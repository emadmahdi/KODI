# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
v1NALptEHU = 'M3U'
s8zrCjhgWx9OvmKq65oefIXHw = '_M3U_'
gXbKi2S5869pG3xc = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
wcJtRB8pgQ0 = 4
def PPFx0TCKwf(Mauf6CrJjP87s,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs,Um2ITJ1iLnEjqZevskVt06NY34,bjSL1IZNRp59z2,wyMiO0VErpqda2hH5cRge):
	global s8zrCjhgWx9OvmKq65oefIXHw
	try:
		JwTceYNvUD = str(wyMiO0VErpqda2hH5cRge['folder'])
		s8zrCjhgWx9OvmKq65oefIXHw = '_MU'+JwTceYNvUD+'_'
	except: JwTceYNvUD = G9G0YqivIfmUWO8K
	try: D0SV9UiuJv4tpezrsNx3dGWRwM1 = str(wyMiO0VErpqda2hH5cRge['sequence'])
	except: D0SV9UiuJv4tpezrsNx3dGWRwM1 = G9G0YqivIfmUWO8K
	if   Mauf6CrJjP87s==710: kqe8AmaJG6pIvUCPSXb = CCeQhu3VlNDkO54IiJfXZgK6()
	elif Mauf6CrJjP87s==711: kqe8AmaJG6pIvUCPSXb = blB4noXQuOqCmLxPG0wYv(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1)
	elif Mauf6CrJjP87s==712: kqe8AmaJG6pIvUCPSXb = VJjIRS372YMKveNq9c(JwTceYNvUD)
	elif Mauf6CrJjP87s==713: kqe8AmaJG6pIvUCPSXb = RlObognJh9DjiHyIE54(JwTceYNvUD,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs,bjSL1IZNRp59z2)
	elif Mauf6CrJjP87s==714: kqe8AmaJG6pIvUCPSXb = Mt7X1vp6TLucKVrw8EUhyI(JwTceYNvUD,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs,bjSL1IZNRp59z2)
	elif Mauf6CrJjP87s==715: kqe8AmaJG6pIvUCPSXb = sWujQcGynM9NtJeTfqk3D(JwTceYNvUD,Qjnkp0KgXq2Ty,Um2ITJ1iLnEjqZevskVt06NY34)
	elif Mauf6CrJjP87s==716: kqe8AmaJG6pIvUCPSXb = i5LeVImdyv7JaXxM3T0qZzw(JwTceYNvUD,True)
	elif Mauf6CrJjP87s==717: kqe8AmaJG6pIvUCPSXb = u6Cyjrzdi2qP7ZDVko4OE5wJTYNXF(JwTceYNvUD,True)
	elif Mauf6CrJjP87s==718: kqe8AmaJG6pIvUCPSXb = uYnNtf8ToWeJ0pDCERQAmiPh(JwTceYNvUD,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==719: kqe8AmaJG6pIvUCPSXb = CEL2jIhns8aW(Vvju9Ht8SGxoiTa6lCs,JwTceYNvUD,Qjnkp0KgXq2Ty,bjSL1IZNRp59z2)
	elif Mauf6CrJjP87s==720: kqe8AmaJG6pIvUCPSXb = fo3aZrpvQn248jXK9CY05DGx(JwTceYNvUD,True)
	elif Mauf6CrJjP87s==721: kqe8AmaJG6pIvUCPSXb = fPyLAr0gzuowDpa(JwTceYNvUD)
	elif Mauf6CrJjP87s==722: kqe8AmaJG6pIvUCPSXb = Jx4svCfeUbwPk(JwTceYNvUD)
	elif Mauf6CrJjP87s==723: kqe8AmaJG6pIvUCPSXb = Cfs1Ux7ruyHISPmZ9e(JwTceYNvUD)
	elif Mauf6CrJjP87s==726: kqe8AmaJG6pIvUCPSXb = Z79ZHEe6Y2dtIRsNbSrnmafADupPg(JwTceYNvUD)
	elif Mauf6CrJjP87s==729: kqe8AmaJG6pIvUCPSXb = Z2M9Opm7tG1qjDTcodLu8PQ3lawW(Vvju9Ht8SGxoiTa6lCs,JwTceYNvUD,Qjnkp0KgXq2Ty,bjSL1IZNRp59z2)
	else: kqe8AmaJG6pIvUCPSXb = False
	return kqe8AmaJG6pIvUCPSXb
def CCeQhu3VlNDkO54IiJfXZgK6():
	for JwTceYNvUD in range(1,XmGcjWDVrAuKeMFlbSvdhYi1+1):
		s8zrCjhgWx9OvmKq65oefIXHw = '_MU'+str(JwTceYNvUD)+'_'
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قائمة مجلد '+F7hmrbfYztVycGjDE4Sd[JwTceYNvUD],G9G0YqivIfmUWO8K,720,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	return
def fo3aZrpvQn248jXK9CY05DGx(JwTceYNvUD=G9G0YqivIfmUWO8K,TThZapolz65vswcfC18AKSdX2HMV=G9G0YqivIfmUWO8K):
	if JwTceYNvUD:
		B2cyihMaYN4DJPA = {'folder':JwTceYNvUD}
		ygLtm7VzT1WZN5Fdfo = G9G0YqivIfmUWO8K
	else:
		B2cyihMaYN4DJPA = G9G0YqivIfmUWO8K
		ygLtm7VzT1WZN5Fdfo = G9G0YqivIfmUWO8K
	fNqkP2zVstyBUJ096rOjxwcS = eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV)
	if not fNqkP2zVstyBUJ096rOjxwcS:
		Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+ipjCIhwEXsbadR+' إضافة وتغيير رابط'+ygLtm7VzT1WZN5Fdfo+ww0sZkBU9JKd+F7hmrbfYztVycGjDE4Sd[1]+' '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,711,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD,'sequence':1})
		Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+ipjCIhwEXsbadR+' جلب ملفات'+ygLtm7VzT1WZN5Fdfo+' '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,712,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	else:
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'بحث في الملفات'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,729,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_',G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مصنفة مرتبة'+ygLtm7VzT1WZN5Fdfo,'LIVE_GROUPED_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مصنفة من القسم'+ygLtm7VzT1WZN5Fdfo,'LIVE_FROM_GROUP_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مصنفة من الاسم'+ygLtm7VzT1WZN5Fdfo,'LIVE_FROM_NAME_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مصنفة بلا ترتيب'+ygLtm7VzT1WZN5Fdfo,'LIVE_GROUPED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات بلا ترتيب'+ygLtm7VzT1WZN5Fdfo,'LIVE_ORIGINAL_GROUPED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مجهولة مرتبة'+ygLtm7VzT1WZN5Fdfo,'LIVE_UNKNOWN_GROUPED_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'قنوات مجهولة بلا ترتيب'+ygLtm7VzT1WZN5Fdfo,'LIVE_UNKNOWN_GROUPED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'فيديوهات بلا ترتيب'+ygLtm7VzT1WZN5Fdfo,'VOD_ORIGINAL_GROUPED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'فيديوهات مصنفة القسم'+ygLtm7VzT1WZN5Fdfo,'VOD_FROM_GROUP_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'فيديوهات مصنفة من الاسم'+ygLtm7VzT1WZN5Fdfo,'VOD_FROM_NAME_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'فيديوهات مجهولة بلا ترتيب'+ygLtm7VzT1WZN5Fdfo,'VOD_UNKNOWN_GROUPED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'فيديوهات مجهولة مرتبة'+ygLtm7VzT1WZN5Fdfo,'VOD_UNKNOWN_GROUPED_SORTED',713,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
		Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'إضافة وتغيير رابط'+ygLtm7VzT1WZN5Fdfo+ww0sZkBU9JKd+F7hmrbfYztVycGjDE4Sd[o6IQax2n7skH],G9G0YqivIfmUWO8K,711,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD,'sequence':o6IQax2n7skH})
	Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'جلب ملفات'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,712,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
	Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'مسح ملفات'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,717,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
	Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'عدد فيديوهات'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,721,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
	Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'Referer تغيير'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,726,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
	Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+'User-Agent تغيير'+ygLtm7VzT1WZN5Fdfo,G9G0YqivIfmUWO8K,723,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,B2cyihMaYN4DJPA)
	return
def i5LeVImdyv7JaXxM3T0qZzw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV=True):
	wlkC1ngAjEUZQSxyXvFe,slI8jRFcrVv = False,G9G0YqivIfmUWO8K
	WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	gDOUW0M5FTu8GhXpa1idEbyZ,kkWUKB6ImOxXwsbfrG9Hdc,GU0EI7ymTzdQqPuaA42rbo,ctli4D8LnsgZp,NJAspjOePFMfDqoRhc3 = GGT9AlBXMKC32J6RIahQwviepW1OHx(JwTceYNvUD)
	if ctli4D8LnsgZp==G9G0YqivIfmUWO8K: return False,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = VVIpNavEdMx2jnDs93lQ(JwTceYNvUD)
	if gDOUW0M5FTu8GhXpa1idEbyZ:
		gULrv3Q4Cq = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',gDOUW0M5FTu8GhXpa1idEbyZ,G9G0YqivIfmUWO8K,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,False,G9G0YqivIfmUWO8K,'M3U-CHECK_ACCOUNT-1st')
		kkKvgtpTiRAhrIEBVm = gULrv3Q4Cq.content
		if gULrv3Q4Cq.succeeded:
			aT06JKfvE89c,BFMDQ3pvRVrgJxPAeuN,ofiAwQNsyU09YOcgVx6kLMrEKXb4JW,ZgrujB1wWvECeR60,EErxYeVGf1 = 0,0,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
			try:
				AvqN68HCXkJbOw1plrYia4ZyRQMGo = bRCSwcA89e4J7pqdays5PxGiD2('dict',kkKvgtpTiRAhrIEBVm)
				slI8jRFcrVv = AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['status']
				wlkC1ngAjEUZQSxyXvFe = True
				ofiAwQNsyU09YOcgVx6kLMrEKXb4JW = AvqN68HCXkJbOw1plrYia4ZyRQMGo['server_info']['time_now']
			except: pass
			if ofiAwQNsyU09YOcgVx6kLMrEKXb4JW:
				try:
					Fmu9jeqH3i04ZhGTy8Ez = SSCU3jdyFn2V.strptime(ofiAwQNsyU09YOcgVx6kLMrEKXb4JW,'%Y.%m.%d %H:%M:%S')
					aT06JKfvE89c = int(SSCU3jdyFn2V.mktime(Fmu9jeqH3i04ZhGTy8Ez))
					BFMDQ3pvRVrgJxPAeuN = int(AVeHPW5shuXLdr2vwD-aT06JKfvE89c)
					BFMDQ3pvRVrgJxPAeuN = int((BFMDQ3pvRVrgJxPAeuN+900)/1800)*1800
				except: pass
				try:
					Fmu9jeqH3i04ZhGTy8Ez = SSCU3jdyFn2V.localtime(int(AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['created_at']))
					ZgrujB1wWvECeR60 = SSCU3jdyFn2V.strftime('%Y.%m.%d %H:%M:%S',Fmu9jeqH3i04ZhGTy8Ez)
				except: pass
				try:
					Fmu9jeqH3i04ZhGTy8Ez = SSCU3jdyFn2V.localtime(int(AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['exp_date']))
					EErxYeVGf1 = SSCU3jdyFn2V.strftime('%Y.%m.%d %H:%M:%S',Fmu9jeqH3i04ZhGTy8Ez)
				except: pass
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.timestamp_'+JwTceYNvUD,str(AVeHPW5shuXLdr2vwD))
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.timediff_'+JwTceYNvUD,str(BFMDQ3pvRVrgJxPAeuN))
			try:
				prnA4ZH7Km5PjY6hab = '"server_info":'+kkKvgtpTiRAhrIEBVm.split('"server_info":')[1]
				prnA4ZH7Km5PjY6hab = prnA4ZH7Km5PjY6hab.replace(':',': ').replace(',',', ').replace('}}','}')
				LXanptOVcH0sD85KlhIyFzbogBuiJ = oo9kuULlebNgpY0Om.findall('"url": "(.*?)", "port": "(.*?)"',prnA4ZH7Km5PjY6hab,oo9kuULlebNgpY0Om.DOTALL)
				WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM = LXanptOVcH0sD85KlhIyFzbogBuiJ[0]
			except: wlkC1ngAjEUZQSxyXvFe = False
			if wlkC1ngAjEUZQSxyXvFe and TThZapolz65vswcfC18AKSdX2HMV:
				max = AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['max_connections']
				jjvWebIxXT = AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['active_cons']
				GkSgjQTCK7WO2xHdhzXM3wr = AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['is_trial']
				nG9iesFo2BwqlbAzSJ0Z = gDOUW0M5FTu8GhXpa1idEbyZ.split('?',1)
				JPhoBimWUM0Gu2H1Fe9fRv8 = 'URL:  '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+gDOUW0M5FTu8GhXpa1idEbyZ+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\n\nStatus:  '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+slI8jRFcrVv+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\nTrial:    '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+str(GkSgjQTCK7WO2xHdhzXM3wr=='1')+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\nCreated  At:  '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+ZgrujB1wWvECeR60+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\nExpiry Date:  '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+EErxYeVGf1+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\nConnections   ( Active / Maximum ) :  '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+jjvWebIxXT+' / '+max+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\nAllowed Outputs:   '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+" , ".join(AvqN68HCXkJbOw1plrYia4ZyRQMGo['user_info']['allowed_output_formats'])+zzGfwLAyN5HTxUoJeaivY
				JPhoBimWUM0Gu2H1Fe9fRv8 += '\n\n'+prnA4ZH7Km5PjY6hab
				if slI8jRFcrVv=='Active': FGHjRISMPqDg('الاشتراك يعمل بدون مشاكل',JPhoBimWUM0Gu2H1Fe9fRv8)
				else: FGHjRISMPqDg('يبدو أن هناك مشكلة في الاشتراك',JPhoBimWUM0Gu2H1Fe9fRv8)
	if gDOUW0M5FTu8GhXpa1idEbyZ and wlkC1ngAjEUZQSxyXvFe and slI8jRFcrVv=='Active':
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+gDOUW0M5FTu8GhXpa1idEbyZ+' ]')
		ISlwNu6cCWfTAQs = True
	else:
		vvqQRbuChP(DqJLhysGer98KFOZ,'Checking M3U URL   [ Does not work ]   [ '+gDOUW0M5FTu8GhXpa1idEbyZ+' ]')
		if TThZapolz65vswcfC18AKSdX2HMV: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		ISlwNu6cCWfTAQs = False
	return ISlwNu6cCWfTAQs,WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM
def Mt7X1vp6TLucKVrw8EUhyI(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ,V9VNQbzlS16Eq,OQka3nI8tDsAZ6ebwMdX,TThZapolz65vswcfC18AKSdX2HMV=True):
	if not OQka3nI8tDsAZ6ebwMdX: OQka3nI8tDsAZ6ebwMdX = '1'
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV): return
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ)
	OKCAQ0sxp94dyuIatJW1B7G2woDh = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list',KEqwWYSFhVzpyBs2D4XZ,V9VNQbzlS16Eq)
	tB7zgXx4UMvo9bY6WHK8Fy = int(OQka3nI8tDsAZ6ebwMdX)*100
	x30lvsJ9hKwoGb1 = tB7zgXx4UMvo9bY6WHK8Fy-100
	for mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in OKCAQ0sxp94dyuIatJW1B7G2woDh[x30lvsJ9hKwoGb1:tB7zgXx4UMvo9bY6WHK8Fy]:
		qdGmpAs1jyN = ('GROUPED' in KEqwWYSFhVzpyBs2D4XZ or KEqwWYSFhVzpyBs2D4XZ=='ALL')
		HHbIDUPa4AW6dfY8TupJB2sQvwnS = ('GROUPED' not in KEqwWYSFhVzpyBs2D4XZ and KEqwWYSFhVzpyBs2D4XZ!='ALL')
		if qdGmpAs1jyN or HHbIDUPa4AW6dfY8TupJB2sQvwnS:
			if   'ARCHIVED'  in KEqwWYSFhVzpyBs2D4XZ: eANQpmZPJaI7wc8.append(['folder',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,718,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,'ARCHIVED',G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD}])
			elif 'EPG' 		 in KEqwWYSFhVzpyBs2D4XZ: eANQpmZPJaI7wc8.append(['folder',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,718,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,'FULL_EPG',G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD}])
			elif 'TIMESHIFT' in KEqwWYSFhVzpyBs2D4XZ: eANQpmZPJaI7wc8.append(['folder',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,718,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,'TIMESHIFT',G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD}])
			elif 'LIVE' 	 in KEqwWYSFhVzpyBs2D4XZ: eANQpmZPJaI7wc8.append(['live',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,715,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,mUTXiaBzJf2utgY3KFIQl,{'folder':JwTceYNvUD}])
			else: eANQpmZPJaI7wc8.append(['video',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,715,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD}])
	fRo3XgN2pxte4MK = len(OKCAQ0sxp94dyuIatJW1B7G2woDh)
	Uvld19IVa5fjZNKpBFMx7OckGQ(JwTceYNvUD,OQka3nI8tDsAZ6ebwMdX,KEqwWYSFhVzpyBs2D4XZ,714,fRo3XgN2pxte4MK,V9VNQbzlS16Eq)
	return
def PpaMYjTR9I40cH1qBDuAvtZWsd(eGmD1MYrduzyp9):
	Qm8SMu6ecXtigDCWw1oak('link',eGmD1MYrduzyp9+'هذه القائمة إما فارغة أو غير موجودة',G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('link',eGmD1MYrduzyp9+'أو الخدمة غير موجودة في اشتراكك',G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('link',eGmD1MYrduzyp9+'أو رابط M3U الذي أنت أضفته غير صحيح',G9G0YqivIfmUWO8K,9999)
	return
def RlObognJh9DjiHyIE54(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ,V9VNQbzlS16Eq,OQka3nI8tDsAZ6ebwMdX,OOhvpPg0eUKFs6A3Bl=G9G0YqivIfmUWO8K,TThZapolz65vswcfC18AKSdX2HMV=True):
	if not OQka3nI8tDsAZ6ebwMdX: OQka3nI8tDsAZ6ebwMdX = '1'
	eGmD1MYrduzyp9 = s8zrCjhgWx9OvmKq65oefIXHw
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV): return False
	if '__SERIES__' in V9VNQbzlS16Eq: xFA1dDUuhcKLMibG8vSa,aavhilPLErGAzK20YdpH = V9VNQbzlS16Eq.split('__SERIES__')
	else: xFA1dDUuhcKLMibG8vSa,aavhilPLErGAzK20YdpH = V9VNQbzlS16Eq,G9G0YqivIfmUWO8K
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ)
	tgRjFUHc65OIZMABD7ndkmr0 = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list',KEqwWYSFhVzpyBs2D4XZ,'__GROUPS__')
	if not tgRjFUHc65OIZMABD7ndkmr0: return False
	QViRKMsWtDPHY7FLzClrqJ = []
	for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in tgRjFUHc65OIZMABD7ndkmr0:
		if '===== ===== =====' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6:
			Qm8SMu6ecXtigDCWw1oak('link',eGmD1MYrduzyp9+lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,9999)
			Qm8SMu6ecXtigDCWw1oak('link',eGmD1MYrduzyp9+lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,9999)
			continue
		if OOhvpPg0eUKFs6A3Bl:
			if '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: eGmD1MYrduzyp9 = 'SERIES'
			elif '!!__UNKNOWN__!!' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: eGmD1MYrduzyp9 = 'UNKNOWN'
			elif 'LIVE' in KEqwWYSFhVzpyBs2D4XZ: eGmD1MYrduzyp9 = 'LIVE'
			else: eGmD1MYrduzyp9 = 'VIDEOS'
			eGmD1MYrduzyp9 = ','+A7XhkmSYZlidyMt5FpWqTgjNezbnD+eGmD1MYrduzyp9+': '+zzGfwLAyN5HTxUoJeaivY
		if '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: cNPROyZITLV,fJ0CE6GXpxF1n5K3vaoN = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.split('__SERIES__')
		else: cNPROyZITLV,fJ0CE6GXpxF1n5K3vaoN = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K
		if not V9VNQbzlS16Eq:
			if cNPROyZITLV in QViRKMsWtDPHY7FLzClrqJ: continue
			QViRKMsWtDPHY7FLzClrqJ.append(cNPROyZITLV)
			if 'RANDOM' in OOhvpPg0eUKFs6A3Bl: Qm8SMu6ecXtigDCWw1oak('folder',eGmD1MYrduzyp9+cNPROyZITLV,KEqwWYSFhVzpyBs2D4XZ,168,G9G0YqivIfmUWO8K,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
			elif '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: Qm8SMu6ecXtigDCWw1oak('folder',eGmD1MYrduzyp9+cNPROyZITLV,KEqwWYSFhVzpyBs2D4XZ,713,G9G0YqivIfmUWO8K,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
			else: Qm8SMu6ecXtigDCWw1oak('folder',eGmD1MYrduzyp9+cNPROyZITLV,KEqwWYSFhVzpyBs2D4XZ,714,G9G0YqivIfmUWO8K,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
		elif '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 and cNPROyZITLV==xFA1dDUuhcKLMibG8vSa:
			if fJ0CE6GXpxF1n5K3vaoN in QViRKMsWtDPHY7FLzClrqJ: continue
			QViRKMsWtDPHY7FLzClrqJ.append(fJ0CE6GXpxF1n5K3vaoN)
			if 'RANDOM' in OOhvpPg0eUKFs6A3Bl: Qm8SMu6ecXtigDCWw1oak('folder',eGmD1MYrduzyp9+fJ0CE6GXpxF1n5K3vaoN,KEqwWYSFhVzpyBs2D4XZ,168,G9G0YqivIfmUWO8K,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
			else: Qm8SMu6ecXtigDCWw1oak('folder',eGmD1MYrduzyp9+fJ0CE6GXpxF1n5K3vaoN,KEqwWYSFhVzpyBs2D4XZ,714,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	eANQpmZPJaI7wc8[:] = sorted(eANQpmZPJaI7wc8,reverse=False,key=lambda u2ynb8RckJiqGpeV07hEF63: u2ynb8RckJiqGpeV07hEF63[1].lower())
	if not OOhvpPg0eUKFs6A3Bl:
		tB7zgXx4UMvo9bY6WHK8Fy = int(OQka3nI8tDsAZ6ebwMdX)*100
		x30lvsJ9hKwoGb1 = tB7zgXx4UMvo9bY6WHK8Fy-100
		fRo3XgN2pxte4MK = len(eANQpmZPJaI7wc8)
		eANQpmZPJaI7wc8[:] = eANQpmZPJaI7wc8[x30lvsJ9hKwoGb1:tB7zgXx4UMvo9bY6WHK8Fy]
		Uvld19IVa5fjZNKpBFMx7OckGQ(JwTceYNvUD,OQka3nI8tDsAZ6ebwMdX,KEqwWYSFhVzpyBs2D4XZ,713,fRo3XgN2pxte4MK,V9VNQbzlS16Eq)
	return True
def uYnNtf8ToWeJ0pDCERQAmiPh(JwTceYNvUD,Qjnkp0KgXq2Ty,XPW8BQhGt5jAdFyzEmnpo):
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,True): return
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = VVIpNavEdMx2jnDs93lQ(JwTceYNvUD)
	aT06JKfvE89c = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.timestamp_'+JwTceYNvUD)
	if not aT06JKfvE89c or AVeHPW5shuXLdr2vwD-int(aT06JKfvE89c)>24*UadgtfoXpJGL9zZcKHq0yFnI:
		ISlwNu6cCWfTAQs,WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM = i5LeVImdyv7JaXxM3T0qZzw(JwTceYNvUD,False)
		if not ISlwNu6cCWfTAQs: return
	BFMDQ3pvRVrgJxPAeuN = int(amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.timediff_'+JwTceYNvUD))
	GU0EI7ymTzdQqPuaA42rbo = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.server_'+JwTceYNvUD)
	ctli4D8LnsgZp = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.username_'+JwTceYNvUD)
	NJAspjOePFMfDqoRhc3 = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.password_'+JwTceYNvUD)
	IhKqk8DvmYsnXueZ9HE7yNJ = Qjnkp0KgXq2Ty.split('/')
	PPkLQ09xs2W = IhKqk8DvmYsnXueZ9HE7yNJ[-1].replace('.ts',G9G0YqivIfmUWO8K).replace('.m3u8',G9G0YqivIfmUWO8K)
	if XPW8BQhGt5jAdFyzEmnpo=='SHORT_EPG': PXyKUGTwtVB05r2d369o = 'get_short_epg'
	else: PXyKUGTwtVB05r2d369o = 'get_simple_data_table'
	gDOUW0M5FTu8GhXpa1idEbyZ,kkWUKB6ImOxXwsbfrG9Hdc,GU0EI7ymTzdQqPuaA42rbo,ctli4D8LnsgZp,NJAspjOePFMfDqoRhc3 = GGT9AlBXMKC32J6RIahQwviepW1OHx(JwTceYNvUD)
	if not ctli4D8LnsgZp: return
	FFbar2ZhfOC8l = gDOUW0M5FTu8GhXpa1idEbyZ+'&action='+PXyKUGTwtVB05r2d369o+'&stream_id='+PPkLQ09xs2W
	kkKvgtpTiRAhrIEBVm = GLX7ygNq3Y5xw4S8laJjes(gWhZuzBnwiUVx5RoGFc6O7Hb,FFbar2ZhfOC8l,G9G0YqivIfmUWO8K,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,G9G0YqivIfmUWO8K,'M3U-EPG_ITEMS-2nd')
	BFpf47VTQocgsJn = bRCSwcA89e4J7pqdays5PxGiD2('dict',kkKvgtpTiRAhrIEBVm)
	baNl2cJyjmeARf = BFpf47VTQocgsJn['epg_listings']
	tMedaD3JgPFGXQlEV2fwHKA0Bn = []
	if XPW8BQhGt5jAdFyzEmnpo in ['ARCHIVED','TIMESHIFT']:
		for AvqN68HCXkJbOw1plrYia4ZyRQMGo in baNl2cJyjmeARf:
			if AvqN68HCXkJbOw1plrYia4ZyRQMGo['has_archive']==1:
				tMedaD3JgPFGXQlEV2fwHKA0Bn.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo)
				if XPW8BQhGt5jAdFyzEmnpo in ['TIMESHIFT']: break
		if not tMedaD3JgPFGXQlEV2fwHKA0Bn: return
		Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+A7XhkmSYZlidyMt5FpWqTgjNezbnD+'الملفات الأولي بهذه القائمة قد لا تعمل'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		if XPW8BQhGt5jAdFyzEmnpo in ['TIMESHIFT']:
			Gf4MkBvdXhNJ1c9Q = 2
			l6l2Rpejn8TPYvE5wzOomCSBQg = Gf4MkBvdXhNJ1c9Q*UadgtfoXpJGL9zZcKHq0yFnI
			tMedaD3JgPFGXQlEV2fwHKA0Bn = []
			BYCKesPXadhNigfT = int(int(AvqN68HCXkJbOw1plrYia4ZyRQMGo['start_timestamp'])/l6l2Rpejn8TPYvE5wzOomCSBQg)*l6l2Rpejn8TPYvE5wzOomCSBQg
			YlD7wBQmLN3rqfAM8i = AVeHPW5shuXLdr2vwD+l6l2Rpejn8TPYvE5wzOomCSBQg
			iUpbCms7L2AczxKoMDYOh5SX08 = int((YlD7wBQmLN3rqfAM8i-BYCKesPXadhNigfT)/UadgtfoXpJGL9zZcKHq0yFnI)
			for UZq3rSzmpw61ALGCIeuxBRyhb75V4 in range(iUpbCms7L2AczxKoMDYOh5SX08):
				if UZq3rSzmpw61ALGCIeuxBRyhb75V4>=6:
					if UZq3rSzmpw61ALGCIeuxBRyhb75V4%Gf4MkBvdXhNJ1c9Q!=0: continue
					TlMHUhYWy2G = l6l2Rpejn8TPYvE5wzOomCSBQg
				else: TlMHUhYWy2G = l6l2Rpejn8TPYvE5wzOomCSBQg//2
				ZXFR8OKCtmUrieVEogGdqpWaDA = BYCKesPXadhNigfT+UZq3rSzmpw61ALGCIeuxBRyhb75V4*UadgtfoXpJGL9zZcKHq0yFnI
				AvqN68HCXkJbOw1plrYia4ZyRQMGo = {}
				AvqN68HCXkJbOw1plrYia4ZyRQMGo['title'] = G9G0YqivIfmUWO8K
				Fmu9jeqH3i04ZhGTy8Ez = SSCU3jdyFn2V.localtime(ZXFR8OKCtmUrieVEogGdqpWaDA-BFMDQ3pvRVrgJxPAeuN-UadgtfoXpJGL9zZcKHq0yFnI)
				AvqN68HCXkJbOw1plrYia4ZyRQMGo['start'] = SSCU3jdyFn2V.strftime('%Y.%m.%d %H:%M:%S',Fmu9jeqH3i04ZhGTy8Ez)
				AvqN68HCXkJbOw1plrYia4ZyRQMGo['start_timestamp'] = str(ZXFR8OKCtmUrieVEogGdqpWaDA)
				AvqN68HCXkJbOw1plrYia4ZyRQMGo['stop_timestamp'] = str(ZXFR8OKCtmUrieVEogGdqpWaDA+TlMHUhYWy2G)
				tMedaD3JgPFGXQlEV2fwHKA0Bn.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo)
	elif XPW8BQhGt5jAdFyzEmnpo in ['SHORT_EPG','FULL_EPG']: tMedaD3JgPFGXQlEV2fwHKA0Bn = baNl2cJyjmeARf
	if XPW8BQhGt5jAdFyzEmnpo=='FULL_EPG' and len(tMedaD3JgPFGXQlEV2fwHKA0Bn)>0:
		Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+A7XhkmSYZlidyMt5FpWqTgjNezbnD+'هذه قائمة برامج القنوات (جدول فقط)ـ'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	ZfJYO690k3AznXa = []
	XXq21TJ3Zo4FuYDEgh9GBcLPOVR = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Icon')
	for AvqN68HCXkJbOw1plrYia4ZyRQMGo in tMedaD3JgPFGXQlEV2fwHKA0Bn:
		G3V6fB4UjqZA1pH5mENOsa = jaFsD83SB9ZQkrxeI.b64decode(AvqN68HCXkJbOw1plrYia4ZyRQMGo['title'])
		if LTze51miOknVcslNF43WSA6vMjYZt: G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		ZXFR8OKCtmUrieVEogGdqpWaDA = int(AvqN68HCXkJbOw1plrYia4ZyRQMGo['start_timestamp'])
		fnQ5aXMHLlgWwiy3hdpDuPvt = int(AvqN68HCXkJbOw1plrYia4ZyRQMGo['stop_timestamp'])
		K3AEkHnwW52UJoVhtfu = str(int((fnQ5aXMHLlgWwiy3hdpDuPvt-ZXFR8OKCtmUrieVEogGdqpWaDA+59)/60))
		BJ81U0PbxuH = AvqN68HCXkJbOw1plrYia4ZyRQMGo['start'].replace(ww0sZkBU9JKd,':')
		Fmu9jeqH3i04ZhGTy8Ez = SSCU3jdyFn2V.localtime(ZXFR8OKCtmUrieVEogGdqpWaDA-UadgtfoXpJGL9zZcKHq0yFnI)
		mn9bB23Frt6EYTAi84w = SSCU3jdyFn2V.strftime('%H:%M',Fmu9jeqH3i04ZhGTy8Ez)
		DlKFidsEL8zTOwfJ5q7 = SSCU3jdyFn2V.strftime('%a',Fmu9jeqH3i04ZhGTy8Ez)
		if XPW8BQhGt5jAdFyzEmnpo=='SHORT_EPG': G3V6fB4UjqZA1pH5mENOsa = ipjCIhwEXsbadR+mn9bB23Frt6EYTAi84w+' ـ '+G3V6fB4UjqZA1pH5mENOsa+zzGfwLAyN5HTxUoJeaivY
		elif XPW8BQhGt5jAdFyzEmnpo=='TIMESHIFT': G3V6fB4UjqZA1pH5mENOsa = DlKFidsEL8zTOwfJ5q7+ww0sZkBU9JKd+mn9bB23Frt6EYTAi84w+' ('+K3AEkHnwW52UJoVhtfu+'min)'
		else: G3V6fB4UjqZA1pH5mENOsa = DlKFidsEL8zTOwfJ5q7+ww0sZkBU9JKd+mn9bB23Frt6EYTAi84w+' ('+K3AEkHnwW52UJoVhtfu+'min)   '+G3V6fB4UjqZA1pH5mENOsa+' ـ'
		if XPW8BQhGt5jAdFyzEmnpo in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			ChcXBm4IvLWZ0sdFbAJ23gTeyDiuf = GU0EI7ymTzdQqPuaA42rbo+'/timeshift/'+ctli4D8LnsgZp+'/'+NJAspjOePFMfDqoRhc3+'/'+K3AEkHnwW52UJoVhtfu+'/'+BJ81U0PbxuH+'/'+PPkLQ09xs2W+'.m3u8'
			if XPW8BQhGt5jAdFyzEmnpo=='FULL_EPG': Qm8SMu6ecXtigDCWw1oak('link',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,ChcXBm4IvLWZ0sdFbAJ23gTeyDiuf,9999,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
			else: Qm8SMu6ecXtigDCWw1oak('video',s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,ChcXBm4IvLWZ0sdFbAJ23gTeyDiuf,715,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
		ZfJYO690k3AznXa.append(G3V6fB4UjqZA1pH5mENOsa)
	if XPW8BQhGt5jAdFyzEmnpo=='SHORT_EPG' and ZfJYO690k3AznXa: wOEVKJtblosZn5j = Ld0qx6IJ4kEtpXv9KieZ(ZfJYO690k3AznXa)
	return ZfJYO690k3AznXa
def Jx4svCfeUbwPk(JwTceYNvUD):
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,True): return
	GU0EI7ymTzdQqPuaA42rbo,e4OxkhgnGZRLIt2mDEUq0KfBAd,UC0T4Q1FNSbaPW5Lrd = G9G0YqivIfmUWO8K,0,0
	ISlwNu6cCWfTAQs,WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM = i5LeVImdyv7JaXxM3T0qZzw(JwTceYNvUD,False)
	if ISlwNu6cCWfTAQs:
		mwMvguECL6tzZpH = JKneMTZDt6Vfp5a(WQ8bBsl5j3XzM1vZnT)
		e4OxkhgnGZRLIt2mDEUq0KfBAd = bbLMfWytx9laFd41(mwMvguECL6tzZpH[0],int(mBnYcg28z3tKM))
		oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,'LIVE_GROUPED')
		lnLEoFyazbjp9eSKcQV0C6 = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list','LIVE_GROUPED')
		OKCAQ0sxp94dyuIatJW1B7G2woDh = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list','LIVE_GROUPED',lnLEoFyazbjp9eSKcQV0C6[1])
		Qjnkp0KgXq2Ty = OKCAQ0sxp94dyuIatJW1B7G2woDh[0][2]
		Et64uLyxTV3vQzw = oo9kuULlebNgpY0Om.findall('://(.*?)/',Qjnkp0KgXq2Ty,oo9kuULlebNgpY0Om.DOTALL)
		Et64uLyxTV3vQzw = Et64uLyxTV3vQzw[0]
		if ':' in Et64uLyxTV3vQzw: GSfsz7YP96jcM4J,uZgakC7oxplsH = Et64uLyxTV3vQzw.split(':')
		else: GSfsz7YP96jcM4J,uZgakC7oxplsH = Et64uLyxTV3vQzw,'80'
		VHOS683dNFjo2bscamTlKQWZ5 = JKneMTZDt6Vfp5a(GSfsz7YP96jcM4J)
		UC0T4Q1FNSbaPW5Lrd = bbLMfWytx9laFd41(VHOS683dNFjo2bscamTlKQWZ5[0],int(uZgakC7oxplsH))
	if e4OxkhgnGZRLIt2mDEUq0KfBAd and UC0T4Q1FNSbaPW5Lrd:
		JPhoBimWUM0Gu2H1Fe9fRv8 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		JPhoBimWUM0Gu2H1Fe9fRv8 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+zEgtT9cR6bFp7JXqI5VuhNeP+str(int(UC0T4Q1FNSbaPW5Lrd*1000))+' ملي ثانية'
		JPhoBimWUM0Gu2H1Fe9fRv8 += '\n\n'+'وقت ضائع في السيرفر البديل'+zEgtT9cR6bFp7JXqI5VuhNeP+str(int(e4OxkhgnGZRLIt2mDEUq0KfBAd*1000))+' ملي ثانية'
		KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',JPhoBimWUM0Gu2H1Fe9fRv8)
		if KKrj6Fkd5Tgv9ImSAGyaEeLcipt==1 and e4OxkhgnGZRLIt2mDEUq0KfBAd<UC0T4Q1FNSbaPW5Lrd: GU0EI7ymTzdQqPuaA42rbo = WQ8bBsl5j3XzM1vZnT+':'+mBnYcg28z3tKM
	else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.server_'+JwTceYNvUD,GU0EI7ymTzdQqPuaA42rbo)
	return
def sWujQcGynM9NtJeTfqk3D(JwTceYNvUD,Qjnkp0KgXq2Ty,Um2ITJ1iLnEjqZevskVt06NY34):
	fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.useragent_'+JwTceYNvUD)
	OOnwpmsUEt5jLB9H3TlRPGc0M = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.referer_'+JwTceYNvUD)
	if fwYj6oCrh9Z3q7xd0NnlMO2K8J4P or OOnwpmsUEt5jLB9H3TlRPGc0M:
		Qjnkp0KgXq2Ty += '|'
		if fwYj6oCrh9Z3q7xd0NnlMO2K8J4P: Qjnkp0KgXq2Ty += '&User-Agent='+fwYj6oCrh9Z3q7xd0NnlMO2K8J4P
		if OOnwpmsUEt5jLB9H3TlRPGc0M: Qjnkp0KgXq2Ty += '&Referer='+OOnwpmsUEt5jLB9H3TlRPGc0M
		Qjnkp0KgXq2Ty = Qjnkp0KgXq2Ty.replace('|&','|')
	Imphr8LRTUDs(Qjnkp0KgXq2Ty,v1NALptEHU,Um2ITJ1iLnEjqZevskVt06NY34)
	return
def Cfs1Ux7ruyHISPmZ9e(JwTceYNvUD):
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.useragent_'+JwTceYNvUD)
	g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center','استخدام الأصلي','تعديل القديم',fwYj6oCrh9Z3q7xd0NnlMO2K8J4P,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if g8FVIbLGmlpQHPw052T1XD==1: fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = ZT7zGWSCtpvfmwMNRjYrKL('أكتب ـM3U User-Agent جديد',fwYj6oCrh9Z3q7xd0NnlMO2K8J4P,True)
	else: fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = 'Unknown'
	if fwYj6oCrh9Z3q7xd0NnlMO2K8J4P==ww0sZkBU9JKd:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,fwYj6oCrh9Z3q7xd0NnlMO2K8J4P,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if g8FVIbLGmlpQHPw052T1XD!=1:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم الإلغاء')
		return
	amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.useragent_'+JwTceYNvUD,fwYj6oCrh9Z3q7xd0NnlMO2K8J4P)
	WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD)
	return
def Z79ZHEe6Y2dtIRsNbSrnmafADupPg(JwTceYNvUD):
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	OOnwpmsUEt5jLB9H3TlRPGc0M = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.referer_'+JwTceYNvUD)
	g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center','استخدام الأصلي','تعديل القديم',OOnwpmsUEt5jLB9H3TlRPGc0M,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if g8FVIbLGmlpQHPw052T1XD==1: OOnwpmsUEt5jLB9H3TlRPGc0M = ZT7zGWSCtpvfmwMNRjYrKL('أكتب ـM3U Referer جديد',OOnwpmsUEt5jLB9H3TlRPGc0M,True)
	else: OOnwpmsUEt5jLB9H3TlRPGc0M = G9G0YqivIfmUWO8K
	if OOnwpmsUEt5jLB9H3TlRPGc0M==ww0sZkBU9JKd:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,OOnwpmsUEt5jLB9H3TlRPGc0M,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if g8FVIbLGmlpQHPw052T1XD!=1:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم الإلغاء')
		return
	amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.referer_'+JwTceYNvUD,OOnwpmsUEt5jLB9H3TlRPGc0M)
	WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD)
	return
def GGT9AlBXMKC32J6RIahQwviepW1OHx(JwTceYNvUD,Q3xyEugNYZGnctw6hiMJKldem=G9G0YqivIfmUWO8K):
	if not eT8PjlaAmBQ7LxzbW61JDc: eT8PjlaAmBQ7LxzbW61JDc = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.url_'+JwTceYNvUD)
	GU0EI7ymTzdQqPuaA42rbo = xWiOjcUrJVdtP4B5Iml(eT8PjlaAmBQ7LxzbW61JDc,'url')
	ctli4D8LnsgZp = oo9kuULlebNgpY0Om.findall('username=(.*?)&',eT8PjlaAmBQ7LxzbW61JDc+'&',oo9kuULlebNgpY0Om.DOTALL)
	NJAspjOePFMfDqoRhc3 = oo9kuULlebNgpY0Om.findall('password=(.*?)&',eT8PjlaAmBQ7LxzbW61JDc+'&',oo9kuULlebNgpY0Om.DOTALL)
	if not ctli4D8LnsgZp or not NJAspjOePFMfDqoRhc3:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	ctli4D8LnsgZp = ctli4D8LnsgZp[0]
	NJAspjOePFMfDqoRhc3 = NJAspjOePFMfDqoRhc3[0]
	gDOUW0M5FTu8GhXpa1idEbyZ = GU0EI7ymTzdQqPuaA42rbo+'/player_api.php?username='+ctli4D8LnsgZp+'&password='+NJAspjOePFMfDqoRhc3
	kkWUKB6ImOxXwsbfrG9Hdc = GU0EI7ymTzdQqPuaA42rbo+'/get.php?username='+ctli4D8LnsgZp+'&password='+NJAspjOePFMfDqoRhc3+'&type=m3u_plus'
	return gDOUW0M5FTu8GhXpa1idEbyZ,kkWUKB6ImOxXwsbfrG9Hdc,GU0EI7ymTzdQqPuaA42rbo,ctli4D8LnsgZp,NJAspjOePFMfDqoRhc3
def G4mzc9gC6npILJ7P(JwTceYNvUD,x24eYSlf6NJDQb5RTIVyq=G9G0YqivIfmUWO8K):
	F5f1jkbEJOcT7vtQHYBSZxdn3WD6 = x24eYSlf6NJDQb5RTIVyq.replace('/','_').replace(':','_').replace('.','_')
	F5f1jkbEJOcT7vtQHYBSZxdn3WD6 = F5f1jkbEJOcT7vtQHYBSZxdn3WD6.replace('?','_').replace('=','_').replace('&','_')
	F5f1jkbEJOcT7vtQHYBSZxdn3WD6 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,F5f1jkbEJOcT7vtQHYBSZxdn3WD6).strip('.m3u')+'.m3u'
	return F5f1jkbEJOcT7vtQHYBSZxdn3WD6
def blB4noXQuOqCmLxPG0wYv(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1):
	JG75vAFcM2Ww1Zb6zLBPqE = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.url_'+JwTceYNvUD+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
	ASY6agMBdFx8GQntb = True
	if JG75vAFcM2Ww1Zb6zLBPqE:
		g8FVIbLGmlpQHPw052T1XD = YZL469QjvSV('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',A7XhkmSYZlidyMt5FpWqTgjNezbnD+JG75vAFcM2Ww1Zb6zLBPqE+zzGfwLAyN5HTxUoJeaivY+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if g8FVIbLGmlpQHPw052T1XD==-1: return
		elif g8FVIbLGmlpQHPw052T1XD==0: JG75vAFcM2Ww1Zb6zLBPqE = G9G0YqivIfmUWO8K
		elif g8FVIbLGmlpQHPw052T1XD==2:
			g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if g8FVIbLGmlpQHPw052T1XD in [-1,0]: return
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم مسح الرابط')
			ASY6agMBdFx8GQntb = False
			AYMGqjPsKNbfUxht3neo16CiF8pXQ7 = G9G0YqivIfmUWO8K
	if ASY6agMBdFx8GQntb:
		AYMGqjPsKNbfUxht3neo16CiF8pXQ7 = ZT7zGWSCtpvfmwMNRjYrKL('اكتب رابط M3U كاملا',JG75vAFcM2Ww1Zb6zLBPqE)
		AYMGqjPsKNbfUxht3neo16CiF8pXQ7 = AYMGqjPsKNbfUxht3neo16CiF8pXQ7.strip(ww0sZkBU9JKd)
		if not AYMGqjPsKNbfUxht3neo16CiF8pXQ7:
			g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if g8FVIbLGmlpQHPw052T1XD in [-1,0]: return
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم مسح الرابط')
		else:
			JPhoBimWUM0Gu2H1Fe9fRv8 = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			g8FVIbLGmlpQHPw052T1XD = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'الرابط الجديد هو:',A7XhkmSYZlidyMt5FpWqTgjNezbnD+AYMGqjPsKNbfUxht3neo16CiF8pXQ7+zzGfwLAyN5HTxUoJeaivY+'\n\n'+JPhoBimWUM0Gu2H1Fe9fRv8)
			if g8FVIbLGmlpQHPw052T1XD!=1:
				hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم الإلغاء')
				return
	amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.url_'+JwTceYNvUD+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1,AYMGqjPsKNbfUxht3neo16CiF8pXQ7)
	fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.useragent_'+JwTceYNvUD)
	if not fwYj6oCrh9Z3q7xd0NnlMO2K8J4P: amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.useragent_'+JwTceYNvUD,'Unknown')
	WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD)
	return
def XsMebRQd057npq(RJBGyivQKTech8DM9xN,b4htYQl9qDyfX5oHsIC,eOpIEhaBd5MRj6f0sNA,D2vJY7Wkuxdr0t6oX1zIjMeFg,JPLChxqYSwU1syfdIVnOHT7Xrc0,xXiojqUmVlbuSnswBhQ,kkWUKB6ImOxXwsbfrG9Hdc):
	OKCAQ0sxp94dyuIatJW1B7G2woDh,i9j5HT3mP7sUleYhZcwdWz = [],[]
	u2dc3VljGRUbL = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		if xXiojqUmVlbuSnswBhQ%473==0:
			CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,40+int(10*xXiojqUmVlbuSnswBhQ/JPLChxqYSwU1syfdIVnOHT7Xrc0),'قراءة الفيديوهات','الفيديو رقم:-',str(xXiojqUmVlbuSnswBhQ)+' / '+str(JPLChxqYSwU1syfdIVnOHT7Xrc0))
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return None,None,None
		Qjnkp0KgXq2Ty = oo9kuULlebNgpY0Om.findall('^(.*?)\n+((http|https|rtmp).*?)$',B71KDuTRjsXOcoh4JWbPdMSi28A,oo9kuULlebNgpY0Om.DOTALL)
		if Qjnkp0KgXq2Ty:
			B71KDuTRjsXOcoh4JWbPdMSi28A,Qjnkp0KgXq2Ty,v2v3YoplfDdKJEhW5i = Qjnkp0KgXq2Ty[0]
			Qjnkp0KgXq2Ty = Qjnkp0KgXq2Ty.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K)
			B71KDuTRjsXOcoh4JWbPdMSi28A = B71KDuTRjsXOcoh4JWbPdMSi28A.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K)
		else:
			i9j5HT3mP7sUleYhZcwdWz.append({'line':B71KDuTRjsXOcoh4JWbPdMSi28A})
			continue
		VVvclNfCzqtrZk5QISL,mUTXiaBzJf2utgY3KFIQl,lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G3V6fB4UjqZA1pH5mENOsa,Um2ITJ1iLnEjqZevskVt06NY34,HtNpLJ96T7ZqYEDS = {},G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,False
		try:
			B71KDuTRjsXOcoh4JWbPdMSi28A,G3V6fB4UjqZA1pH5mENOsa = B71KDuTRjsXOcoh4JWbPdMSi28A.rsplit('",',1)
			B71KDuTRjsXOcoh4JWbPdMSi28A = B71KDuTRjsXOcoh4JWbPdMSi28A+'"'
		except:
			try: B71KDuTRjsXOcoh4JWbPdMSi28A,G3V6fB4UjqZA1pH5mENOsa = B71KDuTRjsXOcoh4JWbPdMSi28A.rsplit('1,',1)
			except: G3V6fB4UjqZA1pH5mENOsa = G9G0YqivIfmUWO8K
		VVvclNfCzqtrZk5QISL['url'] = Qjnkp0KgXq2Ty
		aZnyb4g6BLzMGNXfeYTjqU = oo9kuULlebNgpY0Om.findall(' (.*?)="(.*?)"',B71KDuTRjsXOcoh4JWbPdMSi28A,oo9kuULlebNgpY0Om.DOTALL)
		for u2ynb8RckJiqGpeV07hEF63,bZYntjRQarszwWUv0XT in aZnyb4g6BLzMGNXfeYTjqU:
			u2ynb8RckJiqGpeV07hEF63 = u2ynb8RckJiqGpeV07hEF63.replace('"',G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			VVvclNfCzqtrZk5QISL[u2ynb8RckJiqGpeV07hEF63] = bZYntjRQarszwWUv0XT.strip(ww0sZkBU9JKd)
		vvrMZbHyPu6W2Emta8 = list(VVvclNfCzqtrZk5QISL.keys())
		if not G3V6fB4UjqZA1pH5mENOsa:
			if 'name' in vvrMZbHyPu6W2Emta8 and VVvclNfCzqtrZk5QISL['name']: G3V6fB4UjqZA1pH5mENOsa = VVvclNfCzqtrZk5QISL['name']
		VVvclNfCzqtrZk5QISL['title'] = G3V6fB4UjqZA1pH5mENOsa.strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		if 'logo' in vvrMZbHyPu6W2Emta8:
			VVvclNfCzqtrZk5QISL['img'] = VVvclNfCzqtrZk5QISL['logo']
			del VVvclNfCzqtrZk5QISL['logo']
		else: VVvclNfCzqtrZk5QISL['img'] = G9G0YqivIfmUWO8K
		if 'group' in vvrMZbHyPu6W2Emta8 and VVvclNfCzqtrZk5QISL['group']: lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = VVvclNfCzqtrZk5QISL['group']
		if any(yW70dtahIjkPCJg2TA in Qjnkp0KgXq2Ty.lower() for yW70dtahIjkPCJg2TA in u2dc3VljGRUbL):
			HtNpLJ96T7ZqYEDS = True if 'm3u' not in Qjnkp0KgXq2Ty else False
		if HtNpLJ96T7ZqYEDS or '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 or '__MOVIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6:
			Um2ITJ1iLnEjqZevskVt06NY34 = 'VOD'
			if '__SERIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: Um2ITJ1iLnEjqZevskVt06NY34 = Um2ITJ1iLnEjqZevskVt06NY34+'_SERIES'
			elif '__MOVIES__' in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: Um2ITJ1iLnEjqZevskVt06NY34 = Um2ITJ1iLnEjqZevskVt06NY34+'_MOVIES'
			else: Um2ITJ1iLnEjqZevskVt06NY34 = Um2ITJ1iLnEjqZevskVt06NY34+'_UNKNOWN'
			lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.replace('__SERIES__',G9G0YqivIfmUWO8K).replace('__MOVIES__',G9G0YqivIfmUWO8K)
		else:
			Um2ITJ1iLnEjqZevskVt06NY34 = 'LIVE'
			if G3V6fB4UjqZA1pH5mENOsa in b4htYQl9qDyfX5oHsIC: mUTXiaBzJf2utgY3KFIQl = mUTXiaBzJf2utgY3KFIQl+'_EPG'
			if G3V6fB4UjqZA1pH5mENOsa in eOpIEhaBd5MRj6f0sNA: mUTXiaBzJf2utgY3KFIQl = mUTXiaBzJf2utgY3KFIQl+'_ARCHIVED'
			if not lQRCX7wUkWf1Opjaxbno2ZDh5GAi6: Um2ITJ1iLnEjqZevskVt06NY34 = Um2ITJ1iLnEjqZevskVt06NY34+'_UNKNOWN'
			else: Um2ITJ1iLnEjqZevskVt06NY34 = Um2ITJ1iLnEjqZevskVt06NY34+mUTXiaBzJf2utgY3KFIQl
		lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		if 'LIVE_UNKNOWN' in Um2ITJ1iLnEjqZevskVt06NY34: lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in Um2ITJ1iLnEjqZevskVt06NY34: lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in Um2ITJ1iLnEjqZevskVt06NY34:
			aF3TqBgOZc8 = oo9kuULlebNgpY0Om.findall('(.*?) [Ss]\d+ +[Ee]\d+',VVvclNfCzqtrZk5QISL['title'],oo9kuULlebNgpY0Om.DOTALL)
			if aF3TqBgOZc8: aF3TqBgOZc8 = aF3TqBgOZc8[0]
			else: aF3TqBgOZc8 = '!!__UNKNOWN_SERIES__!!'
			lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6+'__SERIES__'+aF3TqBgOZc8
		if 'id' in vvrMZbHyPu6W2Emta8: del VVvclNfCzqtrZk5QISL['id']
		if 'ID' in vvrMZbHyPu6W2Emta8: del VVvclNfCzqtrZk5QISL['ID']
		if 'name' in vvrMZbHyPu6W2Emta8: del VVvclNfCzqtrZk5QISL['name']
		G3V6fB4UjqZA1pH5mENOsa = VVvclNfCzqtrZk5QISL['title']
		G3V6fB4UjqZA1pH5mENOsa = zDBtm4MwIagkfcpE5oxJOAq6lZQY(G3V6fB4UjqZA1pH5mENOsa)
		G3V6fB4UjqZA1pH5mENOsa = MqrEiwKemZ1phV5o2L(G3V6fB4UjqZA1pH5mENOsa)
		huLZj7o4gQd6v,lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 = xmbACRhBj3PK7a6OQ1odYc(lQRCX7wUkWf1Opjaxbno2ZDh5GAi6)
		dR1OT0s4Mm9BKjJp6zkclVnfyP,G3V6fB4UjqZA1pH5mENOsa = xmbACRhBj3PK7a6OQ1odYc(G3V6fB4UjqZA1pH5mENOsa)
		VVvclNfCzqtrZk5QISL['type'] = Um2ITJ1iLnEjqZevskVt06NY34
		VVvclNfCzqtrZk5QISL['context'] = mUTXiaBzJf2utgY3KFIQl
		VVvclNfCzqtrZk5QISL['group'] = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.upper()
		VVvclNfCzqtrZk5QISL['title'] = G3V6fB4UjqZA1pH5mENOsa.upper()
		VVvclNfCzqtrZk5QISL['country'] = dR1OT0s4Mm9BKjJp6zkclVnfyP.upper()
		VVvclNfCzqtrZk5QISL['language'] = huLZj7o4gQd6v.upper()
		OKCAQ0sxp94dyuIatJW1B7G2woDh.append(VVvclNfCzqtrZk5QISL)
		xXiojqUmVlbuSnswBhQ += 1
	return OKCAQ0sxp94dyuIatJW1B7G2woDh,xXiojqUmVlbuSnswBhQ,i9j5HT3mP7sUleYhZcwdWz
def MqrEiwKemZ1phV5o2L(G3V6fB4UjqZA1pH5mENOsa):
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.replace('||','|').replace('___',':').replace('--','-')
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.replace('[[','[').replace(']]',']')
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.replace('((','(').replace('))',')')
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.replace('<<','<').replace('>>','>')
	G3V6fB4UjqZA1pH5mENOsa = G3V6fB4UjqZA1pH5mENOsa.strip(ww0sZkBU9JKd)
	return G3V6fB4UjqZA1pH5mENOsa
def rK5LdVy6lju0UvTOnMNJIcp8qQzmk(GdhS3NtrA87IU6pwRDjoMZ9c1b,D2vJY7Wkuxdr0t6oX1zIjMeFg,D0SV9UiuJv4tpezrsNx3dGWRwM1):
	WUR8sKuN25AC0lpHE = {}
	for HHRWxq2IQ3GCral7ZmP6gB4FtsOK in gXbKi2S5869pG3xc: WUR8sKuN25AC0lpHE[HHRWxq2IQ3GCral7ZmP6gB4FtsOK+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1] = []
	JPLChxqYSwU1syfdIVnOHT7Xrc0 = len(GdhS3NtrA87IU6pwRDjoMZ9c1b)
	ggWUzQNotVMLG4 = str(JPLChxqYSwU1syfdIVnOHT7Xrc0)
	xXiojqUmVlbuSnswBhQ = 0
	i9j5HT3mP7sUleYhZcwdWz = []
	for VVvclNfCzqtrZk5QISL in GdhS3NtrA87IU6pwRDjoMZ9c1b:
		if xXiojqUmVlbuSnswBhQ%873==0:
			CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,50+int(5*xXiojqUmVlbuSnswBhQ/JPLChxqYSwU1syfdIVnOHT7Xrc0),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(xXiojqUmVlbuSnswBhQ)+' / '+ggWUzQNotVMLG4)
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return None,None
		lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR = VVvclNfCzqtrZk5QISL['group'],VVvclNfCzqtrZk5QISL['context'],VVvclNfCzqtrZk5QISL['title'],VVvclNfCzqtrZk5QISL['url'],VVvclNfCzqtrZk5QISL['img']
		dR1OT0s4Mm9BKjJp6zkclVnfyP,huLZj7o4gQd6v,HHRWxq2IQ3GCral7ZmP6gB4FtsOK = VVvclNfCzqtrZk5QISL['country'],VVvclNfCzqtrZk5QISL['language'],VVvclNfCzqtrZk5QISL['type']
		TK5AbXzjoCY9QW = (lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR)
		cu8LMYSPo9pUysBTH1JtwDQ = False
		if 'LIVE' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK:
			if 'UNKNOWN' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_UNKNOWN_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			elif 'LIVE' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			else: cu8LMYSPo9pUysBTH1JtwDQ = True
			WUR8sKuN25AC0lpHE['LIVE_ORIGINAL_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
		elif 'VOD' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK:
			if 'UNKNOWN' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_UNKNOWN_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			elif 'MOVIES' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_MOVIES_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			elif 'SERIES' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_SERIES_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			else: cu8LMYSPo9pUysBTH1JtwDQ = True
			WUR8sKuN25AC0lpHE['VOD_ORIGINAL_GROUPED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
		else: cu8LMYSPo9pUysBTH1JtwDQ = True
		if cu8LMYSPo9pUysBTH1JtwDQ: i9j5HT3mP7sUleYhZcwdWz.append(VVvclNfCzqtrZk5QISL)
		xXiojqUmVlbuSnswBhQ += 1
	bbpXDw1UdTWlKIzL5 = sorted(GdhS3NtrA87IU6pwRDjoMZ9c1b,reverse=False,key=lambda u2ynb8RckJiqGpeV07hEF63: u2ynb8RckJiqGpeV07hEF63['title'].lower())
	del GdhS3NtrA87IU6pwRDjoMZ9c1b
	ggWUzQNotVMLG4 = str(JPLChxqYSwU1syfdIVnOHT7Xrc0)
	xXiojqUmVlbuSnswBhQ = 0
	for VVvclNfCzqtrZk5QISL in bbpXDw1UdTWlKIzL5:
		xXiojqUmVlbuSnswBhQ += 1
		if xXiojqUmVlbuSnswBhQ%873==0:
			CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,55+int(5*xXiojqUmVlbuSnswBhQ/JPLChxqYSwU1syfdIVnOHT7Xrc0),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(xXiojqUmVlbuSnswBhQ)+' / '+ggWUzQNotVMLG4)
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return None,None
		HHRWxq2IQ3GCral7ZmP6gB4FtsOK = VVvclNfCzqtrZk5QISL['type']
		lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR = VVvclNfCzqtrZk5QISL['group'],VVvclNfCzqtrZk5QISL['context'],VVvclNfCzqtrZk5QISL['title'],VVvclNfCzqtrZk5QISL['url'],VVvclNfCzqtrZk5QISL['img']
		dR1OT0s4Mm9BKjJp6zkclVnfyP,huLZj7o4gQd6v = VVvclNfCzqtrZk5QISL['country'],VVvclNfCzqtrZk5QISL['language']
		Ohx8fw2Akma5gl = (lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl+'_TIMESHIFT',G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR)
		TK5AbXzjoCY9QW = (lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR)
		viOC9rZucySMGxgJIz4tL3wkmq = (dR1OT0s4Mm9BKjJp6zkclVnfyP,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR)
		M0ibN4Zo5BcP7f3 = (huLZj7o4gQd6v,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR)
		if 'LIVE' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK:
			if 'UNKNOWN' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_UNKNOWN_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			else: WUR8sKuN25AC0lpHE['LIVE_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			if 'EPG'		in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_EPG_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			if 'ARCHIVED'	in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_ARCHIVED_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			if 'ARCHIVED'	in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['LIVE_TIMESHIFT_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(Ohx8fw2Akma5gl)
			WUR8sKuN25AC0lpHE['LIVE_FROM_NAME_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(viOC9rZucySMGxgJIz4tL3wkmq)
			WUR8sKuN25AC0lpHE['LIVE_FROM_GROUP_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(M0ibN4Zo5BcP7f3)
		elif 'VOD' in HHRWxq2IQ3GCral7ZmP6gB4FtsOK:
			if   'UNKNOWN'	in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_UNKNOWN_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			elif 'MOVIES'	in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_MOVIES_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			elif 'SERIES'	in HHRWxq2IQ3GCral7ZmP6gB4FtsOK: WUR8sKuN25AC0lpHE['VOD_SERIES_GROUPED_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(TK5AbXzjoCY9QW)
			WUR8sKuN25AC0lpHE['VOD_FROM_NAME_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(viOC9rZucySMGxgJIz4tL3wkmq)
			WUR8sKuN25AC0lpHE['VOD_FROM_GROUP_SORTED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1].append(M0ibN4Zo5BcP7f3)
	return WUR8sKuN25AC0lpHE,i9j5HT3mP7sUleYhZcwdWz
def xmbACRhBj3PK7a6OQ1odYc(G3V6fB4UjqZA1pH5mENOsa):
	if len(G3V6fB4UjqZA1pH5mENOsa)<3: return G3V6fB4UjqZA1pH5mENOsa,G3V6fB4UjqZA1pH5mENOsa
	GQJ4MZ6bx58AHV,SQPFEhwYIfuMb2pk5nG9ezKHxL8 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	P4J0GpcwgEKNaF = G3V6fB4UjqZA1pH5mENOsa
	BQYWXE3sqTwJtd7i5vMOmb01 = G3V6fB4UjqZA1pH5mENOsa[:1]
	Y9YvhzcMdfmTKuWG0aCpnl7 = G3V6fB4UjqZA1pH5mENOsa[1:]
	if   BQYWXE3sqTwJtd7i5vMOmb01=='(': SQPFEhwYIfuMb2pk5nG9ezKHxL8 = ')'
	elif BQYWXE3sqTwJtd7i5vMOmb01=='[': SQPFEhwYIfuMb2pk5nG9ezKHxL8 = ']'
	elif BQYWXE3sqTwJtd7i5vMOmb01=='<': SQPFEhwYIfuMb2pk5nG9ezKHxL8 = '>'
	elif BQYWXE3sqTwJtd7i5vMOmb01=='|': SQPFEhwYIfuMb2pk5nG9ezKHxL8 = '|'
	if SQPFEhwYIfuMb2pk5nG9ezKHxL8 and (SQPFEhwYIfuMb2pk5nG9ezKHxL8 in Y9YvhzcMdfmTKuWG0aCpnl7):
		DoQ5f7P1ydRlvAw0kbJFqIB8YUpT,xhmn0JKfHSUQizNjk7dv = Y9YvhzcMdfmTKuWG0aCpnl7.split(SQPFEhwYIfuMb2pk5nG9ezKHxL8,1)
		GQJ4MZ6bx58AHV = DoQ5f7P1ydRlvAw0kbJFqIB8YUpT
		P4J0GpcwgEKNaF = BQYWXE3sqTwJtd7i5vMOmb01+DoQ5f7P1ydRlvAw0kbJFqIB8YUpT+SQPFEhwYIfuMb2pk5nG9ezKHxL8+ww0sZkBU9JKd+xhmn0JKfHSUQizNjk7dv
	elif G3V6fB4UjqZA1pH5mENOsa.count('|')>=2:
		DoQ5f7P1ydRlvAw0kbJFqIB8YUpT,xhmn0JKfHSUQizNjk7dv = G3V6fB4UjqZA1pH5mENOsa.split('|',1)
		GQJ4MZ6bx58AHV = DoQ5f7P1ydRlvAw0kbJFqIB8YUpT
		P4J0GpcwgEKNaF = DoQ5f7P1ydRlvAw0kbJFqIB8YUpT+' |'+xhmn0JKfHSUQizNjk7dv
	else:
		SQPFEhwYIfuMb2pk5nG9ezKHxL8 = oo9kuULlebNgpY0Om.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',G3V6fB4UjqZA1pH5mENOsa,oo9kuULlebNgpY0Om.DOTALL)
		if not SQPFEhwYIfuMb2pk5nG9ezKHxL8: SQPFEhwYIfuMb2pk5nG9ezKHxL8 = oo9kuULlebNgpY0Om.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',G3V6fB4UjqZA1pH5mENOsa,oo9kuULlebNgpY0Om.DOTALL)
		if not SQPFEhwYIfuMb2pk5nG9ezKHxL8: SQPFEhwYIfuMb2pk5nG9ezKHxL8 = oo9kuULlebNgpY0Om.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',G3V6fB4UjqZA1pH5mENOsa,oo9kuULlebNgpY0Om.DOTALL)
		if SQPFEhwYIfuMb2pk5nG9ezKHxL8:
			DoQ5f7P1ydRlvAw0kbJFqIB8YUpT,xhmn0JKfHSUQizNjk7dv = G3V6fB4UjqZA1pH5mENOsa.split(SQPFEhwYIfuMb2pk5nG9ezKHxL8[0],1)
			GQJ4MZ6bx58AHV = DoQ5f7P1ydRlvAw0kbJFqIB8YUpT
			P4J0GpcwgEKNaF = DoQ5f7P1ydRlvAw0kbJFqIB8YUpT+ww0sZkBU9JKd+SQPFEhwYIfuMb2pk5nG9ezKHxL8[0]+ww0sZkBU9JKd+xhmn0JKfHSUQizNjk7dv
	P4J0GpcwgEKNaF = P4J0GpcwgEKNaF.replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	GQJ4MZ6bx58AHV = GQJ4MZ6bx58AHV.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	if not GQJ4MZ6bx58AHV: GQJ4MZ6bx58AHV = '!!__UNKNOWN__!!'
	GQJ4MZ6bx58AHV = GQJ4MZ6bx58AHV.strip(ww0sZkBU9JKd)
	P4J0GpcwgEKNaF = P4J0GpcwgEKNaF.strip(ww0sZkBU9JKd)
	return GQJ4MZ6bx58AHV,P4J0GpcwgEKNaF
def VVIpNavEdMx2jnDs93lQ(JwTceYNvUD):
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {}
	fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.useragent_'+JwTceYNvUD)
	if fwYj6oCrh9Z3q7xd0NnlMO2K8J4P: cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI['User-Agent'] = fwYj6oCrh9Z3q7xd0NnlMO2K8J4P
	OOnwpmsUEt5jLB9H3TlRPGc0M = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.referer_'+JwTceYNvUD)
	if OOnwpmsUEt5jLB9H3TlRPGc0M: cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI['Referer'] = OOnwpmsUEt5jLB9H3TlRPGc0M
	return cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI
def ZgJSxUdtnhwc0jiGWH1O8DACrR(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1):
	global D2vJY7Wkuxdr0t6oX1zIjMeFg,WUR8sKuN25AC0lpHE,M4Cucb89IfWv0XiDRr7,tMLjSXUo1HCT2Yg8E,VmAI5vPZWjKTafz6,lnLEoFyazbjp9eSKcQV0C6,AB3iQ4rxak,pCGSPcun5YfBxLD2rzv,dywzce865Q
	kkWUKB6ImOxXwsbfrG9Hdc = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.url_'+JwTceYNvUD+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
	fwYj6oCrh9Z3q7xd0NnlMO2K8J4P = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.useragent_'+JwTceYNvUD)
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {'User-Agent':fwYj6oCrh9Z3q7xd0NnlMO2K8J4P}
	F5f1jkbEJOcT7vtQHYBSZxdn3WD6 = Qe2LqnH1RN3mU.replace('___','_'+JwTceYNvUD+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
	if 1:
		ISlwNu6cCWfTAQs,WQ8bBsl5j3XzM1vZnT,mBnYcg28z3tKM = True,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		if not ISlwNu6cCWfTAQs:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not kkWUKB6ImOxXwsbfrG9Hdc: vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+'   No M3U URL found to download M3U files')
			else: vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(v1NALptEHU)+'   Failed to download M3U files')
			return
		AUjsprIJNExKOl = A7AmGFnBgYU63Dyl2hv4cP(kkWUKB6ImOxXwsbfrG9Hdc,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,True)
		if not AUjsprIJNExKOl: return
		open(F5f1jkbEJOcT7vtQHYBSZxdn3WD6,'wb').write(AUjsprIJNExKOl)
	else: AUjsprIJNExKOl = open(F5f1jkbEJOcT7vtQHYBSZxdn3WD6,'rb').read()
	if LTze51miOknVcslNF43WSA6vMjYZt and AUjsprIJNExKOl: AUjsprIJNExKOl = AUjsprIJNExKOl.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	D2vJY7Wkuxdr0t6oX1zIjMeFg = dWO9bFPCYXVDrcU81xN5kJ23laR()
	D2vJY7Wkuxdr0t6oX1zIjMeFg.create('جلب ملفات M3U جديدة',G9G0YqivIfmUWO8K)
	CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,15,'تنظيف الملف الرئيسي',G9G0YqivIfmUWO8K)
	AUjsprIJNExKOl = AUjsprIJNExKOl.replace('"tvg-','" tvg-')
	AUjsprIJNExKOl = AUjsprIJNExKOl.replace('َ',G9G0YqivIfmUWO8K).replace('ً',G9G0YqivIfmUWO8K).replace('ُ',G9G0YqivIfmUWO8K).replace('ٌ',G9G0YqivIfmUWO8K)
	AUjsprIJNExKOl = AUjsprIJNExKOl.replace('ّ',G9G0YqivIfmUWO8K).replace('ِ',G9G0YqivIfmUWO8K).replace('ٍ',G9G0YqivIfmUWO8K).replace('ْ',G9G0YqivIfmUWO8K)
	AUjsprIJNExKOl = AUjsprIJNExKOl.replace('group-title=','group=').replace('tvg-',G9G0YqivIfmUWO8K)
	eOpIEhaBd5MRj6f0sNA,b4htYQl9qDyfX5oHsIC = [],[]
	AUjsprIJNExKOl = AUjsprIJNExKOl.replace(fXE2iwNYcD,zEgtT9cR6bFp7JXqI5VuhNeP)
	RJBGyivQKTech8DM9xN = oo9kuULlebNgpY0Om.findall('NF:(.+?)'+'#'+'EXTI',AUjsprIJNExKOl+'\n+'+'#'+'EXTINF:',oo9kuULlebNgpY0Om.DOTALL)
	if not RJBGyivQKTech8DM9xN:
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(v1NALptEHU)+'   Folder:'+JwTceYNvUD+'  Sequence:'+D0SV9UiuJv4tpezrsNx3dGWRwM1+'   No video links found in M3U file')
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+'مجلد رقم '+JwTceYNvUD+'      رابط رقم '+D0SV9UiuJv4tpezrsNx3dGWRwM1+zzGfwLAyN5HTxUoJeaivY)
		D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
		return
	IIKxvWLBfNunEejpmGqySM968alF05 = []
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		mtYu8IHJZ7pUz6320yxoLncOP = B71KDuTRjsXOcoh4JWbPdMSi28A.lower()
		if 'adult' in mtYu8IHJZ7pUz6320yxoLncOP: continue
		if 'xxx' in mtYu8IHJZ7pUz6320yxoLncOP: continue
		IIKxvWLBfNunEejpmGqySM968alF05.append(B71KDuTRjsXOcoh4JWbPdMSi28A)
	RJBGyivQKTech8DM9xN = IIKxvWLBfNunEejpmGqySM968alF05
	del IIKxvWLBfNunEejpmGqySM968alF05
	if 'iptv-org' in kkWUKB6ImOxXwsbfrG9Hdc:
		IIKxvWLBfNunEejpmGqySM968alF05,KrdkCY3vAweTSsjVUmOq7bhMcg = [],[]
		for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
			lnLEoFyazbjp9eSKcQV0C6 = oo9kuULlebNgpY0Om.findall('group="(.*?)"',B71KDuTRjsXOcoh4JWbPdMSi28A,oo9kuULlebNgpY0Om.DOTALL)
			if lnLEoFyazbjp9eSKcQV0C6:
				lnLEoFyazbjp9eSKcQV0C6 = lnLEoFyazbjp9eSKcQV0C6[0]
				EQ6TIFHC3fzPJph5dRr0u = lnLEoFyazbjp9eSKcQV0C6.split(';')
				if 'region' in kkWUKB6ImOxXwsbfrG9Hdc: Ha5UfbKvYrNh0l = '1_'
				elif 'category' in kkWUKB6ImOxXwsbfrG9Hdc: Ha5UfbKvYrNh0l = '2_'
				elif 'language' in kkWUKB6ImOxXwsbfrG9Hdc: Ha5UfbKvYrNh0l = '3_'
				elif 'country' in kkWUKB6ImOxXwsbfrG9Hdc: Ha5UfbKvYrNh0l = '4_'
				else: Ha5UfbKvYrNh0l = '5_'
				F1HelhjUMDZ = B71KDuTRjsXOcoh4JWbPdMSi28A.replace('group="'+lnLEoFyazbjp9eSKcQV0C6+'"','group="'+Ha5UfbKvYrNh0l+'~'+A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY+'"')
				IIKxvWLBfNunEejpmGqySM968alF05.append(F1HelhjUMDZ)
				for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in EQ6TIFHC3fzPJph5dRr0u:
					F1HelhjUMDZ = B71KDuTRjsXOcoh4JWbPdMSi28A.replace('group="'+lnLEoFyazbjp9eSKcQV0C6+'"','group="'+Ha5UfbKvYrNh0l+lQRCX7wUkWf1Opjaxbno2ZDh5GAi6+'"')
					IIKxvWLBfNunEejpmGqySM968alF05.append(F1HelhjUMDZ)
			else: IIKxvWLBfNunEejpmGqySM968alF05.append(B71KDuTRjsXOcoh4JWbPdMSi28A)
		RJBGyivQKTech8DM9xN = IIKxvWLBfNunEejpmGqySM968alF05
		del IIKxvWLBfNunEejpmGqySM968alF05,KrdkCY3vAweTSsjVUmOq7bhMcg
	ecv9SLu2QhoaJtgzblOX6y0F = 1024*1024
	QQIPtdV13sNDiqz26GT4K9HUycZw = 1+len(AUjsprIJNExKOl)//ecv9SLu2QhoaJtgzblOX6y0F//10
	del AUjsprIJNExKOl
	oqrU9aA7kZ0thyx5bSBQ = len(RJBGyivQKTech8DM9xN)
	KrdkCY3vAweTSsjVUmOq7bhMcg = ZxFewT6jWI1puarhCYmdbSGP(RJBGyivQKTech8DM9xN,QQIPtdV13sNDiqz26GT4K9HUycZw)
	del RJBGyivQKTech8DM9xN
	for KJZlbgk2TdD5GWQFqucMP in range(QQIPtdV13sNDiqz26GT4K9HUycZw):
		CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,35+int(5*KJZlbgk2TdD5GWQFqucMP/QQIPtdV13sNDiqz26GT4K9HUycZw),'تقطيع الملف الرئيسي','الجزء رقم:-',str(KJZlbgk2TdD5GWQFqucMP+1)+' / '+str(QQIPtdV13sNDiqz26GT4K9HUycZw))
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
		CCAVpH49gEjcWy5z = str(KrdkCY3vAweTSsjVUmOq7bhMcg[KJZlbgk2TdD5GWQFqucMP])
		if LTze51miOknVcslNF43WSA6vMjYZt: CCAVpH49gEjcWy5z = CCAVpH49gEjcWy5z.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open(F5f1jkbEJOcT7vtQHYBSZxdn3WD6+'.00'+str(KJZlbgk2TdD5GWQFqucMP),'wb').write(CCAVpH49gEjcWy5z)
	del KrdkCY3vAweTSsjVUmOq7bhMcg,CCAVpH49gEjcWy5z
	DOBgUu14G7V5QnZt0aCyifdSxls,GdhS3NtrA87IU6pwRDjoMZ9c1b,xXiojqUmVlbuSnswBhQ = [],[],0
	for KJZlbgk2TdD5GWQFqucMP in range(QQIPtdV13sNDiqz26GT4K9HUycZw):
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
		CCAVpH49gEjcWy5z = open(F5f1jkbEJOcT7vtQHYBSZxdn3WD6+'.00'+str(KJZlbgk2TdD5GWQFqucMP),'rb').read()
		SSCU3jdyFn2V.sleep(1)
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(F5f1jkbEJOcT7vtQHYBSZxdn3WD6+'.00'+str(KJZlbgk2TdD5GWQFqucMP))
		except: pass
		if LTze51miOknVcslNF43WSA6vMjYZt: CCAVpH49gEjcWy5z = CCAVpH49gEjcWy5z.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		z0zQocOKYgNJbnvldxkBPET2w = bRCSwcA89e4J7pqdays5PxGiD2('list',CCAVpH49gEjcWy5z)
		del CCAVpH49gEjcWy5z
		OKCAQ0sxp94dyuIatJW1B7G2woDh,xXiojqUmVlbuSnswBhQ,i9j5HT3mP7sUleYhZcwdWz = XsMebRQd057npq(z0zQocOKYgNJbnvldxkBPET2w,b4htYQl9qDyfX5oHsIC,eOpIEhaBd5MRj6f0sNA,D2vJY7Wkuxdr0t6oX1zIjMeFg,oqrU9aA7kZ0thyx5bSBQ,xXiojqUmVlbuSnswBhQ,kkWUKB6ImOxXwsbfrG9Hdc)
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
		if not OKCAQ0sxp94dyuIatJW1B7G2woDh:
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
		GdhS3NtrA87IU6pwRDjoMZ9c1b += OKCAQ0sxp94dyuIatJW1B7G2woDh
		DOBgUu14G7V5QnZt0aCyifdSxls += i9j5HT3mP7sUleYhZcwdWz
	del z0zQocOKYgNJbnvldxkBPET2w,OKCAQ0sxp94dyuIatJW1B7G2woDh
	WUR8sKuN25AC0lpHE,i9j5HT3mP7sUleYhZcwdWz = rK5LdVy6lju0UvTOnMNJIcp8qQzmk(GdhS3NtrA87IU6pwRDjoMZ9c1b,D2vJY7Wkuxdr0t6oX1zIjMeFg,D0SV9UiuJv4tpezrsNx3dGWRwM1)
	if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
		D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
		return
	DOBgUu14G7V5QnZt0aCyifdSxls += i9j5HT3mP7sUleYhZcwdWz
	del GdhS3NtrA87IU6pwRDjoMZ9c1b,i9j5HT3mP7sUleYhZcwdWz
	tMLjSXUo1HCT2Yg8E,VmAI5vPZWjKTafz6,lnLEoFyazbjp9eSKcQV0C6,AB3iQ4rxak,pCGSPcun5YfBxLD2rzv = {},{},{},0,0
	HHSbQCo1UtfJIXMO5VlezZ = list(WUR8sKuN25AC0lpHE.keys())
	dywzce865Q = len(HHSbQCo1UtfJIXMO5VlezZ)*3
	if 1:
		YLD0KHcpCqay3neWkXzU71EioR6B = {}
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ] = fu19TY0PdM6AZB5.Thread(target=UUmofzPrSYH6FEwZbJ,args=(KEqwWYSFhVzpyBs2D4XZ,))
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ].start()
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ].join()
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
	else:
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			UUmofzPrSYH6FEwZbJ(KEqwWYSFhVzpyBs2D4XZ)
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return
	EdLm3xM7ShJwtjvQPRnqBF4HDU1NWg(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1,False)
	HHSbQCo1UtfJIXMO5VlezZ = list(tMLjSXUo1HCT2Yg8E.keys())
	M4Cucb89IfWv0XiDRr7 = 0
	if 1:
		YLD0KHcpCqay3neWkXzU71EioR6B = {}
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ] = fu19TY0PdM6AZB5.Thread(target=HdmOpguitvL0G5kI,args=(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ))
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ].start()
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			YLD0KHcpCqay3neWkXzU71EioR6B[KEqwWYSFhVzpyBs2D4XZ].join()
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
			D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
			return
	else:
		for KEqwWYSFhVzpyBs2D4XZ in HHSbQCo1UtfJIXMO5VlezZ:
			HdmOpguitvL0G5kI(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ)
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return
	KJZlbgk2TdD5GWQFqucMP = 0
	xrE2BipIOyLj5euUPAR = len(DOBgUu14G7V5QnZt0aCyifdSxls)
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,'IGNORED')
	for PDqmaw4p5fyX7CI2j in DOBgUu14G7V5QnZt0aCyifdSxls:
		if KJZlbgk2TdD5GWQFqucMP%27==0:
			CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,95+int(5*KJZlbgk2TdD5GWQFqucMP//xrE2BipIOyLj5euUPAR),'تخزين المهملة','الفيديو رقم:-',str(KJZlbgk2TdD5GWQFqucMP)+' / '+str(xrE2BipIOyLj5euUPAR))
			if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled():
				D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
				return
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,'IGNORED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1,str(PDqmaw4p5fyX7CI2j),G9G0YqivIfmUWO8K,UKDwMTZk9dni1JSLcf0oRXhqy)
		KJZlbgk2TdD5GWQFqucMP += 1
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,'IGNORED_'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__',str(xrE2BipIOyLj5euUPAR),UKDwMTZk9dni1JSLcf0oRXhqy)
	D2vJY7Wkuxdr0t6oX1zIjMeFg.close()
	SSCU3jdyFn2V.sleep(1)
	WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD)
	return
def UUmofzPrSYH6FEwZbJ(KEqwWYSFhVzpyBs2D4XZ):
	global D2vJY7Wkuxdr0t6oX1zIjMeFg,WUR8sKuN25AC0lpHE,M4Cucb89IfWv0XiDRr7,tMLjSXUo1HCT2Yg8E,VmAI5vPZWjKTafz6,lnLEoFyazbjp9eSKcQV0C6,AB3iQ4rxak,pCGSPcun5YfBxLD2rzv,dywzce865Q
	tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ] = {}
	e7EF16APVwXqvhNGKo5yIrcO,z0Ni65MUCpcVLD = {},[]
	sM1Oy0HcU3o4JC2EGAw = len(WUR8sKuN25AC0lpHE[KEqwWYSFhVzpyBs2D4XZ])
	tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ]['__COUNT__'] = sM1Oy0HcU3o4JC2EGAw
	if sM1Oy0HcU3o4JC2EGAw>0:
		PnaTX5Wfrj8,uuwqJ2BLXCPWlS5o9mKanQ,Q3MGSu9cdLJnC84twFDgNoE15,CvMo6EtmifJUpx7FKRjVg,Y9ztpcFvOVBR = zip(*WUR8sKuN25AC0lpHE[KEqwWYSFhVzpyBs2D4XZ])
		del uuwqJ2BLXCPWlS5o9mKanQ,Q3MGSu9cdLJnC84twFDgNoE15,CvMo6EtmifJUpx7FKRjVg
		EQ6TIFHC3fzPJph5dRr0u = list(set(PnaTX5Wfrj8))
		for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in EQ6TIFHC3fzPJph5dRr0u:
			e7EF16APVwXqvhNGKo5yIrcO[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] = G9G0YqivIfmUWO8K
			tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ][lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] = []
		CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,60+int(15*pCGSPcun5YfBxLD2rzv//dywzce865Q),'تصنيع القوائم','الجزء رقم:-',str(pCGSPcun5YfBxLD2rzv)+' / '+str(dywzce865Q))
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled(): return
		pCGSPcun5YfBxLD2rzv += 1
		VaNeiUZ4bHc = len(EQ6TIFHC3fzPJph5dRr0u)
		del EQ6TIFHC3fzPJph5dRr0u
		z0Ni65MUCpcVLD = list(set(zip(PnaTX5Wfrj8,Y9ztpcFvOVBR)))
		del PnaTX5Wfrj8,Y9ztpcFvOVBR
		for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,eEDLWJkqd4hg in z0Ni65MUCpcVLD:
			if not e7EF16APVwXqvhNGKo5yIrcO[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] and eEDLWJkqd4hg: e7EF16APVwXqvhNGKo5yIrcO[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] = eEDLWJkqd4hg
		CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,60+int(15*pCGSPcun5YfBxLD2rzv//dywzce865Q),'تصنيع القوائم','الجزء رقم:-',str(pCGSPcun5YfBxLD2rzv)+' / '+str(dywzce865Q))
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled(): return
		pCGSPcun5YfBxLD2rzv += 1
		D8D7UKJsxr1NVmvSl4Ca = list(e7EF16APVwXqvhNGKo5yIrcO.keys())
		QHGYLwhcV9bn2Nq = list(e7EF16APVwXqvhNGKo5yIrcO.values())
		del e7EF16APVwXqvhNGKo5yIrcO
		z0Ni65MUCpcVLD = list(zip(D8D7UKJsxr1NVmvSl4Ca,QHGYLwhcV9bn2Nq))
		del D8D7UKJsxr1NVmvSl4Ca,QHGYLwhcV9bn2Nq
		z0Ni65MUCpcVLD = sorted(z0Ni65MUCpcVLD)
	else: pCGSPcun5YfBxLD2rzv += 2
	tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ]['__GROUPS__'] = z0Ni65MUCpcVLD
	del z0Ni65MUCpcVLD
	for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in WUR8sKuN25AC0lpHE[KEqwWYSFhVzpyBs2D4XZ]:
		tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ][lQRCX7wUkWf1Opjaxbno2ZDh5GAi6].append((mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR))
	CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,60+int(15*pCGSPcun5YfBxLD2rzv//dywzce865Q),'تصنيع القوائم','الجزء رقم:-',str(pCGSPcun5YfBxLD2rzv)+' / '+str(dywzce865Q))
	if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled(): return
	pCGSPcun5YfBxLD2rzv += 1
	del WUR8sKuN25AC0lpHE[KEqwWYSFhVzpyBs2D4XZ]
	lnLEoFyazbjp9eSKcQV0C6[KEqwWYSFhVzpyBs2D4XZ] = list(tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ].keys())
	VmAI5vPZWjKTafz6[KEqwWYSFhVzpyBs2D4XZ] = len(lnLEoFyazbjp9eSKcQV0C6[KEqwWYSFhVzpyBs2D4XZ])
	AB3iQ4rxak += VmAI5vPZWjKTafz6[KEqwWYSFhVzpyBs2D4XZ]
	return
def HdmOpguitvL0G5kI(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ):
	global D2vJY7Wkuxdr0t6oX1zIjMeFg,WUR8sKuN25AC0lpHE,M4Cucb89IfWv0XiDRr7,tMLjSXUo1HCT2Yg8E,VmAI5vPZWjKTafz6,lnLEoFyazbjp9eSKcQV0C6,AB3iQ4rxak,pCGSPcun5YfBxLD2rzv,dywzce865Q
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ)
	for xXiojqUmVlbuSnswBhQ in range(1+VmAI5vPZWjKTafz6[KEqwWYSFhVzpyBs2D4XZ]//273):
		Qzx814CLhOc3XIbTVM5rD2dlgjiwuB = []
		KKRLBevinMtXpFxl = lnLEoFyazbjp9eSKcQV0C6[KEqwWYSFhVzpyBs2D4XZ][0:273]
		for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in KKRLBevinMtXpFxl:
			Qzx814CLhOc3XIbTVM5rD2dlgjiwuB.append(tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ][lQRCX7wUkWf1Opjaxbno2ZDh5GAi6])
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,KEqwWYSFhVzpyBs2D4XZ,KKRLBevinMtXpFxl,Qzx814CLhOc3XIbTVM5rD2dlgjiwuB,UKDwMTZk9dni1JSLcf0oRXhqy,True)
		M4Cucb89IfWv0XiDRr7 += len(KKRLBevinMtXpFxl)
		CigEOdTqom6Gw5nta(D2vJY7Wkuxdr0t6oX1zIjMeFg,75+int(20*M4Cucb89IfWv0XiDRr7//AB3iQ4rxak),'تخزين القوائم','القائمة رقم:-',str(M4Cucb89IfWv0XiDRr7)+' / '+str(AB3iQ4rxak))
		if D2vJY7Wkuxdr0t6oX1zIjMeFg.iscanceled(): return
		del lnLEoFyazbjp9eSKcQV0C6[KEqwWYSFhVzpyBs2D4XZ][0:273]
	del tMLjSXUo1HCT2Yg8E[KEqwWYSFhVzpyBs2D4XZ],lnLEoFyazbjp9eSKcQV0C6[KEqwWYSFhVzpyBs2D4XZ],VmAI5vPZWjKTafz6[KEqwWYSFhVzpyBs2D4XZ]
	return
def VQ3Sc8lLbIAnrEyXJsN0mOfvhaCug(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1,TThZapolz65vswcfC18AKSdX2HMV=True):
	S3chIQa4byNJLZnvp21 = 'عدد فيديوهات جميع الروابط'
	A0v79kFtGlr8cqumVRQHEaiC4zXTD = qa4IeON9SmPWn0R128(JwTceYNvUD,'LIVE_ORIGINAL_GROUPED')
	Qbw3ld8Hz7ZPscNmnJSLxYtuF2j = qa4IeON9SmPWn0R128(JwTceYNvUD,'VOD_ORIGINAL_GROUPED')
	if D0SV9UiuJv4tpezrsNx3dGWRwM1:
		S3chIQa4byNJLZnvp21 = 'عدد فيديوهات رابط '+F7hmrbfYztVycGjDE4Sd[int(D0SV9UiuJv4tpezrsNx3dGWRwM1)]
		D0SV9UiuJv4tpezrsNx3dGWRwM1 = '_'+D0SV9UiuJv4tpezrsNx3dGWRwM1
	xrE2BipIOyLj5euUPAR = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','IGNORED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	lFU9VnOLBDImHNePiw4jg = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','LIVE_ORIGINAL_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	KPGHXyDVwbaZf0rWSg = PiXRCL1dtv6pWfU(Qbw3ld8Hz7ZPscNmnJSLxYtuF2j,'int','VOD_ORIGINAL_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	O3NdQLozY1m2Ba8M9nw = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','LIVE_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	OxG14q90Uiaz3Njkhy8fABZpl = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','LIVE_UNKNOWN_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	i7NvrnD4yZY2TX1 = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','VOD_MOVIES_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	EdPXKgrLRbiqvpQD8mJ = PiXRCL1dtv6pWfU(Qbw3ld8Hz7ZPscNmnJSLxYtuF2j,'int','VOD_SERIES_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	aEu4OVyZsS0QYi1PfWR = PiXRCL1dtv6pWfU(A0v79kFtGlr8cqumVRQHEaiC4zXTD,'int','VOD_UNKNOWN_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__COUNT__')
	lnLEoFyazbjp9eSKcQV0C6 = PiXRCL1dtv6pWfU(Qbw3ld8Hz7ZPscNmnJSLxYtuF2j,'list','VOD_SERIES_GROUPED'+D0SV9UiuJv4tpezrsNx3dGWRwM1,'__GROUPS__')
	ZPFndxiIjW = []
	for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in lnLEoFyazbjp9eSKcQV0C6:
		pUTtkDgXJq = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.split('__SERIES__')[1]
		ZPFndxiIjW.append(pUTtkDgXJq)
	oghywQHXIVfs7Z = len(ZPFndxiIjW)
	fRo3XgN2pxte4MK = int(i7NvrnD4yZY2TX1)+int(EdPXKgrLRbiqvpQD8mJ)+int(aEu4OVyZsS0QYi1PfWR)+int(OxG14q90Uiaz3Njkhy8fABZpl)+int(O3NdQLozY1m2Ba8M9nw)
	S0f2EpJzD1aYv5UnkmWdTROi = G9G0YqivIfmUWO8K
	S0f2EpJzD1aYv5UnkmWdTROi += 'قنوات: '+str(O3NdQLozY1m2Ba8M9nw)
	S0f2EpJzD1aYv5UnkmWdTROi += '   .   أفلام: '+str(i7NvrnD4yZY2TX1)
	S0f2EpJzD1aYv5UnkmWdTROi += '\nمسلسلات: '+str(oghywQHXIVfs7Z)
	S0f2EpJzD1aYv5UnkmWdTROi += '   .   حلقات: '+str(EdPXKgrLRbiqvpQD8mJ)
	S0f2EpJzD1aYv5UnkmWdTROi += '\nقنوات مجهولة: '+str(OxG14q90Uiaz3Njkhy8fABZpl)
	S0f2EpJzD1aYv5UnkmWdTROi += '   .   فيدوهات مجهولة: '+str(aEu4OVyZsS0QYi1PfWR)
	S0f2EpJzD1aYv5UnkmWdTROi += '\nمجموع القنوات: '+str(lFU9VnOLBDImHNePiw4jg)
	S0f2EpJzD1aYv5UnkmWdTROi += '   .   مجموع الفيديوهات: '+str(KPGHXyDVwbaZf0rWSg)
	S0f2EpJzD1aYv5UnkmWdTROi += '\n\nمجموع المضافة: '+str(fRo3XgN2pxte4MK)
	S0f2EpJzD1aYv5UnkmWdTROi += '   .   مجموع المهملة: '+str(xrE2BipIOyLj5euUPAR)
	if TThZapolz65vswcfC18AKSdX2HMV: hbKFzulmsw4k('center',G9G0YqivIfmUWO8K,S3chIQa4byNJLZnvp21,S0f2EpJzD1aYv5UnkmWdTROi)
	yMUCAQiuZ7RYb = S0f2EpJzD1aYv5UnkmWdTROi.replace('\n\n',zEgtT9cR6bFp7JXqI5VuhNeP)
	if not D0SV9UiuJv4tpezrsNx3dGWRwM1: D0SV9UiuJv4tpezrsNx3dGWRwM1 = 'All'
	else: D0SV9UiuJv4tpezrsNx3dGWRwM1 = D0SV9UiuJv4tpezrsNx3dGWRwM1[1]
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,'.\tCounts of M3U videos   Folder: '+JwTceYNvUD+'   Sequence: '+D0SV9UiuJv4tpezrsNx3dGWRwM1+zEgtT9cR6bFp7JXqI5VuhNeP+yMUCAQiuZ7RYb)
	return S0f2EpJzD1aYv5UnkmWdTROi
def EdLm3xM7ShJwtjvQPRnqBF4HDU1NWg(JwTceYNvUD,D0SV9UiuJv4tpezrsNx3dGWRwM1,TThZapolz65vswcfC18AKSdX2HMV=True):
	if TThZapolz65vswcfC18AKSdX2HMV:
		KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if KKrj6Fkd5Tgv9ImSAGyaEeLcipt!=1: return
		Z2mSnLO1p5JUdWBr83 = Qe2LqnH1RN3mU.replace('___','_'+JwTceYNvUD+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(Z2mSnLO1p5JUdWBr83)
		except: pass
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,G9G0YqivIfmUWO8K)
	if D0SV9UiuJv4tpezrsNx3dGWRwM1:
		ppAbF3RjLNc5MsdSCuH = []
		for kKLYDqoeza0m7F4i8Pr9fbEIT in gXbKi2S5869pG3xc:
			ppAbF3RjLNc5MsdSCuH.append(kKLYDqoeza0m7F4i8Pr9fbEIT+'_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,'LINK_'+D0SV9UiuJv4tpezrsNx3dGWRwM1)
	else:
		ppAbF3RjLNc5MsdSCuH = gXbKi2S5869pG3xc
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,'DUMMY')
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,'GROUPS')
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,'ITEMS')
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,'SEARCH')
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'SECTIONS_M3U','SECTIONS_M3U_'+JwTceYNvUD)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for KEqwWYSFhVzpyBs2D4XZ in ppAbF3RjLNc5MsdSCuH:
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,KEqwWYSFhVzpyBs2D4XZ)
	CU83wctmZIMAaxHv(False)
	WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD)
	if TThZapolz65vswcfC18AKSdX2HMV: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD=G9G0YqivIfmUWO8K,TThZapolz65vswcfC18AKSdX2HMV=True):
	if JwTceYNvUD:
		oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(str(JwTceYNvUD),'DUMMY')
		v2v3YoplfDdKJEhW5i = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'str','DUMMY','__DUMMY__')
		if v2v3YoplfDdKJEhW5i: return True
	else:
		JwTceYNvUD = '1'
		for ygLtm7VzT1WZN5Fdfo in range(1,XmGcjWDVrAuKeMFlbSvdhYi1+1):
			oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(str(ygLtm7VzT1WZN5Fdfo),'DUMMY')
			v2v3YoplfDdKJEhW5i = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'str','DUMMY','__DUMMY__')
			if v2v3YoplfDdKJEhW5i: return True
	if TThZapolz65vswcfC18AKSdX2HMV:
		sa1y5jINFiV6P3vOB4D0C = 'https://iptv-org.github.io/iptv/index.region.m3u'
		tDcAXVbokl03rqLU = 'https://iptv-org.github.io/iptv/index.category.m3u'
		Xe0sAHmQZP1TWlVk = 'https://iptv-org.github.io/iptv/index.language.m3u'
		oubNx3p8FIP4q91BeA0 = 'https://iptv-org.github.io/iptv/index.country.m3u'
		tWISr9nR3wmGJPjgTXNL8o = sa1y5jINFiV6P3vOB4D0C+zEgtT9cR6bFp7JXqI5VuhNeP+tDcAXVbokl03rqLU+zEgtT9cR6bFp7JXqI5VuhNeP+Xe0sAHmQZP1TWlVk+zEgtT9cR6bFp7JXqI5VuhNeP+oubNx3p8FIP4q91BeA0
		KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+A7XhkmSYZlidyMt5FpWqTgjNezbnD+'http://github.com/iptv-org/iptv'+zzGfwLAyN5HTxUoJeaivY+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+A7XhkmSYZlidyMt5FpWqTgjNezbnD+tWISr9nR3wmGJPjgTXNL8o+zzGfwLAyN5HTxUoJeaivY,profile='confirm_smallfont')
		if KKrj6Fkd5Tgv9ImSAGyaEeLcipt==1:
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.url_'+str(JwTceYNvUD)+'_1',sa1y5jINFiV6P3vOB4D0C)
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.url_'+str(JwTceYNvUD)+'_2',tDcAXVbokl03rqLU)
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.url_'+str(JwTceYNvUD)+'_3',Xe0sAHmQZP1TWlVk)
			amx9qJHkhw7oLdtVMG3.setSetting('av.m3u.url_'+str(JwTceYNvUD)+'_4',oubNx3p8FIP4q91BeA0)
			KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if KKrj6Fkd5Tgv9ImSAGyaEeLcipt==1:
				LYxPXhImrsfR9ZdHGzt = VJjIRS372YMKveNq9c(JwTceYNvUD)
				return LYxPXhImrsfR9ZdHGzt
		else:
			S3chIQa4byNJLZnvp21 = 'إضافة وتغيير رابط '+F7hmrbfYztVycGjDE4Sd[1]+' (مجلد '+F7hmrbfYztVycGjDE4Sd[int(JwTceYNvUD)]+')'
			KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,S3chIQa4byNJLZnvp21,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if KKrj6Fkd5Tgv9ImSAGyaEeLcipt==1: blB4noXQuOqCmLxPG0wYv(JwTceYNvUD,'1')
	return False
def CEL2jIhns8aW(Pl2a5Y30gbqRShyNXrFosxvDVu8L,JwTceYNvUD=G9G0YqivIfmUWO8K,KEqwWYSFhVzpyBs2D4XZ=G9G0YqivIfmUWO8K,OQka3nI8tDsAZ6ebwMdX=G9G0YqivIfmUWO8K):
	if not OQka3nI8tDsAZ6ebwMdX: OQka3nI8tDsAZ6ebwMdX = '1'
	I47oPYM1VXxnt,m5qG0Lfhadn7kzVQSsM,TThZapolz65vswcfC18AKSdX2HMV = bY6tjyS08hUC(Pl2a5Y30gbqRShyNXrFosxvDVu8L)
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV): return
	if not I47oPYM1VXxnt:
		I47oPYM1VXxnt = ZT7zGWSCtpvfmwMNRjYrKL()
		if not I47oPYM1VXxnt: return
	EXfBOIZR7sJk5ziMG = [G9G0YqivIfmUWO8K,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not KEqwWYSFhVzpyBs2D4XZ:
		if not TThZapolz65vswcfC18AKSdX2HMV:
			if   '_M3U-LIVE_' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[1]
			elif '_M3U-MOVIES' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[2]
			elif '_M3U-SERIES' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[3]
			else: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[0]
		else:
			UUIikfJ6xmZqwng21uXBpFMCE3 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			z5zsxSmjpGVIoJ6OT = wjrY1si9L6('أختر البحث المناسب', UUIikfJ6xmZqwng21uXBpFMCE3)
			if z5zsxSmjpGVIoJ6OT==-1: return
			KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[z5zsxSmjpGVIoJ6OT]
	I47oPYM1VXxnt = I47oPYM1VXxnt+'_NODIALOGS_'
	if JwTceYNvUD: Z2M9Opm7tG1qjDTcodLu8PQ3lawW(I47oPYM1VXxnt,JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ,OQka3nI8tDsAZ6ebwMdX)
	else:
		for JwTceYNvUD in range(1,XmGcjWDVrAuKeMFlbSvdhYi1+1):
			Z2M9Opm7tG1qjDTcodLu8PQ3lawW(I47oPYM1VXxnt,str(JwTceYNvUD),KEqwWYSFhVzpyBs2D4XZ,OQka3nI8tDsAZ6ebwMdX)
		eANQpmZPJaI7wc8[:] = sorted(eANQpmZPJaI7wc8,reverse=False,key=lambda u2ynb8RckJiqGpeV07hEF63: u2ynb8RckJiqGpeV07hEF63[1].lower())
	return
def Z2M9Opm7tG1qjDTcodLu8PQ3lawW(Pl2a5Y30gbqRShyNXrFosxvDVu8L,JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ=G9G0YqivIfmUWO8K,OQka3nI8tDsAZ6ebwMdX=G9G0YqivIfmUWO8K):
	if not OQka3nI8tDsAZ6ebwMdX: OQka3nI8tDsAZ6ebwMdX = '1'
	I47oPYM1VXxnt,m5qG0Lfhadn7kzVQSsM,TThZapolz65vswcfC18AKSdX2HMV = bY6tjyS08hUC(Pl2a5Y30gbqRShyNXrFosxvDVu8L)
	if not JwTceYNvUD: return
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV): return
	if not I47oPYM1VXxnt:
		I47oPYM1VXxnt = ZT7zGWSCtpvfmwMNRjYrKL()
		if not I47oPYM1VXxnt: return
	EXfBOIZR7sJk5ziMG = [G9G0YqivIfmUWO8K,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not KEqwWYSFhVzpyBs2D4XZ:
		if not TThZapolz65vswcfC18AKSdX2HMV:
			if   '_M3U-LIVE_' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[1]
			elif '_M3U-MOVIES' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[2]
			elif '_M3U-SERIES' in m5qG0Lfhadn7kzVQSsM: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[3]
			else: KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[0]
		else:
			UUIikfJ6xmZqwng21uXBpFMCE3 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			z5zsxSmjpGVIoJ6OT = wjrY1si9L6('أختر البحث المناسب', UUIikfJ6xmZqwng21uXBpFMCE3)
			if z5zsxSmjpGVIoJ6OT==-1: return
			KEqwWYSFhVzpyBs2D4XZ = EXfBOIZR7sJk5ziMG[z5zsxSmjpGVIoJ6OT]
	GnHsSgZxlCuLpe2URJ = I47oPYM1VXxnt.lower()
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,'SEARCH')
	kqe8AmaJG6pIvUCPSXb = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list','SEARCH',(KEqwWYSFhVzpyBs2D4XZ,GnHsSgZxlCuLpe2URJ))
	if not kqe8AmaJG6pIvUCPSXb:
		vmsrR7hiOtDxV8nGS,DWpocSkw9eqzgfsFmbJl = [],[]
		if not KEqwWYSFhVzpyBs2D4XZ: NwHcDqLi49WyX0ZCEpteQdaBFhk1Uz = [1,2,3,4,5]
		else: NwHcDqLi49WyX0ZCEpteQdaBFhk1Uz = [EXfBOIZR7sJk5ziMG.index(KEqwWYSFhVzpyBs2D4XZ)]
		for KJZlbgk2TdD5GWQFqucMP in NwHcDqLi49WyX0ZCEpteQdaBFhk1Uz:
			if KJZlbgk2TdD5GWQFqucMP!=3:
				OKCAQ0sxp94dyuIatJW1B7G2woDh = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'dict',EXfBOIZR7sJk5ziMG[KJZlbgk2TdD5GWQFqucMP])
				del OKCAQ0sxp94dyuIatJW1B7G2woDh['__COUNT__']
				del OKCAQ0sxp94dyuIatJW1B7G2woDh['__GROUPS__']
				del OKCAQ0sxp94dyuIatJW1B7G2woDh['__SEQUENCED_COLUMNS__']
				lnLEoFyazbjp9eSKcQV0C6 = list(OKCAQ0sxp94dyuIatJW1B7G2woDh.keys())
				for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in lnLEoFyazbjp9eSKcQV0C6:
					for mUTXiaBzJf2utgY3KFIQl,G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in OKCAQ0sxp94dyuIatJW1B7G2woDh[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6]:
						if GnHsSgZxlCuLpe2URJ in G3V6fB4UjqZA1pH5mENOsa.lower(): DWpocSkw9eqzgfsFmbJl.append((G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR))
					del OKCAQ0sxp94dyuIatJW1B7G2woDh[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6]
				del OKCAQ0sxp94dyuIatJW1B7G2woDh
			else: lnLEoFyazbjp9eSKcQV0C6 = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'list',EXfBOIZR7sJk5ziMG[KJZlbgk2TdD5GWQFqucMP],'__GROUPS__')
			for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in lnLEoFyazbjp9eSKcQV0C6:
				try: lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,XXq21TJ3Zo4FuYDEgh9GBcLPOVR = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6
				except: XXq21TJ3Zo4FuYDEgh9GBcLPOVR = G9G0YqivIfmUWO8K
				if GnHsSgZxlCuLpe2URJ in lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.lower():
					if KJZlbgk2TdD5GWQFqucMP!=3: KKhsjcGXeEakAWyrtu2iD = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6
					else:
						cNPROyZITLV,fJ0CE6GXpxF1n5K3vaoN = lQRCX7wUkWf1Opjaxbno2ZDh5GAi6.split('__SERIES__')
						if GnHsSgZxlCuLpe2URJ in cNPROyZITLV.lower(): KKhsjcGXeEakAWyrtu2iD = cNPROyZITLV
						else: KKhsjcGXeEakAWyrtu2iD = fJ0CE6GXpxF1n5K3vaoN
					vmsrR7hiOtDxV8nGS.append((lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,KKhsjcGXeEakAWyrtu2iD,EXfBOIZR7sJk5ziMG[KJZlbgk2TdD5GWQFqucMP],XXq21TJ3Zo4FuYDEgh9GBcLPOVR))
			del lnLEoFyazbjp9eSKcQV0C6
		vmsrR7hiOtDxV8nGS = set(vmsrR7hiOtDxV8nGS)
		DWpocSkw9eqzgfsFmbJl = set(DWpocSkw9eqzgfsFmbJl)
		vmsrR7hiOtDxV8nGS = sorted(vmsrR7hiOtDxV8nGS,reverse=False,key=lambda u2ynb8RckJiqGpeV07hEF63: u2ynb8RckJiqGpeV07hEF63[1])
		DWpocSkw9eqzgfsFmbJl = sorted(DWpocSkw9eqzgfsFmbJl,reverse=False,key=lambda u2ynb8RckJiqGpeV07hEF63: u2ynb8RckJiqGpeV07hEF63[0])
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,'SEARCH',(KEqwWYSFhVzpyBs2D4XZ,GnHsSgZxlCuLpe2URJ),(vmsrR7hiOtDxV8nGS,DWpocSkw9eqzgfsFmbJl),UKDwMTZk9dni1JSLcf0oRXhqy)
	else: vmsrR7hiOtDxV8nGS,DWpocSkw9eqzgfsFmbJl = kqe8AmaJG6pIvUCPSXb
	lnLEoFyazbjp9eSKcQV0C6 = len(vmsrR7hiOtDxV8nGS)
	AMmWv9D4wI7opgaFVzkRtO185PCdj = len(DWpocSkw9eqzgfsFmbJl)
	bjSL1IZNRp59z2 = int(OQka3nI8tDsAZ6ebwMdX)
	pdHN5EgrnDQc9mqTK23ZoaCtAji = max(0,(bjSL1IZNRp59z2-1)*100)
	rf35PVYJd96KqH0pl2GMwtzSemXvT1 = max(0,bjSL1IZNRp59z2*100)
	FMqseutgwS4 = max(0,pdHN5EgrnDQc9mqTK23ZoaCtAji-lnLEoFyazbjp9eSKcQV0C6)
	Qf2GnRrBV86U0HkCJyTIlaszL = max(0,rf35PVYJd96KqH0pl2GMwtzSemXvT1-lnLEoFyazbjp9eSKcQV0C6)
	for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,KKhsjcGXeEakAWyrtu2iD,tPl76uMvbWHfg5B1hj8,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in vmsrR7hiOtDxV8nGS[pdHN5EgrnDQc9mqTK23ZoaCtAji:rf35PVYJd96KqH0pl2GMwtzSemXvT1]:
		Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+KKhsjcGXeEakAWyrtu2iD,tPl76uMvbWHfg5B1hj8,714,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,'1',lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	del vmsrR7hiOtDxV8nGS
	for G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,XXq21TJ3Zo4FuYDEgh9GBcLPOVR in DWpocSkw9eqzgfsFmbJl[FMqseutgwS4:Qf2GnRrBV86U0HkCJyTIlaszL]:
		tsfUgen0TAckI3CzF2vdxuL = Ig4jFuXGfUQeCn6wlB8(Qjnkp0KgXq2Ty)
		Um2ITJ1iLnEjqZevskVt06NY34 = 'live'
		if '.mkv' in tsfUgen0TAckI3CzF2vdxuL or 'VOD' in KEqwWYSFhVzpyBs2D4XZ: Um2ITJ1iLnEjqZevskVt06NY34 = 'video'
		Qm8SMu6ecXtigDCWw1oak(Um2ITJ1iLnEjqZevskVt06NY34,s8zrCjhgWx9OvmKq65oefIXHw+G3V6fB4UjqZA1pH5mENOsa,Qjnkp0KgXq2Ty,715,XXq21TJ3Zo4FuYDEgh9GBcLPOVR,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	del DWpocSkw9eqzgfsFmbJl
	Uvld19IVa5fjZNKpBFMx7OckGQ(JwTceYNvUD,OQka3nI8tDsAZ6ebwMdX,KEqwWYSFhVzpyBs2D4XZ,719,lnLEoFyazbjp9eSKcQV0C6+AMmWv9D4wI7opgaFVzkRtO185PCdj,I47oPYM1VXxnt+'_NODIALOGS_')
	return
def Uvld19IVa5fjZNKpBFMx7OckGQ(JwTceYNvUD,OQka3nI8tDsAZ6ebwMdX,KEqwWYSFhVzpyBs2D4XZ,Mauf6CrJjP87s,fRo3XgN2pxte4MK,Vvju9Ht8SGxoiTa6lCs):
	if not OQka3nI8tDsAZ6ebwMdX: OQka3nI8tDsAZ6ebwMdX = '1'
	if OQka3nI8tDsAZ6ebwMdX!='1': Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'صفحة '+str(1),KEqwWYSFhVzpyBs2D4XZ,Mauf6CrJjP87s,G9G0YqivIfmUWO8K,str(1),Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	if not fRo3XgN2pxte4MK: fRo3XgN2pxte4MK = 0
	lJEp7gyOYUzkGRtB25Hv = int(fRo3XgN2pxte4MK/100)+1
	for bjSL1IZNRp59z2 in range(2,lJEp7gyOYUzkGRtB25Hv):
		qdGmpAs1jyN = (bjSL1IZNRp59z2%10==0 or int(OQka3nI8tDsAZ6ebwMdX)-4<bjSL1IZNRp59z2<int(OQka3nI8tDsAZ6ebwMdX)+4)
		HHbIDUPa4AW6dfY8TupJB2sQvwnS = (qdGmpAs1jyN and int(OQka3nI8tDsAZ6ebwMdX)-40<bjSL1IZNRp59z2<int(OQka3nI8tDsAZ6ebwMdX)+40)
		if str(bjSL1IZNRp59z2)!=OQka3nI8tDsAZ6ebwMdX and (bjSL1IZNRp59z2%100==0 or HHbIDUPa4AW6dfY8TupJB2sQvwnS):
			Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'صفحة '+str(bjSL1IZNRp59z2),KEqwWYSFhVzpyBs2D4XZ,Mauf6CrJjP87s,G9G0YqivIfmUWO8K,str(bjSL1IZNRp59z2),Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	if str(lJEp7gyOYUzkGRtB25Hv)!=OQka3nI8tDsAZ6ebwMdX: Qm8SMu6ecXtigDCWw1oak('folder',s8zrCjhgWx9OvmKq65oefIXHw+'أخر صفحة '+str(lJEp7gyOYUzkGRtB25Hv),KEqwWYSFhVzpyBs2D4XZ,Mauf6CrJjP87s,G9G0YqivIfmUWO8K,str(lJEp7gyOYUzkGRtB25Hv),Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,{'folder':JwTceYNvUD})
	return
def qa4IeON9SmPWn0R128(JwTceYNvUD,KEqwWYSFhVzpyBs2D4XZ):
	oGslP3LehCWpUq0dZAt = xrqZW7U0vfmJP9Dw.replace('___','_'+JwTceYNvUD)
	return oGslP3LehCWpUq0dZAt
def VJjIRS372YMKveNq9c(JwTceYNvUD):
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,G9G0YqivIfmUWO8K)
	KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if KKrj6Fkd5Tgv9ImSAGyaEeLcipt!=1: return False
	u6Cyjrzdi2qP7ZDVko4OE5wJTYNXF(JwTceYNvUD,False)
	FFVRpScDL2sib0xWyOrgm = [0]
	for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
		x24eYSlf6NJDQb5RTIVyq = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.url_'+JwTceYNvUD+'_'+str(o6IQax2n7skH))
		if x24eYSlf6NJDQb5RTIVyq: ZgJSxUdtnhwc0jiGWH1O8DACrR(JwTceYNvUD,str(o6IQax2n7skH))
		FFVRpScDL2sib0xWyOrgm.append(0)
	for KEqwWYSFhVzpyBs2D4XZ in gXbKi2S5869pG3xc:
		N9DxUYtCdBwuH0mWGahb,NI6AUbv3imfenZ94WgPt5wBz,Tf5Z1rUt37bSkWEPCX,jjJ8m6Y5fxouy7PRpDwdzivF,e7EF16APVwXqvhNGKo5yIrcO = 0,{},[],[],[]
		for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
			tPl76uMvbWHfg5B1hj8 = KEqwWYSFhVzpyBs2D4XZ+'_'+str(o6IQax2n7skH)
			WUR8sKuN25AC0lpHE = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'dict',tPl76uMvbWHfg5B1hj8)
			try:
				Kf4SzeFnQHuLjqO = WUR8sKuN25AC0lpHE['__GROUPS__']
				UZq3rSzmpw61ALGCIeuxBRyhb75V4 = WUR8sKuN25AC0lpHE['__COUNT__']
			except: Kf4SzeFnQHuLjqO,UZq3rSzmpw61ALGCIeuxBRyhb75V4 = [],'0'
			for sT1ZvCpR8jf3AcSzVKq7L in Kf4SzeFnQHuLjqO:
				lQRCX7wUkWf1Opjaxbno2ZDh5GAi6,eEDLWJkqd4hg = sT1ZvCpR8jf3AcSzVKq7L
				OKCAQ0sxp94dyuIatJW1B7G2woDh = WUR8sKuN25AC0lpHE[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6]
				if lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 not in jjJ8m6Y5fxouy7PRpDwdzivF:
					jjJ8m6Y5fxouy7PRpDwdzivF.append(lQRCX7wUkWf1Opjaxbno2ZDh5GAi6)
					e7EF16APVwXqvhNGKo5yIrcO.append(sT1ZvCpR8jf3AcSzVKq7L)
					NI6AUbv3imfenZ94WgPt5wBz[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] = []
				NI6AUbv3imfenZ94WgPt5wBz[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6] += OKCAQ0sxp94dyuIatJW1B7G2woDh
			aaSYfirqFBsp9IDRG7MAQtdLbxluV(oGslP3LehCWpUq0dZAt,tPl76uMvbWHfg5B1hj8)
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,tPl76uMvbWHfg5B1hj8,'__COUNT__',UZq3rSzmpw61ALGCIeuxBRyhb75V4,UKDwMTZk9dni1JSLcf0oRXhqy)
			FFVRpScDL2sib0xWyOrgm[o6IQax2n7skH] += int(UZq3rSzmpw61ALGCIeuxBRyhb75V4)
		for lQRCX7wUkWf1Opjaxbno2ZDh5GAi6 in jjJ8m6Y5fxouy7PRpDwdzivF:
			OKCAQ0sxp94dyuIatJW1B7G2woDh = list(set(NI6AUbv3imfenZ94WgPt5wBz[lQRCX7wUkWf1Opjaxbno2ZDh5GAi6]))
			if 'SORTED' in KEqwWYSFhVzpyBs2D4XZ: OKCAQ0sxp94dyuIatJW1B7G2woDh = sorted(OKCAQ0sxp94dyuIatJW1B7G2woDh,reverse=False,key=lambda key: key[1].lower())
			N9DxUYtCdBwuH0mWGahb += len(OKCAQ0sxp94dyuIatJW1B7G2woDh)
			Tf5Z1rUt37bSkWEPCX.append(OKCAQ0sxp94dyuIatJW1B7G2woDh)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,KEqwWYSFhVzpyBs2D4XZ,'__COUNT__',str(N9DxUYtCdBwuH0mWGahb),UKDwMTZk9dni1JSLcf0oRXhqy)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,KEqwWYSFhVzpyBs2D4XZ,'__GROUPS__',e7EF16APVwXqvhNGKo5yIrcO,UKDwMTZk9dni1JSLcf0oRXhqy)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,KEqwWYSFhVzpyBs2D4XZ,jjJ8m6Y5fxouy7PRpDwdzivF,Tf5Z1rUt37bSkWEPCX,UKDwMTZk9dni1JSLcf0oRXhqy,True)
	LLlfGUV7B43i = False
	for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
		if int(FFVRpScDL2sib0xWyOrgm[o6IQax2n7skH])>0:
			x24eYSlf6NJDQb5RTIVyq = amx9qJHkhw7oLdtVMG3.getSetting('av.m3u.url_'+JwTceYNvUD+'_'+str(o6IQax2n7skH))
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,'LINK_'+str(o6IQax2n7skH),'__LINK__',x24eYSlf6NJDQb5RTIVyq,UKDwMTZk9dni1JSLcf0oRXhqy)
			LLlfGUV7B43i = True
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(oGslP3LehCWpUq0dZAt,'DUMMY','__DUMMY__','DUMMY',UKDwMTZk9dni1JSLcf0oRXhqy)
	if not LLlfGUV7B43i:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	fPyLAr0gzuowDpa(JwTceYNvUD)
	CU83wctmZIMAaxHv(False)
	Wz9Lj5vK4qeIBn1rTP20y78aogJ(False)
	return True
def fPyLAr0gzuowDpa(JwTceYNvUD):
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,G9G0YqivIfmUWO8K)
	if not eia6WyskqpVGdRYrM0xLuUTOw(JwTceYNvUD,True): return
	for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
		x24eYSlf6NJDQb5RTIVyq = PiXRCL1dtv6pWfU(oGslP3LehCWpUq0dZAt,'str','LINK_'+str(o6IQax2n7skH),'__LINK__')
		if x24eYSlf6NJDQb5RTIVyq: S0f2EpJzD1aYv5UnkmWdTROi = VQ3Sc8lLbIAnrEyXJsN0mOfvhaCug(JwTceYNvUD,str(o6IQax2n7skH))
	VQ3Sc8lLbIAnrEyXJsN0mOfvhaCug(JwTceYNvUD,G9G0YqivIfmUWO8K)
	return
def u6Cyjrzdi2qP7ZDVko4OE5wJTYNXF(JwTceYNvUD,TThZapolz65vswcfC18AKSdX2HMV):
	if TThZapolz65vswcfC18AKSdX2HMV:
		KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if KKrj6Fkd5Tgv9ImSAGyaEeLcipt!=1: return
	oGslP3LehCWpUq0dZAt = qa4IeON9SmPWn0R128(JwTceYNvUD,G9G0YqivIfmUWO8K)
	try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(oGslP3LehCWpUq0dZAt)
	except: pass
	for o6IQax2n7skH in range(1,wcJtRB8pgQ0+1):
		gte6YE2JupmKiP = Qe2LqnH1RN3mU.replace('___','_'+JwTceYNvUD+'_'+str(o6IQax2n7skH))
		z67VfApLXyIaZQTRrJuc = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,gte6YE2JupmKiP)
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(z67VfApLXyIaZQTRrJuc)
		except: pass
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'SECTIONS_M3U','SECTIONS_M3U_'+JwTceYNvUD)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if TThZapolz65vswcfC18AKSdX2HMV:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(False)
	return
def WWJNq3IoO675KxgjblYcHDLwTCR(JwTceYNvUD):
	bbQDZvfek0n5AhEVlRmPY1uH8MNqG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.provider')
	tiDlKLqjJPsG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.code')
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'MENUS_CACHE_'+bbQDZvfek0n5AhEVlRmPY1uH8MNqG+'_'+tiDlKLqjJPsG,'%_MU'+JwTceYNvUD+'_%')
	return
xT0CzGSV2c1i3ULjp4fQ = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
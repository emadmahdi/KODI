# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'YOUTUBE'
TdtCLWYSJNK8zOb = '_YUT_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
jQRpwuOxlSDbhaMYkzV = 0
def RAndFk3y4Pbvs29(mode,url,text,type,eehFlSEjHioyAWpLqZXt79,name,Vy1U0koJLPFhxe2TS):
	if	 mode==140: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==141: tRojAyBgfDH37eLCwP4dWl = xjMbCX2fNGFhvOTrqBmyI41tsQW(url,name,Vy1U0koJLPFhxe2TS)
	elif mode==143: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url,type)
	elif mode==144: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79,text)
	elif mode==145: tRojAyBgfDH37eLCwP4dWl = NSa42MzFeJcuV9qBdrH5PTw(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==147: tRojAyBgfDH37eLCwP4dWl = r9mFB0SiMnx73bT()
	elif mode==148: tRojAyBgfDH37eLCwP4dWl = kJvy1uNhGlcFADn504Vg()
	elif mode==149: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	if 0:
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'قائمة 1',ffVP3AK5RqhkgYnjZoNis+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'قائمة 2',ffVP3AK5RqhkgYnjZoNis+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'شخص',ffVP3AK5RqhkgYnjZoNis+'/user/TCNofficial',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'موقع',ffVP3AK5RqhkgYnjZoNis+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'حساب',ffVP3AK5RqhkgYnjZoNis+'/@TheSocialCTV',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'العاب',ffVP3AK5RqhkgYnjZoNis+'/gaming',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'افلام',ffVP3AK5RqhkgYnjZoNis+'/feed/storefront',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مختارات',ffVP3AK5RqhkgYnjZoNis+'/feed/guide_builder',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'قصيرة',ffVP3AK5RqhkgYnjZoNis+'/shorts',144,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'تصفح',ffVP3AK5RqhkgYnjZoNis+'/youtubei/v1/guide?key=',144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'رئيسية',ffVP3AK5RqhkgYnjZoNis+G9G0YqivIfmUWO8K,144)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'رائج',ffVP3AK5RqhkgYnjZoNis+'/feed/trending?bp=',144)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,149,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الرائجة',ffVP3AK5RqhkgYnjZoNis+'/feed/trending',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'التصفح',ffVP3AK5RqhkgYnjZoNis+'/youtubei/v1/guide?key=',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'القصيرة',ffVP3AK5RqhkgYnjZoNis+'/shorts',144,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مختارات يوتيوب',ffVP3AK5RqhkgYnjZoNis+'/feed/guide_builder',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مختارات البرنامج',G9G0YqivIfmUWO8K,290)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: قنوات عربية',G9G0YqivIfmUWO8K,147)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: قنوات أجنبية',G9G0YqivIfmUWO8K,148)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: افلام عربية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=فيلم',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: افلام اجنبية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=movie',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: مسرحيات عربية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=مسرحية',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: مسلسلات عربية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: مسلسلات اجنبية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=series&sp=EgIQAw==',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: مسلسلات كارتون',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=كارتون&sp=EgIQAw==',144)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث: خطبة المرجعية',ffVP3AK5RqhkgYnjZoNis+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def xjMbCX2fNGFhvOTrqBmyI41tsQW(url,name,Vy1U0koJLPFhxe2TS):
	name = wilKJdNLRzVvboaHjkYBrU51(name)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'CHNL:  '+name,url,144,Vy1U0koJLPFhxe2TS)
	return
def r9mFB0SiMnx73bT():
	UUhwKBgI2nt(ffVP3AK5RqhkgYnjZoNis+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def kJvy1uNhGlcFADn504Vg():
	UUhwKBgI2nt(ffVP3AK5RqhkgYnjZoNis+'/results?search_query=tv&sp=EgJAAQ==')
	return
def sWujQcGynM9NtJeTfqk3D(url,type):
	url = url.split('&',1)[0]
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk([url],s5slfAmHkUtMR3WSKY1ZTX,type,url)
	return
def vvUfg9Bsh7w0G2(JOnDaEjiAcKWXrsthC,url,iT2wOVymHEMAhWl6jbJs8pY):
	level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = iT2wOVymHEMAhWl6jbJs8pY.split('::')
	G9JRzlB8pgj,naZDPoWU8YeIOz = [],[]
	if '/youtubei/v1/browse' in url: G9JRzlB8pgj.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: G9JRzlB8pgj.append("yccc['onResponseReceivedCommands']")
	G9JRzlB8pgj.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': G9JRzlB8pgj.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	G9JRzlB8pgj.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	G9JRzlB8pgj.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	G9JRzlB8pgj.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	G9JRzlB8pgj.append("yccc['entries']")
	G9JRzlB8pgj.append("yccc['items'][3]['guideSectionRenderer']['items']")
	fG4gKBih71LM,iEubxJ4rT3SmpcaWys,gN3w4AdypBvj1Q9VbE6FPWMelD5H = gsEXl3JmrcPRvYWOqLy4u9eNA6(JOnDaEjiAcKWXrsthC,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
	if level=='1' and fG4gKBih71LM:
		if len(iEubxJ4rT3SmpcaWys)>1 and 'search_query' not in url:
			for Z4T1wWMYg0jhEsVzb5NqHk in range(len(iEubxJ4rT3SmpcaWys)):
				UUhJ3naPX8mVDZT6BkWp = str(Z4T1wWMYg0jhEsVzb5NqHk)
				G9JRzlB8pgj = []
				G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['reloadContinuationItemsCommand']['continuationItems']")
				G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['command']")
				G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]")
				pEU7uHoc0zQOC1Anab3KxZ9k,XX2Btn97vEfkCjcuWs,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(iEubxJ4rT3SmpcaWys,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
				if pEU7uHoc0zQOC1Anab3KxZ9k: naZDPoWU8YeIOz.append([XX2Btn97vEfkCjcuWs,url,'2::'+UUhJ3naPX8mVDZT6BkWp+'::0::0'])
			G9JRzlB8pgj.append("yccc['continuationEndpoint']")
			pEU7uHoc0zQOC1Anab3KxZ9k,XX2Btn97vEfkCjcuWs,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(JOnDaEjiAcKWXrsthC,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
			if pEU7uHoc0zQOC1Anab3KxZ9k and naZDPoWU8YeIOz and 'continuationCommand' in list(XX2Btn97vEfkCjcuWs.keys()):
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/my_main_page_shorts_link'
				naZDPoWU8YeIOz.append([XX2Btn97vEfkCjcuWs,Y6YdkAMluFbwx,'1::0::0::0'])
	return iEubxJ4rT3SmpcaWys,fG4gKBih71LM,naZDPoWU8YeIOz,gN3w4AdypBvj1Q9VbE6FPWMelD5H
def Xb1BPYRsIcm6H0Tv8lQr4O9q(JOnDaEjiAcKWXrsthC,iEubxJ4rT3SmpcaWys,url,iT2wOVymHEMAhWl6jbJs8pY):
	level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = iT2wOVymHEMAhWl6jbJs8pY.split('::')
	G9JRzlB8pgj,hK8cpQyWbaTrNloxE0Iui = [],[]
	G9JRzlB8pgj.append("yddd[0]['itemSectionRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['reloadContinuationItemsCommand']['continuationItems']")
	G9JRzlB8pgj.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: G9JRzlB8pgj.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: G9JRzlB8pgj.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	G9JRzlB8pgj.append("yddd["+UUhJ3naPX8mVDZT6BkWp+"]")
	QZs3ADqBPkRhHnLG27u,nnRX62k9ZfQObzCqrx,uudUyIs2A0HwtSD9 = gsEXl3JmrcPRvYWOqLy4u9eNA6(iEubxJ4rT3SmpcaWys,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
	if level=='2' and QZs3ADqBPkRhHnLG27u:
		if len(nnRX62k9ZfQObzCqrx)>1:
			for Z4T1wWMYg0jhEsVzb5NqHk in range(len(nnRX62k9ZfQObzCqrx)):
				d4FHPYiaLrOjctlK9oN7uQJWsIp = str(Z4T1wWMYg0jhEsVzb5NqHk)
				G9JRzlB8pgj = []
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['richSectionRenderer']['content']")
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]")
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['richItemRenderer']['content']")
				G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]")
				pEU7uHoc0zQOC1Anab3KxZ9k,XX2Btn97vEfkCjcuWs,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(nnRX62k9ZfQObzCqrx,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
				if pEU7uHoc0zQOC1Anab3KxZ9k: hK8cpQyWbaTrNloxE0Iui.append([XX2Btn97vEfkCjcuWs,url,'3::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::0'])
			G9JRzlB8pgj.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			G9JRzlB8pgj.append("yddd[1]")
			pEU7uHoc0zQOC1Anab3KxZ9k,XX2Btn97vEfkCjcuWs,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(iEubxJ4rT3SmpcaWys,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
			if pEU7uHoc0zQOC1Anab3KxZ9k and hK8cpQyWbaTrNloxE0Iui and 'continuationItemRenderer' in list(XX2Btn97vEfkCjcuWs.keys()):
				hK8cpQyWbaTrNloxE0Iui.append([XX2Btn97vEfkCjcuWs,url,'3::0::0::0'])
	return nnRX62k9ZfQObzCqrx,QZs3ADqBPkRhHnLG27u,hK8cpQyWbaTrNloxE0Iui,uudUyIs2A0HwtSD9
def BSpdAYj2zXfIK0ag1sclUiGC9WJ(JOnDaEjiAcKWXrsthC,nnRX62k9ZfQObzCqrx,url,iT2wOVymHEMAhWl6jbJs8pY):
	level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = iT2wOVymHEMAhWl6jbJs8pY.split('::')
	G9JRzlB8pgj,QK9muhroUGTlzEvkFVptxDqj = [],[]
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	G9JRzlB8pgj.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	G9JRzlB8pgj.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	G9JRzlB8pgj.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['reelShelfRenderer']['items']")
	G9JRzlB8pgj.append("yeee["+d4FHPYiaLrOjctlK9oN7uQJWsIp+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	G9JRzlB8pgj.append("yeee")
	AsClNceOSGhZ6zEKF,TMWqurJzxCAHtnXL5Y,xNWBpo5CKkfts19Ty8iXaL = gsEXl3JmrcPRvYWOqLy4u9eNA6(nnRX62k9ZfQObzCqrx,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
	if level=='3' and AsClNceOSGhZ6zEKF:
		if len(TMWqurJzxCAHtnXL5Y)>0:
			for Z4T1wWMYg0jhEsVzb5NqHk in range(len(TMWqurJzxCAHtnXL5Y)):
				qGn9pLfuSXJFe2N = str(Z4T1wWMYg0jhEsVzb5NqHk)
				G9JRzlB8pgj = []
				G9JRzlB8pgj.append("yfff["+qGn9pLfuSXJFe2N+"]['richItemRenderer']['content']")
				G9JRzlB8pgj.append("yfff["+qGn9pLfuSXJFe2N+"]['gameCardRenderer']['game']")
				G9JRzlB8pgj.append("yfff["+qGn9pLfuSXJFe2N+"]['itemSectionRenderer']['contents'][0]")
				G9JRzlB8pgj.append("yfff["+qGn9pLfuSXJFe2N+"]")
				G9JRzlB8pgj.append("yfff")
				pEU7uHoc0zQOC1Anab3KxZ9k,XX2Btn97vEfkCjcuWs,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(TMWqurJzxCAHtnXL5Y,G9G0YqivIfmUWO8K,G9JRzlB8pgj)
				if pEU7uHoc0zQOC1Anab3KxZ9k: QK9muhroUGTlzEvkFVptxDqj.append([XX2Btn97vEfkCjcuWs,url,'4::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N])
	return TMWqurJzxCAHtnXL5Y,AsClNceOSGhZ6zEKF,QK9muhroUGTlzEvkFVptxDqj,xNWBpo5CKkfts19Ty8iXaL
def gsEXl3JmrcPRvYWOqLy4u9eNA6(gIRLK2jm74q31vs5z,uB9bUF45na,CjDAIYqptlUc4xy):
	JOnDaEjiAcKWXrsthC,uB9bUF45na = gIRLK2jm74q31vs5z,uB9bUF45na
	iEubxJ4rT3SmpcaWys,uB9bUF45na = gIRLK2jm74q31vs5z,uB9bUF45na
	nnRX62k9ZfQObzCqrx,uB9bUF45na = gIRLK2jm74q31vs5z,uB9bUF45na
	TMWqurJzxCAHtnXL5Y,uB9bUF45na = gIRLK2jm74q31vs5z,uB9bUF45na
	XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ = gIRLK2jm74q31vs5z,uB9bUF45na
	count = len(CjDAIYqptlUc4xy)
	for p0p6MxKbklodNCR92Wv in range(count):
		try:
			xvNDMeSchtjfrz8H9KPV = eval(CjDAIYqptlUc4xy[p0p6MxKbklodNCR92Wv])
			return True,xvNDMeSchtjfrz8H9KPV,p0p6MxKbklodNCR92Wv+1
		except: pass
	return False,G9G0YqivIfmUWO8K,0
def UUhwKBgI2nt(url,iT2wOVymHEMAhWl6jbJs8pY=G9G0YqivIfmUWO8K,data=G9G0YqivIfmUWO8K):
	naZDPoWU8YeIOz,hK8cpQyWbaTrNloxE0Iui,QK9muhroUGTlzEvkFVptxDqj = [],[],[]
	if '::' not in iT2wOVymHEMAhWl6jbJs8pY: iT2wOVymHEMAhWl6jbJs8pY = '1::0::0::0'
	level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = iT2wOVymHEMAhWl6jbJs8pY.split('::')
	if level=='4': level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = '1',UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N
	data = data.replace('_REMEMBERRESULTS_',G9G0YqivIfmUWO8K)
	GagwMT6q3oc7UZ2Q,JOnDaEjiAcKWXrsthC,pPIbdY3oKe = T2jLdkU8WXSJu(url,data)
	iT2wOVymHEMAhWl6jbJs8pY = level+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
	if level in ['1','2','3']:
		iEubxJ4rT3SmpcaWys,fG4gKBih71LM,naZDPoWU8YeIOz,gN3w4AdypBvj1Q9VbE6FPWMelD5H = vvUfg9Bsh7w0G2(JOnDaEjiAcKWXrsthC,url,iT2wOVymHEMAhWl6jbJs8pY)
		if not fG4gKBih71LM: return
		D9LnNgXyBj4IbTQeufG1qv = len(naZDPoWU8YeIOz)
		if D9LnNgXyBj4IbTQeufG1qv<2:
			if level=='1': level = '2'
			naZDPoWU8YeIOz = []
	iT2wOVymHEMAhWl6jbJs8pY = level+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
	if level in ['2','3']:
		nnRX62k9ZfQObzCqrx,QZs3ADqBPkRhHnLG27u,hK8cpQyWbaTrNloxE0Iui,uudUyIs2A0HwtSD9 = Xb1BPYRsIcm6H0Tv8lQr4O9q(JOnDaEjiAcKWXrsthC,iEubxJ4rT3SmpcaWys,url,iT2wOVymHEMAhWl6jbJs8pY)
		if not QZs3ADqBPkRhHnLG27u: return
		Ub1VAQzGgR = len(hK8cpQyWbaTrNloxE0Iui)
		if Ub1VAQzGgR<2:
			if level=='2': level = '3'
			hK8cpQyWbaTrNloxE0Iui = []
	iT2wOVymHEMAhWl6jbJs8pY = level+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
	if level in ['3']:
		TMWqurJzxCAHtnXL5Y,AsClNceOSGhZ6zEKF,QK9muhroUGTlzEvkFVptxDqj,xNWBpo5CKkfts19Ty8iXaL = BSpdAYj2zXfIK0ag1sclUiGC9WJ(JOnDaEjiAcKWXrsthC,nnRX62k9ZfQObzCqrx,url,iT2wOVymHEMAhWl6jbJs8pY)
		if not AsClNceOSGhZ6zEKF: return
		GNsQkmgib2j6ycAR = len(QK9muhroUGTlzEvkFVptxDqj)
	for XX2Btn97vEfkCjcuWs,url,iT2wOVymHEMAhWl6jbJs8pY in naZDPoWU8YeIOz+hK8cpQyWbaTrNloxE0Iui+QK9muhroUGTlzEvkFVptxDqj:
		L7saIgqHGDxmkRl8hAr3Y6NFWpfy = DaviYXPMS8bHp9Net(XX2Btn97vEfkCjcuWs,url,iT2wOVymHEMAhWl6jbJs8pY)
	return
def DaviYXPMS8bHp9Net(XX2Btn97vEfkCjcuWs,url=G9G0YqivIfmUWO8K,iT2wOVymHEMAhWl6jbJs8pY=G9G0YqivIfmUWO8K):
	if '::' in iT2wOVymHEMAhWl6jbJs8pY: level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = iT2wOVymHEMAhWl6jbJs8pY.split('::')
	else: level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = '1','0','0','0'
	pEU7uHoc0zQOC1Anab3KxZ9k,title,Y6YdkAMluFbwx,M4qkBDatEIf3T,count,ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ,ZWyp7eUvASuOQ3mk1qP,MnY7UcAuPXSrxtBekqobzy3h4f = nnHpgODrbG529dxUf(XX2Btn97vEfkCjcuWs)
	bRx6PsIvEpG1oaztMTJ2k8mcg = '/videos?' in Y6YdkAMluFbwx or '/streams?' in Y6YdkAMluFbwx or '/playlists?' in Y6YdkAMluFbwx
	bbrRn0qHLiNMQAphedTvgycIf = '/channels?' in Y6YdkAMluFbwx or '/shorts?' in Y6YdkAMluFbwx
	if bRx6PsIvEpG1oaztMTJ2k8mcg or bbrRn0qHLiNMQAphedTvgycIf: Y6YdkAMluFbwx = url
	bRx6PsIvEpG1oaztMTJ2k8mcg = 'watch?v=' not in Y6YdkAMluFbwx and '/playlist?list=' not in Y6YdkAMluFbwx
	bbrRn0qHLiNMQAphedTvgycIf = '/gaming' not in Y6YdkAMluFbwx  and '/feed/storefront' not in Y6YdkAMluFbwx
	if iT2wOVymHEMAhWl6jbJs8pY[0:5]=='3::0::' and bRx6PsIvEpG1oaztMTJ2k8mcg and bbrRn0qHLiNMQAphedTvgycIf: Y6YdkAMluFbwx = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in Y6YdkAMluFbwx:
		level,UUhJ3naPX8mVDZT6BkWp,d4FHPYiaLrOjctlK9oN7uQJWsIp,qGn9pLfuSXJFe2N = '1','0','0','0'
		iT2wOVymHEMAhWl6jbJs8pY = G9G0YqivIfmUWO8K
	pPIbdY3oKe = G9G0YqivIfmUWO8K
	if '/youtubei/v1/browse' in Y6YdkAMluFbwx or '/youtubei/v1/search' in Y6YdkAMluFbwx or '/my_main_page_shorts_link' in url:
		data = amx9qJHkhw7oLdtVMG3.getSetting('av.youtube.data')
		if data.count(':::')==4:
			DQl8E4WI37SZgxtnhGusq1Ty5Um,key,mWizAL4cYpdNUq80M2BxyoJgl,X3JnOdYPmNk1aT0,jJ1iOyvCtQxbFeK = data.split(':::')
			pPIbdY3oKe = DQl8E4WI37SZgxtnhGusq1Ty5Um+':::'+key+':::'+mWizAL4cYpdNUq80M2BxyoJgl+':::'+X3JnOdYPmNk1aT0+':::'+MnY7UcAuPXSrxtBekqobzy3h4f
			if '/my_main_page_shorts_link' in url and not Y6YdkAMluFbwx: Y6YdkAMluFbwx = url
			else: Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?key='+key
	if not title:
		global jQRpwuOxlSDbhaMYkzV
		jQRpwuOxlSDbhaMYkzV += 1
		title = 'فيديوهات '+str(jQRpwuOxlSDbhaMYkzV)
		iT2wOVymHEMAhWl6jbJs8pY = '3'+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
	if not pEU7uHoc0zQOC1Anab3KxZ9k: return False
	elif 'searchPyvRenderer' in str(XX2Btn97vEfkCjcuWs): return False
	elif '/about' in Y6YdkAMluFbwx: return False
	elif '/community' in Y6YdkAMluFbwx: return False
	elif 'continuationItemRenderer' in list(XX2Btn97vEfkCjcuWs.keys()) or 'continuationCommand' in list(XX2Btn97vEfkCjcuWs.keys()):
		if int(level)>1: level = str(int(level)-1)
		iT2wOVymHEMAhWl6jbJs8pY = level+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: '+'صفحة أخرى',Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY,pPIbdY3oKe)
	elif '/search' in Y6YdkAMluFbwx:
		title = ':: '+title
		iT2wOVymHEMAhWl6jbJs8pY = '3'+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
		url = url.replace('/search',G9G0YqivIfmUWO8K)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,145,G9G0YqivIfmUWO8K,iT2wOVymHEMAhWl6jbJs8pY,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not Y6YdkAMluFbwx:
		iT2wOVymHEMAhWl6jbJs8pY = '3'+'::'+UUhJ3naPX8mVDZT6BkWp+'::'+d4FHPYiaLrOjctlK9oN7uQJWsIp+'::'+qGn9pLfuSXJFe2N
		title = ':: '+title
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY,pPIbdY3oKe)
	elif '/browse' in Y6YdkAMluFbwx and url==ffVP3AK5RqhkgYnjZoNis:
		title = ':: '+title
		iT2wOVymHEMAhWl6jbJs8pY = '2::0::0::0'
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY,pPIbdY3oKe)
	elif not Y6YdkAMluFbwx and 'horizontalMovieListRenderer' in str(XX2Btn97vEfkCjcuWs):
		title = ':: '+title
		iT2wOVymHEMAhWl6jbJs8pY = '3::0::0::0'
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY)
	elif 'messageRenderer' in str(XX2Btn97vEfkCjcuWs):
		Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,9999)
	elif DC1B9MOsWbnQ:
		Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+DC1B9MOsWbnQ+title,Y6YdkAMluFbwx,143,M4qkBDatEIf3T)
	elif '/playlist?list=' in Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('&playnext=1',G9G0YqivIfmUWO8K)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'LIST'+count+':  '+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY)
	elif '/shorts/' in Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('&list=',1)[0]
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,143,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	elif '/watch?v=' in Y6YdkAMluFbwx:
		if '&list=' in Y6YdkAMluFbwx and count:
			Z1LS2qDiv9pVwBHaICF84TJoQWXR = Y6YdkAMluFbwx.split('&list=',1)[1]
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/playlist?list='+Z1LS2qDiv9pVwBHaICF84TJoQWXR
			iT2wOVymHEMAhWl6jbJs8pY = '1::0::0::0'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'LIST'+count+':  '+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY)
		else:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('&list=',1)[0]
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,143,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	elif '/channel/' in Y6YdkAMluFbwx or '/c/' in Y6YdkAMluFbwx or ('/@' in Y6YdkAMluFbwx and Y6YdkAMluFbwx.count('/')==3):
		if gA0m6CQUyfLG:
			title = title.decode(f3uIcZ2C6pzbX1JlFBrVOdt).encode('raw_unicode_escape')
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'CHNL'+count+':  '+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY)
	elif '/user/' in Y6YdkAMluFbwx:
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'USER'+count+':  '+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY)
	else:
		if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = url
		title = ':: '+title
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,144,M4qkBDatEIf3T,iT2wOVymHEMAhWl6jbJs8pY,pPIbdY3oKe)
	return True
def nnHpgODrbG529dxUf(XX2Btn97vEfkCjcuWs):
	pEU7uHoc0zQOC1Anab3KxZ9k,title,Y6YdkAMluFbwx,M4qkBDatEIf3T,count,ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ,ZWyp7eUvASuOQ3mk1qP,jJ1iOyvCtQxbFeK = False,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if not isinstance(XX2Btn97vEfkCjcuWs,dict): return pEU7uHoc0zQOC1Anab3KxZ9k,title,Y6YdkAMluFbwx,M4qkBDatEIf3T,count,ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ,ZWyp7eUvASuOQ3mk1qP,jJ1iOyvCtQxbFeK
	for TF8KjeoqG4xSurw in list(XX2Btn97vEfkCjcuWs.keys()):
		xP4Vark5NIzuyRgDfsA7YwQ = XX2Btn97vEfkCjcuWs[TF8KjeoqG4xSurw]
		if isinstance(xP4Vark5NIzuyRgDfsA7YwQ,dict): break
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	G9JRzlB8pgj.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	G9JRzlB8pgj.append("yrender['header']['richListHeaderRenderer']['title']")
	G9JRzlB8pgj.append("yrender['headline']['simpleText']")
	G9JRzlB8pgj.append("yrender['unplayableText']['simpleText']")
	G9JRzlB8pgj.append("yrender['formattedTitle']['simpleText']")
	G9JRzlB8pgj.append("yrender['title']['simpleText']")
	G9JRzlB8pgj.append("yrender['title']['runs'][0]['text']")
	G9JRzlB8pgj.append("yrender['text']['simpleText']")
	G9JRzlB8pgj.append("yrender['text']['runs'][0]['text']")
	G9JRzlB8pgj.append("yrender['title']['content']")
	G9JRzlB8pgj.append("yrender['title']")
	G9JRzlB8pgj.append("item['title']")
	G9JRzlB8pgj.append("item['reelWatchEndpoint']['videoId']")
	pEU7uHoc0zQOC1Anab3KxZ9k,title,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	G9JRzlB8pgj.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	G9JRzlB8pgj.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	G9JRzlB8pgj.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	G9JRzlB8pgj.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	G9JRzlB8pgj.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	G9JRzlB8pgj.append("item['commandMetadata']['webCommandMetadata']['url']")
	pEU7uHoc0zQOC1Anab3KxZ9k,Y6YdkAMluFbwx,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['thumbnail']['thumbnails'][0]['url']")
	G9JRzlB8pgj.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	G9JRzlB8pgj.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	pEU7uHoc0zQOC1Anab3KxZ9k,M4qkBDatEIf3T,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	G9JRzlB8pgj.append("yrender['videoCountShortText']['simpleText']")
	G9JRzlB8pgj.append("yrender['videoCountText']['runs'][0]['text']")
	G9JRzlB8pgj.append("yrender['videoCount']")
	pEU7uHoc0zQOC1Anab3KxZ9k,count,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	G9JRzlB8pgj.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	G9JRzlB8pgj.append("yrender['lengthText']['simpleText']")
	G9JRzlB8pgj.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	G9JRzlB8pgj.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	pEU7uHoc0zQOC1Anab3KxZ9k,ii9h6QFxBUuCeqJODlfYmsI7ZT,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	G9JRzlB8pgj = []
	G9JRzlB8pgj.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	G9JRzlB8pgj.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	pEU7uHoc0zQOC1Anab3KxZ9k,jJ1iOyvCtQxbFeK,zzp23C7fBiwrLHhdYt9a = gsEXl3JmrcPRvYWOqLy4u9eNA6(XX2Btn97vEfkCjcuWs,xP4Vark5NIzuyRgDfsA7YwQ,G9JRzlB8pgj)
	if 'LIVE' in ii9h6QFxBUuCeqJODlfYmsI7ZT: ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ = G9G0YqivIfmUWO8K,'LIVE:  '
	if 'مباشر' in ii9h6QFxBUuCeqJODlfYmsI7ZT: ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ = G9G0YqivIfmUWO8K,'LIVE:  '
	if 'badges' in list(xP4Vark5NIzuyRgDfsA7YwQ.keys()):
		RRZva5EUF8lzidh = str(xP4Vark5NIzuyRgDfsA7YwQ['badges'])
		if 'Free with Ads' in RRZva5EUF8lzidh: ZWyp7eUvASuOQ3mk1qP = '$:  '
		if 'LIVE' in RRZva5EUF8lzidh: DC1B9MOsWbnQ = 'LIVE:  '
		if 'Buy' in RRZva5EUF8lzidh or 'Rent' in RRZva5EUF8lzidh: ZWyp7eUvASuOQ3mk1qP = '$$:  '
		if X0Y7Axf35La9jPc1EiVIu(u'مباشر') in RRZva5EUF8lzidh: DC1B9MOsWbnQ = 'LIVE:  '
		if X0Y7Axf35La9jPc1EiVIu(u'شراء') in RRZva5EUF8lzidh: ZWyp7eUvASuOQ3mk1qP = '$$:  '
		if X0Y7Axf35La9jPc1EiVIu(u'استئجار') in RRZva5EUF8lzidh: ZWyp7eUvASuOQ3mk1qP = '$$:  '
		if X0Y7Axf35La9jPc1EiVIu(u'إعلانات') in RRZva5EUF8lzidh: ZWyp7eUvASuOQ3mk1qP = '$:  '
	Y6YdkAMluFbwx = zDBtm4MwIagkfcpE5oxJOAq6lZQY(Y6YdkAMluFbwx)
	if Y6YdkAMluFbwx and 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
	M4qkBDatEIf3T = M4qkBDatEIf3T.split('?')[0]
	if  M4qkBDatEIf3T and 'http' not in M4qkBDatEIf3T: M4qkBDatEIf3T = 'https:'+M4qkBDatEIf3T
	title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
	if ZWyp7eUvASuOQ3mk1qP: title = ZWyp7eUvASuOQ3mk1qP+title
	ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.replace(',',G9G0YqivIfmUWO8K)
	count = count.replace(',',G9G0YqivIfmUWO8K)
	count = oo9kuULlebNgpY0Om.findall('\d+',count)
	if count: count = count[0]
	else: count = G9G0YqivIfmUWO8K
	return True,title,Y6YdkAMluFbwx,M4qkBDatEIf3T,count,ii9h6QFxBUuCeqJODlfYmsI7ZT,DC1B9MOsWbnQ,ZWyp7eUvASuOQ3mk1qP,jJ1iOyvCtQxbFeK
def T2jLdkU8WXSJu(url,data=G9G0YqivIfmUWO8K,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	if A0AzrLupg8h1s==G9G0YqivIfmUWO8K: A0AzrLupg8h1s = 'ytInitialData'
	TkUSmDLJYy = uCUkPIYFszbV90wSpKqWNOjZ1687Eh()
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'User-Agent':TkUSmDLJYy,'Cookie':'PREF=hl=ar'}
	global amx9qJHkhw7oLdtVMG3
	if not data: data = amx9qJHkhw7oLdtVMG3.getSetting('av.youtube.data')
	if data.count(':::')==4: DQl8E4WI37SZgxtnhGusq1Ty5Um,key,mWizAL4cYpdNUq80M2BxyoJgl,X3JnOdYPmNk1aT0,jJ1iOyvCtQxbFeK = data.split(':::')
	else: DQl8E4WI37SZgxtnhGusq1Ty5Um,key,mWizAL4cYpdNUq80M2BxyoJgl,X3JnOdYPmNk1aT0,jJ1iOyvCtQxbFeK = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	pPIbdY3oKe = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":mWizAL4cYpdNUq80M2BxyoJgl}}}
	if url==ffVP3AK5RqhkgYnjZoNis+'/shorts' or '/my_main_page_shorts_link' in url:
		url = ffVP3AK5RqhkgYnjZoNis+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		pPIbdY3oKe['sequenceParams'] = DQl8E4WI37SZgxtnhGusq1Ty5Um
		pPIbdY3oKe = str(pPIbdY3oKe)
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',url,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = ffVP3AK5RqhkgYnjZoNis+'/youtubei/v1/guide?key='+key
		pPIbdY3oKe = str(pPIbdY3oKe)
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',url,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and DQl8E4WI37SZgxtnhGusq1Ty5Um:
		pPIbdY3oKe['continuation'] = jJ1iOyvCtQxbFeK
		pPIbdY3oKe['context']['client']['visitorData'] = DQl8E4WI37SZgxtnhGusq1Ty5Um
		pPIbdY3oKe = str(pPIbdY3oKe)
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',url,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and X3JnOdYPmNk1aT0:
		AAFEPhnMlsH5B3z0gYQWD4j7kUc.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':mWizAL4cYpdNUq80M2BxyoJgl})
		AAFEPhnMlsH5B3z0gYQWD4j7kUc.update({'Cookie':'VISITOR_INFO1_LIVE='+X3JnOdYPmNk1aT0})
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'YOUTUBE-GET_PAGE_DATA-6th')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('"innertubeApiKey".*?"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.I)
	if VwRHKuBk48UPEqnQsp: key = VwRHKuBk48UPEqnQsp[0]
	VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('"cver".*?"value".*?"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.I)
	if VwRHKuBk48UPEqnQsp: mWizAL4cYpdNUq80M2BxyoJgl = VwRHKuBk48UPEqnQsp[0]
	VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('"visitorData".*?"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.I)
	if VwRHKuBk48UPEqnQsp: DQl8E4WI37SZgxtnhGusq1Ty5Um = VwRHKuBk48UPEqnQsp[0]
	cookies = D7omduSeM5Gk.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): X3JnOdYPmNk1aT0 = cookies['VISITOR_INFO1_LIVE']
	cRx6fa73DukTQ0S9NemsizY1LvHCMI = DQl8E4WI37SZgxtnhGusq1Ty5Um+':::'+key+':::'+mWizAL4cYpdNUq80M2BxyoJgl+':::'+X3JnOdYPmNk1aT0+':::'+jJ1iOyvCtQxbFeK
	if A0AzrLupg8h1s=='ytInitialData' and 'ytInitialData' in GagwMT6q3oc7UZ2Q:
		PybdRoXZ61Afwsh5KtI4JS3iLkMB = oo9kuULlebNgpY0Om.findall('window\["ytInitialData"\] = ({.*?});',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not PybdRoXZ61Afwsh5KtI4JS3iLkMB: PybdRoXZ61Afwsh5KtI4JS3iLkMB = oo9kuULlebNgpY0Om.findall('var ytInitialData = ({.*?});',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		bCM8HZyKLlm = bRCSwcA89e4J7pqdays5PxGiD2('str',PybdRoXZ61Afwsh5KtI4JS3iLkMB[0])
	elif A0AzrLupg8h1s=='ytInitialGuideData' and 'ytInitialGuideData' in GagwMT6q3oc7UZ2Q:
		PybdRoXZ61Afwsh5KtI4JS3iLkMB = oo9kuULlebNgpY0Om.findall('var ytInitialGuideData = ({.*?});',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		bCM8HZyKLlm = bRCSwcA89e4J7pqdays5PxGiD2('str',PybdRoXZ61Afwsh5KtI4JS3iLkMB[0])
	elif '</script>' not in GagwMT6q3oc7UZ2Q: bCM8HZyKLlm = bRCSwcA89e4J7pqdays5PxGiD2('str',GagwMT6q3oc7UZ2Q)
	else: bCM8HZyKLlm = G9G0YqivIfmUWO8K
	if 0:
		JOnDaEjiAcKWXrsthC = str(bCM8HZyKLlm)
		if LTze51miOknVcslNF43WSA6vMjYZt: JOnDaEjiAcKWXrsthC = JOnDaEjiAcKWXrsthC.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open('S:\\0000emad.dat','wb').write(JOnDaEjiAcKWXrsthC)
	amx9qJHkhw7oLdtVMG3.setSetting('av.youtube.data',cRx6fa73DukTQ0S9NemsizY1LvHCMI)
	return GagwMT6q3oc7UZ2Q,bCM8HZyKLlm,cRx6fa73DukTQ0S9NemsizY1LvHCMI
def NSa42MzFeJcuV9qBdrH5PTw(url,iT2wOVymHEMAhWl6jbJs8pY):
	search = ZT7zGWSCtpvfmwMNRjYrKL()
	if not search: return
	search = search.replace(ww0sZkBU9JKd,'+')
	XXzvmn7ewM8yBfoxua = url+'/search?query='+search
	UUhwKBgI2nt(XXzvmn7ewM8yBfoxua,iT2wOVymHEMAhWl6jbJs8pY)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	search = search.replace(ww0sZkBU9JKd,'+')
	XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in EIcQfuLpMO2jX: p8HGRjUWKtNOngyeTDqCVZX0Jm6Q = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in EIcQfuLpMO2jX: p8HGRjUWKtNOngyeTDqCVZX0Jm6Q = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in EIcQfuLpMO2jX: p8HGRjUWKtNOngyeTDqCVZX0Jm6Q = '&sp=EgIQAg%253D%253D'
		else: p8HGRjUWKtNOngyeTDqCVZX0Jm6Q = G9G0YqivIfmUWO8K
		XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua+p8HGRjUWKtNOngyeTDqCVZX0Jm6Q
	else:
		gW0dOr4FsZnSQkht6cKpeqi9LvVYIm,Zhfz78KgCWV1,GS7Y93B0b8TLxueF = [],[],G9G0YqivIfmUWO8K
		ZMwUG7Joj43LIK9ENQqipm = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		AHDWqJv4nFzBxkRIPmZT7YcgG = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		b0HXEVYP6RmgN = wjrY1si9L6('اختر البحث المناسب',ZMwUG7Joj43LIK9ENQqipm)
		if b0HXEVYP6RmgN == -1: return
		WeE304APbX9coMVCp6 = AHDWqJv4nFzBxkRIPmZT7YcgG[b0HXEVYP6RmgN]
		GagwMT6q3oc7UZ2Q,uHjxYiJ58UOTDmMZEwz0sfR7kLSA,data = T2jLdkU8WXSJu(XXzvmn7ewM8yBfoxua+WeE304APbX9coMVCp6)
		if uHjxYiJ58UOTDmMZEwz0sfR7kLSA:
			try:
				hb2zi0PXn1Y = uHjxYiJ58UOTDmMZEwz0sfR7kLSA['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for QjW9tor7clLax80hvHRTCbM5d4 in range(len(hb2zi0PXn1Y)):
					group = hb2zi0PXn1Y[QjW9tor7clLax80hvHRTCbM5d4]['searchFilterGroupRenderer']['filters']
					for sRIHxA6JNqWnjDkbfhG in range(len(group)):
						xP4Vark5NIzuyRgDfsA7YwQ = group[sRIHxA6JNqWnjDkbfhG]['searchFilterRenderer']
						if 'navigationEndpoint' in list(xP4Vark5NIzuyRgDfsA7YwQ.keys()):
							Y6YdkAMluFbwx = xP4Vark5NIzuyRgDfsA7YwQ['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('\u0026','&')
							title = xP4Vark5NIzuyRgDfsA7YwQ['tooltip']
							title = title.replace('البحث عن ',G9G0YqivIfmUWO8K)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								GS7Y93B0b8TLxueF = title
								z7GYBmKiXwreV2QybCNn80v9pT = Y6YdkAMluFbwx
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',G9G0YqivIfmUWO8K)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								GS7Y93B0b8TLxueF = title
								z7GYBmKiXwreV2QybCNn80v9pT = Y6YdkAMluFbwx
							if 'Sort by' in title: continue
							gW0dOr4FsZnSQkht6cKpeqi9LvVYIm.append(zDBtm4MwIagkfcpE5oxJOAq6lZQY(title))
							Zhfz78KgCWV1.append(Y6YdkAMluFbwx)
			except: pass
		if not GS7Y93B0b8TLxueF: WC9tGnp7X51vej3uwLPBA = G9G0YqivIfmUWO8K
		else:
			gW0dOr4FsZnSQkht6cKpeqi9LvVYIm = ['بدون فلتر',GS7Y93B0b8TLxueF]+gW0dOr4FsZnSQkht6cKpeqi9LvVYIm
			Zhfz78KgCWV1 = [G9G0YqivIfmUWO8K,z7GYBmKiXwreV2QybCNn80v9pT]+Zhfz78KgCWV1
			pFkP7LqiUvfgsSe8lVOJXI1tKWoj = wjrY1si9L6('موقع يوتيوب - اختر الفلتر',gW0dOr4FsZnSQkht6cKpeqi9LvVYIm)
			if pFkP7LqiUvfgsSe8lVOJXI1tKWoj == -1: return
			WC9tGnp7X51vej3uwLPBA = Zhfz78KgCWV1[pFkP7LqiUvfgsSe8lVOJXI1tKWoj]
		if WC9tGnp7X51vej3uwLPBA: XjWHSnbf6NwhMgpKt4yLY7AkIT = ffVP3AK5RqhkgYnjZoNis+WC9tGnp7X51vej3uwLPBA
		elif WeE304APbX9coMVCp6: XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua+WeE304APbX9coMVCp6
		else: XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua
	UUhwKBgI2nt(XjWHSnbf6NwhMgpKt4yLY7AkIT)
	return
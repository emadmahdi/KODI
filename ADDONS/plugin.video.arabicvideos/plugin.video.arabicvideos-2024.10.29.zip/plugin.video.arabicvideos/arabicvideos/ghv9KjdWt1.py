# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'GOOGLESEARCH'
TdtCLWYSJNK8zOb = '_GOS_'
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs):
	if   Mauf6CrJjP87s==1010: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif Mauf6CrJjP87s==1011: tRojAyBgfDH37eLCwP4dWl = ZzXKNbBk1f807YnEMAhSa(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==1012: tRojAyBgfDH37eLCwP4dWl = VyBGDMOKfH2mXTAa(Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==1013: tRojAyBgfDH37eLCwP4dWl = YnZ043kfiRVGKT59FWdLBPS2q6J1lb()
	elif Mauf6CrJjP87s==1014: tRojAyBgfDH37eLCwP4dWl = wv2abGUzCy9AJnVQq7EmeYsSF(Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==1015: tRojAyBgfDH37eLCwP4dWl = S7OFqBVNu5LDCZ4WhGMk80npgU(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==1016: tRojAyBgfDH37eLCwP4dWl = S7T1lrYQfAb45vpCUe0JN8GimOFRE(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==1018: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(Vvju9Ht8SGxoiTa6lCs,-InpqoEf2WrlSe8)
	elif Mauf6CrJjP87s==1019: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(Vvju9Ht8SGxoiTa6lCs)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder','بحث جوجل جديد',G9G0YqivIfmUWO8K,1019)
	Qm8SMu6ecXtigDCWw1oak('link','كيف يعمل بحث جوجل','',1013)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'==== كلمات البحث المخزنة ===='+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	I57oUOlDXgzTmAui4HPtf9cY = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if I57oUOlDXgzTmAui4HPtf9cY:
		I57oUOlDXgzTmAui4HPtf9cY = I57oUOlDXgzTmAui4HPtf9cY['__SEQUENCED_COLUMNS__']
		for I47oPYM1VXxnt in reversed(I57oUOlDXgzTmAui4HPtf9cY):
			Qm8SMu6ecXtigDCWw1oak('folder',I47oPYM1VXxnt,G9G0YqivIfmUWO8K,1019,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,I47oPYM1VXxnt)
	return
def b6WZDnA0dLBiCITrF37OS(search,ffQUyobFxSM6m3l48ZcV9BILptk1=InpqoEf2WrlSe8):
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
		search = search.lower()
	srmO43LfnxajeDQPTzXI6gVvB = search.replace(TdtCLWYSJNK8zOb,G9G0YqivIfmUWO8K)
	wME0WAtrQ28db5vmK4osaD1 = []
	if ffQUyobFxSM6m3l48ZcV9BILptk1>0: wME0WAtrQ28db5vmK4osaD1 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GOOGLESEARCH_RESULTS',srmO43LfnxajeDQPTzXI6gVvB)
	if not wME0WAtrQ28db5vmK4osaD1 or ffQUyobFxSM6m3l48ZcV9BILptk1<0:
		lOaELZR2omtHwxAn = l3d2gewHba(search,ffQUyobFxSM6m3l48ZcV9BILptk1)
		XjczKJCetV6N5hyA,wApXd1IujQg = [],[]
		for XX2Btn97vEfkCjcuWs in lOaELZR2omtHwxAn:
			name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN = XX2Btn97vEfkCjcuWs
			if name==oob2dzmG3jTMpZwQyIfN: wApXd1IujQg.append(XX2Btn97vEfkCjcuWs)
			else: XjczKJCetV6N5hyA.append(XX2Btn97vEfkCjcuWs)
		import yJoXUw5pTK
		if ffQUyobFxSM6m3l48ZcV9BILptk1>=0: yJoXUw5pTK.ovAMa2fJgeKPBQpxVh(srmO43LfnxajeDQPTzXI6gVvB,'_GOOGLE',True)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'GOOGLESEARCH_RESULTS',srmO43LfnxajeDQPTzXI6gVvB,[XjczKJCetV6N5hyA,wApXd1IujQg],InpqoEf2WrlSe8)
		if ffQUyobFxSM6m3l48ZcV9BILptk1<0:
			aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DETAILED_GOOGLE',srmO43LfnxajeDQPTzXI6gVvB)
			yJoXUw5pTK.ovAMa2fJgeKPBQpxVh(srmO43LfnxajeDQPTzXI6gVvB,'_GOOGLE',False)
			aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+srmO43LfnxajeDQPTzXI6gVvB+"')")
			hbKFzulmsw4k('','','رسالة من المبرمج','تم عمل بحث جوجل جديد')
	Qm8SMu6ecXtigDCWw1oak('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('folder','بحث منفرد لمواقع جوجل',G9G0YqivIfmUWO8K,1011,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder','نتائج البحث مفصلة - '+srmO43LfnxajeDQPTzXI6gVvB,'opened_sites_google',1012,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('folder','نتائج البحث مقسمة - '+srmO43LfnxajeDQPTzXI6gVvB,'listed_sites_google',1012,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder','مواقع جوجل - '+srmO43LfnxajeDQPTzXI6gVvB,'',1016,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('link','إعادة بحث جوجل - '+srmO43LfnxajeDQPTzXI6gVvB,'',1018,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	return
def S7T1lrYQfAb45vpCUe0JN8GimOFRE(srmO43LfnxajeDQPTzXI6gVvB):
	XjczKJCetV6N5hyA,wApXd1IujQg = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GOOGLESEARCH_RESULTS',srmO43LfnxajeDQPTzXI6gVvB)
	XjczKJCetV6N5hyA = sorted(XjczKJCetV6N5hyA,reverse=kkMuQrLWcEayRm,key=lambda key: key[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	wME0WAtrQ28db5vmK4osaD1 = {}
	for name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN in XjczKJCetV6N5hyA: wME0WAtrQ28db5vmK4osaD1[oob2dzmG3jTMpZwQyIfN] = name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN
	ccDQeyqFsvw = list(wME0WAtrQ28db5vmK4osaD1.keys())
	import yJoXUw5pTK
	mYfR3VETgLzdCk2bU6 = yJoXUw5pTK.nu2WTZYIvOrHaERCXc7jispNyK(ccDQeyqFsvw)
	for oob2dzmG3jTMpZwQyIfN in mYfR3VETgLzdCk2bU6:
		if 'tuple' in str(type(oob2dzmG3jTMpZwQyIfN)):
			eANQpmZPJaI7wc8.append(oob2dzmG3jTMpZwQyIfN)
			continue
		name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN = wME0WAtrQ28db5vmK4osaD1[oob2dzmG3jTMpZwQyIfN]
		oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
		Qm8SMu6ecXtigDCWw1oak('folder',P8Pqs0UvEBg2AfmXDK6C+name,Y6YdkAMluFbwx,1014,uwtYA4XnVaxl,'',oob2dzmG3jTMpZwQyIfN)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'مواقع بجوجل غير موجودة بالبرنامج'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,1015)
	wApXd1IujQg = sorted(wApXd1IujQg,reverse=kkMuQrLWcEayRm,key=lambda key: key[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	for name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN in wApXd1IujQg:
		Qm8SMu6ecXtigDCWw1oak('link','_GOS_'+A7XhkmSYZlidyMt5FpWqTgjNezbnD+name+ww0sZkBU9JKd+zzGfwLAyN5HTxUoJeaivY,Y6YdkAMluFbwx,1015,uwtYA4XnVaxl,'',oob2dzmG3jTMpZwQyIfN)
	return
def VyBGDMOKfH2mXTAa(JJaOb15lYHUgtDcpdVS,srmO43LfnxajeDQPTzXI6gVvB):
	wME0WAtrQ28db5vmK4osaD1 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GOOGLESEARCH_RESULTS',srmO43LfnxajeDQPTzXI6gVvB)
	if not wME0WAtrQ28db5vmK4osaD1: return
	XjczKJCetV6N5hyA,wApXd1IujQg = wME0WAtrQ28db5vmK4osaD1
	LudWKUGrmhp4cYB6Qw5MfPJDt3,gudza5cKFL8Afs3OS = [],{}
	for name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN in XjczKJCetV6N5hyA:
		LudWKUGrmhp4cYB6Qw5MfPJDt3.append(oob2dzmG3jTMpZwQyIfN)
		gudza5cKFL8Afs3OS[oob2dzmG3jTMpZwQyIfN] = Rg6Fc2qdijomIT7lsEthAbZLPBrJ(title)
	import yJoXUw5pTK
	yJoXUw5pTK.E9fN0uclKIzSajYHmgv(srmO43LfnxajeDQPTzXI6gVvB,JJaOb15lYHUgtDcpdVS,G9G0YqivIfmUWO8K,LudWKUGrmhp4cYB6Qw5MfPJDt3,gudza5cKFL8Afs3OS)
	return
def ZzXKNbBk1f807YnEMAhSa(search):
	wME0WAtrQ28db5vmK4osaD1 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GOOGLESEARCH_RESULTS',search)
	if not wME0WAtrQ28db5vmK4osaD1: return
	XjczKJCetV6N5hyA,wApXd1IujQg = wME0WAtrQ28db5vmK4osaD1
	XjczKJCetV6N5hyA = sorted(XjczKJCetV6N5hyA,reverse=kkMuQrLWcEayRm,key=lambda key: key[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	wME0WAtrQ28db5vmK4osaD1 = {}
	for name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN in XjczKJCetV6N5hyA:
		wME0WAtrQ28db5vmK4osaD1[oob2dzmG3jTMpZwQyIfN] = name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN
	ccDQeyqFsvw = list(wME0WAtrQ28db5vmK4osaD1.keys())
	import yJoXUw5pTK
	mYfR3VETgLzdCk2bU6 = yJoXUw5pTK.nu2WTZYIvOrHaERCXc7jispNyK(ccDQeyqFsvw)
	for oob2dzmG3jTMpZwQyIfN in mYfR3VETgLzdCk2bU6:
		if 'tuple' in str(type(oob2dzmG3jTMpZwQyIfN)):
			eANQpmZPJaI7wc8.append(oob2dzmG3jTMpZwQyIfN)
			continue
		name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN = wME0WAtrQ28db5vmK4osaD1[oob2dzmG3jTMpZwQyIfN]
		oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
		title = Rg6Fc2qdijomIT7lsEthAbZLPBrJ(title)
		name = name+' - '+search
		Qm8SMu6ecXtigDCWw1oak('folder',P8Pqs0UvEBg2AfmXDK6C+name,oob2dzmG3jTMpZwQyIfN,548,uwtYA4XnVaxl,'',title)
	return
def Rg6Fc2qdijomIT7lsEthAbZLPBrJ(title):
	RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة)',title,oo9kuULlebNgpY0Om.DOTALL)
	GS7Y93B0b8TLxueF = RnV3EqPNpXTDuI7[0][0] if RnV3EqPNpXTDuI7 else title
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return GS7Y93B0b8TLxueF
def l3d2gewHba(search,ffQUyobFxSM6m3l48ZcV9BILptk1):
	search = search.replace(ww0sZkBU9JKd,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	D7omduSeM5Gk = PPRoOyl2xVH(ffQUyobFxSM6m3l48ZcV9BILptk1,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'GOOGLESEARCH-SEARCH-1st')
	j0a6zLsGrq8Ix5CSm7n4YA9BoWM,bhCpX42TK6VN = [],[]
	if not D7omduSeM5Gk.succeeded: return j0a6zLsGrq8Ix5CSm7n4YA9BoWM
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	XrhbE60f17 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ffDhnivjmRXeuHSIa1qEZNA,'googlesearch')
	if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(XrhbE60f17):
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.makedirs(XrhbE60f17)
		except: pass
	cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		BN1KdkzCmvshw = bRCSwcA89e4J7pqdays5PxGiD2('list',BN1KdkzCmvshw)
		Y6YdkAMluFbwx = BN1KdkzCmvshw[17]
		title,text,name,Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw[31][0:4]
		name = name.strip(' ')
		if not name: name = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
		name = jHk81i3RbxZ(name)
		if 'http://' in Vy1U0koJLPFhxe2TS or 'https://' in Vy1U0koJLPFhxe2TS: uwtYA4XnVaxl = Vy1U0koJLPFhxe2TS
		elif 'data:image/' in Vy1U0koJLPFhxe2TS and ';base64,' in Vy1U0koJLPFhxe2TS:
			oBcr0UWAdv72Mh4kzq8 = oo9kuULlebNgpY0Om.findall('data:image/(\w+);base64,',Vy1U0koJLPFhxe2TS)
			oBcr0UWAdv72Mh4kzq8 = oBcr0UWAdv72Mh4kzq8[0]
			uwtYA4XnVaxl = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(XrhbE60f17,name+'.'+oBcr0UWAdv72Mh4kzq8)
			if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(uwtYA4XnVaxl):
				Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.replace('\\u003d','=')
				Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.replace('data:image/'+oBcr0UWAdv72Mh4kzq8+';base64,','')
				sZczFdeEW3omXR5xNq6K = jaFsD83SB9ZQkrxeI.b64decode(Vy1U0koJLPFhxe2TS)
				open(uwtYA4XnVaxl,'wb').write(sZczFdeEW3omXR5xNq6K)
		else: uwtYA4XnVaxl = ''
		oob2dzmG3jTMpZwQyIfN = fiy1PUvLZD5Tc(name,Y6YdkAMluFbwx)
		if oob2dzmG3jTMpZwQyIfN not in bhCpX42TK6VN:
			bhCpX42TK6VN.append(oob2dzmG3jTMpZwQyIfN)
			name = GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN)
			j0a6zLsGrq8Ix5CSm7n4YA9BoWM.append([name,Y6YdkAMluFbwx,title,text,uwtYA4XnVaxl,oob2dzmG3jTMpZwQyIfN])
	return j0a6zLsGrq8Ix5CSm7n4YA9BoWM
def wv2abGUzCy9AJnVQq7EmeYsSF(Y6YdkAMluFbwx,oob2dzmG3jTMpZwQyIfN):
	oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
	if P8Pqs0UvEBg2AfmXDK6C: oyuFxk4Vew5cHP16()
	else: S7OFqBVNu5LDCZ4WhGMk80npgU()
	return
def YnZ043kfiRVGKT59FWdLBPS2q6J1lb():
	hbKFzulmsw4k('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def S7OFqBVNu5LDCZ4WhGMk80npgU(oob2dzmG3jTMpZwQyIfN=''):
	hbKFzulmsw4k('','',oob2dzmG3jTMpZwQyIfN,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def fiy1PUvLZD5Tc(name,Y6YdkAMluFbwx):
	vAFqdwunjc0R = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	mpniyIdLxTPW3BN8UcY2v = name.lower()
	hh2WobBZGFs5Lp0EjISNHfwdMkKv = ''
	for key in list(vAFqdwunjc0R.keys()):
		if key.lower() in mpniyIdLxTPW3BN8UcY2v: hh2WobBZGFs5Lp0EjISNHfwdMkKv = vAFqdwunjc0R[key]
	if not hh2WobBZGFs5Lp0EjISNHfwdMkKv:
		z7GYBmKiXwreV2QybCNn80v9pT = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'url')
		for oob2dzmG3jTMpZwQyIfN in list(Kkfl8xemuHbd1w3a0ABPcDrN.keys()):
			iSgUrJ1alz6hMnuPx8ekbQI7BLD = xWiOjcUrJVdtP4B5Iml(Kkfl8xemuHbd1w3a0ABPcDrN[oob2dzmG3jTMpZwQyIfN][0],'url')
			if z7GYBmKiXwreV2QybCNn80v9pT==iSgUrJ1alz6hMnuPx8ekbQI7BLD: hh2WobBZGFs5Lp0EjISNHfwdMkKv = oob2dzmG3jTMpZwQyIfN
	if not hh2WobBZGFs5Lp0EjISNHfwdMkKv:
		mpniyIdLxTPW3BN8UcY2v = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
		for oob2dzmG3jTMpZwQyIfN in list(Kkfl8xemuHbd1w3a0ABPcDrN.keys()):
			IJeNd3DL4Tb5h2m9i8p = xWiOjcUrJVdtP4B5Iml(Kkfl8xemuHbd1w3a0ABPcDrN[oob2dzmG3jTMpZwQyIfN][0],'name')
			if mpniyIdLxTPW3BN8UcY2v==IJeNd3DL4Tb5h2m9i8p: hh2WobBZGFs5Lp0EjISNHfwdMkKv = oob2dzmG3jTMpZwQyIfN
	if not hh2WobBZGFs5Lp0EjISNHfwdMkKv: hh2WobBZGFs5Lp0EjISNHfwdMkKv = name
	hh2WobBZGFs5Lp0EjISNHfwdMkKv = hh2WobBZGFs5Lp0EjISNHfwdMkKv.upper()
	return hh2WobBZGFs5Lp0EjISNHfwdMkKv
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SHAHIDNEWS'
TdtCLWYSJNK8zOb = '_SHN_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['قنوات فضائية','فارسكو','Show more']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==580: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==581: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==582: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==583: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url,text)
	elif mode==584: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==589: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHIDNEWS-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,589,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('/category.php">(.*?)"navslide-divider"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("'dropdown-menu'(.*?)</ul>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for duYhmVFABjltoJ9PcE in cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = BN1KdkzCmvshw.replace(duYhmVFABjltoJ9PcE,G9G0YqivIfmUWO8K)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,584)
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHIDNEWS-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"presentation"','</ul>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [(G9G0YqivIfmUWO8K,BN1KdkzCmvshw)]
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' فرز أو فلتر أو ترتيب '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for mX8PGEof4iCvtnYeT,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if mX8PGEof4iCvtnYeT: mX8PGEof4iCvtnYeT = mX8PGEof4iCvtnYeT+': '
			for Y6YdkAMluFbwx,title in items:
				title = mX8PGEof4iCvtnYeT+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,581)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"pm-category-subcats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)<30:
			Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			for Y6YdkAMluFbwx,title in items:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,581)
	if not kyoQ0h8lGBOW13cNvRqjDp and not msFSK7j9MrcoPafDnkNO: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHIDNEWS-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(data-echo=".*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"BlocksList"(.*?)"titleSectionCon"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="pm-grid"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="pm-related"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not items: items = oo9kuULlebNgpY0Om.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
		if 'http' not in M4qkBDatEIf3T: M4qkBDatEIf3T = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+M4qkBDatEIf3T.strip('/')
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,582,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'الحلقة' in title:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,583,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/movseries/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,581,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,583,M4qkBDatEIf3T)
	if A0AzrLupg8h1s not in ['featured_movies','featured_series']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,581)
		R67d0jkqLyfChz1PV = oo9kuULlebNgpY0Om.findall('showmore" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if R67d0jkqLyfChz1PV:
			Y6YdkAMluFbwx = R67d0jkqLyfChz1PV[0]
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مشاهدة المزيد',Y6YdkAMluFbwx,581)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url,JlwhosfkrT):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHIDNEWS-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('nav-seasons"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	items = []
	nfs7kxySvpQHP = False
	if kyoQ0h8lGBOW13cNvRqjDp and not JlwhosfkrT:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for JlwhosfkrT,title in items:
			JlwhosfkrT = JlwhosfkrT.strip('#')
			if len(items)>1: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,583,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,JlwhosfkrT)
			else: nfs7kxySvpQHP = True
	else: nfs7kxySvpQHP = True
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('id="'+JlwhosfkrT+'"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO and nfs7kxySvpQHP:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,582)
		else:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,582)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	ODnaR0N8UHv7Twy6jS = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHIDNEWS-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('"Playerholder".*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
	if Y6YdkAMluFbwx and 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
	hash = Y6YdkAMluFbwx.split('hash=')[1]
	mtMexSFLnkwhbAaP9pgDduCRBi2 = hash.split('__')
	HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8 = []
	for O40rBwVeybEYaR in mtMexSFLnkwhbAaP9pgDduCRBi2:
		try:
			O40rBwVeybEYaR = jaFsD83SB9ZQkrxeI.b64decode(O40rBwVeybEYaR+'=')
			if LTze51miOknVcslNF43WSA6vMjYZt: O40rBwVeybEYaR = O40rBwVeybEYaR.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8.append(O40rBwVeybEYaR)
		except: pass
	dsGzqX4k0a8RLyc = '>'.join(HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8)
	dsGzqX4k0a8RLyc = dsGzqX4k0a8RLyc.splitlines()
	if 'farsol' not in str(dsGzqX4k0a8RLyc):
		for Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
			if ' => ' in Y6YdkAMluFbwx:
				title,Y6YdkAMluFbwx = Y6YdkAMluFbwx.split(' => ')
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		import iOVAoxDJew
		iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	else:
		title,Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[0].split(' => ')
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+zEgtT9cR6bFp7JXqI5VuhNeP+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?keywords='+search
	UUhwKBgI2nt(url)
	return
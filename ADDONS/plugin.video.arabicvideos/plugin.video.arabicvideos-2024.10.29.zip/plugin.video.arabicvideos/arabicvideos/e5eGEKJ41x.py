﻿# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,ytKPSzFrncYI):
	if ytKPSzFrncYI==G9G0YqivIfmUWO8K: return
	if Mauf6CrJjP87s==1:
		JJO5kzfVjQY7ZyEFd68tKgrLUboDPS = tDG1bZwX86UPjWEoVOJ.getCurrentWindowDialogId()
		vjBym4Uf38PAcFLwoDhItd6pgY = tDG1bZwX86UPjWEoVOJ.Window(JJO5kzfVjQY7ZyEFd68tKgrLUboDPS)
		ytKPSzFrncYI = cpsXCrtE94DfY51mS(ytKPSzFrncYI)
		vjBym4Uf38PAcFLwoDhItd6pgY.getControl(311).setLabel(ytKPSzFrncYI)
	if Mauf6CrJjP87s==0:
		C9uTVdSkLlb5UemavyB6NjWHFh='X'
		if LTze51miOknVcslNF43WSA6vMjYZt: P6zsDLBtv2Rc = isinstance(ytKPSzFrncYI,str)
		else: P6zsDLBtv2Rc = isinstance(ytKPSzFrncYI,unicode)
		if P6zsDLBtv2Rc==True: C9uTVdSkLlb5UemavyB6NjWHFh='U'
		kBMvpz2s3ra1qPU0ewynmJ5fTiNI=str(type(ytKPSzFrncYI))+ww0sZkBU9JKd+ytKPSzFrncYI+ww0sZkBU9JKd+C9uTVdSkLlb5UemavyB6NjWHFh+ww0sZkBU9JKd
		for KT9tdUH3hmiLZCEFz in range(0,len(ytKPSzFrncYI),1):
			kBMvpz2s3ra1qPU0ewynmJ5fTiNI += hex(ord(ytKPSzFrncYI[KT9tdUH3hmiLZCEFz])).replace('0x',G9G0YqivIfmUWO8K)+ww0sZkBU9JKd
		ytKPSzFrncYI = cpsXCrtE94DfY51mS(ytKPSzFrncYI)
		C9uTVdSkLlb5UemavyB6NjWHFh='X'
		if LTze51miOknVcslNF43WSA6vMjYZt: P6zsDLBtv2Rc = isinstance(ytKPSzFrncYI, str)
		else: P6zsDLBtv2Rc = isinstance(ytKPSzFrncYI, unicode)
		if P6zsDLBtv2Rc==True: C9uTVdSkLlb5UemavyB6NjWHFh='U'
		ARmeHihgBCIXP6NGOxs431p=str(type(ytKPSzFrncYI))+ww0sZkBU9JKd+ytKPSzFrncYI+ww0sZkBU9JKd+C9uTVdSkLlb5UemavyB6NjWHFh+ww0sZkBU9JKd
		for KT9tdUH3hmiLZCEFz in range(0,len(ytKPSzFrncYI),1):
			ARmeHihgBCIXP6NGOxs431p += hex(ord(ytKPSzFrncYI[KT9tdUH3hmiLZCEFz])).replace('0x',G9G0YqivIfmUWO8K)+ww0sZkBU9JKd
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
s5slfAmHkUtMR3WSKY1ZTX = 'AKWAM'
TdtCLWYSJNK8zOb = '_AKW_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
rFxmB0jXJ1vLCiRlTe7N6EaZszwW4P = G9G0YqivIfmUWO8K
tlcXBJEfIHF02vQ6yxSom9z1 = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==240: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==241: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==242: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==243: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==244: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'FILTERS___'+text)
	elif mode==245: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'CATEGORIES___'+text)
	elif mode==246: tRojAyBgfDH37eLCwP4dWl = SpaW1UvBctG9wshiRHmYf4Cgrznob(url)
	elif mode==247: tRojAyBgfDH37eLCwP4dWl = kWNeG6A4xP8cdOBj1Xv(url)
	elif mode==248: tRojAyBgfDH37eLCwP4dWl = znvTCfGP8WIyYJo()
	elif mode==249: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def znvTCfGP8WIyYJo():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'AKWAM-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	grFEjPTV4JWxbLkO = oo9kuULlebNgpY0Om.findall('home-site-btn-container.*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if grFEjPTV4JWxbLkO: grFEjPTV4JWxbLkO = grFEjPTV4JWxbLkO[0]
	else: grFEjPTV4JWxbLkO = ffVP3AK5RqhkgYnjZoNis
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',grFEjPTV4JWxbLkO,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'AKWAM-MENU-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,249,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',ffVP3AK5RqhkgYnjZoNis,246)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',ffVP3AK5RqhkgYnjZoNis,247)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المميزة',grFEjPTV4JWxbLkO,241,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	recent = oo9kuULlebNgpY0Om.findall('recently-container.*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Y6YdkAMluFbwx = recent[0]
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أضيف حديثا',Y6YdkAMluFbwx,241)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,name,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
		if name in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,241)
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			title = name+ww0sZkBU9JKd+title
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,241)
	return
def SpaW1UvBctG9wshiRHmYf4Cgrznob(website=G9G0YqivIfmUWO8K):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'AKWAM-MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="menu(.*?)<nav',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?text">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title not in tlcXBJEfIHF02vQ6yxSom9z1:
				title = title+' مصنفة'
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,245)
		if website==G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	return GagwMT6q3oc7UZ2Q
def kWNeG6A4xP8cdOBj1Xv(website=G9G0YqivIfmUWO8K):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'AKWAM-MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="menu(.*?)<nav',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?text">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title not in tlcXBJEfIHF02vQ6yxSom9z1:
				title = title+' مفلترة'
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,244)
		if website==G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('swiper-container(.*?)swiper-button-prev',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="widget"(.*?)main-footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not items:
			items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
			if '/series/' in Y6YdkAMluFbwx or '/shows/' in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,242,M4qkBDatEIf3T)
			elif '/movies/' in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,243,M4qkBDatEIf3T)
			elif '/games/' not in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,243,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			Y6YdkAMluFbwx = kD2wGe8Oh4T7Cj3BMsy0(Y6YdkAMluFbwx)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,241)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'%20')
	url = ffVP3AK5RqhkgYnjZoNis + '/search?q='+HG9ZQqnw71y0JmrDLx
	tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in GagwMT6q3oc7UZ2Q:
		M4qkBDatEIf3T = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Icon')
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+'رابط التشغيل',url,243,M4qkBDatEIf3T)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('-episodes">(.*?)<div class="widget-4',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		GOQI6tW4xVh8NYwdPqMD9Kg = oo9kuULlebNgpY0Om.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in GOQI6tW4xVh8NYwdPqMD9Kg:
			title = title.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,242,M4qkBDatEIf3T)
			else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,243,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,True,'AKWAM-PLAY-1st')
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('badge-danger.*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	eCvsoQmbGgFIRp2y = oo9kuULlebNgpY0Om.findall('li><a href="#(.*?)".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,cUE5uH8hAtOmTp,tXaE8rSPFDosBh = [],[],[],[]
	if eCvsoQmbGgFIRp2y:
		FF94GpU6MrbZy = 'mp4'
		for zNhFDfBUQcjOProqaH5bwxMS36WEe,I5chimw4D1okfxlBE2UpbuHJvStsZ in eCvsoQmbGgFIRp2y:
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('tab-content quality" id="'+zNhFDfBUQcjOProqaH5bwxMS36WEe+'".*?</div>.\s*</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			cUE5uH8hAtOmTp.append(BN1KdkzCmvshw)
			tXaE8rSPFDosBh.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="qualities(.*?)<h3.*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			BN1KdkzCmvshw,filename = cSLKDEATk7y10ovtGZCwF[0]
			NAUjQiCGnldJDeyw0Psz4572 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			FF94GpU6MrbZy = filename.rsplit('.',1)[1].strip(ww0sZkBU9JKd)
			if FF94GpU6MrbZy in NAUjQiCGnldJDeyw0Psz4572:
				hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		cUE5uH8hAtOmTp.append(BN1KdkzCmvshw)
		tXaE8rSPFDosBh.append(G9G0YqivIfmUWO8K)
	for KT9tdUH3hmiLZCEFz in range(len(cUE5uH8hAtOmTp)):
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?icon-(.*?)"',cUE5uH8hAtOmTp[KT9tdUH3hmiLZCEFz],oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,zJheCUrcQMt0HGYZ34Nmu657 in dsGzqX4k0a8RLyc:
			if 'torrent' in zJheCUrcQMt0HGYZ34Nmu657: continue
			elif 'download' in zJheCUrcQMt0HGYZ34Nmu657: type = 'download'
			elif 'play' in zJheCUrcQMt0HGYZ34Nmu657: type = 'watch'
			else: type = 'unknown'
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named=__'+type+'____'+tXaE8rSPFDosBh[KT9tdUH3hmiLZCEFz]+'__akwam'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	IzbOhN0Flo8j4gtdcVewMB = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='CATEGORIES':
		if IzbOhN0Flo8j4gtdcVewMB[0]+'=' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[0]
		for KT9tdUH3hmiLZCEFz in range(len(IzbOhN0Flo8j4gtdcVewMB[0:-1])):
			if IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz]+'=' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'all')
		XXzvmn7ewM8yBfoxua = url+'?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='FILTERS':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'all')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'?'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها',XXzvmn7ewM8yBfoxua,241,G9G0YqivIfmUWO8K,'1')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',XXzvmn7ewM8yBfoxua,241,G9G0YqivIfmUWO8K,'1')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,True,'AKWAM-FILTERS_MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<form id(.*?)</form>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	dict = {}
	for TaVcxgUOBpSwX6Rl9PYkzeudt1,name,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		items = oo9kuULlebNgpY0Om.findall('<option(.*?)>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if '=' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='CATEGORIES':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<=1:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: UUhwKBgI2nt(XXzvmn7ewM8yBfoxua)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'CATEGORIES___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,241,G9G0YqivIfmUWO8K,'1')
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,245,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='FILTERS':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع : '+name,XXzvmn7ewM8yBfoxua,244,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			if 'value' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = M0nQuWoaIxhSdqyV9N
			else: yW70dtahIjkPCJg2TA = oo9kuULlebNgpY0Om.findall('"(.*?)"',yW70dtahIjkPCJg2TA,oo9kuULlebNgpY0Om.DOTALL)[0]
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = M0nQuWoaIxhSdqyV9N
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+M0nQuWoaIxhSdqyV9N
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			title = M0nQuWoaIxhSdqyV9N+' : '#+dict[TaVcxgUOBpSwX6Rl9PYkzeudt1]['0']
			title = M0nQuWoaIxhSdqyV9N+' : '+name
			if type=='FILTERS': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,244,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='CATEGORIES' and IzbOhN0Flo8j4gtdcVewMB[-2]+'=' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'all')
				XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,XjWHSnbf6NwhMgpKt4yLY7AkIT,241,G9G0YqivIfmUWO8K,'1')
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,245,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&')
	R9h6MqBxlsEpNztI0AU = {}
	if '=' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('=')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = G9G0YqivIfmUWO8K
	KH5NQOvAkRje = ['section','category','rating','year','language','formats','quality']
	for key in KH5NQOvAkRje:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&')
	return lOaCfpSNzejn
﻿# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ALMAAREF'
headers = {'User-Agent':G9G0YqivIfmUWO8K}
TdtCLWYSJNK8zOb = '_MRF_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def RAndFk3y4Pbvs29(mode,url,text,eehFlSEjHioyAWpLqZXt79):
	if   mode==40: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==41: tRojAyBgfDH37eLCwP4dWl = ooMbFZDa6xRHXp()
	elif mode==42: tRojAyBgfDH37eLCwP4dWl = c7JsEZ1AGRnNkCphDvTyz4LiVfF(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==43: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==44: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==49: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,49)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'البث الحي لقناة المعارف',G9G0YqivIfmUWO8K,41)
	c7JsEZ1AGRnNkCphDvTyz4LiVfF(G9G0YqivIfmUWO8K,'1')
	return
def vvo9iWeUmwBJkadbFHj0cntpGy(EIcQfuLpMO2jX,fg5osvEJ9eBZpwkl4S):
	search,sort,TLEKHoau3C7xrVOi0,nxguK9laUWBGHIR4zEsTo7,m5TAdiEk0bnwcZXI49YWJ = G9G0YqivIfmUWO8K,[],[],[],[]
	HHFwtdVPy2OZ,yIvTHJBm5Znrkq0waKpeg = uNeAyo6mgQTwGtDFhfcU5ZasI(EIcQfuLpMO2jX)
	for M0nQuWoaIxhSdqyV9N in list(yIvTHJBm5Znrkq0waKpeg.keys()):
		yW70dtahIjkPCJg2TA = yIvTHJBm5Znrkq0waKpeg[M0nQuWoaIxhSdqyV9N]
		if not yW70dtahIjkPCJg2TA: continue
		if   M0nQuWoaIxhSdqyV9N=='sort': sort = [yW70dtahIjkPCJg2TA]
		elif M0nQuWoaIxhSdqyV9N=='series': TLEKHoau3C7xrVOi0 = [yW70dtahIjkPCJg2TA]
		elif M0nQuWoaIxhSdqyV9N=='search': search = yW70dtahIjkPCJg2TA
		elif M0nQuWoaIxhSdqyV9N=='category': nxguK9laUWBGHIR4zEsTo7 = [yW70dtahIjkPCJg2TA]
		elif M0nQuWoaIxhSdqyV9N=='specialist': m5TAdiEk0bnwcZXI49YWJ = [yW70dtahIjkPCJg2TA]
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":nxguK9laUWBGHIR4zEsTo7,"specialist":m5TAdiEk0bnwcZXI49YWJ,"series":TLEKHoau3C7xrVOi0,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(fg5osvEJ9eBZpwkl4S)}}
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = EEMsy4SLwnD0T92ztchdIUZ.dumps(QKsd6VmaOnMPCWuqcTyl28JZH7ASjo)
	Y6YdkAMluFbwx = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',Y6YdkAMluFbwx,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	data = bRCSwcA89e4J7pqdays5PxGiD2('dict',GagwMT6q3oc7UZ2Q)
	return data
def c7JsEZ1AGRnNkCphDvTyz4LiVfF(EIcQfuLpMO2jX,level):
	cUE5uH8hAtOmTp = vvo9iWeUmwBJkadbFHj0cntpGy(EIcQfuLpMO2jX,'1')
	BN1KdkzCmvshw = cUE5uH8hAtOmTp['facets']
	if level=='1':
		BN1KdkzCmvshw = BN1KdkzCmvshw['video_categories']
		items = oo9kuULlebNgpY0Om.findall('<div(.*?)/div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for XX2Btn97vEfkCjcuWs in items:
			VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',XX2Btn97vEfkCjcuWs+'<',oo9kuULlebNgpY0Om.DOTALL)
			if not VwRHKuBk48UPEqnQsp: VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('data-value=\\"(.*?)\\">(.*?)<',XX2Btn97vEfkCjcuWs+'<',oo9kuULlebNgpY0Om.DOTALL)
			nxguK9laUWBGHIR4zEsTo7,title = VwRHKuBk48UPEqnQsp[0]
			if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			if not EIcQfuLpMO2jX: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,42,G9G0YqivIfmUWO8K,'2','?category='+nxguK9laUWBGHIR4zEsTo7)
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,42,G9G0YqivIfmUWO8K,'2',EIcQfuLpMO2jX+'&category='+nxguK9laUWBGHIR4zEsTo7)
	if level=='2':
		BN1KdkzCmvshw = BN1KdkzCmvshw['specialist']
		items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for m5TAdiEk0bnwcZXI49YWJ,title in items:
			if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			if not m5TAdiEk0bnwcZXI49YWJ: title = title = 'الجميع'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,42,G9G0YqivIfmUWO8K,'3',EIcQfuLpMO2jX+'&specialist='+m5TAdiEk0bnwcZXI49YWJ)
	elif level=='3':
		BN1KdkzCmvshw = BN1KdkzCmvshw['series']
		items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for TLEKHoau3C7xrVOi0,title in items:
			if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			if not TLEKHoau3C7xrVOi0: title = title = 'الجميع'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,42,G9G0YqivIfmUWO8K,'4',EIcQfuLpMO2jX+'&series='+TLEKHoau3C7xrVOi0)
	elif level=='4':
		BN1KdkzCmvshw = BN1KdkzCmvshw['sort_video']
		items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for sort,title in items:
			if not sort: continue
			if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,44,G9G0YqivIfmUWO8K,'1',EIcQfuLpMO2jX+'&sort='+sort)
	return
def UUhwKBgI2nt(EIcQfuLpMO2jX,fg5osvEJ9eBZpwkl4S):
	cUE5uH8hAtOmTp = vvo9iWeUmwBJkadbFHj0cntpGy(EIcQfuLpMO2jX,fg5osvEJ9eBZpwkl4S)
	BN1KdkzCmvshw = cUE5uH8hAtOmTp['template']
	items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,43,M4qkBDatEIf3T)
	BN1KdkzCmvshw = cUE5uH8hAtOmTp['facets']['pagination']
	items = oo9kuULlebNgpY0Om.findall('data-page="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for eehFlSEjHioyAWpLqZXt79,title in items:
		if fg5osvEJ9eBZpwkl4S==eehFlSEjHioyAWpLqZXt79: continue
		if gA0m6CQUyfLG: title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,G9G0YqivIfmUWO8K,44,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,EIcQfuLpMO2jX)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ALMAAREF-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<video src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('youtube_url.*?(http.*?)&',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0].replace('\/','/')
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def ooMbFZDa6xRHXp():
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/بث-مباشر',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ALMAAREF-LIVE-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	url = oo9kuULlebNgpY0Om.findall('"svpPlayer".*?(http.*?)&',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	url = url[0].replace('\\',G9G0YqivIfmUWO8K)
	Imphr8LRTUDs(url,s5slfAmHkUtMR3WSKY1ZTX,'live')
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	VUsS35rAeXjPg24Q19oDYMOwupxL = False
	if search==G9G0YqivIfmUWO8K:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		VUsS35rAeXjPg24Q19oDYMOwupxL = True
	if search==G9G0YqivIfmUWO8K: return
	if not VUsS35rAeXjPg24Q19oDYMOwupxL: UUhwKBgI2nt('?search='+search,'1')
	else: c7JsEZ1AGRnNkCphDvTyz4LiVfF('?search='+search,'1')
	return
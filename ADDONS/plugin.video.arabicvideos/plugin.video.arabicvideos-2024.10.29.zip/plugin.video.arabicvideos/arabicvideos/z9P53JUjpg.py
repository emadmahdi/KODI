# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
v1NALptEHU = 'FAVORITES'
def PPFx0TCKwf(Mauf6CrJjP87s,vXgVBD5Q0LoPmYlG69e4qxRyc):
	if   Mauf6CrJjP87s==270: kqe8AmaJG6pIvUCPSXb = fo3aZrpvQn248jXK9CY05DGx(vXgVBD5Q0LoPmYlG69e4qxRyc)
	else: kqe8AmaJG6pIvUCPSXb = False
	return kqe8AmaJG6pIvUCPSXb
def hKY8iAO7a62IpoM(mUTXiaBzJf2utgY3KFIQl,vXgVBD5Q0LoPmYlG69e4qxRyc,lUTJCsERQcrtZX):
	if not mUTXiaBzJf2utgY3KFIQl: return
	if   lUTJCsERQcrtZX=='UP1'	: NL80sBEw93TIAhWud(vXgVBD5Q0LoPmYlG69e4qxRyc,True,fdQOo6Hu4B5Rbg)
	elif lUTJCsERQcrtZX=='DOWN1'	: NL80sBEw93TIAhWud(vXgVBD5Q0LoPmYlG69e4qxRyc,False,fdQOo6Hu4B5Rbg)
	elif lUTJCsERQcrtZX=='UP4'	: NL80sBEw93TIAhWud(vXgVBD5Q0LoPmYlG69e4qxRyc,True,xsCEkXb6tgrh3195YZ)
	elif lUTJCsERQcrtZX=='DOWN4'	: NL80sBEw93TIAhWud(vXgVBD5Q0LoPmYlG69e4qxRyc,False,xsCEkXb6tgrh3195YZ)
	elif lUTJCsERQcrtZX=='ADD1'	: OU3AuMZxqpFs5RbV6XYy(vXgVBD5Q0LoPmYlG69e4qxRyc)
	elif lUTJCsERQcrtZX=='REMOVE1': HVuxqy7p5FTJOXY0KPtwf4kehgj(vXgVBD5Q0LoPmYlG69e4qxRyc)
	elif lUTJCsERQcrtZX=='DELETELIST': VRnWstNw0Eh4(vXgVBD5Q0LoPmYlG69e4qxRyc)
	return
def fo3aZrpvQn248jXK9CY05DGx(vXgVBD5Q0LoPmYlG69e4qxRyc):
	DHNaSJAvwIOgGuPCFd1MEiQm = yEBVNehOAP8abZcHvLjzigr0s()
	if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
		try:
			dt38oY9s7mjgNyBGPHEibAxkcXLV = DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]
			if dQ5JhEYolPmy1fvHktMw6NFRxiz and vXgVBD5Q0LoPmYlG69e4qxRyc in ['5','11','12','13']:
				for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge in dt38oY9s7mjgNyBGPHEibAxkcXLV:
					if Um2ITJ1iLnEjqZevskVt06NY34=='video':
						Qm8SMu6ecXtigDCWw1oak('video',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'تشغيل من الأعلى إلى الأسفل'+zzGfwLAyN5HTxUoJeaivY,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl)
						Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
						break
			for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge in dt38oY9s7mjgNyBGPHEibAxkcXLV:
				Qm8SMu6ecXtigDCWw1oak(Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge)
		except:
			DHNaSJAvwIOgGuPCFd1MEiQm = yBxCaXY5UwkD(Mh2XHLxaCsToiUFymceOGKS)
			dt38oY9s7mjgNyBGPHEibAxkcXLV = DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]
			for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge in dt38oY9s7mjgNyBGPHEibAxkcXLV:
				Qm8SMu6ecXtigDCWw1oak(Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge)
	return
def OU3AuMZxqpFs5RbV6XYy(vXgVBD5Q0LoPmYlG69e4qxRyc):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	if vXgVBD5Q0LoPmYlG69e4qxRyc in ['5','11','12','13'] and Um2ITJ1iLnEjqZevskVt06NY34!='video':
		hbKFzulmsw4k('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	NTRtuJQvWLmGwoSe0fghq6UIZxrCX = Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,wyMiO0VErpqda2hH5cRge
	DHNaSJAvwIOgGuPCFd1MEiQm = yEBVNehOAP8abZcHvLjzigr0s()
	JSwv5A2Fj0 = {}
	for laRp9WZi3G6E2vAorMwgNPhctYj in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
		if laRp9WZi3G6E2vAorMwgNPhctYj!=vXgVBD5Q0LoPmYlG69e4qxRyc: JSwv5A2Fj0[laRp9WZi3G6E2vAorMwgNPhctYj] = DHNaSJAvwIOgGuPCFd1MEiQm[laRp9WZi3G6E2vAorMwgNPhctYj]
		else:
			if YwC7jt5BQHhTUvbdGeM6f2ZLx and YwC7jt5BQHhTUvbdGeM6f2ZLx!='..':
				qLiRSV1Mg8DX4r6flEBvZtU25b = DHNaSJAvwIOgGuPCFd1MEiQm[laRp9WZi3G6E2vAorMwgNPhctYj]
				if NTRtuJQvWLmGwoSe0fghq6UIZxrCX in qLiRSV1Mg8DX4r6flEBvZtU25b:
					c8qyCWkoKInXY = qLiRSV1Mg8DX4r6flEBvZtU25b.index(NTRtuJQvWLmGwoSe0fghq6UIZxrCX)
					del qLiRSV1Mg8DX4r6flEBvZtU25b[c8qyCWkoKInXY]
				GAgvjRct0NaQbTMqCE7PF = qLiRSV1Mg8DX4r6flEBvZtU25b+[NTRtuJQvWLmGwoSe0fghq6UIZxrCX]
				JSwv5A2Fj0[laRp9WZi3G6E2vAorMwgNPhctYj] = GAgvjRct0NaQbTMqCE7PF
			else: JSwv5A2Fj0[laRp9WZi3G6E2vAorMwgNPhctYj] = DHNaSJAvwIOgGuPCFd1MEiQm[laRp9WZi3G6E2vAorMwgNPhctYj]
	if vXgVBD5Q0LoPmYlG69e4qxRyc not in list(JSwv5A2Fj0.keys()): JSwv5A2Fj0[vXgVBD5Q0LoPmYlG69e4qxRyc] = [NTRtuJQvWLmGwoSe0fghq6UIZxrCX]
	RPmHzT1kr2QbZLOc9J = str(JSwv5A2Fj0)
	if LTze51miOknVcslNF43WSA6vMjYZt: RPmHzT1kr2QbZLOc9J = RPmHzT1kr2QbZLOc9J.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	open(Mh2XHLxaCsToiUFymceOGKS,'wb').write(RPmHzT1kr2QbZLOc9J)
	return
def HVuxqy7p5FTJOXY0KPtwf4kehgj(vXgVBD5Q0LoPmYlG69e4qxRyc):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	NTRtuJQvWLmGwoSe0fghq6UIZxrCX = Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,wyMiO0VErpqda2hH5cRge
	DHNaSJAvwIOgGuPCFd1MEiQm = yEBVNehOAP8abZcHvLjzigr0s()
	if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()) and NTRtuJQvWLmGwoSe0fghq6UIZxrCX in DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]:
		DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc].remove(NTRtuJQvWLmGwoSe0fghq6UIZxrCX)
		if len(DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc])==dQ5JhEYolPmy1fvHktMw6NFRxiz: del DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]
		RPmHzT1kr2QbZLOc9J = str(DHNaSJAvwIOgGuPCFd1MEiQm)
		if LTze51miOknVcslNF43WSA6vMjYZt: RPmHzT1kr2QbZLOc9J = RPmHzT1kr2QbZLOc9J.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open(Mh2XHLxaCsToiUFymceOGKS,'wb').write(RPmHzT1kr2QbZLOc9J)
	return
def NL80sBEw93TIAhWud(vXgVBD5Q0LoPmYlG69e4qxRyc,rgPpWQEzwdjGfx9oHAX628OkDc,K3bk0tXqeW):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	NTRtuJQvWLmGwoSe0fghq6UIZxrCX = Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,wyMiO0VErpqda2hH5cRge
	DHNaSJAvwIOgGuPCFd1MEiQm = yEBVNehOAP8abZcHvLjzigr0s()
	if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
		qLiRSV1Mg8DX4r6flEBvZtU25b = DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]
		if NTRtuJQvWLmGwoSe0fghq6UIZxrCX not in qLiRSV1Mg8DX4r6flEBvZtU25b: return
		e9I2TbwEJYNMg5Bav8tFVGx = len(qLiRSV1Mg8DX4r6flEBvZtU25b)
		for KJZlbgk2TdD5GWQFqucMP in range(dQ5JhEYolPmy1fvHktMw6NFRxiz,K3bk0tXqeW):
			Jbun7MWzZs = qLiRSV1Mg8DX4r6flEBvZtU25b.index(NTRtuJQvWLmGwoSe0fghq6UIZxrCX)
			if rgPpWQEzwdjGfx9oHAX628OkDc: gW0f451Y6MTNaGXDPFeoS = Jbun7MWzZs-fdQOo6Hu4B5Rbg
			else: gW0f451Y6MTNaGXDPFeoS = Jbun7MWzZs+fdQOo6Hu4B5Rbg
			if gW0f451Y6MTNaGXDPFeoS>=e9I2TbwEJYNMg5Bav8tFVGx: gW0f451Y6MTNaGXDPFeoS = gW0f451Y6MTNaGXDPFeoS-e9I2TbwEJYNMg5Bav8tFVGx
			if gW0f451Y6MTNaGXDPFeoS<dQ5JhEYolPmy1fvHktMw6NFRxiz: gW0f451Y6MTNaGXDPFeoS = gW0f451Y6MTNaGXDPFeoS+e9I2TbwEJYNMg5Bav8tFVGx
			qLiRSV1Mg8DX4r6flEBvZtU25b.insert(gW0f451Y6MTNaGXDPFeoS, qLiRSV1Mg8DX4r6flEBvZtU25b.pop(Jbun7MWzZs))
		DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc] = qLiRSV1Mg8DX4r6flEBvZtU25b
		RPmHzT1kr2QbZLOc9J = str(DHNaSJAvwIOgGuPCFd1MEiQm)
		if LTze51miOknVcslNF43WSA6vMjYZt: RPmHzT1kr2QbZLOc9J = RPmHzT1kr2QbZLOc9J.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open(Mh2XHLxaCsToiUFymceOGKS,'wb').write(RPmHzT1kr2QbZLOc9J)
	return
def rrI04mHTNsXO9dQFpWqMGgvhk7DJjZ(vXgVBD5Q0LoPmYlG69e4qxRyc):
	if vXgVBD5Q0LoPmYlG69e4qxRyc in ['1','2','3','4']: F4697cAuQfo,Tvwm78jJYd4oE = 'مفضلة',vXgVBD5Q0LoPmYlG69e4qxRyc
	elif vXgVBD5Q0LoPmYlG69e4qxRyc in ['5']: F4697cAuQfo,Tvwm78jJYd4oE = 'تشغيل','1'
	elif vXgVBD5Q0LoPmYlG69e4qxRyc in ['11']: F4697cAuQfo,Tvwm78jJYd4oE = 'تشغيل','2'
	else: F4697cAuQfo,Tvwm78jJYd4oE = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	AQhF132wENxPTHebZVoD8B7 = F4697cAuQfo+ww0sZkBU9JKd+Tvwm78jJYd4oE
	return AQhF132wENxPTHebZVoD8B7
def VRnWstNw0Eh4(vXgVBD5Q0LoPmYlG69e4qxRyc):
	AQhF132wENxPTHebZVoD8B7 = rrI04mHTNsXO9dQFpWqMGgvhk7DJjZ(vXgVBD5Q0LoPmYlG69e4qxRyc)
	KKrj6Fkd5Tgv9ImSAGyaEeLcipt = xNVJH71kmLUIy3CjS9TDBQoYu5('center',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+AQhF132wENxPTHebZVoD8B7+' ؟!')
	if KKrj6Fkd5Tgv9ImSAGyaEeLcipt!=1: return
	DHNaSJAvwIOgGuPCFd1MEiQm = yEBVNehOAP8abZcHvLjzigr0s()
	if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
		del DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]
		RPmHzT1kr2QbZLOc9J = str(DHNaSJAvwIOgGuPCFd1MEiQm)
		if LTze51miOknVcslNF43WSA6vMjYZt: RPmHzT1kr2QbZLOc9J = RPmHzT1kr2QbZLOc9J.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open(Mh2XHLxaCsToiUFymceOGKS,'wb').write(RPmHzT1kr2QbZLOc9J)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+AQhF132wENxPTHebZVoD8B7)
	return
def yEBVNehOAP8abZcHvLjzigr0s():
	DHNaSJAvwIOgGuPCFd1MEiQm = {}
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(Mh2XHLxaCsToiUFymceOGKS):
		ttUilEMQav9PARNgY3HSOrs2kK = open(Mh2XHLxaCsToiUFymceOGKS,'rb').read()
		if LTze51miOknVcslNF43WSA6vMjYZt: ttUilEMQav9PARNgY3HSOrs2kK = ttUilEMQav9PARNgY3HSOrs2kK.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		DHNaSJAvwIOgGuPCFd1MEiQm = bRCSwcA89e4J7pqdays5PxGiD2('dict',ttUilEMQav9PARNgY3HSOrs2kK)
	return DHNaSJAvwIOgGuPCFd1MEiQm
def E53xQykpKhNU61IqmbulZSJs7iLfc(DHNaSJAvwIOgGuPCFd1MEiQm,NTRtuJQvWLmGwoSe0fghq6UIZxrCX,JRoDl1LwSb):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = NTRtuJQvWLmGwoSe0fghq6UIZxrCX
	if not Mauf6CrJjP87s: Um2ITJ1iLnEjqZevskVt06NY34,Mauf6CrJjP87s = 'folder','260'
	O9vls4Mk6S,vXgVBD5Q0LoPmYlG69e4qxRyc = [],G9G0YqivIfmUWO8K
	if 'context=' in ccW1tVjJvUx5efKbPHu6yAMLqaF:
		GdSuMZW4FHJ0B2L9o5q37UaCwTxrip = oo9kuULlebNgpY0Om.findall('context=(\d+)',ccW1tVjJvUx5efKbPHu6yAMLqaF,oo9kuULlebNgpY0Om.DOTALL)
		if GdSuMZW4FHJ0B2L9o5q37UaCwTxrip: vXgVBD5Q0LoPmYlG69e4qxRyc = str(GdSuMZW4FHJ0B2L9o5q37UaCwTxrip[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	if Mauf6CrJjP87s=='270':
		vXgVBD5Q0LoPmYlG69e4qxRyc = mUTXiaBzJf2utgY3KFIQl
		if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
			AQhF132wENxPTHebZVoD8B7 = rrI04mHTNsXO9dQFpWqMGgvhk7DJjZ(vXgVBD5Q0LoPmYlG69e4qxRyc)
			O9vls4Mk6S.append(('مسح قائمة '+AQhF132wENxPTHebZVoD8B7,'RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_DELETELIST'+')'))
	else:
		if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()):
			count = len(DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc])
			if count>fdQOo6Hu4B5Rbg: O9vls4Mk6S.append(('تحريك 1 للأعلى','RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_UP1)'))
			if count>xsCEkXb6tgrh3195YZ: O9vls4Mk6S.append(('تحريك 4 للأعلى','RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_UP4)'))
			if count>fdQOo6Hu4B5Rbg: O9vls4Mk6S.append(('تحريك 1 للأسفل','RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_DOWN1)'))
			if count>xsCEkXb6tgrh3195YZ: O9vls4Mk6S.append(('تحريك 4 للأسفل','RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_DOWN4)'))
		for vXgVBD5Q0LoPmYlG69e4qxRyc in ['1','2','3','4','5','11']:
			AQhF132wENxPTHebZVoD8B7 = rrI04mHTNsXO9dQFpWqMGgvhk7DJjZ(vXgVBD5Q0LoPmYlG69e4qxRyc)
			if vXgVBD5Q0LoPmYlG69e4qxRyc in list(DHNaSJAvwIOgGuPCFd1MEiQm.keys()) and NTRtuJQvWLmGwoSe0fghq6UIZxrCX in DHNaSJAvwIOgGuPCFd1MEiQm[vXgVBD5Q0LoPmYlG69e4qxRyc]:
				O9vls4Mk6S.append(('مسح من '+AQhF132wENxPTHebZVoD8B7,'RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_REMOVE1)'))
			else: O9vls4Mk6S.append(('إضافة ل'+AQhF132wENxPTHebZVoD8B7,'RunPlugin('+JRoDl1LwSb+'&context='+vXgVBD5Q0LoPmYlG69e4qxRyc+'_ADD1)'))
	i7iaoCkmpYecg2Kr = []
	for kELvN4I52J30pKDXb9uyw,uEHDMUPcW2RmqIv0FrNGihds4o8 in O9vls4Mk6S:
		kELvN4I52J30pKDXb9uyw = ipjCIhwEXsbadR+kELvN4I52J30pKDXb9uyw+zzGfwLAyN5HTxUoJeaivY
		i7iaoCkmpYecg2Kr.append((kELvN4I52J30pKDXb9uyw,uEHDMUPcW2RmqIv0FrNGihds4o8,))
	return i7iaoCkmpYecg2Kr
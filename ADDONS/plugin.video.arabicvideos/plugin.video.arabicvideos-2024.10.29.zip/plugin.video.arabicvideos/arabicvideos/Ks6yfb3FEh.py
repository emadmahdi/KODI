# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMAFANS'
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
TdtCLWYSJNK8zOb = '_CMF_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==90: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==91: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI(url)
	elif mode==92: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==94: tRojAyBgfDH37eLCwP4dWl = HDY16Cs8Q2qxREhZ3Iw()
	elif mode==95: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==99: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,99,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المضاف حديثا',G9G0YqivIfmUWO8K,94)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الأحدث',ffVP3AK5RqhkgYnjZoNis+'/?type=latest',91)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الأعلى تقيماً',ffVP3AK5RqhkgYnjZoNis+'/?type=imdb',91)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الأكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis+'/?type=view',91)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المثبت',ffVP3AK5RqhkgYnjZoNis+'/?type=pin',91)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الأفلام',ffVP3AK5RqhkgYnjZoNis+'/?type=newMovies',91)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الحلقات',ffVP3AK5RqhkgYnjZoNis+'/?type=newEpisodes',91)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'CIMAFANS-MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="mainmenu(.*?)nav',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('<li><a href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	tlcXBJEfIHF02vQ6yxSom9z1 = ['افلام للكبار فقط']
	for Y6YdkAMluFbwx,title in items:
		title = title.strip(ww0sZkBU9JKd)
		if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,91)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="f-cats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('<li><a href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		title = title.strip(ww0sZkBU9JKd)
		if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,91)
	return GagwMT6q3oc7UZ2Q
def Mt7X1vp6TLucKVrw8EUhyI(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : G9G0YqivIfmUWO8K , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAFANS-ITEMS-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	else:
		headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'CIMAFANS-ITEMS-2nd')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="movies-items(.*?)class="listfoot"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	else: BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	items = oo9kuULlebNgpY0Om.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة [0-9]+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7:
				title = '_MOD_'+RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,95,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/video/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,92,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,91,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<a href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,91)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'CIMAFANS-EPISODES-1st')
	M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('img src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	M4qkBDatEIf3T = M4qkBDatEIf3T[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="episodes-panel(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		name = oo9kuULlebNgpY0Om.findall('itemprop="title">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if name: name = name[1]
		else:
			name = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Label')
			if zzGfwLAyN5HTxUoJeaivY in name: name = name.split(zzGfwLAyN5HTxUoJeaivY,1)[1]
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?name">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+name+' - '+title,Y6YdkAMluFbwx,92,M4qkBDatEIf3T)
	else:
		VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall('class="movietitle"><a href="(.*?)">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if VwRHKuBk48UPEqnQsp: Y6YdkAMluFbwx,title = VwRHKuBk48UPEqnQsp[0]
		else: Y6YdkAMluFbwx,title = url,name
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,92,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS,WRJB5Aun46mj82z9thxviEdSgk1wX = [],[]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'CIMAFANS-PLAY-1st')
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('text-shadow: none;">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="links-panel(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?__download'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('nav-tabs"(.*?)video-panel-more',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('id="(.*?)".*?embed src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,Y6YdkAMluFbwx in items:
			title = 'سيرفر '+id
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		items = oo9kuULlebNgpY0Om.findall('data-server-src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in items:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
			Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def HDY16Cs8Q2qxREhZ3Iw():
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'CIMAFANS-LATEST-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="index-last-movie(.*?)id="index-slider-movie',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if '/video/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,92,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,91,M4qkBDatEIf3T)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis + '/search.php?t='+search
	Mt7X1vp6TLucKVrw8EUhyI(url)
	return
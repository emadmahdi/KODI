# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMALIGHT'
TdtCLWYSJNK8zOb = '_CML_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['قنوات فضائية']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==470: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==471: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==472: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==473: tRojAyBgfDH37eLCwP4dWl = fNn6k23ORzwyBe14EbYSvZXxoAM(url,text)
	elif mode==474: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==479: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = oo9kuULlebNgpY0Om.findall('"url": "(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	sg0IMYl698kyvmfVASQU4K13Z2L = sg0IMYl698kyvmfVASQU4K13Z2L[0].strip('/')
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(sg0IMYl698kyvmfVASQU4K13Z2L,'url')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,479,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"content"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		title = title.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('cat=online-movies1','cat=online-movies')
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,474)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('/category.php">(.*?)"navslide-divider"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("'dropdown-menu'(.*?)</ul>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,474)
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'topvideos.php' in url: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"caret"(.*?)id="pm-grid"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if 'topvideos.php' in Y6YdkAMluFbwx:
				if 'topvideos.php?c=english-movies' in Y6YdkAMluFbwx: continue
				if 'topvideos.php?c=online-movies1' in Y6YdkAMluFbwx: continue
				if 'topvideos.php?c=misc' in Y6YdkAMluFbwx: continue
				if 'topvideos.php?c=tv-channel' in Y6YdkAMluFbwx: continue
				if 'منذ البداية' in title and 'do=rating' not in Y6YdkAMluFbwx: continue
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,471)
	else: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = []
	if A0AzrLupg8h1s=='featured_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"container-fluid"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		dsGzqX4k0a8RLyc,JoSpAl1HIVd0f,TB4Ly9iZD2N5Fjxv = zip(*items)
		items = zip(TB4Ly9iZD2N5Fjxv,dsGzqX4k0a8RLyc,JoSpAl1HIVd0f)
	elif A0AzrLupg8h1s=='featured_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('المسلسلات المميزة(.*?)<style>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		dsGzqX4k0a8RLyc,JoSpAl1HIVd0f,TB4Ly9iZD2N5Fjxv = zip(*items)
		items = zip(TB4Ly9iZD2N5Fjxv,dsGzqX4k0a8RLyc,JoSpAl1HIVd0f)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(data-echo=".*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"BlocksList"(.*?)"titleSectionCon"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="pm-grid"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="pm-related"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pm-ul-browse-videos(.*?)clearfix',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: return
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not items: items = oo9kuULlebNgpY0Om.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		title = title.replace('ماي سيما',G9G0YqivIfmUWO8K).replace('مشاهدة',G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
		if 'http' not in M4qkBDatEIf3T: M4qkBDatEIf3T = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+M4qkBDatEIf3T.strip('/')
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة) \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			title = '_MOD_'+title
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,472,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'حلقة' in title:
			title = '_MOD_'+RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,473,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/movseries/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,471,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,473,M4qkBDatEIf3T)
	if A0AzrLupg8h1s not in ['featured_movies','featured_series']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,471)
		R67d0jkqLyfChz1PV = oo9kuULlebNgpY0Om.findall('showmore" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if R67d0jkqLyfChz1PV:
			Y6YdkAMluFbwx = R67d0jkqLyfChz1PV[0]
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مشاهدة المزيد',Y6YdkAMluFbwx,471)
	return
def fNn6k23ORzwyBe14EbYSvZXxoAM(url,JlwhosfkrT):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"SeasonsBox"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	items = []
	if kyoQ0h8lGBOW13cNvRqjDp and not JlwhosfkrT:
		M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('"series-header".*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		M4qkBDatEIf3T = M4qkBDatEIf3T[0] if M4qkBDatEIf3T else G9G0YqivIfmUWO8K
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)==1: JlwhosfkrT = items[0][0]
		elif len(items)>1:
			for JlwhosfkrT,title in items: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,473,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,JlwhosfkrT)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('id="'+JlwhosfkrT+'"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO and len(items)<2:
		M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('"series-header".*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		M4qkBDatEIf3T = M4qkBDatEIf3T[0] if M4qkBDatEIf3T else G9G0YqivIfmUWO8K
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,title in items:
				title = title.replace('ماي سيما',G9G0YqivIfmUWO8K).replace('مسلسل',G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,472,M4qkBDatEIf3T)
		else:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,472,M4qkBDatEIf3T)
	if 'id="pm-related"' in GagwMT6q3oc7UZ2Q:
		if items: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مواضيع ذات صلة',url,471)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<div itemprop="description">(.*?)href=',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('<p>(.*?)</p>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd,True): return
	XXzvmn7ewM8yBfoxua = url.replace('/watch.php','/play.php')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-PLAY-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	HhP0AXOUR9zcWB4p = []
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('"embedURL" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
		if Y6YdkAMluFbwx and Y6YdkAMluFbwx not in HhP0AXOUR9zcWB4p:
			HhP0AXOUR9zcWB4p.append(Y6YdkAMluFbwx)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named=__embed'
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	items = oo9kuULlebNgpY0Om.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if Y6YdkAMluFbwx not in HhP0AXOUR9zcWB4p:
			HhP0AXOUR9zcWB4p.append(Y6YdkAMluFbwx)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	XXzvmn7ewM8yBfoxua = url.replace('/watch.php','/downloads.php')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMALIGHT-PLAY-3rd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"downloadlist"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<strong>(.*?)</strong>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if Y6YdkAMluFbwx not in HhP0AXOUR9zcWB4p:
				HhP0AXOUR9zcWB4p.append(Y6YdkAMluFbwx)
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(ffVP3AK5RqhkgYnjZoNis,'url')
	url = yVgLqfcUN1iO4+'/search.php?keywords='+search
	UUhwKBgI2nt(url,'search')
	return
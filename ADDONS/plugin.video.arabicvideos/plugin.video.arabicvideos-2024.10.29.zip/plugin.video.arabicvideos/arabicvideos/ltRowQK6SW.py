# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'EGYBESTVIP'
TdtCLWYSJNK8zOb = '_EGV_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
def RAndFk3y4Pbvs29(mode,url,eehFlSEjHioyAWpLqZXt79,text):
	if   mode==220: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==221: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==222: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==223: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==224: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url)
	elif mode==229: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,229,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="i i-home"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,222)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="ba(.*?)<script',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for title,Y6YdkAMluFbwx in items:
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,221)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if 'html' not in Y6YdkAMluFbwx: continue
			if not Y6YdkAMluFbwx.endswith('/'): Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,221)
	return GagwMT6q3oc7UZ2Q
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="rs_scroll"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,224)
	return
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url):
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',url,221)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-FILTERS_MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="sub_nav(.*?)id="movies',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".+?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if Y6YdkAMluFbwx=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,221)
	else: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79='1'):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	if '/search' in url or '?' in url: XXzvmn7ewM8yBfoxua = url + '&'
	else: XXzvmn7ewM8yBfoxua = url + '?'
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua + 'page=' + eehFlSEjHioyAWpLqZXt79
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('class="pda"(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[-1]
	elif '/series/' in url:
		cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('class="owl-carousel owl-carousel(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	else:
		cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('id="movies(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[-1]
	items = oo9kuULlebNgpY0Om.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if '/movie/' in Y6YdkAMluFbwx or '/episode' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx.rstrip('/'),223,M4qkBDatEIf3T)
		else:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,221,M4qkBDatEIf3T)
	if len(items)>=16:
		QdR4yMeDp68mwoKzBAGcuLIlV7siN0 = ['/movies','/tv','/search','/trending']
		eehFlSEjHioyAWpLqZXt79 = int(eehFlSEjHioyAWpLqZXt79)
		if any(yW70dtahIjkPCJg2TA in url for yW70dtahIjkPCJg2TA in QdR4yMeDp68mwoKzBAGcuLIlV7siN0):
			for RRuQjr4cZS in range(0,1000,100):
				if int(eehFlSEjHioyAWpLqZXt79/100)*100==RRuQjr4cZS:
					for KT9tdUH3hmiLZCEFz in range(RRuQjr4cZS,RRuQjr4cZS+100,10):
						if int(eehFlSEjHioyAWpLqZXt79/10)*10==KT9tdUH3hmiLZCEFz:
							for MtcB169HDRaj38urXGZC2qd0LiyPmh in range(KT9tdUH3hmiLZCEFz,KT9tdUH3hmiLZCEFz+10,1):
								if not eehFlSEjHioyAWpLqZXt79==MtcB169HDRaj38urXGZC2qd0LiyPmh and MtcB169HDRaj38urXGZC2qd0LiyPmh!=0:
									Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+str(MtcB169HDRaj38urXGZC2qd0LiyPmh),url,221,G9G0YqivIfmUWO8K,str(MtcB169HDRaj38urXGZC2qd0LiyPmh))
						elif KT9tdUH3hmiLZCEFz!=0: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+str(KT9tdUH3hmiLZCEFz),url,221,G9G0YqivIfmUWO8K,str(KT9tdUH3hmiLZCEFz))
						else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+str(1),url,221,G9G0YqivIfmUWO8K,str(1))
				elif RRuQjr4cZS!=0: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+str(RRuQjr4cZS),url,221,G9G0YqivIfmUWO8K,str(RRuQjr4cZS))
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+str(1),url,221)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-PLAY-1st')
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('<td>التصنيف</td>.*?">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	mg3NutDryfoPJC9WxM,iv5ZtYQ8rf2Hm0ETWDjnPK1 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	LuVdiNcv9xPRtKp,D3dJ8UxpFtXmRrquWzj5LSO7s = GagwMT6q3oc7UZ2Q,GagwMT6q3oc7UZ2Q
	npKyLPgkmuQIH1lb83qFXxGf2E = oo9kuULlebNgpY0Om.findall('show_dl api" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if npKyLPgkmuQIH1lb83qFXxGf2E:
		for Y6YdkAMluFbwx in npKyLPgkmuQIH1lb83qFXxGf2E:
			if '/watch/' in Y6YdkAMluFbwx: mg3NutDryfoPJC9WxM = Y6YdkAMluFbwx
			elif '/download/' in Y6YdkAMluFbwx: iv5ZtYQ8rf2Hm0ETWDjnPK1 = Y6YdkAMluFbwx
		if mg3NutDryfoPJC9WxM!=G9G0YqivIfmUWO8K: LuVdiNcv9xPRtKp = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,mg3NutDryfoPJC9WxM,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-PLAY-2nd')
		if iv5ZtYQ8rf2Hm0ETWDjnPK1!=G9G0YqivIfmUWO8K: D3dJ8UxpFtXmRrquWzj5LSO7s = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,iv5ZtYQ8rf2Hm0ETWDjnPK1,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-PLAY-3rd')
	LL58esWNK1BA0HfqQDwPhSj = oo9kuULlebNgpY0Om.findall('id="video".*?data-src="(.*?)"',LuVdiNcv9xPRtKp,oo9kuULlebNgpY0Om.DOTALL)
	if LL58esWNK1BA0HfqQDwPhSj:
		XXzvmn7ewM8yBfoxua = LL58esWNK1BA0HfqQDwPhSj[0]
		if XXzvmn7ewM8yBfoxua!=G9G0YqivIfmUWO8K and 'uploaded.egybest.download' in XXzvmn7ewM8yBfoxua and '/?id=_' not in XXzvmn7ewM8yBfoxua:
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-PLAY-4th')
			r5VmsJ2q7wZWvUOybdGY = oo9kuULlebNgpY0Om.findall('source src="(.*?)" title="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if r5VmsJ2q7wZWvUOybdGY:
				for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in r5VmsJ2q7wZWvUOybdGY:
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx+'?named=ed.egybest.do__watch__mp4__'+I5chimw4D1okfxlBE2UpbuHJvStsZ)
			else:
				yVgLqfcUN1iO4 = XXzvmn7ewM8yBfoxua.split('/')[2]
				ODnaR0N8UHv7Twy6jS.append(XXzvmn7ewM8yBfoxua+'?named='+yVgLqfcUN1iO4+'__watch')
		elif XXzvmn7ewM8yBfoxua!=G9G0YqivIfmUWO8K:
			yVgLqfcUN1iO4 = XXzvmn7ewM8yBfoxua.split('/')[2]
			ODnaR0N8UHv7Twy6jS.append(XXzvmn7ewM8yBfoxua+'?named='+yVgLqfcUN1iO4+'__watch')
	UBaOjxKz2XVEmYIZf6wbcp4NM = oo9kuULlebNgpY0Om.findall('<table class="dls_table(.*?)</table>',D3dJ8UxpFtXmRrquWzj5LSO7s,oo9kuULlebNgpY0Om.DOTALL)
	if UBaOjxKz2XVEmYIZf6wbcp4NM:
		UBaOjxKz2XVEmYIZf6wbcp4NM = UBaOjxKz2XVEmYIZf6wbcp4NM[0]
		mTftg3ZDRlNbrp = oo9kuULlebNgpY0Om.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',UBaOjxKz2XVEmYIZf6wbcp4NM,oo9kuULlebNgpY0Om.DOTALL)
		if mTftg3ZDRlNbrp:
			for I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx in mTftg3ZDRlNbrp:
				if 'myegyvip' not in Y6YdkAMluFbwx: continue
				if Y6YdkAMluFbwx.count('/')>=2:
					yVgLqfcUN1iO4 = Y6YdkAMluFbwx.split('/')[2]
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__download__mp4__'+I5chimw4D1okfxlBE2UpbuHJvStsZ)
	hayNktUR2Tq8g = []
	for Y6YdkAMluFbwx in ODnaR0N8UHv7Twy6jS:
		hayNktUR2Tq8g.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(hayNktUR2Tq8g,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'+')
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBESTVIP-SEARCH-1st')
	jJ1iOyvCtQxbFeK = oo9kuULlebNgpY0Om.findall('name="_token" value="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if jJ1iOyvCtQxbFeK:
		url = ffVP3AK5RqhkgYnjZoNis+'/search?_token='+jJ1iOyvCtQxbFeK[0]+'&q='+HG9ZQqnw71y0JmrDLx
		UUhwKBgI2nt(url)
	return
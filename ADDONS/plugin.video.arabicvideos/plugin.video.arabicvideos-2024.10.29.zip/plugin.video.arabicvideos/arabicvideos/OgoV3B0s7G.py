# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = iAGgjwb7tVMmacRJ(u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨᮗ")
TdtCLWYSJNK8zOb = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡡࡏࡗ࡙ࡥࠧᮘ")
HuskB0c1Ob3r6CLiJXTyx = xsCEkXb6tgrh3195YZ
bOopYZI426luPgiUWQa8Bz5C7 = jR9YtmsgDX8nTQlMb6G3(u"࠳࠳ḁ")
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,url,Vvju9Ht8SGxoiTa6lCs,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3):
	try: Gzo1nsVM84m6abfISDup9xjQdBO = str(zF4nhxYlaiKPwA6NJZ3[bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮙ")])
	except: Gzo1nsVM84m6abfISDup9xjQdBO = G9G0YqivIfmUWO8K
	if   Mauf6CrJjP87s==VHrIziKUDuNGXkMla(u"࠴࠺࠵Ḃ"): tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif Mauf6CrJjP87s==vCmnFshSi4flecXIY2gy38G0DJw(u"࠵࠻࠷ḃ"): tRojAyBgfDH37eLCwP4dWl = Tp0qDh9i7Bg3SyKLsnJlI(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==UighHKAfySm4PWErqJ(u"࠶࠼࠲Ḅ"): tRojAyBgfDH37eLCwP4dWl = fWRVJ4syvQM(Vvju9Ht8SGxoiTa6lCs,UighHKAfySm4PWErqJ(u"࠶࠼࠲Ḅ"))
	elif Mauf6CrJjP87s==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠶࠴ḅ"): tRojAyBgfDH37eLCwP4dWl = fWRVJ4syvQM(Vvju9Ht8SGxoiTa6lCs,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠶࠴ḅ"))
	elif Mauf6CrJjP87s==dC3PsQJ0Ti28uYlov(u"࠱࠷࠶Ḇ"): tRojAyBgfDH37eLCwP4dWl = OL6SteZlWC3quRfv970T(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠲࠸࠸ḇ"): tRojAyBgfDH37eLCwP4dWl = qu0rJOKYgoaIs4Q(url,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠳࠹࠺Ḉ"): tRojAyBgfDH37eLCwP4dWl = C7WhqVcENtTSrD4FJdai82xL(url,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==t2sCrJ0xbgDRkf(u"࠴࠺࠼ḉ"): tRojAyBgfDH37eLCwP4dWl = N23lsFyVYDbK(url,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠵࠻࠾Ḋ"): tRojAyBgfDH37eLCwP4dWl = YDpCBmWV47AGL(url,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==vCmnFshSi4flecXIY2gy38G0DJw(u"࠼࠼࠱ḋ"): tRojAyBgfDH37eLCwP4dWl = o0ITe1NqdmACS8gpWvB4kzhFQ3RnLi()
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠽࠶࠳Ḍ"): tRojAyBgfDH37eLCwP4dWl = xxg1CvrTuAJ()
	elif Mauf6CrJjP87s==FWqeEzO1i8Dn0ga(u"࠷࠷࠵ḍ"): tRojAyBgfDH37eLCwP4dWl = iGwPCjz1NVpE37x50odLauWUhSYF(Gzo1nsVM84m6abfISDup9xjQdBO,Vvju9Ht8SGxoiTa6lCs,eehFlSEjHioyAWpLqZXt79)
	elif Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠸࠸࠷Ḏ"): tRojAyBgfDH37eLCwP4dWl = OrsJThENqZ3yuUV8YXLxiW67wb(Gzo1nsVM84m6abfISDup9xjQdBO,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠹࠹࠹ḏ"): tRojAyBgfDH37eLCwP4dWl = jS0h3RN6YpyZOwVfuMT7W8LHPE4KGF(Gzo1nsVM84m6abfISDup9xjQdBO,Vvju9Ht8SGxoiTa6lCs)
	else: tRojAyBgfDH37eLCwP4dWl = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࡆࡢ࡮ࡶࡩṨ")
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡪࡴࡲࡤࡦࡴࠪᮚ"),FWqeEzO1i8Dn0ga(u"ࠫ็์่ศฬࠣฮ้็า๋๊้ࠤ฾ฺ่ศศํอࠬᮛ"),G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠴࠺࠶Ḑ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮜ"))
	Qm8SMu6ecXtigDCWw1oak(vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮝ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧใี่ࠤ฾ฺ่ศศํࠫᮞ"),G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠵࠻࠸ḑ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᮟ"))
	Qm8SMu6ecXtigDCWw1oak(iqHhJSxdaANDG5rlZm7B(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮠ"),cJSNFCIhymEfx6grGu0M(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭ᮡ"),G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠶࠼࠳Ḓ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᮢ"))
	Qm8SMu6ecXtigDCWw1oak(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᮣ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭แ๋ัํ์์อสࠡสะฯࠥ฿ิ้ษษ๎ࠬᮤ"),G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"࠷࠶࠵ḓ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᮥ"))
	Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᮦ"),yiaeCEwJjOcWA4ZSd5h(u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬᮧ"),G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"࠷࠷࠵Ḕ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬᮨ"))
	Qm8SMu6ecXtigDCWw1oak(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡱ࡯࡮࡬ࠩᮩ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿᮪ࠣࠫ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠺࠻࠼࠽ḕ"))
	Qm8SMu6ecXtigDCWw1oak(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡦࡰ࡮ࡧࡩࡷ᮫࠭"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧใ่๋หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫᮬ"),G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"࠳࠹࠷Ḗ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᮭ"))
	Qm8SMu6ecXtigDCWw1oak(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮮ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪᮯ"),G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"࠴࠺࠸ḗ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᮰"))
	Qm8SMu6ecXtigDCWw1oak(iAGgjwb7tVMmacRJ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᮱"),rr7Xolsp4JwjPK3L(u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭᮲"),G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"࠵࠻࠸Ḙ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᮳"))
	Qm8SMu6ecXtigDCWw1oak(yiaeCEwJjOcWA4ZSd5h(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᮴"),rr7Xolsp4JwjPK3L(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ᮵"),G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠶࠼࠲ḙ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠪࡣࡒ࠹ࡕࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᮶"))
	Qm8SMu6ecXtigDCWw1oak(dC3PsQJ0Ti28uYlov(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᮷"),jR9YtmsgDX8nTQlMb6G3(u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤอำหࠡ฻ื์ฬฬ๊ࠨ᮸"),G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"࠷࠶࠵Ḛ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᮹"))
	Qm8SMu6ecXtigDCWw1oak(qTVF3icWwGXy5(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᮺ"),ETNq5t4MYngSsbfFD8J0v(u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᮻ"),G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠷࠷࠷ḛ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᮼ"))
	Qm8SMu6ecXtigDCWw1oak(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡰ࡮ࡴ࡫ࠨᮽ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+t2sCrJ0xbgDRkf(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᮾ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠺࠻࠼࠽Ḝ"))
	Qm8SMu6ecXtigDCWw1oak(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᮿ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭โ็๊สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᯀ"),G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠳࠹࠷ḝ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯁ"))
	Qm8SMu6ecXtigDCWw1oak(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯂ"),DTF3Lwy9etRH8mI(u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪᯃ"),G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"࠴࠺࠸Ḟ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯄ"))
	Qm8SMu6ecXtigDCWw1oak(ETNq5t4MYngSsbfFD8J0v(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯅ"),iAGgjwb7tVMmacRJ(u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭ᯆ"),G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠵࠻࠸ḟ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᯇ"))
	Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯈ"),UighHKAfySm4PWErqJ(u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩᯉ"),G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"࠶࠼࠲Ḡ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᯊ"))
	Qm8SMu6ecXtigDCWw1oak(VHrIziKUDuNGXkMla(u"ࠪࡪࡴࡲࡤࡦࡴࠪᯋ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨᯌ"),G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠷࠶࠵ḡ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᯍ"))
	Qm8SMu6ecXtigDCWw1oak(vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᯎ"),EHUAyW2lQfe4LXmhgIGc(u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨᯏ"),G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠷࠷࠶Ḣ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᯐ"))
	return
def o0ITe1NqdmACS8gpWvB4kzhFQ3RnLi():
	Qm8SMu6ecXtigDCWw1oak(dC3PsQJ0Ti28uYlov(u"ࠩࡩࡳࡱࡪࡥࡳࠩᯑ"),FWqeEzO1i8Dn0ga(u"ࠪࡣࡎࡖࡔࡠࠩᯒ")+cJSNFCIhymEfx6grGu0M(u"ࠫๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤࡎࡖࡔࡗࠩᯓ"),G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠸࠸࠷ḣ"))
	Qm8SMu6ecXtigDCWw1oak(EHUAyW2lQfe4LXmhgIGc(u"ࠬࡲࡩ࡯࡭ࠪᯔ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+vCmnFshSi4flecXIY2gy38G0DJw(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᯕ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠻࠼࠽࠾Ḥ"))
	for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
		TdtCLWYSJNK8zOb = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡠࡋࡓࠫᯖ")+str(Gzo1nsVM84m6abfISDup9xjQdBO)+FWqeEzO1i8Dn0ga(u"ࠨࡡࠪᯗ")
		Qm8SMu6ecXtigDCWw1oak(iqHhJSxdaANDG5rlZm7B(u"ࠩࡩࡳࡱࡪࡥࡳࠩᯘ"),TdtCLWYSJNK8zOb+FWqeEzO1i8Dn0ga(u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬᯙ")+F7hmrbfYztVycGjDE4Sd[Gzo1nsVM84m6abfISDup9xjQdBO],G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"࠺࠺࠹ḥ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{iAGgjwb7tVMmacRJ(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯚ"):Gzo1nsVM84m6abfISDup9xjQdBO})
	return
def xxg1CvrTuAJ():
	Qm8SMu6ecXtigDCWw1oak(iAGgjwb7tVMmacRJ(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯛ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭࡟ࡎ࠵ࡘࡣࠬᯜ")+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧโ์า๎ํํวหࠢฯ้๏฿ࠠࡎ࠵ࡘࠫᯝ"),G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"࠻࠻࠻Ḧ"))
	Qm8SMu6ecXtigDCWw1oak(t2sCrJ0xbgDRkf(u"ࠨ࡮࡬ࡲࡰ࠭ᯞ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᯟ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"࠾࠿࠹࠺ḧ"))
	for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
		TdtCLWYSJNK8zOb = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡣࡒ࡛ࠧᯠ")+str(Gzo1nsVM84m6abfISDup9xjQdBO)+RVpeGcmPxj9tCnT40Nf216(u"ࠫࡤ࠭ᯡ")
		Qm8SMu6ecXtigDCWw1oak(dC3PsQJ0Ti28uYlov(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯢ"),TdtCLWYSJNK8zOb+RVpeGcmPxj9tCnT40Nf216(u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨᯣ")+F7hmrbfYztVycGjDE4Sd[Gzo1nsVM84m6abfISDup9xjQdBO],G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠽࠶࠶Ḩ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,{dC3PsQJ0Ti28uYlov(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯤ"):Gzo1nsVM84m6abfISDup9xjQdBO})
	return
def zzad8Ii1HopvKDrGXEQhgTZ6(oob2dzmG3jTMpZwQyIfN):
	global xe1CRapPDqhW3rgNGvO8dIk,cRakf8eJD5
	oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
	try:
		if DTF3Lwy9etRH8mI(u"ࠨࡋࡉࡍࡑࡓࠧᯥ") in oob2dzmG3jTMpZwQyIfN: oyuFxk4Vew5cHP16(oob2dzmG3jTMpZwQyIfN)
		else: oyuFxk4Vew5cHP16()
		yvbDuTf0xtcNeV5Qd9AYaopi = VHrIziKUDuNGXkMla(u"ࡇࡣ࡯ࡷࡪṩ")
	except:
		XDk4GnqsF2KNRptPwfg0cBJebZ()
		yvbDuTf0xtcNeV5Qd9AYaopi = rr7Xolsp4JwjPK3L(u"ࡖࡵࡹࡪṪ")
	oob2dzmG3jTMpZwQyIfN = GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN)
	if yvbDuTf0xtcNeV5Qd9AYaopi:
		XXeZuvhknsKYqB17gwm6dfc(oob2dzmG3jTMpZwQyIfN,iAGgjwb7tVMmacRJ(u"ࠩไุ้ࠦไๅลึๅ᯦ࠬ"),SSCU3jdyFn2V=Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠲࠱࠲࠳ḩ"))
		xe1CRapPDqhW3rgNGvO8dIk += fdQOo6Hu4B5Rbg
		cRakf8eJD5 += ww0sZkBU9JKd+oob2dzmG3jTMpZwQyIfN
	else: XXeZuvhknsKYqB17gwm6dfc(oob2dzmG3jTMpZwQyIfN,G9G0YqivIfmUWO8K,SSCU3jdyFn2V=UighHKAfySm4PWErqJ(u"࠲࠲࠳࠴Ḫ"))
	return
def Z0T74gk1RHfUoSKcAOWPQsalBuh(w0MIkEKy5Zpch9=ETNq5t4MYngSsbfFD8J0v(u"ࡗࡶࡺ࡫ṫ")):
	global xe1CRapPDqhW3rgNGvO8dIk,cRakf8eJD5,y2authQZX56sVUGEdNpFOzKD40cgw
	if not w0MIkEKy5Zpch9:
		y2authQZX56sVUGEdNpFOzKD40cgw = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,VHrIziKUDuNGXkMla(u"ࠪࡨ࡮ࡩࡴࠨᯧ"),cjbAkCIinvs(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬᯨ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪᯩ"))
		if y2authQZX56sVUGEdNpFOzKD40cgw: return
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(dC3PsQJ0Ti28uYlov(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ᯪ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᯫ"),ssGdubC4mngM9D5SRc3Ye(u"ࠨๆๆ๎ࠥะๅๅศ๋ࠣีํࠠศๆๅหห๋ษࠡ࠰ࠣห้ฮั็ษ่ะࠥ๐อหษฯࠤศ์๋ࠠใะูࠥาๅ๋฻้ࠣํอโฺࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡใํࠤฬ๊ศา่ส้ัࠦไไ์ࠣ๎ุะฮาฮ้๋ࠣํวࠡใๅ฻ࠥอไฤไึห๊ࠦวๅำษ๎ุ๐ษࠡ࠰ࠣฯ๊๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ์ึ็ࠡษ็ว็ูวๆࠢะฮ๎ࠦไศࠢอัฯอฬࠡล้ࠤฯ๋ไว้สࠤ๊ืษࠡลัี๎ࠦ࠮ࠡ฻่่๏ฯࠠๆๆษࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣฮาะวอࠢ฼หิฯࠠฤไ็ࠤ๊์ࠠ࠴ࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬᯬ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=fdQOo6Hu4B5Rbg: return
	ggGCyoxkHXwif(bneABYmwFUH8GXphg0Kl2Sq(u"ࡊࡦࡲࡳࡦṬ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࡊࡦࡲࡳࡦṬ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࡊࡦࡲࡳࡦṬ"))
	SlZbQq48owRsJpzXd = eANQpmZPJaI7wc8
	xe1CRapPDqhW3rgNGvO8dIk,cRakf8eJD5,threads = dQ5JhEYolPmy1fvHktMw6NFRxiz,G9G0YqivIfmUWO8K,{}
	for oob2dzmG3jTMpZwQyIfN in TTNMWtsb1eaAd6:
		SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
		threads[oob2dzmG3jTMpZwQyIfN] = fu19TY0PdM6AZB5.Thread(target=zzad8Ii1HopvKDrGXEQhgTZ6,args=(oob2dzmG3jTMpZwQyIfN,))
		threads[oob2dzmG3jTMpZwQyIfN].start()
		if xe1CRapPDqhW3rgNGvO8dIk>=bOopYZI426luPgiUWQa8Bz5C7: break
	else:
		for oob2dzmG3jTMpZwQyIfN in list(threads.keys()): threads[oob2dzmG3jTMpZwQyIfN].join()
	eANQpmZPJaI7wc8[:] = SlZbQq48owRsJpzXd
	if xe1CRapPDqhW3rgNGvO8dIk>=bOopYZI426luPgiUWQa8Bz5C7: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᯭ"),yiaeCEwJjOcWA4ZSd5h(u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫᯮ")+str(xe1CRapPDqhW3rgNGvO8dIk)+UighHKAfySm4PWErqJ(u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩᯯ")+cRakf8eJD5)
	else:
		y2authQZX56sVUGEdNpFOzKD40cgw = {}
		for oob2dzmG3jTMpZwQyIfN in list(threads.keys()):
			try: Nf1yObCTQo6nKE = MMznYDmqKf0gVWpiSulZJ1waTRc[oob2dzmG3jTMpZwQyIfN]
			except: continue
			oob2dzmG3jTMpZwQyIfN = ETNq5t4MYngSsbfFD8J0v(u"ࠬࡥࡌࡔࡖࡢࠫᯰ")+GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN)
			for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge in Nf1yObCTQo6nKE:
				if not YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭࠮࠯࠰࠱ࠫᯱ")
				else:
					if YwC7jt5BQHhTUvbdGeM6f2ZLx.count(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡠ᯲ࠩ"))>fdQOo6Hu4B5Rbg: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.split(jR9YtmsgDX8nTQlMb6G3(u"ࠨࡡ᯳ࠪ"),SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU)[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ETNq5t4MYngSsbfFD8J0v(u"ࠩࢣࠫ᯴"),G9G0YqivIfmUWO8K).replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࠤࡍࡊࠧ᯵"),G9G0YqivIfmUWO8K).replace(RVpeGcmPxj9tCnT40Nf216(u"ࠫࡍࡊࠠࠨ᯶"),G9G0YqivIfmUWO8K)
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(yiaeCEwJjOcWA4ZSd5h(u"ࠬๆࠧ᯷"),G9G0YqivIfmUWO8K).replace(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ษࠨ᯸"),EHUAyW2lQfe4LXmhgIGc(u"่ࠧࠩ᯹")).replace(cJSNFCIhymEfx6grGu0M(u"ࠨฦࠪ᯺"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"๋ࠩࠫ᯻"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠪวࠬ᯼"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫฬ࠭᯽")).replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬหࠧ᯾"),dC3PsQJ0Ti28uYlov(u"࠭วࠨ᯿")).replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧรࠩᰀ"),ETNq5t4MYngSsbfFD8J0v(u"ࠨษࠪᰁ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠩ็วࠬᰂ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"่ࠪฬ࠭ᰃ")).replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"้ࠫหࠧᰄ"),EHUAyW2lQfe4LXmhgIGc(u"๊ࠬวࠨᰅ")).replace(RVpeGcmPxj9tCnT40Nf216(u"࠭ไรࠩᰆ"),ETNq5t4MYngSsbfFD8J0v(u"ࠧๅษࠪᰇ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠨ๐ࠪᰈ"),G9G0YqivIfmUWO8K).replace(rr7Xolsp4JwjPK3L(u"ࠩ๎ࠫᰉ"),G9G0YqivIfmUWO8K).replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪ๓ࠬᰊ"),G9G0YqivIfmUWO8K).replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ๑࠭ᰋ"),G9G0YqivIfmUWO8K)
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ๖ࠧᰌ"),G9G0YqivIfmUWO8K).replace(rxWDdRBIct57i90s(u"࠭ํࠨᰍ"),G9G0YqivIfmUWO8K).replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ๓ࠩᰎ"),G9G0YqivIfmUWO8K).replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨ๓ࠪᰏ"),G9G0YqivIfmUWO8K)
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡿࠫᰐ"),G9G0YqivIfmUWO8K).replace(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࢂࠬᰑ"),G9G0YqivIfmUWO8K)
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫฬ๎ๆࠡๆส๎๋࠭ᰒ"),G9G0YqivIfmUWO8K).replace(yiaeCEwJjOcWA4ZSd5h(u"ู๊ࠬๆษ่ࠣฬ๐สࠨᰓ"),G9G0YqivIfmUWO8K)
					xanuwTrMbOSkl0NoAeB = [dC3PsQJ0Ti28uYlov(u"࠭วๅ฻สฬࠬᰔ"),dC3PsQJ0Ti28uYlov(u"ࠧฯ์ส่ࠬᰕ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨษ็ฬํ๋ࠧᰖ"),t2sCrJ0xbgDRkf(u"ࠩส่ฬ์ࠧᰗ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪห฼็วๅࠩᰘ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫาอไ๋้ࠪᰙ"),VHrIziKUDuNGXkMla(u"ࠬอไ฻ษีࠫᰚ"),cJSNFCIhymEfx6grGu0M(u"࠭ีศๆะࠫᰛ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧศๆา๎๋࠭ᰜ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ็๋ห้๐ฯࠨᰝ"),EHUAyW2lQfe4LXmhgIGc(u"ࠩส่฾อไๆࠩᰞ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪห฾๋วๅࠩᰟ")]
					if not any(bZYntjRQarszwWUv0XT in YwC7jt5BQHhTUvbdGeM6f2ZLx for bZYntjRQarszwWUv0XT in xanuwTrMbOSkl0NoAeB): YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rr7Xolsp4JwjPK3L(u"ࠫฬ๊ࠧᰠ"),G9G0YqivIfmUWO8K)
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(FWqeEzO1i8Dn0ga(u"ࠬอฮา์ࠪᰡ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭วฯำ์ࠫᰢ")).replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧศฮ้ฬ๎࠭ᰣ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨษฯ๊อ๐ࠧᰤ")).replace(ETNq5t4MYngSsbfFD8J0v(u"ࠩ฼หห๊๊่ࠩᰥ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ฽ฬฬไ๋ࠩᰦ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rxWDdRBIct57i90s(u"ࠫฬาๆษ์๊ࠫᰧ"),VHrIziKUDuNGXkMla(u"ࠬอฬ็สํࠫᰨ")).replace(ETNq5t4MYngSsbfFD8J0v(u"ู࠭าสํ๋ࠬᰩ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ฺࠧำห๎ࠬᰪ")).replace(ssGdubC4mngM9D5SRc3Ye(u"ࠨำ๋้ฬ์ำ๋้ࠪᰫ"),DTF3Lwy9etRH8mI(u"ࠩิ์๊อๆิ์ࠪᰬ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rxWDdRBIct57i90s(u"ࠪ฾ึฮ๊่ࠩᰭ"),RVpeGcmPxj9tCnT40Nf216(u"ࠫ฿ืศ๋ࠩᰮ")).replace(RVpeGcmPxj9tCnT40Nf216(u"ࠬ๎ࠠๆี็ื้อสࠨᰯ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ๅิๆึ่ฬะࠧᰰ")).replace(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧศ฼ส๊๎࠭ᰱ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨษ฽ห๋๐ࠧᰲ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rr7Xolsp4JwjPK3L(u"ࠩอหึ๐ฮ๋ࠩᰳ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪฮฬื๊ฯࠩᰴ")).replace(qTVF3icWwGXy5(u"ࠫำ๐วๅࠢ฼่๊๐ࠧᰵ"),ETNq5t4MYngSsbfFD8J0v(u"ࠬิ๊ศๆࠪᰶ")).replace(EHUAyW2lQfe4LXmhgIGc(u"࠭ๅ้ีํๆ๏ํ᰷ࠧ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧๆ๊ึ๎็๏ࠧ᰸"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(EHUAyW2lQfe4LXmhgIGc(u"ࠨ้้ำ๎࠭᰹"),t2sCrJ0xbgDRkf(u"๊๊ࠩิ๐ࠧ᰺")).replace(t2sCrJ0xbgDRkf(u"๋๋ࠪี๊่ࠩ᰻"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ์์ฯ๋ࠩ᰼")).replace(iAGgjwb7tVMmacRJ(u"ࠬ๎หศศๅ๎์࠭᰽"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"่࠭ฬษษๆ๏࠭᰾"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧหๆํๅื๐่็์๊ࠫ᰿"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨฬ็ๅื๐่็ࠩ᱀")).replace(rr7Xolsp4JwjPK3L(u"ࠩอ่ๆุ๊้่ํ๋ࠬ᱁"),qTVF3icWwGXy5(u"ࠪฮ้็า๋๊้ࠫ᱂")).replace(iAGgjwb7tVMmacRJ(u"ࠫํࠦใาฬ๋๊ࠬ᱃"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬ๎ใาฬ๋๊ࠬ᱄"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(cjbAkCIinvs(u"࠭วๅฯส่๏ํࠧ᱅"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧฮษ็๎์࠭᱆")).replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ็๋ื໑่๊ࠨ᱇"),dC3PsQJ0Ti28uYlov(u"่ࠩ์ุ๐โ๊ࠩ᱈")).replace(yiaeCEwJjOcWA4ZSd5h(u"ࠪห้อๆๆ์ࠪ᱉"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫฬ์ๅ๋ࠩ᱊"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(cjbAkCIinvs(u"ࠬอไๆี็ื้อสࠨ᱋"),rr7Xolsp4JwjPK3L(u"࠭ๅิๆึ่ฬะࠧ᱌")).replace(rr7Xolsp4JwjPK3L(u"ࠧศๆหีฬ๋ฬࠨᱍ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨสิห๊าࠧᱎ")).replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩๆหึะ่็ࠩᱏ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ็ึะ่็ࠩ᱐"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠫาื่ษࠩ᱑"),t2sCrJ0xbgDRkf(u"ࠬำัษࠩ᱒")).replace(bneABYmwFUH8GXphg0Kl2Sq(u"࠭วๅษ้หู๐ฯࠨ᱓"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧศ่สุ๏ีࠧ᱔")).replace(qTVF3icWwGXy5(u"ࠨษึ๎ํ๐็ࠨ᱕"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩสื๏๎๊ࠨ᱖"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪ฽ึฮ้ࠨ᱗"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ฾ืศ๋ࠩ᱘")).replace(t2sCrJ0xbgDRkf(u"ࠬะัไ๋ࠪ᱙"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭สาๅํࠫᱚ")).replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧหำๆ๎์࠭ᱛ"),qTVF3icWwGXy5(u"ࠨฬิ็๏࠭ᱜ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠩิ๎ฬ฼๊ࠨᱝ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪี๏อึสࠩᱞ")).replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫึ๐วื้ࠪᱟ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬื๊ศุฬࠫᱠ")).replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭วิ์๋๎์࠭ᱡ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧศีํ์๏࠭ᱢ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rxWDdRBIct57i90s(u"ࠨๅ๋้๏ี้ࠨᱣ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩๆ์๊๐ฯ๋ࠩᱤ")).replace(DTF3Lwy9etRH8mI(u"ࠪ็ํ๋๊ะ์๊ࠫᱥ"),bneABYmwFUH8GXphg0Kl2Sq(u"่ࠫ๎ๅ๋ัํࠫᱦ")).replace(cJSNFCIhymEfx6grGu0M(u"ࠬอๆ๋็ํࠫᱧ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ว็็ํࠫᱨ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(rxWDdRBIct57i90s(u"ࠧศ่ํ้๏ฺๆࠨᱩ"),dC3PsQJ0Ti28uYlov(u"ࠨษ้้๏ฺๆࠨᱪ")).replace(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩส๊๊๏ࠧᱫ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪห๋๋๊ี่ࠪᱬ")).replace(cjbAkCIinvs(u"ࠫฬ์ๅ๋ࠩᱭ"),DTF3Lwy9etRH8mI(u"ࠬอๆๆ์ื๊ࠬᱮ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ว็็ํฺุ๋ๆࠨᱯ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧศ่่๎ู์ࠧᱰ")).replace(yiaeCEwJjOcWA4ZSd5h(u"ࠨษ็ห๋๋๊ี่ࠪᱱ"),ETNq5t4MYngSsbfFD8J0v(u"ࠩส๊๊๐ิ็ࠩᱲ")).replace(VHrIziKUDuNGXkMla(u"ࠪหๆ๊วๆ่ࠢืู้ไศฬࠪᱳ"),cjbAkCIinvs(u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬᱴ"))
					YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).strip(ww0sZkBU9JKd)
				if YwC7jt5BQHhTUvbdGeM6f2ZLx not in list(y2authQZX56sVUGEdNpFOzKD40cgw.keys()): y2authQZX56sVUGEdNpFOzKD40cgw[YwC7jt5BQHhTUvbdGeM6f2ZLx] = {}
				y2authQZX56sVUGEdNpFOzKD40cgw[YwC7jt5BQHhTUvbdGeM6f2ZLx][oob2dzmG3jTMpZwQyIfN] = [Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge]
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,FWqeEzO1i8Dn0ga(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭ᱵ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫᱶ"),y2authQZX56sVUGEdNpFOzKD40cgw,UKDwMTZk9dni1JSLcf0oRXhqy)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱷ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧᱸ"))
	ggGCyoxkHXwif(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
	NNetFngY7vowQPJp5xCumG2qrKcfk1()
	return
def v8pUC16gkEG(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM):
	BM9q472Scdmj0 = ETNq5t4MYngSsbfFD8J0v(u"ࡋࡧ࡬ࡴࡧṭ")
	UzkbHgRAS0NrWYB = eANQpmZPJaI7wc8
	eANQpmZPJaI7wc8[:] = []
	if BM9q472Scdmj0 and wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᱹ") not in m5qG0Lfhadn7kzVQSsM:
		tRojAyBgfDH37eLCwP4dWl = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,rxWDdRBIct57i90s(u"ࠪࡰ࡮ࡹࡴࠨᱺ"),VHrIziKUDuNGXkMla(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫᱻ"),UighHKAfySm4PWErqJ(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭ᱼ")+Gzo1nsVM84m6abfISDup9xjQdBO)
	elif ETNq5t4MYngSsbfFD8J0v(u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭ᱽ") not in m5qG0Lfhadn7kzVQSsM or GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡠࡘࡒࡈࡤ࠭᱾") not in m5qG0Lfhadn7kzVQSsM:
		import QMzke4oxuJ
		JPhoBimWUM0Gu2H1Fe9fRv8 = UighHKAfySm4PWErqJ(u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭᱿")
		if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩᲀ") not in m5qG0Lfhadn7kzVQSsM:
			try: QMzke4oxuJ.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,VHrIziKUDuNGXkMla(u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᲁ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+dC3PsQJ0Ti28uYlov(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲂ"),iqHhJSxdaANDG5rlZm7B(u"ࡌࡡ࡭ࡵࡨṮ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᲃ"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: QMzke4oxuJ.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,t2sCrJ0xbgDRkf(u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᲄ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲅ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࡆࡢ࡮ࡶࡩṯ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩᲆ"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: QMzke4oxuJ.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,VHrIziKUDuNGXkMla(u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᲇ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᲈ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࡇࡣ࡯ࡷࡪṰ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬᲉ"),JPhoBimWUM0Gu2H1Fe9fRv8)
		if cJSNFCIhymEfx6grGu0M(u"ࠬࡥࡖࡐࡆࡢࠫᲊ") not in m5qG0Lfhadn7kzVQSsM:
			try: QMzke4oxuJ.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᲋"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+cjbAkCIinvs(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᲌"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࡈࡤࡰࡸ࡫ṱ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไใ่๋หฯ࠭᲍"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: QMzke4oxuJ.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,FWqeEzO1i8Dn0ga(u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ᲎"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+iAGgjwb7tVMmacRJ(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᲏"),UighHKAfySm4PWErqJ(u"ࡉࡥࡱࡹࡥṲ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩᲐ"),JPhoBimWUM0Gu2H1Fe9fRv8)
		tRojAyBgfDH37eLCwP4dWl = eANQpmZPJaI7wc8
		if BM9q472Scdmj0: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,jR9YtmsgDX8nTQlMb6G3(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᲑ"),cJSNFCIhymEfx6grGu0M(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧᲒ")+Gzo1nsVM84m6abfISDup9xjQdBO,tRojAyBgfDH37eLCwP4dWl,UKDwMTZk9dni1JSLcf0oRXhqy)
	eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB
	return tRojAyBgfDH37eLCwP4dWl
def xoap9TC4RAkK1INwX3eEb7(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM):
	BM9q472Scdmj0 = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࡊࡦࡲࡳࡦṳ")
	UzkbHgRAS0NrWYB = eANQpmZPJaI7wc8
	eANQpmZPJaI7wc8[:] = []
	if BM9q472Scdmj0 and cjbAkCIinvs(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᲓ") not in m5qG0Lfhadn7kzVQSsM:
		tRojAyBgfDH37eLCwP4dWl = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,qTVF3icWwGXy5(u"ࠨ࡮࡬ࡷࡹ࠭Ე"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨᲕ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪᲖ")+Gzo1nsVM84m6abfISDup9xjQdBO)
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡤࡒࡉࡗࡇࡢࠫᲗ") not in m5qG0Lfhadn7kzVQSsM or hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡥࡖࡐࡆࡢࠫᲘ") not in m5qG0Lfhadn7kzVQSsM:
		import UUQbsdSjoM
		JPhoBimWUM0Gu2H1Fe9fRv8 = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫᲙ")
		if rr7Xolsp4JwjPK3L(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᲚ") not in m5qG0Lfhadn7kzVQSsM:
			try: UUQbsdSjoM.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᲛ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᲜ"),rr7Xolsp4JwjPK3L(u"ࡋࡧ࡬ࡴࡧṴ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"้ࠪํู่ࠡโࡐ࠷࡚ࠦไๅใํำ๏๎็ศฬࠪᲝ"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: UUQbsdSjoM.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,dC3PsQJ0Ti28uYlov(u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᲞ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲟ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࡌࡡ࡭ࡵࡨṵ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭Რ"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: UUQbsdSjoM.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᲡ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ტ"),rr7Xolsp4JwjPK3L(u"ࡆࡢ࡮ࡶࡩṶ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᲣ"),JPhoBimWUM0Gu2H1Fe9fRv8)
		if t2sCrJ0xbgDRkf(u"ࠪࡣ࡛ࡕࡄࡠࠩᲤ") not in m5qG0Lfhadn7kzVQSsM:
			try: UUQbsdSjoM.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,cJSNFCIhymEfx6grGu0M(u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᲥ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᲦ"),qTVF3icWwGXy5(u"ࡇࡣ࡯ࡷࡪṷ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่็์่ศฬࠪᲧ"),JPhoBimWUM0Gu2H1Fe9fRv8)
			try: UUQbsdSjoM.RlObognJh9DjiHyIE54(Gzo1nsVM84m6abfISDup9xjQdBO,iAGgjwb7tVMmacRJ(u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭Შ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,m5qG0Lfhadn7kzVQSsM+yiaeCEwJjOcWA4ZSd5h(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ჩ"),iqHhJSxdaANDG5rlZm7B(u"ࡈࡤࡰࡸ࡫Ṹ"))
			except: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭Ც"),JPhoBimWUM0Gu2H1Fe9fRv8)
		tRojAyBgfDH37eLCwP4dWl = eANQpmZPJaI7wc8
		if BM9q472Scdmj0: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᲫ"),iAGgjwb7tVMmacRJ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫᲬ")+Gzo1nsVM84m6abfISDup9xjQdBO,tRojAyBgfDH37eLCwP4dWl,UKDwMTZk9dni1JSLcf0oRXhqy)
	eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB
	return tRojAyBgfDH37eLCwP4dWl
def iGwPCjz1NVpE37x50odLauWUhSYF(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM,LdsXMNOgfjQe7YKIoP):
	if LdsXMNOgfjQe7YKIoP: Z0T74gk1RHfUoSKcAOWPQsalBuh(kkMuQrLWcEayRm)
	elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᲭ") in m5qG0Lfhadn7kzVQSsM and not LdsXMNOgfjQe7YKIoP: Z0T74gk1RHfUoSKcAOWPQsalBuh(P5VqbRSzjtO4UE1rZaolG67XA)
	xx6yDOustoTJHLpWlqG = m5qG0Lfhadn7kzVQSsM.replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᲮ"),G9G0YqivIfmUWO8K).replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᲯ"),G9G0YqivIfmUWO8K).replace(ssGdubC4mngM9D5SRc3Ye(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᲰ"),G9G0YqivIfmUWO8K)
	if not LdsXMNOgfjQe7YKIoP:
		Qm8SMu6ecXtigDCWw1oak(RVpeGcmPxj9tCnT40Nf216(u"ࠩ࡯࡭ࡳࡱࠧᲱ"),cJSNFCIhymEfx6grGu0M(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡษ็ว็ูวๆࠩᲲ"),G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"࠹࠹࠷ḫ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᲳ")+xx6yDOustoTJHLpWlqG,G9G0YqivIfmUWO8K,{ETNq5t4MYngSsbfFD8J0v(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᲴ"):Gzo1nsVM84m6abfISDup9xjQdBO})
		Qm8SMu6ecXtigDCWw1oak(rxWDdRBIct57i90s(u"࠭࡬ࡪࡰ࡮ࠫᲵ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+RVpeGcmPxj9tCnT40Nf216(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᲶ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"࠼࠽࠾࠿Ḭ"))
		PHNnGoTBQS1iLO5lKa = [EHUAyW2lQfe4LXmhgIGc(u"ࠨลไ่ฬ๋ࠧᲷ"),jR9YtmsgDX8nTQlMb6G3(u"่ࠩืู้ไศฬࠪᲸ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ุ้ࠪือ๋ษอࠫᲹ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫอืวๆฮࠪᲺ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬษืโษ็ࠤํ้ัห๊้ࠫ᲻"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ัๆุส๊ࠬ᲼"),RVpeGcmPxj9tCnT40Nf216(u"ࠧฤฯาฯ࠲ษฮาࠩᲽ"),t2sCrJ0xbgDRkf(u"ࠨี็หุ๊ࠧᲾ"),iAGgjwb7tVMmacRJ(u"่ࠩ์ุ๐โ๊ࠩᲿ"),qTVF3icWwGXy5(u"ࠪวูํั࠮ลๆฯึ࠭᳀"),cJSNFCIhymEfx6grGu0M(u"ࠫฬ๊ย็ࠩ᳁"),rxWDdRBIct57i90s(u"ࠬ฼อไࠩ᳂"),dC3PsQJ0Ti28uYlov(u"࠭ั๋ษูอࠬ᳃"),EHUAyW2lQfe4LXmhgIGc(u"ࠧ็์อๅ้้ำࠨ᳄"),rxWDdRBIct57i90s(u"ࠨ็่ฯ้๐ๆࠨ᳅"),FWqeEzO1i8Dn0ga(u"ࠩหฯࠥำ๊ࠨ᳆"),ssGdubC4mngM9D5SRc3Ye(u"ࠪำ๏์๊สࠩ᳇"),iqHhJSxdaANDG5rlZm7B(u"ุࠫ์่ศฬࠪ᳈"),ssGdubC4mngM9D5SRc3Ye(u"ࠬษฮา๋ࠪ᳉")]
		LdsXMNOgfjQe7YKIoP = dQ5JhEYolPmy1fvHktMw6NFRxiz
		for vTBg3arXYqMsiL in PHNnGoTBQS1iLO5lKa:
			LdsXMNOgfjQe7YKIoP += fdQOo6Hu4B5Rbg
			Qm8SMu6ecXtigDCWw1oak(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᳊"),TdtCLWYSJNK8zOb+vTBg3arXYqMsiL,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"࠻࠻࠹ḭ"),G9G0YqivIfmUWO8K,str(LdsXMNOgfjQe7YKIoP),xx6yDOustoTJHLpWlqG,G9G0YqivIfmUWO8K,{UighHKAfySm4PWErqJ(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳋"):Gzo1nsVM84m6abfISDup9xjQdBO})
	else:
		voI5nUyCWpbDQ1K2x07hNumdjJ = [GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨษไ่ฬ๋ࠧ᳌"),iqHhJSxdaANDG5rlZm7B(u"ࠩࡰࡳࡻ࡯ࡥࠨ᳍"),DTF3Lwy9etRH8mI(u"ࠪๅ๏๊ๅࠨ᳎"),dC3PsQJ0Ti28uYlov(u"ࠫๆ๊ๅࠨ᳏")]
		k6V25enhgRWdHu = [FWqeEzO1i8Dn0ga(u"๋ࠬำๅี็ࠫ᳐"),ssGdubC4mngM9D5SRc3Ye(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭᳑")]
		wF56fWrLyP9dkoQ = [yiaeCEwJjOcWA4ZSd5h(u"ࠧๆีสีา࠭᳒"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ็ึีา๐วหࠩ᳓")]
		bpHrysUNOnXW = [RVpeGcmPxj9tCnT40Nf216(u"ࠩหีฬ๋ฬࠨ᳔"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡷ࡭ࡵࡷࠨ᳕"),dC3PsQJ0Ti28uYlov(u"ࠫฯ๊แำ์๋๊᳖ࠬ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬะไ๋ใี๎ํ์᳗ࠧ")]
		ssk5F34ZeQzPurAy0M = [ssGdubC4mngM9D5SRc3Ye(u"࠭ว็็ํ᳘ࠫ"),cjbAkCIinvs(u"ࠧไำอ์๋᳙࠭"),qTVF3icWwGXy5(u"ࠨๅสีฯ๎ๆࠨ᳚"),UighHKAfySm4PWErqJ(u"ࠩ࡮࡭ࡩࡹࠧ᳛"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ฻ๆ๊᳜ࠧ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫฬ฽แศๆ᳝ࠪ")]
		vvrQtSqguG8syYz1Roe = [iqHhJSxdaANDG5rlZm7B(u"ࠬืๅืษ้᳞ࠫ")]
		HDY16Cs8Q2qxREhZ3Iw = [ssGdubC4mngM9D5SRc3Ye(u"࠭วฮัฮ᳟ࠫ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠧศะิࠫ᳠"),t2sCrJ0xbgDRkf(u"ࠨ็๋าึ࠭᳡"),rr7Xolsp4JwjPK3L(u"ࠩฯำ๏ี᳢ࠧ"),dC3PsQJ0Ti28uYlov(u"้ࠪ฻อแࠨ᳣"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫาี๊ฬ᳤ࠩ")]
		xfyqPGubwsdecoVRIZYpXn5UD8Mr9 = [bneABYmwFUH8GXphg0Kl2Sq(u"ูࠬไศี็᳥ࠫ"),t2sCrJ0xbgDRkf(u"࠭ำๅี็᳦๋ࠬ")]
		YYhl8wacyHIp7L5N0mAFvgE = [VHrIziKUDuNGXkMla(u"ࠧศ฼ส๊๏᳧࠭"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ็๋ื๏่้ࠨ᳨"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩๆ่๏ฮࠧᳩ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪัๆ๊ࠧᳪ"),EHUAyW2lQfe4LXmhgIGc(u"ࠫࡲࡻࡳࡪࡥࠪᳫ")]
		tLa0BZj9d1MJfecAuUG = [VHrIziKUDuNGXkMla(u"ࠬอใฬำࠪᳬ"),RVpeGcmPxj9tCnT40Nf216(u"࠭วี้ิ᳭ࠫ"),jR9YtmsgDX8nTQlMb6G3(u"ࠧๆ็ํึ์࠭ᳮ"),dC3PsQJ0Ti28uYlov(u"ࠨษ฼่๎࠭ᳯ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"่ࠩาฯอั่ࠩᳰ"),EHUAyW2lQfe4LXmhgIGc(u"้ࠪำะวาษอࠫᳱ"),ssGdubC4mngM9D5SRc3Ye(u"ࠫฬ่่๊ࠩᳲ")]
		Lkq7YmEUPC8xBycRs3Mhfzua = [RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬอไศ่ࠪᳳ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭อศๆํࠫ᳴"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧๆอหฮࠬᳵ"),iqHhJSxdaANDG5rlZm7B(u"ࠨำสสั࠭ᳶ")]
		qcbwr8tE9ah7QW = [RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ูࠩั่࠭᳷"),FWqeEzO1i8Dn0ga(u"ࠪ็ํ๋๊ะ์ࠪ᳸")]
		sOZiHArDGepuwJh1z845qLF = [vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫึ๐วื้ࠪ᳹"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"้่ࠬา้ࠪᳺ"),FWqeEzO1i8Dn0ga(u"࠭ๅึษิ฽์࠭᳻"),UighHKAfySm4PWErqJ(u"ࠧี๊อࠫ᳼"),jR9YtmsgDX8nTQlMb6G3(u"ࠨำํห฻ฯࠧ᳽")]
		LoR6dvWnBX = [wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"้ࠩ๎ฯ็ไไีࠪ᳾"),yiaeCEwJjOcWA4ZSd5h(u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫ᳿"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"๋ࠫ๐สโๆํ็ุ࠭ᴀ")]
		BIEY4h1FVRlzXc6N8oMgdvJsaWq = [dC3PsQJ0Ti28uYlov(u"๋ࠬๅฬๆํ๊ࠬᴁ"),VHrIziKUDuNGXkMla(u"࠭วีะสูࠬᴂ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ็ฮ๋้ࠬᴃ")]
		ooMbFZDa6xRHXp = [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨสฮࠤา๐ࠧᴄ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡯࡭ࡻ࡫ࠧᴅ"),ssGdubC4mngM9D5SRc3Ye(u"ࠪๆ๋อ็ࠨᴆ"),qTVF3icWwGXy5(u"ࠫ็์่ศฬࠪᴇ")]
		aKPJvwClNyYhq = [RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬี๊็ࠩᴈ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭วะ฻ํ๋ࠬᴉ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧำ์สีฬะࠧᴊ"),ETNq5t4MYngSsbfFD8J0v(u"ࠨๆฺ้๏อสࠨᴋ"),EHUAyW2lQfe4LXmhgIGc(u"ࠩา฽ฬวࠧᴌ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪๆึอๆࠨᴍ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ็฻ววัࠪᴎ"),iAGgjwb7tVMmacRJ(u"ࠬืหศรࠪᴏ"),qTVF3icWwGXy5(u"࠭ๅาฮ฼๎์࠭ᴐ"),VHrIziKUDuNGXkMla(u"ࠧศาส๊ࠬᴑ"),dC3PsQJ0Ti28uYlov(u"ࠨษึ่ฬ๋ࠧᴒ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩอ์ฬฺ๊ฮࠩᴓ"),rxWDdRBIct57i90s(u"ࠪา฼ฮࠧᴔ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫา๎า้์ࠪᴕ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬ฿สษษอࠫᴖ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ๅ้ษ็๎ิ࠭ᴗ"),dC3PsQJ0Ti28uYlov(u"ࠧ็๊ส฽๏࠭ᴘ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨ฻ๅหหีࠧᴙ"),ssGdubC4mngM9D5SRc3Ye(u"ࠩส๊ฬฺ๊ะࠩᴚ")]
		sYDuIfoPlZmQX1da = [rxWDdRBIct57i90s(u"ࠪ࠶࠵࠷࠰ࠨᴛ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠷࠶࠱࠲ࠩᴜ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬ࠸࠰࠲࠴ࠪᴝ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࠲࠱࠳࠶ࠫᴞ"),DTF3Lwy9etRH8mI(u"ࠧ࠳࠲࠴࠸ࠬᴟ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ࠴࠳࠵࠺࠭ᴠ"),rr7Xolsp4JwjPK3L(u"ࠩ࠵࠴࠶࠼ࠧᴡ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠪ࠶࠵࠷࠷ࠨᴢ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫ࠷࠶࠱࠹ࠩᴣ"),yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠸࠰࠲࠻ࠪᴤ"),jR9YtmsgDX8nTQlMb6G3(u"࠭࠲࠱࠴࠳ࠫᴥ"),UighHKAfySm4PWErqJ(u"ࠧ࠳࠲࠵࠵ࠬᴦ"),EHUAyW2lQfe4LXmhgIGc(u"ࠨ࠴࠳࠶࠷࠭ᴧ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࠵࠴࠷࠹ࠧᴨ"),cjbAkCIinvs(u"ࠪ࠶࠵࠸࠴ࠨᴩ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠷࠶࠲࠶ࠩᴪ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬ࠸࠰࠳࠸ࠪᴫ"),yiaeCEwJjOcWA4ZSd5h(u"࠭࠲࠱࠴࠺ࠫᴬ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࠳࠲࠵࠼ࠬᴭ")]
		for YwC7jt5BQHhTUvbdGeM6f2ZLx in sorted(list(y2authQZX56sVUGEdNpFOzKD40cgw.keys())):
			mpniyIdLxTPW3BN8UcY2v = YwC7jt5BQHhTUvbdGeM6f2ZLx.lower()
			nxguK9laUWBGHIR4zEsTo7 = []
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in voI5nUyCWpbDQ1K2x07hNumdjJ): nxguK9laUWBGHIR4zEsTo7.append(fdQOo6Hu4B5Rbg)
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in k6V25enhgRWdHu): nxguK9laUWBGHIR4zEsTo7.append(SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU)
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in wF56fWrLyP9dkoQ): nxguK9laUWBGHIR4zEsTo7.append(c1R9fnIY4XBDZ)
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in bpHrysUNOnXW): nxguK9laUWBGHIR4zEsTo7.append(xsCEkXb6tgrh3195YZ)
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in ssk5F34ZeQzPurAy0M): nxguK9laUWBGHIR4zEsTo7.append(qTVF3icWwGXy5(u"࠺Ḯ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in vvrQtSqguG8syYz1Roe): nxguK9laUWBGHIR4zEsTo7.append(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠼ḯ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in HDY16Cs8Q2qxREhZ3Iw) and mpniyIdLxTPW3BN8UcY2v not in [t2sCrJ0xbgDRkf(u"ࠨษัี๎࠭ᴮ")]: nxguK9laUWBGHIR4zEsTo7.append(DTF3Lwy9etRH8mI(u"࠷Ḱ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in xfyqPGubwsdecoVRIZYpXn5UD8Mr9): nxguK9laUWBGHIR4zEsTo7.append(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹ḱ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in YYhl8wacyHIp7L5N0mAFvgE): nxguK9laUWBGHIR4zEsTo7.append(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠻Ḳ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in tLa0BZj9d1MJfecAuUG): nxguK9laUWBGHIR4zEsTo7.append(cjbAkCIinvs(u"࠴࠴ḳ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in Lkq7YmEUPC8xBycRs3Mhfzua): nxguK9laUWBGHIR4zEsTo7.append(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠵࠶Ḵ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in qcbwr8tE9ah7QW): nxguK9laUWBGHIR4zEsTo7.append(dC3PsQJ0Ti28uYlov(u"࠶࠸ḵ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in sOZiHArDGepuwJh1z845qLF): nxguK9laUWBGHIR4zEsTo7.append(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠷࠳Ḷ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in LoR6dvWnBX): nxguK9laUWBGHIR4zEsTo7.append(rr7Xolsp4JwjPK3L(u"࠱࠵ḷ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in BIEY4h1FVRlzXc6N8oMgdvJsaWq): nxguK9laUWBGHIR4zEsTo7.append(iqHhJSxdaANDG5rlZm7B(u"࠲࠷Ḹ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in ooMbFZDa6xRHXp): nxguK9laUWBGHIR4zEsTo7.append(FWqeEzO1i8Dn0ga(u"࠳࠹ḹ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in aKPJvwClNyYhq): nxguK9laUWBGHIR4zEsTo7.append(rxWDdRBIct57i90s(u"࠴࠻Ḻ"))
			if any(yW70dtahIjkPCJg2TA in mpniyIdLxTPW3BN8UcY2v for yW70dtahIjkPCJg2TA in sYDuIfoPlZmQX1da): nxguK9laUWBGHIR4zEsTo7.append(UighHKAfySm4PWErqJ(u"࠵࠽ḻ"))
			if not nxguK9laUWBGHIR4zEsTo7: nxguK9laUWBGHIR4zEsTo7 = [EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠶࠿Ḽ")]
			for oo7kpizdm9Yvg in nxguK9laUWBGHIR4zEsTo7:
				if str(oo7kpizdm9Yvg)==LdsXMNOgfjQe7YKIoP:
					Qm8SMu6ecXtigDCWw1oak(jR9YtmsgDX8nTQlMb6G3(u"ࠩࡩࡳࡱࡪࡥࡳࠩᴯ"),TdtCLWYSJNK8zOb+YwC7jt5BQHhTUvbdGeM6f2ZLx,YwC7jt5BQHhTUvbdGeM6f2ZLx,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠶࠷ḽ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,xx6yDOustoTJHLpWlqG+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᴰ"))
	return
def OrsJThENqZ3yuUV8YXLxiW67wb(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM):
	BM9q472Scdmj0 = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࡉࡥࡱࡹࡥṹ")
	if BM9q472Scdmj0:
		Qm8SMu6ecXtigDCWw1oak(t2sCrJ0xbgDRkf(u"ࠫࡱ࡯࡮࡬ࠩᴱ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬะอะ์ฮࠤ็อฦๆหࠣว็ูวๆࠢࡌࡔ࡙࡜ࠧᴲ"),G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠷࠷࠶Ḿ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫᴳ"),G9G0YqivIfmUWO8K,{EHUAyW2lQfe4LXmhgIGc(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴴ"):Gzo1nsVM84m6abfISDup9xjQdBO})
		Qm8SMu6ecXtigDCWw1oak(EHUAyW2lQfe4LXmhgIGc(u"ࠨ࡮࡬ࡲࡰ࠭ᴵ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+iqHhJSxdaANDG5rlZm7B(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᴶ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠺࠻࠼࠽ḿ"))
	UzkbHgRAS0NrWYB = eANQpmZPJaI7wc8[:]
	import QMzke4oxuJ
	if Gzo1nsVM84m6abfISDup9xjQdBO:
		if not QMzke4oxuJ.eia6WyskqpVGdRYrM0xLuUTOw(Gzo1nsVM84m6abfISDup9xjQdBO,ETNq5t4MYngSsbfFD8J0v(u"ࡘࡷࡻࡥṺ")): return
		FeNHpnkAZ8Kx1r5utQm6CJPT0B = v8pUC16gkEG(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM)
		hayNktUR2Tq8g = sorted(FeNHpnkAZ8Kx1r5utQm6CJPT0B,reverse=RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࡋࡧ࡬ࡴࡧṻ"),key=lambda key: key[fdQOo6Hu4B5Rbg].lower())
	else:
		if not QMzke4oxuJ.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࡚ࡲࡶࡧṼ")): return
		if BM9q472Scdmj0 and GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨᴷ") not in m5qG0Lfhadn7kzVQSsM:
			hayNktUR2Tq8g = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,yiaeCEwJjOcWA4ZSd5h(u"ࠫࡱ࡯ࡳࡵࠩᴸ"),cJSNFCIhymEfx6grGu0M(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬᴹ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪᴺ"))
		else:
			PaAepCn2gJxr0YVTlhHoF,hayNktUR2Tq8g,FeNHpnkAZ8Kx1r5utQm6CJPT0B = [],[],[]
			for XkavsVbtdU6BLu5gyE9fwmzASKpli in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
				hayNktUR2Tq8g += v8pUC16gkEG(str(XkavsVbtdU6BLu5gyE9fwmzASKpli),m5qG0Lfhadn7kzVQSsM)
			for type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in hayNktUR2Tq8g:
				if Vvju9Ht8SGxoiTa6lCs not in PaAepCn2gJxr0YVTlhHoF:
					PaAepCn2gJxr0YVTlhHoF.append(Vvju9Ht8SGxoiTa6lCs)
					kFoHN4ADd6QM8 = type,YwC7jt5BQHhTUvbdGeM6f2ZLx,Vvju9Ht8SGxoiTa6lCs,cjbAkCIinvs(u"࠳࠹࠹Ṁ"),Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,m5qG0Lfhadn7kzVQSsM,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3
					FeNHpnkAZ8Kx1r5utQm6CJPT0B.append(kFoHN4ADd6QM8)
			hayNktUR2Tq8g = sorted(FeNHpnkAZ8Kx1r5utQm6CJPT0B,reverse=UighHKAfySm4PWErqJ(u"ࡆࡢ࡮ࡶࡩṽ"),key=lambda key: key[fdQOo6Hu4B5Rbg].lower())
			if BM9q472Scdmj0: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,iqHhJSxdaANDG5rlZm7B(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧᴻ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬᴼ"),hayNktUR2Tq8g,UKDwMTZk9dni1JSLcf0oRXhqy)
	eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g
	Wz9Lj5vK4qeIBn1rTP20y78aogJ(iqHhJSxdaANDG5rlZm7B(u"ࡇࡣ࡯ࡷࡪṾ"))
	return
def jS0h3RN6YpyZOwVfuMT7W8LHPE4KGF(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM):
	BM9q472Scdmj0 = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࡈࡤࡰࡸ࡫ṿ")
	if BM9q472Scdmj0:
		Qm8SMu6ecXtigDCWw1oak(ssGdubC4mngM9D5SRc3Ye(u"ࠩ࡯࡭ࡳࡱࠧᴽ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪฮาี๊ฬࠢๅหห๋ษࠡลๅืฬ๋ࠠࡎ࠵ࡘࠫᴾ"),G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"࠺࠺࠺ṁ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᴿ"),G9G0YqivIfmUWO8K,{VHrIziKUDuNGXkMla(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵀ"):Gzo1nsVM84m6abfISDup9xjQdBO})
		Qm8SMu6ecXtigDCWw1oak(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭࡬ࡪࡰ࡮ࠫᵁ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+EHUAyW2lQfe4LXmhgIGc(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᵂ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠽࠾࠿࠹Ṃ"))
	UzkbHgRAS0NrWYB = eANQpmZPJaI7wc8[:]
	import UUQbsdSjoM
	if Gzo1nsVM84m6abfISDup9xjQdBO:
		if not UUQbsdSjoM.eia6WyskqpVGdRYrM0xLuUTOw(Gzo1nsVM84m6abfISDup9xjQdBO,bneABYmwFUH8GXphg0Kl2Sq(u"ࡗࡶࡺ࡫Ẁ")): return
		FeNHpnkAZ8Kx1r5utQm6CJPT0B = xoap9TC4RAkK1INwX3eEb7(Gzo1nsVM84m6abfISDup9xjQdBO,m5qG0Lfhadn7kzVQSsM)
		hayNktUR2Tq8g = sorted(FeNHpnkAZ8Kx1r5utQm6CJPT0B,reverse=RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࡊࡦࡲࡳࡦẁ"),key=lambda key: key[fdQOo6Hu4B5Rbg].lower())
	else:
		if not UUQbsdSjoM.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࡙ࡸࡵࡦẂ")): return
		if BM9q472Scdmj0 and vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᵃ") not in m5qG0Lfhadn7kzVQSsM:
			hayNktUR2Tq8g = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,iAGgjwb7tVMmacRJ(u"ࠩ࡯࡭ࡸࡺࠧᵄ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩᵅ"),UighHKAfySm4PWErqJ(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧᵆ"))
		else:
			PaAepCn2gJxr0YVTlhHoF,hayNktUR2Tq8g,FeNHpnkAZ8Kx1r5utQm6CJPT0B = [],[],[]
			for XkavsVbtdU6BLu5gyE9fwmzASKpli in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
				hayNktUR2Tq8g += xoap9TC4RAkK1INwX3eEb7(str(XkavsVbtdU6BLu5gyE9fwmzASKpli),m5qG0Lfhadn7kzVQSsM)
			for type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in hayNktUR2Tq8g:
				if Vvju9Ht8SGxoiTa6lCs not in PaAepCn2gJxr0YVTlhHoF:
					PaAepCn2gJxr0YVTlhHoF.append(Vvju9Ht8SGxoiTa6lCs)
					kFoHN4ADd6QM8 = type,YwC7jt5BQHhTUvbdGeM6f2ZLx,Vvju9Ht8SGxoiTa6lCs,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠶࠼࠵ṃ"),Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,m5qG0Lfhadn7kzVQSsM,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3
					FeNHpnkAZ8Kx1r5utQm6CJPT0B.append(kFoHN4ADd6QM8)
			hayNktUR2Tq8g = sorted(FeNHpnkAZ8Kx1r5utQm6CJPT0B,reverse=rr7Xolsp4JwjPK3L(u"ࡌࡡ࡭ࡵࡨẃ"),key=lambda key: key[fdQOo6Hu4B5Rbg].lower())
			if BM9q472Scdmj0: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫᵇ"),UighHKAfySm4PWErqJ(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩᵈ"),hayNktUR2Tq8g,UKDwMTZk9dni1JSLcf0oRXhqy)
	eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g
	Wz9Lj5vK4qeIBn1rTP20y78aogJ(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࡆࡢ࡮ࡶࡩẄ"))
	return
def qu0rJOKYgoaIs4Q(group,m5qG0Lfhadn7kzVQSsM):
	BM9q472Scdmj0 = dC3PsQJ0Ti28uYlov(u"ࡇࡣ࡯ࡷࡪẅ")
	tRojAyBgfDH37eLCwP4dWl = []
	fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b = UighHKAfySm4PWErqJ(u"ࠧࡠࡋࡓࡘ࡛ࡥࠧᵉ") if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡋࡓࡘ࡛࠭ᵊ") in m5qG0Lfhadn7kzVQSsM else ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡢࡑ࠸࡛࡟ࠨᵋ")
	if BM9q472Scdmj0: tRojAyBgfDH37eLCwP4dWl = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,FWqeEzO1i8Dn0ga(u"ࠪࡰ࡮ࡹࡴࠨᵌ"),RVpeGcmPxj9tCnT40Nf216(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘ࠭ᵍ")+fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b[:-qTVF3icWwGXy5(u"࠷Ṅ")],group)
	if not tRojAyBgfDH37eLCwP4dWl:
		for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
			if BM9q472Scdmj0: tRojAyBgfDH37eLCwP4dWl += PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡲࡩࡴࡶࠪᵎ"),rxWDdRBIct57i90s(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨᵏ")+fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b[:-fdQOo6Hu4B5Rbg],RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᵐ")+fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b+str(Gzo1nsVM84m6abfISDup9xjQdBO))
			elif fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡡࡌࡔ࡙࡜࡟ࠨᵑ"): tRojAyBgfDH37eLCwP4dWl += v8pUC16gkEG(str(Gzo1nsVM84m6abfISDup9xjQdBO),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᵒ"))
			elif fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b==yiaeCEwJjOcWA4ZSd5h(u"ࠪࡣࡒ࠹ࡕࡠࠩᵓ"): tRojAyBgfDH37eLCwP4dWl += xoap9TC4RAkK1INwX3eEb7(str(Gzo1nsVM84m6abfISDup9xjQdBO),FWqeEzO1i8Dn0ga(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᵔ"))
		for type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in tRojAyBgfDH37eLCwP4dWl:
			if Vvju9Ht8SGxoiTa6lCs==group: TadilgrWnheCzbZI4LHv1S7DVB(type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
		items,qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = [],[]
		for type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in eANQpmZPJaI7wc8:
			Htk1LgouSsaEZ0KO7Ux = type,YwC7jt5BQHhTUvbdGeM6f2ZLx[xsCEkXb6tgrh3195YZ:],url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,G9G0YqivIfmUWO8K
			if Htk1LgouSsaEZ0KO7Ux not in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv.append(Htk1LgouSsaEZ0KO7Ux)
				XX2Btn97vEfkCjcuWs = type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3
				items.append(XX2Btn97vEfkCjcuWs)
		tRojAyBgfDH37eLCwP4dWl = sorted(items,reverse=cjbAkCIinvs(u"ࡈࡤࡰࡸ࡫Ẇ"),key=lambda key: key[fdQOo6Hu4B5Rbg].lower()[ETNq5t4MYngSsbfFD8J0v(u"࠵ṅ"):])
		if BM9q472Scdmj0: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧᵕ")+fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b[:-fdQOo6Hu4B5Rbg],group,tRojAyBgfDH37eLCwP4dWl,UKDwMTZk9dni1JSLcf0oRXhqy)
	if dC3PsQJ0Ti28uYlov(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᵖ") in m5qG0Lfhadn7kzVQSsM and len(tRojAyBgfDH37eLCwP4dWl)>HuskB0c1Ob3r6CLiJXTyx:
		eANQpmZPJaI7wc8[:] = []
		Qm8SMu6ecXtigDCWw1oak(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᵗ"),dC3PsQJ0Ti28uYlov(u"ࠨ࡝ࠪᵘ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+group+zzGfwLAyN5HTxUoJeaivY+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࠣ࠾ฬ๊โิ็ࡠࠫᵙ"),group,rxWDdRBIct57i90s(u"࠲࠸࠸Ṇ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b+cjbAkCIinvs(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵚ"))
		Qm8SMu6ecXtigDCWw1oak(RVpeGcmPxj9tCnT40Nf216(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᵛ"),UighHKAfySm4PWErqJ(u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫᵜ"),group,qTVF3icWwGXy5(u"࠳࠹࠹ṇ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,fNWAdVMT3xZvjoc8BwLIJyHuS4Dl7b+bneABYmwFUH8GXphg0Kl2Sq(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵝ"))
		Qm8SMu6ecXtigDCWw1oak(ssGdubC4mngM9D5SRc3Ye(u"ࠧ࡭࡫ࡱ࡯ࠬᵞ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭ᵟ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"࠼࠽࠾࠿Ṉ"))
		tRojAyBgfDH37eLCwP4dWl = eANQpmZPJaI7wc8+voWS3GzbN5HXaTsiwLMeU.sample(tRojAyBgfDH37eLCwP4dWl,HuskB0c1Ob3r6CLiJXTyx)
	eANQpmZPJaI7wc8[:] = tRojAyBgfDH37eLCwP4dWl
	Wz9Lj5vK4qeIBn1rTP20y78aogJ(rxWDdRBIct57i90s(u"ࡉࡥࡱࡹࡥẇ"))
	return
def Tp0qDh9i7Bg3SyKLsnJlI(m5qG0Lfhadn7kzVQSsM):
	Qm8SMu6ecXtigDCWw1oak(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡩࡳࡱࡪࡥࡳࠩᵠ"),DTF3Lwy9etRH8mI(u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭ᵡ"),G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠵࠻࠷ṉ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡏࡍ࡛ࡋࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࠫᵢ"))
	Qm8SMu6ecXtigDCWw1oak(FWqeEzO1i8Dn0ga(u"ࠬࡲࡩ࡯࡭ࠪᵣ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᵤ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠾࠿࠹࠺Ṋ"))
	ZrWkONIuojPHgt = eANQpmZPJaI7wc8[:]
	eANQpmZPJaI7wc8[:] = []
	import miH2b7Cvj3
	miH2b7Cvj3.Mt7X1vp6TLucKVrw8EUhyI(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠱ࠩᵥ"),EHUAyW2lQfe4LXmhgIGc(u"ࡊࡦࡲࡳࡦẈ"))
	miH2b7Cvj3.Mt7X1vp6TLucKVrw8EUhyI(FWqeEzO1i8Dn0ga(u"ࠨ࠳ࠪᵦ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࡋࡧ࡬ࡴࡧẉ"))
	miH2b7Cvj3.Mt7X1vp6TLucKVrw8EUhyI(iAGgjwb7tVMmacRJ(u"ࠩ࠵ࠫᵧ"),qTVF3icWwGXy5(u"ࡌࡡ࡭ࡵࡨẊ"))
	if hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬᵨ") in m5qG0Lfhadn7kzVQSsM:
		eANQpmZPJaI7wc8[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
		if len(eANQpmZPJaI7wc8)>HuskB0c1Ob3r6CLiJXTyx: eANQpmZPJaI7wc8[:] = voWS3GzbN5HXaTsiwLMeU.sample(eANQpmZPJaI7wc8,HuskB0c1Ob3r6CLiJXTyx)
	eANQpmZPJaI7wc8[:] = ZrWkONIuojPHgt+eANQpmZPJaI7wc8
	return
def OL6SteZlWC3quRfv970T(m5qG0Lfhadn7kzVQSsM):
	m5qG0Lfhadn7kzVQSsM = m5qG0Lfhadn7kzVQSsM.replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵩ"),G9G0YqivIfmUWO8K).replace(iAGgjwb7tVMmacRJ(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵪ"),G9G0YqivIfmUWO8K)
	headers = { DTF3Lwy9etRH8mI(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᵫ") : G9G0YqivIfmUWO8K }
	url = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡥࡴࡶࡵࡥࡳࡪ࡯࡮ࡵ࠱ࡧࡴࡳ࠯ࡳࡣࡱࡨࡴࡳ࠭ࡢࡴࡤࡦ࡮ࡩ࠭ࡸࡱࡵࡨࡸ࠭ᵬ")
	data = {EHUAyW2lQfe4LXmhgIGc(u"ࠨࡳࡸࡥࡳࡺࡩࡵࡻࠪᵭ"):qTVF3icWwGXy5(u"ࠩ࠸࠴ࠬᵮ")}
	data = tAPSK0wDYQhczOgZ(data)
	D7omduSeM5Gk = PPRoOyl2xVH(PvAZ1fCRqL5F,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡋࡊ࡚ࠧᵯ"),url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡗࡇࡎࡅࡑࡐࡗ࠲ࡘࡁࡏࡆࡒࡑࡤ࡜ࡉࡅࡇࡒࡗࡤࡌࡒࡐࡏࡢ࡛ࡔࡘࡄࡔ࠯࠴ࡷࡹ࠭ᵰ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(RVpeGcmPxj9tCnT40Nf216(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࡩ࡭ࡽࠨࠧᵱ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	items = oo9kuULlebNgpY0Om.findall(ssGdubC4mngM9D5SRc3Ye(u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᵲ"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ssBV2Ydg7JfcXaitIu,qdZbMB4Q0hH8CUT = list(zip(*items))
	tfSxh7XoJjE6TDzOmKnPAFLNi = []
	WMePYpEvuy41l97VXxdUSb = [ww0sZkBU9JKd,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࠣࠩᵳ"),iAGgjwb7tVMmacRJ(u"ࠨࡢࠪᵴ"),yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠯ࠫᵵ"),rxWDdRBIct57i90s(u"ࠪ࠲ࠬᵶ"),jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠿࠭ᵷ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡁࠧᵸ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࠧࠣᵹ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧ࠮ࠩᵺ")]
	mmgKAYOxwb = qdZbMB4Q0hH8CUT+ssBV2Ydg7JfcXaitIu
	for PAHuZI7do0tpO9vsr8X2CLGVME6 in mmgKAYOxwb:
		if PAHuZI7do0tpO9vsr8X2CLGVME6 in qdZbMB4Q0hH8CUT: J51S8WLK0cXP2z64smkEO3AI = SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
		if PAHuZI7do0tpO9vsr8X2CLGVME6 in ssBV2Ydg7JfcXaitIu: J51S8WLK0cXP2z64smkEO3AI = xsCEkXb6tgrh3195YZ
		SsQwGZuKVBkLYJzgRb3I0orfpWH = [KT9tdUH3hmiLZCEFz in PAHuZI7do0tpO9vsr8X2CLGVME6 for KT9tdUH3hmiLZCEFz in WMePYpEvuy41l97VXxdUSb]
		if any(SsQwGZuKVBkLYJzgRb3I0orfpWH):
			iT2wOVymHEMAhWl6jbJs8pY = SsQwGZuKVBkLYJzgRb3I0orfpWH.index(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࡔࡳࡷࡨẋ"))
			RRKzdo0F7s95nZ1QabeJMjEADYBI84 = WMePYpEvuy41l97VXxdUSb[iT2wOVymHEMAhWl6jbJs8pY]
			CLt0dJ6uKZOpXlwcAPaSsrxE7 = G9G0YqivIfmUWO8K
			if PAHuZI7do0tpO9vsr8X2CLGVME6.count(RRKzdo0F7s95nZ1QabeJMjEADYBI84)>fdQOo6Hu4B5Rbg: Q018bNv6fl2e,kyEG0lCSBFIZRno,CLt0dJ6uKZOpXlwcAPaSsrxE7 = PAHuZI7do0tpO9vsr8X2CLGVME6.split(RRKzdo0F7s95nZ1QabeJMjEADYBI84,SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU)
			else: Q018bNv6fl2e,kyEG0lCSBFIZRno = PAHuZI7do0tpO9vsr8X2CLGVME6.split(RRKzdo0F7s95nZ1QabeJMjEADYBI84,fdQOo6Hu4B5Rbg)
			if len(Q018bNv6fl2e)>J51S8WLK0cXP2z64smkEO3AI: tfSxh7XoJjE6TDzOmKnPAFLNi.append(Q018bNv6fl2e.lower())
			if len(kyEG0lCSBFIZRno)>J51S8WLK0cXP2z64smkEO3AI: tfSxh7XoJjE6TDzOmKnPAFLNi.append(kyEG0lCSBFIZRno.lower())
			if len(CLt0dJ6uKZOpXlwcAPaSsrxE7)>J51S8WLK0cXP2z64smkEO3AI: tfSxh7XoJjE6TDzOmKnPAFLNi.append(CLt0dJ6uKZOpXlwcAPaSsrxE7.lower())
		elif len(PAHuZI7do0tpO9vsr8X2CLGVME6)>J51S8WLK0cXP2z64smkEO3AI: tfSxh7XoJjE6TDzOmKnPAFLNi.append(PAHuZI7do0tpO9vsr8X2CLGVME6.lower())
	for KT9tdUH3hmiLZCEFz in range(bneABYmwFUH8GXphg0Kl2Sq(u"࠿ṋ")): voWS3GzbN5HXaTsiwLMeU.shuffle(tfSxh7XoJjE6TDzOmKnPAFLNi)
	if iAGgjwb7tVMmacRJ(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩᵻ") in m5qG0Lfhadn7kzVQSsM:
		TKdtbEk4zPJQ6hVew2ZvHWI8RcxA = jBCFu0HwftZ3XvQyOY
	elif RVpeGcmPxj9tCnT40Nf216(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩᵼ") in m5qG0Lfhadn7kzVQSsM:
		TKdtbEk4zPJQ6hVew2ZvHWI8RcxA = [cJSNFCIhymEfx6grGu0M(u"ࠪࡍࡕ࡚ࡖࠨᵽ")]
		import QMzke4oxuJ
		if not QMzke4oxuJ.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࡕࡴࡸࡩẌ")): return
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠫࡤࡓ࠳ࡖࡡࠪᵾ") in m5qG0Lfhadn7kzVQSsM:
		TKdtbEk4zPJQ6hVew2ZvHWI8RcxA = [RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡓ࠳ࡖࠩᵿ")]
		import UUQbsdSjoM
		if not UUQbsdSjoM.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࡖࡵࡹࡪẍ")): return
	count,s0deGTCN7Ktb2wORozQa = dQ5JhEYolPmy1fvHktMw6NFRxiz,dQ5JhEYolPmy1fvHktMw6NFRxiz
	Qm8SMu6ecXtigDCWw1oak(ETNq5t4MYngSsbfFD8J0v(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶀ"),t2sCrJ0xbgDRkf(u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨᶁ"),G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"࠱࠷࠶Ṍ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶂ")+m5qG0Lfhadn7kzVQSsM)
	Qm8SMu6ecXtigDCWw1oak(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶃ"),jR9YtmsgDX8nTQlMb6G3(u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪᶄ"),G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲࠸࠷ṍ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶅ")+m5qG0Lfhadn7kzVQSsM)
	Qm8SMu6ecXtigDCWw1oak(EHUAyW2lQfe4LXmhgIGc(u"ࠬࡲࡩ࡯࡭ࠪᶆ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᶇ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠻࠼࠽࠾Ṏ"))
	Ketm9Aay0lYxNHvznps38G = eANQpmZPJaI7wc8[:]
	eANQpmZPJaI7wc8[:] = []
	drpKzTJN8Vigc2FyMIs = []
	for PAHuZI7do0tpO9vsr8X2CLGVME6 in tfSxh7XoJjE6TDzOmKnPAFLNi:
		kyEG0lCSBFIZRno = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧᶈ")+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࠥࠪᶉ")+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭ᶊ"),PAHuZI7do0tpO9vsr8X2CLGVME6,oo9kuULlebNgpY0Om.DOTALL)
		if kyEG0lCSBFIZRno: PAHuZI7do0tpO9vsr8X2CLGVME6 = PAHuZI7do0tpO9vsr8X2CLGVME6.split(kyEG0lCSBFIZRno[dQ5JhEYolPmy1fvHktMw6NFRxiz],fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		ZZRac79JemQ38THwEDVOuGnqpPY = PAHuZI7do0tpO9vsr8X2CLGVME6.replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪ๕ࠬᶋ"),G9G0YqivIfmUWO8K).replace(cjbAkCIinvs(u"ࠫ๓࠭ᶌ"),G9G0YqivIfmUWO8K).replace(DTF3Lwy9etRH8mI(u"ࠬ๑ࠧᶍ"),G9G0YqivIfmUWO8K).replace(RVpeGcmPxj9tCnT40Nf216(u"࠭๏ࠨᶎ"),G9G0YqivIfmUWO8K).replace(rr7Xolsp4JwjPK3L(u"ࠧํࠩᶏ"),G9G0YqivIfmUWO8K)
		ZZRac79JemQ38THwEDVOuGnqpPY = ZZRac79JemQ38THwEDVOuGnqpPY.replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ๒ࠪᶐ"),G9G0YqivIfmUWO8K).replace(FWqeEzO1i8Dn0ga(u"ࠩ๐ࠫᶑ"),G9G0YqivIfmUWO8K).replace(FWqeEzO1i8Dn0ga(u"ࠪ๖ࠬᶒ"),G9G0YqivIfmUWO8K).replace(rxWDdRBIct57i90s(u"ࠫฑ࠭ᶓ"),G9G0YqivIfmUWO8K).replace(ssGdubC4mngM9D5SRc3Ye(u"ࠬๆࠧᶔ"),G9G0YqivIfmUWO8K)
		if ZZRac79JemQ38THwEDVOuGnqpPY: drpKzTJN8Vigc2FyMIs.append(ZZRac79JemQ38THwEDVOuGnqpPY)
	n5nalb8CVUQo1kZTY9siuJDKm6Fc7 = []
	for p0p6MxKbklodNCR92Wv in range(dQ5JhEYolPmy1fvHktMw6NFRxiz,cjbAkCIinvs(u"࠵࠴ṏ")):
		search = voWS3GzbN5HXaTsiwLMeU.sample(drpKzTJN8Vigc2FyMIs,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if search in n5nalb8CVUQo1kZTY9siuJDKm6Fc7: continue
		n5nalb8CVUQo1kZTY9siuJDKm6Fc7.append(search)
		oob2dzmG3jTMpZwQyIfN = voWS3GzbN5HXaTsiwLMeU.sample(TKdtbEk4zPJQ6hVew2ZvHWI8RcxA,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dC3PsQJ0Ti28uYlov(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮࡙ࠢ࡭ࡩ࡫࡯ࠡࡕࡨࡥࡷࡩࡨࠡࠢࠣࡷ࡮ࡺࡥ࠻ࠩᶕ")+str(oob2dzmG3jTMpZwQyIfN)+cjbAkCIinvs(u"ࠧࠡࠢࡶࡩࡦࡸࡣࡩ࠼ࠪᶖ")+search)
		oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
		PYymEzqnMT0it36kHG(search+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ᶗ"))
		if len(eANQpmZPJaI7wc8)>dQ5JhEYolPmy1fvHktMw6NFRxiz: break
	search = search.replace(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡢࡑࡔࡊ࡟ࠨᶘ"),G9G0YqivIfmUWO8K)
	Ketm9Aay0lYxNHvznps38G[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg] = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪ࡟ࠬᶙ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+search+zzGfwLAyN5HTxUoJeaivY+RVpeGcmPxj9tCnT40Nf216(u"ࠫࠥࡀศฮอࠣ฽๋ࡣࠧᶚ")
	eANQpmZPJaI7wc8[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
	if len(eANQpmZPJaI7wc8)>HuskB0c1Ob3r6CLiJXTyx: eANQpmZPJaI7wc8[:] = voWS3GzbN5HXaTsiwLMeU.sample(eANQpmZPJaI7wc8,HuskB0c1Ob3r6CLiJXTyx)
	eANQpmZPJaI7wc8[:] = Ketm9Aay0lYxNHvznps38G+eANQpmZPJaI7wc8
	return
def C7WhqVcENtTSrD4FJdai82xL(Z7aMVf9Eis0DxUj6lJK31wpGt,m5qG0Lfhadn7kzVQSsM):
	Z7aMVf9Eis0DxUj6lJK31wpGt = Z7aMVf9Eis0DxUj6lJK31wpGt.replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡥࡍࡐࡆࡢࠫᶛ"),G9G0YqivIfmUWO8K)
	m5qG0Lfhadn7kzVQSsM = m5qG0Lfhadn7kzVQSsM.replace(jR9YtmsgDX8nTQlMb6G3(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶜ"),G9G0YqivIfmUWO8K).replace(yiaeCEwJjOcWA4ZSd5h(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶝ"),G9G0YqivIfmUWO8K)
	Z0T74gk1RHfUoSKcAOWPQsalBuh(rxWDdRBIct57i90s(u"ࡉࡥࡱࡹࡥẎ"))
	if not y2authQZX56sVUGEdNpFOzKD40cgw: return
	if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪᶞ") in m5qG0Lfhadn7kzVQSsM:
		Qm8SMu6ecXtigDCWw1oak(EHUAyW2lQfe4LXmhgIGc(u"ࠩࡩࡳࡱࡪࡥࡳࠩᶟ"),DTF3Lwy9etRH8mI(u"ࠪ࡟ࠬᶠ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Z7aMVf9Eis0DxUj6lJK31wpGt+zzGfwLAyN5HTxUoJeaivY+yiaeCEwJjOcWA4ZSd5h(u"ࠫࠥࡀวๅไึ้ࡢ࠭ᶡ"),Z7aMVf9Eis0DxUj6lJK31wpGt,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠵࠻࠼Ṑ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶢ")+m5qG0Lfhadn7kzVQSsM)
		Qm8SMu6ecXtigDCWw1oak(t2sCrJ0xbgDRkf(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶣ"),qTVF3icWwGXy5(u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭ᶤ"),Z7aMVf9Eis0DxUj6lJK31wpGt,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠶࠼࠶ṑ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶥ")+m5qG0Lfhadn7kzVQSsM)
		Qm8SMu6ecXtigDCWw1oak(rr7Xolsp4JwjPK3L(u"ࠩ࡯࡭ࡳࡱࠧᶦ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+t2sCrJ0xbgDRkf(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᶧ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"࠿࠹࠺࠻Ṓ"))
	for website in sorted(list(y2authQZX56sVUGEdNpFOzKD40cgw[Z7aMVf9Eis0DxUj6lJK31wpGt].keys())):
		type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = y2authQZX56sVUGEdNpFOzKD40cgw[Z7aMVf9Eis0DxUj6lJK31wpGt][website]
		if t2sCrJ0xbgDRkf(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᶨ") in m5qG0Lfhadn7kzVQSsM or len(y2authQZX56sVUGEdNpFOzKD40cgw[Z7aMVf9Eis0DxUj6lJK31wpGt])==fdQOo6Hu4B5Rbg:
			TadilgrWnheCzbZI4LHv1S7DVB(type,G9G0YqivIfmUWO8K,url,qivZbzYC2WgXVJmcTL,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
			eANQpmZPJaI7wc8[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
			UzkbHgRAS0NrWYB,hayNktUR2Tq8g = eANQpmZPJaI7wc8[:c1R9fnIY4XBDZ],eANQpmZPJaI7wc8[c1R9fnIY4XBDZ:]
			if iqHhJSxdaANDG5rlZm7B(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᶩ") in m5qG0Lfhadn7kzVQSsM:
				for KT9tdUH3hmiLZCEFz in range(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠹ṓ")): voWS3GzbN5HXaTsiwLMeU.shuffle(hayNktUR2Tq8g)
				eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g[:HuskB0c1Ob3r6CLiJXTyx]
			else: eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g
		elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧᶪ") in m5qG0Lfhadn7kzVQSsM: Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶫ"),website,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
	return
def fWRVJ4syvQM(m5qG0Lfhadn7kzVQSsM,Mauf6CrJjP87s):
	m5qG0Lfhadn7kzVQSsM = m5qG0Lfhadn7kzVQSsM.replace(DTF3Lwy9etRH8mI(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶬ"),G9G0YqivIfmUWO8K).replace(RVpeGcmPxj9tCnT40Nf216(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶭ"),G9G0YqivIfmUWO8K)
	YwC7jt5BQHhTUvbdGeM6f2ZLx,hayNktUR2Tq8g = G9G0YqivIfmUWO8K,[]
	Qm8SMu6ecXtigDCWw1oak(iAGgjwb7tVMmacRJ(u"ࠪࡪࡴࡲࡤࡦࡴࠪᶮ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡠ࠭ᶯ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+YwC7jt5BQHhTUvbdGeM6f2ZLx+zzGfwLAyN5HTxUoJeaivY+EHUAyW2lQfe4LXmhgIGc(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᶰ"),G9G0YqivIfmUWO8K,Mauf6CrJjP87s,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶱ")+m5qG0Lfhadn7kzVQSsM)
	Qm8SMu6ecXtigDCWw1oak(FWqeEzO1i8Dn0ga(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᶲ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨᶳ"),G9G0YqivIfmUWO8K,Mauf6CrJjP87s,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶴ")+m5qG0Lfhadn7kzVQSsM)
	Qm8SMu6ecXtigDCWw1oak(rr7Xolsp4JwjPK3L(u"ࠪࡰ࡮ࡴ࡫ࠨᶵ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᶶ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"࠺࠻࠼࠽Ṕ"))
	UzkbHgRAS0NrWYB = eANQpmZPJaI7wc8[:]
	eANQpmZPJaI7wc8[:] = []
	tRojAyBgfDH37eLCwP4dWl = []
	if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭ᶷ") in m5qG0Lfhadn7kzVQSsM:
		Z0T74gk1RHfUoSKcAOWPQsalBuh(bneABYmwFUH8GXphg0Kl2Sq(u"ࡊࡦࡲࡳࡦẏ"))
		if not y2authQZX56sVUGEdNpFOzKD40cgw: return
		bbKSohgfaqx4Dwny6sIVXZYF = list(y2authQZX56sVUGEdNpFOzKD40cgw.keys())
		Z7aMVf9Eis0DxUj6lJK31wpGt = voWS3GzbN5HXaTsiwLMeU.sample(bbKSohgfaqx4Dwny6sIVXZYF,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		tfSxh7XoJjE6TDzOmKnPAFLNi = list(y2authQZX56sVUGEdNpFOzKD40cgw[Z7aMVf9Eis0DxUj6lJK31wpGt].keys())
		website = voWS3GzbN5HXaTsiwLMeU.sample(tfSxh7XoJjE6TDzOmKnPAFLNi,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = y2authQZX56sVUGEdNpFOzKD40cgw[Z7aMVf9Eis0DxUj6lJK31wpGt][website]
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dC3PsQJ0Ti28uYlov(u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩᶸ")+website+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪᶹ")+YwC7jt5BQHhTUvbdGeM6f2ZLx+FWqeEzO1i8Dn0ga(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪᶺ")+url+ssGdubC4mngM9D5SRc3Ye(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬᶻ")+str(qivZbzYC2WgXVJmcTL))
	elif cjbAkCIinvs(u"ࠪࡣࡎࡖࡔࡗࡡࠪᶼ") in m5qG0Lfhadn7kzVQSsM:
		import QMzke4oxuJ
		if not QMzke4oxuJ.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡙ࡸࡵࡦẐ")): return
		for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
			tRojAyBgfDH37eLCwP4dWl += v8pUC16gkEG(str(Gzo1nsVM84m6abfISDup9xjQdBO),m5qG0Lfhadn7kzVQSsM)
		if not tRojAyBgfDH37eLCwP4dWl: return
		type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = voWS3GzbN5HXaTsiwLMeU.sample(tRojAyBgfDH37eLCwP4dWl,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫᶽ")+YwC7jt5BQHhTUvbdGeM6f2ZLx+jR9YtmsgDX8nTQlMb6G3(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧᶾ")+url+UighHKAfySm4PWErqJ(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩᶿ")+str(qivZbzYC2WgXVJmcTL))
	elif wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡠࡏ࠶࡙ࡤ࠭᷀") in m5qG0Lfhadn7kzVQSsM:
		import UUQbsdSjoM
		if not UUQbsdSjoM.eia6WyskqpVGdRYrM0xLuUTOw(G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"࡚ࡲࡶࡧẑ")): return
		for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
			tRojAyBgfDH37eLCwP4dWl += xoap9TC4RAkK1INwX3eEb7(str(Gzo1nsVM84m6abfISDup9xjQdBO),m5qG0Lfhadn7kzVQSsM)
		if not tRojAyBgfDH37eLCwP4dWl: return
		type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = voWS3GzbN5HXaTsiwLMeU.sample(tRojAyBgfDH37eLCwP4dWl,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+rxWDdRBIct57i90s(u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ᷁")+YwC7jt5BQHhTUvbdGeM6f2ZLx+cjbAkCIinvs(u"ࠩࠣࠤࠥࡻࡲ࡭࠼᷂ࠣࠫ")+url+jR9YtmsgDX8nTQlMb6G3(u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭᷃")+str(qivZbzYC2WgXVJmcTL))
	ibjhwUyspF5eLd = YwC7jt5BQHhTUvbdGeM6f2ZLx
	VbNcxQTOHaG5ndoXC3ZRE9i = []
	for KT9tdUH3hmiLZCEFz in range(dQ5JhEYolPmy1fvHktMw6NFRxiz,cjbAkCIinvs(u"࠳࠳ṕ")):
		if KT9tdUH3hmiLZCEFz>dQ5JhEYolPmy1fvHktMw6NFRxiz: vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ᷄")+YwC7jt5BQHhTUvbdGeM6f2ZLx+ssGdubC4mngM9D5SRc3Ye(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ᷅")+url+DTF3Lwy9etRH8mI(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ᷆")+str(qivZbzYC2WgXVJmcTL))
		eANQpmZPJaI7wc8[:] = []
		if qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠵࠷࠹Ṗ") and wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ᷇") in Vvju9Ht8SGxoiTa6lCs: qivZbzYC2WgXVJmcTL = ETNq5t4MYngSsbfFD8J0v(u"࠶࠸࠹ṗ")
		if qivZbzYC2WgXVJmcTL==jR9YtmsgDX8nTQlMb6G3(u"࠼࠷࠴Ṙ") and DTF3Lwy9etRH8mI(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ᷈") in Vvju9Ht8SGxoiTa6lCs: qivZbzYC2WgXVJmcTL = yiaeCEwJjOcWA4ZSd5h(u"࠽࠱࠴ṙ")
		if qivZbzYC2WgXVJmcTL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠱࠵࠶Ṛ"): qivZbzYC2WgXVJmcTL = jR9YtmsgDX8nTQlMb6G3(u"࠳࠻࠴ṛ")
		HHFwtdVPy2OZ = TadilgrWnheCzbZI4LHv1S7DVB(type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
		if rxWDdRBIct57i90s(u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ᷉") in m5qG0Lfhadn7kzVQSsM and qivZbzYC2WgXVJmcTL==jR9YtmsgDX8nTQlMb6G3(u"࠳࠹࠻Ṝ"): del eANQpmZPJaI7wc8[:c1R9fnIY4XBDZ]
		if rr7Xolsp4JwjPK3L(u"ࠪࡣࡒ࠹ࡕࡠ᷊ࠩ") in m5qG0Lfhadn7kzVQSsM and qivZbzYC2WgXVJmcTL==iAGgjwb7tVMmacRJ(u"࠴࠺࠽ṝ"): del eANQpmZPJaI7wc8[:c1R9fnIY4XBDZ]
		hayNktUR2Tq8g[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
		if VbNcxQTOHaG5ndoXC3ZRE9i and X0Y7Axf35La9jPc1EiVIu(EHUAyW2lQfe4LXmhgIGc(u"ࡹࠬำไใหࠪ᷋")) in str(hayNktUR2Tq8g) or X0Y7Axf35La9jPc1EiVIu(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࡺ࠭อๅไ๊ࠫ᷌")) in str(hayNktUR2Tq8g):
			YwC7jt5BQHhTUvbdGeM6f2ZLx = ibjhwUyspF5eLd
			hayNktUR2Tq8g[:] = VbNcxQTOHaG5ndoXC3ZRE9i
			break
		ibjhwUyspF5eLd = YwC7jt5BQHhTUvbdGeM6f2ZLx
		VbNcxQTOHaG5ndoXC3ZRE9i = hayNktUR2Tq8g
		if str(hayNktUR2Tq8g).count(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡶࡪࡦࡨࡳࠬ᷍"))>dQ5JhEYolPmy1fvHktMw6NFRxiz: break
		if str(hayNktUR2Tq8g).count(VHrIziKUDuNGXkMla(u"ࠧ࡭࡫ࡹࡩ᷎ࠬ"))>dQ5JhEYolPmy1fvHktMw6NFRxiz: break
		if qivZbzYC2WgXVJmcTL==EHUAyW2lQfe4LXmhgIGc(u"࠶࠸࠹Ṟ"): break
		if qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠼࠷࠳ṟ"): break
		if qivZbzYC2WgXVJmcTL==cJSNFCIhymEfx6grGu0M(u"࠸࠹࠲Ṡ"): break
		if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡ᷏ࠪ") in m5qG0Lfhadn7kzVQSsM and hayNktUR2Tq8g: type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,qivZbzYC2WgXVJmcTL,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = voWS3GzbN5HXaTsiwLMeU.sample(hayNktUR2Tq8g,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if not YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = qTVF3icWwGXy5(u"ࠩ࠱࠲࠳࠴᷐ࠧ")
	elif YwC7jt5BQHhTUvbdGeM6f2ZLx.count(t2sCrJ0xbgDRkf(u"ࠪࡣࠬ᷑"))>fdQOo6Hu4B5Rbg: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.split(qTVF3icWwGXy5(u"ࠫࡤ࠭᷒"),SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU)[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨᷓ"),G9G0YqivIfmUWO8K)
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(VHrIziKUDuNGXkMla(u"࠭࡟ࡎࡑࡇࡣࠬᷔ"),G9G0YqivIfmUWO8K)
	UzkbHgRAS0NrWYB[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg] = rr7Xolsp4JwjPK3L(u"ࠧ࡜ࠩᷕ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+YwC7jt5BQHhTUvbdGeM6f2ZLx+zzGfwLAyN5HTxUoJeaivY+iqHhJSxdaANDG5rlZm7B(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪᷖ")
	if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᷗ") in m5qG0Lfhadn7kzVQSsM:
		for KT9tdUH3hmiLZCEFz in range(dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠹ṡ")): voWS3GzbN5HXaTsiwLMeU.shuffle(hayNktUR2Tq8g)
		eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g[:HuskB0c1Ob3r6CLiJXTyx]
	else: eANQpmZPJaI7wc8[:] = UzkbHgRAS0NrWYB+hayNktUR2Tq8g
	return
def N23lsFyVYDbK(wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg):
	HsQA4vlcwFN6Xg = HsQA4vlcwFN6Xg.replace(t2sCrJ0xbgDRkf(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᷘ"),G9G0YqivIfmUWO8K).replace(rr7Xolsp4JwjPK3L(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᷙ"),G9G0YqivIfmUWO8K)
	bjIQsqXTyM = HsQA4vlcwFN6Xg
	if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᷚ") in HsQA4vlcwFN6Xg:
		bjIQsqXTyM = HsQA4vlcwFN6Xg.split(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧᷛ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		type = jR9YtmsgDX8nTQlMb6G3(u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪᷜ")
	elif yiaeCEwJjOcWA4ZSd5h(u"ࠨࡘࡒࡈࠬᷝ") in wGEuZvi0I4gLPKAhn67WzecoTXY: type = ssGdubC4mngM9D5SRc3Ye(u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬᷞ")
	elif wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡐࡎ࡜ࡅࠨᷟ") in wGEuZvi0I4gLPKAhn67WzecoTXY: type = iAGgjwb7tVMmacRJ(u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬᷠ")
	Qm8SMu6ecXtigDCWw1oak(RVpeGcmPxj9tCnT40Nf216(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷡ"),yiaeCEwJjOcWA4ZSd5h(u"࡛࠭ࠨᷢ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+type+bjIQsqXTyM+zzGfwLAyN5HTxUoJeaivY+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩᷣ"),wGEuZvi0I4gLPKAhn67WzecoTXY,UighHKAfySm4PWErqJ(u"࠲࠸࠺Ṣ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷤ")+HsQA4vlcwFN6Xg)
	Qm8SMu6ecXtigDCWw1oak(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡩࡳࡱࡪࡥࡳࠩᷥ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩᷦ"),wGEuZvi0I4gLPKAhn67WzecoTXY,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠳࠹࠻ṣ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᷧ")+HsQA4vlcwFN6Xg)
	Qm8SMu6ecXtigDCWw1oak(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡲࡩ࡯࡭ࠪᷨ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᷩ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"࠼࠽࠾࠿Ṥ"))
	import QMzke4oxuJ
	for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
		if yiaeCEwJjOcWA4ZSd5h(u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨᷪ") in HsQA4vlcwFN6Xg: QMzke4oxuJ.RlObognJh9DjiHyIE54(str(Gzo1nsVM84m6abfISDup9xjQdBO),wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࡆࡢ࡮ࡶࡩẒ"))
		else: QMzke4oxuJ.Mt7X1vp6TLucKVrw8EUhyI(str(Gzo1nsVM84m6abfISDup9xjQdBO),wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࡇࡣ࡯ࡷࡪẓ"))
	eANQpmZPJaI7wc8[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
	if len(eANQpmZPJaI7wc8)>(HuskB0c1Ob3r6CLiJXTyx+c1R9fnIY4XBDZ): eANQpmZPJaI7wc8[:] = eANQpmZPJaI7wc8[:c1R9fnIY4XBDZ]+voWS3GzbN5HXaTsiwLMeU.sample(eANQpmZPJaI7wc8[c1R9fnIY4XBDZ:],HuskB0c1Ob3r6CLiJXTyx)
	return
def YDpCBmWV47AGL(wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg):
	HsQA4vlcwFN6Xg = HsQA4vlcwFN6Xg.replace(cjbAkCIinvs(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᷫ"),G9G0YqivIfmUWO8K).replace(UighHKAfySm4PWErqJ(u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᷬ"),G9G0YqivIfmUWO8K)
	bjIQsqXTyM = HsQA4vlcwFN6Xg
	if ETNq5t4MYngSsbfFD8J0v(u"ࠪࡣࡤࡓ࠳ࡖࡕࡨࡶ࡮࡫ࡳࡠࡡࠪᷭ") in HsQA4vlcwFN6Xg:
		bjIQsqXTyM = HsQA4vlcwFN6Xg.split(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᷮ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		type = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨᷯ")
	elif qTVF3icWwGXy5(u"࠭ࡖࡐࡆࠪᷰ") in wGEuZvi0I4gLPKAhn67WzecoTXY: type = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࠭ࡘࡌࡈࡊࡕࡓ࠻ࠢࠪᷱ")
	elif VHrIziKUDuNGXkMla(u"ࠨࡎࡌ࡚ࡊ࠭ᷲ") in wGEuZvi0I4gLPKAhn67WzecoTXY: type = yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪᷳ")
	Qm8SMu6ecXtigDCWw1oak(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡪࡴࡲࡤࡦࡴࠪᷴ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡠ࠭᷵")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+type+bjIQsqXTyM+zzGfwLAyN5HTxUoJeaivY+RVpeGcmPxj9tCnT40Nf216(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧ᷶"),wGEuZvi0I4gLPKAhn67WzecoTXY,UighHKAfySm4PWErqJ(u"࠵࠻࠾ṥ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢ᷷ࠫ")+HsQA4vlcwFN6Xg)
	Qm8SMu6ecXtigDCWw1oak(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡧࡱ࡯ࡨࡪࡸ᷸ࠧ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋᷹ࠧ"),wGEuZvi0I4gLPKAhn67WzecoTXY,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠶࠼࠸Ṧ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᷺ࠧ")+HsQA4vlcwFN6Xg)
	Qm8SMu6ecXtigDCWw1oak(jR9YtmsgDX8nTQlMb6G3(u"ࠪࡰ࡮ࡴ࡫ࠨ᷻"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+yiaeCEwJjOcWA4ZSd5h(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩ᷼")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"࠿࠹࠺࠻ṧ"))
	import UUQbsdSjoM
	for Gzo1nsVM84m6abfISDup9xjQdBO in range(fdQOo6Hu4B5Rbg,XmGcjWDVrAuKeMFlbSvdhYi1+fdQOo6Hu4B5Rbg):
		if cJSNFCIhymEfx6grGu0M(u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣ᷽ࠬ") in HsQA4vlcwFN6Xg: UUQbsdSjoM.RlObognJh9DjiHyIE54(str(Gzo1nsVM84m6abfISDup9xjQdBO),wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࡈࡤࡰࡸ࡫Ẕ"))
		else: UUQbsdSjoM.Mt7X1vp6TLucKVrw8EUhyI(str(Gzo1nsVM84m6abfISDup9xjQdBO),wGEuZvi0I4gLPKAhn67WzecoTXY,HsQA4vlcwFN6Xg,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࡉࡥࡱࡹࡥẕ"))
	eANQpmZPJaI7wc8[:] = Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8)
	if len(eANQpmZPJaI7wc8)>(HuskB0c1Ob3r6CLiJXTyx+c1R9fnIY4XBDZ): eANQpmZPJaI7wc8[:] = eANQpmZPJaI7wc8[:c1R9fnIY4XBDZ]+voWS3GzbN5HXaTsiwLMeU.sample(eANQpmZPJaI7wc8[c1R9fnIY4XBDZ:],HuskB0c1Ob3r6CLiJXTyx)
	return
def Q6rwsc7EF4yPCU1HDqRf(eANQpmZPJaI7wc8):
	jK8XUVlEhLnbzJrp1f = []
	for type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in eANQpmZPJaI7wc8:
		if bneABYmwFUH8GXphg0Kl2Sq(u"࠭ีโฯฬࠫ᷾") in YwC7jt5BQHhTUvbdGeM6f2ZLx or dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧึใะ๋᷿ࠬ") in YwC7jt5BQHhTUvbdGeM6f2ZLx or cJSNFCIhymEfx6grGu0M(u"ࠨࡲࡤ࡫ࡪ࠭Ḁ") in YwC7jt5BQHhTUvbdGeM6f2ZLx.lower(): continue
		jK8XUVlEhLnbzJrp1f.append([type,YwC7jt5BQHhTUvbdGeM6f2ZLx,url,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3])
	return jK8XUVlEhLnbzJrp1f
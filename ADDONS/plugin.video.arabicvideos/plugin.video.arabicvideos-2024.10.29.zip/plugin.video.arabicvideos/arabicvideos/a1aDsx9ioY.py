# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from pPyIeTklaY import *
import base64 as jaFsD83SB9ZQkrxeI
s5slfAmHkUtMR3WSKY1ZTX = EHUAyW2lQfe4LXmhgIGc(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ୯")
eANQpmZPJaI7wc8,MMznYDmqKf0gVWpiSulZJ1waTRc,y2authQZX56sVUGEdNpFOzKD40cgw = [],{},{}
m0ijDc8uwEGXxU1,pkAM4Z8ch6TJY,voQk40gmzx3UBaTnyMlEKSfLVJA = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
W8N1ecfjgDVSsaARwzk9I = {}
f5jdSUbP761JrgynW2GZAXIsc8YRCQ,SpMGtPOf20hUK5BNLb = [dQ5JhEYolPmy1fvHktMw6NFRxiz],[dQ5JhEYolPmy1fvHktMw6NFRxiz]
jnYipcC6lerd7xT4QW50g1 = {}
UWfvC06tXBdKkDeGlzgsrbF92J8Rm5 = kkMuQrLWcEayRm
if LTze51miOknVcslNF43WSA6vMjYZt:
	NGLWtwdZaOCMnlXizgqJmDxVph13sB = JJMb7fKtaDTQloFcdNjxRW6OCrn.translatePath(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ୰"))
	irwSnY4qBFv5txbM9u0kNOlfmHDR8h = JJMb7fKtaDTQloFcdNjxRW6OCrn.translatePath(jR9YtmsgDX8nTQlMb6G3(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫୱ"))
	BUQsMTLHaboC7eEX2h4Pz0gkJyl9d3 = JJMb7fKtaDTQloFcdNjxRW6OCrn.translatePath(FWqeEzO1i8Dn0ga(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ୲"))
	xxXTUlvGQ15JZAV0CbIc7Ry3wkES = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ୳"),iAGgjwb7tVMmacRJ(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ୴"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ୵"))
	LKOXASjqYnGa1wW0iJcRpT4sEueo = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,yiaeCEwJjOcWA4ZSd5h(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ୶"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ୷"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ୸"))
	PUVchiMBQ0L2zr1bZ8oYASR = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,cjbAkCIinvs(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭୹"),rxWDdRBIct57i90s(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ୺"),ETNq5t4MYngSsbfFD8J0v(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭୻"))
	vq9L3uo7rDVm2zPO4h = rr7Xolsp4JwjPK3L(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ୼")
	from urllib.parse import quote as _P2Smn1ZkNGscwI3KFApTY4e
else:
	NGLWtwdZaOCMnlXizgqJmDxVph13sB = oR7SuW56ZQcpXnswUMqIkrP.translatePath(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ୽"))
	irwSnY4qBFv5txbM9u0kNOlfmHDR8h = oR7SuW56ZQcpXnswUMqIkrP.translatePath(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ୾"))
	BUQsMTLHaboC7eEX2h4Pz0gkJyl9d3 = oR7SuW56ZQcpXnswUMqIkrP.translatePath(cjbAkCIinvs(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ୿"))
	xxXTUlvGQ15JZAV0CbIc7Ry3wkES = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,qTVF3icWwGXy5(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭஀"),iqHhJSxdaANDG5rlZm7B(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ஁"),jR9YtmsgDX8nTQlMb6G3(u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫஂ"))
	LKOXASjqYnGa1wW0iJcRpT4sEueo = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,t2sCrJ0xbgDRkf(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩஃ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ஄"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩஅ"))
	PUVchiMBQ0L2zr1bZ8oYASR = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,FWqeEzO1i8Dn0ga(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬஆ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭இ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬஈ"))
	vq9L3uo7rDVm2zPO4h = qTVF3icWwGXy5(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧஉ").encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	from urllib import quote as _P2Smn1ZkNGscwI3KFApTY4e
UcSsAurHXqJwR70DT1i = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(BUQsMTLHaboC7eEX2h4Pz0gkJyl9d3,RVpeGcmPxj9tCnT40Nf216(u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩஊ"))
tkYsz4jTx8NUoOILul0bqf9PKCMcV = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(BUQsMTLHaboC7eEX2h4Pz0gkJyl9d3,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧ஋"))
zIOumdrhtTHF89X1M = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,rr7Xolsp4JwjPK3L(u"ࠩ࡬ࡴࡹࡼ࠱ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫ஌"))
b2Hjwhx5lA8X3 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,RVpeGcmPxj9tCnT40Nf216(u"ࠪ࡭ࡵࡺࡶ࠳ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ஍"))
xrqZW7U0vfmJP9Dw = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡲ࠹ࡵࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫஎ"))
Mh2XHLxaCsToiUFymceOGKS = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭ஏ"))
QpCIAdKo8DZY1SmOH2yMW = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,RVpeGcmPxj9tCnT40Nf216(u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨஐ"))
Qe2LqnH1RN3mU = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ஑"))
ffDhnivjmRXeuHSIa1qEZNA = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,UighHKAfySm4PWErqJ(u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨஒ"))
fkW4uJKsLEMtBvUAQpd9r2hHe15z6 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ffDhnivjmRXeuHSIa1qEZNA,DTF3Lwy9etRH8mI(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡵࠪஓ"))
pBVU0FrKY7soCucdwbTmjPOzyiGh = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ffDhnivjmRXeuHSIa1qEZNA,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡵࠪஔ"))
F0xXYapD5dS4HBM = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(fkW4uJKsLEMtBvUAQpd9r2hHe15z6,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧக"))
ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J = K8EzSxPHWjcp.Addon().getAddonInfo(ssGdubC4mngM9D5SRc3Ye(u"ࠬࡶࡡࡵࡪࠪ஖"))
YvPznWuqLKHVlrcy94wSQTa8hOdxb = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,DTF3Lwy9etRH8mI(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ஗"))
ihPGw1e7Z3gszrKtDTBA0 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,t2sCrJ0xbgDRkf(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ஘"))
BQyXZbeflD1hVziWCOMTmHpSg6s = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬங"))
pgtNxXOjCuyEDoVwdP1hT = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,iAGgjwb7tVMmacRJ(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭ச"))
XTMxQ5m61fedDn3B = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,rr7Xolsp4JwjPK3L(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪ஛"))
lqTAvF30NWtXBJd298cQOeiPw = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨஜ"))
cy5CLXOVMaxfmUuW9460 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬ஝"))
kxN0Oz4RemitSJYpal = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,ssGdubC4mngM9D5SRc3Ye(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬஞ"))
JVqRU9FrdwvjpCcSoTHgmlX51YNWs0 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧ࡮ࡧࡱࡹࡤࡸࡥࡥࡡ࠵࠴࠵ࡾ࠲࠶࠲࠱ࡴࡳ࡭ࠧட"))
hEmTAjMeXOsyGxCn0pN8PHU2V = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,cJSNFCIhymEfx6grGu0M(u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨ஠"))
wikRq4pjIX6Nx7d3lm = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ஡"))
NNan7CfOHFd0xDG3XvbPlwtuRpy = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ஢"),rxWDdRBIct57i90s(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨண"),IJPabrdjXE7HGR163qY48pMVU5l,cJSNFCIhymEfx6grGu0M(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫத"))
VaKLXphjxdTmCZGRzDl0tuE1geW3s = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(NGLWtwdZaOCMnlXizgqJmDxVph13sB,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭࡭ࡦࡦ࡬ࡥࠬ஥"),iqHhJSxdaANDG5rlZm7B(u"ࠧࡇࡱࡱࡸࡸ࠭஦"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫ஧"))
XmGcjWDVrAuKeMFlbSvdhYi1 = iqHhJSxdaANDG5rlZm7B(u"࠹፵")
F7hmrbfYztVycGjDE4Sd = [qTVF3icWwGXy5(u"ุࠩๅึ࠭ந"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪวํ๊ࠧன"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫะอๆ๋ࠩப"),jR9YtmsgDX8nTQlMb6G3(u"ࠬัวๅอࠪ஫"),dC3PsQJ0Ti28uYlov(u"࠭ัศส฼ࠫ஬"),FWqeEzO1i8Dn0ga(u"ࠧฯษ่ืࠬ஭"),qTVF3icWwGXy5(u"ࠨีสำุ࠭ம"),rr7Xolsp4JwjPK3L(u"ࠩึหอ฿ࠧய"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪฯฬ๋ๆࠨர"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫฯอำฺࠩற"),yiaeCEwJjOcWA4ZSd5h(u"ࠬ฿วีำࠪல")]
ohAe4cj3KsyuTEp7 = UighHKAfySm4PWErqJ(u"࠭⸻ࠡ⼟ࠣ⸮ࠥ⹁ࠧள")
CJhaFdZxoSfGsmIcw = [qTVF3icWwGXy5(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ழ")]
ZcUkyaPDlKMb6 = [yiaeCEwJjOcWA4ZSd5h(u"ࠨࡄࡒࡏࡗࡇࠧவ"),rr7Xolsp4JwjPK3L(u"ࠩࡓࡅࡓࡋࡔࠨஶ"),UighHKAfySm4PWErqJ(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨஷ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧஸ"),rr7Xolsp4JwjPK3L(u"ࠬࡏࡆࡊࡎࡐࠫஹ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ஺"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ஻")]
ZcUkyaPDlKMb6 += [EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ஼"),cjbAkCIinvs(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ஽"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡅࡐࡕࡁࡎࠩா"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡆࡑࡗࡂࡏࠪி"),iqHhJSxdaANDG5rlZm7B(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧீ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨு")]
y46TMmgNJ80XDRWArUlGfxBKkoEpi = [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧூ"),iqHhJSxdaANDG5rlZm7B(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ௃"),t2sCrJ0xbgDRkf(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ௄"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ௅"),rr7Xolsp4JwjPK3L(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬெ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩே"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨை")]
y46TMmgNJ80XDRWArUlGfxBKkoEpi += [bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ௉"),cJSNFCIhymEfx6grGu0M(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪொ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡖࡌࡔࡌࡈࡂࠩோ"),dC3PsQJ0Ti28uYlov(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫௌ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶்ࠬ")]
krTUKuO6xwR = [UighHKAfySm4PWErqJ(u"࡚ࠬࡉࡌࡃࡄࡘࠬ௎"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡁ࡚ࡎࡒࡐࠬ௏"),RVpeGcmPxj9tCnT40Nf216(u"ࠧࡇࡑࡖࡘࡆ࠭ௐ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ௑"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩ࡜ࡅࡖࡕࡔࠨ௒"),UighHKAfySm4PWErqJ(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭௓"),RVpeGcmPxj9tCnT40Nf216(u"࡛ࠫࡇࡒࡃࡑࡑࠫ௔"),iqHhJSxdaANDG5rlZm7B(u"ࠬࡈࡒࡔࡖࡈࡎࠬ௕")]
krTUKuO6xwR += [UighHKAfySm4PWErqJ(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧ௖"),ssGdubC4mngM9D5SRc3Ye(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩௗ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩ௘"),ETNq5t4MYngSsbfFD8J0v(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ௙"),ssGdubC4mngM9D5SRc3Ye(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫ௚"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭௛"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭௜")]
krTUKuO6xwR += [EHUAyW2lQfe4LXmhgIGc(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨ௝"),UighHKAfySm4PWErqJ(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ௞"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫ௟"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪ௠"),qTVF3icWwGXy5(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭௡"),DTF3Lwy9etRH8mI(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ௢"),FWqeEzO1i8Dn0ga(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ௣")]
krTUKuO6xwR += [EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩ௤"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪ௥"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ௦"),VHrIziKUDuNGXkMla(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ௧"),DTF3Lwy9etRH8mI(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬ௨"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡆࡎࡗࡂࡍࠪ௩"),qTVF3icWwGXy5(u"ࠬ࡜ࡉࡅࡇࡒࡒࡘࡇࡅࡎࠩ௪")]
krTUKuO6xwR += [RVpeGcmPxj9tCnT40Nf216(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ௫"),VHrIziKUDuNGXkMla(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫ௬"),UighHKAfySm4PWErqJ(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭௭"),jR9YtmsgDX8nTQlMb6G3(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ௮"),iqHhJSxdaANDG5rlZm7B(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ௯"),dC3PsQJ0Ti28uYlov(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭௰"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ௱")]
YY2sanqyXwEIGtMxziDOHLgKQkZ4 = [vCmnFshSi4flecXIY2gy38G0DJw(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ௲"),dC3PsQJ0Ti28uYlov(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ௳"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ௴"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ௵")]
YY2sanqyXwEIGtMxziDOHLgKQkZ4 += [GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ௶"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ௷"),VHrIziKUDuNGXkMla(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭௸"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭௹"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫ௺"),EHUAyW2lQfe4LXmhgIGc(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨ௻")]
YY2sanqyXwEIGtMxziDOHLgKQkZ4 += [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡌࡔ࡙࡜ࠧ௼"),t2sCrJ0xbgDRkf(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭௽"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ௾"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ௿")]
YY2sanqyXwEIGtMxziDOHLgKQkZ4 += [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡍ࠴ࡗࠪఀ"),UighHKAfySm4PWErqJ(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩఁ"),rr7Xolsp4JwjPK3L(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬం"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ః")]
U6keACwnTHK71tsy = []
C2sxY5a7y4gZutGp0N8keIhMnLR  = [cjbAkCIinvs(u"ࠪࡅࡐ࡝ࡁࡎࠩఄ"),iAGgjwb7tVMmacRJ(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭అ"),jR9YtmsgDX8nTQlMb6G3(u"ࠬࡈࡏࡌࡔࡄࠫఆ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡁࡌࡑࡄࡑࠬఇ"),dC3PsQJ0Ti28uYlov(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩఈ"),t2sCrJ0xbgDRkf(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩఉ"),VHrIziKUDuNGXkMla(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫఊ"),rr7Xolsp4JwjPK3L(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬఋ"),cjbAkCIinvs(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫఌ")]
C2sxY5a7y4gZutGp0N8keIhMnLR += [EHUAyW2lQfe4LXmhgIGc(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ఍"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩఎ"),ssGdubC4mngM9D5SRc3Ye(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨఏ"),DTF3Lwy9etRH8mI(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩఐ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪ఑"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧఒ"),cjbAkCIinvs(u"ࠫࡋࡕࡓࡕࡃࠪఓ"),dC3PsQJ0Ti28uYlov(u"ࠬࡇࡈࡘࡃࡎࠫఔ"),ETNq5t4MYngSsbfFD8J0v(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨక")]
C2sxY5a7y4gZutGp0N8keIhMnLR += [VHrIziKUDuNGXkMla(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫఖ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫగ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬఘ"),rr7Xolsp4JwjPK3L(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬఙ"),rr7Xolsp4JwjPK3L(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭చ"),dC3PsQJ0Ti28uYlov(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧఛ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨజ"),DTF3Lwy9etRH8mI(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪఝ")]
C2sxY5a7y4gZutGp0N8keIhMnLR += [dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩఞ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫట"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬఠ"),qTVF3icWwGXy5(u"࡙ࠫ࡜ࡆࡖࡐࠪడ"),RVpeGcmPxj9tCnT40Nf216(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧఢ"),FWqeEzO1i8Dn0ga(u"࠭ࡓࡉࡑࡉࡌࡆ࠭ణ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡗࡃࡕࡆࡔࡔࠧత"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡃࡏࡑࡘ࡚ࡂࡂࠩథ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪద")]
C2sxY5a7y4gZutGp0N8keIhMnLR += [RVpeGcmPxj9tCnT40Nf216(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪధ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࡞ࡇࡑࡐࡖࠪన"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭఩"),qTVF3icWwGXy5(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧప"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬఫ"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪబ"),jR9YtmsgDX8nTQlMb6G3(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫభ"),RVpeGcmPxj9tCnT40Nf216(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪమ"),RVpeGcmPxj9tCnT40Nf216(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭య")]
C2sxY5a7y4gZutGp0N8keIhMnLR += [iqHhJSxdaANDG5rlZm7B(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪర"),DTF3Lwy9etRH8mI(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨఱ"),qTVF3icWwGXy5(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨల"),t2sCrJ0xbgDRkf(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫళ"),cJSNFCIhymEfx6grGu0M(u"ࠩࡗࡍࡐࡇࡁࡕࠩఴ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭వ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭శ")]
XayQpenJqO  = [rxWDdRBIct57i90s(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪష"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧస"),EHUAyW2lQfe4LXmhgIGc(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧహ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬ఺"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ఻")]
XayQpenJqO += [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄ఼ࠩ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫఽ")]
XayQpenJqO += [wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭ా"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪి"),dC3PsQJ0Ti28uYlov(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪీ")]
XayQpenJqO += [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫు"),iqHhJSxdaANDG5rlZm7B(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧూ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨృ")]
XayQpenJqO += [t2sCrJ0xbgDRkf(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ౄ"),UighHKAfySm4PWErqJ(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ౅"),rxWDdRBIct57i90s(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪె")]
VSlARun5T491Ue = [dC3PsQJ0Ti28uYlov(u"ࠧࡎ࠵ࡘࠫే"),rr7Xolsp4JwjPK3L(u"ࠨࡋࡓࡘ࡛࠭ై"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ౉"),FWqeEzO1i8Dn0ga(u"ࠪࡍࡋࡏࡌࡎࠩొ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬో")]
R9REDCIH1Ykn = C2sxY5a7y4gZutGp0N8keIhMnLR+XayQpenJqO
jBCFu0HwftZ3XvQyOY = C2sxY5a7y4gZutGp0N8keIhMnLR+VSlARun5T491Ue
TTNMWtsb1eaAd6 = C2sxY5a7y4gZutGp0N8keIhMnLR+XayQpenJqO+CJhaFdZxoSfGsmIcw
fGx7vehHaVmkAgR1pJn = [DTF3Lwy9etRH8mI(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭ౌ")]+ZcUkyaPDlKMb6+[qTVF3icWwGXy5(u"࠭ࡍࡊ࡚ࡈࡈ్ࠬ")]+y46TMmgNJ80XDRWArUlGfxBKkoEpi+[iqHhJSxdaANDG5rlZm7B(u"ࠧࡑࡗࡅࡐࡎࡉࠧ౎")]+krTUKuO6xwR+[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ౏")]+YY2sanqyXwEIGtMxziDOHLgKQkZ4
eJAcFfPEs2ahrSgw1kKTDb06XoyQlH = [hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡄࡏࡔࡇࡍࠨ౐"),DTF3Lwy9etRH8mI(u"ࠪࡅࡐ࡝ࡁࡎࠩ౑"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡎࡌࡉࡍࡏࠪ౒"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ౓"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ౔"),ssGdubC4mngM9D5SRc3Ye(u"ࠧࡔࡊࡒࡓࡋࡓࡁౕ࡙ࠩ"),RVpeGcmPxj9tCnT40Nf216(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈౖࠫ"),rr7Xolsp4JwjPK3L(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ౗"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨౘ"),cJSNFCIhymEfx6grGu0M(u"ࠫࡒ࠹ࡕࠨౙ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡏࡐࡕࡘࠪౚ"),bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡂࡐࡍࡕࡅࠬ౛"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ౜"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ౝ")]
NOT_TO_TEST_ALL_SERVERS = [dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡢࡅࡐࡕ࡟ࠨ౞"),iAGgjwb7tVMmacRJ(u"ࠪࡣࡆࡑࡗࡠࠩ౟"),FWqeEzO1i8Dn0ga(u"ࠫࡤࡏࡆࡍࡡࠪౠ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡥࡋࡓࡄࡢࠫౡ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࡟ࡎࡔࡉࡣࠬౢ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡠࡕࡋࡑࡤ࠭ౣ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡡࡖࡌ࡛ࡥࠧ౤"),cJSNFCIhymEfx6grGu0M(u"ࠩࡢ࡝࡚࡚࡟ࠨ౥"),qTVF3icWwGXy5(u"ࠪࡣࡉࡒࡍࡠࠩ౦"),ssGdubC4mngM9D5SRc3Ye(u"ࠫࡤࡓࡕࠨ౧"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡥࡉࡑࠩ౨"),FWqeEzO1i8Dn0ga(u"࠭࡟ࡃࡍࡕࡣࠬ౩"),EHUAyW2lQfe4LXmhgIGc(u"ࠧࡠࡇࡏࡇࡤ࠭౪"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡡࡄࡖ࡙ࡥࠧ౫")]
I0WwEiyadX8qGtNAzc4 = [jR9YtmsgDX8nTQlMb6G3(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡓࡉࡗࡓࠧ౬"),t2sCrJ0xbgDRkf(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ౭"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡒࡋࡎࡖࡡࡇࡉࡘࡉࡅࡏࡆࡈࡈࡤࡖࡅࡓࡏࠪ౮"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊ࡟ࡑࡇࡕࡑࠬ౯"),rxWDdRBIct57i90s(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉࡥࡔࡆࡏࡓࠫ౰"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬ౱"),ETNq5t4MYngSsbfFD8J0v(u"ࠨࡏࡈࡒ࡚ࡥࡄࡆࡕࡆࡉࡓࡊࡅࡅࡡࡗࡉࡒࡖࠧ౲"),ETNq5t4MYngSsbfFD8J0v(u"ࠩࡐࡉࡓ࡛࡟ࡓࡃࡑࡈࡔࡓࡉ࡛ࡇࡇࡣ࡙ࡋࡍࡑࠩ౳")]
VUxGrbhSsEQjcltBTDmYIzKyeAvaqZ = [
						 ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ౴")
						,dC3PsQJ0Ti28uYlov(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭౵")
						,t2sCrJ0xbgDRkf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭౶")
						]
g3douDifIqHWVZ2AL9E6zScwR0OrG1 = [
						 UighHKAfySm4PWErqJ(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚ࡓ࠮࠳ࡶࡸࠬ౷")
						,RVpeGcmPxj9tCnT40Nf216(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ౸")
						,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ౹")
						,DTF3Lwy9etRH8mI(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ౺")
						,rr7Xolsp4JwjPK3L(u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ౻")
						,EHUAyW2lQfe4LXmhgIGc(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ౼")
						,EHUAyW2lQfe4LXmhgIGc(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ౽")
						,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ౾")
						,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ౿")
						,DTF3Lwy9etRH8mI(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬಀ")
						,t2sCrJ0xbgDRkf(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩಁ")
						,DTF3Lwy9etRH8mI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪಂ")
						,RVpeGcmPxj9tCnT40Nf216(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪಃ")
						,EHUAyW2lQfe4LXmhgIGc(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ಄")
						,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨಅ")
						]
x6jGtaZDVI = g3douDifIqHWVZ2AL9E6zScwR0OrG1+[
				 Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩಆ")
				,VHrIziKUDuNGXkMla(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಇ")
				,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಈ")
				,iAGgjwb7tVMmacRJ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭ಉ")
				,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧಊ")
				,FWqeEzO1i8Dn0ga(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨಋ")
				,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨಌ")
				,jR9YtmsgDX8nTQlMb6G3(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩ಍")
				,FWqeEzO1i8Dn0ga(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪಎ")
				,VHrIziKUDuNGXkMla(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ಏ")
				,iAGgjwb7tVMmacRJ(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ಐ")
				,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧ಑")
				,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨಒ")
				,EHUAyW2lQfe4LXmhgIGc(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫಓ")
				,qTVF3icWwGXy5(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨಔ")
				,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪಕ")
				]
vu5wBPhStlH2b7MR = [EHUAyW2lQfe4LXmhgIGc(u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪಖ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫಗ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬಘ"),jR9YtmsgDX8nTQlMb6G3(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ಙ"),ssGdubC4mngM9D5SRc3Ye(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧಚ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨಛ")]
Kkfl8xemuHbd1w3a0ABPcDrN = {
			 RVpeGcmPxj9tCnT40Nf216(u"ࠨࡃࡋ࡛ࡆࡑࠧಜ")		:[RVpeGcmPxj9tCnT40Nf216(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫಝ")]
			,FWqeEzO1i8Dn0ga(u"ࠪࡅࡐࡕࡁࡎࠩಞ")		:[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹ࠳ࡴࡲࡤࠨಟ")]
			,yiaeCEwJjOcWA4ZSd5h(u"ࠬࡇࡋࡘࡃࡐࠫಠ")		:[cjbAkCIinvs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭ಡ")]
			,cjbAkCIinvs(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪಢ")	:[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨಣ")]
			,rr7Xolsp4JwjPK3L(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫತ")		:[iAGgjwb7tVMmacRJ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩಥ")]
			,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬದ")		:[ssGdubC4mngM9D5SRc3Ye(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡳࡳࡵࡤࡤ࠲ࡹࡼࠧಧ")]
			,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨನ")		:[UighHKAfySm4PWErqJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱ࡭ࡲ࡫ࡺࡪࡦ࠱ࡷ࡭ࡵࡷࠨ಩")]
			,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭ಪ")	:[DTF3Lwy9etRH8mI(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩಫ")]
			,cJSNFCIhymEfx6grGu0M(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬಬ")		:[VHrIziKUDuNGXkMla(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫಭ")]
			,cJSNFCIhymEfx6grGu0M(u"ࠬࡇ࡙ࡍࡑࡏࠫಮ")		:[ETNq5t4MYngSsbfFD8J0v(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧ࠱ࡥࡾࡲ࡯࡭࠰ࡱࡩࡹ࠭ಯ")]
			,qTVF3icWwGXy5(u"ࠧࡃࡑࡎࡖࡆ࠭ರ")		:[yiaeCEwJjOcWA4ZSd5h(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧಱ")]
			,iqHhJSxdaANDG5rlZm7B(u"ࠩࡅࡖࡘ࡚ࡅࡋࠩಲ")		:[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧࡸࡳࡵࡧ࡭࠲ࡨࡵ࡭ࠨಳ")]
			,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ಴")		:[cJSNFCIhymEfx6grGu0M(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠸࠵࠶࠮ࡤࡱࡰࠫವ")]
			,iqHhJSxdaANDG5rlZm7B(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ಶ")		:[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡧ࡮ࡳࡡ࠵ࡲ࠱ࡧࡴࡳࠧಷ")]
			,t2sCrJ0xbgDRkf(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨಸ")		:[dC3PsQJ0Ti28uYlov(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠵ࡨ࡯࡭ࡢ࠶ࡸ࠲ࡨࡵ࡭ࠨಹ")]
			,DTF3Lwy9etRH8mI(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ಺")		:[iqHhJSxdaANDG5rlZm7B(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠶ࡦࡩࡵ࠮ࡤࡱࡰࠫ಻")]
			,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ಼ࠧ")		:[t2sCrJ0xbgDRkf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡥࡹࡩࡨࠨಽ")]
			,cJSNFCIhymEfx6grGu0M(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ಾ")	:[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺࡻ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭ಿ")]
			,dC3PsQJ0Ti28uYlov(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫೀ")		:[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵ࠱ࡧࡴࡳࠧು")]
			,t2sCrJ0xbgDRkf(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ೂ")		:[dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡪࡷ࡫ࡥ࠯ࡸ࡬ࡴࠬೃ")]
			,jR9YtmsgDX8nTQlMb6G3(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩೄ")	:[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠵࠻࠳ࡳࡹ࠮ࡥ࡬ࡱࡦ࠴࡮ࡦࡶ࠲ࡱࡾࡩ࠱ࠨ೅")]
			,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩೆ")		:[iqHhJSxdaANDG5rlZm7B(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡨࡩࠧೇ")]
			,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬೈ")		:[jR9YtmsgDX8nTQlMb6G3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡺࡦࡦࡹ࠮࡮ࡻࡦ࡭ࡲࡧ࠮ࡤࡥࠪ೉")]
			,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪೊ")	:[dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ೋ"),ssGdubC4mngM9D5SRc3Ye(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨೌ")]
			,ssGdubC4mngM9D5SRc3Ye(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈ್ࠫ")	:[dC3PsQJ0Ti28uYlov(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠻࠮ࡥࡴࡤࡱࡦࡩࡡࡧࡧ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪ೎")]
			,FWqeEzO1i8Dn0ga(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ೏")		:[cJSNFCIhymEfx6grGu0M(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡣ࠯ࡦࡵࡥࡲࡧࡳ࠸࠰ࡦࡳࡲ࠭೐")]
			,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ೑")		:[RVpeGcmPxj9tCnT40Nf216(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡨࡸࡲࠬ೒")]
			,iqHhJSxdaANDG5rlZm7B(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ೓")		:[rxWDdRBIct57i90s(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡻࡪࡨࡣࡢ࡯ࠪ೔")]
			,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫೕ")		:[DTF3Lwy9etRH8mI(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪೖ")]
			,RVpeGcmPxj9tCnT40Nf216(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭೗")		:[UighHKAfySm4PWErqJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ೘")]
			,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ೙")		:[ssGdubC4mngM9D5SRc3Ye(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ೚")]
			,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ೛")		:[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ೜")]
			,dC3PsQJ0Ti28uYlov(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ೝ")	:[cjbAkCIinvs(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࡬ࡨ࠳࡫࡬ࡪࡨ࠱ࡲࡪࡽࡳࠨೞ")]
			,FWqeEzO1i8Dn0ga(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭೟")		:[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫೠ")]
			,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪೡ")	:[iqHhJSxdaANDG5rlZm7B(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭ೢ")]
			,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪೣ")		:[ssGdubC4mngM9D5SRc3Ye(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡰ࠯ࡨࡤࡶࡪࡹ࡫ࡰ࠰ࡱࡩࡹ࠭೤")]
			,dC3PsQJ0Ti28uYlov(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭೥")		:[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫ೦")]
			,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡆࡐࡕࡗࡅࠬ೧")		:[cJSNFCIhymEfx6grGu0M(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫ೨")]
			,DTF3Lwy9etRH8mI(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩ೩")		:[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࠳ࡧ࡬࡮ࡧࡶ࡬ࡰࡧࡨ࠯ࡰࡨࡸࠬ೪")]
			,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡊ࡚࡙ࡈࡂࡔࡗ࡚ࠬ೫")		:[UighHKAfySm4PWErqJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨ࠮ࡧࡷࡶ࡬ࡦࡸ࠭ࡵࡸ࠱ࡧࡴࡳࠧ೬")]
			,rxWDdRBIct57i90s(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ೭")	:[FWqeEzO1i8Dn0ga(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡩࡹࡸ࡮ࡡࡳ࠰ࡹ࡭ࡩ࡫࡯ࠨ೮")]
			,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ೯")		:[rr7Xolsp4JwjPK3L(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡫ࡥࡱࡧࡣࡪ࡯ࡤ࠲ࡲ࡫ࡤࡪࡣࠪ೰")]
			,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡌࡊࡎࡒࡍࠨೱ")		:[ssGdubC4mngM9D5SRc3Ye(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫೲ"),DTF3Lwy9etRH8mI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡮࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬೳ"),rr7Xolsp4JwjPK3L(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭೴"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠵࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ೵"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠺࠵࠱࠵࠾࠶࠮࠳࠶࠱࠵࠷࠸ࠧ೶")]
			,rxWDdRBIct57i90s(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ೷")	:[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡦࡸࡢࡢ࡮ࡤ࠱ࡹࡼ࠮ࡪࡳࠪ೸")]
			,jR9YtmsgDX8nTQlMb6G3(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ೹")		:[iqHhJSxdaANDG5rlZm7B(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰࡮࡭ࡹࡱ࡯ࡵ࠰ࡦࡥࡲ࠭೺")]
			,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭೻")		:[rxWDdRBIct57i90s(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡷ࠱࡯࡮ࡸ࡭ࡢ࡮࡮࠲ࡨࡵ࡭ࠨ೼")]
			,jR9YtmsgDX8nTQlMb6G3(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭೽")	:[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ೾"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼࠳࡬ࡷࡴ࠰ࡶࡸࡴࡸࡥࠨ೿")]
			,EHUAyW2lQfe4LXmhgIGc(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪഀ")		:[dC3PsQJ0Ti28uYlov(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮ࡧࡱࠪഁ")]
			,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ം")		:[cjbAkCIinvs(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭ഃ")]
			,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪഄ")	:[iAGgjwb7tVMmacRJ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡢࡵࡤࡺ࡮ࡪࡥࡰ࠰ࡱࡩࡼࡹࠧഅ")]
			,cJSNFCIhymEfx6grGu0M(u"ࠩࡓࡅࡓࡋࡔࠨആ")		:[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬഇ")]
			,yiaeCEwJjOcWA4ZSd5h(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ഈ")		:[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ഉ")]
			,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪഊ")	:[UighHKAfySm4PWErqJ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬഋ")]
			,RVpeGcmPxj9tCnT40Nf216(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫഌ")	:[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥ࠳࡙ࡈࡂࡄࡄࡏࡆ࡚࡙࠯ࡸ࡬ࡴࠬ഍")]
			,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬഎ")		:[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡦࡦ࠷ࡹ࠷࠴ࡣࡰ࡯ࠪഏ")]
			,rr7Xolsp4JwjPK3L(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩഐ")	:[jR9YtmsgDX8nTQlMb6G3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ഑")]
			,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡔࡊࡒࡊࡍࡇࠧഒ")		:[cjbAkCIinvs(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡳࡩࡱࡩ࡬ࡦ࠴ࡴࡷࠩഓ")]
			,iqHhJSxdaANDG5rlZm7B(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫഔ")		:[cjbAkCIinvs(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪക"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫഖ"),cjbAkCIinvs(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨഗ")]
			,FWqeEzO1i8Dn0ga(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨഘ")		:[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦࡱࡷࡢ࡯࠱ࡸࡺࡨࡥࠨങ")]
			,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡖࡌࡏࡆࡇࡔࠨച")		:[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡵ࡫࡮ࡥࡦࡺ࠮࡯ࡧࡷࠫഛ")]
			,t2sCrJ0xbgDRkf(u"ࠪࡘ࡛ࡌࡕࡏࠩജ")		:[cjbAkCIinvs(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩഝ")]
			,cjbAkCIinvs(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬഞ")		:[iAGgjwb7tVMmacRJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ട")]
			,cjbAkCIinvs(u"ࠧࡗࡋࡇࡉࡔࡔࡓࡂࡇࡐࠫഠ")	:[FWqeEzO1i8Dn0ga(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡰࡶࡥࡪࡳ࠮࡯ࡧࡷࠫഡ")]
			,iAGgjwb7tVMmacRJ(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪഢ")		:[iqHhJSxdaANDG5rlZm7B(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡸ࡮࡯ࡸࠩണ")]
			,iqHhJSxdaANDG5rlZm7B(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬത")		:[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡣ࡭࡫ࡦ࡯ࠬഥ")]
			,rr7Xolsp4JwjPK3L(u"࡙࠭ࡂࡓࡒࡘࠬദ")		:[rxWDdRBIct57i90s(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬധ")]
			,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩന")		:[UighHKAfySm4PWErqJ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬഩ")]
			,FWqeEzO1i8Dn0ga(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩപ")	:[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧഫ")]
			,cJSNFCIhymEfx6grGu0M(u"ࠬࡏࡐࡕࡘࠪബ")			:[t2sCrJ0xbgDRkf(u"࠭ࠧഭ")]
			,iqHhJSxdaANDG5rlZm7B(u"ࠧࡎ࠵ࡘࠫമ")			:[VHrIziKUDuNGXkMla(u"ࠨࠩയ")]
			,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡕࡉࡕࡕࡓࠨര")		:[ssGdubC4mngM9D5SRc3Ye(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪറ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨല"),ETNq5t4MYngSsbfFD8J0v(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩള")]
			,rxWDdRBIct57i90s(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩഴ")	:[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬവ"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪശ"),yiaeCEwJjOcWA4ZSd5h(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫഷ")]
			,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫസ")		:[UighHKAfySm4PWErqJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫഹ"),iAGgjwb7tVMmacRJ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪഺ"),UighHKAfySm4PWErqJ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ഻ࠩ")]
			}
if fdQOo6Hu4B5Rbg:
	Kkfl8xemuHbd1w3a0ABPcDrN[FWqeEzO1i8Dn0ga(u"ࠧࡑ࡛ࡗࡌࡔࡔ഼ࠧ")] = [yiaeCEwJjOcWA4ZSd5h(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪഽ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧാ"),VHrIziKUDuNGXkMla(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭ി"),iAGgjwb7tVMmacRJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩീ"),rr7Xolsp4JwjPK3L(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩു"),t2sCrJ0xbgDRkf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬൂ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨൃ"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩൄ"),yiaeCEwJjOcWA4ZSd5h(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ൅"),cJSNFCIhymEfx6grGu0M(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨെ")]
	Kkfl8xemuHbd1w3a0ABPcDrN[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨേ")] = [cJSNFCIhymEfx6grGu0M(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨൈ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ൉"),rr7Xolsp4JwjPK3L(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫൊ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧോ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧൌ"),iAGgjwb7tVMmacRJ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ്ࠪ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ൎ"),iAGgjwb7tVMmacRJ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ൏"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ൐"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭൑")]
else:
	Kkfl8xemuHbd1w3a0ABPcDrN[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ൒")] = [hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ൓"),iqHhJSxdaANDG5rlZm7B(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩൔ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨൕ"),EHUAyW2lQfe4LXmhgIGc(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫൖ"),rr7Xolsp4JwjPK3L(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫൗ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ൘"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ൙"),cjbAkCIinvs(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ൚"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ൛"),jR9YtmsgDX8nTQlMb6G3(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ൜")]
	Kkfl8xemuHbd1w3a0ABPcDrN[iAGgjwb7tVMmacRJ(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ൝")] = [bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ൞"),UighHKAfySm4PWErqJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ൟ"),rr7Xolsp4JwjPK3L(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬൠ"),ETNq5t4MYngSsbfFD8J0v(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨൡ"),iqHhJSxdaANDG5rlZm7B(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨൢ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫൣ"),rxWDdRBIct57i90s(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ൤"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ൥"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ൦"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ൧")]
TMKgSsLYy0A429rkWvq = [iAGgjwb7tVMmacRJ(u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫ൨"),qTVF3icWwGXy5(u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫ൩"),DTF3Lwy9etRH8mI(u"ࠫࡊࡓࡁࡊࡎࡖࠫ൪"),rxWDdRBIct57i90s(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ൫"),RVpeGcmPxj9tCnT40Nf216(u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ൬"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ൭"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭൮"),iAGgjwb7tVMmacRJ(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ൯"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡘࡊ࡙ࡔࡊࡐࡊࠫ൰"),t2sCrJ0xbgDRkf(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭൱")]
RvGE4rQKubUyZSa = [CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡇࡄࡅࡑࡑࡗࠬ൲"),cJSNFCIhymEfx6grGu0M(u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠸ࠨ൳"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠺ࠩ൴")]
class GDCMAfqb8LjRVu(EbOZKPeXIg):
	def __init__(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,*aargs,**kkwargs):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.choiceID = -fdQOo6Hu4B5Rbg
	def onClick(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,Y6jlrRAmkGpd):
		if Y6jlrRAmkGpd>=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠾࠶࠱࠱፶"): sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.choiceID = Y6jlrRAmkGpd-ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠾࠶࠱࠱፶")
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.UBxXTALSKiOj7MQGCNY612p9PuJ()
	def S3yQOFb0NB2CifckvL84XZMmpuT(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,*aargs):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button0,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button1,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button2 = aargs[dQ5JhEYolPmy1fvHktMw6NFRxiz],aargs[fdQOo6Hu4B5Rbg],aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.header,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.text = aargs[c1R9fnIY4XBDZ],aargs[xsCEkXb6tgrh3195YZ]
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.profile,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.direction = aargs[yiaeCEwJjOcWA4ZSd5h(u"࠻፷")],aargs[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠶፸")]
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout = aargs[FWqeEzO1i8Dn0ga(u"࠹፺")],aargs[t2sCrJ0xbgDRkf(u"࠹፹")]
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout>dQ5JhEYolPmy1fvHktMw6NFRxiz or sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout>ssGdubC4mngM9D5SRc3Ye(u"࠳፻"): sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.enable_progressbar = P5VqbRSzjtO4UE1rZaolG67XA
		else: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.enable_progressbar = kkMuQrLWcEayRm
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename = F0xXYapD5dS4HBM.replace(iqHhJSxdaANDG5rlZm7B(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ൵"),dC3PsQJ0Ti28uYlov(u"ࠩࡢࠫ൶")+str(SSCU3jdyFn2V.time())+iAGgjwb7tVMmacRJ(u"ࠪࡣࠬ൷"))
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename = sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename.replace(dC3PsQJ0Ti28uYlov(u"ࠫࡡࡢࠧ൸"),cjbAkCIinvs(u"ࠬࡢ࡜࡝࡞ࠪ൹")).replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࠯࠰ࠩൺ"),FWqeEzO1i8Dn0ga(u"ࠧ࠰࠱࠲࠳ࠬൻ"))
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_height = cvGgZknSKbf6lU7pwt8Y(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button0,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button1,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button2,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.header,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.text,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.profile,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.direction,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.enable_progressbar,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename)
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.show()
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(ETNq5t4MYngSsbfFD8J0v(u"࠽࠵࠻࠰፼")).setImage(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename)
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠾࠶࠵࠱፽")).setHeight(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_height)
		if not sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button1 and sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button0 and sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button2: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(dC3PsQJ0Ti28uYlov(u"࠹࠱࠳࠵፿")).setPosition(-ssGdubC4mngM9D5SRc3Ye(u"࠳࠴࠳ᎀ"),RVpeGcmPxj9tCnT40Nf216(u"࠶፾"))
		return sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_height
	def OA4TgriyIlYZBQ7EqU(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout:
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.th1 = fu19TY0PdM6AZB5.Thread(target=sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.ZQdDT6BpoV8zwsPyR0MIhJg5,args=())
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.th1.start()
		else: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.uD32VbpYG40qaLWlSm9AQIMh6owsCn()
	def ZQdDT6BpoV8zwsPyR0MIhJg5(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(UighHKAfySm4PWErqJ(u"࠻࠳࠶࠵ᎁ")).setEnabled(P5VqbRSzjtO4UE1rZaolG67XA)
		for p0p6MxKbklodNCR92Wv in range(fdQOo6Hu4B5Rbg,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout+fdQOo6Hu4B5Rbg):
			SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
			s1nV7afRxIO6j0dmpTbN = int(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠴࠴࠵ᎂ")*p0p6MxKbklodNCR92Wv/sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout)
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.x5xcY1UazDm9MIwQyG(s1nV7afRxIO6j0dmpTbN)
			if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.choiceID>wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠴ᎃ"): break
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.uD32VbpYG40qaLWlSm9AQIMh6owsCn()
	def jWbzRYhZaSHpi8Jg6LGVcP0MOC1ND(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout:
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.th2 = fu19TY0PdM6AZB5.Thread(target=sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.rA6O1vWSIg2xK9bps3Nuef,args=())
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.th2.start()
		else: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.uD32VbpYG40qaLWlSm9AQIMh6owsCn()
	def rA6O1vWSIg2xK9bps3Nuef(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(RVpeGcmPxj9tCnT40Nf216(u"࠾࠶࠲࠱ᎄ")).setEnabled(P5VqbRSzjtO4UE1rZaolG67XA)
		SSCU3jdyFn2V.sleep(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.buttonstimeout)
		for p0p6MxKbklodNCR92Wv in range(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout-fdQOo6Hu4B5Rbg,-fdQOo6Hu4B5Rbg,-fdQOo6Hu4B5Rbg):
			SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
			s1nV7afRxIO6j0dmpTbN = int(rxWDdRBIct57i90s(u"࠷࠰࠱ᎅ")*p0p6MxKbklodNCR92Wv/sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout)
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.x5xcY1UazDm9MIwQyG(s1nV7afRxIO6j0dmpTbN)
			if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.choiceID>dQ5JhEYolPmy1fvHktMw6NFRxiz: break
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.closetimeout>dQ5JhEYolPmy1fvHktMw6NFRxiz: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.choiceID = EHUAyW2lQfe4LXmhgIGc(u"࠱࠱ᎆ")
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.UBxXTALSKiOj7MQGCNY612p9PuJ()
	def x5xcY1UazDm9MIwQyG(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,s1nV7afRxIO6j0dmpTbN):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.precent = s1nV7afRxIO6j0dmpTbN
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(iAGgjwb7tVMmacRJ(u"࠺࠲࠵࠴ᎇ")).setPercent(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.precent)
	def uD32VbpYG40qaLWlSm9AQIMh6owsCn(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button0: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(vCmnFshSi4flecXIY2gy38G0DJw(u"࠻࠳࠵࠵ᎈ")).setEnabled(P5VqbRSzjtO4UE1rZaolG67XA)
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button1: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(DTF3Lwy9etRH8mI(u"࠼࠴࠶࠷ᎉ")).setEnabled(P5VqbRSzjtO4UE1rZaolG67XA)
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.button2: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.getControl(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠽࠵࠷࠲ᎊ")).setEnabled(P5VqbRSzjtO4UE1rZaolG67XA)
	def UBxXTALSKiOj7MQGCNY612p9PuJ(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.close()
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.image_filename)
		except: pass
class QnzeRvFJ8G():
	def __init__(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,showDialogs=kkMuQrLWcEayRm,logErrors=P5VqbRSzjtO4UE1rZaolG67XA):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.showDialogs = showDialogs
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.logErrors = logErrors
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.finishedLIST,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.failedLIST = [],[]
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.statusDICT,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.resultsDICT = {},{}
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.processesLIST = []
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.starttimeDICT,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.finishtimeDICT,sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.elpasedtimeDICT = {},{},{}
	def zSpce8FsXjQyi390AOEBV7lIwr(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,ww5lQDRFdag8VnuXOTUMCbcp,Xg92etbKYaHnfm38j,*aargs):
		ww5lQDRFdag8VnuXOTUMCbcp = str(ww5lQDRFdag8VnuXOTUMCbcp)
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.statusDICT[ww5lQDRFdag8VnuXOTUMCbcp] = yiaeCEwJjOcWA4ZSd5h(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩർ")
		if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.showDialogs: XXeZuvhknsKYqB17gwm6dfc(G9G0YqivIfmUWO8K,ww5lQDRFdag8VnuXOTUMCbcp)
		QQtXwjfvhARJ = fu19TY0PdM6AZB5.Thread(target=sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.WAzd4MRxuZGCtNeS0BQ29wnDEkaT3o,args=(ww5lQDRFdag8VnuXOTUMCbcp,Xg92etbKYaHnfm38j,aargs))
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.processesLIST.append(QQtXwjfvhARJ)
		return QQtXwjfvhARJ
	def gVHbwiKWqxL(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,ww5lQDRFdag8VnuXOTUMCbcp,Xg92etbKYaHnfm38j,*aargs):
		QQtXwjfvhARJ = sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.zSpce8FsXjQyi390AOEBV7lIwr(ww5lQDRFdag8VnuXOTUMCbcp,Xg92etbKYaHnfm38j,*aargs)
		QQtXwjfvhARJ.start()
	def WAzd4MRxuZGCtNeS0BQ29wnDEkaT3o(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,ww5lQDRFdag8VnuXOTUMCbcp,Xg92etbKYaHnfm38j,aargs):
		ww5lQDRFdag8VnuXOTUMCbcp = str(ww5lQDRFdag8VnuXOTUMCbcp)
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.starttimeDICT[ww5lQDRFdag8VnuXOTUMCbcp] = SSCU3jdyFn2V.time()
		try:
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.resultsDICT[ww5lQDRFdag8VnuXOTUMCbcp] = Xg92etbKYaHnfm38j(*aargs)
			if dC3PsQJ0Ti28uYlov(u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪൽ") in str(Xg92etbKYaHnfm38j) and not sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.resultsDICT[ww5lQDRFdag8VnuXOTUMCbcp].succeeded: NNetFngY7vowQPJp5xCumG2qrKcfk1()
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.finishedLIST.append(ww5lQDRFdag8VnuXOTUMCbcp)
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.statusDICT[ww5lQDRFdag8VnuXOTUMCbcp] = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬൾ")
		except Exception as MGlP3SpZY8VTHmBt7:
			if sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.logErrors:
				fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
				if fEKoHajMCOh!=jR9YtmsgDX8nTQlMb6G3(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧൿ"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.failedLIST.append(ww5lQDRFdag8VnuXOTUMCbcp)
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.statusDICT[ww5lQDRFdag8VnuXOTUMCbcp] = DTF3Lwy9etRH8mI(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ඀")
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.finishtimeDICT[ww5lQDRFdag8VnuXOTUMCbcp] = SSCU3jdyFn2V.time()
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.elpasedtimeDICT[ww5lQDRFdag8VnuXOTUMCbcp] = sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.finishtimeDICT[ww5lQDRFdag8VnuXOTUMCbcp] - sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.starttimeDICT[ww5lQDRFdag8VnuXOTUMCbcp]
	def rLew60CtWuYQ8sxZ21lEPHkmh9vd(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		for fEhMyIUV1LdTFXxsloa62QqB in sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.processesLIST:
			fEhMyIUV1LdTFXxsloa62QqB.start()
	def DExaBcOv3lsIAm(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		while GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧඁ") in list(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.statusDICT.values()): SSCU3jdyFn2V.sleep(RVpeGcmPxj9tCnT40Nf216(u"࠶ᎋ"))
def fnZKIRS4TapChxV2EwF():
	if not jlFg5ptfLPEYns7mkOuyZG4z0WaqK: return EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪං")
	EWdBekDQqgcUL = EHUAyW2lQfe4LXmhgIGc(u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭ඃ")
	WiGkdF01eKX9Ogrj = [dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࠻࠲࠺࠴࠰ࠨ඄"),ETNq5t4MYngSsbfFD8J0v(u"ࠪ࠶࠵࠸࠱࠯࠳࠳࠲࠶࠿ࠧඅ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠷࠶࠲࠲࠰࠴࠵࠳࠸࠴ࡢࠩආ"),ssGdubC4mngM9D5SRc3Ye(u"ࠬ࠸࠰࠳࠳࠱࠵࠷࠴࠳࠱ࠩඇ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭࠲࠱࠴࠵࠲࠵࠸࠮࠱࠴ࠪඈ"),UighHKAfySm4PWErqJ(u"ࠧ࠳࠲࠵࠶࠳࠷࠰࠯࠴࠵ࠫඉ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࠴࠳࠶࠸࠴࠰࠴࠰࠳࠺ࠬඊ"),VHrIziKUDuNGXkMla(u"ࠩ࠵࠴࠷࠹࠮࠱࠷࠱࠵࠻࠭උ"),iAGgjwb7tVMmacRJ(u"ࠪ࠶࠵࠸࠳࠯࠲࠹࠲࠵࠼ࠧඌ"),qTVF3icWwGXy5(u"ࠫ࠷࠶࠲࠴࠰࠴࠴࠳࠸࠸ࠨඍ"),ETNq5t4MYngSsbfFD8J0v(u"ࠬ࠸࠰࠳࠶࠱࠴࠶࠴࠱࠵ࠩඎ"),VHrIziKUDuNGXkMla(u"࠭࠲࠱࠴࠷࠲࠵࠽࠮࠳࠲ࠪඏ")]
	rNOmbTL2X3wVqPlFoxsSY = WiGkdF01eKX9Ogrj[-fdQOo6Hu4B5Rbg]
	zs4ZRxfy7MWimvb = hwmEHOpWo24TygucdVUM(rNOmbTL2X3wVqPlFoxsSY)
	PgJk5tpj9Hin32mT = hwmEHOpWo24TygucdVUM(GBx0Fcf7sLbqlntEX3yMezu)
	if PgJk5tpj9Hin32mT>zs4ZRxfy7MWimvb:
		EWdBekDQqgcUL = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧඐ")
	return EWdBekDQqgcUL
def bokM8YKe3AVmjnq4():
	for EEJceIDXMy2TFb90AS1oRUf,UU8hpuKsC7an50qAOXelvTfby2Fi,WX5T7vwl4P0qtOgmLNkzKGBUfeY in ifTNQtY3XrquHMV4wlCgI6FmpPK.walk(ffDhnivjmRXeuHSIa1qEZNA,topdown=kkMuQrLWcEayRm):
		if len(WX5T7vwl4P0qtOgmLNkzKGBUfeY)>qTVF3icWwGXy5(u"࠻࠰࠱ᎌ"): Sm8oLxifPQNzI(EEJceIDXMy2TFb90AS1oRUf,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	return
def vXAlKF2MkTnw0icVNIua1qR(BM9q472Scdmj0):
	if iAGgjwb7tVMmacRJ(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪඑ") in str(IIHKo82wPrNpgqCkQJOV): return
	global Kkfl8xemuHbd1w3a0ABPcDrN,f5jdSUbP761JrgynW2GZAXIsc8YRCQ,U6keACwnTHK71tsy,fGx7vehHaVmkAgR1pJn
	X6h8sAqwxPov93J0RCHZVmcOy = G9G0YqivIfmUWO8K
	if BM9q472Scdmj0: X6h8sAqwxPov93J0RCHZVmcOy = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,jR9YtmsgDX8nTQlMb6G3(u"ࠩࡶࡸࡷ࠭ඒ"),jR9YtmsgDX8nTQlMb6G3(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ඓ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭ඔ"))
	if not X6h8sAqwxPov93J0RCHZVmcOy:
		yzieWRVX4nkB3DjGHJphEdQo = Kkfl8xemuHbd1w3a0ABPcDrN[RVpeGcmPxj9tCnT40Nf216(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬඕ")][DTF3Lwy9etRH8mI(u"࠹ᎍ")]
		nLi5fzKDxgcvMY0C3GUpedPSQ = {CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡵࡴࡧࡵࠫඖ"):iOtjqZ6Iydl,DTF3Lwy9etRH8mI(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ඗"):GBx0Fcf7sLbqlntEX3yMezu}
		DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡒࡒࡗ࡙࠭඘"),yzieWRVX4nkB3DjGHJphEdQo,nLi5fzKDxgcvMY0C3GUpedPSQ,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡡࡓ࡝࡙ࡎࡏࡏࡡࡆࡓࡉࡋ࠭࠲ࡵࡷࠫ඙"))
		if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
			X6h8sAqwxPov93J0RCHZVmcOy = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ක"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭ඛ"),X6h8sAqwxPov93J0RCHZVmcOy,UKDwMTZk9dni1JSLcf0oRXhqy)
	if X6h8sAqwxPov93J0RCHZVmcOy:
		global NEW_SITESURLS,SpMGtPOf20hUK5BNLb,jnYipcC6lerd7xT4QW50g1
		exec(X6h8sAqwxPov93J0RCHZVmcOy,globals(),locals())
		Kkfl8xemuHbd1w3a0ABPcDrN.update(NEW_SITESURLS)
		f5jdSUbP761JrgynW2GZAXIsc8YRCQ = SpMGtPOf20hUK5BNLb
		if GBx0Fcf7sLbqlntEX3yMezu in list(jnYipcC6lerd7xT4QW50g1.keys()): U6keACwnTHK71tsy += jnYipcC6lerd7xT4QW50g1[GBx0Fcf7sLbqlntEX3yMezu]
		for oob2dzmG3jTMpZwQyIfN in U6keACwnTHK71tsy:
			if oob2dzmG3jTMpZwQyIfN in fGx7vehHaVmkAgR1pJn: fGx7vehHaVmkAgR1pJn.remove(oob2dzmG3jTMpZwQyIfN)
	return
def s4pFjloGN8whX6EZIcr1SbP7x():
	try: ifTNQtY3XrquHMV4wlCgI6FmpPK.makedirs(ZwIThN17YKVQnbp52gX)
	except: pass
	BZ3O2T6qeR1Yim5QaFJcXjG4xWD9 = fnZKIRS4TapChxV2EwF()
	if BZ3O2T6qeR1Yim5QaFJcXjG4xWD9==DTF3Lwy9etRH8mI(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬග"): vvqQRbuChP(oz95q0dcEtSuxIJgP841M,cjbAkCIinvs(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡕࡌࡑࡕࡒࡅࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬඝ")+ccW1tVjJvUx5efKbPHu6yAMLqaF+FWqeEzO1i8Dn0ga(u"ࠧࠡ࡟ࠪඞ"))
	else: vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ssGdubC4mngM9D5SRc3Ye(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬඟ")+ccW1tVjJvUx5efKbPHu6yAMLqaF+iqHhJSxdaANDG5rlZm7B(u"ࠩࠣࡡࠬච"))
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ඡ"),t2sCrJ0xbgDRkf(u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫජ")+GBx0Fcf7sLbqlntEX3yMezu)
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨඣ"),cJSNFCIhymEfx6grGu0M(u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩඤ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,cJSNFCIhymEfx6grGu0M(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪඥ"),ETNq5t4MYngSsbfFD8J0v(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫඦ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,RVpeGcmPxj9tCnT40Nf216(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬට"),ETNq5t4MYngSsbfFD8J0v(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫඨ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧඩ"),cJSNFCIhymEfx6grGu0M(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧඪ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,cjbAkCIinvs(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩණ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬඬ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫත"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧථ"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,dC3PsQJ0Ti28uYlov(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ද"),RVpeGcmPxj9tCnT40Nf216(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪධ"))
	amx9qJHkhw7oLdtVMG3.setSetting(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬන"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨ඲"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(ssGdubC4mngM9D5SRc3Ye(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪඳ"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(dC3PsQJ0Ti28uYlov(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫප"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(qTVF3icWwGXy5(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬඵ"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(cjbAkCIinvs(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠷࠭බ"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭භ"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(RVpeGcmPxj9tCnT40Nf216(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪම"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ඹ"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(RVpeGcmPxj9tCnT40Nf216(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫය"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(qTVF3icWwGXy5(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩර"),G9G0YqivIfmUWO8K)
	amx9qJHkhw7oLdtVMG3.setSetting(ETNq5t4MYngSsbfFD8J0v(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ඼"),G9G0YqivIfmUWO8K)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,UighHKAfySm4PWErqJ(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫල"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,iqHhJSxdaANDG5rlZm7B(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ඾"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,UighHKAfySm4PWErqJ(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ඿"))
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,cjbAkCIinvs(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨව"))
	CU83wctmZIMAaxHv(kkMuQrLWcEayRm)
	ewXaFc6410BDW8dgYAzVR(gWhZuzBnwiUVx5RoGFc6O7Hb)
	import diEohNHXbY
	diEohNHXbY.hJXy9kqmV6gZe0C5bnuO1(P5VqbRSzjtO4UE1rZaolG67XA)
	if BZ3O2T6qeR1Yim5QaFJcXjG4xWD9==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧශ"):
		dfi8XnHqv2J3oxUSB5D7Rs1F6k(P5VqbRSzjtO4UE1rZaolG67XA,[FicKOG8M4gQsvf3naoU])
	else:
		dfi8XnHqv2J3oxUSB5D7Rs1F6k(kkMuQrLWcEayRm,[])
		diEohNHXbY.U5RhmxZzjcX4EB0HPb732Qu()
		diEohNHXbY.MJGPcFsKn9hfoukHbyOeS(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨෂ"),kkMuQrLWcEayRm)
		diEohNHXbY.MJGPcFsKn9hfoukHbyOeS(iqHhJSxdaANDG5rlZm7B(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬස"),kkMuQrLWcEayRm)
		try:
			WV1jRdI2PqeJmAwC6FXSxZB9os8g = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬහ"),EHUAyW2lQfe4LXmhgIGc(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨළ"),rxWDdRBIct57i90s(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩෆ"),cjbAkCIinvs(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ෇"))
			rhEelC8fMi = K8EzSxPHWjcp.Addon(id=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ෈"))
			rhEelC8fMi.setSetting(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧ෉"),cJSNFCIhymEfx6grGu0M(u"ࠩࡉࡥࡱࡹࡥࠨ්"))
		except: pass
		try:
			WV1jRdI2PqeJmAwC6FXSxZB9os8g = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,jR9YtmsgDX8nTQlMb6G3(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ෋"),VHrIziKUDuNGXkMla(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ෌"),ETNq5t4MYngSsbfFD8J0v(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬ෍"),yiaeCEwJjOcWA4ZSd5h(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ෎"))
			rhEelC8fMi = K8EzSxPHWjcp.Addon(id=vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧා"))
			rhEelC8fMi.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫැ"),EHUAyW2lQfe4LXmhgIGc(u"ࠩ࠶ࠫෑ"))
		except: pass
		try:
			WV1jRdI2PqeJmAwC6FXSxZB9os8g = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬි"),yiaeCEwJjOcWA4ZSd5h(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨී"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬු"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ෕"))
			rhEelC8fMi = K8EzSxPHWjcp.Addon(id=rxWDdRBIct57i90s(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧූ"))
			rhEelC8fMi.setSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭෗"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ࠵ࠫෘ"))
		except: pass
	snev3rg1V28C9pxGO6RNfIDBS0z = yBxCaXY5UwkD(iyNfWHemZaC1)
	snev3rg1V28C9pxGO6RNfIDBS0z = yBxCaXY5UwkD(Mh2XHLxaCsToiUFymceOGKS)
	diEohNHXbY.J7JyRu984hsUoScZdVD5qHnYOIbjvE(kkMuQrLWcEayRm)
	amx9qJHkhw7oLdtVMG3.setSetting(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧෙ"),GBx0Fcf7sLbqlntEX3yMezu)
	Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def CGgKTAJBluf8rYSPEUQ1kobN75O():
	aJPth0C1fc = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(ssGdubC4mngM9D5SRc3Ye(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩේ")))
	aJPth0C1fc = dQ5JhEYolPmy1fvHktMw6NFRxiz if not aJPth0C1fc else int(aJPth0C1fc)
	if not aJPth0C1fc or not dQ5JhEYolPmy1fvHktMw6NFRxiz<=AVeHPW5shuXLdr2vwD-aJPth0C1fc<=HpjLKS83swXDzVInEf2xUZaCuNbR9d:
		amx9qJHkhw7oLdtVMG3.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪෛ"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
		ewXaFc6410BDW8dgYAzVR(gWhZuzBnwiUVx5RoGFc6O7Hb)
		XdTGfUQ56zvMLB = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(jR9YtmsgDX8nTQlMb6G3(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭ො")))
		XdTGfUQ56zvMLB = dQ5JhEYolPmy1fvHktMw6NFRxiz if not XdTGfUQ56zvMLB else int(XdTGfUQ56zvMLB)
		if not XdTGfUQ56zvMLB or not dQ5JhEYolPmy1fvHktMw6NFRxiz<=AVeHPW5shuXLdr2vwD-XdTGfUQ56zvMLB<=TTm2opnt9fLX8DBYizbuSPvwhJZCl:
			amx9qJHkhw7oLdtVMG3.setSetting(DTF3Lwy9etRH8mI(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧෝ"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
			vXAlKF2MkTnw0icVNIua1qR(kkMuQrLWcEayRm)
		Auy1XJ0hs3kgWRpOn = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬෞ")))
		Auy1XJ0hs3kgWRpOn = dQ5JhEYolPmy1fvHktMw6NFRxiz if not Auy1XJ0hs3kgWRpOn else int(Auy1XJ0hs3kgWRpOn)
		if not Auy1XJ0hs3kgWRpOn or not dQ5JhEYolPmy1fvHktMw6NFRxiz<=AVeHPW5shuXLdr2vwD-Auy1XJ0hs3kgWRpOn<=AH0BQ4LKlDMrfvqWmXn5:
			amx9qJHkhw7oLdtVMG3.setSetting(VHrIziKUDuNGXkMla(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ෟ"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
			QQtXwjfvhARJ = fu19TY0PdM6AZB5.Thread(target=bokM8YKe3AVmjnq4)
			QQtXwjfvhARJ.start()
	CDpEnfibKORe0wJvY6ANWokPBXuj = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬ෠")))
	CDpEnfibKORe0wJvY6ANWokPBXuj = dQ5JhEYolPmy1fvHktMw6NFRxiz if not CDpEnfibKORe0wJvY6ANWokPBXuj else int(CDpEnfibKORe0wJvY6ANWokPBXuj)
	NkyMJ3itlWm5Od = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(rr7Xolsp4JwjPK3L(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭෡")))
	NkyMJ3itlWm5Od = dQ5JhEYolPmy1fvHktMw6NFRxiz if not NkyMJ3itlWm5Od else int(NkyMJ3itlWm5Od)
	if not CDpEnfibKORe0wJvY6ANWokPBXuj or not NkyMJ3itlWm5Od or not dQ5JhEYolPmy1fvHktMw6NFRxiz<=AVeHPW5shuXLdr2vwD-NkyMJ3itlWm5Od<=CDpEnfibKORe0wJvY6ANWokPBXuj: l73KHdntw6s()
	return
def l73KHdntw6s():
	INx86JyBXVuYc7nOUEj3H1 = fdQOo6Hu4B5Rbg
	WytVKXgGn7ZpRz9uBlAC3OhTE0 = kkMuQrLWcEayRm if iKLYEvx39c.kqWwuhJS1K3gIvpbQnGRcfl0C else P5VqbRSzjtO4UE1rZaolG67XA
	if WytVKXgGn7ZpRz9uBlAC3OhTE0:
		YvSXiz5xrJEpUlDcA = nuDV6jzU0TEISJQ(P5VqbRSzjtO4UE1rZaolG67XA)
		if len(YvSXiz5xrJEpUlDcA)>fdQOo6Hu4B5Rbg:
			vvqQRbuChP(oz95q0dcEtSuxIJgP841M,t2sCrJ0xbgDRkf(u"ࠬ࠴࡜ࡵࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ෢")+ccW1tVjJvUx5efKbPHu6yAMLqaF+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࠠ࡞ࠩ෣"))
			ww5lQDRFdag8VnuXOTUMCbcp,agZ6rli0mxGfo8,pFGTX4fZNI9RB2xKOWAdsgb,HgbMUjLOaP43Ts6W,y4gZHwkYufl,DeRNxUpz3y8h05KCvgJEi = YvSXiz5xrJEpUlDcA[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			KKGHBLXWq6pkOx,HRTLBshamJ2 = HgbMUjLOaP43Ts6W.split(jR9YtmsgDX8nTQlMb6G3(u"ࠧ࡝ࡰ࠾࠿ࠬ෤"))
			del YvSXiz5xrJEpUlDcA[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			O2bxygVasnM = voWS3GzbN5HXaTsiwLMeU.sample(YvSXiz5xrJEpUlDcA,fdQOo6Hu4B5Rbg)
			ww5lQDRFdag8VnuXOTUMCbcp,agZ6rli0mxGfo8,pFGTX4fZNI9RB2xKOWAdsgb,HgbMUjLOaP43Ts6W,y4gZHwkYufl,DeRNxUpz3y8h05KCvgJEi = O2bxygVasnM[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			pFGTX4fZNI9RB2xKOWAdsgb = ssGdubC4mngM9D5SRc3Ye(u"ࠨ࡝ࡕࡘࡑࡣࠧ෥")+ipjCIhwEXsbadR+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࠣ࠾ࠥ࠭෦")+ww5lQDRFdag8VnuXOTUMCbcp+zzGfwLAyN5HTxUoJeaivY+pFGTX4fZNI9RB2xKOWAdsgb
			y4gZHwkYufl = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩ෧")
			ohAe4cj3KsyuTEp7 = rr7Xolsp4JwjPK3L(u"ࠫฬ๊สษำ฼หฯ࠭෨")
			button0,button1 = HgbMUjLOaP43Ts6W,y4gZHwkYufl
			eCvsoQmbGgFIRp2y = [button0,button1,ohAe4cj3KsyuTEp7]
			OHSsBNg2W8C4 = fdQOo6Hu4B5Rbg if iKLYEvx39c.w0Zn3BsVo7GWDyuli else qTVF3icWwGXy5(u"࠲࠲ᎎ")
			CorYkXhAmuvNR9SDZTJz = -cjbAkCIinvs(u"࠻ᎏ")
			while CorYkXhAmuvNR9SDZTJz<dQ5JhEYolPmy1fvHktMw6NFRxiz:
				zziq3mcLD2GeBKQXYVyIF1t6Wv = voWS3GzbN5HXaTsiwLMeU.sample(eCvsoQmbGgFIRp2y,c1R9fnIY4XBDZ)
				CorYkXhAmuvNR9SDZTJz = YZL469QjvSV(G9G0YqivIfmUWO8K,zziq3mcLD2GeBKQXYVyIF1t6Wv[dQ5JhEYolPmy1fvHktMw6NFRxiz],zziq3mcLD2GeBKQXYVyIF1t6Wv[fdQOo6Hu4B5Rbg],zziq3mcLD2GeBKQXYVyIF1t6Wv[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU],KKGHBLXWq6pkOx,pFGTX4fZNI9RB2xKOWAdsgb,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ෩"),OHSsBNg2W8C4,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠹࠴᎐"))
				if CorYkXhAmuvNR9SDZTJz==rr7Xolsp4JwjPK3L(u"࠵࠵᎑"): break
				import diEohNHXbY
				if CorYkXhAmuvNR9SDZTJz>=dQ5JhEYolPmy1fvHktMw6NFRxiz and zziq3mcLD2GeBKQXYVyIF1t6Wv[CorYkXhAmuvNR9SDZTJz]==eCvsoQmbGgFIRp2y[fdQOo6Hu4B5Rbg]:
					diEohNHXbY.H9dPKlWAyZ3OSi4D1()
					if CorYkXhAmuvNR9SDZTJz>=dQ5JhEYolPmy1fvHktMw6NFRxiz: CorYkXhAmuvNR9SDZTJz = -wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠾᎒")
				elif CorYkXhAmuvNR9SDZTJz>=dQ5JhEYolPmy1fvHktMw6NFRxiz and zziq3mcLD2GeBKQXYVyIF1t6Wv[CorYkXhAmuvNR9SDZTJz]==eCvsoQmbGgFIRp2y[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]:
					diEohNHXbY.gKVfG6vwnYyOxlAH(kkMuQrLWcEayRm)
				if CorYkXhAmuvNR9SDZTJz==-fdQOo6Hu4B5Rbg: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ෪"),ipjCIhwEXsbadR+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧฯำ๋ะࠥิืฤࠩ෫")+zzGfwLAyN5HTxUoJeaivY+RVpeGcmPxj9tCnT40Nf216(u"ࠨ࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭෬"))
			INx86JyBXVuYc7nOUEj3H1 = fdQOo6Hu4B5Rbg
		else: INx86JyBXVuYc7nOUEj3H1 = dQ5JhEYolPmy1fvHktMw6NFRxiz
	amx9qJHkhw7oLdtVMG3.setSetting(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ෭"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,iAGgjwb7tVMmacRJ(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭෮"),qTVF3icWwGXy5(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ෯"),INx86JyBXVuYc7nOUEj3H1,UKDwMTZk9dni1JSLcf0oRXhqy)
	return
def GVDN5bHaP2CXs7h(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,G6XbgFWwaiq,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ):
	mI85v4YGehUSD6Jt2rkqsj = int(kFehKHZGBD7RvSYp%ssGdubC4mngM9D5SRc3Ye(u"࠷࠰᎓"))
	qivZbzYC2WgXVJmcTL = int(kFehKHZGBD7RvSYp/rxWDdRBIct57i90s(u"࠱࠱᎔"))
	IMD6EhOxAUndHjFc2 = C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3
	K4Kil0vYfNmxOHLUgwyC = amx9qJHkhw7oLdtVMG3.getSetting(EHUAyW2lQfe4LXmhgIGc(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ෰"))
	if not K4Kil0vYfNmxOHLUgwyC: amx9qJHkhw7oLdtVMG3.setSetting(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭෱"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡂࡗࡗࡓࠬෲ"))
	w0oqhWrypS1QlT5zX6UAnFIGfKOkc = amx9qJHkhw7oLdtVMG3.getSetting(iAGgjwb7tVMmacRJ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬෳ"))
	Oj5ehfpzir4o0kqCGwntHAugVQ = wilKJdNLRzVvboaHjkYBrU51(G6XbgFWwaiq)
	QvKyubHT62 = [dQ5JhEYolPmy1fvHktMw6NFRxiz,rxWDdRBIct57i90s(u"࠳࠸᎖"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠴࠻᎗"),dC3PsQJ0Ti28uYlov(u"࠵࠾᎘"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠳࠸᎕"),RVpeGcmPxj9tCnT40Nf216(u"࠳࠵᎛"),qTVF3icWwGXy5(u"࠺࠶᎙"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠻࠳᎚")]
	bIaSvYKMzshGjW2gHRDEdu = qivZbzYC2WgXVJmcTL not in QvKyubHT62
	JbiINRvfsTxj3wKYrQ = qivZbzYC2WgXVJmcTL in [t2sCrJ0xbgDRkf(u"࠶࠸᎟"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠳࠺᎜"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠺࠵᎞"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠹࠵᎝")]
	IPCpaUqELxtM5 = kFehKHZGBD7RvSYp in [EHUAyW2lQfe4LXmhgIGc(u"࠸࠶࠶Ꭱ"),ssGdubC4mngM9D5SRc3Ye(u"࠷࠽࠰Ꭰ")]
	arcqzwUNKFu9EH8m = (bIaSvYKMzshGjW2gHRDEdu or JbiINRvfsTxj3wKYrQ) and not IPCpaUqELxtM5
	yLmki3ZD6CfTzKEN8XWaVve = (w0oqhWrypS1QlT5zX6UAnFIGfKOkc or not CW2cwYfL9s) and w0oqhWrypS1QlT5zX6UAnFIGfKOkc not in [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ෴")]+I0WwEiyadX8qGtNAzc4
	jjmpn4yRfJ = ETNq5t4MYngSsbfFD8J0v(u"ࠪࡸࡾࡶࡥ࠾ࠩ෵") in w0oqhWrypS1QlT5zX6UAnFIGfKOkc
	OgoV3B0s7G = kFehKHZGBD7RvSYp in [dC3PsQJ0Ti28uYlov(u"࠴࠺࠶Ꭼ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠵࠻࠸Ꭽ"),rr7Xolsp4JwjPK3L(u"࠶࠼࠳Ꭾ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠷࠶࠵Ꭸ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠱࠷࠷Ꭹ"),rr7Xolsp4JwjPK3L(u"࠲࠸࠹Ꭺ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠳࠹࠻Ꭻ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠶࠼࠸Ꭷ"),DTF3Lwy9etRH8mI(u"࠹࠹࠵Ꭴ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠷࠷࠴Ꭲ"),t2sCrJ0xbgDRkf(u"࠸࠸࠶Ꭳ"),DTF3Lwy9etRH8mI(u"࠺࠺࠹Ꭵ"),rr7Xolsp4JwjPK3L(u"࠻࠻࠻Ꭶ")]
	b6WZDnA0dLBiCITrF37OS = mI85v4YGehUSD6Jt2rkqsj==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠿Ꭿ") or kFehKHZGBD7RvSYp in [ETNq5t4MYngSsbfFD8J0v(u"࠲࠶࠸Ꮁ"),bneABYmwFUH8GXphg0Kl2Sq(u"࠸࠵࠻Ꮃ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠷࠵࠷Ꮂ"),UighHKAfySm4PWErqJ(u"࠴࠶Ꮀ")]
	vdauRWzTwsBhDemy = not OgoV3B0s7G
	yvonKQkY97zxj = not b6WZDnA0dLBiCITrF37OS
	uCtGWhR9oNYqxMT7FDX4cZS1 = Oj5ehfpzir4o0kqCGwntHAugVQ in [G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠳࠴ࠧ෶")]
	c6RnLsDZq0umzF5QO = uCtGWhR9oNYqxMT7FDX4cZS1 or vdauRWzTwsBhDemy
	Cyl9J5DgH3O24ipZPWdXuGVzB7K0kb = uCtGWhR9oNYqxMT7FDX4cZS1 or yvonKQkY97zxj or jjmpn4yRfJ
	j0TYO81Z5Hop2s6InBA = kFehKHZGBD7RvSYp not in [Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠳࠸࠳Ꮈ"),rr7Xolsp4JwjPK3L(u"࠶࠻࠷Ꮄ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠴࠹࠹Ꮉ"),t2sCrJ0xbgDRkf(u"࠸࠷࠱Ꮆ"),iqHhJSxdaANDG5rlZm7B(u"࠸࠹࠰Ꮅ"),DTF3Lwy9etRH8mI(u"࠵࠵࠲Ꮇ"),iqHhJSxdaANDG5rlZm7B(u"࠴࠴࠶࠶Ꮊ")]
	if K4Kil0vYfNmxOHLUgwyC==cJSNFCIhymEfx6grGu0M(u"࡙ࠬࡔࡐࡒࠪ෷"): IJFHLurYtMQov9C1w6hbyZEf = b6WZDnA0dLBiCITrF37OS or OgoV3B0s7G
	else: IJFHLurYtMQov9C1w6hbyZEf = P5VqbRSzjtO4UE1rZaolG67XA
	Uspql0LfhEvPXStF3z1ewWQM8j6nG = qivZbzYC2WgXVJmcTL in [rr7Xolsp4JwjPK3L(u"࠽࠴Ꮍ"),FWqeEzO1i8Dn0ga(u"࠼࠻Ꮌ"),UighHKAfySm4PWErqJ(u"࠹࠹Ꮋ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠱࠱࠳Ꮎ")]
	jYU1x2pKg3Pd45IAhnzMGo = kFehKHZGBD7RvSYp in [dC3PsQJ0Ti28uYlov(u"࠳࠺࠳Ꮏ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠹࠵࠴Ꮐ")]
	tfvnWubExZwYN0Xms8HdkG4jPBJL = not Uspql0LfhEvPXStF3z1ewWQM8j6nG and not jYU1x2pKg3Pd45IAhnzMGo
	ES3bh2YZPcNK4yLRm = c6RnLsDZq0umzF5QO and Cyl9J5DgH3O24ipZPWdXuGVzB7K0kb and j0TYO81Z5Hop2s6InBA and IJFHLurYtMQov9C1w6hbyZEf and tfvnWubExZwYN0Xms8HdkG4jPBJL
	wj9gzyRLeT = j0TYO81Z5Hop2s6InBA and IJFHLurYtMQov9C1w6hbyZEf and tfvnWubExZwYN0Xms8HdkG4jPBJL
	qqxaed5XC68wcWZz4bnsjhOD = wj9gzyRLeT
	txP2Fq6BV1aLjgdGeTolwRzk = amx9qJHkhw7oLdtVMG3.getSetting(dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭෸"))
	MMqlhoRVbzJ = amx9qJHkhw7oLdtVMG3.getSetting(bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ෹"))
	rrBe3aq1HRTkQ2LOJzf9o4V = kkMuQrLWcEayRm
	if yLmki3ZD6CfTzKEN8XWaVve and ES3bh2YZPcNK4yLRm:
		mFjAToWnfvbrXypEtHPzdZ13 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࡮࡬ࡷࡹ࠭෺"),cJSNFCIhymEfx6grGu0M(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ෻")+txP2Fq6BV1aLjgdGeTolwRzk+dC3PsQJ0Ti28uYlov(u"ࠪࡣࠬ෼")+MMqlhoRVbzJ,IMD6EhOxAUndHjFc2)
		if mFjAToWnfvbrXypEtHPzdZ13:
			vvqQRbuChP(G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࠳ࡢࡴࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭෽")+txP2Fq6BV1aLjgdGeTolwRzk+rxWDdRBIct57i90s(u"ࠬࡥࠧ෾")+MMqlhoRVbzJ+UighHKAfySm4PWErqJ(u"࠭ࠠࠡࠢࡏࡳࡦࡪࡩ࡯ࡩࠣࡱࡪࡴࡵࠡࡨࡵࡳࡲࠦࡣࡢࡥ࡫ࡩࠬ෿"))
			if jjmpn4yRfJ:
				HUi8azwjfgqINMO0TuV = []
				from EsiXdlyHOk import X7YfLJuN5R
				from z9P53JUjpg import yEBVNehOAP8abZcHvLjzigr0s,E53xQykpKhNU61IqmbulZSJs7iLfc
				brdagoYiCc = X7YfLJuN5R
				j2aMSXxDf3Zvbr8P6n0U = yEBVNehOAP8abZcHvLjzigr0s()
				qmiuOdeNr2MjKJSPgQcUw8WoD7kpt = w0oqhWrypS1QlT5zX6UAnFIGfKOkc
				ts8AcoIB15SnbOhmwQgeDa,jpSihX27D0IRH8kG,eeVzsYl2MjuU4DxpkWrgBf5aA0,u2nfzYxBw3EiaR8mkc,f5EnKDg1yPaWXcZJbzAtLk,zlvQS2pFYWxygULmkEcwbPdB6DjeK,H4Mcba1U5jSnd9lxWfC6v,JiBtbO8VWN7gY3KFmwv0U6ylD,N8jJgCmXb2 = blF9qcJ4uon53mZIQpDT7j(qmiuOdeNr2MjKJSPgQcUw8WoD7kpt)
				xqBNvsAKXE7Vn9TPypZRHk2hOU6Ilt = ts8AcoIB15SnbOhmwQgeDa,jpSihX27D0IRH8kG,eeVzsYl2MjuU4DxpkWrgBf5aA0,u2nfzYxBw3EiaR8mkc,f5EnKDg1yPaWXcZJbzAtLk,zlvQS2pFYWxygULmkEcwbPdB6DjeK,H4Mcba1U5jSnd9lxWfC6v,G9G0YqivIfmUWO8K,N8jJgCmXb2
				for hamABQeONngJTkco4 in mFjAToWnfvbrXypEtHPzdZ13:
					Tvrd2gwGiDM1 = hamABQeONngJTkco4[t2sCrJ0xbgDRkf(u"ࠧ࡮ࡧࡱࡹࡎࡺࡥ࡮ࠩ฀")]
					if Tvrd2gwGiDM1==xqBNvsAKXE7Vn9TPypZRHk2hOU6Ilt or hamABQeONngJTkco4[ETNq5t4MYngSsbfFD8J0v(u"ࠨ࡯ࡲࡨࡪ࠭ก")] in [jR9YtmsgDX8nTQlMb6G3(u"࠶࠻࠻Ꮒ"),t2sCrJ0xbgDRkf(u"࠵࠻࠵Ꮑ")]:
						hamABQeONngJTkco4 = aqN9Yu8RfrTn(Tvrd2gwGiDM1,brdagoYiCc,j2aMSXxDf3Zvbr8P6n0U)
						if hamABQeONngJTkco4[cjbAkCIinvs(u"ࠩࡩࡥࡻࡵࡲࡪࡶࡨࡷࠬข")]:
							nLP0chliz8D3vWuqaIskx = E53xQykpKhNU61IqmbulZSJs7iLfc(j2aMSXxDf3Zvbr8P6n0U,Tvrd2gwGiDM1,hamABQeONngJTkco4[yiaeCEwJjOcWA4ZSd5h(u"ࠪࡲࡪࡽࡰࡢࡶ࡫ࠫฃ")])
							hamABQeONngJTkco4[cjbAkCIinvs(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪค")] = nLP0chliz8D3vWuqaIskx+hamABQeONngJTkco4[t2sCrJ0xbgDRkf(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫฅ")]
					HUi8azwjfgqINMO0TuV.append(hamABQeONngJTkco4)
				amx9qJHkhw7oLdtVMG3.setSetting(iqHhJSxdaANDG5rlZm7B(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪฆ"),G9G0YqivIfmUWO8K)
				if C9uTVdSkLlb5UemavyB6NjWHFh==DTF3Lwy9etRH8mI(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧง"): ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧจ")+txP2Fq6BV1aLjgdGeTolwRzk+yiaeCEwJjOcWA4ZSd5h(u"ࠩࡢࠫฉ")+MMqlhoRVbzJ,IMD6EhOxAUndHjFc2,HUi8azwjfgqINMO0TuV,TTm2opnt9fLX8DBYizbuSPvwhJZCl)
			else: HUi8azwjfgqINMO0TuV = mFjAToWnfvbrXypEtHPzdZ13
			if C9uTVdSkLlb5UemavyB6NjWHFh==qTVF3icWwGXy5(u"ࠪࡪࡴࡲࡤࡦࡴࠪช") and Oj5ehfpzir4o0kqCGwntHAugVQ!=hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࠳࠴ࠧซ") and arcqzwUNKFu9EH8m: PCxyizn0mbJW16cqVNIZBA()
			rrBe3aq1HRTkQ2LOJzf9o4V = S2Nr95pgUQbsVJE8RKImHG(IMD6EhOxAUndHjFc2,HUi8azwjfgqINMO0TuV,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ)
	elif C9uTVdSkLlb5UemavyB6NjWHFh==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฌ") and w0oqhWrypS1QlT5zX6UAnFIGfKOkc not in [hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ญ")]+I0WwEiyadX8qGtNAzc4 and wj9gzyRLeT:
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ฎ")+txP2Fq6BV1aLjgdGeTolwRzk+jR9YtmsgDX8nTQlMb6G3(u"ࠨࡡࠪฏ")+MMqlhoRVbzJ,IMD6EhOxAUndHjFc2)
	return rrBe3aq1HRTkQ2LOJzf9o4V,w0oqhWrypS1QlT5zX6UAnFIGfKOkc,IMD6EhOxAUndHjFc2,Oj5ehfpzir4o0kqCGwntHAugVQ,arcqzwUNKFu9EH8m,qqxaed5XC68wcWZz4bnsjhOD,txP2Fq6BV1aLjgdGeTolwRzk,MMqlhoRVbzJ
def KdinOgD3v2Wl4A6tUIL(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09):
	if t1w4Q95EfFKLMujJSbIRNZ in [vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩ࠴ࠫฐ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪ࠶ࠬฑ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࠸࠭ฒ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࠺ࠧณ"),UighHKAfySm4PWErqJ(u"࠭࠵ࠨด"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࠲࠳ࠪต"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࠳࠵ࠫถ"),UighHKAfySm4PWErqJ(u"ࠩ࠴࠷ࠬท")] and uIfFCQDdrm3wjoaO2ZVpYy09:
		import z9P53JUjpg
		z9P53JUjpg.hKY8iAO7a62IpoM(CW2cwYfL9s,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09)
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm,ccW1tVjJvUx5efKbPHu6yAMLqaF)
	elif t1w4Q95EfFKLMujJSbIRNZ==yiaeCEwJjOcWA4ZSd5h(u"ࠪ࠺ࠬธ"):
		import a1aDsx9ioY
		if uIfFCQDdrm3wjoaO2ZVpYy09==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭น"): a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬบ"),rr7Xolsp4JwjPK3L(u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭ป"),SSCU3jdyFn2V=CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠷࠶࠰࠱Ꮓ"))
		elif uIfFCQDdrm3wjoaO2ZVpYy09==vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡅࡇࡏࡉ࡙ࡋࠧผ"): c87cQjAhJxUVH9Key3EMSwWsXO(Qjnkp0KgXq2Ty,kkMuQrLWcEayRm)
		tRojAyBgfDH37eLCwP4dWl = a1aDsx9ioY.TadilgrWnheCzbZI4LHv1S7DVB(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,kFehKHZGBD7RvSYp,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
		if uIfFCQDdrm3wjoaO2ZVpYy09==dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪฝ"): NNetFngY7vowQPJp5xCumG2qrKcfk1()
	elif CW2cwYfL9s==yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠺ࠫพ"):
		import yJoXUw5pTK
		yJoXUw5pTK.vvWHIEqsdj1RZL(dC3PsQJ0Ti28uYlov(u"ࠪࡣࡆࡒࡌࠨฟ"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	elif CW2cwYfL9s==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࠽࠭ภ"): oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(iqHhJSxdaANDG5rlZm7B(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫม")+IJPabrdjXE7HGR163qY48pMVU5l+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭࠿࡮ࡱࡧࡩࡂ࠭ย")+str(bmP3CnZr75H984yd1k2Ng0EYLA)+ssGdubC4mngM9D5SRc3Ye(u"ࠧࠧࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷ࠯ࠧร"))
	elif CW2cwYfL9s==vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨ࠻ࠪฤ"):
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(P5VqbRSzjtO4UE1rZaolG67XA)
	elif CW2cwYfL9s==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ࠴࠴ࠬล"):
		import yJoXUw5pTK
		yJoXUw5pTK.vvWHIEqsdj1RZL(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡣࡌࡕࡏࡈࡎࡈࠫฦ"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	elif CW2cwYfL9s==rxWDdRBIct57i90s(u"ࠫ࠶࠺ࠧว"): Wz9Lj5vK4qeIBn1rTP20y78aogJ(P5VqbRSzjtO4UE1rZaolG67XA,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡓࡅࡏࡗࡢࡖࡊ࡜ࡅࡓࡕࡈࡈࡤ࡚ࡅࡎࡒࠪศ"))
	elif CW2cwYfL9s==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭࠱࠶ࠩษ"): Wz9Lj5vK4qeIBn1rTP20y78aogJ(P5VqbRSzjtO4UE1rZaolG67XA,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡎࡇࡑ࡙ࡤࡇࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬส"))
	elif CW2cwYfL9s==yiaeCEwJjOcWA4ZSd5h(u"ࠨ࠳࠹ࠫห"): Wz9Lj5vK4qeIBn1rTP20y78aogJ(P5VqbRSzjtO4UE1rZaolG67XA,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡘࡊࡓࡐࠨฬ"))
	elif CW2cwYfL9s==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪ࠵࠼࠭อ"): Wz9Lj5vK4qeIBn1rTP20y78aogJ(P5VqbRSzjtO4UE1rZaolG67XA,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡒࡋࡎࡖࡡࡕࡅࡓࡊࡏࡎࡋ࡝ࡉࡉࡥࡔࡆࡏࡓࠫฮ"))
	elif CW2cwYfL9s==EHUAyW2lQfe4LXmhgIGc(u"ࠬ࠷࠸ࠨฯ"):
		GFohMKWlxTBYdmSknLCUaw0qERt52 = amx9qJHkhw7oLdtVMG3.getSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪะ"))
		if GFohMKWlxTBYdmSknLCUaw0qERt52: amx9qJHkhw7oLdtVMG3.setSetting(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫั"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࠯ࠪา")+GFohMKWlxTBYdmSknLCUaw0qERt52)
	if CW2cwYfL9s in [CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࠼ࠫำ"),FWqeEzO1i8Dn0ga(u"ࠪ࠵࠹࠭ิ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࠶࠻ࠧี"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬ࠷࠶ࠨึ"),jR9YtmsgDX8nTQlMb6G3(u"࠭࠱࠸ࠩื")]: NNetFngY7vowQPJp5xCumG2qrKcfk1()
	return
def wcJnx5TaLO1bMg83y(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09,G6XbgFWwaiq):
	if jlFg5ptfLPEYns7mkOuyZG4z0WaqK: s4pFjloGN8whX6EZIcr1SbP7x()
	if CW2cwYfL9s: KdinOgD3v2Wl4A6tUIL(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09)
	CGgKTAJBluf8rYSPEUQ1kobN75O()
	vXAlKF2MkTnw0icVNIua1qR(P5VqbRSzjtO4UE1rZaolG67XA)
	pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ = P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm,kkMuQrLWcEayRm
	PPTnMVyxSOmtN3z6sjG = GVDN5bHaP2CXs7h(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,G6XbgFWwaiq,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ)
	rrBe3aq1HRTkQ2LOJzf9o4V,w0oqhWrypS1QlT5zX6UAnFIGfKOkc,IMD6EhOxAUndHjFc2,Oj5ehfpzir4o0kqCGwntHAugVQ,arcqzwUNKFu9EH8m,qqxaed5XC68wcWZz4bnsjhOD,txP2Fq6BV1aLjgdGeTolwRzk,MMqlhoRVbzJ = PPTnMVyxSOmtN3z6sjG
	if rrBe3aq1HRTkQ2LOJzf9o4V: return
	if w0oqhWrypS1QlT5zX6UAnFIGfKOkc==jR9YtmsgDX8nTQlMb6G3(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋุࠧ"): ewXaFc6410BDW8dgYAzVR(gWhZuzBnwiUVx5RoGFc6O7Hb)
	vlcUutakSyFDIi(EHUAyW2lQfe4LXmhgIGc(u"ࠨࡵࡷࡥࡷࡺูࠧ"))
	if amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨฺ")) not in [iqHhJSxdaANDG5rlZm7B(u"ࠪࡅ࡚࡚ࡏࠨ฻"),jR9YtmsgDX8nTQlMb6G3(u"ࠫࡘ࡚ࡏࡑࠩ฼"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭฽")]:
		amx9qJHkhw7oLdtVMG3.setSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ฾"),rr7Xolsp4JwjPK3L(u"ࠧࡂࡗࡗࡓࠬ฿"))
	if not amx9qJHkhw7oLdtVMG3.getSetting(cJSNFCIhymEfx6grGu0M(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨเ")): amx9qJHkhw7oLdtVMG3.setSetting(cjbAkCIinvs(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡪ࡮ࡴࠩแ"),vu5wBPhStlH2b7MR[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	tRojAyBgfDH37eLCwP4dWl = TadilgrWnheCzbZI4LHv1S7DVB(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
	if hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬโ") in xCVyDu98lp4NE3MR6A0: T5bfMDupFVnvX6cdikURs1 = P5VqbRSzjtO4UE1rZaolG67XA
	if C9uTVdSkLlb5UemavyB6NjWHFh==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫใ"):
		if Oj5ehfpzir4o0kqCGwntHAugVQ!=ssGdubC4mngM9D5SRc3Ye(u"ࠬ࠴࠮ࠨไ") and arcqzwUNKFu9EH8m: PCxyizn0mbJW16cqVNIZBA()
		if Q0ykDeVYNBOECG5WU>-fdQOo6Hu4B5Rbg:
			iLUYPK37hBE15F = [dQ5JhEYolPmy1fvHktMw6NFRxiz,iqHhJSxdaANDG5rlZm7B(u"࠱࠶Ꮕ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠲࠹Ꮖ"),rxWDdRBIct57i90s(u"࠳࠼Ꮗ"),t2sCrJ0xbgDRkf(u"࠸࠶Ꮔ"),qTVF3icWwGXy5(u"࠸࠺Ꮚ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸࠴Ꮘ"),jR9YtmsgDX8nTQlMb6G3(u"࠹࠸Ꮙ")]
			if (PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡩ࡯ࡶࠪๅ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪๆ"),rxWDdRBIct57i90s(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭็")) or kFehKHZGBD7RvSYp not in iLUYPK37hBE15F) and not iKLYEvx39c.t6Xn5IBwJPG0so47MEif:
				from EsiXdlyHOk import X7YfLJuN5R
				mFjAToWnfvbrXypEtHPzdZ13 = tylh1kHjNOod(X7YfLJuN5R)
				rrBe3aq1HRTkQ2LOJzf9o4V = S2Nr95pgUQbsVJE8RKImHG(IMD6EhOxAUndHjFc2,mFjAToWnfvbrXypEtHPzdZ13,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ)
				if mFjAToWnfvbrXypEtHPzdZ13 and qqxaed5XC68wcWZz4bnsjhOD:
					ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,ssGdubC4mngM9D5SRc3Ye(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ่")+txP2Fq6BV1aLjgdGeTolwRzk+dC3PsQJ0Ti28uYlov(u"ࠪࡣ้ࠬ")+MMqlhoRVbzJ,IMD6EhOxAUndHjFc2,mFjAToWnfvbrXypEtHPzdZ13,TTm2opnt9fLX8DBYizbuSPvwhJZCl)
			else:
				GWMro8TCBy2dNai.addDirectoryItem(Q0ykDeVYNBOECG5WU,qTVF3icWwGXy5(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵๊ࠧ")+IJPabrdjXE7HGR163qY48pMVU5l+FWqeEzO1i8Dn0ga(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴๋ࠬ"),tDG1bZwX86UPjWEoVOJ.ListItem(UighHKAfySm4PWErqJ(u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ์")))
				GWMro8TCBy2dNai.addDirectoryItem(Q0ykDeVYNBOECG5WU,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪํ")+IJPabrdjXE7HGR163qY48pMVU5l+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ๎"),tDG1bZwX86UPjWEoVOJ.ListItem(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ๏")))
			GWMro8TCBy2dNai.endOfDirectory(Q0ykDeVYNBOECG5WU,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ)
	return
def ewXaFc6410BDW8dgYAzVR(yQv0O7V49oz1MZIF8NenRc5bjX):
	if qTVF3icWwGXy5(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ๐") in IIHKo82wPrNpgqCkQJOV or EHUAyW2lQfe4LXmhgIGc(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩ๑") in IIHKo82wPrNpgqCkQJOV: return
	NNSl6mpIzqVWvgka7YPj53neL = kkMuQrLWcEayRm if yQv0O7V49oz1MZIF8NenRc5bjX else P5VqbRSzjtO4UE1rZaolG67XA
	if not NNSl6mpIzqVWvgka7YPj53neL:
		aHLkO8dT69NZVgx = o0Ez9jLOuAvaYgpGXrt4Ww8kQ(amx9qJHkhw7oLdtVMG3.getSetting(cjbAkCIinvs(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭๒")))
		aHLkO8dT69NZVgx = dQ5JhEYolPmy1fvHktMw6NFRxiz if not aHLkO8dT69NZVgx else int(aHLkO8dT69NZVgx)
		if not aHLkO8dT69NZVgx or not dQ5JhEYolPmy1fvHktMw6NFRxiz<=AVeHPW5shuXLdr2vwD-aHLkO8dT69NZVgx<=yQv0O7V49oz1MZIF8NenRc5bjX: NNSl6mpIzqVWvgka7YPj53neL = P5VqbRSzjtO4UE1rZaolG67XA
	if not NNSl6mpIzqVWvgka7YPj53neL:
		oo49PLQIlUO8tgaCN6kvqr2 = amx9qJHkhw7oLdtVMG3.getSetting(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ๓"))
		if oo49PLQIlUO8tgaCN6kvqr2 in [G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭๔"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧ๕")]: NNSl6mpIzqVWvgka7YPj53neL = P5VqbRSzjtO4UE1rZaolG67XA
	if not NNSl6mpIzqVWvgka7YPj53neL:
		I0QESDsRT3iZdu95GAoJlj = amx9qJHkhw7oLdtVMG3.getSetting(rxWDdRBIct57i90s(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ๖"))
		g3uJCH1iof5VtqyGNhQpwljdx = amx9qJHkhw7oLdtVMG3.getSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠷࠭๗"))
		k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(rr7Xolsp4JwjPK3L(u"࠻Ꮛ")*I0QESDsRT3iZdu95GAoJlj.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
		k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(iAGgjwb7tVMmacRJ(u"࠱࠵Ꮜ")*k1kV8SlEacW69.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
		k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠲࠻Ꮝ")*k1kV8SlEacW69.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
		if k1kV8SlEacW69!=g3uJCH1iof5VtqyGNhQpwljdx: NNSl6mpIzqVWvgka7YPj53neL = P5VqbRSzjtO4UE1rZaolG67XA
	if NNSl6mpIzqVWvgka7YPj53neL: YqSr2bj9TZxshFd(kkMuQrLWcEayRm)
	return
def TadilgrWnheCzbZI4LHv1S7DVB(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3):
	kFehKHZGBD7RvSYp = int(bmP3CnZr75H984yd1k2Ng0EYLA)
	qivZbzYC2WgXVJmcTL = int(kFehKHZGBD7RvSYp//UighHKAfySm4PWErqJ(u"࠳࠳Ꮞ"))
	if   qivZbzYC2WgXVJmcTL==dQ5JhEYolPmy1fvHktMw6NFRxiz:  from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==fdQOo6Hu4B5Rbg:  from VoNzeJ0yCT 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:  from nngBVuzXUo 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==c1R9fnIY4XBDZ:  from VpQ2IGhF6u 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==xsCEkXb6tgrh3195YZ:  from zPrdLEfHpX 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,eehFlSEjHioyAWpLqZXt79)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠸Ꮟ"):  from cUw0nzSrsP 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠺Ꮠ"):  from yGr4o5BFM0 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==FWqeEzO1i8Dn0ga(u"࠼Ꮡ"):  from xx1DRtjhcN 			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠾Ꮢ"):  from HIADrh8zPE 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹Ꮣ"):  from Ks6yfb3FEh		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠲࠲Ꮤ"): from miH2b7Cvj3 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠳࠴Ꮥ"): from CCOzBEyRvg 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iAGgjwb7tVMmacRJ(u"࠴࠶Ꮦ"): from SDoMIkl0yf 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RVpeGcmPxj9tCnT40Nf216(u"࠵࠸Ꮧ"): from wrjh9fNHVi		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==VHrIziKUDuNGXkMla(u"࠶࠺Ꮨ"): from HJQMP045Ze 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79,Tqd89eUHZ7l,Vy1U0koJLPFhxe2TS)
	elif qivZbzYC2WgXVJmcTL==vCmnFshSi4flecXIY2gy38G0DJw(u"࠷࠵Ꮩ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==cjbAkCIinvs(u"࠱࠷Ꮪ"): from OgoV3B0s7G		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠲࠹Ꮫ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠳࠻Ꮬ"): from RcBEyv9xmK		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rr7Xolsp4JwjPK3L(u"࠴࠽Ꮭ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==UighHKAfySm4PWErqJ(u"࠶࠵Ꮮ"): from VN1wd39pve		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rr7Xolsp4JwjPK3L(u"࠷࠷Ꮯ"): from tjyIDp0NTr	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠸࠲Ꮰ"): from ltRowQK6SW		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==bneABYmwFUH8GXphg0Kl2Sq(u"࠲࠴Ꮱ"): from QMzke4oxuJ			import PPFx0TCKwf; tRojAyBgfDH37eLCwP4dWl = PPFx0TCKwf(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠳࠶Ꮲ"): from NNHDVzYX8O 			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠴࠸Ꮳ"): from ghAocGITQE 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠵࠺Ꮴ"): from EsiXdlyHOk 			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ETNq5t4MYngSsbfFD8J0v(u"࠶࠼Ꮵ"): from z9P53JUjpg		import PPFx0TCKwf; tRojAyBgfDH37eLCwP4dWl = PPFx0TCKwf(kFehKHZGBD7RvSYp,CW2cwYfL9s)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠷࠾Ꮶ"): from QMzke4oxuJ			import PPFx0TCKwf; tRojAyBgfDH37eLCwP4dWl = PPFx0TCKwf(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==UighHKAfySm4PWErqJ(u"࠸࠹Ꮷ"): from zkVFcnjCRB	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠳࠱Ꮸ"): from ROz51TArF8		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ssGdubC4mngM9D5SRc3Ye(u"࠴࠳Ꮹ"): from rrRxdsjcvG		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠵࠵Ꮺ"): from i27RhJKYpk		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠶࠷Ꮻ"): from uQGjVohL2e		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo)
	elif qivZbzYC2WgXVJmcTL==FWqeEzO1i8Dn0ga(u"࠷࠹Ꮼ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠸࠻Ꮽ"): from Pq0s8YmBrW		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠹࠶Ꮾ"): from AD62PQ4gWj			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠳࠸Ꮿ"): from a4ms6ISnL5			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠴࠺Ᏸ"): from cYuti2ydov 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠵࠼Ᏹ"): from Nb2MYp7A8v		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠴Ᏺ"): from JaizWxwHY6	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79)
	elif qivZbzYC2WgXVJmcTL==cjbAkCIinvs(u"࠸࠶Ᏻ"): from JaizWxwHY6	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79)
	elif qivZbzYC2WgXVJmcTL==iAGgjwb7tVMmacRJ(u"࠹࠸Ᏼ"): from SGzMOepn4H			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠺࠳Ᏽ"): from xyz1QBauXg			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iAGgjwb7tVMmacRJ(u"࠴࠵᏶"): from KB2yzoTgjk		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==yiaeCEwJjOcWA4ZSd5h(u"࠵࠷᏷"): from TB34L5RJ8a		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==EHUAyW2lQfe4LXmhgIGc(u"࠶࠹ᏸ"): from MMS8IfhQvJ			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠷࠻ᏹ"): from G5oJd6lKs2		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠸࠽ᏺ"): from uhNyoqjf65		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==EHUAyW2lQfe4LXmhgIGc(u"࠹࠿ᏻ"): from XTjciq7QDv		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠻࠰ᏼ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠵࠲ᏽ"): from oIVtjGrleB 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==vCmnFshSi4flecXIY2gy38G0DJw(u"࠶࠴᏾"): from oIVtjGrleB 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠷࠶᏿"): from EsiXdlyHOk 			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸࠸᐀"): from yJoXUw5pTK	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,eehFlSEjHioyAWpLqZXt79)
	elif qivZbzYC2WgXVJmcTL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠹࠺ᐁ"): from cPoxDNVpRG 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==UighHKAfySm4PWErqJ(u"࠺࠼ᐂ"): from B3EeC061Fy		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠻࠷ᐃ"): from RnXoZzTYVh		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==cJSNFCIhymEfx6grGu0M(u"࠵࠹ᐄ"): from ePXAlKd1b3		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==dC3PsQJ0Ti28uYlov(u"࠶࠻ᐅ"): from JV7Os5T0jF		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸࠳ᐆ"): from yEG4fWLa5h			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==yiaeCEwJjOcWA4ZSd5h(u"࠹࠵ᐇ"): from kWKLl4pav2			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠺࠷ᐈ"): from WBrGOatN1y		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠻࠹ᐉ"): from e8e57S9N0W	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rr7Xolsp4JwjPK3L(u"࠼࠴ᐊ"): from YZx3WrXdtJ			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠶࠶ᐋ"): from m7cWXSE4NF			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷࠸ᐌ"): from TT5kAXZFOI			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ssGdubC4mngM9D5SRc3Ye(u"࠸࠺ᐍ"): from IoEYqguvP8		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rr7Xolsp4JwjPK3L(u"࠹࠼ᐎ"): from PGToIvZ1Em		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠺࠾ᐏ"): from HEAVlNCWB6		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠼࠶ᐐ"): from RYWbOd6qZF			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==bneABYmwFUH8GXphg0Kl2Sq(u"࠽࠱ᐑ"): from UUQbsdSjoM			import PPFx0TCKwf; tRojAyBgfDH37eLCwP4dWl = PPFx0TCKwf(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==RVpeGcmPxj9tCnT40Nf216(u"࠷࠳ᐒ"): from UUQbsdSjoM			import PPFx0TCKwf; tRojAyBgfDH37eLCwP4dWl = PPFx0TCKwf(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,C9uTVdSkLlb5UemavyB6NjWHFh,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠸࠵ᐓ"): from dPyzDFtHZ5	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ETNq5t4MYngSsbfFD8J0v(u"࠹࠷ᐔ"): from vI5esAfPRL		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠺࠹ᐕ"): from vI5esAfPRL		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp)
	elif qivZbzYC2WgXVJmcTL==dC3PsQJ0Ti28uYlov(u"࠻࠻ᐖ"): from OgoV3B0s7G		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0,eehFlSEjHioyAWpLqZXt79,zF4nhxYlaiKPwA6NJZ3)
	elif qivZbzYC2WgXVJmcTL==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠼࠽ᐗ"): from oJCMRaUesk 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠽࠸ᐘ"): from TKZwaIdUNA 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iAGgjwb7tVMmacRJ(u"࠷࠺ᐙ"): from NE6q2giP1A 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ssGdubC4mngM9D5SRc3Ye(u"࠹࠲ᐚ"): from pg8n1POVBx 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==VHrIziKUDuNGXkMla(u"࠺࠴ᐛ"): from GGdrq1FDwj 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==VHrIziKUDuNGXkMla(u"࠻࠶ᐜ"): from bJWPe8tmuq		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠼࠸ᐝ"): from uxNMiOoQnl		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠽࠺ᐞ"): from pmvfK280zt		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠾࠵ᐟ"): from DhAGCN2eQx		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==iqHhJSxdaANDG5rlZm7B(u"࠸࠷ᐠ"): from Rv4Vr8E9MU		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==bneABYmwFUH8GXphg0Kl2Sq(u"࠹࠹ᐡ"): from RbeOjlTzQI			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==jR9YtmsgDX8nTQlMb6G3(u"࠺࠻ᐢ"): from E97qINVYMl			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠻࠽ᐣ"): from nnK4UgS0XM		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==dC3PsQJ0Ti28uYlov(u"࠽࠵ᐤ"): from CvfLK2wysN	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==cjbAkCIinvs(u"࠾࠷ᐥ"): from bbEyuBvqA2		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==dC3PsQJ0Ti28uYlov(u"࠿࠲ᐦ"): from bKcFVQqJ9l		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠹࠴ᐧ"): from pfF9k7uaV2		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ETNq5t4MYngSsbfFD8J0v(u"࠺࠶ᐨ"): from tTDElSi9qn			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠻࠸ᐩ"): from XYdx0ZKPTL			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==UighHKAfySm4PWErqJ(u"࠼࠺ᐪ"): from PabNtdGAxg		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==jR9YtmsgDX8nTQlMb6G3(u"࠽࠼ᐫ"): from U0Q3WRXbZD		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==cJSNFCIhymEfx6grGu0M(u"࠾࠾ᐬ"): from Zzt9qkiBaH		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠿࠹ᐭ"): from bu6LkO3VUE		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠱࠱࠲ᐮ"): from cJDB5O9ZsN		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==rxWDdRBIct57i90s(u"࠲࠲࠴ᐯ"): from ghv9KjdWt1	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠳࠳࠶ᐰ"): from diEohNHXbY 		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠴࠴࠸ᐱ"): from Jjx3ro6wm9	import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==qTVF3icWwGXy5(u"࠵࠵࠺ᐲ"): from Uqu6CKd9Hp		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠶࠶࠵ᐳ"): from MvpUkBYmWn			import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==dC3PsQJ0Ti28uYlov(u"࠷࠰࠷ᐴ"): from p29dKyBG17		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	elif qivZbzYC2WgXVJmcTL==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠱࠱࠹ᐵ"): from MjKG5vkHoi		import RAndFk3y4Pbvs29	; tRojAyBgfDH37eLCwP4dWl = RAndFk3y4Pbvs29(kFehKHZGBD7RvSYp,yzieWRVX4nkB3DjGHJphEdQo,xCVyDu98lp4NE3MR6A0)
	else: tRojAyBgfDH37eLCwP4dWl = None
	return tRojAyBgfDH37eLCwP4dWl
def SAdYOJNgER8L(sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi,XdoFLQ20O6SNVlcp,showDialogs):
	oob2dzmG3jTMpZwQyIfN = XdoFLQ20O6SNVlcp.split(FWqeEzO1i8Dn0ga(u"ࠫ࠲࠭๘"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz] if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬ࠳ࠧ๙") in XdoFLQ20O6SNVlcp else XdoFLQ20O6SNVlcp
	if not showDialogs or XdoFLQ20O6SNVlcp in g3douDifIqHWVZ2AL9E6zScwR0OrG1: return kkMuQrLWcEayRm
	pxwYdJA4eTtiI25HXBQ9nKuV7l = amx9qJHkhw7oLdtVMG3.getSetting(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ๚"))
	amx9qJHkhw7oLdtVMG3.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ๛"),G9G0YqivIfmUWO8K)
	ZZD3SuERcfCw = sNWjYO26TqeSHihfx5aD8EUlon49 in [VHrIziKUDuNGXkMla(u"࠻ᐹ"),VHrIziKUDuNGXkMla(u"࠳࠴࠴࠵࠷ᐷ"),FWqeEzO1i8Dn0ga(u"࠲࠳࠳࠴࠷ᐶ"),cjbAkCIinvs(u"࠴࠴࠵࠻࠴ᐸ")]
	qEmic4znV1eadgKTsPORrW7A89C = DeRNxUpz3y8h05KCvgJEi.lower()
	xaIOuvGebL3AR1gzylX = sNWjYO26TqeSHihfx5aD8EUlon49 in [dQ5JhEYolPmy1fvHktMw6NFRxiz,bneABYmwFUH8GXphg0Kl2Sq(u"࠱࠱࠶ᐼ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠶࠶࠰࠷࠳ᐺ"),iqHhJSxdaANDG5rlZm7B(u"࠷࠱࠲ᐻ")]
	YDB6yi0JW28PgovM = cJSNFCIhymEfx6grGu0M(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ๜") in qEmic4znV1eadgKTsPORrW7A89C
	blWmV71kZgJS = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ๝") in qEmic4znV1eadgKTsPORrW7A89C
	F0F1o5mujBlxOWRqZcKayEsfdeN7 = rxWDdRBIct57i90s(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ๞") in qEmic4znV1eadgKTsPORrW7A89C
	CSlRpPib2YBtnAL0e = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭๟") in qEmic4znV1eadgKTsPORrW7A89C
	M5o1e2cPaA4NO9viqIFUt7x3RblLg0 = amx9qJHkhw7oLdtVMG3.getSetting(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ๠"))
	ct6DoMTHzUEbp4sv1BGWyxrw = amx9qJHkhw7oLdtVMG3.getSetting(bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ๡"))
	a0aVvkIHqzwQE = cjbAkCIinvs(u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ๢")
	CCkI64L0cm = bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡇࡵࡶࡴࡸࠠࠨ๣")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+t2sCrJ0xbgDRkf(u"ࠩ࠽ࠤࠬ๤")+DeRNxUpz3y8h05KCvgJEi
	CCkI64L0cm = aKAyEnjxIlzZtCTv(CCkI64L0cm)
	if xaIOuvGebL3AR1gzylX or YDB6yi0JW28PgovM or blWmV71kZgJS or F0F1o5mujBlxOWRqZcKayEsfdeN7 or CSlRpPib2YBtnAL0e: a0aVvkIHqzwQE += VHrIziKUDuNGXkMla(u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ๥")
	if ZZD3SuERcfCw: a0aVvkIHqzwQE += RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ๦")
	CCkI64L0cm = zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+CCkI64L0cm+zzGfwLAyN5HTxUoJeaivY
	if M5o1e2cPaA4NO9viqIFUt7x3RblLg0==jR9YtmsgDX8nTQlMb6G3(u"ࠬࡇࡓࡌࠩ๧") or ct6DoMTHzUEbp4sv1BGWyxrw==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡁࡔࡍࠪ๨"):
		a0aVvkIHqzwQE += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+ssGdubC4mngM9D5SRc3Ye(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩ๩")+zzGfwLAyN5HTxUoJeaivY
	qJNHBFAfi3SyvPGn1u6Ur2TM = kkMuQrLWcEayRm
	if M5o1e2cPaA4NO9viqIFUt7x3RblLg0==iAGgjwb7tVMmacRJ(u"ࠨࡃࡖࡏࠬ๪") or ct6DoMTHzUEbp4sv1BGWyxrw==DTF3Lwy9etRH8mI(u"ࠩࡄࡗࡐ࠭๫"):
		CorYkXhAmuvNR9SDZTJz = YZL469QjvSV(FWqeEzO1i8Dn0ga(u"ࠪࡧࡪࡴࡴࡦࡴࠪ๬"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫำื่อࠩ๭"),ETNq5t4MYngSsbfFD8J0v(u"ࠬหัิษ็ࠤ้๊ๅษำ่ะࠬ๮"),ssGdubC4mngM9D5SRc3Ye(u"࠭สึๆํัࠥอไๆึๆ่ฮ࠭๯"),oob2dzmG3jTMpZwQyIfN+wKBSo48e5PYtn63DpiG+GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN),a0aVvkIHqzwQE+zEgtT9cR6bFp7JXqI5VuhNeP+CCkI64L0cm)
		if CorYkXhAmuvNR9SDZTJz==fdQOo6Hu4B5Rbg:
			from diEohNHXbY import H9dPKlWAyZ3OSi4D1
			H9dPKlWAyZ3OSi4D1()
		elif CorYkXhAmuvNR9SDZTJz==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: qJNHBFAfi3SyvPGn1u6Ur2TM = P5VqbRSzjtO4UE1rZaolG67XA
	else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,oob2dzmG3jTMpZwQyIfN+wKBSo48e5PYtn63DpiG+GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN),a0aVvkIHqzwQE,CCkI64L0cm)
	amx9qJHkhw7oLdtVMG3.setSetting(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ๰"),pxwYdJA4eTtiI25HXBQ9nKuV7l)
	return qJNHBFAfi3SyvPGn1u6Ur2TM
def dfi8XnHqv2J3oxUSB5D7Rs1F6k(pqkui3rDLJ4Y2FzdHCv9xR=kkMuQrLWcEayRm,e914D2ZzYvWbcIXUKQqV53MtJ=[]):
	XXq3Ye4IHgZBGbDvtdKQy8maF = [iyNfWHemZaC1,Mh2XHLxaCsToiUFymceOGKS]+e914D2ZzYvWbcIXUKQqV53MtJ
	for zsZJaB5qojX42KcD in ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(ZwIThN17YKVQnbp52gX):
		if pqkui3rDLJ4Y2FzdHCv9xR and (zsZJaB5qojX42KcD.startswith(DTF3Lwy9etRH8mI(u"ࠨ࡫ࡳࡸࡻ࠭๱")) or zsZJaB5qojX42KcD.startswith(DTF3Lwy9etRH8mI(u"ࠩࡰ࠷ࡺ࠭๲"))): continue
		if zsZJaB5qojX42KcD.startswith(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡪ࡮ࡲࡥࡠࠩ๳")): continue
		AAVlqoQWIsRJr8dGaTKjiXhO = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,zsZJaB5qojX42KcD)
		if AAVlqoQWIsRJr8dGaTKjiXhO in XXq3Ye4IHgZBGbDvtdKQy8maF: continue
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(AAVlqoQWIsRJr8dGaTKjiXhO)
		except: pass
	if ffDhnivjmRXeuHSIa1qEZNA not in XXq3Ye4IHgZBGbDvtdKQy8maF: Sm8oLxifPQNzI(ffDhnivjmRXeuHSIa1qEZNA,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
	SSCU3jdyFn2V.sleep(vCmnFshSi4flecXIY2gy38G0DJw(u"࠲ᐽ"))
	return
def s7ZBoL2PGHQjFmb08tRqUxYONh(lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu=P5VqbRSzjtO4UE1rZaolG67XA,kUAmTPh7SuOxdLrCi9=P5VqbRSzjtO4UE1rZaolG67XA):
	yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo+rxWDdRBIct57i90s(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ๴")+lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu,kUAmTPh7SuOxdLrCi9)
	if yzieWRVX4nkB3DjGHJphEdQo in DD1ExCgnvNZhY7Acwpq6yeTSmz.content: DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded = kkMuQrLWcEayRm
	if not DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		NNetFngY7vowQPJp5xCumG2qrKcfk1()
	return DD1ExCgnvNZhY7Acwpq6yeTSmz
def HgFoXc156SNuTstRPrmnQwkBVL(yzieWRVX4nkB3DjGHJphEdQo):
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,EHUAyW2lQfe4LXmhgIGc(u"ࠬࡍࡅࡕࠩ๵"),yzieWRVX4nkB3DjGHJphEdQo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ๶"),P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
	CCetuPnIlqVDsz8OgMQWc5GSFy = []
	if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
		FfwMoPrQY5qKBp24 = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ๷"),RpnYai0qJ4G6mIw)
		if FfwMoPrQY5qKBp24: RpnYai0qJ4G6mIw = zEgtT9cR6bFp7JXqI5VuhNeP.join(FfwMoPrQY5qKBp24)
		qjlJQ3zUwAn9HBPGNucp7XyWDea = RpnYai0qJ4G6mIw.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).strip(zEgtT9cR6bFp7JXqI5VuhNeP).split(zEgtT9cR6bFp7JXqI5VuhNeP)
		CCetuPnIlqVDsz8OgMQWc5GSFy = []
		for lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3 in qjlJQ3zUwAn9HBPGNucp7XyWDea:
			if lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3.count(RVpeGcmPxj9tCnT40Nf216(u"ࠨ࠰ࠪ๸"))==c1R9fnIY4XBDZ: CCetuPnIlqVDsz8OgMQWc5GSFy.append(lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3)
	return CCetuPnIlqVDsz8OgMQWc5GSFy
def sxjogkuleZE54RTyhMvIfP9CD0dWK(*aargs):
	Q1MtfU4VZH = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ๹")
	JJ0H4Z6tTigk = bneABYmwFUH8GXphg0Kl2Sq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ๺")
	VVNGWC9sXh4cEqu1ev7JSyQRH6brLY = HgFoXc156SNuTstRPrmnQwkBVL(JJ0H4Z6tTigk)
	CCetuPnIlqVDsz8OgMQWc5GSFy = HgFoXc156SNuTstRPrmnQwkBVL(Q1MtfU4VZH)
	fwzOeLXcsrFSx8NREPnk2qIZy9oiVM = VVNGWC9sXh4cEqu1ev7JSyQRH6brLY+CCetuPnIlqVDsz8OgMQWc5GSFy
	vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+VHrIziKUDuNGXkMla(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ๻")+str(len(VVNGWC9sXh4cEqu1ev7JSyQRH6brLY))+cjbAkCIinvs(u"ࠬ࠱ࠧ๼")+str(len(CCetuPnIlqVDsz8OgMQWc5GSFy))+jR9YtmsgDX8nTQlMb6G3(u"࠭ࠠ࡞ࠩ๽"))
	lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3 = amx9qJHkhw7oLdtVMG3.getSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ๾"))
	DD1ExCgnvNZhY7Acwpq6yeTSmz = LGmh2jCPAgpY()
	amx9qJHkhw7oLdtVMG3.setSetting(iqHhJSxdaANDG5rlZm7B(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ๿"),G9G0YqivIfmUWO8K)
	if lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3 or fwzOeLXcsrFSx8NREPnk2qIZy9oiVM:
		ww5lQDRFdag8VnuXOTUMCbcp,Hvui6ETwrexpG9zcs5Cl = dQ5JhEYolPmy1fvHktMw6NFRxiz,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠳࠳ᐾ")
		Olvf3GYhCqiU2aTdASQjnX = len(fwzOeLXcsrFSx8NREPnk2qIZy9oiVM)
		olawFLyPM90e5qO3Rk8Tbrjx2zDvs1 = Hvui6ETwrexpG9zcs5Cl
		if Olvf3GYhCqiU2aTdASQjnX>olawFLyPM90e5qO3Rk8Tbrjx2zDvs1: OOBkR83KhbtI = olawFLyPM90e5qO3Rk8Tbrjx2zDvs1
		else: OOBkR83KhbtI = Olvf3GYhCqiU2aTdASQjnX
		z6rOaPwKYbSNukvenZ2 = voWS3GzbN5HXaTsiwLMeU.sample(fwzOeLXcsrFSx8NREPnk2qIZy9oiVM,OOBkR83KhbtI)
		if lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3: z6rOaPwKYbSNukvenZ2 = [lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3]+z6rOaPwKYbSNukvenZ2
		DvTq73b6zKdZnJlrcauxwpWY = QnzeRvFJ8G(kkMuQrLWcEayRm,kkMuQrLWcEayRm)
		ONEZrIFzqkX1no = SSCU3jdyFn2V.time()
		while SSCU3jdyFn2V.time()-ONEZrIFzqkX1no<=Hvui6ETwrexpG9zcs5Cl and not DvTq73b6zKdZnJlrcauxwpWY.finishedLIST:
			if ww5lQDRFdag8VnuXOTUMCbcp<OOBkR83KhbtI:
				lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3 = z6rOaPwKYbSNukvenZ2[ww5lQDRFdag8VnuXOTUMCbcp]
				DvTq73b6zKdZnJlrcauxwpWY.gVHbwiKWqxL(ww5lQDRFdag8VnuXOTUMCbcp,s7ZBoL2PGHQjFmb08tRqUxYONh,lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3,*aargs)
			SSCU3jdyFn2V.sleep(UighHKAfySm4PWErqJ(u"࠳࠲࠼࠻ᐿ"))
			ww5lQDRFdag8VnuXOTUMCbcp += fdQOo6Hu4B5Rbg
			vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ຀")+lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3+ETNq5t4MYngSsbfFD8J0v(u"ࠪࠤࡢ࠭ກ"))
		finishedLIST = DvTq73b6zKdZnJlrcauxwpWY.finishedLIST
		if finishedLIST:
			resultsDICT = DvTq73b6zKdZnJlrcauxwpWY.resultsDICT
			BCvzkj3yhI1gH9bPOQ = finishedLIST[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			DD1ExCgnvNZhY7Acwpq6yeTSmz = resultsDICT[BCvzkj3yhI1gH9bPOQ]
			lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3 = z6rOaPwKYbSNukvenZ2[int(BCvzkj3yhI1gH9bPOQ)]
			amx9qJHkhw7oLdtVMG3.setSetting(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫຂ"),lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3)
			if BCvzkj3yhI1gH9bPOQ!=dQ5JhEYolPmy1fvHktMw6NFRxiz: vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ຃")+lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3+RVpeGcmPxj9tCnT40Nf216(u"࠭ࠠ࡞ࠩຄ"))
			else: vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iqHhJSxdaANDG5rlZm7B(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ຅")+lXEVYvLjKzkD1nWbgw4ZaCOBo8T0U3+iAGgjwb7tVMmacRJ(u"ࠨࠢࡠࠫຆ"))
	return DD1ExCgnvNZhY7Acwpq6yeTSmz
def bbBxyV8WMeOaP7JA(UnB8CQVOjgsuz4,ALZsrP4M3TfRG9X1c7ENQKob):
	zzhj0OoCkpTePH7Zit8Ya = UnB8CQVOjgsuz4.create_connection
	def ZiDr6KMF3PQVmBJb(EgjlAszaSpJF8X,*aargs,**kkwargs):
		DDBtZjzny37,c6hqJUlZmCTpnB = EgjlAszaSpJF8X
		ip = JKneMTZDt6Vfp5a(DDBtZjzny37,ALZsrP4M3TfRG9X1c7ENQKob)
		if ip: DDBtZjzny37 = ip[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else:
			if ALZsrP4M3TfRG9X1c7ENQKob in vu5wBPhStlH2b7MR: vu5wBPhStlH2b7MR.remove(ALZsrP4M3TfRG9X1c7ENQKob)
			if vu5wBPhStlH2b7MR:
				pXNZSfyMTPY1dt4mUg = vu5wBPhStlH2b7MR[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				ip = JKneMTZDt6Vfp5a(DDBtZjzny37,pXNZSfyMTPY1dt4mUg)
				if ip: DDBtZjzny37 = ip[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		EgjlAszaSpJF8X = (DDBtZjzny37,c6hqJUlZmCTpnB)
		return zzhj0OoCkpTePH7Zit8Ya(EgjlAszaSpJF8X,*aargs,**kkwargs)
	UnB8CQVOjgsuz4.create_connection = ZiDr6KMF3PQVmBJb
	return zzhj0OoCkpTePH7Zit8Ya
def fRnxytWF5L(yzieWRVX4nkB3DjGHJphEdQo):
	Uy6pNmYuoS5qt02le1EBfcwC3kKQjR,E4q7r9vG1di = yzieWRVX4nkB3DjGHJphEdQo.split(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࠲ࠫງ"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU],ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠼࠵ᑀ")
	if cJSNFCIhymEfx6grGu0M(u"ࠪ࠾ࠬຈ") in Uy6pNmYuoS5qt02le1EBfcwC3kKQjR: Uy6pNmYuoS5qt02le1EBfcwC3kKQjR,E4q7r9vG1di = Uy6pNmYuoS5qt02le1EBfcwC3kKQjR.split(VHrIziKUDuNGXkMla(u"ࠫ࠿࠭ຉ"))
	xFVEGNJt2Hkhon5SfuId30ZiAa4l = DTF3Lwy9etRH8mI(u"ࠬ࠵ࠧຊ")+RVpeGcmPxj9tCnT40Nf216(u"࠭࠯ࠨ຋").join(yzieWRVX4nkB3DjGHJphEdQo.split(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠰ࠩຌ"))[iAGgjwb7tVMmacRJ(u"࠸ᑁ"):])
	A0AzrLupg8h1s = FWqeEzO1i8Dn0ga(u"ࠨࡉࡈࡘࠥ࠭ຍ")+xFVEGNJt2Hkhon5SfuId30ZiAa4l+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩຎ")
	A0AzrLupg8h1s += wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡌࡴࡹࡴ࠻ࠢࠪຏ")+Uy6pNmYuoS5qt02le1EBfcwC3kKQjR+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡡࡸ࡜࡯ࠩຐ")
	A0AzrLupg8h1s += GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡢࡲ࡝ࡰࠪຑ")
	from socket import socket as Uj57k9GZzYH3oh4inb,AF_INET as hN15RTFGmxM47slPe2EXdIwyZzWn,SOCK_STREAM as jj2MqvQzkZB6eSbGYml3WOUhFpKas
	try:
		wgKID4MNjhbkJ8qevcRGoVBLdSQ5 = Uj57k9GZzYH3oh4inb(hN15RTFGmxM47slPe2EXdIwyZzWn,jj2MqvQzkZB6eSbGYml3WOUhFpKas)
		wgKID4MNjhbkJ8qevcRGoVBLdSQ5.connect((Uy6pNmYuoS5qt02le1EBfcwC3kKQjR,E4q7r9vG1di))
		wgKID4MNjhbkJ8qevcRGoVBLdSQ5.send(A0AzrLupg8h1s.encode(f3uIcZ2C6pzbX1JlFBrVOdt))
		MtVb8HueWow5k2 = wgKID4MNjhbkJ8qevcRGoVBLdSQ5.recv(DTF3Lwy9etRH8mI(u"࠴࠱࠻࠹ᑃ")*CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠷࠰࠳࠶ᑂ"))
		RpnYai0qJ4G6mIw = repr(MtVb8HueWow5k2)
	except: RpnYai0qJ4G6mIw = G9G0YqivIfmUWO8K
	return RpnYai0qJ4G6mIw
def xWiOjcUrJVdtP4B5Iml(I2JutUeCgPyZoVL5Rvr9S,C9uTVdSkLlb5UemavyB6NjWHFh):
	if RVpeGcmPxj9tCnT40Nf216(u"࠭࠮ࠨຒ") not in I2JutUeCgPyZoVL5Rvr9S: return I2JutUeCgPyZoVL5Rvr9S
	I2JutUeCgPyZoVL5Rvr9S = I2JutUeCgPyZoVL5Rvr9S+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠰ࠩຓ")
	ccPyALDNh6gj4mieZlJoK3bB,kkd6hia7tF8pQxuRl9Bn = I2JutUeCgPyZoVL5Rvr9S.split(ETNq5t4MYngSsbfFD8J0v(u"ࠨ࠰ࠪດ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠲ᑄ"))
	vv1ywnhjNgX7P,JSy8QNjp4qdMbw3tFmOUo0ZArenYxv = kkd6hia7tF8pQxuRl9Bn.split(FWqeEzO1i8Dn0ga(u"ࠩ࠲ࠫຕ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠳ᑅ"))
	NjfyDTPiolAcsVQ4v2La = ccPyALDNh6gj4mieZlJoK3bB+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ࠲ࠬຖ")+vv1ywnhjNgX7P
	if C9uTVdSkLlb5UemavyB6NjWHFh in [GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࡭ࡵࡳࡵࠩທ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡴࡡ࡮ࡧࠪຘ")] and wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭࠯ࠨນ") in NjfyDTPiolAcsVQ4v2La: NjfyDTPiolAcsVQ4v2La = NjfyDTPiolAcsVQ4v2La.rsplit(RVpeGcmPxj9tCnT40Nf216(u"ࠧ࠰ࠩບ"),VHrIziKUDuNGXkMla(u"࠴ᑆ"))[fdQOo6Hu4B5Rbg]
	if C9uTVdSkLlb5UemavyB6NjWHFh==cjbAkCIinvs(u"ࠨࡰࡤࡱࡪ࠭ປ") and qTVF3icWwGXy5(u"ࠩ࠱ࠫຜ") in NjfyDTPiolAcsVQ4v2La:
		hcFtQJui5jI6eDv0XqadBpywPxGZH9 = NjfyDTPiolAcsVQ4v2La.split(iAGgjwb7tVMmacRJ(u"ࠪ࠲ࠬຝ"))
		xJvUrkfQoqeWCXw8Bzm1 = len(hcFtQJui5jI6eDv0XqadBpywPxGZH9)
		if t2sCrJ0xbgDRkf(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩພ") in NjfyDTPiolAcsVQ4v2La: hcFtQJui5jI6eDv0XqadBpywPxGZH9 = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪຟ")
		elif xJvUrkfQoqeWCXw8Bzm1<=SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: hcFtQJui5jI6eDv0XqadBpywPxGZH9 = hcFtQJui5jI6eDv0XqadBpywPxGZH9[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		elif xJvUrkfQoqeWCXw8Bzm1>=c1R9fnIY4XBDZ: hcFtQJui5jI6eDv0XqadBpywPxGZH9 = hcFtQJui5jI6eDv0XqadBpywPxGZH9[fdQOo6Hu4B5Rbg]
		if len(hcFtQJui5jI6eDv0XqadBpywPxGZH9)>fdQOo6Hu4B5Rbg: NjfyDTPiolAcsVQ4v2La = hcFtQJui5jI6eDv0XqadBpywPxGZH9
	return NjfyDTPiolAcsVQ4v2La
def X0Y7Axf35La9jPc1EiVIu(TcRVzxNtb9OLKevuy):
	IbD0BeWk2XUx5K4g = repr(TcRVzxNtb9OLKevuy.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).replace(rr7Xolsp4JwjPK3L(u"ࠨࠧࠣຠ"),G9G0YqivIfmUWO8K)
	return IbD0BeWk2XUx5K4g
def cpsXCrtE94DfY51mS(kbMgml05PD):
	evnS6Lqoj9RbKC = G9G0YqivIfmUWO8K
	if gA0m6CQUyfLG: kbMgml05PD = kbMgml05PD.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	from unicodedata import decomposition as n2MAiKLbuOv7wpGE
	for TjSUz14BXpPFrEodkRLGu9lbDaHe in kbMgml05PD:
		if   TjSUz14BXpPFrEodkRLGu9lbDaHe==ssGdubC4mngM9D5SRc3Ye(u"ࡵࠨฤࠪມ"): e5fq2C6wGy0Zml48OuX9QNFIJi = cjbAkCIinvs(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳ࠩຢ")
		elif TjSUz14BXpPFrEodkRLGu9lbDaHe==cJSNFCIhymEfx6grGu0M(u"ࡷࠪวࠬຣ"): e5fq2C6wGy0Zml48OuX9QNFIJi = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡠࡡࡻ࠰࠷࠴࠶ࠫ຤")
		elif TjSUz14BXpPFrEodkRLGu9lbDaHe==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࡹࠬสࠧລ"): e5fq2C6wGy0Zml48OuX9QNFIJi = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹࠭຦")
		elif TjSUz14BXpPFrEodkRLGu9lbDaHe==UighHKAfySm4PWErqJ(u"ࡻࠧฦࠩວ"): e5fq2C6wGy0Zml48OuX9QNFIJi = UighHKAfySm4PWErqJ(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨຨ")
		elif TjSUz14BXpPFrEodkRLGu9lbDaHe==bneABYmwFUH8GXphg0Kl2Sq(u"ࡶࠩษࠫຩ"): e5fq2C6wGy0Zml48OuX9QNFIJi = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ࠪສ")
		else:
			g18czfYpV92e = n2MAiKLbuOv7wpGE(TjSUz14BXpPFrEodkRLGu9lbDaHe)
			if ww0sZkBU9JKd in g18czfYpV92e: e5fq2C6wGy0Zml48OuX9QNFIJi = DTF3Lwy9etRH8mI(u"ࠪࡠࡡࡻࠧຫ")+g18czfYpV92e.split(ww0sZkBU9JKd,fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
			else:
				e5fq2C6wGy0Zml48OuX9QNFIJi = rxWDdRBIct57i90s(u"ࠫ࠵࠶࠰࠱ࠩຬ")+hex(ord(TjSUz14BXpPFrEodkRLGu9lbDaHe)).replace(UighHKAfySm4PWErqJ(u"ࠬ࠶ࡸࠨອ"),G9G0YqivIfmUWO8K)
				e5fq2C6wGy0Zml48OuX9QNFIJi = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࡜࡝ࡷࠪຮ")+e5fq2C6wGy0Zml48OuX9QNFIJi[-xsCEkXb6tgrh3195YZ:]
		evnS6Lqoj9RbKC += e5fq2C6wGy0Zml48OuX9QNFIJi
	evnS6Lqoj9RbKC = evnS6Lqoj9RbKC.replace(iAGgjwb7tVMmacRJ(u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨຯ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ࠩະ"))
	if gA0m6CQUyfLG: evnS6Lqoj9RbKC = evnS6Lqoj9RbKC.decode(rxWDdRBIct57i90s(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪັ")).encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	else: evnS6Lqoj9RbKC = evnS6Lqoj9RbKC.encode(f3uIcZ2C6pzbX1JlFBrVOdt).decode(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫາ"))
	return evnS6Lqoj9RbKC
def ZT7zGWSCtpvfmwMNRjYrKL(header=VHrIziKUDuNGXkMla(u"้ࠫ๎อสࠢส่๊็วห์ะࠫຳ"),ZZv9UABzh7FpuYmscyo8LEKj5XQgt=G9G0YqivIfmUWO8K,PVnpHZhKTgD29QMkL51dC3RAoiF=kkMuQrLWcEayRm,source=G9G0YqivIfmUWO8K):
	xCVyDu98lp4NE3MR6A0 = dtBNoiyZmP5RxTlDVaGsUcACnHL9(header,ZZv9UABzh7FpuYmscyo8LEKj5XQgt,type=tDG1bZwX86UPjWEoVOJ.INPUT_ALPHANUM)
	xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	if not xCVyDu98lp4NE3MR6A0 and not PVnpHZhKTgD29QMkL51dC3RAoiF:
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,t2sCrJ0xbgDRkf(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠾ࠥࠦࠠࠣࠩິ")+xCVyDu98lp4NE3MR6A0+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࠢࠨີ"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪຶ"),cJSNFCIhymEfx6grGu0M(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หฯฯษ็ࠫື"))
		return G9G0YqivIfmUWO8K
	if xCVyDu98lp4NE3MR6A0 not in [G9G0YqivIfmUWO8K,ww0sZkBU9JKd]:
		xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.strip(ww0sZkBU9JKd)
		xCVyDu98lp4NE3MR6A0 = cpsXCrtE94DfY51mS(xCVyDu98lp4NE3MR6A0)
	if source!=t2sCrJ0xbgDRkf(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖຸࠫ") and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(DTF3Lwy9etRH8mI(u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈູࠬ"),G9G0YqivIfmUWO8K,[xCVyDu98lp4NE3MR6A0],kkMuQrLWcEayRm):
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࠳ࡢࡴࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨ຺ࠧ")+xCVyDu98lp4NE3MR6A0+yiaeCEwJjOcWA4ZSd5h(u"ࠬࠨࠧົ"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩຼ"),DTF3Lwy9etRH8mI(u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩຽ"))
		return G9G0YqivIfmUWO8K
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ETNq5t4MYngSsbfFD8J0v(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫ຾")+xCVyDu98lp4NE3MR6A0+VHrIziKUDuNGXkMla(u"ࠩࠥࠫ຿"))
	return xCVyDu98lp4NE3MR6A0
def wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,XXzvmn7ewM8yBfoxua,AAFEPhnMlsH5B3z0gYQWD4j7kUc={}):
	yzieWRVX4nkB3DjGHJphEdQo,wXmKnlG2qMvUVCgyBNDxiWdbjH,FF0ORpe6IgNKcvuDo139yH,aPn2Gk9IhOgtp3mJNFAYyKw8ZD = XXzvmn7ewM8yBfoxua,{},{},G9G0YqivIfmUWO8K
	if bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࢀࠬເ") in XXzvmn7ewM8yBfoxua: yzieWRVX4nkB3DjGHJphEdQo,wXmKnlG2qMvUVCgyBNDxiWdbjH = uNeAyo6mgQTwGtDFhfcU5ZasI(XXzvmn7ewM8yBfoxua,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࢁ࠭ແ"))
	XWF06PbiLQNMzmR5ZAcCjB1U = list(set(list(AAFEPhnMlsH5B3z0gYQWD4j7kUc.keys())+list(wXmKnlG2qMvUVCgyBNDxiWdbjH.keys())))
	for sKzaZIMqmo in XWF06PbiLQNMzmR5ZAcCjB1U:
		if sKzaZIMqmo in list(wXmKnlG2qMvUVCgyBNDxiWdbjH.keys()): FF0ORpe6IgNKcvuDo139yH[sKzaZIMqmo] = wXmKnlG2qMvUVCgyBNDxiWdbjH[sKzaZIMqmo]
		else: FF0ORpe6IgNKcvuDo139yH[sKzaZIMqmo] = AAFEPhnMlsH5B3z0gYQWD4j7kUc[sKzaZIMqmo]
	if vCmnFshSi4flecXIY2gy38G0DJw(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩໂ") not in XWF06PbiLQNMzmR5ZAcCjB1U: FF0ORpe6IgNKcvuDo139yH[cjbAkCIinvs(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪໃ")] = uCUkPIYFszbV90wSpKqWNOjZ1687Eh()
	if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨໄ") not in XWF06PbiLQNMzmR5ZAcCjB1U: FF0ORpe6IgNKcvuDo139yH[rxWDdRBIct57i90s(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ໅")] = xWiOjcUrJVdtP4B5Iml(yzieWRVX4nkB3DjGHJphEdQo,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡸࡶࡱ࠭ໆ"))
	if EHUAyW2lQfe4LXmhgIGc(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬ໇") not in XWF06PbiLQNMzmR5ZAcCjB1U: FF0ORpe6IgNKcvuDo139yH[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ່࠭")] = iAGgjwb7tVMmacRJ(u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠾້࠭")
	for sKzaZIMqmo in list(FF0ORpe6IgNKcvuDo139yH.keys()): aPn2Gk9IhOgtp3mJNFAYyKw8ZD += yiaeCEwJjOcWA4ZSd5h(u"࠭ࠦࠨ໊")+sKzaZIMqmo+rxWDdRBIct57i90s(u"ࠧ࠾໋ࠩ")+FF0ORpe6IgNKcvuDo139yH[sKzaZIMqmo]
	if aPn2Gk9IhOgtp3mJNFAYyKw8ZD: aPn2Gk9IhOgtp3mJNFAYyKw8ZD = jR9YtmsgDX8nTQlMb6G3(u"ࠨࡾࠪ໌")+aPn2Gk9IhOgtp3mJNFAYyKw8ZD[fdQOo6Hu4B5Rbg:]
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(PvAZ1fCRqL5F,bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡊࡉ࡙࠭ໍ"),yzieWRVX4nkB3DjGHJphEdQo,G9G0YqivIfmUWO8K,FF0ORpe6IgNKcvuDo139yH,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ໎"),kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
	if bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨ໏") not in RpnYai0qJ4G6mIw: return [EHUAyW2lQfe4LXmhgIGc(u"ࠬ࠳࠱ࠨ໐")],[yzieWRVX4nkB3DjGHJphEdQo+aPn2Gk9IhOgtp3mJNFAYyKw8ZD]
	if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ໑") in RpnYai0qJ4G6mIw: return [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ࠮࠳ࠪ໒")],[yzieWRVX4nkB3DjGHJphEdQo+aPn2Gk9IhOgtp3mJNFAYyKw8ZD]
	if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ໓") in RpnYai0qJ4G6mIw: return [iqHhJSxdaANDG5rlZm7B(u"ࠩ࠰࠵ࠬ໔")],[yzieWRVX4nkB3DjGHJphEdQo+aPn2Gk9IhOgtp3mJNFAYyKw8ZD]
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,lldZ1jtIychxivq7YgkOQLRXp,BB9YonQhjLd = [],[],[],[]
	G5n4vArOfUz3CKS2o = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫ໕"),RpnYai0qJ4G6mIw+zEgtT9cR6bFp7JXqI5VuhNeP,oo9kuULlebNgpY0Om.DOTALL)
	if not G5n4vArOfUz3CKS2o: return [RVpeGcmPxj9tCnT40Nf216(u"ࠫ࠲࠷ࠧ໖")],[yzieWRVX4nkB3DjGHJphEdQo+aPn2Gk9IhOgtp3mJNFAYyKw8ZD]
	for k83jFdPwOph5,I2JutUeCgPyZoVL5Rvr9S in G5n4vArOfUz3CKS2o:
		MXHu5aeg1INz9to7BQcdipZk,GFohMKWlxTBYdmSknLCUaw0qERt52,I5chimw4D1okfxlBE2UpbuHJvStsZ = {},-UighHKAfySm4PWErqJ(u"࠵ᑇ"),-UighHKAfySm4PWErqJ(u"࠵ᑇ")
		aUGQzqn7moYDw = G9G0YqivIfmUWO8K
		XD3GbcWnEJhsT7arvk5K84q = k83jFdPwOph5.split(RVpeGcmPxj9tCnT40Nf216(u"ࠬ࠲ࠧ໗"))
		for xis68omJPAWO0gLN in XD3GbcWnEJhsT7arvk5K84q:
			if UighHKAfySm4PWErqJ(u"࠭࠽ࠨ໘") in xis68omJPAWO0gLN:
				sKzaZIMqmo,B4BDjGwmcPLfMysiFnHX = xis68omJPAWO0gLN.split(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧ࠾ࠩ໙"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠶ᑈ"))
				MXHu5aeg1INz9to7BQcdipZk[sKzaZIMqmo.lower()] = B4BDjGwmcPLfMysiFnHX
		if UighHKAfySm4PWErqJ(u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ໚") in k83jFdPwOph5.lower():
			GFohMKWlxTBYdmSknLCUaw0qERt52 = int(MXHu5aeg1INz9to7BQcdipZk[rr7Xolsp4JwjPK3L(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭໛")])//rr7Xolsp4JwjPK3L(u"࠷࠰࠳࠶ᑉ")
			aUGQzqn7moYDw += str(GFohMKWlxTBYdmSknLCUaw0qERt52)+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪໜ")
		elif wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧໝ") in k83jFdPwOph5.lower():
			GFohMKWlxTBYdmSknLCUaw0qERt52 = int(MXHu5aeg1INz9to7BQcdipZk[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨໞ")])//EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠱࠱࠴࠷ᑊ")
			aUGQzqn7moYDw += str(GFohMKWlxTBYdmSknLCUaw0qERt52)+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ໟ")
		if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱࠫ໠") in k83jFdPwOph5.lower():
			I5chimw4D1okfxlBE2UpbuHJvStsZ = int(MXHu5aeg1INz9to7BQcdipZk[dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ໡")].split(dC3PsQJ0Ti28uYlov(u"ࠩࡻࠫ໢"))[fdQOo6Hu4B5Rbg])
			aUGQzqn7moYDw += str(I5chimw4D1okfxlBE2UpbuHJvStsZ)+zVnkcBX6aJDPRpqyCjhoSZYQbL
		aUGQzqn7moYDw = aUGQzqn7moYDw.strip(zVnkcBX6aJDPRpqyCjhoSZYQbL)
		if not aUGQzqn7moYDw: aUGQzqn7moYDw = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ໣")
		if not I2JutUeCgPyZoVL5Rvr9S.startswith(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࡭ࡺࡴࡱࠩ໤")):
			if I2JutUeCgPyZoVL5Rvr9S.startswith(cJSNFCIhymEfx6grGu0M(u"ࠬ࠵࠯ࠨ໥")): I2JutUeCgPyZoVL5Rvr9S = yzieWRVX4nkB3DjGHJphEdQo.split(EHUAyW2lQfe4LXmhgIGc(u"࠭࠺ࠨ໦"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]+cjbAkCIinvs(u"ࠧ࠻ࠩ໧")+I2JutUeCgPyZoVL5Rvr9S
			elif I2JutUeCgPyZoVL5Rvr9S.startswith(iAGgjwb7tVMmacRJ(u"ࠨ࠱ࠪ໨")): I2JutUeCgPyZoVL5Rvr9S = xWiOjcUrJVdtP4B5Iml(yzieWRVX4nkB3DjGHJphEdQo,ssGdubC4mngM9D5SRc3Ye(u"ࠩࡸࡶࡱ࠭໩"))+I2JutUeCgPyZoVL5Rvr9S
			else: I2JutUeCgPyZoVL5Rvr9S = yzieWRVX4nkB3DjGHJphEdQo.rsplit(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࠳ࠬ໪"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]+yiaeCEwJjOcWA4ZSd5h(u"ࠫ࠴࠭໫")+I2JutUeCgPyZoVL5Rvr9S
		if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ໬") in list(MXHu5aeg1INz9to7BQcdipZk.keys()):
			z7GYBmKiXwreV2QybCNn80v9pT = MXHu5aeg1INz9to7BQcdipZk[ssGdubC4mngM9D5SRc3Ye(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ໭")]
			z7GYBmKiXwreV2QybCNn80v9pT = z7GYBmKiXwreV2QybCNn80v9pT.replace(rxWDdRBIct57i90s(u"ࠧࠣࠩ໮"),G9G0YqivIfmUWO8K).replace(iqHhJSxdaANDG5rlZm7B(u"ࠣࠩࠥ໯"),G9G0YqivIfmUWO8K).split(UighHKAfySm4PWErqJ(u"ࠩࠦࠫ໰"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			TJCK7aEsA0Dnl2FmQ = Ig4jFuXGfUQeCn6wlB8(z7GYBmKiXwreV2QybCNn80v9pT)
			if TJCK7aEsA0Dnl2FmQ: GS7Y93B0b8TLxueF = aUGQzqn7moYDw+zVnkcBX6aJDPRpqyCjhoSZYQbL+TJCK7aEsA0Dnl2FmQ
			else: GS7Y93B0b8TLxueF = aUGQzqn7moYDw
			GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF+FWqeEzO1i8Dn0ga(u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪ໱")
			GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF+zVnkcBX6aJDPRpqyCjhoSZYQbL+xWiOjcUrJVdtP4B5Iml(z7GYBmKiXwreV2QybCNn80v9pT,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡳࡧ࡭ࡦࠩ໲"))
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(GS7Y93B0b8TLxueF)
			ODnaR0N8UHv7Twy6jS.append(z7GYBmKiXwreV2QybCNn80v9pT)
			lldZ1jtIychxivq7YgkOQLRXp.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
			BB9YonQhjLd.append(GFohMKWlxTBYdmSknLCUaw0qERt52)
		I2JutUeCgPyZoVL5Rvr9S = I2JutUeCgPyZoVL5Rvr9S.split(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࠩࠧ໳"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		TJCK7aEsA0Dnl2FmQ = Ig4jFuXGfUQeCn6wlB8(I2JutUeCgPyZoVL5Rvr9S)
		if TJCK7aEsA0Dnl2FmQ: aUGQzqn7moYDw = aUGQzqn7moYDw+zVnkcBX6aJDPRpqyCjhoSZYQbL+TJCK7aEsA0Dnl2FmQ
		aUGQzqn7moYDw = aUGQzqn7moYDw+zVnkcBX6aJDPRpqyCjhoSZYQbL+xWiOjcUrJVdtP4B5Iml(I2JutUeCgPyZoVL5Rvr9S,DTF3Lwy9etRH8mI(u"࠭࡮ࡢ࡯ࡨࠫ໴"))
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(aUGQzqn7moYDw)
		ODnaR0N8UHv7Twy6jS.append(I2JutUeCgPyZoVL5Rvr9S)
		lldZ1jtIychxivq7YgkOQLRXp.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
		BB9YonQhjLd.append(GFohMKWlxTBYdmSknLCUaw0qERt52)
	iiMkLyedYA = list(zip(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,lldZ1jtIychxivq7YgkOQLRXp,BB9YonQhjLd))
	iiMkLyedYA = sorted(iiMkLyedYA, reverse=P5VqbRSzjtO4UE1rZaolG67XA, key=lambda key: key[c1R9fnIY4XBDZ])
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,lldZ1jtIychxivq7YgkOQLRXp,BB9YonQhjLd = list(zip(*iiMkLyedYA))
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = list(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO),list(ODnaR0N8UHv7Twy6jS)
	EEm7hgHpsjDO82aIQSNMf9yY6ZXrc = []
	for I2JutUeCgPyZoVL5Rvr9S in ODnaR0N8UHv7Twy6jS: EEm7hgHpsjDO82aIQSNMf9yY6ZXrc.append(I2JutUeCgPyZoVL5Rvr9S+aPn2Gk9IhOgtp3mJNFAYyKw8ZD)
	f91aHEqdGAPIT7nOyoNmvKMwF = list(zip(EEm7hgHpsjDO82aIQSNMf9yY6ZXrc,[ETNq5t4MYngSsbfFD8J0v(u"ࠧࡥࡷࡰࡱࡾ࠭໵")]*len(EEm7hgHpsjDO82aIQSNMf9yY6ZXrc),BB9YonQhjLd))
	rrCXLBihPDA = idRsI1pxWEXFaL(s5slfAmHkUtMR3WSKY1ZTX,f91aHEqdGAPIT7nOyoNmvKMwF)
	if rrCXLBihPDA:
		Y6YdkAMluFbwx,HHFwtdVPy2OZ,GFohMKWlxTBYdmSknLCUaw0qERt52 = rrCXLBihPDA[qTVF3icWwGXy5(u"࠱ᑋ")]
		index = EEm7hgHpsjDO82aIQSNMf9yY6ZXrc.index(Y6YdkAMluFbwx)
		title = Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[index]
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,EEm7hgHpsjDO82aIQSNMf9yY6ZXrc = [title],[Y6YdkAMluFbwx]
	return Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,EEm7hgHpsjDO82aIQSNMf9yY6ZXrc
def JKneMTZDt6Vfp5a(DDBtZjzny37,ALZsrP4M3TfRG9X1c7ENQKob=G9G0YqivIfmUWO8K):
	if not ALZsrP4M3TfRG9X1c7ENQKob: ALZsrP4M3TfRG9X1c7ENQKob = vu5wBPhStlH2b7MR[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if DDBtZjzny37.replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࠰ࠪ໶"),G9G0YqivIfmUWO8K).isdigit(): return [DDBtZjzny37]
	from struct import pack as C2Sbn0iWAaO9eF7,unpack_from as zNUJgLPMWrZjm
	from socket import socket as Uj57k9GZzYH3oh4inb,AF_INET as hN15RTFGmxM47slPe2EXdIwyZzWn,SOCK_DGRAM as ATkUgNwEbui3pmcYWOCj
	try:
		An1ZWlX8H0kpsJDPOd = C2Sbn0iWAaO9eF7(dC3PsQJ0Ti28uYlov(u"ࠤࡁࡌࠧ໷"), wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠳࠵࠴࠹࠿ᑌ"))
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(qTVF3icWwGXy5(u"ࠥࡂࡍࠨ໸"), t2sCrJ0xbgDRkf(u"࠵࠹࠻ᑍ"))
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(RVpeGcmPxj9tCnT40Nf216(u"ࠦࡃࡎࠢ໹"), fdQOo6Hu4B5Rbg)
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡄࡈࠣ໺"), dQ5JhEYolPmy1fvHktMw6NFRxiz)
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ࠾ࡉࠤ໻"), dQ5JhEYolPmy1fvHktMw6NFRxiz)
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠢ࠿ࡊࠥ໼"), dQ5JhEYolPmy1fvHktMw6NFRxiz)
		if LTze51miOknVcslNF43WSA6vMjYZt: gEuWSOMwjzTUZIsX2reFd16xAyLYf = DDBtZjzny37.split(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨ࠰ࠪ໽"))
		else: gEuWSOMwjzTUZIsX2reFd16xAyLYf = DDBtZjzny37.decode(f3uIcZ2C6pzbX1JlFBrVOdt).split(FWqeEzO1i8Dn0ga(u"ࠩ࠱ࠫ໾"))
		for w054jsNq8VIDt in gEuWSOMwjzTUZIsX2reFd16xAyLYf:
			dc7nfCvkNHVIE4jADpFWXSug6b3 = w054jsNq8VIDt.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(UighHKAfySm4PWErqJ(u"ࠥࡆࠧ໿"), len(w054jsNq8VIDt))
			for eP38qrvy9hKGjd in w054jsNq8VIDt:
				An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(dC3PsQJ0Ti28uYlov(u"ࠦࡨࠨༀ"), eP38qrvy9hKGjd.encode(f3uIcZ2C6pzbX1JlFBrVOdt))
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡈࠢ༁"), dQ5JhEYolPmy1fvHktMw6NFRxiz)
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ࠾ࡉࠤ༂"), fdQOo6Hu4B5Rbg)
		An1ZWlX8H0kpsJDPOd += C2Sbn0iWAaO9eF7(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠢ࠿ࡊࠥ༃"), fdQOo6Hu4B5Rbg)
		hs4MFckRBjAONKaw = Uj57k9GZzYH3oh4inb(hN15RTFGmxM47slPe2EXdIwyZzWn,ATkUgNwEbui3pmcYWOCj)
		hs4MFckRBjAONKaw.sendto(bytes(An1ZWlX8H0kpsJDPOd), (ALZsrP4M3TfRG9X1c7ENQKob, rxWDdRBIct57i90s(u"࠹࠸ᑎ")))
		hs4MFckRBjAONKaw.settimeout(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠻ᑏ"))
		snev3rg1V28C9pxGO6RNfIDBS0z, yszZ7D3luJ1acHq4j0bMBQe58C6Vr = hs4MFckRBjAONKaw.recvfrom(jR9YtmsgDX8nTQlMb6G3(u"࠷࠰࠳࠶ᑐ"))
		hs4MFckRBjAONKaw.close()
		ssCk5cbl8Y = zNUJgLPMWrZjm(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ༄"), snev3rg1V28C9pxGO6RNfIDBS0z, dQ5JhEYolPmy1fvHktMw6NFRxiz)
		rrqftCBzKeiZwVs3YSnPHc0a = ssCk5cbl8Y[c1R9fnIY4XBDZ]
		fflmpVtYSOAciKeo = len(DDBtZjzny37)+dC3PsQJ0Ti28uYlov(u"࠱࠹ᑑ")
		HgbMUjLOaP43Ts6W = []
		for _IfPMUNXaAKG4 in range(rrqftCBzKeiZwVs3YSnPHc0a):
			ooMz3nQutIr6i7UVkCdsY8 = fflmpVtYSOAciKeo
			TT5z0KpEcDVoSmyMdX = fdQOo6Hu4B5Rbg
			ZoTrC5OKQghP = kkMuQrLWcEayRm
			while P5VqbRSzjtO4UE1rZaolG67XA:
				eP38qrvy9hKGjd = zNUJgLPMWrZjm(EHUAyW2lQfe4LXmhgIGc(u"ࠤࡁࡆࠧ༅"), snev3rg1V28C9pxGO6RNfIDBS0z, ooMz3nQutIr6i7UVkCdsY8)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				if eP38qrvy9hKGjd == dQ5JhEYolPmy1fvHktMw6NFRxiz:
					ooMz3nQutIr6i7UVkCdsY8 += fdQOo6Hu4B5Rbg
					break
				if eP38qrvy9hKGjd >= GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠲࠻࠵ᑒ"):
					hwgA1jFoPpUEuBXDCQIWiZkd4e0t79 = zNUJgLPMWrZjm(cJSNFCIhymEfx6grGu0M(u"ࠥࡂࡇࠨ༆"), snev3rg1V28C9pxGO6RNfIDBS0z, ooMz3nQutIr6i7UVkCdsY8 + fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
					ooMz3nQutIr6i7UVkCdsY8 = ((eP38qrvy9hKGjd << RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠺ᑓ")) + hwgA1jFoPpUEuBXDCQIWiZkd4e0t79 - 0xc000) - fdQOo6Hu4B5Rbg
					ZoTrC5OKQghP = P5VqbRSzjtO4UE1rZaolG67XA
				ooMz3nQutIr6i7UVkCdsY8 += fdQOo6Hu4B5Rbg
				if ZoTrC5OKQghP == kkMuQrLWcEayRm: TT5z0KpEcDVoSmyMdX += fdQOo6Hu4B5Rbg
			if ZoTrC5OKQghP == P5VqbRSzjtO4UE1rZaolG67XA: TT5z0KpEcDVoSmyMdX += fdQOo6Hu4B5Rbg
			fflmpVtYSOAciKeo = fflmpVtYSOAciKeo + TT5z0KpEcDVoSmyMdX
			qqeTWlImrCMpsP3wA = zNUJgLPMWrZjm(DTF3Lwy9etRH8mI(u"ࠦࡃࡎࡈࡊࡊࠥ༇"), snev3rg1V28C9pxGO6RNfIDBS0z, fflmpVtYSOAciKeo)
			fflmpVtYSOAciKeo = fflmpVtYSOAciKeo + DTF3Lwy9etRH8mI(u"࠴࠴ᑔ")
			sJXFOl1LA3b6dQCr = qqeTWlImrCMpsP3wA[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			SBxKgJ1IGnoH = qqeTWlImrCMpsP3wA[c1R9fnIY4XBDZ]
			if sJXFOl1LA3b6dQCr == fdQOo6Hu4B5Rbg:
				CCkaDK0mxW6euY9XApUj37Qi2E = zNUJgLPMWrZjm(dC3PsQJ0Ti28uYlov(u"ࠧࡄࠢ༈")+ssGdubC4mngM9D5SRc3Ye(u"ࠨࡂࠣ༉")*SBxKgJ1IGnoH, snev3rg1V28C9pxGO6RNfIDBS0z, fflmpVtYSOAciKeo)
				ip = G9G0YqivIfmUWO8K
				for eP38qrvy9hKGjd in CCkaDK0mxW6euY9XApUj37Qi2E: ip += str(eP38qrvy9hKGjd) + ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧ࠯ࠩ༊")
				ip = ip[dQ5JhEYolPmy1fvHktMw6NFRxiz:-fdQOo6Hu4B5Rbg]
				HgbMUjLOaP43Ts6W.append(ip)
			if sJXFOl1LA3b6dQCr in [fdQOo6Hu4B5Rbg,SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU,UighHKAfySm4PWErqJ(u"࠻ᑗ"),qTVF3icWwGXy5(u"࠶ᑘ"),cjbAkCIinvs(u"࠶࠻ᑖ"),RVpeGcmPxj9tCnT40Nf216(u"࠶࠽ᑕ")]: fflmpVtYSOAciKeo = fflmpVtYSOAciKeo + SBxKgJ1IGnoH
	except: HgbMUjLOaP43Ts6W = []
	if not HgbMUjLOaP43Ts6W: vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧ་")+DDBtZjzny37+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࠣࡡࠬ༌"))
	return HgbMUjLOaP43Ts6W
def j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,yzieWRVX4nkB3DjGHJphEdQo,UUKJu0BWM9x4vQ7j6HLDaISyieTd,showDialogs=P5VqbRSzjtO4UE1rZaolG67XA):
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd:
		uuyApQ8hxKMoC2d4XbvwV9JqNIjW0z = [t2sCrJ0xbgDRkf(u"ࠪ็ออัࠨ།"),ssGdubC4mngM9D5SRc3Ye(u"ࠫออไ฻ࠩ༎"),qTVF3icWwGXy5(u"ࠬࡧࡤࡶ࡮ࡷࠫ༏"),ETNq5t4MYngSsbfFD8J0v(u"࠭ࡸࡹࠩ༐"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡴࡧࡻࠫ༑")]
		if s5slfAmHkUtMR3WSKY1ZTX!=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡄࡒࡏࡗࡇࠧ༒"):
			uuyApQ8hxKMoC2d4XbvwV9JqNIjW0z += [qTVF3icWwGXy5(u"ࠩࡵ࠾ࠬ༓"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡶ࠲࠭༔"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࠲ࡳࡡࠨ༕")]
			uuyApQ8hxKMoC2d4XbvwV9JqNIjW0z += [RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡀࡲࠨ༖"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࠭ࡳࠩ༗"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࡮ࡣ࠰༘ࠫ")]
		for tj9RfNKmAs8Ui3Q0wcuBbPY in UUKJu0BWM9x4vQ7j6HLDaISyieTd:
			if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁ༙ࠪ") in tj9RfNKmAs8Ui3Q0wcuBbPY: continue
			if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩะ่็ฯࠧ༚") in tj9RfNKmAs8Ui3Q0wcuBbPY: continue
			tj9RfNKmAs8Ui3Q0wcuBbPY = tj9RfNKmAs8Ui3Q0wcuBbPY.lower()
			if gA0m6CQUyfLG: tj9RfNKmAs8Ui3Q0wcuBbPY = tj9RfNKmAs8Ui3Q0wcuBbPY.decode(f3uIcZ2C6pzbX1JlFBrVOdt).encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			tj9RfNKmAs8Ui3Q0wcuBbPY = tj9RfNKmAs8Ui3Q0wcuBbPY.replace(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪ࠾ࠬ༛"),G9G0YqivIfmUWO8K)
			GF9MvoImi1AZ0Kaj = oo9kuULlebNgpY0Om.findall(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ༜"),tj9RfNKmAs8Ui3Q0wcuBbPY,oo9kuULlebNgpY0Om.DOTALL)
			PGyRXD7J4p6VufMCgntQ9Ajb1o = kkMuQrLWcEayRm
			for j1jXFNZOpf47yU in GF9MvoImi1AZ0Kaj:
				if len(j1jXFNZOpf47yU)==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:
					PGyRXD7J4p6VufMCgntQ9Ajb1o = P5VqbRSzjtO4UE1rZaolG67XA
					break
			if UighHKAfySm4PWErqJ(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ༝") in tj9RfNKmAs8Ui3Q0wcuBbPY: continue
			elif qTVF3icWwGXy5(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ༞") in tj9RfNKmAs8Ui3Q0wcuBbPY: continue
			elif hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧ฻์ิࠤ๊฻ๆโࠩ༟") in tj9RfNKmAs8Ui3Q0wcuBbPY: continue
			elif kWUE5INdVuX9wSOFsnZ([wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ༠")])[dQ5JhEYolPmy1fvHktMw6NFRxiz]: continue
			elif tj9RfNKmAs8Ui3Q0wcuBbPY in [ssGdubC4mngM9D5SRc3Ye(u"ࠩࡵࠫ༡")] or PGyRXD7J4p6VufMCgntQ9Ajb1o or any(yW70dtahIjkPCJg2TA in tj9RfNKmAs8Ui3Q0wcuBbPY for yW70dtahIjkPCJg2TA in uuyApQ8hxKMoC2d4XbvwV9JqNIjW0z):
				vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+ssGdubC4mngM9D5SRc3Ye(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ༢")+yzieWRVX4nkB3DjGHJphEdQo+UighHKAfySm4PWErqJ(u"ࠫࠥࡣࠧ༣"))
				if showDialogs: XXeZuvhknsKYqB17gwm6dfc(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༤"),iAGgjwb7tVMmacRJ(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ༥"))
				return P5VqbRSzjtO4UE1rZaolG67XA
	return kkMuQrLWcEayRm
def hbKFzulmsw4k(*aargs,**kkwargs):
	if aargs:
		direction = aargs[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		zNhFDfBUQcjOProqaH5bwxMS36WEe = aargs[fdQOo6Hu4B5Rbg]
		if not direction: direction = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡤࡧࡱࡸࡪࡸࠧ༦")
		if not zNhFDfBUQcjOProqaH5bwxMS36WEe: zNhFDfBUQcjOProqaH5bwxMS36WEe = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨษึฮ๊ืวาࠩ༧")
		O3mkKnrawgDfLhI2 = aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		xCVyDu98lp4NE3MR6A0 = zEgtT9cR6bFp7JXqI5VuhNeP.join(aargs[dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠴ᑙ"):])
	else: direction,zNhFDfBUQcjOProqaH5bwxMS36WEe,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0 = G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠩࡒࡏࠬ༨"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	YZL469QjvSV(direction,G9G0YqivIfmUWO8K,zNhFDfBUQcjOProqaH5bwxMS36WEe,G9G0YqivIfmUWO8K,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,**kkwargs)
	return
def xNVJH71kmLUIy3CjS9TDBQoYu5(*aargs,**kkwargs):
	direction = aargs[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	ccQ2M05C7VSbDTnsFxepyaE6ov = aargs[fdQOo6Hu4B5Rbg]
	SFw9lJcTOpaZ78h3QHEmWr = aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
	if SFw9lJcTOpaZ78h3QHEmWr or ccQ2M05C7VSbDTnsFxepyaE6ov: WvnCs0z3f6kdpPYQGSxNZgVlu81 = P5VqbRSzjtO4UE1rZaolG67XA
	else: WvnCs0z3f6kdpPYQGSxNZgVlu81 = kkMuQrLWcEayRm
	O3mkKnrawgDfLhI2 = aargs[c1R9fnIY4XBDZ]
	xCVyDu98lp4NE3MR6A0 = aargs[xsCEkXb6tgrh3195YZ]
	if not direction: direction = cJSNFCIhymEfx6grGu0M(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༩")
	if not ccQ2M05C7VSbDTnsFxepyaE6ov: ccQ2M05C7VSbDTnsFxepyaE6ov = rxWDdRBIct57i90s(u"่๊ࠫวࠡࠢࡑࡳࠬ༪")
	if not SFw9lJcTOpaZ78h3QHEmWr: SFw9lJcTOpaZ78h3QHEmWr = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ༫")
	if len(aargs)>=Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠹ᑛ"): xCVyDu98lp4NE3MR6A0 += zEgtT9cR6bFp7JXqI5VuhNeP+aargs[RVpeGcmPxj9tCnT40Nf216(u"࠷ᑚ")]
	if len(aargs)>=bneABYmwFUH8GXphg0Kl2Sq(u"࠻ᑜ"): xCVyDu98lp4NE3MR6A0 += zEgtT9cR6bFp7JXqI5VuhNeP+aargs[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠻ᑝ")]
	CorYkXhAmuvNR9SDZTJz = YZL469QjvSV(direction,ccQ2M05C7VSbDTnsFxepyaE6ov,G9G0YqivIfmUWO8K,SFw9lJcTOpaZ78h3QHEmWr,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,**kkwargs)
	if CorYkXhAmuvNR9SDZTJz==-cJSNFCIhymEfx6grGu0M(u"࠷ᑞ") and WvnCs0z3f6kdpPYQGSxNZgVlu81: CorYkXhAmuvNR9SDZTJz = -fdQOo6Hu4B5Rbg
	elif CorYkXhAmuvNR9SDZTJz==-fdQOo6Hu4B5Rbg and not WvnCs0z3f6kdpPYQGSxNZgVlu81: CorYkXhAmuvNR9SDZTJz = kkMuQrLWcEayRm
	elif CorYkXhAmuvNR9SDZTJz==dQ5JhEYolPmy1fvHktMw6NFRxiz: CorYkXhAmuvNR9SDZTJz = kkMuQrLWcEayRm
	elif CorYkXhAmuvNR9SDZTJz==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: CorYkXhAmuvNR9SDZTJz = P5VqbRSzjtO4UE1rZaolG67XA
	return CorYkXhAmuvNR9SDZTJz
def wjrY1si9L6(*aargs,**kkwargs):
	return tDG1bZwX86UPjWEoVOJ.Dialog().select(*aargs,**kkwargs)
def XXeZuvhknsKYqB17gwm6dfc(*aargs,**kkwargs):
	O3mkKnrawgDfLhI2 = aargs[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	xCVyDu98lp4NE3MR6A0 = aargs[fdQOo6Hu4B5Rbg]
	C0JmdWy6jHNkpgQeuhXI8vla = kkwargs[hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡴࡪ࡯ࡨࠫ༬")] if yiaeCEwJjOcWA4ZSd5h(u"ࠧࡵ࡫ࡰࡩࠬ༭") in list(kkwargs.keys()) else GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠱࠱࠲࠳ᑟ")
	TewQs5GNkzvXbVAZRc43xK = aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU] if len(aargs)>SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU and dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡶ࡬ࡱࡪ࠭༮") not in aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU] else hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ༯")
	QQtXwjfvhARJ = fu19TY0PdM6AZB5.Thread(target=RR1Ih2f5aqVXDzb6vcMnF8,args=(O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,TewQs5GNkzvXbVAZRc43xK,C0JmdWy6jHNkpgQeuhXI8vla))
	QQtXwjfvhARJ.start()
	return
def RR1Ih2f5aqVXDzb6vcMnF8(O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,TewQs5GNkzvXbVAZRc43xK,C0JmdWy6jHNkpgQeuhXI8vla):
	wN3TWLtc2v9yPGlbSIJXpUa5DdBAV = TewQs5GNkzvXbVAZRc43xK.replace(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࠪ༰"),G9G0YqivIfmUWO8K)
	name = AyU7CaxXKirHj6kISTMR0d1mgZlJ4s(P5VqbRSzjtO4UE1rZaolG67XA,wN3TWLtc2v9yPGlbSIJXpUa5DdBAV+RVpeGcmPxj9tCnT40Nf216(u"ࠫࠥ࠳ࠠࠨ༱")+O3mkKnrawgDfLhI2+FWqeEzO1i8Dn0ga(u"ࠬࠦ࠭ࠡࠩ༲")+xCVyDu98lp4NE3MR6A0)
	name = jHk81i3RbxZ(name)
	image_filename = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(pBVU0FrKY7soCucdwbTmjPOzyiGh,name+RVpeGcmPxj9tCnT40Nf216(u"࠭࠮ࡱࡰࡪࠫ༳"))
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(image_filename):
		if TewQs5GNkzvXbVAZRc43xK==rr7Xolsp4JwjPK3L(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡲࡦࡩࡸࡰࡦࡸࠧ༴"): image_height = dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠲࠳࠺ᑠ")
		elif TewQs5GNkzvXbVAZRc43xK==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳ༵ࠬ"): image_height = EHUAyW2lQfe4LXmhgIGc(u"࠴࠴࠴ᑡ")
	else: image_height = cvGgZknSKbf6lU7pwt8Y(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,TewQs5GNkzvXbVAZRc43xK,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ࡯ࡩ࡫ࡺࠧ༶"),kkMuQrLWcEayRm,image_filename)
	oyNTx5pdWm1jO8sJuAX = EbOZKPeXIg(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮༷ࠪ"),ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ༸"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࠽࠲࠱ࡲ༹ࠪ"))
	oyNTx5pdWm1jO8sJuAX.show()
	if TewQs5GNkzvXbVAZRc43xK==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡧࡵࡵࡱࠪ༺"):
		oyNTx5pdWm1jO8sJuAX.getControl(yiaeCEwJjOcWA4ZSd5h(u"࠽࠵࠺࠰ᑣ")).setHeight(UighHKAfySm4PWErqJ(u"࠵࠵࠺ᑢ"))
		oyNTx5pdWm1jO8sJuAX.getControl(RVpeGcmPxj9tCnT40Nf216(u"࠹࠱࠶࠳ᑦ")).setPosition(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠺࠻ᑤ"),-Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠾࠰ᑥ"))
		oyNTx5pdWm1jO8sJuAX.getControl(rxWDdRBIct57i90s(u"࠺࠲࠸࠴ᑧ")).setPosition(ETNq5t4MYngSsbfFD8J0v(u"࠳࠵࠴ᑨ"),-ssGdubC4mngM9D5SRc3Ye(u"࠹࠴ᑩ"))
		oyNTx5pdWm1jO8sJuAX.getControl(t2sCrJ0xbgDRkf(u"࠺࠰࠱ᑬ")).setPosition(t2sCrJ0xbgDRkf(u"࠽࠵ᑪ"),-iAGgjwb7tVMmacRJ(u"࠸࠻ᑫ"))
	oyNTx5pdWm1jO8sJuAX.getControl(RVpeGcmPxj9tCnT40Nf216(u"࠴࠱࠳ᑭ")).setVisible(kkMuQrLWcEayRm)
	oyNTx5pdWm1jO8sJuAX.getControl(UighHKAfySm4PWErqJ(u"࠵࠲࠵ᑮ")).setVisible(kkMuQrLWcEayRm)
	oyNTx5pdWm1jO8sJuAX.getControl(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠻࠳࠹࠵ᑯ")).setImage(image_filename)
	oyNTx5pdWm1jO8sJuAX.getControl(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠼࠴࠺࠶ᑰ")).setHeight(image_height)
	SSCU3jdyFn2V.sleep(C0JmdWy6jHNkpgQeuhXI8vla//wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠵࠵࠶࠰࠯࠲ᑱ"))
	return
def FGHjRISMPqDg(*aargs,**kkwargs):
	O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,profile,direction = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ༻"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ࡮ࡨࡪࡹ࠭༼")
	if len(aargs)>=fdQOo6Hu4B5Rbg: O3mkKnrawgDfLhI2 = aargs[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if len(aargs)>=SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: xCVyDu98lp4NE3MR6A0 = aargs[fdQOo6Hu4B5Rbg]
	if len(aargs)>=c1R9fnIY4XBDZ: profile = aargs[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
	if len(aargs)>=xsCEkXb6tgrh3195YZ: direction = aargs[c1R9fnIY4XBDZ]
	return tg6EQSH7P4(direction,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,profile)
def Ld0qx6IJ4kEtpXv9KieZ(*aargs,**kkwargs):
	return tDG1bZwX86UPjWEoVOJ.Dialog().contextmenu(*aargs,**kkwargs)
def SulWg06IykM7CxDF9OnZt(*aargs,**kkwargs):
	return tDG1bZwX86UPjWEoVOJ.Dialog().browseSingle(*aargs,**kkwargs)
def dtBNoiyZmP5RxTlDVaGsUcACnHL9(*aargs,**kkwargs):
	return tDG1bZwX86UPjWEoVOJ.Dialog().input(*aargs,**kkwargs)
def dWO9bFPCYXVDrcU81xN5kJ23laR(*aargs,**kkwargs):
	return tDG1bZwX86UPjWEoVOJ.DialogProgress(*aargs,**kkwargs)
def YZL469QjvSV(direction,button0=G9G0YqivIfmUWO8K,button1=G9G0YqivIfmUWO8K,button2=G9G0YqivIfmUWO8K,O3mkKnrawgDfLhI2=G9G0YqivIfmUWO8K,xCVyDu98lp4NE3MR6A0=G9G0YqivIfmUWO8K,profile=rr7Xolsp4JwjPK3L(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ༽"),eZTR19k2PxEB4=dQ5JhEYolPmy1fvHktMw6NFRxiz,kLxTYWAE4o8PbhSuwg3eF=dQ5JhEYolPmy1fvHktMw6NFRxiz):
	if not direction: direction = VHrIziKUDuNGXkMla(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༾")
	oyNTx5pdWm1jO8sJuAX = GDCMAfqb8LjRVu(RVpeGcmPxj9tCnT40Nf216(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭༿"),ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,t2sCrJ0xbgDRkf(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ཀ"),rxWDdRBIct57i90s(u"࠭࠷࠳࠲ࡳࠫཁ"))
	oyNTx5pdWm1jO8sJuAX.S3yQOFb0NB2CifckvL84XZMmpuT(button0,button1,button2,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,profile,direction,eZTR19k2PxEB4,kLxTYWAE4o8PbhSuwg3eF)
	if eZTR19k2PxEB4>dQ5JhEYolPmy1fvHktMw6NFRxiz: oyNTx5pdWm1jO8sJuAX.OA4TgriyIlYZBQ7EqU()
	if kLxTYWAE4o8PbhSuwg3eF>dQ5JhEYolPmy1fvHktMw6NFRxiz: oyNTx5pdWm1jO8sJuAX.jWbzRYhZaSHpi8Jg6LGVcP0MOC1ND()
	if eZTR19k2PxEB4==dQ5JhEYolPmy1fvHktMw6NFRxiz and kLxTYWAE4o8PbhSuwg3eF==dQ5JhEYolPmy1fvHktMw6NFRxiz: oyNTx5pdWm1jO8sJuAX.uD32VbpYG40qaLWlSm9AQIMh6owsCn()
	oyNTx5pdWm1jO8sJuAX.doModal()
	CorYkXhAmuvNR9SDZTJz = oyNTx5pdWm1jO8sJuAX.choiceID
	return CorYkXhAmuvNR9SDZTJz
def tg6EQSH7P4(direction,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,profile=RVpeGcmPxj9tCnT40Nf216(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨག")):
	if not direction: direction = cJSNFCIhymEfx6grGu0M(u"ࠨ࡮ࡨࡪࡹ࠭གྷ")
	oyNTx5pdWm1jO8sJuAX = EbOZKPeXIg(UighHKAfySm4PWErqJ(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬང"),ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫཅ"),ssGdubC4mngM9D5SRc3Ye(u"ࠫ࠼࠸࠰ࡱࠩཆ"))
	image_filename = F0xXYapD5dS4HBM.replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬཇ"),RVpeGcmPxj9tCnT40Nf216(u"࠭࡟ࠨ཈")+str(SSCU3jdyFn2V.time())+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡠࠩཉ"))
	image_filename = image_filename.replace(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨ࡞࡟ࠫཊ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩ࡟ࡠࡡࡢࠧཋ")).replace(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪ࠳࠴࠭ཌ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࠴࠵࠯࠰ࠩཌྷ"))
	image_height = cvGgZknSKbf6lU7pwt8Y(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,O3mkKnrawgDfLhI2,xCVyDu98lp4NE3MR6A0,profile,direction,kkMuQrLWcEayRm,image_filename)
	oyNTx5pdWm1jO8sJuAX.show()
	oyNTx5pdWm1jO8sJuAX.getControl(qTVF3icWwGXy5(u"࠾࠶࠵࠱ᑲ")).setHeight(image_height)
	oyNTx5pdWm1jO8sJuAX.getControl(cJSNFCIhymEfx6grGu0M(u"࠿࠰࠶࠲ᑳ")).setImage(image_filename)
	rD3NAm1sywq4Bn7Yv98F2eizXlc = oyNTx5pdWm1jO8sJuAX.doModal()
	try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(image_filename)
	except: pass
	return rD3NAm1sywq4Bn7Yv98F2eizXlc
def uCUkPIYFszbV90wSpKqWNOjZ1687Eh(eft61KWaJcDlU24=P5VqbRSzjtO4UE1rZaolG67XA):
	if eft61KWaJcDlU24:
		TkUSmDLJYy = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,VHrIziKUDuNGXkMla(u"ࠬࡹࡴࡳࠩཎ"),UighHKAfySm4PWErqJ(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩཏ"),UighHKAfySm4PWErqJ(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪཐ"))
		if TkUSmDLJYy: return TkUSmDLJYy
	xCVyDu98lp4NE3MR6A0 = G9G0YqivIfmUWO8K
	if dQ5JhEYolPmy1fvHktMw6NFRxiz and DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
		d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6 = RpnYai0qJ4G6mIw.count(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢࠩད"))
		if d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6>iqHhJSxdaANDG5rlZm7B(u"࠸࠱ᑴ"):
			xCVyDu98lp4NE3MR6A0 = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠩࡪࡩࡹ࠳ࡴࡩࡧ࠰ࡰ࡮ࡹࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫདྷ"),RpnYai0qJ4G6mIw,oo9kuULlebNgpY0Om.DOTALL)
			xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if not xCVyDu98lp4NE3MR6A0:
		aMKW1bw6XN = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,qTVF3icWwGXy5(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩན"),rr7Xolsp4JwjPK3L(u"ࠫࡺࡹࡥࡳࡣࡪࡩࡳࡺࡳ࠯ࡶࡻࡸࠬཔ"))
		xCVyDu98lp4NE3MR6A0 = open(aMKW1bw6XN,t2sCrJ0xbgDRkf(u"ࠬࡸࡢࠨཕ")).read()
		if LTze51miOknVcslNF43WSA6vMjYZt: xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
	neNpd8F2D4f = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧབ"),xCVyDu98lp4NE3MR6A0,oo9kuULlebNgpY0Om.DOTALL)
	Jr4Vyx03LZkugBvAFSpT1CNhec = []
	for k83jFdPwOph5 in neNpd8F2D4f:
		S9rmvaqc7V1gb53Cw = k83jFdPwOph5.lower()
		if dC3PsQJ0Ti28uYlov(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨབྷ") in S9rmvaqc7V1gb53Cw: continue
		if t2sCrJ0xbgDRkf(u"ࠨࡷࡥࡹࡳࡺࡵࠨམ") in S9rmvaqc7V1gb53Cw: continue
		if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩཙ") in S9rmvaqc7V1gb53Cw: continue
		if iqHhJSxdaANDG5rlZm7B(u"ࠪࡧࡷࡵࡳࠨཚ") in S9rmvaqc7V1gb53Cw: continue
		Jr4Vyx03LZkugBvAFSpT1CNhec.append(k83jFdPwOph5)
	TkUSmDLJYy = voWS3GzbN5HXaTsiwLMeU.sample(Jr4Vyx03LZkugBvAFSpT1CNhec,fdQOo6Hu4B5Rbg)
	TkUSmDLJYy = TkUSmDLJYy[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧཛ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨཛྷ"),TkUSmDLJYy,TTm2opnt9fLX8DBYizbuSPvwhJZCl)
	return TkUSmDLJYy
def XDk4GnqsF2KNRptPwfg0cBJebZ(fEKoHajMCOh=G9G0YqivIfmUWO8K):
	if not fEKoHajMCOh: fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
	if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡓࡺࡵࡷࡩࡲࡋࡸࡪࡶࠪཝ") in fEKoHajMCOh or DTF3Lwy9etRH8mI(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪཞ") in fEKoHajMCOh: return
	if fEKoHajMCOh!=vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫཟ"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
	G5n4vArOfUz3CKS2o = fEKoHajMCOh.splitlines()
	pNmWTskohjIPSt7fQl = G5n4vArOfUz3CKS2o[-cjbAkCIinvs(u"࠲ᑵ")]
	lywerV98qTnsoEj4XpdZY0UkP6CS = open(UcSsAurHXqJwR70DT1i,rxWDdRBIct57i90s(u"ࠩࡵࡦࠬའ")).read()
	if LTze51miOknVcslNF43WSA6vMjYZt: lywerV98qTnsoEj4XpdZY0UkP6CS = lywerV98qTnsoEj4XpdZY0UkP6CS.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	lywerV98qTnsoEj4XpdZY0UkP6CS = lywerV98qTnsoEj4XpdZY0UkP6CS[-t2sCrJ0xbgDRkf(u"࠺࠳࠴࠵ᑶ"):]
	KKuAjNF7ZWUGOw0abglrVTM2znxh3 = jR9YtmsgDX8nTQlMb6G3(u"ࠪࡁࠬཡ")*qTVF3icWwGXy5(u"࠴࠴࠵ᑷ")
	if KKuAjNF7ZWUGOw0abglrVTM2znxh3 in lywerV98qTnsoEj4XpdZY0UkP6CS: lywerV98qTnsoEj4XpdZY0UkP6CS = lywerV98qTnsoEj4XpdZY0UkP6CS.rsplit(KKuAjNF7ZWUGOw0abglrVTM2znxh3,fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
	if pNmWTskohjIPSt7fQl in lywerV98qTnsoEj4XpdZY0UkP6CS: lywerV98qTnsoEj4XpdZY0UkP6CS = lywerV98qTnsoEj4XpdZY0UkP6CS.rsplit(pNmWTskohjIPSt7fQl,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	L7hUToPpbQRdO9Ca6lG5kF = oo9kuULlebNgpY0Om.findall(qTVF3icWwGXy5(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪར"),lywerV98qTnsoEj4XpdZY0UkP6CS,oo9kuULlebNgpY0Om.DOTALL)
	for zL96TiGHI0ZNEfDr2A8aFd,XdoFLQ20O6SNVlcp in reversed(L7hUToPpbQRdO9Ca6lG5kF):
		if XdoFLQ20O6SNVlcp: break
	else: XdoFLQ20O6SNVlcp = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬལ")
	u4uT6Mx7CnDAWspy2jIh,k83jFdPwOph5,Xg92etbKYaHnfm38j = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	ddRp6rLc0Sv4uGeOFIqYt = dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡛࠭ࡓࡖࡏࡡࠬཤ")+ipjCIhwEXsbadR+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧศๆั฻ศࡀࠠࠡࠩཥ")+zzGfwLAyN5HTxUoJeaivY+pNmWTskohjIPSt7fQl
	LYwAUpercInVkKPtHGM87fSZs = cjbAkCIinvs(u"ࠨ࡝ࡕࡘࡑࡣࠧས")+ipjCIhwEXsbadR+cJSNFCIhymEfx6grGu0M(u"ࠩส่๊฻ฯา࠼ࠣࠤࠬཧ")+zzGfwLAyN5HTxUoJeaivY+XdoFLQ20O6SNVlcp
	for g1HRG3B6aUNwLfm in reversed(G5n4vArOfUz3CKS2o):
		if iqHhJSxdaANDG5rlZm7B(u"ࠪࡊ࡮ࡲࡥࠡࠤࠪཨ") in g1HRG3B6aUNwLfm and wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪཀྵ") in g1HRG3B6aUNwLfm: break
	g1HRG3B6aUNwLfm = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨཪ"),g1HRG3B6aUNwLfm,oo9kuULlebNgpY0Om.DOTALL)
	if g1HRG3B6aUNwLfm:
		u4uT6Mx7CnDAWspy2jIh,k83jFdPwOph5,Xg92etbKYaHnfm38j = g1HRG3B6aUNwLfm[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if FWqeEzO1i8Dn0ga(u"࠭࠯ࠨཫ") in u4uT6Mx7CnDAWspy2jIh: u4uT6Mx7CnDAWspy2jIh = u4uT6Mx7CnDAWspy2jIh.rsplit(DTF3Lwy9etRH8mI(u"ࠧ࠰ࠩཬ"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
		else: u4uT6Mx7CnDAWspy2jIh = u4uT6Mx7CnDAWspy2jIh.rsplit(cJSNFCIhymEfx6grGu0M(u"ࠨ࡞࡟ࠫ཭"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
		rgKt8idDRy1X = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ཮")+ipjCIhwEXsbadR+bneABYmwFUH8GXphg0Kl2Sq(u"ࠪห้๋ไโ࠼ࠣࠤࠬ཯")+zzGfwLAyN5HTxUoJeaivY+u4uT6Mx7CnDAWspy2jIh
		zUvtISW0fdVcsN8YDaCE5quQp7XlFH = cJSNFCIhymEfx6grGu0M(u"ࠫࡠࡘࡔࡍ࡟ࠪ཰")+ipjCIhwEXsbadR+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬอไิูิ࠾ཱࠥࠦࠧ")+zzGfwLAyN5HTxUoJeaivY+k83jFdPwOph5
		ojZApgXdREYFs = EHUAyW2lQfe4LXmhgIGc(u"࡛࠭ࡓࡖࡏࡡིࠬ")+ipjCIhwEXsbadR+bneABYmwFUH8GXphg0Kl2Sq(u"ࠧศๆ่็ฬ์࠺ཱིࠡࠢࠪ")+zzGfwLAyN5HTxUoJeaivY+Xg92etbKYaHnfm38j
		dgYLTviRAGwEFV15 = rgKt8idDRy1X+zEgtT9cR6bFp7JXqI5VuhNeP+zUvtISW0fdVcsN8YDaCE5quQp7XlFH+zEgtT9cR6bFp7JXqI5VuhNeP+ojZApgXdREYFs+zEgtT9cR6bFp7JXqI5VuhNeP+LYwAUpercInVkKPtHGM87fSZs+zEgtT9cR6bFp7JXqI5VuhNeP+ddRp6rLc0Sv4uGeOFIqYt
		llRJfWygdDtYzu03CFkKNpLhE89IX = zUvtISW0fdVcsN8YDaCE5quQp7XlFH+zEgtT9cR6bFp7JXqI5VuhNeP+LYwAUpercInVkKPtHGM87fSZs+zEgtT9cR6bFp7JXqI5VuhNeP+ddRp6rLc0Sv4uGeOFIqYt+zEgtT9cR6bFp7JXqI5VuhNeP+rgKt8idDRy1X+zEgtT9cR6bFp7JXqI5VuhNeP+ojZApgXdREYFs
		NNkTygWcJUAhLMS = zUvtISW0fdVcsN8YDaCE5quQp7XlFH+zEgtT9cR6bFp7JXqI5VuhNeP+ddRp6rLc0Sv4uGeOFIqYt+zEgtT9cR6bFp7JXqI5VuhNeP+rgKt8idDRy1X+zEgtT9cR6bFp7JXqI5VuhNeP+ojZApgXdREYFs
	else:
		rgKt8idDRy1X,zUvtISW0fdVcsN8YDaCE5quQp7XlFH,ojZApgXdREYFs = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		dgYLTviRAGwEFV15 = LYwAUpercInVkKPtHGM87fSZs+VHrIziKUDuNGXkMla(u"ࠨ࡞ࡱࡠࡳུ࠭")+ddRp6rLc0Sv4uGeOFIqYt
		llRJfWygdDtYzu03CFkKNpLhE89IX = LYwAUpercInVkKPtHGM87fSZs+ssGdubC4mngM9D5SRc3Ye(u"ࠩ࡟ࡲࡡࡴཱུࠧ")+ddRp6rLc0Sv4uGeOFIqYt
		NNkTygWcJUAhLMS = ddRp6rLc0Sv4uGeOFIqYt
	PPaLcMud2Em = bneABYmwFUH8GXphg0Kl2Sq(u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧྲྀ")+zEgtT9cR6bFp7JXqI5VuhNeP
	yhzDrESJuqnvtAI27iWF4xUeKpskR0 = oEJ0MXzZcUlR8wCi6h7G()
	ffBMvxOeKorN2tkm = []
	tRojAyBgfDH37eLCwP4dWl = yhzDrESJuqnvtAI27iWF4xUeKpskR0[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩཷ")]
	PgJk5tpj9Hin32mT = hwmEHOpWo24TygucdVUM(GBx0Fcf7sLbqlntEX3yMezu)
	if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪླྀ") in list(yhzDrESJuqnvtAI27iWF4xUeKpskR0.keys()):
		for CfRkqdn4IDNir,zIehbpiLVQXSmujy,PDHihRjYzAwISxn7cdF1mVrTvKot0 in tRojAyBgfDH37eLCwP4dWl:
			ffBMvxOeKorN2tkm = max(ffBMvxOeKorN2tkm,zIehbpiLVQXSmujy)
		if PgJk5tpj9Hin32mT<ffBMvxOeKorN2tkm:
			O3mkKnrawgDfLhI2 = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩཹ")
			CorYkXhAmuvNR9SDZTJz = YZL469QjvSV(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡳ࡫ࡪ࡬ࡹེ࠭"),qTVF3icWwGXy5(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะཻࠬ"),RVpeGcmPxj9tCnT40Nf216(u"ࠩอัิ๐หࠨོ"),cjbAkCIinvs(u"ࠪาึ๎ฬࠨཽ"),PPaLcMud2Em+O3mkKnrawgDfLhI2,dgYLTviRAGwEFV15)
			if CorYkXhAmuvNR9SDZTJz==fdQOo6Hu4B5Rbg:
				import diEohNHXbY
				diEohNHXbY.hJXy9kqmV6gZe0C5bnuO1(P5VqbRSzjtO4UE1rZaolG67XA)
				NNetFngY7vowQPJp5xCumG2qrKcfk1()
			elif CorYkXhAmuvNR9SDZTJz==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: NNetFngY7vowQPJp5xCumG2qrKcfk1()
	RNLVGsjzCKZ6Wr9eiwIFPDpvcMo = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,RVpeGcmPxj9tCnT40Nf216(u"ࠫࡱ࡯ࡳࡵࠩཾ"),cJSNFCIhymEfx6grGu0M(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨཿ"),UighHKAfySm4PWErqJ(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨྀ"))
	if not RNLVGsjzCKZ6Wr9eiwIFPDpvcMo: RNLVGsjzCKZ6Wr9eiwIFPDpvcMo = []
	llRJfWygdDtYzu03CFkKNpLhE89IX = llRJfWygdDtYzu03CFkKNpLhE89IX.replace(zEgtT9cR6bFp7JXqI5VuhNeP,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧ࡝࡞ࡱཱྀࠫ")).replace(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨ࡝ࡕࡘࡑࡣࠧྂ"),G9G0YqivIfmUWO8K).replace(ipjCIhwEXsbadR,G9G0YqivIfmUWO8K).replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)
	NNkTygWcJUAhLMS = NNkTygWcJUAhLMS.replace(zEgtT9cR6bFp7JXqI5VuhNeP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࡟ࡠࡳ࠭ྃ")).replace(ETNq5t4MYngSsbfFD8J0v(u"ࠪ࡟ࡗ࡚ࡌ࡞྄ࠩ"),G9G0YqivIfmUWO8K).replace(ipjCIhwEXsbadR,G9G0YqivIfmUWO8K).replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)
	FhgyQSqcuE685e134WxXvwYsf = GBx0Fcf7sLbqlntEX3yMezu+jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠿ࡀࠧ྅")+NNkTygWcJUAhLMS
	if FhgyQSqcuE685e134WxXvwYsf in RNLVGsjzCKZ6Wr9eiwIFPDpvcMo:
		O3mkKnrawgDfLhI2 = ssGdubC4mngM9D5SRc3Ye(u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ྆")
		hbKFzulmsw4k(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡲࡪࡩ࡫ࡸࠬ྇"),G9G0YqivIfmUWO8K,PPaLcMud2Em+O3mkKnrawgDfLhI2,dgYLTviRAGwEFV15)
		return
	BB3WhzNV1muMaO = str(F7aJYwLMEmxAVRupWf).split(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧ࠯ࠩྈ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	yzieWRVX4nkB3DjGHJphEdQo = Kkfl8xemuHbd1w3a0ABPcDrN[bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨྉ")][rr7Xolsp4JwjPK3L(u"࠺ᑸ")]
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,RVpeGcmPxj9tCnT40Nf216(u"ࠩࡓࡓࡘ࡚ࠧྊ"),yzieWRVX4nkB3DjGHJphEdQo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫྋ"),kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
	rUb6T01oHm8vzPjCsp5EL2NadGixZ = oo9kuULlebNgpY0Om.findall(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫྌ"),RpnYai0qJ4G6mIw,oo9kuULlebNgpY0Om.DOTALL)
	for Y2Ldvt13j8yJla0fEKXQR,sZAdkDhyUR9Vb,Tt4H9SZIzbsad56o,kwNx4tfaC7pd in rUb6T01oHm8vzPjCsp5EL2NadGixZ:
		Y2Ldvt13j8yJla0fEKXQR = Y2Ldvt13j8yJla0fEKXQR.split(VHrIziKUDuNGXkMla(u"ࠬ࠱ࠧྍ"))
		Tt4H9SZIzbsad56o = Tt4H9SZIzbsad56o.split(iAGgjwb7tVMmacRJ(u"࠭ࠫࠨྎ"))
		kwNx4tfaC7pd = kwNx4tfaC7pd.split(RVpeGcmPxj9tCnT40Nf216(u"ࠧࠬࠩྏ"))
		if k83jFdPwOph5 in Y2Ldvt13j8yJla0fEKXQR and pNmWTskohjIPSt7fQl==sZAdkDhyUR9Vb and GBx0Fcf7sLbqlntEX3yMezu in Tt4H9SZIzbsad56o and BB3WhzNV1muMaO in kwNx4tfaC7pd:
			O3mkKnrawgDfLhI2 = qTVF3icWwGXy5(u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭ྐ")
			J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(cJSNFCIhymEfx6grGu0M(u"ࠩࡵ࡭࡬࡮ࡴࠨྑ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪาึ๎ฬࠨྒ"),cjbAkCIinvs(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨྒྷ"),PPaLcMud2Em+O3mkKnrawgDfLhI2,dgYLTviRAGwEFV15)
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg: hbKFzulmsw4k(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬྔ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,O3mkKnrawgDfLhI2)
			return
	O3mkKnrawgDfLhI2 = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭ྕ")
	FLYhX5inS0lMZ = YZL469QjvSV(DTF3Lwy9etRH8mI(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ྖ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬྗ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩอัิ๐หࠡฮีส๏࠭྘"),FWqeEzO1i8Dn0ga(u"ࠪฮาี๊ฬࠢส่อืๆศ็ฯࠫྙ"),PPaLcMud2Em+O3mkKnrawgDfLhI2,dgYLTviRAGwEFV15)
	if FLYhX5inS0lMZ==fdQOo6Hu4B5Rbg:
		vXAlKF2MkTnw0icVNIua1qR(kkMuQrLWcEayRm)
		XXeZuvhknsKYqB17gwm6dfc(bneABYmwFUH8GXphg0Kl2Sq(u"๋ࠫาอหࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠢส่ัุฦ๋ࠩྚ"),VHrIziKUDuNGXkMla(u"ࠬ๓ࡓࡶࡥࡦࡩࡸࡹࠧྛ"),SSCU3jdyFn2V=yiaeCEwJjOcWA4ZSd5h(u"࠼࠻࠰ᑹ"))
		NNetFngY7vowQPJp5xCumG2qrKcfk1()
	elif FLYhX5inS0lMZ==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:
		import diEohNHXbY
		diEohNHXbY.hJXy9kqmV6gZe0C5bnuO1(P5VqbRSzjtO4UE1rZaolG67XA)
		NNetFngY7vowQPJp5xCumG2qrKcfk1()
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ྜ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྜྷ"),EHUAyW2lQfe4LXmhgIGc(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩྞ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg: tuhOpP4A07F8e = iAGgjwb7tVMmacRJ(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬྟ")
	else:
		hbKFzulmsw4k(ETNq5t4MYngSsbfFD8J0v(u"ࠪࡧࡪࡴࡴࡦࡴࠪྠ"),G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྡ"),ipjCIhwEXsbadR+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬྡྷ")+zzGfwLAyN5HTxUoJeaivY+FWqeEzO1i8Dn0ga(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩྣ"))
		return
	n1rcMdD6CB8ie3lFqTW = llRJfWygdDtYzu03CFkKNpLhE89IX
	import diEohNHXbY
	pEU7uHoc0zQOC1Anab3KxZ9k = diEohNHXbY.PHxrpu4dEJInZf36qVWs7NwUtGDO(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡆࡴࡵࡳࡷࡹࠧྤ"),n1rcMdD6CB8ie3lFqTW,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨྥ"),tuhOpP4A07F8e)
	if pEU7uHoc0zQOC1Anab3KxZ9k and tuhOpP4A07F8e:
		RNLVGsjzCKZ6Wr9eiwIFPDpvcMo.append(FhgyQSqcuE685e134WxXvwYsf)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,ETNq5t4MYngSsbfFD8J0v(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬྦ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬྦྷ"),RNLVGsjzCKZ6Wr9eiwIFPDpvcMo,UKDwMTZk9dni1JSLcf0oRXhqy)
	return
def XylVYsO6wgKreZ5xBE3Ntp(snev3rg1V28C9pxGO6RNfIDBS0z,filename=None):
	if LTze51miOknVcslNF43WSA6vMjYZt: snev3rg1V28C9pxGO6RNfIDBS0z = snev3rg1V28C9pxGO6RNfIDBS0z.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	if not filename: zsZJaB5qojX42KcD = FWqeEzO1i8Dn0ga(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫྨ")+str(SSCU3jdyFn2V.time())+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬ࠴ࡤࡢࡶࠪྩ")
	else: zsZJaB5qojX42KcD = iqHhJSxdaANDG5rlZm7B(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭ྪ")+filename+RVpeGcmPxj9tCnT40Nf216(u"ࠧ࠯ࡦࡤࡸࠬྫ")
	open(zsZJaB5qojX42KcD,cJSNFCIhymEfx6grGu0M(u"ࠨࡹࡥࠫྫྷ")).write(snev3rg1V28C9pxGO6RNfIDBS0z)
	return
def nuDV6jzU0TEISJQ(BM9q472Scdmj0):
	if BM9q472Scdmj0:
		YvSXiz5xrJEpUlDcA = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,UighHKAfySm4PWErqJ(u"ࠩ࡯࡭ࡸࡺࠧྭ"),iqHhJSxdaANDG5rlZm7B(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ྮ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧྯ"))
		if YvSXiz5xrJEpUlDcA: return YvSXiz5xrJEpUlDcA
	yzieWRVX4nkB3DjGHJphEdQo = Kkfl8xemuHbd1w3a0ABPcDrN[ssGdubC4mngM9D5SRc3Ye(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬྰ")][cjbAkCIinvs(u"࠻ᑺ")]
	agZ6rli0mxGfo8 = bVA4SCPumtZKi(kkMuQrLWcEayRm) if not BM9q472Scdmj0 else iOtjqZ6Iydl
	tAPnOsC2Fi6WIRUdSQhJLclXHYTp = veFOcmHqAr1jfz()
	JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA = tAPnOsC2Fi6WIRUdSQhJLclXHYTp.split(cjbAkCIinvs(u"࠭ࠬࠨྱ"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
	QcIUaMfd1XNsuwTJDpySBrOE5047 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,cjbAkCIinvs(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ྲ"))
	kkhj8Ds0OuTBZJRmNFl9IHd = af4TRecYZQ5WCOdkLKhtqJxpsHFmP()
	nLi5fzKDxgcvMY0C3GUpedPSQ = {EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡷࡶࡩࡷ࠭ླ"):agZ6rli0mxGfo8,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪྴ"):GBx0Fcf7sLbqlntEX3yMezu,t2sCrJ0xbgDRkf(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫྵ"):JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࡮ࡪࡳࠨྶ"):FCV0wTRHopA2ljcvrP(kkhj8Ds0OuTBZJRmNFl9IHd)}
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,iqHhJSxdaANDG5rlZm7B(u"ࠬࡖࡏࡔࡖࠪྷ"),yzieWRVX4nkB3DjGHJphEdQo,nLi5fzKDxgcvMY0C3GUpedPSQ,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫྸ"))
	YvSXiz5xrJEpUlDcA = []
	if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
		YvSXiz5xrJEpUlDcA = RpnYai0qJ4G6mIw.replace(rr7Xolsp4JwjPK3L(u"ࠧ࡝࡞ࡵࠫྐྵ"),zEgtT9cR6bFp7JXqI5VuhNeP).replace(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࡞࡟ࡲࠬྺ"),zEgtT9cR6bFp7JXqI5VuhNeP).replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࡟ࡶࡡࡴࠧྻ"),zEgtT9cR6bFp7JXqI5VuhNeP).replace(fXE2iwNYcD,zEgtT9cR6bFp7JXqI5VuhNeP)
		YvSXiz5xrJEpUlDcA = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ྼ"),YvSXiz5xrJEpUlDcA,oo9kuULlebNgpY0Om.DOTALL)
		if YvSXiz5xrJEpUlDcA:
			YvSXiz5xrJEpUlDcA = sorted(YvSXiz5xrJEpUlDcA,reverse=kkMuQrLWcEayRm,key=lambda key: int(key[dQ5JhEYolPmy1fvHktMw6NFRxiz]))
			ww5lQDRFdag8VnuXOTUMCbcp,agZ6rli0mxGfo8,pFGTX4fZNI9RB2xKOWAdsgb,HgbMUjLOaP43Ts6W,y4gZHwkYufl,DeRNxUpz3y8h05KCvgJEi = YvSXiz5xrJEpUlDcA[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			LLjWHQVnMsdCyr = DeRNxUpz3y8h05KCvgJEi if kWUE5INdVuX9wSOFsnZ([UighHKAfySm4PWErqJ(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪ྽")])[dQ5JhEYolPmy1fvHktMw6NFRxiz] else pFGTX4fZNI9RB2xKOWAdsgb
			amx9qJHkhw7oLdtVMG3.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ྾"),LLjWHQVnMsdCyr)
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,ssGdubC4mngM9D5SRc3Ye(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ྿"),UighHKAfySm4PWErqJ(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ࿀"),YvSXiz5xrJEpUlDcA,TTm2opnt9fLX8DBYizbuSPvwhJZCl)
			amx9qJHkhw7oLdtVMG3.setSetting(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ࿁"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
	return YvSXiz5xrJEpUlDcA
def ZxFewT6jWI1puarhCYmdbSGP(XD3GbcWnEJhsT7arvk5K84q,atvxkHQC20WMgJOm=dQ5JhEYolPmy1fvHktMw6NFRxiz,TeOl2aW6Eod9Pcr15ChHp3nk=dQ5JhEYolPmy1fvHktMw6NFRxiz):
	if atvxkHQC20WMgJOm and not TeOl2aW6Eod9Pcr15ChHp3nk: TeOl2aW6Eod9Pcr15ChHp3nk = len(XD3GbcWnEJhsT7arvk5K84q)//atvxkHQC20WMgJOm
	z7zIOkLxeQFwH,p0p6MxKbklodNCR92Wv,OyIA1vwqgV4 = [],-fdQOo6Hu4B5Rbg,dQ5JhEYolPmy1fvHktMw6NFRxiz
	for xis68omJPAWO0gLN in XD3GbcWnEJhsT7arvk5K84q:
		if OyIA1vwqgV4%TeOl2aW6Eod9Pcr15ChHp3nk==dQ5JhEYolPmy1fvHktMw6NFRxiz:
			p0p6MxKbklodNCR92Wv += fdQOo6Hu4B5Rbg
			z7zIOkLxeQFwH.append([])
		z7zIOkLxeQFwH[p0p6MxKbklodNCR92Wv].append(xis68omJPAWO0gLN)
		OyIA1vwqgV4 += fdQOo6Hu4B5Rbg
	return z7zIOkLxeQFwH
def J2JeCHy7MV5aus8NbEXo1DAlztKm(zsZJaB5qojX42KcD,snev3rg1V28C9pxGO6RNfIDBS0z):
	DDUjpRBOdVXkcYHtE0slP9 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,zsZJaB5qojX42KcD)
	if fdQOo6Hu4B5Rbg or hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡌࡔ࡙࡜࡟ࠨ࿂") not in zsZJaB5qojX42KcD or wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡑ࠸࡛࡟ࠨ࿃") not in zsZJaB5qojX42KcD: xCVyDu98lp4NE3MR6A0 = str(snev3rg1V28C9pxGO6RNfIDBS0z)
	else:
		z7zIOkLxeQFwH = ZxFewT6jWI1puarhCYmdbSGP(snev3rg1V28C9pxGO6RNfIDBS0z,VHrIziKUDuNGXkMla(u"࠸ᑻ"))
		xCVyDu98lp4NE3MR6A0 = G9G0YqivIfmUWO8K
		for LLqaXn748s2idlwxuJO6IYtmQATGEM in z7zIOkLxeQFwH:
			xCVyDu98lp4NE3MR6A0 += str(LLqaXn748s2idlwxuJO6IYtmQATGEM)+bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ࿄")
		xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.strip(yiaeCEwJjOcWA4ZSd5h(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ࿅"))
	ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM = opMdBjWmRv4GJU.compress(xCVyDu98lp4NE3MR6A0)
	open(DDUjpRBOdVXkcYHtE0slP9,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡷࡣ࿆ࠩ")).write(ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM)
	return
def DRNEnojsqxPY(yPzwn62HO0FEkNC,zsZJaB5qojX42KcD):
	if yPzwn62HO0FEkNC==rr7Xolsp4JwjPK3L(u"ࠧࡥ࡫ࡦࡸࠬ࿇"): snev3rg1V28C9pxGO6RNfIDBS0z = {}
	elif yPzwn62HO0FEkNC==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ࡮࡬ࡷࡹ࠭࿈"): snev3rg1V28C9pxGO6RNfIDBS0z = []
	elif yPzwn62HO0FEkNC==qTVF3icWwGXy5(u"ࠩࡶࡸࡷ࠭࿉"): snev3rg1V28C9pxGO6RNfIDBS0z = G9G0YqivIfmUWO8K
	elif yPzwn62HO0FEkNC==ssGdubC4mngM9D5SRc3Ye(u"ࠪ࡭ࡳࡺࠧ࿊"): snev3rg1V28C9pxGO6RNfIDBS0z = dQ5JhEYolPmy1fvHktMw6NFRxiz
	else: snev3rg1V28C9pxGO6RNfIDBS0z = None
	DDUjpRBOdVXkcYHtE0slP9 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,zsZJaB5qojX42KcD)
	ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM = open(DDUjpRBOdVXkcYHtE0slP9,dC3PsQJ0Ti28uYlov(u"ࠫࡷࡨࠧ࿋")).read()
	xCVyDu98lp4NE3MR6A0 = opMdBjWmRv4GJU.decompress(ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM)
	if rxWDdRBIct57i90s(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ࿌") not in xCVyDu98lp4NE3MR6A0: snev3rg1V28C9pxGO6RNfIDBS0z = eval(xCVyDu98lp4NE3MR6A0)
	else:
		z7zIOkLxeQFwH = xCVyDu98lp4NE3MR6A0.split(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ࿍"))
		del xCVyDu98lp4NE3MR6A0
		snev3rg1V28C9pxGO6RNfIDBS0z = []
		C0e8FUWzM5k7c4tiJnpb = QnzeRvFJ8G()
		ww5lQDRFdag8VnuXOTUMCbcp = dQ5JhEYolPmy1fvHktMw6NFRxiz
		for LLqaXn748s2idlwxuJO6IYtmQATGEM in z7zIOkLxeQFwH:
			C0e8FUWzM5k7c4tiJnpb.zSpce8FsXjQyi390AOEBV7lIwr(str(ww5lQDRFdag8VnuXOTUMCbcp),eval,LLqaXn748s2idlwxuJO6IYtmQATGEM)
			ww5lQDRFdag8VnuXOTUMCbcp += fdQOo6Hu4B5Rbg
		del z7zIOkLxeQFwH
		C0e8FUWzM5k7c4tiJnpb.rLew60CtWuYQ8sxZ21lEPHkmh9vd()
		C0e8FUWzM5k7c4tiJnpb.DExaBcOv3lsIAm()
		TiNW3LnYbKwk5SpsIC6 = list(C0e8FUWzM5k7c4tiJnpb.resultsDICT.keys())
		HKj0SNEJvXwBR95Gft = sorted(TiNW3LnYbKwk5SpsIC6,reverse=kkMuQrLWcEayRm,key=lambda key: int(key))
		for ww5lQDRFdag8VnuXOTUMCbcp in HKj0SNEJvXwBR95Gft:
			snev3rg1V28C9pxGO6RNfIDBS0z += C0e8FUWzM5k7c4tiJnpb.resultsDICT[ww5lQDRFdag8VnuXOTUMCbcp]
	return snev3rg1V28C9pxGO6RNfIDBS0z
def iDmn0uvdwpWHo7yP(IJPabrdjXE7HGR163qY48pMVU5l):
	Hg9QLlftBjbv3oK = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡢࡦࡧࡳࡳࡹࠧ࿎"),IJPabrdjXE7HGR163qY48pMVU5l,qTVF3icWwGXy5(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ࿏"))
	try: HXV2IhGz4vNqMoZOw3rlEWndYt71Q6 = open(Hg9QLlftBjbv3oK,iqHhJSxdaANDG5rlZm7B(u"ࠩࡵࡦࠬ࿐")).read()
	except:
		kP0ty8E9m4NnvH12IWDqzUlcQ5eoB = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(NGLWtwdZaOCMnlXizgqJmDxVph13sB,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ࿑"),IJPabrdjXE7HGR163qY48pMVU5l,EHUAyW2lQfe4LXmhgIGc(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ࿒"))
		try: HXV2IhGz4vNqMoZOw3rlEWndYt71Q6 = open(kP0ty8E9m4NnvH12IWDqzUlcQ5eoB,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡸࡢࠨ࿓")).read()
		except: return G9G0YqivIfmUWO8K,[]
	if LTze51miOknVcslNF43WSA6vMjYZt: HXV2IhGz4vNqMoZOw3rlEWndYt71Q6 = HXV2IhGz4vNqMoZOw3rlEWndYt71Q6.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	cX5ALtk3G0JQ = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪ࿔"),HXV2IhGz4vNqMoZOw3rlEWndYt71Q6,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	if not cX5ALtk3G0JQ: return G9G0YqivIfmUWO8K,[]
	DuXbOwN5Ays29qMTIfvL8zmkQZP3,GUQXoE6eZ2mvND97qrW1nlLgRIPx = cX5ALtk3G0JQ[dQ5JhEYolPmy1fvHktMw6NFRxiz],hwmEHOpWo24TygucdVUM(cX5ALtk3G0JQ[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	return DuXbOwN5Ays29qMTIfvL8zmkQZP3,GUQXoE6eZ2mvND97qrW1nlLgRIPx
def oEJ0MXzZcUlR8wCi6h7G():
	aF48hCXsYJnuopZv3M5KEkSxjBc = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡥ࡫ࡦࡸࠬ࿕"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ࿖"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ࿗"))
	if aF48hCXsYJnuopZv3M5KEkSxjBc: return aF48hCXsYJnuopZv3M5KEkSxjBc
	yhzDrESJuqnvtAI27iWF4xUeKpskR0,aF48hCXsYJnuopZv3M5KEkSxjBc = {},{}
	L7hUToPpbQRdO9Ca6lG5kF = [Kkfl8xemuHbd1w3a0ABPcDrN[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡖࡊࡖࡏࡔࠩ࿘")][dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	if F7aJYwLMEmxAVRupWf>RVpeGcmPxj9tCnT40Nf216(u"࠲࠹࠱࠽࠾ᑼ"): L7hUToPpbQRdO9Ca6lG5kF.append(Kkfl8xemuHbd1w3a0ABPcDrN[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡗࡋࡐࡐࡕࠪ࿙")][fdQOo6Hu4B5Rbg])
	if LTze51miOknVcslNF43WSA6vMjYZt: L7hUToPpbQRdO9Ca6lG5kF.append(Kkfl8xemuHbd1w3a0ABPcDrN[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡘࡅࡑࡑࡖࠫ࿚")][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU])
	for O3fy5A07aNziRuMW6QXLlJpE in L7hUToPpbQRdO9Ca6lG5kF:
		DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡇࡆࡖࠪ࿛"),O3fy5A07aNziRuMW6QXLlJpE,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ࿜"))
		if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
			RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
			GWYpbSAOn2P7r = O3fy5A07aNziRuMW6QXLlJpE.rsplit(rr7Xolsp4JwjPK3L(u"ࠨ࠱ࠪ࿝"),bneABYmwFUH8GXphg0Kl2Sq(u"࠳ᑽ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			C05nJAiobgedHVuRUZFWQa4spvt = oo9kuULlebNgpY0Om.findall(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࿞"),RpnYai0qJ4G6mIw,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
			for IJPabrdjXE7HGR163qY48pMVU5l,DHAdK9oOJuIBv in C05nJAiobgedHVuRUZFWQa4spvt:
				wtFqneLXsH2a = GWYpbSAOn2P7r+qTVF3icWwGXy5(u"ࠪ࠳ࠬ࿟")+IJPabrdjXE7HGR163qY48pMVU5l+EHUAyW2lQfe4LXmhgIGc(u"ࠫ࠴࠭࿠")+IJPabrdjXE7HGR163qY48pMVU5l+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬ࠳ࠧ࿡")+DHAdK9oOJuIBv+hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭࠮ࡻ࡫ࡳࠫ࿢")
				if IJPabrdjXE7HGR163qY48pMVU5l not in list(yhzDrESJuqnvtAI27iWF4xUeKpskR0.keys()):
					yhzDrESJuqnvtAI27iWF4xUeKpskR0[IJPabrdjXE7HGR163qY48pMVU5l] = []
					aF48hCXsYJnuopZv3M5KEkSxjBc[IJPabrdjXE7HGR163qY48pMVU5l] = []
				WWuvQNsXAebMOYLg = hwmEHOpWo24TygucdVUM(DHAdK9oOJuIBv)
				yhzDrESJuqnvtAI27iWF4xUeKpskR0[IJPabrdjXE7HGR163qY48pMVU5l].append((DHAdK9oOJuIBv,WWuvQNsXAebMOYLg,wtFqneLXsH2a))
	for IJPabrdjXE7HGR163qY48pMVU5l in list(yhzDrESJuqnvtAI27iWF4xUeKpskR0.keys()):
		aF48hCXsYJnuopZv3M5KEkSxjBc[IJPabrdjXE7HGR163qY48pMVU5l] = sorted(yhzDrESJuqnvtAI27iWF4xUeKpskR0[IJPabrdjXE7HGR163qY48pMVU5l],reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: key[fdQOo6Hu4B5Rbg])
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ࿣"),ssGdubC4mngM9D5SRc3Ye(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ࿤"),aF48hCXsYJnuopZv3M5KEkSxjBc,TTm2opnt9fLX8DBYizbuSPvwhJZCl)
	return aF48hCXsYJnuopZv3M5KEkSxjBc
def hwmEHOpWo24TygucdVUM(DHAdK9oOJuIBv):
	WWuvQNsXAebMOYLg = []
	kiDdMmwYato2y = DHAdK9oOJuIBv.split(iqHhJSxdaANDG5rlZm7B(u"ࠩ࠱ࠫ࿥"))
	for qrOuR4yZi5UI60z in kiDdMmwYato2y:
		dc7nfCvkNHVIE4jADpFWXSug6b3 = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧ࿦"),qrOuR4yZi5UI60z,oo9kuULlebNgpY0Om.DOTALL)
		HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8 = []
		for w054jsNq8VIDt in dc7nfCvkNHVIE4jADpFWXSug6b3:
			if w054jsNq8VIDt.isdigit(): w054jsNq8VIDt = int(w054jsNq8VIDt)
			HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8.append(w054jsNq8VIDt)
		WWuvQNsXAebMOYLg.append(HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8)
	return WWuvQNsXAebMOYLg
def wwcfLBUPWqVuh29YJZXSgkExFbn(WWuvQNsXAebMOYLg):
	DHAdK9oOJuIBv = G9G0YqivIfmUWO8K
	for qrOuR4yZi5UI60z in WWuvQNsXAebMOYLg:
		for w054jsNq8VIDt in qrOuR4yZi5UI60z: DHAdK9oOJuIBv += str(w054jsNq8VIDt)
		DHAdK9oOJuIBv += jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠳࠭࿧")
	DHAdK9oOJuIBv = DHAdK9oOJuIBv.strip(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬ࠴ࠧ࿨"))
	return DHAdK9oOJuIBv
def EdSa1xYWFqh7AogkzZlV9ny(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4):
	zc5UCovAZSP4i = {}
	yhzDrESJuqnvtAI27iWF4xUeKpskR0 = oEJ0MXzZcUlR8wCi6h7G()
	fhytpU9ATuCJ = pXtYw28arhDB4MlQ6CSz9ydFs(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4)
	for IJPabrdjXE7HGR163qY48pMVU5l in Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4:
		if IJPabrdjXE7HGR163qY48pMVU5l not in list(yhzDrESJuqnvtAI27iWF4xUeKpskR0.keys()): continue
		aF48hCXsYJnuopZv3M5KEkSxjBc = yhzDrESJuqnvtAI27iWF4xUeKpskR0[IJPabrdjXE7HGR163qY48pMVU5l]
		fm1hjlvwnq5cPGbEOd3up6MRtLx8T,lBWo8JLrdaTHbiK5XC72vsU9cNPIF,R9xUITMGiXnVjtCqWdDFoO3NB = aF48hCXsYJnuopZv3M5KEkSxjBc[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		lUCF7QjfxkSD6Id3JMaB2sy,Kkavce27DOol = iDmn0uvdwpWHo7yP(IJPabrdjXE7HGR163qY48pMVU5l)
		SdQxTMVyGqs2RtHr4em6WCzc0bgkBZ,RPAfQ3794OGch6aWkJFHXKEIvS = fhytpU9ATuCJ[IJPabrdjXE7HGR163qY48pMVU5l]
		ZtNi7L2JqVrwWEucXYS = lBWo8JLrdaTHbiK5XC72vsU9cNPIF>Kkavce27DOol and SdQxTMVyGqs2RtHr4em6WCzc0bgkBZ
		GB7zx0pZDrQTeHCRW = P5VqbRSzjtO4UE1rZaolG67XA
		if not SdQxTMVyGqs2RtHr4em6WCzc0bgkBZ: HIpi1JT8nK7NyWBf6z3kcwu = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ࿩")
		elif not RPAfQ3794OGch6aWkJFHXKEIvS: HIpi1JT8nK7NyWBf6z3kcwu = EHUAyW2lQfe4LXmhgIGc(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ࿪")
		elif ZtNi7L2JqVrwWEucXYS: HIpi1JT8nK7NyWBf6z3kcwu = t2sCrJ0xbgDRkf(u"ࠨࡱ࡯ࡨࠬ࿫")
		else:
			HIpi1JT8nK7NyWBf6z3kcwu = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡪࡳࡴࡪࠧ࿬")
			GB7zx0pZDrQTeHCRW = kkMuQrLWcEayRm
		zc5UCovAZSP4i[IJPabrdjXE7HGR163qY48pMVU5l] = GB7zx0pZDrQTeHCRW,lUCF7QjfxkSD6Id3JMaB2sy,Kkavce27DOol,fm1hjlvwnq5cPGbEOd3up6MRtLx8T,lBWo8JLrdaTHbiK5XC72vsU9cNPIF,HIpi1JT8nK7NyWBf6z3kcwu,R9xUITMGiXnVjtCqWdDFoO3NB
	return zc5UCovAZSP4i
def CigEOdTqom6Gw5nta(HofqU5Wsa9,J5RWbFoOldsjfwEz17utC,I72yN9cRlgkMuheFOa6sA=G9G0YqivIfmUWO8K,zUvtISW0fdVcsN8YDaCE5quQp7XlFH=G9G0YqivIfmUWO8K,Y2Ldvt13j8yJla0fEKXQR=G9G0YqivIfmUWO8K):
	if gA0m6CQUyfLG: HofqU5Wsa9.update(J5RWbFoOldsjfwEz17utC,I72yN9cRlgkMuheFOa6sA,zUvtISW0fdVcsN8YDaCE5quQp7XlFH,Y2Ldvt13j8yJla0fEKXQR)
	else: HofqU5Wsa9.update(J5RWbFoOldsjfwEz17utC,I72yN9cRlgkMuheFOa6sA+zEgtT9cR6bFp7JXqI5VuhNeP+zUvtISW0fdVcsN8YDaCE5quQp7XlFH+zEgtT9cR6bFp7JXqI5VuhNeP+Y2Ldvt13j8yJla0fEKXQR)
	return
def NbUXSx5TuGC(ytgAme6a3Mi4Wq79Zdc1PDClTIRK):
	def GTspBEmoRq1wND(qb0pGQ7wUmyncAOBJlI5tP,Ibr61AOhmk02WFsGLjvfU,jSBDkque9MWsmdZEHOzarfVTK1vU=RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥ࿭")):
		return ((qb0pGQ7wUmyncAOBJlI5tP == dQ5JhEYolPmy1fvHktMw6NFRxiz) and jSBDkque9MWsmdZEHOzarfVTK1vU[dQ5JhEYolPmy1fvHktMw6NFRxiz]) or (GTspBEmoRq1wND(qb0pGQ7wUmyncAOBJlI5tP // Ibr61AOhmk02WFsGLjvfU, Ibr61AOhmk02WFsGLjvfU, jSBDkque9MWsmdZEHOzarfVTK1vU).lstrip(jSBDkque9MWsmdZEHOzarfVTK1vU[dQ5JhEYolPmy1fvHktMw6NFRxiz]) + jSBDkque9MWsmdZEHOzarfVTK1vU[qb0pGQ7wUmyncAOBJlI5tP % Ibr61AOhmk02WFsGLjvfU])
	def c6e9l1XxarQtj(iOmehagPA3uW50nlJZwcM9zp, qIjOPGKdtixmreBTkuz9gAXW14y, uHjxYiJ58UOTDmMZEwz0sfR7kLSA, gpDA3bPEletIyH1RNB, Ako2LgN5rIHvq1pXieuBTJMdQD=None, hb2zi0PXn1Y=None, Cbd8Aios5RBZVypX9gkajLYtJmc=None):
		while (uHjxYiJ58UOTDmMZEwz0sfR7kLSA):
			uHjxYiJ58UOTDmMZEwz0sfR7kLSA-=GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠴ᑾ")
			if (gpDA3bPEletIyH1RNB[uHjxYiJ58UOTDmMZEwz0sfR7kLSA]): iOmehagPA3uW50nlJZwcM9zp = oo9kuULlebNgpY0Om.sub(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠦࡡࡢࡢࠣ࿮") + GTspBEmoRq1wND(uHjxYiJ58UOTDmMZEwz0sfR7kLSA, qIjOPGKdtixmreBTkuz9gAXW14y) + DTF3Lwy9etRH8mI(u"ࠧࡢ࡜ࡣࠤ࿯"),  gpDA3bPEletIyH1RNB[uHjxYiJ58UOTDmMZEwz0sfR7kLSA], iOmehagPA3uW50nlJZwcM9zp)
		return iOmehagPA3uW50nlJZwcM9zp
	ytgAme6a3Mi4Wq79Zdc1PDClTIRK = ytgAme6a3Mi4Wq79Zdc1PDClTIRK.split(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡽࠩࠩ࿰"))[fdQOo6Hu4B5Rbg]
	ytgAme6a3Mi4Wq79Zdc1PDClTIRK = ytgAme6a3Mi4Wq79Zdc1PDClTIRK.rsplit(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡴࡲ࡯࡭ࡹ࠭࿱"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+ssGdubC4mngM9D5SRc3Ye(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨ࿲")
	l1RSViQejk8r5LOA4PWwYBX = eval(rr7Xolsp4JwjPK3L(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ࿳")+ytgAme6a3Mi4Wq79Zdc1PDClTIRK,{RVpeGcmPxj9tCnT40Nf216(u"ࠪࡦࡦࡹࡥࡏࠩ࿴"):GTspBEmoRq1wND,DTF3Lwy9etRH8mI(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ࿵"):c6e9l1XxarQtj})
	return l1RSViQejk8r5LOA4PWwYBX
def XaMFZPCb7J9tN(code):
	_IlYhep7Tu=rxWDdRBIct57i90s(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞࠰࠵ࠢ࿶")
	def CumeFShpMbfYa(hb2zi0PXn1Y,Ako2LgN5rIHvq1pXieuBTJMdQD,qOZwXBSAQzE):
		YADnh3QpNdg = list(_IlYhep7Tu)
		C4m0RAdxT6aZvKeUc72g815OpoHM = YADnh3QpNdg[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠴ᑿ"):Ako2LgN5rIHvq1pXieuBTJMdQD]
		KT9tdUH3hmiLZCEFz = YADnh3QpNdg[yiaeCEwJjOcWA4ZSd5h(u"࠵ᒀ"):qOZwXBSAQzE]
		hb2zi0PXn1Y = list(hb2zi0PXn1Y)[::-dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠷ᒁ")]
		MtcB169HDRaj38urXGZC2qd0LiyPmh = t2sCrJ0xbgDRkf(u"࠰ᒂ")
		for uHjxYiJ58UOTDmMZEwz0sfR7kLSA,Ibr61AOhmk02WFsGLjvfU in enumerate(hb2zi0PXn1Y):
			if Ibr61AOhmk02WFsGLjvfU in C4m0RAdxT6aZvKeUc72g815OpoHM: MtcB169HDRaj38urXGZC2qd0LiyPmh = MtcB169HDRaj38urXGZC2qd0LiyPmh + C4m0RAdxT6aZvKeUc72g815OpoHM.index(Ibr61AOhmk02WFsGLjvfU)*Ako2LgN5rIHvq1pXieuBTJMdQD**uHjxYiJ58UOTDmMZEwz0sfR7kLSA
		gpDA3bPEletIyH1RNB = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࠢ࿷")
		while MtcB169HDRaj38urXGZC2qd0LiyPmh > FWqeEzO1i8Dn0ga(u"࠱ᒃ"):
			gpDA3bPEletIyH1RNB = KT9tdUH3hmiLZCEFz[MtcB169HDRaj38urXGZC2qd0LiyPmh%qOZwXBSAQzE] + gpDA3bPEletIyH1RNB
			MtcB169HDRaj38urXGZC2qd0LiyPmh = (MtcB169HDRaj38urXGZC2qd0LiyPmh - (MtcB169HDRaj38urXGZC2qd0LiyPmh%qOZwXBSAQzE))//qOZwXBSAQzE
		return int(gpDA3bPEletIyH1RNB) or CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠲ᒄ")
	def kDb9BrF5h7gn(C4m0RAdxT6aZvKeUc72g815OpoHM,u,RRuQjr4cZS,gqTOJN1bmo5Kz,Ako2LgN5rIHvq1pXieuBTJMdQD,Cbd8Aios5RBZVypX9gkajLYtJmc):
		Cbd8Aios5RBZVypX9gkajLYtJmc = VHrIziKUDuNGXkMla(u"ࠢࠣ࿸");
		KT9tdUH3hmiLZCEFz = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠳ᒅ")
		while KT9tdUH3hmiLZCEFz < len(C4m0RAdxT6aZvKeUc72g815OpoHM):
			MtcB169HDRaj38urXGZC2qd0LiyPmh = bneABYmwFUH8GXphg0Kl2Sq(u"࠴ᒆ")
			H59FeDGtPmY = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠣࠤ࿹")
			while C4m0RAdxT6aZvKeUc72g815OpoHM[KT9tdUH3hmiLZCEFz] is not RRuQjr4cZS[Ako2LgN5rIHvq1pXieuBTJMdQD]:
				H59FeDGtPmY = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࠪ࿺").join([H59FeDGtPmY,C4m0RAdxT6aZvKeUc72g815OpoHM[KT9tdUH3hmiLZCEFz]])
				KT9tdUH3hmiLZCEFz = KT9tdUH3hmiLZCEFz + FWqeEzO1i8Dn0ga(u"࠶ᒇ")
			while MtcB169HDRaj38urXGZC2qd0LiyPmh < len(RRuQjr4cZS):
				H59FeDGtPmY = H59FeDGtPmY.replace(RRuQjr4cZS[MtcB169HDRaj38urXGZC2qd0LiyPmh],str(MtcB169HDRaj38urXGZC2qd0LiyPmh))
				MtcB169HDRaj38urXGZC2qd0LiyPmh = MtcB169HDRaj38urXGZC2qd0LiyPmh + RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠷ᒈ")
			Cbd8Aios5RBZVypX9gkajLYtJmc = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠫ࿻").join([Cbd8Aios5RBZVypX9gkajLYtJmc,dC3PsQJ0Ti28uYlov(u"ࠫࠬ࿼").join(map(chr, [CumeFShpMbfYa(H59FeDGtPmY,Ako2LgN5rIHvq1pXieuBTJMdQD,yiaeCEwJjOcWA4ZSd5h(u"࠱࠱ᒉ")) - gqTOJN1bmo5Kz]))])
			KT9tdUH3hmiLZCEFz = KT9tdUH3hmiLZCEFz + wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠲ᒊ")
		return Cbd8Aios5RBZVypX9gkajLYtJmc
	code = code.replace(VHrIziKUDuNGXkMla(u"ࠬࡢ࡮ࠨ࿽"),qTVF3icWwGXy5(u"࠭ࠧ࿾")).replace(qTVF3icWwGXy5(u"ࠧ࡝ࡴࠪ࿿"),ETNq5t4MYngSsbfFD8J0v(u"ࠨࠩက"))
	vLUAWDK60jBrP9pMIYcJab1SVomXEQ = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࡟ࢁࡡ࠮ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭࠱࠮࡜ࡥ࠭ࠬࡠ࠮ࡢࠩࠨခ"),code,oo9kuULlebNgpY0Om.DOTALL)
	if vLUAWDK60jBrP9pMIYcJab1SVomXEQ:
		vLUAWDK60jBrP9pMIYcJab1SVomXEQ = list(vLUAWDK60jBrP9pMIYcJab1SVomXEQ[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠲ᒋ")])
		for yEfedcCUN9BipGHwOZgWPkKJTn0,code in enumerate(vLUAWDK60jBrP9pMIYcJab1SVomXEQ):
			if code.isdigit(): vLUAWDK60jBrP9pMIYcJab1SVomXEQ[yEfedcCUN9BipGHwOZgWPkKJTn0] = int(code)
			else: vLUAWDK60jBrP9pMIYcJab1SVomXEQ[yEfedcCUN9BipGHwOZgWPkKJTn0] = code.replace(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡠࠧ࠭ဂ"),jR9YtmsgDX8nTQlMb6G3(u"ࠫࠬဃ"))
		tFW3OSLI1QCgVvyM7EeH0nosu = kDb9BrF5h7gn(*vLUAWDK60jBrP9pMIYcJab1SVomXEQ)
		return tFW3OSLI1QCgVvyM7EeH0nosu
	return wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࠭င")
def p5Q17cZn8L(yzieWRVX4nkB3DjGHJphEdQo,Xx4tFRp7qzAh=G9G0YqivIfmUWO8K):
	if Xx4tFRp7qzAh==vCmnFshSi4flecXIY2gy38G0DJw(u"࠭࡬ࡰࡹࡨࡶࠬစ"): yzieWRVX4nkB3DjGHJphEdQo = oo9kuULlebNgpY0Om.sub(iAGgjwb7tVMmacRJ(u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧဆ"),lambda k7yRIXwt4l9K: k7yRIXwt4l9K.group(dQ5JhEYolPmy1fvHktMw6NFRxiz).lower(),yzieWRVX4nkB3DjGHJphEdQo)
	elif Xx4tFRp7qzAh==vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡷࡳࡴࡪࡸࠧဇ"): yzieWRVX4nkB3DjGHJphEdQo = oo9kuULlebNgpY0Om.sub(EHUAyW2lQfe4LXmhgIGc(u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩဈ"),lambda k7yRIXwt4l9K: k7yRIXwt4l9K.group(dQ5JhEYolPmy1fvHktMw6NFRxiz).upper(),yzieWRVX4nkB3DjGHJphEdQo)
	return yzieWRVX4nkB3DjGHJphEdQo
def pXtYw28arhDB4MlQ6CSz9ydFs(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4):
	YKVOTvagq28Bs6ceHfj5RPS3G,BYRz6kMFpxG3NcqOj5902XirEn = kkMuQrLWcEayRm,kkMuQrLWcEayRm
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n = Pkp47glurdBOS38Y.connect(xxXTUlvGQ15JZAV0CbIc7Ry3wkES)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.text_factory = str
	ww2WhlesJYXSLQBMZ6gdy4K7c = plXWEwZYQTbg4JHCByU6LSr8RO1m0n.cursor()
	if len(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4)==fdQOo6Hu4B5Rbg: YZqMs76RUcCrL2xk8GegTzmjHVDotF = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࠬࠧ࠭ဉ")+Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4[dQ5JhEYolPmy1fvHktMw6NFRxiz]+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠧ࠯ࠧည")
	else: YZqMs76RUcCrL2xk8GegTzmjHVDotF = str(tuple(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(ssGdubC4mngM9D5SRc3Ye(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬဋ")+YZqMs76RUcCrL2xk8GegTzmjHVDotF+VHrIziKUDuNGXkMla(u"࠭ࠠ࠼ࠩဌ"))
	E52cBHtlZuUM9TdNn3FGp7kVJ04m = ww2WhlesJYXSLQBMZ6gdy4K7c.fetchall()
	fhytpU9ATuCJ = {}
	for IJPabrdjXE7HGR163qY48pMVU5l in Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4: fhytpU9ATuCJ[IJPabrdjXE7HGR163qY48pMVU5l] = (kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	for IJPabrdjXE7HGR163qY48pMVU5l,BYRz6kMFpxG3NcqOj5902XirEn in E52cBHtlZuUM9TdNn3FGp7kVJ04m:
		YKVOTvagq28Bs6ceHfj5RPS3G = P5VqbRSzjtO4UE1rZaolG67XA
		BYRz6kMFpxG3NcqOj5902XirEn = BYRz6kMFpxG3NcqOj5902XirEn==fdQOo6Hu4B5Rbg
		fhytpU9ATuCJ[IJPabrdjXE7HGR163qY48pMVU5l] = (YKVOTvagq28Bs6ceHfj5RPS3G,BYRz6kMFpxG3NcqOj5902XirEn)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
	return fhytpU9ATuCJ
def yBxCaXY5UwkD(u4uT6Mx7CnDAWspy2jIh):
	tRojAyBgfDH37eLCwP4dWl = G9G0YqivIfmUWO8K
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(u4uT6Mx7CnDAWspy2jIh):
		jnmXeb8f90Rpa6cFtsyDW2TJKLEr = open(u4uT6Mx7CnDAWspy2jIh,cJSNFCIhymEfx6grGu0M(u"ࠧࡳࡤࠪဍ")).read()
		if LTze51miOknVcslNF43WSA6vMjYZt: jnmXeb8f90Rpa6cFtsyDW2TJKLEr = jnmXeb8f90Rpa6cFtsyDW2TJKLEr.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		lsqZ3jrpe0I7gXMoCT8hwzY4 = bRCSwcA89e4J7pqdays5PxGiD2(rr7Xolsp4JwjPK3L(u"ࠨࡦ࡬ࡧࡹ࠭ဎ"),jnmXeb8f90Rpa6cFtsyDW2TJKLEr)
		if lsqZ3jrpe0I7gXMoCT8hwzY4:
			tRojAyBgfDH37eLCwP4dWl = {}
			for sKzaZIMqmo in lsqZ3jrpe0I7gXMoCT8hwzY4.keys():
				tRojAyBgfDH37eLCwP4dWl[sKzaZIMqmo] = []
				for jXSN5WDECbU9lsY3rHKegqBApknt in lsqZ3jrpe0I7gXMoCT8hwzY4[sKzaZIMqmo]:
					C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
					C9uTVdSkLlb5UemavyB6NjWHFh = jXSN5WDECbU9lsY3rHKegqBApknt[dQ5JhEYolPmy1fvHktMw6NFRxiz]
					Tqd89eUHZ7l = jXSN5WDECbU9lsY3rHKegqBApknt[fdQOo6Hu4B5Rbg]
					Tqd89eUHZ7l = wilKJdNLRzVvboaHjkYBrU51(Tqd89eUHZ7l)
					yzieWRVX4nkB3DjGHJphEdQo = jXSN5WDECbU9lsY3rHKegqBApknt[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
					bmP3CnZr75H984yd1k2Ng0EYLA = jXSN5WDECbU9lsY3rHKegqBApknt[c1R9fnIY4XBDZ]
					Vy1U0koJLPFhxe2TS = jXSN5WDECbU9lsY3rHKegqBApknt[xsCEkXb6tgrh3195YZ]
					eehFlSEjHioyAWpLqZXt79 = jXSN5WDECbU9lsY3rHKegqBApknt[jR9YtmsgDX8nTQlMb6G3(u"࠸ᒌ")]
					if len(jXSN5WDECbU9lsY3rHKegqBApknt)>DTF3Lwy9etRH8mI(u"࠺ᒍ"): xCVyDu98lp4NE3MR6A0 = jXSN5WDECbU9lsY3rHKegqBApknt[DTF3Lwy9etRH8mI(u"࠺ᒍ")]
					if len(jXSN5WDECbU9lsY3rHKegqBApknt)>Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠼ᒎ"): CW2cwYfL9s = jXSN5WDECbU9lsY3rHKegqBApknt[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠼ᒎ")]
					if len(jXSN5WDECbU9lsY3rHKegqBApknt)>iAGgjwb7tVMmacRJ(u"࠾ᒏ"): zF4nhxYlaiKPwA6NJZ3 = jXSN5WDECbU9lsY3rHKegqBApknt[iAGgjwb7tVMmacRJ(u"࠾ᒏ")]
					if u4uT6Mx7CnDAWspy2jIh==Mh2XHLxaCsToiUFymceOGKS: KIQhN0FCsGnbiSwlOjEpWfLRHrak3t = C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3
					else: KIQhN0FCsGnbiSwlOjEpWfLRHrak3t = C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3
					tRojAyBgfDH37eLCwP4dWl[sKzaZIMqmo].append(KIQhN0FCsGnbiSwlOjEpWfLRHrak3t)
		qyQ8MvDhH94crSZbYaC = str(tRojAyBgfDH37eLCwP4dWl)
		if LTze51miOknVcslNF43WSA6vMjYZt: qyQ8MvDhH94crSZbYaC = qyQ8MvDhH94crSZbYaC.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		open(u4uT6Mx7CnDAWspy2jIh,iqHhJSxdaANDG5rlZm7B(u"ࠩࡺࡦࠬဏ")).write(qyQ8MvDhH94crSZbYaC)
	return tRojAyBgfDH37eLCwP4dWl
def vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN):
	WWlx4Byhe182uF7YivmCGIJL = oob2dzmG3jTMpZwQyIfN.split(EHUAyW2lQfe4LXmhgIGc(u"ࠪ࠱ࠬတ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if   WWlx4Byhe182uF7YivmCGIJL==DTF3Lwy9etRH8mI(u"ࠫࡆࡎࡗࡂࡍࠪထ")		:	from kWKLl4pav2			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dC3PsQJ0Ti28uYlov(u"ࠬࡇࡋࡐࡃࡐࠫဒ")		:	from xx1DRtjhcN			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rxWDdRBIct57i90s(u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨဓ")	:	from Pq0s8YmBrW		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡂࡍ࡚ࡅࡒ࠭န")		:	from NNHDVzYX8O			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫပ")	:	from DhAGCN2eQx		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EHUAyW2lQfe4LXmhgIGc(u"ࠩࡄࡐࡆࡘࡁࡃࠩဖ")	:	from VoNzeJ0yCT			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RVpeGcmPxj9tCnT40Nf216(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬဗ")	:	from yGr4o5BFM0		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==ETNq5t4MYngSsbfFD8J0v(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧဘ")	: 	from wrjh9fNHVi		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧမ")	:	from zPrdLEfHpX		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧယ")	:	from Rv4Vr8E9MU		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==VHrIziKUDuNGXkMla(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩရ")	:	from U0Q3WRXbZD		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==ssGdubC4mngM9D5SRc3Ye(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭လ"):	from dPyzDFtHZ5	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==qTVF3icWwGXy5(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫဝ")	:	from ghAocGITQE		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==ssGdubC4mngM9D5SRc3Ye(u"ࠪࡅ࡞ࡒࡏࡍࠩသ")		:	from MvpUkBYmWn			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡇࡕࡋࡓࡃࠪဟ")		:	from a4ms6ISnL5			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iqHhJSxdaANDG5rlZm7B(u"ࠬࡈࡒࡔࡖࡈࡎࠬဠ")	:	from m7cWXSE4NF			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==yiaeCEwJjOcWA4ZSd5h(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧအ")	:	from HEAVlNCWB6		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡄࡋࡐࡅ࠹ࡖࠧဢ")	:	from E97qINVYMl			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨဣ")	:	from SGzMOepn4H			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iqHhJSxdaANDG5rlZm7B(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫဤ")	:	from cPoxDNVpRG		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rr7Xolsp4JwjPK3L(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬဥ")	:	from bJWPe8tmuq		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪဦ"):	from e8e57S9N0W	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧဧ")	:	from XTjciq7QDv		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨဨ")	:	from Ks6yfb3FEh		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==cjbAkCIinvs(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩဩ")	:	from uxNMiOoQnl		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫဪ")	:	from G5oJd6lKs2		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==t2sCrJ0xbgDRkf(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪါ")	:	from ROz51TArF8		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬာ")	:	from Zzt9qkiBaH		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==UighHKAfySm4PWErqJ(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩိ"):	from JaizWxwHY6	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iAGgjwb7tVMmacRJ(u"ࠬࡊࡒࡂࡏࡄࡇࡆࡌࡅࠨီ")	:	from pfF9k7uaV2		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dC3PsQJ0Ti28uYlov(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧု")	:	from PGToIvZ1Em		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rr7Xolsp4JwjPK3L(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨူ")	:	from SDoMIkl0yf		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪေ")	:	from oJCMRaUesk		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫဲ")	:	from TKZwaIdUNA		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==jR9YtmsgDX8nTQlMb6G3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬဳ")	:	from NE6q2giP1A		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==t2sCrJ0xbgDRkf(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ဴ")	:	from pg8n1POVBx		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭ဵ")	:	from KB2yzoTgjk		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭ံ")	:	from xyz1QBauXg			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==t2sCrJ0xbgDRkf(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ့ࠩ")	:	from oIVtjGrleB		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡇࡏࡍࡋ࡜ࡉࡅࡇࡒࠫး")	:	from p29dKyBG17		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡉࡅࡇࡘࡁࡌࡃ္ࠪ")	:	from WBrGOatN1y		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rxWDdRBIct57i90s(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜်࠭")	:	from Nb2MYp7A8v		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==FWqeEzO1i8Dn0ga(u"ࠫࡋࡇࡒࡆࡕࡎࡓࠬျ")	:	from bu6LkO3VUE		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧြ")	:	from RnXoZzTYVh		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==VHrIziKUDuNGXkMla(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨွ")	:	from JV7Os5T0jF		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==ssGdubC4mngM9D5SRc3Ye(u"ࠧࡇࡑࡖࡘࡆ࠭ှ")		:	from yEG4fWLa5h			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡈࡘࡒࡔࡔࡔࡗࠩဿ")	:	from MjKG5vkHoi		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==cjbAkCIinvs(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ၀")	:	from bbEyuBvqA2		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨ၁"):	from CvfLK2wysN	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪ၂"):	from ghv9KjdWt1	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EHUAyW2lQfe4LXmhgIGc(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ၃")	:	from HIADrh8zPE		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RVpeGcmPxj9tCnT40Nf216(u"࠭ࡉࡇࡋࡏࡑࠬ၄")		:	from nngBVuzXUo			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dC3PsQJ0Ti28uYlov(u"ࠧࡊࡒࡗ࡚ࠬ၅")		:	from QMzke4oxuJ			import fo3aZrpvQn248jXK9CY05DGx as oyuFxk4Vew5cHP16,CEL2jIhns8aW as PYymEzqnMT0it36kHG,s8zrCjhgWx9OvmKq65oefIXHw as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ၆")	:	from i27RhJKYpk		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==qTVF3icWwGXy5(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ၇")	:	from GGdrq1FDwj		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iAGgjwb7tVMmacRJ(u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ၈")	:	from IoEYqguvP8		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iAGgjwb7tVMmacRJ(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬ၉")	:	from bKcFVQqJ9l		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==dC3PsQJ0Ti28uYlov(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ၊")	:	from RYWbOd6qZF			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ။")	:	from TB34L5RJ8a		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RVpeGcmPxj9tCnT40Nf216(u"ࠧࡎ࠵ࡘࠫ၌")		:	from UUQbsdSjoM			import fo3aZrpvQn248jXK9CY05DGx as oyuFxk4Vew5cHP16,CEL2jIhns8aW as PYymEzqnMT0it36kHG,s8zrCjhgWx9OvmKq65oefIXHw as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡏࡄࡗࡆ࡜ࡉࡅࡇࡒࠫ၍")	:	from Uqu6CKd9Hp		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rr7Xolsp4JwjPK3L(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ၎")	:	from cYuti2ydov			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rr7Xolsp4JwjPK3L(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ၏")	:	from AD62PQ4gWj			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡕࡇࡎࡆࡖࠪၐ")		:	from VpQ2IGhF6u			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rxWDdRBIct57i90s(u"ࠬࡗࡆࡊࡎࡐࠫၑ")		:	from XYdx0ZKPTL			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iqHhJSxdaANDG5rlZm7B(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪၒ"):	from nnK4UgS0XM		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪၓ")	:	from PabNtdGAxg		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==yiaeCEwJjOcWA4ZSd5h(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪၔ")	:	from CCOzBEyRvg		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==cJSNFCIhymEfx6grGu0M(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ၕ"):	from ePXAlKd1b3		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==iqHhJSxdaANDG5rlZm7B(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ၖ")	:	from rrRxdsjcvG		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡘࡎࡏࡇࡊࡄࠫၗ")	:	from YZx3WrXdtJ			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==jR9YtmsgDX8nTQlMb6G3(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧၘ")	:	from cUw0nzSrsP		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==rr7Xolsp4JwjPK3L(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨၙ")	:	from pmvfK280zt		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩၚ")	:	from uhNyoqjf65		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==EHUAyW2lQfe4LXmhgIGc(u"ࠨࡖࡌࡏࡆࡇࡔࠨၛ")	:	from tTDElSi9qn			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡗ࡚ࡋ࡛ࡎࠨၜ")		:	from MMS8IfhQvJ			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࡚ࠪࡆࡘࡂࡐࡐࠪၝ")	:	from RbeOjlTzQI			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==cJSNFCIhymEfx6grGu0M(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨၞ"):	from Jjx3ro6wm9		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==RVpeGcmPxj9tCnT40Nf216(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ၟ")	:	from B3EeC061Fy		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧၠ")	:	from cJDB5O9ZsN		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡚ࠧࡃࡔࡓ࡙࠭ၡ")		:	from TT5kAXZFOI			import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩၢ")	:	from HJQMP045Ze		import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	elif WWlx4Byhe182uF7YivmCGIJL==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨၣ"):	from zkVFcnjCRB	import hXz0OvlBbVLste3xWE6C74 as oyuFxk4Vew5cHP16,b6WZDnA0dLBiCITrF37OS as PYymEzqnMT0it36kHG,TdtCLWYSJNK8zOb as P8Pqs0UvEBg2AfmXDK6C
	return oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C
def A7AmGFnBgYU63Dyl2hv4cP(n8UgVdcQvbfW1TGLRoMs,m4iYHG1j9Cg6U7VEp,showDialogs):
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨၤ")+n8UgVdcQvbfW1TGLRoMs+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧၥ")+str(m4iYHG1j9Cg6U7VEp)+VHrIziKUDuNGXkMla(u"ࠬࠦ࡝ࠨၦ"))
	HofqU5Wsa9 = dWO9bFPCYXVDrcU81xN5kJ23laR()
	HofqU5Wsa9.create(iqHhJSxdaANDG5rlZm7B(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၧ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩၨ"))
	xow215zFbEDBRei9qONlUH3nCy = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠱࠱࠴࠷ᒐ")*RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠱࠱࠴࠷ᒐ")
	DJXWYLguhrTH9 = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠲ᒑ")*xow215zFbEDBRei9qONlUH3nCy
	import requests as MMEFXQfRHgZI3VSo4nrP57ypaLY
	DD1ExCgnvNZhY7Acwpq6yeTSmz = MMEFXQfRHgZI3VSo4nrP57ypaLY.get(n8UgVdcQvbfW1TGLRoMs,stream=P5VqbRSzjtO4UE1rZaolG67XA,headers=m4iYHG1j9Cg6U7VEp)
	SQx4h56e3trmX8NHfUw9us1DRy = DD1ExCgnvNZhY7Acwpq6yeTSmz.headers
	DD1ExCgnvNZhY7Acwpq6yeTSmz.close()
	ALTIWPVhlpgv3NDGOfck7sESMqd8 = bytes()
	if not SQx4h56e3trmX8NHfUw9us1DRy:
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫၩ"),cjbAkCIinvs(u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฬ่็๋ࠦๅ็ࠢอั๊๐ไࠡษ็้้็ࠠศๆ่฻้๎ศ๊ࠡสุ่ฮศࠡไาࠤ๏้่็ࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮ࠡฮิฬࠥะอๆ์็ࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠬၪ"))
		HofqU5Wsa9.close()
	else:
		if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫၫ") not in list(SQx4h56e3trmX8NHfUw9us1DRy.keys()): VlQGS7gnFom8tXTv0YsMWf9rhzPDa = dQ5JhEYolPmy1fvHktMw6NFRxiz
		else: VlQGS7gnFom8tXTv0YsMWf9rhzPDa = int(SQx4h56e3trmX8NHfUw9us1DRy[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬၬ")])
		wcEdUAlhtZbpPDr8j = str(int(yiaeCEwJjOcWA4ZSd5h(u"࠴࠴࠵࠶ᒓ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa/xow215zFbEDBRei9qONlUH3nCy)/VHrIziKUDuNGXkMla(u"࠳࠳࠴࠵࠴࠰ᒒ"))
		bFeqxjOi508KPZlw6IuGzUyfNadTSg = int(VlQGS7gnFom8tXTv0YsMWf9rhzPDa/DJXWYLguhrTH9)+fdQOo6Hu4B5Rbg
		if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬၭ") in list(SQx4h56e3trmX8NHfUw9us1DRy.keys()) and VlQGS7gnFom8tXTv0YsMWf9rhzPDa>xow215zFbEDBRei9qONlUH3nCy:
			DsgFwxVXSp7JjyRv6 = P5VqbRSzjtO4UE1rZaolG67XA
			StdixW1QOyqcr2mBIz0s45nJ = []
			auNtB09fnCc3MjFYxRk = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠵࠵ᒔ")
			StdixW1QOyqcr2mBIz0s45nJ.append(str(dQ5JhEYolPmy1fvHktMw6NFRxiz*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+VHrIziKUDuNGXkMla(u"࠭࠭ࠨၮ")+str(fdQOo6Hu4B5Rbg*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(fdQOo6Hu4B5Rbg*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+qTVF3icWwGXy5(u"ࠧ࠮ࠩၯ")+str(SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+iAGgjwb7tVMmacRJ(u"ࠨ࠯ࠪၰ")+str(c1R9fnIY4XBDZ*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(c1R9fnIY4XBDZ*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+ETNq5t4MYngSsbfFD8J0v(u"ࠩ࠰ࠫၱ")+str(xsCEkXb6tgrh3195YZ*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(xsCEkXb6tgrh3195YZ*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪ࠱ࠬၲ")+str(ETNq5t4MYngSsbfFD8J0v(u"࠺ᒕ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(t2sCrJ0xbgDRkf(u"࠻ᒖ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+t2sCrJ0xbgDRkf(u"ࠫ࠲࠭ၳ")+str(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠶ᒗ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(jR9YtmsgDX8nTQlMb6G3(u"࠸ᒙ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+RVpeGcmPxj9tCnT40Nf216(u"ࠬ࠳ࠧၴ")+str(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠸ᒘ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(rr7Xolsp4JwjPK3L(u"࠻ᒛ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࠭ࠨၵ")+str(FWqeEzO1i8Dn0ga(u"࠻ᒚ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠾ᒝ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+UighHKAfySm4PWErqJ(u"ࠧ࠮ࠩၶ")+str(cJSNFCIhymEfx6grGu0M(u"࠾ᒜ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk-fdQOo6Hu4B5Rbg))
			StdixW1QOyqcr2mBIz0s45nJ.append(str(VHrIziKUDuNGXkMla(u"࠹ᒞ")*VlQGS7gnFom8tXTv0YsMWf9rhzPDa//auNtB09fnCc3MjFYxRk)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨ࠯ࠪၷ"))
			lk2MIdAXB1KYOFEV5PoUjLu = float(bFeqxjOi508KPZlw6IuGzUyfNadTSg)/auNtB09fnCc3MjFYxRk
			RR3QKvHk79weMZf2orFTCbP = lk2MIdAXB1KYOFEV5PoUjLu/int(fdQOo6Hu4B5Rbg+lk2MIdAXB1KYOFEV5PoUjLu)
		else:
			DsgFwxVXSp7JjyRv6 = kkMuQrLWcEayRm
			auNtB09fnCc3MjFYxRk = fdQOo6Hu4B5Rbg
			RR3QKvHk79weMZf2orFTCbP = fdQOo6Hu4B5Rbg
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,rxWDdRBIct57i90s(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪၸ")+str(DsgFwxVXSp7JjyRv6)+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࠤࡢࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬၹ")+str(VlQGS7gnFom8tXTv0YsMWf9rhzPDa)+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࠥࡣࠧၺ"))
		p0p6MxKbklodNCR92Wv,LLewk6fUs5TINgndGBv = dQ5JhEYolPmy1fvHktMw6NFRxiz,dQ5JhEYolPmy1fvHktMw6NFRxiz
		for OyIA1vwqgV4 in range(auNtB09fnCc3MjFYxRk):
			AAFEPhnMlsH5B3z0gYQWD4j7kUc = m4iYHG1j9Cg6U7VEp.copy()
			if DsgFwxVXSp7JjyRv6: AAFEPhnMlsH5B3z0gYQWD4j7kUc[dC3PsQJ0Ti28uYlov(u"ࠬࡘࡡ࡯ࡩࡨࠫၻ")] = FWqeEzO1i8Dn0ga(u"࠭ࡢࡺࡶࡨࡷࡂ࠭ၼ")+StdixW1QOyqcr2mBIz0s45nJ[OyIA1vwqgV4]
			DD1ExCgnvNZhY7Acwpq6yeTSmz = MMEFXQfRHgZI3VSo4nrP57ypaLY.get(n8UgVdcQvbfW1TGLRoMs,stream=P5VqbRSzjtO4UE1rZaolG67XA,headers=AAFEPhnMlsH5B3z0gYQWD4j7kUc,timeout=rr7Xolsp4JwjPK3L(u"࠴࠲࠳ᒟ"))
			for BZ9CDdyORc4SeMVlPv in DD1ExCgnvNZhY7Acwpq6yeTSmz.iter_content(chunk_size=DJXWYLguhrTH9):
				if HofqU5Wsa9.iscanceled():
					vvqQRbuChP(oz95q0dcEtSuxIJgP841M,EHUAyW2lQfe4LXmhgIGc(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧၽ"))
					break
				p0p6MxKbklodNCR92Wv += RR3QKvHk79weMZf2orFTCbP
				ALTIWPVhlpgv3NDGOfck7sESMqd8 += BZ9CDdyORc4SeMVlPv
				if not LLewk6fUs5TINgndGBv: LLewk6fUs5TINgndGBv = len(BZ9CDdyORc4SeMVlPv)
				if VlQGS7gnFom8tXTv0YsMWf9rhzPDa: CigEOdTqom6Gw5nta(HofqU5Wsa9,jR9YtmsgDX8nTQlMb6G3(u"࠳࠳࠴ᒠ")*p0p6MxKbklodNCR92Wv//bFeqxjOi508KPZlw6IuGzUyfNadTSg,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩၾ"),str(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠴࠴࠵࠴࠰ᒡ")*LLewk6fUs5TINgndGBv*p0p6MxKbklodNCR92Wv//DJXWYLguhrTH9//RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠴࠴࠵࠴࠰ᒡ"))+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࠣ࠳ࠥ࠭ၿ")+wcEdUAlhtZbpPDr8j+FWqeEzO1i8Dn0ga(u"ࠪࠤࡒࡈࠧႀ"))
				else: CigEOdTqom6Gw5nta(HofqU5Wsa9,LLewk6fUs5TINgndGBv*p0p6MxKbklodNCR92Wv//DJXWYLguhrTH9,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩႁ"),str(iqHhJSxdaANDG5rlZm7B(u"࠵࠵࠶࠮࠱ᒢ")*LLewk6fUs5TINgndGBv*p0p6MxKbklodNCR92Wv//DJXWYLguhrTH9//iqHhJSxdaANDG5rlZm7B(u"࠵࠵࠶࠮࠱ᒢ"))+qTVF3icWwGXy5(u"ࠬࠦࡍࡃࠩႂ"))
			DD1ExCgnvNZhY7Acwpq6yeTSmz.close()
		HofqU5Wsa9.close()
		if len(ALTIWPVhlpgv3NDGOfck7sESMqd8)<VlQGS7gnFom8tXTv0YsMWf9rhzPDa and VlQGS7gnFom8tXTv0YsMWf9rhzPDa>dQ5JhEYolPmy1fvHktMw6NFRxiz:
			vvqQRbuChP(oz95q0dcEtSuxIJgP841M,EHUAyW2lQfe4LXmhgIGc(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩႃ")+str(len(ALTIWPVhlpgv3NDGOfck7sESMqd8)//xow215zFbEDBRei9qONlUH3nCy)+RVpeGcmPxj9tCnT40Nf216(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬႄ")+wcEdUAlhtZbpPDr8j+iAGgjwb7tVMmacRJ(u"ࠨࠢࡐࡆࠥࡣࠧႅ"))
			CorYkXhAmuvNR9SDZTJz = YZL469QjvSV(G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩศ่฿อม๊ࠡัีําࠧႆ"),RVpeGcmPxj9tCnT40Nf216(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪႇ"),cJSNFCIhymEfx6grGu0M(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭ႈ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႉ"),EHUAyW2lQfe4LXmhgIGc(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪႊ")+str(len(ALTIWPVhlpgv3NDGOfck7sESMqd8)//xow215zFbEDBRei9qONlUH3nCy)+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭ႋ")+wcEdUAlhtZbpPDr8j+DTF3Lwy9etRH8mI(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪႌ"))
			if CorYkXhAmuvNR9SDZTJz==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: ALTIWPVhlpgv3NDGOfck7sESMqd8 = A7AmGFnBgYU63Dyl2hv4cP(n8UgVdcQvbfW1TGLRoMs,m4iYHG1j9Cg6U7VEp,showDialogs)
			elif CorYkXhAmuvNR9SDZTJz==fdQOo6Hu4B5Rbg: vvqQRbuChP(oz95q0dcEtSuxIJgP841M,iAGgjwb7tVMmacRJ(u"ࠩ࠱ࡠࡹࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨႍ"))
			else: return G9G0YqivIfmUWO8K
			if not ALTIWPVhlpgv3NDGOfck7sESMqd8: return G9G0YqivIfmUWO8K
		else: vvqQRbuChP(oz95q0dcEtSuxIJgP841M,iqHhJSxdaANDG5rlZm7B(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧႎ")+wcEdUAlhtZbpPDr8j+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠥࡓࡂࠡ࡟ࠪႏ"))
	return ALTIWPVhlpgv3NDGOfck7sESMqd8
def aVOXjmfZiq1hcsptH2dL8zWxPkAKJE(s5slfAmHkUtMR3WSKY1ZTX):
	return DD1ExCgnvNZhY7Acwpq6yeTSmz
def veFOcmHqAr1jfz(ip=G9G0YqivIfmUWO8K):
	global ttWSxEM3Gp
	if ttWSxEM3Gp: return ttWSxEM3Gp
	sReJ67XGjpxonzCQy4iFSmaZwNOv,JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA,MJBzOIqCdQ47aNAG,RAbmyxr0TtFu5nIGz6LEisQOWwU,ihWm4BxVI1QlHpf9gaMCnq,GZsi1o5pDvnOHxyqEtJ = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	yzieWRVX4nkB3DjGHJphEdQo = jR9YtmsgDX8nTQlMb6G3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ႐")+ip+FWqeEzO1i8Dn0ga(u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ႑")
	m4iYHG1j9Cg6U7VEp = {wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ႒"):G9G0YqivIfmUWO8K}
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cJSNFCIhymEfx6grGu0M(u"ࠨࡉࡈࡘࠬ႓"),yzieWRVX4nkB3DjGHJphEdQo,G9G0YqivIfmUWO8K,m4iYHG1j9Cg6U7VEp,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ႔"))
	if not DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		yzieWRVX4nkB3DjGHJphEdQo = t2sCrJ0xbgDRkf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵ࠳ࡡࡱ࡫࠱ࡧࡴࡳ࠯࡫ࡵࡲࡲ࠴࠭႕")+ip+VHrIziKUDuNGXkMla(u"ࠫࡄ࡬ࡩࡦ࡮ࡧࡷࡂࡷࡵࡦࡴࡼ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧ࠯ࡧ࡮ࡺࡹ࠭ࡱࡩࡪࡸ࡫ࡴࠨ႖")
		DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡍࡅࡕࠩ႗"),yzieWRVX4nkB3DjGHJphEdQo,G9G0YqivIfmUWO8K,m4iYHG1j9Cg6U7VEp,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠸࡮ࡥࠩ႘"))
	if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		GagwMT6q3oc7UZ2Q = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
		qHW7xG3kJXnh4S = EEMsy4SLwnD0T92ztchdIUZ.loads(GagwMT6q3oc7UZ2Q)
		PBRaO4AuJrSfdnqtQ = list(qHW7xG3kJXnh4S.keys())
		if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡪࡲࠪ႙") in PBRaO4AuJrSfdnqtQ: ip = qHW7xG3kJXnh4S[ssGdubC4mngM9D5SRc3Ye(u"ࠨ࡫ࡳࠫႚ")]
		if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬႛ") in PBRaO4AuJrSfdnqtQ: sReJ67XGjpxonzCQy4iFSmaZwNOv = qHW7xG3kJXnh4S[DTF3Lwy9etRH8mI(u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭ႜ")]
		if VHrIziKUDuNGXkMla(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬႝ") in PBRaO4AuJrSfdnqtQ: JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA = qHW7xG3kJXnh4S[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭႞")]
		if cjbAkCIinvs(u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ႟") in PBRaO4AuJrSfdnqtQ: MJBzOIqCdQ47aNAG = qHW7xG3kJXnh4S[t2sCrJ0xbgDRkf(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭Ⴀ")]
		if iqHhJSxdaANDG5rlZm7B(u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨႡ") in PBRaO4AuJrSfdnqtQ: RAbmyxr0TtFu5nIGz6LEisQOWwU = qHW7xG3kJXnh4S[UighHKAfySm4PWErqJ(u"ࠩࡵࡩ࡬࡯࡯࡯ࠩႢ")]
		if jR9YtmsgDX8nTQlMb6G3(u"ࠪࡧ࡮ࡺࡹࠨႣ") in PBRaO4AuJrSfdnqtQ: ihWm4BxVI1QlHpf9gaMCnq = qHW7xG3kJXnh4S[bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡨ࡯ࡴࡺࠩႤ")]
		if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡷࡵࡦࡴࡼࠫႥ") in PBRaO4AuJrSfdnqtQ: ip = qHW7xG3kJXnh4S[cJSNFCIhymEfx6grGu0M(u"࠭ࡱࡶࡧࡵࡽࠬႦ")]
		if VHrIziKUDuNGXkMla(u"ࠧࡤࡱࡸࡲࡹࡸࡹࡄࡱࡧࡩࠬႧ") in PBRaO4AuJrSfdnqtQ: MJBzOIqCdQ47aNAG = qHW7xG3kJXnh4S[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡅࡲࡨࡪ࠭Ⴈ")]
		if VHrIziKUDuNGXkMla(u"ࠩࡵࡩ࡬࡯࡯࡯ࡐࡤࡱࡪ࠭Ⴉ") in PBRaO4AuJrSfdnqtQ: RAbmyxr0TtFu5nIGz6LEisQOWwU = qHW7xG3kJXnh4S[rxWDdRBIct57i90s(u"ࠪࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠧႪ")]
		if EHUAyW2lQfe4LXmhgIGc(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭Ⴋ") in PBRaO4AuJrSfdnqtQ:
			GZsi1o5pDvnOHxyqEtJ = qHW7xG3kJXnh4S[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧႬ")][ssGdubC4mngM9D5SRc3Ye(u"࠭ࡵࡵࡥࠪႭ")]
			if GZsi1o5pDvnOHxyqEtJ[dQ5JhEYolPmy1fvHktMw6NFRxiz] not in [VHrIziKUDuNGXkMla(u"ࠧ࠮ࠩႮ"),DTF3Lwy9etRH8mI(u"ࠨ࠭ࠪႯ")]: GZsi1o5pDvnOHxyqEtJ = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࠮ࠫႰ")+GZsi1o5pDvnOHxyqEtJ
		if t2sCrJ0xbgDRkf(u"ࠪࡳ࡫࡬ࡳࡦࡶࠪႱ") in PBRaO4AuJrSfdnqtQ:
			GZsi1o5pDvnOHxyqEtJ = qHW7xG3kJXnh4S[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡴ࡬ࡦࡴࡧࡷࠫႲ")]
			if GZsi1o5pDvnOHxyqEtJ>=UighHKAfySm4PWErqJ(u"࠵ᒣ"): GZsi1o5pDvnOHxyqEtJ = UighHKAfySm4PWErqJ(u"ࠬ࠱ࠧႳ")+SSCU3jdyFn2V.strftime(FWqeEzO1i8Dn0ga(u"ࠨࠥࡉ࠼ࠨࡑࠧႴ"),SSCU3jdyFn2V.gmtime(GZsi1o5pDvnOHxyqEtJ))
			else: GZsi1o5pDvnOHxyqEtJ = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ࠮ࠩႵ")+SSCU3jdyFn2V.strftime(bneABYmwFUH8GXphg0Kl2Sq(u"ࠣࠧࡋ࠾ࠪࡓࠢႶ"),SSCU3jdyFn2V.gmtime(-GZsi1o5pDvnOHxyqEtJ))
	ttWSxEM3Gp = ip+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩ࠯ࠫႷ")+sReJ67XGjpxonzCQy4iFSmaZwNOv+DTF3Lwy9etRH8mI(u"ࠪ࠰ࠬႸ")+JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA+ETNq5t4MYngSsbfFD8J0v(u"ࠫ࠱࠭Ⴙ")+RAbmyxr0TtFu5nIGz6LEisQOWwU+cJSNFCIhymEfx6grGu0M(u"ࠬ࠲ࠧႺ")+ihWm4BxVI1QlHpf9gaMCnq+cjbAkCIinvs(u"࠭ࠬࠨႻ")+GZsi1o5pDvnOHxyqEtJ
	ttWSxEM3Gp = ttWSxEM3Gp.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	if LTze51miOknVcslNF43WSA6vMjYZt: ttWSxEM3Gp = ttWSxEM3Gp.decode(EHUAyW2lQfe4LXmhgIGc(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨႼ"))
	ttWSxEM3Gp = zDBtm4MwIagkfcpE5oxJOAq6lZQY(ttWSxEM3Gp)
	return ttWSxEM3Gp
def bY6tjyS08hUC(E1E6VxONrDKZc9eSkRs):
	SA9b8FjHWCBomEqhkrxpgv,showDialogs = G9G0YqivIfmUWO8K,P5VqbRSzjtO4UE1rZaolG67XA
	if E1E6VxONrDKZc9eSkRs.count(qTVF3icWwGXy5(u"ࠨࡡࠪႽ"))>=SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:
		E1E6VxONrDKZc9eSkRs,SA9b8FjHWCBomEqhkrxpgv = E1E6VxONrDKZc9eSkRs.split(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡢࠫႾ"),fdQOo6Hu4B5Rbg)
		SA9b8FjHWCBomEqhkrxpgv = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡣࠬႿ")+SA9b8FjHWCBomEqhkrxpgv
		if rxWDdRBIct57i90s(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩჀ") in SA9b8FjHWCBomEqhkrxpgv: showDialogs = kkMuQrLWcEayRm
		else: showDialogs = P5VqbRSzjtO4UE1rZaolG67XA
	return E1E6VxONrDKZc9eSkRs,SA9b8FjHWCBomEqhkrxpgv,showDialogs
def af4TRecYZQ5WCOdkLKhtqJxpsHFmP():
	QcIUaMfd1XNsuwTJDpySBrOE5047 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫჁ"))
	kkhj8Ds0OuTBZJRmNFl9IHd = dQ5JhEYolPmy1fvHktMw6NFRxiz
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(QcIUaMfd1XNsuwTJDpySBrOE5047):
		for zsZJaB5qojX42KcD in ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(QcIUaMfd1XNsuwTJDpySBrOE5047):
			if cJSNFCIhymEfx6grGu0M(u"࠭࠮ࡱࡻࡲࠫჂ") in zsZJaB5qojX42KcD: continue
			if cjbAkCIinvs(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬჃ") in zsZJaB5qojX42KcD: continue
			pprwfZdSi1xgh0KNTG = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(QcIUaMfd1XNsuwTJDpySBrOE5047,zsZJaB5qojX42KcD)
			CHQs9yVjAI1f2LY7ekmZU,d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6 = OSNKd3Zsh4GgE(pprwfZdSi1xgh0KNTG)
			kkhj8Ds0OuTBZJRmNFl9IHd += CHQs9yVjAI1f2LY7ekmZU
	return kkhj8Ds0OuTBZJRmNFl9IHd
def YqSr2bj9TZxshFd(showDialogs):
	jjLzq9xJTOWB1A26KaFfX7dI = amx9qJHkhw7oLdtVMG3.getSetting(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭Ⴤ"))
	ppsbayQ6txfS = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡶࡸࡷ࠭Ⴥ"),qTVF3icWwGXy5(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭჆"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭Ⴧ"))
	bl1ouYNVMwne2PQiTyJ8WXsAkS,lorLq81mU4e5NHi9BKs6Y = jjLzq9xJTOWB1A26KaFfX7dI,ppsbayQ6txfS
	eeFx4KSVWzJmfun2Y7asLPR0kAj5,VTpb89g45da = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if fdQOo6Hu4B5Rbg:
		yzieWRVX4nkB3DjGHJphEdQo = Kkfl8xemuHbd1w3a0ABPcDrN[rxWDdRBIct57i90s(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ჈")][c1R9fnIY4XBDZ]
		tAPnOsC2Fi6WIRUdSQhJLclXHYTp = veFOcmHqAr1jfz()
		JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA = tAPnOsC2Fi6WIRUdSQhJLclXHYTp.split(bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࠬࠨ჉"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		kkhj8Ds0OuTBZJRmNFl9IHd = af4TRecYZQ5WCOdkLKhtqJxpsHFmP()
		nLi5fzKDxgcvMY0C3GUpedPSQ = {wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡶࡵࡨࡶࠬ჊"):iOtjqZ6Iydl,UighHKAfySm4PWErqJ(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ჋"):GBx0Fcf7sLbqlntEX3yMezu,dC3PsQJ0Ti28uYlov(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ჌"):JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪ࡭ࡩࡹࠧჍ"):FCV0wTRHopA2ljcvrP(kkhj8Ds0OuTBZJRmNFl9IHd)}
		DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡕࡕࡓࡕࠩ჎"),yzieWRVX4nkB3DjGHJphEdQo,nLi5fzKDxgcvMY0C3GUpedPSQ,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ჏"))
		if not DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
			if jjLzq9xJTOWB1A26KaFfX7dI in [G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡎࡆ࡙ࠪა")]: bl1ouYNVMwne2PQiTyJ8WXsAkS = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ბ")
			elif jjLzq9xJTOWB1A26KaFfX7dI==ssGdubC4mngM9D5SRc3Ye(u"ࠨࡑࡏࡈࠬგ"): bl1ouYNVMwne2PQiTyJ8WXsAkS = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨდ")
		else:
			lw2vyKtRiLnfx3qk6OESXBh4dFb = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
			lw2vyKtRiLnfx3qk6OESXBh4dFb = bRCSwcA89e4J7pqdays5PxGiD2(EHUAyW2lQfe4LXmhgIGc(u"ࠪࡰ࡮ࡹࡴࠨე"),lw2vyKtRiLnfx3qk6OESXBh4dFb)
			lw2vyKtRiLnfx3qk6OESXBh4dFb = sorted(lw2vyKtRiLnfx3qk6OESXBh4dFb,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: int(key[dQ5JhEYolPmy1fvHktMw6NFRxiz]))
			VTpb89g45da,lorLq81mU4e5NHi9BKs6Y = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
			for vm1RFZMclUqQfNO8dKJrx0WI,mBnDZt7xuWpC,n1rcMdD6CB8ie3lFqTW in lw2vyKtRiLnfx3qk6OESXBh4dFb:
				if vm1RFZMclUqQfNO8dKJrx0WI==ETNq5t4MYngSsbfFD8J0v(u"ࠫ࠵࠭ვ"):
					VTpb89g45da += n1rcMdD6CB8ie3lFqTW+cjbAkCIinvs(u"ࠬࡀ࠺ࠨზ")
					continue
				if lorLq81mU4e5NHi9BKs6Y: lorLq81mU4e5NHi9BKs6Y += zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬთ")+zzGfwLAyN5HTxUoJeaivY+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ࡝ࡰ࡟ࡲࠬი")
				irhcsd9YQDP4fGej6E = n1rcMdD6CB8ie3lFqTW.split(zEgtT9cR6bFp7JXqI5VuhNeP)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				HDaA1S9vRzgKeZUBm42q = qTVF3icWwGXy5(u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬკ") if mBnDZt7xuWpC else G9G0YqivIfmUWO8K
				lorLq81mU4e5NHi9BKs6Y += n1rcMdD6CB8ie3lFqTW.replace(irhcsd9YQDP4fGej6E,ipjCIhwEXsbadR+irhcsd9YQDP4fGej6E+HDaA1S9vRzgKeZUBm42q+zzGfwLAyN5HTxUoJeaivY)+zEgtT9cR6bFp7JXqI5VuhNeP
			lorLq81mU4e5NHi9BKs6Y = zEgtT9cR6bFp7JXqI5VuhNeP+lorLq81mU4e5NHi9BKs6Y+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࡟ࡲࡡࡴࠧლ")
			VTpb89g45da = VTpb89g45da.strip(rr7Xolsp4JwjPK3L(u"ࠪ࠾࠿࠭მ"))
			eeFx4KSVWzJmfun2Y7asLPR0kAj5 = amx9qJHkhw7oLdtVMG3.getSetting(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧნ"))
			if lorLq81mU4e5NHi9BKs6Y==ppsbayQ6txfS and jjLzq9xJTOWB1A26KaFfX7dI in [EHUAyW2lQfe4LXmhgIGc(u"ࠬࡕࡌࡅࠩო"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬპ")]: bl1ouYNVMwne2PQiTyJ8WXsAkS = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡐࡎࡇࠫჟ")
			else: bl1ouYNVMwne2PQiTyJ8WXsAkS = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡐࡈ࡛ࠬრ")
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,ETNq5t4MYngSsbfFD8J0v(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬს"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬტ"),lorLq81mU4e5NHi9BKs6Y,UKDwMTZk9dni1JSLcf0oRXhqy)
			amx9qJHkhw7oLdtVMG3.setSetting(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬუ"),FCV0wTRHopA2ljcvrP(AVeHPW5shuXLdr2vwD))
			amx9qJHkhw7oLdtVMG3.setSetting(DTF3Lwy9etRH8mI(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨფ"),VTpb89g45da)
			k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠻ᒤ")*VTpb89g45da.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
			k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(jR9YtmsgDX8nTQlMb6G3(u"࠱࠵ᒥ")*k1kV8SlEacW69.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
			k1kV8SlEacW69 = QzHB32naPjOLJ46.md5(FWqeEzO1i8Dn0ga(u"࠲࠻ᒦ")*k1kV8SlEacW69.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()
			amx9qJHkhw7oLdtVMG3.setSetting(qTVF3icWwGXy5(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠳ࠩქ"),k1kV8SlEacW69)
	if showDialogs:
		if bl1ouYNVMwne2PQiTyJ8WXsAkS in [ssGdubC4mngM9D5SRc3Ye(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ღ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧყ")]:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬშ"),iAGgjwb7tVMmacRJ(u"๋๋ࠪอใࠡ็ื็้ฯࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํะ่ࠢสฺ่๊ใๅหࠣๆิ๊ࠦไ๊้ࠤุฮศ่ษࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣห้ืว้ฬิࠤฬ๊ฮศืࠣฬ่ࠦรุ้่่๊ࠢษࠡใํࠤฬ๊ริๆส็ࠥ฿ๆะๅࠪჩ"))
		else:
			tg6EQSH7P4(cjbAkCIinvs(u"ࠫࡷ࡯ࡧࡩࡶࠪც"),ssGdubC4mngM9D5SRc3Ye(u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨძ"),lorLq81mU4e5NHi9BKs6Y,t2sCrJ0xbgDRkf(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧწ"))
			bl1ouYNVMwne2PQiTyJ8WXsAkS = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡐࡎࡇࠫჭ")
	if bl1ouYNVMwne2PQiTyJ8WXsAkS!=jjLzq9xJTOWB1A26KaFfX7dI:
		amx9qJHkhw7oLdtVMG3.setSetting(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ხ"),bl1ouYNVMwne2PQiTyJ8WXsAkS)
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	AdD79jrMkm3 = P5VqbRSzjtO4UE1rZaolG67XA if VTpb89g45da!=eeFx4KSVWzJmfun2Y7asLPR0kAj5 else kkMuQrLWcEayRm
	if AdD79jrMkm3:
		dL81kZyMJI4t0CsE2fziw = iKLYEvx39c.w0Zn3BsVo7GWDyuli
		iKLYEvx39c.t6Xn5IBwJPG0so47MEif,iKLYEvx39c.w0Zn3BsVo7GWDyuli,iKLYEvx39c.b7sHudTqiWcg51n9IlXJ0BzAa,iKLYEvx39c.kqWwuhJS1K3gIvpbQnGRcfl0C = kWUE5INdVuX9wSOFsnZ([RVpeGcmPxj9tCnT40Nf216(u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪჯ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫჰ"),jR9YtmsgDX8nTQlMb6G3(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡛ࡒࡗࡐࡘࡗ࡚࠻ࡈ࡙ࠩჱ"),EHUAyW2lQfe4LXmhgIGc(u"ࠬࡕࡔ࠲࠻ࡍ࡙࠵ࡾࡂࡕࡗ࡯ࡈ࡝࠭ჲ")])
		xu4zVOINsMlbUWLGcAC = iKLYEvx39c.w0Zn3BsVo7GWDyuli
		if not dL81kZyMJI4t0CsE2fziw and xu4zVOINsMlbUWLGcAC and vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫჳ") in IIHKo82wPrNpgqCkQJOV:
			IIHKo82wPrNpgqCkQJOV.remove(rr7Xolsp4JwjPK3L(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬჴ"))
			IIHKo82wPrNpgqCkQJOV.append(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪჵ"))
		elif dL81kZyMJI4t0CsE2fziw and not xu4zVOINsMlbUWLGcAC and cjbAkCIinvs(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫჶ") in IIHKo82wPrNpgqCkQJOV:
			IIHKo82wPrNpgqCkQJOV.remove(iAGgjwb7tVMmacRJ(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬჷ"))
			IIHKo82wPrNpgqCkQJOV.append(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘࡥࡔࡔࠩჸ"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def bbLMfWytx9laFd41(DDBtZjzny37,c6hqJUlZmCTpnB):
	from socket import socket as Uj57k9GZzYH3oh4inb,AF_INET as hN15RTFGmxM47slPe2EXdIwyZzWn,SOCK_STREAM as jj2MqvQzkZB6eSbGYml3WOUhFpKas
	hs4MFckRBjAONKaw = Uj57k9GZzYH3oh4inb(hN15RTFGmxM47slPe2EXdIwyZzWn,jj2MqvQzkZB6eSbGYml3WOUhFpKas)
	hs4MFckRBjAONKaw.settimeout(fdQOo6Hu4B5Rbg)
	L7saIgqHGDxmkRl8hAr3Y6NFWpfy,F7K8laN1nV = P5VqbRSzjtO4UE1rZaolG67XA,dQ5JhEYolPmy1fvHktMw6NFRxiz
	ONEZrIFzqkX1no = SSCU3jdyFn2V.time()
	try: hs4MFckRBjAONKaw.connect((DDBtZjzny37,c6hqJUlZmCTpnB))
	except: L7saIgqHGDxmkRl8hAr3Y6NFWpfy = kkMuQrLWcEayRm
	KKtnT8wFmZXUxoIlgu5y6 = SSCU3jdyFn2V.time()
	if L7saIgqHGDxmkRl8hAr3Y6NFWpfy: F7K8laN1nV = KKtnT8wFmZXUxoIlgu5y6-ONEZrIFzqkX1no
	return F7K8laN1nV
def CU83wctmZIMAaxHv(showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨჹ"),iqHhJSxdaANDG5rlZm7B(u"࠭ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤ฾๋ไ๋หࠣห้ะๆู์ไࠤฬ๊ย็ࠢยࠥࠬჺ"))
	else: J8UB4bgrawlyzjYXA759Ee1c0N2fd = P5VqbRSzjtO4UE1rZaolG67XA
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg:
		for zsZJaB5qojX42KcD in ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(ZwIThN17YKVQnbp52gX):
			if zsZJaB5qojX42KcD.endswith(cjbAkCIinvs(u"ࠧ࠯ࡦࡥࠫ჻")) and hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡦࡤࡸࡦ࠭ჼ") in zsZJaB5qojX42KcD:
				oUMr9z6kD8Ht20XVAifdYJuhOgs = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,zsZJaB5qojX42KcD)
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c = JPlczjbGwnL6yapMuK(oUMr9z6kD8Ht20XVAifdYJuhOgs)
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(UighHKAfySm4PWErqJ(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡩࡳࡷ࡫ࡩࡨࡰࡢ࡯ࡪࡿࡳ࠾ࡰࡲ࠿ࠬჽ"))
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(rr7Xolsp4JwjPK3L(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡸࡪࡳࡰࡠࡵࡷࡳࡷ࡫࠽ࡎࡇࡐࡓࡗ࡟࠻ࠨჾ"))
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧჿ"))
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(iAGgjwb7tVMmacRJ(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨᄀ"))
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧᄁ"))
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n.commit()
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄂ"),ssGdubC4mngM9D5SRc3Ye(u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩᄃ"))
	return
def ggGCyoxkHXwif(mPqswd359vATtVZ,rUuhQYBpVRjfcKe,showDialogs):
	if mPqswd359vATtVZ!=None:
		global m0ijDc8uwEGXxU1
		m0ijDc8uwEGXxU1 = mPqswd359vATtVZ
	if rUuhQYBpVRjfcKe!=None:
		global pkAM4Z8ch6TJY
		pkAM4Z8ch6TJY = rUuhQYBpVRjfcKe
	if showDialogs!=None:
		global voQk40gmzx3UBaTnyMlEKSfLVJA
		voQk40gmzx3UBaTnyMlEKSfLVJA = showDialogs
	return
def HHAjQYS3EvxuoyG4c2b(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,data,headers,allow_redirects,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu,kUAmTPh7SuOxdLrCi9):
	if showDialogs==G9G0YqivIfmUWO8K: ALuIKiVCBPqE = P5VqbRSzjtO4UE1rZaolG67XA if voQk40gmzx3UBaTnyMlEKSfLVJA==G9G0YqivIfmUWO8K else voQk40gmzx3UBaTnyMlEKSfLVJA
	else: ALuIKiVCBPqE = P5VqbRSzjtO4UE1rZaolG67XA if showDialogs else kkMuQrLWcEayRm
	if kUAmTPh7SuOxdLrCi9==G9G0YqivIfmUWO8K: yyU0dfH65vQGu = P5VqbRSzjtO4UE1rZaolG67XA if pkAM4Z8ch6TJY==G9G0YqivIfmUWO8K else pkAM4Z8ch6TJY
	else: yyU0dfH65vQGu = P5VqbRSzjtO4UE1rZaolG67XA if kUAmTPh7SuOxdLrCi9 else kkMuQrLWcEayRm
	if gp8MxzolmeB1IYhO6s0XRZFu==G9G0YqivIfmUWO8K: MSFOAi6yH9n8JeV3KWmpChagE5BPNo = P5VqbRSzjtO4UE1rZaolG67XA if m0ijDc8uwEGXxU1==G9G0YqivIfmUWO8K else m0ijDc8uwEGXxU1
	else: MSFOAi6yH9n8JeV3KWmpChagE5BPNo = P5VqbRSzjtO4UE1rZaolG67XA if gp8MxzolmeB1IYhO6s0XRZFu else kkMuQrLWcEayRm
	if allow_redirects==G9G0YqivIfmUWO8K: BlOvmjrZWVH7u = P5VqbRSzjtO4UE1rZaolG67XA
	else: BlOvmjrZWVH7u = P5VqbRSzjtO4UE1rZaolG67XA if allow_redirects else kkMuQrLWcEayRm
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {} if headers==G9G0YqivIfmUWO8K else headers
	pPIbdY3oKe = {} if data==G9G0YqivIfmUWO8K else data
	if XdoFLQ20O6SNVlcp==cjbAkCIinvs(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡎࡔࡓࡕࡃࡏࡐࡤࡕࡌࡅࡡࡕࡉࡑࡋࡁࡔࡇ࠰࠵ࡸࡺࠧᄄ"): AAFEPhnMlsH5B3z0gYQWD4j7kUc = {}
	else:
		dmFpA6Ls0Mb3rlB4SkXyT = list(AAFEPhnMlsH5B3z0gYQWD4j7kUc.keys())
		if ssGdubC4mngM9D5SRc3Ye(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᄅ") not in dmFpA6Ls0Mb3rlB4SkXyT: AAFEPhnMlsH5B3z0gYQWD4j7kUc[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᄆ")] = bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ࡮ࡴࡵࡲࠪᄇ")
		if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᄈ") not in dmFpA6Ls0Mb3rlB4SkXyT: AAFEPhnMlsH5B3z0gYQWD4j7kUc[rxWDdRBIct57i90s(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᄉ")] = uCUkPIYFszbV90wSpKqWNOjZ1687Eh(P5VqbRSzjtO4UE1rZaolG67XA)
	return urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,MSFOAi6yH9n8JeV3KWmpChagE5BPNo,yyU0dfH65vQGu
def zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu=G9G0YqivIfmUWO8K,kUAmTPh7SuOxdLrCi9=G9G0YqivIfmUWO8K):
	uRh0OfcrCjvt7LQEgk = HHAjQYS3EvxuoyG4c2b(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu,kUAmTPh7SuOxdLrCi9)
	urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,MSFOAi6yH9n8JeV3KWmpChagE5BPNo,yyU0dfH65vQGu = uRh0OfcrCjvt7LQEgk
	XXzvmn7ewM8yBfoxua,rQmWAsndP6cgJNT8iEM7yVzhla1UkC,CEuGyZ4rFkON2K7qJHfBxmgpvPAQX,rpnIyPil9WTCLE = IpXs8rqBAYFlfNg0wch46bia(yzieWRVX4nkB3DjGHJphEdQo)
	ALZsrP4M3TfRG9X1c7ENQKob = amx9qJHkhw7oLdtVMG3.getSetting(UighHKAfySm4PWErqJ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨᄊ"))
	ct6DoMTHzUEbp4sv1BGWyxrw = amx9qJHkhw7oLdtVMG3.getSetting(rxWDdRBIct57i90s(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᄋ"))
	M5o1e2cPaA4NO9viqIFUt7x3RblLg0 = amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᄌ"))
	SnpbfahEeYLF0O5itkArjTJIPu2 = [bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹࠧᄍ"),RVpeGcmPxj9tCnT40Nf216(u"ࠬࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪࠩᄎ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷࠫᄏ"),UighHKAfySm4PWErqJ(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺࠧᄐ"),yiaeCEwJjOcWA4ZSd5h(u"ࠨࡵࡦࡶࡦࡶࡥࡶࡲࠪᄑ"),cJSNFCIhymEfx6grGu0M(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳࠬᄒ")]
	JRnLE8F216uaZ4MQgIpzvc = P5VqbRSzjtO4UE1rZaolG67XA if any(yW70dtahIjkPCJg2TA in yzieWRVX4nkB3DjGHJphEdQo for yW70dtahIjkPCJg2TA in SnpbfahEeYLF0O5itkArjTJIPu2) else kkMuQrLWcEayRm
	if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࠪࡺࡸ࡬࠾ࠩᄓ") in XXzvmn7ewM8yBfoxua and JRnLE8F216uaZ4MQgIpzvc: fhF7vrH2Eal5Atu3iV1Rq89os = XXzvmn7ewM8yBfoxua.rsplit(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࠫࡻࡲ࡭࠿ࠪᄔ"),cjbAkCIinvs(u"࠳ᒧ"))[fdQOo6Hu4B5Rbg]
	else: fhF7vrH2Eal5Atu3iV1Rq89os = G9G0YqivIfmUWO8K
	cOzh5Dp3gLFYI7te = Kkfl8xemuHbd1w3a0ABPcDrN[yiaeCEwJjOcWA4ZSd5h(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᄕ")]
	UUThdmPcAVD4tx9SiHewME = XXzvmn7ewM8yBfoxua in cOzh5Dp3gLFYI7te or fhF7vrH2Eal5Atu3iV1Rq89os in cOzh5Dp3gLFYI7te
	uZo9jNYT7tGUE6Jd4x0wql1hB = Kkfl8xemuHbd1w3a0ABPcDrN[cJSNFCIhymEfx6grGu0M(u"࠭ࡒࡆࡒࡒࡗࠬᄖ")]
	ndEP7f5ZtwGOKWghuVReL82c0 = XXzvmn7ewM8yBfoxua in uZo9jNYT7tGUE6Jd4x0wql1hB or fhF7vrH2Eal5Atu3iV1Rq89os in uZo9jNYT7tGUE6Jd4x0wql1hB
	KyuHEjzY93cpsIed8xa7TnfZioQ = UUThdmPcAVD4tx9SiHewME or ndEP7f5ZtwGOKWghuVReL82c0
	XM5lyWoecKEs1vuQgx = kkMuQrLWcEayRm
	Ltv8PQFqMWEY = P5VqbRSzjtO4UE1rZaolG67XA
	zrK6MFTlkBnqyvo = rQmWAsndP6cgJNT8iEM7yVzhla1UkC==None and CEuGyZ4rFkON2K7qJHfBxmgpvPAQX==None and not JRnLE8F216uaZ4MQgIpzvc
	if zrK6MFTlkBnqyvo and KyuHEjzY93cpsIed8xa7TnfZioQ:
		if UUThdmPcAVD4tx9SiHewME:
			KeVQHsTjPAg0xoBY6lW7yv = cOzh5Dp3gLFYI7te.index(XXzvmn7ewM8yBfoxua)
			WQpbTAq5IO7Sujn8rJfl = Kkfl8xemuHbd1w3a0ABPcDrN[cjbAkCIinvs(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫᄗ")][KeVQHsTjPAg0xoBY6lW7yv]
			ybOHG96WcPCBgqU3Z7K8STp24 = TMKgSsLYy0A429rkWvq[KeVQHsTjPAg0xoBY6lW7yv]
			if ybOHG96WcPCBgqU3Z7K8STp24==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪᄘ"): MSFOAi6yH9n8JeV3KWmpChagE5BPNo,yyU0dfH65vQGu,Ltv8PQFqMWEY = kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm
			elif ybOHG96WcPCBgqU3Z7K8STp24==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪᄙ"): XM5lyWoecKEs1vuQgx = P5VqbRSzjtO4UE1rZaolG67XA
		elif ndEP7f5ZtwGOKWghuVReL82c0:
			KeVQHsTjPAg0xoBY6lW7yv = uZo9jNYT7tGUE6Jd4x0wql1hB.index(XXzvmn7ewM8yBfoxua)
			WQpbTAq5IO7Sujn8rJfl = Kkfl8xemuHbd1w3a0ABPcDrN[cjbAkCIinvs(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭ᄚ")][KeVQHsTjPAg0xoBY6lW7yv]
			ybOHG96WcPCBgqU3Z7K8STp24 = RvGE4rQKubUyZSa[KeVQHsTjPAg0xoBY6lW7yv]
	if CEuGyZ4rFkON2K7qJHfBxmgpvPAQX==G9G0YqivIfmUWO8K: CEuGyZ4rFkON2K7qJHfBxmgpvPAQX = ALZsrP4M3TfRG9X1c7ENQKob
	elif CEuGyZ4rFkON2K7qJHfBxmgpvPAQX==None and ct6DoMTHzUEbp4sv1BGWyxrw in [rr7Xolsp4JwjPK3L(u"ࠫࡆ࡛ࡔࡐࠩᄛ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᄜ")] and MSFOAi6yH9n8JeV3KWmpChagE5BPNo: CEuGyZ4rFkON2K7qJHfBxmgpvPAQX = ALZsrP4M3TfRG9X1c7ENQKob
	if UUThdmPcAVD4tx9SiHewME or ndEP7f5ZtwGOKWghuVReL82c0: Hvui6ETwrexpG9zcs5Cl = bneABYmwFUH8GXphg0Kl2Sq(u"࠴࠹ᒨ")
	elif JRnLE8F216uaZ4MQgIpzvc: Hvui6ETwrexpG9zcs5Cl = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠺࠵ᒩ")
	elif XdoFLQ20O6SNVlcp in g3douDifIqHWVZ2AL9E6zScwR0OrG1: Hvui6ETwrexpG9zcs5Cl = DTF3Lwy9etRH8mI(u"࠶࠶ᒪ")
	elif XdoFLQ20O6SNVlcp==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᄝ"): Hvui6ETwrexpG9zcs5Cl = DTF3Lwy9etRH8mI(u"࠸࠰ᒫ")
	elif XdoFLQ20O6SNVlcp==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᄞ"): Hvui6ETwrexpG9zcs5Cl = VHrIziKUDuNGXkMla(u"࠲࠱ᒬ")
	elif EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏࠪᄟ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠸࠲ᒭ")
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠩࡖࡌࡔࡌࡈࡂࠩᄠ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹࠸ᒮ")
	elif GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪᄡ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = bneABYmwFUH8GXphg0Kl2Sq(u"࠵࠹ᒯ")
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡆࡎࡗࡂࡍࠪᄢ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = rr7Xolsp4JwjPK3L(u"࠶࠵ᒰ")
	elif cJSNFCIhymEfx6grGu0M(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᄣ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠷࠶ᒱ")
	elif RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬᄤ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠹࠰ᒲ")
	elif wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡂࡍࡒࡅࡒ࠭ᄥ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = EHUAyW2lQfe4LXmhgIGc(u"࠲࠶ᒳ")
	elif cjbAkCIinvs(u"ࠨࡃࡎ࡛ࡆࡓࠧᄦ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = rr7Xolsp4JwjPK3L(u"࠴࠲ᒴ")
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫᄧ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠴࠳ᒵ")
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬᄨ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = yiaeCEwJjOcWA4ZSd5h(u"࠹࠴ᒶ")
	elif iAGgjwb7tVMmacRJ(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ᄩ") in XdoFLQ20O6SNVlcp: Hvui6ETwrexpG9zcs5Cl = ssGdubC4mngM9D5SRc3Ye(u"࠸࠵ᒷ")
	else: Hvui6ETwrexpG9zcs5Cl = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠶࠻ᒸ")
	YlmjsUCxfTuq = (rQmWAsndP6cgJNT8iEM7yVzhla1UkC!=None)
	FbDXhSVOofTACn7G = (CEuGyZ4rFkON2K7qJHfBxmgpvPAQX!=None and ct6DoMTHzUEbp4sv1BGWyxrw!=bneABYmwFUH8GXphg0Kl2Sq(u"࡙ࠬࡔࡐࡒࠪᄪ"))
	if YlmjsUCxfTuq and not JRnLE8F216uaZ4MQgIpzvc: XXeZuvhknsKYqB17gwm6dfc(RVpeGcmPxj9tCnT40Nf216(u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩᄫ"),rQmWAsndP6cgJNT8iEM7yVzhla1UkC)
	elif FbDXhSVOofTACn7G: XXeZuvhknsKYqB17gwm6dfc(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧᄬ"),CEuGyZ4rFkON2K7qJHfBxmgpvPAQX)
	if YlmjsUCxfTuq:
		qjlJQ3zUwAn9HBPGNucp7XyWDea = {EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠣࡪࡷࡸࡵࠨᄭ"):rQmWAsndP6cgJNT8iEM7yVzhla1UkC,cJSNFCIhymEfx6grGu0M(u"ࠤ࡫ࡸࡹࡶࡳࠣᄮ"):rQmWAsndP6cgJNT8iEM7yVzhla1UkC}
		K5ua2sSv8h = rQmWAsndP6cgJNT8iEM7yVzhla1UkC
	else: qjlJQ3zUwAn9HBPGNucp7XyWDea,K5ua2sSv8h = {},G9G0YqivIfmUWO8K
	if FbDXhSVOofTACn7G:
		import urllib3.util.connection as UnB8CQVOjgsuz4
		zzhj0OoCkpTePH7Zit8Ya = bbBxyV8WMeOaP7JA(UnB8CQVOjgsuz4,ALZsrP4M3TfRG9X1c7ENQKob)
	lg62oiPc9yvYHX,LYwAUpercInVkKPtHGM87fSZs,lld4bP9IkCErJ5o1m,OYWqFyJi4C60USrG7QszjnH,frnqXY4Rz7WaBKpsCb,verify = BlOvmjrZWVH7u,XdoFLQ20O6SNVlcp,urfTS1aCy6hklQRxKzmGFgWste,kkMuQrLWcEayRm,kkMuQrLWcEayRm,rpnIyPil9WTCLE
	if XM5lyWoecKEs1vuQgx: frnqXY4Rz7WaBKpsCb = P5VqbRSzjtO4UE1rZaolG67XA
	if KyuHEjzY93cpsIed8xa7TnfZioQ or BlOvmjrZWVH7u: lg62oiPc9yvYHX = kkMuQrLWcEayRm
	if UUThdmPcAVD4tx9SiHewME: lld4bP9IkCErJ5o1m = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡔࡔ࡙ࡔࠨᄯ")
	sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi = -fdQOo6Hu4B5Rbg,dC3PsQJ0Ti28uYlov(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫᄰ")
	dU615ys7n08MhQKrk = kkMuQrLWcEayRm
	global W8N1ecfjgDVSsaARwzk9I
	if not W8N1ecfjgDVSsaARwzk9I: W8N1ecfjgDVSsaARwzk9I = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,t2sCrJ0xbgDRkf(u"ࠬࡪࡩࡤࡶࠪᄱ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩᄲ"),rr7Xolsp4JwjPK3L(u"ࠧࡇࡑࡕ࡛ࡆࡘࡄࡔࠩᄳ"))
	CSvJwQNWDfhcF3 = []
	while XXzvmn7ewM8yBfoxua not in CSvJwQNWDfhcF3 and XXzvmn7ewM8yBfoxua in list(W8N1ecfjgDVSsaARwzk9I.keys()):
		CSvJwQNWDfhcF3.append(XXzvmn7ewM8yBfoxua)
		XXzvmn7ewM8yBfoxua = W8N1ecfjgDVSsaARwzk9I[XXzvmn7ewM8yBfoxua]
	import requests as MMEFXQfRHgZI3VSo4nrP57ypaLY
	for p0p6MxKbklodNCR92Wv in range(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠿ᒹ")):
		wSjfdovlF7rnZ = P5VqbRSzjtO4UE1rZaolG67XA
		pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
		try:
			if p0p6MxKbklodNCR92Wv: LYwAUpercInVkKPtHGM87fSZs = RVpeGcmPxj9tCnT40Nf216(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩᄴ")
			if JRnLE8F216uaZ4MQgIpzvc or not YlmjsUCxfTuq: SNAjoRGWnlMtauXpc5sI87FdU(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧᄵ"),XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,LYwAUpercInVkKPtHGM87fSZs,lld4bP9IkCErJ5o1m)
			try: DD1ExCgnvNZhY7Acwpq6yeTSmz.close()
			except: pass
			XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua
			DD1ExCgnvNZhY7Acwpq6yeTSmz = MMEFXQfRHgZI3VSo4nrP57ypaLY.request(lld4bP9IkCErJ5o1m,XXzvmn7ewM8yBfoxua,data=pPIbdY3oKe,headers=AAFEPhnMlsH5B3z0gYQWD4j7kUc,verify=verify,allow_redirects=lg62oiPc9yvYHX,timeout=Hvui6ETwrexpG9zcs5Cl,proxies=qjlJQ3zUwAn9HBPGNucp7XyWDea)
			if qTVF3icWwGXy5(u"࠳࠱࠲ᒺ")<=DD1ExCgnvNZhY7Acwpq6yeTSmz.status_code<=GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠴࠻࠼ᒻ"):
				if not OYWqFyJi4C60USrG7QszjnH:
					q8oeQZfvbtxjCJ429aykDVT3YMGLgF = list(DD1ExCgnvNZhY7Acwpq6yeTSmz.headers.keys())
					if iqHhJSxdaANDG5rlZm7B(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᄶ") in q8oeQZfvbtxjCJ429aykDVT3YMGLgF: XXzvmn7ewM8yBfoxua = DD1ExCgnvNZhY7Acwpq6yeTSmz.headers[EHUAyW2lQfe4LXmhgIGc(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᄷ")]
					elif cJSNFCIhymEfx6grGu0M(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧᄸ") in q8oeQZfvbtxjCJ429aykDVT3YMGLgF: XXzvmn7ewM8yBfoxua = DD1ExCgnvNZhY7Acwpq6yeTSmz.headers[EHUAyW2lQfe4LXmhgIGc(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᄹ")]
					else: OYWqFyJi4C60USrG7QszjnH = P5VqbRSzjtO4UE1rZaolG67XA
					if not OYWqFyJi4C60USrG7QszjnH: XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.encode(ETNq5t4MYngSsbfFD8J0v(u"ࠧ࡭ࡣࡷ࡭ࡳ࠳࠱ࠨᄺ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᄻ")).decode(f3uIcZ2C6pzbX1JlFBrVOdt,bneABYmwFUH8GXphg0Kl2Sq(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᄼ"))
					if KyuHEjzY93cpsIed8xa7TnfZioQ and DD1ExCgnvNZhY7Acwpq6yeTSmz.status_code==VHrIziKUDuNGXkMla(u"࠵࠳࠻ᒼ"):
						lg62oiPc9yvYHX = BlOvmjrZWVH7u
						lld4bP9IkCErJ5o1m = urfTS1aCy6hklQRxKzmGFgWste
						OYWqFyJi4C60USrG7QszjnH = P5VqbRSzjtO4UE1rZaolG67XA
						D1DVmskGS96MR80YZP24JzCf
				if not OYWqFyJi4C60USrG7QszjnH or BlOvmjrZWVH7u:
					if FWqeEzO1i8Dn0ga(u"ࠪ࡬ࡹࡺࡰࠨᄽ") not in XXzvmn7ewM8yBfoxua:
						NjfyDTPiolAcsVQ4v2La = xWiOjcUrJVdtP4B5Iml(XjWHSnbf6NwhMgpKt4yLY7AkIT,cjbAkCIinvs(u"ࠫࡺࡸ࡬ࠨᄾ"))
						XXzvmn7ewM8yBfoxua = NjfyDTPiolAcsVQ4v2La+t2sCrJ0xbgDRkf(u"ࠬ࠵ࠧᄿ")+XXzvmn7ewM8yBfoxua.lstrip(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࠯ࠨᅀ"))
				if XXzvmn7ewM8yBfoxua!=XjWHSnbf6NwhMgpKt4yLY7AkIT:
					W8N1ecfjgDVSsaARwzk9I[XjWHSnbf6NwhMgpKt4yLY7AkIT] = XXzvmn7ewM8yBfoxua
					dU615ys7n08MhQKrk = P5VqbRSzjtO4UE1rZaolG67XA
				if not OYWqFyJi4C60USrG7QszjnH and BlOvmjrZWVH7u and not Ig4jFuXGfUQeCn6wlB8(XXzvmn7ewM8yBfoxua): D1DVmskGS96MR80YZP24JzCf
			elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠹࠺࠶ᒾ")<=DD1ExCgnvNZhY7Acwpq6yeTSmz.status_code<=bneABYmwFUH8GXphg0Kl2Sq(u"࠸࠽࠾ᒽ"):
				DD1ExCgnvNZhY7Acwpq6yeTSmz.reason = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
				frnqXY4Rz7WaBKpsCb = P5VqbRSzjtO4UE1rZaolG67XA
			XjWHSnbf6NwhMgpKt4yLY7AkIT = DD1ExCgnvNZhY7Acwpq6yeTSmz.url
			sNWjYO26TqeSHihfx5aD8EUlon49 = DD1ExCgnvNZhY7Acwpq6yeTSmz.status_code
			DeRNxUpz3y8h05KCvgJEi = DD1ExCgnvNZhY7Acwpq6yeTSmz.reason
			DD1ExCgnvNZhY7Acwpq6yeTSmz.raise_for_status()
			pEU7uHoc0zQOC1Anab3KxZ9k = P5VqbRSzjtO4UE1rZaolG67XA
		except MMEFXQfRHgZI3VSo4nrP57ypaLY.exceptions.HTTPError as MGlP3SpZY8VTHmBt7:
			pass
		except MMEFXQfRHgZI3VSo4nrP57ypaLY.exceptions.Timeout as MGlP3SpZY8VTHmBt7:
			if gA0m6CQUyfLG: DeRNxUpz3y8h05KCvgJEi = str(MGlP3SpZY8VTHmBt7.message).split(rxWDdRBIct57i90s(u"ࠧ࠻ࠢࠪᅁ"))[fdQOo6Hu4B5Rbg]
			else: DeRNxUpz3y8h05KCvgJEi = str(MGlP3SpZY8VTHmBt7).split(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ࠼ࠣࠫᅂ"))[fdQOo6Hu4B5Rbg]
		except MMEFXQfRHgZI3VSo4nrP57ypaLY.exceptions.ConnectionError as MGlP3SpZY8VTHmBt7:
			try: pNmWTskohjIPSt7fQl = MGlP3SpZY8VTHmBt7.message[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			except: pNmWTskohjIPSt7fQl = str(MGlP3SpZY8VTHmBt7)
			aBfzWluiS0GN = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦᅃ"),pNmWTskohjIPSt7fQl)
			if not aBfzWluiS0GN: aBfzWluiS0GN = oo9kuULlebNgpY0Om.findall(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᅄ"),pNmWTskohjIPSt7fQl)
			if not aBfzWluiS0GN:
				j1UIBgNbxs8lRG2O4t03y6KLowzrh = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠦ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯࠺ࠣᅅ"),pNmWTskohjIPSt7fQl)
				if j1UIBgNbxs8lRG2O4t03y6KLowzrh: aBfzWluiS0GN = [j1UIBgNbxs8lRG2O4t03y6KLowzrh[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg],j1UIBgNbxs8lRG2O4t03y6KLowzrh[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz]]
			if not aBfzWluiS0GN: aBfzWluiS0GN = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠧࡀࠨ࡝ࡦ࠮࠭࠿ࠦࠨ࠯ࠬࡂ࠭ࠬࠨᅆ"),pNmWTskohjIPSt7fQl)
			if not aBfzWluiS0GN: aBfzWluiS0GN = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠨࠠࠩ࡞ࡧ࠯࠮ࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢᅇ"),pNmWTskohjIPSt7fQl)
			try: sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi = aBfzWluiS0GN[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			except: sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi = -ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠷ᒿ"),pNmWTskohjIPSt7fQl
		except MMEFXQfRHgZI3VSo4nrP57ypaLY.exceptions.RequestException as MGlP3SpZY8VTHmBt7:
			if gA0m6CQUyfLG: DeRNxUpz3y8h05KCvgJEi = MGlP3SpZY8VTHmBt7.message
			else: DeRNxUpz3y8h05KCvgJEi = str(MGlP3SpZY8VTHmBt7)
		except:
			wSjfdovlF7rnZ = kkMuQrLWcEayRm
			try: sNWjYO26TqeSHihfx5aD8EUlon49 = DD1ExCgnvNZhY7Acwpq6yeTSmz.status_code
			except: pass
			try: DeRNxUpz3y8h05KCvgJEi = DD1ExCgnvNZhY7Acwpq6yeTSmz.reason
			except: pass
		DeRNxUpz3y8h05KCvgJEi = str(DeRNxUpz3y8h05KCvgJEi)
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,DTF3Lwy9etRH8mI(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࡟ࡸࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᅈ")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᅉ")+DeRNxUpz3y8h05KCvgJEi+RVpeGcmPxj9tCnT40Nf216(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᅊ")+XdoFLQ20O6SNVlcp+ssGdubC4mngM9D5SRc3Ye(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᅋ")+yzieWRVX4nkB3DjGHJphEdQo+rxWDdRBIct57i90s(u"ࠫࠥࡣࠧᅌ"))
		if zrK6MFTlkBnqyvo and KyuHEjzY93cpsIed8xa7TnfZioQ and wSjfdovlF7rnZ and not frnqXY4Rz7WaBKpsCb and sNWjYO26TqeSHihfx5aD8EUlon49!=yiaeCEwJjOcWA4ZSd5h(u"࠸࠰࠱ᓀ"):
			XXzvmn7ewM8yBfoxua = WQpbTAq5IO7Sujn8rJfl
			frnqXY4Rz7WaBKpsCb = P5VqbRSzjtO4UE1rZaolG67XA
			continue
		if wSjfdovlF7rnZ: break
	if not pEU7uHoc0zQOC1Anab3KxZ9k and CSvJwQNWDfhcF3:
		for url in CSvJwQNWDfhcF3: del W8N1ecfjgDVSsaARwzk9I[url]
		dU615ys7n08MhQKrk = P5VqbRSzjtO4UE1rZaolG67XA
	if dU615ys7n08MhQKrk:
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,dC3PsQJ0Ti28uYlov(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᅍ"),VHrIziKUDuNGXkMla(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᅎ"),W8N1ecfjgDVSsaARwzk9I,AH0BQ4LKlDMrfvqWmXn5)
		W8N1ecfjgDVSsaARwzk9I = {}
	if CEuGyZ4rFkON2K7qJHfBxmgpvPAQX!=None and ct6DoMTHzUEbp4sv1BGWyxrw!=FWqeEzO1i8Dn0ga(u"ࠧࡔࡖࡒࡔࠬᅏ"): UnB8CQVOjgsuz4.create_connection = zzhj0OoCkpTePH7Zit8Ya
	if ct6DoMTHzUEbp4sv1BGWyxrw==iAGgjwb7tVMmacRJ(u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨᅐ") and MSFOAi6yH9n8JeV3KWmpChagE5BPNo: CEuGyZ4rFkON2K7qJHfBxmgpvPAQX = None
	if not pEU7uHoc0zQOC1Anab3KxZ9k and rQmWAsndP6cgJNT8iEM7yVzhla1UkC==None and XdoFLQ20O6SNVlcp not in g3douDifIqHWVZ2AL9E6zScwR0OrG1:
		fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
		if fEKoHajMCOh!=RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬᅑ"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
	WvxUIHz0cMJB = LGmh2jCPAgpY()
	if JRnLE8F216uaZ4MQgIpzvc: XjWHSnbf6NwhMgpKt4yLY7AkIT = fhF7vrH2Eal5Atu3iV1Rq89os
	if not XjWHSnbf6NwhMgpKt4yLY7AkIT: XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua
	WvxUIHz0cMJB.url = XjWHSnbf6NwhMgpKt4yLY7AkIT
	WvxUIHz0cMJB.scrape = JRnLE8F216uaZ4MQgIpzvc
	try: FuDVqHKYTArPk = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
	except: FuDVqHKYTArPk = G9G0YqivIfmUWO8K
	try: FF0ORpe6IgNKcvuDo139yH = DD1ExCgnvNZhY7Acwpq6yeTSmz.headers
	except: FF0ORpe6IgNKcvuDo139yH = {}
	try: uq9ivWKEZB6ntxrVC = DD1ExCgnvNZhY7Acwpq6yeTSmz.cookies.get_dict()
	except: uq9ivWKEZB6ntxrVC = {}
	try: DD1ExCgnvNZhY7Acwpq6yeTSmz.close()
	except: pass
	if LTze51miOknVcslNF43WSA6vMjYZt:
		try: FuDVqHKYTArPk = FuDVqHKYTArPk.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		except: pass
	sNWjYO26TqeSHihfx5aD8EUlon49 = int(sNWjYO26TqeSHihfx5aD8EUlon49)
	WvxUIHz0cMJB.code = sNWjYO26TqeSHihfx5aD8EUlon49
	WvxUIHz0cMJB.reason = DeRNxUpz3y8h05KCvgJEi
	WvxUIHz0cMJB.content = FuDVqHKYTArPk
	WvxUIHz0cMJB.headers = FF0ORpe6IgNKcvuDo139yH
	WvxUIHz0cMJB.cookies = uq9ivWKEZB6ntxrVC
	WvxUIHz0cMJB.succeeded = pEU7uHoc0zQOC1Anab3KxZ9k
	WvxUIHz0cMJB.scrapernumber = G9G0YqivIfmUWO8K
	WvxUIHz0cMJB.scraperserver = G9G0YqivIfmUWO8K
	WvxUIHz0cMJB.scraperurl = G9G0YqivIfmUWO8K
	if gA0m6CQUyfLG or isinstance(WvxUIHz0cMJB.content,str): ySlW4BsEMIdL10wOxJCaf37 = WvxUIHz0cMJB.content.lower()
	else: ySlW4BsEMIdL10wOxJCaf37 = G9G0YqivIfmUWO8K
	bRx6PsIvEpG1oaztMTJ2k8mcg = (rr7Xolsp4JwjPK3L(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧᅒ") in ySlW4BsEMIdL10wOxJCaf37 or RVpeGcmPxj9tCnT40Nf216(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫᅓ") in ySlW4BsEMIdL10wOxJCaf37) and ySlW4BsEMIdL10wOxJCaf37.count(cJSNFCIhymEfx6grGu0M(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨᅔ"))>dC3PsQJ0Ti28uYlov(u"࠲ᓁ") and rxWDdRBIct57i90s(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᅕ") not in XdoFLQ20O6SNVlcp and GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩᅖ") not in ySlW4BsEMIdL10wOxJCaf37 and not JRnLE8F216uaZ4MQgIpzvc
	if sNWjYO26TqeSHihfx5aD8EUlon49==RVpeGcmPxj9tCnT40Nf216(u"࠳࠲࠳ᓂ") and bRx6PsIvEpG1oaztMTJ2k8mcg: WvxUIHz0cMJB.succeeded = kkMuQrLWcEayRm
	if WvxUIHz0cMJB.succeeded and zrK6MFTlkBnqyvo and KyuHEjzY93cpsIed8xa7TnfZioQ:
		kQtFlTA5d9p8Lho = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩᅗ")+pPIbdY3oKe[qTVF3icWwGXy5(u"ࠩ࡭ࡳࡧ࠭ᅘ")].upper().replace(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡋࡊ࡚ࠧᅙ"),G9G0YqivIfmUWO8K) if XM5lyWoecKEs1vuQgx else ybOHG96WcPCBgqU3Z7K8STp24
		UhZuB0G4InHX7s(kQtFlTA5d9p8Lho)
	if not WvxUIHz0cMJB.succeeded and zrK6MFTlkBnqyvo:
		bbrRn0qHLiNMQAphedTvgycIf = (jR9YtmsgDX8nTQlMb6G3(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨᅚ") in ySlW4BsEMIdL10wOxJCaf37 and RVpeGcmPxj9tCnT40Nf216(u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧᅛ") in ySlW4BsEMIdL10wOxJCaf37)
		a0aVcwUhJ7 = (rxWDdRBIct57i90s(u"࠭࠵ࠡࡵࡨࡧࠬᅜ") in ySlW4BsEMIdL10wOxJCaf37 and dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨᅝ") in ySlW4BsEMIdL10wOxJCaf37)
		kkznfXPQBZU = (sNWjYO26TqeSHihfx5aD8EUlon49 in [wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠶࠳࠷ᓃ")] and RVpeGcmPxj9tCnT40Nf216(u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫᅞ") in ySlW4BsEMIdL10wOxJCaf37)
		rERPdD2x1X9ogKMYO = (RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫᅟ") in ySlW4BsEMIdL10wOxJCaf37 and wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧᅠ") in ySlW4BsEMIdL10wOxJCaf37)
		if   bRx6PsIvEpG1oaztMTJ2k8mcg: DeRNxUpz3y8h05KCvgJEi = jR9YtmsgDX8nTQlMb6G3(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫᅡ")
		elif bbrRn0qHLiNMQAphedTvgycIf: DeRNxUpz3y8h05KCvgJEi = dC3PsQJ0Ti28uYlov(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᅢ")
		elif a0aVcwUhJ7: DeRNxUpz3y8h05KCvgJEi = t2sCrJ0xbgDRkf(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭ᅣ")
		elif kkznfXPQBZU: DeRNxUpz3y8h05KCvgJEi = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨᅤ")
		elif rERPdD2x1X9ogKMYO: DeRNxUpz3y8h05KCvgJEi = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪᅥ")
		else: DeRNxUpz3y8h05KCvgJEi = str(DeRNxUpz3y8h05KCvgJEi)
		if XdoFLQ20O6SNVlcp in VUxGrbhSsEQjcltBTDmYIzKyeAvaqZ: pass
		elif XdoFLQ20O6SNVlcp in g3douDifIqHWVZ2AL9E6zScwR0OrG1:
			vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᅦ")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+DTF3Lwy9etRH8mI(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᅧ")+DeRNxUpz3y8h05KCvgJEi+ETNq5t4MYngSsbfFD8J0v(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᅨ")+XdoFLQ20O6SNVlcp+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᅩ")+XXzvmn7ewM8yBfoxua+rr7Xolsp4JwjPK3L(u"࠭ࠠ࡞ࠩᅪ"))
		else: vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࠡࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᅫ")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+jR9YtmsgDX8nTQlMb6G3(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᅬ")+DeRNxUpz3y8h05KCvgJEi+EHUAyW2lQfe4LXmhgIGc(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᅭ")+XdoFLQ20O6SNVlcp+UighHKAfySm4PWErqJ(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᅮ")+XXzvmn7ewM8yBfoxua+rxWDdRBIct57i90s(u"ࠫࠥࡣࠧᅯ"))
		AbE0wPyDtLjaeZ3fG = fhF7vrH2Eal5Atu3iV1Rq89os if JRnLE8F216uaZ4MQgIpzvc else aKAyEnjxIlzZtCTv(XXzvmn7ewM8yBfoxua)
		if gA0m6CQUyfLG and isinstance(AbE0wPyDtLjaeZ3fG,unicode): AbE0wPyDtLjaeZ3fG = AbE0wPyDtLjaeZ3fG.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		if KyuHEjzY93cpsIed8xa7TnfZioQ: AbE0wPyDtLjaeZ3fG = AbE0wPyDtLjaeZ3fG.split(yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠵ࠧᅰ"))[-fdQOo6Hu4B5Rbg]
		uezolFtNgj5ACOSMcBy2hR = str(DeRNxUpz3y8h05KCvgJEi)+rr7Xolsp4JwjPK3L(u"࠭࡜࡯ࠪࠣࠫᅱ")+AbE0wPyDtLjaeZ3fG+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࠡࠫࠪᅲ")
		if sNWjYO26TqeSHihfx5aD8EUlon49 in [-fdQOo6Hu4B5Rbg,-SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU] or bRx6PsIvEpG1oaztMTJ2k8mcg or bbrRn0qHLiNMQAphedTvgycIf or a0aVcwUhJ7 or kkznfXPQBZU or rERPdD2x1X9ogKMYO:
			WvxUIHz0cMJB.code = -c1R9fnIY4XBDZ
			WvxUIHz0cMJB.reason = DeRNxUpz3y8h05KCvgJEi
			if yyU0dfH65vQGu:
				w8w4tXrQA5ojk7mzFpbUguZ = sJu0WwVmpYXChEDHLBUM(urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi)
				if w8w4tXrQA5ojk7mzFpbUguZ.succeeded: return w8w4tXrQA5ojk7mzFpbUguZ
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = P5VqbRSzjtO4UE1rZaolG67XA
		if (ct6DoMTHzUEbp4sv1BGWyxrw==VHrIziKUDuNGXkMla(u"ࠨࡃࡖࡏࠬᅳ") or M5o1e2cPaA4NO9viqIFUt7x3RblLg0==jR9YtmsgDX8nTQlMb6G3(u"ࠩࡄࡗࡐ࠭ᅴ")) and (MSFOAi6yH9n8JeV3KWmpChagE5BPNo or yyU0dfH65vQGu):
			J8UB4bgrawlyzjYXA759Ee1c0N2fd = SAdYOJNgER8L(sNWjYO26TqeSHihfx5aD8EUlon49,uezolFtNgj5ACOSMcBy2hR,XdoFLQ20O6SNVlcp,ALuIKiVCBPqE)
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd and ct6DoMTHzUEbp4sv1BGWyxrw==dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡅࡘࡑࠧᅵ"): ct6DoMTHzUEbp4sv1BGWyxrw = rr7Xolsp4JwjPK3L(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᅶ")
			else: ct6DoMTHzUEbp4sv1BGWyxrw = cjbAkCIinvs(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᅷ")
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd and M5o1e2cPaA4NO9viqIFUt7x3RblLg0==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡁࡔࡍࠪᅸ"): M5o1e2cPaA4NO9viqIFUt7x3RblLg0 = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩᅹ")
			else: M5o1e2cPaA4NO9viqIFUt7x3RblLg0 = iAGgjwb7tVMmacRJ(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᅺ")
			amx9qJHkhw7oLdtVMG3.setSetting(UighHKAfySm4PWErqJ(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᅻ"),ct6DoMTHzUEbp4sv1BGWyxrw)
			amx9qJHkhw7oLdtVMG3.setSetting(iqHhJSxdaANDG5rlZm7B(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᅼ"),M5o1e2cPaA4NO9viqIFUt7x3RblLg0)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
			if sNWjYO26TqeSHihfx5aD8EUlon49==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠻ᓄ") and EHUAyW2lQfe4LXmhgIGc(u"ࠫ࡭ࡺࡴࡱࡵࠪᅽ") in XXzvmn7ewM8yBfoxua and Ltv8PQFqMWEY:
				if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(bneABYmwFUH8GXphg0Kl2Sq(u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬᅾ"),rr7Xolsp4JwjPK3L(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᅿ"),SSCU3jdyFn2V=UighHKAfySm4PWErqJ(u"࠶࠵࠶࠰ᓅ"))
				XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᆀ")
				PisJcWj8of9xTKUNmpyI = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,XjWHSnbf6NwhMgpKt4yLY7AkIT,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,ALuIKiVCBPqE,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠸࡮ࡥࠩᆁ"))
				if PisJcWj8of9xTKUNmpyI.succeeded:
					WvxUIHz0cMJB = PisJcWj8of9xTKUNmpyI
					vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dC3PsQJ0Ti28uYlov(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆂ")+XdoFLQ20O6SNVlcp+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆃ")+yzieWRVX4nkB3DjGHJphEdQo+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࠥࡣࠧᆄ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ์ฬศฯࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩᆅ"),DTF3Lwy9etRH8mI(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆆ"),SSCU3jdyFn2V=bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠶࠰࠱ᓆ"))
				else:
					vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RVpeGcmPxj9tCnT40Nf216(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆇ")+XdoFLQ20O6SNVlcp+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᆈ")+yzieWRVX4nkB3DjGHJphEdQo+ETNq5t4MYngSsbfFD8J0v(u"ࠩࠣࡡࠬᆉ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RVpeGcmPxj9tCnT40Nf216(u"ࠪๅู๊ࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ᆊ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᆋ"),SSCU3jdyFn2V=iAGgjwb7tVMmacRJ(u"࠸࠰࠱࠲ᓇ"))
			if not WvxUIHz0cMJB.succeeded and M5o1e2cPaA4NO9viqIFUt7x3RblLg0 in [iAGgjwb7tVMmacRJ(u"ࠬࡇࡕࡕࡑࠪᆌ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᆍ")] and yyU0dfH65vQGu:
				if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧหใ฼๎้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᆎ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆏ"),SSCU3jdyFn2V=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠲࠱࠲࠳ᓈ"))
				PisJcWj8of9xTKUNmpyI = sxjogkuleZE54RTyhMvIfP9CD0dWK(urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp)
				if PisJcWj8of9xTKUNmpyI.succeeded:
					WvxUIHz0cMJB = PisJcWj8of9xTKUNmpyI
					vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+t2sCrJ0xbgDRkf(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᆐ")+XdoFLQ20O6SNVlcp+jR9YtmsgDX8nTQlMb6G3(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆑ")+yzieWRVX4nkB3DjGHJphEdQo+rxWDdRBIct57i90s(u"ࠫࠥࡣࠧᆒ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬ์ฬศฯࠣื๏ืแาษอࠤอื่ไีํࠫᆓ"),yiaeCEwJjOcWA4ZSd5h(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆔ"),SSCU3jdyFn2V=CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠳࠲࠳࠴ᓉ"))
				else:
					vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iqHhJSxdaANDG5rlZm7B(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆕ")+XdoFLQ20O6SNVlcp+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᆖ")+yzieWRVX4nkB3DjGHJphEdQo+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࠣࡡࠬᆗ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨᆘ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᆙ"),SSCU3jdyFn2V=dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠴࠳࠴࠵ᓊ"))
			if not WvxUIHz0cMJB.succeeded and ct6DoMTHzUEbp4sv1BGWyxrw in [bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡇࡕࡕࡑࠪᆚ"),EHUAyW2lQfe4LXmhgIGc(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᆛ")] and MSFOAi6yH9n8JeV3KWmpChagE5BPNo:
				if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩᆜ"),iAGgjwb7tVMmacRJ(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆝ"),SSCU3jdyFn2V=GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠵࠴࠵࠶ᓋ"))
				XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua+VHrIziKUDuNGXkMla(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᆞ")
				PisJcWj8of9xTKUNmpyI = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,XjWHSnbf6NwhMgpKt4yLY7AkIT,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,ALuIKiVCBPqE,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠵ࡶ࡫ࠫᆟ"))
				if PisJcWj8of9xTKUNmpyI.succeeded:
					WvxUIHz0cMJB = PisJcWj8of9xTKUNmpyI
					vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+ssGdubC4mngM9D5SRc3Ye(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫᆠ")+ALZsrP4M3TfRG9X1c7ENQKob+FWqeEzO1i8Dn0ga(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᆡ")+XdoFLQ20O6SNVlcp+t2sCrJ0xbgDRkf(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᆢ")+yzieWRVX4nkB3DjGHJphEdQo+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࠡ࡟ࠪᆣ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩᆤ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᆥ"),SSCU3jdyFn2V=cjbAkCIinvs(u"࠶࠵࠶࠰ᓌ"))
				else:
					vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iAGgjwb7tVMmacRJ(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧᆦ")+ALZsrP4M3TfRG9X1c7ENQKob+DTF3Lwy9etRH8mI(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᆧ")+XdoFLQ20O6SNVlcp+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆨ")+yzieWRVX4nkB3DjGHJphEdQo+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࠠ࡞ࠩᆩ"))
					if ALuIKiVCBPqE: XXeZuvhknsKYqB17gwm6dfc(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᆪ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᆫ"),SSCU3jdyFn2V=wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠷࠶࠰࠱ᓍ"))
		if M5o1e2cPaA4NO9viqIFUt7x3RblLg0==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᆬ") or ct6DoMTHzUEbp4sv1BGWyxrw==cjbAkCIinvs(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᆭ"): ALuIKiVCBPqE = kkMuQrLWcEayRm
		if not WvxUIHz0cMJB.succeeded:
			if ALuIKiVCBPqE: qJNHBFAfi3SyvPGn1u6Ur2TM = SAdYOJNgER8L(sNWjYO26TqeSHihfx5aD8EUlon49,uezolFtNgj5ACOSMcBy2hR,XdoFLQ20O6SNVlcp,ALuIKiVCBPqE)
			if sNWjYO26TqeSHihfx5aD8EUlon49!=DTF3Lwy9etRH8mI(u"࠸࠰࠱ᓎ") and XdoFLQ20O6SNVlcp not in x6jGtaZDVI and FWqeEzO1i8Dn0ga(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨᆮ") not in XdoFLQ20O6SNVlcp: fdGJteXp3aEi2wcMYDgP0T46lZ()
	if amx9qJHkhw7oLdtVMG3.getSetting(jR9YtmsgDX8nTQlMb6G3(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᆯ")) not in [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡁࡖࡖࡒࠫᆰ"),t2sCrJ0xbgDRkf(u"ࠧࡔࡖࡒࡔࠬᆱ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡃࡖࡏࠬᆲ")]: amx9qJHkhw7oLdtVMG3.setSetting(DTF3Lwy9etRH8mI(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᆳ"),VHrIziKUDuNGXkMla(u"ࠪࡅࡘࡑࠧᆴ"))
	if amx9qJHkhw7oLdtVMG3.getSetting(qTVF3icWwGXy5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᆵ")) not in [RVpeGcmPxj9tCnT40Nf216(u"ࠬࡇࡕࡕࡑࠪᆶ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡓࡕࡑࡓࠫᆷ"),DTF3Lwy9etRH8mI(u"ࠧࡂࡕࡎࠫᆸ")]: amx9qJHkhw7oLdtVMG3.setSetting(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᆹ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡄࡗࡐ࠭ᆺ"))
	return WvxUIHz0cMJB
def BrCIhmKkMPo(website,EpcejN4h5wGdfBax,JYG26FoyqK5Pv0197u=None):
	MdBS1aFDyirGUKwoL9Nvmf = ETNq5t4MYngSsbfFD8J0v(u"࠱࠱ᓏ")
	F87mt602vYVsTdjUR = [DTF3Lwy9etRH8mI(u"࠲ᓐ"),DTF3Lwy9etRH8mI(u"࠲ᓐ"),DTF3Lwy9etRH8mI(u"࠲ᓐ"),DTF3Lwy9etRH8mI(u"࠳࠳ᓑ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸ᓒ"),DTF3Lwy9etRH8mI(u"࠳࠳ᓑ"),DTF3Lwy9etRH8mI(u"࠲ᓐ"),DTF3Lwy9etRH8mI(u"࠲ᓐ"),DTF3Lwy9etRH8mI(u"࠲ᓐ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸ᓒ")]
	eeXfusiWnhvZ = f5jdSUbP761JrgynW2GZAXIsc8YRCQ
	lSNZYp1ToRVXKuc3Aiz09mqQjtHFL = []
	TtfLb0lFuYZqHWN = [ssGdubC4mngM9D5SRc3Ye(u"࠴ᓓ")]*MdBS1aFDyirGUKwoL9Nvmf
	ISBX6qJdzegA9EHrD1ZsQPKOCpbv = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡨ࡮ࡩࡴࠨᆻ"),dC3PsQJ0Ti28uYlov(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ᆼ"))
	for defQ2E7otmuT in list(ISBX6qJdzegA9EHrD1ZsQPKOCpbv.keys()):
		if website not in defQ2E7otmuT: continue
		oob2dzmG3jTMpZwQyIfN,oJHA2S9MUNfKap54h68VjYk = defQ2E7otmuT.split(iqHhJSxdaANDG5rlZm7B(u"ࠬࡥ࡟ࠨᆽ"))
		TtfLb0lFuYZqHWN[int(oJHA2S9MUNfKap54h68VjYk)] = ISBX6qJdzegA9EHrD1ZsQPKOCpbv[defQ2E7otmuT]
	for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(MdBS1aFDyirGUKwoL9Nvmf):
		if NAfxw4FYmpauWhLM2rX8soZk9QnC0 in eeXfusiWnhvZ+EpcejN4h5wGdfBax: continue
		if NAfxw4FYmpauWhLM2rX8soZk9QnC0==JYG26FoyqK5Pv0197u: TtfLb0lFuYZqHWN[NAfxw4FYmpauWhLM2rX8soZk9QnC0] = TtfLb0lFuYZqHWN[NAfxw4FYmpauWhLM2rX8soZk9QnC0]+qTVF3icWwGXy5(u"࠶ᓔ")
		if TtfLb0lFuYZqHWN[NAfxw4FYmpauWhLM2rX8soZk9QnC0]<CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠹ᓕ"): lSNZYp1ToRVXKuc3Aiz09mqQjtHFL += [NAfxw4FYmpauWhLM2rX8soZk9QnC0]*F87mt602vYVsTdjUR[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
	if not lSNZYp1ToRVXKuc3Aiz09mqQjtHFL:
		for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(MdBS1aFDyirGUKwoL9Nvmf):
			TtfLb0lFuYZqHWN[NAfxw4FYmpauWhLM2rX8soZk9QnC0] = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠰ᓖ")
			if NAfxw4FYmpauWhLM2rX8soZk9QnC0 in eeXfusiWnhvZ+EpcejN4h5wGdfBax: continue
			lSNZYp1ToRVXKuc3Aiz09mqQjtHFL += [NAfxw4FYmpauWhLM2rX8soZk9QnC0]*F87mt602vYVsTdjUR[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
	for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in eeXfusiWnhvZ: TtfLb0lFuYZqHWN[NAfxw4FYmpauWhLM2rX8soZk9QnC0] = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠺࠻࠼࠽ᓗ")
	kxFpZsr7NLA8b = []
	for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(MdBS1aFDyirGUKwoL9Nvmf): kxFpZsr7NLA8b.append(website+VHrIziKUDuNGXkMla(u"࠭࡟ࡠࠩᆾ")+str(NAfxw4FYmpauWhLM2rX8soZk9QnC0))
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,rr7Xolsp4JwjPK3L(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩᆿ"),kxFpZsr7NLA8b,TtfLb0lFuYZqHWN,mEbUloJpiHD90Skd45A2WMYKqORC*ssGdubC4mngM9D5SRc3Ye(u"࠷ᓘ"),P5VqbRSzjtO4UE1rZaolG67XA)
	return lSNZYp1ToRVXKuc3Aiz09mqQjtHFL
def sJu0WwVmpYXChEDHLBUM(urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi,EpcejN4h5wGdfBax=[]):
	XXeZuvhknsKYqB17gwm6dfc(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨสาวฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪᇀ"),G9G0YqivIfmUWO8K,SSCU3jdyFn2V=EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠺࠹࠵ᓙ"))
	vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᇁ")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+cjbAkCIinvs(u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᇂ")+DeRNxUpz3y8h05KCvgJEi+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᇃ")+XdoFLQ20O6SNVlcp+iqHhJSxdaANDG5rlZm7B(u"ࠬࠦ࡝ࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᇄ")+XXzvmn7ewM8yBfoxua+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࠠ࡞ࠩᇅ"))
	website = XdoFLQ20O6SNVlcp.split(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧ࠮ࠩᇆ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	SnpbfahEeYLF0O5itkArjTJIPu2 = BrCIhmKkMPo(website,EpcejN4h5wGdfBax)
	CgEYJzhcIf6 = []
	if website==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪᇇ"):
		if dQ5JhEYolPmy1fvHktMw6NFRxiz in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if fdQOo6Hu4B5Rbg in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [fdQOo6Hu4B5Rbg]
		if SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		if c1R9fnIY4XBDZ in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [c1R9fnIY4XBDZ]*qTVF3icWwGXy5(u"࠵࠵ᓚ")
		if xsCEkXb6tgrh3195YZ in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [xsCEkXb6tgrh3195YZ]*rxWDdRBIct57i90s(u"࠺ᓛ")
		if EHUAyW2lQfe4LXmhgIGc(u"࠵ᓝ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [EHUAyW2lQfe4LXmhgIGc(u"࠵ᓝ")]*yiaeCEwJjOcWA4ZSd5h(u"࠷࠰ᓜ")
		if ssGdubC4mngM9D5SRc3Ye(u"࠷ᓞ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [ssGdubC4mngM9D5SRc3Ye(u"࠷ᓞ")]
		if cJSNFCIhymEfx6grGu0M(u"࠹ᓟ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [cJSNFCIhymEfx6grGu0M(u"࠹ᓟ")]
	elif website==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫᇈ"):
		if c1R9fnIY4XBDZ in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [c1R9fnIY4XBDZ]*hhdGMSsBzel96obfEmrwiuLPOvq(u"࠴࠴ᓠ")
	elif website==UighHKAfySm4PWErqJ(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬᇉ"):
		if fdQOo6Hu4B5Rbg in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [fdQOo6Hu4B5Rbg]
		if xsCEkXb6tgrh3195YZ in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [xsCEkXb6tgrh3195YZ]*ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠹ᓡ")
		if vCmnFshSi4flecXIY2gy38G0DJw(u"࠻ᓣ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [vCmnFshSi4flecXIY2gy38G0DJw(u"࠻ᓣ")]*yiaeCEwJjOcWA4ZSd5h(u"࠶࠶ᓢ")
		if EHUAyW2lQfe4LXmhgIGc(u"࠶ᓤ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [EHUAyW2lQfe4LXmhgIGc(u"࠶ᓤ")]
		if jR9YtmsgDX8nTQlMb6G3(u"࠸ᓥ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [jR9YtmsgDX8nTQlMb6G3(u"࠸ᓥ")]
	elif website==t2sCrJ0xbgDRkf(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᇊ"):
		if xsCEkXb6tgrh3195YZ in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [xsCEkXb6tgrh3195YZ]*ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠷ᓦ")
		if iAGgjwb7tVMmacRJ(u"࠹ᓨ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [iAGgjwb7tVMmacRJ(u"࠹ᓨ")]*ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠴࠴ᓧ")
	elif website==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ᇋ"):
		if UighHKAfySm4PWErqJ(u"࠾ᓩ") in SnpbfahEeYLF0O5itkArjTJIPu2: CgEYJzhcIf6 += [UighHKAfySm4PWErqJ(u"࠾ᓩ")]*dC3PsQJ0Ti28uYlov(u"࠻ᓪ")
	if CgEYJzhcIf6: SnpbfahEeYLF0O5itkArjTJIPu2 = CgEYJzhcIf6
	if SnpbfahEeYLF0O5itkArjTJIPu2:
		gxw5auqQd78v4SPBMU = voWS3GzbN5HXaTsiwLMeU.sample(SnpbfahEeYLF0O5itkArjTJIPu2,fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	else: gxw5auqQd78v4SPBMU = -fdQOo6Hu4B5Rbg
	update = P5VqbRSzjtO4UE1rZaolG67XA
	if gxw5auqQd78v4SPBMU==dQ5JhEYolPmy1fvHktMw6NFRxiz:
		scraperserver = FWqeEzO1i8Dn0ga(u"࠭ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠳ࠪᇌ")
		MgOXedqWFBs9yL043AV7u = rr7Xolsp4JwjPK3L(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯࠾࠶࠻࠰ࡥ࠴࠵ࡪ࠶࠳ࡣ࠶࠺ࡤ࠱࠹࠶࠲࠲࠯ࡤࡥ࠽࠺࠭ࡦ࠻࠵࠷ࡨࡧࡦ࠹࠷࠻࠷࠹ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡫ࡲ࠾࠺࠹࠵࠴ࠩᇍ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+cjbAkCIinvs(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇎ")+MgOXedqWFBs9yL043AV7u+EHUAyW2lQfe4LXmhgIGc(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇏ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==fdQOo6Hu4B5Rbg:
		scraperserver = FWqeEzO1i8Dn0ga(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠸ࠧᇐ")
		MgOXedqWFBs9yL043AV7u = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡂ࡯࡬࠻࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭ᇑ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+UighHKAfySm4PWErqJ(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇒ")+MgOXedqWFBs9yL043AV7u+DTF3Lwy9etRH8mI(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇓ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:
		scraperserver = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬ࠫᇔ")
		MgOXedqWFBs9yL043AV7u = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠾࡫࡯࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧᇕ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+dC3PsQJ0Ti28uYlov(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇖ")+MgOXedqWFBs9yL043AV7u+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇗ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==c1R9fnIY4XBDZ:
		scraperserver = bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ᇘ")
		XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua.replace(VHrIziKUDuNGXkMla(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧᇙ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧᇚ"))
		AauCDOGPIN4hnrmHoX1Lv7 = rxWDdRBIct57i90s(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢࡲ࡬࠲ࡸࡩࡲࡢࡲࡨࡹࡵ࠴ࡣࡰ࡯࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠩ࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡉࡥࡱࡹࡥࠧࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫࠽ࡪ࡮ࠩࡹࡷࡲ࠽ࠨᇛ")+SSX6oT0lADZhKRImPvCHFkYJs(XjWHSnbf6NwhMgpKt4yLY7AkIT)
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡉࡈࡘࠬᇜ"),AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==xsCEkXb6tgrh3195YZ:
		scraperserver = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵࠩᇝ")
		AauCDOGPIN4hnrmHoX1Lv7 = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺ࠮ࡤࡱࡰ࠳ࡄࡺ࡯࡬ࡧࡱࡁࡦ࠺ࡦ࠸ࡨࡥ࠵࠹࠳࠲ࡥࡧࡩ࠱࠹࠶࠷࠲࠯࠻࠺࠹ࡨ࠭࠳࠴ࡨ࠷࠷࠼࠴ࡥ࠶ࡧࡨࡨࠬࡰࡳࡱࡻࡽࡈࡵࡵ࡯ࡶࡵࡽࡂࡏࡌࠧࡷࡵࡰࡂ࠭ᇞ")+SSX6oT0lADZhKRImPvCHFkYJs(XXzvmn7ewM8yBfoxua)
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡌࡋࡔࠨᇟ"),AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
		try:
			w8w4tXrQA5ojk7mzFpbUguZ.content = bRCSwcA89e4J7pqdays5PxGiD2(iqHhJSxdaANDG5rlZm7B(u"ࠬࡪࡩࡤࡶࠪᇠ"),w8w4tXrQA5ojk7mzFpbUguZ.content)
			w8w4tXrQA5ojk7mzFpbUguZ.content = w8w4tXrQA5ojk7mzFpbUguZ.content[EHUAyW2lQfe4LXmhgIGc(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᇡ")]
		except: pass
	elif gxw5auqQd78v4SPBMU==EHUAyW2lQfe4LXmhgIGc(u"࠵ᓫ"):
		scraperserver = yiaeCEwJjOcWA4ZSd5h(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠶࠭ᇢ")
		MgOXedqWFBs9yL043AV7u = ETNq5t4MYngSsbfFD8J0v(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹࠬࡰࡳࡱࡻࡽࡤࡩ࡯ࡶࡰࡷࡶࡾࡃࡉࡍࠨࡥࡶࡴࡽࡳࡦࡴࡀࡊࡦࡲࡳࡦࠨࡩࡳࡷࡽࡡࡳࡦࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠼࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠲ࡨࡵ࡭࠻࠺࠳࠼࠵࠭ᇣ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+rr7Xolsp4JwjPK3L(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩᇤ")+MgOXedqWFBs9yL043AV7u+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪᇥ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==rxWDdRBIct57i90s(u"࠷ᓬ"):
		scraperserver = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠱ࠨᇦ")
		MgOXedqWFBs9yL043AV7u = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡣ࠳࠸࠶ࡥࡧ࠷ࡥ࠶࠲࠷࠸ࡩ࠸ࡣࡢ࠷ࡧ࠹ࡩ࠹ࡦ࠺ࡧ࠶ࡧ࠸࠾࠶ࡦࡥࡤ࠵࠶࠶࠸࠴࠺࠼ࡥ࠼࠹࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩࠫ࡭ࡥࡰࡅࡲࡨࡪࡃࡩ࡭ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩᇧ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᇨ")+MgOXedqWFBs9yL043AV7u+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᇩ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==cjbAkCIinvs(u"࠹ᓭ"):
		scraperserver = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠶ࠬᇪ")
		MgOXedqWFBs9yL043AV7u = jR9YtmsgDX8nTQlMb6G3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼࠾ࡨࡻࡳࡵࡱࡰࡌࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦࠨࡪࡩࡴࡉ࡯ࡥࡧࡀ࡭ࡱࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ᇫ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+FWqeEzO1i8Dn0ga(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇬ")+MgOXedqWFBs9yL043AV7u+rr7Xolsp4JwjPK3L(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇭ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠻ᓮ"):
		scraperserver = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩᇮ")
		AauCDOGPIN4hnrmHoX1Lv7 = RVpeGcmPxj9tCnT40Nf216(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭ࠨࡸࡶࡱࡃࠧᇯ")+SSX6oT0lADZhKRImPvCHFkYJs(XXzvmn7ewM8yBfoxua)
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(iAGgjwb7tVMmacRJ(u"ࠧࡈࡇࡗࠫᇰ"),AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	elif gxw5auqQd78v4SPBMU==ETNq5t4MYngSsbfFD8J0v(u"࠽ᓯ"):
		scraperserver = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠸ࠧᇱ")
		MgOXedqWFBs9yL043AV7u = yiaeCEwJjOcWA4ZSd5h(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡶࡪࡺࡵࡳࡰࡢࡴࡦ࡭ࡥࡠࡵࡲࡹࡷࡩࡥ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪᇲ")
		AauCDOGPIN4hnrmHoX1Lv7 = XXzvmn7ewM8yBfoxua+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇳ")+MgOXedqWFBs9yL043AV7u+FWqeEzO1i8Dn0ga(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇴ")
		w8w4tXrQA5ojk7mzFpbUguZ = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,AauCDOGPIN4hnrmHoX1Lv7,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	else:
		scraperserver,AauCDOGPIN4hnrmHoX1Lv7 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		w8w4tXrQA5ojk7mzFpbUguZ = LGmh2jCPAgpY()
		update = kkMuQrLWcEayRm
	if update and not w8w4tXrQA5ojk7mzFpbUguZ.succeeded:
		BrCIhmKkMPo(website,[],gxw5auqQd78v4SPBMU)
		if len(list(set(SnpbfahEeYLF0O5itkArjTJIPu2)))>fdQOo6Hu4B5Rbg:
			J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᇵ"),qTVF3icWwGXy5(u"࠭ไๅลึๅู๊ࠥาใิࠤ๊฿วๅฮฬࠤฬ๊ออสࠣี็๋ࠠࠨᇶ")+str(gxw5auqQd78v4SPBMU)+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࠡใื่ࠥ็๊ࠡ฻่่๏ฯࠠหฮส์ืࠦวๅฯฯฬࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢัฬ๎ไสࠢอะฬ๎าࠡษ็ััฮࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤุ๐ัโำ้ࠣำะไโࠢยࠥࠬᇷ"))
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg:
				EpcejN4h5wGdfBax.append(gxw5auqQd78v4SPBMU)
				w8w4tXrQA5ojk7mzFpbUguZ = sJu0WwVmpYXChEDHLBUM(urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,BlOvmjrZWVH7u,ALuIKiVCBPqE,XdoFLQ20O6SNVlcp,sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi,EpcejN4h5wGdfBax)
				return w8w4tXrQA5ojk7mzFpbUguZ
	w8w4tXrQA5ojk7mzFpbUguZ.scrapernumber = str(gxw5auqQd78v4SPBMU)
	w8w4tXrQA5ojk7mzFpbUguZ.scraperserver = scraperserver
	w8w4tXrQA5ojk7mzFpbUguZ.scraperurl = AauCDOGPIN4hnrmHoX1Lv7
	Jrk7W0IwKjEAV85nRpHCX3 = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨีํีๆืࠠาไ่ࠤࠬᇸ")+w8w4tXrQA5ojk7mzFpbUguZ.scrapernumber
	if w8w4tXrQA5ojk7mzFpbUguZ.succeeded:
		vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+UighHKAfySm4PWErqJ(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᇹ")+scraperserver+jR9YtmsgDX8nTQlMb6G3(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᇺ")+XdoFLQ20O6SNVlcp+cjbAkCIinvs(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᇻ")+XXzvmn7ewM8yBfoxua+RVpeGcmPxj9tCnT40Nf216(u"ࠬࠦ࡝ࠨᇼ"))
		XXeZuvhknsKYqB17gwm6dfc(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᇽ"),Jrk7W0IwKjEAV85nRpHCX3,SSCU3jdyFn2V=wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠼࠻࠰ᓰ"))
	else:
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iAGgjwb7tVMmacRJ(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫᇾ")+scraperserver+yiaeCEwJjOcWA4ZSd5h(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᇿ")+str(w8w4tXrQA5ojk7mzFpbUguZ.code)+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫሀ")+w8w4tXrQA5ojk7mzFpbUguZ.reason+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬሁ")+XdoFLQ20O6SNVlcp+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪሂ")+XXzvmn7ewM8yBfoxua+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࠦ࡝ࠨሃ"))
		XXeZuvhknsKYqB17gwm6dfc(vCmnFshSi4flecXIY2gy38G0DJw(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨሄ"),Jrk7W0IwKjEAV85nRpHCX3,SSCU3jdyFn2V=qTVF3icWwGXy5(u"࠽࠵࠱ᓱ"))
	return w8w4tXrQA5ojk7mzFpbUguZ
def PPRoOyl2xVH(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu=G9G0YqivIfmUWO8K,kUAmTPh7SuOxdLrCi9=G9G0YqivIfmUWO8K):
	XXzvmn7ewM8yBfoxua,rQmWAsndP6cgJNT8iEM7yVzhla1UkC,CEuGyZ4rFkON2K7qJHfBxmgpvPAQX,rpnIyPil9WTCLE = IpXs8rqBAYFlfNg0wch46bia(yzieWRVX4nkB3DjGHJphEdQo)
	try: PPTrWvjIyZUOn = m4iYHG1j9Cg6U7VEp.copy()
	except: PPTrWvjIyZUOn = m4iYHG1j9Cg6U7VEp
	xis68omJPAWO0gLN = urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,snev3rg1V28C9pxGO6RNfIDBS0z,PPTrWvjIyZUOn,AAN9XWm3DpYwZrPoztk
	if k5GDfLeHJ0ZP3vSYbz<ssGdubC4mngM9D5SRc3Ye(u"࠰ᓲ"):
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,ETNq5t4MYngSsbfFD8J0v(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪህ"),xis68omJPAWO0gLN)
		k5GDfLeHJ0ZP3vSYbz = -k5GDfLeHJ0ZP3vSYbz
	if k5GDfLeHJ0ZP3vSYbz>ETNq5t4MYngSsbfFD8J0v(u"࠱ᓳ"):
		DD1ExCgnvNZhY7Acwpq6yeTSmz = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪሆ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬሇ"),xis68omJPAWO0gLN)
		if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
			SNAjoRGWnlMtauXpc5sI87FdU(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪለ"),XXzvmn7ewM8yBfoxua,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp,urfTS1aCy6hklQRxKzmGFgWste)
			return DD1ExCgnvNZhY7Acwpq6yeTSmz
	DD1ExCgnvNZhY7Acwpq6yeTSmz = zjZ540rAadvbsRu6qywPicxXLtpTM(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,AAN9XWm3DpYwZrPoztk,showDialogs,XdoFLQ20O6SNVlcp,gp8MxzolmeB1IYhO6s0XRZFu,kUAmTPh7SuOxdLrCi9)
	if DD1ExCgnvNZhY7Acwpq6yeTSmz.succeeded:
		if ssGdubC4mngM9D5SRc3Ye(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬሉ") in XdoFLQ20O6SNVlcp: DD1ExCgnvNZhY7Acwpq6yeTSmz.content = mq1uWkCvVfw(DD1ExCgnvNZhY7Acwpq6yeTSmz.content)
		if DD1ExCgnvNZhY7Acwpq6yeTSmz.scrape: k5GDfLeHJ0ZP3vSYbz = AH0BQ4LKlDMrfvqWmXn5
		if k5GDfLeHJ0ZP3vSYbz and DD1ExCgnvNZhY7Acwpq6yeTSmz.content: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,cjbAkCIinvs(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨሊ"),xis68omJPAWO0gLN,DD1ExCgnvNZhY7Acwpq6yeTSmz,k5GDfLeHJ0ZP3vSYbz)
	return DD1ExCgnvNZhY7Acwpq6yeTSmz
def ccdVMC96FlRTykuaExOWzmXQ(k5GDfLeHJ0ZP3vSYbz,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,showDialogs,XdoFLQ20O6SNVlcp):
	if not snev3rg1V28C9pxGO6RNfIDBS0z or isinstance(snev3rg1V28C9pxGO6RNfIDBS0z,dict): urfTS1aCy6hklQRxKzmGFgWste = rr7Xolsp4JwjPK3L(u"࠭ࡇࡆࡖࠪላ")
	else:
		urfTS1aCy6hklQRxKzmGFgWste = bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡑࡑࡖࡘࠬሌ")
		snev3rg1V28C9pxGO6RNfIDBS0z = aKAyEnjxIlzZtCTv(snev3rg1V28C9pxGO6RNfIDBS0z)
		b8PVxoJDTyS7UcWOGuaQlvI53E1,snev3rg1V28C9pxGO6RNfIDBS0z = uNeAyo6mgQTwGtDFhfcU5ZasI(snev3rg1V28C9pxGO6RNfIDBS0z)
	DD1ExCgnvNZhY7Acwpq6yeTSmz = PPRoOyl2xVH(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,P5VqbRSzjtO4UE1rZaolG67XA,showDialogs,XdoFLQ20O6SNVlcp)
	RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.content
	RpnYai0qJ4G6mIw = str(RpnYai0qJ4G6mIw)
	return RpnYai0qJ4G6mIw
def IpXs8rqBAYFlfNg0wch46bia(yzieWRVX4nkB3DjGHJphEdQo):
	njlmkaEcPwSzNvQ6HyU = yzieWRVX4nkB3DjGHJphEdQo.split(qTVF3icWwGXy5(u"ࠨࡾࡿࠫል"))
	XXzvmn7ewM8yBfoxua,rQmWAsndP6cgJNT8iEM7yVzhla1UkC,CEuGyZ4rFkON2K7qJHfBxmgpvPAQX,rpnIyPil9WTCLE = njlmkaEcPwSzNvQ6HyU[dQ5JhEYolPmy1fvHktMw6NFRxiz],None,None,P5VqbRSzjtO4UE1rZaolG67XA
	for xis68omJPAWO0gLN in njlmkaEcPwSzNvQ6HyU:
		if jR9YtmsgDX8nTQlMb6G3(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧሎ") in xis68omJPAWO0gLN: rQmWAsndP6cgJNT8iEM7yVzhla1UkC = xis68omJPAWO0gLN[dC3PsQJ0Ti28uYlov(u"࠳࠴ᓴ"):]
		elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ሏ") in xis68omJPAWO0gLN: CEuGyZ4rFkON2K7qJHfBxmgpvPAQX = xis68omJPAWO0gLN[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠼ᓵ"):]
		elif cjbAkCIinvs(u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩሐ") in xis68omJPAWO0gLN: rpnIyPil9WTCLE = kkMuQrLWcEayRm
	return XXzvmn7ewM8yBfoxua,rQmWAsndP6cgJNT8iEM7yVzhla1UkC,CEuGyZ4rFkON2K7qJHfBxmgpvPAQX,rpnIyPil9WTCLE
def P8mV07Q3n4xcsfiOe(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,p02XgeOM9uKT,W3zSmAsB7uyfGxPhetRKL4YX,t3UZl1JbyzNvQWMm,m4iYHG1j9Cg6U7VEp=G9G0YqivIfmUWO8K):
	tJG2VLvFswRdYkU = xWiOjcUrJVdtP4B5Iml(yzieWRVX4nkB3DjGHJphEdQo,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡻࡲ࡭ࠩሑ"))
	hzOMx3BknjZywDgcqPeFbs = amx9qJHkhw7oLdtVMG3.getSetting(rxWDdRBIct57i90s(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨሒ")+p02XgeOM9uKT)
	if tJG2VLvFswRdYkU==hzOMx3BknjZywDgcqPeFbs: amx9qJHkhw7oLdtVMG3.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩሓ")+p02XgeOM9uKT,G9G0YqivIfmUWO8K)
	if hzOMx3BknjZywDgcqPeFbs: XjWHSnbf6NwhMgpKt4yLY7AkIT = yzieWRVX4nkB3DjGHJphEdQo.replace(tJG2VLvFswRdYkU,hzOMx3BknjZywDgcqPeFbs)
	else:
		XjWHSnbf6NwhMgpKt4yLY7AkIT = yzieWRVX4nkB3DjGHJphEdQo
		hzOMx3BknjZywDgcqPeFbs = tJG2VLvFswRdYkU
	PisJcWj8of9xTKUNmpyI = PPRoOyl2xVH(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,m4iYHG1j9Cg6U7VEp,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬሔ"))
	RpnYai0qJ4G6mIw = PisJcWj8of9xTKUNmpyI.content
	if LTze51miOknVcslNF43WSA6vMjYZt:
		try: RpnYai0qJ4G6mIw = RpnYai0qJ4G6mIw.decode(f3uIcZ2C6pzbX1JlFBrVOdt,FWqeEzO1i8Dn0ga(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩሕ"))
		except: pass
	if not PisJcWj8of9xTKUNmpyI.succeeded or t3UZl1JbyzNvQWMm not in RpnYai0qJ4G6mIw:
		W3zSmAsB7uyfGxPhetRKL4YX = W3zSmAsB7uyfGxPhetRKL4YX.replace(ww0sZkBU9JKd,UighHKAfySm4PWErqJ(u"ࠪ࠯ࠬሖ"))
		XXzvmn7ewM8yBfoxua = VHrIziKUDuNGXkMla(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩሗ")+W3zSmAsB7uyfGxPhetRKL4YX
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {bneABYmwFUH8GXphg0Kl2Sq(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩመ"):G9G0YqivIfmUWO8K}
		WvxUIHz0cMJB = PPRoOyl2xVH(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠲࡯ࡦࠪሙ"))
		if WvxUIHz0cMJB.succeeded:
			RpnYai0qJ4G6mIw = WvxUIHz0cMJB.content
			if LTze51miOknVcslNF43WSA6vMjYZt:
				try: RpnYai0qJ4G6mIw = RpnYai0qJ4G6mIw.decode(f3uIcZ2C6pzbX1JlFBrVOdt,bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧሚ"))
				except: pass
			dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩማ"),RpnYai0qJ4G6mIw,oo9kuULlebNgpY0Om.DOTALL)
			sAcg3tMmzuYSVo5GjlIyqZiF76vXHx = [hzOMx3BknjZywDgcqPeFbs]
			DDONZs5EpTfQSKzPIj4tquBe9m = [RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡤࡴࡰ࠭ሜ"),VHrIziKUDuNGXkMla(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪም"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬሞ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ሟ"),FWqeEzO1i8Dn0ga(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨሠ"),rr7Xolsp4JwjPK3L(u"ࠧࡱࡪࡳࠫሡ"),iqHhJSxdaANDG5rlZm7B(u"ࠨࡣࡷࡰࡦࡷࠧሢ"),UighHKAfySm4PWErqJ(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧሣ"),cjbAkCIinvs(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪሤ"),ssGdubC4mngM9D5SRc3Ye(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭ሥ"),FWqeEzO1i8Dn0ga(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧሦ"),cJSNFCIhymEfx6grGu0M(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨሧ"),rxWDdRBIct57i90s(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪረ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪሩ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭ሪ"),qTVF3icWwGXy5(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭ራ")]
			for I2JutUeCgPyZoVL5Rvr9S in dsGzqX4k0a8RLyc:
				if any(yW70dtahIjkPCJg2TA in I2JutUeCgPyZoVL5Rvr9S for yW70dtahIjkPCJg2TA in DDONZs5EpTfQSKzPIj4tquBe9m): continue
				hzOMx3BknjZywDgcqPeFbs = xWiOjcUrJVdtP4B5Iml(I2JutUeCgPyZoVL5Rvr9S,rr7Xolsp4JwjPK3L(u"ࠫࡺࡸ࡬ࠨሬ"))
				if hzOMx3BknjZywDgcqPeFbs in sAcg3tMmzuYSVo5GjlIyqZiF76vXHx: continue
				if len(sAcg3tMmzuYSVo5GjlIyqZiF76vXHx)==iAGgjwb7tVMmacRJ(u"࠽ᓶ"):
					vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dC3PsQJ0Ti28uYlov(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬር")+p02XgeOM9uKT+UighHKAfySm4PWErqJ(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫሮ")+tJG2VLvFswRdYkU+VHrIziKUDuNGXkMla(u"ࠧࠡ࡟ࠪሯ"))
					amx9qJHkhw7oLdtVMG3.setSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪሰ")+p02XgeOM9uKT,G9G0YqivIfmUWO8K)
					break
				sAcg3tMmzuYSVo5GjlIyqZiF76vXHx.append(hzOMx3BknjZywDgcqPeFbs)
				XjWHSnbf6NwhMgpKt4yLY7AkIT = yzieWRVX4nkB3DjGHJphEdQo.replace(tJG2VLvFswRdYkU,hzOMx3BknjZywDgcqPeFbs)
				PisJcWj8of9xTKUNmpyI = PPRoOyl2xVH(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,m4iYHG1j9Cg6U7VEp,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭ሱ"))
				RpnYai0qJ4G6mIw = PisJcWj8of9xTKUNmpyI.content
				if PisJcWj8of9xTKUNmpyI.succeeded and t3UZl1JbyzNvQWMm in RpnYai0qJ4G6mIw:
					vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡦࡰࡷࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪሲ")+p02XgeOM9uKT+jR9YtmsgDX8nTQlMb6G3(u"ࠫࠥࡣࠠࠡࠢࡑࡩࡼࡀࠠ࡜ࠢࠪሳ")+hzOMx3BknjZywDgcqPeFbs+DTF3Lwy9etRH8mI(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪሴ")+tJG2VLvFswRdYkU+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࠠ࡞ࠩስ"))
					amx9qJHkhw7oLdtVMG3.setSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩሶ")+p02XgeOM9uKT,hzOMx3BknjZywDgcqPeFbs)
					break
	return hzOMx3BknjZywDgcqPeFbs,XjWHSnbf6NwhMgpKt4yLY7AkIT,PisJcWj8of9xTKUNmpyI
def GoAEsgO4hHICi65(xCVyDu98lp4NE3MR6A0):
	YYroBSiJWpDNZc9albVIwMskzv = {
	 qTVF3icWwGXy5(u"ࠨࡣ࡫ࡻࡦࡱࠧሷ")				:dhANiYPG7xXrSyJfIjZ8nBboLv(u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫሸ")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠪࡥࡰࡵࡡ࡮ࠩሹ")				:hhdGMSsBzel96obfEmrwiuLPOvq(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨሺ")
	,cJSNFCIhymEfx6grGu0M(u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧሻ")				:ssGdubC4mngM9D5SRc3Ye(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧሼ")
	,UighHKAfySm4PWErqJ(u"ࠧࡢ࡭ࡺࡥࡲ࠭ሽ")				:hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬሾ")
	,rr7Xolsp4JwjPK3L(u"ࠩࡤ࡯ࡼࡧ࡭ࡵࡷࡥࡩࠬሿ")			:t2sCrJ0xbgDRkf(u"้ࠪํู่ࠡษๆ์ฬ๋ࠠห์๋ฬࠬቀ")
	,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡦࡲࡡࡳࡣࡥࠫቁ")				:dC3PsQJ0Ti28uYlov(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬቂ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨቃ")				:Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ቄ")
	,ETNq5t4MYngSsbfFD8J0v(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫቅ")			:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬቆ")
	,VHrIziKUDuNGXkMla(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬቇ")				:EHUAyW2lQfe4LXmhgIGc(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨቈ")
	,rxWDdRBIct57i90s(u"ࠬࡧ࡬࡮ࡵࡷࡦࡦ࠭቉")				:yiaeCEwJjOcWA4ZSd5h(u"࠭ๅ้ไ฼ࠤฬ๊ๅึูหอࠬቊ")
	,dC3PsQJ0Ti28uYlov(u"ࠧࡢࡰ࡬ࡱࡪࢀࡩࡥࠩቋ")				:hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ็๋ๆ฾ࠦว็็ํࠤืีࠧቌ")
	,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡤࡶࡦࡨࡩࡤࡶࡲࡳࡳࡹࠧቍ")			:VHrIziKUDuNGXkMla(u"้ࠪํู่ࠡฬ๋๊ืูࠦาสํอࠬ቎")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭቏")				:ETNq5t4MYngSsbfFD8J0v(u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬቐ")
	,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨቑ")				:bneABYmwFUH8GXphg0Kl2Sq(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨቒ")
	,DTF3Lwy9etRH8mI(u"ࠨࡣࡼࡰࡴࡲࠧቓ")				:t2sCrJ0xbgDRkf(u"่ࠩ์็฿ࠠฤ์็์้࠭ቔ")
	,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡦࡴࡱࡲࡢࠩቕ")				:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"๊ࠫ๎โฺࠢห็ึอࠧቖ")
	,iqHhJSxdaANDG5rlZm7B(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬ቗")				:ssGdubC4mngM9D5SRc3Ye(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫቘ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨ቙")				:t2sCrJ0xbgDRkf(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨቚ")
	,UighHKAfySm4PWErqJ(u"ࠩࡦ࡭ࡲࡧ࠴ࡱࠩቛ")				:yiaeCEwJjOcWA4ZSd5h(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำࠣฬ๏࠭ቜ")
	,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫቝ")				:RVpeGcmPxj9tCnT40Nf216(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧ቞")
	,dC3PsQJ0Ti28uYlov(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ቟")				:dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨበ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪቡ")				:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪቢ")
	,qTVF3icWwGXy5(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩባ")			:dhANiYPG7xXrSyJfIjZ8nBboLv(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩቤ")
	,DTF3Lwy9etRH8mI(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧብ")				:DTF3Lwy9etRH8mI(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧቦ")
	,iqHhJSxdaANDG5rlZm7B(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩቧ")				:ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩቨ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡦ࡭ࡲࡧࡦࡳࡧࡨࠫቩ")				:EHUAyW2lQfe4LXmhgIGc(u"้ࠪํู่ࠡีํ้ฬࠦแา์ࠪቪ")
	,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧቫ")			:rr7Xolsp4JwjPK3L(u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ቬ")
	,qTVF3icWwGXy5(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧቭ")				:VHrIziKUDuNGXkMla(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧቮ")
	,ETNq5t4MYngSsbfFD8J0v(u"ࠨࡥ࡬ࡱࡦࡽࡢࡢࡵࠪቯ")				:rxWDdRBIct57i90s(u"่ࠩ์็฿ࠠิ์่หࠥ๎ศิࠩተ")
	,rr7Xolsp4JwjPK3L(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨቱ")			:yiaeCEwJjOcWA4ZSd5h(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋࠭ቲ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬታ")	:rr7Xolsp4JwjPK3L(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็ึฮำีๅ๋่ࠪቴ")
	,iAGgjwb7tVMmacRJ(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲࡮ࡡࡴࡪࡷࡥ࡬ࡹࠧት")	:RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่๋ࠣฬฺสศๅࠪቶ")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭࡭࡫ࡹࡩࡸ࠭ቷ")	:cjbAkCIinvs(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋ࠥศศึิࠫቸ")
	,ssGdubC4mngM9D5SRc3Ye(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬቹ"):RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠใ๊สส๊࠭ቺ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫቻ")	:FWqeEzO1i8Dn0ga(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็่ࠢ์ฬ฼ฺ๊ࠩቼ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡶࡪࡦࡨࡳࡸ࠭ች")	:cJSNFCIhymEfx6grGu0M(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ቾ")
	,rxWDdRBIct57i90s(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬቿ")				:dhANiYPG7xXrSyJfIjZ8nBboLv(u"๊ࠫะ่ใใࠪኀ")
	,rxWDdRBIct57i90s(u"ࠬࡪࡲࡢ࡯ࡤࡧࡦ࡬ࡥࠨኁ")			:CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ๅ้ไ฼ࠤิืวๆษࠣ็ฬ็๊่ࠩኂ")
	,VHrIziKUDuNGXkMla(u"ࠧࡥࡴࡤࡱࡦࡹ࠷ࠨኃ")				:dC3PsQJ0Ti28uYlov(u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨኄ")
	,dC3PsQJ0Ti28uYlov(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪኅ")				:RVpeGcmPxj9tCnT40Nf216(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫኆ")
	,VHrIziKUDuNGXkMla(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭ኇ")				:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨኈ")
	,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠲ࠨ኉")				:yiaeCEwJjOcWA4ZSd5h(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠴ࠪኊ")
	,RVpeGcmPxj9tCnT40Nf216(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪኋ")				:jR9YtmsgDX8nTQlMb6G3(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬኌ")
	,RVpeGcmPxj9tCnT40Nf216(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠸ࠬኍ")				:yiaeCEwJjOcWA4ZSd5h(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧ኎")
	,VHrIziKUDuNGXkMla(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩ኏")			:rr7Xolsp4JwjPK3L(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫነ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨኑ")				:iAGgjwb7tVMmacRJ(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨኒ")
	,rxWDdRBIct57i90s(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩና")				:rr7Xolsp4JwjPK3L(u"้ࠪํู่ࠡวํะ๏ࠦๆศ๊ࠪኔ")
	,iAGgjwb7tVMmacRJ(u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭ን")				:RMxjDCgEBtiFmWvrdVeU0cwTqz(u"๋่ࠬใ฻้ࠣํฺู่หࠣหู้๊็็สࠫኖ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡥ࡭࡫ࡩࡺ࡮ࡪࡥࡰࠩኗ")			:dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧๆ๊ๅ฽ࠥษไ๋ใࠣๅ๏ี๊้ࠩኘ")
	,UighHKAfySm4PWErqJ(u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩኙ")				:yiaeCEwJjOcWA4ZSd5h(u"่ࠩ์็฿ࠠโสิ็ฮ࠭ኚ")
	,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪኛ")				:CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫๆฺไࠨኜ")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨኝ")			:jR9YtmsgDX8nTQlMb6G3(u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫኞ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡧࡣࡵࡩࡸࡱ࡯ࠨኟ")				:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ็๋ๆ฾ࠦแศำํื่๎ࠧአ")
	,UighHKAfySm4PWErqJ(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫኡ")				:Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬኢ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠭ኣ")				:yiaeCEwJjOcWA4ZSd5h(u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨኤ")
	,UighHKAfySm4PWErqJ(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭እ")				:bneABYmwFUH8GXphg0Kl2Sq(u"ࠧๆฮ็ำࠬኦ")
	,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡨࡲࡷࡹࡧࠧኧ")				:ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"่ࠩ์็฿ࠠโ๊ึฮฬ࠭ከ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡪࡺࡴ࡯࡯ࡶࡹࠫኩ")				:hhdGMSsBzel96obfEmrwiuLPOvq(u"๊ࠫ๎โฺࠢไ๊ํ์ࠠห์ไ๎ࠬኪ")
	,ssGdubC4mngM9D5SRc3Ye(u"ࠬ࡬ࡵࡴࡪࡤࡶࡹࡼࠧካ")				:hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ๅ้ไ฼ࠤๆ๎ิศำࠣฮ๏็๊ࠨኬ")
	,ssGdubC4mngM9D5SRc3Ye(u"ࠧࡧࡷࡶ࡬ࡦࡸࡶࡪࡦࡨࡳࠬክ")			:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨ็๋ๆ฾ࠦแ้ึสีࠥ็๊ะ์๋ࠫኮ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡪࡳࡴࡪࠧኯ")					:iqHhJSxdaANDG5rlZm7B(u"ࠪะ๏ีࠧኰ")
	,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭኱")				:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬኲ")
	,EHUAyW2lQfe4LXmhgIGc(u"࠭ࡨࡦ࡮ࡤࡰࠬኳ")				:bneABYmwFUH8GXphg0Kl2Sq(u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪኴ")
	,cjbAkCIinvs(u"ࠨ࡫ࡩ࡭ࡱࡳࠧኵ")				:yiaeCEwJjOcWA4ZSd5h(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭኶")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ࡭࡫࡯࡬࡮࠯ࡤࡶࡦࡨࡩࡤࠩ኷")			:rr7Xolsp4JwjPK3L(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ኸ")
	,cJSNFCIhymEfx6grGu0M(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡪࡴࡧ࡭࡫ࡶ࡬ࠬኹ")		:ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣห๋าไ๋ิํࠫኺ")
	,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡪࡲࡷࡺࠬኻ")					:t2sCrJ0xbgDRkf(u"ࠨࡋࡓࡘ࡛࠭ኼ")
	,yiaeCEwJjOcWA4ZSd5h(u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬኽ")			:RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧኾ")
	,dC3PsQJ0Ti28uYlov(u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩ኿")			:rxWDdRBIct57i90s(u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩዀ")
	,DTF3Lwy9etRH8mI(u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫ዁")			:EHUAyW2lQfe4LXmhgIGc(u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭ዂ")
	,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫዃ")			:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬዄ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬዅ")				:hh4FrbOWHjmD5KcS13MN9CexsT7p(u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭዆")
	,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ዇")				:Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪወ")
	,jR9YtmsgDX8nTQlMb6G3(u"ࠧ࡬࡫ࡵࡱࡦࡲ࡫ࠨዉ")				:hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ็๋ๆ฾ࠦใา็ส่่࠭ዊ")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠩ࡯ࡥࡷࡵࡺࡢࠩዋ")				:ETNq5t4MYngSsbfFD8J0v(u"้ࠪํู่ࠡๆสีํุวࠨዌ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡱ࡯ࡢࡳࡣࡵࡽࠬው")				:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"๋ࠬไโࠩዎ")
	,rr7Xolsp4JwjPK3L(u"࠭࡬ࡪࡸࡨࠫዏ")					:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧใ่สอࠬዐ")
	,RVpeGcmPxj9tCnT40Nf216(u"ࠨ࡮࡬ࡺࡪࡺࡶࠨዑ")				:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"่่ࠩๆ࠭ዒ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫዓ")				:t2sCrJ0xbgDRkf(u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪዔ")
	,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡳ࠳ࡶࠩዕ")					:DTF3Lwy9etRH8mI(u"࠭ࡍ࠴ࡗࠪዖ")
	,DTF3Lwy9etRH8mI(u"ࠧ࡮࠵ࡸ࠱ࡱ࡯ࡶࡦࠩ዗")				:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡏ࠶่࡙ࠥๆ้ษอࠫዘ")
	,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡰ࠷ࡺ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ዙ")			:dC3PsQJ0Ti28uYlov(u"ࠪࡑ࠸࡛ࠠฤใ็ห๊࠭ዚ")
	,t2sCrJ0xbgDRkf(u"ࠫࡲ࠹ࡵ࠮ࡵࡨࡶ࡮࡫ࡳࠨዛ")			:t2sCrJ0xbgDRkf(u"ࠬࡓ࠳ࡖ่ࠢืู้ไศฬࠪዜ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭࡭ࡢࡵࡤࡺ࡮ࡪࡥࡰࠩዝ")			:dC3PsQJ0Ti28uYlov(u"ࠧๆ๊ๅ฽๋ࠥวิษࠣๅ๏ี๊้ࠩዞ")
	,jR9YtmsgDX8nTQlMb6G3(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩዟ")				:Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"่ࠩๅ็๎ฯࠨዠ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪዡ")				:bneABYmwFUH8GXphg0Kl2Sq(u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭ዢ")
	,RVpeGcmPxj9tCnT40Nf216(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬዣ")				:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭ዤ")
	,DTF3Lwy9etRH8mI(u"ࠧࡰ࡮ࡧࠫዥ")					:dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨไา๎๊࠭ዦ")
	,yiaeCEwJjOcWA4ZSd5h(u"ࠩࡳࡥࡳ࡫ࡴࠨዧ")				:jR9YtmsgDX8nTQlMb6G3(u"้ࠪํู่ࠡสส๊๏ะࠧየ")
	,t2sCrJ0xbgDRkf(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪዩ")			:FWqeEzO1i8Dn0ga(u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨዪ")
	,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬያ")			:bneABYmwFUH8GXphg0Kl2Sq(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬዬ")
	,iAGgjwb7tVMmacRJ(u"ࠨࡳࡩ࡭ࡱࡳࠧይ")				:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"่ࠩ์็฿ࠠไ์๋ࠤๆ๐ไๆࠩዮ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫ࠧዯ")			:ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"๊ࠫ๎โฺࠢึ๎ึ๐ำࠡฬส๎๊࠭ደ")
	,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡹࡨࡢࡤࡤ࡯ࡦࡺࡹࠨዱ")			:UighHKAfySm4PWErqJ(u"࠭ๅ้ไ฼ࠤูฮให์ࠪዲ")
	,VHrIziKUDuNGXkMla(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩዳ")				:DTF3Lwy9etRH8mI(u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪዴ")
	,iqHhJSxdaANDG5rlZm7B(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭ድ")			:bneABYmwFUH8GXphg0Kl2Sq(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫዶ")
	,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧዷ")			:vCmnFshSi4flecXIY2gy38G0DJw(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧዸ")
	,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩዹ")		:EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨዺ")
	,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫዻ")		:rxWDdRBIct57i90s(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫዼ")
	,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧዽ")	:bneABYmwFUH8GXphg0Kl2Sq(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫዾ")
	,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡹࡨࡰࡨ࡫ࡥࠬዿ")				:FWqeEzO1i8Dn0ga(u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨጀ")
	,qTVF3icWwGXy5(u"ࠧࡴࡪࡲࡳ࡫ࡳࡡࡹࠩጁ")				:bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨጂ")
	,EHUAyW2lQfe4LXmhgIGc(u"ࠩࡶ࡬ࡴࡵࡦ࡯ࡧࡷࠫጃ")				:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"้ࠪํู่ࠡึ๋ๅࠥ์สࠨጄ")
	,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ጅ")				:cjbAkCIinvs(u"๋่ࠬใ฻ุࠣํ็ࠠษำ๋ࠫጆ")
	,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡴࡪ࡭ࡤࡥࡹ࠭ጇ")				:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧๆ๊ๅ฽ࠥะใศฬࠪገ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡶࡹࡪࡺࡴࠧጉ")				:jR9YtmsgDX8nTQlMb6G3(u"่ࠩ์็฿ࠠห์ไ๎ࠥ็ว็ࠩጊ")
	,ssGdubC4mngM9D5SRc3Ye(u"ࠪࡺࡦࡸࡢࡰࡰࠪጋ")				:wIu47Z8T0cVjg5iNX6omfkPbsDO(u"๊ࠫ๎โฺࠢไหึฮ่็ࠩጌ")
	,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡼࡩࡥࡧࡲࠫግ")				:hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭แ๋ัํ์ࠬጎ")
	,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡷ࡫ࡧࡩࡴࡴࡳࡢࡧࡰࠫጏ")			:dC3PsQJ0Ti28uYlov(u"ࠨ็๋ๆ฾ࠦแ๋ัํ์ࠥ์ำศศ่ࠫጐ")
	,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠳ࠪ጑")				:hh4FrbOWHjmD5KcS13MN9CexsT7p(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠴ࠫጒ")
	,qTVF3icWwGXy5(u"ࠫࡼ࡫ࡣࡪ࡯ࡤ࠶ࠬጓ")				:DTF3Lwy9etRH8mI(u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠤ࠷࠭ጔ")
	,EHUAyW2lQfe4LXmhgIGc(u"࠭ࡹࡢࡳࡲࡸࠬጕ")				:VHrIziKUDuNGXkMla(u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ጖")
	,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ጗")				:wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠧጘ")
	,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ጙ")		:vCmnFshSi4flecXIY2gy38G0DJw(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ๊ํอสࠨጚ")
	,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩጛ")	:ETNq5t4MYngSsbfFD8J0v(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็๎วว็ࠪጜ")
	,cJSNFCIhymEfx6grGu0M(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨጝ")		:ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨጞ")
	,rr7Xolsp4JwjPK3L(u"ࠩࡼࡸࡧࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨጟ")			:UighHKAfySm4PWErqJ(u"้ࠪํอโฺ่๊ࠢࠥ๐่ห์๋ฬࠬጠ")
	}
	PPt8XZgE6MpU = xCVyDu98lp4NE3MR6A0.lower()
	for key in list(YYroBSiJWpDNZc9albVIwMskzv.keys()):
		hnO7ufdqZFPKswtX2YT4eNIMC9 = key.lower()
		if PPt8XZgE6MpU==hnO7ufdqZFPKswtX2YT4eNIMC9:
			xCVyDu98lp4NE3MR6A0 = YYroBSiJWpDNZc9albVIwMskzv[key]
			break
	return xCVyDu98lp4NE3MR6A0
def NNetFngY7vowQPJp5xCumG2qrKcfk1():
	PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(RVpeGcmPxj9tCnT40Nf216(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡉ࡬ࡦࡣࡵࠦ࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡳࡰࡦࡿ࡬ࡪࡵࡷ࡭ࡩࠨ࠺࠲ࡿࢀࠫጡ"))
	raise ValueError(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨጢ"))
def Wz9Lj5vK4qeIBn1rTP20y78aogJ(REAvc8zkCV04n7xJw2pFGP5YTNqb,e2wT4McthFLlI8dVvpD0RfiuNnC=G9G0YqivIfmUWO8K):
	global UWfvC06tXBdKkDeGlzgsrbF92J8Rm5
	UWfvC06tXBdKkDeGlzgsrbF92J8Rm5 = P5VqbRSzjtO4UE1rZaolG67XA
	if not e2wT4McthFLlI8dVvpD0RfiuNnC and REAvc8zkCV04n7xJw2pFGP5YTNqb: e2wT4McthFLlI8dVvpD0RfiuNnC = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧጣ")
	amx9qJHkhw7oLdtVMG3.setSetting(UighHKAfySm4PWErqJ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫጤ"),e2wT4McthFLlI8dVvpD0RfiuNnC)
	return
def SSX6oT0lADZhKRImPvCHFkYJs(yzieWRVX4nkB3DjGHJphEdQo,hpPBkxwsUTfd=ssGdubC4mngM9D5SRc3Ye(u"ࠨ࠼࠲ࠫጥ")):
	return _P2Smn1ZkNGscwI3KFApTY4e(yzieWRVX4nkB3DjGHJphEdQo,hpPBkxwsUTfd)
def Gbn1H2vNxtjzX3aLAKc7kiOsRdIF(e2eGmXWys8Kdlj4qiFb7pDf):
	if e2eGmXWys8Kdlj4qiFb7pDf in [G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠩ࠳ࠫጦ"),dQ5JhEYolPmy1fvHktMw6NFRxiz]: return G9G0YqivIfmUWO8K
	e2eGmXWys8Kdlj4qiFb7pDf = int(e2eGmXWys8Kdlj4qiFb7pDf)
	Qbp3TYnCEcLyI8PF5WJSskZl = e2eGmXWys8Kdlj4qiFb7pDf^AH0BQ4LKlDMrfvqWmXn5
	qqBvbRtUeZ = e2eGmXWys8Kdlj4qiFb7pDf^TTm2opnt9fLX8DBYizbuSPvwhJZCl
	OuRNno7VtTxAcIKUSf14Qa0EhyBe = e2eGmXWys8Kdlj4qiFb7pDf^HpjLKS83swXDzVInEf2xUZaCuNbR9d
	rD3NAm1sywq4Bn7Yv98F2eizXlc = str(Qbp3TYnCEcLyI8PF5WJSskZl)+str(qqBvbRtUeZ)+str(OuRNno7VtTxAcIKUSf14Qa0EhyBe)
	return rD3NAm1sywq4Bn7Yv98F2eizXlc
def tDfCT52ISG4WJYEFpvcojuL8(e2eGmXWys8Kdlj4qiFb7pDf):
	if e2eGmXWys8Kdlj4qiFb7pDf in [G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠪ࠴ࠬጧ"),dQ5JhEYolPmy1fvHktMw6NFRxiz]: return G9G0YqivIfmUWO8K
	e2eGmXWys8Kdlj4qiFb7pDf = str(e2eGmXWys8Kdlj4qiFb7pDf)
	rD3NAm1sywq4Bn7Yv98F2eizXlc = G9G0YqivIfmUWO8K
	if len(e2eGmXWys8Kdlj4qiFb7pDf)==bneABYmwFUH8GXphg0Kl2Sq(u"࠶࠻ᓷ"):
		Qbp3TYnCEcLyI8PF5WJSskZl,qqBvbRtUeZ,OuRNno7VtTxAcIKUSf14Qa0EhyBe = e2eGmXWys8Kdlj4qiFb7pDf[dQ5JhEYolPmy1fvHktMw6NFRxiz:xsCEkXb6tgrh3195YZ],e2eGmXWys8Kdlj4qiFb7pDf[xsCEkXb6tgrh3195YZ:RVpeGcmPxj9tCnT40Nf216(u"࠿ᓸ")],e2eGmXWys8Kdlj4qiFb7pDf[RVpeGcmPxj9tCnT40Nf216(u"࠿ᓸ"):]
		Qbp3TYnCEcLyI8PF5WJSskZl = int(Qbp3TYnCEcLyI8PF5WJSskZl)^HpjLKS83swXDzVInEf2xUZaCuNbR9d
		qqBvbRtUeZ = int(qqBvbRtUeZ)^TTm2opnt9fLX8DBYizbuSPvwhJZCl
		OuRNno7VtTxAcIKUSf14Qa0EhyBe = int(OuRNno7VtTxAcIKUSf14Qa0EhyBe)^AH0BQ4LKlDMrfvqWmXn5
		if Qbp3TYnCEcLyI8PF5WJSskZl==qqBvbRtUeZ==OuRNno7VtTxAcIKUSf14Qa0EhyBe: rD3NAm1sywq4Bn7Yv98F2eizXlc = str(Qbp3TYnCEcLyI8PF5WJSskZl*Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠶࠱ᓹ"))
	return rD3NAm1sywq4Bn7Yv98F2eizXlc
def FCV0wTRHopA2ljcvrP(e2eGmXWys8Kdlj4qiFb7pDf,Gb47QY5PBlZWaKgMLizNfdxps6TyRX=EHUAyW2lQfe4LXmhgIGc(u"ࠫ࠻࠹࠸࠵࠳࠻࠶࠸࠭ጨ")):
	if e2eGmXWys8Kdlj4qiFb7pDf==G9G0YqivIfmUWO8K: return G9G0YqivIfmUWO8K
	e2eGmXWys8Kdlj4qiFb7pDf = int(e2eGmXWys8Kdlj4qiFb7pDf)+int(Gb47QY5PBlZWaKgMLizNfdxps6TyRX)
	Qbp3TYnCEcLyI8PF5WJSskZl = e2eGmXWys8Kdlj4qiFb7pDf^AH0BQ4LKlDMrfvqWmXn5
	qqBvbRtUeZ = e2eGmXWys8Kdlj4qiFb7pDf^TTm2opnt9fLX8DBYizbuSPvwhJZCl
	OuRNno7VtTxAcIKUSf14Qa0EhyBe = e2eGmXWys8Kdlj4qiFb7pDf^HpjLKS83swXDzVInEf2xUZaCuNbR9d
	rD3NAm1sywq4Bn7Yv98F2eizXlc = str(Qbp3TYnCEcLyI8PF5WJSskZl)+str(qqBvbRtUeZ)+str(OuRNno7VtTxAcIKUSf14Qa0EhyBe)
	return rD3NAm1sywq4Bn7Yv98F2eizXlc
def o0Ez9jLOuAvaYgpGXrt4Ww8kQ(e2eGmXWys8Kdlj4qiFb7pDf,Gb47QY5PBlZWaKgMLizNfdxps6TyRX=FWqeEzO1i8Dn0ga(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧጩ")):
	if e2eGmXWys8Kdlj4qiFb7pDf==G9G0YqivIfmUWO8K: return G9G0YqivIfmUWO8K
	e2eGmXWys8Kdlj4qiFb7pDf = str(e2eGmXWys8Kdlj4qiFb7pDf)
	xJvUrkfQoqeWCXw8Bzm1 = int(len(e2eGmXWys8Kdlj4qiFb7pDf)/c1R9fnIY4XBDZ)
	Qbp3TYnCEcLyI8PF5WJSskZl = int(e2eGmXWys8Kdlj4qiFb7pDf[dQ5JhEYolPmy1fvHktMw6NFRxiz:xJvUrkfQoqeWCXw8Bzm1])^AH0BQ4LKlDMrfvqWmXn5
	qqBvbRtUeZ = int(e2eGmXWys8Kdlj4qiFb7pDf[xJvUrkfQoqeWCXw8Bzm1:SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU*xJvUrkfQoqeWCXw8Bzm1])^TTm2opnt9fLX8DBYizbuSPvwhJZCl
	OuRNno7VtTxAcIKUSf14Qa0EhyBe = int(e2eGmXWys8Kdlj4qiFb7pDf[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU*xJvUrkfQoqeWCXw8Bzm1:c1R9fnIY4XBDZ*xJvUrkfQoqeWCXw8Bzm1])^HpjLKS83swXDzVInEf2xUZaCuNbR9d
	rD3NAm1sywq4Bn7Yv98F2eizXlc = G9G0YqivIfmUWO8K
	if Qbp3TYnCEcLyI8PF5WJSskZl==qqBvbRtUeZ==OuRNno7VtTxAcIKUSf14Qa0EhyBe: rD3NAm1sywq4Bn7Yv98F2eizXlc = str(int(Qbp3TYnCEcLyI8PF5WJSskZl)-int(Gb47QY5PBlZWaKgMLizNfdxps6TyRX))
	return rD3NAm1sywq4Bn7Yv98F2eizXlc
def I3CD0odtcR5mZqXYkVj(jN01o7FQrDbavMEgAh3B):
	sumga1F0yT = Kkfl8xemuHbd1w3a0ABPcDrN[cjbAkCIinvs(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ጪ")][RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹ᓺ")]
	akh2SKjQwBUNXM = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,EHUAyW2lQfe4LXmhgIGc(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪጫ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡵ࡮࡭ࡳࡹࠧጬ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪጭ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪ࠻࠷࠶ࡰࠨጮ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ጯ"))
	pdDoI8Q2ezCHr,dBfyeHPY02R7Saq1TjzQ = OSNKd3Zsh4GgE(akh2SKjQwBUNXM)
	pdDoI8Q2ezCHr = FCV0wTRHopA2ljcvrP(pdDoI8Q2ezCHr,UighHKAfySm4PWErqJ(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨጰ"))
	bJa7KinMgpwS6Q1FTYd = {dC3PsQJ0Ti28uYlov(u"࠭ࡩࡥࡵࠪጱ"):Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡅࡋࡄࡐࡔࡍࠧጲ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡷࡶࡶࠬጳ"):iOtjqZ6Iydl,DTF3Lwy9etRH8mI(u"ࠩࡹࡩࡷ࠭ጴ"):GBx0Fcf7sLbqlntEX3yMezu,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡷࡨࡸࠧጵ"):jN01o7FQrDbavMEgAh3B,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡸ࡯ࡺࠨጶ"):pdDoI8Q2ezCHr}
	Eb6JVyIge7aYHdBqz4vmLok = {ssGdubC4mngM9D5SRc3Ye(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫጷ"):hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬጸ")}
	bTvnpz2BD6l7IZtRSG = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,qTVF3icWwGXy5(u"ࠧࡑࡑࡖࡘࠬጹ"),sumga1F0yT,bJa7KinMgpwS6Q1FTYd,Eb6JVyIge7aYHdBqz4vmLok,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡑࡎࡄ࡝ࡤࡊࡉࡂࡎࡒࡋ࠲࠷ࡳࡵࠩጺ"))
	I6bXZUafmj8nSxQkdvDBK5pPl1e = bTvnpz2BD6l7IZtRSG.content
	try:
		if not I6bXZUafmj8nSxQkdvDBK5pPl1e: fvTJsXdyrtl
		QqFk5b8cBZXpEn7rG9AYJI4ax = bRCSwcA89e4J7pqdays5PxGiD2(EHUAyW2lQfe4LXmhgIGc(u"ࠩࡧ࡭ࡨࡺࠧጻ"),I6bXZUafmj8nSxQkdvDBK5pPl1e)
		dd7xebwlvkLPXNMV8JBTKuCt5 = QqFk5b8cBZXpEn7rG9AYJI4ax[cJSNFCIhymEfx6grGu0M(u"ࠪࡱࡸ࡭ࠧጼ")]
		kktUGf4zqcpFHOxs = QqFk5b8cBZXpEn7rG9AYJI4ax[VHrIziKUDuNGXkMla(u"ࠫࡸ࡫ࡣࠨጽ")]
		COSy3lcDMQEJNaGfzdsbnmiuH1W = QqFk5b8cBZXpEn7rG9AYJI4ax[t2sCrJ0xbgDRkf(u"ࠬࡹࡴࡱࠩጾ")]
		kktUGf4zqcpFHOxs = int(o0Ez9jLOuAvaYgpGXrt4Ww8kQ(kktUGf4zqcpFHOxs,bneABYmwFUH8GXphg0Kl2Sq(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩጿ")))
		COSy3lcDMQEJNaGfzdsbnmiuH1W = int(o0Ez9jLOuAvaYgpGXrt4Ww8kQ(COSy3lcDMQEJNaGfzdsbnmiuH1W,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪፀ")))
		for gVSmxPbknoF7jCO in range(kktUGf4zqcpFHOxs,dQ5JhEYolPmy1fvHktMw6NFRxiz,-COSy3lcDMQEJNaGfzdsbnmiuH1W):
			if not eval(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ፁ"),{UighHKAfySm4PWErqJ(u"ࠩࡻࡦࡲࡩࠧፂ"):oR7SuW56ZQcpXnswUMqIkrP}): fvTJsXdyrtl
			XXeZuvhknsKYqB17gwm6dfc(ETNq5t4MYngSsbfFD8J0v(u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩፃ"),str(gVSmxPbknoF7jCO)+qTVF3icWwGXy5(u"ࠫࠥࠦหศ่ํอࠬፄ"),SSCU3jdyFn2V=RVpeGcmPxj9tCnT40Nf216(u"࠵࠳࠴ᓻ")*COSy3lcDMQEJNaGfzdsbnmiuH1W)
			oR7SuW56ZQcpXnswUMqIkrP.sleep(cJSNFCIhymEfx6grGu0M(u"࠴࠴࠵࠶ᓼ")*COSy3lcDMQEJNaGfzdsbnmiuH1W)
		if eval(VHrIziKUDuNGXkMla(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࠩࠫࠪፅ"),{iAGgjwb7tVMmacRJ(u"࠭ࡸࡣ࡯ࡦࠫፆ"):oR7SuW56ZQcpXnswUMqIkrP}):
			dd7xebwlvkLPXNMV8JBTKuCt5 = dd7xebwlvkLPXNMV8JBTKuCt5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࡝࡞ࡱࠫፇ")).replace(fXE2iwNYcD,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ࡞࡟ࡶࠬፈ"))
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩัีําࠧፉ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፊ"),dd7xebwlvkLPXNMV8JBTKuCt5)
		fvTJsXdyrtl
	except: exec(t2sCrJ0xbgDRkf(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫፋ"),{FWqeEzO1i8Dn0ga(u"ࠬࡾࡢ࡮ࡥࠪፌ"):oR7SuW56ZQcpXnswUMqIkrP})
	return
def LkZbFqJUuo8():
	exec(FWqeEzO1i8Dn0ga(u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫፍ"),{Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡹࡤࡰࡧ࡬ࡻࡩࠨፎ"):tDG1bZwX86UPjWEoVOJ,qTVF3icWwGXy5(u"ࠨࡺࡥࡱࡨ࠭ፏ"):oR7SuW56ZQcpXnswUMqIkrP})
	return
def OSNKd3Zsh4GgE(u4uT6Mx7CnDAWspy2jIh):
	CHQs9yVjAI1f2LY7ekmZU,d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6 = dQ5JhEYolPmy1fvHktMw6NFRxiz,dQ5JhEYolPmy1fvHktMw6NFRxiz
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(u4uT6Mx7CnDAWspy2jIh):
		try: CHQs9yVjAI1f2LY7ekmZU = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.getsize(u4uT6Mx7CnDAWspy2jIh)
		except: pass
		if not CHQs9yVjAI1f2LY7ekmZU:
			try: CHQs9yVjAI1f2LY7ekmZU = ifTNQtY3XrquHMV4wlCgI6FmpPK.stat(u4uT6Mx7CnDAWspy2jIh).st_size
			except: pass
		if not CHQs9yVjAI1f2LY7ekmZU:
			try:
				from pathlib import Path as O0OiPIG6manjH5Q2guvtcoeR
				CHQs9yVjAI1f2LY7ekmZU = O0OiPIG6manjH5Q2guvtcoeR(u4uT6Mx7CnDAWspy2jIh).stat().st_size
			except: pass
		if CHQs9yVjAI1f2LY7ekmZU: d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6 = fdQOo6Hu4B5Rbg
	return CHQs9yVjAI1f2LY7ekmZU,d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6
def c87cQjAhJxUVH9Key3EMSwWsXO(mmgrqnQl76RH3WS98UkNMAZLvodDKY,showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬፐ"),mmgrqnQl76RH3WS98UkNMAZLvodDKY+rr7Xolsp4JwjPK3L(u"ࠪࡠࡳࡢ࡮ࠨፑ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็็ๅࠥลࠡࠨፒ")+zzGfwLAyN5HTxUoJeaivY)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=FWqeEzO1i8Dn0ga(u"࠵ᓽ"): return
	Qa6fLE3iD75Ow2FzHqXlSbKCAk = kkMuQrLWcEayRm
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(mmgrqnQl76RH3WS98UkNMAZLvodDKY):
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(mmgrqnQl76RH3WS98UkNMAZLvodDKY.decode(f3uIcZ2C6pzbX1JlFBrVOdt))
		except:
			try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(CaqY25hBEokKs6truUQjefXWJ0wgL)
			except Exception as ltZxqcMaQsi0BfDTIO31z:
				if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨፓ"),str(ltZxqcMaQsi0BfDTIO31z))
				Qa6fLE3iD75Ow2FzHqXlSbKCAk = P5VqbRSzjtO4UE1rZaolG67XA
	if showDialogs:
		if Qa6fLE3iD75Ow2FzHqXlSbKCAk: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩፔ"),UighHKAfySm4PWErqJ(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡษ็้้็ࠧፕ"))
		else:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫፖ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪፗ"))
			Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def Sm8oLxifPQNzI(HRirTSnwQKYOx2Cck18sguj0aE7,LtXEP9QRTq2BygmuJw84bK,showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፘ"),HRirTSnwQKYOx2Cck18sguj0aE7+EHUAyW2lQfe4LXmhgIGc(u"ࠫࡡࡴ࡜࡯ࠩፙ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+cjbAkCIinvs(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣࠪፚ")+zzGfwLAyN5HTxUoJeaivY)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=fdQOo6Hu4B5Rbg: return
	pNmWTskohjIPSt7fQl = kkMuQrLWcEayRm
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(HRirTSnwQKYOx2Cck18sguj0aE7):
		for EEJceIDXMy2TFb90AS1oRUf,UU8hpuKsC7an50qAOXelvTfby2Fi,WX5T7vwl4P0qtOgmLNkzKGBUfeY in ifTNQtY3XrquHMV4wlCgI6FmpPK.walk(HRirTSnwQKYOx2Cck18sguj0aE7,topdown=kkMuQrLWcEayRm):
			for u4uT6Mx7CnDAWspy2jIh in WX5T7vwl4P0qtOgmLNkzKGBUfeY:
				DDUjpRBOdVXkcYHtE0slP9 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(EEJceIDXMy2TFb90AS1oRUf,u4uT6Mx7CnDAWspy2jIh)
				try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(DDUjpRBOdVXkcYHtE0slP9)
				except Exception as MGlP3SpZY8VTHmBt7:
					if showDialogs and not pNmWTskohjIPSt7fQl: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ፛"),str(MGlP3SpZY8VTHmBt7))
					pNmWTskohjIPSt7fQl = P5VqbRSzjtO4UE1rZaolG67XA
			if LtXEP9QRTq2BygmuJw84bK:
				for dir in UU8hpuKsC7an50qAOXelvTfby2Fi:
					C89v6yA24QZgn = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(EEJceIDXMy2TFb90AS1oRUf,dir)
					try: ifTNQtY3XrquHMV4wlCgI6FmpPK.rmdir(C89v6yA24QZgn)
					except: pass
		if LtXEP9QRTq2BygmuJw84bK:
			try: ifTNQtY3XrquHMV4wlCgI6FmpPK.rmdir(EEJceIDXMy2TFb90AS1oRUf)
			except: pass
	if showDialogs and not pNmWTskohjIPSt7fQl:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ፜"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ፝"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def Rhct7Iy953qaglTse(k5GDfLeHJ0ZP3vSYbz,urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp):
	XXzvmn7ewM8yBfoxua,rQmWAsndP6cgJNT8iEM7yVzhla1UkC,CEuGyZ4rFkON2K7qJHfBxmgpvPAQX,rpnIyPil9WTCLE = IpXs8rqBAYFlfNg0wch46bia(yzieWRVX4nkB3DjGHJphEdQo)
	xis68omJPAWO0gLN = urfTS1aCy6hklQRxKzmGFgWste,XXzvmn7ewM8yBfoxua,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp
	if k5GDfLeHJ0ZP3vSYbz<wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠵ᓾ"):
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,dC3PsQJ0Ti28uYlov(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ፞"),xis68omJPAWO0gLN)
		k5GDfLeHJ0ZP3vSYbz = -k5GDfLeHJ0ZP3vSYbz
	if k5GDfLeHJ0ZP3vSYbz>yiaeCEwJjOcWA4ZSd5h(u"࠶ᓿ"):
		RpnYai0qJ4G6mIw = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡷࡹࡸࠧ፟"),yiaeCEwJjOcWA4ZSd5h(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠬ፠"),xis68omJPAWO0gLN)
		if RpnYai0qJ4G6mIw:
			SNAjoRGWnlMtauXpc5sI87FdU(t2sCrJ0xbgDRkf(u"࡛ࠬࡒࡍࡎࡌࡆࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ፡"),yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp,urfTS1aCy6hklQRxKzmGFgWste)
			return RpnYai0qJ4G6mIw
	RpnYai0qJ4G6mIw = GOoTcZPzSh(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp)
	if RpnYai0qJ4G6mIw and k5GDfLeHJ0ZP3vSYbz: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,cjbAkCIinvs(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧ።"),xis68omJPAWO0gLN,RpnYai0qJ4G6mIw,k5GDfLeHJ0ZP3vSYbz)
	return RpnYai0qJ4G6mIw
def idRsI1pxWEXFaL(s5slfAmHkUtMR3WSKY1ZTX,nmRNBDtwqf6YHLSOlu1,FAnkdpCHEGijhNtrcM1=dQ5JhEYolPmy1fvHktMw6NFRxiz):
	LPegGQTVZMYEDu4k = amx9qJHkhw7oLdtVMG3.getSetting(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫ፣"))
	if LPegGQTVZMYEDu4k and wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨ࠯ࠪ፤") not in LPegGQTVZMYEDu4k: wwCFVzNkHGQsoRYgpDhtL4qJ7dBP,Dwh7IKVTBl5n4c0uzW = int(LPegGQTVZMYEDu4k),P5VqbRSzjtO4UE1rZaolG67XA
	elif FAnkdpCHEGijhNtrcM1: wwCFVzNkHGQsoRYgpDhtL4qJ7dBP,Dwh7IKVTBl5n4c0uzW = FAnkdpCHEGijhNtrcM1,kkMuQrLWcEayRm
	else: return []
	qZaHeAK1miL3j4GI,SzEi3cqABpdu6ym5D8sC1Fn = [],G9G0YqivIfmUWO8K
	ggzhk51ZlWC,V4Ir3ij7youJ,fNRBX2WeAmQkKIGVh8Y,CQ2H0FaOZKwlRexIiS3J = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dQ5JhEYolPmy1fvHktMw6NFRxiz,dQ5JhEYolPmy1fvHktMw6NFRxiz
	nmRNBDtwqf6YHLSOlu1 = sorted(nmRNBDtwqf6YHLSOlu1,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: (key[fdQOo6Hu4B5Rbg],key[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]))
	for stream,y4yxmRhoMiVG5B0IzZDPWvlnA3,GFohMKWlxTBYdmSknLCUaw0qERt52 in nmRNBDtwqf6YHLSOlu1+[[G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dQ5JhEYolPmy1fvHktMw6NFRxiz]]:
		if y4yxmRhoMiVG5B0IzZDPWvlnA3==SzEi3cqABpdu6ym5D8sC1Fn:
			if GFohMKWlxTBYdmSknLCUaw0qERt52>wwCFVzNkHGQsoRYgpDhtL4qJ7dBP: V4Ir3ij7youJ,CQ2H0FaOZKwlRexIiS3J = stream,GFohMKWlxTBYdmSknLCUaw0qERt52
			elif not ggzhk51ZlWC: ggzhk51ZlWC,fNRBX2WeAmQkKIGVh8Y = stream,GFohMKWlxTBYdmSknLCUaw0qERt52
		else:
			if V4Ir3ij7youJ or ggzhk51ZlWC:
				if ggzhk51ZlWC: qZaHeAK1miL3j4GI.append([ggzhk51ZlWC,SzEi3cqABpdu6ym5D8sC1Fn,fNRBX2WeAmQkKIGVh8Y])
				elif V4Ir3ij7youJ: qZaHeAK1miL3j4GI.append([V4Ir3ij7youJ,SzEi3cqABpdu6ym5D8sC1Fn,CQ2H0FaOZKwlRexIiS3J])
			if GFohMKWlxTBYdmSknLCUaw0qERt52>wwCFVzNkHGQsoRYgpDhtL4qJ7dBP:
				V4Ir3ij7youJ,CQ2H0FaOZKwlRexIiS3J = stream,GFohMKWlxTBYdmSknLCUaw0qERt52
				ggzhk51ZlWC,fNRBX2WeAmQkKIGVh8Y = G9G0YqivIfmUWO8K,dQ5JhEYolPmy1fvHktMw6NFRxiz
			else:
				V4Ir3ij7youJ,CQ2H0FaOZKwlRexIiS3J = G9G0YqivIfmUWO8K,dQ5JhEYolPmy1fvHktMw6NFRxiz
				ggzhk51ZlWC,fNRBX2WeAmQkKIGVh8Y = stream,GFohMKWlxTBYdmSknLCUaw0qERt52
		SzEi3cqABpdu6ym5D8sC1Fn = y4yxmRhoMiVG5B0IzZDPWvlnA3
	if Dwh7IKVTBl5n4c0uzW:
		iWfaqNJIgvQXA,eEnR986p4Iyq1KFtrcaMis,zAabXCwySkVK2Y91Tgpvhs8O75 = zip(*qZaHeAK1miL3j4GI)
		lXLVUiZ1xcHzynYCBS53GfFmW = [cjbAkCIinvs(u"ࠩࡰࡴ࠹࠭፥"),VHrIziKUDuNGXkMla(u"ࠪࡱࡵࡪࠧ፦"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡹࡹࠧ፧"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡳ࠳ࡶࠩ፨")]
		for y4yxmRhoMiVG5B0IzZDPWvlnA3 in lXLVUiZ1xcHzynYCBS53GfFmW:
			if y4yxmRhoMiVG5B0IzZDPWvlnA3 in eEnR986p4Iyq1KFtrcaMis:
				index = eEnR986p4Iyq1KFtrcaMis.index(y4yxmRhoMiVG5B0IzZDPWvlnA3)
				qZaHeAK1miL3j4GI = [[iWfaqNJIgvQXA[index],eEnR986p4Iyq1KFtrcaMis[index],zAabXCwySkVK2Y91Tgpvhs8O75[index]]]
				break
	return qZaHeAK1miL3j4GI
def nu2WTZYIvOrHaERCXc7jispNyK(ccDQeyqFsvw):
	mYfR3VETgLzdCk2bU6,wQYrc95f3Jlju = [],None
	for oob2dzmG3jTMpZwQyIfN in fGx7vehHaVmkAgR1pJn:
		if oob2dzmG3jTMpZwQyIfN==RVpeGcmPxj9tCnT40Nf216(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧ፩"): wQYrc95f3Jlju = (RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧ࡭࡫ࡱ࡯ࠬ፪"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไࠨ፫")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"࠱࠶࠹ᔀ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
		elif oob2dzmG3jTMpZwQyIfN==VHrIziKUDuNGXkMla(u"ࠩࡐࡍ࡝ࡋࡄࠨ፬"): wQYrc95f3Jlju = (rr7Xolsp4JwjPK3L(u"ࠪࡰ࡮ࡴ࡫ࠨ፭"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪ፮")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"࠲࠷࠺ᔁ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
		elif oob2dzmG3jTMpZwQyIfN==UighHKAfySm4PWErqJ(u"ࠬࡖࡕࡃࡎࡌࡇࠬ፯"): wQYrc95f3Jlju = (iAGgjwb7tVMmacRJ(u"࠭࡬ࡪࡰ࡮ࠫ፰"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊ࠧ፱")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"࠳࠸࠻ᔂ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
		if oob2dzmG3jTMpZwQyIfN not in ccDQeyqFsvw: continue
		if wQYrc95f3Jlju:
			mYfR3VETgLzdCk2bU6.append(wQYrc95f3Jlju)
			wQYrc95f3Jlju = None
		if oob2dzmG3jTMpZwQyIfN not in [vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆࠩ፲"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡐࡍ࡝ࡋࡄࠨ፳"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡔ࡚ࡈࡌࡊࡅࠪ፴")]: mYfR3VETgLzdCk2bU6.append(oob2dzmG3jTMpZwQyIfN)
	return mYfR3VETgLzdCk2bU6
from jtxTCF0UZP import *
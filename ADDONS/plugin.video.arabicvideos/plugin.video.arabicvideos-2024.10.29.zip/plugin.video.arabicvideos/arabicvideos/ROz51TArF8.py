# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMANOW'
TdtCLWYSJNK8zOb = '_CMN_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['قائمتي']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==300: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==301: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==302: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==303: tRojAyBgfDH37eLCwP4dWl = dQo18YGKDWrfl(url)
	elif mode==304: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==305: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==306: tRojAyBgfDH37eLCwP4dWl = JhZaVTx7KMIjBc2fXRFCYDAyLOQ()
	elif mode==309: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+'لماذا الموقع بطيء',G9G0YqivIfmUWO8K,306)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,309,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/home',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<header>(.*?)</header>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('<li><a href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		title = title.strip(ww0sZkBU9JKd)
		if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,301)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	QgXYczTwIFivtxa8l4d32oKhkrHn(ffVP3AK5RqhkgYnjZoNis+'/home',GagwMT6q3oc7UZ2Q)
	return GagwMT6q3oc7UZ2Q
def JhZaVTx7KMIjBc2fXRFCYDAyLOQ():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url,GagwMT6q3oc7UZ2Q=G9G0YqivIfmUWO8K):
	if not GagwMT6q3oc7UZ2Q:
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-SUBMENU-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	JXKAgPztneLxQh = 0
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(<section>.*?</section>)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		for BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			JXKAgPztneLxQh += 1
			items = oo9kuULlebNgpY0Om.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for title,rrnBAXSpqjUxuQHIb5,Y6YdkAMluFbwx in items:
				title = title.strip(ww0sZkBU9JKd)
				if title==G9G0YqivIfmUWO8K: title = 'بووووو'
				if 'em><a' not in rrnBAXSpqjUxuQHIb5:
					if BN1KdkzCmvshw.count('/category/')>0:
						PHNnGoTBQS1iLO5lKa = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
						for Y6YdkAMluFbwx in PHNnGoTBQS1iLO5lKa:
							title = Y6YdkAMluFbwx.split('/')[-2]
							Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,301)
						continue
					else: Y6YdkAMluFbwx = url+'?sequence='+str(JXKAgPztneLxQh)
				if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,302)
	else: UUhwKBgI2nt(url,GagwMT6q3oc7UZ2Q)
	return
def UUhwKBgI2nt(url,GagwMT6q3oc7UZ2Q=G9G0YqivIfmUWO8K):
	if GagwMT6q3oc7UZ2Q==G9G0YqivIfmUWO8K:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-TITLES-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if '?sequence=' in url:
		url,JXKAgPztneLxQh = url.split('?sequence=')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(<section>.*?</section>)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[int(JXKAgPztneLxQh)-1]
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"posts"(.*?)</body>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for Y6YdkAMluFbwx,data,M4qkBDatEIf3T in items:
		title = oo9kuULlebNgpY0Om.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,oo9kuULlebNgpY0Om.DOTALL)
		if title: title = title[0][2].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		if not title or title==G9G0YqivIfmUWO8K:
			title = oo9kuULlebNgpY0Om.findall('title">.*?</em>(.*?)<',data,oo9kuULlebNgpY0Om.DOTALL)
			if title: title = title[0].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			if not title or title==G9G0YqivIfmUWO8K:
				title = oo9kuULlebNgpY0Om.findall('title">(.*?)<',data,oo9kuULlebNgpY0Om.DOTALL)
				title = title[0].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		title = title.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
			ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
			duYhmVFABjltoJ9PcE = Y6YdkAMluFbwx+data+M4qkBDatEIf3T
			if '/selary/' in duYhmVFABjltoJ9PcE or 'مسلسل' in duYhmVFABjltoJ9PcE or '"episode"' in duYhmVFABjltoJ9PcE:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,303,M4qkBDatEIf3T)
			else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,305,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<li><a href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,302)
	return
def dQo18YGKDWrfl(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-SEASONS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	name = oo9kuULlebNgpY0Om.findall('<title>(.*?)</title>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	name = name[0].replace('| سيما ناو',G9G0YqivIfmUWO8K).replace('Cima Now',G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	name = name.split('الحلقة')[0].strip(ww0sZkBU9JKd)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<section(.*?)</section>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)>1:
			for Y6YdkAMluFbwx,title in items:
				title = name+' - '+title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,304)
		else: EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if '/selary/' not in url:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"episodes"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			title = 'الحلقة '+title
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,305)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"details"(.*?)"related"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,305,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	XXzvmn7ewM8yBfoxua = url+'watching/'
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMANOW-PLAY-5th')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	ODnaR0N8UHv7Twy6jS = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"download"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall('\d\d\d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if I5chimw4D1okfxlBE2UpbuHJvStsZ:
				I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ[0]
				title = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
			else: I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
			z7GYBmKiXwreV2QybCNn80v9pT = Y6YdkAMluFbwx+'?named='+title+'__download'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ODnaR0N8UHv7Twy6jS.append(z7GYBmKiXwreV2QybCNn80v9pT)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"watch"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('"embed".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
			title = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__embed'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		dsGzqX4k0a8RLyc = [ffVP3AK5RqhkgYnjZoNis+'/wp-content/themes/Cima%20Now%20New/core.php']
		if dsGzqX4k0a8RLyc:
			items = oo9kuULlebNgpY0Om.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for iT2wOVymHEMAhWl6jbJs8pY,id,title in items:
				title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[0]+'?action=switch&index='+iT2wOVymHEMAhWl6jbJs8pY+'&id='+id+'?named='+title+'__watch'
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis + '/?s='+search
	UUhwKBgI2nt(url)
	return
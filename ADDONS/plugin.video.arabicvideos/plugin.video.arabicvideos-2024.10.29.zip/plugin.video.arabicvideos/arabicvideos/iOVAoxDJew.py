# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧẖ")
SS4m9PQ1okOGueM6BnLFdU = []
headers = {CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩẗ"):G9G0YqivIfmUWO8K}
def DIzqARyrWQ(source,C9uTVdSkLlb5UemavyB6NjWHFh,url):
	vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ẘ")+source+cjbAkCIinvs(u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨẙ")+C9uTVdSkLlb5UemavyB6NjWHFh+jR9YtmsgDX8nTQlMb6G3(u"ࠨࠢࡠࠫẚ"))
	EjDOFi3nHVoQUR485CPzase = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡧ࡭ࡨࡺࠧẛ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ẜ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪẝ"))
	Fbwk3iOU9Pvx7hMJjZWGTrfIC = SSCU3jdyFn2V.strftime(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭ẞ"),SSCU3jdyFn2V.gmtime(AVeHPW5shuXLdr2vwD))
	r5B4eRs8aPk2jzuUHCcnYGAN9dl = Fbwk3iOU9Pvx7hMJjZWGTrfIC,url
	key = source+MjuRWebwX0pfD+GBx0Fcf7sLbqlntEX3yMezu+MjuRWebwX0pfD+str(F7aJYwLMEmxAVRupWf)
	JPhoBimWUM0Gu2H1Fe9fRv8 = G9G0YqivIfmUWO8K
	if key not in list(EjDOFi3nHVoQUR485CPzase.keys()): EjDOFi3nHVoQUR485CPzase[key] = [r5B4eRs8aPk2jzuUHCcnYGAN9dl]
	else:
		if url not in str(EjDOFi3nHVoQUR485CPzase[key]): EjDOFi3nHVoQUR485CPzase[key].append(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
		else: JPhoBimWUM0Gu2H1Fe9fRv8 = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭࡜࡯๊ࠢิฬࠦวๅใํำ๏๎ࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡษ็ๅ๏ี๊้้สฮࠥอไห์่๊ࠣࠦสฺ็็ࠫẟ")
	PPNWkJiwjq9gf = dQ5JhEYolPmy1fvHktMw6NFRxiz
	for key in list(EjDOFi3nHVoQUR485CPzase.keys()):
		EjDOFi3nHVoQUR485CPzase[key] = list(set(EjDOFi3nHVoQUR485CPzase[key]))
		PPNWkJiwjq9gf += len(EjDOFi3nHVoQUR485CPzase[key])
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪẠ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩạ")+JPhoBimWUM0Gu2H1Fe9fRv8+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡟ࡲࡡࡴࠠๅๆ฼่๊ࠦวๅสิ๊ฬ๋ฬࠡ์ๅ์๊ࠦศอ็฼ࠤ็อฦๆหࠣฬฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢํะิࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่๊ࠡึ์ๆฺ๊ࠦำูࠤ฾๊๊ไࠢส่อืๆศ็ฯࠤศ์ࠠหำึ่ࠥํะ่ࠢส่็อฦๆหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻้ำ๊อ๋ࠠืหัࠥ฿ฯะ้สࠤ࠺ࠦแ๋ัํ์์อสࠨẢ")+t2sCrJ0xbgDRkf(u"ࠪࡠࡳࡢ࡮ࠨả")+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡษ็ๆฬฬๅสࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠧẤ")+str(PPNWkJiwjq9gf))
	if PPNWkJiwjq9gf>=iqHhJSxdaANDG5rlZm7B(u"࠸ද"):
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨấ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧẦ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd==EHUAyW2lQfe4LXmhgIGc(u"࠵ධ"):
			CpcihqlUI3KrNf2w1Fxy98YMJRzn = G9G0YqivIfmUWO8K
			for key in list(EjDOFi3nHVoQUR485CPzase.keys()):
				CpcihqlUI3KrNf2w1Fxy98YMJRzn += zEgtT9cR6bFp7JXqI5VuhNeP+key
				jmr6YltEWkMNJgVC3ULcZ2 = sorted(EjDOFi3nHVoQUR485CPzase[key],reverse=kkMuQrLWcEayRm,key=lambda X5027RCfHe: X5027RCfHe[dQ5JhEYolPmy1fvHktMw6NFRxiz])
				for Fbwk3iOU9Pvx7hMJjZWGTrfIC,url in jmr6YltEWkMNJgVC3ULcZ2:
					CpcihqlUI3KrNf2w1Fxy98YMJRzn += zEgtT9cR6bFp7JXqI5VuhNeP+Fbwk3iOU9Pvx7hMJjZWGTrfIC+MjuRWebwX0pfD+aKAyEnjxIlzZtCTv(url)
				CpcihqlUI3KrNf2w1Fxy98YMJRzn += hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡝ࡰ࡟ࡲࠬầ")
			import diEohNHXbY
			pEU7uHoc0zQOC1Anab3KxZ9k = diEohNHXbY.PHxrpu4dEJInZf36qVWs7NwUtGDO(DTF3Lwy9etRH8mI(u"ࠨࡘ࡬ࡨࡪࡵࡳࠨẨ"),G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ẩ"),G9G0YqivIfmUWO8K,CpcihqlUI3KrNf2w1Fxy98YMJRzn)
			if pEU7uHoc0zQOC1Anab3KxZ9k: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ẫ"),cjbAkCIinvs(u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧẫ"))
			else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨẬ"),VHrIziKUDuNGXkMla(u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫậ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=-fdQOo6Hu4B5Rbg:
			EjDOFi3nHVoQUR485CPzase = {}
			aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪẮ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧắ"))
	if EjDOFi3nHVoQUR485CPzase: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,qTVF3icWwGXy5(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬẰ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩằ"),EjDOFi3nHVoQUR485CPzase,UKDwMTZk9dni1JSLcf0oRXhqy)
	return
def XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,source,C9uTVdSkLlb5UemavyB6NjWHFh,url):
	if not ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
		DIzqARyrWQ(source,C9uTVdSkLlb5UemavyB6NjWHFh,url)
		return
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = list(set(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh))
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = iizAxmpbu0WYTGaPU7gHyM(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,source)
	if iKLYEvx39c.resolveonly:
		jgHSfzdQOmq0atiETWI96Rc3NCX = jWJ1gBs6PoZQbInrX0YpqlGdKtk23h(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,source,kkMuQrLWcEayRm)
		return
	MM0YcIS35LjKT,lP8McnNzaX5,LD9bZg6KTe,jgHSfzdQOmq0atiETWI96Rc3NCX,JJ6lgCuM1XZUqz,XX2Btn97vEfkCjcuWs = kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[],G9G0YqivIfmUWO8K,[]
	NRX7a0hfvElHZKO9krSD = not any(yW70dtahIjkPCJg2TA in source for yW70dtahIjkPCJg2TA in eJAcFfPEs2ahrSgw1kKTDb06XoyQlH)
	if NRX7a0hfvElHZKO9krSD:
		tW5sdB9l0TfDcwUVxvYPgNKbHQ1n = dQ5JhEYolPmy1fvHktMw6NFRxiz
		FMiJ6lhuZ8TefUWcBqOCPRASX = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡱ࡯ࡳࡵࠩẲ"),rxWDdRBIct57i90s(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊ࡟ࡔࡗࡆࡇࡊࡋࡄࡆࡆࠪẳ"))
		XjnJrpqT9zw0xs8lIoDMAF4PfO7 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,dC3PsQJ0Ti28uYlov(u"࠭࡬ࡪࡵࡷࠫẴ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡉࡅࡎࡒࡅࡅࠩẵ"))
		JXKAgPztneLxQh = dQ5JhEYolPmy1fvHktMw6NFRxiz
		for title,Y6YdkAMluFbwx in zip(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS):
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split(ETNq5t4MYngSsbfFD8J0v(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩẶ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			if Y6YdkAMluFbwx in FMiJ6lhuZ8TefUWcBqOCPRASX:
				tW5sdB9l0TfDcwUVxvYPgNKbHQ1n += fdQOo6Hu4B5Rbg
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh] = HPYodKgEM7npNrRJmazXDxWA+title+zzGfwLAyN5HTxUoJeaivY
			elif Y6YdkAMluFbwx in XjnJrpqT9zw0xs8lIoDMAF4PfO7:
				tW5sdB9l0TfDcwUVxvYPgNKbHQ1n += fdQOo6Hu4B5Rbg
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh] = A7XhkmSYZlidyMt5FpWqTgjNezbnD+title+zzGfwLAyN5HTxUoJeaivY
			JXKAgPztneLxQh += fdQOo6Hu4B5Rbg
		XX2Btn97vEfkCjcuWs = [ipjCIhwEXsbadR+dC3PsQJ0Ti28uYlov(u"ࠩไัฺࠦฬๆ์฼ࠤฬ๊ำ๋ำไีฬะࠧặ")+zzGfwLAyN5HTxUoJeaivY]
	else: JJ6lgCuM1XZUqz = ipjCIhwEXsbadR+DTF3Lwy9etRH8mI(u"ࠪวำะัࠡษ็ื๏ืแาࠢส่๊์วิสࠪẸ")+zzGfwLAyN5HTxUoJeaivY
	wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = amx9qJHkhw7oLdtVMG3.getSetting(ssGdubC4mngM9D5SRc3Ye(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨẹ"))
	LtVxJGRbUYCaMqO6ezv = jR9YtmsgDX8nTQlMb6G3(u"ࠬ࠳ࠧẺ") not in wwCFVzNkHGQsoRYgpDhtL4qJ7dBP
	while P5VqbRSzjtO4UE1rZaolG67XA:
		cEIATJOaDuld2ve7L94zKY5UoPCw = P5VqbRSzjtO4UE1rZaolG67XA
		if NRX7a0hfvElHZKO9krSD:
			if LtVxJGRbUYCaMqO6ezv and len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)==fdQOo6Hu4B5Rbg: PXeEIRkdShOGm45lbLJc2B38s = fdQOo6Hu4B5Rbg
			else:
				uZCXnfpxFrlQmHRV = str(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO).count(HPYodKgEM7npNrRJmazXDxWA)
				P8iDkclF1jxf = str(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO).count(A7XhkmSYZlidyMt5FpWqTgjNezbnD)
				m5XkLqrfEx1TzdpY2wc = len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)-uZCXnfpxFrlQmHRV-P8iDkclF1jxf
				if gA0m6CQUyfLG: JJ6lgCuM1XZUqz = A7XhkmSYZlidyMt5FpWqTgjNezbnD+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨẻ")+str(P8iDkclF1jxf)+zzGfwLAyN5HTxUoJeaivY+dC3PsQJ0Ti28uYlov(u"้ࠧࠡࠢࠣัํ่ๅห࠽ࠫẼ")+str(m5XkLqrfEx1TzdpY2wc)+HPYodKgEM7npNrRJmazXDxWA+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨฮํำฮࡀࠧẽ")+str(uZCXnfpxFrlQmHRV)+zzGfwLAyN5HTxUoJeaivY
				else: JJ6lgCuM1XZUqz = HPYodKgEM7npNrRJmazXDxWA+t2sCrJ0xbgDRkf(u"ࠩฯ๎ิฯ࠺ࠨẾ")+str(uZCXnfpxFrlQmHRV)+zzGfwLAyN5HTxUoJeaivY+UighHKAfySm4PWErqJ(u"ࠪࠤࠥࠦๅอ้๋่ฮࡀࠧế")+str(m5XkLqrfEx1TzdpY2wc)+A7XhkmSYZlidyMt5FpWqTgjNezbnD+jR9YtmsgDX8nTQlMb6G3(u"ࠫࠥࠦࠠิ์ษอ࠿࠭Ề")+str(P8iDkclF1jxf)+zzGfwLAyN5HTxUoJeaivY
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(JJ6lgCuM1XZUqz,XX2Btn97vEfkCjcuWs+Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			if PXeEIRkdShOGm45lbLJc2B38s==dQ5JhEYolPmy1fvHktMw6NFRxiz:
				cEIATJOaDuld2ve7L94zKY5UoPCw = kkMuQrLWcEayRm
				start,end = dQ5JhEYolPmy1fvHktMw6NFRxiz,len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)-fdQOo6Hu4B5Rbg
				jgHSfzdQOmq0atiETWI96Rc3NCX = jWJ1gBs6PoZQbInrX0YpqlGdKtk23h(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,source,P5VqbRSzjtO4UE1rZaolG67XA)
				LD9bZg6KTe = qTVF3icWwGXy5(u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪ࡟ࡢ࡮࡯ࠫề") if jgHSfzdQOmq0atiETWI96Rc3NCX else EHUAyW2lQfe4LXmhgIGc(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧỂ")
			elif PXeEIRkdShOGm45lbLJc2B38s>dQ5JhEYolPmy1fvHktMw6NFRxiz: start,end = PXeEIRkdShOGm45lbLJc2B38s-fdQOo6Hu4B5Rbg,PXeEIRkdShOGm45lbLJc2B38s-fdQOo6Hu4B5Rbg
		else:
			if LtVxJGRbUYCaMqO6ezv and len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)==fdQOo6Hu4B5Rbg: PXeEIRkdShOGm45lbLJc2B38s = dQ5JhEYolPmy1fvHktMw6NFRxiz
			else: PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(JJ6lgCuM1XZUqz,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			start,end = PXeEIRkdShOGm45lbLJc2B38s,PXeEIRkdShOGm45lbLJc2B38s
		if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg:
			LD9bZg6KTe = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩể")
			break
		if cEIATJOaDuld2ve7L94zKY5UoPCw:
			LD9bZg6KTe = RVpeGcmPxj9tCnT40Nf216(u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࡢࡳࡳ࡫ࠧỄ")
			jgHSfzdQOmq0atiETWI96Rc3NCX = jWJ1gBs6PoZQbInrX0YpqlGdKtk23h([Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[start]],[ODnaR0N8UHv7Twy6jS[start]],source,P5VqbRSzjtO4UE1rZaolG67XA)
			title,Y6YdkAMluFbwx,lP8McnNzaX5,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc = jgHSfzdQOmq0atiETWI96Rc3NCX[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			z2Fc1kie9fwvuaVTIs8CYt,j7dhKWaAPLUw5 = SAcEyo5CwXUQ9IegmNFH(title,Y6YdkAMluFbwx,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc,source,C9uTVdSkLlb5UemavyB6NjWHFh)
			if z2Fc1kie9fwvuaVTIs8CYt in [DTF3Lwy9etRH8mI(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧễ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫỆ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬệ")]:
				MM0YcIS35LjKT = P5VqbRSzjtO4UE1rZaolG67XA
				break
			else:
				if not lP8McnNzaX5: lP8McnNzaX5 = t2sCrJ0xbgDRkf(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡩࡥ࡮ࡲࡥࡥࠩỈ")
				title = A7XhkmSYZlidyMt5FpWqTgjNezbnD+title+zzGfwLAyN5HTxUoJeaivY
				jgHSfzdQOmq0atiETWI96Rc3NCX[dQ5JhEYolPmy1fvHktMw6NFRxiz] = title,Y6YdkAMluFbwx,lP8McnNzaX5,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc
				V7JB2YuSMWc6HDqvA9ot = Y6YdkAMluFbwx.split(rxWDdRBIct57i90s(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧỉ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,cjbAkCIinvs(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬỊ"),V7JB2YuSMWc6HDqvA9ot)
				ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,iqHhJSxdaANDG5rlZm7B(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡊࡆࡏࡌࡆࡆࠪị"),V7JB2YuSMWc6HDqvA9ot,[lP8McnNzaX5,title,Y6YdkAMluFbwx],TTm2opnt9fLX8DBYizbuSPvwhJZCl)
			if lP8McnNzaX5==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧỌ"): break
			KkcIVB7sXq8g3Mb1WfTn = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬọ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,cjbAkCIinvs(u"ࠫࡡࡴ࡛ࡍࡇࡉࡘࡢࠦࠠࠨỎ")) if lP8McnNzaX5.count(zEgtT9cR6bFp7JXqI5VuhNeP)>rxWDdRBIct57i90s(u"࠸න") else zEgtT9cR6bFp7JXqI5VuhNeP+lP8McnNzaX5
			if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ỏ") not in source: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩỐ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪố")+zEgtT9cR6bFp7JXqI5VuhNeP+KkcIVB7sXq8g3Mb1WfTn,profile=dC3PsQJ0Ti28uYlov(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭Ồ"))
			if len(ODnaR0N8UHv7Twy6jS)==fdQOo6Hu4B5Rbg and lP8McnNzaX5: break
		for JXKAgPztneLxQh in range(start,end+fdQOo6Hu4B5Rbg):
			nn6HrjWtvdX5SyxLlzkYA = dQ5JhEYolPmy1fvHktMw6NFRxiz if cEIATJOaDuld2ve7L94zKY5UoPCw else JXKAgPztneLxQh
			title,Y6YdkAMluFbwx,lP8McnNzaX5,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc = jgHSfzdQOmq0atiETWI96Rc3NCX[nn6HrjWtvdX5SyxLlzkYA]
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh] = Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh].replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,G9G0YqivIfmUWO8K).replace(HPYodKgEM7npNrRJmazXDxWA,G9G0YqivIfmUWO8K).replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)
			if lP8McnNzaX5: Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh] = A7XhkmSYZlidyMt5FpWqTgjNezbnD+Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh]+zzGfwLAyN5HTxUoJeaivY
			else: Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh] = HPYodKgEM7npNrRJmazXDxWA+Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[JXKAgPztneLxQh]+zzGfwLAyN5HTxUoJeaivY
	if LD9bZg6KTe==iAGgjwb7tVMmacRJ(u"ࠩࡱࡳࡹࡥࡲࡦࡵࡲࡰࡻࡧࡢ࡭ࡧࠪồ"): hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ổ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"้๊ࠫริใ่ࠣฬ๊้ࠦฮาࠤุ๐ัโำสฮࠥา๊ะหࠣๅ๏ࠦ็ัษࠣห้็๊ะ์๋ࠤ࠳࠴ࠠฮษ๋่ࠥษๆࠡฬหัะูࠦ็๊ࠢิฬࠦวๅใํำ๏๎ࠠโ์้ࠣํอโฺࠢฦาึ๏ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠩổ"))
	if not MM0YcIS35LjKT or LD9bZg6KTe in [t2sCrJ0xbgDRkf(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧỖ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࡮ࡰࡶࡢࡶࡪࡹ࡯࡭ࡸࡤࡦࡱ࡫ࠧỗ")] or lP8McnNzaX5:
		PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(cJSNFCIhymEfx6grGu0M(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡅ࡯ࡩࡦࡸࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵ࢂࢃࠧỘ"))
	return
OfE2y4cseK8NP,zOkGChDc3lxKXoNtr9v5QI,vf6BNMbx0XUTt8hGPcqrmASZF1j,xFU9803Giwah6pvP7jVMQ2sYkXHA,IPdLCXj7Rs9EhbOQ,ju8elM3gsTFSibfH1VIaBo = [],[],[],[],[],[]
def jWJ1gBs6PoZQbInrX0YpqlGdKtk23h(GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,source,showDialogs):
	global OfE2y4cseK8NP,zOkGChDc3lxKXoNtr9v5QI,vf6BNMbx0XUTt8hGPcqrmASZF1j,xFU9803Giwah6pvP7jVMQ2sYkXHA,IPdLCXj7Rs9EhbOQ,ju8elM3gsTFSibfH1VIaBo
	tRojAyBgfDH37eLCwP4dWl,YP72bBvuV0sI5i4r,new = [],[],[]
	ggGCyoxkHXwif(kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	count = len(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh)
	for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(count):
		OfE2y4cseK8NP.append(None)
		zOkGChDc3lxKXoNtr9v5QI.append(None)
		vf6BNMbx0XUTt8hGPcqrmASZF1j.append(None)
		xFU9803Giwah6pvP7jVMQ2sYkXHA.append(None)
		IPdLCXj7Rs9EhbOQ.append(None)
		ju8elM3gsTFSibfH1VIaBo.append(dQ5JhEYolPmy1fvHktMw6NFRxiz)
		title = GGoLgj5BFbWI[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
		Y6YdkAMluFbwx = ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh[NAfxw4FYmpauWhLM2rX8soZk9QnC0].strip(ww0sZkBU9JKd).strip(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࠨࠪộ")).strip(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡂࠫỚ")).strip(dC3PsQJ0Ti28uYlov(u"ࠪ࠳ࠬớ"))
		if count>fdQOo6Hu4B5Rbg and showDialogs: XXeZuvhknsKYqB17gwm6dfc(dC3PsQJ0Ti28uYlov(u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭Ờ")+str(NAfxw4FYmpauWhLM2rX8soZk9QnC0+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠷඲")),title)
		HLiP6CZojg8zAraRqXxD57hK2YbI = [cjbAkCIinvs(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ờ"),ssGdubC4mngM9D5SRc3Ye(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫỞ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡂࡍ࡚ࡅࡒ࠭ở")]
		if source in HLiP6CZojg8zAraRqXxD57hK2YbI: OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0] = HHAgLdUznaYsv2pxQjESKriB6(title,Y6YdkAMluFbwx,source,NAfxw4FYmpauWhLM2rX8soZk9QnC0)
		else:
			if iqHhJSxdaANDG5rlZm7B(u"࠱ඳ"):
				Q6BsV9rZEkMPpR5NDYL0fhwIdW = fu19TY0PdM6AZB5.Thread(target=HHAgLdUznaYsv2pxQjESKriB6,args=(title,Y6YdkAMluFbwx,source,NAfxw4FYmpauWhLM2rX8soZk9QnC0))
				Q6BsV9rZEkMPpR5NDYL0fhwIdW.start()
				YP72bBvuV0sI5i4r.append(Q6BsV9rZEkMPpR5NDYL0fhwIdW)
				new.append(NAfxw4FYmpauWhLM2rX8soZk9QnC0)
				SSCU3jdyFn2V.sleep(cjbAkCIinvs(u"࠲ප"))
	timeout = rxWDdRBIct57i90s(u"࠸࠳ඵ") if source==iqHhJSxdaANDG5rlZm7B(u"ࠨࡃࡎ࡛ࡆࡓࠧỠ") else RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠶࠴බ")
	ONEZrIFzqkX1no = SSCU3jdyFn2V.time()
	for Q6BsV9rZEkMPpR5NDYL0fhwIdW in YP72bBvuV0sI5i4r: Q6BsV9rZEkMPpR5NDYL0fhwIdW.join(timeout)
	for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(count):
		title = GGoLgj5BFbWI[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
		Y6YdkAMluFbwx = ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh[NAfxw4FYmpauWhLM2rX8soZk9QnC0].strip(ww0sZkBU9JKd).strip(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࠩࠫỡ")).strip(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡃࠬỢ")).strip(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࠴࠭ợ"))
		rcsIiKSzZjo = P5VqbRSzjtO4UE1rZaolG67XA if ju8elM3gsTFSibfH1VIaBo[NAfxw4FYmpauWhLM2rX8soZk9QnC0]+fdQOo6Hu4B5Rbg>timeout else kkMuQrLWcEayRm
		if OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0] and len(OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0])==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷භ") and (OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0][dQ5JhEYolPmy1fvHktMw6NFRxiz] or OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]): KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT = OfE2y4cseK8NP[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
		elif rcsIiKSzZjo: KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT = DTF3Lwy9etRH8mI(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡕ࡫ࡰࡩࡩࠦࡏࡶࡶࠣࠬࠬỤ")+str(timeout)+rxWDdRBIct57i90s(u"࠭ࠠࡴࡧࡦࡳࡳࡪࡳࠪࠩụ"),[],[]
		else: KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT = EHUAyW2lQfe4LXmhgIGc(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡆࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫỦ"),[],[]
		tRojAyBgfDH37eLCwP4dWl.append([title,Y6YdkAMluFbwx,KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT])
		if NAfxw4FYmpauWhLM2rX8soZk9QnC0 in new:
			V7JB2YuSMWc6HDqvA9ot = Y6YdkAMluFbwx.split(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩủ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			if not KkcIVB7sXq8g3Mb1WfTn: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧỨ"),V7JB2YuSMWc6HDqvA9ot,[KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT],TTm2opnt9fLX8DBYizbuSPvwhJZCl)
			else: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,qTVF3icWwGXy5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬứ"),V7JB2YuSMWc6HDqvA9ot,[KkcIVB7sXq8g3Mb1WfTn,GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT],TTm2opnt9fLX8DBYizbuSPvwhJZCl)
	ggGCyoxkHXwif(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
	return tRojAyBgfDH37eLCwP4dWl
def HHAgLdUznaYsv2pxQjESKriB6(yVgLqfcUN1iO4,url,source,o6IQax2n7skH):
	global OfE2y4cseK8NP,ju8elM3gsTFSibfH1VIaBo
	ju8elM3gsTFSibfH1VIaBo[o6IQax2n7skH] = dQ5JhEYolPmy1fvHktMw6NFRxiz
	ONEZrIFzqkX1no = SSCU3jdyFn2V.time()
	vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dC3PsQJ0Ti28uYlov(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬỪ")+yVgLqfcUN1iO4+FWqeEzO1i8Dn0ga(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩừ")+url+EHUAyW2lQfe4LXmhgIGc(u"࠭ࠠ࡞ࠩỬ"))
	Y6YdkAMluFbwx,YOVkyEgnDR7Wo = url,G9G0YqivIfmUWO8K
	IqtZWA3ym4RoewUGa79zPC = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡊࡐࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࠫử")
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = vH2fZE7GIABl3Yy9Sr1oMe(url,source)
	if lP8McnNzaX5==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ữ"):
		OfE2y4cseK8NP[o6IQax2n7skH] = dC3PsQJ0Ti28uYlov(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧữ"),[],[]
		ju8elM3gsTFSibfH1VIaBo[o6IQax2n7skH] = SSCU3jdyFn2V.time()-ONEZrIFzqkX1no
		return OfE2y4cseK8NP[o6IQax2n7skH]
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ự") in lP8McnNzaX5:
		YOVkyEgnDR7Wo = rxWDdRBIct57i90s(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥࡔࡥࡦࡦࠣࡉࡽࡺࡥࡳࡰࡤࡰࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠧự")
		Y6YdkAMluFbwx = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		IqtZWA3ym4RoewUGa79zPC,YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = i2Tu3gj1BhfXV(YOVkyEgnDR7Wo,Y6YdkAMluFbwx,source,o6IQax2n7skH)
		if YOVkyEgnDR7Wo==vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪỲ"):
			ju8elM3gsTFSibfH1VIaBo[o6IQax2n7skH] = SSCU3jdyFn2V.time()-ONEZrIFzqkX1no
			return YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	elif lP8McnNzaX5: YOVkyEgnDR7Wo = EHUAyW2lQfe4LXmhgIGc(u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠥ࠭ỳ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)[:iqHhJSxdaANDG5rlZm7B(u"࠽࠶ම")]
	if ODnaR0N8UHv7Twy6jS:
		ODnaR0N8UHv7Twy6jS = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)
		vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+t2sCrJ0xbgDRkf(u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪỴ")+yVgLqfcUN1iO4+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬỵ")+IqtZWA3ym4RoewUGa79zPC+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ỷ")+url+FWqeEzO1i8Dn0ga(u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪỷ")+Y6YdkAMluFbwx+UighHKAfySm4PWErqJ(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭Ỹ")+str(ODnaR0N8UHv7Twy6jS)+bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࠦ࡝ࠨỹ"))
	else: vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iAGgjwb7tVMmacRJ(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭Ỻ")+yVgLqfcUN1iO4+UighHKAfySm4PWErqJ(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫỻ")+url+iqHhJSxdaANDG5rlZm7B(u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨỼ")+Y6YdkAMluFbwx+DTF3Lwy9etRH8mI(u"ࠩࠣࡡࠥࠦࠠࡆࡴࡵࡳࡷࡹ࠺ࠡ࡝ࠣࠫỽ")+YOVkyEgnDR7Wo+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠤࡢ࠭Ỿ"))
	YOVkyEgnDR7Wo = aKAyEnjxIlzZtCTv(YOVkyEgnDR7Wo)
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	ju8elM3gsTFSibfH1VIaBo[o6IQax2n7skH] = SSCU3jdyFn2V.time()-ONEZrIFzqkX1no
	return YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def SAcEyo5CwXUQ9IegmNFH(title,Y6YdkAMluFbwx,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,source,C9uTVdSkLlb5UemavyB6NjWHFh=G9G0YqivIfmUWO8K):
	if ODnaR0N8UHv7Twy6jS:
		if not Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[dC3PsQJ0Ti28uYlov(u"࠶ඹ")]: Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = ODnaR0N8UHv7Twy6jS
		wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = amx9qJHkhw7oLdtVMG3.getSetting(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨỿ"))
		LtVxJGRbUYCaMqO6ezv = dC3PsQJ0Ti28uYlov(u"ࠬ࠳ࠧἀ") not in wwCFVzNkHGQsoRYgpDhtL4qJ7dBP
		while P5VqbRSzjtO4UE1rZaolG67XA:
			if LtVxJGRbUYCaMqO6ezv and len(ODnaR0N8UHv7Twy6jS)==fdQOo6Hu4B5Rbg: PXeEIRkdShOGm45lbLJc2B38s = dQ5JhEYolPmy1fvHktMw6NFRxiz
			else: PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(rr7Xolsp4JwjPK3L(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬἁ"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: hh2WobBZGFs5Lp0EjISNHfwdMkKv = dC3PsQJ0Ti28uYlov(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩἂ")
			else:
				OqKEDoeFi0Rp47UA2ngtVTCbks = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
				vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+t2sCrJ0xbgDRkf(u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧἃ")+title+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭ἄ")+Y6YdkAMluFbwx+RVpeGcmPxj9tCnT40Nf216(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫἅ")+str(OqKEDoeFi0Rp47UA2ngtVTCbks)+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࠥࡣࠧἆ"))
				if yiaeCEwJjOcWA4ZSd5h(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨἇ") in OqKEDoeFi0Rp47UA2ngtVTCbks and rr7Xolsp4JwjPK3L(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭Ἀ") in OqKEDoeFi0Rp47UA2ngtVTCbks:
					KkcIVB7sXq8g3Mb1WfTn,YeMhgjKoiwFRbATH5d8QVGmv4fsB,EEm7hgHpsjDO82aIQSNMf9yY6ZXrc = M5B94WgJfbkAxhIX3nqCwcE(OqKEDoeFi0Rp47UA2ngtVTCbks)
					if EEm7hgHpsjDO82aIQSNMf9yY6ZXrc: OqKEDoeFi0Rp47UA2ngtVTCbks = EEm7hgHpsjDO82aIQSNMf9yY6ZXrc[dQ5JhEYolPmy1fvHktMw6NFRxiz]
					else: OqKEDoeFi0Rp47UA2ngtVTCbks = G9G0YqivIfmUWO8K
				if not OqKEDoeFi0Rp47UA2ngtVTCbks: hh2WobBZGFs5Lp0EjISNHfwdMkKv = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫἉ")
				else: hh2WobBZGFs5Lp0EjISNHfwdMkKv = Imphr8LRTUDs(OqKEDoeFi0Rp47UA2ngtVTCbks,source,C9uTVdSkLlb5UemavyB6NjWHFh)
			if hh2WobBZGFs5Lp0EjISNHfwdMkKv in [ssGdubC4mngM9D5SRc3Ye(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩἊ"),rr7Xolsp4JwjPK3L(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪἋ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨἌ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠭Ἅ")] or len(ODnaR0N8UHv7Twy6jS)==vCmnFshSi4flecXIY2gy38G0DJw(u"࠱ය"): break
			elif hh2WobBZGFs5Lp0EjISNHfwdMkKv in [iAGgjwb7tVMmacRJ(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬἎ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧἏ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡵࡴ࡬ࡩࡩ࠭ἐ")]: break
			else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫἑ"),iqHhJSxdaANDG5rlZm7B(u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨἒ"))
	else:
		hh2WobBZGFs5Lp0EjISNHfwdMkKv = RVpeGcmPxj9tCnT40Nf216(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧἓ")
		if Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx): hh2WobBZGFs5Lp0EjISNHfwdMkKv = Imphr8LRTUDs(Y6YdkAMluFbwx,source,C9uTVdSkLlb5UemavyB6NjWHFh)
	return hh2WobBZGFs5Lp0EjISNHfwdMkKv,ODnaR0N8UHv7Twy6jS
def FoD0uGpW8I54(url,source):
	XXzvmn7ewM8yBfoxua,hhmGjKt3FQkWaIP62vJzexpAs5B,yVgLqfcUN1iO4,j3ThPldsiUAqF0xXJtu,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,pM0RwoYjfsUVZcqt6uTOiFkhEXCS = url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if FWqeEzO1i8Dn0ga(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬἔ") in url:
		XXzvmn7ewM8yBfoxua,hhmGjKt3FQkWaIP62vJzexpAs5B = url.split(yiaeCEwJjOcWA4ZSd5h(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ἕ"),fdQOo6Hu4B5Rbg)
		hhmGjKt3FQkWaIP62vJzexpAs5B = hhmGjKt3FQkWaIP62vJzexpAs5B+dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭࡟ࡠࠩ἖")+ssGdubC4mngM9D5SRc3Ye(u"ࠧࡠࡡࠪ἗")+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡡࡢࠫἘ")+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡢࡣࠬἙ")+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡣࡤ࠭Ἒ")
		YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,pM0RwoYjfsUVZcqt6uTOiFkhEXCS,LYwAUpercInVkKPtHGM87fSZs, = hhmGjKt3FQkWaIP62vJzexpAs5B.split(cjbAkCIinvs(u"ࠫࡤࡥࠧἛ"))[:ETNq5t4MYngSsbfFD8J0v(u"࠷ර")]
	if not I5chimw4D1okfxlBE2UpbuHJvStsZ: I5chimw4D1okfxlBE2UpbuHJvStsZ = VHrIziKUDuNGXkMla(u"ࠬ࠶ࠧἜ")
	else: I5chimw4D1okfxlBE2UpbuHJvStsZ = I5chimw4D1okfxlBE2UpbuHJvStsZ.replace(bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡰࠨἝ"),G9G0YqivIfmUWO8K).replace(ww0sZkBU9JKd,G9G0YqivIfmUWO8K)
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.strip(iqHhJSxdaANDG5rlZm7B(u"ࠧࡀࠩ἞")).strip(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ࠱ࠪ἟")).strip(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࠩࠫἠ"))
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࡬ࡴࡹࡴࠨἡ"))
	if YwC7jt5BQHhTUvbdGeM6f2ZLx: j3ThPldsiUAqF0xXJtu = YwC7jt5BQHhTUvbdGeM6f2ZLx
	else: j3ThPldsiUAqF0xXJtu = yVgLqfcUN1iO4
	j3ThPldsiUAqF0xXJtu = xWiOjcUrJVdtP4B5Iml(j3ThPldsiUAqF0xXJtu,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡳࡧ࡭ࡦࠩἢ"))
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ssGdubC4mngM9D5SRc3Ye(u"๋ࠬศศึิࠫἣ"),G9G0YqivIfmUWO8K).replace(VHrIziKUDuNGXkMla(u"࠭ำ๋ำไีࠬἤ"),G9G0YqivIfmUWO8K).replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧศๆࠣࠫἥ"),ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	hhmGjKt3FQkWaIP62vJzexpAs5B = hhmGjKt3FQkWaIP62vJzexpAs5B.replace(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ็หหูืࠧἦ"),G9G0YqivIfmUWO8K).replace(iqHhJSxdaANDG5rlZm7B(u"ࠩึ๎ึ็ัࠨἧ"),G9G0YqivIfmUWO8K).replace(iAGgjwb7tVMmacRJ(u"ࠪห้ࠦࠧἨ"),ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	j3ThPldsiUAqF0xXJtu = j3ThPldsiUAqF0xXJtu.replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"๊ࠫฮวีำࠪἩ"),G9G0YqivIfmUWO8K).replace(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ู๊ࠬาใิࠫἪ"),G9G0YqivIfmUWO8K).replace(RVpeGcmPxj9tCnT40Nf216(u"࠭วๅࠢࠪἫ"),ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	return XXzvmn7ewM8yBfoxua,hhmGjKt3FQkWaIP62vJzexpAs5B,yVgLqfcUN1iO4,j3ThPldsiUAqF0xXJtu,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,pM0RwoYjfsUVZcqt6uTOiFkhEXCS
def qq7GSYLQePjBE(url,source):
	cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,HDaA1S9vRzgKeZUBm42q,JSlC1mtxL8H9d7AiMj2sPzUg,jYCf4ViPQxhueXRyS50lsvkZt2mz,KNtTBWXxADlbvnpOz,IqtZWA3ym4RoewUGa79zPC = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,None,None,None,None,None
	XXzvmn7ewM8yBfoxua,hhmGjKt3FQkWaIP62vJzexpAs5B,yVgLqfcUN1iO4,j3ThPldsiUAqF0xXJtu,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,pM0RwoYjfsUVZcqt6uTOiFkhEXCS = FoD0uGpW8I54(url,source)
	if ssGdubC4mngM9D5SRc3Ye(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨἬ") in url:
		if   C9uTVdSkLlb5UemavyB6NjWHFh==RVpeGcmPxj9tCnT40Nf216(u"ࠨࡧࡰࡦࡪࡪࠧἭ"): C9uTVdSkLlb5UemavyB6NjWHFh = ww0sZkBU9JKd+FWqeEzO1i8Dn0ga(u"่ࠩๅ฻๊ࠧἮ")
		elif C9uTVdSkLlb5UemavyB6NjWHFh==yiaeCEwJjOcWA4ZSd5h(u"ࠪࡻࡦࡺࡣࡩࠩἯ"): C9uTVdSkLlb5UemavyB6NjWHFh = ww0sZkBU9JKd+cjbAkCIinvs(u"๋ࠫࠪิศ้าอࠬἰ")
		elif C9uTVdSkLlb5UemavyB6NjWHFh==cJSNFCIhymEfx6grGu0M(u"ࠬࡨ࡯ࡵࡪࠪἱ"): C9uTVdSkLlb5UemavyB6NjWHFh = ww0sZkBU9JKd+bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࠥࠦ็ืห์ีษ๊ࠡอั๊๐ไࠨἲ")
		elif C9uTVdSkLlb5UemavyB6NjWHFh==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩἳ"): C9uTVdSkLlb5UemavyB6NjWHFh = ww0sZkBU9JKd+t2sCrJ0xbgDRkf(u"ࠨࠧࠨࠩฯำๅ๋ๆࠪἴ")
		elif C9uTVdSkLlb5UemavyB6NjWHFh==G9G0YqivIfmUWO8K: C9uTVdSkLlb5UemavyB6NjWHFh = ww0sZkBU9JKd+iqHhJSxdaANDG5rlZm7B(u"ࠩࠨࠩࠪࠫࠧἵ")
		if FF94GpU6MrbZy!=G9G0YqivIfmUWO8K:
			if iqHhJSxdaANDG5rlZm7B(u"ࠪࡱࡵ࠺ࠧἶ") not in FF94GpU6MrbZy: FF94GpU6MrbZy = bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࠪ࠭ἷ")+FF94GpU6MrbZy
			FF94GpU6MrbZy = ww0sZkBU9JKd+FF94GpU6MrbZy
		if I5chimw4D1okfxlBE2UpbuHJvStsZ!=G9G0YqivIfmUWO8K:
			I5chimw4D1okfxlBE2UpbuHJvStsZ = t2sCrJ0xbgDRkf(u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨἸ")+I5chimw4D1okfxlBE2UpbuHJvStsZ
			I5chimw4D1okfxlBE2UpbuHJvStsZ = ww0sZkBU9JKd+I5chimw4D1okfxlBE2UpbuHJvStsZ[-DTF3Lwy9etRH8mI(u"࠻඼"):]
	if   dC3PsQJ0Ti28uYlov(u"࠭ࡁࡌࡑࡄࡑࠬἹ")		in source: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif iqHhJSxdaANDG5rlZm7B(u"ࠧࡂࡍ࡚ࡅࡒ࠭Ἲ")		in source: HDaA1S9vRzgKeZUBm42q	= ETNq5t4MYngSsbfFD8J0v(u"ࠨࡣ࡮ࡻࡦࡳࠧἻ")
	elif qTVF3icWwGXy5(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫἼ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif VHrIziKUDuNGXkMla(u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩἽ")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭Ἶ")		in source: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif dC3PsQJ0Ti28uYlov(u"ࠬࡧ࡬ࡢࡴࡤࡦࠬἿ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif dC3PsQJ0Ti28uYlov(u"࠭ࡦࡢࡵࡨࡰࠬὀ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif t2sCrJ0xbgDRkf(u"ࠧࡵ࠹ࡰࡩࡪࡲࠧὁ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨὂ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫὃ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡪࡦࡰࡥࡳࠩὄ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif cjbAkCIinvs(u"ࠫๆาัࠨὅ")			in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= rr7Xolsp4JwjPK3L(u"ࠬ࡬ࡡ࡫ࡧࡵࠫ὆")
	elif iqHhJSxdaANDG5rlZm7B(u"࠭แๅีฺ๎๋࠭὇")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= EHUAyW2lQfe4LXmhgIGc(u"ࠧࡱࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪὈ")
	elif cjbAkCIinvs(u"ࠨࡩࡧࡶ࡮ࡼࡥࠨὉ")		in XXzvmn7ewM8yBfoxua:   HDaA1S9vRzgKeZUBm42q	= vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩὊ")
	elif VHrIziKUDuNGXkMla(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪὋ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif EHUAyW2lQfe4LXmhgIGc(u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫὌ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭Ὅ")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧ὎")		in YwC7jt5BQHhTUvbdGeM6f2ZLx:   HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ὏")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif FWqeEzO1i8Dn0ga(u"ࠨࡤࡲ࡯ࡷࡧࠧὐ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡷࡺ࡫ࡻ࡮ࠨὑ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif rxWDdRBIct57i90s(u"ࠪࡸࡻࡱࡳࡢࠩὒ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬὓ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif qTVF3icWwGXy5(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧὔ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨὕ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩὖ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif DTF3Lwy9etRH8mI(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨὗ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ὘")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬὙ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif qTVF3icWwGXy5(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭὚")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭Ὓ")	 	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= DTF3Lwy9etRH8mI(u"࠭ࡲࡦࡦࡰࡳࡩࡾࠧ὜")
	elif wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡺࡱࡸࡸࡺ࠭Ὕ")	 	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= dC3PsQJ0Ti28uYlov(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ὞")
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩὟ")	 	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= t2sCrJ0xbgDRkf(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫὠ")
	elif cJSNFCIhymEfx6grGu0M(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪὡ")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= j3ThPldsiUAqF0xXJtu
	elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪὢ")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= VHrIziKUDuNGXkMla(u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪὣ")
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩὤ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= FWqeEzO1i8Dn0ga(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪὥ")
	elif EHUAyW2lQfe4LXmhgIGc(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪὦ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= jR9YtmsgDX8nTQlMb6G3(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬὧ")
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭Ὠ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧὩ")
	elif dC3PsQJ0Ti28uYlov(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬὪ")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= ssGdubC4mngM9D5SRc3Ye(u"ࠧࡧࡣࡦࡹࡱࡺࡹࡣࡱࡲ࡯ࡸ࠭Ὣ")
	elif rxWDdRBIct57i90s(u"ࠨ࡫ࡱࡪࡱࡧ࡭࠯ࡥࡦࠫὬ")	in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࡬ࡲ࡫ࡲࡡ࡮ࠩὭ")
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫὮ")		in yVgLqfcUN1iO4: HDaA1S9vRzgKeZUBm42q	= cJSNFCIhymEfx6grGu0M(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬὯ")
	elif cJSNFCIhymEfx6grGu0M(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨὰ")	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩά")
	elif GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨὲ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= t2sCrJ0xbgDRkf(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩέ")
	elif yiaeCEwJjOcWA4ZSd5h(u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫὴ")	 	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡧࡦࡺࡣࡩࠩή")
	elif iAGgjwb7tVMmacRJ(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬὶ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬ࡬ࡩ࡭ࡧࡵ࡭ࡴ࠭ί")
	elif EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡶࡪࡦࡥࡱࠬὸ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡷ࡫ࡧࡦࡲ࠭ό")
	elif dC3PsQJ0Ti28uYlov(u"ࠨࡸ࡬ࡨ࡭ࡪࠧὺ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡰࡽࡻ࡯ࡤࠨύ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif VHrIziKUDuNGXkMla(u"ࠪࡱࡾࡼࡩࡪࡦࠪὼ")		in yVgLqfcUN1iO4: KNtTBWXxADlbvnpOz	= j3ThPldsiUAqF0xXJtu
	elif EHUAyW2lQfe4LXmhgIGc(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭ώ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ὾")
	elif ETNq5t4MYngSsbfFD8J0v(u"࠭ࡧࡰࡸ࡬ࡨࠬ὿")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= VHrIziKUDuNGXkMla(u"ࠧࡨࡱࡹ࡭ࡩ࠭ᾀ")
	elif ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪᾁ") 	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫᾂ")
	elif cJSNFCIhymEfx6grGu0M(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ᾃ")	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧᾄ")
	elif iqHhJSxdaANDG5rlZm7B(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪᾅ")	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡰࡶࡤ࡯࡭ࡨࡼࡩࡥࡧࡲࠫᾆ")
	elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫᾇ") 	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= rr7Xolsp4JwjPK3L(u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬᾈ")
	elif rxWDdRBIct57i90s(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪᾉ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= iAGgjwb7tVMmacRJ(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫᾊ")
	elif rxWDdRBIct57i90s(u"ࠫࡺࡶࡰࠨᾋ") 			in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡻࡰࡣࡱࡰࠫᾌ")
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡵࡱࡤࠪᾍ") 			in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡶࡲࡥࡳࡲ࠭ᾎ")
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠨࡷࡴࡰࡴࡧࡤࠨᾏ") 		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡸࡵࡱࡵࡡࡥࠩᾐ")
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬᾑ") 	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= ssGdubC4mngM9D5SRc3Ye(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ᾒ")
	elif EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡼࡩࡥࡤࡲࡦࠬᾓ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡶࡪࡦࡥࡳࡧ࠭ᾔ")
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧᾕ") 		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= DTF3Lwy9etRH8mI(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨᾖ")
	elif DTF3Lwy9etRH8mI(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭ᾗ") 	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= cjbAkCIinvs(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧᾘ")
	elif iqHhJSxdaANDG5rlZm7B(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨᾙ")	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩᾚ")
	elif GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪᾛ")	in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫᾜ")
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨᾝ")		in yVgLqfcUN1iO4: JSlC1mtxL8H9d7AiMj2sPzUg	= hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩᾞ")
	if   HDaA1S9vRzgKeZUBm42q:	cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = iqHhJSxdaANDG5rlZm7B(u"ࠪาฬ฻ࠧᾟ"),HDaA1S9vRzgKeZUBm42q
	elif KNtTBWXxADlbvnpOz:		cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = EHUAyW2lQfe4LXmhgIGc(u"๋ࠫࠪอะัࠪᾠ"),KNtTBWXxADlbvnpOz
	elif JSlC1mtxL8H9d7AiMj2sPzUg:		cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪᾡ"),JSlC1mtxL8H9d7AiMj2sPzUg
	elif jYCf4ViPQxhueXRyS50lsvkZt2mz:	cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = iAGgjwb7tVMmacRJ(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬᾢ"),jYCf4ViPQxhueXRyS50lsvkZt2mz
	elif IqtZWA3ym4RoewUGa79zPC:	cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧᾣ"),j3ThPldsiUAqF0xXJtu
	else:			cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩᾤ"),j3ThPldsiUAqF0xXJtu
	return cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ
def vH2fZE7GIABl3Yy9Sr1oMe(url,source):
	XXzvmn7ewM8yBfoxua,KNtTBWXxADlbvnpOz,yVgLqfcUN1iO4,j3ThPldsiUAqF0xXJtu,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,pM0RwoYjfsUVZcqt6uTOiFkhEXCS = FoD0uGpW8I54(url,source)
	if   GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡄࡏࡔࡇࡍࠨᾥ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = xx1DRtjhcN(XXzvmn7ewM8yBfoxua,YwC7jt5BQHhTUvbdGeM6f2ZLx)
	elif cJSNFCIhymEfx6grGu0M(u"ࠪࡅࡐ࡝ࡁࡎࠩᾦ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = NNHDVzYX8O(XXzvmn7ewM8yBfoxua,C9uTVdSkLlb5UemavyB6NjWHFh,I5chimw4D1okfxlBE2UpbuHJvStsZ)
	elif VHrIziKUDuNGXkMla(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᾧ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = RnXoZzTYVh(XXzvmn7ewM8yBfoxua)
	elif dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ᾨ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = iqHhJSxdaANDG5rlZm7B(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾩ"),[G9G0YqivIfmUWO8K],[url]
	elif FWqeEzO1i8Dn0ga(u"ࠧࡺࡱࡸࡸࡺ࠭ᾪ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = DTF3Lwy9etRH8mI(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᾫ"),[G9G0YqivIfmUWO8K],[url]
	elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩᾬ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = rxWDdRBIct57i90s(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᾭ"),[G9G0YqivIfmUWO8K],[url]
	elif cJSNFCIhymEfx6grGu0M(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫᾮ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = SGzMOepn4H(XXzvmn7ewM8yBfoxua)
	elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧᾯ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = bJWPe8tmuq(XXzvmn7ewM8yBfoxua)
	elif DTF3Lwy9etRH8mI(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨᾰ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = ghAocGITQE(XXzvmn7ewM8yBfoxua)
	elif DTF3Lwy9etRH8mI(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᾱ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = cPoxDNVpRG(XXzvmn7ewM8yBfoxua)
	elif qTVF3icWwGXy5(u"ࠨࡕࡋࡓࡋࡎࡁࠨᾲ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = YZx3WrXdtJ(XXzvmn7ewM8yBfoxua)
	elif wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫᾳ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = oJCMRaUesk(XXzvmn7ewM8yBfoxua,pM0RwoYjfsUVZcqt6uTOiFkhEXCS)
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫᾴ")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = Rv4Vr8E9MU(XXzvmn7ewM8yBfoxua)
	elif VHrIziKUDuNGXkMla(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ᾵")		in source: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = RYWbOd6qZF(XXzvmn7ewM8yBfoxua)
	elif GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧᾶ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = IoEYqguvP8(XXzvmn7ewM8yBfoxua)
	elif dC3PsQJ0Ti28uYlov(u"࠭ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮ࠩᾷ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = Pq0s8YmBrW(XXzvmn7ewM8yBfoxua)
	elif FWqeEzO1i8Dn0ga(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧᾸ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = nA6guTHBYh1CP80rd(XXzvmn7ewM8yBfoxua)
	elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᾹ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = CCOzBEyRvg(XXzvmn7ewM8yBfoxua)
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫᾺ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = CCOzBEyRvg(XXzvmn7ewM8yBfoxua)
	elif RVpeGcmPxj9tCnT40Nf216(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪΆ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = xyz1QBauXg(XXzvmn7ewM8yBfoxua)
	elif hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡹࡼࡦࡶࡰࠪᾼ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = MMS8IfhQvJ(XXzvmn7ewM8yBfoxua)
	elif DTF3Lwy9etRH8mI(u"ࠬࡺࡶ࡬ࡵࡤࠫ᾽")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = MMS8IfhQvJ(XXzvmn7ewM8yBfoxua)
	elif dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡴࡷ࠯ࡩ࠲ࡨࡵ࡭ࠨι")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = MMS8IfhQvJ(XXzvmn7ewM8yBfoxua)
	elif ssGdubC4mngM9D5SRc3Ye(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ᾿")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = HIADrh8zPE(XXzvmn7ewM8yBfoxua)
	elif iqHhJSxdaANDG5rlZm7B(u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ῀")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = uhNyoqjf65(XXzvmn7ewM8yBfoxua)
	elif dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ῁")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = SzXBl0uhom2JA1bC9xwNDr6Zc8(XXzvmn7ewM8yBfoxua)
	elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡺࡸ࠺ࡵࠨῂ")			in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = cYuti2ydov(XXzvmn7ewM8yBfoxua)
	elif iqHhJSxdaANDG5rlZm7B(u"ࠫ࡫ࡧࡪࡦࡴࠪῃ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = Nb2MYp7A8v(XXzvmn7ewM8yBfoxua)
	elif UighHKAfySm4PWErqJ(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ῄ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = ROz51TArF8(XXzvmn7ewM8yBfoxua)
	elif iAGgjwb7tVMmacRJ(u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧ῅")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = ROz51TArF8(XXzvmn7ewM8yBfoxua)
	elif EHUAyW2lQfe4LXmhgIGc(u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫῆ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G5oJd6lKs2(XXzvmn7ewM8yBfoxua)
	elif vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫῇ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G5oJd6lKs2(XXzvmn7ewM8yBfoxua)
	elif qTVF3icWwGXy5(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩῈ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = AD62PQ4gWj(XXzvmn7ewM8yBfoxua)
	elif iqHhJSxdaANDG5rlZm7B(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪΈ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = dDs7jmXNAFHu1tBxSYqRZnflP4y8Mg(XXzvmn7ewM8yBfoxua)
	elif wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡧࡵ࡫ࡳࡣࠪῊ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = a4ms6ISnL5(XXzvmn7ewM8yBfoxua)
	elif cjbAkCIinvs(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪΉ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = JaizWxwHY6(XXzvmn7ewM8yBfoxua)
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨῌ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = VN1wd39pve(XXzvmn7ewM8yBfoxua)
	elif qTVF3icWwGXy5(u"ࠧࡦࡩࡼ࠱ࡧ࡫ࡳࡵ࠰ࡱࡩࡹ࠭῍")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = pg8n1POVBx(XXzvmn7ewM8yBfoxua)
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭῎")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ῏")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = NE6q2giP1A(XXzvmn7ewM8yBfoxua)
	elif rxWDdRBIct57i90s(u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩῐ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = tjyIDp0NTr(XXzvmn7ewM8yBfoxua)
	elif qTVF3icWwGXy5(u"ࠫࡺࡶࡢࡢ࡯ࠪῑ") 		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	else: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = dC3PsQJ0Ti28uYlov(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῒ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	if lP8McnNzaX5 and lP8McnNzaX5!=iAGgjwb7tVMmacRJ(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫΐ"): lP8McnNzaX5 = VHrIziKUDuNGXkMla(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪ῔")+lP8McnNzaX5
	return lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def XXnt8Y21BKAJP(lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS):
	JoSpAl1HIVd0f,dsGzqX4k0a8RLyc = [],[]
	for title,Y6YdkAMluFbwx in zip(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS):
		if Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx):
			JoSpAl1HIVd0f.append(title)
			dsGzqX4k0a8RLyc.append(Y6YdkAMluFbwx)
	if not dsGzqX4k0a8RLyc and not lP8McnNzaX5: lP8McnNzaX5 = bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠨ῕")
	return lP8McnNzaX5,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc
def i2Tu3gj1BhfXV(YOVkyEgnDR7Wo,url,source,o6IQax2n7skH):
	global OfE2y4cseK8NP,zOkGChDc3lxKXoNtr9v5QI,vf6BNMbx0XUTt8hGPcqrmASZF1j,xFU9803Giwah6pvP7jVMQ2sYkXHA,IPdLCXj7Rs9EhbOQ
	LB4VPHSJR5eZ6xXUApcrKGuz = []
	for IqtZWA3ym4RoewUGa79zPC in [zOkGChDc3lxKXoNtr9v5QI,vf6BNMbx0XUTt8hGPcqrmASZF1j,xFU9803Giwah6pvP7jVMQ2sYkXHA,IPdLCXj7Rs9EhbOQ]: IqtZWA3ym4RoewUGa79zPC[o6IQax2n7skH] = UighHKAfySm4PWErqJ(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪῖ"),[],[]
	NGHrLW8iI6,PJndHV0kgbjA4 = [NsJXgymVU8FcW4fTAjonhLHxreDEb,ddQP3MU86u,JJqvOYXcduZ3a2Bnz6FrjK7lCD,lfGgjKAu5U1DoyiMIVNkYBa3Sm4EOp],[]
	if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡪࡷࡪ࡬ࠨῗ") in url: NGHrLW8iI6,PJndHV0kgbjA4 = [NsJXgymVU8FcW4fTAjonhLHxreDEb,ddQP3MU86u,lfGgjKAu5U1DoyiMIVNkYBa3Sm4EOp],[xFU9803Giwah6pvP7jVMQ2sYkXHA]
	if FWqeEzO1i8Dn0ga(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬῘ") in url: NGHrLW8iI6,PJndHV0kgbjA4 = [NsJXgymVU8FcW4fTAjonhLHxreDEb],[vf6BNMbx0XUTt8hGPcqrmASZF1j,xFU9803Giwah6pvP7jVMQ2sYkXHA,IPdLCXj7Rs9EhbOQ]
	for IqtZWA3ym4RoewUGa79zPC in PJndHV0kgbjA4: IqtZWA3ym4RoewUGa79zPC[o6IQax2n7skH] = ETNq5t4MYngSsbfFD8J0v(u"࡙ࠬ࡫ࡪࡲࡳࡩࡩ࠭Ῑ"),[],[]
	for IqtZWA3ym4RoewUGa79zPC in NGHrLW8iI6:
		lB1eOx4fhcHP = fu19TY0PdM6AZB5.Thread(target=IqtZWA3ym4RoewUGa79zPC,args=(url,source,o6IQax2n7skH))
		LB4VPHSJR5eZ6xXUApcrKGuz.append(lB1eOx4fhcHP)
		lB1eOx4fhcHP.start()
		SSCU3jdyFn2V.sleep(UighHKAfySm4PWErqJ(u"࠴ල"))
	iVndvNSA2mXOteo9Rpgflz6yZjsFr,jMgdOrTSARkJqpYz,xi40AaIusgPzKb,jtlA2Ur3z8oaPnVQSXbH1gFJhcGZw = kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm
	timeout,step = t2sCrJ0xbgDRkf(u"࠷࠵඾"),SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
	for yyVl5dQtKBagJMibEIh0ZrkX8exOW in range(timeout//step):
		if not iVndvNSA2mXOteo9Rpgflz6yZjsFr and zOkGChDc3lxKXoNtr9v5QI[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz]!=RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧῚ"): iVndvNSA2mXOteo9Rpgflz6yZjsFr = P5VqbRSzjtO4UE1rZaolG67XA
		if not jMgdOrTSARkJqpYz and vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz]!=dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨΊ"): jMgdOrTSARkJqpYz = P5VqbRSzjtO4UE1rZaolG67XA
		if not xi40AaIusgPzKb and xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz]!=rr7Xolsp4JwjPK3L(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ῜"): xi40AaIusgPzKb = P5VqbRSzjtO4UE1rZaolG67XA
		if not jtlA2Ur3z8oaPnVQSXbH1gFJhcGZw and IPdLCXj7Rs9EhbOQ[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz]!=ssGdubC4mngM9D5SRc3Ye(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ῝"): jtlA2Ur3z8oaPnVQSXbH1gFJhcGZw = P5VqbRSzjtO4UE1rZaolG67XA
		if iVndvNSA2mXOteo9Rpgflz6yZjsFr and jMgdOrTSARkJqpYz and xi40AaIusgPzKb and jtlA2Ur3z8oaPnVQSXbH1gFJhcGZw: break
		if not zOkGChDc3lxKXoNtr9v5QI[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz] and zOkGChDc3lxKXoNtr9v5QI[o6IQax2n7skH][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]: break
		if not vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz] and vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]: break
		if not xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz] and xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]: break
		if not IPdLCXj7Rs9EhbOQ[o6IQax2n7skH][dQ5JhEYolPmy1fvHktMw6NFRxiz] and IPdLCXj7Rs9EhbOQ[o6IQax2n7skH][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]: break
		SSCU3jdyFn2V.sleep(step)
	for lB1eOx4fhcHP in LB4VPHSJR5eZ6xXUApcrKGuz: lB1eOx4fhcHP.join(VHrIziKUDuNGXkMla(u"࠶඿"))
	KDhAwLgl5p7GM = qTVF3icWwGXy5(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩ῞")
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = zOkGChDc3lxKXoNtr9v5QI[o6IQax2n7skH]
	ODnaR0N8UHv7Twy6jS = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	if lP8McnNzaX5==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ῟") or ODnaR0N8UHv7Twy6jS: return KDhAwLgl5p7GM,lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	YOVkyEgnDR7Wo += hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧῠ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)[:RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠾࠰ව")]
	KDhAwLgl5p7GM = iAGgjwb7tVMmacRJ(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬῡ")
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH]
	ODnaR0N8UHv7Twy6jS = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	if lP8McnNzaX5==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬῢ") or ODnaR0N8UHv7Twy6jS: return KDhAwLgl5p7GM,lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	YOVkyEgnDR7Wo += wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠹࠺ࠡࠢࠪΰ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)[:iAGgjwb7tVMmacRJ(u"࠸࠱ශ")]
	KDhAwLgl5p7GM = EHUAyW2lQfe4LXmhgIGc(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠴ࠨῤ")
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH]
	ODnaR0N8UHv7Twy6jS = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	if lP8McnNzaX5==dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῥ") or ODnaR0N8UHv7Twy6jS: return KDhAwLgl5p7GM,lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	YOVkyEgnDR7Wo += t2sCrJ0xbgDRkf(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠶࠽ࠤࠥ࠭ῦ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)[:RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠹࠲ෂ")]
	KDhAwLgl5p7GM = rr7Xolsp4JwjPK3L(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫῧ")
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = IPdLCXj7Rs9EhbOQ[o6IQax2n7skH]
	ODnaR0N8UHv7Twy6jS = x9SoTXBLDYt3Zd56gNrabl(ODnaR0N8UHv7Twy6jS)
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	if lP8McnNzaX5==FWqeEzO1i8Dn0ga(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῨ") or ODnaR0N8UHv7Twy6jS: return KDhAwLgl5p7GM,lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	YOVkyEgnDR7Wo += iqHhJSxdaANDG5rlZm7B(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠺ࡀࠠࠡࠩῩ")+lP8McnNzaX5.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)[:dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠺࠳ස")]
	OfE2y4cseK8NP[o6IQax2n7skH] = YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	return KDhAwLgl5p7GM,YOVkyEgnDR7Wo,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def NsJXgymVU8FcW4fTAjonhLHxreDEb(url,source,o6IQax2n7skH):
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡰࡤࡱࡪ࠭Ὺ"))
	ODnaR0N8UHv7Twy6jS = []
	if qTVF3icWwGXy5(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧΎ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = JaizWxwHY6(url)
	elif ETNq5t4MYngSsbfFD8J0v(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࡸࡷࡪࡸࡣࡰࠩῬ") in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = sk4xJVydw9nNztPG7oLbpOUe(url)
	elif rr7Xolsp4JwjPK3L(u"ࠫࡾࡵࡵࡵࡷࠪ῭")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = nnJUZtLkYDXA19SEhydmRFiwzv(url)
	elif EHUAyW2lQfe4LXmhgIGc(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ΅")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = nnJUZtLkYDXA19SEhydmRFiwzv(url)
	elif rr7Xolsp4JwjPK3L(u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ`")	in url   : lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = aeDh10ERzq8KrG7pT9BCgjuSw(url)
	elif rr7Xolsp4JwjPK3L(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ῰")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = M5B94WgJfbkAxhIX3nqCwcE(url)
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ῱")		in url   : lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = RnXoZzTYVh(url)
	elif UighHKAfySm4PWErqJ(u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬῲ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = g6eVm8UF0WwN4OJ2QXSnCAtTdh1(url)
	elif iqHhJSxdaANDG5rlZm7B(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫῳ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = VXfZd6JQLTDo7hOxqGrBEFKWN(url)
	elif jR9YtmsgDX8nTQlMb6G3(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬῴ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = GctvNqFxUXdBuArysba(url)
	elif hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ῵")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = ufPUCc8zrwX2Tx7t3vHA0oIK5R1(url)
	elif FWqeEzO1i8Dn0ga(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬῶ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = JNuTRbqGdXcCAUwQ(url)
	elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪῷ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = JNuTRbqGdXcCAUwQ(url)
	elif vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡷࡳࡦࡦࡳࠧῸ") 		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
	elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫΌ") 	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = xG6bM0fC3WUrDS2dXQIYBaNZypu7gO(url)
	elif Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭Ὼ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = QfYkaKFeERJ7mvphWZr(url)
	elif vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨΏ") 	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = llBkIghaAtVZFiD(url)
	elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ῼ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = QJ5hDgywiAnRoEt17Bkpq2I3(url)
	elif FWqeEzO1i8Dn0ga(u"࠭ࡵࡱࡤࠪ´") 			in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = hEfcxwbLNCym(url)
	elif t2sCrJ0xbgDRkf(u"ࠧࡶࡲࡳࠫ῾") 			in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = hEfcxwbLNCym(url)
	elif RVpeGcmPxj9tCnT40Nf216(u"ࠨࡷࡴࡰࡴࡧࡤࠨ῿") 		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = er5oHMm7Atp0NZJa2qwyX9(url)
	elif vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭ࠀ") 	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = B6A1cRgtrhU4pVYxDlSa8P(url)
	elif rr7Xolsp4JwjPK3L(u"ࠬࡼࡩࡥࡤࡲࡦࠬࠁ")		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = wivyGHKTQXJqt7VBfLM1W9ED(url)
	elif iqHhJSxdaANDG5rlZm7B(u"࠭ࡶࡪࡦࡲࡾࡦ࠭ࠂ") 		in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = GPbYFvUBRhm9nyg74OM8ku6rCi5(url)
	elif hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫࠃ") 	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = pKDzLymRPZl(url)
	elif DTF3Lwy9etRH8mI(u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬࠄ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = q3zom68EfHG09bJ(url)
	elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭ࠅ")	in yVgLqfcUN1iO4: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = es8Y7RjbvJWiFUB05xI4tQZnaS(url)
	else: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[],[]
	global zOkGChDc3lxKXoNtr9v5QI
	if lP8McnNzaX5 and lP8McnNzaX5!=iAGgjwb7tVMmacRJ(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࠆ"): lP8McnNzaX5 = qTVF3icWwGXy5(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧࠇ")
	zOkGChDc3lxKXoNtr9v5QI[o6IQax2n7skH] = lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	return
def ddQP3MU86u(url,source,o6IQax2n7skH):
	global vf6BNMbx0XUTt8hGPcqrmASZF1j
	if iqHhJSxdaANDG5rlZm7B(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠈ") in url:
		vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH] = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡕ࡮࡭ࡵࡶࡥࡥࠩࠉ"),[],[]
		return
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[],[]
	if Ig4jFuXGfUQeCn6wlB8(url): lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
	if not ODnaR0N8UHv7Twy6jS: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = EXWGFe7gvoi1zM2qtkpuh3U4Nr0YB(url)
	if not ODnaR0N8UHv7Twy6jS: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = ssWwpzyIxZrH08mViTCb2M4LqdkUNa(url)
	if not ODnaR0N8UHv7Twy6jS:
		if lP8McnNzaX5==iqHhJSxdaANDG5rlZm7B(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠊ"): lP8McnNzaX5 = G9G0YqivIfmUWO8K
		vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH] = yiaeCEwJjOcWA4ZSd5h(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫࠋ")+lP8McnNzaX5,[],[]
		return
	vf6BNMbx0XUTt8hGPcqrmASZF1j[o6IQax2n7skH] = lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	return
def JJqvOYXcduZ3a2Bnz6FrjK7lCD(url,source,o6IQax2n7skH):
	fEKoHajMCOh = G9G0YqivIfmUWO8K
	tRojAyBgfDH37eLCwP4dWl = kkMuQrLWcEayRm
	try:
		import resolveurl as R9K0XmeaIdHYEAFwo8QS
		tRojAyBgfDH37eLCwP4dWl = R9K0XmeaIdHYEAFwo8QS.resolve(url)
	except Exception as ooisRrTEKOxbyJMXGq9SCP1wvYc: fEKoHajMCOh = str(ooisRrTEKOxbyJMXGq9SCP1wvYc)
	global xFU9803Giwah6pvP7jVMQ2sYkXHA
	if not tRojAyBgfDH37eLCwP4dWl:
		if fEKoHajMCOh==G9G0YqivIfmUWO8K:
			fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
			if fEKoHajMCOh!=DTF3Lwy9etRH8mI(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬࠌ"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
		lP8McnNzaX5 = fEKoHajMCOh.splitlines()[-fdQOo6Hu4B5Rbg]
		xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH] = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭ࠍ")+lP8McnNzaX5,[],[]
		return
	xFU9803Giwah6pvP7jVMQ2sYkXHA[o6IQax2n7skH] = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[tRojAyBgfDH37eLCwP4dWl]
	return
def lfGgjKAu5U1DoyiMIVNkYBa3Sm4EOp(url,source,o6IQax2n7skH):
	fEKoHajMCOh = G9G0YqivIfmUWO8K
	tRojAyBgfDH37eLCwP4dWl = kkMuQrLWcEayRm
	try:
		import yt_dlp as d8CWhcXKxarR
		UUKrMeA8q9w = d8CWhcXKxarR.YoutubeDL({wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭ࠎ"): P5VqbRSzjtO4UE1rZaolG67XA})
		tRojAyBgfDH37eLCwP4dWl = UUKrMeA8q9w.extract_info(url,download=kkMuQrLWcEayRm)
	except Exception as ooisRrTEKOxbyJMXGq9SCP1wvYc: fEKoHajMCOh = str(ooisRrTEKOxbyJMXGq9SCP1wvYc)
	global IPdLCXj7Rs9EhbOQ
	if not tRojAyBgfDH37eLCwP4dWl or FWqeEzO1i8Dn0ga(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ࠏ") not in list(tRojAyBgfDH37eLCwP4dWl.keys()):
		if fEKoHajMCOh==G9G0YqivIfmUWO8K:
			fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
			if fEKoHajMCOh!=EHUAyW2lQfe4LXmhgIGc(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩࠐ"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
		lP8McnNzaX5 = fEKoHajMCOh.splitlines()[-fdQOo6Hu4B5Rbg]
		IPdLCXj7Rs9EhbOQ[o6IQax2n7skH] = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪࠑ")+lP8McnNzaX5,[],[]
	else:
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
		for Y6YdkAMluFbwx in tRojAyBgfDH37eLCwP4dWl[dC3PsQJ0Ti28uYlov(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩࠒ")]:
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(Y6YdkAMluFbwx[iAGgjwb7tVMmacRJ(u"ࠩࡩࡳࡷࡳࡡࡵࠩࠓ")])
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡹࡷࡲࠧࠔ")])
		IPdLCXj7Rs9EhbOQ[o6IQax2n7skH] = G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	return
def EXWGFe7gvoi1zM2qtkpuh3U4Nr0YB(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡌࡋࡔࠨࠕ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,dC3PsQJ0Ti28uYlov(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡈࡎࡘࡅࡄࡖࡢ࡙ࡗࡒ࠭࠲ࡵࡷࠫࠖ"))
	headers = D7omduSeM5Gk.headers
	if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࠗ") in list(headers.keys()):
		Y6YdkAMluFbwx = D7omduSeM5Gk.headers[ETNq5t4MYngSsbfFD8J0v(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࠘")]
		if Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx): return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫ࠙"),[],[]
def x9SoTXBLDYt3Zd56gNrabl(pUrSPMLW53w1cYRD08fHzodEZ):
	if iAGgjwb7tVMmacRJ(u"ࠩ࡯࡭ࡸࡺࠧࠚ") in str(type(pUrSPMLW53w1cYRD08fHzodEZ)):
		dsGzqX4k0a8RLyc = []
		for Y6YdkAMluFbwx in pUrSPMLW53w1cYRD08fHzodEZ:
			if FWqeEzO1i8Dn0ga(u"ࠪࡷࡹࡸࠧࠛ") in str(type(Y6YdkAMluFbwx)): Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			dsGzqX4k0a8RLyc.append(Y6YdkAMluFbwx)
	else: dsGzqX4k0a8RLyc = pUrSPMLW53w1cYRD08fHzodEZ.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
	return dsGzqX4k0a8RLyc
def iizAxmpbu0WYTGaPU7gHyM(EEm7hgHpsjDO82aIQSNMf9yY6ZXrc,source):
	data = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡱ࡯ࡳࡵࠩࠜ"),iqHhJSxdaANDG5rlZm7B(u"࡙ࠬࡅࡓࡘࡈࡖࡘ࠭ࠝ"),EEm7hgHpsjDO82aIQSNMf9yY6ZXrc)
	if data:
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = zip(*data)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = list(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO),list(ODnaR0N8UHv7Twy6jS)
		return Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,CAE1JeRThczIad7SOt95 = [],[],[]
	for Y6YdkAMluFbwx in EEm7hgHpsjDO82aIQSNMf9yY6ZXrc:
		if RVpeGcmPxj9tCnT40Nf216(u"࠭࠯࠰ࠩࠞ") not in Y6YdkAMluFbwx: continue
		cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ = qq7GSYLQePjBE(Y6YdkAMluFbwx,source)
		I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠧ࡝ࡦ࠮ࠫࠟ"),I5chimw4D1okfxlBE2UpbuHJvStsZ,oo9kuULlebNgpY0Om.DOTALL)
		if I5chimw4D1okfxlBE2UpbuHJvStsZ: I5chimw4D1okfxlBE2UpbuHJvStsZ = int(I5chimw4D1okfxlBE2UpbuHJvStsZ[dQ5JhEYolPmy1fvHktMw6NFRxiz])
		else: I5chimw4D1okfxlBE2UpbuHJvStsZ = dQ5JhEYolPmy1fvHktMw6NFRxiz
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,qTVF3icWwGXy5(u"ࠨࡰࡤࡱࡪ࠭ࠠ"))
		CAE1JeRThczIad7SOt95.append([cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx,yVgLqfcUN1iO4])
	if CAE1JeRThczIad7SOt95:
		tLODKzlj6RNysUcMaQE = sorted(CAE1JeRThczIad7SOt95,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: (key[xsCEkXb6tgrh3195YZ],key[dQ5JhEYolPmy1fvHktMw6NFRxiz],key[c1R9fnIY4XBDZ],key[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU],key[fdQOo6Hu4B5Rbg],key[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠸හ")],key[qTVF3icWwGXy5(u"࠺ළ")]))
		JzQ1sP6HyGwO9,TT7gyYqNeIn = [],[]
		for r5B4eRs8aPk2jzuUHCcnYGAN9dl in tLODKzlj6RNysUcMaQE:
			cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx,yVgLqfcUN1iO4 = r5B4eRs8aPk2jzuUHCcnYGAN9dl
			if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"่ࠩๅ฻๊ࠧࠡ") in C9uTVdSkLlb5UemavyB6NjWHFh:
				TT7gyYqNeIn.append(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
				continue
			if r5B4eRs8aPk2jzuUHCcnYGAN9dl not in JzQ1sP6HyGwO9: JzQ1sP6HyGwO9.append(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
		JzQ1sP6HyGwO9 = TT7gyYqNeIn+JzQ1sP6HyGwO9
		JXKAgPztneLxQh = dQ5JhEYolPmy1fvHktMw6NFRxiz
		for cEa8y9Un5GPC2w,YwC7jt5BQHhTUvbdGeM6f2ZLx,C9uTVdSkLlb5UemavyB6NjWHFh,FF94GpU6MrbZy,I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx,yVgLqfcUN1iO4 in JzQ1sP6HyGwO9:
			I5chimw4D1okfxlBE2UpbuHJvStsZ = str(I5chimw4D1okfxlBE2UpbuHJvStsZ) if I5chimw4D1okfxlBE2UpbuHJvStsZ else G9G0YqivIfmUWO8K
			title = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪื๏ืแาࠩࠢ")+ww0sZkBU9JKd+C9uTVdSkLlb5UemavyB6NjWHFh+ww0sZkBU9JKd+cEa8y9Un5GPC2w+ww0sZkBU9JKd+I5chimw4D1okfxlBE2UpbuHJvStsZ+ww0sZkBU9JKd+FF94GpU6MrbZy+ww0sZkBU9JKd+YwC7jt5BQHhTUvbdGeM6f2ZLx
			if yVgLqfcUN1iO4 not in title: title = title+ww0sZkBU9JKd+yVgLqfcUN1iO4
			title = title.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠫࠪ࠭ࠣ"),G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
			JXKAgPztneLxQh += fdQOo6Hu4B5Rbg
			title = str(JXKAgPztneLxQh)+RVpeGcmPxj9tCnT40Nf216(u"ࠬ࠴ࠠࠨࠤ")+title
			if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		if ODnaR0N8UHv7Twy6jS:
			data = zip(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS)
			if data: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,ETNq5t4MYngSsbfFD8J0v(u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧࠥ"),EEm7hgHpsjDO82aIQSNMf9yY6ZXrc,data,AH0BQ4LKlDMrfvqWmXn5)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = list(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO),list(ODnaR0N8UHv7Twy6jS)
	return Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def nA6guTHBYh1CP80rd(url):
	if hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࠦ") in url:
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,url)
		if ODnaR0N8UHv7Twy6jS: return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
		return FWqeEzO1i8Dn0ga(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨࠧ"),[],[]
	return hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠨ"),[G9G0YqivIfmUWO8K],[url]
def IoEYqguvP8(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,GGoLgj5BFbWI = [],[]
	if RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭ࠩ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,qTVF3icWwGXy5(u"ࠫࡌࡋࡔࠨࠪ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧࠫ"))
		if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࠬ") in D7omduSeM5Gk.headers:
			Y6YdkAMluFbwx = D7omduSeM5Gk.headers[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ࠭")]
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
			yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,jR9YtmsgDX8nTQlMb6G3(u"ࠨࡰࡤࡱࡪ࠭࠮"))
			GGoLgj5BFbWI.append(yVgLqfcUN1iO4)
	elif wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ࠯") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,jR9YtmsgDX8nTQlMb6G3(u"ࠪࡋࡊ࡚ࠧ࠰"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭࠱"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		ytgAme6a3Mi4Wq79Zdc1PDClTIRK = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ࠲"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if ytgAme6a3Mi4Wq79Zdc1PDClTIRK:
			ytgAme6a3Mi4Wq79Zdc1PDClTIRK = ytgAme6a3Mi4Wq79Zdc1PDClTIRK[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			l1RSViQejk8r5LOA4PWwYBX = NbUXSx5TuGC(ytgAme6a3Mi4Wq79Zdc1PDClTIRK)
			L7hUToPpbQRdO9Ca6lG5kF = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ࠳"),l1RSViQejk8r5LOA4PWwYBX,oo9kuULlebNgpY0Om.DOTALL)
			if L7hUToPpbQRdO9Ca6lG5kF:
				L7hUToPpbQRdO9Ca6lG5kF = L7hUToPpbQRdO9Ca6lG5kF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				L7hUToPpbQRdO9Ca6lG5kF = bRCSwcA89e4J7pqdays5PxGiD2(UighHKAfySm4PWErqJ(u"ࠧ࡭࡫ࡶࡸࠬ࠴"),L7hUToPpbQRdO9Ca6lG5kF)
				for dict in L7hUToPpbQRdO9Ca6lG5kF:
					Y6YdkAMluFbwx = dict[yiaeCEwJjOcWA4ZSd5h(u"ࠨࡨ࡬ࡰࡪ࠭࠵")]
					I5chimw4D1okfxlBE2UpbuHJvStsZ = dict[DTF3Lwy9etRH8mI(u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࠶")]
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
					yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,EHUAyW2lQfe4LXmhgIGc(u"ࠪࡲࡦࡳࡥࠨ࠷"))
					GGoLgj5BFbWI.append(I5chimw4D1okfxlBE2UpbuHJvStsZ+ww0sZkBU9JKd+yVgLqfcUN1iO4)
		elif bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭࠸") in D7omduSeM5Gk.headers:
			Y6YdkAMluFbwx = D7omduSeM5Gk.headers[bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ࠹")]
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
			yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭࡮ࡢ࡯ࡨࠫ࠺"))
			GGoLgj5BFbWI.append(yVgLqfcUN1iO4)
		if GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧ࠻") in url:
			Y6YdkAMluFbwx = url.split(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡁࡸࡶࡱࡃࠧ࠼"))[fdQOo6Hu4B5Rbg]
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split(VHrIziKUDuNGXkMla(u"ࠩࠩࠫ࠽"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			if Y6YdkAMluFbwx:
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
				GGoLgj5BFbWI.append(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪ࠾"))
	else:
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(url)
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,EHUAyW2lQfe4LXmhgIGc(u"ࠫࡳࡧ࡭ࡦࠩ࠿"))
		GGoLgj5BFbWI.append(yVgLqfcUN1iO4)
	if not ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh: return VHrIziKUDuNGXkMla(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩࡀ"),[],[]
	elif len(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh)==fdQOo6Hu4B5Rbg: Y6YdkAMluFbwx = ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	else:
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(RVpeGcmPxj9tCnT40Nf216(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫࡁ"),GGoLgj5BFbWI)
		if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return qTVF3icWwGXy5(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࡂ"),[],[]
		Y6YdkAMluFbwx = ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh[PXeEIRkdShOGm45lbLJc2B38s]
	return iqHhJSxdaANDG5rlZm7B(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡃ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def sk4xJVydw9nNztPG7oLbpOUe(url):
	headers = {rxWDdRBIct57i90s(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࡄ"):dC3PsQJ0Ti28uYlov(u"ࠪࡏࡴࡪࡩ࠰ࠩࡅ")+str(F7aJYwLMEmxAVRupWf)}
	for p0p6MxKbklodNCR92Wv in range(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠺࠶ෆ")):
		SSCU3jdyFn2V.sleep(DTF3Lwy9etRH8mI(u"࠶࠮࠲࠲࠳෇"))
		D7omduSeM5Gk = zjZ540rAadvbsRu6qywPicxXLtpTM(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡌࡋࡔࠨࡆ"),url,G9G0YqivIfmUWO8K,headers,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩࡇ"))
		if iAGgjwb7tVMmacRJ(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨࡈ") in list(D7omduSeM5Gk.headers.keys()):
			Y6YdkAMluFbwx = D7omduSeM5Gk.headers[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩࡉ")]
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+rr7Xolsp4JwjPK3L(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧࡊ")+headers[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࡋ")]
			return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
		if D7omduSeM5Gk.code!=jR9YtmsgDX8nTQlMb6G3(u"࠴࠳࠻෈"): break
	return UighHKAfySm4PWErqJ(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩࡌ"),[],[]
def aeDh10ERzq8KrG7pT9BCgjuSw(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡌࡋࡔࠨࡍ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫࡎ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪࡏ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		return G9G0YqivIfmUWO8K,[I5chimw4D1okfxlBE2UpbuHJvStsZ],[Y6YdkAMluFbwx]
	return EHUAyW2lQfe4LXmhgIGc(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨࡐ"),[],[]
def cJDB5O9ZsN(url):
	if bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ࠱ࡺࡩࡪࡶࡩࡴ࠱ࠪࡑ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,t2sCrJ0xbgDRkf(u"ࠩࡊࡉ࡙࠭ࡒ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠸࠭࠲ࡵࡷࠫࡓ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡱࡶࡣ࡯࡭ࡹࡿ࠾ࠨࡔ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx: url = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else: return VHrIziKUDuNGXkMla(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇ࠲ࠨࡕ"),[],[]
	return iAGgjwb7tVMmacRJ(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࡖ"),[G9G0YqivIfmUWO8K],[url]
def Rv4Vr8E9MU(url):
	if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡴࡧࡵࡺࡂ࠭ࡗ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,FWqeEzO1i8Dn0ga(u"ࠨࡉࡈࡘࠬࡘ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡌࡎࡕࡗࡆࡆ࠳࠱ࡴࡶ࡙ࠪ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅ࡚ࠩࠣࠩ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx: url = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else:
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠦࡆࡲࡢࡢࡒ࡯ࡥࡾ࡫ࡲࡄࡱࡱࡸࡷࡵ࡬࡝ࠪࠪࠬ࠳࠰࠿࡛ࠪࠩࠥ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if Y6YdkAMluFbwx:
				url = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				url = jaFsD83SB9ZQkrxeI.b64decode(url)
				if LTze51miOknVcslNF43WSA6vMjYZt: url = url.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			else: return ETNq5t4MYngSsbfFD8J0v(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡎࡐࡗ࡙ࡈࡁࠨ࡜"),[],[]
	return hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࡝"),[G9G0YqivIfmUWO8K],[url]
def RnXoZzTYVh(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡈࡇࡗࠫ࡞"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪ࡟"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	GagwMT6q3oc7UZ2Q = mq1uWkCvVfw(GagwMT6q3oc7UZ2Q)
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(EHUAyW2lQfe4LXmhgIGc(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪࡠ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	return cjbAkCIinvs(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧࡡ"),[],[]
def RYWbOd6qZF(url):
	if len(url)>EHUAyW2lQfe4LXmhgIGc(u"࠳࠲࠳෉"):
		url = url.strip(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫ࠴࠭ࡢ"))+VHrIziKUDuNGXkMla(u"ࠬ࠵ࠧࡣ")
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,ETNq5t4MYngSsbfFD8J0v(u"࠭ࡇࡆࡖࠪࡤ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡆࡘࡏ࡛ࡃ࠰࠵ࡸࡺࠧࡥ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		if dQ5JhEYolPmy1fvHktMw6NFRxiz and bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩࡦ") in GagwMT6q3oc7UZ2Q:
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠩࠥࡰࡴࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨࡧ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if cSLKDEATk7y10ovtGZCwF:
				BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲්")]
				cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡀࡸࡩࡲࡪࡲࡷࡂࡻࡧࡲࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺࠧࡨ"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				if cSLKDEATk7y10ovtGZCwF:
					BN1KdkzCmvshw = XaMFZPCb7J9tN(cSLKDEATk7y10ovtGZCwF[t2sCrJ0xbgDRkf(u"࠳෋")])
		elif len(GagwMT6q3oc7UZ2Q)<GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠸࠵࠶෌"): Y6YdkAMluFbwx = GagwMT6q3oc7UZ2Q
		else: return bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡂࡔࡒ࡞ࡆ࠭ࡩ"),[],[]
		return bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ࠭ࡪ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return rxWDdRBIct57i90s(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ࡫"),[G9G0YqivIfmUWO8K],[url]
def YZx3WrXdtJ(url):
	if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ࠰ࡦࡲࡻࡳ࠴ࡰࡩࡲࠪ࡬") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡉࡈࡘࠬ࡭"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡈࡋࡅ࠲࠷ࡳࡵࠩ࡮"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡺࡶࡦࡶࡰࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࡯"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		url = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return DTF3Lwy9etRH8mI(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࡰ"),[G9G0YqivIfmUWO8K],[url]
def SGzMOepn4H(url):
	if ssGdubC4mngM9D5SRc3Ye(u"ࠬࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩࡱ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,dC3PsQJ0Ti28uYlov(u"࠭ࡇࡆࡖࠪࡲ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁ࠵ࡗ࠰࠵ࡸࡺࠧࡳ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡴ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if ETNq5t4MYngSsbfFD8J0v(u"ࠩ࡫ࡸࡹࡶࠧࡵ") in Y6YdkAMluFbwx: return GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࡶ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
		return rr7Xolsp4JwjPK3L(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭ࡷ"),[],[]
	return yiaeCEwJjOcWA4ZSd5h(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡸ"),[G9G0YqivIfmUWO8K],[url]
def xyz1QBauXg(url):
	XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {VHrIziKUDuNGXkMla(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩࡹ"):dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨࡺ"),DTF3Lwy9etRH8mI(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࡻ"):RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࡼ")}
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,VHrIziKUDuNGXkMla(u"ࠪࡔࡔ࡙ࡔࠨࡽ"),XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫࡾ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(ssGdubC4mngM9D5SRc3Ye(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࡿ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: return RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨࢀ"),[],[]
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return jR9YtmsgDX8nTQlMb6G3(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࢁ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def uhNyoqjf65(url):
	headers = {t2sCrJ0xbgDRkf(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫࢂ"):vCmnFshSi4flecXIY2gy38G0DJw(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪࢃ")}
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,rxWDdRBIct57i90s(u"ࠪࡋࡊ࡚ࠧࢄ"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭ࢅ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࢆ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	if not Y6YdkAMluFbwx: return iAGgjwb7tVMmacRJ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪࢇ"),[],[]
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ࢈"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def HIADrh8zPE(url):
	XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࢉ"):Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࢊ")}
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡔࡔ࡙ࡔࠨࢋ"),XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭ࢌ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࡡࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤࠪࡡࠬ࠭ࠧࢍ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	if not Y6YdkAMluFbwx: return t2sCrJ0xbgDRkf(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪࢎ"),[],[]
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡩࡶࡷࡴࠬ࢏") not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = yiaeCEwJjOcWA4ZSd5h(u"ࠨࡪࡷࡸࡵࡀࠧ࢐")+Y6YdkAMluFbwx
	return iAGgjwb7tVMmacRJ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࢑"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def cPoxDNVpRG(url):
	z7GYBmKiXwreV2QybCNn80v9pT,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = url,[],[]
	if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪ࠳ࡦࡰࡡࡹ࠱ࠪ࢒") in url:
		XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {iqHhJSxdaANDG5rlZm7B(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࢓"):cJSNFCIhymEfx6grGu0M(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ࢔")}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,iqHhJSxdaANDG5rlZm7B(u"࠭ࡐࡐࡕࡗࠫ࢕"),XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩ࢖"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		CgEYJzhcIf6 = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀ࡟ࠧ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢࠨ࡟ࠪࠫࠬࢗ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if CgEYJzhcIf6: z7GYBmKiXwreV2QybCNn80v9pT = CgEYJzhcIf6[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ࢘"),[G9G0YqivIfmUWO8K],[z7GYBmKiXwreV2QybCNn80v9pT]
def MMS8IfhQvJ(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡋࡊ࡚࢙ࠧ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶ࢚ࠪ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ࢛"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	if SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V:
		SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V[dQ5JhEYolPmy1fvHktMw6NFRxiz][iAGgjwb7tVMmacRJ(u"࠷෍"):]
		SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = jaFsD83SB9ZQkrxeI.b64decode(SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V)
		if LTze51miOknVcslNF43WSA6vMjYZt: SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V = SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࢜"),SJ8AtziPBkwHTjoFgsIvYKq1WrMn0V,oo9kuULlebNgpY0Om.DOTALL)
	else: Y6YdkAMluFbwx = G9G0YqivIfmUWO8K
	if not Y6YdkAMluFbwx: return dC3PsQJ0Ti28uYlov(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡗ࡚ࡋ࡛ࡎࠨ࢝"),[],[]
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡪࡷࡸࡵ࠭࢞") not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ࢟")+Y6YdkAMluFbwx
	return wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࢠ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def SzXBl0uhom2JA1bC9xwNDr6Zc8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡌࡋࡔࠨࢡ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧࢢ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢣ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: return iAGgjwb7tVMmacRJ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫࢤ"),[],[]
	Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࢥ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def JaizWxwHY6(url):
	id = url.split(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩ࠲ࠫࢦ"))[-dC3PsQJ0Ti28uYlov(u"࠷෎")]
	if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪࢧ") in url: url = url.replace(ETNq5t4MYngSsbfFD8J0v(u"ࠫ࠴࡫࡭ࡣࡧࡧࠫࢨ"),G9G0YqivIfmUWO8K)
	url = url.replace(t2sCrJ0xbgDRkf(u"ࠬ࠴ࡣࡰ࡯࠲ࠫࢩ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡲ࡫ࡴࡢࡦࡤࡸࡦ࠵ࠧࢪ"))
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,t2sCrJ0xbgDRkf(u"ࠧࡈࡇࡗࠫࢫ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭ࢬ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	lP8McnNzaX5 = rxWDdRBIct57i90s(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩࢭ")
	ooisRrTEKOxbyJMXGq9SCP1wvYc = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫࢮ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if ooisRrTEKOxbyJMXGq9SCP1wvYc: lP8McnNzaX5 = ooisRrTEKOxbyJMXGq9SCP1wvYc[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	url = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢯ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not url and lP8McnNzaX5:
		return lP8McnNzaX5,[],[]
	Y6YdkAMluFbwx = url[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(iqHhJSxdaANDG5rlZm7B(u"ࠬࡢ࡜ࠨࢰ"),G9G0YqivIfmUWO8K)
	YeMhgjKoiwFRbATH5d8QVGmv4fsB,EEm7hgHpsjDO82aIQSNMf9yY6ZXrc = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,Y6YdkAMluFbwx)
	wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪࢱ"))
	if wwCFVzNkHGQsoRYgpDhtL4qJ7dBP and t2sCrJ0xbgDRkf(u"ࠧ࠮ࠩࢲ") not in wwCFVzNkHGQsoRYgpDhtL4qJ7dBP: title,Y6YdkAMluFbwx = YeMhgjKoiwFRbATH5d8QVGmv4fsB[EHUAyW2lQfe4LXmhgIGc(u"࠰ා")],EEm7hgHpsjDO82aIQSNMf9yY6ZXrc[EHUAyW2lQfe4LXmhgIGc(u"࠰ා")]
	else:
		MYgd8SpmZE = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࡟ࡿࠧ࡯ࡤࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࢳ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if MYgd8SpmZE: fR8rh7yx0KJWZEiY3q,QeOvljhYpsg14I03ca6oFxwHyJ,llKV1ZWbG0zauODFHofsQm = MYgd8SpmZE[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else: fR8rh7yx0KJWZEiY3q,QeOvljhYpsg14I03ca6oFxwHyJ,llKV1ZWbG0zauODFHofsQm = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		llKV1ZWbG0zauODFHofsQm = llKV1ZWbG0zauODFHofsQm.replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩ࡟࠳ࠬࢴ"),FWqeEzO1i8Dn0ga(u"ࠪ࠳ࠬࢵ"))
		QeOvljhYpsg14I03ca6oFxwHyJ = zDBtm4MwIagkfcpE5oxJOAq6lZQY(QeOvljhYpsg14I03ca6oFxwHyJ)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = [A7XhkmSYZlidyMt5FpWqTgjNezbnD+cjbAkCIinvs(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࢶ")+QeOvljhYpsg14I03ca6oFxwHyJ+zzGfwLAyN5HTxUoJeaivY]+YeMhgjKoiwFRbATH5d8QVGmv4fsB
		ODnaR0N8UHv7Twy6jS = [llKV1ZWbG0zauODFHofsQm]+EEm7hgHpsjDO82aIQSNMf9yY6ZXrc
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(qTVF3icWwGXy5(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭ࢷ")+str(len(ODnaR0N8UHv7Twy6jS)-wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲ැ"))+qTVF3icWwGXy5(u"࠭ࠠๆๆไ࠭ࠬࢸ"),Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
		if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return ssGdubC4mngM9D5SRc3Ye(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࢹ"),[],[]
		elif PXeEIRkdShOGm45lbLJc2B38s==dQ5JhEYolPmy1fvHktMw6NFRxiz:
			yyjYbUs0dO9LCP = yyrcMwk6RWmH3xOKQUpGdghiX.argv[dQ5JhEYolPmy1fvHktMw6NFRxiz]+UighHKAfySm4PWErqJ(u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧࢺ")+llKV1ZWbG0zauODFHofsQm+cJSNFCIhymEfx6grGu0M(u"ࠩࠩࡸࡪࡾࡴࡵ࠿ࠪࢻ")+QeOvljhYpsg14I03ca6oFxwHyJ
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(iqHhJSxdaANDG5rlZm7B(u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢࢼ")+yyjYbUs0dO9LCP+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠦ࠮ࠨࢽ"))
			return EHUAyW2lQfe4LXmhgIGc(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࢾ"),[],[]
		title,Y6YdkAMluFbwx = Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[PXeEIRkdShOGm45lbLJc2B38s],ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	return G9G0YqivIfmUWO8K,[title],[Y6YdkAMluFbwx]
def a4ms6ISnL5(Y6YdkAMluFbwx):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡇࡆࡖࠪࢿ"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭ࣀ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if DTF3Lwy9etRH8mI(u"ࠨ࠰࡭ࡷࡴࡴࠧࣁ") in Y6YdkAMluFbwx: url = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩࣂ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else: url = oo9kuULlebNgpY0Om.findall(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣃ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not url: return iqHhJSxdaANDG5rlZm7B(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬࣄ"),[],[]
	url = url[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬ࡮ࡴࡵࡲࠪࣅ") not in url: url = iAGgjwb7tVMmacRJ(u"࠭ࡨࡵࡶࡳ࠾ࠬࣆ")+url
	return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
def M5B94WgJfbkAxhIX3nqCwcE(url):
	headers = { RVpeGcmPxj9tCnT40Nf216(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ") : G9G0YqivIfmUWO8K }
	if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫࣈ") in url:
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠲ࡵࡷࠫࣉ"))
		items = oo9kuULlebNgpY0Om.findall(UighHKAfySm4PWErqJ(u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࣊"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if items: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[items[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
		else:
			JPhoBimWUM0Gu2H1Fe9fRv8 = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࣋"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if JPhoBimWUM0Gu2H1Fe9fRv8:
				hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ࣌"),JPhoBimWUM0Gu2H1Fe9fRv8[dQ5JhEYolPmy1fvHktMw6NFRxiz])
				return vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ࣍")+JPhoBimWUM0Gu2H1Fe9fRv8[dQ5JhEYolPmy1fvHktMw6NFRxiz],[],[]
	else:
		mpniyIdLxTPW3BN8UcY2v = iAGgjwb7tVMmacRJ(u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ࣎")
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦ࣏ࠪ"))
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹ࣐ࠫ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: return FWqeEzO1i8Dn0ga(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇ࣑ࠧ"),[],[]
		z7GYBmKiXwreV2QybCNn80v9pT = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz]
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]
		if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫ࠳ࡸࡡࡳ࣒ࠩ") in BN1KdkzCmvshw or cjbAkCIinvs(u"ࠬ࠴ࡺࡪࡲ࣓ࠪ") in BN1KdkzCmvshw: return RVpeGcmPxj9tCnT40Nf216(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫࣔ"),[],[]
		items = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣕ"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {}
		for YwC7jt5BQHhTUvbdGeM6f2ZLx,yW70dtahIjkPCJg2TA in items:
			QKsd6VmaOnMPCWuqcTyl28JZH7ASjo[YwC7jt5BQHhTUvbdGeM6f2ZLx] = yW70dtahIjkPCJg2TA
		data = tAPSK0wDYQhczOgZ(QKsd6VmaOnMPCWuqcTyl28JZH7ASjo)
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,z7GYBmKiXwreV2QybCNn80v9pT,data,headers,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪࣖ"))
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧࣗ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: return FWqeEzO1i8Dn0ga(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧࣘ"),[],[]
		download = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz]
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]
		items = oo9kuULlebNgpY0Om.findall(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫࣙ"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		R4RX2OvJ5pnt,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,RJeLopO9taYQqD85MIj1dHX7Tv6s,ODnaR0N8UHv7Twy6jS,AAkX679TftDbj = [],[],[],[],[]
		for Y6YdkAMluFbwx,title in items:
			if jR9YtmsgDX8nTQlMb6G3(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࣚ") in Y6YdkAMluFbwx:
				R4RX2OvJ5pnt,RJeLopO9taYQqD85MIj1dHX7Tv6s = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,Y6YdkAMluFbwx)
				ODnaR0N8UHv7Twy6jS = ODnaR0N8UHv7Twy6jS + RJeLopO9taYQqD85MIj1dHX7Tv6s
				if R4RX2OvJ5pnt[dQ5JhEYolPmy1fvHktMw6NFRxiz]==VHrIziKUDuNGXkMla(u"࠭࠭࠲ࠩࣛ"): Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(FWqeEzO1i8Dn0ga(u"ࠧࠡีํีๆืࠠฯษุࠤࠬࣜ")+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࡯࠶ࡹ࠽ࠦࠧࣝ")+mpniyIdLxTPW3BN8UcY2v)
				else:
					for title in R4RX2OvJ5pnt:
						Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(FWqeEzO1i8Dn0ga(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧࣞ")+ETNq5t4MYngSsbfFD8J0v(u"ࠪࡱ࠸ࡻ࠸ࠡࠩࣟ")+mpniyIdLxTPW3BN8UcY2v+ww0sZkBU9JKd+title)
			else:
				title = title.replace(t2sCrJ0xbgDRkf(u"ࠫ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠭࣠"),G9G0YqivIfmUWO8K)
				title = title.strip(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࠨࠧ࣡"))
				title = ETNq5t4MYngSsbfFD8J0v(u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ࣢")+ETNq5t4MYngSsbfFD8J0v(u"ࠧࠡ࡯ࡳ࠸ࣣࠥ࠭")+mpniyIdLxTPW3BN8UcY2v+ww0sZkBU9JKd+title
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		Y6YdkAMluFbwx = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧࠪࣤ") + download
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫࣥ"))
		items = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࣦࠢ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for id,Mauf6CrJjP87s,hash,bbo3lEYsnfHcpRAxO in items:
			title = DTF3Lwy9etRH8mI(u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨࣧ")+rr7Xolsp4JwjPK3L(u"ࠬࠦ࡭ࡱ࠶ࠣࠫࣨ")+mpniyIdLxTPW3BN8UcY2v+ww0sZkBU9JKd+bbo3lEYsnfHcpRAxO.split(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡸࠨࣩ"))[fdQOo6Hu4B5Rbg]
			Y6YdkAMluFbwx = rr7Xolsp4JwjPK3L(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ࣪")+id+ssGdubC4mngM9D5SRc3Ye(u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ࣫")+Mauf6CrJjP87s+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ࣬")+hash
			AAkX679TftDbj.append(bbo3lEYsnfHcpRAxO)
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		AAkX679TftDbj = set(AAkX679TftDbj)
		mmkU03zdtDQgvEVwJjSxlM67,QBhaniE1d4lb = [],[]
		for title in Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO:
			Y4mtsbU6i0E2a9DjMIfZv = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨ࣭ࠥ"),title+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࣮ࠫࠫࠬࠧ"),oo9kuULlebNgpY0Om.DOTALL)
			for bbo3lEYsnfHcpRAxO in AAkX679TftDbj:
				if Y4mtsbU6i0E2a9DjMIfZv[dQ5JhEYolPmy1fvHktMw6NFRxiz] in bbo3lEYsnfHcpRAxO:
					title = title.replace(Y4mtsbU6i0E2a9DjMIfZv[dQ5JhEYolPmy1fvHktMw6NFRxiz],bbo3lEYsnfHcpRAxO.split(iqHhJSxdaANDG5rlZm7B(u"ࠬࡾ࣯ࠧ"))[fdQOo6Hu4B5Rbg])
			mmkU03zdtDQgvEVwJjSxlM67.append(title)
		for KT9tdUH3hmiLZCEFz in range(len(ODnaR0N8UHv7Twy6jS)):
			items = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦࣰ࠭࠭ࠫࠬࠢ"),FWqeEzO1i8Dn0ga(u"ࠧࠧࠨࣱࠪ")+mmkU03zdtDQgvEVwJjSxlM67[KT9tdUH3hmiLZCEFz]+ETNq5t4MYngSsbfFD8J0v(u"ࠨࠨࣲࠩࠫ"),oo9kuULlebNgpY0Om.DOTALL)
			QBhaniE1d4lb.append( [mmkU03zdtDQgvEVwJjSxlM67[KT9tdUH3hmiLZCEFz],ODnaR0N8UHv7Twy6jS[KT9tdUH3hmiLZCEFz],items[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz],items[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]] )
		QBhaniE1d4lb = sorted(QBhaniE1d4lb, key=lambda mrHZQgCk7yN: mrHZQgCk7yN[c1R9fnIY4XBDZ], reverse=P5VqbRSzjtO4UE1rZaolG67XA)
		QBhaniE1d4lb = sorted(QBhaniE1d4lb, key=lambda mrHZQgCk7yN: mrHZQgCk7yN[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU], reverse=kkMuQrLWcEayRm)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
		for KT9tdUH3hmiLZCEFz in range(len(QBhaniE1d4lb)):
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(QBhaniE1d4lb[KT9tdUH3hmiLZCEFz][dQ5JhEYolPmy1fvHktMw6NFRxiz])
			ODnaR0N8UHv7Twy6jS.append(QBhaniE1d4lb[KT9tdUH3hmiLZCEFz][fdQOo6Hu4B5Rbg])
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return EHUAyW2lQfe4LXmhgIGc(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭ࣳ"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def ufPUCc8zrwX2Tx7t3vHA0oIK5R1(url):
	mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡃࠬࣴ"))
	XXzvmn7ewM8yBfoxua = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	headers = { dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣵ") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࠸ࡘࡘࡇࡒ࠮࠳ࡶࡸࣶࠬ"))
	items = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡷࡢ࡫ࡷ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧࣷ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	url = items[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࣸ"),[G9G0YqivIfmUWO8K],[url]
def GctvNqFxUXdBuArysba(url):
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	headers = { ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࣹࠬ") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨࣺ"))
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࣻ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	else: return cjbAkCIinvs(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧࣼ"),[],[]
def JNuTRbqGdXcCAUwQ(url):
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	headers = { RVpeGcmPxj9tCnT40Nf216(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࣽ") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬࣾ"))
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪࣿ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	else: return yiaeCEwJjOcWA4ZSd5h(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩऀ"),[],[]
def Nb2MYp7A8v(url):
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,errno = [],[],G9G0YqivIfmUWO8K
	if DTF3Lwy9etRH8mI(u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭ँ") in url:
		XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {t2sCrJ0xbgDRkf(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩं"):EHUAyW2lQfe4LXmhgIGc(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫः")}
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cjbAkCIinvs(u"ࠬࡖࡏࡔࡖࠪऄ"),XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩअ"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		if ssVw9GhqHbuQD5On3YxeKPWFkgjRJt.startswith(t2sCrJ0xbgDRkf(u"ࠧࡩࡶࡷࡴࠬआ")): XXzvmn7ewM8yBfoxua = ssVw9GhqHbuQD5On3YxeKPWFkgjRJt
		else:
			XjWHSnbf6NwhMgpKt4yLY7AkIT = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩइ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if XjWHSnbf6NwhMgpKt4yLY7AkIT:
				XXzvmn7ewM8yBfoxua = XjWHSnbf6NwhMgpKt4yLY7AkIT[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				XjWHSnbf6NwhMgpKt4yLY7AkIT = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩ࡜ࠨࠧࡡࠬई"),XXzvmn7ewM8yBfoxua,oo9kuULlebNgpY0Om.DOTALL)
				if XjWHSnbf6NwhMgpKt4yLY7AkIT:
					XXzvmn7ewM8yBfoxua = aKAyEnjxIlzZtCTv(XjWHSnbf6NwhMgpKt4yLY7AkIT[dQ5JhEYolPmy1fvHktMw6NFRxiz])
					return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	elif EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ࠳ࡱ࡯࡮࡬ࡵ࠲ࠫउ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,RVpeGcmPxj9tCnT40Nf216(u"ࠫࡌࡋࡔࠨऊ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨऋ"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨऌ") in list(D7omduSeM5Gk.headers.keys()): XXzvmn7ewM8yBfoxua = D7omduSeM5Gk.headers[t2sCrJ0xbgDRkf(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩऍ")]
		else: XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬऎ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࠲ࡺ࠴࠭ए") in XXzvmn7ewM8yBfoxua or t2sCrJ0xbgDRkf(u"ࠪ࠳࡫࠵ࠧऐ") in XXzvmn7ewM8yBfoxua:
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠴࡬࠯ࠨऑ"),EHUAyW2lQfe4LXmhgIGc(u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫऒ"))
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭࠯ࡷ࠱ࠪओ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭औ"))
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡒࡒࡗ࡙࠭क"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬख"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		items = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ग"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠫࡡࡢࠧघ"),G9G0YqivIfmUWO8K)
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		else:
			items = oo9kuULlebNgpY0Om.findall(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ङ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if items:
				Y6YdkAMluFbwx = items[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(jR9YtmsgDX8nTQlMb6G3(u"࠭࡜࡝ࠩच"),G9G0YqivIfmUWO8K)
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G9G0YqivIfmUWO8K)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	else: return FWqeEzO1i8Dn0ga(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪछ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return FWqeEzO1i8Dn0ga(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ज"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def cYuti2ydov(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,jR9YtmsgDX8nTQlMb6G3(u"ࠩࡊࡉ࡙࠭झ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪञ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,errno = [],[],G9G0YqivIfmUWO8K
	if cjbAkCIinvs(u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧट") in url or ssGdubC4mngM9D5SRc3Ye(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ठ") in url:
		if EHUAyW2lQfe4LXmhgIGc(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩड") in url:
			XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬढ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else: XXzvmn7ewM8yBfoxua = url
		if iqHhJSxdaANDG5rlZm7B(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨण") not in XXzvmn7ewM8yBfoxua: return iAGgjwb7tVMmacRJ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬत"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡋࡊ࡚ࠧथ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠳ࡰࡧࠫद"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩࡷ࡫ࡧࡩࡴࡰࡳࠨध"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		items = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧन"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,G6XbgFWwaiq in items:
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G6XbgFWwaiq)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࡮ࡣ࡬ࡲࡤࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩऩ") in url:
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(rxWDdRBIct57i90s(u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬप"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,DTF3Lwy9etRH8mI(u"ࠩࡊࡉ࡙࠭फ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠳ࡳࡦࠪब"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		XjWHSnbf6NwhMgpKt4yLY7AkIT = oo9kuULlebNgpY0Om.findall(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭भ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		XjWHSnbf6NwhMgpKt4yLY7AkIT = XjWHSnbf6NwhMgpKt4yLY7AkIT[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G9G0YqivIfmUWO8K)
		ODnaR0N8UHv7Twy6jS.append(XjWHSnbf6NwhMgpKt4yLY7AkIT)
	elif yiaeCEwJjOcWA4ZSd5h(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬम") in url:
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩय"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if XXzvmn7ewM8yBfoxua:
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			return wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪर"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return ETNq5t4MYngSsbfFD8J0v(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪऱ"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def bJWPe8tmuq(url):
	if hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡂ࡫ࡪࡺ࠽ࠨल") in url:
		Y6YdkAMluFbwx = url.split(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡃ࡬࡫ࡴ࠾ࠩळ"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
		Y6YdkAMluFbwx = jaFsD83SB9ZQkrxeI.b64decode(Y6YdkAMluFbwx)
		if LTze51miOknVcslNF43WSA6vMjYZt: Y6YdkAMluFbwx = Y6YdkAMluFbwx.decode(f3uIcZ2C6pzbX1JlFBrVOdt,DTF3Lwy9etRH8mI(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫऴ"))
		return dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨव"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	website = Kkfl8xemuHbd1w3a0ABPcDrN[jR9YtmsgDX8nTQlMb6G3(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨश")][dQ5JhEYolPmy1fvHktMw6NFRxiz]
	headers = {iqHhJSxdaANDG5rlZm7B(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨष"):website}
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,jR9YtmsgDX8nTQlMb6G3(u"ࠨࡉࡈࡘࠬस"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭࠳ࡰࡧࠫह"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,dC3PsQJ0Ti28uYlov(u"ࠪࡹࡷࡲࠧऺ"))
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(rxWDdRBIct57i90s(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऻ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(VHrIziKUDuNGXkMla(u"ࠧࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠪࠬ࠳࠰࠿़ࠪࠩࠥ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠨࡦࡪ࡮ࡨ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧऽ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]+DTF3Lwy9etRH8mI(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪा")+website
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	if t2sCrJ0xbgDRkf(u"ࠨࡰࡤࡱࡪࡃ࡙ࠢࡶࡲ࡯ࡪࡴࠢࠨि") in GagwMT6q3oc7UZ2Q:
		aaWswjhBfNbEIAeVc = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡱࡥࡲ࡫࠽࡚ࠣࡷࡳࡰ࡫࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫी"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if aaWswjhBfNbEIAeVc:
			Y6YdkAMluFbwx = aaWswjhBfNbEIAeVc[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			Y6YdkAMluFbwx = jaFsD83SB9ZQkrxeI.b64decode(Y6YdkAMluFbwx)
			if LTze51miOknVcslNF43WSA6vMjYZt: Y6YdkAMluFbwx = Y6YdkAMluFbwx.decode(f3uIcZ2C6pzbX1JlFBrVOdt,rxWDdRBIct57i90s(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪु"))
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"ࠫ࡭ࡺࡴࡱ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠬࠨू"),Y6YdkAMluFbwx,oo9kuULlebNgpY0Om.DOTALL)
			if Y6YdkAMluFbwx:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]+iAGgjwb7tVMmacRJ(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨृ")+website
				return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩॄ"),[G9G0YqivIfmUWO8K],[url]
def oJCMRaUesk(url,pM0RwoYjfsUVZcqt6uTOiFkhEXCS):
	GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = [],[]
	if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧ࠰࠳࠲ࠫॅ") in url:
		Y6YdkAMluFbwx = url.replace(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨ࠱࠴࠳ࠬॆ"),UighHKAfySm4PWErqJ(u"ࠩ࠲࠸࠴࠭े"))
		D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡋࡊ࡚ࠧै"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭ॉ"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫॊ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			items = oo9kuULlebNgpY0Om.findall(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬो"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in items:
				if Y6YdkAMluFbwx not in ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
					yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡯ࡣࡰࡩࠬौ"))
					GGoLgj5BFbWI.append(yVgLqfcUN1iO4+zVnkcBX6aJDPRpqyCjhoSZYQbL+I5chimw4D1okfxlBE2UpbuHJvStsZ)
			return G9G0YqivIfmUWO8K,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh
	elif yiaeCEwJjOcWA4ZSd5h(u"ࠨ࠱ࡧ࠳्ࠬ") in url:
		D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡊࡉ࡙࠭ॎ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠴ࡱࡨࠬॏ"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॐ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬ࠵࠱࠰ࠩ॑"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭࠯࠵࠱॒ࠪ"))
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,VHrIziKUDuNGXkMla(u"ࠧࡈࡇࡗࠫ॓"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪ॔"))
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩॕ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if Y6YdkAMluFbwx: return ETNq5t4MYngSsbfFD8J0v(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ॖ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࠴ࡸ࡯࡭ࡧ࠲ࠫॗ") in url:
		headers = {RVpeGcmPxj9tCnT40Nf216(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭क़"):pM0RwoYjfsUVZcqt6uTOiFkhEXCS}
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡇࡆࡖࠪख़"),url,G9G0YqivIfmUWO8K,headers,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠺ࡴࡩࠩग़"))
		Y6YdkAMluFbwx = D7omduSeM5Gk.headers[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪज़")]
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡊࡉ࡙࠭ड़"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠷ࡷ࡬ࠬढ़"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = BBkCNjPeRKa149q6pUOyz75E(Y6YdkAMluFbwx,GagwMT6q3oc7UZ2Q)
		return lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh
	elif dC3PsQJ0Ti28uYlov(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨफ़") in url:
		XXzvmn7ewM8yBfoxua = url.replace(iqHhJSxdaANDG5rlZm7B(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩय़"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࠯ࡴࡥࡵ࡭ࡵࡺ࠯ࠨॠ"))
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨॡ"):pM0RwoYjfsUVZcqt6uTOiFkhEXCS}
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,UighHKAfySm4PWErqJ(u"ࠨࡉࡈࡘࠬॢ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠷ࡶ࡫ࠫॣ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ।"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡌࡋࡔࠨ॥"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠻ࡹ࡮ࠧ०"))
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
			if EHUAyW2lQfe4LXmhgIGc(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ१") in list(D7omduSeM5Gk.headers.keys()):
				Y6YdkAMluFbwx = D7omduSeM5Gk.headers[EHUAyW2lQfe4LXmhgIGc(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ२")]
				D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cJSNFCIhymEfx6grGu0M(u"ࠨࡉࡈࡘࠬ३"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠹ࡶ࡫ࠫ४"))
				GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
				lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = BBkCNjPeRKa149q6pUOyz75E(Y6YdkAMluFbwx,GagwMT6q3oc7UZ2Q)
				if ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh: return lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh
			elif RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ५") in Y6YdkAMluFbwx:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(yiaeCEwJjOcWA4ZSd5h(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ६"),FWqeEzO1i8Dn0ga(u"ࠬ࠵ࡪࡸࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ७"))
				return VHrIziKUDuNGXkMla(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ८"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	else: return UighHKAfySm4PWErqJ(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ९"),[G9G0YqivIfmUWO8K],[url]
	return qTVF3icWwGXy5(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ॰"),[],[]
def NE6q2giP1A(url):
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡊࡉ࡙࠭ॱ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠳ࡶࡸࠬॲ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	data = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠧࡧࡣࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॳ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if data:
		IIWxSehdBcAHkEjX,id,zedfm3vjApVh5oXSDOxZaHT7nYLIy = data[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		data = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡵࡰ࠾ࠩॴ")+IIWxSehdBcAHkEjX+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࠦࡪࡦࡀࠫॵ")+id+DTF3Lwy9etRH8mI(u"ࠧࠧࡨࡱࡥࡲ࡫࠽ࠨॶ")+zedfm3vjApVh5oXSDOxZaHT7nYLIy
		headers = {hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧॷ"):bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨॸ")}
		D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡔࡔ࡙ࡔࠨॹ"),url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠵ࡲࡩ࠭ॺ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࠨࡲࡦࡨࡨࡶࡪࡸࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॻ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx: return RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩॼ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
	return hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫॽ"),[],[]
def pg8n1POVBx(url):
	headers = {ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫॾ"):ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪॿ")}
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,jR9YtmsgDX8nTQlMb6G3(u"ࠪࡋࡊ࡚ࠧঀ"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯࠴ࡷࡹ࠭ঁ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪং"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K)
		return CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩঃ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return dC3PsQJ0Ti28uYlov(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ঄"),[],[]
def SDoMIkl0yf(url):
	XXzvmn7ewM8yBfoxua = url.split(ssGdubC4mngM9D5SRc3Ye(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩঅ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz].strip(bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡂࠫআ")).strip(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪ࠳ࠬই")).strip(iAGgjwb7tVMmacRJ(u"ࠫࠫ࠭ঈ"))
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,items,XjWHSnbf6NwhMgpKt4yLY7AkIT = [],[],[],G9G0YqivIfmUWO8K
	headers = { wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩউ"):dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮࠭ঊ") }
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡈࡇࡗࠫঋ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩঌ"))
	if UighHKAfySm4PWErqJ(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ঍") in list(D7omduSeM5Gk.headers.keys()): XjWHSnbf6NwhMgpKt4yLY7AkIT = D7omduSeM5Gk.headers[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ঎")]
	if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࡭ࡺࡴࡱࠩএ") in XjWHSnbf6NwhMgpKt4yLY7AkIT:
		if DTF3Lwy9etRH8mI(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ঐ") in url: XjWHSnbf6NwhMgpKt4yLY7AkIT = XjWHSnbf6NwhMgpKt4yLY7AkIT.replace(t2sCrJ0xbgDRkf(u"࠭࠯ࡧ࠱ࠪ঑"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧ࠰ࡸ࠲ࠫ঒"))
		LHSOCZNo6JAnmt = XXzvmn7ewM8yBfoxua.split(UighHKAfySm4PWErqJ(u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪও"))[fdQOo6Hu4B5Rbg]
		headers = { iqHhJSxdaANDG5rlZm7B(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ঔ"):headers[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧক")] , Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫখ"):yiaeCEwJjOcWA4ZSd5h(u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭গ")+LHSOCZNo6JAnmt }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,rxWDdRBIct57i90s(u"࠭ࡇࡆࡖࠪঘ"),XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,headers,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪঙ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨ࠱ࡩ࠳ࠬচ") in XjWHSnbf6NwhMgpKt4yLY7AkIT: items = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠩ࠿࡬࠷ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨছ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		elif ssGdubC4mngM9D5SRc3Ye(u"ࠪ࠳ࡻ࠵ࠧজ") in XjWHSnbf6NwhMgpKt4yLY7AkIT: items = oo9kuULlebNgpY0Om.findall(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࡮ࡪ࠽ࠣࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨঝ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if items: return [],[G9G0YqivIfmUWO8K],[ items[dQ5JhEYolPmy1fvHktMw6NFRxiz] ]
		elif DTF3Lwy9etRH8mI(u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫঞ") in GagwMT6q3oc7UZ2Q:
			return iAGgjwb7tVMmacRJ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩট"),[],[]
	else: return cJSNFCIhymEfx6grGu0M(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪঠ"),[],[]
def tjyIDp0NTr(Y6YdkAMluFbwx):
	mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪড"),Y6YdkAMluFbwx+dC3PsQJ0Ti28uYlov(u"ࠩࠩࠪࠬঢ"),oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	HGD02clisfMEkyYwX5PRebUnAu,GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0 = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	url = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫণ")+HGD02clisfMEkyYwX5PRebUnAu+jR9YtmsgDX8nTQlMb6G3(u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨত")+GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0
	headers = { dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩথ"):G9G0YqivIfmUWO8K , UighHKAfySm4PWErqJ(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩদ"):rr7Xolsp4JwjPK3L(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨধ") }
	XXzvmn7ewM8yBfoxua = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰࠵ࡸࡺࠧন"))
	return FWqeEzO1i8Dn0ga(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ঩"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
def AD62PQ4gWj(url):
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡹࡷࡲࠧপ"))
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {ETNq5t4MYngSsbfFD8J0v(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬফ"):yVgLqfcUN1iO4,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧব"):qTVF3icWwGXy5(u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭ভ")}
	D7omduSeM5Gk = PPRoOyl2xVH(PvAZ1fCRqL5F,rr7Xolsp4JwjPK3L(u"ࠧࡈࡇࡗࠫম"),url,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨয"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪর"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	XXzvmn7ewM8yBfoxua = G9G0YqivIfmUWO8K
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		items = oo9kuULlebNgpY0Om.findall(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ঱"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
		for title,Y6YdkAMluFbwx in items:
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		if len(ODnaR0N8UHv7Twy6jS)==fdQOo6Hu4B5Rbg: XXzvmn7ewM8yBfoxua = ODnaR0N8UHv7Twy6jS[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		elif len(ODnaR0N8UHv7Twy6jS)>fdQOo6Hu4B5Rbg:
			PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(iqHhJSxdaANDG5rlZm7B(u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩল"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return DTF3Lwy9etRH8mI(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ঳"),[],[]
			XXzvmn7ewM8yBfoxua = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ঴"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: XXzvmn7ewM8yBfoxua = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if not XXzvmn7ewM8yBfoxua: return hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡈࡏࡍࡂࠩ঵"),[],[]
	return ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫশ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
def dDs7jmXNAFHu1tBxSYqRZnflP4y8Mg(url):
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡸࡶࡱ࠭ষ"))
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = {iAGgjwb7tVMmacRJ(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫস"):yVgLqfcUN1iO4,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭হ"):rxWDdRBIct57i90s(u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ঺")}
	D7omduSeM5Gk = PPRoOyl2xVH(PvAZ1fCRqL5F,cJSNFCIhymEfx6grGu0M(u"࠭ࡇࡆࡖࠪ঻"),url,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺ়ࠧ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩঽ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	XXzvmn7ewM8yBfoxua = G9G0YqivIfmUWO8K
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		items = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨা"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
		for title,Y6YdkAMluFbwx in items:
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		if len(ODnaR0N8UHv7Twy6jS)==fdQOo6Hu4B5Rbg: XXzvmn7ewM8yBfoxua = ODnaR0N8UHv7Twy6jS[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		elif len(ODnaR0N8UHv7Twy6jS)>fdQOo6Hu4B5Rbg:
			PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨি"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩী"),[],[]
			XXzvmn7ewM8yBfoxua = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	if not XXzvmn7ewM8yBfoxua:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪু"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: XXzvmn7ewM8yBfoxua = cSLKDEATk7y10ovtGZCwF[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if not XXzvmn7ewM8yBfoxua: return FWqeEzO1i8Dn0ga(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡈࡇࡎࡓࡁࠨূ"),[],[]
	return wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪৃ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
def Pq0s8YmBrW(Y6YdkAMluFbwx):
	mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧৄ"),Y6YdkAMluFbwx+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࠩࠪࠬ৅"),oo9kuULlebNgpY0Om.DOTALL)
	url,HGD02clisfMEkyYwX5PRebUnAu,GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0 = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	data = {qTVF3icWwGXy5(u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫ৆"):HGD02clisfMEkyYwX5PRebUnAu,EHUAyW2lQfe4LXmhgIGc(u"ࠫࡸ࡫ࡲࡷࡧࡵࠫে"):GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0}
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡖࡏࡔࡖࠪৈ"),url,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ৉"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ৊"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return cjbAkCIinvs(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫো"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
def G5oJd6lKs2(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,t2sCrJ0xbgDRkf(u"ࠩࡊࡉ࡙࠭ৌ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯࠴ࡷࡹ্࠭"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬৎ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if Y6YdkAMluFbwx: return rxWDdRBIct57i90s(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ৏"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return iqHhJSxdaANDG5rlZm7B(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ৐"),[],[]
def XTjciq7QDv(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡈࡇࡗࠫ৑"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳࠱ࡴࡶࠪ৒"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࠿ࡍࡋࡘࡁࡎࡇࠣࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৓"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return iqHhJSxdaANDG5rlZm7B(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭৔"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def ROz51TArF8(url):
	LV6wHuJn8BiWZeyRkcI3sdXU = xWiOjcUrJVdtP4B5Iml(url,DTF3Lwy9etRH8mI(u"ࠫࡺࡸ࡬ࠨ৕"))
	if UighHKAfySm4PWErqJ(u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ৖") in url:
		headers = {hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧৗ"):LV6wHuJn8BiWZeyRkcI3sdXU}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡈࡇࡗࠫ৘"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ৙"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(FWqeEzO1i8Dn0ga(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৚"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if XXzvmn7ewM8yBfoxua:
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			if cJSNFCIhymEfx6grGu0M(u"ࠪ࡬ࡹࡺࡰࠨ৛") not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࡭ࡺࡴࡱ࠼ࠪড়")+XXzvmn7ewM8yBfoxua
			if yiaeCEwJjOcWA4ZSd5h(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭ঢ়") in XXzvmn7ewM8yBfoxua:
				XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace(qTVF3icWwGXy5(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ৞"),iAGgjwb7tVMmacRJ(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨয়"))
				D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,iqHhJSxdaANDG5rlZm7B(u"ࠨࡉࡈࡘࠬৠ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪৡ"))
				ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
				items = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩৢ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
				NPlUQFruOmeD = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,iAGgjwb7tVMmacRJ(u"ࠫࡺࡸ࡬ࠨৣ"))
				for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in reversed(items):
					Y6YdkAMluFbwx = NPlUQFruOmeD+Y6YdkAMluFbwx+DTF3Lwy9etRH8mI(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ৤")+NPlUQFruOmeD
					Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
				return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
			else: return EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৥"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	XXzvmn7ewM8yBfoxua = url+EHUAyW2lQfe4LXmhgIGc(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ০")+LV6wHuJn8BiWZeyRkcI3sdXU
	if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡪࡷࡸࡵ࠭১") not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = rxWDdRBIct57i90s(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ২")+XXzvmn7ewM8yBfoxua
	return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
def AP1RZ36OdolKbFxDeBtjC98hkMy(Y6YdkAMluFbwx):
	LV6wHuJn8BiWZeyRkcI3sdXU = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,qTVF3icWwGXy5(u"ࠪࡹࡷࡲࠧ৩"))
	if FWqeEzO1i8Dn0ga(u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ৪") in Y6YdkAMluFbwx:
		mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ৫"),Y6YdkAMluFbwx+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࠦࠧࠩ৬"),oo9kuULlebNgpY0Om.DOTALL)
		url,HGD02clisfMEkyYwX5PRebUnAu,GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0 = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		data = {wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡪࡦࠪ৭"):HGD02clisfMEkyYwX5PRebUnAu,FWqeEzO1i8Dn0ga(u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ৮"):GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡓࡓࡘ࡚ࠧ৯"),url,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫৰ"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩৱ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭৲") in XXzvmn7ewM8yBfoxua:
			headers = {RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ৳"):LV6wHuJn8BiWZeyRkcI3sdXU,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ৴"):G9G0YqivIfmUWO8K}
			D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡉࡈࡘࠬ৵"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ৶"))
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
			items = oo9kuULlebNgpY0Om.findall(rxWDdRBIct57i90s(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৷"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
			NPlUQFruOmeD = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,UighHKAfySm4PWErqJ(u"ࠫࡺࡸ࡬ࠨ৸"))
			for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in reversed(items):
				Y6YdkAMluFbwx = NPlUQFruOmeD+Y6YdkAMluFbwx+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ৹")+NPlUQFruOmeD
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
			return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
		else: return rxWDdRBIct57i90s(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৺"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	else:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx+t2sCrJ0xbgDRkf(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ৻")+LV6wHuJn8BiWZeyRkcI3sdXU
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
def VN1wd39pve(Y6YdkAMluFbwx):
	if cjbAkCIinvs(u"ࠨࡲࡲࡷࡹ࡯ࡤࠨৼ") in Y6YdkAMluFbwx:
		mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ৽"),Y6YdkAMluFbwx+UighHKAfySm4PWErqJ(u"ࠪࠪࠫ࠭৾"),oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		HGD02clisfMEkyYwX5PRebUnAu,GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0 = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		nihPHREgaW15oqdvpxr2O6XYtc = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,cJSNFCIhymEfx6grGu0M(u"ࠫࡺࡸ࡬ࠨ৿"))
		url = nihPHREgaW15oqdvpxr2O6XYtc+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ਀")+HGD02clisfMEkyYwX5PRebUnAu+UighHKAfySm4PWErqJ(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪਁ")+GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0
		headers = { wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫਂ"):G9G0YqivIfmUWO8K , Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫਃ"):iAGgjwb7tVMmacRJ(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ਄") }
		XXzvmn7ewM8yBfoxua = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬਅ"))
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
		return t2sCrJ0xbgDRkf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਆ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	elif rr7Xolsp4JwjPK3L(u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩਇ") in Y6YdkAMluFbwx:
		aPJqUThKiZd = dQ5JhEYolPmy1fvHktMw6NFRxiz
		while bneABYmwFUH8GXphg0Kl2Sq(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪਈ") in Y6YdkAMluFbwx and aPJqUThKiZd<GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠷ෑ"):
			D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,jR9YtmsgDX8nTQlMb6G3(u"ࠧࡈࡇࡗࠫਉ"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪਊ"))
			if t2sCrJ0xbgDRkf(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ਋") in list(D7omduSeM5Gk.headers.keys()): Y6YdkAMluFbwx = D7omduSeM5Gk.headers[VHrIziKUDuNGXkMla(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ਌")]
			aPJqUThKiZd += fdQOo6Hu4B5Rbg
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	else: return RVpeGcmPxj9tCnT40Nf216(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ਍"),[],[]
def ghAocGITQE(url):
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡻࡲ࡭ࠩ਎"))
	headers = {RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਏ"):yVgLqfcUN1iO4,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫਐ"):uCUkPIYFszbV90wSpKqWNOjZ1687Eh()}
	if cjbAkCIinvs(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ਑") in url:
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫ਒"))
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਓ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(dC3PsQJ0Ti28uYlov(u"ࠫ࡭ࡺࡴࡱࡵࠪਔ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬ࡮ࡴࡵࡲࠪਕ"))
			return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	else:
		DD5nqN71sKPTIOEFRuokWZjQv0 = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,t2sCrJ0xbgDRkf(u"࠭ࡇࡆࡖࠪਖ"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩਗ"))
		GagwMT6q3oc7UZ2Q = DD5nqN71sKPTIOEFRuokWZjQv0.content
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = headers.copy()
		if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡡ࡯ࡲࡰࡥࠧਘ") in str(DD5nqN71sKPTIOEFRuokWZjQv0.cookies):
			cookies = DD5nqN71sKPTIOEFRuokWZjQv0.cookies
			AAFEPhnMlsH5B3z0gYQWD4j7kUc[dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡆࡳࡴࡱࡩࡦࠩਙ")] = aKAyEnjxIlzZtCTv(tAPSK0wDYQhczOgZ(cookies))
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(FWqeEzO1i8Dn0ga(u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ਚ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not Y6YdkAMluFbwx: return t2sCrJ0xbgDRkf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਛ"),[G9G0YqivIfmUWO8K],[url]
		else:
			Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz])+bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࠬࡤ࠾࠳ࠪਜ")
			WvxUIHz0cMJB = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡇࡆࡖࠪਝ"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩਞ"))
			GagwMT6q3oc7UZ2Q = WvxUIHz0cMJB.content
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਟ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if Y6YdkAMluFbwx:
				Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz])
				if cJSNFCIhymEfx6grGu0M(u"ࠩࡰࡴ࠹࠭ਠ") in Y6YdkAMluFbwx and EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ࠳ࡩ࠵ࠧਡ") in Y6YdkAMluFbwx: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
				else: return RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧਢ"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return t2sCrJ0xbgDRkf(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡘࡋࡅࡅࠩਣ"),[],[]
def CCOzBEyRvg(Y6YdkAMluFbwx):
	if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠪਤ") in Y6YdkAMluFbwx:
		headers = {jR9YtmsgDX8nTQlMb6G3(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪਥ"):hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩਦ")}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡊࡉ࡙࠭ਧ"),Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠳ࡶࡸࠬਨ"))
		url = D7omduSeM5Gk.content
		if url: return yiaeCEwJjOcWA4ZSd5h(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ਩"),[G9G0YqivIfmUWO8K],[url]
	else:
		mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ਪ"),Y6YdkAMluFbwx,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if not mtMexSFLnkwhbAaP9pgDduCRBi2: mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩਫ"),Y6YdkAMluFbwx,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		HGD02clisfMEkyYwX5PRebUnAu,GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0 = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,qTVF3icWwGXy5(u"ࠧࡶࡴ࡯ࠫਬ"))
		url = yVgLqfcUN1iO4+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡴࡩࡧࡰࡩ࠴ࡇࡪࡢࡺࡤࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩਭ")
		data = {hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡬ࡨࠬਮ"):HGD02clisfMEkyYwX5PRebUnAu,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࡭ࠬਯ"):GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0}
		headers = {ssGdubC4mngM9D5SRc3Ye(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧਰ"):hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭਱"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧਲ"):Y6YdkAMluFbwx}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,rr7Xolsp4JwjPK3L(u"ࠧࡑࡑࡖࡘࠬਲ਼"),url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪ਴"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਵ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if XXzvmn7ewM8yBfoxua:
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			return hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ਸ਼"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	return yiaeCEwJjOcWA4ZSd5h(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ਷"),[],[]
def jGa2SYHmhpOFq0UMboR(dQ4oKjz1Lle7HtG8m3DqR):
	US8CaDFXHtjx7MTmzwePd2nEL0sy5 = amx9qJHkhw7oLdtVMG3.getSetting(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡧࡶ࠯ࡣ࡮ࡻࡦࡳ࠮ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ਸ"))
	headers = {DTF3Lwy9etRH8mI(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ਹ"):US8CaDFXHtjx7MTmzwePd2nEL0sy5} if US8CaDFXHtjx7MTmzwePd2nEL0sy5 else G9G0YqivIfmUWO8K
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,dC3PsQJ0Ti28uYlov(u"ࠧࡈࡇࡗࠫ਺"),dQ4oKjz1Lle7HtG8m3DqR,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨ਻"))
	bn42I6TyC9ZgiY = D7omduSeM5Gk.content
	Rbi5w7F1dVuAl4UsG = str(D7omduSeM5Gk.headers)
	E5pMzFT7lyXjC8IOQN0Ubc2dGfomv = Rbi5w7F1dVuAl4UsG+bn42I6TyC9ZgiY
	if qTVF3icWwGXy5(u"ࠩ࠱ࡱࡵ࠺਼ࠧ") in E5pMzFT7lyXjC8IOQN0Ubc2dGfomv: a2brFZlqWO8hK1UfAmLVz = P5VqbRSzjtO4UE1rZaolG67XA
	else:
		mXDWkJMI4zgU5w6e0n9,jJ1iOyvCtQxbFeK,rrufohaGUd1ynRSjqVJwbW9zekM,LRebTraNEgnW1lcmKjkFuw4i,a2brFZlqWO8hK1UfAmLVz = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm
		captcha = oo9kuULlebNgpY0Om.findall(qTVF3icWwGXy5(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਽"),bn42I6TyC9ZgiY,oo9kuULlebNgpY0Om.DOTALL)
		if captcha: rrufohaGUd1ynRSjqVJwbW9zekM,LRebTraNEgnW1lcmKjkFuw4i = captcha[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		CYP5zWsJqDpx4jcvESXBTGw = Kkfl8xemuHbd1w3a0ABPcDrN[bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫਾ")][Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠺ි")]
		if dQ5JhEYolPmy1fvHktMw6NFRxiz:
			data = {yiaeCEwJjOcWA4ZSd5h(u"ࠬࡻࡳࡦࡴࠪਿ"):iOtjqZ6Iydl,iAGgjwb7tVMmacRJ(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧੀ"):GBx0Fcf7sLbqlntEX3yMezu,cjbAkCIinvs(u"ࠧࡶࡴ࡯ࠫੁ"):dQ4oKjz1Lle7HtG8m3DqR,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨ࡭ࡨࡽࠬੂ"):LRebTraNEgnW1lcmKjkFuw4i,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡬ࡨࠬ੃"):G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࡮ࡴࡨࠧ੄"):rr7Xolsp4JwjPK3L(u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬ੅")}
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,rr7Xolsp4JwjPK3L(u"ࠬࡖࡏࡔࡖࠪ੆"),CYP5zWsJqDpx4jcvESXBTGw,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠵ࡲࡩ࠭ੇ"))
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		GagwMT6q3oc7UZ2Q = G9G0YqivIfmUWO8K
		if GagwMT6q3oc7UZ2Q.startswith(qTVF3icWwGXy5(u"ࠧࡖࡔࡏࡗࡂ࠭ੈ")):
			pUrSPMLW53w1cYRD08fHzodEZ = bRCSwcA89e4J7pqdays5PxGiD2(dC3PsQJ0Ti28uYlov(u"ࠨ࡮࡬ࡷࡹ࠭੉"),GagwMT6q3oc7UZ2Q.split(FWqeEzO1i8Dn0ga(u"ࠩࡘࡖࡑ࡙࠽ࠨ੊"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg])
			for A0AzrLupg8h1s in pUrSPMLW53w1cYRD08fHzodEZ:
				url = A0AzrLupg8h1s[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡹࡷࡲࠧੋ")]
				H6hoDfAm89WLMiKkP7dpRYXF2qeQGJ = A0AzrLupg8h1s[jR9YtmsgDX8nTQlMb6G3(u"ࠫࡲ࡫ࡴࡩࡱࡧࠫੌ")]
				data = A0AzrLupg8h1s[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡪࡡࡵࡣ੍ࠪ")]
				headers = A0AzrLupg8h1s[rxWDdRBIct57i90s(u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧ੎")]
				D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,H6hoDfAm89WLMiKkP7dpRYXF2qeQGJ,url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ੏"))
				bn42I6TyC9ZgiY = D7omduSeM5Gk.content
				if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࠰ࡰࡴ࠹࠭੐") in bn42I6TyC9ZgiY:
					a2brFZlqWO8hK1UfAmLVz = P5VqbRSzjtO4UE1rZaolG67XA
					break
				Rbi5w7F1dVuAl4UsG = str(D7omduSeM5Gk.headers)
				E5pMzFT7lyXjC8IOQN0Ubc2dGfomv = Rbi5w7F1dVuAl4UsG+bn42I6TyC9ZgiY
				mXDWkJMI4zgU5w6e0n9 = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪੑ"),E5pMzFT7lyXjC8IOQN0Ubc2dGfomv,oo9kuULlebNgpY0Om.DOTALL)
				jJ1iOyvCtQxbFeK = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ੒"),E5pMzFT7lyXjC8IOQN0Ubc2dGfomv,oo9kuULlebNgpY0Om.DOTALL)
				if jJ1iOyvCtQxbFeK: jJ1iOyvCtQxbFeK = jJ1iOyvCtQxbFeK[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				if mXDWkJMI4zgU5w6e0n9 or jJ1iOyvCtQxbFeK: break
		if not a2brFZlqWO8hK1UfAmLVz:
			if not mXDWkJMI4zgU5w6e0n9:
				if captcha and not jJ1iOyvCtQxbFeK:
					if fdQOo6Hu4B5Rbg: jJ1iOyvCtQxbFeK = eP4Y3d7zXWc5nka0ExbliNZf(LRebTraNEgnW1lcmKjkFuw4i,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡦࡸࠧ੓"),dQ4oKjz1Lle7HtG8m3DqR)
					else:
						if not GagwMT6q3oc7UZ2Q.startswith(EHUAyW2lQfe4LXmhgIGc(u"ࠬࡏࡄ࠾ࠩ੔")):
							data = {EHUAyW2lQfe4LXmhgIGc(u"࠭ࡵࡴࡧࡵࠫ੕"):iOtjqZ6Iydl,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ੖"):GBx0Fcf7sLbqlntEX3yMezu,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡷࡵࡰࠬ੗"):dQ4oKjz1Lle7HtG8m3DqR,rxWDdRBIct57i90s(u"ࠩ࡮ࡩࡾ࠭੘"):LRebTraNEgnW1lcmKjkFuw4i,qTVF3icWwGXy5(u"ࠪ࡭ࡩ࠭ਖ਼"):G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠫ࡯ࡵࡢࠨਗ਼"):GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡭ࡥࡵ࡫ࡧࠫਜ਼")}
							D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,ETNq5t4MYngSsbfFD8J0v(u"࠭ࡐࡐࡕࡗࠫੜ"),CYP5zWsJqDpx4jcvESXBTGw,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧ੝"))
							GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
						else: GagwMT6q3oc7UZ2Q = jR9YtmsgDX8nTQlMb6G3(u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩਫ਼")
						if GagwMT6q3oc7UZ2Q.startswith(UighHKAfySm4PWErqJ(u"ࠩࡌࡈࡂ࠭੟")):
							giDI1vZMHfnplERP8s0GUOX9QbV = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩ੠"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
							XKVpjsB2RAS,Hvui6ETwrexpG9zcs5Cl = giDI1vZMHfnplERP8s0GUOX9QbV[dQ5JhEYolPmy1fvHktMw6NFRxiz]
							JPhoBimWUM0Gu2H1Fe9fRv8 = DTF3Lwy9etRH8mI(u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩ੡")+Hvui6ETwrexpG9zcs5Cl+ssGdubC4mngM9D5SRc3Ye(u"ࠬࠦหศ่ํอࠬ੢")
							HofqU5Wsa9 = dWO9bFPCYXVDrcU81xN5kJ23laR()
							HofqU5Wsa9.create(RVpeGcmPxj9tCnT40Nf216(u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ੣"),JPhoBimWUM0Gu2H1Fe9fRv8)
							Au5hSTpyGZoje4Q0BFvEm8agLfkY29 = SSCU3jdyFn2V.time()
							SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR,JH9QFvWNfaejK4d6TsLP08yA5IYODz = dQ5JhEYolPmy1fvHktMw6NFRxiz,dQ5JhEYolPmy1fvHktMw6NFRxiz
							while SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR<int(Hvui6ETwrexpG9zcs5Cl):
								CigEOdTqom6Gw5nta(HofqU5Wsa9,int(SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR/int(Hvui6ETwrexpG9zcs5Cl)*jR9YtmsgDX8nTQlMb6G3(u"࠵࠵࠶ී")),JPhoBimWUM0Gu2H1Fe9fRv8,G9G0YqivIfmUWO8K,Hvui6ETwrexpG9zcs5Cl+rxWDdRBIct57i90s(u"ࠧࠡ࠱ࠣࠫ੤")+str(int(SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR))+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࠢࠣฯฬ์๊สࠩ੥"))
								if SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR>JH9QFvWNfaejK4d6TsLP08yA5IYODz+FWqeEzO1i8Dn0ga(u"࠶࠶ු"):
									data = {bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡸࡷࡪࡸࠧ੦"):iOtjqZ6Iydl,rxWDdRBIct57i90s(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ੧"):GBx0Fcf7sLbqlntEX3yMezu,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡺࡸ࡬ࠨ੨"):dQ4oKjz1Lle7HtG8m3DqR,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡱࡥࡺࠩ੩"):LRebTraNEgnW1lcmKjkFuw4i,vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡩࡥࠩ੪"):XKVpjsB2RAS,DTF3Lwy9etRH8mI(u"ࠧ࡫ࡱࡥࠫ੫"):Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡩࡨࡸࡹࡵ࡫ࡦࡰࠪ੬")}
									D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,EHUAyW2lQfe4LXmhgIGc(u"ࠩࡓࡓࡘ࡚ࠧ੭"),CYP5zWsJqDpx4jcvESXBTGw,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ੮"))
									GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
									if GagwMT6q3oc7UZ2Q.startswith(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࡙ࠫࡕࡋࡆࡐࡀࠫ੯")):
										jJ1iOyvCtQxbFeK = GagwMT6q3oc7UZ2Q.split(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࡚ࠬࡏࡌࡇࡑࡁࠬੰ"),rr7Xolsp4JwjPK3L(u"࠷෕"))[fdQOo6Hu4B5Rbg]
										break
									JH9QFvWNfaejK4d6TsLP08yA5IYODz = SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR
								else: SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
								SPuCMh4Njq9Z5VzYyr0EQ7XvWcGiR = SSCU3jdyFn2V.time()-Au5hSTpyGZoje4Q0BFvEm8agLfkY29
							HofqU5Wsa9.close()
				if jJ1iOyvCtQxbFeK:
					k0iuzJDf9qsFOZBSrMl5YEto37I = D7omduSeM5Gk.cookies
					ko8YKizX2n9GSLU = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭ੱ"),E5pMzFT7lyXjC8IOQN0Ubc2dGfomv,oo9kuULlebNgpY0Om.DOTALL)
					if bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧੲ") in list(k0iuzJDf9qsFOZBSrMl5YEto37I.keys()): ko8YKizX2n9GSLU = k0iuzJDf9qsFOZBSrMl5YEto37I[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨੳ")]
					elif ko8YKizX2n9GSLU: ko8YKizX2n9GSLU = ko8YKizX2n9GSLU[dQ5JhEYolPmy1fvHktMw6NFRxiz]
					captcha = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧੴ"),bn42I6TyC9ZgiY,oo9kuULlebNgpY0Om.DOTALL)
					if captcha: rrufohaGUd1ynRSjqVJwbW9zekM,LRebTraNEgnW1lcmKjkFuw4i = captcha[dQ5JhEYolPmy1fvHktMw6NFRxiz]
					if ko8YKizX2n9GSLU and captcha:
						headers = {vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪੵ"):cJSNFCIhymEfx6grGu0M(u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ੶")+ko8YKizX2n9GSLU,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭੷"):dQ4oKjz1Lle7HtG8m3DqR,cjbAkCIinvs(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ੸"):vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭੹")}
						data = rr7Xolsp4JwjPK3L(u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ੺")+jJ1iOyvCtQxbFeK
						D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡓࡓࡘ࡚ࠧ੻"),rrufohaGUd1ynRSjqVJwbW9zekM,data,headers,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ੼"))
						bn42I6TyC9ZgiY = D7omduSeM5Gk.content
						try: cookies = D7omduSeM5Gk.cookies
						except: cookies = {}
						mXDWkJMI4zgU5w6e0n9 = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ੽"),str(cookies),oo9kuULlebNgpY0Om.DOTALL)
			if mXDWkJMI4zgU5w6e0n9:
				YwC7jt5BQHhTUvbdGeM6f2ZLx,mXDWkJMI4zgU5w6e0n9 = mXDWkJMI4zgU5w6e0n9[dQ5JhEYolPmy1fvHktMw6NFRxiz]
				US8CaDFXHtjx7MTmzwePd2nEL0sy5 = YwC7jt5BQHhTUvbdGeM6f2ZLx+bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡃࠧ੾")+mXDWkJMI4zgU5w6e0n9
				amx9qJHkhw7oLdtVMG3.setSetting(dC3PsQJ0Ti28uYlov(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ੿"),US8CaDFXHtjx7MTmzwePd2nEL0sy5)
				hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ઀"),DTF3Lwy9etRH8mI(u"ࠨ่ฯัฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦล็ีส๊ࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦๆหษษะࠥํะศࠢส่ๆำีࠡๆๆ๎ࠥ๐ำหะา้์อࠠๅษะๆฬࠦ࠮࠯๋่ࠢฬࠦส้ฮาࠤาอฬสࠢ็ษ฾อฯส๊ࠢิฬࠦวๅใะูู๊ࠥะหࠣวูํัࠡ࡞ࡱࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊แฮืࠣืํ็๋ࠠฬๆีึࠦแ๋ࠢะห้ฯࠠห฼ํีࠥืศุࠢส่ัํวำࠢหห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤส฽แศรࠣีฬ๎สาࠢส่ส์สา่อࠤ࠳࠴ࠠฤ๊ࠣๅฺ๊ࠠิๆๆࠤฬ๊ัศ๊อีࠥ࠴࠮ࠡล๋ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥฮั้ๅึ๎ࠬઁ"))
				if bneABYmwFUH8GXphg0Kl2Sq(u"ࠩ࠱ࡱࡵ࠺ࠧં") not in bn42I6TyC9ZgiY:
					headers = {RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪઃ"):US8CaDFXHtjx7MTmzwePd2nEL0sy5}
					D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,iqHhJSxdaANDG5rlZm7B(u"ࠫࡌࡋࡔࠨ઄"),dQ4oKjz1Lle7HtG8m3DqR,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠹ࡷ࡬ࠬઅ"))
					bn42I6TyC9ZgiY = D7omduSeM5Gk.content
	if not a2brFZlqWO8hK1UfAmLVz and not US8CaDFXHtjx7MTmzwePd2nEL0sy5: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩઆ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧઇ"))
	return bn42I6TyC9ZgiY
def NNHDVzYX8O(url,C9uTVdSkLlb5UemavyB6NjWHFh,I5chimw4D1okfxlBE2UpbuHJvStsZ):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,GGoLgj5BFbWI = [],[]
	dQ4oKjz1Lle7HtG8m3DqR = url
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡉࡈࡘࠬઈ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨઉ"))
	ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
	hDLFrE70PVo6uwzXfHq4v9aB = []
	if qTVF3icWwGXy5(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫઊ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt or RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨઋ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt:
		cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬઌ"),ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if cUE5uH8hAtOmTp:
			for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
				dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪઍ"),BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,title in dsGzqX4k0a8RLyc:
					if Y6YdkAMluFbwx in ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh: continue
					if GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ઎") not in Y6YdkAMluFbwx and hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬએ") not in Y6YdkAMluFbwx: continue
					if bneABYmwFUH8GXphg0Kl2Sq(u"ࠩสࠫઐ") not in title:
						hDLFrE70PVo6uwzXfHq4v9aB.append((title,Y6YdkAMluFbwx))
						continue
					title = title.replace(t2sCrJ0xbgDRkf(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫઑ"),G9G0YqivIfmUWO8K).replace(rr7Xolsp4JwjPK3L(u"ࠫࠥ࠳ࠠࠨ઒"),G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
					if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡹࡰࡢࡰࠪઓ") in title: continue
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
					GGoLgj5BFbWI.append(title)
			for title,Y6YdkAMluFbwx in hDLFrE70PVo6uwzXfHq4v9aB:
				if Y6YdkAMluFbwx not in ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
					GGoLgj5BFbWI.append(title)
			PXeEIRkdShOGm45lbLJc2B38s = dQ5JhEYolPmy1fvHktMw6NFRxiz
			if len(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh)>fdQOo6Hu4B5Rbg:
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(VHrIziKUDuNGXkMla(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭ઔ"),GGoLgj5BFbWI)
				if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return iAGgjwb7tVMmacRJ(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬક"),[],[]
			if ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh and PXeEIRkdShOGm45lbLJc2B38s>=dQ5JhEYolPmy1fvHktMw6NFRxiz: dQ4oKjz1Lle7HtG8m3DqR = ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh[PXeEIRkdShOGm45lbLJc2B38s]
	bn42I6TyC9ZgiY = jGa2SYHmhpOFq0UMboR(dQ4oKjz1Lle7HtG8m3DqR)
	ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = [],[]
	if C9uTVdSkLlb5UemavyB6NjWHFh==UighHKAfySm4PWErqJ(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪખ"):
		jLCKc3hMGgTA4Ns8lbz6yidxt0mXW = oo9kuULlebNgpY0Om.findall(EHUAyW2lQfe4LXmhgIGc(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧગ"),bn42I6TyC9ZgiY,oo9kuULlebNgpY0Om.DOTALL)
		if jLCKc3hMGgTA4Ns8lbz6yidxt0mXW:
			Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(jLCKc3hMGgTA4Ns8lbz6yidxt0mXW[dQ5JhEYolPmy1fvHktMw6NFRxiz])
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(I5chimw4D1okfxlBE2UpbuHJvStsZ)
	elif C9uTVdSkLlb5UemavyB6NjWHFh==cjbAkCIinvs(u"ࠪࡻࡦࡺࡣࡩࠩઘ"):
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ઙ"),bn42I6TyC9ZgiY,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,size in dsGzqX4k0a8RLyc:
			if not Y6YdkAMluFbwx: continue
			if I5chimw4D1okfxlBE2UpbuHJvStsZ in size:
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(size)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
				break
		if not ODnaR0N8UHv7Twy6jS:
			for Y6YdkAMluFbwx,size in dsGzqX4k0a8RLyc:
				if not Y6YdkAMluFbwx: continue
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(size)
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if not ODnaR0N8UHv7Twy6jS: return cJSNFCIhymEfx6grGu0M(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭ચ"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def xx1DRtjhcN(url,YwC7jt5BQHhTUvbdGeM6f2ZLx):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡇࡆࡖࠪછ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭જ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cookies = D7omduSeM5Gk.cookies
	if rr7Xolsp4JwjPK3L(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨઝ") in list(cookies.keys()):
		US8CaDFXHtjx7MTmzwePd2nEL0sy5 = cookies[yiaeCEwJjOcWA4ZSd5h(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩઞ")]
		US8CaDFXHtjx7MTmzwePd2nEL0sy5 = aKAyEnjxIlzZtCTv(zDBtm4MwIagkfcpE5oxJOAq6lZQY(US8CaDFXHtjx7MTmzwePd2nEL0sy5))
		items = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫટ"),US8CaDFXHtjx7MTmzwePd2nEL0sy5,oo9kuULlebNgpY0Om.DOTALL)
		XXzvmn7ewM8yBfoxua = items[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡡ࠵ࠧઠ"),jR9YtmsgDX8nTQlMb6G3(u"ࠬ࠵ࠧડ"))
		XXzvmn7ewM8yBfoxua = zDBtm4MwIagkfcpE5oxJOAq6lZQY(XXzvmn7ewM8yBfoxua)
	else: XXzvmn7ewM8yBfoxua = url
	if UighHKAfySm4PWErqJ(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨઢ") in XXzvmn7ewM8yBfoxua:
		xkwP5GvqpMUa3VzKHDf = XXzvmn7ewM8yBfoxua.split(UighHKAfySm4PWErqJ(u"ࠧࠦ࠴ࡉࠫણ"))[-fdQOo6Hu4B5Rbg]
		XXzvmn7ewM8yBfoxua = iqHhJSxdaANDG5rlZm7B(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫત")+xkwP5GvqpMUa3VzKHDf
		return RVpeGcmPxj9tCnT40Nf216(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬથ"),[G9G0YqivIfmUWO8K],[XXzvmn7ewM8yBfoxua]
	else:
		website = Kkfl8xemuHbd1w3a0ABPcDrN[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡅࡐࡕࡁࡎࠩદ")][dQ5JhEYolPmy1fvHktMw6NFRxiz]
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡌࡋࡔࠨધ"),website,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫન"))
		mbHkXnTBC1tosFp6yjV9qDiQS = D7omduSeM5Gk.url
		f4YwcnPq5TemkNLtaJM6 = XXzvmn7ewM8yBfoxua.split(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭࠯ࠨ઩"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		qOnf7TpFzRjvmEkSNys5PV3LQJalMw = mbHkXnTBC1tosFp6yjV9qDiQS.split(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࠰ࠩપ"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
		XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua.replace(f4YwcnPq5TemkNLtaJM6,qOnf7TpFzRjvmEkSNys5PV3LQJalMw)
		headers = { iqHhJSxdaANDG5rlZm7B(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬફ"):G9G0YqivIfmUWO8K , qTVF3icWwGXy5(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬબ"):t2sCrJ0xbgDRkf(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫભ") , RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬમ"):XjWHSnbf6NwhMgpKt4yLY7AkIT }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡖࡏࡔࡖࠪય"), XjWHSnbf6NwhMgpKt4yLY7AkIT, G9G0YqivIfmUWO8K, headers, kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬર"))
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		items = oo9kuULlebNgpY0Om.findall(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ઱"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if not items:
			items = oo9kuULlebNgpY0Om.findall(EHUAyW2lQfe4LXmhgIGc(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩલ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
			if not items:
				items = oo9kuULlebNgpY0Om.findall(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩળ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if items:
			Y6YdkAMluFbwx = items[dQ5JhEYolPmy1fvHktMw6NFRxiz].replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡠ࠴࠭઴"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠴࠭વ"))
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.rstrip(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬ࠵ࠧશ"))
			if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡨࡵࡶࡳࠫષ") not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡩࡶࡷࡴ࠿࠭સ") + Y6YdkAMluFbwx
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(VHrIziKUDuNGXkMla(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩહ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ઺"))
			if YwC7jt5BQHhTUvbdGeM6f2ZLx==G9G0YqivIfmUWO8K: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
			else: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = iAGgjwb7tVMmacRJ(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭઻"),[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
		else: lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑ઼ࠬ"),[],[]
		return lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def llBkIghaAtVZFiD(url):
	headers = { ssGdubC4mngM9D5SRc3Ye(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઽ") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪા"))
	items = oo9kuULlebNgpY0Om.findall(UighHKAfySm4PWErqJ(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨિ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS,errno = [],[],G9G0YqivIfmUWO8K
	if items:
		for Y6YdkAMluFbwx,G6XbgFWwaiq in items:
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G6XbgFWwaiq)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧી"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def er5oHMm7Atp0NZJa2qwyX9(url):
	headers = {rxWDdRBIct57i90s(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ુ"):G9G0YqivIfmUWO8K}
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪૂ"))
	items = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩૃ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		url = items[dQ5JhEYolPmy1fvHktMw6NFRxiz]+cJSNFCIhymEfx6grGu0M(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨૄ")+url
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
	else: return yiaeCEwJjOcWA4ZSd5h(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨૅ"),[],[]
def B6A1cRgtrhU4pVYxDlSa8P(url):
	url = url.strip(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧ࠰ࠩ૆"))
	if ssGdubC4mngM9D5SRc3Ye(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩે") in url: xkwP5GvqpMUa3VzKHDf = url.split(ETNq5t4MYngSsbfFD8J0v(u"ࠩ࠲ࠫૈ"))[xsCEkXb6tgrh3195YZ]
	else: xkwP5GvqpMUa3VzKHDf = url.split(ETNq5t4MYngSsbfFD8J0v(u"ࠪ࠳ࠬૉ"))[-fdQOo6Hu4B5Rbg]
	url = UighHKAfySm4PWErqJ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ૊") + xkwP5GvqpMUa3VzKHDf
	headers = { t2sCrJ0xbgDRkf(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩો") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨૌ"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧ࡝࡞્ࠪ"),G9G0YqivIfmUWO8K)
	items = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૎"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[ items[dQ5JhEYolPmy1fvHktMw6NFRxiz] ]
	else: return CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭૏"),[],[]
def GPbYFvUBRhm9nyg74OM8ku6rCi5(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪૐ"))
	items = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ૑"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	for Y6YdkAMluFbwx,G6XbgFWwaiq,Y4mtsbU6i0E2a9DjMIfZv in items:
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G6XbgFWwaiq+ww0sZkBU9JKd+Y4mtsbU6i0E2a9DjMIfZv)
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return FWqeEzO1i8Dn0ga(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ૒"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def pKDzLymRPZl(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ૓"))
	items = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ૔"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	items = set(items)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	for xkwP5GvqpMUa3VzKHDf,Mauf6CrJjP87s,sThEywUInP5HiDbOQZoG9,G6XbgFWwaiq,Y4mtsbU6i0E2a9DjMIfZv in items:
		url = ssGdubC4mngM9D5SRc3Ye(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ૕")+xkwP5GvqpMUa3VzKHDf+EHUAyW2lQfe4LXmhgIGc(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ૖")+Mauf6CrJjP87s+DTF3Lwy9etRH8mI(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ૗")+sThEywUInP5HiDbOQZoG9
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ૘"))
		items = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ૙"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in items:
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(G6XbgFWwaiq+ww0sZkBU9JKd+Y4mtsbU6i0E2a9DjMIfZv)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if len(ODnaR0N8UHv7Twy6jS)==dQ5JhEYolPmy1fvHktMw6NFRxiz: return FWqeEzO1i8Dn0ga(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬ૚"),[],[]
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def hEfcxwbLNCym(url):
	Y6YdkAMluFbwx = G9G0YqivIfmUWO8K
	if fdQOo6Hu4B5Rbg or RVpeGcmPxj9tCnT40Nf216(u"ࠧࡌࡧࡼࡁࠬ૛") not in url:
		XXzvmn7ewM8yBfoxua = url.replace(t2sCrJ0xbgDRkf(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ૜"),VHrIziKUDuNGXkMla(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭૝"))
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.split(t2sCrJ0xbgDRkf(u"ࠪ࠳ࠬ૞"))
		xkwP5GvqpMUa3VzKHDf = XXzvmn7ewM8yBfoxua[c1R9fnIY4XBDZ]
		XXzvmn7ewM8yBfoxua = rr7Xolsp4JwjPK3L(u"ࠫ࠴࠭૟").join(XXzvmn7ewM8yBfoxua[dQ5JhEYolPmy1fvHktMw6NFRxiz:xsCEkXb6tgrh3195YZ])
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {FWqeEzO1i8Dn0ga(u"ࠬ࡯ࡤࠨૠ"):xkwP5GvqpMUa3VzKHDf,ETNq5t4MYngSsbfFD8J0v(u"࠭࡯ࡱࠩૡ"):qTVF3icWwGXy5(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪૢ"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭ૣ"):CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ૤")}
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡔࡔ࡙ࡔࠨ૥"),XXzvmn7ewM8yBfoxua,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ૦"))
		if jR9YtmsgDX8nTQlMb6G3(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ૧") in list(D7omduSeM5Gk.headers.keys()): Y6YdkAMluFbwx = D7omduSeM5Gk.headers[ETNq5t4MYngSsbfFD8J0v(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ૨")]
		if not Y6YdkAMluFbwx and D7omduSeM5Gk.succeeded:
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
			Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ૩"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if Y6YdkAMluFbwx: Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cjbAkCIinvs(u"ࠨࡉࡈࡘࠬ૪"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ૫"))
		if bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ૬") in list(D7omduSeM5Gk.headers.keys()): Y6YdkAMluFbwx = D7omduSeM5Gk.headers[cjbAkCIinvs(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭૭")]
	if Y6YdkAMluFbwx: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	return cJSNFCIhymEfx6grGu0M(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭૮"),[],[]
def xG6bM0fC3WUrDS2dXQIYBaNZypu7gO(url):
	headers = { t2sCrJ0xbgDRkf(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ૯") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ૰"))
	items = oo9kuULlebNgpY0Om.findall(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ૱"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	if items:
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡰࡴ࠹࠭૲"))
		ODnaR0N8UHv7Twy6jS.append(items[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg])
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(FWqeEzO1i8Dn0ga(u"ࠪࡱ࠸ࡻ࠸ࠨ૳"))
		ODnaR0N8UHv7Twy6jS.append(items[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz])
		return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
	else: return vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ૴"),[],[]
def nnJUZtLkYDXA19SEhydmRFiwzv(url):
	xkwP5GvqpMUa3VzKHDf = url.split(dC3PsQJ0Ti28uYlov(u"ࠬ࠵ࠧ૵"))[-fdQOo6Hu4B5Rbg]
	xkwP5GvqpMUa3VzKHDf = xkwP5GvqpMUa3VzKHDf.split(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࠦࠨ૶"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	xkwP5GvqpMUa3VzKHDf = xkwP5GvqpMUa3VzKHDf.replace(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ૷"),G9G0YqivIfmUWO8K)
	XXzvmn7ewM8yBfoxua = Kkfl8xemuHbd1w3a0ABPcDrN[UighHKAfySm4PWErqJ(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ૸")][dQ5JhEYolPmy1fvHktMw6NFRxiz]+qTVF3icWwGXy5(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬૹ")+xkwP5GvqpMUa3VzKHDf
	i5FubIlqEramYSJW7f4NTHdMp = jR9YtmsgDX8nTQlMb6G3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭ૺ")+xkwP5GvqpMUa3VzKHDf
	r7ry096dBnxu,l1BGb7Vk2HMw30j = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	headers = {jR9YtmsgDX8nTQlMb6G3(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨૻ"):G9G0YqivIfmUWO8K}
	if dQ5JhEYolPmy1fvHktMw6NFRxiz:
		GagwMT6q3oc7UZ2Q = G9G0YqivIfmUWO8K
		for p0p6MxKbklodNCR92Wv in range(bneABYmwFUH8GXphg0Kl2Sq(u"࠵ූ")):
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,rxWDdRBIct57i90s(u"ࠬࡍࡅࡕࠩૼ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ૽"))
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
			if rr7Xolsp4JwjPK3L(u"ࠧࡪࡶࡤ࡫ࠬ૾") in GagwMT6q3oc7UZ2Q: break
			SSCU3jdyFn2V.sleep(SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU)
		iHRhfNUTIJ5l01cM = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡑ࡮ࡤࡽࡪࡸࡒࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ૿"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if iHRhfNUTIJ5l01cM: iHRhfNUTIJ5l01cM = iHRhfNUTIJ5l01cM[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else: iHRhfNUTIJ5l01cM = GagwMT6q3oc7UZ2Q
	else:
		GagwMT6q3oc7UZ2Q = G9G0YqivIfmUWO8K
		npQ50TJGgKtN6S,qsRUfFwphQXBZEvHPc = G9G0YqivIfmUWO8K,{}
		RbuvYgAmzSd0jkH6fMo9s58,J78cpFkWgLmRws4DrY59HKd6vM = G9G0YqivIfmUWO8K,{}
		XjWHSnbf6NwhMgpKt4yLY7AkIT = Kkfl8xemuHbd1w3a0ABPcDrN[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ଀")][dQ5JhEYolPmy1fvHktMw6NFRxiz]+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࠩଁ")
		headers[FWqeEzO1i8Dn0ga(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪଂ")] = cJSNFCIhymEfx6grGu0M(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨଃ")
		if fdQOo6Hu4B5Rbg:
			cRx6fa73DukTQ0S9NemsizY1LvHCMI = bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭଄")+xkwP5GvqpMUa3VzKHDf+cJSNFCIhymEfx6grGu0M(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠻࠲࠶࠸࠮࠱ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡇࡎࡅࡔࡒࡍࡉࡥࡕࡏࡒࡏ࡙ࡌࡍࡅࡅࠤࢀࢁࢂ࠭ଅ")
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,jR9YtmsgDX8nTQlMb6G3(u"ࠨࡒࡒࡗ࡙࠭ଆ"),XjWHSnbf6NwhMgpKt4yLY7AkIT,cRx6fa73DukTQ0S9NemsizY1LvHCMI,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪଇ"))
			iHRhfNUTIJ5l01cM = D7omduSeM5Gk.content
			if hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪଈ") in iHRhfNUTIJ5l01cM:
				npQ50TJGgKtN6S = iHRhfNUTIJ5l01cM.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬଉ"),RVpeGcmPxj9tCnT40Nf216(u"ࠬࠬࠧଊ"))
				qsRUfFwphQXBZEvHPc = bRCSwcA89e4J7pqdays5PxGiD2(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡤࡪࡥࡷࠫଋ"),npQ50TJGgKtN6S)
		if fdQOo6Hu4B5Rbg:
			cRx6fa73DukTQ0S9NemsizY1LvHCMI = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡼࠤࡹ࡭ࡩ࡫࡯ࡊࡦࠥ࠾ࠥࠨࠧଌ")+xkwP5GvqpMUa3VzKHDf+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࠤ࠯ࠤࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ࠻ࠢࠥ࠺࠳࠹࠶ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡎࡕࡓࡠࡗࡑࡔࡑ࡛ࡇࡈࡇࡇࠦࢂࢃࡽࠨ଍")
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡓࡓࡘ࡚ࠧ଎"),XjWHSnbf6NwhMgpKt4yLY7AkIT,cRx6fa73DukTQ0S9NemsizY1LvHCMI,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠴ࡴࡧࠫଏ"))
			iHRhfNUTIJ5l01cM = D7omduSeM5Gk.content
			if jR9YtmsgDX8nTQlMb6G3(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫଐ") in iHRhfNUTIJ5l01cM:
				RbuvYgAmzSd0jkH6fMo9s58 = iHRhfNUTIJ5l01cM.replace(dC3PsQJ0Ti28uYlov(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭଑"),iqHhJSxdaANDG5rlZm7B(u"࠭ࠦࠨ଒"))
				J78cpFkWgLmRws4DrY59HKd6vM = bRCSwcA89e4J7pqdays5PxGiD2(yiaeCEwJjOcWA4ZSd5h(u"ࠧࡥ࡫ࡦࡸࠬଓ"),RbuvYgAmzSd0jkH6fMo9s58)
		if fdQOo6Hu4B5Rbg and iAGgjwb7tVMmacRJ(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨଔ") not in npQ50TJGgKtN6S+RbuvYgAmzSd0jkH6fMo9s58:
			npQ50TJGgKtN6S,RbuvYgAmzSd0jkH6fMo9s58 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
			qsRUfFwphQXBZEvHPc,J78cpFkWgLmRws4DrY59HKd6vM = {},{}
			cRx6fa73DukTQ0S9NemsizY1LvHCMI = ETNq5t4MYngSsbfFD8J0v(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩକ")+xkwP5GvqpMUa3VzKHDf+RVpeGcmPxj9tCnT40Nf216(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠹࠯࠴࠼࠲࠸࠽ࠢ࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ࠻ࠢࠥࡍࡔ࡙ࠢࡾࡿࢀࠫଖ")
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡕࡕࡓࡕࠩଗ"),XjWHSnbf6NwhMgpKt4yLY7AkIT,cRx6fa73DukTQ0S9NemsizY1LvHCMI,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠷ࡸ࡭࠭ଘ"))
			iHRhfNUTIJ5l01cM = D7omduSeM5Gk.content
			if qTVF3icWwGXy5(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ଙ") in iHRhfNUTIJ5l01cM:
				npQ50TJGgKtN6S = iHRhfNUTIJ5l01cM.replace(iqHhJSxdaANDG5rlZm7B(u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨଚ"),yiaeCEwJjOcWA4ZSd5h(u"ࠨࠨࠪଛ"))
				qsRUfFwphQXBZEvHPc = bRCSwcA89e4J7pqdays5PxGiD2(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡧ࡭ࡨࡺࠧଜ"),npQ50TJGgKtN6S)
	IMceYKnpwZrXNPFHUQf,I1eR2Pzoh6aKElyX0FnMkrqwY3pUBv,kOh946GnepxYgLSaoqNVKzUF,GDLI5mvKq1Z7AC2rsjeEPV4B3 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[],[]
	bBFjX59Vq1GsdumiRtUSpnN,BBTdYj16nk5OP3KJFiZ4h0uXC,J1PmsRbOfo8i3NMjT2H,uojqmXT5z1 = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[],[]
	try: I1eR2Pzoh6aKElyX0FnMkrqwY3pUBv = qsRUfFwphQXBZEvHPc[RVpeGcmPxj9tCnT40Nf216(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪଝ")][bneABYmwFUH8GXphg0Kl2Sq(u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬଞ")]
	except: pass
	try: BBTdYj16nk5OP3KJFiZ4h0uXC = J78cpFkWgLmRws4DrY59HKd6vM[ETNq5t4MYngSsbfFD8J0v(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬଟ")][wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧଠ")]
	except: pass
	try: IMceYKnpwZrXNPFHUQf = qsRUfFwphQXBZEvHPc[rr7Xolsp4JwjPK3L(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧଡ")][CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪଢ")]
	except: pass
	try: bBFjX59Vq1GsdumiRtUSpnN = J78cpFkWgLmRws4DrY59HKd6vM[VHrIziKUDuNGXkMla(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩଣ")][hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡨࡦࡹࡨࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬତ")]
	except: pass
	try: kOh946GnepxYgLSaoqNVKzUF = qsRUfFwphQXBZEvHPc[jR9YtmsgDX8nTQlMb6G3(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫଥ")][t2sCrJ0xbgDRkf(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭ଦ")]
	except: pass
	try: J1PmsRbOfo8i3NMjT2H = J78cpFkWgLmRws4DrY59HKd6vM[cjbAkCIinvs(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ଧ")][CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨନ")]
	except: pass
	try: GDLI5mvKq1Z7AC2rsjeEPV4B3 = qsRUfFwphQXBZEvHPc[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ଩")][FWqeEzO1i8Dn0ga(u"ࠩࡤࡨࡦࡶࡴࡪࡸࡨࡊࡴࡸ࡭ࡢࡶࡶࠫପ")]
	except: pass
	try: uojqmXT5z1 = J78cpFkWgLmRws4DrY59HKd6vM[t2sCrJ0xbgDRkf(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪଫ")][dC3PsQJ0Ti28uYlov(u"ࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡌ࡯ࡳ࡯ࡤࡸࡸ࠭ବ")]
	except: pass
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [bneABYmwFUH8GXphg0Kl2Sq(u"ࠬฮฯ้่ࠣฮึาๅสࠢํ์ฯ๐่ษࠩଭ")],[G9G0YqivIfmUWO8K]
	try:
		WW1c7RYkm3o = qsRUfFwphQXBZEvHPc[FWqeEzO1i8Dn0ga(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨମ")][rxWDdRBIct57i90s(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫଯ")][bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨର")]
		for UWe2OjviqA4dRZ05Gf in WW1c7RYkm3o:
			Y6YdkAMluFbwx = UWe2OjviqA4dRZ05Gf[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ଱")]
			try: title = UWe2OjviqA4dRZ05Gf[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡲࡦࡳࡥࠨଲ")][dC3PsQJ0Ti28uYlov(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨଳ")]
			except: title = UWe2OjviqA4dRZ05Gf[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡴࡡ࡮ࡧࠪ଴")][dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡲࡶࡰࡶࠫଵ")][dQ5JhEYolPmy1fvHktMw6NFRxiz][GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡵࡧࡻࡸࡹ࠭ଶ")]
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
	except: pass
	try:
		WW1c7RYkm3o = J78cpFkWgLmRws4DrY59HKd6vM[rr7Xolsp4JwjPK3L(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪଷ")][qTVF3icWwGXy5(u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ସ")][GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪହ")]
		for UWe2OjviqA4dRZ05Gf in WW1c7RYkm3o:
			Y6YdkAMluFbwx = UWe2OjviqA4dRZ05Gf[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ଺")]
			try: title = UWe2OjviqA4dRZ05Gf[cJSNFCIhymEfx6grGu0M(u"ࠬࡴࡡ࡮ࡧࠪ଻")][iqHhJSxdaANDG5rlZm7B(u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶ଼ࠪ")]
			except: title = UWe2OjviqA4dRZ05Gf[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡯ࡣࡰࡩࠬଽ")][vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡴࡸࡲࡸ࠭ା")][dQ5JhEYolPmy1fvHktMw6NFRxiz][EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡷࡩࡽࡺࡴࠨି")]
			if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
				Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
	except: pass
	if len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)>fdQOo6Hu4B5Rbg:
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(RVpeGcmPxj9tCnT40Nf216(u"ࠪหำะัࠡษ็ฮึาๅสࠢࠫࠫୀ")+str(len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO))+FWqeEzO1i8Dn0ga(u"๋ࠫࠥไโࠫࠪୁ"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
		if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return RVpeGcmPxj9tCnT40Nf216(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪୂ"),[],[]
		elif PXeEIRkdShOGm45lbLJc2B38s!=dQ5JhEYolPmy1fvHktMw6NFRxiz:
			Y6YdkAMluFbwx = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]+bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࠦࠨୃ")
			XgcU3Kuav6OnNYwbBs = oo9kuULlebNgpY0Om.findall(RVpeGcmPxj9tCnT40Nf216(u"ࠧࠧࠪࡩࡱࡹࡃ࠮ࠫࡁࠬࠪࠬୄ"),Y6YdkAMluFbwx)
			if XgcU3Kuav6OnNYwbBs: Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(XgcU3Kuav6OnNYwbBs[dQ5JhEYolPmy1fvHktMw6NFRxiz],ssGdubC4mngM9D5SRc3Ye(u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ୅"))
			else: Y6YdkAMluFbwx = Y6YdkAMluFbwx+dC3PsQJ0Ti28uYlov(u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ୆")
			r7ry096dBnxu = Y6YdkAMluFbwx.strip(t2sCrJ0xbgDRkf(u"ࠪࠪࠬେ"))
	TdhBgFfkXebOZtay3YMJSr0E2,JTg3PQOYKGhd95DLrvxA1XaW,TexbdHpu74Vm2jWLXiQ08qSFYJsK = [],[],[]
	QQHcC6EW7kyOlZYAu8FwD1nd59zpN = [I1eR2Pzoh6aKElyX0FnMkrqwY3pUBv,BBTdYj16nk5OP3KJFiZ4h0uXC]
	SzuwNkdcoIqvxyLh9mQADBCpa = [IMceYKnpwZrXNPFHUQf,bBFjX59Vq1GsdumiRtUSpnN]
	JzQ1sP6HyGwO9,vMfjgThc07q3sBaDXACxNrnw1 = [],[]
	for AvqN68HCXkJbOw1plrYia4ZyRQMGo in kOh946GnepxYgLSaoqNVKzUF+J1PmsRbOfo8i3NMjT2H:
		if AvqN68HCXkJbOw1plrYia4ZyRQMGo[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࡮ࡺࡡࡨࠩୈ")] not in JzQ1sP6HyGwO9:
			JzQ1sP6HyGwO9.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo[rxWDdRBIct57i90s(u"ࠬ࡯ࡴࡢࡩࠪ୉")])
			vMfjgThc07q3sBaDXACxNrnw1.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo)
	JzQ1sP6HyGwO9,ZSUJinqvCP05Fes6zg7kXVrho = [],[]
	for AvqN68HCXkJbOw1plrYia4ZyRQMGo in GDLI5mvKq1Z7AC2rsjeEPV4B3+uojqmXT5z1:
		if AvqN68HCXkJbOw1plrYia4ZyRQMGo[qTVF3icWwGXy5(u"࠭ࡩࡵࡣࡪࠫ୊")] not in JzQ1sP6HyGwO9:
			JzQ1sP6HyGwO9.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo[yiaeCEwJjOcWA4ZSd5h(u"ࠧࡪࡶࡤ࡫ࠬୋ")])
			ZSUJinqvCP05Fes6zg7kXVrho.append(AvqN68HCXkJbOw1plrYia4ZyRQMGo)
	for dict in vMfjgThc07q3sBaDXACxNrnw1+ZSUJinqvCP05Fes6zg7kXVrho:
		if DTF3Lwy9etRH8mI(u"ࠨ࡫ࡷࡥ࡬࠭ୌ") in list(dict.keys()): dict[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡬ࡸࡦ࡭୍ࠧ")] = str(dict[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࡭ࡹࡧࡧࠨ୎")])
		if yiaeCEwJjOcWA4ZSd5h(u"ࠫ࡫ࡶࡳࠨ୏") in list(dict.keys()): dict[UighHKAfySm4PWErqJ(u"ࠬ࡬ࡰࡴࠩ୐")] = str(dict[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡦࡱࡵࠪ୑")])
		if hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ୒") in list(dict.keys()): dict[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡶࡼࡴࡪ࠭୓")] = dict[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ୔")]
		if qTVF3icWwGXy5(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ୕") in list(dict.keys()): dict[cjbAkCIinvs(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨୖ")] = str(dict[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧୗ")])
		if ETNq5t4MYngSsbfFD8J0v(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭୘") in list(dict.keys()): dict[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ୙")] = str(dict[VHrIziKUDuNGXkMla(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ୚")])
		if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡺ࡭ࡩࡺࡨࠨ୛") in list(dict.keys()): dict[rr7Xolsp4JwjPK3L(u"ࠪࡷ࡮ࢀࡥࠨଡ଼")] = str(dict[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡼ࡯ࡤࡵࡪࠪଢ଼")])+VHrIziKUDuNGXkMla(u"ࠬࡾࠧ୞")+str(dict[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ୟ")])
		if bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪୠ") in list(dict.keys()): dict[ETNq5t4MYngSsbfFD8J0v(u"ࠨ࡫ࡱ࡭ࡹ࠭ୡ")] = dict[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬୢ")][hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡷࡹࡧࡲࡵࠩୣ")]+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࠲࠭୤")+dict[cJSNFCIhymEfx6grGu0M(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ୥")][ETNq5t4MYngSsbfFD8J0v(u"࠭ࡥ࡯ࡦࠪ୦")]
		if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ୧") in list(dict.keys()): dict[yiaeCEwJjOcWA4ZSd5h(u"ࠨ࡫ࡱࡨࡪࡾࠧ୨")] = dict[EHUAyW2lQfe4LXmhgIGc(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭୩")][RVpeGcmPxj9tCnT40Nf216(u"ࠪࡷࡹࡧࡲࡵࠩ୪")]+DTF3Lwy9etRH8mI(u"ࠫ࠲࠭୫")+dict[rxWDdRBIct57i90s(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ୬")][FWqeEzO1i8Dn0ga(u"࠭ࡥ࡯ࡦࠪ୭")]
		if cJSNFCIhymEfx6grGu0M(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ୮") in list(dict.keys()): dict[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ୯")] = dict[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ୰")]
		if hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫୱ") in list(dict.keys()) and int(dict[rr7Xolsp4JwjPK3L(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ୲")])>vCmnFshSi4flecXIY2gy38G0DJw(u"࠲࠳࠴࠶࠷࠸࠳࠴࠵෗"): del dict[iAGgjwb7tVMmacRJ(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭୳")]
		if qTVF3icWwGXy5(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ୴") in list(dict.keys()):
			MXZLahlU4YJn6KmrSkC5 = dict[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ୵")].split(EHUAyW2lQfe4LXmhgIGc(u"ࠨࠨࠪ୶"))
			for XX2Btn97vEfkCjcuWs in MXZLahlU4YJn6KmrSkC5:
				key,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split(UighHKAfySm4PWErqJ(u"ࠩࡀࠫ୷"),ssGdubC4mngM9D5SRc3Ye(u"࠳ෘ"))
				dict[key] = aKAyEnjxIlzZtCTv(yW70dtahIjkPCJg2TA)
		if vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡹࡷࡲࠧ୸") in list(dict.keys()): dict[EHUAyW2lQfe4LXmhgIGc(u"ࠫࡺࡸ࡬ࠨ୹")] = aKAyEnjxIlzZtCTv(dict[rxWDdRBIct57i90s(u"ࠬࡻࡲ࡭ࠩ୺")])
		TdhBgFfkXebOZtay3YMJSr0E2.append(dict)
	te9Z5d6CHYBX3k4jqgMERFb = G9G0YqivIfmUWO8K
	if hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡳࡱ࠿ࡶ࡭࡬࠭୻") in npQ50TJGgKtN6S or ETNq5t4MYngSsbfFD8J0v(u"ࠧࡴࡲࡀࡷ࡮࡭ࠧ୼") in RbuvYgAmzSd0jkH6fMo9s58:
		if not GagwMT6q3oc7UZ2Q:
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡉࡈࡘࠬ୽"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪ୾"))
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		KeARZP0Gzo = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩ୿"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if KeARZP0Gzo:
			KeARZP0Gzo = Kkfl8xemuHbd1w3a0ABPcDrN[iAGgjwb7tVMmacRJ(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ஀")][dQ5JhEYolPmy1fvHktMw6NFRxiz]+KeARZP0Gzo[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,cjbAkCIinvs(u"ࠬࡍࡅࡕࠩ஁"),KeARZP0Gzo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠺ࡹ࡮ࠧஂ"))
			te9Z5d6CHYBX3k4jqgMERFb = D7omduSeM5Gk.content
			import youtube_signature.cipher as RR61xbzs73ycPADLJ2,youtube_signature.json_script_engine as rFfeVDJ1yKERcgLBUSn92t8
			MXZLahlU4YJn6KmrSkC5 = aa4Z8dHnjTWwVpFBQDtL.MXZLahlU4YJn6KmrSkC5.Cipher()
			MXZLahlU4YJn6KmrSkC5._object_cache = {}
			YQvGL1mMpxCTkZ5Kfe = MXZLahlU4YJn6KmrSkC5._load_javascript(te9Z5d6CHYBX3k4jqgMERFb)
			Iucq6SBMPsxX7imew = bRCSwcA89e4J7pqdays5PxGiD2(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡴࡶࡵࠫஃ"),str(YQvGL1mMpxCTkZ5Kfe))
			R4RtSWIZiKgBUCaqh9ybXGQcP2u = aa4Z8dHnjTWwVpFBQDtL.QtNUfkzSnCZhWqTp4i.JsonScriptEngine(Iucq6SBMPsxX7imew)
	for dict in TdhBgFfkXebOZtay3YMJSr0E2:
		url = dict[iAGgjwb7tVMmacRJ(u"ࠨࡷࡵࡰࠬ஄")]
		if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭அ") in url or url.count(qTVF3icWwGXy5(u"ࠪࡷ࡮࡭࠽ࠨஆ"))>fdQOo6Hu4B5Rbg:
			JTg3PQOYKGhd95DLrvxA1XaW.append(dict)
		elif te9Z5d6CHYBX3k4jqgMERFb and rxWDdRBIct57i90s(u"ࠫࡸ࠭இ") in list(dict.keys()) and ETNq5t4MYngSsbfFD8J0v(u"ࠬࡹࡰࠨஈ") in list(dict.keys()):
			y86xniT0ESaWdMkzKF329lhbIJX = R4RtSWIZiKgBUCaqh9ybXGQcP2u.execute(dict[t2sCrJ0xbgDRkf(u"࠭ࡳࠨஉ")])
			if y86xniT0ESaWdMkzKF329lhbIJX!=dict[ssGdubC4mngM9D5SRc3Ye(u"ࠧࡴࠩஊ")]:
				dict[EHUAyW2lQfe4LXmhgIGc(u"ࠨࡷࡵࡰࠬ஋")] = url+dC3PsQJ0Ti28uYlov(u"ࠩࠩࠫ஌")+dict[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡷࡵ࠭஍")]+EHUAyW2lQfe4LXmhgIGc(u"ࠫࡂ࠭எ")+y86xniT0ESaWdMkzKF329lhbIJX
				JTg3PQOYKGhd95DLrvxA1XaW.append(dict)
	for dict in JTg3PQOYKGhd95DLrvxA1XaW:
		FF94GpU6MrbZy,hGIQ9NBUw3a1fkjrJtxDsTvZnRyH,llZdN9gJCcoODYV8FsjB0,hEDd8S3OLIugvAc5HRzQkTqM60wW,SIE35AxPdFfq0DM9Yzt7R4jkU8,GFohMKWlxTBYdmSknLCUaw0qERt52 = UighHKAfySm4PWErqJ(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭ஏ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧஐ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ஑"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩஒ"),G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࠳ࠫஓ")
		try:
			gIHYiG0uPKmWC8AycehM57zD3 = dict[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡸࡾࡶࡥࠨஔ")]
			gIHYiG0uPKmWC8AycehM57zD3 = gIHYiG0uPKmWC8AycehM57zD3.replace(EHUAyW2lQfe4LXmhgIGc(u"ࠫ࠰࠭க"),G9G0YqivIfmUWO8K)
			items = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ஖"),gIHYiG0uPKmWC8AycehM57zD3,oo9kuULlebNgpY0Om.DOTALL)
			hEDd8S3OLIugvAc5HRzQkTqM60wW,FF94GpU6MrbZy,SIE35AxPdFfq0DM9Yzt7R4jkU8 = items[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			O3GVKldLzAogpc6EyubBt1XeWC = SIE35AxPdFfq0DM9Yzt7R4jkU8.split(qTVF3icWwGXy5(u"࠭ࠬࠨ஗"))
			hGIQ9NBUw3a1fkjrJtxDsTvZnRyH = G9G0YqivIfmUWO8K
			for XX2Btn97vEfkCjcuWs in O3GVKldLzAogpc6EyubBt1XeWC: hGIQ9NBUw3a1fkjrJtxDsTvZnRyH += XX2Btn97vEfkCjcuWs.split(iAGgjwb7tVMmacRJ(u"ࠧ࠯ࠩ஘"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࠮ࠪங")
			hGIQ9NBUw3a1fkjrJtxDsTvZnRyH = hGIQ9NBUw3a1fkjrJtxDsTvZnRyH.strip(FWqeEzO1i8Dn0ga(u"ࠩ࠯ࠫச"))
			if EHUAyW2lQfe4LXmhgIGc(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ஛") in list(dict.keys()): GFohMKWlxTBYdmSknLCUaw0qERt52 = str(int(dict[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬஜ")])//UighHKAfySm4PWErqJ(u"࠴࠴࠷࠺ෙ"))+yiaeCEwJjOcWA4ZSd5h(u"ࠬࡱࡢࡱࡵࠣࠤࠬ஝")
			else: GFohMKWlxTBYdmSknLCUaw0qERt52 = G9G0YqivIfmUWO8K
			if hEDd8S3OLIugvAc5HRzQkTqM60wW==t2sCrJ0xbgDRkf(u"࠭ࡴࡦࡺࡷࡸࠬஞ"): continue
			elif GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࠭ࠩட") in gIHYiG0uPKmWC8AycehM57zD3:
				hEDd8S3OLIugvAc5HRzQkTqM60wW = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡃ࠮࡚ࠬ஠")
				llZdN9gJCcoODYV8FsjB0 = FF94GpU6MrbZy+zVnkcBX6aJDPRpqyCjhoSZYQbL+GFohMKWlxTBYdmSknLCUaw0qERt52+dict[dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡶ࡭ࡿ࡫ࠧ஡")].split(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡼࠬ஢"))[fdQOo6Hu4B5Rbg]
			elif hEDd8S3OLIugvAc5HRzQkTqM60wW==VHrIziKUDuNGXkMla(u"ࠫࡻ࡯ࡤࡦࡱࠪண"):
				hEDd8S3OLIugvAc5HRzQkTqM60wW = cJSNFCIhymEfx6grGu0M(u"ࠬ࡜ࡩࡥࡧࡲࠫத")
				llZdN9gJCcoODYV8FsjB0 = GFohMKWlxTBYdmSknLCUaw0qERt52+dict[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡳࡪࡼࡨࠫ஥")].split(cJSNFCIhymEfx6grGu0M(u"ࠧࡹࠩ஦"))[fdQOo6Hu4B5Rbg]+zVnkcBX6aJDPRpqyCjhoSZYQbL+dict[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡨࡳࡷࠬ஧")]+UighHKAfySm4PWErqJ(u"ࠩࡩࡴࡸ࠭ந")+zVnkcBX6aJDPRpqyCjhoSZYQbL+FF94GpU6MrbZy
			elif hEDd8S3OLIugvAc5HRzQkTqM60wW==FWqeEzO1i8Dn0ga(u"ࠪࡥࡺࡪࡩࡰࠩன"):
				hEDd8S3OLIugvAc5HRzQkTqM60wW = EHUAyW2lQfe4LXmhgIGc(u"ࠫࡆࡻࡤࡪࡱࠪப")
				llZdN9gJCcoODYV8FsjB0 = GFohMKWlxTBYdmSknLCUaw0qERt52+str(int(dict[dC3PsQJ0Ti28uYlov(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ஫")])/wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠵࠵࠶࠰ේ"))+RVpeGcmPxj9tCnT40Nf216(u"࠭࡫ࡩࡼࠣࠤࠬ஬")+dict[dC3PsQJ0Ti28uYlov(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ஭")]+iqHhJSxdaANDG5rlZm7B(u"ࠨࡥ࡫ࠫம")+zVnkcBX6aJDPRpqyCjhoSZYQbL+FF94GpU6MrbZy
		except:
			fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
			if fEKoHajMCOh!=Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬய"): yyrcMwk6RWmH3xOKQUpGdghiX.stderr.write(fEKoHajMCOh)
		if rxWDdRBIct57i90s(u"ࠪࡨࡺࡸ࠽ࠨர") in dict[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡺࡸ࡬ࠨற")]: ii9h6QFxBUuCeqJODlfYmsI7ZT = round(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠶࠮࠶ො")+float(dict[qTVF3icWwGXy5(u"ࠬࡻࡲ࡭ࠩல")].split(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡤࡶࡴࡀࠫள"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠶ෛ"))[fdQOo6Hu4B5Rbg].split(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࠧࠩழ"),fdQOo6Hu4B5Rbg)[dQ5JhEYolPmy1fvHktMw6NFRxiz]))
		elif CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫவ") in list(dict.keys()): ii9h6QFxBUuCeqJODlfYmsI7ZT = round(yiaeCEwJjOcWA4ZSd5h(u"࠰࠯࠷ෝ")+float(dict[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬஶ")])/wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲࠲࠳࠴ෞ"))
		else: ii9h6QFxBUuCeqJODlfYmsI7ZT = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪ࠴ࠬஷ")
		if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬஸ") not in list(dict.keys()): GFohMKWlxTBYdmSknLCUaw0qERt52 = dict[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡹࡩࡻࡧࠪஹ")].split(dC3PsQJ0Ti28uYlov(u"࠭ࡸࠨ஺"))[fdQOo6Hu4B5Rbg]
		else: GFohMKWlxTBYdmSknLCUaw0qERt52 = str(int(dict[qTVF3icWwGXy5(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ஻")])//RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠳࠳࠶࠹ෟ"))
		if cJSNFCIhymEfx6grGu0M(u"ࠨ࡫ࡱ࡭ࡹ࠭஼") not in list(dict.keys()): dict[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩ࡬ࡲ࡮ࡺࠧ஽")] = VHrIziKUDuNGXkMla(u"ࠪ࠴࠲࠶ࠧா")
		dict[VHrIziKUDuNGXkMla(u"ࠫࡹ࡯ࡴ࡭ࡧࠪி")] = hEDd8S3OLIugvAc5HRzQkTqM60wW+DTF3Lwy9etRH8mI(u"ࠬࡀࠠࠡࠩீ")+llZdN9gJCcoODYV8FsjB0+dC3PsQJ0Ti28uYlov(u"࠭ࠠࠡࠪࠪு")+hGIQ9NBUw3a1fkjrJtxDsTvZnRyH+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧ࠭ࠩூ")+dict[ssGdubC4mngM9D5SRc3Ye(u"ࠨ࡫ࡷࡥ࡬࠭௃")]+DTF3Lwy9etRH8mI(u"ࠩࠬࠫ௄")
		dict[iqHhJSxdaANDG5rlZm7B(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ௅")] = llZdN9gJCcoODYV8FsjB0.split(zVnkcBX6aJDPRpqyCjhoSZYQbL)[dQ5JhEYolPmy1fvHktMw6NFRxiz].split(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡰࡨࡰࡴࠩெ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		dict[jR9YtmsgDX8nTQlMb6G3(u"ࠬࡺࡹࡱࡧ࠵ࠫே")] = hEDd8S3OLIugvAc5HRzQkTqM60wW
		dict[ETNq5t4MYngSsbfFD8J0v(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨை")] = FF94GpU6MrbZy
		dict[cjbAkCIinvs(u"ࠧࡤࡱࡧࡩࡨࡹࠧ௉")] = SIE35AxPdFfq0DM9Yzt7R4jkU8
		dict[RVpeGcmPxj9tCnT40Nf216(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪொ")] = ii9h6QFxBUuCeqJODlfYmsI7ZT
		dict[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪோ")] = GFohMKWlxTBYdmSknLCUaw0qERt52
		TexbdHpu74Vm2jWLXiQ08qSFYJsK.append(dict)
	GeARD6l8bXQ3Mm,seI2YgPWEnGNMT0Bc7tbLOAziru5,LdhPxziYoFk9HrUO2VKS48y5wa6Q,jjqgdylsWviUaoLZDReB7ICfx3cE0,edcHF2hiBUkCtWKM3wEml = [],[],[],[],[]
	wxyX5uSk0VmIsgGbChK2MJOTpWRqA,pRGW9mgNc3AO6vd7HFaw,r4aBLWqDyJYveInVfZ1hF,VzWE5AbHiuJ4TKN3UGd2,VVozbHQi26FNxJwrRDdjGyeIsZEu3 = [],[],[],[],[]
	for GGyBK21qfQkXd8WVhHZonxtFsN in SzuwNkdcoIqvxyLh9mQADBCpa:
		if not GGyBK21qfQkXd8WVhHZonxtFsN: continue
		dict = {}
		dict[ssGdubC4mngM9D5SRc3Ye(u"ࠪࡸࡾࡶࡥ࠳ࠩௌ")] = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡆ࠱ࡖࠨ்")
		dict[DTF3Lwy9etRH8mI(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௎")] = cJSNFCIhymEfx6grGu0M(u"࠭࡭ࡱࡦࠪ௏")
		dict[dC3PsQJ0Ti28uYlov(u"ࠧࡵ࡫ࡷࡰࡪ࠭ௐ")] = dict[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡶࡼࡴࡪ࠸ࠧ௑")]+RVpeGcmPxj9tCnT40Nf216(u"ࠩ࠽ࠤࠥ࠭௒")+dict[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ௓")]+zVnkcBX6aJDPRpqyCjhoSZYQbL+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫั๎ฯสࠢำ็๏ฯࠧ௔")
		dict[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡻࡲ࡭ࠩ௕")] = GGyBK21qfQkXd8WVhHZonxtFsN
		dict[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ௖")] = yiaeCEwJjOcWA4ZSd5h(u"ࠧ࠱ࠩௗ")
		dict[cJSNFCIhymEfx6grGu0M(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௘")] = cjbAkCIinvs(u"ࠩ࠴࠵࠶࠸࠲࠳࠵࠶࠷ࠬ௙")
		TexbdHpu74Vm2jWLXiQ08qSFYJsK.append(dict)
	for ddOt4eC71u in QQHcC6EW7kyOlZYAu8FwD1nd59zpN:
		if not ddOt4eC71u: continue
		R4RX2OvJ5pnt,RJeLopO9taYQqD85MIj1dHX7Tv6s = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,ddOt4eC71u)
		bFAJwQ4K2mPDNE5TIy = list(zip(R4RX2OvJ5pnt,RJeLopO9taYQqD85MIj1dHX7Tv6s))
		for title,Y6YdkAMluFbwx in bFAJwQ4K2mPDNE5TIy:
			dict = {}
			dict[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡸࡾࡶࡥ࠳ࠩ௚")] = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡆ࠱ࡖࠨ௛")
			dict[bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௜")] = rxWDdRBIct57i90s(u"࠭࡭࠴ࡷ࠻ࠫ௝")
			dict[iqHhJSxdaANDG5rlZm7B(u"ࠧࡶࡴ࡯ࠫ௞")] = Y6YdkAMluFbwx
			if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨ࡭ࡥࡴࡸ࠭௟") in title: dict[rxWDdRBIct57i90s(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ௠")] = title.split(ssGdubC4mngM9D5SRc3Ye(u"ࠪ࡯ࡧࡶࡳࠨ௡"))[dQ5JhEYolPmy1fvHktMw6NFRxiz].rsplit(zVnkcBX6aJDPRpqyCjhoSZYQbL)[-fdQOo6Hu4B5Rbg]
			else: dict[DTF3Lwy9etRH8mI(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௢")] = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬ࠷࠰ࠨ௣")
			if title.count(zVnkcBX6aJDPRpqyCjhoSZYQbL)>fdQOo6Hu4B5Rbg:
				I5chimw4D1okfxlBE2UpbuHJvStsZ = title.rsplit(zVnkcBX6aJDPRpqyCjhoSZYQbL)[-c1R9fnIY4XBDZ]
				if I5chimw4D1okfxlBE2UpbuHJvStsZ.isdigit(): dict[ETNq5t4MYngSsbfFD8J0v(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ௤")] = I5chimw4D1okfxlBE2UpbuHJvStsZ
				else: dict[ssGdubC4mngM9D5SRc3Ye(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ௥")] = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ࠲࠳࠴࠵࠭௦")
			if title==UighHKAfySm4PWErqJ(u"ࠩ࠰࠵ࠬ௧"): dict[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡸ࡮ࡺ࡬ࡦࠩ௨")] = dict[cjbAkCIinvs(u"ࠫࡹࡿࡰࡦ࠴ࠪ௩")]+cjbAkCIinvs(u"ࠬࡀࠠࠡࠩ௪")+dict[dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ௫")]+zVnkcBX6aJDPRpqyCjhoSZYQbL+cjbAkCIinvs(u"ࠧอ๊าอࠥึใ๋หࠪ௬")
			else: dict[cJSNFCIhymEfx6grGu0M(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ௭")] = dict[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡷࡽࡵ࡫࠲ࠨ௮")]+ssGdubC4mngM9D5SRc3Ye(u"ࠪ࠾ࠥࠦࠧ௯")+dict[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭௰")]+zVnkcBX6aJDPRpqyCjhoSZYQbL+dict[t2sCrJ0xbgDRkf(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭௱")]+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭࡫ࡣࡲࡶࠤࠥ࠭௲")+dict[rxWDdRBIct57i90s(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ௳")]
			TexbdHpu74Vm2jWLXiQ08qSFYJsK.append(dict)
	TexbdHpu74Vm2jWLXiQ08qSFYJsK = sorted(TexbdHpu74Vm2jWLXiQ08qSFYJsK,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: int(key[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௴")]))
	if not TexbdHpu74Vm2jWLXiQ08qSFYJsK:
		if not GagwMT6q3oc7UZ2Q:
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡊࡉ࡙࠭௵"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠸ࡶ࡫ࠫ௶"))
			GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		TsWkBdGYqEAHmrx = oo9kuULlebNgpY0Om.findall(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ௷"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		zcbj21qWCFYL4MrS7R = oo9kuULlebNgpY0Om.findall(ssGdubC4mngM9D5SRc3Ye(u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௸"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		eCfQMxBE8j9hYzNU3IVHSp = oo9kuULlebNgpY0Om.findall(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ௹"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		yOmLxKSdh0sHAeQC2Wb = oo9kuULlebNgpY0Om.findall(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ௺"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		QeyRs9FTwZrf8ASa4uLdD6,p5pFzYmB2guQThMwVRsCkiZ1r,uAwhiOgfTnb2aq0y = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		try: QeyRs9FTwZrf8ASa4uLdD6 = qsRUfFwphQXBZEvHPc[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ௻")][iAGgjwb7tVMmacRJ(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ௼")][dC3PsQJ0Ti28uYlov(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ௽")][vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ௾")][wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡸࡵ࡯ࡵࠪ௿")][dQ5JhEYolPmy1fvHktMw6NFRxiz][EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡴࡦࡺࡷࡸࠬఀ")]
		except:
			try: QeyRs9FTwZrf8ASa4uLdD6 = J78cpFkWgLmRws4DrY59HKd6vM[qTVF3icWwGXy5(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫఁ")][yiaeCEwJjOcWA4ZSd5h(u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭ం")][hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪః")][iqHhJSxdaANDG5rlZm7B(u"ࠪࡸ࡮ࡺ࡬ࡦࠩఄ")][t2sCrJ0xbgDRkf(u"ࠫࡷࡻ࡮ࡴࠩఅ")][dQ5JhEYolPmy1fvHktMw6NFRxiz][vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡺࡥࡹࡶࡷࠫఆ")]
			except: pass
		try: p5pFzYmB2guQThMwVRsCkiZ1r = qsRUfFwphQXBZEvHPc[cJSNFCIhymEfx6grGu0M(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪఇ")][ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬఈ")][ssGdubC4mngM9D5SRc3Ye(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩఉ")][bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪఊ")][dQ5JhEYolPmy1fvHktMw6NFRxiz][jR9YtmsgDX8nTQlMb6G3(u"ࠪࡶࡺࡴࡳࠨఋ")][dQ5JhEYolPmy1fvHktMw6NFRxiz][cjbAkCIinvs(u"ࠫࡹ࡫ࡸࡵࡶࠪఌ")]
		except:
			try: p5pFzYmB2guQThMwVRsCkiZ1r = J78cpFkWgLmRws4DrY59HKd6vM[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ఍")][ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫఎ")][wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨఏ")][UighHKAfySm4PWErqJ(u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩఐ")][dQ5JhEYolPmy1fvHktMw6NFRxiz][wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡵࡹࡳࡹࠧ఑")][dQ5JhEYolPmy1fvHktMw6NFRxiz][EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡸࡪࡾࡴࡵࠩఒ")]
			except: pass
		try: uAwhiOgfTnb2aq0y = qsRUfFwphQXBZEvHPc[DTF3Lwy9etRH8mI(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨఓ")][EHUAyW2lQfe4LXmhgIGc(u"ࠬࡸࡥࡢࡵࡲࡲࠬఔ")]
		except:
			try: uAwhiOgfTnb2aq0y = J78cpFkWgLmRws4DrY59HKd6vM[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪక")][UighHKAfySm4PWErqJ(u"ࠧࡳࡧࡤࡷࡴࡴࠧఖ")]
			except: pass
		if TsWkBdGYqEAHmrx or zcbj21qWCFYL4MrS7R or eCfQMxBE8j9hYzNU3IVHSp or yOmLxKSdh0sHAeQC2Wb or QeyRs9FTwZrf8ASa4uLdD6 or p5pFzYmB2guQThMwVRsCkiZ1r or uAwhiOgfTnb2aq0y:
			if   TsWkBdGYqEAHmrx: JPhoBimWUM0Gu2H1Fe9fRv8 = TsWkBdGYqEAHmrx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			elif zcbj21qWCFYL4MrS7R: JPhoBimWUM0Gu2H1Fe9fRv8 = zcbj21qWCFYL4MrS7R[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			elif eCfQMxBE8j9hYzNU3IVHSp: JPhoBimWUM0Gu2H1Fe9fRv8 = eCfQMxBE8j9hYzNU3IVHSp[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			elif yOmLxKSdh0sHAeQC2Wb: JPhoBimWUM0Gu2H1Fe9fRv8 = yOmLxKSdh0sHAeQC2Wb[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			elif QeyRs9FTwZrf8ASa4uLdD6: JPhoBimWUM0Gu2H1Fe9fRv8 = QeyRs9FTwZrf8ASa4uLdD6
			elif p5pFzYmB2guQThMwVRsCkiZ1r: JPhoBimWUM0Gu2H1Fe9fRv8 = p5pFzYmB2guQThMwVRsCkiZ1r
			elif uAwhiOgfTnb2aq0y: JPhoBimWUM0Gu2H1Fe9fRv8 = uAwhiOgfTnb2aq0y
			VVLwjxt0ElhW = JPhoBimWUM0Gu2H1Fe9fRv8.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			IIHPGbkW4f = A7XhkmSYZlidyMt5FpWqTgjNezbnD+UighHKAfySm4PWErqJ(u"ࠨ้ำหࠥอไโ์า๎ํࠦแู๋้้้ࠣไสࠢ࠱࠲ࠥษ่ࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦ࠮࠯ࠢฦ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋ࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥ๐อหษฯࠤู๐มࠡ็ะำิࠦ࠮࠯ࠢฦ์ࠥ๐่ห์๋ฬࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎ูเไࠡษ็ๅ๏ี๊้ࠢส่ว์ࠧగ")+zzGfwLAyN5HTxUoJeaivY
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭ఘ"),IIHPGbkW4f+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡠࡳࡢ࡮ࠨఙ")+ipjCIhwEXsbadR+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫึูวๅห้๋๊้ࠣࠦฬํ์อ࠭చ")+zzGfwLAyN5HTxUoJeaivY+zEgtT9cR6bFp7JXqI5VuhNeP+VVLwjxt0ElhW)
			return iqHhJSxdaANDG5rlZm7B(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧఛ")+VVLwjxt0ElhW,[],[]
		else: return EHUAyW2lQfe4LXmhgIGc(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭జ"),[],[]
	nmRNBDtwqf6YHLSOlu1 = []
	for dict in TexbdHpu74Vm2jWLXiQ08qSFYJsK:
		if dict[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡵࡻࡳࡩ࠷࠭ఝ")]==cJSNFCIhymEfx6grGu0M(u"ࠨࡘ࡬ࡨࡪࡵࠧఞ"):
			GeARD6l8bXQ3Mm.append(dict[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡷ࡭ࡹࡲࡥࠨట")])
			wxyX5uSk0VmIsgGbChK2MJOTpWRqA.append(dict)
		elif dict[dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡸࡾࡶࡥ࠳ࠩఠ")]==FWqeEzO1i8Dn0ga(u"ࠫࡆࡻࡤࡪࡱࠪడ"):
			seI2YgPWEnGNMT0Bc7tbLOAziru5.append(dict[qTVF3icWwGXy5(u"ࠬࡺࡩࡵ࡮ࡨࠫఢ")])
			pRGW9mgNc3AO6vd7HFaw.append(dict)
		elif dict[yiaeCEwJjOcWA4ZSd5h(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨణ")]==t2sCrJ0xbgDRkf(u"ࠧ࡮ࡲࡧࠫత"):
			title = dict[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡶ࡬ࡸࡱ࡫ࠧథ")].replace(FWqeEzO1i8Dn0ga(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩద"),G9G0YqivIfmUWO8K)
			if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫధ") not in list(dict.keys()): GFohMKWlxTBYdmSknLCUaw0qERt52 = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫ࠵࠭న")
			else: GFohMKWlxTBYdmSknLCUaw0qERt52 = dict[t2sCrJ0xbgDRkf(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭఩")]
			nmRNBDtwqf6YHLSOlu1.append([dict,{},title,GFohMKWlxTBYdmSknLCUaw0qERt52])
		else:
			title = dict[iqHhJSxdaANDG5rlZm7B(u"࠭ࡴࡪࡶ࡯ࡩࠬప")].replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡂ࡙࠭࠾ࠥࠦࠧఫ"),G9G0YqivIfmUWO8K)
			if hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩబ") not in list(dict.keys()): GFohMKWlxTBYdmSknLCUaw0qERt52 = RVpeGcmPxj9tCnT40Nf216(u"ࠩ࠳ࠫభ")
			else: GFohMKWlxTBYdmSknLCUaw0qERt52 = dict[cJSNFCIhymEfx6grGu0M(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫమ")]
			nmRNBDtwqf6YHLSOlu1.append([dict,{},title,GFohMKWlxTBYdmSknLCUaw0qERt52])
			LdhPxziYoFk9HrUO2VKS48y5wa6Q.append(title)
			r4aBLWqDyJYveInVfZ1hF.append(dict)
		lpbi2IwVQ9gSvfAP5F8a04o3t1WU = P5VqbRSzjtO4UE1rZaolG67XA
		if ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡨࡵࡤࡦࡥࡶࠫయ") in list(dict.keys()):
			if cJSNFCIhymEfx6grGu0M(u"ࠬࡧࡶ࠱ࠩర") in dict[EHUAyW2lQfe4LXmhgIGc(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ఱ")]: lpbi2IwVQ9gSvfAP5F8a04o3t1WU = kkMuQrLWcEayRm
			elif F7aJYwLMEmxAVRupWf<VHrIziKUDuNGXkMla(u"࠴࠼෠") and jR9YtmsgDX8nTQlMb6G3(u"ࠧࡢࡸࡦࠫల") not in dict[FWqeEzO1i8Dn0ga(u"ࠨࡥࡲࡨࡪࡩࡳࠨళ")] and ssGdubC4mngM9D5SRc3Ye(u"ࠩࡰࡴ࠹ࡧࠧఴ") not in dict[RVpeGcmPxj9tCnT40Nf216(u"ࠪࡧࡴࡪࡥࡤࡵࠪవ")]: lpbi2IwVQ9gSvfAP5F8a04o3t1WU = kkMuQrLWcEayRm
		if lpbi2IwVQ9gSvfAP5F8a04o3t1WU and dict[ETNq5t4MYngSsbfFD8J0v(u"ࠫࡹࡿࡰࡦ࠴ࠪశ")]==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡜ࡩࡥࡧࡲࠫష") and dict[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡩ࡯࡫ࡷࠫస")]!=DTF3Lwy9etRH8mI(u"ࠧ࠱࠯࠳ࠫహ"):
			edcHF2hiBUkCtWKM3wEml.append(dict[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡶ࡬ࡸࡱ࡫ࠧ఺")])
			VVozbHQi26FNxJwrRDdjGyeIsZEu3.append(dict)
		elif lpbi2IwVQ9gSvfAP5F8a04o3t1WU and dict[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡷࡽࡵ࡫࠲ࠨ఻")]==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡅࡺࡪࡩࡰ఼ࠩ") and dict[dC3PsQJ0Ti28uYlov(u"ࠫ࡮ࡴࡩࡵࠩఽ")]!=wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬ࠶࠭࠱ࠩా"):
			jjqgdylsWviUaoLZDReB7ICfx3cE0.append(dict[qTVF3icWwGXy5(u"࠭ࡴࡪࡶ࡯ࡩࠬి")])
			VzWE5AbHiuJ4TKN3UGd2.append(dict)
	for YACKghoSBVQOZP in VzWE5AbHiuJ4TKN3UGd2:
		ffJ5MXCqo9g2Udnt13OZ0 = YACKghoSBVQOZP[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨీ")]
		for YYrizB7vfHuADSGZJXOmc in VVozbHQi26FNxJwrRDdjGyeIsZEu3:
			obfkA7hsyCLGTvpFD0ztixP = YYrizB7vfHuADSGZJXOmc[iAGgjwb7tVMmacRJ(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩు")]
			GFohMKWlxTBYdmSknLCUaw0qERt52 = int(obfkA7hsyCLGTvpFD0ztixP)+int(ffJ5MXCqo9g2Udnt13OZ0)
			title = YYrizB7vfHuADSGZJXOmc[rxWDdRBIct57i90s(u"ࠩࡷ࡭ࡹࡲࡥࠨూ")].replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬృ"),FWqeEzO1i8Dn0ga(u"ࠫࡲࡶࡤࠡࠢࠪౄ"))
			title = title.replace(YYrizB7vfHuADSGZJXOmc[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ౅")]+zVnkcBX6aJDPRpqyCjhoSZYQbL,G9G0YqivIfmUWO8K)
			title = title.replace(obfkA7hsyCLGTvpFD0ztixP+dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭࡫ࡣࡲࡶࠫె"),str(GFohMKWlxTBYdmSknLCUaw0qERt52)+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࡬ࡤࡳࡷࠬే"))
			title = title+UighHKAfySm4PWErqJ(u"ࠨࠪࠪై")+YACKghoSBVQOZP[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡷ࡭ࡹࡲࡥࠨ౉")].split(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࠬࠬొ"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
			nmRNBDtwqf6YHLSOlu1.append([YYrizB7vfHuADSGZJXOmc,YACKghoSBVQOZP,title,GFohMKWlxTBYdmSknLCUaw0qERt52])
	f91aHEqdGAPIT7nOyoNmvKMwF = []
	for stream in nmRNBDtwqf6YHLSOlu1:
		YYrizB7vfHuADSGZJXOmc,YACKghoSBVQOZP,title,GFohMKWlxTBYdmSknLCUaw0qERt52 = stream
		y4yxmRhoMiVG5B0IzZDPWvlnA3 = title[:c1R9fnIY4XBDZ]
		if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫี้๊สࠩో") in title: y4yxmRhoMiVG5B0IzZDPWvlnA3 += hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬ࠱ࠧౌ")
		f91aHEqdGAPIT7nOyoNmvKMwF.append([stream,y4yxmRhoMiVG5B0IzZDPWvlnA3,int(GFohMKWlxTBYdmSknLCUaw0qERt52)])
	KzfT6yMiWdxNpaVDFckqHu = kkMuQrLWcEayRm
	TJIV6vCDtLq8OeySPmBW = idRsI1pxWEXFaL(s5slfAmHkUtMR3WSKY1ZTX,f91aHEqdGAPIT7nOyoNmvKMwF)
	if TJIV6vCDtLq8OeySPmBW:
		cU6gZ1vnSxs,buihV7mWKQoXrA81dzHS9ngF0,title,GFohMKWlxTBYdmSknLCUaw0qERt52 = TJIV6vCDtLq8OeySPmBW[EHUAyW2lQfe4LXmhgIGc(u"࠴෡")][EHUAyW2lQfe4LXmhgIGc(u"࠴෡")]
		l1BGb7Vk2HMw30j = cU6gZ1vnSxs[UighHKAfySm4PWErqJ(u"࠭ࡵࡳ࡮్ࠪ")]
		if FWqeEzO1i8Dn0ga(u"ࠧ࡮ࡲࡧࠫ౎") in title and l1BGb7Vk2HMw30j!=GGyBK21qfQkXd8WVhHZonxtFsN: KzfT6yMiWdxNpaVDFckqHu = P5VqbRSzjtO4UE1rZaolG67XA
		QUsyx762VbAXRPzMNrdYcG = title
	else:
		qZaHeAK1miL3j4GI = idRsI1pxWEXFaL(s5slfAmHkUtMR3WSKY1ZTX,f91aHEqdGAPIT7nOyoNmvKMwF,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠶࠻࠰࠱෢"))
		qZaHeAK1miL3j4GI,eEnR986p4Iyq1KFtrcaMis,zAabXCwySkVK2Y91Tgpvhs8O75 = zip(*qZaHeAK1miL3j4GI)
		h5E3G1V4yfLHJTj,Mofi2KPukEXIZ,EpDP8t4Vglo2cheq53MnwNGHQK = [],[],dQ5JhEYolPmy1fvHktMw6NFRxiz
		nmRNBDtwqf6YHLSOlu1 = sorted(nmRNBDtwqf6YHLSOlu1, reverse=P5VqbRSzjtO4UE1rZaolG67XA, key=lambda key: float(key[c1R9fnIY4XBDZ]))
		QeOvljhYpsg14I03ca6oFxwHyJ,hh4aNAcUkw76I,si0q7y2Kazn1wmvR9IC4EHONdupThB = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		try: QeOvljhYpsg14I03ca6oFxwHyJ = qsRUfFwphQXBZEvHPc[jR9YtmsgDX8nTQlMb6G3(u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ౏")][FWqeEzO1i8Dn0ga(u"ࠩࡤࡹࡹ࡮࡯ࡳࠩ౐")]
		except:
			try: QeOvljhYpsg14I03ca6oFxwHyJ = J78cpFkWgLmRws4DrY59HKd6vM[RVpeGcmPxj9tCnT40Nf216(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ౑")][t2sCrJ0xbgDRkf(u"ࠫࡦࡻࡴࡩࡱࡵࠫ౒")]
			except: pass
		try: hh4aNAcUkw76I = qsRUfFwphQXBZEvHPc[FWqeEzO1i8Dn0ga(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ౓")][VHrIziKUDuNGXkMla(u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ౔")]
		except:
			try: hh4aNAcUkw76I = J78cpFkWgLmRws4DrY59HKd6vM[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸౕ࠭")][dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧౖࠫ")]
			except: pass
		if QeOvljhYpsg14I03ca6oFxwHyJ and hh4aNAcUkw76I:
			EpDP8t4Vglo2cheq53MnwNGHQK += fdQOo6Hu4B5Rbg
			title = A7XhkmSYZlidyMt5FpWqTgjNezbnD+ssGdubC4mngM9D5SRc3Ye(u"ࠩࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ౗")+QeOvljhYpsg14I03ca6oFxwHyJ+zzGfwLAyN5HTxUoJeaivY
			Y6YdkAMluFbwx = Kkfl8xemuHbd1w3a0ABPcDrN[DTF3Lwy9etRH8mI(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫౘ")][dQ5JhEYolPmy1fvHktMw6NFRxiz]+t2sCrJ0xbgDRkf(u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧౙ")+hh4aNAcUkw76I
			h5E3G1V4yfLHJTj.append(title)
			Mofi2KPukEXIZ.append(Y6YdkAMluFbwx)
			try: si0q7y2Kazn1wmvR9IC4EHONdupThB = qsRUfFwphQXBZEvHPc[rxWDdRBIct57i90s(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫౚ")][dC3PsQJ0Ti28uYlov(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ౛")][t2sCrJ0xbgDRkf(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ౜")][-fdQOo6Hu4B5Rbg][cJSNFCIhymEfx6grGu0M(u"ࠨࡷࡵࡰࠬౝ")]
			except:
				try: si0q7y2Kazn1wmvR9IC4EHONdupThB = J78cpFkWgLmRws4DrY59HKd6vM[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ౞")][hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠭౟")][hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨౠ")][-fdQOo6Hu4B5Rbg][cJSNFCIhymEfx6grGu0M(u"ࠬࡻࡲ࡭ࠩౡ")]
				except: pass
		for YYrizB7vfHuADSGZJXOmc,YACKghoSBVQOZP,title,GFohMKWlxTBYdmSknLCUaw0qERt52 in qZaHeAK1miL3j4GI:
			h5E3G1V4yfLHJTj.append(title) ; Mofi2KPukEXIZ.append(DTF3Lwy9etRH8mI(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧౢ"))
		if LdhPxziYoFk9HrUO2VKS48y5wa6Q: h5E3G1V4yfLHJTj.append(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩౣ")) ; Mofi2KPukEXIZ.append(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࡯ࡸࡼࡪࡪࠧ౤"))
		if nmRNBDtwqf6YHLSOlu1: h5E3G1V4yfLHJTj.append(EHUAyW2lQfe4LXmhgIGc(u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭౥")) ; Mofi2KPukEXIZ.append(dC3PsQJ0Ti28uYlov(u"ࠪࡥࡱࡲࠧ౦"))
		if edcHF2hiBUkCtWKM3wEml: h5E3G1V4yfLHJTj.append(VHrIziKUDuNGXkMla(u"ࠫฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ౧")) ; Mofi2KPukEXIZ.append(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡳࡰࡥࠩ౨"))
		if GeARD6l8bXQ3Mm: h5E3G1V4yfLHJTj.append(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭౩")) ; Mofi2KPukEXIZ.append(jR9YtmsgDX8nTQlMb6G3(u"ࠧࡷ࡫ࡧࡩࡴ࠭౪"))
		if seI2YgPWEnGNMT0Bc7tbLOAziru5: h5E3G1V4yfLHJTj.append(t2sCrJ0xbgDRkf(u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨ౫")) ; Mofi2KPukEXIZ.append(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡤࡹࡩ࡯࡯ࠨ౬"))
		while P5VqbRSzjtO4UE1rZaolG67XA:
			PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(i5FubIlqEramYSJW7f4NTHdMp, h5E3G1V4yfLHJTj)
			if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg: return DTF3Lwy9etRH8mI(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ౭"),[],[]
			elif PXeEIRkdShOGm45lbLJc2B38s==dQ5JhEYolPmy1fvHktMw6NFRxiz and QeOvljhYpsg14I03ca6oFxwHyJ:
				Y6YdkAMluFbwx = Mofi2KPukEXIZ[PXeEIRkdShOGm45lbLJc2B38s]
				yyjYbUs0dO9LCP = yyrcMwk6RWmH3xOKQUpGdghiX.argv[dQ5JhEYolPmy1fvHktMw6NFRxiz]+RVpeGcmPxj9tCnT40Nf216(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫ౮")+SSX6oT0lADZhKRImPvCHFkYJs(QeOvljhYpsg14I03ca6oFxwHyJ)+yiaeCEwJjOcWA4ZSd5h(u"ࠬࠬࡵࡳ࡮ࡀࠫ౯")+Y6YdkAMluFbwx
				if si0q7y2Kazn1wmvR9IC4EHONdupThB: yyjYbUs0dO9LCP = yyjYbUs0dO9LCP+qTVF3icWwGXy5(u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧ౰")+SSX6oT0lADZhKRImPvCHFkYJs(si0q7y2Kazn1wmvR9IC4EHONdupThB)
				oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(yiaeCEwJjOcWA4ZSd5h(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ౱")+yyjYbUs0dO9LCP+rxWDdRBIct57i90s(u"ࠣࠫࠥ౲"))
				return VHrIziKUDuNGXkMla(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ౳"),[],[]
			z5zsxSmjpGVIoJ6OT = Mofi2KPukEXIZ[PXeEIRkdShOGm45lbLJc2B38s]
			QUsyx762VbAXRPzMNrdYcG = h5E3G1V4yfLHJTj[PXeEIRkdShOGm45lbLJc2B38s]
			if z5zsxSmjpGVIoJ6OT==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡨࡦࡹࡨࠨ౴"):
				l1BGb7Vk2HMw30j = GGyBK21qfQkXd8WVhHZonxtFsN
				break
			elif z5zsxSmjpGVIoJ6OT in [cJSNFCIhymEfx6grGu0M(u"ࠫࡦࡻࡤࡪࡱࠪ౵"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡼࡩࡥࡧࡲࠫ౶"),qTVF3icWwGXy5(u"࠭࡭ࡶࡺࡨࡨࠬ౷")]:
				if z5zsxSmjpGVIoJ6OT==RVpeGcmPxj9tCnT40Nf216(u"ࠧ࡮ࡷࡻࡩࡩ࠭౸"): Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,SeWszYRPoOwXluyErqfC7D = LdhPxziYoFk9HrUO2VKS48y5wa6Q,r4aBLWqDyJYveInVfZ1hF
				elif z5zsxSmjpGVIoJ6OT==rxWDdRBIct57i90s(u"ࠨࡸ࡬ࡨࡪࡵࠧ౹"): Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,SeWszYRPoOwXluyErqfC7D = GeARD6l8bXQ3Mm,wxyX5uSk0VmIsgGbChK2MJOTpWRqA
				elif z5zsxSmjpGVIoJ6OT==iAGgjwb7tVMmacRJ(u"ࠩࡤࡹࡩ࡯࡯ࠨ౺"): Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,SeWszYRPoOwXluyErqfC7D = seI2YgPWEnGNMT0Bc7tbLOAziru5,pRGW9mgNc3AO6vd7HFaw
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪหำะัࠡษ็้้็ࠠࠩࠩ౻")+str(len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO))+DTF3Lwy9etRH8mI(u"๋ࠫࠥไโࠫࠪ౼"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
				if PXeEIRkdShOGm45lbLJc2B38s!=-fdQOo6Hu4B5Rbg:
					l1BGb7Vk2HMw30j = SeWszYRPoOwXluyErqfC7D[PXeEIRkdShOGm45lbLJc2B38s][dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡻࡲ࡭ࠩ౽")]
					QUsyx762VbAXRPzMNrdYcG = Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[PXeEIRkdShOGm45lbLJc2B38s]
					break
			elif z5zsxSmjpGVIoJ6OT==qTVF3icWwGXy5(u"࠭࡭ࡱࡦࠪ౾"):
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧศะอีࠥา่ะหࠣห้฻่าหࠣࠬࠬ౿")+str(len(edcHF2hiBUkCtWKM3wEml))+yiaeCEwJjOcWA4ZSd5h(u"ࠨ่่ࠢๆ࠯ࠧಀ"), edcHF2hiBUkCtWKM3wEml)
				if PXeEIRkdShOGm45lbLJc2B38s!=-fdQOo6Hu4B5Rbg:
					QUsyx762VbAXRPzMNrdYcG = edcHF2hiBUkCtWKM3wEml[PXeEIRkdShOGm45lbLJc2B38s]
					cU6gZ1vnSxs = VVozbHQi26FNxJwrRDdjGyeIsZEu3[PXeEIRkdShOGm45lbLJc2B38s]
					PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(yiaeCEwJjOcWA4ZSd5h(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊อࠤ࠭࠭ಁ")+str(len(jjqgdylsWviUaoLZDReB7ICfx3cE0))+yiaeCEwJjOcWA4ZSd5h(u"ࠪࠤ๊๊แࠪࠩಂ"), jjqgdylsWviUaoLZDReB7ICfx3cE0)
					if PXeEIRkdShOGm45lbLJc2B38s!=-fdQOo6Hu4B5Rbg:
						QUsyx762VbAXRPzMNrdYcG += dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠥ࠱ࠠࠨಃ")+jjqgdylsWviUaoLZDReB7ICfx3cE0[PXeEIRkdShOGm45lbLJc2B38s]
						buihV7mWKQoXrA81dzHS9ngF0 = VzWE5AbHiuJ4TKN3UGd2[PXeEIRkdShOGm45lbLJc2B38s]
						KzfT6yMiWdxNpaVDFckqHu = P5VqbRSzjtO4UE1rZaolG67XA
						break
			elif z5zsxSmjpGVIoJ6OT==qTVF3icWwGXy5(u"ࠬࡧ࡬࡭ࠩ಄"):
				QQn9ameIWqN8JB,u14rWSJU2dKMBN,VYuH9IABGl0JDkT1X3xiSwL,HAdmUQxcEF8s3P6tYqyIuCBOWr0Xz = list(zip(*nmRNBDtwqf6YHLSOlu1))
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭วฯฬิࠤฬ๊ๅๅใࠣࠬࠬಅ")+str(len(VYuH9IABGl0JDkT1X3xiSwL))+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࠡ็็ๅ࠮࠭ಆ"), VYuH9IABGl0JDkT1X3xiSwL)
				if PXeEIRkdShOGm45lbLJc2B38s!=-fdQOo6Hu4B5Rbg:
					QUsyx762VbAXRPzMNrdYcG = VYuH9IABGl0JDkT1X3xiSwL[PXeEIRkdShOGm45lbLJc2B38s]
					cU6gZ1vnSxs = QQn9ameIWqN8JB[PXeEIRkdShOGm45lbLJc2B38s]
					if iqHhJSxdaANDG5rlZm7B(u"ࠨ࡯ࡳࡨࠬಇ") in VYuH9IABGl0JDkT1X3xiSwL[PXeEIRkdShOGm45lbLJc2B38s] and cU6gZ1vnSxs[DTF3Lwy9etRH8mI(u"ࠩࡸࡶࡱ࠭ಈ")]!=GGyBK21qfQkXd8WVhHZonxtFsN:
						buihV7mWKQoXrA81dzHS9ngF0 = u14rWSJU2dKMBN[PXeEIRkdShOGm45lbLJc2B38s]
						KzfT6yMiWdxNpaVDFckqHu = P5VqbRSzjtO4UE1rZaolG67XA
					else: l1BGb7Vk2HMw30j = cU6gZ1vnSxs[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡹࡷࡲࠧಉ")]
					break
			elif z5zsxSmjpGVIoJ6OT==RVpeGcmPxj9tCnT40Nf216(u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬಊ"):
				QQn9ameIWqN8JB,u14rWSJU2dKMBN,VYuH9IABGl0JDkT1X3xiSwL,HAdmUQxcEF8s3P6tYqyIuCBOWr0Xz = list(zip(*qZaHeAK1miL3j4GI))
				cU6gZ1vnSxs = QQn9ameIWqN8JB[PXeEIRkdShOGm45lbLJc2B38s-EpDP8t4Vglo2cheq53MnwNGHQK]
				if UighHKAfySm4PWErqJ(u"ࠬࡳࡰࡥࠩಋ") in VYuH9IABGl0JDkT1X3xiSwL[PXeEIRkdShOGm45lbLJc2B38s-EpDP8t4Vglo2cheq53MnwNGHQK] and cU6gZ1vnSxs[FWqeEzO1i8Dn0ga(u"࠭ࡵࡳ࡮ࠪಌ")]!=GGyBK21qfQkXd8WVhHZonxtFsN:
					buihV7mWKQoXrA81dzHS9ngF0 = u14rWSJU2dKMBN[PXeEIRkdShOGm45lbLJc2B38s-EpDP8t4Vglo2cheq53MnwNGHQK]
					KzfT6yMiWdxNpaVDFckqHu = P5VqbRSzjtO4UE1rZaolG67XA
				else: l1BGb7Vk2HMw30j = cU6gZ1vnSxs[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡶࡴ࡯ࠫ಍")]
				QUsyx762VbAXRPzMNrdYcG = VYuH9IABGl0JDkT1X3xiSwL[PXeEIRkdShOGm45lbLJc2B38s-EpDP8t4Vglo2cheq53MnwNGHQK]
				break
	if KzfT6yMiWdxNpaVDFckqHu:
		qCNFOBaplrbyL = int(cU6gZ1vnSxs[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪಎ")])
		ihVvL9W8qDz5UE = int(buihV7mWKQoXrA81dzHS9ngF0[cjbAkCIinvs(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫಏ")])
		ii9h6QFxBUuCeqJODlfYmsI7ZT = str(max(qCNFOBaplrbyL,ihVvL9W8qDz5UE))
		yyQ0TiFp5r7HAKEDc = cU6gZ1vnSxs[cjbAkCIinvs(u"ࠪࡹࡷࡲࠧಐ")].replace(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࠫ࠭಑"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࠬࡡ࡮ࡲ࠾ࠫಒ"))
		daqnQUf95hmJ2W1ul0YwvV3zFyk = buihV7mWKQoXrA81dzHS9ngF0[rxWDdRBIct57i90s(u"࠭ࡵࡳ࡮ࠪಓ")].replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࠧࠩಔ"),yiaeCEwJjOcWA4ZSd5h(u"ࠨࠨࡤࡱࡵࡁࠧಕ"))
		mpd = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩ࠿ࡑࡕࡊࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩಖ")+ii9h6QFxBUuCeqJODlfYmsI7ZT+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡗࠧࡄ࡜࡯ࠩಗ")
		mpd += iqHhJSxdaANDG5rlZm7B(u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨಘ")
		mpd += vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩಙ")+cU6gZ1vnSxs[hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨಚ")]+yiaeCEwJjOcWA4ZSd5h(u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫಛ")+cU6gZ1vnSxs[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡥࡲࡨࡪࡩࡳࠨಜ")]+DTF3Lwy9etRH8mI(u"ࠩࠥࡂࡡࡴࠧಝ")
		mpd += RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨಞ")
		mpd += DTF3Lwy9etRH8mI(u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧಟ")+yyQ0TiFp5r7HAKEDc+DTF3Lwy9etRH8mI(u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫಠ")
		mpd += bneABYmwFUH8GXphg0Kl2Sq(u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫಡ")+cU6gZ1vnSxs[jR9YtmsgDX8nTQlMb6G3(u"ࠧࡪࡰࡧࡩࡽ࠭ಢ")]+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࠤࡁࡠࡳ࠭ಣ")
		mpd += rxWDdRBIct57i90s(u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬತ")+cU6gZ1vnSxs[DTF3Lwy9etRH8mI(u"ࠪ࡭ࡳ࡯ࡴࠨಥ")]+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࠧࠦ࠯࠿࡞ࡱࠫದ")
		mpd += VHrIziKUDuNGXkMla(u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨಧ")
		mpd += CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬನ")
		mpd += wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ಩")
		mpd += RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡧࡵࡥ࡫ࡲ࠳ࠬಪ")+buihV7mWKQoXrA81dzHS9ngF0[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫಫ")]+DTF3Lwy9etRH8mI(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧಬ")+buihV7mWKQoXrA81dzHS9ngF0[cJSNFCIhymEfx6grGu0M(u"ࠫࡨࡵࡤࡦࡥࡶࠫಭ")]+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࠨ࠾࡝ࡰࠪಮ")
		mpd += rr7Xolsp4JwjPK3L(u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫಯ")
		mpd += vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪರ")+daqnQUf95hmJ2W1ul0YwvV3zFyk+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧಱ")
		mpd += cjbAkCIinvs(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧಲ")+buihV7mWKQoXrA81dzHS9ngF0[ETNq5t4MYngSsbfFD8J0v(u"ࠪ࡭ࡳࡪࡥࡹࠩಳ")]+bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࠧࡄ࡜࡯ࠩ಴")
		mpd += rr7Xolsp4JwjPK3L(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨವ")+buihV7mWKQoXrA81dzHS9ngF0[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡩ࡯࡫ࡷࠫಶ")]+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧಷ")
		mpd += cjbAkCIinvs(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫಸ")
		mpd += RVpeGcmPxj9tCnT40Nf216(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨಹ")
		mpd += wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ಺")
		mpd += ETNq5t4MYngSsbfFD8J0v(u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ಻")
		mpd += ETNq5t4MYngSsbfFD8J0v(u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴ಼ࠧ")
		if LTze51miOknVcslNF43WSA6vMjYZt:
			import http.server as r2UvpI5LlOxtdmqJgfV94s
			import http.client as gQJr3iNzCu9EsAeknS5KPIU7
		else:
			import BaseHTTPServer as r2UvpI5LlOxtdmqJgfV94s
			import httplib as gQJr3iNzCu9EsAeknS5KPIU7
		class q6qnCSvKpyQabMVWHrlz5tiE(r2UvpI5LlOxtdmqJgfV94s.HTTPServer):
			def __init__(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo,ip=CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵࠩಽ"),port=wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠻࠵࠱࠷࠸෣"),mpd=cJSNFCIhymEfx6grGu0M(u"ࠧ࠽ࡀࠪಾ")):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.ip = ip
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.port = port
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.mpd = mpd
				r2UvpI5LlOxtdmqJgfV94s.HTTPServer.__init__(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo,(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.ip,Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.port),LAumDgvlNZIHGa5fkoEnd1q)
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.mpdurl = iAGgjwb7tVMmacRJ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩಿ")+ip+yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠽ࠫೀ")+str(port)+iAGgjwb7tVMmacRJ(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩು")
			def start(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.threads = QnzeRvFJ8G(kkMuQrLWcEayRm)
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.threads.gVHbwiKWqxL(fdQOo6Hu4B5Rbg,Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.K14x7QC63pMtJ0HgX)
			def K14x7QC63pMtJ0HgX(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.keeprunning = P5VqbRSzjtO4UE1rZaolG67XA
				while Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.keeprunning:
					Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.handle_request()
			def stop(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.keeprunning = kkMuQrLWcEayRm
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.QnTSHN1A2J8UL9hZKjR5kO6xBas()
			def LLsX4y0HjPduZt6Sla(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.stop()
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.Uj57k9GZzYH3oh4inb.close()
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.server_close()
			def wBSocNPbvnuO26ylhY7XmIs1g(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo,mpd):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.mpd = mpd
			def QnTSHN1A2J8UL9hZKjR5kO6xBas(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n = gQJr3iNzCu9EsAeknS5KPIU7.HTTPConnection(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.ip+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫ࠿࠭ೂ")+str(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.port))
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n.request(cJSNFCIhymEfx6grGu0M(u"ࠧࡎࡅࡂࡆࠥೃ"), VHrIziKUDuNGXkMla(u"ࠨ࠯ࠣೄ"))
		class LAumDgvlNZIHGa5fkoEnd1q(r2UvpI5LlOxtdmqJgfV94s.BaseHTTPRequestHandler):
			def PCDiOTIYW9RrzwZS0NhmLdg(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.send_response(iqHhJSxdaANDG5rlZm7B(u"࠲࠱࠲෤"))
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.send_header(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭೅"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬೆ"))
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.end_headers()
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.wfile.write(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.yVgLqfcUN1iO4.mpd.encode(f3uIcZ2C6pzbX1JlFBrVOdt))
				SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
				if Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.path==cJSNFCIhymEfx6grGu0M(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨೇ"): Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.yVgLqfcUN1iO4.LLsX4y0HjPduZt6Sla()
				if Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.path==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭ೈ"): Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.yVgLqfcUN1iO4.LLsX4y0HjPduZt6Sla()
			def WWavDPyksE45z(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.send_response(RVpeGcmPxj9tCnT40Nf216(u"࠳࠲࠳෥"))
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.end_headers()
		W4hiRgF5qYa = q6qnCSvKpyQabMVWHrlz5tiE(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࠶࠸࠷࠯࠲࠱࠴࠳࠷ࠧ೉"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠸࠴࠺࠻෦"),mpd)
		l1BGb7Vk2HMw30j = W4hiRgF5qYa.mpdurl
		W4hiRgF5qYa.start()
	else: W4hiRgF5qYa = G9G0YqivIfmUWO8K
	if LTze51miOknVcslNF43WSA6vMjYZt: DiOU9ahITqonKzy2e7HJbx,xP0VJi8OkNTBAEWen5av6ZI7qs9gU4 = G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡢࡴࠨೊ")
	else: DiOU9ahITqonKzy2e7HJbx,xP0VJi8OkNTBAEWen5av6ZI7qs9gU4 = iqHhJSxdaANDG5rlZm7B(u"࠭࡜ࡵࠩೋ"),G9G0YqivIfmUWO8K
	p2Q7lZwE5kFqa8KxLbVND = DiOU9ahITqonKzy2e7HJbx+VHrIziKUDuNGXkMla(u"ࠧࡂࡷࡧ࡭ࡴࡀࠠ࡜ࠢࠪೌ")+buihV7mWKQoXrA81dzHS9ngF0[ssGdubC4mngM9D5SRc3Ye(u"ࠨࡷࡵࡰ್ࠬ")]+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࠣࡡࡡࡴ࡜ࡵ࡞ࡷࠫ೎")+xP0VJi8OkNTBAEWen5av6ZI7qs9gU4+EHUAyW2lQfe4LXmhgIGc(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭೏")+cU6gZ1vnSxs[jR9YtmsgDX8nTQlMb6G3(u"ࠫࡺࡸ࡬ࠨ೐")]+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࠦ࡝ࠨ೑") if KzfT6yMiWdxNpaVDFckqHu else DiOU9ahITqonKzy2e7HJbx+cjbAkCIinvs(u"࠭ࡁࠬࡘ࠽ࠤࡠࠦࠧ೒")+l1BGb7Vk2HMw30j+rxWDdRBIct57i90s(u"ࠧࠡ࡟ࠪ೓")
	vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+rr7Xolsp4JwjPK3L(u"ࠨ࡞ࡷࡔࡱࡧࡹࡪࡰࡪࠤࡘࡺࡲࡦࡣࡰ࠾ࠥࡡࠠࠨ೔")+QUsyx762VbAXRPzMNrdYcG+RVpeGcmPxj9tCnT40Nf216(u"ࠩࠣࡡࠥࠦࠠࠨೕ")+p2Q7lZwE5kFqa8KxLbVND+RVpeGcmPxj9tCnT40Nf216(u"ࠪࠫೖ"))
	if not l1BGb7Vk2HMw30j: return FWqeEzO1i8Dn0ga(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ೗"),[],[]
	return G9G0YqivIfmUWO8K,[QUsyx762VbAXRPzMNrdYcG],[[l1BGb7Vk2HMw30j,r7ry096dBnxu,W4hiRgF5qYa]]
def wivyGHKTQXJqt7VBfLM1W9ED(url):
	headers = { ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ೘") : G9G0YqivIfmUWO8K }
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡈࡏࡃ࠯࠴ࡷࡹ࠭೙"))
	items = oo9kuULlebNgpY0Om.findall(rr7Xolsp4JwjPK3L(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࡼࠪ࡞ࢀࠫ೚"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	items = set(items)
	items = sorted(items, reverse=P5VqbRSzjtO4UE1rZaolG67XA, key=lambda key: key[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU])
	R4RX2OvJ5pnt,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,RJeLopO9taYQqD85MIj1dHX7Tv6s,ODnaR0N8UHv7Twy6jS = [],[],[],[]
	if not items: return RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ೛"),[],[]
	for Y6YdkAMluFbwx,HHFwtdVPy2OZ,G6XbgFWwaiq in items:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ೜"),cJSNFCIhymEfx6grGu0M(u"ࠪ࡬ࡹࡺࡰ࠻ࠩೝ"))
		if CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪೞ") in Y6YdkAMluFbwx:
			R4RX2OvJ5pnt,RJeLopO9taYQqD85MIj1dHX7Tv6s = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,Y6YdkAMluFbwx)
			ODnaR0N8UHv7Twy6jS = ODnaR0N8UHv7Twy6jS + RJeLopO9taYQqD85MIj1dHX7Tv6s
			if R4RX2OvJ5pnt[dQ5JhEYolPmy1fvHktMw6NFRxiz]==iqHhJSxdaANDG5rlZm7B(u"ࠬ࠳࠱ࠨ೟"): Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ำ๋ำไีࠥิวึࠩೠ")+qTVF3icWwGXy5(u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨೡ"))
			else:
				for title in R4RX2OvJ5pnt:
					Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨีํีๆืࠠฯษุࠫೢ")+wKBSo48e5PYtn63DpiG+title)
		else:
			title = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩึ๎ึ็ัࠡะสูࠬೣ")+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭೤")+G6XbgFWwaiq
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
	return G9G0YqivIfmUWO8K,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
def BBkCNjPeRKa149q6pUOyz75E(url,GagwMT6q3oc7UZ2Q):
	GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,pSIPMUG8AVZDRQBFfN7ub24E,EsHlvk9Zn2tIgU7KRLwGaNQbCcjB,dsGzqX4k0a8RLyc = [],[],[],[],[]
	if ssGdubC4mngM9D5SRc3Ye(u"ࠫࡸࡺࡲࠨ೥") not in str(type(GagwMT6q3oc7UZ2Q)): GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.decode(f3uIcZ2C6pzbX1JlFBrVOdt,ssGdubC4mngM9D5SRc3Ye(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ೦"))
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೧"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx and not Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]): Y6YdkAMluFbwx = []
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭೨"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx and not Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]): Y6YdkAMluFbwx = []
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೩"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx and not Ig4jFuXGfUQeCn6wlB8(Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]): Y6YdkAMluFbwx = []
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		title = Y6YdkAMluFbwx.rsplit(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩ࠱ࠫ೪"),RVpeGcmPxj9tCnT40Nf216(u"࠴෧"))[fdQOo6Hu4B5Rbg]
		GGoLgj5BFbWI.append(title)
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	else:
		cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰ࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪࠩ೫"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cUE5uH8hAtOmTp: cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠫࡻࡧࡲࠡࡵࡲࡹࡷࡩࡥࡴࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧ೬"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cUE5uH8hAtOmTp: cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡼࡡࡳࠢ࡭ࡻࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ೭"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cUE5uH8hAtOmTp: cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡶࡢࡴࠣࡴࡱࡧࡹࡦࡴࠣࡁࠥ࠴ࠪࡀ࡞ࠫࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮ࡢࠩࠨ೮"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cUE5uH8hAtOmTp:
			cUE5uH8hAtOmTp = cUE5uH8hAtOmTp[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.sub(vCmnFshSi4flecXIY2gy38G0DJw(u"ࡲࠨࠪ࡞ࡠࢀࡢࠬ࡞࡝࡟ࡸࡡࡹ࡜࡯࡞ࡵࡡ࠯࠯ࠨ࡝ࡹ࠮࡟ࡡࡺ࡜ࡴ࡟࠭࠭࠿࠭೯"),iAGgjwb7tVMmacRJ(u"ࡳࠩ࡟࠵ࠧࡢ࠲ࠣ࠼ࠪ೰"),cUE5uH8hAtOmTp)
			cUE5uH8hAtOmTp = bRCSwcA89e4J7pqdays5PxGiD2(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡧ࡭ࡨࡺࠧೱ"),cUE5uH8hAtOmTp)
			if isinstance(cUE5uH8hAtOmTp,dict): cUE5uH8hAtOmTp = [cUE5uH8hAtOmTp]
			for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
				Jwq9DNp1Qg48OFEIlaji,Y6YdkAMluFbwx = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
				if isinstance(BN1KdkzCmvshw,dict):
					keys = list(BN1KdkzCmvshw.keys())
					if   bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡸࡾࡶࡥࠨೲ") in keys: Jwq9DNp1Qg48OFEIlaji = str(BN1KdkzCmvshw[dC3PsQJ0Ti28uYlov(u"ࠫࡹࡿࡰࡦࠩೳ")])
					if   wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬ࡬ࡩ࡭ࡧࠪ೴") in keys: Y6YdkAMluFbwx = BN1KdkzCmvshw[UighHKAfySm4PWErqJ(u"࠭ࡦࡪ࡮ࡨࠫ೵")]
					elif dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡩ࡮ࡶࠫ೶") in keys: Y6YdkAMluFbwx = BN1KdkzCmvshw[bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡪ࡯ࡷࠬ೷")]
					elif wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡶࡶࡨ࠭೸") in keys: Y6YdkAMluFbwx = BN1KdkzCmvshw[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡷࡷࡩࠧ೹")]
					if   cjbAkCIinvs(u"ࠫࡱࡧࡢࡦ࡮ࠪ೺") in keys: title = str(BN1KdkzCmvshw[cjbAkCIinvs(u"ࠬࡲࡡࡣࡧ࡯ࠫ೻")])
					elif dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬ೼") in keys: title = str(BN1KdkzCmvshw[iqHhJSxdaANDG5rlZm7B(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭೽")])
					elif EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࠰ࠪ೾") in Y6YdkAMluFbwx: title = Y6YdkAMluFbwx.rsplit(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࠱ࠫ೿"),bneABYmwFUH8GXphg0Kl2Sq(u"࠵෨"))[fdQOo6Hu4B5Rbg]
					else: title = Y6YdkAMluFbwx
				elif isinstance(BN1KdkzCmvshw,str):
					Y6YdkAMluFbwx = BN1KdkzCmvshw
					title = Y6YdkAMluFbwx.rsplit(yiaeCEwJjOcWA4ZSd5h(u"ࠪ࠲ࠬഀ"),iAGgjwb7tVMmacRJ(u"࠶෩"))[fdQOo6Hu4B5Rbg]
				if fdQOo6Hu4B5Rbg:
					GGoLgj5BFbWI.append(title+zVnkcBX6aJDPRpqyCjhoSZYQbL+Jwq9DNp1Qg48OFEIlaji)
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	for Y6YdkAMluFbwx,title in zip(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,GGoLgj5BFbWI):
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡡࡢ࠯ࠨഁ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ࠵ࠧം"))
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,iqHhJSxdaANDG5rlZm7B(u"࠭ࡵࡳ࡮ࠪഃ"))
		TkUSmDLJYy = uCUkPIYFszbV90wSpKqWNOjZ1687Eh()
		if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡩࡶࡷࡴࠬഄ") not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = yVgLqfcUN1iO4+Y6YdkAMluFbwx
		if dC3PsQJ0Ti28uYlov(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧഅ") in Y6YdkAMluFbwx:
			headers = {hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ആ"):TkUSmDLJYy,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫഇ"):yVgLqfcUN1iO4}
			frdGQqEOlet2w3,d3dig8UJyEmWwb91 = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,Y6YdkAMluFbwx,headers)
			EsHlvk9Zn2tIgU7KRLwGaNQbCcjB += d3dig8UJyEmWwb91
			pSIPMUG8AVZDRQBFfN7ub24E += frdGQqEOlet2w3
		else:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪഈ")+TkUSmDLJYy+FWqeEzO1i8Dn0ga(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨഉ")+yVgLqfcUN1iO4
			EsHlvk9Zn2tIgU7KRLwGaNQbCcjB.append(Y6YdkAMluFbwx)
			pSIPMUG8AVZDRQBFfN7ub24E.append(title)
	lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = G9G0YqivIfmUWO8K,[],[]
	if EsHlvk9Zn2tIgU7KRLwGaNQbCcjB: lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = G9G0YqivIfmUWO8K,pSIPMUG8AVZDRQBFfN7ub24E,EsHlvk9Zn2tIgU7KRLwGaNQbCcjB
	else:
		if rr7Xolsp4JwjPK3L(u"࠭࠼ࠨഊ") not in GagwMT6q3oc7UZ2Q and len(GagwMT6q3oc7UZ2Q)<rr7Xolsp4JwjPK3L(u"࠷࠰࠱෪") and GagwMT6q3oc7UZ2Q: lP8McnNzaX5 = GagwMT6q3oc7UZ2Q
		else:
			msg = oo9kuULlebNgpY0Om.findall(EHUAyW2lQfe4LXmhgIGc(u"ࠧ࠽ࡦ࡬ࡺࠥࡹࡴࡺ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬࡋ࡯࡬ࡦ࠰࠭ࡃ࠮ࡂࠧഋ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if not msg: msg = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡱࡡࡹ࡭ࡩ࡫࡯ࡠࡵࡷࡹࡧࡥࡴࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫഌ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if not msg: msg = oo9kuULlebNgpY0Om.findall(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࠿࡬࠷ࡄࠨࡔࡱࡵࡶࡾ࠴ࠪࡀࠫ࠿ࠫ഍"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if msg: lP8McnNzaX5 = msg[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	return lP8McnNzaX5,GGoLgj5BFbWI,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh
def jnRiIsKz6AZdYUGh3xoXtv5fHM(ulNpx2GSMWhO,url):
	global rrC9AFBSswx0QEiNY8Jbu
	url = url.strip(rr7Xolsp4JwjPK3L(u"ࠪ࠳ࠬഎ"))
	l1RSViQejk8r5LOA4PWwYBX,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = G9G0YqivIfmUWO8K,{}
	headers = {jR9YtmsgDX8nTQlMb6G3(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨഏ"):uCUkPIYFszbV90wSpKqWNOjZ1687Eh()}
	headers[cjbAkCIinvs(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ഐ")] = xWiOjcUrJVdtP4B5Iml(url,EHUAyW2lQfe4LXmhgIGc(u"࠭ࡵࡳ࡮ࠪ഑"))
	headers[RVpeGcmPxj9tCnT40Nf216(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩഒ")] = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠺ࠩഓ")
	headers[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡖࡩࡨ࠳ࡆࡦࡶࡦ࡬࠲ࡊࡥࡴࡶࠪഔ")] = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪക")
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cJSNFCIhymEfx6grGu0M(u"ࠫࡌࡋࡔࠨഖ"),url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,VHrIziKUDuNGXkMla(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧഗ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	T0NSHFMZPgWa2 = D7omduSeM5Gk.code
	if not isinstance(GagwMT6q3oc7UZ2Q,str): GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.decode(f3uIcZ2C6pzbX1JlFBrVOdt,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ഘ"))
	if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭ങ") in GagwMT6q3oc7UZ2Q:
		ytgAme6a3Mi4Wq79Zdc1PDClTIRK = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫച"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if ytgAme6a3Mi4Wq79Zdc1PDClTIRK:
			try: l1RSViQejk8r5LOA4PWwYBX = NbUXSx5TuGC(ytgAme6a3Mi4Wq79Zdc1PDClTIRK[dQ5JhEYolPmy1fvHktMw6NFRxiz])
			except: l1RSViQejk8r5LOA4PWwYBX = G9G0YqivIfmUWO8K
	if yiaeCEwJjOcWA4ZSd5h(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳࠫࠪഛ") in GagwMT6q3oc7UZ2Q:
		ytgAme6a3Mi4Wq79Zdc1PDClTIRK = oo9kuULlebNgpY0Om.findall(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪജ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if ytgAme6a3Mi4Wq79Zdc1PDClTIRK:
			try: l1RSViQejk8r5LOA4PWwYBX = XaMFZPCb7J9tN(ytgAme6a3Mi4Wq79Zdc1PDClTIRK[dQ5JhEYolPmy1fvHktMw6NFRxiz])
			except: l1RSViQejk8r5LOA4PWwYBX = G9G0YqivIfmUWO8K
	ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = GagwMT6q3oc7UZ2Q+l1RSViQejk8r5LOA4PWwYBX
	if rxWDdRBIct57i90s(u"ࠫࠧ࡯ࡤ࠳ࠤࠪഝ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt or wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࠨࡩࡥࠤࠪഞ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt:
		WDrRBjouFt5gdwqlzA9xseQI = url.split(rxWDdRBIct57i90s(u"࠭࠯ࠨട"))[c1R9fnIY4XBDZ].replace(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧഠ"),G9G0YqivIfmUWO8K).replace(cJSNFCIhymEfx6grGu0M(u"ࠨ࠰࡫ࡸࡲࡲࠧഡ"),G9G0YqivIfmUWO8K)
		if iqHhJSxdaANDG5rlZm7B(u"ࠩࠥ࡭ࡩ࠸ࠢࠨഢ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt: QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {iAGgjwb7tVMmacRJ(u"ࠪ࡭ࡩ࠸ࠧണ"):WDrRBjouFt5gdwqlzA9xseQI,dC3PsQJ0Ti28uYlov(u"ࠫࡴࡶࠧത"):yiaeCEwJjOcWA4ZSd5h(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨഥ")}
		elif dC3PsQJ0Ti28uYlov(u"࠭ࠢࡪࡦࠥࠫദ") in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt: QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {iqHhJSxdaANDG5rlZm7B(u"ࠧࡪࡦࠪധ"):WDrRBjouFt5gdwqlzA9xseQI,jR9YtmsgDX8nTQlMb6G3(u"ࠨࡱࡳࠫന"):ETNq5t4MYngSsbfFD8J0v(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬഩ")}
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = headers.copy()
		AAFEPhnMlsH5B3z0gYQWD4j7kUc[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩപ")] = dC3PsQJ0Ti28uYlov(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪഫ")
		WvxUIHz0cMJB = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,rr7Xolsp4JwjPK3L(u"ࠬࡖࡏࡔࡖࠪബ"),url,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨഭ"))
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = WvxUIHz0cMJB.content
	NmILqDokZGTxEOJjYdlwz4vuXtP56U,bUTC0iIRAGqadcr4KVu1n2zFBoMjQt,GylHUOvMgFNZw = BBkCNjPeRKa149q6pUOyz75E(url,ssVw9GhqHbuQD5On3YxeKPWFkgjRJt)
	rrC9AFBSswx0QEiNY8Jbu[ulNpx2GSMWhO] = NmILqDokZGTxEOJjYdlwz4vuXtP56U,bUTC0iIRAGqadcr4KVu1n2zFBoMjQt,GylHUOvMgFNZw,T0NSHFMZPgWa2
	return
rrC9AFBSswx0QEiNY8Jbu,VLeRz0q869AS4x2XKZmhyWIN = {},dQ5JhEYolPmy1fvHktMw6NFRxiz
def ssWwpzyIxZrH08mViTCb2M4LqdkUNa(url):
	global rrC9AFBSswx0QEiNY8Jbu,VLeRz0q869AS4x2XKZmhyWIN
	dsGzqX4k0a8RLyc,threads = [],[]
	VLeRz0q869AS4x2XKZmhyWIN += dC3PsQJ0Ti28uYlov(u"࠱࠱࠲෫")
	R3wc0NjrioZIH4QA = VLeRz0q869AS4x2XKZmhyWIN
	dsGzqX4k0a8RLyc.append([fdQOo6Hu4B5Rbg,url])
	rrC9AFBSswx0QEiNY8Jbu[R3wc0NjrioZIH4QA+fdQOo6Hu4B5Rbg] = [None,None,None,None]
	ifa9GtzjdP = fu19TY0PdM6AZB5.Thread(target=jnRiIsKz6AZdYUGh3xoXtv5fHM,args=(R3wc0NjrioZIH4QA+fdQOo6Hu4B5Rbg,url))
	ifa9GtzjdP.start()
	ifa9GtzjdP.join(jR9YtmsgDX8nTQlMb6G3(u"࠲࠲෬"))
	if not rrC9AFBSswx0QEiNY8Jbu[R3wc0NjrioZIH4QA+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠳෭")][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]:
		XXzvmn7ewM8yBfoxua = url.replace(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨമ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ࠱ࠪയ"))
		mtMexSFLnkwhbAaP9pgDduCRBi2 = oo9kuULlebNgpY0Om.findall(VHrIziKUDuNGXkMla(u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧര"),XXzvmn7ewM8yBfoxua+iAGgjwb7tVMmacRJ(u"ࠪ࠳ࠬറ"),oo9kuULlebNgpY0Om.DOTALL)
		start,Jh2QtvGRVyIsFf3,end = mtMexSFLnkwhbAaP9pgDduCRBi2[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		end = end.strip(iqHhJSxdaANDG5rlZm7B(u"ࠫ࠴࠭ല"))
		Sz9alXdBFJMRGmt4I = len(Jh2QtvGRVyIsFf3)<xsCEkXb6tgrh3195YZ or Jh2QtvGRVyIsFf3 in [GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡬ࡩ࡭ࡧࠪള"),ssGdubC4mngM9D5SRc3Ye(u"࠭ࡶࡪࡦࡨࡳࠬഴ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡷ࡫ࡧࡩࡴ࡫࡭ࡣࡧࡧࠫവ"),FWqeEzO1i8Dn0ga(u"ࠨࡣ࡭ࡥࡽ࠭ശ"),cjbAkCIinvs(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩഷ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࡱ࡮ࡸࡲࡰࡴࠪസ")]
		if not Sz9alXdBFJMRGmt4I: dsGzqX4k0a8RLyc.append([SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU,start+jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬഹ")+Jh2QtvGRVyIsFf3+rr7Xolsp4JwjPK3L(u"ࠬ࠵ࠧഺ")+end])
		if end: dsGzqX4k0a8RLyc.append([c1R9fnIY4XBDZ,start+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࠯ࠨ഻")+Jh2QtvGRVyIsFf3+ETNq5t4MYngSsbfFD8J0v(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ഼")+end])
		if iqHhJSxdaANDG5rlZm7B(u"ࠨ࠰࡫ࡸࡲࡲࠧഽ") in Jh2QtvGRVyIsFf3:
			l7x1EnOd2jSL9ysVPIgT68J4wkfr = Jh2QtvGRVyIsFf3.replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩ࠱࡬ࡹࡳ࡬ࠨാ"),G9G0YqivIfmUWO8K)
			dsGzqX4k0a8RLyc.append([xsCEkXb6tgrh3195YZ,start+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪ࠳ࠬി")+l7x1EnOd2jSL9ysVPIgT68J4wkfr+dC3PsQJ0Ti28uYlov(u"ࠫ࠴࠭ീ")+end])
			dsGzqX4k0a8RLyc.append([vCmnFshSi4flecXIY2gy38G0DJw(u"࠸෮"),start+iAGgjwb7tVMmacRJ(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ു")+l7x1EnOd2jSL9ysVPIgT68J4wkfr+DTF3Lwy9etRH8mI(u"࠭࠯ࠨൂ")+end])
			if end: dsGzqX4k0a8RLyc.append([cJSNFCIhymEfx6grGu0M(u"࠺෯"),start+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧ࠰ࠩൃ")+l7x1EnOd2jSL9ysVPIgT68J4wkfr+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩൄ")+end])
		elif cJSNFCIhymEfx6grGu0M(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ൅") in end:
			dwp0L6yHqXFU = end.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠪ࠲࡭ࡺ࡭࡭ࠩെ"),G9G0YqivIfmUWO8K)
			dsGzqX4k0a8RLyc.append([cjbAkCIinvs(u"࠼෰"),start+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫ࠴࠭േ")+Jh2QtvGRVyIsFf3+t2sCrJ0xbgDRkf(u"ࠬ࠵ࠧൈ")+dwp0L6yHqXFU])
			if not Sz9alXdBFJMRGmt4I: dsGzqX4k0a8RLyc.append([GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠾෱"),start+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ൉")+Jh2QtvGRVyIsFf3+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠰ࠩൊ")+dwp0L6yHqXFU])
			dsGzqX4k0a8RLyc.append([DTF3Lwy9etRH8mI(u"࠹ෲ"),start+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨ࠱ࠪോ")+Jh2QtvGRVyIsFf3+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪൌ")+dwp0L6yHqXFU])
		else:
			if not Sz9alXdBFJMRGmt4I: dsGzqX4k0a8RLyc.append([yiaeCEwJjOcWA4ZSd5h(u"࠲࠲ෳ"),start+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪ࠳്ࠬ")+Jh2QtvGRVyIsFf3+jR9YtmsgDX8nTQlMb6G3(u"ࠫ࠳࡮ࡴ࡮࡮ࠪൎ")])
			if not Sz9alXdBFJMRGmt4I: dsGzqX4k0a8RLyc.append([CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠳࠴෴"),start+yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭൏")+Jh2QtvGRVyIsFf3+yiaeCEwJjOcWA4ZSd5h(u"࠭࠮ࡩࡶࡰࡰࠬ൐")])
			if end: dsGzqX4k0a8RLyc.append([jR9YtmsgDX8nTQlMb6G3(u"࠴࠶෵"),start+ssGdubC4mngM9D5SRc3Ye(u"ࠧ࠰ࠩ൑")+Jh2QtvGRVyIsFf3+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ࠱ࠪ൒")+end+yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ൓")])
			if end: dsGzqX4k0a8RLyc.append([CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠵࠸෶"),start+rxWDdRBIct57i90s(u"ࠪ࠳ࠬൔ")+Jh2QtvGRVyIsFf3+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬൕ")+end+FWqeEzO1i8Dn0ga(u"ࠬ࠴ࡨࡵ࡯࡯ࠫൖ")])
		if Sz9alXdBFJMRGmt4I and end:
			end = end.replace(ssGdubC4mngM9D5SRc3Ye(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧൗ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠰ࠩ൘"))
			dsGzqX4k0a8RLyc.append([RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠶࠺෷"),start+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࠱ࠪ൙")+end])
			dsGzqX4k0a8RLyc.append([ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠷࠵෸"),start+DTF3Lwy9etRH8mI(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ൚")+end])
			if bneABYmwFUH8GXphg0Kl2Sq(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ൛") in end:
				dwp0L6yHqXFU = end.replace(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ൜"),G9G0YqivIfmUWO8K)
				dsGzqX4k0a8RLyc.append([ssGdubC4mngM9D5SRc3Ye(u"࠱࠷෹"),start+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬ࠵ࠧ൝")+dwp0L6yHqXFU])
				dsGzqX4k0a8RLyc.append([wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲࠹෺"),start+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ൞")+dwp0L6yHqXFU])
			else:
				dsGzqX4k0a8RLyc.append([cjbAkCIinvs(u"࠳࠻෻"),start+RVpeGcmPxj9tCnT40Nf216(u"ࠧ࠰ࠩൟ")+end+VHrIziKUDuNGXkMla(u"ࠨ࠰࡫ࡸࡲࡲࠧൠ")])
				dsGzqX4k0a8RLyc.append([hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠴࠽෼"),start+rr7Xolsp4JwjPK3L(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪൡ")+end+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪ࠲࡭ࡺ࡭࡭ࠩൢ")])
		TDlkz6SgJdfBWQb3q42rPNV5Y7hs = []
		for TJMXlg4jb6GzS5ew,Y6YdkAMluFbwx in dsGzqX4k0a8RLyc[fdQOo6Hu4B5Rbg:]:
			rrC9AFBSswx0QEiNY8Jbu[R3wc0NjrioZIH4QA+TJMXlg4jb6GzS5ew] = [None,None,None,None]
			n5uSP9HqxlMdW4zLZVNgU = fu19TY0PdM6AZB5.Thread(target=jnRiIsKz6AZdYUGh3xoXtv5fHM,args=(R3wc0NjrioZIH4QA+TJMXlg4jb6GzS5ew,Y6YdkAMluFbwx))
			n5uSP9HqxlMdW4zLZVNgU.start()
			TDlkz6SgJdfBWQb3q42rPNV5Y7hs.append(n5uSP9HqxlMdW4zLZVNgU)
			SSCU3jdyFn2V.sleep(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠴࠳࠽࠵෽"))
		for n5uSP9HqxlMdW4zLZVNgU in TDlkz6SgJdfBWQb3q42rPNV5Y7hs: n5uSP9HqxlMdW4zLZVNgU.join(bneABYmwFUH8GXphg0Kl2Sq(u"࠶࠶෾"))
	lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,[],[]
	yyEVe85v4Rk7oc01wLjJnQm = []
	for TJMXlg4jb6GzS5ew,Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
		KKfAMVOZ0RjIhYmwg7XSiLkHCuvqr,jjoywfd8hPMqxgIszRv703WGtK,Bidt2DRzjI9,uAdLkX738eyaFES25BWInmTrO = rrC9AFBSswx0QEiNY8Jbu[R3wc0NjrioZIH4QA+TJMXlg4jb6GzS5ew]
		if not ODnaR0N8UHv7Twy6jS and Bidt2DRzjI9: Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = jjoywfd8hPMqxgIszRv703WGtK,Bidt2DRzjI9
		if not lP8McnNzaX5 and KKfAMVOZ0RjIhYmwg7XSiLkHCuvqr: lP8McnNzaX5 = KKfAMVOZ0RjIhYmwg7XSiLkHCuvqr
		if uAdLkX738eyaFES25BWInmTrO: yyEVe85v4Rk7oc01wLjJnQm.append(uAdLkX738eyaFES25BWInmTrO)
	yyEVe85v4Rk7oc01wLjJnQm = list(set(yyEVe85v4Rk7oc01wLjJnQm))
	if not lP8McnNzaX5 and len(yyEVe85v4Rk7oc01wLjJnQm)==cjbAkCIinvs(u"࠷෿"):
		T0NSHFMZPgWa2 = yyEVe85v4Rk7oc01wLjJnQm[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if T0NSHFMZPgWa2!=hhdGMSsBzel96obfEmrwiuLPOvq(u"࠲࠱࠲฀"):
			if T0NSHFMZPgWa2<dQ5JhEYolPmy1fvHktMw6NFRxiz: lP8McnNzaX5 = vCmnFshSi4flecXIY2gy38G0DJw(u"࡛ࠫ࡯ࡤࡦࡱࠣࡴࡦ࡭ࡥ࠰ࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡳࡵࡴࠡࡣࡦࡧࡪࡹࡳࡪࡤ࡯ࡩࠬൣ")
			else:
				lP8McnNzaX5 = iAGgjwb7tVMmacRJ(u"ࠬࡎࡔࡕࡒࠣࡉࡷࡸ࡯ࡳ࠼ࠣࠫ൤")+str(T0NSHFMZPgWa2)
				if LTze51miOknVcslNF43WSA6vMjYZt: import http.client as gQJr3iNzCu9EsAeknS5KPIU7
				else: import httplib as gQJr3iNzCu9EsAeknS5KPIU7
				try: lP8McnNzaX5 += RVpeGcmPxj9tCnT40Nf216(u"࠭ࠠࠩࠢࠪ൥")+gQJr3iNzCu9EsAeknS5KPIU7.responses[T0NSHFMZPgWa2]+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࠡࠫࠪ൦")
				except: pass
	SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
	return lP8McnNzaX5,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS
class TX7RM2FrqDzLCB06tsQlyAx4Z(tDG1bZwX86UPjWEoVOJ.WindowDialog):
	def __init__(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo, *args, **qPNBLdR4xgmZ12H6):
		qgH0WcurSEIRAO765Qep92 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J, iAGgjwb7tVMmacRJ(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ൧"), dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭൨"), wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡥ࡫࠳ࡶ࡮ࡨࠩ൩"))
		FvIxLbrT51E7ekX = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J, Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ൪"), RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ൫"), dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠯ࡲࡱ࡫ࠬ൬"))
		a3bSRqUuT7VFNA1pnLOevHPQkWyo = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J, RVpeGcmPxj9tCnT40Nf216(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ൭"), wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬ൮"), ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡥࡹࡹࡺ࡯࡯ࡨࡲ࠲ࡵࡴࡧࠨ൯"))
		QQRUaFOI0W4AHPnShE8D3jdL = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J, ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭൰"), RVpeGcmPxj9tCnT40Nf216(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨ൱"), t2sCrJ0xbgDRkf(u"ࠬࡨࡵࡵࡶࡲࡲࡳ࡬࠮ࡱࡰࡪࠫ൲"))
		eIYFGwyi5sTq7MgAN4H = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J, rr7Xolsp4JwjPK3L(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ൳"), RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫ൴"), RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡤࡸࡸࡹࡵ࡮ࡣࡩ࠱ࡴࡳ࡭ࠧ൵"))
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelled = kkMuQrLWcEayRm
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chk = [dQ5JhEYolPmy1fvHktMw6NFRxiz] * VHrIziKUDuNGXkMla(u"࠺ก")
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton = [dQ5JhEYolPmy1fvHktMw6NFRxiz] * EHUAyW2lQfe4LXmhgIGc(u"࠻ข")
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate = [kkMuQrLWcEayRm] * iAGgjwb7tVMmacRJ(u"࠼ฃ")
		cYobWKr9imzVdvj, mnOow2El4zeqM3LGVWZN, I6cGgqOiD2XUnLyRPlWhFTu0kVZf, Z1X2wGoKsNe30u8izUDp = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠶࠺࠶ค"), dQ5JhEYolPmy1fvHktMw6NFRxiz, hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠼࠶࠰ฅ"), rr7Xolsp4JwjPK3L(u"࠽࠶࠱ฆ")
		RNwIDhqo4JXKG = cYobWKr9imzVdvj+I6cGgqOiD2XUnLyRPlWhFTu0kVZf//SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
		NIDCW9Gt8peLzT, pC0GYWqcVvnSUaOo4KJzRh, OOA43HwrqbIdkagjGp60xzRFZJX, vrIwiNclUWe0k2Z = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠴࠷࠸จ"), ssGdubC4mngM9D5SRc3Ye(u"࠱࠳࠲ง"), EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷࠳࠴ฉ"), EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷࠳࠴ฉ")
		rDjXHFmu3htyenTiNO56JMc = NIDCW9Gt8peLzT+OOA43HwrqbIdkagjGp60xzRFZJX//SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
		O3VwSfFN8D5BXmbZj, RI5a2Jd1vEgSyA, YQqGldh0txs3oR5DyBc4MWfJg, DDrwVtESmqF6j5JegyGzhKRuTQ3 = t2sCrJ0xbgDRkf(u"࠵࠵࠶ซ"), RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠻࠻࠵ฌ"), EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠴࠹࠵ช"), FWqeEzO1i8Dn0ga(u"࠻࠰ญ")
		VtwUbyXpjKYuh9QGcFf5r4J0S = RNwIDhqo4JXKG-YQqGldh0txs3oR5DyBc4MWfJg-O3VwSfFN8D5BXmbZj//SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
		fCKJv07jPl5ZEDBtmqg6uIx = RNwIDhqo4JXKG+O3VwSfFN8D5BXmbZj//SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
		yUoj5uYXNkOn9c7JWQgzAId, jl8wpoIL7Ai5Ovu, UNEpzxtrZnCJ, ofkzM15RVEtqnUHi92NJGps0b = cjbAkCIinvs(u"࠳࠶࠷ฎ"), wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠴࠲ฏ"), RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠸࠴࠵ฑ"), bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠳ฐ")
		NDqrkGi0FQhLMYE, SYv25xynlfqdXIVsOo, zTg9phq1XUGJs8aouwxC5MlbAZPFr, j2skGwBlA3M5myoLq0iDHQUbE = iAGgjwb7tVMmacRJ(u"࠷࠺࠻ฒ"), FWqeEzO1i8Dn0ga(u"࠷࠱ต"), RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠻࠰࠱ด"), wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠺࠶ณ")
		LkFJDqfTn05hGueRdKWyCOo7E9QSiA = EHUAyW2lQfe4LXmhgIGc(u"࠱࠰࠼ถ")
		cYobWKr9imzVdvj, mnOow2El4zeqM3LGVWZN, I6cGgqOiD2XUnLyRPlWhFTu0kVZf, Z1X2wGoKsNe30u8izUDp = int(cYobWKr9imzVdvj*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(mnOow2El4zeqM3LGVWZN*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(I6cGgqOiD2XUnLyRPlWhFTu0kVZf*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(Z1X2wGoKsNe30u8izUDp*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		NIDCW9Gt8peLzT, pC0GYWqcVvnSUaOo4KJzRh, OOA43HwrqbIdkagjGp60xzRFZJX, vrIwiNclUWe0k2Z = int(NIDCW9Gt8peLzT*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(pC0GYWqcVvnSUaOo4KJzRh*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(OOA43HwrqbIdkagjGp60xzRFZJX*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(vrIwiNclUWe0k2Z*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		VtwUbyXpjKYuh9QGcFf5r4J0S, mD195MdaZtKyTfwoFVHzXi, Zms8i4X5c9qWToP, wZAJxuYq7hsl1of = int(VtwUbyXpjKYuh9QGcFf5r4J0S*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(RI5a2Jd1vEgSyA*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(YQqGldh0txs3oR5DyBc4MWfJg*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(DDrwVtESmqF6j5JegyGzhKRuTQ3*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		fCKJv07jPl5ZEDBtmqg6uIx, ZDsNCTlVgvPLwGyxnQrW2uhm, T0TqevfmxgUMWAGBtLOrIQSj, Cws3kPjo5pFYXRGD6 = int(fCKJv07jPl5ZEDBtmqg6uIx*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(RI5a2Jd1vEgSyA*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(YQqGldh0txs3oR5DyBc4MWfJg*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(DDrwVtESmqF6j5JegyGzhKRuTQ3*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		yUoj5uYXNkOn9c7JWQgzAId, jl8wpoIL7Ai5Ovu, UNEpzxtrZnCJ, ofkzM15RVEtqnUHi92NJGps0b = int(yUoj5uYXNkOn9c7JWQgzAId*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(jl8wpoIL7Ai5Ovu*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(UNEpzxtrZnCJ*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(ofkzM15RVEtqnUHi92NJGps0b*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		NDqrkGi0FQhLMYE, SYv25xynlfqdXIVsOo, zTg9phq1XUGJs8aouwxC5MlbAZPFr, j2skGwBlA3M5myoLq0iDHQUbE = int(NDqrkGi0FQhLMYE*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(SYv25xynlfqdXIVsOo*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(zTg9phq1XUGJs8aouwxC5MlbAZPFr*LkFJDqfTn05hGueRdKWyCOo7E9QSiA), int(j2skGwBlA3M5myoLq0iDHQUbE*LkFJDqfTn05hGueRdKWyCOo7E9QSiA)
		BLzJMEv8TwouSVd2jhN6ftg = tDG1bZwX86UPjWEoVOJ.ControlImage(cYobWKr9imzVdvj, mnOow2El4zeqM3LGVWZN, I6cGgqOiD2XUnLyRPlWhFTu0kVZf, Z1X2wGoKsNe30u8izUDp, qgH0WcurSEIRAO765Qep92)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(BLzJMEv8TwouSVd2jhN6ftg)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.iteration = qPNBLdR4xgmZ12H6.get(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡬ࡸࡪࡸࡡࡵ࡫ࡲࡲࠬ൶"))
		Q1pLWI74hOagmPtXE = ipjCIhwEXsbadR+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪๅา฻ࠠฤ่สࠤส์ำศ่ࠣ์ู้สࠡำ๋ฬํะࠠࠡࠢࠣࠤࠥࠦࠠࠡࠩ൷")+VHrIziKUDuNGXkMla(u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็ࠣࠤࠬ൸")+str(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.iteration)+zzGfwLAyN5HTxUoJeaivY
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.strActionInfo = tDG1bZwX86UPjWEoVOJ.ControlLabel(yUoj5uYXNkOn9c7JWQgzAId, jl8wpoIL7Ai5Ovu, UNEpzxtrZnCJ, ofkzM15RVEtqnUHi92NJGps0b, Q1pLWI74hOagmPtXE, CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬ൹"))
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.strActionInfo)
		M4qkBDatEIf3T = tDG1bZwX86UPjWEoVOJ.ControlImage(NIDCW9Gt8peLzT, pC0GYWqcVvnSUaOo4KJzRh, OOA43HwrqbIdkagjGp60xzRFZJX, vrIwiNclUWe0k2Z, qPNBLdR4xgmZ12H6.get(RVpeGcmPxj9tCnT40Nf216(u"࠭ࡣࡢࡲࡷࡧ࡭ࡧࠧൺ")))
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(M4qkBDatEIf3T)
		eeaxwhNdYpXB3J = ipjCIhwEXsbadR+qPNBLdR4xgmZ12H6.get(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡮ࡵࡪࠫൻ"))+zzGfwLAyN5HTxUoJeaivY
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.strActionInfo = tDG1bZwX86UPjWEoVOJ.ControlLabel(NDqrkGi0FQhLMYE, SYv25xynlfqdXIVsOo, zTg9phq1XUGJs8aouwxC5MlbAZPFr, j2skGwBlA3M5myoLq0iDHQUbE, eeaxwhNdYpXB3J, FWqeEzO1i8Dn0ga(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨർ"))
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.strActionInfo)
		text = ipjCIhwEXsbadR+jR9YtmsgDX8nTQlMb6G3(u"ࠩัีําࠧൽ")+zzGfwLAyN5HTxUoJeaivY
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton = tDG1bZwX86UPjWEoVOJ.ControlButton(VtwUbyXpjKYuh9QGcFf5r4J0S, mD195MdaZtKyTfwoFVHzXi, Zms8i4X5c9qWToP, wZAJxuYq7hsl1of, text, focusTexture=eIYFGwyi5sTq7MgAN4H, noFocusTexture=a3bSRqUuT7VFNA1pnLOevHPQkWyo, alignment=qTVF3icWwGXy5(u"࠴ท"))
		text = ipjCIhwEXsbadR+t2sCrJ0xbgDRkf(u"ࠪหุะๅาษิࠫൾ")+zzGfwLAyN5HTxUoJeaivY
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton = tDG1bZwX86UPjWEoVOJ.ControlButton(fCKJv07jPl5ZEDBtmqg6uIx, ZDsNCTlVgvPLwGyxnQrW2uhm, T0TqevfmxgUMWAGBtLOrIQSj, Cws3kPjo5pFYXRGD6, text, focusTexture=eIYFGwyi5sTq7MgAN4H, noFocusTexture=a3bSRqUuT7VFNA1pnLOevHPQkWyo, alignment=ETNq5t4MYngSsbfFD8J0v(u"࠵ธ"))
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton)
		g4ay6kE9wF0uWN5G7TnX, fftseJxPUpiIwrEK4 = vrIwiNclUWe0k2Z//c1R9fnIY4XBDZ, OOA43HwrqbIdkagjGp60xzRFZJX//c1R9fnIY4XBDZ
		for KT9tdUH3hmiLZCEFz in range(vCmnFshSi4flecXIY2gy38G0DJw(u"࠽น")):
			b3527bNxCPwK1 = KT9tdUH3hmiLZCEFz // c1R9fnIY4XBDZ
			jP9ibz2t4HO3WEYkXrqeF8NxAsLd = KT9tdUH3hmiLZCEFz % c1R9fnIY4XBDZ
			C5S7V2vRkrjWQwzJbMlX3Hmi = NIDCW9Gt8peLzT + (fftseJxPUpiIwrEK4 * jP9ibz2t4HO3WEYkXrqeF8NxAsLd)
			zD3toMiF7ILYCZRrG6Pw = pC0GYWqcVvnSUaOo4KJzRh + (g4ay6kE9wF0uWN5G7TnX * b3527bNxCPwK1)
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chk[KT9tdUH3hmiLZCEFz] = tDG1bZwX86UPjWEoVOJ.ControlImage(C5S7V2vRkrjWQwzJbMlX3Hmi, zD3toMiF7ILYCZRrG6Pw, fftseJxPUpiIwrEK4, g4ay6kE9wF0uWN5G7TnX, FvIxLbrT51E7ekX)
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chk[KT9tdUH3hmiLZCEFz])
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chk[KT9tdUH3hmiLZCEFz].setVisible(kkMuQrLWcEayRm)
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz] = tDG1bZwX86UPjWEoVOJ.ControlButton(C5S7V2vRkrjWQwzJbMlX3Hmi, zD3toMiF7ILYCZRrG6Pw, fftseJxPUpiIwrEK4, g4ay6kE9wF0uWN5G7TnX, str(KT9tdUH3hmiLZCEFz + fdQOo6Hu4B5Rbg), font=wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫൿ"), focusTexture=a3bSRqUuT7VFNA1pnLOevHPQkWyo, noFocusTexture=QQRUaFOI0W4AHPnShE8D3jdL)
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.addControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz])
		for KT9tdUH3hmiLZCEFz in range(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠾บ")):
			lVjzoqvZ0gbS7muwN1GeI2JFWdYi = (KT9tdUH3hmiLZCEFz // c1R9fnIY4XBDZ) * c1R9fnIY4XBDZ
			uecT0dNhWUfHD = lVjzoqvZ0gbS7muwN1GeI2JFWdYi + (KT9tdUH3hmiLZCEFz + fdQOo6Hu4B5Rbg) % c1R9fnIY4XBDZ
			VXn2fD3FlC7tyJU09 = lVjzoqvZ0gbS7muwN1GeI2JFWdYi + (KT9tdUH3hmiLZCEFz - fdQOo6Hu4B5Rbg) % c1R9fnIY4XBDZ
			HZz5TgDR0o8WfqcSLxu4 = (KT9tdUH3hmiLZCEFz - c1R9fnIY4XBDZ) % GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠿ป")
			FrqePNOQ71jMWBGSf9D486 = (KT9tdUH3hmiLZCEFz + c1R9fnIY4XBDZ) % cjbAkCIinvs(u"࠹ผ")
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlRight(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[uecT0dNhWUfHD])
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlLeft(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[VXn2fD3FlC7tyJU09])
			if KT9tdUH3hmiLZCEFz <= SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU:
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlUp(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
			else:
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlUp(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[HZz5TgDR0o8WfqcSLxu4])
			if KT9tdUH3hmiLZCEFz >= iqHhJSxdaANDG5rlZm7B(u"࠷ฝ"):
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlDown(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
			else:
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[KT9tdUH3hmiLZCEFz].controlDown(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[FrqePNOQ71jMWBGSf9D486])
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton.controlLeft(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton.controlRight(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton.controlLeft(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton.controlRight(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton.controlDown(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU])
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton.controlUp(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[VHrIziKUDuNGXkMla(u"࠺พ")])
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton.controlDown(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[dQ5JhEYolPmy1fvHktMw6NFRxiz])
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton.controlUp(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkbutton[qTVF3icWwGXy5(u"࠹ฟ")])
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.setFocus(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton)
	def get(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo):
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.doModal()
		Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.close()
		if not Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelled:
			return [KT9tdUH3hmiLZCEFz for KT9tdUH3hmiLZCEFz in range(UighHKAfySm4PWErqJ(u"࠽ภ")) if Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate[KT9tdUH3hmiLZCEFz]]
	def onControl(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo, DyYeSUlFTQNiG):
		if DyYeSUlFTQNiG.getId() == Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.okbutton.getId() and any(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate):
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.close()
		elif DyYeSUlFTQNiG.getId() == Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelbutton.getId():
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelled = P5VqbRSzjtO4UE1rZaolG67XA
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.close()
		else:
			G6XbgFWwaiq = DyYeSUlFTQNiG.getLabel()
			if G6XbgFWwaiq.isnumeric():
				index = int(G6XbgFWwaiq) - fdQOo6Hu4B5Rbg
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate[index] = not Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate[index]
				Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chk[index].setVisible(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.chkstate[index])
	def onAction(Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo, ybOHG96WcPCBgqU3Z7K8STp24):
		if ybOHG96WcPCBgqU3Z7K8STp24 == EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠶࠶ม"):
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.cancelled = P5VqbRSzjtO4UE1rZaolG67XA
			Xt3c8xK0MCYq7dQuHb1ZeasgnI4Oo.close()
def eP4Y3d7zXWc5nka0ExbliNZf(key,BSAJjHXKpCaq9Y04ym1frVb8iv,url):
	headers = {ssGdubC4mngM9D5SRc3Ye(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭඀"):url,jR9YtmsgDX8nTQlMb6G3(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨඁ"):BSAJjHXKpCaq9Y04ym1frVb8iv}
	kMY6xDK8VAC5g4UWwrjEPFu = ssGdubC4mngM9D5SRc3Ye(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠳ࡦࡶࡩ࠰ࡨࡤࡰࡱࡨࡡࡤ࡭ࡂ࡯ࡂ࠭ං")+key
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,UighHKAfySm4PWErqJ(u"ࠨࡉࡈࡘࠬඃ"),kMY6xDK8VAC5g4UWwrjEPFu,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dC3PsQJ0Ti28uYlov(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠷ࡳࡵࠩ඄"))
	jJ1iOyvCtQxbFeK,iteration = G9G0YqivIfmUWO8K,dQ5JhEYolPmy1fvHktMw6NFRxiz
	while P5VqbRSzjtO4UE1rZaolG67XA:
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = oo9kuULlebNgpY0Om.findall(ssGdubC4mngM9D5SRc3Ye(u"ࠪࠦ࠭࠵ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠱ࡤࡴ࡮࠸࠯ࡱࡣࡼࡰࡴࡧࡤ࡜ࡠࠥࡡ࠰࠯ࠧඅ"), GagwMT6q3oc7UZ2Q)
		iteration += fdQOo6Hu4B5Rbg
		message = oo9kuULlebNgpY0Om.findall(ssGdubC4mngM9D5SRc3Ye(u"ࠫࡁࡲࡡࡣࡧ࡯࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡹ࡫ࡸࡵࠤ࡞ࡢࡃࡣࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮ࡤࡦࡪࡲ࠾ࠨආ"), GagwMT6q3oc7UZ2Q)
		if not message: message = oo9kuULlebNgpY0Om.findall(EHUAyW2lQfe4LXmhgIGc(u"ࠬࡂࡤࡪࡸ࡞ࡢࡃࡣࠫࡤ࡮ࡤࡷࡸࡃࠢࡧࡤࡦ࠱࡮ࡳࡡࡨࡧࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡸࡹࡡࡨࡧ࠰ࡩࡷࡸ࡯ࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨඇ"), GagwMT6q3oc7UZ2Q)
		if not message:
			jJ1iOyvCtQxbFeK = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"࠭ࡲࡦࡣࡧࡳࡳࡲࡹ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨඈ"), GagwMT6q3oc7UZ2Q)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			break
		else:
			message = message[dQ5JhEYolPmy1fvHktMw6NFRxiz]
			QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = QKsd6VmaOnMPCWuqcTyl28JZH7ASjo[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		esG8P3BVihmdxnb = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"ࡲࠨࡰࡤࡱࡪࡃࠢࡤࠤ࡟ࡷ࠰ࡼࡡ࡭ࡷࡨࡁࠧ࠮࡛࡟ࠤࡠ࠯࠮࠭ඉ"), GagwMT6q3oc7UZ2Q)[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		alQbqxTDLV8 = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯ࠨࡷࠬඊ") % (QKsd6VmaOnMPCWuqcTyl28JZH7ASjo.replace(rr7Xolsp4JwjPK3L(u"ࠩࠩࡥࡲࡶ࠻ࠨඋ"), FWqeEzO1i8Dn0ga(u"ࠪࠪࠬඌ")))
		message = oo9kuULlebNgpY0Om.sub(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡁ࠵࠿ࠩࡦ࡬ࡺࢁࡹࡴࡳࡱࡱ࡫࠮ࡡ࡞࠿࡟࠭ࡂࠬඍ"), G9G0YqivIfmUWO8K, message)
		Yeh1jxPQSU = TX7RM2FrqDzLCB06tsQlyAx4Z(captcha=alQbqxTDLV8, msg=message, iteration=iteration)
		puOi0WGTKsSyQDAcJF1r6fgbeEU3R = Yeh1jxPQSU.get()
		if not puOi0WGTKsSyQDAcJF1r6fgbeEU3R: break
		data = {yiaeCEwJjOcWA4ZSd5h(u"ࠬࡩࠧඎ"): esG8P3BVihmdxnb, CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨඏ"): puOi0WGTKsSyQDAcJF1r6fgbeEU3R}
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,t2sCrJ0xbgDRkf(u"ࠧࡑࡑࡖࡘࠬඐ"),kMY6xDK8VAC5g4UWwrjEPFu,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑ࠱࠷ࡴࡤࠨඑ"))
	return jJ1iOyvCtQxbFeK
def g6eVm8UF0WwN4OJ2QXSnCAtTdh1(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬඒ"))
	items = oo9kuULlebNgpY0Om.findall(DTF3Lwy9etRH8mI(u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨඓ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[ items[dQ5JhEYolPmy1fvHktMw6NFRxiz] ]
	else: return Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡐࡔࡇࡄࡔࠩඔ"),[],[]
def QJ5hDgywiAnRoEt17Bkpq2I3(url):
	return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
def es8Y7RjbvJWiFUB05xI4tQZnaS(url):
	yVgLqfcUN1iO4 = url.split(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬ࠵ࠧඕ"))
	eWbB3fKTVY = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࠯ࠨඖ").join(yVgLqfcUN1iO4[dQ5JhEYolPmy1fvHktMw6NFRxiz:c1R9fnIY4XBDZ])
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ඗"))
	items = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ඘"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		gIRLK2jm74q31vs5z,uB9bUF45na,sUcPV0EKIN4iLAQFl7WJdnZ3S,pYRO1cuUqSXANTsfKroJnQ,Xh5wV3Ll7rMTAavHKG1F640U9,wFoMiTvNfO3xcCm2EIQB = items[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		wwLKR5YpyqGu = int(uB9bUF45na) % int(sUcPV0EKIN4iLAQFl7WJdnZ3S) + int(pYRO1cuUqSXANTsfKroJnQ) % int(Xh5wV3Ll7rMTAavHKG1F640U9)
		url = eWbB3fKTVY + gIRLK2jm74q31vs5z + str(wwLKR5YpyqGu) + wFoMiTvNfO3xcCm2EIQB
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[url]
	else: return VHrIziKUDuNGXkMla(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅࠨ඙"),[],[]
def QfYkaKFeERJ7mvphWZr(url):
	id = url.split(qTVF3icWwGXy5(u"ࠪ࠳ࠬක"))[-fdQOo6Hu4B5Rbg]
	headers = { UighHKAfySm4PWErqJ(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪඛ") : iAGgjwb7tVMmacRJ(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫග") }
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { VHrIziKUDuNGXkMla(u"ࠨࡩࡥࠤඝ"):id , iqHhJSxdaANDG5rlZm7B(u"ࠢࡰࡲࠥඞ"):wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦඟ") }
	A0AzrLupg8h1s = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,cJSNFCIhymEfx6grGu0M(u"ࠩࡓࡓࡘ࡚ࠧච"), url, QKsd6VmaOnMPCWuqcTyl28JZH7ASjo, headers, G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭ඡ"))
	if t2sCrJ0xbgDRkf(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ජ") in list(A0AzrLupg8h1s.headers.keys()): Y6YdkAMluFbwx = A0AzrLupg8h1s.headers[UighHKAfySm4PWErqJ(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧඣ")]
	else: Y6YdkAMluFbwx = url
	if Y6YdkAMluFbwx: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[Y6YdkAMluFbwx]
	else: return dC3PsQJ0Ti28uYlov(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡓ࠸࡚ࡖࡌࡐࡃࡇࠫඤ"),[],[]
def q3zom68EfHG09bJ(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡎࡔࡔࡗࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪඥ"))
	items = oo9kuULlebNgpY0Om.findall(iqHhJSxdaANDG5rlZm7B(u"ࠨ࡯ࡳ࠸࠿ࠦ࡜࡜࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫඦ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[ items[dQ5JhEYolPmy1fvHktMw6NFRxiz] ]
	else: return jR9YtmsgDX8nTQlMb6G3(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧට"),[],[]
def VXfZd6JQLTDo7hOxqGrBEFKWN(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡅࡋࡍ࡛ࡋ࠭࠲ࡵࡷࠫඨ"))
	items = oo9kuULlebNgpY0Om.findall(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩඩ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		url = url = iqHhJSxdaANDG5rlZm7B(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫඪ") + items[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[ url ]
	else: return hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡇࡍࡏࡖࡆࠩණ"),[],[]
def OYEMpa6d4oPvqSnj1N5ZTJFA(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨඬ"))
	items = oo9kuULlebNgpY0Om.findall(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨත"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items: return G9G0YqivIfmUWO8K,[G9G0YqivIfmUWO8K],[ items[dQ5JhEYolPmy1fvHktMw6NFRxiz] ]
	else: return ETNq5t4MYngSsbfFD8J0v(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬථ"),[],[]
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
s5slfAmHkUtMR3WSKY1ZTX = 'AKOAM'
TdtCLWYSJNK8zOb = '_AKO_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
AAtaSZM3iv2XOQTJRjGW87 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==70: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==71: tRojAyBgfDH37eLCwP4dWl = cHghWIxRvzV2QD(url)
	elif mode==72: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==73: tRojAyBgfDH37eLCwP4dWl = DcSh7TfXGziYyA(url)
	elif mode==74: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==79: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,79,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'سلسلة افلام',G9G0YqivIfmUWO8K,79,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'سلسلة افلام')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'سلاسل منوعة',G9G0YqivIfmUWO8K,79,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'سلسلة')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	tlcXBJEfIHF02vQ6yxSom9z1 = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'AKOAM-MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="partions"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title not in tlcXBJEfIHF02vQ6yxSom9z1:
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,71)
	return GagwMT6q3oc7UZ2Q
def cHghWIxRvzV2QD(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'AKOAM-CATEGORIES-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('sect_parts(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,72)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'جميع الفروع',url,72)
	else: UUhwKBgI2nt(url,G9G0YqivIfmUWO8K)
	return
def UUhwKBgI2nt(url,type):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('section_title featured_title(.*?)subjects-crousel',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='search':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('akoam_result(.*?)<script',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='more':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('section_title more_title(.*?)footer_bottom_services',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('navigation(.*?)<script',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not items and cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in AAtaSZM3iv2XOQTJRjGW87): Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,73,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,73,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall("</li><li >.*?href='(.*?)'>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,72,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def Y3SljPqhp8e9cxtgbZvT(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,True,'AKOAM-SECTIONS-2nd')
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('"href","(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[1]
	return XXzvmn7ewM8yBfoxua
def DcSh7TfXGziYyA(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,True,'AKOAM-SECTIONS-1st')
	Li6smH8wNdcDak = oo9kuULlebNgpY0Om.findall('"(https*://akwam.net/\w+.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Re7f38DEZmHSOM6ANbVBxiKnYP = oo9kuULlebNgpY0Om.findall('"(https*://underurl.com/\w+.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Li6smH8wNdcDak or Re7f38DEZmHSOM6ANbVBxiKnYP:
		if Li6smH8wNdcDak: XjWHSnbf6NwhMgpKt4yLY7AkIT = Li6smH8wNdcDak[0]
		elif Re7f38DEZmHSOM6ANbVBxiKnYP: XjWHSnbf6NwhMgpKt4yLY7AkIT = Y3SljPqhp8e9cxtgbZvT(Re7f38DEZmHSOM6ANbVBxiKnYP[0])
		XjWHSnbf6NwhMgpKt4yLY7AkIT = aKAyEnjxIlzZtCTv(XjWHSnbf6NwhMgpKt4yLY7AkIT)
		import NNHDVzYX8O
		if '/series/' in XjWHSnbf6NwhMgpKt4yLY7AkIT or '/shows/' in XjWHSnbf6NwhMgpKt4yLY7AkIT: NNHDVzYX8O.EL0QAd56tj7Db9eFSw3UZofIsra8(XjWHSnbf6NwhMgpKt4yLY7AkIT)
		else: NNHDVzYX8O.sWujQcGynM9NtJeTfqk3D(XjWHSnbf6NwhMgpKt4yLY7AkIT)
		return
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	items = oo9kuULlebNgpY0Om.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,73)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF:
		XXeZuvhknsKYqB17gwm6dfc('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,M4qkBDatEIf3T,BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	name = name.strip(ww0sZkBU9JKd)
	if 'sub_epsiode_title' in BN1KdkzCmvshw:
		items = oo9kuULlebNgpY0Om.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	else:
		iVKl6bQHUc0w = oo9kuULlebNgpY0Om.findall('sub_file_title\'>(.*?) - <i>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		items = []
		for filename in iVKl6bQHUc0w:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',G9G0YqivIfmUWO8K) ]
	count = 0
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,PnN12SEmlCzk6eZrRGqsBDpQ = [],[]
	size = len(items)
	for title,filename in items:
		FF94GpU6MrbZy = G9G0YqivIfmUWO8K
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: FF94GpU6MrbZy = filename.split('.')[-1]
		title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append(title)
		PnN12SEmlCzk6eZrRGqsBDpQ.append(count)
		count += 1
	if size>0:
		if any(yW70dtahIjkPCJg2TA in name for yW70dtahIjkPCJg2TA in AAtaSZM3iv2XOQTJRjGW87):
			if size==1:
				PXeEIRkdShOGm45lbLJc2B38s = 0
			else:
				PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر الفيديو المناسب:', Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
				if PXeEIRkdShOGm45lbLJc2B38s == -1: return
			sWujQcGynM9NtJeTfqk3D(url+'?section='+str(1+PnN12SEmlCzk6eZrRGqsBDpQ[size-PXeEIRkdShOGm45lbLJc2B38s-1]))
		else:
			for KT9tdUH3hmiLZCEFz in reversed(range(size)):
				title = name + ' - ' + Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[KT9tdUH3hmiLZCEFz]
				title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				Y6YdkAMluFbwx = url + '?section='+str(size-KT9tdUH3hmiLZCEFz)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,74,M4qkBDatEIf3T)
	else:
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+'الرابط ليس فيديو',G9G0YqivIfmUWO8K,9999,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	XXzvmn7ewM8yBfoxua,RnV3EqPNpXTDuI7 = url.split('?section=')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,True,G9G0YqivIfmUWO8K,'AKOAM-PLAY_AKOAM-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = cSLKDEATk7y10ovtGZCwF[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw + 'direct_link_box'
	cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('epsoide_box(.*?)direct_link_box',o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw,oo9kuULlebNgpY0Om.DOTALL)
	RnV3EqPNpXTDuI7 = len(cUE5uH8hAtOmTp)-int(RnV3EqPNpXTDuI7)
	BN1KdkzCmvshw = cUE5uH8hAtOmTp[RnV3EqPNpXTDuI7]
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	L6c4E9JYh5j1NpbkHu = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = oo9kuULlebNgpY0Om.findall("class='download_btn.*?href='(.*?)'",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx in items:
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named=________akoam')
	items = oo9kuULlebNgpY0Om.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for ssBJ5nKcIzuiamk6yEr,Y6YdkAMluFbwx in items:
		ssBJ5nKcIzuiamk6yEr = ssBJ5nKcIzuiamk6yEr.split('/')[-1]
		ssBJ5nKcIzuiamk6yEr = ssBJ5nKcIzuiamk6yEr.split('.')[0]
		if ssBJ5nKcIzuiamk6yEr in L6c4E9JYh5j1NpbkHu:
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+L6c4E9JYh5j1NpbkHu[ssBJ5nKcIzuiamk6yEr]+'________akoam')
		else: ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+ssBJ5nKcIzuiamk6yEr+'________akoam')
	if not ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
		message = oo9kuULlebNgpY0Om.findall('sub-no-file.*?\n(.*?)\n',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if message: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من الموقع الاصلي',message[0])
	else:
		import iOVAoxDJew
		iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'%20')
	url = ffVP3AK5RqhkgYnjZoNis + '/search/'+HG9ZQqnw71y0JmrDLx
	tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,'search')
	return
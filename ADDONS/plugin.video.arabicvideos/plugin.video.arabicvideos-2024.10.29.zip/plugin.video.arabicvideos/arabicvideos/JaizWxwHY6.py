# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'DAILYMOTION'
TdtCLWYSJNK8zOb = '_DLM_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
cEz6aWRhkf1KS = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][1]
def RAndFk3y4Pbvs29(mode,url,text,type,eehFlSEjHioyAWpLqZXt79):
	if	 mode==400: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==401: tRojAyBgfDH37eLCwP4dWl = ttcSCWUL8efu0XpBhA2g7y(url,text)
	elif mode==402: tRojAyBgfDH37eLCwP4dWl = sFMr3gitAYp2wkouhem8(url,text)
	elif mode==403: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url,text)
	elif mode==404: tRojAyBgfDH37eLCwP4dWl = Rj09qNBzMmsZeDxUwHLFIGbE(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==405: tRojAyBgfDH37eLCwP4dWl = fEnlFiZv0sY3uk(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==406: tRojAyBgfDH37eLCwP4dWl = ueyaR9qhDilg6XkE0Ab(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==407: tRojAyBgfDH37eLCwP4dWl = oE8kzwmxaD5lj03HdrTMc(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==408: tRojAyBgfDH37eLCwP4dWl = iizQmZHphqnvEcVl7UtjwySf(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==409: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==411: tRojAyBgfDH37eLCwP4dWl = HRjr3WGk0DEn9U(url,text)
	elif mode==414: tRojAyBgfDH37eLCwP4dWl = Pl5q9NBAKib61R0zLFvCkm3XVuh(text)
	elif mode==415: tRojAyBgfDH37eLCwP4dWl = SfOHnIrDwbx98k4iYeN(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==416: tRojAyBgfDH37eLCwP4dWl = VbU57ikZ3pNdLyoBu(text,eehFlSEjHioyAWpLqZXt79)
	elif mode==417: tRojAyBgfDH37eLCwP4dWl = C02RE3lDG56YXSaPZIz(url,eehFlSEjHioyAWpLqZXt79)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الرئيسية',G9G0YqivIfmUWO8K,414)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن فيديوهات',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'videos?sortBy=','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن آخر الفيديوهات',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن الفيديوهات الأكثر مشاهدة',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن قوائم التشغيل',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'playlists','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن مستخدم',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'channels','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن بث حي',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'lives','_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن هاشتاك',G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,'hashtags','_REMEMBERRESULTS_')
	return
def sFMr3gitAYp2wkouhem8(url,qdJSNuzy63oO5mb9W):
	if '/dm_' in url:
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,False,G9G0YqivIfmUWO8K,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = D7omduSeM5Gk.headers
		if 'Location' in list(headers.keys()): url = ffVP3AK5RqhkgYnjZoNis+headers['Location']
	qdJSNuzy63oO5mb9W = A7XhkmSYZlidyMt5FpWqTgjNezbnD+qdJSNuzy63oO5mb9W+zzGfwLAyN5HTxUoJeaivY
	qdJSNuzy63oO5mb9W = ERxLAJDbIwoY(qdJSNuzy63oO5mb9W)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: بث حي',url,411,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'channel_lives_now')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: آخر الفيديوهات',url+'/videos',408)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: المميزة',url,411,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'channel_featured_videos')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: قوائم التشغيل',url+'/playlists',407)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+':: قنوات ذات صلة',url,411,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'channel_related_channel')
	return
def ERxLAJDbIwoY(title):
	title = title.rstrip('\\').strip(ww0sZkBU9JKd).replace('\\\\','\\')
	title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
	return title
def sWujQcGynM9NtJeTfqk3D(url,MYgd8SpmZE):
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk([url],s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def Rj09qNBzMmsZeDxUwHLFIGbE(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = G9G0YqivIfmUWO8K
	search = search.split('/videos')[0]
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	if sort==G9G0YqivIfmUWO8K: A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysortmethod',G9G0YqivIfmUWO8K)
	else: A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/videos'
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"videos"(.*?)"VideoConnection"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,title,LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W,ii9h6QFxBUuCeqJODlfYmsI7ZT,M4qkBDatEIf3T in items:
			if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
			if '"' in title: title = title.replace('"',G9G0YqivIfmUWO8K)
			if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
			if '"' in ii9h6QFxBUuCeqJODlfYmsI7ZT: ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.replace('"',G9G0YqivIfmUWO8K)
			if '"' in LzFP51ueOwqymWTDa3s6ktC4N0h: LzFP51ueOwqymWTDa3s6ktC4N0h = LzFP51ueOwqymWTDa3s6ktC4N0h.replace('"',G9G0YqivIfmUWO8K)
			if '"' in qdJSNuzy63oO5mb9W: qdJSNuzy63oO5mb9W = qdJSNuzy63oO5mb9W.replace('"',G9G0YqivIfmUWO8K)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+id
			title = ERxLAJDbIwoY(title)
			MYgd8SpmZE = LzFP51ueOwqymWTDa3s6ktC4N0h+'::'+qdJSNuzy63oO5mb9W
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT,MYgd8SpmZE)
		if '"hasNextPage":true' in GagwMT6q3oc7UZ2Q:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,404,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def fEnlFiZv0sY3uk(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/playlists'
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	items = oo9kuULlebNgpY0Om.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for id,name,Bp0zaIAsfMoP1LwUeuFgKHQ,LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W,M4qkBDatEIf3T,count in items:
		if '"' in Bp0zaIAsfMoP1LwUeuFgKHQ: Bp0zaIAsfMoP1LwUeuFgKHQ = Bp0zaIAsfMoP1LwUeuFgKHQ.replace('"',G9G0YqivIfmUWO8K)
		if '"' in LzFP51ueOwqymWTDa3s6ktC4N0h: LzFP51ueOwqymWTDa3s6ktC4N0h = LzFP51ueOwqymWTDa3s6ktC4N0h.replace('"',G9G0YqivIfmUWO8K)
		if '"' in qdJSNuzy63oO5mb9W: qdJSNuzy63oO5mb9W = qdJSNuzy63oO5mb9W.replace('"',G9G0YqivIfmUWO8K)
		if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
		if '"' in name: name = name.replace('"',G9G0YqivIfmUWO8K)
		if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
		if '"' in count: count = count.replace('"',G9G0YqivIfmUWO8K)
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = ERxLAJDbIwoY(title)
		MYgd8SpmZE = LzFP51ueOwqymWTDa3s6ktC4N0h+'::'+qdJSNuzy63oO5mb9W
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,401,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,MYgd8SpmZE)
	if '"hasNextPage":true' in GagwMT6q3oc7UZ2Q:
		eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,405,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def ueyaR9qhDilg6XkE0Ab(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/channels'
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"channels"(.*?)"ChannelConnection"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,name,M4qkBDatEIf3T in items:
			if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
			if '"' in name: name = name.replace('"',G9G0YqivIfmUWO8K)
			if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+id
			title = 'USER:  '+name
			title = ERxLAJDbIwoY(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,402,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,name)
		if '"hasNextPage":true' in GagwMT6q3oc7UZ2Q:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,406,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def Pl5q9NBAKib61R0zLFvCkm3XVuh(kqExTaS9v1smZyACp3QW2XYgNU):
	A0AzrLupg8h1s = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['home']['neon']['sections']['edges']
		if not kqExTaS9v1smZyACp3QW2XYgNU:
			RqPazOmMYBLfDZ82WT = []
			for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
				qrOuR4yZi5UI60z = qqZlepJ2gyvdnUcIRD['node']['title']
				if qrOuR4yZi5UI60z not in RqPazOmMYBLfDZ82WT: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+qrOuR4yZi5UI60z,G9G0YqivIfmUWO8K,414,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qrOuR4yZi5UI60z)
				RqPazOmMYBLfDZ82WT.append(qrOuR4yZi5UI60z)
		else:
			for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
				qrOuR4yZi5UI60z = qqZlepJ2gyvdnUcIRD['node']['title']
				if qrOuR4yZi5UI60z==kqExTaS9v1smZyACp3QW2XYgNU:
					WgNuyQY8jBH30P2O = qqZlepJ2gyvdnUcIRD['node']['components']['edges']
					for G47s0E2WfSavxwZKV8QBdFXHYRe1i in WgNuyQY8jBH30P2O:
						ii9h6QFxBUuCeqJODlfYmsI7ZT = str(G47s0E2WfSavxwZKV8QBdFXHYRe1i['node']['duration'])
						title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(G47s0E2WfSavxwZKV8QBdFXHYRe1i['node']['title'])
						title = title.replace('\/','/')
						CWVgYQwUA3Z0OJ1N = G47s0E2WfSavxwZKV8QBdFXHYRe1i['node']['xid']
						M4qkBDatEIf3T = G47s0E2WfSavxwZKV8QBdFXHYRe1i['node']['thumbnailx480']
						M4qkBDatEIf3T = M4qkBDatEIf3T.replace('\/','/')
						Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+CWVgYQwUA3Z0OJ1N
						Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	return
def SfOHnIrDwbx98k4iYeN(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/lives'
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		try: ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['search']['lives']['edges']
		except: ttZkfD6GEOwa = []
		for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
			name = qqZlepJ2gyvdnUcIRD['node']['title']
			name = zDBtm4MwIagkfcpE5oxJOAq6lZQY(name)
			CWVgYQwUA3Z0OJ1N = qqZlepJ2gyvdnUcIRD['node']['xid']
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+CWVgYQwUA3Z0OJ1N
			Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'LIVE: '+name,Y6YdkAMluFbwx,403)
		if '"hasNextPage":true' in iHRhfNUTIJ5l01cM:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,415,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def CudhAQilRMgBF5xIEf689V(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/topics'
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		try: ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['search']['topics']['edges']
		except: ttZkfD6GEOwa = []
		for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
			name = qqZlepJ2gyvdnUcIRD['node']['name']
			CWVgYQwUA3Z0OJ1N = qqZlepJ2gyvdnUcIRD['node']['xid']
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/topic/'+CWVgYQwUA3Z0OJ1N
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'TOPIC: '+name,Y6YdkAMluFbwx,413)
		if '"hasNextPage":true' in iHRhfNUTIJ5l01cM:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,412,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def gIPBoRFkfwXGrcalz2hTZ3509esx6y(url,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	CWVgYQwUA3Z0OJ1N = url.split('/')[-1]
	A0AzrLupg8h1s = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mytopicid',CWVgYQwUA3Z0OJ1N)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['topic']['videos']['edges']
		for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
			ii9h6QFxBUuCeqJODlfYmsI7ZT = str(qqZlepJ2gyvdnUcIRD['node']['duration'])
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(qqZlepJ2gyvdnUcIRD['node']['title'])
			title = title.replace('\/','/')
			CWVgYQwUA3Z0OJ1N = qqZlepJ2gyvdnUcIRD['node']['xid']
			M4qkBDatEIf3T = qqZlepJ2gyvdnUcIRD['node']['thumbnailx480']
			M4qkBDatEIf3T = M4qkBDatEIf3T.replace('\/','/')
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+CWVgYQwUA3Z0OJ1N
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
		if '"hasNextPage":true' in iHRhfNUTIJ5l01cM:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,413,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79)
	return
def ttcSCWUL8efu0XpBhA2g7y(url,MYgd8SpmZE):
	id = url.split('/')[-1]
	LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W = MYgd8SpmZE.split('::',1)
	Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+LzFP51ueOwqymWTDa3s6ktC4N0h
	qdJSNuzy63oO5mb9W = ERxLAJDbIwoY(qdJSNuzy63oO5mb9W)
	title = A7XhkmSYZlidyMt5FpWqTgjNezbnD+'OWNER:  '+qdJSNuzy63oO5mb9W+zzGfwLAyN5HTxUoJeaivY
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,402,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qdJSNuzy63oO5mb9W)
	A0AzrLupg8h1s = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('myplaylistid',id)
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"collection_videos"(.*?)"SectionEdge"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,title,ii9h6QFxBUuCeqJODlfYmsI7ZT,M4qkBDatEIf3T,LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W in items:
			if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
			if '"' in title: title = title.replace('"',G9G0YqivIfmUWO8K)
			if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
			if '"' in ii9h6QFxBUuCeqJODlfYmsI7ZT: ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.replace('"',G9G0YqivIfmUWO8K)
			if '"' in LzFP51ueOwqymWTDa3s6ktC4N0h: LzFP51ueOwqymWTDa3s6ktC4N0h = LzFP51ueOwqymWTDa3s6ktC4N0h.replace('"',G9G0YqivIfmUWO8K)
			if '"' in qdJSNuzy63oO5mb9W: qdJSNuzy63oO5mb9W = qdJSNuzy63oO5mb9W.replace('"',G9G0YqivIfmUWO8K)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+id
			title = ERxLAJDbIwoY(title)
			MYgd8SpmZE = LzFP51ueOwqymWTDa3s6ktC4N0h+'::'+qdJSNuzy63oO5mb9W
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT,MYgd8SpmZE)
	return
def iizQmZHphqnvEcVl7UtjwySf(url,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	TJMXlg4jb6GzS5ew = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	A0AzrLupg8h1s = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mychannelid',TJMXlg4jb6GzS5ew)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysortmethod',sort)
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,title,ii9h6QFxBUuCeqJODlfYmsI7ZT,LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W,M4qkBDatEIf3T in items:
			if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
			if '"' in title: title = title.replace('"',G9G0YqivIfmUWO8K)
			if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
			if '"' in ii9h6QFxBUuCeqJODlfYmsI7ZT: ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.replace('"',G9G0YqivIfmUWO8K)
			if '"' in LzFP51ueOwqymWTDa3s6ktC4N0h: LzFP51ueOwqymWTDa3s6ktC4N0h = LzFP51ueOwqymWTDa3s6ktC4N0h.replace('"',G9G0YqivIfmUWO8K)
			if '"' in qdJSNuzy63oO5mb9W: qdJSNuzy63oO5mb9W = qdJSNuzy63oO5mb9W.replace('"',G9G0YqivIfmUWO8K)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+id
			title = ERxLAJDbIwoY(title)
			MYgd8SpmZE = LzFP51ueOwqymWTDa3s6ktC4N0h+'::'+qdJSNuzy63oO5mb9W
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT,MYgd8SpmZE)
		if '"hasNextPage":true' in GagwMT6q3oc7UZ2Q:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,408,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79)
	return
def oE8kzwmxaD5lj03HdrTMc(url,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	TJMXlg4jb6GzS5ew = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	A0AzrLupg8h1s = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mychannelid',TJMXlg4jb6GzS5ew)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysortmethod',sort)
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for id,name,M4qkBDatEIf3T,count,Bp0zaIAsfMoP1LwUeuFgKHQ,LzFP51ueOwqymWTDa3s6ktC4N0h,qdJSNuzy63oO5mb9W in items:
			if '"' in id: id = id.replace('"',G9G0YqivIfmUWO8K)
			if '"' in name: name = name.replace('"',G9G0YqivIfmUWO8K)
			if '"' in M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T.replace('"',G9G0YqivIfmUWO8K)
			if '"' in count: count = count.replace('"',G9G0YqivIfmUWO8K)
			if '"' in Bp0zaIAsfMoP1LwUeuFgKHQ: Bp0zaIAsfMoP1LwUeuFgKHQ = Bp0zaIAsfMoP1LwUeuFgKHQ.replace('"',G9G0YqivIfmUWO8K)
			if '"' in LzFP51ueOwqymWTDa3s6ktC4N0h: LzFP51ueOwqymWTDa3s6ktC4N0h = LzFP51ueOwqymWTDa3s6ktC4N0h.replace('"',G9G0YqivIfmUWO8K)
			if '"' in qdJSNuzy63oO5mb9W: qdJSNuzy63oO5mb9W = qdJSNuzy63oO5mb9W.replace('"',G9G0YqivIfmUWO8K)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = ERxLAJDbIwoY(title)
			MYgd8SpmZE = LzFP51ueOwqymWTDa3s6ktC4N0h+'::'+qdJSNuzy63oO5mb9W
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,401,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,MYgd8SpmZE)
		if '"hasNextPage":true' in GagwMT6q3oc7UZ2Q:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,407,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79)
	return
def HRjr3WGk0DEn9U(url,gXNdG07Y3qE6yU):
	TJMXlg4jb6GzS5ew = url.split('/')[3]
	A0AzrLupg8h1s = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mychannelid',TJMXlg4jb6GzS5ew)
	GagwMT6q3oc7UZ2Q = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	RMP1JzANawH407iZxY3gu9B8SWK = EEMsy4SLwnD0T92ztchdIUZ.loads(GagwMT6q3oc7UZ2Q)
	try: items = RMP1JzANawH407iZxY3gu9B8SWK['data']['channel'][gXNdG07Y3qE6yU]['edges']
	except: items = []
	if not items: Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+'لا توجد نتائج',G9G0YqivIfmUWO8K,9999)
	else:
		for XX2Btn97vEfkCjcuWs in items:
			tmXdZCc7kVl = XX2Btn97vEfkCjcuWs['node']
			CWVgYQwUA3Z0OJ1N = tmXdZCc7kVl['xid']
			keys = list(tmXdZCc7kVl.keys())
			RtaBKWL14Xhi0e = tmXdZCc7kVl['__typename'].lower()
			if RtaBKWL14Xhi0e=='channel':
				name = tmXdZCc7kVl['name']
				F2bMS7eLnCi = tmXdZCc7kVl['displayName']
				title = 'USER:  '+F2bMS7eLnCi
				M4qkBDatEIf3T = tmXdZCc7kVl['coverURLx375']
			else:
				name = tmXdZCc7kVl['channel']['name']
				F2bMS7eLnCi = tmXdZCc7kVl['channel']['displayName']
				title = tmXdZCc7kVl['title']
				M4qkBDatEIf3T = tmXdZCc7kVl['thumbnailx360']
				if RtaBKWL14Xhi0e=='live': title = 'LIVE:  '+title
			title = ERxLAJDbIwoY(title)
			MYgd8SpmZE = name+'::'+F2bMS7eLnCi
			if gA0m6CQUyfLG:
				title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				MYgd8SpmZE = MYgd8SpmZE.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			if RtaBKWL14Xhi0e=='channel':
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+CWVgYQwUA3Z0OJ1N
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,402,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,MYgd8SpmZE)
			else:
				if RtaBKWL14Xhi0e=='video': ii9h6QFxBUuCeqJODlfYmsI7ZT = str(tmXdZCc7kVl['duration'])
				else: ii9h6QFxBUuCeqJODlfYmsI7ZT = G9G0YqivIfmUWO8K
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+CWVgYQwUA3Z0OJ1N
				Qm8SMu6ecXtigDCWw1oak(RtaBKWL14Xhi0e,TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT,MYgd8SpmZE)
	return
def VbU57ikZ3pNdLyoBu(search,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	A0AzrLupg8h1s = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mysearchwords',search)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagelimit','40')
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'/hashtags'
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		try: ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['search']['hashtags']['edges']
		except: ttZkfD6GEOwa = []
		for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
			name = qqZlepJ2gyvdnUcIRD['node']['name']
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/hashtag/'+name[1:]
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'HSHTG: '+name,Y6YdkAMluFbwx,417)
		if '"hasNextPage":true' in iHRhfNUTIJ5l01cM:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,416,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79,search)
	return
def C02RE3lDG56YXSaPZIz(url,eehFlSEjHioyAWpLqZXt79=G9G0YqivIfmUWO8K):
	if eehFlSEjHioyAWpLqZXt79==G9G0YqivIfmUWO8K: eehFlSEjHioyAWpLqZXt79 = '1'
	name = url.split('/')[-1]
	A0AzrLupg8h1s = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('myhashtagname',name)
	A0AzrLupg8h1s = A0AzrLupg8h1s.replace('mypagenumber',eehFlSEjHioyAWpLqZXt79)
	iHRhfNUTIJ5l01cM = HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s)
	if iHRhfNUTIJ5l01cM:
		fipyd27K6OLhRqroI4CXHBPS8UJY = bRCSwcA89e4J7pqdays5PxGiD2('dict',iHRhfNUTIJ5l01cM)
		ttZkfD6GEOwa = fipyd27K6OLhRqroI4CXHBPS8UJY['data']['contentFeed']['edges']
		for qqZlepJ2gyvdnUcIRD in ttZkfD6GEOwa:
			ii9h6QFxBUuCeqJODlfYmsI7ZT = str(qqZlepJ2gyvdnUcIRD['node']['post']['duration'])
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(qqZlepJ2gyvdnUcIRD['node']['post']['title'])
			title = title.replace('\/','/')
			CWVgYQwUA3Z0OJ1N = qqZlepJ2gyvdnUcIRD['node']['post']['xid']
			M4qkBDatEIf3T = qqZlepJ2gyvdnUcIRD['node']['post']['thumbnailx480']
			M4qkBDatEIf3T = M4qkBDatEIf3T.replace('\/','/')
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video/'+CWVgYQwUA3Z0OJ1N
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,403,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
		if '"hasNextPage":true' in iHRhfNUTIJ5l01cM:
			eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)+1)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+eehFlSEjHioyAWpLqZXt79,url,416,G9G0YqivIfmUWO8K,eehFlSEjHioyAWpLqZXt79)
	return
def HP6l2q0KsBTORjFNuo7AibmLet(A0AzrLupg8h1s,search=G9G0YqivIfmUWO8K):
	if LTze51miOknVcslNF43WSA6vMjYZt: A0AzrLupg8h1s = A0AzrLupg8h1s.encode('utf-8')
	kh2N30qYHcJmDbPGUW = zgaQpbXFucvDZ2T5y8fn()
	headers = {"Authorization":kh2N30qYHcJmDbPGUW,"Origin":ffVP3AK5RqhkgYnjZoNis,'Content-Type':'text/plain; charset=utf-8'}
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',cEz6aWRhkf1KS,A0AzrLupg8h1s,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'DAILYMOTION-GET_PAGEDATA-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	return GagwMT6q3oc7UZ2Q
def zgaQpbXFucvDZ2T5y8fn():
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'DAILYMOTION-GET_AUTHINTICATION-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	HqjzZ6kmNEnIK4lrL8tQvWegRa = oo9kuULlebNgpY0Om.findall('var r="(.*?)",o="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	gy0HlXqMsJBCmzpeEtNA7921nYaKv,Ol1TznaXufAdMS4rW = HqjzZ6kmNEnIK4lrL8tQvWegRa[-1]
	thkyBF31nGc4fbQTZLp0AjRNK = 'https://graphql.api.dailymotion.com/oauth/token'
	qxZhOG8HnldpIvtmC4Uu1Xf = 'client_credentials'
	data = {'client_id':gy0HlXqMsJBCmzpeEtNA7921nYaKv,'client_secret':Ol1TznaXufAdMS4rW,'grant_type':qxZhOG8HnldpIvtmC4Uu1Xf}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',thkyBF31nGc4fbQTZLp0AjRNK,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	HqjzZ6kmNEnIK4lrL8tQvWegRa = oo9kuULlebNgpY0Om.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	smBAXM9u6EOSRx1Ufk,kkKUN6cCmSZasp3rGdAg2iz5fM9v = HqjzZ6kmNEnIK4lrL8tQvWegRa[0]
	kh2N30qYHcJmDbPGUW = kkKUN6cCmSZasp3rGdAg2iz5fM9v+" "+smBAXM9u6EOSRx1Ufk
	return kh2N30qYHcJmDbPGUW
def b6WZDnA0dLBiCITrF37OS(search,hEDd8S3OLIugvAc5HRzQkTqM60wW=G9G0YqivIfmUWO8K):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not hEDd8S3OLIugvAc5HRzQkTqM60wW and showDialogs:
		w1GHmzWFvYLkD0eN8SjZJbOoEBs4XT = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('موقع ديلي موشن - اختر البحث',w1GHmzWFvYLkD0eN8SjZJbOoEBs4XT)
		if PXeEIRkdShOGm45lbLJc2B38s==-1: return
		elif PXeEIRkdShOGm45lbLJc2B38s==0: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'videos?sortBy='
		elif PXeEIRkdShOGm45lbLJc2B38s==1: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'videos?sortBy=RECENT'
		elif PXeEIRkdShOGm45lbLJc2B38s==2: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'videos?sortBy=VIEW_COUNT'
		elif PXeEIRkdShOGm45lbLJc2B38s==3: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'playlists'
		elif PXeEIRkdShOGm45lbLJc2B38s==4: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'channels'
		elif PXeEIRkdShOGm45lbLJc2B38s==5: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'lives'
		elif PXeEIRkdShOGm45lbLJc2B38s==6: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in EIcQfuLpMO2jX: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in EIcQfuLpMO2jX: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in EIcQfuLpMO2jX: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'channels'
	elif '_DAILYMOTION-LIVES_' in EIcQfuLpMO2jX: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in EIcQfuLpMO2jX: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'hashtags'
	elif not hEDd8S3OLIugvAc5HRzQkTqM60wW: hEDd8S3OLIugvAc5HRzQkTqM60wW = 'videos?sortBy='
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	if 'videos' in hEDd8S3OLIugvAc5HRzQkTqM60wW: Rj09qNBzMmsZeDxUwHLFIGbE(search+'/'+hEDd8S3OLIugvAc5HRzQkTqM60wW)
	elif 'playlists' in hEDd8S3OLIugvAc5HRzQkTqM60wW: fEnlFiZv0sY3uk(search)
	elif 'channels' in hEDd8S3OLIugvAc5HRzQkTqM60wW: ueyaR9qhDilg6XkE0Ab(search)
	elif 'lives' in hEDd8S3OLIugvAc5HRzQkTqM60wW: SfOHnIrDwbx98k4iYeN(search)
	elif 'hashtags' in hEDd8S3OLIugvAc5HRzQkTqM60wW: VbU57ikZ3pNdLyoBu(search)
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ALFATIMI'
TdtCLWYSJNK8zOb = '_FTM_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
X2xJRCWVlTp3P8s45i7deu = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
JJ31L7CEZp82S6I = ['3030','628']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==60: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==61: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==62: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==63: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==64: tRojAyBgfDH37eLCwP4dWl = fQHCPMh4wmD1GTg(text)
	elif mode==69: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,69,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'ما يتم مشاهدته الان',ffVP3AK5RqhkgYnjZoNis,64,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'recent_viewed_vids')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الاكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis,64,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'most_viewed_vids')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'اضيفت مؤخرا',ffVP3AK5RqhkgYnjZoNis,64,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'recently_added_vids')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'فيديو عشوائي',ffVP3AK5RqhkgYnjZoNis,64,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'random_vids')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'افلام ومسلسلات',ffVP3AK5RqhkgYnjZoNis,61,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'-1')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'البرامج الدينية',ffVP3AK5RqhkgYnjZoNis,61,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'-2')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'English Videos',ffVP3AK5RqhkgYnjZoNis,61,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'-3')
	return G9G0YqivIfmUWO8K
def UUhwKBgI2nt(url,nxguK9laUWBGHIR4zEsTo7):
	oo7kpizdm9Yvg = G9G0YqivIfmUWO8K
	if nxguK9laUWBGHIR4zEsTo7 not in ['-1','-2','-3']: oo7kpizdm9Yvg = '?cat='+nxguK9laUWBGHIR4zEsTo7
	XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis+'/menu_level.php'+oo7kpizdm9Yvg
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ALFATIMI-TITLES-1st')
	items = oo9kuULlebNgpY0Om.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	P3kgADamHtwC4F5eEZW9rUINi2bh,a2brFZlqWO8hK1UfAmLVz = False,False
	for Y6YdkAMluFbwx,title,count in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		title = title.strip(ww0sZkBU9JKd)
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
		oo7kpizdm9Yvg = oo9kuULlebNgpY0Om.findall('cat=(.*?)&',Y6YdkAMluFbwx,oo9kuULlebNgpY0Om.DOTALL)[0]
		if nxguK9laUWBGHIR4zEsTo7==oo7kpizdm9Yvg: P3kgADamHtwC4F5eEZW9rUINi2bh = True
		elif P3kgADamHtwC4F5eEZW9rUINi2bh 	or (nxguK9laUWBGHIR4zEsTo7=='-1' and oo7kpizdm9Yvg in X2xJRCWVlTp3P8s45i7deu)  						or (nxguK9laUWBGHIR4zEsTo7=='-2' and oo7kpizdm9Yvg not in JJ31L7CEZp82S6I and oo7kpizdm9Yvg not in X2xJRCWVlTp3P8s45i7deu)  						or (nxguK9laUWBGHIR4zEsTo7=='-3' and oo7kpizdm9Yvg in JJ31L7CEZp82S6I):
							if count=='1': Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,63)
							else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,61,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,oo7kpizdm9Yvg)
							a2brFZlqWO8hK1UfAmLVz = True
	if not a2brFZlqWO8hK1UfAmLVz: EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,True,'ALFATIMI-EPISODES-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pagination(.*?)id="footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	Y6YdkAMluFbwx = G9G0YqivIfmUWO8K
	for M4qkBDatEIf3T,title,Y6YdkAMluFbwx in items:
		title = title.replace('Add',G9G0YqivIfmUWO8K).replace('to Quicklist',G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,63,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('(.*?)div',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw=cSLKDEATk7y10ovtGZCwF[0]
	BN1KdkzCmvshw=oo9kuULlebNgpY0Om.findall('pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	items=oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	XXzvmn7ewM8yBfoxua = url.split('?')[0]
	for Y6YdkAMluFbwx,zz1cDUuAaFjxL7HZThqon9OPG4MNdv in items:
		Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua + Y6YdkAMluFbwx
		title = kD2wGe8Oh4T7Cj3BMsy0(zz1cDUuAaFjxL7HZThqon9OPG4MNdv)
		title = 'صفحة ' + title
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,62)
	return Y6YdkAMluFbwx
def sWujQcGynM9NtJeTfqk3D(url):
	if 'videos.php' in url: url = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,True,'ALFATIMI-PLAY-1st')
	items = oo9kuULlebNgpY0Om.findall('playlistfile:"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	Imphr8LRTUDs(url,s5slfAmHkUtMR3WSKY1ZTX,'video')
	return
def fQHCPMh4wmD1GTg(nxguK9laUWBGHIR4zEsTo7):
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'mode' : nxguK9laUWBGHIR4zEsTo7 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = tAPSK0wDYQhczOgZ(QKsd6VmaOnMPCWuqcTyl28JZH7ASjo)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
		title = title.strip(ww0sZkBU9JKd)
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,63,M4qkBDatEIf3T)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis + '/search_result.php?query=' + HG9ZQqnw71y0JmrDLx
	EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	return
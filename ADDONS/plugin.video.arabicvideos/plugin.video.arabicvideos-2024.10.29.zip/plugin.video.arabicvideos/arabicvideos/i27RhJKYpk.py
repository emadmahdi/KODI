# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'KARBALATV'
TdtCLWYSJNK8zOb = '_KRB_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
headers = {'User-Agent':G9G0YqivIfmUWO8K}
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==320: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==321: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==322: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==329: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,329,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/video.php',G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KARBALATV-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="icono-plus"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title=='المكتبة المرئية': continue
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,321)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KARBALATV-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="container"(.*?)class="footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,count,title in items:
		count = count.replace('عدد ',G9G0YqivIfmUWO8K).replace(ww0sZkBU9JKd,G9G0YqivIfmUWO8K)
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('/',G9G0YqivIfmUWO8K)
		M4qkBDatEIf3T = M4qkBDatEIf3T.replace("'",G9G0YqivIfmUWO8K)
		if '.php' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'video.php'+Y6YdkAMluFbwx
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+M4qkBDatEIf3T
		title = title.strip(ww0sZkBU9JKd)
		title = title+' ('+count+')'
		if 'video.php' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,321,M4qkBDatEIf3T)
		elif 'watch.php' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,322,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)class="footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/video.php'+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,321)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KARBALATV-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<video.*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx[0]
	Imphr8LRTUDs(Y6YdkAMluFbwx,s5slfAmHkUtMR3WSKY1ZTX,'video')
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?q='+search
	UUhwKBgI2nt(url)
	return
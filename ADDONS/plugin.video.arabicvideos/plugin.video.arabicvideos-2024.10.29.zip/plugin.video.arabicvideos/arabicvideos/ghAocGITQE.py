# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ARABSEED'
headers = {'User-Agent':uCUkPIYFszbV90wSpKqWNOjZ1687Eh()}
TdtCLWYSJNK8zOb = '_ARS_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==250: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==251: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==252: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==253: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==254: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'CATEGORIES___'+text)
	elif mode==255: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'FILTERS___'+text)
	elif mode==256: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url,text)
	elif mode==259: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/main',G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,259,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',ffVP3AK5RqhkgYnjZoNis+'/category/اخرى',254)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',ffVP3AK5RqhkgYnjZoNis+'/category/اخرى',255)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',ffVP3AK5RqhkgYnjZoNis+'/main',251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured_main')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الأفلام',ffVP3AK5RqhkgYnjZoNis+'/main',251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'new_movies')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الحلقات',ffVP3AK5RqhkgYnjZoNis+'/main',251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'new_episodes')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المضاف حديثاً',ffVP3AK5RqhkgYnjZoNis+'/latest',251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'lastest')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('class="MenuHeader"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	duYhmVFABjltoJ9PcE = msFSK7j9MrcoPafDnkNO[0]
	qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if title not in tlcXBJEfIHF02vQ6yxSom9z1 and title!=G9G0YqivIfmUWO8K:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,256)
	return GagwMT6q3oc7UZ2Q
def QgXYczTwIFivtxa8l4d32oKhkrHn(url,type):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'class="SliderInSection' in GagwMT6q3oc7UZ2Q: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الأكثر مشاهدة',url,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'most')
	if 'class="MainSlides' in GagwMT6q3oc7UZ2Q: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',url,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	if 'class="LinksList' in GagwMT6q3oc7UZ2Q:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="LinksList(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			if len(cSLKDEATk7y10ovtGZCwF)>1 and type=='new_episodes': BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)"(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				GS7Y93B0b8TLxueF = oo9kuULlebNgpY0Om.findall('</i>(.*?)<span>(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
				try: ONEZrIFzqkX1no = GS7Y93B0b8TLxueF[0][0].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				except: ONEZrIFzqkX1no = G9G0YqivIfmUWO8K
				try: vJWjiaB4Eg2US8Z01nQ7Xy6boz = GS7Y93B0b8TLxueF[0][1].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				except: vJWjiaB4Eg2US8Z01nQ7Xy6boz = G9G0YqivIfmUWO8K
				GS7Y93B0b8TLxueF = ONEZrIFzqkX1no+ww0sZkBU9JKd+vJWjiaB4Eg2US8Z01nQ7Xy6boz
				if '<strong>' in title:
					kepvmcMhd8w2OqBSYKU = oo9kuULlebNgpY0Om.findall('</i>(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
					if kepvmcMhd8w2OqBSYKU: GS7Y93B0b8TLxueF = kepvmcMhd8w2OqBSYKU[0]
				if not GS7Y93B0b8TLxueF:
					kepvmcMhd8w2OqBSYKU = oo9kuULlebNgpY0Om.findall('alt="(.*?)"',title,oo9kuULlebNgpY0Om.DOTALL)
					if kepvmcMhd8w2OqBSYKU: GS7Y93B0b8TLxueF = kepvmcMhd8w2OqBSYKU[0]
				if GS7Y93B0b8TLxueF:
					if 'key=' in Y6YdkAMluFbwx: type = Y6YdkAMluFbwx.split('key=')[1]
					else: type = 'newest'
					GS7Y93B0b8TLxueF = GS7Y93B0b8TLxueF.strip(ww0sZkBU9JKd)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,Y6YdkAMluFbwx,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def UUhwKBgI2nt(url,type):
	H6hoDfAm89WLMiKkP7dpRYXF2qeQGJ,data,items = 'GET',G9G0YqivIfmUWO8K,[]
	if type=='filters':
		if '?' in url:
			lld4bP9IkCErJ5o1m,pPIbdY3oKe = 'POST',{}
			XXzvmn7ewM8yBfoxua,cRx6fa73DukTQ0S9NemsizY1LvHCMI = url.split('?')
			G5n4vArOfUz3CKS2o = cRx6fa73DukTQ0S9NemsizY1LvHCMI.split('&')
			for r5B4eRs8aPk2jzuUHCcnYGAN9dl in G5n4vArOfUz3CKS2o:
				key,yW70dtahIjkPCJg2TA = r5B4eRs8aPk2jzuUHCcnYGAN9dl.split('=')
				pPIbdY3oKe[key] = yW70dtahIjkPCJg2TA
			if G5n4vArOfUz3CKS2o: H6hoDfAm89WLMiKkP7dpRYXF2qeQGJ,url,data = lld4bP9IkCErJ5o1m,XXzvmn7ewM8yBfoxua,pPIbdY3oKe
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,H6hoDfAm89WLMiKkP7dpRYXF2qeQGJ,url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if type=='filters': cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q]
	elif 'featured' in type: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="MainSlides(.*?)class="LinksList',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='new_movies': cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='new_episodes': cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='most': cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="SliderInSection(.*?)class="LinksList',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="Blocks-UL"(.*?)class="AboElSeed"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if 'featured' in type:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		Z4T1wWMYg0jhEsVzb5NqHk = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if Z4T1wWMYg0jhEsVzb5NqHk:
			ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,hdl2oDFzge5TRHJVaKSU86YMqpyN,MMyF7Sa3Hh0TbOJqEwLlmPnCZ = zip(*Z4T1wWMYg0jhEsVzb5NqHk)
			items = zip(ODnaR0N8UHv7Twy6jS,MMyF7Sa3Hh0TbOJqEwLlmPnCZ,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
	else:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if 'WWE' in title: continue
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if 'الحلقة' in title:
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,253,M4qkBDatEIf3T)
			else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,252,M4qkBDatEIf3T)
		elif '/selary/' in Y6YdkAMluFbwx or 'مسلسل' in title:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,253,M4qkBDatEIf3T)
		else:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,252,M4qkBDatEIf3T)
	if type in ['newest','best','most']:
		items = oo9kuULlebNgpY0Om.findall('page-numbers" href="(.*?)">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Y6YdkAMluFbwx = kD2wGe8Oh4T7Cj3BMsy0(Y6YdkAMluFbwx)
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q[10000:]
	items = oo9kuULlebNgpY0Om.findall('data-src="(.*?)".*?alt="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not items: return
	M4qkBDatEIf3T,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(ww0sZkBU9JKd)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(ww0sZkBU9JKd)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="ContainerEpisodesList"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<em>(.*?)</em>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,RnV3EqPNpXTDuI7 in items:
			title = name+' - الحلقة رقم '+RnV3EqPNpXTDuI7
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,252,M4qkBDatEIf3T)
	else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+'ملف التشغيل',url,252,M4qkBDatEIf3T)
	return
def nnHQEjsYZPc45AmM(title,Y6YdkAMluFbwx):
	GS7Y93B0b8TLxueF = oo9kuULlebNgpY0Om.findall('[a-zA-Z-]+',title,oo9kuULlebNgpY0Om.DOTALL)
	if GS7Y93B0b8TLxueF: title = GS7Y93B0b8TLxueF[0]
	else: title = title+ww0sZkBU9JKd+xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
	title = title.replace('عرب سيد',G9G0YqivIfmUWO8K).replace('مباشر',G9G0YqivIfmUWO8K).replace('مشاهدة',G9G0YqivIfmUWO8K)
	title = title.replace('ٍ',G9G0YqivIfmUWO8K)
	title = title.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	return title
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	XXzvmn7ewM8yBfoxua = D7omduSeM5Gk.url
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,'url')
	headers['Referer'] = yVgLqfcUN1iO4+'/'
	mg3NutDryfoPJC9WxM,iv5ZtYQ8rf2Hm0ETWDjnPK1,ODnaR0N8UHv7Twy6jS = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[]
	Wpc3fetnXHhwaAS2QZD6qLz = oo9kuULlebNgpY0Om.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Wpc3fetnXHhwaAS2QZD6qLz: mg3NutDryfoPJC9WxM,gcfGZbI9h5a,iv5ZtYQ8rf2Hm0ETWDjnPK1,hEDd8S3OLIugvAc5HRzQkTqM60wW = Wpc3fetnXHhwaAS2QZD6qLz[0]
	else:
		Wpc3fetnXHhwaAS2QZD6qLz = oo9kuULlebNgpY0Om.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Wpc3fetnXHhwaAS2QZD6qLz:
			Y6YdkAMluFbwx,gcfGZbI9h5a = Wpc3fetnXHhwaAS2QZD6qLz[0]
			if 'watch' in gcfGZbI9h5a: mg3NutDryfoPJC9WxM = Y6YdkAMluFbwx
			else: iv5ZtYQ8rf2Hm0ETWDjnPK1 = Y6YdkAMluFbwx
	if mg3NutDryfoPJC9WxM:
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',mg3NutDryfoPJC9WxM,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-PLAY-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="WatcherArea(.*?</ul>)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = cSLKDEATk7y10ovtGZCwF[0]
			o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw.replace('</ul>','<h3>')
			o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw.replace('<h3>','<h3><h3>')
			cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('<h3>.*?(\d+)(.*?)<h3>',o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw,oo9kuULlebNgpY0Om.DOTALL)
			if not cUE5uH8hAtOmTp: cUE5uH8hAtOmTp = [(G9G0YqivIfmUWO8K,o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw)]
			for I5chimw4D1okfxlBE2UpbuHJvStsZ,BN1KdkzCmvshw in cUE5uH8hAtOmTp:
				if I5chimw4D1okfxlBE2UpbuHJvStsZ: I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
				items = oo9kuULlebNgpY0Om.findall('data-link="(.*?)".*?<span>(.*?)</span>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,name in items:
					if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
					Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__watch'+I5chimw4D1okfxlBE2UpbuHJvStsZ
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not dsGzqX4k0a8RLyc: dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if dsGzqX4k0a8RLyc:
			Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ = dsGzqX4k0a8RLyc[0]
			name = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
			if '%' in I5chimw4D1okfxlBE2UpbuHJvStsZ: Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__embed__'
			else: Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__embed____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if iv5ZtYQ8rf2Hm0ETWDjnPK1:
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',iv5ZtYQ8rf2Hm0ETWDjnPK1,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-PLAY-3rd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="DownloadArea(.*?)<script src=',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw = cSLKDEATk7y10ovtGZCwF[0]
			cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('class="DownloadServers(.*?)</ul>',o0rZYmeRgFLHsOcaNBbMEflQ34S5Jw,oo9kuULlebNgpY0Om.DOTALL)
			for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
				items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,title,I5chimw4D1okfxlBE2UpbuHJvStsZ in items:
					if not Y6YdkAMluFbwx: continue
					if 'reviewstation' in Y6YdkAMluFbwx: continue
					Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
					Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	LrhC7SUPgV5fbpT = str(ODnaR0N8UHv7Twy6jS)
	NAUjQiCGnldJDeyw0Psz4572 = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(yW70dtahIjkPCJg2TA in LrhC7SUPgV5fbpT for yW70dtahIjkPCJg2TA in NAUjQiCGnldJDeyw0Psz4572):
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if not search: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/find/?find='+search
	UUhwKBgI2nt(url,'search')
	return
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='CATEGORIES':
		if bcFXUN0LqngMKR684BWDCTY5[0]+'==' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = bcFXUN0LqngMKR684BWDCTY5[0]
		for KT9tdUH3hmiLZCEFz in range(len(bcFXUN0LqngMKR684BWDCTY5[0:-1])):
			if bcFXUN0LqngMKR684BWDCTY5[KT9tdUH3hmiLZCEFz]+'==' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = bcFXUN0LqngMKR684BWDCTY5[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+nxguK9laUWBGHIR4zEsTo7+'==0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+nxguK9laUWBGHIR4zEsTo7+'==0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'//getposts??'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='FILTERS':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'//getposts??'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XXzvmn7ewM8yBfoxua)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',AauCDOGPIN4hnrmHoX1Lv7,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',AauCDOGPIN4hnrmHoX1Lv7,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'POST',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABSEED-FILTERS_MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	JMlVnvY5uOQz6qEI = oo9kuULlebNgpY0Om.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	RuiTBCKs8wLzmQhxN6JjgdtOYXn = oo9kuULlebNgpY0Om.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	FgGiXAn5NeaTHS0mZ = JMlVnvY5uOQz6qEI+RuiTBCKs8wLzmQhxN6JjgdtOYXn
	dict = {}
	for name,TaVcxgUOBpSwX6Rl9PYkzeudt1,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		items = oo9kuULlebNgpY0Om.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('data-rate="(.*?)".*?<em>(.*?)</em>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			items = []
			for M0nQuWoaIxhSdqyV9N,yW70dtahIjkPCJg2TA in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append([M0nQuWoaIxhSdqyV9N,G9G0YqivIfmUWO8K,yW70dtahIjkPCJg2TA])
			TaVcxgUOBpSwX6Rl9PYkzeudt1 = 'rate'
			name = 'التقييم'
		else: TaVcxgUOBpSwX6Rl9PYkzeudt1 = items[0][1]
		if '==' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='CATEGORIES':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<=1:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==bcFXUN0LqngMKR684BWDCTY5[-1]: UUhwKBgI2nt(XXzvmn7ewM8yBfoxua)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'CATEGORIES___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XXzvmn7ewM8yBfoxua)
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==bcFXUN0LqngMKR684BWDCTY5[-1]: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع ',AauCDOGPIN4hnrmHoX1Lv7,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع ',XXzvmn7ewM8yBfoxua,254,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='FILTERS':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'==0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'==0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع :'+name,XXzvmn7ewM8yBfoxua,255,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for M0nQuWoaIxhSdqyV9N,HHFwtdVPy2OZ,yW70dtahIjkPCJg2TA in items:
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			if 'الكل' in M0nQuWoaIxhSdqyV9N: continue
			M0nQuWoaIxhSdqyV9N = kD2wGe8Oh4T7Cj3BMsy0(M0nQuWoaIxhSdqyV9N)
			GdTzrVD9t0cFUu5,GS7Y93B0b8TLxueF = M0nQuWoaIxhSdqyV9N,M0nQuWoaIxhSdqyV9N
			GS7Y93B0b8TLxueF = name+': '+GdTzrVD9t0cFUu5
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = GS7Y93B0b8TLxueF
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=='+GdTzrVD9t0cFUu5
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			if type=='FILTERS':
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,url,255,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='CATEGORIES' and bcFXUN0LqngMKR684BWDCTY5[-2]+'==' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'modified_filters')
				XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'//getposts??'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XjWHSnbf6NwhMgpKt4yLY7AkIT)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,AauCDOGPIN4hnrmHoX1Lv7,251,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,url,254,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
bcFXUN0LqngMKR684BWDCTY5 = ['category','country','release-year']
PxEvV69renqAkTHIhSwCGFd = ['category','country','genre','release-year','language','quality','rate']
def V8Qsn10rM6fpcRzm5wqT7Cxt2(url):
	z4dqwvASaLxjpUsbHgntETC7fhD = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',z4dqwvASaLxjpUsbHgntETC7fhD)
	url = url.replace('/category/اخرى',G9G0YqivIfmUWO8K)
	if z4dqwvASaLxjpUsbHgntETC7fhD not in url: url = url+z4dqwvASaLxjpUsbHgntETC7fhD
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&&')
	R9h6MqBxlsEpNztI0AU,lOaCfpSNzejn = {},G9G0YqivIfmUWO8K
	if '==' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('==')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	for key in PxEvV69renqAkTHIhSwCGFd:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&&'+key+'=='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&&'+key+'=='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&&')
	return lOaCfpSNzejn
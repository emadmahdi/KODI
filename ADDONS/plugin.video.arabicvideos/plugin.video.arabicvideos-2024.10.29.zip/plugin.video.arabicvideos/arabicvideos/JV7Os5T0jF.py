# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'FASELHD2'
headers = {'User-Agent':G9G0YqivIfmUWO8K}
TdtCLWYSJNK8zOb = '_FH2_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['wwe']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==590: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==591: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==592: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==593: tRojAyBgfDH37eLCwP4dWl = HbfhT3tmkAPMJCENld672jGn(url,text)
	elif mode==599: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	sg0IMYl698kyvmfVASQU4K13Z2L = ffVP3AK5RqhkgYnjZoNis
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',sg0IMYl698kyvmfVASQU4K13Z2L,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD2-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',sg0IMYl698kyvmfVASQU4K13Z2L,599,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',sg0IMYl698kyvmfVASQU4K13Z2L,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured1')
	items = oo9kuULlebNgpY0Om.findall('<strong>(.*?)</strong>.*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for title,Y6YdkAMluFbwx in items:
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details1')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-menu"(.*?)header-social',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		KVq2tMs6enifCThSZB = oo9kuULlebNgpY0Om.findall('<li (.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for hifDqHbzE39x5Jja7wsd8OeTvotYIB in KVq2tMs6enifCThSZB:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',hifDqHbzE39x5Jja7wsd8OeTvotYIB,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details2')
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD2-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	MALBS0ixsEmkV7OvK1Re5pThc4JtG = 0
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"archive-slider(.*?)<h4>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO: duYhmVFABjltoJ9PcE = msFSK7j9MrcoPafDnkNO[0]
	else: duYhmVFABjltoJ9PcE = G9G0YqivIfmUWO8K
	if type=='featured1':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"slider-carousel"(.*?)</container>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		L4TFi6QA2BmW,JoSpAl1HIVd0f,dsGzqX4k0a8RLyc = zip(*items)
		items = zip(dsGzqX4k0a8RLyc,L4TFi6QA2BmW,JoSpAl1HIVd0f)
	elif type=='featured2':
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='filters':
		cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in duYhmVFABjltoJ9PcE:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<h4>(.*?)</h4>(.*?)</container>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مميزة',url,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured2')
		title = cSLKDEATk7y10ovtGZCwF[0][0]
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details3')
		return
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<h4>(.*?)</h4>(.*?)</container>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		title,BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if any(yW70dtahIjkPCJg2TA in title.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
		title = title.strip(ww0sZkBU9JKd)
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if '/movseries/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,591,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and type==G9G0YqivIfmUWO8K:
			title = '_MOD_'+RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,593,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,592,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,593,M4qkBDatEIf3T)
	if type=='filters':
		CoX5H3D7jVWGapxst = oo9kuULlebNgpY0Om.findall('"more_button_page":(.*?),',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if CoX5H3D7jVWGapxst:
			count = CoX5H3D7jVWGapxst[0]
			Y6YdkAMluFbwx = url+'/offset/'+count
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة أخرى',Y6YdkAMluFbwx,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
	elif 'details' in type:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = 'صفحة '+kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,591,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details4')
	return
def HbfhT3tmkAPMJCENld672jGn(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD2-SEASONS_EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	KmsdJXWHbDET9AankUCeMutfvQj = False
	if not type:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<seasons(.*?)</seasons>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if len(items)>1:
				sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
				KmsdJXWHbDET9AankUCeMutfvQj = True
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
					title = kD2wGe8Oh4T7Cj3BMsy0(title)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,593,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,'episodes')
	if type=='episodes' or not KmsdJXWHbDET9AankUCeMutfvQj:
		Vy1U0koJLPFhxe2TS = oo9kuULlebNgpY0Om.findall('<bkز*?image:url\((.*?)\)"></bk>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Vy1U0koJLPFhxe2TS: M4qkBDatEIf3T = Vy1U0koJLPFhxe2TS[0]
		else: M4qkBDatEIf3T = G9G0YqivIfmUWO8K
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<all-episodes(.*?)</all-episodes>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = title.strip(ww0sZkBU9JKd)
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,592,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,eEOn6HTlmRa,EsHlvk9Zn2tIgU7KRLwGaNQbCcjB = [],[],[]
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD2-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	pwtcGBTPo7k3nqWmsFbxS = oo9kuULlebNgpY0Om.findall('العمر :.*?<strong">(.*?)</strong>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if pwtcGBTPo7k3nqWmsFbxS and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,pwtcGBTPo7k3nqWmsFbxS): return
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<iframe src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named=__embed')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<slice-title(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-url="(.*?)".*?</i>(.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			name = name.strip(ww0sZkBU9JKd)
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__watch')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<downloads(.*?)</downloads>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</div>(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__download')
	for Fk9KTLaxOms6o84 in ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
		Y6YdkAMluFbwx,name = Fk9KTLaxOms6o84.split('?named')
		if Y6YdkAMluFbwx not in eEOn6HTlmRa:
			eEOn6HTlmRa.append(Y6YdkAMluFbwx)
			EsHlvk9Zn2tIgU7KRLwGaNQbCcjB.append(Fk9KTLaxOms6o84)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(EsHlvk9Zn2tIgU7KRLwGaNQbCcjB,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	sg0IMYl698kyvmfVASQU4K13Z2L = ffVP3AK5RqhkgYnjZoNis
	url = sg0IMYl698kyvmfVASQU4K13Z2L+'/?s='+search
	UUhwKBgI2nt(url,'details5')
	return
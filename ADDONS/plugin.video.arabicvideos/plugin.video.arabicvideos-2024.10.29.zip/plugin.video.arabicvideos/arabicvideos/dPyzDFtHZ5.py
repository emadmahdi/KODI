# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ARABICTOONS'
TdtCLWYSJNK8zOb = '_ART_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==730: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==731: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==732: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==733: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==734: tRojAyBgfDH37eLCwP4dWl = CMkwoxXd5LnJNObryTR1WzmB(url)
	elif mode==735: tRojAyBgfDH37eLCwP4dWl = V2VJYluEqx90Nf(url)
	elif mode==739: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,739,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'افلام',ffVP3AK5RqhkgYnjZoNis+'/movies.php',731)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات',ffVP3AK5RqhkgYnjZoNis+'/cartoon.php',734)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات مميزة',ffVP3AK5RqhkgYnjZoNis+'/top.php',735)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أحدث الأفلام المضافة',ffVP3AK5RqhkgYnjZoNis,731,'','','LATEST_MOVIES')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أحدث المسلسلات المضافة',ffVP3AK5RqhkgYnjZoNis,731,'','','LATEST_SERIES')
	return
def CMkwoxXd5LnJNObryTR1WzmB(url):
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الكل',url,731)
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-SERIES_SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('label="navigation"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall("href='(.*?)'>(.*?)</a>",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = 'حرف '+title
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,731)
	return
def V2VJYluEqx90Nf(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-SERIES_FEATURED-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="slider"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for title,Y6YdkAMluFbwx,M4qkBDatEIf3T in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
			title = title.strip(ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,733,M4qkBDatEIf3T)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("class='moviesBlocks(.*?)list-group",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if A0AzrLupg8h1s=='LATEST_SERIES': BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
	else: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
		title = title.strip(ww0sZkBU9JKd)
		if 'movies.php' in url or A0AzrLupg8h1s=='LATEST_MOVIES':
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,732,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,733,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[-1]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title.strip(ww0sZkBU9JKd)
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,731)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("class='moviesBlocks(.*?)script",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for title,Y6YdkAMluFbwx,M4qkBDatEIf3T,e2eGmXWys8Kdlj4qiFb7pDf in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
			title = title.strip(ww0sZkBU9JKd)
			title = title+ww0sZkBU9JKd+e2eGmXWys8Kdlj4qiFb7pDf.strip(ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,732,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('source src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if dsGzqX4k0a8RLyc:
		Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[0]
		if 'Referer=' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = Y6YdkAMluFbwx+'|Referer=https://www.arabic-toons.com'
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named=__embed')
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'%20')
	ODnaR0N8UHv7Twy6jS = [G9G0YqivIfmUWO8K,'m']
	Y4aIzyVXN2j = ['مسلسلات','افلام']
	if showDialogs:
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر النوع المطلوب:', Y4aIzyVXN2j)
		if PXeEIRkdShOGm45lbLJc2B38s==-1: return
	else: PXeEIRkdShOGm45lbLJc2B38s = 0
	type = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	url = ffVP3AK5RqhkgYnjZoNis+'/livesearch.php?'+type+'&q='+search
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ARABICTOONS-SEARCH-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)
		if type=='m': Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,732)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,733)
	return
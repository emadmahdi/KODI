# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ALARAB'
headers = {'User-Agent':G9G0YqivIfmUWO8K}
TdtCLWYSJNK8zOb = '_KLA_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==10: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==11: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==12: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==13: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==14: tRojAyBgfDH37eLCwP4dWl = HDY16Cs8Q2qxREhZ3Iw()
	elif mode==15: tRojAyBgfDH37eLCwP4dWl = QzO4HCD3ma()
	elif mode==16: tRojAyBgfDH37eLCwP4dWl = vvrQtSqguG8syYz1Roe()
	elif mode==19: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,19,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'آخر الإضافات',G9G0YqivIfmUWO8K,14)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات رمضان',G9G0YqivIfmUWO8K,15)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'ALARAB-MENU-1st')
	cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('id="nav-slider"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	vLISGBd2pOhMWPtVRcmKnw3AXHQE = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',vLISGBd2pOhMWPtVRcmKnw3AXHQE,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,11)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="navbar"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	duYhmVFABjltoJ9PcE = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,11)
	return GagwMT6q3oc7UZ2Q
def QzO4HCD3ma():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'جميع المسلسلات العربية',ffVP3AK5RqhkgYnjZoNis+'/view-8/مسلسلات-عربية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات السنة الأخيرة',G9G0YqivIfmUWO8K,16)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان الأخيرة 1',ffVP3AK5RqhkgYnjZoNis+'/view-8/مسلسلات-رمضان-2022',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان الأخيرة 2',ffVP3AK5RqhkgYnjZoNis+'/view-8/مسلسلات-رمضان-2023',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2023',ffVP3AK5RqhkgYnjZoNis+'/ramadan2023/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2022',ffVP3AK5RqhkgYnjZoNis+'/ramadan2022/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2021',ffVP3AK5RqhkgYnjZoNis+'/ramadan2021/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2020',ffVP3AK5RqhkgYnjZoNis+'/ramadan2020/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2019',ffVP3AK5RqhkgYnjZoNis+'/ramadan2019/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2018',ffVP3AK5RqhkgYnjZoNis+'/ramadan2018/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2017',ffVP3AK5RqhkgYnjZoNis+'/ramadan2017/مصرية',11)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات رمضان 2016',ffVP3AK5RqhkgYnjZoNis+'/ramadan2016/مصرية',11)
	return
def HDY16Cs8Q2qxREhZ3Iw():
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,True,'ALARAB-LATEST-1st')
	cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('heading-top(.*?)div class=',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]+cSLKDEATk7y10ovtGZCwF[1]
	items=oo9kuULlebNgpY0Om.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		url = ffVP3AK5RqhkgYnjZoNis + Y6YdkAMluFbwx
		if 'series' in url: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,11,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,url,12,M4qkBDatEIf3T)
	return
def UUhwKBgI2nt(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,True,True,'ALARAB-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('video-category(.*?)right_content',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	a2brFZlqWO8hK1UfAmLVz = False
	items = oo9kuULlebNgpY0Om.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC,hdmcLJ2WMbZ4ASgOGP80s = [],[]
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if title==G9G0YqivIfmUWO8K: title = Y6YdkAMluFbwx.split('/')[-1].replace('-',ww0sZkBU9JKd)
		zzp23C7fBiwrLHhdYt9a = oo9kuULlebNgpY0Om.findall('(\d+)',title,oo9kuULlebNgpY0Om.DOTALL)
		if zzp23C7fBiwrLHhdYt9a: zzp23C7fBiwrLHhdYt9a = int(zzp23C7fBiwrLHhdYt9a[0])
		else: zzp23C7fBiwrLHhdYt9a = 0
		hdmcLJ2WMbZ4ASgOGP80s.append([M4qkBDatEIf3T,Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a])
	hdmcLJ2WMbZ4ASgOGP80s = sorted(hdmcLJ2WMbZ4ASgOGP80s, reverse=True, key=lambda key: key[3])
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a in hdmcLJ2WMbZ4ASgOGP80s:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis + Y6YdkAMluFbwx
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',G9G0YqivIfmUWO8K)
		title = title.replace('عالية على العرب',G9G0YqivIfmUWO8K)
		title = title.replace('مشاهدة مباشرة',G9G0YqivIfmUWO8K)
		title = title.replace('اون لاين',G9G0YqivIfmUWO8K)
		title = title.replace('اونلاين',G9G0YqivIfmUWO8K)
		title = title.replace('بجودة عالية',G9G0YqivIfmUWO8K)
		title = title.replace('جودة عالية',G9G0YqivIfmUWO8K)
		title = title.replace('بدون تحميل',G9G0YqivIfmUWO8K)
		title = title.replace('على العرب',G9G0YqivIfmUWO8K)
		title = title.replace('مباشرة',G9G0YqivIfmUWO8K)
		title = title.strip(ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		title = '_MOD_'+title
		GS7Y93B0b8TLxueF = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7: GS7Y93B0b8TLxueF = RnV3EqPNpXTDuI7[0]
		if GS7Y93B0b8TLxueF not in ehHpxSUAZnVITs4y5XjDKb8zC:
			ehHpxSUAZnVITs4y5XjDKb8zC.append(GS7Y93B0b8TLxueF)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,Y6YdkAMluFbwx,13,M4qkBDatEIf3T)
				a2brFZlqWO8hK1UfAmLVz = True
			elif 'series' in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,11,M4qkBDatEIf3T)
				a2brFZlqWO8hK1UfAmLVz = True
			else:
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,12,M4qkBDatEIf3T)
				a2brFZlqWO8hK1UfAmLVz = True
	if a2brFZlqWO8hK1UfAmLVz:
		items = oo9kuULlebNgpY0Om.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,eehFlSEjHioyAWpLqZXt79 in items:
			url = ffVP3AK5RqhkgYnjZoNis + Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+eehFlSEjHioyAWpLqZXt79,url,11)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,True,'ALARAB-EPISODES-1st')
	TLEKHoau3C7xrVOi0 = oo9kuULlebNgpY0Om.findall('href="(/series.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis+TLEKHoau3C7xrVOi0[0]
	tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(XXzvmn7ewM8yBfoxua)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(HpjLKS83swXDzVInEf2xUZaCuNbR9d,url,G9G0YqivIfmUWO8K,headers,True,'ALARAB-PLAY-1st')
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('class="resp-iframe" src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua:
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('^(http.*?)(http.*?)$',XXzvmn7ewM8yBfoxua,oo9kuULlebNgpY0Om.DOTALL)
		if dsGzqX4k0a8RLyc:
			n6m2IWeNsk7i = dsGzqX4k0a8RLyc[0][0]
			CYdSsVq96ZiGceKkmr7UonX8lFLgIW,OuRNno7VtTxAcIKUSf14Qa0EhyBe = dsGzqX4k0a8RLyc[0][1].rsplit('/',1)
			XjWHSnbf6NwhMgpKt4yLY7AkIT = CYdSsVq96ZiGceKkmr7UonX8lFLgIW+'?named=__watch'
			ODnaR0N8UHv7Twy6jS.append(XjWHSnbf6NwhMgpKt4yLY7AkIT)
			AauCDOGPIN4hnrmHoX1Lv7 = n6m2IWeNsk7i+OuRNno7VtTxAcIKUSf14Qa0EhyBe
		else:
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,False,'ALARAB-PLAY-2nd')
			XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('"src": "(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if XXzvmn7ewM8yBfoxua:
				XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]+'?named=__watch__m3u8'
				ODnaR0N8UHv7Twy6jS.append(XXzvmn7ewM8yBfoxua)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('searchBox(.*?)<style>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if XXzvmn7ewM8yBfoxua:
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]+'?named=__watch'
			ODnaR0N8UHv7Twy6jS.append(XXzvmn7ewM8yBfoxua)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def vvrQtSqguG8syYz1Roe():
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,True,'ALARAB-RAMADAN-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="content_sec"(.*?)id="left_content"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	FacmI0Q1RDxEhn2NXBro5YUO7w = oo9kuULlebNgpY0Om.findall('/ramadan([0-9]+)/',str(items),oo9kuULlebNgpY0Om.DOTALL)
	FacmI0Q1RDxEhn2NXBro5YUO7w = FacmI0Q1RDxEhn2NXBro5YUO7w[0]
	for Y6YdkAMluFbwx,title in items:
		url = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)+ww0sZkBU9JKd+FacmI0Q1RDxEhn2NXBro5YUO7w
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,11)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis + "/q/" + HG9ZQqnw71y0JmrDLx
	tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	return
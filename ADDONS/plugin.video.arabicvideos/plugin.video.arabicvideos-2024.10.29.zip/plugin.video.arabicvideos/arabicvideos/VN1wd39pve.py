# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ARBLIONZ'
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
TdtCLWYSJNK8zOb = '_ARL_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==200: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==201: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==202: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==203: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==204: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'FILTERS___'+text)
	elif mode==205: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'CATEGORIES___'+text)
	elif mode==209: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,209,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',ffVP3AK5RqhkgYnjZoNis,205)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',ffVP3AK5RqhkgYnjZoNis,204)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مميزة',ffVP3AK5RqhkgYnjZoNis+'??trending',201)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أفلام مميزة',ffVP3AK5RqhkgYnjZoNis+'??trending_movies',201)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات مميزة',ffVP3AK5RqhkgYnjZoNis+'??trending_series',201)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الصفحة الرئيسية',ffVP3AK5RqhkgYnjZoNis+'??mainpage',201)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,True,G9G0YqivIfmUWO8K,'ARBLIONZ-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('categories-tabs(.*?)MainRow',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-get="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for filter,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/ajax/home/more?filter='+filter
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,201)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('navigation-menu(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)
		if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,201)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url):
	if '??' in url: url,type = url.split('??')
	else: type = G9G0YqivIfmUWO8K
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,True,G9G0YqivIfmUWO8K,'ARBLIONZ-TITLES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	if 'getposts' in url: cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q]
	elif type=='trending':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='trending_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='trending_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='111mainpage':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="container page-content"(.*?)class="tabs"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('page-content(.*?)main-footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	vvWOPDzyKX09YaRfmhVH7UdiBS = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = oo9kuULlebNgpY0Om.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items:
		items = oo9kuULlebNgpY0Om.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		dsGzqX4k0a8RLyc,L4TFi6QA2BmW,JoSpAl1HIVd0f = zip(*items)
		items = zip(L4TFi6QA2BmW,dsGzqX4k0a8RLyc,JoSpAl1HIVd0f)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if '/series/' in Y6YdkAMluFbwx: continue
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.strip('/')
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		title = title.strip(ww0sZkBU9JKd)
		if '/film/' in Y6YdkAMluFbwx or any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in vvWOPDzyKX09YaRfmhVH7UdiBS):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,202,M4qkBDatEIf3T)
		elif '/episode/' in Y6YdkAMluFbwx and 'الحلقة' in title:
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,203,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/pack/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx+'/films',201,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,203,M4qkBDatEIf3T)
	if type in [G9G0YqivIfmUWO8K,'mainpage']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href=["\'](http.*?)["\'].*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = kD2wGe8Oh4T7Cj3BMsy0(Y6YdkAMluFbwx)
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
				if 'search?s=' in url:
					oZfep9J7bdmrwaEVMqgOn8BPUhXHyC = Y6YdkAMluFbwx.split('page=')[1]
					fp016mJHWNBiIrwyKT7od2O9VS3G = url.split('page=')[1]
					Y6YdkAMluFbwx = url.replace('page='+fp016mJHWNBiIrwyKT7od2O9VS3G,'page='+oZfep9J7bdmrwaEVMqgOn8BPUhXHyC)
				if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,201)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	dCHEukZBcqWgfRhmK,items,hdmcLJ2WMbZ4ASgOGP80s = -1,[],[]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,True,G9G0YqivIfmUWO8K,'ARBLIONZ-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('ti-list-numbered(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		hdmcLJ2WMbZ4ASgOGP80s = []
		cUE5uH8hAtOmTp = G9G0YqivIfmUWO8K.join(cSLKDEATk7y10ovtGZCwF)
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"',cUE5uH8hAtOmTp,oo9kuULlebNgpY0Om.DOTALL)
	items.append(url)
	items = set(items)
	for Y6YdkAMluFbwx in items:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.strip('/')
		title = '_MOD_' + Y6YdkAMluFbwx.split('/')[-1].replace('-',ww0sZkBU9JKd)
		zzp23C7fBiwrLHhdYt9a = oo9kuULlebNgpY0Om.findall('الحلقة-(\d+)',Y6YdkAMluFbwx.split('/')[-1],oo9kuULlebNgpY0Om.DOTALL)
		if zzp23C7fBiwrLHhdYt9a: zzp23C7fBiwrLHhdYt9a = zzp23C7fBiwrLHhdYt9a[0]
		else: zzp23C7fBiwrLHhdYt9a = '0'
		hdmcLJ2WMbZ4ASgOGP80s.append([Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a])
	items = sorted(hdmcLJ2WMbZ4ASgOGP80s, reverse=False, key=lambda key: int(key[2]))
	IIvy3KOMdQG2xpUmb6eESPXlCuR7qw = str(items).count('/season/')
	dCHEukZBcqWgfRhmK = str(items).count('/episode/')
	if IIvy3KOMdQG2xpUmb6eESPXlCuR7qw>1 and dCHEukZBcqWgfRhmK>0 and '/season/' not in url:
		for Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a in items:
			if '/season/' in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,203)
	else:
		for Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a in items:
			if '/season/' not in Y6YdkAMluFbwx:
				title = aKAyEnjxIlzZtCTv(title)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,202)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('/')
	vkPoTrNVqlI4xX6As1Ogae3UpSm = ffVP3AK5RqhkgYnjZoNis
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,True,True,'ARBLIONZ-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	id = oo9kuULlebNgpY0Om.findall('postId:"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not id: id = oo9kuULlebNgpY0Om.findall('post_id=(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not id: id = oo9kuULlebNgpY0Om.findall('post-id="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if id: id = id[0]
	if '/watch/' in GagwMT6q3oc7UZ2Q:
		XXzvmn7ewM8yBfoxua = url.replace(mtMexSFLnkwhbAaP9pgDduCRBi2[3],'watch')
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,True,True,'ARBLIONZ-PLAY-2nd')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		VVevamF18rQNYhIp5MSZos = oo9kuULlebNgpY0Om.findall('data-embedd="(.*?)".*?alt="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('data-embedd=".*?(http.*?)("|&quot;)',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		E9zSRAvUHtBlhfFNmWYDJs5LgQ = oo9kuULlebNgpY0Om.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt)
		YVlFS1PibyUsNRkCn = oo9kuULlebNgpY0Om.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		WmrLCGMsuNAq2H = oo9kuULlebNgpY0Om.findall('server="(.*?)".*?<span>(.*?)<',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		items = VVevamF18rQNYhIp5MSZos+qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv+E9zSRAvUHtBlhfFNmWYDJs5LgQ+WoMm7Vx8uZpPQR5kwdr0j+YVlFS1PibyUsNRkCn+WmrLCGMsuNAq2H
		if not items:
			items = oo9kuULlebNgpY0Om.findall('<span>(.*?)</span>.*?src="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
			items = [(Ibr61AOhmk02WFsGLjvfU,qIjOPGKdtixmreBTkuz9gAXW14y) for qIjOPGKdtixmreBTkuz9gAXW14y,Ibr61AOhmk02WFsGLjvfU in items]
		for yVgLqfcUN1iO4,title in items:
			if '.png' in yVgLqfcUN1iO4: continue
			if '.jpg' in yVgLqfcUN1iO4: continue
			if '&quot;' in yVgLqfcUN1iO4: continue
			I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall('\d\d\d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if I5chimw4D1okfxlBE2UpbuHJvStsZ:
				I5chimw4D1okfxlBE2UpbuHJvStsZ = I5chimw4D1okfxlBE2UpbuHJvStsZ[0]
				if I5chimw4D1okfxlBE2UpbuHJvStsZ in title: title = title.replace(I5chimw4D1okfxlBE2UpbuHJvStsZ+'p',G9G0YqivIfmUWO8K).replace(I5chimw4D1okfxlBE2UpbuHJvStsZ,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			else: I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
			if yVgLqfcUN1iO4.isdigit():
				Y6YdkAMluFbwx = vkPoTrNVqlI4xX6As1Ogae3UpSm+'/?postid='+id+'&serverid='+yVgLqfcUN1iO4+'?named='+title+'__watch'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			else:
				if 'http' not in yVgLqfcUN1iO4: yVgLqfcUN1iO4 = 'http:'+yVgLqfcUN1iO4
				I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall('\d\d\d+',title,oo9kuULlebNgpY0Om.DOTALL)
				if I5chimw4D1okfxlBE2UpbuHJvStsZ: I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ[0]
				else: I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
				Y6YdkAMluFbwx = yVgLqfcUN1iO4+'?named=__watch'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if 'DownloadNow' in GagwMT6q3oc7UZ2Q:
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		XXzvmn7ewM8yBfoxua = url+'/download'
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,True,G9G0YqivIfmUWO8K,'ARBLIONZ-PLAY-3rd')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<ul class="download-items(.*?)</ul>',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		for BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			items = oo9kuULlebNgpY0Om.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,name,I5chimw4D1okfxlBE2UpbuHJvStsZ in items:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__download'+'____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	elif '/download/' in GagwMT6q3oc7UZ2Q:
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = { 'User-Agent':G9G0YqivIfmUWO8K , 'X-Requested-With':'XMLHttpRequest' }
		XXzvmn7ewM8yBfoxua = vkPoTrNVqlI4xX6As1Ogae3UpSm + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,True,True,'ARBLIONZ-PLAY-4th')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		if 'download-btns' in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt:
			E9zSRAvUHtBlhfFNmWYDJs5LgQ = oo9kuULlebNgpY0Om.findall('href="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			for XjWHSnbf6NwhMgpKt4yLY7AkIT in E9zSRAvUHtBlhfFNmWYDJs5LgQ:
				if '/page/' not in XjWHSnbf6NwhMgpKt4yLY7AkIT and 'http' in XjWHSnbf6NwhMgpKt4yLY7AkIT:
					XjWHSnbf6NwhMgpKt4yLY7AkIT = XjWHSnbf6NwhMgpKt4yLY7AkIT+'?named=__download'
					ODnaR0N8UHv7Twy6jS.append(XjWHSnbf6NwhMgpKt4yLY7AkIT)
				elif '/page/' in XjWHSnbf6NwhMgpKt4yLY7AkIT:
					I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
					D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,headers,True,True,'ARBLIONZ-PLAY-5th')
					oXZQasye6HMLA9K = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
					cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('(<strong>.*?)-----',oXZQasye6HMLA9K,oo9kuULlebNgpY0Om.DOTALL)
					for EIw0C9VoX5ryeKN2pQ81RasZ7WHT4 in cUE5uH8hAtOmTp:
						TZS2fpdRqr7L6DoFaUjQJuVHcl = G9G0YqivIfmUWO8K
						WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('<strong>(.*?)</strong>',EIw0C9VoX5ryeKN2pQ81RasZ7WHT4,oo9kuULlebNgpY0Om.DOTALL)
						for VFMrY9DWTHaR8 in WoMm7Vx8uZpPQR5kwdr0j:
							XX2Btn97vEfkCjcuWs = oo9kuULlebNgpY0Om.findall('\d\d\d+',VFMrY9DWTHaR8,oo9kuULlebNgpY0Om.DOTALL)
							if XX2Btn97vEfkCjcuWs:
								I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+XX2Btn97vEfkCjcuWs[0]
								break
						for VFMrY9DWTHaR8 in reversed(WoMm7Vx8uZpPQR5kwdr0j):
							XX2Btn97vEfkCjcuWs = oo9kuULlebNgpY0Om.findall('\w\w+',VFMrY9DWTHaR8,oo9kuULlebNgpY0Om.DOTALL)
							if XX2Btn97vEfkCjcuWs:
								TZS2fpdRqr7L6DoFaUjQJuVHcl = XX2Btn97vEfkCjcuWs[0]
								break
						YVlFS1PibyUsNRkCn = oo9kuULlebNgpY0Om.findall('href="(.*?)"',EIw0C9VoX5ryeKN2pQ81RasZ7WHT4,oo9kuULlebNgpY0Om.DOTALL)
						for ZZpYGLWu4inNbCR5K in YVlFS1PibyUsNRkCn:
							ZZpYGLWu4inNbCR5K = ZZpYGLWu4inNbCR5K+'?named='+TZS2fpdRqr7L6DoFaUjQJuVHcl+'__download'+I5chimw4D1okfxlBE2UpbuHJvStsZ
							ODnaR0N8UHv7Twy6jS.append(ZZpYGLWu4inNbCR5K)
		elif 'slow-motion' in ssVw9GhqHbuQD5On3YxeKPWFkgjRJt:
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ssVw9GhqHbuQD5On3YxeKPWFkgjRJt.replace('<h6 ','==END== ==START==')+'==END=='
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ssVw9GhqHbuQD5On3YxeKPWFkgjRJt.replace('<h3 ','==END== ==START==')+'==END=='
			vxQCmz2Zs3XWBGMVunSrah5 = oo9kuULlebNgpY0Om.findall('==START==(.*?)==END==',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if vxQCmz2Zs3XWBGMVunSrah5:
				for EIw0C9VoX5ryeKN2pQ81RasZ7WHT4 in vxQCmz2Zs3XWBGMVunSrah5:
					if 'href=' not in EIw0C9VoX5ryeKN2pQ81RasZ7WHT4: continue
					S7Zi6o0cxnO9Y4 = G9G0YqivIfmUWO8K
					WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('slow-motion">(.*?)<',EIw0C9VoX5ryeKN2pQ81RasZ7WHT4,oo9kuULlebNgpY0Om.DOTALL)
					for VFMrY9DWTHaR8 in WoMm7Vx8uZpPQR5kwdr0j:
						XX2Btn97vEfkCjcuWs = oo9kuULlebNgpY0Om.findall('\d\d\d+',VFMrY9DWTHaR8,oo9kuULlebNgpY0Om.DOTALL)
						if XX2Btn97vEfkCjcuWs:
							S7Zi6o0cxnO9Y4 = '____'+XX2Btn97vEfkCjcuWs[0]
							break
					WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('<td>(.*?)</td>.*?href="(http.*?)"',EIw0C9VoX5ryeKN2pQ81RasZ7WHT4,oo9kuULlebNgpY0Om.DOTALL)
					if WoMm7Vx8uZpPQR5kwdr0j:
						for TZS2fpdRqr7L6DoFaUjQJuVHcl,Bidt2DRzjI9 in WoMm7Vx8uZpPQR5kwdr0j:
							Bidt2DRzjI9 = Bidt2DRzjI9+'?named='+TZS2fpdRqr7L6DoFaUjQJuVHcl+'__download'+S7Zi6o0cxnO9Y4
							ODnaR0N8UHv7Twy6jS.append(Bidt2DRzjI9)
					else:
						WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('href="(.*?http.*?)".*?name">(.*?)<',EIw0C9VoX5ryeKN2pQ81RasZ7WHT4,oo9kuULlebNgpY0Om.DOTALL)
						for Bidt2DRzjI9,TZS2fpdRqr7L6DoFaUjQJuVHcl in WoMm7Vx8uZpPQR5kwdr0j:
							Bidt2DRzjI9 = Bidt2DRzjI9.strip(ww0sZkBU9JKd)+'?named='+TZS2fpdRqr7L6DoFaUjQJuVHcl+'__download'+S7Zi6o0cxnO9Y4
							ODnaR0N8UHv7Twy6jS.append(Bidt2DRzjI9)
			else:
				WoMm7Vx8uZpPQR5kwdr0j = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(\w+)<',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
				for Bidt2DRzjI9,TZS2fpdRqr7L6DoFaUjQJuVHcl in WoMm7Vx8uZpPQR5kwdr0j:
					Bidt2DRzjI9 = Bidt2DRzjI9.strip(ww0sZkBU9JKd)+'?named='+TZS2fpdRqr7L6DoFaUjQJuVHcl+'__download'
					ODnaR0N8UHv7Twy6jS.append(Bidt2DRzjI9)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/alz',G9G0YqivIfmUWO8K,headers,True,G9G0YqivIfmUWO8K,'ARBLIONZ-SEARCH-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('chevron-select(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if showDialogs and cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		BBzv3TGJyqheS1E8OZkj,SfZnHPUoMuiEsQB9zAy4 = [],[]
		for nxguK9laUWBGHIR4zEsTo7,title in items:
			BBzv3TGJyqheS1E8OZkj.append(nxguK9laUWBGHIR4zEsTo7)
			SfZnHPUoMuiEsQB9zAy4.append(title)
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر الفلتر المناسب:', SfZnHPUoMuiEsQB9zAy4)
		if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
		nxguK9laUWBGHIR4zEsTo7 = BBzv3TGJyqheS1E8OZkj[PXeEIRkdShOGm45lbLJc2B38s]
	else: nxguK9laUWBGHIR4zEsTo7 = G9G0YqivIfmUWO8K
	url = ffVP3AK5RqhkgYnjZoNis + '/search?s='+search+'&category='+nxguK9laUWBGHIR4zEsTo7+'&page=1'
	UUhwKBgI2nt(url)
	return
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	IzbOhN0Flo8j4gtdcVewMB = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='CATEGORIES':
		if IzbOhN0Flo8j4gtdcVewMB[0]+'=' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[0]
		for KT9tdUH3hmiLZCEFz in range(len(IzbOhN0Flo8j4gtdcVewMB[0:-1])):
			if IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz]+'=' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'/getposts?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='FILTERS':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'/getposts?'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',XXzvmn7ewM8yBfoxua,201)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',XXzvmn7ewM8yBfoxua,201)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url+'/alz',G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'ARBLIONZ-FILTERS_MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('AjaxFilteringData(.*?)FilterWord',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	dict = {}
	for name,TaVcxgUOBpSwX6Rl9PYkzeudt1,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		name = name.replace('اختيار ',G9G0YqivIfmUWO8K)
		name = name.replace('سنة الإنتاج','السنة')
		items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?</div>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if '=' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='CATEGORIES':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<=1:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: UUhwKBgI2nt(XXzvmn7ewM8yBfoxua)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'CATEGORIES___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع ',XXzvmn7ewM8yBfoxua,201)
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع ',XXzvmn7ewM8yBfoxua,205,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='FILTERS':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع :'+name,XXzvmn7ewM8yBfoxua,204,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			M0nQuWoaIxhSdqyV9N = M0nQuWoaIxhSdqyV9N.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K)
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = M0nQuWoaIxhSdqyV9N
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+M0nQuWoaIxhSdqyV9N
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			title = M0nQuWoaIxhSdqyV9N+' :'#+dict[TaVcxgUOBpSwX6Rl9PYkzeudt1]['0']
			title = M0nQuWoaIxhSdqyV9N+' :'+name
			if type=='FILTERS': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,204,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='CATEGORIES' and IzbOhN0Flo8j4gtdcVewMB[-2]+'=' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'modified_filters')
				XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'/getposts?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,XjWHSnbf6NwhMgpKt4yLY7AkIT,201)
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,205,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.replace('=&','=0&')
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&')
	R9h6MqBxlsEpNztI0AU = {}
	if '=' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('=')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = G9G0YqivIfmUWO8K
	KH5NQOvAkRje = ['category','release-year','genre','Quality']
	for key in KH5NQOvAkRje:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&')
	lOaCfpSNzejn = lOaCfpSNzejn.replace('=0','=')
	lOaCfpSNzejn = lOaCfpSNzejn.replace('Quality','quality')
	return lOaCfpSNzejn
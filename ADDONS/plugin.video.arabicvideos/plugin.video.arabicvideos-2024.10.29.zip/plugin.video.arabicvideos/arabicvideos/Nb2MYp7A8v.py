# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'FAJERSHOW'
TdtCLWYSJNK8zOb = '_FJS_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==390: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==391: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==392: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==393: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==399: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,399,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FAJERSHOW-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = oo9kuULlebNgpY0Om.findall('<header>.*?<h2>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for JXKAgPztneLxQh in range(len(items)):
		title = items[JXKAgPztneLxQh]
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,ffVP3AK5RqhkgYnjZoNis,391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'latest'+str(JXKAgPztneLxQh))
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مختارات عشوائية',ffVP3AK5RqhkgYnjZoNis,391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'randoms')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أعلى الأفلام تقييماً',ffVP3AK5RqhkgYnjZoNis,391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'top_imdb_movies')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أعلى المسلسلات تقييماً',ffVP3AK5RqhkgYnjZoNis,391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'top_imdb_series')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أفلام مميزة',ffVP3AK5RqhkgYnjZoNis+'/movies',391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured_movies')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات مميزة',ffVP3AK5RqhkgYnjZoNis+'/tvshows',391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured_tvshows')
	BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="menu"(.*?)id="contenedor"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw += cSLKDEATk7y10ovtGZCwF[0]
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/movies',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FAJERSHOW-MENU-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="releases"(.*?)aside',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw += cSLKDEATk7y10ovtGZCwF[0]
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	n6m2IWeNsk7i = True
	for Y6YdkAMluFbwx,title in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if title=='الأعلى مشاهدة':
			if n6m2IWeNsk7i:
				title = 'الافلام '+title
				n6m2IWeNsk7i = False
			else: title = 'المسلسلات '+title
		if title not in tlcXBJEfIHF02vQ6yxSom9z1:
			if title=='أفلام': Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,ffVP3AK5RqhkgYnjZoNis+'/movies',391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'all_movies_tvshows')
			elif title=='مسلسلات': Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,ffVP3AK5RqhkgYnjZoNis+'/tvshows',391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'all_movies_tvshows')
			else: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,391)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,type):
	BN1KdkzCmvshw,items = [],[]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FAJERSHOW-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if type in ['featured_movies','featured_tvshows']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="content"(.*?)id="archive-content"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif type=='all_movies_tvshows':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="archive-content"(.*?)class="pagination"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif type=='top_imdb_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='top_imdb_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("class='top-imdb-list tright(.*?)footer",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='search':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="search-page"(.*?)class="sidebar',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='sider':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="widget(.*?)class="widget',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		iiMkLyedYA = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		ODnaR0N8UHv7Twy6jS,MMyF7Sa3Hh0TbOJqEwLlmPnCZ,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = zip(*iiMkLyedYA)
		items = zip(MMyF7Sa3Hh0TbOJqEwLlmPnCZ,ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
	elif type=='randoms':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="slider-movies-tvshows"(.*?)<header>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif 'latest' in type:
		JXKAgPztneLxQh = int(type[-1:])
		GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('<header>','<end><start>')
		GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('</div></div></div>','</div></div></div><end>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<start>(.*?)<end>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[JXKAgPztneLxQh]
		if JXKAgPztneLxQh==6:
			iiMkLyedYA = oo9kuULlebNgpY0Om.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			MMyF7Sa3Hh0TbOJqEwLlmPnCZ,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = zip(*iiMkLyedYA)
			items = zip(MMyF7Sa3Hh0TbOJqEwLlmPnCZ,ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="content"(.*?)class="(pagination|sidebar)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0][0]
			if '/collection/' in url:
				items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			elif '/quality/' in url:
				items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items and BN1KdkzCmvshw:
		items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = oo9kuULlebNgpY0Om.findall('^(.*?)<.*?serie">(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
			title = title[0][1]
			if title in ehHpxSUAZnVITs4y5XjDKb8zC: continue
			ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
			title = '_MOD_'+title
		GS7Y93B0b8TLxueF = oo9kuULlebNgpY0Om.findall('^(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
		if GS7Y93B0b8TLxueF: title = GS7Y93B0b8TLxueF[0]
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if '/tvshows/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,393,M4qkBDatEIf3T)
		elif '/episodes/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,393,M4qkBDatEIf3T)
		elif '/seasons/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,393,M4qkBDatEIf3T)
		elif '/collection/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,391,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,392,M4qkBDatEIf3T)
	if type not in ['featured_movies','featured_tvshows']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,391,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(url,'url')
	url = url.replace(yVgLqfcUN1iO4,ffVP3AK5RqhkgYnjZoNis)
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FAJERSHOW-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('class="C rated".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<ul class="episodios">(.*?)</ul></div></div></div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,392,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	GagwMT6q3oc7UZ2Q = Rhct7Iy953qaglTse(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FAJERSHOW-PLAY-1st')
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('class="C rated".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	ODnaR0N8UHv7Twy6jS = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0][0]
		items = oo9kuULlebNgpY0Om.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for type,Jd7Bb5xfKNkU1upLqjYGWnZCg0,qhJ1oWQfMY,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+Jd7Bb5xfKNkU1upLqjYGWnZCg0+'&nume='+qhJ1oWQfMY+'&type='+type
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for M4qkBDatEIf3T,Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ,BSAJjHXKpCaq9Y04ym1frVb8iv in items:
			if '=' in M4qkBDatEIf3T:
				nihPHREgaW15oqdvpxr2O6XYtc = M4qkBDatEIf3T.split('=')[1]
				title = xWiOjcUrJVdtP4B5Iml(nihPHREgaW15oqdvpxr2O6XYtc,'host')
			else: title = G9G0YqivIfmUWO8K
			title = BSAJjHXKpCaq9Y04ym1frVb8iv+ww0sZkBU9JKd+title
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/?s='+search
	UUhwKBgI2nt(url,'search')
	return
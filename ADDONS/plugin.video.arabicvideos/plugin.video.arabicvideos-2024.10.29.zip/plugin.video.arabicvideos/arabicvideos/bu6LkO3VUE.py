# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'FARESKO'
TdtCLWYSJNK8zOb = '_FSK_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الرئيسية','يلا شوت']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==990: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==991: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==992: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==993: tRojAyBgfDH37eLCwP4dWl = k6V25enhgRWdHu(url)
	elif mode==999: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,999,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"primary-links"(.*?)</u',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,991)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"list-categories"(.*?)</u',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx.lstrip('/')
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,991)
	return
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"home-content"(.*?)"footer"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"overlay"','"duration"><')
		items = oo9kuULlebNgpY0Om.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		ehHpxSUAZnVITs4y5XjDKb8zC = []
		for M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT,Y6YdkAMluFbwx,title in items:
			title = title.strip(' ')
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if 'episodes' not in type and RnV3EqPNpXTDuI7:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
				title = title.replace('اون لاين',G9G0YqivIfmUWO8K)
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,993,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
			else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,992,M4qkBDatEIf3T,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''["']pagination["'](.*?)["']footer["']''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,991,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	else:
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('load-next-button" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة جديدة',Y6YdkAMluFbwx[0],991,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def k6V25enhgRWdHu(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-SERIES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="eplist"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		GOQI6tW4xVh8NYwdPqMD9Kg = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in GOQI6tW4xVh8NYwdPqMD9Kg:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,992)
	else:
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('"category".*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
			UUhwKBgI2nt(Y6YdkAMluFbwx,'episodes')
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,JzQ1sP6HyGwO9 = [],[]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'hash=' in GagwMT6q3oc7UZ2Q:
		wwasBzLeYfjh = oo9kuULlebNgpY0Om.findall('hash=(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		wwasBzLeYfjh = list(set(wwasBzLeYfjh))
		for Jd7Bb5xfKNkU1upLqjYGWnZCg0 in wwasBzLeYfjh:
			HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8 = []
			mtMexSFLnkwhbAaP9pgDduCRBi2 = Jd7Bb5xfKNkU1upLqjYGWnZCg0.split('__')
			for O40rBwVeybEYaR in mtMexSFLnkwhbAaP9pgDduCRBi2:
				try:
					O40rBwVeybEYaR = jaFsD83SB9ZQkrxeI.b64decode(O40rBwVeybEYaR+'=')
					if LTze51miOknVcslNF43WSA6vMjYZt: O40rBwVeybEYaR = O40rBwVeybEYaR.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
					HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8.append(O40rBwVeybEYaR)
				except: pass
			dsGzqX4k0a8RLyc = '>'.join(HvP3LJxeg9aO2w6pRn4hQIVFMY1qU8)
			dsGzqX4k0a8RLyc = dsGzqX4k0a8RLyc.splitlines()
			for Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
				if ' => ' in Y6YdkAMluFbwx:
					title,Y6YdkAMluFbwx = Y6YdkAMluFbwx.split(' => ')
					Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
					ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	elif 'post_id' in GagwMT6q3oc7UZ2Q:
		HGD02clisfMEkyYwX5PRebUnAu = oo9kuULlebNgpY0Om.findall("post_id = '(.*?)'",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if HGD02clisfMEkyYwX5PRebUnAu:
			HGD02clisfMEkyYwX5PRebUnAu = HGD02clisfMEkyYwX5PRebUnAu[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			SSHDzNikR29jQxn6ITCfdboM = ffVP3AK5RqhkgYnjZoNis+'/wp-admin/admin-ajax.php?action=video_info&post_id='+HGD02clisfMEkyYwX5PRebUnAu
			D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',SSHDzNikR29jQxn6ITCfdboM,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-PLAY-2nd')
			rDt6wKG3WCzdyRTpIs41uO2Ujq = D7omduSeM5Gk.content
			B42J8mtF3y9KZIbvqMQHA = oo9kuULlebNgpY0Om.findall('"name":"(.*?)","src":"(.*?)"',rDt6wKG3WCzdyRTpIs41uO2Ujq,oo9kuULlebNgpY0Om.DOTALL)
			if not B42J8mtF3y9KZIbvqMQHA:
				B42J8mtF3y9KZIbvqMQHA = oo9kuULlebNgpY0Om.findall('"src":"(.*?)"',rDt6wKG3WCzdyRTpIs41uO2Ujq,oo9kuULlebNgpY0Om.DOTALL)
				if B42J8mtF3y9KZIbvqMQHA:
					S3uHQeLAo0Ez48lvjDbshFik = ['']*len(B42J8mtF3y9KZIbvqMQHA)
					B42J8mtF3y9KZIbvqMQHA = list(zip(S3uHQeLAo0Ez48lvjDbshFik,B42J8mtF3y9KZIbvqMQHA))
			for name,Y6YdkAMluFbwx in B42J8mtF3y9KZIbvqMQHA:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('\\/','/')
				Y6YdkAMluFbwx = SSX6oT0lADZhKRImPvCHFkYJs(Y6YdkAMluFbwx)
				if Y6YdkAMluFbwx in JzQ1sP6HyGwO9: continue
				else: JzQ1sP6HyGwO9.append(Y6YdkAMluFbwx)
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__watch')
			z7GYBmKiXwreV2QybCNn80v9pT = ffVP3AK5RqhkgYnjZoNis+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+HGD02clisfMEkyYwX5PRebUnAu+'&video_id=null&video_url=null&video_source=custom'
			D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',z7GYBmKiXwreV2QybCNn80v9pT,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FARESKO-PLAY-3rd')
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
			z6F2EjLrUtmf = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if z6F2EjLrUtmf:
				SNHXewjYkhCvAuaPgil9,r1eBwpAIQjD3M = zip(*z6F2EjLrUtmf)
				z6F2EjLrUtmf = list(zip(r1eBwpAIQjD3M,SNHXewjYkhCvAuaPgil9))
			for name,Y6YdkAMluFbwx in z6F2EjLrUtmf:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('\\/','/')
				Y6YdkAMluFbwx = SSX6oT0lADZhKRImPvCHFkYJs(Y6YdkAMluFbwx)
				if Y6YdkAMluFbwx in JzQ1sP6HyGwO9: continue
				else: JzQ1sP6HyGwO9.append(Y6YdkAMluFbwx)
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__download')
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/?s='+search
	UUhwKBgI2nt(url,'search')
	return
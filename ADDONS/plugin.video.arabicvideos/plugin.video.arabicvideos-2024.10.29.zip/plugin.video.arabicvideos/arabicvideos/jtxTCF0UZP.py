# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
v1NALptEHU = 'EXCLUDES'
def D8vj2ZLSIt7e(YwC7jt5BQHhTUvbdGeM6f2ZLx,l5Bna2KTi81gR3W6sN):
	l5Bna2KTi81gR3W6sN = l5Bna2KTi81gR3W6sN.replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,G9G0YqivIfmUWO8K).replace(' '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)[1:]
	FXte7S4sIMKbBcvuOiWT9grA3 = oo9kuULlebNgpY0Om.findall('[a-zA-Z]',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
	if 'بحث IPTV - ' in YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace('بحث IPTV - ',wLgGlRoMI589yT6j1rvbW+'بحث IPTV - '+wLgGlRoMI589yT6j1rvbW)
	elif ' IPTV' in YwC7jt5BQHhTUvbdGeM6f2ZLx and l5Bna2KTi81gR3W6sN=='IPT': YwC7jt5BQHhTUvbdGeM6f2ZLx = wLgGlRoMI589yT6j1rvbW+YwC7jt5BQHhTUvbdGeM6f2ZLx
	elif 'بحث M3U - ' in YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace('بحث M3U - ',wLgGlRoMI589yT6j1rvbW+'بحث M3U - '+wLgGlRoMI589yT6j1rvbW)
	elif ' M3U' in YwC7jt5BQHhTUvbdGeM6f2ZLx and l5Bna2KTi81gR3W6sN=='M3U': YwC7jt5BQHhTUvbdGeM6f2ZLx = wLgGlRoMI589yT6j1rvbW+YwC7jt5BQHhTUvbdGeM6f2ZLx
	elif 'بحث ' in YwC7jt5BQHhTUvbdGeM6f2ZLx and ' - ' in YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = wLgGlRoMI589yT6j1rvbW+YwC7jt5BQHhTUvbdGeM6f2ZLx
	elif not FXte7S4sIMKbBcvuOiWT9grA3:
		NzWi6Aa92VndwH8XoIOu = oo9kuULlebNgpY0Om.findall('^( *?)(.*?)( *?)$',YwC7jt5BQHhTUvbdGeM6f2ZLx)
		ssGRuwQUzXoMEBrnkPZYHifSdjgtev,WcpQvbfei0gE48LUXyqTDYmZun,vaoAbpSUgXRVYcG8571WeZy = NzWi6Aa92VndwH8XoIOu[0]
		RRogDlBLWpFInNV = oo9kuULlebNgpY0Om.findall('^([!-~])',WcpQvbfei0gE48LUXyqTDYmZun)
		if RRogDlBLWpFInNV: YwC7jt5BQHhTUvbdGeM6f2ZLx = ssGRuwQUzXoMEBrnkPZYHifSdjgtev+Leu8GC4bRxh6How7I5U+WcpQvbfei0gE48LUXyqTDYmZun+vaoAbpSUgXRVYcG8571WeZy
		else: YwC7jt5BQHhTUvbdGeM6f2ZLx = vaoAbpSUgXRVYcG8571WeZy+wLgGlRoMI589yT6j1rvbW+WcpQvbfei0gE48LUXyqTDYmZun+ssGRuwQUzXoMEBrnkPZYHifSdjgtev
	else:
		import bidi.algorithm as Hu1ZSQWYqVx6FINLdhfm9EMeJg
		if 1:
			rCnwskvXSV24QeyHo = YwC7jt5BQHhTUvbdGeM6f2ZLx
			RR7YHvOFhyGrj6BicpsxTAzQJdUIt = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(YwC7jt5BQHhTUvbdGeM6f2ZLx,base_dir='L')
			if gA0m6CQUyfLG: rCnwskvXSV24QeyHo = rCnwskvXSV24QeyHo.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			if gA0m6CQUyfLG: RR7YHvOFhyGrj6BicpsxTAzQJdUIt = RR7YHvOFhyGrj6BicpsxTAzQJdUIt.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			eTx0B67oi34zqE5hlgdI9ORn = rCnwskvXSV24QeyHo.split(ww0sZkBU9JKd)
			kIQBmgtNK2hi = RR7YHvOFhyGrj6BicpsxTAzQJdUIt.split(ww0sZkBU9JKd)
			buQMvwmTxaZHVJdqOtK,B7cqzMKd0pPQtkO,ai3kyvZqYP2gswWLfznedlFu7V,dfNwBa5J9bqI1URYvMkV7GDTo8C = [],[],G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
			wk38fve0VPGNuYQ24SbThB6Lil = zip(eTx0B67oi34zqE5hlgdI9ORn,kIQBmgtNK2hi)
			for bbkGm6Bfnh5,oRyYMK1IHBGW9A0deV74POafNzgSp in wk38fve0VPGNuYQ24SbThB6Lil:
				if bbkGm6Bfnh5==oRyYMK1IHBGW9A0deV74POafNzgSp==G9G0YqivIfmUWO8K and dfNwBa5J9bqI1URYvMkV7GDTo8C:
					ai3kyvZqYP2gswWLfznedlFu7V += ww0sZkBU9JKd
					continue
				if bbkGm6Bfnh5==oRyYMK1IHBGW9A0deV74POafNzgSp:
					GQJ4MZ6bx58AHV = 'EN'
					if dfNwBa5J9bqI1URYvMkV7GDTo8C==GQJ4MZ6bx58AHV: ai3kyvZqYP2gswWLfznedlFu7V += ww0sZkBU9JKd+bbkGm6Bfnh5
					elif bbkGm6Bfnh5:
						if ai3kyvZqYP2gswWLfznedlFu7V:
							B7cqzMKd0pPQtkO.append(ai3kyvZqYP2gswWLfznedlFu7V)
							buQMvwmTxaZHVJdqOtK.append(G9G0YqivIfmUWO8K)
						ai3kyvZqYP2gswWLfznedlFu7V = bbkGm6Bfnh5
				else:
					GQJ4MZ6bx58AHV = 'AR'
					if dfNwBa5J9bqI1URYvMkV7GDTo8C==GQJ4MZ6bx58AHV: ai3kyvZqYP2gswWLfznedlFu7V += ww0sZkBU9JKd+bbkGm6Bfnh5
					elif bbkGm6Bfnh5:
						if ai3kyvZqYP2gswWLfznedlFu7V:
							buQMvwmTxaZHVJdqOtK.append(ai3kyvZqYP2gswWLfznedlFu7V)
							B7cqzMKd0pPQtkO.append(G9G0YqivIfmUWO8K)
						ai3kyvZqYP2gswWLfznedlFu7V = bbkGm6Bfnh5
				dfNwBa5J9bqI1URYvMkV7GDTo8C = GQJ4MZ6bx58AHV
			if GQJ4MZ6bx58AHV=='EN':
				buQMvwmTxaZHVJdqOtK.append(ai3kyvZqYP2gswWLfznedlFu7V)
				B7cqzMKd0pPQtkO.append(G9G0YqivIfmUWO8K)
			else:
				B7cqzMKd0pPQtkO.append(ai3kyvZqYP2gswWLfznedlFu7V)
				buQMvwmTxaZHVJdqOtK.append(G9G0YqivIfmUWO8K)
			y5YJZrcC2o8zNGDgRxXbsW = G9G0YqivIfmUWO8K
			wk38fve0VPGNuYQ24SbThB6Lil = zip(buQMvwmTxaZHVJdqOtK,B7cqzMKd0pPQtkO)
			import bidi.mirror as mjYH3XwqO9raNKvJ4thBlcDne
			for RhIvQ6yeYTXA8xgEfbiC1POq,NHjoZBp4VFrEcwYDXMGkQLg1dle7TO in wk38fve0VPGNuYQ24SbThB6Lil:
				if RhIvQ6yeYTXA8xgEfbiC1POq: y5YJZrcC2o8zNGDgRxXbsW += ww0sZkBU9JKd+RhIvQ6yeYTXA8xgEfbiC1POq
				else:
					RRogDlBLWpFInNV = oo9kuULlebNgpY0Om.findall('([!-~]) *$',NHjoZBp4VFrEcwYDXMGkQLg1dle7TO)
					if RRogDlBLWpFInNV:
						RRogDlBLWpFInNV = RRogDlBLWpFInNV[0]
						try:
							muyVeafQxOXkNz4p = mjYH3XwqO9raNKvJ4thBlcDne.MIRRORED[RRogDlBLWpFInNV]
							NzWi6Aa92VndwH8XoIOu = oo9kuULlebNgpY0Om.findall('^( *?)(.*?)( *?)$',NHjoZBp4VFrEcwYDXMGkQLg1dle7TO)
							if NzWi6Aa92VndwH8XoIOu: ssGRuwQUzXoMEBrnkPZYHifSdjgtev,NHjoZBp4VFrEcwYDXMGkQLg1dle7TO,vaoAbpSUgXRVYcG8571WeZy = NzWi6Aa92VndwH8XoIOu[0]
							NHjoZBp4VFrEcwYDXMGkQLg1dle7TO = ssGRuwQUzXoMEBrnkPZYHifSdjgtev+muyVeafQxOXkNz4p+NHjoZBp4VFrEcwYDXMGkQLg1dle7TO[:-1]+vaoAbpSUgXRVYcG8571WeZy
						except: pass
					y5YJZrcC2o8zNGDgRxXbsW += ww0sZkBU9JKd+NHjoZBp4VFrEcwYDXMGkQLg1dle7TO
			YwC7jt5BQHhTUvbdGeM6f2ZLx = y5YJZrcC2o8zNGDgRxXbsW[1:]
			if gA0m6CQUyfLG: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		else:
			if gA0m6CQUyfLG: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			YwC7jt5BQHhTUvbdGeM6f2ZLx = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(YwC7jt5BQHhTUvbdGeM6f2ZLx)
			rCnwskvXSV24QeyHo,RR7YHvOFhyGrj6BicpsxTAzQJdUIt = YwC7jt5BQHhTUvbdGeM6f2ZLx,YwC7jt5BQHhTUvbdGeM6f2ZLx
			if 1:
				dfNwBa5J9bqI1URYvMkV7GDTo8C,qnd2svXNkyiwbhKCY0o7QrAxJPzM9 = G9G0YqivIfmUWO8K,[]
				Gg4rflEzt6O0wxkC1e = YwC7jt5BQHhTUvbdGeM6f2ZLx.split(ww0sZkBU9JKd)
				for njQY1i76Ns in Gg4rflEzt6O0wxkC1e:
					if not njQY1i76Ns:
						if qnd2svXNkyiwbhKCY0o7QrAxJPzM9: qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1] += ww0sZkBU9JKd
						else: qnd2svXNkyiwbhKCY0o7QrAxJPzM9.append(G9G0YqivIfmUWO8K)
						continue
					QQBzEPJu02t8pV1no4el3vZLHsIAfG = oo9kuULlebNgpY0Om.findall('[!-~]',njQY1i76Ns[0])
					if QQBzEPJu02t8pV1no4el3vZLHsIAfG==dfNwBa5J9bqI1URYvMkV7GDTo8C and qnd2svXNkyiwbhKCY0o7QrAxJPzM9: qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1] += ww0sZkBU9JKd+njQY1i76Ns
					else:
						if qnd2svXNkyiwbhKCY0o7QrAxJPzM9:
							JcaxTWQz94ls8bFv = oo9kuULlebNgpY0Om.findall('[^!-~]',qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1])
							if JcaxTWQz94ls8bFv:
								qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1] = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1])
								yzbY6SWeBad = oo9kuULlebNgpY0Om.findall('^ +',qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1])
								if yzbY6SWeBad: qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1] = qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1].lstrip(ww0sZkBU9JKd)+yzbY6SWeBad[0]
						qnd2svXNkyiwbhKCY0o7QrAxJPzM9.append(njQY1i76Ns)
					dfNwBa5J9bqI1URYvMkV7GDTo8C = QQBzEPJu02t8pV1no4el3vZLHsIAfG
				if qnd2svXNkyiwbhKCY0o7QrAxJPzM9: qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1] = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(qnd2svXNkyiwbhKCY0o7QrAxJPzM9[-1])
				YwC7jt5BQHhTUvbdGeM6f2ZLx = ww0sZkBU9JKd.join(qnd2svXNkyiwbhKCY0o7QrAxJPzM9)
			if gA0m6CQUyfLG: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	return YwC7jt5BQHhTUvbdGeM6f2ZLx
def aqN9Yu8RfrTn(NTRtuJQvWLmGwoSe0fghq6UIZxrCX,lXm0rJ4Qtkp76jwVMhWf5yTxC83cA,vLKW8d3ZfsIawPYCJSR):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,Vf3T1WjrhCyn8vmdPMc2,HNJyAr63cjVuSZmbTF4X,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = NTRtuJQvWLmGwoSe0fghq6UIZxrCX
	Mauf6CrJjP87s = int(Mauf6CrJjP87s)
	raCGPszVgclj7mZXqhBkESbw = oo9kuULlebNgpY0Om.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
	if raCGPszVgclj7mZXqhBkESbw:
		raCGPszVgclj7mZXqhBkESbw,xTbnHfBkRi,aotpLw4fxbWk = raCGPszVgclj7mZXqhBkESbw[0]
		YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(raCGPszVgclj7mZXqhBkESbw,G9G0YqivIfmUWO8K)
	TT9zsyqCn0Ze = YwC7jt5BQHhTUvbdGeM6f2ZLx
	l5Bna2KTi81gR3W6sN = oo9kuULlebNgpY0Om.findall('^_(\w\w\w)_(.*?)$',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
	if l5Bna2KTi81gR3W6sN:
		l5Bna2KTi81gR3W6sN,YwC7jt5BQHhTUvbdGeM6f2ZLx = l5Bna2KTi81gR3W6sN[0]
		HrkZWtSCYIV0wcKus5v = '_MOD_' in YwC7jt5BQHhTUvbdGeM6f2ZLx
		JwTceYNvUD = Um2ITJ1iLnEjqZevskVt06NY34=='folder'
		if HrkZWtSCYIV0wcKus5v and JwTceYNvUD: x30lvsJ9hKwoGb1 = ';'
		elif HrkZWtSCYIV0wcKus5v and not JwTceYNvUD: x30lvsJ9hKwoGb1 = vq9L3uo7rDVm2zPO4h
		elif not HrkZWtSCYIV0wcKus5v and JwTceYNvUD: x30lvsJ9hKwoGb1 = ','
		elif not HrkZWtSCYIV0wcKus5v and not JwTceYNvUD: x30lvsJ9hKwoGb1 = ww0sZkBU9JKd
		YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace('_MOD_',G9G0YqivIfmUWO8K)
		l5Bna2KTi81gR3W6sN = x30lvsJ9hKwoGb1+A7XhkmSYZlidyMt5FpWqTgjNezbnD+l5Bna2KTi81gR3W6sN+' '+zzGfwLAyN5HTxUoJeaivY
	else: l5Bna2KTi81gR3W6sN = G9G0YqivIfmUWO8K
	if raCGPszVgclj7mZXqhBkESbw:
		if gA0m6CQUyfLG:
			raCGPszVgclj7mZXqhBkESbw = ipjCIhwEXsbadR+xTbnHfBkRi+ww0sZkBU9JKd+aotpLw4fxbWk+zzGfwLAyN5HTxUoJeaivY
			if l5Bna2KTi81gR3W6sN: YwC7jt5BQHhTUvbdGeM6f2ZLx = raCGPszVgclj7mZXqhBkESbw+ww0sZkBU9JKd+wLgGlRoMI589yT6j1rvbW+l5Bna2KTi81gR3W6sN+YwC7jt5BQHhTUvbdGeM6f2ZLx
			else: YwC7jt5BQHhTUvbdGeM6f2ZLx = raCGPszVgclj7mZXqhBkESbw+wLgGlRoMI589yT6j1rvbW+YwC7jt5BQHhTUvbdGeM6f2ZLx+ww0sZkBU9JKd
		elif LTze51miOknVcslNF43WSA6vMjYZt:
			if l5Bna2KTi81gR3W6sN:
				raCGPszVgclj7mZXqhBkESbw = ipjCIhwEXsbadR+xTbnHfBkRi+ww0sZkBU9JKd+aotpLw4fxbWk+zzGfwLAyN5HTxUoJeaivY
				YwC7jt5BQHhTUvbdGeM6f2ZLx = raCGPszVgclj7mZXqhBkESbw+ww0sZkBU9JKd+l5Bna2KTi81gR3W6sN+YwC7jt5BQHhTUvbdGeM6f2ZLx
			else:
				raCGPszVgclj7mZXqhBkESbw = ipjCIhwEXsbadR+aotpLw4fxbWk+ww0sZkBU9JKd+xTbnHfBkRi+zzGfwLAyN5HTxUoJeaivY
				YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx+ww0sZkBU9JKd+wLgGlRoMI589yT6j1rvbW+raCGPszVgclj7mZXqhBkESbw
	elif l5Bna2KTi81gR3W6sN:
		YwC7jt5BQHhTUvbdGeM6f2ZLx = D8vj2ZLSIt7e(YwC7jt5BQHhTUvbdGeM6f2ZLx,l5Bna2KTi81gR3W6sN)
		YwC7jt5BQHhTUvbdGeM6f2ZLx = l5Bna2KTi81gR3W6sN+YwC7jt5BQHhTUvbdGeM6f2ZLx
	NTRtuJQvWLmGwoSe0fghq6UIZxrCX = Um2ITJ1iLnEjqZevskVt06NY34,TT9zsyqCn0Ze,Qjnkp0KgXq2Ty,str(Mauf6CrJjP87s),eEDLWJkqd4hg,Vf3T1WjrhCyn8vmdPMc2,HNJyAr63cjVuSZmbTF4X,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge
	y2u65vS4WVAB1zDCdg8lbtqYjJ = {'type':G9G0YqivIfmUWO8K,'mode':G9G0YqivIfmUWO8K,'url':G9G0YqivIfmUWO8K,'text':G9G0YqivIfmUWO8K,'page':G9G0YqivIfmUWO8K,'name':G9G0YqivIfmUWO8K,'image':G9G0YqivIfmUWO8K,'context':G9G0YqivIfmUWO8K,'infodict':G9G0YqivIfmUWO8K}
	y2u65vS4WVAB1zDCdg8lbtqYjJ['name'] = SSX6oT0lADZhKRImPvCHFkYJs(TT9zsyqCn0Ze)
	y2u65vS4WVAB1zDCdg8lbtqYjJ['type'] = Um2ITJ1iLnEjqZevskVt06NY34.strip(ww0sZkBU9JKd)
	y2u65vS4WVAB1zDCdg8lbtqYjJ['mode'] = str(Mauf6CrJjP87s).strip(ww0sZkBU9JKd)
	if Um2ITJ1iLnEjqZevskVt06NY34=='folder' and Vf3T1WjrhCyn8vmdPMc2: y2u65vS4WVAB1zDCdg8lbtqYjJ['page'] = SSX6oT0lADZhKRImPvCHFkYJs(Vf3T1WjrhCyn8vmdPMc2.strip(ww0sZkBU9JKd))
	if mUTXiaBzJf2utgY3KFIQl: y2u65vS4WVAB1zDCdg8lbtqYjJ['context'] = mUTXiaBzJf2utgY3KFIQl.strip(ww0sZkBU9JKd)
	if HNJyAr63cjVuSZmbTF4X: y2u65vS4WVAB1zDCdg8lbtqYjJ['text'] = SSX6oT0lADZhKRImPvCHFkYJs(HNJyAr63cjVuSZmbTF4X.strip(ww0sZkBU9JKd))
	if eEDLWJkqd4hg: y2u65vS4WVAB1zDCdg8lbtqYjJ['image'] = SSX6oT0lADZhKRImPvCHFkYJs(eEDLWJkqd4hg.strip(ww0sZkBU9JKd))
	if wyMiO0VErpqda2hH5cRge:
		wyMiO0VErpqda2hH5cRge = str(wyMiO0VErpqda2hH5cRge)
		y2u65vS4WVAB1zDCdg8lbtqYjJ['infodict'] = SSX6oT0lADZhKRImPvCHFkYJs(wyMiO0VErpqda2hH5cRge.strip(ww0sZkBU9JKd))
		wyMiO0VErpqda2hH5cRge = eval(wyMiO0VErpqda2hH5cRge)
	else: wyMiO0VErpqda2hH5cRge = {}
	if Qjnkp0KgXq2Ty: y2u65vS4WVAB1zDCdg8lbtqYjJ['url'] = SSX6oT0lADZhKRImPvCHFkYJs(Qjnkp0KgXq2Ty.strip(ww0sZkBU9JKd))
	toVAvU4we1yMRBnK72XS = {'name':G9G0YqivIfmUWO8K,'context_menu':G9G0YqivIfmUWO8K,'plot':G9G0YqivIfmUWO8K,'stars':G9G0YqivIfmUWO8K,'image':G9G0YqivIfmUWO8K,'type':G9G0YqivIfmUWO8K,'isFolder':G9G0YqivIfmUWO8K,'newpath':G9G0YqivIfmUWO8K,'duration':G9G0YqivIfmUWO8K}
	mQYrxbCznTOW = []
	sRAcnCtxrS = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'/?type='+y2u65vS4WVAB1zDCdg8lbtqYjJ['type']+'&mode='+y2u65vS4WVAB1zDCdg8lbtqYjJ['mode']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['page']: sRAcnCtxrS += '&page='+y2u65vS4WVAB1zDCdg8lbtqYjJ['page']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['name']: sRAcnCtxrS += '&name='+y2u65vS4WVAB1zDCdg8lbtqYjJ['name']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['text']: sRAcnCtxrS += '&text='+y2u65vS4WVAB1zDCdg8lbtqYjJ['text']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['infodict']: sRAcnCtxrS += '&infodict='+y2u65vS4WVAB1zDCdg8lbtqYjJ['infodict']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['image']: sRAcnCtxrS += '&image='+y2u65vS4WVAB1zDCdg8lbtqYjJ['image']
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['url']: sRAcnCtxrS += '&url='+y2u65vS4WVAB1zDCdg8lbtqYjJ['url']
	if Mauf6CrJjP87s!=265: toVAvU4we1yMRBnK72XS['favorites'] = True
	else: toVAvU4we1yMRBnK72XS['favorites'] = False
	if y2u65vS4WVAB1zDCdg8lbtqYjJ['context']: sRAcnCtxrS += '&context='+y2u65vS4WVAB1zDCdg8lbtqYjJ['context']
	if Mauf6CrJjP87s in [235,238] and Um2ITJ1iLnEjqZevskVt06NY34=='live' and 'EPG' in mUTXiaBzJf2utgY3KFIQl:
		rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?mode=238&text=SHORT_EPG&url='+Qjnkp0KgXq2Ty
		NNVwaGPz7dE = ipjCIhwEXsbadR+'البرامج القادمة'+zzGfwLAyN5HTxUoJeaivY
		D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
		mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Mauf6CrJjP87s==265:
		JPLChxqYSwU1syfdIVnOHT7Xrc0 = lXm0rJ4Qtkp76jwVMhWf5yTxC83cA(HNJyAr63cjVuSZmbTF4X,True)
		if JPLChxqYSwU1syfdIVnOHT7Xrc0>0:
			rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?mode=266&text='+HNJyAr63cjVuSZmbTF4X
			NNVwaGPz7dE = ipjCIhwEXsbadR+'مسح قائمة آخر 50 '+GoAEsgO4hHICi65(HNJyAr63cjVuSZmbTF4X)+zzGfwLAyN5HTxUoJeaivY
			D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
			mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Um2ITJ1iLnEjqZevskVt06NY34=='video' and Mauf6CrJjP87s!=331:
		rXcRmO6TgMvDnN = sRAcnCtxrS+'&context=6_DOWNLOAD'
		NNVwaGPz7dE = ipjCIhwEXsbadR+'تحميل ملف الفيديو'+zzGfwLAyN5HTxUoJeaivY
		D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
		mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Mauf6CrJjP87s==331:
		rXcRmO6TgMvDnN = sRAcnCtxrS+'&context=6_DELETE'
		NNVwaGPz7dE = ipjCIhwEXsbadR+'حذف ملف الفيديو'+zzGfwLAyN5HTxUoJeaivY
		D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
		mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Um2ITJ1iLnEjqZevskVt06NY34=='folder' and Mauf6CrJjP87s==540:
		cuKCgeY32xUhLBdtRf4Zsob5 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_SPLITTED_ALL')
		if cuKCgeY32xUhLBdtRf4Zsob5:
			rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?context=7'
			NNVwaGPz7dE = ipjCIhwEXsbadR+'مسح كلمات بحث المواقع'+zzGfwLAyN5HTxUoJeaivY
			D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
			mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Um2ITJ1iLnEjqZevskVt06NY34=='folder' and Mauf6CrJjP87s==1010:
		cuKCgeY32xUhLBdtRf4Zsob5 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if cuKCgeY32xUhLBdtRf4Zsob5:
			rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?context=10'
			NNVwaGPz7dE = ipjCIhwEXsbadR+'مسح كلمات بحث جوجل'+zzGfwLAyN5HTxUoJeaivY
			D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
			mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	WqZHjabDFkgTnOJcmL5 = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if Mauf6CrJjP87s not in WqZHjabDFkgTnOJcmL5:
		rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?context=8&mode=260'
		NNVwaGPz7dE = ipjCIhwEXsbadR+'القائمة الرئيسية'+zzGfwLAyN5HTxUoJeaivY
		D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
		mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	w9ROdA15uUhGEH7opQKnjgePNzcCXD = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	aQdXiTH0PWqy2F = Mauf6CrJjP87s-Mauf6CrJjP87s%10
	if Mauf6CrJjP87s%10:
		if aQdXiTH0PWqy2F==280: aQdXiTH0PWqy2F = 230
		if aQdXiTH0PWqy2F==410: aQdXiTH0PWqy2F = 400
		if aQdXiTH0PWqy2F==520: aQdXiTH0PWqy2F = 510
		if aQdXiTH0PWqy2F not in w9ROdA15uUhGEH7opQKnjgePNzcCXD:
			rXcRmO6TgMvDnN = 'plugin://'+IJPabrdjXE7HGR163qY48pMVU5l+'?context=8&mode='+str(aQdXiTH0PWqy2F)
			NNVwaGPz7dE = ipjCIhwEXsbadR+'قائمة الموقع'+zzGfwLAyN5HTxUoJeaivY
			D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
			mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	rXcRmO6TgMvDnN = sRAcnCtxrS+'&context=9'
	NNVwaGPz7dE = ipjCIhwEXsbadR+'تحديث القائمة'+zzGfwLAyN5HTxUoJeaivY
	D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
	mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Um2ITJ1iLnEjqZevskVt06NY34 in ['video','live']:
		rXcRmO6TgMvDnN = sRAcnCtxrS+'&context=18'
		NNVwaGPz7dE = ipjCIhwEXsbadR+'قائمة الجودة'+zzGfwLAyN5HTxUoJeaivY
		D4FbCAjqovHw8LiXY = (NNVwaGPz7dE,'RunPlugin('+rXcRmO6TgMvDnN+')')
		mQYrxbCznTOW.append(D4FbCAjqovHw8LiXY)
	if Um2ITJ1iLnEjqZevskVt06NY34 in ['link','video','live']: uIizLbW0T4O5JSr = False
	elif Um2ITJ1iLnEjqZevskVt06NY34=='folder': uIizLbW0T4O5JSr = True
	toVAvU4we1yMRBnK72XS['name'] = YwC7jt5BQHhTUvbdGeM6f2ZLx
	toVAvU4we1yMRBnK72XS['context_menu'] = mQYrxbCznTOW
	if 'plot' in list(wyMiO0VErpqda2hH5cRge.keys()): toVAvU4we1yMRBnK72XS['plot'] = wyMiO0VErpqda2hH5cRge['plot']
	if 'stars' in list(wyMiO0VErpqda2hH5cRge.keys()): toVAvU4we1yMRBnK72XS['stars'] = wyMiO0VErpqda2hH5cRge['stars']
	if eEDLWJkqd4hg: toVAvU4we1yMRBnK72XS['image'] = eEDLWJkqd4hg
	if Um2ITJ1iLnEjqZevskVt06NY34=='video' and Vf3T1WjrhCyn8vmdPMc2:
		TlMHUhYWy2G = oo9kuULlebNgpY0Om.findall('[\d:]+',Vf3T1WjrhCyn8vmdPMc2,oo9kuULlebNgpY0Om.DOTALL)
		if TlMHUhYWy2G:
			TlMHUhYWy2G = '0:0:0:0:0:'+TlMHUhYWy2G[0]
			v2v3YoplfDdKJEhW5i,Jopd3wlrEYALa,As2GB9d7K1QwFnupLtXl3z85IW,fugSk6WYz8590Hcnse,AAQ1njU4Z7wWhPHKXM = TlMHUhYWy2G.rsplit(':',4)
			oIP6Mft9OgvmETXhKyDzpakeL = int(Jopd3wlrEYALa)*24*UadgtfoXpJGL9zZcKHq0yFnI+int(As2GB9d7K1QwFnupLtXl3z85IW)*UadgtfoXpJGL9zZcKHq0yFnI+int(fugSk6WYz8590Hcnse)*60+int(AAQ1njU4Z7wWhPHKXM)
			toVAvU4we1yMRBnK72XS['duration'] = oIP6Mft9OgvmETXhKyDzpakeL
	toVAvU4we1yMRBnK72XS['type'] = Um2ITJ1iLnEjqZevskVt06NY34
	toVAvU4we1yMRBnK72XS['isFolder'] = uIizLbW0T4O5JSr
	toVAvU4we1yMRBnK72XS['newpath'] = sRAcnCtxrS
	toVAvU4we1yMRBnK72XS['menuItem'] = NTRtuJQvWLmGwoSe0fghq6UIZxrCX
	toVAvU4we1yMRBnK72XS['mode'] = Mauf6CrJjP87s
	return toVAvU4we1yMRBnK72XS
def tylh1kHjNOod(lXm0rJ4Qtkp76jwVMhWf5yTxC83cA):
	uuNsrS4tcHd,qsQBKShZJyOFX3zCT2kdfoI = [],G9G0YqivIfmUWO8K
	from z9P53JUjpg import yEBVNehOAP8abZcHvLjzigr0s,E53xQykpKhNU61IqmbulZSJs7iLfc
	vLKW8d3ZfsIawPYCJSR = yEBVNehOAP8abZcHvLjzigr0s()
	w0oqhWrypS1QlT5zX6UAnFIGfKOkc = amx9qJHkhw7oLdtVMG3.getSetting('av.status.refresh')
	if ccW1tVjJvUx5efKbPHu6yAMLqaF and (not w0oqhWrypS1QlT5zX6UAnFIGfKOkc or w0oqhWrypS1QlT5zX6UAnFIGfKOkc=='REFRESH_CACHE'): w0oqhWrypS1QlT5zX6UAnFIGfKOkc = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'str','FOLDERS_SORT',ccW1tVjJvUx5efKbPHu6yAMLqaF)
	if w0oqhWrypS1QlT5zX6UAnFIGfKOkc:
		if   '_PERM' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: qsQBKShZJyOFX3zCT2kdfoI = 'دائمي'
		elif '_TEMP' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: qsQBKShZJyOFX3zCT2kdfoI = 'مؤقت'
		if   '_REVERSED_' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: mpniyIdLxTPW3BN8UcY2v = 'عكسي' ; eANQpmZPJaI7wc8[:] = reversed(eANQpmZPJaI7wc8)
		elif '_ASCENDED_' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: mpniyIdLxTPW3BN8UcY2v = 'تصاعدي' ; eANQpmZPJaI7wc8[:] = sorted(eANQpmZPJaI7wc8,reverse=kkMuQrLWcEayRm,key=lambda key:key[fdQOo6Hu4B5Rbg])
		elif '_DESCENDED_' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: mpniyIdLxTPW3BN8UcY2v = 'تنازلي' ; eANQpmZPJaI7wc8[:] = sorted(eANQpmZPJaI7wc8,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key:key[fdQOo6Hu4B5Rbg])
		elif '_RANDOMIZED_' in w0oqhWrypS1QlT5zX6UAnFIGfKOkc: mpniyIdLxTPW3BN8UcY2v = 'عشوائي' ; voWS3GzbN5HXaTsiwLMeU.shuffle(eANQpmZPJaI7wc8)
	name = 'ترتيب '+mpniyIdLxTPW3BN8UcY2v+ww0sZkBU9JKd+qsQBKShZJyOFX3zCT2kdfoI if qsQBKShZJyOFX3zCT2kdfoI else 'بدون ترتيب (أصلي)'
	name = ipjCIhwEXsbadR+name+zzGfwLAyN5HTxUoJeaivY
	if w0oqhWrypS1QlT5zX6UAnFIGfKOkc in I0WwEiyadX8qGtNAzc4: amx9qJHkhw7oLdtVMG3.setSetting('av.status.refresh',G9G0YqivIfmUWO8K)
	C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	w9ROdA15uUhGEH7opQKnjgePNzcCXD = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990,1020]
	Mauf6CrJjP87s = int(bmP3CnZr75H984yd1k2Ng0EYLA)
	aQdXiTH0PWqy2F = Mauf6CrJjP87s-Mauf6CrJjP87s%10
	if Mauf6CrJjP87s%10 and aQdXiTH0PWqy2F not in w9ROdA15uUhGEH7opQKnjgePNzcCXD and len(eANQpmZPJaI7wc8)>1:
		eANQpmZPJaI7wc8[:] = [('link',name,'',533,'','',ccW1tVjJvUx5efKbPHu6yAMLqaF,'','')]+eANQpmZPJaI7wc8
	for NTRtuJQvWLmGwoSe0fghq6UIZxrCX in eANQpmZPJaI7wc8:
		toVAvU4we1yMRBnK72XS = aqN9Yu8RfrTn(NTRtuJQvWLmGwoSe0fghq6UIZxrCX,lXm0rJ4Qtkp76jwVMhWf5yTxC83cA,vLKW8d3ZfsIawPYCJSR)
		if toVAvU4we1yMRBnK72XS['favorites']:
			AsW68p3UjGqXbhVonKrmd = E53xQykpKhNU61IqmbulZSJs7iLfc(vLKW8d3ZfsIawPYCJSR,toVAvU4we1yMRBnK72XS['menuItem'],toVAvU4we1yMRBnK72XS['newpath'])
			toVAvU4we1yMRBnK72XS['context_menu'] = AsW68p3UjGqXbhVonKrmd+toVAvU4we1yMRBnK72XS['context_menu']
		uuNsrS4tcHd.append(toVAvU4we1yMRBnK72XS)
	return uuNsrS4tcHd
def XQqidz7xZMG52CV1nSWa43K(RJBGyivQKTech8DM9xN):
	x30lvsJ9hKwoGb1,G0ZkgDKaJVh, = [],G9G0YqivIfmUWO8K
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		if not B71KDuTRjsXOcoh4JWbPdMSi28A: x30lvsJ9hKwoGb1.append(G9G0YqivIfmUWO8K)
		else: break
	RJBGyivQKTech8DM9xN = RJBGyivQKTech8DM9xN[len(x30lvsJ9hKwoGb1):]
	Vvju9Ht8SGxoiTa6lCs = '\n\n\n\n'.join(RJBGyivQKTech8DM9xN)
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('===== ===== =====','000001')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,'000002')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(ipjCIhwEXsbadR,'000003')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zzGfwLAyN5HTxUoJeaivY,'000004')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RIGHT]','000005')
	o6IQax2n7skH = 100000
	Lwfz1tIA8TjG03PX = {}
	X7qzRvUNyVgbe69 = oo9kuULlebNgpY0Om.findall('http.*?[\r\n ]',Vvju9Ht8SGxoiTa6lCs,oo9kuULlebNgpY0Om.DOTALL)
	for AbPKBVe8WaFzr09IoqQxj in X7qzRvUNyVgbe69:
		o6IQax2n7skH += 1
		Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(AbPKBVe8WaFzr09IoqQxj,str(o6IQax2n7skH))
		Lwfz1tIA8TjG03PX[str(o6IQax2n7skH)] = AbPKBVe8WaFzr09IoqQxj
	for KJZlbgk2TdD5GWQFqucMP in range(0,len(Vvju9Ht8SGxoiTa6lCs),4800):
		ZUIAXm04bSkO = Vvju9Ht8SGxoiTa6lCs[KJZlbgk2TdD5GWQFqucMP:KJZlbgk2TdD5GWQFqucMP+4800]
		tiDlKLqjJPsG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.code')
		Qjnkp0KgXq2Ty = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+tiDlKLqjJPsG
		cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {'Content-Type':'text/plain'}
		iQ2XdBOtrLg = ZUIAXm04bSkO.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		gULrv3Q4Cq = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'POST',Qjnkp0KgXq2Ty,iQ2XdBOtrLg,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if gULrv3Q4Cq.succeeded:
			kkKvgtpTiRAhrIEBVm = gULrv3Q4Cq.content
			zY2MtC5dlp1myn08GLOxsXNQ = bRCSwcA89e4J7pqdays5PxGiD2('str',kkKvgtpTiRAhrIEBVm)
			if zY2MtC5dlp1myn08GLOxsXNQ:
				zY2MtC5dlp1myn08GLOxsXNQ = zY2MtC5dlp1myn08GLOxsXNQ['translation']
				zY2MtC5dlp1myn08GLOxsXNQ = zDBtm4MwIagkfcpE5oxJOAq6lZQY(zY2MtC5dlp1myn08GLOxsXNQ)
				for xXiojqUmVlbuSnswBhQ in range(len(zY2MtC5dlp1myn08GLOxsXNQ)):
					G0ZkgDKaJVh += zY2MtC5dlp1myn08GLOxsXNQ[xXiojqUmVlbuSnswBhQ][0]
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000001','===== ===== =====')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000002',A7XhkmSYZlidyMt5FpWqTgjNezbnD)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000003',ipjCIhwEXsbadR)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000004',zzGfwLAyN5HTxUoJeaivY)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000005','[RIGHT]')
	for o6IQax2n7skH in list(Lwfz1tIA8TjG03PX.keys()):
		AbPKBVe8WaFzr09IoqQxj = Lwfz1tIA8TjG03PX[o6IQax2n7skH]
		G0ZkgDKaJVh = G0ZkgDKaJVh.replace(o6IQax2n7skH,AbPKBVe8WaFzr09IoqQxj)
	G0ZkgDKaJVh = G0ZkgDKaJVh.split('\n\n\n\n')
	return x30lvsJ9hKwoGb1+G0ZkgDKaJVh
def ShgaEHqTPN91Kcdt4Q(RJBGyivQKTech8DM9xN):
	x30lvsJ9hKwoGb1,G0ZkgDKaJVh, = [],G9G0YqivIfmUWO8K
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		if not B71KDuTRjsXOcoh4JWbPdMSi28A: x30lvsJ9hKwoGb1.append(G9G0YqivIfmUWO8K)
		else: break
	RJBGyivQKTech8DM9xN = RJBGyivQKTech8DM9xN[len(x30lvsJ9hKwoGb1):]
	Vvju9Ht8SGxoiTa6lCs = '\\n\\n\\n\\n'.join(RJBGyivQKTech8DM9xN)
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('كلا','no')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('استمرار','continue')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('===== ===== =====','000001')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,'000002')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(ipjCIhwEXsbadR,'000003')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zzGfwLAyN5HTxUoJeaivY,'000004')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RIGHT]','000005')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[CENTER]','000006')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RTL]','000007')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace("'","\\\\\\'")
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('"','\\\\\\"')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zEgtT9cR6bFp7JXqI5VuhNeP,'\\n')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(fXE2iwNYcD,'\\\\r')
	for KJZlbgk2TdD5GWQFqucMP in range(0,len(Vvju9Ht8SGxoiTa6lCs),4800):
		ZUIAXm04bSkO = Vvju9Ht8SGxoiTa6lCs[KJZlbgk2TdD5GWQFqucMP:KJZlbgk2TdD5GWQFqucMP+4800]
		Qjnkp0KgXq2Ty = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {'Content-Type':'application/x-www-form-urlencoded'}
		tiDlKLqjJPsG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.code')
		iQ2XdBOtrLg = 'f.req='+SSX6oT0lADZhKRImPvCHFkYJs('[[["MkEWBc","[[\\"'+ZUIAXm04bSkO+'\\",\\"ar\\",\\"'+tiDlKLqjJPsG+'\\",1],[]]",null,"generic"]]]',G9G0YqivIfmUWO8K)
		iQ2XdBOtrLg = iQ2XdBOtrLg.replace('%5Cn','%5C%5Cn')
		gULrv3Q4Cq = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'POST',Qjnkp0KgXq2Ty,iQ2XdBOtrLg,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if gULrv3Q4Cq.succeeded:
			kkKvgtpTiRAhrIEBVm = gULrv3Q4Cq.content
			kkKvgtpTiRAhrIEBVm = kkKvgtpTiRAhrIEBVm.split(zEgtT9cR6bFp7JXqI5VuhNeP)[-1]
			zY2MtC5dlp1myn08GLOxsXNQ = bRCSwcA89e4J7pqdays5PxGiD2('str',kkKvgtpTiRAhrIEBVm)[0][2]
			if zY2MtC5dlp1myn08GLOxsXNQ:
				zY2MtC5dlp1myn08GLOxsXNQ = bRCSwcA89e4J7pqdays5PxGiD2('str',zY2MtC5dlp1myn08GLOxsXNQ)[1][0][0][5]
				zY2MtC5dlp1myn08GLOxsXNQ = zDBtm4MwIagkfcpE5oxJOAq6lZQY(zY2MtC5dlp1myn08GLOxsXNQ)
				for xXiojqUmVlbuSnswBhQ in range(len(zY2MtC5dlp1myn08GLOxsXNQ)):
					G0ZkgDKaJVh += zY2MtC5dlp1myn08GLOxsXNQ[xXiojqUmVlbuSnswBhQ][0]
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('00000','0000').replace('0000','000')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0001','===== ===== =====')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0002',A7XhkmSYZlidyMt5FpWqTgjNezbnD)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0003',ipjCIhwEXsbadR)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0004',zzGfwLAyN5HTxUoJeaivY)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0005','[RIGHT]')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0006','[CENTER]')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0007','[RTL]')
	G0ZkgDKaJVh = G0ZkgDKaJVh.split('\n\n\n\n')
	return x30lvsJ9hKwoGb1+G0ZkgDKaJVh
def ejmpUrR3OcqHX(RJBGyivQKTech8DM9xN):
	x30lvsJ9hKwoGb1,YDmPX20KoMpExWThUn7vfL = [],[]
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		if not B71KDuTRjsXOcoh4JWbPdMSi28A: x30lvsJ9hKwoGb1.append(G9G0YqivIfmUWO8K)
		else: break
	RJBGyivQKTech8DM9xN = RJBGyivQKTech8DM9xN[len(x30lvsJ9hKwoGb1):]
	Vvju9Ht8SGxoiTa6lCs = '\n\n\n\n'.join(RJBGyivQKTech8DM9xN)
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('كلا','no')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('استمرار','continue')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('أدناه','below')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,'00001')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(ipjCIhwEXsbadR,'00002')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zzGfwLAyN5HTxUoJeaivY,'00003')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('=====','00004')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(',','00005')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RTL]','00009')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[CENTER]','0000A')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(fXE2iwNYcD,'0000B')
	RJBGyivQKTech8DM9xN = Vvju9Ht8SGxoiTa6lCs.split(zEgtT9cR6bFp7JXqI5VuhNeP)
	Vvju9Ht8SGxoiTa6lCs,G0ZkgDKaJVh = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
		if len(Vvju9Ht8SGxoiTa6lCs+B71KDuTRjsXOcoh4JWbPdMSi28A)<1800: Vvju9Ht8SGxoiTa6lCs += zEgtT9cR6bFp7JXqI5VuhNeP+B71KDuTRjsXOcoh4JWbPdMSi28A
		else:
			YDmPX20KoMpExWThUn7vfL.append(Vvju9Ht8SGxoiTa6lCs)
			Vvju9Ht8SGxoiTa6lCs = B71KDuTRjsXOcoh4JWbPdMSi28A
	YDmPX20KoMpExWThUn7vfL.append(Vvju9Ht8SGxoiTa6lCs)
	for B71KDuTRjsXOcoh4JWbPdMSi28A in YDmPX20KoMpExWThUn7vfL:
		cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {'Content-Type':'application/json','User-Agent':G9G0YqivIfmUWO8K}
		Qjnkp0KgXq2Ty = 'https://api.reverso.net/translate/v1/translation'
		tiDlKLqjJPsG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.code')
		iQ2XdBOtrLg = {"format":"text","from":"ara","to":tiDlKLqjJPsG,"input":B71KDuTRjsXOcoh4JWbPdMSi28A,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		iQ2XdBOtrLg = EEMsy4SLwnD0T92ztchdIUZ.dumps(iQ2XdBOtrLg)
		gULrv3Q4Cq = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'POST',Qjnkp0KgXq2Ty,iQ2XdBOtrLg,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIBRARY-REVERSO_TRANSLATE-1st')
		if gULrv3Q4Cq.succeeded:
			kkKvgtpTiRAhrIEBVm = gULrv3Q4Cq.content
			kkKvgtpTiRAhrIEBVm = bRCSwcA89e4J7pqdays5PxGiD2('dict',kkKvgtpTiRAhrIEBVm)
			G0ZkgDKaJVh += zEgtT9cR6bFp7JXqI5VuhNeP+G9G0YqivIfmUWO8K.join(kkKvgtpTiRAhrIEBVm['translation'])
	G0ZkgDKaJVh = G0ZkgDKaJVh[2:]
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000000','00000').replace('00000','0000').replace('0000','000')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0001',A7XhkmSYZlidyMt5FpWqTgjNezbnD)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0002',ipjCIhwEXsbadR)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0003',zzGfwLAyN5HTxUoJeaivY)
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0004','=====')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0005',',')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('0009','[RTL]')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000A','[CENTER]')
	G0ZkgDKaJVh = G0ZkgDKaJVh.replace('000B',fXE2iwNYcD)
	G0ZkgDKaJVh = G0ZkgDKaJVh.split('\n\n\n\n')
	return x30lvsJ9hKwoGb1+G0ZkgDKaJVh
def z18LlakeBCowF4NfMgcqZ(RJBGyivQKTech8DM9xN):
	crLCQ89R6573HBmUFgJZfXsqhW2lp = amx9qJHkhw7oLdtVMG3.getSetting('av.language.translate')
	if not crLCQ89R6573HBmUFgJZfXsqhW2lp or not RJBGyivQKTech8DM9xN: return RJBGyivQKTech8DM9xN
	bbQDZvfek0n5AhEVlRmPY1uH8MNqG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.provider')
	tiDlKLqjJPsG = amx9qJHkhw7oLdtVMG3.getSetting('av.language.code')
	CFvwW4oxbBDT8APREZs0 = tiDlKLqjJPsG+'__'+str(RJBGyivQKTech8DM9xN)
	amx9qJHkhw7oLdtVMG3.setSetting('av.language.translate',G9G0YqivIfmUWO8K)
	G0ZkgDKaJVh = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','TRANSLATE_'+bbQDZvfek0n5AhEVlRmPY1uH8MNqG,CFvwW4oxbBDT8APREZs0)
	if not G0ZkgDKaJVh:
		if bbQDZvfek0n5AhEVlRmPY1uH8MNqG=='GOOGLE': G0ZkgDKaJVh = ShgaEHqTPN91Kcdt4Q(RJBGyivQKTech8DM9xN)
		elif bbQDZvfek0n5AhEVlRmPY1uH8MNqG=='REVERSO': G0ZkgDKaJVh = ejmpUrR3OcqHX(RJBGyivQKTech8DM9xN)
		elif bbQDZvfek0n5AhEVlRmPY1uH8MNqG=='GLOSBE': G0ZkgDKaJVh = XQqidz7xZMG52CV1nSWa43K(RJBGyivQKTech8DM9xN)
		if len(RJBGyivQKTech8DM9xN)==len(G0ZkgDKaJVh):
			ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'TRANSLATE_'+bbQDZvfek0n5AhEVlRmPY1uH8MNqG,CFvwW4oxbBDT8APREZs0,G0ZkgDKaJVh,InpqoEf2WrlSe8)
		else:
			G0ZkgDKaJVh = RJBGyivQKTech8DM9xN
			XXeZuvhknsKYqB17gwm6dfc('الترجمة فشلت','Translation Failed')
	amx9qJHkhw7oLdtVMG3.setSetting('av.language.translate','1')
	return G0ZkgDKaJVh
def S2Nr95pgUQbsVJE8RKImHG(NTRtuJQvWLmGwoSe0fghq6UIZxrCX,uuNsrS4tcHd,ISlwNu6cCWfTAQs,hVcJ6I7Otn4YQZDRw9gG,Zj9qRAOMkrJ5YHfCFsyVd0):
	Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge = NTRtuJQvWLmGwoSe0fghq6UIZxrCX
	lUPARX59gN = []
	crLCQ89R6573HBmUFgJZfXsqhW2lp = amx9qJHkhw7oLdtVMG3.getSetting('av.language.translate')
	if crLCQ89R6573HBmUFgJZfXsqhW2lp:
		heJQRNUdlLI14k5yO03wmsFZPC6Su,l6lUh4ymdgHKv2GcCDpTfPOWeFjRJ,pV76qS4o8OjG5f1mR3LU = [],[],[]
		if not lUPARX59gN:
			for toVAvU4we1yMRBnK72XS in uuNsrS4tcHd:
				YwC7jt5BQHhTUvbdGeM6f2ZLx = toVAvU4we1yMRBnK72XS['name'].replace(wLgGlRoMI589yT6j1rvbW,G9G0YqivIfmUWO8K).replace(Leu8GC4bRxh6How7I5U,G9G0YqivIfmUWO8K)
				raCGPszVgclj7mZXqhBkESbw = oo9kuULlebNgpY0Om.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
				if raCGPszVgclj7mZXqhBkESbw:
					x30lvsJ9hKwoGb1,xTbnHfBkRi,aotpLw4fxbWk,tB7zgXx4UMvo9bY6WHK8Fy,YwC7jt5BQHhTUvbdGeM6f2ZLx = raCGPszVgclj7mZXqhBkESbw[0]
					raCGPszVgclj7mZXqhBkESbw = x30lvsJ9hKwoGb1+xTbnHfBkRi+ww0sZkBU9JKd+aotpLw4fxbWk+tB7zgXx4UMvo9bY6WHK8Fy+ww0sZkBU9JKd
				else:
					raCGPszVgclj7mZXqhBkESbw = oo9kuULlebNgpY0Om.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
					if raCGPszVgclj7mZXqhBkESbw:
						YwC7jt5BQHhTUvbdGeM6f2ZLx,x30lvsJ9hKwoGb1,aotpLw4fxbWk,xTbnHfBkRi,tB7zgXx4UMvo9bY6WHK8Fy = raCGPszVgclj7mZXqhBkESbw[0]
						raCGPszVgclj7mZXqhBkESbw = x30lvsJ9hKwoGb1+xTbnHfBkRi+ww0sZkBU9JKd+aotpLw4fxbWk+tB7zgXx4UMvo9bY6WHK8Fy+ww0sZkBU9JKd
					else: raCGPszVgclj7mZXqhBkESbw = G9G0YqivIfmUWO8K
				l5Bna2KTi81gR3W6sN = oo9kuULlebNgpY0Om.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
				if l5Bna2KTi81gR3W6sN: l5Bna2KTi81gR3W6sN,YwC7jt5BQHhTUvbdGeM6f2ZLx = l5Bna2KTi81gR3W6sN[0]
				else: l5Bna2KTi81gR3W6sN = G9G0YqivIfmUWO8K
				heJQRNUdlLI14k5yO03wmsFZPC6Su.append(raCGPszVgclj7mZXqhBkESbw+l5Bna2KTi81gR3W6sN)
				l6lUh4ymdgHKv2GcCDpTfPOWeFjRJ.append(YwC7jt5BQHhTUvbdGeM6f2ZLx)
			pV76qS4o8OjG5f1mR3LU = z18LlakeBCowF4NfMgcqZ(l6lUh4ymdgHKv2GcCDpTfPOWeFjRJ)
			if pV76qS4o8OjG5f1mR3LU:
				for KJZlbgk2TdD5GWQFqucMP in range(len(uuNsrS4tcHd)):
					toVAvU4we1yMRBnK72XS = uuNsrS4tcHd[KJZlbgk2TdD5GWQFqucMP]
					toVAvU4we1yMRBnK72XS['name'] = heJQRNUdlLI14k5yO03wmsFZPC6Su[KJZlbgk2TdD5GWQFqucMP]+pV76qS4o8OjG5f1mR3LU[KJZlbgk2TdD5GWQFqucMP]
					lUPARX59gN.append(toVAvU4we1yMRBnK72XS)
	if lUPARX59gN: uuNsrS4tcHd = lUPARX59gN
	Hy4a7ezd5PI81,dru9Bw5AosqJUvZf3RVlQKPyIHDb8,h9hZL8b27WosQeUB = [],0,0
	o5xGaJD9PlLqwNmHTESrI1ieZ87kAO = amx9qJHkhw7oLdtVMG3.getSetting('av.status.menusimages')
	bIyiElJDmTG4 = o5xGaJD9PlLqwNmHTESrI1ieZ87kAO!='STOP'
	if bIyiElJDmTG4:
		rvfuPxABw3XtEkMpHjcIDsgSYUVya = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ffDhnivjmRXeuHSIa1qEZNA,Mauf6CrJjP87s)
		try: PQ2v35tdgA6Gcuk = ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(rvfuPxABw3XtEkMpHjcIDsgSYUVya)
		except:
			if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(rvfuPxABw3XtEkMpHjcIDsgSYUVya):
				try: ifTNQtY3XrquHMV4wlCgI6FmpPK.makedirs(rvfuPxABw3XtEkMpHjcIDsgSYUVya)
				except: pass
			PQ2v35tdgA6Gcuk = []
	aaefPW7u68bx9Dzcr4EKi = EKUfxZQHjc7hLTAWd1o9gimlO('menu_item')
	for toVAvU4we1yMRBnK72XS in uuNsrS4tcHd:
		YwC7jt5BQHhTUvbdGeM6f2ZLx = toVAvU4we1yMRBnK72XS['name']
		mQYrxbCznTOW = toVAvU4we1yMRBnK72XS['context_menu']
		d8tabTuICUcNRQkmwE2ADon96H = toVAvU4we1yMRBnK72XS['plot']
		EpuThWXikUYVs6Iz8cbGeRf0K4a5r = toVAvU4we1yMRBnK72XS['stars']
		eEDLWJkqd4hg = toVAvU4we1yMRBnK72XS['image']
		Um2ITJ1iLnEjqZevskVt06NY34 = toVAvU4we1yMRBnK72XS['type']
		TlMHUhYWy2G = toVAvU4we1yMRBnK72XS['duration']
		uIizLbW0T4O5JSr = toVAvU4we1yMRBnK72XS['isFolder']
		sRAcnCtxrS = toVAvU4we1yMRBnK72XS['newpath']
		eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG = tDG1bZwX86UPjWEoVOJ.ListItem(YwC7jt5BQHhTUvbdGeM6f2ZLx)
		eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.addContextMenuItems(mQYrxbCznTOW)
		AMokQj3fb46XLlHKyFxNw = False if bIyiElJDmTG4 else True
		if eEDLWJkqd4hg:
			eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setArt({'icon':eEDLWJkqd4hg,'thumb':eEDLWJkqd4hg,'fanart':eEDLWJkqd4hg,'banner':eEDLWJkqd4hg,'clearart':eEDLWJkqd4hg,'poster':eEDLWJkqd4hg,'clearlogo':eEDLWJkqd4hg,'landscape':eEDLWJkqd4hg})
			AMokQj3fb46XLlHKyFxNw = False
		elif not AMokQj3fb46XLlHKyFxNw:
			AMokQj3fb46XLlHKyFxNw = True
			YwC7jt5BQHhTUvbdGeM6f2ZLx = AyU7CaxXKirHj6kISTMR0d1mgZlJ4s(kkMuQrLWcEayRm,YwC7jt5BQHhTUvbdGeM6f2ZLx)
			YwC7jt5BQHhTUvbdGeM6f2ZLx = jHk81i3RbxZ(YwC7jt5BQHhTUvbdGeM6f2ZLx)
			OTybGEiFxwfMs3cq6PZpDk9V7CjgIt = YwC7jt5BQHhTUvbdGeM6f2ZLx+'.png'
			Yd6ji9UqkFbNgl13 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(rvfuPxABw3XtEkMpHjcIDsgSYUVya,OTybGEiFxwfMs3cq6PZpDk9V7CjgIt)
			if OTybGEiFxwfMs3cq6PZpDk9V7CjgIt in PQ2v35tdgA6Gcuk:
				eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setArt({'icon':Yd6ji9UqkFbNgl13,'thumb':Yd6ji9UqkFbNgl13,'fanart':Yd6ji9UqkFbNgl13,'banner':Yd6ji9UqkFbNgl13,'clearart':Yd6ji9UqkFbNgl13,'poster':Yd6ji9UqkFbNgl13,'clearlogo':Yd6ji9UqkFbNgl13,'landscape':Yd6ji9UqkFbNgl13})
				AMokQj3fb46XLlHKyFxNw = False
			elif dru9Bw5AosqJUvZf3RVlQKPyIHDb8<40 and h9hZL8b27WosQeUB<=3:
				try:
					JakR94N85FmALl2cGHueyVv = TaBxzOYokcjL58fbUlF31nveR2rdqD(aaefPW7u68bx9Dzcr4EKi,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,YwC7jt5BQHhTUvbdGeM6f2ZLx,'menu_item','center',False,Yd6ji9UqkFbNgl13)
					eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setArt({'icon':Yd6ji9UqkFbNgl13,'thumb':Yd6ji9UqkFbNgl13,'fanart':Yd6ji9UqkFbNgl13,'banner':Yd6ji9UqkFbNgl13,'clearart':Yd6ji9UqkFbNgl13,'poster':Yd6ji9UqkFbNgl13,'clearlogo':Yd6ji9UqkFbNgl13,'landscape':Yd6ji9UqkFbNgl13})
					dru9Bw5AosqJUvZf3RVlQKPyIHDb8 += 1
					AMokQj3fb46XLlHKyFxNw = False
					PQ2v35tdgA6Gcuk.append(OTybGEiFxwfMs3cq6PZpDk9V7CjgIt)
					if dru9Bw5AosqJUvZf3RVlQKPyIHDb8==5: XXeZuvhknsKYqB17gwm6dfc('إضافة الكتابة لصور القائمة','انتظار',SSCU3jdyFn2V=500)
				except: h9hZL8b27WosQeUB += 1
		if AMokQj3fb46XLlHKyFxNw:
			eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setArt({'icon':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'thumb':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'fanart':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'banner':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'clearart':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'poster':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'clearlogo':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0,'landscape':JVqRU9FrdwvjpCcSoTHgmlX51YNWs0})
		if F7aJYwLMEmxAVRupWf<20:
			if d8tabTuICUcNRQkmwE2ADon96H: eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setInfo('video',{'Plot':d8tabTuICUcNRQkmwE2ADon96H,'PlotOutline':d8tabTuICUcNRQkmwE2ADon96H})
			if EpuThWXikUYVs6Iz8cbGeRf0K4a5r: eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setInfo('video',{'Rating':EpuThWXikUYVs6Iz8cbGeRf0K4a5r})
			if not eEDLWJkqd4hg:
				eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setInfo('video',{'Title':YwC7jt5BQHhTUvbdGeM6f2ZLx})
			if Um2ITJ1iLnEjqZevskVt06NY34=='video':
				eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setInfo('video',{'mediatype':'tvshow'})
				if TlMHUhYWy2G: eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setInfo('video',{'duration':TlMHUhYWy2G})
				eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setProperty('IsPlayable','true')
		else:
			Iq9WcgQXjk0BVPy7fKSrC8 = eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.getVideoInfoTag()
			if EpuThWXikUYVs6Iz8cbGeRf0K4a5r: Iq9WcgQXjk0BVPy7fKSrC8.setRating(float(EpuThWXikUYVs6Iz8cbGeRf0K4a5r))
			if not eEDLWJkqd4hg:
				Iq9WcgQXjk0BVPy7fKSrC8.setTitle(YwC7jt5BQHhTUvbdGeM6f2ZLx)
			if Um2ITJ1iLnEjqZevskVt06NY34=='video':
				Iq9WcgQXjk0BVPy7fKSrC8.setMediaType('tvshow')
				if TlMHUhYWy2G: Iq9WcgQXjk0BVPy7fKSrC8.setDuration(TlMHUhYWy2G)
				eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG.setProperty('IsPlayable','true')
		Hy4a7ezd5PI81.append((sRAcnCtxrS,eAl7E1jhnT20rfO9Sdx8cQ6KwzvsNG,uIizLbW0T4O5JSr))
	GWMro8TCBy2dNai.setContent(Q0ykDeVYNBOECG5WU,'tvshows')
	sSyOc1TbY4U5REfjrvpdNkau = GWMro8TCBy2dNai.addDirectoryItems(Q0ykDeVYNBOECG5WU,Hy4a7ezd5PI81)
	GWMro8TCBy2dNai.endOfDirectory(Q0ykDeVYNBOECG5WU,ISlwNu6cCWfTAQs,hVcJ6I7Otn4YQZDRw9gG,Zj9qRAOMkrJ5YHfCFsyVd0)
	return sSyOc1TbY4U5REfjrvpdNkau
def Qm8SMu6ecXtigDCWw1oak(Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg=G9G0YqivIfmUWO8K,bjSL1IZNRp59z2=G9G0YqivIfmUWO8K,Vvju9Ht8SGxoiTa6lCs=G9G0YqivIfmUWO8K,mUTXiaBzJf2utgY3KFIQl=G9G0YqivIfmUWO8K,wyMiO0VErpqda2hH5cRge={}):
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace('\t',G9G0YqivIfmUWO8K)
	Qjnkp0KgXq2Ty = Qjnkp0KgXq2Ty.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace('\t',G9G0YqivIfmUWO8K)
	if '_SCRIPT_' in YwC7jt5BQHhTUvbdGeM6f2ZLx:
		v1NALptEHU,YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.split('_SCRIPT_',fdQOo6Hu4B5Rbg)
		if v1NALptEHU not in list(MMznYDmqKf0gVWpiSulZJ1waTRc.keys()): MMznYDmqKf0gVWpiSulZJ1waTRc[v1NALptEHU] = []
		MMznYDmqKf0gVWpiSulZJ1waTRc[v1NALptEHU].append([Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge])
	eANQpmZPJaI7wc8.append([Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,eEDLWJkqd4hg,bjSL1IZNRp59z2,Vvju9Ht8SGxoiTa6lCs,mUTXiaBzJf2utgY3KFIQl,wyMiO0VErpqda2hH5cRge])
	return
def kD2wGe8Oh4T7Cj3BMsy0(MmdcCkB4a0tNezgqJ1Ei9rILo6R):
	if LTze51miOknVcslNF43WSA6vMjYZt: from html import unescape as _jBtOaWYAIz
	else:
		from HTMLParser import HTMLParser as iso7145N0gnSrbIW
		_jBtOaWYAIz = iso7145N0gnSrbIW().unescape
	if '&' in MmdcCkB4a0tNezgqJ1Ei9rILo6R and ';' in MmdcCkB4a0tNezgqJ1Ei9rILo6R:
		if gA0m6CQUyfLG: MmdcCkB4a0tNezgqJ1Ei9rILo6R = MmdcCkB4a0tNezgqJ1Ei9rILo6R.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		MmdcCkB4a0tNezgqJ1Ei9rILo6R = _jBtOaWYAIz(MmdcCkB4a0tNezgqJ1Ei9rILo6R)
		if gA0m6CQUyfLG: MmdcCkB4a0tNezgqJ1Ei9rILo6R = MmdcCkB4a0tNezgqJ1Ei9rILo6R.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	return MmdcCkB4a0tNezgqJ1Ei9rILo6R
def zDBtm4MwIagkfcpE5oxJOAq6lZQY(MmdcCkB4a0tNezgqJ1Ei9rILo6R):
	if '\\u' in MmdcCkB4a0tNezgqJ1Ei9rILo6R:
		if gA0m6CQUyfLG: MmdcCkB4a0tNezgqJ1Ei9rILo6R = MmdcCkB4a0tNezgqJ1Ei9rILo6R.decode('unicode_escape','ignore').encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		elif LTze51miOknVcslNF43WSA6vMjYZt: MmdcCkB4a0tNezgqJ1Ei9rILo6R = MmdcCkB4a0tNezgqJ1Ei9rILo6R.encode(f3uIcZ2C6pzbX1JlFBrVOdt).decode('unicode_escape','ignore')
	return MmdcCkB4a0tNezgqJ1Ei9rILo6R
def cvGgZknSKbf6lU7pwt8Y(kkCZc3TnBUP,bXwYjBHzsfeL8Pva,ynkzWTcZ5Cuatf8xKsSP6L,KSEyq972WH5oT,Vvju9Ht8SGxoiTa6lCs,dwD51KktlTYQWehOc2F0a4z3CPZrJs,RF0SvtkQzWsdGjX,bmRw7DqFlZiuHh0BPjQ,GG0tshD8ywnpEPCRAqJ3):
	XC9tKS63TmNlzJFR0ubcGxYqpePUr = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.dirname(GG0tshD8ywnpEPCRAqJ3)
	if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(XC9tKS63TmNlzJFR0ubcGxYqpePUr):
		try: ifTNQtY3XrquHMV4wlCgI6FmpPK.makedirs(XC9tKS63TmNlzJFR0ubcGxYqpePUr)
		except: pass
	ddPRECvTzfSGDwxceY = EKUfxZQHjc7hLTAWd1o9gimlO(dwD51KktlTYQWehOc2F0a4z3CPZrJs)
	JakR94N85FmALl2cGHueyVv = TaBxzOYokcjL58fbUlF31nveR2rdqD(ddPRECvTzfSGDwxceY,kkCZc3TnBUP,bXwYjBHzsfeL8Pva,ynkzWTcZ5Cuatf8xKsSP6L,KSEyq972WH5oT,Vvju9Ht8SGxoiTa6lCs,dwD51KktlTYQWehOc2F0a4z3CPZrJs,RF0SvtkQzWsdGjX,bmRw7DqFlZiuHh0BPjQ,GG0tshD8ywnpEPCRAqJ3)
	return JakR94N85FmALl2cGHueyVv
def EKUfxZQHjc7hLTAWd1o9gimlO(dwD51KktlTYQWehOc2F0a4z3CPZrJs):
	hGI3UOFM7J9D4Ld8BnyrHpjTfxai1N = 5
	LvopNmgkP0G4QYCUxbFs = 20
	XSJyImB7GTUtEf8 = 20
	wUvJyCnfdzirhBSlAFs870 = 0
	TDU6Pr7x4LQlpu2gd = 'center'
	ha7L1mKdMe8JsgktIDX2yoV = 0
	rd2CIYtwLyFUsNvuzQKmlkfjE = 19
	z56W2AvC4gHirKYmlbexup87a = 30
	owQ4u6WBhGAKpa = 8
	TTaKqy4bL3Skl = True
	HHFhPjQxyvnD4KaGOVoXfq = 375
	T1TMBVledgQwUKLpnGqmk7zaIC5uYN = 410
	RUPKCTxn0VSo7O2Q9aGBWbtYyAl = 50
	GZCWRqUt1fhSKiz9oNxy4T = 280
	ssS9hbHUZOPrFj = 28
	xwvZn6d1zB23b9afFk = 5
	buXoh2zimLd1 = 0
	aWAbRpGsiT7g8ozOf = 31
	iSgrxnumhLdt1Gw0Jz947NsM8BU5V = [36,32,28]
	from PIL import ImageDraw as hN15RTFGmxM47slPe2EXdIwyZzWn,ImageFont as jj2MqvQzkZB6eSbGYml3WOUhFpKas,Image as n2MAiKLbuOv7wpGE
	if 'notification' in dwD51KktlTYQWehOc2F0a4z3CPZrJs:
		if dwD51KktlTYQWehOc2F0a4z3CPZrJs=='notification_regular':
			UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4 = 117
			TDU6Pr7x4LQlpu2gd = 'left'
			TTaKqy4bL3Skl = False
		elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='notification_auto':
			UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4 = 'UPPER'
			TDU6Pr7x4LQlpu2gd = 'right'
			wUvJyCnfdzirhBSlAFs870 = 10
		r3blYuifzOW = 720
		iSgrxnumhLdt1Gw0Jz947NsM8BU5V = [33,33,33]
		XSJyImB7GTUtEf8 = 20
		LvopNmgkP0G4QYCUxbFs = 0
		z56W2AvC4gHirKYmlbexup87a = 20
		rd2CIYtwLyFUsNvuzQKmlkfjE = 35
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='menu_item':
		iSgrxnumhLdt1Gw0Jz947NsM8BU5V,r3blYuifzOW,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4 = [28,28,28],200,250
		ha7L1mKdMe8JsgktIDX2yoV,z56W2AvC4gHirKYmlbexup87a,rd2CIYtwLyFUsNvuzQKmlkfjE, = 0,-12,-30
		LvopNmgkP0G4QYCUxbFs = 0
		iw7PdDZ3eEyu = n2MAiKLbuOv7wpGE.open(JVqRU9FrdwvjpCcSoTHgmlX51YNWs0)
		GM8LvBPOXaq = n2MAiKLbuOv7wpGE.new('RGBA',(r3blYuifzOW,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4),(255,0,0,255))
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='confirm_smallfont': iSgrxnumhLdt1Gw0Jz947NsM8BU5V,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = [28,24,20],500,900
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='confirm_mediumfont': iSgrxnumhLdt1Gw0Jz947NsM8BU5V,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = [32,28,24],500,900
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='confirm_bigfont': iSgrxnumhLdt1Gw0Jz947NsM8BU5V,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = [36,32,28],500,900
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='textview_bigfont': UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = 740,1270
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='textview_bigfont_long': UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = 'UPPER',1270
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='textview_smallfont': iSgrxnumhLdt1Gw0Jz947NsM8BU5V,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = [28,23,18],740,1270
	elif dwD51KktlTYQWehOc2F0a4z3CPZrJs=='textview_smallfont_long': iSgrxnumhLdt1Gw0Jz947NsM8BU5V,UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4,r3blYuifzOW = [28,23,18],'UPPER',1270
	ejWwUvByas,DipOgaXBAb14,eyvrVQqjSYs = iSgrxnumhLdt1Gw0Jz947NsM8BU5V
	llHTi9v7sj5qnIJUuafO0631rkY = jj2MqvQzkZB6eSbGYml3WOUhFpKas.truetype(VaKLXphjxdTmCZGRzDl0tuE1geW3s,size=ejWwUvByas)
	D5V4pyZnIX9fuN8JtFmiT = jj2MqvQzkZB6eSbGYml3WOUhFpKas.truetype(VaKLXphjxdTmCZGRzDl0tuE1geW3s,size=DipOgaXBAb14)
	dMzn4mFU5YqxVZcB = jj2MqvQzkZB6eSbGYml3WOUhFpKas.truetype(VaKLXphjxdTmCZGRzDl0tuE1geW3s,size=eyvrVQqjSYs)
	pCtF1UX6DI4irbPyJds0M9R = r3blYuifzOW-z56W2AvC4gHirKYmlbexup87a*2
	VaryDHgOnoTwiqvLcutAERKebs6S = n2MAiKLbuOv7wpGE.new('RGBA',(pCtF1UX6DI4irbPyJds0M9R,100),(255,255,255,0))
	k5kerqvoRTAcfl2UOHu9tZFjd = hN15RTFGmxM47slPe2EXdIwyZzWn.Draw(VaryDHgOnoTwiqvLcutAERKebs6S)
	ectuJb6mnoV,FVAc9xENZDwRrkQ = k5kerqvoRTAcfl2UOHu9tZFjd.textsize('HHH BBB 888 000',font=llHTi9v7sj5qnIJUuafO0631rkY)
	XDZbsMPBFG6d3nNh7YKl2Ae1zvr4,xnsDcE014yqLrNh56UTm8B = k5kerqvoRTAcfl2UOHu9tZFjd.textsize('HHH BBB 888 000',font=D5V4pyZnIX9fuN8JtFmiT)
	A4BOju2TXcxC9RPKhnysYFeJ = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as C2Sbn0iWAaO9eF7
	EVFCrOoRb3lJsTQ = C2Sbn0iWAaO9eF7(configuration=A4BOju2TXcxC9RPKhnysYFeJ)
	ddPRECvTzfSGDwxceY = {}
	Ga2Y7HnoKI5ALiSB6dMFucjh9xg = locals()
	for u2ynb8RckJiqGpeV07hEF63 in Ga2Y7HnoKI5ALiSB6dMFucjh9xg: ddPRECvTzfSGDwxceY[u2ynb8RckJiqGpeV07hEF63] = Ga2Y7HnoKI5ALiSB6dMFucjh9xg[u2ynb8RckJiqGpeV07hEF63]
	return ddPRECvTzfSGDwxceY
def TaBxzOYokcjL58fbUlF31nveR2rdqD(ddPRECvTzfSGDwxceY,kkCZc3TnBUP,bXwYjBHzsfeL8Pva,ynkzWTcZ5Cuatf8xKsSP6L,KSEyq972WH5oT,Vvju9Ht8SGxoiTa6lCs,dwD51KktlTYQWehOc2F0a4z3CPZrJs,RF0SvtkQzWsdGjX,bmRw7DqFlZiuHh0BPjQ,GG0tshD8ywnpEPCRAqJ3):
	for u2ynb8RckJiqGpeV07hEF63 in ddPRECvTzfSGDwxceY: globals()[u2ynb8RckJiqGpeV07hEF63] = ddPRECvTzfSGDwxceY[u2ynb8RckJiqGpeV07hEF63]
	global ssS9hbHUZOPrFj,xwvZn6d1zB23b9afFk
	if dwD51KktlTYQWehOc2F0a4z3CPZrJs!='menu_item':
		crLCQ89R6573HBmUFgJZfXsqhW2lp = amx9qJHkhw7oLdtVMG3.getSetting('av.language.translate')
		if crLCQ89R6573HBmUFgJZfXsqhW2lp:
			if kkCZc3TnBUP=='نعم  Yes': kkCZc3TnBUP = 'Yes'
			elif kkCZc3TnBUP=='كلا  No': kkCZc3TnBUP = 'No'
			if bXwYjBHzsfeL8Pva=='نعم  Yes': bXwYjBHzsfeL8Pva = 'Yes'
			elif bXwYjBHzsfeL8Pva=='كلا  No': bXwYjBHzsfeL8Pva = 'No'
			if ynkzWTcZ5Cuatf8xKsSP6L=='نعم  Yes': ynkzWTcZ5Cuatf8xKsSP6L = 'Yes'
			elif ynkzWTcZ5Cuatf8xKsSP6L=='كلا  No': ynkzWTcZ5Cuatf8xKsSP6L = 'No'
			kqe8AmaJG6pIvUCPSXb = z18LlakeBCowF4NfMgcqZ([kkCZc3TnBUP,bXwYjBHzsfeL8Pva,ynkzWTcZ5Cuatf8xKsSP6L,KSEyq972WH5oT,Vvju9Ht8SGxoiTa6lCs])
			if kqe8AmaJG6pIvUCPSXb: kkCZc3TnBUP,bXwYjBHzsfeL8Pva,ynkzWTcZ5Cuatf8xKsSP6L,KSEyq972WH5oT,Vvju9Ht8SGxoiTa6lCs = kqe8AmaJG6pIvUCPSXb
	if gA0m6CQUyfLG:
		Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		KSEyq972WH5oT = KSEyq972WH5oT.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		kkCZc3TnBUP = kkCZc3TnBUP.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		bXwYjBHzsfeL8Pva = bXwYjBHzsfeL8Pva.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		ynkzWTcZ5Cuatf8xKsSP6L = ynkzWTcZ5Cuatf8xKsSP6L.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	CCMu4jHfBq = KSEyq972WH5oT.count(zEgtT9cR6bFp7JXqI5VuhNeP)+1
	OVBzgjGwkvHMJZmtaRTQIDnLCN = LvopNmgkP0G4QYCUxbFs+CCMu4jHfBq*(FVAc9xENZDwRrkQ+wUvJyCnfdzirhBSlAFs870)-wUvJyCnfdzirhBSlAFs870
	if Vvju9Ht8SGxoiTa6lCs:
		qMoQCdhNXfAUr8ntbKmLaxeI6DFHO = xnsDcE014yqLrNh56UTm8B+owQ4u6WBhGAKpa
		g4VSOkvwAt9Y1zyNEU5Lp = EVFCrOoRb3lJsTQ.reshape(Vvju9Ht8SGxoiTa6lCs)
		if TTaKqy4bL3Skl:
			fsw8MgUOeAhqlit = ffadohVx0yF2bwpCWiDTA6vSELgR(k5kerqvoRTAcfl2UOHu9tZFjd,D5V4pyZnIX9fuN8JtFmiT,g4VSOkvwAt9Y1zyNEU5Lp,DipOgaXBAb14,pCtF1UX6DI4irbPyJds0M9R,qMoQCdhNXfAUr8ntbKmLaxeI6DFHO)
			eHbOW3dZFI4CvBg2JRGD6SL = WhU5RlJ1kgP7fHZc9aeGQwzvN(fsw8MgUOeAhqlit)
			GnthASmyF1cL = eHbOW3dZFI4CvBg2JRGD6SL.count(zEgtT9cR6bFp7JXqI5VuhNeP)+1
			SnyD9MzIXjKWH52gYAqeBCF14x = rd2CIYtwLyFUsNvuzQKmlkfjE+GnthASmyF1cL*qMoQCdhNXfAUr8ntbKmLaxeI6DFHO-owQ4u6WBhGAKpa
		else:
			SnyD9MzIXjKWH52gYAqeBCF14x = rd2CIYtwLyFUsNvuzQKmlkfjE+xnsDcE014yqLrNh56UTm8B
			eHbOW3dZFI4CvBg2JRGD6SL = g4VSOkvwAt9Y1zyNEU5Lp.split(zEgtT9cR6bFp7JXqI5VuhNeP)[0]
			fsw8MgUOeAhqlit = g4VSOkvwAt9Y1zyNEU5Lp.split(zEgtT9cR6bFp7JXqI5VuhNeP)[0]
	else: SnyD9MzIXjKWH52gYAqeBCF14x = rd2CIYtwLyFUsNvuzQKmlkfjE
	x0ZXFbruOJmCBq2ntyvoWTaz3YwlpR = buXoh2zimLd1+aWAbRpGsiT7g8ozOf
	if bmRw7DqFlZiuHh0BPjQ:
		sVjafxAUITDNOFzPXRB5t8lqw2 = T1TMBVledgQwUKLpnGqmk7zaIC5uYN-HHFhPjQxyvnD4KaGOVoXfq
		x0ZXFbruOJmCBq2ntyvoWTaz3YwlpR += sVjafxAUITDNOFzPXRB5t8lqw2
	else: sVjafxAUITDNOFzPXRB5t8lqw2 = 0
	if kkCZc3TnBUP or bXwYjBHzsfeL8Pva or ynkzWTcZ5Cuatf8xKsSP6L: x0ZXFbruOJmCBq2ntyvoWTaz3YwlpR += RUPKCTxn0VSo7O2Q9aGBWbtYyAl
	JakR94N85FmALl2cGHueyVv = UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4 if UTh6fnD3GQ8J0w5vgAmRuFHqsebkp4!='UPPER' else OVBzgjGwkvHMJZmtaRTQIDnLCN+SnyD9MzIXjKWH52gYAqeBCF14x+x0ZXFbruOJmCBq2ntyvoWTaz3YwlpR
	VaryDHgOnoTwiqvLcutAERKebs6S = n2MAiKLbuOv7wpGE.new('RGBA',(r3blYuifzOW,JakR94N85FmALl2cGHueyVv),(255,255,255,0))
	jyiJLwPKVc1W5qAT3bt = hN15RTFGmxM47slPe2EXdIwyZzWn.Draw(VaryDHgOnoTwiqvLcutAERKebs6S)
	OO5F7XACcxbGRh4dipev = JakR94N85FmALl2cGHueyVv-OVBzgjGwkvHMJZmtaRTQIDnLCN-x0ZXFbruOJmCBq2ntyvoWTaz3YwlpR-rd2CIYtwLyFUsNvuzQKmlkfjE
	if not bXwYjBHzsfeL8Pva and kkCZc3TnBUP and ynkzWTcZ5Cuatf8xKsSP6L:
		ssS9hbHUZOPrFj += 105
		xwvZn6d1zB23b9afFk -= 110
	import bidi.algorithm as Hu1ZSQWYqVx6FINLdhfm9EMeJg
	if KSEyq972WH5oT:
		aXufezyO6qNMbpIJQ7KjvFSG2g = LvopNmgkP0G4QYCUxbFs
		KSEyq972WH5oT = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(EVFCrOoRb3lJsTQ.reshape(KSEyq972WH5oT))
		RJBGyivQKTech8DM9xN = KSEyq972WH5oT.splitlines()
		for B71KDuTRjsXOcoh4JWbPdMSi28A in RJBGyivQKTech8DM9xN:
			if B71KDuTRjsXOcoh4JWbPdMSi28A:
				HEWu4gj6ArnSx9LkeIz0dtF,EDijGX7ATvgU6rIOpZoNSb9JLCw8RB = jyiJLwPKVc1W5qAT3bt.textsize(B71KDuTRjsXOcoh4JWbPdMSi28A,font=llHTi9v7sj5qnIJUuafO0631rkY)
				if TDU6Pr7x4LQlpu2gd=='center': avWcCyzqdlMQr2mo = hGI3UOFM7J9D4Ld8BnyrHpjTfxai1N+(r3blYuifzOW-HEWu4gj6ArnSx9LkeIz0dtF)/2
				elif TDU6Pr7x4LQlpu2gd=='right': avWcCyzqdlMQr2mo = hGI3UOFM7J9D4Ld8BnyrHpjTfxai1N+r3blYuifzOW-HEWu4gj6ArnSx9LkeIz0dtF-XSJyImB7GTUtEf8
				elif TDU6Pr7x4LQlpu2gd=='left': avWcCyzqdlMQr2mo = hGI3UOFM7J9D4Ld8BnyrHpjTfxai1N+XSJyImB7GTUtEf8
				jyiJLwPKVc1W5qAT3bt.text((avWcCyzqdlMQr2mo,aXufezyO6qNMbpIJQ7KjvFSG2g),B71KDuTRjsXOcoh4JWbPdMSi28A,font=llHTi9v7sj5qnIJUuafO0631rkY,fill='yellow')
			aXufezyO6qNMbpIJQ7KjvFSG2g += ejWwUvByas+wUvJyCnfdzirhBSlAFs870
	if kkCZc3TnBUP or bXwYjBHzsfeL8Pva or ynkzWTcZ5Cuatf8xKsSP6L:
		x0Ej4enBNpfKItA65bwdukgT1ry = OVBzgjGwkvHMJZmtaRTQIDnLCN+OO5F7XACcxbGRh4dipev+rd2CIYtwLyFUsNvuzQKmlkfjE+sVjafxAUITDNOFzPXRB5t8lqw2+buXoh2zimLd1
		if kkCZc3TnBUP:
			kkCZc3TnBUP = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(EVFCrOoRb3lJsTQ.reshape(kkCZc3TnBUP))
			Yu5LqFE4w9X,I3ax016Rw7cLVkN5qEJAXBuyhO9 = jyiJLwPKVc1W5qAT3bt.textsize(kkCZc3TnBUP,font=dMzn4mFU5YqxVZcB)
			II0V1zXAfkrKEUqChS9x = ssS9hbHUZOPrFj+0*(xwvZn6d1zB23b9afFk+GZCWRqUt1fhSKiz9oNxy4T)+(GZCWRqUt1fhSKiz9oNxy4T-Yu5LqFE4w9X)/2
			jyiJLwPKVc1W5qAT3bt.text((II0V1zXAfkrKEUqChS9x,x0Ej4enBNpfKItA65bwdukgT1ry),kkCZc3TnBUP,font=dMzn4mFU5YqxVZcB,fill='yellow')
		if bXwYjBHzsfeL8Pva:
			bXwYjBHzsfeL8Pva = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(EVFCrOoRb3lJsTQ.reshape(bXwYjBHzsfeL8Pva))
			fUKxEp0SgX9nijm5Yq,YiHsKj4zO2IgUnXoGBr = jyiJLwPKVc1W5qAT3bt.textsize(bXwYjBHzsfeL8Pva,font=dMzn4mFU5YqxVZcB)
			fn4Yj0VvhUwkDOlG2aeQ56C3mW = ssS9hbHUZOPrFj+1*(xwvZn6d1zB23b9afFk+GZCWRqUt1fhSKiz9oNxy4T)+(GZCWRqUt1fhSKiz9oNxy4T-fUKxEp0SgX9nijm5Yq)/2
			jyiJLwPKVc1W5qAT3bt.text((fn4Yj0VvhUwkDOlG2aeQ56C3mW,x0Ej4enBNpfKItA65bwdukgT1ry),bXwYjBHzsfeL8Pva,font=dMzn4mFU5YqxVZcB,fill='yellow')
		if ynkzWTcZ5Cuatf8xKsSP6L:
			ynkzWTcZ5Cuatf8xKsSP6L = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(EVFCrOoRb3lJsTQ.reshape(ynkzWTcZ5Cuatf8xKsSP6L))
			olx9mqeRPONBS7WVFrZH,NtqvD6lELkgsS4cfVO = jyiJLwPKVc1W5qAT3bt.textsize(ynkzWTcZ5Cuatf8xKsSP6L,font=dMzn4mFU5YqxVZcB)
			bbXnoyKdTliICPDQF0uxp = ssS9hbHUZOPrFj+2*(xwvZn6d1zB23b9afFk+GZCWRqUt1fhSKiz9oNxy4T)+(GZCWRqUt1fhSKiz9oNxy4T-olx9mqeRPONBS7WVFrZH)/2
			jyiJLwPKVc1W5qAT3bt.text((bbXnoyKdTliICPDQF0uxp,x0Ej4enBNpfKItA65bwdukgT1ry),ynkzWTcZ5Cuatf8xKsSP6L,font=dMzn4mFU5YqxVZcB,fill='yellow')
	if Vvju9Ht8SGxoiTa6lCs:
		u2PNcpI4LtfzikreJFBY7S,hBLcXKTxbyD6s9nRt1UFSrgeH = [],[]
		fsw8MgUOeAhqlit = fvyLaxSo2Q4j0JCPcdRiU(fsw8MgUOeAhqlit)
		b6kA1D3aQX = fsw8MgUOeAhqlit.split('_sss__newline_')
		for ItPxAn9Gg85bTaVq in b6kA1D3aQX:
			sEZT6lNW8AC0FMkSJPujQ2D = RF0SvtkQzWsdGjX
			if   '_sss__lineleft_' in ItPxAn9Gg85bTaVq: sEZT6lNW8AC0FMkSJPujQ2D = 'left'
			elif '_sss__lineright_' in ItPxAn9Gg85bTaVq: sEZT6lNW8AC0FMkSJPujQ2D = 'right'
			elif '_sss__linecenter_' in ItPxAn9Gg85bTaVq: sEZT6lNW8AC0FMkSJPujQ2D = 'center'
			GtQ7cswoh0eKn8alBm4P = ItPxAn9Gg85bTaVq
			MJaSienlHtA2WZXN = oo9kuULlebNgpY0Om.findall('_sss__.*?_',ItPxAn9Gg85bTaVq,oo9kuULlebNgpY0Om.DOTALL)
			for sLE5F0Pgui1YrpNA6TZBH4 in MJaSienlHtA2WZXN: GtQ7cswoh0eKn8alBm4P = GtQ7cswoh0eKn8alBm4P.replace(sLE5F0Pgui1YrpNA6TZBH4,G9G0YqivIfmUWO8K)
			if GtQ7cswoh0eKn8alBm4P==G9G0YqivIfmUWO8K: HEWu4gj6ArnSx9LkeIz0dtF,EDijGX7ATvgU6rIOpZoNSb9JLCw8RB = 0,qMoQCdhNXfAUr8ntbKmLaxeI6DFHO
			else: HEWu4gj6ArnSx9LkeIz0dtF,EDijGX7ATvgU6rIOpZoNSb9JLCw8RB = jyiJLwPKVc1W5qAT3bt.textsize(GtQ7cswoh0eKn8alBm4P,font=D5V4pyZnIX9fuN8JtFmiT)
			if   sEZT6lNW8AC0FMkSJPujQ2D=='left': hVaMQnig7ZuYHbDXtRvFwoITJN = ha7L1mKdMe8JsgktIDX2yoV+z56W2AvC4gHirKYmlbexup87a
			elif sEZT6lNW8AC0FMkSJPujQ2D=='right': hVaMQnig7ZuYHbDXtRvFwoITJN = ha7L1mKdMe8JsgktIDX2yoV+z56W2AvC4gHirKYmlbexup87a+pCtF1UX6DI4irbPyJds0M9R-HEWu4gj6ArnSx9LkeIz0dtF
			elif sEZT6lNW8AC0FMkSJPujQ2D=='center': hVaMQnig7ZuYHbDXtRvFwoITJN = ha7L1mKdMe8JsgktIDX2yoV+z56W2AvC4gHirKYmlbexup87a+(pCtF1UX6DI4irbPyJds0M9R-HEWu4gj6ArnSx9LkeIz0dtF)/2
			if hVaMQnig7ZuYHbDXtRvFwoITJN<z56W2AvC4gHirKYmlbexup87a: hVaMQnig7ZuYHbDXtRvFwoITJN = ha7L1mKdMe8JsgktIDX2yoV+z56W2AvC4gHirKYmlbexup87a
			u2PNcpI4LtfzikreJFBY7S.append(hVaMQnig7ZuYHbDXtRvFwoITJN)
			hBLcXKTxbyD6s9nRt1UFSrgeH.append(HEWu4gj6ArnSx9LkeIz0dtF)
		hVaMQnig7ZuYHbDXtRvFwoITJN = u2PNcpI4LtfzikreJFBY7S[0]
		UqiRlkXept6nQOY2 = fsw8MgUOeAhqlit.split('_sss_')
		uPFDe8vO1Z7wWlTLx46tad0 = (255,255,255,255)
		rrQEUHaR6ITCVxc2uJhjgSbsn = uPFDe8vO1Z7wWlTLx46tad0
		UmCT8dsEnD7SuMJbWaF0G,PlnbiOJuyAhgvDW4Mrm3VcG6N = 0,0
		nQI376jAuMNWlb0 = False
		LLpB6DcqdYfzkXPAChsIaT = 0
		obHP0QaNW7ifd5Ml8Ip3tKV9BCwZ = OVBzgjGwkvHMJZmtaRTQIDnLCN+rd2CIYtwLyFUsNvuzQKmlkfjE/2
		if SnyD9MzIXjKWH52gYAqeBCF14x<(OO5F7XACcxbGRh4dipev+rd2CIYtwLyFUsNvuzQKmlkfjE):
			kYzxRM7wqU = (OO5F7XACcxbGRh4dipev+rd2CIYtwLyFUsNvuzQKmlkfjE-SnyD9MzIXjKWH52gYAqeBCF14x)/2
			obHP0QaNW7ifd5Ml8Ip3tKV9BCwZ = OVBzgjGwkvHMJZmtaRTQIDnLCN+rd2CIYtwLyFUsNvuzQKmlkfjE+kYzxRM7wqU-xnsDcE014yqLrNh56UTm8B/2
		for B71KDuTRjsXOcoh4JWbPdMSi28A in UqiRlkXept6nQOY2:
			if not B71KDuTRjsXOcoh4JWbPdMSi28A or (B71KDuTRjsXOcoh4JWbPdMSi28A and ord(B71KDuTRjsXOcoh4JWbPdMSi28A[0])==65279): continue
			iiAw9xofbzl4k3hFa1n2JQe7SVT6d = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_newline_',1)
			up9vZ6qYyX0mh47VUwsJGF = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_newcolor',1)
			lLkruc4AaEyZSxQOCmIh21e0Js = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_endcolor_',1)
			a7aV3EyJ5NjnmAuMp6Ye = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_linertl_',1)
			a0ZlKCQ6Uh74ORyIk = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_lineleft_',1)
			a6IntJi4kdlhqG = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_lineright_',1)
			VWkHsfr2lnCKx4BQ50GoTU9d = B71KDuTRjsXOcoh4JWbPdMSi28A.split('_linecenter_',1)
			if len(iiAw9xofbzl4k3hFa1n2JQe7SVT6d)>1:
				LLpB6DcqdYfzkXPAChsIaT += 1
				B71KDuTRjsXOcoh4JWbPdMSi28A = iiAw9xofbzl4k3hFa1n2JQe7SVT6d[1]
				UmCT8dsEnD7SuMJbWaF0G = 0
				hVaMQnig7ZuYHbDXtRvFwoITJN = u2PNcpI4LtfzikreJFBY7S[LLpB6DcqdYfzkXPAChsIaT]
				PlnbiOJuyAhgvDW4Mrm3VcG6N += qMoQCdhNXfAUr8ntbKmLaxeI6DFHO
				nQI376jAuMNWlb0 = False
			elif len(up9vZ6qYyX0mh47VUwsJGF)>1:
				B71KDuTRjsXOcoh4JWbPdMSi28A = up9vZ6qYyX0mh47VUwsJGF[1]
				rrQEUHaR6ITCVxc2uJhjgSbsn = B71KDuTRjsXOcoh4JWbPdMSi28A[0:8]
				rrQEUHaR6ITCVxc2uJhjgSbsn = '#'+rrQEUHaR6ITCVxc2uJhjgSbsn[2:]
				B71KDuTRjsXOcoh4JWbPdMSi28A = B71KDuTRjsXOcoh4JWbPdMSi28A[9:]
			elif len(lLkruc4AaEyZSxQOCmIh21e0Js)>1:
				B71KDuTRjsXOcoh4JWbPdMSi28A = lLkruc4AaEyZSxQOCmIh21e0Js[1]
				rrQEUHaR6ITCVxc2uJhjgSbsn = uPFDe8vO1Z7wWlTLx46tad0
			elif len(a7aV3EyJ5NjnmAuMp6Ye)>1:
				B71KDuTRjsXOcoh4JWbPdMSi28A = a7aV3EyJ5NjnmAuMp6Ye[1]
				nQI376jAuMNWlb0 = True
				UmCT8dsEnD7SuMJbWaF0G = hBLcXKTxbyD6s9nRt1UFSrgeH[LLpB6DcqdYfzkXPAChsIaT]
			elif len(a0ZlKCQ6Uh74ORyIk)>1: B71KDuTRjsXOcoh4JWbPdMSi28A = a0ZlKCQ6Uh74ORyIk[1]
			elif len(a6IntJi4kdlhqG)>1: B71KDuTRjsXOcoh4JWbPdMSi28A = a6IntJi4kdlhqG[1]
			elif len(VWkHsfr2lnCKx4BQ50GoTU9d)>1: B71KDuTRjsXOcoh4JWbPdMSi28A = VWkHsfr2lnCKx4BQ50GoTU9d[1]
			if B71KDuTRjsXOcoh4JWbPdMSi28A:
				apZUGvO50RMuYswcyxNf6robjeAqX = obHP0QaNW7ifd5Ml8Ip3tKV9BCwZ+PlnbiOJuyAhgvDW4Mrm3VcG6N
				B71KDuTRjsXOcoh4JWbPdMSi28A = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(B71KDuTRjsXOcoh4JWbPdMSi28A)
				HEWu4gj6ArnSx9LkeIz0dtF,EDijGX7ATvgU6rIOpZoNSb9JLCw8RB = jyiJLwPKVc1W5qAT3bt.textsize(B71KDuTRjsXOcoh4JWbPdMSi28A,font=D5V4pyZnIX9fuN8JtFmiT)
				if nQI376jAuMNWlb0: UmCT8dsEnD7SuMJbWaF0G -= HEWu4gj6ArnSx9LkeIz0dtF
				YYjQdCZ7Xvn1sIlWPAHq = hVaMQnig7ZuYHbDXtRvFwoITJN+UmCT8dsEnD7SuMJbWaF0G
				jyiJLwPKVc1W5qAT3bt.text((YYjQdCZ7Xvn1sIlWPAHq,apZUGvO50RMuYswcyxNf6robjeAqX),B71KDuTRjsXOcoh4JWbPdMSi28A,font=D5V4pyZnIX9fuN8JtFmiT,fill=rrQEUHaR6ITCVxc2uJhjgSbsn)
				if dwD51KktlTYQWehOc2F0a4z3CPZrJs=='menu_item': jyiJLwPKVc1W5qAT3bt.text((YYjQdCZ7Xvn1sIlWPAHq+1,apZUGvO50RMuYswcyxNf6robjeAqX+1),B71KDuTRjsXOcoh4JWbPdMSi28A,font=D5V4pyZnIX9fuN8JtFmiT,fill=rrQEUHaR6ITCVxc2uJhjgSbsn)
				if not nQI376jAuMNWlb0: UmCT8dsEnD7SuMJbWaF0G += HEWu4gj6ArnSx9LkeIz0dtF
				if apZUGvO50RMuYswcyxNf6robjeAqX>OO5F7XACcxbGRh4dipev+qMoQCdhNXfAUr8ntbKmLaxeI6DFHO: break
	if dwD51KktlTYQWehOc2F0a4z3CPZrJs=='menu_item':
		VGBA3Z4YCbeIDl0dSFTwi8UP = iw7PdDZ3eEyu.copy()
		SSCU3jdyFn2V.sleep(0.05)
		VGBA3Z4YCbeIDl0dSFTwi8UP.paste(GM8LvBPOXaq,(0,0),mask=VaryDHgOnoTwiqvLcutAERKebs6S)
	else: VGBA3Z4YCbeIDl0dSFTwi8UP = VaryDHgOnoTwiqvLcutAERKebs6S
	if gA0m6CQUyfLG: GG0tshD8ywnpEPCRAqJ3 = GG0tshD8ywnpEPCRAqJ3.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	try: VGBA3Z4YCbeIDl0dSFTwi8UP.save(GG0tshD8ywnpEPCRAqJ3)
	except UnicodeError:
		if gA0m6CQUyfLG:
			GG0tshD8ywnpEPCRAqJ3 = GG0tshD8ywnpEPCRAqJ3.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			VGBA3Z4YCbeIDl0dSFTwi8UP.save(GG0tshD8ywnpEPCRAqJ3)
	return JakR94N85FmALl2cGHueyVv
def ffadohVx0yF2bwpCWiDTA6vSELgR(k5kerqvoRTAcfl2UOHu9tZFjd,D5V4pyZnIX9fuN8JtFmiT,Pz20LflSYo6J7hck,WgMLKG0ZTYohDI,pCtF1UX6DI4irbPyJds0M9R,gUrhYDiMv9W5SRsqmyazT):
	oM38TPpcutW496kZNAFnmJ,gdU2j9uyGw5,hyK5VO4TIncS7CkDBL9Z3AeWv1r = G9G0YqivIfmUWO8K,0,15000
	Pz20LflSYo6J7hck = Pz20LflSYo6J7hck.replace('[COLOR ','[COLOR:::')
	dbKp3y6otkWNlD91nZLEf = pCtF1UX6DI4irbPyJds0M9R-WgMLKG0ZTYohDI*2
	for JJPzR5bLEoeHyCjfOw in Pz20LflSYo6J7hck.splitlines():
		gdU2j9uyGw5 += gUrhYDiMv9W5SRsqmyazT
		cpDMCWIRLhFHvqQlO7BsGrK0,KKrIwi8gjWLZB6mEQzTfcVYC9d5a = 0,G9G0YqivIfmUWO8K
		for njQY1i76Ns in JJPzR5bLEoeHyCjfOw.split(ww0sZkBU9JKd):
			VChIeJdmpQ8c9 = WhU5RlJ1kgP7fHZc9aeGQwzvN(ww0sZkBU9JKd+njQY1i76Ns)
			oy4vXVi8AqjFN9hRTptELa3l0uwxW,e3Vq9a7nbZzOYuUc1tkTvoyBAPj = k5kerqvoRTAcfl2UOHu9tZFjd.textsize(VChIeJdmpQ8c9,font=D5V4pyZnIX9fuN8JtFmiT)
			if cpDMCWIRLhFHvqQlO7BsGrK0+oy4vXVi8AqjFN9hRTptELa3l0uwxW<dbKp3y6otkWNlD91nZLEf:
				if not KKrIwi8gjWLZB6mEQzTfcVYC9d5a: KKrIwi8gjWLZB6mEQzTfcVYC9d5a += njQY1i76Ns
				else: KKrIwi8gjWLZB6mEQzTfcVYC9d5a += ww0sZkBU9JKd+njQY1i76Ns
				cpDMCWIRLhFHvqQlO7BsGrK0 += oy4vXVi8AqjFN9hRTptELa3l0uwxW
			else:
				if oy4vXVi8AqjFN9hRTptELa3l0uwxW<dbKp3y6otkWNlD91nZLEf:
					KKrIwi8gjWLZB6mEQzTfcVYC9d5a += '\n '+njQY1i76Ns
					gdU2j9uyGw5 += gUrhYDiMv9W5SRsqmyazT
					cpDMCWIRLhFHvqQlO7BsGrK0 = oy4vXVi8AqjFN9hRTptELa3l0uwxW
				else:
					while oy4vXVi8AqjFN9hRTptELa3l0uwxW>dbKp3y6otkWNlD91nZLEf:
						for KJZlbgk2TdD5GWQFqucMP in range(1,len(ww0sZkBU9JKd+njQY1i76Ns),1):
							YMjWQAbLR0mgK2cBkvPX3 = ww0sZkBU9JKd+njQY1i76Ns[:KJZlbgk2TdD5GWQFqucMP]
							D6Dxf1qdKo7QuiAe = njQY1i76Ns[KJZlbgk2TdD5GWQFqucMP:]
							U290alXAqWemb = WhU5RlJ1kgP7fHZc9aeGQwzvN(YMjWQAbLR0mgK2cBkvPX3)
							C2CBuzrjaIULPYO8bJdqXR7,XoDqck5avQ9 = k5kerqvoRTAcfl2UOHu9tZFjd.textsize(U290alXAqWemb,font=D5V4pyZnIX9fuN8JtFmiT)
							if cpDMCWIRLhFHvqQlO7BsGrK0+C2CBuzrjaIULPYO8bJdqXR7>dbKp3y6otkWNlD91nZLEf:
								ccrKsoCPQiXS = oy4vXVi8AqjFN9hRTptELa3l0uwxW-C2CBuzrjaIULPYO8bJdqXR7
								KKrIwi8gjWLZB6mEQzTfcVYC9d5a += YMjWQAbLR0mgK2cBkvPX3+zEgtT9cR6bFp7JXqI5VuhNeP
								gdU2j9uyGw5 += gUrhYDiMv9W5SRsqmyazT
								oy4vXVi8AqjFN9hRTptELa3l0uwxW = ccrKsoCPQiXS
								if ccrKsoCPQiXS>dbKp3y6otkWNlD91nZLEf:
									cpDMCWIRLhFHvqQlO7BsGrK0 = 0
									njQY1i76Ns = D6Dxf1qdKo7QuiAe
								else:
									cpDMCWIRLhFHvqQlO7BsGrK0 = ccrKsoCPQiXS
									KKrIwi8gjWLZB6mEQzTfcVYC9d5a += D6Dxf1qdKo7QuiAe
								break
				if gdU2j9uyGw5>hyK5VO4TIncS7CkDBL9Z3AeWv1r: break
		oM38TPpcutW496kZNAFnmJ += zEgtT9cR6bFp7JXqI5VuhNeP+KKrIwi8gjWLZB6mEQzTfcVYC9d5a
		if gdU2j9uyGw5>hyK5VO4TIncS7CkDBL9Z3AeWv1r: break
	oM38TPpcutW496kZNAFnmJ = oM38TPpcutW496kZNAFnmJ[1:]
	oM38TPpcutW496kZNAFnmJ = oM38TPpcutW496kZNAFnmJ.replace('[COLOR:::','[COLOR ')
	return oM38TPpcutW496kZNAFnmJ
def WhU5RlJ1kgP7fHZc9aeGQwzvN(njQY1i76Ns):
	if '[' in njQY1i76Ns and ']' in njQY1i76Ns:
		MJaSienlHtA2WZXN = [zzGfwLAyN5HTxUoJeaivY,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		T0tGSyUl7Zj = oo9kuULlebNgpY0Om.findall('\[COLOR .*?\]',njQY1i76Ns,oo9kuULlebNgpY0Om.DOTALL)
		w5UnMNl4kKp = oo9kuULlebNgpY0Om.findall('\[COLOR:::.*?\]',njQY1i76Ns,oo9kuULlebNgpY0Om.DOTALL)
		FSDqzu1g2o8WeXbnL = MJaSienlHtA2WZXN+T0tGSyUl7Zj+w5UnMNl4kKp
		for sLE5F0Pgui1YrpNA6TZBH4 in FSDqzu1g2o8WeXbnL: njQY1i76Ns = njQY1i76Ns.replace(sLE5F0Pgui1YrpNA6TZBH4,G9G0YqivIfmUWO8K)
	return njQY1i76Ns
def fvyLaxSo2Q4j0JCPcdRiU(Vvju9Ht8SGxoiTa6lCs):
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zEgtT9cR6bFp7JXqI5VuhNeP,'_sss__newline_')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RTL]','_sss__linertl_')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[LEFT]','_sss__lineleft_')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[RIGHT]','_sss__lineright_')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[CENTER]','_sss__linecenter_')
	Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace(zzGfwLAyN5HTxUoJeaivY,'_sss__endcolor_')
	OgGXjJ4uARhsEr5dl = oo9kuULlebNgpY0Om.findall('\[COLOR (.*?)\]',Vvju9Ht8SGxoiTa6lCs,oo9kuULlebNgpY0Om.DOTALL)
	for Y6Lcdeo0GBa8hQN2tPOzF9mXyZk in OgGXjJ4uARhsEr5dl: Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.replace('[COLOR '+Y6Lcdeo0GBa8hQN2tPOzF9mXyZk+']','_sss__newcolor'+Y6Lcdeo0GBa8hQN2tPOzF9mXyZk+'_')
	return Vvju9Ht8SGxoiTa6lCs
def AyU7CaxXKirHj6kISTMR0d1mgZlJ4s(ASg9yePcQnDzlBhr0a,YwC7jt5BQHhTUvbdGeM6f2ZLx=G9G0YqivIfmUWO8K):
	if not YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Label')
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).strip(ww0sZkBU9JKd)
	if ASg9yePcQnDzlBhr0a: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace('[COLOR ',G9G0YqivIfmUWO8K).replace(']',G9G0YqivIfmUWO8K)
	else: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(ipjCIhwEXsbadR,G9G0YqivIfmUWO8K).replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,G9G0YqivIfmUWO8K).replace(HPYodKgEM7npNrRJmazXDxWA,G9G0YqivIfmUWO8K).replace(a7aDsfFrVq20,G9G0YqivIfmUWO8K)
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)
	YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.replace(wLgGlRoMI589yT6j1rvbW,G9G0YqivIfmUWO8K).replace(Leu8GC4bRxh6How7I5U,G9G0YqivIfmUWO8K)
	GdSuMZW4FHJ0B2L9o5q37UaCwTxrip = oo9kuULlebNgpY0Om.findall('\d\d:\d\d ',YwC7jt5BQHhTUvbdGeM6f2ZLx,oo9kuULlebNgpY0Om.DOTALL)
	if GdSuMZW4FHJ0B2L9o5q37UaCwTxrip: YwC7jt5BQHhTUvbdGeM6f2ZLx = YwC7jt5BQHhTUvbdGeM6f2ZLx.split(GdSuMZW4FHJ0B2L9o5q37UaCwTxrip[0],1)[1]
	if not YwC7jt5BQHhTUvbdGeM6f2ZLx: YwC7jt5BQHhTUvbdGeM6f2ZLx = 'Main Menu'
	return YwC7jt5BQHhTUvbdGeM6f2ZLx
def jHk81i3RbxZ(gte6YE2JupmKiP):
	ssjnay2dXlNhkwcQS = G9G0YqivIfmUWO8K.join(KJZlbgk2TdD5GWQFqucMP for KJZlbgk2TdD5GWQFqucMP in gte6YE2JupmKiP if KJZlbgk2TdD5GWQFqucMP not in '\/":*?<>|'+vq9L3uo7rDVm2zPO4h)
	return ssjnay2dXlNhkwcQS
def mq1uWkCvVfw(bjSL1IZNRp59z2):
	iQ2XdBOtrLg = oo9kuULlebNgpY0Om.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",bjSL1IZNRp59z2,oo9kuULlebNgpY0Om.S)
	if iQ2XdBOtrLg:
		iiEwygLCQb7ZdFzOhDt3K8v,lC8g1UhziIMNeQPamRGTK7BA9pj = iQ2XdBOtrLg[0]
		iiEwygLCQb7ZdFzOhDt3K8v = oo9kuULlebNgpY0Om.findall("=[\r\n\s\t]+'(.*?)';", iiEwygLCQb7ZdFzOhDt3K8v, oo9kuULlebNgpY0Om.S)[0]
		if iiEwygLCQb7ZdFzOhDt3K8v and lC8g1UhziIMNeQPamRGTK7BA9pj:
			dJwsj3KEPZYr4gqb0F = iiEwygLCQb7ZdFzOhDt3K8v.replace("'",G9G0YqivIfmUWO8K).replace("+",G9G0YqivIfmUWO8K).replace("\n",G9G0YqivIfmUWO8K).replace("\r",G9G0YqivIfmUWO8K)
			BEL5PtaCho6N0Fx = dJwsj3KEPZYr4gqb0F.split('.')
			bjSL1IZNRp59z2 = G9G0YqivIfmUWO8K
			for lPQr0eR8CSDqUGs4jFLyI in BEL5PtaCho6N0Fx:
				UMNm9LhIEYBkwrG = jaFsD83SB9ZQkrxeI.b64decode(lPQr0eR8CSDqUGs4jFLyI+'==').decode(f3uIcZ2C6pzbX1JlFBrVOdt)
				NNokLdarEmzJqH2yw3bRsQn08 = oo9kuULlebNgpY0Om.findall('\d+', UMNm9LhIEYBkwrG, oo9kuULlebNgpY0Om.S)
				if NNokLdarEmzJqH2yw3bRsQn08:
					iB0JeMKkFqhXaH3wt = int(NNokLdarEmzJqH2yw3bRsQn08[0])
					iB0JeMKkFqhXaH3wt += int(lC8g1UhziIMNeQPamRGTK7BA9pj)
					bjSL1IZNRp59z2 = bjSL1IZNRp59z2 + chr(iB0JeMKkFqhXaH3wt)
			if LTze51miOknVcslNF43WSA6vMjYZt: bjSL1IZNRp59z2 = bjSL1IZNRp59z2.encode('iso-8859-1').decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	return bjSL1IZNRp59z2
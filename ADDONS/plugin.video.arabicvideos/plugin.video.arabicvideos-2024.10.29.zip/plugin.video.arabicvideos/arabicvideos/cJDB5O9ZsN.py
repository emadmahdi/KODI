# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'WECIMA2'
TdtCLWYSJNK8zOb = '_WC2_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['مصارعة حرة','wwe']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==1000: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==1001: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==1002: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==1003: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url,text)
	elif mode==1004: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'CATEGORIES___'+text)
	elif mode==1005: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'FILTERS___'+text)
	elif mode==1006: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==1009: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text,url)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',ffVP3AK5RqhkgYnjZoNis,1009,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',ffVP3AK5RqhkgYnjZoNis+'/AjaxCenter/RightBar',1004)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',ffVP3AK5RqhkgYnjZoNis+'/AjaxCenter/RightBar',1005)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('class="menu-item.*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title==G9G0YqivIfmUWO8K: continue
			if any(yW70dtahIjkPCJg2TA in title.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1006)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('hoverable activable(.*?)hoverable activable',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1006,M4qkBDatEIf3T)
	return GagwMT6q3oc7UZ2Q
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'class="Slider--Grid"' in GagwMT6q3oc7UZ2Q:
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',url,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="list--Tabsui"(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1001)
	return
def UUhwKBgI2nt(eeVzsYl2MjuU4DxpkWrgBf5aA0,type=G9G0YqivIfmUWO8K):
	if '::' in eeVzsYl2MjuU4DxpkWrgBf5aA0:
		XjWHSnbf6NwhMgpKt4yLY7AkIT,url = eeVzsYl2MjuU4DxpkWrgBf5aA0.split('::')
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(XjWHSnbf6NwhMgpKt4yLY7AkIT,'url')
		url = yVgLqfcUN1iO4+url
	else: url,XjWHSnbf6NwhMgpKt4yLY7AkIT = eeVzsYl2MjuU4DxpkWrgBf5aA0,eeVzsYl2MjuU4DxpkWrgBf5aA0
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if type=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type in ['filters','search']:
		cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q.replace('\\/','/').replace('\\"','"')]
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"Grid--WecimaPosts"(.*?)"RightUI"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
			if any(yW70dtahIjkPCJg2TA in title.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			M4qkBDatEIf3T = zDBtm4MwIagkfcpE5oxJOAq6lZQY(M4qkBDatEIf3T)
			Y6YdkAMluFbwx = zDBtm4MwIagkfcpE5oxJOAq6lZQY(Y6YdkAMluFbwx)
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			title = title.replace('مشاهدة ',G9G0YqivIfmUWO8K)
			if '/series/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1003,M4qkBDatEIf3T)
			elif 'حلقة' in title:
				RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) +حلقة +\d+',title,oo9kuULlebNgpY0Om.DOTALL)
				if RnV3EqPNpXTDuI7: title = '_MOD_' + RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1003,M4qkBDatEIf3T)
			else:
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1002,M4qkBDatEIf3T)
		if type=='filters':
			CoX5H3D7jVWGapxst = oo9kuULlebNgpY0Om.findall('"more_button_page":(.*?),',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if CoX5H3D7jVWGapxst:
				count = CoX5H3D7jVWGapxst[0]
				Y6YdkAMluFbwx = url+'/offset/'+count
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة أخرى',Y6YdkAMluFbwx,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
		elif type==G9G0YqivIfmUWO8K:
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if cSLKDEATk7y10ovtGZCwF:
				BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
				items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,title in items:
					if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
					title = 'صفحة '+kD2wGe8Oh4T7Cj3BMsy0(title)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1001)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url,data=G9G0YqivIfmUWO8K):
	if data:
		data = bRCSwcA89e4J7pqdays5PxGiD2('dict',data)
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-EPISODES-1st')
	else: D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	GagwMT6q3oc7UZ2Q = aKAyEnjxIlzZtCTv(GagwMT6q3oc7UZ2Q)
	name = oo9kuULlebNgpY0Om.findall('itemprop="item" href=".*?/series/(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if name: name = name[-1].replace('-',ww0sZkBU9JKd).strip(ww0sZkBU9JKd)
	else: name = G9G0YqivIfmUWO8K
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="Seasons--Episodes"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not data and cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-id="(.*?)" data-season="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)>1:
			for HGD02clisfMEkyYwX5PRebUnAu,vJNbaDZ4loufnwGsp,title in items:
				title = title.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				if name: title += ' - '+name
				Y6YdkAMluFbwx = 'https://wecima.click/ajax/Episode'
				pPIbdY3oKe = {'season':vJNbaDZ4loufnwGsp,'post_id':HGD02clisfMEkyYwX5PRebUnAu}
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1003,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,str(pPIbdY3oKe))
			return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0] if cSLKDEATk7y10ovtGZCwF else GagwMT6q3oc7UZ2Q
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	for Y6YdkAMluFbwx,title in items:
		title = title.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		if name: title += ' - '+name
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1002)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd:
		UUKJu0BWM9x4vQ7j6HLDaISyieTd = [UUKJu0BWM9x4vQ7j6HLDaISyieTd[0][0],UUKJu0BWM9x4vQ7j6HLDaISyieTd[0][1]]
		if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-url="(.*?)".*?strong>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if name=='سيرفر وي سيما': name = 'wecima'
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__watch'
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('class="List--Download.*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua:
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-PLAY-2nd')
		BN1KdkzCmvshw = D7omduSeM5Gk.content
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in items:
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall('\d\d\d+',I5chimw4D1okfxlBE2UpbuHJvStsZ,oo9kuULlebNgpY0Om.DOTALL)
			if I5chimw4D1okfxlBE2UpbuHJvStsZ: I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ[0]
			else: I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named=wecima'+'__download'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search,vkPoTrNVqlI4xX6As1Ogae3UpSm=G9G0YqivIfmUWO8K):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	if not vkPoTrNVqlI4xX6As1Ogae3UpSm:
		vkPoTrNVqlI4xX6As1Ogae3UpSm = ffVP3AK5RqhkgYnjZoNis
	XXzvmn7ewM8yBfoxua = vkPoTrNVqlI4xX6As1Ogae3UpSm+'/AjaxCenter/Searching/'+search+'/'
	UUhwKBgI2nt(XXzvmn7ewM8yBfoxua,'search')
	return
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(eeVzsYl2MjuU4DxpkWrgBf5aA0,filter):
	if '??' in eeVzsYl2MjuU4DxpkWrgBf5aA0: url = eeVzsYl2MjuU4DxpkWrgBf5aA0.split('//getposts??')[0]
	else: url = eeVzsYl2MjuU4DxpkWrgBf5aA0
	filter = filter.replace('_FORGETRESULTS_',G9G0YqivIfmUWO8K)
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='CATEGORIES':
		if bcFXUN0LqngMKR684BWDCTY5[0]+'==' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = bcFXUN0LqngMKR684BWDCTY5[0]
		for KT9tdUH3hmiLZCEFz in range(len(bcFXUN0LqngMKR684BWDCTY5[0:-1])):
			if bcFXUN0LqngMKR684BWDCTY5[KT9tdUH3hmiLZCEFz]+'==' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = bcFXUN0LqngMKR684BWDCTY5[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+nxguK9laUWBGHIR4zEsTo7+'==0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+nxguK9laUWBGHIR4zEsTo7+'==0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'//getposts??'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='FILTERS':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'//getposts??'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XXzvmn7ewM8yBfoxua,eeVzsYl2MjuU4DxpkWrgBf5aA0)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',AauCDOGPIN4hnrmHoX1Lv7,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',AauCDOGPIN4hnrmHoX1Lv7,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'WECIMA2-FILTERS_MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('\\"','"').replace('\\/','/')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<wecima--filter(.*?)</wecima--filter>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',BN1KdkzCmvshw+'<filterbox',oo9kuULlebNgpY0Om.DOTALL)
	dict = {}
	for TaVcxgUOBpSwX6Rl9PYkzeudt1,name,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		name = zDBtm4MwIagkfcpE5oxJOAq6lZQY(name)
		if 'interest' in TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
		items = oo9kuULlebNgpY0Om.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if '==' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='CATEGORIES':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<=1:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==bcFXUN0LqngMKR684BWDCTY5[-1]: UUhwKBgI2nt(XXzvmn7ewM8yBfoxua)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'CATEGORIES___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XXzvmn7ewM8yBfoxua,eeVzsYl2MjuU4DxpkWrgBf5aA0)
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==bcFXUN0LqngMKR684BWDCTY5[-1]:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',AauCDOGPIN4hnrmHoX1Lv7,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,1004,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='FILTERS':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'==0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'==0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name+': الجميع',XXzvmn7ewM8yBfoxua,1005,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR+'_FORGETRESULTS_')
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			name = zDBtm4MwIagkfcpE5oxJOAq6lZQY(name)
			M0nQuWoaIxhSdqyV9N = zDBtm4MwIagkfcpE5oxJOAq6lZQY(M0nQuWoaIxhSdqyV9N)
			if yW70dtahIjkPCJg2TA=='r' or yW70dtahIjkPCJg2TA=='nc-17': continue
			if any(yW70dtahIjkPCJg2TA in M0nQuWoaIxhSdqyV9N.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' in M0nQuWoaIxhSdqyV9N: continue
			if 'الكل' in M0nQuWoaIxhSdqyV9N: continue
			if 'n-a' in yW70dtahIjkPCJg2TA: continue
			if M0nQuWoaIxhSdqyV9N==G9G0YqivIfmUWO8K: M0nQuWoaIxhSdqyV9N = yW70dtahIjkPCJg2TA
			GdTzrVD9t0cFUu5 = M0nQuWoaIxhSdqyV9N
			qsQBKShZJyOFX3zCT2kdfoI = oo9kuULlebNgpY0Om.findall('<name>(.*?)</name>',M0nQuWoaIxhSdqyV9N,oo9kuULlebNgpY0Om.DOTALL)
			if qsQBKShZJyOFX3zCT2kdfoI: GdTzrVD9t0cFUu5 = qsQBKShZJyOFX3zCT2kdfoI[0]
			GS7Y93B0b8TLxueF = name+': '+GdTzrVD9t0cFUu5
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = GS7Y93B0b8TLxueF
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=='+GdTzrVD9t0cFUu5
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			if type=='FILTERS':
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,url,1005,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and bcFXUN0LqngMKR684BWDCTY5[-2]+'==' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'modified_filters')
				XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'//getposts??'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				AauCDOGPIN4hnrmHoX1Lv7 = V8Qsn10rM6fpcRzm5wqT7Cxt2(XjWHSnbf6NwhMgpKt4yLY7AkIT,eeVzsYl2MjuU4DxpkWrgBf5aA0)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,AauCDOGPIN4hnrmHoX1Lv7,1001,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,url,1004,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
bcFXUN0LqngMKR684BWDCTY5 = ['genre','release-year','nation']
PxEvV69renqAkTHIhSwCGFd = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def V8Qsn10rM6fpcRzm5wqT7Cxt2(XXzvmn7ewM8yBfoxua,XjWHSnbf6NwhMgpKt4yLY7AkIT):
	if '/AjaxCenter/RightBar' in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace('//getposts??','::/AjaxCenter/Filtering/')
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace('==','/')
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace('&&','/')
	return XXzvmn7ewM8yBfoxua
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&&')
	R9h6MqBxlsEpNztI0AU,lOaCfpSNzejn = {},G9G0YqivIfmUWO8K
	if '==' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('==')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	for key in PxEvV69renqAkTHIhSwCGFd:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&&'+key+'=='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&&'+key+'=='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&&')
	return lOaCfpSNzejn
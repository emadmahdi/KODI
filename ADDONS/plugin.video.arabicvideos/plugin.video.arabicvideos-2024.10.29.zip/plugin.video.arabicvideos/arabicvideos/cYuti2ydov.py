# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'MOVS4U'
TdtCLWYSJNK8zOb = '_M4U_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['انواع افلام','جودات افلام']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==380: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==381: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==382: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==383: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==389: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,389,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المميزة',ffVP3AK5RqhkgYnjZoNis,381,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الجانبية',ffVP3AK5RqhkgYnjZoNis,381,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'sider')
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'MOVS4U-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = oo9kuULlebNgpY0Om.findall('<header>.*?<h2>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for JXKAgPztneLxQh in range(len(items)):
		title = items[JXKAgPztneLxQh]
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,ffVP3AK5RqhkgYnjZoNis,381,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'latest'+str(JXKAgPztneLxQh))
	BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="menu"(.*?)id="contenedor"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw += cSLKDEATk7y10ovtGZCwF[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="sidebar(.*?)aside',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw += cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	n6m2IWeNsk7i = True
	for Y6YdkAMluFbwx,title in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if title=='الأعلى مشاهدة':
			if n6m2IWeNsk7i:
				title = 'الافلام '+title
				n6m2IWeNsk7i = False
			else: title = 'المسلسلات '+title
		if title not in tlcXBJEfIHF02vQ6yxSom9z1:
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,381)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,type):
	BN1KdkzCmvshw,items = [],[]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'MOVS4U-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if type=='search':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="search-page"(.*?)class="sidebar',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='sider':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="widget(.*?)class="widget',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		X7mAoIQJWcSPlDaRreM = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		ODnaR0N8UHv7Twy6jS,MMyF7Sa3Hh0TbOJqEwLlmPnCZ,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = zip(*X7mAoIQJWcSPlDaRreM)
		items = zip(MMyF7Sa3Hh0TbOJqEwLlmPnCZ,ODnaR0N8UHv7Twy6jS,Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
	elif type=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="slider-movies-tvshows"(.*?)<header>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif 'latest' in type:
		JXKAgPztneLxQh = int(type[-1:])
		GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('<header>','<end><start>')
		GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('<div class="sidebar','<end><div class="sidebar')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<start>(.*?)<end>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[JXKAgPztneLxQh]
		if JXKAgPztneLxQh==2: items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="content"(.*?)class="(pagination|sidebar)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0][0]
			if '/collection/' in url:
				items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			elif '/quality/' in url:
				items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items and BN1KdkzCmvshw:
		items = oo9kuULlebNgpY0Om.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if 'serie' in title:
			title = oo9kuULlebNgpY0Om.findall('^(.*?)<.*?serie">(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
			title = title[0][1]
			if title in ehHpxSUAZnVITs4y5XjDKb8zC: continue
			ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
			title = '_MOD_'+title
		GS7Y93B0b8TLxueF = oo9kuULlebNgpY0Om.findall('^(.*?)<',title,oo9kuULlebNgpY0Om.DOTALL)
		if GS7Y93B0b8TLxueF: title = GS7Y93B0b8TLxueF[0]
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if '/tvshows/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,383,M4qkBDatEIf3T)
		elif '/episodes/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,383,M4qkBDatEIf3T)
		elif '/seasons/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,383,M4qkBDatEIf3T)
		elif '/collection/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,381,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,382,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		TkWCVDgvzrP0L6FfIuxond1 = cSLKDEATk7y10ovtGZCwF[0][0]
		Y49igVLjponhuwamZH7FXQJKrER2 = cSLKDEATk7y10ovtGZCwF[0][1]
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0][2]
		items = oo9kuULlebNgpY0Om.findall("href='(.*?)'.*?>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title==G9G0YqivIfmUWO8K or title==Y49igVLjponhuwamZH7FXQJKrER2: continue
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,381,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('/page/'+title+'/','/page/'+Y49igVLjponhuwamZH7FXQJKrER2+'/')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'اخر صفحة '+Y49igVLjponhuwamZH7FXQJKrER2,Y6YdkAMluFbwx,381,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,type)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'MOVS4U-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('class="C rated".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd,False):
		Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+'المسلسل للكبار والمبرمج منعه',G9G0YqivIfmUWO8K,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('''class='item'><a href="(.*?)"''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if XXzvmn7ewM8yBfoxua:
			XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[1]
			EL0QAd56tj7Db9eFSw3UZofIsra8(XXzvmn7ewM8yBfoxua)
			return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''class='episodios'(.*?)id="cast"''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for M4qkBDatEIf3T,RnV3EqPNpXTDuI7,Y6YdkAMluFbwx,name in items:
			title = RnV3EqPNpXTDuI7+' : '+name+' الحلقة'
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,382)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'MOVS4U-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('class="C rated".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	ODnaR0N8UHv7Twy6jS = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0][0]
		items = oo9kuULlebNgpY0Om.findall("data-url='(.*?)'.*?class='server'>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="remodal"(.*?)class="remodal-close"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/?s='+search
	UUhwKBgI2nt(url,'search')
	return
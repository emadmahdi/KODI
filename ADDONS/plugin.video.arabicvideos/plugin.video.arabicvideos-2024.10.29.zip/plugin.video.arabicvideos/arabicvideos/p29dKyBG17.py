# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'ELIFVIDEO'
TdtCLWYSJNK8zOb = '_ELV_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = ''
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==1060: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==1061: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==1062: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==1063: tRojAyBgfDH37eLCwP4dWl = fNn6k23ORzwyBe14EbYSvZXxoAM(url,text)
	elif mode==1064: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==1069: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,1069,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''["']navslide-wrap["'](.*?)</ul>''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1064)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('/category.php">(.*?)"navslide-divider"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('''["']dropdown-menu["'](.*?)</ul>''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for duYhmVFABjltoJ9PcE in cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = BN1KdkzCmvshw.replace(duYhmVFABjltoJ9PcE,G9G0YqivIfmUWO8K)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if not title: continue
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1064)
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	VVevamF18rQNYhIp5MSZos,qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = [],[]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp and '.php' in str(kyoQ0h8lGBOW13cNvRqjDp):
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"presentation"','</ul>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [(G9G0YqivIfmUWO8K,BN1KdkzCmvshw)]
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' فرز أو فلتر أو ترتيب '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for mX8PGEof4iCvtnYeT,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			VVevamF18rQNYhIp5MSZos = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if mX8PGEof4iCvtnYeT: mX8PGEof4iCvtnYeT = mX8PGEof4iCvtnYeT+': '
			for Y6YdkAMluFbwx,title in VVevamF18rQNYhIp5MSZos:
				title = mX8PGEof4iCvtnYeT+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1061)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"pm-category-subcats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if 1 or len(qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv)<30:
			if VVevamF18rQNYhIp5MSZos: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1061)
	if not VVevamF18rQNYhIp5MSZos and not msFSK7j9MrcoPafDnkNO: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	if A0AzrLupg8h1s=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = headers.copy()
		AAFEPhnMlsH5B3z0gYQWD4j7kUc['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-TITLES-1st')
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-TITLES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	BN1KdkzCmvshw,items = G9G0YqivIfmUWO8K,[]
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	if A0AzrLupg8h1s=='ajax-search':
		BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	elif A0AzrLupg8h1s=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pm-carousel_featured"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_episodes':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if len(cSLKDEATk7y10ovtGZCwF)>1: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
	elif A0AzrLupg8h1s=='featured_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pm-grid"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if BN1KdkzCmvshw and not items: items = oo9kuULlebNgpY0Om.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: return
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
		M4qkBDatEIf3T += '|Referer='+ffVP3AK5RqhkgYnjZoNis
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('./')
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1062,M4qkBDatEIf3T)
		elif A0AzrLupg8h1s=='new_episodes':
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1062,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1063,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1063,M4qkBDatEIf3T)
	if 1:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('./')
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,1061)
	return
def fNn6k23ORzwyBe14EbYSvZXxoAM(url,JlwhosfkrT):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Vy1U0koJLPFhxe2TS = oo9kuULlebNgpY0Om.findall('"image" content="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	M4qkBDatEIf3T = Vy1U0koJLPFhxe2TS[0] if Vy1U0koJLPFhxe2TS else G9G0YqivIfmUWO8K
	M4qkBDatEIf3T += '|Referer='+ffVP3AK5RqhkgYnjZoNis
	items = []
	nfs7kxySvpQHP = False
	if kyoQ0h8lGBOW13cNvRqjDp and not JlwhosfkrT:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for JlwhosfkrT,title in items:
			JlwhosfkrT = JlwhosfkrT.strip('#')
			if len(items)>1: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,1063,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,JlwhosfkrT)
			else: nfs7kxySvpQHP = True
	else: nfs7kxySvpQHP = True
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('id="'+JlwhosfkrT+'"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not msFSK7j9MrcoPafDnkNO:
		msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('SeasonsEpisodesMain(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if msFSK7j9MrcoPafDnkNO:
			BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('./')
				title = title.replace('</em><span>',ww0sZkBU9JKd)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1062,M4qkBDatEIf3T)
	elif msFSK7j9MrcoPafDnkNO and nfs7kxySvpQHP:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
			vNVBJ0PYWhmua6k1pxb5EiT8gL,NJShD5w1tylRBsHXAV7K2OG = zip(*qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv)
			GgYWjOUA7MtakPulEc0dQC4 = [M4qkBDatEIf3T]*len(qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv)
			items = zip(NJShD5w1tylRBsHXAV7K2OG,vNVBJ0PYWhmua6k1pxb5EiT8gL,GgYWjOUA7MtakPulEc0dQC4)
		if not items: items = oo9kuULlebNgpY0Om.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
			M4qkBDatEIf3T += '|Referer='+ffVP3AK5RqhkgYnjZoNis
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('./')
			title = title.replace('</em><span>',ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,1062,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('"xtgo" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
		sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
		headers = {'User-Agent':uCUkPIYFszbV90wSpKqWNOjZ1687Eh(),'Referer':sg0IMYl698kyvmfVASQU4K13Z2L}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELIFVIDEO-PLAY-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"embeding"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('embed="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?keywords='+search
	UUhwKBgI2nt(url,'search')
	return
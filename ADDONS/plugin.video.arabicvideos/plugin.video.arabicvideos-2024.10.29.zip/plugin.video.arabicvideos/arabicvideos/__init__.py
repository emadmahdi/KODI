# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from pPyIeTklaY import *
s5slfAmHkUtMR3WSKY1ZTX = DTF3Lwy9etRH8mI(u"࠭ࡉࡏࡋࡗࠫᇶ")
RCaBDoeZbFhuqH6jYm2QXUK = qTVF3icWwGXy5(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠧᇷ")
C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
kFehKHZGBD7RvSYp = int(bmP3CnZr75H984yd1k2Ng0EYLA)
G6XbgFWwaiq = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(FWqeEzO1i8Dn0ga(u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩᇸ"))
G6XbgFWwaiq = G6XbgFWwaiq.replace(Leu8GC4bRxh6How7I5U,G9G0YqivIfmUWO8K).replace(wLgGlRoMI589yT6j1rvbW,G9G0YqivIfmUWO8K)
if kFehKHZGBD7RvSYp==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠶࠻࠶ሞ"): MKhg763qCeyTu2k9bFDZ18Yxj = iAGgjwb7tVMmacRJ(u"ࠩࠣࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪᇹ")+GBx0Fcf7sLbqlntEX3yMezu+FWqeEzO1i8Dn0ga(u"ࠪࠤࡢࠦࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪᇺ")+RM76u41Dy82UmfTqvEwhZ+qTVF3icWwGXy5(u"ࠫࠥࡣࠧᇻ")
else:
	DDfvrZhgV2j9GbWTH5MJK = aKAyEnjxIlzZtCTv(ccW1tVjJvUx5efKbPHu6yAMLqaF).replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,G9G0YqivIfmUWO8K).replace(ipjCIhwEXsbadR,G9G0YqivIfmUWO8K)
	DDfvrZhgV2j9GbWTH5MJK = DDfvrZhgV2j9GbWTH5MJK.replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
	DDfvrZhgV2j9GbWTH5MJK = DDfvrZhgV2j9GbWTH5MJK.replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	MKhg763qCeyTu2k9bFDZ18Yxj = dC3PsQJ0Ti28uYlov(u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫᇼ")+G6XbgFWwaiq+VHrIziKUDuNGXkMla(u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᇽ")+bmP3CnZr75H984yd1k2Ng0EYLA+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧᇾ")+DDfvrZhgV2j9GbWTH5MJK+yiaeCEwJjOcWA4ZSd5h(u"ࠨࠢࡠࠫᇿ")
vvqQRbuChP(oz95q0dcEtSuxIJgP841M,RCaBDoeZbFhuqH6jYm2QXUK+zEgtT9cR6bFp7JXqI5VuhNeP+ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+MKhg763qCeyTu2k9bFDZ18Yxj)
if cjbAkCIinvs(u"ࠩࡢࠫሀ") in CW2cwYfL9s: t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09 = CW2cwYfL9s.split(cJSNFCIhymEfx6grGu0M(u"ࠪࡣࠬሁ"),t2sCrJ0xbgDRkf(u"࠶ሟ"))
else: t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09 = CW2cwYfL9s,G9G0YqivIfmUWO8K
UWfvC06tXBdKkDeGlzgsrbF92J8Rm5,fEKoHajMCOh = kkMuQrLWcEayRm,G9G0YqivIfmUWO8K
if t1w4Q95EfFKLMujJSbIRNZ in [FWqeEzO1i8Dn0ga(u"ࠫ࠶࠭ሂ"),t2sCrJ0xbgDRkf(u"ࠬ࠸ࠧሃ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭࠳ࠨሄ"),rxWDdRBIct57i90s(u"ࠧ࠵ࠩህ"),iAGgjwb7tVMmacRJ(u"ࠨ࠷ࠪሆ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࠴࠵ࠬሇ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࠵࠷࠭ለ"),rxWDdRBIct57i90s(u"ࠫ࠶࠹ࠧሉ")] and (jR9YtmsgDX8nTQlMb6G3(u"ࠬࡇࡄࡅࠩሊ") in uIfFCQDdrm3wjoaO2ZVpYy09 or CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡒࡆࡏࡒ࡚ࡊ࠭ላ") in uIfFCQDdrm3wjoaO2ZVpYy09 or iAGgjwb7tVMmacRJ(u"ࠧࡖࡒࠪሌ") in uIfFCQDdrm3wjoaO2ZVpYy09 or qTVF3icWwGXy5(u"ࠨࡆࡒ࡛ࡓ࠭ል") in uIfFCQDdrm3wjoaO2ZVpYy09):
	from z9P53JUjpg import hKY8iAO7a62IpoM
	hKY8iAO7a62IpoM(CW2cwYfL9s,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09)
	amx9qJHkhw7oLdtVMG3.setSetting(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ሎ"),ccW1tVjJvUx5efKbPHu6yAMLqaF)
	UWfvC06tXBdKkDeGlzgsrbF92J8Rm5 = P5VqbRSzjtO4UE1rZaolG67XA
elif not jlFg5ptfLPEYns7mkOuyZG4z0WaqK and kFehKHZGBD7RvSYp in [qTVF3icWwGXy5(u"࠸࠳࠶ሠ"),EHUAyW2lQfe4LXmhgIGc(u"࠷࠲࠷ሡ")]:
	Gzo1nsVM84m6abfISDup9xjQdBO = str(zF4nhxYlaiKPwA6NJZ3[jR9YtmsgDX8nTQlMb6G3(u"ࠪࡪࡴࡲࡤࡦࡴࠪሏ")])
	s5slfAmHkUtMR3WSKY1ZTX = rr7Xolsp4JwjPK3L(u"ࠫࡎࡖࡔࡗࠩሐ") if kFehKHZGBD7RvSYp==rr7Xolsp4JwjPK3L(u"࠳࠵࠸ሢ") else bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡓ࠳ࡖࠩሑ")
	h5zDTda4t78wyuCH1EUZRFo = s5slfAmHkUtMR3WSKY1ZTX.lower()
	TkUSmDLJYy = amx9qJHkhw7oLdtVMG3.getSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡡࡷ࠰ࠪሒ")+h5zDTda4t78wyuCH1EUZRFo+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬሓ")+Gzo1nsVM84m6abfISDup9xjQdBO)
	pM0RwoYjfsUVZcqt6uTOiFkhEXCS = amx9qJHkhw7oLdtVMG3.getSetting(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡣࡹ࠲ࠬሔ")+h5zDTda4t78wyuCH1EUZRFo+iAGgjwb7tVMmacRJ(u"ࠩ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬሕ")+Gzo1nsVM84m6abfISDup9xjQdBO)
	if TkUSmDLJYy or pM0RwoYjfsUVZcqt6uTOiFkhEXCS:
		yzieWRVX4nkB3DjGHJphEdQo += UighHKAfySm4PWErqJ(u"ࠪࢀࠬሖ")
		if TkUSmDLJYy: yzieWRVX4nkB3DjGHJphEdQo += dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪሗ")+TkUSmDLJYy
		if pM0RwoYjfsUVZcqt6uTOiFkhEXCS: yzieWRVX4nkB3DjGHJphEdQo += hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨመ")+pM0RwoYjfsUVZcqt6uTOiFkhEXCS
		yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo.replace(EHUAyW2lQfe4LXmhgIGc(u"࠭ࡼࠧࠩሙ"),UighHKAfySm4PWErqJ(u"ࠧࡽࠩሚ"))
	fJIuTHnBCpESUjRm2Qg7tZdzOlY1 = amx9qJHkhw7oLdtVMG3.getSetting(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡣࡹ࠲ࠬማ")+h5zDTda4t78wyuCH1EUZRFo+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࠱ࡷࡪࡸࡶࡦࡴࡢࠫሜ")+Gzo1nsVM84m6abfISDup9xjQdBO)
	if fJIuTHnBCpESUjRm2Qg7tZdzOlY1:
		GIr6Ap72Heb9xT1C4MqjtP0Ufs3 = oo9kuULlebNgpY0Om.findall(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭ም"),yzieWRVX4nkB3DjGHJphEdQo,oo9kuULlebNgpY0Om.DOTALL)
		yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo.replace(GIr6Ap72Heb9xT1C4MqjtP0Ufs3[dQ5JhEYolPmy1fvHktMw6NFRxiz],fJIuTHnBCpESUjRm2Qg7tZdzOlY1)
	Imphr8LRTUDs(yzieWRVX4nkB3DjGHJphEdQo,s5slfAmHkUtMR3WSKY1ZTX,C9uTVdSkLlb5UemavyB6NjWHFh)
else:
	import a1aDsx9ioY
	try: a1aDsx9ioY.wcJnx5TaLO1bMg83y(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3,kFehKHZGBD7RvSYp,t1w4Q95EfFKLMujJSbIRNZ,uIfFCQDdrm3wjoaO2ZVpYy09,G6XbgFWwaiq)
	except Exception as pNmWTskohjIPSt7fQl: fEKoHajMCOh = ISZeOrqTo0wGmLK3fEjHaD2n.format_exc()
	UWfvC06tXBdKkDeGlzgsrbF92J8Rm5 = a1aDsx9ioY.UWfvC06tXBdKkDeGlzgsrbF92J8Rm5
jBzmSE2F7uCKJ4pw5QxT9Df8W(UWfvC06tXBdKkDeGlzgsrbF92J8Rm5,fEKoHajMCOh)
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SHIAVOICE'
TdtCLWYSJNK8zOb = '_SHV_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
headers = {'User-Agent':None}
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==310: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==311: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==312: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==313: tRojAyBgfDH37eLCwP4dWl = VltKjUB9oEarNLApeRqYuvSd2I(url)
	elif mode==314: tRojAyBgfDH37eLCwP4dWl = HDY16Cs8Q2qxREhZ3Iw(text)
	elif mode==319: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,319,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('id="menulinks"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	items = oo9kuULlebNgpY0Om.findall('<h5>(.*?)</h5>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
	for JXKAgPztneLxQh in range(len(items)):
		title = items[JXKAgPztneLxQh].strip(ww0sZkBU9JKd)
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,ffVP3AK5RqhkgYnjZoNis,314,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,str(JXKAgPztneLxQh+1))
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مقاطع شهر',ffVP3AK5RqhkgYnjZoNis,314,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'0')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<B>(.*?)</B>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,311)
	return GagwMT6q3oc7UZ2Q
def HDY16Cs8Q2qxREhZ3Iw(JXKAgPztneLxQh):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-LATEST-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if JXKAgPztneLxQh=='0':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="tab-content"(.*?)</table>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title.strip(ww0sZkBU9JKd)
			name = name.strip(ww0sZkBU9JKd)
			title = title+' ('+name+')'
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312)
	elif JXKAgPztneLxQh in ['1','2','3']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(<h5>.*?)<div class="col-lg',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		Mocr0bV9zF4KeQSNHEU2whOn = int(JXKAgPztneLxQh)-1
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[Mocr0bV9zF4KeQSNHEU2whOn]
		if JXKAgPztneLxQh=='1': items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		else: items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title,name in items:
			M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title.strip(ww0sZkBU9JKd)
			name = name.strip(ww0sZkBU9JKd)
			title = title+' ('+name+')'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,311,M4qkBDatEIf3T)
	elif JXKAgPztneLxQh in ['4','5','6']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(<h5>.*?)</table>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		JXKAgPztneLxQh = int(JXKAgPztneLxQh)-4
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[JXKAgPztneLxQh]
		items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for M4qkBDatEIf3T,Y6YdkAMluFbwx,qsQBKShZJyOFX3zCT2kdfoI,title,mpniyIdLxTPW3BN8UcY2v in items:
			M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title.strip(ww0sZkBU9JKd)
			qsQBKShZJyOFX3zCT2kdfoI = qsQBKShZJyOFX3zCT2kdfoI.strip(ww0sZkBU9JKd)
			mpniyIdLxTPW3BN8UcY2v = mpniyIdLxTPW3BN8UcY2v.strip(ww0sZkBU9JKd)
			if qsQBKShZJyOFX3zCT2kdfoI: name = qsQBKShZJyOFX3zCT2kdfoI
			else: name = mpniyIdLxTPW3BN8UcY2v
			title = title+' ('+name+')'
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312,M4qkBDatEIf3T)
	return
def UUhwKBgI2nt(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('ibox-heading"(.*?)class="float-right',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if 'catsum-mobile' in BN1KdkzCmvshw:
		items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for M4qkBDatEIf3T,Y6YdkAMluFbwx,title,count in items:
				M4qkBDatEIf3T = ffVP3AK5RqhkgYnjZoNis+'/'+M4qkBDatEIf3T
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
				count = count.replace(' الصوتية: ',':')
				title = title.strip(ww0sZkBU9JKd)
				title = title+' ('+count+')'
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,311,M4qkBDatEIf3T)
	else:
		items = oo9kuULlebNgpY0Om.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,JJNZI10tTr4,ii9h6QFxBUuCeqJODlfYmsI7ZT in items:
			if title==G9G0YqivIfmUWO8K or JJNZI10tTr4==G9G0YqivIfmUWO8K: continue
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title+' ('+ii9h6QFxBUuCeqJODlfYmsI7ZT+')'
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312)
	if not items: EL0QAd56tj7Db9eFSw3UZofIsra8(GagwMT6q3oc7UZ2Q)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(GagwMT6q3oc7UZ2Q):
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="ibox-content"(.*?)class="pagination',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title,name,count,ii9h6QFxBUuCeqJODlfYmsI7ZT in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)
		name = name.strip(ww0sZkBU9JKd)
		title = title+' ('+name+')'
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312,G9G0YqivIfmUWO8K,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	return
def VltKjUB9oEarNLApeRqYuvSd2I(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-SEARCH_ITEMS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="ibox-content p-1"(.*?)class="ibox-content"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF:
		UUhwKBgI2nt(url)
		return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<strong>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
		title = title.strip(ww0sZkBU9JKd)
		if '/play-' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,311)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<audio.*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not Y6YdkAMluFbwx: Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<video.*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx[0]
	Imphr8LRTUDs(Y6YdkAMluFbwx,s5slfAmHkUtMR3WSKY1ZTX,'video')
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	Dzdfq3OnAo4Hcvj = ['&t=a','&t=c','&t=s']
	if showDialogs:
		oxdHAFuqYB0GPJLVIbZh = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('موقع صوت الشيعة - أختر البحث', oxdHAFuqYB0GPJLVIbZh)
		if PXeEIRkdShOGm45lbLJc2B38s == -1: return
	elif '_SHIAVOICE-PERSONS_' in EIcQfuLpMO2jX: PXeEIRkdShOGm45lbLJc2B38s = 0
	elif '_SHIAVOICE-ALBUMS_' in EIcQfuLpMO2jX: PXeEIRkdShOGm45lbLJc2B38s = 1
	elif '_SHIAVOICE-AUDIOS_' in EIcQfuLpMO2jX: PXeEIRkdShOGm45lbLJc2B38s = 2
	else: return
	type = Dzdfq3OnAo4Hcvj[PXeEIRkdShOGm45lbLJc2B38s]
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?q='+search+type
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHIAVOICE-SEARCH-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="ibox-content"(.*?)class="ibox-content"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		if PXeEIRkdShOGm45lbLJc2B38s in [0,1]:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title,name in items:
				title = title.strip(ww0sZkBU9JKd)
				name = name.strip(ww0sZkBU9JKd)
				title = title+' ('+name+')'
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,313,M4qkBDatEIf3T)
		elif PXeEIRkdShOGm45lbLJc2B38s==2:
			items = oo9kuULlebNgpY0Om.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title,name in items:
				title = title.strip(ww0sZkBU9JKd)
				name = name.strip(ww0sZkBU9JKd)
				title = title+' ('+name+')'
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,312)
	return
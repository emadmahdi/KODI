# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'IFILM'
TdtCLWYSJNK8zOb = '_IFL_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
cEz6aWRhkf1KS = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][1]
JJ6hGQx95F = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][2]
CfXgxAi5U9w2njJ8E0a = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][3]
def RAndFk3y4Pbvs29(mode,url,eehFlSEjHioyAWpLqZXt79,text):
	if   mode==20: tRojAyBgfDH37eLCwP4dWl = JLbf2mGSvw9D4()
	elif mode==21: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74(url)
	elif mode==22: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==23: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==24: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url,text)
	elif mode==25: tRojAyBgfDH37eLCwP4dWl = VUQjOAu3fNpo(url)
	elif mode==27: tRojAyBgfDH37eLCwP4dWl = ooMbFZDa6xRHXp(url)
	elif mode==28: tRojAyBgfDH37eLCwP4dWl = vKbI5BlYyPQ8ua()
	elif mode==29: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def JLbf2mGSvw9D4():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'عربي',ffVP3AK5RqhkgYnjZoNis,21,G9G0YqivIfmUWO8K,'101')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'English',cEz6aWRhkf1KS,21,G9G0YqivIfmUWO8K,'101')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فارسى',JJ6hGQx95F,21,G9G0YqivIfmUWO8K,'101')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فارسى 2',CfXgxAi5U9w2njJ8E0a,21,G9G0YqivIfmUWO8K,'101')
	return
def vKbI5BlYyPQ8ua():
	Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'عربي',ffVP3AK5RqhkgYnjZoNis,27)
	Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'English',cEz6aWRhkf1KS,27)
	Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'فارسى',JJ6hGQx95F,27)
	Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+'فارسى 2',CfXgxAi5U9w2njJ8E0a,27)
	return
def hXz0OvlBbVLste3xWE6C74(lYnsVoaFUHjmECBqcTS2AQrh):
	s5slfAmHkUtMR3WSKY1ZTX = lYnsVoaFUHjmECBqcTS2AQrh
	if lYnsVoaFUHjmECBqcTS2AQrh=='IFILM-ARABIC': lYnsVoaFUHjmECBqcTS2AQrh = ffVP3AK5RqhkgYnjZoNis
	elif lYnsVoaFUHjmECBqcTS2AQrh=='IFILM-ENGLISH': lYnsVoaFUHjmECBqcTS2AQrh = cEz6aWRhkf1KS
	else: s5slfAmHkUtMR3WSKY1ZTX = G9G0YqivIfmUWO8K
	BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(lYnsVoaFUHjmECBqcTS2AQrh)
	if BSAJjHXKpCaq9Y04ym1frVb8iv=='ar' or s5slfAmHkUtMR3WSKY1ZTX=='IFILM-ARABIC':
		MJOk4n7LygWb3pvo = 'بحث في الموقع'
		qsQBKShZJyOFX3zCT2kdfoI = 'مسلسلات - حالية'
		mpniyIdLxTPW3BN8UcY2v = 'مسلسلات - أحدث'
		IJeNd3DL4Tb5h2m9i8p = 'مسلسلات - أبجدي'
		tNhpB8Tb3a0vVP4ZQdG = 'بث حي آي فيلم'
		xACyPs5UKO = 'أفلام'
		QZkhLBPdY7Mc60 = 'موسيقى'
		oYL7kBK9j8JT3iF = 'برامج'
	elif BSAJjHXKpCaq9Y04ym1frVb8iv=='en' or s5slfAmHkUtMR3WSKY1ZTX=='IFILM-ENGLISH':
		MJOk4n7LygWb3pvo = 'Search in site'
		qsQBKShZJyOFX3zCT2kdfoI = 'Series - Current'
		mpniyIdLxTPW3BN8UcY2v = 'Series - Latest'
		IJeNd3DL4Tb5h2m9i8p = 'Series - Alphabet'
		tNhpB8Tb3a0vVP4ZQdG = 'Live iFilm channel'
		xACyPs5UKO = 'Movies'
		QZkhLBPdY7Mc60 = 'Music'
		oYL7kBK9j8JT3iF = 'Shows'
	elif BSAJjHXKpCaq9Y04ym1frVb8iv in ['fa','fa2']:
		MJOk4n7LygWb3pvo = 'جستجو در سایت'
		qsQBKShZJyOFX3zCT2kdfoI = 'سريال - جاری'
		mpniyIdLxTPW3BN8UcY2v = 'سريال - آخرین'
		IJeNd3DL4Tb5h2m9i8p = 'سريال - الفبا'
		tNhpB8Tb3a0vVP4ZQdG = 'پخش زنده اي فيلم'
		xACyPs5UKO = 'فيلم'
		QZkhLBPdY7Mc60 = 'موسيقى'
		oYL7kBK9j8JT3iF = 'برنامه ها'
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+MJOk4n7LygWb3pvo,lYnsVoaFUHjmECBqcTS2AQrh,29,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('live',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+tNhpB8Tb3a0vVP4ZQdG,lYnsVoaFUHjmECBqcTS2AQrh,27)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	hifDqHbzE39x5Jja7wsd8OeTvotYIB = ['Series','Program','Music']
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,lYnsVoaFUHjmECBqcTS2AQrh+'/home',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-MENU-1st')
	cSLKDEATk7y10ovtGZCwF=oo9kuULlebNgpY0Om.findall('button-menu(.*?)/Contact',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if any(yW70dtahIjkPCJg2TA in Y6YdkAMluFbwx for yW70dtahIjkPCJg2TA in hifDqHbzE39x5Jja7wsd8OeTvotYIB):
				url = lYnsVoaFUHjmECBqcTS2AQrh+Y6YdkAMluFbwx
				if 'Series' in Y6YdkAMluFbwx:
					Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,url,22,G9G0YqivIfmUWO8K,'100')
					Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+mpniyIdLxTPW3BN8UcY2v,url,22,G9G0YqivIfmUWO8K,'101')
					Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+IJeNd3DL4Tb5h2m9i8p,url,22,G9G0YqivIfmUWO8K,'201')
				elif 'Film' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+xACyPs5UKO,url,22,G9G0YqivIfmUWO8K,'100')
				elif 'Music' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+QZkhLBPdY7Mc60,url,25,G9G0YqivIfmUWO8K,'101')
				elif 'Program' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+oYL7kBK9j8JT3iF,url,22,G9G0YqivIfmUWO8K,'101')
	return GagwMT6q3oc7UZ2Q
def VUQjOAu3fNpo(url):
	lYnsVoaFUHjmECBqcTS2AQrh = VV01woDxLB(url)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-MUSIC_MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('Music-tools-header(.*?)Music-body',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	title = oo9kuULlebNgpY0Om.findall('<p>(.*?)</p>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)[0]
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,22,G9G0YqivIfmUWO8K,'101')
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Y6YdkAMluFbwx = lYnsVoaFUHjmECBqcTS2AQrh + Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,23,G9G0YqivIfmUWO8K,'101')
	return
def UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79):
	lYnsVoaFUHjmECBqcTS2AQrh = VV01woDxLB(url)
	BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(url)
	type = url.split('/')[-1]
	lUIPwvoBGqV2f9Yujh7SmQyD1HETsA = str(int(eehFlSEjHioyAWpLqZXt79)//100)
	eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)%100)
	if type=='Series' and eehFlSEjHioyAWpLqZXt79=='0':
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-TITLES-1st')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('serial-body(.*?)class="row',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Y6YdkAMluFbwx = lYnsVoaFUHjmECBqcTS2AQrh + Y6YdkAMluFbwx
			M4qkBDatEIf3T = lYnsVoaFUHjmECBqcTS2AQrh + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,23,M4qkBDatEIf3T,lUIPwvoBGqV2f9Yujh7SmQyD1HETsA+'01')
	ErFhfeKQIkOMSYUms35vbqTD0x8=0
	if type=='Series': nxguK9laUWBGHIR4zEsTo7='3'
	if type=='Film': nxguK9laUWBGHIR4zEsTo7='5'
	if type=='Program': nxguK9laUWBGHIR4zEsTo7='7'
	if type in ['Series','Program','Film'] and eehFlSEjHioyAWpLqZXt79!='0':
		XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Home/PageingItem?category='+nxguK9laUWBGHIR4zEsTo7+'&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&orderby='+lUIPwvoBGqV2f9Yujh7SmQyD1HETsA
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-TITLES-2nd')
		items = oo9kuULlebNgpY0Om.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for id,title,M4qkBDatEIf3T in items:
			title = zDBtm4MwIagkfcpE5oxJOAq6lZQY(title)
			title = title.replace('\\',G9G0YqivIfmUWO8K)
			title = title.replace('"',G9G0YqivIfmUWO8K)
			ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
			Y6YdkAMluFbwx = lYnsVoaFUHjmECBqcTS2AQrh + '/' + type + '/Content/' + id
			M4qkBDatEIf3T = lYnsVoaFUHjmECBqcTS2AQrh + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
			if type=='Film': Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,24,M4qkBDatEIf3T,lUIPwvoBGqV2f9Yujh7SmQyD1HETsA+'01')
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,23,M4qkBDatEIf3T,lUIPwvoBGqV2f9Yujh7SmQyD1HETsA+'01')
	if type=='Music':
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,lYnsVoaFUHjmECBqcTS2AQrh+'/Music/Index?page='+eehFlSEjHioyAWpLqZXt79,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-TITLES-3rd')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pagination-demo(.*?)pagination-demo',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
			M4qkBDatEIf3T = lYnsVoaFUHjmECBqcTS2AQrh + M4qkBDatEIf3T
			Y6YdkAMluFbwx = lYnsVoaFUHjmECBqcTS2AQrh + Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,23,M4qkBDatEIf3T,'101')
	if ErFhfeKQIkOMSYUms35vbqTD0x8>20:
		title='صفحة '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='en': title = 'Page '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': title = 'صفحه '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': title = 'صفحه '
		for j43xMTeoZfOUEKJ in range(1,11) :
			if not eehFlSEjHioyAWpLqZXt79==str(j43xMTeoZfOUEKJ):
				snoI4uUR8bgawviTXySl2dP1c = '0'+str(j43xMTeoZfOUEKJ)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title+str(j43xMTeoZfOUEKJ),url,22,G9G0YqivIfmUWO8K,lUIPwvoBGqV2f9Yujh7SmQyD1HETsA+snoI4uUR8bgawviTXySl2dP1c[-2:])
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url,eehFlSEjHioyAWpLqZXt79):
	if not eehFlSEjHioyAWpLqZXt79: eehFlSEjHioyAWpLqZXt79 = 0
	lYnsVoaFUHjmECBqcTS2AQrh = VV01woDxLB(url)
	mUcijqvHal8pfEYhIoXSWdL6nx = VV01woDxLB(url)
	BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(url)
	mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('/')
	id,type = mtMexSFLnkwhbAaP9pgDduCRBi2[-1],mtMexSFLnkwhbAaP9pgDduCRBi2[3]
	lUIPwvoBGqV2f9Yujh7SmQyD1HETsA = str(int(eehFlSEjHioyAWpLqZXt79)//100)
	eehFlSEjHioyAWpLqZXt79 = str(int(eehFlSEjHioyAWpLqZXt79)%100)
	ErFhfeKQIkOMSYUms35vbqTD0x8 = 0
	if type=='Series':
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-1st')
		items = oo9kuULlebNgpY0Om.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		title = ' - الحلقة '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='en': title = ' - Episode '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': title = ' - قسمت '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': title = ' - قسمت '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': kBoG4iYsqJ18ZUd = G9G0YqivIfmUWO8K
		else: kBoG4iYsqJ18ZUd = BSAJjHXKpCaq9Y04ym1frVb8iv
		HiLItYV9W3uUM = oo9kuULlebNgpY0Om.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for name,count,M4qkBDatEIf3T,Y6YdkAMluFbwx in items:
			for RnV3EqPNpXTDuI7 in range(int(count),0,-1):
				Bxclm1vWUdIpg6i = M4qkBDatEIf3T + kBoG4iYsqJ18ZUd + id + '/' + str(RnV3EqPNpXTDuI7) + '.png'
				qsQBKShZJyOFX3zCT2kdfoI = name + title + str(RnV3EqPNpXTDuI7)
				qsQBKShZJyOFX3zCT2kdfoI = kD2wGe8Oh4T7Cj3BMsy0(qsQBKShZJyOFX3zCT2kdfoI)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,url,24,Bxclm1vWUdIpg6i,G9G0YqivIfmUWO8K,str(RnV3EqPNpXTDuI7))
	elif type=='Program':
		XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&orderby=1'
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-2nd')
		items = oo9kuULlebNgpY0Om.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		title = ' - الحلقة '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='en': title = ' - Episode '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': title = ' - قسمت '
		if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': title = ' - قسمت '
		for RnV3EqPNpXTDuI7,M4qkBDatEIf3T,Y6YdkAMluFbwx,PbpIOTARHiQCkSJreWhFKyGju0w2,name in items:
			ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
			Bxclm1vWUdIpg6i = mUcijqvHal8pfEYhIoXSWdL6nx + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
			name = zDBtm4MwIagkfcpE5oxJOAq6lZQY(name)
			qsQBKShZJyOFX3zCT2kdfoI = name + title + str(RnV3EqPNpXTDuI7)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,XXzvmn7ewM8yBfoxua,24,Bxclm1vWUdIpg6i,G9G0YqivIfmUWO8K,str(ErFhfeKQIkOMSYUms35vbqTD0x8))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Music/GetTracksBy?id='+str(id)+'&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&type=0'
			GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-3rd')
			items = oo9kuULlebNgpY0Om.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			for M4qkBDatEIf3T,Y6YdkAMluFbwx,name,title in items:
				ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
				Bxclm1vWUdIpg6i = mUcijqvHal8pfEYhIoXSWdL6nx + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
				qsQBKShZJyOFX3zCT2kdfoI = name + ' - ' + title
				qsQBKShZJyOFX3zCT2kdfoI = qsQBKShZJyOFX3zCT2kdfoI.strip(ww0sZkBU9JKd)
				qsQBKShZJyOFX3zCT2kdfoI = zDBtm4MwIagkfcpE5oxJOAq6lZQY(qsQBKShZJyOFX3zCT2kdfoI)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,XXzvmn7ewM8yBfoxua,24,Bxclm1vWUdIpg6i,G9G0YqivIfmUWO8K,str(ErFhfeKQIkOMSYUms35vbqTD0x8))
		elif 'Clips' in url:
			XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Music/GetTracksBy?id=0&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&type=15'
			GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-4th')
			items = oo9kuULlebNgpY0Om.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			for M4qkBDatEIf3T,title,Y6YdkAMluFbwx in items:
				ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
				Bxclm1vWUdIpg6i = mUcijqvHal8pfEYhIoXSWdL6nx + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
				qsQBKShZJyOFX3zCT2kdfoI = title.strip(ww0sZkBU9JKd)
				qsQBKShZJyOFX3zCT2kdfoI = zDBtm4MwIagkfcpE5oxJOAq6lZQY(qsQBKShZJyOFX3zCT2kdfoI)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,XXzvmn7ewM8yBfoxua,24,Bxclm1vWUdIpg6i,G9G0YqivIfmUWO8K,str(ErFhfeKQIkOMSYUms35vbqTD0x8))
		elif 'category' in url:
			if 'category=6' in url:
				XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Music/GetTracksBy?id=0&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&type=6'
				GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				XXzvmn7ewM8yBfoxua = lYnsVoaFUHjmECBqcTS2AQrh+'/Music/GetTracksBy?id=0&page='+eehFlSEjHioyAWpLqZXt79+'&size=30&type=4'
				GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-EPISODES-6th')
			items = oo9kuULlebNgpY0Om.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			for M4qkBDatEIf3T,Y6YdkAMluFbwx,name,title in items:
				ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
				Bxclm1vWUdIpg6i = mUcijqvHal8pfEYhIoXSWdL6nx + SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
				qsQBKShZJyOFX3zCT2kdfoI = name + ' - ' + title
				qsQBKShZJyOFX3zCT2kdfoI = qsQBKShZJyOFX3zCT2kdfoI.strip(ww0sZkBU9JKd)
				qsQBKShZJyOFX3zCT2kdfoI = zDBtm4MwIagkfcpE5oxJOAq6lZQY(qsQBKShZJyOFX3zCT2kdfoI)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+qsQBKShZJyOFX3zCT2kdfoI,XXzvmn7ewM8yBfoxua,24,Bxclm1vWUdIpg6i,G9G0YqivIfmUWO8K,str(ErFhfeKQIkOMSYUms35vbqTD0x8))
	if type=='Music' or type=='Program':
		if ErFhfeKQIkOMSYUms35vbqTD0x8>25:
			title='صفحة '
			if BSAJjHXKpCaq9Y04ym1frVb8iv=='en': title = ' Page '
			if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': title = ' صفحه '
			if BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': title = ' صفحه '
			for j43xMTeoZfOUEKJ in range(1,11):
				if not eehFlSEjHioyAWpLqZXt79==str(j43xMTeoZfOUEKJ):
					snoI4uUR8bgawviTXySl2dP1c = '0'+str(j43xMTeoZfOUEKJ)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title+str(j43xMTeoZfOUEKJ),url,23,G9G0YqivIfmUWO8K,lUIPwvoBGqV2f9Yujh7SmQyD1HETsA+snoI4uUR8bgawviTXySl2dP1c[-2:])
	return
def sWujQcGynM9NtJeTfqk3D(url,RnV3EqPNpXTDuI7):
	mUcijqvHal8pfEYhIoXSWdL6nx = VV01woDxLB(url)
	Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = [],[]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-PLAY-1st')
	items = oo9kuULlebNgpY0Om.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(url)
		mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('/')
		id,type = mtMexSFLnkwhbAaP9pgDduCRBi2[-1],mtMexSFLnkwhbAaP9pgDduCRBi2[3]
		Y6YdkAMluFbwx = items[0][0]+BSAJjHXKpCaq9Y04ym1frVb8iv+id+'/,'+RnV3EqPNpXTDuI7+','+RnV3EqPNpXTDuI7+'_'+items[0][2]
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append('m3u8')
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	items = oo9kuULlebNgpY0Om.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(url)
		mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('/')
		id,type = mtMexSFLnkwhbAaP9pgDduCRBi2[-1],mtMexSFLnkwhbAaP9pgDduCRBi2[3]
		Y6YdkAMluFbwx = items[0][0]+BSAJjHXKpCaq9Y04ym1frVb8iv+id+'/'+RnV3EqPNpXTDuI7+items[0][2]
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append('mp4 url')
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	items = oo9kuULlebNgpY0Om.findall('source src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx in items:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('//','/')
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append('mp4 src')
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	items = oo9kuULlebNgpY0Om.findall('VideoAddress":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		Y6YdkAMluFbwx = items[int(RnV3EqPNpXTDuI7)-1]
		Y6YdkAMluFbwx = mUcijqvHal8pfEYhIoXSWdL6nx+SSX6oT0lADZhKRImPvCHFkYJs(Y6YdkAMluFbwx)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append('mp4 address')
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	items = oo9kuULlebNgpY0Om.findall('VoiceAddress":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		Y6YdkAMluFbwx = items[int(RnV3EqPNpXTDuI7)-1]
		Y6YdkAMluFbwx = mUcijqvHal8pfEYhIoXSWdL6nx+SSX6oT0lADZhKRImPvCHFkYJs(Y6YdkAMluFbwx)
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO.append('mp3 address')
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if len(ODnaR0N8UHv7Twy6jS)==1: Y6YdkAMluFbwx = ODnaR0N8UHv7Twy6jS[0]
	else:
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر الفيديو المناسب:', Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
		if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
		Y6YdkAMluFbwx = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	Imphr8LRTUDs(Y6YdkAMluFbwx,s5slfAmHkUtMR3WSKY1ZTX,'video')
	return
def VV01woDxLB(url):
	if ffVP3AK5RqhkgYnjZoNis in url: oob2dzmG3jTMpZwQyIfN = ffVP3AK5RqhkgYnjZoNis
	elif cEz6aWRhkf1KS in url: oob2dzmG3jTMpZwQyIfN = cEz6aWRhkf1KS
	elif JJ6hGQx95F in url: oob2dzmG3jTMpZwQyIfN = JJ6hGQx95F
	elif CfXgxAi5U9w2njJ8E0a in url: oob2dzmG3jTMpZwQyIfN = CfXgxAi5U9w2njJ8E0a
	else: oob2dzmG3jTMpZwQyIfN = G9G0YqivIfmUWO8K
	return oob2dzmG3jTMpZwQyIfN
def j6zZt2mqSwK3g9upJ1TknfA7Ra(url):
	if   ffVP3AK5RqhkgYnjZoNis in url: BSAJjHXKpCaq9Y04ym1frVb8iv = 'ar'
	elif cEz6aWRhkf1KS in url: BSAJjHXKpCaq9Y04ym1frVb8iv = 'en'
	elif JJ6hGQx95F in url: BSAJjHXKpCaq9Y04ym1frVb8iv = 'fa'
	elif CfXgxAi5U9w2njJ8E0a in url: BSAJjHXKpCaq9Y04ym1frVb8iv = 'fa2'
	else: BSAJjHXKpCaq9Y04ym1frVb8iv = G9G0YqivIfmUWO8K
	return BSAJjHXKpCaq9Y04ym1frVb8iv
def ooMbFZDa6xRHXp(url):
	BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(url)
	XXzvmn7ewM8yBfoxua = url + '/Home/Live'
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-LIVE-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = oo9kuULlebNgpY0Om.findall('source src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	XjWHSnbf6NwhMgpKt4yLY7AkIT = items[0]
	Imphr8LRTUDs(XjWHSnbf6NwhMgpKt4yLY7AkIT,s5slfAmHkUtMR3WSKY1ZTX,'live')
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'+')
	if showDialogs:
		WRJB5Aun46mj82z9thxviEdSgk1wX = [ ffVP3AK5RqhkgYnjZoNis , cEz6aWRhkf1KS , JJ6hGQx95F , CfXgxAi5U9w2njJ8E0a ]
		Y4aIzyVXN2j = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر اللغة المناسبة:', Y4aIzyVXN2j)
		if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
		website = WRJB5Aun46mj82z9thxviEdSgk1wX[PXeEIRkdShOGm45lbLJc2B38s]
	else:
		if '_IFILM-ARABIC_' in EIcQfuLpMO2jX: website = ffVP3AK5RqhkgYnjZoNis
		elif '_IFILM-ENGLISH_' in EIcQfuLpMO2jX: website = cEz6aWRhkf1KS
		else: website = G9G0YqivIfmUWO8K
	if not website: return
	BSAJjHXKpCaq9Y04ym1frVb8iv = j6zZt2mqSwK3g9upJ1TknfA7Ra(website)
	XXzvmn7ewM8yBfoxua = website + "/Home/Search?searchstring=" + HG9ZQqnw71y0JmrDLx
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'IFILM-SEARCH-1st')
	items = oo9kuULlebNgpY0Om.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		for M4qkBDatEIf3T,nxguK9laUWBGHIR4zEsTo7,id,title in items:
			if nxguK9laUWBGHIR4zEsTo7 in ['3','7']:
				title = title.replace('\\',G9G0YqivIfmUWO8K)
				title = title.replace('"',G9G0YqivIfmUWO8K)
				if nxguK9laUWBGHIR4zEsTo7=='3':
					type = 'Series'
					if BSAJjHXKpCaq9Y04ym1frVb8iv=='ar': name = 'مسلسل : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='en': name = 'Series : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': name = 'سريال ها : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': name = 'سريال ها : '
				elif nxguK9laUWBGHIR4zEsTo7=='5':
					type = 'Film'
					if BSAJjHXKpCaq9Y04ym1frVb8iv=='ar': name = 'فيلم : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='en': name = 'Movie : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': name = 'فيلم : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': name = 'فلم ها : '
				elif nxguK9laUWBGHIR4zEsTo7=='7':
					type = 'Program'
					if BSAJjHXKpCaq9Y04ym1frVb8iv=='ar': name = 'برنامج : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='en': name = 'Program : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa': name = 'برنامه ها : '
					elif BSAJjHXKpCaq9Y04ym1frVb8iv=='fa2': name = 'برنامه ها : '
				title = name + title
				Y6YdkAMluFbwx = website + '/' + type + '/Content/' + id
				M4qkBDatEIf3T = SSX6oT0lADZhKRImPvCHFkYJs(M4qkBDatEIf3T)
				M4qkBDatEIf3T = website+M4qkBDatEIf3T
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,23,M4qkBDatEIf3T,'101')
	return
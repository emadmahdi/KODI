# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢡ")
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,Qjnkp0KgXq2Ty):
	if   Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠹࠳࠱श"): tRojAyBgfDH37eLCwP4dWl = VVYs1Emw3i()
	elif Mauf6CrJjP87s==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠳࠴࠳ष"): tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(Qjnkp0KgXq2Ty)
	elif Mauf6CrJjP87s==vCmnFshSi4flecXIY2gy38G0DJw(u"࠴࠵࠵स"): tRojAyBgfDH37eLCwP4dWl = X4zfvRK0xeZ7()
	elif Mauf6CrJjP87s==iAGgjwb7tVMmacRJ(u"࠵࠶࠷ह"): tRojAyBgfDH37eLCwP4dWl = WmJdOxN39Bw()
	else: tRojAyBgfDH37eLCwP4dWl = kkMuQrLWcEayRm
	return tRojAyBgfDH37eLCwP4dWl
def sWujQcGynM9NtJeTfqk3D(Qjnkp0KgXq2Ty):
	Imphr8LRTUDs(Qjnkp0KgXq2Ty,s5slfAmHkUtMR3WSKY1ZTX,ETNq5t4MYngSsbfFD8J0v(u"ࠬࡼࡩࡥࡧࡲࠫࢢ"))
	return
def WmJdOxN39Bw():
	JPhoBimWUM0Gu2H1Fe9fRv8 = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢣ")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢤ"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def VVYs1Emw3i():
	Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࡮࡬ࡲࡰ࠭ࢥ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+t2sCrJ0xbgDRkf(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢦ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠶࠷࠸ऺ"))
	Qm8SMu6ecXtigDCWw1oak(DTF3Lwy9etRH8mI(u"ࠪࡰ࡮ࡴ࡫ࠨࢧ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢨ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠸࠸ऻ"))
	Qm8SMu6ecXtigDCWw1oak(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡲࡩ࡯࡭ࠪࢩ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+DTF3Lwy9etRH8mI(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢪ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠾࠿࠹࠺़"))
	BNT8yrgUFsfl72adOR = GlWOncToi8PgmfFSKukvLHXBs3p()
	RsojgpxGNH1 = ifTNQtY3XrquHMV4wlCgI6FmpPK.stat(BNT8yrgUFsfl72adOR).st_mtime
	WX5T7vwl4P0qtOgmLNkzKGBUfeY = []
	if LTze51miOknVcslNF43WSA6vMjYZt: wuyiTRP7j2L6WKS = ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(BNT8yrgUFsfl72adOR.encode(f3uIcZ2C6pzbX1JlFBrVOdt))
	else: wuyiTRP7j2L6WKS = ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(BNT8yrgUFsfl72adOR.decode(f3uIcZ2C6pzbX1JlFBrVOdt))
	for gte6YE2JupmKiP in wuyiTRP7j2L6WKS:
		if LTze51miOknVcslNF43WSA6vMjYZt: gte6YE2JupmKiP = gte6YE2JupmKiP.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		if not gte6YE2JupmKiP.startswith(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢫ")): continue
		rfveNDjko5tucZ = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(BNT8yrgUFsfl72adOR,gte6YE2JupmKiP)
		RsojgpxGNH1 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.getmtime(rfveNDjko5tucZ)
		WX5T7vwl4P0qtOgmLNkzKGBUfeY.append([gte6YE2JupmKiP,RsojgpxGNH1])
	WX5T7vwl4P0qtOgmLNkzKGBUfeY = sorted(WX5T7vwl4P0qtOgmLNkzKGBUfeY,reverse=P5VqbRSzjtO4UE1rZaolG67XA,key=lambda key: key[fdQOo6Hu4B5Rbg])
	for gte6YE2JupmKiP,RsojgpxGNH1 in WX5T7vwl4P0qtOgmLNkzKGBUfeY:
		if gA0m6CQUyfLG:
			try: gte6YE2JupmKiP = gte6YE2JupmKiP.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
			except: pass
			gte6YE2JupmKiP = gte6YE2JupmKiP.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		rfveNDjko5tucZ = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(BNT8yrgUFsfl72adOR,gte6YE2JupmKiP)
		Qm8SMu6ecXtigDCWw1oak(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡸ࡬ࡨࡪࡵࠧࢬ"),gte6YE2JupmKiP,rfveNDjko5tucZ,rr7Xolsp4JwjPK3L(u"࠹࠳࠲ऽ"))
	return
def GlWOncToi8PgmfFSKukvLHXBs3p():
	BNT8yrgUFsfl72adOR = amx9qJHkhw7oLdtVMG3.getSetting(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢭ"))
	if BNT8yrgUFsfl72adOR: return BNT8yrgUFsfl72adOR
	amx9qJHkhw7oLdtVMG3.setSetting(DTF3Lwy9etRH8mI(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢮ"),ZwIThN17YKVQnbp52gX)
	return ZwIThN17YKVQnbp52gX
def X4zfvRK0xeZ7():
	BNT8yrgUFsfl72adOR = GlWOncToi8PgmfFSKukvLHXBs3p()
	pNv8FwBr21qmDljEitb = xNVJH71kmLUIy3CjS9TDBQoYu5(iqHhJSxdaANDG5rlZm7B(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢯ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢰ"),ipjCIhwEXsbadR+BNT8yrgUFsfl72adOR+zzGfwLAyN5HTxUoJeaivY+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢱ"))
	if pNv8FwBr21qmDljEitb==VHrIziKUDuNGXkMla(u"࠱ा"):
		iZhOIBRpsK1ety0SD = SulWg06IykM7CxDF9OnZt(DTF3Lwy9etRH8mI(u"࠴ि"),rxWDdRBIct57i90s(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢲ"),qTVF3icWwGXy5(u"ࠨ࡮ࡲࡧࡦࡲࠧࢳ"),G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA,BNT8yrgUFsfl72adOR)
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢴ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢵ"),ipjCIhwEXsbadR+BNT8yrgUFsfl72adOR+zzGfwLAyN5HTxUoJeaivY+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢶ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠳ी"):
			amx9qJHkhw7oLdtVMG3.setSetting(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢷ"),iZhOIBRpsK1ety0SD)
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢸ"),iqHhJSxdaANDG5rlZm7B(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࢹ"))
	return
def IIXSx6vntQc4gMJ(Qjnkp0KgXq2Ty,TJCK7aEsA0Dnl2FmQ=G9G0YqivIfmUWO8K,website=G9G0YqivIfmUWO8K):
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+ssGdubC4mngM9D5SRc3Ye(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࢺ")+Qjnkp0KgXq2Ty+DTF3Lwy9etRH8mI(u"ࠩࠣࡡࠬࢻ"))
	if not TJCK7aEsA0Dnl2FmQ: TJCK7aEsA0Dnl2FmQ = Ig4jFuXGfUQeCn6wlB8(Qjnkp0KgXq2Ty)
	BNT8yrgUFsfl72adOR = GlWOncToi8PgmfFSKukvLHXBs3p()
	Oj5ehfpzir4o0kqCGwntHAugVQ = AyU7CaxXKirHj6kISTMR0d1mgZlJ4s(kkMuQrLWcEayRm)
	gte6YE2JupmKiP = Oj5ehfpzir4o0kqCGwntHAugVQ.replace(ww0sZkBU9JKd,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡣࠬࢼ"))
	gte6YE2JupmKiP = jHk81i3RbxZ(gte6YE2JupmKiP)
	gte6YE2JupmKiP = EHUAyW2lQfe4LXmhgIGc(u"ࠫ࡫࡯࡬ࡦࡡࠪࢽ")+str(int(AVeHPW5shuXLdr2vwD))[-dC3PsQJ0Ti28uYlov(u"࠷ु"):]+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡥࠧࢾ")+gte6YE2JupmKiP+TJCK7aEsA0Dnl2FmQ
	QpuzmorljvAdxafOstcV1B4Le = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(BNT8yrgUFsfl72adOR,gte6YE2JupmKiP)
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI = {}
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI[RVpeGcmPxj9tCnT40Nf216(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࢿ")] = G9G0YqivIfmUWO8K
	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣀ")] = iqHhJSxdaANDG5rlZm7B(u"ࠨࠬ࠲࠮ࠬࣁ")
	Qjnkp0KgXq2Ty = Qjnkp0KgXq2Ty.replace(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣂ"),G9G0YqivIfmUWO8K)
	if rr7Xolsp4JwjPK3L(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨࣃ") in Qjnkp0KgXq2Ty:
		XXzvmn7ewM8yBfoxua,TkUSmDLJYy = Qjnkp0KgXq2Ty.rsplit(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࣄ"),VHrIziKUDuNGXkMla(u"࠵ू"))
		TkUSmDLJYy = TkUSmDLJYy.replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࢂࠧࣅ"),G9G0YqivIfmUWO8K).replace(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࠦࠨࣆ"),G9G0YqivIfmUWO8K)
	else: XXzvmn7ewM8yBfoxua,TkUSmDLJYy = Qjnkp0KgXq2Ty,None
	if not TkUSmDLJYy: TkUSmDLJYy = uCUkPIYFszbV90wSpKqWNOjZ1687Eh()
	if TkUSmDLJYy: cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI[ssGdubC4mngM9D5SRc3Ye(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣇ")] = TkUSmDLJYy
	if wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪࣈ") in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua,pM0RwoYjfsUVZcqt6uTOiFkhEXCS = XXzvmn7ewM8yBfoxua.rsplit(ETNq5t4MYngSsbfFD8J0v(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫࣉ"),bneABYmwFUH8GXphg0Kl2Sq(u"࠶ृ"))
	else: XXzvmn7ewM8yBfoxua,pM0RwoYjfsUVZcqt6uTOiFkhEXCS = XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.strip(VHrIziKUDuNGXkMla(u"ࠪࢀࠬ࣊")).strip(qTVF3icWwGXy5(u"ࠫࠫ࠭࣋")).strip(RVpeGcmPxj9tCnT40Nf216(u"ࠬࢂࠧ࣌")).strip(yiaeCEwJjOcWA4ZSd5h(u"࠭ࠦࠨ࣍"))
	pM0RwoYjfsUVZcqt6uTOiFkhEXCS = pM0RwoYjfsUVZcqt6uTOiFkhEXCS.replace(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡽࠩ࣎"),G9G0YqivIfmUWO8K).replace(cJSNFCIhymEfx6grGu0M(u"ࠨࠨ࣏ࠪ"),G9G0YqivIfmUWO8K)
	if pM0RwoYjfsUVZcqt6uTOiFkhEXCS:	cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI[RVpeGcmPxj9tCnT40Nf216(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴ࣐ࠪ")] = pM0RwoYjfsUVZcqt6uTOiFkhEXCS
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝࣑ࠣࠫ")+XXzvmn7ewM8yBfoxua+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠ࣒ࠦࠧ")+str(cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI)+rxWDdRBIct57i90s(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤ࣓ࠬ")+QpuzmorljvAdxafOstcV1B4Le+bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࠠ࡞ࠩࣔ"))
	xow215zFbEDBRei9qONlUH3nCy = RVpeGcmPxj9tCnT40Nf216(u"࠷࠰࠳࠶ॄ")*RVpeGcmPxj9tCnT40Nf216(u"࠷࠰࠳࠶ॄ")
	xRkKdS8BE6MUJiPp = qTVF3icWwGXy5(u"࠰ॅ")
	try:
		MMNI7jCqVGbOgnlJTsd3E =	oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣕ"))
		MMNI7jCqVGbOgnlJTsd3E = oo9kuULlebNgpY0Om.findall(jR9YtmsgDX8nTQlMb6G3(u"ࠨ࡞ࡧ࠯ࠬࣖ"),MMNI7jCqVGbOgnlJTsd3E)
		xRkKdS8BE6MUJiPp = int(MMNI7jCqVGbOgnlJTsd3E[dQ5JhEYolPmy1fvHktMw6NFRxiz])
	except: pass
	if not xRkKdS8BE6MUJiPp:
		try:
			xUwMpASHvzjRq = ifTNQtY3XrquHMV4wlCgI6FmpPK.statvfs(BNT8yrgUFsfl72adOR)
			xRkKdS8BE6MUJiPp = xUwMpASHvzjRq.f_frsize*xUwMpASHvzjRq.f_bavail//xow215zFbEDBRei9qONlUH3nCy
		except: pass
	if not xRkKdS8BE6MUJiPp:
		try:
			xUwMpASHvzjRq = ifTNQtY3XrquHMV4wlCgI6FmpPK.fstatvfs(BNT8yrgUFsfl72adOR)
			xRkKdS8BE6MUJiPp = xUwMpASHvzjRq.f_frsize*xUwMpASHvzjRq.f_bavail//xow215zFbEDBRei9qONlUH3nCy
		except: pass
	if not xRkKdS8BE6MUJiPp:
		try:
			import shutil as P9dvwKhmIxeJSB5YO
			PPNWkJiwjq9gf,AuKxrsIwU5ZcdJ8G,f2fP4JOyzDtYj = P9dvwKhmIxeJSB5YO.disk_usage(BNT8yrgUFsfl72adOR)
			xRkKdS8BE6MUJiPp = f2fP4JOyzDtYj//xow215zFbEDBRei9qONlUH3nCy
		except: pass
	if not xRkKdS8BE6MUJiPp:
		tg6EQSH7P4(iqHhJSxdaANDG5rlZm7B(u"ࠩࡵ࡭࡬࡮ࡴࠨࣗ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣘ"),yiaeCEwJjOcWA4ZSd5h(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨࣙ"),cjbAkCIinvs(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࣚ"))
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+EHUAyW2lQfe4LXmhgIGc(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧࣛ"))
		return kkMuQrLWcEayRm
	if TJCK7aEsA0Dnl2FmQ==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࣜ"):
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = wjWrbquZad3QefJ2yz4(s5slfAmHkUtMR3WSKY1ZTX,XXzvmn7ewM8yBfoxua,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI)
		if len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠱ॆ"):
			XXeZuvhknsKYqB17gwm6dfc(iqHhJSxdaANDG5rlZm7B(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣝ"),G9G0YqivIfmUWO8K)
			return kkMuQrLWcEayRm
		elif len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)==bneABYmwFUH8GXphg0Kl2Sq(u"࠳े"): PXeEIRkdShOGm45lbLJc2B38s = dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠳ै")
		elif len(Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)>t2sCrJ0xbgDRkf(u"࠵ॉ"):
			PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣞ"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
			if PXeEIRkdShOGm45lbLJc2B38s == -cJSNFCIhymEfx6grGu0M(u"࠶ॊ") :
				XXeZuvhknsKYqB17gwm6dfc(dC3PsQJ0Ti28uYlov(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้࠭ࣟ"),G9G0YqivIfmUWO8K)
				return kkMuQrLWcEayRm
		XXzvmn7ewM8yBfoxua = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	B4OtyRxPfANeZobT = RVpeGcmPxj9tCnT40Nf216(u"࠶ो")
	import requests as MMEFXQfRHgZI3VSo4nrP57ypaLY
	if TJCK7aEsA0Dnl2FmQ==cJSNFCIhymEfx6grGu0M(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ࣠"):
		QpuzmorljvAdxafOstcV1B4Le = QpuzmorljvAdxafOstcV1B4Le.rsplit(rr7Xolsp4JwjPK3L(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ࣡"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+DTF3Lwy9etRH8mI(u"࠭࠮࡮ࡲ࠷ࠫ࣢")
		gULrv3Q4Cq = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡈࡇࡗࣣࠫ"),XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨࣤ"))
		VdYiOMjybIsm7qxD2EGPeJW3hg = gULrv3Q4Cq.content
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪࣥ"),VdYiOMjybIsm7qxD2EGPeJW3hg+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡠࡳࡢࡲࠨࣦ"),oo9kuULlebNgpY0Om.DOTALL)
		if not dsGzqX4k0a8RLyc:
			vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧࣧ")+XXzvmn7ewM8yBfoxua+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࠦ࡝ࠨࣨ"))
			return kkMuQrLWcEayRm
		Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if not Y6YdkAMluFbwx.startswith(FWqeEzO1i8Dn0ga(u"࠭ࡨࡵࡶࡳࣩࠫ")):
			if Y6YdkAMluFbwx.startswith(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧ࠰࠱ࠪ࣪")): Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua.split(iAGgjwb7tVMmacRJ(u"ࠨ࠼ࠪ࣫"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠱ौ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+yiaeCEwJjOcWA4ZSd5h(u"ࠩ࠽ࠫ࣬")+Y6YdkAMluFbwx
			elif Y6YdkAMluFbwx.startswith(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪ࠳࣭ࠬ")): Y6YdkAMluFbwx = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,FWqeEzO1i8Dn0ga(u"ࠫࡺࡸ࡬ࠨ࣮"))+Y6YdkAMluFbwx
			else: Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua.rsplit(yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠵࣯ࠧ"),iqHhJSxdaANDG5rlZm7B(u"࠲्"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+t2sCrJ0xbgDRkf(u"࠭࠯ࠨࣰ")+Y6YdkAMluFbwx
		gULrv3Q4Cq = MMEFXQfRHgZI3VSo4nrP57ypaLY.request(UighHKAfySm4PWErqJ(u"ࠧࡈࡇࡗࣱࠫ"),Y6YdkAMluFbwx,headers=cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,verify=kkMuQrLWcEayRm)
		FtyW9IjBVma = gULrv3Q4Cq.content
		FKmlL2QoMj8uPO4aY963X = len(FtyW9IjBVma)
		bFeqxjOi508KPZlw6IuGzUyfNadTSg = len(dsGzqX4k0a8RLyc)
		B4OtyRxPfANeZobT = FKmlL2QoMj8uPO4aY963X*bFeqxjOi508KPZlw6IuGzUyfNadTSg
	else:
		FKmlL2QoMj8uPO4aY963X = iAGgjwb7tVMmacRJ(u"࠳ॎ")*xow215zFbEDBRei9qONlUH3nCy
		gULrv3Q4Cq = MMEFXQfRHgZI3VSo4nrP57ypaLY.request(ETNq5t4MYngSsbfFD8J0v(u"ࠨࡉࡈࡘࣲࠬ"),XXzvmn7ewM8yBfoxua,headers=cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,verify=kkMuQrLWcEayRm,stream=P5VqbRSzjtO4UE1rZaolG67XA)
		if iqHhJSxdaANDG5rlZm7B(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪࣳ") in gULrv3Q4Cq.headers: B4OtyRxPfANeZobT = int(gULrv3Q4Cq.headers[ssGdubC4mngM9D5SRc3Ye(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣴ")])
		bFeqxjOi508KPZlw6IuGzUyfNadTSg = int(B4OtyRxPfANeZobT//FKmlL2QoMj8uPO4aY963X)
	wcEdUAlhtZbpPDr8j = int(B4OtyRxPfANeZobT//xow215zFbEDBRei9qONlUH3nCy)+dC3PsQJ0Ti28uYlov(u"࠴ॏ")
	if B4OtyRxPfANeZobT<Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠶࠶࠶࠰࠱ॐ"):
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣵ")+XXzvmn7ewM8yBfoxua+UighHKAfySm4PWErqJ(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࣶࠦࠡࠩ")+str(wcEdUAlhtZbpPDr8j)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣷ")+str(xRkKdS8BE6MUJiPp)+RVpeGcmPxj9tCnT40Nf216(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣸ")+QpuzmorljvAdxafOstcV1B4Le+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࠢࡠࣹࠫ"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࣺࠬ"),VHrIziKUDuNGXkMla(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬࣻ"))
		return kkMuQrLWcEayRm
	zWd4fQBJYDAVO5hF = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠹࠶࠰॑")
	gQV6A80NEYWBD9PKMR = xRkKdS8BE6MUJiPp-wcEdUAlhtZbpPDr8j
	if gQV6A80NEYWBD9PKMR<zWd4fQBJYDAVO5hF:
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+qTVF3icWwGXy5(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪࣼ")+XXzvmn7ewM8yBfoxua+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(wcEdUAlhtZbpPDr8j)+cjbAkCIinvs(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(xRkKdS8BE6MUJiPp)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧࣿ")+str(zWd4fQBJYDAVO5hF)+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऀ")+QpuzmorljvAdxafOstcV1B4Le+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࠣࡡࠬँ"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪं"),t2sCrJ0xbgDRkf(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪः")+str(wcEdUAlhtZbpPDr8j)+cjbAkCIinvs(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऄ")+str(xRkKdS8BE6MUJiPp)+cJSNFCIhymEfx6grGu0M(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭अ")+str(zWd4fQBJYDAVO5hF)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩआ"))
		return kkMuQrLWcEayRm
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨइ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪई"),RVpeGcmPxj9tCnT40Nf216(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩउ")+str(wcEdUAlhtZbpPDr8j)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऊ")+str(xRkKdS8BE6MUJiPp)+DTF3Lwy9etRH8mI(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऋ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷॒"):
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫऌ"))
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऍ")+XXzvmn7ewM8yBfoxua+yiaeCEwJjOcWA4ZSd5h(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऎ")+QpuzmorljvAdxafOstcV1B4Le+EHUAyW2lQfe4LXmhgIGc(u"ࠩࠣࡡࠬए"))
		return kkMuQrLWcEayRm
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+EHUAyW2lQfe4LXmhgIGc(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨऐ"))
	HofqU5Wsa9 = dWO9bFPCYXVDrcU81xN5kJ23laR()
	HofqU5Wsa9.create(QpuzmorljvAdxafOstcV1B4Le,jR9YtmsgDX8nTQlMb6G3(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬऑ"))
	rrSiRbgxDu2vt = P5VqbRSzjtO4UE1rZaolG67XA
	ONEZrIFzqkX1no = SSCU3jdyFn2V.time()
	if not iKLYEvx39c.w0Zn3BsVo7GWDyuli:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨऒ"),RVpeGcmPxj9tCnT40Nf216(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧओ"))
		return kkMuQrLWcEayRm
	if LTze51miOknVcslNF43WSA6vMjYZt: Z2mSnLO1p5JUdWBr83 = open(QpuzmorljvAdxafOstcV1B4Le,iAGgjwb7tVMmacRJ(u"ࠧࡸࡤࠪऔ"))
	else: Z2mSnLO1p5JUdWBr83 = open(QpuzmorljvAdxafOstcV1B4Le.decode(f3uIcZ2C6pzbX1JlFBrVOdt),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡹࡥࠫक"))
	if TJCK7aEsA0Dnl2FmQ==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨख"):
		for p0p6MxKbklodNCR92Wv in range(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠱॓"),bFeqxjOi508KPZlw6IuGzUyfNadTSg+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠱॓")):
			Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[p0p6MxKbklodNCR92Wv-iAGgjwb7tVMmacRJ(u"࠲॔")]
			if not Y6YdkAMluFbwx.startswith(EHUAyW2lQfe4LXmhgIGc(u"ࠪ࡬ࡹࡺࡰࠨग")):
				if Y6YdkAMluFbwx.startswith(FWqeEzO1i8Dn0ga(u"ࠫ࠴࠵ࠧघ")): Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua.split(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡀࠧङ"),rr7Xolsp4JwjPK3L(u"࠳ॕ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+iAGgjwb7tVMmacRJ(u"࠭࠺ࠨच")+Y6YdkAMluFbwx
				elif Y6YdkAMluFbwx.startswith(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࠰ࠩछ")): Y6YdkAMluFbwx = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,iqHhJSxdaANDG5rlZm7B(u"ࠨࡷࡵࡰࠬज"))+Y6YdkAMluFbwx
				else: Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua.rsplit(cjbAkCIinvs(u"ࠩ࠲ࠫझ"),t2sCrJ0xbgDRkf(u"࠴ॖ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪ࠳ࠬञ")+Y6YdkAMluFbwx
			gULrv3Q4Cq = MMEFXQfRHgZI3VSo4nrP57ypaLY.request(UighHKAfySm4PWErqJ(u"ࠫࡌࡋࡔࠨट"),Y6YdkAMluFbwx,headers=cjJsYDC0Bb31rRtWoqP6uQ2E5pSyUI,verify=kkMuQrLWcEayRm)
			FtyW9IjBVma = gULrv3Q4Cq.content
			gULrv3Q4Cq.close()
			Z2mSnLO1p5JUdWBr83.write(FtyW9IjBVma)
			KKtnT8wFmZXUxoIlgu5y6 = SSCU3jdyFn2V.time()
			HjY6fZprhdIoACW904T = KKtnT8wFmZXUxoIlgu5y6-ONEZrIFzqkX1no
			OVzywtbkfqL6493dQlumG = HjY6fZprhdIoACW904T//p0p6MxKbklodNCR92Wv
			GGoBwPLfmvcRkDYj = OVzywtbkfqL6493dQlumG*(bFeqxjOi508KPZlw6IuGzUyfNadTSg+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠵ॗ"))
			fC8lZcPu9UNFsTd5V = GGoBwPLfmvcRkDYj-HjY6fZprhdIoACW904T
			CigEOdTqom6Gw5nta(HofqU5Wsa9,int(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠷࠰࠱ख़")*p0p6MxKbklodNCR92Wv//(bFeqxjOi508KPZlw6IuGzUyfNadTSg+hhdGMSsBzel96obfEmrwiuLPOvq(u"࠶क़"))),RVpeGcmPxj9tCnT40Nf216(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ठ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ड"),str(p0p6MxKbklodNCR92Wv*FKmlL2QoMj8uPO4aY963X//xow215zFbEDBRei9qONlUH3nCy)+iqHhJSxdaANDG5rlZm7B(u"ࠧ࠰ࠩढ")+str(wcEdUAlhtZbpPDr8j)+dC3PsQJ0Ti28uYlov(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ण")+SSCU3jdyFn2V.strftime(jR9YtmsgDX8nTQlMb6G3(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦत"),SSCU3jdyFn2V.gmtime(fC8lZcPu9UNFsTd5V))+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠤๅ࠭थ"))
			if HofqU5Wsa9.iscanceled():
				rrSiRbgxDu2vt = kkMuQrLWcEayRm
				break
	else:
		p0p6MxKbklodNCR92Wv = iqHhJSxdaANDG5rlZm7B(u"࠰ग़")
		for FtyW9IjBVma in gULrv3Q4Cq.iter_content(chunk_size=FKmlL2QoMj8uPO4aY963X):
			Z2mSnLO1p5JUdWBr83.write(FtyW9IjBVma)
			p0p6MxKbklodNCR92Wv = p0p6MxKbklodNCR92Wv+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠲ज़")
			KKtnT8wFmZXUxoIlgu5y6 = SSCU3jdyFn2V.time()
			HjY6fZprhdIoACW904T = KKtnT8wFmZXUxoIlgu5y6-ONEZrIFzqkX1no
			OVzywtbkfqL6493dQlumG = HjY6fZprhdIoACW904T/p0p6MxKbklodNCR92Wv
			GGoBwPLfmvcRkDYj = OVzywtbkfqL6493dQlumG*(bFeqxjOi508KPZlw6IuGzUyfNadTSg+ETNq5t4MYngSsbfFD8J0v(u"࠳ड़"))
			fC8lZcPu9UNFsTd5V = GGoBwPLfmvcRkDYj-HjY6fZprhdIoACW904T
			CigEOdTqom6Gw5nta(HofqU5Wsa9,int(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠵࠵࠶फ़")*p0p6MxKbklodNCR92Wv/(bFeqxjOi508KPZlw6IuGzUyfNadTSg+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠴ढ़"))),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬद"),ssGdubC4mngM9D5SRc3Ye(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬध"),str(p0p6MxKbklodNCR92Wv*FKmlL2QoMj8uPO4aY963X//xow215zFbEDBRei9qONlUH3nCy)+EHUAyW2lQfe4LXmhgIGc(u"࠭࠯ࠨन")+str(wcEdUAlhtZbpPDr8j)+iqHhJSxdaANDG5rlZm7B(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬऩ")+SSCU3jdyFn2V.strftime(dC3PsQJ0Ti28uYlov(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥप"),SSCU3jdyFn2V.gmtime(fC8lZcPu9UNFsTd5V))+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࠣไࠬफ"))
			if HofqU5Wsa9.iscanceled():
				rrSiRbgxDu2vt = kkMuQrLWcEayRm
				break
		gULrv3Q4Cq.close()
	Z2mSnLO1p5JUdWBr83.close()
	HofqU5Wsa9.close()
	if not rrSiRbgxDu2vt:
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+EHUAyW2lQfe4LXmhgIGc(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧब")+XXzvmn7ewM8yBfoxua+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫभ")+QpuzmorljvAdxafOstcV1B4Le+iqHhJSxdaANDG5rlZm7B(u"ࠬࠦ࡝ࠨम"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩय"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"))
		return P5VqbRSzjtO4UE1rZaolG67XA
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+cjbAkCIinvs(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧऱ")+XXzvmn7ewM8yBfoxua+RVpeGcmPxj9tCnT40Nf216(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩल")+QpuzmorljvAdxafOstcV1B4Le+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࠤࡢ࠭ळ"))
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫव"))
	return P5VqbRSzjtO4UE1rZaolG67XA
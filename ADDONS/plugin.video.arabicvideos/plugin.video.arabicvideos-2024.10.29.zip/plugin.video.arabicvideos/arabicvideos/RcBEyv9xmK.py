# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'MOVIZLAND'
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
TdtCLWYSJNK8zOb = '_MVZ_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
cEz6aWRhkf1KS = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][1]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==180: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==181: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==182: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==183: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==188: tRojAyBgfDH37eLCwP4dWl = E0wRI9B58K1WGAMxhL()
	elif mode==189: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def E0wRI9B58K1WGAMxhL():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج',message)
	return
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,189,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'بوكس اوفيس موفيز لاند',ffVP3AK5RqhkgYnjZoNis,181,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'box-office')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أحدث الافلام',ffVP3AK5RqhkgYnjZoNis,181,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'latest-movies')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'تليفزيون موفيز لاند',ffVP3AK5RqhkgYnjZoNis,181,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'tv')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الاكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis,181,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'top-views')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أقوى الافلام الحالية',ffVP3AK5RqhkgYnjZoNis,181,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'top-movies')
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-MENU-1st')
	items = oo9kuULlebNgpY0Om.findall('<h2><a href="(.*?)".*?">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,181)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	elif type=='box-office': BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	elif type=='top-movies': BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('btn-2-overlay(.*?)<style>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	elif type=='top-views': BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	elif type=='tv': BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	else: BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
	if type in ['top-views','top-movies']:
		items = oo9kuULlebNgpY0Om.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	else: items = oo9kuULlebNgpY0Om.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	vvWOPDzyKX09YaRfmhVH7UdiBS = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for M4qkBDatEIf3T,gIRLK2jm74q31vs5z,uB9bUF45na,sUcPV0EKIN4iLAQFl7WJdnZ3S in items:
		if type in ['top-views','top-movies']:
			M4qkBDatEIf3T,Y6YdkAMluFbwx,z7GYBmKiXwreV2QybCNn80v9pT,title = M4qkBDatEIf3T,gIRLK2jm74q31vs5z,uB9bUF45na,sUcPV0EKIN4iLAQFl7WJdnZ3S
		else: M4qkBDatEIf3T,title,Y6YdkAMluFbwx,z7GYBmKiXwreV2QybCNn80v9pT = M4qkBDatEIf3T,gIRLK2jm74q31vs5z,uB9bUF45na,sUcPV0EKIN4iLAQFl7WJdnZ3S
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('?view=true',G9G0YqivIfmUWO8K)
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',G9G0YqivIfmUWO8K).replace('بجوده ',G9G0YqivIfmUWO8K)
		title = title.strip(ww0sZkBU9JKd)
		if 'الحلقة' in title or 'الحلقه' in title:
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|الحلقه) \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,183,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in vvWOPDzyKX09YaRfmhVH7UdiBS):
			Y6YdkAMluFbwx = Y6YdkAMluFbwx + '?servers=' + z7GYBmKiXwreV2QybCNn80v9pT
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,182,M4qkBDatEIf3T)
		else:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx + '?servers=' + z7GYBmKiXwreV2QybCNn80v9pT
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,183,M4qkBDatEIf3T)
	if type==G9G0YqivIfmUWO8K:
		items = oo9kuULlebNgpY0Om.findall('\n<li><a href="(.*?)".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
			if title!=G9G0YqivIfmUWO8K:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,181)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	XXzvmn7ewM8yBfoxua = url.split('?servers=')[0]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-EPISODES-1st')
	BN1KdkzCmvshw = oo9kuULlebNgpY0Om.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	title,HHFwtdVPy2OZ,M4qkBDatEIf3T = BN1KdkzCmvshw[0]
	name = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,oo9kuULlebNgpY0Om.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="episodesNumbers"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in items:
			Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
			title = oo9kuULlebNgpY0Om.findall('(الحلقة|الحلقه)-([0-9]+)',Y6YdkAMluFbwx.split('/')[-2],oo9kuULlebNgpY0Om.DOTALL)
			if not title: title = oo9kuULlebNgpY0Om.findall('()-([0-9]+)',Y6YdkAMluFbwx.split('/')[-2],oo9kuULlebNgpY0Om.DOTALL)
			if title: title = ww0sZkBU9JKd + title[0][1]
			else: title = G9G0YqivIfmUWO8K
			title = name + ' - ' + 'الحلقة' + title
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,182,M4qkBDatEIf3T)
	if not items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',G9G0YqivIfmUWO8K).replace('بجوده ',G9G0YqivIfmUWO8K)
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,url,182,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	pUrSPMLW53w1cYRD08fHzodEZ = url.split('?servers=')
	XXzvmn7ewM8yBfoxua = pUrSPMLW53w1cYRD08fHzodEZ[0]
	del pUrSPMLW53w1cYRD08fHzodEZ[0]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-PLAY-1st')
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('font-size: 25px;" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	if Y6YdkAMluFbwx not in pUrSPMLW53w1cYRD08fHzodEZ: pUrSPMLW53w1cYRD08fHzodEZ.append(Y6YdkAMluFbwx)
	ODnaR0N8UHv7Twy6jS = []
	for Y6YdkAMluFbwx in pUrSPMLW53w1cYRD08fHzodEZ:
		if '://moshahda.' in Y6YdkAMluFbwx:
			qhmjcz6UAFyY0xJ = Y6YdkAMluFbwx
			ODnaR0N8UHv7Twy6jS.append(qhmjcz6UAFyY0xJ+'?named=Main')
	for Y6YdkAMluFbwx in pUrSPMLW53w1cYRD08fHzodEZ:
		if '://vb.movizland.' in Y6YdkAMluFbwx:
			GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,Y6YdkAMluFbwx,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-PLAY-2nd')
			GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.decode('windows-1256').encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			if cSLKDEATk7y10ovtGZCwF:
				YeMhgjKoiwFRbATH5d8QVGmv4fsB,EEm7hgHpsjDO82aIQSNMf9yY6ZXrc = [],[]
				if len(cSLKDEATk7y10ovtGZCwF)==1:
					title = G9G0YqivIfmUWO8K
					BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
				else:
					for BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
						duYhmVFABjltoJ9PcE = oo9kuULlebNgpY0Om.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
						if duYhmVFABjltoJ9PcE: BN1KdkzCmvshw = 'src="/uploads/13721411411.png"  \n  ' + duYhmVFABjltoJ9PcE[0][1]
						duYhmVFABjltoJ9PcE = oo9kuULlebNgpY0Om.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
						if duYhmVFABjltoJ9PcE: BN1KdkzCmvshw = 'src="/uploads/13721411411.png"  \n  ' + duYhmVFABjltoJ9PcE[0]
						duYhmVFABjltoJ9PcE = oo9kuULlebNgpY0Om.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
						if duYhmVFABjltoJ9PcE: BN1KdkzCmvshw = duYhmVFABjltoJ9PcE[0] + '  \n  src="/uploads/13721411411.png"'
						rcDQl6dYFH37JwELACPqMBhaz1gjyn = oo9kuULlebNgpY0Om.findall('<(.*?)http://up.movizland.(online|com)/uploads/',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
						title = oo9kuULlebNgpY0Om.findall('> *([^<>]+) *<',rcDQl6dYFH37JwELACPqMBhaz1gjyn[0][0],oo9kuULlebNgpY0Om.DOTALL)
						title = ww0sZkBU9JKd.join(title)
						title = title.strip(ww0sZkBU9JKd)
						title = title.replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
						YeMhgjKoiwFRbATH5d8QVGmv4fsB.append(title)
					PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('أختر الفيديو المطلوب:', YeMhgjKoiwFRbATH5d8QVGmv4fsB)
					if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
					title = YeMhgjKoiwFRbATH5d8QVGmv4fsB[PXeEIRkdShOGm45lbLJc2B38s]
					BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[PXeEIRkdShOGm45lbLJc2B38s]
				Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('href="(http://moshahda\..*?/\w+.html)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				cUhjfFKRqpsBnS5Hb = Y6YdkAMluFbwx[0]
				ODnaR0N8UHv7Twy6jS.append(cUhjfFKRqpsBnS5Hb+'?named=Forum')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('ـ',G9G0YqivIfmUWO8K)
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				BN1KdkzCmvshw = BN1KdkzCmvshw.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				CsMxdoibDf9 = oo9kuULlebNgpY0Om.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for aCd6q7tXLIPu2i in CsMxdoibDf9:
					type = oo9kuULlebNgpY0Om.findall(' typetype="(.*?)" ',aCd6q7tXLIPu2i)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = G9G0YqivIfmUWO8K
					items = oo9kuULlebNgpY0Om.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',aCd6q7tXLIPu2i,oo9kuULlebNgpY0Om.DOTALL)
					for cIrD3YgjF1H,Y6YdkAMluFbwx in items:
						title = oo9kuULlebNgpY0Om.findall('(\w+[ \w]*)<',cIrD3YgjF1H)
						title = title[-1]
						Y6YdkAMluFbwx = Y6YdkAMluFbwx + '?named=' + title + type
						ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	XjWHSnbf6NwhMgpKt4yLY7AkIT = XXzvmn7ewM8yBfoxua.replace(ffVP3AK5RqhkgYnjZoNis,cEz6aWRhkf1KS)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-PLAY-3rd')
	items = oo9kuULlebNgpY0Om.findall('" href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		hhImdz6tlRAO7U = items[-1]
		ODnaR0N8UHv7Twy6jS.append(hhImdz6tlRAO7U+'?named=Mobile')
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'MOVIZLAND-SEARCH-1st')
	items = oo9kuULlebNgpY0Om.findall('<option value="(.*?)">(.*?)</option>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BBzv3TGJyqheS1E8OZkj = [ G9G0YqivIfmUWO8K ]
	SfZnHPUoMuiEsQB9zAy4 = [ 'الكل وبدون فلتر' ]
	for nxguK9laUWBGHIR4zEsTo7,title in items:
		BBzv3TGJyqheS1E8OZkj.append(nxguK9laUWBGHIR4zEsTo7)
		SfZnHPUoMuiEsQB9zAy4.append(title)
	if nxguK9laUWBGHIR4zEsTo7:
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('اختر الفلتر المناسب:', SfZnHPUoMuiEsQB9zAy4)
		if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
		nxguK9laUWBGHIR4zEsTo7 = BBzv3TGJyqheS1E8OZkj[PXeEIRkdShOGm45lbLJc2B38s]
	else: nxguK9laUWBGHIR4zEsTo7 = G9G0YqivIfmUWO8K
	url = ffVP3AK5RqhkgYnjZoNis + '/?s='+search+'&mcat='+nxguK9laUWBGHIR4zEsTo7
	UUhwKBgI2nt(url)
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SHOOFMAX'
TdtCLWYSJNK8zOb = '_SHM_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
cEz6aWRhkf1KS = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][1]
JJ6hGQx95F = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][2]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==50: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==51: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==52: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==53: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==55: tRojAyBgfDH37eLCwP4dWl = xsiD2hMQUEpPF8G0c1X3()
	elif mode==56: tRojAyBgfDH37eLCwP4dWl = BIpP68SDTCwAney07cYWgoZVNhqkuU()
	elif mode==57: tRojAyBgfDH37eLCwP4dWl = zzR2cwayn6V9vITEgspxLi3oZ(url,1)
	elif mode==58: tRojAyBgfDH37eLCwP4dWl = zzR2cwayn6V9vITEgspxLi3oZ(url,2)
	elif mode==59: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,59,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المسلسلات',G9G0YqivIfmUWO8K,56)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الافلام',G9G0YqivIfmUWO8K,55)
	return G9G0YqivIfmUWO8K
def xsiD2hMQUEpPF8G0c1X3():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أفلام مرتبة بسنة الإنتاج',ffVP3AK5RqhkgYnjZoNis+'/movie/1/yop',57)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أفلام مرتبة بالأفضل تقييم',ffVP3AK5RqhkgYnjZoNis+'/movie/1/review',57)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أفلام مرتبة بالأكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis+'/movie/1/views',57)
	return
def BIpP68SDTCwAney07cYWgoZVNhqkuU():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات مرتبة بسنة الإنتاج',ffVP3AK5RqhkgYnjZoNis+'/series/1/yop',57)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات مرتبة بالأفضل تقييم',ffVP3AK5RqhkgYnjZoNis+'/series/1/review',57)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسلات مرتبة بالأكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis+'/series/1/views',57)
	return
def UUhwKBgI2nt(url):
	if '?' in url:
		mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('?')
		url = mtMexSFLnkwhbAaP9pgDduCRBi2[0]
		filter = '?' + SSX6oT0lADZhKRImPvCHFkYJs(mtMexSFLnkwhbAaP9pgDduCRBi2[1],'=&:/%')
	else: filter = G9G0YqivIfmUWO8K
	type,eehFlSEjHioyAWpLqZXt79,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': gcfGZbI9h5a='فيلم'
		elif type=='series': gcfGZbI9h5a='مسلسل'
		url = ffVP3AK5RqhkgYnjZoNis + '/genre/filter/' + SSX6oT0lADZhKRImPvCHFkYJs(gcfGZbI9h5a) + '/' + eehFlSEjHioyAWpLqZXt79 + '/' + sort + filter
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOOFMAX-TITLES-1st')
		items = oo9kuULlebNgpY0Om.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		ErFhfeKQIkOMSYUms35vbqTD0x8=0
		for id,title,INYsuanxqjhc8eBd1FrwbTKU,M4qkBDatEIf3T in items:
			ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
			M4qkBDatEIf3T = JJ6hGQx95F + '/v2/img/program/main/' + M4qkBDatEIf3T + '-2.jpg'
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis + '/program/' + id
			if type=='movie': Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,53,M4qkBDatEIf3T)
			if type=='series': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسل '+title,Y6YdkAMluFbwx+'?ep='+INYsuanxqjhc8eBd1FrwbTKU+'='+title+'='+M4qkBDatEIf3T,52,M4qkBDatEIf3T)
	else:
		if type=='movie': gcfGZbI9h5a='movies'
		elif type=='series': gcfGZbI9h5a='series'
		url = cEz6aWRhkf1KS + '/json/selected/' + sort + '-' + gcfGZbI9h5a + '-WW.json'
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOOFMAX-TITLES-2nd')
		items = oo9kuULlebNgpY0Om.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		ErFhfeKQIkOMSYUms35vbqTD0x8=0
		for id,INYsuanxqjhc8eBd1FrwbTKU,M4qkBDatEIf3T,title in items:
			ErFhfeKQIkOMSYUms35vbqTD0x8 += 1
			M4qkBDatEIf3T = cEz6aWRhkf1KS + '/img/program/' + M4qkBDatEIf3T + '-2.jpg'
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis + '/program/' + id
			if type=='movie': Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,53,M4qkBDatEIf3T)
			elif type=='series': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مسلسل '+title,Y6YdkAMluFbwx+'?ep='+INYsuanxqjhc8eBd1FrwbTKU+'='+title+'='+M4qkBDatEIf3T,52,M4qkBDatEIf3T)
	title='صفحة '
	if ErFhfeKQIkOMSYUms35vbqTD0x8==16:
		for j43xMTeoZfOUEKJ in range(1,13) :
			if not eehFlSEjHioyAWpLqZXt79==str(j43xMTeoZfOUEKJ):
				url = ffVP3AK5RqhkgYnjZoNis+'/genre/filter/'+type+'/'+str(j43xMTeoZfOUEKJ)+'/'+sort+filter
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title+str(j43xMTeoZfOUEKJ),url,51)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('=')
	INYsuanxqjhc8eBd1FrwbTKU = int(mtMexSFLnkwhbAaP9pgDduCRBi2[1])
	name = aKAyEnjxIlzZtCTv(mtMexSFLnkwhbAaP9pgDduCRBi2[2])
	name = name.replace('_MOD_مسلسل ',G9G0YqivIfmUWO8K)
	M4qkBDatEIf3T = mtMexSFLnkwhbAaP9pgDduCRBi2[3]
	url = url.split('?')[0]
	if INYsuanxqjhc8eBd1FrwbTKU==0:
		GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOOFMAX-EPISODES-1st')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<select(.*?)</select>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('option value="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		INYsuanxqjhc8eBd1FrwbTKU = int(items[-1])
	for RnV3EqPNpXTDuI7 in range(INYsuanxqjhc8eBd1FrwbTKU,0,-1):
		Y6YdkAMluFbwx = url + '?ep=' + str(RnV3EqPNpXTDuI7)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(RnV3EqPNpXTDuI7)
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,53,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOOFMAX-PLAY-1st')
	RGS8Q1VJzlbM = oo9kuULlebNgpY0Om.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if RGS8Q1VJzlbM:
		SSCU3jdyFn2V = RGS8Q1VJzlbM[1].replace('T',MjuRWebwX0pfD)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+zEgtT9cR6bFp7JXqI5VuhNeP+SSCU3jdyFn2V)
		return
	EZvlYsQbjWcCokaGdg,VVqcGEo5O2hxBYnfSHgbD = [],[]
	WY2jCAw64QTREgqyeBxJDrIa9hNK = oo9kuULlebNgpY0Om.findall('var origin_link = "(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	vv8ohbxsST1kQErnNuCjL = oo9kuULlebNgpY0Om.findall('var backup_origin_link = "(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)[0]
	dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('hls: (.*?)_link\+"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for yVgLqfcUN1iO4,Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
		if 'backup' in yVgLqfcUN1iO4:
			yVgLqfcUN1iO4 = 'backup server'
			url = vv8ohbxsST1kQErnNuCjL + Y6YdkAMluFbwx
		else:
			yVgLqfcUN1iO4 = 'main server'
			url = WY2jCAw64QTREgqyeBxJDrIa9hNK + Y6YdkAMluFbwx
		if '.m3u8' in url:
			EZvlYsQbjWcCokaGdg.append(url)
			VVqcGEo5O2hxBYnfSHgbD.append('m3u8  '+yVgLqfcUN1iO4)
	dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	dsGzqX4k0a8RLyc += oo9kuULlebNgpY0Om.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for yVgLqfcUN1iO4,Y6YdkAMluFbwx in dsGzqX4k0a8RLyc:
		filename = Y6YdkAMluFbwx.split('/')[-1]
		filename = filename.replace('fallback',G9G0YqivIfmUWO8K)
		filename = filename.replace('.mp4',G9G0YqivIfmUWO8K)
		filename = filename.replace('-',G9G0YqivIfmUWO8K)
		if 'backup' in yVgLqfcUN1iO4:
			yVgLqfcUN1iO4 = 'backup server'
			url = vv8ohbxsST1kQErnNuCjL + Y6YdkAMluFbwx
		else:
			yVgLqfcUN1iO4 = 'main server'
			url = WY2jCAw64QTREgqyeBxJDrIa9hNK + Y6YdkAMluFbwx
		EZvlYsQbjWcCokaGdg.append(url)
		VVqcGEo5O2hxBYnfSHgbD.append('mp4  '+yVgLqfcUN1iO4+zVnkcBX6aJDPRpqyCjhoSZYQbL+filename)
	PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6('Select Video Quality:', VVqcGEo5O2hxBYnfSHgbD)
	if PXeEIRkdShOGm45lbLJc2B38s == -1 : return
	url = EZvlYsQbjWcCokaGdg[PXeEIRkdShOGm45lbLJc2B38s]
	Imphr8LRTUDs(url,s5slfAmHkUtMR3WSKY1ZTX,'video')
	return
def zzR2cwayn6V9vITEgspxLi3oZ(url,type):
	if 'series' in url: XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis + '/genre/مسلسل'
	else: XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis + '/genre/فيلم'
	XXzvmn7ewM8yBfoxua = SSX6oT0lADZhKRImPvCHFkYJs(XXzvmn7ewM8yBfoxua)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOOFMAX-FILTERS-1st')
	if type==1: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('subgenre(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	elif type==2: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('country(.*?)div',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('option value="(.*?)">(.*?)</option',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if type==1:
		for Tt5H31sVpjR,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url+'?subgenre='+Tt5H31sVpjR,58)
	elif type==2:
		url,Tt5H31sVpjR = url.split('?')
		for JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url+'?country='+JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA+'&'+Tt5H31sVpjR,51)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if not search: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'%20')
	url = ffVP3AK5RqhkgYnjZoNis+'/search?q='+HG9ZQqnw71y0JmrDLx
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,True,G9G0YqivIfmUWO8K,'SHOOFMAX-SEARCH-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('general-body(.*?)search-bottom-padding',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			url = ffVP3AK5RqhkgYnjZoNis + Y6YdkAMluFbwx
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+SSX6oT0lADZhKRImPvCHFkYJs(title)+'='+M4qkBDatEIf3T
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,52,M4qkBDatEIf3T)
				else:
					title = '_MOD_فيلم '+title
					Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,url,53,M4qkBDatEIf3T)
	return
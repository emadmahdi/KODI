# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'BOKRA'
TdtCLWYSJNK8zOb = '_BKR_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
headers = {'User-Agent':G9G0YqivIfmUWO8K}
tlcXBJEfIHF02vQ6yxSom9z1 = ['افلام للكبار','بكرا TV']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==370: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==371: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==372: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==374: tRojAyBgfDH37eLCwP4dWl = miNequbrZR(url)
	elif mode==375: tRojAyBgfDH37eLCwP4dWl = tLa0BZj9d1MJfecAuUG(url)
	elif mode==376: tRojAyBgfDH37eLCwP4dWl = wuWxHR0ynAlXMDCIQ3(0,url)
	elif mode==377: tRojAyBgfDH37eLCwP4dWl = wuWxHR0ynAlXMDCIQ3(1,url)
	elif mode==379: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-MENU-1st')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,379,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('right-side(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المميزة',ffVP3AK5RqhkgYnjZoNis,375)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الأحدث',ffVP3AK5RqhkgYnjZoNis,376)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'قائمة الممثلين',ffVP3AK5RqhkgYnjZoNis,374)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="container"(.*?)top-menu',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items[7:]:
			title = title.strip(ww0sZkBU9JKd)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371)
		for Y6YdkAMluFbwx,title in items[0:7]:
			title = title.strip(ww0sZkBU9JKd)
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371)
	return
def miNequbrZR(website=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-ACTORSMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="row cat Tags"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if 'http' in Y6YdkAMluFbwx: continue
			else: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371)
	return
def tLa0BZj9d1MJfecAuUG(website=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-FEATURED-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"MainContent"(.*?)main-title2',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				M4qkBDatEIf3T = M4qkBDatEIf3T.replace('://',':///').replace('//','/').replace(ww0sZkBU9JKd,'%20')
				Qm8SMu6ecXtigDCWw1oak('video',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,372,M4qkBDatEIf3T)
	return
def wuWxHR0ynAlXMDCIQ3(id,website=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-WATCHINGNOW-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-title2(.*?)class="row',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[id]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
				M4qkBDatEIf3T = M4qkBDatEIf3T.replace('://',':///').replace('//','/').replace(ww0sZkBU9JKd,'%20')
				Qm8SMu6ecXtigDCWw1oak('video',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,372,M4qkBDatEIf3T)
	return
def UUhwKBgI2nt(url,gcfGZbI9h5a=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'vidpage_' in url:
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('href="(/Album-.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx[0]
			UUhwKBgI2nt(Y6YdkAMluFbwx)
			return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class=" subcats"(.*?)class="col-md-3',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if gcfGZbI9h5a==G9G0YqivIfmUWO8K and cSLKDEATk7y10ovtGZCwF and cSLKDEATk7y10ovtGZCwF[0].count('href')>1:
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',url,371,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'titles')
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/'+Y6YdkAMluFbwx
			title = title.strip(ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371)
	else:
		ehHpxSUAZnVITs4y5XjDKb8zC = []
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="col-md-3(.*?)col-xs-12',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="col-sm-8"(.*?)col-xs-12',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
				title = title.strip(ww0sZkBU9JKd)
				M4qkBDatEIf3T = M4qkBDatEIf3T.replace('://',':///').replace('//','/').replace(ww0sZkBU9JKd,'%20')
				if '/al_' in Y6YdkAMluFbwx:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371,M4qkBDatEIf3T)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) - +الحلقة +\d+',title,oo9kuULlebNgpY0Om.DOTALL)
					if RnV3EqPNpXTDuI7: title = '_MOD_مسلسل '+RnV3EqPNpXTDuI7[0]
					if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
						ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
						Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371,M4qkBDatEIf3T)
				else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,372,M4qkBDatEIf3T)
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('class="".*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
				title = 'صفحة '+kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,371,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'titles')
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('label-success mrg-btm-5 ">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	XjWHSnbf6NwhMgpKt4yLY7AkIT = G9G0YqivIfmUWO8K
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('var url = "(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]
	else: XXzvmn7ewM8yBfoxua = url.replace('/vidpage_','/Play/')
	if 'http' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis+XXzvmn7ewM8yBfoxua
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.strip('-')
	D7omduSeM5Gk = PPRoOyl2xVH(PvAZ1fCRqL5F,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'BOKRA-PLAY-2nd')
	ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
	XjWHSnbf6NwhMgpKt4yLY7AkIT = oo9kuULlebNgpY0Om.findall('src="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
	if XjWHSnbf6NwhMgpKt4yLY7AkIT:
		XjWHSnbf6NwhMgpKt4yLY7AkIT = XjWHSnbf6NwhMgpKt4yLY7AkIT[-1]
		if 'http' not in XjWHSnbf6NwhMgpKt4yLY7AkIT: XjWHSnbf6NwhMgpKt4yLY7AkIT = 'http:'+XjWHSnbf6NwhMgpKt4yLY7AkIT
		if '/PLAY/' not in XXzvmn7ewM8yBfoxua:
			if 'embed.min.js' in XjWHSnbf6NwhMgpKt4yLY7AkIT:
				oz7gLUAM4lcxYmeTG3SHajJFtv = oo9kuULlebNgpY0Om.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
				if oz7gLUAM4lcxYmeTG3SHajJFtv:
					WZwedxy1CnmXjko57DgTp8bAEsaY, Lzs7y5dWKZH9pcO1o36ICv2Vjmg = oz7gLUAM4lcxYmeTG3SHajJFtv[0]
					XjWHSnbf6NwhMgpKt4yLY7AkIT = xWiOjcUrJVdtP4B5Iml(XjWHSnbf6NwhMgpKt4yLY7AkIT,'url')+'/v2/'+WZwedxy1CnmXjko57DgTp8bAEsaY+'/config/'+Lzs7y5dWKZH9pcO1o36ICv2Vjmg+'.json'
		import iOVAoxDJew
		iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk([XjWHSnbf6NwhMgpKt4yLY7AkIT],s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/Search/'+search
	UUhwKBgI2nt(url)
	return
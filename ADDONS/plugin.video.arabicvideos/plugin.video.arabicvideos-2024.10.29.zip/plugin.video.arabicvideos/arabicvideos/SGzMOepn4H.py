# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMA4U'
headers = {'User-Agent':G9G0YqivIfmUWO8K}
TdtCLWYSJNK8zOb = '_C4U_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==420: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==421: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==422: tRojAyBgfDH37eLCwP4dWl = dQo18YGKDWrfl(url)
	elif mode==423: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==424: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==427: tRojAyBgfDH37eLCwP4dWl = zAa59mqDfNJL76(url)
	elif mode==429: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = oo9kuULlebNgpY0Om.findall('href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	sg0IMYl698kyvmfVASQU4K13Z2L = sg0IMYl698kyvmfVASQU4K13Z2L[0].strip('/')
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(sg0IMYl698kyvmfVASQU4K13Z2L,'url')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,429,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',sg0IMYl698kyvmfVASQU4K13Z2L,425)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',sg0IMYl698kyvmfVASQU4K13Z2L,424)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'الرئيسية',sg0IMYl698kyvmfVASQU4K13Z2L,421)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('NavigationMenu(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="*(.*?)"*>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if '/actors' in Y6YdkAMluFbwx: title = 'أفلام النجوم'
		elif '/netflix' in Y6YdkAMluFbwx: title = 'أفلام ومسلسلات نيتفلكس'
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,421)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'قائمة تفصيلية',sg0IMYl698kyvmfVASQU4K13Z2L,427)
	return
def zAa59mqDfNJL76(website=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('FilteringTitle(.*?)PageTitle',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for nxguK9laUWBGHIR4zEsTo7,id,Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if 'netflix-movies' in Y6YdkAMluFbwx: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in Y6YdkAMluFbwx: title = 'مسلسلات نيتفلكس'
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,nxguK9laUWBGHIR4zEsTo7+'|'+id)
	return
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if not TDgxqHQoZd8v or '|' in TDgxqHQoZd8v:
		if '|' not in TDgxqHQoZd8v: hPCY5ygBKnvFNa = G9G0YqivIfmUWO8K
		else: hPCY5ygBKnvFNa = '/archive/'+TDgxqHQoZd8v
		KKuAjNF7ZWUGOw0abglrVTM2znxh3 = False
		if 'PinSlider' in GagwMT6q3oc7UZ2Q:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',url,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
			KKuAjNF7ZWUGOw0abglrVTM2znxh3 = True
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('PageTitle(.*?)PageContent',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			duYhmVFABjltoJ9PcE = cSLKDEATk7y10ovtGZCwF[0]
			qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('data-tab="(.*?)".*?<span>(.*?)<',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
			for sL68W4XT5PaKzodCVF0Alvp,GS7Y93B0b8TLxueF in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				z7GYBmKiXwreV2QybCNn80v9pT = sg0IMYl698kyvmfVASQU4K13Z2L+'/ajaxcenter/action/HomepageLoader/tab/'+sL68W4XT5PaKzodCVF0Alvp+hPCY5ygBKnvFNa+'/'
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+GS7Y93B0b8TLxueF,z7GYBmKiXwreV2QybCNn80v9pT,421)
				KKuAjNF7ZWUGOw0abglrVTM2znxh3 = True
		if KKuAjNF7ZWUGOw0abglrVTM2znxh3: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	if TDgxqHQoZd8v=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('PinSlider(.*?)MultiFilter',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('PinSlider(.*?)PageTitle',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		else: BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
	elif '/filter/' in url:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('PageContent(.*?)class="*pagination"*',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif '/actors' in url:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('PageContent(.*?)class="*pagination"*',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('Cima4uBlocks(.*?)</li></ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		else: BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	if not items: items = oo9kuULlebNgpY0Om.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: items = oo9kuULlebNgpY0Om.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if not title: continue
		if '?news=' in Y6YdkAMluFbwx: continue
		title = title.replace('مشاهدة ',G9G0YqivIfmUWO8K)
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) حلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if RnV3EqPNpXTDuI7 and 'حلقة' in title:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,422,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/actor/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,421,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,422,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF and TDgxqHQoZd8v!='featured':
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
			if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,421)
	R67d0jkqLyfChz1PV = oo9kuULlebNgpY0Om.findall('</li><a href="(.*?)".*?>(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if R67d0jkqLyfChz1PV:
		Y6YdkAMluFbwx,title = R67d0jkqLyfChz1PV[0]
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,421)
	return
def dQo18YGKDWrfl(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-SEASONS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="WatchNow".*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		url = cSLKDEATk7y10ovtGZCwF[0]
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-SEASONS-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('SeasonsSections(.*?)</div></div></div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if '/tag/' in url or '/actor' in url:
		UUhwKBgI2nt(url)
	elif cSLKDEATk7y10ovtGZCwF:
		M4qkBDatEIf3T = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Thumb')
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall("href='(.*?)'>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		JIK5h2ws4Cx1 = ['مسلسل','موسم','برنامج','حلقة']
		for Y6YdkAMluFbwx,title in items:
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in JIK5h2ws4Cx1):
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,423,M4qkBDatEIf3T)
			else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,426,M4qkBDatEIf3T)
	else: EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('"background-image:url\((.*?)\)',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T[0]
	else: M4qkBDatEIf3T = G9G0YqivIfmUWO8K
	veBnCIcRWyJi7Gg8tuOfNQswUq = oo9kuULlebNgpY0Om.findall('EpisodesSection(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if veBnCIcRWyJi7Gg8tuOfNQswUq:
		BN1KdkzCmvshw = veBnCIcRWyJi7Gg8tuOfNQswUq[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,RnV3EqPNpXTDuI7 in items:
			title = title+ww0sZkBU9JKd+RnV3EqPNpXTDuI7
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,426,M4qkBDatEIf3T)
	else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+'رابط التشغيل',url,426,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	x9EsB4hWjJ2SRvy = D7omduSeM5Gk.url
	if gA0m6CQUyfLG: x9EsB4hWjJ2SRvy = x9EsB4hWjJ2SRvy.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(x9EsB4hWjJ2SRvy,'url')
	ODnaR0N8UHv7Twy6jS = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('WatchSection(.*?)</div></div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-link="(.*?)".*? />(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if 'myvid' in title.lower(): title = 'خاص '+title
			Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/structure/server.php?id='+GDi7vOqwMjtbclE6ZPF4ofkxR2XQ0+'?named='+title+'__watch'
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('DownloadServers(.*?)</div></div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*? />(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if 'myvid' in title.lower(): GS7Y93B0b8TLxueF = '__خاص'
			else: GS7Y93B0b8TLxueF = G9G0YqivIfmUWO8K
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'+GS7Y93B0b8TLxueF
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/Search?q='+search
	UUhwKBgI2nt(url,'search')
	return
def RFEgei8ox2aIBLJDTzfswql(url):
	if 'smartemadfilter' not in url: url = xWiOjcUrJVdtP4B5Iml(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('MultiFilter(.*?)PageTitle',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	return FgGiXAn5NeaTHS0mZ
def X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw):
	items = oo9kuULlebNgpY0Om.findall('data-id="(.*?)".*?</div>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	return items
def JJyGN2OoV4BxbrPfCweuQ(url):
	LV6wHuJn8BiWZeyRkcI3sdXU = url.split('/smartemadfilter?')[0]
	NPlUQFruOmeD = xWiOjcUrJVdtP4B5Iml(url,'url')
	url = url.replace(LV6wHuJn8BiWZeyRkcI3sdXU,NPlUQFruOmeD)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
IzbOhN0Flo8j4gtdcVewMB = ['category','types','release-year']
KH5NQOvAkRje = ['Quality','release-year','types','category']
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global IzbOhN0Flo8j4gtdcVewMB
			IzbOhN0Flo8j4gtdcVewMB = IzbOhN0Flo8j4gtdcVewMB[1:]
		if IzbOhN0Flo8j4gtdcVewMB[0]+'=' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[0]
		for KT9tdUH3hmiLZCEFz in range(len(IzbOhN0Flo8j4gtdcVewMB[0:-1])):
			if IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz]+'=' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='ALL_ITEMS_FILTER':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		XXzvmn7ewM8yBfoxua = JJyGN2OoV4BxbrPfCweuQ(XXzvmn7ewM8yBfoxua)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',XXzvmn7ewM8yBfoxua,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filter')
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',XXzvmn7ewM8yBfoxua,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filter')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	FgGiXAn5NeaTHS0mZ = RFEgei8ox2aIBLJDTzfswql(url)
	dict = {}
	for name,BN1KdkzCmvshw,TaVcxgUOBpSwX6Rl9PYkzeudt1 in FgGiXAn5NeaTHS0mZ:
		if '/category/' in url and TaVcxgUOBpSwX6Rl9PYkzeudt1=='category': continue
		name = name.replace('--',G9G0YqivIfmUWO8K)
		items = X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw)
		if '=' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='SPECIFIED_FILTER':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<2:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]:
					url = JJyGN2OoV4BxbrPfCweuQ(url)
					UUhwKBgI2nt(url)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'SPECIFIED_FILTER___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				XXzvmn7ewM8yBfoxua = JJyGN2OoV4BxbrPfCweuQ(XXzvmn7ewM8yBfoxua)
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filter')
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,425,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='ALL_ITEMS_FILTER':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع :'+name,XXzvmn7ewM8yBfoxua,424,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			if yW70dtahIjkPCJg2TA=='196533': M0nQuWoaIxhSdqyV9N = 'أفلام نيتفلكس'
			elif yW70dtahIjkPCJg2TA=='196531': M0nQuWoaIxhSdqyV9N = 'مسلسلات نيتفلكس'
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = M0nQuWoaIxhSdqyV9N
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+M0nQuWoaIxhSdqyV9N
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			title = M0nQuWoaIxhSdqyV9N+' :'#+dict[TaVcxgUOBpSwX6Rl9PYkzeudt1]['0']
			title = M0nQuWoaIxhSdqyV9N+' :'+name
			if type=='ALL_ITEMS_FILTER': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,424,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='SPECIFIED_FILTER' and IzbOhN0Flo8j4gtdcVewMB[-2]+'=' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'modified_filters')
				XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				XjWHSnbf6NwhMgpKt4yLY7AkIT = JJyGN2OoV4BxbrPfCweuQ(XjWHSnbf6NwhMgpKt4yLY7AkIT)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,XjWHSnbf6NwhMgpKt4yLY7AkIT,421,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filter')
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,425,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.replace('=&','=0&')
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&')
	R9h6MqBxlsEpNztI0AU = {}
	if '=' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('=')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = G9G0YqivIfmUWO8K
	for key in KH5NQOvAkRje:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&')
	lOaCfpSNzejn = lOaCfpSNzejn.replace('=0','=')
	return lOaCfpSNzejn
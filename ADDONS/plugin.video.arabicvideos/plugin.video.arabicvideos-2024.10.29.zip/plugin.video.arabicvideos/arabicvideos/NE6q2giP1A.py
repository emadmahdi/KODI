# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'EGYBEST3'
TdtCLWYSJNK8zOb = '_EB3_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def RAndFk3y4Pbvs29(mode,url,eehFlSEjHioyAWpLqZXt79,text):
	if   mode==790: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==791: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==792: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==793: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==796: tRojAyBgfDH37eLCwP4dWl = HbfhT3tmkAPMJCENld672jGn(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==799: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('list-pages(.*?)fa-folder',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)</span>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-article(.*?)social-box',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('main-title.*?">(.*?)<.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for title,Y6YdkAMluFbwx in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791,G9G0YqivIfmUWO8K,'mainmenu')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-menu(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791)
	return GagwMT6q3oc7UZ2Q
def HbfhT3tmkAPMJCENld672jGn(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-SEASONS_EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-article".*?">(.*?)<(.*?)article',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		KmsdJXWHbDET9AankUCeMutfvQj,GOQI6tW4xVh8NYwdPqMD9Kg,items = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[]
		for name,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			if 'حلقات' in name: GOQI6tW4xVh8NYwdPqMD9Kg = BN1KdkzCmvshw
			if 'مواسم' in name: KmsdJXWHbDET9AankUCeMutfvQj = BN1KdkzCmvshw
		if KmsdJXWHbDET9AankUCeMutfvQj and not type:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',KmsdJXWHbDET9AankUCeMutfvQj,oo9kuULlebNgpY0Om.DOTALL)
			if len(items)>1:
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,796,M4qkBDatEIf3T,'season')
		if GOQI6tW4xVh8NYwdPqMD9Kg and len(items)<2:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',GOQI6tW4xVh8NYwdPqMD9Kg,oo9kuULlebNgpY0Om.DOTALL)
			if items:
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
					Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,793,M4qkBDatEIf3T)
			else:
				items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',GOQI6tW4xVh8NYwdPqMD9Kg,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,title in items:
					Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,793)
	return
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	wwCFVzNkHGQsoRYgpDhtL4qJ7dBP,start,hEDd8S3OLIugvAc5HRzQkTqM60wW,select,qLUBEJS0aNbFHk3hpcvW = 0,0,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if 'pagination' in type:
		Ab6uwEN8v4aYz5ImCrVGQl9yL,data = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
		wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = int(data['limit'])
		start = int(data['start'])
		hEDd8S3OLIugvAc5HRzQkTqM60wW = data['type']
		select = data['select']
		pPIbdY3oKe = 'limit='+str(wwCFVzNkHGQsoRYgpDhtL4qJ7dBP)+'&start='+str(start)+'&type='+hEDd8S3OLIugvAc5HRzQkTqM60wW+'&select='+select
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'Content-Type':'application/x-www-form-urlencoded'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',Ab6uwEN8v4aYz5ImCrVGQl9yL,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-TITLES-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = 'blocks'+GagwMT6q3oc7UZ2Q+'article'
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-TITLES-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = GagwMT6q3oc7UZ2Q
		code = oo9kuULlebNgpY0Om.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if code:
			code = code[0].replace('var',G9G0YqivIfmUWO8K).replace(ww0sZkBU9JKd,G9G0YqivIfmUWO8K).replace("'",G9G0YqivIfmUWO8K).replace(';','&')
			HHFwtdVPy2OZ,data = uNeAyo6mgQTwGtDFhfcU5ZasI('?'+code)
			wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = int(data['limit'])
			start = int(data['start'])
			hEDd8S3OLIugvAc5HRzQkTqM60wW = data['type']
			select = data['select']
			qLUBEJS0aNbFHk3hpcvW = data['ajaxurl']
			pPIbdY3oKe = 'limit='+str(wwCFVzNkHGQsoRYgpDhtL4qJ7dBP)+'&start='+str(start)+'&type='+hEDd8S3OLIugvAc5HRzQkTqM60wW+'&select='+select
			Ab6uwEN8v4aYz5ImCrVGQl9yL = ffVP3AK5RqhkgYnjZoNis+qLUBEJS0aNbFHk3hpcvW
			AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'Content-Type':'application/x-www-form-urlencoded'}
			D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',Ab6uwEN8v4aYz5ImCrVGQl9yL,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-TITLES-3rd')
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = 'blocks'+ssVw9GhqHbuQD5On3YxeKPWFkgjRJt+'article'
	items,FgXjbkoJlSm,IjPUNHfzpc0mvu2CsAhLOqQ = [],False,False
	if not type:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-content(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = title.strip(ww0sZkBU9JKd)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791,G9G0YqivIfmUWO8K,'submenu')
				FgXjbkoJlSm = True
	if not type:
		IjPUNHfzpc0mvu2CsAhLOqQ = zzR2cwayn6V9vITEgspxLi3oZ(GagwMT6q3oc7UZ2Q)
	if not FgXjbkoJlSm and not IjPUNHfzpc0mvu2CsAhLOqQ:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('blocks(.*?)article',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
				M4qkBDatEIf3T = M4qkBDatEIf3T.strip(zEgtT9cR6bFp7JXqI5VuhNeP)
				Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
				if '/selary/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791,M4qkBDatEIf3T)
				elif 'مسلسل' in Y6YdkAMluFbwx and 'حلقة' not in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,796,M4qkBDatEIf3T)
				elif 'موسم' in Y6YdkAMluFbwx and 'حلقة' not in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,796,M4qkBDatEIf3T)
				else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,793,M4qkBDatEIf3T)
		QkfP94eVT3g1tBlnsaSMyqCUKh6x = 12
		data = oo9kuULlebNgpY0Om.findall('class="(load-more.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)==QkfP94eVT3g1tBlnsaSMyqCUKh6x and (data or 'pagination' in type):
			pPIbdY3oKe = 'limit='+str(QkfP94eVT3g1tBlnsaSMyqCUKh6x)+'&start='+str(start+QkfP94eVT3g1tBlnsaSMyqCUKh6x)+'&type='+hEDd8S3OLIugvAc5HRzQkTqM60wW+'&select='+select
			XXzvmn7ewM8yBfoxua = Ab6uwEN8v4aYz5ImCrVGQl9yL+'?next=page&'+pPIbdY3oKe
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المزيد',XXzvmn7ewM8yBfoxua,791,G9G0YqivIfmUWO8K,'pagination_'+type)
	return
def zzR2cwayn6V9vITEgspxLi3oZ(GagwMT6q3oc7UZ2Q):
	IjPUNHfzpc0mvu2CsAhLOqQ = False
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-article(.*?)article',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if cUE5uH8hAtOmTp: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for nxguK9laUWBGHIR4zEsTo7,name,BN1KdkzCmvshw in cUE5uH8hAtOmTp:
			name = name.strip(ww0sZkBU9JKd)
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,yW70dtahIjkPCJg2TA in items:
				title = name+':  '+yW70dtahIjkPCJg2TA
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,791,G9G0YqivIfmUWO8K,'filter')
				IjPUNHfzpc0mvu2CsAhLOqQ = True
	return IjPUNHfzpc0mvu2CsAhLOqQ
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST3-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,Y3yumlhcKaj2RQUg = [],[]
	items = oo9kuULlebNgpY0Om.findall('server-item.*?data-code="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for dCFALseUGuwOfj0cSHt1vJ6 in items:
		yEUWIuPQL9zsmtMOriT3J1qjHDB = jaFsD83SB9ZQkrxeI.b64decode(dCFALseUGuwOfj0cSHt1vJ6)
		if LTze51miOknVcslNF43WSA6vMjYZt: yEUWIuPQL9zsmtMOriT3J1qjHDB = yEUWIuPQL9zsmtMOriT3J1qjHDB.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('src="(.*?)"',yEUWIuPQL9zsmtMOriT3J1qjHDB,oo9kuULlebNgpY0Om.DOTALL)
		if Y6YdkAMluFbwx:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
			if Y6YdkAMluFbwx not in Y3yumlhcKaj2RQUg:
				Y3yumlhcKaj2RQUg.append(Y6YdkAMluFbwx)
				yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__watch')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="downloads(.*?)</section>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx in items:
			if Y6YdkAMluFbwx not in Y3yumlhcKaj2RQUg:
				if '/?url=' in Y6YdkAMluFbwx: Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('/?url=')[1]
				Y3yumlhcKaj2RQUg.append(Y6YdkAMluFbwx)
				yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__download____'+I5chimw4D1okfxlBE2UpbuHJvStsZ)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(text):
	return
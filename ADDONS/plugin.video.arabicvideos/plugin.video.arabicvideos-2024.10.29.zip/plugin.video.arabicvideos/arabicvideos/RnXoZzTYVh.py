# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'FASELHD1'
headers = {'User-Agent':G9G0YqivIfmUWO8K}
TdtCLWYSJNK8zOb = '_FH1_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['جوائز الأوسكار','المراجعات','wwe']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==570: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==571: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==572: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==573: tRojAyBgfDH37eLCwP4dWl = HbfhT3tmkAPMJCENld672jGn(url,text)
	elif mode==576: tRojAyBgfDH37eLCwP4dWl = JhZaVTx7KMIjBc2fXRFCYDAyLOQ()
	elif mode==579: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+'لماذا الموقع بطيء',G9G0YqivIfmUWO8K,576)
	sg0IMYl698kyvmfVASQU4K13Z2L,url = ffVP3AK5RqhkgYnjZoNis,ffVP3AK5RqhkgYnjZoNis
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD1-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',sg0IMYl698kyvmfVASQU4K13Z2L,579,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',sg0IMYl698kyvmfVASQU4K13Z2L,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured1')
	items = oo9kuULlebNgpY0Om.findall('class="h3">(.*?)<.*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for title,Y6YdkAMluFbwx in items:
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details1')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"menu-primary"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		KVq2tMs6enifCThSZB = oo9kuULlebNgpY0Om.findall('<li (.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		kiDdMmwYato2y = [G9G0YqivIfmUWO8K,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		p0p6MxKbklodNCR92Wv = 0
		for hifDqHbzE39x5Jja7wsd8OeTvotYIB in KVq2tMs6enifCThSZB:
			if p0p6MxKbklodNCR92Wv>0: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',hifDqHbzE39x5Jja7wsd8OeTvotYIB,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
				if title==G9G0YqivIfmUWO8K: continue
				if any(yW70dtahIjkPCJg2TA in title.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
				title = kiDdMmwYato2y[p0p6MxKbklodNCR92Wv]+title
				Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details2')
			p0p6MxKbklodNCR92Wv += 1
	return
def JhZaVTx7KMIjBc2fXRFCYDAyLOQ():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD1-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('class="h4">(.*?)</div>(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not msFSK7j9MrcoPafDnkNO: return
	if type=='filters':
		cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"homeSlide"(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		L4TFi6QA2BmW,dsGzqX4k0a8RLyc,JoSpAl1HIVd0f = zip(*items)
		items = zip(dsGzqX4k0a8RLyc,L4TFi6QA2BmW,JoSpAl1HIVd0f)
	elif type=='featured2':
		title,BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif type=='details2' and len(msFSK7j9MrcoPafDnkNO)>1:
		title = msFSK7j9MrcoPafDnkNO[0][0]
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured2')
		title = msFSK7j9MrcoPafDnkNO[1][0]
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details3')
		return
	else:
		title,BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[-1]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if any(yW70dtahIjkPCJg2TA in title.lower() for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
		M4qkBDatEIf3T = zDBtm4MwIagkfcpE5oxJOAq6lZQY(M4qkBDatEIf3T)
		M4qkBDatEIf3T = M4qkBDatEIf3T.split('?resize=')[0]
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if '/collections/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,571,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and type==G9G0YqivIfmUWO8K:
			title = '_MOD_'+RnV3EqPNpXTDuI7[0][0]
			title = title.strip(' –')
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,573,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif 'episodes/' in Y6YdkAMluFbwx or 'movies/' in Y6YdkAMluFbwx or 'hindi/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,572,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,573,M4qkBDatEIf3T)
	if type=='filters':
		CoX5H3D7jVWGapxst = oo9kuULlebNgpY0Om.findall('"more_button_page":(.*?),',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if CoX5H3D7jVWGapxst:
			count = CoX5H3D7jVWGapxst[0]
			Y6YdkAMluFbwx = url+'/offset/'+count
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة أخرى',Y6YdkAMluFbwx,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'filters')
	elif 'details' in type:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("class='pagination(.*?)</div>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall("href='(.*?)'.*?>(.*?)<",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = 'صفحة '+kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,571,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'details4')
	return
def HbfhT3tmkAPMJCENld672jGn(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD1-SEASONS_EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	KmsdJXWHbDET9AankUCeMutfvQj = False
	if not type:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"seasonList"(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if len(items)>1:
				sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
				KmsdJXWHbDET9AankUCeMutfvQj = True
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,name,title in items:
					name = kD2wGe8Oh4T7Cj3BMsy0(name)
					if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
					title = name+' - '+title
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,573,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,'episodes')
	if type=='episodes' or not KmsdJXWHbDET9AankUCeMutfvQj:
		Vy1U0koJLPFhxe2TS = oo9kuULlebNgpY0Om.findall('"posterImg".*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if Vy1U0koJLPFhxe2TS: M4qkBDatEIf3T = Vy1U0koJLPFhxe2TS[0]
		else: M4qkBDatEIf3T = G9G0YqivIfmUWO8K
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"epAll"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = title.strip(ww0sZkBU9JKd)
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,572,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,eEOn6HTlmRa,EsHlvk9Zn2tIgU7KRLwGaNQbCcjB = [],[],[]
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FASELHD1-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	pwtcGBTPo7k3nqWmsFbxS = oo9kuULlebNgpY0Om.findall('مستوى المشاهدة.*?">(.*?)</span>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if pwtcGBTPo7k3nqWmsFbxS:
		UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('"tag">(.*?)</a>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"videoRow"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('&img=')[0]
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named=__embed')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="streamHeader(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall("href = '(.*?)'.*?</i>(.*?)</a>",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('&img=')[0]
			name = name.strip(ww0sZkBU9JKd)
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__watch')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="downloadLinks(.*?)blackwindow',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</span>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('&img=')[0]
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__download')
	for Fk9KTLaxOms6o84 in ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh:
		Y6YdkAMluFbwx,name = Fk9KTLaxOms6o84.split('?named')
		if Y6YdkAMluFbwx not in eEOn6HTlmRa:
			eEOn6HTlmRa.append(Y6YdkAMluFbwx)
			EsHlvk9Zn2tIgU7KRLwGaNQbCcjB.append(Fk9KTLaxOms6o84)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(EsHlvk9Zn2tIgU7KRLwGaNQbCcjB,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis+'/?s='+search
	UUhwKBgI2nt(XXzvmn7ewM8yBfoxua,'details5')
	return
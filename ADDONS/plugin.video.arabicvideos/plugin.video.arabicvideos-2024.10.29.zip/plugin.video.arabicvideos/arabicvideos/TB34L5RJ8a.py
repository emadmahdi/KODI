# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'LODYNET'
TdtCLWYSJNK8zOb = '_LDN_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الرئيسية','استفسارتكم و الطلبات']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==450: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==451: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==452: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==453: tRojAyBgfDH37eLCwP4dWl = dQo18YGKDWrfl(url)
	elif mode==454: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==459: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LODYNET-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(ffVP3AK5RqhkgYnjZoNis,'url')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,459,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مثبتات لودي نت',sg0IMYl698kyvmfVASQU4K13Z2L,451,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المضاف حديثا',sg0IMYl698kyvmfVASQU4K13Z2L,451,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'latest')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"MainMenu"(.*?)"SiteSlider"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if Y6YdkAMluFbwx=='#': continue
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,451)
	return
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K):
	items = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LODYNET-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if TDgxqHQoZd8v=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"SiteSlider"(.*?)"waves"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif TDgxqHQoZd8v=='latest':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"RecentPosts"(.*?)"pagination"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif '"ActorsList"' in GagwMT6q3oc7UZ2Q:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"ActorsList"(.*?)"text/javascript"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	elif TDgxqHQoZd8v in ['0','1','2']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"Section"(.*?)</li></ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[int(TDgxqHQoZd8v)]
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"BlocksArea"(.*?)"text/javascript"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not items: items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if '"ActorsList"' in GagwMT6q3oc7UZ2Q and 'src=' in M4qkBDatEIf3T:
			M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('src="(.*?)"',M4qkBDatEIf3T,oo9kuULlebNgpY0Om.DOTALL)
			M4qkBDatEIf3T = M4qkBDatEIf3T[0]
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) حلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if not RnV3EqPNpXTDuI7: RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if set(title.split()) & set(N78M4ZjFtLi0CvKDzTlmERSe9rc) and 'مسلسل' not in title:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,452,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'حلقة' in title:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,453,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,453,M4qkBDatEIf3T)
	if TDgxqHQoZd8v in [G9G0YqivIfmUWO8K,'latest']:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,451)
	return
def dQo18YGKDWrfl(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LODYNET-SEASONS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"CategorySubLinks"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp and 'href=' in str(kyoQ0h8lGBOW13cNvRqjDp):
		title = oo9kuULlebNgpY0Om.findall('<title>(.*?)-',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		title = title[0].strip(ww0sZkBU9JKd)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,454)
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,454)
	else: EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LODYNET-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"BlocksArea"(.*?)"text/javascript"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,452,M4qkBDatEIf3T)
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,454)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	XXzvmn7ewM8yBfoxua = url.replace('/movies/','/watch_movies/')
	XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua.replace('/episodes/','/watch_episodes/')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LODYNET-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(XXzvmn7ewM8yBfoxua,'url')
	ODnaR0N8UHv7Twy6jS = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"WatchTitle"(.*?)</aside>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-embed="(.*?)">(.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"DownloadLinks"(.*?)"selary"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)</span>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			name = kD2wGe8Oh4T7Cj3BMsy0(name)
			I5chimw4D1okfxlBE2UpbuHJvStsZ = oo9kuULlebNgpY0Om.findall('\d\d\d+',name,oo9kuULlebNgpY0Om.DOTALL)
			if I5chimw4D1okfxlBE2UpbuHJvStsZ:
				I5chimw4D1okfxlBE2UpbuHJvStsZ = '____'+I5chimw4D1okfxlBE2UpbuHJvStsZ[0]
				name = G9G0YqivIfmUWO8K
			else: I5chimw4D1okfxlBE2UpbuHJvStsZ = G9G0YqivIfmUWO8K
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__download'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search
	UUhwKBgI2nt(url)
	return
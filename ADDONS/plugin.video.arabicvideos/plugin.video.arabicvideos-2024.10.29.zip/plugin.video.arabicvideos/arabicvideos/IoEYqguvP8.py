# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'KATKOUTE'
TdtCLWYSJNK8zOb = '_KTK_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الصفحة الرئيسية','Sign in','الأقسام']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==670: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==671: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==672: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==673: tRojAyBgfDH37eLCwP4dWl = fNn6k23ORzwyBe14EbYSvZXxoAM(url,text)
	elif mode==674: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==679: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,679,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"navslide-divider"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,mode)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	items = cHghWIxRvzV2QD(ffVP3AK5RqhkgYnjZoNis+'/watch/browse.html')
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,674,M4qkBDatEIf3T)
	return
def cHghWIxRvzV2QD(url):
	PHNnGoTBQS1iLO5lKa = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','KATKOUTE','CATEGORIES')
	if PHNnGoTBQS1iLO5lKa: return PHNnGoTBQS1iLO5lKa
	PHNnGoTBQS1iLO5lKa = []
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-CATEGORIES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"category-header"(.*?)<footer>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		PHNnGoTBQS1iLO5lKa = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if PHNnGoTBQS1iLO5lKa: ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'KATKOUTE','CATEGORIES',PHNnGoTBQS1iLO5lKa,AH0BQ4LKlDMrfvqWmXn5)
	return PHNnGoTBQS1iLO5lKa
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"presentation"','</ul>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [(G9G0YqivIfmUWO8K,BN1KdkzCmvshw)]
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' فرز أو فلتر أو ترتيب '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for mX8PGEof4iCvtnYeT,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if mX8PGEof4iCvtnYeT: mX8PGEof4iCvtnYeT = mX8PGEof4iCvtnYeT+': '
			for Y6YdkAMluFbwx,title in items:
				title = mX8PGEof4iCvtnYeT+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,671)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"pm-category-subcats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)<30:
			Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			for Y6YdkAMluFbwx,title in items:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,671)
	if not kyoQ0h8lGBOW13cNvRqjDp and not msFSK7j9MrcoPafDnkNO: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	if A0AzrLupg8h1s=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-TITLES-1st')
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-TITLES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	BN1KdkzCmvshw,items = G9G0YqivIfmUWO8K,[]
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	if A0AzrLupg8h1s=='ajax-search':
		BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	elif A0AzrLupg8h1s=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pm-video-watch-featured"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_episodes':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if len(cSLKDEATk7y10ovtGZCwF)>1: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
	elif A0AzrLupg8h1s=='featured_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(data-echo=".*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if BN1KdkzCmvshw and not items: items = oo9kuULlebNgpY0Om.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: return
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,672,M4qkBDatEIf3T)
		elif A0AzrLupg8h1s=='new_episodes':
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,672,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,673,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/movseries/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,671,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,673,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if Y6YdkAMluFbwx=='#': continue
			if 'http' not in Y6YdkAMluFbwx:
				XXzvmn7ewM8yBfoxua = url.rsplit('/',1)[0]
				Y6YdkAMluFbwx = XXzvmn7ewM8yBfoxua+'/'+Y6YdkAMluFbwx.strip('/')
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,671,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,A0AzrLupg8h1s)
	return
def fNn6k23ORzwyBe14EbYSvZXxoAM(url,JlwhosfkrT):
	Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+'تشغيل الفيديو',url,672)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	PHNnGoTBQS1iLO5lKa = cHghWIxRvzV2QD(ffVP3AK5RqhkgYnjZoNis+'/watch/browse.html')
	tH3pFmvLfRWB9GAT1OyVslMb,tVdJXfH2UR7MNs9,lTOmWJeGNP60z8Y9Ciqj43c = zip(*PHNnGoTBQS1iLO5lKa)
	Ttw2B0EyIJf = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-video-heading"(.*?)id="player"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in dsGzqX4k0a8RLyc:
			if Y6YdkAMluFbwx not in tH3pFmvLfRWB9GAT1OyVslMb:
				XX2Btn97vEfkCjcuWs = (Y6YdkAMluFbwx,title)
				Ttw2B0EyIJf.append(XX2Btn97vEfkCjcuWs)
		if len(Ttw2B0EyIJf)==1:
			Y6YdkAMluFbwx,title = Ttw2B0EyIJf[0]
			UUhwKBgI2nt(Y6YdkAMluFbwx,'new_episodes')
			return
		else:
			for Y6YdkAMluFbwx,title in Ttw2B0EyIJf:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,671,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'new_episodes')
	if not Ttw2B0EyIJf: UUhwKBgI2nt(url,'new_episodes')
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'KATKOUTE-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('sources:(.*?)flashplayer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('file: "(.*?)".*?label: "(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,I5chimw4D1okfxlBE2UpbuHJvStsZ in dsGzqX4k0a8RLyc:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named=__watch__'+I5chimw4D1okfxlBE2UpbuHJvStsZ
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('"embedded-video".*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not dsGzqX4k0a8RLyc: dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall("file: '(.*?)'",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if dsGzqX4k0a8RLyc:
		Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[0]
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named=__embed')
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/watch/search.php?keywords='+search
	UUhwKBgI2nt(url,'search')
	return
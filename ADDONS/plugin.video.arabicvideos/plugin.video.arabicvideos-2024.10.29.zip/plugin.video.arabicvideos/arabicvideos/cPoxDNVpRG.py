# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMAABDO'
TdtCLWYSJNK8zOb = '_ABD_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الرئيسية']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==550: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==551: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==552: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==553: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==559: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis+'/home',G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(ffVP3AK5RqhkgYnjZoNis,'url')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,559,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'اخترنا لك',sg0IMYl698kyvmfVASQU4K13Z2L+'/home',551,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-content(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('data-name="(.*?)".*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for TDgxqHQoZd8v,title in items:
		Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/ajax/getItem?item='+TDgxqHQoZd8v+'&Ajax=1'
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,551)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"nav-main"(.*?)</nav>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if Y6YdkAMluFbwx=='#': continue
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,551)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	for Y6YdkAMluFbwx,title in items:
		if Y6YdkAMluFbwx=='#': continue
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,551)
	return
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(url)
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-TITLES-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cSLKDEATk7y10ovtGZCwF = [GagwMT6q3oc7UZ2Q]
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-TITLES-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		if TDgxqHQoZd8v=='featured':
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"container"(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		elif '"section-post mb-10"' in GagwMT6q3oc7UZ2Q:
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"section-post mb-10"(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		else:
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<article(.*?)"pagination"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not items:
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not items: items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if 'سلاسل' not in url and any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,552,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'الحلقة' in title:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,553,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/movies/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,551,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,553,M4qkBDatEIf3T)
	if TDgxqHQoZd8v==G9G0YqivIfmUWO8K:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)<footer',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=="": continue
				if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'هناك المزيد',url,551)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"getSeasonsBySeries(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"list-episodes"(.*?)"container"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp and '/series/' not in url:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,553,M4qkBDatEIf3T)
	elif msFSK7j9MrcoPafDnkNO:
		M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('"image" src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		M4qkBDatEIf3T = M4qkBDatEIf3T[0]
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,552,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	XjWHSnbf6NwhMgpKt4yLY7AkIT = url.replace('/movies/','/watch_movies/')
	XjWHSnbf6NwhMgpKt4yLY7AkIT = XjWHSnbf6NwhMgpKt4yLY7AkIT.replace('/episodes/','/watch_episodes/')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(XjWHSnbf6NwhMgpKt4yLY7AkIT,'url')
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('''<iframe.*?src=["'](.*?)["']''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'url')
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__embed')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"servers"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		HGD02clisfMEkyYwX5PRebUnAu = oo9kuULlebNgpY0Om.findall('postID = "(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		HGD02clisfMEkyYwX5PRebUnAu = HGD02clisfMEkyYwX5PRebUnAu[0]
		items = oo9kuULlebNgpY0Om.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for yVgLqfcUN1iO4,title in items:
				title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/ajax/getPlayer?server='+yVgLqfcUN1iO4+'&postID='+HGD02clisfMEkyYwX5PRebUnAu+'&Ajax=1'
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
		else:
			items = oo9kuULlebNgpY0Om.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if items:
				yVgLqfcUN1iO4,nsoYXeIQRNxk2,title = items[0]
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/ajax/getPlayerByName?server='+yVgLqfcUN1iO4+'&multipleServers='+nsoYXeIQRNxk2+'&postID='+HGD02clisfMEkyYwX5PRebUnAu+'&Ajax=1'
				XXzvmn7ewM8yBfoxua,pPIbdY3oKe = uNeAyo6mgQTwGtDFhfcU5ZasI(Y6YdkAMluFbwx)
				AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',XXzvmn7ewM8yBfoxua,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-PLAY-2nd')
				GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
				CgEYJzhcIf6 = oo9kuULlebNgpY0Om.findall('''<iframe src=["'](.*?)["']''',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
				z7GYBmKiXwreV2QybCNn80v9pT = CgEYJzhcIf6[0] if CgEYJzhcIf6 else G9G0YqivIfmUWO8K
				if '/iframe/' in z7GYBmKiXwreV2QybCNn80v9pT:
					D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',z7GYBmKiXwreV2QybCNn80v9pT,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-PLAY-3rd')
					GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
					s0w9zT6IfXdbxaCtAR5EOHNiWBc = oo9kuULlebNgpY0Om.findall('version&quot;:&quot;(.*?)&',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
					s0w9zT6IfXdbxaCtAR5EOHNiWBc = s0w9zT6IfXdbxaCtAR5EOHNiWBc[0]
					AAFEPhnMlsH5B3z0gYQWD4j7kUc = {}
					AAFEPhnMlsH5B3z0gYQWD4j7kUc['X-Inertia-Partial-Component'] = 'files/mirror/video'
					AAFEPhnMlsH5B3z0gYQWD4j7kUc['X-Inertia'] = 'true'
					AAFEPhnMlsH5B3z0gYQWD4j7kUc['X-Inertia-Partial-Data'] = 'streams'
					AAFEPhnMlsH5B3z0gYQWD4j7kUc['X-Inertia-Version'] = s0w9zT6IfXdbxaCtAR5EOHNiWBc
					D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',z7GYBmKiXwreV2QybCNn80v9pT,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMAABDO-PLAY-4th')
					GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
					x3FCtTDvkpWQBgmji = bRCSwcA89e4J7pqdays5PxGiD2('dict',GagwMT6q3oc7UZ2Q)
					groups = x3FCtTDvkpWQBgmji['props']['streams']['data']
					for group in groups:
						I5chimw4D1okfxlBE2UpbuHJvStsZ = group['label'].replace(' (source)',G9G0YqivIfmUWO8K)
						obJv0A8CuOm23eT = group['mirrors']
						for OlhA39RVkZL4K85fIwuXxbdDG in obJv0A8CuOm23eT:
							yVgLqfcUN1iO4 = OlhA39RVkZL4K85fIwuXxbdDG['driver']
							Y6YdkAMluFbwx = 'http:'+OlhA39RVkZL4K85fIwuXxbdDG['link']+'?named='+yVgLqfcUN1iO4+'__watch____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
							ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"downs"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,name in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+name+'__download'
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = 'http:'+Y6YdkAMluFbwx
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'-')
	url = ffVP3AK5RqhkgYnjZoNis+'/search/'+search+'.html'
	UUhwKBgI2nt(url)
	return
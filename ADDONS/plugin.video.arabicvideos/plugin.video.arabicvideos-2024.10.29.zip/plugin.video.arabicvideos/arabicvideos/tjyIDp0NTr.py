# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SERIES4WATCH'
headers = { 'User-Agent' : G9G0YqivIfmUWO8K }
TdtCLWYSJNK8zOb = '_SFW_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==210: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==211: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url)
	elif mode==212: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==213: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==214: tRojAyBgfDH37eLCwP4dWl = yPtbYSsGIarlUA6BQdL(url)
	elif mode==215: tRojAyBgfDH37eLCwP4dWl = fZjXQ7oAYEux6L8tJDl2gK5r(url)
	elif mode==218: tRojAyBgfDH37eLCwP4dWl = E0wRI9B58K1WGAMxhL()
	elif mode==219: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def E0wRI9B58K1WGAMxhL():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,219,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	url = ffVP3AK5RqhkgYnjZoNis+'/getpostsPin?type=one&data=pin&limit=25'
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المميزة',url,211)
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-MENU-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('FiltersButtons(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('data-get="(.*?)".*?</i>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		url = ffVP3AK5RqhkgYnjZoNis+'/getposts?type=one&data='+Y6YdkAMluFbwx
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,url,211)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('navigation-menu(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(http.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	tlcXBJEfIHF02vQ6yxSom9z1 = ['مسلسلات انمي','الرئيسية']
	for Y6YdkAMluFbwx,title in items:
		title = title.strip(ww0sZkBU9JKd)
		if not any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1):
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,211)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url):
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('MediaGrid"(.*?)class="pagination"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		else: return
	items = oo9kuULlebNgpY0Om.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	vvWOPDzyKX09YaRfmhVH7UdiBS = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		if '/series/' in Y6YdkAMluFbwx: continue
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		title = title.strip(ww0sZkBU9JKd)
		if '/film/' in Y6YdkAMluFbwx or any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in vvWOPDzyKX09YaRfmhVH7UdiBS):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,212,M4qkBDatEIf3T)
		elif '/episode/' in Y6YdkAMluFbwx and 'الحلقة' in title:
			RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
			if RnV3EqPNpXTDuI7:
				title = '_MOD_' + RnV3EqPNpXTDuI7[0]
				if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,213,M4qkBDatEIf3T)
					ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,213,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="pagination(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = kD2wGe8Oh4T7Cj3BMsy0(Y6YdkAMluFbwx)
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
			if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,211)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	dCHEukZBcqWgfRhmK,items,hdmcLJ2WMbZ4ASgOGP80s = -1,[],[]
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(TTm2opnt9fLX8DBYizbuSPvwhJZCl,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-EPISODES-1st')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('ti-list-numbered(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		cUE5uH8hAtOmTp = G9G0YqivIfmUWO8K.join(cSLKDEATk7y10ovtGZCwF)
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)"',cUE5uH8hAtOmTp,oo9kuULlebNgpY0Om.DOTALL)
	items.append(url)
	items = set(items)
	for Y6YdkAMluFbwx in items:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx.strip('/')
		title = '_MOD_' + Y6YdkAMluFbwx.split('/')[-1].replace('-',ww0sZkBU9JKd)
		zzp23C7fBiwrLHhdYt9a = oo9kuULlebNgpY0Om.findall('الحلقة-(\d+)',Y6YdkAMluFbwx.split('/')[-1],oo9kuULlebNgpY0Om.DOTALL)
		if zzp23C7fBiwrLHhdYt9a: zzp23C7fBiwrLHhdYt9a = zzp23C7fBiwrLHhdYt9a[0]
		else: zzp23C7fBiwrLHhdYt9a = '0'
		hdmcLJ2WMbZ4ASgOGP80s.append([Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a])
	items = sorted(hdmcLJ2WMbZ4ASgOGP80s, reverse=False, key=lambda key: int(key[2]))
	IIvy3KOMdQG2xpUmb6eESPXlCuR7qw = str(items).count('/season/')
	dCHEukZBcqWgfRhmK = str(items).count('/episode/')
	if IIvy3KOMdQG2xpUmb6eESPXlCuR7qw>1 and dCHEukZBcqWgfRhmK>0 and '/season/' not in url:
		for Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a in items:
			if '/season/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,213)
	else:
		for Y6YdkAMluFbwx,title,zzp23C7fBiwrLHhdYt9a in items:
			if '/season/' not in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,212)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS = []
	mtMexSFLnkwhbAaP9pgDduCRBi2 = url.split('/')
	GagwMT6q3oc7UZ2Q = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in GagwMT6q3oc7UZ2Q:
		XXzvmn7ewM8yBfoxua = url.replace(mtMexSFLnkwhbAaP9pgDduCRBi2[3],'watch')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-PLAY-2nd')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="servers-list(.*?)</div>',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if items:
				id = oo9kuULlebNgpY0Om.findall('post_id=(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
				if id:
					TJMXlg4jb6GzS5ew = id[0]
					for Y6YdkAMluFbwx,title in items:
						Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/?postid='+TJMXlg4jb6GzS5ew+'&serverid='+Y6YdkAMluFbwx+'?named='+title+'__watch'
						ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
			else:
				items = oo9kuULlebNgpY0Om.findall('data-embedd=".*?(http.*?)("|&quot;)',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,HHFwtdVPy2OZ in items:
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if '/download/' in GagwMT6q3oc7UZ2Q:
		XXzvmn7ewM8yBfoxua = url.replace(mtMexSFLnkwhbAaP9pgDduCRBi2[3],'download')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,'SERIES4WATCH-PLAY-3rd')
		id = oo9kuULlebNgpY0Om.findall('postId:"(.*?)"',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if id:
			TJMXlg4jb6GzS5ew = id[0]
			AAFEPhnMlsH5B3z0gYQWD4j7kUc = { 'User-Agent':G9G0YqivIfmUWO8K , 'X-Requested-With':'XMLHttpRequest' }
			XXzvmn7ewM8yBfoxua = ffVP3AK5RqhkgYnjZoNis + '/ajaxCenter?_action=getdownloadlinks&postId='+TJMXlg4jb6GzS5ew
			ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = ccdVMC96FlRTykuaExOWzmXQ(AH0BQ4LKlDMrfvqWmXn5,XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,'SERIES4WATCH-PLAY-4th')
			cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<h3.*?(\d+)(.*?)</div>',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
			if cSLKDEATk7y10ovtGZCwF:
				for bbo3lEYsnfHcpRAxO,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
					items = oo9kuULlebNgpY0Om.findall('<td>(.*?)<.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
					for name,Y6YdkAMluFbwx in items:
						ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx+'?named='+name+'__download'+'____'+bbo3lEYsnfHcpRAxO)
			else:
				cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('<h6(.*?)</table>',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
				if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [ssVw9GhqHbuQD5On3YxeKPWFkgjRJt]
				for BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
					name = G9G0YqivIfmUWO8K
					items = oo9kuULlebNgpY0Om.findall('href="(http.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
					for Y6YdkAMluFbwx in items:
						yVgLqfcUN1iO4 = '&&' + Y6YdkAMluFbwx.split('/')[2].lower() + '&&'
						yVgLqfcUN1iO4 = yVgLqfcUN1iO4.replace('.com&&',G9G0YqivIfmUWO8K).replace('.co&&',G9G0YqivIfmUWO8K)
						yVgLqfcUN1iO4 = yVgLqfcUN1iO4.replace('.net&&',G9G0YqivIfmUWO8K).replace('.org&&',G9G0YqivIfmUWO8K)
						yVgLqfcUN1iO4 = yVgLqfcUN1iO4.replace('.live&&',G9G0YqivIfmUWO8K).replace('.online&&',G9G0YqivIfmUWO8K)
						yVgLqfcUN1iO4 = yVgLqfcUN1iO4.replace('&&hd.',G9G0YqivIfmUWO8K).replace('&&www.',G9G0YqivIfmUWO8K)
						yVgLqfcUN1iO4 = yVgLqfcUN1iO4.replace('&&',G9G0YqivIfmUWO8K)
						Y6YdkAMluFbwx = Y6YdkAMluFbwx + '?named=' + name + yVgLqfcUN1iO4 + '__download'
						ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis + '/search?s='+search
	UUhwKBgI2nt(url)
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'FABRAKA'
TdtCLWYSJNK8zOb = '_FBK_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الصفحة الرئيسية','Sign in']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==620: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==621: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==622: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==623: tRojAyBgfDH37eLCwP4dWl = fNn6k23ORzwyBe14EbYSvZXxoAM(url,text)
	elif mode==624: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==629: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	sg0IMYl698kyvmfVASQU4K13Z2L,url,D7omduSeM5Gk = P8mV07Q3n4xcsfiOe(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',ffVP3AK5RqhkgYnjZoNis,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,629,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الحلقات',sg0IMYl698kyvmfVASQU4K13Z2L,621,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'new_episodes')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الأفلام',sg0IMYl698kyvmfVASQU4K13Z2L,621,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'new_movies')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المسلسلات المميزة',sg0IMYl698kyvmfVASQU4K13Z2L,621,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured_series')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"navslide-wrap"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'موقع فبركة','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,624)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('/category.php">(.*?)"navslide-divider"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall("'dropdown-menu'(.*?)</ul>",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	for duYhmVFABjltoJ9PcE in cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = BN1KdkzCmvshw.replace(duYhmVFABjltoJ9PcE,G9G0YqivIfmUWO8K)
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,624)
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FABRAKA-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"presentation"','</ul>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [(G9G0YqivIfmUWO8K,BN1KdkzCmvshw)]
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' فرز أو فلتر أو ترتيب '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for mX8PGEof4iCvtnYeT,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if mX8PGEof4iCvtnYeT: mX8PGEof4iCvtnYeT = mX8PGEof4iCvtnYeT+': '
			for Y6YdkAMluFbwx,title in items:
				title = mX8PGEof4iCvtnYeT+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,621)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"pm-category-subcats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(items)<30:
			Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			for Y6YdkAMluFbwx,title in items:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,621)
	if not kyoQ0h8lGBOW13cNvRqjDp and not msFSK7j9MrcoPafDnkNO: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	if A0AzrLupg8h1s=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FABRAKA-TITLES-1st')
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FABRAKA-TITLES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	BN1KdkzCmvshw,items = G9G0YqivIfmUWO8K,[]
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	if A0AzrLupg8h1s=='ajax-search':
		BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	elif A0AzrLupg8h1s=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pm-video-watch-featured"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_episodes':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if len(cSLKDEATk7y10ovtGZCwF)>1: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
	elif A0AzrLupg8h1s=='featured_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(data-echo=".*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if BN1KdkzCmvshw and not items: items = oo9kuULlebNgpY0Om.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: return
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,622,M4qkBDatEIf3T)
		elif A0AzrLupg8h1s=='new_episodes':
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,622,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,623,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,623,M4qkBDatEIf3T)
	if 1:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,621)
	return
def fNn6k23ORzwyBe14EbYSvZXxoAM(url,JlwhosfkrT):
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FABRAKA-EPISODES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	Vy1U0koJLPFhxe2TS = oo9kuULlebNgpY0Om.findall('"series-header".*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Vy1U0koJLPFhxe2TS: M4qkBDatEIf3T = Vy1U0koJLPFhxe2TS[0]
	else: M4qkBDatEIf3T = G9G0YqivIfmUWO8K
	items = []
	nfs7kxySvpQHP = False
	if kyoQ0h8lGBOW13cNvRqjDp and not JlwhosfkrT:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for JlwhosfkrT,title in items:
			JlwhosfkrT = JlwhosfkrT.strip('#')
			if len(items)>1: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,623,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,JlwhosfkrT)
			else: nfs7kxySvpQHP = True
	else: nfs7kxySvpQHP = True
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('id="'+JlwhosfkrT+'"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO and nfs7kxySvpQHP:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('''href=['"](.*?)['"]><li><em>(.*?)</span>''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		items = []
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((Y6YdkAMluFbwx,title,M4qkBDatEIf3T))
		if not items: items = oo9kuULlebNgpY0Om.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title,M4qkBDatEIf3T in items:
			Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
			title = title.replace('</em><span>',ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,622,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = []
	url = url.replace('watch.php','see.php')
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'FABRAKA-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"WatchList"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('<iframe src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]+'?named='+title+'__embed'
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"downloadlist"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'
			ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?keywords='+search
	sg0IMYl698kyvmfVASQU4K13Z2L,XXzvmn7ewM8yBfoxua,WvxUIHz0cMJB = P8mV07Q3n4xcsfiOe(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',url,'fabraka','فبركة azureedge.net','كافة الحقوق محفوظة')
	UUhwKBgI2nt(XXzvmn7ewM8yBfoxua,'search')
	return
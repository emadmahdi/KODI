# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'CIMACLUP'
TdtCLWYSJNK8zOb = '_CMC_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['موقع نتفليكس']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==490: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==491: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==492: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==493: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==494: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==499: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text,url)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = oo9kuULlebNgpY0Om.findall('href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	sg0IMYl698kyvmfVASQU4K13Z2L = sg0IMYl698kyvmfVASQU4K13Z2L[0].strip('/')
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(sg0IMYl698kyvmfVASQU4K13Z2L,'url')
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"filter AjaxifyFilter"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('data-filter="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/wp-content/themes/old/filter/'+Y6YdkAMluFbwx+'.php'
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,491)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'أفلام',sg0IMYl698kyvmfVASQU4K13Z2L+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'مسلسلات',sg0IMYl698kyvmfVASQU4K13Z2L+'/category/مسلسلات/مسلسلات-اجنبى',494,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="navigation-menu"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if Y6YdkAMluFbwx=='/': continue
		if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,491)
	return GagwMT6q3oc7UZ2Q
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"filter"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,491)
	return
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K):
	items = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	BN1KdkzCmvshw = G9G0YqivIfmUWO8K
	if '.php' in url: BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
	elif '?s=' in url:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"blocks(.*?)"manifest"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"Blocks(.*?)"manifest"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not BN1KdkzCmvshw: return
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) حلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if not RnV3EqPNpXTDuI7: RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if not RnV3EqPNpXTDuI7 or any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,492,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'حلقة' in title:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,493,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,493,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<li><a href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
			if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,491)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	XXzvmn7ewM8yBfoxua = oo9kuULlebNgpY0Om.findall('"ButtonsBarCo".*?href="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if XXzvmn7ewM8yBfoxua:
		XXzvmn7ewM8yBfoxua = XXzvmn7ewM8yBfoxua[0]
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-EPISODES-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	M4qkBDatEIf3T = oo9kuULlebNgpY0Om.findall('"img-responsive" src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if M4qkBDatEIf3T: M4qkBDatEIf3T = M4qkBDatEIf3T[0]
	else: M4qkBDatEIf3T = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel('ListItem.Thumb')
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"filter"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"Blocks(.*?)class="pagination"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp and '/series/' not in url:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,493,M4qkBDatEIf3T)
	elif msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if items:
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
				title = title.strip(ww0sZkBU9JKd)
				Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,492,M4qkBDatEIf3T)
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				title = title.replace('الصفحة ',G9G0YqivIfmUWO8K)
				if title!=G9G0YqivIfmUWO8K: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,491)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	XXzvmn7ewM8yBfoxua = url.strip('/')+'/?view=1'
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'CIMACLUP-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	ODnaR0N8UHv7Twy6jS = []
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	GMEihFzYkDN9R = oo9kuULlebNgpY0Om.findall("data: 'q=(.*?)&",GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	GMEihFzYkDN9R = GMEihFzYkDN9R[0]
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"serversList"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('data-server="(.*?)">(.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for kV0iYd9H3usaDtmUneF51S8bNfx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/wp-content/themes/old/servers/server.php?q='+GMEihFzYkDN9R+'&i='+kV0iYd9H3usaDtmUneF51S8bNfx+'?named='+title+'__watch'
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('"embedServer".*?SRC="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		title = 'مفضل'
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0]+'?named=__embed__'+title
		ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"downloadsList"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<td>(.*?)</td>.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for title,Y6YdkAMluFbwx in items:
			title = title.strip(ww0sZkBU9JKd)
			if 'anavidz' in Y6YdkAMluFbwx: GS7Y93B0b8TLxueF = '__خاص'
			else: GS7Y93B0b8TLxueF = G9G0YqivIfmUWO8K
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'+GS7Y93B0b8TLxueF
			ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search,sg0IMYl698kyvmfVASQU4K13Z2L=G9G0YqivIfmUWO8K):
	if not sg0IMYl698kyvmfVASQU4K13Z2L: sg0IMYl698kyvmfVASQU4K13Z2L = ffVP3AK5RqhkgYnjZoNis
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = sg0IMYl698kyvmfVASQU4K13Z2L+'/index.php?s='+search
	UUhwKBgI2nt(url)
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SHAHID4U'
TdtCLWYSJNK8zOb = '_SH4_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
headers = {'User-Agent':uCUkPIYFszbV90wSpKqWNOjZ1687Eh(True)}
tlcXBJEfIHF02vQ6yxSom9z1 = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==110: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==111: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==112: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==113: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url,True)
	elif mode==114: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'FULL_FILTER___'+text)
	elif mode==115: tRojAyBgfDH37eLCwP4dWl = nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,'DEFINED_FILTER___'+text)
	elif mode==116: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url,False)
	elif mode==119: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(D7omduSeM5Gk.url,'url')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,119,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر محدد',sg0IMYl698kyvmfVASQU4K13Z2L,115)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر كامل',sg0IMYl698kyvmfVASQU4K13Z2L,114)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'المميزة',sg0IMYl698kyvmfVASQU4K13Z2L,111,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('simple-filter(.*?)adv-filter',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for filter,M4qkBDatEIf3T,title in items:
			url = sg0IMYl698kyvmfVASQU4K13Z2L+filter
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,url,111,M4qkBDatEIf3T,G9G0YqivIfmUWO8K,filter)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="dropdown"(.*?)<script>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
			if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
			if 'netflix' in Y6YdkAMluFbwx: title = 'نيتفلكس'
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,111)
	return GagwMT6q3oc7UZ2Q
def UUhwKBgI2nt(url,TDgxqHQoZd8v=G9G0YqivIfmUWO8K,D7omduSeM5Gk=G9G0YqivIfmUWO8K):
	if not D7omduSeM5Gk: D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF,items,ehHpxSUAZnVITs4y5XjDKb8zC = [],[],[]
	if TDgxqHQoZd8v=='featured': cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('glide__slides(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	else: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('shows-container(.*?)pagination',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if not items: items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
		if 'WWE' in title: continue
		if 'javascript' in Y6YdkAMluFbwx: continue
		Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx).strip('/')
		title = kD2wGe8Oh4T7Cj3BMsy0(title)
		title = title.strip(ww0sZkBU9JKd)
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) الحلقة \d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if '/film/' in Y6YdkAMluFbwx or 'فيلم' in Y6YdkAMluFbwx or any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,112,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7 and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,113,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		elif '/actor/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,111,M4qkBDatEIf3T)
		elif '/series/' in Y6YdkAMluFbwx and '/list' not in url:
			Y6YdkAMluFbwx = Y6YdkAMluFbwx+'/list'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,111,M4qkBDatEIf3T)
		elif '/list' in url and 'حلقة' in title:
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,112,M4qkBDatEIf3T)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,113,M4qkBDatEIf3T)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		if TDgxqHQoZd8v!='search': items = oo9kuULlebNgpY0Om.findall('(updateQuery).*?>(.+?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		else: items = oo9kuULlebNgpY0Om.findall('<li>.*?href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for Y6YdkAMluFbwx,title in items:
			title = title.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).replace(fXE2iwNYcD,G9G0YqivIfmUWO8K)
			title = title.strip(ww0sZkBU9JKd)
			if TDgxqHQoZd8v!='search':
				if '?' in url: Y6YdkAMluFbwx = url+'&page='+title
				else: Y6YdkAMluFbwx = url+'?page='+title
			title = kD2wGe8Oh4T7Cj3BMsy0(title)
			if title: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,111,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,TDgxqHQoZd8v)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url,HZGOjy8dgXs):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('items d-flex(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if len(cSLKDEATk7y10ovtGZCwF)>1:
		if '/season/' in cSLKDEATk7y10ovtGZCwF[0]: KmsdJXWHbDET9AankUCeMutfvQj,GOQI6tW4xVh8NYwdPqMD9Kg = cSLKDEATk7y10ovtGZCwF[0],cSLKDEATk7y10ovtGZCwF[1]
		else: KmsdJXWHbDET9AankUCeMutfvQj,GOQI6tW4xVh8NYwdPqMD9Kg = cSLKDEATk7y10ovtGZCwF[1],cSLKDEATk7y10ovtGZCwF[0]
	else: KmsdJXWHbDET9AankUCeMutfvQj,GOQI6tW4xVh8NYwdPqMD9Kg = cSLKDEATk7y10ovtGZCwF[0],cSLKDEATk7y10ovtGZCwF[0]
	for p0p6MxKbklodNCR92Wv in range(2):
		if HZGOjy8dgXs: mode,type,BN1KdkzCmvshw = 116,'folder',KmsdJXWHbDET9AankUCeMutfvQj
		else: mode,type,BN1KdkzCmvshw = 112,'video',GOQI6tW4xVh8NYwdPqMD9Kg
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if HZGOjy8dgXs and len(items)<2:
			HZGOjy8dgXs = False
			continue
		for Y6YdkAMluFbwx,GdTzrVD9t0cFUu5,GS7Y93B0b8TLxueF in items:
			title = GdTzrVD9t0cFUu5+ww0sZkBU9JKd+GS7Y93B0b8TLxueF
			Qm8SMu6ecXtigDCWw1oak(type,TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,mode)
		break
	if not items and '/episodes' in GagwMT6q3oc7UZ2Q:
		veBnCIcRWyJi7Gg8tuOfNQswUq = oo9kuULlebNgpY0Om.findall('class="breadcrumb"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if veBnCIcRWyJi7Gg8tuOfNQswUq:
			BN1KdkzCmvshw = veBnCIcRWyJi7Gg8tuOfNQswUq[0]
			dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if len(dsGzqX4k0a8RLyc)>2:
				Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[2]+'list'
				UUhwKBgI2nt(Y6YdkAMluFbwx)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="actions(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: return
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	M5MQmkjRiXhFVupbODrlGYSIzT = '/watch/' in BN1KdkzCmvshw
	download = '/download/' in BN1KdkzCmvshw
	if   M5MQmkjRiXhFVupbODrlGYSIzT and not download: H1BiM3KyJq,dCOTsQMhK6105n = dsGzqX4k0a8RLyc[0],G9G0YqivIfmUWO8K
	elif not M5MQmkjRiXhFVupbODrlGYSIzT and download: H1BiM3KyJq,dCOTsQMhK6105n = G9G0YqivIfmUWO8K,dsGzqX4k0a8RLyc[0]
	elif M5MQmkjRiXhFVupbODrlGYSIzT and download: H1BiM3KyJq,dCOTsQMhK6105n = dsGzqX4k0a8RLyc[0],dsGzqX4k0a8RLyc[1]
	else: H1BiM3KyJq,dCOTsQMhK6105n = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	ODnaR0N8UHv7Twy6jS = []
	if M5MQmkjRiXhFVupbODrlGYSIzT:
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',H1BiM3KyJq,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-PLAY-2nd')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('let servers(.*?)player',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL|oo9kuULlebNgpY0Om.IGNORECASE)
		if msFSK7j9MrcoPafDnkNO:
			duYhmVFABjltoJ9PcE = msFSK7j9MrcoPafDnkNO[0]
			qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('"name":"(.*?)".*?"url":"(.*?)"',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
			for title,Y6YdkAMluFbwx in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.replace('\\/','/')
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__watch'
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if download:
		D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',dCOTsQMhK6105n,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-PLAY-3rd')
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = D7omduSeM5Gk.content
		msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"servers"(.*?)info-container',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if msFSK7j9MrcoPafDnkNO:
			duYhmVFABjltoJ9PcE = msFSK7j9MrcoPafDnkNO[0]
			qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',duYhmVFABjltoJ9PcE,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title,I5chimw4D1okfxlBE2UpbuHJvStsZ in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				Y6YdkAMluFbwx = Y6YdkAMluFbwx+'?named='+title+'__download'+'____'+I5chimw4D1okfxlBE2UpbuHJvStsZ
				ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ODnaR0N8UHv7Twy6jS,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search:
		search = ZT7zGWSCtpvfmwMNRjYrKL()
		if not search: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search?s='+search
	UUhwKBgI2nt(url,'search')
	return
def RFEgei8ox2aIBLJDTzfswql(url):
	url = url.split('/smartemadfilter?')[0]
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	FgGiXAn5NeaTHS0mZ = []
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('adv-filter(.*?)shows-container',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		ppzYOGZjfPi,k7zM3Heg90OtGrJWYm,cUE5uH8hAtOmTp = zip(*FgGiXAn5NeaTHS0mZ)
		FgGiXAn5NeaTHS0mZ = zip(k7zM3Heg90OtGrJWYm,ppzYOGZjfPi,cUE5uH8hAtOmTp)
	return FgGiXAn5NeaTHS0mZ
def X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw):
	items = oo9kuULlebNgpY0Om.findall('value="(.*?)".*?>\s*(.*?)\s*<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	return items
def awQqEIVzfnOMZtAbpC6Bv1hgsSFc(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	LV6wHuJn8BiWZeyRkcI3sdXU = url.split('/smartemadfilter?')[0]
	NPlUQFruOmeD = xWiOjcUrJVdtP4B5Iml(url,'url')
	url = url.replace(LV6wHuJn8BiWZeyRkcI3sdXU,NPlUQFruOmeD)
	url = url.replace('/smartemadfilter?','/?')
	return url
ZlQjWRtKAOrqmpTsELD5CfYzxdIBog = ['quality','year','genre','category']
kiRCOXcAlv04BqHWdMpbDzQFGmJw = ['category','genre','year']
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='DEFINED_FILTER':
		if kiRCOXcAlv04BqHWdMpbDzQFGmJw[0]+'=' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = kiRCOXcAlv04BqHWdMpbDzQFGmJw[0]
		for KT9tdUH3hmiLZCEFz in range(len(kiRCOXcAlv04BqHWdMpbDzQFGmJw[0:-1])):
			if kiRCOXcAlv04BqHWdMpbDzQFGmJw[KT9tdUH3hmiLZCEFz]+'=' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = kiRCOXcAlv04BqHWdMpbDzQFGmJw[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='FULL_FILTER':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		XjWHSnbf6NwhMgpKt4yLY7AkIT = awQqEIVzfnOMZtAbpC6Bv1hgsSFc(XXzvmn7ewM8yBfoxua)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',XjWHSnbf6NwhMgpKt4yLY7AkIT,111)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',XjWHSnbf6NwhMgpKt4yLY7AkIT,111)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	FgGiXAn5NeaTHS0mZ = RFEgei8ox2aIBLJDTzfswql(url)
	dict = {}
	for name,TaVcxgUOBpSwX6Rl9PYkzeudt1,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		name = name.replace('كل ',G9G0YqivIfmUWO8K)
		items = X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw)
		if '=' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='DEFINED_FILTER':
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<2:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==kiRCOXcAlv04BqHWdMpbDzQFGmJw[-1]:
					XjWHSnbf6NwhMgpKt4yLY7AkIT = awQqEIVzfnOMZtAbpC6Bv1hgsSFc(XXzvmn7ewM8yBfoxua)
					UUhwKBgI2nt(XjWHSnbf6NwhMgpKt4yLY7AkIT)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'DEFINED_FILTER___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==kiRCOXcAlv04BqHWdMpbDzQFGmJw[-1]:
					XjWHSnbf6NwhMgpKt4yLY7AkIT = awQqEIVzfnOMZtAbpC6Bv1hgsSFc(XXzvmn7ewM8yBfoxua)
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XjWHSnbf6NwhMgpKt4yLY7AkIT,111)
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,115,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='FULL_FILTER':
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع :'+name,XXzvmn7ewM8yBfoxua,114,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			if yW70dtahIjkPCJg2TA=='196533': M0nQuWoaIxhSdqyV9N = 'أفلام نيتفلكس'
			elif yW70dtahIjkPCJg2TA=='196531': M0nQuWoaIxhSdqyV9N = 'مسلسلات نيتفلكس'
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = M0nQuWoaIxhSdqyV9N
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+M0nQuWoaIxhSdqyV9N
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			title = M0nQuWoaIxhSdqyV9N+' :'#+dict[TaVcxgUOBpSwX6Rl9PYkzeudt1]['0']
			title = M0nQuWoaIxhSdqyV9N+' :'+name
			if type=='FULL_FILTER': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,114,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='DEFINED_FILTER' and kiRCOXcAlv04BqHWdMpbDzQFGmJw[-2]+'=' in UHjy18F6pJO0DYdcsr5L:
				DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'modified_filters')
				XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
				XjWHSnbf6NwhMgpKt4yLY7AkIT = awQqEIVzfnOMZtAbpC6Bv1hgsSFc(XXzvmn7ewM8yBfoxua)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,XjWHSnbf6NwhMgpKt4yLY7AkIT,111)
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,115,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.replace('=&','=0&')
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&')
	R9h6MqBxlsEpNztI0AU = {}
	if '=' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('=')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = G9G0YqivIfmUWO8K
	for key in ZlQjWRtKAOrqmpTsELD5CfYzxdIBog:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
		elif mode=='all': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&')
	lOaCfpSNzejn = lOaCfpSNzejn.replace('=0','=')
	return lOaCfpSNzejn
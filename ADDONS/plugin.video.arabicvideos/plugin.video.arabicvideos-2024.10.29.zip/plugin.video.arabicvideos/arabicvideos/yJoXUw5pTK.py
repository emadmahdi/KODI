# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'GLOBALSEARCH'
TdtCLWYSJNK8zOb = '_GLS_'
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs,eehFlSEjHioyAWpLqZXt79):
	if   Mauf6CrJjP87s==540: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif Mauf6CrJjP87s==541: tRojAyBgfDH37eLCwP4dWl = i4WFCgmxslJaw(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==542: tRojAyBgfDH37eLCwP4dWl = E9fN0uclKIzSajYHmgv(Vvju9Ht8SGxoiTa6lCs,Qjnkp0KgXq2Ty,eehFlSEjHioyAWpLqZXt79)
	elif Mauf6CrJjP87s==543: tRojAyBgfDH37eLCwP4dWl = YnZ043kfiRVGKT59FWdLBPS2q6J1lb()
	elif Mauf6CrJjP87s==548: tRojAyBgfDH37eLCwP4dWl = oCxuiF2dJ47phZl85fPYtOMyk(Qjnkp0KgXq2Ty,Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==549: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(Vvju9Ht8SGxoiTa6lCs)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder','بحث جديد لجميع المواقع',G9G0YqivIfmUWO8K,549)
	Qm8SMu6ecXtigDCWw1oak('link','كيف يعمل بحث جميع المواقع','',543)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'==== كلمات البحث المخزنة ===='+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	I57oUOlDXgzTmAui4HPtf9cY = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if I57oUOlDXgzTmAui4HPtf9cY:
		I57oUOlDXgzTmAui4HPtf9cY = I57oUOlDXgzTmAui4HPtf9cY['__SEQUENCED_COLUMNS__']
		for I47oPYM1VXxnt in reversed(I57oUOlDXgzTmAui4HPtf9cY):
			Qm8SMu6ecXtigDCWw1oak('folder',I47oPYM1VXxnt,G9G0YqivIfmUWO8K,549,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,I47oPYM1VXxnt)
	return
def b6WZDnA0dLBiCITrF37OS(I47oPYM1VXxnt):
	if not I47oPYM1VXxnt:
		I47oPYM1VXxnt = ZT7zGWSCtpvfmwMNRjYrKL()
		if not I47oPYM1VXxnt: return
		I47oPYM1VXxnt = I47oPYM1VXxnt.lower()
	srmO43LfnxajeDQPTzXI6gVvB = I47oPYM1VXxnt.replace(TdtCLWYSJNK8zOb,G9G0YqivIfmUWO8K)
	ovAMa2fJgeKPBQpxVh(srmO43LfnxajeDQPTzXI6gVvB,'_ALL',True)
	Qm8SMu6ecXtigDCWw1oak('link','بحث جماعي للمواقع - '+srmO43LfnxajeDQPTzXI6gVvB,'search_sites_all',542,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('folder','بحث منفرد للمواقع - '+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,541,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder','نتائج البحث مفصلة - '+srmO43LfnxajeDQPTzXI6gVvB,'opened_sites_all',542,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	Qm8SMu6ecXtigDCWw1oak('folder','نتائج البحث مقسمة - '+srmO43LfnxajeDQPTzXI6gVvB,'listed_sites_all',542,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,srmO43LfnxajeDQPTzXI6gVvB)
	return
def ovAMa2fJgeKPBQpxVh(v4byiPk7wGKH9EYDgL6rZSzTx,pAw6Ej4RB0J9D7ezcSnCsT,lC6tOvjNwgGVbAKPozrq7aJ452RI):
	if pAw6Ej4RB0J9D7ezcSnCsT=='_ALL': PKNzo3qJVFefnwpRZO = '_GLS_'
	elif pAw6Ej4RB0J9D7ezcSnCsT=='_GOOGLE': PKNzo3qJVFefnwpRZO = '_GOS_'
	xruw5mFBd60SWe = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,v4byiPk7wGKH9EYDgL6rZSzTx)
	avuw6GKe7g9iyL8HP = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,PKNzo3qJVFefnwpRZO+v4byiPk7wGKH9EYDgL6rZSzTx)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,v4byiPk7wGKH9EYDgL6rZSzTx)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,PKNzo3qJVFefnwpRZO+v4byiPk7wGKH9EYDgL6rZSzTx)
	CVpqGTAZWyiYROevw = xruw5mFBd60SWe+avuw6GKe7g9iyL8HP
	if CVpqGTAZWyiYROevw and lC6tOvjNwgGVbAKPozrq7aJ452RI: v4byiPk7wGKH9EYDgL6rZSzTx = PKNzo3qJVFefnwpRZO+v4byiPk7wGKH9EYDgL6rZSzTx
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,v4byiPk7wGKH9EYDgL6rZSzTx,CVpqGTAZWyiYROevw,InpqoEf2WrlSe8)
	return
def vvWHIEqsdj1RZL(pAw6Ej4RB0J9D7ezcSnCsT):
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=1: return
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DETAILED'+pAw6Ej4RB0J9D7ezcSnCsT)
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DIVIDED'+pAw6Ej4RB0J9D7ezcSnCsT)
	if pAw6Ej4RB0J9D7ezcSnCsT=='_GOOGLE': aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GOOGLESEARCH_RESULTS')
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def E9fN0uclKIzSajYHmgv(LWtfrK1FP6V59kb,InFWAGLxuvhqrJM82Dmylzbf,s90dRJb74PCUcZgxilYFnh=G9G0YqivIfmUWO8K,vwg5GUneoN7Oz0=R9REDCIH1Ykn,r7DP6UCSwn4HI2k3ajsRxphic={}):
	AreDCPuqNRLHbkMQ1I,ww8EoLTnbsOuAgil0qFCX3ax6H2,rGvziNafACju0ly9IcV6bd52,oz3rbgXH8ItCcdD,YLD0KHcpCqay3neWkXzU71EioR6B = [],{},{},{},{}
	if '_all' in InFWAGLxuvhqrJM82Dmylzbf: pAw6Ej4RB0J9D7ezcSnCsT,JJaOb15lYHUgtDcpdVS,PKNzo3qJVFefnwpRZO = '_ALL','_all','_GLS_'
	elif '_google' in InFWAGLxuvhqrJM82Dmylzbf: pAw6Ej4RB0J9D7ezcSnCsT,JJaOb15lYHUgtDcpdVS,PKNzo3qJVFefnwpRZO = '_GOOGLE','_google','_GOS_'
	if InFWAGLxuvhqrJM82Dmylzbf in ['listed_sites'+JJaOb15lYHUgtDcpdVS,'opened_sites'+JJaOb15lYHUgtDcpdVS,'closed_sites'+JJaOb15lYHUgtDcpdVS]:
		if InFWAGLxuvhqrJM82Dmylzbf=='listed_sites'+JJaOb15lYHUgtDcpdVS: AreDCPuqNRLHbkMQ1I = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,PKNzo3qJVFefnwpRZO+LWtfrK1FP6V59kb)
		elif InFWAGLxuvhqrJM82Dmylzbf=='opened_sites'+JJaOb15lYHUgtDcpdVS: AreDCPuqNRLHbkMQ1I = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_DETAILED'+pAw6Ej4RB0J9D7ezcSnCsT,LWtfrK1FP6V59kb)
		elif InFWAGLxuvhqrJM82Dmylzbf=='closed_sites'+JJaOb15lYHUgtDcpdVS: AreDCPuqNRLHbkMQ1I = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,'list','GLOBALSEARCH_DIVIDED'+pAw6Ej4RB0J9D7ezcSnCsT,(s90dRJb74PCUcZgxilYFnh,LWtfrK1FP6V59kb))
	if not AreDCPuqNRLHbkMQ1I:
		TsWkBdGYqEAHmrx = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		zcbj21qWCFYL4MrS7R = 'هل تريد الآن البحث في جميع المواقع عن \n "'+ipjCIhwEXsbadR+ww0sZkBU9JKd+LWtfrK1FP6V59kb+ww0sZkBU9JKd+zzGfwLAyN5HTxUoJeaivY+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if InFWAGLxuvhqrJM82Dmylzbf=='search_sites'+JJaOb15lYHUgtDcpdVS: JPhoBimWUM0Gu2H1Fe9fRv8 = zcbj21qWCFYL4MrS7R
		else: JPhoBimWUM0Gu2H1Fe9fRv8 = TsWkBdGYqEAHmrx+zcbj21qWCFYL4MrS7R
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج',JPhoBimWUM0Gu2H1Fe9fRv8)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=1: return
		ggGCyoxkHXwif(False,False,False)
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+'   Search For: [ '+LWtfrK1FP6V59kb+' ]')
		Up63nro51cm7EzOga9RjSGhqi = 1
		for oob2dzmG3jTMpZwQyIfN in vwg5GUneoN7Oz0:
			qKWunmY1OiDPSAarEG53CF = r7DP6UCSwn4HI2k3ajsRxphic[oob2dzmG3jTMpZwQyIfN] if r7DP6UCSwn4HI2k3ajsRxphic else LWtfrK1FP6V59kb
			try: oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
			except: continue
			ww8EoLTnbsOuAgil0qFCX3ax6H2[oob2dzmG3jTMpZwQyIfN] = []
			m5qG0Lfhadn7kzVQSsM = '_NODIALOGS_'
			if '-' in oob2dzmG3jTMpZwQyIfN: m5qG0Lfhadn7kzVQSsM = m5qG0Lfhadn7kzVQSsM+'_REMEMBERRESULTS__'+oob2dzmG3jTMpZwQyIfN+'_'
			if Up63nro51cm7EzOga9RjSGhqi:
				SSCU3jdyFn2V.sleep(0.75)
				YLD0KHcpCqay3neWkXzU71EioR6B[oob2dzmG3jTMpZwQyIfN] = fu19TY0PdM6AZB5.Thread(target=PYymEzqnMT0it36kHG,args=(qKWunmY1OiDPSAarEG53CF+m5qG0Lfhadn7kzVQSsM,))
				YLD0KHcpCqay3neWkXzU71EioR6B[oob2dzmG3jTMpZwQyIfN].start()
			else: PYymEzqnMT0it36kHG(qKWunmY1OiDPSAarEG53CF+m5qG0Lfhadn7kzVQSsM)
			XXeZuvhknsKYqB17gwm6dfc(GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN),G9G0YqivIfmUWO8K,SSCU3jdyFn2V=1000)
		if Up63nro51cm7EzOga9RjSGhqi:
			SSCU3jdyFn2V.sleep(2)
			for oob2dzmG3jTMpZwQyIfN in vwg5GUneoN7Oz0: YLD0KHcpCqay3neWkXzU71EioR6B[oob2dzmG3jTMpZwQyIfN].join(10)
			SSCU3jdyFn2V.sleep(2)
		for oob2dzmG3jTMpZwQyIfN in vwg5GUneoN7Oz0:
			try: oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
			except: continue
			for u5PH2z4f3d76TZtlxpOcghmvr in eANQpmZPJaI7wc8:
				Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = u5PH2z4f3d76TZtlxpOcghmvr
				if P8Pqs0UvEBg2AfmXDK6C in YwC7jt5BQHhTUvbdGeM6f2ZLx:
					if 'IPTV-' in oob2dzmG3jTMpZwQyIfN and (239>=Mauf6CrJjP87s>=230 or 289>=Mauf6CrJjP87s>=280):
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['IPTV-LIVE']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['IPTV-MOVIES']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['IPTV-SERIES']: continue
						if 'صفحة' not in YwC7jt5BQHhTUvbdGeM6f2ZLx:
							if   Um2ITJ1iLnEjqZevskVt06NY34=='live': oob2dzmG3jTMpZwQyIfN = 'IPTV-LIVE'
							elif Um2ITJ1iLnEjqZevskVt06NY34=='video': oob2dzmG3jTMpZwQyIfN = 'IPTV-MOVIES'
							elif Um2ITJ1iLnEjqZevskVt06NY34=='folder': oob2dzmG3jTMpZwQyIfN = 'IPTV-SERIES'
						else:
							if   'LIVE' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'IPTV-LIVE'
							elif 'MOVIES' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'IPTV-MOVIES'
							elif 'SERIES' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'IPTV-SERIES'
					elif 'M3U-' in oob2dzmG3jTMpZwQyIfN and 729>=Mauf6CrJjP87s>=710:
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['M3U-LIVE']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['M3U-MOVIES']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['M3U-SERIES']: continue
						if 'صفحة' not in YwC7jt5BQHhTUvbdGeM6f2ZLx:
							if   Um2ITJ1iLnEjqZevskVt06NY34=='live': oob2dzmG3jTMpZwQyIfN = 'M3U-LIVE'
							elif Um2ITJ1iLnEjqZevskVt06NY34=='video': oob2dzmG3jTMpZwQyIfN = 'M3U-MOVIES'
							elif Um2ITJ1iLnEjqZevskVt06NY34=='folder': oob2dzmG3jTMpZwQyIfN = 'M3U-SERIES'
						else:
							if   'LIVE' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'M3U-LIVE'
							elif 'MOVIES' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'M3U-MOVIES'
							elif 'SERIES' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'M3U-SERIES'
					elif 'YOUTUBE-' in oob2dzmG3jTMpZwQyIfN and 149>=Mauf6CrJjP87s>=140:
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['YOUTUBE-CHANNELS']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['YOUTUBE-PLAYLISTS']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in YwC7jt5BQHhTUvbdGeM6f2ZLx or ':: ' in YwC7jt5BQHhTUvbdGeM6f2ZLx:
							continue
						else:
							if   Mauf6CrJjP87s==144 and 'USER' in YwC7jt5BQHhTUvbdGeM6f2ZLx: oob2dzmG3jTMpZwQyIfN = 'YOUTUBE-CHANNELS'
							elif Mauf6CrJjP87s==144 and 'CHNL' in YwC7jt5BQHhTUvbdGeM6f2ZLx: oob2dzmG3jTMpZwQyIfN = 'YOUTUBE-CHANNELS'
							elif Mauf6CrJjP87s==144 and 'LIST' in YwC7jt5BQHhTUvbdGeM6f2ZLx: oob2dzmG3jTMpZwQyIfN = 'YOUTUBE-PLAYLISTS'
							elif Mauf6CrJjP87s==143: oob2dzmG3jTMpZwQyIfN = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in oob2dzmG3jTMpZwQyIfN and 419>=Mauf6CrJjP87s>=400:
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['DAILYMOTION-PLAYLISTS']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['DAILYMOTION-CHANNELS']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['DAILYMOTION-VIDEOS']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['DAILYMOTION-LIVES']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['DAILYMOTION-HASHTAGS']: continue
						if   Mauf6CrJjP87s in [401,405]: oob2dzmG3jTMpZwQyIfN = 'DAILYMOTION-PLAYLISTS'
						elif Mauf6CrJjP87s in [402,406]: oob2dzmG3jTMpZwQyIfN = 'DAILYMOTION-CHANNELS'
						elif Mauf6CrJjP87s in [404]: oob2dzmG3jTMpZwQyIfN = 'DAILYMOTION-VIDEOS'
						elif Mauf6CrJjP87s in [415]: oob2dzmG3jTMpZwQyIfN = 'DAILYMOTION-LIVES'
						elif Mauf6CrJjP87s in [416]: oob2dzmG3jTMpZwQyIfN = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in oob2dzmG3jTMpZwQyIfN and 39>=Mauf6CrJjP87s>=30:
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['PANET-SERIES']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['PANET-MOVIES']: continue
						if   Mauf6CrJjP87s in [32,39]: oob2dzmG3jTMpZwQyIfN = 'PANET-SERIES'
						elif Mauf6CrJjP87s in [33,39]: oob2dzmG3jTMpZwQyIfN = 'PANET-MOVIES'
					elif 'IFILM-' in oob2dzmG3jTMpZwQyIfN and 29>=Mauf6CrJjP87s>=20:
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['IFILM-ARABIC']: continue
						if u5PH2z4f3d76TZtlxpOcghmvr in ww8EoLTnbsOuAgil0qFCX3ax6H2['IFILM-ENGLISH']: continue
						if   '/ar.' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'IFILM-ARABIC'
						elif '/en.' in Qjnkp0KgXq2Ty: oob2dzmG3jTMpZwQyIfN = 'IFILM-ENGLISH'
					ww8EoLTnbsOuAgil0qFCX3ax6H2[oob2dzmG3jTMpZwQyIfN].append(u5PH2z4f3d76TZtlxpOcghmvr)
		for oob2dzmG3jTMpZwQyIfN in list(ww8EoLTnbsOuAgil0qFCX3ax6H2.keys()):
			rGvziNafACju0ly9IcV6bd52[oob2dzmG3jTMpZwQyIfN] = []
			oz3rbgXH8ItCcdD[oob2dzmG3jTMpZwQyIfN] = []
			for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in ww8EoLTnbsOuAgil0qFCX3ax6H2[oob2dzmG3jTMpZwQyIfN]:
				u5PH2z4f3d76TZtlxpOcghmvr = (Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
				if 'صفحة' in YwC7jt5BQHhTUvbdGeM6f2ZLx and Um2ITJ1iLnEjqZevskVt06NY34=='folder': oz3rbgXH8ItCcdD[oob2dzmG3jTMpZwQyIfN].append(u5PH2z4f3d76TZtlxpOcghmvr)
				else: rGvziNafACju0ly9IcV6bd52[oob2dzmG3jTMpZwQyIfN].append(u5PH2z4f3d76TZtlxpOcghmvr)
		sSlUcx0XrVjPz,MMfyUxeCGA = [],[]
		ccDQeyqFsvw = list(rGvziNafACju0ly9IcV6bd52.keys())
		mYfR3VETgLzdCk2bU6 = nu2WTZYIvOrHaERCXc7jispNyK(ccDQeyqFsvw)
		wQYrc95f3Jlju = []
		for oob2dzmG3jTMpZwQyIfN in mYfR3VETgLzdCk2bU6:
			if 'tuple' in str(type(oob2dzmG3jTMpZwQyIfN)):
				wQYrc95f3Jlju = [oob2dzmG3jTMpZwQyIfN]
				continue
			if oob2dzmG3jTMpZwQyIfN not in vwg5GUneoN7Oz0: continue
			if rGvziNafACju0ly9IcV6bd52[oob2dzmG3jTMpZwQyIfN]:
				gkdiHI6smMUyECJnDeRQ3YtPX9vAqG = GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN)
				LNyMqPFpzXacuT8mK4SHjRUdnBQlw = [('link',ipjCIhwEXsbadR+'===== '+gkdiHI6smMUyECJnDeRQ3YtPX9vAqG+' ====='+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)]
				if 0: NaR5UvOkjwL6Te41EA = LWtfrK1FP6V59kb+' - '+'بحث'+ww0sZkBU9JKd+gkdiHI6smMUyECJnDeRQ3YtPX9vAqG
				else: NaR5UvOkjwL6Te41EA = 'بحث'+ww0sZkBU9JKd+gkdiHI6smMUyECJnDeRQ3YtPX9vAqG+' - '+LWtfrK1FP6V59kb
				if len(rGvziNafACju0ly9IcV6bd52[oob2dzmG3jTMpZwQyIfN])<8: uLG6cwni9YUMsTq = []
				else:
					pp43QEXRMZGkwN9dyAa2Wime = A7XhkmSYZlidyMt5FpWqTgjNezbnD+NaR5UvOkjwL6Te41EA+zzGfwLAyN5HTxUoJeaivY
					uLG6cwni9YUMsTq = [('folder',PKNzo3qJVFefnwpRZO+pp43QEXRMZGkwN9dyAa2Wime,'closed_sites'+JJaOb15lYHUgtDcpdVS,542,G9G0YqivIfmUWO8K,oob2dzmG3jTMpZwQyIfN,LWtfrK1FP6V59kb,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)]
				sCwHLkO3BuKXordNJ7VWa = rGvziNafACju0ly9IcV6bd52[oob2dzmG3jTMpZwQyIfN]+oz3rbgXH8ItCcdD[oob2dzmG3jTMpZwQyIfN]
				qCAlktriJhznMaFY40H2Ksf19 = wQYrc95f3Jlju+LNyMqPFpzXacuT8mK4SHjRUdnBQlw+sCwHLkO3BuKXordNJ7VWa[:7]+uLG6cwni9YUMsTq
				sSlUcx0XrVjPz += qCAlktriJhznMaFY40H2Ksf19
				Jyl0FZ2PexGudSIf3p7t5 = [('folder',PKNzo3qJVFefnwpRZO+NaR5UvOkjwL6Te41EA,'closed_sites'+JJaOb15lYHUgtDcpdVS,542,G9G0YqivIfmUWO8K,oob2dzmG3jTMpZwQyIfN,LWtfrK1FP6V59kb,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)]
				D2RT5uGrHdPo9z6Sw = wQYrc95f3Jlju+Jyl0FZ2PexGudSIf3p7t5
				MMfyUxeCGA += D2RT5uGrHdPo9z6Sw
				ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DIVIDED'+pAw6Ej4RB0J9D7ezcSnCsT,(oob2dzmG3jTMpZwQyIfN,LWtfrK1FP6V59kb),sCwHLkO3BuKXordNJ7VWa,InpqoEf2WrlSe8)
				wQYrc95f3Jlju = []
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_DETAILED'+pAw6Ej4RB0J9D7ezcSnCsT,LWtfrK1FP6V59kb,sSlUcx0XrVjPz,InpqoEf2WrlSe8)
		aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,LWtfrK1FP6V59kb)
		ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,'GLOBALSEARCH_SPLITTED'+pAw6Ej4RB0J9D7ezcSnCsT,PKNzo3qJVFefnwpRZO+LWtfrK1FP6V59kb,MMfyUxeCGA,InpqoEf2WrlSe8)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		AreDCPuqNRLHbkMQ1I = MMfyUxeCGA if InFWAGLxuvhqrJM82Dmylzbf=='listed_sites'+JJaOb15lYHUgtDcpdVS and MMfyUxeCGA else sSlUcx0XrVjPz
	if InFWAGLxuvhqrJM82Dmylzbf in ['listed_sites'+JJaOb15lYHUgtDcpdVS,'opened_sites'+JJaOb15lYHUgtDcpdVS,'closed_sites'+JJaOb15lYHUgtDcpdVS]:
		for Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 in AreDCPuqNRLHbkMQ1I:
			if InFWAGLxuvhqrJM82Dmylzbf in ['listed_sites'+JJaOb15lYHUgtDcpdVS,'opened_sites'+JJaOb15lYHUgtDcpdVS] and 'صفحة' in YwC7jt5BQHhTUvbdGeM6f2ZLx and Um2ITJ1iLnEjqZevskVt06NY34=='folder': continue
			Qm8SMu6ecXtigDCWw1oak(Um2ITJ1iLnEjqZevskVt06NY34,YwC7jt5BQHhTUvbdGeM6f2ZLx,Qjnkp0KgXq2Ty,Mauf6CrJjP87s,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,Vvju9Ht8SGxoiTa6lCs,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
	ggGCyoxkHXwif(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
	return
def i4WFCgmxslJaw(search):
	mYfR3VETgLzdCk2bU6 = nu2WTZYIvOrHaERCXc7jispNyK(fGx7vehHaVmkAgR1pJn)
	for oob2dzmG3jTMpZwQyIfN in mYfR3VETgLzdCk2bU6:
		if '-' in oob2dzmG3jTMpZwQyIfN: continue
		if 'tuple' in str(type(oob2dzmG3jTMpZwQyIfN)):
			eANQpmZPJaI7wc8.append(oob2dzmG3jTMpZwQyIfN)
			continue
		oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
		name = GoAEsgO4hHICi65(oob2dzmG3jTMpZwQyIfN)+' - '+search
		Qm8SMu6ecXtigDCWw1oak('folder',P8Pqs0UvEBg2AfmXDK6C+name,oob2dzmG3jTMpZwQyIfN,548,'','',search)
	return
def oCxuiF2dJ47phZl85fPYtOMyk(oob2dzmG3jTMpZwQyIfN,search):
	oyuFxk4Vew5cHP16,PYymEzqnMT0it36kHG,P8Pqs0UvEBg2AfmXDK6C = vW5j4M9gkHeJX0a(oob2dzmG3jTMpZwQyIfN)
	PYymEzqnMT0it36kHG(search)
	return
def YnZ043kfiRVGKT59FWdLBPS2q6J1lb():
	hbKFzulmsw4k('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def zJkuepo9g0qAwa1vnMTQ(LWtfrK1FP6V59kb=G9G0YqivIfmUWO8K):
	I47oPYM1VXxnt,m5qG0Lfhadn7kzVQSsM,showDialogs = bY6tjyS08hUC(LWtfrK1FP6V59kb)
	if not I47oPYM1VXxnt:
		I47oPYM1VXxnt = ZT7zGWSCtpvfmwMNRjYrKL()
		if not I47oPYM1VXxnt: return
		I47oPYM1VXxnt = I47oPYM1VXxnt.lower()
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+'   Search For: [ '+I47oPYM1VXxnt+' ]')
	HG9ZQqnw71y0JmrDLx = I47oPYM1VXxnt+m5qG0Lfhadn7kzVQSsM
	if 0: uZj6YyI1QU8,srmO43LfnxajeDQPTzXI6gVvB = I47oPYM1VXxnt+' - ',G9G0YqivIfmUWO8K
	else: uZj6YyI1QU8,srmO43LfnxajeDQPTzXI6gVvB = G9G0YqivIfmUWO8K,' - '+I47oPYM1VXxnt
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'مواقع سيرفرات خاصة - قليلة المشاكل'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,157)
	Qm8SMu6ecXtigDCWw1oak('folder','_M3U_'+uZj6YyI1QU8+'بحث M3U'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,719,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_IPT_'+uZj6YyI1QU8+'بحث IPTV'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,239,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_BKR_'+uZj6YyI1QU8+'بحث موقع بكرا'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,379,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_ART_'+uZj6YyI1QU8+'بحث موقع تونز عربية'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,739,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_KRB_'+uZj6YyI1QU8+'بحث موقع قناة كربلاء'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,329,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FH2_'+uZj6YyI1QU8+'بحث موقع فاصل الثاني'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,599,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_KTV_'+uZj6YyI1QU8+'بحث موقع كتكوت تيفي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,819,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_EB1_'+uZj6YyI1QU8+'بحث موقع ايجي بيست 1'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,779,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_EB2_'+uZj6YyI1QU8+'بحث موقع ايجي بيست 2'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,789,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_IFL_'+uZj6YyI1QU8+'  بحث موقع قناة آي فيلم'+srmO43LfnxajeDQPTzXI6gVvB+zVnkcBX6aJDPRpqyCjhoSZYQbL,G9G0YqivIfmUWO8K,29,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_AKO_'+uZj6YyI1QU8+'بحث موقع أكوام القديم'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,79,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_AKW_'+uZj6YyI1QU8+'بحث موقع أكوام الجديد'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,249,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_MRF_'+uZj6YyI1QU8+'بحث موقع قناة المعارف'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,49,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SHM_'+uZj6YyI1QU8+'بحث موقع شوف ماكس'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,59,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,157)
	Qm8SMu6ecXtigDCWw1oak('folder','_LRZ_'+uZj6YyI1QU8+'بحث موقع لاروزا'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,709,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FJS_'+uZj6YyI1QU8+' بحث موقع فجر شو'+srmO43LfnxajeDQPTzXI6gVvB+ww0sZkBU9JKd,G9G0YqivIfmUWO8K,399,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_TVF_'+uZj6YyI1QU8+'بحث موقع تيفي فان'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,469,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_LDN_'+uZj6YyI1QU8+'بحث موقع لودي نت'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,459,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CMN_'+uZj6YyI1QU8+'بحث موقع سيما ناو'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,309,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SHN_'+uZj6YyI1QU8+'بحث موقع شاهد نيوز'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,589,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx+'_NODIALOGS_')
	Qm8SMu6ecXtigDCWw1oak('folder','_ARS_'+uZj6YyI1QU8+'بحث موقع عرب سييد'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,259,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CCB_'+uZj6YyI1QU8+'بحث موقع سيما كلوب'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,829,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SH4_'+uZj6YyI1QU8+'بحث موقع شاهد فوريو'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,119,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx+'_NODIALOGS_')
	Qm8SMu6ecXtigDCWw1oak('folder','_SHT_'+uZj6YyI1QU8+'بحث موقع شوفها تيفي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,649,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_WC1_'+uZj6YyI1QU8+'بحث موقع وي سيما 1'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,569,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_WC2_'+uZj6YyI1QU8+'بحث موقع وي سيما 2'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,1009,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'مواقع سيرفرات عامة - كثيرة المشاكل'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,157)
	Qm8SMu6ecXtigDCWw1oak('folder','_TKT_'+uZj6YyI1QU8+'بحث موقع تكات'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,949,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FST_'+uZj6YyI1QU8+'بحث موقع فوستا'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,609,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FBK_'+uZj6YyI1QU8+'بحث موقع فبركة'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,629,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_YQT_'+uZj6YyI1QU8+'بحث موقع ياقوت'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,669,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SHB_'+uZj6YyI1QU8+'بحث موقع شبكتي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,969,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_VRB_'+uZj6YyI1QU8+'بحث موقع فاربون'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,879,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_BRS_'+uZj6YyI1QU8+'بحث موقع برستيج'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,659,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_KRM_'+uZj6YyI1QU8+'بحث موقع كرمالك'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,929,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_ANZ_'+uZj6YyI1QU8+'بحث موقع انمي زد'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,979,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FSK_'+uZj6YyI1QU8+'بحث موقع فاريسكو'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,999,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_HLC_'+uZj6YyI1QU8+'بحث موقع هلا سيما'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,89,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_MST_'+uZj6YyI1QU8+'بحث موقع المصطبة'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,869,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SNT_'+uZj6YyI1QU8+'بحث موقع شوف نت'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,849,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_DR7_'+uZj6YyI1QU8+'بحث موقع دراما صح'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,689,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CFR_'+uZj6YyI1QU8+'بحث موقع سيما فري'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,839,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CMF_'+uZj6YyI1QU8+'بحث موقع سيما فانز'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,99,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CML_'+uZj6YyI1QU8+'بحث موقع سيما لايت'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,479,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_C4H_'+uZj6YyI1QU8+'بحث موقع سيما 400'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,699,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_ABD_'+uZj6YyI1QU8+'بحث موقع سيما عبدو'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,559,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_AKT_'+uZj6YyI1QU8+'بحث موقع اكوام تيوب'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,859,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_DCF_'+uZj6YyI1QU8+'بحث موقع دراما كافيه'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,939,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FTV_'+uZj6YyI1QU8+'بحث موقع فوشار تيفي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,919,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_CWB_'+uZj6YyI1QU8+'بحث موقع سيما وبس'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,989,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_AHK_'+uZj6YyI1QU8+'بحث موقع أهواك تيفي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,619,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_SRT_'+uZj6YyI1QU8+'بحث موقع سيريس تايم'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,899,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_FVD_'+uZj6YyI1QU8+'بحث موقع فوشار فيديو'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,909,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_C4P_'+uZj6YyI1QU8+'بحث موقع سيما فور بي'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,889,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_EB4_'+uZj6YyI1QU8+'بحث موقع ايجي بيست 4'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,809,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+'مواقع سيرفرات خاصة - قليلة المشاكل'+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,157)
	Qm8SMu6ecXtigDCWw1oak('folder','_YUT_'+uZj6YyI1QU8+'بحث موقع يوتيوب'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,149,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	Qm8SMu6ecXtigDCWw1oak('folder','_DLM_'+uZj6YyI1QU8+'بحث موقع دايلي موشن'+srmO43LfnxajeDQPTzXI6gVvB,G9G0YqivIfmUWO8K,409,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,HG9ZQqnw71y0JmrDLx)
	return
# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨย")
def RAndFk3y4Pbvs29(Mauf6CrJjP87s,Vvju9Ht8SGxoiTa6lCs=G9G0YqivIfmUWO8K):
	if   Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠳ᅙ"): jWpcKtBhSbmevDuyZzkXCJfg1sNYO0(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==DTF3Lwy9etRH8mI(u"࠵ᅚ"): pass
	elif Mauf6CrJjP87s==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠷ᅛ"): H9dPKlWAyZ3OSi4D1(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠹ᅜ"): r6NtwShX8bk3Z14MipFY5Rzeo()
	elif Mauf6CrJjP87s==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠴ᅝ"): Ey7qhRWQ9KYcbICOo(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==DTF3Lwy9etRH8mI(u"࠶ᅞ"): bNytOahj1mDs2zIqirJUE7Z()
	elif Mauf6CrJjP87s==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠸ᅟ"): QqlEynLcvGaf1K()
	elif Mauf6CrJjP87s==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠺ᅠ"): iEKQs7waFroJUNl58RH6()
	elif Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠼ᅡ"): eAFdIcjVlZ7OHzLgMUuaDiJ()
	elif Mauf6CrJjP87s==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠾ᅢ"): sCpM1Gdnlz8XwLYIJO()
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠷࠵࠱ᅣ"): qvUK0GmIr3kPNfHn9X5ph()
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠱࠶࠳ᅤ"): O2ea4X0Qzf()
	elif Mauf6CrJjP87s==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠲࠷࠵ᅥ"): lPzvy9QJNqEoiD0()
	elif Mauf6CrJjP87s==t2sCrJ0xbgDRkf(u"࠳࠸࠷ᅦ"): cCAOZ7PD8RpYi436m5SUKv0()
	elif Mauf6CrJjP87s==rr7Xolsp4JwjPK3L(u"࠴࠹࠹ᅧ"): NNtCEoZPI5jasiedUnKgVW0()
	elif Mauf6CrJjP87s==dC3PsQJ0Ti28uYlov(u"࠵࠺࠻ᅨ"): PoCcVz5UWetLr9()
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠶࠻࠶ᅩ"): cQrRS4Vh1jbgZqsBYCHymJfLw6()
	elif Mauf6CrJjP87s==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠷࠵࠸ᅪ"): rUoLJ1ph8HXIiW0b5wkGFjzAutd2C()
	elif Mauf6CrJjP87s==VHrIziKUDuNGXkMla(u"࠱࠶࠺ᅫ"): zutsfRQq82TZO()
	elif Mauf6CrJjP87s==t2sCrJ0xbgDRkf(u"࠲࠷࠼ᅬ"): YeaMu3GlvJApz(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==vCmnFshSi4flecXIY2gy38G0DJw(u"࠳࠺࠴ᅭ"): DtwnbuAhzpjI()
	elif Mauf6CrJjP87s==rr7Xolsp4JwjPK3L(u"࠴࠻࠶ᅮ"): rhUs5P8mG3LFgjeBICNdTiqAQ()
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠵࠼࠸ᅯ"): dPyvmhpTxFLABWVr8Ht3Ml([Vvju9Ht8SGxoiTa6lCs],P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
	elif Mauf6CrJjP87s==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠶࠽࠳ᅰ"): MJGPcFsKn9hfoukHbyOeS(EHUAyW2lQfe4LXmhgIGc(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧร"),P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==rxWDdRBIct57i90s(u"࠷࠷࠵ᅱ"): MJGPcFsKn9hfoukHbyOeS(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫฤ"),P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==t2sCrJ0xbgDRkf(u"࠱࠸࠷ᅲ"): sygVCHIWDGc1rK5S2dBiOh()
	elif Mauf6CrJjP87s==ssGdubC4mngM9D5SRc3Ye(u"࠲࠹࠹ᅳ"): UFAzPjG0cbLluvkifd3K7X45qHIZEg()
	elif Mauf6CrJjP87s==cJSNFCIhymEfx6grGu0M(u"࠳࠺࠻ᅴ"): ji1wWUSZ0Q4vYtqHma5bhJzTdN69M(VHrIziKUDuNGXkMla(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ล"))
	elif Mauf6CrJjP87s==ETNq5t4MYngSsbfFD8J0v(u"࠴࠻࠾ᅵ"): ji1wWUSZ0Q4vYtqHma5bhJzTdN69M(t2sCrJ0xbgDRkf(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪฦ"))
	elif Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠵࠾࠶ᅶ"): NNIuYUCkzqQpvexKShL3RBDrAOX8()
	elif Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠶࠿࠱ᅷ"): kvJa7XZxUjGeI1tSlyL()
	elif Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠷࠹࠳ᅸ"): GpfRJdnDrU4l9M8KgskwtVSy()
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠱࠺࠵ᅹ"): bxPmSwAzpLTOuHB0GqvZXDkd1jJ48t()
	elif Mauf6CrJjP87s==jR9YtmsgDX8nTQlMb6G3(u"࠲࠻࠷ᅺ"): JGL7Bogtk4fwcZh0()
	elif Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠳࠼࠹ᅻ"): Q30DfSM7pEjYcaZgFu()
	elif Mauf6CrJjP87s==rr7Xolsp4JwjPK3L(u"࠴࠽࠻ᅼ"): WAFofPqR7UHJXiujKdkr3DTw()
	elif Mauf6CrJjP87s==ssGdubC4mngM9D5SRc3Ye(u"࠵࠾࠽ᅽ"): gJTKj6hEyFXavtVoflpc1()
	elif Mauf6CrJjP87s==ssGdubC4mngM9D5SRc3Ye(u"࠶࠿࠸ᅾ"): ggPEuxzTXrIwyFShnWo2pCcb3()
	elif Mauf6CrJjP87s==rr7Xolsp4JwjPK3L(u"࠷࠹࠺ᅿ"): IICTtWDm9UK3wJYqhjFZXf2()
	elif Mauf6CrJjP87s==DTF3Lwy9etRH8mI(u"࠳࠵࠲ᆀ"): sp1UYiZwoGLSjVEQJtzWvHOxaB6lC(Vvju9Ht8SGxoiTa6lCs)
	elif Mauf6CrJjP87s==EHUAyW2lQfe4LXmhgIGc(u"࠴࠶࠴ᆁ"): U5RhmxZzjcX4EB0HPb732Qu()
	elif Mauf6CrJjP87s==UighHKAfySm4PWErqJ(u"࠵࠷࠶ᆂ"): e9VKRSm7glUoE43FxyDTcB20sAzpI()
	elif Mauf6CrJjP87s==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠶࠸࠸ᆃ"): hhfMk7oiWDvwmOlSUEGQa()
	elif Mauf6CrJjP87s==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠷࠹࠺ᆄ"): isGetm1hI0HZkD9E(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==cJSNFCIhymEfx6grGu0M(u"࠸࠺࠵ᆅ"): HvfikBFNotw1yh()
	elif Mauf6CrJjP87s==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠹࠴࠷ᆆ"): gKVfG6vwnYyOxlAH(kkMuQrLWcEayRm)
	elif Mauf6CrJjP87s==VHrIziKUDuNGXkMla(u"࠳࠵࠹ᆇ"): hJXy9kqmV6gZe0C5bnuO1(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠴࠶࠻ᆈ"): rVs1jTFnup5XPoQ27d()
	elif Mauf6CrJjP87s==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠵࠷࠽ᆉ"): l0B5NMxSjdr8ta72PpHQsqTKuJ6DU(t2sCrJ0xbgDRkf(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩว"),P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠸࠴࠵ᆊ"): Kcf5v79ikuaS2D6qgHVEZLh()
	elif Mauf6CrJjP87s==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠹࠵࠷ᆋ"): kmcbg9nCdV8WjiPTsEY1X5qOl()
	elif Mauf6CrJjP87s==VHrIziKUDuNGXkMla(u"࠺࠶࠲ᆌ"): DDaB3jowumTvMeniEZIUf()
	elif Mauf6CrJjP87s==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠻࠰࠴ᆍ"): MEuegKbnCNa2zF01iUxYtJImAOVp(iyNfWHemZaC1)
	elif Mauf6CrJjP87s==qTVF3icWwGXy5(u"࠵࠱࠶ᆎ"): MEuegKbnCNa2zF01iUxYtJImAOVp(Mh2XHLxaCsToiUFymceOGKS)
	elif Mauf6CrJjP87s==dC3PsQJ0Ti28uYlov(u"࠶࠲࠸ᆏ"): HCMj1Lvm6tg5pJhlk3KA()
	elif Mauf6CrJjP87s==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠷࠳࠺ᆐ"): CU83wctmZIMAaxHv(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠸࠴࠼ᆑ"): wOfujtdkYAgKC7()
	elif Mauf6CrJjP87s==dC3PsQJ0Ti28uYlov(u"࠹࠵࠾ᆒ"): PsDlWcYxmqKORzTaef49wgUoECp()
	elif Mauf6CrJjP87s==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠺࠶࠹ᆓ"): zcPqpnjk4t2WbaGu6FVLoim()
	elif Mauf6CrJjP87s==iqHhJSxdaANDG5rlZm7B(u"࠷࠰࠳࠲ᆔ"): ggNIQ9DaCFBWGKdjfwx7ty()
	elif Mauf6CrJjP87s==EHUAyW2lQfe4LXmhgIGc(u"࠱࠱࠴࠴ᆕ"): MMCW0RpfPOb4F68qsnLi2NIXghS()
	elif Mauf6CrJjP87s==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠲࠲࠵࠶ᆖ"): ji1wWUSZ0Q4vYtqHma5bhJzTdN69M(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪศ"))
	elif Mauf6CrJjP87s==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠳࠳࠶࠸ᆗ"): lQkDRLcVe4x8imuW()
	return
def lQkDRLcVe4x8imuW():
	GFohMKWlxTBYdmSknLCUaw0qERt52 = amx9qJHkhw7oLdtVMG3.getSetting(RVpeGcmPxj9tCnT40Nf216(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪษ"))
	message = cjbAkCIinvs(u"ࠧศๆิๆ๊ࠦวๅ็ะำิࠦอศๆํหࠥํ่ࠡ࠼ࠣࠤࠥ࠭ส")+str(GFohMKWlxTBYdmSknLCUaw0qERt52)+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࠢ࡮ࡦࡵࡹࠧห") if GFohMKWlxTBYdmSknLCUaw0qERt52 else UighHKAfySm4PWErqJ(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส่ࠢฮํ่แสࠢะห้๐วࠨฬ")
	message = A7XhkmSYZlidyMt5FpWqTgjNezbnD+message+ETNq5t4MYngSsbfFD8J0v(u"ࠪࡠࡳํไࠡฬิ๎ิࠦวๅฤ้ࠤฯฺฺ๋ๆࠣวํࠦส฻์ํีࠥืโๆࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩอ")+zzGfwLAyN5HTxUoJeaivY
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫฮ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠬิั้ฮࠪฯ"),VHrIziKUDuNGXkMla(u"࠭ล๋ไสๅࠬะ"),cJSNFCIhymEfx6grGu0M(u"ࠧหึ฽๎้࠭ั"),iAGgjwb7tVMmacRJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫา"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊ส๊ࠢ๎ࠥ฿ๅๅ์ฬࠤ๏่่ๆࠢห๋ฬࠦวๅสิ๊ฬ๋ฬࠡสสาฯ๐วาࠢฦ฽้๏ࠠอ๊าอ๋ࠥส้ใิอ๊ࠥัใ็ࠣห้า่ะหࠣห้ึ๊ࠡษ้ฮࠥะอะั๊ࠤๆ๐่ࠠา๊ࠤฬ๊ิศึฬࠤ࠳࠴้้ࠠำหู๋ࠥ็ษ๊ࠤ฾์ฯๆษࠣฮ็๎ๅࠡษ้ฮࠥฮสี฼ํ่ࠥ็๊ะ์๋ࠤๆอๆࠡษ็ฬึ์วๆฮ่๋๊ࠣࠦิล็็ࠥ฿ๆࠡษ็ะํีษࠡษ็ฮ๏ࠦสา์า๋ฬࠦไฤ่ࠣห้ฮั็ษ่ะู่ࠥโࠢําฯอัࠡษ็ะํีษࠡล๋ฮํ๋วห์ๆ๎ฬࠦ࠮࠯ࠢ฼่๊อࠠศ่๊ࠤ๏าศࠡษัฮ๏อัࠡำๅ้ࠥา่ะหูࠣ฿๐ัࠡวำห้ࠥว็ฬࠣห้หๆหำ้ฮࠥ฿ๆะๅࠣฬ฼๐ฦสࠢฦ์่ࠥไ๋ๆฬࡠࡳࡢ࡮ࠨำ")+message)
	if z5zsxSmjpGVIoJ6OT in [-RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠴ᆘ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"࠴ᆙ")]: return
	if z5zsxSmjpGVIoJ6OT==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠶ᆚ"):
		GFohMKWlxTBYdmSknLCUaw0qERt52 = G9G0YqivIfmUWO8K
		hbKFzulmsw4k(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࠫิ"),t2sCrJ0xbgDRkf(u"ࠫࠬี"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨึ"),FWqeEzO1i8Dn0ga(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ๏่วโࠢส่ั๎ฯสࠢส่ศ๎ส้็สฮ๏้๊สࠩื"))
	else:
		items = [RVpeGcmPxj9tCnT40Nf216(u"ࠧ࠳࠷࠳ࠤࡰࡨࡰࡴุࠩ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࠷࠳࠴ࠥࡱࡢࡱࡵูࠪ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩ࠺࠹࠵ࠦ࡫ࡣࡲࡶฺࠫ"),ETNq5t4MYngSsbfFD8J0v(u"ࠪ࠵࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭฻"),UighHKAfySm4PWErqJ(u"ࠫ࠶࠸࠵࠱ࠢ࡮ࡦࡵࡹࠧ฼"),ssGdubC4mngM9D5SRc3Ye(u"ࠬ࠷࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ฽"),cJSNFCIhymEfx6grGu0M(u"࠭࠱࠸࠷࠳ࠤࡰࡨࡰࡴࠩ฾"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠧ࠳࠲࠳࠴ࠥࡱࡢࡱࡵࠪ฿"),iqHhJSxdaANDG5rlZm7B(u"ࠨ࠴࠸࠴࠵ࠦ࡫ࡣࡲࡶࠫเ"),iqHhJSxdaANDG5rlZm7B(u"ࠩ࠶࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬแ"),iAGgjwb7tVMmacRJ(u"ࠪ࠷࠺࠶࠰ࠡ࡭ࡥࡴࡸ࠭โ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫ࠹࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧใ"),VHrIziKUDuNGXkMla(u"ࠬ࠺࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨไ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭࠵࠱࠲࠳ࠤࡰࡨࡰࡴࠩๅ"),iqHhJSxdaANDG5rlZm7B(u"ࠧ࠷࠲࠳࠴ࠥࡱࡢࡱࡵࠪๆ"),DTF3Lwy9etRH8mI(u"ࠨ࠹࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ็"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࠻࠴࠵࠶ࠠ࡬ࡤࡳࡷ่ࠬ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪ࠽࠵࠶࠰ࠡ࡭ࡥࡴࡸ้࠭"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࠶࠶࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ๊"),yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠷࠱࠱࠲࠳ࠤࡰࡨࡰࡴ๋ࠩ"),ETNq5t4MYngSsbfFD8J0v(u"࠭࠱࠳࠲࠳࠴ࠥࡱࡢࡱࡵࠪ์"),ssGdubC4mngM9D5SRc3Ye(u"ࠧ࠺࠻࠼࠽࠾ࠦ࡫ࡣࡲࡶࠫํ")]
		PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(FWqeEzO1i8Dn0ga(u"ࠨษัฮึࠦวๅฮ๋ำฮࠦวๅล๋ฮํ๋วห์ๆ๎ฮࠦวๅ็้หุฮษࠨ๎"),items)
		if PXeEIRkdShOGm45lbLJc2B38s==-wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠷ᆛ"): return
		GFohMKWlxTBYdmSknLCUaw0qERt52 = str(items[PXeEIRkdShOGm45lbLJc2B38s][:-hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠵ᆜ")])
		hbKFzulmsw4k(ETNq5t4MYngSsbfFD8J0v(u"ࠩࠪ๏"),yiaeCEwJjOcWA4ZSd5h(u"ࠪࠫ๐"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ๑"),EHUAyW2lQfe4LXmhgIGc(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢอุ฿๐ไ๊ࠡอัิ๐ฯࠡำๅ้ࠥอไอ๊าอࠥอไฤ๊อ์๊อส๋ๅํอࡡࡴ࡜࡯ࠩ๒")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+GFohMKWlxTBYdmSknLCUaw0qERt52+ssGdubC4mngM9D5SRc3Ye(u"࠭ࠠ࡬ࡤࡳࡷࠬ๓")+zzGfwLAyN5HTxUoJeaivY)
	amx9qJHkhw7oLdtVMG3.setSetting(FWqeEzO1i8Dn0ga(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫ๔"),GFohMKWlxTBYdmSknLCUaw0qERt52)
	return
def MMCW0RpfPOb4F68qsnLi2NIXghS(oCRJkPa80z4vjx6n9qDrb7Fuf5MKmO=kkMuQrLWcEayRm):
	BYRz6kMFpxG3NcqOj5902XirEn = xnPeISFRsg3XjbYZW7L()
	Do8w3taAP2InE4kOqBuc = rxWDdRBIct57i90s(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใࠢํ฽๊๊ࠧ๕") if BYRz6kMFpxG3NcqOj5902XirEn else EHUAyW2lQfe4LXmhgIGc(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไ้ࠣฯ๎โโࠩ๖")
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(t2sCrJ0xbgDRkf(u"ࠪࡧࡪࡴࡴࡦࡴࠪ๗"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫำื่อࠩ๘"),dC3PsQJ0Ti28uYlov(u"ࠬห๊ใษไࠫ๙"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭สี฼ํ่ࠬ๚"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ๛"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+Do8w3taAP2InE4kOqBuc+zzGfwLAyN5HTxUoJeaivY+zEgtT9cR6bFp7JXqI5VuhNeP+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสอ฻็ࠤ่๎ฯ๋ࠢฦ์ฯ๎ๅศฬํ็๏อ๋ࠠไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦวๅๆสั็ࠦ࠮࠯ࠢศ้ฬࠦศฺัࠣห๋ะ็ศรࠣห้็๊ะ์๋ࠤฬ๊อศๆํࠤอษใๆๆ๊ࠤ࠳࠴ࠠฤ๊ࠣฬ฾ีࠠศๆ้ๆึูࠦๅ๋ࠣึึࠦࠢหฮส์ืࠦลๅ๋ࠣห้๊วฮไࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤสฺ๊ศรࠣห้ะิ฻์็ࠤฬ๊ไศฯๅࠤออไ็ไิࠤ฾๊้ࠡิิࠤࠧห๊ใษไࠤฬ๊แ๋ัํ์ࠧࠦ࠮࠯๋ࠢว๏฼วࠡ็่็๋ࠦวๅษึฮๆอฯส่๊ࠢࠥะฺ๋์ิࠤฯืส๋ส้ࠣาะ่๋ษอࠤฬ๊โ้ษษ้ࠥ࠴࠮๊ࠡัหฺฯࠠหำอ๎อࠦอๅไสฮࠥอไๆี็ื้อสࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅ๊ࠢิ์ࠦวๅ๊฻๎ๆฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨ๜"))
	if z5zsxSmjpGVIoJ6OT==fdQOo6Hu4B5Rbg: PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞ࡡࢂࢃࠧ๝"))
	elif z5zsxSmjpGVIoJ6OT==SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU: PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟࠶ࡣࡽࡾࠩ๞"))
	if z5zsxSmjpGVIoJ6OT in [fdQOo6Hu4B5Rbg,SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]:
		if ETNq5t4MYngSsbfFD8J0v(u"ࠫࡹࡸࡵࡦࠩ๟") in str(PFpbXEKiR7nLu4AYd): hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๠"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ๡"))
		else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ๢"),dC3PsQJ0Ti28uYlov(u"ࠨๆ็วุ็ࠠศๆ฼้้๐ษࠡใื่ฯ࠭๣"))
	return
def ggNIQ9DaCFBWGKdjfwx7ty():
	url = Kkfl8xemuHbd1w3a0ABPcDrN[t2sCrJ0xbgDRkf(u"ࠩࡕࡉࡑࡋࡁࡔࡇࡖࠫ๤")][t2sCrJ0xbgDRkf(u"࠱ᆝ")]
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡋࡊ࡚ࠧ๥"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡉࡏࡕࡗࡅࡑࡒ࡟ࡐࡎࡇࡣࡗࡋࡌࡆࡃࡖࡉ࠲࠷ࡳࡵࠩ๦"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	WX5T7vwl4P0qtOgmLNkzKGBUfeY = oo9kuULlebNgpY0Om.findall(ETNq5t4MYngSsbfFD8J0v(u"ࠬ࡮ࡲࡦࡨࡀࠦࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࠬࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠮ࡄ࠯࠮ࡻ࡫ࡳࠦࠬ๧"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	WX5T7vwl4P0qtOgmLNkzKGBUfeY = sorted(WX5T7vwl4P0qtOgmLNkzKGBUfeY,reverse=P5VqbRSzjtO4UE1rZaolG67XA)
	PXeEIRkdShOGm45lbLJc2B38s = wjrY1si9L6(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭วฯฬิࠤฬ๊ลึัสีࠥอไั์ࠣฮึ๐ฯࠡฬฮฬ๏ะ็ࠨ๨"),WX5T7vwl4P0qtOgmLNkzKGBUfeY)
	if PXeEIRkdShOGm45lbLJc2B38s>=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠲ᆞ"):
		fx03y4CdzcFGZhOu = url.rsplit(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࠰ࠩ๩"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠴ᆟ"))[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠴ᆠ")]+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨ࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࠩ๪")+WX5T7vwl4P0qtOgmLNkzKGBUfeY[PXeEIRkdShOGm45lbLJc2B38s]+bneABYmwFUH8GXphg0Kl2Sq(u"ࠩ࠱ࡾ࡮ࡶࠧ๫")
		succeeded = T7Zj25fv6JUF3DyI1g(ssGdubC4mngM9D5SRc3Ye(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ๬"),fx03y4CdzcFGZhOu,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡚ࡲࡶࡧᇯ"))
		if succeeded:
			amx9qJHkhw7oLdtVMG3.setSetting(dC3PsQJ0Ti28uYlov(u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ๭"),G9G0YqivIfmUWO8K)
			J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๮"),DTF3Lwy9etRH8mI(u"࠭สๆࠢอฯอ๐สࠡวุำฬืࠠใัํ้๊ࠥไษำ้ห๊าࠠ࠯࠰่่ࠣ์ࠠษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣวํะ่ๆษอ๎่๐วࠡสอัิ๐หࠡฮ่๎฾ࠦวๅสิห๊าࠠษษึฮำีวๆࠢลาึࠦลึัสี๋ࠥส้ใิࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦล๋ไสๅࠥอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥ็ัษࠣห้ฮั็ษ่ะࠥลࠡࠢࠩ๯"))
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd: l0B5NMxSjdr8ta72PpHQsqTKuJ6DU(rxWDdRBIct57i90s(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ๰"),P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA)
	return
def wOfujtdkYAgKC7():
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ๱"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"๊่ࠩࠥะั๋ัࠣๅ฾๊วࠡ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡษ็าฬ฻ษࠡส๋ๆฯࠦฬๅสࠣห้ะอะ์ฮหฯࠦ࠮࠯๊ࠢิฬࠦวๅ็ึัู่ࠥโࠢํือฮࠠหฯา๎ะࠦแ้ำํࠤ้าๅ๋฻ࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํ๋ࠥั้ำࠣ์็ะࠠๆ฻ํ๊ࠬ๲"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
		amx9qJHkhw7oLdtVMG3.setSetting(rxWDdRBIct57i90s(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡶ࡬ࡴࡸࡴࠨ๳"),G9G0YqivIfmUWO8K)
		amx9qJHkhw7oLdtVMG3.setSetting(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫ๴"),G9G0YqivIfmUWO8K)
		amx9qJHkhw7oLdtVMG3.setSetting(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩ๵"),G9G0YqivIfmUWO8K)
		amx9qJHkhw7oLdtVMG3.setSetting(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ๶"),G9G0YqivIfmUWO8K)
		amx9qJHkhw7oLdtVMG3.setSetting(rxWDdRBIct57i90s(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ๷"),G9G0YqivIfmUWO8K)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ๸"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫ๹"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def zcPqpnjk4t2WbaGu6FVLoim():
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭๺"),dC3PsQJ0Ti28uYlov(u"ࠫ์๊ࠠหำํำࠥ็ูๅษุ้ࠣำࠠอ็ํ฽ࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ๋ำฮࠢฯ้๏฿ࠠๆๆไหฯࠦวๅสิ๊ฬ๋ฬࠡษ็ๆิ๐ๅสࠢ࠱࠲๊ࠥใ๋ࠢํ฽ํีࠠศๆหี๋อๅอࠢศ่๎ࠦอศๆฬࠤฬ๊ีโำࠣ࠲࠳ฺ๊่ࠦํࠤฯาฯ๋ัࠣห้ฮั็ษ่ะࠥ๎สึใํี์ุ่้ࠦ฼๋ࠥฮอศๆฬࠤฬ๊ๅึ่฼ࠤฬ๊สฺ๋๋ࠢ฾ํวࠡษ็้อืๅอࠢยࠥࠦ࠭๻"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
		isGetm1hI0HZkD9E(kkMuQrLWcEayRm)
		Sm8oLxifPQNzI(ZwIThN17YKVQnbp52gX,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๼"),EHUAyW2lQfe4LXmhgIGc(u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦไๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤํ฿วะࠢส่อืๆศ็ฯࠤสู๊้๊ࠡ฽๏ฯࠠศๆุๅึࠦ࠮࠯ฺ๋ࠢ฾๐ษࠡษ็ฺ้์ูࠨ๽"))
	return
def HCMj1Lvm6tg5pJhlk3KA():
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ๾"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ๿"))
	YvSXiz5xrJEpUlDcA = nuDV6jzU0TEISJQ(kkMuQrLWcEayRm)
	obVEKCMXaTdZ4twqyYj = zEgtT9cR6bFp7JXqI5VuhNeP
	y4meMlt6s0jToDpkgzYrxFQ = ipjCIhwEXsbadR+rr7Xolsp4JwjPK3L(u"ࠩࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠭຀")+zzGfwLAyN5HTxUoJeaivY
	N6r2M7S8wKj4AfoqDszxdbgac9CH = zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧກ")+zzGfwLAyN5HTxUoJeaivY+VHrIziKUDuNGXkMla(u"ࠫࡡࡴ࡜࡯ࠩຂ")
	for id,agZ6rli0mxGfo8,pFGTX4fZNI9RB2xKOWAdsgb,HgbMUjLOaP43Ts6W,y4gZHwkYufl,reason in reversed(YvSXiz5xrJEpUlDcA):
		if id==yiaeCEwJjOcWA4ZSd5h(u"ࠬ࠶ࠧ຃"):
			KKGHBLXWq6pkOx,HRTLBshamJ2 = HgbMUjLOaP43Ts6W.split(cjbAkCIinvs(u"࠭࡜࡯࠽࠾ࠫຄ"))
			continue
		if obVEKCMXaTdZ4twqyYj!=zEgtT9cR6bFp7JXqI5VuhNeP: obVEKCMXaTdZ4twqyYj += N6r2M7S8wKj4AfoqDszxdbgac9CH
		TsWkBdGYqEAHmrx = cJSNFCIhymEfx6grGu0M(u"ࠧ࡜ࡔࡗࡐࡢ࠭຅")+ipjCIhwEXsbadR+id+rr7Xolsp4JwjPK3L(u"ࠨࠢ࠽ࠤࠬຆ")+EHUAyW2lQfe4LXmhgIGc(u"ࠩสุ่สวๅࠢ࠽ࠤࠬງ")+zzGfwLAyN5HTxUoJeaivY+pFGTX4fZNI9RB2xKOWAdsgb
		zcbj21qWCFYL4MrS7R = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫຈ")+ipjCIhwEXsbadR+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫฬ๊ฬ้ษหࠤ࠿ࠦࠧຉ")+zzGfwLAyN5HTxUoJeaivY+HgbMUjLOaP43Ts6W
		eCfQMxBE8j9hYzNU3IVHSp = t2sCrJ0xbgDRkf(u"ࠬࡡࡒࡕࡎࡠࠫຊ")+ipjCIhwEXsbadR+ETNq5t4MYngSsbfFD8J0v(u"࠭วๅะฺวࠥࡀࠠࠨ຋")+zzGfwLAyN5HTxUoJeaivY+y4gZHwkYufl
		yOmLxKSdh0sHAeQC2Wb = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨຌ")+ipjCIhwEXsbadR+cJSNFCIhymEfx6grGu0M(u"ࠨษ็ือฮࠠ࠻ࠢࠪຍ")+zzGfwLAyN5HTxUoJeaivY+reason
		obVEKCMXaTdZ4twqyYj += TsWkBdGYqEAHmrx+zcbj21qWCFYL4MrS7R+zEgtT9cR6bFp7JXqI5VuhNeP+y4meMlt6s0jToDpkgzYrxFQ+zEgtT9cR6bFp7JXqI5VuhNeP+eCfQMxBE8j9hYzNU3IVHSp+yOmLxKSdh0sHAeQC2Wb+zEgtT9cR6bFp7JXqI5VuhNeP
	tg6EQSH7P4(ETNq5t4MYngSsbfFD8J0v(u"ࠩࡵ࡭࡬࡮ࡴࠨຎ"),HRTLBshamJ2,obVEKCMXaTdZ4twqyYj,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫຏ"))
	return
def MEuegKbnCNa2zF01iUxYtJImAOVp(file):
	if file==Mh2XHLxaCsToiUFymceOGKS: WqRyTj7eaJPBIxsUfHYKVEz42iLvck = t2sCrJ0xbgDRkf(u"ࠫ็๎วว็ࠣห้๋แืๆฬࠫຐ")
	elif file==iyNfWHemZaC1: WqRyTj7eaJPBIxsUfHYKVEz42iLvck = ETNq5t4MYngSsbfFD8J0v(u"่่ࠬศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬຑ")
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(iAGgjwb7tVMmacRJ(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ຒ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧๆีะࠫຓ"),cjbAkCIinvs(u"ࠨวุ่ฬำࠧດ"),UighHKAfySm4PWErqJ(u"ࠩัีําࠧຕ"),cJSNFCIhymEfx6grGu0M(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ຖ"),rr7Xolsp4JwjPK3L(u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩທ")+WqRyTj7eaJPBIxsUfHYKVEz42iLvck+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬຘ"))
	if z5zsxSmjpGVIoJ6OT==vCmnFshSi4flecXIY2gy38G0DJw(u"࠵ᆡ"):
		if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(file):
			try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(file)
			except: pass
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩນ"),rr7Xolsp4JwjPK3L(u"ࠧห็ุ้ࠣำࠠๆๆไࠤࠬບ")+WqRyTj7eaJPBIxsUfHYKVEz42iLvck)
	elif z5zsxSmjpGVIoJ6OT==rxWDdRBIct57i90s(u"࠷ᆢ"):
		data = yBxCaXY5UwkD(file)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫປ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩຜ")+WqRyTj7eaJPBIxsUfHYKVEz42iLvck)
	return
def kmcbg9nCdV8WjiPTsEY1X5qOl():
	if F7aJYwLMEmxAVRupWf<wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠱࠹ᆣ"):
		JPhoBimWUM0Gu2H1Fe9fRv8 = yiaeCEwJjOcWA4ZSd5h(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭ຝ")+str(F7aJYwLMEmxAVRupWf)+iqHhJSxdaANDG5rlZm7B(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬພ")
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨຟ"),JPhoBimWUM0Gu2H1Fe9fRv8)
		return
	ZQclMw2RbJL = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(ETNq5t4MYngSsbfFD8J0v(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩຠ"))
	zc5UCovAZSP4i = EdSa1xYWFqh7AogkzZlV9ny([EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ມ")])
	GB7zx0pZDrQTeHCRW,xiqNzFvHcDmbfIE,yO1ZBje8kYEAaGm5npuHtqCb0,V1mlYuxHU5eiWZ8I6OvS4,HVlTv0ANEs8uMFZS2DO,UDSidyZh3JFxXQkt,AVLRS8cHkNwU4ZBfOqW2gudQtGEv = zc5UCovAZSP4i[wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧຢ")]
	if GB7zx0pZDrQTeHCRW or RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨຣ") not in str(ZQclMw2RbJL):
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭຤"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩລ"))
		pEU7uHoc0zQOC1Anab3KxZ9k = DDaB3jowumTvMeniEZIUf()
		if not pEU7uHoc0zQOC1Anab3KxZ9k: return
	J7JyRu984hsUoScZdVD5qHnYOIbjvE(P5VqbRSzjtO4UE1rZaolG67XA)
	return
def J7JyRu984hsUoScZdVD5qHnYOIbjvE(showDialogs=P5VqbRSzjtO4UE1rZaolG67XA):
	ZQclMw2RbJL = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ຦"))
	if iqHhJSxdaANDG5rlZm7B(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬວ") not in str(ZQclMw2RbJL):
		if showDialogs:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪຨ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ຩ"))
		return
	jxOJzvtPeZEN16HFYW0ioU = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩສ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩຫ"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫ࠼࠸࠰ࡱࠩຬ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭ອ"))
	if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(jxOJzvtPeZEN16HFYW0ioU): return
	jnmXeb8f90Rpa6cFtsyDW2TJKLEr = open(jxOJzvtPeZEN16HFYW0ioU,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡲࡣࠩຮ")).read()
	if LTze51miOknVcslNF43WSA6vMjYZt: jnmXeb8f90Rpa6cFtsyDW2TJKLEr = jnmXeb8f90Rpa6cFtsyDW2TJKLEr.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	F10QztcXnowIdASjf4BE = oo9kuULlebNgpY0Om.findall(t2sCrJ0xbgDRkf(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧຯ"),jnmXeb8f90Rpa6cFtsyDW2TJKLEr,oo9kuULlebNgpY0Om.DOTALL)
	YZ1P8ELm5v7,psLlji9tbkF64Ax = F10QztcXnowIdASjf4BE[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	TTwIdln7C25kWMKsr = cJSNFCIhymEfx6grGu0M(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩະ")+YZ1P8ELm5v7+qTVF3icWwGXy5(u"ࠩ࠯ࠫັ")+psLlji9tbkF64Ax+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬາ")
	if showDialogs:
		LLsXS6CvjArfgcPk5l = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(ETNq5t4MYngSsbfFD8J0v(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩຳ"))
		if LLsXS6CvjArfgcPk5l==iqHhJSxdaANDG5rlZm7B(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨິ"): TTqi9PKphMHbv = dC3PsQJ0Ti28uYlov(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ີ")
		elif LLsXS6CvjArfgcPk5l==dC3PsQJ0Ti28uYlov(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ຶ"): TTqi9PKphMHbv = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭ື")
		else: TTqi9PKphMHbv = iAGgjwb7tVMmacRJ(u"ࠩๅ์ฬฬๅࠡลัี๎ຸ࠭")
		z5zsxSmjpGVIoJ6OT = YZL469QjvSV(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡧࡪࡴࡴࡦࡴູࠪ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ็๎วว็ࠣวำื้ࠨ຺"),bneABYmwFUH8GXphg0Kl2Sq(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬົ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭โ้ษษ้ࠥอไึ๊ิࠫຼ"),VHrIziKUDuNGXkMla(u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫຽ")+TTqi9PKphMHbv,FWqeEzO1i8Dn0ga(u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣࠫ຾")+ipjCIhwEXsbadR+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࠣวำะัࠡษ็ฦ๋ࠦๆ้฻ࠣห้่่ศศ่ࠤฬ๊ส๋ࠢอี๏ีࠠฤีอาิอๅ่ษࠣรࠦ࠭຿")+zzGfwLAyN5HTxUoJeaivY)
		if z5zsxSmjpGVIoJ6OT==EHUAyW2lQfe4LXmhgIGc(u"࠲ᆤ"): BbJgksZLtHdI2iWCpKzD = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ເ")
		elif z5zsxSmjpGVIoJ6OT==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠴ᆥ"): BbJgksZLtHdI2iWCpKzD = rr7Xolsp4JwjPK3L(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪແ")
		else: BbJgksZLtHdI2iWCpKzD = G9G0YqivIfmUWO8K
	else:
		LLsXS6CvjArfgcPk5l = amx9qJHkhw7oLdtVMG3.getSetting(ETNq5t4MYngSsbfFD8J0v(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪໂ"))
		if   LLsXS6CvjArfgcPk5l==G9G0YqivIfmUWO8K: z5zsxSmjpGVIoJ6OT = hhdGMSsBzel96obfEmrwiuLPOvq(u"࠳ᆦ")
		elif LLsXS6CvjArfgcPk5l==vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩໃ"): z5zsxSmjpGVIoJ6OT = VHrIziKUDuNGXkMla(u"࠵ᆧ")
		elif LLsXS6CvjArfgcPk5l==jR9YtmsgDX8nTQlMb6G3(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ໄ"): z5zsxSmjpGVIoJ6OT = DTF3Lwy9etRH8mI(u"࠷ᆨ")
		BbJgksZLtHdI2iWCpKzD = LLsXS6CvjArfgcPk5l
	if   z5zsxSmjpGVIoJ6OT==jR9YtmsgDX8nTQlMb6G3(u"࠶ᆩ"): JJIXwO0h8e9Y3Qv1y2VMGkDLPr = DTF3Lwy9etRH8mI(u"ࠨ࠷࠸࠰࠺࠺࠴࠭࠷࠸࠹ࠬ໅")
	elif z5zsxSmjpGVIoJ6OT==UighHKAfySm4PWErqJ(u"࠱ᆪ"): JJIXwO0h8e9Y3Qv1y2VMGkDLPr = cJSNFCIhymEfx6grGu0M(u"ࠩ࠸࠸࠹࠲࠵࠶࠷࠯࠹࠺࠭ໆ")
	elif z5zsxSmjpGVIoJ6OT==rxWDdRBIct57i90s(u"࠳ᆫ"): JJIXwO0h8e9Y3Qv1y2VMGkDLPr = VHrIziKUDuNGXkMla(u"ࠪ࠹࠺࠻ࠬ࠶࠷࠯࠹࠹࠺ࠧ໇")
	else: return
	amx9qJHkhw7oLdtVMG3.setSetting(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦ່ࠩ"),BbJgksZLtHdI2iWCpKzD)
	uf9A7ki2v0s6PHFUVSdeIE = yiaeCEwJjOcWA4ZSd5h(u"ࠬࡂࡶࡪࡧࡺࡷࡃ້࠭")+JJIXwO0h8e9Y3Qv1y2VMGkDLPr+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࠬࠨ໊")+psLlji9tbkF64Ax+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿໋ࠩ")
	qyQ8MvDhH94crSZbYaC = jnmXeb8f90Rpa6cFtsyDW2TJKLEr.replace(TTwIdln7C25kWMKsr,uf9A7ki2v0s6PHFUVSdeIE)
	if LTze51miOknVcslNF43WSA6vMjYZt: qyQ8MvDhH94crSZbYaC = qyQ8MvDhH94crSZbYaC.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	open(jxOJzvtPeZEN16HFYW0ioU,EHUAyW2lQfe4LXmhgIGc(u"ࠨࡹࡥࠫ໌")).write(qyQ8MvDhH94crSZbYaC)
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࠱ࡠࡹ࡙࡫ࡪࡰࠣࡈࡪ࡬ࡡࡶ࡮ࡷࠤ࡛࡯ࡥࡸࡵ࠽ࠤࡠࠦࠧໍ")+JJIXwO0h8e9Y3Qv1y2VMGkDLPr+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࠤࡢ࠭໎"))
	if showDialogs: oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(t2sCrJ0xbgDRkf(u"ࠫࡗ࡫࡬ࡰࡣࡧࡗࡰ࡯࡮ࠩࠫࠪ໏"))
	return
def Kcf5v79ikuaS2D6qgHVEZLh():
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ໐"),t2sCrJ0xbgDRkf(u"࠭ศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦรๅวุำฬืࠠใัํ้ࠥ࠴࠮࠯ࠢฦ์ࠥอๆห่้๋ࠢ๎ูࠡ็้ࠤฬูสฯัส้ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤศ๎ࠠๅัํ็๋ࠥิไๆฬࠤศิั๊ࠢอาฺࠦฬ่ษี็ࠥษๆห๋่ࠢฬࠦสฯืࠣฬ็๐ษࠡะ็ๆࠥอไๅ้ࠣࡠࡳࡢ࡮ࠡฯส์้ࠦสฮัํฯࠥอไษำ้ห๊าࠠฤ๊ࠣหฯ฻ไࠡสส่๊ฮัๆฮ่๊ࠣ฿ัโหࠣือฮࠠศๆุ่่๊ษࠡ฻้ำ่ࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำีࠡษ็ฮาี๊ฬษอࠤฬ๊ย็ࠢยࠫ໑"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==VHrIziKUDuNGXkMla(u"࠳ᆬ"): iEKQs7waFroJUNl58RH6()
	return
def eAFdIcjVlZ7OHzLgMUuaDiJ():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໒"),jR9YtmsgDX8nTQlMb6G3(u"ࠨ้ำหࠥอไๆ๊ๅ฽ฺ๋ࠥๅไ้๋ࠣࠦวๅ็ุำึ่ࠦ฻์ิࠤ๊฿ั้ใ้ࠣฯ๐๋ࠠำฯ฽๊ࠥไฺ็็ࠫ໓"))
	return
def rVs1jTFnup5XPoQ27d():
	TsWkBdGYqEAHmrx = ipjCIhwEXsbadR+iqHhJSxdaANDG5rlZm7B(u"ࠩอ฽ิอฯࠡึํ฽ฮࠦยๅ่ࠢั๊ีࠠๅี้อࠥ࠸࠰࠳࠳ࠣ࠾ࠥ࠭໔")+zzGfwLAyN5HTxUoJeaivY
	TsWkBdGYqEAHmrx += VHrIziKUDuNGXkMla(u"ࠪห้๋่ใ฻ࠣวิ์ว่ࠢไ๎์ࠦลฮืสส๏ฯࠠๅ฻าำࠥอไี์฼อࠥ็๊ࠡษ็฽ฬ๊ๅࠡฬ่ࠤัู๋่ษ้๋ࠣࠦฬๆ์฼ࠤฬ๊ๅึษาีࠥอไๆฬ๋ๅึฯࠠโ์ࠣห้หๆหำ้ฮࠥอไใัํ้ฮ่ࠦศๆฯำ๏ีษࠡษ็ั่๎ๅ๋หࠣ์ฬฺ๊๋ำࠣั่๎ๅ๋หࠣ์๊์ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆࠢฮ้ࠥะๅࠡฬ๋ั๏ี็ศ๋ࠢัุอศࠡษ็้฾ีไࠡฯึฬูࠥใศ่ࠣำํ๊ࠠศๆ฼ห้๋ࠠๅี้อࠥ࠸࠰࠳࠳ࠣ์์๐ࠠศๆศัฺอฦ๋หࠣห้ษอะอࠣ์ฬ๊รี็็ࠤฬ๊ส๋ࠢอ้ࠥ฿ๅๅ้สࠤๆ๐ࠠศๆึ๊ํอสࠡษ็฽ูืษࠡษ็้ฬ฼๊สࠩ໕")
	TsWkBdGYqEAHmrx += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+ETNq5t4MYngSsbfFD8J0v(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵࠩ໖")+zzGfwLAyN5HTxUoJeaivY
	zcbj21qWCFYL4MrS7R = ipjCIhwEXsbadR+jR9YtmsgDX8nTQlMb6G3(u"ࠬฮั็ษ่ะฺࠥัู๋ࠣห้๋ำๅ็ࠣ࠾ࠥ࠭໗")+zzGfwLAyN5HTxUoJeaivY
	zcbj21qWCFYL4MrS7R += wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭็้ࠢ฼ฬฬืษࠡ฻้ࠤอืๆศ็ฯࠤ๏๎แา่ࠢ฽้๎ๅศฬࠣัุอศ๋หࠣ็ะ๐ัสࠢอ๋๊ࠦฬๆ์฼ࠤฬ๊ๅิๆ่๎๋ࠦๅฬๆࠣวํ่วหࠢสฺ่๊วส๋ࠢวํ่วหࠢสู่่่โ๋ࠢห้ิำ้ใࠣ์ู้ไࠡษ็ๆ๊ื้ࠠล๋ๆฬะࠠศๆๅ้ึ่ࠦฤ์ูหࠥ๐่โำࠣีษ๐ษࠡษ็๋้อไࠡใํࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊่ࠦฤ์ูหࠥ็๊่ࠢอๆํ๐ๅࠡ็ํ่ฬี๊๊๊ࠡะึ๐้ࠠใํ๋ࠥษ๊ืษࠣฬาั้ࠠไิหฦฯࠠศๆๅีว์้ࠠลํฺฬࠦแ๋้ࠣหุะฮศำฬࠤํะแศฦ็ࠤํ็๊่ࠢฦๆํอไࠡ็้ืํฮษࠡๆ็ว๊อๅࠡ฻็๎ࠥ๎รๆ๊ิࠤศิั๊ࠢอ๋๊ࠦใๅ่ࠢื้๋ࠠ࠯ࠢส่อืๆศ็ฯࠤ๊้ส้สࠣฬ้เษࠡฮสๅฬࠦำไำหฮࠥ๎๊ิฬัำ๊ࠦๆูษ่ࠤํ๐ๆะ๊ีࠤฯำสࠡสํสฮ่๋่ࠦา์ืࠦใศฮํฮࠥ๎ๅฯืุࠤๆ่ืࠡๆฦะ์ุษࠡษ็์๏์ฯ้ิࠣ࠲ࠥอไๆ๊ๅ฽ࠥอไาี่๎๊ࠥไษำ้ห๊า่๊ࠠࠪ໘")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+rr7Xolsp4JwjPK3L(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸࠧ໙")+zzGfwLAyN5HTxUoJeaivY
	JPhoBimWUM0Gu2H1Fe9fRv8 = ssGdubC4mngM9D5SRc3Ye(u"ࠨ࡝ࡕࡘࡑࡣࠧ໚")+TsWkBdGYqEAHmrx+jR9YtmsgDX8nTQlMb6G3(u"ࠩ࡟ࡲࡡࡴ࡜࡯࡝ࡕࡘࡑࡣࠧ໛")+zcbj21qWCFYL4MrS7R
	tg6EQSH7P4(DTF3Lwy9etRH8mI(u"ࠪࡶ࡮࡭ࡨࡵࠩໜ"),G9G0YqivIfmUWO8K,JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def gKVfG6vwnYyOxlAH(BM9q472Scdmj0):
	ewXaFc6410BDW8dgYAzVR(gWhZuzBnwiUVx5RoGFc6O7Hb)
	YvSXiz5xrJEpUlDcA = nuDV6jzU0TEISJQ(BM9q472Scdmj0)
	for kQtFlTA5d9p8Lho in [FWqeEzO1i8Dn0ga(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ໝ"),cjbAkCIinvs(u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨໞ"),iAGgjwb7tVMmacRJ(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫໟ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࡢࡘࡘ࠭໠")]:
		if kQtFlTA5d9p8Lho in IIHKo82wPrNpgqCkQJOV: IIHKo82wPrNpgqCkQJOV.remove(kQtFlTA5d9p8Lho)
	UhZuB0G4InHX7s(ssGdubC4mngM9D5SRc3Ye(u"ࠨࡆࡒࡒࡆ࡚ࡉࡐࡐࡖࠫ໡"))
	id,agZ6rli0mxGfo8,pFGTX4fZNI9RB2xKOWAdsgb,HgbMUjLOaP43Ts6W,y4gZHwkYufl,reason = YvSXiz5xrJEpUlDcA[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	KKGHBLXWq6pkOx,HRTLBshamJ2 = HgbMUjLOaP43Ts6W.split(qTVF3icWwGXy5(u"ࠩ࡟ࡲࡀࡁࠧ໢"))
	zcbj21qWCFYL4MrS7R,eCfQMxBE8j9hYzNU3IVHSp,yOmLxKSdh0sHAeQC2Wb = y4gZHwkYufl.split(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡠࡳࡁ࠻ࠨ໣"))
	JxGkgrqauU7OtMs = P5VqbRSzjtO4UE1rZaolG67XA
	while JxGkgrqauU7OtMs:
		hZsWy6qHlXvprULTd07gfScbNx = YZL469QjvSV(G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠫำื่อࠩ໤"),rr7Xolsp4JwjPK3L(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫ໥"),EHUAyW2lQfe4LXmhgIGc(u"࠭โศศ่อࠥอไหสิ฽ฬะࠧ໦"),UighHKAfySm4PWErqJ(u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧ໧"),zcbj21qWCFYL4MrS7R)
		if hZsWy6qHlXvprULTd07gfScbNx==jR9YtmsgDX8nTQlMb6G3(u"࠵ᆭ"): jbKo6ty8gPNYpxeBIkr5CVhuQAW = YZL469QjvSV(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠨ฻๋ำฮ࠭໨"),G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"่ࠩฬิษࠠศๆอฬึ฿ࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩ໩"),eCfQMxBE8j9hYzNU3IVHSp,bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺࠧ໪"))
		elif hZsWy6qHlXvprULTd07gfScbNx==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠵ᆮ"): H9dPKlWAyZ3OSi4D1()
		else: JxGkgrqauU7OtMs = kkMuQrLWcEayRm
	if BM9q472Scdmj0: Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def isGetm1hI0HZkD9E(showDialogs):
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = P5VqbRSzjtO4UE1rZaolG67XA
	if showDialogs: J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(dC3PsQJ0Ti28uYlov(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ໫"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ูࠬฤศๆࠪ໬"),EHUAyW2lQfe4LXmhgIGc(u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧ໭"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
		pEU7uHoc0zQOC1Anab3KxZ9k = P5VqbRSzjtO4UE1rZaolG67XA
		if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(NNan7CfOHFd0xDG3XvbPlwtuRpy):
			try: ifTNQtY3XrquHMV4wlCgI6FmpPK.remove(NNan7CfOHFd0xDG3XvbPlwtuRpy)
			except: pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
		if showDialogs:
			if pEU7uHoc0zQOC1Anab3KxZ9k: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠧห็ࠣฬ๋าวฮ่ࠢืา่ࠦหืไ๎ึࠦๅๅใࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ໮"))
			else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็็ๅࠥอไฦ฻าหิอสࠨ໯"))
	return
def HvfikBFNotw1yh():
	NNIuYUCkzqQpvexKShL3RBDrAOX8()
	aSUrspYVKzQBjv = amx9qJHkhw7oLdtVMG3.getSetting(DTF3Lwy9etRH8mI(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ໰"))
	JPhoBimWUM0Gu2H1Fe9fRv8 = {}
	JPhoBimWUM0Gu2H1Fe9fRv8[bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡅ࡚࡚ࡏࠨ໱")] = DTF3Lwy9etRH8mI(u"ࠫฬ๊ใศึࠣห้ะไใษษ๎ࠥ๐ูๆๆࠪ໲")
	JPhoBimWUM0Gu2H1Fe9fRv8[vCmnFshSi4flecXIY2gy38G0DJw(u"࡙ࠬࡔࡐࡒࠪ໳")] = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭วๅๅสุ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ໴")
	JPhoBimWUM0Gu2H1Fe9fRv8[RVpeGcmPxj9tCnT40Nf216(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ໵")] = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨๅสุࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦ࠮ࠡࠩ໶")+str(EwuAeDoaOmr2R7X3Qb6NhtJUF/DTF3Lwy9etRH8mI(u"࠻࠶ᆯ"))+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࠣำ็๐โสࠢไๆ฼࠭໷")
	cLwQGmMke6TxzCuEUA2V = JPhoBimWUM0Gu2H1Fe9fRv8[aSUrspYVKzQBjv]
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(G9G0YqivIfmUWO8K,bneABYmwFUH8GXphg0Kl2Sq(u"ࠪ็ฬฺࠠࠨ໸")+str(EwuAeDoaOmr2R7X3Qb6NhtJUF/ETNq5t4MYngSsbfFD8J0v(u"࠼࠰ᆰ"))+ETNq5t4MYngSsbfFD8J0v(u"ࠫࠥีโ๋ไฬࠫ໹"),dC3PsQJ0Ti28uYlov(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ໺"),cJSNFCIhymEfx6grGu0M(u"࠭ล๋ไสๅ้ࠥวๆๆࠪ໻"),cLwQGmMke6TxzCuEUA2V,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪ໼"))
	if z5zsxSmjpGVIoJ6OT==vCmnFshSi4flecXIY2gy38G0DJw(u"࠰ᆱ"): KKsugPAx0SCyL8Ormv54YUzd3I = RVpeGcmPxj9tCnT40Nf216(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ໽")
	elif z5zsxSmjpGVIoJ6OT==dC3PsQJ0Ti28uYlov(u"࠲ᆲ"): KKsugPAx0SCyL8Ormv54YUzd3I = cjbAkCIinvs(u"ࠩࡄ࡙࡙ࡕࠧ໾")
	elif z5zsxSmjpGVIoJ6OT==rxWDdRBIct57i90s(u"࠴ᆳ"): KKsugPAx0SCyL8Ormv54YUzd3I = cJSNFCIhymEfx6grGu0M(u"ࠪࡗ࡙ࡕࡐࠨ໿")
	else: KKsugPAx0SCyL8Ormv54YUzd3I = G9G0YqivIfmUWO8K
	if KKsugPAx0SCyL8Ormv54YUzd3I:
		amx9qJHkhw7oLdtVMG3.setSetting(iqHhJSxdaANDG5rlZm7B(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪༀ"),KKsugPAx0SCyL8Ormv54YUzd3I)
		Gl30NdHpLB9Cf4wxbcna8VXYsoArD = JPhoBimWUM0Gu2H1Fe9fRv8[KKsugPAx0SCyL8Ormv54YUzd3I]
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Gl30NdHpLB9Cf4wxbcna8VXYsoArD)
	return
def hhfMk7oiWDvwmOlSUEGQa():
	JPhoBimWUM0Gu2H1Fe9fRv8 = {}
	JPhoBimWUM0Gu2H1Fe9fRv8[UighHKAfySm4PWErqJ(u"ࠬࡇࡕࡕࡑࠪ༁")] = yiaeCEwJjOcWA4ZSd5h(u"࠭ำ๋ำไีࠥࡊࡎࡔࠢส่ฯ๊โศศํࠤ๏฿ๅๅ࠼ࠣࠫ༂")
	JPhoBimWUM0Gu2H1Fe9fRv8[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࡂࡕࡎࠫ༃")] = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨีํีๆืࠠࡅࡐࡖࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้࠽ࠤࠬ༄")
	JPhoBimWUM0Gu2H1Fe9fRv8[DTF3Lwy9etRH8mI(u"ࠩࡖࡘࡔࡖࠧ༅")] = dC3PsQJ0Ti28uYlov(u"ࠪื๏ืแาࠢࡇࡒࡘࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭༆")
	GTqnsutQ01Yb5pjyiwA = amx9qJHkhw7oLdtVMG3.getSetting(ETNq5t4MYngSsbfFD8J0v(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫ༇"))
	aSUrspYVKzQBjv = amx9qJHkhw7oLdtVMG3.getSetting(UighHKAfySm4PWErqJ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ༈"))
	cLwQGmMke6TxzCuEUA2V = JPhoBimWUM0Gu2H1Fe9fRv8[aSUrspYVKzQBjv]+GTqnsutQ01Yb5pjyiwA
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"࠭สี฼ํ่ࠥ฿ๆะࠢส่๊๎วโไฬࠫ༉"),t2sCrJ0xbgDRkf(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭༊"),yiaeCEwJjOcWA4ZSd5h(u"ࠨวํๆฬ็ࠠไษ่่ࠬ་"),cLwQGmMke6TxzCuEUA2V,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐โ้็ࠣฬฯำ่๋ๆࠣวุ๋วยࠢส่๊๎วใ฻ࠣ์ฬ๊ำ๋ำไีฬะࠠฦๆ์ࠤศืโศ็ࠣ์฾์ฯࠡส฼ฺࠥอไ็ษึࠤ๏่่ๆࠢหััฮ้ࠠ็้฽ࠥ๎อืำࠣฬ฾฼ࠠศๆ่์ฬู่ࠡ࠰่ࠣฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘࠦโๆࠢหหำะ๊ศำࠣหู้๊าใิࠤฬ๊ๅ็ษึฬࠥษ่ࠡไ่ࠤอห๊ใษไ๋ࠥฮวๅๅส้้࠭༌"))
	if z5zsxSmjpGVIoJ6OT==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠳ᆴ"): KKsugPAx0SCyL8Ormv54YUzd3I = DTF3Lwy9etRH8mI(u"ࠪࡅࡘࡑࠧ།")
	elif z5zsxSmjpGVIoJ6OT==iqHhJSxdaANDG5rlZm7B(u"࠵ᆵ"): KKsugPAx0SCyL8Ormv54YUzd3I = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡆ࡛ࡔࡐࠩ༎")
	elif z5zsxSmjpGVIoJ6OT==hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠷ᆶ"): KKsugPAx0SCyL8Ormv54YUzd3I = dhANiYPG7xXrSyJfIjZ8nBboLv(u"࡙ࠬࡔࡐࡒࠪ༏")
	if z5zsxSmjpGVIoJ6OT in [Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠰ᆸ"),FWqeEzO1i8Dn0ga(u"࠷ᆷ")]:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༐"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧิ์ิๅึࡀࠠࠨ༑")+vu5wBPhStlH2b7MR[fdQOo6Hu4B5Rbg],rxWDdRBIct57i90s(u"ࠨีํีๆื࠺ࠡࠩ༒")+vu5wBPhStlH2b7MR[dQ5JhEYolPmy1fvHktMw6NFRxiz],G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠩฦาฯอัࠡีํีๆืࠠࡅࡐࡖࠤฬ๊ๅ็ษึฬ๊ࠥใࠨ༓"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd==RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠲ᆹ"): hzOMx3BknjZywDgcqPeFbs = vu5wBPhStlH2b7MR[dQ5JhEYolPmy1fvHktMw6NFRxiz]
		else: hzOMx3BknjZywDgcqPeFbs = vu5wBPhStlH2b7MR[fdQOo6Hu4B5Rbg]
	elif z5zsxSmjpGVIoJ6OT==rr7Xolsp4JwjPK3L(u"࠴ᆺ"): hzOMx3BknjZywDgcqPeFbs = G9G0YqivIfmUWO8K
	else: KKsugPAx0SCyL8Ormv54YUzd3I = G9G0YqivIfmUWO8K
	if KKsugPAx0SCyL8Ormv54YUzd3I:
		amx9qJHkhw7oLdtVMG3.setSetting(RVpeGcmPxj9tCnT40Nf216(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭༔"),KKsugPAx0SCyL8Ormv54YUzd3I)
		amx9qJHkhw7oLdtVMG3.setSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫ༕"),hzOMx3BknjZywDgcqPeFbs)
		Gl30NdHpLB9Cf4wxbcna8VXYsoArD = JPhoBimWUM0Gu2H1Fe9fRv8[KKsugPAx0SCyL8Ormv54YUzd3I]+hzOMx3BknjZywDgcqPeFbs
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Gl30NdHpLB9Cf4wxbcna8VXYsoArD)
	return
def e9VKRSm7glUoE43FxyDTcB20sAzpI():
	aSUrspYVKzQBjv = amx9qJHkhw7oLdtVMG3.getSetting(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ༖"))
	JPhoBimWUM0Gu2H1Fe9fRv8 = {}
	JPhoBimWUM0Gu2H1Fe9fRv8[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡁࡖࡖࡒࠫ༗")] = ETNq5t4MYngSsbfFD8J0v(u"ࠧศๆหีํ้ำ๋ࠢส่ฯ๊โศศํࠤัอ็ำࠢ็่฾๋ไࠨ༘")
	JPhoBimWUM0Gu2H1Fe9fRv8[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡃࡖࡏ༙ࠬ")] = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩส่อื่ไีํࠤุ๐ูๆๆࠣฬ฾ีࠠศๆึ้ฬำࠠๅ้ࠪ༚")
	JPhoBimWUM0Gu2H1Fe9fRv8[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡗ࡙ࡕࡐࠨ༛")] = rr7Xolsp4JwjPK3L(u"ࠫฬ๊ศา๊ๆื๏ࠦๅห๊ๅๅࠥะๅศ็สࠤํฮวๅๅส้้࠭༜")
	cLwQGmMke6TxzCuEUA2V = JPhoBimWUM0Gu2H1Fe9fRv8[aSUrspYVKzQBjv]
	z5zsxSmjpGVIoJ6OT = YZL469QjvSV(G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ༝"),cjbAkCIinvs(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬ༞"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧฦ์ๅหๆࠦใศ็็ࠫ༟"),cLwQGmMke6TxzCuEUA2V,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨษ็ฬึ๎ใิ์๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎฾๋ไ๊ࠡึ๎฼ࠦศ๋่ࠣะ์อาไ๋ࠢห้หๆหำ้๎ฯࠦ࠮้๋ࠡࠤ๏ูสๅ็ࠣ฻้ฮวหๅࠣ์๏่่ๆࠢหืาฮ็ศࠢหำ้อࠠๆ่ๆࠤะ๋๋ࠠส฼ฯ์อࠠๅๅࠣ࠲ࠥํไࠡฬิ๎ิࠦสี฼ํ่ࠥษๅࠡวํๆฬ็ࠠศๆหีํ้ำ๋ࠢยࠫ༠"))
	if z5zsxSmjpGVIoJ6OT==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠳ᆻ"): KKsugPAx0SCyL8Ormv54YUzd3I = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡄࡗࡐ࠭༡")
	elif z5zsxSmjpGVIoJ6OT==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠵ᆼ"): KKsugPAx0SCyL8Ormv54YUzd3I = ssGdubC4mngM9D5SRc3Ye(u"ࠪࡅ࡚࡚ࡏࠨ༢")
	elif z5zsxSmjpGVIoJ6OT==jR9YtmsgDX8nTQlMb6G3(u"࠷ᆽ"): KKsugPAx0SCyL8Ormv54YUzd3I = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࡘ࡚ࡏࡑࠩ༣")
	else: KKsugPAx0SCyL8Ormv54YUzd3I = G9G0YqivIfmUWO8K
	if KKsugPAx0SCyL8Ormv54YUzd3I:
		amx9qJHkhw7oLdtVMG3.setSetting(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ༤"),KKsugPAx0SCyL8Ormv54YUzd3I)
		Gl30NdHpLB9Cf4wxbcna8VXYsoArD = JPhoBimWUM0Gu2H1Fe9fRv8[KKsugPAx0SCyL8Ormv54YUzd3I]
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Gl30NdHpLB9Cf4wxbcna8VXYsoArD)
	return
def PsDlWcYxmqKORzTaef49wgUoECp():
	K4Kil0vYfNmxOHLUgwyC = amx9qJHkhw7oLdtVMG3.getSetting(vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭༥"))
	if K4Kil0vYfNmxOHLUgwyC==t2sCrJ0xbgDRkf(u"ࠧࡔࡖࡒࡔࠬ༦"): header = ETNq5t4MYngSsbfFD8J0v(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧ༧")
	else: header = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧ༨")
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠪษ๏่วโࠩ༩"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫฯ็ู๋ๆࠪ༪"),header,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"่่ࠬศศ่ࠤฬ๊ศา่ส้ั๊ࠦห็ࠣฮาี๊ฬ้สࠤศ๎ส้็สฮ๏้๊ศࠢห฽ิࠦ࠱࠷ࠢึห฾ฯࠠๆ่ࠣวํ๊ࠠฤีอาิอๅࠡ࠰࠱ࠤํห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠤ๏สฯ๋ࠢศ่๎ࠦสฮัํฯ์อࠠโ์ࠣ็้ࠦๅาหࠣ๎ฯ๋ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢ࠱࠲ࠥ๎็ัษࠣ๎ุฮศࠡสฺสࠥ็๊ࠡใอั่่ࠥศศ่ࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ༫"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==-bneABYmwFUH8GXphg0Kl2Sq(u"࠷ᆾ"): return
	elif J8UB4bgrawlyzjYXA759Ee1c0N2fd:
		amx9qJHkhw7oLdtVMG3.setSetting(RVpeGcmPxj9tCnT40Nf216(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭༬"),cjbAkCIinvs(u"ࠧࡂࡗࡗࡓࠬ༭"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ༮"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩอ้ࠥะแฺ์็ࠤฯิา๋่ࠣห้่่ศศ่ࠫ༯"))
	else:
		amx9qJHkhw7oLdtVMG3.setSetting(RVpeGcmPxj9tCnT40Nf216(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ༰"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡘ࡚ࡏࡑࠩ༱"))
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༲"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ༳"))
	return
def jWpcKtBhSbmevDuyZzkXCJfg1sNYO0(Vvju9Ht8SGxoiTa6lCs):
	if Vvju9Ht8SGxoiTa6lCs!=G9G0YqivIfmUWO8K:
		Vvju9Ht8SGxoiTa6lCs = cpsXCrtE94DfY51mS(Vvju9Ht8SGxoiTa6lCs)
		Vvju9Ht8SGxoiTa6lCs = Vvju9Ht8SGxoiTa6lCs.decode(f3uIcZ2C6pzbX1JlFBrVOdt).encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		JJO5kzfVjQY7ZyEFd68tKgrLUboDPS = t2sCrJ0xbgDRkf(u"࠱࠱࠳࠳࠷ᆿ")
		vjBym4Uf38PAcFLwoDhItd6pgY = tDG1bZwX86UPjWEoVOJ.Window(JJO5kzfVjQY7ZyEFd68tKgrLUboDPS)
		vjBym4Uf38PAcFLwoDhItd6pgY.getControl(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠴࠳࠴ᇀ")).setLabel(Vvju9Ht8SGxoiTa6lCs)
	return
WoGJLltKnDSQ1 = [
			 RVpeGcmPxj9tCnT40Nf216(u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࡥࡻࡹࡰࡢࡥࡨࡷ࠵ࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧ༴")
			,ETNq5t4MYngSsbfFD8J0v(u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶ༵ࠫ")
			,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫ༶")
			,ETNq5t4MYngSsbfFD8J0v(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽ༷ࠬ")
			,cJSNFCIhymEfx6grGu0M(u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬ༸")
			,qTVF3icWwGXy5(u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ༹ࠧ")
			,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠬ༺")+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧࠤࠩ༻")+iqHhJSxdaANDG5rlZm7B(u"ࠨࡵࡶࡰ࠲ࡽࡡࡳࡰ࡬ࡲ࡬ࡹࠧ༼")
			,t2sCrJ0xbgDRkf(u"ࠩࡌࡲࡸ࡫ࡣࡶࡴࡨࡖࡪࡷࡵࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪ࠰ࠬ༽")
			,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡉࡷࡸ࡯ࡳࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࠳ࡄࡳ࡯ࡥࡧࡨࡁ࠵ࠬࡴࡦࡺࡷࡸࡂ࠭༾")
			,UighHKAfySm4PWErqJ(u"ࠫࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠴ࡷࡢࡴࡱࠬࠬ༿")
			,rr7Xolsp4JwjPK3L(u"ࠬࡤ࡞࡟ࡠࡡࠫཀ")
			,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫཁ")
			]
def BfNMgOtEGl(r5B4eRs8aPk2jzuUHCcnYGAN9dl):
	if jR9YtmsgDX8nTQlMb6G3(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬག") in r5B4eRs8aPk2jzuUHCcnYGAN9dl and FWqeEzO1i8Dn0ga(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭གྷ") in r5B4eRs8aPk2jzuUHCcnYGAN9dl: return P5VqbRSzjtO4UE1rZaolG67XA
	for Vvju9Ht8SGxoiTa6lCs in WoGJLltKnDSQ1:
		if Vvju9Ht8SGxoiTa6lCs in r5B4eRs8aPk2jzuUHCcnYGAN9dl: return P5VqbRSzjtO4UE1rZaolG67XA
	return kkMuQrLWcEayRm
def NI20LFWOM9EDxizJV8fdZq4tG5Hmas(data):
	B2BJzteTjqUf8mMSnEFV = rr7Xolsp4JwjPK3L(u"࠺ᇂ") if LTze51miOknVcslNF43WSA6vMjYZt else dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠳࠸ᇁ")
	data = data.replace(UighHKAfySm4PWErqJ(u"࠷࠵ᇃ")*ww0sZkBU9JKd,B2BJzteTjqUf8mMSnEFV*ww0sZkBU9JKd)
	data = data.replace(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࠣࡀ࡬࡫࡮ࡦࡴࡤࡰࡃࡀࠠࠨང"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪ࠾ࠥ࠭ཅ"))
	pPIbdY3oKe = G9G0YqivIfmUWO8K
	for r5B4eRs8aPk2jzuUHCcnYGAN9dl in data.splitlines():
		UBxXTALSKiOj7MQGCNY612p9PuJ = oo9kuULlebNgpY0Om.findall(cjbAkCIinvs(u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠭ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪཆ"),r5B4eRs8aPk2jzuUHCcnYGAN9dl,oo9kuULlebNgpY0Om.DOTALL)
		if UBxXTALSKiOj7MQGCNY612p9PuJ: r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(UBxXTALSKiOj7MQGCNY612p9PuJ[dQ5JhEYolPmy1fvHktMw6NFRxiz],G9G0YqivIfmUWO8K)
		pPIbdY3oKe += zEgtT9cR6bFp7JXqI5VuhNeP+r5B4eRs8aPk2jzuUHCcnYGAN9dl
	return pPIbdY3oKe
def sp1UYiZwoGLSjVEQJtzWvHOxaB6lC(HEgp6y3MKv):
	if FWqeEzO1i8Dn0ga(u"ࠬࡕࡌࡅࠩཇ") in HEgp6y3MKv:
		Jp13B8SToFmlr9eRGgiXN = tkYsz4jTx8NUoOILul0bqf9PKCMcV
		header = iqHhJSxdaANDG5rlZm7B(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭཈")
	else:
		Jp13B8SToFmlr9eRGgiXN = UcSsAurHXqJwR70DT1i
		header = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧཉ")
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,header,rxWDdRBIct57i90s(u"ࠨีฯ่ࠥอไฤะฺหฦ๊ࠦฮฬ๋๎ࠥษ๊ืษࠣ฽้๏ࠠิฮ็ࠤฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢห้อห็์้ࠤ฻ื่า์ฬࠤู้๋าใฬࠤ่๐แࠡฯาฯฯࠦวๅ็ื็้ฯ้ࠠ็สࠤ์๎ࠠศๆ่็ฬ์ࠠศๆำ๎ูࠥศษࠢะำํัࠠศๆุ่่๊ษࠡ࠰ࠣ็ํี๊ࠡ์ะฮๆ฾ࠠษีฯ่๏์ࠠ࠯ࠢส่ศ๎ไ้๋ࠡࠤฬ๊ำอๆࠣห้ำวๅ์ࠣ์ๆ๐็ࠡ็฼่ํ๋วหࠢอฬิษࠠๆ่ำࠤอีว๋หࠣห้ะิ฻์็ࠤฬ๊อศๆํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์ฬ๊้ࠡษ็ฦ๋ࠦ࠮ࠡล่หࠥอไิฮ็ࠤฬ๊โะ์่ࠤๆํ่ࠡษ็ืั๊ࠠศๆึหอ่ࠠศๆำ๎ࠥะๅࠡฮ่฽์ࠦๅ็ࠢหี๋อๅอࠢๆ์ิ๐ࠠใส็ࠤวิัࠡวฺๅฬวࠠๅ้ࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠫཊ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=jR9YtmsgDX8nTQlMb6G3(u"࠶ᇄ"): return
	UXCLFnmQGuTvMw37bY,aPJqUThKiZd = [],ssGdubC4mngM9D5SRc3Ye(u"࠶ᇅ")
	size,count = OSNKd3Zsh4GgE(Jp13B8SToFmlr9eRGgiXN)
	file = open(Jp13B8SToFmlr9eRGgiXN,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡵࡦࠬཋ"))
	if size>EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠲࠲࠳࠶࠵࠶ᇇ"): file.seek(-hhdGMSsBzel96obfEmrwiuLPOvq(u"࠱࠱࠲࠴࠴࠵ᇆ"),ifTNQtY3XrquHMV4wlCgI6FmpPK.SEEK_END)
	data = file.read()
	file.close()
	if LTze51miOknVcslNF43WSA6vMjYZt: data = data.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	data = NI20LFWOM9EDxizJV8fdZq4tG5Hmas(data)
	G5n4vArOfUz3CKS2o = data.split(zEgtT9cR6bFp7JXqI5VuhNeP)
	for r5B4eRs8aPk2jzuUHCcnYGAN9dl in reversed(G5n4vArOfUz3CKS2o):
		WP9iN7yaVMu = BfNMgOtEGl(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
		if WP9iN7yaVMu: continue
		r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡣࠬཌ"),ipjCIhwEXsbadR+RVpeGcmPxj9tCnT40Nf216(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧཌྷ")+zzGfwLAyN5HTxUoJeaivY)
		r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(jR9YtmsgDX8nTQlMb6G3(u"ࠬࡋࡒࡓࡑࡕ࠾ࠬཎ"),t2sCrJ0xbgDRkf(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉ࠴࠵࠶࠰࡞ࠩཏ")+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡆࡔࡕࡓࡗࡀࠧཐ")+zzGfwLAyN5HTxUoJeaivY)
		K6Coc2zfQ94r = G9G0YqivIfmUWO8K
		zzEY39yPTbMI0FV1uKXAcweOfGg4U6 = oo9kuULlebNgpY0Om.findall(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨད"),r5B4eRs8aPk2jzuUHCcnYGAN9dl,oo9kuULlebNgpY0Om.DOTALL)
		if zzEY39yPTbMI0FV1uKXAcweOfGg4U6:
			r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz],zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]).replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU],G9G0YqivIfmUWO8K)
			K6Coc2zfQ94r = zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]
		else:
			zzEY39yPTbMI0FV1uKXAcweOfGg4U6 = oo9kuULlebNgpY0Om.findall(UighHKAfySm4PWErqJ(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩདྷ"),r5B4eRs8aPk2jzuUHCcnYGAN9dl,oo9kuULlebNgpY0Om.DOTALL)
			if zzEY39yPTbMI0FV1uKXAcweOfGg4U6:
				r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg],G9G0YqivIfmUWO8K)
				K6Coc2zfQ94r = zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz]
		if K6Coc2zfQ94r: r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(K6Coc2zfQ94r,A7XhkmSYZlidyMt5FpWqTgjNezbnD+K6Coc2zfQ94r+zzGfwLAyN5HTxUoJeaivY)
		UXCLFnmQGuTvMw37bY.append(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
		if len(str(UXCLFnmQGuTvMw37bY))>EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷࠳࠵࠵࠶ᇈ"): break
	UXCLFnmQGuTvMw37bY = reversed(UXCLFnmQGuTvMw37bY)
	ScUC93fZ2ake0HtYRA = zEgtT9cR6bFp7JXqI5VuhNeP.join(UXCLFnmQGuTvMw37bY)
	tg6EQSH7P4(iqHhJSxdaANDG5rlZm7B(u"ࠪࡰࡪ࡬ࡴࠨན"),yiaeCEwJjOcWA4ZSd5h(u"ࠫวิัࠡลึ฻ึࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠨཔ"),ScUC93fZ2ake0HtYRA,VHrIziKUDuNGXkMla(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨཕ"))
	return
def IICTtWDm9UK3wJYqhjFZXf2():
	F8FqdsxfGbwnBLZtj = open(hEmTAjMeXOsyGxCn0pN8PHU2V,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡲࡣࠩབ")).read()
	if LTze51miOknVcslNF43WSA6vMjYZt: F8FqdsxfGbwnBLZtj = F8FqdsxfGbwnBLZtj.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	F8FqdsxfGbwnBLZtj = F8FqdsxfGbwnBLZtj.replace(yiaeCEwJjOcWA4ZSd5h(u"ࠧ࡝ࡶࠪབྷ"),yiaeCEwJjOcWA4ZSd5h(u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪམ"))
	zc5UCovAZSP4i = oo9kuULlebNgpY0Om.findall(dC3PsQJ0Ti28uYlov(u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪཙ"),F8FqdsxfGbwnBLZtj,oo9kuULlebNgpY0Om.DOTALL)
	for r5B4eRs8aPk2jzuUHCcnYGAN9dl in zc5UCovAZSP4i:
		F8FqdsxfGbwnBLZtj = F8FqdsxfGbwnBLZtj.replace(r5B4eRs8aPk2jzuUHCcnYGAN9dl,ipjCIhwEXsbadR+r5B4eRs8aPk2jzuUHCcnYGAN9dl+zzGfwLAyN5HTxUoJeaivY)
	FGHjRISMPqDg(rr7Xolsp4JwjPK3L(u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫཚ"),F8FqdsxfGbwnBLZtj)
	return
def ggPEuxzTXrIwyFShnWo2pCcb3():
	TsWkBdGYqEAHmrx = EHUAyW2lQfe4LXmhgIGc(u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭ཛ")
	zcbj21qWCFYL4MrS7R = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩཛྷ")
	eCfQMxBE8j9hYzNU3IVHSp = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩཝ")
	JPhoBimWUM0Gu2H1Fe9fRv8 = TsWkBdGYqEAHmrx+dC3PsQJ0Ti28uYlov(u"ࠧ࠻ࠢࠪཞ")+zcbj21qWCFYL4MrS7R+cJSNFCIhymEfx6grGu0M(u"ࠨࠢ࠱ࠤࠬཟ")+eCfQMxBE8j9hYzNU3IVHSp
	tg6EQSH7P4(UighHKAfySm4PWErqJ(u"ࠩࡦࡩࡳࡺࡥࡳࠩའ"),rr7Xolsp4JwjPK3L(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ཡ"),JPhoBimWUM0Gu2H1Fe9fRv8,rxWDdRBIct57i90s(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧར"))
	return
def PHxrpu4dEJInZf36qVWs7NwUtGDO(type,JPhoBimWUM0Gu2H1Fe9fRv8,showDialogs=P5VqbRSzjtO4UE1rZaolG67XA,url=G9G0YqivIfmUWO8K,XdoFLQ20O6SNVlcp=G9G0YqivIfmUWO8K,Vvju9Ht8SGxoiTa6lCs=G9G0YqivIfmUWO8K,CpcihqlUI3KrNf2w1Fxy98YMJRzn=G9G0YqivIfmUWO8K):
	wnhIgFs8pvA5RKeHy = P5VqbRSzjtO4UE1rZaolG67XA
	if not iKLYEvx39c.t6Xn5IBwJPG0so47MEif:
		if showDialogs:
			dw3XctLA6vnbDWeR = (VHrIziKUDuNGXkMla(u"ࠬอไิูิ࠾ࠬལ") in JPhoBimWUM0Gu2H1Fe9fRv8 and dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭วๅ็ๆห๋ࡀࠧཤ") in JPhoBimWUM0Gu2H1Fe9fRv8 and hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧศๆ่่ๆࡀࠧཥ") in JPhoBimWUM0Gu2H1Fe9fRv8 and dC3PsQJ0Ti28uYlov(u"ࠨษ็า฼ษࠧས") in JPhoBimWUM0Gu2H1Fe9fRv8 and bneABYmwFUH8GXphg0Kl2Sq(u"ࠩส่๊฻ฯา࠼ࠪཧ") in JPhoBimWUM0Gu2H1Fe9fRv8)
			if not dw3XctLA6vnbDWeR: wnhIgFs8pvA5RKeHy = xNVJH71kmLUIy3CjS9TDBQoYu5(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡧࡪࡴࡴࡦࡴࠪཨ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨཀྵ"),JPhoBimWUM0Gu2H1Fe9fRv8.replace(dC3PsQJ0Ti28uYlov(u"ࠬࡢ࡜࡯ࠩཪ"),zEgtT9cR6bFp7JXqI5VuhNeP))
	elif showDialogs:
		JPhoBimWUM0Gu2H1Fe9fRv8 = dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮ࠭ཫ")
		VCKYvUD9agR7qsZn3oHMl0zwr1J = xNVJH71kmLUIy3CjS9TDBQoYu5(rr7Xolsp4JwjPK3L(u"ࠧࡤࡧࡱࡸࡪࡸࠧཬ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ཭")+ssGdubC4mngM9D5SRc3Ye(u"ࠩࠣࠤ࠶࠵࠵ࠨ཮"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ཯"))
		ll7jnNW4zpSLmeCYoVcO0Q = xNVJH71kmLUIy3CjS9TDBQoYu5(qTVF3icWwGXy5(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ཰"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ཱࠬ")+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࠠࠡ࠴࠲࠹ིࠬ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อཱིࠬ"))
		ARlihEMmbvND8eIPjJVCWfYdzk0F = xNVJH71kmLUIy3CjS9TDBQoYu5(t2sCrJ0xbgDRkf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨུ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไཱུࠩ")+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪࠤࠥ࠹࠯࠶ࠩྲྀ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩཷ"))
		GGz5TB0QkHF7gPhw81tn9DXEZjI = xNVJH71kmLUIy3CjS9TDBQoYu5(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬླྀ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ཹ")+DTF3Lwy9etRH8mI(u"ࠧࠡࠢ࠷࠳࠺ེ࠭"),cJSNFCIhymEfx6grGu0M(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮཻ࠭"))
		wnhIgFs8pvA5RKeHy = xNVJH71kmLUIy3CjS9TDBQoYu5(jR9YtmsgDX8nTQlMb6G3(u"ࠩࡦࡩࡳࡺࡥࡳོࠩ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅཽࠪ")+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫࠥࠦ࠵࠰࠷ࠪཾ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪཿ"))
	agZ6rli0mxGfo8 = bVA4SCPumtZKi(kkMuQrLWcEayRm)
	OceyMEgRH4mCtPoNbuk9p8nADF2T = FWqeEzO1i8Dn0ga(u"࠭ࡁࡗ࠼ྀࠣࠫ")+agZ6rli0mxGfo8+iqHhJSxdaANDG5rlZm7B(u"ࠧ࠮ཱྀࠩ")+type
	tuhOpP4A07F8e = P5VqbRSzjtO4UE1rZaolG67XA if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫྂ") in Vvju9Ht8SGxoiTa6lCs else kkMuQrLWcEayRm
	if not wnhIgFs8pvA5RKeHy:
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬྃ"),cJSNFCIhymEfx6grGu0M(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้ࠦศ็ษฤࠤ฾ู๊้ࠡ็ฬ྄่࠭"))
		return kkMuQrLWcEayRm
	bbeVBn7FgG = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪ྅"))
	JPhoBimWUM0Gu2H1Fe9fRv8 += qTVF3icWwGXy5(u"ࠬࠦ࡜࡝ࡰ࡟ࡠࡳࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࡜࡝ࡰࡄࡨࡩࡵ࡮ࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ྆")+GBx0Fcf7sLbqlntEX3yMezu+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࠠ࠻࡞࡟ࡲࠬ྇")
	JPhoBimWUM0Gu2H1Fe9fRv8 += dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡆ࡯ࡤ࡭ࡱࠦࡓࡦࡰࡧࡩࡷࡀࠠࠨྈ")+agZ6rli0mxGfo8+DTF3Lwy9etRH8mI(u"ࠨࠢ࠽ࡠࡡࡴࡋࡰࡦ࡬ࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧྉ")+RM76u41Dy82UmfTqvEwhZ+t2sCrJ0xbgDRkf(u"ࠩࠣ࠾ࡡࡢ࡮ࠨྊ")
	JPhoBimWUM0Gu2H1Fe9fRv8 += vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡏࡴࡪࡩࠡࡐࡤࡱࡪࡀࠠࠨྋ")+bbeVBn7FgG
	tAPnOsC2Fi6WIRUdSQhJLclXHYTp = veFOcmHqAr1jfz()
	tAPnOsC2Fi6WIRUdSQhJLclXHYTp = SSX6oT0lADZhKRImPvCHFkYJs(tAPnOsC2Fi6WIRUdSQhJLclXHYTp)
	if tAPnOsC2Fi6WIRUdSQhJLclXHYTp: JPhoBimWUM0Gu2H1Fe9fRv8 += t2sCrJ0xbgDRkf(u"ࠫࠥࡀ࡜࡝ࡰࡏࡳࡨࡧࡴࡪࡱࡱ࠾ࠥ࠭ྌ")+tAPnOsC2Fi6WIRUdSQhJLclXHYTp
	if url: JPhoBimWUM0Gu2H1Fe9fRv8 += ssGdubC4mngM9D5SRc3Ye(u"ࠬࠦ࠺࡝࡞ࡱ࡙ࡗࡒ࠺ࠡࠩྍ")+url
	if XdoFLQ20O6SNVlcp: JPhoBimWUM0Gu2H1Fe9fRv8 += wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࠠ࠻࡞࡟ࡲࡘࡵࡵࡳࡥࡨ࠾ࠥ࠭ྎ")+XdoFLQ20O6SNVlcp
	JPhoBimWUM0Gu2H1Fe9fRv8 += cJSNFCIhymEfx6grGu0M(u"ࠧࠡ࠼࡟ࡠࡳ࠭ྏ")
	if showDialogs: XXeZuvhknsKYqB17gwm6dfc(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨฮสี๏ࠦวๅวิืฬ๊ࠧྐ"),cjbAkCIinvs(u"ࠩส่ึาวยࠢส่ฬ์สูษิࠫྑ"))
	if CpcihqlUI3KrNf2w1Fxy98YMJRzn:
		ScUC93fZ2ake0HtYRA = CpcihqlUI3KrNf2w1Fxy98YMJRzn
		if LTze51miOknVcslNF43WSA6vMjYZt: ScUC93fZ2ake0HtYRA = ScUC93fZ2ake0HtYRA.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		ScUC93fZ2ake0HtYRA = jaFsD83SB9ZQkrxeI.b64encode(ScUC93fZ2ake0HtYRA)
	elif tuhOpP4A07F8e:
		if iAGgjwb7tVMmacRJ(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪྒ") in Vvju9Ht8SGxoiTa6lCs: y81PTbXUCpj4dwhsrSGA5HNRauvi = tkYsz4jTx8NUoOILul0bqf9PKCMcV
		else: y81PTbXUCpj4dwhsrSGA5HNRauvi = UcSsAurHXqJwR70DT1i
		if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(y81PTbXUCpj4dwhsrSGA5HNRauvi):
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧྒྷ"),ssGdubC4mngM9D5SRc3Ye(u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪྔ"))
			return kkMuQrLWcEayRm
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,cJSNFCIhymEfx6grGu0M(u"࠭࠮࡝ࡶࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡵࡨࡲࡩࠦࡴࡩࡧࠣࡰࡴ࡭ࡦࡪ࡮ࡨࠫྕ"))
		UXCLFnmQGuTvMw37bY,aPJqUThKiZd = [],wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠳ᇉ")
		file = open(y81PTbXUCpj4dwhsrSGA5HNRauvi,dC3PsQJ0Ti28uYlov(u"ࠧࡳࡤࠪྖ"))
		size,count = OSNKd3Zsh4GgE(y81PTbXUCpj4dwhsrSGA5HNRauvi)
		if size>dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠷࠵࠷࠰࠱࠲ᇊ"): file.seek(-dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠷࠵࠷࠰࠱࠲ᇊ"),ifTNQtY3XrquHMV4wlCgI6FmpPK.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		data = NI20LFWOM9EDxizJV8fdZq4tG5Hmas(data)
		G5n4vArOfUz3CKS2o = data.splitlines()
		for r5B4eRs8aPk2jzuUHCcnYGAN9dl in reversed(G5n4vArOfUz3CKS2o):
			WP9iN7yaVMu = BfNMgOtEGl(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
			if WP9iN7yaVMu: continue
			zzEY39yPTbMI0FV1uKXAcweOfGg4U6 = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨྗ"),r5B4eRs8aPk2jzuUHCcnYGAN9dl,oo9kuULlebNgpY0Om.DOTALL)
			if zzEY39yPTbMI0FV1uKXAcweOfGg4U6:
				r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz],zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg]).replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU],G9G0YqivIfmUWO8K)
			else:
				zzEY39yPTbMI0FV1uKXAcweOfGg4U6 = oo9kuULlebNgpY0Om.findall(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ྘"),r5B4eRs8aPk2jzuUHCcnYGAN9dl,oo9kuULlebNgpY0Om.DOTALL)
				if zzEY39yPTbMI0FV1uKXAcweOfGg4U6: r5B4eRs8aPk2jzuUHCcnYGAN9dl = r5B4eRs8aPk2jzuUHCcnYGAN9dl.replace(zzEY39yPTbMI0FV1uKXAcweOfGg4U6[dQ5JhEYolPmy1fvHktMw6NFRxiz][fdQOo6Hu4B5Rbg],G9G0YqivIfmUWO8K)
			UXCLFnmQGuTvMw37bY.append(r5B4eRs8aPk2jzuUHCcnYGAN9dl)
			if len(str(UXCLFnmQGuTvMw37bY))>t2sCrJ0xbgDRkf(u"࠷࠻࠱࠱࠲࠳ᇋ"): break
		UXCLFnmQGuTvMw37bY = reversed(UXCLFnmQGuTvMw37bY)
		ScUC93fZ2ake0HtYRA = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡠࡷࡢ࡮ࠨྙ").join(UXCLFnmQGuTvMw37bY)
		ScUC93fZ2ake0HtYRA = ScUC93fZ2ake0HtYRA.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		ScUC93fZ2ake0HtYRA = jaFsD83SB9ZQkrxeI.b64encode(ScUC93fZ2ake0HtYRA)
	else: ScUC93fZ2ake0HtYRA = G9G0YqivIfmUWO8K
	url = Kkfl8xemuHbd1w3a0ABPcDrN[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫྚ")][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {qTVF3icWwGXy5(u"ࠬࡹࡵࡣ࡬ࡨࡧࡹ࠭ྛ"):OceyMEgRH4mCtPoNbuk9p8nADF2T,jR9YtmsgDX8nTQlMb6G3(u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧྜ"):JPhoBimWUM0Gu2H1Fe9fRv8,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧ࡭ࡱࡪࡪ࡮ࡲࡥࠨྜྷ"):ScUC93fZ2ake0HtYRA}
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,cjbAkCIinvs(u"ࠨࡒࡒࡗ࡙࠭ྞ"),url,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌ࠮࠳ࡶࡸࠬྟ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if UighHKAfySm4PWErqJ(u"ࠪࠦࡸࡻࡣࡤࡧࡨࡨࡪࡪࠢ࠻ࠢ࠴࠰ࠬྠ") in GagwMT6q3oc7UZ2Q: pEU7uHoc0zQOC1Anab3KxZ9k = P5VqbRSzjtO4UE1rZaolG67XA
	else: pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
	if showDialogs:
		if pEU7uHoc0zQOC1Anab3KxZ9k:
			XXeZuvhknsKYqB17gwm6dfc(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧྡ"),yiaeCEwJjOcWA4ZSd5h(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ྡྷ"))
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡍࡦࡵࡶࡥ࡬࡫ࠠࡴࡧࡱࡸࠬྣ"),ETNq5t4MYngSsbfFD8J0v(u"ࠧห็ࠣษึูวๅࠢส่ึูวๅหࠣฬ๋าวฮࠩྤ"))
		else:
			XXeZuvhknsKYqB17gwm6dfc(GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨๆ็วุ็ࠠโึ็ࠤฬ๊ลาีส่ࠬྥ"),ETNq5t4MYngSsbfFD8J0v(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪྦ"))
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྦྷ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩྨ"))
	return pEU7uHoc0zQOC1Anab3KxZ9k
def O2ea4X0Qzf():
	TsWkBdGYqEAHmrx = bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ࠷࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࡺ࡭ࡹ࡮ࠠࡂࡴࡤࡦ࡮ࡩࠠࡵࡧࡻࡸࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫྩ")
	zcbj21qWCFYL4MrS7R = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࠱࠯ࠢࠣࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊ࠡษ็วาืแࠡษ็฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨྪ")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࡂࡴࡤࡦ࡮ࡩࠠࡑࡴࡲࡦࡱ࡫࡭ࠨྫ"),TsWkBdGYqEAHmrx+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨ࡞ࡱࡠࡳ࠭ྫྷ")+zcbj21qWCFYL4MrS7R)
	TsWkBdGYqEAHmrx = ssGdubC4mngM9D5SRc3Ye(u"ࠩ࠵࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡤࡣࡱࡠࠬࡺࠠࡧ࡫ࡱࡨࠥࠨࡁࡳ࡫ࡤࡰࠧࠦࡦࡰࡰࡷࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡳ࡬࡫ࡱࠤࡦࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠨྭ")
	zcbj21qWCFYL4MrS7R = yiaeCEwJjOcWA4ZSd5h(u"ࠪ࠶࠳ࠦࠠࠡวำห๊ࠥๅࠡฬฯำࠥอไฯูࠣࠦࡆࡸࡩࡢ࡮ࠥࠤๆ่ๅࠡสอ฾๏๐ัࠡษ็ะ้ีࠠฬ็ࠣๆ๊ࠦศห฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪྮ")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠫࡋࡵ࡮ࡵࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪྯ"),TsWkBdGYqEAHmrx+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡢ࡮࡝ࡰࠪྰ")+zcbj21qWCFYL4MrS7R)
	TsWkBdGYqEAHmrx = t2sCrJ0xbgDRkf(u"࠭࠳࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤࡩࡵ࡮࡝ࠩࡷࠤ࡭ࡧࡶࡦࠢࡄࡶࡦࡨࡩࡤࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫྱ")
	zcbj21qWCFYL4MrS7R = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧ࠴࠰ࠣࠤࠥหะศࠢ็้ࠥ๐ใ็ࠢ็ำ๏้ࠠๅ๊ะอ๋ࠥแศฬํัࠥ฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥหูะษาหฯࠦวๅ็้฻็ฯࠠศๆฯ฾ึอแ๋หࠪྲ")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡈࡲࡲࡹࠦࡐࡳࡱࡥࡰࡪࡳࠧླ"),TsWkBdGYqEAHmrx+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡟ࡲࡡࡴࠧྴ")+zcbj21qWCFYL4MrS7R)
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡧࡪࡴࡴࡦࡴࠪྵ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫྶ"),t2sCrJ0xbgDRkf(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩྷ")+UighHKAfySm4PWErqJ(u"࠭࡜࡯࡞ࡱࠫྸ")+jR9YtmsgDX8nTQlMb6G3(u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧྐྵ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==t2sCrJ0xbgDRkf(u"࠷ᇌ"): QqlEynLcvGaf1K()
	return
def cCAOZ7PD8RpYi436m5SUKv0():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྺ"),UighHKAfySm4PWErqJ(u"ࠩ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬ๊ࠡ็่ฯษใะࠢๅ้ࠥฮสี฼ํ่ࠥอไาษห฻ࠥอไั์่ࠣฬฺ๊ࠦ็็ࠤะ๋ࠠใ็ࠣฬสืำศๆู้้ࠣไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣห้่วว็ฬࠤฬ๊ัว์ึ๎ฮࠦไๅสิ๊ฬ๋ฬࠨྻ"))
	return
def NNtCEoZPI5jasiedUnKgVW0():
	JPhoBimWUM0Gu2H1Fe9fRv8 = cJSNFCIhymEfx6grGu0M(u"๋ࠪีอࠠศๆหี๋อๅอ่ࠢาฺ฻ࠠโไฺࠤฺ้๊สࠢส่฾ืศ๋หࠣ์้้ๆ้ࠡำห๊ࠥวࠡ์่๊฾่ࠦอ๊าࠤ๊๎วใ฻ࠣๅ๏ํวࠡลไ่ฬ๋้ࠠ็ึุ่๊วห่ࠢฮึาๅสࠢฦ์๋ࠥฯษๆฯอࠥหไ๊ࠢส่้เษࠡษ็฽ึฮ๊ส๋ࠢห้๏ࠠๅ฼สฮࠥอฮา๋ࠣ์้อ๋๊ࠠฯำูࠥศษࠢ็่ฯ้ัศำࠪྼ")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ྽"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def PoCcVz5UWetLr9():
	JPhoBimWUM0Gu2H1Fe9fRv8 = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ྾")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ྿"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def cQrRS4Vh1jbgZqsBYCHymJfLw6():
	JPhoBimWUM0Gu2H1Fe9fRv8 = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫ࿀")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿁"),VHrIziKUDuNGXkMla(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫ࿂"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def rUoLJ1ph8HXIiW0b5wkGFjzAutd2C():
	JPhoBimWUM0Gu2H1Fe9fRv8 = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨ࿃")
	tg6EQSH7P4(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ࿄"),ssGdubC4mngM9D5SRc3Ye(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿅"),JPhoBimWUM0Gu2H1Fe9fRv8,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵ࿆ࠩ"))
	return
def zutsfRQq82TZO():
	TsWkBdGYqEAHmrx = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨ࿇")
	zcbj21qWCFYL4MrS7R = t2sCrJ0xbgDRkf(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪ࿈")
	eCfQMxBE8j9hYzNU3IVHSp = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ࿉")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿊"),TsWkBdGYqEAHmrx,zcbj21qWCFYL4MrS7R,eCfQMxBE8j9hYzNU3IVHSp)
	return
def NNIuYUCkzqQpvexKShL3RBDrAOX8():
	zcbj21qWCFYL4MrS7R = hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫฬ๊ใศึ๋ࠣํࠦๅฯิ้ࠤ๊สโหࠢ็่๊฿ไ้็สฮࠥ๐ำหะา้์ࠦวๅสิ๊ฬ๋ฬࠡๆัึ๋ࠦีโฯสฮࠥอไฦ่อี๋๐ส๊ࠡิ์ฬฮืࠡษ็ๅ๏ี๊้้สฮ๊ࠥไ้ื๋่ࠥหไ๋้สࠤอูัฺหࠣ์อี่็ࠢศ๊ฯืๆ๋ฬࠣ์ฬ๊ศา่ส้ั๊ࠦๆีะ๋ฬࠦสๅไสส๏อࠠษ฻าࠤฬ์ส่ษฤࠤ฾๋ั่ษࠣ์ศ๐ึศࠢ฼๊ิࠦสฮัํฯࠥอไษำ้ห๊าࠠ࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢํืฯิฯๆࠢึฬ฾ฯࠠฤ่๋ห฾ࠦไฺ็ิࠤฬ๊ใศึࠣ࠾ࠬ࿋")
	zcbj21qWCFYL4MrS7R += hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࡢ࡮࡝ࡰࠪ࿌") + jR9YtmsgDX8nTQlMb6G3(u"࠭࠱࠯ࠢฮหอะࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๅฺำ๋ๅࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ์็ศศํหࠥ๎ๅะฬ๊ࠤࠬ࿍") + str(UKDwMTZk9dni1JSLcf0oRXhqy/wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠶࠱ᇍ")/wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠶࠱ᇍ")/RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠳࠶ᇎ")/FWqeEzO1i8Dn0ga(u"࠵࠳ᇏ")) + cJSNFCIhymEfx6grGu0M(u"ࠧࠡึ๊ีࠬ࿎")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + FWqeEzO1i8Dn0ga(u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ࿏") + str(InpqoEf2WrlSe8/FWqeEzO1i8Dn0ga(u"࠹࠴ᇐ")/FWqeEzO1i8Dn0ga(u"࠹࠴ᇐ")/RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠶࠹ᇑ")) + DTF3Lwy9etRH8mI(u"ࠩࠣ๎ํ๋ࠧ࿐")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪ࠷࠳ࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋้ࠢหิืวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ࿑") + str(AH0BQ4LKlDMrfvqWmXn5/hhdGMSsBzel96obfEmrwiuLPOvq(u"࠻࠶ᇒ")/hhdGMSsBzel96obfEmrwiuLPOvq(u"࠻࠶ᇒ")/hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠸࠴ᇓ")) + qTVF3icWwGXy5(u"ࠫࠥ๐่ๆࠩ࿒")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + bneABYmwFUH8GXphg0Kl2Sq(u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ࿓") + str(TTm2opnt9fLX8DBYizbuSPvwhJZCl/wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠶࠱ᇔ")/wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠶࠱ᇔ")) + hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࠠิษ฼อࠬ࿔")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + t2sCrJ0xbgDRkf(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫ࿕") + str(HpjLKS83swXDzVInEf2xUZaCuNbR9d/iAGgjwb7tVMmacRJ(u"࠷࠲ᇕ")/iAGgjwb7tVMmacRJ(u"࠷࠲ᇕ")) + jR9YtmsgDX8nTQlMb6G3(u"ࠨࠢึห฾ฯࠧ࿖")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪ࿗") + str(PvAZ1fCRqL5F/wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠸࠳ᇖ")) + CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࠤิ่๊ใหࠪ࿘")
	zcbj21qWCFYL4MrS7R += zEgtT9cR6bFp7JXqI5VuhNeP + EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫ࠼࠴ࠠษั๋๊้ࠥวีࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠษีิ฽ฮ่ࠦๆัอ๋ࠥ࠭࿙") + str(gWhZuzBnwiUVx5RoGFc6O7Hb) + wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࠦฯใ์ๅอࠬ࿚")
	zcbj21qWCFYL4MrS7R += iqHhJSxdaANDG5rlZm7B(u"࠭࡜࡯࡞ࡱࠫ࿛") + Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧๆอ็ห࠿ࠦีโฯสฮ่่ࠥศศ่ࠤฬ๊รโๆส้ࠥ๎วๅ็ึุ่๊วห๋ࠢห้ำไใษอࠤ฾๋ั่ษࠣࠫ࿜") + str(TTm2opnt9fLX8DBYizbuSPvwhJZCl/cjbAkCIinvs(u"࠹࠴ᇗ")/cjbAkCIinvs(u"࠹࠴ᇗ")) + dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࠢึห฾ฯࠠ࠯ࠢฦ้ฬࠦโ้ษษ้ࠥษๆ้ษ฼ࠤฬ๊แ๋ัํ์์อสࠡใ฼้ึํวࠡࠩ࿝") + str(AH0BQ4LKlDMrfvqWmXn5/cjbAkCIinvs(u"࠹࠴ᇗ")/cjbAkCIinvs(u"࠹࠴ᇗ")/t2sCrJ0xbgDRkf(u"࠶࠹ᇘ")) + hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࠣว๏อๅࠡ࠰ࠣว๊อࠠๆๆไหฯࠦวๅใํำ๏๎ࠠโ฻่ี์อࠠࠨ࿞") + str(HpjLKS83swXDzVInEf2xUZaCuNbR9d/cjbAkCIinvs(u"࠹࠴ᇗ")/cjbAkCIinvs(u"࠹࠴ᇗ")) + rr7Xolsp4JwjPK3L(u"ࠪࠤุอูสࠢไๆ฼ࠦ࠮ࠡล่หࠥ็อึࠢิๆ๊ࠦวๅวุำฬืࠠโ฻่ี์ࠦࠧ࿟") + str(PvAZ1fCRqL5F/cjbAkCIinvs(u"࠹࠴ᇗ")) + bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࠥีโ๋ไฬࠤ࠳ࠦรๆษࠣๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛ࠦแฺ็ิ๋ࠥ࠭࿠") + str(gWhZuzBnwiUVx5RoGFc6O7Hb) + cJSNFCIhymEfx6grGu0M(u"ࠬࠦฯใ์ๅอࠬ࿡")
	tg6EQSH7P4(hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡲࡪࡩ࡫ࡸࠬ࿢"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧๆษ๋ࠣํࠦวๅๅสุࠥอไๆีอาิ๋ࠠโ์ࠣห้ฮั็ษ่ะࠬ࿣"),zcbj21qWCFYL4MrS7R,cJSNFCIhymEfx6grGu0M(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ࿤"))
	return
def kvJa7XZxUjGeI1tSlyL():
	JPhoBimWUM0Gu2H1Fe9fRv8 = UighHKAfySm4PWErqJ(u"ࠩส่ๆอีๅหࠣฮ฾์๊ࠡ็ฯ่ิࠦศ็ใึࠤฬูๅ่ࠢส่ศ฻ไ๋๋ࠢห้์โุหࠣฮ฾์๊ࠡล้ࠤฬ๊วิ็ࠣห้ษีๅ์ࠣฮ๊ࠦสฺัํ่์่ࠦโษุ่ฮ่ࠦ็ไฺอࠥะู็๋้ࠣั๊ฯ๊ࠡอ้ࠥะูะ์็ࠤฬูๅ่๋ࠢฬิ๎ๆࠡ฻็ห๊ฯࠠห฻้๎๋ࠥไโࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠬ࿥")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࿦"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def GpfRJdnDrU4l9M8KgskwtVSy():
	JPhoBimWUM0Gu2H1Fe9fRv8 = iqHhJSxdaANDG5rlZm7B(u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ࿧")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿨"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def bxPmSwAzpLTOuHB0GqvZXDkd1jJ48t():
	JPhoBimWUM0Gu2H1Fe9fRv8 = jR9YtmsgDX8nTQlMb6G3(u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ࿩")
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࿪"),JPhoBimWUM0Gu2H1Fe9fRv8)
	return
def JGL7Bogtk4fwcZh0():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿫"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ์ึวࠡษ็๊ํ฿ࠠๆ่ࠣห้็๊ะ์๋๋ฬะࠠ࡝ࡰࠣ๎ัฮࠠหใ฼๎้ࠦลืษไอࠥอำๆ้สࠤࡡࡴࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ࿬"))
	MJGPcFsKn9hfoukHbyOeS(EHUAyW2lQfe4LXmhgIGc(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ࿭"),P5VqbRSzjtO4UE1rZaolG67XA)
	return
def Q30DfSM7pEjYcaZgFu():
	JPhoBimWUM0Gu2H1Fe9fRv8  = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"๊ࠫสฮาษࠣๆฬ๋สࠡส฼ฺฺࠥัไษอࠤฬ๊ล็ฬิ๊ฯࠦวๅั๋่๏ࠦศุ้฼ࠤ฾อฦใูࠢำࠥอไษำส้ัࠦๅฬๆࠣ็ํี๊ࠡๆอื๊ำࠠโไฺࠤ้ฮูื่ࠢืฯิฯๆ์ࠣห้๋สึใะࠤออไะะ๋่๊ࠥๅ้ษๅ฽ࠥอไโ์า๎ํ࠭࿮")
	JPhoBimWUM0Gu2H1Fe9fRv8 += UighHKAfySm4PWErqJ(u"่ࠬࠦ็ฬํะฮࠦไ่าสࠤฬู๊ศศๅࠤๆอๆ่ࠢอๆึ๐ศศࠢฯ้๏฿ࠠๆีอาิ๋๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦไศࠢํืฯ฽ฺ๊๊้ࠤฬ๊ฯฯ๊็ࠤ้าๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠤาะ้ࠡ็฼ࠤฬูสฯัส้ࠬ࿯")
	JPhoBimWUM0Gu2H1Fe9fRv8 += zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭เ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำࠪ࿰")+zzGfwLAyN5HTxUoJeaivY+zEgtT9cR6bFp7JXqI5VuhNeP
	JPhoBimWUM0Gu2H1Fe9fRv8 += cJSNFCIhymEfx6grGu0M(u"ࠧ࡝ࡰ็ห๋ࠦ็ัษ่๋๊ࠣࠦฮๆࠣห้๋ิไๆฬࠤํหๆๆษࠣๅ็฽ࠠิ์ๅ์๊ࠦศฦื็หาࠦศฺุࠣห้๋่ศไ฼ࠤํหูศไฬࠤ๊๎วใ฻ࠣหำื้ࠡๅส๊ฯࠦสฺ็็ࠤุอศใษࠣฬิ๎ๆࠡ็ืห่๊ࠧ࿱")
	tg6EQSH7P4(jR9YtmsgDX8nTQlMb6G3(u"ࠨࡴ࡬࡫࡭ࡺࠧ࿲"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࿳"),JPhoBimWUM0Gu2H1Fe9fRv8,rxWDdRBIct57i90s(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭࿴"))
	JPhoBimWUM0Gu2H1Fe9fRv8 = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ࿵")
	JPhoBimWUM0Gu2H1Fe9fRv8 += zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ࿶")+zzGfwLAyN5HTxUoJeaivY
	JPhoBimWUM0Gu2H1Fe9fRv8 += wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭࡜࡯࡞ࡱࠫ࿷")+yiaeCEwJjOcWA4ZSd5h(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ࿸")
	JPhoBimWUM0Gu2H1Fe9fRv8 += zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪ࿹")+zzGfwLAyN5HTxUoJeaivY
	JPhoBimWUM0Gu2H1Fe9fRv8 += hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩ࡟ࡲࡡࡴࠧ࿺")+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫ࿻")
	JPhoBimWUM0Gu2H1Fe9fRv8 += A7XhkmSYZlidyMt5FpWqTgjNezbnD+EHUAyW2lQfe4LXmhgIGc(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭࿼")+zzGfwLAyN5HTxUoJeaivY
	tg6EQSH7P4(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡸࡩࡨࡪࡷࠫ࿽"),rr7Xolsp4JwjPK3L(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿾"),JPhoBimWUM0Gu2H1Fe9fRv8,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ࿿"))
	return
def WAFofPqR7UHJXiujKdkr3DTw():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨက"),rxWDdRBIct57i90s(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࠬခ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+rxWDdRBIct57i90s(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࠬဂ")+zzGfwLAyN5HTxUoJeaivY+qTVF3icWwGXy5(u"ࠫࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣࠫဃ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+yiaeCEwJjOcWA4ZSd5h(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫင")+zzGfwLAyN5HTxUoJeaivY)
	return
def sCpM1Gdnlz8XwLYIJO():
	NNIuYUCkzqQpvexKShL3RBDrAOX8()
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(VHrIziKUDuNGXkMla(u"࠭ࡣࡦࡰࡷࡩࡷ࠭စ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣห้้วีࠢยࠫဆ"),iqHhJSxdaANDG5rlZm7B(u"ࠨษ็็ฬฺ๋ࠠีิ฽ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤํ๋ำฮ้ࠣ๎฾๐ฯࠡีะฬࠥอไึใะหฯࠦๅ็ࠢส่ส์สา่อࠤ฾์ฯࠡษ็ัฬาษࠡว็๎์อ้ࠠษ็ุ้ำ๋ࠠฬ่ࠤฯ๊โศศํหࠥ฿ๆะࠢส๊ฯํวยࠢ฼้ึࠦวๅืไัฬะ้ࠠษ็ุ้ำࠠๅษࠣ๎฻ื้ࠠ็่็๋๊ࠦฮๆࠣฬ฾฼ࠠศๆุ่ฬ้ไࠨဇ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==ETNq5t4MYngSsbfFD8J0v(u"࠶ᇙ"):
		dfi8XnHqv2J3oxUSB5D7Rs1F6k(P5VqbRSzjtO4UE1rZaolG67XA)
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡสส่่อๅๅࠩဈ"),VHrIziKUDuNGXkMla(u"ࠪษีอࠠไษ้ฮࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥออะࠢส่๊๎วใ฻ࠣๅัืศࠡษ็้ํู่ࠡษ็ฦ๋ࠦ࠮࠯࠰ࠣ์ศึวࠡษ็ู้้ไส่ࠢืฯ๋ัสࠢไษี์ࠠศำึ่ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫဉ"))
	return J8UB4bgrawlyzjYXA759Ee1c0N2fd
def Ey7qhRWQ9KYcbICOo(showDialogs=P5VqbRSzjtO4UE1rZaolG67XA):
	if not showDialogs: showDialogs = P5VqbRSzjtO4UE1rZaolG67XA
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,cJSNFCIhymEfx6grGu0M(u"ࠫࡌࡋࡔࠨည"),rxWDdRBIct57i90s(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡹࡣࡰࡴࡱ࡫࠮ࡤࡱࡰࠫဋ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩဌ"))
	if not D7omduSeM5Gk.succeeded:
		J6JpQgGFkXs = kkMuQrLWcEayRm
		Oj5ehfpzir4o0kqCGwntHAugVQ = AyU7CaxXKirHj6kISTMR0d1mgZlJ4s(kkMuQrLWcEayRm)
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+EHUAyW2lQfe4LXmhgIGc(u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬဍ")+Oj5ehfpzir4o0kqCGwntHAugVQ+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࡟ࠪဎ"))
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬဏ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧတ"))
	else:
		J6JpQgGFkXs = P5VqbRSzjtO4UE1rZaolG67XA
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧထ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩဒ"))
	if not J6JpQgGFkXs and showDialogs: lPzvy9QJNqEoiD0()
	return J6JpQgGFkXs
def lPzvy9QJNqEoiD0():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩဓ"),cJSNFCIhymEfx6grGu0M(u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭န"))
	bS62AUkxiOP3Co()
	return
def H9dPKlWAyZ3OSi4D1(Vvju9Ht8SGxoiTa6lCs=G9G0YqivIfmUWO8K):
	tuhOpP4A07F8e = P5VqbRSzjtO4UE1rZaolG67XA
	if GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫပ") not in Vvju9Ht8SGxoiTa6lCs:
		tuhOpP4A07F8e = kkMuQrLWcEayRm
		z5zsxSmjpGVIoJ6OT = YZL469QjvSV(UighHKAfySm4PWErqJ(u"ࠩࡦࡩࡳࡺࡥࡳࠩဖ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪาึ๎ฬࠨဗ"),iAGgjwb7tVMmacRJ(u"ࠫสืำศๆู้้ࠣไสࠩဘ"),VHrIziKUDuNGXkMla(u"ࠬหัิษ็ࠤึูวๅหࠪမ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩယ"),FWqeEzO1i8Dn0ga(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯืำๅࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ัࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣว๋ࠦสาี็ࠤฺ๊ใๅห้ࠣํา่ะหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠪရ"))
		if z5zsxSmjpGVIoJ6OT in [-VHrIziKUDuNGXkMla(u"࠷ᇚ"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠰ᇛ")]: return
		elif z5zsxSmjpGVIoJ6OT==rr7Xolsp4JwjPK3L(u"࠲ᇜ"):
			tuhOpP4A07F8e = P5VqbRSzjtO4UE1rZaolG67XA
			Vvju9Ht8SGxoiTa6lCs = qTVF3icWwGXy5(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫလ")
	if tuhOpP4A07F8e:
		if UighHKAfySm4PWErqJ(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩဝ") not in Vvju9Ht8SGxoiTa6lCs:
			J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(ETNq5t4MYngSsbfFD8J0v(u"ࠪࡧࡪࡴࡴࡦࡴࠪသ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"ࠫํ฼ูࠡษ็ู้้ไสࠢไ๎ࠥอไิฮ็ࠫဟ"),qTVF3icWwGXy5(u"่ࠬศๅࠢศีุอไࠡษ็ืัฺ๊ࠠๆํ็ࠥษๆࠡฬๆีึࠦࠠ็ใึࠤฬ๊แฺๆࠣห้ึ๊ࠡล฼฻ฬ้ࠠศๆุ่่๊ษࠡ࠰่่ࠣ๐๋ࠠฬ่ࠤฯูฬ๋ๆ๋ࠣีํࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦ࠮๊ࠡหำํ์่ࠠาสࠤฬ๊สิฮํู่่ࠥโࠢอีุ๊ࠠๆๆไࠤ้อࠠโษษำฮࠦๅ็้่ࠣส์็ࠡๆสࠤ๏ำส้์ࠣ฽้๏ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦสา์าࠤฬ์สࠡษ็ษอ๊ว฻ࠢ฼๊์อࠠ࠯๊่่ࠢࠥๅหࠢหฮ่ืวาࠢสฺ่๊ใๅหࠣรࠬဠ"))
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=FWqeEzO1i8Dn0ga(u"࠳ᇝ"):
				hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠩအ"),rr7Xolsp4JwjPK3L(u"ࠧๅๆฦืๆࠦศะ๊้ࠤฯูฬ๋ๆࠣห้๋ิไๆฬࠤๆ๐ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢไห๋ࠦวๅ็หี๊าࠠๅษࠣ๎ุะื๋฻้ࠣ฾ืแสࠢสฺ่๊ใๅหࠣ์้อࠠฮๆ๊ห๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪဢ"))
				return
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫဣ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩไ๎ࠥอไีษือࠥอไใษา้ฮࠦอศ๊็ࠤศ์ࠠหๅอฬࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอ๋ࠢหูือࠡใํ๋ฬࠦวๅ็ื็้ฯࠠฤ๊ࠣห้๋่ื๊฼ࠤํหะศࠢฦีิะࠠอ๊สฬ๋ࠥๆࠡษ็้อืๅอࠢไษี์ࠠฤๅอฬࠥ฿ๆ้ษ้ࠤอื๊ะๅࠣว้หไไฬิ์๋๐ࠠศๆศ๎๊๐ไ๊ࠡอิ่ื้ࠠๆสࠤฯ์ำ๊ࠢฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ဤ"))
	search = ZT7zGWSCtpvfmwMNRjYrKL(header=GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࡛ࠪࡷ࡯ࡴࡦࠢࡤࠤࡲ࡫ࡳࡴࡣࡪࡩࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬဥ"),source=s5slfAmHkUtMR3WSKY1ZTX)
	if not search: return
	JPhoBimWUM0Gu2H1Fe9fRv8 = search
	if tuhOpP4A07F8e: type = t2sCrJ0xbgDRkf(u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬဦ")
	else: type = iqHhJSxdaANDG5rlZm7B(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪ࠭ဧ")
	pEU7uHoc0zQOC1Anab3KxZ9k = PHxrpu4dEJInZf36qVWs7NwUtGDO(type,JPhoBimWUM0Gu2H1Fe9fRv8,P5VqbRSzjtO4UE1rZaolG67XA,G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩဨ"),Vvju9Ht8SGxoiTa6lCs)
	return
def r6NtwShX8bk3Z14MipFY5Rzeo():
	Vvju9Ht8SGxoiTa6lCs = rxWDdRBIct57i90s(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫဩ")
	tg6EQSH7P4(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡴ࡬࡫࡭ࡺࠧဪ"),ssGdubC4mngM9D5SRc3Ye(u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩါ"),Vvju9Ht8SGxoiTa6lCs,rxWDdRBIct57i90s(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ာ"))
	Vvju9Ht8SGxoiTa6lCs = hhdGMSsBzel96obfEmrwiuLPOvq(u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧိ")
	tg6EQSH7P4(rxWDdRBIct57i90s(u"ࠬࡲࡥࡧࡶࠪီ"),UighHKAfySm4PWErqJ(u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫု"),Vvju9Ht8SGxoiTa6lCs,cJSNFCIhymEfx6grGu0M(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪူ"))
	return
def rhUs5P8mG3LFgjeBICNdTiqAQ():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫေ"),jR9YtmsgDX8nTQlMb6G3(u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧဲ"))
	bxPmSwAzpLTOuHB0GqvZXDkd1jJ48t()
	return
def UFAzPjG0cbLluvkifd3K7X45qHIZEg():
	TsWkBdGYqEAHmrx,zcbj21qWCFYL4MrS7R,eCfQMxBE8j9hYzNU3IVHSp,yOmLxKSdh0sHAeQC2Wb,dA6fDaLR43JBxml,B65QvNEcmanC0oUI4,paDuj0t6m5hJdNinX2kgo8AVUz9G = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,uDFZaxmorhpRIzV,hTNVEmJ1pltSD9B,lMY0tqi7XS6hwuBLk3rjd = {vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡥࠬဳ"):iAGgjwb7tVMmacRJ(u"ࠫࡦ࠭ဴ")},{},[],{}
	url = Kkfl8xemuHbd1w3a0ABPcDrN[ETNq5t4MYngSsbfFD8J0v(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬဵ")][fdQOo6Hu4B5Rbg]
	D7omduSeM5Gk = PPRoOyl2xVH(PvAZ1fCRqL5F,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡐࡐࡕࡗࠫံ"),url,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸ့ࠬ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨး"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࡘࡗࡆ္࠭"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰ်ࠫ"),rxWDdRBIct57i90s(u"࡚ࠫࡑࠧျ"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(yiaeCEwJjOcWA4ZSd5h(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬြ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡕࡂࡇࠪွ"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭ှ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡍࡖࡅࠬဿ"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ၀"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ၁"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ၂"),cjbAkCIinvs(u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ၃"))
	GagwMT6q3oc7UZ2Q = GagwMT6q3oc7UZ2Q.replace(cJSNFCIhymEfx6grGu0M(u"࠭࡟ࡠࡡࠪ၄"),zVnkcBX6aJDPRpqyCjhoSZYQbL)
	try: LGd8IczOvqgFM = bRCSwcA89e4J7pqdays5PxGiD2(dC3PsQJ0Ti28uYlov(u"ࠧ࡭࡫ࡶࡸࠬ၅"),GagwMT6q3oc7UZ2Q)
	except:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ၆"),cJSNFCIhymEfx6grGu0M(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ၇"))
		return
	xxmM4Lj0OwB3ZYC9A,BpGerqKlJ1ynWOIMCPNbwVASEZ745,TTjZPueyW6JxsmnDK2Sq7fpIO4h = LGd8IczOvqgFM
	lMY0tqi7XS6hwuBLk3rjd = {}
	HAsbSU2TK6NZJL1PijedWvRnh = [EHUAyW2lQfe4LXmhgIGc(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭၈"),yiaeCEwJjOcWA4ZSd5h(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪ၉")]
	OO6ihSLVjXsry08dYua5m2WDvEF = [EHUAyW2lQfe4LXmhgIGc(u"ࠬࡇࡌࡍࠩ၊"),UighHKAfySm4PWErqJ(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭။"),dC3PsQJ0Ti28uYlov(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ၌"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ၍"),cJSNFCIhymEfx6grGu0M(u"ࠩࡕࡉࡕࡕࡓࠨ၎")]+HAsbSU2TK6NZJL1PijedWvRnh+TMKgSsLYy0A429rkWvq+RvGE4rQKubUyZSa
	for oob2dzmG3jTMpZwQyIfN,Wv8EzDVjHC7dTunFch5JLO2bkXS6,xJidnqZm4s73BQjXYf2ClghKoIy in BpGerqKlJ1ynWOIMCPNbwVASEZ745:
		xJidnqZm4s73BQjXYf2ClghKoIy = zDBtm4MwIagkfcpE5oxJOAq6lZQY(xJidnqZm4s73BQjXYf2ClghKoIy)
		xJidnqZm4s73BQjXYf2ClghKoIy = xJidnqZm4s73BQjXYf2ClghKoIy.strip(ww0sZkBU9JKd).strip(ETNq5t4MYngSsbfFD8J0v(u"ࠪࠤ࠳࠭၏"))
		yOmLxKSdh0sHAeQC2Wb += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+oob2dzmG3jTMpZwQyIfN+iAGgjwb7tVMmacRJ(u"ࠫ࠿ࠦࠧၐ")+zzGfwLAyN5HTxUoJeaivY+xJidnqZm4s73BQjXYf2ClghKoIy+zEgtT9cR6bFp7JXqI5VuhNeP
		if Wv8EzDVjHC7dTunFch5JLO2bkXS6.isdigit():
			lMY0tqi7XS6hwuBLk3rjd[oob2dzmG3jTMpZwQyIfN] = int(Wv8EzDVjHC7dTunFch5JLO2bkXS6)
			if int(Wv8EzDVjHC7dTunFch5JLO2bkXS6)>VHrIziKUDuNGXkMla(u"࠴࠴࠵ᇞ"): Wv8EzDVjHC7dTunFch5JLO2bkXS6 = rxWDdRBIct57i90s(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨၑ")
			else: Wv8EzDVjHC7dTunFch5JLO2bkXS6 = EHUAyW2lQfe4LXmhgIGc(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨၒ")
		if oob2dzmG3jTMpZwQyIfN not in OO6ihSLVjXsry08dYua5m2WDvEF:
			if   Wv8EzDVjHC7dTunFch5JLO2bkXS6==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪၓ"): TsWkBdGYqEAHmrx += zVnkcBX6aJDPRpqyCjhoSZYQbL+oob2dzmG3jTMpZwQyIfN
			elif Wv8EzDVjHC7dTunFch5JLO2bkXS6==UighHKAfySm4PWErqJ(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪၔ"): zcbj21qWCFYL4MrS7R += zVnkcBX6aJDPRpqyCjhoSZYQbL+oob2dzmG3jTMpZwQyIfN
	DOTqc9eKXIfB2bilyFvJLPAE8Gszha,RkXzAGISs98TwnaohP6NFZJ253t,rZIShbgnHeGP7yiMQk = list(zip(*BpGerqKlJ1ynWOIMCPNbwVASEZ745))
	for oob2dzmG3jTMpZwQyIfN in sorted(jBCFu0HwftZ3XvQyOY):
		if oob2dzmG3jTMpZwQyIfN not in DOTqc9eKXIfB2bilyFvJLPAE8Gszha:
			yOmLxKSdh0sHAeQC2Wb += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+oob2dzmG3jTMpZwQyIfN+FWqeEzO1i8Dn0ga(u"ࠩ࠽ࠤࠬၕ")+zzGfwLAyN5HTxUoJeaivY+EHUAyW2lQfe4LXmhgIGc(u"่ࠪฬ๊้ࠦฮาࠫၖ")+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡡࡴ࡜࡯ࠩၗ")
			if oob2dzmG3jTMpZwQyIfN not in OO6ihSLVjXsry08dYua5m2WDvEF: eCfQMxBE8j9hYzNU3IVHSp += zVnkcBX6aJDPRpqyCjhoSZYQbL+oob2dzmG3jTMpZwQyIfN
	for xJidnqZm4s73BQjXYf2ClghKoIy,aPJqUThKiZd in xxmM4Lj0OwB3ZYC9A:
		xJidnqZm4s73BQjXYf2ClghKoIy = zDBtm4MwIagkfcpE5oxJOAq6lZQY(xJidnqZm4s73BQjXYf2ClghKoIy)
		dA6fDaLR43JBxml += xJidnqZm4s73BQjXYf2ClghKoIy+FWqeEzO1i8Dn0ga(u"ࠬࡀࠠࠨၘ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+str(aPJqUThKiZd)+zzGfwLAyN5HTxUoJeaivY+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࠠࠡࠢࠪၙ")
	TsWkBdGYqEAHmrx = TsWkBdGYqEAHmrx.strip(ww0sZkBU9JKd)
	zcbj21qWCFYL4MrS7R = zcbj21qWCFYL4MrS7R.strip(ww0sZkBU9JKd)
	eCfQMxBE8j9hYzNU3IVHSp = eCfQMxBE8j9hYzNU3IVHSp.strip(ww0sZkBU9JKd)
	p5pFzYmB2guQThMwVRsCkiZ1r = TsWkBdGYqEAHmrx+zVnkcBX6aJDPRpqyCjhoSZYQbL+zcbj21qWCFYL4MrS7R
	QeyRs9FTwZrf8ASa4uLdD6  = dC3PsQJ0Ti28uYlov(u"ࠧๆ๊สๆ฾ࠦๆอฯࠣห้ฮั็ษ่ะࠥฮสี฼ํ่ࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫၚ")+zEgtT9cR6bFp7JXqI5VuhNeP+jR9YtmsgDX8nTQlMb6G3(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ่์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั࠭ၛ")+zEgtT9cR6bFp7JXqI5VuhNeP
	QeyRs9FTwZrf8ASa4uLdD6 += A7XhkmSYZlidyMt5FpWqTgjNezbnD+p5pFzYmB2guQThMwVRsCkiZ1r+zzGfwLAyN5HTxUoJeaivY+jR9YtmsgDX8nTQlMb6G3(u"ࠩ࡟ࡲࡡࡴࠧၜ")
	QeyRs9FTwZrf8ASa4uLdD6 += RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩၝ")+zEgtT9cR6bFp7JXqI5VuhNeP+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไࠡๅห๎ึ่ࠦอ๊าࠤฺ๊ใๅหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨၞ")+zEgtT9cR6bFp7JXqI5VuhNeP
	QeyRs9FTwZrf8ASa4uLdD6 += A7XhkmSYZlidyMt5FpWqTgjNezbnD+eCfQMxBE8j9hYzNU3IVHSp+zzGfwLAyN5HTxUoJeaivY
	eYJAbjrBVLSWgidTR8,eervylTtNcGAJhbgEa05XdM,IehnjEWoiOVbS6PsMZ5yT1k02RA7,evsj9X2g7YfHLi = qTVF3icWwGXy5(u"࠴ᇟ"),qTVF3icWwGXy5(u"࠴ᇟ"),qTVF3icWwGXy5(u"࠴ᇟ"),qTVF3icWwGXy5(u"࠴ᇟ")
	all = lMY0tqi7XS6hwuBLk3rjd[VHrIziKUDuNGXkMla(u"ࠬࡇࡌࡍࠩၟ")]
	if yiaeCEwJjOcWA4ZSd5h(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ၠ") in list(lMY0tqi7XS6hwuBLk3rjd.keys()): eYJAbjrBVLSWgidTR8 = lMY0tqi7XS6hwuBLk3rjd[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧၡ")]
	if GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩၢ") in list(lMY0tqi7XS6hwuBLk3rjd.keys()): eervylTtNcGAJhbgEa05XdM = lMY0tqi7XS6hwuBLk3rjd[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪၣ")]
	if cjbAkCIinvs(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧၤ") in list(lMY0tqi7XS6hwuBLk3rjd.keys()): IehnjEWoiOVbS6PsMZ5yT1k02RA7 = lMY0tqi7XS6hwuBLk3rjd[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨၥ")]
	if rxWDdRBIct57i90s(u"ࠬࡘࡅࡑࡑࡖࠫၦ") in list(lMY0tqi7XS6hwuBLk3rjd.keys()): evsj9X2g7YfHLi = lMY0tqi7XS6hwuBLk3rjd[iAGgjwb7tVMmacRJ(u"࠭ࡒࡆࡒࡒࡗࠬၧ")]
	s6zlC3tBf9KerHjVdqb27W = all-eYJAbjrBVLSWgidTR8-eervylTtNcGAJhbgEa05XdM-IehnjEWoiOVbS6PsMZ5yT1k02RA7-evsj9X2g7YfHLi
	HHFwtdVPy2OZ,Bi61AQS4aWkynXjgfNxzU5 = TTjZPueyW6JxsmnDK2Sq7fpIO4h[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	HHFwtdVPy2OZ,kkowK8VemcPg = TTjZPueyW6JxsmnDK2Sq7fpIO4h[fdQOo6Hu4B5Rbg]
	ZbUQBIkXhlo3pR4stq5P0 = Bi61AQS4aWkynXjgfNxzU5-kkowK8VemcPg
	paDuj0t6m5hJdNinX2kgo8AVUz9G += ipjCIhwEXsbadR+str(kkowK8VemcPg)+zzGfwLAyN5HTxUoJeaivY+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧศๆ฼ำิࠦวๅฯๅ๎็๐ࠠๅๆฦะ์ุษࠡ࠼ࠣࠫၨ")
	paDuj0t6m5hJdNinX2kgo8AVUz9G += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(ZbUQBIkXhlo3pR4stq5P0)+zzGfwLAyN5HTxUoJeaivY+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬၩ")
	paDuj0t6m5hJdNinX2kgo8AVUz9G += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(Bi61AQS4aWkynXjgfNxzU5)+zzGfwLAyN5HTxUoJeaivY+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩส่฾ีฯࠡษ็็้๐ࠠๅฮ่๎฾ࠦวๅลฯ๋ืฯࠠ࠻ࠢࠪၪ")
	paDuj0t6m5hJdNinX2kgo8AVUz9G += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(len(TTjZPueyW6JxsmnDK2Sq7fpIO4h[EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷ᇠ"):]))+zzGfwLAyN5HTxUoJeaivY+VHrIziKUDuNGXkMla(u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨၫ")
	for JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA,agZ6rli0mxGfo8 in TTjZPueyW6JxsmnDK2Sq7fpIO4h[cJSNFCIhymEfx6grGu0M(u"࠸ᇡ"):]:
		JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA = zDBtm4MwIagkfcpE5oxJOAq6lZQY(JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA)
		JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA = JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA.strip(ww0sZkBU9JKd).strip(dC3PsQJ0Ti28uYlov(u"ࠫࠥ࠴ࠧၬ"))
		paDuj0t6m5hJdNinX2kgo8AVUz9G += JQYrOX8zxkTVtcLMfCwBGa7DvHpIlA+yiaeCEwJjOcWA4ZSd5h(u"ࠬࡀࠠࠨၭ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+str(agZ6rli0mxGfo8)+zzGfwLAyN5HTxUoJeaivY+iqHhJSxdaANDG5rlZm7B(u"࠭ࠠࠡࠢࠪၮ")
	B65QvNEcmanC0oUI4 += ipjCIhwEXsbadR+str(s6zlC3tBf9KerHjVdqb27W)+zzGfwLAyN5HTxUoJeaivY+dC3PsQJ0Ti28uYlov(u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬၯ")
	B65QvNEcmanC0oUI4 += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(eYJAbjrBVLSWgidTR8)+zzGfwLAyN5HTxUoJeaivY+ssGdubC4mngM9D5SRc3Ye(u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩၰ")
	B65QvNEcmanC0oUI4 += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(evsj9X2g7YfHLi)+zzGfwLAyN5HTxUoJeaivY+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่ืฯ๎ฯฺࠢ࠽ࠤࠬၱ")
	B65QvNEcmanC0oUI4 += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(eervylTtNcGAJhbgEa05XdM)+zzGfwLAyN5HTxUoJeaivY+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧၲ")
	B65QvNEcmanC0oUI4 += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(IehnjEWoiOVbS6PsMZ5yT1k02RA7)+zzGfwLAyN5HTxUoJeaivY+t2sCrJ0xbgDRkf(u"ࠫฯัศ๋ฬࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠻ࠢࠪၳ")
	B65QvNEcmanC0oUI4 += zEgtT9cR6bFp7JXqI5VuhNeP+ipjCIhwEXsbadR+str(len(xxmM4Lj0OwB3ZYC9A))+zzGfwLAyN5HTxUoJeaivY+dC3PsQJ0Ti28uYlov(u"ࠬี่ๅࠢื฾้ะࠠโ์า๎ํํวหࠢ࠽ࠤࠬၴ")
	B65QvNEcmanC0oUI4 += yiaeCEwJjOcWA4ZSd5h(u"࠭࡜࡯࡞ࡱࠫၵ")+dA6fDaLR43JBxml
	tg6EQSH7P4(DTF3Lwy9etRH8mI(u"ࠧࡤࡧࡱࡸࡪࡸࠧၶ"),rxWDdRBIct57i90s(u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨၷ"),paDuj0t6m5hJdNinX2kgo8AVUz9G,RVpeGcmPxj9tCnT40Nf216(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬၸ"))
	tg6EQSH7P4(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡧࡪࡴࡴࡦࡴࠪၹ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬၺ"),B65QvNEcmanC0oUI4,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨၻ"))
	tg6EQSH7P4(vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ၼ"),ssGdubC4mngM9D5SRc3Ye(u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪၽ"),QeyRs9FTwZrf8ASa4uLdD6,VHrIziKUDuNGXkMla(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫၾ"))
	tg6EQSH7P4(jR9YtmsgDX8nTQlMb6G3(u"ࠩ࡯ࡩ࡫ࡺࠧၿ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬႀ"),yOmLxKSdh0sHAeQC2Wb,ssGdubC4mngM9D5SRc3Ye(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬႁ"))
	return
def gJTKj6hEyFXavtVoflpc1():
	JPhoBimWUM0Gu2H1Fe9fRv8 = iqHhJSxdaANDG5rlZm7B(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴࠧႂ")+ipjCIhwEXsbadR+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬႃ")+zzGfwLAyN5HTxUoJeaivY+qTVF3icWwGXy5(u"ࠧ࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠡล๋ࠤฯำๅ๋ๆ๊ࠤ๊์࡜࡯ࠩႄ")+ipjCIhwEXsbadR+yiaeCEwJjOcWA4ZSd5h(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰࠩႅ")+zzGfwLAyN5HTxUoJeaivY+yiaeCEwJjOcWA4ZSd5h(u"ࠩ࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡลฯ์อฯࠠศๆหี๋อๅอࠩႆ")
	tg6EQSH7P4(ETNq5t4MYngSsbfFD8J0v(u"ࠪࡧࡪࡴࡴࡦࡴࠪႇ"),FWqeEzO1i8Dn0ga(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧႈ"),JPhoBimWUM0Gu2H1Fe9fRv8,vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨႉ"))
	return
def U5RhmxZzjcX4EB0HPb732Qu():
	JPhoBimWUM0Gu2H1Fe9fRv8 = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫႊ")+zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Kkfl8xemuHbd1w3a0ABPcDrN[iAGgjwb7tVMmacRJ(u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭ႋ")][dQ5JhEYolPmy1fvHktMw6NFRxiz]+zzGfwLAyN5HTxUoJeaivY+RVpeGcmPxj9tCnT40Nf216(u"ࠨࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡࠩႌ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Kkfl8xemuHbd1w3a0ABPcDrN[dC3PsQJ0Ti28uYlov(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨႍ")][fdQOo6Hu4B5Rbg]+zzGfwLAyN5HTxUoJeaivY
	JPhoBimWUM0Gu2H1Fe9fRv8 += DTF3Lwy9etRH8mI(u"ࠪࡠࡳࡢ࡮࡝ࡰส่ึอศุࠢฦำ๋อ็้๋ࠡࠤฬ๊ำ้ำึࠤฬ๊ะ๋ࠢํัฯอฬ่่ࠢำ๏ืࠠๆๆไหฯࠦใ้ัํࠤ้ะหษ์อࠤอืๆศ็ฯࠤ฾๋วะࠢหห้฽ั๋ไฬࠤฬ๊สใๆํำ๏ฯࠠศๆๅำ๏๋ษ࡝ࡰࠪႎ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Kkfl8xemuHbd1w3a0ABPcDrN[RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬႏ")][fdQOo6Hu4B5Rbg]+zzGfwLAyN5HTxUoJeaivY
	JPhoBimWUM0Gu2H1Fe9fRv8 += cJSNFCIhymEfx6grGu0M(u"ࠬࡢ࡮࡝ࡰ࡟ࡲัฺ๋๊่่ࠢๆอสࠡ฻่หิࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่๊๎โฺࠢฦำ๋อ็ࠨ႐")+zEgtT9cR6bFp7JXqI5VuhNeP+A7XhkmSYZlidyMt5FpWqTgjNezbnD+Kkfl8xemuHbd1w3a0ABPcDrN[CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ႑")][SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]+zzGfwLAyN5HTxUoJeaivY
	tg6EQSH7P4(qTVF3icWwGXy5(u"ࠧࡤࡧࡱࡸࡪࡸࠧ႒"),DTF3Lwy9etRH8mI(u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ႓"),JPhoBimWUM0Gu2H1Fe9fRv8,rxWDdRBIct57i90s(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ႔"))
	return
def ji1wWUSZ0Q4vYtqHma5bhJzTdN69M(p2HJkthUfdx7yM5FA):
	oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩ႕")+p2HJkthUfdx7yM5FA+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠫ࠮࠭႖"), P5VqbRSzjtO4UE1rZaolG67XA)
	return
def QqlEynLcvGaf1K():
	vlcUutakSyFDIi(cjbAkCIinvs(u"ࠬࡹࡴࡰࡲࠪ႗"))
	oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(qTVF3icWwGXy5(u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧ႘"))
	return
def bNytOahj1mDs2zIqirJUE7Z():
	oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(rr7Xolsp4JwjPK3L(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭႙"), P5VqbRSzjtO4UE1rZaolG67XA)
	return
def DtwnbuAhzpjI():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႚ"),yiaeCEwJjOcWA4ZSd5h(u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦร้ࠢสืฯิฯๆࠢࠥห้้๊ษ๊ิำ่ࠧࠦศุ฽฻ࠥ฿ไ๊ࠢะีๆࠦࠢࡄࠤࠣวํูࠦๅ๋ࠣห฻เืࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠩႛ"))
	return
def qvUK0GmIr3kPNfHn9X5ph():
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ႜ"),cjbAkCIinvs(u"้๊ࠫสฺษู่่๋ࠥࠡษ็้ๆ฼ไสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅำสฬ฼ࠦวๅาํࠤฯื๊ะࠢศฺฬ็ส่ࠢฦ์๋ࠥำฮ้้๋ࠣࠦࠠใษษ้ฮࠦวๅ็ไฺ้ฯ้ࠠๆๆ๊๊ࠥวࠡฬ้ๆึูࠦๅ์๊ࠤํ๊วࠡฬื฾้ํࠠ࠯๋ࠢฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎รๆษࠣฬฬูสฯัส้ࠥࠨวๅๅํฬํืฯࠣࠢไห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่ࠣ࠲ࠥ๎ๆโีࠣห้้ไศ็ࠣ์ฬ๊ืา์ๅอࠥ฿ๆะࠢส่ฯ฿วๆๆ้ࠣ฾ࠦๅฮฬ๋๎ฬะࠠใ๊สส๊ࠦวๅ็ไฺ้ฯࠧႝ"))
	return
def DDaB3jowumTvMeniEZIUf(UUQqJiHbwhjNGEDgkIYKZSecO0uf=wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ႞"),showDialogs=P5VqbRSzjtO4UE1rZaolG67XA):
	ZQclMw2RbJL = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(cJSNFCIhymEfx6grGu0M(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ႟"))
	data = EEMsy4SLwnD0T92ztchdIUZ.loads(ZQclMw2RbJL)
	QjaWmOkt8ozKSfnyL23NpM7 = data[t2sCrJ0xbgDRkf(u"ࠧࡳࡧࡶࡹࡱࡺࠧႠ")][RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡸࡤࡰࡺ࡫ࠧႡ")]
	if gA0m6CQUyfLG: QjaWmOkt8ozKSfnyL23NpM7 = QjaWmOkt8ozKSfnyL23NpM7.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႢ"),cJSNFCIhymEfx6grGu0M(u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨႣ")+QjaWmOkt8ozKSfnyL23NpM7+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭Ⴄ")+UUQqJiHbwhjNGEDgkIYKZSecO0uf+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࠦฟࠢࠩႥ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠱ᇢ"): return kkMuQrLWcEayRm
	pEU7uHoc0zQOC1Anab3KxZ9k,BUbwGAXyaiTV,IjPtLu6gvMFXhGy7l = ii9OThabCGVIQq8FK1kLUJe(UUQqJiHbwhjNGEDgkIYKZSecO0uf,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	if pEU7uHoc0zQOC1Anab3KxZ9k:
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႦ"),FWqeEzO1i8Dn0ga(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩႧ"))
		hh2WobBZGFs5Lp0EjISNHfwdMkKv = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬႨ")+UUQqJiHbwhjNGEDgkIYKZSecO0uf+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩࠥࢁࢂ࠭Ⴉ"))
		pEU7uHoc0zQOC1Anab3KxZ9k = P5VqbRSzjtO4UE1rZaolG67XA if Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠪࡓࡐ࠭Ⴊ") in hh2WobBZGFs5Lp0EjISNHfwdMkKv else kkMuQrLWcEayRm
		SSCU3jdyFn2V.sleep(cJSNFCIhymEfx6grGu0M(u"࠲ᇣ"))
		oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(t2sCrJ0xbgDRkf(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫႫ"))
	elif showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႬ"),cJSNFCIhymEfx6grGu0M(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨႭ"))
	return pEU7uHoc0zQOC1Anab3KxZ9k
def bS62AUkxiOP3Co():
	url = jR9YtmsgDX8nTQlMb6G3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮࡫ࡵࡶࡴࡸࡳ࠯࡭ࡲࡨ࡮࠴ࡴࡷ࠱ࡵࡩࡱ࡫ࡡࡴࡧࡶ࠳ࡼ࡯࡮ࡥࡱࡺࡷ࠴ࡽࡩ࡯࠸࠷࠳ࠬႮ")
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡉࡈࡘࠬႯ"),url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬႰ"))
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	tcOZsQ5WhubC = oo9kuULlebNgpY0Om.findall(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩႱ"),GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	tcOZsQ5WhubC = tcOZsQ5WhubC[dQ5JhEYolPmy1fvHktMw6NFRxiz].split(ssGdubC4mngM9D5SRc3Ye(u"ࠫ࠲࠭Ⴒ"))[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	kTLY2g7E0f5Kytdl = str(F7aJYwLMEmxAVRupWf)
	yOmLxKSdh0sHAeQC2Wb = ssGdubC4mngM9D5SRc3Ye(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆฦา๏ืࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧႳ")+ipjCIhwEXsbadR+tcOZsQ5WhubC+zzGfwLAyN5HTxUoJeaivY
	yOmLxKSdh0sHAeQC2Wb += dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭࡜࡯࡞ࡱࠫႴ")+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭Ⴕ")+ipjCIhwEXsbadR+kTLY2g7E0f5Kytdl+zzGfwLAyN5HTxUoJeaivY
	hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫႶ"),yOmLxKSdh0sHAeQC2Wb)
	return
def f45fOQwhD3icj1mqV():
	GKvBcR6wxUDWCs3YHAObS,yyWhlfQGTj,wOxYvdHue5MBLh = kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	cGoPVN0JQqM,HVzaGURPC8DcKg,K9amTnkhIXD = kkMuQrLWcEayRm,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4 = [dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧႷ"),EHUAyW2lQfe4LXmhgIGc(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬႸ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪႹ")]
	zc5UCovAZSP4i = EdSa1xYWFqh7AogkzZlV9ny(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4)
	for IJPabrdjXE7HGR163qY48pMVU5l in Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4:
		if IJPabrdjXE7HGR163qY48pMVU5l not in list(zc5UCovAZSP4i.keys()): continue
		GB7zx0pZDrQTeHCRW,lUCF7QjfxkSD6Id3JMaB2sy,Kkavce27DOol,fm1hjlvwnq5cPGbEOd3up6MRtLx8T,lBWo8JLrdaTHbiK5XC72vsU9cNPIF,TILKfFsNnkryg3De,R9xUITMGiXnVjtCqWdDFoO3NB = zc5UCovAZSP4i[IJPabrdjXE7HGR163qY48pMVU5l]
		if IJPabrdjXE7HGR163qY48pMVU5l==cJSNFCIhymEfx6grGu0M(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪႺ"):
			cGoPVN0JQqM = GB7zx0pZDrQTeHCRW
			HVzaGURPC8DcKg = lUCF7QjfxkSD6Id3JMaB2sy+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࠠࠡࠢࠣࠬࠥ࠭Ⴛ")+GoAEsgO4hHICi65(TILKfFsNnkryg3De)+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࠡࠫࠪႼ")
			K9amTnkhIXD = fm1hjlvwnq5cPGbEOd3up6MRtLx8T
		elif IJPabrdjXE7HGR163qY48pMVU5l==t2sCrJ0xbgDRkf(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪႽ"):
			GKvBcR6wxUDWCs3YHAObS = GKvBcR6wxUDWCs3YHAObS or GB7zx0pZDrQTeHCRW
			yyWhlfQGTj += RVpeGcmPxj9tCnT40Nf216(u"ࠩࠣࠤ࠱ࠦࠠࠨႾ")+lUCF7QjfxkSD6Id3JMaB2sy+dC3PsQJ0Ti28uYlov(u"ࠪࠤࠥࠦࠠࠩࠢࠪႿ")+GoAEsgO4hHICi65(TILKfFsNnkryg3De)+ETNq5t4MYngSsbfFD8J0v(u"ࠫࠥ࠯ࠧჀ")
			wOxYvdHue5MBLh += wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࠦࠠ࠭ࠢࠣࠫჁ")+fm1hjlvwnq5cPGbEOd3up6MRtLx8T
		elif IJPabrdjXE7HGR163qY48pMVU5l==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬჂ"):
			P0sRg2T7l84UhzY = GB7zx0pZDrQTeHCRW
			JbsSFfo1ilXeTpVNmYBykDvz = lUCF7QjfxkSD6Id3JMaB2sy+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠧࠡࠢࠣࠤ࠭ࠦࠧჃ")+GoAEsgO4hHICi65(TILKfFsNnkryg3De)+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠨࠢࠬࠫჄ")
			a3aBmJFzGqeQAb = fm1hjlvwnq5cPGbEOd3up6MRtLx8T
	yyWhlfQGTj = yyWhlfQGTj.strip(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࠣࠤ࠱ࠦࠠࠨჅ"))
	wOxYvdHue5MBLh = wOxYvdHue5MBLh.strip(rxWDdRBIct57i90s(u"ࠪࠤࠥ࠲ࠠࠡࠩ჆"))
	o7of6KbkMgVpnG53QZ0  = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩჇ")+ipjCIhwEXsbadR+K9amTnkhIXD+zzGfwLAyN5HTxUoJeaivY
	o7of6KbkMgVpnG53QZ0 += zEgtT9cR6bFp7JXqI5VuhNeP+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧ჈")+ipjCIhwEXsbadR+HVzaGURPC8DcKg+zzGfwLAyN5HTxUoJeaivY
	o7of6KbkMgVpnG53QZ0 += cJSNFCIhymEfx6grGu0M(u"࠭࡜࡯࡞ࡱࠫ჉")+jR9YtmsgDX8nTQlMb6G3(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ჊")+ipjCIhwEXsbadR+wOxYvdHue5MBLh+zzGfwLAyN5HTxUoJeaivY
	o7of6KbkMgVpnG53QZ0 += zEgtT9cR6bFp7JXqI5VuhNeP+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪ჋")+ipjCIhwEXsbadR+yyWhlfQGTj+zzGfwLAyN5HTxUoJeaivY
	o7of6KbkMgVpnG53QZ0 += CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩ࡟ࡲࡡࡴࠧ჌")+ETNq5t4MYngSsbfFD8J0v(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧჍ")+ipjCIhwEXsbadR+a3aBmJFzGqeQAb+zzGfwLAyN5HTxUoJeaivY
	o7of6KbkMgVpnG53QZ0 += zEgtT9cR6bFp7JXqI5VuhNeP+cjbAkCIinvs(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬ჎")+ipjCIhwEXsbadR+JbsSFfo1ilXeTpVNmYBykDvz+zzGfwLAyN5HTxUoJeaivY
	GB7zx0pZDrQTeHCRW = cGoPVN0JQqM or GKvBcR6wxUDWCs3YHAObS
	if GB7zx0pZDrQTeHCRW:
		header = UighHKAfySm4PWErqJ(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧ჏")
		DTUp9SXGQBRuy6a2OWVEKL7Pk = VHrIziKUDuNGXkMla(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧა")
	else:
		header = dC3PsQJ0Ti28uYlov(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨბ")
		DTUp9SXGQBRuy6a2OWVEKL7Pk = FWqeEzO1i8Dn0ga(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪგ")
	gkRpy0nfKFa1tQb48l3ZrC9qO = yiaeCEwJjOcWA4ZSd5h(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪდ")
	QYsK8uo0Sh9C = o7of6KbkMgVpnG53QZ0+rxWDdRBIct57i90s(u"ࠪࡠࡳࡢ࡮ࠨე")+DTUp9SXGQBRuy6a2OWVEKL7Pk+cjbAkCIinvs(u"ࠫࡡࡴ࡜࡯ࠩვ")+gkRpy0nfKFa1tQb48l3ZrC9qO
	tg6EQSH7P4(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡸࡩࡨࡪࡷࠫზ"),header,QYsK8uo0Sh9C,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩთ"))
	return GB7zx0pZDrQTeHCRW
def T7Zj25fv6JUF3DyI1g(IJPabrdjXE7HGR163qY48pMVU5l,R9xUITMGiXnVjtCqWdDFoO3NB,showDialogs):
	pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪი"),dC3PsQJ0Ti28uYlov(u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫკ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=fdQOo6Hu4B5Rbg: return kkMuQrLWcEayRm
	nNz63K5LvhmWlo4r = A7AmGFnBgYU63Dyl2hv4cP(R9xUITMGiXnVjtCqWdDFoO3NB,{},showDialogs)
	if nNz63K5LvhmWlo4r:
		C89v6yA24QZgn = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(wikRq4pjIX6Nx7d3lm,IJPabrdjXE7HGR163qY48pMVU5l)
		Sm8oLxifPQNzI(C89v6yA24QZgn,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
		import zipfile as vwk1P8MpYIDayhb,io as Hr2fBYRUWySpOPVjJ0Eq3TdDwQ
		e5xYbj7Xly = Hr2fBYRUWySpOPVjJ0Eq3TdDwQ.BytesIO(nNz63K5LvhmWlo4r)
		try:
			wY21fbX3ADTnGOqiPrH9pBd4x = vwk1P8MpYIDayhb.ZipFile(e5xYbj7Xly)
			wY21fbX3ADTnGOqiPrH9pBd4x.extractall(wikRq4pjIX6Nx7d3lm)
			SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(t2sCrJ0xbgDRkf(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ლ"))
			SSCU3jdyFn2V.sleep(fdQOo6Hu4B5Rbg)
			pEU7uHoc0zQOC1Anab3KxZ9k = QR8mJoqI4BOy7nDtGNWp6(IJPabrdjXE7HGR163qY48pMVU5l)
		except: pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
	if showDialogs:
		if pEU7uHoc0zQOC1Anab3KxZ9k: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭მ"),ssGdubC4mngM9D5SRc3Ye(u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨნ"))
		else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨო"),DTF3Lwy9etRH8mI(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫპ"))
	return pEU7uHoc0zQOC1Anab3KxZ9k
def MJGPcFsKn9hfoukHbyOeS(IJPabrdjXE7HGR163qY48pMVU5l,showDialogs=P5VqbRSzjtO4UE1rZaolG67XA):
	if showDialogs==G9G0YqivIfmUWO8K: showDialogs = P5VqbRSzjtO4UE1rZaolG67XA
	fhytpU9ATuCJ = pXtYw28arhDB4MlQ6CSz9ydFs([IJPabrdjXE7HGR163qY48pMVU5l])
	SdQxTMVyGqs2RtHr4em6WCzc0bgkBZ,RPAfQ3794OGch6aWkJFHXKEIvS = fhytpU9ATuCJ[IJPabrdjXE7HGR163qY48pMVU5l]
	if RPAfQ3794OGch6aWkJFHXKEIvS:
		pEU7uHoc0zQOC1Anab3KxZ9k = P5VqbRSzjtO4UE1rZaolG67XA
		if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪჟ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨใะูࠥอไฦุสๅฮࠦ࡜࡯ࠢࠪრ")+IJPabrdjXE7HGR163qY48pMVU5l+ssGdubC4mngM9D5SRc3Ye(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬს"))
	else:
		pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(cjbAkCIinvs(u"ࠪࡧࡪࡴࡴࡦࡴࠪტ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧუ"),G9G0YqivIfmUWO8K+IJPabrdjXE7HGR163qY48pMVU5l+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็ࠥเ๊า่ࠢๅ฾๊ษࠡล๋ࠤ฿๐ัࠡ็๋ะํีษࠡ࠰ࠣ๎ัฮࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ่่ࠣ๐๋ࠠ฻่่ࠥอไษำ้ห๊าฺ่ࠠา็ࠥฮี้ำฬࠤฺำ๊ฮหࠣ࠲ࠥํไࠡฬิ๎ิࠦสฬสํฮࠥ๎สโ฻ํ่ࠥํะ่ࠢส่ส฼วโหࠣห้ศๆࠡมࠪფ"))
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd==cJSNFCIhymEfx6grGu0M(u"࠳ᇤ"):
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(rr7Xolsp4JwjPK3L(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭ქ")+IJPabrdjXE7HGR163qY48pMVU5l+jR9YtmsgDX8nTQlMb6G3(u"ࠧࠪࠩღ"))
			SSCU3jdyFn2V.sleep(FWqeEzO1i8Dn0ga(u"࠴ᇥ"))
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(ETNq5t4MYngSsbfFD8J0v(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨყ"))
			SSCU3jdyFn2V.sleep(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠵ᇦ"))
			while oR7SuW56ZQcpXnswUMqIkrP.getCondVisibility(rr7Xolsp4JwjPK3L(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭შ")): SSCU3jdyFn2V.sleep(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠶ᇧ"))
			pEU7uHoc0zQOC1Anab3KxZ9k = QR8mJoqI4BOy7nDtGNWp6(IJPabrdjXE7HGR163qY48pMVU5l)
			if showDialogs and pEU7uHoc0zQOC1Anab3KxZ9k: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ჩ"),iAGgjwb7tVMmacRJ(u"ࠫฯ๋ࠠโฯุࠤศ๎ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪც"))
			elif showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨძ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭แีๆࠣๅ๏ࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ࠴้ࠠษ็ั้ࠦ็้ࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๋ࠥๆࠡะสีัࠦวๅสิ๊ฬ๋ฬࠨწ"))
	return pEU7uHoc0zQOC1Anab3KxZ9k
def YeaMu3GlvJApz(showDialogs):
	if not showDialogs: J8UB4bgrawlyzjYXA759Ee1c0N2fd = P5VqbRSzjtO4UE1rZaolG67XA
	else: J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡤࡧࡱࡸࡪࡸࠧჭ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ssGdubC4mngM9D5SRc3Ye(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫხ"),iqHhJSxdaANDG5rlZm7B(u"ࠩหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥฮูๆๆํอࠥะอะ์ฮࠤัฺ๋๊ࠢส่ส฼วโษอࠤฯ๊โศศํห้ࠥไࠡ࠴࠷ࠤุอูส๋่่ࠢ์ࠠๆ็ๆ๊ࠥหฬาษฤ๋ฬࠦวๅฤ้ࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢส่ว์ࠠภࠩჯ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠷ᇨ"):
		oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࡙ࠪࡵࡪࡡࡵࡧࡄࡨࡩࡵ࡮ࡓࡧࡳࡳࡸ࠭ჰ"))
		if showDialogs:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧჱ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬะๅࠡวิืฬุ๊ࠠๆหࠤส๊้ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦวๅาํࠤๆ๐ࠠอ้สึ่ࠦไไ์ࠣ๎็๎ๅࠡสอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤ࠳ࠦศๆษࠣๅ๏ํวࠡฬะำ๏ั่ࠠาสࠤฬ๊ศา่ส้ั่ࠦหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬჲ"))
	return
def iEKQs7waFroJUNl58RH6():
	aaSYfirqFBsp9IDRG7MAQtdLbxluV(FicKOG8M4gQsvf3naoU,t2sCrJ0xbgDRkf(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩჳ"),EHUAyW2lQfe4LXmhgIGc(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨჴ"))
	bS62AUkxiOP3Co()
	GB7zx0pZDrQTeHCRW = f45fOQwhD3icj1mqV()
	if GB7zx0pZDrQTeHCRW:
		hJXy9kqmV6gZe0C5bnuO1(P5VqbRSzjtO4UE1rZaolG67XA)
		YeaMu3GlvJApz(P5VqbRSzjtO4UE1rZaolG67XA)
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def QR8mJoqI4BOy7nDtGNWp6(IJPabrdjXE7HGR163qY48pMVU5l):
	tRojAyBgfDH37eLCwP4dWl = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫჵ")+IJPabrdjXE7HGR163qY48pMVU5l+rr7Xolsp4JwjPK3L(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧჶ"))
	succeeded = P5VqbRSzjtO4UE1rZaolG67XA if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡓࡐ࠭ჷ") in tRojAyBgfDH37eLCwP4dWl else kkMuQrLWcEayRm
	return succeeded
def JE8Nq3AR1FOu(IJPabrdjXE7HGR163qY48pMVU5l):
	tRojAyBgfDH37eLCwP4dWl = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧჸ")+IJPabrdjXE7HGR163qY48pMVU5l+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡪࡦࡲࡳࡦࡿࢀࠫჹ"))
	succeeded = P5VqbRSzjtO4UE1rZaolG67XA if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡏࡌࠩჺ") in tRojAyBgfDH37eLCwP4dWl else kkMuQrLWcEayRm
	return succeeded
def ii9OThabCGVIQq8FK1kLUJe(IJPabrdjXE7HGR163qY48pMVU5l,showDialogs,nZrYq53F7zjEw0CX29,zc5UCovAZSP4i=None):
	J8UB4bgrawlyzjYXA759Ee1c0N2fd,succeeded,BUbwGAXyaiTV,lUCF7QjfxkSD6Id3JMaB2sy = P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm,VHrIziKUDuNGXkMla(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ჻"),G9G0YqivIfmUWO8K
	if not zc5UCovAZSP4i: zc5UCovAZSP4i = EdSa1xYWFqh7AogkzZlV9ny([IJPabrdjXE7HGR163qY48pMVU5l])
	if IJPabrdjXE7HGR163qY48pMVU5l in list(zc5UCovAZSP4i.keys()):
		GB7zx0pZDrQTeHCRW,lUCF7QjfxkSD6Id3JMaB2sy,Kkavce27DOol,fm1hjlvwnq5cPGbEOd3up6MRtLx8T,lBWo8JLrdaTHbiK5XC72vsU9cNPIF,TILKfFsNnkryg3De,R9xUITMGiXnVjtCqWdDFoO3NB = zc5UCovAZSP4i[IJPabrdjXE7HGR163qY48pMVU5l]
		if TILKfFsNnkryg3De==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡩࡲࡳࡩ࠭ჼ"):
			succeeded,BUbwGAXyaiTV = P5VqbRSzjtO4UE1rZaolG67XA,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡱࡳࡹ࡮ࡩ࡯ࡩࠪჽ")
			if nZrYq53F7zjEw0CX29 and showDialogs:
				J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ჾ"),iAGgjwb7tVMmacRJ(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡๅ๋ำ๏๊ࠦิฬัำ๊ࠦรฯำࠣษฺีวา่ࠢฮํ็ัࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡๆ๊ิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫჿ")+IJPabrdjXE7HGR163qY48pMVU5l+DTF3Lwy9etRH8mI(u"ࠬࡢ࡮࡝ࡰ๊่ࠥะั๋ัࠣษ฾อฯสࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦๅาหࠣวำื้ࠨᄀ"))
				if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
					succeeded = T7Zj25fv6JUF3DyI1g(IJPabrdjXE7HGR163qY48pMVU5l,R9xUITMGiXnVjtCqWdDFoO3NB,kkMuQrLWcEayRm)
					if succeeded:
						BUbwGAXyaiTV = EHUAyW2lQfe4LXmhgIGc(u"࠭ࡲࡦ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫᄁ")
						if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄂ"),ETNq5t4MYngSsbfFD8J0v(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ๊๎ฬ้ัฬࠤ࠳࠴้ࠠไส้ࠥอไษำ้ห๊าࠠษว฼หิฯࠠหอห๎ฯํว࡝ࡰ࡟ࡲࠬᄃ")+IJPabrdjXE7HGR163qY48pMVU5l)
					else:
						BUbwGAXyaiTV = dC3PsQJ0Ti28uYlov(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᄄ")
						hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄅ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫᄆ")+IJPabrdjXE7HGR163qY48pMVU5l)
		else:
			if showDialogs:
				if TILKfFsNnkryg3De==DTF3Lwy9etRH8mI(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᄇ"): JPhoBimWUM0Gu2H1Fe9fRv8 = rxWDdRBIct57i90s(u"࠭ๅห๊ๅๅฮ࠭ᄈ")
				elif TILKfFsNnkryg3De==EHUAyW2lQfe4LXmhgIGc(u"ࠧࡰ࡮ࡧࠫᄉ"): JPhoBimWUM0Gu2H1Fe9fRv8 = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨไา๎๊ฯࠧᄊ")
				elif TILKfFsNnkryg3De==RVpeGcmPxj9tCnT40Nf216(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪᄋ"): JPhoBimWUM0Gu2H1Fe9fRv8 = cJSNFCIhymEfx6grGu0M(u"ࠪ฾๏ืࠠๆอหฮฮ࠭ᄌ")
				J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᄍ"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬํะ่ࠢส่ส฼วโหࠣࠫᄎ")+JPhoBimWUM0Gu2H1Fe9fRv8+yiaeCEwJjOcWA4ZSd5h(u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨᄏ")+IJPabrdjXE7HGR163qY48pMVU5l)
			if not J8UB4bgrawlyzjYXA759Ee1c0N2fd: BUbwGAXyaiTV = qTVF3icWwGXy5(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩᄐ")
			else:
				if TILKfFsNnkryg3De==VHrIziKUDuNGXkMla(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪᄑ"):
					succeeded = QR8mJoqI4BOy7nDtGNWp6(IJPabrdjXE7HGR163qY48pMVU5l)
					if succeeded:
						BUbwGAXyaiTV = UighHKAfySm4PWErqJ(u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪᄒ")
						if showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄓ"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩᄔ")+IJPabrdjXE7HGR163qY48pMVU5l)
					elif showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄕ"),bneABYmwFUH8GXphg0Kl2Sq(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ษ฻อแส่ࠢฮํ่แสࠢ࠱࠲ࠥ๎ไๆࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩᄖ")+IJPabrdjXE7HGR163qY48pMVU5l)
				elif TILKfFsNnkryg3De in [wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡰ࡮ࡧࠫᄗ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩᄘ")]:
					succeeded = T7Zj25fv6JUF3DyI1g(IJPabrdjXE7HGR163qY48pMVU5l,R9xUITMGiXnVjtCqWdDFoO3NB,kkMuQrLWcEayRm)
					if succeeded:
						if TILKfFsNnkryg3De==vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࡲࡰࡩ࠭ᄙ"): BUbwGAXyaiTV = FWqeEzO1i8Dn0ga(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫᄚ")
						elif TILKfFsNnkryg3De==VHrIziKUDuNGXkMla(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᄛ"): BUbwGAXyaiTV = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨᄜ")
						lUCF7QjfxkSD6Id3JMaB2sy = fm1hjlvwnq5cPGbEOd3up6MRtLx8T
						if showDialogs:
							if BUbwGAXyaiTV==rxWDdRBIct57i90s(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧᄝ"): hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄞ"),FWqeEzO1i8Dn0ga(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦใศ่อࠤ็ี๊ๆหࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหฯา๎ะํว࡝ࡰ࡟ࡲࠬᄟ")+IJPabrdjXE7HGR163qY48pMVU5l)
							elif BUbwGAXyaiTV==rr7Xolsp4JwjPK3L(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬᄠ"): hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᄡ"),cJSNFCIhymEfx6grGu0M(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢ็้ࠥะใ็่ࠢ์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหอห๎ฯํว࡝ࡰ࡟ࡲࠬᄢ")+IJPabrdjXE7HGR163qY48pMVU5l)
					elif showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᄣ"),bneABYmwFUH8GXphg0Kl2Sq(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩᄤ")+IJPabrdjXE7HGR163qY48pMVU5l)
	elif showDialogs: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cjbAkCIinvs(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄥ"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭ᄦ")+IJPabrdjXE7HGR163qY48pMVU5l)
	return succeeded,BUbwGAXyaiTV,lUCF7QjfxkSD6Id3JMaB2sy
def l0B5NMxSjdr8ta72PpHQsqTKuJ6DU(IJPabrdjXE7HGR163qY48pMVU5l,showDialogs,l3lioeVQPBuTU4k1sNKxwIpbGXFA,lXUSvLtWdTj8GHk0o3PKeM4=None,ww2WhlesJYXSLQBMZ6gdy4K7c=None):
	LUpMD39CSFIm1fPl2uekWRd = P5VqbRSzjtO4UE1rZaolG67XA if lXUSvLtWdTj8GHk0o3PKeM4 else kkMuQrLWcEayRm
	if not LUpMD39CSFIm1fPl2uekWRd:
		lXUSvLtWdTj8GHk0o3PKeM4 = Pkp47glurdBOS38Y.connect(xxXTUlvGQ15JZAV0CbIc7Ry3wkES)
		lXUSvLtWdTj8GHk0o3PKeM4.text_factory = str
		ww2WhlesJYXSLQBMZ6gdy4K7c = lXUSvLtWdTj8GHk0o3PKeM4.cursor()
	succeeded,WDu3VtOBxiYw47 = P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm
	try:
		wvH9784MLI = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫᄧ")
		ww2WhlesJYXSLQBMZ6gdy4K7c.execute(jR9YtmsgDX8nTQlMb6G3(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᄨ")+IJPabrdjXE7HGR163qY48pMVU5l+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࠧࠦ࠻ࠨᄩ"))
		E52cBHtlZuUM9TdNn3FGp7kVJ04m = ww2WhlesJYXSLQBMZ6gdy4K7c.fetchall()
		if E52cBHtlZuUM9TdNn3FGp7kVJ04m and wvH9784MLI not in str(E52cBHtlZuUM9TdNn3FGp7kVJ04m): ww2WhlesJYXSLQBMZ6gdy4K7c.execute(DTF3Lwy9etRH8mI(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩᄪ")+wvH9784MLI+t2sCrJ0xbgDRkf(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬᄫ")+IJPabrdjXE7HGR163qY48pMVU5l+FWqeEzO1i8Dn0ga(u"ࠧࠣࠢ࠾ࠫᄬ"))
		eKq7uNVGZ94LTwIYB = iAGgjwb7tVMmacRJ(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫᄭ") if gA0m6CQUyfLG else CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨᄮ")
		ww2WhlesJYXSLQBMZ6gdy4K7c.execute(cJSNFCIhymEfx6grGu0M(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫᄯ")+eKq7uNVGZ94LTwIYB+ETNq5t4MYngSsbfFD8J0v(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩᄰ")+IJPabrdjXE7HGR163qY48pMVU5l+EHUAyW2lQfe4LXmhgIGc(u"ࠬࠨࠠ࠼ࠩᄱ"))
		E52cBHtlZuUM9TdNn3FGp7kVJ04m = ww2WhlesJYXSLQBMZ6gdy4K7c.fetchall()
		if E52cBHtlZuUM9TdNn3FGp7kVJ04m:
			if showDialogs: J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᄲ"),rxWDdRBIct57i90s(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫᄳ")+IJPabrdjXE7HGR163qY48pMVU5l+cjbAkCIinvs(u"ࠨࠢ࡟ࡲࡡࡴࠠࠨᄴ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"้ࠩࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣࠫᄵ")+zzGfwLAyN5HTxUoJeaivY+yiaeCEwJjOcWA4ZSd5h(u"ࠪࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨᄶ"))
			else: J8UB4bgrawlyzjYXA759Ee1c0N2fd = fdQOo6Hu4B5Rbg
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg:
				WDu3VtOBxiYw47 = P5VqbRSzjtO4UE1rZaolG67XA
				ww2WhlesJYXSLQBMZ6gdy4K7c.execute(DTF3Lwy9etRH8mI(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠪᄷ")+eKq7uNVGZ94LTwIYB+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪᄸ")+IJPabrdjXE7HGR163qY48pMVU5l+iAGgjwb7tVMmacRJ(u"࠭ࠢࠡ࠽ࠪᄹ"))
		elif l3lioeVQPBuTU4k1sNKxwIpbGXFA:
			if showDialogs: J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᄺ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬᄻ")+IJPabrdjXE7HGR163qY48pMVU5l+bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩᄼ")+A7XhkmSYZlidyMt5FpWqTgjNezbnD+iAGgjwb7tVMmacRJ(u"ࠪࠤ๊็ูๅ๋ࠢ๎฾๋ไࠡ࠰࠱ࠤ์๊ࠠหำํำࠥห๊ใษไ๋ࠥอไร่ࠣรࠦࠧࠠࠨᄽ")+zzGfwLAyN5HTxUoJeaivY+jR9YtmsgDX8nTQlMb6G3(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩᄾ"))
			else: J8UB4bgrawlyzjYXA759Ee1c0N2fd = fdQOo6Hu4B5Rbg
			if J8UB4bgrawlyzjYXA759Ee1c0N2fd==fdQOo6Hu4B5Rbg:
				WDu3VtOBxiYw47 = P5VqbRSzjtO4UE1rZaolG67XA
				if gA0m6CQUyfLG: ww2WhlesJYXSLQBMZ6gdy4K7c.execute(rr7Xolsp4JwjPK3L(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠫᄿ")+eKq7uNVGZ94LTwIYB+iqHhJSxdaANDG5rlZm7B(u"࠭ࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ᅀ")+IJPabrdjXE7HGR163qY48pMVU5l+VHrIziKUDuNGXkMla(u"ࠧࠣࠫࠣ࠿ࠬᅁ"))
				else: ww2WhlesJYXSLQBMZ6gdy4K7c.execute(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠧᅂ")+eKq7uNVGZ94LTwIYB+jR9YtmsgDX8nTQlMb6G3(u"ࠩࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ᅃ")+IJPabrdjXE7HGR163qY48pMVU5l+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪᅄ"))
	except: succeeded = kkMuQrLWcEayRm
	if showDialogs and WDu3VtOBxiYw47:
		if succeeded: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅅ"),ETNq5t4MYngSsbfFD8J0v(u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ᅆ")+IJPabrdjXE7HGR163qY48pMVU5l)
		else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅇ"),cJSNFCIhymEfx6grGu0M(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣฮาี๊ฬࠢส่ส฼วโหࠣࡠࡳࡢ࡮ࠨᅈ")+IJPabrdjXE7HGR163qY48pMVU5l)
	if not LUpMD39CSFIm1fPl2uekWRd:
		lXUSvLtWdTj8GHk0o3PKeM4.commit()
		lXUSvLtWdTj8GHk0o3PKeM4.close()
		if WDu3VtOBxiYw47:
			SSCU3jdyFn2V.sleep(RVpeGcmPxj9tCnT40Nf216(u"࠱ᇩ"))
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬᅉ"))
			SSCU3jdyFn2V.sleep(t2sCrJ0xbgDRkf(u"࠲ᇪ"))
	return WDu3VtOBxiYw47
def dPyvmhpTxFLABWVr8Ht3Ml(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4,showDialogs,nZrYq53F7zjEw0CX29,l3lioeVQPBuTU4k1sNKxwIpbGXFA):
	lXUSvLtWdTj8GHk0o3PKeM4 = Pkp47glurdBOS38Y.connect(xxXTUlvGQ15JZAV0CbIc7Ry3wkES)
	lXUSvLtWdTj8GHk0o3PKeM4.text_factory = str
	ww2WhlesJYXSLQBMZ6gdy4K7c = lXUSvLtWdTj8GHk0o3PKeM4.cursor()
	zc5UCovAZSP4i = EdSa1xYWFqh7AogkzZlV9ny(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4)
	O4XkFcW17NjC2DzTHVEtfPQx6G = kkMuQrLWcEayRm
	for IJPabrdjXE7HGR163qY48pMVU5l in Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4:
		succeeded,BUbwGAXyaiTV,lUCF7QjfxkSD6Id3JMaB2sy = ii9OThabCGVIQq8FK1kLUJe(IJPabrdjXE7HGR163qY48pMVU5l,showDialogs,nZrYq53F7zjEw0CX29,zc5UCovAZSP4i)
		WDu3VtOBxiYw47 = l0B5NMxSjdr8ta72PpHQsqTKuJ6DU(IJPabrdjXE7HGR163qY48pMVU5l,showDialogs,l3lioeVQPBuTU4k1sNKxwIpbGXFA,lXUSvLtWdTj8GHk0o3PKeM4,ww2WhlesJYXSLQBMZ6gdy4K7c)
		if WDu3VtOBxiYw47: O4XkFcW17NjC2DzTHVEtfPQx6G = P5VqbRSzjtO4UE1rZaolG67XA
	lXUSvLtWdTj8GHk0o3PKeM4.commit()
	lXUSvLtWdTj8GHk0o3PKeM4.close()
	if O4XkFcW17NjC2DzTHVEtfPQx6G:
		SSCU3jdyFn2V.sleep(cJSNFCIhymEfx6grGu0M(u"࠳ᇫ"))
		oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(DTF3Lwy9etRH8mI(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ᅊ"))
		SSCU3jdyFn2V.sleep(dC3PsQJ0Ti28uYlov(u"࠴ᇬ"))
	if showDialogs:
		if len(Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4)>RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠵ᇭ"): hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᅋ"),FWqeEzO1i8Dn0ga(u"ࠫฯ๋ࠠษ่ฯหาࠦแฮืࠣะ๊๐ูࠡษ็ษ฻อแศฬࠪᅌ"))
		else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,rr7Xolsp4JwjPK3L(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᅍ"),yiaeCEwJjOcWA4ZSd5h(u"࠭สๆࠢห๊ัออࠡใะูࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪᅎ")+Q9lExyoCZ2dAWzG3huqPaKiTHV0Y4[cjbAkCIinvs(u"࠵ᇮ")])
	return
def hJXy9kqmV6gZe0C5bnuO1(showDialogs):
	hJ2dxun3Yav4SrDLmyfpQG9i1e = [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᅏ"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪᅐ"),dC3PsQJ0Ti28uYlov(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ᅑ"),t2sCrJ0xbgDRkf(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪᅒ")]
	wwtrTRLxNGAMXa7uQ = [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴࡯ࡵࡪࡨࡶࡸ࠭ᅓ"),iAGgjwb7tVMmacRJ(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡪ࠭ᅔ"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦࠩᅕ"),DTF3Lwy9etRH8mI(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩᅖ"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩᅗ"),dC3PsQJ0Ti28uYlov(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡨࡵࡤࡦࡤࡨࡶ࡬࠭ᅘ")]
	for IJPabrdjXE7HGR163qY48pMVU5l in wwtrTRLxNGAMXa7uQ: JE8Nq3AR1FOu(IJPabrdjXE7HGR163qY48pMVU5l)
	dPyvmhpTxFLABWVr8Ht3Ml(hJ2dxun3Yav4SrDLmyfpQG9i1e,showDialogs,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	return
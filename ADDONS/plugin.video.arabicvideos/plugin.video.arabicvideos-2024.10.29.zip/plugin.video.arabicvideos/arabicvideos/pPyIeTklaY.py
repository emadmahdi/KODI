# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
import xbmc as oR7SuW56ZQcpXnswUMqIkrP,re as oo9kuULlebNgpY0Om,sys as yyrcMwk6RWmH3xOKQUpGdghiX,xbmcaddon as K8EzSxPHWjcp,random as voWS3GzbN5HXaTsiwLMeU,os as ifTNQtY3XrquHMV4wlCgI6FmpPK,xbmcvfs as JJMb7fKtaDTQloFcdNjxRW6OCrn,time as SSCU3jdyFn2V,pickle as kk7pArQsGbMSUW32zO9lFImZadRo,zlib as opMdBjWmRv4GJU,xbmcgui as tDG1bZwX86UPjWEoVOJ,xbmcplugin as GWMro8TCBy2dNai,sqlite3 as Pkp47glurdBOS38Y,traceback as ISZeOrqTo0wGmLK3fEjHaD2n,threading as fu19TY0PdM6AZB5,hashlib as QzHB32naPjOLJ46,json as EEMsy4SLwnD0T92ztchdIUZ
import iKLYEvx39c
s5slfAmHkUtMR3WSKY1ZTX = ssGdubC4mngM9D5SRc3Ye(u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭य़")
G9G0YqivIfmUWO8K = UighHKAfySm4PWErqJ(u"࠭ࠧॠ")
ww0sZkBU9JKd = qTVF3icWwGXy5(u"ࠧࠡࠩॡ")
zVnkcBX6aJDPRpqyCjhoSZYQbL = ww0sZkBU9JKd*ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠲ଡ")
wKBSo48e5PYtn63DpiG = ww0sZkBU9JKd*RVpeGcmPxj9tCnT40Nf216(u"࠴ଢ")
MjuRWebwX0pfD = ww0sZkBU9JKd*hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠶ଣ")
P5VqbRSzjtO4UE1rZaolG67XA = dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࡘࡷࡻࡥ୫")
kkMuQrLWcEayRm = jR9YtmsgDX8nTQlMb6G3(u"ࡋࡧ࡬ࡴࡧ୬")
dQ5JhEYolPmy1fvHktMw6NFRxiz = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠳ତ")
fdQOo6Hu4B5Rbg = EHUAyW2lQfe4LXmhgIGc(u"࠵ଥ")
SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU = UighHKAfySm4PWErqJ(u"࠷ଦ")
c1R9fnIY4XBDZ = jR9YtmsgDX8nTQlMb6G3(u"࠹ଧ")
xsCEkXb6tgrh3195YZ = DTF3Lwy9etRH8mI(u"࠴ନ")
A7XhkmSYZlidyMt5FpWqTgjNezbnD = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫॢ")
ipjCIhwEXsbadR = ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬॣ")
HPYodKgEM7npNrRJmazXDxWA = yiaeCEwJjOcWA4ZSd5h(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭।")
a7aDsfFrVq20 = DTF3Lwy9etRH8mI(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧ॥")
zzGfwLAyN5HTxUoJeaivY = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ०")
f3uIcZ2C6pzbX1JlFBrVOdt = vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡵࡵࡨ࠻ࠫ१")
oz95q0dcEtSuxIJgP841M = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࡏࡑࡗࡍࡈࡋࠧ२")
ZQ6C9pmUGj4oIE12BJycX7 = UighHKAfySm4PWErqJ(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ३")
jT5y4a7sUiLJ8R = jR9YtmsgDX8nTQlMb6G3(u"ࠩࡈࡖࡗࡕࡒࠨ४")
DqJLhysGer98KFOZ = jR9YtmsgDX8nTQlMb6G3(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ५")
zEgtT9cR6bFp7JXqI5VuhNeP = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡡࡴࠧ६")
fXE2iwNYcD = FWqeEzO1i8Dn0ga(u"ࠬࡢࡲࠨ७")
ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J = K8EzSxPHWjcp.Addon().getAddonInfo(jR9YtmsgDX8nTQlMb6G3(u"࠭ࡰࡢࡶ࡫ࠫ८"))
eG1rm6ViLEIQ = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ocw8Kk7MNEIX29ur5hLqYSxv4gWG0J,cJSNFCIhymEfx6grGu0M(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ९"))
yyrcMwk6RWmH3xOKQUpGdghiX.path.append(eG1rm6ViLEIQ)
RM76u41Dy82UmfTqvEwhZ = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(EHUAyW2lQfe4LXmhgIGc(u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ॰"))
F7aJYwLMEmxAVRupWf = oo9kuULlebNgpY0Om.findall(qTVF3icWwGXy5(u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭ॱ"),RM76u41Dy82UmfTqvEwhZ,oo9kuULlebNgpY0Om.DOTALL)
F7aJYwLMEmxAVRupWf = float(F7aJYwLMEmxAVRupWf[dQ5JhEYolPmy1fvHktMw6NFRxiz])
OX803BEQFmdwexVbkhy9uz = oR7SuW56ZQcpXnswUMqIkrP.Player
EbOZKPeXIg = tDG1bZwX86UPjWEoVOJ.WindowXMLDialog
gA0m6CQUyfLG = F7aJYwLMEmxAVRupWf<DTF3Lwy9etRH8mI(u"࠲࠻଩")
LTze51miOknVcslNF43WSA6vMjYZt = F7aJYwLMEmxAVRupWf>FWqeEzO1i8Dn0ga(u"࠳࠻࠲࠾࠿ପ")
if LTze51miOknVcslNF43WSA6vMjYZt:
	K2XMCdoguZG1hAcLW4jSwReF9V5sQ = oR7SuW56ZQcpXnswUMqIkrP.LOGINFO
	Leu8GC4bRxh6How7I5U,wLgGlRoMI589yT6j1rvbW = t2sCrJ0xbgDRkf(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫॲ"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬॳ")
	eZgfQSTdy7pciUO4kjhur3IKb = JJMb7fKtaDTQloFcdNjxRW6OCrn.translatePath(cjbAkCIinvs(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ॴ"))
	from urllib.parse import unquote as _vOacUxEu2ZIFYrbN
else:
	K2XMCdoguZG1hAcLW4jSwReF9V5sQ = oR7SuW56ZQcpXnswUMqIkrP.LOGNOTICE
	Leu8GC4bRxh6How7I5U,wLgGlRoMI589yT6j1rvbW = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧॵ").encode(f3uIcZ2C6pzbX1JlFBrVOdt),RVpeGcmPxj9tCnT40Nf216(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨॶ").encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	eZgfQSTdy7pciUO4kjhur3IKb = oR7SuW56ZQcpXnswUMqIkrP.translatePath(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩॷ"))
	from urllib import unquote as _vOacUxEu2ZIFYrbN
SMyFu0CEQ6O9eB = hhdGMSsBzel96obfEmrwiuLPOvq(u"࠹࠴ଫ")
UadgtfoXpJGL9zZcKHq0yFnI = VHrIziKUDuNGXkMla(u"࠺࠵ବ")*SMyFu0CEQ6O9eB
mEbUloJpiHD90Skd45A2WMYKqORC = bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠺ଭ")*UadgtfoXpJGL9zZcKHq0yFnI
C8sYZL65TeNlJrB = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹࠰ମ")*mEbUloJpiHD90Skd45A2WMYKqORC
gWhZuzBnwiUVx5RoGFc6O7Hb = dQ5JhEYolPmy1fvHktMw6NFRxiz
PvAZ1fCRqL5F = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠳࠱ଯ")*SMyFu0CEQ6O9eB
HpjLKS83swXDzVInEf2xUZaCuNbR9d = SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU*UadgtfoXpJGL9zZcKHq0yFnI
TTm2opnt9fLX8DBYizbuSPvwhJZCl = cJSNFCIhymEfx6grGu0M(u"࠲࠸ର")*UadgtfoXpJGL9zZcKHq0yFnI
AH0BQ4LKlDMrfvqWmXn5 = c1R9fnIY4XBDZ*mEbUloJpiHD90Skd45A2WMYKqORC
InpqoEf2WrlSe8 = ETNq5t4MYngSsbfFD8J0v(u"࠵࠳଱")*mEbUloJpiHD90Skd45A2WMYKqORC
UKDwMTZk9dni1JSLcf0oRXhqy = FWqeEzO1i8Dn0ga(u"࠴࠶ଲ")*C8sYZL65TeNlJrB
EwuAeDoaOmr2R7X3Qb6NhtJUF = UadgtfoXpJGL9zZcKHq0yFnI
IJPabrdjXE7HGR163qY48pMVU5l = yyrcMwk6RWmH3xOKQUpGdghiX.argv[dQ5JhEYolPmy1fvHktMw6NFRxiz].split(qTVF3icWwGXy5(u"ࠩ࠲ࠫॸ"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
Q0ykDeVYNBOECG5WU = int(yyrcMwk6RWmH3xOKQUpGdghiX.argv[fdQOo6Hu4B5Rbg])
ccW1tVjJvUx5efKbPHu6yAMLqaF = yyrcMwk6RWmH3xOKQUpGdghiX.argv[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
ojQhH42vi5Zfsc = IJPabrdjXE7HGR163qY48pMVU5l.split(RVpeGcmPxj9tCnT40Nf216(u"ࠪ࠲ࠬॹ"))[SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU]
GBx0Fcf7sLbqlntEX3yMezu = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(FWqeEzO1i8Dn0ga(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫॺ")+IJPabrdjXE7HGR163qY48pMVU5l+rxWDdRBIct57i90s(u"ࠬ࠯ࠧॻ"))
ZwIThN17YKVQnbp52gX = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(eZgfQSTdy7pciUO4kjhur3IKb,IJPabrdjXE7HGR163qY48pMVU5l)
FicKOG8M4gQsvf3naoU = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,rr7Xolsp4JwjPK3L(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫॼ"))
iyNfWHemZaC1 = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(ZwIThN17YKVQnbp52gX,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨॽ"))
AVeHPW5shuXLdr2vwD = int(SSCU3jdyFn2V.time())
amx9qJHkhw7oLdtVMG3 = K8EzSxPHWjcp.Addon(id=IJPabrdjXE7HGR163qY48pMVU5l)
CfRkqdn4IDNir = amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬॾ"))
jlFg5ptfLPEYns7mkOuyZG4z0WaqK = kkMuQrLWcEayRm if CfRkqdn4IDNir==GBx0Fcf7sLbqlntEX3yMezu else P5VqbRSzjtO4UE1rZaolG67XA
sqOTfRikj0nJUr9a38QpwhogNCXBdx = kkMuQrLWcEayRm
def uNeAyo6mgQTwGtDFhfcU5ZasI(yzieWRVX4nkB3DjGHJphEdQo,KKuAjNF7ZWUGOw0abglrVTM2znxh3=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡂࠫॿ")):
	if cjbAkCIinvs(u"ࠪࡁࠬঀ") in yzieWRVX4nkB3DjGHJphEdQo:
		if KKuAjNF7ZWUGOw0abglrVTM2znxh3 in yzieWRVX4nkB3DjGHJphEdQo: XXzvmn7ewM8yBfoxua,PS1vT73owK0zXbuaA2DBYMU9flsm8r = yzieWRVX4nkB3DjGHJphEdQo.split(KKuAjNF7ZWUGOw0abglrVTM2znxh3,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠵ଳ"))
		else: XXzvmn7ewM8yBfoxua,PS1vT73owK0zXbuaA2DBYMU9flsm8r = G9G0YqivIfmUWO8K,yzieWRVX4nkB3DjGHJphEdQo
		PS1vT73owK0zXbuaA2DBYMU9flsm8r = PS1vT73owK0zXbuaA2DBYMU9flsm8r.split(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࠫ࠭ঁ"))
		pPIbdY3oKe = {}
		for hR5Bi8FnNK in PS1vT73owK0zXbuaA2DBYMU9flsm8r:
			sKzaZIMqmo,B4BDjGwmcPLfMysiFnHX = hR5Bi8FnNK.split(RVpeGcmPxj9tCnT40Nf216(u"ࠬࡃࠧং"),hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠶଴"))
			pPIbdY3oKe[sKzaZIMqmo] = B4BDjGwmcPLfMysiFnHX
	else: XXzvmn7ewM8yBfoxua,pPIbdY3oKe = yzieWRVX4nkB3DjGHJphEdQo,{}
	return XXzvmn7ewM8yBfoxua,pPIbdY3oKe
def wilKJdNLRzVvboaHjkYBrU51(Tqd89eUHZ7l):
	xGSck2P7nNXiKlgFrm8HQBfsRjhTt,oob2dzmG3jTMpZwQyIfN,Y4JcnAbwEz0VRCBldWS = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	Tqd89eUHZ7l = Tqd89eUHZ7l.replace(Leu8GC4bRxh6How7I5U,G9G0YqivIfmUWO8K).replace(wLgGlRoMI589yT6j1rvbW,G9G0YqivIfmUWO8K)
	VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌ࠰࠹ࡅ࠴ࡊࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ঃ"),Tqd89eUHZ7l,oo9kuULlebNgpY0Om.DOTALL)
	if VwRHKuBk48UPEqnQsp: xGSck2P7nNXiKlgFrm8HQBfsRjhTt,oob2dzmG3jTMpZwQyIfN,Tqd89eUHZ7l = VwRHKuBk48UPEqnQsp[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	if xGSck2P7nNXiKlgFrm8HQBfsRjhTt not in [ww0sZkBU9JKd,yiaeCEwJjOcWA4ZSd5h(u"ࠧ࠭ࠩ঄"),G9G0YqivIfmUWO8K]: Y4JcnAbwEz0VRCBldWS = bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡡࡐࡓࡉࡥࠧঅ")
	if oob2dzmG3jTMpZwQyIfN: oob2dzmG3jTMpZwQyIfN = cJSNFCIhymEfx6grGu0M(u"ࠩࡢࠫআ")+oob2dzmG3jTMpZwQyIfN+FWqeEzO1i8Dn0ga(u"ࠪࡣࠬই")
	Tqd89eUHZ7l = oob2dzmG3jTMpZwQyIfN+Y4JcnAbwEz0VRCBldWS+Tqd89eUHZ7l
	return Tqd89eUHZ7l
def aKAyEnjxIlzZtCTv(yzieWRVX4nkB3DjGHJphEdQo):
	return _vOacUxEu2ZIFYrbN(yzieWRVX4nkB3DjGHJphEdQo)
def blF9qcJ4uon53mZIQpDT7j(wEbor9AmLhtDcp):
	A8abMwfNeJz = {dC3PsQJ0Ti28uYlov(u"ࠫࡹࡿࡰࡦࠩঈ"):G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠬࡳ࡯ࡥࡧࠪউ"):G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"࠭ࡵࡳ࡮ࠪঊ"):G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"ࠧࡵࡧࡻࡸࠬঋ"):G9G0YqivIfmUWO8K,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡲࡤ࡫ࡪ࠭ঌ"):G9G0YqivIfmUWO8K,t2sCrJ0xbgDRkf(u"ࠩࡱࡥࡲ࡫ࠧ঍"):G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"ࠪ࡭ࡲࡧࡧࡦࠩ঎"):G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬএ"):G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧঐ"):G9G0YqivIfmUWO8K}
	if RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭࠿ࠨ঑") in wEbor9AmLhtDcp: wEbor9AmLhtDcp = wEbor9AmLhtDcp.split(dC3PsQJ0Ti28uYlov(u"ࠧࡀࠩ঒"),fdQOo6Hu4B5Rbg)[fdQOo6Hu4B5Rbg]
	XXzvmn7ewM8yBfoxua,ppH72kCxic = uNeAyo6mgQTwGtDFhfcU5ZasI(wEbor9AmLhtDcp)
	aargs = dict(list(A8abMwfNeJz.items())+list(ppH72kCxic.items()))
	TOSitYyRugKJGbeoFZ3v6LjVHs8E7q = aargs[qTVF3icWwGXy5(u"ࠨ࡯ࡲࡨࡪ࠭ও")]
	SZzsl3Yg8MqfVrWtA = aKAyEnjxIlzZtCTv(aargs[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡸࡶࡱ࠭ঔ")])
	v4dpw1fUnIuAakbsPNVJiCz5F = aKAyEnjxIlzZtCTv(aargs[EHUAyW2lQfe4LXmhgIGc(u"ࠪࡸࡪࡾࡴࠨক")])
	E72qFtbxzQ = aKAyEnjxIlzZtCTv(aargs[ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡵࡧࡧࡦࠩখ")])
	AYH2MCZBnfUXQ = aKAyEnjxIlzZtCTv(aargs[iqHhJSxdaANDG5rlZm7B(u"ࠬࡺࡹࡱࡧࠪগ")])
	A1UJTqrLkGpli6wx = aKAyEnjxIlzZtCTv(aargs[cJSNFCIhymEfx6grGu0M(u"࠭࡮ࡢ࡯ࡨࠫঘ")])
	mmFoY8a4O1ujdX = aKAyEnjxIlzZtCTv(aargs[hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ঙ")])
	ooVNBGYtUR4yk1mZPhujzrC = aargs[hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩচ")]
	Ml36aAbnejkFXU4EYtxRqSTu1DozN = aKAyEnjxIlzZtCTv(aargs[qTVF3icWwGXy5(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫছ")])
	if Ml36aAbnejkFXU4EYtxRqSTu1DozN: Ml36aAbnejkFXU4EYtxRqSTu1DozN = eval(Ml36aAbnejkFXU4EYtxRqSTu1DozN)
	else: Ml36aAbnejkFXU4EYtxRqSTu1DozN = {}
	if not TOSitYyRugKJGbeoFZ3v6LjVHs8E7q: AYH2MCZBnfUXQ = cJSNFCIhymEfx6grGu0M(u"ࠪࡪࡴࡲࡤࡦࡴࠪজ") ; TOSitYyRugKJGbeoFZ3v6LjVHs8E7q = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫ࠷࠼࠰ࠨঝ")
	return AYH2MCZBnfUXQ,A1UJTqrLkGpli6wx,SZzsl3Yg8MqfVrWtA,TOSitYyRugKJGbeoFZ3v6LjVHs8E7q,mmFoY8a4O1ujdX,E72qFtbxzQ,v4dpw1fUnIuAakbsPNVJiCz5F,ooVNBGYtUR4yk1mZPhujzrC,Ml36aAbnejkFXU4EYtxRqSTu1DozN
def ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX):
	ee8YUtiuN7cCf2g9TP = yyrcMwk6RWmH3xOKQUpGdghiX._getframe(fdQOo6Hu4B5Rbg).f_code.co_name
	if not s5slfAmHkUtMR3WSKY1ZTX or not ee8YUtiuN7cCf2g9TP or ee8YUtiuN7cCf2g9TP==cjbAkCIinvs(u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧঞ"):
		return ETNq5t4MYngSsbfFD8J0v(u"࡛࠭ࠡࠩট")+ojQhH42vi5Zfsc.upper()+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠧࡠࠩঠ")+GBx0Fcf7sLbqlntEX3yMezu+ssGdubC4mngM9D5SRc3Ye(u"ࠨࡡࠪড")+str(F7aJYwLMEmxAVRupWf)+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࠣࡡࠬঢ")
	return vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪ࠲ࡡࡺࠧণ")+ee8YUtiuN7cCf2g9TP
def vvqQRbuChP(jBkeEonG5IdqwMrNlPXz,n1rcMdD6CB8ie3lFqTW):
	if gA0m6CQUyfLG: n1rcMdD6CB8ie3lFqTW = n1rcMdD6CB8ie3lFqTW.decode(f3uIcZ2C6pzbX1JlFBrVOdt).encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	PcQmDvxuTJyCSng1Xa = K2XMCdoguZG1hAcLW4jSwReF9V5sQ
	G5n4vArOfUz3CKS2o = [G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K]
	if jBkeEonG5IdqwMrNlPXz: n1rcMdD6CB8ie3lFqTW = n1rcMdD6CB8ie3lFqTW.replace(ipjCIhwEXsbadR,G9G0YqivIfmUWO8K).replace(A7XhkmSYZlidyMt5FpWqTgjNezbnD,G9G0YqivIfmUWO8K).replace(zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K)
	else: jBkeEonG5IdqwMrNlPXz = oz95q0dcEtSuxIJgP841M
	iILqCyOGoaxFrl4nwuEkcB,KKuAjNF7ZWUGOw0abglrVTM2znxh3 = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫࡡࡺࠧত"),wKBSo48e5PYtn63DpiG
	EpDP8t4Vglo2cheq53MnwNGHQK = qTVF3icWwGXy5(u"࠴࠳ଶ")*ww0sZkBU9JKd if LTze51miOknVcslNF43WSA6vMjYZt else GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠹࠱ଵ")*ww0sZkBU9JKd
	g6t4vPlSUxfiOBnIDY2eC5hs3AGk7 = xsCEkXb6tgrh3195YZ*iILqCyOGoaxFrl4nwuEkcB
	if n1rcMdD6CB8ie3lFqTW.startswith(cJSNFCIhymEfx6grGu0M(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭থ")): n1rcMdD6CB8ie3lFqTW = wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭࠮࡝ࡶࠪদ")+n1rcMdD6CB8ie3lFqTW
	if jT5y4a7sUiLJ8R in jBkeEonG5IdqwMrNlPXz: PcQmDvxuTJyCSng1Xa = oR7SuW56ZQcpXnswUMqIkrP.LOGERROR
	if jBkeEonG5IdqwMrNlPXz in [oz95q0dcEtSuxIJgP841M,jT5y4a7sUiLJ8R]: G5n4vArOfUz3CKS2o = [n1rcMdD6CB8ie3lFqTW]
	elif jBkeEonG5IdqwMrNlPXz==DqJLhysGer98KFOZ: G5n4vArOfUz3CKS2o = n1rcMdD6CB8ie3lFqTW.split(KKuAjNF7ZWUGOw0abglrVTM2znxh3)
	elif jBkeEonG5IdqwMrNlPXz==ZQ6C9pmUGj4oIE12BJycX7:
		CgEYJzhcIf6 = n1rcMdD6CB8ie3lFqTW.split(KKuAjNF7ZWUGOw0abglrVTM2znxh3)
		G5n4vArOfUz3CKS2o = [CgEYJzhcIf6[dQ5JhEYolPmy1fvHktMw6NFRxiz]]
		for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(fdQOo6Hu4B5Rbg,len(CgEYJzhcIf6),SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU):
			try: pMl9w160NB5KzJg = CgEYJzhcIf6[NAfxw4FYmpauWhLM2rX8soZk9QnC0]+KKuAjNF7ZWUGOw0abglrVTM2znxh3+CgEYJzhcIf6[NAfxw4FYmpauWhLM2rX8soZk9QnC0+RVpeGcmPxj9tCnT40Nf216(u"࠲ଷ")]
			except: pMl9w160NB5KzJg = CgEYJzhcIf6[NAfxw4FYmpauWhLM2rX8soZk9QnC0]
			G5n4vArOfUz3CKS2o.append(pMl9w160NB5KzJg)
	Vj1MQW6gisy7XUGkEczY3K = G5n4vArOfUz3CKS2o[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	for k83jFdPwOph5 in G5n4vArOfUz3CKS2o[fdQOo6Hu4B5Rbg:]:
		if jBkeEonG5IdqwMrNlPXz in [DqJLhysGer98KFOZ,ZQ6C9pmUGj4oIE12BJycX7]: g6t4vPlSUxfiOBnIDY2eC5hs3AGk7 += iILqCyOGoaxFrl4nwuEkcB
		Vj1MQW6gisy7XUGkEczY3K += fXE2iwNYcD+EpDP8t4Vglo2cheq53MnwNGHQK+g6t4vPlSUxfiOBnIDY2eC5hs3AGk7+k83jFdPwOph5
	Vj1MQW6gisy7XUGkEczY3K += RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠧࠡࡡࠪধ")
	if dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨࠧࠪন") in Vj1MQW6gisy7XUGkEczY3K: Vj1MQW6gisy7XUGkEczY3K = aKAyEnjxIlzZtCTv(Vj1MQW6gisy7XUGkEczY3K)
	oR7SuW56ZQcpXnswUMqIkrP.log(Vj1MQW6gisy7XUGkEczY3K,level=PcQmDvxuTJyCSng1Xa)
	return
def JPlczjbGwnL6yapMuK(oUMr9z6kD8Ht20XVAifdYJuhOgs):
	try: plXWEwZYQTbg4JHCByU6LSr8RO1m0n = Pkp47glurdBOS38Y.connect(oUMr9z6kD8Ht20XVAifdYJuhOgs,check_same_thread=ssGdubC4mngM9D5SRc3Ye(u"ࡌࡡ࡭ࡵࡨ୭"))
	except:
		if not ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(ZwIThN17YKVQnbp52gX):
			ifTNQtY3XrquHMV4wlCgI6FmpPK.makedirs(ZwIThN17YKVQnbp52gX)
			plXWEwZYQTbg4JHCByU6LSr8RO1m0n = Pkp47glurdBOS38Y.connect(oUMr9z6kD8Ht20XVAifdYJuhOgs,check_same_thread=rxWDdRBIct57i90s(u"ࡆࡢ࡮ࡶࡩ୮"))
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.text_factory = str
	ww2WhlesJYXSLQBMZ6gdy4K7c = plXWEwZYQTbg4JHCByU6LSr8RO1m0n.cursor()
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨ঩"))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭࡬ࡴ࡯ࡳࡧࡢࡧ࡭࡫ࡣ࡬ࡡࡦࡳࡳࡹࡴࡳࡣ࡬ࡲࡹࡹ࠽ࡺࡧࡶ࠿ࠬপ"))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(yiaeCEwJjOcWA4ZSd5h(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡯ࡵࡵࡳࡰࡤࡰࡤࡳ࡯ࡥࡧࡀࡓࡋࡌ࠻ࠨফ"))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴ࡯ࡶࡵࡀࡓࡋࡌ࠻ࠨব"))
	PFpbXEKiR7nLu4AYd = WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨভ"))
	if PFpbXEKiR7nLu4AYd: plXWEwZYQTbg4JHCByU6LSr8RO1m0n.commit()
	else:
		fdGJteXp3aEi2wcMYDgP0T46lZ()
	return plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c
def WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,FulK8jfTGMZIi9z2Ncx4vmJLCA1Hs,x5xy4ZVnsAUQaLBrwGz1o2,ghDVK9i0mFuGLovwHPeEfx4dj=()):
	try:
		if FulK8jfTGMZIi9z2Ncx4vmJLCA1Hs: ww2WhlesJYXSLQBMZ6gdy4K7c.executemany(x5xy4ZVnsAUQaLBrwGz1o2,ghDVK9i0mFuGLovwHPeEfx4dj)
		else: ww2WhlesJYXSLQBMZ6gdy4K7c.execute(x5xy4ZVnsAUQaLBrwGz1o2,ghDVK9i0mFuGLovwHPeEfx4dj)
		plXWEwZYQTbg4JHCByU6LSr8RO1m0n.commit()
		PFpbXEKiR7nLu4AYd = P5VqbRSzjtO4UE1rZaolG67XA
	except:
		PFpbXEKiR7nLu4AYd,timeout = kkMuQrLWcEayRm,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠳࠳ସ")
		vNVBJ0PYWhmua6k1pxb5EiT8gL = SSCU3jdyFn2V.time()
		while SSCU3jdyFn2V.time()-vNVBJ0PYWhmua6k1pxb5EiT8gL<timeout and not PFpbXEKiR7nLu4AYd:
			try:
				if FulK8jfTGMZIi9z2Ncx4vmJLCA1Hs: ww2WhlesJYXSLQBMZ6gdy4K7c.executemany(x5xy4ZVnsAUQaLBrwGz1o2,ghDVK9i0mFuGLovwHPeEfx4dj)
				else: ww2WhlesJYXSLQBMZ6gdy4K7c.execute(x5xy4ZVnsAUQaLBrwGz1o2,ghDVK9i0mFuGLovwHPeEfx4dj)
				plXWEwZYQTbg4JHCByU6LSr8RO1m0n.commit()
				PFpbXEKiR7nLu4AYd = P5VqbRSzjtO4UE1rZaolG67XA
			except: SSCU3jdyFn2V.sleep(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠳࠲࠺ହ"))
		if not PFpbXEKiR7nLu4AYd:
			vvqQRbuChP(DqJLhysGer98KFOZ,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧ࠯࡞ࡷ࡙ࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡷࡳ࡫ࡷࡩࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡧ࡫࡯ࡩࠥࠦࠠࠨম")+oUMr9z6kD8Ht20XVAifdYJuhOgs+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡼ࡮ࡥ࡯ࠢࡨࡼࡪࡩࡵࡵ࡫ࡱ࡫ࠥࡺࡨࡪࡵࠣࡷࡹࡧࡴࡦ࡯ࡨࡲࡹࠦࠠࠡࠩয")+x5xy4ZVnsAUQaLBrwGz1o2+zEgtT9cR6bFp7JXqI5VuhNeP)
			import a1aDsx9ioY
			a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(UighHKAfySm4PWErqJ(u"ࠩไุ้ࠦแ๋ࠢๅห฾ีษࠡษ็ฬ๏อๆศฬࠪর"),rxWDdRBIct57i90s(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫ঱"))
	return PFpbXEKiR7nLu4AYd
def PiXRCL1dtv6pWfU(oUMr9z6kD8Ht20XVAifdYJuhOgs,yPzwn62HO0FEkNC,hW1XtNpzG92m7o3cJ,ShI3Z7CxPbDBu=None):
	snev3rg1V28C9pxGO6RNfIDBS0z = jx48U9wlGyTC2gEcaVd(yPzwn62HO0FEkNC)
	k5GDfLeHJ0ZP3vSYbz = amx9qJHkhw7oLdtVMG3.getSetting(bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪল"))
	if hW1XtNpzG92m7o3cJ not in [wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ঳"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡐࡍࡋࡗࡘࡊࡊ࡟ࡂࡎࡏࠫ঴"),iqHhJSxdaANDG5rlZm7B(u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡑࡎࡌࡘ࡙ࡋࡄࡠࡉࡒࡓࡌࡒࡅࠨ঵")] and oUMr9z6kD8Ht20XVAifdYJuhOgs==FicKOG8M4gQsvf3naoU and ShI3Z7CxPbDBu!=bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪশ"):
		if k5GDfLeHJ0ZP3vSYbz==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡖࡘࡔࡖࠧষ"): return snev3rg1V28C9pxGO6RNfIDBS0z
		w0oqhWrypS1QlT5zX6UAnFIGfKOkc = amx9qJHkhw7oLdtVMG3.getSetting(iqHhJSxdaANDG5rlZm7B(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧস"))
		if w0oqhWrypS1QlT5zX6UAnFIGfKOkc==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫহ"):
			aaSYfirqFBsp9IDRG7MAQtdLbxluV(oUMr9z6kD8Ht20XVAifdYJuhOgs,hW1XtNpzG92m7o3cJ,ShI3Z7CxPbDBu)
			return snev3rg1V28C9pxGO6RNfIDBS0z
	dp0rbEsftz3yo8971TXOPq4e = dQ5JhEYolPmy1fvHktMw6NFRxiz
	if k5GDfLeHJ0ZP3vSYbz==bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭঺"): dp0rbEsftz3yo8971TXOPq4e = EwuAeDoaOmr2R7X3Qb6NhtJUF
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c = JPlczjbGwnL6yapMuK(oUMr9z6kD8Ht20XVAifdYJuhOgs)
	jCiA3hxo025vEF = ww2WhlesJYXSLQBMZ6gdy4K7c.execute(cjbAkCIinvs(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦ࡮ࡢ࡯ࡨࠤࡋࡘࡏࡎࠢࡶࡵࡱ࡯ࡴࡦࡡࡰࡥࡸࡺࡥࡳ࡚ࠢࡌࡊࡘࡅࠡࡶࡼࡴࡪࡃࠢࡵࡣࡥࡰࡪࠨࠠࡂࡐࡇࠤࡳࡧ࡭ࡦ࠿ࠥࠫ঻")+hW1XtNpzG92m7o3cJ+rxWDdRBIct57i90s(u"ࠧࠣࠢ࠾়ࠫ")).fetchall()
	if jCiA3hxo025vEF:
		if dp0rbEsftz3yo8971TXOPq4e: WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,qTVF3icWwGXy5(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨঽ")+hW1XtNpzG92m7o3cJ+iqHhJSxdaANDG5rlZm7B(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫা")+str(AVeHPW5shuXLdr2vwD+dp0rbEsftz3yo8971TXOPq4e)+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪࠤࡀ࠭ি"))
		WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫী")+hW1XtNpzG92m7o3cJ+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧু")+str(AVeHPW5shuXLdr2vwD)+rxWDdRBIct57i90s(u"࠭ࠠ࠼ࠩূ"))
		if ShI3Z7CxPbDBu:
			HG80vm2cWq9dblajP3eEBJfoST5 = (str(ShI3Z7CxPbDBu),)
			ww2WhlesJYXSLQBMZ6gdy4K7c.execute(FWqeEzO1i8Dn0ga(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬৃ")+hW1XtNpzG92m7o3cJ+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨৄ"),HG80vm2cWq9dblajP3eEBJfoST5)
			E52cBHtlZuUM9TdNn3FGp7kVJ04m = ww2WhlesJYXSLQBMZ6gdy4K7c.fetchall()
			if E52cBHtlZuUM9TdNn3FGp7kVJ04m:
				try:
					xCVyDu98lp4NE3MR6A0 = opMdBjWmRv4GJU.decompress(E52cBHtlZuUM9TdNn3FGp7kVJ04m[dQ5JhEYolPmy1fvHktMw6NFRxiz][dQ5JhEYolPmy1fvHktMw6NFRxiz])
					snev3rg1V28C9pxGO6RNfIDBS0z = kk7pArQsGbMSUW32zO9lFImZadRo.loads(xCVyDu98lp4NE3MR6A0)
				except: pass
		else:
			ww2WhlesJYXSLQBMZ6gdy4K7c.execute(iAGgjwb7tVMmacRJ(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ৅")+hW1XtNpzG92m7o3cJ+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࠦࠥࡁࠧ৆"))
			E52cBHtlZuUM9TdNn3FGp7kVJ04m = ww2WhlesJYXSLQBMZ6gdy4K7c.fetchall()
			if E52cBHtlZuUM9TdNn3FGp7kVJ04m:
				snev3rg1V28C9pxGO6RNfIDBS0z,tZNSCPlKkupX8sfED6WBm = {},[]
				for ZZ8zbNmntw3rhdJ,pPIbdY3oKe in E52cBHtlZuUM9TdNn3FGp7kVJ04m:
					DTUp9SXGQBRuy6a2OWVEKL7Pk = opMdBjWmRv4GJU.decompress(pPIbdY3oKe)
					pPIbdY3oKe = kk7pArQsGbMSUW32zO9lFImZadRo.loads(DTUp9SXGQBRuy6a2OWVEKL7Pk)
					snev3rg1V28C9pxGO6RNfIDBS0z[ZZ8zbNmntw3rhdJ] = pPIbdY3oKe
					tZNSCPlKkupX8sfED6WBm.append(ZZ8zbNmntw3rhdJ)
				if tZNSCPlKkupX8sfED6WBm:
					snev3rg1V28C9pxGO6RNfIDBS0z[vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬে")] = tZNSCPlKkupX8sfED6WBm
					if yPzwn62HO0FEkNC==dC3PsQJ0Ti28uYlov(u"ࠬࡲࡩࡴࡶࠪৈ"): snev3rg1V28C9pxGO6RNfIDBS0z = tZNSCPlKkupX8sfED6WBm
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
	return snev3rg1V28C9pxGO6RNfIDBS0z
def ISnrjfT1tByLYcOaq4MPpQxUlEuC(oUMr9z6kD8Ht20XVAifdYJuhOgs,hW1XtNpzG92m7o3cJ,ShI3Z7CxPbDBu,snev3rg1V28C9pxGO6RNfIDBS0z,vQaKINicJ9UPtsp,Oo9HuGrzSAqgP4ZT=kkMuQrLWcEayRm):
	k5GDfLeHJ0ZP3vSYbz = amx9qJHkhw7oLdtVMG3.getSetting(UighHKAfySm4PWErqJ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ৉"))
	if k5GDfLeHJ0ZP3vSYbz==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ৊") and vQaKINicJ9UPtsp>EwuAeDoaOmr2R7X3Qb6NhtJUF: vQaKINicJ9UPtsp = EwuAeDoaOmr2R7X3Qb6NhtJUF
	if Oo9HuGrzSAqgP4ZT:
		ONEZrIFzqkX1no,vJWjiaB4Eg2US8Z01nQ7Xy6boz = [],[]
		for p0p6MxKbklodNCR92Wv in range(len(ShI3Z7CxPbDBu)):
			xCVyDu98lp4NE3MR6A0 = kk7pArQsGbMSUW32zO9lFImZadRo.dumps(snev3rg1V28C9pxGO6RNfIDBS0z[p0p6MxKbklodNCR92Wv])
			WW6b7vjJhYrFt = opMdBjWmRv4GJU.compress(xCVyDu98lp4NE3MR6A0)
			ONEZrIFzqkX1no.append((ShI3Z7CxPbDBu[p0p6MxKbklodNCR92Wv],))
			vJWjiaB4Eg2US8Z01nQ7Xy6boz.append((vQaKINicJ9UPtsp+AVeHPW5shuXLdr2vwD,str(ShI3Z7CxPbDBu[p0p6MxKbklodNCR92Wv]),WW6b7vjJhYrFt))
	else:
		xCVyDu98lp4NE3MR6A0 = kk7pArQsGbMSUW32zO9lFImZadRo.dumps(snev3rg1V28C9pxGO6RNfIDBS0z)
		ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM = opMdBjWmRv4GJU.compress(xCVyDu98lp4NE3MR6A0)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c = JPlczjbGwnL6yapMuK(oUMr9z6kD8Ht20XVAifdYJuhOgs)
	WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩো")+hW1XtNpzG92m7o3cJ+FWqeEzO1i8Dn0ga(u"ࠩࠥࠤ࠭࡫ࡸࡱ࡫ࡵࡽ࠱ࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠬࠤࡀ࠭ৌ"))
	if Oo9HuGrzSAqgP4ZT:
		WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,P5VqbRSzjtO4UE1rZaolG67XA,RVpeGcmPxj9tCnT40Nf216(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤ্ࠪ")+hW1XtNpzG92m7o3cJ+ssGdubC4mngM9D5SRc3Ye(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫৎ"),ONEZrIFzqkX1no)
		WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,P5VqbRSzjtO4UE1rZaolG67XA,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ৏")+hW1XtNpzG92m7o3cJ+qTVF3icWwGXy5(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ৐"),vJWjiaB4Eg2US8Z01nQ7Xy6boz)
	else:
		if vQaKINicJ9UPtsp:
			HG80vm2cWq9dblajP3eEBJfoST5 = (str(ShI3Z7CxPbDBu),)
			WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,dC3PsQJ0Ti28uYlov(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ৑")+hW1XtNpzG92m7o3cJ+iqHhJSxdaANDG5rlZm7B(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ৒"),HG80vm2cWq9dblajP3eEBJfoST5)
			HG80vm2cWq9dblajP3eEBJfoST5 = (vQaKINicJ9UPtsp+AVeHPW5shuXLdr2vwD,str(ShI3Z7CxPbDBu),ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM)
			WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,cJSNFCIhymEfx6grGu0M(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ৓")+hW1XtNpzG92m7o3cJ+VHrIziKUDuNGXkMla(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ৔"),HG80vm2cWq9dblajP3eEBJfoST5)
		else:
			HG80vm2cWq9dblajP3eEBJfoST5 = (ftLo6yRWT8FPa2ZuQkNxSIb57DHmhM,str(ShI3Z7CxPbDBu))
			WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,qTVF3icWwGXy5(u"࡚ࠫࡖࡄࡂࡖࡈࠤࠧ࠭৕")+hW1XtNpzG92m7o3cJ+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠬࠨࠠࡔࡇࡗࠤࡩࡧࡴࡢࠢࡀࠤࡄࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ৖"),HG80vm2cWq9dblajP3eEBJfoST5)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
	return
def aaSYfirqFBsp9IDRG7MAQtdLbxluV(oUMr9z6kD8Ht20XVAifdYJuhOgs,hW1XtNpzG92m7o3cJ,ShI3Z7CxPbDBu=None):
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c = JPlczjbGwnL6yapMuK(oUMr9z6kD8Ht20XVAifdYJuhOgs)
	if ShI3Z7CxPbDBu==None: WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,yiaeCEwJjOcWA4ZSd5h(u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨৗ")+hW1XtNpzG92m7o3cJ+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࠣࠢ࠾ࠫ৘"))
	else:
		jCiA3hxo025vEF = ww2WhlesJYXSLQBMZ6gdy4K7c.execute(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡰࡤࡱࡪࠦࡆࡓࡑࡐࠤࡸࡷ࡬ࡪࡶࡨࡣࡲࡧࡳࡵࡧࡵࠤ࡜ࡎࡅࡓࡇࠣࡸࡾࡶࡥ࠾ࠤࡷࡥࡧࡲࡥࠣࠢࡄࡒࡉࠦ࡮ࡢ࡯ࡨࡁࠧ࠭৙")+hW1XtNpzG92m7o3cJ+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩࠥࠤࡀ࠭৚")).fetchall()
		if jCiA3hxo025vEF:
			HG80vm2cWq9dblajP3eEBJfoST5 = (str(ShI3Z7CxPbDBu),)
			if t2sCrJ0xbgDRkf(u"ࠪࠩࠬ৛") in ShI3Z7CxPbDBu: WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫড়")+hW1XtNpzG92m7o3cJ+t2sCrJ0xbgDRkf(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨঢ়"),HG80vm2cWq9dblajP3eEBJfoST5)
			else: WanLYkXbs3(oUMr9z6kD8Ht20XVAifdYJuhOgs,plXWEwZYQTbg4JHCByU6LSr8RO1m0n,ww2WhlesJYXSLQBMZ6gdy4K7c,kkMuQrLWcEayRm,CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৞")+hW1XtNpzG92m7o3cJ+FWqeEzO1i8Dn0ga(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧয়"),HG80vm2cWq9dblajP3eEBJfoST5)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
	return
class yycb46gaZq0Y52FCOB1EpVxfAP(): pass
class LGmh2jCPAgpY(yycb46gaZq0Y52FCOB1EpVxfAP):
	def __init__(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.url = G9G0YqivIfmUWO8K
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.code = -dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠽࠾଺")
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.reason = G9G0YqivIfmUWO8K
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.content = G9G0YqivIfmUWO8K
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.headers = {}
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.cookies = {}
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.succeeded = kkMuQrLWcEayRm
def jx48U9wlGyTC2gEcaVd(C9uTVdSkLlb5UemavyB6NjWHFh):
	if C9uTVdSkLlb5UemavyB6NjWHFh==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡦ࡬ࡧࡹ࠭ৠ"): snev3rg1V28C9pxGO6RNfIDBS0z = {}
	elif C9uTVdSkLlb5UemavyB6NjWHFh==bneABYmwFUH8GXphg0Kl2Sq(u"ࠩ࡯࡭ࡸࡺࠧৡ"): snev3rg1V28C9pxGO6RNfIDBS0z = []
	elif C9uTVdSkLlb5UemavyB6NjWHFh==ssGdubC4mngM9D5SRc3Ye(u"ࠪࡸࡺࡶ࡬ࡦࠩৢ"): snev3rg1V28C9pxGO6RNfIDBS0z = ()
	elif C9uTVdSkLlb5UemavyB6NjWHFh==Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡸࡺࡲࠨৣ"): snev3rg1V28C9pxGO6RNfIDBS0z = G9G0YqivIfmUWO8K
	elif C9uTVdSkLlb5UemavyB6NjWHFh==wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬ࡯࡮ࡵࠩ৤"): snev3rg1V28C9pxGO6RNfIDBS0z = dQ5JhEYolPmy1fvHktMw6NFRxiz
	elif C9uTVdSkLlb5UemavyB6NjWHFh==EHUAyW2lQfe4LXmhgIGc(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ৥"): snev3rg1V28C9pxGO6RNfIDBS0z = LGmh2jCPAgpY()
	elif not C9uTVdSkLlb5UemavyB6NjWHFh: snev3rg1V28C9pxGO6RNfIDBS0z = None
	else: snev3rg1V28C9pxGO6RNfIDBS0z = None
	return snev3rg1V28C9pxGO6RNfIDBS0z
def kWUE5INdVuX9wSOFsnZ(QQR0smH7TzAEMwvu):
	twzBhacixJEMIe4VvyAGW8Nkb9dng = amx9qJHkhw7oLdtVMG3.getSetting(dC3PsQJ0Ti28uYlov(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪ০"))
	p8wfB4mIkxn1NVEqRPh = iOtjqZ6Iydl.splitlines()
	sQCvO8q4N5byK7lnfLXmHEz2YGcU = dQ5JhEYolPmy1fvHktMw6NFRxiz
	QkfP94eVT3g1tBlnsaSMyqCUKh6x = len(QQR0smH7TzAEMwvu)
	VTpb89g45da = [kkMuQrLWcEayRm]*QkfP94eVT3g1tBlnsaSMyqCUKh6x
	for qusTNMH5FAGO9kJYUxd40 in [AVeHPW5shuXLdr2vwD,AVeHPW5shuXLdr2vwD-HpjLKS83swXDzVInEf2xUZaCuNbR9d]:
		B1xPUfQlkchZHuEgRp9 = str(qusTNMH5FAGO9kJYUxd40*bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠰࠱࠲࠳࠴࠳࠶଼")/yiaeCEwJjOcWA4ZSd5h(u"࠹࠹࠲࠱࠲࠳଻"))[dQ5JhEYolPmy1fvHktMw6NFRxiz:hhdGMSsBzel96obfEmrwiuLPOvq(u"࠴ଽ")]
		if B1xPUfQlkchZHuEgRp9!=sQCvO8q4N5byK7lnfLXmHEz2YGcU:
			for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in range(QkfP94eVT3g1tBlnsaSMyqCUKh6x):
				if not VTpb89g45da[NAfxw4FYmpauWhLM2rX8soZk9QnC0]:
					L7saIgqHGDxmkRl8hAr3Y6NFWpfy = kkMuQrLWcEayRm
					for i1yNfFstkAeqY in p8wfB4mIkxn1NVEqRPh:
						FKbIQl9z4GVumMci2pHNYXr = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨ࡚࠴࠽ࠬ১")+QQR0smH7TzAEMwvu[NAfxw4FYmpauWhLM2rX8soZk9QnC0]+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠩ࠴࠼ࡂ࠭২")+i1yNfFstkAeqY[-rr7Xolsp4JwjPK3L(u"࠳࠶ା"):]+GBx0Fcf7sLbqlntEX3yMezu+B1xPUfQlkchZHuEgRp9
						FKbIQl9z4GVumMci2pHNYXr = QzHB32naPjOLJ46.md5(FKbIQl9z4GVumMci2pHNYXr.encode(f3uIcZ2C6pzbX1JlFBrVOdt)).hexdigest()[:GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠵࠵ି")]
						if FKbIQl9z4GVumMci2pHNYXr in twzBhacixJEMIe4VvyAGW8Nkb9dng:
							L7saIgqHGDxmkRl8hAr3Y6NFWpfy = P5VqbRSzjtO4UE1rZaolG67XA
							break
					VTpb89g45da[NAfxw4FYmpauWhLM2rX8soZk9QnC0] = L7saIgqHGDxmkRl8hAr3Y6NFWpfy
		sQCvO8q4N5byK7lnfLXmHEz2YGcU = B1xPUfQlkchZHuEgRp9
	return VTpb89g45da
class hCOtUkrGsJEgxqKibN(OX803BEQFmdwexVbkhy9uz):
	def __init__(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX): pass
	def W0STqPpiCyOIVced25F4BXm6owRng(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX,jN01o7FQrDbavMEgAh3B):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = cjbAkCIinvs(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৩") if iKLYEvx39c.t6Xn5IBwJPG0so47MEif else G9G0YqivIfmUWO8K
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.jN01o7FQrDbavMEgAh3B = jN01o7FQrDbavMEgAh3B
		if not iKLYEvx39c.w0Zn3BsVo7GWDyuli:
			import a1aDsx9ioY
			a1aDsx9ioY.ewXaFc6410BDW8dgYAzVR(PvAZ1fCRqL5F)
	def onPlayBackStopped(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX): sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = DTF3Lwy9etRH8mI(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ৪")
	def onPlayBackError(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX): sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ৫")
	def onPlayBackEnded(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX): sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = ETNq5t4MYngSsbfFD8J0v(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭৬")
	def onPlayBackStarted(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = rr7Xolsp4JwjPK3L(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ৭")
		o5sk1yJGcUxq0pNLeQZ2RAtDrTBd = fu19TY0PdM6AZB5.Thread(target=sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.IXru0mYei2KoR3JQDj7GT,args=())
		o5sk1yJGcUxq0pNLeQZ2RAtDrTBd.start()
	def onAVStarted(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		if iKLYEvx39c.w0Zn3BsVo7GWDyuli: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ৮")
		else: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ৯")
	def IXru0mYei2KoR3JQDj7GT(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX):
		vlcUutakSyFDIi(iAGgjwb7tVMmacRJ(u"ࠪࡷࡹࡵࡰࠨৰ"))
		H2H8byX1LuVhwExMpaU = dQ5JhEYolPmy1fvHktMw6NFRxiz
		while not eval(t2sCrJ0xbgDRkf(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩৱ"),{UighHKAfySm4PWErqJ(u"ࠬࡾࡢ࡮ࡥࠪ৲"):oR7SuW56ZQcpXnswUMqIkrP}) and sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ৳"):
			oR7SuW56ZQcpXnswUMqIkrP.sleep(vCmnFshSi4flecXIY2gy38G0DJw(u"࠴࠴࠵࠶ୀ"))
			H2H8byX1LuVhwExMpaU += fdQOo6Hu4B5Rbg
			if H2H8byX1LuVhwExMpaU>iAGgjwb7tVMmacRJ(u"࠺࠵ୁ"): return
		if iKLYEvx39c.t6Xn5IBwJPG0so47MEif: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = iAGgjwb7tVMmacRJ(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ৴")
		elif iKLYEvx39c.w0Zn3BsVo7GWDyuli: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = cJSNFCIhymEfx6grGu0M(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ৵")
		elif iKLYEvx39c.b7sHudTqiWcg51n9IlXJ0BzAa:
			import a1aDsx9ioY
			sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ৶")
			lSwfMdcGe2ZXy = fu19TY0PdM6AZB5.Thread(target=a1aDsx9ioY.I3CD0odtcR5mZqXYkVj,args=(sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.jN01o7FQrDbavMEgAh3B,))
			lSwfMdcGe2ZXy.start()
			l2xDBSM5cGqgtZYOQykraNJ = fu19TY0PdM6AZB5.Thread(target=a1aDsx9ioY.LkZbFqJUuo8,args=())
			l2xDBSM5cGqgtZYOQykraNJ.start()
		else: sVn4a62Mu0AUjm95ZfLFg7GltdNWPX.wkl1TALE2MscoZuWt = cjbAkCIinvs(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৷")
def JwxaNC6TWsVtR5Eg():
	qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	la5ZYCvdpRAroTGHx9E = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪ৸"))
	try:
		XVustZIcfK9zpJr = open(RVpeGcmPxj9tCnT40Nf216(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ৹"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡲࡣࠩ৺")).read()
		if LTze51miOknVcslNF43WSA6vMjYZt: XVustZIcfK9zpJr = XVustZIcfK9zpJr.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		byvDaWVUtx0FCmSLOfR51EM = oo9kuULlebNgpY0Om.findall(cJSNFCIhymEfx6grGu0M(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫ৻"),XVustZIcfK9zpJr,oo9kuULlebNgpY0Om.IGNORECASE)
		if byvDaWVUtx0FCmSLOfR51EM: qOTBtSJ0Rxr82NI = byvDaWVUtx0FCmSLOfR51EM[dQ5JhEYolPmy1fvHktMw6NFRxiz]
	except: pass
	try:
		import subprocess as RRGq48uQHjx1efyTA
		fEhMyIUV1LdTFXxsloa62QqB = RRGq48uQHjx1efyTA.Popen(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭ৼ"),shell=P5VqbRSzjtO4UE1rZaolG67XA,stdin=RRGq48uQHjx1efyTA.PIPE,stdout=RRGq48uQHjx1efyTA.PIPE,stderr=RRGq48uQHjx1efyTA.PIPE)
		QqDh0R82stfmKUEdVPceM7pGnj = fEhMyIUV1LdTFXxsloa62QqB.stdout.read()
		if QqDh0R82stfmKUEdVPceM7pGnj:
			if LTze51miOknVcslNF43WSA6vMjYZt:
				QqDh0R82stfmKUEdVPceM7pGnj = QqDh0R82stfmKUEdVPceM7pGnj.decode(f3uIcZ2C6pzbX1JlFBrVOdt,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ৽"))
			Vhec4ojT1Hp968xqOSLJNs = oo9kuULlebNgpY0Om.findall(UighHKAfySm4PWErqJ(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧ৾"),QqDh0R82stfmKUEdVPceM7pGnj,oo9kuULlebNgpY0Om.IGNORECASE)
			if Vhec4ojT1Hp968xqOSLJNs: smLeaEMIyPX5f32YcKiub0GZxH4Aoj = min(Vhec4ojT1Hp968xqOSLJNs)
	except: pass
	return la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj
def bVA4SCPumtZKi(OuBzJZDgnmGil7YQpVR5PhET=P5VqbRSzjtO4UE1rZaolG67XA,xJvUrkfQoqeWCXw8Bzm1=jR9YtmsgDX8nTQlMb6G3(u"࠸࠸ୂ")):
	PMG19adpYUjQmsfeWkoDFy0 = P5VqbRSzjtO4UE1rZaolG67XA
	if OuBzJZDgnmGil7YQpVR5PhET:
		ww6cXM5zUoebHmxrKs = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,yiaeCEwJjOcWA4ZSd5h(u"ࠫࡱ࡯ࡳࡵࠩ৿"),EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ਀"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫਁ"))
		if ww6cXM5zUoebHmxrKs:
			p8wfB4mIkxn1NVEqRPh,L7SeqTCNKHOYEG9uPcsk5,ZhIwLRiA5vUa7rqo2kfyWe,k6LP9rf5mA2ougeb = ww6cXM5zUoebHmxrKs
			PMG19adpYUjQmsfeWkoDFy0 = PiXRCL1dtv6pWfU(FicKOG8M4gQsvf3naoU,EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧ࡭࡫ࡶࡸࠬਂ"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਃ"),UighHKAfySm4PWErqJ(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ਄"))
			if PMG19adpYUjQmsfeWkoDFy0: la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj = PMG19adpYUjQmsfeWkoDFy0
			else: la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj = JwxaNC6TWsVtR5Eg()
			if (L7SeqTCNKHOYEG9uPcsk5,ZhIwLRiA5vUa7rqo2kfyWe,k6LP9rf5mA2ougeb)==(la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj): return zEgtT9cR6bFp7JXqI5VuhNeP.join(p8wfB4mIkxn1NVEqRPh)
	if PMG19adpYUjQmsfeWkoDFy0: la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj = JwxaNC6TWsVtR5Eg()
	global GwLSv2ayoC9zPixfOEkUpqgmnb,iihweY9G7ts6j5aQ0
	GwLSv2ayoC9zPixfOEkUpqgmnb,iihweY9G7ts6j5aQ0,ugbnYKwPN7oUZ = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	xJvUrkfQoqeWCXw8Bzm1 = xJvUrkfQoqeWCXw8Bzm1//SMoXWA4VtK8q1Yu9HzegcFBwp3ynLU
	fu19TY0PdM6AZB5.Thread(target=XmiG5jJUEkrMlSbN6x).start()
	fu19TY0PdM6AZB5.Thread(target=LLC18SdvxVa7grsqTD).start()
	for p0p6MxKbklodNCR92Wv in range(bneABYmwFUH8GXphg0Kl2Sq(u"࠷࠰ୃ")):
		SSCU3jdyFn2V.sleep(bneABYmwFUH8GXphg0Kl2Sq(u"࠰࠯࠷ୄ"))
		if not ugbnYKwPN7oUZ:
			try:
				Ndp8hiQFB9lXr3EHV12y = oR7SuW56ZQcpXnswUMqIkrP.getInfoLabel(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨਅ"))
				if Ndp8hiQFB9lXr3EHV12y.count(cJSNFCIhymEfx6grGu0M(u"ࠫ࠿࠭ਆ"))==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠷୆") and Ndp8hiQFB9lXr3EHV12y.count(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬ࠶ࠧਇ"))<CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠺୅"):
					Ndp8hiQFB9lXr3EHV12y = Ndp8hiQFB9lXr3EHV12y.lower().replace(t2sCrJ0xbgDRkf(u"࠭࠺ࠨਈ"),G9G0YqivIfmUWO8K)
					ugbnYKwPN7oUZ = str(int(Ndp8hiQFB9lXr3EHV12y,cJSNFCIhymEfx6grGu0M(u"࠴࠺େ")))
			except: pass
		if GwLSv2ayoC9zPixfOEkUpqgmnb and iihweY9G7ts6j5aQ0 and ugbnYKwPN7oUZ: break
	weguRrs7ETW6x = [iihweY9G7ts6j5aQ0,GwLSv2ayoC9zPixfOEkUpqgmnb,ugbnYKwPN7oUZ,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,VHrIziKUDuNGXkMla(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪਉ")]
	if qOTBtSJ0Rxr82NI or smLeaEMIyPX5f32YcKiub0GZxH4Aoj:
		WWYN9hp54GH1 = [(xsCEkXb6tgrh3195YZ,qOTBtSJ0Rxr82NI),(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠹ୈ"),smLeaEMIyPX5f32YcKiub0GZxH4Aoj)]
		for sKzaZIMqmo,B4BDjGwmcPLfMysiFnHX in WWYN9hp54GH1:
			B4BDjGwmcPLfMysiFnHX = B4BDjGwmcPLfMysiFnHX.strip(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨ࠲ࠪਊ"))
			if B4BDjGwmcPLfMysiFnHX:
				if LTze51miOknVcslNF43WSA6vMjYZt: B4BDjGwmcPLfMysiFnHX = B4BDjGwmcPLfMysiFnHX.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				B4BDjGwmcPLfMysiFnHX = str(int(QzHB32naPjOLJ46.md5(B4BDjGwmcPLfMysiFnHX).hexdigest(),bneABYmwFUH8GXphg0Kl2Sq(u"࠸࠼୉")))
				mmJSuyUOWAtLgr6Dpk42 = [int(B4BDjGwmcPLfMysiFnHX[OMmB8JERc1gHxA2DhVrwT4:OMmB8JERc1gHxA2DhVrwT4+rr7Xolsp4JwjPK3L(u"࠱࠶ୋ")]) for OMmB8JERc1gHxA2DhVrwT4 in range(len(B4BDjGwmcPLfMysiFnHX)) if OMmB8JERc1gHxA2DhVrwT4%rr7Xolsp4JwjPK3L(u"࠱࠶ୋ")==rxWDdRBIct57i90s(u"࠶୊")]
				weguRrs7ETW6x[sKzaZIMqmo-fdQOo6Hu4B5Rbg] = str(sum(mmJSuyUOWAtLgr6Dpk42))
	p8wfB4mIkxn1NVEqRPh,X6IJzPAyZ7GFcu10aHv59E = [],kkMuQrLWcEayRm
	for KZzWvB8Q04kD6,mmJSuyUOWAtLgr6Dpk42 in enumerate(weguRrs7ETW6x):
		if not mmJSuyUOWAtLgr6Dpk42: continue
		if X6IJzPAyZ7GFcu10aHv59E and mmJSuyUOWAtLgr6Dpk42==weguRrs7ETW6x[-fdQOo6Hu4B5Rbg]: continue
		X6IJzPAyZ7GFcu10aHv59E = P5VqbRSzjtO4UE1rZaolG67XA
		mmJSuyUOWAtLgr6Dpk42 = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࠳ࠫ਋")*xJvUrkfQoqeWCXw8Bzm1+mmJSuyUOWAtLgr6Dpk42
		mmJSuyUOWAtLgr6Dpk42 = mmJSuyUOWAtLgr6Dpk42[-xJvUrkfQoqeWCXw8Bzm1:]
		uVaRqxrWIB2,AGwDyim5ltZ = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
		aOpFmciRElfyDd6H5ZYKk1t = str(int(cJSNFCIhymEfx6grGu0M(u"ࠪ࠽ࠬ਌")*(xJvUrkfQoqeWCXw8Bzm1+fdQOo6Hu4B5Rbg))-int(mmJSuyUOWAtLgr6Dpk42))[-xJvUrkfQoqeWCXw8Bzm1:]
		for NAfxw4FYmpauWhLM2rX8soZk9QnC0 in list(range(dQ5JhEYolPmy1fvHktMw6NFRxiz,xJvUrkfQoqeWCXw8Bzm1,xsCEkXb6tgrh3195YZ)):
			uVaRqxrWIB2 += aOpFmciRElfyDd6H5ZYKk1t[NAfxw4FYmpauWhLM2rX8soZk9QnC0:NAfxw4FYmpauWhLM2rX8soZk9QnC0+xsCEkXb6tgrh3195YZ]+EHUAyW2lQfe4LXmhgIGc(u"ࠫ࠲࠭਍")
			AGwDyim5ltZ += str(sum(map(int,mmJSuyUOWAtLgr6Dpk42[NAfxw4FYmpauWhLM2rX8soZk9QnC0:NAfxw4FYmpauWhLM2rX8soZk9QnC0+xsCEkXb6tgrh3195YZ]))%CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠲࠲ୌ"))
		i1yNfFstkAeqY = str(KZzWvB8Q04kD6)+uVaRqxrWIB2+AGwDyim5ltZ
		p8wfB4mIkxn1NVEqRPh.append(i1yNfFstkAeqY)
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,iAGgjwb7tVMmacRJ(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ਎"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬਏ"),[la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj],TTm2opnt9fLX8DBYizbuSPvwhJZCl)
	ISnrjfT1tByLYcOaq4MPpQxUlEuC(FicKOG8M4gQsvf3naoU,VHrIziKUDuNGXkMla(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਐ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭਑"),[p8wfB4mIkxn1NVEqRPh,la5ZYCvdpRAroTGHx9E,qOTBtSJ0Rxr82NI,smLeaEMIyPX5f32YcKiub0GZxH4Aoj],AH0BQ4LKlDMrfvqWmXn5)
	return zEgtT9cR6bFp7JXqI5VuhNeP.join(p8wfB4mIkxn1NVEqRPh)
def XmiG5jJUEkrMlSbN6x():
	global GwLSv2ayoC9zPixfOEkUpqgmnb
	import getmac82 as LStmZEaQHOshD0fyCNvuPj2i1T
	try:
		Wdf8s5A2FYVtzKjyBcRqDT0MH = LStmZEaQHOshD0fyCNvuPj2i1T.get_mac_address()
		if Wdf8s5A2FYVtzKjyBcRqDT0MH.count(RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩ࠽ࠫ਒"))==rxWDdRBIct57i90s(u"࠸୎") and Wdf8s5A2FYVtzKjyBcRqDT0MH.count(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪ࠴ࠬਓ"))<RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠻୍"):
			Wdf8s5A2FYVtzKjyBcRqDT0MH = Wdf8s5A2FYVtzKjyBcRqDT0MH.lower().replace(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠫ࠿࠭ਔ"),G9G0YqivIfmUWO8K)
			GwLSv2ayoC9zPixfOEkUpqgmnb = str(int(Wdf8s5A2FYVtzKjyBcRqDT0MH,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠵࠻୏")))
	except: pass
	return
def LLC18SdvxVa7grsqTD():
	global iihweY9G7ts6j5aQ0
	import getmac94 as jmGDKfSaVpCMuTUBgeh70Oxtq
	try:
		Ua9yJgGtuOdkpWTxM5PzbiXHK = jmGDKfSaVpCMuTUBgeh70Oxtq.get_mac_address()
		if Ua9yJgGtuOdkpWTxM5PzbiXHK.count(iqHhJSxdaANDG5rlZm7B(u"ࠬࡀࠧਕ"))==rr7Xolsp4JwjPK3L(u"࠻୑") and Ua9yJgGtuOdkpWTxM5PzbiXHK.count(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭࠰ࠨਖ"))<CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠾୐"):
			Ua9yJgGtuOdkpWTxM5PzbiXHK = Ua9yJgGtuOdkpWTxM5PzbiXHK.lower().replace(cJSNFCIhymEfx6grGu0M(u"ࠧ࠻ࠩਗ"),G9G0YqivIfmUWO8K)
			iihweY9G7ts6j5aQ0 = str(int(Ua9yJgGtuOdkpWTxM5PzbiXHK,RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠱࠷୒")))
	except: pass
	return
def SNAjoRGWnlMtauXpc5sI87FdU(C9uTVdSkLlb5UemavyB6NjWHFh,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp,urfTS1aCy6hklQRxKzmGFgWste):
	AAFEPhnMlsH5B3z0gYQWD4j7kUc = str(m4iYHG1j9Cg6U7VEp)[dQ5JhEYolPmy1fvHktMw6NFRxiz:jR9YtmsgDX8nTQlMb6G3(u"࠳࠷࠳୓")].replace(zEgtT9cR6bFp7JXqI5VuhNeP,iqHhJSxdaANDG5rlZm7B(u"ࠨ࡞࡟ࡲࠬਘ")).replace(fXE2iwNYcD,FWqeEzO1i8Dn0ga(u"ࠩ࡟ࡠࡷ࠭ਙ")).replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd)
	if len(str(m4iYHG1j9Cg6U7VEp))>hhdGMSsBzel96obfEmrwiuLPOvq(u"࠴࠸࠴୔"): AAFEPhnMlsH5B3z0gYQWD4j7kUc = AAFEPhnMlsH5B3z0gYQWD4j7kUc+yiaeCEwJjOcWA4ZSd5h(u"ࠪࠤ࠳࠴࠮ࠨਚ")
	pPIbdY3oKe = str(snev3rg1V28C9pxGO6RNfIDBS0z)[dQ5JhEYolPmy1fvHktMw6NFRxiz:iqHhJSxdaANDG5rlZm7B(u"࠵࠹࠵୕")].replace(zEgtT9cR6bFp7JXqI5VuhNeP,UighHKAfySm4PWErqJ(u"ࠫࡡࡢ࡮ࠨਛ")).replace(fXE2iwNYcD,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࡢ࡜ࡳࠩਜ")).replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd)
	if len(str(snev3rg1V28C9pxGO6RNfIDBS0z))>iqHhJSxdaANDG5rlZm7B(u"࠶࠺࠶ୖ"): pPIbdY3oKe = pPIbdY3oKe+jR9YtmsgDX8nTQlMb6G3(u"࠭ࠠ࠯࠰࠱ࠫਝ")
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࠩਞ")+C9uTVdSkLlb5UemavyB6NjWHFh+iAGgjwb7tVMmacRJ(u"ࠨ࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫਟ")+yzieWRVX4nkB3DjGHJphEdQo+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫਠ")+XdoFLQ20O6SNVlcp+cjbAkCIinvs(u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬਡ")+urfTS1aCy6hklQRxKzmGFgWste+cJSNFCIhymEfx6grGu0M(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧਢ")+str(AAFEPhnMlsH5B3z0gYQWD4j7kUc)+iqHhJSxdaANDG5rlZm7B(u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬਣ")+pPIbdY3oKe+FWqeEzO1i8Dn0ga(u"࠭ࠠ࡞ࠩਤ"))
	return
def GOoTcZPzSh(urfTS1aCy6hklQRxKzmGFgWste,yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z=G9G0YqivIfmUWO8K,m4iYHG1j9Cg6U7VEp=G9G0YqivIfmUWO8K,XdoFLQ20O6SNVlcp=G9G0YqivIfmUWO8K):
	SNAjoRGWnlMtauXpc5sI87FdU(bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡖࡔࡏࡐࡎࡈ࡜ࡵ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬਥ"),yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,XdoFLQ20O6SNVlcp,urfTS1aCy6hklQRxKzmGFgWste)
	if LTze51miOknVcslNF43WSA6vMjYZt: import urllib.request as TH0XCRVWxil
	else: import urllib2 as TH0XCRVWxil
	if not m4iYHG1j9Cg6U7VEp: m4iYHG1j9Cg6U7VEp = {rr7Xolsp4JwjPK3L(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਦ"):G9G0YqivIfmUWO8K}
	if not snev3rg1V28C9pxGO6RNfIDBS0z: snev3rg1V28C9pxGO6RNfIDBS0z = {}
	if urfTS1aCy6hklQRxKzmGFgWste==cJSNFCIhymEfx6grGu0M(u"ࠩࡊࡉ࡙࠭ਧ"):
		yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo+iqHhJSxdaANDG5rlZm7B(u"ࠪࡃࠬਨ")+tAPSK0wDYQhczOgZ(snev3rg1V28C9pxGO6RNfIDBS0z)
		snev3rg1V28C9pxGO6RNfIDBS0z = None
	elif urfTS1aCy6hklQRxKzmGFgWste==cjbAkCIinvs(u"ࠫࡕࡕࡓࡕࠩ਩") and RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠬࡰࡳࡰࡰࠪਪ") in str(m4iYHG1j9Cg6U7VEp):
		snev3rg1V28C9pxGO6RNfIDBS0z = EEMsy4SLwnD0T92ztchdIUZ.dumps(snev3rg1V28C9pxGO6RNfIDBS0z)
		snev3rg1V28C9pxGO6RNfIDBS0z = str(snev3rg1V28C9pxGO6RNfIDBS0z).encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	elif urfTS1aCy6hklQRxKzmGFgWste==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭ࡐࡐࡕࡗࠫਫ"):
		snev3rg1V28C9pxGO6RNfIDBS0z = tAPSK0wDYQhczOgZ(snev3rg1V28C9pxGO6RNfIDBS0z)
		snev3rg1V28C9pxGO6RNfIDBS0z = snev3rg1V28C9pxGO6RNfIDBS0z.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	try:
		pn2kCabs6RKJcNDUuSfX9O = TH0XCRVWxil.Request(yzieWRVX4nkB3DjGHJphEdQo,headers=m4iYHG1j9Cg6U7VEp,data=snev3rg1V28C9pxGO6RNfIDBS0z)
		DD1ExCgnvNZhY7Acwpq6yeTSmz = TH0XCRVWxil.urlopen(pn2kCabs6RKJcNDUuSfX9O)
		RpnYai0qJ4G6mIw = DD1ExCgnvNZhY7Acwpq6yeTSmz.read()
		sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi = VHrIziKUDuNGXkMla(u"࠷࠶࠰ୗ"),t2sCrJ0xbgDRkf(u"ࠧࡐࡍࠪਬ")
	except:
		RpnYai0qJ4G6mIw = G9G0YqivIfmUWO8K
		sNWjYO26TqeSHihfx5aD8EUlon49,DeRNxUpz3y8h05KCvgJEi = -fdQOo6Hu4B5Rbg,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨਭ")
	vvqQRbuChP(oz95q0dcEtSuxIJgP841M,FWqeEzO1i8Dn0ga(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫਮ")+str(sNWjYO26TqeSHihfx5aD8EUlon49)+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬਯ")+DeRNxUpz3y8h05KCvgJEi+qTVF3icWwGXy5(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ਰ")+XdoFLQ20O6SNVlcp+rr7Xolsp4JwjPK3L(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ਱")+yzieWRVX4nkB3DjGHJphEdQo+cJSNFCIhymEfx6grGu0M(u"࠭ࠠ࡞ࠩਲ"))
	if RpnYai0qJ4G6mIw and LTze51miOknVcslNF43WSA6vMjYZt: RpnYai0qJ4G6mIw = RpnYai0qJ4G6mIw.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
	return RpnYai0qJ4G6mIw
def HMF6jA382ENmk7q1(oYcXDEaQCHzK7NFsAu3R):
	baP6eUtAiHpsDzcvN9l3mf71YJ0L = {
		wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣਲ਼"):qqeE2oiXPnzLKk,
		qTVF3icWwGXy5(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧ਴"):str(F7aJYwLMEmxAVRupWf),
		rr7Xolsp4JwjPK3L(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢਵ"):GBx0Fcf7sLbqlntEX3yMezu,
		yiaeCEwJjOcWA4ZSd5h(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥਸ਼"):GBx0Fcf7sLbqlntEX3yMezu,
		RVpeGcmPxj9tCnT40Nf216(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨ਷"): GBx0Fcf7sLbqlntEX3yMezu,
		ETNq5t4MYngSsbfFD8J0v(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨਸ"):RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨਹ"),
		ETNq5t4MYngSsbfFD8J0v(u"ࠢࡪࡲࠥ਺"): FWqeEzO1i8Dn0ga(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ਻"),
		EHUAyW2lQfe4LXmhgIGc(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣ਼ࠣ"):kkMuQrLWcEayRm
	}
	aaTwGh5vE7N = []
	for ybOHG96WcPCBgqU3Z7K8STp24 in oYcXDEaQCHzK7NFsAu3R:
		kQtFlTA5d9p8Lho = baP6eUtAiHpsDzcvN9l3mf71YJ0L.copy()
		kQtFlTA5d9p8Lho[DTF3Lwy9etRH8mI(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ਽")] = ybOHG96WcPCBgqU3Z7K8STp24
		kQtFlTA5d9p8Lho[Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧਾ")] = {vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤਿ"):ybOHG96WcPCBgqU3Z7K8STp24}
		kQtFlTA5d9p8Lho[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨੀ")] = {Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤੁ"):ybOHG96WcPCBgqU3Z7K8STp24}
		aaTwGh5vE7N.append(kQtFlTA5d9p8Lho)
	HorXYyAje0c2z9fv7 = str(voWS3GzbN5HXaTsiwLMeU.randrange(ssGdubC4mngM9D5SRc3Ye(u"࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴୘"),t2sCrJ0xbgDRkf(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽୙")))
	snev3rg1V28C9pxGO6RNfIDBS0z = {
		yiaeCEwJjOcWA4ZSd5h(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤੂ"):VHrIziKUDuNGXkMla(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧ੃"),
		EHUAyW2lQfe4LXmhgIGc(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ੄"):HorXYyAje0c2z9fv7,
		rxWDdRBIct57i90s(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ੅"): aaTwGh5vE7N
	}
	m4iYHG1j9Cg6U7VEp = {iqHhJSxdaANDG5rlZm7B(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ੆"):VHrIziKUDuNGXkMla(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩੇ")}
	yzieWRVX4nkB3DjGHJphEdQo = VHrIziKUDuNGXkMla(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩੈ")
	RpnYai0qJ4G6mIw = GOoTcZPzSh(UighHKAfySm4PWErqJ(u"ࠨࡒࡒࡗ࡙࠭੉"),yzieWRVX4nkB3DjGHJphEdQo,snev3rg1V28C9pxGO6RNfIDBS0z,m4iYHG1j9Cg6U7VEp,ETNq5t4MYngSsbfFD8J0v(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨ੊"))
	return RpnYai0qJ4G6mIw
def bRCSwcA89e4J7pqdays5PxGiD2(yPzwn62HO0FEkNC,xCVyDu98lp4NE3MR6A0):
	xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠪࡲࡺࡲ࡬ࠨੋ"),cJSNFCIhymEfx6grGu0M(u"ࠫࡓࡵ࡮ࡦࠩੌ"))
	xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠬࡺࡲࡶࡧ੍ࠪ"),DTF3Lwy9etRH8mI(u"࠭ࡔࡳࡷࡨࠫ੎"))
	xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(DTF3Lwy9etRH8mI(u"ࠧࡧࡣ࡯ࡷࡪ࠭੏"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡈࡤࡰࡸ࡫ࠧ੐"))
	xCVyDu98lp4NE3MR6A0 = xCVyDu98lp4NE3MR6A0.replace(ssGdubC4mngM9D5SRc3Ye(u"ࠩ࡟࠳ࠬੑ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠪ࠳ࠬ੒"))
	try: DTUp9SXGQBRuy6a2OWVEKL7Pk = eval(xCVyDu98lp4NE3MR6A0)
	except: DTUp9SXGQBRuy6a2OWVEKL7Pk = jx48U9wlGyTC2gEcaVd(yPzwn62HO0FEkNC)
	return DTUp9SXGQBRuy6a2OWVEKL7Pk
def PCxyizn0mbJW16cqVNIZBA():
	C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	VwRHKuBk48UPEqnQsp = oo9kuULlebNgpY0Om.findall(iAGgjwb7tVMmacRJ(u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠ࡝࡝࠲ࡇࡔࡒࡏࡓ࡞ࡠࠫ੓"),Tqd89eUHZ7l,oo9kuULlebNgpY0Om.DOTALL)
	if VwRHKuBk48UPEqnQsp: Tqd89eUHZ7l = Tqd89eUHZ7l.split(VwRHKuBk48UPEqnQsp[dQ5JhEYolPmy1fvHktMw6NFRxiz],rr7Xolsp4JwjPK3L(u"࠲୚"))[fdQOo6Hu4B5Rbg]
	Fbwk3iOU9Pvx7hMJjZWGTrfIC = SSCU3jdyFn2V.strftime(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠬࡥࠥ࡮࠰ࠨࡨࡤࠫࡈ࠻ࠧࡐࡣࠬ੔"),SSCU3jdyFn2V.localtime(AVeHPW5shuXLdr2vwD))
	Tqd89eUHZ7l = Tqd89eUHZ7l+Fbwk3iOU9Pvx7hMJjZWGTrfIC
	u5PH2z4f3d76TZtlxpOcghmvr = C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3
	if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(iyNfWHemZaC1):
		jnmXeb8f90Rpa6cFtsyDW2TJKLEr = open(iyNfWHemZaC1,cJSNFCIhymEfx6grGu0M(u"࠭ࡲࡣࠩ੕")).read()
		if LTze51miOknVcslNF43WSA6vMjYZt: jnmXeb8f90Rpa6cFtsyDW2TJKLEr = jnmXeb8f90Rpa6cFtsyDW2TJKLEr.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		jnmXeb8f90Rpa6cFtsyDW2TJKLEr = bRCSwcA89e4J7pqdays5PxGiD2(DTF3Lwy9etRH8mI(u"ࠧࡥ࡫ࡦࡸࠬ੖"),jnmXeb8f90Rpa6cFtsyDW2TJKLEr)
	else: jnmXeb8f90Rpa6cFtsyDW2TJKLEr = {}
	qyQ8MvDhH94crSZbYaC = {}
	for W4abdOmjVXn0g in list(jnmXeb8f90Rpa6cFtsyDW2TJKLEr.keys()):
		if W4abdOmjVXn0g!=C9uTVdSkLlb5UemavyB6NjWHFh: qyQ8MvDhH94crSZbYaC[W4abdOmjVXn0g] = jnmXeb8f90Rpa6cFtsyDW2TJKLEr[W4abdOmjVXn0g]
		else:
			if Tqd89eUHZ7l and Tqd89eUHZ7l!=rr7Xolsp4JwjPK3L(u"ࠨ࠰࠱ࠫ੗"):
				KlEgbJSaVZtNT = jnmXeb8f90Rpa6cFtsyDW2TJKLEr[W4abdOmjVXn0g]
				if u5PH2z4f3d76TZtlxpOcghmvr in KlEgbJSaVZtNT:
					iT2wOVymHEMAhWl6jbJs8pY = KlEgbJSaVZtNT.index(u5PH2z4f3d76TZtlxpOcghmvr)
					del KlEgbJSaVZtNT[iT2wOVymHEMAhWl6jbJs8pY]
				hayNktUR2Tq8g = [u5PH2z4f3d76TZtlxpOcghmvr]+KlEgbJSaVZtNT
				hayNktUR2Tq8g = hayNktUR2Tq8g[:Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠷࠳୛")]
				qyQ8MvDhH94crSZbYaC[W4abdOmjVXn0g] = hayNktUR2Tq8g
			else: qyQ8MvDhH94crSZbYaC[W4abdOmjVXn0g] = jnmXeb8f90Rpa6cFtsyDW2TJKLEr[W4abdOmjVXn0g]
	if C9uTVdSkLlb5UemavyB6NjWHFh not in list(qyQ8MvDhH94crSZbYaC.keys()): qyQ8MvDhH94crSZbYaC[C9uTVdSkLlb5UemavyB6NjWHFh] = [u5PH2z4f3d76TZtlxpOcghmvr]
	qyQ8MvDhH94crSZbYaC = str(qyQ8MvDhH94crSZbYaC)
	if LTze51miOknVcslNF43WSA6vMjYZt: qyQ8MvDhH94crSZbYaC = qyQ8MvDhH94crSZbYaC.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	open(iyNfWHemZaC1,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠩࡺࡦࠬ੘")).write(qyQ8MvDhH94crSZbYaC)
	return
def tAPSK0wDYQhczOgZ(snev3rg1V28C9pxGO6RNfIDBS0z):
	if LTze51miOknVcslNF43WSA6vMjYZt: import urllib.parse as sQqBhP1fdaev6XS9FlRT5Ek
	else: import urllib as sQqBhP1fdaev6XS9FlRT5Ek
	otCdO7AVv9kMsZQF8n = sQqBhP1fdaev6XS9FlRT5Ek.urlencode(snev3rg1V28C9pxGO6RNfIDBS0z)
	return otCdO7AVv9kMsZQF8n
def Imphr8LRTUDs(XjWHSnbf6NwhMgpKt4yLY7AkIT,mUcijqvHal8pfEYhIoXSWdL6nx=G9G0YqivIfmUWO8K,AYH2MCZBnfUXQ=G9G0YqivIfmUWO8K):
	OJInHcqgYdM42bFPVau = mUcijqvHal8pfEYhIoXSWdL6nx not in [qTVF3icWwGXy5(u"ࠪࡑ࠸࡛ࠧਖ਼"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫࡎࡖࡔࡗࠩਗ਼")]
	if not AYH2MCZBnfUXQ: AYH2MCZBnfUXQ = rr7Xolsp4JwjPK3L(u"ࠬࡼࡩࡥࡧࡲࠫਜ਼")
	z2Fc1kie9fwvuaVTIs8CYt,AOiSfR65Uey,W4hiRgF5qYa = rr7Xolsp4JwjPK3L(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨੜ"),G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if len(XjWHSnbf6NwhMgpKt4yLY7AkIT)==c1R9fnIY4XBDZ:
		yzieWRVX4nkB3DjGHJphEdQo,TxrvPgQF4dk1b8Cc,W4hiRgF5qYa = XjWHSnbf6NwhMgpKt4yLY7AkIT
		if TxrvPgQF4dk1b8Cc: AOiSfR65Uey = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ੝")+TxrvPgQF4dk1b8Cc+UighHKAfySm4PWErqJ(u"ࠨࠢࡠࠫਫ਼")
	else: yzieWRVX4nkB3DjGHJphEdQo,TxrvPgQF4dk1b8Cc,W4hiRgF5qYa = XjWHSnbf6NwhMgpKt4yLY7AkIT,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo.replace(VHrIziKUDuNGXkMla(u"ࠩࠨ࠶࠵࠭੟"),ww0sZkBU9JKd)
	TJCK7aEsA0Dnl2FmQ = Ig4jFuXGfUQeCn6wlB8(yzieWRVX4nkB3DjGHJphEdQo)
	if mUcijqvHal8pfEYhIoXSWdL6nx not in [t2sCrJ0xbgDRkf(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ੠"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫࡎࡖࡔࡗࠩ੡")]:
		if mUcijqvHal8pfEYhIoXSWdL6nx!=hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੢"): yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo.replace(ww0sZkBU9JKd,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࠥ࠳࠲ࠪ੣"))
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡳࡰࡦࡿ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࠢࡹ࡭ࡩ࡫࡯࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭੤")+yzieWRVX4nkB3DjGHJphEdQo+iqHhJSxdaANDG5rlZm7B(u"ࠨࠢࡠࠫ੥")+AOiSfR65Uey)
		if TJCK7aEsA0Dnl2FmQ==UighHKAfySm4PWErqJ(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ੦") and mUcijqvHal8pfEYhIoXSWdL6nx not in [GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠪࡍࡕ࡚ࡖࠨ੧"),FWqeEzO1i8Dn0ga(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ੨")]:
			import a1aDsx9ioY
			Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO,ODnaR0N8UHv7Twy6jS = a1aDsx9ioY.wjWrbquZad3QefJ2yz4(mUcijqvHal8pfEYhIoXSWdL6nx,yzieWRVX4nkB3DjGHJphEdQo)
			d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6 = len(ODnaR0N8UHv7Twy6jS)
			if d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6>fdQOo6Hu4B5Rbg:
				PXeEIRkdShOGm45lbLJc2B38s = a1aDsx9ioY.wjrY1si9L6(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭੩")+str(d3n9j7N0TZPVoSsMU1JL2Dc4bvQ6)+iqHhJSxdaANDG5rlZm7B(u"࠭ࠠๆๆไ࠭ࠬ੪"), Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO)
				if PXeEIRkdShOGm45lbLJc2B38s==-fdQOo6Hu4B5Rbg:
					a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(RVpeGcmPxj9tCnT40Nf216(u"ࠧฦๆ฽หฦูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ੫"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠨࡅࡤࡲࡨ࡫࡬ࠨ੬"))
					return z2Fc1kie9fwvuaVTIs8CYt
			else: PXeEIRkdShOGm45lbLJc2B38s = dQ5JhEYolPmy1fvHktMw6NFRxiz
			yzieWRVX4nkB3DjGHJphEdQo = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
			if Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[dQ5JhEYolPmy1fvHktMw6NFRxiz]!=wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩ࠰࠵ࠬ੭"):
				vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠿࡛ࠦࠡࠩ੮")+Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO[PXeEIRkdShOGm45lbLJc2B38s]+cJSNFCIhymEfx6grGu0M(u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ੯")+yzieWRVX4nkB3DjGHJphEdQo+ETNq5t4MYngSsbfFD8J0v(u"ࠬࠦ࡝ࠨੰ"))
		if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭࠯ࡪࡨ࡬ࡰࡲ࠵ࠧੱ") in yzieWRVX4nkB3DjGHJphEdQo: yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo+ssGdubC4mngM9D5SRc3Ye(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧੲ")
		elif FWqeEzO1i8Dn0ga(u"ࠨࡪࡷࡸࡵ࠭ੳ") in yzieWRVX4nkB3DjGHJphEdQo.lower() and wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩੴ") not in yzieWRVX4nkB3DjGHJphEdQo and t2sCrJ0xbgDRkf(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨੵ") not in yzieWRVX4nkB3DjGHJphEdQo:
			yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࢁ࠭੶") if bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࢂࠧ੷") not in yzieWRVX4nkB3DjGHJphEdQo else yzieWRVX4nkB3DjGHJphEdQo+hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࠦࠨ੸")
			if iqHhJSxdaANDG5rlZm7B(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࠬ੹") not in yzieWRVX4nkB3DjGHJphEdQo and VHrIziKUDuNGXkMla(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ੺") in yzieWRVX4nkB3DjGHJphEdQo.lower(): yzieWRVX4nkB3DjGHJphEdQo += wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠫ࠭੻")
			if iAGgjwb7tVMmacRJ(u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺ࠽ࠨ੼") not in yzieWRVX4nkB3DjGHJphEdQo.lower() and mUcijqvHal8pfEYhIoXSWdL6nx not in [vCmnFshSi4flecXIY2gy38G0DJw(u"ࠫࡎࡖࡔࡗࠩ੽"),cjbAkCIinvs(u"ࠬࡓ࠳ࡖࠩ੾")]: yzieWRVX4nkB3DjGHJphEdQo += jR9YtmsgDX8nTQlMb6G3(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ੿")
			if iqHhJSxdaANDG5rlZm7B(u"ࠧࡳࡧࡩࡩࡷ࡫ࡲ࠾ࠩ઀") not in yzieWRVX4nkB3DjGHJphEdQo.lower(): yzieWRVX4nkB3DjGHJphEdQo += cJSNFCIhymEfx6grGu0M(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶࠦࠨઁ")
	vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iAGgjwb7tVMmacRJ(u"ࠩࠣࠤࠥࡍ࡯ࡵࠢࡩ࡭ࡳࡧ࡬ࠡࡷࡵࡰࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪં")+yzieWRVX4nkB3DjGHJphEdQo+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࠤࡢ࠭ઃ"))
	kuz2FARH7lg = tDG1bZwX86UPjWEoVOJ.ListItem()
	AYH2MCZBnfUXQ,A1UJTqrLkGpli6wx,SZzsl3Yg8MqfVrWtA,TOSitYyRugKJGbeoFZ3v6LjVHs8E7q,mmFoY8a4O1ujdX,E72qFtbxzQ,v4dpw1fUnIuAakbsPNVJiCz5F,ooVNBGYtUR4yk1mZPhujzrC,Ml36aAbnejkFXU4EYtxRqSTu1DozN = blF9qcJ4uon53mZIQpDT7j(ccW1tVjJvUx5efKbPHu6yAMLqaF)
	if mUcijqvHal8pfEYhIoXSWdL6nx not in [CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭઄"),UighHKAfySm4PWErqJ(u"ࠬࡏࡐࡕࡘࠪઅ")]:
		if gA0m6CQUyfLG: CCRpAWoI6fO = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩઆ")
		else: CCRpAWoI6fO = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬઇ")
		kuz2FARH7lg.setProperty(CCRpAWoI6fO, G9G0YqivIfmUWO8K)
		kuz2FARH7lg.setMimeType(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨ࡯࡬ࡱࡪ࠵ࡸ࠮ࡶࡼࡴࡪ࠭ઈ"))
		if F7aJYwLMEmxAVRupWf<RVpeGcmPxj9tCnT40Nf216(u"࠵࠴ଡ଼"): kuz2FARH7lg.setInfo(Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡹ࡭ࡩ࡫࡯ࠨઉ"),{CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭ઊ"):bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡲࡵࡶࡪࡧࠪઋ")})
		else:
			Omn6HQSDPLR09AXyz = kuz2FARH7lg.getVideoInfoTag()
			Omn6HQSDPLR09AXyz.setMediaType(bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡳ࡯ࡷ࡫ࡨࠫઌ"))
		kuz2FARH7lg.setArt({wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠭ࡴࡩࡷࡰࡦࠬઍ"):mmFoY8a4O1ujdX,yiaeCEwJjOcWA4ZSd5h(u"ࠧࡱࡱࡶࡸࡪࡸࠧ઎"):mmFoY8a4O1ujdX,VHrIziKUDuNGXkMla(u"ࠨࡤࡤࡲࡳ࡫ࡲࠨએ"):mmFoY8a4O1ujdX,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠩࡩࡥࡳࡧࡲࡵࠩઐ"):mmFoY8a4O1ujdX,bneABYmwFUH8GXphg0Kl2Sq(u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬઑ"):mmFoY8a4O1ujdX,ssGdubC4mngM9D5SRc3Ye(u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ઒"):mmFoY8a4O1ujdX,bneABYmwFUH8GXphg0Kl2Sq(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨઓ"):mmFoY8a4O1ujdX,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"࠭ࡩࡤࡱࡱࠫઔ"):mmFoY8a4O1ujdX})
		if TJCK7aEsA0Dnl2FmQ in [ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧ࠯࡯ࡳࡨࠬક"),iAGgjwb7tVMmacRJ(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧખ")]: kuz2FARH7lg.setContentLookup(P5VqbRSzjtO4UE1rZaolG67XA)
		else: kuz2FARH7lg.setContentLookup(kkMuQrLWcEayRm)
		from diEohNHXbY import MJGPcFsKn9hfoukHbyOeS
		if dC3PsQJ0Ti28uYlov(u"ࠩࡵࡸࡲࡶࠧગ") in yzieWRVX4nkB3DjGHJphEdQo:
			MJGPcFsKn9hfoukHbyOeS(hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭ઘ"),kkMuQrLWcEayRm)
		elif TJCK7aEsA0Dnl2FmQ==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫ࠳ࡳࡰࡥࠩઙ") or iAGgjwb7tVMmacRJ(u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬચ") in yzieWRVX4nkB3DjGHJphEdQo:
			MJGPcFsKn9hfoukHbyOeS(qTVF3icWwGXy5(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭છ"),kkMuQrLWcEayRm)
			kuz2FARH7lg.setProperty(CCRpAWoI6fO,ssGdubC4mngM9D5SRc3Ye(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧજ"))
			kuz2FARH7lg.setProperty(dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨઝ"),dC3PsQJ0Ti28uYlov(u"ࠩࡰࡴࡩ࠭ઞ"))
		if TxrvPgQF4dk1b8Cc:
			kuz2FARH7lg.setSubtitles([TxrvPgQF4dk1b8Cc])
	if AYH2MCZBnfUXQ==ssGdubC4mngM9D5SRc3Ye(u"ࠪࡺ࡮ࡪࡥࡰࠩટ") and mUcijqvHal8pfEYhIoXSWdL6nx==rxWDdRBIct57i90s(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ઠ"):
		z2Fc1kie9fwvuaVTIs8CYt = jR9YtmsgDX8nTQlMb6G3(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬડ")
		mUcijqvHal8pfEYhIoXSWdL6nx = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭ઢ")
	elif AYH2MCZBnfUXQ==EHUAyW2lQfe4LXmhgIGc(u"ࠧࡷ࡫ࡧࡩࡴ࠭ણ") and ooVNBGYtUR4yk1mZPhujzrC.startswith(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࠸ࠪત")):
		z2Fc1kie9fwvuaVTIs8CYt = rr7Xolsp4JwjPK3L(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧથ")
		mUcijqvHal8pfEYhIoXSWdL6nx = mUcijqvHal8pfEYhIoXSWdL6nx+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡣࡉࡒࠧદ")
	if z2Fc1kie9fwvuaVTIs8CYt!=bneABYmwFUH8GXphg0Kl2Sq(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩધ"): PCxyizn0mbJW16cqVNIZBA()
	eTWASZtufxLs3Ny4kp.W0STqPpiCyOIVced25F4BXm6owRng(mUcijqvHal8pfEYhIoXSWdL6nx)
	if eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt: return iqHhJSxdaANDG5rlZm7B(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭ન")
	if AYH2MCZBnfUXQ==ssGdubC4mngM9D5SRc3Ye(u"࠭ࡶࡪࡦࡨࡳࠬ઩") and not ooVNBGYtUR4yk1mZPhujzrC.startswith(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧ࠷ࠩપ")):
		kuz2FARH7lg.setPath(yzieWRVX4nkB3DjGHJphEdQo)
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+iAGgjwb7tVMmacRJ(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨફ")+yzieWRVX4nkB3DjGHJphEdQo+DTF3Lwy9etRH8mI(u"ࠩࠣࡡࠬબ"))
		GWMro8TCBy2dNai.setResolvedUrl(Q0ykDeVYNBOECG5WU,P5VqbRSzjtO4UE1rZaolG67XA,kuz2FARH7lg)
	elif AYH2MCZBnfUXQ==dC3PsQJ0Ti28uYlov(u"ࠪࡰ࡮ࡼࡥࠨભ"):
		vvqQRbuChP(oz95q0dcEtSuxIJgP841M,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+cJSNFCIhymEfx6grGu0M(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧમ")+yzieWRVX4nkB3DjGHJphEdQo+RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠬࠦ࡝ࠨય"))
		eTWASZtufxLs3Ny4kp.play(yzieWRVX4nkB3DjGHJphEdQo,kuz2FARH7lg)
	pEU7uHoc0zQOC1Anab3KxZ9k = kkMuQrLWcEayRm
	if z2Fc1kie9fwvuaVTIs8CYt==GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫર"):
		from uQGjVohL2e import IIXSx6vntQc4gMJ
		pEU7uHoc0zQOC1Anab3KxZ9k = IIXSx6vntQc4gMJ(yzieWRVX4nkB3DjGHJphEdQo,TJCK7aEsA0Dnl2FmQ,mUcijqvHal8pfEYhIoXSWdL6nx)
		if pEU7uHoc0zQOC1Anab3KxZ9k: PCxyizn0mbJW16cqVNIZBA()
	else:
		Hvui6ETwrexpG9zcs5Cl,z2Fc1kie9fwvuaVTIs8CYt,kfhnA1XMdBO3oVT4NxEa,ZZ3Y6njyfHv7WURcp8PxK,ssPZeAdHXGzht9 = dQ5JhEYolPmy1fvHktMw6NFRxiz,cJSNFCIhymEfx6grGu0M(u"ࠧࡵࡴ࡬ࡩࡩ࠭઱"),kkMuQrLWcEayRm,qTVF3icWwGXy5(u"࠶࠶࠰࠱୞"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠸࠺࠶࠰࠱ଢ଼")
		if OJInHcqgYdM42bFPVau: import a1aDsx9ioY
		while Hvui6ETwrexpG9zcs5Cl<ssPZeAdHXGzht9:
			oR7SuW56ZQcpXnswUMqIkrP.sleep(ZZ3Y6njyfHv7WURcp8PxK)
			Hvui6ETwrexpG9zcs5Cl += ZZ3Y6njyfHv7WURcp8PxK
			if eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt==yiaeCEwJjOcWA4ZSd5h(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩલ") and not kfhnA1XMdBO3oVT4NxEa:
				if OJInHcqgYdM42bFPVau: a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(rr7Xolsp4JwjPK3L(u"้ࠩะาะฺࠠ็็๎ฮࠦล๋ฮสำࠥอไโ์า๎ํ࠭ળ"),ETNq5t4MYngSsbfFD8J0v(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫ઴"),SSCU3jdyFn2V=wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠽࠵࠱ୟ"))
				vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻࡚ࠢࠣ࡮ࡪࡥࡰࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨવ")+yzieWRVX4nkB3DjGHJphEdQo+UighHKAfySm4PWErqJ(u"ࠬࠦ࡝ࠨશ")+AOiSfR65Uey)
				kfhnA1XMdBO3oVT4NxEa = P5VqbRSzjtO4UE1rZaolG67XA
			elif eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt in [Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧષ"),EHUAyW2lQfe4LXmhgIGc(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨસ")]:
				vvqQRbuChP(ZQ6C9pmUGj4oIE12BJycX7,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RVpeGcmPxj9tCnT40Nf216(u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼ࡭ࡳ࡭࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬહ")+yzieWRVX4nkB3DjGHJphEdQo+yiaeCEwJjOcWA4ZSd5h(u"ࠩࠣࡡࠬ઺")+AOiSfR65Uey)
				break
			elif eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ઻"):
				vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡱ࡮ࡤࡽ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤ઼ࠬ")+yzieWRVX4nkB3DjGHJphEdQo+iqHhJSxdaANDG5rlZm7B(u"ࠬࠦ࡝ࠨઽ")+AOiSfR65Uey)
				if OJInHcqgYdM42bFPVau: a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(FWqeEzO1i8Dn0ga(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪા"),iAGgjwb7tVMmacRJ(u"ࠧࡇࡣ࡬ࡰࡺࡸࡥࠨિ"),SSCU3jdyFn2V=t2sCrJ0xbgDRkf(u"࠷࠶࠲ୠ"))
				break
			elif eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt==wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩી"):
				vvqQRbuChP(jT5y4a7sUiLJ8R,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࠣࠤࠥࡊࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡤ࡯ࡳࡨࡱࡥࡥࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧુ")+yzieWRVX4nkB3DjGHJphEdQo+rxWDdRBIct57i90s(u"ࠪࠤࡢ࠭ૂ"))
				break
		else: z2Fc1kie9fwvuaVTIs8CYt = EHUAyW2lQfe4LXmhgIGc(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬૃ")
	if z2Fc1kie9fwvuaVTIs8CYt in [rr7Xolsp4JwjPK3L(u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬૄ")] or eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt in [bneABYmwFUH8GXphg0Kl2Sq(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧૅ"),UighHKAfySm4PWErqJ(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ૆")] or pEU7uHoc0zQOC1Anab3KxZ9k: UhZuB0G4InHX7s(mUcijqvHal8pfEYhIoXSWdL6nx)
	else: exec(iqHhJSxdaANDG5rlZm7B(u"ࠨ࡫ࡰࡴࡴࡸࡴࠡࡺࡥࡱࡨࡁࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ે"))
	wUiO1mSaIV2r3sHoANZ6 = oR7SuW56ZQcpXnswUMqIkrP.Player().isPlaying()
	if not wUiO1mSaIV2r3sHoANZ6 and z2Fc1kie9fwvuaVTIs8CYt not in [CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧૈ")]:
		msg = EHUAyW2lQfe4LXmhgIGc(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫૉ") if z2Fc1kie9fwvuaVTIs8CYt==FWqeEzO1i8Dn0ga(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ૊") else DTF3Lwy9etRH8mI(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭ો")
		if OJInHcqgYdM42bFPVau: a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪૌ"),msg,SSCU3jdyFn2V=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠸࠷࠳ୡ"))
		vvqQRbuChP(DqJLhysGer98KFOZ,ag0UEFd3x5vzSkce14uGDbwK(s5slfAmHkUtMR3WSKY1ZTX)+qTVF3icWwGXy5(u"્ࠧࠡࠢࠣࠫ")+msg+wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠨ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ૎")+yzieWRVX4nkB3DjGHJphEdQo+bneABYmwFUH8GXphg0Kl2Sq(u"ࠩࠣࡡࠬ૏")+AOiSfR65Uey)
	return eTWASZtufxLs3Ny4kp.wkl1TALE2MscoZuWt
def Ig4jFuXGfUQeCn6wlB8(yzieWRVX4nkB3DjGHJphEdQo):
	path = DTF3Lwy9etRH8mI(u"ࠪ࠳ࠬૐ").join(yzieWRVX4nkB3DjGHJphEdQo.split(UighHKAfySm4PWErqJ(u"ࠫ࠴࠭૑"))[GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠵ୢ"):]) if wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡀ࠯࠰ࠩ૒") in yzieWRVX4nkB3DjGHJphEdQo else yzieWRVX4nkB3DjGHJphEdQo
	J5zLvtGUjYM2gxI = oo9kuULlebNgpY0Om.findall(yiaeCEwJjOcWA4ZSd5h(u"࠭࡜࠯ࠪ࡞ࡥ࠲ࢀ࠰࠮࠻ࡠ࠯࠮࠭૓"),path,oo9kuULlebNgpY0Om.DOTALL)
	BlLcZnK69sPiFf = [cjbAkCIinvs(u"ࠧ࡮࠵ࡸ࠼ࠬ૔"),cJSNFCIhymEfx6grGu0M(u"ࠨ࡯ࡳ࠸ࠬ૕"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࡰࡴࡩ࠭૖"),t2sCrJ0xbgDRkf(u"ࠪࡻࡪࡨ࡭ࠨ૗"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡦࡼࡩࠨ૘"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠬࡧࡡࡤࠩ૙"),bneABYmwFUH8GXphg0Kl2Sq(u"࠭࡭࠴ࡷࠪ૚"),yiaeCEwJjOcWA4ZSd5h(u"ࠧ࡮࡭ࡹࠫ૛"),Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠨࡨ࡯ࡺࠬ૜"),RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࡰࡴ࠸࠭૝"),vCmnFshSi4flecXIY2gy38G0DJw(u"ࠪࡸࡸ࠭૞")]
	for WaGrcsxKZIdAT in J5zLvtGUjYM2gxI:
		if WaGrcsxKZIdAT in BlLcZnK69sPiFf: return Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"ࠫ࠳࠭૟")+WaGrcsxKZIdAT
	return G9G0YqivIfmUWO8K
def UhZuB0G4InHX7s(kQtFlTA5d9p8Lho):
	if not iKLYEvx39c.w0Zn3BsVo7GWDyuli: kQtFlTA5d9p8Lho += hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡥࡔࡔࠩૠ")
	IIHKo82wPrNpgqCkQJOV.append(kQtFlTA5d9p8Lho)
	return
def fdGJteXp3aEi2wcMYDgP0T46lZ(RRXMNDk3SUWz8Tf1QrEv4=kkMuQrLWcEayRm):
	jBzmSE2F7uCKJ4pw5QxT9Df8W(RRXMNDk3SUWz8Tf1QrEv4,ssGdubC4mngM9D5SRc3Ye(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩૡ"))
	yyrcMwk6RWmH3xOKQUpGdghiX.exit()
def jBzmSE2F7uCKJ4pw5QxT9Df8W(RRXMNDk3SUWz8Tf1QrEv4,fEKoHajMCOh):
	if fEKoHajMCOh:
		if bneABYmwFUH8GXphg0Kl2Sq(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪૢ") in fEKoHajMCOh: vvqQRbuChP(G9G0YqivIfmUWO8K,rxWDdRBIct57i90s(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫૣ"))
		else:
			pxwYdJA4eTtiI25HXBQ9nKuV7l = amx9qJHkhw7oLdtVMG3.getSetting(UighHKAfySm4PWErqJ(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ૤"))
			amx9qJHkhw7oLdtVMG3.setSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૥"),G9G0YqivIfmUWO8K)
			import a1aDsx9ioY
			a1aDsx9ioY.XDk4GnqsF2KNRptPwfg0cBJebZ(fEKoHajMCOh)
			amx9qJHkhw7oLdtVMG3.setSetting(iqHhJSxdaANDG5rlZm7B(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ૦"),pxwYdJA4eTtiI25HXBQ9nKuV7l)
	vlcUutakSyFDIi(yiaeCEwJjOcWA4ZSd5h(u"ࠬࡹࡴࡰࡲࠪ૧"))
	w0oqhWrypS1QlT5zX6UAnFIGfKOkc = amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ૨"))
	if w0oqhWrypS1QlT5zX6UAnFIGfKOkc==iqHhJSxdaANDG5rlZm7B(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ૩"): amx9qJHkhw7oLdtVMG3.setSetting(bneABYmwFUH8GXphg0Kl2Sq(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ૪"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૫"))
	elif w0oqhWrypS1QlT5zX6UAnFIGfKOkc==t2sCrJ0xbgDRkf(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ૬"): amx9qJHkhw7oLdtVMG3.setSetting(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ૭"),G9G0YqivIfmUWO8K)
	if amx9qJHkhw7oLdtVMG3.getSetting(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ૮")) not in [rxWDdRBIct57i90s(u"࠭ࡁࡖࡖࡒࠫ૯"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡔࡖࡒࡔࠬ૰"),cjbAkCIinvs(u"ࠨࡃࡖࡏࠬ૱")]: amx9qJHkhw7oLdtVMG3.setSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ૲"),yiaeCEwJjOcWA4ZSd5h(u"ࠪࡅࡘࡑࠧ૳"))
	if amx9qJHkhw7oLdtVMG3.getSetting(qTVF3icWwGXy5(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ૴")) not in [hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࡇࡕࡕࡑࠪ૵"),vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ࡓࡕࡑࡓࠫ૶"),ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧࡂࡕࡎࠫ૷")]: amx9qJHkhw7oLdtVMG3.setSetting(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭૸"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠩࡄࡗࡐ࠭ૹ"))
	TTqi9PKphMHbv = amx9qJHkhw7oLdtVMG3.getSetting(RVpeGcmPxj9tCnT40Nf216(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨૺ"))
	ZQclMw2RbJL = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(EHUAyW2lQfe4LXmhgIGc(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧૻ"))
	if dC3PsQJ0Ti28uYlov(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫૼ") in str(ZQclMw2RbJL) and TTqi9PKphMHbv in [hhdGMSsBzel96obfEmrwiuLPOvq(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ૽"),hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭૾")]:
		SSCU3jdyFn2V.sleep(VHrIziKUDuNGXkMla(u"࠳࠲࠶࠶࠰ୣ"))
		oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬ૿"))
	if dQ5JhEYolPmy1fvHktMw6NFRxiz and Q0ykDeVYNBOECG5WU>-fdQOo6Hu4B5Rbg:
		GWMro8TCBy2dNai.setResolvedUrl(Q0ykDeVYNBOECG5WU,kkMuQrLWcEayRm,tDG1bZwX86UPjWEoVOJ.ListItem())
		pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ = kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm
		GWMro8TCBy2dNai.endOfDirectory(Q0ykDeVYNBOECG5WU,pEU7uHoc0zQOC1Anab3KxZ9k,T5bfMDupFVnvX6cdikURs1,lGKXAJ1nuoQFjZ)
	if IIHKo82wPrNpgqCkQJOV:
		lSwfMdcGe2ZXy = fu19TY0PdM6AZB5.Thread(target=HMF6jA382ENmk7q1,args=(IIHKo82wPrNpgqCkQJOV,))
		lSwfMdcGe2ZXy.start()
	eFQmjNWHfLI29upJd3UbZVSXl = xnPeISFRsg3XjbYZW7L()
	wUiO1mSaIV2r3sHoANZ6 = oR7SuW56ZQcpXnswUMqIkrP.Player().isPlaying()
	if eFQmjNWHfLI29upJd3UbZVSXl:
		if not wUiO1mSaIV2r3sHoANZ6: PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(yiaeCEwJjOcWA4ZSd5h(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩ଀"))
		else:
			elmoA60CiZIYBj41csHRQVGLq = AKky3HT8roi5GOwFBsSR0vdm()
			if elmoA60CiZIYBj41csHRQVGLq:
				iKLYEvx39c.resolveonly = P5VqbRSzjtO4UE1rZaolG67XA
				SSCU3jdyFn2V.sleep(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠺࠵୤"))
				wUiO1mSaIV2r3sHoANZ6 = oR7SuW56ZQcpXnswUMqIkrP.Player().isPlaying()
				if wUiO1mSaIV2r3sHoANZ6:
					C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3 = blF9qcJ4uon53mZIQpDT7j(elmoA60CiZIYBj41csHRQVGLq)
					import a1aDsx9ioY
					if not any(yW70dtahIjkPCJg2TA in Tqd89eUHZ7l for yW70dtahIjkPCJg2TA in a1aDsx9ioY.NOT_TO_TEST_ALL_SERVERS):
						a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(RVpeGcmPxj9tCnT40Nf216(u"ࠪห้็๊ะ์๋ࠤฬ๊ไศฯๅࠫଁ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩଂ"),SSCU3jdyFn2V=dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠶࠶࠰࠱୥"))
						SSCU3jdyFn2V.sleep(RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠸୦"))
						if gA0m6CQUyfLG:
							yzieWRVX4nkB3DjGHJphEdQo = yzieWRVX4nkB3DjGHJphEdQo.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
						a1aDsx9ioY.ggGCyoxkHXwif(kkMuQrLWcEayRm,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
						tRojAyBgfDH37eLCwP4dWl = a1aDsx9ioY.TadilgrWnheCzbZI4LHv1S7DVB(C9uTVdSkLlb5UemavyB6NjWHFh,Tqd89eUHZ7l,yzieWRVX4nkB3DjGHJphEdQo,bmP3CnZr75H984yd1k2Ng0EYLA,Vy1U0koJLPFhxe2TS,eehFlSEjHioyAWpLqZXt79,xCVyDu98lp4NE3MR6A0,CW2cwYfL9s,zF4nhxYlaiKPwA6NJZ3)
						a1aDsx9ioY.ggGCyoxkHXwif(P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
						a1aDsx9ioY.XXeZuvhknsKYqB17gwm6dfc(DTF3Lwy9etRH8mI(u"ࠬอไโ์า๎ํࠦวๅๆสั็࠭ଃ"),rr7Xolsp4JwjPK3L(u"࠭ว็ฬ๊ํࠥ็อึࠢสุ่๐ัโำสฮࠬ଄"),SSCU3jdyFn2V=iAGgjwb7tVMmacRJ(u"࠱࠱࠲࠳୧"))
						RRXMNDk3SUWz8Tf1QrEv4 = kkMuQrLWcEayRm
	wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = amx9qJHkhw7oLdtVMG3.getSetting(EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡦ࡮ࡺࡲࡢࡶࡨࠫଅ"))
	if EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠨ࠯ࠪଆ") in wwCFVzNkHGQsoRYgpDhtL4qJ7dBP:
		wwCFVzNkHGQsoRYgpDhtL4qJ7dBP = wwCFVzNkHGQsoRYgpDhtL4qJ7dBP.replace(t2sCrJ0xbgDRkf(u"ࠩ࠰ࠫଇ"),G9G0YqivIfmUWO8K)
		amx9qJHkhw7oLdtVMG3.setSetting(EHUAyW2lQfe4LXmhgIGc(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧଈ"),wwCFVzNkHGQsoRYgpDhtL4qJ7dBP)
	if RRXMNDk3SUWz8Tf1QrEv4: oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨଉ"))
	return
def AKky3HT8roi5GOwFBsSR0vdm():
	g5reJ0EY7XhuHKx = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹ࠴ࡇࡦࡶࡌࡸࡪࡳࡳࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶࠲ࠢࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ࠿ࡡࠢࡵ࡫ࡷࡰࡪࠨࠬࠣࡨ࡬ࡰࡪࠨࠬࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦࡢࢃࠬࠣ࡫ࡧࠦ࠿࠷ࡽࠨଊ"))
	tRojAyBgfDH37eLCwP4dWl = EEMsy4SLwnD0T92ztchdIUZ.loads(g5reJ0EY7XhuHKx)[RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ଋ")]
	elmoA60CiZIYBj41csHRQVGLq = G9G0YqivIfmUWO8K
	try: items = tRojAyBgfDH37eLCwP4dWl[wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡪࡶࡨࡱࡸ࠭ଌ")]
	except: return G9G0YqivIfmUWO8K
	if items:
		for JXKAgPztneLxQh,file in enumerate(items):
			path = file[iAGgjwb7tVMmacRJ(u"ࠨࡨ࡬ࡰࡪ࠭଍")]
			if IJPabrdjXE7HGR163qY48pMVU5l not in path: continue
			path = path.split(IJPabrdjXE7HGR163qY48pMVU5l)[fdQOo6Hu4B5Rbg][fdQOo6Hu4B5Rbg:]
			if path==ccW1tVjJvUx5efKbPHu6yAMLqaF: break
		count = tRojAyBgfDH37eLCwP4dWl[ETNq5t4MYngSsbfFD8J0v(u"ࠩ࡯࡭ࡲ࡯ࡴࡴࠩ଎")][RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠪࡸࡴࡺࡡ࡭ࠩଏ")]
		if JXKAgPztneLxQh+fdQOo6Hu4B5Rbg<count: elmoA60CiZIYBj41csHRQVGLq = items[JXKAgPztneLxQh+fdQOo6Hu4B5Rbg][cjbAkCIinvs(u"ࠫ࡫࡯࡬ࡦࠩଐ")]
	return elmoA60CiZIYBj41csHRQVGLq
def xnPeISFRsg3XjbYZW7L():
	PFpbXEKiR7nLu4AYd = oR7SuW56ZQcpXnswUMqIkrP.executeJSONRPC(qTVF3icWwGXy5(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡺ࡮ࡪࡥࡰࡲ࡯ࡥࡾ࡫ࡲ࠯ࡣࡸࡸࡴࡶ࡬ࡢࡻࡱࡩࡽࡺࡩࡵࡧࡰࠦࢂࢃࠧ଑"))
	BYRz6kMFpxG3NcqOj5902XirEn = kkMuQrLWcEayRm if rxWDdRBIct57i90s(u"࡛࠭࡞ࠩ଒") in str(PFpbXEKiR7nLu4AYd) else P5VqbRSzjtO4UE1rZaolG67XA
	return BYRz6kMFpxG3NcqOj5902XirEn
def vlcUutakSyFDIi(NWwd5VE8Aa3qP):
	global sqOTfRikj0nJUr9a38QpwhogNCXBdx
	if sqOTfRikj0nJUr9a38QpwhogNCXBdx:
		if NWwd5VE8Aa3qP==VHrIziKUDuNGXkMla(u"ࠧࡴࡶࡲࡴࠬଓ"):
			oyNTx5pdWm1jO8sJuAX = rr7Xolsp4JwjPK3L(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ଔ") if F7aJYwLMEmxAVRupWf>vCmnFshSi4flecXIY2gy38G0DJw(u"࠲࠹࠱࠽࠾୨") else EHUAyW2lQfe4LXmhgIGc(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭କ")
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪଖ")+oyNTx5pdWm1jO8sJuAX+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫ࠮࠭ଗ"))
			sqOTfRikj0nJUr9a38QpwhogNCXBdx = kkMuQrLWcEayRm
	else:
		if NWwd5VE8Aa3qP==cjbAkCIinvs(u"ࠬࡹࡴࡢࡴࡷࠫଘ"):
			oyNTx5pdWm1jO8sJuAX = RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫଙ") if F7aJYwLMEmxAVRupWf>cjbAkCIinvs(u"࠳࠺࠲࠾࠿୩") else qTVF3icWwGXy5(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫଚ")
			oR7SuW56ZQcpXnswUMqIkrP.executebuiltin(vCmnFshSi4flecXIY2gy38G0DJw(u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪଛ")+oyNTx5pdWm1jO8sJuAX+FWqeEzO1i8Dn0ga(u"ࠩࠬࠫଜ"))
			sqOTfRikj0nJUr9a38QpwhogNCXBdx = P5VqbRSzjtO4UE1rZaolG67XA
	return
QBgxljAsKkzpDrXHieuOI9Ft,RRQAdgVyq6LOf1coM0v = None,None
IIHKo82wPrNpgqCkQJOV = []
iOtjqZ6Iydl = bVA4SCPumtZKi()
qqeE2oiXPnzLKk = iOtjqZ6Iydl.splitlines()[dQ5JhEYolPmy1fvHktMw6NFRxiz][-rxWDdRBIct57i90s(u"࠵࠸୪"):]
iKLYEvx39c.t6Xn5IBwJPG0so47MEif,iKLYEvx39c.w0Zn3BsVo7GWDyuli,iKLYEvx39c.b7sHudTqiWcg51n9IlXJ0BzAa,iKLYEvx39c.kqWwuhJS1K3gIvpbQnGRcfl0C = kWUE5INdVuX9wSOFsnZ([EHUAyW2lQfe4LXmhgIGc(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫଝ"),jR9YtmsgDX8nTQlMb6G3(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬଞ"),wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪଟ"),wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧଠ")])
ttWSxEM3Gp = G9G0YqivIfmUWO8K
iKLYEvx39c.resolveonly = kkMuQrLWcEayRm
eTWASZtufxLs3Ny4kp = hCOtUkrGsJEgxqKibN()
iKLYEvx39c.showDialogs = P5VqbRSzjtO4UE1rZaolG67XA
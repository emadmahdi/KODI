# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'LIVETV'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN['PYTHON'][0]
def RAndFk3y4Pbvs29(mode,url):
	if   mode==100: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==101: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI('0',True)
	elif mode==102: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI('1',True)
	elif mode==103: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI('2',True)
	elif mode==104: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI('3',True)
	elif mode==105: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==106: tRojAyBgfDH37eLCwP4dWl = Mt7X1vp6TLucKVrw8EUhyI('4',True)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder','_M3U_'+'قوائم فيديوهات M3U',G9G0YqivIfmUWO8K,762)
	Qm8SMu6ecXtigDCWw1oak('folder','_IPT_'+'قوائم فيديوهات IPTV',G9G0YqivIfmUWO8K,761)
	Qm8SMu6ecXtigDCWw1oak('folder','_TV0_'+'قنوات من مواقعها الأصلية',G9G0YqivIfmUWO8K,101)
	Qm8SMu6ecXtigDCWw1oak('folder','_TV4_'+'قنوات مختارة من يوتيوب',G9G0YqivIfmUWO8K,106)
	Qm8SMu6ecXtigDCWw1oak('folder','_YUT_'+'قنوات عربية من يوتيوب',G9G0YqivIfmUWO8K,147)
	Qm8SMu6ecXtigDCWw1oak('folder','_YUT_'+'قنوات أجنبية من يوتيوب',G9G0YqivIfmUWO8K,148)
	Qm8SMu6ecXtigDCWw1oak('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',G9G0YqivIfmUWO8K,28)
	Qm8SMu6ecXtigDCWw1oak('live','_MRF_'+'قناة المعارف من موقعهم',G9G0YqivIfmUWO8K,41)
	Qm8SMu6ecXtigDCWw1oak('live','_PNT_'+'قناة هلا من موقع بانيت',G9G0YqivIfmUWO8K,38)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder','_TV1_'+'قنوات تلفزيونية عامة',G9G0YqivIfmUWO8K,102)
	Qm8SMu6ecXtigDCWw1oak('folder','_TV2_'+'قنوات تلفزيونية خاصة',G9G0YqivIfmUWO8K,103)
	Qm8SMu6ecXtigDCWw1oak('folder','_TV3_'+'قنوات تلفزيونية للفحص',G9G0YqivIfmUWO8K,104)
	return
def Mt7X1vp6TLucKVrw8EUhyI(hifDqHbzE39x5Jja7wsd8OeTvotYIB,showDialogs=True):
	TdtCLWYSJNK8zOb = '_TV'+hifDqHbzE39x5Jja7wsd8OeTvotYIB+'_'
	QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = {'id':G9G0YqivIfmUWO8K,'user':iOtjqZ6Iydl,'function':'list','menu':hifDqHbzE39x5Jja7wsd8OeTvotYIB}
	D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',ffVP3AK5RqhkgYnjZoNis,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIVETV-ITEMS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	items = oo9kuULlebNgpY0Om.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if items:
		for KT9tdUH3hmiLZCEFz in range(len(items)):
			name = items[KT9tdUH3hmiLZCEFz][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[KT9tdUH3hmiLZCEFz] = items[KT9tdUH3hmiLZCEFz][0],items[KT9tdUH3hmiLZCEFz][1],items[KT9tdUH3hmiLZCEFz][2],name,items[KT9tdUH3hmiLZCEFz][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for XdoFLQ20O6SNVlcp,yVgLqfcUN1iO4,TJMXlg4jb6GzS5ew,name,M4qkBDatEIf3T in items:
			if '#' in XdoFLQ20O6SNVlcp: continue
			if XdoFLQ20O6SNVlcp!='URL': name = name+A7XhkmSYZlidyMt5FpWqTgjNezbnD+wKBSo48e5PYtn63DpiG+XdoFLQ20O6SNVlcp+zzGfwLAyN5HTxUoJeaivY
			url = XdoFLQ20O6SNVlcp+';;'+yVgLqfcUN1iO4+';;'+TJMXlg4jb6GzS5ew+';;'+hifDqHbzE39x5Jja7wsd8OeTvotYIB
			Qm8SMu6ecXtigDCWw1oak('live',TdtCLWYSJNK8zOb+G9G0YqivIfmUWO8K+name,url,105,M4qkBDatEIf3T)
	else:
		if showDialogs: Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+'هذه الخدمة مخصصة للمبرمج فقط',G9G0YqivIfmUWO8K,9999)
	return
def sWujQcGynM9NtJeTfqk3D(id):
	XdoFLQ20O6SNVlcp,yVgLqfcUN1iO4,TJMXlg4jb6GzS5ew,hifDqHbzE39x5Jja7wsd8OeTvotYIB = id.split(';;')
	url = G9G0YqivIfmUWO8K
	if XdoFLQ20O6SNVlcp=='URL': url = TJMXlg4jb6GzS5ew
	elif XdoFLQ20O6SNVlcp=='YOUTUBE':
		url = Kkfl8xemuHbd1w3a0ABPcDrN['YOUTUBE'][0]+'/watch?v='+TJMXlg4jb6GzS5ew
		import iOVAoxDJew
		iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk([url],s5slfAmHkUtMR3WSKY1ZTX,'live',url)
		return
	elif XdoFLQ20O6SNVlcp=='GA':
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'id' : G9G0YqivIfmUWO8K, 'user' : iOtjqZ6Iydl , 'function' : 'playGA1' , 'menu' : G9G0YqivIfmUWO8K }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,G9G0YqivIfmUWO8K,False,G9G0YqivIfmUWO8K,'LIVETV-PLAY-1st')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		cookies = D7omduSeM5Gk.cookies
		ko8YKizX2n9GSLU = cookies['ASP.NET_SessionId']
		url = D7omduSeM5Gk.headers['Location']
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'id' : TJMXlg4jb6GzS5ew , 'user' : iOtjqZ6Iydl , 'function' : 'playGA2' , 'menu' : G9G0YqivIfmUWO8K }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+ko8YKizX2n9GSLU }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'GET',ffVP3AK5RqhkgYnjZoNis,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIVETV-PLAY-2nd')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		url = oo9kuULlebNgpY0Om.findall('resp":"(http.*?m3u8)(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		Y6YdkAMluFbwx = url[0][0]
		uRh0OfcrCjvt7LQEgk = url[0][1]
		eeb6rUVMlQN5qK40m = 'http://38.'+yVgLqfcUN1iO4+'777/'+TJMXlg4jb6GzS5ew+'_HD.m3u8'+uRh0OfcrCjvt7LQEgk
		qmJr9MhERHTVW2Xe = eeb6rUVMlQN5qK40m.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		PnrIYmMjONBUAXwdb810Eguxp = eeb6rUVMlQN5qK40m.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		Bs6eUlPNYrgFZ9SCAcu41nqXmf5GwO = ['HD','SD1','SD2']
		ODnaR0N8UHv7Twy6jS = [eeb6rUVMlQN5qK40m,qmJr9MhERHTVW2Xe,PnrIYmMjONBUAXwdb810Eguxp]
		PXeEIRkdShOGm45lbLJc2B38s = 0
		if PXeEIRkdShOGm45lbLJc2B38s == -1: return
		else: url = ODnaR0N8UHv7Twy6jS[PXeEIRkdShOGm45lbLJc2B38s]
	elif XdoFLQ20O6SNVlcp=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'id' : TJMXlg4jb6GzS5ew , 'user' : iOtjqZ6Iydl , 'function' : 'playNT' , 'menu' : hifDqHbzE39x5Jja7wsd8OeTvotYIB }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST', ffVP3AK5RqhkgYnjZoNis, QKsd6VmaOnMPCWuqcTyl28JZH7ASjo, headers, False,G9G0YqivIfmUWO8K,'LIVETV-PLAY-3rd')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		url = D7omduSeM5Gk.headers['Location']
		url = url.replace('%20',ww0sZkBU9JKd)
		url = url.replace('%3D','=')
		if 'Learn' in TJMXlg4jb6GzS5ew:
			url = url.replace('NTNNile',G9G0YqivIfmUWO8K)
			url = url.replace('learning1','Learning')
	elif XdoFLQ20O6SNVlcp=='PL':
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'id' : TJMXlg4jb6GzS5ew , 'user' : iOtjqZ6Iydl , 'function' : 'playPL' , 'menu' : hifDqHbzE39x5Jja7wsd8OeTvotYIB }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST', ffVP3AK5RqhkgYnjZoNis, QKsd6VmaOnMPCWuqcTyl28JZH7ASjo, G9G0YqivIfmUWO8K,False,G9G0YqivIfmUWO8K,'LIVETV-PLAY-4th')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		url = D7omduSeM5Gk.headers['Location']
		headers = {'Referer':D7omduSeM5Gk.headers['Referer']}
		D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'POST',url, G9G0YqivIfmUWO8K,headers , G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIVETV-PLAY-5th')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		items = oo9kuULlebNgpY0Om.findall('source src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		url = items[0]
	elif XdoFLQ20O6SNVlcp in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if XdoFLQ20O6SNVlcp=='TA': TJMXlg4jb6GzS5ew = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		QKsd6VmaOnMPCWuqcTyl28JZH7ASjo = { 'id' : TJMXlg4jb6GzS5ew , 'user' : iOtjqZ6Iydl , 'function' : 'play'+XdoFLQ20O6SNVlcp , 'menu' : hifDqHbzE39x5Jja7wsd8OeTvotYIB }
		D7omduSeM5Gk = PPRoOyl2xVH(HpjLKS83swXDzVInEf2xUZaCuNbR9d,'POST',ffVP3AK5RqhkgYnjZoNis,QKsd6VmaOnMPCWuqcTyl28JZH7ASjo,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'LIVETV-PLAY-6th')
		if not D7omduSeM5Gk.succeeded:
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		url = D7omduSeM5Gk.headers['Location']
		if XdoFLQ20O6SNVlcp=='FM':
			D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET', url, G9G0YqivIfmUWO8K, G9G0YqivIfmUWO8K, False,G9G0YqivIfmUWO8K,'LIVETV-PLAY-7th')
			url = D7omduSeM5Gk.headers['Location']
			url = url.replace('https','http')
	Imphr8LRTUDs(url,s5slfAmHkUtMR3WSKY1ZTX,'live')
	return
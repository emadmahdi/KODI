# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
import bs4 as GROJ24tpaQ7iNZr0uqy3X8WmE
s5slfAmHkUtMR3WSKY1ZTX = 'ELCINEMA'
TdtCLWYSJNK8zOb = '_ELC_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
headers = {'Referer':ffVP3AK5RqhkgYnjZoNis}
tlcXBJEfIHF02vQ6yxSom9z1 = []
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==510: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==511: tRojAyBgfDH37eLCwP4dWl = UbdG8ArlT25WF(url)
	elif mode==512: tRojAyBgfDH37eLCwP4dWl = nbktMzeI0jgfVXO2hyK4B(url)
	elif mode==513: tRojAyBgfDH37eLCwP4dWl = MI6WBhZtnAbkRQz3T9L5X(url)
	elif mode==514: tRojAyBgfDH37eLCwP4dWl = h7mi1co6XrVlvnd5fLF2QIjAU(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: tRojAyBgfDH37eLCwP4dWl = h7mi1co6XrVlvnd5fLF2QIjAU(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: tRojAyBgfDH37eLCwP4dWl = G4j96ZolXwEaeqsfAVhrk(text)
	elif mode==517: tRojAyBgfDH37eLCwP4dWl = VBbhHNZcCDJl(url)
	elif mode==518: tRojAyBgfDH37eLCwP4dWl = rLXQqK4GbehYd7sJ6MyOCUczpkm(url)
	elif mode==519: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	elif mode==520: tRojAyBgfDH37eLCwP4dWl = l8Yt1BnvUQHShKpmXFZjE0M(url)
	elif mode==521: tRojAyBgfDH37eLCwP4dWl = r1rHNUGqdBgL8C5RzSaZ9u72O(url)
	elif mode==522: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==523: tRojAyBgfDH37eLCwP4dWl = kspuVRGHBNZU(text)
	elif mode==524: tRojAyBgfDH37eLCwP4dWl = MJV9d7IXy1zFNhx4QWmHvt6q()
	elif mode==525: tRojAyBgfDH37eLCwP4dWl = Iyv71YknOGECANJcuFleWD()
	elif mode==526: tRojAyBgfDH37eLCwP4dWl = eUd7yxhbHWa8ZNAqtG()
	elif mode==527: tRojAyBgfDH37eLCwP4dWl = t5t7nudOrYGmDyR6SZBTQcW()
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث بموسوعة السينما',G9G0YqivIfmUWO8K,519)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'موسوعة الأعمال',G9G0YqivIfmUWO8K,525)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'موسوعة الأشخاص',G9G0YqivIfmUWO8K,526)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'موسوعة المصنفات',G9G0YqivIfmUWO8K,527)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'موسوعة المنوعات',G9G0YqivIfmUWO8K,524)
	return
def MJV9d7IXy1zFNhx4QWmHvt6q():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' فيديوهات - خاصة',ffVP3AK5RqhkgYnjZoNis+'/video',520)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فيديوهات - أحدث',ffVP3AK5RqhkgYnjZoNis+'/video/latest',521)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فيديوهات - أقدم',ffVP3AK5RqhkgYnjZoNis+'/video/oldest',521)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فيديوهات - أكثر مشاهدة',ffVP3AK5RqhkgYnjZoNis+'/video/views',521)
	return
def Iyv71YknOGECANJcuFleWD():
	O03G9hKRZPQkad = ffVP3AK5RqhkgYnjZoNis+'/lineup?utf8=%E2%9C%93'
	V1VGgmCDk5Y9xq = O03G9hKRZPQkad+'&type=2&category=1&foreign=false&tag='
	ZDO2AxMdzaJ8 = O03G9hKRZPQkad+'&type=2&category=3&foreign=false&tag='
	qY5gnKxSB7HQfokriIRE = O03G9hKRZPQkad+'&type=2&category=1&foreign=true&tag='
	T9EZk0gfKX = O03G9hKRZPQkad+'&type=2&category=3&foreign=true&tag='
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات أفلام عربي',V1VGgmCDk5Y9xq,511)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات مسلسلات عربي',ZDO2AxMdzaJ8,511)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات أفلام اجنبي',qY5gnKxSB7HQfokriIRE,511)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات مسلسلات اجنبي',T9EZk0gfKX,511)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس أعمال أبجدي',ffVP3AK5RqhkgYnjZoNis+'/index/work/alphabet',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس  بلد الإنتاج',ffVP3AK5RqhkgYnjZoNis+'/index/work/country',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس اللغة',ffVP3AK5RqhkgYnjZoNis+'/index/work/language',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس مصنفات العمل',ffVP3AK5RqhkgYnjZoNis+'/index/work/genre',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس سنة الإصدار',ffVP3AK5RqhkgYnjZoNis+'/index/work/release_year',517)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مواسم - فلتر محدد',ffVP3AK5RqhkgYnjZoNis+'/seasonals',515)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مواسم - فلتر كامل',ffVP3AK5RqhkgYnjZoNis+'/seasonals',514)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات - فلتر محدد',ffVP3AK5RqhkgYnjZoNis+'/lineup',515)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات - فلتر كامل',ffVP3AK5RqhkgYnjZoNis+'/lineup',514)
	return
def t5t7nudOrYGmDyR6SZBTQcW():
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis+'/lineup',G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	BN1KdkzCmvshw = t6SKaQwq7Cszke9jGlUW42bo.find('select',attrs={'name':'tag'})
	EIcQfuLpMO2jX = BN1KdkzCmvshw.find_all('option')
	for M0nQuWoaIxhSdqyV9N in EIcQfuLpMO2jX:
		yW70dtahIjkPCJg2TA = M0nQuWoaIxhSdqyV9N.get('value')
		if not yW70dtahIjkPCJg2TA: continue
		title = M0nQuWoaIxhSdqyV9N.text
		if gA0m6CQUyfLG:
			title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			yW70dtahIjkPCJg2TA = yW70dtahIjkPCJg2TA.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+yW70dtahIjkPCJg2TA
		title = title.replace('قائمة ',G9G0YqivIfmUWO8K)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,511)
	return
def eUd7yxhbHWa8ZNAqtG():
	O03G9hKRZPQkad = ffVP3AK5RqhkgYnjZoNis+'/lineup?utf8=%E2%9C%93'
	SSHDzNikR29jQxn6ITCfdboM = O03G9hKRZPQkad+'&type=1&category=&foreign=&tag='
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات أشخاص',SSHDzNikR29jQxn6ITCfdboM,511)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس أشخاص أبجدي',ffVP3AK5RqhkgYnjZoNis+'/index/person/alphabet',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس موطن',ffVP3AK5RqhkgYnjZoNis+'/index/person/nationality',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس  تاريخ الميلاد',ffVP3AK5RqhkgYnjZoNis+'/index/person/birth_year',517)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فهرس  تاريخ الوفاة',ffVP3AK5RqhkgYnjZoNis+'/index/person/death_year',517)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات - فلتر محدد',ffVP3AK5RqhkgYnjZoNis+'/lineup',515)
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'مصنفات - فلتر كامل',ffVP3AK5RqhkgYnjZoNis+'/lineup',514)
	return
def UbdG8ArlT25WF(url):
	if '/seasonals' in url: iT2wOVymHEMAhWl6jbJs8pY = 0
	elif '/lineup' in url: iT2wOVymHEMAhWl6jbJs8pY = 1
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-LISTS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	cUE5uH8hAtOmTp = t6SKaQwq7Cszke9jGlUW42bo.find_all(class_='jumbo-theater clearfix')
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		title = BN1KdkzCmvshw.find_all('a')[iT2wOVymHEMAhWl6jbJs8pY].text
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+BN1KdkzCmvshw.find_all('a')[iT2wOVymHEMAhWl6jbJs8pY].get('href')
		if gA0m6CQUyfLG:
			title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		if not cUE5uH8hAtOmTp:
			nbktMzeI0jgfVXO2hyK4B(Y6YdkAMluFbwx)
			return
		else:
			title = title.replace('قائمة ',G9G0YqivIfmUWO8K)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,512)
	Uvld19IVa5fjZNKpBFMx7OckGQ(t6SKaQwq7Cszke9jGlUW42bo,511)
	return
def Uvld19IVa5fjZNKpBFMx7OckGQ(t6SKaQwq7Cszke9jGlUW42bo,mode):
	BN1KdkzCmvshw = t6SKaQwq7Cszke9jGlUW42bo.find(class_='pagination')
	if BN1KdkzCmvshw:
		FFOtK5PIBpezcsXqSmr0yj7Mn = BN1KdkzCmvshw.find_all('a')
		Remlxa8DHZIyBuOk7 = BN1KdkzCmvshw.find_all('li')
		E07ZhOGy8J = list(zip(FFOtK5PIBpezcsXqSmr0yj7Mn,Remlxa8DHZIyBuOk7))
		p0p6MxKbklodNCR92Wv = -1
		QkfP94eVT3g1tBlnsaSMyqCUKh6x = len(E07ZhOGy8J)
		for zz1cDUuAaFjxL7HZThqon9OPG4MNdv,LM4d2pH7swykDj5iA1fgBR0F3SKZXG in E07ZhOGy8J:
			p0p6MxKbklodNCR92Wv += 1
			LM4d2pH7swykDj5iA1fgBR0F3SKZXG = LM4d2pH7swykDj5iA1fgBR0F3SKZXG['class']
			if 'unavailable' in LM4d2pH7swykDj5iA1fgBR0F3SKZXG or 'current' in LM4d2pH7swykDj5iA1fgBR0F3SKZXG: continue
			mpniyIdLxTPW3BN8UcY2v = zz1cDUuAaFjxL7HZThqon9OPG4MNdv.text
			z7GYBmKiXwreV2QybCNn80v9pT = ffVP3AK5RqhkgYnjZoNis+zz1cDUuAaFjxL7HZThqon9OPG4MNdv.get('href')
			if gA0m6CQUyfLG:
				mpniyIdLxTPW3BN8UcY2v = mpniyIdLxTPW3BN8UcY2v.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				z7GYBmKiXwreV2QybCNn80v9pT = z7GYBmKiXwreV2QybCNn80v9pT.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			if   p0p6MxKbklodNCR92Wv==0: mpniyIdLxTPW3BN8UcY2v = 'أولى'
			elif p0p6MxKbklodNCR92Wv==1: mpniyIdLxTPW3BN8UcY2v = 'سابقة'
			elif p0p6MxKbklodNCR92Wv==QkfP94eVT3g1tBlnsaSMyqCUKh6x-2: mpniyIdLxTPW3BN8UcY2v = 'لاحقة'
			elif p0p6MxKbklodNCR92Wv==QkfP94eVT3g1tBlnsaSMyqCUKh6x-1: mpniyIdLxTPW3BN8UcY2v = 'أخيرة'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+mpniyIdLxTPW3BN8UcY2v,z7GYBmKiXwreV2QybCNn80v9pT,mode)
	return
def nbktMzeI0jgfVXO2hyK4B(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-TITLES1-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	cUE5uH8hAtOmTp = t6SKaQwq7Cszke9jGlUW42bo.find_all(class_='row')
	items,n6m2IWeNsk7i = [],True
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		if not BN1KdkzCmvshw.find(class_='thumbnail-wrapper'): continue
		if n6m2IWeNsk7i: n6m2IWeNsk7i = False ; continue
		S7rhHVt0ebMRFmzy1 = []
		OuRSCjhLIdaVkc6G8AHXDBMf1ezZ = BN1KdkzCmvshw.find_all(class_=['censorship red','censorship purple'])
		for y4Rfgs1lTrmGHwhZPdNY9Bo in OuRSCjhLIdaVkc6G8AHXDBMf1ezZ:
			tj9RfNKmAs8Ui3Q0wcuBbPY = y4Rfgs1lTrmGHwhZPdNY9Bo.find_all('li')[1].text
			if gA0m6CQUyfLG:
				tj9RfNKmAs8Ui3Q0wcuBbPY = tj9RfNKmAs8Ui3Q0wcuBbPY.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			S7rhHVt0ebMRFmzy1.append(tj9RfNKmAs8Ui3Q0wcuBbPY)
		if not j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,G9G0YqivIfmUWO8K,S7rhHVt0ebMRFmzy1,False):
			Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('data-src')
			title = BN1KdkzCmvshw.find('h3')
			name = title.find('a').text
			Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+title.find('a').get('href')
			FMOnxPAfTdUZV = BN1KdkzCmvshw.find(class_='no-margin')
			HwMAN6hWadE4stCg3L1jeBnpKQD = BN1KdkzCmvshw.find(class_='legend')
			if FMOnxPAfTdUZV: FMOnxPAfTdUZV = FMOnxPAfTdUZV.text
			if HwMAN6hWadE4stCg3L1jeBnpKQD: HwMAN6hWadE4stCg3L1jeBnpKQD = HwMAN6hWadE4stCg3L1jeBnpKQD.text
			if gA0m6CQUyfLG:
				Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				name = name.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
				if FMOnxPAfTdUZV: FMOnxPAfTdUZV = FMOnxPAfTdUZV.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			zF4nhxYlaiKPwA6NJZ3 = {}
			if HwMAN6hWadE4stCg3L1jeBnpKQD: zF4nhxYlaiKPwA6NJZ3['stars'] = HwMAN6hWadE4stCg3L1jeBnpKQD
			if FMOnxPAfTdUZV:
				FMOnxPAfTdUZV = FMOnxPAfTdUZV.replace(zEgtT9cR6bFp7JXqI5VuhNeP,' .. ')
				zF4nhxYlaiKPwA6NJZ3['plot'] = FMOnxPAfTdUZV.replace('...اقرأ المزيد',G9G0YqivIfmUWO8K)
			if '/work/' in Y6YdkAMluFbwx:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,516,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3)
			elif '/person/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,513,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3)
	Uvld19IVa5fjZNKpBFMx7OckGQ(t6SKaQwq7Cszke9jGlUW42bo,512)
	return
def MI6WBhZtnAbkRQz3T9L5X(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-TITLES2-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	cUE5uH8hAtOmTp = t6SKaQwq7Cszke9jGlUW42bo.find_all('li')
	k7zM3Heg90OtGrJWYm,items = [],[]
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		if not BN1KdkzCmvshw.find(class_='thumbnail-wrapper'): continue
		if not BN1KdkzCmvshw.find(class_=['unstyled','unstyled text-center']): continue
		if BN1KdkzCmvshw.find(class_='hide'): continue
		title = BN1KdkzCmvshw.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in k7zM3Heg90OtGrJWYm: continue
		k7zM3Heg90OtGrJWYm.append(name)
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+title.find('a').get('href')
		if '/search/work/' in url: Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('src')
		elif '/search/person/' in url: Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('data-src')
		elif '/search/video/' in url: Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('data-src')
		else: Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('src')
		if gA0m6CQUyfLG:
			name = name.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		name = name.strip(ww0sZkBU9JKd)
		items.append((name,Y6YdkAMluFbwx,Vy1U0koJLPFhxe2TS))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,Y6YdkAMluFbwx,Vy1U0koJLPFhxe2TS in items:
		if '/search/video/' in url: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,522,Vy1U0koJLPFhxe2TS)
		elif '/search/person/' in url: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,513,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,516,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name)
	return
def G4j96ZolXwEaeqsfAVhrk(text):
	text = text.replace('الإعلان',G9G0YqivIfmUWO8K).replace('لفيلم',G9G0YqivIfmUWO8K).replace('الرسمي',G9G0YqivIfmUWO8K)
	text = text.replace('إعلان',G9G0YqivIfmUWO8K).replace('فيلم',G9G0YqivIfmUWO8K).replace('البرومو',G9G0YqivIfmUWO8K)
	text = text.replace('التشويقي',G9G0YqivIfmUWO8K).replace('لمسلسل',G9G0YqivIfmUWO8K).replace('مسلسل',G9G0YqivIfmUWO8K)
	text = text.replace(':',G9G0YqivIfmUWO8K).replace(')',G9G0YqivIfmUWO8K).replace('(',G9G0YqivIfmUWO8K).replace(',',G9G0YqivIfmUWO8K)
	text = text.replace('_',G9G0YqivIfmUWO8K).replace(';',G9G0YqivIfmUWO8K).replace('-',G9G0YqivIfmUWO8K).replace('.',G9G0YqivIfmUWO8K)
	text = text.replace('\'',G9G0YqivIfmUWO8K).replace('\"',G9G0YqivIfmUWO8K)
	text = text.replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
	text = text.strip(ww0sZkBU9JKd)
	oZYIdHqXhfntJ = text.count(ww0sZkBU9JKd)+1
	if oZYIdHqXhfntJ==1:
		kspuVRGHBNZU(text)
		return
	Qm8SMu6ecXtigDCWw1oak('link',TdtCLWYSJNK8zOb+A7XhkmSYZlidyMt5FpWqTgjNezbnD+'==== كلمات للبحث ===='+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	zGiTvxWdlZtys4kn3XC = text.split(ww0sZkBU9JKd)
	LfnRPiSh4WwIsZ2umFN9to0 = pow(2,oZYIdHqXhfntJ)
	IyvhVeGS7xP2F = []
	def Qin5bGoxRcJaPZpLXzANt4uVSYMym(qIjOPGKdtixmreBTkuz9gAXW14y,Ibr61AOhmk02WFsGLjvfU):
		if qIjOPGKdtixmreBTkuz9gAXW14y=='1': return Ibr61AOhmk02WFsGLjvfU
		return G9G0YqivIfmUWO8K
	for p0p6MxKbklodNCR92Wv in range(LfnRPiSh4WwIsZ2umFN9to0,0,-1):
		exkZrqS2BKcpi9L3OCFIDAlyT = list(oZYIdHqXhfntJ*'0'+bin(p0p6MxKbklodNCR92Wv)[2:])[-oZYIdHqXhfntJ:]
		exkZrqS2BKcpi9L3OCFIDAlyT = reversed(exkZrqS2BKcpi9L3OCFIDAlyT)
		hh2WobBZGFs5Lp0EjISNHfwdMkKv = map(Qin5bGoxRcJaPZpLXzANt4uVSYMym,exkZrqS2BKcpi9L3OCFIDAlyT,zGiTvxWdlZtys4kn3XC)
		title = ww0sZkBU9JKd.join(filter(None,hh2WobBZGFs5Lp0EjISNHfwdMkKv))
		if gA0m6CQUyfLG: GS7Y93B0b8TLxueF = title.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		else: GS7Y93B0b8TLxueF = title
		if len(GS7Y93B0b8TLxueF)>2 and title not in IyvhVeGS7xP2F:
			IyvhVeGS7xP2F.append(title)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,G9G0YqivIfmUWO8K,523,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,title)
	return
def kspuVRGHBNZU(srmO43LfnxajeDQPTzXI6gVvB):
	if gA0m6CQUyfLG:
		srmO43LfnxajeDQPTzXI6gVvB = srmO43LfnxajeDQPTzXI6gVvB.decode(f3uIcZ2C6pzbX1JlFBrVOdt)
		import arabic_reshaper as rRbg54ULGe3vpY0QtzZJk98i,bidi.algorithm as Hu1ZSQWYqVx6FINLdhfm9EMeJg
		srmO43LfnxajeDQPTzXI6gVvB = rRbg54ULGe3vpY0QtzZJk98i.ArabicReshaper().reshape(srmO43LfnxajeDQPTzXI6gVvB)
		srmO43LfnxajeDQPTzXI6gVvB = Hu1ZSQWYqVx6FINLdhfm9EMeJg.get_display(srmO43LfnxajeDQPTzXI6gVvB)
	import yJoXUw5pTK
	srmO43LfnxajeDQPTzXI6gVvB = ZT7zGWSCtpvfmwMNRjYrKL(ZZv9UABzh7FpuYmscyo8LEKj5XQgt=srmO43LfnxajeDQPTzXI6gVvB)
	yJoXUw5pTK.b6WZDnA0dLBiCITrF37OS(srmO43LfnxajeDQPTzXI6gVvB)
	return
def VBbhHNZcCDJl(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-INDEXES_LISTS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	BN1KdkzCmvshw = t6SKaQwq7Cszke9jGlUW42bo.find(class_='list-separator list-title')
	JoSpAl1HIVd0f = BN1KdkzCmvshw.find_all('a')
	items = []
	for title in JoSpAl1HIVd0f:
		name = title.text
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+title.get('href')
		if gA0m6CQUyfLG:
			name = name.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		if '#' not in Y6YdkAMluFbwx: items.append((name,Y6YdkAMluFbwx))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for XX2Btn97vEfkCjcuWs in items:
		name,Y6YdkAMluFbwx = XX2Btn97vEfkCjcuWs
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,518)
	return
def rLXQqK4GbehYd7sJ6MyOCUczpkm(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-INDEXES_TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	cUE5uH8hAtOmTp = t6SKaQwq7Cszke9jGlUW42bo.find(class_='expand').find_all('tr')
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		iY8nAml2ydRkB0PMb = BN1KdkzCmvshw.find_all('a')
		if not iY8nAml2ydRkB0PMb: continue
		Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('data-src')
		name = iY8nAml2ydRkB0PMb[1].text
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+iY8nAml2ydRkB0PMb[1].get('href')
		HwMAN6hWadE4stCg3L1jeBnpKQD = BN1KdkzCmvshw.find(class_='legend')
		if HwMAN6hWadE4stCg3L1jeBnpKQD: HwMAN6hWadE4stCg3L1jeBnpKQD = HwMAN6hWadE4stCg3L1jeBnpKQD.text
		if gA0m6CQUyfLG:
			name = name.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		zF4nhxYlaiKPwA6NJZ3 = {}
		if HwMAN6hWadE4stCg3L1jeBnpKQD: zF4nhxYlaiKPwA6NJZ3['stars'] = HwMAN6hWadE4stCg3L1jeBnpKQD
		if '/work/' in Y6YdkAMluFbwx:
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,516,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3)
		elif '/person/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+name,Y6YdkAMluFbwx,513,Vy1U0koJLPFhxe2TS,G9G0YqivIfmUWO8K,name,G9G0YqivIfmUWO8K,zF4nhxYlaiKPwA6NJZ3)
	Uvld19IVa5fjZNKpBFMx7OckGQ(t6SKaQwq7Cszke9jGlUW42bo,518)
	return
def l8Yt1BnvUQHShKpmXFZjE0M(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-VIDEOS_LISTS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	JoSpAl1HIVd0f = t6SKaQwq7Cszke9jGlUW42bo.find_all(class_='section-title inline')
	dsGzqX4k0a8RLyc = t6SKaQwq7Cszke9jGlUW42bo.find_all(class_='button green small right')
	items = zip(JoSpAl1HIVd0f,dsGzqX4k0a8RLyc)
	for title,Y6YdkAMluFbwx in items:
		title = title.text
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx.get('href')
		if gA0m6CQUyfLG:
			title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		title = title.replace(MjuRWebwX0pfD,ww0sZkBU9JKd).replace(wKBSo48e5PYtn63DpiG,ww0sZkBU9JKd).replace(zVnkcBX6aJDPRpqyCjhoSZYQbL,ww0sZkBU9JKd)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,521)
	return
def r1rHNUGqdBgL8C5RzSaZ9u72O(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-VIDEOS_TITLES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	pfhqQwm2o5d3VJux = t6SKaQwq7Cszke9jGlUW42bo.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	cUE5uH8hAtOmTp = pfhqQwm2o5d3VJux.find_all('li')
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		title = BN1KdkzCmvshw.find(class_='title').text
		Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+BN1KdkzCmvshw.find('a').get('href')
		Vy1U0koJLPFhxe2TS = BN1KdkzCmvshw.find('img').get('data-src')
		ii9h6QFxBUuCeqJODlfYmsI7ZT = BN1KdkzCmvshw.find(class_='duration').text
		if gA0m6CQUyfLG:
			title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			Vy1U0koJLPFhxe2TS = Vy1U0koJLPFhxe2TS.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
			ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		ii9h6QFxBUuCeqJODlfYmsI7ZT = ii9h6QFxBUuCeqJODlfYmsI7ZT.replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K).strip(ww0sZkBU9JKd)
		Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,522,Vy1U0koJLPFhxe2TS,ii9h6QFxBUuCeqJODlfYmsI7ZT)
	Uvld19IVa5fjZNKpBFMx7OckGQ(t6SKaQwq7Cszke9jGlUW42bo,521)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	Y6YdkAMluFbwx = t6SKaQwq7Cszke9jGlUW42bo.find(class_='flex-video').find('iframe').get('src')
	if gA0m6CQUyfLG: Y6YdkAMluFbwx = Y6YdkAMluFbwx.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk([Y6YdkAMluFbwx],s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'%20')
	url = ffVP3AK5RqhkgYnjZoNis+'/search/?q='+search
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-SEARCH-1st')
	if not D7omduSeM5Gk.succeeded:
		SSHDzNikR29jQxn6ITCfdboM = ffVP3AK5RqhkgYnjZoNis+'/search_entity/?q='+search+'&entity=work'
		z7GYBmKiXwreV2QybCNn80v9pT = ffVP3AK5RqhkgYnjZoNis+'/search_entity/?q='+search+'&entity=person'
		iSgUrJ1alz6hMnuPx8ekbQI7BLD = ffVP3AK5RqhkgYnjZoNis+'/search_entity/?q='+search+'&entity=video'
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن أعمال',SSHDzNikR29jQxn6ITCfdboM,513,G9G0YqivIfmUWO8K,search)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن أشخاص',z7GYBmKiXwreV2QybCNn80v9pT,513,G9G0YqivIfmUWO8K,search)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث عن فيديوهات',iSgUrJ1alz6hMnuPx8ekbQI7BLD,513,G9G0YqivIfmUWO8K,search)
		return
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	t6SKaQwq7Cszke9jGlUW42bo = GROJ24tpaQ7iNZr0uqy3X8WmE.BeautifulSoup(GagwMT6q3oc7UZ2Q,'html.parser',multi_valued_attributes=None)
	cUE5uH8hAtOmTp = t6SKaQwq7Cszke9jGlUW42bo.find_all(class_='section-title left')
	for BN1KdkzCmvshw in cUE5uH8hAtOmTp:
		title = BN1KdkzCmvshw.text
		if gA0m6CQUyfLG:
			title = title.encode(f3uIcZ2C6pzbX1JlFBrVOdt)
		title = title.split('(',1)[0].strip(ww0sZkBU9JKd)
		if   'أعمال' in title: Y6YdkAMluFbwx = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: Y6YdkAMluFbwx = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: Y6YdkAMluFbwx = url.replace('/search/','/search/video/')
		else: continue
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,513)
	return
def h7mi1co6XrVlvnd5fLF2QIjAU(url,text):
	global IzbOhN0Flo8j4gtdcVewMB,KH5NQOvAkRje
	if '/seasonals' in url:
		IzbOhN0Flo8j4gtdcVewMB = ['seasonal','year','category']
		KH5NQOvAkRje = ['seasonal','year','category']
	elif '/lineup' in url:
		IzbOhN0Flo8j4gtdcVewMB = ['category','foreign','type']
		KH5NQOvAkRje = ['category','foreign','type']
	nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,text)
	return
def RFEgei8ox2aIBLJDTzfswql(url):
	url = url.split('/smartemadfilter?')[0]
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',url,G9G0YqivIfmUWO8K,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('form action="/(.*?)</form>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	FgGiXAn5NeaTHS0mZ = oo9kuULlebNgpY0Om.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	return FgGiXAn5NeaTHS0mZ
def X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw):
	items = oo9kuULlebNgpY0Om.findall('<option value="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	return items
def JJyGN2OoV4BxbrPfCweuQ(url):
	LV6wHuJn8BiWZeyRkcI3sdXU = url.split('/smartemadfilter?')[0]
	NPlUQFruOmeD = xWiOjcUrJVdtP4B5Iml(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def NNlFmAH3hkrOyLueasfpqCZ1EITzW(lnC86vW0YyXq5GEtHcBJKdu,url):
	DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(lnC86vW0YyXq5GEtHcBJKdu,'all_filters')
	XjWHSnbf6NwhMgpKt4yLY7AkIT = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	XjWHSnbf6NwhMgpKt4yLY7AkIT = JJyGN2OoV4BxbrPfCweuQ(XjWHSnbf6NwhMgpKt4yLY7AkIT)
	return XjWHSnbf6NwhMgpKt4yLY7AkIT
def nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==G9G0YqivIfmUWO8K: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	else: UHjy18F6pJO0DYdcsr5L,if4qIWbJKOjDQHzPcrFMn6dmNxgCG = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if IzbOhN0Flo8j4gtdcVewMB[0]+'=' not in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[0]
		for KT9tdUH3hmiLZCEFz in range(len(IzbOhN0Flo8j4gtdcVewMB[0:-1])):
			if IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz]+'=' in UHjy18F6pJO0DYdcsr5L: nxguK9laUWBGHIR4zEsTo7 = IzbOhN0Flo8j4gtdcVewMB[KT9tdUH3hmiLZCEFz+1]
		A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+nxguK9laUWBGHIR4zEsTo7+'=0'
		FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE.strip('&')+'___'+lnC86vW0YyXq5GEtHcBJKdu.strip('&')
		DoH0seUKBWROlpN9Td36GhmgAv4V5Z = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+DoH0seUKBWROlpN9Td36GhmgAv4V5Z
	elif type=='ALL_ITEMS_FILTER':
		JVhKosuyNpMlzXkEHqnx4ref = S6JVi8xLvWb2KmARu7nZo(UHjy18F6pJO0DYdcsr5L,'modified_values')
		JVhKosuyNpMlzXkEHqnx4ref = aKAyEnjxIlzZtCTv(JVhKosuyNpMlzXkEHqnx4ref)
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG!=G9G0YqivIfmUWO8K: if4qIWbJKOjDQHzPcrFMn6dmNxgCG = S6JVi8xLvWb2KmARu7nZo(if4qIWbJKOjDQHzPcrFMn6dmNxgCG,'modified_filters')
		if if4qIWbJKOjDQHzPcrFMn6dmNxgCG==G9G0YqivIfmUWO8K: XXzvmn7ewM8yBfoxua = url
		else: XXzvmn7ewM8yBfoxua = url+'/smartemadfilter?'+if4qIWbJKOjDQHzPcrFMn6dmNxgCG
		XXzvmn7ewM8yBfoxua = JJyGN2OoV4BxbrPfCweuQ(XXzvmn7ewM8yBfoxua)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'أظهار قائمة الفيديو التي تم اختيارها ',XXzvmn7ewM8yBfoxua,511)
		Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+' [[   '+JVhKosuyNpMlzXkEHqnx4ref+'   ]]',XXzvmn7ewM8yBfoxua,511)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	FgGiXAn5NeaTHS0mZ = RFEgei8ox2aIBLJDTzfswql(url)
	dict = {}
	for name,TaVcxgUOBpSwX6Rl9PYkzeudt1,BN1KdkzCmvshw in FgGiXAn5NeaTHS0mZ:
		name = name.replace('--',G9G0YqivIfmUWO8K)
		items = X2MkxSItbuBCq84l1QpG0co6Van(BN1KdkzCmvshw)
		if '=' not in XXzvmn7ewM8yBfoxua: XXzvmn7ewM8yBfoxua = url
		if type=='SPECIFIED_FILTER':
			if TaVcxgUOBpSwX6Rl9PYkzeudt1 not in IzbOhN0Flo8j4gtdcVewMB: continue
			if nxguK9laUWBGHIR4zEsTo7!=TaVcxgUOBpSwX6Rl9PYkzeudt1: continue
			elif len(items)<2:
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]:
					url = JJyGN2OoV4BxbrPfCweuQ(url)
					nbktMzeI0jgfVXO2hyK4B(url)
				else: nLGRmpXCDO6lAgi4MrtPI7BzvxeUST(XXzvmn7ewM8yBfoxua,'SPECIFIED_FILTER___'+FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
				return
			else:
				XXzvmn7ewM8yBfoxua = JJyGN2OoV4BxbrPfCweuQ(XXzvmn7ewM8yBfoxua)
				if TaVcxgUOBpSwX6Rl9PYkzeudt1==IzbOhN0Flo8j4gtdcVewMB[-1]: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,511)
				else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع',XXzvmn7ewM8yBfoxua,515,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		elif type=='ALL_ITEMS_FILTER':
			if TaVcxgUOBpSwX6Rl9PYkzeudt1 not in KH5NQOvAkRje: continue
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'=0'
			FQtZDdeWr7KLvOisTunX4S5Vxb6GfR = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'الجميع: '+name,XXzvmn7ewM8yBfoxua,514,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,FQtZDdeWr7KLvOisTunX4S5Vxb6GfR)
		dict[TaVcxgUOBpSwX6Rl9PYkzeudt1] = {}
		for yW70dtahIjkPCJg2TA,M0nQuWoaIxhSdqyV9N in items:
			if M0nQuWoaIxhSdqyV9N in tlcXBJEfIHF02vQ6yxSom9z1: continue
			if 'مصنفات أخرى' in M0nQuWoaIxhSdqyV9N: continue
			if 'الكل' in M0nQuWoaIxhSdqyV9N: continue
			if 'اللغة' in M0nQuWoaIxhSdqyV9N: continue
			M0nQuWoaIxhSdqyV9N = M0nQuWoaIxhSdqyV9N.replace('قائمة ',G9G0YqivIfmUWO8K)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[TaVcxgUOBpSwX6Rl9PYkzeudt1][yW70dtahIjkPCJg2TA] = M0nQuWoaIxhSdqyV9N
			A8NydP0UvsWDOToQIcmagprE = UHjy18F6pJO0DYdcsr5L+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+M0nQuWoaIxhSdqyV9N
			lnC86vW0YyXq5GEtHcBJKdu = if4qIWbJKOjDQHzPcrFMn6dmNxgCG+'&'+TaVcxgUOBpSwX6Rl9PYkzeudt1+'='+yW70dtahIjkPCJg2TA
			eLUgvCWyPV80zboYB71TKl = A8NydP0UvsWDOToQIcmagprE+'___'+lnC86vW0YyXq5GEtHcBJKdu
			if name: title = M0nQuWoaIxhSdqyV9N+' :'+name
			else: title = M0nQuWoaIxhSdqyV9N
			if type=='ALL_ITEMS_FILTER': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,514,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
			elif type=='SPECIFIED_FILTER' and IzbOhN0Flo8j4gtdcVewMB[-2]+'=' in UHjy18F6pJO0DYdcsr5L:
				XjWHSnbf6NwhMgpKt4yLY7AkIT = NNlFmAH3hkrOyLueasfpqCZ1EITzW(lnC86vW0YyXq5GEtHcBJKdu,url)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,XjWHSnbf6NwhMgpKt4yLY7AkIT,511)
			else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,url,515,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,eLUgvCWyPV80zboYB71TKl)
	return
def S6JVi8xLvWb2KmARu7nZo(IjPUNHfzpc0mvu2CsAhLOqQ,mode):
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.replace('=&','=0&')
	IjPUNHfzpc0mvu2CsAhLOqQ = IjPUNHfzpc0mvu2CsAhLOqQ.strip('&')
	R9h6MqBxlsEpNztI0AU = {}
	if '=' in IjPUNHfzpc0mvu2CsAhLOqQ:
		items = IjPUNHfzpc0mvu2CsAhLOqQ.split('&')
		for XX2Btn97vEfkCjcuWs in items:
			wwLKR5YpyqGu,yW70dtahIjkPCJg2TA = XX2Btn97vEfkCjcuWs.split('=')
			R9h6MqBxlsEpNztI0AU[wwLKR5YpyqGu] = yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = G9G0YqivIfmUWO8K
	for key in KH5NQOvAkRje:
		if key in list(R9h6MqBxlsEpNztI0AU.keys()): yW70dtahIjkPCJg2TA = R9h6MqBxlsEpNztI0AU[key]
		else: yW70dtahIjkPCJg2TA = '0'
		if '%' not in yW70dtahIjkPCJg2TA: yW70dtahIjkPCJg2TA = SSX6oT0lADZhKRImPvCHFkYJs(yW70dtahIjkPCJg2TA)
		if mode=='modified_values' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+' + '+yW70dtahIjkPCJg2TA
		elif mode=='modified_filters' and yW70dtahIjkPCJg2TA!='0': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
		elif mode=='all_filters': lOaCfpSNzejn = lOaCfpSNzejn+'&'+key+'='+yW70dtahIjkPCJg2TA
	lOaCfpSNzejn = lOaCfpSNzejn.strip(' + ')
	lOaCfpSNzejn = lOaCfpSNzejn.strip('&')
	lOaCfpSNzejn = lOaCfpSNzejn.replace('=0','=')
	return lOaCfpSNzejn
IzbOhN0Flo8j4gtdcVewMB = []
KH5NQOvAkRje = []
# -*- coding: utf-8 -*-
import sys as yyrcMwk6RWmH3xOKQUpGdghiX
MxyZ2UatQlpY6c3 = yyrcMwk6RWmH3xOKQUpGdghiX.version_info [0] == 2
Gav5dbwYBr2yCOL3IlEpqx1JAk = 2048
p2kiFJ1zYTbh6u7dHxoRwKGtmjlA = 7
def NiEwnzFKlcUmgOuL (xH06GtkV9o):
	global QabF03REqvTzBPwe8GdXipfAno
	VWYGMA2QFPO = ord (xH06GtkV9o [-1])
	gRGChBm7MoJVf = xH06GtkV9o [:-1]
	NeBUsdRXPtyFAuGhl5ZW = VWYGMA2QFPO % len (gRGChBm7MoJVf)
	ULIeNnjyJF0 = gRGChBm7MoJVf [:NeBUsdRXPtyFAuGhl5ZW] + gRGChBm7MoJVf [NeBUsdRXPtyFAuGhl5ZW:]
	if MxyZ2UatQlpY6c3:
		bhFT8VJXNm = unicode () .join ([unichr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	else:
		bhFT8VJXNm = str () .join ([chr (ord (L45LWY9kir6tpvUMHP) - Gav5dbwYBr2yCOL3IlEpqx1JAk - (tgdKabfvFS8043X9H1LZ5Bl + VWYGMA2QFPO) % p2kiFJ1zYTbh6u7dHxoRwKGtmjlA) for tgdKabfvFS8043X9H1LZ5Bl, L45LWY9kir6tpvUMHP in enumerate (ULIeNnjyJF0)])
	return eval (bhFT8VJXNm)
ssGdubC4mngM9D5SRc3Ye,iqHhJSxdaANDG5rlZm7B,iAGgjwb7tVMmacRJ=NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL,NiEwnzFKlcUmgOuL
dhANiYPG7xXrSyJfIjZ8nBboLv,UighHKAfySm4PWErqJ,hhdGMSsBzel96obfEmrwiuLPOvq=iAGgjwb7tVMmacRJ,iqHhJSxdaANDG5rlZm7B,ssGdubC4mngM9D5SRc3Ye
cjbAkCIinvs,rxWDdRBIct57i90s,yiaeCEwJjOcWA4ZSd5h=hhdGMSsBzel96obfEmrwiuLPOvq,UighHKAfySm4PWErqJ,dhANiYPG7xXrSyJfIjZ8nBboLv
vCmnFshSi4flecXIY2gy38G0DJw,bneABYmwFUH8GXphg0Kl2Sq,hh4FrbOWHjmD5KcS13MN9CexsT7p=yiaeCEwJjOcWA4ZSd5h,rxWDdRBIct57i90s,cjbAkCIinvs
cJSNFCIhymEfx6grGu0M,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,EHUAyW2lQfe4LXmhgIGc=hh4FrbOWHjmD5KcS13MN9CexsT7p,bneABYmwFUH8GXphg0Kl2Sq,vCmnFshSi4flecXIY2gy38G0DJw
CJ0Z89jUnbRxAtguzMdlX6YqVKsS,qTVF3icWwGXy5,t2sCrJ0xbgDRkf=EHUAyW2lQfe4LXmhgIGc,EEhslBbQRMKpSviLGuew1Jr5ncdmj8,cJSNFCIhymEfx6grGu0M
dC3PsQJ0Ti28uYlov,DTF3Lwy9etRH8mI,wIu47Z8T0cVjg5iNX6omfkPbsDO=t2sCrJ0xbgDRkf,qTVF3icWwGXy5,CJ0Z89jUnbRxAtguzMdlX6YqVKsS
RMxjDCgEBtiFmWvrdVeU0cwTqz,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RVpeGcmPxj9tCnT40Nf216=wIu47Z8T0cVjg5iNX6omfkPbsDO,DTF3Lwy9etRH8mI,dC3PsQJ0Ti28uYlov
ETNq5t4MYngSsbfFD8J0v,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,Dj4ySMftbrzYh8aFRBeZUiLAd7k=RVpeGcmPxj9tCnT40Nf216,RkxO6mlVHEiTcajWDJrFGsvg2Qz,RMxjDCgEBtiFmWvrdVeU0cwTqz
FWqeEzO1i8Dn0ga,GvaYKBCsURLOh9H6o02QcT4qM3liP,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg=Dj4ySMftbrzYh8aFRBeZUiLAd7k,wRK6Ms5kgQXGJA1ZVOBxjTLovPa8,ETNq5t4MYngSsbfFD8J0v
rr7Xolsp4JwjPK3L,VHrIziKUDuNGXkMla,jR9YtmsgDX8nTQlMb6G3=ZajcoF2kN6vd7KCqGTbHSQwxA8Jg,GvaYKBCsURLOh9H6o02QcT4qM3liP,FWqeEzO1i8Dn0ga
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = rr7Xolsp4JwjPK3L(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
TdtCLWYSJNK8zOb = iAGgjwb7tVMmacRJ(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
gLcsYrORXAaopQ73K6jk = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(wikRq4pjIX6Nx7d3lm,EHUAyW2lQfe4LXmhgIGc(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
zlpyf7mbj8MNAxUcPd = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(wikRq4pjIX6Nx7d3lm,hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
SBRA6rKkCzMwHm7Jb5i4FtpEsf = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(irwSnY4qBFv5txbM9u0kNOlfmHDR8h,iAGgjwb7tVMmacRJ(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),rxWDdRBIct57i90s(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
AocKaTSP94dVQ1rfWxUY6Nn23 = PUVchiMBQ0L2zr1bZ8oYASR
j7yV9qvStXOFAbKkRWLde1rEuaPi = qTVF3icWwGXy5(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
kj1rVidLIlwZSoJzGxPEA75muhnv0 = CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
ea2RYdv8WNE5bT4l = rr7Xolsp4JwjPK3L(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
Y13VmZM9Gs5y = Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
gzb8kGN3nqTsM5pj6 = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
kk7iKnfav1IRx0oC4BbhwdzPl = iqHhJSxdaANDG5rlZm7B(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def RAndFk3y4Pbvs29(Mauf6CrJjP87s):
	if   Mauf6CrJjP87s==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠼࠺࠰ࡸ"): tRojAyBgfDH37eLCwP4dWl = Dldwj2vxqLo6NeOAf97HSCK()
	elif Mauf6CrJjP87s==ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠽࠴࠲ࡹ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(gLcsYrORXAaopQ73K6jk,P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"࠷࠵࠴ࡺ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(zlpyf7mbj8MNAxUcPd,P5VqbRSzjtO4UE1rZaolG67XA,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==DTF3Lwy9etRH8mI(u"࠸࠶࠶ࡻ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(SBRA6rKkCzMwHm7Jb5i4FtpEsf,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"࠹࠷࠸ࡼ"): tRojAyBgfDH37eLCwP4dWl = NXJf0R6kAoYm2qUdhFZucI(AocKaTSP94dVQ1rfWxUY6Nn23,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==hhdGMSsBzel96obfEmrwiuLPOvq(u"࠺࠸࠺ࡽ"): tRojAyBgfDH37eLCwP4dWl = hRsQZmcIqoN6faH47B9(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==UighHKAfySm4PWErqJ(u"࠻࠺࠶ࡾ"): tRojAyBgfDH37eLCwP4dWl = RZqcHodgiuws()
	elif Mauf6CrJjP87s==EHUAyW2lQfe4LXmhgIGc(u"࠼࠻࠱ࡿ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(j7yV9qvStXOFAbKkRWLde1rEuaPi,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==DTF3Lwy9etRH8mI(u"࠽࠵࠳ࢀ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(kj1rVidLIlwZSoJzGxPEA75muhnv0,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==ssGdubC4mngM9D5SRc3Ye(u"࠷࠶࠵ࢁ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(ea2RYdv8WNE5bT4l,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==yiaeCEwJjOcWA4ZSd5h(u"࠸࠷࠷ࢂ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(Y13VmZM9Gs5y,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==dC3PsQJ0Ti28uYlov(u"࠹࠸࠹ࢃ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(gzb8kGN3nqTsM5pj6,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==ssGdubC4mngM9D5SRc3Ye(u"࠺࠹࠻ࢄ"): tRojAyBgfDH37eLCwP4dWl = Sm8oLxifPQNzI(kk7iKnfav1IRx0oC4BbhwdzPl,kkMuQrLWcEayRm,P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠻࠺࠽ࢅ"): tRojAyBgfDH37eLCwP4dWl = nSkVvL6CuIMGps0Q5axe3hE7K(P5VqbRSzjtO4UE1rZaolG67XA)
	elif Mauf6CrJjP87s==dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠼࠻࠸ࢆ"): tRojAyBgfDH37eLCwP4dWl = DptBcgAIyJQS045EXl8vhRTZOq3wH()
	else: tRojAyBgfDH37eLCwP4dWl = kkMuQrLWcEayRm
	return tRojAyBgfDH37eLCwP4dWl
def Dldwj2vxqLo6NeOAf97HSCK():
	vstnSTrYdRo3g9xy7kEC8KwZM,D9LnNgXyBj4IbTQeufG1qv = T2TMhELomcX8NfjFW3HiU15DJdCQ7(gLcsYrORXAaopQ73K6jk)
	bKu8CcjpyRf,Ub1VAQzGgR = T2TMhELomcX8NfjFW3HiU15DJdCQ7(zlpyf7mbj8MNAxUcPd)
	jLit3msHkpBGqbTKS2,GNsQkmgib2j6ycAR = T2TMhELomcX8NfjFW3HiU15DJdCQ7(SBRA6rKkCzMwHm7Jb5i4FtpEsf)
	HHrizKtMUL50nWRFkc8TZAqQ,dUma5MI3vyZQjxXKJrTk = OSNKd3Zsh4GgE(AocKaTSP94dVQ1rfWxUY6Nn23)
	HHrizKtMUL50nWRFkc8TZAqQ -= UighHKAfySm4PWErqJ(u"࠹࠶࠹࠸࠷ࢇ")
	dUma5MI3vyZQjxXKJrTk -= FWqeEzO1i8Dn0ga(u"࠱࢈")
	o7of6KbkMgVpnG53QZ0 = GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠩࠣࠬࠬࠌ")+hfx3IbcMO8Z6gGeonPQz(vstnSTrYdRo3g9xy7kEC8KwZM)+yiaeCEwJjOcWA4ZSd5h(u"ࠪࠤ࠲ࠦࠧࠍ")+str(D9LnNgXyBj4IbTQeufG1qv)+VHrIziKUDuNGXkMla(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	DTUp9SXGQBRuy6a2OWVEKL7Pk = vCmnFshSi4flecXIY2gy38G0DJw(u"ࠬࠦࠨࠨࠏ")+hfx3IbcMO8Z6gGeonPQz(bKu8CcjpyRf)+jR9YtmsgDX8nTQlMb6G3(u"࠭ࠠ࠮ࠢࠪࠐ")+str(Ub1VAQzGgR)+dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	gkRpy0nfKFa1tQb48l3ZrC9qO = EHUAyW2lQfe4LXmhgIGc(u"ࠨࠢࠫࠫࠒ")+hfx3IbcMO8Z6gGeonPQz(jLit3msHkpBGqbTKS2)+VHrIziKUDuNGXkMla(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(GNsQkmgib2j6ycAR)+rxWDdRBIct57i90s(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	QYsK8uo0Sh9C = EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠫࠥ࠮ࠧࠕ")+hfx3IbcMO8Z6gGeonPQz(HHrizKtMUL50nWRFkc8TZAqQ)+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠬ࠯ࠧࠖ")
	e9I2TbwEJYNMg5Bav8tFVGx = vstnSTrYdRo3g9xy7kEC8KwZM+bKu8CcjpyRf+jLit3msHkpBGqbTKS2+HHrizKtMUL50nWRFkc8TZAqQ
	UZq3rSzmpw61ALGCIeuxBRyhb75V4 = D9LnNgXyBj4IbTQeufG1qv+Ub1VAQzGgR+GNsQkmgib2j6ycAR+dUma5MI3vyZQjxXKJrTk
	Vvju9Ht8SGxoiTa6lCs = EHUAyW2lQfe4LXmhgIGc(u"࠭ࠠࠩࠩࠗ")+hfx3IbcMO8Z6gGeonPQz(e9I2TbwEJYNMg5Bav8tFVGx)+t2sCrJ0xbgDRkf(u"ࠧࠡ࠯ࠣࠫ࠘")+str(UZq3rSzmpw61ALGCIeuxBRyhb75V4)+CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	Qm8SMu6ecXtigDCWw1oak(EHUAyW2lQfe4LXmhgIGc(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),TdtCLWYSJNK8zOb+dC3PsQJ0Ti28uYlov(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠸࠶࠸ࢉ"))
	Qm8SMu6ecXtigDCWw1oak(VHrIziKUDuNGXkMla(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,iAGgjwb7tVMmacRJ(u"࠻࠼࠽࠾ࢊ"))
	Qm8SMu6ecXtigDCWw1oak(VHrIziKUDuNGXkMla(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),TdtCLWYSJNK8zOb+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+o7of6KbkMgVpnG53QZ0,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"࠺࠸࠶ࢋ"))
	Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),TdtCLWYSJNK8zOb+RVpeGcmPxj9tCnT40Nf216(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+DTUp9SXGQBRuy6a2OWVEKL7Pk,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"࠻࠹࠸ࢌ"))
	Qm8SMu6ecXtigDCWw1oak(t2sCrJ0xbgDRkf(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),TdtCLWYSJNK8zOb+ssGdubC4mngM9D5SRc3Ye(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+gkRpy0nfKFa1tQb48l3ZrC9qO,G9G0YqivIfmUWO8K,RVpeGcmPxj9tCnT40Nf216(u"࠼࠺࠳ࢍ"))
	Qm8SMu6ecXtigDCWw1oak(wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),TdtCLWYSJNK8zOb+qTVF3icWwGXy5(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+QYsK8uo0Sh9C,G9G0YqivIfmUWO8K,jR9YtmsgDX8nTQlMb6G3(u"࠽࠴࠵ࢎ"))
	amx9qJHkhw7oLdtVMG3.setSetting(ETNq5t4MYngSsbfFD8J0v(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),G9G0YqivIfmUWO8K)
	return
def RZqcHodgiuws():
	MhK2TBwzXikmDfUjy = P5VqbRSzjtO4UE1rZaolG67XA if qTVF3icWwGXy5(u"ࠨ࠱ࠪࠧ") in irwSnY4qBFv5txbM9u0kNOlfmHDR8h else kkMuQrLWcEayRm
	if not MhK2TBwzXikmDfUjy:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),cjbAkCIinvs(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	w0oqhWrypS1QlT5zX6UAnFIGfKOkc = amx9qJHkhw7oLdtVMG3.getSetting(yiaeCEwJjOcWA4ZSd5h(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not w0oqhWrypS1QlT5zX6UAnFIGfKOkc: DptBcgAIyJQS045EXl8vhRTZOq3wH()
	vstnSTrYdRo3g9xy7kEC8KwZM,D9LnNgXyBj4IbTQeufG1qv = T2TMhELomcX8NfjFW3HiU15DJdCQ7(j7yV9qvStXOFAbKkRWLde1rEuaPi)
	bKu8CcjpyRf,Ub1VAQzGgR = T2TMhELomcX8NfjFW3HiU15DJdCQ7(kj1rVidLIlwZSoJzGxPEA75muhnv0)
	jLit3msHkpBGqbTKS2,GNsQkmgib2j6ycAR = T2TMhELomcX8NfjFW3HiU15DJdCQ7(ea2RYdv8WNE5bT4l)
	HHrizKtMUL50nWRFkc8TZAqQ,dUma5MI3vyZQjxXKJrTk = T2TMhELomcX8NfjFW3HiU15DJdCQ7(Y13VmZM9Gs5y)
	LLw2hIZdG8sfUXub,NVEpgfF2tKP8x3WyHQe4zTqRB = T2TMhELomcX8NfjFW3HiU15DJdCQ7(gzb8kGN3nqTsM5pj6)
	KKJFHhPT4e2QLVdWX,NuYLiExznTPUO9rHRKGh10Jmf = T2TMhELomcX8NfjFW3HiU15DJdCQ7(kk7iKnfav1IRx0oC4BbhwdzPl)
	o7of6KbkMgVpnG53QZ0 = rxWDdRBIct57i90s(u"ࠬࠦࠨࠨࠫ")+hfx3IbcMO8Z6gGeonPQz(vstnSTrYdRo3g9xy7kEC8KwZM)+iAGgjwb7tVMmacRJ(u"࠭ࠠ࠮ࠢࠪࠬ")+str(D9LnNgXyBj4IbTQeufG1qv)+vCmnFshSi4flecXIY2gy38G0DJw(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	DTUp9SXGQBRuy6a2OWVEKL7Pk = hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠨࠢࠫࠫ࠮")+hfx3IbcMO8Z6gGeonPQz(bKu8CcjpyRf)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠩࠣ࠱ࠥ࠭࠯")+str(Ub1VAQzGgR)+t2sCrJ0xbgDRkf(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	gkRpy0nfKFa1tQb48l3ZrC9qO = rr7Xolsp4JwjPK3L(u"ࠫࠥ࠮ࠧ࠱")+hfx3IbcMO8Z6gGeonPQz(jLit3msHkpBGqbTKS2)+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"ࠬࠦ࠭ࠡࠩ࠲")+str(GNsQkmgib2j6ycAR)+UighHKAfySm4PWErqJ(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	QYsK8uo0Sh9C = rr7Xolsp4JwjPK3L(u"ࠧࠡࠪࠪ࠴")+hfx3IbcMO8Z6gGeonPQz(HHrizKtMUL50nWRFkc8TZAqQ)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠨࠢ࠰ࠤࠬ࠵")+str(dUma5MI3vyZQjxXKJrTk)+iqHhJSxdaANDG5rlZm7B(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	HZ2JTMahcP7 = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࠤ࠭࠭࠷")+hfx3IbcMO8Z6gGeonPQz(LLw2hIZdG8sfUXub)+RMxjDCgEBtiFmWvrdVeU0cwTqz(u"ࠫࠥ࠳ࠠࠨ࠸")+str(NVEpgfF2tKP8x3WyHQe4zTqRB)+VHrIziKUDuNGXkMla(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	VcySBqrUMd96zOHQTjeKNAkgFP = RMxjDCgEBtiFmWvrdVeU0cwTqz(u"࠭ࠠࠩࠩ࠺")+hfx3IbcMO8Z6gGeonPQz(KKJFHhPT4e2QLVdWX)+dC3PsQJ0Ti28uYlov(u"ࠧࠡ࠯ࠣࠫ࠻")+str(NuYLiExznTPUO9rHRKGh10Jmf)+hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	e9I2TbwEJYNMg5Bav8tFVGx = vstnSTrYdRo3g9xy7kEC8KwZM+bKu8CcjpyRf+jLit3msHkpBGqbTKS2+HHrizKtMUL50nWRFkc8TZAqQ+LLw2hIZdG8sfUXub+KKJFHhPT4e2QLVdWX
	UZq3rSzmpw61ALGCIeuxBRyhb75V4 = D9LnNgXyBj4IbTQeufG1qv+Ub1VAQzGgR+GNsQkmgib2j6ycAR+dUma5MI3vyZQjxXKJrTk+NVEpgfF2tKP8x3WyHQe4zTqRB+NuYLiExznTPUO9rHRKGh10Jmf
	Vvju9Ht8SGxoiTa6lCs = wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠩࠣࠬࠬ࠽")+hfx3IbcMO8Z6gGeonPQz(e9I2TbwEJYNMg5Bav8tFVGx)+VHrIziKUDuNGXkMla(u"ࠪࠤ࠲ࠦࠧ࠾")+str(UZq3rSzmpw61ALGCIeuxBRyhb75V4)+jR9YtmsgDX8nTQlMb6G3(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	Qm8SMu6ecXtigDCWw1oak(hh4FrbOWHjmD5KcS13MN9CexsT7p(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),TdtCLWYSJNK8zOb+Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"࠷࠶࠺࢏"))
	Qm8SMu6ecXtigDCWw1oak(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),TdtCLWYSJNK8zOb+rxWDdRBIct57i90s(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+Vvju9Ht8SGxoiTa6lCs,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠸࠷࠺࢐"))
	Qm8SMu6ecXtigDCWw1oak(dC3PsQJ0Ti28uYlov(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+rxWDdRBIct57i90s(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"࠻࠼࠽࠾࢑"))
	Qm8SMu6ecXtigDCWw1oak(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),TdtCLWYSJNK8zOb+EEhslBbQRMKpSviLGuew1Jr5ncdmj8(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+o7of6KbkMgVpnG53QZ0,G9G0YqivIfmUWO8K,UighHKAfySm4PWErqJ(u"࠺࠹࠶࢒"))
	Qm8SMu6ecXtigDCWw1oak(VHrIziKUDuNGXkMla(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),TdtCLWYSJNK8zOb+GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+DTUp9SXGQBRuy6a2OWVEKL7Pk,G9G0YqivIfmUWO8K,DTF3Lwy9etRH8mI(u"࠻࠺࠸࢓"))
	Qm8SMu6ecXtigDCWw1oak(rr7Xolsp4JwjPK3L(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),TdtCLWYSJNK8zOb+hhdGMSsBzel96obfEmrwiuLPOvq(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+gkRpy0nfKFa1tQb48l3ZrC9qO,G9G0YqivIfmUWO8K,FWqeEzO1i8Dn0ga(u"࠼࠻࠳࢔"))
	Qm8SMu6ecXtigDCWw1oak(wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),TdtCLWYSJNK8zOb+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+QYsK8uo0Sh9C,G9G0YqivIfmUWO8K,GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠽࠵࠵࢕"))
	Qm8SMu6ecXtigDCWw1oak(ETNq5t4MYngSsbfFD8J0v(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),TdtCLWYSJNK8zOb+vCmnFshSi4flecXIY2gy38G0DJw(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+HZ2JTMahcP7,G9G0YqivIfmUWO8K,yiaeCEwJjOcWA4ZSd5h(u"࠷࠶࠷࢖"))
	Qm8SMu6ecXtigDCWw1oak(ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),TdtCLWYSJNK8zOb+DTF3Lwy9etRH8mI(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+VcySBqrUMd96zOHQTjeKNAkgFP,G9G0YqivIfmUWO8K,iqHhJSxdaANDG5rlZm7B(u"࠸࠷࠹ࢗ"))
	amx9qJHkhw7oLdtVMG3.setSetting(CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),G9G0YqivIfmUWO8K)
	return
def DptBcgAIyJQS045EXl8vhRTZOq3wH():
	J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,EHUAyW2lQfe4LXmhgIGc(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),yiaeCEwJjOcWA4ZSd5h(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd==-iAGgjwb7tVMmacRJ(u"࠳࢘"): return
	if J8UB4bgrawlyzjYXA759Ee1c0N2fd:
		import subprocess as RRGq48uQHjx1efyTA
		try:
			RRGq48uQHjx1efyTA.Popen(DTF3Lwy9etRH8mI(u"ࠬࡹࡵࠨࡕ"))
			o590lxhLquR7z6QrSNy = P5VqbRSzjtO4UE1rZaolG67XA
		except: o590lxhLquR7z6QrSNy = kkMuQrLWcEayRm
		if o590lxhLquR7z6QrSNy:
			mtdnaAj4kzZ = j7yV9qvStXOFAbKkRWLde1rEuaPi+ww0sZkBU9JKd+kj1rVidLIlwZSoJzGxPEA75muhnv0+ww0sZkBU9JKd+ea2RYdv8WNE5bT4l+ww0sZkBU9JKd+Y13VmZM9Gs5y+ww0sZkBU9JKd+gzb8kGN3nqTsM5pj6+ww0sZkBU9JKd+kk7iKnfav1IRx0oC4BbhwdzPl
			Xm86iluW31oU = RRGq48uQHjx1efyTA.Popen(rxWDdRBIct57i90s(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+mtdnaAj4kzZ+rr7Xolsp4JwjPK3L(u"ࠧࠣࠩࡗ"),shell=P5VqbRSzjtO4UE1rZaolG67XA,stdin=RRGq48uQHjx1efyTA.PIPE,stdout=RRGq48uQHjx1efyTA.PIPE,stderr=RRGq48uQHjx1efyTA.PIPE)
			hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,qTVF3icWwGXy5(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),qTVF3icWwGXy5(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
		else: hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,cJSNFCIhymEfx6grGu0M(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),bneABYmwFUH8GXphg0Kl2Sq(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def hfx3IbcMO8Z6gGeonPQz(e9I2TbwEJYNMg5Bav8tFVGx):
	for mrHZQgCk7yN in [wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬࡈࠧ࡜"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"࠭ࡋࡃࠩ࡝"),yiaeCEwJjOcWA4ZSd5h(u"ࠧࡎࡄࠪ࡞"),RkxO6mlVHEiTcajWDJrFGsvg2Qz(u"ࠨࡉࡅࠫ࡟"),dhANiYPG7xXrSyJfIjZ8nBboLv(u"ࠩࡗࡆࠬࡠ")]:
		if e9I2TbwEJYNMg5Bav8tFVGx<FWqeEzO1i8Dn0ga(u"࠴࠴࠷࠺࢙"): break
		else: e9I2TbwEJYNMg5Bav8tFVGx /= CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"࠵࠵࠸࠴࠯࠲࢚")
	Vvju9Ht8SGxoiTa6lCs = iAGgjwb7tVMmacRJ(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(e9I2TbwEJYNMg5Bav8tFVGx,mrHZQgCk7yN)
	return Vvju9Ht8SGxoiTa6lCs
def T2TMhELomcX8NfjFW3HiU15DJdCQ7(EKDb0jTYfh5g9U1Gua7=wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠫ࠳࠭ࡢ")):
	global ppzUMZiJmCe8QKjTb,Bw7AKmHM8TenU0SCPZxy4Rpvi
	ppzUMZiJmCe8QKjTb,Bw7AKmHM8TenU0SCPZxy4Rpvi = iqHhJSxdaANDG5rlZm7B(u"࠵࢛"),iqHhJSxdaANDG5rlZm7B(u"࠵࢛")
	def lRiOBZUVuKz0(EKDb0jTYfh5g9U1Gua7):
		global ppzUMZiJmCe8QKjTb,Bw7AKmHM8TenU0SCPZxy4Rpvi
		if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.exists(EKDb0jTYfh5g9U1Gua7):
			if RVpeGcmPxj9tCnT40Nf216(u"࠶࢜") and hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(ifTNQtY3XrquHMV4wlCgI6FmpPK):
				for iQLnxMfadXEbUrpv6lqNmPjtSO in ifTNQtY3XrquHMV4wlCgI6FmpPK.scandir(EKDb0jTYfh5g9U1Gua7):
					if iQLnxMfadXEbUrpv6lqNmPjtSO.is_dir(follow_symlinks=kkMuQrLWcEayRm):
						lRiOBZUVuKz0(iQLnxMfadXEbUrpv6lqNmPjtSO.path)
					elif iQLnxMfadXEbUrpv6lqNmPjtSO.is_file(follow_symlinks=kkMuQrLWcEayRm):
						ppzUMZiJmCe8QKjTb += iQLnxMfadXEbUrpv6lqNmPjtSO.stat().st_size
						Bw7AKmHM8TenU0SCPZxy4Rpvi += rxWDdRBIct57i90s(u"࠱࢝")
			else:
				for iQLnxMfadXEbUrpv6lqNmPjtSO in ifTNQtY3XrquHMV4wlCgI6FmpPK.listdir(EKDb0jTYfh5g9U1Gua7):
					pprwfZdSi1xgh0KNTG = ifTNQtY3XrquHMV4wlCgI6FmpPK.path.abspath(ifTNQtY3XrquHMV4wlCgI6FmpPK.path.join(EKDb0jTYfh5g9U1Gua7,iQLnxMfadXEbUrpv6lqNmPjtSO))
					if ifTNQtY3XrquHMV4wlCgI6FmpPK.path.isdir(pprwfZdSi1xgh0KNTG):
						lRiOBZUVuKz0(pprwfZdSi1xgh0KNTG)
					elif ifTNQtY3XrquHMV4wlCgI6FmpPK.path.isfile(pprwfZdSi1xgh0KNTG):
						e9I2TbwEJYNMg5Bav8tFVGx,UZq3rSzmpw61ALGCIeuxBRyhb75V4 = OSNKd3Zsh4GgE(pprwfZdSi1xgh0KNTG)
						ppzUMZiJmCe8QKjTb += e9I2TbwEJYNMg5Bav8tFVGx
						Bw7AKmHM8TenU0SCPZxy4Rpvi += UZq3rSzmpw61ALGCIeuxBRyhb75V4
		return
	try: lRiOBZUVuKz0(EKDb0jTYfh5g9U1Gua7)
	except: pass
	return ppzUMZiJmCe8QKjTb,Bw7AKmHM8TenU0SCPZxy4Rpvi
def hRsQZmcIqoN6faH47B9(showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,Dj4ySMftbrzYh8aFRBeZUiLAd7k(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+t2sCrJ0xbgDRkf(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠬࡥ")+zEgtT9cR6bFp7JXqI5VuhNeP+ssGdubC4mngM9D5SRc3Ye(u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧࡦ")+zEgtT9cR6bFp7JXqI5VuhNeP+FWqeEzO1i8Dn0ga(u"ࠩยࠥࠦ࠭ࡧ")+zzGfwLAyN5HTxUoJeaivY)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=iqHhJSxdaANDG5rlZm7B(u"࠲࢞"): return
	Sm8oLxifPQNzI(gLcsYrORXAaopQ73K6jk,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(zlpyf7mbj8MNAxUcPd,P5VqbRSzjtO4UE1rZaolG67XA,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(SBRA6rKkCzMwHm7Jb5i4FtpEsf,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	NXJf0R6kAoYm2qUdhFZucI(AocKaTSP94dVQ1rfWxUY6Nn23,kkMuQrLWcEayRm)
	if showDialogs:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ZajcoF2kN6vd7KCqGTbHSQwxA8Jg(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),GvaYKBCsURLOh9H6o02QcT4qM3liP(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def nSkVvL6CuIMGps0Q5axe3hE7K(showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+ETNq5t4MYngSsbfFD8J0v(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ࡫")+zEgtT9cR6bFp7JXqI5VuhNeP+wRK6Ms5kgQXGJA1ZVOBxjTLovPa8(u"ࠧࡶࡵࡤ࡫ࡪࡹࡴࡢࡶࡶࠤ࠳࠴ࠠࡥࡴࡲࡴࡧࡵࡸࠡ࠰࠱ࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠡ࠰࠱ࠤࡱࡵࡧࡨࡧࡵࠤ࠳࠴ࠠ࡭ࡱࡪࠤ࠳࠴ࠠࡢࡰࡵࠫ࡬")+zEgtT9cR6bFp7JXqI5VuhNeP+rxWDdRBIct57i90s(u"ࠨࡁࠤࠥࠬ࡭")+zzGfwLAyN5HTxUoJeaivY)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=cjbAkCIinvs(u"࠳࢟"): return
	Sm8oLxifPQNzI(j7yV9qvStXOFAbKkRWLde1rEuaPi,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(kj1rVidLIlwZSoJzGxPEA75muhnv0,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(ea2RYdv8WNE5bT4l,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(Y13VmZM9Gs5y,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(gzb8kGN3nqTsM5pj6,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	Sm8oLxifPQNzI(kk7iKnfav1IRx0oC4BbhwdzPl,kkMuQrLWcEayRm,kkMuQrLWcEayRm)
	if showDialogs:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,ETNq5t4MYngSsbfFD8J0v(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),FWqeEzO1i8Dn0ga(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
def NXJf0R6kAoYm2qUdhFZucI(oUMr9z6kD8Ht20XVAifdYJuhOgs,showDialogs):
	if showDialogs:
		J8UB4bgrawlyzjYXA759Ee1c0N2fd = xNVJH71kmLUIy3CjS9TDBQoYu5(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,wIu47Z8T0cVjg5iNX6omfkPbsDO(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),A7XhkmSYZlidyMt5FpWqTgjNezbnD+bneABYmwFUH8GXphg0Kl2Sq(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࡱ")+zzGfwLAyN5HTxUoJeaivY)
		if J8UB4bgrawlyzjYXA759Ee1c0N2fd!=dhANiYPG7xXrSyJfIjZ8nBboLv(u"࠴ࢠ"): return
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n = Pkp47glurdBOS38Y.connect(oUMr9z6kD8Ht20XVAifdYJuhOgs)
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.text_factory = str
	ww2WhlesJYXSLQBMZ6gdy4K7c = plXWEwZYQTbg4JHCByU6LSr8RO1m0n.cursor()
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(ETNq5t4MYngSsbfFD8J0v(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪࡲ"))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(yiaeCEwJjOcWA4ZSd5h(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬࡳ"))
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(RVpeGcmPxj9tCnT40Nf216(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨࡴ"))
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.commit()
	ww2WhlesJYXSLQBMZ6gdy4K7c.execute(cjbAkCIinvs(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪࡵ"))
	plXWEwZYQTbg4JHCByU6LSr8RO1m0n.close()
	if showDialogs:
		hbKFzulmsw4k(G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,hhdGMSsBzel96obfEmrwiuLPOvq(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),CJ0Z89jUnbRxAtguzMdlX6YqVKsS(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡷ"))
		Wz9Lj5vK4qeIBn1rTP20y78aogJ(kkMuQrLWcEayRm)
	return
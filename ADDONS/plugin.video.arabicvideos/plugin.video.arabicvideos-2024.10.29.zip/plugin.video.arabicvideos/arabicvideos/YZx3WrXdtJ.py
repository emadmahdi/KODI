# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'SHOFHA'
TdtCLWYSJNK8zOb = '_SHT_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def RAndFk3y4Pbvs29(mode,url,text):
	if   mode==640: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==641: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,text)
	elif mode==642: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==644: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==645: tRojAyBgfDH37eLCwP4dWl = EL0QAd56tj7Db9eFSw3UZofIsra8(url)
	elif mode==649: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,649,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'المميزة',ffVP3AK5RqhkgYnjZoNis,641,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'featured')
	Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+'جديد الموقع',ffVP3AK5RqhkgYnjZoNis+'/newvideos.php',641,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K)
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"navslide-divider"></div>(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	for Y6YdkAMluFbwx,title in items:
		if title in tlcXBJEfIHF02vQ6yxSom9z1: continue
		Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,644)
	return
def QgXYczTwIFivtxa8l4d32oKhkrHn(url):
	VVevamF18rQNYhIp5MSZos = []
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-SUBMENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	kyoQ0h8lGBOW13cNvRqjDp = oo9kuULlebNgpY0Om.findall('"caret"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if kyoQ0h8lGBOW13cNvRqjDp:
		BN1KdkzCmvshw = kyoQ0h8lGBOW13cNvRqjDp[0]
		BN1KdkzCmvshw = BN1KdkzCmvshw.replace('"presentation"','</ul>')
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = [(G9G0YqivIfmUWO8K,BN1KdkzCmvshw)]
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' فرز أو فلتر أو ترتيب '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
		for mX8PGEof4iCvtnYeT,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			VVevamF18rQNYhIp5MSZos = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if mX8PGEof4iCvtnYeT: mX8PGEof4iCvtnYeT = mX8PGEof4iCvtnYeT+': '
			for Y6YdkAMluFbwx,title in VVevamF18rQNYhIp5MSZos:
				title = mX8PGEof4iCvtnYeT+title
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,641)
	msFSK7j9MrcoPafDnkNO = oo9kuULlebNgpY0Om.findall('"pm-category-subcats"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if msFSK7j9MrcoPafDnkNO:
		BN1KdkzCmvshw = msFSK7j9MrcoPafDnkNO[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if len(qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv)<30:
			if VVevamF18rQNYhIp5MSZos: Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
			for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,641)
	if not kyoQ0h8lGBOW13cNvRqjDp and not msFSK7j9MrcoPafDnkNO: UUhwKBgI2nt(url)
	return
def UUhwKBgI2nt(url,A0AzrLupg8h1s=G9G0YqivIfmUWO8K):
	if A0AzrLupg8h1s=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',url,data,headers,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-TITLES-1st')
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-TITLES-2nd')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	BN1KdkzCmvshw,items = G9G0YqivIfmUWO8K,[]
	sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
	if A0AzrLupg8h1s=='ajax-search':
		BN1KdkzCmvshw = GagwMT6q3oc7UZ2Q
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	elif A0AzrLupg8h1s=='featured':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pm-video-watch-featured"(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_episodes':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	elif A0AzrLupg8h1s=='new_movies':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"row pm-ul-browse-videos(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if len(cSLKDEATk7y10ovtGZCwF)>1: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[1]
	elif A0AzrLupg8h1s=='featured_series':
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in qJd3Ds8GcMQfU2Bmnjz7l14ROT0PIv: items.append((G9G0YqivIfmUWO8K,Y6YdkAMluFbwx,title))
	else:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('(data-echo=".*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF: BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
	if BN1KdkzCmvshw and not items: items = oo9kuULlebNgpY0Om.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
	if not items: return
	ehHpxSUAZnVITs4y5XjDKb8zC = []
	N78M4ZjFtLi0CvKDzTlmERSe9rc = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for M4qkBDatEIf3T,Y6YdkAMluFbwx,title in items:
		RnV3EqPNpXTDuI7 = oo9kuULlebNgpY0Om.findall('(.*?) (الحلقة|حلقة).\d+',title,oo9kuULlebNgpY0Om.DOTALL)
		if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in N78M4ZjFtLi0CvKDzTlmERSe9rc):
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,642,M4qkBDatEIf3T)
		elif A0AzrLupg8h1s=='new_episodes':
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,642,M4qkBDatEIf3T)
		elif RnV3EqPNpXTDuI7:
			title = '_MOD_' + RnV3EqPNpXTDuI7[0][0]
			if title not in ehHpxSUAZnVITs4y5XjDKb8zC:
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,645,M4qkBDatEIf3T)
				ehHpxSUAZnVITs4y5XjDKb8zC.append(title)
		else: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,645,M4qkBDatEIf3T)
	if 1:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"pagination(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				if Y6YdkAMluFbwx=='#': continue
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+'/'+Y6YdkAMluFbwx.strip('/')
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'صفحة '+title,Y6YdkAMluFbwx,641)
	return
def EL0QAd56tj7Db9eFSw3UZofIsra8(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	Vy1U0koJLPFhxe2TS = oo9kuULlebNgpY0Om.findall('"og:image" content="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Vy1U0koJLPFhxe2TS: M4qkBDatEIf3T = Vy1U0koJLPFhxe2TS[0]
	else: M4qkBDatEIf3T = G9G0YqivIfmUWO8K
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('episodeNumber.*?</div>(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if not cSLKDEATk7y10ovtGZCwF: cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('class="eplist"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?><span>(.*?)</em>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		if not items: items = oo9kuULlebNgpY0Om.findall('href="(.*?)" title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.replace('</span><em>',ww0sZkBU9JKd)
			Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,642,M4qkBDatEIf3T)
	return
def sWujQcGynM9NtJeTfqk3D(url):
	ODnaR0N8UHv7Twy6jS,Y4aIzyVXN2j,ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh = [],[],[]
	if '/watch.php' in url: XXzvmn7ewM8yBfoxua = url.replace('/watch.php','/view.php')
	else: XXzvmn7ewM8yBfoxua = url
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',XXzvmn7ewM8yBfoxua,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'SHOFHA-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	if 'embedded-video' in GagwMT6q3oc7UZ2Q:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"embedded-video"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if dsGzqX4k0a8RLyc:
				Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[0]
				if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
					Y4aIzyVXN2j.append('?named=__embed')
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if 'WatchServers' in GagwMT6q3oc7UZ2Q:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"WatchServers"(.*?)</script>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			oz7gLUAM4lcxYmeTG3SHajJFtv = oo9kuULlebNgpY0Om.findall('id="(.*?)".*?</span>(.*?)</button>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			BN1KdkzCmvshw = BN1KdkzCmvshw.replace('\\"','"').replace('\/','/')
			dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('"<iframe.src="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if len(oz7gLUAM4lcxYmeTG3SHajJFtv)==len(dsGzqX4k0a8RLyc):
				for id,title in oz7gLUAM4lcxYmeTG3SHajJFtv:
					Y6YdkAMluFbwx = dsGzqX4k0a8RLyc[int(id)]
					if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
						Y4aIzyVXN2j.append('?named='+title+'__watch')
						ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	if 'DownloadServer' in GagwMT6q3oc7UZ2Q:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('"DownloadServer"(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			if not dsGzqX4k0a8RLyc: dsGzqX4k0a8RLyc = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			sg0IMYl698kyvmfVASQU4K13Z2L = xWiOjcUrJVdtP4B5Iml(url,'url')
			for Y6YdkAMluFbwx,title in dsGzqX4k0a8RLyc:
				if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = sg0IMYl698kyvmfVASQU4K13Z2L+Y6YdkAMluFbwx
				if Y6YdkAMluFbwx not in ODnaR0N8UHv7Twy6jS:
					Y4aIzyVXN2j.append('?named='+title+'__download')
					ODnaR0N8UHv7Twy6jS.append(Y6YdkAMluFbwx)
	iiMkLyedYA = zip(ODnaR0N8UHv7Twy6jS,Y4aIzyVXN2j)
	for Y6YdkAMluFbwx,name in iiMkLyedYA: ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+name)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if search==G9G0YqivIfmUWO8K: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if search==G9G0YqivIfmUWO8K: return
	search = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/search.php?keywords='+search
	UUhwKBgI2nt(url,'search')
	return
# -*- coding: utf-8 -*-
from a1aDsx9ioY import *
s5slfAmHkUtMR3WSKY1ZTX = 'EGYBEST4'
TdtCLWYSJNK8zOb = '_EB4_'
ffVP3AK5RqhkgYnjZoNis = Kkfl8xemuHbd1w3a0ABPcDrN[s5slfAmHkUtMR3WSKY1ZTX][0]
tlcXBJEfIHF02vQ6yxSom9z1 = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def RAndFk3y4Pbvs29(mode,url,eehFlSEjHioyAWpLqZXt79,text):
	if   mode==800: tRojAyBgfDH37eLCwP4dWl = hXz0OvlBbVLste3xWE6C74()
	elif mode==801: tRojAyBgfDH37eLCwP4dWl = UUhwKBgI2nt(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==802: tRojAyBgfDH37eLCwP4dWl = QgXYczTwIFivtxa8l4d32oKhkrHn(url)
	elif mode==803: tRojAyBgfDH37eLCwP4dWl = sWujQcGynM9NtJeTfqk3D(url)
	elif mode==804: tRojAyBgfDH37eLCwP4dWl = zzR2cwayn6V9vITEgspxLi3oZ(url)
	elif mode==806: tRojAyBgfDH37eLCwP4dWl = HbfhT3tmkAPMJCENld672jGn(url,eehFlSEjHioyAWpLqZXt79)
	elif mode==809: tRojAyBgfDH37eLCwP4dWl = b6WZDnA0dLBiCITrF37OS(text)
	else: tRojAyBgfDH37eLCwP4dWl = False
	return tRojAyBgfDH37eLCwP4dWl
def hXz0OvlBbVLste3xWE6C74():
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'بحث في الموقع',G9G0YqivIfmUWO8K,809,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'فلتر',ffVP3AK5RqhkgYnjZoNis+'/trending',804,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'_REMEMBERRESULTS_')
	Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	D7omduSeM5Gk = PPRoOyl2xVH(AH0BQ4LKlDMrfvqWmXn5,'GET',ffVP3AK5RqhkgYnjZoNis,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-MENU-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('nav-categories(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801)
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('mainContent(.*?)<footer>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801,G9G0YqivIfmUWO8K,'mainmenu')
		Qm8SMu6ecXtigDCWw1oak('link',A7XhkmSYZlidyMt5FpWqTgjNezbnD+' ===== ===== ===== '+zzGfwLAyN5HTxUoJeaivY,G9G0YqivIfmUWO8K,9999)
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('main-menu(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for Y6YdkAMluFbwx,title in items:
			title = title.strip(ww0sZkBU9JKd)
			if any(yW70dtahIjkPCJg2TA in title for yW70dtahIjkPCJg2TA in tlcXBJEfIHF02vQ6yxSom9z1): continue
			if 'http' not in Y6YdkAMluFbwx: Y6YdkAMluFbwx = ffVP3AK5RqhkgYnjZoNis+Y6YdkAMluFbwx
			Qm8SMu6ecXtigDCWw1oak('folder',s5slfAmHkUtMR3WSKY1ZTX+'_SCRIPT_'+TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801)
	return GagwMT6q3oc7UZ2Q
def HbfhT3tmkAPMJCENld672jGn(url,type=G9G0YqivIfmUWO8K):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-SEASONS_EPISODES-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('mainTitle.*?>(.*?)<(.*?)pageContent',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		KmsdJXWHbDET9AankUCeMutfvQj,GOQI6tW4xVh8NYwdPqMD9Kg,items = G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,[]
		for name,BN1KdkzCmvshw in cSLKDEATk7y10ovtGZCwF:
			if 'حلقات' in name: GOQI6tW4xVh8NYwdPqMD9Kg = BN1KdkzCmvshw
			if 'مواسم' in name: KmsdJXWHbDET9AankUCeMutfvQj = BN1KdkzCmvshw
		if KmsdJXWHbDET9AankUCeMutfvQj and not type:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',KmsdJXWHbDET9AankUCeMutfvQj,oo9kuULlebNgpY0Om.DOTALL)
			if len(items)>1:
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
					Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,806,M4qkBDatEIf3T,'season')
		if GOQI6tW4xVh8NYwdPqMD9Kg and len(items)<2:
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',GOQI6tW4xVh8NYwdPqMD9Kg,oo9kuULlebNgpY0Om.DOTALL)
			if items:
				for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
					Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,803,M4qkBDatEIf3T)
			else:
				items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',GOQI6tW4xVh8NYwdPqMD9Kg,oo9kuULlebNgpY0Om.DOTALL)
				for Y6YdkAMluFbwx,title in items:
					Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,803)
	return
def UUhwKBgI2nt(url,type=G9G0YqivIfmUWO8K):
	wwCFVzNkHGQsoRYgpDhtL4qJ7dBP,start,hEDd8S3OLIugvAc5HRzQkTqM60wW,select,qLUBEJS0aNbFHk3hpcvW = 0,0,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K
	if 'pagination' in type:
		Ab6uwEN8v4aYz5ImCrVGQl9yL,pPIbdY3oKe = url.split('?next=page&')
		AAFEPhnMlsH5B3z0gYQWD4j7kUc = {'Content-Type':'application/x-www-form-urlencoded'}
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'POST',Ab6uwEN8v4aYz5ImCrVGQl9yL,pPIbdY3oKe,AAFEPhnMlsH5B3z0gYQWD4j7kUc,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-TITLES-1st')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = 'secContent'+GagwMT6q3oc7UZ2Q+'<footer>'
	else:
		D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-TITLES-2nd')
		GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
		ssVw9GhqHbuQD5On3YxeKPWFkgjRJt = GagwMT6q3oc7UZ2Q
	items,FgXjbkoJlSm,IjPUNHfzpc0mvu2CsAhLOqQ = [],False,False
	if not type and '/collections' not in url:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('mainContent(.*?)</div>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?</i>(.*?)</a>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,title in items:
				title = title.strip(ww0sZkBU9JKd)
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801,G9G0YqivIfmUWO8K,'submenu')
				FgXjbkoJlSm = True
	if not FgXjbkoJlSm:
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('secContent(.*?)mainContent',ssVw9GhqHbuQD5On3YxeKPWFkgjRJt,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,M4qkBDatEIf3T,title in items:
				Y6YdkAMluFbwx = aKAyEnjxIlzZtCTv(Y6YdkAMluFbwx)
				M4qkBDatEIf3T = M4qkBDatEIf3T.strip(zEgtT9cR6bFp7JXqI5VuhNeP)
				title = kD2wGe8Oh4T7Cj3BMsy0(title)
				if '/series/' in Y6YdkAMluFbwx and type=='season': Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,806,M4qkBDatEIf3T,'season')
				elif '/series/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,806,M4qkBDatEIf3T)
				elif '/seasons/' in Y6YdkAMluFbwx: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801,M4qkBDatEIf3T,'season')
				elif '/collections' in url: Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801,M4qkBDatEIf3T,'collections')
				else: Qm8SMu6ecXtigDCWw1oak('video',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,803,M4qkBDatEIf3T)
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('loadMoreParams = (.*?);',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			uRh0OfcrCjvt7LQEgk = bRCSwcA89e4J7pqdays5PxGiD2('dict',BN1KdkzCmvshw)
			qLUBEJS0aNbFHk3hpcvW = uRh0OfcrCjvt7LQEgk['ajaxurl']
			CoX5H3D7jVWGapxst = int(uRh0OfcrCjvt7LQEgk['current_page'])+1
			ssIOCu0ZqQD6ThNL = int(uRh0OfcrCjvt7LQEgk['max_page'])
			Qy6tiYcRjHA8dxLMSXaw = uRh0OfcrCjvt7LQEgk['posts'].replace('False','false').replace('True','true').replace('None','null')
			if CoX5H3D7jVWGapxst<ssIOCu0ZqQD6ThNL:
				pPIbdY3oKe = 'action=loadmore&query='+SSX6oT0lADZhKRImPvCHFkYJs(Qy6tiYcRjHA8dxLMSXaw,G9G0YqivIfmUWO8K)+'&page='+str(CoX5H3D7jVWGapxst)
				XXzvmn7ewM8yBfoxua = qLUBEJS0aNbFHk3hpcvW+'?next=page&'+pPIbdY3oKe
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'جلب المزيد',XXzvmn7ewM8yBfoxua,801,G9G0YqivIfmUWO8K,'pagination_'+type)
		elif '?next=page&' in url:
			pPIbdY3oKe,zz1cDUuAaFjxL7HZThqon9OPG4MNdv = pPIbdY3oKe.rsplit('=',1)
			zz1cDUuAaFjxL7HZThqon9OPG4MNdv = int(zz1cDUuAaFjxL7HZThqon9OPG4MNdv)+1
			XXzvmn7ewM8yBfoxua = Ab6uwEN8v4aYz5ImCrVGQl9yL+'?next=page&'+pPIbdY3oKe+'='+str(zz1cDUuAaFjxL7HZThqon9OPG4MNdv)
			Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+'جلب المزيد',XXzvmn7ewM8yBfoxua,801,G9G0YqivIfmUWO8K,'pagination_'+type)
	return
def zzR2cwayn6V9vITEgspxLi3oZ(url):
	D7omduSeM5Gk = PPRoOyl2xVH(TTm2opnt9fLX8DBYizbuSPvwhJZCl,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-FILTERS-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('sub_nav(.*?)secContent ',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		cUE5uH8hAtOmTp = oo9kuULlebNgpY0Om.findall('"current_opt">(.*?)<(.*?)</div>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for name,BN1KdkzCmvshw in cUE5uH8hAtOmTp:
			if 'التصنيف' in name: continue
			name = name.strip(ww0sZkBU9JKd)
			items = oo9kuULlebNgpY0Om.findall('href="(.*?)">(.*?)<',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for Y6YdkAMluFbwx,yW70dtahIjkPCJg2TA in items:
				title = name+':  '+yW70dtahIjkPCJg2TA
				Qm8SMu6ecXtigDCWw1oak('folder',TdtCLWYSJNK8zOb+title,Y6YdkAMluFbwx,801,G9G0YqivIfmUWO8K,'filter')
	return
def sWujQcGynM9NtJeTfqk3D(url):
	D7omduSeM5Gk = PPRoOyl2xVH(gWhZuzBnwiUVx5RoGFc6O7Hb,'GET',url,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,G9G0YqivIfmUWO8K,'EGYBEST4-PLAY-1st')
	GagwMT6q3oc7UZ2Q = D7omduSeM5Gk.content
	UUKJu0BWM9x4vQ7j6HLDaISyieTd = oo9kuULlebNgpY0Om.findall('<td>التصنيف</td>.*?">(.*?)<',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if UUKJu0BWM9x4vQ7j6HLDaISyieTd and j4cVg3ZvbOTPDFt0mzJYHAlL2UB1p(s5slfAmHkUtMR3WSKY1ZTX,url,UUKJu0BWM9x4vQ7j6HLDaISyieTd): return
	ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,Y3yumlhcKaj2RQUg = [],[]
	Y6YdkAMluFbwx = oo9kuULlebNgpY0Om.findall('postEmbed.*?src="(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if Y6YdkAMluFbwx:
		Y6YdkAMluFbwx = Y6YdkAMluFbwx[0].replace(zEgtT9cR6bFp7JXqI5VuhNeP,G9G0YqivIfmUWO8K)
		Y3yumlhcKaj2RQUg.append(Y6YdkAMluFbwx)
		yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
		ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__embed')
	JkbicyYexsBrDZq7 = oo9kuULlebNgpY0Om.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if JkbicyYexsBrDZq7:
		qLUBEJS0aNbFHk3hpcvW,HGD02clisfMEkyYwX5PRebUnAu = JkbicyYexsBrDZq7[0]
		cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('postPlayer(.*?)</ul>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
		if cSLKDEATk7y10ovtGZCwF:
			BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
			iWfaqNJIgvQXA = oo9kuULlebNgpY0Om.findall('<li.*?id\,(.*?)\);">(.*?)</li>',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
			for ihFAt40cEu85dlwz2BnoqO,name in iWfaqNJIgvQXA:
				Y6YdkAMluFbwx = qLUBEJS0aNbFHk3hpcvW+'/temp/ajax/iframe.php?id='+HGD02clisfMEkyYwX5PRebUnAu+'&video='+ihFAt40cEu85dlwz2BnoqO
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+name+'__watch')
	cSLKDEATk7y10ovtGZCwF = oo9kuULlebNgpY0Om.findall('pageContentDown(.*?)</table>',GagwMT6q3oc7UZ2Q,oo9kuULlebNgpY0Om.DOTALL)
	if cSLKDEATk7y10ovtGZCwF:
		BN1KdkzCmvshw = cSLKDEATk7y10ovtGZCwF[0]
		items = oo9kuULlebNgpY0Om.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',BN1KdkzCmvshw,oo9kuULlebNgpY0Om.DOTALL)
		for I5chimw4D1okfxlBE2UpbuHJvStsZ,Y6YdkAMluFbwx in items:
			if Y6YdkAMluFbwx not in Y3yumlhcKaj2RQUg:
				if '/?url=' in Y6YdkAMluFbwx: Y6YdkAMluFbwx = Y6YdkAMluFbwx.split('/?url=')[1]
				Y3yumlhcKaj2RQUg.append(Y6YdkAMluFbwx)
				yVgLqfcUN1iO4 = xWiOjcUrJVdtP4B5Iml(Y6YdkAMluFbwx,'name')
				ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh.append(Y6YdkAMluFbwx+'?named='+yVgLqfcUN1iO4+'__download____'+I5chimw4D1okfxlBE2UpbuHJvStsZ)
	import iOVAoxDJew
	iOVAoxDJew.XTjZSa3Idi5DwmqxWrJyKGk(ffUc7nNLdrSC9j3AZ5R0IHQPiDGMVh,s5slfAmHkUtMR3WSKY1ZTX,'video',url)
	return
def b6WZDnA0dLBiCITrF37OS(search):
	search,EIcQfuLpMO2jX,showDialogs = bY6tjyS08hUC(search)
	if not search: search = ZT7zGWSCtpvfmwMNRjYrKL()
	if not search: return
	HG9ZQqnw71y0JmrDLx = search.replace(ww0sZkBU9JKd,'+')
	url = ffVP3AK5RqhkgYnjZoNis+'/?s='+HG9ZQqnw71y0JmrDLx
	UUhwKBgI2nt(url,'search')
	return
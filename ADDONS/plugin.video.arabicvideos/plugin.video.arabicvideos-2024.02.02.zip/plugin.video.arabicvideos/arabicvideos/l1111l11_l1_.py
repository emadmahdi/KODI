# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭ஂ")
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫஃ"):l1l111_l1_ (u"ࠨࠩ஄")}
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡏࡑࡇ࡟ࠨஅ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==10: l1lll_l1_ = l1l1l11_l1_()
	elif mode==11: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==12: l1lll_l1_ = PLAY(url)
	elif mode==13: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==14: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==15: l1lll_l1_ = l111111l_l1_()
	elif mode==16: l1lll_l1_ = l11111l1_l1_()
	elif mode==19: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஆ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫஇ"),l1l111_l1_ (u"ࠬ࠭ஈ"),19,l1l111_l1_ (u"࠭ࠧஉ"),l1l111_l1_ (u"ࠧࠨஊ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ஋"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ஌"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ஍"),l1l111_l1_ (u"ࠫࠬஎ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬஏ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨஐ")+l1lllll_l1_+l1l111_l1_ (u"ࠧระิࠤฬ๊ลืษไหฯ࠭஑"),l1l111_l1_ (u"ࠨࠩஒ"),14)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩஓ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬஔ")+l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠫக"),l1l111_l1_ (u"ࠬ࠭஖"),15)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ஗"),headers,l1l111_l1_ (u"ࠧࠨ஘"),l1l111_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪங"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨ࡮ࡢࡸ࠰ࡷࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨச"),html,re.DOTALL)
	l1111lll_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ஛"),l1111lll_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ஜ"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ஝"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨஞ")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬட"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ஠"),l1l111_l1_ (u"ࠩࠪ஡"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢ࡯ࡣࡹࡦࡦࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ஢"),html,re.DOTALL)
	l1l1l1l_l1_ = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ண"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬத"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ஥")+l1lllll_l1_+title,l1ll1ll_l1_,11)
	return html
def l111111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஦"),l1lllll_l1_+l1l111_l1_ (u"ࠨฮ่๎฾ࠦวๅ็ึุ่๊วหࠢส่฾ืศ๋หࠪ஧"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡺ࡮࡫ࡷ࠮࠺࠲ุ้๊ำๅษอ࠱฾ืศ๋หࠪந"),11)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪன"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥอไิ่ฬࠤฬ๊รฯ์ิอࠬப"),l1l111_l1_ (u"ࠬ࠭஫"),16)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭஬"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠศๆฦา๏ืษࠡ࠳ࠪ஭"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡪࡽ࠭࠹࠱่ืู้ไศฬ࠰ี๊฼ว็࠯࠵࠴࠷࠸ࠧம"),11)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩய"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣห้ษฮ๋ำฬࠤ࠷࠭ர"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡦࡹ࠰࠼࠴๋ำๅี็หฯ࠳ัๆุส๊࠲࠸࠰࠳࠵ࠪற"),11)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬல"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠴࠶ࠫள"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠶࠸࠵ๅึำํอࠬழ"),11)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨவ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠷࠸ࠧஶ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠲࠳࠱ู่ึ๐ษࠨஷ"),11)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫஸ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠳࠳ࠪஹ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠵࠵࠴๋ีา์ฬࠫ஺"),11)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஻"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠶࠵࠭஼"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠸࠰࠰็ุี๏ฯࠧ஽"),11)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪா"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠱࠺ࠩி"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠳࠼࠳๊฻ั๋หࠪீ"),11)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ு"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠴࠼ࠬூ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠶࠾࠯ๆืิ๎ฮ࠭௃"),11)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ௄"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠷࠷ࠨ௅"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠲࠹࠲ฺ้ื๊สࠩெ"),11)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬே"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠳࠹ࠫை"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠵࠻࠵ๅึำํอࠬ௉"),11)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩொ"),headers,True,l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ோ"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪ࡬ࡪࡧࡤࡪࡰࡪ࠱ࡹࡵࡰࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠩௌ"),html,re.DOTALL)
	block = l11llll_l1_[0]+l11llll_l1_[1]
	items=re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ்࠭ࠧ࠭"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ௎") in url: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭௏"),l1lllll_l1_+title,url,11,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ௐ"),l1lllll_l1_+title,url,12,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ௑"),url,l1l111_l1_ (u"ࠩࠪ௒"),headers,True,True,l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ௓"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠭࠴ࠪࡀࠫࡵ࡭࡬࡮ࡴࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ௔"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	found = False
	items = re.findall(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ௕"),block,re.DOTALL)
	l1l1_l1_,l11111ll_l1_ = [],[]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if title==l1l111_l1_ (u"࠭ࠧ௖"): title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩௗ"))[-1].replace(l1l111_l1_ (u"ࠨ࠯ࠪ௘"),l1l111_l1_ (u"ࠩࠣࠫ௙"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡡࡪࠫࠪࠩ௚"),title,re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = int(l1111ll1_l1_[0])
		else: l1111ll1_l1_ = 0
		l11111ll_l1_.append([l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_])
	l11111ll_l1_ = sorted(l11111ll_l1_, reverse=True, key=lambda key: key[3])
	for l1ll1l_l1_,l1ll1ll_l1_,title,l1111ll1_l1_ in l11111ll_l1_:
		l1ll1ll_l1_ = l111l1_l1_ + l1ll1ll_l1_
		title = title.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠤู๊ไิๆࠪ௛"),l1l111_l1_ (u"๋ࠬำๅี็ࠫ௜"))
		title = title.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ึุ่๊ࠧ௝"),l1l111_l1_ (u"ࠧศๆ่ืู้ไࠨ௞"))
		title = title.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡใํ่๊࠭௟"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ௠"))
		title = title.replace(l1l111_l1_ (u"ู้ࠪอ็ะหࠣห้็๊ๅ็ࠪ௡"),l1l111_l1_ (u"ࠫฬ๊แ๋ๆ่ࠫ௢"))
		title = title.replace(l1l111_l1_ (u"๋ࠬศศึิอ้่ࠥศๆํฮ๏࠭௣"),l1l111_l1_ (u"࠭ࠧ௤"))
		title = title.replace(l1l111_l1_ (u"ฺࠧษ็๎ฮูࠦๅ๋ࠣห้฿ัษࠩ௥"),l1l111_l1_ (u"ࠨࠩ௦"))
		title = title.replace(l1l111_l1_ (u"ุ่ࠩฬํฯส่ࠢฬฬฺัสࠩ௧"),l1l111_l1_ (u"ࠪࠫ௨"))
		title = title.replace(l1l111_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋࠭௩"),l1l111_l1_ (u"ࠬ࠭௪"))
		title = title.replace(l1l111_l1_ (u"࠭ว้่็ห๏์ࠧ௫"),l1l111_l1_ (u"ࠧࠨ௬"))
		title = title.replace(l1l111_l1_ (u"ࠨสฯ์ิฯฺࠠษ็๎ฮ࠭௭"),l1l111_l1_ (u"ࠩࠪ௮"))
		title = title.replace(l1l111_l1_ (u"ࠪะํีษࠡ฻ส่๏ฯࠧ௯"),l1l111_l1_ (u"ࠫࠬ௰"))
		title = title.replace(l1l111_l1_ (u"ࠬฮฯ้่ࠣฮา๋๊ๅࠩ௱"),l1l111_l1_ (u"࠭ࠧ௲"))
		title = title.replace(l1l111_l1_ (u"ฺࠧๆ์ࠤฬู๊าสࠪ௳"),l1l111_l1_ (u"ࠨࠩ௴"))
		title = title.replace(l1l111_l1_ (u"่ࠩฬฬฺัสࠩ௵"),l1l111_l1_ (u"ࠪࠫ௶"))
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭௷")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ௸"),l1l111_l1_ (u"࠭ࠠࠨ௹")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ௺"),l1l111_l1_ (u"ࠨࠢࠪ௻"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ௼")+title
		l1lllllll_l1_ = title
		if l1l111_l1_ (u"ࠪ࠳ࡶ࠵ࠧ௽") in url and (l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ௾") in title or l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬ௿") in title):
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩఀ"),title,re.DOTALL)
			if l1l1lll_l1_: l1lllllll_l1_ = l1l1lll_l1_[0]
		if l1lllllll_l1_ not in l1l1_l1_:
			l1l1_l1_.append(l1lllllll_l1_)
			if l1l111_l1_ (u"ࠧ࠰ࡳ࠲ࠫఁ") in url and (l1l111_l1_ (u"ࠨษ็ั้่ษࠨం") in title or l1l111_l1_ (u"ࠩส่า๊โ่ࠩః") in title):
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪఄ"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,13,l1ll1l_l1_)
				found = True
			elif l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫఅ") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬఆ"),l1lllll_l1_+title,l1ll1ll_l1_,11,l1ll1l_l1_)
				found = True
			else:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬఇ"),l1lllll_l1_+title,l1ll1ll_l1_,12,l1ll1l_l1_)
				found = True
	if found:
		items = re.findall(l1l111_l1_ (u"ࠧࡵࡵࡦࡣ࠸ࡪ࡟ࡣࡷࡷࡸࡴࡴࠠࡳࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬఈ"),block,re.DOTALL)
		for l1ll1ll_l1_,l1llllll1_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨఉ"),l1lllll_l1_+l1llllll1_l1_,url,11)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪఊ"),headers,True,l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩఋ"))
	l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡹࡥࡳ࡫ࡨࡷ࠳࠰࠿ࠪࠤࠪఌ"),html,re.DOTALL)
	l1lllll1_l1_ = l111l1_l1_+l1111l1l_l1_[0]
	l1lll_l1_ = l1lll11_l1_(l1lllll1_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭఍"),headers,True,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨఎ"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡶࡴ࠲࡯ࡦࡳࡣࡰࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫఏ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠤࠨఐ"),l1lllll1_l1_,re.DOTALL)
		if l1ll_l1_:
			first = l1ll_l1_[0][0]
			second,l111l111_l1_ = l1ll_l1_[0][1].rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ఑"),1)
			l1llllll_l1_ = second+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫఒ")
			l1llll_l1_.append(l1llllll_l1_)
			l1111111_l1_ = first+l111l111_l1_
		else:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬఓ"),headers,False,l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧఔ"))
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡴࡦࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧక"),l11l1ll1_l1_,re.DOTALL)
			if l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࡠࡡࡰ࠷ࡺ࠾ࠧఖ")
				l1llll_l1_.append(l1lllll1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡃࡱࡻࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩగ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨఘ"),block,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫఙ")
			l1llll_l1_.append(l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪచ"),url)
	return
def l11111l1_l1_():
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ఛ"),headers,True,l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡒࡂࡏࡄࡈࡆࡔ࠭࠲ࡵࡷࠫజ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࡤࡹࡥࡤࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡱ࡫ࡦࡵࡡࡦࡳࡳࡺࡥ࡯ࡶࠥࠫఝ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪఞ"),block,re.DOTALL)
	year = re.findall(l1l111_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱࠬࡠ࠶࠭࠺࡟࠮࠭࠴࠭ట"),str(items),re.DOTALL)
	year = year[0]
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬఠ"))+l1l111_l1_ (u"ࠫࠥ࠭డ")+year
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬఢ"),l1lllll_l1_+title,url,11)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧణ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨత"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠨࠢࠪథ"),l1l111_l1_ (u"ࠩ࠮ࠫద"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠥ࠳ࡶ࠵ࠢధ") + l1lll1ll_l1_
	l1lll_l1_ = l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ䉰")
headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䉱") : l1l111_l1_ (u"ࠧࠨ䉲") }
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧ䉳")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1llllll1l_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1llllll1l_l1_():
	message = l1l111_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠥ࠴࠮࠯๋ࠢฬาอฬสࠢส่๎ࠦวฺษาอࠥฮัๆฮฬࠤ๊์ࠠศๆุๅึࠦ࠮࠯࠰ࠣ์ฬ๊ๅษำ่ะࠥำวๅ์สࠤฺฺ๊้ๆࠣ์๏฿ว็์ฺ้๋่ࠣࠦๅฬࠤฺำ๊สࠢ࠱࠲࠳่ࠦๅ้ำหู่ࠥโࠢํฬ็๏ࠠศๆ่์็฿ࠠๆ฼็ๆࠥอไ๊่ࠢหฺࠥวยࠢส่้ํࠧ䉴")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䉵"),l1l111_l1_ (u"ࠫࠬ䉶"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䉷"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䉸"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䉹"),l1l111_l1_ (u"ࠨࠩ䉺"),189,l1l111_l1_ (u"ࠩࠪ䉻"),l1l111_l1_ (u"ࠪࠫ䉼"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䉽"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉾"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䉿")+l1lllll_l1_+l1l111_l1_ (u"ࠧษ๊ๆืࠥอ่โ์ึࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䊀"),l111l1_l1_,181,l1l111_l1_ (u"ࠨࠩ䊁"),l1l111_l1_ (u"ࠩࠪ䊂"),l1l111_l1_ (u"ࠪࡦࡴࡾ࠭ࡰࡨࡩ࡭ࡨ࡫ࠧ䊃"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊄"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊅")+l1lllll_l1_+l1l111_l1_ (u"࠭รฮัฮࠤฬ๊วโๆส้ࠬ䊆"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䊇"),l1l111_l1_ (u"ࠨࠩ䊈"),l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊉"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊊"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䊋")+l1lllll_l1_+l1l111_l1_ (u"ࠬะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࠫ䊌"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䊍"),l1l111_l1_ (u"ࠧࠨ䊎"),l1l111_l1_ (u"ࠨࡶࡹࠫ䊏"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊐"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䊑")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊วไอิࠤฺ๊ว่ัฬࠫ䊒"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䊓"),l1l111_l1_ (u"࠭ࠧ䊔"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡻ࡯ࡥࡸࡵࠪ䊕"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䊗")+l1lllll_l1_+l1l111_l1_ (u"ࠪว็๎้ࠡษ็หๆ๊วๆࠢส่าอไ๋หࠪ䊘"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䊙"),l1l111_l1_ (u"ࠬ࠭䊚"),l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䊛"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠧࠨ䊜"),headers,l1l111_l1_ (u"ࠨࠩ䊝"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䊞"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠸࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䊟"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊠"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䊡")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ䊢")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ䊣"),headers,l1l111_l1_ (u"ࠨࠩ䊤"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ䊥"))
	if type==l1l111_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶ࠰ࡱࡴࡼࡩࡦࡵࠪ䊦"): block = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂศำฯฬࠢส่ศ็ไศ็࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂࡨ࠲ࠩ䊧"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠬࡨ࡯ࡹ࠯ࡲࡪ࡫࡯ࡣࡦࠩ䊨"): block = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࠧࡄศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ี࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䊩"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䊪"): block = re.findall(l1l111_l1_ (u"ࠨࡤࡷࡲ࠲࠸࠭ࡰࡸࡨࡶࡱࡧࡹࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭䊫"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠩࡷࡳࡵ࠳ࡶࡪࡧࡺࡷࠬ䊬"): block = re.findall(l1l111_l1_ (u"ࠪࡦࡹࡴ࠭࠲ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠮࠮ࠫࡁࠬࡦࡹࡴ࠭࠳ࠢࡥࡸࡳ࠳ࡡࡣࡵࡲࡰࡾ࠭䊭"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡹࡼࠧ䊮"): block = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃะไ๋ใี๎ํ์ࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲ࡬ࠨࠧ䊯"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䊰"),l1l111_l1_ (u"ࠧࡵࡱࡳ࠱ࡲࡵࡶࡪࡧࡶࠫ䊱")]:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡷࡽࡱ࡫࠽ࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䊲"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥ࠷ࡠ࠶࠭࠺࡟࠮ࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡨ࡯ࡵࡶࡲࡱ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䊳"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ䊴"),l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ䊵"),l1l111_l1_ (u"ࠬอไฮๆๅ๋ࠬ䊶"),l1l111_l1_ (u"ู࠭าุࠪ䊷"),l1l111_l1_ (u"ࠧࡓࡣࡺࠫ䊸"),l1l111_l1_ (u"ࠨࡕࡰࡥࡨࡱࡄࡰࡹࡱࠫ䊹"),l1l111_l1_ (u"ࠩส฽้อๆࠨ䊺"),l1l111_l1_ (u"ࠪหัุวยࠩ䊻")]
	for l1ll1l_l1_,l1l1llll1lll_l1_,l1l1lllllll1_l1_,l1l1llllllll_l1_ in items:
		if type in [l1l111_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䊼"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊽")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1llll1lll_l1_,l1l1lllllll1_l1_,l1l1llllllll_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1llll1lll_l1_,l1l1lllllll1_l1_,l1l1llllllll_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࠿ࡷ࡫ࡨࡻࡂࡺࡲࡶࡧࠪ䊾"),l1l111_l1_ (u"ࠧࠨ䊿"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䋀") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䋁") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋂") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䋃"),l1l111_l1_ (u"ࠬ࠭䋄")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䋅"),l1l111_l1_ (u"ࠧࠨ䋆"))
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ䋇"))
		if l1l111_l1_ (u"ࠩส่า๊โสࠩ䋈") in title or l1l111_l1_ (u"ࠪห้ำไใ้ࠪ䋉") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ䋊"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䋋") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋌"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䋍") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䋎"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䋏") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋐"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࠬ䋑"):
		items = re.findall(l1l111_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䋒"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧ䋓"),l1l111_l1_ (u"ࠧࠨ䋔"))
			if title!=l1l111_l1_ (u"ࠨࠩ䋕"):
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋖"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ䋗")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䋘"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䋙"),headers,l1l111_l1_ (u"࠭ࠧ䋚"),l1l111_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䋛"))
	block = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䋜"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ䋝"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋞") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䋟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䋠"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"࠭ࠨศๆะ่็ฯࡼศๆะ่็ํࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ䋡"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䋢"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠨࠪࠬ࠱࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭䋣"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䋤"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠪࠤࠬ䋥") + title[0][1]
			else: title = l1l111_l1_ (u"ࠫࠬ䋦")
			title = name + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䋧") + l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭䋨") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䋩"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠨสฯ์ิฯࠠࠨ䋪") in title or l1l111_l1_ (u"ࠩหะํี็ࠡࠩ䋫") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䋬") + title.replace(l1l111_l1_ (u"ࠫอา่ะหࠣࠫ䋭"),l1l111_l1_ (u"ࠬ࠭䋮")).replace(l1l111_l1_ (u"࠭ศอ๊า๋ࠥ࠭䋯"),l1l111_l1_ (u"ࠧࠨ䋰"))
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䋱"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1lllll1l1_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䋲"))
	l1lllll1_l1_ = l1l1lllll1l1_l1_[0]
	del l1l1lllll1l1_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ䋳"),headers,l1l111_l1_ (u"ࠫࠬ䋴"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䋵"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡰࡷ࠱ࡸ࡯ࡺࡦ࠼ࠣ࠶࠺ࡶࡸ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䋶"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1lllll1l1_l1_: l1l1lllll1l1_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1lllll1l1_l1_:
		if l1l111_l1_ (u"ࠧ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䋷") in l1ll1ll_l1_:
			l1l1llll1l1l_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1llll1l1l_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡤ࡭ࡳ࠭䋸"))
	for l1ll1ll_l1_ in l1l1lllll1l1_l1_:
		if l1l111_l1_ (u"ࠩ࠽࠳࠴ࡼࡢ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࠬ䋹") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䋺"),headers,l1l111_l1_ (u"ࠫࠬ䋻"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䋼"))
			html = html.decode(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡹ࠭࠲࠴࠸࠺ࠬ䋽")).encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䋾"))
			html = html.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䋿"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭䌀"))
			html = html.replace(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌁"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌂"))
			html = html.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡢࡀ࠿࠳ࡩ࡯ࡶ࠿࠾ࡥࡶࠥ࠵࠾࠽ࡦ࡬ࡺࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧࡄࠧ䌃"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䌄"))
			html = html.replace(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡤࡲࡶࡩ࡫ࡲࠣࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠪ䌅"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䌆"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ䌇"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1llll1ll1_l1_,l1ll11l111l1_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠪࠫ䌈")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠰࠭ࡃࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮࠰࠮࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䌉"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䌊") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠪ䌋")+l1l111_l1_ (u"ࠧࠤࠩ䌌")+l1l111_l1_ (u"ࠨ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠪ䌍")+l1l111_l1_ (u"ࠩࠦࠫ䌎")+l1l111_l1_ (u"ࠪ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䌏"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䌐") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࠫ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠨ䌑")+l1l111_l1_ (u"࠭ࠣࠨ䌒")+l1l111_l1_ (u"ࠧ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠩ䌓")+l1l111_l1_ (u"ࠨࠥࠪ䌔")+l1l111_l1_ (u"ࠩ࠶࠷࠸ࠨࠠ࠰ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䌕"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠪࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䌖")
						l1l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁ࠮࠮ࠫࡁࠬ࡬ࡹࡺࡰ࠻࠱࠲ࡹࡵ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࠫࡳࡳࡲࡩ࡯ࡧࡿࡧࡴࡳࠩ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱ࠪ䌗"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠬࡄࠠࠫࠪ࡞ࡢࡁࡄ࡝ࠬࠫࠣ࠮ࡁ࠭䌘"),l1l1llllll11_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"࠭ࠠࠨ䌙").join(title)
						title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䌚"))
						title = title.replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䌛"),l1l111_l1_ (u"ࠩࠣࠫ䌜")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䌝"),l1l111_l1_ (u"ࠫࠥ࠭䌞")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䌟"),l1l111_l1_ (u"࠭ࠠࠨ䌠")).replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䌡"),l1l111_l1_ (u"ࠨࠢࠪ䌢")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䌣"),l1l111_l1_ (u"ࠪࠤࠬ䌤"))
						l1l1llll1ll1_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ืๅ๊ห࠾ࠬ䌥"), l1l1llll1ll1_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1llll1ll1_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠩࠣࠩ䌦"),block,re.DOTALL)
				l1l1llll1l11_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1llll1l11_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡆࡰࡴࡸࡱࠬ䌧"))
				block = block.replace(l1l111_l1_ (u"ࠧแࠩ䌨"),l1l111_l1_ (u"ࠨࠩ䌩"))
				block = block.replace(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠷࠴࠻࠹࠷࠲࠲࠹࠸࠶࠾࠼࠮ࡱࡰࡪࠦࠬ䌪"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭䌫"))
				block = block.replace(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ䌬"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡦࡴࡺࡨࠣࠢࠣࡠࡳࠦࠠࠨ䌭"))
				block = block.replace(l1l111_l1_ (u"࠭ำ๋ำไีฬะࠠศๆอั๊๐ไࠨ䌮"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ䌯"))
				block = block.replace(l1l111_l1_ (u"ࠨำ๋หอ฽ࠠศๆอั๊๐ไࠨ䌰"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࠤࠣࠤࡡࡴࠠࠡࠩ䌱"))
				block = block.replace(l1l111_l1_ (u"ࠪื๏ืแาษอࠤฬ๊ๅีษ๊ำࠬ䌲"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ䌳"))
				block = block.replace(l1l111_l1_ (u"ࠬื่ศสฺࠤฬ๊ๅีษ๊ำࠬ䌴"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡼࡧࡴࡤࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䌵"))
				l1l1lllll111_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࡟ࡨ࠰ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭䌶"),block,re.DOTALL)
				for l1l1lllll1ll_l1_ in l1l1lllll111_l1_:
					type = re.findall(l1l111_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭䌷"),l1l1lllll1ll_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䌸"): type = l1l111_l1_ (u"ࠪࡣࡤ࠭䌹")+type[0]
						else: type = l1l111_l1_ (u"ࠫࠬ䌺")
					items = re.findall(l1l111_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ䌻"),l1l1lllll1ll_l1_,re.DOTALL)
					for l1l1lllll11l_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ䌼"),l1l1lllll11l_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䌽") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1l1l1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ䌾"),headers,l1l111_l1_ (u"ࠩࠪ䌿"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䍀"))
	items = re.findall(l1l111_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䍁"),html,re.DOTALL)
	if items:
		l1ll11111111_l1_ = items[-1]
		l1llll_l1_.append(l1ll11111111_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓ࡯ࡣ࡫࡯ࡩࠬ䍂"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䍃"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ䍄"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ䍅"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ䍆"),l1l111_l1_ (u"ࠪ࠯ࠬ䍇"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䍈"),headers,l1l111_l1_ (u"ࠬ࠭䍉"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䍊"))
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡱࡳࡸ࡮ࡵ࡮࠿ࠩ䍋"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠨࠩ䍌") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠩส่่๊้ࠠสา์๋ࠦแๅฬิࠫ䍍") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ䍎"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠫࠬ䍏")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䍐")+search+l1l111_l1_ (u"࠭ࠦ࡮ࡥࡤࡸࡂ࠭䍑")+category
	l1lll11_l1_(url)
	return
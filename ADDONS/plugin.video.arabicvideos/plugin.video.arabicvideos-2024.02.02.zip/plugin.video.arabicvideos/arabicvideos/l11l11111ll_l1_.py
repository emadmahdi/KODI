# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ儁")
headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ儂") : l1l111_l1_ (u"ࠬ࠭儃") }
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡔࡈ࡚ࡣࠬ億")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11llll1l11l_l1_(url)
	elif mode==215: l1lll_l1_ = l11llll1l1l1_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1llllll1l_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1llllll1l_l1_():
	message = l1l111_l1_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬ儅")
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ儆"),l1l111_l1_ (u"ࠩࠪ儇"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭儈"),l1l111_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠪ儉"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ儊"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭儋"),l1l111_l1_ (u"ࠧࠨ儌"),219,l1l111_l1_ (u"ࠨࠩ儍"),l1l111_l1_ (u"ࠩࠪ儎"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ儏"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ儐")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ儑"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ儒")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ儓"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠨࠩ儔"),headers,l1l111_l1_ (u"ࠩࠪ儕"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ儖"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ儗"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ儘"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ儙")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儚"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ儛")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ儜"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭儝"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ儞"),l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ償")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ儠"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儡"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ儢")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ儣"),headers,l1l111_l1_ (u"ࠪࠫ儤"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ儥"))
	if l1l111_l1_ (u"ࠬ࡭ࡥࡵࡲࡲࡷࡹࡹࠧ儦") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ儧") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡎࡧࡧ࡭ࡦࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭儨"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭儩"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ優"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ儫"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ儬"),l1l111_l1_ (u"้ࠬไ๋สࠪ儭"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ儮"),l1l111_l1_ (u"่ࠧัสๅࠬ儯"),l1l111_l1_ (u"ࠨ็หหึอษࠨ儰"),l1l111_l1_ (u"ࠩ฼ี฻࠭儱"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ儲"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ儳")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ儴") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨ儵"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ儶"))
		if l1l111_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳ࠯ࠨ儷") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ儸"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭儹") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫฬ๊อๅไฬࠫ儺") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ儻"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ儼") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ儽"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ儾"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ儿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭兀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ允"),l1l111_l1_ (u"ࠬ࠭兂"))
			if title!=l1l111_l1_ (u"࠭ࠧ元"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ兄"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ充")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ兆"),headers,l1l111_l1_ (u"ࠪࠫ兇"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ先"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ光"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"࠭ࠧ兊").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭克"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ兌"))
		title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ免") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ兎"))[-1].replace(l1l111_l1_ (u"ࠫ࠲࠭兏"),l1l111_l1_ (u"ࠬࠦࠧ児"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ兑"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ兒"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ兓")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ兔"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭兕"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭兖") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ兗") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭兘"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ兙") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ党"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ兛"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ兜"),headers,l1l111_l1_ (u"ࠫࠬ兝"),l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭兞"))
	if l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ兟") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭兠"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ兡"),headers,l1l111_l1_ (u"ࠩࠪ兢"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ兣"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ兤"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ入"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ兦"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l1111l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ內")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ全")+l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ兩")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ兪")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪࠥࢀࠫࡷࡵࡰࡶ࠾࠭ࠬ八"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ公") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ六"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ兮"),headers,l1l111_l1_ (u"ࠨࠩ兯"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ兰"))
		id = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ共"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l1111l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ兲"):l1l111_l1_ (u"ࠬ࠭关") , l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ兴"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ兵") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ其")+l1l1l1111l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ具"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ典"),l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ兹"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ兺"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ养"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ兼")+name+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ兽")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ兾")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠼ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭兿"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠫࠬ冀")
					items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ冁"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"࠭ࠦࠧࠩ冂") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ冃"))[2].lower() + l1l111_l1_ (u"ࠨࠨࠩࠫ冄")
						server = server.replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ内"),l1l111_l1_ (u"ࠪࠫ円")).replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ冇"),l1l111_l1_ (u"ࠬ࠭冈"))
						server = server.replace(l1l111_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭冉"),l1l111_l1_ (u"ࠧࠨ冊")).replace(l1l111_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ冋"),l1l111_l1_ (u"ࠩࠪ册"))
						server = server.replace(l1l111_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ再"),l1l111_l1_ (u"ࠫࠬ冎")).replace(l1l111_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ冏"),l1l111_l1_ (u"࠭ࠧ冐"))
						server = server.replace(l1l111_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭冑"),l1l111_l1_ (u"ࠨࠩ冒")).replace(l1l111_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ冓"),l1l111_l1_ (u"ࠪࠫ冔"))
						server = server.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ冕"),l1l111_l1_ (u"ࠬ࠭冖"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ冗") + name + server + l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ冘")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ写"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ冚"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ军"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭农"),l1l111_l1_ (u"ࠬ࠱ࠧ冝"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ冞")+search
	l1lll11_l1_(url)
	return
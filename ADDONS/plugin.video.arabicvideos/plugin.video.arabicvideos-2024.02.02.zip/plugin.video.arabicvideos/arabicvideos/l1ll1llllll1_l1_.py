# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ嬇")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嬈"):l1l111_l1_ (u"ࠩࠪ嬉")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡜ࡉࡍࡠࠩ嬊")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ嬋"),l1l111_l1_ (u"ࠬࡽࡷࡦࠩ嬌")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭嬍")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ嬎")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬏"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ嬐"),l111l1_l1_,569,l1l111_l1_ (u"ࠪࠫ嬑"),l1l111_l1_ (u"ࠫࠬ嬒"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ嬓"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嬔"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ嬕"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ嬖"),564)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬗"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭嬘"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ嬙"),565)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嬚"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嬛"),l1l111_l1_ (u"ࠧࠨ嬜"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嬝"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ嬞"),l1l111_l1_ (u"ࠪࠫ嬟"),l1l111_l1_ (u"ࠫࠬ嬠"),l1l111_l1_ (u"ࠬ࠭嬡"),l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ嬢"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ嬣"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嬤"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠩࠪ嬥"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嬦"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嬧")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嬨"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嬩"),l1l111_l1_ (u"ࠧࠨ嬪"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ嬫"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ嬬"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嬭"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嬮")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嬯"),url,l1l111_l1_ (u"࠭ࠧ嬰"),l1l111_l1_ (u"ࠧࠨ嬱"),l1l111_l1_ (u"ࠨࠩ嬲"),l1l111_l1_ (u"ࠩࠪ嬳"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嬴"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠫ嬵") in html:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬶"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ嬷"),url,561,l1l111_l1_ (u"ࠧࠨ嬸"),l1l111_l1_ (u"ࠨࠩ嬹"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嬺"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴ࠮࠯ࡗࡥࡧࡹࡵࡪࠤࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ嬻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嬼"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬽"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1llll1lll11_l1_,type=l1l111_l1_ (u"࠭ࠧ嬾")):
	if l1l111_l1_ (u"ࠧ࠻࠼ࠪ嬿") in l1llll1lll11_l1_:
		l1llllll_l1_,url = l1llll1lll11_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ孀"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭孁"))
		url = server+url
	else: url,l1llllll_l1_ = l1llll1lll11_l1_,l1llll1lll11_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ孂"),url,l1l111_l1_ (u"ࠫࠬ孃"),l1l111_l1_ (u"ࠬ࠭孄"),l1l111_l1_ (u"࠭ࠧ孅"),l1l111_l1_ (u"ࠧࠨ孆"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ孇"))
	html = response.content
	if type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ孈"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ孉"),html,re.DOTALL)
	elif type in [l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ孊"),l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ孋")]:
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ孌"),l1l111_l1_ (u"ࠧ࠰ࠩ孍")).replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ孎"),l1l111_l1_ (u"ࠩࠥࠫ孏"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡓ࡫ࡪ࡬ࡹ࡛ࡉࠣࠩ子"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࡚ࠫࠧࡨࡶ࡯ࡥ࠱࠲ࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ孑"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭孒"),l1l111_l1_ (u"࠭ࠧ孓"))
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ孔") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ孕"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠩะ่็ฯࠧ孖") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭字"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ存") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孙"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ孚"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ孛"):
			l111l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭孜"),block,re.DOTALL)
			if l111l1llll_l1_:
				count = l111l1llll_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ孝")+count
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孞"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ孟"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠬ࠭孠"),l1l111_l1_ (u"࠭ࠧ孡"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ孢"))
		elif type==l1l111_l1_ (u"ࠨࠩ季"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ孤"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ孥"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ学")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孧"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ孨")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ孩"),url,l1l111_l1_ (u"ࠨࠩ孪"),l1l111_l1_ (u"ࠩࠪ孫"),l1l111_l1_ (u"ࠪࠫ孬"),l1l111_l1_ (u"ࠫࠬ孭"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ孮"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ孯"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ孰"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ孱"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠩࠪ孲"),l1l111_l1_ (u"ࠪࠫ孳"),l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭孴"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࡷࡃ࠭孵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡳ࡭ࡸࡵࡤࡦࡖ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠧ孶"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ孷"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ學"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ孹"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ孺"),l1l111_l1_ (u"ࠫࠬ孻")).replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭孼"),l1l111_l1_ (u"࠭ࠧ孽"))
		else: title = l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ孾")
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ孿"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭宀"),url,l1l111_l1_ (u"ࠪࠫ宁"),l1l111_l1_ (u"ࠫࠬ宂"),l1l111_l1_ (u"ࠬ࠭它"),l1l111_l1_ (u"࠭ࠧ宄"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ宅"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ宆"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ宇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ守"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ安") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ู๊ࠬาใิࠤํ๐ࠠิ์่หࠬ宊"): name = l1l111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭宋")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ完")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ宍")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ宎"),l1l111_l1_ (u"ࠪࠫ宏")).replace(l1l111_l1_ (u"ࠫࡡࡸࠧ宐"),l1l111_l1_ (u"ࠬ࠭宑"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡵࡷ࠱࠲ࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ宒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ宓"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭宔") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ宕"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ宖")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠬ宗")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡽࡥࡤ࡫ࡰࡥࠬ官")+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ宙")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ定"),l1l111_l1_ (u"ࠨࠩ宛")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ宜"),l1l111_l1_ (u"ࠪࠫ宝"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ实"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠬ࠭実")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ宠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ审"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ客"),l1l111_l1_ (u"ࠩ࠮ࠫ宣"))
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ室")+search
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ宥"))
	return
def l1l1ll1l_l1_(l1llll1lll11_l1_,filter):
	if l1l111_l1_ (u"ࠬࡅ࠿ࠨ宦") in l1llll1lll11_l1_: url = l1llll1lll11_l1_.split(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ宧"))[0]
	else: url = l1llll1lll11_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ宨"),l1l111_l1_ (u"ࠨࠩ宩"))
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭宪"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ宫"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ宬"),l1l111_l1_ (u"ࠬ࠭宭")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ宮"))
	if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ宯"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ宰") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠩࡀࡁࠬ宱") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭宲")+category+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ害")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ宴")+category+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ宵")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ家"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ宷")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ宸"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭容"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ宺")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭宻"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ宼"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ宽"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ宾"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ宿"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ寀")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll11_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寁"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ寂"),l1111111_l1_,561,l1l111_l1_ (u"࠭ࠧ寃"),l1l111_l1_ (u"ࠧࠨ寄"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ寅"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ密"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ寇")+l11l1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ寈"),l1111111_l1_,561,l1l111_l1_ (u"ࠬ࠭寉"),l1l111_l1_ (u"࠭ࠧ寊"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ寋"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭富"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ寍"),l1l111_l1_ (u"ࠪࠫ寎"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ寏"),url,l1l111_l1_ (u"ࠬ࠭寐"),l1l111_l1_ (u"࠭ࠧ寑"),l1l111_l1_ (u"ࠧࠨ寒"),l1l111_l1_ (u"ࠨࠩ寓"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ寔"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ寕"),l1l111_l1_ (u"ࠫࠧ࠭寖")).replace(l1l111_l1_ (u"ࠬࡢ࡜࠰ࠩ寗"),l1l111_l1_ (u"࠭࠯ࠨ寘"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ寙"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭寚"),block+l1l111_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭寛"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ寜") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭寝"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠬࡃ࠽ࠨ寞") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ察"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ寠")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1llll1lll11_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ寡"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩ寢"),l1111111_l1_,561,l1l111_l1_ (u"ࠪࠫ寣"),l1l111_l1_ (u"ࠫࠬ寤"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭寥"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭實"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ寧"),l1lllll1_l1_,564,l1l111_l1_ (u"ࠨࠩ寨"),l1l111_l1_ (u"ࠩࠪ審"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ寪"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ寫")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ寬")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ寭")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ寮")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ寯")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寰"),l1lllll_l1_+name+l1l111_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ寱"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠫࠬ寲"),l1l111_l1_ (u"ࠬ࠭寳"),l1l111l1_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ寴"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠧࡳࠩ寵") or value==l1l111_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ寶"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ寷") in option: continue
			if l1l111_l1_ (u"ࠪห้้ไࠨ寸") in option: continue
			if l1l111_l1_ (u"ࠫࡳ࠳ࡡࠨ对") in value: continue
			if option==l1l111_l1_ (u"ࠬ࠭寺"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ寻"),option,re.DOTALL)
			if l1ll1l11l1l_l1_: l1l11l1ll_l1_ = l1ll1l11l1l_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠧ࠻ࠢࠪ导")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ寽")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁࠬ対")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭寿")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃࠧ尀")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ封")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ専"):
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ尃"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"ࠨࠩ射"),l1l111_l1_ (u"ࠩࠪ尅"),l1l1l11l_l1_+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ将"))
			elif type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ將") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ專") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ尉"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭尊")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1llll1lll11_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尋"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠩࠪ尌"),l1l111_l1_ (u"ࠪࠫ對"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ導"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ小"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"࠭ࠧ尐"),l1l111_l1_ (u"ࠧࠨ少"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ尒"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ尓"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ尔")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠫࡲࡶࡡࡢࠩ尕"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ尖"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ尗"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ尘"),l1l111_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩ尙"),l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ尚"),l1l111_l1_ (u"ࠪࡲࡦࡺࡩࡰࡰࠪ尛"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭尜")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ尝") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭尞"),l1l111_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࠨ尟"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ尠"),l1l111_l1_ (u"ࠩ࠽࠾࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࠴࠭尡"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࡁࡂ࠭尢"),l1l111_l1_ (u"ࠫ࠴࠭尣"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬࠬࠦࠨ尤"),l1l111_l1_ (u"࠭࠯ࠨ尥"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ尦"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠨࠩ尧")
	if l1l111_l1_ (u"ࠩࡀࡁࠬ尨") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠫ࠭尩"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂࡃࠧ尪"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ尫")
		if l1l111_l1_ (u"࠭ࠥࠨ尬") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ尭") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ尮"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭尯")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭尰") and value!=l1l111_l1_ (u"ࠫ࠵࠭就"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ尲")+key+l1l111_l1_ (u"࠭࠽࠾ࠩ尳")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ尴"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ尵")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ尶")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ尷"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫࠬࠧ尸"))
	return l1l1l111_l1_
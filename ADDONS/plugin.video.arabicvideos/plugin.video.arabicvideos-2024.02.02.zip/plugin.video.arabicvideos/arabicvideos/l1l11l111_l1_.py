# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨຄ")
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ຅"):l1l1ll11l_l1_()}
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡄࡖࡘࡥࠧຆ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫງ"),l1l111_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศํࠪຈ"),l1l111_l1_ (u"๊ࠫ฻วา฻๊ࠫຉ"),l1l111_l1_ (u"ࠬอูๅ่้ࠣ฾์วࠡ⠕ࠣࡊࡴࡸࠠࡢࡦࡶࠫຊ"),l1l111_l1_ (u"࠭ๅ้สส๎้อสࠨ຋"),l1l111_l1_ (u"ࠧษำส้ัࠦใๆสํ์ฯืࠧຌ"),l1l111_l1_ (u"ࠨษ็฽ฬฮࠠไ็ห๎ํะัࠨຍ"),l1l111_l1_ (u"ࠩสื้อๅ๋ษอࠫຎ"),l1l111_l1_ (u"ࠪหำื้ࠨຏ"),l1l111_l1_ (u"ࠫฬ่ำศ็ࠣหำื๊ࠨຐ"),l1l111_l1_ (u"ࠬอิหำส็ฬะࠧຑ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==250: l1lll_l1_ = l1l1l11_l1_()
	elif mode==251: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==252: l1lll_l1_ = PLAY(url)
	elif mode==253: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==254: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ຒ")+text)
	elif mode==255: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫຓ")+text)
	elif mode==256: l1lll_l1_ = l11ll1_l1_(url,text)
	elif mode==259: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬດ"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡦ࡯࡮ࠨຕ"),l1l111_l1_ (u"ࠪࠫຖ"),headers,l1l111_l1_ (u"ࠫࠬທ"),l1l111_l1_ (u"ࠬ࠭ຘ"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪນ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧບ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨປ"),l1l111_l1_ (u"ࠩࠪຜ"),259,l1l111_l1_ (u"ࠪࠫຝ"),l1l111_l1_ (u"ࠫࠬພ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩຟ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ຠ"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪມ"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ฬิั๊ࠩຢ"),254)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩຣ"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭຤"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬລ"),255)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ຦"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨວ"),l1l111_l1_ (u"ࠧࠨຨ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨຩ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪສ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩຫ"),251,l1l111_l1_ (u"ࠫࠬຬ"),l1l111_l1_ (u"ࠬ࠭ອ"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡤ࡭ࡳ࠭ຮ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຯ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪະ")+l1lllll_l1_+l1l111_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨັ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩາ"),251,l1l111_l1_ (u"ࠫࠬຳ"),l1l111_l1_ (u"ࠬ࠭ິ"),l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪີ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຶ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪື")+l1lllll_l1_+l1l111_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨຸ"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ູࠩ"),251,l1l111_l1_ (u"຺ࠫࠬ"),l1l111_l1_ (u"ࠬ࠭ົ"),l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬຼ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຽ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ຾")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัว์ࠩ຿"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡱࡧࡴࡦࡵࡷࠫເ"),251,l1l111_l1_ (u"ࠫࠬແ"),l1l111_l1_ (u"ࠬ࠭ໂ"),l1l111_l1_ (u"࠭࡬ࡢࡵࡷࡩࡸࡺࠧໃ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬໄ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ໅"),l1l111_l1_ (u"ࠩࠪໆ"),9999)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡪࡴࡵࡉࡧࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ໇"),html,re.DOTALL)
	l1l1l1l_l1_ = l11ll11_l1_[0]
	l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ່࠭"),l1l1l1l_l1_,re.DOTALL)
	for l1ll1ll_l1_,title in l1l1111_l1_:
		title = unescapeHTML(title)
		if title not in l11lll_l1_ and title!=l1l111_l1_ (u"້ࠬ࠭"):
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳ໊ࠫ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ໋ࠧ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ໌")+l1lllll_l1_+title,l1ll1ll_l1_,256)
	return html
def l11ll1_l1_(url,type):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ໍ"),url,l1l111_l1_ (u"ࠪࠫ໎"),headers,l1l111_l1_ (u"ࠫࠬ໏"),l1l111_l1_ (u"ࠬ࠭໐"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭໑"))
	html = response.content
	if l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠩ໒") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໓"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ศ้หาุ่ࠢฬํฯสࠩ໔"),url,251,l1l111_l1_ (u"ࠪࠫ໕"),l1l111_l1_ (u"ࠫࠬ໖"),l1l111_l1_ (u"ࠬࡳ࡯ࡴࡶࠪ໗"))
	if l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡢ࡫ࡱࡗࡱ࡯ࡤࡦࡵࠪ໘") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໙"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ໚"),url,251,l1l111_l1_ (u"ࠩࠪ໛"),l1l111_l1_ (u"ࠪࠫໜ"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ໝ"))
	if l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩ࡯࡭ࡶࡐ࡮ࡹࡴࠨໞ") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬໟ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			if len(l11llll_l1_)>1 and type==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭໠"): block = l11llll_l1_[1]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ໡"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ໢"),title,re.DOTALL)
				try: l1l11ll11_l1_ = l1lllllll_l1_[0][0]
				except: l1l11ll11_l1_ = l1l111_l1_ (u"ࠪࠫ໣")
				try: l1l11ll1l_l1_ = l1lllllll_l1_[0][1]
				except: l1l11ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ໤")
				l1lllllll_l1_ = l1l11ll11_l1_+l1l11ll1l_l1_
				l1lllllll_l1_ = l1lllllll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ໥"),l1l111_l1_ (u"࠭ࠧ໦"))
				if l1l111_l1_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠩ໧") in title:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ໨"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if not l1lllllll_l1_:
					l1l11l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ໩"),title,re.DOTALL)
					if l1l11l1l1_l1_: l1lllllll_l1_ = l1l11l1l1_l1_[0]
				if l1lllllll_l1_:
					if l1l111_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ໪") in l1ll1ll_l1_: type = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ໫"))[1]
					else: type = l1l111_l1_ (u"ࠬࡴࡥࡸࡧࡶࡸࠬ໬")
					l1lllllll_l1_ = l1lllllll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ໭"))
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໮"),l1lllll_l1_+l1lllllll_l1_,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠨࠩ໯"),l1l111_l1_ (u"ࠩࠪ໰"),type)
	return
def l1lll11_l1_(url,type):
	method,data,items = l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ໱"),l1l111_l1_ (u"ࠫࠬ໲"),[]
	if type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭໳"):
		if l1l111_l1_ (u"࠭࠿ࠨ໴") in url:
			l1l11lll1_l1_,l1l11llll_l1_ = l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ໵"),{}
			l1lllll1_l1_,l1l1l1111_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࠪ໶"))
			lines = l1l1l1111_l1_.split(l1l111_l1_ (u"ࠩࠩࠫ໷"))
			for line in lines:
				key,value = line.split(l1l111_l1_ (u"ࠪࡁࠬ໸"))
				l1l11llll_l1_[key] = value
			if lines: method,url,data = l1l11lll1_l1_,l1lllll1_l1_,l1l11llll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,method,url,data,headers,l1l111_l1_ (u"ࠫࠬ໹"),l1l111_l1_ (u"ࠬ࠭໺"),l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ໻"))
	html = response.content
	if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ໼"): l11llll_l1_ = [html]
	elif l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ໽") in type: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭໾"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ໿"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫัี๊ะࠢส่ฬ็ไศ็࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫༀ"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ༁"): l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭༂"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧ࡮ࡱࡶࡸࠬ༃"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪ༄"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡅࡰࡴࡩ࡫ࡴ࠯ࡘࡐࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡅࡧࡵࡅ࡭ࡕࡨࡩࡩࠨࠧ༅"),html,re.DOTALL)
	if l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ༆") in type:
		block = l11llll_l1_[0]
		zz = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡰࡦࢀࡹ࠯ࠬࡂࠤ࠭ࡹࡲࡤࡾࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ༇"),block,re.DOTALL)
		if zz:
			l1llll_l1_,l1l1lll1_l1_,l1l1l1l1l_l1_,l1l1ll1ll_l1_ = zip(*zz)
			items = zip(l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_)
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࡇࡲࡦࡣ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳࡜ࡸࡽ࠶࠰࠺ࢃ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ༈"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"࠭ࡗࡘࡇࠪ༉") in title: continue
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠧศๆะ่็ฯࠧ༊") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ་"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ༌") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ།"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ༎"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ༏") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭ๅิๆึ่ࠬ༐") in title:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ༑"),l1lllll_l1_+title,l1ll1ll_l1_,253,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ༒"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	if type in [l1l111_l1_ (u"ࠩࡱࡩࡼ࡫ࡳࡵࠩ༓"),l1l111_l1_ (u"ࠪࡦࡪࡹࡴࠨ༔"),l1l111_l1_ (u"ࠫࡲࡵࡳࡵࠩ༕")]:
		items = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨࡧ࠰ࡲࡺࡳࡢࡦࡴࡶࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ༖"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༗"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอ༘ࠥ࠭")+title,l1ll1ll_l1_,251,l1l111_l1_ (u"ࠨ༙ࠩ"),l1l111_l1_ (u"ࠩࠪ༚"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ༛"),url,l1l111_l1_ (u"ࠫࠬ༜"),headers,l1l111_l1_ (u"ࠬ࠭༝"),l1l111_l1_ (u"࠭ࠧ༞"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ༟"))
	html = response.content
	html = html[10000:]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༠"),html,re.DOTALL)
	if not items: return
	l1ll1l_l1_,name = items[0]
	if l1l111_l1_ (u"ࠩส่า๊โสࠩ༡") in name: name = name.split(l1l111_l1_ (u"ࠪห้ำไใหࠪ༢"))[0].strip(l1l111_l1_ (u"ࠫࠥ࠭༣"))
	elif l1l111_l1_ (u"ࠬำไใหࠪ༤") in name: name = name.split(l1l111_l1_ (u"࠭อๅไฬࠫ༥"))[0].strip(l1l111_l1_ (u"ࠧࠡࠩ༦"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵࡉࡵ࡯ࡳࡰࡦࡨࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ༧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ༨"),block,re.DOTALL)
		for l1ll1ll_l1_,l1l1lll_l1_ in items:
			title = name+l1l111_l1_ (u"ࠪࠤ࠲ࠦวๅฯ็ๆฮࠦัใ็ࠣࠫ༩")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ༪"),l1lllll_l1_+title,l1ll1ll_l1_,252,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ༫"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ༬"),url,252,l1ll1l_l1_)
	return
def l1l111lll_l1_(title,l1ll1ll_l1_):
	l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡜ࡣ࠰ࡾࡆ࠳࡚࠮࡟࠮ࠫ༭"),title,re.DOTALL)
	if l1lllllll_l1_: title = l1lllllll_l1_[0]
	else: title = title+l1l111_l1_ (u"ࠨࠢࠪ༮")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ༯"))
	title = title.replace(l1l111_l1_ (u"ࠪ฽ึฮࠠิ์าࠫ༰"),l1l111_l1_ (u"ࠫࠬ༱")).replace(l1l111_l1_ (u"๋ࠬศศึิࠫ༲"),l1l111_l1_ (u"࠭ࠧ༳")).replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ༴"),l1l111_l1_ (u"ࠨ༵ࠩ"))
	title = title.replace(l1l111_l1_ (u"ࠩ๐ࠫ༶"),l1l111_l1_ (u"༷ࠪࠫ"))
	title = title.replace(l1l111_l1_ (u"ࠫࠥࠦࠧ༸"),l1l111_l1_ (u"༹ࠬࠦࠧ")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ༺"),l1l111_l1_ (u"ࠧࠡࠩ༻"))
	return title
def PLAY(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ༼"),url,l1l111_l1_ (u"ࠩࠪ༽"),headers,l1l111_l1_ (u"ࠪࠫ༾"),l1l111_l1_ (u"ࠫࠬ༿"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩཀ"))
	html = response.content
	l1lllll1_l1_ = response.url
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪཁ"))
	headers[l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨག")] = server+l1l111_l1_ (u"ࠨ࠱ࠪགྷ")
	l1l111ll1_l1_,l1l1l11ll_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪང"),l1l111_l1_ (u"ࠪࠫཅ"),[]
	l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡅࡹࡹࡺ࡯࡯ࡵࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡷࡢࡶࡦ࡬࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠭ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࠫࡁࠬࠦࠬཆ"),html,re.DOTALL)
	if l1l1ll1l1_l1_: l1l111ll1_l1_,l1l1l1lll_l1_,l1l1l11ll_l1_,l1l1l1ll1_l1_ = l1l1ll1l1_l1_[0]
	else:
		l1l1ll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡆࡺࡺࡴࡰࡰࡶࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ཇ"),html,re.DOTALL)
		if l1l1ll1l1_l1_:
			l1ll1ll_l1_,l1l1l1lll_l1_ = l1l1ll1l1_l1_[0]
			if l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ཈") in l1l1l1lll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			else: l1l1l11ll_l1_ = l1ll1ll_l1_
	if l1l111ll1_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫཉ"),l1l111ll1_l1_,l1l111_l1_ (u"ࠨࠩཊ"),headers,l1l111_l1_ (u"ࠩࠪཋ"),l1l111_l1_ (u"ࠪࠫཌ"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨཌྷ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡩࡷࡇࡲࡦࡣࠥࠬ࠳࠰࠿࠽࠱ࡸࡰࡃ࠯ࠧཎ"),html,re.DOTALL)
		if l11llll_l1_:
			l1l111l11_l1_ = l11llll_l1_[0]
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬཏ"),l1l111_l1_ (u"ࠧ࠽ࡪ࠶ࡂࠬཐ"))
			l1l111l11_l1_ = l1l111l11_l1_.replace(l1l111_l1_ (u"ࠨ࠾࡫࠷ࡃ࠭ད"),l1l111_l1_ (u"ࠩ࠿࡬࠸ࡄ࠼ࡩ࠵ࡁࠫདྷ"))
			l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠹࠾࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼ࡩ࠵ࡁࠫན"),l1l111l11_l1_,re.DOTALL)
			if not l1lll1l1_l1_: l1lll1l1_l1_ = [(l1l111_l1_ (u"ࠫࠬཔ"),l1l111l11_l1_)]
			for l111l1ll_l1_,block in l1lll1l1_l1_:
				if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪཕ")+l111l1ll_l1_
				items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪབ"),block,re.DOTALL)
				for l1ll1ll_l1_,name in items:
					if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬབྷ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧམ")+l1ll1ll_l1_
					l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪཙ")+name+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫཚ")+l111l1ll_l1_
					l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࡉࡧࡴࡤࡱࡪࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬཛ"),html,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࡊࡨࡵࡥࡲ࡫ࠢ࠯ࠬࡂࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡎࡅࡊࡉࡋࡘࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ཛྷ"),html,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_,l111l1ll_l1_ = l1ll_l1_[0]
			name = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫཝ"))
			if l1l111_l1_ (u"ࠧࠦࠩཞ") in l111l1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩཟ")+name+l1l111_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࡢࡣࠬའ")
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫཡ")+name+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࡤࡥ࡟ࡠࠩར")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	if l1l1l11ll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩལ"),l1l1l11ll_l1_,l1l111_l1_ (u"࠭ࠧཤ"),headers,l1l111_l1_ (u"ࠧࠨཥ"),l1l111_l1_ (u"ࠨࠩས"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ཧ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࡧࡷࡱࡧࡹ࡯࡯࡯ࠩཨ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫཀྵ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
				if not l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡸࡺࡡࡵ࡫ࡲࡲࠬཪ") in l1ll1ll_l1_: continue
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧཫ")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨཬ")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	l1l11l11l_l1_ = str(l1llll_l1_)
	l111ll1l_l1_ = [l1l111_l1_ (u"ࠨ࠰ࡽ࡭ࡵࡅࠧ཭"),l1l111_l1_ (u"ࠩ࠱ࡶࡦࡸ࠿ࠨ཮"),l1l111_l1_ (u"ࠪ࠲ࡹࡾࡴࡀࠩ཯"),l1l111_l1_ (u"ࠫ࠳ࡶࡤࡧࡁࠪ཰"),l1l111_l1_ (u"ࠬ࠴ࡴࡢࡴࡂཱࠫ"),l1l111_l1_ (u"࠭࠮ࡪࡵࡲࡃིࠬ"),l1l111_l1_ (u"ࠧ࠯ࡼ࡬ࡴ࠳ཱི࠭"),l1l111_l1_ (u"ࠨ࠰ࡵࡥࡷ࠴ུࠧ"),l1l111_l1_ (u"ࠩ࠱ࡸࡽࡺ࠮ࠨཱུ"),l1l111_l1_ (u"ࠪ࠲ࡵࡪࡦ࠯ࠩྲྀ"),l1l111_l1_ (u"ࠫ࠳ࡺࡡࡳ࠰ࠪཷ"),l1l111_l1_ (u"ࠬ࠴ࡩࡴࡱ࠱ࠫླྀ")]
	if any(value in l1l11l11l_l1_ for value in l111ll1l_l1_):
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧཹ"),l1l111_l1_ (u"ࠧࠨེ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯཻࠫ"),l1l111_l1_ (u"ࠩฯีอࠦัศสฺࠤ๊ิสๅใ่ࠣศ์่ࠠาสࠤฬ๊ัศสฺࠤ้๐ำࠡ็้ࠤ๋๎ูࠡษ็ีํอศุࠢส่ฯ๐ࠠโ์๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦไฤ่๋ࠣีอࠠศๆ่์็฿ࠠโ์๊ࠤำีๅศฬࠣวำื้ࠡ฼ํี๋ࠥไโษอࠤฬ๊แ๋ัํ์ོࠬ"))
		return
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰཽࠩ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ཾ"),l1l111_l1_ (u"ࠬ࠱ࠧཿ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧ࡫ࡱࡨ࠴ࡅࡦࡪࡰࡧࡁྀࠬ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ཱྀࠧ"))
	return
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࡂࠫྂ") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨྃ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥ྄ࠧ"),1)
	if filter==l1l111_l1_ (u"ࠫࠬ྅"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭྆"),l1l111_l1_ (u"࠭ࠧ྇")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫྈ"))
	if type==l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬྉ"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠩࡀࡁࠬྊ") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠪࡁࡂ࠭ྋ") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧྌ")+category+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩྍ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩྎ")+category+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫྏ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫྐ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ྑ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭ྒ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧྒྷ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫྔ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧྕ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩྖ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠨࠩྗ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ྘"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠪࠫྙ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪྚ")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬྛ"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩྜ"),l1111111_l1_,251,l1l111_l1_ (u"ࠧࠨྜྷ"),l1l111_l1_ (u"ࠨࠩྞ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪྟ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྠ"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫྡ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫྡྷ"),l1111111_l1_,251,l1l111_l1_ (u"࠭ࠧྣ"),l1l111_l1_ (u"ࠧࠨྤ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩྥ"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧྦ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬྦྷ"),l1l111_l1_ (u"ࠫࠬྨ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪྩ"),url,l1l111_l1_ (u"࠭ࠧྪ"),headers,l1l111_l1_ (u"ࠧࠨྫ"),l1l111_l1_ (u"ࠨࠩྫྷ"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧྭ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡘࡦࡾࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡨࡶࡲࡈࡔࡏࡵࠥࠫྮ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l1l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀ࡙ࠦࡧࡸࡑࡣࡪࡩࡋ࡯࡬ࡵࡧࡵࡍࡹ࡫࡭ࠣ࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ྯ"),block,re.DOTALL)
	l1l1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡘࡡࡵ࡫ࡱ࡫ࡋ࡯࡬ࡵࡧࡵࠦ࠳࠰࠿࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾࠯ࠬࡂࠬࡁࡻ࡬࠿ࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ྰ"),block,re.DOTALL)
	l1l11l1l_l1_ = l1l1l1l11_l1_+l1l1l111l_l1_
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧྱ"),block,re.DOTALL)
		if name==l1l111_l1_ (u"ࠧศะิํࠬྲ"): name = l1l111_l1_ (u"ࠨษ็ห็ูวๆࠩླ")
		if not items:
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩྴ"),block,re.DOTALL)
			items = []
			for option,value in l1l1111_l1_: items.append([option,l1l111_l1_ (u"ࠪࠫྵ"),value])
			l1l111ll_l1_ = l1l111_l1_ (u"ࠫࡷࡧࡴࡦࠩྶ")
			name = l1l111_l1_ (u"ࠬอไหไํ๎๊࠭ྷ")
		else: l1l111ll_l1_ = items[0][1]
		if l1l111_l1_ (u"࠭࠽࠾ࠩྸ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫྐྵ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨྺ")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྻ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫྼ"),l1111111_l1_,251,l1l111_l1_ (u"ࠫࠬ྽"),l1l111_l1_ (u"ࠬ࠭྾"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ྿"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿀"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ࿁"),l1lllll1_l1_,254,l1l111_l1_ (u"ࠩࠪ࿂"),l1l111_l1_ (u"ࠪࠫ࿃"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ࿄"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ࿅")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾࠲࿆ࠪ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ࿇")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ࿈")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭࿉")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿊"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭࿋")+name,l1lllll1_l1_,255,l1l111_l1_ (u"ࠬ࠭࿌"),l1l111_l1_ (u"࠭ࠧ࿍"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for option,dummy,value in items:
			if option in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠧศๆๆ่ࠬ࿎") in option: continue
			option = unescapeHTML(option)
			l1l11l1ll_l1_,l1lllllll_l1_ = option,option
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠨ࠼ࠣࠫ࿏")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ࿐")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠭࿑")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ࿒")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨ࿓")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ࿔")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ࿕"):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿖"),l1lllll_l1_+l1lllllll_l1_,url,255,l1l111_l1_ (u"ࠩࠪ࿗"),l1l111_l1_ (u"ࠪࠫ࿘"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ࿙") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ࿚") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ࿛"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭࿜")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿝"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,251,l1l111_l1_ (u"ࠩࠪ࿞"),l1l111_l1_ (u"ࠪࠫ࿟"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ࿠"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿡"),l1lllll_l1_+l1lllllll_l1_,url,254,l1l111_l1_ (u"࠭ࠧ࿢"),l1l111_l1_ (u"ࠧࠨ࿣"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ࿤"),l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ࿥"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ࿦")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭࿧"),l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭࿨"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ࿩"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭࿪"),l1l111_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ࿫"),l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ࿬"),l1l111_l1_ (u"ࠪࡶࡦࡺࡥࠨ࿭")]
def l1l1l11l1_l1_(url):
	l1l111l1l_l1_ = l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈࡰࡸ࡮ࡡࡪ࡭࡫࠶࠵࠸࠱࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ࿮")
	url = url.replace(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࠩ࿯"),l1l111l1l_l1_)
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สาึ๏ࠧ࿰"),l1l111_l1_ (u"ࠧࠨ࿱"))
	if l1l111l1l_l1_ not in url: url = url+l1l111l1l_l1_
	url = url.replace(l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ࿲"),l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ࿳"))
	url = url.replace(l1l111_l1_ (u"ࠪࡃࡄ࠭࿴"),l1l111_l1_ (u"ࠫࡄ࠭࿵"))
	url = url.replace(l1l111_l1_ (u"ࠬࠬࠦࠨ࿶"),l1l111_l1_ (u"࠭ࠦࠨ࿷"))
	url = url.replace(l1l111_l1_ (u"ࠧ࠾࠿ࠪ࿸"),l1l111_l1_ (u"ࠨ࠿ࠪ࿹"))
	return url
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ࿺"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠪࠫ࿻")
	if l1l111_l1_ (u"ࠫࡂࡃࠧ࿼") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠦࠨ࿽"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽࠾ࠩ࿾"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ࿿")
		if l1l111_l1_ (u"ࠨࠧࠪက") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫခ") and value!=l1l111_l1_ (u"ࠪ࠴ࠬဂ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨဃ")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨင") and value!=l1l111_l1_ (u"࠭࠰ࠨစ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪဆ")+key+l1l111_l1_ (u"ࠨ࠿ࡀࠫဇ")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱ࠭ဈ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭ဉ")+key+l1l111_l1_ (u"ࠫࡂࡃࠧည")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩဋ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩဌ"))
	return l1l1l111_l1_
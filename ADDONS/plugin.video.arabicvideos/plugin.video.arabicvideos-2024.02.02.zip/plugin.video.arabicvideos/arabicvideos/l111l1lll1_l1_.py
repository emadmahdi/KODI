# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ⋈")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡈࡆ࠹ࡥࠧ⋉")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส๎ั๐ࠠษีอࠫ⋊"),l1l111_l1_ (u"ࠪหฯ฻ไࠡส้หࠬ⋋"),l1l111_l1_ (u"ࠫฬ๐ฬ๋ࠢหืฯࠦวๅษุ่๏࠭⋌"),l1l111_l1_ (u"ࠬอ๊อ์ࠣฬุะࠠศๆฯำ๏ีࠧ⋍"),l1l111_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็ฬิ๐ไࠨ⋎"),l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ⋏"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอูสࠨ⋐")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==800: l1lll_l1_ = l1l1l11_l1_()
	elif mode==801: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==802: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==803: l1lll_l1_ = PLAY(url)
	elif mode==804: l1lll_l1_ = l111ll11l1_l1_(url)
	elif mode==806: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==809: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⋑"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⋒"),l1l111_l1_ (u"ࠫࠬ⋓"),809,l1l111_l1_ (u"ࠬ࠭⋔"),l1l111_l1_ (u"࠭ࠧ⋕"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⋖"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋗"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠧ⋘"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭⋙"),804,l1l111_l1_ (u"ࠫࠬ⋚"),l1l111_l1_ (u"ࠬ࠭⋛"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⋜"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⋝"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⋞"),l1l111_l1_ (u"ࠩࠪ⋟"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⋠"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ⋡"),l1l111_l1_ (u"ࠬ࠭⋢"),l1l111_l1_ (u"࠭ࠧ⋣"),l1l111_l1_ (u"ࠧࠨ⋤"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⋥"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡻ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⋦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⋧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⋨"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⋩") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋪"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⋫")+l1lllll_l1_+title,l1ll1ll_l1_,801)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⋬"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⋭"),l1l111_l1_ (u"ࠪࠫ⋮"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸ࠾ࠨ⋯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡗ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⋰"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ⋱"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ⋲") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋳"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⋴")+l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠪࠫ⋵"),l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࡯ࡨࡲࡺ࠭⋶"))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⋷"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⋸"),l1l111_l1_ (u"ࠧࠨ⋹"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⋺"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⋻"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⋼"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⋽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⋾"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⋿")+l1lllll_l1_+title,l1ll1ll_l1_,801)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⌀")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⌁"),url,l1l111_l1_ (u"ࠩࠪ⌂"),l1l111_l1_ (u"ࠪࠫ⌃"),l1l111_l1_ (u"ࠫࠬ⌄"),l1l111_l1_ (u"ࠬ࠭⌅"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⌆"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠨ⌇"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠨࠩ⌈"),l1l111_l1_ (u"ࠩࠪ⌉"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠪั้่วหࠩ⌊") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๊ࠫ๎วิ็ࠪ⌋") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⌌"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⌍"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⌎"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⌏"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⌐"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⌑"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⌒"),l1lllll_l1_+title,l1ll1ll_l1_,803)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭⌓")):
	limit,start,l1l1l1ll1_l1_,select,l111ll111l_l1_ = 0,0,l1l111_l1_ (u"࠭ࠧ⌔"),l1l111_l1_ (u"ࠧࠨ⌕"),l1l111_l1_ (u"ࠨࠩ⌖")
	if l1l111_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭⌗") in type:
		l111ll1l11_l1_,l1l11llll_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࡳ࡫ࡸࡵ࠿ࡳࡥ࡬࡫ࠦࠨ⌘"))
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⌙"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ⌚")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ⌛"),l111ll1l11_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ⌜"),l1l111_l1_ (u"ࠨࠩ⌝"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⌞"))
		html = response.content
		l11l1ll1_l1_ = l1l111_l1_ (u"ࠪࡷࡪࡩࡃࡰࡰࡷࡩࡳࡺࠧ⌟")+html+l1l111_l1_ (u"ࠫࡁ࡬࡯ࡰࡶࡨࡶࡃ࠭⌠")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⌡"),url,l1l111_l1_ (u"࠭ࠧ⌢"),l1l111_l1_ (u"ࠧࠨ⌣"),l1l111_l1_ (u"ࠨࠩ⌤"),l1l111_l1_ (u"ࠩࠪ⌥"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⌦"))
		html = response.content
		l11l1ll1_l1_ = html
	items,l111llllll_l1_,filters = [],False,False
	if not type and l1l111_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡵࠪ⌧") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⌨"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ〈"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ〉"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌫"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠩࠪ⌬"),l1l111_l1_ (u"ࠪࡷࡺࡨ࡭ࡦࡰࡸࠫ⌭"))
				l111llllll_l1_ = True
	if not l111llllll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫ࡣࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰࡆࡳࡳࡺࡥ࡯ࡶࠪ⌮"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⌯"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"࠭࡜࡯ࠩ⌰"))
				title = unescapeHTML(title)
				if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⌱") in l1ll1ll_l1_ and type==l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⌲"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌳"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪ⌴"))
				elif l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⌵") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⌶"),l1lllll_l1_+title,l1ll1ll_l1_,806,l1ll1l_l1_)
				elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ⌷") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⌸"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⌹"))
				elif l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳࠨ⌺") in url: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌻"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1ll1l_l1_,l1l111_l1_ (u"ࠫࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮ࡴࠩ⌼"))
				else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⌽"),l1lllll_l1_+title,l1ll1ll_l1_,803,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡬ࡰࡣࡧࡑࡴࡸࡥࡑࡣࡵࡥࡲࡹࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼ࠩ⌾"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			params = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⌿"),block)
			l111ll111l_l1_ = params[l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽࡻࡲ࡭ࠩ⍀")]
			l111l1llll_l1_ = int(params[l1l111_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡴࡦ࡭ࡥࠨ⍁")])+1
			l111ll1111_l1_ = int(params[l1l111_l1_ (u"ࠪࡱࡦࡾ࡟ࡱࡣࡪࡩࠬ⍂")])
			query = params[l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡵࠪ⍃")].replace(l1l111_l1_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ⍄"),l1l111_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ⍅")).replace(l1l111_l1_ (u"ࠧࡕࡴࡸࡩࠬ⍆"),l1l111_l1_ (u"ࠨࡶࡵࡹࡪ࠭⍇")).replace(l1l111_l1_ (u"ࠩࡑࡳࡳ࡫ࠧ⍈"),l1l111_l1_ (u"ࠪࡲࡺࡲ࡬ࠨ⍉"))
			if l111l1llll_l1_<l111ll1111_l1_:
				l1l11llll_l1_ = l1l111_l1_ (u"ࠫࡦࡩࡴࡪࡱࡱࡁࡱࡵࡡࡥ࡯ࡲࡶࡪࠬࡱࡶࡧࡵࡽࡂ࠭⍊")+QUOTE(query,l1l111_l1_ (u"ࠬ࠭⍋"))+l1l111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⍌")+str(l111l1llll_l1_)
				l1lllll1_l1_ = l111ll111l_l1_+l1l111_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ⍍")+l1l11llll_l1_
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍎"),l1lllll_l1_+l1l111_l1_ (u"ࠩฯ่อࠦวๅ็ี๎ิ࠭⍏"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠪࠫ⍐"),l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡠࠩ⍑")+type)
		elif l1l111_l1_ (u"ࠬࡅ࡮ࡦࡺࡷࡁࡵࡧࡧࡦࠨࠪ⍒") in url:
			l1l11llll_l1_,l1lll1l1l_l1_ = l1l11llll_l1_.rsplit(l1l111_l1_ (u"࠭࠽ࠨ⍓"),1)
			l1lll1l1l_l1_ = int(l1lll1l1l_l1_)+1
			l1lllll1_l1_ = l111ll1l11_l1_+l1l111_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ⍔")+l1l11llll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ⍕")+str(l1lll1l1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍖"),l1lllll_l1_+l1l111_l1_ (u"ࠪะ้ฮࠠศๆ่ึ๏ีࠧ⍗"),l1lllll1_l1_,801,l1l111_l1_ (u"ࠫࠬ⍘"),l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡡࠪ⍙")+type)
	return
def l111ll11l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⍚"),url,l1l111_l1_ (u"ࠧࠨ⍛"),l1l111_l1_ (u"ࠨࠩ⍜"),l1l111_l1_ (u"ࠩࠪ⍝"),l1l111_l1_ (u"ࠪࠫ⍞"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡆࡊࡎࡗࡉࡗ࡙࠭࠲ࡵࡷࠫ⍟"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡵࡣࡡࡱࡥࡻ࠮࠮ࠫࡁࠬࡷࡪࡩࡃࡰࡰࡷࡩࡳࡺࠠࠨ⍠"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡷࡵࡶࡪࡴࡴࡠࡱࡳࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⍡"),block,re.DOTALL)
		for name,block in l1lll1l1_l1_:
			if l1l111_l1_ (u"ࠧศๆอู๋๐แࠨ⍢") in name: continue
			name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ⍣"))
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⍤"),block,re.DOTALL)
			for l1ll1ll_l1_,value in items:
				title = name+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ⍥")+value
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⍦"),l1lllll_l1_+title,l1ll1ll_l1_,801,l1l111_l1_ (u"ࠬ࠭⍧"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⍨"))
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⍩"),url,l1l111_l1_ (u"ࠨࠩ⍪"),l1l111_l1_ (u"ࠩࠪ⍫"),l1l111_l1_ (u"ࠪࠫ⍬"),l1l111_l1_ (u"ࠫࠬ⍭"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⍮"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⍯"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l111ll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡊࡳࡢࡦࡦ࠱࠮ࡄࡶ࡯ࡴࡶࡀࠬ࠳࠰࠿ࠪࠤࠪ⍰"),html,re.DOTALL)
	if l111ll1ll1_l1_:
		l1ll_l1_ = base64.b64decode(l111ll1ll1_l1_[0])
		if PY3: l1ll_l1_ = l1ll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭⍱"))
		l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ⍲"),l1ll_l1_)
		l1ll_l1_ = list(l1ll_l1_.values())
		for l1ll1ll_l1_ in l1ll_l1_:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ⍳"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⍴")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⍵"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡰࡢࡩࡨࡇࡴࡴࡴࡦࡰࡷࡈࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ⍶"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶࡵࡂ࠳࠰࠿࠽ࡶࡧࡂࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪࠩ࡞ࡧࡿ࠸࠲࠴ࡾࠫ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯ࡂ࠯ࡵࡦࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⍷"),block,re.DOTALL)
		for l111l1ll_l1_,l1ll1ll_l1_ in items:
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				if l1l111_l1_ (u"ࠨ࠱ࡂࡹࡷࡲ࠽ࠨ⍸") in l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࡃࡺࡸ࡬࠾ࠩ⍹"))[1]
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ⍺"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⍻")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡣࡤ࠭⍼")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⍽"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ⍾"),l1l111_l1_ (u"ࠨ࠭ࠪ⍿"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⎀")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⎁"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬሴ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡃࡔࡖࡣࠬስ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩሶ"),l1l111_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩሷ"),l1l111_l1_ (u"ࠩส่ฬ่ำศ็ࠪሸ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧሹ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==650: l1lll_l1_ = l1l1l11_l1_()
	elif mode==651: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==652: l1lll_l1_ = PLAY(url)
	elif mode==653: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==654: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==659: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨሺ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ሻ"),l1l111_l1_ (u"࠭ࠧሼ"),l1l111_l1_ (u"ࠧࠨሽ"),l1l111_l1_ (u"ࠨࠩሾ"),l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫሿ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪቀ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫቁ"),l1l111_l1_ (u"ࠬ࠭ቂ"),659,l1l111_l1_ (u"࠭ࠧቃ"),l1l111_l1_ (u"ࠧࠨቄ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬቅ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧቆ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬቇ"),l1l111_l1_ (u"ࠫࠬቈ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ቉"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨቊ")+l1lllll_l1_+l1l111_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ቋ"),l111l1_l1_,651,l1l111_l1_ (u"ࠨࠩቌ"),l1l111_l1_ (u"ࠩࠪቍ"),l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ቎"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ቏"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧቐ")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ቑ"),l111l1_l1_,651,l1l111_l1_ (u"ࠧࠨቒ"),l1l111_l1_ (u"ࠨࠩቓ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫቔ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨቕ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ቖ"),l1l111_l1_ (u"ࠬ࠭቗"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ቘ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࠪ቙"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		title = title.replace(l1l111_l1_ (u"ࠨ࠾ࡥࡂࠬቚ"),l1l111_l1_ (u"ࠩࠪቛ")).strip(l1l111_l1_ (u"ࠪࠤࠬቜ"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫቝ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ቞")+l1lllll_l1_+title,l1ll1ll_l1_,654)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ቟"),url,l1l111_l1_ (u"ࠧࠨበ"),l1l111_l1_ (u"ࠨࠩቡ"),l1l111_l1_ (u"ࠩࠪቢ"),l1l111_l1_ (u"ࠪࠫባ"),l1l111_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩቤ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩብ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧቦ"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ቧ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬቨ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪቩ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨቪ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩቫ"),l1l111_l1_ (u"ࠬ࠭ቬ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫቭ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪቮ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨቯ"),l1lllll_l1_+title,l1ll1ll_l1_,651)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ተ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬቱ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩቲ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧታ"),l1l111_l1_ (u"࠭ࠧቴ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧት"),l1lllll_l1_+title,l1ll1ll_l1_,651)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩቶ")):
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧቷ"):
		url,search = url.split(l1l111_l1_ (u"ࠪࡃࠬቸ"),1)
		data = l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪቹ")+search
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫቺ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ቻ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬቼ"),url,data,headers,l1l111_l1_ (u"ࠨࠩች"),l1l111_l1_ (u"ࠩࠪቾ"),l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧቿ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨኀ"),url,l1l111_l1_ (u"ࠬ࠭ኁ"),l1l111_l1_ (u"࠭ࠧኂ"),l1l111_l1_ (u"ࠧࠨኃ"),l1l111_l1_ (u"ࠨࠩኄ"),l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ኅ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠪࠫኆ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨኇ"))
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪኈ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ኉"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨኊ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪኋ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪኌ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩኍ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ኎"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ኏"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ነ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩኑ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡥࡥࠥࡳࡧࡣࠢࡷࡥࡧࡲࡥࠡࡨࡸࡰࡱࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨኒ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨና"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠪࠫኔ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬን"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ኖ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ኗ"),l1l111_l1_ (u"ࠧโ์็้ࠬኘ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧኙ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧኚ"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩኛ"),l1l111_l1_ (u"ࠫ์ีวโࠩኜ"),l1l111_l1_ (u"๋ࠬศศำสอࠬኝ"),l1l111_l1_ (u"ู࠭าุࠪኞ"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧኟ"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧአ"),l1l111_l1_ (u"่ࠩืึำ๊สࠩኡ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ኢ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪኣ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫኤ"):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬእ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ኦ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨኧ"),l1lllll_l1_+title,l1ll1ll_l1_,653,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩከ"),l1lllll_l1_+title,l1ll1ll_l1_,653,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫኩ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩኪ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧካ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨኬ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩክ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨኮ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨኯ")+title,l1ll1ll_l1_,651)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧኰ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ኱"),url,l1l111_l1_ (u"ࠬ࠭ኲ"),l1l111_l1_ (u"࠭ࠧኳ"),l1l111_l1_ (u"ࠧࠨኴ"),l1l111_l1_ (u"ࠨࠩኵ"),l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ኶"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭኷"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ኸ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭ኹ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࠧࠨࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭ኺ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩኻ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠨࠥࠪኼ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩኽ"),l1lllll_l1_+title,url,653,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫኾ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠬ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠩ࠯࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ኿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪዀ")+l1l11_l1_+l1l111_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ዁"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭ዂ")+l1l11_l1_+l1l111_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧዃ"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡓࡦࡣࡶࡳࡳ࠭ዄ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨዅ"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠥ዆"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ዇"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬወ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠯࠱ࠪዉ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪዊ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫዋ"))
			title = title.replace(l1l111_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨዌ"),l1l111_l1_ (u"ࠫࠥ࠭ው"))
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫዎ"),l1lllll_l1_+title,l1ll1ll_l1_,652,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪዏ"),l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪዐ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬዑ"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪዒ"),l1l111_l1_ (u"ࠪࠫዓ"),l1l111_l1_ (u"ࠫࠬዔ"),l1l111_l1_ (u"ࠬ࠭ዕ"),l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨዖ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ዗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧዘ"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪዙ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬዚ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦ࠰ࡹࡷࡲ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬዛ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧዜ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧዝ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨዞ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧዟ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪዠ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫዡ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ዢ"),l1l111_l1_ (u"ࠬ࠱ࠧዣ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧዤ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧዥ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ媛")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡔࡗࡈࡢࠫ媜")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ媝")]
def l11l1ll_l1_(mode,url,text):
	if   mode==460: l1lll_l1_ = l1l1l11_l1_()
	elif mode==461: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==462: l1lll_l1_ = PLAY(url)
	elif mode==463: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==469: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ媞"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ媟"),l1l111_l1_ (u"ࠩࠪ媠"),l1l111_l1_ (u"ࠪࠫ媡"),l1l111_l1_ (u"ࠫࠬ媢"),l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭媣"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媤"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ媥"),l1l111_l1_ (u"ࠨࠩ媦"),469,l1l111_l1_ (u"ࠩࠪ媧"),l1l111_l1_ (u"ࠪࠫ媨"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ媩"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ媪"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ媫"),l1l111_l1_ (u"ࠧࠨ媬"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ媭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ媮"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ媯") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title==l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭媰"): title = l1l111_l1_ (u"ࠬาฯ๋ัࠣั้่วหࠢอ๎ๆ๐ࠠโษ้ࠫ媱")
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媲"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ媳")+l1lllll_l1_+title,l1ll1ll_l1_,461)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠨࠩ媴")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭媵"),url,l1l111_l1_ (u"ࠪࠫ媶"),l1l111_l1_ (u"ࠫࠬ媷"),l1l111_l1_ (u"ࠬ࠭媸"),l1l111_l1_ (u"࠭ࠧ媹"),l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ媺"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡧࡱࡲࡸࡪࡸࠢࠨ媻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ媼"),block,re.DOTALL)
		l1l1_l1_ = []
		l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪ媽"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩ媾"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫ媿"),l1l111_l1_ (u"࠭ใๅ์หࠫ嫀"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭嫁"),l1l111_l1_ (u"ࠨ้าหๆ࠭嫂"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ嫃"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ嫄"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ嫅"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ嫆")]
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ嫇") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ嫈"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嫉"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ嫊") in title:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ嫋") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫌"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嫍"),l1lllll_l1_+title,l1ll1ll_l1_,463,l1ll1l_l1_)
	if l111l1l1l_l1_!=l1l111_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭嫎"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嫏"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嫐"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ嫑"))
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠥࠦ嫒"): continue
				if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嫓") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
				if title!=l1l111_l1_ (u"ࠬ࠭嫔"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫕"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭嫖")+title,l1ll1ll_l1_,461)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嫗"),url,l1l111_l1_ (u"ࠩࠪ嫘"),l1l111_l1_ (u"ࠪࠫ嫙"),l1l111_l1_ (u"ࠫࠬ嫚"),l1l111_l1_ (u"ࠬ࠭嫛"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ嫜"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ嫝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嫞"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嫟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嫠"),l1lllll_l1_+title,l1ll1ll_l1_,462,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嫡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嫢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ嫣"))
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠢࠣ嫤"): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭嫥") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title!=l1l111_l1_ (u"ࠩࠪ嫦"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫧"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ嫨")+title,l1ll1ll_l1_,463)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嫩"),url,l1l111_l1_ (u"࠭ࠧ嫪"),l1l111_l1_ (u"ࠧࠨ嫫"),l1l111_l1_ (u"ࠨࠩ嫬"),l1l111_l1_ (u"ࠩࠪ嫭"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ嫮"))
	html = response.content
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧ࡙ࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ嫯"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = l11l1l11l1_l1_[0]
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ嫰") not in l11l1l11l1_l1_:
			if l1l111_l1_ (u"࠭࠯࠰ࠩ嫱") in l11l1l11l1_l1_: l11l1l11l1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭嫲")+l11l1l11l1_l1_
			else: l11l1l11l1_l1_ = l111l1_l1_+l11l1l11l1_l1_
		l11l1l11l1_l1_ = l11l1l11l1_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ嫳")
		l1llll_l1_.append(l11l1l11l1_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡥ࠵࠺ࡀࡢࡦࡨࡲࡶࡪ࠮࠮ࠫࡁࠬࡷࡲࡧ࡬࡭࠰࠭ࡃࠧ࡜ࡩࡥࡧࡲࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫࠥࡔࡱࡧࡹࠣࠩ嫴"),html,re.DOTALL)
	if l11llll_l1_:
		l11l11ll1l1l_l1_,l11l11ll1ll1_l1_ = l11llll_l1_[0]
		names = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嫵"),l11l11ll1l1l_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠦࡸ࡫ࡴࡗ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫࠥ嫶"),l11l11ll1ll1_l1_,re.DOTALL)
		l11l11ll1l11_l1_ = zip(names,l1ll_l1_)
		for name,l11llllll111_l1_ in l11l11ll1l11_l1_:
			l11llllll111_l1_ = l11llllll111_l1_[2:]
			if PY2: l11llllll111_l1_ = l11llllll111_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ嫷"))
			l11llllll111_l1_ = base64.b64decode(l11llllll111_l1_)
			if PY3: l11llllll111_l1_ = l11llllll111_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ嫸"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嫹"),l11llllll111_l1_,re.DOTALL)
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭嫺") not in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠩ࠲࠳ࠬ嫻") in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ嫼")+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嫽")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嫾")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嫿"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	if l1l111_l1_ (u"ࠧࠡࠩ嬀") in search:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ嬁"),l1l111_l1_ (u"ࠩࠪ嬂"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ嬃"),l1l111_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ嬄"))
		return
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡱ࠰ࠩ嬅")+search+l1l111_l1_ (u"࠭࠯ࠨ嬆")
	l1lll11_l1_(url)
	return
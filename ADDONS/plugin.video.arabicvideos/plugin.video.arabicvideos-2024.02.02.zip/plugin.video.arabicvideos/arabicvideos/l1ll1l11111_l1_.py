# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ⾍")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧ⾎")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⾏"):l1l111_l1_ (u"ࠪࠫ⾐")}
def l11l1ll_l1_(mode,url,text):
	if   mode==320: l1lll_l1_ = l1l1l11_l1_()
	elif mode==321: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==322: l1lll_l1_ = PLAY(url)
	elif mode==329: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾑"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⾒"),l1l111_l1_ (u"࠭ࠧ⾓"),329,l1l111_l1_ (u"ࠧࠨ⾔"),l1l111_l1_ (u"ࠨࠩ⾕"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⾖"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⾗"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⾘"),l1l111_l1_ (u"ࠬ࠭⾙"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⾚"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ⾛"),l1l111_l1_ (u"ࠨࠩ⾜"),headers,l1l111_l1_ (u"ࠩࠪ⾝"),l1l111_l1_ (u"ࠪࠫ⾞"),l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⾟"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰࡲ࠱ࡵࡲࡵࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⾠"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⾡"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title==l1l111_l1_ (u"ࠧศๆ่็ฯฮษࠡษ็้ึฬ๊สࠩ⾢"): continue
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⾣"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⾤")+l1lllll_l1_+title,l1ll1ll_l1_,321)
	return html
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⾥"),url,l1l111_l1_ (u"ࠫࠬ⾦"),headers,l1l111_l1_ (u"ࠬ࠭⾧"),l1l111_l1_ (u"࠭ࠧ⾨"),l1l111_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⾩"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ⾪"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡵࡪ࠵ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⾫"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⾬"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,count,title in items:
		count = count.replace(l1l111_l1_ (u"ࠫ฾ีฯࠡࠩ⾭"),l1l111_l1_ (u"ࠬ࠭⾮")).replace(l1l111_l1_ (u"࠭ࠠࠨ⾯"),l1l111_l1_ (u"ࠧࠨ⾰"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࠪ⾱"),l1l111_l1_ (u"ࠩࠪ⾲"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠥࠫࠧ⾳"),l1l111_l1_ (u"ࠫࠬ⾴"))
		if l1l111_l1_ (u"ࠬ࠴ࡰࡩࡲࠪ⾵") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ⾶")+l1ll1ll_l1_
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ⾷")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ⾸"))
		title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ⾹")+count+l1l111_l1_ (u"ࠪ࠭ࠬ⾺")
		if l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ⾻") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⾼"),l1lllll_l1_+title,l1ll1ll_l1_,321,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩ⾽") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⾾"),l1lllll_l1_+title,l1ll1ll_l1_,322,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ⾿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⿀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ⿁")+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿂"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⿃")+title,l1ll1ll_l1_,321)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⿄"),url,l1l111_l1_ (u"ࠧࠨ⿅"),headers,l1l111_l1_ (u"ࠨࠩ⿆"),l1l111_l1_ (u"ࠩࠪ⿇"),l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⿈"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⿉"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⿊"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ⿋"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ⿌"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⿍"),l1l111_l1_ (u"ࠩ࠮ࠫ⿎"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫ⿏")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ夦")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ大")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l11l1l111l11_l1_()
	elif mode==56: l1lll_l1_ = l11l11llllll_l1_()
	elif mode==57: l1lll_l1_ = l111ll11l1_l1_(url,1)
	elif mode==58: l1lll_l1_ = l111ll11l1_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夨"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ天"),l1l111_l1_ (u"࠭ࠧ太"),59,l1l111_l1_ (u"ࠧࠨ夫"),l1l111_l1_ (u"ࠨࠩ夬"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭夭"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ央"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭夯"),l1l111_l1_ (u"ࠬ࠭夰"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭失"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ夲")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ夳"),l1l111_l1_ (u"ࠩࠪ头"),56)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ夵"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭夶")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไศใ็ห๊࠭夷"),l1l111_l1_ (u"࠭ࠧ夸"),55)
	return l1l111_l1_ (u"ࠧࠨ夹")
def l11l1l111l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ夺"),l1lllll_l1_+l1l111_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ夻"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ夼"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ夽"),l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠤึอฦอหࠪ夾"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ夿"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奀"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไศใ็ห๊࠭奁"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ奂"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奃"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣ็้อำ๋ๅํอࠬ奄"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ奅"),51)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ奆"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ奇"),l1l111_l1_ (u"ࠨࠩ奈"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奉"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสึ๊ฮࠦวๅษ้ฮฬาࠧ奊"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡹࡰࡲࠪ奋"),57)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奌"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศใู่ࠥะโ๋์่ࠫ奍"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ奎"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奏"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็ห่ััࠡ็ืห์ีษࠨ奐"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ契"),57)
	return
def l11l11llllll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奒"),l1lllll_l1_+l1l111_l1_ (u"ࠬออะอࠣห้๋ำๅี็หฯ࠭奓"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ奔"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奕"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢิหหาษࠨ奖"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭套"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奘"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็ุ้๊ำๅษอࠫ奙"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ奚"),51)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭奛"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้อสࠡๅ็หุ๐ใ๋หࠪ奜"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ奝"),51)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ奞"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ奟"),l1l111_l1_ (u"ࠫࠬ奠"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奡"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศิ่ฬࠤฬ๊ว็ฬสะࠬ奢"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡽࡴࡶࠧ奣"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奤"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อแืๆࠣฮ็๐๊ๆࠩ奥"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭奦"),57)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奧"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษๆฯึࠦๅีษ๊ำฮ࠭奨"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ奩"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠧࡀࠩ奪") in url:
		parts = url.split(l1l111_l1_ (u"ࠨࡁࠪ奫"))
		url = parts[0]
		filter = l1l111_l1_ (u"ࠩࡂࠫ奬") + QUOTE(parts[1],l1l111_l1_ (u"ࠪࡁࠫࡀ࠯ࠦࠩ奭"))
	else: filter = l1l111_l1_ (u"ࠫࠬ奮")
	parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ奯"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"࠭ࡹࡰࡲࠪ奰"),l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࠧ奱"),l1l111_l1_ (u"ࠨࡸ࡬ࡩࡼࡹࠧ奲")]:
		if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ女"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ奴")
		elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ奵"): l1l1l1lll_l1_=l1l111_l1_ (u"๋ࠬำๅี็ࠫ奶")
		url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ奷") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠧ࠰ࠩ奸") + l1llllll1_l1_ + l1l111_l1_ (u"ࠨ࠱ࠪ她") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ奺"),l1l111_l1_ (u"ࠪࠫ奻"),l1l111_l1_ (u"ࠫࠬ奼"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ好"))
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡫ࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡲࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠯ࡄࠨࡰࡦࡲ࡬ࡷࡴࡪࡥࡴࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡴࡷ࡫ࡳࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ奾"),html,re.DOTALL)
		l1ll1l111l1_l1_=0
		for id,title,l11l11lllll1_l1_,l1ll1l_l1_ in items:
			l1ll1l111l1_l1_ += 1
			l1ll1l_l1_ = l1ll1l1ll1l_l1_ + l1l111_l1_ (u"ࠧ࠰ࡸ࠵࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࡰࡥ࡮ࡴ࠯ࠨ奿") + l1ll1l_l1_ + l1l111_l1_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ妀")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ妁") + id
			if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ如"): addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ妃"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ妄"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妅"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ妆")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡨࡴࡂ࠭妇")+l11l11lllll1_l1_+l1l111_l1_ (u"ࠩࡀࠫ妈")+title+l1l111_l1_ (u"ࠪࡁࠬ妉")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ妊"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ妋")
		elif type==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭妌"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ妍")
		url = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ妎") + sort + l1l111_l1_ (u"ࠩ࠰ࠫ妏") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ妐")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ妑"),l1l111_l1_ (u"ࠬ࠭妒"),l1l111_l1_ (u"࠭ࠧ妓"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭妔"))
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妕"),html,re.DOTALL)
		l1ll1l111l1_l1_=0
		for id,l11l11lllll1_l1_,l1ll1l_l1_,title in items:
			l1ll1l111l1_l1_ += 1
			l1ll1l_l1_ = l1l1l1l1l1_l1_ + l1l111_l1_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ妖") + l1ll1l_l1_ + l1l111_l1_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ妗")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ妘") + id
			if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ妙"): addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ妚"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ妛"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妜"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไࠡࠩ妝")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡪࡶ࠽ࠨ妞")+l11l11lllll1_l1_+l1l111_l1_ (u"ࠫࡂ࠭妟")+title+l1l111_l1_ (u"ࠬࡃࠧ妠")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"࠭ีโฯฬࠤࠬ妡")
	if l1ll1l111l1_l1_==16:
		for l1ll1l1lll1_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll1l1lll1_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ妢")+type+l1l111_l1_ (u"ࠨ࠱ࠪ妣")+str(l1ll1l1lll1_l1_)+l1l111_l1_ (u"ࠩ࠲ࠫ妤")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妥"),l1lllll_l1_+title+str(l1ll1l1lll1_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠫࡂ࠭妦"))
	l11l11lllll1_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ妧"),l1l111_l1_ (u"࠭ࠧ妨"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠧࡀࠩ妩"))[0]
	if l11l11lllll1_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࠪ妫"),l1l111_l1_ (u"ࠪࠫ妬"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ妭"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭妮"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妯"),block,re.DOTALL)
		l11l11lllll1_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l11l11lllll1_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ妰") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭妱")+name+l1l111_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭妲")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ妳"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ妴"),l1l111_l1_ (u"ࠬ࠭妵"),l1l111_l1_ (u"࠭ࠧ妶"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ妷"))
	l11l1l111111_l1_ = re.findall(l1l111_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妸"),html,re.DOTALL)
	if l11l1l111111_l1_:
		time = l11l1l111111_l1_[1].replace(l1l111_l1_ (u"ࠩࡗࠫ妹"),l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ妺"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ妻"),l1l111_l1_ (u"ࠬ࠭妼"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ妽"),l1l111_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ妾")+l1l111_l1_ (u"ࠨ࡞ࡱࠫ妿")+time)
		return
	l11l11llll11_l1_,l11l1l1111l1_l1_ = [],[]
	l11l1l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ姀"),html,re.DOTALL)[0]
	l11l1l11111l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ姁"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ姂"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ姃") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭姄")
			url = l11l1l11111l_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ姅")
			url = l11l1l1111ll_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ姆") in url:
			l11l11llll11_l1_.append(url)
			l11l1l1111l1_l1_.append(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ姇")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡣࡱ࡯࡮࡬࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ姈"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡡࡺࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ姉"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ姊"))[-1]
		filename = filename.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࠨ始"),l1l111_l1_ (u"ࠧࠨ姌"))
		filename = filename.replace(l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭姍"),l1l111_l1_ (u"ࠩࠪ姎"))
		filename = filename.replace(l1l111_l1_ (u"ࠪ࠱ࠬ姏"),l1l111_l1_ (u"ࠫࠬ姐"))
		if l1l111_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ姑") in server:
			server = l1l111_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭姒")
			url = l11l1l11111l_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ姓")
			url = l11l1l1111ll_l1_ + l1ll1ll_l1_
		l11l11llll11_l1_.append(url)
		l11l1l1111l1_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࠦࠧ委")+server+l1l111_l1_ (u"ࠩࠣࠤࠬ姕")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪࡗࡪࡲࡥࡤࡶ࡚ࠣ࡮ࡪࡥࡰࠢࡔࡹࡦࡲࡩࡵࡻ࠽ࠫ姖"), l11l1l1111l1_l1_)
	if l11l11l_l1_ == -1 : return
	url = l11l11llll11_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姗"))
	return
def l111ll11l1_l1_(url,type):
	if l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ姘") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ๅิๆึ่ࠬ姙")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯โ์็้ࠬ姚")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ姛"),l1l111_l1_ (u"ࠩࠪ姜"),l1l111_l1_ (u"ࠪࠫ姝"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡆࡊࡎࡗࡉࡗ࡙࠭࠲ࡵࡷࠫ姞"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ姟"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ姠"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ姡"),block,re.DOTALL)
	if type==1:
		for l11l11llll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姢"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭姣")+l11l11llll1l_l1_,58)
	elif type==2:
		url,l11l11llll1l_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࠬ姤"))
		for l1llll1l111l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ姥"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ姦")+l1llll1l111l_l1_+l1l111_l1_ (u"࠭ࠦࠨ姧")+l11l11llll1l_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ姨"),l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ姩"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭姪")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ姫"),url,l1l111_l1_ (u"ࠫࠬ姬"),l1l111_l1_ (u"ࠬ࠭姭"),True,l1l111_l1_ (u"࠭ࠧ姮"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡖࡉࡆࡘࡃࡉ࠯࠵ࡲࡩ࠭姯"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡩࡨࡲࡪࡸࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡸ࡫ࡡࡳࡥ࡫࠱ࡧࡵࡴࡵࡱࡰ࠱ࡵࡧࡤࡥ࡫ࡱ࡫ࠬ姰"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭姱"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭姲") in url:
				if l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ姳") in url:
					title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ姴")+title
					url = url.replace(l1l111_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ姵"),l1l111_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭姶"))
					url = url+l1l111_l1_ (u"ࠨ࠿ࠪ姷")+QUOTE(title)+l1l111_l1_ (u"ࠩࡀࠫ姸")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ姹"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ姺")+title
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ姻"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
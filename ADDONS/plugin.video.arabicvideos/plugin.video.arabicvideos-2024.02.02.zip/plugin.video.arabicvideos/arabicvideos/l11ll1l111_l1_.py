# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ᶢ")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡅࡔ࠺ࡣࠬᶣ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᶤ"),l1l111_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩᶥ"),l1l111_l1_ (u"ࠩอืั๐ไࠨᶦ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==680: l1lll_l1_ = l1l1l11_l1_()
	elif mode==681: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==682: l1lll_l1_ = PLAY(url)
	elif mode==683: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==684: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==689: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᶧ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬᶨ"),l1l111_l1_ (u"ࠬ࠭ᶩ"),l1l111_l1_ (u"࠭ࠧᶪ"),l1l111_l1_ (u"ࠧࠨᶫ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᶬ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᶭ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᶮ"),l1l111_l1_ (u"ࠫࠬᶯ"),689,l1l111_l1_ (u"ࠬ࠭ᶰ"),l1l111_l1_ (u"࠭ࠧᶱ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶲ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᶳ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᶴ"),l1l111_l1_ (u"ࠪࠫᶵ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᶶ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᶷ")+l1lllll_l1_+l1l111_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬᶸ"),l111l1_l1_,681,l1l111_l1_ (u"ࠧࠨᶹ"),l1l111_l1_ (u"ࠨࠩᶺ"),l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᶻ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᶽ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠩᶾ"),l111l1_l1_,681,l1l111_l1_ (u"࠭ࠧᶿ"),l1l111_l1_ (u"ࠧࠨ᷀"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ᷁"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱ᷂ࠧ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᷃"),l1l111_l1_ (u"ࠫࠬ᷄"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ᷅"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ᷆"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠧࠨ᷇"))
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᷈"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᷉"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ᷊ࠬ")+l1lllll_l1_+title,l1ll1ll_l1_,684)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ᷋"),url,l1l111_l1_ (u"ࠬ࠭᷌"),l1l111_l1_ (u"࠭ࠧ᷍"),l1l111_l1_ (u"ࠧࠨ᷎"),l1l111_l1_ (u"ࠨ᷏ࠩ"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ᷐"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᷑"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ᷒"),l1l111_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫᷓ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᷔ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠧࠨᷕ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᷖ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᷗ"),l1l111_l1_ (u"ࠪࠫᷘ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᷙ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠬࡀࠠࠨᷚ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᷛ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᷜ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᷝ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᷞ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᷟ"),l1l111_l1_ (u"ࠫࠬᷠ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᷡ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧᷢ")):
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬᷣ"):
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࠪᷤ"),1)
		data = l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨᷥ")+search
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᷦ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫᷧ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪᷨ"),url,data,headers,l1l111_l1_ (u"࠭ࠧᷩ"),l1l111_l1_ (u"ࠧࠨᷪ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᷫ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᷬ"),url,l1l111_l1_ (u"ࠪࠫᷭ"),l1l111_l1_ (u"ࠫࠬᷮ"),l1l111_l1_ (u"ࠬ࠭ᷯ"),l1l111_l1_ (u"࠭ࠧᷰ"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᷱ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠨࠩᷲ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᷳ"))
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨᷴ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᷵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭᷶"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ᷷"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᷸"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ᷹ࠧ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿᷺ࠩ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ᷻"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᷼"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹ᷽ࠧ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ᷾"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿᷿ࠩ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩḀ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪḁ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫḂ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫḃ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪḄ"),l1l111_l1_ (u"࠭ว฻่ํอࠬḅ"),l1l111_l1_ (u"ࠧไๆํฬࠬḆ"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧḇ"),l1l111_l1_ (u"๊ࠩำฬ็ࠧḈ"),l1l111_l1_ (u"้ࠪออัศหࠪḉ"),l1l111_l1_ (u"ࠫ฾ืึࠨḊ"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬḋ"),l1l111_l1_ (u"࠭วๅส๋้ࠬḌ"),l1l111_l1_ (u"ࠧๆีิั๏ฯࠧḍ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫḎ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨḏ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩḐ"):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪḑ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫḒ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ḓ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḔ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩḕ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧḖ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬḗ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭Ḙ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧḙ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ḛ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ḛ")+title,l1ll1ll_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬḜ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ḝ"),url,l1l111_l1_ (u"ࠪࠫḞ"),l1l111_l1_ (u"ࠫࠬḟ"),l1l111_l1_ (u"ࠬ࠭Ḡ"),l1l111_l1_ (u"࠭ࠧḡ"),l1l111_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧḢ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫḣ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫḤ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫḥ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠬ࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫḦ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧḧ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ḩ"),l1lllll_l1_+title,url,683,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨḩ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭Ḫ")+l1l11_l1_+l1l111_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧḫ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀ࠿ࡰ࡮ࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠤḬ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪḭ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧḮ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨḯ"))
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬḰ"),l1l111_l1_ (u"ࠨࠢࠪḱ"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨḲ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l11ll11lll_l1_ = [],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ḳ"),l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭Ḵ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩḵ"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧḶ"),l1l111_l1_ (u"ࠧࠨḷ"),l1l111_l1_ (u"ࠨࠩḸ"),l1l111_l1_ (u"ࠩࠪḹ"),l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ḻ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬḻ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭Ḽ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫḽ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨḾ")+server+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩḿ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṀ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l11ll11lll_l1_:
			l11ll11lll_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨṁ"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬṂ")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ṃ")
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪṄ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫṅ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭Ṇ"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪṇ")+server+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧṈ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪṉ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭Ṋ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧṋ"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩṌ"),l1l111_l1_ (u"ࠨ࠭ࠪṍ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪṎ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪṏ"))
	return
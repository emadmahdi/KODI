# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ᳔ࠫ")
def l11l1ll_l1_(mode,url):
	if   mode==330: l1lll_l1_ = l1l11l111l_l1_()
	elif mode==331: l1lll_l1_ = PLAY(url)
	elif mode==332: l1lll_l1_ = l11lllllll_l1_()
	elif mode==333: l1lll_l1_ = l11ll1ll1l_l1_()
	elif mode==334: l1lll_l1_ = l1lll1ll1l_l1_(url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lll1ll1l_l1_(l11lll1l11_l1_):
	try: os.remove(l11lll1l11_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ᳕")))
	except: os.remove(l11lll1l11_l1_)
	return
def PLAY(url):
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ᳖ࠪ"))
	return
def l11ll1ll1l_l1_():
	message = l1l111_l1_ (u"ࠬษะ่สࠣษ้๏ࠠาษห฻ࠥอไโ์า๎ํࠦร้ࠢสฺ่๎สࠡใํࠤฬ๊ๅ้ไ฼ࠤฬ๊ๅุๆ๋ฬࠥัๅࠡลู฾฼ูࠦๅ๋ࠣึึࠦวๅไสส๊ฯࠠศๆํ้๏์ࠠฬ็ࠣวำะวาࠢࠥฮา๋๊ๅ่่ࠢๆอสࠡใํำ๏๎ࠢࠡอ่ࠤฬิสศำࠣำ็ฯࠠศๆุ์ึฯ้ࠠษัฮฬืࠠ็๊฼ࠤ๊๊แࠡษ็ูํืษ๊ࠡห฽ิํวࠡี๋ๅࠥ๐ศะลࠣห้ะอๆ์็᳗ࠫ")
	l1111l1_l1_(l1l111_l1_ (u"᳘࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ᳙"),l1l111_l1_ (u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧ᳚"),message)
	return
def l1l11l111l_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᳛"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊࡞࠳ࡈࡕࡌࡐࡔࡠ᳜ࠫ"),l1l111_l1_ (u"᳝ࠫࠬ"),333)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭᳞ࠪ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ฬ฽๎๏ืࠠๆๅส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อส࡜࠱ࡆࡓࡑࡕࡒ࡞᳟ࠩ"),l1l111_l1_ (u"ࠧࠨ᳠"),332)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᳡"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠ᳢ࠫ"),l1l111_l1_ (u"᳣ࠪࠫ"),9999)
	l1l111l11l_l1_ = l11llll1ll_l1_()
	mtime = os.stat(l1l111l11l_l1_).st_mtime
	l1l1111111_l1_ = []
	if PY3: l1l111l111_l1_ = os.listdir(l1l111l11l_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹᳤ࠩ")))
	else: l1l111l111_l1_ = os.listdir(l1l111l11l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺᳥ࠪ")))
	for filename in l1l111l111_l1_:
		if PY3: filename = filename.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻᳦ࠫ"))
		if not filename.startswith(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡤ᳧࠭")): continue
		filepath = os.path.join(l1l111l11l_l1_,filename)
		mtime = os.path.getmtime(filepath)
		l1l1111111_l1_.append([filename,mtime])
	l1l1111111_l1_ = sorted(l1l1111111_l1_,reverse=True,key=lambda key: key[1])
	for filename,mtime in l1l1111111_l1_:
		if PY2:
			try: filename = filename.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽᳨࠭"))
			except: pass
			filename = filename.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᳩ"))
		filepath = os.path.join(l1l111l11l_l1_,filename)
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᳪ"),filename,filepath,331)
	return
def l11llll1ll_l1_():
	l1l111l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧᳫ"))
	if l1l111l11l_l1_: return l1l111l11l_l1_
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨᳬ"),addoncachefolder)
	return addoncachefolder
def l11lllllll_l1_():
	l1l111l11l_l1_ = l11llll1ll_l1_()
	l1l1111l1l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ᳭࠭"),l1l111_l1_ (u"ࠧࠨᳮ"),l1l111_l1_ (u"ࠨࠩᳯ"),l1l111_l1_ (u"่ࠩ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไหฯ่๎้࠭ᳰ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ᳱ")+l1l111l11l_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ๊ิฬࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใสฮࠥอไโ์า๎ํࠦวๅฬํࠤฯำๅๅ้สࠤฬ์สࠡสสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะฺ๋์ิࠤฬ๊ๅไษ้ࠤฤ࠭ᳲ"))
	if l1l1111l1l_l1_==1:
		newpath = l1l11111l1_l1_(3,l1l111_l1_ (u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩᳳ"),l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡰࠬ᳴"),l1l111_l1_ (u"ࠧࠨᳵ"),False,True,l1l111l11l_l1_)
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᳶ"),l1l111_l1_ (u"ࠩࠪ᳷"),l1l111_l1_ (u"ࠪࠫ᳸"),l1l111_l1_ (u"๊้ࠫว็ࠢอาื๐ๆࠡ็็ๅฬะࠠศๆอั๊๐ไࠨ᳹"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨᳺ")+l1l111l11l_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲ์ึว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ฬะ์าࠤ้ะฮำ์้ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอั๊๊็ศࠢส๊ฯࠦศศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ࠥฮฯๅษ้๋ࠣࠦวๅ็ๆห๋ࠦวๅไา๎๊ࠦฟࠨ᳻"))
		if l1llll111l_l1_==1:
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ᳼"),newpath)
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᳽"),l1l111_l1_ (u"ࠩࠪ᳾"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᳿"),l1l111_l1_ (u"ࠫฯ๋ࠠห฼ํ๎ึࠦๅไษ้ࠤฯิา๋่ࠣห้๋ไโษอࠤฬ๊ๅฮ็็อࠬᴀ"))
	return
def l11lll11l1_l1_(url,l11ll1l1l1_l1_=l1l111_l1_ (u"ࠬ࠭ᴁ"),l1l11l11_l1_=l1l111_l1_ (u"࠭ࠧᴂ")):
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᴃ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᴄ")+url+l1l111_l1_ (u"ࠩࠣࡡࠬᴅ"))
	if not l11ll1l1l1_l1_: l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(url)
	l1l111l11l_l1_ = l11llll1ll_l1_()
	l1l111ll11_l1_ = CLEAN_MENU_LABEL()
	filename = l1l111ll11_l1_.replace(l1l111_l1_ (u"ࠪࠤࠬᴆ"),l1l111_l1_ (u"ࠫࡤ࠭ᴇ"))
	filename = WINDOWS_FILENAME(filename)
	filename = l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡢࠫᴈ")+str(int(now))[-4:]+l1l111_l1_ (u"࠭࡟ࠨᴉ")+filename+l11ll1l1l1_l1_
	l11ll1lll1_l1_ = os.path.join(l1l111l11l_l1_,filename)
	headers = {}
	headers[l1l111_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩᴊ")] = l1l111_l1_ (u"ࠨࠩᴋ")
	headers[l1l111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩᴌ")] = l1l111_l1_ (u"ࠪ࠮࠴࠰ࠧᴍ")
	url = url.replace(l1l111_l1_ (u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧᴎ"),l1l111_l1_ (u"ࠬ࠭ᴏ"))
	if l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᴐ") in url:
		l1lllll1_l1_,l11ll1l1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬᴑ"),1)
		l11ll1l1ll_l1_ = l11ll1l1ll_l1_.replace(l1l111_l1_ (u"ࠨࡾࠪᴒ"),l1l111_l1_ (u"ࠩࠪᴓ")).replace(l1l111_l1_ (u"ࠪࠪࠬᴔ"),l1l111_l1_ (u"ࠫࠬᴕ"))
	else: l1lllll1_l1_,l11ll1l1ll_l1_ = url,None
	if not l11ll1l1ll_l1_: l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	if l11ll1l1ll_l1_: headers[l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᴖ")] = l11ll1l1ll_l1_
	if l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᴗ") in l1lllll1_l1_: l1lllll1_l1_,l11lll1lll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᴘ"),1)
	else: l1lllll1_l1_,l11lll1lll_l1_ = l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩᴙ")
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠩࡿࠫᴚ")).strip(l1l111_l1_ (u"ࠪࠪࠬᴛ")).strip(l1l111_l1_ (u"ࠫࢁ࠭ᴜ")).strip(l1l111_l1_ (u"ࠬࠬࠧᴝ"))
	l11lll1lll_l1_ = l11lll1lll_l1_.replace(l1l111_l1_ (u"࠭ࡼࠨᴞ"),l1l111_l1_ (u"ࠧࠨᴟ")).replace(l1l111_l1_ (u"ࠨࠨࠪᴠ"),l1l111_l1_ (u"ࠩࠪᴡ"))
	if l11lll1lll_l1_:	headers[l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᴢ")] = l11lll1lll_l1_
	l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᴣ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ᴤ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩᴥ")+str(headers)+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᴦ")+l11ll1lll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫᴧ"))
	l1l11l11l1_l1_ = 1024*1024
	l1l111l1ll_l1_ = 0
	try:
		l1l111l1l1_l1_ =	xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬᴨ"))
		l1l111l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࠧᴩ"),l1l111l1l1_l1_)
		l1l111l1ll_l1_ = int(l1l111l1l1_l1_[0])
	except: pass
	if not l1l111l1ll_l1_:
		try:
			l1l1111ll1_l1_ = os.l11ll1l11l_l1_(l1l111l11l_l1_)
			l1l111l1ll_l1_ = l1l1111ll1_l1_.f_frsize*l1l1111ll1_l1_.f_bavail//l1l11l11l1_l1_
		except: pass
	if not l1l111l1ll_l1_:
		try:
			l1l1111ll1_l1_ = os.l1l11l1111_l1_(l1l111l11l_l1_)
			l1l111l1ll_l1_ = l1l1111ll1_l1_.f_frsize*l1l1111ll1_l1_.f_bavail//l1l11l11l1_l1_
		except: pass
	if not l1l111l1ll_l1_:
		try:
			import shutil
			total,l11llllll1_l1_,l11llll1l1_l1_ = shutil.l1l11l1l11_l1_(l1l111l11l_l1_)
			l1l111l1ll_l1_ = l11llll1l1_l1_//l1l11l11l1_l1_
		except: pass
	if not l1l111l1ll_l1_:
		l1l11l1l1l_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪᴪ"),l1l111_l1_ (u"๋ࠬำศฯฬࠤฬ๊สฯิํ๊๋ࠥฬ่๊็อࠬᴫ"),l1l111_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠ฻์ิࠤ็อฯาࠢฦ๊ࠥ๐อะั้ࠣ็ีวา่ࠢืฬำษࠡษ็ฮำุ๊็ࠢส่ๆอั฻หࠣๅ๏ࠦฬ่ษี็ࠥ๎ูๅ์๊ࠤๆอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ้์๋ࠠ฻่่ࠥ฿ๆะๅࠣษ้๏ࠠฤ่ࠣ๎็๎ๅࠡ็หี๊า๊ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦศฮๆ๋ࠣีํࠠศๆุ่่๊ษࠡๆส๊ࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠡไาࠤ๏ูศษࠢส้ฯ๊วยࠢฯ๋ฬุใࠡสส่๊๊แศฬࠣ์์ึวࠡใํ๋ࠥิื้ำฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอ฻่าหูࠣา๐อส๋่ࠢ์ึวࠡษ็ือฮࠠใษ่ࠤฬ๊ๅษำ่ะ๋ࠥฤใฬสࠤอ๋ๆฺࠢส่อืๆศ็ฯࠤ๊์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪᴬ"),l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᴭ"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᴮ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤࡹ࡮ࡥࠡࡦ࡬ࡷࡰࠦࡦࡳࡧࡨࠤࡸࡶࡡࡤࡧࠪᴯ"))
		return False
	if l11ll1l1l1_l1_==l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᴰ"):
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(l1lllll1_l1_,headers)
		if len(l1l1lll1_l1_)==0:
			l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆฺไࠡใํࠤส๐ฬศั้้ࠣ็ࠠศๆอั๊๐ไࠨᴱ"),l1l111_l1_ (u"ࠬ࠭ᴲ"))
			return False
		elif len(l1l1lll1_l1_)==1: l11l11l_l1_ = 0
		elif len(l1l1lll1_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᴳ"), l1l1lll1_l1_)
			if l11l11l_l1_ == -1 :
				l1ll1lll_l1_(l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯำๅ๋ๆࠪᴴ"),l1l111_l1_ (u"ࠨࠩᴵ"))
				return False
		l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	filesize = 0
	if l11ll1l1l1_l1_==l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᴶ"):
		l11ll1lll1_l1_ = l11ll1lll1_l1_.rsplit(l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᴷ"))[0]+l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩᴸ")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᴹ"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧᴺ"),headers,l1l111_l1_ (u"ࠧࠨᴻ"),l1l111_l1_ (u"ࠨࠩᴼ"),l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ࠱ࡉࡕࡗࡏࡎࡒࡅࡉࡥࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩᴽ"))
		l11lllll11_l1_ = response.content
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠧࡊ࡞ࡔࡊࡐࡉ࠾࠳࠰࠿࡜࡞ࡱࡠࡷࡣࠨ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠫᴾ"),l11lllll11_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜ࡳࠩᴿ"),re.DOTALL)
		if not l1ll_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᵀ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗ࡬ࡪࠦ࡭࠴ࡷ࠻ࠤ࡫࡯࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣ࡬ࡦࡼࡥࠡࡶ࡫ࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠ࡭࡫ࡱ࡯ࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᵁ")+l1lllll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᵂ"))
			return False
		l1ll1ll_l1_ = l1ll_l1_[0]
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᵃ")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠩ࠲࠳ࠬᵄ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪ࠾ࠬᵅ"),1)[0]+l1l111_l1_ (u"ࠫ࠿࠭ᵆ")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵ࠧᵇ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᵈ"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩᵉ"),1)[0]+l1l111_l1_ (u"ࠨ࠱ࠪᵊ")+l1ll1ll_l1_
		response = requests.request(l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᵋ"),l1ll1ll_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11llll11l_l1_ = len(l1ll_l1_)
		filesize = chunksize*l11llll11l_l1_
	else:
		chunksize = 1*l1l11l11l1_l1_
		response = requests.request(l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᵌ"),l1lllll1_l1_,headers=headers,verify=False,stream=True)
		if l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬᵍ") in response.headers: filesize = int(response.headers[l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᵎ")])
		l11llll11l_l1_ = int(filesize//chunksize)
	l1l111ll1l_l1_ = int(filesize//l1l11l11l1_l1_)+1
	if filesize<21000:
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫᵏ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᵐ")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬᵑ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᵒ")+str(l1l111l1ll_l1_)+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᵓ")+l11ll1lll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧᵔ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭ᵕ"),l1l111_l1_ (u"࠭ࠧᵖ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᵗ"),l1l111_l1_ (u"ࠨใื่ࠥ็๊ࠡ็฼ีๆฯࠠฮฮ่ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไๆๆไࠤฺเ๊าࠢฯำฬ่ࠦๅ้ำห๊ࠥวࠡ์่็๋ࠦไๅสิ๊ฬ๋ฬࠡฬะ้๏๊่ࠠาสࠤฬ๊ๅๅใࠪᵘ"))
		return False
	l11lll1ll1_l1_ = 400
	l11lll111l_l1_ = l1l111l1ll_l1_-l1l111ll1l_l1_
	if l11lll111l_l1_<l11lll1ll1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᵙ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡎࡰࡶࠣࡩࡳࡵࡵࡨࡪࠣࡨ࡮ࡹ࡫ࠡࡵࡳࡥࡨ࡫ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᵚ")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᵛ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᵜ")+str(l1l111l1ll_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣ࠱ࠥ࠭ᵝ")+str(l11lll1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᵞ")+l11ll1lll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫᵟ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪᵠ"),l1l111_l1_ (u"ࠪࠫᵡ"),l1l111_l1_ (u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫᵢ"),l1l111_l1_ (u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫᵣ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬᵤ")+str(l1l111l1ll_l1_)+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧᵥ")+str(l11lll1ll1_l1_)+l1l111_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪᵦ"))
		return False
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩᵧ"),l1l111_l1_ (u"ࠪࠫᵨ"),l1l111_l1_ (u"ࠫࠬᵩ"),l1l111_l1_ (u"ࠬํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฤ࠭ᵪ"),l1l111_l1_ (u"࠭วๅ็็ๅࠥอไๆู็์อࠦออ็๊ࠤฯ่ั๋สสࠤࠬᵫ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อࠥะโา์หหࠥ࠭ᵬ")+str(l1l111l1ll_l1_)+l1l111_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤํํะศࠢส่๊๊แࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦไๅฬะ้๏๊ࠠๆ่ࠣห้หๆหำ้ฮࠥหไ๊ࠢฯ๋ฬุใࠡ࠰๋้ࠣࠦว็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡษ็หุะๅาษิࠤอะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢยࠫᵭ"))
	if l1llll111l_l1_!=1:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪᵮ"),l1l111_l1_ (u"ࠪࠫᵯ"),l1l111_l1_ (u"ࠫࠬᵰ"),l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᵱ"))
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᵲ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡴࡨࡪࡺࡹࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᵳ")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᵴ")+l11ll1lll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬᵵ"))
		return False
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᵶ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩᵷ"))
	l1l1111lll_l1_ = l1l111lll1_l1_()
	l1l1111lll_l1_.create(l11ll1lll1_l1_,l1l111_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ᵸ"))
	l11llll111_l1_ = True
	t1 = time.time()
	if PY3: file = open(l11ll1lll1_l1_,l1l111_l1_ (u"࠭ࡷࡣࠩᵹ"))
	else: file = open(l11ll1lll1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᵺ")),l1l111_l1_ (u"ࠨࡹࡥࠫᵻ"))
	if l11ll1l1l1_l1_==l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᵼ"):
		for l1l111llll_l1_ in range(1,l11llll11l_l1_+1):
			l1ll1ll_l1_ = l1ll_l1_[l1l111llll_l1_-1]
			if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᵽ")):
				if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࠴࠵ࠧᵾ")): l1ll1ll_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬࡀࠧᵿ"),1)[0]+l1l111_l1_ (u"࠭࠺ࠨᶀ")+l1ll1ll_l1_
				elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠰ࠩᶁ")): l1ll1ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᶂ"))+l1ll1ll_l1_
				else: l1ll1ll_l1_ = l1lllll1_l1_.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫᶃ"),1)[0]+l1l111_l1_ (u"ࠪ࠳ࠬᶄ")+l1ll1ll_l1_
			response = requests.request(l1l111_l1_ (u"ࠫࡌࡋࡔࠨᶅ"),l1ll1ll_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11lll1111_l1_ = time.time()
			l11ll1ll11_l1_ = l11lll1111_l1_-t1
			l11ll1llll_l1_ = l11ll1ll11_l1_//l1l111llll_l1_
			l1l11111ll_l1_ = l11ll1llll_l1_*(l11llll11l_l1_+1)
			l11lll11ll_l1_ = l1l11111ll_l1_-l11ll1ll11_l1_
			l1l1111l11_l1_(l1l1111lll_l1_,int(100*l1l111llll_l1_//(l11llll11l_l1_+1)),l1l111_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ᶆ"),l1l111_l1_ (u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ᶇ"),str(l1l111llll_l1_*chunksize//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠧ࠰ࠩᶈ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ᶉ")+time.strftime(l1l111_l1_ (u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦᶊ"),time.gmtime(l11lll11ll_l1_))+l1l111_l1_ (u"ࠪࠤๅ࠭ᶋ"))
			if l1l1111lll_l1_.iscanceled():
				l11llll111_l1_ = False
				break
	else:
		l1l111llll_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l1l111llll_l1_ = l1l111llll_l1_+1
			l11lll1111_l1_ = time.time()
			l11ll1ll11_l1_ = l11lll1111_l1_-t1
			l11ll1llll_l1_ = l11ll1ll11_l1_/l1l111llll_l1_
			l1l11111ll_l1_ = l11ll1llll_l1_*(l11llll11l_l1_+1)
			l11lll11ll_l1_ = l1l11111ll_l1_-l11ll1ll11_l1_
			l1l1111l11_l1_(l1l1111lll_l1_,int(100*l1l111llll_l1_/(l11llll11l_l1_+1)),l1l111_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᶌ"),l1l111_l1_ (u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬᶍ"),str(l1l111llll_l1_*chunksize//l1l11l11l1_l1_)+l1l111_l1_ (u"࠭࠯ࠨᶎ")+str(l1l111ll1l_l1_)+l1l111_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬᶏ")+time.strftime(l1l111_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᶐ"),time.gmtime(l11lll11ll_l1_))+l1l111_l1_ (u"ࠩࠣไࠬᶑ"))
			if l1l1111lll_l1_.iscanceled():
				l11llll111_l1_ = False
				break
		response.close()
	file.close()
	l1l1111lll_l1_.close()
	if not l11llll111_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᶒ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᶓ")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᶔ")+l11ll1lll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩᶕ"))
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᶖ"),l1l111_l1_ (u"ࠨࠩᶗ"),l1l111_l1_ (u"ࠩࠪᶘ"),l1l111_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᶙ"))
		return True
	l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᶚ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᶛ")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᶜ")+l11ll1lll1_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠪᶝ"))
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩᶞ"),l1l111_l1_ (u"ࠩࠪᶟ"),l1l111_l1_ (u"ࠪࠫᶠ"),l1l111_l1_ (u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪᶡ"))
	return True
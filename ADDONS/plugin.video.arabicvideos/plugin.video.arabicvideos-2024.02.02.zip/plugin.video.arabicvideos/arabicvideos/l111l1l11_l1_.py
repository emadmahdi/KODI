# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬᓧ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡇࡂࡅࡡࠪᓨ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧᓩ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==550: l1lll_l1_ = l1l1l11_l1_()
	elif mode==551: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==552: l1lll_l1_ = PLAY(url)
	elif mode==553: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==559: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᓪ"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭ᓫ"),l1l111_l1_ (u"ࠨࠩᓬ"),l1l111_l1_ (u"ࠩࠪᓭ"),l1l111_l1_ (u"ࠪࠫᓮ"),l1l111_l1_ (u"ࠫࠬᓯ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᓰ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᓱ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓲ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᓳ"),l1l111_l1_ (u"ࠩࠪᓴ"),559,l1l111_l1_ (u"ࠪࠫᓵ"),l1l111_l1_ (u"ࠫࠬᓶ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᓷ"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᓸ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᓹ"),l1l111_l1_ (u"ࠨࠩᓺ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᓻ"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะั็ษ่่ࠣ࠭ᓼ"),l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᓽ"),551,l1l111_l1_ (u"ࠬ࠭ᓾ"),l1l111_l1_ (u"࠭ࠧᓿ"),l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᔀ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᔁ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬᔂ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࡂ࡭ࡹ࡫࡭࠾ࠩᔃ")+l111l1l1l_l1_+l1l111_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬᔄ")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔅ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔆ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨᔇ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᔈ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫᔉ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ุ้๊ࠪำๅࠢࠪᔊ") in title: continue
		if l1l111_l1_ (u"ࠫศำฯฬࠩᔋ") in title: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔌ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔍ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᔎ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔏ"),l1l111_l1_ (u"ࠩࠪᔐ"),9999)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬᔑ"): continue
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫᔒ") in title: continue
		if l1l111_l1_ (u"ࠬษอะอࠪᔓ") not in title: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔔ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔕ")+l1lllll_l1_+title,l1ll1ll_l1_,551)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠨࠩᔖ")):
	items = []
	if l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᔗ") in url or l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫᔘ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᔙ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᔚ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫᔛ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨᔜ"),l1l111_l1_ (u"ࠨࠩᔝ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᔞ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᔟ"),url,l1l111_l1_ (u"ࠫࠬᔠ"),l1l111_l1_ (u"ࠬ࠭ᔡ"),l1l111_l1_ (u"࠭ࠧᔢ"),l1l111_l1_ (u"ࠧࠨᔣ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᔤ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᔥ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪᔦ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᔧ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦࠬᔨ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡲࡲࡷࡹࠦ࡭ࡣ࠯࠴࠴ࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨᔩ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣࡵࡸ࡮ࡩ࡬ࡦࠪ࠱࠮ࡄ࠯ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬᔪ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡰࡴ࡬࡫࡮ࡴࡡ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᔫ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᔬ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪᔭ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩᔮ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫᔯ"),l1l111_l1_ (u"࠭ใๅ์หࠫᔰ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ᔱ"),l1l111_l1_ (u"ࠨ้าหๆ࠭ᔲ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩᔳ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧᔴ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫᔵ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫᔶ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨᔷ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᔸ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠨี็หุ๊ࠧᔹ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᔺ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪห้ำไใหࠪᔻ") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᔼ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔽ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨᔾ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔿ"),l1lllll_l1_+title,l1ll1ll_l1_,551,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕀ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࠪᕁ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸࠧᕂ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᕃ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠨᕄ"): continue
				if title!=l1l111_l1_ (u"࠭ࠧᕅ"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕆ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧᕇ")+title,l1ll1ll_l1_,551)
	if l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩᕈ") in url or l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫᕉ") in url:
		if l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫᕊ") in url:
			url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬᕋ"),l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧᕌ"))+l1l111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾࠴࠳ࠫᕍ")
		elif l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩᕎ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫᕏ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬᕐ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᕑ"),l1lllll_l1_+l1l111_l1_ (u"ࠬํๆศๅࠣห้๋า๋ัࠪᕒ"),url,551)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᕓ"),url,l1l111_l1_ (u"ࠧࠨᕔ"),l1l111_l1_ (u"ࠨࠩᕕ"),l1l111_l1_ (u"ࠩࠪᕖ"),l1l111_l1_ (u"ࠪࠫᕗ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᕘ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࡅࡽࡘ࡫ࡲࡪࡧࡶࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ᕙ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡭࡫ࡶࡸ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪᕚ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩᕛ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᕜ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕝ"),l1lllll_l1_+title,l1ll1ll_l1_,553,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡮ࡳࡡࡨࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᕞ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᕟ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᕠ"),l1lllll_l1_+title,l1ll1ll_l1_,552,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨᕡ"),l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨᕢ"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬᕣ"),l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬᕤ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᕥ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬᕦ"),l1l111_l1_ (u"ࠬ࠭ᕧ"),l1l111_l1_ (u"࠭ࠧᕨ"),l1l111_l1_ (u"ࠧࠨᕩ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᕪ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᕫ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕬ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᕭ"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧᕮ"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩᕯ"),l1l111_l1_ (u"ࠧࠨᕰ")).strip(l1l111_l1_ (u"ࠨࠢࠪᕱ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡃࡸ࡫ࡲࡷࡧࡵࡁࠬᕲ")+server+l1l111_l1_ (u"ࠪࠪࡵࡵࡳࡵࡋࡇࡁࠬᕳ")+l11l1l11_l1_+l1l111_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬᕴ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᕵ")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᕶ")
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠢࡨࡧࡷࡔࡱࡧࡹࡦࡴࡅࡽࡓࡧ࡭ࡦ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࡝ࠤࡶࡩࡷࡼࡥࡳ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢᕷ"),block,re.DOTALL)
			for server,l111l11ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫᕸ"),l1l111_l1_ (u"ࠩࠪᕹ")).strip(l1l111_l1_ (u"ࠪࠤࠬᕺ"))
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡈࡹࡏࡣࡰࡩࡄࡹࡥࡳࡸࡨࡶࡂ࠭ᕻ")+server+l1l111_l1_ (u"ࠬࠬ࡭ࡶ࡮ࡷ࡭ࡵࡲࡥࡔࡧࡵࡺࡪࡸࡳ࠾ࠩᕼ")+l111l11ll_l1_+l1l111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡎࡊ࠽ࠨᕽ")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨᕾ")
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᕿ")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᖀ")
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡵࡷ࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᖁ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᖂ"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᖃ")+name+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᖄ")
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬᖅ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᖆ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᖇ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫᖈ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬᖉ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧᖊ"),l1l111_l1_ (u"࠭࠭ࠨᖋ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩᖌ")+search+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧᖍ")
	l1lll11_l1_(url)
	return
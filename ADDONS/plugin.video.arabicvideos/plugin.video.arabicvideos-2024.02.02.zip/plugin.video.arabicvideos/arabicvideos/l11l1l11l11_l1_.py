# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ䍒")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡐ࠸࡚ࡥࠧ䍓")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩส๊ํอูࠡษไ่ฬ๋ࠧ䍔"),l1l111_l1_ (u"ࠪะํีวหࠢสๅ้อๅࠨ䍕")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍖"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䍗"),l1l111_l1_ (u"࠭ࠧ䍘"),389,l1l111_l1_ (u"ࠧࠨ䍙"),l1l111_l1_ (u"ࠨࠩ䍚"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䍛"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䍜"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䍝"),l1l111_l1_ (u"ࠬ࠭䍞"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䍟"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䍠")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ䍡"),l111l1_l1_,381,l1l111_l1_ (u"ࠩࠪ䍢"),l1l111_l1_ (u"ࠪࠫ䍣"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䍤"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䍥"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䍦")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯห๋ฮ๊สࠩ䍧"),l111l1_l1_,381,l1l111_l1_ (u"ࠨࠩ䍨"),l1l111_l1_ (u"ࠩࠪ䍩"),l1l111_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ䍪"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䍫"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭䍬"),l1l111_l1_ (u"࠭ࠧ䍭"),l1l111_l1_ (u"ࠧࠨ䍮"),l1l111_l1_ (u"ࠨࠩ䍯"),l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䍰"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䍱"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍲"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䍳")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"࠭ࠧ䍴"),l1l111_l1_ (u"ࠧࠨ䍵"),l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䍶")+str(seq))
	block = l1l111_l1_ (u"ࠩࠪ䍷")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡨࡨࡴࡸࠢࠨ䍸"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶ࠭࠴ࠪࡀࠫࡤࡷ࡮ࡪࡥࠨ䍹"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䍺"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䍻"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䍼"),l1l111_l1_ (u"ࠨࠩ䍽"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠩส่ศ฿ไุ๊่ࠢฬํฯสࠩ䍾"):
			if first:
				title = l1l111_l1_ (u"ࠪห้อแๅษ่ࠤࠬ䍿")+title
				first = False
			else: title = l1l111_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠࠨ䎀")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎁"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䎂")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䎃"),url,l1l111_l1_ (u"ࠨࠩ䎄"),l1l111_l1_ (u"ࠩࠪ䎅"),l1l111_l1_ (u"ࠪࠫ䎆"),l1l111_l1_ (u"ࠫࠬ䎇"),l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䎈"))
	html = response.content
	if type==l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䎉"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡤࡶࡨ࡮࠭ࡱࡣࡪࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䎊"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎋"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ䎌"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠧ䎍"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎎"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䎏"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࡵ࠰ࡸࡻࡹࡨࡰࡹࡶࠦ࠭࠴ࠪࡀࠫ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䎐"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎑"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䎒") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䎓"),l1l111_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡶࡸࡦࡸࡴ࠿ࠩ䎔"))
		html = html.replace(l1l111_l1_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䎕"),l1l111_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䎖"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡶࡤࡶࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡮ࡥࡀࠪ䎗"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䎘"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠩࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࢁࡹࡩࡥࡧࡥࡥࡷ࠯ࠧ䎙"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ䎚") in url:
				items = re.findall(l1l111_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䎛"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠫ࠴ࡷࡵࡢ࡮࡬ࡸࡾ࠵ࠧ䎜") in url:
				items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎝"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䎞"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭䎟") in title:
			title = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䎠"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䎡")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿ࠫ䎢"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ䎣") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎤"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䎥") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎦"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ䎧") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎨"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ䎩") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎪"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䎫"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࡐࡢࡩࡨࠤ࠭࠴ࠪࡀࠫࠣࡳ࡫ࠦࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䎬"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ䎭"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠨࠩ䎮") or title==last: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎯"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ䎰")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠫࠬ䎱"),l1l111_l1_ (u"ࠬ࠭䎲"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭䎳")+title+l1l111_l1_ (u"ࠧ࠰ࠩ䎴"),l1l111_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ䎵")+last+l1l111_l1_ (u"ࠩ࠲ࠫ䎶"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎷"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬิัࠡืไัฮࠦࠧ䎸")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠬ࠭䎹"),l1l111_l1_ (u"࠭ࠧ䎺"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䎻"),url,l1l111_l1_ (u"ࠨࠩ䎼"),l1l111_l1_ (u"ࠩࠪ䎽"),l1l111_l1_ (u"ࠪࠫ䎾"),l1l111_l1_ (u"ࠫࠬ䎿"),l1l111_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䏀"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏁"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䏂"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ุ้๊ำๅࠢ็่่ฮวา๋ࠢห้๋ศา็ฯࠤ๊์ู่ࠩ䏃"),l1l111_l1_ (u"ࠩࠪ䏄"),9999)
		return
	if l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ䏅") in url or l1l111_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ䏆") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡪࡶࡨࡱࠬࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ䏇"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨࡧࡳ࡭ࡸࡵࡤࡪࡱࡶࠫ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡢࡵࡷࠦࠬ࠭ࠧ䏈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡱࡹࡲ࡫ࡲࡢࡰࡧࡳࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ䏉"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"ࠨࠢ࠽ࠤࠬ䏊")+name+l1l111_l1_ (u"ࠩࠣห้ำไใหࠪ䏋")
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䏌"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䏍"),url,l1l111_l1_ (u"ࠬ࠭䏎"),l1l111_l1_ (u"࠭ࠧ䏏"),l1l111_l1_ (u"ࠧࠨ䏐"),l1l111_l1_ (u"ࠨࠩ䏑"),l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䏒"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䏓"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡩࡥ࠿ࠪࡴࡱࡧࡹࡦࡴ࠰ࡳࡵࡺࡩࡰࡰ࠰࠵ࠬ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠫࠦࡸ࡮ࡥࡢࡦࡨࡶࠧࢂࠧࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ࠩࠨࠩࠪ䏔"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠧࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡷࡪࡸࡶࡦࡴࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ䏕"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䏖")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ䏗")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬࠮ࡥ࡯ࡳࡸ࡫ࠢࠨ䏘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡢࡣࡤࡪ࡬ࡠࡩࡧࡶ࡮ࡼࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䏙"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䏚")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ䏛")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䏜"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ䏝"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ䏞"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ䏟"),l1l111_l1_ (u"ࠩ࠮ࠫ䏠"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ䏡")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ䏢"))
	return
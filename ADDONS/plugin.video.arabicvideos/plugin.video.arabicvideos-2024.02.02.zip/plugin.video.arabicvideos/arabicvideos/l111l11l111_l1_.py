# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ塙")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌ࡙ࡥࠧ塚")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ塛"),l1l111_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫ塜"),l1l111_l1_ (u"ࠫศ็ไศ็่้้ࠣศศำࠣๅ็฽ࠧ塝")]
def l11l1ll_l1_(mode,url,text):
	if   mode==640: l1lll_l1_ = l1l1l11_l1_()
	elif mode==641: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==642: l1lll_l1_ = PLAY(url)
	elif mode==643: l1lll_l1_ = l11l1l111l1l_l1_(url,text)
	elif mode==644: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==645: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==649: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ塞"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ塟"),l1l111_l1_ (u"ࠧࠨ塠"),l1l111_l1_ (u"ࠨࠩ塡"),l1l111_l1_ (u"ࠩࠪ塢"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ塣"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ塤"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ塥"),l1l111_l1_ (u"࠭ࠧ塦"),649,l1l111_l1_ (u"ࠧࠨ塧"),l1l111_l1_ (u"ࠨࠩ塨"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭塩"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ塪"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭填"),l1l111_l1_ (u"ࠬ࠭塬"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ塭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ塮"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ塯"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ塰"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ塱"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭塲")+l1lllll_l1_+title,l1ll1ll_l1_,644)
	return
def l11ll1_l1_(url):
	l11ll111l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ塳"),url,l1l111_l1_ (u"࠭ࠧ塴"),l1l111_l1_ (u"ࠧࠨ塵"),l1l111_l1_ (u"ࠨࠩ塶"),l1l111_l1_ (u"ࠩࠪ塷"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ塸"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ塹"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭塺"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ塻"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ塼"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ塽"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ塾"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ塿"),l1l111_l1_ (u"ࠫࠬ墀"),9999)
		for l11111_l1_,block in l11llll_l1_:
			l11ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ墁"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩ墂")
			for l1ll1ll_l1_,title in l11ll111l_l1_:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ境"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ墄"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ墅"),block,re.DOTALL)
		if len(l1l1111_l1_)<30:
			if l11ll111l_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ墆"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭墇"),l1l111_l1_ (u"ࠬ࠭墈"),9999)
			for l1ll1ll_l1_,title in l1l1111_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭墉"),l1lllll_l1_+title,l1ll1ll_l1_,641)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨ墊")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭墋"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫ墌"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ墍")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ墎"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ墏")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ墐"),url,data,headers,l1l111_l1_ (u"ࠧࠨ墑"),l1l111_l1_ (u"ࠨࠩ墒"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭墓"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ墔"),url,l1l111_l1_ (u"ࠫࠬ墕"),l1l111_l1_ (u"ࠬ࠭墖"),l1l111_l1_ (u"࠭ࠧ増"),l1l111_l1_ (u"ࠧࠨ墘"),l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ墙"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪ墚"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ墛"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ墜"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ墝"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧ增"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ墟"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ墠"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ墡"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ墢"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ墣"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ墤"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ墥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ墦"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ墧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪ墨"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ墩"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭墪"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ墫"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ墬"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭墭"),l1l111_l1_ (u"ࠨๅ็๎อ࠭墮"),l1l111_l1_ (u"ࠩส฽้อๆࠨ墯"),l1l111_l1_ (u"๋ࠪิอแࠨ墰"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ墱"),l1l111_l1_ (u"ࠬ฿ัืࠩ墲"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭墳"),l1l111_l1_ (u"ࠧศๆห์๊࠭墴"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ墵")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ墶"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ墷"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ墸"):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ墹"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ墺") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墻"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墼"),l1lllll_l1_+title,l1ll1ll_l1_,645,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ墽"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ墾"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭墿"): continue
				if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ壀") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ壁")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ壂"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壃"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ壄")+title,l1ll1ll_l1_,641)
	return
def l11l1l111l1l_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ壅"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ壆"),url,l1l111_l1_ (u"ࠬ࠭壇"),l1l111_l1_ (u"࠭ࠧ壈"),l1l111_l1_ (u"ࠧࠨ壉"),l1l111_l1_ (u"ࠨࠩ壊"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ壋"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭壌"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭壍"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭壎")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ壏"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠧࠤࠩ壐"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壑"),l1lllll_l1_+title,url,645,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ壒"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ壓")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ壔"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ壕"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ壖") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ壗")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠨ࠱ࠪ壘"))
			title = title.replace(l1l111_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀ࠿ࡩࡲࡄࠧ壙"),l1l111_l1_ (u"ࠪࠤࠬ壚"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ壛"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ壜"),url,l1l111_l1_ (u"࠭ࠧ壝"),l1l111_l1_ (u"ࠧࠨ壞"),l1l111_l1_ (u"ࠨࠩ壟"),l1l111_l1_ (u"ࠩࠪ壠"),l1l111_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ壡"))
	html = response.content
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡵࡧ࠻࡫ࡰࡥ࡬࡫ࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ壢"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭壣")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡎࡶ࡯ࡥࡩࡷ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ壤"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡲ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ壥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭壦"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ壧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ壨"),l1l111_l1_ (u"ࠫࠥ࠭壩"))
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ壪"),l1lllll_l1_+title,l1ll1ll_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ士"),url,l1l111_l1_ (u"ࠧࠨ壬"),l1l111_l1_ (u"ࠨࠩ壭"),l1l111_l1_ (u"ࠩࠪ壮"),l1l111_l1_ (u"ࠪࠫ壯"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭声"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻ࠳ࡲ࡯ࡤࡣࡷ࡭ࡴࡴ࠮ࡳࡧࡳࡰࡦࡩࡥ࡝ࠪࠥࠬ࠳࠰࠿ࠪࠤࠪ壱"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ売"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ壳"),l1l111_l1_ (u"ࠨࠩ壴"),l1l111_l1_ (u"ࠩࠪ壵"),l1l111_l1_ (u"ࠪࠫ壶"),l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭壷"))
	html = response.content
	l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ壸"),html,re.DOTALL)
	l11l1l11_l1_ = l11l1l11_l1_[0]
	l1l11ll_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ壹"))
	l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࡥࡩࡳࡩ࡯࠯ࡤ࡮ࡦࡾ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡻ࡯ࡤࡦࡱࡢ࡭ࡳ࡬࡯ࠧࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ壺")+l11l1l11_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ壻"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ壼"),l1l111_l1_ (u"ࠪࠫ壽"),l1l111_l1_ (u"ࠫࠬ壾"),l1l111_l1_ (u"ࠬ࠭壿"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ夀"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ夁"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		title = escapeUNICODE(title)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ夂"),l1l111_l1_ (u"ࠩࠪ夃"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ处")+title+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬ夅"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ夆"),url)
	return
def l11l1l111ll1_l1_(url):
	l1ll11l1_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ备"),l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠴ࡰࡩࡲࠪ夈"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ変"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ夊"),l1l111_l1_ (u"ࠪࠫ夋"),l1l111_l1_ (u"ࠫࠬ夌"),l1l111_l1_ (u"ࠬ࠭复"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ夎"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ夏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夐"),block,re.DOTALL)
		if l1ll_l1_:
			l1ll1ll_l1_ = l1ll_l1_[0]
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ夑"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ夒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ夓"),block,re.DOTALL)
		block = block.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠣࠩ夔"),l1l111_l1_ (u"࠭ࠢࠨ夕")).replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ外"),l1l111_l1_ (u"ࠨ࠱ࠪ夗"))
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡀ࡮࡬ࡲࡢ࡯ࡨ࠲ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ夘"),block,re.DOTALL)
		if len(l11l1l1l1_l1_)==len(l1ll_l1_):
			for id,title in l11l1l1l1_l1_:
				l1ll1ll_l1_ = l1ll_l1_[int(id)]
				if l1ll1ll_l1_ not in l1llll_l1_:
					l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ夙")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ多"))
					l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ夛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ夜"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ夝")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ夞"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ够"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ夠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ夡"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ夢"),l1l111_l1_ (u"࠭ࠫࠨ夣"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ夤")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ夥"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ␞")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭␟")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠨ␠"),l1l111_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨ␡"),l1l111_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩ␢"),l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭␣"),l1l111_l1_ (u"ࠬออะอࠣห้อฺศ่์ࠫ␤")]
def l11l1ll_l1_(mode,url,text):
	if   mode==440: l1lll_l1_ = l1l1l11_l1_()
	elif mode==441: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==442: l1lll_l1_ = PLAY(url)
	elif mode==443: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==449: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ␥"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ␦"),l1l111_l1_ (u"ࠨࠩ␧"),l1l111_l1_ (u"ࠩࠪ␨"),l1l111_l1_ (u"ࠪࠫ␩"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ␪"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ␫"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␬"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ␭"),l1l111_l1_ (u"ࠨࠩ␮"),449,l1l111_l1_ (u"ࠩࠪ␯"),l1l111_l1_ (u"ࠪࠫ␰"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ␱"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␲"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ␳")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ␴"),l111l1_l1_,441)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭␵"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ␶"),l1l111_l1_ (u"ࠪࠫ␷"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡢࡱࡪࡴࡵࡠࡴ࡬࡫࡭ࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ␸"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ␹"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ␺"): continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␻"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ␼")+l1lllll_l1_+title,l1ll1ll_l1_,441)
	return
def l1lll11_l1_(url,l1111ll1_l1_=l1l111_l1_ (u"ࠩࠪ␽")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ␾"),url,l1l111_l1_ (u"ࠫࠬ␿"),l1l111_l1_ (u"ࠬ࠭⑀"),l1l111_l1_ (u"࠭ࠧ⑁"),l1l111_l1_ (u"ࠧࠨ⑂"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⑃"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ⑄"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠴ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⑅"),block,re.DOTALL)
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		if l1l111_l1_ (u"ࠫ࠴ࡻࡲ࡭࠱ࠪ⑆") in l1ll1ll_l1_: continue
		elif l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ⑇") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⑈"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ⑉") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⑊"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⑋"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⑌"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⑍"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⑎"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⑏")+title,l1ll1ll_l1_,441)
	return
def l1ll1l11_l1_(url):
	data = {l1l111_l1_ (u"ࠧࡗ࡫ࡨࡻࠬ⑐"):1}
	headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⑑"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ⑒")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⑓"),url,data,headers,l1l111_l1_ (u"ࠫࠬ⑔"),l1l111_l1_ (u"ࠬ࠭⑕"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⑖"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ⑗"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧ⑘"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⑙"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⑚"),l1lllll_l1_+title,l1ll1ll_l1_,443,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡵࡧ࠻࡫ࡰࡥ࡬࡫ࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⑛"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⑜"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ⑝"),l1l111_l1_ (u"ࠧࠨ⑞")).strip(l1l111_l1_ (u"ࠨࠢࠪ⑟"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ①"),l1lllll_l1_+title,l1ll1ll_l1_,442,l1ll1l_l1_)
	return
def PLAY(url):
	data = {l1l111_l1_ (u"࡚ࠪ࡮࡫ࡷࠨ②"):1}
	headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ③"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ④")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ⑤"),url,data,headers,l1l111_l1_ (u"ࠧࠨ⑥"),l1l111_l1_ (u"ࠨࠩ⑦"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⑧"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⑨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡯࡭ࡳࡱ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ⑩"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⑪"),l1l111_l1_ (u"࠭ࠧ⑫")).strip(l1l111_l1_ (u"ࠧࠡࠩ⑬"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⑭")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⑮")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⑯"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳ࠯ࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑰"),block,re.DOTALL)
		for title,l111l1ll_l1_,l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ⑱"),l1l111_l1_ (u"࠭ࠧ⑲"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⑳")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⑴")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ⑵")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⑶"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ⑷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭⑸"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ⑹"),l1l111_l1_ (u"ࠧࠬࠩ⑺"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⑻")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫᖎ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡈࡉࡂࡠࠩᖏ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫ฾ื่ืࠢส่๊฻วา฻๊ࠫᖐ"),l1l111_l1_ (u"๊ࠬไไสสีࠥ็โุࠢ࠮࠵࠽࠭ᖑ"),l1l111_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᖒ"),l1l111_l1_ (u"ࠧศใ็ห๊ࠦไๅๅหหึࠦแใูࠪᖓ"),l1l111_l1_ (u"ࠨࡆࡐࡇࡆ࠭ᖔ")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==820: l1lll_l1_ = l1l1l11_l1_()
	elif mode==821: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==822: l1lll_l1_ = PLAY(url)
	elif mode==823: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==824: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᖕ")+text)
	elif mode==825: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧᖖ")+text)
	elif mode==829: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᖗ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᖘ"),l1l111_l1_ (u"࠭ࠧᖙ"),l1l111_l1_ (u"ࠧࠨᖚ"),l1l111_l1_ (u"ࠨࠩᖛ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᖜ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖝ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᖞ"),l111l1_l1_,829,l1l111_l1_ (u"ࠬ࠭ᖟ"),l1l111_l1_ (u"࠭ࠧᖠ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᖡ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᖢ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᖣ"),l1l111_l1_ (u"ࠪࠫᖤ"),9999)
	l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹ࡬ࡪࡦࡨࡶ࡭ࡵ࡭ࡦ࠰ࡳ࡬ࡵ࠭ᖥ")
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖦ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᖧ")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨᖨ"),l1ll1ll_l1_,821,l1l111_l1_ (u"ࠨࠩᖩ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᖪ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᖫ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࡚ࠫࠧࡡࡣࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᖬ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖭ"),block,re.DOTALL)
		for data,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪᖮ")+data
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᖯ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᖰ")+l1lllll_l1_+title,l1ll1ll_l1_,821,l1l111_l1_ (u"ࠩࠪᖱ"),l1l111_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫᖲ"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᖳ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖴ"),l1l111_l1_ (u"࠭ࠧᖵ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᖶ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᖷ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩ࠲ࠫᖸ") not in l1ll1ll_l1_: continue
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖹ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᖺ")+l1lllll_l1_+title,l1ll1ll_l1_,821)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭ᖻ")):
	block,items = l1l111_l1_ (u"࠭ࠧᖼ"),[]
	if type==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᖽ"):
		headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᖾ"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᖿ")}
		payload = l1l111_l1_ (u"ࠪ࡫ࡪࡺࠧᗀ")
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩᗁ"),url,payload,headers,l1l111_l1_ (u"ࠬ࠭ᗂ"),l1l111_l1_ (u"࠭ࠧᗃ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᗄ"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩᗅ"),html,re.DOTALL)
		l1111l11l_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l1111l11l_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪᗆ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᗇ"),url,l1l111_l1_ (u"ࠫࠬᗈ"),l1l111_l1_ (u"ࠬ࠭ᗉ"),l1l111_l1_ (u"࠭ࠧᗊ"),l1l111_l1_ (u"ࠧࠨᗋ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧᗌ"))
		html = response.content
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᗍ"),url,l1l111_l1_ (u"ࠪࠫᗎ"),l1l111_l1_ (u"ࠫࠬᗏ"),l1l111_l1_ (u"ࠬ࠭ᗐ"),l1l111_l1_ (u"࠭ࠧᗑ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭ᗒ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧ࠭ࡣ࡮ࡲࡧࡰ࠮࠮ࠫࡁࠬࡪࡴࡵࡴࡦࡴ࠰ࡱࡪࡴࡵࠨᗓ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if not block: block = html
	if not items: items = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡦࡴࡾ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗔ"),block,re.DOTALL)
	l111l1111_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭ᗕ"),l1l111_l1_ (u"ࠫ࠴࠭ᗖ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨᗗ"),l1l111_l1_ (u"࠭࠯ࠨᗘ"))
		l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
		title = escapeUNICODE(title)
		if l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᗙ") in l1ll1ll_l1_:
			l1111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩ็๋ื๊ࢂวๅ็๋ื๊࠯ࠧᗚ"),title,re.DOTALL)
			if l1111l1l_l1_: title = l1111l1l_l1_[0][0]
			else:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪะ่็ฯࡼศๆะ่็ฯࠩࠨᗛ"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l1lll_l1_[0][0]
			if title in l111l1111_l1_: continue
			l111l1111_l1_.append(title)
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᗜ")+title.strip(l1l111_l1_ (u"ࠫࠥ⠙ࠠࠨᗝ"))
		if l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᗞ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗟ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴࠩᗠ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗡ"),l1lllll_l1_+title,l1ll1ll_l1_,821,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦ࠱ࠪᗢ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗣ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡧ࡮ࡪ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧ࠲ࠫᗤ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗥ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨᗦ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗧ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᗨ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗩ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᗪ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᗫ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᗬ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if title: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᗭ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ᗮ")+title,l1ll1ll_l1_,821)
	return
def l1111lll1_l1_(url,l1l11_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᗯ"),url,l1l111_l1_ (u"ࠩࠪᗰ"),l1l111_l1_ (u"ࠪࠫᗱ"),l1l111_l1_ (u"ࠫࠬᗲ"),l1l111_l1_ (u"ࠬ࠭ᗳ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᗴ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸ࠭ࡪ࡯ࡤ࡫ࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗵ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0] if l1ll1l_l1_ else l1l111_l1_ (u"ࠨࠩᗶ")
	items = []
	if not l1l11_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᗷ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡓ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡃ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᗸ"),block,re.DOTALL)
			if len(items)>1:
				for l1l11_l1_,l1111ll1l_l1_,l1111llll_l1_,title in items:
					title = title.replace(l1l111_l1_ (u"ࠫࠥࠦࠧᗹ"),l1l111_l1_ (u"ࠬࠦࠧᗺ"))
					l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂࡍࡥࡵࡕࡨࡥࡸࡵ࡮ࡆࡲࠩࡣࡸ࡫ࡡࡴࡱࡱࡁࠬᗻ")+l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡡࡖࡁࠬᗼ")+l1111ll1l_l1_+l1l111_l1_ (u"ࠨࠨࡢࡆࡂ࠭ᗽ")+l1111llll_l1_
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗾ"),l1lllll_l1_+title,l1ll1ll_l1_,823,l1ll1l_l1_,l1l111_l1_ (u"ࠪࠫᗿ"),l1l11_l1_)
	if len(items)<2:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡋࡰࡪࡵࡲࡨࡪࡹࠠࡴࡧ࡯ࡩࡨࡺࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᘀ"),html,re.DOTALL)
		if l11llll_l1_: l111l11l1_l1_,block = l1l111_l1_ (u"ࠬ࠭ᘁ"),l11llll_l1_[0]
		else: l111l11l1_l1_,block = l1l111_l1_ (u"࠭ๅ้ี่ࠤࠬᘂ")+l1l11_l1_,html
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫᘃ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = l111l11l1_l1_+l1l111_l1_ (u"ࠨࠢะ่็ฯࠠࠨᘄ")+l1l1lll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫᘅ"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᘆ"),l1lllll_l1_+title,l1ll1ll_l1_,822,l1ll1l_l1_)
	return
def PLAY(url):
	url = url.replace(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧᘇ"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ᘈ")).replace(l1l111_l1_ (u"࠭࠯ࡢࡰ࡬ࡱࡪ࠵ࠧᘉ"),l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨᘊ")).replace(l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰ࠩᘋ"),l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪᘌ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᘍ"),url,l1l111_l1_ (u"ࠫࠬᘎ"),l1l111_l1_ (u"ࠬ࠭ᘏ"),l1l111_l1_ (u"࠭ࠧᘐ"),l1l111_l1_ (u"ࠧࠨᘑ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᘒ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠯ࡺࡶࡦࡶࡥࡳ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᘓ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1111l1ll_l1_.append(l1ll1ll_l1_)
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨᘔ"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᘕ")+server+l1l111_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᘖ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡹ࠭ࡵࡣࡥࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᘗ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬᘘ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡬ࡱ࡬ࡃࠧᘙ"),1)[0]
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫᘚ"))
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᘛ")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᘜ"))
	items = re.findall(l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡣ࡮ࡲࡧࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪᘝ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			title = title.replace(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠭ᘞ"),l1l111_l1_ (u"ࠧࠡࠩᘟ")).replace(l1l111_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩᘠ"),l1l111_l1_ (u"ࠩࠪᘡ")).replace(l1l111_l1_ (u"ࠪࡀ࡮ࡄࠧᘢ"),l1l111_l1_ (u"ࠫࠬᘣ")).replace(l1l111_l1_ (u"ࠬࡂ࠯ࡪࡀࠪᘤ"),l1l111_l1_ (u"࠭ࠠࠨᘥ"))
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩᘦ"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᘧ")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᘨ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᘩ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ᘪ"),l1l111_l1_ (u"ࠬ࠱ࠧᘫ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪᘬ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧᘭ"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᘮ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᘯ"),url,l1l111_l1_ (u"ࠪࠫᘰ"),l1l111_l1_ (u"ࠫࠬᘱ"),l1l111_l1_ (u"ࠬ࠭ᘲ"),l1l111_l1_ (u"࠭ࠧᘳ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫᘴ"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡷࡪࡧࡲࡤࡪࠫ࠲࠯ࡅࠩ࠽࠱ࡩࡳࡷࡳ࠾ࠨᘵ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡳࡻࠢ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᘶ"),block,re.DOTALL)
		names,l1111l111_l1_,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡧࡦࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡴࡲࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᘷ"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᘸ") in url:
		url,filters = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᘹ"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᘺ")+filters
	else: l1ll1ll_l1_ = l111l1_l1_
	return l1ll1ll_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᘻ"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᘼ"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨᘽ"),l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫᘾ")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᘿ"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᙀ"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬᙁ")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᙂ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬᙃ"),1)
	if filter==l1l111_l1_ (u"ࠩࠪᙄ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫᙅ"),l1l111_l1_ (u"ࠫࠬᙆ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᙇ"))
	if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᙈ"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩᙉ") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪᙊ") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫᙋ")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ᙌ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᙍ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨᙎ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨᙏ"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫᙐ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪᙑ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᙒ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᙓ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩᙔ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᙕ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᙖ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᙗ")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙘ"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬᙙ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠪࠫᙚ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᙛ"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙜ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ᙝ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ᙞ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠨࠩᙟ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᙠ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᙡ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᙢ"),l1l111_l1_ (u"ࠬ࠭ᙣ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"࠭ใๅࠢࠪᙤ"),l1l111_l1_ (u"ࠧࠨᙥ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪᙦ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᙧ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᙨ"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨᙩ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙪ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᙫ"),l1llllll_l1_,821,l1l111_l1_ (u"ࠧࠨᙬ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ᙭"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᙮"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫᙯ"),l1lllll1_l1_,825,l1l111_l1_ (u"ࠫࠬᙰ"),l1l111_l1_ (u"ࠬ࠭ᙱ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫᙲ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᙳ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫᙴ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᙵ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭ᙶ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᙷ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙸ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨᙹ")+name,l1lllll1_l1_,824,l1l111_l1_ (u"ࠧࠨᙺ"),l1l111_l1_ (u"ࠨࠩᙻ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫᙼ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬᙽ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᙾ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧᙿ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪᚁ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪᚂ")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬᚃ")+name
			if type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨᚄ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᚅ"),l1lllll_l1_+title,url,824,l1l111_l1_ (u"ࠬ࠭ᚆ"),l1l111_l1_ (u"࠭ࠧᚇ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᚈ") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪᚉ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᚊ"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᚋ")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᚌ"),l1lllll_l1_+title,l1llllll_l1_,821,l1l111_l1_ (u"ࠬ࠭ᚍ"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᚎ"))
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᚏ"),l1lllll_l1_+title,url,825,l1l111_l1_ (u"ࠨࠩᚐ"),l1l111_l1_ (u"ࠩࠪᚑ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭ᚒ"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨᚓ"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧᚔ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨᚕ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩᚖ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪᚗ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪᚘ")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬᚙ")
		if l1l111_l1_ (u"ࠫࠪ࠭ᚚ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ᚛") and value!=l1l111_l1_ (u"࠭࠰ࠨ᚜"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ᚝")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ᚞") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ᚟"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬᚠ")+key+l1l111_l1_ (u"ࠫࡂ࠭ᚡ")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩᚢ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨᚣ")+key+l1l111_l1_ (u"ࠧ࠾ࠩᚤ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬᚥ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫᚦ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭ᚧ"),l1l111_l1_ (u"ࠫࡂ࠭ᚨ"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭⸚")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ⸛")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1l1l1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll1l1ll1l_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll1l1llll_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll1ll1111_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll1l11l11_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll1ll11l1_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll1ll1111_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸜"),l1lllll_l1_+l1l111_l1_ (u"ࠪ฽ึฮ๊ࠨ⸝"),l111l1_l1_,21,l1l111_l1_ (u"ࠫࠬ⸞"),l1l111_l1_ (u"ࠬ࠷࠰࠲ࠩ⸟"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸠"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ⸡"),l1l1l1l1l1_l1_,21,l1l111_l1_ (u"ࠨࠩ⸢"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⸣"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸤"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆอัิ๋ࠪ⸥"),l1ll1l1ll1l_l1_,21,l1l111_l1_ (u"ࠬ࠭⸦"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⸧"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸨"),l1lllll_l1_+l1l111_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ⸩"),l1ll1l1llll_l1_,21,l1l111_l1_ (u"ࠩࠪ⸪"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⸫"))
	return
def l1ll1ll11l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⸬"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฿ัษ์ࠪ⸭"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ⸮"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨⸯ"),l1l1l1l1l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⸰"),l1lllll_l1_+l1l111_l1_ (u"ࠩไหึู้ࠨ⸱"),l1ll1l1ll1l_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⸲"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ⸳"),l1ll1l1llll_l1_,27)
	return
def l1l1l11_l1_(l1ll1ll11ll_l1_):
	l1ll1_l1_ = l1ll1ll11ll_l1_
	if l1ll1ll11ll_l1_==l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⸴"): l1ll1ll11ll_l1_ = l111l1_l1_
	elif l1ll1ll11ll_l1_==l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭⸵"): l1ll1ll11ll_l1_ = l1l1l1l1l1_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ⸶")
	l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(l1ll1ll11ll_l1_)
	if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡣࡵࠫ⸷") or l1ll1_l1_==l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⸸"):
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⸹")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ู๊ࠫไิๆสฮࠥ࠳ࠠฮษ็๎ฮ࠭⸺")
		l11111111l_l1_ = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡละำะ࠭⸻")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢฦฬัี๊ࠨ⸼")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠧษอࠣั๏ࠦย๋ࠢไ๎้๋ࠧ⸽")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠨลไ่ฬ๋ࠧ⸾")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"่ࠩ์ุ๐โ๊ࠩ⸿")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠪฬึอๅอࠩ⹀")
	elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⹁") or l1ll1_l1_==l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ⹂"):
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡩ࡯ࠢࡶ࡭ࡹ࡫ࠧ⹃")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠮ࠢࡆࡹࡷࡸࡥ࡯ࡶࠪ⹄")
		l11111111l_l1_ = l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡐࡦࡺࡥࡴࡶࠪ⹅")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡆࡲࡰࡩࡣࡥࡩࡹ࠭⹆")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"ࠪࡐ࡮ࡼࡥࠡ࡫ࡉ࡭ࡱࡳࠠࡤࡪࡤࡲࡳ࡫࡬ࠨ⹇")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠫࡒࡵࡶࡪࡧࡶࠫ⹈")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⹉")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"࠭ࡓࡩࡱࡺࡷࠬ⹊")
	elif l1lllll11ll_l1_ in [l1l111_l1_ (u"ࠧࡧࡣࠪ⹋"),l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⹌")]:
		l1ll1l11ll1_l1_ = l1l111_l1_ (u"ࠩฯืฯา่ࠡัิࠤุอ໌หࠩ⹍")
		l1ll1l11l1l_l1_ = l1l111_l1_ (u"ࠪืึ๐วๅࠢ࠰ࠤัอัໍࠩ⹎")
		l11111111l_l1_ = l1l111_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥศฮา໎้ࠫ⹏")
		l1ll1l11lll_l1_ = l1l111_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦวๅใหหࠬ⹐")
		l1ll1l1l11l_l1_ = l1l111_l1_ (u"࠭๾ฯึࠣึ๋ี็ࠡษํࠤๆ๐ไๆࠩ⹑")
		l1ll1l1l111_l1_ = l1l111_l1_ (u"ࠧโ์็้ࠬ⹒")
		l1ll1l1l1ll_l1_ = l1l111_l1_ (u"ࠨ็๋ื๏่้ࠨ⹓")
		l1ll1l1l1l1_l1_ = l1l111_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠬ⹔")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹕"),l1lllll_l1_+l1ll1l11ll1_l1_,l1ll1ll11ll_l1_,29,l1l111_l1_ (u"ࠫࠬ⹖"),l1l111_l1_ (u"ࠬ࠭⹗"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⹘"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⹙"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹚")+l1lllll_l1_+l1ll1l1l11l_l1_,l1ll1ll11ll_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⹛"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⹜"),l1l111_l1_ (u"ࠫࠬ⹝"),9999)
	l1llll1llll_l1_ = [l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⹞"),l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⹟"),l1l111_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⹠")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧ⹡"),l1l111_l1_ (u"ࠩࠪ⹢"),l1l111_l1_ (u"ࠪࠫ⹣"),l1l111_l1_ (u"ࠫࠬ⹤"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⹥"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡢࡶࡶࡷࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠱ࡆࡳࡳࡺࡡࡤࡶࠪ⹦"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⹧"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1llll1llll_l1_):
				url = l1ll1ll11ll_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⹨") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹩"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⹪")+l1lllll_l1_+l1ll1l11l1l_l1_,url,22,l1l111_l1_ (u"ࠫࠬ⹫"),l1l111_l1_ (u"ࠬ࠷࠰࠱ࠩ⹬"))
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹭"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⹮")+l1lllll_l1_+l11111111l_l1_,url,22,l1l111_l1_ (u"ࠨࠩ⹯"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⹰"))
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹱"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⹲")+l1lllll_l1_+l1ll1l11lll_l1_,url,22,l1l111_l1_ (u"ࠬ࠭⹳"),l1l111_l1_ (u"࠭࠲࠱࠳ࠪ⹴"))
				elif l1l111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⹵") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹶"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⹷")+l1lllll_l1_+l1ll1l1l111_l1_,url,22,l1l111_l1_ (u"ࠪࠫ⹸"),l1l111_l1_ (u"ࠫ࠶࠶࠰ࠨ⹹"))
				elif l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⹺") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⹼")+l1lllll_l1_+l1ll1l1l1ll_l1_,url,25,l1l111_l1_ (u"ࠨࠩ⹽"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⹾"))
				elif l1l111_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⹿") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺀"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⺁")+l1lllll_l1_+l1ll1l1l1l1_l1_,url,22,l1l111_l1_ (u"࠭ࠧ⺂"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⺃"))
	return html
def l1ll1l11l11_l1_(url):
	l1ll1ll11ll_l1_ = l1ll1l1ll11_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ⺄"),l1l111_l1_ (u"ࠩࠪ⺅"),l1l111_l1_ (u"ࠪࠫ⺆"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡑ࡚࡙ࡉࡄࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⺇"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦ࠱ࡹࡵ࡯࡭ࡵ࠰࡬ࡪࡧࡤࡦࡴࠫ࠲࠯ࡅࠩࡎࡷࡶ࡭ࡨ࠳ࡢࡰࡦࡼࠫ⺈"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"࠭࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ⺉"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺊"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"ࠨࠩ⺋"),l1l111_l1_ (u"ࠩ࠴࠴࠶࠭⺌"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⺍"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll1ll11ll_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺎"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"ࠬ࠭⺏"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⺐"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll1ll11ll_l1_ = l1ll1l1ll11_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ⺑"))[-1]
	l1ll1l1111l_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⺒") and l1llllll1_l1_==l1l111_l1_ (u"ࠩ࠳ࠫ⺓"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ⺔"),l1l111_l1_ (u"ࠫࠬ⺕"),l1l111_l1_ (u"ࠬ࠭⺖"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⺗"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡦࡲ࠭ࡣࡱࡧࡽ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡵࡳࡼ࠭⺘"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠨ࠯ࠬࡂ࠭ࡃ࠴ࠪࡀࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⺙"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll1ll11ll_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺚"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l1111l_l1_+l1l111_l1_ (u"ࠪ࠴࠶࠭⺛"))
	l1ll1l111l1_l1_=0
	if type==l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⺜"): category=l1l111_l1_ (u"ࠬ࠹ࠧ⺝")
	if type==l1l111_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⺞"): category=l1l111_l1_ (u"ࠧ࠶ࠩ⺟")
	if type==l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⺠"): category=l1l111_l1_ (u"ࠩ࠺ࠫ⺡")
	if type in [l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⺢"),l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⺣"),l1l111_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ⺤")] and l1llllll1_l1_!=l1l111_l1_ (u"࠭࠰ࠨ⺥"):
		l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡊࡲࡱࡪ࠵ࡐࡢࡩࡨ࡭ࡳ࡭ࡉࡵࡧࡰࡃࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧ⺦")+category+l1l111_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ⺧")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡴࡸࡤࡦࡴࡥࡽࡂ࠭⺨")+l1ll1l1111l_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⺩"),l1l111_l1_ (u"ࠫࠬ⺪"),l1l111_l1_ (u"ࠬ࠭⺫"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⺬"))
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠱࠿ࠣࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⺭"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ⺮"),l1l111_l1_ (u"ࠩࠪ⺯"))
			title = title.replace(l1l111_l1_ (u"ࠪࠦࠬ⺰"),l1l111_l1_ (u"ࠫࠬ⺱"))
			l1ll1l111l1_l1_ += 1
			l1ll1ll_l1_ = l1ll1ll11ll_l1_ + l1l111_l1_ (u"ࠬ࠵ࠧ⺲") + type + l1l111_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰ࠩ⺳") + id
			l1ll1l_l1_ = l1ll1ll11ll_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⺴"): addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⺵"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll1l1111l_l1_+l1l111_l1_ (u"ࠩ࠳࠵ࠬ⺶"))
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺷"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll1l1111l_l1_+l1l111_l1_ (u"ࠫ࠵࠷ࠧ⺸"))
	if type==l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⺹"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll1ll11ll_l1_+l1l111_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡉ࡯ࡦࡨࡼࡄࡶࡡࡨࡧࡀࠫ⺺")+l1llllll1_l1_,l1l111_l1_ (u"ࠧࠨ⺻"),l1l111_l1_ (u"ࠨࠩ⺼"),l1l111_l1_ (u"ࠩࠪ⺽"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭⺾"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࠭ࡥࡧࡰࡳࠬ⺿"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ⻀"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll1l111l1_l1_ += 1
			l1ll1l_l1_ = l1ll1ll11ll_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll1ll11ll_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻁"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⻂"))
	if l1ll1l111l1_l1_>20:
		title=l1l111_l1_ (u"ࠨืไัฮࠦࠧ⻃")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⻄"): title = l1l111_l1_ (u"ࠪࡔࡦ࡭ࡥࠡࠩ⻅")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⻆"): title = l1l111_l1_ (u"ࠬ฻แฮ้ࠣࠫ⻇")
		if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⻈"): title = l1l111_l1_ (u"ࠧึใะ๋ࠥ࠭⻉")
		for l1ll1l1lll1_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll1l1lll1_l1_):
				l1ll1l111ll_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ⻊")+str(l1ll1l1lll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⻋"),l1lllll_l1_+title+str(l1ll1l1lll1_l1_),url,22,l1l111_l1_ (u"ࠪࠫ⻌"),l1ll1l1111l_l1_+l1ll1l111ll_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll1ll11ll_l1_ = l1ll1l1ll11_l1_(url)
	l1ll1ll1l11_l1_ = l1ll1l1ll11_l1_(url)
	l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(url)
	parts = url.split(l1l111_l1_ (u"ࠫ࠴࠭⻍"))
	id,type = parts[-1],parts[3]
	l1ll1l1111l_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll1l111l1_l1_ = 0
	if type==l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⻎"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ⻏"),l1l111_l1_ (u"ࠧࠨ⻐"),l1l111_l1_ (u"ࠨࠩ⻑"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⻒"))
		items = re.findall(l1l111_l1_ (u"ࠪࡇࡴࡳ࡭ࡦࡰࡷࡣࡵࡧ࡮ࡦ࡮ࡢࡍࡹ࡫࡭࠯ࠬࡂࡴࡃ࠮࠮ࠫࡁࠬࡀ࡮࠴ࠫࡀࡸࡤࡶࠥ࡯࡮ࡵࡧࡵࡣࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ⻓"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ⻔")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⻕"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ⻖")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⻗"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⻘")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⻙"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⻚")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⻛"): l1ll1ll111l_l1_ = l1l111_l1_ (u"ࠬ࠭⻜")
		else: l1ll1ll111l_l1_ = l1lllll11ll_l1_
		l1ll1ll1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱࡀࠦ࠭࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪࡣ࠮࠮࠮ࠫࡁࠬࠦࡃ࠭⻝"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1ll1ll1_l1_ = l1ll1l_l1_ + l1ll1ll111l_l1_ + id + l1l111_l1_ (u"ࠧ࠰ࠩ⻞") + str(l1l1lll_l1_) + l1l111_l1_ (u"ࠨ࠰ࡳࡲ࡬࠭⻟")
				l1ll1l11l1l_l1_ = name + title + str(l1l1lll_l1_)
				l1ll1l11l1l_l1_ = unescapeHTML(l1ll1l11l1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⻠"),l1lllll_l1_+l1ll1l11l1l_l1_,url,24,l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠪࠫ⻡"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⻢"):
		l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡕࡧࡧࡦ࡫ࡱ࡫ࡆࡺࡴࡢࡥ࡫ࡱࡪࡴࡴࡊࡶࡨࡱࡄ࡯ࡤ࠾ࠩ⻣")+str(id)+l1l111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⻤")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡲࡶࡩ࡫ࡲࡣࡻࡀ࠵ࠬ⻥")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⻦"),l1l111_l1_ (u"ࠩࠪ⻧"),l1l111_l1_ (u"ࠪࠫ⻨"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ⻩"))
		items = re.findall(l1l111_l1_ (u"ࠬࡋࡰࡪࡵࡲࡨࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲࠮ࠫࡁࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗ࡫ࡧࡩࡴࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡈ࡮ࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⻪"),html,re.DOTALL)
		title = l1l111_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ⻫")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡦࡰࠪ⻬"): title = l1l111_l1_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭⻭")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥࠬ⻮"): title = l1l111_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⻯")
		if l1lllll11ll_l1_==l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⻰"): title = l1l111_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ⻱")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll1l111l1_l1_ += 1
			l1ll1ll1ll1_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll1l11l1l_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⻲"),l1lllll_l1_+l1ll1l11l1l_l1_,l1lllll1_l1_,24,l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠧࠨ⻳"),str(l1ll1l111l1_l1_))
	elif type==l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⻴"):
		if l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶࠪ⻵") in url and l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⻶") not in url:
			l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠭⻷")+str(id)+l1l111_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⻸")+l1llllll1_l1_+l1l111_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡶࡼࡴࡪࡃ࠰ࠨ⻹")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⻺"),l1l111_l1_ (u"ࠨࠩ⻻"),l1l111_l1_ (u"ࠩࠪ⻼"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠸ࡸࡤࠨ⻽"))
			items = re.findall(l1l111_l1_ (u"ࠫࡎࡳࡡࡨࡧࡄࡨࡩࡸࡥࡴࡵࡢࡗࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙ࡳ࡮ࡩࡥࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡗ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⻾"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111l1_l1_ += 1
				l1ll1ll1ll1_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l1l_l1_ = name + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ⻿") + title
				l1ll1l11l1l_l1_ = l1ll1l11l1l_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ⼀"))
				l1ll1l11l1l_l1_ = escapeUNICODE(l1ll1l11l1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⼁"),l1lllll_l1_+l1ll1l11l1l_l1_,l1lllll1_l1_,24,l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠨࠩ⼂"),str(l1ll1l111l1_l1_))
		elif l1l111_l1_ (u"ࠩࡆࡰ࡮ࡶࡳࠨ⼃") in url:
			l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁ࠵ࠬࡰࡢࡩࡨࡁࠬ⼄")+l1llllll1_l1_+l1l111_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠶࠻ࠧ⼅")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⼆"),l1l111_l1_ (u"࠭ࠧ⼇"),l1l111_l1_ (u"ࠧࠨ⼈"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠷ࡸ࡭࠭⼉"))
			items = re.findall(l1l111_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⼊"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll1l111l1_l1_ += 1
				l1ll1ll1ll1_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l1l_l1_ = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⼋"))
				l1ll1l11l1l_l1_ = escapeUNICODE(l1ll1l11l1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⼌"),l1lllll_l1_+l1ll1l11l1l_l1_,l1lllll1_l1_,24,l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠬ࠭⼍"),str(l1ll1l111l1_l1_))
		elif l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⼎") in url:
			if l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠹ࠫ⼏") in url:
				l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ⼐")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠹ࠫ⼑")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⼒"),l1l111_l1_ (u"ࠫࠬ⼓"),l1l111_l1_ (u"ࠬ࠭⼔"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠶ࡶ࡫ࠫ⼕"))
			elif l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠷ࠫ⼖") in url:
				l1lllll1_l1_ = l1ll1ll11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ⼗")+l1llllll1_l1_+l1l111_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠷ࠫ⼘")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ⼙"),l1l111_l1_ (u"ࠫࠬ⼚"),l1l111_l1_ (u"ࠬ࠭⼛"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠷ࡶ࡫ࠫ⼜"))
			items = re.findall(l1l111_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⼝"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll1l111l1_l1_ += 1
				l1ll1ll1ll1_l1_ = l1ll1ll1l11_l1_ + QUOTE(l1ll1l_l1_)
				l1ll1l11l1l_l1_ = name + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ⼞") + title
				l1ll1l11l1l_l1_ = l1ll1l11l1l_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ⼟"))
				l1ll1l11l1l_l1_ = escapeUNICODE(l1ll1l11l1l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⼠"),l1lllll_l1_+l1ll1l11l1l_l1_,l1lllll1_l1_,24,l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠫࠬ⼡"),str(l1ll1l111l1_l1_))
	if type==l1l111_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⼢") or type==l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⼣"):
		if l1ll1l111l1_l1_>25:
			title=l1l111_l1_ (u"ࠧึใะอࠥ࠭⼤")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⼥"): title = l1l111_l1_ (u"ࠩࠣࡔࡦ࡭ࡥࠡࠩ⼦")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⼧"): title = l1l111_l1_ (u"ࠫࠥ฻แฮ้ࠣࠫ⼨")
			if l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⼩"): title = l1l111_l1_ (u"࠭ࠠึใะ๋ࠥ࠭⼪")
			for l1ll1l1lll1_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll1l1lll1_l1_):
					l1ll1l111ll_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ⼫")+str(l1ll1l1lll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼬"),l1lllll_l1_+title+str(l1ll1l1lll1_l1_),url,23,l1l111_l1_ (u"ࠩࠪ⼭"),l1ll1l1111l_l1_+l1ll1l111ll_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll1ll1l11_l1_ = l1ll1l1ll11_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ⼮"),l1l111_l1_ (u"ࠫࠬ⼯"),l1l111_l1_ (u"ࠬ࠭⼰"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⼱"))
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲࡁࠧ࠮࠮ࠫࡁࠬࠬࡡ࠭࠮ࠫࡁ࡟ࠫࡤ࠯ࠨ࠯ࠬࡂ࠭ࠧࡄࠧ⼲"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ⼳"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"ࠩ࠲࠰ࠬ⼴")+l1l1lll_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ⼵")+l1l1lll_l1_+l1l111_l1_ (u"ࠫࡤ࠭⼶")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ⼷"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬ࠯ࠨ࡝࠰࠱࠮ࡄ࠯ࠢࠨ⼸"),html,re.DOTALL)
	if items:
		l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ⼹"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lllll11ll_l1_+id+l1l111_l1_ (u"ࠨ࠱ࠪ⼺")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࡰࡴ࠹ࠦࡵࡳ࡮ࠪ⼻"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⼼"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࠴࠵ࠧ⼽"),l1l111_l1_ (u"ࠬ࠵ࠧ⼾"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭ࡱ࠶ࠣࡷࡷࡩࠧ⼿"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⽀"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l11_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠥࡧࡤࡥࡴࡨࡷࡸ࠭⽁"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡙ࠩࡳ࡮ࡩࡥࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ⽂"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll1ll1l11_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠹ࠠࡢࡦࡧࡶࡪࡹࡳࠨ⽃"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬ⽄"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⽅"))
	return
def l1ll1l1ll11_l1_(url):
	if l111l1_l1_ in url: l1lll11ll11_l1_ = l111l1_l1_
	elif l1l1l1l1l1_l1_ in url: l1lll11ll11_l1_ = l1l1l1l1l1_l1_
	elif l1ll1l1ll1l_l1_ in url: l1lll11ll11_l1_ = l1ll1l1ll1l_l1_
	elif l1ll1l1llll_l1_ in url: l1lll11ll11_l1_ = l1ll1l1llll_l1_
	else: l1lll11ll11_l1_ = l1l111_l1_ (u"࠭ࠧ⽆")
	return l1lll11ll11_l1_
def l1ll1ll1l1l_l1_(url):
	if   l111l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠧࡢࡴࠪ⽇")
	elif l1l1l1l1l1_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠨࡧࡱࠫ⽈")
	elif l1ll1l1ll1l_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠩࡩࡥࠬ⽉")
	elif l1ll1l1llll_l1_ in url: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⽊")
	else: l1lllll11ll_l1_ = l1l111_l1_ (u"ࠫࠬ⽋")
	return l1lllll11ll_l1_
def l1ll1llll_l1_(url):
	l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡑ࡯ࡶࡦࠩ⽌")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⽍"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ⽎"),l1l111_l1_ (u"ࠨࠩ⽏"),l1l111_l1_ (u"ࠩࠪ⽐"),l1l111_l1_ (u"ࠪࠫ⽑"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ⽒"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⽓"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ⽔"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠧࠡࠩ⽕"),l1l111_l1_ (u"ࠨ࠭ࠪ⽖"))
	if l11_l1_:
		l1111111l_l1_ = [ l111l1_l1_ , l1l1l1l1l1_l1_ , l1ll1l1ll1l_l1_ , l1ll1l1llll_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠩ฼ีอ๐ࠧ⽗") , l1l111_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⽘") , l1l111_l1_ (u"ࠫๆอัิ๋ࠪ⽙") , l1l111_l1_ (u"ࠬ็วาี์ࠤ࠷࠭⽚") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ไ฻หࠣห้๋ๆศีหอ࠿࠭⽛"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l1111111l_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠧࡠࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉ࡟ࠨ⽜") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"ࠨࡡࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࡡࠪ⽝") in options: l1l11l11_l1_ = l1l1l1l1l1_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"ࠩࠪ⽞")
	if not l1l11l11_l1_: return
	l1lllll11ll_l1_ = l1ll1ll1l1l_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠥ࠳ࡍࡵ࡭ࡦ࠱ࡖࡩࡦࡸࡣࡩࡁࡶࡩࡦࡸࡣࡩࡵࡷࡶ࡮ࡴࡧ࠾ࠤ⽟") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⽠"),l1l111_l1_ (u"ࠬ࠭⽡"),l1l111_l1_ (u"࠭ࠧ⽢"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ⽣"))
	items = re.findall(l1l111_l1_ (u"ࠨࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠬ⽤"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"ࠩ࠶ࠫ⽥"),l1l111_l1_ (u"ࠪ࠻ࠬ⽦")]:
				title = title.replace(l1l111_l1_ (u"ࠫࡡࡢࠧ⽧"),l1l111_l1_ (u"ࠬ࠭⽨"))
				title = title.replace(l1l111_l1_ (u"࠭ࠢࠨ⽩"),l1l111_l1_ (u"ࠧࠨ⽪"))
				if category==l1l111_l1_ (u"ࠨ࠵ࠪ⽫"):
					type = l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⽬")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡥࡷ࠭⽭"): name = l1l111_l1_ (u"ู๊ࠫไิๆࠣ࠾ࠥ࠭⽮")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⽯"): name = l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠺ࠡࠩ⽰")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⽱"): name = l1l111_l1_ (u"ࠨีิ๎ฬ๊่ࠠษࠣ࠾ࠥ࠭⽲")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⽳"): name = l1l111_l1_ (u"ࠪืึ๐วๅ๊ࠢหࠥࡀࠠࠨ⽴")
				elif category==l1l111_l1_ (u"ࠫ࠺࠭⽵"):
					type = l1l111_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ⽶")
					if l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡡࡳࠩ⽷"): name = l1l111_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ⽸")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⽹"): name = l1l111_l1_ (u"ࠩࡐࡳࡻ࡯ࡥࠡ࠼ࠣࠫ⽺")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⽻"): name = l1l111_l1_ (u"ࠫๆ๐ไๆࠢ࠽ࠤࠬ⽼")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⽽"): name = l1l111_l1_ (u"࠭แๅ็๋ࠣฬࠦ࠺ࠡࠩ⽾")
				elif category==l1l111_l1_ (u"ࠧ࠸ࠩ⽿"):
					type = l1l111_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ⾀")
					if l1lllll11ll_l1_==l1l111_l1_ (u"ࠩࡤࡶࠬ⾁"): name = l1l111_l1_ (u"ࠪฬึ์วๆฮࠣ࠾ࠥ࠭⾂")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠫࡪࡴࠧ⾃"): name = l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲࠦ࠺ࠡࠩ⾄")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"࠭ࡦࡢࠩ⾅"): name = l1l111_l1_ (u"ࠧษำ้ห๊ํ่ࠠษࠣ࠾ࠥ࠭⾆")
					elif l1lllll11ll_l1_==l1l111_l1_ (u"ࠨࡨࡤ࠶ࠬ⾇"): name = l1l111_l1_ (u"ࠩหี๋อๅ่๊ࠢหࠥࡀࠠࠨ⾈")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠪ࠳ࠬ⾉") + type + l1l111_l1_ (u"ࠫ࠴ࡉ࡯࡯ࡶࡨࡲࡹ࠵ࠧ⾊") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⾋"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⾌"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙ࠫ㮄")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㮅")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠰ࠨ㮆"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠲ࠩ㮇"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠨ࠴ࠪ㮈"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠩ࠶ࠫ㮉"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠸ࠬ㮊"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮋"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ㮌")+l1l111_l1_ (u"࠭โ้ษษ้ࠥ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠫ㮍"),l1l111_l1_ (u"ࠧࠨ㮎"),762)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮏"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ㮐")+l1l111_l1_ (u"ࠪๆํอฦๆࠢไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠩ㮑"),l1l111_l1_ (u"ࠫࠬ㮒"),761)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮓"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠳ࡣࠬ㮔")+l1l111_l1_ (u"ࠧใ่๋หฯࠦๅ็่ࠢ์ฬู่่ษࠣห้ษีๅ์ฬࠫ㮕"),l1l111_l1_ (u"ࠨࠩ㮖"),101)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮗"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠴ࡠࠩ㮘")+l1l111_l1_ (u"ࠫ็์่ศฬ้ࠣำะวาห้๋๊้ࠣࠦฬํ์อ࠭㮙"),l1l111_l1_ (u"ࠬ࠭㮚"),106)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮛"),l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㮜")+l1l111_l1_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㮝"),l1l111_l1_ (u"ࠩࠪ㮞"),147)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮟"),l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㮠")+l1l111_l1_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㮡"),l1l111_l1_ (u"࠭ࠧ㮢"),148)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮣"),l1l111_l1_ (u"ࠨࡡࡌࡊࡑࡥࠧ㮤")+l1l111_l1_ (u"ࠩࠣࠤ็์วสࠢล๎ࠥ็๊ๅ็้๋ࠣࠦๅ้ไ฼๋๊ࠦࠠࠨ㮥"),l1l111_l1_ (u"ࠪࠫ㮦"),28)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㮧"),l1l111_l1_ (u"ࠬࡥࡍࡓࡈࡢࠫ㮨")+l1l111_l1_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ㮩"),l1l111_l1_ (u"ࠧࠨ㮪"),41)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㮫"),l1l111_l1_ (u"ࠩࡢࡔࡓ࡚࡟ࠨ㮬")+l1l111_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ㮭"),l1l111_l1_ (u"ࠫࠬ㮮"),38)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㮯"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㮰"),l1l111_l1_ (u"ࠧࠨ㮱"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮲"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠷࡟ࠨ㮳")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอࠥ฿วๆหࠪ㮴"),l1l111_l1_ (u"ࠫࠬ㮵"),102)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮶"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠵ࡣࠬ㮷")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢัหฺฯࠧ㮸"),l1l111_l1_ (u"ࠨࠩ㮹"),103)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮺"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠳ࡠࠩ㮻")+l1l111_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦไๅใะูࠬ㮼"),l1l111_l1_ (u"ࠬ࠭㮽"),104)
	return
def ITEMS(l1llll1llll_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡕࡘࠪ㮾")+l1llll1llll_l1_+l1l111_l1_ (u"ࠧࡠࠩ㮿")
	l1ll11l11l11_l1_ = l1l11l1l1ll_l1_(32)
	payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ㯀"):l1l111_l1_ (u"ࠩࠪ㯁"),l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㯂"):l1ll11l11l11_l1_,l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㯃"):l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㯄"),l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㯅"):l1llll1llll_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㯆"),l111l1_l1_,payload,l1l111_l1_ (u"ࠨࠩ㯇"),l1l111_l1_ (u"ࠩࠪ㯈"),l1l111_l1_ (u"ࠪࠫ㯉"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㯊"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠬ࠮࡛࡟࠽࡟ࡶࡡࡴ࡝ࠬࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠭㯋"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"࠭ࡡ࡭ࠩ㯌"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯍"))
			start = start.replace(l1l111_l1_ (u"ࠨࡇ࡯ࠫ㯎"),l1l111_l1_ (u"ࠩࡄࡰࠬ㯏"))
			start = start.replace(l1l111_l1_ (u"ࠪࡅࡑ࠭㯐"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯑"))
			start = start.replace(l1l111_l1_ (u"ࠬࡋࡌࠨ㯒"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯓"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠧࡂ࡮࠰ࠫ㯔"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㯕"))
			start = start.replace(l1l111_l1_ (u"ࠩࡄࡰࠥ࠭㯖"),l1l111_l1_ (u"ࠪࡅࡱ࠭㯗"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l1111l_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠫࠨ࠭㯘") in source: continue
			if source!=l1l111_l1_ (u"࡛ࠬࡒࡍࠩ㯙"): name = name+l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࠣࠤࠬ㯚")+source+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㯛")
			url = source+l1l111_l1_ (u"ࠨ࠽࠾ࠫ㯜")+server+l1l111_l1_ (u"ࠩ࠾࠿ࠬ㯝")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠪ࠿ࡀ࠭㯞")+l1llll1llll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㯟"),l1lllll_l1_+l1l111_l1_ (u"ࠬ࠭㯠")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㯡"),l1lllll_l1_+l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㯢"),l1l111_l1_ (u"ࠨࠩ㯣"),9999)
	return
def PLAY(id):
	source,server,l1l1l1111l_l1_,l1llll1llll_l1_ = id.split(l1l111_l1_ (u"ࠩ࠾࠿ࠬ㯤"))
	url = l1l111_l1_ (u"ࠪࠫ㯥")
	l1ll11l11l11_l1_ = l1l11l1l1ll_l1_(32)
	if source==l1l111_l1_ (u"࡚ࠫࡘࡌࠨ㯦"): url = l1l1l1111l_l1_
	elif source==l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㯧"):
		url = l1l11l1_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㯨")][0]+l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ㯩")+l1l1l1111l_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㯪"),url)
		return
	elif source==l1l111_l1_ (u"ࠩࡊࡅࠬ㯫"):
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㯬") : l1l111_l1_ (u"ࠫࠬ㯭"), l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㯮") : l1ll11l11l11_l1_ , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㯯") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠱ࠨ㯰") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㯱") : l1l111_l1_ (u"ࠩࠪ㯲") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㯳"),l111l1_l1_,payload,l1l111_l1_ (u"ࠫࠬ㯴"),False,l1l111_l1_ (u"ࠬ࠭㯵"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㯶"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㯷"),l1l111_l1_ (u"ࠨࠩ㯸"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㯹"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㯺"))
			return
		html = response.content
		cookies = response.cookies
		l1ll111ll1l1_l1_ = cookies[l1l111_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤࠨ㯻")]
		url = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㯼")]
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㯽") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㯾") : l1ll11l11l11_l1_ , l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㯿") : l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠴ࠪ㰀") , l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㰁") : l1l111_l1_ (u"ࠫࠬ㰂") }
		headers = { l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ㰃") : l1l111_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࡀࠫ㰄")+l1ll111ll1l1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㰅"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠨࠩ㰆"),l1l111_l1_ (u"ࠩࠪ㰇"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㰈"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㰉"),l1l111_l1_ (u"ࠬ࠭㰊"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㰋"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㰌"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ㰍"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1ll111ll11l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠼࠳࠭㰎")+server+l1l111_l1_ (u"ࠪ࠻࠼࠽࠯ࠨ㰏")+l1l1l1111l_l1_+l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㰐")+params
		l1ll111ll111_l1_ = l1ll111ll11l_l1_.replace(l1l111_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㰑"),l1l111_l1_ (u"࠭࠴࠱࠼࠺ࠫ㰒")).replace(l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㰓"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㰔"))
		l1ll111ll1ll_l1_ = l1ll111ll11l_l1_.replace(l1l111_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㰕"),l1l111_l1_ (u"ࠪ࠸࠷ࡀ࠷ࠨ㰖")).replace(l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㰗"),l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㰘"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"࠭ࡈࡅࠩ㰙"),l1l111_l1_ (u"ࠧࡔࡆ࠴ࠫ㰚"),l1l111_l1_ (u"ࠨࡕࡇ࠶ࠬ㰛")]
		l1llll_l1_ = [l1ll111ll11l_l1_,l1ll111ll111_l1_,l1ll111ll1ll_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠩࡑࡘࠬ㰜"):
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㰝") : l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㰞") }
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㰟") : l1l1l1111l_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰠") : l1ll11l11l11_l1_ , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰡") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡔࡔࠨ㰢") , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰣") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㰤"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠫࠬ㰥"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㰦"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㰧"),l1l111_l1_ (u"ࠧࠨ㰨"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㰩"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㰪"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㰫")]
		url = url.replace(l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㰬"),l1l111_l1_ (u"ࠬࠦࠧ㰭"))
		url = url.replace(l1l111_l1_ (u"࠭ࠥ࠴ࡆࠪ㰮"),l1l111_l1_ (u"ࠧ࠾ࠩ㰯"))
		if l1l111_l1_ (u"ࠨࡎࡨࡥࡷࡴࠧ㰰") in l1l1l1111l_l1_:
			url = url.replace(l1l111_l1_ (u"ࠩࡑࡘࡓࡔࡩ࡭ࡧࠪ㰱"),l1l111_l1_ (u"ࠪࠫ㰲"))
			url = url.replace(l1l111_l1_ (u"ࠫࡱ࡫ࡡࡳࡰ࡬ࡲ࡬࠷ࠧ㰳"),l1l111_l1_ (u"ࠬࡒࡥࡢࡴࡱ࡭ࡳ࡭ࠧ㰴"))
	elif source==l1l111_l1_ (u"࠭ࡐࡍࠩ㰵"):
		payload = { l1l111_l1_ (u"ࠧࡪࡦࠪ㰶") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㰷") : l1ll11l11l11_l1_ , l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㰸") : l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡑࡎࠪ㰹") , l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㰺") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㰻"), l111l1_l1_, payload, l1l111_l1_ (u"࠭ࠧ㰼"),False,l1l111_l1_ (u"ࠧࠨ㰽"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ㰾"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㰿"),l1l111_l1_ (u"ࠪࠫ㱀"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㱁"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㱂"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㱃")]
		headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㱄"):response.headers[l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㱅")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㱆"),url, l1l111_l1_ (u"ࠪࠫ㱇"),headers , l1l111_l1_ (u"ࠫࠬ㱈"),l1l111_l1_ (u"ࠬ࠭㱉"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ㱊"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㱋"),l1l111_l1_ (u"ࠨࠩ㱌"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㱍"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㱎"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㱏"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"࡚ࠬࡁࠨ㱐"),l1l111_l1_ (u"࠭ࡆࡎࠩ㱑"),l1l111_l1_ (u"࡚ࠧࡗࠪ㱒"),l1l111_l1_ (u"ࠨ࡙ࡖ࠵ࠬ㱓"),l1l111_l1_ (u"࡚ࠩࡗ࠷࠭㱔"),l1l111_l1_ (u"ࠪࡖࡑ࠷ࠧ㱕"),l1l111_l1_ (u"ࠫࡗࡒ࠲ࠨ㱖")]:
		if source==l1l111_l1_ (u"࡚ࠬࡁࠨ㱗"): l1l1l1111l_l1_ = id
		headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㱘") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㱙") }
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㱚") : l1l1l1111l_l1_ , l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㱛") : l1ll11l11l11_l1_ , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㱜") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࠩ㱝")+source , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㱞") : l1llll1llll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㱟"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠧࠨ㱠"),l1l111_l1_ (u"ࠨࠩ㱡"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ㱢"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㱣"),l1l111_l1_ (u"ࠫࠬ㱤"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㱥"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㱦"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㱧")]
		if source==l1l111_l1_ (u"ࠨࡈࡐࠫ㱨"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㱩"), url, l1l111_l1_ (u"ࠪࠫ㱪"), l1l111_l1_ (u"ࠫࠬ㱫"), False,l1l111_l1_ (u"ࠬ࠭㱬"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠼ࡺࡨࠨ㱭"))
			url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㱮")]
			url = url.replace(l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㱯"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㱰"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㱱"))
	return
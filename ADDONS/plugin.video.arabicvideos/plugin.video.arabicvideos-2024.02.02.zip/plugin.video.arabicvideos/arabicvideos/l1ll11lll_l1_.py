﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩඉ")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬඊ"):l1l111_l1_ (u"ࠩࠪඋ")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩඌ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊ส้ษุ่ࠥอไศฮอ้ฬ฿๊ࠨඍ"),l1l111_l1_ (u"ࠬ฻่าࠢส่ฯ๎วึๆࠣห้อฬห็ส฽๏࠭ඎ"),l1l111_l1_ (u"࠭ราึํๅࠥาๅ๋฻ࠣห้ฮัศ็ฯࠫඏ")]
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==40: l1lll_l1_ = l1l1l11_l1_()
	elif mode==41: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==42: l1lll_l1_ = l1ll11l11_l1_(text,l1llllll1_l1_)
	elif mode==43: l1lll_l1_ = PLAY(url)
	elif mode==44: l1lll_l1_ = l1lll11_l1_(text,l1llllll1_l1_)
	elif mode==49: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬඐ"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣหู้๋ศำไࠫඑ"),l1l111_l1_ (u"ࠩࠪඒ"),41)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪඓ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫඔ"),l1l111_l1_ (u"ࠬ࠭ඕ"),49)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫඖ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ඗"),l1l111_l1_ (u"ࠨࠩ඘"),9999)
	l1ll11l11_l1_(l1l111_l1_ (u"ࠩࠪ඙"),l1l111_l1_ (u"ࠪ࠵ࠬක"))
	return
def l1ll111l1_l1_(options,l1ll11l1l_l1_):
	search,sort,l1111l1l_l1_,category,l1ll1l11l_l1_ = l1l111_l1_ (u"ࠫࠬඛ"),[],[],[],[]
	dummy,l1ll111ll_l1_ = l1ll11ll1_l1_(options)
	for option in list(l1ll111ll_l1_.keys()):
		value = l1ll111ll_l1_[option]
		if not value: continue
		if   option==l1l111_l1_ (u"ࠬࡹ࡯ࡳࡶࠪග"): sort = [value]
		elif option==l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ඝ"): l1111l1l_l1_ = [value]
		elif option==l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧඞ"): search = value
		elif option==l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪඟ"): category = [value]
		elif option==l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࡬ࡷࡹ࠭ච"): l1ll1l11l_l1_ = [value]
	payload = {l1l111_l1_ (u"ࠥࡥࡨࡺࡩࡰࡰࠥඡ"):l1l111_l1_ (u"ࠦ࡫ࡧࡣࡦࡶࡺࡴࡤࡸࡥࡧࡴࡨࡷ࡭ࠨජ"),l1l111_l1_ (u"ࠧࡪࡡࡵࡣࠥඣ"):{l1l111_l1_ (u"ࠨࡦࡢࡥࡨࡸࡸࠨඤ"):{l1l111_l1_ (u"ࠢࡴࡧࡤࡶࡨ࡮ࠢඥ"):search,l1l111_l1_ (u"ࠣࡸ࡬ࡨࡪࡵ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠦඦ"):category,l1l111_l1_ (u"ࠤࡶࡴࡪࡩࡩࡢ࡮࡬ࡷࡹࠨට"):l1ll1l11l_l1_,l1l111_l1_ (u"ࠥࡷࡪࡸࡩࡦࡵࠥඨ"):l1111l1l_l1_,l1l111_l1_ (u"ࠦࡳࡻ࡭ࡣࡧࡵࠦඩ"):[],l1l111_l1_ (u"ࠧࡹ࡯ࡳࡶࡢࡺ࡮ࡪࡥࡰࠤඪ"):sort,l1l111_l1_ (u"ࠨࡣࡰࡷࡱࡸࠧණ"):[],l1l111_l1_ (u"ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦඬ"):[]},l1l111_l1_ (u"ࠣࡨࡵࡳࡿ࡫࡮ࡠࡨࡤࡧࡪࡺࡳࠣත"):{},l1l111_l1_ (u"ࠤࡷࡩࡲࡶ࡬ࡢࡶࡨࠦථ"):l1l111_l1_ (u"ࠥࡺ࡮ࡪࡥࡰࡡࡧࡩࡸࡱࡴࡰࡲࡢࡴࡴࡹࡴࡴࠤද"),l1l111_l1_ (u"ࠦࡪࡾࡴࡳࡣࡶࠦධ"):{l1l111_l1_ (u"ࠧࡹ࡯ࡳࡶࠥන"):l1l111_l1_ (u"ࠨࡤࡦࡨࡤࡹࡱࡺࠢ඲")},l1l111_l1_ (u"ࠢࡴࡱࡩࡸࡤࡸࡥࡧࡴࡨࡷ࡭ࠨඳ"):0,l1l111_l1_ (u"ࠣ࡫ࡶࡣࡧ࡬ࡣࡢࡥ࡫ࡩࠧප"):1,l1l111_l1_ (u"ࠤࡩ࡭ࡷࡹࡴࡠ࡮ࡲࡥࡩࠨඵ"):0,l1l111_l1_ (u"ࠥࡴࡦ࡭ࡥࡥࠤබ"):int(l1ll11l1l_l1_)}}
	import json
	payload = json.dumps(payload)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪ࠲ࡻࡵ࠳ࡪࡴࡱࡱ࠳࡫ࡧࡣࡦࡶࡺࡴ࠴ࡼ࠱࠰ࡴࡨࡪࡷ࡫ࡳࡩࠩභ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪම"),l1ll1ll_l1_,payload,l1l111_l1_ (u"࠭ࠧඹ"),l1l111_l1_ (u"ࠧࠨය"),l1l111_l1_ (u"ࠨࠩර"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡗࡋࡑࡖࡇࡖࡘࡤࡊࡁࡕࡃࡢࡔࡆࡍࡅ࠮࠳ࡶࡸࠬ඼"))
	html = response.content
	data = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨල"),html)
	return data
def l1ll11l11_l1_(options,level):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1l111_l1_ (u"ࠫ࠶࠭඾"))
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠬ࡬ࡡࡤࡧࡷࡷࠬ඿")]
	if level==l1l111_l1_ (u"࠭࠱ࠨව"):
		block = block[l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡥࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࠪශ")]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡧ࡭ࡻ࠮࠮ࠫࡁࠬ࠳ࡩ࡯ࡶ࠿ࠩෂ"),block,re.DOTALL)
		for item in items:
			tmp = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡷࡣ࡯ࡹࡪࡃ࡜࡝ࠤࠫ࠲࠯ࡅࠩ࡝࡞ࠥ࠲࠯ࡅࡤࡪࡵࡳࡰࡦࡿ࠭ࡷࡣ࡯ࡹࡪࡢ࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩස"),item+l1l111_l1_ (u"ࠪࡀࠬහ"),re.DOTALL)
			if not tmp: tmp = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡹࡥࡱࡻࡥ࠾࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ළ"),item+l1l111_l1_ (u"ࠬࡂࠧෆ"),re.DOTALL)
			category,title = tmp[0]
			if not options: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෇"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ෈")+l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ෉"),42,l1l111_l1_ (u"්ࠩࠪ"),l1l111_l1_ (u"ࠪ࠶ࠬ෋"),l1l111_l1_ (u"ࠫࡄࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ෌")+category)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෍"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ෎"),42,l1l111_l1_ (u"ࠧࠨා"),l1l111_l1_ (u"ࠨ࠴ࠪැ"),options+l1l111_l1_ (u"ࠩࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭ෑ")+category)
	if level==l1l111_l1_ (u"ࠪ࠶ࠬි"):
		block = block[l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࡮ࡹࡴࠨී")]
		items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨු"),block,re.DOTALL)
		for l1ll1l11l_l1_,title in items:
			if not l1ll1l11l_l1_: title = title = l1l111_l1_ (u"࠭วๅฮ่๎฾࠭෕")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧූ"),l1lllll_l1_+title,l1l111_l1_ (u"ࠨࠩ෗"),42,l1l111_l1_ (u"ࠩࠪෘ"),l1l111_l1_ (u"ࠪ࠷ࠬෙ"),options+l1l111_l1_ (u"ࠫࠫࡹࡰࡦࡥ࡬ࡥࡱ࡯ࡳࡵ࠿ࠪේ")+l1ll1l11l_l1_)
	elif level==l1l111_l1_ (u"ࠬ࠹ࠧෛ"):
		block = block[l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ො")]
		items = re.findall(l1l111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪෝ"),block,re.DOTALL)
		for l1111l1l_l1_,title in items:
			if not l1111l1l_l1_: title = title = l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨෞ")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩෟ"),l1lllll_l1_+title,l1l111_l1_ (u"ࠪࠫ෠"),42,l1l111_l1_ (u"ࠫࠬ෡"),l1l111_l1_ (u"ࠬ࠺ࠧ෢"),options+l1l111_l1_ (u"࠭ࠦࡴࡧࡵ࡭ࡪࡹ࠽ࠨ෣")+l1111l1l_l1_)
	elif level==l1l111_l1_ (u"ࠧ࠵ࠩ෤"):
		block = block[l1l111_l1_ (u"ࠨࡵࡲࡶࡹࡥࡶࡪࡦࡨࡳࠬ෥")]
		items = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ෦"),block,re.DOTALL)
		for sort,title in items:
			if not sort: continue
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෧"),l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬ෨"),44,l1l111_l1_ (u"ࠬ࠭෩"),l1l111_l1_ (u"࠭࠱ࠨ෪"),options+l1l111_l1_ (u"ࠧࠧࡵࡲࡶࡹࡃࠧ෫")+sort)
	return
def l1lll11_l1_(options,l1ll11l1l_l1_):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1ll11l1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠨࡶࡨࡱࡵࡲࡡࡵࡧࠪ෬")]
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ෭"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ෮"),l1lllll_l1_+title,l1ll1ll_l1_,43,l1ll1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡶࡶࠫ෯")][l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ෰")]
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡵࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ෱"),block,re.DOTALL)
	for l1llllll1_l1_,title in items:
		if l1ll11l1l_l1_==l1llllll1_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧෲ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧෳ")+title,l1l111_l1_ (u"ࠩࠪ෴"),44,l1l111_l1_ (u"ࠪࠫ෵"),l1llllll1_l1_,options)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ෶"),url,l1l111_l1_ (u"ࠬ࠭෷"),l1l111_l1_ (u"࠭ࠧ෸"),l1l111_l1_ (u"ࠧࠨ෹"),l1l111_l1_ (u"ࠨࠩ෺"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭෻"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ෼"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࡤࡻࡲ࡭࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠦࠨ෽"),html,re.DOTALL)
	l1ll11l1_l1_ = []
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ෾"),l1l111_l1_ (u"࠭࠯ࠨ෿"))
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭฀"),url)
	return
def l1ll1llll_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬก"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ฬะ࠳ๅษษืีࠬข"),l1l111_l1_ (u"ࠪࠫฃ"),l1l111_l1_ (u"ࠫࠬค"),l1l111_l1_ (u"ࠬ࠭ฅ"),l1l111_l1_ (u"࠭ࠧฆ"),l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫง"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭จ"),html,re.DOTALL)
	url = l111l11_l1_(items[0])
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧฉ"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	l1ll1l111_l1_ = False
	if search==l1l111_l1_ (u"ࠪࠫช"):
		search = l1llll1_l1_()
		l1ll1l111_l1_ = True
	if search==l1l111_l1_ (u"ࠫࠬซ"): return
	if not l1ll1l111_l1_: l1lll11_l1_(l1l111_l1_ (u"ࠬࡅࡳࡦࡣࡵࡧ࡭ࡃࠧฌ")+search,l1l111_l1_ (u"࠭࠱ࠨญ"))
	else: l1ll11l11_l1_(l1l111_l1_ (u"ࠧࡀࡵࡨࡥࡷࡩࡨ࠾ࠩฎ")+search,l1l111_l1_ (u"ࠨ࠳ࠪฏ"))
	return
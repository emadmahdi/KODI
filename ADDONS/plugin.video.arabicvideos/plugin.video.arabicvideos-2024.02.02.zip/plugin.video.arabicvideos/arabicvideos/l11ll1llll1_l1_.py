# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ峪")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ峫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11l1111llll_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l11l1111ll1l_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l11l11l1llll_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l11l11l11111_l1_()
	elif mode==148: l1lll_l1_ = l11l11l111l1_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ峬"),l1lllll_l1_+l1l111_l1_ (u"ࠪๆฬฬๅสࠩ峭"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡂ࡬࠸ࡋࡸ࠾ࡆࡉ࠺࡝ࡲ࡚ࡨࡆ࠱ࡔ࡙࠱࠼ࡍ࠳ࡃࡱࡴࡍࡾࡠࡁ࠵ࡷࡖࡅࠬ峮"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ峯"),l1lllll_l1_+l1l111_l1_ (u"࠭ิฯืࠪ峰"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࡔࡄࡐࡲࡪ࡫࡯ࡣࡪࡣ࡯ࠫ峱"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峲"),l1lllll_l1_+l1l111_l1_ (u"่ࠩ์็฿ࠧ峳"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡲ࠷࠼ࡥࡌࡔࡳࡲ࠻ࡥࡦ࡭ࡽࡖࡕࡳ࠴࡙ࡹࡼࡧࡸࠩ峴"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ峵"),l1lllll_l1_+l1l111_l1_ (u"ࠬำำศสࠪ島"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡁࡖ࡫ࡩࡘࡵࡣࡪࡣ࡯ࡇ࡙࡜ࠧ峷"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峸"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็฽ฬฮࠧ峹"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ峺"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ峻"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠪ峼"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ峽"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峾"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆะอหึอสࠨ峿"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ崀"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崁"),l1lllll_l1_+l1l111_l1_ (u"ࠪๆฺ๐ัสࠩ崂"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ崃"),144,l1l111_l1_ (u"ࠬ࠭崄"),l1l111_l1_ (u"࠭ࠧ崅"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ崆"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崇"),l1lllll_l1_+l1l111_l1_ (u"ࠩอูๆำࠧ崈"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭崉"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崊"),l1lllll_l1_+l1l111_l1_ (u"ࠬืฦ๋ีํอࠬ崋"),l111l1_l1_+l1l111_l1_ (u"࠭ࠧ崌"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崍"),l1lllll_l1_+l1l111_l1_ (u"ࠨำสสั࠭崎"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࡂࡦࡵࡃࠧ崏"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ崐"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭崑"),l1l111_l1_ (u"ࠬ࠭崒"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崓"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ崔"),l1l111_l1_ (u"ࠨࠩ崕"),149,l1l111_l1_ (u"ࠩࠪ崖"),l1l111_l1_ (u"ࠪࠫ崗"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ崘"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ崙"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ崚"),l1l111_l1_ (u"ࠧࠨ崛"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ崜"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ崝"),l111l1_l1_+l1l111_l1_ (u"ࠪࠫ崞"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崟"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไาษษะฮ࠭崠"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ崡"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崢"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ฮฺ็อࠨ崣"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ崤"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崥"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊โึ์ิอࠬ崦"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭崧"),144,l1l111_l1_ (u"࠭ࠧ崨"),l1l111_l1_ (u"ࠧࠨ崩"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ崪"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崫"),l1lllll_l1_+l1l111_l1_ (u"้ࠪำะวาษอࠤ๏๎ส๋๊หࠫ崬"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ崭"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ崮"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅฯฬสีฬะࠠศๆหี๋อๅอࠩ崯"),l1l111_l1_ (u"ࠧࠨ崰"),290)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭崱"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ崲"),l1l111_l1_ (u"ࠪࠫ崳"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崴"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢ฼ีอ๐ษࠨ崵"),l1l111_l1_ (u"࠭ࠧ崶"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崷"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ崸"),l1l111_l1_ (u"ࠩࠪ崹"),148)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崺"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡ฻ิฬ๏ฯࠧ崻"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃแ๋ๆ่ࠫ崼"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崽"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤฬาๆษ์ฬࠫ崾"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡰࡳࡻ࡯ࡥࠨ崿"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嵀"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึีา๐วหࠢ฼ีอ๐ษࠨ嵁"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำาฯํอࠬ嵂"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嵃"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥ฿ัษ์ฬࠫ嵄"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึุ่๊ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ嵅"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嵆"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ嵇"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ嵈"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵉"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ่อัห๊้ࠫ嵊"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ไษิฮํ์ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ嵋"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵌"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭嵍"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭嵎"),144)
	return
def l11l1111ll1l_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵏"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡈࡎࡎࡍ࠼ࠣࠤࠬ嵐")+name,url,144,l11l_l1_)
	return
def l11l11l11111_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯อัࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ嵑"))
	return
def l11l11l111l1_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡵࡸࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ嵒"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠧࠧࠩ嵓"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l11l111ll11l_l1_(yccc,url,index):
	level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵔"))
	l11l1111l1ll_l1_,l11l111ll1l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ嵕") in url: l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞ࠤ嵖"))
	if l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ嵗") in url: l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࠧ嵘"))
	if level==l1l111_l1_ (u"࠭࠱ࠨ嵙"): l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡧࡧࡨࡨࡋ࡯࡬ࡵࡧࡵࡇ࡭࡯ࡰࡃࡣࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ嵚"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嵛"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࠧ嵜"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡨࡲࡹࡸࡩࡦࡵࠪࡡࠧ嵝"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾࡩࡣࡤ࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠ࡟࠸ࡣ࡛ࠨࡩࡸ࡭ࡩ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ嵞"))
	l11l11l11l1l_l1_,yddd,l11l111ll111_l1_ = l11l1111l11l_l1_(yccc,l1l111_l1_ (u"ࠬ࠭嵟"),l11l1111l1ll_l1_)
	if level==l1l111_l1_ (u"࠭࠱ࠨ嵠") and l11l11l11l1l_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭嵡") not in url:
			for zz in range(len(yddd)):
				l11l111l11l1_l1_ = str(zz)
				l11l1111l1ll_l1_ = []
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ嵢")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ嵣"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ嵤")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࠨ࡟ࠥ嵥"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ嵦")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨ࡝ࠣ嵧"))
				succeeded,item,l1111ll1_l1_ = l11l1111l11l_l1_(yddd,l1l111_l1_ (u"ࠧࠨ嵨"),l11l1111l1ll_l1_)
				if succeeded: l11l111ll1l1_l1_.append([item,url,l1l111_l1_ (u"ࠨ࠴࠽࠾ࠬ嵩")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ嵪")])
			l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠࠦ嵫"))
			succeeded,item,l1111ll1_l1_ = l11l1111l11l_l1_(yccc,l1l111_l1_ (u"ࠫࠬ嵬"),l11l1111l1ll_l1_)
			if succeeded and l11l111ll1l1_l1_ and l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ嵭") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ嵮")
				l11l111ll1l1_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ嵯")])
	return yddd,l11l11l11l1l_l1_,l11l111ll1l1_l1_,l11l111ll111_l1_
def l11l11111ll1_l1_(yccc,yddd,url,index):
	level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵰"))
	l11l1111l1ll_l1_,l11l111ll1ll_l1_ = [],[]
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵱"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ嵲")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ嵳"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠵ࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ嵴"))
	if l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ嵵") in url: l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ嵶"))
	elif l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ嵷") in url: l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ嵸"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ嵹")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ嵺"))
	if l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭嵻") in url or (l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ嵼") in url and l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ嵽") not in url):
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ嵾")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ嵿"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ嶀")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ嶁"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ嶂")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ嶃"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ嶄")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嶅"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛ࠣ嶆")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠥࡡࠧ嶇"))
	l11l11l111ll_l1_,yeee,l11l111l1lll_l1_ = l11l1111l11l_l1_(yddd,l1l111_l1_ (u"ࠫࠬ嶈"),l11l1111l1ll_l1_)
	if level==l1l111_l1_ (u"ࠬ࠸ࠧ嶉") and l11l11l111ll_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l11l1111l1ll_l1_ = []
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嶊")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ嶋"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嶌")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ嶍"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ嶎")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ嶏"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嶐")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ嶑"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嶒")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ嶓"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ嶔")+index2+l1l111_l1_ (u"ࠥࡡࠧ嶕"))
				succeeded,item,l1111ll1_l1_ = l11l1111l11l_l1_(yeee,l1l111_l1_ (u"ࠫࠬ嶖"),l11l1111l1ll_l1_)
				if succeeded: l11l111ll1ll_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠹࠺࠻ࠩ嶗")+l11l111l11l1_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ嶘")+index2+l1l111_l1_ (u"ࠧ࠻࠼࠳ࠫ嶙")])
			l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠲࡟ࠥ嶚"))
			l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡨࡩࡪ࡛࠲࡟ࠥ嶛"))
			succeeded,item,l1111ll1_l1_ = l11l1111l11l_l1_(yddd,l1l111_l1_ (u"ࠪࠫ嶜"),l11l1111l1ll_l1_)
			if succeeded and l11l111ll1ll_l1_ and l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ嶝") in list(item.keys()):
				l11l111ll1ll_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ嶞")])
	return yeee,l11l11l111ll_l1_,l11l111ll1ll_l1_,l11l111l1lll_l1_
def l11l1111lll1_l1_(yccc,yeee,url,index):
	level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ嶟"))
	l11l1111l1ll_l1_,l11l111l1111_l1_ = [],[]
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嶠")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡻ࡫ࡲࡵ࡫ࡦࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ嶡"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ嶢")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ嶣"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ嶤")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ嶥"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ嶦")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嶧"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ嶨")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ嶩"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ嶪")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡩࡽࡶࡡ࡯ࡦࡨࡨࡘ࡮ࡥ࡭ࡨࡆࡳࡳࡺࡥ࡯ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ嶫"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嶬")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ嶭"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嶮")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嶯"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嶰"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ嶱"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嶲"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ嶳")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ嶴"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ嶵")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ嶶"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫ࠢ嶷"))
	l11l11l11lll_l1_,yfff,l11l11ll111l_l1_ = l11l1111l11l_l1_(yeee,l1l111_l1_ (u"ࠪࠫ嶸"),l11l1111l1ll_l1_)
	if level==l1l111_l1_ (u"ࠫ࠸࠭嶹") and l11l11l11lll_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l11l111l1l11_l1_ = str(zz)
				l11l1111l1ll_l1_ = []
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ嶺")+l11l111l1l11_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ嶻"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡨࡩࡪࡠࠨ嶼")+l11l111l1l11_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ嶽"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡪ࡫࡬࡛ࠣ嶾")+l11l111l1l11_l1_+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ嶿"))
				l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾ࡬ࡦࡧ࡝ࠥ巀")+l11l111l1l11_l1_+l1l111_l1_ (u"ࠧࡣࠢ巁"))
				succeeded,item,l1111ll1_l1_ = l11l1111l11l_l1_(yfff,l1l111_l1_ (u"࠭ࠧ巂"),l11l1111l1ll_l1_)
				if succeeded: l11l111l1111_l1_.append([item,url,l1l111_l1_ (u"ࠧ࠵࠼࠽ࠫ巃")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巄")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巅")+l11l111l1l11_l1_])
	return yfff,l11l11l11lll_l1_,l11l111l1111_l1_,l11l11ll111l_l1_
def l11l1111l11l_l1_(l1l1llll1lll_l1_,l1l1lllllll1_l1_,l11l111l111l_l1_):
	yccc,l1l1lllllll1_l1_ = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	yddd,l1l1lllllll1_l1_ = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	yeee,l1l1lllllll1_l1_ = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	yfff,l1l1lllllll1_l1_ = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	item,yrender = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	count = len(l11l111l111l_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l111l111l_l1_[l1l111llll_l1_])
			return True,out,l1l111llll_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠪࠫ巆"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠫࠬ巇"),data=l1l111_l1_ (u"ࠬ࠭巈")):
	l11l111ll1l1_l1_,l11l111ll1ll_l1_,l11l111l1111_l1_ = [],[],[]
	if l1l111_l1_ (u"࠭࠺࠻ࠩ巉") not in index: index = l1l111_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ巊")
	level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = index.split(l1l111_l1_ (u"ࠨ࠼࠽ࠫ巋"))
	if level==l1l111_l1_ (u"ࠩ࠷ࠫ巌"): level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = l1l111_l1_ (u"ࠪ࠵ࠬ巍"),l11l111l11l1_l1_,index2,l11l111l1l11_l1_
	data = data.replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ巎"),l1l111_l1_ (u"ࠬ࠭巏"))
	html,yccc,l1l11llll_l1_ = l11l111lll11_l1_(url,data)
	index = level+l1l111_l1_ (u"࠭࠺࠻ࠩ巐")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ巑")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巒")+l11l111l1l11_l1_
	if level in [l1l111_l1_ (u"ࠩ࠴ࠫ巓"),l1l111_l1_ (u"ࠪ࠶ࠬ巔"),l1l111_l1_ (u"ࠫ࠸࠭巕")]:
		yddd,l11l11l11l1l_l1_,l11l111ll1l1_l1_,l11l111ll111_l1_ = l11l111ll11l_l1_(yccc,url,index)
		if not l11l11l11l1l_l1_: return
		l1llll1l1l_l1_ = len(l11l111ll1l1_l1_)
		if l1llll1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠬ࠷ࠧ巖"): level = l1l111_l1_ (u"࠭࠲ࠨ巗")
			l11l111ll1l1_l1_ = []
	index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ巘")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巙")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巚")+l11l111l1l11_l1_
	if level in [l1l111_l1_ (u"ࠪ࠶ࠬ巛"),l1l111_l1_ (u"ࠫ࠸࠭巜")]:
		yeee,l11l11l111ll_l1_,l11l111ll1ll_l1_,l11l111l1lll_l1_ = l11l11111ll1_l1_(yccc,yddd,url,index)
		if not l11l11l111ll_l1_: return
		l1ll1l111l_l1_ = len(l11l111ll1ll_l1_)
		if l1ll1l111l_l1_<2:
			if level==l1l111_l1_ (u"ࠬ࠸ࠧ川"): level = l1l111_l1_ (u"࠭࠳ࠨ州")
			l11l111ll1ll_l1_ = []
	index = level+l1l111_l1_ (u"ࠧ࠻࠼ࠪ巟")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ巠")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ巡")+l11l111l1l11_l1_
	if level in [l1l111_l1_ (u"ࠪ࠷ࠬ巢")]:
		yfff,l11l11l11lll_l1_,l11l111l1111_l1_,l11l11ll111l_l1_ = l11l1111lll1_l1_(yccc,yeee,url,index)
		if not l11l11l11lll_l1_: return
		l1ll1l11l1_l1_ = len(l11l111l1111_l1_)
	for item,url,index in l11l111ll1l1_l1_+l11l111ll1ll_l1_+l11l111l1111_l1_:
		l1ll1ll1ll11_l1_ = l11l1111ll11_l1_(item,url,index)
	return
def l11l1111ll11_l1_(item,url=l1l111_l1_ (u"ࠫࠬ巣"),index=l1l111_l1_ (u"ࠬ࠭巤")):
	if l1l111_l1_ (u"࠭࠺࠻ࠩ工") in index: level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = index.split(l1l111_l1_ (u"ࠧ࠻࠼ࠪ左"))
	else: level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ巧"),l1l111_l1_ (u"ࠩ࠳ࠫ巨"),l1l111_l1_ (u"ࠪ࠴ࠬ巩"),l1l111_l1_ (u"ࠫ࠵࠭巪")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_,l11l11l1lll1_l1_ = l11l11ll11ll_l1_(item)
	l1lllll1ll11_l1_ = l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸࡅࠧ巫") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡴࡶࡵࡩࡦࡳࡳࡀࠩ巬") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ巭") in l1ll1ll_l1_
	l1lllll1l1l1_l1_ = l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ差") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࡂࠫ巯") in l1ll1ll_l1_
	if l1lllll1ll11_l1_ or l1lllll1l1l1_l1_: l1ll1ll_l1_ = url
	l1lllll1ll11_l1_ = l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ巰") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭己") not in l1ll1ll_l1_
	l1lllll1l1l1_l1_ = l1l111_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭已") not in l1ll1ll_l1_  and l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ巳") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀࠧ巴") and l1lllll1ll11_l1_ and l1lllll1l1l1_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ巵") in url or l1l111_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ巶") in l1ll1ll_l1_:
		level,l11l111l11l1_l1_,index2,l11l111l1l11_l1_ = l1l111_l1_ (u"ࠪ࠵ࠬ巷"),l1l111_l1_ (u"ࠫ࠵࠭巸"),l1l111_l1_ (u"ࠬ࠶ࠧ巹"),l1l111_l1_ (u"࠭࠰ࠨ巺")
		index = l1l111_l1_ (u"ࠧࠨ巻")
	l1l11llll_l1_ = l1l111_l1_ (u"ࠨࠩ巼")
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࠨ巽") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ巾") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ巿") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ帀"))
		if data.count(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ币"))==4:
			l11l11l11ll1_l1_,key,l11l11l1111l_l1_,l11l111llll1_l1_,token = data.split(l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ市"))
			l1l11llll_l1_ = l11l11l11ll1_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ布")+key+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭帄")+l11l11l1111l_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ帅")+l11l111llll1_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ帆")+l11l11l1lll1_l1_
			if l1l111_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ帇") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ师")+key
	if not title:
		global l11l1111llll_l1_
		l11l1111llll_l1_ += 1
		title = l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࠪ帉")+str(l11l1111llll_l1_)
		index = l1l111_l1_ (u"ࠨ࠵ࠪ帊")+l1l111_l1_ (u"ࠩ࠽࠾ࠬ帋")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠪ࠾࠿࠭希")+index2+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帍")+l11l111l1l11_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ帎") in str(item): return False
	elif l1l111_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭帏") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ帐") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ帑") in list(item.keys()) or l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ帒") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠪ࠾࠿࠭帓")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ帔")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ帕")+l11l111l1l11_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭帖"),l1lllll_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ帗")+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ帘"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ帙") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠪ࠾࠿ࠦࠧ帚")+title
		index = l1l111_l1_ (u"ࠫ࠸࠭帛")+l1l111_l1_ (u"ࠬࡀ࠺ࠨ帜")+l11l111l11l1_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ帝")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ帞")+l11l111l1l11_l1_
		url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ帟"),l1l111_l1_ (u"ࠩࠪ帠"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ帡"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠫࠬ帢"),index,l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ帣"))
	elif l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ帤") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠧ࠴ࠩ帥")+l1l111_l1_ (u"ࠨ࠼࠽ࠫ带")+l11l111l11l1_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ帧")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭帨")+l11l111l1l11_l1_
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ帩")+title
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ帪"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫ࠧ師") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠧ࠻࠼ࠣࠫ帬")+title
		index = l1l111_l1_ (u"ࠨ࠴࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ席")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ帮"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ帯") in str(item):
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ帰")+title
		index = l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ帱")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭帲"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ帳") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭帴"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ帵"),9999)
	elif l11l11l1l111_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ帶"),l1lllll_l1_+l11l11l1l111_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭帷") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ常"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ帹")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ帺")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ帻") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ帼"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ帽"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ帾") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ帿") in l1ll1ll_l1_ and count:
			l11l11l11l11_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭幀"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ幁")+l11l11l11l11_l1_
			index = l1l111_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ幂")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ幃"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ幄")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ幅")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ幆"),1)[0]
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ幇"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ幈") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡦ࠳ࠬ幉") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠩ࠲ࡄࠬ幊") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠪ࠳ࠬ幋"))==3):
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ幌"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡉࡈࡏࡎࠪ幍")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ幎")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ幏") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ幐"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡘࡗࡊࡘࠧ幑")+count+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ幒")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨ幓")+title
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ幔"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l11l11ll11ll_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_,token = False,l1l111_l1_ (u"࠭ࠧ幕"),l1l111_l1_ (u"ࠧࠨ幖"),l1l111_l1_ (u"ࠨࠩ幗"),l1l111_l1_ (u"ࠩࠪ幘"),l1l111_l1_ (u"ࠪࠫ幙"),l1l111_l1_ (u"ࠫࠬ幚"),l1l111_l1_ (u"ࠬ࠭幛"),l1l111_l1_ (u"࠭ࠧ幜")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_,token
	for l11l111lllll_l1_ in list(item.keys()):
		yrender = item[l11l111lllll_l1_]
		if isinstance(yrender,dict): break
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ幝"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡐ࡮ࡹࡴࡉࡧࡤࡨࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ幞"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥ࡮࡬ࡲࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ幟"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡻ࡮ࡱ࡮ࡤࡽࡦࡨ࡬ࡦࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ幠"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡦࡰࡴࡰࡥࡹࡺࡥࡥࡖ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ幡"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ幢"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ幣"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ幤"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ幥"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ幦"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ幧"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡺ࡮ࡪࡥࡰࡋࡧࠫࡢࠨ幨"))
	succeeded,title,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ幩"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ幪"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ幫"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ幬"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ幭"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ幮"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ幯"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ幰"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ幱"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ干"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࠧ࡞ࠤ平"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࡕࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ年"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡆࡴࡺࡴࡰ࡯ࡓࡥࡳ࡫࡬ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ幵"))
	succeeded,count,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ并"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ幷"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨ࡮ࡨࡲ࡬ࡺࡨࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ幸"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࠭࡝࡜ࠩ࡬ࡧࡴࡴࡔࡺࡲࡨࠫࡢࠨ幹"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡸࡾࡲࡥࠨ࡟ࠥ幺"))
	succeeded,l1l1lll111_l1_,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ幻"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ幼"))
	succeeded,token,l1111ll1_l1_ = l11l1111l11l_l1_(item,yrender,l11l1111l1ll_l1_)
	if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ幽") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭幾"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ广")
	if l1l111_l1_ (u"ࠧๆสสุึ࠭庀") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1l111_l1_ = l1l111_l1_ (u"ࠨࠩ庁"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ庂")
	if l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ広") in list(yrender.keys()):
		l11l11l1ll11_l1_ = str(yrender[l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ庄")])
		if l1l111_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ庅") in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ庆")
		if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ庇") in l11l11l1ll11_l1_: l11l11l1l111_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ庈")
		if l1l111_l1_ (u"ࠩࡅࡹࡾ࠭庉") in l11l11l1ll11_l1_ or l1l111_l1_ (u"ࠪࡖࡪࡴࡴࠨ床") in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ庋")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡺ࠭ๅษษืีࠬ庌")) in l11l11l1ll11_l1_: l11l11l1l111_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ庍")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡵࠨึิหฦ࠭庎")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ序")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡷࠪหุะฦอษิࠫ庐")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ庑")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡹࠬหูๅษ้หฯ࠭庒")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ库")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ应") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠧࡀࠩ底"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭庖") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ店")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l111lll1l_l1_: title = l11l111lll1l_l1_+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠪ࠰ࠬ庘"),l1l111_l1_ (u"ࠫࠬ庙"))
	count = count.replace(l1l111_l1_ (u"ࠬ࠲ࠧ庚"),l1l111_l1_ (u"࠭ࠧ庛"))
	count = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࠮ࠫ府"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠨࠩ庝")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_,token
def l11l111lll11_l1_(url,data=l1l111_l1_ (u"ࠩࠪ庞"),request=l1l111_l1_ (u"ࠪࠫ废")):
	if request==l1l111_l1_ (u"ࠫࠬ庠"): request = l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ庡")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ庢"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ庣"):l1l111_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ庤")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ庥"))
	if data.count(l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ度"))==4: l11l11l11ll1_l1_,key,l11l11l1111l_l1_,l11l111llll1_l1_,token = data.split(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ座"))
	else: l11l11l11ll1_l1_,key,l11l11l1111l_l1_,l11l111llll1_l1_,token = l1l111_l1_ (u"ࠬ࠭庨"),l1l111_l1_ (u"࠭ࠧ庩"),l1l111_l1_ (u"ࠧࠨ庪"),l1l111_l1_ (u"ࠨࠩ庫"),l1l111_l1_ (u"ࠩࠪ庬")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠥࡧࡴࡴࡴࡦࡺࡷࠦ庭"):{l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ庮"):{l1l111_l1_ (u"ࠧ࡮࡬ࠣ庯"):l1l111_l1_ (u"ࠨࡡࡳࠤ庰"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ庱"):l1l111_l1_ (u"࡙ࠣࡈࡆࠧ庲"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ庳"):l11l11l1111l_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ庴") or l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ庵") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡷ࡫ࡥ࡭࠱ࡵࡩࡪࡲ࡟ࡸࡣࡷࡧ࡭ࡥࡳࡦࡳࡸࡩࡳࡩࡥࠨ庶")+l1l111_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ康")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࡒࡤࡶࡦࡳࡳࠨ庸")] = l11l11l11ll1_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭庹"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ庺"))
	elif l1l111_l1_ (u"ࠪ࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ庻") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ庼")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ庽"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ庾"))
	elif l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ庿") in url and l11l11l11ll1_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ廀")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ廁")][l1l111_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࠪ廂")][l1l111_l1_ (u"ࠫࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠩ廃")] = l11l11l11ll1_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ廄"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠵ࡶ࡫ࠫ廅"))
	elif l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ廆") in url and l11l111llll1_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ廇"):l1l111_l1_ (u"ࠩ࠴ࠫ廈"),l1l111_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ廉"):l11l11l1111l_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ廊"):l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ廋")+l11l111llll1_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ廌"),url,l1l111_l1_ (u"ࠧࠨ廍"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ廎"),l1l111_l1_ (u"ࠩࠪ廏"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠺ࡺࡨࠨ廐"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ廑"),url,l1l111_l1_ (u"ࠬ࠭廒"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ廓"),l1l111_l1_ (u"ࠧࠨ廔"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠹ࡸ࡭࠭廕"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ廖"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ廗"),html,re.DOTALL|re.I)
	if tmp: l11l11l1111l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ廘"),html,re.DOTALL|re.I)
	if tmp: l11l11l11ll1_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ廙") in list(cookies.keys()): l11l111llll1_l1_ = cookies[l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ廚")]
	l1l1l1111_l1_ = l11l11l11ll1_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ廛")+key+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ廜")+l11l11l1111l_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭廝")+l11l111llll1_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ廞")+token
	if request==l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ廟") and l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ廠") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ廡"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ廢"),html,re.DOTALL)
		l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ廣"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ廤") and l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ廥") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ廦"),html,re.DOTALL)
		l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ廧"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ廨") not in html: l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ廩"),html)
	else: l11l11l1l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ廪")
	if 0:
		yccc = str(l11l11l1l1ll_l1_)
		if PY3: yccc = yccc.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ廫"))
		open(l1l111_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰ࡧࡥࡹ࠭廬"),l1l111_l1_ (u"ࠫࡼࡨࠧ廭")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ廮"),l1l1l1111_l1_)
	return html,l11l11l1l1ll_l1_,l1l1l1111_l1_
def l11l11l1llll_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ廯"),l1l111_l1_ (u"ࠧࠬࠩ廰"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ廱")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ廲"),l1l111_l1_ (u"ࠪ࠯ࠬ廳"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ࠭廴")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ廵") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡓࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭延")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭廷") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ廸")
		elif l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ廹") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆ࡭ࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ建")
		else: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠫࠬ廻")
		l1llllll_l1_ = l1lllll1_l1_+l11l111l1ll1_l1_
	else:
		l11l111l1l1l_l1_,l11l1111l111_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠬ࠭廼")
		l11l1111l1l1_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ廽"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭廾"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ廿"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ开"),l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ弁")]
		l11l11l1l1l1_l1_ = [l1l111_l1_ (u"ࠫࠬ异"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ弃"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ弄"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭弅"),l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ弆")]
		l11l11l1ll1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ弇"),l11l1111l1l1_l1_)
		if l11l11l1ll1l_l1_ == -1: return
		l11l111l11ll_l1_ = l11l11l1l1l1_l1_[l11l11l1ll1l_l1_]
		html,c,data = l11l111lll11_l1_(l1lllll1_l1_+l11l111l11ll_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ弈")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弉")][l1l111_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ弊")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ弋")][l1l111_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ弌")][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ弍")][l1l111_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ弎")]
				for l11l11111lll_l1_ in range(len(d)):
					group = d[l11l11111lll_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ式")][l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ弐")]
					for l11l11ll1111_l1_ in range(len(group)):
						yrender = group[l11l11ll1111_l1_][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ弑")]
						if l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ弒") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ弓")][l1l111_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ弔")][l1l111_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ引")][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ弖")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ弗"),l1l111_l1_ (u"ࠬࠬࠧ弘"))
							title = yrender[l1l111_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ弙")]
							title = title.replace(l1l111_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ弚"),l1l111_l1_ (u"ࠨࠩ弛"))
							if l1l111_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ弜") in title: continue
							if l1l111_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ弝") in title:
								title = l1l111_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ弞")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠬะัห์หࠤาูศࠨ弟") in title: continue
							title = title.replace(l1l111_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ张"),l1l111_l1_ (u"ࠧࠨ弡"))
							if l1l111_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ弢") in title: continue
							if l1l111_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ弣") in title:
								title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ弤")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ弥") in title: continue
							l11l111l1l1l_l1_.append(escapeUNICODE(title))
							l11l1111l111_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l11l11l1l11l_l1_ = l1l111_l1_ (u"ࠬ࠭弦")
		else:
			l11l111l1l1l_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ弧"),l1lllllll_l1_]+l11l111l1l1l_l1_
			l11l1111l111_l1_ = [l1l111_l1_ (u"ࠧࠨ弨"),l111lllll_l1_]+l11l1111l111_l1_
			l11l11ll11l1_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭弩"),l11l111l1l1l_l1_)
			if l11l11ll11l1_l1_ == -1: return
			l11l11l1l11l_l1_ = l11l1111l111_l1_[l11l11ll11l1_l1_]
		if l11l11l1l11l_l1_: l1llllll_l1_ = l111l1_l1_+l11l11l1l11l_l1_
		elif l11l111l11ll_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l111l11ll_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
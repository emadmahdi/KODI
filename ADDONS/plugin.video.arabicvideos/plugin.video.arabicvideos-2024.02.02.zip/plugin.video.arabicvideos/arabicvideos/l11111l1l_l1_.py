# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫᝣ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩᝤ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ๎โฺ้ࠢฮๆ๊๊ไีࠪᝥ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==490: l1lll_l1_ = l1l1l11_l1_()
	elif mode==491: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==492: l1lll_l1_ = PLAY(url)
	elif mode==493: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==494: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==499: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᝦ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᝧ"),l1l111_l1_ (u"ࠧࠨᝨ"),l1l111_l1_ (u"ࠨࠩᝩ"),l1l111_l1_ (u"ࠩࠪᝪ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᝫ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᝬ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠬ࠵ࠧ᝭"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᝮ"))
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠡࡃ࡭ࡥࡽ࡯ࡦࡺࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᝯ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡦࡪ࡮ࡷࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᝰ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡰ࡮ࡧ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ᝱")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨᝲ")
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᝳ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᝴")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᝵"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᝶"),l1l111_l1_ (u"ࠨࠩ᝷"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᝸"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᝹")+l1lllll_l1_+l1l111_l1_ (u"ࠫศ็ไศ็ࠪ᝺"),l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษไ่ฬ๋࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡧ࡫࡯ࡱࡪ࠵ࡦࡰࡴࡨ࡭࡬ࡴ࠭ࡩࡦ࠰หๆ๊วๆ࠯สะ๋ฮ้࠮࠴ࠪ᝻"),494,l1l111_l1_ (u"࠭ࠧ᝼"),l1l111_l1_ (u"ࠧࠨ᝽"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᝾"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᝿"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬក")+l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮࠬខ"),l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰็ึุ่๊วห࠱่ืู้ไศฬ࠰หั์ศ๊ࠩគ"),494,l1l111_l1_ (u"࠭ࠧឃ"),l1l111_l1_ (u"ࠧࠨង"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬច"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧឆ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬជ"),l1l111_l1_ (u"ࠫࠬឈ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫញ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫដ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧ࠰ࠩឋ"): continue
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ឌ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩឍ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬណ")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨត"),url,l1l111_l1_ (u"ࠬ࠭ថ"),l1l111_l1_ (u"࠭ࠧទ"),l1l111_l1_ (u"ࠧࠨធ"),l1l111_l1_ (u"ࠨࠩន"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩប"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩផ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩព"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬភ"),l1lllll_l1_+title,l1ll1ll_l1_,491)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"࠭ࠧម")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫយ"),url,l1l111_l1_ (u"ࠨࠩរ"),l1l111_l1_ (u"ࠩࠪល"),l1l111_l1_ (u"ࠪࠫវ"),l1l111_l1_ (u"ࠫࠬឝ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫឞ"))
	html = response.content
	block = l1l111_l1_ (u"࠭ࠧស")
	if l1l111_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬហ") in url: block = html
	elif l1l111_l1_ (u"ࠨࡁࡶࡁࠬឡ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࠣ࡯ࡤࡲ࡮࡬ࡥࡴࡶࠥࠫអ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩឣ"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫࠥࡱࡦࡴࡩࡧࡧࡶࡸࠧ࠭ឤ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
	if not block: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬឥ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫឦ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ឧ"),l1l111_l1_ (u"ࠨล฽๊๏ฯࠧឨ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧឩ"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩឪ"),l1l111_l1_ (u"ࠫ์ีวโࠩឫ"),l1l111_l1_ (u"๋ࠬศศำสอࠬឬ"),l1l111_l1_ (u"ู࠭าุࠪឭ"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧឮ"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧឯ"),l1l111_l1_ (u"่ࠩืึำ๊สࠩឰ")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫឱ"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧឲ"),title,re.DOTALL)
		if not l1l1lll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫឳ"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ឴") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭឵") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨា"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩិ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬី"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩឹ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭ឺ"),l1l111_l1_ (u"࠭ࠧុ"))
			if title!=l1l111_l1_ (u"ࠧࠨូ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨួ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨើ")+title,l1ll1ll_l1_,491)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧឿ"),url,l1l111_l1_ (u"ࠫࠬៀ"),l1l111_l1_ (u"ࠬ࠭េ"),l1l111_l1_ (u"࠭ࠧែ"),l1l111_l1_ (u"ࠧࠨៃ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩោ"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡺࡺࡴࡰࡰࡶࡆࡦࡸࡃࡰࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫៅ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧំ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬះ"),l1l111_l1_ (u"ࠬ࠭ៈ"),l1l111_l1_ (u"࠭ࠧ៉"),l1l111_l1_ (u"ࠧࠨ៊"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩ់"))
		html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡲ࡭࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ៌"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ៍"))
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ៎"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨ៏"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ័") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ៑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ្"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	elif l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࡞࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࠧࡨ࡯ࡹࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭៓"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ។"))
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ៕"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ៖"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫៗ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨ៘"),l1l111_l1_ (u"ࠨࠩ៙"))
				if title!=l1l111_l1_ (u"ࠩࠪ៚"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ៛"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪៜ")+title,l1ll1ll_l1_,491)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ៝"))+l1l111_l1_ (u"࠭࠯ࡀࡸ࡬ࡩࡼࡃ࠱ࠨ៞")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ៟"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ០"),l1l111_l1_ (u"ࠩࠪ១"),l1l111_l1_ (u"ࠪࠫ២"),l1l111_l1_ (u"ࠫࠬ៣"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ៤"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ៥"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠢࡥࡣࡷࡥ࠿ࠦࠧࡲ࠿ࠫ࠲࠯ࡅࠩࠧࠤ៦"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ៧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ៨"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ៩"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡲࡰࡩ࠵ࡳࡦࡴࡹࡩࡷࡹ࠯ࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃࡶࡃࠧ៪")+l11111l11_l1_+l1l111_l1_ (u"ࠬࠬࡩ࠾ࠩ៫")+l111111ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៬")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ៭")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡔࡧࡵࡺࡪࡸࠢ࠯ࠬࡂࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៮"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111_l1_ (u"่ࠩๅ฻๊ࠧ៯")
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭៰")+title
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ៱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ៲"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ៳"))
			if l1l111_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ៴") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠨࡡࡢาฬ฻ࠧ៵")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࠪ៶")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ៷")+title+l1l111_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ៸")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ៹"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"࠭ࠧ៺")):
	if not l1l11ll_l1_: l1l11ll_l1_ = l111l1_l1_
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ៻"),l1l111_l1_ (u"ࠨ࠭ࠪ៼"))
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡳ࠾ࠩ៽")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll11l_l1_ import *
import bidi.algorithm,base64,requests
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ㍝")
contentsDICT = {}
menuItemsLIST = []
if PY3:
	l111ll1l111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ㍞"))
	l1ll11ll11_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭㍟"))
	l11l1l1l111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ㍠"))
	l111ll11l11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㍡"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㍢"),l1l111_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ㍣"))
	l11l1llll11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㍤"),l1l111_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㍥"),l1l111_l1_ (u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ㍦"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㍧"),l1l111_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㍨"),l1l111_l1_ (u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ㍩"))
	half_triangular_colon = l1l111_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ㍪")
	from urllib.parse import quote as _1lllllll1l1_l1_
else:
	l111ll1l111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ㍫"))
	l1ll11ll11_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ㍬"))
	l11l1l1l111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ㍭"))
	l111ll11l11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㍮"),l1l111_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㍯"),l1l111_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭㍰"))
	l11l1llll11_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㍱"),l1l111_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㍲"),l1l111_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ㍳"))
	l1llll11l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㍴"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㍵"),l1l111_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ㍶"))
	half_triangular_colon = l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ㍷").encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㍸"))
	from urllib import quote as _1lllllll1l1_l1_
l111llll11l_l1_ = os.path.join(l11l1l1l111_l1_,l1l111_l1_ (u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬ㍹"))
l11111ll11l_l1_ = os.path.join(l11l1l1l111_l1_,l1l111_l1_ (u"ࠫࡰࡵࡤࡪ࠰ࡲࡰࡩ࠴࡬ࡰࡩࠪ㍺"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸ࠴ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㍻"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡩࡱࡶࡹ࠶ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㍼"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧ࡮࠵ࡸࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㍽"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨࡨࡤࡺࡴࡻࡲࡪࡶࡨࡷ࠳ࡪࡡࡵࠩ㍾"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫ㍿"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡱ࠸ࡻࡦࡪ࡮ࡨࡣࡤࡥ࠮ࡥࡣࡷࠫ㎀"))
l1ll11l11lll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡤࡢࡶࠪ㎁"))
addonimagesfolder = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬ࡯࡭ࡢࡩࡨࡷࠬ㎂"))
l1ll1lll11l1_l1_ = os.path.join(addonimagesfolder,l1l111_l1_ (u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡹࠧ㎃"))
l1ll11lllll1_l1_ = os.path.join(l1ll1lll11l1_l1_,l1l111_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪ㎄"))
l1l1l1l11ll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠨࡲࡤࡸ࡭࠭㎅"))
defaulticon = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ㎆"))
defaultthumb = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣ࠰ࡳࡲ࡬࠭㎇"))
defaultfanart = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲ࡵࡴࡧࠨ㎈"))
defaultbanner = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶ࠳ࡶ࡮ࡨࠩ㎉"))
defaultlandscape = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦ࠰ࡳࡲ࡬࠭㎊"))
defaultposter = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸ࠮ࡱࡰࡪࠫ㎋"))
defaultclearlogo = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲ࠲ࡵࡴࡧࠨ㎌"))
defaultclearart = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷ࠲ࡵࡴࡧࠨ㎍"))
defaultmenu = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠪࡱࡪࡴࡵ࠯ࡲࡱ࡫ࠬ㎎"))
l1lll1l1ll11_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡩࡨࡰࡴ࡭࠮ࡵࡺࡷࠫ㎏"))
l1lllll1ll_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ㎐"))
l1lll1l111l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㎑"),l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ㎒"),addon_id,l1l111_l1_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ㎓"))
fontfile = os.path.join(l111ll1l111_l1_,l1l111_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࠨ㎔"),l1l111_l1_ (u"ࠪࡊࡴࡴࡴࡴࠩ㎕"),l1l111_l1_ (u"ࠫࡦࡸࡩࡢ࡮࠱ࡸࡹ࡬ࠧ㎖"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠬ฻แาࠩ㎗"),l1l111_l1_ (u"࠭ร้ๆࠪ㎘"),l1l111_l1_ (u"ࠧฬษ้๎ࠬ㎙"),l1l111_l1_ (u"ࠨอส่ะ࠭㎚"),l1l111_l1_ (u"ࠩิหอ฿ࠧ㎛"),l1l111_l1_ (u"ࠪาฬ๋ำࠨ㎜"),l1l111_l1_ (u"ุࠫอฯิࠩ㎝"),l1l111_l1_ (u"ูࠬวษ฻ࠪ㎞"),l1l111_l1_ (u"࠭หศ็้ࠫ㎟"),l1l111_l1_ (u"ࠧหษึ฽ࠬ㎠"),l1l111_l1_ (u"ࠨ฻สุึ࠭㎡")]
l11111l1lll_l1_ = l1l111_l1_ (u"ࠩ⸾ࠤ⼢ࠦ⸪ࠡ⸽ࠪ㎢")
l11ll11l_l1_ = 0
l1llll111lll_l1_ = 30*l1l1ll1ll1l_l1_
l111l11l_l1_ = 2*l1l11lll1ll_l1_
l1lll11ll1l_l1_ = 30*l1l11lll111_l1_
l1l11l11111_l1_ = 1*l1l11lll1ll_l1_
l1ll1l11ll1l_l1_ = [l1l111_l1_ (u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㎣")]
l1111l1llll_l1_ = [l1l111_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭㎤"),l1l111_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ㎥"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ㎦"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ㎧"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㎨"),l1l111_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ㎩"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ㎪"),l1l111_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ㎫"),l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㎬"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㎭")]
l1111l1llll_l1_ += [l1l111_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㎮"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㎯"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㎰"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㎱"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㎲"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㎳"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ㎴"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㎵"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㎶")]
l1ll11l1l1l1_l1_ = [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㎷"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㎸"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㎹"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㎺")]
l1ll11l1l1l1_l1_ += [l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㎻"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㎼"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㎽"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㎾")]
l1ll11l1l1l1_l1_ += [l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㎿"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㏀"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㏁")]
l1ll11l1l1l1_l1_ += [l1l111_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭㏂"),l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㏃"),l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㏄"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㏅"),l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ㏆"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㏇")]
l1ll11l1l1l1_l1_ += [l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㏈"),l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㏉"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㏊"),l1l111_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㏋"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㏌"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㏍")]
l1ll1lll1ll_l1_ = [l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㏎"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭㏏"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㏐"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㏑")]
l1ll1lll1ll_l1_ += [l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㏒"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㏓"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㏔"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㏕"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ㏖")]
l1lll111l11_l1_ = [l1l111_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ㏗"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㏘"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㏙"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㏚"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㏛"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㏜")]
l1lll111l11_l1_ += [l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㏝"),l1l111_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ㏞"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㏟"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ㏠"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㏡")]
l1llll11111_l1_ = [l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ㏢"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭㏣"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ㏤"),l1l111_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㏥"),l1l111_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㏦"),l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㏧")]
l1llll11111_l1_ += [l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㏨"),l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㏩"),l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㏪"),l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㏫"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㏬"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㏭")]
l1lll1ll11l1_l1_  = [l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㏮"),l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㏯"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㏰"),l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㏱"),l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㏲"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ㏳"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩ㏴"),l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㏵")]
l1lll1ll11l1_l1_ += [l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㏶"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㏷"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ㏸"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ㏹"),l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㏺"),l1l111_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭㏻"),l1l111_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ㏼")]
l1lll1ll11l1_l1_ += [l1l111_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㏽"),l1l111_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㏾"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭㏿"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㐀"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㐁"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㐂")]
l1lll1ll11l1_l1_ += [l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㐃"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㐄"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㐅"),l1l111_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ㐆"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㐇"),l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㐈"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭㐉")]
l1lll1ll11l1_l1_ += [l1l111_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㐊"),l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㐋"),l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㐌"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㐍"),l1l111_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㐎"),l1l111_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ㐏"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ㐐")]
l1ll1ll111ll_l1_  = [l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭㐑"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ㐒"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ㐓"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩ㐔")]
l1ll1ll111ll_l1_ += [l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ㐕"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㐖")]
l1ll1ll111ll_l1_ += [l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ㐗"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㐘"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㐙")]
l1ll1ll111ll_l1_ += [l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㐚"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㐛"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㐜")]
l1ll1ll111ll_l1_ += [l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ㐝"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㐞"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㐟")]
l1ll1llll1ll_l1_ = [l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㐠"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㐡"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㐢"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㐣"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㐤")]
l1lll1l111l_l1_ = l1lll1ll11l1_l1_+l1ll1ll111ll_l1_
l1lll11ll1ll_l1_ = l1lll1ll11l1_l1_+l1ll1llll1ll_l1_
l1l11111111_l1_ = l1lll1ll11l1_l1_+l1ll1ll111ll_l1_
l1lll1l1111_l1_ = l1ll11l1l1l1_l1_+l1lll111l11_l1_+l1llll11111_l1_+l1ll1lll1ll_l1_
l1lll111l1ll_l1_ = [
						l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ㐥")
						,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ㐦")
						,l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡕࡍࡖࡌࡣ࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ㐧")
						]
l111111lll1_l1_ = [
						l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㐨")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㐩")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭㐪")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ㐫")
						,l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ㐬")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ㐭")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭㐮")
						,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧ㐯")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡂࡆࡢࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏ࠱࠶ࡹࡴࠨ㐰")
						,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ㐱")
						,l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭㐲")
						,l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ㐳")
						,l1l111_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ㐴")
						]
l11l1l1llll_l1_ = l111111lll1_l1_+[
				 l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ㐵")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ㐶")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ㐷")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨ㐸")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩ㐹")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪ㐺")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪ㐻")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫ㐼")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬ㐽")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ㐾")
				,l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ㐿")
				,l1l111_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩ㑀")
				,l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪ㑁")
				,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭㑂")
				,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓ࠮ࡕࡋࡓ࡜ࡥࡍࡆࡕࡖࡅࡌࡋࡓ࠮࠳ࡶࡸࠬ㑃")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ㑄")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㑅")
				]
l1111lll1ll_l1_ = [l1l111_l1_ (u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭㑆"),l1l111_l1_ (u"࠭࠱࠯࠳࠱࠵࠳࠷ࠧ㑇"),l1l111_l1_ (u"ࠧ࠲࠰࠳࠲࠵࠴࠱ࠨ㑈"),l1l111_l1_ (u"ࠨ࠺࠱࠼࠳࠺࠮࠵ࠩ㑉"),l1l111_l1_ (u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠷࠴࠲࠳࠴ࠪ㑊"),l1l111_l1_ (u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠶࠮࠳࠴࠳ࠫ㑋")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㑌")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬ࡱࡤࡱ࠳ࡴࡥࡵࠩ㑍")]
			,l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㑎")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦ࡮ࡷࡢ࡭ࡷࡺ࠳ࡴࡥࡵࠩ㑏")]
			,l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㑐")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹ࠭㑑")]
			,l1l111_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㑒")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠭㑓")]
			,l1l111_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ㑔")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭ࡨࡤࡸ࡮ࡳࡩ࠯ࡶࡹࠫ㑕")]
			,l1l111_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ㑖")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡰࡲࡧࡡࡳࡧࡩ࠲ࡨ࡮ࠧ㑗")]
			,l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㑘")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ࠪ㑙")]
			,l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭㑚")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬ㑛")]
			,l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㑜")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡼ࡯ࡥ࠰ࡦࡳࡲ࠭㑝")]
			,l1l111_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㑞")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡷࡹࡴࡦ࡬࠱ࡧࡴࡳࠧ㑟")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㑠")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠷࠴࠵࠴ࡣࡰ࡯ࠪ㑡")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㑢")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬ㑣")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㑤")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠳ࡣࡦࡲ࠲ࡨࡵ࡭ࠨ㑥")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㑦")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡳ࡬࡫ࡱࠫ㑧")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㑨")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡵ࡫ࡳࡵ࠭㑩")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㑪")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ㑫")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㑬")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠼࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸࠬ㑭")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㑮")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩ㑯")]
			,l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㑰")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㑱"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㑲")]
			,l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㑳")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫ㑴")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㑵")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴ࠭ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ㑶")]
			,l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㑷")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡥࡩࡸࡺ࠮ࡴࡶࡲࡶࡪ࠭㑸")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㑹")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨ㑺")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㑻")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㑼")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㑽")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬ㑾")]
			,l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ㑿")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ㒀")]
			,l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㒁")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ㒂")]
			,l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㒃")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩ㒄")]
			,l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㒅")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡲࡩ࡯࡭ࠪ㒆")]
			,l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ㒇")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧ㒈")]
			,l1l111_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㒉")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧ㒊")]
			,l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㒋")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯࡯ࡨࡨ࡮ࡧࠧ㒌")]
			,l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㒍")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㒎"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㒏"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㒐"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㒑"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫ㒒")]
			,l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㒓")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧ㒔")]
			,l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ㒕")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪࡳࡴ࠴࡫ࡪࡶ࡮ࡳࡹ࠴ࡴࡷࠩ㒖")]
			,l1l111_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ㒗")	:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ㒘"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪ㒙")]
			,l1l111_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㒚")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡥࡤࡱࠬ㒛")]
			,l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㒜")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ㒝")]
			,l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㒞")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡢ࠰ࡦࡥࡲ࠭㒟")]
			,l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㒠")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ㒡")]
			,l1l111_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㒢")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨ㒣")]
			,l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㒤")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㒥"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ㒦"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ㒧")]
			,l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㒨")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ㒩")]
			,l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㒪")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡻࡲ࠲࠳࠭࠮࠯࠰ࡲࡿ࡫ࡢࡤࡣ࠸࡫ࡩ࠽࡯ࡥࡧ࠳ࡦ࡮࡭࡬ࡩ࠰ࡰࡽࡨ࡯ࡩ࡮ࡣ࠰ࡻࡪࡩࡩࡪ࡯ࡤ࠲ࡸ࡮࡯ࡱࠩ㒫")]
			,l1l111_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㒬")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ㒭")]
			,l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㒮")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ㒯")]
			,l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㒰")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㒱"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ㒲"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭㒳")]
			,l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭㒴")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㒵"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ㒶"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ㒷")]
			,l1l111_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ㒸")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡯ࡴࡪࡩࠨ㒹"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮ࠧ㒺"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠭㒻")]
			}
if 1:
	l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㒼")] = [l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㒽"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㒾"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㒿"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㓀"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㓁"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㓂"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㓃"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭㓄"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㓅")]
	l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ㓆")] = [l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㓇"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㓈"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㓉"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㓊"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㓋"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㓌"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㓍"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡦࡥࡵࡺࡣࡩࡣࠪ㓎"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡸࡪࡹࡴࡪࡰࡪࠫ㓏")]
else:
	l1l11l1_l1_[l1l111_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㓐")] = [l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ㓑"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ㓒"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ㓓"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㓔"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭㓕"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ㓖"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ㓗"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭㓘"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㓙")]
	l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ㓚")] = [l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㓛"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㓜"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㓝"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㓞"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㓟"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㓠"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㓡"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ㓢"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ㓣")]
l111l11lll1_l1_ = [l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫ㓤"),l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫ㓥"),l1l111_l1_ (u"ࠫࡊࡓࡁࡊࡎࡖࠫ㓦"),l1l111_l1_ (u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ㓧"),l1l111_l1_ (u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ㓨"),l1l111_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ㓩"),l1l111_l1_ (u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭㓪"),l1l111_l1_ (u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ㓫"),l1l111_l1_ (u"ࠪࡘࡊ࡙ࡔࡊࡐࡊࠫ㓬")]
l11l11lll1l_l1_ = [l1l111_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖࠫ㓭"),l1l111_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠾ࠧ㓮"),l1l111_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠹ࠨ㓯")]
class l1ll1lllll1l_l1_(l1l1l1llll1_l1_):
	def __init__(self,*args,**kwargs):
		self.l11llll1l1l_l1_ = -1
	def onClick(self,l1111lllll1_l1_):
		if l1111lllll1_l1_>=9010: self.l11llll1l1l_l1_ = l1111lllll1_l1_-9010
		self.delete()
	def l11l11ll1l1_l1_(self,*args):
		self.l111l1lll11_l1_,self.l1ll1lll111l_l1_,self.l1llllll1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1lll1lll1ll_l1_ = args[5],args[6]
		self.l1ll11l111ll_l1_,self.l1ll1l1l1l1l_l1_ = args[7],args[8]
		if self.l1ll11l111ll_l1_>0 or self.l1ll1l1l1l1l_l1_>0: self.l1lll1l11l1l_l1_ = True
		else: self.l1lll1l11l1l_l1_ = False
		self.l11111lll11_l1_ = l1ll11lllll1_l1_.replace(l1l111_l1_ (u"ࠧࡠ࠲࠳࠴࠵ࡥࠧ㓰"),l1l111_l1_ (u"ࠨࡡࠪ㓱")+str(time.time())+l1l111_l1_ (u"ࠩࡢࠫ㓲"))
		self.l11111lll11_l1_ = self.l11111lll11_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭㓳"),l1l111_l1_ (u"ࠫࡡࡢ࡜࡝ࠩ㓴")).replace(l1l111_l1_ (u"ࠬ࠵࠯ࠨ㓵"),l1l111_l1_ (u"࠭࠯࠰࠱࠲ࠫ㓶"))
		self.l11l1111lll_l1_ = CREATE_IMAGE(self.l111l1lll11_l1_,self.l1ll1lll111l_l1_,self.l1llllll1lll_l1_,self.header,self.text,self.profile,self.l1lll1lll1ll_l1_,self.l1lll1l11l1l_l1_,self.l11111lll11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l11111lll11_l1_)
		self.getControl(9050).setHeight(self.l11l1111lll_l1_)
		if not self.l1ll1lll111l_l1_ and self.l111l1lll11_l1_ and self.l1llllll1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l11111lll11_l1_,self.l11l1111lll_l1_
	def l11llll11l1_l1_(self):
		if self.l1ll11l111ll_l1_:
			self.l1lll11ll11l_l1_ = threading.Thread(target=self.l1llll11lll1_l1_,args=())
			self.l1lll11ll11l_l1_.start()
		else: self.l11l11l1l1l_l1_()
	def l1llll11lll1_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l111llll_l1_ in range(1,self.l1ll11l111ll_l1_+1):
			time.sleep(1)
			l1ll11l1l111_l1_ = int(100*l1l111llll_l1_/self.l1ll11l111ll_l1_)
			self.l1ll1l1111ll_l1_(l1ll11l1l111_l1_)
			if self.l11llll1l1l_l1_>0: break
		self.l11l11l1l1l_l1_()
	def l11ll1lll1l_l1_(self):
		if self.l1ll1l1l1l1l_l1_:
			self.l1lll11ll1l1_l1_ = threading.Thread(target=self.l11111lllll_l1_,args=())
			self.l1lll11ll1l1_l1_.start()
		else: self.l11l11l1l1l_l1_()
	def l11111lllll_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll11l111ll_l1_)
		for l1l111llll_l1_ in range(self.l1ll1l1l1l1l_l1_-1,-1,-1):
			time.sleep(1)
			l1ll11l1l111_l1_ = int(100*l1l111llll_l1_/self.l1ll1l1l1l1l_l1_)
			self.l1ll1l1111ll_l1_(l1ll11l1l111_l1_)
			if self.l11llll1l1l_l1_>0: break
		if self.l1ll1l1l1l1l_l1_>0: self.l11llll1l1l_l1_ = 10
		self.delete()
	def l1ll1l1111ll_l1_(self,l1ll11l1l111_l1_):
		self.l11111ll111_l1_ = l1ll11l1l111_l1_
		self.getControl(9020).setPercent(self.l11111ll111_l1_)
	def l11l11l1l1l_l1_(self):
		if self.l111l1lll11_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll1lll111l_l1_: self.getControl(9011).setEnabled(True)
		if self.l1llllll1lll_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l11111lll11_l1_)
		except: pass
class l11l11l1lll_l1_():
	def __init__(self,l11_l1_=False,l1lll1l1l111_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1lll1l1l111_l1_ = l1lll1l1l111_l1_
		self.l11l1l1l11l_l1_,self.l11llllllll_l1_ = [],[]
		self.l1111llllll_l1_,self.l1111ll1ll1_l1_ = {},{}
		self.l111lll1l11_l1_ = []
		self.l1ll1l111l11_l1_,self.l11111l11ll_l1_,self.l11lll1ll11_l1_ = {},{},{}
	def l11l111lll1_l1_(self,id,func,*args):
		id = str(id)
		self.l1111llllll_l1_[id] = l1l111_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ㓷")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨࠩ㓸"),id)
		l11llll1lll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l111lll1l11_l1_.append(l11llll1lll_l1_)
		return l11llll1lll_l1_
	def start_new_thread(self,id,func,*args):
		l11llll1lll_l1_ = self.l11l111lll1_l1_(id,func,*args)
		l11llll1lll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1ll1l111l11_l1_[id] = time.time()
		try:
			self.l1111ll1ll1_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪ㓹") in str(func) and not self.l1111ll1ll1_l1_[id].succeeded:
				l1111l1l1ll_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡦࡸࡩࠥࡺ࡯ࠡࡶ࡫ࡶࡪࡧࡤࡦࡦࠣࡓࡕࡋࡎࡖࡔࡏࠤ࡫ࡧࡩ࡭ࠩ㓺"))
			self.l11l1l1l11l_l1_.append(id)
			self.l1111llllll_l1_[id] = l1l111_l1_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩ࠭㓻")
		except Exception as err:
			if self.l1lll1l1l111_l1_:
				l111l11l1ll_l1_ = traceback.format_exc()
				if l111l11l1ll_l1_!=l1l111_l1_ (u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ㓼"): sys.stderr.write(l111l11l1ll_l1_)
			self.l11llllllll_l1_.append(id)
			self.l1111llllll_l1_[id] = l1l111_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㓽")
		self.l11111l11ll_l1_[id] = time.time()
		self.l11lll1ll11_l1_[id] = self.l11111l11ll_l1_[id] - self.l1ll1l111l11_l1_[id]
	def l1lll1l11lll_l1_(self):
		for proc in self.l111lll1l11_l1_:
			proc.start()
	def l1ll11l1ll11_l1_(self):
		while l1l111_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ㓾") in list(self.l1111llllll_l1_.values()): time.sleep(1.000)
def l1lll1ll1lll_l1_():
	l1lll11l1111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㓿"))
	if l1lll11l1111_l1_==l1l11l1111l_l1_:
		status,l111l1ll11l_l1_ = l1l111_l1_ (u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬ㔀"),False
		return status,l111l1ll11l_l1_
	try: os.makedirs(addoncachefolder)
	except: pass
	status,l111l1ll11l_l1_ = l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ㔁"),True
	l11l1lll11l_l1_ = [l1l111_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ㔂"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ㔃"),l1l111_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ㔄"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ㔅"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ㔆"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭㔇"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ㔈"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ㔉"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ㔊"),l1l111_l1_ (u"࠭࠲࠱࠴࠶࠲࠶࠶࠮࠳࠺ࠪ㔋"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠸࠳࠶࠱࠯࠳࠷ࠫ㔌")]
	l1llllllllll_l1_ = l11l1lll11l_l1_[-1]
	l111ll111ll_l1_ = l1ll11l11ll1_l1_(l1llllllllll_l1_)
	l1lllll11l11_l1_ = l1ll11l11ll1_l1_(l1l11l1111l_l1_)
	if l1lllll11l11_l1_>l111ll111ll_l1_:
		status = l1l111_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ㔍")
	return status,l111l1ll11l_l1_
def l111111llll_l1_():
	l11ll11l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡫ࡰࡥ࡬࡫ࡳࠨ㔎"))
	if not l11ll11l11l_l1_: l1lll1lll1_l1_ = 5001
	else:
		l1lll1lll1_l1_ = 0
		for root,dirs,l1l1111111_l1_ in os.walk(addonimagesfolder,topdown=False):
			l1lll1lll1_l1_ += len(l1l1111111_l1_)
	if l1lll1lll1_l1_>5000: l1llll1ll1_l1_(addonimagesfolder,True,False)
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡬ࡱࡦ࡭ࡥࡴࠩ㔏"),str(now))
	return
def l1111l1l1l1_l1_(l1lll11l111_l1_,l1llll1lllll_l1_):
	succeeded,l111l11l11l_l1_,l11ll11llll_l1_ = True,False,False
	type,name,l1l1l11lll1_l1_,mode,l1l1ll11111_l1_,l1l1111l11l_l1_,text,context,l1llllll1ll_l1_ = l1lll11l111_l1_
	l1ll1l11ll11_l1_ = type,name,l1l1l11lll1_l1_,mode,l1l1ll11111_l1_,l1l1111l11l_l1_,text,l1l111_l1_ (u"ࠫࠬ㔐"),l1llllll1ll_l1_
	l1lll11lllll_l1_ = int(mode)
	l1lll11llll1_l1_ = int(l1lll11lllll_l1_%10)
	l1lll1l11111_l1_ = int(l1lll11lllll_l1_/10)
	l1ll11l1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ㔑"))
	if not l1ll11l1l1ll_l1_: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭㔒"),l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㔓"))
	l11l11l1111_l1_,l111l1ll11l_l1_ = l1lll1ll1lll_l1_()
	if l111l1ll11l_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㔔"),l1l111_l1_ (u"ࠩࠪ㔕"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㔖"),l1l111_l1_ (u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫ㔗")+l1l11l1111l_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㔘"),l1l111_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㔙"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㔚"),l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㔛"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㔜"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ㔝"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㔞"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪ㔟"))
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㔠"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭㔡"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨ㔢"),l1l111_l1_ (u"ࠩࠪ㔣"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬ㔤"),l1l111_l1_ (u"ࠫࠬ㔥"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ㔦"),l1l111_l1_ (u"࠭ࠧ㔧"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ㔨"),l1l111_l1_ (u"ࠨࠩ㔩"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨࡴࡴࡹࠧ㔪"),l1l111_l1_ (u"ࠪࠫ㔫"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱࡭ࡲࡧࡧࡦࡵࠪ㔬"),l1l111_l1_ (u"ࠬ࠭㔭"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㔮"),l1l111_l1_ (u"ࠧࠨ㔯"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㔰"),l1l111_l1_ (u"ࠩࠪ㔱"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷࠬ㔲"),l1l111_l1_ (u"ࠫࠬ㔳"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ㔴"),l1l111_l1_ (u"࠭ࠧ㔵"))
		import l1l11lllll1_l1_
		if l11l11l1111_l1_==l1l111_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㔶"):
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㔷"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㔸")+addon_path+l1l111_l1_ (u"ࠪࠤࡢ࠭㔹"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ㔺"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ㔻"))
			l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ㔼"))
			l11l1lll1l1_l1_(True,[main_dbfile])
		else:
			l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㔽"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ㔾")+addon_path+l1l111_l1_ (u"ࠩࠣࡡࠬ㔿"))
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㕀"),l1l111_l1_ (u"ࠫࠬ㕁"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㕂"),l1l111_l1_ (u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩ㕃"))
			l11l1lll1l1_l1_()
			FIX_ALL_DATABASES(False)
			l1l11lllll1_l1_.l1ll1ll1lll1_l1_()
			l1l11lllll1_l1_.l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㕄"),False)
			l1l11lllll1_l1_.l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫ㕅"),False)
			l1l11lllll1_l1_.l11111ll1ll_l1_(False)
			l1l11lllll1_l1_.l1ll1ll11lll_l1_(False)
			l1l11lllll1_l1_.l111ll1lll1_l1_(l1l111_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㕆"),l1l111_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ㕇"),False)
			try:
				l11l1ll1l1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕈"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕉"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㕊"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕋"))
				l1111lll1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㕌"))
				l1111lll1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ㕍"),l1l111_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ㕎"))
			except: pass
			try:
				l11l1ll1l1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕏"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕐"),l1l111_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㕑"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕒"))
				l1111lll1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㕓"))
				l1111lll1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ㕔"),l1l111_l1_ (u"ࠪ࠷ࠬ㕕"))
			except: pass
			try:
				l11l1ll1l1l_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㕖"),l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㕗"),l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㕘"),l1l111_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㕙"))
				l1111lll1l1_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㕚"))
				l1111lll1l1_l1_.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ㕛"),l1l111_l1_ (u"ࠪ࠶ࠬ㕜"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l1l1111l1_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll11l11lll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㕝"),l1l11l1111l_l1_)
		l1l11lllll1_l1_.l11ll1l1lll_l1_(False)
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㕞"))
	l1l111ll11_l1_ = l11lll1111l_l1_(l1llll1lllll_l1_)
	l1l11ll1ll1_l1_ = l11lll1111l_l1_(name)
	l1111llll11_l1_ = [0,15,17,19,26,34,50,53]
	l1lll1llll1l_l1_ = [0,15,17,19,26,34,50,53]
	l11llll1111_l1_ = l1lll1l11111_l1_ not in l1lll1llll1l_l1_
	l1ll11l1lll1_l1_ = l1lll1l11111_l1_ in [23,28,71,72]
	l1llll1ll1ll_l1_ = l1lll11lllll_l1_ in [265,270]
	l111111l1l1_l1_ = (l11llll1111_l1_ or l1ll11l1lll1_l1_) and not l1llll1ll1ll_l1_
	l11l1ll1lll_l1_ = l1ll11l1l1_l1_!=l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㕟") and (l1ll11l1l1_l1_!=l1l111_l1_ (u"ࠧࠨ㕠") or context==l1l111_l1_ (u"ࠨࠩ㕡"))
	l1lll1l111ll_l1_ = l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠽ࠨ㕢") in l1ll11l1l1_l1_
	l1ll1ll1l1l1_l1_ = l1lll11lllll_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1lll11llll1_l1_==9 or l1lll11lllll_l1_ in [145,516,523,45]
	l11lll11111_l1_ = not l1ll1ll1l1l1_l1_
	l11l1l11ll1_l1_ = not l1lll1_l1_
	l1lllll111l1_l1_ = l1l111ll11_l1_ in [l1l111_l1_ (u"ࠪࠫ㕣"),l1l111_l1_ (u"ࠫ࠳࠴ࠧ㕤")]
	l111ll11111_l1_ = l1lllll111l1_l1_ or l11lll11111_l1_
	l1111l1ll1l_l1_ = l1lllll111l1_l1_ or l11l1l11ll1_l1_ or l1lll1l111ll_l1_
	l1ll1l11llll_l1_ = l1lll11lllll_l1_ not in [260,261,265,270,330,540]
	if l1ll11l1l1ll_l1_==l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㕥"): l111l1lll1l_l1_ = l1lll1_l1_ or l1ll1ll1l1l1_l1_
	else: l111l1lll1l_l1_ = True
	l1ll1ll1ll_l1_ = l1lll1l11111_l1_ in [74,75]
	l1111l1111l_l1_ = l1lll11lllll_l1_ in [280,720]
	l111ll1ll11_l1_ = not l1ll1ll1ll_l1_ and not l1111l1111l_l1_
	l1ll11ll111l_l1_ = l111ll11111_l1_ and l1111l1ll1l_l1_ and l1ll1l11llll_l1_ and l111l1lll1l_l1_ and l111ll1ll11_l1_
	l11l1l11111_l1_ = l1ll1l11llll_l1_ and l111l1lll1l_l1_ and l111ll1ll11_l1_
	l11l1l111l1_l1_ = l11l1l11111_l1_
	l1l111111l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭㕦"))
	l111lllll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ㕧"))
	if 1 and l11l1ll1lll_l1_ and l1ll11ll111l_l1_:
		l1111111ll1_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㕨"),l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㕩")+l1l111111l1_l1_+l1l111_l1_ (u"ࠪࡣࠬ㕪")+l111lllll11_l1_,l1ll1l11ll11_l1_)
		if l1111111ll1_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠫࠬ㕫"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㕬")+l1l111111l1_l1_+l1l111_l1_ (u"࠭࡟ࠨ㕭")+l111lllll11_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡐࡴࡧࡤࡪࡰࡪࠤࡲ࡫࡮ࡶࠢࡩࡶࡴࡳࠠࡤࡣࡦ࡬ࡪ࠭㕮"))
			if 1 and l1lll1l111ll_l1_:
				l11ll1ll1l1_l1_ = []
				from l1ll1l1ll11l_l1_ import l11111111l1_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1lllll11111_l1_ = l11111111l1_l1_
				l11ll1l1l11_l1_ = GET_ALL_FAVORITES()
				l111l1111l1_l1_ = l1ll11l1l1_l1_
				l11l11llll1_l1_,l11l1l1l1l1_l1_,l1llll1lll11_l1_,l1lll11ll111_l1_,l11ll111111_l1_,l1111l11ll1_l1_,l11l1l1l1ll_l1_,l1llll111l11_l1_,l1111l1lll1_l1_ = EXTRACT_KODI_PATH(l111l1111l1_l1_)
				l1lllll1111l_l1_ = l11l11llll1_l1_,l11l1l1l1l1_l1_,l1llll1lll11_l1_,l1lll11ll111_l1_,l11ll111111_l1_,l1111l11ll1_l1_,l11l1l1l1ll_l1_,l1l111_l1_ (u"ࠨࠩ㕯"),l1111l1lll1_l1_
				for l1l111111ll_l1_ in l1111111ll1_l1_:
					l1lll111111l_l1_ = l1l111111ll_l1_[l1l111_l1_ (u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ㕰")]
					if l1lll111111l_l1_==l1lllll1111l_l1_ or l1l111111ll_l1_[l1l111_l1_ (u"ࠪࡱࡴࡪࡥࠨ㕱")] in [265,270]:
						l1l111111ll_l1_ = GET_LIST_ITEM(l1lll111111l_l1_,l1lllll11111_l1_,l11ll1l1l11_l1_)
						if l1l111111ll_l1_[l1l111_l1_ (u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ㕲")]:
							l1lll11l111l_l1_ = GET_FAVORITES_CONTEXT_MENU(l11ll1l1l11_l1_,l1lll111111l_l1_,l1l111111ll_l1_[l1l111_l1_ (u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭㕳")])
							l1l111111ll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㕴")] = l1lll11l111l_l1_+l1l111111ll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭㕵")]
					l11ll1ll1l1_l1_.append(l1l111111ll_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㕶"),l1l111_l1_ (u"ࠩࠪ㕷"))
				if type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕸"): l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㕹")+l1l111111l1_l1_+l1l111_l1_ (u"ࠬࡥࠧ㕺")+l111lllll11_l1_,l1ll1l11ll11_l1_,l11ll1ll1l1_l1_,l11l1l1_l1_)
			else: l11ll1ll1l1_l1_ = l1111111ll1_l1_
			if type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕻") and l1l111ll11_l1_!=l1l111_l1_ (u"ࠧ࠯࠰ࠪ㕼") and l111111l1l1_l1_: l1l1l1ll1ll_l1_()
			l11l1ll11ll_l1_ = CREATE_KODI_MENU(l1ll1l11ll11_l1_,l11ll1ll1l1_l1_,succeeded,l111l11l11l_l1_,l11ll11llll_l1_)
			return
	elif type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕽") and l1ll11l1l1_l1_==l1l111_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㕾") and l11l1l11111_l1_:
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㕿")+l1l111111l1_l1_+l1l111_l1_ (u"ࠫࡤ࠭㖀")+l111lllll11_l1_,l1ll1l11ll11_l1_)
	if l1l111_l1_ (u"ࠬࡥࠧ㖁") in context: l1lll1llllll_l1_,l1llll111111_l1_ = context.split(l1l111_l1_ (u"࠭࡟ࠨ㖂"),1)
	else: l1lll1llllll_l1_,l1llll111111_l1_ = context,l1l111_l1_ (u"ࠧࠨ㖃")
	if l1lll1llllll_l1_ in [l1l111_l1_ (u"ࠨ࠳ࠪ㖄"),l1l111_l1_ (u"ࠩ࠵ࠫ㖅"),l1l111_l1_ (u"ࠪ࠷ࠬ㖆"),l1l111_l1_ (u"ࠫ࠹࠭㖇"),l1l111_l1_ (u"ࠬ࠻ࠧ㖈")] and l1llll111111_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㖉"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㖊"))
		return
	elif l1lll1llllll_l1_==l1l111_l1_ (u"ࠨ࠸ࠪ㖋"):
		if l1llll111111_l1_==l1l111_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㖌"): l1ll1lll_l1_(l1l111_l1_ (u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪ㖍"),l1l111_l1_ (u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫ㖎"))
		elif l1llll111111_l1_==l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠬ㖏"): l1lll11lllll_l1_ = 334
		l1lll_l1_ = l1lll11111ll_l1_(type,l1l11ll1ll1_l1_,l1l1l11lll1_l1_,l1lll11lllll_l1_,l1l1ll11111_l1_,l1l1111l11l_l1_,text,context,l1llllll1ll_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㖐"))
		return
	elif context==l1l111_l1_ (u"ࠧ࠸ࠩ㖑"):
		from l1111l1l11_l1_ import l1lll111l1l_l1_
		l1lll111l1l_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㖒"))
		return
	elif context==l1l111_l1_ (u"ࠩ࠻ࠫ㖓"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㖔")+addon_id+l1l111_l1_ (u"ࠫࡄࡳ࡯ࡥࡧࡀࠫ㖕")+str(mode)+l1l111_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬ㖖"))
		return
	elif context==l1l111_l1_ (u"࠭࠹ࠨ㖗"):
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㖘"),l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ㖙"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㖚"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ㖛")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㖜"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㖝"),l1l111_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㖞")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭㖟"),l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㖠"))
	if not settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩ㖡")): settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪ㖢"),l1111lll1ll_l1_[0])
	l11ll11l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱࡭ࡲࡧࡧࡦࡵࠪ㖣"))
	l11ll11l11l_l1_ = 0 if not l11ll11l11l_l1_ else int(l11ll11l11l_l1_)
	if not l11ll11l11l_l1_ or now-l11ll11l11l_l1_<=0 or now-l11ll11l11l_l1_>l11l1l1_l1_:
		l11llll1lll_l1_ = threading.Thread(target=l111111llll_l1_)
		l11llll1lll_l1_.start()
	l1ll11lll1ll_l1_ = False if l1l111lllll_l1_(l1l111_l1_ (u"ࠬࡕࡔ࠲࠻ࡍ࡙࠵ࡾࡂࡕࡗ࡯ࡈ࡝࠭㖤")) else True
	l11llll1l11_l1_ = l111l11l_l1_ if l1ll11lll1ll_l1_ else l11l1l1_l1_
	l11lll111ll_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ㖥"))
	l1ll1l1l1111_l1_ = l1111l1l11l_l1_(settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㖦")))
	l1ll1l1l1111_l1_ = 0 if not l1ll1l1l1111_l1_ else int(l1ll1l1l1111_l1_)
	if l11lll111ll_l1_ in [l1l111_l1_ (u"ࠨࠩ㖧"),l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㖨")] or not l11llll1l11_l1_ or not l1ll1l1l1111_l1_ or now-l1ll1l1l1111_l1_<0 or now-l1ll1l1l1111_l1_>l11llll1l11_l1_:
		l11lll111ll_l1_ = l1ll1l1l11ll_l1_(True,False)
	l11lll1ll1l_l1_ = l1111l1l11l_l1_(settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬ㖩")))
	l11lll1ll1l_l1_ = 0 if not l11lll1ll1l_l1_ else int(l11lll1ll1l_l1_)
	l11l1l11lll_l1_ = l1111l1l11l_l1_(settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㖪")))
	l11l1l11lll_l1_ = 0 if not l11l1l11lll_l1_ else int(l11l1l11lll_l1_)
	if not l11lll1ll1l_l1_ or not l11l1l11lll_l1_ or now-l11l1l11lll_l1_<0 or now-l11l1l11lll_l1_>l11lll1ll1l_l1_:
		l1lll111ll1l_l1_ = 1
		if l1ll11lll1ll_l1_:
			l1lll11111l1_l1_ = l11lll1l11l_l1_(True)
			if len(l1lll11111l1_l1_)>1:
				l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㖫"),l1l111_l1_ (u"࠭࠮ࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ㖬")+addon_path+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㖭"))
				id,l1ll11l11l11_l1_,l111l111ll1_l1_,l11l11l11ll_l1_,l11l111llll_l1_,reason = l1lll11111l1_l1_[0]
				l111l111111_l1_,l111l11111l_l1_ = l11l11l11ll_l1_.split(l1l111_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㖮"))
				del l1lll11111l1_l1_[0]
				l1lll1l1111l_l1_ = random.sample(l1lll11111l1_l1_,1)
				id,l1ll11l11l11_l1_,l111l111ll1_l1_,l11l11l11ll_l1_,l11l111llll_l1_,reason = l1lll1l1111l_l1_[0]
				l111l111ll1_l1_ = l1l111_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠾ࠥ࠭㖯")+id+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㖰")+l111l111ll1_l1_
				l11l111llll_l1_ = l1l111_l1_ (u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ㖱")
				l11111l1lll_l1_ = l1l111_l1_ (u"ࠬอไหสิ฽ฬะࠧ㖲")
				l111l1lll11_l1_,l1ll1lll111l_l1_ = l11l11l11ll_l1_,l11l111llll_l1_
				l111llll_l1_ = [l111l1lll11_l1_,l1ll1lll111l_l1_,l11111l1lll_l1_]
				l11l1111l11_l1_ = 1 if l1l111lllll_l1_(l1l111_l1_ (u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ㖳")) else 10
				l11l1111l1l_l1_ = -9
				while l11l1111l1l_l1_<0:
					l11l1l1lll1_l1_ = random.sample(l111llll_l1_,3)
					l11l1111l1l_l1_ = l1ll11ll11l1_l1_(l1l111_l1_ (u"ࠧࠨ㖴"),l11l1l1lll1_l1_[0],l11l1l1lll1_l1_[1],l11l1l1lll1_l1_[2],l111l111111_l1_,l111l111ll1_l1_,l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ㖵"),l11l1111l11_l1_,60)
					if l11l1111l1l_l1_==10: break
					from l1l11lllll1_l1_ import l1lll1l1lll1_l1_,l1l1l1l111l_l1_
					if l11l1111l1l_l1_>=0 and l11l1l1lll1_l1_[l11l1111l1l_l1_]==l111llll_l1_[1]:
						l1lll1l1lll1_l1_()
						if l11l1111l1l_l1_>=0: l11l1111l1l_l1_ = -9
					elif l11l1111l1l_l1_>=0 and l11l1l1lll1_l1_[l11l1111l1l_l1_]==l111llll_l1_[2]:
						l1l1l1l111l_l1_(False)
					if l11l1111l1l_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㖶"),l1l111_l1_ (u"ࠪࠫ㖷"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㖸"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ฯำ๋ะࠥิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧ㖹"))
				l1lll111ll1l_l1_ = 1
			else: l1lll111ll1l_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㖺"),l1lll1ll111l_l1_(now))
		l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㖻"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭㖼"),l1lll111ll1l_l1_,l1ll111l1ll_l1_)
	l1lll_l1_ = l1lll11111ll_l1_(type,l1l11ll1ll1_l1_,l1l1l11lll1_l1_,mode,l1l1ll11111_l1_,l1l1111l11l_l1_,text,context,l1llllll1ll_l1_)
	if l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㖽") in text: l111l11l11l_l1_ = True
	if type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㖾"):
		if l1l111ll11_l1_!=l1l111_l1_ (u"ࠫ࠳࠴ࠧ㖿") and l111111l1l1_l1_: l1l1l1ll1ll_l1_()
		if addon_handle>-1:
			if (l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬ࡯࡮ࡵࠩ㗀"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㗁"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ㗂")) or l1lll11lllll_l1_ not in l1111llll11_l1_) and not l1l111lllll_l1_(l1l111_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ㗃")):
				from l1ll1l1ll11l_l1_ import l11111111l1_l1_
				l1111111ll1_l1_ = GET_ALL_LIST_ITEMS(l11111111l1_l1_)
				l11l1ll11ll_l1_ = CREATE_KODI_MENU(l1ll1l11ll11_l1_,l1111111ll1_l1_,succeeded,l111l11l11l_l1_,l11ll11llll_l1_)
				if 1 and l1111111ll1_l1_ and l11l1l111l1_l1_:
					l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㗄")+l1l111111l1_l1_+l1l111_l1_ (u"ࠪࡣࠬ㗅")+l111lllll11_l1_,l1ll1l11ll11_l1_,l1111111ll1_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ㗆")+addon_id+l1l111_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ㗇"),xbmcgui.ListItem(l1l111_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ㗈")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㗉")+addon_id+l1l111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ㗊"),xbmcgui.ListItem(l1l111_l1_ (u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ㗋")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l11l11l_l1_,l11ll11llll_l1_)
	return
def l1lll11111ll_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_):
	l1lll11lllll_l1_ = int(mode)
	l1lll1l11111_l1_ = int(l1lll11lllll_l1_//10)
	if   l1lll1l11111_l1_==0:  from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==2:  from l1ll1lll111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==3:  from l11l11ll1ll_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,l1llllll1_l1_)
	elif l1lll1l11111_l1_==5:  from l11lll1l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==8:  from l1ll1lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==9:  from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==10: from l1llll1llll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url)
	elif l1lll1l11111_l1_==11: from l1ll1llll111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==12: from l11l11ll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==14: from l11ll1llll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1lll1l11111_l1_==15: from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==16: from l1ll1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==17: from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==18: from l1ll11ll1ll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==19: from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==21: from l11l11111ll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==22: from l111l1l1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==26: from l1ll1l1ll11l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1lll11lllll_l1_,context)
	elif l1lll1l11111_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==29: from l11ll111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==30: from l1lllllll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==31: from l11l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==32: from l1ll1l11111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==33: from l11lll1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url)
	elif l1lll1l11111_l1_==34: from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==36: from l1llll11ll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==38: from l11l1l11l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==39: from l1lllll1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==40: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1l11111_l1_==41: from l1l1l111l1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_)
	elif l1lll1l11111_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==43: from l111l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==44: from l111l11l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==45: from l11lllll11l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==46: from l1111l1ll11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==47: from l11111111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==48: from l1ll1l1llll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==49: from l11111l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==50: from l1l11lllll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,text)
	elif l1lll1l11111_l1_==51: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==52: from l1111l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==53: from l1ll1l1ll11l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==54: from l1111l1l11_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,l1llllll1_l1_)
	elif l1lll1l11111_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==56: from l1ll1llllll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==57: from l1llll1ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==58: from l11ll1l11l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==59: from l1llll11lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==60: from l1llll11l1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==62: from l1lllll1l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==63: from l11111ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==64: from l111l11l111_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==66: from l11lll111l1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==67: from l1ll11lll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==68: from l11ll1l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==70: from l1ll111ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1lll11lllll_l1_,url,text,type,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==74: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_)
	elif l1lll1l11111_l1_==75: from l1ll1ll1ll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_)
	elif l1lll1l11111_l1_==76: from l1ll1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text,l1llllll1_l1_,l1llllll1ll_l1_)
	elif l1lll1l11111_l1_==77: from l111llll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==78: from l111ll1l1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==79: from l111ll11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==80: from l111l1lll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	elif l1lll1l11111_l1_==81: from l1ll11lllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,text)
	elif l1lll1l11111_l1_==82: from l1111ll11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1lll11lllll_l1_,url,l1llllll1_l1_,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l11111111ll_l1_(code,reason,source,l11_l1_):
	l1111l11111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㗌"))
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㗍"),l1l111_l1_ (u"ࠬ࠭㗎"))
	if l1l111_l1_ (u"࠭࠭ࠨ㗏") in source: l1lll11ll11_l1_ = source.split(l1l111_l1_ (u"ࠧ࠮ࠩ㗐"),1)[0]
	else: l1lll11ll11_l1_ = source
	l11l1ll1l11_l1_ = code in [7,11001,11002,10054]
	l1ll11ll1111_l1_ = reason.lower()
	l111ll1111l_l1_ = code in [0,104,10061,111]
	l1llllll1ll1_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ㗑") in l1ll11ll1111_l1_
	l1llllll1l1l_l1_ = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ㗒") in l1ll11ll1111_l1_
	l1llllll1l11_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ㗓") in l1ll11ll1111_l1_
	l1llllll11ll_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭㗔") in l1ll11ll1111_l1_
	l1ll1ll1ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ㗕"))
	l1ll1l1lll11_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ㗖"))
	l1111ll1l11_l1_ = l1l111_l1_ (u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ㗗")
	l1111l11lll_l1_ = l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠨ㗘")+str(code)+l1l111_l1_ (u"ࠩ࠽ࠤࠬ㗙")+reason
	l1111l11lll_l1_ = l111l11_l1_(l1111l11lll_l1_)
	if l111ll1111l_l1_ or l1llllll1ll1_l1_ or l1llllll1l1l_l1_ or l1llllll1l11_l1_ or l1llllll11ll_l1_:
		l1111ll1l11_l1_ += l1l111_l1_ (u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ㗚")
	if l11l1ll1l11_l1_: l1111ll1l11_l1_ += l1l111_l1_ (u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ㗛")
	l1111l11lll_l1_ = l1l111_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㗜")+l1111l11lll_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗝")
	if l1ll1ll1ll1l_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㗞") or l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㗟"):
		l1111ll1l11_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㗠")
	l11lll11l1l_l1_ = False
	if l11_l1_ and source not in l111111lll1_l1_:
		if l1ll1ll1ll1l_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㗡") or l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㗢"):
			l11l1111l1l_l1_ = l1ll11ll11l1_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㗣"),l1l111_l1_ (u"࠭ฮา๊ฯࠫ㗤"),l1l111_l1_ (u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭㗥"),l1l111_l1_ (u"ࠨวุ่ฬำࠠศๆุ่่๊ษࠨ㗦"),l1lll11ll11_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㗧")+TRANSLATE(l1lll11ll11_l1_),l1111ll1l11_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㗨")+l1111l11lll_l1_)
			if l11l1111l1l_l1_==1:
				from l1l11lllll1_l1_ import l1lll1l1lll1_l1_
				l1lll1l1lll1_l1_()
			elif l11l1111l1l_l1_==2: l11lll11l1l_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㗩"),l1l111_l1_ (u"ࠬ࠭㗪"),l1lll11ll11_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࠪ㗫")+TRANSLATE(l1lll11ll11_l1_),l1111ll1l11_l1_,l1111l11lll_l1_)
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㗬"),l1111l11111_l1_)
	return l11lll11l1l_l1_
def l11l1lll1l1_l1_(l1ll1l1l1lll_l1_=False,l1ll1ll1l11l_l1_=[]):
	l1111ll1lll_l1_ = [l1l1l1111l1_l1_,favoritesfile,l1ll11l11lll_l1_]+l1ll1ll1l11l_l1_
	for filename in os.listdir(addoncachefolder):
		if l1ll1l1l1lll_l1_ and (filename.startswith(l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭㗭")) or filename.startswith(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠭㗮"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩ㗯")): continue
		l111111l11l_l1_ = os.path.join(addoncachefolder,filename)
		if l111111l11l_l1_ in l1111ll1lll_l1_: continue
		try: os.remove(l111111l11l_l1_)
		except: pass
	if addonimagesfolder not in l1111ll1lll_l1_: l1llll1ll1_l1_(addonimagesfolder,True,False)
	time.sleep(1)
	return
def l1llll1l1l1l_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll11_l1_=True,l1lll1ll1l1l_l1_=True):
	url = url+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㗰")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll11_l1_,l1lll1ll1l1l_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l1111l1l1ll_l1_(l1l111_l1_ (u"ࠬࡎࡔࡕࡒࠣࡖࡪࡷࡵࡦࡵࡷࠤࡋࡧࡩ࡭ࡷࡵࡩࠬ㗱"))
	return response
def l1ll1l1ll1l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㗲"),url,l1l111_l1_ (u"ࠧࠨ㗳"),l1l111_l1_ (u"ࠨࠩ㗴"),True,l1l111_l1_ (u"ࠩࠪ㗵"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ㗶"),True,False)
	l111l1llll1_l1_ = []
	if response.succeeded:
		html = response.content
		l1lll1l1llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧ㗷"),html)
		if l1lll1l1llll_l1_: html = l1l111_l1_ (u"ࠬࡢ࡮ࠨ㗸").join(l1lll1l1llll_l1_)
		proxies = html.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㗹"),l1l111_l1_ (u"ࠧࠨ㗺")).strip(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㗻")).split(l1l111_l1_ (u"ࠩ࡟ࡲࠬ㗼"))
		l111l1llll1_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠪ࠲ࠬ㗽"))==3: l111l1llll1_l1_.append(proxy)
	return l111l1llll1_l1_
def l11ll11lll1_l1_(*args):
	l11lll1lll1_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬ㗾")
	l1lllllll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩ㗿")
	l111l1lllll_l1_ = l1ll1l1ll1l1_l1_(l1lllllll1ll_l1_)
	l111l1llll1_l1_ = l1ll1l1ll1l1_l1_(l11lll1lll1_l1_)
	l11lllll1l1_l1_ = l111l1lllll_l1_+l111l1llll1_l1_
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㘀"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡋࡴࡺࠠࡱࡴࡲࡼ࡮࡫ࡳࠡ࡮࡬ࡷࡹࠦࠠࠡ࠳ࡶࡸ࠰࠸࡮ࡥ࠼ࠣ࡟ࠥ࠭㘁")+str(len(l111l1lllll_l1_))+l1l111_l1_ (u"ࠨ࠭ࠪ㘂")+str(len(l111l1llll1_l1_))+l1l111_l1_ (u"ࠩࠣࡡࠬ㘃"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ㘄"))
	response = l1l1lllll11_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㘅"),l1l111_l1_ (u"ࠬ࠭㘆"))
	if proxy or l11lllll1l1_l1_:
		id,l1l11111lll_l1_ = 0,10
		l111ll1llll_l1_ = len(l11lllll1l1_l1_)
		l11l1111111_l1_ = l1l11111lll_l1_
		if l111ll1llll_l1_>l11l1111111_l1_: counts = l11l1111111_l1_
		else: counts = l111ll1llll_l1_
		l11l1l1ll1l_l1_ = random.sample(l11lllll1l1_l1_,counts)
		if proxy: l11l1l1ll1l_l1_ = [proxy]+l11l1l1ll1l_l1_
		threads = l11l11l1lll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l11111lll_l1_ and not threads.l11l1l1l11l_l1_:
			if id<counts:
				proxy = l11l1l1ll1l_l1_[id]
				threads.start_new_thread(id,l1llll1l1l1l_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㘇"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㘈")+proxy+l1l111_l1_ (u"ࠨࠢࡠࠫ㘉"))
		l11l1l1l11l_l1_ = threads.l11l1l1l11l_l1_
		if l11l1l1l11l_l1_:
			l1111ll1ll1_l1_ = threads.l1111ll1ll1_l1_
			l1111l11l1l_l1_ = l11l1l1l11l_l1_[0]
			response = l1111ll1ll1_l1_[l1111l11l1l_l1_]
			proxy = l11l1l1ll1l_l1_[int(l1111l11l1l_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㘊"),proxy)
			if l1111l11l1l_l1_!=0: l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㘋"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㘌")+proxy+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㘍"))
			else: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㘎"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㘏")+proxy+l1l111_l1_ (u"ࠨࠢࡠࠫ㘐"))
	return response
def l1ll1l11l1l1_l1_(connection,l1ll11lll1l1_l1_):
	l11l11l111l_l1_ = connection.create_connection
	def l1lll1111ll1_l1_(address,*args,**kwargs):
		host,port = address
		l1lll1l11l11_l1_ = DNS_RESOLVER(host,l1ll11lll1l1_l1_)
		if l1lll1l11l11_l1_: host = l1lll1l11l11_l1_[0]
		else:
			if l1ll11lll1l1_l1_ in l1111lll1ll_l1_: l1111lll1ll_l1_.remove(l1ll11lll1l1_l1_)
			if l1111lll1ll_l1_:
				l111lll1ll1_l1_ = l1111lll1ll_l1_[0]
				l1lll1l11l11_l1_ = DNS_RESOLVER(host,l111lll1ll1_l1_)
				if l1lll1l11l11_l1_: host = l1lll1l11l11_l1_[0]
		address = (host,port)
		return l11l11l111l_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll1111ll1_l1_
	return l11l11l111l_l1_
def l1ll11ll1l11_l1_(url):
	l11l1lll111_l1_,l111l1l1l11_l1_ = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ㘑"))[2],80
	if l1l111_l1_ (u"ࠪ࠾ࠬ㘒") in l11l1lll111_l1_: l11l1lll111_l1_,l111l1l1l11_l1_ = l11l1lll111_l1_.split(l1l111_l1_ (u"ࠫ࠿࠭㘓"))
	l1111ll1111_l1_ = l1l111_l1_ (u"ࠬ࠵ࠧ㘔")+l1l111_l1_ (u"࠭࠯ࠨ㘕").join(url.split(l1l111_l1_ (u"ࠧ࠰ࠩ㘖"))[3:])
	request = l1l111_l1_ (u"ࠨࡉࡈࡘࠥ࠭㘗")+l1111ll1111_l1_+l1l111_l1_ (u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩ㘘")
	request += l1l111_l1_ (u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ㘙")+l11l1lll111_l1_+l1l111_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㘚")
	request += l1l111_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㘛")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1lll111_l1_,l111l1l1l11_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"࠭ࠧ㘜")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"ࠧ࠯ࠩ㘝") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ㘞")
	l1111l111l1_l1_,l1lll111l1l1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠱ࠫ㘟"),1)
	l1lll111l11l_l1_,l1lll111l111_l1_ = l1lll111l1l1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ㘠"),1)
	server = l1111l111l1_l1_+l1l111_l1_ (u"ࠫ࠳࠭㘡")+l1lll111l11l_l1_
	if type in [l1l111_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ㘢"),l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㘣")] and l1l111_l1_ (u"ࠧ࠰ࠩ㘤") in server: server = server.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪ㘥"),1)[1]
	if type==l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㘦") and l1l111_l1_ (u"ࠪ࠲ࠬ㘧") in server:
		l1ll1lll1lll_l1_ = server.split(l1l111_l1_ (u"ࠫ࠳࠭㘨"))
		l1l1l11ll11_l1_ = len(l1ll1lll1lll_l1_)
		if l1l1l11ll11_l1_<=2 or l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㘩") in server: l1ll1lll1lll_l1_ = l1ll1lll1lll_l1_[0]
		elif l1l1l11ll11_l1_>=3: l1ll1lll1lll_l1_ = l1ll1lll1lll_l1_[1]
		if len(l1ll1lll1lll_l1_)>1: server = l1ll1lll1lll_l1_
	return server
def l111lll1111_l1_(l11l11ll11l_l1_):
	l11l1111ll1_l1_ = repr(l11l11ll11l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㘪"))).replace(l1l111_l1_ (u"ࠢࠨࠤ㘫"),l1l111_l1_ (u"ࠨࠩ㘬"))
	return l11l1111ll1_l1_
def l1ll11l11l1_l1_(string):
	l1ll1l11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ㘭")
	if PY2: string = string.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㘮"))
	from unicodedata import decomposition
	for l11111l1l11_l1_ in string:
		if   l11111l1l11_l1_==l1l111_l1_ (u"ࡹࠬศࠧ㘯"): l11l111l11l_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭㘰")
		elif l11111l1l11_l1_==l1l111_l1_ (u"ࡻࠧฤࠩ㘱"): l11l111l11l_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨ㘲")
		elif l11111l1l11_l1_==l1l111_l1_ (u"ࡶࠩวࠫ㘳"): l11l111l11l_l1_ = l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪ㘴")
		elif l11111l1l11_l1_==l1l111_l1_ (u"ࡸࠫส࠭㘵"): l11l111l11l_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬ㘶")
		elif l11111l1l11_l1_==l1l111_l1_ (u"ࡺ࠭ฦࠨ㘷"): l11l111l11l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ㘸")
		else:
			l1ll111lllll_l1_ = decomposition(l11111l1l11_l1_)
			if l1l111_l1_ (u"ࠧࠡࠩ㘹") in l1ll111lllll_l1_: l11l111l11l_l1_ = l1l111_l1_ (u"ࠨ࡞࡟ࡹࠬ㘺")+l1ll111lllll_l1_.split(l1l111_l1_ (u"ࠩࠣࠫ㘻"),1)[1]
			else:
				l11l111l11l_l1_ = l1l111_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ㘼")+hex(ord(l11111l1l11_l1_)).replace(l1l111_l1_ (u"ࠫ࠵ࡾࠧ㘽"),l1l111_l1_ (u"ࠬ࠭㘾"))
				l11l111l11l_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷࠪ㘿")+l11l111l11l_l1_[-4:]
		l1ll1l11l1ll_l1_ += l11l111l11l_l1_
	l1ll1l11l1ll_l1_ = l1ll1l11l1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨ㙀"),l1l111_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ࠩ㙁"))
	if PY2: l1ll1l11l1ll_l1_ = l1ll1l11l1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㙂")).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㙃"))
	else: l1ll1l11l1ll_l1_ = l1ll1l11l1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㙄")).decode(l1l111_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㙅"))
	return l1ll1l11l1ll_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"࠭ไ้ฯฬࠤฬ๊ๅโษอ๎า࠭㙆"),default=l1l111_l1_ (u"ࠧࠨ㙇"),l111llllll1_l1_=False,source=l1l111_l1_ (u"ࠨࠩ㙈")):
	text = l1lll1l1l11l_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠩࠣࠤࠬ㙉"),l1l111_l1_ (u"ࠪࠤࠬ㙊")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ㙋"),l1l111_l1_ (u"ࠬࠦࠧ㙌")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ㙍"),l1l111_l1_ (u"ࠧࠡࠩ㙎"))
	if not text and not l111llllll1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㙏"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㙐")+text+l1l111_l1_ (u"ࠪࠦࠬ㙑"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㙒"),l1l111_l1_ (u"ࠬ࠭㙓"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㙔"),l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สีฮศๆࠪ㙕"))
		return l1l111_l1_ (u"ࠨࠩ㙖")
	if text not in [l1l111_l1_ (u"ࠩࠪ㙗"),l1l111_l1_ (u"ࠪࠤࠬ㙘")]:
		text = text.strip(l1l111_l1_ (u"ࠫࠥ࠭㙙"))
		text = l1ll11l11l1_l1_(text)
	if source!=l1l111_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙ࠧ㙚") and l11111l_l1_(l1l111_l1_ (u"࠭ࡋࡆ࡛ࡅࡓࡆࡘࡄࠨ㙛"),l1l111_l1_ (u"ࠧࠨ㙜"),[text],False):
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㙝"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬ㙞")+text+l1l111_l1_ (u"ࠪࠦࠬ㙟"))
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㙠"),l1l111_l1_ (u"ࠬ࠭㙡"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㙢"),l1l111_l1_ (u"ࠧศ่อࠤ่ะศหࠢๆ่๊ฯࠠฤ๊ࠣี็๋ࠠๅ้ࠣ฽้อโสࠢหวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼ࠦ࠮࠯๋๋ࠢีอࠠศๆหี๋อๅอࠢ็หࠥ๐ำๆฯࠣฬฬูสฯัส้ࠥํใัษࠣ็้๋วหࠩ㙣"))
		return l1l111_l1_ (u"ࠨࠩ㙤")
	l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㙥"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡢ࡮࡯ࡳࡼ࡫ࡤ࠻ࠢࠣࠤࠧ࠭㙦")+text+l1l111_l1_ (u"ࠫࠧ࠭㙧"))
	return text
def l1l11l11ll_l1_(l1lllll1_l1_,l1ll1ll1l_l1_={}):
	url,l11111l11l1_l1_,l1ll1ll11_l1_,l111lll1lll_l1_ = l1lllll1_l1_,{},{},l1l111_l1_ (u"ࠬ࠭㙨")
	if l1l111_l1_ (u"࠭ࡼࠨ㙩") in l1lllll1_l1_: url,l11111l11l1_l1_ = l1ll11ll1_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡽࠩ㙪"))
	l1lll11lll1l_l1_ = list(set(list(l1ll1ll1l_l1_.keys())+list(l11111l11l1_l1_.keys())))
	for key in l1lll11lll1l_l1_:
		if key in list(l11111l11l1_l1_.keys()): l1ll1ll11_l1_[key] = l11111l11l1_l1_[key]
		else: l1ll1ll11_l1_[key] = l1ll1ll1l_l1_[key]
	if l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㙫") not in l1lll11lll1l_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㙬")] = l1l1ll11l_l1_()
	if l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㙭") not in l1lll11lll1l_l1_: l1ll1ll11_l1_[l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㙮")] = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ㙯"))
	for key in list(l1ll1ll11_l1_.keys()): l111lll1lll_l1_ += l1l111_l1_ (u"࠭ࠦࠨ㙰")+key+l1l111_l1_ (u"ࠧ࠾ࠩ㙱")+l1ll1ll11_l1_[key]
	if l111lll1lll_l1_: l111lll1lll_l1_ = l1l111_l1_ (u"ࠨࡾࠪ㙲")+l111lll1lll_l1_[1:]
	response = l11l1l_l1_(l1llll111lll_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㙳"),url,l1l111_l1_ (u"ࠪࠫ㙴"),l1ll1ll11_l1_,l1l111_l1_ (u"ࠫࠬ㙵"),l1l111_l1_ (u"ࠬ࠭㙶"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ㙷"),False,False)
	html = response.content
	if l1l111_l1_ (u"ࠧࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉࠫ㙸") not in html: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㙹")],[url+l111lll1lll_l1_]
	if l1l111_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭㙺") in html: return [l1l111_l1_ (u"ࠪ࠱࠶࠭㙻")],[url+l111lll1lll_l1_]
	if l1l111_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ㙼") in html: return [l1l111_l1_ (u"ࠬ࠳࠱ࠨ㙽")],[url+l111lll1lll_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111ll11lll_l1_,l1lll1lll1l1_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"࠭ࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ㙾"),html+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㙿"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠨ࠯࠴ࠫ㚀")],[url+l111lll1lll_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1ll1l111l1l_l1_,l11ll111lll_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠩࠪ㚁")
		items = line.split(l1l111_l1_ (u"ࠪ࠰ࠬ㚂"))
		for item in items:
			if l1l111_l1_ (u"ࠫࡂ࠭㚃") in item:
				key,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ㚄"),1)
				l1ll1l111l1l_l1_[key.lower()] = value
		if l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㚅") in line.lower():
			l11ll111lll_l1_ = int(l1ll1l111l1l_l1_[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㚆")])//1024
			title += str(l11ll111lll_l1_)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㚇")
		elif l1l111_l1_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㚈") in line.lower():
			l11ll111lll_l1_ = int(l1ll1l111l1l_l1_[l1l111_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㚉")])//1024
			title += str(l11ll111lll_l1_)+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㚊")
		if l1l111_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㚋") in line.lower():
			l111l1ll_l1_ = int(l1ll1l111l1l_l1_[l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪ㚌")].split(l1l111_l1_ (u"ࠧࡹࠩ㚍"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠫ㚎")
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠤࠬ㚏"))
		if not title: title = l1l111_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ㚐")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㚑")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠬ࠵࠯ࠨ㚒")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"࠭࠺ࠨ㚓"),1)[0]+l1l111_l1_ (u"ࠧ࠻ࠩ㚔")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠱ࠪ㚕")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭㚖"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㚗"),1)[0]+l1l111_l1_ (u"ࠫ࠴࠭㚘")+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㚙") in list(l1ll1l111l1l_l1_.keys()):
			l111lllll_l1_ = l1ll1l111l1l_l1_[l1l111_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ㚚")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠧࠣࠩ㚛"),l1l111_l1_ (u"ࠨࠩ㚜")).replace(l1l111_l1_ (u"ࠤࠪࠦ㚝"),l1l111_l1_ (u"ࠪࠫ㚞")).split(l1l111_l1_ (u"ࠫࠨ࠭㚟"),1)[0]
			l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l111lllll_l1_)
			if l11ll1l1l1_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"ࠬࠦࠠࠨ㚠")+l11ll1l1l1_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭㚡")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪ㚢")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭㚣"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111ll11lll_l1_.append(l111l1ll_l1_)
			l1lll1lll1l1_l1_.append(l11ll111lll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠦࠫ㚤"),1)[0]
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l1l1_l1_: title = title+l1l111_l1_ (u"ࠪࠤࠥ࠭㚥")+l11ll1l1l1_l1_
		title = title+l1l111_l1_ (u"ࠫࠥࠦࠧ㚦")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㚧"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111ll11lll_l1_.append(l111l1ll_l1_)
		l1lll1lll1l1_l1_.append(l11ll111lll_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111ll11lll_l1_,l1lll1lll1l1_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111ll11lll_l1_,l1lll1lll1l1_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	l1ll11l111l1_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_: l1ll11l111l1_l1_.append(l1ll1ll_l1_+l111lll1lll_l1_)
	return l1l1lll1_l1_,l1ll11l111l1_l1_
def DNS_RESOLVER(host,l1ll11lll1l1_l1_=l1l111_l1_ (u"࠭ࠧ㚨")):
	if not l1ll11lll1l1_l1_: l1ll11lll1l1_l1_ = l1111lll1ll_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠧ࠯ࠩ㚩"),l1l111_l1_ (u"ࠨࠩ㚪")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l1lllll1l111_l1_ = pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚫"), 12049)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㚬"), 256)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㚭"), 1)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㚮"), 0)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㚯"), 0)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㚰"), 0)
		if PY3: l111111111l_l1_ = host.split(l1l111_l1_ (u"ࠨ࠰ࠪ㚱"))
		else: l111111111l_l1_ = host.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚲")).split(l1l111_l1_ (u"ࠪ࠲ࠬ㚳"))
		for part in l111111111l_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㚴"))
			l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠧࡈࠢ㚵"), len(part))
			for l111l1l111l_l1_ in part:
				l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠨࡣࠣ㚶"), l111l1l111l_l1_.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚷")))
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠣࡄࠥ㚸"), 0)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠤࡁࡌࠧ㚹"), 1)
		l1lllll1l111_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㚺"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l1lllll1l111_l1_), (l1ll11lll1l1_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1ll11l1_l1_ = unpack_from(l1l111_l1_ (u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ㚻"), data, 0)
		l111lll11ll_l1_ = l11l1ll11l1_l1_[3]
		offset = len(host)+18
		l11l11l11ll_l1_ = []
		for _ in range(l111lll11ll_l1_):
			l111ll11l1l_l1_ = offset
			l1llll1lll1l_l1_ = 1
			l1111ll11ll_l1_ = False
			while True:
				l111l1l111l_l1_ = unpack_from(l1l111_l1_ (u"ࠧࡄࡂࠣ㚼"), data, l111ll11l1l_l1_)[0]
				if l111l1l111l_l1_ == 0:
					l111ll11l1l_l1_ += 1
					break
				if l111l1l111l_l1_ >= 192:
					l111l11l1l1_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࡃࠤ㚽"), data, l111ll11l1l_l1_ + 1)[0]
					l111ll11l1l_l1_ = ((l111l1l111l_l1_ << 8) + l111l11l1l1_l1_ - 0xc000) - 1
					l1111ll11ll_l1_ = True
				l111ll11l1l_l1_ += 1
				if l1111ll11ll_l1_ == False: l1llll1lll1l_l1_ += 1
			if l1111ll11ll_l1_ == True: l1llll1lll1l_l1_ += 1
			offset = offset + l1llll1lll1l_l1_
			l11llll1ll1_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࡊࡋࡍࡍࠨ㚾"), data, offset)
			offset = offset + 10
			l11l1ll1ll1_l1_ = l11llll1ll1_l1_[0]
			l1111ll1l1l_l1_ = l11llll1ll1_l1_[3]
			if l11l1ll1ll1_l1_ == 1:
				l111l1l11ll_l1_ = unpack_from(l1l111_l1_ (u"ࠣࡀࠥ㚿")+l1l111_l1_ (u"ࠤࡅࠦ㛀")*l1111ll1l1l_l1_, data, offset)
				l1lll1l11l11_l1_ = l1l111_l1_ (u"ࠪࠫ㛁")
				for l111l1l111l_l1_ in l111l1l11ll_l1_: l1lll1l11l11_l1_ += str(l111l1l111l_l1_) + l1l111_l1_ (u"ࠫ࠳࠭㛂")
				l1lll1l11l11_l1_ = l1lll1l11l11_l1_[0:-1]
				l11l11l11ll_l1_.append(l1lll1l11l11_l1_)
			if l11l1ll1ll1_l1_ in [1,2,5,6,15,28]: offset = offset + l1111ll1l1l_l1_
	except: l11l11l11ll_l1_ = []
	if not l11l11l11ll_l1_: l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㛃"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬ㛄")+host+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㛅"))
	return l11l11l11ll_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1ll111l_l1_ = [l1l111_l1_ (u"ࠨๅหหึ࠭㛆"),l1l111_l1_ (u"ࠩหห้เࠧ㛇"),l1l111_l1_ (u"ࠪࡥࡩࡻ࡬ࡵࠩ㛈"),l1l111_l1_ (u"ࠫࡽࡾࠧ㛉"),l1l111_l1_ (u"ࠬࡹࡥࡹࠩ㛊")]
		if l1ll1_l1_!=l1l111_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㛋"):
			l11l1ll111l_l1_ += [l1l111_l1_ (u"ࠧࡳ࠼ࠪ㛌"),l1l111_l1_ (u"ࠨࡴ࠰ࠫ㛍"),l1l111_l1_ (u"ࠩ࠰ࡱࡦ࠭㛎")]
			l11l1ll111l_l1_ += [l1l111_l1_ (u"ࠪ࠾ࡷ࠭㛏"),l1l111_l1_ (u"ࠫ࠲ࡸࠧ㛐"),l1l111_l1_ (u"ࠬࡳࡡ࠮ࠩ㛑")]
		for l1111lllll_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"࠭ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨ㛒") in l1111lllll_l1_: continue
			if l1l111_l1_ (u"ࠧฮๆๅอࠬ㛓") in l1111lllll_l1_: continue
			l1111lllll_l1_ = l1111lllll_l1_.lower()
			if PY2: l1111lllll_l1_ = l1111lllll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㛔")).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛕"))
			l1111lllll_l1_ = l1111lllll_l1_.replace(l1l111_l1_ (u"ࠪ࠾ࠬ㛖"),l1l111_l1_ (u"ࠫࠬ㛗"))
			l111l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩ㛘"),l1111lllll_l1_,re.DOTALL)
			l1lll1llll11_l1_ = False
			for digits in l111l11llll_l1_:
				if len(digits)==2:
					l1lll1llll11_l1_ = True
					break
			if l1l111_l1_ (u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩ㛙") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨ㛚") in l1111lllll_l1_: continue
			elif l1l111_l1_ (u"ࠨ฼ํี๋ࠥี็ใࠪ㛛") in l1111lllll_l1_: continue
			elif l1l111lllll_l1_(l1l111_l1_ (u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫ㛜")): continue
			elif l1111lllll_l1_ in [l1l111_l1_ (u"ࠪࡶࠬ㛝")] or l1lll1llll11_l1_ or any(value in l1111lllll_l1_ for value in l11l1ll111l_l1_):
				l1l111111l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㛞"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㛟")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㛠"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㛡"),l1l111_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ㛢"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1lll1lll1ll_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㛣")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠪหุะๅาษิࠫ㛤")
		header = args[2]
		text = l1l111_l1_ (u"ࠫࡡࡴࠧ㛥").join(args[3:])
	else: l1lll1lll1ll_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"ࠬ࠭㛦"),l1l111_l1_ (u"࠭ࡏࡌࠩ㛧"),l1l111_l1_ (u"ࠧࠨ㛨"),l1l111_l1_ (u"ࠨࠩ㛩")
	l1ll11ll11l1_l1_(l1lll1lll1ll_l1_,l1l111_l1_ (u"ࠩࠪ㛪"),l11l111l_l1_,l1l111_l1_ (u"ࠪࠫ㛫"),header,text,**kwargs)
	return
def l1ll11ll1l_l1_(*args,**kwargs):
	l1lll1lll1ll_l1_ = args[0]
	l1lllll1l11l_l1_ = args[1]
	l1llll1ll11l_l1_ = args[2]
	if l1llll1ll11l_l1_ or l1lllll1l11l_l1_: l1lllll11l1l_l1_ = True
	else: l1lllll11l1l_l1_ = False
	header = args[3]
	text = args[4]
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㛬")
	if not l1lllll1l11l_l1_: l1lllll1l11l_l1_ = l1l111_l1_ (u"้ࠬไศࠢࠣࡒࡴ࠭㛭")
	if not l1llll1ll11l_l1_: l1llll1ll11l_l1_ = l1l111_l1_ (u"࠭ๆฺ็ࠣࠤ࡞࡫ࡳࠨ㛮")
	if len(args)>=6: text += l1l111_l1_ (u"ࠧ࡝ࡰࠪ㛯")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠨ࡞ࡱࠫ㛰")+args[6]
	l11l1111l1l_l1_ = l1ll11ll11l1_l1_(l1lll1lll1ll_l1_,l1lllll1l11l_l1_,l1l111_l1_ (u"ࠩࠪ㛱"),l1llll1ll11l_l1_,header,text,**kwargs)
	if l11l1111l1l_l1_==-1 and l1lllll11l1l_l1_: l11l1111l1l_l1_ = -1
	elif l11l1111l1l_l1_==-1 and not l1lllll11l1l_l1_: l11l1111l1l_l1_ = False
	elif l11l1111l1l_l1_==0: l11l1111l1l_l1_ = False
	elif l11l1111l1l_l1_==2: l11l1111l1l_l1_ = True
	return l11l1111l1l_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㛲") in list(kwargs.keys()): l11lllllll1_l1_ = kwargs[l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ㛳")]
	else: l11lllllll1_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㛴") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ㛵")
	l1ll1l1l1l11_l1_ = l1l1l1llll1_l1_(l1l111_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧ㛶"),l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㛷"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㛸"))
	l11111lll11_l1_ = l1ll11lllll1_l1_.replace(l1l111_l1_ (u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ㛹"),l1l111_l1_ (u"ࠫࡤ࠭㛺")+str(time.time())+l1l111_l1_ (u"ࠬࡥࠧ㛻"))
	l11111lll11_l1_ = l11111lll11_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ㛼"),l1l111_l1_ (u"ࠧ࡝࡞࡟ࡠࠬ㛽")).replace(l1l111_l1_ (u"ࠨ࠱࠲ࠫ㛾"),l1l111_l1_ (u"ࠩ࠲࠳࠴࠵ࠧ㛿"))
	l11l1111lll_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠪࠫ㜀"),l1l111_l1_ (u"ࠫࠬ㜁"),l1l111_l1_ (u"ࠬ࠭㜂"),header,text,profile,l1l111_l1_ (u"࠭࡬ࡦࡨࡷࠫ㜃"),False,l11111lll11_l1_)
	l1ll1l1l1l11_l1_.show()
	if profile==l1l111_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ㜄"):
		l1ll1l1l1l11_l1_.getControl(9040).setHeight(215)
		l1ll1l1l1l11_l1_.getControl(9040).setPosition(55,-80)
		l1ll1l1l1l11_l1_.getControl(9050).setPosition(120,-60)
		l1ll1l1l1l11_l1_.getControl(400).setPosition(90,-35)
	l1ll1l1l1l11_l1_.getControl(401).setVisible(False)
	l1ll1l1l1l11_l1_.getControl(402).setVisible(False)
	l1ll1l1l1l11_l1_.getControl(9050).setImage(l11111lll11_l1_)
	l1ll1l1l1l11_l1_.getControl(9050).setHeight(l11l1111lll_l1_)
	l11llll1lll_l1_ = threading.Thread(target=l1ll11l1111l_l1_,args=(l1ll1l1l1l11_l1_,l11111lll11_l1_,l11lllllll1_l1_))
	l11llll1lll_l1_.start()
	return
def l1ll11l1111l_l1_(l1ll1l1l1l11_l1_,l11111lll11_l1_,l11lllllll1_l1_):
	time.sleep(l11lllllll1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l11111lll11_l1_):
		try: os.remove(l11111lll11_l1_)
		except: pass
	return
def l1ll1ll11l11_l1_(*args,**kwargs):
	header,text,profile,l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㜅"),l1l111_l1_ (u"ࠩࠪ㜆"),l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㜇"),l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㜈")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1lll1lll1ll_l1_ = args[3]
	return l1l11l1l1l_l1_(l1lll1lll1ll_l1_,header,text,profile)
def l11ll11111l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1lll111lll1_l1_(*args,**kwargs)
def l1l11111l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1lll1l1l11l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l1l111lll1_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll11ll1l_l1_(l1llll1l1ll1_l1_):
	if kodi_version>17.99: l1ll1l1l1l11_l1_ = l1l111_l1_ (u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪ㜉")
	else: l1ll1l1l1l11_l1_ = l1l111_l1_ (u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪ㜊")
	l1llll1l1ll1_l1_ = l1llll1l1ll1_l1_.lower()
	if l1llll1l1ll1_l1_==l1l111_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭㜋"): xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࠪ㜌")+l1ll1l1l1l11_l1_+l1l111_l1_ (u"ࠩࠬࠫ㜍"))
	elif l1llll1l1ll1_l1_==l1l111_l1_ (u"ࠪࡷࡹࡵࡰࠨ㜎"): xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫ㜏")+l1ll1l1l1l11_l1_+l1l111_l1_ (u"ࠬ࠯ࠧ㜐"))
	return
def l1ll11ll11l1_l1_(l1lll1lll1ll_l1_,l111l1lll11_l1_=l1l111_l1_ (u"࠭ࠧ㜑"),l1ll1lll111l_l1_=l1l111_l1_ (u"ࠧࠨ㜒"),l1llllll1lll_l1_=l1l111_l1_ (u"ࠨࠩ㜓"),header=l1l111_l1_ (u"ࠩࠪ㜔"),text=l1l111_l1_ (u"ࠪࠫ㜕"),profile=l1l111_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭㜖"),l1lllll111ll_l1_=0,l1lll11lll11_l1_=0):
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㜗")
	l1ll1l1l1l11_l1_ = l1ll1lllll1l_l1_(l1l111_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ㜘"),l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ㜙"),l1l111_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭㜚"))
	l1ll1l1l1l11_l1_.l11l11ll1l1_l1_(l111l1lll11_l1_,l1ll1lll111l_l1_,l1llllll1lll_l1_,header,text,profile,l1lll1lll1ll_l1_,l1lllll111ll_l1_,l1lll11lll11_l1_)
	if l1lllll111ll_l1_>0: l1ll1l1l1l11_l1_.l11llll11l1_l1_()
	if l1lll11lll11_l1_>0: l1ll1l1l1l11_l1_.l11ll1lll1l_l1_()
	if l1lllll111ll_l1_==0 and l1lll11lll11_l1_==0: l1ll1l1l1l11_l1_.l11l11l1l1l_l1_()
	l1ll1l1l1l11_l1_.doModal()
	l11l1111l1l_l1_ = l1ll1l1l1l11_l1_.l11llll1l1l_l1_
	return l11l1111l1l_l1_
def l1l11l1l1l_l1_(l1lll1lll1ll_l1_,header,text,profile=l1l111_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ㜛")):
	if not l1lll1lll1ll_l1_: l1lll1lll1ll_l1_ = l1l111_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ㜜")
	l1ll1l1l1l11_l1_ = l1l1l1llll1_l1_(l1l111_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧ㜝"),l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭㜞"),l1l111_l1_ (u"࠭࠷࠳࠲ࡳࠫ㜟"))
	l11111lll11_l1_ = l1ll11lllll1_l1_.replace(l1l111_l1_ (u"ࠧࡠ࠲࠳࠴࠵ࡥࠧ㜠"),l1l111_l1_ (u"ࠨࡡࠪ㜡")+str(time.time())+l1l111_l1_ (u"ࠩࡢࠫ㜢"))
	l11111lll11_l1_ = l11111lll11_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭㜣"),l1l111_l1_ (u"ࠫࡡࡢ࡜࡝ࠩ㜤")).replace(l1l111_l1_ (u"ࠬ࠵࠯ࠨ㜥"),l1l111_l1_ (u"࠭࠯࠰࠱࠲ࠫ㜦"))
	l11l1111lll_l1_ = CREATE_IMAGE(l1l111_l1_ (u"ࠧࠨ㜧"),l1l111_l1_ (u"ࠨࠩ㜨"),l1l111_l1_ (u"ࠩࠪ㜩"),header,text,profile,l1lll1lll1ll_l1_,False,l11111lll11_l1_)
	l1ll1l1l1l11_l1_.show()
	l1ll1l1l1l11_l1_.getControl(9050).setHeight(l11l1111lll_l1_)
	l1ll1l1l1l11_l1_.getControl(9050).setImage(l11111lll11_l1_)
	result = l1ll1l1l1l11_l1_.doModal()
	try: os.remove(l11111lll11_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1lll11l11l1_l1_=True):
	if l1lll11l11l1_l1_:
		l11ll1l1ll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㜪"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㜫"),l1l111_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ㜬"))
		if l11ll1l1ll_l1_: return l11ll1l1ll_l1_
	text = l1l111_l1_ (u"࠭ࠧ㜭")
	if 0 and response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ㜮"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㜯"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1111111111_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㜰"),l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫ㜱"))
		text = open(l1111111111_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㜲")).read()
		if PY3: text = text.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㜳"))
		text = text.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ㜴"),l1l111_l1_ (u"ࠧࠨ㜵"))
	l11111l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ㜶"),text,re.DOTALL)
	l11ll11l1ll_l1_ = []
	for line in l11111l1111_l1_:
		l1llll1l11ll_l1_ = line.lower()
		if l1l111_l1_ (u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ㜷") in l1llll1l11ll_l1_: continue
		if l1l111_l1_ (u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ㜸") in l1llll1l11ll_l1_: continue
		if l1l111_l1_ (u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ㜹") in l1llll1l11ll_l1_: continue
		if l1l111_l1_ (u"ࠬࡩࡲࡰࡵࠪ㜺") in l1llll1l11ll_l1_: continue
		l11ll11l1ll_l1_.append(line)
	l11ll1l1ll_l1_ = random.sample(l11ll11l1ll_l1_,1)
	l11ll1l1ll_l1_ = l11ll1l1ll_l1_[0]
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㜻"),l1l111_l1_ (u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㜼"),l11ll1l1ll_l1_,l11l1l1_l1_)
	return l11ll1l1ll_l1_
def l11l1llllll_l1_(l111l11l1ll_l1_=l1l111_l1_ (u"ࠨࠩ㜽")):
	if not l111l11l1ll_l1_: l111l11l1ll_l1_ = traceback.format_exc()
	if l111l11l1ll_l1_!=l1l111_l1_ (u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ㜾"): sys.stderr.write(l111l11l1ll_l1_)
	lines = l111l11l1ll_l1_.splitlines()
	error = lines[-1]
	l111ll11ll1_l1_ = open(l111llll11l_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㜿")).read()
	if PY3: l111ll11ll1_l1_ = l111ll11ll1_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㝀"))
	l111ll11ll1_l1_ = l111ll11ll1_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠬࡃࠧ㝁")*100
	if sep in l111ll11ll1_l1_: l111ll11ll1_l1_ = l111ll11ll1_l1_.rsplit(sep,1)[1]
	if error in l111ll11ll1_l1_: l111ll11ll1_l1_ = l111ll11ll1_l1_.rsplit(error,1)[0]
	l1lll1111l11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬ㝂"),l111ll11ll1_l1_,re.DOTALL)
	for typ,source in reversed(l1lll1111l11_l1_):
		if source: break
	else: source = l1l111_l1_ (u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧ㝃")
	file,line,func = l1l111_l1_ (u"ࠨࠩ㝄"),l1l111_l1_ (u"ࠩࠪ㝅"),l1l111_l1_ (u"ࠪࠫ㝆")
	l11ll1111ll_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฮุล࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝇")+error
	l1lll111llll_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆืาี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㝈")+source
	for l1lllll11lll_l1_ in reversed(lines):
		if l1l111_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭㝉") in l1lllll11lll_l1_ and l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㝊") in l1lllll11lll_l1_: break
	l1lllll11lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫ㝋"),l1lllll11lll_l1_,re.DOTALL)
	if l1lllll11lll_l1_:
		file,line,func = l1lllll11lll_l1_[0]
		if l1l111_l1_ (u"ࠩ࠲ࠫ㝌") in file: file = file.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㝍"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠫࡡࡢࠧ㝎"),1)[1]
		l1ll1l11lll1_l1_ = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๆไ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㝏")+file
		line2 = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีฺี࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㝐")+line
		l11llll11ll_l1_ = l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่็ฬ์࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㝑")+func
		l1lllll11ll1_l1_ = l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝒")+line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝓")+l11llll11ll_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㝔")+l1lll111llll_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㝕")+l11ll1111ll_l1_
		l1llll11l11l_l1_ = line2+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝖")+l1lll111llll_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㝗")+l11ll1111ll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㝘")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝙")+l11llll11ll_l1_
		l1111111lll_l1_ = line2+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㝚")+l11ll1111ll_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㝛")+l1ll1l11lll1_l1_+l1l111_l1_ (u"ࠫࡡࡴࠧ㝜")+l11llll11ll_l1_
	else:
		l1ll1l11lll1_l1_,line2,l11llll11ll_l1_ = l1l111_l1_ (u"ࠬ࠭㝝"),l1l111_l1_ (u"࠭ࠧ㝞"),l1l111_l1_ (u"ࠧࠨ㝟")
		l1lllll11ll1_l1_ = l1lll111llll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㝠")+l11ll1111ll_l1_
		l1llll11l11l_l1_ = l1lll111llll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ㝡")+l11ll1111ll_l1_
		l1111111lll_l1_ = l11ll1111ll_l1_
	l11l11lll11_l1_ = l1l111_l1_ (u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧ㝢")+l1l111_l1_ (u"ࠫࡡࡴࠧ㝣")
	l1ll1l1l11l1_l1_ = l111lllll1l_l1_()
	l1lllllll11l_l1_ = []
	l1lll_l1_ = l1ll1l1l11l1_l1_[l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㝤")]
	l1lllll11l11_l1_ = l1ll11l11ll1_l1_(l1l11l1111l_l1_)
	if l1l111_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㝥") in list(l1ll1l1l11l1_l1_.keys()):
		for l1lll11l1111_l1_,l111l111l1l_l1_,l11ll111l1l_l1_ in l1lll_l1_: l1lllllll11l_l1_ = max(l1lllllll11l_l1_,l111l111l1l_l1_)
		if l1lllll11l11_l1_<l1lllllll11l_l1_:
			header = l1l111_l1_ (u"ࠧใ็ࠣฬฯำฯ๋อࠣห้ฮั็ษ่ะ่ࠥศๅࠢศีุอไࠡษ็วำ฽วยࠢ็่๊ฮัๆฮࠪ㝦")
			l11l1111l1l_l1_ = l1ll11ll11l1_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㝧"),l1l111_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㝨"),l1l111_l1_ (u"ࠪฮาี๊ฬࠩ㝩"),l1l111_l1_ (u"ࠫำื่อࠩ㝪"),l11l11lll11_l1_+header,l1lllll11ll1_l1_)
			if l11l1111l1l_l1_==0:
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㝫"),l1l111_l1_ (u"࠭ฮา๊ฯࠫ㝬"),l1l111_l1_ (u"ࠧหฯา๎ะ࠭㝭"),l1l111_l1_ (u"ࠨࠩ㝮"),header)
				if l1llll111l_l1_==1: l11l1111l1l_l1_ = 1
			if l11l1111l1l_l1_==1:
				from l1l11lllll1_l1_ import l1llll1ll111_l1_
				l1llll1ll111_l1_()
			return
	l1ll11l11111_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㝯"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㝰"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㝱"))
	if not l1ll11l11111_l1_: l1ll11l11111_l1_ = []
	l1llll11l11l_l1_ = l1llll11l11l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㝲"),l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㝳")).replace(l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㝴"),l1l111_l1_ (u"ࠨࠩ㝵")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㝶"),l1l111_l1_ (u"ࠪࠫ㝷")).replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㝸"),l1l111_l1_ (u"ࠬ࠭㝹"))
	l1111111lll_l1_ = l1111111lll_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㝺"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㝻")).replace(l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㝼"),l1l111_l1_ (u"ࠩࠪ㝽")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㝾"),l1l111_l1_ (u"ࠫࠬ㝿")).replace(l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㞀"),l1l111_l1_ (u"࠭ࠧ㞁"))
	l1ll11l1llll_l1_ = l1l11l1111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ㞂")+l1111111lll_l1_
	if l1ll11l1llll_l1_ in l1ll11l11111_l1_:
		header = l1l111_l1_ (u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㞃")
		l1111l1_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㞄"),l1l111_l1_ (u"ࠪࠫ㞅"),l11l11lll11_l1_+header,l1lllll11ll1_l1_)
		return
	l1ll11lll11l_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠫ࠳࠭㞆"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㞇")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㞈"),url,l1l111_l1_ (u"ࠧࠨ㞉"),l1l111_l1_ (u"ࠨࠩ㞊"),l1l111_l1_ (u"ࠩࠪ㞋"),l1l111_l1_ (u"ࠪࠫ㞌"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬ㞍"),False,False)
	html = response.content
	l11ll1lll11_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ㞎"),html,re.DOTALL)
	for l11l11ll111_l1_,l11ll1111l1_l1_,l1111l111ll_l1_,l1llll11l111_l1_ in l11ll1lll11_l1_:
		l11l11ll111_l1_ = l11l11ll111_l1_.split(l1l111_l1_ (u"࠭ࠫࠨ㞏"))
		l1111l111ll_l1_ = l1111l111ll_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㞐"))
		l1llll11l111_l1_ = l1llll11l111_l1_.split(l1l111_l1_ (u"ࠨ࠭ࠪ㞑"))
		if line in l11l11ll111_l1_ and error==l11ll1111l1_l1_ and l1l11l1111l_l1_ in l1111l111ll_l1_ and l1ll11lll11l_l1_ in l1llll11l111_l1_:
			header = l1l111_l1_ (u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧ㞒")
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㞓"),l1l111_l1_ (u"ࠫำื่อࠩ㞔"),l1l111_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㞕"),l11l11lll11_l1_+header,l1lllll11ll1_l1_)
			if l1llll111l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㞖"),l1l111_l1_ (u"ࠧࠨ㞗"),l1l111_l1_ (u"ࠨࠩ㞘"),header)
			return
	header = l1l111_l1_ (u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ㞙")
	l1111l1_l1_(l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㞚"),l1l111_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㞛"),l11l11lll11_l1_+header,l1lllll11ll1_l1_)
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㞜"),l1l111_l1_ (u"࠭ࠧ㞝"),l1l111_l1_ (u"ࠧࠨ㞞"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㞟"),l1l111_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ㞠"))
	if l1llll111l_l1_==1: l1ll11ll11ll_l1_ = l1l111_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭㞡")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㞢"),l1l111_l1_ (u"ࠬ࠭㞣"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㞤"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬ㞥"))
		return
	message = l1llll11l11l_l1_
	from l1l11lllll1_l1_ import l11l1l11l1l_l1_
	succeeded = l11l1l11l1l_l1_(l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࡳࠨ㞦"),message,True,l1l111_l1_ (u"ࠩࠪ㞧"),l1l111_l1_ (u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕࠪ㞨"),l1ll11ll11ll_l1_)
	if succeeded and l1ll11ll11ll_l1_:
		l1ll11l11111_l1_.append(l1ll11l1llll_l1_)
		l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㞩"),l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡖࡉࡓ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧ㞪"),l1ll11l11111_l1_,l1ll111l1ll_l1_)
	return
def l1lll11l11ll_l1_(data):
	if PY3: data = data.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㞫"))
	filename = l1l111_l1_ (u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧ㞬")+str(time.time())+l1l111_l1_ (u"ࠨ࠰ࡧࡥࡹ࠭㞭")
	open(filename,l1l111_l1_ (u"ࠩࡺࡦࠬ㞮")).write(data)
	return
def l11lll1l11l_l1_(l111lll111l_l1_):
	if l111lll111l_l1_:
		l1lll11111l1_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㞯"),l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㞰"),l1l111_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㞱"))
		if l1lll11111l1_l1_: return l1lll11111l1_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㞲")][5]
	l1ll11l11l11_l1_ = l1l11l1l1ll_l1_(32,l111lll111l_l1_)
	l1ll1l111lll_l1_ = l1111lll11l_l1_()
	l1llll1l111l_l1_ = l1ll1l111lll_l1_.split(l1l111_l1_ (u"ࠧ࠭ࠩ㞳"))[2]
	l1ll1lll1ll1_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㞴"))
	l111111ll11_l1_ = l1ll1l11l11l_l1_()
	payload = {l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㞵"):l1ll11l11l11_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ㞶"):l1l11l1111l_l1_,l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㞷"):l1llll1l111l_l1_,l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㞸"):l1lll1ll111l_l1_(l111111ll11_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㞹"),url,payload,l1l111_l1_ (u"ࠧࠨ㞺"),l1l111_l1_ (u"ࠨࠩ㞻"),l1l111_l1_ (u"ࠩࠪ㞼"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡓࡘࡉࡘ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨ㞽"))
	if not response.succeeded: return []
	html = response.content
	l1lll11111l1_l1_ = html.replace(l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㞾"),l1l111_l1_ (u"ࠬࡢ࡮ࠨ㞿")).replace(l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㟀"),l1l111_l1_ (u"ࠧ࡝ࡰࠪ㟁")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㟂"),l1l111_l1_ (u"ࠩ࡟ࡲࠬ㟃")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㟄"),l1l111_l1_ (u"ࠫࡡࡴࠧ㟅"))
	l1lll11111l1_l1_ = re.findall(l1l111_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࠾࠿࠮࡜ࡥ࠭ࠬ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴࡅࡏࡆ࠽࠾ࡊࡔࡄࠨ㟆"),l1lll11111l1_l1_,re.DOTALL)
	if not l1lll11111l1_l1_: return []
	l1lll11111l1_l1_ = sorted(l1lll11111l1_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1ll11l11l11_l1_,l111l111ll1_l1_,l11l11l11ll_l1_,l11l111llll_l1_,reason = l1lll11111l1_l1_[0]
	l1llll11l1ll_l1_ = reason if l1l111lllll_l1_(l1l111_l1_ (u"࠭ࡍࡕ࠲࠸ࡌ࡝࠶࡬ࡕࡖࡈࡊࡓ࡙ࡕࡏࡨࡘࡉ࡛࡙ࡓࡖ࠻ࡈ࡜ࠬ㟇")) else l111l111ll1_l1_
	settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩ㟈"),l1llll11l1ll_l1_)
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㟉"),l1l111_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㟊"),l1lll11111l1_l1_,l11l1l1_l1_)
	return l1lll11111l1_l1_
def SPLIT_BIGLIST(items,l1ll11l1ll1l_l1_=0,l111111l111_l1_=0):
	if l1ll11l1ll1l_l1_ and not l111111l111_l1_: l111111l111_l1_ = len(items)//l1ll11l1ll1l_l1_
	l1lll1ll11ll_l1_,l1l111llll_l1_,l1llll1l1l11_l1_ = [],-1,0
	for item in items:
		if l1llll1l1l11_l1_%l111111l111_l1_==0:
			l1l111llll_l1_ += 1
			l1lll1ll11ll_l1_.append([])
		l1lll1ll11ll_l1_[l1l111llll_l1_].append(item)
		l1llll1l1l11_l1_ += 1
	return l1lll1ll11ll_l1_
def l111llll111_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࡠࠩ㟋") not in filename or l1l111_l1_ (u"ࠫࡒ࠹ࡕࡠࠩ㟌") not in filename: text = str(data)
	else:
		l1lll1ll11ll_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠬ࠭㟍")
		for split in l1lll1ll11ll_l1_:
			text += str(split)+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㟎")
		text = text.strip(l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㟏"))
	l1l1l1l1111_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠨࡹࡥࠫ㟐")).write(l1l1l1l1111_l1_)
	return
def l11ll11l1l1_l1_(l1l1l1ll111_l1_,filename):
	if l1l1l1ll111_l1_==l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㟑"): data = {}
	elif l1l1l1ll111_l1_==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㟒"): data = []
	elif l1l1l1ll111_l1_==l1l111_l1_ (u"ࠫࡸࡺࡲࠨ㟓"): data = l1l111_l1_ (u"ࠬ࠭㟔")
	elif l1l1l1ll111_l1_==l1l111_l1_ (u"࠭ࡩ࡯ࡶࠪ㟕"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l1l1111_l1_ = open(filepath,l1l111_l1_ (u"ࠧࡳࡤࠪ㟖")).read()
	text = zlib.decompress(l1l1l1l1111_l1_)
	if l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㟗") not in text: data = eval(text)
	else:
		l1lll1ll11ll_l1_ = text.split(l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㟘"))
		del text
		data = []
		l11l1l1ll11_l1_ = l11l11l1lll_l1_()
		id = 0
		for split in l1lll1ll11ll_l1_:
			l11l1l1ll11_l1_.l11l111lll1_l1_(str(id),eval,split)
			id += 1
		del l1lll1ll11ll_l1_
		l11l1l1ll11_l1_.l1lll1l11lll_l1_()
		l11l1l1ll11_l1_.l1ll11l1ll11_l1_()
		l1ll1l111ll1_l1_ = list(l11l1l1ll11_l1_.l1111ll1ll1_l1_.keys())
		l1ll1ll11ll1_l1_ = sorted(l1ll1l111ll1_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll1ll11ll1_l1_:
			data += l11l1l1ll11_l1_.l1111ll1ll1_l1_[id]
	return data
def l1ll1lllll11_l1_(addon_id):
	l11l1lllll1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㟙"),addon_id,l1l111_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㟚"))
	try: l1l1111111l_l1_ = open(l11l1lllll1_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㟛")).read()
	except:
		l1llll1l11l1_l1_ = os.path.join(l111ll1l111_l1_,l1l111_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㟜"),addon_id,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ㟝"))
		try: l1l1111111l_l1_ = open(l1llll1l11l1_l1_,l1l111_l1_ (u"ࠨࡴࡥࠫ㟞")).read()
		except: return l1l111_l1_ (u"ࠩࠪ㟟"),[]
	if PY3: l1l1111111l_l1_ = l1l1111111l_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㟠"))
	version = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ㟡"),l1l1111111l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠬ࠭㟢"),[]
	l11lllll1ll_l1_,l11l111ll11_l1_ = version[0],l1ll11l11ll1_l1_(version[0])
	return l11lllll1ll_l1_,l11l111ll11_l1_
def l111lllll1l_l1_():
	l111l1ll1l1_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㟣"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㟤"),l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㟥"))
	if l111l1ll1l1_l1_: return l111l1ll1l1_l1_
	l1ll1l1l11l1_l1_,l111l1ll1l1_l1_ = {},{}
	l1lll1111l11_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㟦")][0]]
	if kodi_version>17.99: l1lll1111l11_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㟧")][1])
	if PY3: l1lll1111l11_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㟨")][2])
	for l1ll1ll1llll_l1_ in l1lll1111l11_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㟩"),l1ll1ll1llll_l1_,l1l111_l1_ (u"࠭ࠧ㟪"),l1l111_l1_ (u"ࠧࠨ㟫"),l1l111_l1_ (u"ࠨࠩ㟬"),l1l111_l1_ (u"ࠩࠪ㟭"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㟮"))
		if response.succeeded:
			html = response.content
			l1ll11ll1lll_l1_ = l1ll1ll1llll_l1_.rsplit(l1l111_l1_ (u"ࠫ࠴࠭㟯"),1)[0]
			l111l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㟰"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111lll1l1l_l1_ in l111l1ll1ll_l1_:
				l11l111ll1l_l1_ = l1ll11ll1lll_l1_+l1l111_l1_ (u"࠭࠯ࠨ㟱")+addon_id+l1l111_l1_ (u"ࠧ࠰ࠩ㟲")+addon_id+l1l111_l1_ (u"ࠨ࠯ࠪ㟳")+l111lll1l1l_l1_+l1l111_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ㟴")
				if addon_id not in list(l1ll1l1l11l1_l1_.keys()):
					l1ll1l1l11l1_l1_[addon_id] = []
					l111l1ll1l1_l1_[addon_id] = []
				l1llll1ll1l1_l1_ = l1ll11l11ll1_l1_(l111lll1l1l_l1_)
				l1ll1l1l11l1_l1_[addon_id].append((l111lll1l1l_l1_,l1llll1ll1l1_l1_,l11l111ll1l_l1_))
	for addon_id in list(l1ll1l1l11l1_l1_.keys()):
		l111l1ll1l1_l1_[addon_id] = sorted(l1ll1l1l11l1_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㟵"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ㟶"),l111l1ll1l1_l1_,l11l1l1_l1_)
	return l111l1ll1l1_l1_
def l1ll11l11ll1_l1_(l111lll1l1l_l1_):
	l1llll1ll1l1_l1_ = []
	l1llll1l11l_l1_ = l111lll1l1l_l1_.split(l1l111_l1_ (u"ࠬ࠴ࠧ㟷"))
	for l1l1ll11l1_l1_ in l1llll1l11l_l1_:
		parts = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪ㟸"),l1l1ll11l1_l1_,re.DOTALL)
		l1ll1l11l111_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1ll1l11l111_l1_.append(part)
		l1llll1ll1l1_l1_.append(l1ll1l11l111_l1_)
	return l1llll1ll1l1_l1_
def l1llll11111l_l1_(l1llll1ll1l1_l1_):
	l111lll1l1l_l1_ = l1l111_l1_ (u"ࠧࠨ㟹")
	for l1l1ll11l1_l1_ in l1llll1ll1l1_l1_:
		for part in l1l1ll11l1_l1_: l111lll1l1l_l1_ += str(part)
		l111lll1l1l_l1_ += l1l111_l1_ (u"ࠨ࠰ࠪ㟺")
	l111lll1l1l_l1_ = l111lll1l1l_l1_.strip(l1l111_l1_ (u"ࠩ࠱ࠫ㟻"))
	return l111lll1l1l_l1_
def l11111l1l1l_l1_(l11ll11l111_l1_):
	l1ll11lll111_l1_ = {}
	l1ll1l1l11l1_l1_ = l111lllll1l_l1_()
	l11ll1lllll_l1_ = l1lll1l11ll1_l1_(l11ll11l111_l1_)
	for addon_id in l11ll11l111_l1_:
		if addon_id not in list(l1ll1l1l11l1_l1_.keys()): continue
		l111l1ll1l1_l1_ = l1ll1l1l11l1_l1_[addon_id]
		l11ll1ll111_l1_,l11ll1l1ll1_l1_,l1ll111lll11_l1_ = l111l1ll1l1_l1_[0]
		l1llllll111l_l1_,l11l111l1l1_l1_ = l1ll1lllll11_l1_(addon_id)
		l11l1lll1ll_l1_,l1111111l1l_l1_ = l11ll1lllll_l1_[addon_id]
		l11lll1l1l1_l1_ = l11ll1l1ll1_l1_>l11l111l1l1_l1_ and l11l1lll1ll_l1_
		l1ll111llll1_l1_ = True
		if not l11l1lll1ll_l1_: l11llllll11_l1_ = l1l111_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ㟼")
		elif not l1111111l1l_l1_: l11llllll11_l1_ = l1l111_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭㟽")
		elif l11lll1l1l1_l1_: l11llllll11_l1_ = l1l111_l1_ (u"ࠬࡵ࡬ࡥࠩ㟾")
		else:
			l11llllll11_l1_ = l1l111_l1_ (u"࠭ࡧࡰࡱࡧࠫ㟿")
			l1ll111llll1_l1_ = False
		l1ll11lll111_l1_[addon_id] = (l1ll111llll1_l1_,l1llllll111l_l1_,l11l111l1l1_l1_,l11ll1ll111_l1_,l11ll1l1ll1_l1_,l11llllll11_l1_,l1ll111lll11_l1_)
	return l1ll11lll111_l1_
def l1l1111l11_l1_(l1l1111lll_l1_,l1111llll1l_l1_,l11l11l1ll1_l1_=l1l111_l1_ (u"ࠧࠨ㠀"),line2=l1l111_l1_ (u"ࠨࠩ㠁"),l11l11ll111_l1_=l1l111_l1_ (u"ࠩࠪ㠂")):
	if PY2: l1l1111lll_l1_.update(l1111llll1l_l1_,l11l11l1ll1_l1_,line2,l11l11ll111_l1_)
	else: l1l1111lll_l1_.update(l1111llll1l_l1_,l11l11l1ll1_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㠃")+line2+l1l111_l1_ (u"ࠫࡡࡴࠧ㠄")+l11l11ll111_l1_)
	return
def l1lll1l1l1l1_l1_(l11111llll1_l1_):
	def l111111l1ll_l1_(num,b,l1lll11l1l1l_l1_=l1l111_l1_ (u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧ㠅")):
		return ((num == 0) and l1lll11l1l1l_l1_[0]) or (l111111l1ll_l1_(num // b, b, l1lll11l1l1l_l1_).lstrip(l1lll11l1l1l_l1_[0]) + l1lll11l1l1l_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None, r=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠨ࡜࡝ࡤࠥ㠆") + l111111l1ll_l1_(c, a) + l1l111_l1_ (u"ࠢ࡝࡞ࡥࠦ㠇"),  k[c], p)
		return p
	l11111llll1_l1_ = l11111llll1_l1_.split(l1l111_l1_ (u"ࠨࡿࠫࠫ㠈"))[1]
	l11111llll1_l1_ = l11111llll1_l1_.rsplit(l1l111_l1_ (u"ࠩࡶࡴࡱ࡯ࡴࠨ㠉"))[0]+l1l111_l1_ (u"ࠥࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠩࠣ㠊")
	l1lll111ll11_l1_ = eval(l1l111_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬ㠋")+l11111llll1_l1_,{l1l111_l1_ (u"ࠬࡨࡡࡴࡧࡑࠫ㠌"):l111111l1ll_l1_,l1l111_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭㠍"):unpack})
	return l1lll111ll11_l1_
def l111llll1l1_l1_(url,l1lll1ll1l11_l1_=l1l111_l1_ (u"ࠧࠨ㠎")):
	if l1lll1ll1l11_l1_==l1l111_l1_ (u"ࠨ࡮ࡲࡻࡪࡸࠧ㠏"): url = re.sub(l1l111_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩ㠐"),lambda l11llll111l_l1_: l11llll111l_l1_.group(0).lower(),url)
	elif l1lll1ll1l11_l1_==l1l111_l1_ (u"ࠪࡹࡵࡶࡥࡳࠩ㠑"): url = re.sub(l1l111_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫ㠒"),lambda l11llll111l_l1_: l11llll111l_l1_.group(0).upper(),url)
	return url
def l1lll1l11ll1_l1_(l11ll11l111_l1_):
	l1llllllll11_l1_,l1111ll111l_l1_ = False,False
	conn = sqlite3.connect(l111ll11l11_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	if len(l11ll11l111_l1_)==1: l11l111111l_l1_ = l1l111_l1_ (u"ࠬ࠮ࠢࠨ㠓")+l11ll11l111_l1_[0]+l1l111_l1_ (u"࠭ࠢࠪࠩ㠔")
	else: l11l111111l_l1_ = str(tuple(l11ll11l111_l1_))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧ㠕")+l11l111111l_l1_+l1l111_l1_ (u"ࠨࠢ࠾ࠫ㠖"))
	l1l11llll11_l1_ = l1llll1lll_l1_.fetchall()
	l11ll1lllll_l1_ = {}
	for addon_id in l11ll11l111_l1_: l11ll1lllll_l1_[addon_id] = (False,False)
	for addon_id,l1111ll111l_l1_ in l1l11llll11_l1_:
		l1llllllll11_l1_ = True
		l1111ll111l_l1_ = l1111ll111l_l1_==1
		l11ll1lllll_l1_[addon_id] = (l1llllllll11_l1_,l1111ll111l_l1_)
	conn.close()
	return l11ll1lllll_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"ࠩࠪ㠗")
	if file==l1ll11l11lll_l1_: status = l1ll1l1l11ll_l1_(True,False)
	if os.path.exists(file):
		l1l11ll1111_l1_ = open(file,l1l111_l1_ (u"ࠪࡶࡧ࠭㠘")).read()
		if PY3: l1l11ll1111_l1_ = l1l11ll1111_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㠙"))
		if file==l1ll11l11lll_l1_: l1lll_l1_ = l1l11ll1111_l1_
		else:
			l111l1l1111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㠚"),l1l11ll1111_l1_)
			if l111l1l1111_l1_:
				l1lll_l1_ = {}
				for key in l111l1l1111_l1_.keys():
					l1lll_l1_[key] = []
					for l11111l1ll1_l1_ in l111l1l1111_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1l111_l1_ (u"࠭ࠧ㠛"),l1l111_l1_ (u"ࠧࠨ㠜"),l1l111_l1_ (u"ࠨࠩ㠝"),l1l111_l1_ (u"ࠩࠪ㠞"),l1l111_l1_ (u"ࠪࠫ㠟"),l1l111_l1_ (u"ࠫࠬ㠠"),l1l111_l1_ (u"ࠬ࠭㠡"),l1l111_l1_ (u"࠭ࠧ㠢"),l1l111_l1_ (u"ࠧࠨ㠣")
						type = l11111l1ll1_l1_[0]
						name = l11111l1ll1_l1_[1]
						name = l11lll1111l_l1_(name)
						url = l11111l1ll1_l1_[2]
						mode = l11111l1ll1_l1_[3]
						l11l_l1_ = l11111l1ll1_l1_[4]
						l1llllll1_l1_ = l11111l1ll1_l1_[5]
						if len(l11111l1ll1_l1_)>6: text = l11111l1ll1_l1_[6]
						if len(l11111l1ll1_l1_)>7: context = l11111l1ll1_l1_[7]
						if len(l11111l1ll1_l1_)>8: l1llllll1ll_l1_ = l11111l1ll1_l1_[8]
						if file==favoritesfile: l1ll1l11111l_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠨࠩ㠤"),l1llllll1ll_l1_
						else: l1ll1l11111l_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
						l1lll_l1_[key].append(l1ll1l11111l_l1_)
			l1l11l111l1_l1_ = str(l1lll_l1_)
			if PY3: l1l11l111l1_l1_ = l1l11l111l1_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㠥"))
			open(file,l1l111_l1_ (u"ࠪࡻࡧ࠭㠦")).write(l1l11l111l1_l1_)
	return l1lll_l1_
def l1ll1lllll1_l1_(l1lll11ll11_l1_):
	l1llll11llll_l1_ = l1lll11ll11_l1_.split(l1l111_l1_ (u"ࠫ࠲࠭㠧"),1)[0]
	l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_ = l1l111_l1_ (u"ࠬ࠭㠨"),l1l111_l1_ (u"࠭ࠧ㠩"),l1l111_l1_ (u"ࠧࠨ㠪")
	if   l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ㠫")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㠬")		:	from l11l111_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㠭")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㠮")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㠯")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㠰")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㠱")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ㠲")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㠳"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㠴")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ㠵")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㠶")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧ㠷")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㠸")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ㠹")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨ㠺"):	from l11111ll1_l1_	import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ㠻"):		from l1111ll11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㠼")	:	from l11111l1l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ㠽")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ㠾")	:	from l11111111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ㠿")	:	from l1lllllll1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㡀"):	from l1l1l111l1_l1_	import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㡁")	:	from l11ll1l111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㡂")	:	from l11l11ll11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭㡃")	:	from l111llll1l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㡄")	:	from l111ll1l1l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ㡅")	:	from l111ll11ll_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ㡆")	:	from l111l1lll1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ㡇")	:	from l111l11l11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ㡈")	:	from l111l111ll_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㡉")	:	from l1lllll1l11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㡊")	:	from l1lllll1111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㡋")	:	from l1llll1ll11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㡌")	:	from l1llll11lll_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭㡍")		:	from l1llll11l1l_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㡎")	:	from l1ll1lll11l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㡏")		:	from l1ll1lll111_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㡐")		:	from IPTV			import MENUu as l1lll1111ll_l1_,SEARCHh as l1lll11l1ll_l1_,menu_namee as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㡑")	:	from l1ll1l11111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㡒")	:	from l1ll11lllll_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㡓")	:	from l1ll11lll11_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㡔")	:	from l1ll111ll1l_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㡕")	:	from l11lllll11l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㡖")		:	from M3U			import MENUu as l1lll1111ll_l1_,SEARCHh as l1lll11l1ll_l1_,menu_namee as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ㡗")	:	from l11l1l11l11_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ㡘")	:	from l1llll11ll11_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㡙")		:	from l11l11ll1ll_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㡚")	:	from l1ll1llll111_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ㡛"):	from l11ll1l11l1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ㡜")	:	from l11l1l1111l_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㡝")	:	from l111l11l111_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㡞")	:	from l11lll1l1ll_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭㡟")	:	from l1ll1l1llll1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㡠")		:	from l1111l1ll11_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭㡡")	:	from l1ll1llllll1_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㡢")		:	from l11lll111l1_l1_			import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㡣")	:	from l11ll1llll1_l1_		import l1l1l11_l1_ as l1lll1111ll_l1_,l1lll1_l1_ as l1lll11l1ll_l1_,l1lllll_l1_ as l1llll111ll_l1_
	elif l1llll11llll_l1_==l1l111_l1_ (u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ㡤"):	from l11ll111ll1_l1_	import l1l1l11_l1_ as l1lll1111ll_l1_
	return l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_
def l1llllll1111_l1_(l1ll111lll1l_l1_,headers,l11_l1_):
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㡥"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩ㡦")+l1ll111lll1l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ㡧")+str(headers)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㡨"))
	l1l1111lll_l1_ = l1l111lll1_l1_()
	l1l1111lll_l1_.create(l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㡩"),l1l111_l1_ (u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ㡪"))
	l1l11l11l1_l1_ = 1024*1024
	chunksize = 1*l1l11l11l1_l1_
	response = requests.get(l1ll111lll1l_l1_,stream=True,headers=headers)
	l1ll1l1lll1l_l1_ = response.headers
	response.close()
	l1ll1l1ll111_l1_ = bytes()
	if not l1ll1l1lll1l_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㡫"),l1l111_l1_ (u"ࠪࠫ㡬"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㡭"),l1l111_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨ㡮"))
		l1l1111lll_l1_.close()
	else:
		if l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ㡯") not in list(l1ll1l1lll1l_l1_.keys()): filesize = 0
		else: filesize = int(l1ll1l1lll1l_l1_[l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ㡰")])
		l1l111ll1l_l1_ = str(int(1000*filesize/l1l11l11l1_l1_)/1000.0)
		l11llll11l_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨ㡱") in list(l1ll1l1lll1l_l1_.keys()) and filesize>l1l11l11l1_l1_:
			l1ll1lll1111_l1_ = True
			ranges = []
			l1ll11llllll_l1_ = 10
			ranges.append(str(0*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡲")+str(1*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(1*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㡳")+str(2*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(2*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㡴")+str(3*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(3*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㡵")+str(4*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(4*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㡶")+str(5*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(5*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㡷")+str(6*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(6*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㡸")+str(7*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(7*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㡹")+str(8*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(8*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㡺")+str(9*filesize//l1ll11llllll_l1_-1))
			ranges.append(str(9*filesize//l1ll11llllll_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㡻"))
			l11ll1l1111_l1_ = float(l11llll11l_l1_)/l1ll11llllll_l1_
			l1111l11l11_l1_ = l11ll1l1111_l1_/int(1+l11ll1l1111_l1_)
		else:
			l1ll1lll1111_l1_ = False
			l1ll11llllll_l1_ = 1
			l1111l11l11_l1_ = 1
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㡼"),l1l111_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧ㡽")+str(l1ll1lll1111_l1_)+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ㡾")+str(filesize)+l1l111_l1_ (u"ࠨࠢࡠࠫ㡿"))
		l1l111llll_l1_,l1ll1llll11l_l1_ = 0,0
		for l1llll1l1l11_l1_ in range(l1ll11llllll_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll1lll1111_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠩࡕࡥࡳ࡭ࡥࠨ㢀")] = l1l111_l1_ (u"ࠪࡦࡾࡺࡥࡴ࠿ࠪ㢁")+ranges[l1llll1l1l11_l1_]
			response = requests.get(l1ll111lll1l_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l1l1111lll_l1_.iscanceled():
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㢂"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬ㢃"))
					break
				l1l111llll_l1_ += l1111l11l11_l1_
				l1ll1l1ll111_l1_ += chunk
				if not l1ll1llll11l_l1_: l1ll1llll11l_l1_ = len(chunk)
				if filesize: l1l1111l11_l1_(l1l1111lll_l1_,100*l1l111llll_l1_//l11llll11l_l1_,l1l111_l1_ (u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧ㢄"),str(100.0*l1ll1llll11l_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠧࠡ࠱ࠣࠫ㢅")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠨࠢࡐࡆࠬ㢆"))
				else: l1l1111l11_l1_(l1l1111lll_l1_,l1ll1llll11l_l1_*l1l111llll_l1_//chunksize,l1l111_l1_ (u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧ㢇"),str(100.0*l1ll1llll11l_l1_*l1l111llll_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠪࠤࡒࡈࠧ㢈"))
			response.close()
		l1l1111lll_l1_.close()
		if len(l1ll1l1ll111_l1_)<filesize and filesize>0:
			l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㢉"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨ㢊")+str(len(l1ll1l1ll111_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫ㢋")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㢌"))
			l11l1111l1l_l1_ = l1ll11ll11l1_l1_(l1l111_l1_ (u"ࠨࠩ㢍"),l1l111_l1_ (u"ࠩศ่฿อม๊ࠡัีําࠧ㢎"),l1l111_l1_ (u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪ㢏"),l1l111_l1_ (u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭㢐"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㢑"),l1l111_l1_ (u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪ㢒")+str(len(l1ll1l1ll111_l1_)//l1l11l11l1_l1_)+l1l111_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭㢓")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪ㢔"))
			if l11l1111l1l_l1_==2: l1ll1l1ll111_l1_ = l1llllll1111_l1_(l1ll111lll1l_l1_,headers,l11_l1_)
			elif l11l1111l1l_l1_==1: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㢕"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩ㢖"))
			else: return l1l111_l1_ (u"ࠫࠬ㢗")
			if not l1ll1l1ll111_l1_: return l1l111_l1_ (u"ࠬ࠭㢘")
		else: l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㢙"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫ㢚")+l1l111ll1l_l1_+l1l111_l1_ (u"ࠨࠢࡐࡆࠥࡣࠧ㢛"))
	return l1ll1l1ll111_l1_
def l1111l1l111_l1_(l1ll1_l1_):
	return response
def l1111lll11l_l1_(l1lll1l11l11_l1_=l1l111_l1_ (u"ࠩࠪ㢜")):
	l1ll1lllllll_l1_,l1llll1l111l_l1_,l11llllll1l_l1_,l1llll1l1111_l1_,l111l111l11_l1_,timezone = l1l111_l1_ (u"ࠪࠫ㢝"),l1l111_l1_ (u"ࠫࠬ㢞"),l1l111_l1_ (u"ࠬ࠭㢟"),l1l111_l1_ (u"࠭ࠧ㢠"),l1l111_l1_ (u"ࠧࠨ㢡"),l1l111_l1_ (u"ࠨࠩ㢢")
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬ㢣")+l1lll1l11l11_l1_+l1l111_l1_ (u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㢤")
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㢥"):l1l111_l1_ (u"ࠬ࠭㢦")}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㢧"),url,l1l111_l1_ (u"ࠧࠨ㢨"),headers,l1l111_l1_ (u"ࠨࠩ㢩"),l1l111_l1_ (u"ࠩࠪ㢪"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭㢫"))
	if not response.succeeded: l1ll1l111lll_l1_ = l1lll1l11l11_l1_+l1l111_l1_ (u"ࠫ࠱࠭㢬")+l1ll1lllllll_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㢭")+l1llll1l111l_l1_+l1l111_l1_ (u"࠭ࠬࠨ㢮")+l1llll1l1111_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㢯")+l111l111l11_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㢰")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠩ࡟ࡿ࠳࠰࠿࡝ࡿ࡟ࢁࠬ㢱"),html,re.DOTALL)
		if html:
			html = html[0]
			l11l11l11l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㢲"),html)
			keys = list(l11l11l11l1_l1_.keys())
			if l1l111_l1_ (u"ࠫ࡮ࡶࠧ㢳") in keys: l1lll1l11l11_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"ࠬ࡯ࡰࠨ㢴")]
			if l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩ㢵") in keys: l1ll1lllllll_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ㢶")]
			if l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㢷") in keys: l1llll1l111l_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㢸")]
			if l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩ㢹") in keys: l11llllll1l_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ㢺")]
			if l1l111_l1_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ㢻") in keys: l1llll1l1111_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭㢼")]
			if l1l111_l1_ (u"ࠧࡤ࡫ࡷࡽࠬ㢽") in keys: l111l111l11_l1_ = l11l11l11l1_l1_[l1l111_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭㢾")]
			if l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㢿") in keys:
				timezone = l11l11l11l1_l1_[l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㣀")][l1l111_l1_ (u"ࠫࡺࡺࡣࠨ㣁")]
				if timezone[0] not in [l1l111_l1_ (u"ࠬ࠳ࠧ㣂"),l1l111_l1_ (u"࠭ࠫࠨ㣃")]: timezone = l1l111_l1_ (u"ࠧࠬࠩ㣄")+timezone
			l1ll1l111lll_l1_ = l1lll1l11l11_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㣅")+l1ll1lllllll_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㣆")+l1llll1l111l_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㣇")+l1llll1l1111_l1_+l1l111_l1_ (u"ࠫ࠱࠭㣈")+l111l111l11_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㣉")+timezone
			if PY3: l1ll1l111lll_l1_ = l1ll1l111lll_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㣊")).decode(l1l111_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㣋"))
	l1ll1l111lll_l1_ = escapeUNICODE(l1ll1l111lll_l1_)
	return l1ll1l111lll_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"ࠨࠩ㣌"),True
	if search.count(l1l111_l1_ (u"ࠩࡢࠫ㣍"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠪࡣࠬ㣎"),1)
		options = l1l111_l1_ (u"ࠫࡤ࠭㣏")+options
		if l1l111_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ㣐") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1ll1l11l11l_l1_():
	l1ll1lll1ll1_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㣑"))
	l111111ll11_l1_ = 0
	if os.path.exists(l1ll1lll1ll1_l1_):
		for filename in os.listdir(l1ll1lll1ll1_l1_):
			if l1l111_l1_ (u"ࠧ࠯ࡲࡼࡳࠬ㣒") in filename: continue
			if l1l111_l1_ (u"ࠨࡡࡢࡴࡾࡩࡡࡤࡪࡨࡣࡤ࠭㣓") in filename: continue
			l1ll111111_l1_ = os.path.join(l1ll1lll1ll1_l1_,filename)
			size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
			l111111ll11_l1_ += size
	return l111111ll11_l1_
def l1ll1l1l11ll_l1_(l111lll111l_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㣔")][3]
	l1ll11l11l11_l1_ = l1l11l1l1ll_l1_(32,l111lll111l_l1_)
	l1ll1l111lll_l1_ = l1111lll11l_l1_()
	l1llll1l111l_l1_ = l1ll1l111lll_l1_.split(l1l111_l1_ (u"ࠪ࠰ࠬ㣕"))[2]
	l111111ll11_l1_ = l1ll1l11l11l_l1_()
	payload = {l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㣖"):l1ll11l11l11_l1_,l1l111_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭㣗"):l1l11l1111l_l1_,l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㣘"):l1llll1l111l_l1_,l1l111_l1_ (u"ࠧࡪࡦࡶࠫ㣙"):l1lll1ll111l_l1_(l111111ll11_l1_)}
	if not l111lll111l_l1_: l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫ㣚"),(l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㣛"),url,payload,l1l111_l1_ (u"ࠪࠫ㣜"),l1l111_l1_ (u"ࠫࠬ㣝")))
	l1111ll11l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹࠧ㣞"))
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳࠨ㣟"),l1l111_l1_ (u"ࠧࠨ㣠"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㣡"),url,payload,l1l111_l1_ (u"ࠩࠪ㣢"),l1l111_l1_ (u"ࠪࠫ㣣"),l1l111_l1_ (u"ࠫࠬ㣤"),l1l111_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ㣥"))
	l11lll1l111_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ㣦"))
	if not l11lll1l111_l1_: l11lll1l111_l1_ = l1l111_l1_ (u"ࠧࡏࡇ࡚ࠫ㣧")
	l1llll111l1l_l1_ = l11lll1l111_l1_
	l11ll1ll1ll_l1_ = l1l111_l1_ (u"ࠨࠩ㣨")
	if not response.succeeded: l1llll111l1l_l1_ = l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㣩")
	else:
		l111l11ll11_l1_,l111l1l1ll1_l1_,l111l11ll1l_l1_ = l1l111_l1_ (u"ࠪࠫ㣪"),l1l111_l1_ (u"ࠫࠬ㣫"),[]
		newfile = response.content
		if newfile:
			l111l11ll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ㣬"),newfile)
			for l1lllllllll1_l1_,l1lll1111l1l_l1_,message in l111l11ll1l_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㣭")).decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㣮"))
				if l1lllllllll1_l1_==l1l111_l1_ (u"ࠨ࠲ࠪ㣯"): l11ll1ll1ll_l1_ += message+l1l111_l1_ (u"ࠩ࠽࠾ࠬ㣰")
				else: l111l11ll11_l1_ += message+l1l111_l1_ (u"ࠪࡠࡳ࠭㣱")
			l111l11ll11_l1_ = l111l11ll11_l1_.strip(l1l111_l1_ (u"ࠫࡡࡴࠧ㣲"))
			l11ll1ll1ll_l1_ = l11ll1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࡀ࠺ࠨ㣳"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳࠨ㣴"),l11ll1ll1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㣵"),l1lll1ll111l_l1_(now))
		if os.path.exists(l1ll11l11lll_l1_): l111l1l1ll1_l1_ = open(l1ll11l11lll_l1_,l1l111_l1_ (u"ࠨࡴࡥࠫ㣶")).read()
		if PY3: l111l11ll11_l1_ = l111l11ll11_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㣷"))
		if l111l11ll11_l1_!=l111l1l1ll1_l1_:
			l1llll111l1l_l1_ = l1l111_l1_ (u"ࠪࡒࡊ࡝ࠧ㣸")
			try: open(l1ll11l11lll_l1_,l1l111_l1_ (u"ࠫࡼࡨࠧ㣹")).write(l111l11ll11_l1_)
			except: pass
		if l11_l1_:
			l111l11ll1l_l1_ = sorted(l111l11ll1l_l1_,reverse=True,key=lambda key: int(key[0]))
			l111l1l1l1l_l1_ = l1l111_l1_ (u"ࠬ࠭㣺")
			for l1lllllllll1_l1_,l1lll1111l1l_l1_,message in l111l11ll1l_l1_:
				if PY3: message = message.encode(l1l111_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㣻")).decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㣼"))
				if l111l1l1l1l_l1_: l111l1l1l1l_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ㣽")
				if l1lllllllll1_l1_==l1l111_l1_ (u"ࠩ࠳ࠫ㣾"): continue
				date = message.split(l1l111_l1_ (u"ࠪࡠࡳ࠭㣿"))[0]
				l11l1llll1l_l1_ = l1l111_l1_ (u"ࠫࠬ㤀")
				if l1lll1111l1l_l1_:
					l11l1llll1l_l1_ = l1l111_l1_ (u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩ㤁")
					if PY3: l11l1llll1l_l1_ = l11l1llll1l_l1_.encode(l1l111_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㤂")).decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㤃"))
				l111l1l1l1l_l1_ += message.replace(date,l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㤄")+date+l11l1llll1l_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㤅"))+l1l111_l1_ (u"ࠪࡠࡳ࠭㤆")
			l111l1l1l1l_l1_ = escapeUNICODE(l111l1l1l1l_l1_)
			l1l11l1l1l_l1_(l1l111_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㤇"),l1l111_l1_ (u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨ㤈"),l111l1l1l1l_l1_,l1l111_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ㤉"))
			l1llll111l1l_l1_ = l1l111_l1_ (u"ࠧࡐࡎࡇࠫ㤊")
		if l1llll111l1l_l1_!=l11lll1l111_l1_:
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭㤋"),l1llll111l1l_l1_)
	if l11_l1_: xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㤌"))
	if l1111ll11l1_l1_!=l11ll1ll1ll_l1_:
		if not l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪะึฮࠠๆำฬࠤศิั๊ࠩ㤍"),l1l111_l1_ (u"࡙ࠫࡸࡹࠡࡣࡪࡥ࡮ࡴࠧ㤎"),time=2000)
		l1111l1l1ll_l1_(l1l111_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡸࡴࠦࡡࡱࡲ࡯ࡽࠥࡴࡥࡸࠢࡳࡶ࡮ࡼࡩ࡭ࡧࡪࡩࡸ࠭㤏"))
	return l1llll111l1l_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll1ll1ll11_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll1ll1ll11_l1_ = False
	l11lll1111_l1_ = time.time()
	if l1ll1ll1ll11_l1_: resp = l11lll1111_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࠧ㤐"),l1l111_l1_ (u"ࠧࠨ㤑"),l1l111_l1_ (u"ࠨࠩ㤒"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㤓"),l1l111_l1_ (u"ࠪืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡ฻่่๏ฯࠠศๆอ๊฽๐แࠡษ็ฦ๋ࠦฟࠢࠩ㤔"))
	else: l1llll111l_l1_ = True
	if l1llll111l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠫ࠳ࡪࡢࠨ㤕")) and l1l111_l1_ (u"ࠬࡪࡡࡵࡣࠪ㤖") in filename:
				l1ll1lll1l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1llll1lll_l1_ = l1l1llll11l_l1_(l1ll1lll1l_l1_)
				except: return
				l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩ࡯ࡶࡨ࡫ࡷ࡯ࡴࡺࡡࡦ࡬ࡪࡩ࡫࠼ࠩ㤗"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡰࡲࡷ࡭ࡲ࡯ࡺࡦ࠽ࠪ㤘"))
				l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩ㤙"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㤚"),l1l111_l1_ (u"ࠪࠫ㤛"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㤜"),l1l111_l1_ (u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭㤝"))
	return
def l1lll1l1ll1_l1_(l11l1ll1l11_l1_,proxy):
	global l1ll1l1l1ll1_l1_,l1ll11ll1l1l_l1_
	l1ll1l1l1ll1_l1_,l1ll11ll1l1l_l1_ = l11l1ll1l11_l1_,proxy
	return
l1ll1l1l1ll1_l1_,l1ll11ll1l1l_l1_ = None,None
def l11l11lllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll11_l1_=None,l1lll1ll1l1l_l1_=None):
	if l11_l1_==l1l111_l1_ (u"࠭ࠧ㤞"): l11_l1_ = True
	if l1lll1ll1l1l_l1_==None: l1lll1ll1l1l_l1_ = True if l1ll11ll1l1l_l1_==None else l1ll11ll1l1l_l1_
	if l11ll11ll11_l1_==None: l11ll11ll11_l1_ = True if l1ll1l1l1ll1_l1_==None else l1ll1l1l1ll1_l1_
	if allow_redirects==l1l111_l1_ (u"ࠧࠨ㤟"): l1ll1lll11ll_l1_ = True
	else: l1ll1lll11ll_l1_ = allow_redirects
	if data==None: l1l11llll_l1_ = None
	elif data==l1l111_l1_ (u"ࠨࠩ㤠"): l1l11llll_l1_ = {}
	else: l1l11llll_l1_ = data
	if headers==None: l1ll1ll1l_l1_ = None
	elif headers==l1l111_l1_ (u"ࠩࠪ㤡"): l1ll1ll1l_l1_ = {}
	else: l1ll1ll1l_l1_ = headers
	l1llll11ll1l_l1_ = list(l1ll1ll1l_l1_.keys())
	if l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㤢") not in l1llll11ll1l_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㤣")] = l1l111_l1_ (u"ࠬࡆࡀࡁࡕࡎࡍࡕࡥࡈࡆࡃࡇࡉࡗࡆࡀࡁࠩ㤤")
	l1lllll1_l1_,l1ll1ll11l1l_l1_,l1lll1lll111_l1_,l1llll1111l1_l1_ = l1ll1l1l111l_l1_(url)
	l1ll11lll1l1_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭㤥"))
	l1ll1l1lll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ㤦"))
	l1ll1ll1ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭㤧"))
	l1ll1lll1l1l_l1_ = (l1ll1ll11l1l_l1_==None and l1lll1lll111_l1_==None)
	l111lll11l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㤨")]
	l1ll1l1ll1ll_l1_ = l1lllll1_l1_ in l111lll11l1_l1_
	l111llll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㤩")]
	l11ll1l111l_l1_ = l1lllll1_l1_ in l111llll1ll_l1_
	l111lllllll_l1_ = l1ll1l1ll1ll_l1_ or l11ll1l111l_l1_
	if l1ll1lll1l1l_l1_ and l111lllllll_l1_:
		if l1ll1l1ll1ll_l1_:
			l11111l111l_l1_ = l111lll11l1_l1_.index(l1lllll1_l1_)
			l111l111lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㤪")][l11111l111l_l1_]
			l111ll111l1_l1_ = l111l11lll1_l1_[l11111l111l_l1_]
		elif l11ll1l111l_l1_:
			l11111l111l_l1_ = l111llll1ll_l1_.index(l1lllll1_l1_)
			l111l111lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨ㤫")][l11111l111l_l1_]
			l111ll111l1_l1_ = l11l11lll1l_l1_[l11111l111l_l1_]
	if l1lll1lll111_l1_==l1l111_l1_ (u"࠭ࠧ㤬"): l1lll1lll111_l1_ = l1ll11lll1l1_l1_
	elif l1lll1lll111_l1_==None and l1ll1l1lll11_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㤭"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㤮")] and l11ll11ll11_l1_: l1lll1lll111_l1_ = l1ll11lll1l1_l1_
	l1lll1ll1ll1_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㤯")][7]
	l1ll1llll1l1_l1_ = l1ll1ll11l1l_l1_ and l1l111_l1_ (u"ࠪࡷࡨࡸࡡࡱࡧࠪ㤰") in l1ll1ll11l1l_l1_
	if l1ll1llll1l1_l1_: l1l11111lll_l1_ = 60
	elif l1ll1l1ll1ll_l1_ or l11ll1l111l_l1_: l1l11111lll_l1_ = 15
	elif source in l111111lll1_l1_: l1l11111lll_l1_ = 10
	elif source==l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ㤱"): l1l11111lll_l1_ = 120
	elif source==l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡆࡘࡈࡖࡘࡕ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㤲"): l1l11111lll_l1_ = 20
	elif source==l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧ㤳"): l1l11111lll_l1_ = 20
	elif l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎࠩ㤴") in source: l1l11111lll_l1_ = 70
	elif l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㤵") in source: l1l11111lll_l1_ = 75
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㤶") in source: l1l11111lll_l1_ = 25
	elif l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㤷") in source: l1l11111lll_l1_ = 20
	elif l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ㤸") in source: l1l11111lll_l1_ = 20
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ㤹") in source: l1l11111lll_l1_ = 30
	elif l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㤺") in source: l1l11111lll_l1_ = 25
	elif l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㤻") in source: l1l11111lll_l1_ = 30
	elif l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㤼") in source: l1l11111lll_l1_ = 20
	elif l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㤽") in source: l1l11111lll_l1_ = 60
	else: l1l11111lll_l1_ = 15
	if l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㤾") in source and not l1l11llll_l1_ and l1l111_l1_ (u"ࠫࠫ࠭㤿") not in l1lllll1_l1_ and l1l111_l1_ (u"ࠬࡅࠧ㥀") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨ㥁"))+l1l111_l1_ (u"ࠧ࠰ࠩ㥂")
	l11ll1l1l1l_l1_ = (l1ll1ll11l1l_l1_!=None)
	l1lll1ll1111_l1_ = (l1lll1lll111_l1_!=None and l1ll1l1lll11_l1_!=l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㥃"))
	if l11ll1l1l1l_l1_ and not l1ll1llll1l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡสิ์ู่๊ࠡำๅ้ࠬ㥄"),l1ll1ll11l1l_l1_)
	elif l1lll1ll1111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢࡇࡒࡘࠦัใ็ࠪ㥅"),l1lll1lll111_l1_)
	if l11ll1l1l1l_l1_:
		proxies = {l1l111_l1_ (u"ࠦ࡭ࡺࡴࡱࠤ㥆"):l1ll1ll11l1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡴࡵࡲࡶࠦ㥇"):l1ll1ll11l1l_l1_}
		l11111ll1l1_l1_ = l1ll1ll11l1l_l1_
	else: proxies,l11111ll1l1_l1_ = {},l1l111_l1_ (u"࠭ࠧ㥈")
	if l1lll1ll1111_l1_:
		import urllib3.util.connection as connection
		l11l11l111l_l1_ = l1ll1l11l1l1_l1_(connection,l1ll11lll1l1_l1_)
	l1ll1lll1l11_l1_,l1lll111llll_l1_,l1l11lll1_l1_,l11lll11l11_l1_,l11ll1l11ll_l1_,verify = l1ll1lll11ll_l1_,source,method,False,False,l1llll1111l1_l1_
	if l1lll1ll1ll1_l1_: l11ll1l11ll_l1_ = True
	if l111lllllll_l1_ or l1ll1lll11ll_l1_: l1ll1lll1l11_l1_ = False
	if l1ll1l1ll1ll_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㥉")
	code,reason = -1,l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ㥊")
	for l1l111llll_l1_ in range(9):
		l1llllllll1l_l1_ = True
		succeeded = False
		try:
			if l1l111llll_l1_: l1lll111llll_l1_ = l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠱ࡴࡶࠪ㥋")
			if l1ll1llll1l1_l1_ or not l11ll1l1l1l_l1_: l1l1l1ll11l_l1_(l1l111_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡏࡑࡇࡑࡣ࡚ࡘࡌࠨ㥌"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1lll111llll_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=l1l11llll_l1_,headers=l1ll1ll1l_l1_,verify=verify,allow_redirects=l1ll1lll1l11_l1_,timeout=l1l11111lll_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11lll11l11_l1_:
					l11111lll1l_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㥍") in l11111lll1l_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㥎")]
					elif l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㥏") in l11111lll1l_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㥐")]
					else: l11lll11l11_l1_ = True
					if not l11lll11l11_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠨ࡮ࡤࡸ࡮ࡴ࠭࠲ࠩ㥑"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ㥒")).decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㥓"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㥔"))
					if l111lllllll_l1_ and response.status_code==307:
						l1ll1lll1l11_l1_ = l1ll1lll11ll_l1_
						l1l11lll1_l1_ = method
						l11lll11l11_l1_ = True
						l1llll11l1l1_l1_
				if not l11lll11l11_l1_ or l1ll1lll11ll_l1_:
					if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㥕") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㥖"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠧ࠰ࠩ㥗")+l1lllll1_l1_.lstrip(l1l111_l1_ (u"ࠨ࠱ࠪ㥘"))
				if not l11lll11l11_l1_ and l1ll1lll11ll_l1_:
					l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1lllll1_l1_)
					if l11ll1l1l1_l1_ not in [l1l111_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㥙"),l1l111_l1_ (u"ࠪ࠲ࡹࡹࠧ㥚"),l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㥛"),l1l111_l1_ (u"ࠬ࠴ࡡࡢࡥࠪ㥜"),l1l111_l1_ (u"࠭࠮࡮࡭ࡹࠫ㥝"),l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ㥞"),l1l111_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ㥟")]: l1llll11l1l1_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll1l11ll_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if PY2: reason = str(err.message).split(l1l111_l1_ (u"ࠩ࠽ࠤࠬ㥠"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠪ࠾ࠥ࠭㥡"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠫࡊࡸࡲ࡯ࡱࠪ㥢") in error: code,reason = re.findall(l1l111_l1_ (u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢ㥣"),error)[0]
				elif l1l111_l1_ (u"࠭ࠬࠡࡧࡵࡶࡴࡸࠨࠨ㥤") in error: code,reason = re.findall(l1l111_l1_ (u"ࠢ࠭ࠢࡨࡶࡷࡵࡲ࡝ࠪࠫࡠࡩ࠱ࠩ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ㥥"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠨ࠼ࠪ㥦"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠩ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭ࠬ㥧"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if PY2: reason = err.message
			else: reason = str(err)
		except:
			l1llllllll1l_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㥨"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ㥩")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㥪")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㥫")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㥬")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㥭"))
		if l1ll1lll1l1l_l1_ and l111lllllll_l1_ and l1llllllll1l_l1_ and not l11ll1l11ll_l1_ and code!=200:
			l1lllll1_l1_ = l111l111lll_l1_
			l11ll1l11ll_l1_ = True
			continue
		if l1llllllll1l_l1_: break
	if l1lll1lll111_l1_!=None and l1ll1l1lll11_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㥮"): connection.create_connection = l11l11l111l_l1_
	if l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ㥯") and l11ll11ll11_l1_: l1lll1lll111_l1_ = None
	if not succeeded and l1ll1ll11l1l_l1_==None and source not in l111111lll1_l1_:
		l111l11l1ll_l1_ = traceback.format_exc()
		if l111l11l1ll_l1_!=l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ㥰"): sys.stderr.write(l111l11l1ll_l1_)
	l1lll1l11_l1_ = l1l1lllll11_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠬ࠭㥱")
	try: l1ll1ll11_l1_ = response.headers
	except: l1ll1ll11_l1_ = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if PY3:
		try: content = content.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㥲"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = l1ll1ll11_l1_
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if PY2 or isinstance(l1lll1l11_l1_.content,str): l111ll1l1ll_l1_ = l1lll1l11_l1_.content.lower()
	else: l111ll1l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ㥳")
	l1lllll1ll11_l1_ = (l1l111_l1_ (u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㥴") in l111ll1l1ll_l1_ or l1l111_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࠩ㥵") in l111ll1l1ll_l1_) and l111ll1l1ll_l1_.count(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭㥶"))>2 and l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㥷") not in source and l1l111_l1_ (u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴࠧ㥸") not in l111ll1l1ll_l1_ and not l1ll1llll1l1_l1_
	if code==200 and l1lllll1ll11_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1ll1lll1l1l_l1_ and l111lllllll_l1_:
		if l1lll1ll1ll1_l1_: l111ll111l1_l1_ = l1l111_l1_ (u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ㥹")+l1l11llll_l1_[l1l111_l1_ (u"ࠧ࡫ࡱࡥࠫ㥺")].upper().replace(l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㥻"),l1l111_l1_ (u"ࠩࠪ㥼"))
		l1lll11ll_l1_ = l1l1llllll1_l1_(l111ll111l1_l1_)
	if not l1lll1l11_l1_.succeeded and l1ll1lll1l1l_l1_:
		l1lllll1l1l1_l1_ = (l1l111_l1_ (u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ㥽") in l111ll1l1ll_l1_ and l1l111_l1_ (u"ࠫࡷࡧࡹࠡ࡫ࡧ࠾ࠥ࠭㥾") in l111ll1l1ll_l1_)
		l1lllll1l1ll_l1_ = (l1l111_l1_ (u"ࠬ࠻ࠠࡴࡧࡦࠫ㥿") in l111ll1l1ll_l1_ and l1l111_l1_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧ㦀") in l111ll1l1ll_l1_)
		l1lllll1lll1_l1_ = (code in [403] and l1l111_l1_ (u"ࠧࡦࡴࡵࡳࡷࠦࡣࡰࡦࡨ࠾ࠥ࠷࠰࠳࠲ࠪ㦁") in l111ll1l1ll_l1_)
		l1lllll1llll_l1_ = (l1l111_l1_ (u"ࠨࡡࡦࡪࡤࡩࡨ࡭ࡡࠪ㦂") in l111ll1l1ll_l1_ and l1l111_l1_ (u"ࠩࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࠭㦃") in l111ll1l1ll_l1_)
		if   l1lllll1ll11_l1_: reason = l1l111_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ㦄")
		elif l1lllll1l1l1_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ㦅")
		elif l1lllll1l1ll_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ㦆")
		elif l1lllll1lll1_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡢࡥࡦࡩࡸࡹࠠࡥࡧࡱ࡭ࡪࡪࠧ㦇")
		elif l1lllll1llll_l1_: reason = l1l111_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ㦈")
		else: reason = str(reason)
		if source in l1lll111l1ll_l1_: pass
		elif source in l111111lll1_l1_:
			l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㦉"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㦊")+str(code)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㦋")+reason+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㦌")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㦍")+l1lllll1_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㦎"))
		else: l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㦏"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㦐")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㦑")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㦒")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㦓")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㦔"))
		l1111lll111_l1_ = l111l11_l1_(l1lllll1_l1_)
		if PY2 and isinstance(l1111lll111_l1_,unicode): l1111lll111_l1_ = l1111lll111_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㦕"))
		if l111lllllll_l1_: l1111lll111_l1_ = l1111lll111_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ㦖"))[-1]
		l1lll1lll11l_l1_ = reason
		reason = str(reason)+l1l111_l1_ (u"ࠨ࡞ࡱࠬࠥ࠭㦗")+l1111lll111_l1_+l1l111_l1_ (u"ࠩࠣ࠭ࠬ㦘")
		if l1lllll1ll11_l1_ or l1lllll1l1l1_l1_ or l1lllll1l1ll_l1_ or l1lllll1lll1_l1_ or l1lllll1llll_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
			if l1lll1ll1l1l_l1_:
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㦙"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࡖࡵࡽ࡮ࡴࡧࠡࡤࡼࡴࡦࡹࡳࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭㦚")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㦛")+l1lll1lll11l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㦜")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㦝")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㦞"))
				l1ll1lll_l1_(l1l111_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠨ㦟"),l1l111_l1_ (u"ࠪห้็อึࠢส่ศ๋ๆ๋ࠩ㦠"),time=1500)
				l1ll1ll11111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠲ࠩ㦡"))
				l1ll1ll1111l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫ࡤࡰ࠴ࠪ㦢"))
				l1ll1ll11111_l1_ = 9999 if not l1ll1ll11111_l1_ else int(l1ll1ll11111_l1_)
				l1ll1ll1111l_l1_ = 9999 if not l1ll1ll1111l_l1_ else int(l1ll1ll1111l_l1_)
				l11lll11ll1_l1_ = []
				if l1ll1ll11111_l1_>10: l11lll11ll1_l1_.append(1)
				if l1ll1ll1111l_l1_>10: l11lll11ll1_l1_.append(2)
				l11lll11ll1_l1_.append(3)
				l11ll1ll11l_l1_ = random.sample(l11lll11ll1_l1_,1)[0]
				if l11ll1ll11l_l1_==1:
					l1111111l11_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡤ࠴࠹࠷ࡦࡨ࠱ࡦ࠷࠳࠸࠹ࡪ࠲ࡤࡣ࠸ࡨ࠺ࡪ࠳ࡧ࠻ࡨ࠷ࡨ࠹࠸࠷ࡧࡦࡥ࠶࠷࠰࠹࠵࠻࠽ࡦ࠽࠳࠻ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩ㦣")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㦤")+l1111111l11_l1_+l1l111_l1_ (u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨ㦥")
					l1lllll1ll1l_l1_ = l11l11lllll_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠲࡯ࡦࠪ㦦"),False,False)
				elif l11ll1ll11l_l1_==2:
					l1111111l11_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵ࡨ࠹ࡤ࠴ࡣࡨ࠵࠽࠻ࡤࡧ࠶ࡥࡪ࠻ࡧࡦ࠶࠵࠶ࡧ࠼࠶࠴࠱ࡤ࠶࠸࠼ࡩ࠹ࡦ࠻࠼ࡦࡪ࠺࠶࠷ࡣࡨ࠽࠿ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭㦧")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㦨")+l1111111l11_l1_+l1l111_l1_ (u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬ㦩")
					l1lllll1ll1l_l1_ = l11l11lllll_l1_(method,l1111111_l1_,data,headers,allow_redirects,False,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠷ࡷࡪࠧ㦪"),False,False)
				elif l11ll1ll11l_l1_==3:
					l1111111l11_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠾࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࡂࡳࡶࡴࡾࡹ࠮ࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡩ࡯࡮࠼࠻࠴࠵࠷ࠧ㦫")
					l1111111_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㦬")+l1111111l11_l1_+l1l111_l1_ (u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ㦭")
					l1lllll1ll1l_l1_ = l11l11lllll_l1_(method,l1111111_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠵ࡶ࡫ࠫ㦮"),False,False)
				else: l1lllll1ll1l_l1_ = l1lll1l11_l1_
				code,reason = l1lllll1ll1l_l1_.code,l1lllll1ll1l_l1_.reason
				if not l1lllll1ll1l_l1_.succeeded:
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㦯"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ㦰")+str(code)+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㦱")+reason+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ㦲")+source+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㦳")+l1111111_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㦴"))
					l1ll1lll_l1_(l1l111_l1_ (u"่้ࠪษำโࠢไุ้ࠦวๅใะูࠥอไฤ็้๎ࠬ㦵"),l1l111_l1_ (u"ࠫัืศࠡ็ิอࠥษฮา๋ࠪ㦶"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㦷"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㦸")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㦹")+l1111111_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㦺"))
					if l11ll1ll11l_l1_ in [1,2]:
						l1ll11llll11_l1_ = l1lllll1ll1l_l1_.headers[l1l111_l1_ (u"ࠩࡖࡧࡷࡧࡰࡦ࠰ࡧࡳ࠲ࡘࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧ࠮ࡅࡵࡩࡩ࡯ࡴࡴࠩ㦻")]
						if l11ll1ll11l_l1_==1: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡩࡵ࠱ࠨ㦼"),l1ll11llll11_l1_)
						if l11ll1ll11l_l1_==2: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠳ࠩ㦽"),l1ll11llll11_l1_)
					l1ll1lll_l1_(l1l111_l1_ (u"ࠬ์ฬฮࠢส่ๆำีࠡษ็ว๊์๊ࠨ㦾"),l1l111_l1_ (u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧ㦿"),time=2000)
					return l1lllll1ll1l_l1_
		l1llll111l_l1_ = True
		if (l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧀") or l1ll1ll1ll1l_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㧁")) and (l11ll11ll11_l1_ or l1lll1ll1l1l_l1_):
			l1llll111l_l1_ = l11111111ll_l1_(code,reason,source,l11_l1_)
			if l1llll111l_l1_ and l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㧂"): l1ll1l1lll11_l1_ = l1l111_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㧃")
			else: l1ll1l1lll11_l1_ = l1l111_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭㧄")
			if l1llll111l_l1_ and l1ll1ll1ll1l_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㧅"): l1ll1ll1ll1l_l1_ = l1l111_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ㧆")
			else: l1ll1ll1ll1l_l1_ = l1l111_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㧇")
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ㧈"),l1ll1l1lll11_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㧉"),l1ll1ll1ll1l_l1_)
		if l1llll111l_l1_:
			l1ll1l111111_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㧊") in l1lllll1_l1_ and l1ll1l111111_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫ㧋"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧌"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭㧍")
				l1lll11ll_l1_ = l11l11lllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠺ࡺࡨࠨ㧎"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㧏"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧐")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧑")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧒"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ์ฬศฯࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩ㧓"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧔"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㧕"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㧖")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㧗")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㧘"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫๆฺไࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧ㧙"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧚"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1ll1ll1l_l1_ in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㧛"),l1l111_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ㧜")] and l1lll1ll1l1l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨฬไ฽๏๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨ㧝"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㧞"),time=2000)
				l1lll11ll_l1_ = l11ll11lll1_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠷ࡶ࡫ࠫ㧟"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㧠"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧡")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧢")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧣"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ㧤"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㧥"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㧦"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧧")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㧨")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㧩"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㧪"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㧫"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll1l1lll11_l1_ in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㧬"),l1l111_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㧭")] and l11ll11ll11_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭㧮"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧯"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ㧰")
				l1lll11ll_l1_ = l11l11lllll_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠼ࡺࡨࠨ㧱"))
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㧲"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩ㧳")+l1ll11lll1l1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧴")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧵")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧶"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧ㧷"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧸"),time=2000)
				else:
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧹"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡊࡎࡔࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭㧺")+l1ll11lll1l1_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧻")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㧼")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㧽"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭แีๆࠣื๏ืแาࠢࡇࡒࡘ࠭㧾"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧿"),time=2000)
		if l1ll1ll1ll1l_l1_==l1l111_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㨀") or l1ll1l1lll11_l1_==l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㨁"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11lll11l1l_l1_ = l11111111ll_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l1l1llll_l1_ and l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࠧ㨂") not in source:
				l1111l1l1ll_l1_(l1l111_l1_ (u"ࠫࡋࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠢࡧࡹࡪࠦࡴࡰࠢࡱࡩࡹࡽ࡯ࡳ࡭ࠣ࡭ࡸࡹࡵࡦࡵࠣࡻ࡮ࡺࡨ࠻ࠢࠪ㨃")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ㨄")) not in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㨅"),l1l111_l1_ (u"ࠧࡔࡖࡒࡔࠬ㨆"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㨇")]: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ㨈"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㨉"))
	if settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ㨊")) not in [l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㨋"),l1l111_l1_ (u"࠭ࡓࡕࡑࡓࠫ㨌"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㨍")]: settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭㨎"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㨏"))
	return l1lll1l11_l1_
def l11l1l_l1_(cache,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll11_l1_=None,l1lll1ll1l1l_l1_=None):
	l1lllll1_l1_,l1ll1ll11l1l_l1_,l1lll1lll111_l1_,l1llll1111l1_l1_ = l1ll1l1l111l_l1_(url)
	item = method,l1lllll1_l1_,data,headers,allow_redirects
	if cache:
		response = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬ㨐"),l1l111_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧ㨑"),item)
		if response.succeeded:
			l1l1l1ll11l_l1_(l1l111_l1_ (u"ࠬࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬ㨒"),l1lllll1_l1_,data,headers,source,method)
			return response
	response = l11l11lllll_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11ll11_l1_,l1lll1ll1l1l_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ㨓") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if cache: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ㨔"),item,response,cache)
	return response
def l1l1llll_l1_(cache,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㨕")
	else:
		method = l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㨖")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(cache,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1ll1l1l111l_l1_(url):
	l1ll1ll1l1ll_l1_ = url.split(l1l111_l1_ (u"ࠪࢀࢁ࠭㨗"))
	l1lllll1_l1_,l1ll1ll11l1l_l1_,l1lll1lll111_l1_,l1llll1111l1_l1_ = l1ll1ll1l1ll_l1_[0],None,None,True
	for item in l1ll1ll1l1ll_l1_:
		if l1l111_l1_ (u"ࠫࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㨘") in item: l1ll1ll11l1l_l1_ = item.split(l1l111_l1_ (u"ࠬࡃࠧ㨙"))[1]
		elif l1l111_l1_ (u"࠭ࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩ㨚") in item: l1lll1lll111_l1_ = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ㨛"))[1]
		elif l1l111_l1_ (u"ࠨࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭㨜") in item: l1llll1111l1_l1_ = False
	return l1lllll1_l1_,l1ll1ll11l1l_l1_,l1lll1lll111_l1_,l1llll1111l1_l1_
def l11lll1111l_l1_(name):
	start,l1lll11ll11_l1_,modified = l1l111_l1_ (u"ࠩࠪ㨝"),l1l111_l1_ (u"ࠪࠫ㨞"),l1l111_l1_ (u"ࠫࠬ㨟")
	name = name.replace(ltr,l1l111_l1_ (u"ࠬ࠭㨠")).replace(rtl,l1l111_l1_ (u"࠭ࠧ㨡"))
	tmp = re.findall(l1l111_l1_ (u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ㨢"),name,re.DOTALL)
	if tmp: start,l1lll11ll11_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠨࠢࠪ㨣"),l1l111_l1_ (u"ࠩ࠯ࠫ㨤"),l1l111_l1_ (u"ࠪࠫ㨥")]: modified = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㨦")
	if l1lll11ll11_l1_: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠬࡥࠧ㨧")+l1lll11ll11_l1_+l1l111_l1_ (u"࠭࡟ࠨ㨨")
	name = l1lll11ll11_l1_+modified+name
	return name
def l1lllll1l1l_l1_(cache,method,url,l11l111l111_l1_,l1lll1l1l1ll_l1_,l111111ll1l_l1_,headers=l1l111_l1_ (u"ࠧࠨ㨩")):
	l1ll11l1l11l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㨪"))
	l11l1l111ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㨫")+l11l111l111_l1_)
	if l1ll11l1l11l_l1_==l11l1l111ll_l1_: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ㨬")+l11l111l111_l1_,l1l111_l1_ (u"ࠫࠬ㨭"))
	if l11l1l111ll_l1_: l1llllll_l1_ = url.replace(l1ll11l1l11l_l1_,l11l1l111ll_l1_)
	else:
		l1llllll_l1_ = url
		l11l1l111ll_l1_ = l1ll11l1l11l_l1_
	l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠬ࠭㨮"),headers,l1l111_l1_ (u"࠭ࠧ㨯"),l1l111_l1_ (u"ࠧࠨ㨰"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬ㨱"))
	html = l1lll11ll_l1_.content
	if PY3:
		try: html = html.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㨲"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㨳"))
		except: pass
	code = l1lll11ll_l1_.code
	if code!=-2 and (not l1lll11ll_l1_.succeeded or l111111ll1l_l1_ not in html):
		l1lll1l1l1ll_l1_ = l1lll1l1l1ll_l1_.replace(l1l111_l1_ (u"ࠫࠥ࠭㨴"),l1l111_l1_ (u"ࠬ࠱ࠧ㨵"))
		l1lllll1_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ㨶")+l1lll1l1l1ll_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㨷"):l1l111_l1_ (u"ࠨࠩ㨸")}
		l1lll1l11_l1_ = l11l1l_l1_(cache,method,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ㨹"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ㨺"),l1l111_l1_ (u"ࠫࠬ㨻"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩ㨼"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if PY3:
				try: html = html.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㨽"),l1l111_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ㨾"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ㨿"),html,re.DOTALL)
			l111l1111ll_l1_ = [l11l1l111ll_l1_]
			l111l1ll111_l1_ = [l1l111_l1_ (u"ࠩࡤࡴࡰ࠭㩀"),l1l111_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ㩁"),l1l111_l1_ (u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬ㩂"),l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭㩃"),l1l111_l1_ (u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨ㩄"),l1l111_l1_ (u"ࠧࡱࡪࡳࠫ㩅"),l1l111_l1_ (u"ࠨࡣࡷࡰࡦࡷࠧ㩆"),l1l111_l1_ (u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧ㩇"),l1l111_l1_ (u"ࠪࡷࡺࡸ࠮࡭ࡻࠪ㩈"),l1l111_l1_ (u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭㩉"),l1l111_l1_ (u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧ㩊"),l1l111_l1_ (u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨ㩋"),l1l111_l1_ (u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪ㩌"),l1l111_l1_ (u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪ㩍"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭㩎"),l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭㩏")]
			for l1ll1ll_l1_ in l1ll_l1_:
				if any(value in l1ll1ll_l1_ for value in l111l1ll111_l1_): continue
				l11l1l111ll_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㩐"))
				if l11l1l111ll_l1_ in l111l1111ll_l1_: continue
				if len(l111l1111ll_l1_)==9:
					l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㩑"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣࡪ࡮ࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭㩒")+l11l111l111_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬ㩓")+l1ll11l1l11l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㩔"))
					settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ㩕")+l11l111l111_l1_,l1l111_l1_ (u"ࠪࠫ㩖"))
					break
				l111l1111ll_l1_.append(l11l1l111ll_l1_)
				l1llllll_l1_ = url.replace(l1ll11l1l11l_l1_,l11l1l111ll_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(cache,method,l1llllll_l1_,l1l111_l1_ (u"ࠫࠬ㩗"),headers,l1l111_l1_ (u"ࠬ࠭㩘"),l1l111_l1_ (u"࠭ࠧ㩙"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫ㩚"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l111111ll1l_l1_ in html:
					l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㩛"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ㩜")+l11l111l111_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩ㩝")+l11l1l111ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ㩞")+l1ll11l1l11l_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㩟"))
					settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ㩠")+l11l111l111_l1_,l11l1l111ll_l1_)
					break
	return l11l1l111ll_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠧࡰ࡮ࡧࠫ㩡")			:l1l111_l1_ (u"ࠨไา๎๊࠭㩢")
	,l1l111_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ㩣")		:l1l111_l1_ (u"้ࠪฯ๎โโࠩ㩤")
	,l1l111_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ㩥")		:l1l111_l1_ (u"๋ࠬแใ๊าࠫ㩦")
	,l1l111_l1_ (u"࠭ࡧࡰࡱࡧࠫ㩧")			:l1l111_l1_ (u"ࠧอ์าࠫ㩨")
	,l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㩩")		:l1l111_l1_ (u"ࠩไุ้࠭㩪")
	,l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㩫")		:l1l111_l1_ (u"๊ࠫาไะࠩ㩬")
	,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㩭")		:l1l111_l1_ (u"࠭แ๋ัํ์ࠬ㩮")
	,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㩯")			:l1l111_l1_ (u"ࠨไ้หฮ࠭㩰")
	,l1l111_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭ࠨ㩱")		:l1l111_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ㩲")
	,l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ㩳")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢส่ัี๊ะࠩ㩴")
	,l1l111_l1_ (u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨ㩵")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨ㩶")
	,l1l111_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ㩷")		:l1l111_l1_ (u"่ࠩ์็฿ࠠไๆࠣห้฿ัษࠩ㩸")
	,l1l111_l1_ (u"ࠪࡥࡱ࡬ࡡࡵ࡫ࡰ࡭ࠬ㩹")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢส่๊์ศาࠢส่ๆอืๆ์ࠪ㩺")
	,l1l111_l1_ (u"ࠬࡧ࡬࡬ࡣࡺࡸ࡭ࡧࡲࠨ㩻")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่่๎หาࠩ㩼")
	,l1l111_l1_ (u"ࠧࡢ࡮ࡰࡥࡦࡸࡥࡧࠩ㩽")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬ㩾")
	,l1l111_l1_ (u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫ㩿")		:l1l111_l1_ (u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫ㪀")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨ㪁")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦࡶࡪࡲࠪ㪂")
	,l1l111_l1_ (u"࠭ࡥ࡭ࡥ࡬ࡲࡪࡳࡡࠨ㪃")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอไิ์้้ฬ࠭㪄")
	,l1l111_l1_ (u"ࠨࡪࡨࡰࡦࡲࠧ㪅")		:l1l111_l1_ (u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ㪆")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬ㪇")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬ㪈")
	,l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㪉")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨ㪊")
	,l1l111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡳࡡࡹࠩ㪋")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨ㪌")
	,l1l111_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ㪍")		:l1l111_l1_ (u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪ㪎")
	,l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ㪏")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠬ㪐")
	,l1l111_l1_ (u"࠭࡫ࡢࡴࡥࡥࡱࡧࡴࡷࠩ㪑")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪ㪒")
	,l1l111_l1_ (u"ࠨࡻࡷࡦࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ㪓")	:l1l111_l1_ (u"่ࠩ์ฬู่ࠡ์๋ฮ๏๎ศࠨ㪔")
	,l1l111_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ㪕")		:l1l111_l1_ (u"๊ࠫ๎โฺ่ࠢห๏ࠦำ๋็สࠫ㪖")
	,l1l111_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ㪗")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠬ㪘")
	,l1l111_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩ㪙")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪ㪚")
	,l1l111_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠵ࠫ㪛")		:l1l111_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅอส๊๏࠭㪜")
	,l1l111_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ㪝")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣฬ่ืวࠨ㪞")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ㪟")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨ㪠")
	,l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪࡺࡶࠨ㪡")		:l1l111_l1_ (u"่่ࠩๆ࠭㪢")
	,l1l111_l1_ (u"ࠪࡰ࡮ࡨࡲࡢࡴࡼࠫ㪣")		:l1l111_l1_ (u"๊๊ࠫแࠨ㪤")
	,l1l111_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ㪥")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨ㪦")
	,l1l111_l1_ (u"ࠧࡧࡣ࡭ࡩࡷࡹࡨࡰࡹࠪ㪧")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭㪨")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ㪩")		:l1l111_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫ㪪")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭㪫")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨ㪬")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠲ࠨ㪭")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠴ࠪ㪮")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪ㪯")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬ㪰")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠸ࠬ㪱")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠺ࠧ㪲")
	,l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ㪳")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨ㪴")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ㪵")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨ㪶")
	,l1l111_l1_ (u"ࠩࡨ࡫ࡾࡪࡥࡢࡦࠪ㪷")		:l1l111_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ㪸")
	,l1l111_l1_ (u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭㪹")		:l1l111_l1_ (u"๋่ࠬใ฻๋้ࠣอࠠิ์่หࠬ㪺")
	,l1l111_l1_ (u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧ㪻")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭㪼")
	,l1l111_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ㪽")		:l1l111_l1_ (u"่ࠩ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ㪾")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡭࡫ࡪ࡬ࡹ࠭㪿")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠๅษํฮࠬ㫀")
	,l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨࡳ࡫ࡷࡴࠩ㫁")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧ㫂")
	,l1l111_l1_ (u"ࠧࡧࡱࡶࡸࡦ࠭㫃")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแ้ีอหࠬ㫄")
	,l1l111_l1_ (u"ࠩࡤ࡬ࡼࡧ࡫ࠨ㫅")		:l1l111_l1_ (u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬ㫆")
	,l1l111_l1_ (u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬ㫇")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๅอืใสࠩ㫈")
	,l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬ㫉")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬ㫊")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪ㫋")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪ㫌")
	,l1l111_l1_ (u"ࠪࡷ࡭ࡵࡦࡩࡣࠪ㫍")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭㫎")
	,l1l111_l1_ (u"ࠬࡨࡲࡴࡶࡨ࡮ࠬ㫏")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫ㫐")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨ㫑")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨ㫒")
	,l1l111_l1_ (u"ࠩ࡯ࡥࡷࡵࡺࡢࠩ㫓")		:l1l111_l1_ (u"้ࠪํู่ࠡๆสีํุวࠨ㫔")
	,l1l111_l1_ (u"ࠫࡾࡧࡱࡰࡶࠪ㫕")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩ㫖")
	,l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ㫗")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫ㫘")
	,l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡴࡵࡸࠪ㫙")		:l1l111_l1_ (u"่ࠩ์็฿ࠠไฬๆ์ฯࠦส๋ใํࠫ㫚")
	,l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡷࡳࡴࡴࡳࠨ㫛")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢอ์ฺุ๋ࠠำห๎ฮ࠭㫜")
	,l1l111_l1_ (u"ࠬࡪࡲࡢ࡯ࡤࡷ࠼࠭㫝")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤิืวๆษูࠣา࠭㫞")
	,l1l111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ㫟")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧ㫠")
	,l1l111_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨ㫡")				:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ㫢")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪ㫣")			:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧ㫤")
	,l1l111_l1_ (u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭㫥")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬ㫦")
	,l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺࠧ㫧")				:l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭㫨")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㫩")			:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧ㫪")
	,l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㫫")			:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫ㫬")
	,l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ㫭")				:l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭㫮")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪ㫯")		:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪ㫰")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ㫱")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩ㫲")
	,l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ㫳")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫ㫴")
	,l1l111_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫ㫵")			:l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫ㫶")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧ㫷")	:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫ㫸")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣ࡯ࡦࡺࡳࡳࠨ㫹")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧ㫺")
	,l1l111_l1_ (u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡺࡪࡩࡰࡵࠪ㫻")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪ㫼")
	,l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ㫽")			:l1l111_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠫ㫾")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩ㫿")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨ㬀")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ㬁"):l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧ㬂")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨ㬃")	:l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆ๋๎วหࠩ㬄")
	,l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡶࡲࡴ࡮ࡩࡳࠨ㬅")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬ㬆")
	,l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ㬇")					:l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㬈")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡲࡩࡷࡧࠪ㬉")			:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛ࠦโ็๊สฮࠬ㬊")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㬋")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡลไ่ฬ๋ࠧ㬌")
	,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡶࡩࡷ࡯ࡥࡴࠩ㬍")			:l1l111_l1_ (u"ࠬࡏࡐࡕࡘุ้๊ࠣำๅษอࠫ㬎")
	,l1l111_l1_ (u"࠭࡭࠴ࡷࠪ㬏")					:l1l111_l1_ (u"ࠧࡎ࠵ࡘࠫ㬐")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪ㬑")				:l1l111_l1_ (u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬ㬒")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㬓")			:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧ㬔")
	,l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩ㬕")			:l1l111_l1_ (u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫ㬖")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠧࠨ㬗")
	return result
def l1111l1l1ll_l1_(message=l1l111_l1_ (u"ࠨࠩ㬘")):
	l1lll1l1ll1l_l1_()
	if not message: message = l1l111_l1_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡈࡼ࡮ࡺࠧ㬙")
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࠫ㬚"),l1l111_l1_ (u"ࠫࡡࡴࠧ㬛")+message+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㬜"))
	try: sys.exit()
	except: pass
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"࠭࠺࠰ࠩ㬝")):
	return _1lllllll1l1_l1_(urll,exceptions)
def l11l111l1ll_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠧࠨ㬞"),l1l111_l1_ (u"ࠨ࠲ࠪ㬟"),0]: return l1l111_l1_ (u"ࠩࠪ㬠")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1ll1111_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1ll1l_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll1111_l1_)+str(l111ll1ll1l_l1_)+str(l111l111_l1_)
	return result
def l1ll1ll1l111_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠪࠫ㬡"),l1l111_l1_ (u"ࠫ࠵࠭㬢"),0]: return l1l111_l1_ (u"ࠬ࠭㬣")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"࠭ࠧ㬤")
	if len(l1l1llll1_l1_)==15:
		l11l1ll1111_l1_,l111ll1ll1l_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1ll1111_l1_ = int(l11l1ll1111_l1_)^l111l11l_l1_
		l111ll1ll1l_l1_ = int(l111ll1ll1l_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1ll1111_l1_==l111ll1ll1l_l1_==l111l111_l1_: result = str(l11l1ll1111_l1_*60)
	return result
def l1lll1ll111l_l1_(l1l1llll1_l1_,l1lll1lllll1_l1_=l1l111_l1_ (u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩ㬥")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠨࠩ㬦"): return l1l111_l1_ (u"ࠩࠪ㬧")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1lll1lllll1_l1_)
	l11l1ll1111_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111ll1ll1l_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1ll1111_l1_)+str(l111ll1ll1l_l1_)+str(l111l111_l1_)
	return result
def l1111l1l11l_l1_(l1l1llll1_l1_,l1lll1lllll1_l1_=l1l111_l1_ (u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬ㬨")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠫࠬ㬩"): return l1l111_l1_ (u"ࠬ࠭㬪")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l11ll11_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1ll1111_l1_ = int(l1l1llll1_l1_[0:l1l1l11ll11_l1_])^l1ll1ll1_l1_
	l111ll1ll1l_l1_ = int(l1l1llll1_l1_[l1l1l11ll11_l1_:2*l1l1l11ll11_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l11ll11_l1_:3*l1l1l11ll11_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"࠭ࠧ㬫")
	if l11l1ll1111_l1_==l111ll1ll1l_l1_==l111l111_l1_: result = str(int(l11l1ll1111_l1_)-int(l1lll1lllll1_l1_))
	return result
def l1l1ll1111l_l1_(l1l11l1l111_l1_):
	l1llllll11l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㬬")][8]
	l1lll11l1l11_l1_ = l1l11l1l1ll_l1_(32)
	l1lll11l1lll_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ㬭"),l1l111_l1_ (u"ࠩࡶ࡯࡮ࡴࡳࠨ㬮"),l1l111_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㬯"),l1l111_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㬰"),l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㬱"))
	l11ll111l11_l1_,l11l11111l1_l1_ = l1ll1l11ll_l1_(l1lll11l1lll_l1_)
	l11ll111l11_l1_ = l1lll1ll111l_l1_(l11ll111l11_l1_,l1l111_l1_ (u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩ㬲"))
	l111ll1l11l_l1_ = {l1l111_l1_ (u"ࠧࡪࡦࡶࠫ㬳"):l1l111_l1_ (u"ࠨࡆࡌࡅࡑࡕࡇࠨ㬴"),l1l111_l1_ (u"ࠩࡸࡷࡷ࠭㬵"):l1lll11l1l11_l1_,l1l111_l1_ (u"ࠪࡺࡪࡸࠧ㬶"):l1l11l1111l_l1_,l1l111_l1_ (u"ࠫࡸࡩࡲࠨ㬷"):l1l11l1l111_l1_,l1l111_l1_ (u"ࠬࡹࡩࡻࠩ㬸"):l11ll111l11_l1_}
	l1llll111ll1_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㬹"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㬺")}
	l1lllllll111_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㬻"),l1llllll11l1_l1_,l111ll1l11l_l1_,l1llll111ll1_l1_,l1l111_l1_ (u"ࠩࠪ㬼"),l1l111_l1_ (u"ࠪࠫ㬽"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬ㬾"))
	l1ll1l1111l1_l1_ = l1lllllll111_l1_.content
	try:
		if not l1ll1l1111l1_l1_: l1ll1l1lllll_l1_
		l1llll1111ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㬿"),l1ll1l1111l1_l1_)
		l1ll11llll1l_l1_ = l1llll1111ll_l1_[l1l111_l1_ (u"࠭࡭ࡴࡩࠪ㭀")]
		l1ll1ll111l1_l1_ = l1llll1111ll_l1_[l1l111_l1_ (u"ࠧࡴࡧࡦࠫ㭁")]
		l1llll1l1lll_l1_ = l1llll1111ll_l1_[l1l111_l1_ (u"ࠨࡵࡷࡴࠬ㭂")]
		l1ll1ll111l1_l1_ = int(l1111l1l11l_l1_(l1ll1ll111l1_l1_,l1l111_l1_ (u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬ㭃")))
		l1llll1l1lll_l1_ = int(l1111l1l11l_l1_(l1llll1l1lll_l1_,l1l111_l1_ (u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭㭄")))
		for l111l1l11l1_l1_ in range(l1ll1ll111l1_l1_,0,-l1llll1l1lll_l1_):
			if not eval(l1l111_l1_ (u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧ㭅")): l1ll1l1lllll_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠬฮวใ์่้ࠣะฬาสฬࠤํอไโฯุࠫ㭆"),str(l111l1l11l1_l1_)+l1l111_l1_ (u"࠭ࠠࠡอส๊๏ฯࠧ㭇"),time=300*l1llll1l1lll_l1_)
			xbmc.sleep(1000*l1llll1l1lll_l1_)
		if eval(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪ㭈")):
			l111ll1l1l1_l1_ = l1l111_l1_ (u"ࠣࡆࡌࡅࡑࡕࡇࡨࡡࡒࡏ࠭࠭ࠧ࠭ࠩัีําࠧ࠭ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࠲ࠧࠣ㭉")+l1ll11llll1l_l1_+l1l111_l1_ (u"ࠤࠪ࠭ࠧ㭊")
			l111ll1l1l1_l1_ = l111ll1l1l1_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㭋"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㭌")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㭍"),l1l111_l1_ (u"࠭࡜࡝ࡴࠪ㭎"))
			exec(l111ll1l1l1_l1_)
		l1ll1l1lllll_l1_
	except: exec(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧ㭏"))
	return
def l1l1111l1l1_l1_():
	exec(l1l111_l1_ (u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭㭐"))
	return
def l1ll1l11ll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1llll1ll1_l1_(l1lll1111lll_l1_,l1lll1111111_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ㭑"),l1l111_l1_ (u"ࠪࠫ㭒"),l1l111_l1_ (u"ࠫࠬ㭓"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㭔"),l1lll1111lll_l1_+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ㭕")+l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㭖"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1lll1111lll_l1_):
		for root,dirs,l1l1111111_l1_ in os.walk(l1lll1111lll_l1_,topdown=False):
			for file in l1l1111111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㭗"),l1l111_l1_ (u"ࠩࠪ㭘"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㭙"),str(err))
					error = True
			if l1lll1111111_l1_:
				for dir in dirs:
					l1ll11l11l1l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1ll11l11l1l_l1_)
					except: pass
		if l1lll1111111_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㭚"),l1l111_l1_ (u"ࠬ࠭㭛"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㭜"),l1l111_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨ㭝"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭞"),l1l111_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬ㭟"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㭠"))
	return
def l1lll1l1ll1l_l1_(l111l11l1ll_l1_=l1l111_l1_ (u"ࠫࠬ㭡")):
	l11ll11ll1l_l1_(l1l111_l1_ (u"ࠬࡹࡴࡰࡲࠪ㭢"))
	if l111l11l1ll_l1_:
		l1111l11111_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㭣"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㭤"),l1l111_l1_ (u"ࠨࠩ㭥"))
		l11l1llllll_l1_(l111l11l1ll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㭦"),l1111l11111_l1_)
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㭧"))
	if l1ll11l1l1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡊࡊࠧ㭨"): settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㭩"),l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㭪"))
	elif l1ll11l1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ㭫"): settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㭬"),l1l111_l1_ (u"ࠩࠪ㭭"))
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭㭮")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㭯"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㭰"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㭱")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ㭲"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㭳"))
	if settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ㭴")) not in [l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㭵"),l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㭶"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㭷")]: settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ㭸"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㭹"))
	l11lll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭㭺"))
	l11l11l1l11_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ㭻"))
	if l1l111_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ㭼") in str(l11l11l1l11_l1_) and l11lll1llll_l1_ in [l1l111_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ㭽"),l1l111_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ㭾")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡖࡩࡹ࡜ࡩࡦࡹࡐࡳࡩ࡫ࠨ࠱ࠫࠪ㭿"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l111l11l11l_l1_,l11ll11llll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l111l11l11l_l1_,l11ll11llll_l1_)
	return
def l1lllll111l_l1_(cache,method,url,data,headers,source):
	l1lllll1_l1_,l1ll1ll11l1l_l1_,l1lll1lll111_l1_,l1llll1111l1_l1_ = l1ll1l1l111l_l1_(url)
	item = method,l1lllll1_l1_,data,headers
	if cache:
		html = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡴࡶࡵࠫ㮀"),l1l111_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㮁"),item)
		if html:
			l1l1l1ll11l_l1_(l1l111_l1_ (u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ㮂"),url,data,headers,source,method)
			return html
	html = l1l1111l1ll_l1_(method,url,data,headers,source)
	if html and cache: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ㮃"),item,html,cache)
	return html
DIALOGg_OK = l1111l1_l1_
l11lllll111_l1_ = l11ll11ll1l_l1_
l11lll11lll_l1_ = l1lll1l1l11l_l1_
DIALOGg_YESNO = l1ll11ll1l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
DIALOGg_PROGRESS = l1l111lll1_l1_
DIALOGg_TEXTVIEWER = l1ll1ll11l11_l1_
DIALOGg_CONTEXTMENU = l11ll11111l_l1_
l111l1l1lll_l1_ = l1l11111l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1ll11ll11l1_l1_
l1lll11l1ll1_l1_ = l1l11l1l1l_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
OPENURLl_CACHED = l1l1llll_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1l1111l11_l1_
DOWNLOADd_USING_PROGRESSBAR = l1llllll1111_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
HOURr = l1l11lll1ll_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1lll11ll1l_l1_
PERMANENT_CACHEe = l1ll111l1ll_l1_
from EXCLUDES import *
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪⶈ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡌࡑࡉ࡟ࠨⶉ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ฺ้ࠪอัฺหࠪⶊ"),l1l111_l1_ (u"ࠫฬำฯฬࠢส่อืวๆฮࠪⶋ"),l1l111_l1_ (u"ࠬออะอࠣห้อไฺษหࠫⶌ"),l1l111_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬⶍ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==80: l1lll_l1_ = l1l1l11_l1_()
	elif mode==81: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==82: l1lll_l1_ = PLAY(url)
	elif mode==83: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==89: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⶎ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩⶏ"),l1l111_l1_ (u"ࠩࠪⶐ"),l1l111_l1_ (u"ࠪࠫⶑ"),l1l111_l1_ (u"ࠫࠬⶒ"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩⶓ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪⶔ"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶕ"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨⶖ"),l1l111_l1_ (u"ࠩࠪ⶗"),89,l1l111_l1_ (u"ࠪࠫ⶘"),l1l111_l1_ (u"ࠫࠬ⶙"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⶚"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⶛"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⶜"),l1l111_l1_ (u"ࠨࠩ⶝"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⶞"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⶟"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࡃ࡮ࡺࡥ࡮࠿ࠪⶠ")+l111l1l1l_l1_+l1l111_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭ⶡ")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶢ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⶣ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⶤ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⶥ"),l1l111_l1_ (u"ࠪࠫⶦ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡴࡡࡷ࠯ࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡹࡂࠬ⶧"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫⶨ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨⶩ"): continue
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶪ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⶫ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪⶬ")):
	items = []
	if l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪⶭ") in url or l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬⶮ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⶯"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ⶰ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬⶱ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩⶲ"),l1l111_l1_ (u"ࠩࠪⶳ"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩⶴ"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨⶵ"),url,l1l111_l1_ (u"ࠬ࠭ⶶ"),l1l111_l1_ (u"࠭ࠧ⶷"),l1l111_l1_ (u"ࠧࠨⶸ"),l1l111_l1_ (u"ࠨࠩⶹ"),l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨⶺ"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬⶻ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫⶼ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⶽ"),block,re.DOTALL)
		elif l1l111_l1_ (u"࠭ࠢࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡲࡲࡷࡹࠦ࡭ࡣ࠯࠴࠴ࠧ࠭ⶾ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⶿"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭ⷀ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⷁ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⷂ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫⷃ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪⷄ"),l1l111_l1_ (u"࠭ว฻่ํอࠬⷅ"),l1l111_l1_ (u"ࠧไๆํฬࠬⷆ"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ⷇"),l1l111_l1_ (u"๊ࠩำฬ็ࠧⷈ"),l1l111_l1_ (u"้ࠪออัศหࠪⷉ"),l1l111_l1_ (u"ࠫ฾ืึࠨⷊ"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬⷋ"),l1l111_l1_ (u"࠭วๅส๋้ࠬⷌ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠧ࠰ࠩⷍ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫⷎ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ⷏") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷐ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
		elif l1l111_l1_ (u"ุ๊ࠫวิๆࠪⷑ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⷒ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭ⷓ") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ⷔ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷕ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫⷖ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⷗"),l1lllll_l1_+title,l1ll1ll_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷘ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠬ࠭ⷙ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࠪⷚ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩⷛ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠣࠤⷜ"): continue
				if title!=l1l111_l1_ (u"ࠩࠪⷝ"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷞ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ⷟")+title,l1ll1ll_l1_,81)
	if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬⷠ") in url or l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧⷡ") in url:
		if l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧⷢ") in url:
			url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨⷣ"),l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪⷤ"))+l1l111_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁ࠷࠶ࠧⷥ")
		elif l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬⷦ") in url:
			url,offset = url.split(l1l111_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧⷧ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨⷨ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷩ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ้้ห่ࠦวๅ็ี๎ิ࠭ⷪ"),url,81)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ⷫ"),url,l1l111_l1_ (u"ࠪࠫⷬ"),l1l111_l1_ (u"ࠫࠬⷭ"),l1l111_l1_ (u"ࠬ࠭ⷮ"),l1l111_l1_ (u"࠭ࠧⷯ"),l1l111_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨⷰ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸࡈࡹࡔࡧࡵ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩⷱ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡰ࡮ࡹࡴ࠮ࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ⷲ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬⷳ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪⷴ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷵ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡪ࡯ࡤ࡫ࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⷶ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⷷ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⷸ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫⷹ"),l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡱࡴࡼࡩࡦࡵ࠲ࠫⷺ"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨⷻ"),l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨⷼ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪⷽ"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨⷾ"),l1l111_l1_ (u"ࠨࠩⷿ"),l1l111_l1_ (u"ࠩࠪ⸀"),l1l111_l1_ (u"ࠪࠫ⸁"),l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⸂"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ⸃"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⸄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡎࡊࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ⸅"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ⸆"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ⸇"),l1l111_l1_ (u"ࠪࠫ⸈")).strip(l1l111_l1_ (u"ࠫࠥ࠭⸉"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ⸊")+server+l1l111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡎࡊ࠽ࠨ⸋")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨ⸌")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⸍")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⸎")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡵࡷ࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⸏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⸐"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⸑")+name+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⸒")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⸓"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ⸔"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ⸕"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ⸖"),l1l111_l1_ (u"ࠫ࠲࠭⸗"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⸘")+search+l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ⸙")
	l1lll11_l1_(url)
	return
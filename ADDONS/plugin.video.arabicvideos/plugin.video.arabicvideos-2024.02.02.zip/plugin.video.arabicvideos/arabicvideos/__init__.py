# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll11l_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡊࡐࡌࡘࠬ摌")
l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ摍"),l1l111_l1_ (u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠩ摎"))
l1lll11l111_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l111_l1_
l1lll11lllll_l1_ = int(mode)
l1llll1lllll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ摏"))
l1llll1lllll_l1_ = l1llll1lllll_l1_.replace(ltr,l1l111_l1_ (u"ࠫࠬ摐")).replace(rtl,l1l111_l1_ (u"ࠬ࠭摑"))
if l1lll11lllll_l1_==260: message = l1l111_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ摒")+l1l11l1111l_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ摓")+l1l1l11l111_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ摔")
else:
	l111lll1llll_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ摕"),l1l111_l1_ (u"ࠪࠫ摖")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ摗"),l1l111_l1_ (u"ࠬ࠭摘"))
	l111lll1llll_l1_ = l111lll1llll_l1_.replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ摙"),l1l111_l1_ (u"ࠧࠨ摚")).strip(l1l111_l1_ (u"ࠨࠢࠪ摛"))
	l111lll1llll_l1_ = l111lll1llll_l1_.replace(l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ摜"),l1l111_l1_ (u"ࠪࠤࠬ摝")).replace(l1l111_l1_ (u"ࠫࠥࠦࠠࠨ摞"),l1l111_l1_ (u"ࠬࠦࠧ摟")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ摠"),l1l111_l1_ (u"ࠧࠡࠩ摡"))
	message = l1l111_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ摢")+l1llll1lllll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ摣")+mode+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ摤")+l111lll1llll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ摥")
l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ摦"),l11lllll1l_l1_(l1ll1_l1_)+message)
l1lll11l1111_l1_ = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ摧"))
l111l1ll11l_l1_ = False if l1lll11l1111_l1_==l1l11l1111l_l1_ else True
if not l111l1ll11l_l1_ and l1lll11lllll_l1_ in [235,715]:
	l1l1ll1l11l1_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ摨")])
	l1ll1_l1_ = l1l111_l1_ (u"ࠨ࡫ࡳࡸࡻ࠭摩") if l1lll11lllll_l1_==235 else l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠭摪")
	l11ll1l1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࠧ摫")+l1ll1_l1_+l1l111_l1_ (u"ࠫ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ摬")+l1l1ll1l11l1_l1_)
	l11lll1lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࠩ摭")+l1ll1_l1_+l1l111_l1_ (u"࠭࠮ࡳࡧࡩࡩࡷ࡫ࡲࡠࠩ摮")+l1l1ll1l11l1_l1_)
	if l11ll1l1ll_l1_ or l11lll1lll_l1_:
		url += l1l111_l1_ (u"ࠧࡽࠩ摯")
		if l11ll1l1ll_l1_: url += l1l111_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ摰")+l11ll1l1ll_l1_
		if l11lll1lll_l1_: url += l1l111_l1_ (u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ摱")+l11lll1lll_l1_
		url = url.replace(l1l111_l1_ (u"ࠪࢀࠫ࠭摲"),l1l111_l1_ (u"ࠫࢁ࠭摳"))
	l11l11ll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࠩ摴")+l1ll1_l1_+l1l111_l1_ (u"࠭࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ摵")+l1l1ll1l11l1_l1_)
	if l11l11ll1l_l1_:
		l111llll1111_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ摶"),url,re.DOTALL)
		url = url.replace(l111llll1111_l1_[0],l11l11ll1l_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll11ll1l_l1_,l1111l1l1l1_l1_,l1lll1l1ll1l_l1_
	l111l11l1ll_l1_ = l1l111_l1_ (u"ࠨࠩ摷")
	l11ll11ll1l_l1_(l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ摸"))
	try: l1111l1l1l1_l1_(l1lll11l111_l1_,l1llll1lllll_l1_)
	except Exception as error: l111l11l1ll_l1_ = traceback.format_exc()
	l1lll1l1ll1l_l1_(l111l11l1ll_l1_)
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ⨸")
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ⨹"):l1l111_l1_ (u"ࠩࠪ⨺")}
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡋࡎ࠲ࡠࠩ⨻")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫࡼࡽࡥࠨ⨼")]
def l11l1ll_l1_(mode,url,text):
	if   mode==590: l1lll_l1_ = l1l1l11_l1_()
	elif mode==591: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==592: l1lll_l1_ = PLAY(url)
	elif mode==593: l1lll_l1_ = l1111lll1_l1_(url,text)
	elif mode==599: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_ = l111l1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⨽"),l1l11ll_l1_,l1l111_l1_ (u"࠭ࠧ⨾"),l1l111_l1_ (u"ࠧࠨ⨿"),l1l111_l1_ (u"ࠨࠩ⩀"),l1l111_l1_ (u"ࠩࠪ⩁"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⩂"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩃"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⩄"),l1l11ll_l1_,599,l1l111_l1_ (u"࠭ࠧ⩅"),l1l111_l1_ (u"ࠧࠨ⩆"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⩇"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⩈"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⩉"),l1l111_l1_ (u"ࠫࠬ⩊"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⩋"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧ⩌"),l1l11ll_l1_,591,l1l111_l1_ (u"ࠧࠨ⩍"),l1l111_l1_ (u"ࠨࠩ⩎"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠵ࠬ⩏"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⩐"),html,re.DOTALL)
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩑"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⩒")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"࠭ࠧ⩓"),l1l111_l1_ (u"ࠧࠨ⩔"),l1l111_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠳ࠪ⩕"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⩖"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⩗"),l1l111_l1_ (u"ࠫࠬ⩘"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡨࡦࡣࡧࡩࡷ࠳ࡳࡰࡥ࡬ࡥࡱ࠭⩙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llll1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫ࠣࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ⩚"),block,re.DOTALL)
		for l1llll1llll_l1_ in l1llll1ll1l_l1_:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⩛"),l1llll1llll_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭⩜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩝"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⩞")+l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠫࠬ⩟"),l1l111_l1_ (u"ࠬ࠭⩠"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨ⩡"))
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⩢")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⩣"),url,l1l111_l1_ (u"ࠩࠪ⩤"),l1l111_l1_ (u"ࠪࠫ⩥"),l1l111_l1_ (u"ࠫࠬ⩦"),l1l111_l1_ (u"ࠬ࠭⩧"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⩨"))
	html = response.content
	l1llll11ll1_l1_ = 0
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡣࡵࡧ࡭࡯ࡶࡦ࠯ࡶࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯࠼ࡩ࠶ࡁࠫ⩩"),html,re.DOTALL)
	if l11ll11_l1_: l1l1l1l_l1_ = l11ll11_l1_[0]
	else: l1l1l1l_l1_ = l1l111_l1_ (u"ࠨࠩ⩪")
	if type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠵ࠬ⩫"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸࡲࡩࡥࡧࡵ࠱ࡨࡧࡲࡰࡷࡶࡩࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࡀࠪ⩬"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡳ࡭࡫ࡧࡩࡷ࠳ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⩭"),block,re.DOTALL)
		l11ll1l11_l1_,l11l11_l1_,l1ll_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨ⩮"):
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ⩯"),l1l1l1l_l1_,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ⩰"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ⩱"),l1l111_l1_ (u"ࠩ࠲ࠫ⩲")).replace(l1l111_l1_ (u"ࠪࡠࡡࠨࠧ⩳"),l1l111_l1_ (u"ࠫࠧ࠭⩴"))]
	elif type==l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠸ࠧ⩵") and l1l111_l1_ (u"࠭ࡨࡳࡧࡩࠫ⩶") in l1l1l1l_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡪ࠷ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡁࠫ⩷"),html,re.DOTALL)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩸"),l1lllll_l1_+l1l111_l1_ (u"่้ࠩ๏ุษࠨ⩹"),url,591,l1l111_l1_ (u"ࠪࠫ⩺"),l1l111_l1_ (u"ࠫࠬ⩻"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨ⩼"))
		title = l11llll_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⩽"),l1lllll_l1_+title,url,591,l1l111_l1_ (u"ࠧࠨ⩾"),l1l111_l1_ (u"ࠨࠩ⩿"),l1l111_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠶ࠫ⪀"))
		return
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࡄࠧ⪁"),html,re.DOTALL)
		title,block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩ⪂"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ⪃"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ⪄"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭⪅"),l1l111_l1_ (u"ࠨๅ็๎อ࠭⪆"),l1l111_l1_ (u"ࠩส฽้อๆࠨ⪇"),l1l111_l1_ (u"๋ࠪิอแࠨ⪈"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ⪉"),l1l111_l1_ (u"ࠬ฿ัืࠩ⪊"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭⪋"),l1l111_l1_ (u"ࠧศๆห์๊࠭⪌"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨ⪍"),l1l111_l1_ (u"ࠩะ่็ฯࠧ⪎")]
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ⪏"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧ⪐"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⪑") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⪒"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠧࠨ⪓"):
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⪔")+l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⪕"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⪖"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪗"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⪘"):
		l111l1llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ⪙"),block,re.DOTALL)
		if l111l1llll_l1_:
			count = l111l1llll_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ⪚")+count
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⪛"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ⪜"),l1ll1ll_l1_,591,l1l111_l1_ (u"ࠪࠫ⪝"),l1l111_l1_ (u"ࠫࠬ⪞"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⪟"))
	elif l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹࠧ⪠") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⪡"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⪢"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⪣")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪤"),l1lllll_l1_+title,l1ll1ll_l1_,591,l1l111_l1_ (u"ࠫࠬ⪥"),l1l111_l1_ (u"ࠬ࠭⪦"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠴ࠨ⪧"))
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⪨")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⪩"),url,l1l111_l1_ (u"ࠩࠪ⪪"),l1l111_l1_ (u"ࠪࠫ⪫"),l1l111_l1_ (u"ࠫࠬ⪬"),l1l111_l1_ (u"ࠬ࠭⪭"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⪮"))
	html = response.content
	l111lllll1_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡵࡨࡥࡸࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡨࡥࡸࡵ࡮ࡴࡀࠪ⪯"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ⪰"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭⪱"))
				l111lllll1_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪲"),l1lllll_l1_+title,l1ll1ll_l1_,593,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ⪳"),l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⪴"))
	if type==l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⪵") or not l111lllll1_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡤ࡮ึ࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠦࡃࡂ࠯ࡣ࡭ࡁࠫ⪶"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࠩ⪷")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࡱࡲ࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡣ࡯ࡰ࠲࡫ࡰࡪࡵࡲࡨࡪࡹ࠾ࠨ⪸"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⪹"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⪺"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⪻"),l1lllll_l1_+title,l1ll1ll_l1_,592,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1llll1l1ll_l1_,l1llll1lll1_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⪼"),url,l1l111_l1_ (u"ࠧࠨ⪽"),l1l111_l1_ (u"ࠨࠩ⪾"),l1l111_l1_ (u"ࠩࠪ⪿"),l1l111_l1_ (u"ࠪࠫ⫀"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⫁"))
	html = response.content
	l1llll1l111_l1_ = re.findall(l1l111_l1_ (u"ࠬอไฺ็ิࠤ࠿࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ⫂"),html,re.DOTALL)
	if l1llll1l111_l1_ and l11111l_l1_(l1ll1_l1_,url,l1llll1l111_l1_): return
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⫃"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ⫄"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡰ࡮ࡩࡥ࠮ࡶ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⫅"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ⫆"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ⫇"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⫈")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⫉"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡥࡱࡺࡲࡱࡵࡡࡥࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷࡃ࠭⫊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⫋"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⫌")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⫍"))
	for l1llll1l1l1_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1llll1l1l1_l1_.split(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࠪ⫎"))
		if l1ll1ll_l1_ not in l1llll1l1ll_l1_:
			l1llll1l1ll_l1_.append(l1ll1ll_l1_)
			l1llll1lll1_l1_.append(l1llll1l1l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll1lll1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⫏"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭⫐"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ⫑"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ⫒"),l1l111_l1_ (u"ࠨ࠭ࠪ⫓"))
	l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ⫔")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠹ࠬ⫕"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䢃")
l1l11l11l111_l1_ = []
headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䢄"):l1l111_l1_ (u"ࠨࠩ䢅")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䢆"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡦࡪࡰࡧ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࡷࠥࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪ䢇")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࠣࡘࡾࡶࡥ࠻ࠢ࡞ࠤࠬ䢈")+type+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䢉"))
		l1l111111l11_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ䢊"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ䢋"),l1l111_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ䢌"))
		datetime = time.strftime(l1l111_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏࠪ䢍"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ䢎")+l1l11l1111l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠩ䢏")+str(kodi_version)
		message = l1l111_l1_ (u"ࠬ࠭䢐")
		if key not in list(l1l111111l11_l1_.keys()): l1l111111l11_l1_[key] = [line]
		else:
			if url not in str(l1l111111l11_l1_[key]): l1l111111l11_l1_[key].append(line)
			else: message = l1l111_l1_ (u"࠭࡜࡯๊ࠢิฬࠦวๅใํำ๏๎ࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡษ็ๅ๏ี๊้้สฮࠥอไห์่๊ࠣࠦสฺ็็ࠫ䢑")
		total = 0
		for key in list(l1l111111l11_l1_.keys()):
			l1l111111l11_l1_[key] = list(set(l1l111111l11_l1_[key]))
			total += len(l1l111111l11_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䢒"),l1l111_l1_ (u"ࠨࠩ䢓"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䢔"),l1l111_l1_ (u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫ䢕")+message+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠢ็่฾๊ๅࠡษ็ฬึ์วๆฮࠣ๎็๎ๅࠡสฯ้฾ࠦโศศ่อࠥฮวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤ๏าฯࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ์ุ๎แࠡ์฼ี฻ูࠦๅ์ๆࠤฬ๊ศา่ส้ัࠦร็ࠢอีุ๊่ࠠา๊ࠤฬ๊โศศ่อࠥหไ๊ࠢส่๊ฮัๆฮࠣ฽๋ีๅศࠢํูอำฺࠠัา๋ฬࠦ࠵ࠡใํำ๏๎็ศฬࠪ䢖")+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ䢗")+l1l111_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣห้่วว็ฬࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠩ䢘")+str(total))
		if total>=5:
			l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨ䢙"),l1l111_l1_ (u"ࠨࠩ䢚"),l1l111_l1_ (u"ࠩࠪ䢛"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䢜"),l1l111_l1_ (u"ࠫฬ๊ศา่ส้ัࠦฬๆ฻ࠣๆฬฬๅสࠢไ๎์อࠠ࠶ࠢไ๎ิ๐่่ษอࠤ้๋๋ࠠฮาࠤฬ๊ศา่ส้ัࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤุ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศๆีะࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡวิืฬ๊่ࠠา๊ࠤฬ๊โศศ่อ่ࠥศๅ่ࠢืาํวࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎็๎ๅࠡษ็้อืๅอࠢหๅา฻่ࠠา๊ࠤฬ๊แ๋ัํ์์อสࠡมࠤࠥࠬ䢝"))
			if l1llll111l_l1_==1:
				l1l111111ll1_l1_ = l1l111_l1_ (u"ࠬ࠭䢞")
				for key in list(l1l111111l11_l1_.keys()):
					l1l111111ll1_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠩ䢟")+key
					l1l11ll111ll_l1_ = sorted(l1l111111l11_l1_[key],reverse=False,key=lambda l11lllll1l1l_l1_: l11lllll1l1l_l1_[0])
					for datetime,url in l1l11ll111ll_l1_:
						l1l111111ll1_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࠪ䢠")+datetime+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭䢡")+l111l11_l1_(url)
					l1l111111ll1_l1_ += l1l111_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䢢")
				import l1l11lllll1_l1_
				succeeded = l1l11lllll1_l1_.l11l1l11l1l_l1_(l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࡵࠪ䢣"),l1l111_l1_ (u"ࠫࠬ䢤"),False,l1l111_l1_ (u"ࠬ࠭䢥"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䢦"),l1l111_l1_ (u"ࠧࠨ䢧"),l1l111111ll1_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䢨"),l1l111_l1_ (u"ࠩࠪ䢩"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䢪"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ䢫"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䢬"),l1l111_l1_ (u"࠭ࠧ䢭"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䢮"),l1l111_l1_ (u"ࠨใื่ฯูࠦๆๆํอࠥอไฦำึห้࠭䢯"))
			if l1llll111l_l1_!=-1:
				l1l111111l11_l1_ = {}
				l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䢰"),l1l111_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䢱"))
		if l1l111111l11_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䢲"),l1l111_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䢳"),l1l111111l11_l1_,l1ll111l1ll_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11llll1l1ll_l1_(l1ll11l1_l1_,source)
	l1l11llll1l1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䢴"))
	l11lllll11l1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䢵"))
	l1l1l1111lll_l1_ = len(l1llll_l1_)-l1l11llll1l1_l1_-l11lllll11l1_l1_
	l1l11111l1ll_l1_ = l1l111_l1_ (u"ࠨ็ืห์ีษ࠻ࠩ䢶")+str(l1l11llll1l1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࠦสฮ็ํ่࠿࠭䢷")+str(l11lllll11l1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࠠฤะิํ࠿࠭䢸")+str(l1l1l1111lll_l1_)
	if not l1llll_l1_: result,l1l1l111l11l_l1_ = l1l111_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䢹"),l1l111_l1_ (u"ࠬ࠭䢺")
	else:
		add = 0
		l1l111l1l1ll_l1_ = [l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䢻"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ䢼"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ䢽"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ䢾"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ䢿"),l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ䣀"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ䣁"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ䣂"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䣃"),l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ䣄")]
		if not any(value in source for value in l1l111l1l1ll_l1_):
			add = 1
			l1llll_l1_ = [l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡢࡅࡑࡒ࡟ࡍࡋࡑࡏࡘ࠭䣅")]+list(l1llll_l1_)
			l1l1lll1_l1_ = [l1l111_l1_ (u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨ䣆")]+list(l1l1lll1_l1_)
		while True:
			l1l1l111l11l_l1_,result = l1l111_l1_ (u"ࠫࠬ䣇"),l1l111_l1_ (u"ࠬ࠭䣈")
			l11l11l_l1_ = l1ll11ll_l1_(l1l11111l1ll_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ䣉")
			elif add and l11l11l_l1_==0:
				result = l1l111_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ䣊")
				l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠨࠩ䣋"),l1l111_l1_ (u"ࠩࠪ䣌"),l1l111_l1_ (u"ࠪࠫ䣍"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䣎"),l1l111_l1_ (u"ࠬะอั์ิࠤ࠳࠴่ࠠา๊ࠤฬู๊ๆๆํอࠥออห็ส่ࠥะำษสู้ࠣอใๅࠢไ๎ࠥอไฦ่อี๋ะࠠฤ๊ࠣๅ๏ࠦวๅฮ๊หืࠦร้ࠢไ๎ࠥอไษำ้ห๊าࠠๅล้๋ฬࠦสโฬะࠤฺ็อศฬࠣ์๏ฮࠠไอํีฮࠦแ๋้ࠢๅุࠦวๅ๊ๅฮࠥ๎ศฺุุࠣึ้วหࠢอึํ๐ฯࠡษ็ษ๋ะั็ฬࠣ๎฾ะศา๊๊ࠤ๋๎ูࠡ็้ࠤศ์่ศ฻ࠣห้ํฬ้็ࠣ฽้๏ࠠๆ๊สๆ฾ࠦวๅว้ฮึ์สࠡ࠰࠱ࠤ้ึวࠡ์ฯฬࠥอไหไ็๎้ࠦๅ็ࠢสืฯิฯศ็๋ࠣีํࠠศๆ฼้้๐ษ๊ࠡฦ๎฻อࠠศๆศฬ฼อมࠡใํࠤฬูสฯัส้์อࠠษฬิ็ࠥ๎โหูࠢหห฿ࠠษ์้ࠤฺ่๊ࠠ็็๎ฮ่ࠦฤะิํࠥ࠴࠮๊ࠡส่๊ฮัๆฮ่ࠣฬ๊ࠦหฯ่่ࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็ุ้ส่ๅ์ฬࠤอูศษࠢสืฯิฯศ็๋ࠣีํࠠศๆ฼้้๐ษ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ษࠣห้ศๆࠡมࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䣏"))
				if l1llll111l_l1_==1:
					l1lll_l1_ = l1l111llll11_l1_(l1l1lll1_l1_[add:],l1llll_l1_[add:],source)
					if l1lll_l1_:
						l1l1lll1_l1_,l1llll_l1_,errors,l11l11_l1_,l1ll_l1_ = zip(*l1lll_l1_)
						l1l11111l1ll_l1_ = l1l111_l1_ (u"࠭วๅีํีๆืวหࠢส่ั๐ฯสࠢࠫࠤࠬ䣐")+str(len(l1llll_l1_))+l1l111_l1_ (u"ࠧࠡࠫࠪ䣑")
						add = 0
						continue
			else:
				l1lll_l1_ = l1l111llll11_l1_([l1l1lll1_l1_[l11l11l_l1_]],[l1llll_l1_[l11l11l_l1_]],source)
				if l1lll_l1_:
					title,l1ll1ll_l1_,errors,l11l11_l1_,l1ll_l1_ = l1lll_l1_[0]
					if l1l111_l1_ (u"ࠨีํีๆืࠧ䣒") in title and l1l111_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ䣓") in title:
						l1l111111l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䣔"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ䣕")+title+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ䣖")+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䣗"))
						import l1l11lllll1_l1_
						l1l11lllll1_l1_.l11llll1ll1l_l1_()
						result = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䣘")
					else:
						l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䣙"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ䣚")+title+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䣛")+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ䣜"))
						result,l1l1l111l11l_l1_,l1ll11l111l1_l1_ = l1l111ll1l1l_l1_(title,l1ll1ll_l1_,errors,l11l11_l1_,l1ll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䣝"),l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䣞"),l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ䣟"),l1l111_l1_ (u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ䣠"),l1l111_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠶ࡹࡴࡠ࡯ࡨࡲࡺ࠭䣡")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ䣢"),l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ䣣"),l1l111_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ䣤")]: break
			elif result not in [l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䣥"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䣦")]:
				if l1l111_l1_ (u"ࠨ࡞ࡱࠫ䣧") in l1l1l111l11l_l1_: l1l1l111l11l_l1_ = l1l111_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ䣨")+l1l1l111l11l_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭䣩"),l1l111_l1_ (u"ࠫࡡࡴ࡛ࡍࡇࡉࡘࡢ࠭䣪"))
				l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䣫"),l1l111_l1_ (u"࠭ࠧ䣬"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣭"),l1l111_l1_ (u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࠫ䣮")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ䣯")+l1l1l111l11l_l1_,profile=l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ䣰"))
	if result==l1l111_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䣱") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䣲"),l1l111_l1_ (u"࠭ࠧ䣳"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣴"),l1l111_l1_ (u"ࠨีํีๆื่ࠠาสࠤฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้ࠦฬาสࠣๅ๏ี๊้ࠢ฽๎ึํࠧ䣵")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ䣶")+l1l1l111l11l_l1_,profile=l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ䣷"))
	elif result in [l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䣸"),l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭䣹")] and l1l1l111l11l_l1_!=l1l111_l1_ (u"࠭ࠧ䣺"): l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䣻"),l1l111_l1_ (u"ࠨࠩ䣼"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䣽"),l1l1l111l11l_l1_,profile=l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ䣾"))
	return result
def l1l111llll11_l1_(l111llll11_l1_,l1ll11l1_l1_,source):
	global l1l111ll1lll_l1_
	l1l111ll1lll_l1_,l1lll_l1_,threads,new = [],[],[],[]
	l1lll1l1ll1_l1_(False,False)
	for l1l11l1ll1l_l1_ in range(len(l1ll11l1_l1_)):
		l1l111ll1lll_l1_.append(None)
		title = l111llll11_l1_[l1l11l1ll1l_l1_]
		l1ll1ll_l1_ = l1ll11l1_l1_[l1l11l1ll1l_l1_].split(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䣿"),1)[0]
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ䤀")).strip(l1l111_l1_ (u"࠭ࠦࠨ䤁")).strip(l1l111_l1_ (u"ࠧࡀࠩ䤂")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䤃"))
		if l1l11l1ll1l_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩไัฺࠦำ๋ำไีࠥืโๆࠢࠣࠫ䤄")+str(l1l11l1ll1l_l1_),title)
		l1l11lll1l1l_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䤅"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉ࠭䤆"),l1ll1ll_l1_)
		if l1l11lll1l1l_l1_:
			l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll1l1l_l1_
			l1l111ll1lll_l1_[l1l11l1ll1l_l1_] = title,l1ll1ll_l1_,l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
		else:
			thread = threading.Thread(target=l11lllll1lll_l1_,args=(l1ll1ll_l1_,source,title,l1l11l1ll1l_l1_))
			thread.start()
			time.sleep(5)
			threads.append(thread)
			new.append(l1l11l1ll1l_l1_)
	for thread in threads: thread.join(30)
	for l1l11l1ll1l_l1_ in range(len(l1ll11l1_l1_)):
		title,l1ll1ll_l1_,l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1lll_l1_[l1l11l1ll1l_l1_]
		if l1llll_l1_: l1lll_l1_.append([title,l1ll1ll_l1_,l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_])
		if l1l11l1ll1l_l1_ in new: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊࠧ䤇"),l1ll1ll_l1_,[l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_],l11l1l1_l1_)
	l1lll1l1ll1_l1_(None,None)
	return l1lll_l1_
def l1l111ll1l1l_l1_(title,l1ll1ll_l1_,l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_,source,type=l1l111_l1_ (u"࠭ࠧ䤈")):
	if l1l1l111l11l_l1_==l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䤉"): return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ䤊"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ䤋")
			else:
				l1l1l1l111ll_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䤌"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡵࡨࡰࡪࡩࡴࡦࡦࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪ䤍")+title+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䤎")+str(l1l1l1l111ll_l1_)+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䤏"))
				if l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ䤐") in l1l1l1l111ll_l1_ and l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ䤑") in l1l1l1l111ll_l1_:
					l1l1l1l11ll1_l1_,l1l1llll1ll1_l1_,l1ll11l111l1_l1_ = l1l1111ll111_l1_(l1l1l1l111ll_l1_)
					if l1ll11l111l1_l1_: l1l1l1l111ll_l1_ = l1ll11l111l1_l1_[0]
					else: l1l1l1l111ll_l1_ = l1l111_l1_ (u"ࠩࠪ䤒")
				if not l1l1l1l111ll_l1_: result = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䤓")
				else: result = l1llll111_l1_(l1l1l1l111ll_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ䤔"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭䤕"),l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䤖")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䤗"),l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䤘"),l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ䤙")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䤚"),l1l111_l1_ (u"ࠫࠬ䤛"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䤜"),l1l111_l1_ (u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ䤝"))
	else:
		result = l1l111_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䤞")
		l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(l1ll1ll_l1_)
		if l11ll1l1l1_l1_: result = l1llll111_l1_(l1ll1ll_l1_,source,type)
	return result,l1l1l111l11l_l1_,l1llll_l1_
def l1l111l1ll11_l1_(url,source):
	l1lllll1_l1_,l1l11l1l1lll_l1_,server,l11lllll1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"ࠨࠩ䤟"),l1l111_l1_ (u"ࠩࠪ䤠"),l1l111_l1_ (u"ࠪࠫ䤡"),l1l111_l1_ (u"ࠫࠬ䤢"),l1l111_l1_ (u"ࠬ࠭䤣"),l1l111_l1_ (u"࠭ࠧ䤤"),l1l111_l1_ (u"ࠧࠨ䤥")
	if l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䤦") in url:
		l1lllll1_l1_,l1l11l1l1lll_l1_ = url.split(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䤧"),1)
		l1l11l1l1lll_l1_ = l1l11l1l1lll_l1_+l1l111_l1_ (u"ࠪࡣࡤ࠭䤨")+l1l111_l1_ (u"ࠫࡤࡥࠧ䤩")+l1l111_l1_ (u"ࠬࡥ࡟ࠨ䤪")+l1l111_l1_ (u"࠭࡟ࡠࠩ䤫")
		l1l11l1l1lll_l1_ = l1l11l1l1lll_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1lll111llll_l1_ = l1l11l1l1lll_l1_.split(l1l111_l1_ (u"ࠧࡠࡡࠪ䤬"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"ࠨࠩ䤭"): l111l1ll_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ䤮")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠪࡴࠬ䤯"),l1l111_l1_ (u"ࠫࠬ䤰")).replace(l1l111_l1_ (u"ࠬࠦࠧ䤱"),l1l111_l1_ (u"࠭ࠧ䤲"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠧࡀࠩ䤳")).strip(l1l111_l1_ (u"ࠨ࠱ࠪ䤴")).strip(l1l111_l1_ (u"ࠩࠩࠫ䤵"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ䤶"))
	if name: l11lllll1ll1_l1_ = name
	else: l11lllll1ll1_l1_ = server
	l11lllll1ll1_l1_ = l1l111l_l1_(l11lllll1ll1_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䤷"))
	name = name.replace(l1l111_l1_ (u"๋ࠬศศึิࠫ䤸"),l1l111_l1_ (u"࠭ࠧ䤹")).replace(l1l111_l1_ (u"ࠧิ์ิๅึ࠭䤺"),l1l111_l1_ (u"ࠨࠩ䤻")).replace(l1l111_l1_ (u"ࠩส่ࠥ࠭䤼"),l1l111_l1_ (u"ࠪࠤࠬ䤽")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䤾"),l1l111_l1_ (u"ࠬࠦࠧ䤿"))
	l1l11l1l1lll_l1_ = l1l11l1l1lll_l1_.replace(l1l111_l1_ (u"࠭ๅษษืีࠬ䥀"),l1l111_l1_ (u"ࠧࠨ䥁")).replace(l1l111_l1_ (u"ࠨีํีๆืࠧ䥂"),l1l111_l1_ (u"ࠩࠪ䥃")).replace(l1l111_l1_ (u"ࠪห้ࠦࠧ䥄"),l1l111_l1_ (u"ࠫࠥ࠭䥅")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ䥆"),l1l111_l1_ (u"࠭ࠠࠨ䥇"))
	l11lllll1ll1_l1_ = l11lllll1ll1_l1_.replace(l1l111_l1_ (u"ࠧๆสสุึ࠭䥈"),l1l111_l1_ (u"ࠨࠩ䥉")).replace(l1l111_l1_ (u"ࠩึ๎ึ็ัࠨ䥊"),l1l111_l1_ (u"ࠪࠫ䥋")).replace(l1l111_l1_ (u"ࠫฬ๊ࠠࠨ䥌"),l1l111_l1_ (u"ࠬࠦࠧ䥍")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䥎"),l1l111_l1_ (u"ࠧࠡࠩ䥏"))
	return l1lllll1_l1_,l1l11l1l1lll_l1_,server,l11lllll1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11llll1ll_l1_(url,source):
	l1l1l11l11l1_l1_,name,l11l1llll1l_l1_,l1l111l1ll1l_l1_,l1l111l1lll1_l1_,l1l11l11l11l_l1_,l1l1l111lll1_l1_ = l1l111_l1_ (u"ࠨࠩ䥐"),l1l111_l1_ (u"ࠩࠪ䥑"),None,None,None,None,None
	l1lllll1_l1_,l1l11l1l1lll_l1_,server,l11lllll1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111l1ll11_l1_(url,source)
	if l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䥒") in url:
		if   type==l1l111_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ䥓"): type = l1l111_l1_ (u"ࠬࠦࠧ䥔")+l1l111_l1_ (u"࠭ๅโุ็ࠫ䥕")
		elif type==l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭䥖"): type = l1l111_l1_ (u"ࠨࠢࠪ䥗")+l1l111_l1_ (u"ࠩࠨู้อ็ะหࠪ䥘")
		elif type==l1l111_l1_ (u"ࠪࡦࡴࡺࡨࠨ䥙"): type = l1l111_l1_ (u"ࠫࠥ࠭䥚")+l1l111_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ䥛")
		elif type==l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ䥜"): type = l1l111_l1_ (u"ࠧࠡࠩ䥝")+l1l111_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ䥞")
		elif type==l1l111_l1_ (u"ࠩࠪ䥟"): type = l1l111_l1_ (u"ࠪࠤࠬ䥠")+l1l111_l1_ (u"ࠫࠪࠫࠥࠦࠩ䥡")
		if l111lll_l1_!=l1l111_l1_ (u"ࠬ࠭䥢"):
			if l1l111_l1_ (u"࠭࡭ࡱ࠶ࠪ䥣") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠧࠦࠩ䥤")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"ࠨࠢࠪ䥥")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠩࠪ䥦"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭䥧")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠫࠥ࠭䥨")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䥩")		in source: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䥪")		in source: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭䥫")
	elif l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ䥬")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ䥭")	in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䥮")		in source: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䥯")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯ࠫ䥰")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭䥱")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䥲")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䥳")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ䥴")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠪๅัืࠧ䥵")			in name:   l11l1llll1l_l1_	= l1l111_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䥶")
	elif l1l111_l1_ (u"ࠬ็ไิูํ๊ࠬ䥷")		in name:   l11l1llll1l_l1_	= l1l111_l1_ (u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䥸")
	elif l1l111_l1_ (u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧ䥹")		in l1lllll1_l1_:   l11l1llll1l_l1_	= l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ䥺")
	elif l1l111_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䥻")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ䥼")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䥽")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭䥾")		in name:   l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䥿")	in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䦀")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ䦁")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠩࡷࡺࡰࡹࡡࠨ䦂")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ䦃")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭䦄")		in server: l11l1llll1l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ䦅")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨ䦆")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ䦇")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ䦈")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ䦉")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ䦊")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ䦋")	 	in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䦌")
	elif l1l111_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭䦍")	 	in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ䦎")
	elif l1l111_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭䦏")	in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭䦐")
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ䦑")		in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭䦒")
	elif l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䦓")		in server: l11l1llll1l_l1_	= l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ䦔")
	elif l1l111_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䦕")		in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䦖")
	elif l1l111_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ䦗")	in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䦘")
	elif l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ䦙")	in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱࠬ䦚")
	elif l1l111_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ䦛")		in server: l11l1llll1l_l1_	= l1l111_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ䦜")
	elif l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䦝")	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ䦞")
	elif l1l111_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䦟")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䦠")
	elif l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䦡")	 	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"࠭ࡣࡢࡶࡦ࡬ࠬ䦢")
	elif l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ䦣")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ䦤")
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䦥")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䦦")
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ䦧")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫ䦨")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"࠭࡭ࡺࡸ࡬࡭ࡩ࠭䦩")		in server: l1l11l11l11l_l1_	= l11lllll1ll1_l1_
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ䦪")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ䦫")
	elif l1l111_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䦬")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ䦭")
	elif l1l111_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭䦮") 	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䦯")
	elif l1l111_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䦰")	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ䦱")
	elif l1l111_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭䦲")	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ䦳")
	elif l1l111_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䦴") 	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ䦵")
	elif l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䦶")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ䦷")
	elif l1l111_l1_ (u"ࠧࡶࡲࡳࠫ䦸") 			in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ䦹")
	elif l1l111_l1_ (u"ࠩࡸࡴࡧ࠭䦺") 			in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ䦻")
	elif l1l111_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䦼") 		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䦽")
	elif l1l111_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䦾") 	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ䦿")
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䧀")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䧁")
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䧂") 		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䧃")
	elif l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䧄") 	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ䧅")
	elif l1l111_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䧆")	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ䧇")
	elif l1l111_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭䧈")	in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ䧉")
	elif l1l111_l1_ (u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫ䧊")		in server: l1l111l1ll1l_l1_	= l1l111_l1_ (u"ࠬ࡮ࡤ࠮ࡥࡧࡲࠬ䧋")
	if   l11l1llll1l_l1_:	l1l1l11l11l1_l1_,name = l1l111_l1_ (u"࠭ฮศืࠪ䧌"),l11l1llll1l_l1_
	elif l1l11l11l11l_l1_:		l1l1l11l11l1_l1_,name = l1l111_l1_ (u"ࠧࠦ็ะำิ࠭䧍"),l1l11l11l11l_l1_
	elif l1l111l1ll1l_l1_:		l1l1l11l11l1_l1_,name = l1l111_l1_ (u"ࠨࠧࠨ฽ฬ๋ࠠๆ฻ิ์ๆ࠭䧎"),l1l111l1ll1l_l1_
	elif l1l111l1lll1_l1_:	l1l1l11l11l1_l1_,name = l1l111_l1_ (u"ࠩࠨࠩࠪ฿วๆࠢัหึา๊ࠨ䧏"),l1l111l1lll1_l1_
	elif l1l1l111lll1_l1_:	l1l1l11l11l1_l1_,name = l1l111_l1_ (u"ฺࠪࠩࠪࠫࠥษ่ࠤำอัอ์ࠪ䧐"),l11lllll1ll1_l1_
	else:			l1l1l11l11l1_l1_,name = l1l111_l1_ (u"ࠫࠪࠫࠥࠦࠧ฼ห๊ࠦๅอ้๋่ࠬ䧑"),l11lllll1ll1_l1_
	return l1l1l11l11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l11l111111_l1_(url,source):
	l1lllll1_l1_,l1l11l11l11l_l1_,server,l11lllll1ll1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l111l1ll11_l1_(url,source)
	if   l1l111_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䧒")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䧓")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ䧔")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ䧕")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ䧖")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ䧗")		in source: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭䧘")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11lll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨ䧙")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭䧚")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11ll111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ䧛")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ䧜")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llll111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ䧝")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ䧞")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ䧟")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧ䧠")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111l1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ䧡")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1lll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ䧢")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡳࡴ࡬ࡰࡳࡱࠪ䧣")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1llll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ䧤")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡺࡸ࠺ࡵࠨ䧥")			in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1l11l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䧦")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllll1111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠭䧧")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭࡮ࡦࡹࡦ࡭ࡲࡧࠧ䧨")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lllllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࠲ࡲࡩࡨࡪࡷࠫ䧩")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ䧪")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䧫")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll11ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ䧬")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1llllll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ䧭")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䧮")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨ䧯")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ䧰")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ䧱"),[l1l111_l1_ (u"ࠩࠪ䧲")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ䧳")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111llll1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䧴")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ䧵")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l11111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䧶") 		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䧷"),[l1l111_l1_ (u"ࠨࠩ䧸")],[l1lllll1_l1_]
	else: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䧹"),[l1l111_l1_ (u"ࠪࠫ䧺")],[l1lllll1_l1_]
	return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l11lll_l1_(url,source):
	l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111l1l1_l1_(url)
	if l1llll_l1_: return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠣࡊࡦ࡯࡬ࡦࡦࠪ䧻"),[],[]
def l1l111l11ll1_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䧼"))
	l1llll_l1_ = []
	if   l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࠬ䧽")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1llll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧ䧾")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1llll1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵࠧ䧿") in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111111ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ䨀")	in url   : l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䨁")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l111l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䨂")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll111_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭䨃")		in url   : l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1llll1ll11_l1_(url)
	elif l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ䨄")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l11_l1_(url)
	elif l1l111_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䨅")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111l1l_l1_(url)
	elif l1l111_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ䨆")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l1111l11_l1_(url)
	elif l1l111_l1_ (u"ࠩࡨ࠹ࡹࡹࡡࡳࠩ䨇")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1llll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䨈")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l11_l1_(url)
	elif l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ䨉")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll1l11_l1_(url)
	elif l1l111_l1_ (u"ࠬࡻࡰࡣࡣࡰࠫ䨊") 		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࠧ䨋"),[l1l111_l1_ (u"ࠧࠨ䨌")],[url]
	elif l1l111_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ䨍") 	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1111l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ䨎")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11111l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䨏") 	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11111ll1l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䨐")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡻࡰࡣࠩ䨑") 			in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l1l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡲࠪ䨒") 			in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l1l1l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䨓") 		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l11l1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ䨔") 	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䨕")		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l1ll11l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䨖") 		in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1ll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䨗") 	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11lll11ll_l1_(url)
	elif l1l111_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ䨘")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1lll1_l1_(url)
	elif l1l111_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䨙")	in server: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11111ll_l1_(url)
	if l1llll_l1_: return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸ࠦࡆࡢ࡫࡯ࡩࡩ࠭䨚"),[],[]
def l1l111ll1111_l1_(l1l111l111ll_l1_,url,source):
	l1l1l111lll1_l1_ = l1l111_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧ䨛")
	try: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11lll_l1_(url,source)
	except: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࠪ䨜"),[],[]
	l1llll_l1_ = l1l111l111l1_l1_(l1llll_l1_)
	if l1l1l111l11l_l1_==l1l111_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䨝"): return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䨞") in l1l1l111l11l_l1_:
		l1l111l111ll_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠠࠨ䨟")+l1l1l111l11l_l1_
		l1l1l111lll1_l1_ = l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬ䨠")
		try: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11ll1_l1_(url,source)
		except: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䨡"),[],[]
		l1llll_l1_ = l1l111l111l1_l1_(l1llll_l1_)
		if l1l1l111l11l_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨢"): return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ䨣") in l1l1l111l11l_l1_:
			l1l111l111ll_l1_ += l1l111_l1_ (u"ࠪࡠࡳࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠤࠥ࠭䨤")+l1l1l111l11l_l1_
			l1l1l111lll1_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠶ࠪ䨥")
			try: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1l1l1_l1_(url,source)
			except: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬ࠭䨦"),[],[]
			l1llll_l1_ = l1l111l111l1_l1_(l1llll_l1_)
			if l1l1l111l11l_l1_==l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䨧"): return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠹࠭䨨") in l1l1l111l11l_l1_:
				l1l111l111ll_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠴࠻ࠢࠣࠫ䨩")+l1l1l111l11l_l1_
				l1l1l111lll1_l1_ = l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨ䨪")
				try: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l1l11l_l1_(url,source)
				except: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䨫"),[],[]
				l1llll_l1_ = l1l111l111l1_l1_(l1llll_l1_)
				if l1l1l111l11l_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨬"): return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫ䨭") in l1l1l111l11l_l1_:
					l1l111l111ll_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠺ࡀࠠࠡࠩ䨮")+l1l1l111l11l_l1_
	return l1l1l111lll1_l1_,l1l111l111ll_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l111l111l1_l1_(l1l1lllll1l1_l1_):
	if l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䨯") in str(type(l1l1lllll1l1_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1lllll1l1_l1_:
			if l1l111_l1_ (u"ࠨࡵࡷࡶࠬ䨰") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ䨱"),l1l111_l1_ (u"ࠪࠫ䨲")).replace(l1l111_l1_ (u"ࠫࡡࡴࠧ䨳"),l1l111_l1_ (u"ࠬ࠭䨴")).strip(l1l111_l1_ (u"࠭ࠠࠨ䨵"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1lllll1l1_l1_.replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ䨶"),l1l111_l1_ (u"ࠨࠩ䨷")).replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ䨸"),l1l111_l1_ (u"ࠪࠫ䨹")).strip(l1l111_l1_ (u"ࠫࠥ࠭䨺"))
	return l1ll_l1_
def l11lllll1lll_l1_(url,source,title=l1l111_l1_ (u"ࠬ࠭䨻"),seq=0):
	global l1l111ll1lll_l1_
	l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䨼"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡵࡣࡵࡸࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䨽")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ䨾"))
	l1ll1ll_l1_,l1l111l111ll_l1_ = url,l1l111_l1_ (u"ࠩࠪ䨿")
	l1l1l111lll1_l1_ = l1l111_l1_ (u"ࠪࡍࡓ࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠧ䩀")
	try: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111111_l1_(url,source)
	except: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䩁"),[l1l111_l1_ (u"ࠬ࠭䩂")],[url]
	if l1l1l111l11l_l1_==l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䩃"):
		l1l111ll1lll_l1_[seq] = title,url,l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
		return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1l1l111l11l_l1_==l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䩄"):
		l1l111l111ll_l1_ = l1l111_l1_ (u"ࠨࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠶ࡀࠠࠡࡐࡨࡩࡩࠦࡅࡹࡶࡨࡶࡳࡧ࡬ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠪ䩅")
		l1ll1ll_l1_ = l1l111l111l1_l1_(l1llll_l1_)[0]
		l1l1l111lll1_l1_,l1l111l111ll_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111ll1111_l1_(l1l111l111ll_l1_,l1ll1ll_l1_,source)
	elif l1l1l111l11l_l1_: l1l111l111ll_l1_ = l1l111_l1_ (u"ࠩࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪ䩆")+l1l1l111l11l_l1_
	if l1llll_l1_:
		l1llll_l1_ = l1l111l111l1_l1_(l1llll_l1_)
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䩇"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡔࡨࡷࡴࡲࡶࡦࡴ࠽ࠤࡠࠦࠧ䩈")+l1l1l111lll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ䩉")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䩊")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡷ࡯ࡸࡸࡀࠠ࡜ࠢࠪ䩋")+str(l1llll_l1_)+l1l111_l1_ (u"ࠨࠢࡠࠫ䩌"))
	else: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䩍"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ䩎")+url+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䩏")+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡉࡷࡸ࡯ࡳࡵ࠽ࠤࡠࠦࠧ䩐")+l1l111l111ll_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䩑"))
	l1l111l111ll_l1_ = l111l11_l1_(l1l111l111ll_l1_)
	l1l111ll1lll_l1_[seq] = title,url,l1l111l111ll_l1_,l1l1lll1_l1_,l1llll_l1_
	return l1l111l111ll_l1_,l1l1lll1_l1_,l1llll_l1_
def l11llll1l1ll_l1_(l1ll11l111l1_l1_,source):
	l1l1l1l1l1l_l1_ = l1ll1ll1_l1_
	data = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䩒"),l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䩓"),l1ll11l111l1_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l11l1l1ll1_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1ll11l111l1_l1_:
		if l1l111_l1_ (u"ࠩ࠲࠳ࠬ䩔") not in l1ll1ll_l1_: continue
		l1l1l11l11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l11llll1ll_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࠧ䩕"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䩖"))
		l1l11l1l1ll1_l1_.append([l1l1l11l11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l11l1l1ll1_l1_:
		l1l111l11l1l_l1_ = sorted(l1l11l1l1ll1_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11ll11lll_l1_ = []
		for line in l1l111l11l1l_l1_:
			if line not in l11ll11lll_l1_:
				l11ll11lll_l1_.append(line)
		for l1l1l11l11l1_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11ll11lll_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭䩗")
			title = l1l111_l1_ (u"࠭ำ๋ำไีࠬ䩘")+l1l111_l1_ (u"ࠧࠡࠩ䩙")+type+l1l111_l1_ (u"ࠨࠢࠪ䩚")+l1l1l11l11l1_l1_+l1l111_l1_ (u"ࠩࠣࠫ䩛")+l111l1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䩜")+l111lll_l1_+l1l111_l1_ (u"ࠫࠥ࠭䩝")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠬࠦࠧ䩞")+server
			title = title.replace(l1l111_l1_ (u"࠭ࠥࠨ䩟"),l1l111_l1_ (u"ࠧࠨ䩠")).strip(l1l111_l1_ (u"ࠨࠢࠪ䩡")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䩢"),l1l111_l1_ (u"ࠪࠤࠬ䩣")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䩤"),l1l111_l1_ (u"ࠬࠦࠧ䩥")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䩦"),l1l111_l1_ (u"ࠧࠡࠩ䩧"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䩨"),l1ll11l111l1_l1_,data,l1l1l1l1l1l_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l1l111l1l1l1_l1_(url,source):
	l111l11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䩩")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l111l11l1ll_l1_ = str(error)
	if not l1lll_l1_:
		if l111l11l1ll_l1_==l1l111_l1_ (u"ࠪࠫ䩪"):
			l111l11l1ll_l1_ = traceback.format_exc()
			if l111l11l1ll_l1_!=l1l111_l1_ (u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ䩫"): sys.stderr.write(l111l11l1ll_l1_)
		l1l1l111l11l_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠷ࠤࡋࡧࡩ࡭ࡧࡧࠫ䩬")
		l1l1l111l11l_l1_ += l1l111_l1_ (u"࠭ࠠࠨ䩭")+l111l11l1ll_l1_.splitlines()[-1]
		return l1l1l111l11l_l1_,[],[]
	return l1l111_l1_ (u"ࠧࠨ䩮"),[l1l111_l1_ (u"ࠨࠩ䩯")],[l1lll_l1_]
def l1l111l1l11l_l1_(url,source):
	l111l11l1ll_l1_ = l1l111_l1_ (u"ࠩࠪ䩰")
	l1lll_l1_ = False
	try:
		import youtube_dl as l1l1111ll11l_l1_
		l1l11ll11ll1_l1_ = l1l1111ll11l_l1_.YoutubeDL({l1l111_l1_ (u"ࠪࡲࡴࡥࡣࡰ࡮ࡲࡶࠬ䩱"): True})
		l1lll_l1_ = l1l11ll11ll1_l1_.extract_info(url,download=False)
	except Exception as error: l111l11l1ll_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ䩲") not in list(l1lll_l1_.keys()):
		if l111l11l1ll_l1_==l1l111_l1_ (u"ࠬ࠭䩳"):
			l111l11l1ll_l1_ = traceback.format_exc()
			if l111l11l1ll_l1_!=l1l111_l1_ (u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩ䩴"): sys.stderr.write(l111l11l1ll_l1_)
		l1l1l111l11l_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠺ࠦࡆࡢ࡫࡯ࡩࡩ࠭䩵")
		l1l1l111l11l_l1_ += l1l111_l1_ (u"ࠨࠢࠪ䩶")+l111l11l1ll_l1_.splitlines()[-1]
		return l1l1l111l11l_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ䩷")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ䩸")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䩹")])
		return l1l111_l1_ (u"ࠬ࠭䩺"),l1l1lll1_l1_,l1llll_l1_
def l1l11ll111l1_l1_(url):
	if l1l111_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䩻") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠧࠨ䩼"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࠸࡛࠸ࠨ䩽"),[],[]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䩾"),[l1l111_l1_ (u"ࠪࠫ䩿")],[url]
def l1ll11lll11_l1_(url):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧ䪀") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䪁"),url,l1l111_l1_ (u"࠭ࠧ䪂"),l1l111_l1_ (u"ࠧࠨ䪃"),False,l1l111_l1_ (u"ࠨࠩ䪄"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫ䪅"))
		if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䪆") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䪇")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䪈"))
			l111llll11_l1_.append(server)
	elif l1l111_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ䪉") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪊"),url,l1l111_l1_ (u"ࠨࠩ䪋"),l1l111_l1_ (u"ࠩࠪ䪌"),l1l111_l1_ (u"ࠪࠫ䪍"),l1l111_l1_ (u"ࠫࠬ䪎"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧ䪏"))
		html = response.content
		l11111llll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭䪐"),html,re.DOTALL)
		if l11111llll1_l1_:
			l11111llll1_l1_ = l11111llll1_l1_[0]
			l1lll111ll11_l1_ = l1lll1l1l1l1_l1_(l11111llll1_l1_)
			l1lll1111l11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬ䪑"),l1lll111ll11_l1_,re.DOTALL)
			if l1lll1111l11_l1_:
				l1lll1111l11_l1_ = l1lll1111l11_l1_[0]
				l1lll1111l11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䪒"),l1lll1111l11_l1_)
				for dict in l1lll1111l11_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠧ䪓")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ䪔")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䪕"))
					l111llll11_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠬࠦࠧ䪖")+server)
		elif l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䪗") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䪘")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡤࡱࡪ࠭䪙"))
			l111llll11_l1_.append(server)
		if l1l111_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ䪚") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࠩ䪛"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫ࠭䪜"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111llll11_l1_.append(l1l111_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ䪝"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䪞"))
		l111llll11_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ䪟"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䪠"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䪡"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪢"),[l1l111_l1_ (u"ࠫࠬ䪣")],[l1ll1ll_l1_]
def l1l1111111ll_l1_(url):
	headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䪤"):l1l111_l1_ (u"࠭ࡋࡰࡦ࡬࠳ࠬ䪥")+str(kodi_version)}
	for l1l111llll_l1_ in range(50):
		time.sleep(0.100)
		response = l11l11lllll_l1_(l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪦"),url,l1l111_l1_ (u"ࠨࠩ䪧"),headers,False,l1l111_l1_ (u"ࠩࠪ䪨"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ䪩"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䪪") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䪫")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ䪬")+headers[l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䪭")]
			return l1l111_l1_ (u"ࠨࠩ䪮"),[l1l111_l1_ (u"ࠩࠪ䪯")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ䪰"),[],[]
def l1l11l11ll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䪱"),url,l1l111_l1_ (u"ࠬ࠭䪲"),l1l111_l1_ (u"࠭ࠧ䪳"),l1l111_l1_ (u"ࠧࠨ䪴"),l1l111_l1_ (u"ࠨࠩ䪵"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨ䪶"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧ䪷"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠫࠬ䪸"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠭䪹"),[],[]
def l1llll1ll11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䪺"),url,l1l111_l1_ (u"ࠧࠨ䪻"),l1l111_l1_ (u"ࠨࠩ䪼"),l1l111_l1_ (u"ࠩࠪ䪽"),l1l111_l1_ (u"ࠪࠫ䪾"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡖࡉࡑࡎࡄ࠲࠯࠴ࡷࡹ࠭䪿"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫀"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ䫁"),[l1l111_l1_ (u"ࠧࠨ䫂")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ䫃"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭䫄") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䫅"),url,l1l111_l1_ (u"ࠫࠬ䫆"),l1l111_l1_ (u"ࠬ࠭䫇"),l1l111_l1_ (u"࠭ࠧ䫈"),l1l111_l1_ (u"ࠧࠨ䫉"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂ࠶ࡘ࠱࠶ࡹࡴࠨ䫊"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䫋"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䫌") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䫍"),[l1l111_l1_ (u"ࠬ࠭䫎")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆ࠺ࡕࠨ䫏"),[],[]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䫐"),[l1l111_l1_ (u"ࠨࠩ䫑")],[url]
def l111l111ll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䫒"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䫓"),l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䫔"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䫕")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䫖"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䫗"),l1l111_l1_ (u"ࠨࠩ䫘"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩ䫙"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫚"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭䫛"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫜"),[l1l111_l1_ (u"࠭ࠧ䫝")],[l1ll1ll_l1_]
def l1ll1l1llll1_l1_(url):
	headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䫞"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䫟")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䫠"),url,l1l111_l1_ (u"ࠪࠫ䫡"),headers,l1l111_l1_ (u"ࠫࠬ䫢"),l1l111_l1_ (u"ࠬ࠭䫣"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡕࡆࡑࡔࡒ࠱࠶ࡹࡴࠨ䫤"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䫥"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡗࡍࡕࡏࡇࡒࡕࡓࠬ䫦"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䫧"),[l1l111_l1_ (u"ࠪࠫ䫨")],[l1ll1ll_l1_]
def l1ll1lll11l_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䫩"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䫪")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䫫"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ䫬"),l1l111_l1_ (u"ࠨࠩ䫭"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ䫮"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ䫯"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ䫰"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䫱") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䫲")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䫳"),[l1l111_l1_ (u"ࠨࠩ䫴")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䫵"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䫶")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䫷"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䫸"),l1l111_l1_ (u"࠭ࠧ䫹"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩ䫺"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ䫻"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂࡃࡅࡈࡔ࠭䫼"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䫽"),[l1l111_l1_ (u"ࠫࠬ䫾")],[l1ll1ll_l1_]
def l1111l1ll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䫿"),url,l1l111_l1_ (u"࠭ࠧ䬀"),l1l111_l1_ (u"ࠧࠨ䬁"),l1l111_l1_ (u"ࠨࠩ䬂"),l1l111_l1_ (u"ࠩࠪ䬃"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ䬄"))
	html = response.content
	l11llllll111_l1_ = re.findall(l1l111_l1_ (u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ䬅"),html,re.DOTALL|re.IGNORECASE)
	if l11llllll111_l1_:
		l11llllll111_l1_ = l11llllll111_l1_[0][2:]
		l11llllll111_l1_ = base64.b64decode(l11llllll111_l1_)
		if PY3: l11llllll111_l1_ = l11llllll111_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䬆"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䬇"),l11llllll111_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࠨ䬈")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡘ࡛ࡌࡕࡏࠩ䬉"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䬊") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䬋")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䬌"),[l1l111_l1_ (u"ࠬ࠭䬍")],[l1ll1ll_l1_]
def l1l1l111l111_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䬎"),url,l1l111_l1_ (u"ࠧࠨ䬏"),l1l111_l1_ (u"ࠨࠩ䬐"),l1l111_l1_ (u"ࠩࠪ䬑"),l1l111_l1_ (u"ࠪࠫ䬒"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭䬓"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬔"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪ䬕"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䬖"),[l1l111_l1_ (u"ࠨࠩ䬗")],[l1ll1ll_l1_]
def l1l1l111l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䬘"))[-1]
	if l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ䬙") in url: url = url.replace(l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ䬚"),l1l111_l1_ (u"ࠬ࠭䬛"))
	url = url.replace(l1l111_l1_ (u"࠭࠮ࡤࡱࡰ࠳ࠬ䬜"),l1l111_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡳࡥࡵࡣࡧࡥࡹࡧ࠯ࠨ䬝"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䬞"),url,l1l111_l1_ (u"ࠩࠪ䬟"),l1l111_l1_ (u"ࠪࠫ䬠"),l1l111_l1_ (u"ࠫࠬ䬡"),l1l111_l1_ (u"ࠬ࠭䬢"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ䬣"))
	html = response.content
	l1l1l111l11l_l1_ = l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ䬤")
	error = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡶࡷࡵࡲࠣ࠰࠭ࡃࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䬥"),html,re.DOTALL)
	if error: l1l1l111l11l_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠩࡻ࠱ࡲࡶࡥࡨࡗࡕࡐࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬦"),html,re.DOTALL)
	if not url and l1l1l111l11l_l1_:
		return l1l1l111l11l_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠪࡠࡡ࠭䬧"),l1l111_l1_ (u"ࠫࠬ䬨"))
	l1l1llll1ll1_l1_,l1ll11l111l1_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬩"),html,re.DOTALL)
	if owner: l1l11ll11lll_l1_,l1l11ll11l1l_l1_,l1l1l11ll1ll_l1_ = owner[0]
	else: l1l11ll11lll_l1_,l1l11ll11l1l_l1_,l1l1l11ll1ll_l1_ = l1l111_l1_ (u"࠭ࠧ䬪"),l1l111_l1_ (u"ࠧࠨ䬫"),l1l111_l1_ (u"ࠨࠩ䬬")
	l1l1l11ll1ll_l1_ = l1l1l11ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䬭"),l1l111_l1_ (u"ࠪ࠳ࠬ䬮"))
	l1l11ll11l1l_l1_ = escapeUNICODE(l1l11ll11l1l_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䬯")+l1l11ll11l1l_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䬰")]+l1l1llll1ll1_l1_
	l1llll_l1_ = [l1l1l11ll1ll_l1_]+l1ll11l111l1_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ䬱")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠧࠡ็็ๅ࠮࠭䬲"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䬳"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨ䬴")+l1l1l11ll1ll_l1_+l1l111_l1_ (u"ࠪࠪࡹ࡫ࡸࡵ࠿ࠪ䬵")+l1l11ll11l1l_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ䬶")+new_path+l1l111_l1_ (u"ࠧ࠯ࠢ䬷"))
		return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䬸"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠧࠨ䬹"),[l1l111_l1_ (u"ࠨࠩ䬺")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䬻"),l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䬼"),l1l111_l1_ (u"ࠫࠬ䬽"),l1l111_l1_ (u"ࠬ࠭䬾"),l1l111_l1_ (u"࠭ࠧ䬿"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭䭀"))
	html = response.content
	if l1l111_l1_ (u"ࠨ࠰࡭ࡷࡴࡴࠧ䭁") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䭂"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䭃"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬ䭄"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䭅") not in url: url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䭆")+url
	return l1l111_l1_ (u"ࠧࠨ䭇"),[l1l111_l1_ (u"ࠨࠩ䭈")],[url]
def l1l1111ll111_l1_(url):
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䭉") : l1l111_l1_ (u"ࠪࠫ䭊") }
	if l1l111_l1_ (u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ䭋") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䭌"),headers,l1l111_l1_ (u"࠭ࠧ䭍"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠷ࡳࡵࠩ䭎"))
		items = re.findall(l1l111_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䭏"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠩࠪ䭐"),[l1l111_l1_ (u"ࠪࠫ䭑")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䭒"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䭓"),l1l111_l1_ (u"࠭ࠧ䭔"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩ䭕"),message[0])
				return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩ䭖")+message[0],[],[]
	else:
		l11111111l_l1_ = l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬ䭗")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䭘"),headers,l1l111_l1_ (u"ࠫࠬ䭙"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧ䭚"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䭛"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䭜"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"ࠨ࠰ࡵࡥࡷ࠭䭝") in block or l1l111_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ䭞") in block: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨ䭟"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䭠"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠬ࠭䭡"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠸ࡸࡤࠨ䭢"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥ࡙ࠢ࡭ࡩ࡫࡯࠯ࠬࡂ࡫ࡪࡺ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡯࡭ࡢࡩࡨ࠾ࠬ䭣"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ䭤"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤ࠱࠮ࡄࠨࡼࠪࠩ䭥"),block,re.DOTALL)
		l1l1l1111l1l_l1_,l1l1lll1_l1_,l1l111ll1l11_l1_,l1llll_l1_,l1l111l1llll_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䭦") in l1ll1ll_l1_:
				l1l1l1111l1l_l1_,l1l111ll1l11_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l1l111ll1l11_l1_
				if l1l1l1111l1l_l1_[0]==l1l111_l1_ (u"ࠫ࠲࠷ࠧ䭧"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ䭨")+l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ䭩")+l11111111l_l1_)
				else:
					for title in l1l1l1111l1l_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䭪")+l1l111_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䭫")+l11111111l_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭬")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬ䭭"),l1l111_l1_ (u"ࠫࠬ䭮"))
				title = title.strip(l1l111_l1_ (u"ࠬࠨࠧ䭯"))
				title = l1l111_l1_ (u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ䭰")+l1l111_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭䭱")+l11111111l_l1_+l1l111_l1_ (u"ࠨࠢࠪ䭲")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ䭳") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ䭴"),headers,l1l111_l1_ (u"ࠫࠬ䭵"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧ䭶"))
		items = re.findall(l1l111_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥ䭷"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫ䭸")+l1l111_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ䭹")+l11111111l_l1_+l1l111_l1_ (u"ࠩࠣࠫ䭺")+resolution.split(l1l111_l1_ (u"ࠪࡼࠬ䭻"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ䭼")+id+l1l111_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ䭽")+mode+l1l111_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭䭾")+hash
			l1l111l1llll_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l1l111l1llll_l1_ = set(l1l111l1llll_l1_)
		l1l11l11llll_l1_,l1l1l1l1111l_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ䭿"),title+l1l111_l1_ (u"ࠨࠨࠩࠫ䮀"),re.DOTALL)
			for resolution in l1l111l1llll_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠩࡻࠫ䮁"))[1])
			l1l11l11llll_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦ䮂"),l1l111_l1_ (u"ࠫࠫࠬࠧ䮃")+l1l11l11llll_l1_[i]+l1l111_l1_ (u"ࠬࠬࠦࠨ䮄"),re.DOTALL)
			l1l1l1l1111l_l1_.append( [l1l11l11llll_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l1l1l1111l_l1_ = sorted(l1l1l1l1111l_l1_, key=lambda x: x[3], reverse=True)
		l1l1l1l1111l_l1_ = sorted(l1l1l1l1111l_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l1l1l1111l_l1_)):
			l1l1lll1_l1_.append(l1l1l1l1111l_l1_[i][0])
			l1llll_l1_.append(l1l1l1l1111l_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䮅"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䮆"),l1l1lll1_l1_,l1llll_l1_
def l11llll1llll_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠨࡁࠪ䮇"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䮈") : l1l111_l1_ (u"ࠪࠫ䮉") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䮊"),headers,l1l111_l1_ (u"ࠬ࠭䮋"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭䮌"))
	items = re.findall(l1l111_l1_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ䮍"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䮎"),[l1l111_l1_ (u"ࠩࠪ䮏")],[url]
def l1l1l1111l11_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䮐") : l1l111_l1_ (u"ࠫࠬ䮑") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭䮒"),headers,l1l111_l1_ (u"࠭ࠧ䮓"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䮔"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䮕"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠩࠪ䮖"),[l1l111_l1_ (u"ࠪࠫ䮗")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ䮘"),[],[]
def l11lllll1l11_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䮙") : l1l111_l1_ (u"࠭ࠧ䮚") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䮛"),headers,l1l111_l1_ (u"ࠨࠩ䮜"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䮝"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭䮞"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠫࠬ䮟"),[l1l111_l1_ (u"ࠬ࠭䮠")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ䮡"),[],[]
def l1lllll1111_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠧࠨ䮢")
	if l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬ䮣") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䮤"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䮥")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䮦"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䮧"),l1l111_l1_ (u"࠭ࠧ䮨"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪ䮩"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䮪")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨࠩࠪ䮫"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪ࡝ࠩࠨࡢ࠭䮬"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠫࠬ䮭"),[l1l111_l1_ (u"ࠬ࠭䮮")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧ䮯") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䮰"),url,l1l111_l1_ (u"ࠨࠩ䮱"),l1l111_l1_ (u"ࠩࠪ䮲"),True,l1l111_l1_ (u"ࠪࠫ䮳"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧ䮴"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䮵") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䮶")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䮷"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䮸") in l1lllll1_l1_ or l1l111_l1_ (u"ࠩ࠲ࡪ࠴࠭䮹") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䮺"),l1l111_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䮻"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䮼"),l1l111_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䮽"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䮾"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䮿"),l1l111_l1_ (u"ࠩࠪ䯀"),l1l111_l1_ (u"ࠪࠫ䯁"),l1l111_l1_ (u"ࠫࠬ䯂"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨ䯃"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䯄"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ䯅"),l1l111_l1_ (u"ࠨࠩ䯆"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䯇"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠭䯈"),l1l111_l1_ (u"ࠫࠬ䯉"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬ࠭䯊"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䯋"),[l1l111_l1_ (u"ࠧࠨ䯌")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭䯍"),[],[]
	return l1l111_l1_ (u"ࠩࠪ䯎"),l1l1lll1_l1_,l1llll_l1_
def l11l1l11l11_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䯏"),url,l1l111_l1_ (u"ࠫࠬ䯐"),l1l111_l1_ (u"ࠬ࠭䯑"),l1l111_l1_ (u"࠭ࠧ䯒"),l1l111_l1_ (u"ࠧࠨ䯓"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨ䯔"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠩࠪ䯕")
	if l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭䯖") in url or l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ䯗") in url:
		if l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ䯘") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯙"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䯚") not in l1lllll1_l1_: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䯛"),[l1l111_l1_ (u"ࠩࠪ䯜")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䯝"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䯞"),l1l111_l1_ (u"ࠬ࠭䯟"),l1l111_l1_ (u"࠭ࠧ䯠"),l1l111_l1_ (u"ࠧࠨ䯡"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ䯢"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ䯣"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯤"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1llll1lllll_l1_ in items:
				l1l1lll1_l1_.append(l1llll1lllll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭䯥") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ䯦"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䯧"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䯨"),l1l111_l1_ (u"ࠨࠩ䯩"),l1l111_l1_ (u"ࠩࠪ䯪"),l1l111_l1_ (u"ࠪࠫ䯫"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ䯬"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯭"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ࠧ䯮"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧ䯯") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯰"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䯱"),[l1l111_l1_ (u"ࠪࠫ䯲")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭䯳"),[],[]
	return l1l111_l1_ (u"ࠬ࠭䯴"),l1l1lll1_l1_,l1llll_l1_
def l1111ll11_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ䯵")][0]
	headers = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䯶"):l1l11l11_l1_}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯷"),url,l1l111_l1_ (u"ࠩࠪ䯸"),headers,l1l111_l1_ (u"ࠪࠫ䯹"),l1l111_l1_ (u"ࠫࠬ䯺"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠶ࡳࡪࠧ䯻"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䯼"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯽"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䯾"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡩ࡭ࡱ࡫࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ䯿"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䰀")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠫࠬ䰁"),[l1l111_l1_ (u"ࠬ࠭䰂")],[l1ll1ll_l1_]
	if l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࡞ࡴࡰ࡭ࡨࡲࠧ࠭䰃") in html:
		l1l11l1lllll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡘࡵࡱ࡮ࡩࡳࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰄"),html,re.DOTALL)
		if l1l11l1lllll_l1_:
			l1ll1ll_l1_ = l1l11l1lllll_l1_[0]
			l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭䰅"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ䰆"))
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠲ࠧ䰇"),l1ll1ll_l1_,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䰈")+l1l11l11_l1_
				return l1l111_l1_ (u"ࠬ࠭䰉"),[l1l111_l1_ (u"࠭ࠧ䰊")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䰋"),[l1l111_l1_ (u"ࠨࠩ䰌")],[url]
def l111llll1l_l1_(url):
	l111llll11_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠩ࠲࠵࠴࠭䰍") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳࠶࠵ࠧ䰎"),l1l111_l1_ (u"ࠫ࠴࠺࠯ࠨ䰏"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰐"),l1ll1ll_l1_,l1l111_l1_ (u"࠭ࠧ䰑"),l1l111_l1_ (u"ࠧࠨ䰒"),False,l1l111_l1_ (u"ࠨࠩ䰓"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠲ࡵࡷࠫ䰔"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡩ࡫࡯࠿ࠩ䰕"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰖"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䰗"))
					l111llll11_l1_.append(server+l1l111_l1_ (u"࠭ࠠࠡࠩ䰘")+l111l1ll_l1_)
			return l1l111_l1_ (u"ࠧࠨ䰙"),l111llll11_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠨ࠱ࡧ࠳ࠬ䰚") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䰛"),url,l1l111_l1_ (u"ࠪࠫ䰜"),l1l111_l1_ (u"ࠫࠬ䰝"),l1l111_l1_ (u"ࠬ࠭䰞"),l1l111_l1_ (u"࠭ࠧ䰟"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠸࡮ࡥࠩ䰠"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰡"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠩ࠲࠵࠴࠭䰢"),l1l111_l1_ (u"ࠪ࠳࠹࠵ࠧ䰣"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䰤"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䰥"),l1l111_l1_ (u"࠭ࠧ䰦"),False,l1l111_l1_ (u"ࠧࠨ䰧"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪ䰨"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰩"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䰪"),[l1l111_l1_ (u"ࠫࠬ䰫")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ䰬"),[],[]
def l111ll11ll_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰭"),url,l1l111_l1_ (u"ࠧࠨ䰮"),l1l111_l1_ (u"ࠨࠩ䰯"),l1l111_l1_ (u"ࠩࠪ䰰"),l1l111_l1_ (u"ࠪࠫ䰱"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭䰲"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䰳"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"࠭࡯ࡱ࠿ࠪ䰴")+op+l1l111_l1_ (u"ࠧࠧ࡫ࡧࡁࠬ䰵")+id+l1l111_l1_ (u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩ䰶")+fname
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䰷"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ䰸")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䰹"),url,data,headers,l1l111_l1_ (u"ࠬ࠭䰺"),l1l111_l1_ (u"࠭ࠧ䰻"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩ䰼"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䰽"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䰾"),[l1l111_l1_ (u"ࠪࠫ䰿")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ䱀"),[],[]
def l11l11ll11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䱁"),1)[0].strip(l1l111_l1_ (u"࠭࠿ࠨ䱂")).strip(l1l111_l1_ (u"ࠧ࠰ࠩ䱃")).strip(l1l111_l1_ (u"ࠨࠨࠪ䱄"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠩࠪ䱅")
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䱆"):l1l111_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ䱇") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䱈"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䱉"),headers,True,l1l111_l1_ (u"ࠧࠨ䱊"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩ䱋"))
	if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䱌") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䱍")]
	if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䱎") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䱏") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"࠭࠯ࡧ࠱ࠪ䱐"),l1l111_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䱑"))
		l1l11l1l1l11_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪ䱒"))[1]
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䱓"):headers[l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䱔")] , l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䱕"):l1l111_l1_ (u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭䱖")+l1l11l1l1l11_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䱗"),l1llllll_l1_,l1l111_l1_ (u"ࠧࠨ䱘"),headers,False,l1l111_l1_ (u"ࠨࠩ䱙"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䱚"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࠳࡫࠵ࠧ䱛") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱜"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䱝") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱞"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"ࠧࠨ䱟")],[ items[0] ]
		elif l1l111_l1_ (u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧ䱠") in html:
			return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬ䱡"),[],[]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭䱢"),[],[]
def l11l11111ll_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䱣"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䱤"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ䱥")+l11l1l11_l1_+l1l111_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ䱦")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䱧"):l1l111_l1_ (u"ࠩࠪ䱨") , l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䱩"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䱪") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䱫"),headers,l1l111_l1_ (u"࠭ࠧ䱬"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭䱭"))
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䱮"),[l1l111_l1_ (u"ࠩࠪ䱯")],[l1lllll1_l1_]
def l1llll11ll11_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䱰"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䱱"):server,l1l111_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䱲"):l1l111_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࠥࡪࡥࡧ࡮ࡤࡸࡪ࠭䱳")}
	response = l11l1l_l1_(l1llll111lll_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䱴"),url,l1l111_l1_ (u"ࠨࠩ䱵"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ䱶"),l1l111_l1_ (u"ࠪࠫ䱷"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ䱸"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭䱹"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"࠭ࠧ䱺")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱻"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭䱼"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࠪ䱽"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱾"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡅࡌࡑࡆ࠭䱿"),[],[]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䲀"),[l1l111_l1_ (u"࠭ࠧ䲁")],[l1lllll1_l1_]
def l1ll1llllll1_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䲂"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䲃"):server,l1l111_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ䲄"):l1l111_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ䲅")}
	response = l11l1l_l1_(l1llll111lll_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䲆"),url,l1l111_l1_ (u"ࠬ࠭䲇"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ䲈"),l1l111_l1_ (u"ࠧࠨ䲉"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡋࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ䲊"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ䲋"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠪࠫ䲌")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䲍"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䲎"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࠧ䲏"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲐"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪ䲑"),[],[]
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䲒"),[l1l111_l1_ (u"ࠪࠫ䲓")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䲔"),l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䲕"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧ䲖"):l11l1l11_l1_,l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ䲗"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭䲘"),url,data,l1l111_l1_ (u"ࠩࠪ䲙"),l1l111_l1_ (u"ࠪࠫ䲚"),l1l111_l1_ (u"ࠫࠬ䲛"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ䲜"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲝"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䲞"),[l1l111_l1_ (u"ࠨࠩ䲟")],[l1lllll1_l1_]
def l11111111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䲠"),url,l1l111_l1_ (u"ࠪࠫ䲡"),l1l111_l1_ (u"ࠫࠬ䲢"),l1l111_l1_ (u"ࠬ࠭䲣"),l1l111_l1_ (u"࠭ࠧ䲤"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳࠱ࡴࡶࠪ䲥"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䲦"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䲧"),[l1l111_l1_ (u"ࠪࠫ䲨")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ䲩"),[],[]
def l11111l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲪"),url,l1l111_l1_ (u"࠭ࠧ䲫"),l1l111_l1_ (u"ࠧࠨ䲬"),l1l111_l1_ (u"ࠨࠩ䲭"),l1l111_l1_ (u"ࠩࠪ䲮"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬ䲯"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲰"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䲱"),[l1l111_l1_ (u"࠭ࠧ䲲")],[l1ll1ll_l1_]
def l1lllllll1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䲳"))
	if l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ䲴") in url:
		headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䲵"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䲶"),url,l1l111_l1_ (u"ࠫࠬ䲷"),headers,l1l111_l1_ (u"ࠬ࠭䲸"),l1l111_l1_ (u"࠭ࠧ䲹"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ䲺"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲻"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䲼") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ䲽"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ䲾"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䲿"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䳀"),headers,l1l111_l1_ (u"ࠧࠨ䳁"),l1l111_l1_ (u"ࠨࠩ䳂"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ䳃"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䳄"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䳅"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ䳆")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"࠭ࠧ䳇"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䳈"),[l1l111_l1_ (u"ࠨࠩ䳉")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䳊")+l11l11111_l1_
	return l1l111_l1_ (u"ࠪࠫ䳋"),[l1l111_l1_ (u"ࠫࠬ䳌")],[l1lllll1_l1_]
def l1l111l1111l_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䳍"))
	if l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭䳎") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䳏"),l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䳐"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠩ࡬ࡨࠬ䳑"):l11l1l11_l1_,l1l111_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪ䳒"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䳓"),url,data,l1l111_l1_ (u"ࠬ࠭䳔"),l1l111_l1_ (u"࠭ࠧ䳕"),l1l111_l1_ (u"ࠧࠨ䳖"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ䳗"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䳘"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䳙") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䳚"):l11l11111_l1_,l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䳛"):l1l111_l1_ (u"࠭ࠧ䳜")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䳝"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ䳞"),headers,l1l111_l1_ (u"ࠩࠪ䳟"),l1l111_l1_ (u"ࠪࠫ䳠"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ䳡"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䳢"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䳣"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䳤")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠨࠩ䳥"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䳦"),[l1l111_l1_ (u"ࠪࠫ䳧")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䳨")+l11l11111_l1_
		return l1l111_l1_ (u"ࠬ࠭䳩"),[l1l111_l1_ (u"࠭ࠧ䳪")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ䳫") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䳬"),l1ll1ll_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䳭"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䳮"))
		url = host+l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ䳯")+l11l1l11_l1_+l1l111_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ䳰")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䳱"):l1l111_l1_ (u"ࠧࠨ䳲") , l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䳳"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䳴") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䳵"),headers,l1l111_l1_ (u"ࠫࠬ䳶"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ䳷"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䳸"),l1l111_l1_ (u"ࠧࠨ䳹")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ䳺"),l1l111_l1_ (u"ࠩࠪ䳻"))
		return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䳼"),[l1l111_l1_ (u"ࠫࠬ䳽")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ䳾") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ䳿") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䴀"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䴁"),l1l111_l1_ (u"ࠩࠪ䴂"),l1l111_l1_ (u"ࠪࠫ䴃"),l1l111_l1_ (u"ࠫࠬ䴄"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠶ࡳࡪࠧ䴅"))
			if l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䴆") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䴇")]
			counts += 1
		return l1l111_l1_ (u"ࠨࠩ䴈"),[l1l111_l1_ (u"ࠩࠪ䴉")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧ䴊"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䴋"))
	headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䴌"):server,l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䴍"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ䴎") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䴏"),headers,l1l111_l1_ (u"ࠩࠪ䴐"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ䴑"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䴒"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ䴓"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䴔"))
			return l1l111_l1_ (u"ࠧࠨ䴕"),[l1l111_l1_ (u"ࠨࠩ䴖")],[l1ll1ll_l1_]
	else:
		l1l11lllll1l_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䴗"),url,l1l111_l1_ (u"ࠪࠫ䴘"),headers,l1l111_l1_ (u"ࠫࠬ䴙"),l1l111_l1_ (u"ࠬ࠭䴚"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨ䴛"))
		html = l1l11lllll1l_l1_.content
		l1ll1ll1l_l1_ = headers.copy()
		if l1l111_l1_ (u"ࠧࡠ࡮ࡱ࡯ࡤ࠭䴜") in str(l1l11lllll1l_l1_.cookies):
			cookies = l1l11lllll1l_l1_.cookies
			l1ll1ll1l_l1_[l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䴝")] = l111l11_l1_(l1lllll11_l1_(cookies))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ䴞"),html,re.DOTALL)
		if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䴟"),[l1l111_l1_ (u"ࠫࠬ䴠")],[url]
		else:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠬࠬࡤ࠾࠳ࠪ䴡")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䴢"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䴣"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䴤"),l1l111_l1_ (u"ࠩࠪ䴥"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠶ࡷ࡬ࠬ䴦"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡤࡷࡲࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䴧"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				if l1l111_l1_ (u"ࠬࡳࡰ࠵ࠩ䴨") in l1ll1ll_l1_ and l1l111_l1_ (u"࠭࠯ࡥ࠱ࠪ䴩") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ䴪"),[l1l111_l1_ (u"ࠨࠩ䴫")],[l1ll1ll_l1_]
				else: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䴬"),[l1l111_l1_ (u"ࠪࠫ䴭")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ䴮"),[],[]
def l1ll1llll111_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠬࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠩ䴯") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䴰"):l1l111_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䴱")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䴲"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䴳"),headers,l1l111_l1_ (u"ࠪࠫ䴴"),l1l111_l1_ (u"ࠫࠬ䴵"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ䴶"))
		url = response.content
		if url: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䴷"),[l1l111_l1_ (u"ࠧࠨ䴸")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䴹"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠩࡢࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ䴺"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䴻"))
		url = server+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡷ࡬ࡪࡳࡥ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䴼")
		data = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ䴽"):l11l1l11_l1_,l1l111_l1_ (u"࠭ࡩࠨ䴾"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䴿"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䵀"),l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䵁"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䵂"),url,data,headers,l1l111_l1_ (u"ࠫࠬ䵃"),l1l111_l1_ (u"ࠬ࠭䵄"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࠷ࡴࡤࠨ䵅"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䵆"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䵇"),[l1l111_l1_ (u"ࠩࠪ䵈")],[l1lllll1_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡂࡊࡌࡈ࠹࡛ࠧ䵉"),[],[]
def l1l111llllll_l1_(l11llllll1ll_l1_):
	l1l11l1lll1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡢ࡭ࡺࡥࡲ࠴ࡶࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ䵊"))
	headers = {l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䵋"):l1l11l1lll1l_l1_} if l1l11l1lll1l_l1_ else l1l111_l1_ (u"࠭ࠧ䵌")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䵍"),l11llllll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䵎"),headers,l1l111_l1_ (u"ࠩࠪ䵏"),l1l111_l1_ (u"ࠪࠫ䵐"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠲ࡵࡷࠫ䵑"))
	l1l11ll11l11_l1_ = response.content
	l1l1l111ll1l_l1_ = str(response.headers)
	l11lllll1111_l1_ = l1l1l111ll1l_l1_+l1l11ll11l11_l1_
	if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䵒") in l11lllll1111_l1_: found = True
	else:
		l1l111l11111_l1_,token,l11lllll11ll_l1_,l1l111ll11ll_l1_,found = l1l111_l1_ (u"࠭ࠧ䵓"),l1l111_l1_ (u"ࠧࠨ䵔"),l1l111_l1_ (u"ࠨࠩ䵕"),l1l111_l1_ (u"ࠩࠪ䵖"),False
		l1l1111l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵗"),l1l11ll11l11_l1_,re.DOTALL)
		if l1l1111l1ll1_l1_: l11lllll11ll_l1_,l1l111ll11ll_l1_ = l1l1111l1ll1_l1_[0]
		l1l1111l1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ䵘")][7]
		l1ll11l11l11_l1_ = l1l11l1l1ll_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵙"):l1ll11l11l11_l1_,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵚"):l1l11l1111l_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵛"):l11llllll1ll_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵜"):l1l111ll11ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵝"):l1l111_l1_ (u"ࠪࠫ䵞"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵟"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭䵠")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵡"),l1l1111l1lll_l1_,data,l1l111_l1_ (u"ࠧࠨ䵢"),l1l111_l1_ (u"ࠨࠩ䵣"),l1l111_l1_ (u"ࠩࠪ䵤"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠲࡯ࡦࠪ䵥"))
			html = response.content
		html = l1l111_l1_ (u"ࠫࠬ䵦")
		if html.startswith(l1l111_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ䵧")):
			l1l1lllll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䵨"),html.split(l1l111_l1_ (u"ࠧࡖࡔࡏࡗࡂ࠭䵩"),1)[1])
			for request in l1l1lllll1l1_l1_:
				url = request[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䵪")]
				method = request[l1l111_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࠩ䵫")]
				data = request[l1l111_l1_ (u"ࠪࡨࡦࡺࡡࠨ䵬")]
				headers = request[l1l111_l1_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ䵭")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠬ࠭䵮"),l1l111_l1_ (u"࠭ࠧ䵯"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ䵰"))
				l1l11ll11l11_l1_ = response.content
				if l1l111_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䵱") in l1l11ll11l11_l1_:
					found = True
					break
				l1l1l111ll1l_l1_ = str(response.headers)
				l11lllll1111_l1_ = l1l1l111ll1l_l1_+l1l11ll11l11_l1_
				l1l111l11111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡥࡰࡽࡡ࡮ࡘࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡜ࡸ࠭ࠬ࠲࠯ࡅࠢࠩࡧࡼࡎ࠳࠰࠿ࠪࠤࠪ䵲"),l11lllll1111_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲ࠳࠰࠿ࠣࠪ࠳࠷ࡆ࠴ࠪࡀࠫࠥࠫ䵳"),l11lllll1111_l1_,re.DOTALL)
				if token: token = token[0]
				if l1l111l11111_l1_ or token: break
		if not found:
			if not l1l111l11111_l1_:
				if not token and l1l1111l1ll1_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠫࡎࡊ࠽ࠨ䵴")):
						data = {l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ䵵"):l1ll11l11l11_l1_,l1l111_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ䵶"):l1l11l1111l_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ䵷"):l11llllll1ll_l1_,l1l111_l1_ (u"ࠨ࡭ࡨࡽࠬ䵸"):l1l111ll11ll_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࠬ䵹"):l1l111_l1_ (u"ࠪࠫ䵺"),l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䵻"):l1l111_l1_ (u"ࠬ࡭ࡥࡵ࡫ࡧࠫ䵼")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䵽"),l1l1111l1lll_l1_,data,l1l111_l1_ (u"ࠧࠨ䵾"),l1l111_l1_ (u"ࠨࠩ䵿"),l1l111_l1_ (u"ࠩࠪ䶀"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠴ࡵࡪࠪ䶁"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠫࡎࡊ࠽࠲࠴࠶࠸࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿࠷࠹ࠬ䶂")
					if html.startswith(l1l111_l1_ (u"ࠬࡏࡄ࠾ࠩ䶃")):
						l1l111ll111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡉࡅ࠿ࠫ࠲࠯ࡅࠩ࠻࠼࠽࠾࡙ࡏࡍࡆࡑࡘࡘࡂ࠮࠮ࠫࡁࠬࠨࠬ䶄"),html,re.DOTALL)
						l1l1l11lll1l_l1_,l1l11111lll_l1_ = l1l111ll111l_l1_[0]
						message = l1l111_l1_ (u"่ࠧา๊ࠤฬู๊ๆๆํอࠥะอหษฯࠤํ่สࠡ็้ࠤ࠶࠶ࠠฦๆ์ࠤࠬ䶅")+l1l11111lll_l1_+l1l111_l1_ (u"ࠨࠢฮห๋๐ษࠨ䶆")
						l1l1111lll_l1_ = l1l111lll1_l1_()
						l1l1111lll_l1_.create(l1l111_l1_ (u"่ࠩัฬ๎ไสࠢอะฬ๎าࠡใะูࠥษๆศࠢฦุ๊อๆ๊ࠡ็ืฯࠦศา่ส้ัࠦใ้็ห๎ํะัࠨ䶇"),message)
						t1 = time.time()
						l1l11l11111l_l1_,l1l1l1l11l11_l1_ = 0,0
						while l1l11l11111l_l1_<int(l1l11111lll_l1_):
							l1l1111l11_l1_(l1l1111lll_l1_,int(l1l11l11111l_l1_/int(l1l11111lll_l1_)*100),message,l1l111_l1_ (u"ࠪࠫ䶈"),l1l11111lll_l1_+l1l111_l1_ (u"ࠫࠥ࠵ࠠࠨ䶉")+str(int(l1l11l11111l_l1_))+l1l111_l1_ (u"ࠬࠦࠠฬษ้๎ฮ࠭䶊"))
							if l1l11l11111l_l1_>l1l1l1l11l11_l1_+10:
								data = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ䶋"):l1ll11l11l11_l1_,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䶌"):l1l11l1111l_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ䶍"):l11llllll1ll_l1_,l1l111_l1_ (u"ࠩ࡮ࡩࡾ࠭䶎"):l1l111ll11ll_l1_,l1l111_l1_ (u"ࠪ࡭ࡩ࠭䶏"):l1l1l11lll1l_l1_,l1l111_l1_ (u"ࠫ࡯ࡵࡢࠨ䶐"):l1l111_l1_ (u"ࠬ࡭ࡥࡵࡶࡲ࡯ࡪࡴࠧ䶑")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䶒"),l1l1111l1lll_l1_,data,l1l111_l1_ (u"ࠧࠨ䶓"),l1l111_l1_ (u"ࠨࠩ䶔"),l1l111_l1_ (u"ࠩࠪ䶕"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ䶖"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ䶗")):
									token = html.split(l1l111_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ䶘"),1)[1]
									break
								l1l1l1l11l11_l1_ = l1l11l11111l_l1_
							else: time.sleep(1)
							l1l11l11111l_l1_ = time.time()-t1
						l1l1111lll_l1_.close()
				if token:
					l11llllll11l_l1_ = response.cookies
					l1ll111ll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠨ࠯ࠬࡂ࠭ࡀ࠭䶙"),l11lllll1111_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ䶚") in list(l11llllll11l_l1_.keys()): l1ll111ll1l1_l1_ = l11llllll11l_l1_[l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ䶛")]
					elif l1ll111ll1l1_l1_: l1ll111ll1l1_l1_ = l1ll111ll1l1_l1_[0]
					l1l1111l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶜"),l1l11ll11l11_l1_,re.DOTALL)
					if l1l1111l1ll1_l1_: l11lllll11ll_l1_,l1l111ll11ll_l1_ = l1l1111l1ll1_l1_[0]
					if l1ll111ll1l1_l1_ and l1l1111l1ll1_l1_:
						headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䶝"):l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁࠬ䶞")+l1ll111ll1l1_l1_,l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䶟"):l11llllll1ll_l1_,l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䶠"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䶡")}
						data = l1l111_l1_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥ࠾ࠩ䶢")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䶣"),l11lllll11ll_l1_,data,headers,False,l1l111_l1_ (u"ࠪࠫ䶤"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫ䶥"))
						l1l11ll11l11_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l1l111l11111_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ䶦"),str(cookies),re.DOTALL)
			if l1l111l11111_l1_:
				name,l1l111l11111_l1_ = l1l111l11111_l1_[0]
				l1l11l1lll1l_l1_ = name+l1l111_l1_ (u"࠭࠽ࠨ䶧")+l1l111l11111_l1_
				settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ䶨"),l1l11l1lll1l_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䶩"),l1l111_l1_ (u"ࠩࠪ䶪"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䶫"),l1l111_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡใะูࠥษๆศࠢศุ๊อๆࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอิา็้ࠢฮฬฬฬ้ࠡำหࠥอไโฯุࠤ้้๊ࠡ์ึฮำีๅ่ษ่ࠣฬำโศࠢ࠱࠲ࠥ๎ไศࠢอ์ัีࠠฮษฯอ๊ࠥลฺษาอࠥํะศࠢส่ๆำีࠡๆ฼ำฮࠦรี้ิࠤࡡࡴ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆไัฺࠦำ้ใࠣ๎ฯ้ัาࠢไ๎ࠥำวๅหࠣฮ฿๐ัࠡำห฻ࠥอไอ้สึࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฦูไหฦࠦัศ๊อีࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦแึๆࠣื้้ࠠศๆิหํะัࠡ࠰࠱ࠤศ๎ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡสิ์ู่๊ࠨ䶬"))
				if l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ䶭") not in l1l11ll11l11_l1_:
					headers = {l1l111_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭䶮"):l1l11l1lll1l_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䶯"),l11llllll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䶰"),headers,l1l111_l1_ (u"ࠩࠪ䶱"),l1l111_l1_ (u"ࠪࠫ䶲"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫ䶳"))
					l1l11ll11l11_l1_ = response.content
	if not found and not l1l11l1lll1l_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䶴"),l1l111_l1_ (u"࠭ࠧ䶵"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䶶"),l1l111_l1_ (u"ࠨ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠโึ็ฮࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨ䶷"))
	return l1l11ll11l11_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111llll11_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䶸"),url,l1l111_l1_ (u"ࠪࠫ䶹"),l1l111_l1_ (u"ࠫࠬ䶺"),l1l111_l1_ (u"ࠬ࠭䶻"),l1l111_l1_ (u"࠭ࠧ䶼"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭䶽"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ䶾"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭䶿"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ䷀") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䷁") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭䷂"),l1l111_l1_ (u"࠭ࠧ䷃")).replace(l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䷄"),l1l111_l1_ (u"ࠨࠩ䷅")).strip(l1l111_l1_ (u"ࠩࠣࠫ䷆")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䷇"),l1l111_l1_ (u"ࠫࠥ࠭䷈"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111llll11_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬ䷉"),l111llll11_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ䷊"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䷋"),[],[]
	l11llllll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l1l11ll11l11_l1_ = l1l111llllll_l1_(l11llllll1ll_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䷌"):
		l1l11ll1l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䷍"),l1l11ll11l11_l1_,re.DOTALL)
		if l1l11ll1l1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l11ll1l1ll_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䷎"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷏"),l1l11ll11l11_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭䷐"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䷑"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䷒"),url,l1l111_l1_ (u"ࠨࠩ䷓"),l1l111_l1_ (u"ࠩࠪ䷔"),True,l1l111_l1_ (u"ࠪࠫ䷕"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠱ࡴࡶࠪ䷖"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䷗") in list(cookies.keys()):
		l1l11l1lll1l_l1_ = cookies[l1l111_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䷘")]
		l1l11l1lll1l_l1_ = l111l11_l1_(escapeUNICODE(l1l11l1lll1l_l1_))
		items = re.findall(l1l111_l1_ (u"ࠧࡳࡱࡸࡸࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷙"),l1l11l1lll1l_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ䷚"),l1l111_l1_ (u"ࠩ࠲ࠫ䷛"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ䷜") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫࠪ࠸ࡆࠨ䷝"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡡࡵࡥ࡫࠲࡮ࡹ࠯ࠨ䷞")+id
		return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䷟"),[l1l111_l1_ (u"ࠧࠨ䷠")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䷡")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䷢"),l1l11l11_l1_,l1l111_l1_ (u"ࠪࠫ䷣"),l1l111_l1_ (u"ࠫࠬ䷤"),True,l1l111_l1_ (u"ࠬ࠭䷥"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ䷦"))
		l1l1l111l1l1_l1_ = response.url
		l1l1l11ll1l1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䷧"))[2]
		l1l1l1l11lll_l1_ = l1l1l111l1l1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䷨"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l1l11ll1l1_l1_,l1l1l1l11lll_l1_)
		headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䷩"):l1l111_l1_ (u"ࠪࠫ䷪") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ䷫"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭䷬") , l1l111_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䷭"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䷮"), l1llllll_l1_, l1l111_l1_ (u"ࠨࠩ䷯"), headers, False,l1l111_l1_ (u"ࠩࠪ䷰"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠹ࡲࡥࠩ䷱"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䷲"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷳"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"࠭࠼ࡦ࡯ࡥࡩࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷴"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䷵"),l1l111_l1_ (u"ࠨ࠱ࠪ䷶"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠩ࠲ࠫ䷷"))
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䷸") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䷹") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䷺"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䷻"))
			if name==l1l111_l1_ (u"ࠧࠨ䷼"): l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ䷽"),[l1l111_l1_ (u"ࠩࠪ䷾")],[l1ll1ll_l1_]
			else: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䷿"),[l1l111_l1_ (u"ࠫࠬ一")],[l1ll1ll_l1_]
		else: l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭丁"),[],[]
		return l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
def l1l11111ll1l_l1_(url):
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ丂") : l1l111_l1_ (u"ࠧࠨ七") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ丄"),headers,l1l111_l1_ (u"ࠩࠪ丅"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ丆"))
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ万"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠬ࠭丈")
	if items:
		for l1ll1ll_l1_,l1llll1lllll_l1_ in items:
			l1l1lll1_l1_.append(l1llll1lllll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓࠬ三"),[],[]
	return l1l111_l1_ (u"ࠧࠨ上"),l1l1lll1_l1_,l1llll_l1_
def l1l11l11l1ll_l1_(url):
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ下"):l1l111_l1_ (u"ࠩࠪ丌")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ不"),headers,l1l111_l1_ (u"ࠫࠬ与"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬ丏"))
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ丐"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ丑")+url
		return l1l111_l1_ (u"ࠨࠩ丒"),[l1l111_l1_ (u"ࠩࠪ专")],[url]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡑࡍࡑࡄࡈࠬ且"),[],[]
def l1l111lll1ll_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠫ࠴࠭丕"))
	if l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭世") in url: id = url.split(l1l111_l1_ (u"࠭࠯ࠨ丗"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ丘"))[-1]
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡧࡸࡺࡲࡦࡣࡰ࠲ࡹࡵ࠯ࡱ࡮ࡤࡽࡪࡸ࠿ࡧ࡫ࡧࡁࠬ丙") + id
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭业") : l1l111_l1_ (u"ࠪࠫ丛") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ东"),headers,l1l111_l1_ (u"ࠬ࠭丝"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ丞"))
	html = html.replace(l1l111_l1_ (u"ࠧ࡝࡞ࠪ丟"),l1l111_l1_ (u"ࠨࠩ丠"))
	items = re.findall(l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ両"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ丢"),[l1l111_l1_ (u"ࠫࠬ丣")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡅࡖࡘࡗࡋࡁࡎࠩ两"),[],[]
def l1l111ll1ll1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ严"),l1l111_l1_ (u"ࠧࠨ並"),l1l111_l1_ (u"ࠨࠩ丧"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ丨"))
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ丩"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1llll1lllll_l1_,res in items:
		l1l1lll1_l1_.append(l1llll1lllll_l1_+l1l111_l1_ (u"ࠫࠥ࠭个")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ丫"),[],[]
	return l1l111_l1_ (u"࠭ࠧ丬"),l1l1lll1_l1_,l1llll_l1_
def l1l11lll11ll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ中"),l1l111_l1_ (u"ࠨࠩ丮"),l1l111_l1_ (u"ࠩࠪ丯"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ丰"))
	items = re.findall(l1l111_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ丱"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1llll1lllll_l1_,res in items:
		url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ串")+id+l1l111_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭丳")+mode+l1l111_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ临")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ丵"),l1l111_l1_ (u"ࠩࠪ丶"),l1l111_l1_ (u"ࠪࠫ丷"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ丸"))
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ丹"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1llll1lllll_l1_+l1l111_l1_ (u"࠭ࠠࠨ为")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭主"),[],[]
	return l1l111_l1_ (u"ࠨࠩ丼"),l1l1lll1_l1_,l1llll_l1_
def l1l1111l1l1l_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠩࠪ丽")
	if 1 or l1l111_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ举") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ丿"),l1l111_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ乀"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ乁"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠧ࠰ࠩ乂").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ乃"):id,l1l111_l1_ (u"ࠩࡲࡴࠬ乄"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭久"),l1l111_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ乆"):l1l111_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ乇")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ么"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠧࠨ义"),l1l111_l1_ (u"ࠨࠩ乊"),l1l111_l1_ (u"ࠩࠪ之"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ乌"))
		if l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭乍") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ乎")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ乏"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ乐"),url,l1l111_l1_ (u"ࠨࠩ乑"),l1l111_l1_ (u"ࠩࠪ乒"),l1l111_l1_ (u"ࠪࠫ乓"),l1l111_l1_ (u"ࠫࠬ乔"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ乕"))
		if l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ乖") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ乗")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࠩ乘"),[l1l111_l1_ (u"ࠩࠪ乙")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ乚"),[],[]
def l1l11l1111l1_l1_(url):
	headers = { l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ乛") : l1l111_l1_ (u"ࠬ࠭乜") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ九"),headers,l1l111_l1_ (u"ࠧࠨ乞"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ也"))
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ习"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠧ乡"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ乢"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠬ࠭乣"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ乤"),[],[]
def l11ll1llll1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ乥"))[-1]
	id = id.split(l1l111_l1_ (u"ࠨࠨࠪ书"))[0]
	id = id.replace(l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ乧"),l1l111_l1_ (u"ࠪࠫ乨"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ乩")][0]+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ乪")+id
	l1l1111lll1l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ乫")+id
	l1l11llll111_l1_,l1l11lll1ll1_l1_,l1l11l1lll11_l1_,l1l111lll11l_l1_ = l1l111_l1_ (u"ࠧࠨ乬"),l1l111_l1_ (u"ࠨࠩ乭"),l1l111_l1_ (u"ࠩࠪ乮"),l1l111_l1_ (u"ࠪࠫ乯")
	for l1l111llll_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ买"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭乱"),l1l111_l1_ (u"࠭ࠧ乲"),l1l111_l1_ (u"ࠧࠨ乳"),l1l111_l1_ (u"ࠨࠩ乴"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ乵"))
		html = response.content
		if l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ乶") in html: break
		time.sleep(2)
	l1l11lllll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ乷"),html,re.DOTALL)
	if l1l11lllll_l1_: l1l11lllll_l1_ = l1l11lllll_l1_[0]
	else: l1l11lllll_l1_ = html
	l1l11lllll_l1_ = l1l11lllll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭乸"),l1l111_l1_ (u"࠭ࠦࠨ乹"))
	l1l1l111l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ乺"),l1l11lllll_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ乻")],[l1l111_l1_ (u"ࠩࠪ乼")]
	try:
		l1l1l1l11l1l_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ乽")][l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ乾")][l1l111_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ乿")]
		for l1l11l1l11ll_l1_ in l1l1l1l11l1l_l1_:
			l1ll1ll_l1_ = l1l11l1l11ll_l1_[l1l111_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ亀")]
			try: title = l1l11l1l11ll_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ亁")][l1l111_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ亂")]
			except: title = l1l11l1l11ll_l1_[l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ亃")][l1l111_l1_ (u"ࠪࡶࡺࡴࡳࠨ亄")][0][l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ亅")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ了"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ亇"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠧࠧࠩ予")
			l1l11l111l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭争"),l1ll1ll_l1_)
			if l1l11l111l1l_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l11l111l1l_l1_[0],l1l111_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ亊"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ事")
			l1l11llll111_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭二"))
	formats,l1l1l111ll11_l1_,l1l1111l1111_l1_,l1l1111l111l_l1_,l1l11111llll_l1_ = [],[],[],[],[]
	try: l1l11lll1ll1_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ亍")][l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ于")]
	except: pass
	try: l1l11l1lll11_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ亏")][l1l111_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ亐")]
	except: pass
	try: formats = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ云")][l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ互")]
	except: pass
	try: l1l1l111ll11_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ亓")][l1l111_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ五")]
	except: pass
	l1l11lll1lll_l1_ = formats+l1l1l111ll11_l1_
	for dict in l1l11lll1lll_l1_:
		if l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ井") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ亖")] = str(dict[l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭亗")])
		if l1l111_l1_ (u"ࠩࡩࡴࡸ࠭亘") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ亙")] = str(dict[l1l111_l1_ (u"ࠫ࡫ࡶࡳࠨ亚")])
		if l1l111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ些") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫ亜")] = dict[l1l111_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ亝")]
		if l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ亞") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭亟")] = str(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ亠")])
		if l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ亡") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亢")] = str(dict[l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭亣")])
		if l1l111_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭交") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭亥")] = str(dict[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ亦")])+l1l111_l1_ (u"ࠪࡼࠬ产")+str(dict[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ亨")])
		if l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ亩") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ亪")] = dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ享")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ京")]+l1l111_l1_ (u"ࠩ࠰ࠫ亭")+dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭亮")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ亯")]
		if l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ亰") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ亱")] = dict[l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ亲")][l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ亳")]+l1l111_l1_ (u"ࠩ࠰ࠫ亴")+dict[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ亵")][l1l111_l1_ (u"ࠫࡪࡴࡤࠨ亶")]
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭亷") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ亸")] = dict[l1l111_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ亹")]
		if l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ人") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ亻")])>111222333: del dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ亼")]
		if l1l111_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭亽") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ亾")].split(l1l111_l1_ (u"࠭ࠦࠨ亿"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ什"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仁") in list(dict.keys()): dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仂")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ仃")])
		l1l1111l1111_l1_.append(dict)
	l1l11ll11111_l1_ = l1l111_l1_ (u"ࠫࠬ仄")
	if l1l111_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ仅") in l1l11lllll_l1_:
		l1l1l111111l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ仆"),html,re.DOTALL)
		if l1l1l111111l_l1_:
			l1l1l111111l_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ仇")][0]+l1l1l111111l_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ仈"),l1l1l111111l_l1_,l1l111_l1_ (u"ࠩࠪ仉"),l1l111_l1_ (u"ࠪࠫ今"),l1l111_l1_ (u"ࠫࠬ介"),l1l111_l1_ (u"ࠬ࠭仌"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ仍"))
			l1l11ll11111_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11llllllll1_l1_ = cipher._load_javascript(l1l11ll11111_l1_)
			l1l11l11ll1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡴࡶࡵࠫ从"),str(l11llllllll1_l1_))
			l1l11111111l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l11l11ll1l_l1_)
	for dict in l1l1111l1111_l1_:
		url = dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ仏")]
		if l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭仐") in url or url.count(l1l111_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ仑"))>1:
			l1l1111l111l_l1_.append(dict)
		elif l1l11ll11111_l1_ and l1l111_l1_ (u"ࠫࡸ࠭仒") in list(dict.keys()) and l1l111_l1_ (u"ࠬࡹࡰࠨ仓") in list(dict.keys()):
			l1l11l1l1111_l1_ = l1l11111111l_l1_.execute(dict[l1l111_l1_ (u"࠭ࡳࠨ仔")])
			if l1l11l1l1111_l1_!=dict[l1l111_l1_ (u"ࠧࡴࠩ仕")]:
				dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ他")] = url+l1l111_l1_ (u"ࠩࠩࠫ仗")+dict[l1l111_l1_ (u"ࠪࡷࡵ࠭付")]+l1l111_l1_ (u"ࠫࡂ࠭仙")+l1l11l1l1111_l1_
				l1l1111l111l_l1_.append(dict)
	for dict in l1l1111l111l_l1_:
		l111lll_l1_,l1l111111lll_l1_,l1l1l1l111l1_l1_,l1l1l1ll1_l1_,codecs,l11ll111lll_l1_ = l1l111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭仚"),l1l111_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ仛"),l1l111_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ仜"),l1l111_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ仝"),l1l111_l1_ (u"ࠩࠪ仞"),l1l111_l1_ (u"ࠪ࠴ࠬ仟")
		try:
			l1l1111l11l1_l1_ = dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ仠")]
			l1l1111l11l1_l1_ = l1l1111l11l1_l1_.replace(l1l111_l1_ (u"ࠬ࠱ࠧ仡"),l1l111_l1_ (u"࠭ࠧ仢"))
			items = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ代"),l1l1111l11l1_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l11llllll1_l1_ = codecs.split(l1l111_l1_ (u"ࠨ࠮ࠪ令"))
			l1l111111lll_l1_ = l1l111_l1_ (u"ࠩࠪ以")
			for item in l1l11llllll1_l1_: l1l111111lll_l1_ += item.split(l1l111_l1_ (u"ࠪ࠲ࠬ仦"))[0]+l1l111_l1_ (u"ࠫ࠱࠭仧")
			l1l111111lll_l1_ = l1l111111lll_l1_.strip(l1l111_l1_ (u"ࠬ࠲ࠧ仨"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ仩") in list(dict.keys()): l11ll111lll_l1_ = str(float(dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ仪")]*10)//1024/10)+l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ仫")
			else: l11ll111lll_l1_ = l1l111_l1_ (u"ࠩࠪ们")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡸࡪࡾࡴࠨ仭"): continue
			elif l1l111_l1_ (u"ࠫ࠱࠭仮") in l1l1111l11l1_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠬࡇࠫࡗࠩ仯")
				l1l1l1l111l1_l1_ = l111lll_l1_+l1l111_l1_ (u"࠭ࠠࠡࠩ仰")+l11ll111lll_l1_+dict[l1l111_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ仱")].split(l1l111_l1_ (u"ࠨࡺࠪ仲"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ仳"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ仴")
				l1l1l1l111l1_l1_ = l11ll111lll_l1_+dict[l1l111_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ仵")].split(l1l111_l1_ (u"ࠬࡾࠧ件"))[1]+l1l111_l1_ (u"࠭ࠠࠡࠩ价")+dict[l1l111_l1_ (u"ࠧࡧࡲࡶࠫ仸")]+l1l111_l1_ (u"ࠨࡨࡳࡷࠬ仹")+l1l111_l1_ (u"ࠩࠣࠤࠬ仺")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ任"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ仼")
				l1l1l1l111l1_l1_ = l11ll111lll_l1_+str(int(dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ份")])/1000)+l1l111_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ仾")+dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ仿")]+l1l111_l1_ (u"ࠨࡥ࡫ࠫ伀")+l1l111_l1_ (u"ࠩࠣࠤࠬ企")+l111lll_l1_
		except:
			l111l11l1ll_l1_ = traceback.format_exc()
			if l111l11l1ll_l1_!=l1l111_l1_ (u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭伂"): sys.stderr.write(l111l11l1ll_l1_)
		if l1l111_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ伃") in dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ伄")]: l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ伅")].split(l1l111_l1_ (u"ࠧࡥࡷࡵࡁࠬ伆"),1)[1].split(l1l111_l1_ (u"ࠨࠨࠪ伇"),1)[0]))
		elif l1l111_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ伈") in list(dict.keys()): l1l1lll111_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭伉")])/1000)
		else: l1l1lll111_l1_ = l1l111_l1_ (u"ࠫ࠵࠭伊")
		if l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伋") not in list(dict.keys()): l11ll111lll_l1_ = dict[l1l111_l1_ (u"࠭ࡳࡪࡼࡨࠫ伌")].split(l1l111_l1_ (u"ࠧࡹࠩ伍"))[1]
		else: l11ll111lll_l1_ = dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伎")]
		if l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ伏") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ伐")] = l1l111_l1_ (u"ࠫ࠵࠳࠰ࠨ休")
		dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ伒")] = l1l1l1ll1_l1_+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ伓")+l1l1l1l111l1_l1_+l1l111_l1_ (u"ࠧࠡࠢࠫࠫ伔")+l1l111111lll_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ伕")+dict[l1l111_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ伖")]+l1l111_l1_ (u"ࠪ࠭ࠬ众")
		dict[l1l111_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ优")] = l1l1l1l111l1_l1_.split(l1l111_l1_ (u"ࠬࠦࠠࠨ伙"))[0].split(l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ会"))[0]
		dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭伛")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伜")] = l111lll_l1_
		dict[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ伝")] = codecs
		dict[l1l111_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ伞")] = l1l1lll111_l1_
		dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伟")] = l11ll111lll_l1_
		l1l11111llll_l1_.append(dict)
	l1l11lll1l11_l1_,l1l11l1111ll_l1_,l1l1l11ll111_l1_,l1l1l11llll1_l1_,l11lllll111l_l1_ = [],[],[],[],[]
	l1l11lllllll_l1_,l1l1111lll11_l1_,l1l111lll1l1_l1_,l1l11lllll11_l1_,l1l1l11l111l_l1_ = [],[],[],[],[]
	if l1l11lll1ll1_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ传")] = l1l111_l1_ (u"࠭ࡁࠬࡘࠪ伡")
		dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ伢")] = l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ伣")
		dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ伤")] = dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ伥")]+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ伦")+dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ伧")]+l1l111_l1_ (u"࠭ࠠࠡࠩ伨")+l1l111_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ伩")
		dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ伪")] = l1l11lll1ll1_l1_
		dict[l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ伫")] = l1l111_l1_ (u"ࠪ࠴ࠬ伬")
		dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ伭")] = l1l111_l1_ (u"ࠬ࠿࠸࠸࠸࠸࠸࠸࠸࠱࠱ࠩ伮")
		l1l11111llll_l1_.append(dict)
	if l1l11l1lll11_l1_:
		l1l1l1111l1l_l1_,l1l111ll1l11_l1_ = l1l11l11ll_l1_(l1l11l1lll11_l1_)
		l1l11l1ll111_l1_ = list(zip(l1l1l1111l1l_l1_,l1l111ll1l11_l1_))
		for title,l1ll1ll_l1_ in l1l11l1ll111_l1_:
			dict = {}
			dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伯")] = l1l111_l1_ (u"ࠧࡂ࡙࠭ࠫ估")
			dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伱")] = l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ伲")
			dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ伳")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠩ伴") in title: dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伵")] = title.split(l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ伶"))[0].rsplit(l1l111_l1_ (u"ࠧࠡࠢࠪ伷"))[-1]
			else: dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伸")] = l1l111_l1_ (u"ࠩ࠴࠴ࠬ伹")
			if title.count(l1l111_l1_ (u"ࠪࠤࠥ࠭伺"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠫࠥࠦࠧ伻"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭似")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ伽")] = l1l111_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ伾")
			if title==l1l111_l1_ (u"ࠨ࠯࠴ࠫ伿"): dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佀")] = dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ佁")]+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ佂")+dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ佃")]+l1l111_l1_ (u"࠭ࠠࠡࠩ佄")+l1l111_l1_ (u"ࠧอ๊าอࠥึใ๋หࠪ佅")
			else: dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ但")] = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ佇")]+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ佈")+dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佉")]+l1l111_l1_ (u"ࠬࠦࠠࠨ佊")+dict[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ佋")]+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ佌")+dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ位")]
			l1l11111llll_l1_.append(dict)
	l1l11111llll_l1_ = sorted(l1l11111llll_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ低")]))
	if not l1l11111llll_l1_:
		l1lll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡹࡳࡢࡩࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ住"),html,re.DOTALL)
		l1lll1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࡢࡻࠣࡴࡸࡲࡸࠨ࠺࡝࡝࡟ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ佐"),html,re.DOTALL)
		l1l11ll1llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ佑"),html,re.DOTALL)
		l1l11lll1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ佒"),html,re.DOTALL)
		try: l1l11lll111l_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ体")][l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭佔")][l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ何")][l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ佖")][l1l111_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ佗")][0][l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ佘")]
		except: l1l11lll111l_l1_ = l1l111_l1_ (u"࠭ࠧ余")
		try: l1l11lll11l1_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ佚")][l1l111_l1_ (u"ࠨࡧࡵࡶࡴࡸࡓࡤࡴࡨࡩࡳ࠭佛")][l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡇ࡭ࡦࡲ࡯ࡨࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ作")][l1l111_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡐࡩࡸࡹࡡࡨࡧࡶࠫ佝")][0][l1l111_l1_ (u"ࠫࡷࡻ࡮ࡴࠩ佞")][0][l1l111_l1_ (u"ࠬࡺࡥࡹࡶࠪ佟")]
		except: l1l11lll11l1_l1_ = l1l111_l1_ (u"࠭ࠧ你")
		try: l11lllllllll_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫ佡")][l1l111_l1_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨ佢")]
		except: l11lllllllll_l1_ = l1l111_l1_ (u"ࠩࠪ佣")
		if l1lll1ll111_l1_ or l1lll1ll11l_l1_ or l1l11ll1llll_l1_ or l1l11lll1111_l1_ or l1l11lll111l_l1_ or l1l11lll11l1_l1_ or l11lllllllll_l1_:
			if   l1lll1ll111_l1_: message = l1lll1ll111_l1_[0]
			elif l1lll1ll11l_l1_: message = l1lll1ll11l_l1_[0]
			elif l1l11ll1llll_l1_: message = l1l11ll1llll_l1_[0]
			elif l1l11lll1111_l1_: message = l1l11lll1111_l1_[0]
			elif l1l11lll111l_l1_: message = l1l11lll111l_l1_
			elif l1l11lll11l1_l1_: message = l1l11lll11l1_l1_
			elif l11lllllllll_l1_: message = l11lllllllll_l1_
			l1l1l1l11111_l1_ = message.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭佤"),l1l111_l1_ (u"ࠫࠬ佥")).strip(l1l111_l1_ (u"ࠬࠦࠧ佦"))
			l1l1l11lllll_l1_ = l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้ำหࠥอไโ์า๎ํࠦแู๋้้้ࠣไส๋ࠢๆิ๊ࠦไ๊้ࠤ฿๐ัࠡ็็หห๋ࠠๅส฼ฺࠥอไๆีอาิ๋๊็ࠢฦ์ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ佧")
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ佨"),l1l111_l1_ (u"ࠨࠩ佩"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤํอไๆสิ้ั࠭佪"),l1l1l11lllll_l1_+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ佫")+l1l1l1l11111_l1_)
			return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧ࠾ࠥ࠭佬")+l1l1l1l11111_l1_,[],[]
		else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ佭"),[],[]
	l1l11111l111_l1_,l1l11111l11l_l1_,l1l11l111lll_l1_ = [],[],[]
	for dict in l1l11111llll_l1_:
		if dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ佮")]==l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭佯"):
			l1l11lll1l11_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ佰")])
			l1l11lllllll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ佱")]==l1l111_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ佲"):
			l1l11l1111ll_l1_.append(dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ佳")])
			l1l1111lll11_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ佴")]==l1l111_l1_ (u"࠭࡭ࡱࡦࠪ併"):
			title = dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佶")].replace(l1l111_l1_ (u"ࠨࡃ࠮࡚࠿ࠦࠠࠨ佷"),l1l111_l1_ (u"ࠩࠪ佸"))
			if l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ佹") not in list(dict.keys()): l11ll111lll_l1_ = l1l111_l1_ (u"ࠫ࠵࠭佺")
			else: l11ll111lll_l1_ = dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佻")]
			l1l11111l111_l1_.append([dict,{},title,l11ll111lll_l1_])
		else:
			title = dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ佼")].replace(l1l111_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ佽"),l1l111_l1_ (u"ࠨࠩ佾"))
			if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ使") not in list(dict.keys()): l11ll111lll_l1_ = l1l111_l1_ (u"ࠪ࠴ࠬ侀")
			else: l11ll111lll_l1_ = dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ侁")]
			l1l11111l111_l1_.append([dict,{},title,l11ll111lll_l1_])
			l1l1l11ll111_l1_.append(title)
			l1l111lll1l1_l1_.append(dict)
		l1l11ll1111l_l1_ = True
		if l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ侂") in list(dict.keys()):
			if l1l111_l1_ (u"࠭ࡡࡷ࠲ࠪ侃") in dict[l1l111_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ侄")]: l1l11ll1111l_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠨࡣࡹࡧࠬ侅") not in dict[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ來")] and l1l111_l1_ (u"ࠪࡱࡵ࠺ࡡࠨ侇") not in dict[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ侈")]: l1l11ll1111l_l1_ = False
		if dict[l1l111_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ侉")]==l1l111_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ侊") and dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ例")]!=l1l111_l1_ (u"ࠨ࠲࠰࠴ࠬ侌") and l1l11ll1111l_l1_==True:
			l11lllll111l_l1_.append(dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ侍")])
			l1l1l11l111l_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ侎")]==l1l111_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ侏") and dict[l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ侐")]!=l1l111_l1_ (u"࠭࠰࠮࠲ࠪ侑") and l1l11ll1111l_l1_==True:
			l1l1l11llll1_l1_.append(dict[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭侒")])
			l1l11lllll11_l1_.append(dict)
	for l1l11l1llll1_l1_ in l1l11lllll11_l1_:
		l1l1111ll1ll_l1_ = l1l11l1llll1_l1_[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ侓")]
		for l1l11ll1ll11_l1_ in l1l1l11l111l_l1_:
			l1l1l1l1l111_l1_ = l1l11ll1ll11_l1_[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ侔")]
			l11ll111lll_l1_ = l1l1l1l1l111_l1_+l1l1111ll1ll_l1_
			title = l1l11ll1ll11_l1_[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ侕")].replace(l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠥ࠭侖"),l1l111_l1_ (u"ࠬࡳࡰࡥࠢࠣࠫ侗"))
			title = title.replace(l1l11ll1ll11_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ侘")]+l1l111_l1_ (u"ࠧࠡࠢࠪ侙"),l1l111_l1_ (u"ࠨࠩ侚"))
			title = title.replace(str((float(l1l1l1l1l111_l1_*10)//1024/10))+l1l111_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ供"),str((float(l11ll111lll_l1_*10)//1024/10))+l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ侜"))
			title = title+l1l111_l1_ (u"ࠫ࠭࠭依")+l1l11l1llll1_l1_[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ侞")].split(l1l111_l1_ (u"࠭ࠨࠨ侟"),1)[1]
			l1l11111l111_l1_.append([l1l11ll1ll11_l1_,l1l11l1llll1_l1_,title,l11ll111lll_l1_])
	l1l11111l111_l1_ = sorted(l1l11111l111_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l11ll1ll11_l1_,l1l11l1llll1_l1_,title,l11ll111lll_l1_ in l1l11111l111_l1_:
		l1l11111ll11_l1_ = l1l11ll1ll11_l1_[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ侠")]
		if l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ価") in list(l1l11l1llll1_l1_.keys()):
			l1l11111ll11_l1_ = l1l111_l1_ (u"ࠩࡰࡴࡩ࠭侢")
		if l1l11111ll11_l1_ not in l1l11l111lll_l1_:
			l1l11l111lll_l1_.append(l1l11111ll11_l1_)
			l1l11111l11l_l1_.append([l1l11ll1ll11_l1_,l1l11l1llll1_l1_,title,l11ll111lll_l1_])
	l1l11l1l111l_l1_,l1l1l1111ll1_l1_,shift = [],[],0
	l1l11ll11l1l_l1_,l1l1l11l1111_l1_ = l1l111_l1_ (u"ࠪࠫ侣"),l1l111_l1_ (u"ࠫࠬ侤")
	try: l1l11ll11l1l_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ侥")][l1l111_l1_ (u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭侦")]
	except: l1l11ll11l1l_l1_ = l1l111_l1_ (u"ࠧࠨ侧")
	try: l1l111lllll1_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ侨")][l1l111_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ侩")]
	except: l1l111lllll1_l1_ = l1l111_l1_ (u"ࠪࠫ侪")
	if l1l11ll11l1l_l1_ and l1l111lllll1_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ侫")+l1l11ll11l1l_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ侬")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ侭")][0]+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ侮")+l1l111lllll1_l1_
		l1l11l1l111l_l1_.append(title)
		l1l1l1111ll1_l1_.append(l1ll1ll_l1_)
		try: l1l1l11l1111_l1_ = l1l1l111l1ll_l1_[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ侯")][l1l111_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ侰")][l1l111_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ侱")][-1][l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ侲")]
		except: pass
	for l1l11ll1ll11_l1_,l1l11l1llll1_l1_,title,l11ll111lll_l1_ in l1l11111l11l_l1_:
		l1l11l1l111l_l1_.append(title) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭侳"))
	if l1l1l11ll111_l1_: l1l11l1l111l_l1_.append(l1l111_l1_ (u"࠭ี้ำฬࠤํ฻่ห่ࠢัิีษࠨ侴")) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭侵"))
	if l1l11111l111_l1_: l1l11l1l111l_l1_.append(l1l111_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤฬ๊ๅห๊ไีࠬ侶")) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"ࠩࡤࡰࡱ࠭侷"))
	if l11lllll111l_l1_: l1l11l1l111l_l1_.append(l1l111_l1_ (u"ࠪࡱࡵࡪࠠศะอีࠥอไึ๊ิอࠥ๎วๅื๋ฮࠬ侸")) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶࡤࠨ侹"))
	if l1l11lll1l11_l1_: l1l11l1l111l_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣฬิ๎ๆࠡื๋ฮࠬ侺")) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ侻"))
	if l1l11l1111ll_l1_: l1l11l1l111l_l1_.append(l1l111_l1_ (u"ࠧึ๊อࠤอี่็ุࠢ์ึฯࠧ侼")) ; l1l1l1111ll1_l1_.append(l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ侽"))
	l1l1l11lll11_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l1l1111lll1l_l1_, l1l11l1l111l_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ侾"),[],[]
		elif l11l11l_l1_==0 and l1l11ll11l1l_l1_:
			l1ll1ll_l1_ = l1l1l1111ll1_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠲࠶࠴ࠪࡳࡧ࡭ࡦ࠿ࠪ便")+QUOTE(l1l11ll11l1l_l1_)+l1l111_l1_ (u"ࠫࠫࡻࡲ࡭࠿ࠪ俀")+l1ll1ll_l1_
			if l1l1l11l1111_l1_: new_path = new_path+l1l111_l1_ (u"ࠬࠬࡩ࡮ࡣࡪࡩࡂ࠭俁")+QUOTE(l1l1l11l1111_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ係")+new_path+l1l111_l1_ (u"ࠢࠪࠤ促"))
			return l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭俄"),[],[]
		choice = l1l1l1111ll1_l1_[l11l11l_l1_]
		l11llllll1l1_l1_ = l1l11l1l111l_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"ࠩࡧࡥࡸ࡮ࠧ俅"):
			l1l111lll11l_l1_ = l1l11lll1ll1_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ俆"),l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ俇"),l1l111_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ俈")]:
			if choice==l1l111_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ俉"): l1l1lll1_l1_,l1l11ll1l11l_l1_ = l1l1l11ll111_l1_,l1l111lll1l1_l1_
			elif choice==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭俊"): l1l1lll1_l1_,l1l11ll1l11l_l1_ = l1l11lll1l11_l1_,l1l11lllllll_l1_
			elif choice==l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ俋"): l1l1lll1_l1_,l1l11ll1l11l_l1_ = l1l11l1111ll_l1_,l1l1111lll11_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ俌"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l1l111lll11l_l1_ = l1l11ll1l11l_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠪࡹࡷࡲࠧ俍")]
				l11llllll1l1_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠫࡲࡶࡤࠨ俎"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํืษ࠻ࠩ俏"), l11lllll111l_l1_)
			if l11l11l_l1_!=-1:
				l11llllll1l1_l1_ = l11lllll111l_l1_[l11l11l_l1_]
				l1l111111111_l1_ = l1l1l11l111l_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ส࠻ࠩ俐"), l1l1l11llll1_l1_)
				if l11l11l_l1_!=-1:
					l11llllll1l1_l1_ += l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ俑")+l1l1l11llll1_l1_[l11l11l_l1_]
					l1l11l1l11l1_l1_ = l1l11lllll11_l1_[l11l11l_l1_]
					l1l1l11lll11_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ俒"):
			l1l111l1l111_l1_,l11llll1ll11_l1_,l1l1111l11ll_l1_,l1l1l11ll11l_l1_ = list(zip(*l1l11111l111_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ俓"), l1l1111l11ll_l1_)
			if l11l11l_l1_!=-1:
				l11llllll1l1_l1_ = l1l1111l11ll_l1_[l11l11l_l1_]
				l1l111111111_l1_ = l1l111l1l111_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠪࡱࡵࡪࠧ俔") in l1l1111l11ll_l1_[l11l11l_l1_] and l1l111111111_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俕")]!=l1l11lll1ll1_l1_:
					l1l11l1l11l1_l1_ = l11llll1ll11_l1_[l11l11l_l1_]
					l1l1l11lll11_l1_ = True
				else: l1l111lll11l_l1_ = l1l111111111_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俖")]
				break
		elif choice==l1l111_l1_ (u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧ俗"):
			l1l111l1l111_l1_,l11llll1ll11_l1_,l1l1111l11ll_l1_,l1l1l11ll11l_l1_ = list(zip(*l1l11111l11l_l1_))
			l1l111111111_l1_ = l1l111l1l111_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ俘") in l1l1111l11ll_l1_[l11l11l_l1_-shift] and l1l111111111_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ俙")]!=l1l11lll1ll1_l1_:
				l1l11l1l11l1_l1_ = l11llll1ll11_l1_[l11l11l_l1_-shift]
				l1l1l11lll11_l1_ = True
			else: l1l111lll11l_l1_ = l1l111111111_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭俚")]
			l11llllll1l1_l1_ = l1l1111l11ll_l1_[l11l11l_l1_-shift]
			break
	if not l1l1l11lll11_l1_: l1l1111lllll_l1_ = l1l111lll11l_l1_
	else: l1l1111lllll_l1_ = l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠫ俛")+l1l111111111_l1_[l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ俜")]+l1l111_l1_ (u"ࠬࠦࠫࠡࡃࡸࡨ࡮ࡵ࠺ࠡࠩ保")+l1l11l1l11l1_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ俞")]
	if l1l1l11lll11_l1_:
		l1l1l111llll_l1_ = int(l1l111111111_l1_[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ俟")])
		l1l111llll1l_l1_ = int(l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ俠")])
		l1l1lll111_l1_ = str(max(l1l1l111llll_l1_,l1l111llll1l_l1_))
		l1l1111ll1l1_l1_ = l1l111111111_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭信")].replace(l1l111_l1_ (u"ࠪࠪࠬ俢"),l1l111_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ俣"))
		l1l11l111l11_l1_ = l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ俤")].replace(l1l111_l1_ (u"࠭ࠦࠨ俥"),l1l111_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭俦"))
		l1l1l11l1l1l_l1_ = l1l111_l1_ (u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ俧")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪ俨")+l1l1lll111_l1_+l1l111_l1_ (u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩ俩")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ俪")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩ俫")+l1l111111111_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ俬")]+l1l111_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ俭")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭修")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ俯")+l1l111111111_l1_[l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ俰")]+l1l111_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ俱")+l1l111111111_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ俲")]+l1l111_l1_ (u"࠭ࠢࠡࡵࡷࡥࡷࡺࡗࡪࡶ࡫ࡗࡆࡖ࠽ࠣ࠳ࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣࠩ俳")+str(l1l111111111_l1_[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ俴")])+l1l111_l1_ (u"ࠨࠤࠣࡻ࡮ࡪࡴࡩ࠿ࠥࠫ俵")+str(l1l111111111_l1_[l1l111_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ俶")])+l1l111_l1_ (u"ࠪࠦࠥ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠧ俷")+str(l1l111111111_l1_[l1l111_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ俸")])+l1l111_l1_ (u"ࠬࠨࠠࡧࡴࡤࡱࡪࡘࡡࡵࡧࡀࠦࠬ俹")+l1l111111111_l1_[l1l111_l1_ (u"࠭ࡦࡱࡵࠪ俺")]+l1l111_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ俻")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ俼")+l1l1111ll1l1_l1_+l1l111_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ俽")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ俾")+l1l111111111_l1_[l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ俿")]+l1l111_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ倀")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ倁")+l1l111111111_l1_[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ倂")]+l1l111_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ倃")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ倄")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ倅")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ倆")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠵ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡤࡹࡩ࡯࡯࠰ࠩ倇")+l1l11l1l11l1_l1_[l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ倈")]+l1l111_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ倉")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭倊")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ個")+l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ倌")]+l1l111_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ倍")+l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ倎")]+l1l111_l1_ (u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩ倏")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭倐")+l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ們")]+l1l111_l1_ (u"ࠩࠥ࠳ࡃࡢ࡮ࠨ倒")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭倓")+l1l11l111l11_l1_+l1l111_l1_ (u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ倔")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ倕")+l1l11l1l11l1_l1_[l1l111_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ倖")]+l1l111_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ倗")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ倘")+l1l11l1l11l1_l1_[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ候")]+l1l111_l1_ (u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ倚")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ倛")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ倜")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ倝")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ倞")
		l1l1l11l1l1l_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡑࡕࡊ࠾࡝ࡰࠪ借")
		if PY3:
			import http.server as l1l11l111ll1_l1_
			import http.client as l1l11l11lll1_l1_
		else:
			import BaseHTTPServer as l1l11l111ll1_l1_
			import httplib as l1l11l11lll1_l1_
		class l1l11ll1l1l1_l1_(l1l11l111ll1_l1_.HTTPServer):
			def __init__(self,l1lll1l11l11_l1_=l1l111_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ倠"),port=55055,l1l1l11l1l1l_l1_=l1l111_l1_ (u"ࠪࡀࡃ࠭倡")):
				self.l1lll1l11l11_l1_ = l1lll1l11l11_l1_
				self.port = port
				self.l1l1l11l1l1l_l1_ = l1l1l11l1l1l_l1_
				l1l11l111ll1_l1_.HTTPServer.__init__(self,(self.l1lll1l11l11_l1_,self.port),l1l1l11l11ll_l1_)
				self.l1l11l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ倢")+l1lll1l11l11_l1_+l1l111_l1_ (u"ࠬࡀࠧ倣")+str(port)+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ値")
			def start(self):
				self.threads = l11l11l1lll_l1_(False)
				self.threads.start_new_thread(1,self.l1l111ll11l1_l1_)
			def l1l111ll11l1_l1_(self):
				self.l1l1111111l1_l1_ = True
				while self.l1l1111111l1_l1_:
					self.handle_request()
			def stop(self):
				self.l1l1111111l1_l1_ = False
				self.l1l11ll1l111_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l1l11l1l1l_l1_):
				self.l1l1l11l1l1l_l1_ = l1l1l11l1l1l_l1_
			def l1l11ll1l111_l1_(self):
				conn = l1l11l11lll1_l1_.HTTPConnection(self.l1lll1l11l11_l1_+l1l111_l1_ (u"ࠧ࠻ࠩ倥")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠣࡊࡈࡅࡉࠨ倦"), l1l111_l1_ (u"ࠤ࠲ࠦ倧"))
		class l1l1l11l11ll_l1_(l1l11l111ll1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ倨"),l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ倩"))
				self.end_headers()
				self.wfile.write(self.server.l1l1l11l1l1l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ倪")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ倫"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ倬"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l11ll1l1l1_l1_(l1l111_l1_ (u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫ倭"),55055,l1l1l11l1l1l_l1_)
		l1l111lll11l_l1_ = httpd.l1l11l1ll1ll_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"ࠩࠪ倮")
	if not l1l111lll11l_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ倯"),[],[]
	return l1l111_l1_ (u"ࠫࠬ倰"),[l1l111_l1_ (u"ࠬ࠭倱")],[[l1l111lll11l_l1_,l1l11llll111_l1_,httpd]]
def l1l11l1ll11l_l1_(url):
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ倲") : l1l111_l1_ (u"ࠧࠨ倳") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ倴"),headers,l1l111_l1_ (u"ࠩࠪ倵"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡅࡓࡇ࠳࠱ࡴࡶࠪ倶"))
	items = re.findall(l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࢀ࠮ࡢࡽࠨ倷"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l1l1111l1l_l1_,l1l1lll1_l1_,l1l111ll1l11_l1_,l1llll_l1_ = [],[],[],[]
	if not items: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡆࡔࡈࠧ倸"),[],[]
	for l1ll1ll_l1_,dummy,l1llll1lllll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭倹"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭债"))
		if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ倻") in l1ll1ll_l1_:
			l1l1l1111l1l_l1_,l1l111ll1l11_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_)
			l1llll_l1_ = l1llll_l1_ + l1l111ll1l11_l1_
			if l1l1l1111l1l_l1_[0]==l1l111_l1_ (u"ࠩ࠰࠵ࠬ值"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭倽")+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮࠵ࡸ࠼ࠬ倾"))
			else:
				for title in l1l1l1111l1l_l1_:
					l1l1lll1_l1_.append(l1l111_l1_ (u"ู๊ࠬาใิࠤำอีࠨ倿")+l1l111_l1_ (u"࠭ࠠࠡࠢࠪ偀")+title)
		else:
			title = l1l111_l1_ (u"ࠧิ์ิๅึࠦฮศืࠪ偁")+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡶ࠴ࠡࠢࠣࠫ偂")+l1llll1lllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	return l1l111_l1_ (u"ࠩࠪ偃"),l1l1lll1_l1_,l1llll_l1_
def l1l111lll111_l1_(url,html):
	l111llll11_l1_,l1ll11l1_l1_,l11lllllll1l_l1_,l1llll1lll1_l1_,l1ll_l1_ = [],[],[],[],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ偄"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠫ࠳࠭偅"),1)[1]
		l111llll11_l1_.append(title)
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	else:
		l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠࠫࠪ࡟࡟࠳࠰࠿࡝࡟ࠬࠫ偆"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡷࡴࡻࡲࡤࡧࡶࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪࠩ假"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤ࡯ࡽࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬ偈"),html,re.DOTALL)
		if not l1lll1l1_l1_: l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡶ࡬ࡢࡻࡨࡶࠥࡃࠠ࠯ࠬࡂࡠ࠭࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩ࡝ࠫࠪ偉"),html,re.DOTALL)
		if l1lll1l1_l1_:
			l1lll1l1_l1_ = l1lll1l1_l1_[0]
			l1l11llll11l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡞࠰ࡡࢁ࡝ࠡࠬࠫࡠࡼ࠱ࠩ࠻ࠩ偊"),l1lll1l1_l1_,re.DOTALL)
			for key in list(set(l1l11llll11l_l1_)): l1lll1l1_l1_ = l1lll1l1_l1_.replace(key+l1l111_l1_ (u"ࠪ࠾ࠬ偋"),l1l111_l1_ (u"ࠫࠧ࠭偌")+key+l1l111_l1_ (u"ࠬࠨ࠺ࠨ偍"))
			l1lll1l1_l1_ = eval(l1lll1l1_l1_)
			if isinstance(l1lll1l1_l1_,dict): l1lll1l1_l1_ = [l1lll1l1_l1_]
			for block in l1lll1l1_l1_:
				if isinstance(block,dict):
					keys = list(block.keys())
					if l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࠫ偎") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࠬ偏")]
					elif l1l111_l1_ (u"ࠨࡪ࡯ࡷࠬ偐") in keys: l1ll1ll_l1_ = block[l1l111_l1_ (u"ࠩ࡫ࡰࡸ࠭偑")]
					if l1l111_l1_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ偒") in keys: title = str(block[l1l111_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ偓")])
					elif l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡣ࡭࡫ࡩࡨࡪࡷࠫ偔") in keys: title = str(block[l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬ偕")])
					else: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠧ࠯ࠩ偖"),1)[1]
				elif isinstance(block,str):
					l1ll1ll_l1_ = block
					title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠨ࠰ࠪ偗"),1)[1]
				l111llll11_l1_.append(title)
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	for l1ll1ll_l1_,title in zip(l1ll11l1_l1_,l111llll11_l1_):
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭偘"),l1l111_l1_ (u"ࠪ࠳ࠬ偙"))
		l11lll1lll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ做"))
		l11ll1l1ll_l1_ = l1l1ll11l_l1_()
		if l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ偛") in l1ll1ll_l1_:
			headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ停"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ偝"):l11lll1lll_l1_}
			l11lllllll11_l1_,l1l11l1l1l1l_l1_ = l1l11l11ll_l1_(l1ll1ll_l1_,headers)
			l1llll1lll1_l1_ += l1l11l1l1l1l_l1_
			l11lllllll1l_l1_ += l11lllllll11_l1_
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ偞")+l11ll1l1ll_l1_+l1l111_l1_ (u"ࠩࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ偟")+l11lll1lll_l1_
			l1llll1lll1_l1_.append(l1ll1ll_l1_)
			l11lllllll1l_l1_.append(title)
	if l1llll1lll1_l1_: return l1l111_l1_ (u"ࠪࠫ偠"),l11lllllll1l_l1_,l1llll1lll1_l1_
	return l1l111_l1_ (u"ࠫࠬ偡"),[],[]
def l1l1l1l1l11l_l1_(seq,url):
	global l1lll_l1_
	url = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ偢"))
	l1lll111ll11_l1_,payload = l1l111_l1_ (u"࠭ࠧ偣"),{}
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ偤"):l1l1ll11l_l1_()}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ健"),url,l1l111_l1_ (u"ࠩࠪ偦"),headers,l1l111_l1_ (u"ࠪࠫ偧"),False,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭偨"))
	html = response.content
	if not isinstance(html,str): html = html.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ偩"),l1l111_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭偪"))
	if l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭偫") in html:
		l11111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ偬"),html,re.DOTALL)
		if l11111llll1_l1_:
			try: l1lll111ll11_l1_ = l1lll1l1l1l1_l1_(l11111llll1_l1_[0])
			except: l1lll111ll11_l1_ = l1l111_l1_ (u"ࠩࠪ偭")
	l11l1ll1_l1_ = html+l1lll111ll11_l1_
	if l1l111_l1_ (u"ࠪࠦ࡮ࡪ࠲ࠣࠩ偮") in l11l1ll1_l1_ or l1l111_l1_ (u"ࠫࠧ࡯ࡤࠣࠩ偯") in l11l1ll1_l1_:
		l1l11ll1lll1_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ偰"))[3].replace(l1l111_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭偱"),l1l111_l1_ (u"ࠧࠨ偲")).replace(l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ偳"),l1l111_l1_ (u"ࠩࠪ側"))
		if l1l111_l1_ (u"ࠪࠦ࡮ࡪ࠲ࠣࠩ偵") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠫ࡮ࡪ࠲ࠨ偶"):l1l11ll1lll1_l1_,l1l111_l1_ (u"ࠬࡵࡰࠨ偷"):l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ偸")}
		elif l1l111_l1_ (u"ࠧࠣ࡫ࡧࠦࠬ偹") in l11l1ll1_l1_: payload = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ偺"):l1l11ll1lll1_l1_,l1l111_l1_ (u"ࠩࡲࡴࠬ偻"):l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭偼")}
		l1ll1ll1l_l1_ = headers.copy()
		l1ll1ll1l_l1_[l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ偽")] = l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ偾")
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ偿"),url,payload,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ傀"),False,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ傁"))
		l1ll1lll1_l1_ = response.content
		l1l1111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ傂"),l1ll1lll1_l1_,re.DOTALL)
		if l1l1111llll1_l1_:
			l1lll_l1_[seq] = l1l111_l1_ (u"ࠪࠫ傃"),[l1l111_l1_ (u"ࠫࠬ傄")],[l1l1111llll1_l1_[0]]
			return
	l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111lll111_l1_(url,l11l1ll1_l1_)
	if l1llll_l1_:
		l1lll_l1_[seq] = l1l1l111l11l_l1_,l1l1lll1_l1_,l1llll_l1_
		return
	l1lll_l1_[seq] = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡕࡋࡅࡗࡏࡎࡈࠩ傅"),[],[]
	return
def l1l11111l1l1_l1_(url):
	global l1lll_l1_
	l1lll_l1_ = {}
	thread = threading.Thread(target=l1l1l1l1l11l_l1_,args=(999,url))
	thread.start()
	thread.join(5)
	if l1lll_l1_[999][2]: return l1lll_l1_[999]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ傆"))
	headers = {l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ傇"):l1l1ll11l_l1_()}
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ傈"),l1l11ll_l1_,l1l111_l1_ (u"ࠩࠪ傉"),headers,l1l111_l1_ (u"ࠪࠫ傊"),False,l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡗࡏࡘࡎࡥࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ傋"))
	if not response.succeeded: return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ傌"),[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ傍"),l1l111_l1_ (u"ࠧ࠰ࠩ傎"))
	parts = re.findall(l1l111_l1_ (u"ࠨࡠࠫ࠲࠯ࡅ࠺࠰࠱࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࠩ࠭傏"),l1lllll1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ傐"),re.DOTALL)
	start,l1l111l11l11_l1_,end = parts[0]
	end = end.strip(l1l111_l1_ (u"ࠪ࠳ࠬ傑"))
	l1l11l11l1l1_l1_ = len(l1l111l11l11_l1_)<4 or l1l111l11l11_l1_ in [l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࠩ傒"),l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ傓"),l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࡪࡳࡢࡦࡦࠪ傔")]
	l1ll_l1_,seq = [],0
	l1ll_l1_.append([0,start+l1l111_l1_ (u"ࠧ࠰ࠩ傕")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ傖")+end])
	if not l1l11l11l1l1_l1_: l1ll_l1_.append([1,start+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ傗")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ傘")+end])
	if end: l1ll_l1_.append([2,start+l1l111_l1_ (u"ࠫ࠴࠭備")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭傚")+end])
	if l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ傛") in l1l111l11l11_l1_:
		l1l11ll1ll1l_l1_ = l1l111l11l11_l1_.replace(l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭傜"),l1l111_l1_ (u"ࠨࠩ傝"))
		l1ll_l1_.append([3,start+l1l111_l1_ (u"ࠩ࠲ࠫ傞")+l1l11ll1ll1l_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ傟")+end])
		l1ll_l1_.append([4,start+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ傠")+l1l11ll1ll1l_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ傡")+end])
		if end: l1ll_l1_.append([5,start+l1l111_l1_ (u"࠭࠯ࠨ傢")+l1l11ll1ll1l_l1_+l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ傣")+end])
	elif l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ傤") in end:
		l1l1l1111111_l1_ = end.replace(l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ傥"),l1l111_l1_ (u"ࠪࠫ傦"))
		l1ll_l1_.append([6,start+l1l111_l1_ (u"ࠫ࠴࠭傧")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ储")+l1l1l1111111_l1_])
		if not l1l11l11l1l1_l1_: l1ll_l1_.append([7,start+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ傩")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ傪")+l1l1l1111111_l1_])
		l1ll_l1_.append([8,start+l1l111_l1_ (u"ࠨ࠱ࠪ傫")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ催")+l1l1l1111111_l1_])
	else:
		if not l1l11l11l1l1_l1_: l1ll_l1_.append([9,start+l1l111_l1_ (u"ࠪ࠳ࠬ傭")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ傮")])
		if not l1l11l11l1l1_l1_: l1ll_l1_.append([10,start+l1l111_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭傯")+l1l111l11l11_l1_+l1l111_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ傰")])
		if end: l1ll_l1_.append([11,start+l1l111_l1_ (u"ࠧ࠰ࠩ傱")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ傲")+end+l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ傳")])
		if end: l1ll_l1_.append([12,start+l1l111_l1_ (u"ࠪ࠳ࠬ傴")+l1l111l11l11_l1_+l1l111_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ債")+end+l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ傶")])
	if l1l11l11l1l1_l1_ and end:
		end = end.replace(l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ傷"),l1l111_l1_ (u"ࠧ࠰ࠩ傸"))
		l1ll_l1_.append([13,start+l1l111_l1_ (u"ࠨ࠱ࠪ傹")+end])
		l1ll_l1_.append([14,start+l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ傺")+end])
		if l1l111_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ傻") in end:
			l1l1l1111111_l1_ = end.replace(l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ傼"),l1l111_l1_ (u"ࠬ࠭傽"))
			l1ll_l1_.append([15,start+l1l111_l1_ (u"࠭࠯ࠨ傾")+l1l1l1111111_l1_])
			l1ll_l1_.append([16,start+l1l111_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ傿")+l1l1l1111111_l1_])
		else:
			l1ll_l1_.append([17,start+l1l111_l1_ (u"ࠨ࠱ࠪ僀")+end+l1l111_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ僁")])
			l1ll_l1_.append([18,start+l1l111_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ僂")+end+l1l111_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ僃")])
	for l1l1l1111l_l1_,l1ll1ll_l1_ in l1ll_l1_:
		if l1ll1ll_l1_==url: continue
		l1lll_l1_[l1l1l1111l_l1_] = [None,None,None]
		thread = threading.Thread(target=l1l1l1l1l11l_l1_,args=(l1l1l1111l_l1_,l1ll1ll_l1_))
		thread.start()
		time.sleep(0.5)
		threads.append(thread)
	for thread in threads: thread.join(5)
	for l1l1l1111l_l1_,l1ll1ll_l1_ in l1ll_l1_:
		if l1lll_l1_[l1l1l1111l_l1_][2]: return l1lll_l1_[l1l1l1111l_l1_]
	time.sleep(1)
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡗࡏࡘࡎࡥࡘࡔࡊࡄࡖࡎࡔࡇࠨ僄"),[],[]
def l1l1111l1l11_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ僅"),l1l111_l1_ (u"ࠧࠨ僆"),l1l111_l1_ (u"ࠨࠩ僇"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ僈"))
	items = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ僉"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ僊"),[l1l111_l1_ (u"ࠬ࠭僋")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ僌"),[],[]
def l1l11l1ll1l1_l1_(url):
	return l1l111_l1_ (u"ࠧࠨ働"),[l1l111_l1_ (u"ࠨࠩ僎")],[ url ]
def l1l1l11111ll_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ像"))
	basename = l1l111_l1_ (u"ࠪ࠳ࠬ僐").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ僑"),l1l111_l1_ (u"ࠬ࠭僒"),l1l111_l1_ (u"࠭ࠧ僓"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ僔"))
	items = re.findall(l1l111_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ僕"),html,re.DOTALL)
	if items:
		l1l1llll1lll_l1_,l1l1lllllll1_l1_,l1l1llllllll_l1_,l1l1l11l1ll1_l1_,l1l1l11l1lll_l1_,l1l1l11l1l11_l1_ = items[0]
		var = int(l1l1lllllll1_l1_) % int(l1l1llllllll_l1_) + int(l1l1l11l1ll1_l1_) % int(l1l1l11l1lll_l1_)
		url = basename + l1l1llll1lll_l1_ + str(var) + l1l1l11l1l11_l1_
		return l1l111_l1_ (u"ࠩࠪ僖"),[l1l111_l1_ (u"ࠪࠫ僗")],[url]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࡚ࠦࡊࡒࡓ࡝ࡘࡎࡁࡓࡇࠪ僘"),[],[]
def l1l1l11111l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ僙"))[-1]
	headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ僚") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭僛") }
	payload = { l1l111_l1_ (u"ࠣ࡫ࡧࠦ僜"):id , l1l111_l1_ (u"ࠤࡲࡴࠧ僝"):l1l111_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷ࠨ僞") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ僟"), url, payload, headers, l1l111_l1_ (u"ࠬ࠭僠"),l1l111_l1_ (u"࠭ࠧ僡"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ僢"))
	if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ僣") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ僤")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠪࠫ僥"),[l1l111_l1_ (u"ࠫࠬ僦")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡒ࠷࡙ࡕࡒࡏࡂࡆࠪ僧"),[],[]
def l11llll1lll1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ僨"),l1l111_l1_ (u"ࠧࠨ僩"),l1l111_l1_ (u"ࠨࠩ僪"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬ僫"))
	items = re.findall(l1l111_l1_ (u"ࠪࡱࡵ࠺࠺ࠡ࡞࡞ࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭僬"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ僭"),[l1l111_l1_ (u"ࠬ࠭僮")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡌࡒ࡙࡜ࡌࡊࡘࡈࠫ僯"),[],[]
def l1l111111l1l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ僰"),l1l111_l1_ (u"ࠨࠩ僱"),l1l111_l1_ (u"ࠩࠪ僲"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡅࡋࡍ࡛ࡋ࠭࠲ࡵࡷࠫ僳"))
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ僴"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ僵") + items[0]
		return l1l111_l1_ (u"࠭ࠧ僶"),[l1l111_l1_ (u"ࠧࠨ僷")],[ url ]
	else: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ僸"),[],[]
def l1l11111lll1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ價"),l1l111_l1_ (u"ࠪࠫ僺"),l1l111_l1_ (u"ࠫࠬ僻"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭僼"))
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭僽"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠧࠨ僾"),[l1l111_l1_ (u"ࠨࠩ僿")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ儀"),[],[]
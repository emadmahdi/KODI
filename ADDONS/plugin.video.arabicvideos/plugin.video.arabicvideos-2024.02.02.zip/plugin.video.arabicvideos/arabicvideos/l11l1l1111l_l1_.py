# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ垰")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭垱")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ垲"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l11l1l11l111_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垳"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ垴"),l1l111_l1_ (u"ࠫࠬ垵"),319,l1l111_l1_ (u"ࠬ࠭垶"),l1l111_l1_ (u"࠭ࠧ垷"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ垸"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ垹"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ垺"),l1l111_l1_ (u"ࠪࠫ垻"),l1l111_l1_ (u"ࠫࠬ垼"),l1l111_l1_ (u"ࠬ࠭垽"),l1l111_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ垾"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶ࡮࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ垿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭埀"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ埁"),l1l111_l1_ (u"ࠪࠫ埂"),9999)
	items = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠵࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠸ࡂࠬ埃"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠬࠦࠧ埄"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埅"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ埆")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"ࠨࠩ埇"),l1l111_l1_ (u"ࠩࠪ埈"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埉"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭埊")+l1lllll_l1_+l1l111_l1_ (u"๋ࠬโศู฼ࠤูํัࠨ埋"),l111l1_l1_,314,l1l111_l1_ (u"࠭ࠧ埌"),l1l111_l1_ (u"ࠧࠨ埍"),l1l111_l1_ (u"ࠨ࠲ࠪ城"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ埏"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ埐"),l1l111_l1_ (u"ࠫࠬ埑"),9999)
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡃࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡅࡂࠬ埒"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ埓")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ埔"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ埕")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭埖"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ埗"),l1l111_l1_ (u"ࠫࠬ埘"),l1l111_l1_ (u"ࠬ࠭埙"),l1l111_l1_ (u"࠭ࠧ埚"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡐࡆ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ埛"))
	html = response.content
	if seq==l1l111_l1_ (u"ࠨ࠲ࠪ埜"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷࡥࡧ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ埝"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埞"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭域")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ埠"))
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ埡"))
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ埢")+name+l1l111_l1_ (u"ࠨࠫࠪ埣")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ埤"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠪ࠵ࠬ埥"),l1l111_l1_ (u"ࠫ࠷࠭埦"),l1l111_l1_ (u"ࠬ࠹ࠧ埧")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡰ࡬࠭埨"),html,re.DOTALL)
		l11l1l11l11l_l1_ = int(seq)-1
		block = l11llll_l1_[l11l1l11l11l_l1_]
		if seq==l1l111_l1_ (u"ࠧ࠲ࠩ埩"): items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埪"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ埫"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ埬")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭埭")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ埮"))
			name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ埯"))
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ埰")+name+l1l111_l1_ (u"ࠨࠫࠪ埱")
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ埲"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠪ࠸ࠬ埳"),l1l111_l1_ (u"ࠫ࠺࠭埴"),l1l111_l1_ (u"ࠬ࠼ࠧ埵")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠽ࡪ࠸ࡂ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ埶"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠯ࠬࡂ࠱ࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ執"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll1l11l1l_l1_,title,l11111111l_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ埸")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ培")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ基"))
			l1ll1l11l1l_l1_ = l1ll1l11l1l_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭埻"))
			l11111111l_l1_ = l11111111l_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ埼"))
			if l1ll1l11l1l_l1_: name = l1ll1l11l1l_l1_
			else: name = l11111111l_l1_
			title = title+l1l111_l1_ (u"࠭ࠠࠩࠩ埽")+name+l1l111_l1_ (u"ࠧࠪࠩ埾")
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ埿"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭堀"),url,l1l111_l1_ (u"ࠪࠫ堁"),l1l111_l1_ (u"ࠫࠬ堂"),l1l111_l1_ (u"ࠬ࠭堃"),l1l111_l1_ (u"࠭ࠧ堄"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ堅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡥࡳࡽ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡬ࡰࡣࡷ࠱ࡷ࡯ࡧࡩࡶࠪ堆"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠩࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠩ堇") in block:
		items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ堈"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭堉")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ堊")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"࠭ࠠศๆุ์ฯ๐ษ࠻ࠢࠪ堋"),l1l111_l1_ (u"ࠧ࠻ࠩ堌"))
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ堍"))
				title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ堎")+count+l1l111_l1_ (u"ࠪ࠭ࠬ堏")
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堐"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ堑"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l11l1l11l1l1_l1_,l1l1lll111_l1_ in items:
			if title==l1l111_l1_ (u"࠭ࠧ堒") or l11l1l11l1l1_l1_==l1l111_l1_ (u"ࠧࠨ堓"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ堔")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ堕")+l1l1lll111_l1_+l1l111_l1_ (u"ࠪ࠭ࠬ堖")
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ堗"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭堘"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ堙"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1lll111_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ堚")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ堛"))
		name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ堜"))
		title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭堝")+name+l1l111_l1_ (u"ࠫ࠮࠭堞")
		addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ堟"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"࠭ࠧ堠"),l1l1lll111_l1_)
	return
def l11l1l11l111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ堡"),url,l1l111_l1_ (u"ࠨࠩ堢"),l1l111_l1_ (u"ࠩࠪ堣"),l1l111_l1_ (u"ࠪࠫ堤"),l1l111_l1_ (u"ࠫࠬ堥"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈࡠࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ堦"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠥࡶ࠭࠲ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠧ堧"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ堨"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ堩")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ堪"))
		if l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠯ࠪ堫") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ堬"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堭"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ堮"),url,l1l111_l1_ (u"ࠧࠨ堯"),l1l111_l1_ (u"ࠨࠩ堰"),l1l111_l1_ (u"ࠩࠪ報"),l1l111_l1_ (u"ࠪࠫ堲"),l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ堳"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡡࡶࡦ࡬ࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ場"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡷ࡫ࡧࡩࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堵"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭堶"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ堷"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ堸"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ堹"),l1l111_l1_ (u"ࠫ࠰࠭堺"))
	l11l1l11l1ll_l1_ = [l1l111_l1_ (u"ࠬࠬࡴ࠾ࡣࠪ堻"),l1l111_l1_ (u"࠭ࠦࡵ࠿ࡦࠫ堼"),l1l111_l1_ (u"ࠧࠧࡶࡀࡷࠬ堽")]
	if l11_l1_:
		l11l1l111lll_l1_ = [l1l111_l1_ (u"ࠨไสีห࠭堾"),l1l111_l1_ (u"ࠩศูิอัࠡ࠱้ࠣั๊ฯࠨ堿"),l1l111_l1_ (u"้ࠪ็฽ูࠡษ็ูํะ๊ࠨ塀")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦ࠭ࠡลัฮึࠦวๅสะฯࠬ塁"), l11l1l111lll_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫ塂") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࡢࠫ塃") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆ࡛ࡄࡊࡑࡖࡣࠬ塄") in options: l11l11l_l1_ = 2
	else: return
	type = l11l1l11l1ll_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩ塅")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭塆"),url,l1l111_l1_ (u"ࠪࠫ塇"),l1l111_l1_ (u"ࠫࠬ塈"),l1l111_l1_ (u"ࠬ࠭塉"),l1l111_l1_ (u"࠭ࠧ塊"),l1l111_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ塋"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ塌"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ塍"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ塎"))
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭塏"))
				title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ塐")+name+l1l111_l1_ (u"࠭ࠩࠨ塑")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塒"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯ࡵࡦࡁࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ塓"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ塔"))
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ塕"))
				title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ塖")+name+l1l111_l1_ (u"ࠬ࠯ࠧ塗")
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ塘"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ⎂")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡈࡘࡢࠫ⎃")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==220: l1lll_l1_ = l1l1l11_l1_()
	elif mode==221: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==222: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==223: l1lll_l1_ = PLAY(url)
	elif mode==224: l1lll_l1_ = l1l1ll1l_l1_(url)
	elif mode==229: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎄"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⎅"),l1l111_l1_ (u"ࠨࠩ⎆"),229,l1l111_l1_ (u"ࠩࠪ⎇"),l1l111_l1_ (u"ࠪࠫ⎈"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⎉"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⎊"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎋"),l1l111_l1_ (u"ࠧࠨ⎌"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⎍"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ⎎"),l1l111_l1_ (u"ࠪࠫ⎏"),l1l111_l1_ (u"ࠫࠬ⎐"),l1l111_l1_ (u"ࠬ࠭⎑"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⎒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࠢ࡬࠱࡭ࡵ࡭ࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⎓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⎔"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠩ࠿࠳࡮ࡄࠧ⎕") in title: title = title.split(l1l111_l1_ (u"ࠪࡀ࠴࡯࠾ࠨ⎖"))[1]
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎗"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎘")+l1lllll_l1_+title,l1ll1ll_l1_,222)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⎙"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎚"),l1l111_l1_ (u"ࠨࠩ⎛"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡥ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࠪ⎜"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡴࡩࡧࠠࡣࡦࡥࠦࡃࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⎝"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎞"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎟")+l1lllll_l1_+title,l1ll1ll_l1_,221)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⎠"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎡"),l1l111_l1_ (u"ࠨࠩ⎢"),9999)
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⎣"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪ࡬ࡹࡳ࡬ࠨ⎤") not in l1ll1ll_l1_: continue
			if not l1ll1ll_l1_.endswith(l1l111_l1_ (u"ࠫ࠴࠭⎥")): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎦"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎧")+l1lllll_l1_+title,l1ll1ll_l1_,221)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⎨"),url,l1l111_l1_ (u"ࠨࠩ⎩"),l1l111_l1_ (u"ࠩࠪ⎪"),l1l111_l1_ (u"ࠪࠫ⎫"),l1l111_l1_ (u"ࠫࠬ⎬"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⎭"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡴࡡࡶࡧࡷࡵ࡬࡭ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⎮"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⎯"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎰"),l1lllll_l1_+title,l1ll1ll_l1_,224)
	return
def l1l1ll1l_l1_(url):
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎱"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ⎲"),url,221)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ⎳"),l1l111_l1_ (u"ࠬ࠭⎴"),l1l111_l1_ (u"࠭ࠧ⎵"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⎶"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡸࡦࡤࡴࡡࡷࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵࠪ⎷"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⎸"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠪࠧࠬ⎹"): name = title
			else:
				title = title + l1l111_l1_ (u"ࠫࠥࠦ࠺ࠡࠢࠪ⎺") + l1l111_l1_ (u"ࠬ็ไหำࠣࠫ⎻") + name
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎼"),l1lllll_l1_+title,l1ll1ll_l1_,221)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠧ࠲ࠩ⎽")):
	if l1llllll1_l1_==l1l111_l1_ (u"ࠨࠩ⎾"): l1llllll1_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ⎿")
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ⏀") in url or l1l111_l1_ (u"ࠫࡄ࠭⏁") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠬࠬࠧ⏂")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"࠭࠿ࠨ⏃")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭⏄") + l1llllll1_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⏅"),l1l111_l1_ (u"ࠩࠪ⏆"),l1l111_l1_ (u"ࠪࠫ⏇"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⏈"))
	if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭⏉") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡥࡣࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ⏊"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⏋") in url:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠠࡰࡹ࡯࠱ࡨࡧࡲࡰࡷࡶࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ⏌"),html,re.DOTALL)
		block = l11llll_l1_[0]
	else:
		l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⏍"),html,re.DOTALL)
		block = l11llll_l1_[-1]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⏎"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࠬ⏏") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ⏐") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⏑"),l1lllll_l1_+title,l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩ⏒")),223,l1ll1l_l1_)
		else:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏓"),l1lllll_l1_+title,l1ll1ll_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l11l1l1l1l_l1_ = [l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ⏔"),l1l111_l1_ (u"ࠪ࠳ࡹࡼࠧ⏕"),l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ⏖"),l1l111_l1_ (u"ࠬ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ⏗")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l1l_l1_):
			for n in range(0,1000,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏘"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⏙")+str(j),url,221,l1l111_l1_ (u"ࠨࠩ⏚"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏛"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ⏜")+str(i),url,221,l1l111_l1_ (u"ࠫࠬ⏝"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏞"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⏟")+str(1),url,221,l1l111_l1_ (u"ࠧࠨ⏠"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏡"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⏢")+str(n),url,221,l1l111_l1_ (u"ࠪࠫ⏣"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏤"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⏥")+str(1),url,221)
	return
def PLAY(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ⏦"),l1l111_l1_ (u"ࠧࠨ⏧"),l1l111_l1_ (u"ࠨࠩ⏨"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⏩"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡹࡪ࠾ศๆอู๋๐แ࠽࠱ࡷࡨࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⏪"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1l111ll1_l1_,l1l1l11ll_l1_ = l1l111_l1_ (u"ࠫࠬ⏫"),l1l111_l1_ (u"ࠬ࠭⏬")
	l111l1l11l_l1_,l111l11l1l_l1_ = html,html
	l111l1l111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡩࡱࡺࡣࡩࡲࠠࡢࡲ࡬ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⏭"),html,re.DOTALL)
	if l111l1l111_l1_:
		for l1ll1ll_l1_ in l111l1l111_l1_:
			if l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ⏮") in l1ll1ll_l1_: l1l111ll1_l1_ = l1ll1ll_l1_
			elif l1l111_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ⏯") in l1ll1ll_l1_: l1l1l11ll_l1_ = l1ll1ll_l1_
		if l1l111ll1_l1_!=l1l111_l1_ (u"ࠩࠪ⏰"): l111l1l11l_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l111ll1_l1_,l1l111_l1_ (u"ࠪࠫ⏱"),l1l111_l1_ (u"ࠫࠬ⏲"),l1l111_l1_ (u"ࠬ࠭⏳"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ⏴"))
		if l1l1l11ll_l1_!=l1l111_l1_ (u"ࠧࠨ⏵"): l111l11l1l_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1l1l11ll_l1_,l1l111_l1_ (u"ࠨࠩ⏶"),l1l111_l1_ (u"ࠩࠪ⏷"),l1l111_l1_ (u"ࠪࠫ⏸"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ⏹"))
	l111l1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⏺"),l111l1l11l_l1_,re.DOTALL)
	if l111l1l1l1_l1_:
		l1lllll1_l1_ = l111l1l1l1_l1_[0]
		if l1lllll1_l1_!=l1l111_l1_ (u"࠭ࠧ⏻") and l1l111_l1_ (u"ࠧࡶࡲ࡯ࡳࡦࡪࡥࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⏼") in l1lllll1_l1_ and l1l111_l1_ (u"ࠨ࠱ࡂ࡭ࡩࡃ࡟ࠨ⏽") not in l1lllll1_l1_:
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⏾"),l1l111_l1_ (u"ࠪࠫ⏿"),l1l111_l1_ (u"ࠫࠬ␀"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ␁"))
			l111l11ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ␂"),l11l1ll1_l1_,re.DOTALL)
			if l111l11ll1_l1_:
				for l1ll1ll_l1_,l111l1ll_l1_ in l111l11ll1_l1_:
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡦࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩࡵ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯ࡳ࠸ࡤࡥࠧ␃")+l111l1ll_l1_)
			else:
				server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ␄"))[2]
				l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ␅")+server+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ␆"))
		elif l1lllll1_l1_!=l1l111_l1_ (u"ࠫࠬ␇"):
			server = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ␈"))[2]
			l1llll_l1_.append(l1lllll1_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ␉")+server+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ␊"))
	l111l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡥࡧࡲࡥࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡦ࡯ࡷࡤࡺࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ␋"),l111l11l1l_l1_,re.DOTALL)
	if l111l1ll1l_l1_:
		l111l1ll1l_l1_ = l111l1ll1l_l1_[0]
		l111l11lll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ␌"),l111l1ll1l_l1_,re.DOTALL)
		if l111l11lll_l1_:
			for l111l1ll_l1_,l1ll1ll_l1_ in l111l11lll_l1_:
				if l1l111_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ␍") not in l1ll1ll_l1_: continue
				if l1ll1ll_l1_.count(l1l111_l1_ (u"ࠫ࠴࠭␎"))>=2:
					server = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ␏"))[2]
					l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ␐")+server+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫ␑")+l111l1ll_l1_)
	l111l1ll11_l1_ = []
	for l1ll1ll_l1_ in l1llll_l1_:
		l111l1ll11_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111l1ll11_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ␒"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ␓"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ␔"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭␕"),l1l111_l1_ (u"ࠬ࠱ࠧ␖"))
	html = l1l1llll_l1_(l111l11l_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ␗"),l1l111_l1_ (u"ࠧࠨ␘"),l1l111_l1_ (u"ࠨࠩ␙"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ␚"))
	token = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡸࡴࡱࡥ࡯ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ␛"),html,re.DOTALL)
	if token:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡥࡴࡰ࡭ࡨࡲࡂ࠭␜")+token[0]+l1l111_l1_ (u"ࠬࠬࡱ࠾ࠩ␝")+l1lll1ll_l1_
		l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ〡")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡏ࡙ࡑ࡟ࠨ〢")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ〣"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ〤"),l1l111_l1_ (u"ࠬอไฤไึห๊࠭〥")]
def l11l1ll_l1_(mode,url,text):
	if   mode==670: l1lll_l1_ = l1l1l11_l1_()
	elif mode==671: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==672: l1lll_l1_ = PLAY(url)
	elif mode==673: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==674: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==679: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ〦"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ〧"),l1l111_l1_ (u"ࠨࠩ〨"),l1l111_l1_ (u"ࠩࠪ〩"),l1l111_l1_ (u"〪ࠪࠫ"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ〫"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〬"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾〭࠭"),l1l111_l1_ (u"ࠧࠨ〮"),679,l1l111_l1_ (u"ࠨ〯ࠩ"),l1l111_l1_ (u"ࠩࠪ〰"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ〱"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ〲"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〳"),l1l111_l1_ (u"࠭ࠧ〴"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ〵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ〶"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			if title==l1l111_l1_ (u"ࠩส่ศ่ำศ็ࠪ〷"): mode = 675
			else: mode = 674
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ〸"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭〹")+l1lllll_l1_+title,l1ll1ll_l1_,mode)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ〺"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ〻"),l1l111_l1_ (u"ࠧࠨ〼"),9999)
	items = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡤࡵࡳࡼࡹࡥ࠯ࡪࡷࡱࡱ࠭〽"))
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〾"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ〿")+l1lllll_l1_+title,l1ll1ll_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1llllll11_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ぀"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧぁ"),l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪあ"))
	if l1llllll11_l1_: return l1llllll11_l1_
	l1llllll11_l1_ = []
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫぃ"),url,l1l111_l1_ (u"ࠨࠩい"),l1l111_l1_ (u"ࠩࠪぅ"),l1l111_l1_ (u"ࠪࠫう"),l1l111_l1_ (u"ࠫࠬぇ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨえ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯࡫ࡩࡦࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲ࠿ࠩぉ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1llllll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫお"),block,re.DOTALL)
		if l1llllll11_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪか"),l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭が"),l1llllll11_l1_,l1ll1ll1_l1_)
	return l1llllll11_l1_
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧき"),url,l1l111_l1_ (u"ࠫࠬぎ"),l1l111_l1_ (u"ࠬ࠭く"),l1l111_l1_ (u"࠭ࠧぐ"),l1l111_l1_ (u"ࠧࠨけ"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨげ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭こ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫご"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪさ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩざ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧし"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬじ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭す"),l1l111_l1_ (u"ࠩࠪず"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨせ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧぜ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬそ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪぞ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩた"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭だ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫち"),l1l111_l1_ (u"ࠪࠫぢ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫっ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭つ")):
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫづ"):
		url,search = url.split(l1l111_l1_ (u"ࠧࡀࠩて"),1)
		data = l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧで")+search
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨと"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪど")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩな"),url,data,headers,l1l111_l1_ (u"ࠬ࠭に"),l1l111_l1_ (u"࠭ࠧぬ"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ね"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬの"),url,l1l111_l1_ (u"ࠩࠪは"),l1l111_l1_ (u"ࠪࠫば"),l1l111_l1_ (u"ࠫࠬぱ"),l1l111_l1_ (u"ࠬ࠭ひ"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬび"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠧࠨぴ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬふ"))
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧぶ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬぷ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬへ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧべ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧぺ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ほ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨぼ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ぽ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪま"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭み"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧむ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨめ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨも"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩゃ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪや"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪゅ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩゆ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫょ"),l1l111_l1_ (u"࠭ใๅ์หࠫよ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ら"),l1l111_l1_ (u"ࠨ้าหๆ࠭り"),l1l111_l1_ (u"่ࠩฬฬืวสࠩる"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧれ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫろ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫゎ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭わ"),l1l111_l1_ (u"ࠧโๆ่ࠫゐ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫゑ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨを"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩん"):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪゔ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫゕ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ゖ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ゗") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ゘"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ゙ࠩ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁ゚ࠫ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ゛"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ゜"): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫゝ") not in l1ll1ll_l1_:
				l1lllll1_l1_ = url.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩゞ"),1)[0]
				l1ll1ll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪゟ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ゠"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪァ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪア")+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠬ࠭ィ"),l1l111_l1_ (u"࠭ࠧイ"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ゥ"),l1lllll_l1_+l1l111_l1_ (u"ࠨฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨウ"),url,672)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧェ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬエ"),l1l111_l1_ (u"ࠫࠬォ"),9999)
	l1llllll11_l1_ = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡨࡲࡰࡹࡶࡩ࠳࡮ࡴ࡮࡮ࠪオ"))
	l1ll11ll11l_l1_,l1ll11ll1ll_l1_,l1ll11ll1l1_l1_ = zip(*l1llllll11_l1_)
	l1ll11lll1l_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪカ"),url,l1l111_l1_ (u"ࠧࠨガ"),l1l111_l1_ (u"ࠨࠩキ"),l1l111_l1_ (u"ࠩࠪギ"),l1l111_l1_ (u"ࠪࠫク"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬグ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠩケ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡺࡄࡸࡸࡹࡵ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨゲ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1ll11ll11l_l1_:
				item = (l1ll1ll_l1_,title)
				l1ll11lll1l_l1_.append(item)
		if len(l1ll11lll1l_l1_)==1:
			l1ll1ll_l1_,title = l1ll11lll1l_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭コ"))
			return
		else:
			for l1ll1ll_l1_,title in l1ll11lll1l_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨゴ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠩࠪサ"),l1l111_l1_ (u"ࠪࠫザ"),l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪシ"))
	if not l1ll11lll1l_l1_: l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫジ"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪス"),url,l1l111_l1_ (u"ࠧࠨズ"),l1l111_l1_ (u"ࠨࠩセ"),l1l111_l1_ (u"ࠩࠪゼ"),l1l111_l1_ (u"ࠪࠫソ"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨゾ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࠯ࠬࡂ࠭࡫ࡲࡡࡴࡪࡳࡰࡦࡿࡥࡳࠩタ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩダ"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࡠࡡࠪチ")+l111l1ll_l1_
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡥࡧࡧ࠱ࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫヂ"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠤࡩ࡭ࡱ࡫࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤッ"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨツ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪヅ")+l1ll1ll_l1_
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭テ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬデ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨト"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩド"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫナ"),l1l111_l1_ (u"ࠪ࠯ࠬニ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫヌ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬネ"))
	return
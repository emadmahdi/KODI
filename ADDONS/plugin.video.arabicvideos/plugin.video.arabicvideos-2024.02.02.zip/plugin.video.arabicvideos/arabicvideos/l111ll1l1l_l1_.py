# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ⃫")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡅ࠶ࡤ⃬࠭")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ฺ้อัฺหࠣห้ำัส⃭ࠩ"),l1l111_l1_ (u"ࠩส๎ั๐ࠠษ์ึฮ⃮ࠬ"),l1l111_l1_ (u"ࠪ฽ึ๎ึࠡษ็ฺ้อัฺห⃯ࠪ"),l1l111_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ⃰"),l1l111_l1_ (u"ࠬอ๊อ์ࠣฬุะࠠศๆหำ๏๊ࠧ⃱"),l1l111_l1_ (u"࠭ว๋ฮ์ࠤอูสࠡษ็ะิ๐ฯࠨ⃲")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==780: l1lll_l1_ = l1l1l11_l1_()
	elif mode==781: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==782: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==783: l1lll_l1_ = PLAY(url)
	elif mode==784: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⃳")+text)
	elif mode==785: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ⃴")+text)
	elif mode==786: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==789: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⃵"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⃶"),l1l111_l1_ (u"ࠫࠬ⃷"),789,l1l111_l1_ (u"ࠬ࠭⃸"),l1l111_l1_ (u"࠭ࠧ⃹"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⃺"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⃻"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⃼"),l1l111_l1_ (u"ࠪࠫ⃽"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⃾"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭⃿"),l1l111_l1_ (u"࠭ࠧ℀"),l1l111_l1_ (u"ࠧࠨ℁"),l1l111_l1_ (u"ࠨࠩℂ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭℃"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴ࠮ࡲࡤ࡫ࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ℄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ℅"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ℆"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫℇ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ℈"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ℉")+l1lllll_l1_+title,l1ll1ll_l1_,781)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧℊ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬℋ"),l1l111_l1_ (u"ࠫࠬℌ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࡵࡲࡧ࡮ࡧ࡬࠮ࡤࡲࡼࠬℍ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨℎ"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩℏ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭ℐ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩℑ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬℒ")+l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠫࠬℓ"),l1l111_l1_ (u"ࠬࡳࡡࡪࡰࡰࡩࡳࡻࠧ℔"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫℕ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ№"),l1l111_l1_ (u"ࠨࠩ℗"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ℘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩℙ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭ℚ"))
			if any(value in title for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪℛ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ℜ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩℝ")+l1lllll_l1_+title,l1ll1ll_l1_,781)
	return
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠨࠩ℞")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭℟"),url,l1l111_l1_ (u"ࠪࠫ℠"),l1l111_l1_ (u"ࠫࠬ℡"),l1l111_l1_ (u"ࠬ࠭™"),l1l111_l1_ (u"࠭ࠧ℣"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩℤ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫࡤࡶࡹ࡯ࡣ࡭ࡧࠪ℥"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠩࠪΩ"),l1l111_l1_ (u"ࠪࠫ℧"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠫา๊โศฬࠪℨ") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๋่ࠬศี่ࠫ℩") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭K"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧÅ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨℬ"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨℭ"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ℮"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪℯ"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫℰ"),l1lllll_l1_+title,l1ll1ll_l1_,783)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧℱ")):
	if l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫℲ") in type or l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨℳ") in type:
		l1lllll1_l1_,data = url.split(l1l111_l1_ (u"ࠩࡂࡷࡪࡶࡡࡳࡣࡷࡳࡷࠬࠧℴ"))
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩℵ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪℶ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪℷ"),l1lllll1_l1_,data,headers,l1l111_l1_ (u"࠭ࠧℸ"),l1l111_l1_ (u"ࠧࠨℹ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ℺"))
		html = response.content
		html = l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠩ℻")+html+l1l111_l1_ (u"ࠪࡥࡷࡺࡩࡤ࡮ࡨࠫℼ")
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨℽ"),url,l1l111_l1_ (u"ࠬ࠭ℾ"),l1l111_l1_ (u"࠭ࠧℿ"),l1l111_l1_ (u"ࠧࠨ⅀"),l1l111_l1_ (u"ࠨࠩ⅁"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⅂"))
		html = response.content
	items,l111llllll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⅃"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⅄"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧⅅ"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⅆ"),l1lllll_l1_+title,l1ll1ll_l1_,781,l1l111_l1_ (u"ࠧࠨⅇ"),l1l111_l1_ (u"ࠨࡵࡸࡦࡲ࡫࡮ࡶࠩⅈ"))
				l111llllll_l1_ = True
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡤࡰࡱ࠳ࡴࡢࡺࡨࡷ࠭࠴ࠪࡀࠫࠥࡰࡴࡧࡤࠣࠩⅉ"),html,re.DOTALL)
		if l11llll_l1_ and type!=l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⅊"):
			if l111llllll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⅋"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⅌"),l1l111_l1_ (u"࠭ࠧ⅍"),9999)
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⅎ"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ⅏"),url,785,l1l111_l1_ (u"ࠩࠪ⅐"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⅑"))
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⅒"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ⅓"),url,784,l1l111_l1_ (u"࠭ࠧ⅔"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⅕"))
			filters = True
	if not l111llllll_l1_ and not filters:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭⅖"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⅗"),block,re.DOTALL)
			l1l1_l1_ = []
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠪࡠࡳ࠭⅘"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭⅙") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅚"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"࠭อๅไฬࠫ⅛") in title:
					l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ⅜"),title,re.DOTALL)
					if l1l1lll_l1_:
						title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⅝") + l1l1lll_l1_[0][0]
						if title not in l1l1_l1_:
							addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⅞"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
							l1l1_l1_.append(title)
				elif l1l111_l1_ (u"ุ้๊ࠪำๅࠩ⅟") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠫา๊โสࠩⅠ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⅡ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				elif l1l111_l1_ (u"࠭ๅ้ี่ࠫⅢ") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧฮๆๅอࠬⅣ") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⅤ"),l1lllll_l1_+title,l1ll1ll_l1_,786,l1ll1l_l1_)
				else: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⅥ"),l1lllll_l1_+title,l1ll1ll_l1_,783,l1ll1l_l1_)
		length = 12 if l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪⅦ") in type else 16
		data = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࠭ࡲ࡯ࡢࡦ࠰ࡱࡴࡸࡥ࠯ࠬࡂ࠭ࠥ࠴ࠪࡀࡦࡤࡸࡦ࠳ࠨ࠯ࠬࡂ࠭ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⅷ"),html,re.DOTALL)
		if len(items)==length and (data or l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩⅨ") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l1l111_l1_ (u"࠭࡬ࡰࡣࡧࠫⅩ"),l1l111_l1_ (u"ࠧࡨࡧࡷࠫⅪ")).replace(l1l111_l1_ (u"ࠨ࠯ࠪⅫ"),l1l111_l1_ (u"ࠩࡢࠫⅬ")).replace(l1l111_l1_ (u"ࠪࠦࠬⅭ"),l1l111_l1_ (u"ࠫࠬⅮ"))
			else:
				data = re.findall(l1l111_l1_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬࠪࡴ࡬ࡦࡴࡧࡷࡁ࠭࠴ࠪࡀࠫࠩࠬ࠳࠰࠿ࠪ࠿ࠫ࠲࠯ࡅࠩࠥࠩⅯ"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l1l111_l1_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡃࠧⅰ")+action+l1l111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩⅱ")+str(offset)+l1l111_l1_ (u"ࠨࠨࠪⅲ")+name+l1l111_l1_ (u"ࠩࡀࠫⅳ")+value
			url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡴࡧࡳࡥࡷࡧࡴࡰࡴࠩࠫⅴ")+data
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅵ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆิํำࠬⅶ"),url,781,l1l111_l1_ (u"࠭ࠧⅷ"),l1l111_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࡣࠬⅸ")+type)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬⅹ"),url,l1l111_l1_ (u"ࠩࠪⅺ"),l1l111_l1_ (u"ࠪࠫⅻ"),l1l111_l1_ (u"ࠫࠬⅼ"),l1l111_l1_ (u"ࠬ࠭ⅽ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪⅾ"))
	html = response.content
	l1ll11l1_l1_,l1111l1ll_l1_ = [],[]
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⅿ"),html,re.DOTALL)
	for l111ll1ll1_l1_ in items:
		l111lll111_l1_ = base64.b64decode(l111ll1ll1_l1_)
		if PY3: l111lll111_l1_ = l111lll111_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ↀ"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧↁ"),l111lll111_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨↂ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪↃ")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪↄ"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧↅ")+server+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨↆ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬↇ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡨ࡮ࡼ࠾࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࠬࡡࡪࡻ࠴࠮࠷ࢁ࠮ࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧↈ"),block,re.DOTALL)
		for l111l1ll_l1_,l111lll1ll_l1_ in items:
			l1ll1ll_l1_ = base64.b64decode(l111lll1ll_l1_)
			if PY3: l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ↉"))
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ↊") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ↋")+l1ll1ll_l1_
			if l1ll1ll_l1_ not in l1111l1ll_l1_:
				l1111l1ll_l1_.append(l1ll1ll_l1_)
				server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ↌"))
				l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ↍")+server+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ↎")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ↏"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ←"),l1l111_l1_ (u"ࠫ࠲࠭↑"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡪࡰࡧ࠳ࡄࡷ࠽ࠨ→")+l1lll1ll_l1_
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭↓"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ↔"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ↕"),url,l1l111_l1_ (u"ࠩࠪ↖"),l1l111_l1_ (u"ࠪࠫ↗"),l1l111_l1_ (u"ࠫࠬ↘"),l1l111_l1_ (u"ࠬ࠭↙"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ↚"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࡥࡷࡺࡩࡤ࡮ࡨࠫ↛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ↜"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ↝"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷ࠭↞") not in url: l1lllll1_l1_,l111lll11l_l1_ = url,l1l111_l1_ (u"ࠫࠬ↟")
	else: l1lllll1_l1_,l111lll11l_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨ↠"))
	l1llllll_l1_,l111lll1l1_l1_ = l1ll11ll1_l1_(l111lll11l_l1_)
	l111ll1lll_l1_ = l1l111_l1_ (u"࠭ࠧ↡")
	for key in list(l111lll1l1_l1_.keys()):
		l111ll1lll_l1_ += l1l111_l1_ (u"ࠧࠧࡣࡵ࡫ࡸࠫ࠵ࡃࠩ↢")+key+l1l111_l1_ (u"ࠨࠧ࠸ࡈࡂ࠭↣")+l111lll1l1_l1_[key]
	l1111111_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵࡅࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࠨࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡥࡦࡪ࡮ࡷࡩࡷࡪ࡟ࡣ࡮ࡲࡧࡰࡹࠧ↤")+l111ll1lll_l1_
	return l1111111_l1_
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ↥"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭↦"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ↧"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭↨"),l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ↩"),l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ↪"),l1l111_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭↫")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ↬"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭↭"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ↮")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ↯"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ↰"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ↱"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ↲"),l1l111_l1_ (u"ࠪࠫ↳")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ↴"))
	if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭↵"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨ↶") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩ↷") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ↸")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ↹")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ↺")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ↻")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ↼"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ↽")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ↾"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ↿"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⇀")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ⇁"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⇂"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⇃"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⇄")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⇅"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ⇆"),l1llllll_l1_,781,l1l111_l1_ (u"ࠩࠪ⇇"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⇈"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇉"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ⇊")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ⇋"),l1llllll_l1_,781,l1l111_l1_ (u"ࠧࠨ⇌"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⇍"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⇎"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⇏"),l1l111_l1_ (u"ࠫࠬ⇐"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"้ࠬไࠡࠩ⇑"),l1l111_l1_ (u"࠭ࠧ⇒"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠧ࠾ࠩ⇓") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⇔"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ⇕"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⇖")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇗"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭⇘"),l1llllll_l1_,781,l1l111_l1_ (u"࠭ࠧ⇙"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⇚"))
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⇛"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ⇜"),l1lllll1_l1_,785,l1l111_l1_ (u"ࠪࠫ⇝"),l1l111_l1_ (u"ࠫࠬ⇞"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ⇟"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ⇠")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ⇡")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ⇢")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬ⇣")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ⇤")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇥"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ⇦")+name,l1lllll1_l1_,784,l1l111_l1_ (u"࠭ࠧ⇧"),l1l111_l1_ (u"ࠧࠨ⇨"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ⇩")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ⇪")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ⇫")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭⇬")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ⇭")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ⇮")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ⇯")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ⇰")+name
			if type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ⇱"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇲"),l1lllll_l1_+title,url,784,l1l111_l1_ (u"ࠫࠬ⇳"),l1l111_l1_ (u"ࠬ࠭⇴"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⇵") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ⇶") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⇷"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⇸")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⇹"),l1lllll_l1_+title,l1llllll_l1_,781,l1l111_l1_ (u"ࠫࠬ⇺"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⇻"))
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⇼"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⇽"),l1lllll_l1_+title,url,785,l1l111_l1_ (u"ࠨࠩ⇾"),l1l111_l1_ (u"ࠩࠪ⇿"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭∀"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨ∁"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧ∂"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨ∃") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩ∄"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ∅"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪ∆")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ∇")
		if l1l111_l1_ (u"ࠫࠪ࠭∈") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ∉") and value!=l1l111_l1_ (u"࠭࠰ࠨ∊"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ∋")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ∌") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ∍"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ∎")+key+l1l111_l1_ (u"ࠫࡂ࠭∏")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ∐"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ∑")+key+l1l111_l1_ (u"ࠧ࠾ࠩ−")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ∓"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ∔"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭∕"),l1l111_l1_ (u"ࠫࡂ࠭∖"))
	return l1l1l111_l1_
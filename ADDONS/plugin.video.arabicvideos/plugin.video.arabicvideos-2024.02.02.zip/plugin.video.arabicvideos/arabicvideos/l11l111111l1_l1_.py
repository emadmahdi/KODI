# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ弪")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ弫")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l11l11l1llll_l1_(url)
	elif mode==146: l1lll_l1_ = l111lllll11l_l1_(url)
	elif mode==147: l1lll_l1_ = l11l11l11111_l1_()
	elif mode==148: l1lll_l1_ = l11l11l111l1_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弬"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ弭"),l1l111_l1_ (u"࠭ࠧ弮"),149,l1l111_l1_ (u"ࠧࠨ弯"),l1l111_l1_ (u"ࠨࠩ弰"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭弱"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弲"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭弳")+l1l111_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ弴")+l1l111_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬࠦวๅ็หี๊าࠧ張"),l1l111_l1_ (u"ࠧࠨ弶"),290)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ強"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弸")+l1lllll_l1_+l1l111_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣ๎ํะ๊้สࠪ弹"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ强"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弻"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ弼")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ弽"),l111l1_l1_,144,l1l111_l1_ (u"ࠨࠩ弾"),l1l111_l1_ (u"ࠩࠪ弿"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ彀"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彁"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ彂")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ะฮํ๏ࠠศๆิหหาࠧ彃"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ彄"),146)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭彅"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ彆"),l1l111_l1_ (u"ࠪࠫ彇"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彈"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ彉")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ彊"),l1l111_l1_ (u"ࠧࠨ彋"),147)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ彌"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ彍")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ彎"),l1l111_l1_ (u"ࠫࠬ彏"),148)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彐"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ彑")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ归"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ当"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彔"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ录")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ彖"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ彗"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彘"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ彙")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭彚"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ彛"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彜"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭彝")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ彞"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ彟"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彠"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ彡")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ形"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ彣"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彤"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ彥")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ彦"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭彧"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ彨"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ彩")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ彪"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ彫"),144)
	return
def l11l11l11111_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯อัࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ彬"))
	return
def l11l11l111l1_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡵࡸࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ彭"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111lllll11l_l1_(url):
	html,l1llll1lll_l1_,data = l11l111lll11_l1_(url)
	dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ彮")][l1l111_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ彯")][l1l111_l1_ (u"ࠩࡷࡥࡧࡹࠧ彰")]
	for l1l111llll_l1_ in range(len(dd)):
		item = dd[l1l111llll_l1_]
		l11l1111ll11_l1_(item,url,str(l1l111llll_l1_))
	l11l11111111_l1_ = dd[0][l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ影")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ彲")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ彳")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ彴")]
	s = 0
	for l1l111llll_l1_ in range(len(l11l11111111_l1_)):
		item = l11l11111111_l1_[l1l111llll_l1_][l1l111_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彵")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ彶")][0]
		if list(item[l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩ彷")][l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ彸")].keys())[0]==l1l111_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭役"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_ = l11l11ll11ll_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠาษษะฮࠦࠧ彺")+str(s)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彻"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠧࠨ彼"),str(l1l111llll_l1_))
	key = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭彽"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ彾")+key[0]
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l111lll11_l1_(l1lllll1_l1_)
	for l1llll1l1l11_l1_ in range(3,4):
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ彿")][l1llll1l1l11_l1_][l1l111_l1_ (u"ࠫ࡬ࡻࡩࡥࡧࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ往")][l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ征")]
		for l1l111llll_l1_ in range(len(dd)):
			item = dd[l1l111llll_l1_]
			if l1l111_l1_ (u"࡙࠭ࡰࡷࡗࡹࡧ࡫ࠠࡑࡴࡨࡱ࡮ࡻ࡭ࠨ徂") in str(item): continue
			l11l1111ll11_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠧࠨ徃"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ径"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭待"),l1l111_l1_ (u"ࠪࠫ徆"))
	html,l1llll1lll_l1_,l1l11llll_l1_ = l11l111lll11_l1_(url,data)
	l1l11ll11l_l1_,l111llll1lll_l1_ = l1l111_l1_ (u"ࠫࠬ徇"),l1l111_l1_ (u"ࠬ࠭很")
	owner = re.findall(l1l111_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࡔࡡ࡮ࡧࠥ࠲࠯ࡅࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ徉"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ徊"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡐࡩࡹࡧࡤࡢࡶࡤࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࡯ࡸࡰࡨࡶ࡚ࡸ࡬ࡴࠤ࠽ࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧ࠭律"),html,re.DOTALL)
	if owner:
		l1l11ll11l_l1_ = l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ後")+owner[0][0]+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ徍")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ徎") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ徏") in url: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徐"),l1lllll_l1_+l1l11ll11l_l1_,l1ll1ll_l1_,144)
	l111llllll1l_l1_ = [l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ徑"),l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ徒"),l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ従"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ徔"),l1l111_l1_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ徕"),l1l111_l1_ (u"ࠬࡹࡳ࠾ࠩ徖"),l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ得"),l1l111_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ徘"),l1l111_l1_ (u"ࠨࡤࡳࡁࠬ徙"),l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ徚")]
	l111llll1ll1_l1_ = not any(value in url for value in l111llllll1l_l1_)
	if l111llll1ll1_l1_ and l1l11ll11l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠪห้ฮอฬࠩ徛")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠫ็๎วว็ࠣห้ะิ฻์็ࠫ徜")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠬอไโ์า๎ํํวหࠩ徝")
		l111lllll111_l1_ = l1l111_l1_ (u"࠭วๅไ้์ฬะࠧ從")
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ徟"),l1lllll_l1_+l1l11ll11l_l1_,url,9999)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥฬาัࠢࠨ徠") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ御"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠪࠫ徢"),l1l111_l1_ (u"ࠫࠬ徣"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ徤"))
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ徥") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徦"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ徧"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ徨") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ復"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ循"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ徫") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徬"),l1lllll_l1_+l111lllll111_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ徭"),144)
		if l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡗࡪࡧࡲࡤࡪࠥࠫ微") in html: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ徯"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠪࠫ徰"),l1l111_l1_ (u"ࠫࠬ徱"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ徲"))
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ徳") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徴"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ徵"),144)
		if l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ徶") in html: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ德"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ徸"),144)
		if l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡄࡪࡤࡲࡳ࡫࡬ࡴࠤࠪ徹") in html: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徺"),l1lllll_l1_+l111lllll111_l1_,url+l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ徻"),144)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭徼"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ徽"),l1l111_l1_ (u"ࠪࠫ徾"),9999)
	if l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ徿") in url:
		dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ忀")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ忁")][l1l111_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ忂")][l1l111_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ心")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ忄")]
		l111llll1l11_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ必") in list(dd[i].keys()):
				l111llll11ll_l1_ = dd[i][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ忆")]
				length = len(str(l111llll11ll_l1_))
				if length>l111llll1l11_l1_:
					l111llll1l11_l1_ = length
					l111llll1lll_l1_ = l111llll11ll_l1_
		if l111llll1l11_l1_==0: return
	elif l1l111_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ忇") in url or l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ忈") in url or l1l111_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭忉") in url or l1l111_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ忊") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ忋") in url or url==l111l1_l1_:
		l11l1111l1ll_l1_ = []
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ忌"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ忍"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩࡠࠦ忎"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡨࡴ࡬ࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ忏"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠧ忐"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠰࠵ࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ忑"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ忒"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡘࡣࡷࡧ࡭ࡔࡥࡹࡶࡕࡩࡸࡻ࡬ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝ࠣ忓"))
		l111llllll11_l1_,l111llll1lll_l1_ = l111llll11l1_l1_(l1llll1lll_l1_,l1l111_l1_ (u"ࠫࠬ忔"),l11l1111l1ll_l1_)
	if not l111llll1lll_l1_:
		try:
			dd = l1llll1lll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ忕")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ忖")][l1l111_l1_ (u"ࠧࡵࡣࡥࡷࠬ志")]
			l1lllll1ll11_l1_ = l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ忘") in url or l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭忙") in url or l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭忚") in url
			l11l11111l1l_l1_ = l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ忛") in html or l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢใ๊สส๊ࠦวๅฬื฾๏๊ࠢࠨ応") in html or l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๆ๋๎วหࠤࠪ忝") in html
			l11l11111l11_l1_ = l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ忞") in html or l1l111_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ忟") in html or l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ忠") in html
			if l1lllll1ll11_l1_ and (l11l11111l1l_l1_ or l11l11111l11_l1_):
				for l1l111llll_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ忡") not in list(dd[l1l111llll_l1_].keys()): continue
					l11l11111111_l1_ = dd[l1l111llll_l1_][l1l111_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ忢")]
					try: l111lllll1ll_l1_ = l11l11111111_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭忣")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ忤")][l1l111_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ忥")][l1l111_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ忦")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬ忧")][l1l111llll_l1_]
					except: l111lllll1ll_l1_ = l11l11111111_l1_
					try: l1ll1ll_l1_ = l111lllll1ll_l1_[l1l111_l1_ (u"ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬ忨")][l1l111_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭忩")][l1l111_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ忪")][l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ快")]
					except: continue
					if   l1l111_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ忬")		in l1ll1ll_l1_	and l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ忭")		in url: l11l11111111_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭忮")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ忯")	in url: l11l11111111_l1_ = dd[l1l111llll_l1_] ; break
					elif l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ忰")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ忱")		in url: l11l11111111_l1_ = dd[l1l111llll_l1_] ; break
					else: l11l11111111_l1_ = dd[0]
			elif l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ忲") in url: l11l11111111_l1_ = dd[index]
			else: l11l11111111_l1_ = dd[0]
			l111llll1lll_l1_ = l11l11111111_l1_[l1l111_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ忳")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ忴")]
		except: pass
	if not l111llll1lll_l1_: return
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ念"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ忶"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ忷"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ忸"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ忹"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡣࡵࡨࡸ࠭࡝ࠣ忺"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ忻"))
	if l1l111_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ忼") not in url: l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪࡡࡠ࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ࡞ࠤ忽"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ忾"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ忿"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ怀"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ态"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ怂"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ怃"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ怄"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ怅"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦࠣ怆"))
	l11l11ll11l_l1_ = l111lll1111_l1_(l1l111_l1_ (u"ࡻࠧไๆࠣๆํอฦๆࠢส่ฯฺฺ๋ๆࠪ怇"))
	l11l1111ll1_l1_ = l111lll1111_l1_(l1l111_l1_ (u"ࡵࠨๅ็ࠤฬ๊แ๋ัํ์์อสࠨ怈"))
	l111lllll1l1_l1_ = l111lll1111_l1_(l1l111_l1_ (u"ࡶࠩๆ่ࠥอไใ่๋หฯ࠭怉"))
	l1l1ll11l1l1_l1_ = [l11l11ll11l_l1_,l11l1111ll1_l1_,l111lllll1l1_l1_,l1l111_l1_ (u"ࠩࡄࡰࡱࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ怊"),l1l111_l1_ (u"ࠪࡅࡱࡲࠠࡷ࡫ࡧࡩࡴࡹࠧ怋"),l1l111_l1_ (u"ࠫࡆࡲ࡬ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ怌")]
	l111lllllll1_l1_,l111lllll1ll_l1_ = l111llll11l1_l1_(l111llll1lll_l1_,index,l11l1111l1ll_l1_)
	if l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ怍") in str(type(l111lllll1ll_l1_)) and any(value in str(l111lllll1ll_l1_[0]) for value in l1l1ll11l1l1_l1_): del l111lllll1ll_l1_[0]
	for index2 in range(len(l111lllll1ll_l1_)):
		l11l1111l1ll_l1_ = []
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ怎"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ怏"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ怐"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ怑"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ怒"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ怓"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡫ࡦࡳࡥࡄࡣࡵࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡪࡥࡲ࡫ࠧ࡞ࠤ怔"))
		l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟ࠥ怕"))
		l111llllll11_l1_,item = l111llll11l1_l1_(l111lllll1ll_l1_,index2,l11l1111l1ll_l1_)
		l11l1111ll11_l1_(item,url,str(index2))
		if l111llllll11_l1_==l1l111_l1_ (u"ࠧ࠵ࠩ怖"):
			try:
				hh = item[l1l111_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ怗")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ怘")][l1l111_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ怙")][l1l111_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ怚")]
				for l11l111l1l11_l1_ in range(len(hh)):
					l1l1ll1ll1ll_l1_ = hh[l11l111l1l11_l1_]
					l11l1111ll11_l1_(l1l1ll1ll1ll_l1_)
			except: pass
	l111llllll_l1_ = False
	if l1l111_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ怛") not in url and l111lllllll1_l1_==l1l111_l1_ (u"࠭࠸ࠨ怜"): l111llllll_l1_ = True
	if l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ思") in l1l11llll_l1_: l11l11l11ll1_l1_,key,l111llll1l1l_l1_,l11l11l1111l_l1_,token,l11l111llll1_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ怞"))
	else: l11l11l11ll1_l1_,key,l111llll1l1l_l1_,l11l11l1111l_l1_,token,l11l111llll1_l1_ = l1l111_l1_ (u"ࠩࠪ怟"),l1l111_l1_ (u"ࠪࠫ怠"),l1l111_l1_ (u"ࠫࠬ怡"),l1l111_l1_ (u"ࠬ࠭怢"),l1l111_l1_ (u"࠭ࠧ怣"),l1l111_l1_ (u"ࠧࠨ怤")
	l1lllll1_l1_,l111l1llll_l1_ = l1l111_l1_ (u"ࠨࠩ急"),l1l111_l1_ (u"ࠩࠪ怦")
	if menuItemsLIST:
		l11l111111ll_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠪࡇࡍࡔࡌࠨ性") in l11l111111ll_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭怨")
		elif l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪ怩") in l11l111111ll_l1_: l111l1llll_l1_ = l1l111_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ怪")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠧࡍࡋࡖࡘࠬ怫") in l11l111111ll_l1_: l111l1llll_l1_ = l1l111_l1_ (u"ࠨࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ怬")
	if l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠥࠫ怭") in html and l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ怮") not in url and not l111llllll_l1_ and l1l111_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩ࠭怯") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡥࡡ࡫ࡣࡻࡃࡨࡺ࡯࡬ࡧࡱࡁࠬ怰")+l111llll1l1l_l1_
	elif l1l111_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨࠧ怱") in html and l1l111_l1_ (u"ࠧࡣࡲࡀࠫ怲") not in url and l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ怳") in url or l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ怴") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ怵")+key
	elif l1l111_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ怶") in html and l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ怷") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ怸")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ怹"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ怺"),l1lllll1_l1_,144,l111l1llll_l1_,l1l111_l1_ (u"ࠩࠪ总"),l1l11llll_l1_)
	return
def l111llll11l1_l1_(l1l1llll1lll_l1_,l1l1lllllll1_l1_,l11l111l111l_l1_):
	l1llll1lll_l1_ = l1l1llll1lll_l1_
	l111llll1lll_l1_,index = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	l111lllll1ll_l1_,index2 = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	item,l11l1111111l_l1_ = l1l1llll1lll_l1_,l1l1lllllll1_l1_
	count = len(l11l111l111l_l1_)
	for l1l111llll_l1_ in range(count):
		try:
			out = eval(l11l111l111l_l1_[l1l111llll_l1_])
			return str(l1l111llll_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠪࠫ怼"),l1l111_l1_ (u"ࠫࠬ怽")
def l11l11ll11ll_l1_(item):
	try: l11l111lllll_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠬ࠭怾"),l1l111_l1_ (u"࠭ࠧ怿"),l1l111_l1_ (u"ࠧࠨ恀"),l1l111_l1_ (u"ࠨࠩ恁"),l1l111_l1_ (u"ࠩࠪ恂"),l1l111_l1_ (u"ࠪࠫ恃"),l1l111_l1_ (u"ࠫࠬ恄")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_ = False,l1l111_l1_ (u"ࠬ࠭恅"),l1l111_l1_ (u"࠭ࠧ恆"),l1l111_l1_ (u"ࠧࠨ恇"),l1l111_l1_ (u"ࠨࠩ恈"),l1l111_l1_ (u"ࠩࠪ恉"),l1l111_l1_ (u"ࠪࠫ恊"),l1l111_l1_ (u"ࠫࠬ恋")
	l11l1111111l_l1_ = item[l11l111lllll_l1_]
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恌"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恍"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恎"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ恏"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恐"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ恑"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ恒"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ恓"))
	l111llllll11_l1_,title = l111llll11l1_l1_(item,l11l1111111l_l1_,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ恔"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ恕"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ恖"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ恗"))
	l111llllll11_l1_,l1ll1ll_l1_ = l111llll11l1_l1_(item,l11l1111111l_l1_,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ恘"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ恙"))
	l111llllll11_l1_,l1ll1l_l1_ = l111llll11l1_l1_(item,l11l1111111l_l1_,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࠪࡡࠧ恚"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࡘࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ恛"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡂࡰࡶࡷࡳࡲࡖࡡ࡯ࡧ࡯ࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ恜"))
	l111llllll11_l1_,count = l111llll11l1_l1_(item,l11l1111111l_l1_,l11l1111l1ll_l1_)
	l11l1111l1ll_l1_ = []
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡯ࡩࡳ࡭ࡴࡩࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ恝"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恞"))
	l11l1111l1ll_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ恟"))
	l111llllll11_l1_,l1l1lll111_l1_ = l111llll11l1_l1_(item,l11l1111111l_l1_,l11l1111l1ll_l1_)
	if l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ恠") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭恡"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ恢")
	if l1l111_l1_ (u"ࠧๆสสุึ࠭恣") in l1l1lll111_l1_: l1l1lll111_l1_,l11l11l1l111_l1_ = l1l111_l1_ (u"ࠨࠩ恤"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ恥")
	if l1l111_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ恦") in list(l11l1111111l_l1_.keys()):
		l11l11l1ll11_l1_ = str(l11l1111111l_l1_[l1l111_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ恧")])
		if l1l111_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ恨") in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"࠭ࠤ࠻ࠩ恩")
		if l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠥࡔࡏࡘࠩ恪") in l11l11l1ll11_l1_: l11l11l1l111_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ恫")
		if l1l111_l1_ (u"ࠩࡅࡹࡾ࠭恬") in l11l11l1ll11_l1_ or l1l111_l1_ (u"ࠪࡖࡪࡴࡴࠨ恭") in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠫࠩࠪ࠺ࠨ恮")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡺ࠭ๅษษืีࠬ息")) in l11l11l1ll11_l1_: l11l11l1l111_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ恰")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡵࠨึิหฦ࠭恱")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠬ恲")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡷࠪหุะฦอษิࠫ恳")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠪࠨࠩࡀࠧ恴")
		if l111lll1111_l1_(l1l111_l1_ (u"ࡹࠬหูๅษ้หฯ࠭恵")) in l11l11l1ll11_l1_: l11l111lll1l_l1_ = l1l111_l1_ (u"ࠬࠪ࠺ࠨ恶")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ恷") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠧࡀࠩ恸"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭恹") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ恺")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l111lll1l_l1_: title = l11l111lll1l_l1_+l1l111_l1_ (u"ࠪࠤࠥ࠭恻")+title
	l1l1lll111_l1_ = l1l1lll111_l1_.replace(l1l111_l1_ (u"ࠫ࠱࠭恼"),l1l111_l1_ (u"ࠬ࠭恽"))
	count = count.replace(l1l111_l1_ (u"࠭ࠬࠨ恾"),l1l111_l1_ (u"ࠧࠨ恿"))
	count = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧ࠯ࠬ悀"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠩࠪ悁")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_
def l11l1111ll11_l1_(item,url=l1l111_l1_ (u"ࠪࠫ悂"),index=l1l111_l1_ (u"ࠫࠬ悃")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1lll111_l1_,l11l11l1l111_l1_,l11l111lll1l_l1_ = l11l11ll11ll_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ悄") in str(item): return
	elif l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡖࡹࡷࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ悅") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭悆") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ悇") in url or l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ悈") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠪࡁࡂࡃࠠࠨ悉")+title+l1l111_l1_ (u"ࠫࠥࡃ࠽࠾ࠩ悊")
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ悋"),l1lllll_l1_+title,l1l111_l1_ (u"࠭ࠧ悌"),9999)
	elif title and l1l111_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ悍") in str(item):
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭悎"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪ悏"),9999)
	elif l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ悐") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ悑"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l11l11l1l111_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ悒"),l1lllll_l1_+l11l11l1l111_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ悓") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ悔") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ悕") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ悖") not in l1ll1ll_l1_:
			l11l11l11l11_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ悗"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭悘")+l11l11l11l11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悙"),l1lllll_l1_+l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ悚")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ悛")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ悜"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ悝"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1lll111_l1_)
	else:
		type = l1l111_l1_ (u"ࠪࠫ悞")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ悟"),l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ悠"),l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ悡"),l1l111_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ悢"),l1l111_l1_ (u"ࠨࡵࡶࡁࠬ患"),l1l111_l1_ (u"ࠩࡥࡴࡂ࠭悤")]):
			if l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭悥")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡩ࠯ࠨ悦") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠬࡉࡈࡏࡎࠪ悧")+count+l1l111_l1_ (u"࠭࠺ࠡࠢࠪ您")
			if l1l111_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ悩") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠨࡗࡖࡉࡗ࠭悪")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭悫")
			index,l111llllllll_l1_ = l1l111_l1_ (u"ࠪࠫ悬"),l1l111_l1_ (u"ࠫࠬ悭")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悮"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l11l111lll11_l1_(url,data=l1l111_l1_ (u"࠭ࠧ悯"),request=l1l111_l1_ (u"ࠧࠨ悰")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ悱"))
	if request==l1l111_l1_ (u"ࠩࠪ悲"): request = l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ悳")
	l11ll1l1ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ悴"):l11ll1l1ll_l1_,l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ悵"):l1l111_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ悶")}
	if l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ悷") in data: l11l11l11ll1_l1_,key,l111llll1l1l_l1_,l11l11l1111l_l1_,token,l11l111llll1_l1_ = data.split(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ悸"))
	else: l11l11l11ll1_l1_,key,l111llll1l1l_l1_,l11l11l1111l_l1_,token,l11l111llll1_l1_ = l1l111_l1_ (u"ࠩࠪ悹"),l1l111_l1_ (u"ࠪࠫ悺"),l1l111_l1_ (u"ࠫࠬ悻"),l1l111_l1_ (u"ࠬ࠭悼"),l1l111_l1_ (u"࠭ࠧ悽"),l1l111_l1_ (u"ࠧࠨ悾")
	if l1l111_l1_ (u"ࠨࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ悿") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ惀")] = {l1l111_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ惁"):{l1l111_l1_ (u"ࠦ࡭ࡲࠢ惂"):l1l111_l1_ (u"ࠧࡧࡲࠣ惃"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ惄"):l1l111_l1_ (u"ࠢࡘࡇࡅࠦ情"),l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ惆"):l11l11l1111l_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ惇"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ惈"))
	elif l1l111_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ惉") in url and l11l11l11ll1_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ惊"):token}
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ惋")] = {l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ惌"):{l1l111_l1_ (u"ࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ惍"):l11l11l11ll1_l1_,l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ惎"):l1l111_l1_ (u"࡛ࠥࡊࡈࠢ惏"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ惐"):l11l11l1111l_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ惑"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠳ࡰࡧࠫ惒"))
	elif l1l111_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ惓") in url and l11l111llll1_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ惔"):l1l111_l1_ (u"ࠩ࠴ࠫ惕"),l1l111_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ惖"):l11l11l1111l_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ惗"):l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ惘")+l11l111llll1_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ惙"),url,l1l111_l1_ (u"ࠧࠨ惚"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ惛"),l1l111_l1_ (u"ࠩࠪ惜"),l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠸ࡸࡤࠨ惝"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ惞"),url,l1l111_l1_ (u"ࠬ࠭惟"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ惠"),l1l111_l1_ (u"ࠧࠨ惡"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠷ࡸ࡭࠭惢"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ惣"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ惤"),html,re.DOTALL|re.I)
	if tmp: l11l11l1111l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惥"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠬࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ惦"),html,re.DOTALL|re.I)
	if tmp: l11l11l11ll1_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ惧"),html,re.DOTALL|re.I)
	if tmp: l111llll1l1l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ惨") in list(cookies.keys()): l11l111llll1_l1_ = cookies[l1l111_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭惩")]
	data = l11l11l11ll1_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭惪")+key+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ惫")+l111llll1l1l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ惬")+l11l11l1111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ惭")+token+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ惮")+l11l111llll1_l1_
	if request==l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ惯") and l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ惰") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ惱"),html,re.DOTALL)
		if not l11ll11ll1_l1_: l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ惲"),html,re.DOTALL)
		l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡸࡺࡲࠨ想"),l11ll11ll1_l1_[0])
	elif request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ惴") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ惵") in html:
		l11ll11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭惶"),html,re.DOTALL)
		l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ惷"),l11ll11ll1_l1_[0])
	elif l1l111_l1_ (u"ࠩ࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ惸") not in html: l11l11l1l1ll_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ惹"),html)
	else: l11l11l1l1ll_l1_ = l1l111_l1_ (u"ࠫࠬ惺")
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ惻"),data)
	return html,l11l11l1l1ll_l1_,data
def l11l11l1llll_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ惼"),l1l111_l1_ (u"ࠧࠬࠩ惽"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ惾")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ惿"),l1l111_l1_ (u"ࠪ࠯ࠬ愀"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ࠭愁")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ愂") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡓࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭愃")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭愄") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ愅")
		elif l1l111_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ愆") in options: l11l111l1ll1_l1_ = l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆ࡭ࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ愇")
		l1llllll_l1_ = l1lllll1_l1_+l11l111l1ll1_l1_
	else:
		l11l111l1l1l_l1_,l11l1111l111_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠫࠬ愈")
		l11l1111l1l1_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ愉"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ愊"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ愋"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ愌"),l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭愍")]
		l11l11l1l1l1_l1_ = [l1l111_l1_ (u"ࠪࠫ愎"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ意"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ愐"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ愑"),l1l111_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭愒")]
		l11l11l1ll1l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ愓"),l11l1111l1l1_l1_)
		if l11l11l1ll1l_l1_ == -1: return
		l11l111l11ll_l1_ = l11l11l1l1l1_l1_[l11l11l1ll1l_l1_]
		html,c,data = l11l111lll11_l1_(l1lllll1_l1_+l11l111l11ll_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ愔")][l1l111_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭愕")][l1l111_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭愖")][l1l111_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ愗")][l1l111_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ愘")][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ愙")][l1l111_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ愚")]
			for l11l11111lll_l1_ in range(len(d)):
				group = d[l11l11111lll_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ愛")][l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ愜")]
				for l11l11ll1111_l1_ in range(len(group)):
					l11l1111111l_l1_ = group[l11l11ll1111_l1_][l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ愝")]
					if l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ愞") in list(l11l1111111l_l1_.keys()):
						l1ll1ll_l1_ = l11l1111111l_l1_[l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ感")][l1l111_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ愠")][l1l111_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭愡")][l1l111_l1_ (u"ࠩࡸࡶࡱ࠭愢")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ愣"),l1l111_l1_ (u"ࠫࠫ࠭愤"))
						title = l11l1111111l_l1_[l1l111_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭愥")]
						title = title.replace(l1l111_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ愦"),l1l111_l1_ (u"ࠧࠨ愧"))
						if l1l111_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ愨") in title: continue
						if l1l111_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ愩") in title:
							title = l1l111_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ愪")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ愫") in title: continue
						title = title.replace(l1l111_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ愬"),l1l111_l1_ (u"࠭ࠧ愭"))
						if l1l111_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ愮") in title: continue
						if l1l111_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ愯") in title:
							title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ愰")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ愱") in title: continue
						l11l111l1l1l_l1_.append(escapeUNICODE(title))
						l11l1111l111_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l11l11l1l11l_l1_ = l1l111_l1_ (u"ࠫࠬ愲")
		else:
			l11l111l1l1l_l1_ = [l1l111_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ愳"),l1lllllll_l1_]+l11l111l1l1l_l1_
			l11l1111l111_l1_ = [l1l111_l1_ (u"࠭ࠧ愴"),l111lllll_l1_]+l11l1111l111_l1_
			l11l11ll11l1_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ愵"),l11l111l1l1l_l1_)
			if l11l11ll11l1_l1_ == -1: return
			l11l11l1l11l_l1_ = l11l1111l111_l1_[l11l11ll11l1_l1_]
		if l11l11l1l11l_l1_: l1llllll_l1_ = l111l1_l1_+l11l11l1l11l_l1_
		elif l11l111l11ll_l1_: l1llllll_l1_ = l1lllll1_l1_+l11l111l11ll_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
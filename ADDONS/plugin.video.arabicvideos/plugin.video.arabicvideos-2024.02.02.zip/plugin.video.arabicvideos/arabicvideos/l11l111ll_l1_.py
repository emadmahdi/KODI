# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨᎎ")
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᎏ"):l1l111_l1_ (u"ࠪࠫ᎐")}
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉ࠴ࡖࡡࠪ᎑")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ᎒"),l1l111_l1_ (u"࠭วฯำํࠫ᎓"),l1l111_l1_ (u"ࠧศะิํࠬ᎔"),l1l111_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ᎕"),l1l111_l1_ (u"ࠩหำํ์ࠠฦะอ๎ฬืࠧ᎖"),l1l111_l1_ (u"ࠪหๆ๊วๆࠩ᎗"),l1l111_l1_ (u"ู๊ࠫไิๆสฮࠬ᎘")]
def l11l1ll_l1_(mode,url,text):
	if   mode==420: l1lll_l1_ = l1l1l11_l1_()
	elif mode==421: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==422: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==423: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==424: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ᎙")+text)
	elif mode==425: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ᎚")+text)
	elif mode==426: l1lll_l1_ = PLAY(url)
	elif mode==427: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==429: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ᎛"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ᎜"),l1l111_l1_ (u"ࠩࠪ᎝"),l1l111_l1_ (u"ࠪࠫ᎞"),l1l111_l1_ (u"ࠫࠬ᎟"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᎠ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᎡ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠧ࠰ࠩᎢ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᎣ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᎤ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᎥ"),l1l111_l1_ (u"ࠫࠬᎦ"),429,l1l111_l1_ (u"ࠬ࠭Ꭷ"),l1l111_l1_ (u"࠭ࠧᎨ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᎩ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎪ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᎫ"),l1l11ll_l1_,425)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎬ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᎭ"),l1l11ll_l1_,424)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᎮ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᎯ"),l1l111_l1_ (u"ࠧࠨᎰ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎱ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᎲ")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬᎳ"),l1l11ll_l1_,421)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᎴ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬࠦ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭Ꮅ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷࡹࠧᎶ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠧฤใ็ห๊ࠦวๅ่ฯ์๊࠭Ꮇ")
		elif l1l111_l1_ (u"ࠨ࠱ࡱࡩࡹ࡬࡬ࡪࡺࠪᎸ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠩฦๅ้อๅ๊่ࠡืู้ไศฬ๊ࠣ๏ะแๅๅึࠫᎹ")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎺ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ꮋ")+l1lllll_l1_+title,l1ll1ll_l1_,421)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᎼ"),l1lllll_l1_+l1l111_l1_ (u"࠭โศศ่อࠥะแึ์็๎ฮ࠭Ꮍ"),l1l11ll_l1_,427)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠧࠨᎾ")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᎿ"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪᏀ"),l1l111_l1_ (u"ࠪࠫᏁ"),l1l111_l1_ (u"ࠫࠬᏂ"),l1l111_l1_ (u"ࠬ࠭Ꮓ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᏄ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡗ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮ࡖࡡࡨࡧࡗ࡭ࡹࡲࡥࠨᏅ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠯࠮࠮ࠫࡁࠬࠦ࠯ࠦࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠯ࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠫࠪ࠱࠮ࡄ࠯࡛ࠣࡀࡠ࠯࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠭Ꮖ"),block,re.DOTALL)
	for category,id,l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺ࠰ࡱࡴࡼࡩࡦࡵࠪᏇ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪᏈ")
		elif l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶ࠱ࡳ࡫ࡴࡧ࡮࡬ࡼࠬᏉ") in l1ll1ll_l1_: title = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧᏊ")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮛ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᏌ")+l1lllll_l1_+title,l1ll1ll_l1_,421,l1l111_l1_ (u"ࠨࠩᏍ"),l1l111_l1_ (u"ࠩࠪᏎ"),category+l1l111_l1_ (u"ࠪࢀࠬᏏ")+id)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠫࠬᏐ")):
	if l1l111_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᏑ") in url: url = url.strip(l1l111_l1_ (u"࠭࠯ࠨᏒ"))+l1l111_l1_ (u"ࠧ࠰࡯ࡳࡥࡦ࠵ࡦࡢ࡯࡬ࡰࡾ࠵ࠧᏓ")
	items = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᏔ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭Ꮥ"),url,l1l111_l1_ (u"ࠪࠫᏖ"),headers,l1l111_l1_ (u"ࠫࠬᏗ"),l1l111_l1_ (u"ࠬ࠭Ꮨ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᏙ"))
	html = response.content
	if not l111l1l1l_l1_ or l1l111_l1_ (u"ࠧࡽࠩᏚ") in l111l1l1l_l1_:
		if l1l111_l1_ (u"ࠨࡾࠪᏛ") not in l111l1l1l_l1_: l111l1ll1_l1_ = l1l111_l1_ (u"ࠩࠪᏜ")
		else: l111l1ll1_l1_ = l1l111_l1_ (u"ࠪ࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠴࠭Ꮭ")+l111l1l1l_l1_
		l111ll11l_l1_ = False
		if l1l111_l1_ (u"ࠫࡕ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠧᏞ") in html:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏟ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็่๎ืฯࠧᏠ"),url,421,l1l111_l1_ (u"ࠧࠨᏡ"),l1l111_l1_ (u"ࠨࠩᏢ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᏣ"))
			l111ll11l_l1_ = True
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠨᏤ"),html,re.DOTALL)
		if l11llll_l1_:
			l1l1l1l_l1_ = l11llll_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡧࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᏥ"),l1l1l1l_l1_,re.DOTALL)
			for l11l1111l_l1_,l1lllllll_l1_ in l1l1111_l1_:
				l111lllll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡧࡪࡴࡴࡦࡴ࠲ࡥࡨࡺࡩࡰࡰ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࡹࡧࡢ࠰ࠩᏦ")+l11l1111l_l1_+l111l1ll1_l1_+l1l111_l1_ (u"࠭࠯ࠨᏧ")
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᏨ"),l1lllll_l1_+l1lllllll_l1_,l111lllll_l1_,421)
				l111ll11l_l1_ = True
		if l111ll11l_l1_: addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ꮹ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᏪ"),l1l111_l1_ (u"ࠪࠫᏫ"),9999)
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭Ꮼ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡖࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡓࡵ࡭ࡶ࡬ࡊ࡮ࡲࡴࡦࡴࠪᏭ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡐࡪࡰࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᏮ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠧࠨᏯ")
	elif l1l111_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫᏰ") in url or l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡦࡩࡳࡺࡥࡳ࠱ࠪᏱ") in url:
		block = html
	elif l1l111_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬᏲ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠪࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠯࠭Ᏻ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࡸ࠭Ᏼ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡐࡢࡩࡨࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠪࠨᏵ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࡡࠢ࠿࡟࠮࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᏶"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡅ࡬ࡱࡦ࠺ࡵࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾ࠨ᏷"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: block = l1l111_l1_ (u"ࠩࠪᏸ")
	if not items: items = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡒࡵࡶࡪࡧࡅࡰࡴࡩ࡫ࠣࠬ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠱࠮ࡄࡈ࡯ࡹࡖ࡬ࡸࡱ࡫ࡉ࡯ࡨࡲ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏹ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡒࡵࡶࡪࡧࡅࡰࡴࡩ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰࡭ࡲࡧࡧࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᏺ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if not title: continue
		if l1l111_l1_ (u"ࠬࡅ࡮ࡦࡹࡶࡁࠬᏻ") in l1ll1ll_l1_: continue
		title = title.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦࠧᏼ"),l1l111_l1_ (u"ࠧࠨᏽ"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩ᏾"),title,re.DOTALL)
		if l1l1lll_l1_ and l1l111_l1_ (u"ࠩะ่็ฯࠧ᏿") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ᐀") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐁ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶ࠴࠭ᐂ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐃ"),l1lllll_l1_+title,l1ll1ll_l1_,421,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),l1lllll_l1_+title,l1ll1ll_l1_,422,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᐅ"),html,re.DOTALL)
	if l11llll_l1_ and l111l1l1l_l1_!=l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᐆ"):
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾࡝࡟ࠫࡡࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨ࡞ࠥࡡࡃ࠮࠮ࠫࡁࠬࡀࠬᐇ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᐈ"),l1l111_l1_ (u"ࠬ࠭ᐉ"))
			if title!=l1l111_l1_ (u"࠭ࠧᐊ"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐋ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧᐌ")+title,l1ll1ll_l1_,421)
	l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿࠳ࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᐍ"),html,re.DOTALL)
	if l111llll1_l1_:
		l1ll1ll_l1_,title = l111llll1_l1_[0]
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐎ"),l1lllll_l1_+title,l1ll1ll_l1_,421)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᐏ"),url,l1l111_l1_ (u"ࠬ࠭ᐐ"),l1l111_l1_ (u"࠭ࠧᐑ"),l1l111_l1_ (u"ࠧࠨᐒ"),l1l111_l1_ (u"ࠨࠩᐓ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧᐔ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡐࡲࡻࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᐕ"),html,re.DOTALL)
	if l11llll_l1_:
		url = l11llll_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᐖ"),url,l1l111_l1_ (u"ࠬ࠭ᐗ"),l1l111_l1_ (u"࠭ࠧᐘ"),l1l111_l1_ (u"ࠧࠨᐙ"),l1l111_l1_ (u"ࠨࠩᐚ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠶ࡳࡪࠧᐛ"))
		html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗࡪࡧࡳࡰࡰࡶࡗࡪࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᐜ"),html,re.DOTALL)
	if l1l111_l1_ (u"ࠫ࠴ࡺࡡࡨ࠱ࠪᐝ") in url or l1l111_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࠬᐞ") in url:
		l1lll11_l1_(url)
	elif l11llll_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᐟ"))
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨᐠ"),block,re.DOTALL)
		l11l11l11_l1_ = [l1l111_l1_ (u"ࠨ็ึุ่๊ࠧᐡ"),l1l111_l1_ (u"่ࠩ์ุ๋ࠧᐢ"),l1l111_l1_ (u"ࠪฬึ์วๆฮࠪᐣ"),l1l111_l1_ (u"ࠫา๊โสࠩᐤ")]
		for l1ll1ll_l1_,title in items:
			if any(value in title for value in l11l11l11_l1_):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐥ"),l1lllll_l1_+title,l1ll1ll_l1_,423,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᐦ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᐧ"),url,l1l111_l1_ (u"ࠨࠩᐨ"),l1l111_l1_ (u"ࠩࠪᐩ"),l1l111_l1_ (u"ࠪࠫᐪ"),l1l111_l1_ (u"ࠫࠬᐫ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᐬ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᐭ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࠨᐮ")
	l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࡵࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᐯ"),html,re.DOTALL)
	if l111ll111_l1_:
		block = l111ll111_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᐰ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠪࠤࠬᐱ")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᐲ"),l1lllll_l1_+title,l1ll1ll_l1_,426,l1ll1l_l1_)
	else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᐳ"),l1lllll_l1_+l1l111_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬᐴ"),url,426,l1ll1l_l1_)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᐵ"),url,l1l111_l1_ (u"ࠨࠩᐶ"),headers,l1l111_l1_ (u"ࠩࠪᐷ"),l1l111_l1_ (u"ࠪࠫᐸ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᐹ"))
	html = response.content
	newurl = response.url
	if PY2: newurl = newurl.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᐺ"))
	l1l11ll_l1_ = l1l111l_l1_(newurl,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᐻ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡘࡣࡷࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩᐼ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡ࠱ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᐽ"),block,re.DOTALL)
		for l11l1lll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫᐾ"))
			if l1l111_l1_ (u"ࠪࡱࡾࡼࡩࡥࠩᐿ") in title.lower(): title = l1l111_l1_ (u"ࠫำอีࠡࠩᑀ")+title
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡵࡴࡸࡧࡹࡻࡲࡦ࠱ࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵࡅࡩࡥ࠿ࠪᑁ")+l11l1lll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᑂ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᑃ")
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫᑄ"),l1l111_l1_ (u"ࠩࠪᑅ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨᑆ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᑇ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧᑈ"))
			if l1l111_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬᑉ") in title.lower(): l1lllllll_l1_ = l1l111_l1_ (u"ࠧࡠࡡัหฺ࠭ᑊ")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠨࠩᑋ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᑌ")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᑍ")+l1lllllll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡸࠧᑎ"),l1l111_l1_ (u"ࠬ࠭ᑏ"))
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᑐ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨᑑ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩᑒ"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫᑓ"),l1l111_l1_ (u"ࠪ࠯ࠬᑔ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᑕ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬᑖ"))
	return
def l11l111l1_l1_(url):
	if l1l111_l1_ (u"࠭ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨᑗ") not in url: url = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫᑘ"))
	else: url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᑙ"))[0]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᑚ"),url,l1l111_l1_ (u"ࠪࠫᑛ"),l1l111_l1_ (u"ࠫࠬᑜ"),l1l111_l1_ (u"ࠬ࠭ᑝ"),l1l111_l1_ (u"࠭ࠧᑞ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩᑟ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᑠ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡋࡳࡻ࡫ࡲࡢࡤ࡯ࡩ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿ࠣࡣ࡯ࡰࠧ࠴ࠪࡀࠪࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑡ"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᑢ"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᑣ"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩᑤ"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᑥ"),l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡩࡥ࡯ࡶࡨࡶ࠴ࡧࡣࡵ࡫ࡲࡲ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧᑦ"))
	url = url.replace(l1l111_l1_ (u"ࠨ࠿ࠪᑧ"),l1l111_l1_ (u"ࠩ࠲ࠫᑨ")).replace(l1l111_l1_ (u"ࠪࠪࠬᑩ"),l1l111_l1_ (u"ࠫ࠴࠭ᑪ"))
	url = url+l1l111_l1_ (u"ࠬ࠵ࠧᑫ")
	return url
l1l11111_l1_ = [l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᑬ"),l1l111_l1_ (u"ࠧࡵࡻࡳࡩࡸ࠭ᑭ"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᑮ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᑯ"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᑰ"),l1l111_l1_ (u"ࠫࡹࡿࡰࡦࡵࠪᑱ"),l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᑲ")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"࠭࠿ࠨᑳ") in url: url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᑴ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬᑵ"),1)
	if filter==l1l111_l1_ (u"ࠩࠪᑶ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫᑷ"),l1l111_l1_ (u"ࠫࠬᑸ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᑹ"))
	if type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᑺ"):
		if l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫᑻ") in url:
			global l1l11111_l1_
			l1l11111_l1_ = l1l11111_l1_[1:]
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪᑼ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫᑽ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬᑾ")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧᑿ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧᒀ")+category+l1l111_l1_ (u"࠭࠽࠱ࠩᒁ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᒂ"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬᒃ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫᒄ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᒅ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᒆ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨᒇ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᒈ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨᒉ"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᒊ"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪᒋ"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᒌ")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᒍ"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨᒎ"),l1lllll1_l1_,421,l1l111_l1_ (u"࠭ࠧᒏ"),l1l111_l1_ (u"ࠧࠨᒐ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨᒑ"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒒ"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪᒓ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪᒔ"),l1lllll1_l1_,421,l1l111_l1_ (u"ࠬ࠭ᒕ"),l1l111_l1_ (u"࠭ࠧᒖ"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᒗ"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᒘ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒙ"),l1l111_l1_ (u"ࠪࠫᒚ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		if l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨᒛ") in url and l1l111ll_l1_==l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᒜ"): continue
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩᒝ"),l1l111_l1_ (u"ࠧࠨᒞ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪᒟ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬᒠ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᒡ")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᒢ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬᒣ"),l1lllll1_l1_,421,l1l111_l1_ (u"࠭ࠧᒤ"),l1l111_l1_ (u"ࠧࠨᒥ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨᒦ"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒧ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪᒨ"),l1lllll1_l1_,425,l1l111_l1_ (u"ࠫࠬᒩ"),l1l111_l1_ (u"ࠬ࠭ᒪ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩᒫ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᒬ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫᒭ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᒮ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭ᒯ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᒰ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᒱ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨᒲ")+name,l1lllll1_l1_,424,l1l111_l1_ (u"ࠧࠨᒳ"),l1l111_l1_ (u"ࠨࠩᒴ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩᒵ"): option = l1l111_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪᒶ")
			elif value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫᒷ"): option = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧᒸ")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨᒹ")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩᒺ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪᒻ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫᒼ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧᒽ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧᒾ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠬ࠶ࠧᒿ")]
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩᓀ")+name
			if type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᓁ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓂ"),l1lllll_l1_+title,url,424,l1l111_l1_ (u"ࠩࠪᓃ"),l1l111_l1_ (u"ࠪࠫᓄ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᓅ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠬࡃࠧᓆ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᓇ"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᓈ")+l11ll111_l1_
				l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᓉ"),l1lllll_l1_+title,l1llllll_l1_,421,l1l111_l1_ (u"ࠩࠪᓊ"),l1l111_l1_ (u"ࠪࠫᓋ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᓌ"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓍ"),l1lllll_l1_+title,url,425,l1l111_l1_ (u"࠭ࠧᓎ"),l1l111_l1_ (u"ࠧࠨᓏ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫᓐ"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭ᓑ"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬᓒ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭ᓓ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧᓔ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨᓕ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨᓖ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪᓗ")
		if l1l111_l1_ (u"ࠩࠨࠫᓘ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᓙ") and value!=l1l111_l1_ (u"ࠫ࠵࠭ᓚ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩᓛ")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᓜ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩᓝ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪᓞ")+key+l1l111_l1_ (u"ࠩࡀࠫᓟ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧᓠ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᓡ")+key+l1l111_l1_ (u"ࠬࡃࠧᓢ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪᓣ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩᓤ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫᓥ"),l1l111_l1_ (u"ࠩࡀࠫᓦ"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ䗂")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡐࡘ࡚࡟ࠨ䗃")
l1l1lll11l11_l1_ = 4
l1l1lll11111_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llllll1ll_l1_):
	try: l1l1ll1l11l1_l1_ = str(l1llllll1ll_l1_[l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗄")])
	except: l1l1ll1l11l1_l1_ = l1l111_l1_ (u"ࠫࠬ䗅")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1llll11ll_l1_(text)
	elif mode==162: l1lll_l1_ = l1l1ll111lll_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l1ll111lll_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1llll111l_l1_(text)
	elif mode==165: l1lll_l1_ = l1l1l1lll1ll_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1lll1l11l_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l1l1lll1l1_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l1l1l1llll_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1lll1lll1_l1_()
	elif mode==762: l1lll_l1_ = l1l1ll1l1ll1_l1_()
	elif mode==763: l1lll_l1_ = l1l1ll1lllll_l1_(l1l1ll1l11l1_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1lll111l1_l1_(l1l1ll1l11l1_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1lll1ll11_l1_(l1l1ll1l11l1_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗆"),l1l111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์ู๋ࠦี๊สส๏ฯࠧ䗇"),l1l111_l1_ (u"ࠧࠨ䗈"),161,l1l111_l1_ (u"ࠨࠩ䗉"),l1l111_l1_ (u"ࠩࠪ䗊"),l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗋"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗌"),l1l111_l1_ (u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ䗍"),l1l111_l1_ (u"࠭ࠧ䗎"),162,l1l111_l1_ (u"ࠧࠨ䗏"),l1l111_l1_ (u"ࠨࠩ䗐"),l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗑"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗒"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ䗓"),l1l111_l1_ (u"ࠬ࠭䗔"),163,l1l111_l1_ (u"࠭ࠧ䗕"),l1l111_l1_ (u"ࠧࠨ䗖"),l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗗"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗘"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥฮอฬࠢ฼ุํอฦ๋ࠩ䗙"),l1l111_l1_ (u"ࠫࠬ䗚"),164,l1l111_l1_ (u"ࠬ࠭䗛"),l1l111_l1_ (u"࠭ࠧ䗜"),l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗝"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗞"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䗟"),l1l111_l1_ (u"ࠪࠫ䗠"),763,l1l111_l1_ (u"ࠫࠬ䗡"),l1l111_l1_ (u"ࠬ࠭䗢"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䗣"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䗤"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䗥"),l1l111_l1_ (u"ࠩࠪ䗦"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗧"),l1l111_l1_ (u"ࠫ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ䗨"),l1l111_l1_ (u"ࠬ࠭䗩"),163,l1l111_l1_ (u"࠭ࠧ䗪"),l1l111_l1_ (u"ࠧࠨ䗫"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䗬"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗭"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ䗮"),l1l111_l1_ (u"ࠫࠬ䗯"),163,l1l111_l1_ (u"ࠬ࠭䗰"),l1l111_l1_ (u"࠭ࠧ䗱"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䗲"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗳"),l1l111_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ䗴"),l1l111_l1_ (u"ࠪࠫ䗵"),162,l1l111_l1_ (u"ࠫࠬ䗶"),l1l111_l1_ (u"ࠬ࠭䗷"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗸"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗹"),l1l111_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䗺"),l1l111_l1_ (u"ࠩࠪ䗻"),162,l1l111_l1_ (u"ࠪࠫ䗼"),l1l111_l1_ (u"ࠫࠬ䗽"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗾"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗿"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷࡚ࠦศฮอࠣ฽ู๎วว์ࠪ䘀"),l1l111_l1_ (u"ࠨࠩ䘁"),164,l1l111_l1_ (u"ࠩࠪ䘂"),l1l111_l1_ (u"ࠪࠫ䘃"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䘄"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘅"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭䘆"),l1l111_l1_ (u"ࠧࠨ䘇"),765,l1l111_l1_ (u"ࠨࠩ䘈"),l1l111_l1_ (u"ࠩࠪ䘉"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘊"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䘋"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䘌"),l1l111_l1_ (u"࠭ࠧ䘍"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘎"),l1l111_l1_ (u"ࠨไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭䘏"),l1l111_l1_ (u"ࠩࠪ䘐"),163,l1l111_l1_ (u"ࠪࠫ䘑"),l1l111_l1_ (u"ࠫࠬ䘒"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䘓"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘔"),l1l111_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ䘕"),l1l111_l1_ (u"ࠨࠩ䘖"),163,l1l111_l1_ (u"ࠩࠪ䘗"),l1l111_l1_ (u"ࠪࠫ䘘"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䘙"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘚"),l1l111_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ䘛"),l1l111_l1_ (u"ࠧࠨ䘜"),162,l1l111_l1_ (u"ࠨࠩ䘝"),l1l111_l1_ (u"ࠩࠪ䘞"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘟"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘠"),l1l111_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䘡"),l1l111_l1_ (u"࠭ࠧ䘢"),162,l1l111_l1_ (u"ࠧࠨ䘣"),l1l111_l1_ (u"ࠨࠩ䘤"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘥"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘦"),l1l111_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ䘧"),l1l111_l1_ (u"ࠬ࠭䘨"),164,l1l111_l1_ (u"࠭ࠧ䘩"),l1l111_l1_ (u"ࠧࠨ䘪"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䘫"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘬"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䘭"),l1l111_l1_ (u"ࠫࠬ䘮"),764,l1l111_l1_ (u"ࠬ࠭䘯"),l1l111_l1_ (u"࠭ࠧ䘰"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘱"))
	return
def l1l1lll1lll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘲"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ䘳")+l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨ䘴"),l1l111_l1_ (u"ࠫࠬ䘵"),764)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䘶"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䘷"),l1l111_l1_ (u"ࠧࠨ䘸"),9999)
	for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡌࡔࠬ䘹")+str(l1l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠩࡢࠫ䘺")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘻"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭䘼")+NUMBERS_SEQ_NAME[l1l1ll1l11l1_l1_],l1l111_l1_ (u"ࠬ࠭䘽"),764,l1l111_l1_ (u"࠭ࠧ䘾"),l1l111_l1_ (u"ࠧࠨ䘿"),l1l111_l1_ (u"ࠨࠩ䙀"),l1l111_l1_ (u"ࠩࠪ䙁"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䙂"):l1l1ll1l11l1_l1_})
	return
def l1l1ll1l1ll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䙃"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䙄")+l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪ䙅"),l1l111_l1_ (u"ࠧࠨ䙆"),765)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䙇"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䙈"),l1l111_l1_ (u"ࠪࠫ䙉"),9999)
	for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡕࠨ䙊")+str(l1l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠬࡥࠧ䙋")
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙌"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩ䙍")+NUMBERS_SEQ_NAME[l1l1ll1l11l1_l1_],l1l111_l1_ (u"ࠨࠩ䙎"),765,l1l111_l1_ (u"ࠩࠪ䙏"),l1l111_l1_ (u"ࠪࠫ䙐"),l1l111_l1_ (u"ࠫࠬ䙑"),l1l111_l1_ (u"ࠬ࠭䙒"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䙓"):l1l1ll1l11l1_l1_})
	return
def l1l1lll1ll1l_l1_(l1lll11ll11_l1_):
	global l1l1ll11lll1_l1_,l1l1ll11ll11_l1_
	l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_ = l1ll1lllll1_l1_(l1lll11ll11_l1_)
	try:
		if l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭䙔") in l1lll11ll11_l1_: l1lll1111ll_l1_(l1lll11ll11_l1_)
		else: l1lll1111ll_l1_()
		l1l1ll1l1l1l_l1_ = False
	except:
		l11l1llllll_l1_()
		l1l1ll1l1l1l_l1_ = True
	l1lll11ll11_l1_ = TRANSLATE(l1lll11ll11_l1_)
	if l1l1ll1l1l1l_l1_:
		l1ll1lll_l1_(l1lll11ll11_l1_,l1l111_l1_ (u"ࠨใื่๊ࠥไฤีไࠫ䙕"),time=2000)
		l1l1ll11lll1_l1_ += 1
		l1l1ll11ll11_l1_ += l1l111_l1_ (u"ࠩࠣࠫ䙖")+l1lll11ll11_l1_
	else: l1ll1lll_l1_(l1lll11ll11_l1_,l1l111_l1_ (u"ࠪࠫ䙗"),time=1000)
	return
def l1l1ll1l1111_l1_(l1l1ll1l1lll_l1_=True):
	global l1l1ll11lll1_l1_,l1l1ll11ll11_l1_
	if not l1l1ll1l1lll_l1_:
		global contentsDICT
		l1lll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䙘"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭䙙"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ䙚"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䙛"),l1l111_l1_ (u"ࠨࠩ䙜"),l1l111_l1_ (u"ࠩࠪ䙝"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䙞"),l1l111_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ䙟"))
	if l1llll111l_l1_!=1: return
	l1lll1l1ll1_l1_(False,False)
	l1l1l1ll1l11_l1_ = menuItemsLIST
	l1l1ll11lll1_l1_,l1l1ll11ll11_l1_,threads = 0,l1l111_l1_ (u"ࠬ࠭䙠"),{}
	for l1lll11ll11_l1_ in l1l11111111_l1_:
		time.sleep(0.5)
		threads[l1lll11ll11_l1_] = threading.Thread(target=l1l1lll1ll1l_l1_,args=(l1lll11ll11_l1_,))
		threads[l1lll11ll11_l1_].start()
		if l1l1ll11lll1_l1_>=l1l1lll11111_l1_: break
	else:
		for l1lll11ll11_l1_ in list(threads.keys()):
			threads[l1lll11ll11_l1_].join()
	menuItemsLIST[:] = l1l1l1ll1l11_l1_
	if l1l1ll11lll1_l1_>=l1l1lll11111_l1_: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䙡"),l1l111_l1_ (u"ࠧࠨ䙢"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䙣"),l1l111_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ䙤")+str(l1l1ll11lll1_l1_)+l1l111_l1_ (u"ࠪࠤ๊๎วใ฻้๋ࠣࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤํูศษ้สࠤ็ี๋ࠠๅ๋๊ࠥ฿ฯๆ๋ࠢะํีࠠฦ่อี๋๐สࠡใํࠤัํวำๅࠣ์์๐࠺ࠨ䙥")+l1l1ll11ll11_l1_)
	else:
		l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䙦"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘࡥࡁࡍࡎࠪ䙧"),contentsDICT,l1ll111l1ll_l1_)
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䙨"),l1l111_l1_ (u"ࠧࠨ䙩"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䙪"),l1l111_l1_ (u"ࠩอ้ࠥาไษࠢฯ้๏฿ࠠศๆฦๆุอๅࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ䙫"))
	l1lll1l1ll1_l1_(None,None)
	return
def l1l1ll111l11_l1_(l1l1ll1l11l1_l1_,options):
	l111lll111l_l1_ = False
	l1l1l1ll1111_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111lll111l_l1_ and l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䙬") not in options:
		l1lll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䙭"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䙮"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ䙯")+l1l1ll1l11l1_l1_)
	elif l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䙰") not in options or l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䙱") not in options:
		import IPTV
		message = l1l111_l1_ (u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠧ䙲")
		if l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䙳") not in options:
			try: IPTV.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䙴"),l1l111_l1_ (u"ࠬ࠭䙵"),l1l111_l1_ (u"࠭ࠧ䙶"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙷"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙸"),l1l111_l1_ (u"ࠩࠪ䙹"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䙺"),message)
			try: IPTV.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䙻"),l1l111_l1_ (u"ࠬ࠭䙼"),l1l111_l1_ (u"࠭ࠧ䙽"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙾"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙿"),l1l111_l1_ (u"ࠩࠪ䚀"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䚁"),message)
			try: IPTV.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚂"),l1l111_l1_ (u"ࠬ࠭䚃"),l1l111_l1_ (u"࠭ࠧ䚄"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䚅"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䚆"),l1l111_l1_ (u"ࠩࠪ䚇"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䚈"),message)
		if l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䚉") not in options:
			try: IPTV.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚊"),l1l111_l1_ (u"࠭ࠧ䚋"),l1l111_l1_ (u"ࠧࠨ䚌"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚍"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚎"),l1l111_l1_ (u"ࠪࠫ䚏"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ䚐"),message)
			try: IPTV.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䚑"),l1l111_l1_ (u"࠭ࠧ䚒"),l1l111_l1_ (u"ࠧࠨ䚓"),options+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚔"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䚕"),l1l111_l1_ (u"ࠪࠫ䚖"),l1l111_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ䚗"),message)
		l1lll_l1_ = menuItemsLIST
		if l111lll111l_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䚘"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࠧ䚙")+l1l1ll1l11l1_l1_,l1lll_l1_,l1ll111l1ll_l1_)
	menuItemsLIST[:] = l1l1l1ll1111_l1_
	return l1lll_l1_
def l1l1ll1l1l11_l1_(l1l1ll1l11l1_l1_,options):
	l111lll111l_l1_ = False
	l1l1l1ll1111_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l111lll111l_l1_ and l1l111_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ䚚") not in options:
		l1lll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䚛"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䚜"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ䚝")+l1l1ll1l11l1_l1_)
	elif l1l111_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ䚞") not in options or l1l111_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ䚟") not in options:
		import M3U
		message = l1l111_l1_ (u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ䚠")
		if l1l111_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䚡") not in options:
			try: M3U.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚢"),l1l111_l1_ (u"ࠩࠪ䚣"),l1l111_l1_ (u"ࠪࠫ䚤"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚥"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚦"),l1l111_l1_ (u"࠭ࠧ䚧"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䚨"),message)
			try: M3U.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚩"),l1l111_l1_ (u"ࠩࠪ䚪"),l1l111_l1_ (u"ࠪࠫ䚫"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚬"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚭"),l1l111_l1_ (u"࠭ࠧ䚮"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䚯"),message)
			try: M3U.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䚰"),l1l111_l1_ (u"ࠩࠪ䚱"),l1l111_l1_ (u"ࠪࠫ䚲"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚳"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚴"),l1l111_l1_ (u"࠭ࠧ䚵"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䚶"),message)
		if l1l111_l1_ (u"ࠨࡡ࡙ࡓࡉࡥࠧ䚷") not in options:
			try: M3U.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䚸"),l1l111_l1_ (u"ࠪࠫ䚹"),l1l111_l1_ (u"ࠫࠬ䚺"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䚻"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䚼"),l1l111_l1_ (u"ࠧࠨ䚽"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ䚾"),message)
			try: M3U.GROUPS(l1l1ll1l11l1_l1_,l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚿"),l1l111_l1_ (u"ࠪࠫ䛀"),l1l111_l1_ (u"ࠫࠬ䛁"),options+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛂"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䛃"),l1l111_l1_ (u"ࠧࠨ䛄"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦเࡎ࠵ࡘࠤ้๊โ็๊สฮࠬ䛅"),message)
		l1lll_l1_ = menuItemsLIST
		if l111lll111l_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ䛆"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࡡࠪ䛇")+l1l1ll1l11l1_l1_,l1lll_l1_,l1ll111l1ll_l1_)
	menuItemsLIST[:] = l1l1l1ll1111_l1_
	return l1lll_l1_
def l1l1ll1lllll_l1_(l1l1ll1l11l1_l1_,options,l1l1l1llll1l_l1_):
	if l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䛈") in options and l1l1l1llll1l_l1_==l1l111_l1_ (u"ࠬ࠭䛉"): l1l1ll1l1111_l1_(True)
	elif l1l1l1llll1l_l1_: l1l1ll1l1111_l1_(False)
	l1l1ll111111_l1_ = options.replace(l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䛊"),l1l111_l1_ (u"ࠧࠨ䛋")).replace(l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䛌"),l1l111_l1_ (u"ࠩࠪ䛍")).replace(l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䛎"),l1l111_l1_ (u"ࠫࠬ䛏"))
	if not l1l1l1llll1l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䛐"),l1l111_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ䛑"),l1l111_l1_ (u"ࠧࠨ䛒"),763,l1l111_l1_ (u"ࠨࠩ䛓"),l1l111_l1_ (u"ࠩࠪ䛔"),l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䛕")+l1l1ll111111_l1_,l1l111_l1_ (u"ࠫࠬ䛖"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䛗"):l1l1ll1l11l1_l1_})
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䛘"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䛙"),l1l111_l1_ (u"ࠨࠩ䛚"),9999)
	l1llllll11_l1_ = [l1l111_l1_ (u"ࠩฦๅ้อๅࠨ䛛"),l1l111_l1_ (u"ุ้๊ࠪำๅษอࠫ䛜"),l1l111_l1_ (u"ู๊ࠫัฮ์สฮࠬ䛝"),l1l111_l1_ (u"ࠬฮัศ็ฯࠫ䛞"),l1l111_l1_ (u"࠭รุใส่ࠥ๎ใาฬ๋๊ࠬ䛟"),l1l111_l1_ (u"ࠧา็ูห๋࠭䛠"),l1l111_l1_ (u"ࠨละำะ࠳รฯำࠪ䛡"),l1l111_l1_ (u"ࠩึ่ฬูไࠨ䛢"),l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ䛣"),l1l111_l1_ (u"ࠫศฺ็า࠯ฦ็ะืࠧ䛤"),l1l111_l1_ (u"ࠬอไร่ࠪ䛥"),l1l111_l1_ (u"࠭ึฮๅࠪ䛦"),l1l111_l1_ (u"ࠧา์สฺฮ࠭䛧"),l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ䛨"),l1l111_l1_ (u"่้ࠩะ๊๊็ࠩ䛩"),l1l111_l1_ (u"ࠪฬะࠦอ๋ࠩ䛪"),l1l111_l1_ (u"ࠫิ๐ๆ๋หࠪ䛫"),l1l111_l1_ (u"ูࠬๆ้ษอࠫ䛬"),l1l111_l1_ (u"࠭รฯำ์ࠫ䛭")]
	l1l1l1ll1l1l_l1_ = [l1l111_l1_ (u"ࠧศใ็ห๊࠭䛮"),l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ䛯"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ䛰"),l1l111_l1_ (u"ࠪๅ้๋ࠧ䛱")]
	l1ll11llll1_l1_ = [l1l111_l1_ (u"ู๊ࠫไิๆࠪ䛲"),l1l111_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䛳")]
	l1l1llll11l1_l1_ = [l1l111_l1_ (u"࠭ๅิษิัࠬ䛴"),l1l111_l1_ (u"ࠧๆีิั๏อสࠨ䛵")]
	l1l1l1llllll_l1_ = [l1l111_l1_ (u"ࠨสิห๊าࠧ䛶"),l1l111_l1_ (u"ࠩࡶ࡬ࡴࡽࠧ䛷"),l1l111_l1_ (u"ࠪฮ้็า๋๊้ࠫ䛸"),l1l111_l1_ (u"ࠫฯ๊๊โิํ์๋࠭䛹")]
	l1l1ll1llll1_l1_ = [l1l111_l1_ (u"ࠬอๆๆ์ࠪ䛺"),l1l111_l1_ (u"࠭ใาฬ๋๊ࠬ䛻"),l1l111_l1_ (u"ࠧไษิฮํ์ࠧ䛼"),l1l111_l1_ (u"ࠨ࡭࡬ࡨࡸ࠭䛽"),l1l111_l1_ (u"ฺࠩๅ้࠭䛾"),l1l111_l1_ (u"ࠪห฼็วๅࠩ䛿")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠫึ๋ึศ่ࠪ䜀")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠬออะอࠪ䜁"),l1l111_l1_ (u"࠭วฯำࠪ䜂"),l1l111_l1_ (u"ࠧๆ๊ัีࠬ䜃"),l1l111_l1_ (u"ࠨฮา๎ิ࠭䜄"),l1l111_l1_ (u"ฺ่ࠩฬ็ࠧ䜅"),l1l111_l1_ (u"ࠪัิ๐หࠨ䜆")]
	l1l1ll111l1l_l1_ = [l1l111_l1_ (u"ุ๊ࠫวิๆࠪ䜇"),l1l111_l1_ (u"ูࠬไิๆ๊ࠫ䜈")]
	l1l1l1l1lll1_l1_ = [l1l111_l1_ (u"࠭ว฻ษ้๎ࠬ䜉"),l1l111_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ䜊"),l1l111_l1_ (u"ࠨๅ็๎อ࠭䜋"),l1l111_l1_ (u"ࠩะๅ้࠭䜌"),l1l111_l1_ (u"ࠪࡱࡺࡹࡩࡤࠩ䜍")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠫฬ้หาࠩ䜎"),l1l111_l1_ (u"ࠬอิ่ำࠪ䜏"),l1l111_l1_ (u"࠭ๅๆ์ี๋ࠬ䜐"),l1l111_l1_ (u"ࠧศ฻็ํࠬ䜑"),l1l111_l1_ (u"ࠨ็ัฮฬื็ࠨ䜒"),l1l111_l1_ (u"่ࠩาฯอัศฬࠪ䜓"),l1l111_l1_ (u"ࠪห็๎้ࠨ䜔")]
	l1l1l1l1ll1l_l1_ = [l1l111_l1_ (u"ࠫฬ๊ว็ࠩ䜕"),l1l111_l1_ (u"ࠬำวๅ์ࠪ䜖"),l1l111_l1_ (u"࠭ๅฬสอࠫ䜗"),l1l111_l1_ (u"ࠧาษษะࠬ䜘")]
	l1l1l1ll111l_l1_ = [l1l111_l1_ (u"ࠨุะ็ࠬ䜙"),l1l111_l1_ (u"ࠩๆ์๊๐ฯ๋ࠩ䜚")]
	l1l1lll1l111_l1_ = [l1l111_l1_ (u"ࠪี๏อึ่ࠩ䜛"),l1l111_l1_ (u"่ࠫ๎ั่ࠩ䜜"),l1l111_l1_ (u"๋ࠬีศำ฼๋ࠬ䜝"),l1l111_l1_ (u"࠭ิ้ฬࠪ䜞"),l1l111_l1_ (u"ࠧา์สฺฮ࠭䜟")]
	l1l1ll1ll11l_l1_ = [l1l111_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ䜠"),l1l111_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ䜡"),l1l111_l1_ (u"๊ࠪ๏ะแๅ์ๆืࠬ䜢")]
	l1l1l1ll11ll_l1_ = [l1l111_l1_ (u"๊๋ࠫหๅ์้ࠫ䜣"),l1l111_l1_ (u"ࠬอิฯษุࠫ䜤"),l1l111_l1_ (u"࠭ๆอ๊่ࠫ䜥")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"ࠧษอࠣั๏࠭䜦"),l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䜧"),l1l111_l1_ (u"ࠩๅ๊ฬํࠧ䜨"),l1l111_l1_ (u"ࠪๆ๋๎วหࠩ䜩")]
	l1l1ll1lll11_l1_ = [l1l111_l1_ (u"ࠫิ๐ๆࠨ䜪"),l1l111_l1_ (u"ࠬอฯฺ์๊ࠫ䜫"),l1l111_l1_ (u"࠭า๋ษิหฯ࠭䜬"),l1l111_l1_ (u"ࠧๅู่๎ฬะࠧ䜭"),l1l111_l1_ (u"ࠨั฼หฦ࠭䜮"),l1l111_l1_ (u"ࠩๅีฬ์ࠧ䜯"),l1l111_l1_ (u"ࠪๆฺอฦะࠩ䜰"),l1l111_l1_ (u"ࠫึัวยࠩ䜱"),l1l111_l1_ (u"๋ࠬัอ฻ํ๋ࠬ䜲"),l1l111_l1_ (u"࠭วัษ้ࠫ䜳"),l1l111_l1_ (u"ࠧศี็ห๊࠭䜴"),l1l111_l1_ (u"ࠨฬ๋หู๐อࠨ䜵"),l1l111_l1_ (u"ࠩั฻อ࠭䜶"),l1l111_l1_ (u"ࠪัํุ่๋ࠩ䜷"),l1l111_l1_ (u"ࠫ฾ะศศฬࠪ䜸"),l1l111_l1_ (u"๋่ࠬศๆํำࠬ䜹"),l1l111_l1_ (u"࠭ๆ้ษ฼๎ࠬ䜺"),l1l111_l1_ (u"ฺࠧไสสิ࠭䜻"),l1l111_l1_ (u"ࠨษ้หู๐ฯࠨ䜼")]
	l1l1l1ll1ll1_l1_ = [l1l111_l1_ (u"ࠩ࠴࠽ࠬ䜽"),l1l111_l1_ (u"ࠪ࠶࠵࠭䜾"),l1l111_l1_ (u"ࠫ࠷࠷ࠧ䜿"),l1l111_l1_ (u"ࠬ࠸࠲ࠨ䝀"),l1l111_l1_ (u"࠭࠲࠴ࠩ䝁"),l1l111_l1_ (u"ࠧ࠳࠶ࠪ䝂"),l1l111_l1_ (u"ࠨ࠴࠸ࠫ䝃"),l1l111_l1_ (u"ࠩ࠵࠺ࠬ䝄")]
	if not l1l1l1llll1l_l1_:
		l1l1l1llll1l_l1_ = 0
		for l1l1ll1l111l_l1_ in l1llllll11_l1_:
			l1l1l1llll1l_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝅"),l1lllll_l1_+l1l1ll1l111l_l1_,l1l111_l1_ (u"ࠫࠬ䝆"),763,l1l111_l1_ (u"ࠬ࠭䝇"),str(l1l1l1llll1l_l1_),l1l1ll111111_l1_,l1l111_l1_ (u"࠭ࠧ䝈"),{l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䝉"):l1l1ll1l11l1_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l11111111l_l1_ = name.lower()
			category = []
			if any(value in l11111111l_l1_ for value in l1l1l1ll1l1l_l1_): category.append(1)
			if any(value in l11111111l_l1_ for value in l1ll11llll1_l1_): category.append(2)
			if any(value in l11111111l_l1_ for value in l1l1llll11l1_l1_): category.append(3)
			if any(value in l11111111l_l1_ for value in l1l1l1llllll_l1_): category.append(4)
			if any(value in l11111111l_l1_ for value in l1l1ll1llll1_l1_): category.append(5)
			if any(value in l11111111l_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l11111111l_l1_ for value in l1lllll1l_l1_) and l11111111l_l1_ not in [l1l111_l1_ (u"ࠨษัี๎࠭䝊")]: category.append(7)
			if any(value in l11111111l_l1_ for value in l1l1ll111l1l_l1_): category.append(8)
			if any(value in l11111111l_l1_ for value in l1l1l1l1lll1_l1_): category.append(9)
			if any(value in l11111111l_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l11111111l_l1_ for value in l1l1l1l1ll1l_l1_): category.append(11)
			if any(value in l11111111l_l1_ for value in l1l1l1ll111l_l1_): category.append(12)
			if any(value in l11111111l_l1_ for value in l1l1lll1l111_l1_): category.append(13)
			if any(value in l11111111l_l1_ for value in l1l1ll1ll11l_l1_): category.append(14)
			if any(value in l11111111l_l1_ for value in l1l1l1ll11ll_l1_): category.append(15)
			if any(value in l11111111l_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l11111111l_l1_ for value in l1l1ll1lll11_l1_): category.append(17)
			if any(value in l11111111l_l1_ for value in l1l1l1ll1ll1_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l1l1llll1l_l1_:
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝋"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠪࠫ䝌"),l1l111_l1_ (u"ࠫࠬ䝍"),l1l1ll111111_l1_+l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䝎"))
	return
def l1l1lll111l1_l1_(l1l1ll1l11l1_l1_,options):
	l111lll111l_l1_ = False
	if l111lll111l_l1_:
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䝏"),l1l111_l1_ (u"ࠧหฯา๎ะࠦ็ั้ࠣห้่วว็ฬࠫ䝐"),l1l111_l1_ (u"ࠨࠩ䝑"),764,l1l111_l1_ (u"ࠩࠪ䝒"),l1l111_l1_ (u"ࠪࠫ䝓"),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝔"),l1l111_l1_ (u"ࠬ࠭䝕"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䝖"):l1l1ll1l11l1_l1_})
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䝗"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䝘"),l1l111_l1_ (u"ࠩࠪ䝙"),9999)
	l1l1l1ll1111_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l1ll1l11l1_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l1ll1l11l1_l1_,True): return
		l1l1ll111ll1_l1_ = l1l1ll111l11_l1_(l1l1ll1l11l1_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll111ll1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䝚"),True): return
		if l111lll111l_l1_ and l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝛") not in options:
			l111l1ll11_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䝜"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭䝝"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࡂࡎࡏࠫ䝞"))
		else:
			l1l1l1ll1lll_l1_,l111l1ll11_l1_,l1l1ll111ll1_l1_ = [],[],[]
			for l1l1ll11llll_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1ll111l11_l1_(str(l1l1ll11llll_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1l1ll1lll_l1_:
					l1l1l1ll1lll_l1_.append(text)
					l1l1lll1l1l1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll111ll1_l1_.append(l1l1lll1l1l1_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll111ll1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111lll111l_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ䝟"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭䝠"),l111l1ll11_l1_,l1ll111l1ll_l1_)
	menuItemsLIST[:] = l1l1l1ll1111_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䝡"))
	return
def l1l1lll1ll11_l1_(l1l1ll1l11l1_l1_,options):
	l111lll111l_l1_ = False
	if l111lll111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䝢"),l1l111_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ䝣"),l1l111_l1_ (u"࠭ࠧ䝤"),765,l1l111_l1_ (u"ࠧࠨ䝥"),l1l111_l1_ (u"ࠨࠩ䝦"),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䝧"),l1l111_l1_ (u"ࠪࠫ䝨"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䝩"):l1l1ll1l11l1_l1_})
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䝪"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䝫"),l1l111_l1_ (u"ࠧࠨ䝬"),9999)
	l1l1l1ll1111_l1_ = menuItemsLIST[:]
	import M3U
	if l1l1ll1l11l1_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l1ll1l11l1_l1_,True): return
		l1l1ll111ll1_l1_ = l1l1ll1l1l11_l1_(l1l1ll1l11l1_l1_,options)
		l111l1ll11_l1_ = sorted(l1l1ll111ll1_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠨࠩ䝭"),True): return
		if l111lll111l_l1_ and l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䝮") not in options:
			l111l1ll11_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䝯"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࠪ䝰"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࡆࡒࡌࠨ䝱"))
		else:
			l1l1l1ll1lll_l1_,l111l1ll11_l1_,l1l1ll111ll1_l1_ = [],[],[]
			for l1l1ll11llll_l1_ in range(1,FOLDERS_COUNT+1):
				l111l1ll11_l1_ += l1l1ll1l1l11_l1_(str(l1l1ll11llll_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l111l1ll11_l1_:
				if text not in l1l1l1ll1lll_l1_:
					l1l1l1ll1lll_l1_.append(text)
					l1l1lll1l1l1_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llllll1ll_l1_
					l1l1ll111ll1_l1_.append(l1l1lll1l1l1_l1_)
			l111l1ll11_l1_ = sorted(l1l1ll111ll1_l1_,reverse=False,key=lambda key: key[1].lower())
			if l111lll111l_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ䝲"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪ䝳"),l111l1ll11_l1_,l1ll111l1ll_l1_)
	menuItemsLIST[:] = l1l1l1ll1111_l1_+l111l1ll11_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䝴"))
	return
def l1l1l1lll1ll_l1_(group,options):
	l111lll111l_l1_ = False
	l1lll_l1_ = []
	l1l1ll1l11ll_l1_ = l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䝵") if l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ䝶") in options else l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䝷")
	if l111lll111l_l1_: l1lll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ䝸"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠨ䝹")+l1l1ll1l11ll_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
			if l111lll111l_l1_: l1lll_l1_ += l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䝺"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䝻")+l1l1ll1l11ll_l1_[:-1],l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ䝼")+l1l1ll1l11ll_l1_+str(l1l1ll1l11l1_l1_))
			elif l1l1ll1l11ll_l1_==l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䝽"): l1lll_l1_ += l1l1ll111l11_l1_(str(l1l1ll1l11l1_l1_),l1l111_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䝾"))
			elif l1l1ll1l11ll_l1_==l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䝿"): l1lll_l1_ += l1l1ll1l1l11_l1_(str(l1l1ll1l11l1_l1_),l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䞀"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll_l1_:
			if text==group: l1lll11111ll_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
			l1l1ll1ll1ll_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"ࠧࠨ䞁")
			if l1l1ll1ll1ll_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l1ll1ll1ll_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l111lll111l_l1_: l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䞂")+l1l1ll1l11ll_l1_[:-1],group,l1lll_l1_,l1ll111l1ll_l1_)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䞃") in options and len(l1lll_l1_)>l1l1lll11l11_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䞄"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䞅")+group+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䞆"),group,165,l1l111_l1_ (u"࠭ࠧ䞇"),l1l111_l1_ (u"ࠧࠨ䞈"),l1l1ll1l11ll_l1_+l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䞉"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䞊"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䞋"),group,165,l1l111_l1_ (u"ࠫࠬ䞌"),l1l111_l1_ (u"ࠬ࠭䞍"),l1l1ll1l11ll_l1_+l1l111_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞎"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䞏"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䞐"),l1l111_l1_ (u"ࠩࠪ䞑"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1lll11l11_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ䞒"))
	return
def l1l1llll11ll_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䞓"),l1l111_l1_ (u"ࠬหูศัฬࠤ฼๊ศࠡไ้์ฬะฺࠠึ๋หห๐ษࠨ䞔"),l1l111_l1_ (u"࠭ࠧ䞕"),161,l1l111_l1_ (u"ࠧࠨ䞖"),l1l111_l1_ (u"ࠨࠩ䞗"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࠩ䞘"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䞙"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䞚"),l1l111_l1_ (u"ࠬ࠭䞛"),9999)
	l1l1lll1111l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1llll1llll1_l1_
	l1llll1llll1_l1_.ITEMS(l1l111_l1_ (u"࠭࠰ࠨ䞜"),False)
	l1llll1llll1_l1_.ITEMS(l1l111_l1_ (u"ࠧ࠲ࠩ䞝"),False)
	l1llll1llll1_l1_.ITEMS(l1l111_l1_ (u"ࠨ࠴ࠪ䞞"),False)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䞟") in options:
		menuItemsLIST[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1lll11l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lll11l11_l1_)
	menuItemsLIST[:] = l1l1lll1111l_l1_+menuItemsLIST
	return
def l1l1llll111l_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䞠"),l1l111_l1_ (u"ࠫࠬ䞡")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞢"),l1l111_l1_ (u"࠭ࠧ䞣"))
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䞤") : l1l111_l1_ (u"ࠨࠩ䞥") }
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨ䞦")
	data = {l1l111_l1_ (u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬ䞧"):l1l111_l1_ (u"ࠫ࠺࠶ࠧ䞨")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1llll111lll_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䞩"),url,data,headers,l1l111_l1_ (u"࠭ࠧ䞪"),l1l111_l1_ (u"ࠧࠨ䞫"),l1l111_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔ࠯ࡕࡅࡓࡊࡏࡎࡡ࡙ࡍࡉࡋࡏࡔࡡࡉࡖࡔࡓ࡟ࡘࡑࡕࡈࡘ࠳࠱ࡴࡶࠪ䞬"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫ䞭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ䞮"),block,re.DOTALL)
	l1l1l1l1l1ll_l1_,l1l1l1lll111_l1_ = list(zip(*items))
	l1l1lll1l1ll_l1_ = []
	l1l1llll1111_l1_ = [l1l111_l1_ (u"ࠫࠥ࠭䞯"),l1l111_l1_ (u"ࠬࠨࠧ䞰"),l1l111_l1_ (u"࠭ࡠࠨ䞱"),l1l111_l1_ (u"ࠧ࠭ࠩ䞲"),l1l111_l1_ (u"ࠨ࠰ࠪ䞳"),l1l111_l1_ (u"ࠩ࠽ࠫ䞴"),l1l111_l1_ (u"ࠪ࠿ࠬ䞵"),l1l111_l1_ (u"ࠦࠬࠨ䞶"),l1l111_l1_ (u"ࠬ࠳ࠧ䞷")]
	l1l1ll11111l_l1_ = l1l1l1lll111_l1_+l1l1l1l1l1ll_l1_
	for word in l1l1ll11111l_l1_:
		if word in l1l1l1lll111_l1_: l1l1ll1ll111_l1_ = 2
		if word in l1l1l1l1l1ll_l1_: l1l1ll1ll111_l1_ = 4
		l1l1ll1111ll_l1_ = [i in word for i in l1l1llll1111_l1_]
		if any(l1l1ll1111ll_l1_):
			index = l1l1ll1111ll_l1_.index(True)
			l1l1l1lllll1_l1_ = l1l1llll1111_l1_[index]
			l1l1lll11ll1_l1_ = l1l111_l1_ (u"࠭ࠧ䞸")
			if word.count(l1l1l1lllll1_l1_)>1: l1l1lll11lll_l1_,l1l1lll11l1l_l1_,l1l1lll11ll1_l1_ = word.split(l1l1l1lllll1_l1_,2)
			else: l1l1lll11lll_l1_,l1l1lll11l1l_l1_ = word.split(l1l1l1lllll1_l1_,1)
			if len(l1l1lll11lll_l1_)>l1l1ll1ll111_l1_: l1l1lll1l1ll_l1_.append(l1l1lll11lll_l1_.lower())
			if len(l1l1lll11l1l_l1_)>l1l1ll1ll111_l1_: l1l1lll1l1ll_l1_.append(l1l1lll11l1l_l1_.lower())
			if len(l1l1lll11ll1_l1_)>l1l1ll1ll111_l1_: l1l1lll1l1ll_l1_.append(l1l1lll11ll1_l1_.lower())
		elif len(word)>l1l1ll1ll111_l1_: l1l1lll1l1ll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1lll1l1ll_l1_)
	if l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䞹") in options:
		l1l1l1ll11l1_l1_ = l1lll11ll1ll_l1_
	elif l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䞺") in options:
		l1l1l1ll11l1_l1_ = [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ䞻")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䞼"),True): return
	elif l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䞽") in options:
		l1l1l1ll11l1_l1_ = [l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ䞾")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"࠭ࠧ䞿"),True): return
	count,l1l1l1lll11l_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䟀"),l1l111_l1_ (u"ࠨ࡝ࠣࠤࡢࠦ࠺ศๆหัะูࠦ็ࠩ䟁"),l1l111_l1_ (u"ࠩࠪ䟂"),164,l1l111_l1_ (u"ࠪࠫ䟃"),l1l111_l1_ (u"ࠫࠬ䟄"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟅")+options)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䟆"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅสะฯࠥอไฺึ๋หห๐ࠧ䟇"),l1l111_l1_ (u"ࠨࠩ䟈"),164,l1l111_l1_ (u"ࠩࠪ䟉"),l1l111_l1_ (u"ࠪࠫ䟊"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䟋")+options)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䟌"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䟍"),l1l111_l1_ (u"ࠧࠨ䟎"),9999)
	l1l1l1l1l1l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1lll1llll_l1_ = []
	for word in l1l1lll1l1ll_l1_:
		l1l1lll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡝ࠣࡠ࠱ࡢ࠻࡝࠼࡟࠱ࡡ࠱࡜࠾࡞ࠥࡠࠬࡢ࡛࡝࡟࡟ࠬࡡ࠯࡜ࡼ࡞ࢀࡠࠦࡢࡀࠨ䟏")+l1l111_l1_ (u"ࠩࠦࠫ䟐")+l1l111_l1_ (u"ࠪࡠࠩࡢࠥ࡝ࡠ࡟ࠪࡡ࠰࡜ࡠ࡞࠿ࡠࡃࡣࠧ䟑"),word,re.DOTALL)
		if l1l1lll11l1l_l1_: word = word.split(l1l1lll11l1l_l1_[0],1)[0]
		l1l1ll11l111_l1_ = word.replace(l1l111_l1_ (u"ࠫ๖࠭䟒"),l1l111_l1_ (u"ࠬ࠭䟓")).replace(l1l111_l1_ (u"࠭๎ࠨ䟔"),l1l111_l1_ (u"ࠧࠨ䟕")).replace(l1l111_l1_ (u"ࠨํࠪ䟖"),l1l111_l1_ (u"ࠩࠪ䟗")).replace(l1l111_l1_ (u"ࠪ๓ࠬ䟘"),l1l111_l1_ (u"ࠫࠬ䟙")).replace(l1l111_l1_ (u"ࠬ๒ࠧ䟚"),l1l111_l1_ (u"࠭ࠧ䟛"))
		l1l1ll11l111_l1_ = l1l1ll11l111_l1_.replace(l1l111_l1_ (u"ࠧ๑ࠩ䟜"),l1l111_l1_ (u"ࠨࠩ䟝")).replace(l1l111_l1_ (u"ࠩ๐ࠫ䟞"),l1l111_l1_ (u"ࠪࠫ䟟")).replace(l1l111_l1_ (u"ࠫ๗࠭䟠"),l1l111_l1_ (u"ࠬ࠭䟡")).replace(l1l111_l1_ (u"࠭ฌࠨ䟢"),l1l111_l1_ (u"ࠧࠨ䟣")).replace(l1l111_l1_ (u"ࠨโࠪ䟤"),l1l111_l1_ (u"ࠩࠪ䟥"))
		if l1l1ll11l111_l1_: l1l1lll1llll_l1_.append(l1l1ll11l111_l1_)
	l1l1ll1lll1l_l1_ = []
	for l1l111llll_l1_ in range(0,20):
		search = random.sample(l1l1lll1llll_l1_,1)[0]
		if search in l1l1ll1lll1l_l1_: continue
		l1l1ll1lll1l_l1_.append(search)
		l1lll11ll11_l1_ = random.sample(l1l1l1ll11l1_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䟦"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡗ࡫ࡧࡩࡴࠦࡓࡦࡣࡵࡧ࡭ࠦࠠࠡࡵ࡬ࡸࡪࡀࠧ䟧")+str(l1lll11ll11_l1_)+l1l111_l1_ (u"ࠬࠦࠠࡴࡧࡤࡶࡨ࡮࠺ࠨ䟨")+search)
		l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_ = l1ll1lllll1_l1_(l1lll11ll11_l1_)
		l1lll11l1ll_l1_(search+l1l111_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ䟩"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䟪"),l1l111_l1_ (u"ࠨࠩ䟫"))
	l1l1l1l1l1l1_l1_[0][1] = l1l111_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䟬")+search+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀศฮอࠣ฽๋ࡣࠧ䟭")
	menuItemsLIST[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1lll11l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1lll11l11_l1_)
	menuItemsLIST[:] = l1l1l1l1l1l1_l1_+menuItemsLIST
	return
def l1l1lll1l11l_l1_(l1l1l1llll11_l1_,options):
	l1l1l1llll11_l1_ = l1l1l1llll11_l1_.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䟮"),l1l111_l1_ (u"ࠬ࠭䟯"))
	options = options.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䟰"),l1l111_l1_ (u"ࠧࠨ䟱")).replace(l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟲"),l1l111_l1_ (u"ࠩࠪ䟳"))
	l1l1ll1l1111_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䟴") in options:
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䟵"),l1l111_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䟶")+l1l1l1llll11_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ䟷"),l1l1l1llll11_l1_,166,l1l111_l1_ (u"ࠧࠨ䟸"),l1l111_l1_ (u"ࠨࠩ䟹"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䟺")+options)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟻"),l1l111_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䟼"),l1l1l1llll11_l1_,166,l1l111_l1_ (u"ࠬ࠭䟽"),l1l111_l1_ (u"࠭ࠧ䟾"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟿")+options)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䠀"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䠁"),l1l111_l1_ (u"ࠪࠫ䠂"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l1l1llll11_l1_].keys())):
		type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1l1llll11_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䠃") in options or len(contentsDICT[l1l1l1llll11_l1_])==1:
			l1lll11111ll_l1_(type,l1l111_l1_ (u"ࠬ࠭䠄"),url,l1lll1l11111_l1_,l1l111_l1_ (u"࠭ࠧ䠅"),l1llllll1_l1_,text,l1l111_l1_ (u"ࠧࠨ䠆"),l1l111_l1_ (u"ࠨࠩ䠇"))
			menuItemsLIST[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
			l1l1l1ll1111_l1_,l111l1ll11_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l111l1ll11_l1_)
			if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䠈") in options: menuItemsLIST[:] = l1l1l1ll1111_l1_+l111l1ll11_l1_[:l1l1lll11l11_l1_]
			else: menuItemsLIST[:] = l1l1l1ll1111_l1_+l111l1ll11_l1_
		elif l1l111_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䠉") in options: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䠊"),l1l11l11_l1_,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	return
def l1l1ll111lll_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠋"),l1l111_l1_ (u"࠭ࠧ䠌")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠍"),l1l111_l1_ (u"ࠨࠩ䠎"))
	name,l1l1ll1111l1_l1_ = l1l111_l1_ (u"ࠩࠪ䠏"),[]
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠐"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䠑")+name+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䠒"),l1l111_l1_ (u"࠭ࠧ䠓"),mode,l1l111_l1_ (u"ࠧࠨ䠔"),l1l111_l1_ (u"ࠨࠩ䠕"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠖")+options)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䠗"),l1l111_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫ䠘"),l1l111_l1_ (u"ࠬ࠭䠙"),mode,l1l111_l1_ (u"࠭ࠧ䠚"),l1l111_l1_ (u"ࠧࠨ䠛"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䠜")+options)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䠝"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䠞"),l1l111_l1_ (u"ࠫࠬ䠟"),9999)
	l1l1l1ll1111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䠠") in options:
		l1l1ll1l1111_l1_(False)
		if contentsDICT=={}: return
		l1l1ll11l1l1_l1_ = list(contentsDICT.keys())
		l1l1l1llll11_l1_ = random.sample(l1l1ll11l1l1_l1_,1)[0]
		l1l1lll1l1ll_l1_ = list(contentsDICT[l1l1l1llll11_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1lll1l1ll_l1_,1)[0]
		type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = contentsDICT[l1l1l1llll11_l1_][l1l11l11_l1_]
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䠡"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪ䠢")+l1l11l11_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䠣")+name+l1l111_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ䠤")+url+l1l111_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭䠥")+str(l1lll1l11111_l1_))
	elif l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䠦") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䠧"),True): return
		for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll111l11_l1_(str(l1l1ll1l11l1_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䠨"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䠩")+name+l1l111_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䠪")+url+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䠫")+str(l1lll1l11111_l1_))
	elif l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䠬") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䠭"),True): return
		for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l1ll1l1l11_l1_(str(l1l1ll1l11l1_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1lll_l1_,1)[0]
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䠮"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䠯")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䠰")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䠱")+str(l1lll1l11111_l1_))
	l1l1ll1ll1l1_l1_ = name
	l1l1ll11ll1l_l1_ = []
	for i in range(0,10):
		if i>0: l1l111111l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䠲"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䠳")+name+l1l111_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䠴")+url+l1l111_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䠵")+str(l1lll1l11111_l1_))
		menuItemsLIST[:] = []
		if l1lll1l11111_l1_==234 and l1l111_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䠶") in text: l1lll1l11111_l1_ = 233
		if l1lll1l11111_l1_==714 and l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䠷") in text: l1lll1l11111_l1_ = 713
		if l1lll1l11111_l1_==144: l1lll1l11111_l1_ = 291
		dummy = l1lll11111ll_l1_(type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
		if l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䠸") in options and l1lll1l11111_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䠹") in options and l1lll1l11111_l1_==168: del menuItemsLIST[:3]
		l1l1ll1111l1_l1_[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
		if l1l1ll11ll1l_l1_ and l111lll1111_l1_(l1l111_l1_ (u"ࡸࠫา๊โสࠩ䠺")) in str(l1l1ll1111l1_l1_) or l111lll1111_l1_(l1l111_l1_ (u"ࡹࠬำไใ้ࠪ䠻")) in str(l1l1ll1111l1_l1_):
			name = l1l1ll1ll1l1_l1_
			l1l1ll1111l1_l1_[:] = l1l1ll11ll1l_l1_
			break
		l1l1ll1ll1l1_l1_ = name
		l1l1ll11ll1l_l1_ = l1l1ll1111l1_l1_
		if str(l1l1ll1111l1_l1_).count(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䠼"))>0: break
		if str(l1l1ll1111l1_l1_).count(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䠽"))>0: break
		if l1lll1l11111_l1_==233: break
		if l1lll1l11111_l1_==713: break
		if l1lll1l11111_l1_==291: break
		if l1l1ll1111l1_l1_: type,name,url,l1lll1l11111_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = random.sample(l1l1ll1111l1_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"ࠧ࠯࠰࠱࠲ࠬ䠾")
	elif name.count(l1l111_l1_ (u"ࠨࡡࠪ䠿"))>1: name = name.split(l1l111_l1_ (u"ࠩࡢࠫ䡀"),2)[2]
	name = name.replace(l1l111_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭䡁"),l1l111_l1_ (u"ࠫࠬ䡂"))
	name = name.replace(l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䡃"),l1l111_l1_ (u"࠭ࠧ䡄"))
	l1l1l1ll1111_l1_[0][1] = l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䡅")+name+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䡆")
	for i in range(9): random.shuffle(l1l1ll1111l1_l1_)
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䡇") in options: menuItemsLIST[:] = l1l1l1ll1111_l1_+l1l1ll1111l1_l1_[:l1l1lll11l11_l1_]
	else: menuItemsLIST[:] = l1l1l1ll1111_l1_+l1l1ll1111l1_l1_
	return
def l1l1l1lll1l1_l1_(l1l1l1l1ll11_l1_,l1l1lll111ll_l1_):
	l1l1lll111ll_l1_ = l1l1lll111ll_l1_.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡈"),l1l111_l1_ (u"ࠫࠬ䡉")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡊"),l1l111_l1_ (u"࠭ࠧ䡋"))
	l1l1ll11l11l_l1_ = l1l1lll111ll_l1_
	if l1l111_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䡌") in l1l1lll111ll_l1_:
		l1l1ll11l11l_l1_ = l1l1lll111ll_l1_.split(l1l111_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ䡍"))[0]
		type = l1l111_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䡎")
	elif l1l111_l1_ (u"࡚ࠪࡔࡊࠧ䡏") in l1l1l1l1ll11_l1_: type = l1l111_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ䡐")
	elif l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ䡑") in l1l1l1l1ll11_l1_: type = l1l111_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ䡒")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䡓"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䡔")+type+l1l1ll11l11l_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䡕"),l1l1l1l1ll11_l1_,167,l1l111_l1_ (u"ࠪࠫ䡖"),l1l111_l1_ (u"ࠫࠬ䡗"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡘")+l1l1lll111ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡙"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䡚"),l1l1l1l1ll11_l1_,167,l1l111_l1_ (u"ࠨࠩ䡛"),l1l111_l1_ (u"ࠩࠪ䡜"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡝")+l1l1lll111ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䡞"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䡟"),l1l111_l1_ (u"࠭ࠧ䡠"),9999)
	import IPTV
	for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䡡") in l1l1lll111ll_l1_: IPTV.GROUPS(str(l1l1ll1l11l1_l1_),l1l1l1l1ll11_l1_,l1l1lll111ll_l1_,l1l111_l1_ (u"ࠨࠩ䡢"),False)
		else: IPTV.ITEMS(str(l1l1ll1l11l1_l1_),l1l1l1l1ll11_l1_,l1l1lll111ll_l1_,l1l111_l1_ (u"ࠩࠪ䡣"),False)
	menuItemsLIST[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lll11l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lll11l11_l1_)
	return
def l1l1l1l1llll_l1_(l1l1l1l1ll11_l1_,l1l1lll111ll_l1_):
	l1l1lll111ll_l1_ = l1l1lll111ll_l1_.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䡤"),l1l111_l1_ (u"ࠫࠬ䡥")).replace(l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡦"),l1l111_l1_ (u"࠭ࠧ䡧"))
	l1l1ll11l11l_l1_ = l1l1lll111ll_l1_
	if l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡨") in l1l1lll111ll_l1_:
		l1l1ll11l11l_l1_ = l1l1lll111ll_l1_.split(l1l111_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䡩"))[0]
		type = l1l111_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ䡪")
	elif l1l111_l1_ (u"࡚ࠪࡔࡊࠧ䡫") in l1l1l1l1ll11_l1_: type = l1l111_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ䡬")
	elif l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ䡭") in l1l1l1l1ll11_l1_: type = l1l111_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ䡮")
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䡯"),l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䡰")+type+l1l1ll11l11l_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ䡱"),l1l1l1l1ll11_l1_,168,l1l111_l1_ (u"ࠪࠫ䡲"),l1l111_l1_ (u"ࠫࠬ䡳"),l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䡴")+l1l1lll111ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡵"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭䡶"),l1l1l1l1ll11_l1_,168,l1l111_l1_ (u"ࠨࠩ䡷"),l1l111_l1_ (u"ࠩࠪ䡸"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡹")+l1l1lll111ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䡺"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䡻"),l1l111_l1_ (u"࠭ࠧ䡼"),9999)
	import M3U
	for l1l1ll1l11l1_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡽") in l1l1lll111ll_l1_: M3U.GROUPS(str(l1l1ll1l11l1_l1_),l1l1l1l1ll11_l1_,l1l1lll111ll_l1_,l1l111_l1_ (u"ࠨࠩ䡾"),False)
		else: M3U.ITEMS(str(l1l1ll1l11l1_l1_),l1l1l1l1ll11_l1_,l1l1lll111ll_l1_,l1l111_l1_ (u"ࠩࠪ䡿"),False)
	menuItemsLIST[:] = l1l1ll11l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1lll11l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1lll11l11_l1_)
	return
def l1l1ll11l1ll_l1_(menuItemsLIST):
	l1l1ll1111l1_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ูࠪๆำษࠨ䢀") in name or l1l111_l1_ (u"ฺࠫ็อ่ࠩ䢁") in name or l1l111_l1_ (u"ࠬࡶࡡࡨࡧࠪ䢂") in name.lower(): continue
		l1l1ll1111l1_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_])
	return l1l1ll1111l1_l1_
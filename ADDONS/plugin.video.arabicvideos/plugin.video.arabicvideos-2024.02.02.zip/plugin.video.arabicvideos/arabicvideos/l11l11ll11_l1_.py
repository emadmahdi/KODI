# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬṐ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡈࡄࡢࠫṑ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪṒ"):l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠬṓ")}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==120: l1lll_l1_ = l1l1l11_l1_()
	elif mode==121: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==122: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==123: l1lll_l1_ = PLAY(url)
	elif mode==124: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧṔ")+text)
	elif mode==125: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨṕ")+text)
	elif mode==129: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪṖ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫṗ"),l1l111_l1_ (u"ࠬ࠭Ṙ"),129,l1l111_l1_ (u"࠭ࠧṙ"),l1l111_l1_ (u"ࠧࠨṚ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬṛ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṜ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬṝ"),l1l111_l1_ (u"ࠫࠬṞ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩṟ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧṠ"),headers,l1l111_l1_ (u"ࠧࠨṡ"),l1l111_l1_ (u"ࠨࠩṢ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬṣ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࠥ࡯࠭ࡩࡱࡰࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࠥ࡯࠭ࡧࡱ࡯ࡨࡪࡸࠢࠨṤ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ṥ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬอไๆืสี฾ฯࠧṦ") in title: continue
			title = title.rsplit(l1l111_l1_ (u"࠭࠾ࠨṧ"),1)[1]
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩṨ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪṩ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩṪ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬṫ")+l1lllll_l1_+title,l1ll1ll_l1_,122)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩṬ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧṭ"),l1l111_l1_ (u"࠭ࠧṮ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡲࡧࡩ࡯ࡎࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡻ࡫ࡲࡵ࡫ࡦࡥࡱࡊࡹ࡯ࡣࡰ࡭ࡨࠨࠧṯ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡧࡥࠥࡨࡤࡣࠤࡁࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬṰ"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫṱ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠪ࠳ࠬṲ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠫฬ๊ๅึษิ฽ฮ࠭ṳ") in title: continue
			if l1l111_l1_ (u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧṴ") in l1ll1ll_l1_: continue
			if not title and l1l111_l1_ (u"࠭࠯ࡵࡸ࠲ࡥࡷࡧࡢࡪࡥࠪṵ") in l1ll1ll_l1_: title = l1l111_l1_ (u"ࠧๆี็ื้อสࠡ฻ิฬ๏ฯࠧṶ")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṷ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫṸ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨṹ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ṻ"),l1l111_l1_ (u"ࠬ࠭ṻ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡢࠪ࠱࠮ࡄ࠯࠾ࡆࡩࡼࡆࡪࡹࡴ࠽࠱ࡤࡂࠬṼ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩṽ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪṾ"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩṿ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬẀ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨẁ"),url,l1l111_l1_ (u"ࠬ࠭Ẃ"),headers,l1l111_l1_ (u"࠭ࠧẃ"),l1l111_l1_ (u"ࠧࠨẄ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧẅ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡷࡤࡹࡣࡳࡱ࡯ࡰࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪẆ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫẇ"),block,re.DOTALL)
	if l1l111_l1_ (u"ࠫࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭Ẉ") not in url:
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẉ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩẊ"),url,125)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẋ"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫẌ"),url,124)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧẍ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬẎ"),l1l111_l1_ (u"ࠫࠬẏ"),9999)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẐ"),l1lllll_l1_+title,l1ll1ll_l1_,121)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"࠭࠱ࠨẑ")):
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩẒ")
	if l1l111_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࠫẓ") in url or l1l111_l1_ (u"ࠩࡂࠫẔ") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠪࠪࠬẕ")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠫࡄ࠭ẖ")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠬࡵࡵࡵࡲࡸࡸࡤ࡬࡯ࡳ࡯ࡤࡸࡂࡰࡳࡰࡰࠩࡳࡺࡺࡰࡶࡶࡢࡱࡴࡪࡥ࠾࡯ࡲࡺ࡮࡫ࡳࡠ࡮࡬ࡷࡹࠬࡰࡢࡩࡨࡁࠬẗ")+l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪẘ"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨẙ"),headers,l1l111_l1_ (u"ࠨࠩẚ"),l1l111_l1_ (u"ࠩࠪẛ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨẜ"))
	html = response.content
	name,items = l1l111_l1_ (u"ࠫࠬẝ"),[]
	if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧẞ") in url:
		name = re.findall(l1l111_l1_ (u"࠭࠼ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾ࠪẟ"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l111_l1_ (u"ࠧࠡࠩẠ")) + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬạ")
		else: name = xbmc.getInfoLabel( l1l111_l1_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠥẢ") ) + l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧả")
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࠬẤ") not in url: items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡜࡝࡞࡟ࠦ࠭ࡢ࡜࡝࡞࡟࠳ࡸ࡫ࡡࡴࡱࡱ࠲࠯ࡅࠩ࡝࡞࡟ࡠࠧ࠴ࠪࡀࡵࡵࡧࡂࡢ࡜࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦ࡞࡟ࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧấ"),html,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡝࡞࡟ࡠࠧ࠮࠮ࠫࡁࠬࡠࡡࡢ࡜ࠣ࠰࠭ࡃࡸࡸࡣ࠾࡞࡟ࡠࡡࠨࠨ࠯ࠬࡂ࠭ࡡࡢ࡜࡝ࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡠࡡࡢ࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩẦ"),html,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩầ") in url and l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࡞࠲ࠫẨ") not in l1ll1ll_l1_: continue
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫẩ") in url and l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡡ࠵ࠧẪ") not in l1ll1ll_l1_: continue
		title = name+escapeUNICODE(title).strip(l1l111_l1_ (u"ࠫࠥ࠭ẫ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨẬ"),l1l111_l1_ (u"࠭࠯ࠨậ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪẮ"),l1l111_l1_ (u"ࠨ࠱ࠪắ"))
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧẰ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩằ")+l1ll1l_l1_
		l1lllll1_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࠬẲ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨẳ") in l1lllll1_l1_ or l1l111_l1_ (u"࠭࠯࡮ࡣࡶࡶࡦ࡮ࡩࡺࡣࡷ࠳ࠬẴ") in url:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ẵ"),l1lllll_l1_+title,l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪẶ")),123,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩặ"),l1lllll_l1_+title,l1lllll1_l1_,121,l1ll1l_l1_)
	if len(items)>=12:
		l11l1l1l1l_l1_ = [l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬẸ"),l1l111_l1_ (u"ࠫ࠴ࡺࡶ࠰ࠩẹ"),l1l111_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࠨẺ"),l1l111_l1_ (u"࠭࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨ࠱ࠪẻ"),l1l111_l1_ (u"ࠧ࠰࡯ࡤࡷࡷࡧࡨࡪࡻࡤࡸ࠴࠭Ẽ")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l11l1l1l1l_l1_):
			for n in range(0,1100,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẽ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨẾ")+str(j),url,121,l1l111_l1_ (u"ࠪࠫế"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫỀ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫề")+str(i),url,121,l1l111_l1_ (u"࠭ࠧỂ"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧể"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧỄ")+str(1),url,121,l1l111_l1_ (u"ࠩࠪễ"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪỆ"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪệ")+str(n),url,121,l1l111_l1_ (u"ࠬ࠭Ỉ"),str(n))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ỉ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭Ị")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬị"):l1l111_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶ࠧỌ")}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧọ"),url,l1l111_l1_ (u"ࠫࠬỎ"),headers,l1l111_l1_ (u"ࠬ࠭ỏ"),l1l111_l1_ (u"࠭ࠧỐ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪố"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨỒ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡳ࡬ࡀࡵࡳ࡮ࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ồ"),html,re.DOTALL)
	if l11l11ll1l_l1_: server = l1l111l_l1_(l11l11ll1l_l1_[0],l1l111_l1_ (u"ࠪࡹࡷࡲࠧỔ"))
	else: server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨổ"))
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡧࡵࡵࡱ࠰ࡷ࡮ࢀࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧỖ"),html,re.DOTALL)
	if l11l1l11l1_l1_:
		l11l1l11l1_l1_ = server+l11l1l11l1_l1_[0]
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪỗ"),l11l1l11l1_l1_,l1l111_l1_ (u"ࠧࠨỘ"),headers,l1l111_l1_ (u"ࠨࠩộ"),l1l111_l1_ (u"ࠩࠪỚ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ớ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠫࡩࡵࡳࡵࡴࡨࡥࡲ࠭Ờ") not in l11l1ll1_l1_:
			l11l111l11_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡤࡴ࡬ࡴࡹ࠴ࠪࡀࡀࡩࡹࡳࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫờ"),l11l1ll1_l1_,re.DOTALL)
			l11l111l11_l1_ = l11l111l11_l1_[0]
			result = l11l11lll1_l1_(l11l111l11_l1_)
			try: l11l11l1ll_l1_,l11l1111l1_l1_,l11ll11l11_l1_ = result
			except:
				l1111l1_l1_(l1l111_l1_ (u"࠭ࠧỞ"),l1l111_l1_ (u"ࠧࠨở"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫỠ"),l1l111_l1_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣ࠲่ࠥฯࠡ์ๆ์๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦโศ็ࠣฬฯำฯ๋อูࠣๆำวห้ࠣ์ฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡ฻็ํ่ࠥัศรฬࠤฬ๊ีโฯสฮࠥอไอัํำฮ࠭ỡ"))
				return
			l11l1111l1_l1_ = server+l11l1111l1_l1_
			l11l11l1ll_l1_ = server+l11l11l1ll_l1_
			cookies = response.cookies
			if l1l111_l1_ (u"ࠪࡔࡘ࡙ࡉࡅࠩỢ") in cookies.keys():
				l11l11111l_l1_ = cookies[l1l111_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࠪợ")]
				headers[l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬỤ")] = l1l111_l1_ (u"࠭ࡐࡔࡕࡌࡈࡂ࠭ụ")+l11l11111l_l1_
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫỦ"),l11l11l1ll_l1_,l1l111_l1_ (u"ࠨࠩủ"),headers,l1l111_l1_ (u"ࠩࠪỨ"),l1l111_l1_ (u"ࠪࠫứ"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧỪ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪừ"),l11l1111l1_l1_,l11ll11l11_l1_,headers,l1l111_l1_ (u"࠭ࠧỬ"),l1l111_l1_ (u"ࠧࠨử"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫỮ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ữ"),l11l1l11l1_l1_,l1l111_l1_ (u"ࠪࠫỰ"),headers,l1l111_l1_ (u"ࠫࠬự"),l1l111_l1_ (u"ࠬ࠭Ỳ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠻ࡴࡩࠩỳ"))
				l11l1ll1_l1_ = response.content
		l11lllll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬỴ"),l11l1ll1_l1_,re.DOTALL)
		if l11lllll11_l1_:
			l11lllll11_l1_ = server+l11lllll11_l1_[0]
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(l11lllll11_l1_,headers)
			zz = zip(l1l1lll1_l1_,l1llll_l1_)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			for title,l1ll1ll_l1_ in zz:
				l111l1ll_l1_ = title.split(l1l111_l1_ (u"ࠨࠢࠣࠫỵ"))[1]
				l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡹ࡭ࡩࡹࡴࡳࡧࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭࠴ࡷ࠻ࡣࡤ࠭Ỷ")+l111l1ll_l1_)
				l11ll111ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰ࠳ࠬỷ"),l1l111_l1_ (u"ࠫ࠴ࡪ࡬࠰ࠩỸ")).replace(l1l111_l1_ (u"ࠬ࠵ࡳࡵࡴࡨࡥࡲ࠴࡭࠴ࡷ࠻ࠫỹ"),l1l111_l1_ (u"࠭ࠧỺ"))
				l1llll_l1_.append(l11ll111ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟࡮ࡲ࠷ࡣࡤ࠭ỻ")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧỼ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪỽ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫỾ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ỿ"),l1l111_l1_ (u"ࠬ࠱ࠧἀ"))
	url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࡴࡁࠬἁ") + l1lll1ll_l1_
	l1lll11_l1_(url)
	return
l1l11111_l1_ = [l1l111_l1_ (u"ࠧศๆ้์฾࠭ἂ"),l1l111_l1_ (u"ࠨษ็ื๋ฯࠧἃ"),l1l111_l1_ (u"ࠩส่อ๊ฯࠨἄ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠪหู้ๆสࠩἅ"),l1l111_l1_ (u"ࠫฬ๊ไ฻หࠪἆ"),l1l111_l1_ (u"ࠬอไษๆาࠫἇ"),l1l111_l1_ (u"࠭วๅัๅอࠬἈ"),l1l111_l1_ (u"ࠧศๆฯ์ิฯࠧἉ"),l1l111_l1_ (u"ࠨษ็ฮึาๅสࠩἊ"),l1l111_l1_ (u"ࠩส่๋๎ูࠨἋ"),l1l111_l1_ (u"ࠪห้ะี็์ไࠫἌ")]
l11lll_l1_ = []
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨἍ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩἎ"),url,l1l111_l1_ (u"࠭ࠧἏ"),headers,l1l111_l1_ (u"ࠧࠨἐ"),l1l111_l1_ (u"ࠨࠩἑ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬἒ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡷࡵࡰࡥࡱࡺࡲࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠢࠨἓ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	zz = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡻࡲࡳࡧࡱࡸࡤࡵࡰࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ἔ"),block,re.DOTALL)
	l11l1ll111_l1_,l11l1lll1l_l1_ = zip(*zz)
	l1l11l1l_l1_ = zip(l11l1ll111_l1_,l11l1lll1l_l1_,l11l1ll111_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫἕ"),block,re.DOTALL)
	l11l111111_l1_ = []
	for l1ll1ll_l1_,name in items:
		name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ἖"))
		value = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠧ࠰ࠩ἗"),1)[1]
		if name in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠨๆ็็ออัࠨἘ") in name: continue
		if l1l111_l1_ (u"ࠩࡗ࡚࠲ࡓࡁࠨἙ") in name: continue
		if l1l111_l1_ (u"ࠪࡘ࡛࠳࠱࠵ࠩἚ") in name: continue
		l11l111111_l1_.append((value,name))
	return l11l111111_l1_
def l11l1l11ll_l1_(l1l1ll11_l1_,url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨἛ"),1)[0]
	url = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧἜ"))
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨἝ"))
	l11ll111_l1_ = l11ll111_l1_.replace(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ἞"),l1l111_l1_ (u"ࠨ࠯ࠪ἟"))
	url = url+l1l111_l1_ (u"ࠩ࠲ࠫἠ")+l11ll111_l1_
	return url
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠪࡃࠬἡ") in url: url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨἢ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩἣ"),1)
	if filter==l1l111_l1_ (u"࠭ࠧἤ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠧࠨἥ"),l1l111_l1_ (u"ࠨࠩἦ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ἧ"))
	if type==l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭Ἠ"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠫࡂ࠭Ἡ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠬࡃࠧἪ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨἫ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪἬ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪἭ")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬἮ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬἯ"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨἰ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧἱ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩἲ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫἳ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫἴ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫἵ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ἶ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨἷ")+l11lll11_l1_
		l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἸ"),l1lllll_l1_+l1l111_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩἹ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧἺ"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨἻ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨἼ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨἽ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ἶ"),l1l111_l1_ (u"ࠬ࠭Ἷ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		l1l111ll_l1_ = l1l111ll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨὀ"))
		name = name.strip(l1l111_l1_ (u"ࠧࠡࠩὁ"))
		name = name.replace(l1l111_l1_ (u"ࠨ࠯࠰ࠫὂ"),l1l111_l1_ (u"ࠩࠪὃ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠪࡁࠬὄ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧὅ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,url)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ὆")+l1l111l1_l1_)
				return
			else:
				l1llllll_l1_ = l11l1l11ll_l1_(l11lll11_l1_,l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭὇"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨὈ"),l1llllll_l1_,121)
				else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨὉ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪὊ"),l1lllll1_l1_,125,l1l111_l1_ (u"ࠪࠫὋ"),l1l111_l1_ (u"ࠫࠬὌ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨὍ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ὎")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪ὏")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪὐ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀ࠴ࠬὑ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧὒ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫὓ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧὔ")+name,l1lllll1_l1_,124,l1l111_l1_ (u"࠭ࠧὕ"),l1l111_l1_ (u"ࠧࠨὖ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪὗ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ὘")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬὙ")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭὚")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩὛ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ὜")+name
			if type==l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪὝ"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ὞"),l1lllll_l1_+title,url,124,l1l111_l1_ (u"ࠩࠪὟ"),l1l111_l1_ (u"ࠪࠫὠ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧὡ") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠬࡃࠧὢ") in l11lll1l_l1_:
				l1llllll_l1_ = l11l1l11ll_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ὣ"),l1lllll_l1_+title,l1llllll_l1_,121)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧὤ"),l1lllll_l1_+title,url,125,l1l111_l1_ (u"ࠨࠩὥ"),l1l111_l1_ (u"ࠩࠪὦ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠪࡁࠫ࠭ὧ"),l1l111_l1_ (u"ࠫࡂ࠶ࠦࠨὨ"))
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠧὩ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"࠭࠽ࠨὪ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠧࠧࠩὫ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠨ࠿ࠪὬ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠩࠪὭ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬὮ")
		if l1l111_l1_ (u"ࠫࠪ࠭Ὧ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧὰ") and value!=l1l111_l1_ (u"࠭࠰ࠨά"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫὲ")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫέ") and value!=l1l111_l1_ (u"ࠩ࠳ࠫὴ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬή")+key+l1l111_l1_ (u"ࠫࡂ࠭ὶ")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪί"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨὸ")+key+l1l111_l1_ (u"ࠧ࠾ࠩό")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬὺ"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫύ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠪࡁ࠵࠭ὼ"),l1l111_l1_ (u"ࠫࡂ࠭ώ"))
	return l1l1l111_l1_
def l11ll11111_l1_(l11l1111ll_l1_):
	m = re.search(l1l111_l1_ (u"ࡷ࠭࡞ࠩ࡞ࡧ࠯࠮ࡡ࠮࠭࡟ࡂࡠࡩ࠰࠿ࠨ὾"), str(l11l1111ll_l1_))
	return int(m.groups()[-1]) if m and not callable(l11l1111ll_l1_) else 0
def l11l11l11l_l1_(l11l1llll1_l1_):
	try:
		l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_)
	except:
		try:
			l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_+l1l111_l1_ (u"࠭࠽ࠨ὿"))
		except:
			try:
				l11l1ll1l1_l1_ = base64.b64decode(l11l1llll1_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪᾀ"))
			except:
				l11l1ll1l1_l1_ = l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡢࡢࡵࡨ࠺࠹ࠦࡤࡦࡥࡲࡨࡪࠦࡥࡳࡴࡲࡶࠬᾁ")
	if PY3: l11l1ll1l1_l1_ = l11l1ll1l1_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᾂ"))
	return l11l1ll1l1_l1_
def l11l111lll_l1_(l11l1ll11l_l1_,l11l1l1ll1_l1_,a):
	a = a - l11l1l1ll1_l1_
	if a<0:
		c = l1l111_l1_ (u"ࠪࡹࡳࡪࡥࡧ࡫ࡱࡩࡩ࠭ᾃ")
	else:
		c = l11l1ll11l_l1_[a]
	return c
def x(l11l1ll11l_l1_,l11l1l1ll1_l1_,a):
	return(l11l111lll_l1_(l11l1ll11l_l1_,l11l1l1ll1_l1_,a))
def l11l1ll1ll_l1_(l11ll1111l_l1_,step,l11l1l1ll1_l1_,l11l11llll_l1_):
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࠩᾄ"),l1l111_l1_ (u"ࠬ࡭࡬ࡰࡤࡤࡰࠥࡪ࠻ࠡࠩᾅ"))
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"࠭ࡸࠩࠩᾆ"),l1l111_l1_ (u"ࠧࡹࠪࡷࡥࡧ࠲ࡳࡵࡧࡳ࠶࠱࠭ᾇ"))
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࠡࡦ࠾ࠤࡩࡃࠧᾈ"),l1l111_l1_ (u"ࠩࠪᾉ"))
	d = eval(l11l11llll_l1_,{l1l111_l1_ (u"ࠪࡴࡦࡸࡳࡦࡋࡱࡸࠬᾊ"):l11ll11111_l1_,l1l111_l1_ (u"ࠫࡽ࠭ᾋ"):x,l1l111_l1_ (u"ࠬࡺࡡࡣࠩᾌ"):l11ll1111l_l1_,l1l111_l1_ (u"࠭ࡳࡵࡧࡳ࠶ࠬᾍ"):l11l1l1ll1_l1_})
	l11ll11ll1_l1_=0
	while True:
		l11ll11ll1_l1_=l11ll11ll1_l1_+1
		l11ll1111l_l1_.append(l11ll1111l_l1_[0])
		del l11ll1111l_l1_[0]
		d = eval(l11l11llll_l1_,{l1l111_l1_ (u"ࠧࡱࡣࡵࡷࡪࡏ࡮ࡵࠩᾎ"):l11ll11111_l1_,l1l111_l1_ (u"ࠨࡺࠪᾏ"):x,l1l111_l1_ (u"ࠩࡷࡥࡧ࠭ᾐ"):l11ll1111l_l1_,l1l111_l1_ (u"ࠪࡷࡹ࡫ࡰ࠳ࠩᾑ"):l11l1l1ll1_l1_})
		if ((d == step) or (l11ll11ll1_l1_>10000)): break
	return
def l11l11lll1_l1_(l11l111l11_l1_):
	tmp = re.findall(l1l111_l1_ (u"ࠫࡻࡧࡲ࠯ࠬࡂࡁ࠭࠴ࡻ࠳࠮࠷ࢁ࠮ࡢࠨ࡝ࠫࠪᾒ"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼࡙ࡥࡷࡩ࡯࡯ࡵࡷࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧᾓ")
	l11l111l1l_l1_ = tmp[0].strip()
	_print(l1l111_l1_ (u"࠭ࡖࡢࡴࡦࡳࡳࡹࡴࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪᾔ") % l11l111l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠧࡾ࡞ࠫࠫᾕ")+l11l111l1l_l1_+l1l111_l1_ (u"ࠨࡁ࠯ࠬ࠵ࡾ࡛࠱࠯࠼ࡥ࠲࡬࡝ࡼ࠳࠯࠵࠵ࢃࠩ࡝ࠫ࡟࠭ࡀ࠭ᾖ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࠠࡔࡶࡨࡴ࠶ࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩᾗ")
	step = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠪࡗࡹ࡫ࡰ࠲ࠢࠣࠤࠥࠦࠠࠡࠢࡀࠤ࠵ࡾࠥࡴࠩᾘ") % l1l111_l1_ (u"ࠫࢀࡀ࠰࠳࡚ࢀࠫᾙ").format(step).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠬࡪ࠽ࡥ࠯ࠫ࠴ࡽࡡ࠰࠮࠻ࡤ࠱࡫ࡣࡻ࠲࠮࠴࠴ࢂ࠯࠻ࠨᾚ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࡗࡹ࡫ࡰ࠳ࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾛ")
	l11l1l1ll1_l1_ = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡔࡶࡨࡴ࠷ࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡ࠲ࡻࠩࡸ࠭ᾜ") % l1l111_l1_ (u"ࠨࡽ࠽࠴࠷࡞ࡽࠨᾝ").format(l11l1l1ll1_l1_).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠤࡷࡶࡾࢁࠨࡷࡣࡵ࠲࠯ࡅࠩ࠼ࠤᾞ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࡥࡧࡦࡥࡱࡥࡦ࡯ࡥࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭ᾟ")
	l11l11llll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠫࡉ࡫ࡣࡢ࡮ࠣࡪࡺࡴࡣࠡࠢࠣࡁࠥࠨࠠࠦࡵ࠱࠲࠳ࠨࠧᾠ") % l11l11llll_l1_[0:135])
	tmp = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡢࡶࡤࠫ࠿ࢁࠧࠩࡡ࡞࠴࠲࠿ࡡ࠮ࡼࡄ࠱࡟ࡣࡻ࠲࠲࠯࠶࠵ࢃࠩࠨ࠼ࠪࡳࡰ࠭ࠢᾡ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࡔࡴࡹࡴࡌࡧࡼࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧᾢ")
	l11l1lllll_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠧࡑࡱࡶࡸࡐ࡫ࡹࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫᾣ") % l11l1lllll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠣࡨࡸࡲࡨࡺࡩࡰࡰࠣࠦᾤ")+l11l111l1l_l1_+l1l111_l1_ (u"ࠤ࠱࠮ࡄࡼࡡࡳ࠰࠭ࡃࡂ࠮࡜࡜࠰࠭ࡃࡢ࠯ࠢᾥ"), l11l111l11_l1_)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࡕࡣࡥࡐ࡮ࡹࡴࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾦ")
	l11l1l1l11_l1_ = tmp[0]
	l11l1l1l11_l1_ = l11l111l1l_l1_ + l1l111_l1_ (u"ࠦࡂࠨᾧ") + l11l1l1l11_l1_
	exec(l11l1l1l11_l1_) in globals(), locals()
	l11l1ll11l_l1_ = locals()[l11l111l1l_l1_]
	_print(l11l111l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩ࠳࠿࠰ࡴ࠰࠱࠲ࠬᾨ")%str(l11l1ll11l_l1_))
	l11l1ll1ll_l1_(l11l1ll11l_l1_,step,l11l1l1ll1_l1_,l11l11llll_l1_)
	_print(l11l111l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪ࠴࠹࠱ࡵ࠱࠲࠳࠭ᾩ")%str(l11l1ll11l_l1_))
	tmp = re.findall(l1l111_l1_ (u"ࠢ࡝ࠪ࡟࠭ࡀ࠮ࡶࡢࡴࠣ࠲࠯ࡅࠩ࡝ࠦ࡟ࠬࠬࡢࠪࠨ࡞ࠬࠦᾪ"), l11l111l11_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l111_l1_ (u"ࠣࡣ࠳ࡥࡡ࠮࡜ࠪ࠽ࠫ࠲࠯ࡅࠩ࡝ࠦ࡟ࠬࠬࡢࠪࠨ࡞ࠬࠦᾫ"), l11l111l11_l1_, re.S)
		if not tmp:
			return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࡌࡪࡵࡷࡣ࡛ࡧࡲࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾬ")
	l11ll11l1l_l1_ = tmp[0]
	l11ll11l1l_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦ࠮ࠫࡁࢀ࠲࠯ࡅࡽࠪࠤᾭ"), l1l111_l1_ (u"ࠦࠧᾮ"), l11ll11l1l_l1_)
	_print(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡢ࡚ࡦࡸࠠࠡࠢࠣࠤࡂࠦࠥ࠯࠻࠳ࡷ࠳࠴࠮ࠨᾯ") % l11ll11l1l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࠨࡠ࡝ࡤ࠱ࡿࡇ࠭ࡻ࠲࠰࠽ࡢࢁ࠴࠭࠺ࢀ࠭ࡂࡢ࡛࡝࡟ࠥᾰ") , l11ll11l1l_l1_)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾࠸࡜ࡡࡳࡵࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭ᾱ")
	_11l1l1lll_l1_ = tmp
	_print(l1l111_l1_ (u"ࠨ࠵࡙ࡥࡷࡹࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬᾲ")%str(_11l1l1lll_l1_))
	l11l1l111l_l1_ = _11l1l1lll_l1_[1]
	_print(l1l111_l1_ (u"ࠩࡥ࡭࡬ࡥࡳࡵࡴࡢࡺࡦࡸࠠࠡ࠿ࠣࠩࡸ࠭ᾳ")%l11l1l111l_l1_)
	l11ll11l1l_l1_ = l11ll11l1l_l1_.replace(l1l111_l1_ (u"ࠪ࠰ࠬᾴ"),l1l111_l1_ (u"ࠫࡀ࠭᾵")).split(l1l111_l1_ (u"ࠬࡁࠧᾶ"))
	for l11l1llll1_l1_ in l11ll11l1l_l1_:
		l11l1llll1_l1_ = l11l1llll1_l1_.strip()
		if l1l111_l1_ (u"࠭ࡩࡴ࡯ࡲࡦࠬᾷ") in l11l1llll1_l1_: l11l1llll1_l1_=l1l111_l1_ (u"ࠧࠨᾸ")
		if l1l111_l1_ (u"ࠨ࠿࡞ࡡࠬᾹ")   in l11l1llll1_l1_: l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠩࡀ࡟ࡢ࠭Ὰ"),l1l111_l1_ (u"ࠪࡁࢀࢃࠧΆ"))
		l11l1llll1_l1_ = re.sub(l1l111_l1_ (u"ࠦ࠭ࡧ࠰࠯࡞ࠫ࠭ࠧᾼ"), l1l111_l1_ (u"ࠧࡧ࠰ࡥࠪࡰࡥ࡮ࡴ࡟ࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠦ᾽"), l11l1llll1_l1_)
		if l11l1llll1_l1_!=l1l111_l1_ (u"࠭ࠧι"):
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠧࠢࠣ࡞ࡡࠬ᾿"),l1l111_l1_ (u"ࠨࡖࡵࡹࡪ࠭῀"));
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠩࠤ࡟ࡢ࠭῁"),l1l111_l1_ (u"ࠪࡊࡦࡲࡳࡦࠩῂ"));
			l11l1llll1_l1_ = l11l1llll1_l1_.replace(l1l111_l1_ (u"ࠫࡻࡧࡲࠡࠩῃ"),l1l111_l1_ (u"ࠬ࠭ῄ"));
			try:
				exec(l11l1llll1_l1_,{l1l111_l1_ (u"࠭ࡰࡢࡴࡶࡩࡎࡴࡴࠨ῅"):l11ll11111_l1_,l1l111_l1_ (u"ࠧࡢࡶࡲࡦࠬῆ"):l11l11l11l_l1_,l1l111_l1_ (u"ࠨࡣ࠳ࡨࠬῇ"):l11l111lll_l1_,l1l111_l1_ (u"ࠩࡻࠫῈ"):x,l1l111_l1_ (u"ࠪࡱࡦ࡯࡮ࡠࡶࡤࡦࠬΈ"):l11l1ll11l_l1_,l1l111_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪῊ"):l11l1l1ll1_l1_},locals())
			except:
				pass
	l11ll111l1_l1_ = l1l111_l1_ (u"ࠬ࠭Ή")
	for i in range(0,len(locals()[_11l1l1lll_l1_[2]])):
		if locals()[_11l1l1lll_l1_[2]][i] in locals()[_11l1l1lll_l1_[1]]:
			l11ll111l1_l1_ = l11ll111l1_l1_ + locals()[_11l1l1lll_l1_[1]][locals()[_11l1l1lll_l1_[2]][i]]
	_print(l1l111_l1_ (u"࠭ࡢࡪࡩࡖࡸࡷ࡯࡮ࡨࠢࠣࠤࠥࡃࠠࠦ࠰࠼࠴ࡸ࠴࠮࠯ࠩῌ")%l11ll111l1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡧࡃ࡜ࠨ࠱࡟ࠫࡡ࠱ࠨ࠯ࠬࡂ࠭࠭ࡅ࠺࠭ࡾ࠾࠭ࠬ῍"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡇࡦࡶࡘࡶࡱࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ῎")
	l11l111ll1_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠩࡊࡩࡹ࡛ࡲ࡭ࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩࡸ࠭῏") % l11l111ll1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠪࠬࡤ࠴ࠪࡀࠫ࡟࡟ࠬῐ"), l11l111ll1_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࠢࡊࡩࡹ࡜ࡡࡳࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬῑ")
	l11l11l111_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠬࡍࡥࡵࡘࡤࡶࠥࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩῒ") % l11l11l111_l1_)
	l11l1lll11_l1_ = locals()[l11l11l111_l1_][0]
	l11l1lll11_l1_ = l11l11l11l_l1_(l11l1lll11_l1_)
	_print(l1l111_l1_ (u"࠭ࡇࡦࡶ࡙ࡥࡱࠦࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪΐ") % l11l1lll11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠧࡾࡸࡤࡶࠥ࠮ࡦ࠾࠰࠭ࡃ࠮ࡁࠧ῔"), l11l111l11_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡐࡰࡵࡷ࡙ࡷࡲࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪ῕")
	l11l11l1l1_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠩࡓࡳࡸࡺࡕࡳ࡮ࠣࠤࠥࠦࠠࠡ࠿ࠣࠩࡸ࠭ῖ") % l11l11l1l1_l1_)
	l11l11l1l1_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬࡼ࡯࡮ࡥࡱࡺࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠧῗ"), l1l111_l1_ (u"ࠦࡦࡺ࡯ࡣࠤῘ"), l11l11l1l1_l1_)
	l11l11l1l1_l1_ = re.sub(l1l111_l1_ (u"ࠧ࠮࡛ࡂ࠯࡝ࡡࢀ࠷ࠬ࠳ࡿ࡟ࠬ࠮ࠨῙ"), l1l111_l1_ (u"ࠨࡡ࠱ࡦࠫࡱࡦ࡯࡮ࡠࡶࡤࡦ࠱ࡹࡴࡦࡲ࠵࠰ࠧῚ"), l11l11l1l1_l1_)
	l11l11l1l1_l1_ = l1l111_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡧ࠽ࠣࠫΊ")+l11l11l1l1_l1_
	verify = re.findall(l1l111_l1_ (u"ࠨ࡞࠮ࠬࡤ࠴ࠪࡀࠫࠧࠫ῜"),l11l11l1l1_l1_,re.DOTALL)[0]
	l11l1l1111_l1_ = eval(verify)
	l11l11l1l1_l1_ = l11l11l1l1_l1_.replace(l1l111_l1_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࠢࡩ࠿ࠥ࡬࠽ࠨ῝"),l1l111_l1_ (u"ࠪࠫ῞"))
	f = eval(l11l11l1l1_l1_,{l1l111_l1_ (u"ࠫࡦࡺ࡯ࡣࠩ῟"):l11l11l11l_l1_,l1l111_l1_ (u"ࠬࡧ࠰ࡥࠩῠ"):l11l111lll_l1_,l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡣࡹࡧࡢࠨῡ"):l11l1ll11l_l1_,l1l111_l1_ (u"ࠧࡴࡶࡨࡴ࠷࠭ῢ"):l11l1l1ll1_l1_,verify:l11l1l1111_l1_})
	_print(l1l111_l1_ (u"ࠨ࠱ࠪΰ")+l11l1lll11_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧῤ")+f+l11ll111l1_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨῥ")+l11l1lllll_l1_)
	return([l1l111_l1_ (u"ࠫ࠴࠭ῦ")+l11l1lll11_l1_,f+l11ll111l1_l1_,{ l11l1lllll_l1_ : l1l111_l1_ (u"ࠬࡵ࡫ࠨῧ")}])
def _print(text):
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨῨ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡇࡅ࠵ࡤ࠭Ῡ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ๆฮอะ๊ࠨῪ"),l1l111_l1_ (u"ࠩส๎ั๐ࠠษีอࠫΎ")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==770: l1lll_l1_ = l1l1l11_l1_()
	elif mode==771: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==772: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==773: l1lll_l1_ = PLAY(url)
	elif mode==774: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫῬ")+text)
	elif mode==775: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ῭")+text)
	elif mode==776: l1lll_l1_ = l1111lll1_l1_(url,l1llllll1_l1_)
	elif mode==779: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ΅"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭`"),l1l111_l1_ (u"ࠧࠨ῰"),779,l1l111_l1_ (u"ࠨࠩ῱"),l1l111_l1_ (u"ࠩࠪῲ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧῳ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῴ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ῵"),l1l111_l1_ (u"࠭ࠧῶ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫῷ"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩῸ"),l1l111_l1_ (u"ࠩࠪΌ"),l1l111_l1_ (u"ࠪࠫῺ"),l1l111_l1_ (u"ࠫࠬΏ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩῼ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡮ࡢࡸ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ´"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭῾"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ῿"))
			if any(value in title for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ "),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ ")+l1lllll_l1_+title,l1ll1ll_l1_,771)
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ "),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ "),l1l111_l1_ (u"࠭ࠧ "),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࡷࡴࡩࡩࡢ࡮࠰ࡦࡴࡾࠧ "),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ "),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ "))
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ "),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ ")+l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠬ࠭ "),l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱࡱࡪࡴࡵࠨ​"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ‌"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ‍"),l1l111_l1_ (u"ࠩࠪ‎"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ‏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ‐"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ‑"))
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭‒"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ–")+l1lllll_l1_+title,l1ll1ll_l1_,771)
	return html
def l1111lll1_l1_(url,type=l1l111_l1_ (u"ࠨࠩ—")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭―"),url,l1l111_l1_ (u"ࠪࠫ‖"),l1l111_l1_ (u"ࠫࠬ‗"),l1l111_l1_ (u"ࠬ࠭‘"),l1l111_l1_ (u"࠭ࠧ’"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ‚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫࡤࡶࡹ࡯ࡣ࡭ࡧࠪ‛"),html,re.DOTALL)
	if l11llll_l1_:
		l111lllll1_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠩࠪ“"),l1l111_l1_ (u"ࠪࠫ”"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠫา๊โศฬࠪ„") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"๋่ࠬศี่ࠫ‟") in name: l111lllll1_l1_ = block
		if l111lllll1_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭†"),l111lllll1_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ‡"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ•"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ‣"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ․"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ‥"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ…"),l1lllll_l1_+title,l1ll1ll_l1_,773)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ‧")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ "),url,l1l111_l1_ (u"ࠨࠩ "),l1l111_l1_ (u"ࠩࠪ‪"),l1l111_l1_ (u"ࠪࠫ‫"),l1l111_l1_ (u"ࠫࠬ‬"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ‭"))
	html = response.content
	items,l111llllll_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ‮"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ "),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ‰"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‱"),l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠪࠫ′"),l1l111_l1_ (u"ࠫࡸࡻࡢ࡮ࡧࡱࡹࠬ″"))
				l111llllll_l1_ = True
	if not type and l1l111_l1_ (u"ࠬࡶ࠽ࠨ‴") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡬࡯ࡳ࡯ࠫ࠲࠯ࡅࠩ࠽࠱ࡩࡳࡷࡳ࠾ࠨ‵"),html,re.DOTALL)
		if l11llll_l1_:
			if l111llllll_l1_: addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ‶"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ‷"),l1l111_l1_ (u"ࠩࠪ‸"),9999)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ‹"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ›"),url,775,l1l111_l1_ (u"ࠬ࠭※"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭‼"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ‽"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ‾"),url,774,l1l111_l1_ (u"ࠩࠪ‿"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⁀"))
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⁁"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠩ⁂"),url,779)
			addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⁃"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⁄"),l1l111_l1_ (u"ࠨࠩ⁅"),9999)
			filters = True
	if not l111llllll_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ⁆"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⁇"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠫࡡࡴࠧ⁈"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩ࠴࠭⁉") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⁊"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⁋"))
				else: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⁌"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			l1llllll1_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ⁍")
			if l1l111_l1_ (u"ࠪࡴࡂ࠭⁎") in url: url,l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠫࡵࡃࠧ⁏"),1)
			conn = l1l111_l1_ (u"ࠬࠬࠧ⁐") if l1l111_l1_ (u"࠭࠿ࠨ⁑") in url else l1l111_l1_ (u"ࠧࡀࠩ⁒")
			url = url+conn
			url = url.replace(l1l111_l1_ (u"ࠨࡁࠩࠫ⁓"),l1l111_l1_ (u"ࠩࡂࠫ⁔"))
			if len(items)==40:
				url = url+l1l111_l1_ (u"ࠪࡴࡂ࠭⁕")+str(int(l1llllll1_l1_)+1)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⁖"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไึใะอࠥอไหษ็๎ฮ࠭⁗"),url,771)
			elif l1llllll1_l1_!=l1l111_l1_ (u"࠭࠱ࠨ⁘"):
				url = url+l1l111_l1_ (u"ࠧࡱ࠿ࠪ⁙")+str(int(l1llllll1_l1_)-1)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⁚"),l1lllll_l1_+l1l111_l1_ (u"ࠩสฺ่็อสࠢสุ่อศใหࠪ⁛"),url,771)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⁜"),url,l1l111_l1_ (u"ࠫࠬ⁝"),l1l111_l1_ (u"ࠬ࠭⁞"),l1l111_l1_ (u"࠭ࠧ "),l1l111_l1_ (u"ࠧࠨ⁠"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⁡"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰࡦࡨࡥ࡭ࡀส่ฯ฻ๆ๋ใ࠿࠳ࡱࡧࡢࡦ࡮ࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⁢"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111llll11_l1_,l1ll11l1_l1_,l1111l1ll_l1_ = [],[],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡳࡰࡦࡿ࠭ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⁣"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ⁤"))
	items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡳࠢࡩࡰࡪࡾ࠭ࡴࡶࡤࡶࡹࠨ࠮ࠫࡁ࠿ࡨ࡮ࡼ࠾࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࠬࡡࡪࡻ࠴࠮࠷ࢁ࠮ࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⁥"),html,re.DOTALL)
	for l111l1ll_l1_,l1ll1ll_l1_ in items:
		if l1ll1ll_l1_ not in l1111l1ll_l1_:
			l1111l1ll_l1_.append(l1ll1ll_l1_)
			l111l1ll_l1_ = l111l1ll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ⁦"))
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ⁧"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⁨")+server+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟ࡠࡡࠪ⁩")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⁪"),url)
	return
def l1lll1_l1_(search,url=l1l111_l1_ (u"ࠫࠬ⁫")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⁬"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ⁭"))
	if not url: url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ⁮")+l1lll1ll_l1_
	else: url = url+l1l111_l1_ (u"ࠨࡁࡷ࡭ࡹࡲࡥ࠾ࠩ⁯")+l1lll1ll_l1_+l1l111_l1_ (u"ࠩࠩ࡫ࡪࡴࡲࡦ࠿ࠩࡽࡪࡧࡲ࠾ࠨ࡯ࡥࡳ࡭࠽ࠨ⁰")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪⁱ"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⁲"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⁳"),url,l1l111_l1_ (u"࠭ࠧ⁴"),l1l111_l1_ (u"ࠧࠨ⁵"),l1l111_l1_ (u"ࠨࠩ⁶"),l1l111_l1_ (u"ࠩࠪ⁷"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ⁸"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡫ࡵࡲ࡮࠯ࡵࡳࡼ࠮࠮ࠫࡁࠬࡀ࠴࡬࡯ࡳ࡯ࡁࠫ⁹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡥ࡭ࡧࡦࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࠫ⁺"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⁻"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⁼"),l1l111_l1_ (u"ࠨࡁࡷ࡭ࡹࡲࡥ࠾ࠨࠪ⁽"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠩࡼࡩࡦࡸࠧ⁾"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࠨⁿ"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ₀")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠬࡿࡥࡢࡴࠪ₁"),l1l111_l1_ (u"࠭࡬ࡢࡰࡪࠫ₂"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭₃")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ₄"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭₅"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ₆"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ₇"),l1l111_l1_ (u"ࠬ࠭₈")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ₉"))
	if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ₊"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪ₋") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫ₌") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ₍")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ₎")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ₏")+category+l1l111_l1_ (u"࠭࠽࠱ࠩₐ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩₑ"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬₒ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫₓ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡥࡱࡲࠧₔ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨₕ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪₖ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨₗ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫₘ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬₙ")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩₚ"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ₛ"),l1llllll_l1_,771,l1l111_l1_ (u"ࠫࠬₜ"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ₝"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭₞"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ₟")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ₠"),l1llllll_l1_,771,l1l111_l1_ (u"ࠩࠪ₡"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ₢"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ₣"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ₤"),l1l111_l1_ (u"࠭ࠧ₥"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠧไๆࠣࠫ₦"),l1l111_l1_ (u"ࠨࠩ₧"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠩࡀࠫ₨") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ₩"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ₪")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ₫"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ€"),l1llllll_l1_,771,l1l111_l1_ (u"ࠧࠨ₭"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ₮"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₯"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ₰"),l1lllll1_l1_,775,l1l111_l1_ (u"ࠫࠬ₱"),l1l111_l1_ (u"ࠬ࠭₲"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ₳"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ₴")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ₵")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ₶")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭₷")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ₸")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ₹"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨ₺")+name,l1lllll1_l1_,774,l1l111_l1_ (u"ࠧࠨ₻"),l1l111_l1_ (u"ࠨࠩ₼"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ₽")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ₾")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭₿")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ⃀")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ⃁")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ⃂")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪ⃃")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ⃄")+name
			if type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ⃅"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃆"),l1lllll_l1_+title,url,774,l1l111_l1_ (u"ࠬ࠭⃇"),l1l111_l1_ (u"࠭ࠧ⃈"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⃉") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ⃊") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⃋"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⃌")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃍"),l1lllll_l1_+title,l1llllll_l1_,771,l1l111_l1_ (u"ࠬ࠭⃎"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭⃏"))
			elif type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⃐"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃑"),l1lllll_l1_+title,url,775,l1l111_l1_ (u"⃒ࠩࠪ"),l1l111_l1_ (u"⃓ࠪࠫ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠫࡂࠬࠧ⃔"),l1l111_l1_ (u"ࠬࡃ࠰ࠧࠩ⃕"))
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠨ⃖"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠧ࠾ࠩ⃗") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨ⃘ࠪ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀ⃙ࠫ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"⃚ࠪࠫ")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭⃛")
		if l1l111_l1_ (u"ࠬࠫࠧ⃜") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⃝") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ⃞"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ⃟")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⃠") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ⃡"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭⃢")+key+l1l111_l1_ (u"ࠬࡃࠧ⃣")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ⃤"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"⃥ࠧࠧࠩ")+key+l1l111_l1_ (u"ࠨ࠿⃦ࠪ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭⃧"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"⃨ࠪࠪࠬ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠫࡂ࠶ࠧ⃩"),l1l111_l1_ (u"ࠬࡃ⃪ࠧ"))
	return l1l1l111_l1_
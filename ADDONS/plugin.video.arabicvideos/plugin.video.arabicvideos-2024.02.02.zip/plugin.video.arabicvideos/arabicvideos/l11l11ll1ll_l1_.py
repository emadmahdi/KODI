# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䔳"):l1l111_l1_ (u"࠭ࠧ䔴")}
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭䔵")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ䔶")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠩ࠶ࠫ䔷"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠪ࠵ࠬ䔸"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠫ࠷࠭䔹"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠬ࠺ࠧ䔺"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䔻"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䔼")+l1lllll_l1_+l1l111_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ䔽"),l1l111_l1_ (u"ࠩࠪ䔾"),38)
	return l1l111_l1_ (u"ࠪࠫ䔿")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠫࠬ䕀")):
	type = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䕁"))[3]
	if type==l1l111_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䕂"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䕃"),headers,l1l111_l1_ (u"ࠨࠩ䕄"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ䕅"))
		if select==l1l111_l1_ (u"ࠪ࠷ࠬ䕆"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭䕇"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕈"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬ䕉") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ䕊"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕋"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠩ࠷ࠫ䕌"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䕍"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕎"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ䕏"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕐"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䕑"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ䕒"),headers,l1l111_l1_ (u"ࠩࠪ䕓"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠲࡯ࡦࠪ䕔"))
		if select==l1l111_l1_ (u"ࠫ࠶࠭䕕"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡌ࡫࡮ࡥࡧࡵࠬ࠳࠰࠿ࠪࡵࡨࡰࡪࡩࡴࠨ䕖"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䕗"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯ࠨ䕘") + value
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ䕙"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕚"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠪ࠶ࠬ䕛"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡅࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䕜"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䕝"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䕞"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡣࡦࡸࡴࡸ࠯ࠨ䕟") + value
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕠"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䕡"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫ䕢"),headers,l1l111_l1_ (u"ࠫࠬ䕣"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䕤"))
	if l1l111_l1_ (u"࠭ࡨࡰ࡯ࡨࠫ䕥") in url: type=l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䕦")
	if type==l1l111_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䕧"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷ࠭࠴ࠪࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ䕨"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䕩"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䕪"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕫"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䕬"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䕭"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠬࡁࠬࠦࠬ䕮"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ䕯"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䕰"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭䕱"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䕲"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"࠭࠱ࠨ䕳"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷࠬ䕴"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࠩ䕵"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭䕶") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䕷"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳ࠯ࠬࡂࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䕸"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠭䕹"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"࠭ࠠࠨ䕺"))
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䕻"))
			name = title + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䕼") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕽"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡫ࡱࡿࡰࡩ࡫ࡦࡳࡳ࠳ࡣࡩࡧࡹࡶࡴࡴ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠬࡁࠬࡨࡦࡺࡡ࠮ࡴࡨࡺ࡮ࡼࡥ࠮ࡼࡲࡲࡪ࡯ࡤ࠾ࠤ࠷ࠦࠬ䕾"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕿"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ䖀") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖁"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䖂") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࡶ࠲࠱ࡶࡩࡷ࡯ࡥࡴࡎ࡬ࡲࡰ࠵ࠧ䖃") + url.split(l1l111_l1_ (u"ࠩ࠲ࠫ䖄"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䖅"),url,l1l111_l1_ (u"ࠫࠬ䖆"),headers,l1l111_l1_ (u"ࠬ࠭䖇"),l1l111_l1_ (u"࠭ࠧ䖈"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䖉"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䖊"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䖋"),l1l111_l1_ (u"ࠪ࠳ࠬ䖌"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䖍"),url,l1l111_l1_ (u"ࠬ࠭䖎"),headers,l1l111_l1_ (u"࠭ࠧ䖏"),l1l111_l1_ (u"ࠧࠨ䖐"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䖑"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䖒"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䖓"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠫࠬ䖔")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠬࠦࠧ䖕"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ䖖"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䖗"),l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䖘")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠩ࠴ࠫ䖙")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠪ࠳ࠬ䖚"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠫอำหࠡ฻้ࠤฬ็ไศ็ࠪ䖛") , l1l111_l1_ (u"ࠬฮอฬࠢ฼๊๋ࠥำๅี็หฯ࠭䖜")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣ࠱ࠥอฮหำࠣห้ฮอฬࠩ䖝"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠧࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨ䖞") in options: type = l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ䖟")
		elif l1l111_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࡡࠪ䖠") in options: type = l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䖡")
		else: return
	headers[l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䖢")] = l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ䖣")
	data = {l1l111_l1_ (u"࠭ࡱࡶࡧࡵࡽࠬ䖤"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡄࡰ࡯ࡤ࡭ࡳ࠭䖥"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠨ࠳ࠪ䖦"): data[l1l111_l1_ (u"ࠩࡩࡶࡴࡳࠧ䖧")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䖨"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ䖩"),data,headers,l1l111_l1_ (u"ࠬ࠭䖪"),l1l111_l1_ (u"࠭ࠧ䖫"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䖬"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䖭"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟࠳ࠬ䖮"),l1l111_l1_ (u"ࠪ࠳ࠬ䖯"))
			if l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭䖰") in url: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䖱"),l1lllll_l1_+l1l111_l1_ (u"࠭แ๋ๆ่ࠤࠬ䖲")+title,url,33)
			elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䖳") in url:
				url = url.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ䖴"),l1l111_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࠨ䖵"))
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䖶"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫ䖷")+title,url+l1l111_l1_ (u"ࠬ࠵࠱ࠨ䖸"),32)
	count=re.findall(l1l111_l1_ (u"࠭ࠢࡵࡱࡷࡥࡱࠨ࠺ࠩ࠰࠭ࡃ࠮ࢃࠧ䖹"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䖺"),l1l111_l1_ (u"ࠨืไัฮࠦࠧ䖻")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠩࠪ䖼"),39,l1l111_l1_ (u"ࠪࠫ䖽"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠫ࠴࠭䖾")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠬࡧࡈࡓ࠲ࡦࡈࡴࡼࡌ࠳ࡦࡽࡨࡍࡐ࡬࡚࡙࠳࠴ࡑࡴࡂࡩࡤࡰ࡚࠵ࡒ࡭ࡏࡸࡏࡱࡱࡹࡌ࠳ࡘ࡮࡞࠷࡜ࡦ࡚࡙ࡍࡽࡑ࠸ࡨࡩࡤࡊࡊ࡚࡜ࡩ࠺ࡹࡥࡋࡋ࠻ࡢࡈ࡮ࡽࡨࡈ࠻ࡴࡎ࠵ࡘ࠸ࠬ䖿")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䗀"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䗁"))
	return
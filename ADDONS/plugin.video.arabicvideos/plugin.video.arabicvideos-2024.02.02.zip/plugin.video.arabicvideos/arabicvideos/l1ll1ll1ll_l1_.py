# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡑࡋࡁࡏࡇࡕࠫᨄ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡌࡏࡡࠪᨅ")
l1lll11l11_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"ࠬࡺࡥ࡮ࡲࠪᨆ"))
l1ll1111ll_l1_ = os.path.join(l1lllll1ll_l1_,l1l111_l1_ (u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨᨇ"))
l1lll111l1_l1_ = os.path.join(l1ll11ll11_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩᨈ"),l1l111_l1_ (u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬᨉ"))
l1ll11lll1_l1_ = l1llll11l1_l1_
l1ll111l11_l1_ = l1l111_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡵࡼࡷࡹ࡫࡭࠰ࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬᨊ")
l1ll111l1l_l1_ = l1l111_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡧࡶࡴࡶࡢࡰࡺࠪᨋ")
l1lll1111l_l1_ = l1l111_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠧᨌ")
l1lll11l1l_l1_ = l1l111_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡱࡵࡧࡨࡧࡵࠫᨍ")
l1ll11l111_l1_ = l1l111_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࠩᨎ")
l1ll11l11l_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡡ࡯ࡴࠪᨏ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1lllll1l1_l1_()
	elif mode==741: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l11_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1llll1ll1_l1_(l1ll1111ll_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1llll1ll1_l1_(l1lll111l1_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11l1ll_l1_(l1ll11lll1_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll11111l_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1ll1l1_l1_()
	elif mode==751: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l11_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1llll1ll1_l1_(l1ll111l1l_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1llll1ll1_l1_(l1lll1111l_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1llll1ll1_l1_(l1lll11l1l_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l111_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1llll1ll1_l1_(l1ll11l11l_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1ll1lll11_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1l1lll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lllll1l1_l1_():
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1lll11l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll1111ll_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll111l1_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll1l11ll_l1_(l1ll11lll1_l1_)
	l1lll1ll11_l1_ -= 36864
	l1ll11llll_l1_ -= 1
	l1ll111lll_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᨐ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᨑ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᨒ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨓ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᨔ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᨕ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᨖ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᨗ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴᨘࠫࠪ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨙ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠫ࠮࠭ᨚ")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_
	text = l1l111_l1_ (u"ࠬࠦࠨࠨᨛ")+l1lllll111_l1_(size)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ᨜")+str(count)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ᨝")
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᨞"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦวๅฮ่๎฾࠭᨟")+text,l1l111_l1_ (u"ࠪࠫᨠ"),745)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨡ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᨢ"),l1l111_l1_ (u"࠭ࠧᨣ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨤ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠧᨥ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠩࠪᨦ"),741)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨧ"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫᨨ")+l1ll1ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ᨩ"),742)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨪ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤฬ๊ี้ำࠣห้่ฯ๋็ฬࠫᨫ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠨࠩᨬ"),743)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᨭ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬᨮ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠫࠬᨯ"),744)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᨰ"),l1l111_l1_ (u"࠭ࠧᨱ"))
	return
def l1ll1ll1l1_l1_():
	l1llll1l11_l1_ = True if l1l111_l1_ (u"ࠧ࠰ࠩᨲ") in l1ll11ll11_l1_ else False
	if not l1llll1l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩᨳ"),l1l111_l1_ (u"ࠩࠪᨴ"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᨵ"),l1l111_l1_ (u"ࠫ฾๋ไ๋หࠣฮ๋฾๊โࠢส่ัํวำ่ࠢฮํ็ัสࠢไๆ฼ࠦไฤฮ๊ึฮ๊้่ࠦๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ่๋ࠡ฽ࠥ๐่็ๅึࠫᨶ"))
		return
	l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᨷ"))
	if not l1ll11l1l1_l1_: l1ll1l1lll_l1_()
	l1lll1l11l_l1_,l1llll1l1l_l1_ = l1ll111ll1_l1_(l1ll111l11_l1_)
	l1lll1l111_l1_,l1ll1l111l_l1_ = l1ll111ll1_l1_(l1ll111l1l_l1_)
	l1lll11lll_l1_,l1ll1l11l1_l1_ = l1ll111ll1_l1_(l1lll1111l_l1_)
	l1lll1ll11_l1_,l1ll11llll_l1_ = l1ll111ll1_l1_(l1lll11l1l_l1_)
	l1lll1l1ll_l1_,l1ll1l1111_l1_ = l1ll111ll1_l1_(l1ll11l111_l1_)
	l1lll1l1l1_l1_,l1lll11ll1_l1_ = l1ll111ll1_l1_(l1ll11l11l_l1_)
	l1ll111lll_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨸ")+l1lllll111_l1_(l1lll1l11l_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᨹ")+str(l1llll1l1l_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᨺ")
	l1ll1ll11l_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᨻ")+l1lllll111_l1_(l1lll1l111_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨼ")+str(l1ll1l111l_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨽ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨾ")+l1lllll111_l1_(l1lll11lll_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨿ")+str(l1ll1l11l1_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩀ")
	l1lllll11l_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᩁ")+l1lllll111_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᩂ")+str(l1ll11llll_l1_)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᩃ")
	l1ll1l1l11_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᩄ")+l1lllll111_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᩅ")+str(l1ll1l1111_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᩆ")
	l1ll1l1ll1_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᩇ")+l1lllll111_l1_(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᩈ")+str(l1lll11ll1_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᩉ")
	size = l1lll1l11l_l1_+l1lll1l111_l1_+l1lll11lll_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1lll1l1l1_l1_
	count = l1llll1l1l_l1_+l1ll1l111l_l1_+l1ll1l11l1_l1_+l1ll11llll_l1_+l1ll1l1111_l1_+l1lll11ll1_l1_
	text = l1l111_l1_ (u"ࠪࠤ࠭࠭ᩊ")+l1lllll111_l1_(size)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᩋ")+str(count)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᩌ")
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩍ"),l1lllll_l1_+l1l111_l1_ (u"ࠧฦ฻ฺหฦࠦัฯืฬࠤ็ืวยหࠣ์่ะวษหࠪᩎ"),l1l111_l1_ (u"ࠨࠩᩏ"),758)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩐ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠศๆฯ้๏฿ࠧᩑ")+text,l1l111_l1_ (u"ࠫࠬᩒ"),757)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩓ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᩔ"),l1l111_l1_ (u"ࠧࠨᩕ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩖ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡻࡳࡢࡩࡨࡷࡹࡧࡴࡴࠩᩗ")+l1ll111lll_l1_,l1l111_l1_ (u"ࠪࠫᩘ"),751)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩙ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡦࡵࡳࡵࡨ࡯ࡹࠩᩚ")+l1ll1ll11l_l1_,l1l111_l1_ (u"࠭ࠧᩛ"),752)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩜ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨᩝ")+l1ll1ll111_l1_,l1l111_l1_ (u"ࠩࠪᩞ"),753)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᩟"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸ᩠ࠧ")+l1lllll11l_l1_,l1l111_l1_ (u"ࠬ࠭ᩡ"),754)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩢ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࠧᩣ")+l1ll1l1l11_l1_,l1l111_l1_ (u"ࠨࠩᩤ"),755)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩥ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪᩦ")+l1ll1l1ll1_l1_,l1l111_l1_ (u"ࠫࠬᩧ"),756)
	settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᩨ"),l1l111_l1_ (u"࠭ࠧᩩ"))
	return
def l1ll1l1lll_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠧࠨᩪ"),l1l111_l1_ (u"ࠨࠩᩫ"),l1l111_l1_ (u"ࠩࠪᩬ"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᩭ"),l1l111_l1_ (u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫᩮ"))
	if l1llll111l_l1_==-1: return
	if l1llll111l_l1_:
		import subprocess
		try:
			subprocess.Popen(l1l111_l1_ (u"ࠬࡹࡵࠨᩯ"))
			l1llll11ll_l1_ = True
		except: l1llll11ll_l1_ = False
		if l1llll11ll_l1_:
			l1ll1llll1_l1_ = l1ll111l11_l1_+l1l111_l1_ (u"࠭ࠠࠨᩰ")+l1ll111l1l_l1_+l1l111_l1_ (u"ࠧࠡࠩᩱ")+l1lll1111l_l1_+l1l111_l1_ (u"ࠨࠢࠪᩲ")+l1lll11l1l_l1_+l1l111_l1_ (u"ࠩࠣࠫᩳ")+l1ll11l111_l1_+l1l111_l1_ (u"ࠪࠤࠬᩴ")+l1ll11l11l_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬ᩵")+l1ll1llll1_l1_+l1l111_l1_ (u"ࠬࠨࠧ᩶"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᩷"),l1l111_l1_ (u"ࠧࠨ᩸"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᩹"),l1l111_l1_ (u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอࠬ᩺"))
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᩻"),l1l111_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᩼"))
			xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᩽"))
		else: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᩾"),l1l111_l1_ (u"ࠧࠨ᩿"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪀"),l1l111_l1_ (u"ࠩ฼้้๐ษࠡว฼฻ฬวࠠาะุอࠥอไใำสลฮ่ࠦศๆๆฮฬฮษࠡฬะฮฬาࠠษำ้ห๊าࠠࠡࡴࡲࡳࡹࠦࠠฤ๊ࠣࠤࡸࡻࡰࡦࡴࡸࡷࡪࡸࠠࠡล๋ࠤࠥࡹࡵ๋ࠡࠢะ์อาไࠢ็หࠥ๐่อัࠣๅ๏ํ่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮࠯ࠢฦ์้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠩ᪁"))
	return
def l1lllll111_l1_(size):
	for x in [l1l111_l1_ (u"ࠪࡆࠬ᪂"),l1l111_l1_ (u"ࠫࡐࡈࠧ᪃"),l1l111_l1_ (u"ࠬࡓࡂࠨ᪄"),l1l111_l1_ (u"࠭ࡇࡃࠩ᪅"),l1l111_l1_ (u"ࠧࡕࡄࠪ᪆")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠣࠧ࠶࠲࠶࡬ࠠࠦࡵࠥ᪇")%(size,x)
	return text
def l1ll111ll1_l1_(l1llll1111_l1_=l1l111_l1_ (u"ࠩ࠱ࠫ᪈")):
	global l1lll11111_l1_,l1lll1lll1_l1_
	l1lll11111_l1_,l1lll1lll1_l1_ = 0,0
	def l1lll111ll_l1_(l1llll1111_l1_):
		global l1lll11111_l1_,l1lll1lll1_l1_
		if os.path.exists(l1llll1111_l1_):
			if 0 and l1l111_l1_ (u"ࠪࡷࡨࡧ࡮ࡥ࡫ࡵࠫ᪉") in dir(os):
				for l1ll1111l1_l1_ in os.scandir(l1llll1111_l1_):
					if l1ll1111l1_l1_.l1lll1llll_l1_(follow_symlinks=False):
						l1lll111ll_l1_(l1ll1111l1_l1_.path)
					elif l1ll1111l1_l1_.l1ll1l1l1l_l1_(follow_symlinks=False):
						l1lll11111_l1_ += l1ll1111l1_l1_.stat().st_size
						l1lll1lll1_l1_ += 1
			else:
				for l1ll1111l1_l1_ in os.listdir(l1llll1111_l1_):
					l1ll111111_l1_ = os.path.abspath(os.path.join(l1llll1111_l1_,l1ll1111l1_l1_))
					if os.path.isdir(l1ll111111_l1_):
						l1lll111ll_l1_(l1ll111111_l1_)
					elif os.path.isfile(l1ll111111_l1_):
						size,count = l1ll1l11ll_l1_(l1ll111111_l1_)
						l1lll11111_l1_ += size
						l1lll1lll1_l1_ += count
		return
	try: l1lll111ll_l1_(l1llll1111_l1_)
	except: pass
	return l1lll11111_l1_,l1lll1lll1_l1_
def l1lll1ll1l_l1_(l1ll1lllll_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠫࠬ᪊"),l1l111_l1_ (u"ࠬ࠭᪋"),l1l111_l1_ (u"࠭ࠧ᪌"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᪍"),l1ll1lllll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭᪎")+l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็็ๅࠥลࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᪏"))
		if l1llll111l_l1_!=1: return
	error = False
	if os.path.exists(l1ll1lllll_l1_):
		try: os.remove(l1ll1lllll_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᪐"),l1l111_l1_ (u"ࠫࠬ᪑"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪒"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ᪓"),l1l111_l1_ (u"ࠧࠨ᪔"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪕"),l1l111_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪ᪖"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᪗"),l1l111_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᪘"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᪙"))
	return
def l1ll11111l_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"࠭ࠧ᪚"),l1l111_l1_ (u"ࠧࠨ᪛"),l1l111_l1_ (u"ࠨࠩ᪜"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪝"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯࠪ᪞")+l1l111_l1_ (u"ࠫࡡࡴࠧ᪟")+l1l111_l1_ (u"๋ࠬฬๅัࠣห้๋ไโษอࠤฬ๊ๅลไออࠥ࠴࠮๊่ࠡะ้ีࠠศๆ่่ๆอสࠡษ็้฻เุ่หࠣ࠲࠳่ࠦๆฮ็ำࠥอไึ๊ิࠤฬ๊โะ์่อࠥ࠴࠮๊ࠡอๅึ๐ฺࠡ็็ๅࠥ฻่าࠢส่ส฼วโษอࠫ᪠")+l1l111_l1_ (u"࠭࡜࡯ࠩ᪡")+l1l111_l1_ (u"ࠧภࠣࠤࠫ᪢")+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᪣"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1lll11l11_l1_,True,False)
	l1llll1ll1_l1_(l1ll1111ll_l1_,True,False)
	l1llll1ll1_l1_(l1lll111l1_l1_,False,False)
	l1ll11l1ll_l1_(l1ll11lll1_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ᪤"),l1l111_l1_ (u"ࠪࠫ᪥"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪦"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᪧ"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ᪨"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ᪩"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ᪪"))
	return
def l1ll1lll11_l1_(l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ᪫"),l1l111_l1_ (u"ࠪࠫ᪬"),l1l111_l1_ (u"ࠫࠬ᪭"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪮"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืาࠦๅๅใสฮࠬ᪯")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ᪰")+l1l111_l1_ (u"ࠨࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠥ࠴࠮ࠡࡦࡵࡳࡵࡨ࡯ࡹࠢ࠱࠲ࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠢ࠱࠲ࠥࡲ࡯ࡨࡩࡨࡶࠥ࠴࠮ࠡ࡮ࡲ࡫ࠥ࠴࠮ࠡࡣࡱࡶࠬ᪱")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ᪲")+l1l111_l1_ (u"ࠪࡃࠦࠧࠧ᪳")+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᪴"))
		if l1llll111l_l1_!=1: return
	l1llll1ll1_l1_(l1ll111l11_l1_,False,False)
	l1llll1ll1_l1_(l1ll111l1l_l1_,False,False)
	l1llll1ll1_l1_(l1lll1111l_l1_,False,False)
	l1llll1ll1_l1_(l1lll11l1l_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l111_l1_,False,False)
	l1llll1ll1_l1_(l1ll11l11l_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"᪵ࠬ࠭"),l1l111_l1_ (u"᪶࠭ࠧ"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮ᪷ࠪ"),l1l111_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮ᪸ࠩ"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ᪹࠭"),l1l111_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ᪺࠭"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ᪻"))
	return
def l1ll11l1ll_l1_(l1ll1lll1l_l1_,l11_l1_):
	if l11_l1_:
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠬ࠭᪼"),l1l111_l1_ (u"᪽࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ᪾"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯᪿࠫ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรᫀࠦࠧࠧ")+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᫁"))
		if l1llll111l_l1_!=1: return
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	conn.text_factory = str
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨ᫂"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽᫃ࠪ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ᫄࠭"))
	conn.commit()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨ᫅"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᫆"),l1l111_l1_ (u"ࠩࠪ᫇"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᫈"),l1l111_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬ᫉"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴ᫊ࠩ"),l1l111_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩ᫋"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᫌ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩዦ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇ࠹ࡎ࡟ࠨዧ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬየ"),l1l111_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬዩ"),l1l111_l1_ (u"ࠬอไศไึห๊࠭ዪ"),l1l111_l1_ (u"ู࠭าุࠣห้๋า๋ัࠪያ"),l1l111_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠫዬ"),l1l111_l1_ (u"ࠨࠩይ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==690: l1lll_l1_ = l1l1l11_l1_()
	elif mode==691: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==692: l1lll_l1_ = PLAY(url)
	elif mode==693: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==694: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==699: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ዮ"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫዯ"),l1l111_l1_ (u"ࠫࠬደ"),l1l111_l1_ (u"ࠬ࠭ዱ"),l1l111_l1_ (u"࠭ࠧዲ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪዳ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨዴ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩድ"),l1l111_l1_ (u"ࠪࠫዶ"),699,l1l111_l1_ (u"ࠫࠬዷ"),l1l111_l1_ (u"ࠬ࠭ዸ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪዹ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬዺ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪዻ"),l1l111_l1_ (u"ࠩࠪዼ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪዽ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧዾ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		title = title.replace(l1l111_l1_ (u"ࠬࡂࡢ࠿ࠩዿ"),l1l111_l1_ (u"࠭ࠧጀ")).strip(l1l111_l1_ (u"ࠧࠡࠩጁ"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጂ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫጃ")+l1lllll_l1_+title,l1ll1ll_l1_,694)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧጄ"),url,l1l111_l1_ (u"ࠫࠬጅ"),l1l111_l1_ (u"ࠬ࠭ጆ"),l1l111_l1_ (u"࠭ࠧጇ"),l1l111_l1_ (u"ࠧࠨገ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧጉ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ጊ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫጋ"),l1l111_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪጌ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩግ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"࠭ࠧጎ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬጏ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ጐ"),l1l111_l1_ (u"ࠩࠪ጑"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨጒ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠫ࠿ࠦࠧጓ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬጔ"),l1lllll_l1_+title,l1ll1ll_l1_,691)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪጕ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ጖"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭጗"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫጘ"),l1l111_l1_ (u"ࠪࠫጙ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጚ"),l1lllll_l1_+title,l1ll1ll_l1_,691)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠬ࠭ጛ")):
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫጜ"):
		url,search = url.split(l1l111_l1_ (u"ࠧࡀࠩጝ"),1)
		data = l1l111_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧጞ")+search
		headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨጟ"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪጠ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩጡ"),url,data,headers,l1l111_l1_ (u"ࠬ࠭ጢ"),l1l111_l1_ (u"࠭ࠧጣ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬጤ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬጥ"),url,l1l111_l1_ (u"ࠩࠪጦ"),l1l111_l1_ (u"ࠪࠫጧ"),l1l111_l1_ (u"ࠫࠬጨ"),l1l111_l1_ (u"ࠬ࠭ጩ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫጪ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠧࠨጫ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬጬ"))
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧጭ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬጮ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬጯ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧጰ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧጱ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ጲ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨጳ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ጴ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪጵ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ጶ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬጷ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬጸ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠧࠨጹ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩጺ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪጻ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ู้ࠪอ็ะหࠪጼ"),l1l111_l1_ (u"ࠫๆ๐ไๆࠩጽ"),l1l111_l1_ (u"ࠬอฺ็์ฬࠫጾ"),l1l111_l1_ (u"࠭ใๅ์หࠫጿ"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ፀ"),l1l111_l1_ (u"ࠨ้าหๆ࠭ፁ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩፂ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧፃ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫፄ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫፅ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭ፆ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪፇ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧፈ"),l1lllll_l1_+title,l1ll1ll_l1_,692,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨፉ"):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩፊ"),l1lllll_l1_+title,l1ll1ll_l1_,692,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪፋ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፌ"),l1lllll_l1_+title,l1ll1ll_l1_,693,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ፍ"),l1lllll_l1_+title,l1ll1ll_l1_,693,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨፎ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ፏ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫፐ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬፑ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ፒ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፓ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬፔ")+title,l1ll1ll_l1_,691)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫፕ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬፖ"),url,l1l111_l1_ (u"ࠩࠪፗ"),l1l111_l1_ (u"ࠪࠫፘ"),l1l111_l1_ (u"ࠫࠬፙ"),l1l111_l1_ (u"ࠬ࠭ፚ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭፛"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ፜"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ፝"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠩࠪ፞")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ፟"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧ፠"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ፡"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭።"),l1lllll_l1_+title,url,693,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ፣"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬ፤"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ፥")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ፦"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ፧")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ፨"),block,re.DOTALL)
	if not l11ll11_l1_: l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪ፩")+l1l11_l1_+l1l111_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ፪"),block,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢ፫"),block,re.DOTALL)
		if not l1l1111_l1_: l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭፬"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ፭"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠳࠵ࠧ፮"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ፯")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ፰"))
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ፱"),l1l111_l1_ (u"ࠨࠢࠪ፲"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ፳"),l1lllll_l1_+title,l1ll1ll_l1_,692,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ፴"),l1l111_l1_ (u"ࠫ࠴ࡹࡥࡦ࠰ࡳ࡬ࡵ࠭፵"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ፶"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ፷"),l1l111_l1_ (u"ࠧࠨ፸"),l1l111_l1_ (u"ࠨࠩ፹"),l1l111_l1_ (u"ࠩࠪ፺"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭፻"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭፼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ፽"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ፾"))
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡴࡴࡣ࡭࡫ࡦ࡯࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ፿"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᎀ"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᎁ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᎂ"))
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᎃ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				title = title.strip(l1l111_l1_ (u"ࠬࡢ࡮ࠨᎄ"))
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᎅ")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᎆ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᎇ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪᎈ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫᎉ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ᎊ"),l1l111_l1_ (u"ࠬ࠱ࠧᎋ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧᎌ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧᎍ"))
	return
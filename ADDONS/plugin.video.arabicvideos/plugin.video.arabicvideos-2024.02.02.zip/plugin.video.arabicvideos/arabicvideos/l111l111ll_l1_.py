# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ⑼")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡍࡎࡠࠩ⑽")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩ⑾"),l1l111_l1_ (u"ࠬอไไๆࠪ⑿"),l1l111_l1_ (u"࠭࡮࠰ࡃࠪ⒀"),l1l111_l1_ (u"ࠧศๆ่ึ๏ีࠧ⒁"),l1l111_l1_ (u"ࠨไุอࠥ฿ิใࠩ⒂")]
def l11l1ll_l1_(mode,url,text):
	if   mode==430: l1lll_l1_ = l1l1l11_l1_()
	elif mode==431: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==432: l1lll_l1_ = PLAY(url)
	elif mode==433: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==434: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⒃")+text)
	elif mode==435: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⒄")+text)
	elif mode==436: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==437: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==439: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⒅"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷࠬ⒆"),l1l111_l1_ (u"࠭ࠧ⒇"),l1l111_l1_ (u"ࠧࠨ⒈"),l1l111_l1_ (u"ࠨࠩ⒉"),l1l111_l1_ (u"ࠩࠪ⒊"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⒋"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡ࡯ࡱࡱ࡭ࡨࡧ࡬ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⒌"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠬ࠵ࠧ⒍"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ⒎"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒏"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⒐"),l1l111_l1_ (u"ࠩࠪ⒑"),439,l1l111_l1_ (u"ࠪࠫ⒒"),l1l111_l1_ (u"ࠫࠬ⒓"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⒔"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒕"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ⒖"),l1l11ll_l1_,435)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒗"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⒘"),l1l11ll_l1_,434)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⒙"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⒚"),l1l111_l1_ (u"ࠬ࠭⒛"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒜"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⒝")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ⒞"),l1l11ll_l1_,431)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒟"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⒠")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ็ไศ็ࠣหํ์ࠠๅษํ๊ࠬ⒡"),l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷ࠶࠭⒢"),436)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒣"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⒤")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠢส์๋ࠦไศ์้ࠫ⒥"),l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠰ࡥࡱࡲ࠱ࠨ⒦"),436)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒧"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⒨")+l1lllll_l1_+l1l111_l1_ (u"่ࠬวว็ฬࠤฯ็ี๋ๆํอࠬ⒩"),l1l11ll_l1_,437)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⒪"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⒫"),l1l111_l1_ (u"ࠨࠩ⒬"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗ࡮ࡺࡥࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪࠥࠫ⒭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⒮"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭⒯"): continue
		if l1l111_l1_ (u"ࠬอ่็ࠢ็ห๏์ࠧ⒰") in title: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒱"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⒲")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠨࠩ⒳")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⒴"),l1l11l11_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪ⒵"),l1l111_l1_ (u"ࠫࠬⒶ"),l1l111_l1_ (u"ࠬ࠭Ⓑ"),l1l111_l1_ (u"࠭ࠧⒸ"),l1l111_l1_ (u"ࠧࠨⒹ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪⒺ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡴ࡯࡯࡫ࡦࡥࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ⓕ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬⒼ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨⒽ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡌࡪࡵࡷࡈࡷࡵࡰࡦࡦࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡸࡣࡩ࡫ࡱ࡫ࡒࡧࡳࡵࡧࡵࠦࠬⒾ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪⒿ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11lll_l1_: continue
		l1ll1ll_l1_ = l1l11l11_l1_+l1l111_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࡂࠫⓀ")+category+l1l111_l1_ (u"ࠨ࠿ࠪⓁ")+value
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓂ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⓃ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l11ll1_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨⓄ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩⓅ"),url,l1l111_l1_ (u"࠭ࠧⓆ"),l1l111_l1_ (u"ࠧࠨⓇ"),l1l111_l1_ (u"ࠨࠩⓈ"),l1l111_l1_ (u"ࠩࠪⓉ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨⓊ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓋ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬⓌ"),url,431)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭Ⓧ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭Ⓨ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		if title in l11lll_l1_: continue
		l1lllll1_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡏࡲࡺ࡮࡫ࡳ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࡂ࡯ࡪࡿ࠽ࠨⓏ")+l111l1l1l_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓐ"),l1lllll_l1_+title,l1lllll1_l1_,431)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠪࠫⓑ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨⓒ"))
	items = []
	if l1l111_l1_ (u"ࠬ࠵ࡔࡦࡴࡰࡷ࠳ࡶࡨࡱࠩⓓ") in url or l1l111_l1_ (u"࠭࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࠨⓔ") in url or l1l111_l1_ (u"ࠧ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࠪⓕ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫⓖ"):l1l111_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪⓗ"),l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩⓘ"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫⓙ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪⓚ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧⓛ"),l1l111_l1_ (u"ࠧࠨⓜ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬⓝ"))
		html = response.content
		block = html
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫⓞ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧⓟ"),url,l1l111_l1_ (u"ࠫࠬⓠ"),l1l111_l1_ (u"ࠬ࠭ⓡ"),l1l111_l1_ (u"࠭ࠧⓢ"),l1l111_l1_ (u"ࠧࠨⓣ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬⓤ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡍࡢࡶࡦ࡬ࡪࡹࡔࡢࡤ࡯ࡩࠧ࠭ⓥ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭ⓦ"),block,re.DOTALL)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨⓧ"),url,l1l111_l1_ (u"ࠬ࠭ⓨ"),l1l111_l1_ (u"࠭ࠧⓩ"),l1l111_l1_ (u"ࠧࠨ⓪"),l1l111_l1_ (u"ࠨࠩ⓫"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⓬"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠪ⓭"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫ⓮"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⓯"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭⓰"),l1l111_l1_ (u"ࠧโ์็้ࠬ⓱"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ⓲"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ⓳"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ⓴"),l1l111_l1_ (u"ࠫ์ีวโࠩ⓵"),l1l111_l1_ (u"๋ࠬศศำสอࠬ⓶"),l1l111_l1_ (u"ู࠭าุࠪ⓷"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ⓸"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ⓹")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ⓺"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭⓻"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⓼"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠬอไฮๆๅอࠬ⓽") in title:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⓾") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⓿"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭─") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ━"),l1lllll_l1_+title,l1ll1ll_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ│"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	if request!=l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭┃"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡐࡢࡩ࡬ࡲࡦࡺࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ┄"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ┅"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ┆") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				if title!=l1l111_l1_ (u"ࠨࠩ┇"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┈"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩ┉")+title,l1ll1ll_l1_,431)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸ࡯ࡲࡶࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭┊"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┋"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅีษ๊ำฮࠦวๅ็ี๎ิ࠭┌"),l1ll1ll_l1_,431)
	return
def l1ll1l11_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ┍"))
	l11ll1l_l1_,l11ll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࡵ࠱ࡴ࡭ࡶࠧ┎") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ┏"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ┐"),l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ┑"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ┒")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ┓"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ└"),l1l111_l1_ (u"ࠨࠩ┕"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ┖"))
		html = response.content
		l11ll11_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ┗"),url,l1l111_l1_ (u"ࠫࠬ┘"),l1l111_l1_ (u"ࠬ࠭┙"),l1l111_l1_ (u"࠭ࠧ┚"),l1l111_l1_ (u"ࠧࠨ┛"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ├"))
		html = response.content
		l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ┝"),html,re.DOTALL)
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡊࡶࡩࡴࡱࡧࡩࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ┞"),html,re.DOTALL)
	if l11ll1l_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡵࡧ࠻࡫ࡰࡥ࡬࡫ࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ┟"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ┠"),block,re.DOTALL)
		for l1ll11l_l1_,l111l11l1_l1_,title in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠯ࡲ࡫ࡴࡄ࠭┡")+l1l111_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴ࠽ࠨ┢")+l111l11l1_l1_+l1l111_l1_ (u"ࠨࠨࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ┣")+l1ll11l_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┤"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ┥"))
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ┦"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"ࠬࠦࠧ┧")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ┨"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ┩")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ┪"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ┫"),l1l111_l1_ (u"ࠪࠫ┬"),l1l111_l1_ (u"ࠫࠬ┭"),l1l111_l1_ (u"ࠬ࠭┮"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ┯"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ┰"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲ࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ┱"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ┲"),block,re.DOTALL)
		if l11111l11_l1_:
			l11111l11_l1_ = l11111l11_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ┳"),block,re.DOTALL)
			for server,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩ┴")+server+l1l111_l1_ (u"ࠬࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ┵")+l11111l11_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ┶")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ┷")
				l1llll_l1_.append(l1ll1ll_l1_)
	l111l1111l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡯ࡦࡳࡣࡰࡩࠧࡄ࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┸"),html,re.DOTALL)
	if l111l1111l_l1_:
		l111l1111l_l1_ = l111l1111l_l1_[0].replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ┹"),l1l111_l1_ (u"ࠪࠫ┺"))
		title = l1l111l_l1_(l111l1111l_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ┻"))
		l1ll1ll_l1_ = l111l1111l_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭┼")+title+l1l111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ┽")
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ┾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬ┿"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬ╀"),l1l111_l1_ (u"ࠪࠫ╁"))
			if l111l1ll_l1_!=l1l111_l1_ (u"ࠫࠬ╂"): l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ╃")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ╄")+title+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ╅")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ╆"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ╇"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ╈"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭╉"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ╊"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫ╋")+search
	l1lll11_l1_(url)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ╌"))[0]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ╍"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭╎"),l1l11ll_l1_,l1l111_l1_ (u"ࠪࠫ╏"),l1l111_l1_ (u"ࠫࠬ═"),l1l111_l1_ (u"ࠬ࠭║"),l1l111_l1_ (u"࠭ࠧ╒"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ╓"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭╔"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬࠫ╕"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ╖"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ╗"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ╘"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ╙"),l1l111_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࡂࠫ╚"))
	return url
def l111l111l1_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ╛"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╜")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
l1l11111_l1_ = [l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ╝"),l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ╞"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ╟"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ╠")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ╡"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ╢"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ╣"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ╤"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭╥"),l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭╦")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"࠭࠿ࠨ╧") in url: url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ╨"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ╩"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ╪"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ╫"),l1l111_l1_ (u"ࠫࠬ╬")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ╭"))
	if type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ╮"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩ╯") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪ╰") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ╱")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭╲")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭╳")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ╴")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ╵"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ╶")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ╷"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ╸"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ╹")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ╺"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ╻"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ╼"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ╽"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ╾"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭╿")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▀"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ▁"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▂"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭▃")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭▄"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭▅"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ▆"),l1l111_l1_ (u"ࠪࠫ▇"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠫ࠲࠳ࠧ█"),l1l111_l1_ (u"ࠬ࠭▉"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"࠭࠽ࠨ▊") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ▋"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ▌")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▍"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ▎"),l1lllll1_l1_,431)
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▏"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭▐"),l1lllll1_l1_,435,l1l111_l1_ (u"࠭ࠧ░"),l1l111_l1_ (u"ࠧࠨ▒"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ▓"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ▔")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭▕")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭▖")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ▗")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ▘")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ▙"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ▚")+name,l1lllll1_l1_,434,l1l111_l1_ (u"ࠩࠪ▛"),l1l111_l1_ (u"ࠪࠫ▜"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ▝"): option = l1l111_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ▞")
			elif value==l1l111_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭▟"): option = l1l111_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ■")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ□")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ▢")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ▣")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭▤")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ▥")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ▦")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ▧")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ▨")+name
			if type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ▩"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▪"),l1lllll_l1_+title,url,434,l1l111_l1_ (u"ࠫࠬ▫"),l1l111_l1_ (u"ࠬ࠭▬"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ▭") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ▮") in l11lll1l_l1_:
				l1llllll_l1_ = l111l111l1_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▯"),l1lllll_l1_+title,l1llllll_l1_,431)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▰"),l1lllll_l1_+title,url,435,l1l111_l1_ (u"ࠪࠫ▱"),l1l111_l1_ (u"ࠫࠬ▲"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠬࡃࠦࠨ△"),l1l111_l1_ (u"࠭࠽࠱ࠨࠪ▴"))
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠩ▵"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠨ࠿ࠪ▶") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠫ▷"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ▸"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠫࠬ▹")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ►")
		if l1l111_l1_ (u"࠭ࠥࠨ▻") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ▼") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ▽"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭▾")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭▿") and value!=l1l111_l1_ (u"ࠫ࠵࠭◀"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ◁")+key+l1l111_l1_ (u"࠭࠽ࠨ◂")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ◃"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ◄")+key+l1l111_l1_ (u"ࠩࡀࠫ◅")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ◆"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭◇"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠰ࠨ◈"),l1l111_l1_ (u"࠭࠽ࠨ◉"))
	return l1l1l111_l1_
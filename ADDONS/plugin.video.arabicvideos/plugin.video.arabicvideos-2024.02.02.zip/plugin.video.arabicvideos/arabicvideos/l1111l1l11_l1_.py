# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࠬ⮜")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡉࡏࡗࡤ࠭⮝")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll1l1lll_l1_(text)
	elif mode==542: l1lll_l1_ = l1lll11l11l_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮞"),l1l111_l1_ (u"ࠩหัะࠦฬะ์าࠫ⮟"),l1l111_l1_ (u"ࠪࠫ⮠"),549)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⮡"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁ้ࠥไๆษอࠤ๊ิา็หࠣࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮢"),l1l111_l1_ (u"࠭ࠧ⮣"),9999)
	l1lll1l11l1_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⮤"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮥"))
	if l1lll1l11l1_l1_:
		l1lll1l11l1_l1_ = l1lll1l11l1_l1_[l1l111_l1_ (u"ࠩࡢࡣࡘࡋࡑࡖࡇࡑࡇࡊࡊ࡟ࡄࡑࡏ࡙ࡒࡔࡓࡠࡡࠪ⮦")]
		for search in reversed(l1lll1l11l1_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮧"),search,l1l111_l1_ (u"ࠫࠬ⮨"),549,l1l111_l1_ (u"ࠬ࠭⮩"),l1l111_l1_ (u"࠭ࠧ⮪"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111ll11l_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"ࠧࠨ⮫"))
	l1lll11111l_l1_(l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⮬"),l1l111_l1_ (u"ࠩ฼้้ࠦศฮอࠣะ๊อู๋ࠢ࠰ࠤࠬ⮭")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ⮮"),542,l1l111_l1_ (u"ࠫࠬ⮯"),l1l111_l1_ (u"ࠬ࠭⮰"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⮱"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮲"),l1l111_l1_ (u"ࠨࠩ⮳"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮴"),l1l111_l1_ (u"๊ࠪฯอฦอࠢส่อำหࠡ็ไู้ฯࠠ࠮ࠢࠪ⮵")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⮶"),542,l1l111_l1_ (u"ࠬ࠭⮷"),l1l111_l1_ (u"࠭ࠧ⮸"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮹"),l1l111_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅใี่อࠥ࠳ࠠࠨ⮺")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮻"),542,l1l111_l1_ (u"ࠪࠫ⮼"),l1l111_l1_ (u"ࠫࠬ⮽"),l1111ll11l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮾"),l1l111_l1_ (u"࠭ศฮอ้๋ࠣ็ัะࠢ࠰ࠤࠬ⮿")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨ⯀"),541,l1l111_l1_ (u"ࠨࠩ⯁"),l1l111_l1_ (u"ࠩࠪ⯂"),l1111ll11l_l1_)
	return
def l1lll11111l_l1_(l1lll1lll1l_l1_):
	l1lll1lllll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯃"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⯄"),l1lll1lll1l_l1_)
	l1lll1llll1_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ⯅"),l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⯆"),l1lllll_l1_+l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⯇"),l1lll1lll1l_l1_)
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⯈"),l1lllll_l1_+l1lll1lll1l_l1_)
	old_value = l1lll1lllll_l1_+l1lll1llll1_l1_
	if old_value: l1lll1lll1l_l1_ = l1lllll_l1_+l1lll1lll1l_l1_
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⯉"),l1lll1lll1l_l1_,old_value,l1lll11ll1l_l1_)
	return
def l1lll111l1l_l1_():
	l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠪࠫ⯊"),l1l111_l1_ (u"ࠫࠬ⯋"),l1l111_l1_ (u"ࠬ࠭⯌"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⯍"),l1l111_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠤࠫ⯎"))
	if l1llll111l_l1_!=1: return
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⯏"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡑࡓࡉࡓࡋࡄࠨ⯐"))
	l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⯑"))
	l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ⯒"),l1l111_l1_ (u"ࠬ࠭⯓"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⯔"),l1l111_l1_ (u"ࠧห็ࠣฬ๋าวฮ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ⯕"))
	return
def l1lll11l11l_l1_(l1lll111ll1_l1_,action,l1lll11ll11_l1_=l1l111_l1_ (u"ࠨࠩ⯖")):
	l1lll11lll1_l1_,l1lll11llll_l1_,l1lll1l11ll_l1_,l1ll1lll1l1_l1_,l1ll1llll1l_l1_,l1ll1llll11_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨ⯗"):
		if action==l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⯘"): l1lll1l11ll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⯙"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⯚"),l1lllll_l1_+l1lll111ll1_l1_)
		elif action==l1l111_l1_ (u"࠭࡯ࡱࡧࡱࡩࡩࡥࡳࡪࡶࡨࡷࠬ⯛"): l1lll1l11ll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⯜"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧ⯝"),l1lll111ll1_l1_)
		elif action==l1l111_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⯞"): l1lll1l11ll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⯟"),l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪ⯠"),(l1lll11ll11_l1_,l1lll111ll1_l1_))
	if not l1lll1l11ll_l1_:
		l1lll1ll111_l1_ = l1l111_l1_ (u"ࠬํะศࠢส่อำหࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࡠࡳ࠭⯡")
		l1lll1ll11l_l1_ = l1l111_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊ࠥอไษฯฮࠤๆ๐ࠠอ็ํ฽ࠥอไๆ๊สๆ฾ูࠦ็ࠢ࡟ࡲࠥࠨ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢࠪ⯢")+l1lll111ll1_l1_+l1l111_l1_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥࠤࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไษฯฮࠤ็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠩ⯣")
		if action==l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⯤"): message = l1lll1ll11l_l1_
		else: message = l1lll1ll111_l1_+l1lll1ll11l_l1_
		l1llll111l_l1_ = l1ll11ll1l_l1_(l1l111_l1_ (u"ࠩࠪ⯥"),l1l111_l1_ (u"ࠪࠫ⯦"),l1l111_l1_ (u"ࠫࠬ⯧"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⯨"),message)
		if l1llll111l_l1_!=1: return
		l1lll1l1ll1_l1_(False,False)
		l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⯩"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡪࡧࡲࡤࡪࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ⯪")+l1lll111ll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ⯫"))
		l1llll11l11_l1_ = 1
		for l1lll11ll11_l1_ in l1lll1l111l_l1_:
			l1ll1lll1l1_l1_[l1lll11ll11_l1_] = []
			options = l1l111_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ⯬")
			if l1l111_l1_ (u"ࠪ࠱ࠬ⯭") in l1lll11ll11_l1_: options = options+l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ⯮")+l1lll11ll11_l1_+l1l111_l1_ (u"ࠬࡥࠧ⯯")
			l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_ = l1ll1lllll1_l1_(l1lll11ll11_l1_)
			if l1llll11l11_l1_:
				time.sleep(0.5)
				threads[l1lll11ll11_l1_] = threading.Thread(target=l1lll11l1ll_l1_,args=(l1lll111ll1_l1_+options,))
				threads[l1lll11ll11_l1_].start()
			else: l1lll11l1ll_l1_(l1lll111ll1_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1lll11ll11_l1_),l1l111_l1_ (u"࠭ࠧ⯰"),time=1000)
		if l1llll11l11_l1_:
			time.sleep(2)
			for l1lll11ll11_l1_ in l1lll1l111l_l1_:
				threads[l1lll11ll11_l1_].join(10)
			time.sleep(2)
		for l1lll11ll11_l1_ in l1lll1l111l_l1_:
			l1lll1111ll_l1_,l1lll11l1ll_l1_,l1llll111ll_l1_ = l1ll1lllll1_l1_(l1lll11ll11_l1_)
			for l1lll11l111_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = l1lll11l111_l1_
				if l1llll111ll_l1_ in name:
					if l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࠭⯱") in l1lll11ll11_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫ⯲")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯳")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⯴")]: continue
						if l1l111_l1_ (u"ฺࠫ็อสࠩ⯵") not in name:
							if   type==l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⯶"): l1lll11ll11_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⯷")
							elif type==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯸"): l1lll11ll11_l1_ = l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭⯹")
							elif type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯺"): l1lll11ll11_l1_ = l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ⯻")
						else:
							if   l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ⯼") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯽")
							elif l1l111_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭⯾") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⯿")
							elif l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨⰀ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧⰁ")
					elif l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࠨⰂ") in l1lll11ll11_l1_ and 729>=mode>=710:
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭Ⰳ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩⰄ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪⰅ")]: continue
						if l1l111_l1_ (u"ࠧึใะอࠬⰆ") not in name:
							if   type==l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭Ⰷ"): l1lll11ll11_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫⰈ")
							elif type==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⰉ"): l1lll11ll11_l1_ = l1l111_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰊ")
							elif type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⰋ"): l1lll11ll11_l1_ = l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪⰌ")
						else:
							if   l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉࠬⰍ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪⰎ")
							elif l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩⰏ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰐ")
							elif l1l111_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫⰑ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩⰒ")
					elif l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࠨⰓ") in l1lll11ll11_l1_ and 149>=mode>=140:
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪⰔ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬⰕ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪⰖ")]: continue
						if l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭Ⱇ") in name or l1l111_l1_ (u"ࠫ࠿ࡀࠠࠨⰘ") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"࡛ࠬࡓࡆࡔࠪⰙ") in name: l1lll11ll11_l1_ = l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩⰚ")
							elif mode==144 and l1l111_l1_ (u"ࠧࡄࡊࡑࡐࠬⰛ") in name: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰜ")
							elif mode==144 and l1l111_l1_ (u"ࠩࡏࡍࡘ࡚ࠧⰝ") in name: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰞ")
							elif mode==143: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬⰟ")
							else: continue
					elif l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࠫⰠ") in l1lll11ll11_l1_ and 419>=mode>=400:
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧⰡ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧⰢ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭Ⱓ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧⰤ")]: continue
						if   mode in [401,405]: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫⰥ")
						elif mode in [402,406]: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫⰦ")
						elif mode in [403,404]: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪⰧ")
						elif mode in [412,413]: l1lll11ll11_l1_ = l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫⰨ")
					elif l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࠧⰩ") in l1lll11ll11_l1_ and 39>=mode>=30:
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙ࠧⰪ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨⰫ")]: continue
						if   mode in [32,39]: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩⰬ")
						elif mode in [33,39]: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪⰭ")
					elif l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࠬⰮ") in l1lll11ll11_l1_ and 29>=mode>=20:
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬⰯ")]: continue
						if l1lll11l111_l1_ in l1ll1lll1l1_l1_[l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧⰰ")]: continue
						if   l1l111_l1_ (u"ࠨ࠱ࡤࡶ࠳࠭ⰱ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨⰲ")
						elif l1l111_l1_ (u"ࠪ࠳ࡪࡴ࠮ࠨⰳ") in url: l1lll11ll11_l1_ = l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫⰴ")
					l1ll1lll1l1_l1_[l1lll11ll11_l1_].append(l1lll11l111_l1_)
		menuItemsLIST[:] = []
		for l1lll11ll11_l1_ in list(l1ll1lll1l1_l1_.keys()):
			l1ll1llll1l_l1_[l1lll11ll11_l1_] = []
			l1ll1llll11_l1_[l1lll11ll11_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1ll1lll1l1_l1_[l1lll11ll11_l1_]:
				l1lll11l111_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
				if l1l111_l1_ (u"ࠬ฻แฮหࠪⰵ") in name and type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰶ"): l1ll1llll11_l1_[l1lll11ll11_l1_].append(l1lll11l111_l1_)
				else: l1ll1llll1l_l1_[l1lll11ll11_l1_].append(l1lll11l111_l1_)
		l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰷ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰸ"),l1l111_l1_ (u"ࠩࠪⰹ"),157,l1l111_l1_ (u"ࠪࠫⰺ"),l1l111_l1_ (u"ࠫࠬⰻ"),l1l111_l1_ (u"ࠬ࠭ⰼ"),l1l111_l1_ (u"࠭ࠧⰽ"),l1l111_l1_ (u"ࠧࠨⰾ"))]
		for l1lll11ll11_l1_ in l1lll1l1111_l1_:
			if l1lll11ll11_l1_==l1lll111l11_l1_[0]: l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⰿ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⱀ"),l1l111_l1_ (u"ࠪࠫⱁ"),157,l1l111_l1_ (u"ࠫࠬⱂ"),l1l111_l1_ (u"ࠬ࠭ⱃ"),l1l111_l1_ (u"࠭ࠧⱄ"),l1l111_l1_ (u"ࠧࠨⱅ"),l1l111_l1_ (u"ࠨࠩⱆ"))]
			elif l1lll11ll11_l1_==l1llll11111_l1_[0]: l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱇ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ⱈ"),l1l111_l1_ (u"ࠫࠬⱉ"),157,l1l111_l1_ (u"ࠬ࠭ⱊ"),l1l111_l1_ (u"࠭ࠧⱋ"),l1l111_l1_ (u"ࠧࠨⱌ"),l1l111_l1_ (u"ࠨࠩⱍ"),l1l111_l1_ (u"ࠩࠪⱎ"))]
			elif l1lll11ll11_l1_==l1ll1lll1ll_l1_[0]: l1lll1l1l1l_l1_ = [(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱏ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱐ"),l1l111_l1_ (u"ࠬ࠭ⱑ"),157,l1l111_l1_ (u"࠭ࠧⱒ"),l1l111_l1_ (u"ࠧࠨⱓ"),l1l111_l1_ (u"ࠨࠩⱔ"),l1l111_l1_ (u"ࠩࠪⱕ"),l1l111_l1_ (u"ࠪࠫⱖ"))]
			if l1lll11ll11_l1_ not in l1ll1llll1l_l1_.keys(): continue
			if l1ll1llll1l_l1_[l1lll11ll11_l1_]:
				l1lll111111_l1_ = TRANSLATE(l1lll11ll11_l1_)
				l1lll111lll_l1_ = [(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⱗ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࠦࠧⱘ")+l1lll111111_l1_+l1l111_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⱙ"),l1l111_l1_ (u"ࠧࠨⱚ"),9999,l1l111_l1_ (u"ࠨࠩⱛ"),l1l111_l1_ (u"ࠩࠪⱜ"),l1l111_l1_ (u"ࠪࠫⱝ"),l1l111_l1_ (u"ࠫࠬⱞ"),l1l111_l1_ (u"ࠬ࠭ⱟ"))]
				if 0:
					l1llll1111l_l1_ = l1lll111ll1_l1_+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪⱠ")+l1l111_l1_ (u"ࠧษฯฮࠫⱡ")+l1l111_l1_ (u"ࠨࠢࠪⱢ")+l1lll111111_l1_
				else:
					l1llll1111l_l1_ = l1l111_l1_ (u"ࠩหัะ࠭Ᵽ")+l1l111_l1_ (u"ࠪࠤࠬⱤ")+l1lll111111_l1_+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨⱥ")+l1lll111ll1_l1_
				if len(l1ll1llll1l_l1_[l1lll11ll11_l1_])<8: l1lll1l1l11_l1_ = []
				else:
					l1llll111l1_l1_ = l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨⱦ")+l1llll1111l_l1_+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨⱧ")
					l1lll1l1l11_l1_ = [(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱨ"),l1lllll_l1_+l1llll111l1_l1_,l1l111_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱩ"),542,l1l111_l1_ (u"ࠩࠪⱪ"),l1lll11ll11_l1_,l1lll111ll1_l1_,l1l111_l1_ (u"ࠪࠫⱫ"),l1l111_l1_ (u"ࠫࠬⱬ"))]
				l1lll1ll1ll_l1_ = l1ll1llll1l_l1_[l1lll11ll11_l1_]+l1ll1llll11_l1_[l1lll11ll11_l1_]
				l1lll11llll_l1_ += l1lll1l1l1l_l1_+l1lll111lll_l1_+l1lll1ll1ll_l1_[:7]+l1lll1l1l11_l1_
				l1ll1llllll_l1_ = [(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱭ"),l1lllll_l1_+l1llll1111l_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬⱮ"),542,l1l111_l1_ (u"ࠧࠨⱯ"),l1lll11ll11_l1_,l1lll111ll1_l1_,l1l111_l1_ (u"ࠨࠩⱰ"),l1l111_l1_ (u"ࠩࠪⱱ"))]
				l1lll11lll1_l1_ += l1lll1l1l1l_l1_+l1ll1llllll_l1_
				l1lll1l1l1l_l1_ = []
				l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩⱲ"),(l1lll11ll11_l1_,l1lll111ll1_l1_),l1lll1ll1ll_l1_,l1lll11ll1l_l1_)
		l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪⱳ"),l1lll111ll1_l1_,l1lll11llll_l1_,l1lll11ll1l_l1_)
		l1lll1ll1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱴ"),l1lll111ll1_l1_)
		l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱵ"),l1lllll_l1_+l1lll111ll1_l1_,l1lll11lll1_l1_,l1lll11ll1l_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨⱶ"),l1l111_l1_ (u"ࠨࠩⱷ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⱸ"),l1l111_l1_ (u"ࠪห้ฮอฬࠢส่ั๋วฺ์ࠣห๋ะ็๊ࠢห๊ัออࠡ࡞ࡱࡠࡳࠦสๆࠢอาื๐ๆࠡษ็๊ฯอฦอࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤ้๋ฯสࠢฮ่ฬั๊็ࠢํ์๊ࠦไไ์ࠣฮุะื๋฻ࠣห้฿่ะหࠣษ้๐็ศࠢหำํ์ฺࠠ็็ࠤอำหࠡฮา๎ิ࠭ⱹ"))
		if action==l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⱺ") and l1lll11lll1_l1_: l1lll1l11ll_l1_ = l1lll11lll1_l1_
		else: l1lll1l11ll_l1_ = l1lll11llll_l1_
	if action!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫⱻ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ in l1lll1l11ll_l1_:
			if action in [l1l111_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬⱼ"),l1l111_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱽ")] and l1l111_l1_ (u"ࠨืไัฮ࠭Ȿ") in name and type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱿ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_)
	l1lll1l1ll1_l1_(None,None)
	return
def l1lll1l1lll_l1_(l1lll111ll1_l1_=l1l111_l1_ (u"ࠪࠫⲀ")):
	search,options,l11_l1_ = l111ll_l1_(l1lll111ll1_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⲁ"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩⲂ")+search+l1l111_l1_ (u"࠭ࠠ࡞ࠩⲃ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll1lll11_l1_,l1111ll11l_l1_ = search+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫⲄ"),l1l111_l1_ (u"ࠨࠩⲅ")
	else: l1lll1lll11_l1_,l1111ll11l_l1_ = l1l111_l1_ (u"ࠩࠪⲆ"),l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⲇ")+search
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⲈ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⲉ"),l1l111_l1_ (u"࠭ࠧⲊ"),157)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲋ"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧⲌ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦࡍ࠴ࡗࠪⲍ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⲎ"),719,l1l111_l1_ (u"ࠫࠬⲏ"),l1l111_l1_ (u"ࠬ࠭Ⲑ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲑ"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭Ⲓ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯࠥࡏࡐࡕࡘࠪⲓ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⲔ"),239,l1l111_l1_ (u"ࠪࠫⲕ"),l1l111_l1_ (u"ࠫࠬⲖ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲗ"),l1l111_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬⲘ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢห็ึอࠧⲙ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⲚ"),379,l1l111_l1_ (u"ࠩࠪⲛ"),l1l111_l1_ (u"ࠪࠫⲜ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲝ"),l1l111_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫⲞ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪⲟ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⲠ"),19,l1l111_l1_ (u"ࠨࠩⲡ"),l1l111_l1_ (u"ࠩࠪⲢ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲣ"),l1l111_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪⲤ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫⲥ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⲦ"),739,l1l111_l1_ (u"ࠧࠨⲧ"),l1l111_l1_ (u"ࠨࠩⲨ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲩ"),l1l111_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩⲪ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫⲫ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭Ⲭ"),329,l1l111_l1_ (u"࠭ࠧⲭ"),l1l111_l1_ (u"ࠧࠨⲮ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲯ"),l1l111_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⲰ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩⲱ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⲲ"),579,l1l111_l1_ (u"ࠬ࠭ⲳ"),l1l111_l1_ (u"࠭ࠧⲴ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲵ"),l1l111_l1_ (u"ࠨࡡࡎࡘ࡛ࡥࠧⲶ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨⲷ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⲸ"),819,l1l111_l1_ (u"ࠫࠬⲹ"),l1l111_l1_ (u"ࠬ࠭Ⲻ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲻ"),l1l111_l1_ (u"ࠧࡠࡇࡅ࠵ࡤ࠭Ⲽ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯࠦ࠱ࠨⲽ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⲾ"),779,l1l111_l1_ (u"ࠪࠫⲿ"),l1l111_l1_ (u"ࠫࠬⳀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳁ"),l1l111_l1_ (u"࠭࡟ࡆࡄ࠵ࡣࠬⳂ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧⳃ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⳄ"),789,l1l111_l1_ (u"ࠩࠪⳅ"),l1l111_l1_ (u"ࠪࠫⳆ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳇ"),l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫⳈ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ࠠࠡสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩⳉ")+l1111ll11l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠪⳊ"),l1l111_l1_ (u"ࠨࠩⳋ"),29,l1l111_l1_ (u"ࠩࠪⳌ"),l1l111_l1_ (u"ࠪࠫⳍ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳎ"),l1l111_l1_ (u"ࠬࡥࡁࡌࡑࡢࠫⳏ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧⳐ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⳑ"),79,l1l111_l1_ (u"ࠨࠩⳒ"),l1l111_l1_ (u"ࠩࠪⳓ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳔ"),l1l111_l1_ (u"ࠫࡤࡇࡋࡘࡡࠪⳕ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭Ⳗ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⳗ"),249,l1l111_l1_ (u"ࠧࠨⳘ"),l1l111_l1_ (u"ࠨࠩⳙ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳚ"),l1l111_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩⳛ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬⳜ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⳝ"),49,l1l111_l1_ (u"࠭ࠧⳞ"),l1l111_l1_ (u"ࠧࠨⳟ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳠ"),l1l111_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨⳡ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ่ࠢหู่ࠧⳢ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⳣ"),59,l1l111_l1_ (u"ࠬ࠭ⳤ"),l1l111_l1_ (u"࠭ࠧ⳥"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⳦"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษ๊ࠡ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⳧"),l1l111_l1_ (u"ࠩࠪ⳨"),157)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳩"),l1l111_l1_ (u"ࠫࡤࡌࡊࡔࡡࠪ⳪")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬࠦศฮอ้ࠣํู่ࠡใฯีฺ่ࠥࠨⳫ")+l1111ll11l_l1_+l1l111_l1_ (u"࠭ࠠࠨⳬ"),l1l111_l1_ (u"ࠧࠨⳭ"),399,l1l111_l1_ (u"ࠨࠩⳮ"),l1l111_l1_ (u"ࠩࠪ⳯"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳰"),l1l111_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ⳱")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩⳲ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⳳ"),469,l1l111_l1_ (u"ࠧࠨ⳴"),l1l111_l1_ (u"ࠨࠩ⳵"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),l1l111_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ⳷")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦไ้ัํࠤ๋ะࠧ⳸")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭⳹"),459,l1l111_l1_ (u"࠭ࠧ⳺"),l1l111_l1_ (u"ࠧࠨ⳻"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳼"),l1l111_l1_ (u"ࠩࡢࡇࡒࡔ࡟ࠨ⳽")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧ⳾")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⳿"),309,l1l111_l1_ (u"ࠬ࠭ⴀ"),l1l111_l1_ (u"࠭ࠧⴁ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴂ"),l1l111_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧⴃ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤํ๐ࠠิ์่หࠬⴄ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⴅ"),569,l1l111_l1_ (u"ࠫࠬⴆ"),l1l111_l1_ (u"ࠬ࠭ⴇ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴈ"),l1l111_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭ⴉ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣฬํฯ่ࠡํ์ื࠭ⴊ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⴋ"),589,l1l111_l1_ (u"ࠪࠫⴌ"),l1l111_l1_ (u"ࠫࠬⴍ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪⴎ"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l1l111_l1_ (u"ࠧࡠࡃࡕࡗࡤ࠭ⴐ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ฽ึฮࠠิ์ํำࠬⴑ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⴒ"),259,l1l111_l1_ (u"ࠪࠫⴓ"),l1l111_l1_ (u"ࠫࠬⴔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),l1l111_l1_ (u"࠭࡟ࡄࡅࡅࡣࠬⴖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬⴗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴘ"),829,l1l111_l1_ (u"ࠩࠪⴙ"),l1l111_l1_ (u"ࠪࠫⴚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴛ"),l1l111_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫⴜ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦแ้ำํ์ࠬⴝ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴞ"),119,l1l111_l1_ (u"ࠨࠩⴟ"),l1l111_l1_ (u"ࠩࠪⴠ"),l1lll1ll_l1_+l1l111_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨⴡ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴢ"),l1l111_l1_ (u"ࠬࡥࡓࡉࡖࡢࠫⴣ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึ๋ๅ์อࠠห์ไ๎ࠬⴤ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴥ"),649,l1l111_l1_ (u"ࠨࠩ⴦"),l1l111_l1_ (u"ࠩࠪⴧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l1l111_l1_ (u"ࠫࡤࡋࡂ࠴ࡡࠪ⴩")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠷ࠬ⴪")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⴫"),799,l1l111_l1_ (u"ࠧࠨ⴬"),l1l111_l1_ (u"ࠨࠩⴭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⴮"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⴯"),l1l111_l1_ (u"ࠫࠬⴰ"),157)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴱ"),l1l111_l1_ (u"࠭࡟ࡇࡕࡗࡣࠬⴲ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไ์ุะวࠨⴳ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⴴ"),609,l1l111_l1_ (u"ࠩࠪⴵ"),l1l111_l1_ (u"ࠪࠫⴶ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴷ"),l1l111_l1_ (u"ࠬࡥࡆࡃࡍࡢࠫⴸ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใหี่ฯࠧⴹ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⴺ"),629,l1l111_l1_ (u"ࠨࠩⴻ"),l1l111_l1_ (u"ࠩࠪⴼ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⴽ"),l1l111_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪⴾ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋ࠠษๅ์ฯ࠭ⴿ")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧⵀ"),669,l1l111_l1_ (u"ࠧࠨⵁ"),l1l111_l1_ (u"ࠨࠩⵂ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵃ"),l1l111_l1_ (u"ࠪࡣࡇࡘࡓࡠࠩⵄ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศาีอ๎ั࠭ⵅ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⵆ"),659,l1l111_l1_ (u"࠭ࠧⵇ"),l1l111_l1_ (u"ࠧࠨⵈ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵉ"),l1l111_l1_ (u"ࠩࡢࡈࡗ࠽࡟ࠨⵊ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧⵋ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬⵌ"),689,l1l111_l1_ (u"ࠬ࠭ⵍ"),l1l111_l1_ (u"࠭ࠧⵎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵏ"),l1l111_l1_ (u"ࠨࡡࡆࡑࡋࡥࠧⵐ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧⵑ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠪࠫⵒ"),99,l1l111_l1_ (u"ࠫࠬⵓ"),l1l111_l1_ (u"ࠬ࠭ⵔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵕ"),l1l111_l1_ (u"ࠧࡠࡅࡐࡐࡤ࠭ⵖ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ⵗ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠩࠪⵘ"),479,l1l111_l1_ (u"ࠪࠫⵙ"),l1l111_l1_ (u"ࠫࠬⵚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵛ"),l1l111_l1_ (u"࠭࡟ࡂࡄࡇࡣࠬⵜ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อฺࠠสา์ࠬⵝ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠨࠩⵞ"),559,l1l111_l1_ (u"ࠩࠪⵟ"),l1l111_l1_ (u"ࠪࠫⵠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵡ"),l1l111_l1_ (u"ࠬࡥࡃ࠵ࡊࡢࠫⵢ")+l1lll1lll11_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪⵣ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨⵤ"),699,l1l111_l1_ (u"ࠨࠩⵥ"),l1l111_l1_ (u"ࠩࠪⵦ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵧ"),l1l111_l1_ (u"ࠫࡤࡇࡈࡌࡡࠪ⵨")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫ⵩")+l1111ll11l_l1_,l1l111_l1_ (u"࠭ࠧ⵪"),619,l1l111_l1_ (u"ࠧࠨ⵫"),l1l111_l1_ (u"ࠨࠩ⵬"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⵭"),l1l111_l1_ (u"ࠪࡣࡊࡈ࠴ࡠࠩ⵮")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫⵯ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭⵰"),809,l1l111_l1_ (u"࠭ࠧ⵱"),l1l111_l1_ (u"ࠧࠨ⵲"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵳"),l1l111_l1_ (u"ࠩࡢࡇࡈ࡝࡟ࠨ⵴")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬ⵵")+l1111ll11l_l1_,l1l111_l1_ (u"ࠫࠬ⵶"),639,l1l111_l1_ (u"ࠬ࠭⵷"),l1l111_l1_ (u"࠭ࠧ⵸"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⵹"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⵺"),l1l111_l1_ (u"ࠩࠪ⵻"),157)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⵼"),l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ⵽")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠧ⵾")+l1111ll11l_l1_,l1l111_l1_ (u"⵿࠭ࠧ"),149,l1l111_l1_ (u"ࠧࠨⶀ"),l1l111_l1_ (u"ࠨࠩⶁ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶂ"),l1l111_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩⶃ")+l1lll1lll11_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩⶄ")+l1111ll11l_l1_,l1l111_l1_ (u"ࠬ࠭ⶅ"),409,l1l111_l1_ (u"࠭ࠧⶆ"),l1l111_l1_ (u"ࠧࠨⶇ"),l1lll1ll_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ姼")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭姽")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠨ姾"),l1l111_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ姿")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ娀"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ威"),l1l111_l1_ (u"ࠬ࠭娂"),l1l111_l1_ (u"࠭ࠧ娃"),l1l111_l1_ (u"ࠧࠨ娄"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ娅"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ娆"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬ娇"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ娈"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ娉"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭娊"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠧࠨ娋"),l1l111_l1_ (u"ࠨࠩ娌"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭娍"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ娎"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭娏"),l1l111_l1_ (u"ࠬ࠭娐"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭娑"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ娒")+l1lllll_l1_+l1l111_l1_ (u"ࠨละำะࠦวๅ็๋ห฻๐ูࠨ娓"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨ࡭ࡺࡃࡦࡧࡴࡻ࡮ࡵࠤࠪ娔"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ娕"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭娖"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ娗"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ娘")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l11l11lll11l_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ娙"),url,l1l111_l1_ (u"ࠨࠩ娚"),l1l111_l1_ (u"ࠩࠪ娛"),l1l111_l1_ (u"ࠪࠫ娜"),l1l111_l1_ (u"ࠫࠬ娝"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ娞"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡱࡶࡸ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ娟"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭娠"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠨ็ืห์ีษࠨ娡"),l1l111_l1_ (u"ࠩไ๎้๋ࠧ娢"),l1l111_l1_ (u"ࠪห฿์๊สࠩ娣"),l1l111_l1_ (u"ࠫศเๆ๋หࠪ娤"),l1l111_l1_ (u"้ࠬไ๋สࠪ娥"),l1l111_l1_ (u"࠭วฺๆส๊ࠬ娦"),l1l111_l1_ (u"่ࠧัสๅࠬ娧"),l1l111_l1_ (u"ࠨ็หหึอษࠨ娨"),l1l111_l1_ (u"ࠩ฼ี฻࠭娩"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪ娪"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪ娫"),l1l111_l1_ (u"๋ࠬำาฯํอࠬ娬")]
	l11l11lll1l1_l1_ = l1l111_l1_ (u"࠭࠯ࠨ娭").join(l11l11lll11l_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ娮")).split(l1l111_l1_ (u"ࠨ࠱ࠪ娯"))[4:]).split(l1l111_l1_ (u"ࠩ࠰ࠫ娰"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ娱"),title,re.DOTALL)
		if l11l11lll11l_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠫ࠴࠭娲").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧ娳")).split(l1l111_l1_ (u"࠭࠯ࠨ娴"))[4:]).split(l1l111_l1_ (u"ࠧ࠮ࠩ娵"))
			l11l11lll1ll_l1_ = len([x for x in l11l11lll1l1_l1_ if x in l111lllll_l1_])
			if l11l11lll1ll_l1_>2 and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ娶") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ娷"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭娸"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ู๊ࠫไิๆࠪ娹") not in title:
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ娺"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"࠭อๅไฬࠫ娻") in title:
				title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭娼") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ娽"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ娾"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ娿"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ婀"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠣ婁"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ婂"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠧศๆุๅาฯࠠࠨ婃"),l1l111_l1_ (u"ࠨࠩ婄"))
			if title!=l1l111_l1_ (u"ࠩࠪ婅"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婆"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ婇")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠬ࠭婈"),l1l111_l1_ (u"࠭ࠧ婉"),l11l11lll11l_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ婊"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ婋")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭婌"),url,l1l111_l1_ (u"ࠪࠫ婍"),headers,l1l111_l1_ (u"ࠫࠬ婎"),l1l111_l1_ (u"ࠬ࠭婏"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ婐"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ婑"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ婒"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠪ婓"))
	l11l11lll111_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵࡕࡨࡥࡸࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ婔"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶࠫ婕") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠩ婖"))
		if count==0: count = block.count(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠬ婗"))
		if count>1:
			l11l11lll111_l1_ = False
			if l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦࠬ婘") in block:
				items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳ࡭ࡷࡪࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ婙"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠶࠳ࡶࡨࡱࡁࡶࡰࡺ࡭࠽ࠨ婚")+id
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婛"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡦࡹ࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ婜"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹ࠮ࡱࡪࡳࡃࡸ࡫ࡲࡪࡧࡶࡍࡉࡃࠧ婝")+id
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婞"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l11l11lll111_l1_:
		block = l1l111_l1_ (u"ࠧࠨ婟")
		if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ婠") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡵࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ婡"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ婢"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭婣"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ婤"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"࠭࠯ࠨ婥"))+l1l111_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡽࡡࡵࡥ࡫ࠫ婦")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ婧"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ婨"),l1l111_l1_ (u"ࠪࠫ婩"),l1l111_l1_ (u"ࠫࠬ婪"),l1l111_l1_ (u"ࠬ࠭婫"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ婬"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ婭"))
	l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡲࡣࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ婮"),html,re.DOTALL)
	if not l11111l11_l1_: l11111l11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟ࠬࡹ࡮ࡩࡴ࡞࠱࡭ࡩࡢࠬ࠱࡞࠯ࠬ࠳࠰࠿ࠪ࡞ࠬࠫ婯"),html,re.DOTALL)
	l11111l11_l1_ = l11111l11_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭婰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ婱"),block,re.DOTALL)
		for l111111ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ婲"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡪࡨࡵࡥࡲ࡫࠲࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩ婳")+l11111l11_l1_+l1l111_l1_ (u"ࠧࠧࡸ࡬ࡨࡪࡵ࠽ࠨ婴")+l111111ll_l1_[2:]+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ婵")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ婶")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡬࡫ࡴࡆ࡯ࡥࡩࡩࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ婷"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ婸"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭婹")+title+l1l111_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ婺")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠧ࠰ࠩ婻"))+l1l111_l1_ (u"ࠨ࠱ࡂࡨࡴࡃࡤࡰࡹࡱࡰࡴࡧࡤࠨ婼")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭婽"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ婾"),l1l111_l1_ (u"ࠫࠬ婿"),l1l111_l1_ (u"ࠬ࠭媀"),l1l111_l1_ (u"࠭ࠧ媁"),l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ媂"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡷࡥࡧࡲࡥ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ媃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ媄"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ媅"))
			if l1l111_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ媆") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ฯษุࠫ媇")
			else: l1lllllll_l1_ = l1l111_l1_ (u"࠭ࠧ媈")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ媉")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ媊")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ媋"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠪࠫ媌")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ媍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭媎"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ媏"),l1l111_l1_ (u"ࠧࠬࠩ媐"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠨࠩ媑"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ媒")+search+l1l111_l1_ (u"ࠪ࠳ࠬ媓")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࠬ媔"))
	return
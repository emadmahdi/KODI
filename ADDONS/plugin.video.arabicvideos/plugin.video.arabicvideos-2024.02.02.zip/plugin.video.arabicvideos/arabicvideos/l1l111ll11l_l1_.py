# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback,threading
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭㆘")
l1l1l1l11ll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ㆙"))
l1l111l111l_l1_ = os.path.join(l1l1l1l11ll_l1_,l1l111_l1_ (u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ㆚"))
sys.path.append(l1l111l111l_l1_)
l1l1l11l111_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ㆛"))
kodi_version = re.findall(l1l111_l1_ (u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭㆜"),l1l1l11l111_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1ll11l11_l1_ = xbmc.Player
l1l1l1llll1_l1_ = xbmcgui.WindowXMLDialog
PY2 = kodi_version<19
PY3 = kodi_version>18.99
if PY3:
	l1l11l1l1l1_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ㆝"),l1l111_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ㆞")
	l1l11llll1l_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭㆟"))
	from urllib.parse import unquote as _1l1l111ll1_l1_
else:
	l1l11l1l1l1_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧㆠ").encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㆡ")),l1l111_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩㆢ").encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆣ"))
	l1l11llll1l_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫㆤ"))
	from urllib import unquote as _1l1l111ll1_l1_
l1l1ll1ll1l_l1_ = 60
l1l11lll1ll_l1_ = 60*l1l1ll1ll1l_l1_
l1l11lll111_l1_ = 24*l1l11lll1ll_l1_
l1l1ll1l11l_l1_ = 30*l1l11lll111_l1_
l11l1l1_l1_ = 16*l1l11lll1ll_l1_
l1ll1ll1_l1_ = 3*l1l11lll111_l1_
l1ll111l1ll_l1_ = 12*l1l1ll1l11l_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠫ࠴࠭ㆥ"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1lll1ll1_l1_ = addon_id.split(l1l111_l1_ (u"ࠬ࠴ࠧㆦ"))[2]
l1l11l1111l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ㆧ")+addon_id+l1l111_l1_ (u"ࠧࠪࠩㆨ"))
addoncachefolder = os.path.join(l1l11llll1l_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡪࡡࡵࡣ࠱ࡨࡧ࠭ㆩ"))
l1l1l1111l1_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪㆪ"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url,l111ll11l_l1_=l1l111_l1_ (u"ࠪࡃࠬㆫ")):
	if l1l111_l1_ (u"ࠫࡂ࠭ㆬ") in url:
		if l111ll11l_l1_ in url: l1lllll1_l1_,filters = url.split(l111ll11l_l1_,1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"ࠬ࠭ㆭ"),url
		filters = filters.split(l1l111_l1_ (u"࠭ࠦࠨㆮ"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠧ࠾ࠩㆯ"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l111ll1_l1_(urll)
def EXTRACT_KODI_PATH(l1l111l1lll_l1_):
	l1ll111111l_l1_ = {l1l111_l1_ (u"ࠨࡶࡼࡴࡪ࠭ㆰ"):l1l111_l1_ (u"ࠩࠪㆱ"),l1l111_l1_ (u"ࠪࡱࡴࡪࡥࠨㆲ"):l1l111_l1_ (u"ࠫࠬㆳ"),l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩㆴ"):l1l111_l1_ (u"࠭ࠧㆵ"),l1l111_l1_ (u"ࠧࡵࡧࡻࡸࠬㆶ"):l1l111_l1_ (u"ࠨࠩㆷ"),l1l111_l1_ (u"ࠩࡳࡥ࡬࡫ࠧㆸ"):l1l111_l1_ (u"ࠪࠫㆹ"),l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩㆺ"):l1l111_l1_ (u"ࠬ࠭ㆻ"),l1l111_l1_ (u"࠭ࡩ࡮ࡣࡪࡩࠬㆼ"):l1l111_l1_ (u"ࠧࠨㆽ"),l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩㆾ"):l1l111_l1_ (u"ࠩࠪㆿ"),l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬ㇀"):l1l111_l1_ (u"ࠫࠬ㇁")}
	if l1l111_l1_ (u"ࠬࡅࠧ㇂") in l1l111l1lll_l1_: l1l111l1lll_l1_ = l1l111l1lll_l1_.split(l1l111_l1_ (u"࠭࠿ࠨ㇃"),1)[1]
	l1lllll1_l1_,l1ll1111111_l1_ = l1ll11ll1_l1_(l1l111l1lll_l1_)
	args = dict(list(l1ll111111l_l1_.items())+list(l1ll1111111_l1_.items()))
	l1l111l11l1_l1_ = args[l1l111_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ㇄")]
	l1l1l11lll1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㇅")])
	l1l11ll1l1l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ㇆")])
	l1l1111l11l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ㇇")])
	l1l1111l111_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ㇈")])
	l1l11ll1ll1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㇉")])
	l1l1ll11111_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡩ࡮ࡣࡪࡩࠬ㇊")])
	l1l11ll11ll_l1_ = args[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㇋")]
	l1l1l1111ll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪ㇌")])
	if l1l1l1111ll_l1_: l1l1l1111ll_l1_ = eval(l1l1l1111ll_l1_)
	else: l1l1l1111ll_l1_ = {}
	if not l1l111l11l1_l1_: l1l1111l111_l1_ = l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇍") ; l1l111l11l1_l1_ = l1l111_l1_ (u"ࠪ࠶࠻࠶ࠧ㇎")
	return l1l1111l111_l1_,l1l11ll1ll1_l1_,l1l1l11lll1_l1_,l1l111l11l1_l1_,l1l1ll11111_l1_,l1l1111l11l_l1_,l1l11ll1l1l_l1_,l1l11ll11ll_l1_,l1l1l1111ll_l1_
def l11lllll1l_l1_(l1ll1_l1_):
	l1l11ll1l11_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l11ll1l11_l1_ or l1l11ll1l11_l1_==l1l111_l1_ (u"ࠫࡁࡳ࡯ࡥࡷ࡯ࡩࡃ࠭㇏"):
		return l1l111_l1_ (u"ࠬࡡࠠࠨ㇐")+l1l1lll1ll1_l1_.upper()+l1l111_l1_ (u"࠭࠭ࠨ㇑")+l1l11l1111l_l1_+l1l111_l1_ (u"ࠧ࠮ࠩ㇒")+str(kodi_version)+l1l111_l1_ (u"ࠨࠢࡠࠫ㇓")
	return l1l111_l1_ (u"ࠩ࠱ࠤࠥ࠭㇔")+l1l11ll1l11_l1_
def l1l111111l_l1_(level,message):
	if PY2: message = message.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇕")).encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇖"))
	l1l11l111ll_l1_ = l1l11l1l1l1_l1_
	lines = [l1l111_l1_ (u"ࠬ࠭㇗"),l1l111_l1_ (u"࠭ࠧ㇘")]
	if level: message = message.replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㇙"),l1l111_l1_ (u"ࠨࠩ㇚")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㇛"),l1l111_l1_ (u"ࠪࠫ㇜")).replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㇝"),l1l111_l1_ (u"ࠬ࠭㇞"))
	else: level = l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㇟")
	l11ll1111l_l1_,sep,shift = l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ㇠"),l1l111_l1_ (u"ࠨࠢࠣࠤࠬ㇡"),l1l111_l1_ (u"ࠩࠪ㇢")
	if l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㇣") in level: l1l11l111ll_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㇤"):
		message = message+sep
		lines = message.split(sep)
		shift = l11ll1111l_l1_
	elif level==l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㇥"):
		message = message.replace(l1l111_l1_ (u"࠭࠮ࠨ㇦")+sep,l1l111_l1_ (u"ࠧ࠯ࠢࠣࠫ㇧"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠨ࠰ࠪ㇨")+lines[0][1:]
		shift = l11ll1111l_l1_+sep
	elif level in [l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㇩"),l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㇪")]: lines = message.split(l11ll1111l_l1_)
	shift += 6*l11ll1111l_l1_
	l1l11l11l1l_l1_ = 3*l11ll1111l_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"ࠫࠥ࠭㇫")
	l1l1ll11lll_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"ࠬࡢ࡮ࠨ㇬") in line: line = line.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㇭"),l1l111_l1_ (u"ࠧ࡝ࡰࠪ㇮")+l11ll1111l_l1_+l11ll1111l_l1_)
		l1l11l11l1l_l1_ += l11ll1111l_l1_
		l1l1ll11lll_l1_ += l1l111_l1_ (u"ࠨ࡞ࡵࠫ㇯")+shift+l1l11l11l1l_l1_+line
	l1l1ll11lll_l1_ += l1l111_l1_ (u"ࠩࠣࡣࠬㇰ")
	if l1l111_l1_ (u"ࠪࠩࠬㇱ") in l1l1ll11lll_l1_: l1l1ll11lll_l1_ = l111l11_l1_(l1l1ll11lll_l1_)
	xbmc.log(l1l1ll11lll_l1_,level=l1l11l111ll_l1_)
	return
def l1l1llll11l_l1_(l1ll1lll1l_l1_):
	conn = sqlite3.connect(l1ll1lll1l_l1_)
	l1llll1lll_l1_ = conn.cursor()
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡩ࡟ࡪࡰࡧࡩࡽࡃ࡮ࡰ࠽ࠪㇲ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡬࡯ࡳࡧ࡬࡫ࡳࡥ࡫ࡦࡻࡶࡁࡳࡵ࠻ࠨㇳ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩࡨࡰࡲࡶࡪࡥࡣࡩࡧࡦ࡯ࡤࡩ࡯࡯ࡵࡷࡶࡦ࡯࡮ࡵࡵࡀࡽࡪࡹ࠻ࠨㇴ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠ࡫ࡱࡸࡶࡳࡧ࡬ࡠ࡯ࡲࡨࡪࡃࡏࡇࡈ࠾ࠫㇵ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭ㇶ"))
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡶࡽࡳࡩࡨࡳࡱࡱࡳࡺࡹ࠽ࡐࡈࡉ࠿ࠬㇷ"))
	conn.text_factory = str
	return conn,l1llll1lll_l1_
def l1lll1ll1l1_l1_(l1ll1lll1l_l1_,table,l1l1l11l1l1_l1_=None):
	try: conn,l1llll1lll_l1_ = l1l1llll11l_l1_(l1ll1lll1l_l1_)
	except: return
	if l1l1l11l1l1_l1_==None: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡗࡕࡐࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬㇸ")+table+l1l111_l1_ (u"ࠫࠧࠦ࠻ࠨㇹ"))
	else:
		tt = (str(l1l1l11l1l1_l1_),)
		try:
			if l1l111_l1_ (u"ࠬࠫࠧㇺ") in l1l1l11l1l1_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ㇻ")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࡮࡬࡯ࡪࠦ࠿ࠡ࠽ࠪㇼ"),tt)
			else: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨㇽ")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩㇾ"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1ll1l1l1_l1_(): pass
class l1l1lllll11_l1_(l1l1ll1l1l1_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠪࠫㇿ")
		self.code = -99
		self.reason = l1l111_l1_ (u"ࠫࠬ㈀")
		self.content = l1l111_l1_ (u"ࠬ࠭㈁")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l11l11l_l1_(type):
	if type==l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫ㈂"): data = {}
	elif type==l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㈃"): data = []
	elif type==l1l111_l1_ (u"ࠨࡵࡷࡶࠬ㈄"): data = l1l111_l1_ (u"ࠩࠪ㈅")
	elif type==l1l111_l1_ (u"ࠪ࡭ࡳࡺࠧ㈆"): data = 0
	elif type==l1l111_l1_ (u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭㈇"): data = l1l1lllll11_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1l111lllll_l1_(l1l1111ll11_l1_):
	from hashlib import md5
	l1l1llll1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹࠧ㈈"))
	l1l1ll1l111_l1_ = l1l11l1l1ll_l1_(32).splitlines()
	l1l111ll1l1_l1_ = str(now/4.32)[0:4]
	for l1l111lll11_l1_ in l1l1ll1l111_l1_:
		l1l11ll11l1_l1_ = l1l111_l1_ (u"࠭ࡘ࠲࠻ࠪ㈉")+l1l1111ll11_l1_+l1l111_l1_ (u"ࠧ࠲࠺ࡀࠫ㈊")+l1l111lll11_l1_[-24:]+l1l11l1111l_l1_+l1l111ll1l1_l1_
		l1l11ll11l1_l1_ = md5(l1l11ll11l1_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㈋"))).hexdigest()[:32]
		if l1l11ll11l1_l1_ in l1l1llll1ll_l1_: return True
	return False
def l1lll11l1l1_l1_(l1ll1lll1l_l1_,l1l1l1ll111_l1_,table,l1l1l11l1l1_l1_=None):
	data = l1l1l11l11l_l1_(l1l1l1ll111_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ㈌"))
	if table!=l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㈍") and l1ll1lll1l_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㈎"): return data
		l1ll11l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㈏"))
		if l1ll11l1l1_l1_==l1l111_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ㈐"):
			l1lll1ll1l1_l1_(l1ll1lll1l_l1_,table,l1l1l11l1l1_l1_)
			return data
	l1ll111ll11_l1_ = 0
	if cache==l1l111_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ㈑"): l1ll111ll11_l1_ = l1l11l11111_l1_
	try: conn,l1llll1lll_l1_ = l1l1llll11l_l1_(l1ll1lll1l_l1_)
	except: return data
	l1l1l11111l_l1_ = True
	try: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠤࠪ㈒")+table+l1l111_l1_ (u"ࠩࠥࠤࡑࡏࡍࡊࡖࠣ࠵ࠥࡁࠧ㈓"))
	except: l1l1l11111l_l1_ = False
	if l1l1l11111l_l1_:
		if l1ll111ll11_l1_: l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㈔")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭㈕")+str(now+l1ll111ll11_l1_)+l1l111_l1_ (u"ࠬࠦ࠻ࠨ㈖"))
		conn.commit()
		l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㈗")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩ㈘")+str(now)+l1l111_l1_ (u"ࠨࠢ࠾ࠫ㈙"))
		conn.commit()
		if l1l1l11l1l1_l1_:
			tt = (str(l1l1l11l1l1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ㈚")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㈛"),tt)
			l1l11llll11_l1_ = l1llll1lll_l1_.fetchall()
			if l1l11llll11_l1_:
				try:
					text = zlib.decompress(l1l11llll11_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ㈜")+table+l1l111_l1_ (u"ࠬࠨࠠ࠼ࠩ㈝"))
			l1l11llll11_l1_ = l1llll1lll_l1_.fetchall()
			if l1l11llll11_l1_:
				data,l1l1llll111_l1_ = {},[]
				for l1l1ll11ll1_l1_,l1l11llll_l1_ in l1l11llll11_l1_:
					l1ll1ll11l_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1ll11l_l1_)
					data[l1l1ll11ll1_l1_] = l1l11llll_l1_
					l1l1llll111_l1_.append(l1l1ll11ll1_l1_)
				if l1l1llll111_l1_:
					data[l1l111_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ㈞")] = l1l1llll111_l1_
					if l1l1l1ll111_l1_==l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㈟"): data = l1l1llll111_l1_
	conn.close()
	return data
class l1l1l1l11l1_l1_(l1l1ll11l11_l1_):
	def __init__(self): self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠨࠩ㈠")
	def init(self,l1l11l1l111_l1_):
		self.l1l11l1l111_l1_ = l1l11l1l111_l1_
		self.l1ll111l11l_l1_ = l1l111lllll_l1_(l1l111_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㈡"))
		self.l1l1l1lllll_l1_ = l1l111lllll_l1_(l1l111_l1_ (u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫ㈢"))
		self.l1l1l11l1ll_l1_ = l1l111lllll_l1_(l1l111_l1_ (u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡛ࡒࡗࡐࡘࡗ࡚࠻ࡈ࡙ࠩ㈣"))
		if self.l1ll111l11l_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㈤")
		elif self.l1l1l1lllll_l1_: return
		elif self.l1l1l11l1ll_l1_:
			from l1l11lllll1_l1_ import l1l1l1l111l_l1_
			l1l1l1l111l_l1_(False)
		else:
			self.l1l1ll1llll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㈥")
			from l1l11lllll1_l1_ import l1l1l1l111l_l1_
			l1l1l1l111l_l1_(False)
	def onPlayBackStopped(self): self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㈦")
	def onPlayBackError(self): self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㈧")
	def onPlayBackEnded(self): self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㈨")
	def onPlayBackStarted(self):
		self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ㈩")
		l1l111l1l1l_l1_ = threading.Thread(target=self.l1l111ll1ll_l1_,args=())
		l1l111l1l1l_l1_.start()
	def l1l1lll1l11_l1_(self):
		if self.l1ll111l11l_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㈪")
		elif self.l1l1l1lllll_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㈫")
		elif self.l1l1l11l1ll_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㈬")
		else: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㈭")
	def l1l111ll1ll_l1_(self):
		l1l1l11ll1l_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪ࡚࡮ࡪࡥࡰࠪࠬࠫ㈮")) and self.l1l1ll1llll_l1_==l1l111_l1_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ㈯"):
			xbmc.sleep(1500)
			l1l1l11ll1l_l1_ += 1.5
			if l1l1l11ll1l_l1_>60: return
		if self.l1ll111l11l_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㈰")
		elif self.l1l1l1lllll_l1_: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㈱")
		elif self.l1l1l11l1ll_l1_:
			self.l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㈲")
			from LIBSTWO import l1l1ll1111l_l1_,l1l1111l1l1_l1_
			l1l111l1l11_l1_ = threading.Thread(target=l1l1ll1111l_l1_,args=(self.l1l11l1l111_l1_,))
			l1l111l1l11_l1_.start()
			l1l111l1ll1_l1_ = threading.Thread(target=l1l1111l1l1_l1_,args=())
			l1l111l1ll1_l1_.start()
		else: self.l1l1ll1llll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㈳")
def l1l1lll1lll_l1_():
	l1l11l1lll1_l1_,l1l1111lll1_l1_ = l1l111_l1_ (u"ࠧࠨ㈴"),l1l111_l1_ (u"ࠨࠩ㈵")
	l1l1lllllll_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨ㈶"))
	try:
		l1l11l1llll_l1_ = open(l1l111_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡤ࠱ࡦࡴࡺ࡯࡮ࡧࡱࠪ㈷"),l1l111_l1_ (u"ࠫࡷࡨࠧ㈸")).read()
		if PY3: l1l11l1llll_l1_ = l1l11l1llll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㈹"))
		l1l111l11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡥࡱ࠴ࠪࡀ࠼ࠣࠬ࠳࠰࠿ࠪࠦࠪ㈺"),l1l11l1llll_l1_,re.IGNORECASE)
		if l1l111l11ll_l1_: l1l11l1lll1_l1_ = l1l111l11ll_l1_[0]
	except: pass
	try:
		import subprocess
		l1l111lll1l_l1_ = subprocess.Popen(l1l111_l1_ (u"ࠧࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡝ࠦࠢࠡ࠱ࡶࡸࡴࡸࡡࡨࡧ࠲ࡩࡲࡻ࡬ࡢࡶࡨࡨ࠴࠶ࠠ࠼ࠢࡶࡸࡦࡺࠠ࠮ࡥࠣࠦࠥࠫࡗࠡࠤࠣ࠳ࡻࡧࡲ࠰࡮ࡲ࡫ࠬ㈻"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
		l1l11ll111l_l1_ = l1l111lll1l_l1_.stdout.read()
		if l1l11ll111l_l1_:
			if PY3:
				l1l11ll111l_l1_ = l1l11ll111l_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㈼"),l1l111_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ㈽"))
			l1l1l111l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧ㈾"),l1l11ll111l_l1_,re.IGNORECASE)
			if l1l1l111l11_l1_: l1l1111lll1_l1_ = min(l1l1l111l11_l1_)
	except: pass
	return l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_
def l1l11l1l1ll_l1_(l1l1l11ll11_l1_,l1l11l1ll11_l1_=True):
	l1l11lll11l_l1_ = True
	if l1l11l1ll11_l1_:
		l1l11ll1lll_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㈿"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㉀"),l1l111_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫ㉁"))
		if l1l11ll1lll_l1_:
			l1l1ll1l111_l1_,l1ll111l1l1_l1_,l1l1l1l1lll_l1_,l1l1l1l1ll1_l1_ = l1l11ll1lll_l1_
			l1l11lll11l_l1_ = l1lll11l1l1_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㉂"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㉃"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ㉄"))
			if l1l11lll11l_l1_: l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_ = l1l11lll11l_l1_
			else: l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_ = l1l1lll1lll_l1_()
			if (l1ll111l1l1_l1_,l1l1l1l1lll_l1_,l1l1l1l1ll1_l1_)==(l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_): return l1l111_l1_ (u"ࠪࡠࡳ࠭㉅").join(l1l1ll1l111_l1_)
	if l1l11lll11l_l1_: l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_ = l1l1lll1lll_l1_()
	global l1l1lll11l1_l1_,l1l1lll111l_l1_
	l1l1lll11l1_l1_,l1l1lll111l_l1_,l1l1lll1111_l1_ = l1l111_l1_ (u"ࠫࠬ㉆"),l1l111_l1_ (u"ࠬ࠭㉇"),l1l111_l1_ (u"࠭ࠧ㉈")
	l1l1l11ll11_l1_ = l1l1l11ll11_l1_//2
	threading.Thread(target=l1l1lll1l1l_l1_).start()
	threading.Thread(target=l1l1ll11l1l_l1_).start()
	for l1l111llll_l1_ in range(10):
		time.sleep(0.5)
		if not l1l1lll1111_l1_:
			try:
				l1ll1111ll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡏࡧࡷࡻࡴࡸ࡫࠯ࡏࡤࡧࡆࡪࡤࡳࡧࡶࡷࠬ㉉"))
				if l1ll1111ll1_l1_.count(l1l111_l1_ (u"ࠨ࠼ࠪ㉊"))==5 and l1ll1111ll1_l1_.count(l1l111_l1_ (u"ࠩ࠳ࠫ㉋"))<9:
					l1ll1111ll1_l1_ = l1ll1111ll1_l1_.lower().replace(l1l111_l1_ (u"ࠪ࠾ࠬ㉌"),l1l111_l1_ (u"ࠫࠬ㉍"))
					l1l1lll1111_l1_ = str(int(l1ll1111ll1_l1_,16))
			except: pass
		if l1l1lll11l1_l1_ and l1l1lll111l_l1_ and l1l1lll1111_l1_: break
	l1ll11111l1_l1_ = [l1l1lll11l1_l1_,l1l1lll111l_l1_,l1l1lll1111_l1_,l1l111_l1_ (u"ࠬ࠭㉎"),l1l111_l1_ (u"࠭ࠧ㉏"),l1l111_l1_ (u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪ㉐")]
	if l1l11l1lll1_l1_ or l1l1111lll1_l1_:
		from hashlib import md5
		l1l1ll111ll_l1_ = [(4,l1l11l1lll1_l1_),(5,l1l1111lll1_l1_)]
		for l1ll111l111_l1_,l1l1l111lll_l1_ in l1l1ll111ll_l1_:
			l1l1l111lll_l1_ = l1l1l111lll_l1_.strip(l1l111_l1_ (u"ࠨ࠲ࠪ㉑"))
			if l1l1l111lll_l1_:
				if PY3: l1l1l111lll_l1_ = l1l1l111lll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㉒"))
				l1l1l111lll_l1_ = str(int(md5(l1l1l111lll_l1_).hexdigest(),36))
				l1l1ll111l1_l1_ = [int(l1l1l111lll_l1_[l1ll1111lll_l1_:l1ll1111lll_l1_+15]) for l1ll1111lll_l1_ in range(len(l1l1l111lll_l1_)) if l1ll1111lll_l1_%15==0]
				l1ll11111l1_l1_[l1ll111l111_l1_-1] = str(sum(l1l1ll111l1_l1_))
	l1l1ll1l111_l1_,l1l1l1lll11_l1_ = [],False
	for l1l1l11llll_l1_ in range(len(l1ll11111l1_l1_)):
		l1l1ll111l1_l1_ = l1ll11111l1_l1_[l1l1l11llll_l1_]
		if not l1l1ll111l1_l1_: continue
		if l1l1l1lll11_l1_ and l1l1ll111l1_l1_==l1ll11111l1_l1_[-1]: continue
		l1l1l1lll11_l1_ = True
		l1l1ll111l1_l1_ = l1l1l11ll11_l1_*l1l111_l1_ (u"ࠪ࠴ࠬ㉓")+l1l1ll111l1_l1_
		l1l1ll111l1_l1_ = l1l1ll111l1_l1_[-l1l1l11ll11_l1_:]
		l1l1l1l1l11_l1_,l1l1lll11ll_l1_ = l1l111_l1_ (u"ࠫࠬ㉔"),l1l111_l1_ (u"ࠬ࠭㉕")
		l1l11111l1l_l1_ = str(int(l1l111_l1_ (u"࠭࠹ࠨ㉖")*(l1l1l11ll11_l1_+1))-int(l1l1ll111l1_l1_))[-l1l1l11ll11_l1_:]
		for l1l11l1ll1l_l1_ in list(range(0,l1l1l11ll11_l1_,4)):
			l1l11l11ll1_l1_ = l1l11111l1l_l1_[l1l11l1ll1l_l1_:l1l11l1ll1l_l1_+4]
			l1l1l1l1l11_l1_ += l1l11l11ll1_l1_+l1l111_l1_ (u"ࠧ࠮ࠩ㉗")
			l1l1lll11ll_l1_ += str(sum(map(int,l1l1ll111l1_l1_[l1l11l1ll1l_l1_:l1l11l1ll1l_l1_+4]))%10)
		l1l111lll11_l1_ = str(l1l1l11llll_l1_)+l1l1l1l1l11_l1_+l1l1lll11ll_l1_
		l1l1ll1l111_l1_.append(l1l111lll11_l1_)
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㉘"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ㉙"),[l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_],l11l1l1_l1_)
	l1lll1111l1_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㉚"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ㉛"),[l1l1ll1l111_l1_,l1l1lllllll_l1_,l1l11l1lll1_l1_,l1l1111lll1_l1_],l1ll1ll1_l1_)
	return l1l111_l1_ (u"ࠬࡢ࡮ࠨ㉜").join(l1l1ll1l111_l1_)
def l1l1l1ll11l_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㉝"),l1l111_l1_ (u"ࠧ࡝࡞ࡱࠫ㉞")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ㉟"),l1l111_l1_ (u"ࠩ࡟ࡠࡷ࠭㉠")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ㉡"),l1l111_l1_ (u"ࠫࠥ࠭㉢")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠩ㉣"),l1l111_l1_ (u"࠭ࠠࠨ㉤"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠧࠡ࠰࠱࠲ࠬ㉥")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㉦"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㉧")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㉨"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㉩")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㉪"),l1l111_l1_ (u"࠭ࠠࠨ㉫")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㉬"),l1l111_l1_ (u"ࠨࠢࠪ㉭"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㉮")
	l1l111111l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㉯"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࠩ㉰")+type+l1l111_l1_ (u"ࠬࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㉱")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㉲")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡵࡪࡲࡨ࠿࡛ࠦࠡࠩ㉳")+method+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫ㉴")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡅࡣࡷࡥ࠿࡛ࠦࠡࠩ㉵")+l1l11llll_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭㉶"))
	return
def l1l1lll1l1l_l1_():
	global l1l1lll11l1_l1_
	import getmac82
	try:
		l1ll1111l11_l1_ = getmac82.get_mac_address()
		if l1ll1111l11_l1_.count(l1l111_l1_ (u"ࠫ࠿࠭㉷"))==5 and l1ll1111l11_l1_.count(l1l111_l1_ (u"ࠬ࠶ࠧ㉸"))<9:
			l1ll1111l11_l1_ = l1ll1111l11_l1_.lower().replace(l1l111_l1_ (u"࠭࠺ࠨ㉹"),l1l111_l1_ (u"ࠧࠨ㉺"))
			l1l1lll11l1_l1_ = str(int(l1ll1111l11_l1_,16))
	except: pass
	return
def l1l1ll11l1l_l1_():
	global l1l1lll111l_l1_
	import getmac94
	try:
		l1ll1111l1l_l1_ = getmac94.get_mac_address()
		if l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠨ࠼ࠪ㉻"))==5 and l1ll1111l1l_l1_.count(l1l111_l1_ (u"ࠩ࠳ࠫ㉼"))<9:
			l1ll1111l1l_l1_ = l1ll1111l1l_l1_.lower().replace(l1l111_l1_ (u"ࠪ࠾ࠬ㉽"),l1l111_l1_ (u"ࠫࠬ㉾"))
			l1l1lll111l_l1_ = str(int(l1ll1111l1l_l1_,16))
	except: pass
	return
def l1l1111l1ll_l1_(method,url,data=l1l111_l1_ (u"ࠬ࠭㉿"),headers=l1l111_l1_ (u"࠭ࠧ㊀"),source=l1l111_l1_ (u"ࠧࠨ㊁")):
	l1l1l1ll11l_l1_(l1l111_l1_ (u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫ㊂"),url,data,headers,source,method)
	if PY3: import urllib.request as l1l1ll1ll11_l1_
	else: import urllib2 as l1l1ll1ll11_l1_
	if not headers: headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㊃"):l1l111_l1_ (u"ࠪࠫ㊄")}
	if not data: data = {}
	if method==l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㊅"):
		url = url+l1l111_l1_ (u"ࠬࡅࠧ㊆")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㊇") and l1l111_l1_ (u"ࠧ࡫ࡵࡲࡲࠬ㊈") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㊉"))
	elif method==l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㊊"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㊋"))
	try:
		req = l1l1ll1ll11_l1_.Request(url,headers=headers,data=data)
		response = l1l1ll1ll11_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"ࠫࡔࡑࠧ㊌")
	except:
		html = l1l111_l1_ (u"ࠬ࠭㊍")
		code,reason = -1,l1l111_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭㊎")
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㊏"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࠥࠦࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㊐")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫ㊑")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㊒")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㊓")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㊔"))
	if html and PY3: html = html.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㊕"))
	return html
def l1l1llllll1_l1_(l1l11l1l11l_l1_,l1l1111ll1l_l1_=l1l111_l1_ (u"ࠧࠨ㊖")):
	l1l11l11lll_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㊗"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ㊘")}
	l1l11111l11_l1_ = {	l1l111_l1_ (u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ㊙"):l1l11l1l1ll_l1_(32).splitlines()[0][-24:],
				l1l111_l1_ (u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ㊚"):str(kodi_version),
				l1l111_l1_ (u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥ㊛"):l1l11l1111l_l1_,
				l1l111_l1_ (u"ࠨࡤࡦࡸ࡬ࡧࡪࡥࡦࡢ࡯࡬ࡰࡾࠨ㊜"):l1l11l1111l_l1_,
				l1l111_l1_ (u"ࠢࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠦ㊝"):l1l11l1l11l_l1_,
				l1l111_l1_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ㊞"): l1l11l1111l_l1_,
				l1l111_l1_ (u"ࠤࡦࡥࡷࡸࡩࡦࡴࠥ㊟"):l1l111_l1_ (u"ࠥࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࠥ㊠"),
				l1l111_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ㊡"):{l1l111_l1_ (u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㊢"):l1l11l1l11l_l1_},
				l1l111_l1_ (u"ࠨࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㊣"): {l1l111_l1_ (u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㊤"):l1l11l1l11l_l1_},
				l1l111_l1_ (u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢ㊥"):False,
				l1l111_l1_ (u"ࠤ࡬ࡴࠧ㊦"): l1l111_l1_ (u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ㊧")
			}
	if not l1l1111ll1l_l1_: l1l111ll111_l1_ = [l1l11111l11_l1_]
	else:
		l1l11111ll1_l1_ = l1l11111l11_l1_.copy()
		l1l11111ll1_l1_[l1l111_l1_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ㊨")] = l1l1111ll1l_l1_
		l1l11111ll1_l1_[l1l111_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ㊩")] = {l1l111_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊪"):l1l1111ll1l_l1_}
		l1l11111ll1_l1_[l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ㊫")] = {l1l111_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㊬"):l1l1111ll1l_l1_}
		l1l111ll111_l1_ = [l1l11111l11_l1_,l1l11111ll1_l1_]
	data = {l1l111_l1_ (u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ㊭"):l1l111_l1_ (u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ㊮"),
			l1l111_l1_ (u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ㊯"):l1l11l11lll_l1_,
			l1l111_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ㊰"): l1l111ll111_l1_
		}
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ㊱")
	html = l1l1111l1ll_l1_(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㊲"),url,data,headers,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㊳"))
	return html
def l1ll1l1_l1_(l1l1l1ll111_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠩࡱࡹࡱࡲࠧ㊴"),l1l111_l1_ (u"ࠪࡒࡴࡴࡥࠨ㊵"))
	text = text.replace(l1l111_l1_ (u"ࠫࡹࡸࡵࡦࠩ㊶"),l1l111_l1_ (u"࡚ࠬࡲࡶࡧࠪ㊷"))
	text = text.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ㊸"),l1l111_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭㊹"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ㊺"),l1l111_l1_ (u"ࠩ࠲ࠫ㊻"))
	try: l1ll1ll11l_l1_ = eval(text)
	except: l1ll1ll11l_l1_ = l1l1l11l11l_l1_(l1l1l1ll111_l1_)
	return l1ll1ll11l_l1_
def l1l1l1ll1ll_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪ㊼"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫ㊽"),time.localtime(now))
	name = name+datetime
	l1lll11l111_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llllll1ll_l1_
	if os.path.exists(l1l1l1111l1_l1_):
		l1l11ll1111_l1_ = open(l1l1l1111l1_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㊾")).read()
		if PY3: l1l11ll1111_l1_ = l1l11ll1111_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㊿"))
		l1l11ll1111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㋀"),l1l11ll1111_l1_)
	else: l1l11ll1111_l1_ = {}
	l1l11l111l1_l1_ = {}
	for l1l1ll1lll1_l1_ in list(l1l11ll1111_l1_.keys()):
		if l1l1ll1lll1_l1_!=type: l1l11l111l1_l1_[l1l1ll1lll1_l1_] = l1l11ll1111_l1_[l1l1ll1lll1_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠨ࠰࠱ࠫ㋁"):
				l1l111llll1_l1_ = l1l11ll1111_l1_[l1l1ll1lll1_l1_]
				if l1lll11l111_l1_ in l1l111llll1_l1_:
					index = l1l111llll1_l1_.index(l1lll11l111_l1_)
					del l1l111llll1_l1_[index]
				l111l1ll11_l1_ = [l1lll11l111_l1_]+l1l111llll1_l1_
				l111l1ll11_l1_ = l111l1ll11_l1_[:50]
				l1l11l111l1_l1_[l1l1ll1lll1_l1_] = l111l1ll11_l1_
			else: l1l11l111l1_l1_[l1l1ll1lll1_l1_] = l1l11ll1111_l1_[l1l1ll1lll1_l1_]
	if type not in list(l1l11l111l1_l1_.keys()): l1l11l111l1_l1_[type] = [l1lll11l111_l1_]
	l1l11l111l1_l1_ = str(l1l11l111l1_l1_)
	if PY3: l1l11l111l1_l1_ = l1l11l111l1_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㋂"))
	open(l1l1l1111l1_l1_,l1l111_l1_ (u"ࠪࡻࡧ࠭㋃")).write(l1l11l111l1_l1_)
	return
def l1lll1111l1_l1_(l1ll1lll1l_l1_,table,l1l1l11l1l1_l1_,data,l1l1l1l1l1l_l1_,l1l1ll1l1ll_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ㋄"))
	if cache==l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㋅") and l1l1l1l1l1l_l1_>l1l11l11111_l1_: l1l1l1l1l1l_l1_ = l1l11l11111_l1_
	if l1l1ll1l1ll_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l111llll_l1_ in range(len(l1l1l11l1l1_l1_)):
			text = pickle.dumps(data[l1l111llll_l1_])
			l1l11l11l11_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l11l1l1_l1_[l1l111llll_l1_],))
			l1l11ll1l_l1_.append((l1l1l1l1l1l_l1_+now,str(l1l1l11l1l1_l1_[l1l111llll_l1_]),l1l11l11l11_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l1l1111_l1_ = zlib.compress(text)
	try: conn,l1llll1lll_l1_ = l1l1llll11l_l1_(l1ll1lll1l_l1_)
	except: return
	while True:
		try:
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨ㋆"))
			break
		except: time.sleep(0.5)
	l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠧࡄࡔࡈࡅ࡙ࡋࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡑࡓ࡙ࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ㋇")+table+l1l111_l1_ (u"ࠨࠤࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠣ࠿ࠬ㋈"))
	if l1l1ll1l1ll_l1_:
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㋉")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㋊"),l1l11ll11_l1_)
		l1llll1lll_l1_.executemany(l1l111_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ㋋")+table+l1l111_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ㋌"),l1l11ll1l_l1_)
	else:
		if l1l1l1l1l1l_l1_:
			tt = (str(l1l1l11l1l1_l1_),)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㋍")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㋎"),tt)
			tt = (l1l1l1l1l1l_l1_+now,str(l1l1l11l1l1_l1_),l1l1l1l1111_l1_)
			l1llll1lll_l1_.execute(l1l111_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ㋏")+table+l1l111_l1_ (u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ㋐"),tt)
		else:
			tt = (l1l1l1l1111_l1_,str(l1l1l11l1l1_l1_))
			l1llll1lll_l1_.execute(l1l111_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣࠦࠬ㋑")+table+l1l111_l1_ (u"ࠫࠧࠦࡓࡆࡖࠣࡨࡦࡺࡡࠡ࠿ࠣࡃࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㋒"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if PY3: import urllib.parse as l1l1llll1l1_l1_
	else: import urllib as l1l1llll1l1_l1_
	l1ll11111ll_l1_ = l1l1llll1l1_l1_.urlencode(data)
	return l1ll11111ll_l1_
l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠬ࠭㋓")
def l1llll111_l1_(l1llllll_l1_,l1ll1ll1l11_l1_=l1l111_l1_ (u"࠭ࠧ㋔"),l1l1111l111_l1_=l1l111_l1_ (u"ࠧࠨ㋕")):
	l1l1l1ll1l1_l1_ = l1ll1ll1l11_l1_ not in [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㋖"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㋗")]
	global l1l1ll1llll_l1_
	if not l1l1111l111_l1_: l1l1111l111_l1_ = l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㋘")
	l1l1ll1llll_l1_,l1l11llllll_l1_,httpd = l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠶ࠧ㋙"),l1l111_l1_ (u"ࠬ࠭㋚"),l1l111_l1_ (u"࠭ࠧ㋛")
	if len(l1llllll_l1_)==3:
		url,l1l1l111111_l1_,httpd = l1llllll_l1_
		if l1l1l111111_l1_: l1l11llllll_l1_ = l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ㋜")+l1l1l111111_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㋝")
	else: url,l1l1l111111_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㋞"),l1l111_l1_ (u"ࠪࠫ㋟")
	url = url.replace(l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㋠"),l1l111_l1_ (u"ࠬࠦࠧ㋡"))
	l11ll1l1l1_l1_ = GET_VIDEOFILETYPE(url)
	if l1ll1ll1l11_l1_ not in [l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㋢"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㋣")]:
		if l1ll1ll1l11_l1_!=l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㋤"): url = url.replace(l1l111_l1_ (u"ࠩࠣࠫ㋥"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ㋦"))
		l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㋧"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡱ࡮ࡤࡽ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋨")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㋩")+l1l11llllll_l1_)
		if l11ll1l1l1_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㋪") and l1ll1ll1l11_l1_ not in [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㋫"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㋬")]:
			from LIBSTWO import l1l11l11ll_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l11ll_l1_(url)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ㋭")+str(count)+l1l111_l1_ (u"๋ࠫࠥไโࠫࠪ㋮"), l1l1lll1_l1_)
				if l11l11l_l1_==-1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ㋯"),l1l111_l1_ (u"࠭ࠧ㋰"))
					return l1l1ll1llll_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠧ࠮࠳ࠪ㋱"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㋲"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ㋳")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋴")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㋵"))
		if l1l111_l1_ (u"ࠬ࠵ࡩࡧ࡫࡯ࡱ࠴࠭㋶") in url: url = url+l1l111_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㋷")
		elif l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ㋸") in url.lower() and l1l111_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ㋹") not in url and l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ㋺") not in url:
			if l1l111_l1_ (u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࠨ㋻") not in url and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭㋼") in url.lower():
				if l1l111_l1_ (u"ࠬࢂࠧ㋽") not in url: url = url+l1l111_l1_ (u"࠭ࡼࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ㋾")
				else: url = url+l1l111_l1_ (u"ࠧࠧࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ㋿")
			if l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࠬ㌀") not in url.lower() and l1ll1ll1l11_l1_ not in [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㌁"),l1l111_l1_ (u"ࠪࡑ࠸࡛ࠧ㌂")]:
				if l1l111_l1_ (u"ࠫࢁ࠭㌃") not in url: url = url+l1l111_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠪࠬ㌄")
				else: url = url+l1l111_l1_ (u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㌅")
	l1l111111l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㌆"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌇")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㌈"))
	l1l1111llll_l1_ = xbmcgui.ListItem()
	l1l1111l111_l1_,l1l11ll1ll1_l1_,l1l1l11lll1_l1_,l1l111l11l1_l1_,l1l1ll11111_l1_,l1l1111l11l_l1_,l1l11ll1l1l_l1_,l1l11ll11ll_l1_,l1l1l1111ll_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll1ll1l11_l1_ not in [l1l111_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㌉"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㌊")]:
		if PY2: l1l111l1111_l1_ = l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࡤࡨࡩࡵ࡮ࠨ㌋")
		else: l1l111l1111_l1_ = l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠫ㌌")
		l1l1111llll_l1_.setProperty(l1l111l1111_l1_, l1l111_l1_ (u"ࠧࠨ㌍"))
		l1l1111llll_l1_.setMimeType(l1l111_l1_ (u"ࠨ࡯࡬ࡱࡪ࠵ࡸ࠮ࡶࡼࡴࡪ࠭㌎"))
		if kodi_version<20: l1l1111llll_l1_.setInfo(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㌏"),{l1l111_l1_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭㌐"):l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ㌑")})
		else:
			l1l1l111l1l_l1_ = l1l1111llll_l1_.getVideoInfoTag()
			l1l1l111l1l_l1_.setMediaType(l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ㌒"))
		l1l1111llll_l1_.setArt({l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ㌓"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧ㌔"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨ㌕"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ㌖"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬ㌗"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ㌘"):l1l1ll11111_l1_,l1l111_l1_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ㌙"):l1l1ll11111_l1_,l1l111_l1_ (u"࠭ࡩࡤࡱࡱࠫ㌚"):l1l1ll11111_l1_})
		if l11ll1l1l1_l1_ in [l1l111_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ㌛"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㌜")]: l1l1111llll_l1_.setContentLookup(True)
		else: l1l1111llll_l1_.setContentLookup(False)
		from l1l11lllll1_l1_ import l1l1l1lll1l_l1_
		if l1l111_l1_ (u"ࠩࡵࡸࡲࡶࠧ㌝") in url:
			l1l1l1lll1l_l1_(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭㌞"),False)
		elif l11ll1l1l1_l1_==l1l111_l1_ (u"ࠫ࠳ࡳࡰࡥࠩ㌟") or l1l111_l1_ (u"ࠬ࠵ࡤࡢࡵ࡫࠳ࠬ㌠") in url:
			l1l1l1lll1l_l1_(l1l111_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㌡"),False)
			l1l1111llll_l1_.setProperty(l1l111l1111_l1_,l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ㌢"))
			l1l1111llll_l1_.setProperty(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨ㌣"),l1l111_l1_ (u"ࠩࡰࡴࡩ࠭㌤"))
		if l1l1l111111_l1_:
			l1l1111llll_l1_.setSubtitles([l1l1l111111_l1_])
	if l1l1111l111_l1_==l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㌥") and l1ll1ll1l11_l1_==l1l111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㌦"):
		l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㌧")
		l1ll1ll1l11_l1_ = l1l111_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭㌨")
	elif l1l1111l111_l1_==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㌩") and l1l11ll11ll_l1_.startswith(l1l111_l1_ (u"ࠨ࠸ࠪ㌪")):
		l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㌫")
		l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"ࠪࡣࡉࡒࠧ㌬")
	if l1l1ll1llll_l1_!=l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㌭"): l1l1l1ll1ll_l1_()
	l1l11lll1l1_l1_ = l1l1l1l11l1_l1_()
	l1l11lll1l1_l1_.init(l1ll1ll1l11_l1_)
	if l1l11lll1l1_l1_.l1l1ll1llll_l1_: l1l1ll1llll_l1_ == l1l111_l1_ (u"ࠬ࠭㌮")
	elif l1l1111l111_l1_==l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㌯") and not l1l11ll11ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠷ࠩ㌰")):
		l1l1111llll_l1_.setPath(url)
		l1l111111l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㌱"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌲")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌳"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l1111llll_l1_)
	elif l1l1111l111_l1_==l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㌴"):
		l1l111111l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㌵"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌶")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㌷"))
		l1l11lll1l1_l1_.play(url,l1l1111llll_l1_)
	succeeded = False
	if l1l1ll1llll_l1_==l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㌸"):
		from l11lll1l1l_l1_ import l11lll11l1_l1_
		succeeded = l11lll11l1_l1_(url,l11ll1l1l1_l1_,l1ll1ll1l11_l1_)
		if succeeded: l1l1l1ll1ll_l1_()
	else:
		l1l11111lll_l1_,l1l1ll1llll_l1_,l1l1lllll1l_l1_,delay = 0,l1l111_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ㌹"),False,2
		if l1l1l1ll1l1_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l11111lll_l1_<30:
			l1l1ll1llll_l1_ = l1l11lll1l1_l1_.l1l1ll1llll_l1_
			if l1l1ll1llll_l1_==l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ㌺") and not l1l1lllll1l_l1_:
				if l1l1l1ll1l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์๋่ࠥอ๊าࠫ㌻"),l1l111_l1_ (u"ࠬ࠭㌼"),time=500)
				l1l111111l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㌽"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㌾")+url+l1l111_l1_ (u"ࠨࠢࡠࠫ㌿")+l1l11llllll_l1_)
				l1l1lllll1l_l1_ = True
			elif l1l1ll1llll_l1_ in [l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㍀"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㍁")]:
				l1l111111l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㍂"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡴࡱࡧࡹࡪࡰࡪࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㍃")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㍄")+l1l11llllll_l1_)
				break
			elif l1l1ll1llll_l1_==l1l111_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㍅"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㍆"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㍇")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㍈")+l1l11llllll_l1_)
				if l1l1l1ll1l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษࠨ㍉"),l1l111_l1_ (u"ࠬ࠭㍊"),time=500)
				break
			elif l1l1ll1llll_l1_==l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㍋"):
				l1l111111l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㍌"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉ࡫ࡶࡪࡥࡨࠤ࡮ࡹࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㍍")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㍎"))
				break
			xbmc.sleep(delay*1000)
			l1l11111lll_l1_ += delay
		else:
			if l1l1l1ll1l1_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠬ㍏"),l1l111_l1_ (u"ࠫࠬ㍐"),time=500)
			l1l111111l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㍑"),l11lllll1l_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡗ࡭ࡲ࡫࡯ࡶࡶ࠽ࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡰࡳࡱࡥࡰࡪࡳࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㍒")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㍓")+l1l11llllll_l1_)
			l1l1ll1llll_l1_ = l1l111_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ㍔")
	if l1l1ll1llll_l1_ in [l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㍕"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ㍖"),l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㍗")] or succeeded:
		if l1l1ll1llll_l1_==l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㍘"): l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_+l1l111_l1_ (u"࠭࡟ࡕࡕࠪ㍙")
		response = l1l1llllll1_l1_(l1ll1ll1l11_l1_)
	else: exec(l1l111_l1_ (u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧ㍚"))
	return l1l1ll1llll_l1_
def GET_VIDEOFILETYPE(url):
	l11ll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࡟࠲ࡦࡼࡩࡽ࡞࠱ࡸࡸࢂ࡜࠯ࡣࡤࡧࢁࡢ࠮࡮ࡲ࠷ࢀࡡ࠴࡭࠴ࡷࡿࡠ࠳ࡳ࠳ࡶ࠺ࡿࡠ࠳ࡳࡰࡥࡾ࡟࠲ࡲࡱࡶࡽ࡞࠱ࡪࡱࡼࡼ࡝࠰ࡰࡴ࠸ࢂ࡜࠯ࡹࡨࡦࡲ࠯ࠨࡽ࡞ࡂ࠲࠯ࡅࡼ࠰࡞ࡂ࠲࠯ࡅࡼ࡝ࡾ࠱࠮ࡄ࠯ࠤࠨ㍛"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11ll1l1l1_l1_: l11ll1l1l1_l1_ = l11ll1l1l1_l1_[0][0]
	else: l11ll1l1l1_l1_ = l1l111_l1_ (u"ࠩࠪ㍜")
	return l11ll1l1l1_l1_
WRITE_TO_sSQL3 = l1lll1111l1_l1_
READ_FROM_sSQL3 = l1lll11l1l1_l1_
DELETE_FROM_sSQL3 = l1lll1ll1l1_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lllll1l_l1_
LOGg_THIS = l1l111111l_l1_
PLAY_VIDEOo = l1llll111_l1_
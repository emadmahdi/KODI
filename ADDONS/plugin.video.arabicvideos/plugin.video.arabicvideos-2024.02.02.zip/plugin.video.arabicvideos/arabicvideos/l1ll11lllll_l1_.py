# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭⿐")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡋࡕࡘࡢࠫ⿑")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = []
def l11l1ll_l1_(mode,url,text):
	if   mode==810: l1lll_l1_ = l1l1l11_l1_()
	elif mode==811: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==812: l1lll_l1_ = PLAY(url)
	elif mode==813: l1lll_l1_ = l1ll11llll1_l1_(url)
	elif mode==819: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ⿒"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ⿓"),l1l111_l1_ (u"ࠨࠩ⿔"),l1l111_l1_ (u"ࠩࠪ⿕"),l1l111_l1_ (u"ࠪࠫ⿖"),l1l111_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⿗"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿘"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⿙"),l1l111_l1_ (u"ࠧࠨ⿚"),819,l1l111_l1_ (u"ࠨࠩ⿛"),l1l111_l1_ (u"ࠩࠪ⿜"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⿝"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⿞"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⿟"),l1l111_l1_ (u"࠭ࠧ⿠"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡵ࡭ࡲࡧࡲࡺ࠯࡯࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯ࠢ࡮ࡱࡶࡸ࠲ࡼࡩࡦࡹࡨࡨࠧ࠭⿡"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⿢"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿣"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⿤")+l1lllll_l1_+title,l1ll1ll_l1_,811)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ⿥")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⿦"),url,l1l111_l1_ (u"࠭ࠧ⿧"),l1l111_l1_ (u"ࠧࠨ⿨"),l1l111_l1_ (u"ࠨࠩ⿩"),l1l111_l1_ (u"ࠩࠪ⿪"),l1l111_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⿫"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ⿬"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿭"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ⿮"),title,re.DOTALL)
			if l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⿯") not in type and l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⿰") + l1l1lll_l1_[0][0]
				title = title.replace(l1l111_l1_ (u"ࠩส์๋ࠦไศ์้ࠫ⿱"),l1l111_l1_ (u"ࠪࠫ⿲"))
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿳"),l1lllll_l1_+title,l1ll1ll_l1_,813,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⿴"),l1lllll_l1_+title,l1ll1ll_l1_,812,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ࠭࠴ࠪࡀࠫࡩࡳࡴࡺࡥࡳࠤ⿵"),html,re.DOTALL)
	if l11llll_l1_:
		type = l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࡡࡳࡥ࡬࡫ࡳࠨ⿶") if l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⿷") in type else l1l111_l1_ (u"ࠩࡳࡥ࡬࡫ࡳࠨ⿸")
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⿹"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿺"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫ⿻")+title,l1ll1ll_l1_,811,l1l111_l1_ (u"࠭ࠧ⿼"),l1l111_l1_ (u"ࠧࠨ⿽"),type)
	return
def l1ll11llll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⿾"),url,l1l111_l1_ (u"ࠩࠪ⿿"),l1l111_l1_ (u"ࠪࠫ　"),l1l111_l1_ (u"ࠫࠬ、"),l1l111_l1_ (u"ࠬ࠭。"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓ࠮࠳ࡶࡸࠬ〃"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡸࡪ࡭࡯ࡳࡻࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ〄"),html,re.DOTALL)
	if l1ll1ll_l1_: l1lll11_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ々"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡂࡨࡴࡃࡷࡢࡶࡦ࡬ࠬ〆")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ〇"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ〈"),l1l111_l1_ (u"ࠬ࠭〉"),l1l111_l1_ (u"࠭ࠧ《"),l1l111_l1_ (u"ࠧࠨ》"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ「"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ」"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ『"),url,l1l111_l1_ (u"ࠫࠬ』"),l1l111_l1_ (u"ࠬ࠭【"),l1l111_l1_ (u"࠭ࠧ】"),l1l111_l1_ (u"ࠧࠨ〒"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ〓"))
		html = response.content
		l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࡳࡳࡸࡺ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ〔"),html,re.DOTALL)
		if l1ll11l_l1_:
			l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
			if PY3: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ〕"))
			l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ〖"),l1ll11l_l1_)
			l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭〗")]
			l11l11_l1_ = list(l1ll_l1_.keys())
			l1ll_l1_ = list(l1ll_l1_.values())
			l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
			for title,l1ll1ll_l1_ in l1lll1l_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ〘")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ〙")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ〚"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪ〛"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫ〜"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭〝"),l1l111_l1_ (u"ࠬ࠱ࠧ〞"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡵࡀࠫ〟")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ〠"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᢀ")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧᢁ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩๅ๊ํอสࠡใูหห๐ษࠨᢂ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==470: l1lll_l1_ = l1l1l11_l1_()
	elif mode==471: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==472: l1lll_l1_ = PLAY(url)
	elif mode==473: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==474: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==479: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᢃ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬᢄ"),l1l111_l1_ (u"ࠬ࠭ᢅ"),l1l111_l1_ (u"࠭ࠧᢆ"),l1l111_l1_ (u"ࠧࠨᢇ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᢈ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᢉ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠪ࠳ࠬᢊ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᢋ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᢌ"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᢍ"),l1l111_l1_ (u"ࠧࠨᢎ"),479,l1l111_l1_ (u"ࠨࠩᢏ"),l1l111_l1_ (u"ࠩࠪᢐ"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᢑ"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᢒ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᢓ"),l1l111_l1_ (u"࠭ࠧᢔ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢕ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᢖ")+l1lllll_l1_+l1l111_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧᢗ"),l1l11ll_l1_,471,l1l111_l1_ (u"ࠪࠫᢘ"),l1l111_l1_ (u"ࠫࠬᢙ"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᢚ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᢛ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬᢜ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠨࠢࠣࠫᢝ"),l1l111_l1_ (u"ࠩࠪᢞ")).strip(l1l111_l1_ (u"ࠪࠤࠬᢟ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡨࡧࡴ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳ࠲ࠩᢠ"),l1l111_l1_ (u"ࠬࡩࡡࡵ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴࠩᢡ"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢢ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᢣ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᢤ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᢥ"),l1l111_l1_ (u"ࠪࠫᢦ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᢧ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥᢨ"),html,re.DOTALL)
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁᢩࠫ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧᢪ") in title: continue
		if l1l111_l1_ (u"ࠨสิ๊ฬ๋ฬࠡࠩ᢫") in title: continue
		if l1l111_l1_ (u"ࠩ็่่ฮวาࠩ᢬") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᢭"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᢮")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ᢯"),url,l1l111_l1_ (u"࠭ࠧᢰ"),l1l111_l1_ (u"ࠧࠨᢱ"),l1l111_l1_ (u"ࠨࠩᢲ"),l1l111_l1_ (u"ࠩࠪᢳ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᢴ"))
	html = response.content
	if l1l111_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫᢵ") in url: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠩᢶ"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᢷ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᢸ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࠨᢹ") in l1ll1ll_l1_:
				if l1l111_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡪࡴࡧ࡭࡫ࡶ࡬࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᢺ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠶࠭ᢻ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃ࡭ࡪࡵࡦࠫᢼ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡵࡸ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫᢽ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"࠭ๅ็าࠣห้ฮฯศ์ฬࠫᢾ") in title and l1l111_l1_ (u"ࠧࡥࡱࡀࡶࡦࡺࡩ࡯ࡩࠪᢿ") not in l1ll1ll_l1_: continue
			else: title = l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠษษึฮำีวๆ࠼ࠣࠤࠬᣀ")+title
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᣁ"),l1lllll_l1_+title,l1ll1ll_l1_,471)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠪࠫᣂ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᣃ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᣄ"),url,l1l111_l1_ (u"࠭ࠧᣅ"),l1l111_l1_ (u"ࠧࠨᣆ"),l1l111_l1_ (u"ࠨࠩᣇ"),l1l111_l1_ (u"ࠩࠪᣈ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᣉ"))
	html = response.content
	items = []
	if request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᣊ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯ࡩࡰࡺ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᣋ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪᣌ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᣍ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪᣎ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᣏ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l1111l11l_l1_ = zip(*items)
		items = zip(l1111l11l_l1_,l1ll_l1_,l11l11_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣐ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫᣑ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲࡭ࡲࡪࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᣒ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣓ"),html,re.DOTALL)
		if not l11llll_l1_: return
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᣔ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᣕ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩᣖ"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨᣗ"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪᣘ"),l1l111_l1_ (u"้ࠬไ๋สࠪᣙ"),l1l111_l1_ (u"࠭วฺๆส๊ࠬᣚ"),l1l111_l1_ (u"่ࠧัสๅࠬᣛ"),l1l111_l1_ (u"ࠨ็หหึอษࠨᣜ"),l1l111_l1_ (u"ࠩ฼ี฻࠭ᣝ"),l1l111_l1_ (u"้ࠪ์ืฬศ่ࠪᣞ"),l1l111_l1_ (u"ࠫฬ๊ศ้็ࠪᣟ"),l1l111_l1_ (u"๋ࠬำาฯํอࠬᣠ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"࠭࠯ࠨᣡ"))
		title = title.replace(l1l111_l1_ (u"ࠧๆษํࠤุ๐ๅศࠩᣢ"),l1l111_l1_ (u"ࠨࠩᣣ")).replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠩᣤ"),l1l111_l1_ (u"ࠪࠫᣥ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᣦ")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨᣧ"),l1l111_l1_ (u"࠭ࠠࠨᣨ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬᣩ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪᣪ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫᣫ"))
		if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᣬ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠫ࠴࠭ᣭ")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠬ࠵ࠧᣮ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩᣯ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᣰ")+title
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᣱ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩᣲ") in title:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᣳ")+l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᣴ"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪᣵ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᣶"),l1lllll_l1_+title,l1ll1ll_l1_,471,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᣷"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪ᣸"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ᣹")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᣺"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᣻"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ᣼"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ᣽")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ᣾"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᣿"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨᤀ")+title,l1ll1ll_l1_,471)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷ࡭ࡵࡷ࡮ࡱࡵࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᤁ"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤂ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬิศ้าอࠥอไๆิํำࠬᤃ"),l1ll1ll_l1_,471)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪᤄ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᤅ"),url,l1l111_l1_ (u"ࠨࠩᤆ"),l1l111_l1_ (u"ࠩࠪᤇ"),l1l111_l1_ (u"ࠪࠫᤈ"),l1l111_l1_ (u"ࠫࠬᤉ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧᤊ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᤋ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࠬᤌ")+l1l11_l1_+l1l111_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᤍ"),html,re.DOTALL)
	items = []
	if l11ll1l_l1_ and not l1l11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᤎ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸࡡ࠲ࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧᤏ"),block,re.DOTALL)
		for l1l11_l1_,title in items: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤐ"),l1lllll_l1_+title,url,473,l1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭ᤑ"),l1l11_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᤒ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠢࡵ࡫ࡷࡰࡪࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠠࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᤓ"),block,re.DOTALL)
		if items:
			for title,l1ll1ll_l1_ in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪᤔ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫᤕ"))
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᤖ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬᤗ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᤘ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨᤙ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩᤚ"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᤛ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
	if l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠫᤜ") in html:
		if items: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᤝ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᤞ"),l1l111_l1_ (u"ࠬ࠭᤟"),9999)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤠ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊สฺ๏฿ࠠัษอࠤฺ๊ษࠨᤡ"),url,471)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᤢ"),url,l1l111_l1_ (u"ࠩࠪᤣ"),l1l111_l1_ (u"ࠪࠫᤤ"),l1l111_l1_ (u"ࠫࠬᤥ"),l1l111_l1_ (u"ࠬ࠭ᤦ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᤧ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡦ࡬ࡺࠥ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠾ࠩ࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠫᤨ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧᤩ"),block,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,True): return
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ᤪ"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭ᤫ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ᤬"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭᤭"),l1l111_l1_ (u"࠭ࠧ᤮"),l1l111_l1_ (u"ࠧࠨ᤯"),l1l111_l1_ (u"ࠨࠩᤰ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧᤱ"))
	html = response.content
	l1llllllll_l1_ = []
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡖࡑࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᤲ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ and l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬᤳ")
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᤴ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᤵ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠢ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠥᤶ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l1llllllll_l1_:
			l1llllllll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᤷ")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᤸ")
			if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ᤹") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ᤺")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱ᤻ࠩ"),l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱ࡴ࡭ࡶࠧ᤼"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ᤽"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ᤾"),l1l111_l1_ (u"ࠩࠪ᤿"),l1l111_l1_ (u"ࠪࠫ᥀"),l1l111_l1_ (u"ࠫࠬ᥁"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ᥂"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᥃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ᥄"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l1llllllll_l1_:
				l1llllllll_l1_.append(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ᥅")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭᥆")
				if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ᥇") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ᥈")+l1ll1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᥉"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ᥊"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ᥋"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ᥌"),l1l111_l1_ (u"ࠩ࠮ࠫ᥍"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ᥎")+search
	l1lll11_l1_(url)
	return
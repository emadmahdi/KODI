# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ嗬")
headers = l1l111_l1_ (u"ࠪࠫ嗭")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡙ࡈ࠵ࡡࠪ嗮")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ嗯"),l1l111_l1_ (u"࠭วๅๅ็ࠫ嗰"),l1l111_l1_ (u"ࠧศใ็ห๊࠭嗱"),l1l111_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ嗲"),l1l111_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭嗳")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ嗴")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ嗵")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嗶"),l111l1_l1_,l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ嗷"),l1l111_l1_ (u"ࠧีษ๊ำࠥ็่า์๋ࠤ࠲ࠦࡓࡩࡣ࡫࡭ࡩࠦ࠴ࡶࠩ嗸"),l1l111_l1_ (u"ࠨࡨࡤࡧࡪࡨ࡯ࡰ࡭࠱ࡧࡴࡳ࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰ࡱࡩࡹ࠭嗹"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嗺"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ嗻"),l1l111_l1_ (u"ࠫࠬ嗼"),119,l1l111_l1_ (u"ࠬ࠭嗽"),l1l111_l1_ (u"࠭ࠧ嗾"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ嗿"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘀"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ嘁"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘂"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ嘃"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嘄"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嘅"),l1l111_l1_ (u"ࠧࠨ嘆"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘇"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ嘈"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠪࠫ嘉"),l1l111_l1_ (u"ࠫࠬ嘊"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ嘋"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠧ嘌"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ嘍"),l1l111_l1_ (u"ࠨࠩ嘎"),l1l111_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫ嘏"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭嘐"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࠽ࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嘑"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嘒"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ嘓")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ嘔"),filter)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嘕"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嘖"),l1l111_l1_ (u"ࠪࠫ嘗"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡩࡸ࡯ࡱࡦࡲࡻࡳࠨࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭嘘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嘙"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ嘚"),l1l111_l1_ (u"ࠧࠨ嘛")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ嘜"),l1l111_l1_ (u"ࠩࠪ嘝")).strip(l1l111_l1_ (u"ࠪࠤࠬ嘞"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嘟") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭嘠") in l1ll1ll_l1_: title = l1l111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ嘡")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘢"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嘣")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪ嘤"),response=l1l111_l1_ (u"ࠪࠫ嘥")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嘦"),url,l1l111_l1_ (u"ࠬ࠭嘧"),headers,l1l111_l1_ (u"࠭ࠧ嘨"),l1l111_l1_ (u"ࠧࠨ嘩"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ嘪"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ嘫"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡫ࡱ࡯ࡤࡦࡡࡢࡷࡱ࡯ࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嘬"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ嘭"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬ嘮"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭嘯"),l1l111_l1_ (u"ࠧโ์็้ࠬ嘰"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ嘱"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ嘲"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ嘳"),l1l111_l1_ (u"ࠫ์ีวโࠩ嘴"),l1l111_l1_ (u"๋ࠬศศำสอࠬ嘵"),l1l111_l1_ (u"ู࠭าุࠪ嘶"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ嘷"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ嘸")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠩ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹ࠭嘹") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬ嘺"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭嘻"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ嘼"),title,re.DOTALL)
		if l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭嘽") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧโ์็้ࠬ嘾") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嘿"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ噀") in title and l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ噁") not in url:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ噂") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ噃"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧ噄") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ噅"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ噆") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ噇") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ噈")
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ噉"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ噊") in url and l1l111_l1_ (u"࠭อๅไฬࠫ噋") in title:
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭噌"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噍"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ噎"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ噏"): items = re.findall(l1l111_l1_ (u"ࠫ࠭ࡻࡰࡥࡣࡷࡩࡖࡻࡥࡳࡻࠬ࠲࠯ࡅ࠾ࠩ࠰࠮ࡃ࠮ࡂࠧ噐"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ噑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭噒"):
				title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ噓"),l1l111_l1_ (u"ࠨࠩ噔")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ噕"),l1l111_l1_ (u"ࠪࠫ噖"))
				if l1l111_l1_ (u"ࠫࡄ࠭噗") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ噘")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"࠭࠿ࡱࡣࡪࡩࡂ࠭噙")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ噚"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ噛")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠩࠪ噜"),l1l111_l1_ (u"ࠪࠫ噝"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l11l1l11ll1l_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ噞"),url,l1l111_l1_ (u"ࠬ࠭噟"),headers,l1l111_l1_ (u"࠭ࠧ噠"),l1l111_l1_ (u"ࠧࠨ噡"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ噢"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠡࡦ࠰ࡪࡱ࡫ࡸࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ噣"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ噤") in l11llll_l1_[0]: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111lllll1_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l111llll_l1_ in range(2):
		if l11l1l11ll1l_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ噥"),l111lllll1_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ噦"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭噧"),block,re.DOTALL)
		if l11l1l11ll1l_l1_ and len(items)<2:
			l11l1l11ll1l_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"ࠧࠡࠩ器")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ噩") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡶࡪࡧࡤࡤࡴࡸࡱࡧࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ噪"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ噫"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ噬")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ噭"),url,l1l111_l1_ (u"࠭ࠧ噮"),headers,l1l111_l1_ (u"ࠧࠨ噯"),l1l111_l1_ (u"ࠨࠩ噰"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭噱"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡨࡺࡩࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ噲"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ噳"),block,re.DOTALL)
	l11l1l11lll1_l1_ = l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭噴") in block
	download = l1l111_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ噵") in block
	if   l11l1l11lll1_l1_ and not download: l11l1l11llll_l1_,l11l1l11ll11_l1_ = l1ll_l1_[0],l1l111_l1_ (u"ࠧࠨ噶")
	elif not l11l1l11lll1_l1_ and download: l11l1l11llll_l1_,l11l1l11ll11_l1_ = l1l111_l1_ (u"ࠨࠩ噷"),l1ll_l1_[0]
	elif l11l1l11lll1_l1_ and download: l11l1l11llll_l1_,l11l1l11ll11_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l11l1l11llll_l1_,l11l1l11ll11_l1_ = l1l111_l1_ (u"ࠩࠪ噸"),l1l111_l1_ (u"ࠪࠫ噹")
	if l11l1l11lll1_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ噺"),l11l1l11llll_l1_,l1l111_l1_ (u"ࠬ࠭噻"),headers,l1l111_l1_ (u"࠭ࠧ噼"),l1l111_l1_ (u"ࠧࠨ噽"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ噾"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡯ࡩࡹࠦࡳࡦࡴࡹࡩࡷࡹࠨ࠯ࠬࡂ࠭ࡵࡲࡡࡺࡧࡵࠫ噿"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嚀"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫࡡࡢ࠯ࠨ嚁"),l1l111_l1_ (u"ࠬ࠵ࠧ嚂"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ嚃")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ嚄")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嚅"),l11l1l11ll11_l1_,l1l111_l1_ (u"ࠩࠪ嚆"),headers,l1l111_l1_ (u"ࠪࠫ嚇"),l1l111_l1_ (u"ࠫࠬ嚈"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ嚉"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯ࡩ࡯ࡨࡲ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠧ嚊"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嚋"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ嚌")+title+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭嚍")+l1l111_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ嚎")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嚏"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ嚐"),l1l111_l1_ (u"࠭ࠫࠨ嚑"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ嚒")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lllll1l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ嚓"),url,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ嚔"),l1l111_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ嚕"),l1l111_l1_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵࠩ嚖"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嚗"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ嚘"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嚙"),url,l1l111_l1_ (u"ࠨࠩ嚚"),headers,l1l111_l1_ (u"ࠩࠪ嚛"),l1l111_l1_ (u"ࠪࠫ嚜"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ嚝"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡩࡱࡺࡷ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ嚞"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡗࡵࡦࡴࡼࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࠫ嚟"),block,re.DOTALL)
		l1111l111_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111l111_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࡠࡸ࠰ࠨ࠯ࠬࡂ࠭ࡡࡹࠪ࠽ࠩ嚠"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	if l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嚡") not in url: url = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭嚢")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚣"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ嚤"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嚥"),l1l111_l1_ (u"࠭࠯ࡀࠩ嚦"))
	return url
l1111l1l1_l1_ = [l1l111_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ嚧"),l1l111_l1_ (u"ࠨࡻࡨࡥࡷ࠭嚨"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ嚩"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ嚪")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭嚫"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ嚬"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ嚭")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ嚮"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ嚯"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ嚰"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ嚱"),l1l111_l1_ (u"ࠫࠬ嚲")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ嚳"))
	if type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ嚴"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠧ࠾ࠩ嚵") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࠪ嚶") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ嚷")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭嚸")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭嚹")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨ嚺")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ嚻"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嚼")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ嚽"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ嚾"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嚿")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ囀"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ囁"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ囂"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ囃"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ囄"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭囅")+l11lll11_l1_
		l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囆"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ囇"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ囈"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭囉")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭囊"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囋"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ囌"),l1l111_l1_ (u"ࠪࠫ囍"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"่๊ࠫࠠࠨ囎"),l1l111_l1_ (u"ࠬ࠭囏"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"࠭࠽ࠨ囐") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ囑"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ囒")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囓"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ囔"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囕"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭囖"),l1lllll1_l1_,115,l1l111_l1_ (u"࠭ࠧ囗"),l1l111_l1_ (u"ࠧࠨ囘"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭囙"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ囚")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭四")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭囜")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ囝")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ回")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囟"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ因")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠩࠪ囡"),l1l111_l1_ (u"ࠪࠫ团"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ団"): option = l1l111_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ囤")
			elif value==l1l111_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭囥"): option = l1l111_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ囦")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ囧")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ囨")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ囩")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠭囪")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ囫")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ囬")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠧ࠱ࠩ园")]
			title = option+l1l111_l1_ (u"ࠨࠢ࠽ࠫ囮")+name
			if type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ囯"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ困"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠫࠬ囱"),l1l111_l1_ (u"ࠬ࠭囲"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ図") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠧ࠾ࠩ围") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ囵"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭囶")+l11ll111_l1_
				l1llllll_l1_ = l11111lll_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囷"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囸"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠬ࠭囹"),l1l111_l1_ (u"࠭ࠧ固"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠧ࠾ࠨࠪ囻"),l1l111_l1_ (u"ࠨ࠿࠳ࠪࠬ囼"))
	filters = filters.strip(l1l111_l1_ (u"ࠩࠩࠫ国"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠪࡁࠬ图") in filters:
		items = filters.split(l1l111_l1_ (u"ࠫࠫ࠭囿"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ圀"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"࠭ࠧ圁")
	for key in l1111l1l1_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠧ࠱ࠩ圂")
		if l1l111_l1_ (u"ࠨࠧࠪ圃") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ圄") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ圅"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ圆")+value
		elif mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ圇") and value!=l1l111_l1_ (u"࠭࠰ࠨ圈"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠩ圉")+key+l1l111_l1_ (u"ࠨ࠿ࠪ圊")+value
		elif mode==l1l111_l1_ (u"ࠩࡤࡰࡱ࠭國"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠬ圌")+key+l1l111_l1_ (u"ࠫࡂ࠭圍")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠦࠫࠡࠩ圎"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ圏"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠧ࠾࠲ࠪ圐"),l1l111_l1_ (u"ࠨ࠿ࠪ圑"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l1111_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1111_l1_ (l1_l1_):
    global l1l1ll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l11lll_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l111l_l1_ % len (l11lll_l1_)
    l1ll1_l1_ = l11lll_l1_ [:l1lll_l1_] + l11lll_l1_ [l1lll_l1_:]
    if l1l1111_l1_:
        l1l1lll_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l11l_l1_ + l111l_l1_) % l1l11_l1_) for l1l11l_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1lll_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l11l_l1_ + l111l_l1_) % l1l11_l1_) for l1l11l_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1lll_l1_)
from l1l1l1_l1_ import *
LOG_THIS(l1111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ嘈"),l1111_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠨ嘉"))
l1ll11l11_l1_(l1111_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ嘊"))
try: l111l1l_l1_()
except Exception as error: l11l1111111_l1_(error)
l1ll11l11_l1_(l1111_l1_ (u"ࠬࡹࡴࡰࡲࠪ嘋"))
l11l11lllll1_l1_ = settings.getSetting(l1111_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ嘌"))
l111l1ll1ll1_l1_ = xbmc.executeJSONRPC(l1111_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ嘍"))
if l1111_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ嘎") in str(l111l1ll1ll1_l1_) and l11l11lllll1_l1_ in [l1111_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ嘏"),l1111_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ嘐")]:
	#l1ll1l1_l1_(l1111_l1_ (u"ࠫࠬ嘑"),l11l11lllll1_l1_)
	time.sleep(0.100)
	xbmc.executebuiltin(l1111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩ嘒"))
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㊉")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ㊊")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllllll_l1_ = l1ll11l_l1_[script_name][1]
l1l11ll1ll1_l1_ = l1ll11l_l1_[script_name][2]
l1l11lll111_l1_ = l1ll11l_l1_[script_name][3]
#l1l11lllll1_l1_  = l1ll11l_l1_[script_name][4]
#l1l11lllll1_l1_  = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==20: results = l1l11lll11l_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==23: results = l1llllll_l1_(url,l1l11l1_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l11l1ll1l_l1_(url)
	elif mode==27: results = l1l1lll1l_l1_(url)
	elif mode==28: results = l1l11llll11_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l11lll11l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㊋"),l111ll_l1_+l11lll_l1_ (u"ࠫ฾ืศ๋ࠩ㊌"),l11ll1_l1_,21,l11lll_l1_ (u"ࠬ࠭㊍"),l11lll_l1_ (u"࠭࠱࠱࠳ࠪ㊎"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊏"),l111ll_l1_+l11lll_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ㊐"),l11lllllll_l1_,21,l11lll_l1_ (u"ࠩࠪ㊑"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㊒"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊓"),l111ll_l1_+l11lll_l1_ (u"ࠬ็วาี์ࠫ㊔"),l1l11ll1ll1_l1_,21,l11lll_l1_ (u"࠭ࠧ㊕"),l11lll_l1_ (u"ࠧ࠲࠲࠴ࠫ㊖"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊗"),l111ll_l1_+l11lll_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ㊘"),l1l11lll111_l1_,21,l11lll_l1_ (u"ࠪࠫ㊙"),l11lll_l1_ (u"ࠫ࠶࠶࠱ࠨ㊚"))
	return
def l1l11llll11_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ㊛"),l111ll_l1_+l11lll_l1_ (u"ู࠭าสํࠫ㊜"),l11ll1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㊝"),l111ll_l1_+l11lll_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ㊞"),l11lllllll_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㊟"),l111ll_l1_+l11lll_l1_ (u"ࠪๅฬืำ๊ࠩ㊠"),l1l11ll1ll1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㊡"),l111ll_l1_+l11lll_l1_ (u"ࠬ็วาี์ࠤ࠷࠭㊢"),l1l11lll111_l1_,27)
	return
def MENU(l1l11llll1l_l1_):
	script_name = l1l11llll1l_l1_
	if l1l11llll1l_l1_==l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ㊣"): l1l11llll1l_l1_ = l11ll1_l1_
	elif l1l11llll1l_l1_==l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ㊤"): l1l11llll1l_l1_ = l11lllllll_l1_
	else: script_name = l11lll_l1_ (u"ࠨࠩ㊥")
	l1l1llll1l1_l1_ = l1l11llllll_l1_(l1l11llll1l_l1_)
	if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠩࡤࡶࠬ㊦") or script_name==l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㊧"):
		l1l11l1llll_l1_ = l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㊨")
		l1l11l1lll1_l1_ = l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡฯส่๏ฯࠧ㊩")
		l1ll111l111_l1_ = l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢฦัิัࠧ㊪")
		l1l11ll1111_l1_ = l11lll_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣวอาฯ๋ࠩ㊫")
		l1l11ll11l1_l1_ = l11lll_l1_ (u"ࠨสฮࠤา๐ࠠร์ࠣๅ๏๊ๅࠨ㊬")
		l1l11ll111l_l1_ = l11lll_l1_ (u"ࠩฦๅ้อๅࠨ㊭")
		l1l11ll1l11_l1_ = l11lll_l1_ (u"้ࠪํู๊ใ๋ࠪ㊮")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠫอืวๆฮࠪ㊯")
	elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㊰") or script_name==l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㊱"):
		l1l11l1llll_l1_ = l11lll_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡪࡰࠣࡷ࡮ࡺࡥࠨ㊲")
		l1l11l1lll1_l1_ = l11lll_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡇࡺࡸࡲࡦࡰࡷࠫ㊳")
		l1ll111l111_l1_ = l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡑࡧࡴࡦࡵࡷࠫ㊴")
		l1l11ll1111_l1_ = l11lll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡇ࡬ࡱࡪࡤࡦࡪࡺࠧ㊵")
		l1l11ll11l1_l1_ = l11lll_l1_ (u"ࠫࡑ࡯ࡶࡦࠢ࡬ࡊ࡮ࡲ࡭ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠩ㊶")
		l1l11ll111l_l1_ = l11lll_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࡷࠬ㊷")
		l1l11ll1l11_l1_ = l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ㊸")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠧࡔࡪࡲࡻࡸ࠭㊹")
	elif l1l1llll1l1_l1_ in [l11lll_l1_ (u"ࠨࡨࡤࠫ㊺"),l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㊻")]:
		l1l11l1llll_l1_ = l11lll_l1_ (u"ࠪะุะฬ้ࠢาีูࠥวໍฬࠪ㊼")
		l1l11l1lll1_l1_ = l11lll_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥาวา໎ࠪ㊽")
		l1ll111l111_l1_ = l11lll_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦยฯำ໏๊ࠬ㊾")
		l1l11ll1111_l1_ = l11lll_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠศๆไฬฬ࠭㊿")
		l1l11ll11l1_l1_ = l11lll_l1_ (u"ࠧ๿ะืࠤื์ฯ่ࠢส๎ࠥ็๊ๅ็ࠪ㋀")
		l1l11ll111l_l1_ = l11lll_l1_ (u"ࠨใํ่๊࠭㋁")
		l1l11ll1l11_l1_ = l11lll_l1_ (u"่ࠩ์ุ๐โ๊ࠩ㋂")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬ࠭㋃")
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋄"),l111ll_l1_+l1l11l1llll_l1_,l1l11llll1l_l1_,29,l11lll_l1_ (u"ࠬ࠭㋅"),l11lll_l1_ (u"࠭ࠧ㋆"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㋇"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㋈"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㋉")+l111ll_l1_+l1l11ll11l1_l1_,l1l11llll1l_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㋊"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㋋"),l11lll_l1_ (u"ࠬ࠭㋌"),9999)
	menu = [l11lll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭㋍"),l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㋎"),l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㋏")]
	html = OPENURL_CACHED(l11111l_l1_,l1l11llll1l_l1_+l11lll_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ㋐"),l11lll_l1_ (u"ࠪࠫ㋑"),l11lll_l1_ (u"ࠫࠬ㋒"),l11lll_l1_ (u"ࠬ࠭㋓"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㋔"))
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠲ࡇࡴࡴࡴࡢࡥࡷࠫ㋕"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㋖"),block,re.DOTALL)
		for link,title in items:
			if any(value in link for value in menu):
				url = l1l11llll1l_l1_+link
				if l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ㋗") in link:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋘"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㋙")+l111ll_l1_+l1l11l1lll1_l1_,url,22,l11lll_l1_ (u"ࠬ࠭㋚"),l11lll_l1_ (u"࠭࠱࠱࠲ࠪ㋛"))
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋜"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㋝")+l111ll_l1_+l1ll111l111_l1_,url,22,l11lll_l1_ (u"ࠩࠪ㋞"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㋟"))
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋠"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㋡")+l111ll_l1_+l1l11ll1111_l1_,url,22,l11lll_l1_ (u"࠭ࠧ㋢"),l11lll_l1_ (u"ࠧ࠳࠲࠴ࠫ㋣"))
				elif l11lll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭㋤") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋥"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㋦")+l111ll_l1_+l1l11ll111l_l1_,url,22,l11lll_l1_ (u"ࠫࠬ㋧"),l11lll_l1_ (u"ࠬ࠷࠰࠱ࠩ㋨"))
				elif l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ㋩") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋪"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㋫")+l111ll_l1_+l1l11ll1l11_l1_,url,25,l11lll_l1_ (u"ࠩࠪ㋬"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㋭"))
				elif l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㋮") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋯"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㋰")+l111ll_l1_+l1l11ll11ll_l1_,url,22,l11lll_l1_ (u"ࠧࠨ㋱"),l11lll_l1_ (u"ࠨ࠳࠳࠵ࠬ㋲"))
	return html
def l1l11l1ll1l_l1_(url):
	l1l11llll1l_l1_ = l1l11ll1l1l_l1_(url)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ㋳"),l11lll_l1_ (u"ࠪࠫ㋴"),l11lll_l1_ (u"ࠫࠬ㋵"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡒ࡛ࡓࡊࡅࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㋶"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧ࠲ࡺ࡯ࡰ࡮ࡶ࠱࡭࡫ࡡࡥࡧࡵࠬ࠳࠰࠿ࠪࡏࡸࡷ࡮ࡩ࠭ࡣࡱࡧࡽࠬ㋷"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭㋸"),block,re.DOTALL)[0]
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋹"),l111ll_l1_+title,url,22,l11lll_l1_ (u"ࠩࠪ㋺"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㋻"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㋼"),block,re.DOTALL)
	for link,title in items:
		link = l1l11llll1l_l1_ + link
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋽"),l111ll_l1_+title,link,23,l11lll_l1_ (u"࠭ࠧ㋾"),l11lll_l1_ (u"ࠧ࠲࠲࠴ࠫ㋿"))
	return
def l1111l_l1_(url,l1l11l1_l1_):
	l1l11llll1l_l1_ = l1l11ll1l1l_l1_(url)
	l1l1llll1l1_l1_ = l1l11llllll_l1_(url)
	type = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ㌀"))[-1]
	l1l11l1l1l1_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㌁"),l11lll_l1_ (u"ࠪࠫ㌂"),url, type)
	if type==l11lll_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ㌃") and l1l11l1_l1_==l11lll_l1_ (u"ࠬ࠶ࠧ㌄"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㌅"),l11lll_l1_ (u"ࠧࠨ㌆"),l11lll_l1_ (u"ࠨࠩ㌇"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ㌈"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸ࡯ࡸࠩ㌉"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠫ࠲࠯ࡅࠩ࠿࠰࠭ࡃ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㌊"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			link = l1l11llll1l_l1_ + link
			l1llll_l1_ = l1l11llll1l_l1_ + QUOTE(l1llll_l1_)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㌋"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1l1l1_l1_+l11lll_l1_ (u"࠭࠰࠲ࠩ㌌"))
	l1l11l1l1ll_l1_=0
	if type==l11lll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ㌍"): category=l11lll_l1_ (u"ࠨ࠵ࠪ㌎")
	if type==l11lll_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ㌏"): category=l11lll_l1_ (u"ࠪ࠹ࠬ㌐")
	if type==l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㌑"): category=l11lll_l1_ (u"ࠬ࠽ࠧ㌒")
	if type in [l11lll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭㌓"),l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㌔"),l11lll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭㌕")] and l1l11l1_l1_!=l11lll_l1_ (u"ࠩ࠳ࠫ㌖"):
		l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡌࡸࡪࡳ࠿ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ㌗")+category+l11lll_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ㌘")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾ࠩ㌙")+l1l11l1l1l1_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㌚"),l11lll_l1_ (u"ࠧࠨ㌛"),l11lll_l1_ (u"ࠨࠩ㌜"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ㌝"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㌞"),l11lll_l1_ (u"ࠫࠬ㌟"),l11l11l_l1_, html)
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠯ࡄࠨࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㌠"),html,re.DOTALL)
		for id,title,l1llll_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"࠭࡜࡝ࠩ㌡"),l11lll_l1_ (u"ࠧࠨ㌢"))
			title = title.replace(l11lll_l1_ (u"ࠨࠤࠪ㌣"),l11lll_l1_ (u"ࠩࠪ㌤"))
			l1l11l1l1ll_l1_ += 1
			link = l1l11llll1l_l1_ + l11lll_l1_ (u"ࠪ࠳ࠬ㌥") + type + l11lll_l1_ (u"ࠫ࠴ࡉ࡯࡯ࡶࡨࡲࡹ࠵ࠧ㌦") + id
			l1llll_l1_ = l1l11llll1l_l1_ + QUOTE(l1llll_l1_)
			if type==l11lll_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ㌧"): addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㌨"),l111ll_l1_+title,link,24,l1llll_l1_,l1l11l1l1l1_l1_+l11lll_l1_ (u"ࠧ࠱࠳ࠪ㌩"))
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㌪"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1l1l1_l1_+l11lll_l1_ (u"ࠩ࠳࠵ࠬ㌫"))
	if type==l11lll_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ㌬"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l11llll1l_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡎࡴࡤࡦࡺࡂࡴࡦ࡭ࡥ࠾ࠩ㌭")+l1l11l1_l1_,l11lll_l1_ (u"ࠬ࠭㌮"),l11lll_l1_ (u"࠭ࠧ㌯"),l11lll_l1_ (u"ࠧࠨ㌰"),l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠴ࡴࡧࠫ㌱"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠳ࡤࡦ࡯ࡲࠬ࠳࠰࠿ࠪࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠲ࡪࡥ࡮ࡱࠪ㌲"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ㌳"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			l1l11l1l1ll_l1_ += 1
			l1llll_l1_ = l1l11llll1l_l1_ + l1llll_l1_
			link = l1l11llll1l_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌴"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㌵"))
	if l1l11l1l1ll_l1_>20:
		title=l11lll_l1_ (u"࠭ีโฯฬࠤࠬ㌶")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠧࡦࡰࠪ㌷"): title = l11lll_l1_ (u"ࠨࡒࡤ࡫ࡪࠦࠧ㌸")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠩࡩࡥࠬ㌹"): title = l11lll_l1_ (u"ูࠪๆำ็ࠡࠩ㌺")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ㌻"): title = l11lll_l1_ (u"ࠬ฻แฮ้ࠣࠫ㌼")
		for l1l11ll1lll_l1_ in range(1,11) :
			if not l1l11l1_l1_==str(l1l11ll1lll_l1_):
				l1l11l1ll11_l1_ = l11lll_l1_ (u"࠭࠰ࠨ㌽")+str(l1l11ll1lll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㌾"),l111ll_l1_+title+str(l1l11ll1lll_l1_),url,22,l11lll_l1_ (u"ࠨࠩ㌿"),l1l11l1l1l1_l1_+l1l11l1ll11_l1_[-2:])
	return
def l1llllll_l1_(url,l1l11l1_l1_):
	if not l1l11l1_l1_: l1l11l1_l1_ = 0
	l1l11llll1l_l1_ = l1l11ll1l1l_l1_(url)
	l1l11lllll1_l1_ = l1l11ll1l1l_l1_(url)
	l1l1llll1l1_l1_ = l1l11llllll_l1_(url)
	parts = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ㍀"))
	id,type = parts[-1],parts[3]
	l1l11l1l1l1_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	l1l11l1l1ll_l1_ = 0
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㍁"),l11lll_l1_ (u"ࠫࠬ㍂"),url, type)
	if type==l11lll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ㍃"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㍄"),l11lll_l1_ (u"ࠧࠨ㍅"),l11lll_l1_ (u"ࠨࠩ㍆"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㍇"))
		items = re.findall(l11lll_l1_ (u"ࠪࡇࡴࡳ࡭ࡦࡰࡷࡣࡵࡧ࡮ࡦ࡮ࡢࡍࡹ࡫࡭࠯ࠬࡂࡴࡃ࠮࠮ࠫࡁࠬࡀ࡮࠴ࠫࡀࡸࡤࡶࠥ࡯࡮ࡵࡧࡵࡣࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ㍈"),html,re.DOTALL)
		title = l11lll_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ㍉")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㍊"): title = l11lll_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ㍋")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠧࡧࡣࠪ㍌"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ㍍")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㍎"): title = l11lll_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ㍏")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࠧ㍐"): l1l11lll1l1_l1_ = l11lll_l1_ (u"ࠬ࠭㍑")
		else: l1l11lll1l1_l1_ = l1l1llll1l1_l1_
		l1l1l111111_l1_ = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱࡀࠦ࠭࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪࡣ࠮࠮࠮ࠫࡁࠬࠦࡃ࠭㍒"),html,re.DOTALL)
		for name,count,l1llll_l1_,link in items:
			for l1lll11_l1_ in range(int(count),0,-1):
				l1l11lll1_l1_ = l1llll_l1_ + l1l11lll1l1_l1_ + id + l11lll_l1_ (u"ࠧ࠰ࠩ㍓") + str(l1lll11_l1_) + l11lll_l1_ (u"ࠨ࠰ࡳࡲ࡬࠭㍔")
				#l1ll111llll_l1_ = l1l1l111111_l1_[0][0]+l1l1llll1l1_l1_+id+l11lll_l1_ (u"ࠩ࠲࠰ࠬ㍕")+str(l1lll11_l1_)+l11lll_l1_ (u"ࠪ࠰ࠬ㍖")+str(l1lll11_l1_)+l11lll_l1_ (u"ࠫࡤ࠭㍗")+l1l1l111111_l1_[0][2]
				l1l11l1lll1_l1_ = name + title + str(l1lll11_l1_)
				l1l11l1lll1_l1_ = unescapeHTML(l1l11l1lll1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㍘"),l111ll_l1_+l1l11l1lll1_l1_,url,24,l1l11lll1_l1_,l11lll_l1_ (u"࠭ࠧ㍙"),str(l1lll11_l1_))
	elif type==l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㍚"):
		l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡂࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡍࡹ࡫࡭ࡀ࡫ࡧࡁࠬ㍛")+str(id)+l11lll_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ㍜")+l1l11l1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃ࠱ࠨ㍝")
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ㍞"),l11lll_l1_ (u"ࠬ࠭㍟"),l11lll_l1_ (u"࠭ࠧ㍠"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ㍡"))
		items = re.findall(l11lll_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡄࡪࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㍢"),html,re.DOTALL)
		title = l11lll_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭㍣")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠪࡩࡳ࠭㍤"): title = l11lll_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ㍥")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠬ࡬ࡡࠨ㍦"): title = l11lll_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ㍧")
		if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠧࡧࡣ࠵ࠫ㍨"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ㍩")
		for l1lll11_l1_,l1llll_l1_,link,desc,name in items:
			l1l11l1l1ll_l1_ += 1
			l1l11lll1_l1_ = l1l11lllll1_l1_ + QUOTE(l1llll_l1_)
			#l1ll111llll_l1_ = l1l11lllll1_l1_ + QUOTE(link)
			name = escapeUNICODE(name)
			l1l11l1lll1_l1_ = name + title + str(l1lll11_l1_)
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㍪"),l111ll_l1_+l1l11l1lll1_l1_,l11l11l_l1_,24,l1l11lll1_l1_,l11lll_l1_ (u"ࠪࠫ㍫"),str(l1l11l1l1ll_l1_))
	elif type==l11lll_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ㍬"):
		if l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠭㍭") in url and l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ㍮") not in url:
			l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾ࠩ㍯")+str(id)+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ㍰")+l1l11l1_l1_+l11lll_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠳ࠫ㍱")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㍲"),l11lll_l1_ (u"ࠫࠬ㍳"),l11lll_l1_ (u"ࠬ࠭㍴"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠴ࡴࡧࠫ㍵"))
			items = re.findall(l11lll_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㍶"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11l1l1ll_l1_ += 1
				l1l11lll1_l1_ = l1l11lllll1_l1_ + QUOTE(l1llll_l1_)
				#l1ll111llll_l1_ = l1l11lllll1_l1_ + QUOTE(link)
				l1l11l1lll1_l1_ = name + l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ㍷") + title
				l1l11l1lll1_l1_ = l1l11l1lll1_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ㍸"))
				l1l11l1lll1_l1_ = escapeUNICODE(l1l11l1lll1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㍹"),l111ll_l1_+l1l11l1lll1_l1_,l11l11l_l1_,24,l1l11lll1_l1_,l11lll_l1_ (u"ࠫࠬ㍺"),str(l1l11l1l1ll_l1_))
		elif l11lll_l1_ (u"ࠬࡉ࡬ࡪࡲࡶࠫ㍻") in url:
			l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ㍼")+l1l11l1_l1_+l11lll_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠲࠷ࠪ㍽")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㍾"),l11lll_l1_ (u"ࠩࠪ㍿"),l11lll_l1_ (u"ࠪࠫ㎀"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠺ࡴࡩࠩ㎁"))
			items = re.findall(l11lll_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㎂"),html,re.DOTALL)
			for l1llll_l1_,title,link in items:
				l1l11l1l1ll_l1_ += 1
				l1l11lll1_l1_ = l1l11lllll1_l1_ + QUOTE(l1llll_l1_)
				#l1ll111llll_l1_ = l1l11lllll1_l1_ + QUOTE(link)
				l1l11l1lll1_l1_ = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㎃"))
				l1l11l1lll1_l1_ = escapeUNICODE(l1l11l1lll1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㎄"),l111ll_l1_+l1l11l1lll1_l1_,l11l11l_l1_,24,l1l11lll1_l1_,l11lll_l1_ (u"ࠨࠩ㎅"),str(l1l11l1l1ll_l1_))
		elif l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ㎆") in url:
			if l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠼ࠧ㎇") in url:
				l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭㎈")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠼ࠧ㎉")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㎊"),l11lll_l1_ (u"ࠧࠨ㎋"),l11lll_l1_ (u"ࠨࠩ㎌"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠹ࡹ࡮ࠧ㎍"))
			elif l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠺ࠧ㎎") in url:
				l11l11l_l1_ = l1l11llll1l_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭㎏")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠺ࠧ㎐")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㎑"),l11lll_l1_ (u"ࠧࠨ㎒"),l11lll_l1_ (u"ࠨࠩ㎓"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠺ࡹ࡮ࠧ㎔"))
			items = re.findall(l11lll_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㎕"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11l1l1ll_l1_ += 1
				l1l11lll1_l1_ = l1l11lllll1_l1_ + QUOTE(l1llll_l1_)
				#l1ll111llll_l1_ = l1l11lllll1_l1_ + QUOTE(link)
				l1l11l1lll1_l1_ = name + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ㎖") + title
				l1l11l1lll1_l1_ = l1l11l1lll1_l1_.strip(l11lll_l1_ (u"ࠬࠦࠧ㎗"))
				l1l11l1lll1_l1_ = escapeUNICODE(l1l11l1lll1_l1_)
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㎘"),l111ll_l1_+l1l11l1lll1_l1_,l11l11l_l1_,24,l1l11lll1_l1_,l11lll_l1_ (u"ࠧࠨ㎙"),str(l1l11l1l1ll_l1_))
	if type==l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㎚") or type==l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㎛"):
		if l1l11l1l1ll_l1_>25:
			title=l11lll_l1_ (u"ูࠪๆำษࠡࠩ㎜")
			if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠫࡪࡴࠧ㎝"): title = l11lll_l1_ (u"ࠬࠦࡐࡢࡩࡨࠤࠬ㎞")
			if l1l1llll1l1_l1_==l11lll_l1_ (u"࠭ࡦࡢࠩ㎟"): title = l11lll_l1_ (u"ࠧࠡืไั์ࠦࠧ㎠")
			if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠨࡨࡤ࠶ࠬ㎡"): title = l11lll_l1_ (u"ูࠩࠣๆำ็ࠡࠩ㎢")
			for l1l11ll1lll_l1_ in range(1,11):
				if not l1l11l1_l1_==str(l1l11ll1lll_l1_):
					l1l11l1ll11_l1_ = l11lll_l1_ (u"ࠪ࠴ࠬ㎣")+str(l1l11ll1lll_l1_)
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㎤"),l111ll_l1_+title+str(l1l11ll1lll_l1_),url,23,l11lll_l1_ (u"ࠬ࠭㎥"),l1l11l1l1l1_l1_+l1l11l1ll11_l1_[-2:])
	return
def PLAY(url,l1lll11_l1_):
	l1l11lllll1_l1_ = l1l11ll1l1l_l1_(url)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㎦"),l11lll_l1_ (u"ࠧࠨ㎧"),l11lll_l1_ (u"ࠨࠩ㎨"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㎩"))
	# l1l1l_l1_ l1llll1l1_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࡠࠫࠫ࠲࠯ࡅࠩࠣࡀࠪ㎪"),html,re.DOTALL)
	if items:
		l1l1llll1l1_l1_ = l1l11llllll_l1_(url)
		parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭㎫"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1l1llll1l1_l1_+id+l11lll_l1_ (u"ࠬ࠵ࠬࠨ㎬")+l1lll11_l1_+l11lll_l1_ (u"࠭ࠬࠨ㎭")+l1lll11_l1_+l11lll_l1_ (u"ࠧࡠࠩ㎮")+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭㎯"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ url
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࠫࠫࡠ࠳࠴ࠪࡀࠫࠥࠫ㎰"),html,re.DOTALL)
	if items:
		l1l1llll1l1_l1_ = l1l11llllll_l1_(url)
		parts = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ㎱"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1l1llll1l1_l1_+id+l11lll_l1_ (u"ࠫ࠴࠭㎲")+l1lll11_l1_+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠬࡳࡰ࠵ࠢࡸࡶࡱ࠭㎳"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ src
	items = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㎴"),html,re.DOTALL)
	for link in items:
		link = link.replace(l11lll_l1_ (u"ࠧ࠰࠱ࠪ㎵"),l11lll_l1_ (u"ࠨ࠱ࠪ㎶"))
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠩࡰࡴ࠹ࠦࡳࡳࡥࠪ㎷"))
		l1111_l1_.append(link)
	# l1l11lll1ll_l1_ l1111lll_l1_ links
	items = re.findall(l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㎸"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l11lllll1_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࡲࡶ࠴ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ㎹"))
		l1111_l1_.append(link)
	# l1l11lll1ll_l1_ l1l1l11111l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠬ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㎺"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l11lllll1_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"࠭࡭ࡱ࠵ࠣࡥࡩࡪࡲࡦࡵࡶࠫ㎻"))
		l1111_l1_.append(link)
	# l1l_l1_
	if len(l1111_l1_)==1: link = l1111_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ㎼"), l1lll1ll_l1_)
		if l1l_l1_ == -1 : return
		link = l1111_l1_[l1l_l1_]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㎽"))
	return
def l1l11ll1l1l_l1_(url):
	if l11ll1_l1_ in url: l1l1l1l1l1l_l1_ = l11ll1_l1_
	elif l11lllllll_l1_ in url: l1l1l1l1l1l_l1_ = l11lllllll_l1_
	elif l1l11ll1ll1_l1_ in url: l1l1l1l1l1l_l1_ = l1l11ll1ll1_l1_
	elif l1l11lll111_l1_ in url: l1l1l1l1l1l_l1_ = l1l11lll111_l1_
	else: l1l1l1l1l1l_l1_ = l11lll_l1_ (u"ࠩࠪ㎾")
	return l1l1l1l1l1l_l1_
def l1l11llllll_l1_(url):
	if   l11ll1_l1_ in url: l1l1llll1l1_l1_ = l11lll_l1_ (u"ࠪࡥࡷ࠭㎿")
	elif l11lllllll_l1_ in url: l1l1llll1l1_l1_ = l11lll_l1_ (u"ࠫࡪࡴࠧ㏀")
	elif l1l11ll1ll1_l1_ in url: l1l1llll1l1_l1_ = l11lll_l1_ (u"ࠬ࡬ࡡࠨ㏁")
	elif l1l11lll111_l1_ in url: l1l1llll1l1_l1_ = l11lll_l1_ (u"࠭ࡦࡢ࠴ࠪ㏂")
	else: l1l1llll1l1_l1_ = l11lll_l1_ (u"ࠧࠨ㏃")
	return l1l1llll1l1_l1_
def l1l1lll1l_l1_(url):
	l1l1llll1l1_l1_ = l1l11llllll_l1_(url)
	l11l11l_l1_ = url + l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡍ࡫ࡹࡩࠬ㏄")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㏅"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㏆"),l11lll_l1_ (u"ࠫࠬ㏇"),l11lll_l1_ (u"ࠬ࠭㏈"),l11lll_l1_ (u"࠭ࠧ㏉"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ㏊"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㏋"),html,re.DOTALL)
	l11l1l1_l1_ = items[0]
	PLAY_VIDEO(l11l1l1_l1_,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㏌"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠪࠤࠬ㏍"),l11lll_l1_ (u"ࠫ࠰࠭㏎"))
	if l1ll_l1_:
		l1ll1lll11_l1_ = [ l11ll1_l1_ , l11lllllll_l1_ , l1l11ll1ll1_l1_ , l1l11lll111_l1_ ]
		l1l11l1ll_l1_ = [ l11lll_l1_ (u"ࠬ฿ัษ์ࠪ㏏") , l11lll_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ㏐") , l11lll_l1_ (u"ࠧโษิื๎࠭㏑") , l11lll_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ㏒") ]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ็฾ฮࠦวๅ็้หุฮษ࠻ࠩ㏓"), l1l11l1ll_l1_)
		if l1l_l1_ == -1 : return
		l1l1ll11_l1_ = l1ll1lll11_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠪࡣࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࡢࠫ㏔") in options: l1l1ll11_l1_ = l11ll1_l1_
		elif l11lll_l1_ (u"ࠫࡤࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࡤ࠭㏕") in options: l1l1ll11_l1_ = l11lllllll_l1_
		else: l1l1ll11_l1_ = l11lll_l1_ (u"ࠬ࠭㏖")
	if not l1l1ll11_l1_: return
	l1l1llll1l1_l1_ = l1l11llllll_l1_(l1l1ll11_l1_)
	l11l11l_l1_ = l1l1ll11_l1_ + l11lll_l1_ (u"ࠨ࠯ࡉࡱࡰࡩ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡹࡥࡢࡴࡦ࡬ࡸࡺࡲࡪࡰࡪࡁࠧ㏗") + l111l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㏘"),l11lll_l1_ (u"ࠨࠩ㏙"),l1l1llll1l1_l1_,l11l11l_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ㏚"),l11lll_l1_ (u"ࠪࠫ㏛"),l11lll_l1_ (u"ࠫࠬ㏜"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ㏝"))
	items = re.findall(l11lll_l1_ (u"࠭ࠢࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠪ㏞"),html,re.DOTALL)
	if items:
		for l1llll_l1_,category,id,title in items:
			#if category in [l11lll_l1_ (u"ࠧ࠴ࠩ㏟"),l11lll_l1_ (u"ࠨ࠷ࠪ㏠"),l11lll_l1_ (u"ࠩ࠺ࠫ㏡")]:
			if category in [l11lll_l1_ (u"ࠪ࠷ࠬ㏢"),l11lll_l1_ (u"ࠫ࠼࠭㏣")]:
				title = title.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ㏤"),l11lll_l1_ (u"࠭ࠧ㏥"))
				title = title.replace(l11lll_l1_ (u"ࠧࠣࠩ㏦"),l11lll_l1_ (u"ࠨࠩ㏧"))
				if category==l11lll_l1_ (u"ࠩ࠶ࠫ㏨"):
					type = l11lll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ㏩")
					if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠫࡦࡸࠧ㏪"): name = l11lll_l1_ (u"๋ࠬำๅี็ࠤ࠿ࠦࠧ㏫")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"࠭ࡥ࡯ࠩ㏬"): name = l11lll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠻ࠢࠪ㏭")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠨࡨࡤࠫ㏮"): name = l11lll_l1_ (u"ࠩึี๏อไ้ࠡสࠤ࠿ࠦࠧ㏯")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠪࡪࡦ࠸ࠧ㏰"): name = l11lll_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ㏱")
				elif category==l11lll_l1_ (u"ࠬ࠻ࠧ㏲"):
					type = l11lll_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ㏳")
					if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠧࡢࡴࠪ㏴"): name = l11lll_l1_ (u"ࠨใํ่๊ࠦ࠺ࠡࠩ㏵")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠩࡨࡲࠬ㏶"): name = l11lll_l1_ (u"ࠪࡑࡴࡼࡩࡦࠢ࠽ࠤࠬ㏷")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࠧ㏸"): name = l11lll_l1_ (u"ࠬ็๊ๅ็ࠣ࠾ࠥ࠭㏹")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"࠭ࡦࡢ࠴ࠪ㏺"): name = l11lll_l1_ (u"ࠧโๆ่ࠤ์อࠠ࠻ࠢࠪ㏻")
				elif category==l11lll_l1_ (u"ࠨ࠹ࠪ㏼"):
					type = l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㏽")
					if l1l1llll1l1_l1_==l11lll_l1_ (u"ࠪࡥࡷ࠭㏾"): name = l11lll_l1_ (u"ࠫอืๆศ็ฯࠤ࠿ࠦࠧ㏿")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㐀"): name = l11lll_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠠ࠻ࠢࠪ㐁")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠧࡧࡣࠪ㐂"): name = l11lll_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠤ࠿ࠦࠧ㐃")
					elif l1l1llll1l1_l1_==l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㐄"): name = l11lll_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ㐅")
				title = name + title
				link = l1l1ll11_l1_ + l11lll_l1_ (u"ࠫ࠴࠭㐆") + type + l11lll_l1_ (u"ࠬ࠵ࡃࡰࡰࡷࡩࡳࡺ࠯ࠨ㐇") + id
				l1llll_l1_ = QUOTE(l1llll_l1_)
				l1llll_l1_ = l1l1ll11_l1_+l1llll_l1_
				#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㐈"),l1llll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐉"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠨ࠳࠳࠵ࠬ㐊"))
	#else: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㐋"),l11lll_l1_ (u"ࠪࠫ㐌"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㐍"),,لا توجد نتائج للبحث')
	return
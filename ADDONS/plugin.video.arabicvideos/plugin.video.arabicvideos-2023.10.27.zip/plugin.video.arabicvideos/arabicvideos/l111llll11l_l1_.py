# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ潷")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ潸")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠬ࠭潹")
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ潺"):l11lll_l1_ (u"ࠧࠨ潻")}
l1ll1l11111l1_l1_ = 0
def MAIN(mode,url,text,type,l1l11l1_l1_,name,l11l_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1l1111111_l1_(url,name,l11l_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1111l_l1_(url,l1l11l1_l1_,text)
	elif mode==145: results = l1ll1l1l1l11l_l1_(url,l1l11l1_l1_)
	elif mode==147: results = l1ll1l11l1l1l_l1_()
	elif mode==148: results = l1ll1l11l1lll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ潼"),l111ll_l1_+l11lll_l1_ (u"ࠩๅหห๋ษࠨ潽"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ潾"),144)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ潿"),l111ll_l1_+l11lll_l1_ (u"ฺࠬฮึࠩ澀"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ澁"),144)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ澂"),l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ๆ฾࠭澃"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ澄"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ澅"),l111ll_l1_+l11lll_l1_ (u"ࠫาูวษࠩ澆"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭澇"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭澈"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ฼หอ࠭澉"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ澊"),144)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ澋"),l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠩ澌"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ澍"),144)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ澎"),l111ll_l1_+l11lll_l1_ (u"࠭ๅฯฬสีฬะࠧ澏"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭澐"),144)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ澑"),l111ll_l1_+l11lll_l1_ (u"ࠩๅู๏ืษࠨ澒"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ澓"),144,l11lll_l1_ (u"ࠫࠬ澔"),l11lll_l1_ (u"ࠬ࠭澕"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ澖"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ澗"),l111ll_l1_+l11lll_l1_ (u"ࠨฬุๅา࠭澘"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ澙"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ澚"),l111ll_l1_+l11lll_l1_ (u"ࠫึฬ๊ิ์ฬࠫ澛"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠭澜"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭澝"),l111ll_l1_+l11lll_l1_ (u"ࠧาษษะࠬ澞"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭澟"),144)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ澠"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ澡"),l11lll_l1_ (u"ࠫࠬ澢"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ澣"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭澤"),l11lll_l1_ (u"ࠧࠨ澥"),149,l11lll_l1_ (u"ࠨࠩ澦"),l11lll_l1_ (u"ࠩࠪ澧"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ澨"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ澩"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ澪"),l11lll_l1_ (u"࠭ࠧ澫"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ澬"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ澭"),l11ll1_l1_+l11lll_l1_ (u"ࠩࠪ澮"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ澯"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ัศศฯอࠬ澰"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭澱"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭澲"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆอูๆำࠧ澳"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ澴"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ澵"),l111ll_l1_+l11lll_l1_ (u"ࠪห้่ี๋ำฬࠫ澶"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ澷"),144,l11lll_l1_ (u"ࠬ࠭澸"),l11lll_l1_ (u"࠭ࠧ澹"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ澺"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ澻"),l111ll_l1_+l11lll_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ澼"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ澽"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ澾"),l111ll_l1_+l11lll_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ澿"),l11lll_l1_ (u"࠭ࠧ激"),290)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ濁"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ濂"),l11lll_l1_ (u"ࠩࠪ濃"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ濄"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ濅"),l11lll_l1_ (u"ࠬ࠭濆"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭濇"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ濈"),l11lll_l1_ (u"ࠨࠩ濉"),148)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ濊"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭濋"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ濌"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ濍"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ濎"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ濏"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ濐"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ濑"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ濒"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ濓"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ濔"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ濕"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ濖"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ濗"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ濘"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ濙"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ濚"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ濛"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭濜"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ濝"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ濞"),144)
	return
def l1ll1l1111111_l1_(url,name,l11l_l1_):
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ濟"),l111ll_l1_+l11lll_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ濠")+name,url,144,l11l_l1_)
	return
def l1ll1l11l1l1l_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ濡"))
	return
def l1ll1l11l1lll_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ濢"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ濣"),l11lll_l1_ (u"ࠧࠨ濤"),l11lll_l1_ (u"ࠨࠩ濥"),url)
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ濦")
	#items = re.findall(l11lll_l1_ (u"ࠪࡺࡂ࠮࠮ࠫࡁࠬࠨࠬ濧"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ濨")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ濩"))
	#return
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ濪")
	url = url.split(l11lll_l1_ (u"ࠧࠧࠩ濫"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1l111ll1l_l1_(cc,url,index):
	level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ濬"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ濭"),l11lll_l1_ (u"ࠪࠫ濮"),index,l11lll_l1_ (u"ࠫࡋࡏࡒࡔࡖࠪ濯")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ濰")+url)
	l1ll11lllll1l_l1_,l1ll11lllllll_l1_ = [],[]
	# l11ll1ll1ll_l1_ l111ll1l11ll_l1_    should be the first item in the l1ll11lllll1l_l1_ list
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ濱") in url: l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠࠦ濲"))
	# l11ll1ll1ll_l1_ search l1ll1l1l1ll11_l1_      should be the first item in the l1ll11lllll1l_l1_ list
	if l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ濳") in url: l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣࠢ濴"))
	# main l1l11l1_l1_
	if level==l11lll_l1_ (u"ࠪ࠵ࠬ濵"): l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ濶"))
	# search results
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ濷"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣࠢ濸"))
	# l1ll1l11ll11l_l1_ l1ll1l11l1l11_l1_ & main l1l11l1_l1_ l1ll1l11l1l11_l1_ l1ll1l1l1ll11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬࡣࠢ濹"))
	# l1ll1l111lll1_l1_ menu
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࡡ࠳࡞࡝ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ濺"))
	l1ll1l11ll1ll_l1_,dd,l1ll11lll1lll_l1_ = l1ll11llll1ll_l1_(cc,l11lll_l1_ (u"ࠩࠪ濻"),l1ll11lllll1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ濼"),str(dd))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ濽"),l11lll_l1_ (u"ࠬ࠭濾"),l11lll_l1_ (u"࠭ࠧ濿"),str(len(dd)))
	if level==l11lll_l1_ (u"ࠧ࠲ࠩ瀀") and l1ll1l11ll1ll_l1_:
		if len(dd)>1 and l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ瀁") not in url:
			for zz in range(len(dd)):
				l1ll1l1111ll1_l1_ = str(zz)
				l1ll11lllll1l_l1_ = []
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠࠨ瀂")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ瀃"))
				# l1ll1l11ll11l_l1_ l1ll1l11l1l11_l1_
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛ࠣ瀄")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ瀅"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ瀆")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠢ࡞ࠤ瀇"))
				succeeded,item,l111ll1l_l1_ = l1ll11llll1ll_l1_(dd,l11lll_l1_ (u"ࠨࠩ瀈"),l1ll11lllll1l_l1_)
				if succeeded: l1ll11lllllll_l1_.append([item,url,l11lll_l1_ (u"ࠩ࠵࠾࠿࠭瀉")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ瀊")])
				#l1l11lllllll_l1_ = l1ll1l1l11l11_l1_(item,url,l11lll_l1_ (u"ࠫ࠷ࡀ࠺ࠨ瀋")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ瀌"))
				#if l1l11lllllll_l1_: l1ll11ll11_l1_ += 1
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token = l1ll1l1l1ll1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭瀍"),l111ll_l1_+title,link,144,l11lll_l1_ (u"ࠧࠨ瀎"),l11lll_l1_ (u"ࠨ࠴࠽࠾ࠬ瀏")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ瀐"))
				#l1ll11ll11_l1_ += 1
			# main l1l11l1_l1_ l1ll1l11l1l11_l1_ l1ll1l1l1ll11_l1_
			l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ瀑"))
			succeeded,item,l111ll1l_l1_ = l1ll11llll1ll_l1_(cc,l11lll_l1_ (u"ࠫࠬ瀒"),l1ll11lllll1l_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭瀓"),str(cc))
			if succeeded and l1ll11lllllll_l1_ and l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ瀔") in list(item.keys()):
				link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ瀕")
				l1ll11lllllll_l1_.append([item,link,l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ瀖")])
	return dd,l1ll1l11ll1ll_l1_,l1ll11lllllll_l1_,l1ll11lll1lll_l1_
def l1ll11llll111_l1_(cc,dd,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ瀗"),l11lll_l1_ (u"ࠪࠫ瀘"),index,l11lll_l1_ (u"ࠫࡘࡋࡃࡐࡐࡇࠫ瀙")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ瀚")+url)
	level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = index.split(l11lll_l1_ (u"࠭࠺࠻ࠩ瀛"))
	l1ll11lllll1l_l1_,l1ll1l111llll_l1_ = [],[]
	# search results
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ瀜"))
	# main l1l11l1_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ瀝")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ瀞"))
	# l11l1l11l1ll_l1_ l1ll1l11l1l11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ瀟"))
	# l11ll1ll1ll_l1_ search & l111ll1l11ll_l1_ & l1ll1l1l1ll11_l1_
	if l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ瀠") in url: l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ瀡"))
	elif l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ瀢") in url: l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ瀣"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ瀤")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ瀥"))
	# l11l1l11l1ll_l1_ l11ll1l111_l1_ & l1ll1l11l1l11_l1_ filters
	if l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ瀦") in url or (l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ瀧") in url and l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ瀨") not in url):
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ瀩")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ瀪"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ瀫")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ瀬"))
	# l1ll1l11ll11l_l1_ search
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡࠢ瀭")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ瀮"))
	# main l1l11l1_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ瀯")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ瀰"))
	# l11ll1ll1ll_l1_ l111ll1l11ll_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞ࠦ瀱")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ瀲"))
	l1ll1l11ll111_l1_,ee,l1ll1l111l1ll_l1_ = l1ll11llll1ll_l1_(dd,l11lll_l1_ (u"ࠩࠪ瀳"),l1ll11lllll1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ瀴"),str(ee))
	#DIALOG_OK()
	if level==l11lll_l1_ (u"ࠫ࠷࠭瀵") and l1ll1l11ll111_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll11lllll1l_l1_ = []
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ瀶")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ瀷"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ瀸")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ瀹"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ瀺")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ瀻"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ瀼")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ瀽"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ瀾")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ瀿"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ灀")+index2+l11lll_l1_ (u"ࠤࡠࠦ灁"))
				succeeded,item,l111ll1l_l1_ = l1ll11llll1ll_l1_(ee,l11lll_l1_ (u"ࠪࠫ灂"),l1ll11lllll1l_l1_)
				if succeeded: l1ll1l111llll_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠸ࡀ࠺ࠨ灃")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ灄")+index2+l11lll_l1_ (u"࠭࠺࠻࠲ࠪ灅")])
				#l1l11lllllll_l1_ = l1ll1l1l11l11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽ࠫ灆")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ灇")+index2+l11lll_l1_ (u"ࠩ࠽࠾࠵࠭灈"))
				#if l1l11lllllll_l1_: l1l1l11ll1_l1_ += 1
				#LOG_THIS(l11lll_l1_ (u"ࠪࠫ灉"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ灊")+str(item))
				#l1l1l11ll1_l1_ += 1
				#item = ee[zz]
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token = l1ll1l1l1ll1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ灋"),l111ll_l1_+title,link,144,l1llll_l1_,l11lll_l1_ (u"࠭࠳࠻࠼ࠪ灌")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ灍")+index2+l11lll_l1_ (u"ࠨ࠼࠽࠴ࠬ灎"))
			# search l1ll1l1l1ll11_l1_
			l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ灏"))
			# search l1ll1l1l1ll11_l1_
			l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞ࠤ灐"))
			succeeded,item,l111ll1l_l1_ = l1ll11llll1ll_l1_(dd,l11lll_l1_ (u"ࠫࠬ灑"),l1ll11lllll1l_l1_)
			if succeeded and l1ll1l111llll_l1_ and l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ灒") in list(item.keys()):
				l1ll1l111llll_l1_.append([item,url,l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ灓")])
			#l1l11lllllll_l1_ = l1ll1l1l11l11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ灔"))
			#if l1l11lllllll_l1_: l1l1l11ll1_l1_ += 1
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ灕"),str(item))
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ灖"),link+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ灗")+token)
	return ee,l1ll1l11ll111_l1_,l1ll1l111llll_l1_,l1ll1l111l1ll_l1_
def l1ll1l111111l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ灘"),l11lll_l1_ (u"ࠬ࠭灙"),index,l11lll_l1_ (u"࠭ࡔࡉࡋࡕࡈࠬ灚")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ灛")+url)
	level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ灜"))
	l1ll11lllll1l_l1_,l1ll1l1111l11_l1_ = [],[]
	# search results
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ灝")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ灞"))
	# l11ll1ll1ll_l1_ l111ll1l11ll_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ灟")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ灠"))
	# l1ll1l1l111ll_l1_ menu l1ll1l11l1l11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ灡")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ灢"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ灣")+index2+l11lll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ灤"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡࠢ灥")+index2+l11lll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ灦"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ灧")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ灨"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ灩")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ灪"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ火")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ灬"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ灭"))
	# l1ll1l11ll11l_l1_ l1ll1l1l1lll1_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ灮"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ灯"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ灰")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ灱"))
	# main l1l11l1_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ灲")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ灳"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫ࠢ灴"))
	l1ll1l11lll1l_l1_,ff,l1ll1l1l1l1ll_l1_ = l1ll11llll1ll_l1_(ee,l11lll_l1_ (u"ࠬ࠭灵"),l1ll11lllll1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ灶"),str(ff))
	if level==l11lll_l1_ (u"ࠧ࠴ࠩ灷") and l1ll1l11lll1l_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1ll1l11l11ll_l1_ = str(zz)
				#DIALOG_OK()
				l1ll11lllll1l_l1_ = []
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠧ灸")+l1ll1l11l11ll_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ灹"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠢ灺")+l1ll1l11l11ll_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ灻"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠤ灼")+l1ll1l11l11ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ災"))
				l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠦ灾")+l1ll1l11l11ll_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ灿"))
				succeeded,item,l111ll1l_l1_ = l1ll11llll1ll_l1_(ff,l11lll_l1_ (u"ࠩࠪ炀"),l1ll11lllll1l_l1_)
				#succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token = l1ll1l1l1ll1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ炁"),l111ll_l1_+link,link,143,l1llll_l1_)
				if succeeded: l1ll1l1111l11_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠹ࡀ࠺ࠨ炂")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ炃")+index2+l11lll_l1_ (u"࠭࠺࠻ࠩ炄")+l1ll1l11l11ll_l1_])
				#l1l11lllllll_l1_ = l1ll1l1l11l11_l1_(item,url,l11lll_l1_ (u"ࠧ࠵࠼࠽ࠫ炅")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ炆")+index2+l11lll_l1_ (u"ࠩ࠽࠾ࠬ炇")+l1ll1l11l11ll_l1_)
				#if l1l11lllllll_l1_: l1l1l11lll_l1_ += 1
	return ff,l1ll1l11lll1l_l1_,l1ll1l1111l11_l1_,l1ll1l1l1l1ll_l1_
def l1ll11llll1ll_l1_(l11l1l1ll111_l1_,l11l1ll11l11_l1_,l1ll1l1111l1l_l1_):
	cc,l11l1ll11l11_l1_ = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	dd,l11l1ll11l11_l1_ = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	ee,l11l1ll11l11_l1_ = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	ff,l11l1ll11l11_l1_ = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	item,render = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	count = len(l1ll1l1111l1l_l1_)
	for l11ll111l1_l1_ in range(count):
		try:
			out = eval(l1ll1l1111l1l_l1_[l11ll111l1_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"ࠪࠫ炈")
			return True,out,l11ll111l1_l1_+1
		except: pass
	return False,l11lll_l1_ (u"ࠫࠬ炉"),0
def l1111l_l1_(url,index=l11lll_l1_ (u"ࠬ࠭炊"),data=l11lll_l1_ (u"࠭ࠧ炋")):
	l1ll11lllllll_l1_,l1ll1l111llll_l1_,l1ll1l1111l11_l1_ = [],[],[]
	if l11lll_l1_ (u"ࠧ࠻࠼ࠪ炌") not in index: index = l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ炍")
	level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = index.split(l11lll_l1_ (u"ࠩ࠽࠾ࠬ炎"))
	if level==l11lll_l1_ (u"ࠪ࠸ࠬ炏"): level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭炐"),l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭炑"),l11lll_l1_ (u"࠭ࠧ炒"),index,url)
	data = data.replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ炓"),l11lll_l1_ (u"ࠨࠩ炔"))
	html,cc,l11ll1l11_l1_ = l1ll1l11l1111_l1_(url,data)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡰࡴࠣࠫ࠴ࡻࡳࡦࡴ࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠥࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡵࡷ࡯ࡧࡵ࠾ࠥࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠩࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࠫࡰࡹࡱࡩࡷࡔࡁࡎࡇ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠷࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱࠬ࠲࠶࠷࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠧࠨࠢ炕")
	index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭炖")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ炗")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ炘")+l1ll1l11l11ll_l1_
	if level in [l11lll_l1_ (u"࠭࠱ࠨ炙"),l11lll_l1_ (u"ࠧ࠳ࠩ炚"),l11lll_l1_ (u"ࠨ࠵ࠪ炛")]:
		dd,l1ll1l11ll1ll_l1_,l1ll11lllllll_l1_,l1ll11lll1lll_l1_ = l1ll1l111ll1l_l1_(cc,url,index)
		if not l1ll1l11ll1ll_l1_: return
		l1ll11ll11_l1_ = len(l1ll11lllllll_l1_)
		if l1ll11ll11_l1_<2:
			if level==l11lll_l1_ (u"ࠩ࠴ࠫ炜"): level = l11lll_l1_ (u"ࠪ࠶ࠬ炝")
			l1ll11lllllll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ炞"),l11lll_l1_ (u"ࠬ࠭炟"),index,l11lll_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠱࡝ࡰࠪ炠")+l11lll_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ炡")+str(l1ll11lll1lll_l1_)+l11lll_l1_ (u"ࠨ࡞ࡱࠫ炢")+l11lll_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ炣")+str(len(dd))+l11lll_l1_ (u"ࠪࡠࡳ࠭炤")+l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ炥")+str(l1ll11ll11_l1_)+l11lll_l1_ (u"ࠬࡢ࡮ࠨ炦")+url)
	index = level+l11lll_l1_ (u"࠭࠺࠻ࠩ炧")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ炨")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ炩")+l1ll1l11l11ll_l1_
	if level in [l11lll_l1_ (u"ࠩ࠵ࠫ炪"),l11lll_l1_ (u"ࠪ࠷ࠬ炫")]:
		ee,l1ll1l11ll111_l1_,l1ll1l111llll_l1_,l1ll1l111l1ll_l1_ = l1ll11llll111_l1_(cc,dd,url,index)
		if not l1ll1l11ll111_l1_: return
		l1l1l11ll1_l1_ = len(l1ll1l111llll_l1_)
		if l1l1l11ll1_l1_<2:
			if level==l11lll_l1_ (u"ࠫ࠷࠭炬"): level = l11lll_l1_ (u"ࠬ࠹ࠧ炭")
			l1ll1l111llll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ炮"),l11lll_l1_ (u"ࠧࠨ炯"),index,l11lll_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠴࡟ࡲࠬ炰")+l11lll_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭炱")+str(l1ll1l111l1ll_l1_)+l11lll_l1_ (u"ࠪࡠࡳ࠭炲")+l11lll_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭炳")+str(len(ee))+l11lll_l1_ (u"ࠬࡢ࡮ࠨ炴")+l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ炵")+str(l1l1l11ll1_l1_)+l11lll_l1_ (u"ࠧ࡝ࡰࠪ炶")+url)
	index = level+l11lll_l1_ (u"ࠨ࠼࠽ࠫ炷")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ炸")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭点")+l1ll1l11l11ll_l1_
	if level in [l11lll_l1_ (u"ࠫ࠸࠭為")]:
		ff,l1ll1l11lll1l_l1_,l1ll1l1111l11_l1_,l1ll1l1l1l1ll_l1_ = l1ll1l111111l_l1_(cc,ee,url,index)
		if not l1ll1l11lll1l_l1_: return
		l1l1l11lll_l1_ = len(l1ll1l1111l11_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭炻"),l11lll_l1_ (u"࠭ࠧ炼"),index,l11lll_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠴࡞ࡱࠫ炽")+l11lll_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ炾")+str(l1ll1l1l1l1ll_l1_)+l11lll_l1_ (u"ࠩ࡟ࡲࠬ炿")+l11lll_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ烀")+str(len(ff))+l11lll_l1_ (u"ࠫࡡࡴࠧ烁")+l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭烂")+str(l1l1l11lll_l1_)+l11lll_l1_ (u"࠭࡜࡯ࠩ烃")+url)
	for item,url,index in l1ll11lllllll_l1_+l1ll1l111llll_l1_+l1ll1l1111l11_l1_:
		l1l11lllllll_l1_ = l1ll1l1l11l11_l1_(item,url,index)
	return
def l1ll1l1l11l11_l1_(item,url=l11lll_l1_ (u"ࠧࠨ烄"),index=l11lll_l1_ (u"ࠨࠩ烅")):
	if l11lll_l1_ (u"ࠩ࠽࠾ࠬ烆") in index: level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = index.split(l11lll_l1_ (u"ࠪ࠾࠿࠭烇"))
	else: level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭烈"),l11lll_l1_ (u"ࠬ࠶ࠧ烉"),l11lll_l1_ (u"࠭࠰ࠨ烊"),l11lll_l1_ (u"ࠧ࠱ࠩ烋")
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,l1ll1l1l11lll_l1_ = l1ll1l1l1ll1l_l1_(item)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ烌"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ烍"),link)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ烎"),link+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ烏")+title)
	# needed for l1ll1l11ll11l_l1_ l1ll1l1l1lll1_l1_ next l1l11l1_l1_
	# and needed for l1ll1l11ll11l_l1_ l1ll1l1l1lll1_l1_ sub-menu
	#if (l11lll_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭烐") in link or l11lll_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ烑") in link) and (l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ烒") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ烓") in link): link = url
	l1ll11lll1ll_l1_ = l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ烔") in link or l11lll_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭烕") in link or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ烖") in link
	l1ll11lll11l_l1_ = l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ烗") in link or l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ烘") in link
	if l1ll11lll1ll_l1_ or l1ll11lll11l_l1_: link = url
	l1ll11lll1ll_l1_ = l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ烙") not in link and l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ烚") not in link
	l1ll11lll11l_l1_ = l11lll_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ烛") not in link  and l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭烜") not in link
	if index[0:5]==l11lll_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ烝") and l1ll11lll1ll_l1_ and l1ll11lll11l_l1_: link = url
	if l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ烞") in url or l11lll_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ烟") in link:
		level,l1ll1l1111ll1_l1_,index2,l1ll1l11l11ll_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ烠"),l11lll_l1_ (u"ࠨ࠲ࠪ烡"),l11lll_l1_ (u"ࠩ࠳ࠫ烢"),l11lll_l1_ (u"ࠪ࠴ࠬ烣")
		index = l11lll_l1_ (u"ࠫࠬ烤")
	l11ll1l11_l1_ = l11lll_l1_ (u"ࠬ࠭烥")
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ烦") in link or l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭烧") in link or l11lll_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭烨") in url:
		data = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ烩"))
		if data.count(l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ烪"))==4:
			l1ll1l11lll11_l1_,key,l1ll1l11l1ll1_l1_,l1ll1l111l111_l1_,token = data.split(l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ烫"))
			l11ll1l11_l1_ = l1ll1l11lll11_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ烬")+key+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ热")+l1ll1l11l1ll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ烮")+l1ll1l111l111_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ烯")+l1ll1l1l11lll_l1_
			if l11lll_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ烰") in url and not link: link = url
			else: link = link+l11lll_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ烱")+key
	if not title:
		global l1ll1l11111l1_l1_
		l1ll1l11111l1_l1_ += 1
		title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ烲")+str(l1ll1l11111l1_l1_)
		index = l11lll_l1_ (u"ࠬ࠹ࠧ烳")+l11lll_l1_ (u"࠭࠺࠻ࠩ烴")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ烵")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ烶")+l1ll1l11l11ll_l1_
	#if l11lll_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ烷") in url: link = url
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ烸"),l11lll_l1_ (u"ࠫࠬ烹"),title,index+l11lll_l1_ (u"ࠬࡢ࡮ࠨ烺")+link)
	#if not link: link = url
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ烻"),l11lll_l1_ (u"ࠧࠨ烼"),str(succeeded),title+l11lll_l1_ (u"ࠨࠢ࠽࠾࠿ࠦࠧ烽")+link)
	#if l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ烾") in url and index==l11lll_l1_ (u"ࠪ࠴ࠬ烿"):
	#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ焀"),l111ll_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ焁") in str(item): return False			# l1ll1l1l111l1_l1_ not items
	elif l11lll_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭焂") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ焃") in link: return False
	elif l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ焄") in list(item.keys()) or l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ焅") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭焆")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ焇")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ焈")+l1ll1l11l11ll_l1_
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭焉"),l111ll_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠣࠫ焊")+l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ焋"),link,144,l1llll_l1_,index,l11ll1l11_l1_)
	elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ焌") in link:
		title = l11lll_l1_ (u"ࠪ࠾࠿ࠦࠧ焍")+title
		index = l11lll_l1_ (u"ࠫ࠸࠭焎")+l11lll_l1_ (u"ࠬࡀ࠺ࠨ焏")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ焐")+index2+l11lll_l1_ (u"ࠧ࠻࠼ࠪ焑")+l1ll1l11l11ll_l1_
		url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ焒"),l11lll_l1_ (u"ࠩࠪ焓"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ焔"),l111ll_l1_+title,url,145,l11lll_l1_ (u"ࠫࠬ焕"),index,l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ焖"))
	elif l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ焗") in url and not link:
		index = l11lll_l1_ (u"ࠧ࠴ࠩ焘")+l11lll_l1_ (u"ࠨ࠼࠽ࠫ焙")+l1ll1l1111ll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ焚")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭焛")+l1ll1l11l11ll_l1_
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ焜")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ焝"),l111ll_l1_+title,url,144,l1llll_l1_,index,l11ll1l11_l1_)
	#elif l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ焞") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ焟") in link and url==l11ll1_l1_:
		title = l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬ焠")+title
		index = l11lll_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭無")
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ焢"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11ll1l11_l1_)
	elif not link and l11lll_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ焣") in str(item):
		title = l11lll_l1_ (u"ࠬࡀ࠺ࠡࠩ焤")+title
		index = l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ焥")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ焦"),l111ll_l1_+title,url,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ焧") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ焨"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ焩"),9999)
	#elif l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ焪") in link and l11lll_l1_ (u"ࠬࡨࡰ࠾ࠩ焫") not in link:
	#	title = l11lll_l1_ (u"࠭࠺࠻ࠢࠪ焬")+title
	#	index = l11lll_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ焭")
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ焮"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif l1111llllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ焯"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	elif l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ焰") in link:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ焱"),l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ焲")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ焳")+title,link,144,l1llll_l1_,index)
	#elif l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭焴") in link and l11lll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ焵") not in link and l11lll_l1_ (u"ࠩࡷࡁ࠵࠭然") not in link:
	#	l1ll1l11l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ焷"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭焸")+l1ll1l11l11l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ焹"),l111ll_l1_+l11lll_l1_ (u"࠭ࡌࡊࡕࡗࠫ焺")+count+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ焻")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ焼") in link:
		link = link.split(l11lll_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ焽"),1)[0]
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ焾"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	elif l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ焿") in link:
		if l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ煀") in link and count:
			l1ll1l11l11l1_l1_ = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭煁"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ煂")+l1ll1l11l11l1_l1_
			index = l11lll_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ煃")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ煄"),l111ll_l1_+l11lll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ煅")+count+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ煆")+title,link,144,l1llll_l1_,index)
		else:
			link = link.split(l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ煇"),1)[0]
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ煈"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	elif l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ煉") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ煊") in link or (l11lll_l1_ (u"ࠩ࠲ࡄࠬ煋") in link and link.count(l11lll_l1_ (u"ࠪ࠳ࠬ煌"))==3):
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ煍"),l111ll_l1_+l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ煎")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ煏")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ煐") in link:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ煑"),l111ll_l1_+l11lll_l1_ (u"ࠩࡘࡗࡊࡘࠧ煒")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ煓")+title,link,144,l1llll_l1_,index)
	else:
		if not link: link = url
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ煔")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ煕"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11ll1l11_l1_)
	return True
def l1ll1l1l1ll1l_l1_(item):
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token = False,l11lll_l1_ (u"࠭ࠧ煖"),l11lll_l1_ (u"ࠧࠨ煗"),l11lll_l1_ (u"ࠨࠩ煘"),l11lll_l1_ (u"ࠩࠪ煙"),l11lll_l1_ (u"ࠪࠫ煚"),l11lll_l1_ (u"ࠫࠬ煛"),l11lll_l1_ (u"ࠬ࠭煜"),l11lll_l1_ (u"࠭ࠧ煝")
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ煞"),str(item))
	if not isinstance(item,dict): return succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token
	for l1ll1l1l11111_l1_ in list(item.keys()):
		render = item[l1ll1l1l11111_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ煟"),str(render))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ煠"),str(render))
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ煡"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ煢"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡰ࡮ࡴࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ煣"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ煤"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ煥"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ煦"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ照"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ煨"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ煩"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ煪"))
	# required for l11l1l11l1ll_l1_ l1ll1l111ll11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ煫"))
	# l1ll1l11ll11l_l1_ l1ll1l11l1l11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ煬"))
	succeeded,title,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ煭"),l11lll_l1_ (u"ࠩࠪ煮"),l11lll_l1_ (u"ࠪࠫ煯"),str(l111ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ煰"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ煱")+str(title))
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ煲"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ煳"))
	# l1ll1l1l1ll11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ煴"))
	# header feed
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ煵"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ煶"))
	# required for l11l1l11l1ll_l1_ l1lllll1lll_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ煷"))
	# l1ll1l11ll11l_l1_ l1ll1l11l1l11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ煸"))
	succeeded,link,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ煹"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ煺"))
	# l1ll1l11ll11l_l1_ l1ll1l11l1l11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ煻"))
	succeeded,l1llll_l1_,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ煼"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ煽")+l1llll_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ煾"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ煿"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ熀"))
	succeeded,count,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ熁"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ熂"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ熃"))
	# l1ll1l11lllll_l1_ l1ll1l11ll11l_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࡖࡼࡴࡪ࠭࡝ࠣ熄"))
	# l1ll1l11lllll_l1_ l1ll1l11ll11l_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡺࡹ࡭ࡧࠪࡡࠧ熅"))
	succeeded,l1l1l1111_l1_,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	#l1ll11lllll1l_l1_ = []
	# l1ll1l1l1ll11_l1_
	#l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡰ࡮ࡩ࡫ࡕࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ熆"))
	# l11ll1ll1ll_l1_ l111ll1l11ll_l1_
	#l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡶࡵࡥࡨࡱࡩ࡯ࡩࡓࡥࡷࡧ࡭ࡴࠩࡠࠦ熇"))
	#succeeded,l1ll1l11111ll_l1_,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	# l11ll1ll1ll_l1_ l111ll1l11ll_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ熈"))
	# l1ll1l1l1ll11_l1_
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ熉"))
	succeeded,token,l111ll1l_l1_ = l1ll11llll1ll_l1_(item,render,l1ll11lllll1l_l1_)
	if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ熊") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠪࠫ熋"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ熌")
	if l11lll_l1_ (u"๋ࠬศศึิࠫ熍") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ熎"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ熏")
	if l11lll_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ熐") in list(render.keys()):
		l1ll1l1l11l1l_l1_ = str(render[l11lll_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ熑")])
		if l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ熒") in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠫࠩࡀࠠࠡࠩ熓")
		if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ熔") in l1ll1l1l11l1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ熕")
		if l11lll_l1_ (u"ࠧࡃࡷࡼࠫ熖") in l1ll1l1l11l1l_l1_ or l11lll_l1_ (u"ࠨࡔࡨࡲࡹ࠭熗") in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ熘")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡸ๊ࠫฮวีำࠪ熙")) in l1ll1l1l11l1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ熚")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡺ࠭ิาษฤࠫ熛")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ熜")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡵࠨษึฮหาวาࠩ熝")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ熞")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ熟")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ熠")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ熡") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠬࡅࠧ熢"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ熣") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ熤")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1ll1l11l111l_l1_: title = l1ll1l11l111l_l1_+title
	#title = unescapeHTML(title)
	l1l1l1111_l1_ = l1l1l1111_l1_.replace(l11lll_l1_ (u"ࠨ࠮ࠪ熥"),l11lll_l1_ (u"ࠩࠪ熦"))
	count = count.replace(l11lll_l1_ (u"ࠪ࠰ࠬ熧"),l11lll_l1_ (u"ࠫࠬ熨"))
	count = re.findall(l11lll_l1_ (u"ࠬࡢࡤࠬࠩ熩"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"࠭ࠧ熪")
	return True,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_,token
def l1ll1l11l1111_l1_(url,data=l11lll_l1_ (u"ࠧࠨ熫"),request=l11lll_l1_ (u"ࠨࠩ熬")):
	if request==l11lll_l1_ (u"ࠩࠪ熭"): request = l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ熮")
	#if l11lll_l1_ (u"ࠫࡤࡥࠧ熯") in l1ll1l11ll1l1_l1_: l1ll1l11ll1l1_l1_ = l11lll_l1_ (u"ࠬ࠭熰")
	#if l11lll_l1_ (u"࠭ࡳࡴ࠿ࠪ熱") in url: url = url.split(l11lll_l1_ (u"ࠧࡴࡵࡀࠫ熲"))[0]
	l111llll1l_l1_ = l1l11111l_l1_()
	#l111llll1l_l1_ = l11lll_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠰࠺࠰࠳࠲࠵࠴࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠡࡇࡧ࡫࠴࠷࠰࠺࠰࠳࠲࠶࠻࠱࠹࠰࠺࠴ࠬ熳")
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭熴"):l111llll1l_l1_,l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ熵"):l11lll_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ熶")}
	#l1l1ll1ll_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ熷"))
	if data.count(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ熸"))==4: l1ll1l11lll11_l1_,key,l1ll1l11l1ll1_l1_,l1ll1l111l111_l1_,token = data.split(l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ熹"))
	else: l1ll1l11lll11_l1_,key,l1ll1l11l1ll1_l1_,l1ll1l111l111_l1_,token = l11lll_l1_ (u"ࠨࠩ熺"),l11lll_l1_ (u"ࠩࠪ熻"),l11lll_l1_ (u"ࠪࠫ熼"),l11lll_l1_ (u"ࠫࠬ熽"),l11lll_l1_ (u"ࠬ࠭熾")
	l11ll1l11_l1_ = {l11lll_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ熿"):{l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ燀"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ燁"):l11lll_l1_ (u"ࠤࡤࡶࠧ燂"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ燃"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ燄"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ燅"):l1ll1l11l1ll1_l1_}}}
	if url==l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ燆") or l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ燇") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ燈")+l11lll_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ燉")+key
		l11ll1l11_l1_[l11lll_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ燊")] = l1ll1l11lll11_l1_
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ燋"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ燌"))
	elif l11lll_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ燍") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ燎")+key
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭燏"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ燐"))
	elif l11lll_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ燑") in url and l1ll1l11lll11_l1_:
		l11ll1l11_l1_[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ燒")] = token
		l11ll1l11_l1_[l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭燓")][l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭燔")][l11lll_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ燕")] = l1ll1l11lll11_l1_
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭燖"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ燗"))
	elif l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ燘") in url and l1ll1l111l111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ燙"):l11lll_l1_ (u"ࠬ࠷ࠧ燚"),l11lll_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ燛"):l1ll1l11l1ll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ燜"):l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ燝")+l1ll1l111l111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭燞"),url,l11lll_l1_ (u"ࠪࠫ營"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ燠"),l11lll_l1_ (u"ࠬ࠭燡"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ燢"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ燣"),url,l11lll_l1_ (u"ࠨࠩ燤"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ燥"),l11lll_l1_ (u"ࠪࠫ燦"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ燧"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ燨"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ燩"),html,re.DOTALL|re.I)
	if tmp: l1ll1l11l1ll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ燪"),html,re.DOTALL|re.I)
	if tmp: l1ll1l11lll11_l1_ = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ燫"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭燬"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠥ࠾ࢀࠨࡴࡰ࡭ࡨࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ燭"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ燮"),l11lll_l1_ (u"ࠬ࠭燯"),l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ燰"),str(len(tmp)))
	#if tmp: l1ll1l1l1ll11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ燱") in list(cookies.keys()): l1ll1l111l111_l1_ = cookies[l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭燲")]
	l11ll1l1l_l1_ = l1ll1l11lll11_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭燳")+key+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ燴")+l1ll1l11l1ll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ燵")+l1ll1l111l111_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ燶")+token
	if request==l11lll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭燷") and l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ燸") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ燹"),html,re.DOTALL)
		if not l111lll11l_l1_: l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ燺"),html,re.DOTALL)
		l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠪࡷࡹࡸࠧ燻"),l111lll11l_l1_[0])
	elif request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ燼") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ燽") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ燾"),html,re.DOTALL)
		l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ燿"),l111lll11l_l1_[0])
	elif l11lll_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ爀") not in html: l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭爁"),html)
	else: l1ll11llllll1_l1_ = l11lll_l1_ (u"ࠪࠫ爂")
	if 0:
		cc = str(l1ll11llllll1_l1_)
		if kodi_version>18.99: cc = cc.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ爃"))
		open(l11lll_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ爄"),l11lll_l1_ (u"࠭ࡷࡣࠩ爅")).write(cc)
		#open(l11lll_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ爆"),l11lll_l1_ (u"ࠨࡹࠪ爇")).write(html)
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ爈"),l11ll1l1l_l1_)
	return html,l1ll11llllll1_l1_,l11ll1l1l_l1_
def l1ll1l1l1l11l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ爉"),l11lll_l1_ (u"ࠫ࠰࠭爊"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭爋")+search
	l1111l_l1_(l11l11l_l1_,index)
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ爌")+l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ爍")+l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ爎")+l11lll_l1_ (u"ࠩࡢࠫ爏")+search
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ爐"),l11lll_l1_ (u"ࠫࠬ爑"),l11lll_l1_ (u"ࠬ࠭爒"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ爓"),l11lll_l1_ (u"ࠧࠨ爔"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ爕"),l11lll_l1_ (u"ࠩ࠮ࠫ爖"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ爗")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ爘") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ爙")
		elif l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ爚") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ爛")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭爜") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ爝")
		else: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠪࠫ爞")
		l11l1l1_l1_ = l11l11l_l1_+l1ll1l111l1l1_l1_
	else:
		l1ll1l111l11l_l1_,l1ll11llll1l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠫࠬ爟")
		l1ll11lllll11_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ爠"),l11lll_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ爡"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ爢"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ爣"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭爤")]
		l1ll1l1l1111l_l1_ = [l11lll_l1_ (u"ࠪࠫ爥"),l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ爦"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ爧"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ爨"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭爩")]
		l1ll1l1l11ll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ爪"),l1ll11lllll11_l1_)
		if l1ll1l1l11ll1_l1_ == -1: return
		l1ll1l1111lll_l1_ = l1ll1l1l1111l_l1_[l1ll1l1l11ll1_l1_]
		html,c,data = l1ll1l11l1111_l1_(l11l11l_l1_+l1ll1l1111lll_l1_)
		if c:
			try:
				d = c[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ爫")][l11lll_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭爬")][l11lll_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭爭")][l11lll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ爮")][l11lll_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ爯")][l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ爰")][l11lll_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ爱")]
				for l1ll11llll11l_l1_ in range(len(d)):
					group = d[l1ll11llll11l_l1_][l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ爲")][l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ爳")]
					for l1ll1l1l1l1l1_l1_ in range(len(group)):
						render = group[l1ll1l1l1l1l1_l1_][l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ爴")]
						if l11lll_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ爵") in list(render.keys()):
							link = render[l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ父")][l11lll_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ爷")][l11lll_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭爸")][l11lll_l1_ (u"ࠩࡸࡶࡱ࠭爹")]
							link = link.replace(l11lll_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ爺"),l11lll_l1_ (u"ࠫࠫ࠭爻"))
							title = render[l11lll_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭爼")]
							title = title.replace(l11lll_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ爽"),l11lll_l1_ (u"ࠧࠨ爾"))
							if l11lll_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ爿") in title: continue
							if l11lll_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ牀") in title:
								title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ牁")+title
								l1lll1lll_l1_ = title
								l1lllll1ll_l1_ = link
							if l11lll_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ牂") in title: continue
							title = title.replace(l11lll_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ牃"),l11lll_l1_ (u"࠭ࠧ牄"))
							if l11lll_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ牅") in title: continue
							if l11lll_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ牆") in title:
								title = l11lll_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ片")+title
								l1lll1lll_l1_ = title
								l1lllll1ll_l1_ = link
							if l11lll_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ版") in title: continue
							l1ll1l111l11l_l1_.append(escapeUNICODE(title))
							l1ll11llll1l1_l1_.append(link)
			except: pass
		if not l1lll1lll_l1_: l1ll1l11llll1_l1_ = l11lll_l1_ (u"ࠫࠬ牉")
		else:
			l1ll1l111l11l_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ牊"),l1lll1lll_l1_]+l1ll1l111l11l_l1_
			l1ll11llll1l1_l1_ = [l11lll_l1_ (u"࠭ࠧ牋"),l1lllll1ll_l1_]+l1ll11llll1l1_l1_
			l1ll1l1l1l111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ牌"),l1ll1l111l11l_l1_)
			if l1ll1l1l1l111_l1_ == -1: return
			l1ll1l11llll1_l1_ = l1ll11llll1l1_l1_[l1ll1l1l1l111_l1_]
		if l1ll1l11llll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1ll1l11llll1_l1_
		elif l1ll1l1111lll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1ll1l1111lll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ牍")
	#DIALOG_OK()
	l1111l_l1_(l11l1l1_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭༠")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡅࡗ࡚࡟ࠨ༡")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==730: results = MENU()
	elif mode==731: results = l1111l_l1_(url)
	elif mode==732: results = PLAY(url)
	elif mode==733: results = l1llllll_l1_(url)
	elif mode==734: results = l1l11l1l1_l1_(url)
	elif mode==735: results = l1l11l111_l1_(url)
	elif mode==739: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༢"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ༣"),l11lll_l1_ (u"ࠬ࠭༤"),739,l11lll_l1_ (u"࠭ࠧ༥"),l11lll_l1_ (u"ࠧࠨ༦"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ༧"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ༨"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ༩"),l11lll_l1_ (u"ࠫࠬ༪"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ༫"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ༬")+l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧ༭"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡷࡳࡵ࠴ࡰࡩࡲࠪ༮"),735)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ༯"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ༰")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠬ༱"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡣࡢࡴࡷࡳࡴࡴ࠮ࡱࡪࡳࠫ༲"),734)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༳"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ༴")+l111ll_l1_+l11lll_l1_ (u"ࠨษไ่ฬ๋༵ࠧ"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠱ࡴ࡭ࡶࠧ༶"),731)
	return
def l1l11l1l1_l1_(url):
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ༷ࠪ"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ใๅࠩ༸"),url,731)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕ༹ࠩ"),url,l11lll_l1_ (u"࠭ࠧ༺"),l11lll_l1_ (u"ࠧࠨ༻"),l11lll_l1_ (u"ࠨࠩ༼"),l11lll_l1_ (u"ࠩࠪ༽"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓ࠮ࡕࡈࡖࡎࡋࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭༾"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࡀࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ༿"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢཀ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨཁ")+link
			title = l11lll_l1_ (u"ࠧฮำไࠤࠬག")+title
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨགྷ"),l111ll_l1_+title,link,731)
	return
def l1l11l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ང"),url,l11lll_l1_ (u"ࠪࠫཅ"),l11lll_l1_ (u"ࠫࠬཆ"),l11lll_l1_ (u"ࠬ࠭ཇ"),l11lll_l1_ (u"࠭ࠧ཈"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡙ࡅࡓࡋࡈࡗࡤࡌࡅࡂࡖࡘࡖࡊࡊ࠭࠳ࡰࡧࠫཉ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬཊ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨཋ"),block,re.DOTALL)
		for title,link,l1llll_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬཌ")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ཌྷ")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧཎ"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ཏ"),l111ll_l1_+title,link,733,l1llll_l1_)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨཐ"),l11lll_l1_ (u"ࠨࠩད"),request,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭དྷ"),url,l11lll_l1_ (u"ࠪࠫན"),l11lll_l1_ (u"ࠫࠬཔ"),l11lll_l1_ (u"ࠬ࠭ཕ"),l11lll_l1_ (u"࠭ࠧབ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩབྷ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨ࡯ࡲࡺ࡮࡫ࡳࡃ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣམ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡳࡻ࡯ࡥࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡁࠫཙ"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬཚ")+link
		l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ཛ")+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧཛྷ"))
		if l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠴ࡰࡩࡲࠪཝ") in url: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ཞ"),l111ll_l1_+title,link,732,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨཟ"),l111ll_l1_+title,link,733,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪའ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨཡ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ར")+link
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧལ"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ཤ"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ཥ")+title,link,731)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩས"),l11lll_l1_ (u"ࠩࠪཧ"),l11lll_l1_ (u"ࠪࠫཨ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨཀྵ"),url,l11lll_l1_ (u"ࠬ࠭ཪ"),l11lll_l1_ (u"࠭ࠧཫ"),l11lll_l1_ (u"ࠧࠨཬ"),l11lll_l1_ (u"ࠨࠩ཭"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭཮"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡱࡴࡼࡩࡦࡵࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡳࡤࡴ࡬ࡴࡹࠨ཯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨ࠾ࠨ཰"),block,re.DOTALL)
		for title,link,l1llll_l1_,l1l11l11l_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ཱࠧ")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨི")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"ཱིࠧࠡࠩ"))
			title = title+l11lll_l1_ (u"ࠨུࠢࠪ")+l1l11l11l_l1_.strip(l11lll_l1_ (u"ཱུࠩࠣࠫ"))
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩྲྀ"),l111ll_l1_+title,link,732,l1llll_l1_)
	return
def PLAY(url):
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰ࠳ࡳࡧࡵࡴ࡫ࡦࡥࡦ࠳࠳࠴࠲࠶࠹࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲ࡹࡴࡳࡧࡤࡱ࡮ࡴࡧ࠯ࡪࡷࡱࡱ࠭ཷ")
	l1lllll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩླྀ"),url,l11lll_l1_ (u"࠭ࠧཹ"),l11lll_l1_ (u"ࠧࠨེ"),l11lll_l1_ (u"ࠨཻࠩ"),l11lll_l1_ (u"ོࠩࠪ"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶཽࠪ"))
	html = response.content
	# l1l111lll_l1_ link
	links = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩཾ"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧཿ") not in link: link = link+l11lll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ྀࠩ")
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨཱྀ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ྂ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨྃ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"྄ࠪࠫ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ྅"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ྆"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ྇"))
	l1111_l1_ = [l11lll_l1_ (u"ࠧࠨྈ"),l11lll_l1_ (u"ࠨ࡯ࠪྉ")]
	l1l11l1ll_l1_ = [l11lll_l1_ (u"่ࠩืู้ไศฬࠪྊ"),l11lll_l1_ (u"ࠪหๆ๊วๆࠩྋ")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪྌ"), l1l11l1ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	type = l1111_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡬ࡪࡸࡨࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨྍ")+type+l11lll_l1_ (u"࠭ࠦࡲ࠿ࠪྎ")+search
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫྏ"),url,l11lll_l1_ (u"ࠨࠩྐ"),l11lll_l1_ (u"ࠩࠪྑ"),l11lll_l1_ (u"ࠪࠫྒ"),l11lll_l1_ (u"ࠫࠬྒྷ"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧྔ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬྕ"),html,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩྖ")+link
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪྗ"))
		if type==l11lll_l1_ (u"ࠩࡰࠫ྘"): addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩྙ"),l111ll_l1_+title,link,732)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྚ"),l111ll_l1_+title,link,733)
	return
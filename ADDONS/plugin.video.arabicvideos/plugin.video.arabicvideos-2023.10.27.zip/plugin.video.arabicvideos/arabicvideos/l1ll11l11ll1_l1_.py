# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚ࠬ䉾")
l11ll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭䉿")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11lll_l1_ (u"ࠧ࠱ࠩ䊀"),True)
	elif mode==102: results = ITEMS(l11lll_l1_ (u"ࠨ࠳ࠪ䊁"),True)
	elif mode==103: results = ITEMS(l11lll_l1_ (u"ࠩ࠵ࠫ䊂"),True)
	elif mode==104: results = ITEMS(l11lll_l1_ (u"ࠪ࠷ࠬ䊃"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11lll_l1_ (u"ࠫ࠹࠭䊄"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊅"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䊆")+l11lll_l1_ (u"ࠧใ๊สส๊ࠦแ๋ัํ์์อสࠡࡏ࠶࡙ࠬ䊇"),l11lll_l1_ (u"ࠨࠩ䊈"),762)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊉"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡠࠩ䊊")+l11lll_l1_ (u"ࠫ็๎วว็ࠣๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠪ䊋"),l11lll_l1_ (u"ࠬ࠭䊌"),761)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊍"),l11lll_l1_ (u"ࠧࡠࡖ࡙࠴ࡤ࠭䊎")+l11lll_l1_ (u"ࠨไ้์ฬะࠠๆ่้ࠣํอโฺ้สࠤฬ๊รึๆํอࠬ䊏"),l11lll_l1_ (u"ࠩࠪ䊐"),101)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊑"),l11lll_l1_ (u"ࠫࡤ࡚ࡖ࠵ࡡࠪ䊒")+l11lll_l1_ (u"่ࠬๆ้ษอࠤ๊ิสศำฬࠤ๊์๋๊ࠠอ๎ํฮࠧ䊓"),l11lll_l1_ (u"࠭ࠧ䊔"),106)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊕"),l11lll_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ䊖")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ䊗"),l11lll_l1_ (u"ࠪࠫ䊘"),147)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊙"),l11lll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ䊚")+l11lll_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䊛"),l11lll_l1_ (u"ࠧࠨ䊜"),148)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊝"),l11lll_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ䊞")+l11lll_l1_ (u"ࠪࠤ่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠠࠡࠩ䊟"),l11lll_l1_ (u"ࠫࠬ䊠"),28)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䊡"),l11lll_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬ䊢")+l11lll_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ䊣"),l11lll_l1_ (u"ࠨࠩ䊤"),41)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䊥"),l11lll_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩ䊦")+l11lll_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ䊧"),l11lll_l1_ (u"ࠬ࠭䊨"),135)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䊩"),l11lll_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭䊪")+l11lll_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ䊫"),l11lll_l1_ (u"ࠩࠪ䊬"),38)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䊭"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䊮"),l11lll_l1_ (u"ࠬ࠭䊯"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊰"),l11lll_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭䊱")+l11lll_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨ䊲"),l11lll_l1_ (u"ࠩࠪ䊳"),102)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊴"),l11lll_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪ䊵")+l11lll_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬ䊶"),l11lll_l1_ (u"࠭ࠧ䊷"),103)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊸"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ䊹")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪ䊺"),l11lll_l1_ (u"ࠪࠫ䊻"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡚ࡖࠨ䊼")+menu+l11lll_l1_ (u"ࠬࡥࠧ䊽")
	user = l11llll1111_l1_(32)
	payload = {l11lll_l1_ (u"࠭ࡩࡥࠩ䊾"):l11lll_l1_ (u"ࠧࠨ䊿"),l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䋀"):user,l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䋁"):l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䋂"),l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䋃"):menu}
	#data = l1ll1l1ll_l1_(payload)
	#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䋄"),str(payload))
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䋅"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䋆"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠨࠩ䋇"), True,l11lll_l1_ (u"ࠩࠪ䋈"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䋉"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䋊"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠬ࠭䋋"),l11lll_l1_ (u"࠭ࠧ䋌"),l11lll_l1_ (u"ࠧࠨ䋍"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䋎"))
	html = response.content
	#html = html.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ䋏"),l11lll_l1_ (u"ࠪࠫ䋐"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䋑"),l11lll_l1_ (u"ࠬ࠭䋒"),html,html)
	#file = open(l11lll_l1_ (u"࠭ࡳ࠻࠱ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬ䋓"), l11lll_l1_ (u"ࠧࡸࠩ䋔"))
	#file.write(html)
	#file.close()
	items = re.findall(l11lll_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩ䋕"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11lll_l1_ (u"ࠩࡤࡰࠬ䋖"),l11lll_l1_ (u"ࠪࡅࡱ࠭䋗"))
			start = start.replace(l11lll_l1_ (u"ࠫࡊࡲࠧ䋘"),l11lll_l1_ (u"ࠬࡇ࡬ࠨ䋙"))
			start = start.replace(l11lll_l1_ (u"࠭ࡁࡍࠩ䋚"),l11lll_l1_ (u"ࠧࡂ࡮ࠪ䋛"))
			start = start.replace(l11lll_l1_ (u"ࠨࡇࡏࠫ䋜"),l11lll_l1_ (u"ࠩࡄࡰࠬ䋝"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11lll_l1_ (u"ࠪࡅࡱ࠳ࠧ䋞"),l11lll_l1_ (u"ࠫࡆࡲࠧ䋟"))
			start = start.replace(l11lll_l1_ (u"ࠬࡇ࡬ࠡࠩ䋠"),l11lll_l1_ (u"࠭ࡁ࡭ࠩ䋡"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll1ll1_l1_,name,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠧࠤࠩ䋢") in source: continue
			#if source in [l11lll_l1_ (u"ࠨࡐࡗࠫ䋣"),l11lll_l1_ (u"ࠩ࡜࡙ࠬ䋤"),l11lll_l1_ (u"࡛ࠪࡘ࠶ࠧ䋥"),l11lll_l1_ (u"ࠫࡗࡒ࠱ࠨ䋦"),l11lll_l1_ (u"ࠬࡘࡌ࠳ࠩ䋧")]: continue
			if source!=l11lll_l1_ (u"࠭ࡕࡓࡎࠪ䋨"): name = name+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤࠥ࠭䋩")+source+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䋪")
			url = source+l11lll_l1_ (u"ࠩ࠾࠿ࠬ䋫")+server+l11lll_l1_ (u"ࠪ࠿ࡀ࠭䋬")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠫࡀࡁࠧ䋭")+menu
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䋮"),l111ll_l1_+l11lll_l1_ (u"࠭ࠧ䋯")+name,url,105,l1llll_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䋰"),l111ll_l1_+l11lll_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ䋱"),l11lll_l1_ (u"ࠩࠪ䋲"),9999)
		#if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䋳"),l11lll_l1_ (u"ࠫࠬ䋴"),l11lll_l1_ (u"ࠬ࠭䋵"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䋶"))
		#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䋷"),l111ll_l1_+l11lll_l1_ (u"ࠨๆ็วุ็ࠠๅษࠣฮําฯࠡไ้์ฬะࠠหๆไึํ์๊สࠢ็็ࠬ䋸"),l11lll_l1_ (u"ࠩࠪ䋹"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䋺"),l111ll_l1_+l11lll_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆสๆึฮวย๋ࠢห้อีะไสลࠥ็โุࠩ䋻"),l11lll_l1_ (u"ࠬ࠭䋼"),9999)
		#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䋽"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䋾"),l11lll_l1_ (u"ࠨࠩ䋿"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䌀"),l111ll_l1_+l11lll_l1_ (u"࡙ࠪࡳ࡬࡯ࡳࡶࡸࡲࡦࡺࡥ࡭ࡻ࠯ࠤࡳࡵࠠࡕࡘࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠥ࡬࡯ࡳࠢࡼࡳࡺ࠭䌁"),l11lll_l1_ (u"ࠫࠬ䌂"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䌃"),l111ll_l1_+l11lll_l1_ (u"࠭ࡉࡵࠢ࡬ࡷࠥ࡬࡯ࡳࠢࡵࡩࡱࡧࡴࡪࡸࡨࡷࠥࠬࠠࡧࡴ࡬ࡩࡳࡪࡳࠡࡱࡱࡰࡾ࠭䌄"),l11lll_l1_ (u"ࠧࠨ䌅"),9999)
	return
def PLAY(id):
	source,server,l11lll1ll1_l1_,menu = id.split(l11lll_l1_ (u"ࠨ࠽࠾ࠫ䌆"))
	url = l11lll_l1_ (u"ࠩࠪ䌇")
	user = l11llll1111_l1_(32)
	if source==l11lll_l1_ (u"࡙ࠪࡗࡒࠧ䌈"): url = l11lll1ll1_l1_
	elif source==l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ䌉"):
		url = l1ll11l_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䌊")][0]+l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䌋")+l11lll1ll1_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䌌"),url)
		return
	elif source==l11lll_l1_ (u"ࠨࡉࡄࠫ䌍"):
		payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ䌎") : l11lll_l1_ (u"ࠪࠫ䌏"), l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ䌐") : user , l11lll_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ䌑") : l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠷ࠧ䌒") , l11lll_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ䌓") : l11lll_l1_ (u"ࠨࠩ䌔") }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䌕"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠪࠫ䌖"),False,l11lll_l1_ (u"ࠫࠬ䌗"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䌘"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䌙"),l11lll_l1_ (u"ࠧࠨ䌚"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌛"),l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䌜"))
			return
		html = response.content
		cookies = response.cookies
		l1l11111lll1_l1_ = cookies[l11lll_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪࠧ䌝")]
		url = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䌞")]
		payload = { l11lll_l1_ (u"ࠬ࡯ࡤࠨ䌟") : l11lll1ll1_l1_ , l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ䌠") : user , l11lll_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ䌡") : l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡍࡁ࠳ࠩ䌢") , l11lll_l1_ (u"ࠩࡰࡩࡳࡻࠧ䌣") : l11lll_l1_ (u"ࠪࠫ䌤") }
		headers = { l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䌥") : l11lll_l1_ (u"ࠬࡇࡓࡑ࠰ࡑࡉ࡙ࡥࡓࡦࡵࡶ࡭ࡴࡴࡉࡥ࠿ࠪ䌦")+l1l11111lll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䌧"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠧࠨ䌨"),l11lll_l1_ (u"ࠨࠩ䌩"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䌪"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䌫"),l11lll_l1_ (u"ࠫࠬ䌬"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䌭"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䌮"))
			return
		html = response.content
		url = re.findall(l11lll_l1_ (u"ࠧࡳࡧࡶࡴࠧࡀࠢࠩࡪࡷࡸࡵ࠴ࠪࡀ࡯࠶ࡹ࠽࠯ࠨ࠯ࠬࡂ࠭ࠧ࠭䌯"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ䌰"),l11lll_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬࠢࠪ䌱")+link)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ䌲"),l11lll_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠬ䌳")+params)
		l1l11111ll1l_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠸࠯ࠩ䌴")+server+l11lll_l1_ (u"࠭࠷࠸࠹࠲ࠫ䌵")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ䌶")+params
		l1l11111ll11_l1_ = l1l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠨ࠵࠹࠾࠼࠭䌷"),l11lll_l1_ (u"ࠩ࠷࠴࠿࠽ࠧ䌸")).replace(l11lll_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ䌹"),l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䌺"))
		l1l11111llll_l1_ = l1l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ䌻"),l11lll_l1_ (u"࠭࠴࠳࠼࠺ࠫ䌼")).replace(l11lll_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ䌽"),l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䌾"))
		l1lll1ll_l1_ = [l11lll_l1_ (u"ࠩࡋࡈࠬ䌿"),l11lll_l1_ (u"ࠪࡗࡉ࠷ࠧ䍀"),l11lll_l1_ (u"ࠫࡘࡊ࠲ࠨ䍁")]
		l1111_l1_ = [l1l11111ll1l_l1_,l1l11111ll11_l1_,l1l11111llll_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ䍂"), l1lll1ll_l1_)
		if l1l_l1_ == -1: return
		else: url = l1111_l1_[l1l_l1_]
	elif source==l11lll_l1_ (u"࠭ࡎࡕࠩ䍃"):
		headers = { l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䍄") : l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䍅") }
		payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ䍆") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䍇") : user , l11lll_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭䍈") : l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡑࡘࠬ䍉") , l11lll_l1_ (u"࠭࡭ࡦࡰࡸࠫ䍊") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䍋"), l11ll1_l1_, payload, headers, False,l11lll_l1_ (u"ࠨࠩ䍌"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䍍"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䍎"),l11lll_l1_ (u"ࠫࠬ䍏"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䍐"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䍑"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䍒")]
		url = url.replace(l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ䍓"),l11lll_l1_ (u"ࠩࠣࠫ䍔"))
		url = url.replace(l11lll_l1_ (u"ࠪࠩ࠸ࡊࠧ䍕"),l11lll_l1_ (u"ࠫࡂ࠭䍖"))
		if l11lll_l1_ (u"ࠬࡒࡥࡢࡴࡱࠫ䍗") in l11lll1ll1_l1_:
			url = url.replace(l11lll_l1_ (u"࠭ࡎࡕࡐࡑ࡭ࡱ࡫ࠧ䍘"),l11lll_l1_ (u"ࠧࠨ䍙"))
			url = url.replace(l11lll_l1_ (u"ࠨ࡮ࡨࡥࡷࡴࡩ࡯ࡩ࠴ࠫ䍚"),l11lll_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࡪࡰࡪࠫ䍛"))
	elif source==l11lll_l1_ (u"ࠪࡔࡑ࠭䍜"):
		#headers = { l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䍝") : l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䍞") }
		payload = { l11lll_l1_ (u"࠭ࡩࡥࠩ䍟") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ䍠") : user , l11lll_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ䍡") : l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡐࡍࠩ䍢") , l11lll_l1_ (u"ࠪࡱࡪࡴࡵࠨ䍣") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䍤"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠬ࠭䍥"),False,l11lll_l1_ (u"࠭ࠧ䍦"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ䍧"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䍨"),l11lll_l1_ (u"ࠩࠪ䍩"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䍪"),l11lll_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ䍫"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䍬")]
		headers = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䍭"):response.headers[l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䍮")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䍯"),url, l11lll_l1_ (u"ࠩࠪ䍰"),headers , l11lll_l1_ (u"ࠪࠫ䍱"),l11lll_l1_ (u"ࠫࠬ䍲"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧ䍳"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䍴"),l11lll_l1_ (u"ࠧࠨ䍵"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䍶"),l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䍷"))
			return
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䍸"),html,re.DOTALL)
		url = items[0]
	elif source in [l11lll_l1_ (u"࡙ࠫࡇࠧ䍹"),l11lll_l1_ (u"ࠬࡌࡍࠨ䍺"),l11lll_l1_ (u"࡙࠭ࡖࠩ䍻"),l11lll_l1_ (u"ࠧࡘࡕ࠴ࠫ䍼"),l11lll_l1_ (u"ࠨ࡙ࡖ࠶ࠬ䍽"),l11lll_l1_ (u"ࠩࡕࡐ࠶࠭䍾"),l11lll_l1_ (u"ࠪࡖࡑ࠸ࠧ䍿")]:
		if source==l11lll_l1_ (u"࡙ࠫࡇࠧ䎀"): l11lll1ll1_l1_ = id
		headers = { l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䎁") : l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䎂") }
		payload = { l11lll_l1_ (u"ࠧࡪࡦࠪ䎃") : l11lll1ll1_l1_ , l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䎄") : user , l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䎅") : l11lll_l1_ (u"ࠪࡴࡱࡧࡹࠨ䎆")+source , l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䎇") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䎈"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"࠭ࠧ䎉"),l11lll_l1_ (u"ࠧࠨ䎊"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪ䎋"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䎌"),l11lll_l1_ (u"ࠪࠫ䎍"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䎎"),l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭䎏"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䎐")]
		if source==l11lll_l1_ (u"ࠧࡇࡏࠪ䎑"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䎒"), url, l11lll_l1_ (u"ࠩࠪ䎓"), l11lll_l1_ (u"ࠪࠫ䎔"), False,l11lll_l1_ (u"ࠫࠬ䎕"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠻ࡹ࡮ࠧ䎖"))
			url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䎗")]
			url = url.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䎘"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭䎙"))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䎚"))
	return
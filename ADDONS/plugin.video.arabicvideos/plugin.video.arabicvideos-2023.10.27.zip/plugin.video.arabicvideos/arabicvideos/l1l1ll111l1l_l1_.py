# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ剘")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ剙")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอๆ้ษ฼ࠤฬ็ไศ็ࠪ剚"),l11lll_l1_ (u"࠭ฬ้ัสฮࠥอแๅษ่ࠫ剛")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1111l_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llllll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ剜"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ剝"),l11lll_l1_ (u"ࠩࠪ剞"),389,l11lll_l1_ (u"ࠪࠫ剟"),l11lll_l1_ (u"ࠫࠬ剠"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ剡"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ剢"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ剣"),l11lll_l1_ (u"ࠨࠩ剤"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ剥"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ剦")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ剧"),l11ll1_l1_,381,l11lll_l1_ (u"ࠬ࠭剨"),l11lll_l1_ (u"࠭ࠧ剩"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ剪"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ剫"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ剬")+l111ll_l1_+l11lll_l1_ (u"ࠪห้าว็สํอࠬ剭"),l11ll1_l1_,381,l11lll_l1_ (u"ࠫࠬ剮"),l11lll_l1_ (u"ࠬ࠭副"),l11lll_l1_ (u"࠭ࡳࡪࡦࡨࡶࠬ剰"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ剱"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ割"),l11lll_l1_ (u"ࠩࠪ剳"),l11lll_l1_ (u"ࠪࠫ剴"),l11lll_l1_ (u"ࠫࠬ創"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ剶"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"࠭࠼ࡩࡧࡤࡨࡪࡸ࠾࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ剷"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ剸"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ剹")+l111ll_l1_+title,l11ll1_l1_,381,l11lll_l1_ (u"ࠩࠪ剺"),l11lll_l1_ (u"ࠪࠫ剻"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ剼")+str(seq))
	block = l11lll_l1_ (u"ࠬ࠭剽")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫ剾"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠩ࠰࠭ࡃ࠮ࡧࡳࡪࡦࡨࠫ剿"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ劀"),block,re.DOTALL)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ劁"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ劂"),l11lll_l1_ (u"ࠫࠬ劃"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬ劄"):
			if first:
				title = l11lll_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨ劅")+title
				first = False
			else: title = l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫ劆")+title
		if title not in l1l1l1_l1_:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ劇"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ劈")+l111ll_l1_+title,link,381)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ劉"),l11lll_l1_ (u"ࠫࠬ劊"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ劋"),url,l11lll_l1_ (u"࠭ࠧ劌"),l11lll_l1_ (u"ࠧࠨ劍"),l11lll_l1_ (u"ࠨࠩ劎"),l11lll_l1_ (u"ࠩࠪ劏"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ劐"))
	html = response.content
	if type==l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ劑"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡥࡢࡴࡦ࡬࠲ࡶࡡࡨࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ劒"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ劓"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡴ࡫ࡧࡩࡷ࠭劔"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸࠬ劕"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		z = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ劖"),block,re.DOTALL)
		l1111_l1_,l1l111l11_l1_,l1lll1ll_l1_ = zip(*z)
		items = zip(l1l111l11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ劗"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡶࡹࡷ࡭ࡵࡷࡴࠤࠫ࠲࠯ࡅࠩ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ劘"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ劙"),block,re.DOTALL)
	elif l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭劚") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠧ࠽ࡪࡨࡥࡩ࡫ࡲ࠿ࠩ力"),l11lll_l1_ (u"ࠨ࠾ࡨࡲࡩࡄ࠼ࡴࡶࡤࡶࡹࡄࠧ劜"))
		html = html.replace(l11lll_l1_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ劝"),l11lll_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧ办"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡴࡢࡴࡷࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡳࡪ࠾ࠨ功"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==2: items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ加"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠮ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࡿࡷ࡮ࡪࡥࡣࡣࡵ࠭ࠬ务"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭劢") in url:
				items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ劣"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠩ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳ࠬ劤") in url:
				items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ劥"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭劦"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࠫ劧") in title:
			title = re.findall(l11lll_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡩࡷ࡯ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ动"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ助")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ努")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾ࠪ劫"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭劬") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ劭"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ劮") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭劯"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ劰") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ励"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ劲") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ劳"),l111ll_l1_+title,link,381,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ労"),l111ll_l1_+title,link,382,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡖࡡࡨࡧࠣࠬ࠳࠰࠿ࠪࠢࡲࡪࠥ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ劵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		current = l1l1ll1_l1_[0][0]
		last = l1l1ll1_l1_[0][1]
		block = l1l1ll1_l1_[0][2]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ劶"),block,re.DOTALL)
		for link,title in items:
			if title==l11lll_l1_ (u"ࠧࠨ劷") or title==last: continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ劸"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ効")+title,link,381,l11lll_l1_ (u"ࠪࠫ劺"),l11lll_l1_ (u"ࠫࠬ劻"),type)
		#if title==last:
		link = link.replace(l11lll_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ劼")+title+l11lll_l1_ (u"࠭࠯ࠨ劽"),l11lll_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ劾")+last+l11lll_l1_ (u"ࠨ࠱ࠪ势"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ勀"),l111ll_l1_+l11lll_l1_ (u"ࠪหำืࠠึใะอࠥ࠭勁")+last,link,381,l11lll_l1_ (u"ࠫࠬ勂"),l11lll_l1_ (u"ࠬ࠭勃"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ勄"),url,l11lll_l1_ (u"ࠧࠨ勅"),l11lll_l1_ (u"ࠨࠩ勆"),l11lll_l1_ (u"ࠩࠪ勇"),l11lll_l1_ (u"ࠪࠫ勈"),l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ勉"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ勊"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,False):
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ勋"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่ืู้ไࠡๆ็็ออั๊ࠡส่๊ฮัๆฮ้๋ࠣ฿็ࠨ勌"),l11lll_l1_ (u"ࠨࠩ勍"),9999)
		return
	if l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭勎") in url or l11lll_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭勏") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡩࡵࡧࡰࠫࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ勐"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[1]
			l1llllll_l1_(l11l11l_l1_)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡦࡲ࡬ࡷࡴࡪࡩࡰࡵࠪࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩࡡࡴࡶࠥࠫࠬ࠭勑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡰࡸࡱࡪࡸࡡ࡯ࡦࡲࠫࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠧࠨ勒"),block,re.DOTALL)
		for l1llll_l1_,l1lll11_l1_,link,name in items:
			title = l1lll11_l1_+l11lll_l1_ (u"ࠧࠡ࠼ࠣࠫ勓")+name+l11lll_l1_ (u"ࠨࠢส่า๊โสࠩ勔")
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ動"),l111ll_l1_+title,link,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ勖"),url,l11lll_l1_ (u"ࠫࠬ勗"),l11lll_l1_ (u"ࠬ࠭勘"),l11lll_l1_ (u"࠭ࠧ務"),l11lll_l1_ (u"ࠧࠨ勚"),l11lll_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ勛"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ勜"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠦࠧ࡯ࡤ࠾ࠩࡳࡰࡦࡿࡥࡳ࠯ࡲࡴࡹ࡯࡯࡯࠯࠴ࠫ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠪࠥࡷ࡭࡫ࡡࡥࡧࡵࠦࢁ࠭ࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࠯ࠢࠣࠤ勝"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡶࡩࡷࡼࡥࡳࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥ勞"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭募")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ勠")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲ࠭ࡤ࡮ࡲࡷࡪࠨࠧ勡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡡࡢࡣࡩࡲ࡟ࡨࡦࡵ࡭ࡻ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ勢"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ勣")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ勤")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ勥"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ勦"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ勧"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ勨"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ勩"),l11lll_l1_ (u"ࠩ࠮ࠫ勪"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ勫")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ勬"))
	return
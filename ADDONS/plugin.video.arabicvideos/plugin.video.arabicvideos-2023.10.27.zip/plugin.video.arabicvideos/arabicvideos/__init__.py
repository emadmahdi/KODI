# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll111_l1_ import *
script_name = l11lll_l1_ (u"ࠫࡎࡔࡉࡕࠩ矏")
LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ矐"),l11lll_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠫ矑"))
l1l1l1l11l1_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = l1l1l1l11l1_l1_
l1l1ll11ll11_l1_ = int(mode)
l1ll11l1l111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ矒"))
l1ll11l1l111_l1_ = l1ll11l1l111_l1_.replace(ltr,l11lll_l1_ (u"ࠨࠩ矓")).replace(rtl,l11lll_l1_ (u"ࠩࠪ矔"))
if l1l1ll11ll11_l1_==260: message = l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ矕")+l11l1llllll_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ矖")+l11lll111l1_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ矗")
else:
	l1ll11ll111ll_l1_ = l111l_l1_(addon_path).replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ矘"),l11lll_l1_ (u"ࠧࠨ矙")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ矚"),l11lll_l1_ (u"ࠩࠪ矛"))
	l1ll11ll111ll_l1_ = l1ll11ll111ll_l1_.replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ矜"),l11lll_l1_ (u"ࠫࠬ矝")).strip(l11lll_l1_ (u"ࠬࠦࠧ矞"))
	l1ll11ll111ll_l1_ = l1ll11ll111ll_l1_.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ矟"),l11lll_l1_ (u"ࠧࠡࠩ矠")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ矡"),l11lll_l1_ (u"ࠩࠣࠫ矢")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭矣"),l11lll_l1_ (u"ࠫࠥ࠭矤"))
	message = l11lll_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ知")+l1ll11l1l111_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭矦")+mode+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ矧")+l1ll11ll111ll_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ矨")
LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ矩"),LOGGING(script_name)+message)
l1l1l1ll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ矪"))
l1llll11lll1_l1_ = True if l1l1l1ll1lll_l1_==l11l1llllll_l1_ else False
if not l1llll11lll1_l1_ and l1l1ll11ll11_l1_ in [235,715]:
	l11lllllll1l_l1_ = str(l1ll11111l1_l1_[l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ矫")])
	script_name = l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ矬") if l1l1ll11ll11_l1_==235 else l11lll_l1_ (u"࠭࡭࠴ࡷࠪ短")
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࠫ矮")+script_name+l11lll_l1_ (u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭矯")+l11lllllll1l_l1_)
	l11l11l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭矰")+script_name+l11lll_l1_ (u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭矱")+l11lllllll1l_l1_)
	if l111llll1l_l1_ or l11l11l11l_l1_:
		url += l11lll_l1_ (u"ࠫࢁ࠭矲")
		if l111llll1l_l1_: url += l11lll_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ石")+l111llll1l_l1_
		if l11l11l11l_l1_: url += l11lll_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ矴")+l11l11l11l_l1_
		url = url.replace(l11lll_l1_ (u"ࠧࡽࠨࠪ矵"),l11lll_l1_ (u"ࠨࡾࠪ矶"))
	l1111l1ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭矷")+script_name+l11lll_l1_ (u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ矸")+l11lllllll1l_l1_)
	if l1111l1ll1_l1_:
		l11lll1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ矹"),url,re.DOTALL)
		url = url.replace(l11lll1l11ll_l1_[0],l1111l1ll1_l1_)
	script_name = script_name.upper()
	l11llll111l_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠬ࠭矺")
	l1ll11l11_l1_(l11lll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ矻"))
	try: l1lll111ll1l_l1_(l1l1l1l11l1_l1_,l1ll11l1l111_l1_)
	except Exception as error: l1lll1lllll1_l1_ = traceback.format_exc()
	l1ll11l11_l1_(l11lll_l1_ (u"ࠧࡴࡶࡲࡴࠬ矼"))
	l1l1lll11111_l1_(l1lll1lllll1_l1_)
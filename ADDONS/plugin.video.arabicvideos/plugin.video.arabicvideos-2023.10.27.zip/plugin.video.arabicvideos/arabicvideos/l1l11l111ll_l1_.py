# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ㑗")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡏ࡙ࡑ࡟ࠨ㑘")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ㑙"),l11lll_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ㑚"),l11lll_l1_ (u"ࠬอไฤไึห๊࠭㑛")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l1111l_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l11111_l1_(url,text)
	elif mode==674: results = l1l11l_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㑜"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㑝"),l11lll_l1_ (u"ࠨࠩ㑞"),l11lll_l1_ (u"ࠩࠪ㑟"),l11lll_l1_ (u"ࠪࠫ㑠"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㑡"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㑢"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㑣"),l11lll_l1_ (u"ࠧࠨ㑤"),679,l11lll_l1_ (u"ࠨࠩ㑥"),l11lll_l1_ (u"ࠩࠪ㑦"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㑧"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㑨"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㑩"),l11lll_l1_ (u"࠭ࠧ㑪"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㑫"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㑬")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ㑭"),l11ll1_l1_,671,l11lll_l1_ (u"ࠪࠫ㑮"),l11lll_l1_ (u"ࠫࠬ㑯"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㑰"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㑱"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㑲")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ㑳"),l11ll1_l1_,671,l11lll_l1_ (u"ࠩࠪ㑴"),l11lll_l1_ (u"ࠪࠫ㑵"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㑶"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㑷"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㑸")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭㑹"),l11ll1_l1_,671,l11lll_l1_ (u"ࠨࠩ㑺"),l11lll_l1_ (u"ࠩࠪ㑻"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ㑼"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑽"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㑾")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪ㑿"),l11ll1_l1_,671,l11lll_l1_ (u"ࠧࠨ㒀"),l11lll_l1_ (u"ࠨࠩ㒁"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㒂"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㒃"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㒄"),l11lll_l1_ (u"ࠬ࠭㒅"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㒆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㒇"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			if title==l11lll_l1_ (u"ࠨษ็ว็ูวๆࠩ㒈"): mode = 675
			else: mode = 674
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㒉"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㒊")+l111ll_l1_+title,link,mode)
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㒋"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㒌"),l11lll_l1_ (u"࠭ࠧ㒍"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ㒎"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ㒏"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠩࠪ㒐"))
	#items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㒑"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㒒"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㒓")+l111ll_l1_+title,link,674)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㒔"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㒕"),l11lll_l1_ (u"ࠨࠩ㒖"),9999)
	items = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡥࡶࡴࡽࡳࡦ࠰࡫ࡸࡲࡲࠧ㒗"))
	for link,l1llll_l1_,title in items:
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㒘"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㒙")+l111ll_l1_+title,link,674,l1llll_l1_)
	return
def CATEGORIES(url):
	l1ll1l11l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ㒚"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ㒛"),l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ㒜"))
	if l1ll1l11l1_l1_: return l1ll1l11l1_l1_
	#DIALOG_OK()
	l1ll1l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㒝"),url,l11lll_l1_ (u"ࠩࠪ㒞"),l11lll_l1_ (u"ࠪࠫ㒟"),l11lll_l1_ (u"ࠫࠬ㒠"),l11lll_l1_ (u"ࠬ࠭㒡"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ㒢"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰࡬ࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ㒣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1ll1l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㒤"),block,re.DOTALL)
		if l1ll1l11l1_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ㒥"),l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ㒦"),l1ll1l11l1_l1_,l11111l_l1_)
	return l1ll1l11l1_l1_
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㒧"),url,l11lll_l1_ (u"ࠬ࠭㒨"),l11lll_l1_ (u"࠭ࠧ㒩"),l11lll_l1_ (u"ࠧࠨ㒪"),l11lll_l1_ (u"ࠨࠩ㒫"),l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㒬"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㒭"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ㒮"),l11lll_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ㒯"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㒰"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠧࠨ㒱"),block)]
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㒲"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㒳"),l11lll_l1_ (u"ࠪࠫ㒴"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㒵"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠬࡀࠠࠨ㒶")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㒷"),l111ll_l1_+title,link,671)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㒸"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㒹"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㒺"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㒻"),l11lll_l1_ (u"ࠫࠬ㒼"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㒽"),l111ll_l1_+title,link,671)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"࠭ࠧ㒾")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㒿"),l11lll_l1_ (u"ࠨࠩ㓀"),request,url)
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ㓁"):
		url,search = url.split(l11lll_l1_ (u"ࠪࡃࠬ㓂"),1)
		data = l11lll_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ㓃")+search
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㓄"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭㓅")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㓆"),url,data,headers,l11lll_l1_ (u"ࠨࠩ㓇"),l11lll_l1_ (u"ࠩࠪ㓈"),l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㓉"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㓊"),url,l11lll_l1_ (u"ࠬ࠭㓋"),l11lll_l1_ (u"࠭ࠧ㓌"),l11lll_l1_ (u"ࠧࠨ㓍"),l11lll_l1_ (u"ࠨࠩ㓎"),l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㓏"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠪࠫ㓐"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ㓑"))
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ㓒"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㓓"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨ㓔"),link,title))
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ㓕"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲ࡽࡡࡵࡥ࡫࠱࡫࡫ࡡࡵࡷࡵࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㓖"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㓗"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㓘"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㓙"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㓚"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ㓛"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡫ࡳࡲ࡫࠭ࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࡞ࡠࡹࢂ࡜࡯࡟࠭ࡀ࠴ࡪࡩࡷࡀࠪ㓜"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㓝"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ㓞"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㓟"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㓠"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"࠭ๅีษ๊ำฮ࠭㓡"),l11lll_l1_ (u"ࠧโ์็้ࠬ㓢"),l11lll_l1_ (u"ࠨษ฽๊๏ฯࠧ㓣"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ㓤"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ㓥"),l11lll_l1_ (u"ࠫ์ีวโࠩ㓦"),l11lll_l1_ (u"๋ࠬศศำสอࠬ㓧"),l11lll_l1_ (u"ู࠭าุࠪ㓨"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ㓩"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ㓪"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ㓫"),l11lll_l1_ (u"ࠪๅ้๋ࠧ㓬")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭㓭"))
		#if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㓮") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ㓯")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ㓰"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㓱") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㓲")+l1llll_l1_.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㓳"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭㓴"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ㓵"),title,re.DOTALL)
		#addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㓶"),l111ll_l1_+title,link,672,l1llll_l1_)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㓷"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ㓸"):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㓹"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㓺") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓻"),l111ll_l1_+title,link,673,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ㓼") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓽"),l111ll_l1_+title,link,671,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㓾"),l111ll_l1_+title,link,673,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㓿"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ㔀"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠪࠧࠬ㔁"): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㔂") not in link:
				l11l11l_l1_ = url.rsplit(l11lll_l1_ (u"ࠬ࠵ࠧ㔃"),1)[0]
				link = l11l11l_l1_+l11lll_l1_ (u"࠭࠯ࠨ㔄")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ㔅"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔆"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ㔇")+title,link,671,l11lll_l1_ (u"ࠪࠫ㔈"),l11lll_l1_ (u"ࠫࠬ㔉"),request)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㔊"),l11lll_l1_ (u"࠭ࠧ㔋"),l1ll1_l1_,url)
	addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㔌"),l111ll_l1_+l11lll_l1_ (u"ࠨฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ㔍"),url,672)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㔎"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㔏"),l11lll_l1_ (u"ࠫࠬ㔐"),9999)
	l1ll1l11l1_l1_ = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡨࡲࡰࡹࡶࡩ࠳࡮ࡴ࡮࡮ࠪ㔑"))
	l1l11l111l1_l1_,l1l11l1111l_l1_,l1l11l1l111_l1_ = zip(*l1ll1l11l1_l1_)
	l1l11l11l11_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㔒"),url,l11lll_l1_ (u"ࠧࠨ㔓"),l11lll_l1_ (u"ࠨࠩ㔔"),l11lll_l1_ (u"ࠩࠪ㔕"),l11lll_l1_ (u"ࠪࠫ㔖"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ㔗"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡶࡪࡦࡨࡳ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠩ㔘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡺࡄࡸࡸࡹࡵ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㔙"),block,re.DOTALL)
		for link,title in links:
			if link not in l1l11l111l1_l1_:
				item = (link,title)
				l1l11l11l11_l1_.append(item)
		if len(l1l11l11l11_l1_)==1:
			link,title = l1l11l11l11_l1_[0]
			l1111l_l1_(link,l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㔚"))
			return
		else:
			for link,title in l1l11l11l11_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔛"),l111ll_l1_+title,link,671,l11lll_l1_ (u"ࠩࠪ㔜"),l11lll_l1_ (u"ࠪࠫ㔝"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㔞"))
	if not l1l11l11l11_l1_: l1111l_l1_(url,l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㔟"))
	return
#https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l11ll1l111_l1_.l1ll1lllll_l1_?l1l11l11lll_l1_=l1l11l11ll1_l1_
#https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1l111lll_l1_.l1ll1lllll_l1_?l1l11l11lll_l1_=l1l11l11ll1_l1_
def PLAY(url):
	l1lllll1_l1_ = []
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨ࠰ใํ่๊࠳ใาฬ๋๊࠲ฮวาสํ࠱ๆ๐࠭ๆ฼ส้ึฯ࠭ๆฬ็ว้ฬษ࠮็าฬࡤࡪ࠹࠸࠷ࡦࡦ࠼࠻࠳࠯ࡪࡷࡱࡱ࠭㔠")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㔡"),url,l11lll_l1_ (u"ࠨࠩ㔢"),l11lll_l1_ (u"ࠩࠪ㔣"),l11lll_l1_ (u"ࠪࠫ㔤"),l11lll_l1_ (u"ࠫࠬ㔥"),l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ㔦"))
	html = response.content
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡬࡬ࡢࡵ࡫ࡴࡱࡧࡹࡦࡴࠪ㔧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ㔨"),block,re.DOTALL)
		for link,l11l111l_l1_ in links:
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࡡࡢࠫ㔩")+l11l111l_l1_
			l1lllll1_l1_.append(link)
	# l1l111lll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡦࡨࡨ࠲ࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㔪"),html,re.DOTALL)
	if not links: links = re.findall(l11lll_l1_ (u"ࠥࡪ࡮ࡲࡥ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ㔫"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ㔬") not in link: link = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㔭")+link
		l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ㔮"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ㔯"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㔰"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ㔱"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ㔲"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭㔳"),l11lll_l1_ (u"ࠬ࠱ࠧ㔴"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭㔵")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ㔶"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ㔷")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ㔸"))
	return
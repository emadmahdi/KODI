# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭ᗊ")
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᗋ"):l11lll_l1_ (u"ࠨࠩᗌ")}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨᗍ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧᗎ"),l11lll_l1_ (u"ࠫฬิั๋ࠩᗏ"),l11lll_l1_ (u"ࠬอฮา๋ࠪᗐ"),l11lll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᗑ"),l11lll_l1_ (u"ࠧษั๋๊ࠥหฮห์สีࠬᗒ"),l11lll_l1_ (u"ࠨษไ่ฬ๋ࠧᗓ"),l11lll_l1_ (u"่ࠩืู้ไศฬࠪᗔ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l1111l_l1_(url,text)
	elif mode==422: results = l1lll1llll_l1_(url)
	elif mode==423: results = l1llllll_l1_(url)
	elif mode==424: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩᗕ")+text)
	elif mode==425: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗖ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l1llll11ll_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1lllll11l_l1_(l11lll_l1_ (u"ࠬࡍࡅࡕࠩᗗ"),l11ll1_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧᗘ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᗙ"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᗚ"),l11lll_l1_ (u"ࠩࠪᗛ"),l11lll_l1_ (u"ࠪࠫᗜ"),l11lll_l1_ (u"ࠫࠬᗝ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᗞ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᗟ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩᗠ"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᗡ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᗣ"),l11lll_l1_ (u"ࠫࠬᗤ"),429,l11lll_l1_ (u"ࠬ࠭ᗥ"),l11lll_l1_ (u"࠭ࠧᗦ"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᗧ"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗨ"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᗩ"),l1ll1l1_l1_,425)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗪ"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧᗫ"),l1ll1l1_l1_,424)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᗬ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᗭ"),l11lll_l1_ (u"ࠧࠨᗮ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗯ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗰ")+l111ll_l1_+l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬᗱ"),l1ll1l1_l1_,421)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗲ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᗳ")+l111ll_l1_+l11lll_l1_ (u"࠭รโๆส้ࠥอไ็ฮ๋้ࠬᗴ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳ࠰ࠩᗵ"),421)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗶ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗷ")+l111ll_l1_+l11lll_l1_ (u"๊ࠪ๏ะแๅๅึࠫᗸ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡴࡥࡵࡨ࡯࡭ࡽ࠵ࠧᗹ"),421)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᗺ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗻ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠧ࠰ࡣࡦࡸࡴࡸࡳࠨᗼ") in link: title = l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠศๆ้ะํ๋ࠧᗽ")
		elif l11lll_l1_ (u"ࠩ࠲ࡲࡪࡺࡦ࡭࡫ࡻࠫᗾ") in link: title = l11lll_l1_ (u"ࠪวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๋๐สโๆๆืࠬᗿ")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘀ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᘁ")+l111ll_l1_+title,link,421)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘂ"),l111ll_l1_+l11lll_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧᘃ"),l1ll1l1_l1_,427)
	return
def l1llll11ll_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠨࠩᘄ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᘅ"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫᘆ"),l11lll_l1_ (u"ࠫࠬᘇ"),l11lll_l1_ (u"ࠬ࠭ᘈ"),l11lll_l1_ (u"࠭ࠧᘉ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᘊ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡘ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯ࡐࡢࡩࡨࡘ࡮ࡺ࡬ࡦࠩᘋ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᘌ"),block,re.DOTALL)
	for category,id,link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻ࠱ࡲࡵࡶࡪࡧࡶࠫᘍ") in link: title = l11lll_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫᘎ")
		elif l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠲ࡴࡥࡵࡨ࡯࡭ࡽ࠭ᘏ") in link: title = l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨᘐ")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘑ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᘒ")+l111ll_l1_+title,link,421,l11lll_l1_ (u"ࠩࠪᘓ"),l11lll_l1_ (u"ࠪࠫᘔ"),category+l11lll_l1_ (u"ࠫࢁ࠭ᘕ")+id)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"ࠬ࠭ᘖ")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧᘗ"),l11lll_l1_ (u"ࠧࠨᘘ"),l1lll1ll11_l1_,url)
	if l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫ࡰࡢࡩࡨࡐࡴࡧࡤࡦࡴ࠲ࠫᘙ") in url: url = url.strip(l11lll_l1_ (u"ࠩ࠲ࠫᘚ"))+l11lll_l1_ (u"ࠪ࠳ࡲࡶࡡࡢ࠱ࡩࡥࡲ࡯࡬ࡺ࠱ࠪᘛ")
	items = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᘜ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᘝ"),url,l11lll_l1_ (u"࠭ࠧᘞ"),headers,l11lll_l1_ (u"ࠧࠨᘟ"),l11lll_l1_ (u"ࠨࠩᘠ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᘡ"))
	html = response.content
	if not l1lll1ll11_l1_ or l11lll_l1_ (u"ࠪࢀࠬᘢ") in l1lll1ll11_l1_:
		#if l11lll_l1_ (u"ࠫࡒࡻ࡬ࡵ࡫ࡉ࡭ࡱࡺࡥࡳࠩᘣ") in html:
		#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘤ"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩᘥ"),url,425)
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᘦ"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫᘧ"),url,424)
		#	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᘨ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᘩ"),l11lll_l1_ (u"ࠫࠬᘪ"),9999)
		if l11lll_l1_ (u"ࠬࢂࠧᘫ") not in l1lll1ll11_l1_: l1lll1lll1_l1_ = l11lll_l1_ (u"࠭ࠧᘬ")
		else: l1lll1lll1_l1_ = l11lll_l1_ (u"ࠧ࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠱ࠪᘭ")+l1lll1ll11_l1_
		separator = False
		if l11lll_l1_ (u"ࠨࡒ࡬ࡲࡘࡲࡩࡥࡧࡵࠫᘮ") in html:
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᘯ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᘰ"),url,421,l11lll_l1_ (u"ࠫࠬᘱ"),l11lll_l1_ (u"ࠬ࠭ᘲ"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᘳ"))
			separator = True
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩࡈࡵ࡮ࡵࡧࡱࡸࠬᘴ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l1_l1_ = l1l1ll1_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡤࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᘵ"),l11l1_l1_,re.DOTALL)
			for l1llllll1l_l1_,l1lll1lll_l1_ in l1l1lll_l1_:
				l1lllll1ll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡤࡧࡱࡸࡪࡸ࠯ࡢࡥࡷ࡭ࡴࡴ࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࡶࡤࡦ࠴࠭ᘶ")+l1llllll1l_l1_+l1lll1lll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᘷ")
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᘸ"),l111ll_l1_+l1lll1lll_l1_,l1lllll1ll_l1_,421)
				separator = True
		if separator: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᘹ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᘺ"),l11lll_l1_ (u"ࠧࠨᘻ"),9999)
	if l1lll1ll11_l1_==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᘼ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠧᘽ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᘾ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"ࠫࠬᘿ")
	elif l11lll_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᙀ") in url or l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࡣࡦࡰࡷࡩࡷ࠵ࠧᙁ") in url:
		block = html
	elif l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩᙂ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࠮ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠬࠪᙃ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳࡵࠪᙄ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡔࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࠰ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠮ࠬᙅ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠫ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡅࡨࡺ࡯ࡳࡐࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙆ"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡉࡩ࡮ࡣ࠷ࡹࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࠬᙇ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"࠭ࠧᙈ")
	if not items: items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠫࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠰࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠬࠫ࠲࠯ࡅࠩ࡜ࠤࡁࡡ࠰࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠮ࠫࡁࡅࡳࡽ࡚ࡩࡵ࡮ࡨࡍࡳ࡬࡯࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙉ"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡏࡲࡺ࡮࡫ࡂ࡭ࡱࡦ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᙊ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if not title: continue
		if l11lll_l1_ (u"ࠩࡂࡲࡪࡽࡳ࠾ࠩᙋ") in link: continue
		title = title.replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫᙌ"),l11lll_l1_ (u"ࠫࠬᙍ"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭ᙎ"),title,re.DOTALL)
		if l1lll11_l1_ and l11lll_l1_ (u"࠭อๅไฬࠫᙏ") in title:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᙐ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙑ"),l111ll_l1_+title,link,422,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪᙒ") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙓ"),l111ll_l1_+title,link,421,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙔ"),l111ll_l1_+title,link,422,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᙕ"),html,re.DOTALL)
	if l1l1ll1_l1_ and l1lll1ll11_l1_!=l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᙖ"):
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡ࡜ࠨ࡞ࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࡢࠢ࡞ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙗ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠨษ็ูๆำษࠡࠩᙘ"),l11lll_l1_ (u"ࠩࠪᙙ"))
			if title!=l11lll_l1_ (u"ࠪࠫᙚ"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙛ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫᙜ")+title,link,421)
	l1lllll111_l1_ = re.findall(l11lll_l1_ (u"࠭࠼࠰࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙝ"),html,re.DOTALL)
	if l1lllll111_l1_:
		link,title = l1lllll111_l1_[0]
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙞ"),l111ll_l1_+title,link,421)
	return
def l1lll1llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᙟ"),url,l11lll_l1_ (u"ࠩࠪᙠ"),l11lll_l1_ (u"ࠪࠫᙡ"),l11lll_l1_ (u"ࠫࠬᙢ"),l11lll_l1_ (u"ࠬ࠭ᙣ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫᙤ"))
	html = response.content
	# l11l1ll1l_l1_/download main l11l1ll1_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡔ࡯ࡸࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᙥ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		url = l1l1ll1_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᙦ"),url,l11lll_l1_ (u"ࠩࠪᙧ"),l11lll_l1_ (u"ࠪࠫᙨ"),l11lll_l1_ (u"ࠫࠬᙩ"),l11lll_l1_ (u"ࠬ࠭ᙪ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠳ࡰࡧࠫᙫ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᙬ"),l11lll_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ᙭"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡖࡩࡦࡹ࡯࡯ࡵࡖࡩࡨࡺࡩࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭᙮"),html,re.DOTALL)
	# l1llll1l11_l1_ l1lll1ll1l_l1_
	if l11lll_l1_ (u"ࠪ࠳ࡹࡧࡧ࠰ࠩᙯ") in url or l11lll_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵࠫᙰ") in url:
		l1111l_l1_(url)
	# l1lllll_l1_
	elif l1l1ll1_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭ᙱ"))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠧᙲ"),block,re.DOTALL)
		l11111111_l1_ = [l11lll_l1_ (u"ࠧๆี็ื้࠭ᙳ"),l11lll_l1_ (u"ࠨ็๋ื๊࠭ᙴ"),l11lll_l1_ (u"ࠩหี๋อๅอࠩᙵ"),l11lll_l1_ (u"ࠪั้่ษࠨᙶ")]
		for link,title in items:
			if any(value in title for value in l11111111_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙷ"),l111ll_l1_+title,link,423,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᙸ"),l111ll_l1_+title,link,426,l1llll_l1_)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᙹ"),url,l11lll_l1_ (u"ࠧࠨᙺ"),l11lll_l1_ (u"ࠨࠩᙻ"),l11lll_l1_ (u"ࠩࠪᙼ"),l11lll_l1_ (u"ࠪࠫᙽ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᙾ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪᙿ"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ "))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪᚁ"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩᚂ")
	# l1l1l_l1_
	l1l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚃ"),html,re.DOTALL)
	if l1l1l111l_l1_:
		block = l1l1l111l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚄ"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠫࠥ࠭ᚅ")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᚆ"),l111ll_l1_+title,link,426,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚇ"),l111ll_l1_+l11lll_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭ᚈ"),url,426,l1llll_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᚉ"),url,l11lll_l1_ (u"ࠩࠪᚊ"),headers,l11lll_l1_ (u"ࠪࠫᚋ"),l11lll_l1_ (u"ࠫࠬᚌ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᚍ"))
	html = response.content
	#newurl = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡶࡼࡰࡪࡹࡨࡦࡧࡷࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᚎ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᚏ"))
	l1ll1l1_l1_ = SERVER(newurl,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᚐ"))
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᚑ"),l11lll_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᚒ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡜ࡧࡴࡤࡪࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᚓ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚔ"),block,re.DOTALL)
		for l1l11111_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨᚕ"))
			if l11lll_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭ᚖ") in title.lower(): title = l11lll_l1_ (u"ࠨะสูࠥ࠭ᚗ")+title
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡹࡸࡵࡤࡶࡸࡶࡪ࠵ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧᚘ")+l1l11111_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᚙ")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᚚ")
			#link = link.replace(l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡤࡥ࠹ࡻ࠮ࡪࡥࡸࠫ᚛"),l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠴࡭ࡹࠩ᚜"))
			link = link.replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ᚝"),l11lll_l1_ (u"ࠨࠩ᚞"))
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ᚟"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚠ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᚡ"))
			if l11lll_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫᚢ") in title.lower(): l1lll1lll_l1_ = l11lll_l1_ (u"࠭࡟ࡠะสูࠬᚣ")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠧࠨᚤ")
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᚥ")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᚦ")+l1lll1lll_l1_
			link = link.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭ᚧ"),l11lll_l1_ (u"ࠫࠬᚨ"))
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᚩ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᚪ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨᚫ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩᚬ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫᚭ"),l11lll_l1_ (u"ࠪ࠯ࠬᚮ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᚯ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬᚰ"))
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
def l1lllllll1_l1_(url):
	if l11lll_l1_ (u"࠭ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࠨᚱ") not in url: url = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᚲ"))
	else: url = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᚳ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᚴ"),url,l11lll_l1_ (u"ࠪࠫᚵ"),l11lll_l1_ (u"ࠫࠬᚶ"),l11lll_l1_ (u"ࠬ࠭ᚷ"),l11lll_l1_ (u"࠭ࠧᚸ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩᚹ"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡏࡸࡰࡹ࡯ࡆࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡔࡦ࡭ࡥࡕ࡫ࡷࡰࡪ࠭ᚺ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡋࡳࡻ࡫ࡲࡢࡤ࡯ࡩ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿ࠣࡣ࡯ࡰࠧ࠴ࠪࡀࠪࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚻ"),block,re.DOTALL)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# id + title
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᚼ"),block,re.DOTALL)
	return items
def l1llll1ll1_l1_(url):
	l1llllll11_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᚽ"))[0]
	l1llll1lll_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩᚾ"))
	url = url.replace(l1llllll11_l1_,l1llll1lll_l1_)
	url = url.replace(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᚿ"),l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡩࡥ࡯ࡶࡨࡶ࠴ࡧࡣࡵ࡫ࡲࡲ࠴ࡎ࡯࡮ࡧࡳࡥ࡬࡫ࡌࡰࡣࡧࡩࡷ࠵ࠧᛀ"))
	url = url.replace(l11lll_l1_ (u"ࠨ࠿ࠪᛁ"),l11lll_l1_ (u"ࠩ࠲ࠫᛂ")).replace(l11lll_l1_ (u"ࠪࠪࠬᛃ"),l11lll_l1_ (u"ࠫ࠴࠭ᛄ"))
	url = url+l11lll_l1_ (u"ࠬ࠵ࠧᛅ")
	return url
l1l11lll_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᛆ"),l11lll_l1_ (u"ࠧࡵࡻࡳࡩࡸ࠭ᛇ"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᛈ")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪᛉ"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᛊ"),l11lll_l1_ (u"ࠫࡹࡿࡰࡦࡵࠪᛋ"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᛌ")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᛍ"),l11lll_l1_ (u"ࠧࠨᛎ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᛏ"),l11lll_l1_ (u"ࠩࠪᛐ"),filter,url)
	if l11lll_l1_ (u"ࠪࡃࠬᛑ") in url: url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᛒ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩᛓ"),1)
	if filter==l11lll_l1_ (u"࠭ࠧᛔ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨᛕ"),l11lll_l1_ (u"ࠨࠩᛖ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ᛗ"))
	if type==l11lll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᛘ"):
		if l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨᛙ") in url:
			global l1l11lll_l1_
			l1l11lll_l1_ = l1l11lll_l1_[1:]
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠬࡃࠧᛚ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"࠭࠽ࠨᛛ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩᛜ")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫᛝ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫᛞ")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭ᛟ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭ᛠ"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩᛡ")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨᛢ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᛣ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᛤ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬᛥ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᛦ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠫࠬᛧ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᛨ"))
		if l1l11l11_l1_==l11lll_l1_ (u"࠭ࠧᛩ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᛪ")+l1l11l11_l1_
		l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᛫"),l111ll_l1_+l11lll_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ᛬"),l11l11l_l1_,421,l11lll_l1_ (u"ࠪࠫ᛭"),l11lll_l1_ (u"ࠫࠬᛮ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᛯ"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛰ"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧᛱ")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧᛲ"),l11l11l_l1_,421,l11lll_l1_ (u"ࠩࠪᛳ"),l11lll_l1_ (u"ࠪࠫᛴ"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᛵ"))
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᛶ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᛷ"),l11lll_l1_ (u"ࠧࠨᛸ"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		if l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬ᛹") in url and l1ll1lll_l1_==l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ᛺"): continue
		name = name.replace(l11lll_l1_ (u"ࠪ࠱࠲࠭᛻"),l11lll_l1_ (u"ࠫࠬ᛼"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧ᛽") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ᛾"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l1llll1ll1_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭᛿")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l1llll1ll1_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜀ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩᜁ"),l11l11l_l1_,421,l11lll_l1_ (u"ࠪࠫᜂ"),l11lll_l1_ (u"ࠫࠬᜃ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᜄ"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜅ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧᜆ"),l11l11l_l1_,425,l11lll_l1_ (u"ࠨࠩᜇ"),l11lll_l1_ (u"ࠩࠪᜈ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᜉ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᜊ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨᜋ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨᜌ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪᜍ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬᜎ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜏ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᜐ")+name,l11l11l_l1_,424,l11lll_l1_ (u"ࠫࠬᜑ"),l11lll_l1_ (u"ࠬ࠭ᜒ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᜓ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹᜔ࠧ"): option = l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ᜕")
			elif value==l11lll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ᜖"): option = l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ᜗")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ᜘") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᜙"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ᜚")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ᜛")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ᜜")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ᜝")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ᜞")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧᜟ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧᜠ")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩᜡ")+name
			if type==l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᜢ"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᜣ"),l111ll_l1_+title,url,424,l11lll_l1_ (u"ࠩࠪᜤ"),l11lll_l1_ (u"ࠪࠫᜥ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᜦ"))
			elif type==l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᜧ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨᜨ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᜩ"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᜪ")+l1l1111l_l1_
				l11l1l1_l1_ = l1llll1ll1_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᜫ"),l111ll_l1_+title,l11l1l1_l1_,421,l11lll_l1_ (u"ࠪࠫᜬ"),l11lll_l1_ (u"ࠫࠬᜭ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᜮ"))
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜯ"),l111ll_l1_+title,url,425,l11lll_l1_ (u"ࠧࠨᜰ"),l11lll_l1_ (u"ࠨࠩᜱ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᜲ"),l11lll_l1_ (u"ࠪࠫᜳ"),filters,l11lll_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵᜴ࠬ"))
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ᜵")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ᜶")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ᜷")					all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠨ࠿ࠩࠫ᜸"),l11lll_l1_ (u"ࠩࡀ࠴ࠫ࠭᜹"))
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠬ᜺"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠫࡂ࠭᜻") in filters:
		items = filters.split(l11lll_l1_ (u"ࠬࠬࠧ᜼"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"࠭࠽ࠨ᜽"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠧࠨ᜾")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪ᜿")
		if l11lll_l1_ (u"ࠩࠨࠫᝀ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᝁ") and value!=l11lll_l1_ (u"ࠫ࠵࠭ᝂ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩᝃ")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᝄ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᝅ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪᝆ")+key+l11lll_l1_ (u"ࠩࡀࠫᝇ")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᝈ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᝉ")+key+l11lll_l1_ (u"ࠬࡃࠧᝊ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪᝋ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩᝌ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨ࠿࠳ࠫᝍ"),l11lll_l1_ (u"ࠩࡀࠫᝎ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᝏ"),l11lll_l1_ (u"ࠫࠬᝐ"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ᝑ"))
	return l1ll1l1l_l1_
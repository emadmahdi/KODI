# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ⬢")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡌࡂࡌࡡࠪ⬣")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ⬤"),l11lll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ⬥")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l1111l_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l11111_l1_(url,text)
	elif mode==624: results = l1l11l_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1l1lllll11_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ⬦"),l11lll_l1_ (u"ࠨใหี่ฯࠠࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ⬧"),l11lll_l1_ (u"ࠩࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠩ⬨"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⬩"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⬪"),l11lll_l1_ (u"ࠬ࠭⬫"),629,l11lll_l1_ (u"࠭ࠧ⬬"),l11lll_l1_ (u"ࠧࠨ⬭"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⬮"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⬯"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⬰"),l11lll_l1_ (u"ࠫࠬ⬱"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬲"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⬳")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ⬴"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠨࠩ⬵"),l11lll_l1_ (u"ࠩࠪ⬶"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⬷"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⬸"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⬹")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬ⬺"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠧࠨ⬻"),l11lll_l1_ (u"ࠨࠩ⬼"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⬽"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⬾"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⬿")+l111ll_l1_+l11lll_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ⭀"),l1ll1l1_l1_,621,l11lll_l1_ (u"࠭ࠧ⭁"),l11lll_l1_ (u"ࠧࠨ⭂"),l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⭃"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭄"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⭅")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ⭆"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠬ࠭⭇"),l11lll_l1_ (u"࠭ࠧ⭈"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ⭉"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⭊"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⭋"),l11lll_l1_ (u"ࠪࠫ⭌"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⭍"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⭎"),l11lll_l1_ (u"࠭ࠧ⭏"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็ศาๅฬࠫ⭐"),l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦล๋ฮสำࠥ฿ๆ้ษ้ࠤฬ๊ๅ้ไ฼ࠤศ๎ࠠหื่๎๊ࠦวๅ็๋ๆ฾ࠦส฻์ิࠫ⭑"))
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⭒"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⭓"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⭔")+l111ll_l1_+title,link,624)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭕"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭖"),l11lll_l1_ (u"ࠧࠨ⭗"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ⭘"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ⭙"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠪࠫ⭚"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⭛"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭜"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⭝")+l111ll_l1_+title,link,624)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⭞"),url,l11lll_l1_ (u"ࠨࠩ⭟"),l11lll_l1_ (u"ࠩࠪ⭠"),l11lll_l1_ (u"ࠪࠫ⭡"),l11lll_l1_ (u"ࠫࠬ⭢"),l11lll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⭣"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⭤"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ⭥"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ⭦"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⭧"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫ⭨"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⭩"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⭪"),l11lll_l1_ (u"࠭ࠧ⭫"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⭬"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫ⭭")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭮"),l111ll_l1_+title,link,621)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⭯"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⭰"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭱"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭲"),l11lll_l1_ (u"ࠧࠨ⭳"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⭴"),l111ll_l1_+title,link,621)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪ⭵")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⭶"),l11lll_l1_ (u"ࠫࠬ⭷"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ⭸"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨ⭹"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭⭺")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⭻"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ⭼")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⭽"),url,data,headers,l11lll_l1_ (u"ࠫࠬ⭾"),l11lll_l1_ (u"ࠬ࠭⭿"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⮀"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⮁"),url,l11lll_l1_ (u"ࠨࠩ⮂"),l11lll_l1_ (u"ࠩࠪ⮃"),l11lll_l1_ (u"ࠪࠫ⮄"),l11lll_l1_ (u"ࠫࠬ⮅"),l11lll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⮆"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧ⮇"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ⮈"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭⮉"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⮊"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ⮋"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⮌"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⮍"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⮎"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⮏"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ⮐"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⮑"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ⮒"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭⮓"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⮔"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ⮕"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⮖"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⮗"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ⮘"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ⮙"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ⮚"),l11lll_l1_ (u"้ࠬไ๋สࠪ⮛"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ⮜"),l11lll_l1_ (u"่ࠧัสๅࠬ⮝"),l11lll_l1_ (u"ࠨ็หหึอษࠨ⮞"),l11lll_l1_ (u"ࠩ฼ี฻࠭⮟"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ⮠"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ⮡"),l11lll_l1_ (u"๋ࠬำาฯํอࠬ⮢")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨ⮣"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⮤") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ⮥")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ⮦"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⮧") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭⮨")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧ⮩"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ⮪"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ⮫"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⮬"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⮭"):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⮮"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⮯") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮰"),l111ll_l1_+title,link,623,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ⮱") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮲"),l111ll_l1_+title,link,621,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⮳"),l111ll_l1_+title,link,623,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⮴"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ⮵")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⮶"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⮷"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ⮸"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ⮹")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ⮺"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮻"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ⮼")+title,link,621)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⮽"),l11lll_l1_ (u"ࠬ࠭⮾"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⮿"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⯀"),url,l11lll_l1_ (u"ࠨࠩ⯁"),l11lll_l1_ (u"ࠩࠪ⯂"),l11lll_l1_ (u"ࠪࠫ⯃"),l11lll_l1_ (u"ࠫࠬ⯄"),l11lll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ⯅"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ⯆"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⯇"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩ⯈")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩ⯉"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠪࠧࠬ⯊"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯋"),l111ll_l1_+title,url,623,l1llll_l1_,l11lll_l1_ (u"ࠬ࠭⯌"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࠫ⯍")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⯎"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠩࠪ࡬ࡷ࡫ࡦ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨࠩࠪ⯏"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⯐"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ⯑")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭⯒"))
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪ⯓"),l11lll_l1_ (u"࠭ࠠࠨ⯔"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯕"),l111ll_l1_+title,link,622,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ⯖"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⯗") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ⯘")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭⯙"))
		#		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⯚"),l111ll_l1_+title,link,622,l1llll_l1_)
	return
def PLAY(url):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⯛"))
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⯜"),url,l11lll_l1_ (u"ࠨࠩ⯝"),l11lll_l1_ (u"ࠩࠪ⯞"),l11lll_l1_ (u"ࠪࠫ⯟"),l11lll_l1_ (u"ࠫࠬ⯠"),l11lll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⯡"))
	html = response.content
	# l1llll1_l1_ l1l11l1_l1_
	link = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⯢"),html,re.DOTALL)
	link = link[0]
	post = link.split(l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡂ࠭⯣"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⯤"))
	post = EVAL(l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ⯥"),post)
	links = post[l11lll_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࡶࠫ⯦")]
	l1l111_l1_ = list(links.keys())
	links = list(links.values())
	l111l1_l1_ = zip(l1l111_l1_,links)
	for title,link in l111l1_l1_:
		link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⯧")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⯨")
		l1111_l1_.append(link)
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠧ࡮࡬ࠠ࡭࡫ࡱ࡯ࠥࡧ࡮ࡥࠢࠪ࡬ࡹࡺࡰࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡ࡮࡬ࡲࡰࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺ࠨ࠭࡯࡭ࡳࡱࠊࠊࡪࡤࡷ࡭ࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࡨࡢࡵ࡫ࡁࠬ࠯࡛࠲࡟ࠍࠍࡵࡧࡲࡵࡵࠣࡁࠥ࡮ࡡࡴࡪ࠱ࡷࡵࡲࡩࡵࠪࠪࡣࡤ࠭ࠩࠋࠋࡱࡩࡼࡥࡰࡢࡴࡷࡷࠥࡃࠠ࡜࡟ࠍࠍ࡫ࡵࡲࠡࡲࡤࡶࡹࠦࡩ࡯ࠢࡳࡥࡷࡺࡳ࠻ࠌࠌࠍࡹࡸࡹ࠻ࠌࠌࠍࠎࡶࡡࡳࡶࠣࡁࠥࡨࡡࡴࡧ࠹࠸࠳ࡨ࠶࠵ࡦࡨࡧࡴࡪࡥࠩࡲࡤࡶࡹ࠱ࠧ࠾ࠩࠬࠎࠎࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢࡳࡥࡷࡺࠠ࠾ࠢࡳࡥࡷࡺ࠮ࡥࡧࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠋࠋࠌࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡱࡣࡵࡸ࠮ࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠊࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࠪࡂࠬ࠴ࡪࡰ࡫ࡱࠬࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠩࠋࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡰ࡮ࡴ࡫ࡴ࠰ࡶࡴࡱ࡯ࡴ࡭࡫ࡱࡩࡸ࠮ࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠶ࠥ࡯࡮ࠡࡼࡽࡾ࠿ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠷࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠠ࠾ࡀࠣࠫ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡼࡧࡴࡤࡪࠪࠎࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠤࠥࠦ⯩")
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⯪"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⯫"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ⯬"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ⯭"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭⯮"),l11lll_l1_ (u"ࠬ࠱ࠧ⯯"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ⯰")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1l1lllll11_l1_(url,l11lll_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ⯱"),l11lll_l1_ (u"ࠨใหี่ฯࠠࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ⯲"),l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࠬ⯳"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ⯴"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨ⯵")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ⯶"))
	return
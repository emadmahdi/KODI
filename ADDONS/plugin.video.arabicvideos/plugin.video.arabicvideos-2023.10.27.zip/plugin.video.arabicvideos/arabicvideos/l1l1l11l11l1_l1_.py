# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ杨")
headers = l11lll_l1_ (u"࠭ࠧ杩") #{ l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ杪") : l11lll_l1_ (u"ࠨࠩ杫") }
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍ࠺࡟ࠨ杬")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪ฽ึ๎ึࠡ็ุหึ฿ษࠨ杭"),l11lll_l1_ (u"ࠫฬ๊ใๅࠩ杮"),l11lll_l1_ (u"ࠬอแๅษ่ࠫ杯"),l11lll_l1_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ杰"),l11lll_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ東")]
# l1l1ll11_l1_	https://l1ll1ll11l1l1_l1_.l1lll1ll1ll_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/l1lllll11ll1l_l1_.net
# l1llll1111l_l1_	https://l1llll1111l_l1_.com/l1ll1ll11l11l_l1_
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1111l_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llllll_l1_(url,True)
	elif mode==114: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ杲")+text)
	elif mode==115: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭杳")+text)
	elif mode==116: results = l1llllll_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1l1lllll11_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ杴"),l11lll_l1_ (u"ูࠫอ็ะࠢไ์ึ๐่ࠡ࠯ࠣࡗ࡭ࡧࡨࡪࡦࠣ࠸ࡺ࠭杵"),l11lll_l1_ (u"ࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ杶"),headers)
	html = response.content
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭杷"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ杸"),l11lll_l1_ (u"ࠨࠩ杹"),119,l11lll_l1_ (u"ࠩࠪ杺"),l11lll_l1_ (u"ࠪࠫ杻"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ杼"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ杽"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ松"),l1ll1l1_l1_,115)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ板"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ枀"),l1ll1l1_l1_,114)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ极"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ枂"),l11lll_l1_ (u"ࠫࠬ枃"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ构"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ枅"),l1ll1l1_l1_,111,l11lll_l1_ (u"ࠧࠨ枆"),l11lll_l1_ (u"ࠨࠩ枇"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ枈"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷ࡮ࡳࡰ࡭ࡧ࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩࡢࡦࡹ࠱࡫࡯࡬ࡵࡧࡵࠫ枉"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ枊"),l11lll_l1_ (u"ࠬ࠭枋"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨ枌"),l11lll_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥห๊อษาࠤ฾์่ศ่ࠣห้๋่ใ฻ࠣวํࠦสึ็ํ้ࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠪ枍"))
		return
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡁࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ枎"),block,re.DOTALL)
		for filter,l1llll_l1_,title in items:
			url = l1ll1l1_l1_+filter
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ枏"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ析")+l111ll_l1_+title,url,111,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ枑"),filter)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ枒"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭枓"),l11lll_l1_ (u"ࠧࠨ枔"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࡀࠪ枕"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ枖"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭林"),l11lll_l1_ (u"ࠫࠬ枘")).replace(l11lll_l1_ (u"ࠬࡢࡲࠨ枙"),l11lll_l1_ (u"࠭ࠧ枚")).strip(l11lll_l1_ (u"ࠧࠡࠩ枛"))
			if title in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭果") not in link: link = l1ll1l1_l1_+link
			if l11lll_l1_ (u"ࠩࡱࡩࡹ࡬࡬ࡪࡺࠪ枝") in link: title = l11lll_l1_ (u"๊ࠪ๏ะแๅๅึࠫ枞")
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ枟"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ枠")+l111ll_l1_+title,link,111)
	return html
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"࠭ࠧ枡"),response=l11lll_l1_ (u"ࠧࠨ枢")):
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ枣"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ枤")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ枥"),url,l11lll_l1_ (u"ࠫࠬ枦"),headers,l11lll_l1_ (u"ࠬ࠭枧"),l11lll_l1_ (u"࠭ࠧ枨"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭枩"))
	html = response.content
	l1l1ll1_l1_,items,l1l1_l1_ = [],[],[]
	if l1lll1ll11_l1_==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ枪"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡪࡰ࡮ࡪࡥࡠࡡࡶࡰ࡮ࡪࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ枫"),html,re.DOTALL)
	#elif l1lll1ll11_l1_==l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ枬"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡒ࡫ࡤࡪࡣࡊࡶ࡮ࡪࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ枭"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡨࡰࡹࡶ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ枮"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#if l1lll1ll11_l1_==l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭枯"): items = re.findall(l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ枰"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠺࠾ࠨ枱"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ枲"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ枳"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ枴"),l11lll_l1_ (u"้ࠬไ๋สࠪ枵"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ架"),l11lll_l1_ (u"่ࠧัสๅࠬ枷"),l11lll_l1_ (u"ࠨ็หหึอษࠨ枸"),l11lll_l1_ (u"ࠩ฼ี฻࠭枹"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ枺"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ枻")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ枼") in link: continue
		#if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ枽") in link: continue
		#link = link.replace(l11lll_l1_ (u"ࠧࠧࠥ࠳࠷࠽ࡁࠧ枾"),l11lll_l1_ (u"ࠨࠨࠪ枿"))
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ柀"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ柁"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ柂"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ柃") in link or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ柄"),l111ll_l1_+title,link,112,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ柅") in title and l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ柆") not in url:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ柇") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ柈"),l111ll_l1_+title,link,113,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫ࠴ࡧࡣࡵࡱࡵ࠳ࠬ柉") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ柊"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ柋") in link and l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠭柌") not in url:
			link = link+l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ柍")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ柎"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ柏") in url and l11lll_l1_ (u"ࠫา๊โสࠩ某") in title:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ柑"),l111ll_l1_+title,link,112,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭柒"),l111ll_l1_+title,link,113,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ染"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ柔"): items = re.findall(l11lll_l1_ (u"ࠩࠫࡹࡵࡪࡡࡵࡧࡔࡹࡪࡸࡹࠪ࠰࠭ࡃࡃ࠮࠮ࠬࡁࠬࡀࠬ柕"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ柖"),block,re.DOTALL)
		for link,title in items:
			if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ柗"):
				title = title.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ柘"),l11lll_l1_ (u"࠭ࠧ柙")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ柚"),l11lll_l1_ (u"ࠨࠩ柛"))
				if l11lll_l1_ (u"ࠩࡂࠫ柜") in url: link = url+l11lll_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ柝")+title
				else: link = url+l11lll_l1_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫ柞")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ柟"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ柠")+title,link,111,l11lll_l1_ (u"ࠧࠨ柡"),l11lll_l1_ (u"ࠨࠩ柢"),l1lll1ll11_l1_)
	return
def l1llllll_l1_(url,l1ll1ll11l111_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭柣"),url,l11lll_l1_ (u"ࠪࠫ柤"),headers,l11lll_l1_ (u"ࠫࠬ查"),l11lll_l1_ (u"ࠬ࠭柦"),l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ柧"))
	html = response.content
	# l1lllll_l1_ & l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡶࡨࡱࡸࠦࡤ࠮ࡨ࡯ࡩࡽ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ柨"),html,re.DOTALL)
	if len(l1l1ll1_l1_)>1:
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ柩") in l1l1ll1_l1_[0]: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[1]
		else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[1],l1l1ll1_l1_[0]
	else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[0]
	for l11ll111l1_l1_ in range(2):
		if l1ll1ll11l111_l1_: mode,type,block = 116,l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ柪"),l1lllll_l1_
		else: mode,type,block = 112,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ柫"),l1l1l_l1_
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ柬"),block,re.DOTALL)
		if l1ll1ll11l111_l1_ and len(items)<2:
			l1ll1ll11l111_l1_ = False
			continue
		for link,l11l1ll11_l1_,l1lll1lll_l1_ in items:
			title = l11l1ll11_l1_+l11lll_l1_ (u"ࠬࠦࠧ柭")+l1lll1lll_l1_
			addMenuItem(type,l111ll_l1_+title,link,mode)
		break
	# l1l1l_l1_ l11l1ll1_l1_
	if not items and l11lll_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ柮") in html:
		l1l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡴࡨࡥࡩࡩࡲࡶ࡯ࡥࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ柯"),html,re.DOTALL)
		if l1l1l111l_l1_:
			block = l1l1l111l_l1_[0]
			links = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ柰"),block,re.DOTALL)
			if len(links)>2:
				link = links[2]+l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ柱")
				l1111l_l1_(link)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ柲"),url,l11lll_l1_ (u"ࠫࠬ柳"),headers,l11lll_l1_ (u"ࠬ࠭柴"),l11lll_l1_ (u"࠭ࠧ柵"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ柶"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡦࡸ࡮ࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭柷"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ柸"),block,re.DOTALL)
	l11l1ll1l_l1_ = l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ柹") in block
	download = l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ柺") in block
	if   l11l1ll1l_l1_ and not download: l1ll1ll11l1ll_l1_,l111l11ll11l_l1_ = links[0],l11lll_l1_ (u"ࠬ࠭査")
	elif not l11l1ll1l_l1_ and download: l1ll1ll11l1ll_l1_,l111l11ll11l_l1_ = l11lll_l1_ (u"࠭ࠧ柼"),links[0]
	elif l11l1ll1l_l1_ and download: l1ll1ll11l1ll_l1_,l111l11ll11l_l1_ = links[0],links[1]
	else: l1ll1ll11l1ll_l1_,l111l11ll11l_l1_ = l11lll_l1_ (u"ࠧࠨ柽"),l11lll_l1_ (u"ࠨࠩ柾")
	# l11l1ll1l_l1_
	if l11l1ll1l_l1_:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭柿"),l1ll1ll11l1ll_l1_,l11lll_l1_ (u"ࠪࠫ栀"),headers,l11lll_l1_ (u"ࠫࠬ栁"),l11lll_l1_ (u"ࠬ࠭栂"),l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ栃"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡭ࡧࡷࠤࡸ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫࡳࡰࡦࡿࡥࡳࠩ栄"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ栅"),l11l1_l1_,re.DOTALL)
			for title,link in l1l1lll_l1_:
				link = link.replace(l11lll_l1_ (u"ࠩ࡟ࡠ࠴࠭栆"),l11lll_l1_ (u"ࠪ࠳ࠬ标"))
				link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ栈")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭栉")
				l1111_l1_.append(link)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ栊"),l111l11ll11l_l1_,l11lll_l1_ (u"ࠧࠨ栋"),headers,l11lll_l1_ (u"ࠨࠩ栌"),l11lll_l1_ (u"ࠩࠪ栍"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ栎"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭࡮ࡴࡦࡰ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ栏"),l11lll1l_l1_,re.DOTALL)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽࠱࡬ࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭栐"),l11l1_l1_,re.DOTALL)
			for link,title,l11l111l_l1_ in l1l1lll_l1_:
				link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ树")+title+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ栒")+l11lll_l1_ (u"ࠨࡡࡢࡣࡤ࠭栓")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ栔"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ栕"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭栖"),l11lll_l1_ (u"ࠬ࠱ࠧ栗"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ栘")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1l1lllll11_l1_(url,l11lll_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ栙"),l11lll_l1_ (u"ࠨึส๋ิࠦแ้ำํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪࠠ࠵ࡷࠪ栚"),l11lll_l1_ (u"ࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩ栛"),headers)
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ栜"),l1ll111ll_l1_)
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_
# ===========================================
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ栝"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ栞"),url,l11lll_l1_ (u"࠭ࠧ栟"),headers,l11lll_l1_ (u"ࠧࠨ栠"),l11lll_l1_ (u"ࠨࠩ校"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭栢"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭栣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࠩ栤"),block,re.DOTALL)
		l1llll1ll11_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1llll1ll11_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿࡞ࡶ࠮࠭࠴ࠪࡀࠫ࡟ࡷ࠯ࡂࠧ栥"),block,re.DOTALL)
	return items
def l1llll1l11l_l1_(url):
	#url = url.replace(l11lll_l1_ (u"࠭ࡣࡢࡶࡀࠫ栦"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ栧"))
	if l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ栨") not in url: url = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭栩")
	l1llllll11_l1_ = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ株"))[0]
	l1llll1lll_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ栫"))
	url = url.replace(l1llllll11_l1_,l1llll1lll_l1_)
	#url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ栬"),l11lll_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪ栭"))
	url = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ栮"),l11lll_l1_ (u"ࠨ࠱ࡂࠫ栯"))
	return url
l1lllll1l11_l1_ = [l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ栰"),l11lll_l1_ (u"ࠪࡽࡪࡧࡲࠨ栱"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ栲"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ栳")]
l1lllll1l1l_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ栴"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭栵"),l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭栶")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ样"),l11lll_l1_ (u"ࠪࠫ核"))
	url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ根"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ栺"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ栻"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ格"),l11lll_l1_ (u"ࠨࠩ栽")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭栾"))
	if type==l11lll_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ栿"):
		if l1lllll1l1l_l1_[0]+l11lll_l1_ (u"ࠫࡂ࠭桀") not in l1l11l1l_l1_: category = l1lllll1l1l_l1_[0]
		for i in range(len(l1lllll1l1l_l1_[0:-1])):
			if l1lllll1l1l_l1_[i]+l11lll_l1_ (u"ࠬࡃࠧ桁") in l1l11l1l_l1_: category = l1lllll1l1l_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ桂")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ桃")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ桄")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ桅")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ框"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ桇")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ案"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ桉"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ桊")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭桋"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ桌"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠪࠫ桍"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ桎"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠬ࠭桏"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ桐")+l1l11l11_l1_
		l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ桑"),l111ll_l1_+l11lll_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ桒"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ桓"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ桔")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ桕"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ桖"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭桗"),l11lll_l1_ (u"ࠧࠨ桘"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠨๅ็ࠤࠬ桙"),l11lll_l1_ (u"ࠩࠪ桚"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠪࡁࠬ桛") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ桜"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ桝")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桞"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ桟"),l11l1l1_l1_,111)
				else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ桠"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ桡"),l11l11l_l1_,115,l11lll_l1_ (u"ࠪࠫ桢"),l11lll_l1_ (u"ࠫࠬ档"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ桤"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ桥")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ桦")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ桧")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ桨")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ桩")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桪"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ桫")+name,l11l11l_l1_,114,l11lll_l1_ (u"࠭ࠧ桬"),l11lll_l1_ (u"ࠧࠨ桭"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ桮"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ桯"): option = l11lll_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ桰")
			elif value==l11lll_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ桱"): option = l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ桲")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ桳") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ桴"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ桵")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ桶")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ桷")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭桸")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ桹")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩ桺")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠧ࠱ࠩ桻")]
			title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫ桼")+name
			if type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ桽"): addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ桾"),l111ll_l1_+title,url,114,l11lll_l1_ (u"ࠫࠬ桿"),l11lll_l1_ (u"ࠬ࠭梀"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ梁"))
			elif type==l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ梂") and l1lllll1l1l_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࠪ梃") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ梄"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ梅")+l1l1111l_l1_
				l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ梆"),l111ll_l1_+title,l11l1l1_l1_,111)
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ梇"),l111ll_l1_+title,url,115,l11lll_l1_ (u"࠭ࠧ梈"),l11lll_l1_ (u"ࠧࠨ梉"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ梊")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ梋")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧ梌")					all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠫࡂࠬࠧ梍"),l11lll_l1_ (u"ࠬࡃ࠰ࠧࠩ梎"))
	filters = filters.strip(l11lll_l1_ (u"࠭ࠦࠨ梏"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠧ࠾ࠩ梐") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠪ梑"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࠫ梒"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠪࠫ梓")
	for key in l1lllll1l11_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠫ࠵࠭梔")
		if l11lll_l1_ (u"ࠬࠫࠧ梕") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ梖") and value!=l11lll_l1_ (u"ࠧ࠱ࠩ梗"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ梘")+value
		elif mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ梙") and value!=l11lll_l1_ (u"ࠪ࠴ࠬ梚"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭梛")+key+l11lll_l1_ (u"ࠬࡃࠧ梜")+value
		elif mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪ條"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ梞")+key+l11lll_l1_ (u"ࠨ࠿ࠪ梟")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭梠"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ梡"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠫࡂ࠶ࠧ梢"),l11lll_l1_ (u"ࠬࡃࠧ梣"))
	return l1ll1l1l_l1_
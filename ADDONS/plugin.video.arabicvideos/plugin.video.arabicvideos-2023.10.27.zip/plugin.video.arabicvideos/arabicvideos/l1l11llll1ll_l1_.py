# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ唼")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡐࡘ࡚࡟ࠨ唽")
l11l1l111l11_l1_ = 4
l11l1l111111_l1_ = 10
def MAIN(mode,url,text,l1l11l1_l1_,l1ll11111l1_l1_):
	try: l11lllllll1l_l1_ = str(l1ll11111l1_l1_[l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唾")])
	except: l11lllllll1l_l1_ = l11lll_l1_ (u"ࠫࠬ唿")
	if   mode==160: results = MENU()
	elif mode==161: results = l11l1l1l1l11_l1_(text)
	elif mode==162: results = l11l11l1l111_l1_(text,162)
	elif mode==163: results = l11l11l1l111_l1_(text,163)
	elif mode==164: results = l11l1l1l11l1_l1_(text)
	elif mode==165: results = l11l111lll1l_l1_(url,text)
	elif mode==166: results = l11l1l11l11l_l1_(url,text)
	elif mode==167: results = l11l111lll11_l1_(url,text)
	elif mode==168: results = l11l111l111l_l1_(url,text)
	elif mode==761: results = l11l1l11llll_l1_()
	elif mode==762: results = l11l11ll1ll1_l1_()
	elif mode==763: results = l11l11ll1l11_l1_(l11lllllll1l_l1_,text,l1l11l1_l1_)
	elif mode==764: results = l11l1l1111l1_l1_(l11lllllll1l_l1_,text)
	elif mode==765: results = l11l1l11ll1l_l1_(l11lllllll1l_l1_,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ啀"),l11lll_l1_ (u"࠭โ็๊สฮࠥะไโิํ์ู๋ࠦี๊สส๏ฯࠧ啁"),l11lll_l1_ (u"ࠧࠨ啂"),161,l11lll_l1_ (u"ࠨࠩ啃"),l11lll_l1_ (u"ࠩࠪ啄"),l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ啅"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ商"),l11lll_l1_ (u"่ࠬำๆࠢ฼ุํอฦ๋ࠩ啇"),l11lll_l1_ (u"࠭ࠧ啈"),162,l11lll_l1_ (u"ࠧࠨ啉"),l11lll_l1_ (u"ࠨࠩ啊"),l11lll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭啋"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啌"),l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ啍"),l11lll_l1_ (u"ࠬ࠭啎"),163,l11lll_l1_ (u"࠭ࠧ問"),l11lll_l1_ (u"ࠧࠨ啐"),l11lll_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭啑"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ啒"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥฮอฬࠢ฼ุํอฦ๋ࠩ啓"),l11lll_l1_ (u"ࠫࠬ啔"),164,l11lll_l1_ (u"ࠬ࠭啕"),l11lll_l1_ (u"࠭ࠧ啖"),l11lll_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ啗"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ啘"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ啙"),l11lll_l1_ (u"ࠪࠫ啚"),763,l11lll_l1_ (u"ࠫࠬ啛"),l11lll_l1_ (u"ࠬ࠭啜"),l11lll_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ啝"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ啞"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ啟"),l11lll_l1_ (u"ࠩࠪ啠"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啡"),l11lll_l1_ (u"ࠫ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠨ啢"),l11lll_l1_ (u"ࠬ࠭啣"),163,l11lll_l1_ (u"࠭ࠧ啤"),l11lll_l1_ (u"ࠧࠨ啥"),l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ啦"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ啧"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ啨"),l11lll_l1_ (u"ࠫࠬ啩"),163,l11lll_l1_ (u"ࠬ࠭啪"),l11lll_l1_ (u"࠭ࠧ啫"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ啬"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ啭"),l11lll_l1_ (u"ࠩๅื๊ࠦโ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ࠩ啮"),l11lll_l1_ (u"ࠪࠫ啯"),162,l11lll_l1_ (u"ࠫࠬ啰"),l11lll_l1_ (u"ࠬ࠭啱"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ啲"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ啳"),l11lll_l1_ (u"ࠨไึ้ࠥ็๊ะ์๋ࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ啴"),l11lll_l1_ (u"ࠩࠪ啵"),162,l11lll_l1_ (u"ࠪࠫ啶"),l11lll_l1_ (u"ࠫࠬ啷"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ啸"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭啹"),l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷࡚ࠦศฮอࠣ฽ู๎วว์ࠪ啺"),l11lll_l1_ (u"ࠨࠩ啻"),164,l11lll_l1_ (u"ࠩࠪ啼"),l11lll_l1_ (u"ࠪࠫ啽"),l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ啾"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ啿"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭喀"),l11lll_l1_ (u"ࠧࠨ喁"),765,l11lll_l1_ (u"ࠨࠩ喂"),l11lll_l1_ (u"ࠩࠪ喃"),l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭善"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ喅"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ喆"),l11lll_l1_ (u"࠭ࠧ喇"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ喈"),l11lll_l1_ (u"ࠨไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮ࠭喉"),l11lll_l1_ (u"ࠩࠪ喊"),163,l11lll_l1_ (u"ࠪࠫ喋"),l11lll_l1_ (u"ࠫࠬ喌"),l11lll_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ喍"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喎"),l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ喏"),l11lll_l1_ (u"ࠨࠩ喐"),163,l11lll_l1_ (u"ࠩࠪ喑"),l11lll_l1_ (u"ࠪࠫ喒"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭喓"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喔"),l11lll_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧ喕"),l11lll_l1_ (u"ࠧࠨ喖"),162,l11lll_l1_ (u"ࠨࠩ喗"),l11lll_l1_ (u"ࠩࠪ喘"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡐࡎ࡜ࡅࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ喙"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喚"),l11lll_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭喛"),l11lll_l1_ (u"࠭ࠧ喜"),162,l11lll_l1_ (u"ࠧࠨ喝"),l11lll_l1_ (u"ࠨࠩ喞"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡ࡙ࡓࡉࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ喟"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喠"),l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ喡"),l11lll_l1_ (u"ࠬ࠭喢"),164,l11lll_l1_ (u"࠭ࠧ喣"),l11lll_l1_ (u"ࠧࠨ喤"),l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ喥"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ喦"),l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ喧"),l11lll_l1_ (u"ࠫࠬ喨"),764,l11lll_l1_ (u"ࠬ࠭喩"),l11lll_l1_ (u"࠭ࠧ喪"),l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ喫"))
	return
def l11l1l11llll_l1_():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喬"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚࡟ࠨ喭")+l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥาๅ๋฻ࠣࡍࡕ࡚ࡖࠨ單"),l11lll_l1_ (u"ࠫࠬ喯"),764)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ喰"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭喱"),l11lll_l1_ (u"ࠧࠨ喲"),9999)
	for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡌࡔࠬ喳")+str(l11lllllll1l_l1_)+l11lll_l1_ (u"ࠩࡢࠫ喴")
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喵"),l111ll_l1_+l11lll_l1_ (u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭営")+text_numbers[l11lllllll1l_l1_],l11lll_l1_ (u"ࠬ࠭喷"),764,l11lll_l1_ (u"࠭ࠧ喸"),l11lll_l1_ (u"ࠧࠨ喹"),l11lll_l1_ (u"ࠨࠩ喺"),l11lll_l1_ (u"ࠩࠪ喻"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喼"):l11lllllll1l_l1_})
	return
def l11l11ll1ll1_l1_():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ喽"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ喾")+l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡฮ่๎฾ࠦࡍ࠴ࡗࠪ喿"),l11lll_l1_ (u"ࠧࠨ嗀"),765)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭嗁"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嗂"),l11lll_l1_ (u"ࠪࠫ嗃"),9999)
	for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		#l11lll1111l1_l1_ = l11lll_l1_ (u"ࠫࠥࡓ࠳ࡖࠩ嗄")+str(l11lllllll1l_l1_)
		l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡍࡖࠩ嗅")+str(l11lllllll1l_l1_)+l11lll_l1_ (u"࠭࡟ࠨ嗆")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗇"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢไ๎ิ๐่่ษอࠤ๊าไะࠢࠪ嗈")+text_numbers[l11lllllll1l_l1_],l11lll_l1_ (u"ࠩࠪ嗉"),765,l11lll_l1_ (u"ࠪࠫ嗊"),l11lll_l1_ (u"ࠫࠬ嗋"),l11lll_l1_ (u"ࠬ࠭嗌"),l11lll_l1_ (u"࠭ࠧ嗍"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗎"):l11lllllll1l_l1_})
	return
def l11l1l11lll1_l1_(l1l1l1l1l1l_l1_):
	l1l1l11ll11_l1_,l1l1l1l1l11_l1_,l1l1ll1l1l1_l1_ = l1l1l11l111_l1_(l1l1l1l1l1l_l1_)
	try:
		if l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ嗏") in l1l1l1l1l1l_l1_: l1l1l11ll11_l1_(l1l1l1l1l1l_l1_)
		else: l1l1l11ll11_l1_()
		l11l11ll1l1l_l1_ = False
	except: l11l11ll1l1l_l1_ = True
	l1l1l1l1l1l_l1_ = TRANSLATE(l1l1l1l1l1l_l1_)
	if l11l11ll1l1l_l1_: DIALOG_NOTIFICATION(l1l1l1l1l1l_l1_,l11lll_l1_ (u"ࠩไุ้ࠦศ่าสࠤฬ๊ๅ้ไ฼ࠫ嗐"),time=2000)
	else: DIALOG_NOTIFICATION(l1l1l1l1l1l_l1_,l11lll_l1_ (u"ࠪฮ๊ࠦฬๅสࠣห้ษโิษ่ࠫ嗑"),time=2000)
	return l11l11ll1l1l_l1_
def l11l11ll1111_l1_(l11l11ll1lll_l1_=True):
	if not l11l11ll1lll_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ嗒"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭嗓"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ嗔"))
		if results:
			contentsDICT = results
			return
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ嗕"),l11lll_l1_ (u"ࠨࠩ嗖"),l11lll_l1_ (u"ࠩࠪ嗗"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭嗘"),l11lll_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ嗙"))
	if l1ll11l111_l1_!=1: return
	l11l111l1ll1_l1_ = menuItemsLIST
	l11l11l1lll1_l1_,l11l11l1ll11_l1_ = 0,l11lll_l1_ (u"ࠬ࠭嗚")
	for l1l1l1l1l1l_l1_ in l11l1l11ll1_l1_:
		time.sleep(0.5)
		l11l11ll1l1l_l1_ = l11l1l11lll1_l1_(l1l1l1l1l1l_l1_)
		if l11l11ll1l1l_l1_:
			l11l11l1lll1_l1_ += 1
			l11l11l1ll11_l1_ += l11lll_l1_ (u"࠭ࠠࠨ嗛")+l1l1l1l1l1l_l1_
			if l11l11l1lll1_l1_>=l11l1l111111_l1_: break
	menuItemsLIST[:] = l11l111l1ll1_l1_
	if l11l11l1lll1_l1_>=l11l1l111111_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嗜"),l11lll_l1_ (u"ࠨࠩ嗝"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嗞"),l11lll_l1_ (u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫ嗟")+str(l11l11l1lll1_l1_)+l11lll_l1_ (u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩ嗠")+l11l11l1ll11_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭嗡"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙࡟ࡂࡎࡏࠫ嗢"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嗣"),l11lll_l1_ (u"ࠨࠩ嗤"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嗥"),l11lll_l1_ (u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩ嗦"))
	return
def l11l11l11l1l_l1_(l11lllllll1l_l1_,options):
	l11llllll11_l1_ = False
	l11l111l11l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllll11_l1_ and l11lll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ嗧") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ嗨"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭嗩"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ嗪")+l11lllllll1l_l1_)
	elif l11lll_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ嗫") not in options or l11lll_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ嗬") not in options:
		import IPTV
		message = l11lll_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ嗭")
		if l11lll_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ嗮") not in options:
			try: IPTV.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ嗯"),l11lll_l1_ (u"࠭ࠧ嗰"),l11lll_l1_ (u"ࠧࠨ嗱"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嗲"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嗳"),l11lll_l1_ (u"ࠪࠫ嗴"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ嗵"),message)
			try: IPTV.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ嗶"),l11lll_l1_ (u"࠭ࠧ嗷"),l11lll_l1_ (u"ࠧࠨ嗸"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嗹"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嗺"),l11lll_l1_ (u"ࠪࠫ嗻"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ嗼"),message)
			try: IPTV.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ嗽"),l11lll_l1_ (u"࠭ࠧ嗾"),l11lll_l1_ (u"ࠧࠨ嗿"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嘀"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嘁"),l11lll_l1_ (u"ࠪࠫ嘂"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ嘃"),message)
		if l11lll_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ嘄") not in options:
			try: IPTV.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭嘅"),l11lll_l1_ (u"ࠧࠨ嘆"),l11lll_l1_ (u"ࠨࠩ嘇"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嘈"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嘉"),l11lll_l1_ (u"ࠫࠬ嘊"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ嘋"),message)
			try: IPTV.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ嘌"),l11lll_l1_ (u"ࠧࠨ嘍"),l11lll_l1_ (u"ࠨࠩ嘎"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嘏"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嘐"),l11lll_l1_ (u"ࠫࠬ嘑"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ嘒"),message)
		results = menuItemsLIST
		if l11llllll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭嘓"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ嘔")+l11lllllll1l_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11l111l11l1_l1_
	return results
def l11l11ll11ll_l1_(l11lllllll1l_l1_,options):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嘕"),l11lll_l1_ (u"ࠩࠪ嘖"),l11lll_l1_ (u"ࠪࠫ嘗"),options)
	l11llllll11_l1_ = False
	l11l111l11l1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllll11_l1_ and l11lll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ嘘") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ嘙"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ嘚"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ嘛")+l11lllllll1l_l1_)
	elif l11lll_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ嘜") not in options or l11lll_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ嘝") not in options:
		import l1l11l1ll111_l1_
		message = l11lll_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ嘞")
		if l11lll_l1_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ嘟") not in options:
			try: l1l11l1ll111_l1_.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ嘠"),l11lll_l1_ (u"࠭ࠧ嘡"),l11lll_l1_ (u"ࠧࠨ嘢"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嘣"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嘤"),l11lll_l1_ (u"ࠪࠫ嘥"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ嘦"),message)
			try: l1l11l1ll111_l1_.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ嘧"),l11lll_l1_ (u"࠭ࠧ嘨"),l11lll_l1_ (u"ࠧࠨ嘩"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嘪"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嘫"),l11lll_l1_ (u"ࠪࠫ嘬"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ嘭"),message)
			try: l1l11l1ll111_l1_.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ嘮"),l11lll_l1_ (u"࠭ࠧ嘯"),l11lll_l1_ (u"ࠧࠨ嘰"),options+l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嘱"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嘲"),l11lll_l1_ (u"ࠪࠫ嘳"),l11lll_l1_ (u"๊ࠫ๎โฺࠢใࡑ࠸࡛ࠠๅๆไ๎ิ๐่่ษอࠫ嘴"),message)
		if l11lll_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ嘵") not in options:
			try: l1l11l1ll111_l1_.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭嘶"),l11lll_l1_ (u"ࠧࠨ嘷"),l11lll_l1_ (u"ࠨࠩ嘸"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嘹"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嘺"),l11lll_l1_ (u"ࠫࠬ嘻"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ嘼"),message)
			try: l1l11l1ll111_l1_.GROUPS(l11lllllll1l_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ嘽"),l11lll_l1_ (u"ࠧࠨ嘾"),l11lll_l1_ (u"ࠨࠩ嘿"),options+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ噀"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ噁"),l11lll_l1_ (u"ࠫࠬ噂"),l11lll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩ噃"),message)
		results = menuItemsLIST
		if l11llllll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ噄"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧ噅")+l11lllllll1l_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11l111l11l1_l1_
	return results
def l11l11ll1l11_l1_(l11lllllll1l_l1_,options,l11l111lllll_l1_):
	if l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭噆") in options and l11l111lllll_l1_==l11lll_l1_ (u"ࠩࠪ噇"): l11l11ll1111_l1_(True)
	elif l11l111lllll_l1_: l11l11ll1111_l1_(False)
	l11l11l111l1_l1_ = options.replace(l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ噈"),l11lll_l1_ (u"ࠫࠬ噉")).replace(l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ噊"),l11lll_l1_ (u"࠭ࠧ噋")).replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ噌"),l11lll_l1_ (u"ࠨࠩ噍"))
	if not l11l111lllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ噎"),l11lll_l1_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ噏"),l11lll_l1_ (u"ࠫࠬ噐"),763,l11lll_l1_ (u"ࠬ࠭噑"),l11lll_l1_ (u"࠭ࠧ噒"),l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ噓")+l11l11l111l1_l1_,l11lll_l1_ (u"ࠨࠩ噔"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ噕"):l11lllllll1l_l1_})
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ噖"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ噗"),l11lll_l1_ (u"ࠬ࠭噘"),9999)
	l1ll1l11l1_l1_ = [l11lll_l1_ (u"࠭รโๆส้ࠬ噙"),l11lll_l1_ (u"ࠧๆี็ื้อสࠨ噚"),l11lll_l1_ (u"ࠨ็ึีา๐วหࠩ噛"),l11lll_l1_ (u"ࠩหีฬ๋ฬࠨ噜"),l11lll_l1_ (u"ࠪว฼็วๅ๋ࠢ็ึะ่็ࠩ噝"),l11lll_l1_ (u"ࠫึ๋ึศ่ࠪ噞"),l11lll_l1_ (u"ࠬษอะอ࠰วำืࠧ噟"),l11lll_l1_ (u"࠭ำๅษึ่ࠬ噠"),l11lll_l1_ (u"ࠧๆ๊ึ๎็๏ࠧ噡"),l11lll_l1_ (u"ࠨลื๋ึ࠳รไอิࠫ噢"),l11lll_l1_ (u"ࠩส่ว์ࠧ噣"),l11lll_l1_ (u"ฺࠪา้ࠧ噤"),l11lll_l1_ (u"ࠫึ๐วืหࠪ噥"),l11lll_l1_ (u"ࠬ์๊หใ็็ุ࠭噦"),l11lll_l1_ (u"࠭ๅๆอ็๎๋࠭噧"),l11lll_l1_ (u"ࠧษอࠣั๏࠭器"),l11lll_l1_ (u"ࠨัํ๊๏ฯࠧ噩"),l11lll_l1_ (u"ࠩึ๊ํอสࠨ噪"),l11lll_l1_ (u"ࠪวำื้ࠨ噫")]
	l11l111l1lll_l1_ = [l11lll_l1_ (u"ࠫฬ็ไศ็ࠪ噬"),l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ噭"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ噮"),l11lll_l1_ (u"ࠧโๆ่ࠫ噯")]
	l11l1l1111ll_l1_ = [l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ噰"),l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ噱")]
	l11l1l1l11ll_l1_ = [l11lll_l1_ (u"ุ้ࠪอัฮࠩ噲"),l11lll_l1_ (u"ู๊ࠫัฮ์สฮࠬ噳")]
	l11l11l1111l_l1_ = [l11lll_l1_ (u"ࠬฮัศ็ฯࠫ噴"),l11lll_l1_ (u"࠭ࡳࡩࡱࡺࠫ噵"),l11lll_l1_ (u"ࠧหๆไึ๏๎ๆࠨ噶"),l11lll_l1_ (u"ࠨฬ็๎ๆุ๊้่ࠪ噷")]
	l11l11lllll1_l1_ = [l11lll_l1_ (u"ࠩส๊๊๐ࠧ噸"),l11lll_l1_ (u"ࠪ็ึะ่็ࠩ噹"),l11lll_l1_ (u"่ࠫอัห๊้ࠫ噺"),l11lll_l1_ (u"ࠬࡱࡩࡥࡵࠪ噻"),l11lll_l1_ (u"࠭ืโๆࠪ噼"),l11lll_l1_ (u"ࠧศูไห้࠭噽")]
	l111l111_l1_ = [l11lll_l1_ (u"ࠨำฺ่ฬ์ࠧ噾")]
	l1lllll1l_l1_ = [l11lll_l1_ (u"ࠩสัิัࠧ噿"),l11lll_l1_ (u"ࠪหำืࠧ嚀"),l11lll_l1_ (u"๊ࠫ๎ฮาࠩ嚁"),l11lll_l1_ (u"ࠬาฯ๋ัࠪ嚂"),l11lll_l1_ (u"࠭ๅืษไࠫ嚃"),l11lll_l1_ (u"ࠧฮัํฯࠬ嚄")]
	l11l11l11ll1_l1_ = [l11lll_l1_ (u"ࠨี็หุ๊ࠧ嚅"),l11lll_l1_ (u"ࠩึุ่๊็ࠨ嚆")]
	l11l111l1111_l1_ = [l11lll_l1_ (u"ࠪห฿อๆ๋ࠩ嚇"),l11lll_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ嚈"),l11lll_l1_ (u"้ࠬไ๋สࠪ嚉"),l11lll_l1_ (u"࠭อโๆࠪ嚊"),l11lll_l1_ (u"ࠧ࡮ࡷࡶ࡭ࡨ࠭嚋")]
	l11111l11_l1_ = [l11lll_l1_ (u"ࠨษๆฯึ࠭嚌"),l11lll_l1_ (u"ࠩสุ์ืࠧ嚍"),l11lll_l1_ (u"้๊ࠪ๐า่ࠩ嚎"),l11lll_l1_ (u"ࠫฬ฿ไ๊ࠩ嚏"),l11lll_l1_ (u"๋ࠬฮหษิ๋ࠬ嚐"),l11lll_l1_ (u"࠭ๅฯฬสีฬะࠧ嚑"),l11lll_l1_ (u"ࠧศไ๋ํࠬ嚒")]
	l11l1111llll_l1_ = [l11lll_l1_ (u"ࠨษ็ห๋࠭嚓"),l11lll_l1_ (u"ࠩะห้๐ࠧ嚔"),l11lll_l1_ (u"้ࠪะฮสࠨ嚕"),l11lll_l1_ (u"ࠫึอฦอࠩ嚖")]
	l11l111l11ll_l1_ = [l11lll_l1_ (u"ࠬ฼อไࠩ嚗"),l11lll_l1_ (u"࠭ใ้็ํำ๏࠭嚘")]
	l11l1l11l111_l1_ = [l11lll_l1_ (u"ࠧา์สฺ์࠭嚙"),l11lll_l1_ (u"ࠨๅ๋ี์࠭嚚"),l11lll_l1_ (u"ู่ࠩฬืู่ࠩ嚛"),l11lll_l1_ (u"ุࠪํะࠧ嚜"),l11lll_l1_ (u"ࠫึ๐วืหࠪ嚝")]
	l11l11lll11l_l1_ = [l11lll_l1_ (u"ࠬ์๊หใ็็ุ࠭嚞"),l11lll_l1_ (u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧ嚟"),l11lll_l1_ (u"ࠧ็์อๅ้๐ใิࠩ嚠")]
	l11l111l1l1l_l1_ = [l11lll_l1_ (u"ࠨ็่ฯ้๐ๆࠨ嚡"),l11lll_l1_ (u"ࠩสุำอีࠨ嚢"),l11lll_l1_ (u"๊ࠪั๎ๅࠨ嚣")]
	l1l1lll1l_l1_ = [l11lll_l1_ (u"ࠫอัࠠฮ์ࠪ嚤"),l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ嚥"),l11lll_l1_ (u"࠭โ็ษ๊ࠫ嚦"),l11lll_l1_ (u"ࠧใ่๋หฯ࠭嚧")]
	l11l11llll11_l1_ = [l11lll_l1_ (u"ࠨัํ๊ࠬ嚨"),l11lll_l1_ (u"ࠩสำ฾๐็ࠨ嚩"),l11lll_l1_ (u"ࠪึ๏อัศฬࠪ嚪"),l11lll_l1_ (u"้ࠫ฽ๅ๋ษอࠫ嚫"),l11lll_l1_ (u"ࠬีูศรࠪ嚬"),l11lll_l1_ (u"࠭โาษ้ࠫ嚭"),l11lll_l1_ (u"ࠧใืสสิ࠭嚮"),l11lll_l1_ (u"ࠨำฮหฦ࠭嚯"),l11lll_l1_ (u"่ࠩีั฿๊่ࠩ嚰"),l11lll_l1_ (u"ࠪหีอๆࠨ嚱"),l11lll_l1_ (u"ࠫฬูไศ็ࠪ嚲"),l11lll_l1_ (u"ࠬะ่ศึํัࠬ嚳"),l11lll_l1_ (u"࠭ฮุสࠪ嚴"),l11lll_l1_ (u"ࠧฮ๊ี์๏࠭嚵"),l11lll_l1_ (u"ࠨ฻อฬฬะࠧ嚶"),l11lll_l1_ (u"่ࠩ์ฬ๊๊ะࠩ嚷"),l11lll_l1_ (u"๊ࠪํอู๋ࠩ嚸"),l11lll_l1_ (u"ࠫ฾่ววัࠪ嚹"),l11lll_l1_ (u"ࠬอๆศึํำࠬ嚺")]
	l11l111ll111_l1_ = [l11lll_l1_ (u"࠭࠱࠺ࠩ嚻"),l11lll_l1_ (u"ࠧ࠳࠲ࠪ嚼"),l11lll_l1_ (u"ࠨ࠴࠴ࠫ嚽"),l11lll_l1_ (u"ࠩ࠵࠶ࠬ嚾"),l11lll_l1_ (u"ࠪ࠶࠸࠭嚿"),l11lll_l1_ (u"ࠫ࠷࠺ࠧ囀"),l11lll_l1_ (u"ࠬ࠸࠵ࠨ囁"),l11lll_l1_ (u"࠭࠲࠷ࠩ囂")]
	if not l11l111lllll_l1_:
		l11l111lllll_l1_ = 0
		for l11l11ll111l_l1_ in l1ll1l11l1_l1_:
			l11l111lllll_l1_ += 1
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囃"),l111ll_l1_+l11l11ll111l_l1_,l11lll_l1_ (u"ࠨࠩ囄"),763,l11lll_l1_ (u"ࠩࠪ囅"),str(l11l111lllll_l1_),l11l11l111l1_l1_,l11lll_l1_ (u"ࠪࠫ囆"),{l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囇"):l11lllllll1l_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1ll111l111_l1_ = name.lower()
			category = []
			if any(value in l1ll111l111_l1_ for value in l11l111l1lll_l1_): category.append(1)
			if any(value in l1ll111l111_l1_ for value in l11l1l1111ll_l1_): category.append(2)
			if any(value in l1ll111l111_l1_ for value in l11l1l1l11ll_l1_): category.append(3)
			if any(value in l1ll111l111_l1_ for value in l11l11l1111l_l1_): category.append(4)
			if any(value in l1ll111l111_l1_ for value in l11l11lllll1_l1_): category.append(5)
			if any(value in l1ll111l111_l1_ for value in l111l111_l1_): category.append(6)
			if any(value in l1ll111l111_l1_ for value in l1lllll1l_l1_) and l1ll111l111_l1_ not in [l11lll_l1_ (u"ࠬอฮา๋ࠪ囈")]: category.append(7)
			if any(value in l1ll111l111_l1_ for value in l11l11l11ll1_l1_): category.append(8)
			if any(value in l1ll111l111_l1_ for value in l11l111l1111_l1_): category.append(9)
			if any(value in l1ll111l111_l1_ for value in l11111l11_l1_): category.append(10)
			if any(value in l1ll111l111_l1_ for value in l11l1111llll_l1_): category.append(11)
			if any(value in l1ll111l111_l1_ for value in l11l111l11ll_l1_): category.append(12)
			if any(value in l1ll111l111_l1_ for value in l11l1l11l111_l1_): category.append(13)
			if any(value in l1ll111l111_l1_ for value in l11l11lll11l_l1_): category.append(14)
			if any(value in l1ll111l111_l1_ for value in l11l111l1l1l_l1_): category.append(15)
			if any(value in l1ll111l111_l1_ for value in l1l1lll1l_l1_): category.append(16)
			if any(value in l1ll111l111_l1_ for value in l11l11llll11_l1_): category.append(17)
			if any(value in l1ll111l111_l1_ for value in l11l111ll111_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l11l111lllll_l1_:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囉"),l111ll_l1_+name,name,166,l11lll_l1_ (u"ࠧࠨ囊"),l11lll_l1_ (u"ࠨࠩ囋"),l11l11l111l1_l1_+l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭囌"))
	return
def l11l1l1111l1_l1_(l11lllllll1l_l1_,options):
	l11llllll11_l1_ = False
	if l11llllll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ囍"),l11lll_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ囎"),l11lll_l1_ (u"ࠬ࠭囏"),764,l11lll_l1_ (u"࠭ࠧ囐"),l11lll_l1_ (u"ࠧࠨ囑"),l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭囒"),l11lll_l1_ (u"ࠩࠪ囓"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囔"):l11lllllll1l_l1_})
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ囕"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ囖"),l11lll_l1_ (u"࠭ࠧ囗"),9999)
	l11l111l11l1_l1_ = menuItemsLIST[:]
	import IPTV
	if l11lllllll1l_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l11lllllll1l_l1_,True): return
		l11l11l11lll_l1_ = l11l11l11l1l_l1_(l11lllllll1l_l1_,options)
		l1ll1ll1l11_l1_ = sorted(l11l11l11lll_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠧࠨ囘"),True): return
		if l11llllll11_l1_ and l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭囙") not in options:
			l1ll1ll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ囚"),l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ四"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨ囜"))
		else:
			l11l111ll11l_l1_,l1ll1ll1l11_l1_,l11l11l11lll_l1_ = [],[],[]
			for l11lll1111l1_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1ll1l11_l1_ += l11l11l11l1l_l1_(str(l11lll1111l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ in l1ll1ll1l11_l1_:
				if text not in l11l111ll11l_l1_:
					l11l111ll11l_l1_.append(text)
					l11l1l11l1l1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll11111l1_l1_
					l11l11l11lll_l1_.append(l11l1l11l1l1_l1_)
			l1ll1ll1l11_l1_ = sorted(l11l11l11lll_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ囝"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪ回"),l1ll1ll1l11_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11l111l11l1_l1_+l1ll1ll1l11_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ囟"))
	return
def l11l1l11ll1l_l1_(l11lllllll1l_l1_,options):
	l11llllll11_l1_ = False
	if l11llllll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭因"),l11lll_l1_ (u"ࠩอัิ๐ห้ࠡำ๋ࠥอไใษษ้ฮ࠭囡"),l11lll_l1_ (u"ࠪࠫ团"),765,l11lll_l1_ (u"ࠫࠬ団"),l11lll_l1_ (u"ࠬ࠭囤"),l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ囥"),l11lll_l1_ (u"ࠧࠨ囦"),{l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囧"):l11lllllll1l_l1_})
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ囨"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ囩"),l11lll_l1_ (u"ࠫࠬ囪"),9999)
	l11l111l11l1_l1_ = menuItemsLIST[:]
	import l1l11l1ll111_l1_
	if l11lllllll1l_l1_:
		if not l1l11l1ll111_l1_.CHECK_TABLES_EXIST(l11lllllll1l_l1_,True): return
		l11l11l11lll_l1_ = l11l11ll11ll_l1_(l11lllllll1l_l1_,options)
		l1ll1ll1l11_l1_ = sorted(l11l11l11lll_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not l1l11l1ll111_l1_.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠬ࠭囫"),True): return
		if l11llllll11_l1_ and l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ囬") not in options:
			l1ll1ll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ园"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ囮"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬ囯"))
		else:
			l11l111ll11l_l1_,l1ll1ll1l11_l1_,l11l11l11lll_l1_ = [],[],[]
			for l11lll1111l1_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1ll1l11_l1_ += l11l11ll11ll_l1_(str(l11lll1111l1_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ in l1ll1ll1l11_l1_:
				if text not in l11l111ll11l_l1_:
					l11l111ll11l_l1_.append(text)
					l11l1l11l1l1_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll11111l1_l1_
					l11l11l11lll_l1_.append(l11l1l11l1l1_l1_)
			l1ll1ll1l11_l1_ = sorted(l11l11l11lll_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ困"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ囱"),l1ll1ll1l11_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11l111l11l1_l1_+l1ll1ll1l11_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ囲"))
	return
def l11l111lll1l_l1_(group,options):
	# l11l111ll1ll_l1_ & iptv
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ図"),l11lll_l1_ (u"ࠧࠨ围"),group,options)
	l11llllll11_l1_ = False
	results = []
	l11l11ll11l1_l1_ = l11lll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ囵") if l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ囶") in options else l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ囷")
	if l11llllll11_l1_: results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ囸"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ囹")+l11l11ll11l1_l1_[:-1],group)
	if not results:
		for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			if l11llllll11_l1_: results += READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ固"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ囻")+l11l11ll11l1_l1_[:-1],l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ囼")+l11l11ll11l1_l1_+str(l11lllllll1l_l1_))
			elif l11l11ll11l1_l1_==l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ国"): results += l11l11l11l1l_l1_(str(l11lllllll1l_l1_),l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ图"))
			elif l11l11ll11l1_l1_==l11lll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ囿"): results += l11l11ll11ll_l1_(str(l11lllllll1l_l1_),l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ圀"))
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ in results:
			if text==group: l1l1l1l11111_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_)
		items,l1l1lll_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ in menuItemsLIST:
			l11l11lll1ll_l1_ = type,name[4:],url,mode,l11l_l1_,l1l11l1_l1_,text,context,l11lll_l1_ (u"࠭ࠧ圁")
			if l11l11lll1ll_l1_ not in l1l1lll_l1_:
				l1l1lll_l1_.append(l11l11lll1ll_l1_)
				item = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_
				items.append(item)
		results = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l11llllll11_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ圂")+l11l11ll11l1_l1_[:-1],group,results,PERMANENT_CACHE)
	if l11lll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ圃") in options and len(results)>l11l1l111l11_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ圄"),l11lll_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ圅")+group+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ圆"),group,165,l11lll_l1_ (u"ࠬ࠭圇"),l11lll_l1_ (u"࠭ࠧ圈"),l11l11ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭圉"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圊"),l11lll_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ國"),group,165,l11lll_l1_ (u"ࠪࠫ圌"),l11lll_l1_ (u"ࠫࠬ圍"),l11l11ll11l1_l1_+l11lll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ圎"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ圏"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圐"),l11lll_l1_ (u"ࠨࠩ圑"),9999)
		results = menuItemsLIST+random.sample(results,l11l1l111l11_l1_)
	menuItemsLIST[:] = results
	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭園"))
	return
def l11l1l1l1l11_l1_(options):
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ圓"),l11lll_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ圔"),l11lll_l1_ (u"ࠬ࠭圕"),161,l11lll_l1_ (u"࠭ࠧ圖"),l11lll_l1_ (u"ࠧࠨ圗"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ團"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ圙"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ圚"),l11lll_l1_ (u"ࠫࠬ圛"),9999)
	l1l1l11ll1l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圜"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢ࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ圝")+l11lll_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ圞"),l11lll_l1_ (u"ࠨࠩ土"),147)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ圠"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圡")+l11lll_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭圢"),l11lll_l1_ (u"ࠬ࠭圣"),148)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圤"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ圥")+l11lll_l1_ (u"ࠨไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠪ圦"),l11lll_l1_ (u"ࠩࠪ圧"),28)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ在"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ圩")+l11lll_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ圪"),l11lll_l1_ (u"࠭ࠧ圫"),41)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ圬"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ圭")+l11lll_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ圮"),l11lll_l1_ (u"ࠪࠫ圯"),135)
	import l1ll11l11ll1_l1_
	l1ll11l11ll1_l1_.ITEMS(l11lll_l1_ (u"ࠫ࠵࠭地"),False)
	l1ll11l11ll1_l1_.ITEMS(l11lll_l1_ (u"ࠬ࠷ࠧ圱"),False)
	l1ll11l11ll1_l1_.ITEMS(l11lll_l1_ (u"࠭࠲ࠨ圲"),False)
	#l1ll11l11ll1_l1_.ITEMS(l11lll_l1_ (u"ࠧ࠴ࠩ圳"),False)
	if l11lll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ圴") in options:
		menuItemsLIST[:] = l11l11l1l1ll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11l1l111l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1l111l11_l1_)
	menuItemsLIST[:] = l1l1l11ll1l1_l1_+menuItemsLIST
	return
def l11l1l1l11l1_l1_(options):
	options = options.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ圵"),l11lll_l1_ (u"ࠪࠫ圶")).replace(l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ圷"),l11lll_l1_ (u"ࠬ࠭圸"))
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ圹") : l11lll_l1_ (u"ࠧࠨ场") }
	url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ圻")
	data = {l11lll_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ圼"):l11lll_l1_ (u"ࠪ࠹࠵࠭圽")}
	data = l1ll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ圾"),url,data,headers,l11lll_l1_ (u"ࠬ࠭圿"),l11lll_l1_ (u"࠭ࠧ址"),l11lll_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩ坁"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ坂"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ坃"),block,re.DOTALL)
	l11l1111lll1_l1_,l11l111ll1l1_l1_ = list(zip(*items))
	l11l1l11ll11_l1_ = []
	l11l1l1l111l_l1_ = [l11lll_l1_ (u"ࠪࠤࠬ坄"),l11lll_l1_ (u"ࠫࠧ࠭坅"),l11lll_l1_ (u"ࠬࡦࠧ坆"),l11lll_l1_ (u"࠭ࠬࠨ均"),l11lll_l1_ (u"ࠧ࠯ࠩ坈"),l11lll_l1_ (u"ࠨ࠼ࠪ坉"),l11lll_l1_ (u"ࠩ࠾ࠫ坊"),l11lll_l1_ (u"ࠥࠫࠧ坋"),l11lll_l1_ (u"ࠫ࠲࠭坌")]
	l11l1l11111l_l1_ = l11l111ll1l1_l1_+l11l1111lll1_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭坍"),l11lll_l1_ (u"࠭ࠧ坎"),l11lll_l1_ (u"ࠧࠨ坏"),str(l11l1l11111l_l1_))
	for word in l11l1l11111l_l1_:
		if word in l11l111ll1l1_l1_: l11l11lll111_l1_ = 2
		if word in l11l1111lll1_l1_: l11l11lll111_l1_ = 4
		l11l11l11l11_l1_ = [i in word for i in l11l1l1l111l_l1_]
		if any(l11l11l11l11_l1_):
			index = l11l11l11l11_l1_.index(True)
			l11l11l11111_l1_ = l11l1l1l111l_l1_[index]
			l11l1l111ll1_l1_ = l11lll_l1_ (u"ࠨࠩ坐")
			if word.count(l11l11l11111_l1_)>1: l11l1l111lll_l1_,l11l1l111l1l_l1_,l11l1l111ll1_l1_ = word.split(l11l11l11111_l1_,2)
			else: l11l1l111lll_l1_,l11l1l111l1l_l1_ = word.split(l11l11l11111_l1_,1)
			if len(l11l1l111lll_l1_)>l11l11lll111_l1_: l11l1l11ll11_l1_.append(l11l1l111lll_l1_.lower())
			if len(l11l1l111l1l_l1_)>l11l11lll111_l1_: l11l1l11ll11_l1_.append(l11l1l111l1l_l1_.lower())
			if len(l11l1l111ll1_l1_)>l11l11lll111_l1_: l11l1l11ll11_l1_.append(l11l1l111ll1_l1_.lower())
		elif len(word)>l11l11lll111_l1_: l11l1l11ll11_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11l1l11ll11_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11l1l11ll11_l1_)),l11l1l11ll11_l1_)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ坑")
	if l11lll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ坒") in options:
		l11l111l1l11_l1_ = l1l1ll111lll_l1_
	elif l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ坓") in options:
		l11l111l1l11_l1_ = [l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ坔")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"࠭ࠧ坕"),True): return
	elif l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭坖") in options:
		l11l111l1l11_l1_ = [l11lll_l1_ (u"ࠨࡏ࠶࡙ࠬ块")]
		import l1l11l1ll111_l1_
		if not l1l11l1ll111_l1_.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ坘"),True): return
	count,l11l11l1llll_l1_ = 0,0
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坙"),l11lll_l1_ (u"ࠫࡠࠦࠠ࡞ࠢ࠽ห้ฮอฬࠢ฼๊ࠬ坚"),l11lll_l1_ (u"ࠬ࠭坛"),164,l11lll_l1_ (u"࠭ࠧ坜"),l11lll_l1_ (u"ࠧࠨ坝"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭坞")+options)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坟"),l11lll_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ坠"),l11lll_l1_ (u"ࠫࠬ坡"),164,l11lll_l1_ (u"ࠬ࠭坢"),l11lll_l1_ (u"࠭ࠧ坣"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ坤")+options)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭坥"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ坦"),l11lll_l1_ (u"ࠪࠫ坧"),9999)
	l11l1111ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11l1l1l1111_l1_ = []
	for word in l11l1l11ll11_l1_:
		l11l1l111l1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࡠࠨࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩ坨"),word,re.DOTALL)
		if l11l1l111l1l_l1_: word = word.split(l11l1l111l1l_l1_[0],1)[0]
		l11l11llllll_l1_ = word.replace(l11lll_l1_ (u"ࠬ๗ࠧ坩"),l11lll_l1_ (u"࠭ࠧ坪")).replace(l11lll_l1_ (u"ࠧ๏ࠩ坫"),l11lll_l1_ (u"ࠨࠩ坬")).replace(l11lll_l1_ (u"ࠩ๎ࠫ坭"),l11lll_l1_ (u"ࠪࠫ坮")).replace(l11lll_l1_ (u"ࠫ๔࠭坯"),l11lll_l1_ (u"ࠬ࠭坰")).replace(l11lll_l1_ (u"࠭์ࠨ坱"),l11lll_l1_ (u"ࠧࠨ坲"))
		l11l11llllll_l1_ = l11l11llllll_l1_.replace(l11lll_l1_ (u"ࠨ๒ࠪ坳"),l11lll_l1_ (u"ࠩࠪ坴")).replace(l11lll_l1_ (u"ࠪ๑ࠬ坵"),l11lll_l1_ (u"ࠫࠬ坶")).replace(l11lll_l1_ (u"ࠬ๘ࠧ坷"),l11lll_l1_ (u"࠭ࠧ坸")).replace(l11lll_l1_ (u"ࠧญࠩ坹"),l11lll_l1_ (u"ࠨࠩ坺")).replace(l11lll_l1_ (u"ࠩใࠫ坻"),l11lll_l1_ (u"ࠪࠫ坼"))
		if l11l11llllll_l1_: l11l1l1l1111_l1_.append(l11l11llllll_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11l1l1l1111_l1_)),l11l1l1l1111_l1_)
	l11l11llll1l_l1_ = []
	for l11ll111l1_l1_ in range(0,20):
		search = random.sample(l11l1l1l1111_l1_,1)[0]
		if search in l11l11llll1l_l1_: continue
		l11l11llll1l_l1_.append(search)
		l1l1l1l1l1l_l1_ = random.sample(l11l111l1l11_l1_,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ坽"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡘ࡬ࡨࡪࡵࠠࡔࡧࡤࡶࡨ࡮ࠠࠡࠢࡶ࡭ࡹ࡫࠺ࠨ坾")+str(l1l1l1l1l1l_l1_)+l11lll_l1_ (u"࠭ࠠࠡࡵࡨࡥࡷࡩࡨ࠻ࠩ坿")+search)
		#results = l1l1l1l11111_l1_(l11lll_l1_ (u"ࠧࠨ垀"),l11lll_l1_ (u"ࠨࠩ垁"),l11lll_l1_ (u"ࠩࠪ垂"),l1l1l1l1l1l_l1_,l11lll_l1_ (u"ࠪࠫ垃"),l11lll_l1_ (u"ࠫࠬ垄"),search+l11lll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ垅"),l11lll_l1_ (u"࠭ࠧ垆"),l11lll_l1_ (u"ࠧࠨ垇"))
		l1l1l11ll11_l1_,l1l1l1l1l11_l1_,l1l1ll1l1l1_l1_ = l1l1l11l111_l1_(l1l1l1l1l1l_l1_)
		l1l1l1l1l11_l1_(search+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭垈"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ垉"),l11lll_l1_ (u"ࠪࠫ垊"))
	l11l1111ll1l_l1_[0][1] = l11lll_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ型")+search+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻สะฯࠥ฿ๆ࡞ࠩ垌")
	menuItemsLIST[:] = l11l11l1l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11l1l111l11_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11l1l111l11_l1_)
	menuItemsLIST[:] = l11l1111ll1l_l1_+menuItemsLIST
	#import l1ll11ll1ll_l1_
	#l1ll11ll1ll_l1_.SEARCH(search)
	return
def l11l1l11l11l_l1_(l11l111llll1_l1_,options):
	l11l111llll1_l1_ = l11l111llll1_l1_.replace(l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ垍"),l11lll_l1_ (u"ࠧࠨ垎"))
	options = options.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ垏"),l11lll_l1_ (u"ࠩࠪ垐")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ垑"),l11lll_l1_ (u"ࠫࠬ垒"))
	l11l11ll1111_l1_(False)
	if contentsDICT=={}: return
	if l11lll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ垓") in options:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垔"),l11lll_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ垕")+l11l111llll1_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ垖"),l11l111llll1_l1_,166,l11lll_l1_ (u"ࠩࠪ垗"),l11lll_l1_ (u"ࠪࠫ垘"),l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ垙")+options)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垚"),l11lll_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ垛"),l11l111llll1_l1_,166,l11lll_l1_ (u"ࠧࠨ垜"),l11lll_l1_ (u"ࠨࠩ垝"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ垞")+options)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ垟"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ垠"),l11lll_l1_ (u"ࠬ࠭垡"),9999)
	for l1l1ll11_l1_ in sorted(list(contentsDICT[l11l111llll1_l1_].keys())):
		type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = contentsDICT[l11l111llll1_l1_][l1l1ll11_l1_]
		if l11lll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ垢") in options or len(contentsDICT[l11l111llll1_l1_])==1:
			l1l1l1l11111_l1_(type,l11lll_l1_ (u"ࠧࠨ垣"),url,l1l1ll11ll1l_l1_,l11lll_l1_ (u"ࠨࠩ垤"),l1l11l1_l1_,text,l11lll_l1_ (u"ࠩࠪ垥"),l11lll_l1_ (u"ࠪࠫ垦"))
			menuItemsLIST[:] = l11l11l1l1ll_l1_(menuItemsLIST)
			l11l111l11l1_l1_,l1ll1ll1l11_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1ll1ll1l11_l1_)
			if l11lll_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭垧") in options: menuItemsLIST[:] = l11l111l11l1_l1_+l1ll1ll1l11_l1_[:l11l1l111l11_l1_]
			else: menuItemsLIST[:] = l11l111l11l1_l1_+l1ll1ll1l11_l1_
		elif l11lll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭垨") in options: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垩"),l1l1ll11_l1_,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_)
	return
def l11l11l1l111_l1_(options,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ垪"),l11lll_l1_ (u"ࠨࠩ垫"),l11lll_l1_ (u"ࠩࠪ垬"),options)
	options = options.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ垭"),l11lll_l1_ (u"ࠫࠬ垮")).replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ垯"),l11lll_l1_ (u"࠭ࠧ垰"))
	name,l11l11l111ll_l1_ = l11lll_l1_ (u"ࠧࠨ垱"),[]
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垲"),l11lll_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭垳")+name+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭垴"),l11lll_l1_ (u"ࠫࠬ垵"),mode,l11lll_l1_ (u"ࠬ࠭垶"),l11lll_l1_ (u"࠭ࠧ垷"),l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ垸")+options)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垹"),l11lll_l1_ (u"ࠩศ฽ฬีษูࠡ็ฬ่ࠥำๆࠢ฼ุํอฦ๋ࠩ垺"),l11lll_l1_ (u"ࠪࠫ垻"),mode,l11lll_l1_ (u"ࠫࠬ垼"),l11lll_l1_ (u"ࠬ࠭垽"),l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ垾")+options)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ垿"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ埀"),l11lll_l1_ (u"ࠩࠪ埁"),9999)
	l11l111l11l1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	results = []
	if l11lll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ埂") in options:
		l11l11ll1111_l1_(False)
		if contentsDICT=={}: return
		l11l11l1l1l1_l1_ = list(contentsDICT.keys())
		l11l111llll1_l1_ = random.sample(l11l11l1l1l1_l1_,1)[0]
		l11l1l11ll11_l1_ = list(contentsDICT[l11l111llll1_l1_].keys())
		l1l1ll11_l1_ = random.sample(l11l1l11ll11_l1_,1)[0]
		type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = contentsDICT[l11l111llll1_l1_][l1l1ll11_l1_]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ埃"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡽࡥࡣࡵ࡬ࡸࡪࡀࠠࠨ埄")+l1l1ll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ埅")+name+l11lll_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ埆")+url+l11lll_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ埇")+str(l1l1ll11ll1l_l1_))
	elif l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ埈") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠪࠫ埉"),True): return
		for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11l11l11l1l_l1_(str(l11lllllll1l_l1_),options)
		if not results: return
		type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ埊"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ埋")+name+l11lll_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ埌")+url+l11lll_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ埍")+str(l1l1ll11ll1l_l1_))
	elif l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ城") in options:
		import l1l11l1ll111_l1_
		if not l1l11l1ll111_l1_.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ埏"),True): return
		for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11l11ll11ll_l1_(str(l11lllllll1l_l1_),options)
		if not results: return
		type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ埐"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ埑")+name+l11lll_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ埒")+url+l11lll_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ埓")+str(l1l1ll11ll1l_l1_))
	l11l11lll1l1_l1_ = name
	l11l11l1ll1l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ埔"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ埕")+name+l11lll_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ埖")+url+l11lll_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭埗")+str(l1l1ll11ll1l_l1_))
		menuItemsLIST[:] = []
		if l1l1ll11ll1l_l1_==234 and l11lll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ埘") in text: l1l1ll11ll1l_l1_ = 233
		if l1l1ll11ll1l_l1_==714 and l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ埙") in text: l1l1ll11ll1l_l1_ = 713
		if l1l1ll11ll1l_l1_==144: l1l1ll11ll1l_l1_ = 291
		dummy = l1l1l1l11111_l1_(type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_)
		#if l11lll_l1_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ埚") in html: l11l11l1l111_l1_(options,mode)
		if l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ埛") in options and l1l1ll11ll1l_l1_==167: del menuItemsLIST[:3]
		if l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ埜") in options and l1l1ll11ll1l_l1_==168: del menuItemsLIST[:3]
		l11l11l111ll_l1_[:] = l11l11l1l1ll_l1_(menuItemsLIST)
		if l11l11l1ll1l_l1_ and l1l11lllll11_l1_(l11lll_l1_ (u"ࡷࠪั้่ษࠨ埝")) in str(l11l11l111ll_l1_) or l1l11lllll11_l1_(l11lll_l1_ (u"ࡸࠫา๊โ่ࠩ埞")) in str(l11l11l111ll_l1_):
			name = l11l11lll1l1_l1_
			l11l11l111ll_l1_[:] = l11l11l1ll1l_l1_
			break
		l11l11lll1l1_l1_ = name
		l11l11l1ll1l_l1_ = l11l11l111ll_l1_
		if str(l11l11l111ll_l1_).count(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ域"))>0: break
		if str(l11l11l111ll_l1_).count(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ埠"))>0: break
		if l1l1ll11ll1l_l1_==233: break	# iptv l111ll11_l1_ names l11l1lll11l_l1_ of l1l1l_l1_ name
		if l1l1ll11ll1l_l1_==713: break	# l11l111ll1ll_l1_ l111ll11_l1_ names l11l1lll11l_l1_ of l1l1l_l1_ name
		if l1l1ll11ll1l_l1_==291: break	# l1ll1llll_l1_ l11l1l11l1ll_l1_ names l11l1lll11l_l1_ of l1ll1llll_l1_ l11l1l11l1ll_l1_ contents
		if l11l11l111ll_l1_: type,name,url,l1l1ll11ll1l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = random.sample(l11l11l111ll_l1_,1)[0]
	if not name: name = l11lll_l1_ (u"࠭࠮࠯࠰࠱ࠫ埡")
	elif name.count(l11lll_l1_ (u"ࠧࡠࠩ埢"))>1: name = name.split(l11lll_l1_ (u"ࠨࡡࠪ埣"),2)[2]
	name = name.replace(l11lll_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐ࠽ࠤࠬ埤"),l11lll_l1_ (u"ࠪࠫ埥"))#.replace(l11lll_l1_ (u"ࠫ࠱ࡓࡏࡗࡋࡈࡗ࠿ࠦࠧ埦"),l11lll_l1_ (u"ࠬ࠭埧")).replace(l11lll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ埨"),l11lll_l1_ (u"ࠧࠨ埩")).replace(l11lll_l1_ (u"ࠨ࠮ࡏࡍ࡛ࡋ࠺ࠡࠩ埪"),l11lll_l1_ (u"ࠩࠪ埫"))
	name = name.replace(l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ埬"),l11lll_l1_ (u"ࠫࠬ埭"))
	l11l111l11l1_l1_[0][1] = l11lll_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ埮")+name+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ埯")
	for i in range(9): random.shuffle(l11l11l111ll_l1_)
	if l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ埰") in options: menuItemsLIST[:] = l11l111l11l1_l1_+l11l11l111ll_l1_[:l11l1l111l11_l1_]
	else: menuItemsLIST[:] = l11l111l11l1_l1_+l11l11l111ll_l1_
	return
def l11l111lll11_l1_(l11lll11l11l_l1_,l11llll11ll1_l1_):
	l11llll11ll1_l1_ = l11llll11ll1_l1_.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ埱"),l11lll_l1_ (u"ࠩࠪ埲")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ埳"),l11lll_l1_ (u"ࠫࠬ埴"))
	l11l11l1l11l_l1_ = l11llll11ll1_l1_
	if l11lll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭埵") in l11llll11ll1_l1_:
		l11l11l1l11l_l1_ = l11llll11ll1_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ埶"))[0]
		type = l11lll_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ執")
	elif l11lll_l1_ (u"ࠨࡘࡒࡈࠬ埸") in l11lll11l11l_l1_: type = l11lll_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ培")
	elif l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ基") in l11lll11l11l_l1_: type = l11lll_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ埻")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埼"),l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ埽")+type+l11l11l1l11l_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ埾"),l11lll11l11l_l1_,167,l11lll_l1_ (u"ࠨࠩ埿"),l11lll_l1_ (u"ࠩࠪ堀"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ堁")+l11llll11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堂"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ堃"),l11lll11l11l_l1_,167,l11lll_l1_ (u"࠭ࠧ堄"),l11lll_l1_ (u"ࠧࠨ堅"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭堆")+l11llll11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ堇"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ堈"),l11lll_l1_ (u"ࠫࠬ堉"),9999)
	import IPTV
	for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭堊") in l11llll11ll1_l1_: IPTV.GROUPS(str(l11lllllll1l_l1_),l11lll11l11l_l1_,l11llll11ll1_l1_,l11lll_l1_ (u"࠭ࠧ堋"),False)
		else: IPTV.ITEMS(str(l11lllllll1l_l1_),l11lll11l11l_l1_,l11llll11ll1_l1_,l11lll_l1_ (u"ࠧࠨ堌"),False)
	menuItemsLIST[:] = l11l11l1l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1l111l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1l111l11_l1_)
	return
def l11l111l111l_l1_(l11lll11l11l_l1_,l11llll11ll1_l1_):
	l11llll11ll1_l1_ = l11llll11ll1_l1_.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ堍"),l11lll_l1_ (u"ࠩࠪ堎")).replace(l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ堏"),l11lll_l1_ (u"ࠫࠬ堐"))
	l11l11l1l11l_l1_ = l11llll11ll1_l1_
	if l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ堑") in l11llll11ll1_l1_:
		l11l11l1l11l_l1_ = l11llll11ll1_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭堒"))[0]
		type = l11lll_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ堓")
	elif l11lll_l1_ (u"ࠨࡘࡒࡈࠬ堔") in l11lll11l11l_l1_: type = l11lll_l1_ (u"ࠩ࠯࡚ࡎࡊࡅࡐࡕ࠽ࠤࠬ堕")
	elif l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ堖") in l11lll11l11l_l1_: type = l11lll_l1_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ堗")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堘"),l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ堙")+type+l11l11l1l11l_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ堚"),l11lll11l11l_l1_,168,l11lll_l1_ (u"ࠨࠩ堛"),l11lll_l1_ (u"ࠩࠪ堜"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ堝")+l11llll11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堞"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ堟"),l11lll11l11l_l1_,168,l11lll_l1_ (u"࠭ࠧ堠"),l11lll_l1_ (u"ࠧࠨ堡"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭堢")+l11llll11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ堣"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ堤"),l11lll_l1_ (u"ࠫࠬ堥"),9999)
	import l1l11l1ll111_l1_
	for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ堦") in l11llll11ll1_l1_: l1l11l1ll111_l1_.GROUPS(str(l11lllllll1l_l1_),l11lll11l11l_l1_,l11llll11ll1_l1_,l11lll_l1_ (u"࠭ࠧ堧"),False)
		else: l1l11l1ll111_l1_.ITEMS(str(l11lllllll1l_l1_),l11lll11l11l_l1_,l11llll11ll1_l1_,l11lll_l1_ (u"ࠧࠨ堨"),False)
	menuItemsLIST[:] = l11l11l1l1ll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11l1l111l11_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11l1l111l11_l1_)
	return
def l11l11l1l1ll_l1_(menuItemsLIST):
	l11l11l111ll_l1_ = []
	for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ in menuItemsLIST:
		if l11lll_l1_ (u"ࠨืไัฮ࠭堩") in name or l11lll_l1_ (u"ุࠩๅาํࠧ堪") in name or l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ堫") in name.lower(): continue
		l11l11l111ll_l1_.append([type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_])
	return l11l11l111ll_l1_
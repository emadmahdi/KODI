# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ毧")
#headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭毨"):l11lll_l1_ (u"ࠪࠫ毩")}
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪ毪")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๋ࠬีศำ฼อࠬ毫"),l11lll_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ毬")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l1111l_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llllll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ毭"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ毮"),l11lll_l1_ (u"ࠩࠪ毯"),l11lll_l1_ (u"ࠪࠫ毰"),l11lll_l1_ (u"ࠫࠬ毱"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ毲"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ毳"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩ毴"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ毵"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毶"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ毷"),l1ll1l1_l1_,489,l11lll_l1_ (u"ࠫࠬ毸"),l11lll_l1_ (u"ࠬ࠭毹"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ毺"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ毻"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ毼"),l11lll_l1_ (u"ࠩࠪ毽"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ毾"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭毿")+l111ll_l1_+l11lll_l1_ (u"ࠬษอะอࠣห้๋่ศุํ฽ࠬ氀"),l1ll1l1_l1_,481)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫࠥࡱࡾࡇࡣࡤࡱࡸࡲࡹࠨࠧ氁"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ氂"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠨࠥࠪ氃"): continue
		if title in l1l1l1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ氄"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ氅")+l111ll_l1_+title,link,481)
	return html
def l1111l_l1_(url,l1ll1l1ll1l11_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ氆"),url,l11lll_l1_ (u"ࠬ࠭氇"),l11lll_l1_ (u"࠭ࠧ氈"),l11lll_l1_ (u"ࠧࠨ氉"),l11lll_l1_ (u"ࠨࠩ氊"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ氋"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡵࡳࡵࠪ࠱࠮ࡄ࠯ࠢࡧࡱࡲࡸࡪࡸࠢࠨ氌"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ氍"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ氎"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ氏"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭氐"),l11lll_l1_ (u"ࠨล฽๊๏ฯࠧ民"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧ氒"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩ氓"),l11lll_l1_ (u"ࠫ์ีวโࠩ气"),l11lll_l1_ (u"๋ࠬศศำสอࠬ氕"),l11lll_l1_ (u"ู࠭าุࠪ氖"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ気"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ氘"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ氙")]
	l1ll1l1ll1l1l_l1_ = l11lll_l1_ (u"ࠪ࠳ࠬ氚").join(l1ll1l1ll1l11_l1_.strip(l11lll_l1_ (u"ࠫ࠴࠭氛")).split(l11lll_l1_ (u"ࠬ࠵ࠧ氜"))[4:]).split(l11lll_l1_ (u"࠭࠭ࠨ氝"))
	for link,title,l1llll_l1_ in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ氞"),title,re.DOTALL)
		if l1ll1l1ll1l11_l1_:
			l1lllll1ll_l1_ = l11lll_l1_ (u"ࠨ࠱ࠪ氟").join(link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ氠")).split(l11lll_l1_ (u"ࠪ࠳ࠬ氡"))[4:]).split(l11lll_l1_ (u"ࠫ࠲࠭氢"))
			l1ll1l1ll1ll1_l1_ = len([x for x in l1ll1l1ll1l1l_l1_ if x in l1lllll1ll_l1_])
			if l1ll1l1ll1ll1_l1_>2 and l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ氣") in link:
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ氤"),l111ll_l1_+title,link,482,l1llll_l1_)
		else:
			if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ氥"),title,re.DOTALL)
			#if any(value in title for value in l1lll1_l1_):
			if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ氦") not in title:
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ氧"),l111ll_l1_+title,link,482,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠪั้่ษࠨ氨") in title:
				title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ氩") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ氪"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ氫"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氬"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ氭"),url)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ氮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ氯"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ氰"),l11lll_l1_ (u"ࠬ࠭氱"))
			if title!=l11lll_l1_ (u"࠭ࠧ氲"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ氳"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ水")+title,link,481,l11lll_l1_ (u"ࠩࠪ氵"),l11lll_l1_ (u"ࠪࠫ氶"),l1ll1l1ll1l11_l1_)
	return
def l1llllll_l1_(url,l11l11l_l1_):
	headers = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ氷"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭永")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ氹"),url,l11lll_l1_ (u"ࠧࠨ氺"),headers,l11lll_l1_ (u"ࠨࠩ氻"),l11lll_l1_ (u"ࠩࠪ氼"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ氽"))
	html = response.content
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ氾"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭氿"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ汀"))
	l1ll1l1ll11ll_l1_ = True
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࡙ࡥࡢࡵࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ汁"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ求") not in url:
		block = l1l1l11_l1_[0]
		count = block.count(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂ࠭汃"))
		if count==0: count = block.count(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠩ汄"))
		if count>1:
			l1ll1l1ll11ll_l1_ = False
			if l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠩ汅") in block:
				items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭汆"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠳࠰ࡳ࡬ࡵࡅࡳ࡭ࡷࡪࡁࠬ汇")+id
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ汈"),l111ll_l1_+title,link,483,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ汉"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠲ࡵ࡮ࡰࡀࡵࡨࡶ࡮࡫ࡳࡊࡆࡀࠫ汊")+id
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ汋"),l111ll_l1_+title,link,483,l1llll_l1_)
	# l1l1l_l1_
	if l1ll1l1ll11ll_l1_:
		block = l11lll_l1_ (u"ࠫࠬ汌")
		if l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ汍") in url: block = html
		else:
			l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡦࡲ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ汎"),html,re.DOTALL)
			if l1l11ll_l1_: block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭汏"),block,re.DOTALL)
		if items:
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ汐"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ汑"),l111ll_l1_+title,link,482,l1llll_l1_)
	if not menuItemsLIST: l1111l_l1_(l11l11l_l1_,url)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ汒"))+l11lll_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡺࡥࡹࡩࡨࠨ汓")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ汔"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ汕"),l11lll_l1_ (u"ࠧࠨ汖"),l11lll_l1_ (u"ࠨࠩ汗"),l11lll_l1_ (u"ࠩࠪ汘"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ汙"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ汚"))
	l1lll11111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡼ࡯ࡠࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ汛"),html,re.DOTALL)
	if not l1lll11111_l1_: l1lll11111_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ汜"),html,re.DOTALL)
	l1lll11111_l1_ = l1lll11111_l1_[0]
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ汝"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭汞"),block,re.DOTALL)
		for l1lll11l11_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ江"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳࡮࡬ࡲࡢ࡯ࡨ࠶࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭池")+l1lll11111_l1_+l11lll_l1_ (u"ࠫࠫࡼࡩࡥࡧࡲࡁࠬ污")+l1lll11l11_l1_[2:]+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭汢")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ汣")
			l1111_l1_.append(link)
	# l1l111lll_l1_ l11l1ll1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡩࡨࡸࡊࡳࡢࡦࡦࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ汤"),html,re.DOTALL)
	if link:
		title = SERVER(link[0],l11lll_l1_ (u"ࠨࡷࡵࡰࠬ汥"))
		link = link[0]+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ汦")+title+l11lll_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ汧")
		l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠫ࠴࠭汨"))+l11lll_l1_ (u"ࠬ࠵࠿ࡥࡱࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ汩")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ汪"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ汫"),l11lll_l1_ (u"ࠨࠩ汬"),l11lll_l1_ (u"ࠩࠪ汭"),l11lll_l1_ (u"ࠪࠫ汮"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ汯"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡢࡤ࡯ࡩ࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ汰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ汱"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ汲"))
			if l11lll_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ汳") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠩࡢࡣำอีࠨ汴")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠪࠫ汵")
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ汶")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ汷")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ汸"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭汹"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠨࠩ決")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ汻"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ汼"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭汽"),l11lll_l1_ (u"ࠬ࠱ࠧ汾"))
	if l1ll1l1_l1_==l11lll_l1_ (u"࠭ࠧ汿"): l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ沀")+search+l11lll_l1_ (u"ࠨ࠱ࠪ沁")
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࠪ沂"))
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧề")
def MAIN(mode,url):
	if   mode==330: results = l11ll11l1l_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l1l1111_l1_()
	elif mode==333: results = l111llllll_l1_()
	elif mode==334: results = l1ll111l11_l1_(url)
	else: results = False
	return results
def l1ll111l11_l1_(l11l1l1l1l_l1_):
	try: os.remove(l11l1l1l1l_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫỂ")))
	except: os.remove(l11l1l1l1l_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ể"))
	return
def l111llllll_l1_():
	message = l11lll_l1_ (u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧỄ")
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪễ"),l11lll_l1_ (u"ࠪࠫỆ"),l11lll_l1_ (u"ࠫ฼ื๊ใหࠣฮา๋๊ๅࠢส่๊๊แศฬࠪệ"),message)
	return
def l11ll11l1l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪỈ"),l11lll_l1_ (u"࠭ืา์ๅอࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫỉ"),l11lll_l1_ (u"ࠧࠨỊ"),333)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ị"),l11lll_l1_ (u"ࠩอ฾๏๐ัࠡ็ๆห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩỌ"),l11lll_l1_ (u"ࠪࠫọ"),332)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩỎ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬỏ"),l11lll_l1_ (u"࠭ࠧỐ"),9999)
	l11l1ll1ll_l1_ = l11l11lll1_l1_()
	mtime = os.stat(l11l1ll1ll_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1ll1l1_l1_ = os.listdir(l11l1ll1ll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬố")))
	else: l11l1ll1l1_l1_ = os.listdir(l11l1ll1ll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ồ")))
	for filename in l11l1ll1l1_l1_:
		if kodi_version>18.99: filename = filename.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧồ"))
		if not filename.startswith(l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩỔ")): continue
		filepath = os.path.join(l11l1ll1ll_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11ll1111l_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩổ"))
			except: pass
			filename = filename.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪỖ"))
		filepath = os.path.join(l11l1ll1ll_l1_,filename)
		addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬỗ"),filename,filepath,331)
	return
def l11l11lll1_l1_():
	l11l1ll1ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪỘ"))
	if l11l1ll1ll_l1_: return l11l1ll1ll_l1_
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫộ"),addoncachefolder)
	return addoncachefolder
def l11l1l1111_l1_():
	l11l1ll1ll_l1_ = l11l11lll1_l1_()
	l11l111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩỚ"),l11lll_l1_ (u"ࠪࠫớ"),l11lll_l1_ (u"ࠫࠬỜ"),l11l1ll1ll_l1_,l11lll_l1_ (u"ࠬํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩờ"))
	if l11l111ll1_l1_==1:
		newpath = l11l1l11l1_l1_(3,l11lll_l1_ (u"࠭ๅไษ้ࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪỞ"),l11lll_l1_ (u"ࠧ࡭ࡱࡦࡥࡱ࠭ở"),l11lll_l1_ (u"ࠨࠩỠ"),False,True,l11l1ll1ll_l1_)
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩỡ"),l11lll_l1_ (u"ࠪࠫỢ"),l11lll_l1_ (u"ࠫࠬợ"),newpath,l11lll_l1_ (u"ࠬํะศ๊ࠢ์ࠥอไๆๅส๊ࠥอไอัํำ๊ࠥสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฬูสฯัส้์ࠦศะๆสࠤ๊์ࠠศๆ่็ฬ์ࠠศๆๅำ๏๋ࠠภࠩỤ"))
		if l1ll11l111_l1_==1:
			settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩụ"),newpath)
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨỦ"),l11lll_l1_ (u"ࠨࠩủ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬỨ"),l11lll_l1_ (u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫứ"))
	#if not l11l111ll1_l1_ or not l1ll11l111_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬỪ"),l11lll_l1_ (u"ࠬ࠭ừ"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩỬ"),l11lll_l1_ (u"ࠧห็ࠣห้เวยࠢส่฾๋ไ๋หࠪử"))
	return
def l11l1l111l_l1_(filename):
	l11ll11l11_l1_ = l11lll_l1_ (u"ࠨࠩỮ").join(l11ll111l1_l1_ for l11ll111l1_l1_ in filename if l11ll111l1_l1_ not in l11lll_l1_ (u"ࠩ࡟࠳ࠧࡀࠪࡀ࠾ࡁࢀࠬữ")+half_triangular_colon)
	return l11ll11l11_l1_
def l11l11ll1l_l1_(url,l111llll11_l1_=l11lll_l1_ (u"ࠪࠫỰ"),l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬự")):
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬỲ"),l11lll_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭ỳ"))
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧỴ"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨỵ")+url+l11lll_l1_ (u"ࠩࠣࡡࠬỶ"))
	if not l111llll11_l1_: l111llll11_l1_ = l11l1llll1_l1_(url,l1l1ll11_l1_)
	#if not l111llll11_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫỷ"),l11lll_l1_ (u"ࠫࠬỸ"),l11lll_l1_ (u"ࠬะๆำ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩỹ"),l11lll_l1_ (u"࠭วๅ็็ๅ๋ࠥๆ่๋ࠡ฽ࠥ࠭Ỻ")+l111llll11_l1_+l11lll_l1_ (u"๊ࠧࠡส่อืๆศ็ฯࠤาอไ๋ษࠣ฾๏ืࠠอษ๊ึ๊ࠥสฮ็ํ่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊ๅๅใสฮࠬỻ"))
	#	LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ỽ"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡹࡿࡰࡦ࠱ࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫỽ")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭Ỿ"))
	#	return False
	l11l1ll1ll_l1_ = l11l11lll1_l1_()
	l11l1lllll_l1_ = l11l1ll111_l1_()
	filename = l11l1lllll_l1_.replace(l11lll_l1_ (u"ࠫࠥ࠭ỿ"),l11lll_l1_ (u"ࠬࡥࠧἀ"))
	filename = l11l1l111l_l1_(filename)
	#l111llll11_l1_ = l111llll11_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫἁ"))
	filename = l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡤ࠭ἂ")+str(int(now))[-4:]+l11lll_l1_ (u"ࠨࡡࠪἃ")+filename+l111llll11_l1_
	l11l111111_l1_ = os.path.join(l11l1ll1ll_l1_,filename)
	headers = {}
	headers[l11lll_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫἄ")] = l11lll_l1_ (u"ࠪࠫἅ")
	headers[l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷࠫἆ")] = l11lll_l1_ (u"ࠬ࠰࠯ࠫࠩἇ")
	url = url.replace(l11lll_l1_ (u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩἈ"),l11lll_l1_ (u"ࠧࠨἉ"))
	if l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭Ἂ") in url:
		l11l11l_l1_,l111llll1l_l1_ = url.rsplit(l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧἋ"),1)
		l111llll1l_l1_ = l111llll1l_l1_.replace(l11lll_l1_ (u"ࠪࢀࠬἌ"),l11lll_l1_ (u"ࠫࠬἍ")).replace(l11lll_l1_ (u"ࠬࠬࠧἎ"),l11lll_l1_ (u"࠭ࠧἏ"))
	else: l11l11l_l1_,l111llll1l_l1_ = url,None
	if not l111llll1l_l1_: l111llll1l_l1_ = l1l11111l_l1_()
	if l111llll1l_l1_: headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫἐ")] = l111llll1l_l1_
	if l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪἑ") in l11l11l_l1_: l11l11l_l1_,l11l11l11l_l1_ = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫἒ"),1)
	else: l11l11l_l1_,l11l11l11l_l1_ = l11l11l_l1_,l11lll_l1_ (u"ࠪࠫἓ")
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠫࢁ࠭ἔ")).strip(l11lll_l1_ (u"ࠬࠬࠧἕ")).strip(l11lll_l1_ (u"࠭ࡼࠨ἖")).strip(l11lll_l1_ (u"ࠧࠧࠩ἗"))
	l11l11l11l_l1_ = l11l11l11l_l1_.replace(l11lll_l1_ (u"ࠨࡾࠪἘ"),l11lll_l1_ (u"ࠩࠪἙ")).replace(l11lll_l1_ (u"ࠪࠪࠬἚ"),l11lll_l1_ (u"ࠫࠬἛ"))
	if l11l11l11l_l1_:	headers[l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭Ἔ")] = l11l11l11l_l1_
	LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭Ἕ"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ἞")+l11l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫ἟")+str(headers)+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩἠ")+l11l111111_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭ἡ"))
	l11ll11ll1_l1_ = 1024*1024
	l11l1lll1l_l1_ = 0
	try:
		l11l1lll11_l1_ =	xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡥࡦࡕࡳࡥࡨ࡫ࠧἢ"))
		l11l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡢࡤࠬࠩἣ"),l11l1lll11_l1_)
		l11l1lll1l_l1_ = int(l11l1lll11_l1_[0])
	except: pass
	if not l11l1lll1l_l1_:
		try:
			l11l1l1ll1_l1_ = os.l111lll1ll_l1_(l11l1ll1ll_l1_)
			l11l1lll1l_l1_ = l11l1l1ll1_l1_.f_frsize*l11l1l1ll1_l1_.f_bavail//l11ll11ll1_l1_
		except: pass
	if not l11l1lll1l_l1_:
		try:
			l11l1l1ll1_l1_ = os.l11ll111ll_l1_(l11l1ll1ll_l1_)
			l11l1lll1l_l1_ = l11l1l1ll1_l1_.f_frsize*l11l1l1ll1_l1_.f_bavail//l11ll11ll1_l1_
		except: pass
	if not l11l1lll1l_l1_:
		try:
			import shutil
			total,l11l11llll_l1_,l11l11ll11_l1_ = shutil.l11ll1l11l_l1_(l11l1ll1ll_l1_)
			l11l1lll1l_l1_ = l11l11ll11_l1_//l11ll11ll1_l1_
		except: pass
	if not l11l1lll1l_l1_:
		l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬἤ"),l11lll_l1_ (u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠๆฮ๊์้ฯࠧἥ"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ฽๎ึࠦโศัิࠤศ์๋ࠠฯาำ๋ࠥโะษิࠤู๊วฮหࠣห้ะฮำ์้ࠤฬ๊แศำ฽อࠥ็๊ࠡฮ๊หื้้ࠠ฻็๎์ࠦแศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦไ็ࠢํ฽ฺ๊๊่ࠠา็ࠥหไ๊ࠢฦ๊ࠥ๐โ้็้ࠣอืๅอ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡสะ่ࠥํะ่ࠢสฺ่๊ใๅห่ࠣฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠣๆิ๊ࠦิสหࠤฬ๋สๅษฤࠤัํวำๅࠣฬฬ๊ๅๅใสฮࠥ๎็ัษࠣๅ๏ํࠠฯู๋ีฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๊็ัษࠣหู้ศษࠢๅห๊ࠦวๅ็หี๊าࠠๆฦๅฮฬࠦศๆ่฼ࠤฬ๊ศา่ส้ัࠦๅ็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬἦ"),l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬἧ"))
		LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨἨ"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬἩ"))
		return False
	import requests
	if l111llll11_l1_==l11lll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫἪ"):
		l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(l11l11l_l1_,headers)
		#DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫἫ"), l1lll1ll_l1_)
		#DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬἬ"), l1111_l1_)
		if len(l1lll1ll_l1_)==0:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬἭ"),l11lll_l1_ (u"ࠩࠪἮ"))
			return False
		elif len(l1lll1ll_l1_)==1: l1l_l1_ = 0
		elif len(l1lll1ll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨἯ"), l1lll1ll_l1_)
			if l1l_l1_ == -1 :
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬะ้๏๊ࠧἰ"),l11lll_l1_ (u"ࠬ࠭ἱ"))
				return False
		l11l11l_l1_ = l1111_l1_[l1l_l1_]
	filesize = 0
	if l111llll11_l1_==l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬἲ"):
		l11l111111_l1_ = l11l111111_l1_.rsplit(l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ἳ"))[0]+l11lll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭ἴ")
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ἵ"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫἶ"),headers,l11lll_l1_ (u"ࠫࠬἷ"),l11lll_l1_ (u"ࠬ࠭Ἰ"),l11lll_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭Ἱ"))
		l1llll1l1_l1_ = response.content
		links = re.findall(l11lll_l1_ (u"ࠧ࡝ࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩἺ"),l1llll1l1_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡷ࠭Ἳ"),re.DOTALL)
		if not links:
			LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧἼ"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ἵ")+l11l11l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧἾ"))
			return False
		link = links[0]
		if not link.startswith(l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪἿ")):
			if link.startswith(l11lll_l1_ (u"࠭࠯࠰ࠩὀ")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠧ࠻ࠩὁ"),1)[0]+l11lll_l1_ (u"ࠨ࠼ࠪὂ")+link
			elif link.startswith(l11lll_l1_ (u"ࠩ࠲ࠫὃ")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧὄ"))+link
			else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠫ࠴࠭ὅ"),1)[0]+l11lll_l1_ (u"ࠬ࠵ࠧ὆")+link
		response = requests.request(l11lll_l1_ (u"࠭ࡇࡆࡖࠪ὇"),link,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l11l1ll_l1_ = len(links)
		filesize = chunksize*l11l11l1ll_l1_
	else:
		chunksize = 1*l11ll11ll1_l1_
		response = requests.request(l11lll_l1_ (u"ࠧࡈࡇࡗࠫὈ"),l11l11l_l1_,headers=headers,verify=False,stream=True)
		if l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩὉ") in response.headers: filesize = int(response.headers[l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪὊ")])
		l11l11l1ll_l1_ = int(filesize//chunksize)
	#l11ll11111_l1_ = l11l11l1ll_l1_+1
	l11ll11111_l1_ = int(filesize//l11ll11ll1_l1_)+1
	if filesize<21000:
		LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨὋ"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭Ὄ")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩὍ")+str(l11ll11111_l1_)+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ὎")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ὏")+l11l111111_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫὐ"))
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪὑ"),l11lll_l1_ (u"ࠪࠫὒ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧὓ"),l11lll_l1_ (u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧὔ"))
		return False
	l11l11l111_l1_ = 400
	l11l1111ll_l1_ = l11l1lll1l_l1_-l11ll11111_l1_
	if l11l1111ll_l1_<l11l11l111_l1_:
		LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫὕ"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡒࡴࡺࠠࡦࡰࡲࡹ࡬࡮ࠠࡥ࡫ࡶ࡯ࠥࡹࡰࡢࡥࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ὖ")+l11l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬὗ")+str(l11ll11111_l1_)+l11lll_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ὘")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠪࠤࡒࡈࠠ࠮ࠢࠪὙ")+str(l11l11l111_l1_)+l11lll_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ὚")+l11l111111_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨὛ"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ὜"),l11lll_l1_ (u"ࠧࠨὝ"),l11lll_l1_ (u"ࠨๆสࠤ๏๎ฬะ่ࠢืฬำษࠡๅสๅ๏ฯࠠๅๆอั๊๐ไࠨ὞"),l11lll_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่ࠢะะ๊ํࠠࠨὟ")+str(l11ll11111_l1_)+l11lll_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡࠩὠ")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠๆ็้าอแูหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬิ๎ๆࠡ็ืห่๊๋ࠠฮหࠤสฮโศรࠣࠫὡ")+str(l11l11l111_l1_)+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡใสี฿ฯࠠะษษ้ฬ่่ࠦาสࠤ๊฿ๆศ้ࠣว๋ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧὢ"))
		return False
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭ὣ"),l11lll_l1_ (u"ࠧࠨὤ"),l11lll_l1_ (u"ࠨࠩὥ"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪὦ"),l11lll_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩὧ")+str(l11ll11111_l1_)+l11lll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪὨ")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨὩ"))
	if l1ll11l111_l1_!=1:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧὪ"),l11lll_l1_ (u"ࠧࠨὫ"),l11lll_l1_ (u"ࠨࠩὬ"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧὭ"))
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪὮ"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡸࡥࡧࡷࡶࡩࡩࠦࡴࡰࠢࡶࡸࡦࡸࡴࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧὯ")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬὰ")+l11l111111_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩά"))
		return False
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧὲ"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭έ"))
	l11l1ll11l_l1_ = DIALOG_PROGRESS()
	l11l1ll11l_l1_.create(l11l111111_l1_,l11lll_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪὴ"))
	l11l11l1l1_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l11l111111_l1_,l11lll_l1_ (u"ࠪࡻࡧ࠭ή"))
	else: file = open(l11l111111_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩὶ")),l11lll_l1_ (u"ࠬࡽࡢࠨί"))
	if l111llll11_l1_==l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬὸ"): # l11l11llll_l1_ for l1llll1l1_l1_ and l11l111l11_l1_ chunks video files such as .l11l1l1lll_l1_
		for l11ll111l1_l1_ in range(1,l11l11l1ll_l1_+1):
			link = links[l11ll111l1_l1_-1]
			if not link.startswith(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬό")):
				if link.startswith(l11lll_l1_ (u"ࠨ࠱࠲ࠫὺ")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠩ࠽ࠫύ"),1)[0]+l11lll_l1_ (u"ࠪ࠾ࠬὼ")+link
				elif link.startswith(l11lll_l1_ (u"ࠫ࠴࠭ώ")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ὾"))+link
				else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"࠭࠯ࠨ὿"),1)[0]+l11lll_l1_ (u"ࠧ࠰ࠩᾀ")+link
			response = requests.request(l11lll_l1_ (u"ࠨࡉࡈࡘࠬᾁ"),link,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11l1111l1_l1_ = time.time()
			l111lllll1_l1_ = l11l1111l1_l1_-t1
			l11l11111l_l1_ = l111lllll1_l1_//l11ll111l1_l1_
			l11l1l11ll_l1_ = l11l11111l_l1_*(l11l11l1ll_l1_+1)
			l11l111l1l_l1_ = l11l1l11ll_l1_-l111lllll1_l1_
			PROGRESS_UPDATE(l11l1ll11l_l1_,int(100*l11ll111l1_l1_//(l11l11l1ll_l1_+1)),l11lll_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᾂ"),l11lll_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪᾃ"),str(l11ll111l1_l1_*chunksize//l11ll11ll1_l1_)+l11lll_l1_ (u"ࠫ࠴࠭ᾄ")+str(l11ll11111_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪᾅ")+time.strftime(l11lll_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᾆ"),time.gmtime(l11l111l1l_l1_))+l11lll_l1_ (u"ࠧࠡโࠪᾇ"))
			if l11l1ll11l_l1_.iscanceled():
				l11l11l1l1_l1_ = False
				break
	else: # l1111lll_l1_ and other l11l1l1l11_l1_ file l11ll1l111_l1_
		l11ll111l1_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11ll111l1_l1_ = l11ll111l1_l1_+1
			l11l1111l1_l1_ = time.time()
			l111lllll1_l1_ = l11l1111l1_l1_-t1
			l11l11111l_l1_ = l111lllll1_l1_/l11ll111l1_l1_
			l11l1l11ll_l1_ = l11l11111l_l1_*(l11l11l1ll_l1_+1)
			l11l111l1l_l1_ = l11l1l11ll_l1_-l111lllll1_l1_
			PROGRESS_UPDATE(l11l1ll11l_l1_,int(100*l11ll111l1_l1_/(l11l11l1ll_l1_+1)),l11lll_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᾈ"),l11lll_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩᾉ"),str(l11ll111l1_l1_*chunksize//l11ll11ll1_l1_)+l11lll_l1_ (u"ࠪ࠳ࠬᾊ")+str(l11ll11111_l1_)+l11lll_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩᾋ")+time.strftime(l11lll_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᾌ"),time.gmtime(l11l111l1l_l1_))+l11lll_l1_ (u"࠭ࠠแࠩᾍ"))
			if l11l1ll11l_l1_.iscanceled():
				l11l11l1l1_l1_ = False
				break
		response.close()
	file.close()
	l11l1ll11l_l1_.close()
	if not l11l11l1l1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᾎ"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᾏ")+l11l11l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᾐ")+l11l111111_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭ᾑ"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬᾒ"),l11lll_l1_ (u"ࠬ࠭ᾓ"),l11lll_l1_ (u"࠭ࠧᾔ"),l11lll_l1_ (u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᾕ"))
		return True
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᾖ"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᾗ")+l11l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᾘ")+l11l111111_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧᾙ"))
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᾚ"),l11lll_l1_ (u"࠭ࠧᾛ"),l11lll_l1_ (u"ࠧࠨᾜ"),l11lll_l1_ (u"ࠨฬ่ࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡส้ะฬำࠧᾝ"))
	return True
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll111_l1_ import *
import traceback,bidi.algorithm
#import l1l1l1l1ll1l_l1_
script_name = l11lll_l1_ (u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫ㟙")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1lll11l1lll_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬ㟚"))
	l1l1l111l1_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭㟛"))
	l11l11111ll_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ㟜"))
	l1l1l11ll111_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㟝"),l11lll_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㟞"),l11lll_l1_ (u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧ㟟"))
	l111l11lll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㟠"),l11lll_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㟡"),l11lll_l1_ (u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬ㟢"))
	l1ll11l11l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㟣"),l11lll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㟤"),l11lll_l1_ (u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ㟥"))
	half_triangular_colon = l11lll_l1_ (u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪ㟦")
	from urllib.parse import quote as _1ll1l11l11l_l1_
	#from io import BytesIO as _1ll111l11l1_l1_
else:
	l1lll11l1lll_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ㟧"))
	l1l1l111l1_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ㟨"))
	l11l11111ll_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ㟩"))
	l1l1l11ll111_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㟪"),l11lll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ㟫"),l11lll_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭㟬"))
	l111l11lll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ㟭"),l11lll_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ㟮"),l11lll_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ㟯"))
	l1ll11l11l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㟰"),l11lll_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㟱"),l11lll_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ㟲"))
	half_triangular_colon = l11lll_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ㟳").encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㟴"))
	from urllib import quote as _1ll1l11l11l_l1_
	#from StringIO import StringIO as _1ll111l11l1_l1_
#l1lll1ll11ll_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11l1ll1l1l_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡌ࡯࡭ࡦࡨࡶࡕࡧࡴࡩࠩ㟵"))
l1ll1l11ll11_l1_ = os.path.join(l11l11111ll_l1_,l11lll_l1_ (u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭㟶"))
l1ll1llll111_l1_ = os.path.join(l11l11111ll_l1_,l11lll_l1_ (u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫ㟷"))
iptv1_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㟸"))
iptv2_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ㟹"))
l1l1l1lll1l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ㟺"))
#l1ll1llll1ll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩࡻࡸࡷ࡫ࡡ࡮ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㟻"))
#l1ll1lll1111_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪࡰࡦࡹࡴ࡮ࡧࡱࡹ࠳ࡪࡡࡵࠩ㟼"))
favoritesfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫ࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳ࠯ࡦࡤࡸࠬ㟽"))
#dummyiptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬࡪࡵ࡮࡯ࡼ࡭ࡵࡺࡶ࠯ࡦࡤࡸࠬ㟾"))
fulliptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ㟿"))
l1l11llll1l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ㠀"))
l1l1111llll1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡨࡦࡺࠧ㠁"))
l1l111ll1ll1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬ㠂"))
l11lll1l1l1_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠪࡴࡦࡺࡨࠨ㠃"))
defaulticon = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭㠄"))
defaultthumb = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ㠅"))
defaultfanart = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㠆"))
defaultbanner = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ㠇"))
defaultlandscape = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨ㠈"))
defaultposter = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭㠉"))
defaultclearlogo = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪ㠊"))
defaultclearart = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪ㠋"))
l1l1ll1lllll_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬ㠌"))
l1ll1l111l_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㠍"))
l1l1ll1l11l1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㠎"),l11lll_l1_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ㠏"),addon_id,l11lll_l1_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ㠐"))
l1lll1l11lll_l1_ = os.path.join(l1lll11l1lll_l1_,l11lll_l1_ (u"ࠪࡱࡪࡪࡩࡢࠩ㠑"),l11lll_l1_ (u"ࠫࡋࡵ࡮ࡵࡵࠪ㠒"),l11lll_l1_ (u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨ㠓"))
FOLDERS_COUNT = 5
text_numbers = [l11lll_l1_ (u"࠭ีโำࠪ㠔"),l11lll_l1_ (u"ࠧฤ๊็ࠫ㠕"),l11lll_l1_ (u"ࠨอส๊๏࠭㠖"),l11lll_l1_ (u"ࠩฮห้ัࠧ㠗"),l11lll_l1_ (u"ࠪีฬฮูࠨ㠘"),l11lll_l1_ (u"ࠫำอๅิࠩ㠙"),l11lll_l1_ (u"ูࠬวะีࠪ㠚"),l11lll_l1_ (u"࠭ำศส฼ࠫ㠛"),l11lll_l1_ (u"ࠧฬษ่๊ࠬ㠜"),l11lll_l1_ (u"ࠨฬสื฾࠭㠝"),l11lll_l1_ (u"ࠩ฼หูืࠧ㠞")]
l1ll1lll1ll1_l1_ = l11lll_l1_ (u"ࠪ⸿ࠥ⼣ࠠ⸫ࠢ⸾ࠫ㠟")
NO_CACHE = 0
l1ll111111ll_l1_ = 30*l11lllllll1_l1_
l1lll1111_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
VERYLONG_CACHE = 30*l11l1ll1lll_l1_
l11l1lllll1_l1_ = 1*HOUR
l1l1l111l11l_l1_ = [l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㠠"),l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ㠡")]
l1ll1lll11ll_l1_ = [l11lll_l1_ (u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ㠢")]
l1lll11l1ll1_l1_ = [l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩ㠣"),l11lll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㠤"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㠥"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㠦"),l11lll_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㠧"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㠨"),l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㠩"),l11lll_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ㠪")]
l1lll11l1ll1_l1_ += [l11lll_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ㠫"),l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈࠨ㠬"),l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㠭"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㠮"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ㠯"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭㠰"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㠱"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㠲")]
l1l111l1111l_l1_ = [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㠳"),l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㠴"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㠵"),l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㠶")]
l1l111l1111l_l1_ += [l11lll_l1_ (u"࠭ࡍ࠴ࡗࠪ㠷"),l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㠸"),l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㠹"),l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㠺")]
l1l111l1111l_l1_ += [l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㠻"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㠼"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㠽")]
l1l111l1111l_l1_ += [l11lll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㠾"),l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㠿"),l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㡀"),l11lll_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㡁"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㡂"),l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㡃")]
l1l111l1111l_l1_ += [l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㡄"),l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㡅"),l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㡆"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㡇"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ㡈"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ㡉")]
#l1l111l1111l_l1_ += [l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㡊"),l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ㡋"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ㡌"),l11lll_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㡍")]
#l1l111l1111l_l1_ += [l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫ㡎"),l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࠬ㡏"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ㡐"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ㡑")]
l1l1l111l1l_l1_ = [l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㡒"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㡓"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㡔"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㡕")]
l1l1l111l1l_l1_ += [l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㡖"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㡗"),l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㡘"),l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㡙"),l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㡚")]
l1l1l11lll1_l1_ = [l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㡛"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㡜"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㡝"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㡞"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㡟"),l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ㡠")]
l1l1l11lll1_l1_ += [l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㡡"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㡢"),l11lll_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㡣"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㡤"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㡥")]
#l1l1l11lll1_l1_ += [l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ㡦"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㡧")]
l1l1ll11lll_l1_ = [l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㡨"),l11lll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ㡩"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㡪"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㡫"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㡬"),l11lll_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㡭"),l11lll_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㡮"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㡯")]
l1l1ll11lll_l1_ += [l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㡰"),l11lll_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㡱"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㡲"),l11lll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㡳"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ㡴"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ㡵")]
#l1l1ll11lll_l1_ += [l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㡶"),l11lll_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㡷"),l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㡸"),l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ㡹"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ㡺"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㡻"),l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧ㡼")]
l1l1lll11l1l_l1_  = [l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ㡽"),l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㡾"),l11lll_l1_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪ㡿"),l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ㢀"),l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㢁"),l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㢂"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㢃"),l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ㢄")]
l1l1lll11l1l_l1_ += [l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㢅"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㢆"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㢇"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㢈"),l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㢉"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ㢊"),l11lll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ㢋"),l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭㢌"),l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㢍")]
l1l1lll11l1l_l1_ += [l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㢎"),l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ㢏"),l11lll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㢐"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㢑"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ㢒"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㢓"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ㢔")]
l1l1lll11l1l_l1_ += [l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㢕"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ㢖"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭㢗"),l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㢘"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ㢙"),l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ㢚")]
l1l1lll11l1l_l1_ += [l11lll_l1_ (u"ࠨࡄࡕࡗ࡙ࡋࡊࠨ㢛"),l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㢜"),l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㢝"),l11lll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬ㢞"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㢟"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㢠")]
l1l11lll11l1_l1_  = [l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㢡"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㢢"),l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㢣"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㢤")]
l1l11lll11l1_l1_ += [l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㢥"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㢦")]
l1l11lll11l1_l1_ += [l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㢧"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㢨"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㢩")]
l1l11lll11l1_l1_ += [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㢪"),l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㢫"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㢬")]
l1l11lll11l1_l1_ += [l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ㢭"),l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㢮"),l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㢯")]
#l1l11lll11l1_l1_ += [l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㢰"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ㢱")]
#l1l11lll11l1_l1_ += [l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ㢲"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ㢳"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࠨ㢴")]
l1l1l11l1ll1_l1_ = [l11lll_l1_ (u"࠭ࡍ࠴ࡗࠪ㢵"),l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㢶"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㢷"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㢸"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㢹")]		# l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㢺"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㢻")
l1l1l1ll11l_l1_ = l1l1lll11l1l_l1_+l1l11lll11l1_l1_
l1l1ll111lll_l1_ = l1l1lll11l1l_l1_+l1l1l11l1ll1_l1_
l11l1l11ll1_l1_ = l1l1lll11l1l_l1_+l1l1l11l1ll1_l1_+l1l1l111l11l_l1_
l1l1l1ll111_l1_ = l1l111l1111l_l1_+l1l1l11lll1_l1_+l1l1ll11lll_l1_+l1l1l111l1l_l1_
# l1ll1llll11l_l1_ will not show l1llll1ll111_l1_ errors and will not exit from the l11l11ll111_l1_
l1lllllll111_l1_ = [
						l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㢼")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ㢽")
						,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ㢾")
						,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㢿")
						,l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ㣀")
						,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㣁")
						,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㣂")
						,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ㣃")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㣄")
						,l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ㣅")
						,l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ㣆")
						,l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ㣇")
						]
l1111lll111_l1_ = l1lllllll111_l1_+[
				 l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㣈")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㣉")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㣊")
				,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ㣋")
				,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ㣌")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ㣍")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ㣎")
				,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭㣏")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ㣐")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㣑")
				,l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㣒")
				,l11lll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫ㣓")
				,l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬ㣔")
				,l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ㣕")
				,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㣖")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㣗")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㣘")
				#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㣙")
				#,l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㣚")
				#,l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ㣛")
				#,l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㣜")
				#,l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭㣝")
				#,l11lll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡈࡇࡗࡣࡑࡇࡔࡆࡕࡗࡣ࡛ࡋࡒࡔࡋࡒࡒࡤࡔࡕࡎࡄࡈࡖࡘ࠳࠱ࡴࡶࠪ㣞")
				#,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㣟")
				#,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭㣠")
				#,l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㣡")
				]
l1lll1l11ll1_l1_ = [l11lll_l1_ (u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ㣢"),l11lll_l1_ (u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫ㣣"),l11lll_l1_ (u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ㣤"),l11lll_l1_ (u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭㣥"),l11lll_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ㣦"),l11lll_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ㣧")]
l1ll11l_l1_ = {
			#,l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ㣨")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭㣩")]
			#,l11lll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㣪")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡰࡰࡧࡷࡵࡪࡤࡶࡹࡼ࠮ࡪࡴࠪ㣫")]
			#,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧ㣬")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡱࡩࡹ࠭㣭")]
			#,l11lll_l1_ (u"ࠧࡆࡉ࡜࠸ࡇࡋࡓࡕࠩ㣮")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ㣯")]
			#,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㣰")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ㣱")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㣲")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡩ࡬ࡿ࡮ࡰࡹ࠱ࡰ࡮ࡼࡥࠨ㣳")]
			#,l11lll_l1_ (u"࠭ࡈࡆࡎࡄࡐࠬ㣴")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࠶࡫ࡩࡱࡧ࡬࠯࡯ࡨࠫ㣵")]
			#,l11lll_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㣶")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭㣷"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦࠩ㣸")]
			#,l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㣹")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡴࡼࡳ࠵ࡷ࠱ࡻࡸ࠭㣺")]
			#,l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㣻")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡲࠫ㣼")]
			#,l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㣽"):[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠭㣾")]
			#,l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭㣿")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠯ࡥࡲࡱࠬ㤀")]
			#,l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ㤁")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࠰ࡶ࡬ࡴࡵࡦࡱࡴࡲ࠲ࡴࡴ࡬ࡪࡰࡨࠫ㤂")]    #	 https://l1l1l111ll11_l1_.com
			#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㤃")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦ࠳࡯࡯ࠨ㤄")]
			#,l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㤅")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨ࠮ࡷ࡫ࡳࠫ㤆")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㤇")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㤈")]
			#,l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㤉")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡤࡶࡴࢀࡡ࠯ࡱࡱࡩࠬ㤊")]
			 l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㤋")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡱࡩࡹ࠭㤌")]
			,l11lll_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㤍")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭㤎")]
			,l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㤏")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶࠪ㤐")]
			,l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㤑")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪ㤒")]
			,l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㤓")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶࠨ㤔")]
			,l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㤕")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ㤖")]
			,l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㤗")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ㤘")]
			,l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㤙")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ㤚")]
			,l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㤛")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ㤜")]
			,l11lll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㤝")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ㤞")]
			,l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㤟")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ㤠")]
			,l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㤡")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ㤢")]
			,l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㤣")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ㤤")]
			,l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㤥")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ㤦")]
			,l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㤧")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠼࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸࠬ㤨")]
			,l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㤩")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡲࡴࡽ࠮ࡤࡱࡰࠫ㤪")]
			,l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㤫")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㤬"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㤭")]
			,l11lll_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㤮")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫ㤯")]
			,l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㤰")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴ࠭ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ㤱")]
			,l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㤲")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡩࡻ࠭㤳")]
			,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㤴")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨ㤵")]
			,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㤶")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㤷")]
			,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㤸")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬ㤹")]
			,l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ㤺")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ㤻")]
			,l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㤼")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ㤽")]
			,l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㤾")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩ㤿")]
			,l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㥀")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡼࡩࡱࠩ㥁")]
			,l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ㥂")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧ㥃")]
			,l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㥄")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧ㥅")]
			,l11lll_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㥆")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯ࡷࡶࠫ㥇")]
			,l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㥈")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㥉"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㥊"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㥋"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㥌"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫ㥍")]
			,l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㥎")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧ㥏")]
			,l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ㥐")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ㥑")]
			,l11lll_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ㥒")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ㥓"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪ㥔")]
			,l11lll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㥕")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡥࡤࡱࠬ㥖")]
			,l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㥗")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ㥘")]
			,l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㥙")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠷࠮ࡷ࡫ࡳࠫ㥚")]
			,l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㥛")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ㥜")]
			,l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭㥝")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭㥞")]
			,l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ㥟")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ㥠"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ㥡"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ㥢")]
			,l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ㥣")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ㥤")]
			,l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㥥")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡨ࡯࡭ࡢ࠰ࡷࡹࡧ࡫ࠧ㥦")]
			,l11lll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ㥧")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ㥨")]
			,l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㥩")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ㥪")]
			#,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㥫")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㥬"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㥭"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㥮"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㥯"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㥰"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㥱"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㥲")]
			#,l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㥳")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㥴"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㥵"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㥶"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㥷"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㥸"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㥹"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㥺")]
			#,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㥻")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㥼"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㥽"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㥾"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㥿"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㦀"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㦁"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㦂")]
			#,l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㦃")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㦄"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㦅"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㦆"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㦇"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㦈"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㦉"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㦊"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㦋")]
			#,l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㦌")	:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㦍"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㦎"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㦏"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㦐"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㦑"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㦒"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㦓"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㦔")]
			,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㦕")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㦖"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㦗"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㦘"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㦙"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㦚"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㦛"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㦜"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ㦝")]
			,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㦞")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㦟"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㦠"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㦡"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㦢"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㦣"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㦤"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㦥"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㦦")]
			,l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㦧")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ㦨"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ㦩"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ㦪")]
			,l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ㦫")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭㦬"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫ㦭"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬ㦮")]
			,l11lll_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ㦯")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ㦰"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫ࠫ㦱"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ㦲")]
			}
class l1ll11l11111_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l11l1l1l_l1_ = -1
	def onClick(self,l1lll1l1l1l1_l1_):
		if l1lll1l1l1l1_l1_>=9010: self.l11l11l1l1l_l1_ = l1lll1l1l1l1_l1_-9010
		self.delete()
	def l1111111l1l_l1_(self,*args):
		#self.getControl(9001).l1l11l11111_l1_(header)
		#self.getControl(9009).l1ll1ll1lll1_l1_(text)
		#self.getControl(9010).l1l11l11111_l1_(l1llll1l11l1_l1_)
		#self.getControl(9011).l1l11l11111_l1_(l1l1l111l1l1_l1_)
		#self.getControl(9012).l1l11l11111_l1_(l1llll1l1lll_l1_)
		self.l1llll1l11l1_l1_,self.l1l1l111l1l1_l1_,self.l1llll1l1lll_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.l1llllll111_l1_,self.l1l1llll1ll1_l1_ = args[5],args[6]
		self.l1l1lllll1ll_l1_,self.l1l1111ll1l1_l1_,self.l1l11l1ll11l_l1_ = args[7],args[8],args[9]
		if self.l1l1111ll1l1_l1_>0 or self.l1l11l1ll11l_l1_>0: self.l1l1ll1ll111_l1_ = True
		else: self.l1l1ll1ll111_l1_ = False
		self.l1ll1lllll1l_l1_,self.l1111111ll1_l1_ = l1l11ll11111_l1_(self.l1llll1l11l1_l1_,self.l1l1l111l1l1_l1_,self.l1llll1l1lll_l1_,self.header,self.text,self.l1llllll111_l1_,self.l1l1llll1ll1_l1_,self.l1l1lllll1ll_l1_,self.l1l1ll1ll111_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1ll1lllll1l_l1_)
		self.getControl(9050).setHeight(self.l1111111ll1_l1_)
		if not self.l1l1l111l1l1_l1_ and self.l1llll1l11l1_l1_ and self.l1llll1l1lll_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1ll1lllll1l_l1_,self.l1111111ll1_l1_
	def l11l11l1111_l1_(self):
		if self.l1l1111ll1l1_l1_:
			import threading
			self.l11l1lll1l1_l1_ = threading.Thread(target=self.l1ll1111llll_l1_,args=())
			self.l11l1lll1l1_l1_.start()
			#self.l11l1lll1l1_l1_.join()
		else: self.enableButtons()
	def l1ll1111llll_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11ll111l1_l1_ in range(1,self.l1l1111ll1l1_l1_+1):
			time.sleep(1)
			l1l1111lllll_l1_ = int(100*l11ll111l1_l1_/self.l1l1111ll1l1_l1_)
			self.l1l111llll1l_l1_(l1l1111lllll_l1_)
			if self.l11l11l1l1l_l1_>0: break
		self.enableButtons()
	def l111llll111_l1_(self):
		if self.l1l11l1ll11l_l1_:
			import threading
			self.l1l1ll111ll1_l1_ = threading.Thread(target=self.l1lll11111ll_l1_,args=())
			self.l1l1ll111ll1_l1_.start()
			#self.l1l1ll111ll1_l1_.join()
		else: self.enableButtons()
	def l1lll11111ll_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1111ll1l1_l1_)
		for l11ll111l1_l1_ in range(self.l1l11l1ll11l_l1_-1,-1,-1):
			time.sleep(1)
			l1l1111lllll_l1_ = int(100*l11ll111l1_l1_/self.l1l11l1ll11l_l1_)
			self.l1l111llll1l_l1_(l1l1111lllll_l1_)
			if self.l11l11l1l1l_l1_>0: break
		if self.l1l11l1ll11l_l1_>0: self.l11l11l1l1l_l1_ = 10
		self.delete()
	def l1l111llll1l_l1_(self,l1l1111lllll_l1_):
		self.l1ll1lll1lll_l1_ = l1l1111lllll_l1_
		self.getControl(9020).setPercent(self.l1ll1lll1lll_l1_)
	def enableButtons(self):
		if self.l1llll1l11l1_l1_!=l11lll_l1_ (u"ࠨࠩ㦳"): self.getControl(9010).setEnabled(True)
		if self.l1l1l111l1l1_l1_!=l11lll_l1_ (u"ࠩࠪ㦴"): self.getControl(9011).setEnabled(True)
		if self.l1llll1l1lll_l1_!=l11lll_l1_ (u"ࠪࠫ㦵"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1ll1lllll1l_l1_)
		except: pass
		#del self
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࡧࡩ࡫ࠦࡵࡱࡦࡤࡸࡪ࠮ࡳࡦ࡮ࡩ࠰ࡵ࡫ࡲࡤࡧࡱࡸ࠱࠰ࡡࡳࡩࡶ࠭࠿ࠓࠊࠊࠋࡷࡩࡽࡺࠠ࠾ࠢࡤࡶ࡬ࡹ࡛࠱࡟ࠐࠎࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡡࡳࡩࡶ࠭ࡃ࠷࠺ࠡࡶࡨࡼࡹࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࡢࡴࡪࡷࡠ࠷࡝ࠎࠌࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡦࡸࡧࡴࠫࡁ࠶࠿ࠦࡴࡦࡺࡷࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰ࡧࡲࡨࡵ࡞࠶ࡢࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡱࡧࡵࡧࡪࡴࡴ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷࠤࡂࠦࡰࡦࡴࡦࡩࡳࡺࠬࡵࡧࡻࡸࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡭࡫ࡩࡨࡪࡷࠤࡂࠦࡳࡦ࡮ࡩ࠲ࡨࡸࡥࡢࡶࡨࡗ࡭ࡵࡷࡊ࡯ࡤ࡫ࡪ࠮ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠴࠱ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠴࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯࠴࠯ࡷࡪࡲࡦ࠯ࡪࡨࡥࡩ࡫ࡲ࠭ࡵࡨࡰ࡫࠴ࡴࡦࡺࡷ࠰ࡸ࡫࡬ࡧ࠰ࡳࡶࡴ࡬ࡩ࡭ࡧ࠯ࡷࡪࡲࡦ࠯ࡦ࡬ࡶࡪࡩࡴࡪࡱࡱ࠰ࡸ࡫࡬ࡧ࠰࡬ࡱࡦ࡭ࡥࡠࡹ࡬ࡨࡹ࡮ࠬࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲࡸࡺࡩ࡮ࡧࡲࡹࡹ࠲ࡳࡦ࡮ࡩ࠲ࡨࡲ࡯ࡴࡧࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠑࠏࠏࠉࡴࡧ࡯ࡪ࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪࡳࡩࡷࡩࡥ࡯ࡶࠬࠑࠏࠏࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢ࡬ࡪ࡯ࡧࡩࡶࠐࠎࠎࠨࠢࠣ㦶")
class l11111lllll_l1_():
	def __init__(self,l1ll_l1_=False,l1l1ll1ll1ll_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1l1ll1ll1ll_l1_ = l1l1ll1ll1ll_l1_
		self.l1111ll11l1_l1_,self.l11l1l11l1l_l1_ = [],[]
		self.l1lll1l1l1ll_l1_,self.l1ll1l1lll11_l1_ = {},{}
		self.l1llllll111l_l1_ = []
		self.l1lll1l11l11_l1_,self.l1l11l11ll11_l1_,self.l11l111l11l_l1_ = {},{},{}
	def l11111l11ll_l1_(self,id,func,*args):
		id = str(id)
		self.l1lll1l1l1ll_l1_[id] = l11lll_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㦷")
		if self.l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ࠧ㦸"),id)
		# l1llllll11l1_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1llllll11l1_l1_ 2 & 3
		import threading
		l11l11l1lll_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1llllll111l_l1_.append(l11l11l1lll_l1_)
		#l11l11l1lll_l1_.start()
		return l11l11l1lll_l1_
	def start_new_thread(self,id,func,*args):
		l11l11l1lll_l1_ = self.l11111l11ll_l1_(id,func,*args)
		l11l11l1lll_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1lll1l11l11_l1_[id] = time.time()
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㦹"),l11lll_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢ࡬ࡨ࠿ࠦࠧ㦺")+id)
		try:
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㦻"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄ࠻࠼ࠣࠫ㦼")+str(func))
			self.l1ll1l1lll11_l1_[id] = func(*args)
			if l11lll_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ㦽") in str(func) and not self.l1ll1l1lll11_l1_[id].succeeded:
				l1lll111llll_l1_(l11lll_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ㦾"))
			self.l1111ll11l1_l1_.append(id)
			self.l1lll1l1l1ll_l1_[id] = l11lll_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㦿")
			#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㧀"),l11lll_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠣ࡭ࡩࡀࠠࠨ㧁")+id)
		except Exception as err:
			#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㧂"),l11lll_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣ࡭ࡩࡀࠠࠨ㧃")+id)
			if self.l1l1ll1ll1ll_l1_:
				l1lll1lllll1_l1_ = traceback.format_exc()
				sys.stderr.write(l1lll1lllll1_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l1l11l1l_l1_.append(id)
			self.l1lll1l1l1ll_l1_[id] = l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㧄")
		self.l1l11l11ll11_l1_[id] = time.time()
		self.l11l111l11l_l1_[id] = self.l1l11l11ll11_l1_[id] - self.l1lll1l11l11_l1_[id]
	def l1l1ll1ll1l1_l1_(self):
		for proc in self.l1llllll111l_l1_:
			proc.start()
	def l1l111l11l11_l1_(self):
		while l11lll_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭㧅") in list(self.l1lll1l1l1ll_l1_.values()): time.sleep(1.000)
def l1l1lll1lll1_l1_():
	l1l1l1ll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ㧆"))
	l1llll11lll1_l1_ = True
	if l1l1l1ll1lll_l1_==l11l1llllll_l1_:
		status = l11lll_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ㧇")
		l1llll11lll1_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭㧈")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11lll_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ㧉")
	else:
		status = l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ㧊")
		l111l11l1ll_l1_ = [l11lll_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ㧋"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ㧌"),l11lll_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ㧍"),l11lll_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ㧎"),l11lll_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ㧏"),l11lll_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭㧐"),l11lll_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ㧑"),l11lll_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ㧒"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ㧓")]
		l1ll1l11llll_l1_ = l111l11l1ll_l1_[-1]
		l1llll1ll1ll_l1_ = l1l1111lll1l_l1_(l1ll1l11llll_l1_)
		l1ll11ll11l1_l1_ = l1l1111lll1l_l1_(l11l1llllll_l1_)
		if l1ll11ll11l1_l1_>l1llll1ll1ll_l1_:
			status = l11lll_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㧔")
			l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡧ࡫࡯ࡩࡸࠦ࠽ࠡࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲࠪࠏࠍࠍࠎࠏࡦࡪ࡮ࡨࡷࠥࡃࠠࡴࡱࡵࡸࡪࡪࠨࡧ࡫࡯ࡩࡸ࠲ࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠮ࠓࠊࠊࠋࠌࡪࡴࡸࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡶ࠾ࠒࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡥࡣࡷࡥࡤ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡥ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࠪ࠲ࡩࡨࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢࡡࠫ࠲࠯ࡅࠩ࡝࠰ࡧࡦࠬ࠲ࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯࡝࠳ࡡࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࡡࡦࡳࡲࡶࡡࡳࡧࠣࡁࠥ࡜ࡅࡓࡕࡌࡓࡓࡥࡃࡐࡏࡓࡅࡗࡋ࡟ࡑࡃࡕࡗࡊࡘࠨࡰ࡮ࡧࡣࡻ࡫ࡲࡴ࡫ࡲࡲ࠮ࠓࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬࠦࡩ࡯ࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠾ࠒࠐࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠾࠾࡮ࡤࡷࡹ࡬ࡵ࡭࡮ࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩ࠿ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡰ࡮ࡧࡣࡩࡨࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩࠦࡃ࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠾ࠥࡵࡳ࠯ࡴࡨࡲࡦࡳࡥࠩࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩ࠱ࡳࡡࡪࡰࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡳࡵࡣࡷࡹࡸࠦ࠽ࠡࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠑࠏࠏࠉࠊࠋࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠉࠊࠤࠥࠦ㧕")
	return status,l1llll11lll1_l1_
def l1lll111ll1l_l1_(l1l1l1l11l1_l1_,l1ll11l1l111_l1_):
	succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,False
	type,name,l11lll11ll1_l1_,mode,l11lll1llll_l1_,l11l1l1ll11_l1_,text,context,l1ll11111l1_l1_ = l1l1l1l11l1_l1_
	l1l11llll111_l1_ = type,name,l11lll11ll1_l1_,mode,l11lll1llll_l1_,l11l1l1ll11_l1_,text,l11lll_l1_ (u"ࠨࠩ㧖"),l1ll11111l1_l1_
	l1l1ll11ll11_l1_ = int(mode)
	l111111l111_l1_ = int(l1l1ll11ll11_l1_%10)
	l1l1ll11ll1l_l1_ = int(l1l1ll11ll11_l1_/10)
	l1l111l111ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㧗"))
	l1llll1111ll_l1_,l1llll11lll1_l1_ = l1l1lll1lll1_l1_()
	if l1llll11lll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㧘"),l11lll_l1_ (u"ࠫࠬ㧙"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㧚"),l11lll_l1_ (u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭㧛")+l11l1llllll_l1_)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㧜"),l11lll_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㧝"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㧞"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㧟"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㧠"),l11lll_l1_ (u"ࠬࡇࡕࡕࡊࠪ㧡"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩ㧢"),l11lll_l1_ (u"ࠧࠨ㧣"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨ㧤"),l11lll_l1_ (u"ࠩࠪ㧥"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬ㧦"),l11lll_l1_ (u"ࠫࠬ㧧"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ㧨"),l11lll_l1_ (u"࠭ࠧ㧩"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫ࠨ㧪"),l11lll_l1_ (u"ࠨࠩ㧫"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㧬"),l11lll_l1_ (u"ࠪࠫ㧭"))
		#settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㧮"),l11lll_l1_ (u"ࠬ࠭㧯"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡸࡷࡪࡸ࠮ࡱࡴ࡬ࡺࡸ࠭㧰"),l11lll_l1_ (u"ࠧࠨ㧱"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㧲"),l11lll_l1_ (u"ࠩࠪ㧳"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭㧴"),l11lll_l1_ (u"ࠫࠬ㧵"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡴࡴࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㧶"),l11lll_l1_ (u"࠭ࠧ㧷"))
		#if not l1l111l111ll_l1_: settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㧸"),l11lll_l1_ (u"ࠨࠩ㧹"))
		#l1l1l1ll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭㧺"))
		#if l1l1l1ll1lll_l1_:
		#	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㧻"),l11lll_l1_ (u"ࠫࠬ㧼"))
		#	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㧽"))
		#	return
		#l111l11ll11_l1_([main_dbfile])
		import l11ll1ll1l1_l1_
		if l1llll1111ll_l1_==l11lll_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭㧾"):
			LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㧿"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ㨀")+addon_path+l11lll_l1_ (u"ࠩࠣࡡࠬ㨁"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ㨂"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ㨃"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ㨄"))
		else:
			LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㨅"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ㨆")+addon_path+l11lll_l1_ (u"ࠨࠢࡠࠫ㨇"))
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㨈"),l11lll_l1_ (u"ࠪࠫ㨉"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㨊"),l11lll_l1_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ㨋"))
			l111l11ll11_l1_()
			FIX_ALL_DATABASES(False)
			user = l11llll1111_l1_(32)
			l11ll1ll1l1_l1_.l1l1l11111l1_l1_()
			l11ll1ll1l1_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㨌"),False)
			l11ll1ll1l1_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ㨍"),False)
			l11ll1ll1l1_l1_.l1ll1lllll11_l1_(False)
			l11ll1ll1l1_l1_.l1l11lll1ll1_l1_(False)
			l11ll1ll1l1_l1_.l1l1l1111111_l1_(l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㨎"),l11lll_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ㨏"),False)
			l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࠋࠌࡸࡷࡿ࠺ࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳࡧ࡫࡯ࡩ࠷ࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ࠭ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠬࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ࠮ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠶ࠥࡃࠠࡹࡤࡰࡧࡦࡪࡤࡰࡰ࠱ࡅࡩࡪ࡯࡯ࠪ࡬ࡨࡂ࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧ࡬ࡱࡧ࡭ࡴࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡱࡶࡣ࡯࡭ࡹࡿ࠮ࡢࡵ࡮ࠫ࠱࠭ࡴࡳࡷࡨࠫ࠮ࠓࠊࠊࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠎࠏࠢࠣࠤ㨐")
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㨑"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㨒"),l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ㨓"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㨔"))
				l1l111lllll1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㨕"))
				l1l111lllll1_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ㨖"),l11lll_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ㨗"))
			except: pass
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㨘"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㨙"),l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ㨚"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㨛"))
				l1l111lllll1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㨜"))
				l1l111lllll1_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ㨝"),l11lll_l1_ (u"ࠪ࠷ࠬ㨞"))
			except: pass
			try:
				l1111lllll1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㨟"),l11lll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ㨠"),l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㨡"),l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㨢"))
				l1l111lllll1_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㨣"))
				l1l111lllll1_l1_.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ㨤"),l11lll_l1_ (u"ࠪ࠶ࠬ㨥"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㨦"),l11lll_l1_ (u"ࠬ࠭㨧"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㨨"),l11lll_l1_ (u"ࠧฦาสࠤ่์สࠡฬึฮำีๅࠡะา้ฮࠦเࡊࡒࡗ࡚ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢฯำ๏ีษࠨ㨩"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1lll1l1llll_l1_):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㨪"),l11lll_l1_ (u"ࠩࠪ㨫"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㨬"),l11lll_l1_ (u"ࠫสึวࠡๅ้ฮࠥะำหะา้ࠥิฯๆหࠣไࡒ࠹ࡕࠡษ็้ํา่ะหࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ็ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡฬ็ๆฬฬ๊ศࠢหะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ㨭"))
			#	import l1l11l1ll111_l1_
			#	l1l11l1ll111_l1_.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11ll1lllll_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1111llll1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ㨮"),l11l1llllll_l1_)
		l11ll1ll1l1_l1_.l111lll11l1_l1_(False)
		#return
	#text = text.replace(l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㨯"),l11lll_l1_ (u"ࠧࠨ㨰"))
	l1l1l11111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㨱"))
	l11l1lllll_l1_ = RESTORE_PATH_NAME(l1ll11l1l111_l1_)
	l11ll1l11ll_l1_ = RESTORE_PATH_NAME(name)
	l1lll11l111l_l1_ = [0,15,17,19,26,34,50,53]
	l1l1lllll11l_l1_ = [0,15,17,19,26,34,50,53]
	l11l111lll1_l1_ = l1l1ll11ll1l_l1_ not in l1l1lllll11l_l1_
	l1l111l11ll1_l1_ = l1l1ll11ll1l_l1_ in [23,28,71,72]
	l1ll11l1111l_l1_ = l1l1ll11ll11_l1_ in [265,270]
	l1ll1ll111ll_l1_ = (l11l111lll1_l1_ or l1l111l11ll1_l1_) and not l1ll11l1111l_l1_
	l111l111ll1_l1_ = l1l1l11111_l1_!=l11lll_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㨲") and (l1l1l11111_l1_!=l11lll_l1_ (u"ࠪࠫ㨳") or context==l11lll_l1_ (u"ࠫࠬ㨴"))
	l1l1ll1l1l11_l1_ = l11lll_l1_ (u"ࠬࡺࡹࡱࡧࡀࠫ㨵") in l1l1l11111_l1_
	l1l11llll1ll_l1_ = l1l1ll11ll11_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	SEARCH = l111111l111_l1_==9 or l1l1ll11ll11_l1_ in [145,516,523]
	l111lllll1l_l1_ = not l1l11llll1ll_l1_
	l1111l1llll_l1_ = not SEARCH
	l1l1l1ll11l1_l1_ = l11l1lllll_l1_ in [l11lll_l1_ (u"࠭ࠧ㨶"),l11lll_l1_ (u"ࠧ࠯࠰ࠪ㨷")]
	l1llll1l1ll1_l1_ = l1l1l1ll11l1_l1_ or l111lllll1l_l1_
	l1lll11l1l1l_l1_ = l1l1l1ll11l1_l1_ or l1111l1llll_l1_ or l1l1ll1l1l11_l1_
	l1l11l1l1111_l1_ = l1l1ll11ll11_l1_ not in [260,265,270,330,540]
	if l1l111l111ll_l1_: l1llll1l11ll_l1_ = SEARCH or l1l11llll1ll_l1_
	else: l1llll1l11ll_l1_ = True
	l1l1ll111l_l1_ = l1l1ll11ll1l_l1_ in [74,75]
	l111lll1l11_l1_ = l1l1ll11ll11_l1_ in [280,720]
	l1lllll111ll_l1_ = not l1l1ll111l_l1_ and not l111lll1l11_l1_
	l1ll11ll1l11_l1_ = l1llll1l1ll1_l1_ and l1lll11l1l1l_l1_ and l1l11l1l1111_l1_ and l1llll1l11ll_l1_ and l1lllll111ll_l1_
	l1111l1l11l_l1_ = l1l11l1l1111_l1_ and l1llll1l11ll_l1_ and l1lllll111ll_l1_
	l111l1l11ll_l1_ = l1111l1l11l_l1_ and l111l111ll1_l1_ and l1ll11ll1l11_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㨸"),l11lll_l1_ (u"ࠩࠪ㨹"),l11lll_l1_ (u"ࠪࠫ㨺"),type+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㨻")+l1l1l11111_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㨼")+str(l1l1lllll1l1_l1_))
	trans_provider = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭㨽"))
	trans_code = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ㨾"))
	if 1 and l111l111ll1_l1_ and l1ll11ll1l11_l1_:
		l1ll1l1ll11l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㨿"),l11lll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ㩀")+trans_provider+l11lll_l1_ (u"ࠪࡣࠬ㩁")+trans_code,l1l11llll111_l1_)
		if l1ll1l1ll11l_l1_:
			#xbmcgui.Dialog().l1l11ll1ll1l_l1_(l11lll_l1_ (u"ࠫࠬ㩂"),l11lll_l1_ (u"ࠬࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࠬ㩃"),l11lll_l1_ (u"࠭ࠧ㩄"),100,False)
			LOG_THIS(l11lll_l1_ (u"ࠧࠨ㩅"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㩆")+trans_provider+l11lll_l1_ (u"ࠩࡢࠫ㩇")+trans_code+l11lll_l1_ (u"ࠪࠤࠥࠦࡌࡰࡣࡧ࡭ࡳ࡭ࠠ࡮ࡧࡱࡹࠥ࡬ࡲࡰ࡯ࠣࡧࡦࡩࡨࡦࠩ㩈"))
			if 1 and l1l1ll1l1l11_l1_:
				#xbmcgui.Dialog().l1l11ll1ll1l_l1_(l11lll_l1_ (u"ࠫࠬ㩉"),l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩࡽ࡮ࡴࡧࠡࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ㩊"),l11lll_l1_ (u"࠭ࠧ㩋"),100,False)
				l111lll1ll1_l1_ = []
				import l1l11ll111l1_l1_,FAVORITES
				l1ll11l1l1l1_l1_ = l1l11ll111l1_l1_.l1ll1l1l1l11_l1_
				l111ll1llll_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lll1l1lll1_l1_ = l1l1l11111_l1_
				l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll11l111l1_l1_,l1l1ll111l11_l1_,l1l11ll1111l_l1_,l1lll111l11l_l1_,l1111ll1l11_l1_,l1l1llllllll_l1_,l1lll1111l1l_l1_ = EXTRACT_KODI_PATH(l1lll1l1lll1_l1_)
				l1ll11l1ll1l_l1_ = l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll11l111l1_l1_,l1l1ll111l11_l1_,l1l11ll1111l_l1_,l1lll111l11l_l1_,l1111ll1l11_l1_,l11lll_l1_ (u"ࠧࠨ㩌"),l1lll1111l1l_l1_
				#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㩍"),str(l1ll11l1ll1l_l1_))
				for l1l1lll11lll_l1_ in l1ll1l1ll11l_l1_:
					l1l1l11lll1l_l1_ = l1l1lll11lll_l1_[l11lll_l1_ (u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ㩎")]
					#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㩏"),str(l1l1l11lll1l_l1_))
					if l1l1l11lll1l_l1_==l1ll11l1ll1l_l1_ or l1l1lll11lll_l1_[l11lll_l1_ (u"ࠫࡲࡵࡤࡦࠩ㩐")] in [265,270]:
						l1l1lll11lll_l1_ = GET_LIST_ITEM(l1l1l11lll1l_l1_,l1ll11l1l1l1_l1_,l111ll1llll_l1_)
						if l1l1lll11lll_l1_[l11lll_l1_ (u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ㩑")]:
							#xbmcgui.Dialog().l1l11ll1ll1l_l1_(l11lll_l1_ (u"࠭ࠧ㩒"),l11lll_l1_ (u"ࠧࡶࡲࡧࡥࡹ࡯࡮ࡨࠢࡦࡳࡳࡺࡥࡹࡶࠪ㩓"),l11lll_l1_ (u"ࠨࠩ㩔"),100,False)
							l1l1l1lll111_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111ll1llll_l1_,l1l1l11lll1l_l1_,l1l1lll11lll_l1_[l11lll_l1_ (u"ࠩࡱࡩࡼࡶࡡࡵࡪࠪ㩕")])
							#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㩖"),str(l1l1l1lll111_l1_))
							#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㩗"),str(l1l1lll11lll_l1_[l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ㩘")]))
							l1l1lll11lll_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ㩙")] = l1l1l1lll111_l1_+l1l1lll11lll_l1_[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭㩚")]
					l111lll1ll1_l1_.append(l1l1lll11lll_l1_)
				settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㩛"),l11lll_l1_ (u"ࠩࠪ㩜"))
				if type==l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㩝"): WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㩞")+trans_provider+l11lll_l1_ (u"ࠬࡥࠧ㩟")+trans_code,l1l11llll111_l1_,l111lll1ll1_l1_,REGULAR_CACHE)
			else: l111lll1ll1_l1_ = l1ll1l1ll11l_l1_
			if type==l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㩠") and l11l1lllll_l1_!=l11lll_l1_ (u"ࠧ࠯࠰ࠪ㩡") and l1ll1ll111ll_l1_: l11lll1lll1_l1_()
			l1111llll11_l1_ = CREATE_KODI_MENU(l1l11llll111_l1_,l111lll1ll1_l1_,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
			#xbmcgui.Dialog().l1l11ll1ll1l_l1_(l11lll_l1_ (u"ࠨࠩ㩢"),l11lll_l1_ (u"ࠩࡦࡶࡪࡧࡴࡪࡰࡪࠤࡲ࡫࡮ࡶࠩ㩣"),l11lll_l1_ (u"ࠪࠫ㩤"),100,False)
			return
	elif type==l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㩥") and l1l1l11111_l1_==l11lll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㩦") and l1111l1l11l_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㩧"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㩨")+trans_provider+l11lll_l1_ (u"ࠨࡡࠪ㩩")+trans_code+l11lll_l1_ (u"ࠩࠣࠤࠥࡊࡥ࡭ࡧࡷ࡭ࡳ࡭ࠠࡰ࡮ࡧࠤࡨࡧࡣࡩࡧࡧࠤࡲ࡫࡮ࡶࠩ㩪"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㩫")+trans_provider+l11lll_l1_ (u"ࠫࡤ࠭㩬")+trans_code,l1l11llll111_l1_)
	#context = l11lll_l1_ (u"ࠬ࠭㩭")
	if l11lll_l1_ (u"࠭࡟ࠨ㩮") in context: l1l1llllll11_l1_,l1l11l1l1l11_l1_ = context.split(l11lll_l1_ (u"ࠧࡠࠩ㩯"),1)
	else: l1l1llllll11_l1_,l1l11l1l1l11_l1_ = context,l11lll_l1_ (u"ࠨࠩ㩰")
	if l1l1llllll11_l1_ in [l11lll_l1_ (u"ࠩ࠴ࠫ㩱"),l11lll_l1_ (u"ࠪ࠶ࠬ㩲"),l11lll_l1_ (u"ࠫ࠸࠭㩳"),l11lll_l1_ (u"ࠬ࠺ࠧ㩴"),l11lll_l1_ (u"࠭࠵ࠨ㩵")] and l1l11l1l1l11_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㩶") l11l11llll_l1_ l1l11lll1lll_l1_ l1l11l1111ll_l1_ is no addon_handle l1l11l11l_l1_ to l111l111l1l_l1_ for l1ll1ll11ll1_l1_ directory
		#l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠫ㩷") l11l11llll_l1_ to open a menu list using l1l11lllll1l_l1_ addon_path
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ㩸")+sys.argv[0]+addon_path.split(l11lll_l1_ (u"ࠪࠪࡨࡵ࡮ࡵࡧࡻࡸࡂ࠭㩹"))[0]+l11lll_l1_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃ࠰ࠨ㩺")+l11lll_l1_ (u"ࠧ࠯ࠢ㩻"))
		#xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ㩼")+addon_id+l11lll_l1_ (u"ࠧ࠰ࡁࡷࡩࡽࡺ࠽ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠫࠪ㩽"))
		# l1111l1l1l_l1_ not remove addon_path .. it is needed to update l1l1l1lll11l_l1_ status
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㩾"),addon_path)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㩿"))
		return
	elif l1l1llllll11_l1_==l11lll_l1_ (u"ࠪ࠺ࠬ㪀"):
		if l1l11l1l1l11_l1_==l11lll_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㪁"): DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬ㪂"),l11lll_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭㪃"))
		elif l1l11l1l1l11_l1_==l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠧ㪄"): l1l1ll11ll11_l1_ = 334
		results = l1l1l1l11111_l1_(type,l11ll1l11ll_l1_,l11lll11ll1_l1_,l1l1ll11ll11_l1_,l11lll1llll_l1_,l11l1l1ll11_l1_,text,context,l1ll11111l1_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㪅"))
		return
	elif context==l11lll_l1_ (u"ࠩ࠺ࠫ㪆"):
		import l1ll11ll1ll_l1_
		l1ll11ll1ll_l1_.l1l1l11llll_l1_()
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㪇"))
		return
	elif context==l11lll_l1_ (u"ࠫ࠽࠭㪈"):
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ㪉")+addon_id+l11lll_l1_ (u"࠭࠿࡮ࡱࡧࡩࡂ࠭㪊")+str(mode)+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷ࠯ࠧ㪋"))
		return
	elif context==l11lll_l1_ (u"ࠨ࠻ࠪ㪌"):
		# l1l1lll11ll1_l1_ update the l1l111l1llll_l1_ menu
		#results = l1l1l1l11111_l1_(type,l11ll1l11ll_l1_,l11lll11ll1_l1_,mode,l11lll1llll_l1_,l11l1l1ll11_l1_,text,context,l1ll11111l1_l1_)
		# l1l1lll11ll1_l1_ update the l1ll1l1lll1l_l1_ menu
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㪍"),l11lll_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭㪎"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㪏"))
		return
	if settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㪐")) not in [l11lll_l1_ (u"࠭ࡁࡖࡖࡒࠫ㪑"),l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ㪒"),l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㪓")]: settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㪔"),l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㪕"))
	if not settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ㪖")): settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㪗"),l1lll1l11ll1_l1_[0])
	l1l111ll11ll_l1_ = False if l11l1llll11_l1_(l11lll_l1_ (u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧ㪘")) else True
	l11l11l11ll_l1_ = l1lll1111_l1_ if l1l111ll11ll_l1_ else REGULAR_CACHE
	l111lllllll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㪙"))
	l1l11l1l111l_l1_ = l1lll111ll11_l1_(settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㪚")))
	l1l11l1l111l_l1_ = 0 if not l1l11l1l111l_l1_ else int(l1l11l1l111l_l1_)
	if l111lllllll_l1_ in [l11lll_l1_ (u"ࠩࠪ㪛"),l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㪜")] or not l11l11l11ll_l1_ or not l1l11l1l111l_l1_ or now-l1l11l1l111l_l1_<0 or now-l1l11l1l111l_l1_>l11l11l11ll_l1_:
		l111lllllll_l1_ = l11111l1ll1_l1_(True,False)
	l11l111l1l1_l1_ = l1lll111ll11_l1_(settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㪝")))
	l11l111l1l1_l1_ = 0 if not l11l111l1l1_l1_ else int(l11l111l1l1_l1_)
	l1111ll1111_l1_ = l1lll111ll11_l1_(settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㪞")))
	l1111ll1111_l1_ = 0 if not l1111ll1111_l1_ else int(l1111ll1111_l1_)
	if not l11l111l1l1_l1_ or not l1111ll1111_l1_ or now-l1111ll1111_l1_<0 or now-l1111ll1111_l1_>l11l111l1l1_l1_:
		auth = 1
		if l1l111ll11ll_l1_:
			# https://www.l1lll1l11111_l1_.com/l1l1l11111ll_l1_/l111111111l_l1_
			# unescapeHTML(l11lll_l1_ (u"࠭ࠠࠧࠥࡻ࠶࠻࠹ࡂ࠼ࠢࠩࠧࡽ࠸࠷࠲ࡆ࠾ࠤࠫࠩࡸ࠳࠸࠵ࡅࡀࠦࠦࠤࡺ࠵࠺࠸ࡈ࠻ࠨ㪟"))
			#l1ll11l1llll_l1_ = l11lll_l1_ (u"ࠧ⸼ࠢ⼠ࠤࠥ⾐ࠠࠡ⸬ࠣ⸿ࠬ㪠")
			#l1lll111111l_l1_ = l11lll_l1_ (u"ࠨ⸽ࠣ⼡ࠥࠦ⾋ࠡࠢ⸭ࠤ⹀࠭㪡")
			l1l1l11lllll_l1_ = l11l1111ll1_l1_(True)
			if len(l1l1l11lllll_l1_)>1:
				LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㪢"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡓࡩࡱࡺ࡭ࡳ࡭ࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㪣")+addon_path+l11lll_l1_ (u"ࠫࠥࡣࠧ㪤"))
				id,l1l1111ll1ll_l1_,l1l11l1111l1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11lllll_l1_[0]
				#if l11lll_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ㪥") in reason: l1l1llll111l_l1_,l1l1llll11l1_l1_,l1l1llll11ll_l1_ = reason.split(l11lll_l1_ (u"࠭࡜࡯࠽࠾ࠫ㪦"),2)
				#else: l1l1llll111l_l1_,l1l1llll11l1_l1_,l1l1llll11ll_l1_ = reason,reason,reason
				l1lll1l1ll11_l1_,l1lll1l1ll1l_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㪧"))
				del l1l1l11lllll_l1_[0]
				l1l1ll11lll1_l1_ = random.sample(l1l1l11lllll_l1_,1)
				id,l1l1111ll1ll_l1_,l1l11l1111l1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1ll11lll1_l1_[0]
				l1l11l1111l1_l1_ = l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ㪨")+id+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㪩")+l1l11l1111l1_l1_
				l11111l1l11_l1_ = l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㪪")
				l1ll1lll1ll1_l1_ = l11lll_l1_ (u"ࠫฬ๊สษำ฼หฯ࠭㪫")
				l1llll1l11l1_l1_,l1l1l111l1l1_l1_ = l11111lll11_l1_,l11111l1l11_l1_
				l11l1l11_l1_ = [l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1ll1lll1ll1_l1_]
				l1111111l11_l1_ = 5 if l11l1llll11_l1_(l11lll_l1_ (u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭㪬")) else 15
				choice = -9
				while choice<0:
					l1111ll1lll_l1_ = random.sample(l11l1l11_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࠧ㪭"),l1111ll1lll_l1_[0],l1111ll1lll_l1_[1],l1111ll1lll_l1_[2],l1lll1l1ll11_l1_,l1l11l1111l1_l1_,l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㪮"),l1111111l11_l1_,60)
					if choice==10: break
					import l11ll1ll1l1_l1_
					if choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ㪯"),l11lll_l1_ (u"ࠩࠪ㪰"),l11lll_l1_ (u"ࠪ฽ํีษࠨ㪱"),l11lll_l1_ (u"ࠫࠬ㪲"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㪳"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ࠨ㪴")+reason,l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ㪵"),20)
						l11ll1ll1l1_l1_.l1l1lll1111l_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[2]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ㪶"),l11lll_l1_ (u"ࠩࠪ㪷"),l1ll1lll1ll1_l1_,l11lll_l1_ (u"ࠪࠫ㪸"),l1lll1l1ll11_l1_,l1l11l1111l1_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㪹")+l11l1l11_l1_[0]+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㪺"),l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㪻"),30)
						l11ll1ll1l1_l1_.l11lll1l111_l1_(False)
					if choice==-1: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㪼"),l11lll_l1_ (u"ࠨࠩ㪽"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㪾"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ่้ࠣิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ㪿"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㫀"),l1l1lll11l11_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㫁"),l11lll_l1_ (u"࠭ࡁࡖࡖࡋࠫ㫂"),auth,PERMANENT_CACHE)
	# l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㫃")	l111l111l1l_l1_ file to read/write the l1l1l11ll1l1_l1_ menu list
	# l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㫄")		no l11l1l11111_l1_ l1l11lll1l1l_l1_ to the l1l1l11ll1l1_l1_ menu list
	l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉࡔࡋࡗࡉࡘࡥࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡋࡗࡉࡘࡥࡍࡐࡆࡈࡗࠥࡧ࡮ࡥࠢࡰࡳࡩ࡫࠱࠾࠿࠼ࠑࠏࠏࡏࡕࡊࡈࡖࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠺࠲࠵࠲࠸࠯࠹࠷࠹࡝ࠎࠌࠌࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡏࡔࡆࡕࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡲࡶࠥࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠐࠎࠎࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖࠤࡂࠦ࡭ࡰࡦࡨ࠶ࡂࡃ࠱࠷ࠢࡤࡲࡩࠦ࡭ࡰࡦࡨ࠴ࠦࡃ࠱࠷࠲ࠐࠎࠎ࡟ࡏࡖࡖࡘࡆࡊࡥࡍࡆࡐࡘࡗࠥࡃࠠ࡮ࡱࡧࡩ࠵ࠦࡩ࡯ࠢ࡞࠵࠹࠺࡝ࠎࠌࠌࠧࡳࡧ࡭ࡦࡡࠣࡁࠥࡉࡌࡆࡃࡑࡣࡒࡋࡎࡖࡡࡏࡅࡇࡋࡌࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡲࡦࡳࡥࡠࠢࡀࠤࡗࡋࡓࡕࡑࡕࡉࡤࡖࡁࡕࡊࡢࡒࡆࡓࡅࠩࡰࡤࡱࡪࡥࠩࠎࠌࠌࡖࡊࡓࡅࡎࡄࡈࡖࡤࡘࡅࡔࡗࡏࡘࡘࡥࡍࡐࡆࡈࡗࠥࡃࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࡯ࡳࠢࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠑࠏࠏࡩࡧࠢࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖ࠾ࠒࠐࠉࠊࠥ࡬ࡪࠥࡘࡁࡏࡆࡒࡑࡤࡓࡏࡅࡇࡖ࠾ࠥࡩ࡯࡯ࡦ࠴ࠤࡂࠦࠨ࡮ࡧࡱࡹࡤࡲࡡࡣࡧ࡯ࠤ࡮ࡴࠠ࡜ࠩ࠱࠲ࠬ࠲ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪࡡ࠮ࠓࠊࠊࠋࠦࡩࡱ࡯ࡦࠡࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙࠺ࠡࡥࡲࡲࡩ࠷ࠠ࠾ࠢࠫࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠩࠎࠌࠌࠍ࡮࡬ࠠࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࠦࡩ࡯ࠢࡷࡩࡽࡺࠠࡢࡰࡧࠤࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠢ࠿ࡱࡥࡲ࡫࡟ࠡࡣࡱࡨࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮࡬ࡢࡵࡷࡱࡪࡴࡵࡧ࡫࡯ࡩ࠮ࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡵ࡫࡮ࠩ࡮ࡤࡷࡹࡳࡥ࡯ࡷࡩ࡭ࡱ࡫ࠬࠨࡴࡥࠫ࠮࠴ࡲࡦࡣࡧࠬ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱ࡯ࡨࡋࡏࡌࡆ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚࡛࠻࡟ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡳࡱࡪࡆࡊࡎࡈ࠭ࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥ࡝ࡲࡪࡶ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡳࡧࡶࡹࡱࡺࡳࠡ࠿ࠣࡑࡆࡏࡎࡠࡆࡌࡗࡕࡇࡔࡄࡊࡈࡖ࠭ࡺࡹࡱࡧ࠯ࡲࡦࡳࡥࡠ࠮ࡸࡶࡱࡥࠬ࡮ࡱࡧࡩ࠱࡯࡭ࡢࡩࡨࡣ࠱ࡶࡡࡨࡧࡢ࠰ࡹ࡫ࡸࡵ࠮ࡦࡳࡳࡺࡥࡹࡶ࠯࡭ࡳ࡬࡯ࡥ࡫ࡦࡸ࠮ࠓࠊࠊࠋࠌࡲࡪࡽࡆࡊࡎࡈࠤࡂࠦࡳࡵࡴࠫࡱࡪࡴࡵࡊࡶࡨࡱࡸࡒࡉࡔࡖࠬࠑࠏࠏࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡲࡪࡽࡆࡊࡎࡈࠤࡂࠦ࡮ࡦࡹࡉࡍࡑࡋ࠮ࡦࡰࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠎࠌࠌࠍࠎࡵࡰࡦࡰࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦ࠮ࠪࡻࡧ࠭ࠩ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡯ࡧࡺࡊࡎࡒࡅࠪࠏࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡂࠦࡍࡂࡋࡑࡣࡉࡏࡓࡑࡃࡗࡇࡍࡋࡒࠩࡶࡼࡴࡪ࠲࡮ࡢ࡯ࡨࡣ࠱ࡻࡲ࡭ࡡ࠯ࡱࡴࡪࡥ࠭࡫ࡰࡥ࡬࡫࡟࠭ࡲࡤ࡫ࡪࡥࠬࡵࡧࡻࡸ࠱ࡩ࡯࡯ࡶࡨࡼࡹ࠲ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠪࠏࠍࠍࠧࠨࠢ㫅")
	results = l1l1l1l11111_l1_(type,l11ll1l11ll_l1_,l11lll11ll1_l1_,mode,l11lll1llll_l1_,l11l1l1ll11_l1_,text,context,l1ll11111l1_l1_)
	# l1111ll111l_l1_ l1llll11ll11_l1_: succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,True
	# l1lll1llll11_l1_ = True => l1ll1l1l1ll1_l1_ this list is l1l1l1lllll1_l1_ and will exit to main menu
	# l1lll1llll11_l1_ = False => l1ll1l1l1ll1_l1_ this list is l1llllll1l1l_l1_ and will exit to l1l1l11ll1l1_l1_ menu
	# l111ll1l1l1_l1_ = True => will cause the l1l111l111l1_l1_ status to l1l111l1l11l_l1_ l1l1ll11llll_l1_
	# l111ll1l1l1_l1_ = False => will l1l1ll11l111_l1_ the l1l111l111l1_l1_ status to l111l111l11_l1_ l1llll1ll11l_l1_
	#succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = True,False,True
	#if not l11l1l1111l_l1_: l111ll1l1l1_l1_ = False
	if l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㫆") in text: l1lll1llll11_l1_ = True
	if type==l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㫇"):
		if l11l1lllll_l1_!=l11lll_l1_ (u"ࠬ࠴࠮ࠨ㫈") and l1ll1ll111ll_l1_: l11lll1lll1_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡩ࡯ࡶࠪ㫉"),l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㫊"),l11lll_l1_ (u"ࠨࡃࡘࡘࡍ࠭㫋")) or l1l1ll11ll11_l1_ not in l1lll11l111l_l1_) and not l11l1llll11_l1_(l11lll_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㫌")):
				import l1l11ll111l1_l1_
				l1ll1l1ll11l_l1_ = GET_ALL_LIST_ITEMS(l1l11ll111l1_l1_.l1ll1l1l1l11_l1_)
				l1111llll11_l1_ = CREATE_KODI_MENU(l1l11llll111_l1_,l1ll1l1ll11l_l1_,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
				if 1 and l1ll1l1ll11l_l1_ and l111l1l11ll_l1_:
					#xbmcgui.Dialog().l1l11ll1ll1l_l1_(l11lll_l1_ (u"ࠪࠫ㫍"),l11lll_l1_ (u"ࠫࡼࡸࡩࡵ࡫ࡱ࡫ࠥࡩࡡࡤࡪࡨࠫ㫎"),l11lll_l1_ (u"ࠬ࠭㫏"),100,False)
					WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㫐")+trans_provider+l11lll_l1_ (u"ࠧࡠࠩ㫑")+trans_code,l1l11llll111_l1_,l1ll1l1ll11l_l1_,REGULAR_CACHE)
				#elif 1 and not l1ll1l1ll11l_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㫒")+trans_provider+l11lll_l1_ (u"ࠩࡢࠫ㫓")+trans_code,l1l11llll111_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㫔")+addon_id+l11lll_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㫕"),xbmcgui.ListItem(l11lll_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫ㫖")))
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㫗")+addon_id+l11lll_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ㫘"),xbmcgui.ListItem(l11lll_l1_ (u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ㫙")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
	return
def l1l1l1l11111_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_):
	l1l1ll11ll11_l1_ = int(mode)
	l1l1ll11ll1l_l1_ = int(l1l1ll11ll11_l1_//10)
	if   l1l1ll11ll1l_l1_==0:  import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==1:  import l111l1l1_l1_ 		; results = l111l1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==2:  import l1l1l1111l1_l1_ 		; results = l1l1l1111l1_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==3:  import l1111l111ll_l1_ 		; results = l1111l111ll_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==4:  import l1l1l1lll_l1_ 	; results = l1l1l1lll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==5:  import l11l111l111_l1_ 	; results = l11l111l111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==6:  import l1ll11ll1_l1_ 	; results = l1ll11ll1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==7:  import l1l111l_l1_ 		; results = l1l111l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==8:  import l1l1l1111ll_l1_ 	; results = l1l1l1111ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==9:  import l1ll1lll1l_l1_		; results = l1ll1lll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==10: import l1ll11l11ll1_l1_ 		; results = l1ll11l11ll1_l1_.MAIN(l1l1ll11ll11_l1_,url)
	elif l1l1ll11ll1l_l1_==11: import l1l1l11l11l1_l1_ 	; results = l1l1l11l11l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==12: import l11111ll1l_l1_ 		; results = l11111ll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==13: import l1l1ll111_l1_	; results = l1l1ll111_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==14: import l111llll11l_l1_ 		; results = l111llll11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_,name,l11l_l1_)
	elif l1l1ll11ll1l_l1_==15: import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==16: import l1l11llll1ll_l1_	 	; results = l1l11llll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==17: import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==18: import l1l111l1ll1l_l1_	; results = l1l111l1ll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==19: import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==20: import l111lll1l_l1_		; results = l111lll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==21: import l11111111ll_l1_ ; results = l11111111ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==22: import l1ll1ll11ll_l1_ 	; results = l1ll1ll11ll_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==23: import IPTV 		; results = IPTV.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==24: import l111111_l1_ 		; results = l111111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==25: import l11l1l111_l1_ 	; results = l11l1l111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==26: import l1l11ll111l1_l1_ 		; results = l1l11ll111l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1l1ll11ll11_l1_,context)
	elif l1l1ll11ll1l_l1_==28: import IPTV 		; results = IPTV.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==29: import l111l1lll1l_l1_	; results = l111l1lll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==30: import l1ll1l1lll_l1_		; results = l1ll1l1lll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==31: import l1111l1l1l1_l1_	; results = l1111l1l1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==32: import l1l11l1l11l_l1_	; results = l1l11l1l11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==33: import l11l111lll_l1_		; results = l11l111lll_l1_.MAIN(l1l1ll11ll11_l1_,url)
	elif l1l1ll11ll1l_l1_==34: import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==35: import l1l1l111_l1_		; results = l1l1l111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==36: import l1ll1111l1ll_l1_		; results = l1ll1111l1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==37: import l1111l11l_l1_		; results = l1111l11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==38: import l1l1ll111l1l_l1_ 		; results = l1l1ll111l1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==39: import l1l1llll111_l1_	; results = l1l1llll111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==40: import l11lll1lll_l1_	; results = l11lll1lll_l1_.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11ll1l_l1_==41: import l11lll1lll_l1_	; results = l11lll1lll_l1_.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11ll1l_l1_==42: import l1llllllll_l1_		; results = l1llllllll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==43: import l1ll1l1l1l1_l1_		; results = l1ll1l1l1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==44: import l1ll1l1l1ll_l1_		; results = l1ll1l1l1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==45: import l11l11ll11l_l1_		; results = l11l11ll11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==46: import l1lll11l1l11_l1_		; results = l1lll11l1l11_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==47: import l1ll1ll11l_l1_	; results = l1ll1ll11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==48: import l1l11ll1l1l1_l1_		; results = l1l11ll1l1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==49: import l1lll11l1l_l1_		; results = l1lll11l1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==50: import l11ll1ll1l1_l1_ 	; results = l11ll1ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,text)
	elif l1l1ll11ll1l_l1_==51: import l1ll11ll1l1_l1_ 	; results = l1ll11ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==52: import l1ll11ll1l1_l1_ 	; results = l1ll11ll1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==53: import l1l11ll111l1_l1_ 		; results = l1l11ll111l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==54: import l1ll11ll1ll_l1_	; results = l1ll11ll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll11ll1l_l1_==55: import l1lll1l111_l1_ 	; results = l1lll1l111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==56: import l1l1l11ll11l_l1_		; results = l1l1l11ll11l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==57: import l1l1lll1ll1_l1_		; results = l1l1lll1ll1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==58: import l111ll1ll1l_l1_	; results = l111ll1ll1l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==59: import l1l1lll1111_l1_		; results = l1l1lll1111_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==60: import l1l1ll1ll11_l1_		; results = l1l1ll1ll11_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==61: import l1ll1ll_l1_		; results = l1ll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==62: import l1l1llll1ll_l1_		; results = l1l1llll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==63: import l1lll11ll1_l1_		; results = l1lll11ll1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==64: import l1lll1lll1ll_l1_		; results = l1lll1lll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==65: import l111111l1_l1_		; results = l111111l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==66: import l111llllll1_l1_		; results = l111llllll1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==67: import l1l11l111ll_l1_		; results = l1l11l111ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==68: import l111lll1l1_l1_		; results = l111lll1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==69: import l1111111l_l1_		; results = l1111111l_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==70: import l1l111l11l1_l1_		; results = l1l111l11l1_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==71: import l1l11l1ll111_l1_			; results = l1l11l1ll111_l1_.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==72: import l1l11l1ll111_l1_			; results = l1l11l1ll111_l1_.MAIN(l1l1ll11ll11_l1_,url,text,type,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==73: import l1l11ll11_l1_	; results = l1l11ll11_l1_.MAIN(l1l1ll11ll11_l1_,url,text)
	elif l1l1ll11ll1l_l1_==74: import l1l1ll111l_l1_		; results = l1l1ll111l_l1_.MAIN(l1l1ll11ll11_l1_)
	elif l1l1ll11ll1l_l1_==75: import l1l1ll111l_l1_		; results = l1l1ll111l_l1_.MAIN(l1l1ll11ll11_l1_)
	elif l1l1ll11ll1l_l1_==76: import l1l11llll1ll_l1_	 	; results = l1l11llll1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,text,l1l11l1_l1_,l1ll11111l1_l1_)
	elif l1l1ll11ll1l_l1_==77: import l1llll1l1ll_l1_ 	; results = l1llll1l1ll_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==78: import l1lll1l1l11_l1_ 	; results = l1lll1l1l11_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==79: import l1lll11l1l1_l1_ 	; results = l1lll11l1l1_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11ll1l_l1_==80: import l1lll11l111_l1_ 	; results = l1lll11l111_l1_.MAIN(l1l1ll11ll11_l1_,url,l1l11l1_l1_,text)
	else: results = None
	return results
def l11l1ll111_l1_(name=l11lll_l1_ (u"ࠩࠪ㫚")):
	if not name: name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ㫛"))
	name = name.replace(l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㫜"),l11lll_l1_ (u"ࠬ࠭㫝"))
	name = name.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ㫞"),l11lll_l1_ (u"ࠧࠡࠩ㫟")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㫠"),l11lll_l1_ (u"ࠩࠣࠫ㫡")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭㫢"),l11lll_l1_ (u"ࠫࠥ࠭㫣")).strip(l11lll_l1_ (u"ࠬࠦࠧ㫤"))
	name = name.replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㫥"),l11lll_l1_ (u"ࠧࠨ㫦")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㫧"),l11lll_l1_ (u"ࠩࠪ㫨"))
	tmp = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦࠧ㫩"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11lll_l1_ (u"ࠫࡒࡧࡩ࡯ࠢࡐࡩࡳࡻࠧ㫪")
	return name
def l1ll1l1l1l1l_l1_(code,reason,source,l1ll_l1_):
	l1lll1111l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㫫"))
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㫬"),l11lll_l1_ (u"ࠧࠨ㫭"))
	if l11lll_l1_ (u"ࠨ࠯ࠪ㫮") in source: l1l1l1l1l1l_l1_ = source.split(l11lll_l1_ (u"ࠩ࠰ࠫ㫯"),1)[0]
	else: l1l1l1l1l1l_l1_ = source
	l1111llll1l_l1_ = code in [7,11001,11002,10054]
	l1l111l1l111_l1_ = reason.lower()
	l1ll1l111l11_l1_ = code in [0,104,10061,111]
	l1ll1l1111ll_l1_ = l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㫰") in l1l111l1l111_l1_
	l1ll1l1111l1_l1_ = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ㫱") in l1l111l1l111_l1_
	l1ll1l11111l_l1_ = l11lll_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㫲") in l1l111l1l111_l1_
	l1ll1l111111_l1_ = l11lll_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ㫳") in l1l111l1l111_l1_
	l1l1l111111l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㫴"))
	l1l11l1lllll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㫵"))
	l1lll11lll11_l1_ = l11lll_l1_ (u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ㫶")
	l1l1ll1l1lll_l1_ = l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠪ㫷")+str(code)+l11lll_l1_ (u"ࠫ࠿ࠦࠧ㫸")+reason
	l1l1ll1l1lll_l1_ = l111l_l1_(l1l1ll1l1lll_l1_)
	if l1ll1l111l11_l1_ or l1ll1l1111ll_l1_ or l1ll1l1111l1_l1_ or l1ll1l11111l_l1_ or l1ll1l111111_l1_:
		l1lll11lll11_l1_ += l11lll_l1_ (u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬ㫹")
	if l1111llll1l_l1_: l1lll11lll11_l1_ += l11lll_l1_ (u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭㫺")
	l1l1ll1l1lll_l1_ = l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㫻")+l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㫼")
	if l1l1l111111l_l1_==l11lll_l1_ (u"ࠩࡄࡗࡐ࠭㫽") or l1l11l1lllll_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ㫾"):
		l1lll11lll11_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞้็ࠤฯื๊ะࠢฦ๊ࠥ๐อศ๊็ࠤฬ๊ศา่ส้ัࠦลึๆสัࠥอไๆึๆ่ฮࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠡว็ํࠥอไๆสิ้ัࠦฟࠢࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㫿")
	l11l1111l11_l1_ = False
	if l1ll_l1_ and source not in l1lllllll111_l1_:
		if l1l1l111111l_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ㬀") or l1l11l1lllll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ㬁"):
			#if kodi_version<19: l1l1ll1l1lll_l1_ = l1l1ll1l1lll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㬂"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㬃"),l11lll_l1_ (u"ࠩัีําࠧ㬄"),l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ㬅"),l11lll_l1_ (u"ࠫส฻ไศฯࠣห้๋ิไๆฬࠫ㬆"),l1l1l1l1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㬇")+TRANSLATE(l1l1l1l1l1l_l1_),l1lll11lll11_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㬈")+l1l1ll1l1lll_l1_)
			if choice==1:
				import l11ll1ll1l1_l1_
				l11ll1ll1l1_l1_.l1l1lll1111l_l1_()
			elif choice==2: l11l1111l11_l1_ = True
		else: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㬉"),l11lll_l1_ (u"ࠨࠩ㬊"),l1l1l1l1l1l_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㬋")+TRANSLATE(l1l1l1l1l1l_l1_),l1lll11lll11_l1_,l1l1ll1l1lll_l1_)
	#if reason.endswith(l11lll_l1_ (u"ࠪࠤ࠮࠭㬌")): reason = reason.rsplit(l11lll_l1_ (u"ࠫࡡࡴࠧ㬍"))[0]
	#if l11l1111l11_l1_: LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㬎"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㬏")+str(code)+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ㬐")+reason+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㬑")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ㬒")+l1lll11lll11_l1_+l11lll_l1_ (u"ࠪࠤࡢࡣࠠࠡࠢࡈࡒࡌࡒࡉࡔࡊ࠽ࠤࡠࠦࠧ㬓")+l1l1ll1l1lll_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ㬔"))
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭㬕"),l1lll1111l11_l1_)
	return l11l1111l11_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࡥࡰࡶࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠲ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠸ࠠࡰࡴࠣࡦࡱࡵࡣ࡬ࡧࡧ࠷࠿ࠓࠊࠊࠋࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭ๆ้฻้๋ࠣࠦวๅฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไ࠰ࠪࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣ࠯ࡂ้ࠦࠧࠡ็ࠤฯื๊ะࠢอๅฬ฻๊ๅࠢส็ะืࠠภࠩࠐࠎࠎࠏࡩࡧࠢࡧࡲࡸࡀࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤࡂࠦࠧๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่ࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠠࠬ࠿ࠣࠫࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์๋ࠦࠧࠬࡤ࡯ࡳࡨࡱ࡟࡮ࡧࡨࡷࡸࡧࡧࡦࠏࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤࡂ่ࠦࠧาสࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࠮ࡏࡓࡌࡍࡉࡏࡉࠫࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠪ࠭ࠪࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ࠯ࡸࡵࡵࡳࡥࡨ࠯ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡵࡴࠫࡧࡴࡪࡥࠪ࠭ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ࠱ࡲࡦࡣࡶࡳࡳ࠱ࠧࠡ࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠿࡛ࠦࠡࠩ࠮ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠮ࠫࠥࡣ࡝ࠡࠢࠣࡱࡪࡹࡳࡢࡩࡨࡉࡓࡍࡌࡊࡕࡋ࠾ࠥࡡࠠࠨ࠭ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠮ࠫࠥࡣࠧࠪࠏࠍࠍࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࡀࠍࠋࠋࠌࠍࡾ࡫ࡳࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢ࡝ࡊ࡙ࡎࡐࠪࠪࡧࡪࡴࡴࡦࡴࠪ࠰ࡸ࡯ࡴࡦ࠭ࠪࠤࠥࠦࠧࠬࡖࡕࡅࡓ࡙ࡌࡂࡖࡈࠬࡸ࡯ࡴࡦࠫ࠯ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠯ࡱࡪࡹࡳࡢࡩࡨࡉࡓࡍࡌࡊࡕࡋ࠰ࠬ࠭ࠬࠨๅ็หࠬ࠲ࠧ็฻่ࠫ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦࡹࡦࡵࡀࡁ࠶ࡀࠠࡪ࡯ࡳࡳࡷࡺࠠࡔࡇࡕ࡚ࡎࡉࡅࡔࠢ࠾ࠤࡘࡋࡒࡗࡋࡆࡉࡘ࠴ࡍࡂࡋࡑࠬ࠶࠿࠵ࠪࠏࠍࠍࡪࡲࡩࡧࠢࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹ࠺ࠎࠌࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠶ࠥࡃࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠫࠨࠢ࠱ࠤ์๊ࠠหำํำู๋ࠥาใฬࠤฬ๊ริสสฬࠥ๎วๅฯ็์้ࠦฟࠨࠏࠍࠍࠎࡿࡥࡴࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣ࡞ࡋࡓࡏࡑࠫࠫࡨ࡫࡮ࡵࡧࡵࠫ࠱ࡹࡩࡵࡧ࠮ࠫࠥࠦࠠࠨ࠭ࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠭ࡹࡩࡵࡧࠬ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠶࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠷࠺ࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦ࠽ࠡࠩๅำࠥ๐ใ้่๋๋ࠣอใ่๋ࠡ฽๋ࠥๆࠡษ็ััฮฺ่ࠠา็ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่ส์สา่อࠤ฾์ฯไ่ࠢๅฺ๎ไสࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅำห฻ࠥอไๆึไี๊ࠥวࠡ์฼ู้้ࠦ็ัๆࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็ࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ฺ๋ࠦำ๋ࠣีํࠠศๆุๅาฯ้ࠠษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠪࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯࡞ࡱࠫ࠰࠭ฬาสุ้ࠣำࠠศๆๆหูࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡลิื้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ัใࠢิๅ฾ࠦวๅฯฯฬࠥ࠮ๅฬๆสࠤ࡛ࡖࡎࠡ࠮ࠣࡔࡷࡵࡸࡺࠢ࠯ࠤࡉࡔࡓࠪࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦฬาสࠣ฻้ฮ่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ้ออใษࠪࠑࠏࠏࠉࠊࡆࡌࡅࡑࡕࡇࡠࡖࡈ࡜࡙࡜ࡉࡆ࡙ࡈࡖ࠭࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ࠮ࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠬࠑࠏࠏࠢࠣࠤ㬖")
def l111l11ll11_l1_(l1l11l1llll1_l1_=False):
	l1lll1l111l1_l1_ = [l11ll1lllll_l1_,favoritesfile,l1l1111llll1_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l11l1llll1_l1_ and (filename.startswith(l11lll_l1_ (u"ࠧࡪࡲࡷࡺࠬ㬗")) or filename.startswith(l11lll_l1_ (u"ࠨ࡯࠶ࡹࠬ㬘"))): continue
		if filename.startswith(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨ㬙")): continue
		l1ll1l1ll1ll_l1_ = os.path.join(addoncachefolder,filename)
		if l1ll1l1ll1ll_l1_ in l1lll1l111l1_l1_: continue
		try: os.remove(l1ll1l1ll1ll_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll111ll11l_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll11_l1_=True):
	l1l1l11l1l11_l1_,l1ll111ll1ll_l1_ = proxy.split(l11lll_l1_ (u"ࠪ࠾ࠬ㬚"))
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ㬛"),l11lll_l1_ (u"ูࠬรอำหࠤࠬ㬜")+name,time=2000)
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㬝"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ㬞")+name+l11lll_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㬟")+proxy+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㬠")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㬡"))
	url = url+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ㬢")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_,l1l1lll1ll11_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㬣"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ㬤")+name+l11lll_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭㬥")+proxy+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㬦")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㬧"))
		l1lll111llll_l1_(l11lll_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ㬨"))
	#else: LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㬩"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ㬪")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㬫")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㬬"))
	return response
def l1l11ll111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㬭"),url,l11lll_l1_ (u"ࠩࠪ㬮"),l11lll_l1_ (u"ࠪࠫ㬯"),True,l11lll_l1_ (u"ࠫࠬ㬰"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭㬱"),True,False)
	l1llll1l1l11_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l111111_l1_
		l1l1lll111l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ㬲"),html)
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㬳"),str(l1l1lll111l1_l1_))
		if l1l1lll111l1_l1_: html = l11lll_l1_ (u"ࠨ࡞ࡱࠫ㬴").join(l1l1lll111l1_l1_)
		proxies = html.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ㬵"),l11lll_l1_ (u"ࠪࠫ㬶")).strip(l11lll_l1_ (u"ࠫࡡࡴࠧ㬷")).split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㬸"))
		l1llll1l1l11_l1_ = []
		for proxy in proxies:
			if proxy.count(l11lll_l1_ (u"࠭࠮ࠨ㬹"))==3: l1llll1l1l11_l1_.append(proxy)
	return l1llll1l1l11_l1_
def l111ll1l111_l1_(*args):
	#l1l1llll1l1l_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠵࠷࠱࠷࠸࠴࠱࠸࠰࠴࠶࠼࠵ࡡࡱ࡫࠲ࡴࡷࡵࡸࡺࡁࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡹࡰࡦࡧࡧࡁ࠶࠶ࠦ࡭ࡣࡶࡸࡤࡩࡨࡦࡥ࡮ࡁ࠶࠶ࠦࡩࡶࡷࡴࡸࡃࡴࡳࡷࡨࠪࡵࡵࡳࡵ࠿ࡷࡶࡺ࡫ࠦࡧࡱࡵࡱࡦࡺ࠽ࡵࡺࡷࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ㬺")
	l11l111l1ll_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ㬻")
	l1ll1l11l1l1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭㬼")
	#l1llll1l1l1l_l1_ = l1l11ll111ll_l1_(l1l1llll1l1l_l1_)
	l1llll1l1l1l_l1_ = l1l11ll111ll_l1_(l1ll1l11l1l1_l1_)
	l1llll1l1l11_l1_ = l1l11ll111ll_l1_(l11l111l1ll_l1_)
	l11l11ll1l1_l1_ = l1llll1l1l1l_l1_+l1llll1l1l11_l1_
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㬽"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ㬾")+str(len(l1llll1l1l1l_l1_))+l11lll_l1_ (u"ࠬ࠱ࠧ㬿")+str(len(l1llll1l1l11_l1_))+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㭀"))
	proxy = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㭁"))
	response = l1l1111l111_l1_()
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㭂"),l11lll_l1_ (u"ࠩࠪ㭃"))
	if proxy or l11l11ll1l1_l1_:
		id,timeout = 0,10
		l1l11llll11l_l1_ = len(l11l11ll1l1_l1_)
		l1111111111_l1_ = timeout
		if l1l11llll11l_l1_>l1111111111_l1_: counts = l1111111111_l1_
		else: counts = l1l11llll11l_l1_
		l1111ll1ll1_l1_ = random.sample(l11l11ll1l1_l1_,counts)
		if proxy: l1111ll1ll1_l1_ = [proxy]+l1111ll1ll1_l1_
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㭄"),str(l1111ll1ll1_l1_))
		threads = l11111lllll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l1111ll11l1_l1_:
			if id<counts:
				proxy = l1111ll1ll1_l1_[id]
				threads.start_new_thread(id,l1ll111ll11l_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㭅"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㭆")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㭇"))
		l1111ll11l1_l1_ = threads.l1111ll11l1_l1_
		if l1111ll11l1_l1_:
			l1ll1l1lll11_l1_ = threads.l1ll1l1lll11_l1_
			l1lll111l111_l1_ = l1111ll11l1_l1_[0]
			response = l1ll1l1lll11_l1_[l1lll111l111_l1_]
			proxy = l1111ll1ll1_l1_[int(l1lll111l111_l1_)]
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㭈"),proxy)
			if l1lll111l111_l1_!=0: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㭉"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ㭊")+proxy+l11lll_l1_ (u"ࠪࠤࡢ࠭㭋"))
			else: LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㭌"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㭍")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㭎"))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㭏"),l11lll_l1_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙࠸ࠠ࠻࠼ࠣࠫ㭐")+str(l1111ll1ll1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㭑"),l11lll_l1_ (u"ࠪࡴࡷࡵࡸࡪࡧࡶࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㭒")+str(l11l11ll1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㭓"),l11lll_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ㭔")+str(threads.l1111ll11l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㭕"),l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ㭖")+str(threads.l11l1l11l1l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㭗"),l11lll_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࡵࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ㭘")+str(threads.l1ll1l1lll11_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㭙"),l11lll_l1_ (u"ࠫࡪࡲࡰࡢࡵࡨࡨࡹ࡯࡭ࡦࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ㭚")+str(threads.l11l111l11l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㭛"),l11lll_l1_ (u"࠭ࡳࡰࡴࡷࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ㭜")+str(l1lll11ll1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㭝"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㭞")+l1l11lll111l_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㭟")+str(l1lll11ll1l1_l1_))
	return response
def l1l11l11l111_l1_(connection,l1l111ll11l1_l1_):
	l11111l1lll_l1_ = connection.create_connection
	def l1l1l1l11l11_l1_(address,*args,**kwargs):
		host,port = address
		l1l1ll1l1ll1_l1_ = DNS_RESOLVER(host,l1l111ll11l1_l1_)
		if l1l1ll1l1ll1_l1_: host = l1l1ll1l1ll1_l1_[0]
		else:
			if l1l111ll11l1_l1_ in l1lll1l11ll1_l1_: l1lll1l11ll1_l1_.remove(l1l111ll11l1_l1_)
			if l1lll1l11ll1_l1_:
				l1llllll1l11_l1_ = l1lll1l11ll1_l1_[0]
				#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㭠"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡗࡪ࡮࡯ࠤࡹࡸࡹࠡࡶ࡫ࡩࠥࡵࡴࡩࡧࡵࠤࡉࡔࡓ࠻࡝ࠣࠫ㭡")+l1llllll1l11_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡴࡹࡴ࠻࡝ࠣࠫ㭢")+str(host)+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㭣"))
				l1l1ll1l1ll1_l1_ = DNS_RESOLVER(host,l1llllll1l11_l1_)
				if l1l1ll1l1ll1_l1_: host = l1l1ll1l1ll1_l1_[0]
		address = (host,port)
		return l11111l1lll_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1l1l11l11_l1_
	return l11111l1lll_l1_
def l1ll1l1l11_l1_(l11lll1l1ll_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡴࡶࡵࠫ㭤"),l11lll_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ㭥"),(method,url,data,headers))
	if html:
		l11lll1ll1l_l1_(l11lll_l1_ (u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧ㭦"),url,data,headers,source,method)
		return html
	html = l1lllll11l_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ㭧"),(method,url,data,headers),html,l11lll1l1ll_l1_)
	return html
def l1l111l1l1ll_l1_(url):
	l111l111lll_l1_,l111l1l1l1l_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴࠭㭨"))[2],80
	if l11lll_l1_ (u"ࠬࡀࠧ㭩") in l111l111lll_l1_: l111l111lll_l1_,l111l1l1l1l_l1_ = l111l111lll_l1_.split(l11lll_l1_ (u"࠭࠺ࠨ㭪"))
	l111111ll1l_l1_ = l11lll_l1_ (u"ࠧ࠰ࠩ㭫")+l11lll_l1_ (u"ࠨ࠱ࠪ㭬").join(url.split(l11lll_l1_ (u"ࠩ࠲ࠫ㭭"))[3:])
	request = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠠࠨ㭮")+l111111ll1l_l1_+l11lll_l1_ (u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫ㭯")
	#request += l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠼ࠣࡠࡷࡢ࡮ࠨ㭰")
	request += l11lll_l1_ (u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭㭱")+l111l111lll_l1_+l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㭲")
	request += l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭㭳")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l111l111lll_l1_,l111l1l1l1l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11lll_l1_ (u"ࠩࠪ㭴")
	return html
def SERVER(link,type):
	# url:	http://www.l1llll1lll1l_l1_.com
	# host:	www.l1llll1lll1l_l1_.com
	# name:	l1llll1lll1l_l1_
	#server = l11lll_l1_ (u"ࠪ࠳ࠬ㭵").join(link.split(l11lll_l1_ (u"ࠫ࠴࠭㭶"))[:3])
	if l11lll_l1_ (u"ࠬ࠴ࠧ㭷") not in link: return link
	link = link+l11lll_l1_ (u"࠭࠯ࠨ㭸")
	l1l1l1ll111l_l1_,l1l1l1ll1111_l1_ = link.split(l11lll_l1_ (u"ࠧ࠯ࠩ㭹"),1)
	l1l1l1l1llll_l1_,l1l1l1l1lll1_l1_ = l1l1l1ll1111_l1_.split(l11lll_l1_ (u"ࠨ࠱ࠪ㭺"),1)
	server = l1l1l1ll111l_l1_+l11lll_l1_ (u"ࠩ࠱ࠫ㭻")+l1l1l1l1llll_l1_
	if type in [l11lll_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ㭼"),l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㭽")] and l11lll_l1_ (u"ࠬ࠵ࠧ㭾") in server: server = server.rsplit(l11lll_l1_ (u"࠭࠯ࠨ㭿"),1)[1]
	if type==l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㮀") and l11lll_l1_ (u"ࠨ࠰ࠪ㮁") in server:
		l1l1llll1lll_l1_ = server.split(l11lll_l1_ (u"ࠩ࠱ࠫ㮂"))
		length = len(l1l1llll1lll_l1_)
		if length<=2 or l11lll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㮃") in server: l1l1llll1lll_l1_ = l1l1llll1lll_l1_[0]
		elif length>=3: l1l1llll1lll_l1_ = l1l1llll1lll_l1_[1]
		if len(l1l1llll1lll_l1_)>1: server = l1l1llll1lll_l1_
	return server
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࠪ࠳ࠬ࠱ࡵࡳ࡮࠵࠯ࠬ࠵ࠧࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡳ࡫ࡴ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡵ࡭࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡴࡸࡧ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡶࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺࡶ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡼࡹ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡸࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡳࡷ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣࡢ࡯࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡯࡯࡮࡬ࡲࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰࡯࡭ࡻ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡱࡻࡢ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡦࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡳࡸ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲࡮ࡴ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡻࡼࡽ࠮ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡱ࠳࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࠥࠦࠧ㮄")
def l1l11lllll11_l1_(l1111l1111l_l1_):
	l1111l111l1_l1_ = repr(l1111l1111l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㮅"))).replace(l11lll_l1_ (u"ࠨࠧࠣ㮆"),l11lll_l1_ (u"ࠧࠨ㮇"))
	return l1111l111l1_l1_
def l1l111ll1l1_l1_(string):
	#if l11lll_l1_ (u"ࠨ࡞ࡸࠫ㮈") in string:
	#	string = string.decode(l11lll_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㮉"))
	#	l1ll1ll1l1ll_l1_=re.findall(l11lll_l1_ (u"ࡵࠫࡡࡻ࡛࠱࠯࠼ࡅ࠲ࡌ࡝ࠨ㮊"),string)
	#	for unicode in l1ll1ll1l1ll_l1_
	#		char = l1l1111l1lll_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㮋"))
	l1l11l11l1l1_l1_ = l11lll_l1_ (u"ࠬ࠭㮌")
	if kodi_version<19: string = string.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮍"))
	import unicodedata
	for l1l111ll111_l1_ in string:
		if   l1l111ll111_l1_==l11lll_l1_ (u"ࡵࠨฤࠪ㮎"): l111111l11l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳ࠩ㮏")
		elif l1l111ll111_l1_==l11lll_l1_ (u"ࡷࠪวࠬ㮐"): l111111l11l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠶ࠫ㮑")
		elif l1l111ll111_l1_==l11lll_l1_ (u"ࡹࠬสࠧ㮒"): l111111l11l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹࠭㮓")
		elif l1l111ll111_l1_==l11lll_l1_ (u"ࡻࠧฦࠩ㮔"): l111111l11l_l1_ = l11lll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨ㮕")
		elif l1l111ll111_l1_==l11lll_l1_ (u"ࡶࠩษࠫ㮖"): l111111l11l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ࠪ㮗")
		else:
			l1l1111l11ll_l1_ = unicodedata.decomposition(l1l111ll111_l1_)
			if l11lll_l1_ (u"ࠪࠤࠬ㮘") in l1l1111l11ll_l1_: l111111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵࠨ㮙")+l1l1111l11ll_l1_.split(l11lll_l1_ (u"ࠬࠦࠧ㮚"),1)[1]
			else:
				l111111l11l_l1_ = l11lll_l1_ (u"࠭࠰࠱࠲࠳ࠫ㮛")+hex(ord(l1l111ll111_l1_)).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㮜"),l11lll_l1_ (u"ࠨࠩ㮝"))
				l111111l11l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠭㮞")+l111111l11l_l1_[-4:]
			#if ord(l1l111ll111_l1_)<256: l111111l11l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠱ࠩ㮟")+l1l1l1111lll_l1_
			#elif ord(l1l111ll111_l1_)<4096: l111111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵ࠱ࠩ㮠")+l1l1l1111lll_l1_
			#elif l11lll_l1_ (u"ࠬࠦࠧ㮡") in l1l1111l11ll_l1_: l111111l11l_l1_ = l11lll_l1_ (u"࠭࡜࡝ࡷࠪ㮢")+l1l1111l11ll_l1_.split(l11lll_l1_ (u"ࠧࠡࠩ㮣"),1)[1]
			#else: l111111l11l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹࠬ㮤")+l1l1l1111lll_l1_
		l1l11l11l1l1_l1_ += l111111l11l_l1_
	l1l11l11l1l1_l1_ = l1l11l11l1l1_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶ࡄࡅࠪ㮥"),l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠶࠼ࠫ㮦"))
	if kodi_version<19: l1l11l11l1l1_l1_ = l1l11l11l1l1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㮧")).encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㮨"))
	else: l1l11l11l1l1_l1_ = l1l11l11l1l1_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㮩")).decode(l11lll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㮪"))
	return l1l11l11l1l1_l1_
def OPEN_KEYBOARD(header=l11lll_l1_ (u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨ㮫"),default=l11lll_l1_ (u"ࠩࠪ㮬"),l1lllllllll1_l1_=False,source=l11lll_l1_ (u"ࠪࠫ㮭")):
	text = l111l1l1lll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11lll_l1_ (u"ࠫࠥࠦࠧ㮮"),l11lll_l1_ (u"ࠬࠦࠧ㮯")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ㮰"),l11lll_l1_ (u"ࠧࠡࠩ㮱")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ㮲"),l11lll_l1_ (u"ࠩࠣࠫ㮳"))
	if not text and not l1lllllllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㮴"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡥࡤࡲࡨ࡫࡬ࡦࡦ࠽ࠤࠥࠦࠢࠨ㮵")+text+l11lll_l1_ (u"ࠬࠨࠧ㮶"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㮷"),l11lll_l1_ (u"ࠧࠨ㮸"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㮹"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬ㮺"))
		return l11lll_l1_ (u"ࠪࠫ㮻")
	if text not in [l11lll_l1_ (u"ࠫࠬ㮼"),l11lll_l1_ (u"ࠬࠦࠧ㮽")]:
		text = text.strip(l11lll_l1_ (u"࠭ࠠࠨ㮾"))
		text = l1l111ll1l1_l1_(text)
	if source!=l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩ㮿") and l11ll11_l1_(l11lll_l1_ (u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ㯀"),l11lll_l1_ (u"ࠩࠪ㯁"),[text],False):
		LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㯂"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡨࡲࡹࡸࡹࠡࡤ࡯ࡳࡨࡱࡥࡥ࠼ࠣࠤࠥࠨࠧ㯃")+text+l11lll_l1_ (u"ࠬࠨࠧ㯄"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㯅"),l11lll_l1_ (u"ࠧࠨ㯆"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㯇"),l11lll_l1_ (u"ࠩส๊ฯࠦใหสอࠤ่๊ๅสࠢฦ์ࠥืโๆࠢ็๋ࠥ฿ไศไฬࠤอษแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠡ࠰࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ้อ๋ࠠี่ัࠥฮวิฬัำฬ๋่ࠠๅำห้ࠥไๆษอࠫ㯈"))
		return l11lll_l1_ (u"ࠪࠫ㯉")
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㯊"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨ㯋")+text+l11lll_l1_ (u"࠭ࠢࠨ㯌"))
	return text
def l11ll11lll_l1_(l11l11l_l1_,headers={}):
	#if headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㯍")]==l11lll_l1_ (u"ࠨࠩ㯎"): headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㯏")] = l11lll_l1_ (u"ࠪࠤࠬ㯐")
	#l1ll1lll111l_l1_ = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㯑") : l11lll_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠺࠹࠳࠶࠮࠴࠹࠺࠴࠳࠷࠴࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ㯒") }
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡦ࠻࠸࠳ࡳࡹࡤࡦࡱ࠲ࡲ࡫࠯ࡷ࡫ࡧࡩࡴ࠴࡭࠴ࡷ࠻ࠫ㯓")
	#open(l11lll_l1_ (u"ࠧࡔ࠼࡟ࡠࡹ࡫ࡳࡵ࠴࠱ࡱ࠸ࡻ࠸ࠨ㯔"), l11lll_l1_ (u"ࠨࡴࠪ㯕")).read()
	url,params = l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ㯖")
	if l11lll_l1_ (u"ࠪࢀࠬ㯗") in l11l11l_l1_:
		url,params = l11l11l_l1_.split(l11lll_l1_ (u"ࠫࢁ࠭㯘"),1)
		if l11lll_l1_ (u"ࠬࡃࠧ㯙") not in params: url,params = l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㯚")
	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㯛"),url,l11lll_l1_ (u"ࠨࠩ㯜"),headers,l11lll_l1_ (u"ࠩࠪ㯝"),l11lll_l1_ (u"ࠪࠫ㯞"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ㯟"),False,False)
	html = response.content
	if l11lll_l1_ (u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ㯠") not in html: return [l11lll_l1_ (u"࠭࠭࠲ࠩ㯡")],[l11l11l_l1_]
	#	if l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㯢") in list(headers.keys()): del headers[l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㯣")]
	#	else: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㯤")] = l11lll_l1_ (u"ࠪࠫ㯥")
	#	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㯦"),url,l11lll_l1_ (u"ࠬ࠭㯧"),headers,l11lll_l1_ (u"࠭ࠧ㯨"),l11lll_l1_ (u"ࠧࠨ㯩"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠴ࡱࡨࠬ㯪"),False,False)
	#	html = response.content
	if l11lll_l1_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡂࡗࡇࡍࡔ࠭㯫") in html: return [l11lll_l1_ (u"ࠪ࠱࠶࠭㯬")],[l11l11l_l1_]
	if l11lll_l1_ (u"࡙ࠫ࡟ࡐࡆ࠿࡙ࡍࡉࡋࡏࠨ㯭") in html: return [l11lll_l1_ (u"ࠬ࠳࠱ࠨ㯮")],[l11l11l_l1_]
	#if l11lll_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠧ㯯") in html: return [l11lll_l1_ (u"ࠧ࠮࠳ࠪ㯰")],[l11l11l_l1_]
	l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l11_l1_ = [],[],[],[]
	lines = re.findall(l11lll_l1_ (u"ࠨ࡞ࠦࡉ࡝࡚࡙࠭࠯ࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠪ㯱"),html+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㯲"),re.DOTALL)
	if not lines: return [l11lll_l1_ (u"ࠪ࠱࠶࠭㯳")],[l11l11l_l1_]
	for line,link in lines:
		l1l111llllll_l1_,l111l1lllll_l1_,l11l111l_l1_ = {},-1,-1
		title = l11lll_l1_ (u"ࠫࠬ㯴")
		#hostname = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㯵"))
		#title = title+l11lll_l1_ (u"࠭ࠠࠡࠩ㯶")+hostname+l11lll_l1_ (u"ࠧࠡࠢࠪ㯷")
		#line = line.lower()
		items = line.split(l11lll_l1_ (u"ࠨ࠮ࠪ㯸"))
		for item in items:
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㯹"),l11lll_l1_ (u"ࠪࠫ㯺"),item,l11lll_l1_ (u"ࠫࠬ㯻"))
			#if l11lll_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㯼") in item: l1l111llllll_l1_[key] = value
			if l11lll_l1_ (u"࠭࠽ࠨ㯽") in item:
				key,value = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ㯾"),1)
				l1l111llllll_l1_[key.lower()] = value
		if l11lll_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㯿") in line.lower():
			l111l1lllll_l1_ = int(l1l111llllll_l1_[l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㰀")])//1024
			#title += l11lll_l1_ (u"ࠪࡅࡻ࡭ࡂࡘ࠼ࠣࠫ㰁")+str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㰂")
			title += str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ㰃")
		elif l11lll_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㰄") in line.lower():
			l111l1lllll_l1_ = int(l1l111llllll_l1_[l11lll_l1_ (u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㰅")])//1024
			#title += l11lll_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭㰆")+str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㰇")
			title += str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㰈")
		if l11lll_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㰉") in line.lower():
			l11l111l_l1_ = int(l1l111llllll_l1_[l11lll_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㰊")].split(l11lll_l1_ (u"࠭ࡸࠨ㰋"))[1])
			#title += l11lll_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭㰌")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠫ㰍")
			title += str(l11l111l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠬ㰎")
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠥ࠭㰏"))
		if not title: title = l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ㰐")
		if not link.startswith(l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㰑")):
			if link.startswith(l11lll_l1_ (u"࠭࠯࠰ࠩ㰒")): link = url.split(l11lll_l1_ (u"ࠧ࠻ࠩ㰓"),1)[0]+l11lll_l1_ (u"ࠨ࠼ࠪ㰔")+link
			elif link.startswith(l11lll_l1_ (u"ࠩ࠲ࠫ㰕")): link = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ㰖"))+link
			else: link = url.rsplit(l11lll_l1_ (u"ࠫ࠴࠭㰗"),1)[0]+l11lll_l1_ (u"ࠬ࠵ࠧ㰘")+link
		if params!=l11lll_l1_ (u"࠭ࠧ㰙"): link = link+l11lll_l1_ (u"ࠧࡽࠩ㰚")+params
		if l11lll_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ㰛") in list(l1l111llllll_l1_.keys()):
			l1lllll1ll_l1_ = l1l111llllll_l1_[l11lll_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㰜")]
			l1lllll1ll_l1_ = l1lllll1ll_l1_.replace(l11lll_l1_ (u"ࠪࠦࠬ㰝"),l11lll_l1_ (u"ࠫࠬ㰞")).replace(l11lll_l1_ (u"ࠧ࠭ࠢ㰟"),l11lll_l1_ (u"࠭ࠧ㰠")).split(l11lll_l1_ (u"ࠧࠤࠩ㰡"),1)[0]
			l111llll11_l1_ = l11l1llll1_l1_(l1lllll1ll_l1_)
			if l111llll11_l1_: l1lll1lll_l1_ = title+l11lll_l1_ (u"ࠨࠢࠣࠫ㰢")+l111llll11_l1_
			else: l1lll1lll_l1_ = title
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠩࠣࠤࡕࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦࠩ㰣")
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠪࠤࠥ࠭㰤")+SERVER(l1lllll1ll_l1_,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㰥"))
			l1lll1ll_l1_.append(l1lll1lll_l1_)
			l1111_l1_.append(l1lllll1ll_l1_)
			l1lllll1111l_l1_.append(l11l111l_l1_)
			l1l1llll1l11_l1_.append(l111l1lllll_l1_)
		link = link.split(l11lll_l1_ (u"ࠬࠩࠧ㰦"),1)[0]
		l111llll11_l1_ = l11l1llll1_l1_(link)
		if l111llll11_l1_: title = title+l11lll_l1_ (u"࠭ࠠࠡࠩ㰧")+l111llll11_l1_
		title = title+l11lll_l1_ (u"ࠧࠡࠢࠪ㰨")+SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㰩"))
		l1lll1ll_l1_.append(title)
		l1111_l1_.append(link)
		l1lllll1111l_l1_.append(l11l111l_l1_)
		l1l1llll1l11_l1_.append(l111l1lllll_l1_)
	zz = list(zip(l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l11_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll1ll_l1_,l1111_l1_,l1lllll1111l_l1_,l1l1llll1l11_l1_ = list(zip(*zz))
	l1lll1ll_l1_,l1111_l1_ = list(l1lll1ll_l1_),list(l1111_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩࠪ㰪"), l1lll1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪࠫ㰫"), l1111_l1_)
	return l1lll1ll_l1_,l1111_l1_
def DNS_RESOLVER(host,l1l111ll11l1_l1_=l11lll_l1_ (u"ࠫࠬ㰬")):
	if not l1l111ll11l1_l1_: l1l111ll11l1_l1_ = l1lll1l11ll1_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㰭"),l11lll_l1_ (u"࠭ࠧ㰮"),str(l1l111ll11l1_l1_),str(host))
	if host.replace(l11lll_l1_ (u"ࠧ࠯ࠩ㰯"),l11lll_l1_ (u"ࠨࠩ㰰")).isdigit(): return [host]
	import struct,socket
	try:
		l1111l11lll_l1_ = struct.pack(l11lll_l1_ (u"ࠤࡁࡌࠧ㰱"), 12049)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㰲"), 256)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠦࡃࡎࠢ㰳"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡄࡈࠣ㰴"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠨ࠾ࡉࠤ㰵"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠢ࠿ࡊࠥ㰶"), 0)
		if kodi_version>18.99: l1ll1l1l11ll_l1_ = host.split(l11lll_l1_ (u"ࠨ࠰ࠪ㰷"))
		else: l1ll1l1l11ll_l1_ = host.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㰸")).split(l11lll_l1_ (u"ࠪ࠲ࠬ㰹"))
		for part in l1ll1l1l11ll_l1_:
			parts = part.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㰺"))
			l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡈࠢ㰻"), len(part))
			for l1llll111l1l_l1_ in part:
				l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠨࡣࠣ㰼"), l1llll111l1l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㰽")))
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠣࡄࠥ㰾"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠤࡁࡌࠧ㰿"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㱀"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l1111l11lll_l1_), (l1l111ll11l1_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1111lll1ll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧ㱁"), data, 0)
		l1lllll1lll1_l1_ = l1111lll1ll_l1_[3]
		offset = len(host)+18
		l11111lll11_l1_ = []
		for _ in range(l1lllll1lll1_l1_):
			l1llll1lllll_l1_ = offset
			l1ll11l111ll_l1_ = 1
			l1lll11ll1ll_l1_ = False
			while True:
				l1llll111l1l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠧࡄࡂࠣ㱂"), data, l1llll1lllll_l1_)[0]
				if l1llll111l1l_l1_ == 0:
					l1llll1lllll_l1_ += 1
					break
				# l1l1l1l1l1l1_l1_ the field l1l1l111llll_l1_ the first l111l1111l1_l1_ bits l1l1ll1l11ll_l1_ to 1, l1lllllll1ll_l1_ a pointer
				if l1llll111l1l_l1_ >= 192:
					l1lll1llll1l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠨ࠾ࡃࠤ㱃"), data, l1llll1lllll_l1_ + 1)[0]
					# l1l111ll1lll_l1_ the pointer
					l1llll1lllll_l1_ = ((l1llll111l1l_l1_ << 8) + l1lll1llll1l_l1_ - 0xc000) - 1
					l1lll11ll1ll_l1_ = True
				l1llll1lllll_l1_ += 1
				if l1lll11ll1ll_l1_ == False: l1ll11l111ll_l1_ += 1
			if l1lll11ll1ll_l1_ == True: l1ll11l111ll_l1_ += 1
			offset = offset + l1ll11l111ll_l1_
			l11l11l1ll1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠢ࠿ࡊࡋࡍࡍࠨ㱄"), data, offset)
			offset = offset + 10
			l111l1111ll_l1_ = l11l11l1ll1_l1_[0]
			l1lll11lll1l_l1_ = l11l11l1ll1_l1_[3]
			if l111l1111ll_l1_ == 1: # l11111ll11l_l1_ type
				l1llll111ll1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠣࡀࠥ㱅")+l11lll_l1_ (u"ࠤࡅࠦ㱆")*l1lll11lll1l_l1_, data, offset)
				l1l1ll1l1ll1_l1_ = l11lll_l1_ (u"ࠪࠫ㱇")
				for l1llll111l1l_l1_ in l1llll111ll1_l1_: l1l1ll1l1ll1_l1_ += str(l1llll111l1l_l1_) + l11lll_l1_ (u"ࠫ࠳࠭㱈")
				l1l1ll1l1ll1_l1_ = l1l1ll1l1ll1_l1_[0:-1]
				l11111lll11_l1_.append(l1l1ll1l1ll1_l1_)
			if l111l1111ll_l1_ in [1,2,5,6,15,28]: offset = offset + l1lll11lll1l_l1_
	except: l11111lll11_l1_ = []
	if not l11111lll11_l1_: LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㱉"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬ㱊")+host+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㱋"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㱌"),l11lll_l1_ (u"ࠩࠪ㱍"),str(host),str(l11111lll11_l1_))
	return l11111lll11_l1_
def l11ll11_l1_(script_name,url,l11ll1l_l1_,l1ll_l1_=True):
	if l11ll1l_l1_:
		l1111lll11l_l1_ = [l11lll_l1_ (u"ࠪ็ออัࠨ㱎"),l11lll_l1_ (u"ࠫออไ฻ࠩ㱏"),l11lll_l1_ (u"ࠬࡧࡤࡶ࡮ࡷࠫ㱐"),l11lll_l1_ (u"࠭ࡸࡹࠩ㱑"),l11lll_l1_ (u"ࠧࡴࡧࡻࠫ㱒")]
		if script_name!=l11lll_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㱓"):
			l1111lll11l_l1_ += [l11lll_l1_ (u"ࠩࡵ࠾ࠬ㱔"),l11lll_l1_ (u"ࠪࡶ࠲࠭㱕"),l11lll_l1_ (u"ࠫ࠲ࡳࡡࠨ㱖")]
			l1111lll11l_l1_ += [l11lll_l1_ (u"ࠬࡀࡲࠨ㱗"),l11lll_l1_ (u"࠭࠭ࡳࠩ㱘"),l11lll_l1_ (u"ࠧ࡮ࡣ࠰ࠫ㱙")]
		for l1ll1ll1l1_l1_ in l11ll1l_l1_:
			if l11lll_l1_ (u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ㱚") in l1ll1ll1l1_l1_: continue
			if l11lll_l1_ (u"ࠩะ่็ฯࠧ㱛") in l1ll1ll1l1_l1_: continue
			l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.lower()
			if kodi_version<19: l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㱜")).encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㱝"))
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㱞"),l11lll_l1_ (u"࠭ࠧ㱟"),l11lll_l1_ (u"ࠧࠨ㱠"),str(l1ll1ll1l1_l1_))
			#l1lllll1l111_l1_ = re.findall(l11lll_l1_ (u"ࠨࡠࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ㱡"),l1ll1ll1l1_l1_,re.DOTALL)
			#l1lllll1l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࡠ࠰࠮࠱࡜࠸࠰࠽ࡢࢂ࠲࡜࠲࠰࠽ࡢ࠯ࠤࠨ㱢"),l1ll1ll1l1_l1_,re.DOTALL)
			#l1lllll1l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢ࠭࠷࡛࠷࠯࠼ࡡࢁ࠸࡛࠱࠯࠼ࡡ࠮ࡢࠫࠥࠩ㱣"),l1ll1ll1l1_l1_,re.DOTALL)
			#l11111l1l1l_l1_ = any(l1lllll1l111_l1_,l1lllll1l1l1_l1_,l1lllll1l11l_l1_,l1lllll11ll1_l1_)
			l1ll1ll1l1_l1_ = l1ll1ll1l1_l1_.replace(l11lll_l1_ (u"ࠫ࠿࠭㱤"),l11lll_l1_ (u"ࠬ࠭㱥"))
			l11111l1l1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪ㱦"),l1ll1ll1l1_l1_,re.DOTALL)
			l1l1lllll111_l1_ = False
			for digits in l11111l1l1l_l1_:
				if len(digits)==2:
					l1l1lllll111_l1_ = True
					break
			if l11lll_l1_ (u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪ㱧") in l1ll1ll1l1_l1_: continue
			elif l11lll_l1_ (u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩ㱨") in l1ll1ll1l1_l1_: continue
			elif l11lll_l1_ (u"ࠩ฽๎ึࠦๅึ่ไࠫ㱩") in l1ll1ll1l1_l1_: continue
			elif l11l1llll11_l1_(l11lll_l1_ (u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘࡰ࡛ࡊࡖࡆࡘࡈ࡜ࠬ㱪")): continue
			elif l1ll1ll1l1_l1_ in [l11lll_l1_ (u"ࠫࡷ࠭㱫")] or l1l1lllll111_l1_ or any(value in l1ll1ll1l1_l1_ for value in l1111lll11l_l1_):
				LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㱬"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㱭")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㱮"))
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㱯"),l11lll_l1_ (u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ㱰"))
				return True
	return False
def l1l11l11l1ll_l1_(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ㱱"),l11l1l1l1ll_l1_=l11lll_l1_ (u"ࠫࠬ㱲")):
	global l1l111l1111_l1_
	import threading
	l11l1lll1l1_l1_ = threading.Thread(target=l1lllll11l1l_l1_,args=(l11l1l1_l1_,l1l1ll11_l1_,l11l1l1l1ll_l1_))
	l11l1lll1l1_l1_.start()
	l11l1lll1l1_l1_.join()
	return l1l111l1111_l1_
def PLAY_VIDEO(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭㱳"),l11l1l1l1ll_l1_=l11lll_l1_ (u"࠭ࠧ㱴")):
	global l1l111l1111_l1_
	if not l11l1l1l1ll_l1_: l11l1l1l1ll_l1_ = l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㱵")
	l1l111l1111_l1_,l111l11111l_l1_,httpd = l11lll_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ㱶"),l11lll_l1_ (u"ࠩࠪ㱷"),l11lll_l1_ (u"ࠪࠫ㱸")
	if len(l11l1l1_l1_)==3:
		url,l1ll1111ll11_l1_,httpd = l11l1l1_l1_
		if l1ll1111ll11_l1_: l111l11111l_l1_ = l11lll_l1_ (u"ࠫࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼ࠣ࡟ࠥ࠭㱹")+l1ll1111ll11_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㱺")
	else: url,l1ll1111ll11_l1_,httpd = l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ㱻"),l11lll_l1_ (u"ࠧࠨ㱼")
	#url = l111l_l1_(url)		# cause l1l1111ll11l_l1_ for l1ll1llll_l1_ l1llll1l1_l1_ l1111llllll_l1_ l1ll111l1111_l1_
	url = url.replace(l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ㱽"),l11lll_l1_ (u"ࠩࠣࠫ㱾"))	# needed for l1l111lll11l_l1_
	l111llll11_l1_ = l11l1llll1_l1_(url,l1l1ll11_l1_)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ㱿"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ㲀")]:
		if l1l1ll11_l1_!=l11lll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㲁"): url = url.replace(l11lll_l1_ (u"࠭ࠠࠨ㲂"),l11lll_l1_ (u"ࠧࠦ࠴࠳ࠫ㲃"))
		LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㲄"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㲅")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㲆")+l111l11111l_l1_)
		if l111llll11_l1_==l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㲇") and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ㲈"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㲉")]:
			headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㲊"):l11lll_l1_ (u"ࠨࠩ㲋")}
			l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(url,headers)
			count = len(l1111_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪ㲌")+str(count)+l11lll_l1_ (u"ࠪࠤ๊๊แࠪࠩ㲍"), l1lll1ll_l1_)
				if l1l_l1_ == -1:
					DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬื฾๏๊ࠧ㲎"),l11lll_l1_ (u"ࠬ࠭㲏"))
					return l1l111l1111_l1_
			else: l1l_l1_ = 0
			url = l1111_l1_[l1l_l1_]
			if l1lll1ll_l1_[0]!=l11lll_l1_ (u"࠭࠭࠲ࠩ㲐"):
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㲑"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡲࡥࡤࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡩࡰࡰ࠽ࠤࡠࠦࠧ㲒")+l1lll1ll_l1_[l1l_l1_]+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㲓")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㲔"))
		#url = url+l11lll_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠲࠺࠹࠴࠵࠶࠰ࠨ㲕")
		#url = url+l11lll_l1_ (u"ࠬࢂࡄࡏࡖࡀ࠵ࠫࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫࠽ࡦࡰ࠰࡙ࡘ࠲ࡥ࡯࠽ࡴࡁ࠵࠴࠵ࠧࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࡀ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠩࡅࡨࡩࡥࡱࡶࡀ࠮࠴࠰ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫࡐ࡮ࡴࡵࡹ࠽ࠣࡅࡳࡪࡲࡰ࡫ࡧࠤ࠼࠴࠰࠼ࠢࡖࡑ࠲ࡍ࠸࠺࠴ࡄࠤࡇࡻࡩ࡭ࡦ࠲ࡒࡗࡊ࠹࠱ࡏ࠾ࠤࡼࡼࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥ࡜ࡥࡳࡵ࡬ࡳࡳ࠵࠴࠯࠲ࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠺࠼࠴࠰࠯࠵࠶࠽࠻࠴࠸࠸ࠢࡐࡳࡧ࡯࡬ࡦࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ㲖")
		if l11lll_l1_ (u"࠭࠯ࡪࡨ࡬ࡰࡲ࠵ࠧ㲗") in url: url = url+l11lll_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㲘")
		elif l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㲙") in url.lower() and l11lll_l1_ (u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩ㲚") not in url and l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ㲛") not in url:
			if l11lll_l1_ (u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࠩ㲜") not in url and l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ㲝") in url.lower():
				if l11lll_l1_ (u"࠭ࡼࠨ㲞") not in url: url = url+l11lll_l1_ (u"ࠧࡽࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫ㲟")
				else: url = url+l11lll_l1_ (u"ࠨࠨࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㲠")
			if l11lll_l1_ (u"ࠩࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹ࠭㲡") not in url.lower() and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ㲢"),l11lll_l1_ (u"ࠫࡒ࠹ࡕࠨ㲣")]:
				if l11lll_l1_ (u"ࠬࢂࠧ㲤") not in url: url = url+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭㲥")
				else: url = url+l11lll_l1_ (u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㲦")
		#url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ㲧"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ㲨"))
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ㲩"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㲪")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㲫"))
	l11l1ll1111_l1_ = xbmcgui.ListItem()
	#l11l1ll1111_l1_ = xbmcgui.ListItem(l11lll_l1_ (u"࠭ࡴࡦࡵࡷࠫ㲬"))
	l11l1l1l1ll_l1_,l11ll1l11ll_l1_,l11lll11ll1_l1_,l11l1ll11ll_l1_,l11lll1llll_l1_,l11l1l1ll11_l1_,l11ll1l11l1_l1_,l11ll1l1111_l1_,l11lll11111_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㲭"),l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠭㲮")]:
		if kodi_version<19: l1l11l1lll1l_l1_ = l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࡡࡥࡦࡲࡲࠬ㲯")
		else: l1l11l1lll1l_l1_ = l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠨ㲰")
		#l11l1ll1111_l1_ = xbmcgui.ListItem(path=url)
		l11l1ll1111_l1_.setProperty(l1l11l1lll1l_l1_, l11lll_l1_ (u"ࠫࠬ㲱"))
		l11l1ll1111_l1_.setMimeType(l11lll_l1_ (u"ࠬࡳࡩ࡮ࡧ࠲ࡼ࠲ࡺࡹࡱࡧࠪ㲲"))
		if kodi_version<20: l11l1ll1111_l1_.setInfo(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㲳"),{l11lll_l1_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ㲴"):l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ㲵")})
		else:
			l1l11l1l1ll1_l1_ = l11l1ll1111_l1_.getVideoInfoTag()
			l1l11l1l1ll1_l1_.setMediaType(l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㲶"))
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡯ࡣࡰࡰࠪ㲷"))
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㲸"),l11lll_l1_ (u"ࠬࡋࡍࡂࡆ࠽࠾࠿ࡀ࠺ࠡࠩ㲹")+l11l_l1_)
		#l11l1ll1111_l1_.setArt({l11lll_l1_ (u"࠭ࡩࡤࡱࡱࠫ㲺"):l11l_l1_,l11lll_l1_ (u"ࠧࡵࡪࡸࡱࡧ࠭㲻"):l11l_l1_,l11lll_l1_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨ㲼"):l11l_l1_})
		l11l1ll1111_l1_.setArt({l11lll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢࠨ㲽"):l11lll1llll_l1_,l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪ㲾"):l11lll1llll_l1_,l11lll_l1_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫ㲿"):l11lll1llll_l1_,l11lll_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ㳀"):l11lll1llll_l1_,l11lll_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨ㳁"):l11lll1llll_l1_,l11lll_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪ㳂"):l11lll1llll_l1_,l11lll_l1_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ㳃"):l11lll1llll_l1_,l11lll_l1_ (u"ࠩ࡬ࡧࡴࡴࠧ㳄"):l11lll1llll_l1_})
		#l11l1ll1111_l1_.setInfo(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㳅"),{l11lll_l1_ (u"࡙ࠫ࡯ࡴ࡭ࡧࠪ㳆"):name})
		#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭㳇"))
		#name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ㳈"))
		# when set to l11lll_l1_ (u"ࠢࡇࡣ࡯ࡷࡪࠨ㳉") it l111l1l1l11_l1_ l1l1ll11l1ll_l1_ l1ll11l1ll11_l1_ and l1l1ll11l111_l1_ l111111lll1_l1_ l1l111lll1ll_l1_ l1l1llll1l_l1_
		if l111llll11_l1_ in [l11lll_l1_ (u"ࠨ࠰ࡰࡴࡩ࠭㳊"),l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㳋")]: l11l1ll1111_l1_.setContentLookup(True)
		else: l11l1ll1111_l1_.setContentLookup(False)
		#if l111llll11_l1_ in [l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㳌")]: l11l1ll1111_l1_.setContentLookup(False)
		if l11lll_l1_ (u"ࠫࡷࡺ࡭ࡱࠩ㳍") in url:
			import l11ll1ll1l1_l1_
			l11ll1ll1l1_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㳎"),False)
		elif l111llll11_l1_==l11lll_l1_ (u"࠭࠮࡮ࡲࡧࠫ㳏") or l11lll_l1_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ㳐") in url:
			import l11ll1ll1l1_l1_
			l11ll1ll1l1_l1_.l111ll1l11l_l1_(l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㳑"),False)
			l11l1ll1111_l1_.setProperty(l1l11l1lll1l_l1_,l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㳒"))
			l11l1ll1111_l1_.setProperty(l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ㳓"),l11lll_l1_ (u"ࠫࡲࡶࡤࠨ㳔"))
			#l11l1ll1111_l1_.setMimeType(l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡨࡦࡹࡨࠬࡺࡰࡰࠬ㳕"))
			#l11l1ll1111_l1_.setContentLookup(False)
		if l1ll1111ll11_l1_:
			l11l1ll1111_l1_.setSubtitles([l1ll1111ll11_l1_])
			#xbmc.log(LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࡇࡤࡥࡧࡧࠤࡸࡻࡢࡵ࡫ࡷࡰࡪࠦࡴࡰࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿ࡡࠧ㳖")+l1ll1111ll11_l1_+l11lll_l1_ (u"ࠧ࡞ࠩ㳗"), level=xbmc.LOGNOTICE)
	if l11l1l1l1ll_l1_==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㳘") and l1l1ll11_l1_==l11lll_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㳙"):
		l1l111l1111_l1_ = l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㳚")
		l1l1ll11_l1_ = l11lll_l1_ (u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫ㳛")
	elif l11l1l1l1ll_l1_==l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㳜") and l11ll1l1111_l1_.startswith(l11lll_l1_ (u"࠭࠶ࠨ㳝")):
		l1l111l1111_l1_ = l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㳞")
		l1l1ll11_l1_ = l1l1ll11_l1_+l11lll_l1_ (u"ࠨࡡࡇࡐࠬ㳟")
	# l11l1ll1l11_l1_ l1l11111lll_l1_
	#	l11ll1l1ll1_l1_ = l11lll1l11l_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11llll_l1_ with xbmc.sleep(step*1000)
	if l1l111l1111_l1_!=l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㳠"): l11lll1lll1_l1_()
	l11ll1l1ll1_l1_ = l11lll1l11l_l1_()
	if l11ll1l1ll1_l1_.status:
		l1l111l1111_l1_ == l11lll_l1_ (u"ࠪࠫ㳡")
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㳢"),l11lll_l1_ (u"ࠬ࠭㳣"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㳤"),l11lll_l1_ (u"ࠧๅไาࠤ็อๅࠡษ็้อืๅอࠢหษ๏่วโࠢอุ฿๐ไ๊ࠡอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠥ็๊้ࠡำหࠥอไอ้สึࠬ㳥"))
	elif l11l1l1l1ll_l1_==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㳦") and not l11ll1l1111_l1_.startswith(l11lll_l1_ (u"ࠩ࠹ࠫ㳧")):
		#title = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡩࡵ࡮ࡨࠫ㳨"))
		#l11l1ll1111_l1_.setInfo(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㳩"),{l11lll_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ㳪"): 3600})
		#xbmcplugin.setContent(addon_handle,l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭㳫"))
		#l11l1ll1111_l1_.setInfo(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㳬"),{l11lll_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ㳭"):l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ㳮")})
		#l11l1ll1111_l1_.setProperty(l11lll_l1_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧ㳯"),l11lll_l1_ (u"ࠫࡹࡸࡵࡦࠩ㳰"))
		#l11l1ll1111_l1_.setInfo(type=l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㳱"),l1l11l11lll1_l1_={l11lll_l1_ (u"ࠨࡔࡪࡶ࡯ࡩࠧ㳲"):l11lll_l1_ (u"ࠧࡩࡧ࡯ࡰࡴࠦࡷࡰࡴ࡯ࡨࠬ㳳")})
		l11l1ll1111_l1_.setPath(url)
		LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㳴"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㳵")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㳶"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll1111_l1_)
	elif l11l1l1l1ll_l1_==l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㳷"):
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㳸"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㳹")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㳺"))
		l11ll1l1ll1_l1_.play(url,l11l1ll1111_l1_)
		#xbmc.Player().play(url,l11l1ll1111_l1_)
	succeeded = False
	if l1l111l1111_l1_==l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㳻"):
		import l11l111lll_l1_
		succeeded = l11l111lll_l1_.l11l11ll1l_l1_(url,l111llll11_l1_,l1l1ll11_l1_)
		if succeeded: l11lll1lll1_l1_()
	else:
		timeout,l1l111l1111_l1_ = 10,l11lll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ㳼")
		for l11ll111l1_l1_ in range(timeout):
			# l11l1ll1l11_l1_ l1l11111lll_l1_
			#	if using time.sleep() l11l1lll11l_l1_ of xbmc.sleep() l1l111111ll_l1_ the l11ll1111l1_l1_ status
			#	l11lll_l1_ (u"ࠥࡱࡾࡶ࡬ࡢࡻࡨࡶ࠳ࡹࡴࡢࡶࡸࡷࠧ㳽") will stop l11ll1l1lll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l1111_l1_ = l11ll1l1ll1_l1_.status
			if l1l111l1111_l1_==l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㳾"):
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬอไโ์า๎ํฺ๊ࠦ็็ࠫ㳿"),l11lll_l1_ (u"࠭ࠧ㴀"),time=500)
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㴁"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࡶࡪࡦࡨࡳࠥ࡯ࡳࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㴂")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㴃")+l111l11111l_l1_)
				break
			elif l1l111l1111_l1_==l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㴄"):
				LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㴅"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㴆")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㴇")+l111l11111l_l1_)
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠩ㴈"),l11lll_l1_ (u"ࠨࠩ㴉"),time=500)
				break
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩฯหึ๐ࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧ㴊"),l11lll_l1_ (u"ࠪฬฬ่๊ࠡࠩ㴋")+str(timeout-l11ll111l1_l1_)+l11lll_l1_ (u"ࠫࠥัว็์ฬࠫ㴌"))
			if l1l111l1111_l1_:
				LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㴍"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㴎")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㴏"))
				break
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ㴐"),l11lll_l1_ (u"ࠩࠪ㴑"),time=500)
			LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㴒"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴࠡࡷࡱ࡯ࡳࡵࡷ࡯ࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㴓")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㴔")+l111l11111l_l1_)
			l1l111l1111_l1_ = l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㴕")
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡪࡷࡸࡵࡪ࠺ࠎࠌࠌࠍࠨࠦࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ࠼࠸࠹࠵࠻࠵࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩࠓࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡦࡰ࡮ࡩ࡫ࠡࡱ࡮ࠤࡹࡵࠠࡴࡪࡸࡸࡩࡵࡷ࡯ࠢࡷ࡬ࡪࠦࡨࡵࡶࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ࠮ࠓࠊࠊࠋࠦ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡓࡕ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠻ࡴࡩࠩࠬࠑࠏࠏࠉࡵ࡫ࡰࡩ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠯ࠍࠋࠋࠌ࡬ࡹࡺࡰࡥ࠰ࡶ࡬ࡺࡺࡤࡰࡹࡱࠬ࠮ࠓࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࡨࡵࡶࡳࠤࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠬ࠲ࠧࠨࠫࠐࠎࠎࠨࠢࠣ㴖")
	if l1l111l1111_l1_ in [l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㴗"),l11lll_l1_ (u"ࠩࡳࡰࡦࡿ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㴘")] or succeeded: response = l1l1111l1ll_l1_(l1l1ll11_l1_)
	else: l11ll1l1ll1_l1_.stop()
	#if l1l111l1111_l1_ in [l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㴙"),l11lll_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㴚"),l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㴛"),l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㴜"),l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㴝")]: l111l11l11l_l1_(l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪ㴞"),False)
	#l111l11l11l_l1_(l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠴ࡴࡧࠫ㴟"))
	#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ㴠") in url and l1l111l1111_l1_ in [l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㴡"),l11lll_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㴢")]:
	#	l11ll1l1lll_l1_ = HTTPS(False)
	#	if not l11ll1l1lll_l1_:
	#		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㴣"),l11lll_l1_ (u"ࠧࠨ㴤"),l11lll_l1_ (u"ࠨษ็หฯ฻วๅุ่ࠢๆืࠧ㴥"),l11lll_l1_ (u"ุ่่๊ࠩษࠡ࠰࠱࠲ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣ๎าะวอࠢส่๎ࠦวหืส่๋ࠥิโำࠣࠬึฮืࠡ็ืๅึ࠯้ࠠๆๆ๊๊ࠥไฤีไࠤฬ๊วหืส่ࠥอไๆึไี๊ࠥวࠡ์฼ู้้ࠦๅ๋ࠣะ์อาไࠩ㴦"))
	#		return l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㴧")
	#sys.exit()
	if 0 and l1l111l1111_l1_==l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㴨"):
		LOG_THIS(l11lll_l1_ (u"ࠬ࠭㴩"),l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ㴪")+l11lll_l1_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ㴫"))
		while True:
			l1l111l1111_l1_ = l11ll1l1ll1_l1_.status
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㴬"),l11lll_l1_ (u"ࠩࡓࡐࡆ࡟࡟ࡔࡖࡄࡘ࡚࡙࠺࠻ࠢࠣࠤࠬ㴭")+l1l111l1111_l1_)
			if l1l111l1111_l1_!=l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ㴮"): break
			xbmc.sleep(1000)
		LOG_THIS(l11lll_l1_ (u"ࠫࠬ㴯"),l11lll_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡗ࡙ࡇࡔࡖࡕ࠽࠾ࠥࠦࠠࠨ㴰")+l11lll_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ㴱"))
	return l1l111l1111_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1llll1ll1_l1_ = args[0]
		l11l1ll1_l1_ = args[1]
		if not l1l1llll1ll1_l1_: l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㴲")
		if not l11l1ll1_l1_: l11l1ll1_l1_ = l11lll_l1_ (u"ࠨษึฮ๊ืวาࠩ㴳")
		header = args[2]
		text = l11lll_l1_ (u"ࠩ࡟ࡲࠬ㴴").join(args[3:])
	else: l1l1llll1ll1_l1_,l11l1ll1_l1_,header,text = l11lll_l1_ (u"ࠪࠫ㴵"),l11lll_l1_ (u"ࠫࡔࡑࠧ㴶"),l11lll_l1_ (u"ࠬ࠭㴷"),l11lll_l1_ (u"࠭ࠧ㴸")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1ll1_l1_,l11lll_l1_ (u"ࠧࠨ㴹"),l11l1ll1_l1_,l11lll_l1_ (u"ࠨࠩ㴺"),header,text,**kwargs)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1llll1ll1_l1_ = args[0]
	l1ll11lll111_l1_ = args[1]
	l1ll111lllll_l1_ = args[2]
	if l1ll111lllll_l1_ or l1ll11lll111_l1_: l1ll11ll11ll_l1_ = True
	else: l1ll11ll11ll_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1llll1ll1_l1_: l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㴻")
	if not l1ll11lll111_l1_: l1ll11lll111_l1_ = l11lll_l1_ (u"ࠪ็้อࠧ㴼")
	if not l1ll111lllll_l1_: l1ll111lllll_l1_ = l11lll_l1_ (u"๋ࠫ฿ๅࠨ㴽")
	if len(args)>=6: text += l11lll_l1_ (u"ࠬࡢ࡮ࠨ㴾")+args[5]
	if len(args)>=7: text += l11lll_l1_ (u"࠭࡜࡯ࠩ㴿")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1ll1_l1_,l1ll11lll111_l1_,l11lll_l1_ (u"ࠧࠨ㵀"),l1ll111lllll_l1_,header,text,**kwargs)
	if choice==-1 and l1ll11ll11ll_l1_: choice = -1
	elif choice==-1 and not l1ll11ll11ll_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1lll11l11l1_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11lll_l1_ (u"ࠨࡶ࡬ࡱࡪ࠭㵁") in list(kwargs.keys()): l11l1l111ll_l1_ = kwargs[l11lll_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ㵂")]
	else: l11l1l111ll_l1_ = 1000
	if len(args)>2 and l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ㵃") not in args[2]: l1llllll111_l1_ = args[2]
	else: l1llllll111_l1_ = l11lll_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠪ㵄")
	l1l11l1l1l1l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬ㵅"),l11lll1l1l1_l1_,l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㵆"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㵇"))
	l1ll1lllll1l_l1_,l1111111ll1_l1_ = l1l11ll11111_l1_(l11lll_l1_ (u"ࠨࠩ㵈"),l11lll_l1_ (u"ࠩࠪ㵉"),l11lll_l1_ (u"ࠪࠫ㵊"),header,text,l1llllll111_l1_,l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㵋"),720,False)
	#time.sleep(0.200)
	l1l11l1l1l1l_l1_.show()
	if l1llllll111_l1_==l11lll_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㵌"):
		l1l11l1l1l1l_l1_.getControl(9040).setHeight(215)
		l1l11l1l1l1l_l1_.getControl(9040).setPosition(55,-80)
		l1l11l1l1l1l_l1_.getControl(9050).setPosition(120,-60)
		l1l11l1l1l1l_l1_.getControl(400).setPosition(90,-35)
	l1l11l1l1l1l_l1_.getControl(401).setVisible(False)
	l1l11l1l1l1l_l1_.getControl(402).setVisible(False)
	l1l11l1l1l1l_l1_.getControl(9050).setImage(l1ll1lllll1l_l1_)
	l1l11l1l1l1l_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	import threading
	l11l11l1lll_l1_ = threading.Thread(target=l1l1111l1l1l_l1_,args=(l1l11l1l1l1l_l1_,l1ll1lllll1l_l1_,l11l1l111ll_l1_))
	l11l11l1lll_l1_.start()
	#l11l11l1lll_l1_.join()
	return
	#return xbmcgui.Dialog().l1l11ll1ll1l_l1_(l1l1lll1l11l_l1_=False,*args,**kwargs)
def l1l1111l1l1l_l1_(l1l11l1l1l1l_l1_,l1ll1lllll1l_l1_,l11l1l111ll_l1_):
	time.sleep(l11l1l111ll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1ll1lllll1l_l1_):
		try: os.remove(l1ll1lllll1l_l1_)
		except: pass
	#del l1l11l1l1l1l_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,l1llllll111_l1_,l1l1llll1ll1_l1_ = l11lll_l1_ (u"࠭ࠧ㵍"),l11lll_l1_ (u"ࠧࠨ㵎"),l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㵏"),l11lll_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㵐")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: l1llllll111_l1_ = args[2]
	if len(args)>=4: l1l1llll1ll1_l1_ = args[3]
	return l11ll1l1l1_l1_(l1l1llll1ll1_l1_,header,text,l1llllll111_l1_)
	#return xbmcgui.Dialog().l1ll1l111ll1_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1l1ll1l1l_l1_(*args,**kwargs)
def l11l1l11l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111l1l1lll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text,l1llllll111_l1_,l1l1llll1ll1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l11l1l1l1l_l1_ = l1ll11l11111_l1_(l11lll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㵑"),l11lll1l1l1_l1_,l11lll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ㵒"),l11lll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ㵓"))
	#l1l11l1l1l1l_l1_.l1111111l1l_l1_(l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text,l1llllll111_l1_,l1l1llll1ll1_l1_,855)
	#return l1l11l1l1l1l_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠿࠲࠽ࠤࡩ࡯ࡡ࡭ࡱࡪ࠲ࡸࡺࡡࡳࡶࡅࡹࡹࡺ࡯࡯ࡵࡗ࡭ࡲ࡫࡯ࡶࡶࠫࡸ࡮ࡳࡥࡰࡷࡷ࠭ࠒࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡥ࡯ࡣࡥࡰࡪࡈࡵࡵࡶࡲࡲࡸ࠮ࠩࠎࠌࠌࠧࡩ࡯ࡡ࡭ࡱࡪ࠲ࡺࡶࡤࡢࡶࡨࡔࡷࡵࡧࡳࡧࡶࡷࡇࡧࡲࠩ࠹࠳࠭ࠎࠩࠠ࠸࠲ࠨࠑࠏࠏࡤࡪࡣ࡯ࡳ࡬࠴ࡤࡰࡏࡲࡨࡦࡲࠨࠪࠏࠍࠍࡨ࡮࡯ࡪࡥࡨࠤࡂࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡣࡩࡱ࡬ࡧࡪࡏࡄࠎࠌࠌࡸࡷࡿ࠺ࠡࡱࡶ࠲ࡷ࡫࡭ࡰࡸࡨࠬࡩ࡯ࡡ࡭ࡱࡪ࠲࡮ࡳࡡࡨࡧࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠓࠊࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠍࠋࠋࠦࡨࡪࡲࠠࡥ࡫ࡤࡰࡴ࡭ࠍࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡦ࡬ࡴ࡯ࡣࡦࠏࠍࠍࠧࠨࠢ㵔")
def l1ll11l11_l1_(l1ll111ll1l1_l1_):
	if kodi_version>17.99: l1l11l1l1l1l_l1_ = l11lll_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬ㵕")
	else: l1l11l1l1l1l_l1_ = l11lll_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬ㵖")
	l1ll111ll1l1_l1_ = l1ll111ll1l1_l1_.lower()
	if l1ll111ll1l1_l1_==l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㵗"): xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬ㵘")+l1l11l1l1l1l_l1_+l11lll_l1_ (u"ࠫ࠮࠭㵙"))
	elif l1ll111ll1l1_l1_==l11lll_l1_ (u"ࠬࡹࡴࡰࡲࠪ㵚"): xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭࠭㵛")+l1l11l1l1l1l_l1_+l11lll_l1_ (u"ࠧࠪࠩ㵜"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l1llll1ll1_l1_,l1llll1l11l1_l1_=l11lll_l1_ (u"ࠨࠩ㵝"),l1l1l111l1l1_l1_=l11lll_l1_ (u"ࠩࠪ㵞"),l1llll1l1lll_l1_=l11lll_l1_ (u"ࠪࠫ㵟"),header=l11lll_l1_ (u"ࠫࠬ㵠"),text=l11lll_l1_ (u"ࠬ࠭㵡"),l1llllll111_l1_=l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ㵢"),l1ll11ll1111_l1_=0,l1l1ll11l11l_l1_=0):
	if not l1l1llll1ll1_l1_: l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㵣")
	l1l11l1l1l1l_l1_ = l1ll11l11111_l1_(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㵤"),l11lll1l1l1_l1_,l11lll_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㵥"),l11lll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㵦"))
	l1l11l1l1l1l_l1_.l1111111l1l_l1_(l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text,l1llllll111_l1_,l1l1llll1ll1_l1_,900,l1ll11ll1111_l1_,l1l1ll11l11l_l1_)
	if l1ll11ll1111_l1_>0: l1l11l1l1l1l_l1_.l11l11l1111_l1_()
	if l1l1ll11l11l_l1_>0: l1l11l1l1l1l_l1_.l111llll111_l1_()
	if l1ll11ll1111_l1_==0 and l1l1ll11l11l_l1_==0: l1l11l1l1l1l_l1_.enableButtons()
	l1l11l1l1l1l_l1_.doModal()
	choice = l1l11l1l1l1l_l1_.l11l11l1l1l_l1_
	return choice
def l11ll1l1l1_l1_(l1l1llll1ll1_l1_,header,text,l1llllll111_l1_=l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㵧")):
	if not l1l1llll1ll1_l1_: l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ㵨")
	#text = l11lll_l1_ (u"࠭࡜࡯ࠩ㵩").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11lll_l1_ (u"ࠧࠨ㵪")
	l1l11l1l1l1l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡕࡧࡻࡸ࡛࡯ࡥࡸࡧࡵࡊࡺࡲ࡬ࡔࡥࡵࡩࡪࡴ࠮ࡹ࡯࡯ࠫ㵫"),l11lll1l1l1_l1_,l11lll_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㵬"),l11lll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㵭"))
	l1ll1lllll1l_l1_,l1111111ll1_l1_ = l1l11ll11111_l1_(l11lll_l1_ (u"ࠫࠬ㵮"),l11lll_l1_ (u"ࠬ࠭㵯"),l11lll_l1_ (u"࠭ࠧ㵰"),header,text,l1llllll111_l1_,l1l1llll1ll1_l1_,1270,False)
	l1l11l1l1l1l_l1_.show()
	#time.sleep(1)
	#l1l11l1l1l1l_l1_.getControl(9050).l1l11l111lll_l1_(1270-60)
	l1l11l1l1l1l_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	l1l11l1l1l1l_l1_.getControl(9050).setImage(l1ll1lllll1l_l1_)
	result = l1l11l1l1l1l_l1_.doModal()
	#del l1l11l1l1l1l_l1_
	try: os.remove(l1ll1lllll1l_l1_)
	except: pass
	return result
def l1l11111l_l1_(l1l1l1llll11_l1_=True):
	if l1l1l1llll11_l1_:
		l111llll1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡴࡶࡵࠫ㵱"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㵲"),l11lll_l1_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ㵳"))
		if l111llll1l_l1_: return l111llll1l_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㵴"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࠤࡺࡹࡥࡳࡣࡪࡩࡳࡺ࠺ࠡࠩ㵵")+results)
	# l11l11l1l11_l1_ and l11111ll11_l1_ common user l1ll1111111l_l1_ (l111l111l11_l1_ l11l11l111l_l1_)
	text = l11lll_l1_ (u"ࠬ࠭㵶")
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵࡧࡦ࡬ࡧࡲ࡯ࡨ࠰ࡺ࡭ࡱࡲࡳࡩࡱࡸࡷࡪ࠴ࡣࡰ࡯࠲࠶࠵࠷࠲࠰࠲࠴࠳࠵࠹࠯࡮ࡱࡶࡸ࠲ࡩ࡯࡮࡯ࡲࡲ࠲ࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵࡵ࠲ࠫ㵷")
	headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㵸"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㵹"),url,l11lll_l1_ (u"ࠩࠪ㵺"),headers,l11lll_l1_ (u"ࠪࠫ㵻"),l11lll_l1_ (u"ࠫࠬ㵼"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭㵽"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11lll_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧ㵾"))
		if count>80:
			text = re.findall(l11lll_l1_ (u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㵿"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㶀"),l11lll_l1_ (u"ࠩࠪ㶁"),l11lll_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠭㶂"),l11lll_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡘࡗࡊࡘ࠭ࡂࡉࡈࡒ࡙࡙ࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࠫ㶃"))
	if not text:
		l1ll1l1l11l1_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㶄"),l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧ㶅"))
		text = open(l1ll1l1l11l1_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ㶆")).read()
		if kodi_version>18.99: text = text.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㶇"))
		text = text.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ㶈"),l11lll_l1_ (u"ࠪࠫ㶉"))
	l1ll1ll1ll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡓ࡯ࡻ࡫࡯ࡰࡦ࠴ࠪࡀࠫ࡟ࡲࠬ㶊"),text,re.DOTALL)
	l111ll11l1l_l1_ = []
	for line in l1ll1ll1ll11_l1_:
		l1ll111l1lll_l1_ = line.lower()
		if l11lll_l1_ (u"ࠬࡧ࡮ࡥࡴࡲ࡭ࡩ࠭㶋") in l1ll111l1lll_l1_: continue
		if l11lll_l1_ (u"࠭ࡵࡣࡷࡱࡸࡺ࠭㶌") in l1ll111l1lll_l1_: continue
		if l11lll_l1_ (u"ࠧࡪࡲ࡫ࡳࡳ࡫ࠧ㶍") in l1ll111l1lll_l1_: continue
		if l11lll_l1_ (u"ࠨࡥࡵࡳࡸ࠭㶎") in l1ll111l1lll_l1_: continue
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡲࡲࠧ㶏") in l1ll111l1lll_l1_: continue
		l111ll11l1l_l1_.append(line)
	l111llll1l_l1_ = random.sample(l111ll11l1l_l1_,1)
	l111llll1l_l1_ = l111llll1l_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㶐"),l11lll_l1_ (u"ࠫࠬ㶑"),str(len(l1ll1ll1ll11_l1_)),l111llll1l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㶒"),l11lll_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㶓"),l111llll1l_l1_,REGULAR_CACHE)
	return l111llll1l_l1_
def l11l11l11l1_l1_(l1lll1lllll1_l1_):
	#if l11lll_l1_ (u"ࠧࡧࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠬ㶔") in str(error).lower(): return
	#l1lll1lllll1_l1_ = traceback.format_exc()
	sys.stderr.write(l1lll1lllll1_l1_)
	lines = l1lll1lllll1_l1_.splitlines()
	error = lines[-1]
	l1lllll11111_l1_ = open(l1ll1l11ll11_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㶕")).read()
	if kodi_version>18.99: l1lllll11111_l1_ = l1lllll11111_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㶖"))
	l1lllll11111_l1_ = l1lllll11111_l1_[-8000:]
	sep = l11lll_l1_ (u"ࠪࡁࠬ㶗")*100
	if sep in l1lllll11111_l1_: l1lllll11111_l1_ = l1lllll11111_l1_.rsplit(sep,1)[1]
	if error in l1lllll11111_l1_: l1lllll11111_l1_ = l1lllll11111_l1_.rsplit(error,1)[0]
	#l11ll1l1l1_l1_(l11lll_l1_ (u"ࠫࠬ㶘"),error,l1lllll11111_l1_)
	#l11llll1lll_l1_ = l1lllll11111_l1_.splitlines()
	#for line in reversed(l11llll1lll_l1_):
	#	if l11lll_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳࠨ㶙") in line or l11lll_l1_ (u"࠭ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠭㶚") in line: continue
	#	if l11lll_l1_ (u"ࠧࡎࡱࡧࡩ࠿࡛ࠦࠨ㶛") not in line: continue
	l1l1l1l1111l_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧ㶜"),l1lllll11111_l1_,re.DOTALL)
	for typ,source in reversed(l1l1l1l1111l_l1_):
		#if l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࠫ㶝") in source: continue
		#if l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࠭㶞") in source: continue
		if source: break
	else: source = l11lll_l1_ (u"ࠫࡓࡕࡔࠡࡕࡓࡉࡈࡏࡆࡊࡇࡇࠫ㶟")
	#l11ll1l1l1_l1_(l11lll_l1_ (u"ࠬ࠭㶠"),source,str(l1l1l1l1111l_l1_))
	file,line,func = l11lll_l1_ (u"࠭ࠧ㶡"),l11lll_l1_ (u"ࠧࠨ㶢"),l11lll_l1_ (u"ࠨࠩ㶣")
	l111l1ll1ll_l1_ = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽ร࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㶤")+error
	l1lll11lllll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ีะำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㶥")+source
	for l1ll11ll1ll1_l1_ in reversed(lines):
		if l11lll_l1_ (u"ࠫࡋ࡯࡬ࡦࠢࠥࠫ㶦") in l1ll11ll1ll1_l1_ and l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㶧") in l1ll11ll1ll1_l1_: break
	l1ll11ll1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࠬࠦࡡ࠲ࠠ࡭࡫ࡱࡩࠥ࠮࠮ࠫࡁࠬࡠ࠱ࠦࡩ࡯ࠢࠫ࠲࠯ࡅࠩࠥࠩ㶨"),l1ll11ll1ll1_l1_,re.DOTALL)
	if l1ll11ll1ll1_l1_:
		file,line,func = l1ll11ll1ll1_l1_[0]
		if l11lll_l1_ (u"ࠧ࠰ࠩ㶩") in file: file = file.rsplit(l11lll_l1_ (u"ࠨ࠱ࠪ㶪"),1)[1]
		else: file = file.rsplit(l11lll_l1_ (u"ࠩ࡟ࡠࠬ㶫"),1)[1]
		l1l11l11llll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้๋ไโ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㶬")+file
		line2 = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำุำ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㶭")+line
		l1111l1l111_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไๆๅส๊࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㶮")+func
		l1lllll111l1_l1_ = l1l11l11llll_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㶯")+line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㶰")+l1111l1l111_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㶱")+l1lll11lllll_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㶲")+l111l1ll1ll_l1_
		l1ll11111l1l_l1_ = line2+l11lll_l1_ (u"ࠪࡠࡳ࠭㶳")+l1lll11lllll_l1_+l11lll_l1_ (u"ࠫࡡࡴࠧ㶴")+l111l1ll1ll_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㶵")+l1l11l11llll_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㶶")+l1111l1l111_l1_
		l111lll11ll_l1_ = line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㶷")+l111l1ll1ll_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㶸")+l1l11l11llll_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㶹")+l1111l1l111_l1_
	else:
		l1l11l11llll_l1_,line2,l1111l1l111_l1_ = l11lll_l1_ (u"ࠪࠫ㶺"),l11lll_l1_ (u"ࠫࠬ㶻"),l11lll_l1_ (u"ࠬ࠭㶼")
		l1lllll111l1_l1_ = l1lll11lllll_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ㶽")+l111l1ll1ll_l1_
		l1ll11111l1l_l1_ = l1lll11lllll_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㶾")+l111l1ll1ll_l1_
		l111lll11ll_l1_ = l111l1ll1ll_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l11lll_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡵࡹࡲ࡬ࡦࡲࡦࡴࠩ㶿"),time=2000)
	l1111l11l11_l1_ = l11lll_l1_ (u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭㷀")+l11lll_l1_ (u"ࠪࡠࡳ࠭㷁")
	addons = l1llllllll1l_l1_()
	l1ll1l11l111_l1_ = []
	results = addons[l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㷂")]
	l1ll11ll11l1_l1_ = l1l1111lll1l_l1_(l11l1llllll_l1_)
	if l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㷃") in list(addons.keys()):
		for l1l1l1ll1lll_l1_,l1lll1ll1l1l_l1_,l111l1lll11_l1_ in results: l1ll1l11l111_l1_ = max(l1ll1l11l111_l1_,l1lll1ll1l1l_l1_)
		if l1ll11ll11l1_l1_<l1ll1l11l111_l1_:
			header = l11lll_l1_ (u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ㷄")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㷅"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㷆"),l11lll_l1_ (u"ࠩอัิ๐หࠨ㷇"),l11lll_l1_ (u"ࠪาึ๎ฬࠨ㷈"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
			if choice==0:
				l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㷉"),l11lll_l1_ (u"ࠬิั้ฮࠪ㷊"),l11lll_l1_ (u"࠭สฮัํฯࠬ㷋"),l11lll_l1_ (u"ࠧࠨ㷌"),header)
				if l1ll11l111_l1_==1: choice = 1
			if choice==1:
				import l11ll1ll1l1_l1_
				l11ll1ll1l1_l1_.l1ll111llll1_l1_()
			return
	l1l1111l1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㷍"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㷎"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㷏"))
	if not l1l1111l1l11_l1_: l1l1111l1l11_l1_ = []
	l1ll11111l1l_l1_ = l1ll11111l1l_l1_.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ㷐"),l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ㷑")).replace(l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ㷒"),l11lll_l1_ (u"ࠧࠨ㷓")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㷔"),l11lll_l1_ (u"ࠩࠪ㷕")).replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㷖"),l11lll_l1_ (u"ࠫࠬ㷗"))
	l111lll11ll_l1_ = l111lll11ll_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㷘"),l11lll_l1_ (u"࠭࡜࡝ࡰࠪ㷙")).replace(l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㷚"),l11lll_l1_ (u"ࠨࠩ㷛")).replace(l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㷜"),l11lll_l1_ (u"ࠪࠫ㷝")).replace(l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㷞"),l11lll_l1_ (u"ࠬ࠭㷟"))
	l1l111l11lll_l1_ = l11l1llllll_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ㷠")+l111lll11ll_l1_
	if l1l111l11lll_l1_ in l1l1111l1l11_l1_:
		header = l11lll_l1_ (u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㷡")
		#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㷢"),l11lll_l1_ (u"ࠩัีําࠧ㷣"),l11lll_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㷤"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
		#if l1ll11l111_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㷥"),l11lll_l1_ (u"ࠬิั้ฮࠪ㷦"),l11lll_l1_ (u"࠭ࠧ㷧"),header)
		DIALOG_OK(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㷨"),l11lll_l1_ (u"ࠨࠩ㷩"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
		return
	l1l111ll111l_l1_ = str(kodi_version).split(l11lll_l1_ (u"ࠩ࠱ࠫ㷪"))[0]
	#l111lll1lll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㷫"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㷬"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡎࡒࡔ࡝ࡎࡠࡇࡕࡖࡔࡘࡓࠨ㷭"))
	url = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㷮")][6]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㷯"),url,l11lll_l1_ (u"ࠨࠩ㷰"),l11lll_l1_ (u"ࠩࠪ㷱"),l11lll_l1_ (u"ࠪࠫ㷲"),l11lll_l1_ (u"ࠫࠬ㷳"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖ࠱࠶ࡹࡴࠨ㷴"),False,False)
	html = response.content
	l111lll1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭㷵"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㷶"),l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡑࡎࡐ࡙ࡑࡣࡊࡘࡒࡐࡔࡖࠫ㷷"),l111lll1lll_l1_,REGULAR_CACHE)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㷸"),line+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㷹")+error+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㷺")+l11l1llllll_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㷻")+l1l111ll111l_l1_)
	for l1111l11111_l1_,l111l1ll1l1_l1_,l1lll1111ll1_l1_,l1ll11111l11_l1_ in l111lll1lll_l1_:
		l1111l11111_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"࠭ࠫࠨ㷼"))
		l1lll1111ll1_l1_ = l1lll1111ll1_l1_.split(l11lll_l1_ (u"ࠧࠬࠩ㷽"))
		l1ll11111l11_l1_ = l1ll11111l11_l1_.split(l11lll_l1_ (u"ࠨ࠭ࠪ㷾"))
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ㷿"),str(l1111l11111_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㸀")+l111l1ll1l1_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㸁")+str(l1lll1111ll1_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㸂")+str(l1ll11111l11_l1_))
		if line in l1111l11111_l1_ and error==l111l1ll1l1_l1_ and l11l1llllll_l1_ in l1lll1111ll1_l1_ and l1l111ll111l_l1_ in l1ll11111l11_l1_:
			header = l11lll_l1_ (u"࠭็ัษࠣห้ิืฤ่ࠢ฽ึ๎แ๊ࠡึ๎฾อไอࠢหห้หีะษิࠤฬ๊โศั่ࠫ㸃")
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㸄"),l11lll_l1_ (u"ࠨะิ์ั࠭㸅"),l11lll_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭㸆"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
			if l1ll11l111_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㸇"),l11lll_l1_ (u"ࠫࠬ㸈"),l11lll_l1_ (u"ࠬ࠭㸉"),header)
			return
	header = l11lll_l1_ (u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭㸊")
	DIALOG_OK(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㸋"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㸌"),l1111l11l11_l1_+header,l1lllll111l1_l1_)
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㸍"),l11lll_l1_ (u"ࠪ็้อࠧ㸎"),l11lll_l1_ (u"๋ࠫ฿ๅࠨ㸏"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㸐"),l11lll_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎฾ืแࠡษ็้อืๅอࠢฦ๎๋่ࠦๆฬ์ࠤํ้๊โ๋่๊ࠢอะศࠢะู้ะ่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠศื็หาࠦๅีๅ็อࠥ๎็้ࠢ็หࠥ๐ูาใࠣ็๏็ู้ࠠิฮࠥ๎ไๆษำหࠥ฾็าฬࠣ์๊ะฺ้๊ࠡีฯࠦ็ั้ࠣห้๋ิไๆฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤำึห้ࠦวๅีฯ่ࠥลࠧ㸑"))
	if l1ll11l111_l1_==1: l1l111l1l1l1_l1_ = l11lll_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ㸒")
	else:
		DIALOG_OK(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㸓"),l11lll_l1_ (u"ࠩࠪ㸔"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㸕"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสๆࠢศ่฿อมࠡวิืฬ๊ࠠศๆั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ㸖"))
		return
	message = l1ll11111l1l_l1_
	import l11ll1ll1l1_l1_
	succeeded = l11ll1ll1l1_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵࡷࠬ㸗"),message,True,l11lll_l1_ (u"࠭ࠧ㸘"),l11lll_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ㸙"),l1l111l1l1l1_l1_)
	if succeeded and l1l111l1l1l1_l1_:
		l1l1111l1l11_l1_.append(l1l111l11lll_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㸚"),l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ㸛"),l1l1111l1l11_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㸜"))
	filename = l11lll_l1_ (u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ㸝")+str(time.time())+l11lll_l1_ (u"ࠬ࠴ࡤࡢࡶࠪ㸞")
	open(filename,l11lll_l1_ (u"࠭ࡷࡣࠩ㸟")).write(data)
	return
def l11l1111ll1_l1_(l11llllll11_l1_):
	if l11llllll11_l1_:
		l1l1l11lllll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㸠"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㸡"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ㸢"))
		if l1l1l11lllll_l1_: return l1l1l11lllll_l1_
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㸣")][5]
	user = l11llll1111_l1_(32)
	l1lll1ll1lll_l1_ = l11l1l1llll_l1_()
	l1ll111l1l11_l1_ = l1lll1ll1lll_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭㸤"))[2]
	l1l1lll1l1l1_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㸥"))
	l1ll1ll1l111_l1_ = l1l11l111ll1_l1_()
	payload = {l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ㸦"):user,l11lll_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㸧"):l11l1llllll_l1_,l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㸨"):l1ll111l1l11_l1_,l11lll_l1_ (u"ࠩ࡬ࡨࡸ࠭㸩"):l1l1lll11l11_l1_(l1ll1ll1l111_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㸪"),url,payload,l11lll_l1_ (u"ࠫࠬ㸫"),l11lll_l1_ (u"ࠬ࠭㸬"),l11lll_l1_ (u"࠭ࠧ㸭"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬ㸮"))
	if not response.succeeded: return []
	html = response.content
	l1l1l11lllll_l1_ = html.replace(l11lll_l1_ (u"ࠨ࡞࡟ࡶࠬ㸯"),l11lll_l1_ (u"ࠩ࡟ࡲࠬ㸰")).replace(l11lll_l1_ (u"ࠪࡠࡡࡴࠧ㸱"),l11lll_l1_ (u"ࠫࡡࡴࠧ㸲")).replace(l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㸳"),l11lll_l1_ (u"࠭࡜࡯ࠩ㸴")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ㸵"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ㸶"))
	l1l1l11lllll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ㸷"),l1l1l11lllll_l1_,re.DOTALL)
	if not l1l1l11lllll_l1_: return []
	l1l1l11lllll_l1_ = sorted(l1l1l11lllll_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1111ll1ll_l1_,l1l11l1111l1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11lllll_l1_[0]
	#if l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ㸸") in reason: l1l1llll111l_l1_,l1l1llll11l1_l1_,l1l1llll11ll_l1_ = reason.split(l11lll_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ㸹"),2)
	#else: l1l1llll111l_l1_,l1l1llll11l1_l1_,l1l1llll11ll_l1_ = reason,reason,reason
	l1ll1111l111_l1_ = reason if l11l1llll11_l1_(l11lll_l1_ (u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ㸺")) else l1l11l1111l1_l1_
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㸻"),l1ll1111l111_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㸼"),l11lll_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㸽"),l1l1l11lllll_l1_,REGULAR_CACHE)
	return l1l1l11lllll_l1_
def SPLIT_BIGLIST(items,l1l111l11l1l_l1_=0,l1ll1l1ll1l1_l1_=0):
	if l1l111l11l1l_l1_ and not l1ll1l1ll1l1_l1_: l1ll1l1ll1l1_l1_ = len(items)//l1l111l11l1l_l1_
	l1ll11ll111l_l1_,l11ll111l1_l1_,l1ll111ll111_l1_ = [],-1,0
	for item in items:
		if l1ll111ll111_l1_%l1ll1l1ll1l1_l1_==0:
			l11ll111l1_l1_ += 1
			l1ll11ll111l_l1_.append([])
		l1ll11ll111l_l1_[l11ll111l1_l1_].append(item)
		l1ll111ll111_l1_ += 1
	return l1ll11ll111l_l1_
	l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉ࡭ࡧࡱ࡫ࡹ࡮ࠠ࠾ࠢ࡯ࡩࡳ࠮ࡢࡪࡩ࡯࡭ࡸࡺࠩࠎࠌࠌࡷࡵࡲࡩࡵࡶࡨࡨࠥࡃࠠ࡜࡟ࠐࠎࠎ࡬࡯ࡳࠢ࡬࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠲࠮ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴࠬ࠳ࠬ࠾ࠒࠐࠉࠊ࡫ࡩࠤ࡮࡯ࠡ࠾ࡵࡳࡰ࡮ࡺࡳࡠࡥࡲࡹࡳࡺ࠺ࠎࠌࠌࠍࠎࡲࡩ࡯ࡧࡶ࠴ࠥࡃࠠࡣ࡫ࡪࡰ࡮ࡹࡴ࡜࠲࠽࡭ࡳࡺࠨ࡭ࡧࡱ࡫ࡹ࡮࠯ࡴࡲ࡯࡭ࡹࡹ࡟ࡤࡱࡸࡲࡹ࠯࡝ࠎࠌࠌࠍࠎࡪࡥ࡭ࠢࡥ࡭࡬ࡲࡩࡴࡶ࡞࠴࠿࡯࡮ࡵࠪ࡯ࡩࡳ࡭ࡴࡩ࠱ࡶࡴࡱ࡯ࡴࡴࡡࡦࡳࡺࡴࡴࠪ࡟ࠌࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠓࠊࠊࠋࠌࡰ࡮ࡴࡥࡴ࠲ࠣࡁࠥࡨࡩࡨ࡮࡬ࡷࡹࠓࠊࠊࠋࠌࡨࡪࡲࠠࡣ࡫ࡪࡰ࡮ࡹࡴࠎࠌࠌࠍࡸࡶ࡬ࡪࡶࡷࡩࡩ࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰࡨࡷ࠵࠯ࠍࠋࠋࠌࡨࡪࡲࠠ࡭࡫ࡱࡩࡸ࠶ࠍࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡶࡴࡱ࡯ࡴࡵࡧࠐࠎࠎࠨࠢࠣ㸾")
def l1llllll1ll1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11lll_l1_ (u"ࠪࡨࡺࡳ࡭ࡺࡰࡤࡱࡪ࠭㸿"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11lll_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ㹀") not in filename or l11lll_l1_ (u"ࠬࡓ࠳ࡖࡡࠪ㹁") not in filename: text = str(data)
	else:
		l1ll11ll111l_l1_ = SPLIT_BIGLIST(data,8)
		text = l11lll_l1_ (u"࠭ࠧ㹂")
		for split in l1ll11ll111l_l1_:
			text += str(split)+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㹃")
		text = text.strip(l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㹄"))
	l11lll11lll_l1_ = zlib.compress(text)
	open(filepath,l11lll_l1_ (u"ࠩࡺࡦࠬ㹅")).write(l11lll11lll_l1_)
	return
def l111ll111ll_l1_(l11lll1ll11_l1_,filename):
	if l11lll1ll11_l1_==l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㹆"): data = {}
	elif l11lll1ll11_l1_==l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㹇"): data = []
	elif l11lll1ll11_l1_==l11lll_l1_ (u"ࠬࡹࡴࡳࠩ㹈"): data = l11lll_l1_ (u"࠭ࠧ㹉")
	elif l11lll1ll11_l1_==l11lll_l1_ (u"ࠧࡪࡰࡷࠫ㹊"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l11lll11lll_l1_ = open(filepath,l11lll_l1_ (u"ࠨࡴࡥࠫ㹋")).read()
	text = zlib.decompress(l11lll11lll_l1_)
	#open(l11lll_l1_ (u"ࠩࡶ࠾ࡡࡢࡉࡑࡖ࡙࠵࠳ࡺࡸࡵࠩ㹌"),l11lll_l1_ (u"ࠪࡻࡧ࠭㹍")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11lll_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ㹎"))
	#if l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㹏") not in text: data = EVAL(l11lll_l1_ (u"࠭ࡳࡵࡴࠪ㹐"),text)
	if l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㹑") not in text: data = eval(text)
	else:
		l1ll11ll111l_l1_ = text.split(l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㹒"))
		del text
		data = []
		l1111ll1l1l_l1_ = l11111lllll_l1_()
		id = 0
		for split in l1ll11ll111l_l1_:
			#data += EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭㹓"),split)
			l1111ll1l1l_l1_.l11111l11ll_l1_(str(id),eval,split)
			id += 1
		del l1ll11ll111l_l1_
		l1111ll1l1l_l1_.l1l1ll1ll1l1_l1_()
		l1111ll1l1l_l1_.l1l111l11l11_l1_()
		l1l11l11111l_l1_ = list(l1111ll1l1l_l1_.l1ll1l1lll11_l1_.keys())
		l1l11lll1l11_l1_ = sorted(l1l11l11111l_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l11lll1l11_l1_:
			data += l1111ll1l1l_l1_.l1ll1l1lll11_l1_[id]
	return data
def l1ll111lll1l_l1_(addon_id):
	l111l1l11l1_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㹔"),addon_id,l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㹕"))
	try: l1ll1ll1l1l1_l1_ = open(l111l1l11l1_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ㹖")).read()
	except:
		l1ll111l1l1l_l1_ = os.path.join(l1lll11l1lll_l1_,l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭㹗"),addon_id,l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ㹘"))
		try: l1ll1ll1l1l1_l1_ = open(l1ll111l1l1l_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㹙")).read()
		except: return l11lll_l1_ (u"ࠩࠪ㹚"),[]
	if kodi_version>18.99: l1ll1ll1l1l1_l1_ = l1ll1ll1l1l1_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㹛"))
	version = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ㹜"),l1ll1ll1l1l1_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11lll_l1_ (u"ࠬ࠭㹝"),[]
	l11l11lll11_l1_,l11111l1111_l1_ = version[0],l1l1111lll1l_l1_(version[0])
	return l11l11lll11_l1_,l11111l1111_l1_
def l1llllllll1l_l1_():
	l1llll11llll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ㹞"),l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㹟"),l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ㹠"))
	if l1llll11llll_l1_: return l1llll11llll_l1_
	addons,l1llll11llll_l1_ = {},{}
	l1l1l1l1111l_l1_ = [l1ll11l_l1_[l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㹡")][0]]
	if kodi_version>17.99: l1l1l1l1111l_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㹢")][1])
	if kodi_version>18.99: l1l1l1l1111l_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㹣")][2])
	for l1l1l1111l1l_l1_ in l1l1l1l1111l_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㹤"),l1l1l1111l1l_l1_,l11lll_l1_ (u"࠭ࠧ㹥"),l11lll_l1_ (u"ࠧࠨ㹦"),l11lll_l1_ (u"ࠨࠩ㹧"),l11lll_l1_ (u"ࠩࠪ㹨"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ㹩"))
		if response.succeeded:
			html = response.content
			l1l111l1lll1_l1_ = l1l1l1111l1l_l1_.rsplit(l11lll_l1_ (u"ࠫ࠴࠭㹪"),1)[0]
			l1llll1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㹫"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1llllll11ll_l1_ in l1llll1l111l_l1_:
				l11111l111l_l1_ = l1l111l1lll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ㹬")+addon_id+l11lll_l1_ (u"ࠧ࠰ࠩ㹭")+addon_id+l11lll_l1_ (u"ࠨ࠯ࠪ㹮")+l1llllll11ll_l1_+l11lll_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ㹯")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1llll11llll_l1_[addon_id] = []
				l1lll111l1l1_l1_ = l1l1111lll1l_l1_(l1llllll11ll_l1_)
				addons[addon_id].append((l1llllll11ll_l1_,l1lll111l1l1_l1_,l11111l111l_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㹰"),str(addon_id)+l11lll_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ㹱")+str(addons[addon_id]))
		l1llll11llll_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㹲"),l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㹳"),l1llll11llll_l1_,REGULAR_CACHE)
	return l1llll11llll_l1_
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡶࡦࡽ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯ࡥࡧࡥࡩࡷ࡭࠮ࡰࡴࡪ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡥࡶࡦࡴࡣࡩ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡡࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡦࡣ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡨࡲࡢࡰࡦ࡬࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࡢ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷࡩࡪ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠶࠴ࡸࡡࡸ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࠧࠨࠢ㹴")
def l1l1111lll1l_l1_(l1llllll11ll_l1_):
	l1lll111l1l1_l1_ = []
	l1l1lll11l1_l1_ = l1llllll11ll_l1_.split(l11lll_l1_ (u"ࠨ࠰ࠪ㹵"))
	for l1l111l111_l1_ in l1l1lll11l1_l1_:
		parts = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰ࢂ࡛࡝࠭࡟࠱ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠭㹶"),l1l111l111_l1_,re.DOTALL)
		l1l11l111l11_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l11l111l11_l1_.append(part)
		l1lll111l1l1_l1_.append(l1l11l111l11_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㹷"),str(l1llllll11ll_l1_)+l11lll_l1_ (u"ࠫࠥࠦ࠮ࠡࠢࠪ㹸")+str(l1lll111l1l1_l1_))
	return l1lll111l1l1_l1_
def l1l1lllllll1_l1_(l1lll111l1l1_l1_):
	l1llllll11ll_l1_ = l11lll_l1_ (u"ࠬ࠭㹹")
	for l1l111l111_l1_ in l1lll111l1l1_l1_:
		for part in l1l111l111_l1_: l1llllll11ll_l1_ += str(part)
		l1llllll11ll_l1_ += l11lll_l1_ (u"࠭࠮ࠨ㹺")
	l1llllll11ll_l1_ = l1llllll11ll_l1_.strip(l11lll_l1_ (u"ࠧ࠯ࠩ㹻"))
	return l1llllll11ll_l1_
def l1ll1lll1l11_l1_(l111ll11111_l1_):
	# l1l1l11l1lll_l1_ not l111l111l1l_l1_ l1l1ll1l1l1l_l1_ l1l11lll1lll_l1_ addons status l1lllllll1l_l1_ l11l111ll1_l1_ l111l1llll_l1_ l1111111lll_l1_
	#l1l111ll1111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㹼"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㹽"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࡠࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ㹾"))
	#if l1l111ll1111_l1_: return l1l111ll1111_l1_
	l1l111ll1111_l1_ = {}
	addons = l1llllllll1l_l1_()
	l111lllll11_l1_ = l1l1ll1ll11l_l1_(l111ll11111_l1_)
	for addon_id in l111ll11111_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1llll11llll_l1_ = addons[addon_id]
		l1ll1l111lll_l1_,l111lll111l_l1_,l1l1111l1111_l1_ = l1llll11llll_l1_[0]
		#l1llll111111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ㹿")+addon_id+l11lll_l1_ (u"ࠬ࠯ࠧ㺀"))
		l1llll111111_l1_,l111111ll11_l1_ = l1ll111lll1l_l1_(addon_id)
		l111l11ll1l_l1_,l1ll1l1l1lll_l1_ = l111lllll11_l1_[addon_id]
		l11l1111lll_l1_ = l111lll111l_l1_>l111111ll11_l1_ and l111l11ll1l_l1_
		l1l1111l11l1_l1_ = True
		if not l111l11ll1l_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ㺁")
		elif not l1ll1l1l1lll_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ㺂")
		elif l11l1111lll_l1_: l11l11lllll_l1_ = l11lll_l1_ (u"ࠨࡱ࡯ࡨࠬ㺃")
		else:
			l11l11lllll_l1_ = l11lll_l1_ (u"ࠩࡪࡳࡴࡪࠧ㺄")
			l1l1111l11l1_l1_ = False
		l1l111ll1111_l1_[addon_id] = (l1l1111l11l1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l111lll_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1111_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㺅"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ㺆"),l1l111ll1111_l1_,REGULAR_CACHE)
	return l1l111ll1111_l1_
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࠧ࡮࡬ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳ࠮࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠰࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥࡼࡥࡳࡵ࡬ࡳࡳ࠲ࡔࡳࡷࡨ࠰࡙ࡸࡵࡦࠏࠍࠍࠨ࡫࡬ࡴࡧ࠽ࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵ࠰࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠲ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࠨࠩ࠯ࡊࡦࡲࡳࡦ࠮ࡉࡥࡱࡹࡥࠎࠌࠌࠧ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹࠦ࠽ࠡࠪࡻࡦࡲࡩ࠮ࡨࡧࡷࡇࡴࡴࡤࡗ࡫ࡶ࡭ࡧ࡯࡬ࡪࡶࡼ࡙ࠬࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬ࠯ࠧࠪ࠿ࡀ࠵࠮ࠓࠊࠊࠥ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡁࠫࠬࠓࠊࠊࠥ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠬࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡉ࡯࡯ࡦ࡙࡭ࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠮ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳࡏࡳࡆࡰࡤࡦࡱ࡫ࡤࠩࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠩࠨࠫࡀࡁ࠶࠯ࠍࠋࠋࠦࡩࡱࡹࡥ࠻ࠢ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࡰࡲࡸࠥ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡧ࡮ࡥࠢࡱࡳࡹࠦࡩࡴࡡࡨࡼ࡮ࡹࡴࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡨࡪࡩ࡫ࡩࡸࡺ࡟ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠊࠋࠪ࠯ࡸࡺࡲࠩࡪ࡬࡫࡭࡫ࡳࡵࡡࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡤࡼࡥࡳࡡࡦࡳࡲࡶࡡࡳࡧࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠋࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡲࡰࡩࠏࠧࠬࡵࡷࡶ࠭࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡴࡲࡤࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡳ࡫ࡥࡥࡡࡸࡴࡩࡧࡴࡦࠋࠌࠫ࠰ࡹࡴࡳࠪࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡳࡵࡣࡷࡹࡸࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡶࡸࡦࡺࡵࡴࠫࠬࠑࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡶࡦࡴࡶ࡭ࡴࡴࡳ࠻ࠢࠣࠫ࠰ࡹࡴࡳࠪࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭࠰࠭ࠠࠡࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠩࠬࠩࠣࠤࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨ࠮࠯ࠍࠋࠋࠥࠦࠧ㺇")
def PROGRESS_UPDATE(l11l1ll11l_l1_,l1lll1l1l11l_l1_,l11111llll1_l1_=l11lll_l1_ (u"࠭ࠧ㺈"),line2=l11lll_l1_ (u"ࠧࠨ㺉"),l1111l11111_l1_=l11lll_l1_ (u"ࠨࠩ㺊")):
	if kodi_version<19: l11l1ll11l_l1_.update(l1lll1l1l11l_l1_,l11111llll1_l1_,line2,l1111l11111_l1_)
	else: l11l1ll11l_l1_.update(l1lll1l1l11l_l1_,l11111llll1_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㺋")+line2+l11lll_l1_ (u"ࠪࡠࡳ࠭㺌")+l1111l11111_l1_)
	return
def l1l1ll1lll1l_l1_(l1ll11l1lll1_l1_):
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,d)
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,r)
	# l1lll1111111_l1_ l1l1l1l1l1ll_l1_:  https://l1ll11ll1l1l_l1_.io
	def l1ll1ll11lll_l1_(num,b,l1l1l1llllll_l1_=l11lll_l1_ (u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦ㺍")):
		return ((num == 0) and l1l1l1llllll_l1_[0]) or (l1ll1ll11lll_l1_(num // b, b, l1l1l1llllll_l1_).lstrip(l1l1l1llllll_l1_[0]) + l1l1l1llllll_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11lll_l1_ (u"ࠧࡢ࡜ࡣࠤ㺎") + l1ll1ll11lll_l1_(c, a) + l11lll_l1_ (u"ࠨ࡜࡝ࡤࠥ㺏"),  k[c], p)
		return p
	l1ll11l1lll1_l1_ = l1ll11l1lll1_l1_.split(l11lll_l1_ (u"ࠧࡾࠪࠪ㺐"))[1][:-1]
	l1l1l1ll11ll_l1_ = eval(l11lll_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ㺑")+l1ll11l1lll1_l1_,{l11lll_l1_ (u"ࠩࡥࡥࡸ࡫ࡎࠨ㺒"):l1ll1ll11lll_l1_,l11lll_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ㺓"):unpack})   #,locals())
	return l1l1l1ll11ll_l1_
def l1ll1l1ll1_l1_(url,l1ll11l11lll_l1_=l11lll_l1_ (u"ࠫࠬ㺔")):
	if l1ll11l11lll_l1_==l11lll_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ㺕"): url = re.sub(l11lll_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭㺖"),lambda l11l111llll_l1_: l11l111llll_l1_.group(0).lower(),url)
	elif l1ll11l11lll_l1_==l11lll_l1_ (u"ࠧࡶࡲࡳࡩࡷ࠭㺗"): url = re.sub(l11lll_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ㺘"),lambda l11l111llll_l1_: l11l111llll_l1_.group(0).upper(),url)
	return url
def l1l1ll1ll11l_l1_(l111ll11111_l1_):
	installed,l1lll11ll111_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1l11ll111_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll11111_l1_)==1: l1llllllll11_l1_ = l11lll_l1_ (u"ࠩࠫࠦࠬ㺙")+l111ll11111_l1_[0]+l11lll_l1_ (u"ࠪࠦ࠮࠭㺚")
	else: l1llllllll11_l1_ = str(tuple(l111ll11111_l1_))
	cc.execute(l11lll_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ㺛")+l1llllllll11_l1_+l11lll_l1_ (u"ࠬࠦ࠻ࠨ㺜"))
	l11ll1ll111_l1_ = cc.fetchall()
	l111lllll11_l1_ = {}
	for addon_id in l111ll11111_l1_: l111lllll11_l1_[addon_id] = (False,False)
	for addon_id,l1lll11ll111_l1_ in l11ll1ll111_l1_:
		installed = True
		l1lll11ll111_l1_ = l1lll11ll111_l1_==1
		l111lllll11_l1_[addon_id] = (installed,l1lll11ll111_l1_)
	conn.close()
	return l111lllll11_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11lll_l1_ (u"࠭ࠧ㺝")
	if file==l1l1111llll1_l1_: status = l11111l1ll1_l1_(True,False)
	if os.path.exists(file):
		l11ll11lll1_l1_ = open(file,l11lll_l1_ (u"ࠧࡳࡤࠪ㺞")).read()
		if kodi_version>18.99: l11ll11lll1_l1_ = l11ll11lll1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㺟"))
		if file==l1l1111llll1_l1_: results = l11ll11lll1_l1_
		else:
			l1llll111l11_l1_ = EVAL(l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㺠"),l11ll11lll1_l1_)
			if l1llll111l11_l1_:
				results = {}
				for key in l1llll111l11_l1_.keys():
					results[key] = []
					for l1ll1lll1l1l_l1_ in l1llll111l11_l1_[key]:
						type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = l11lll_l1_ (u"ࠪࠫ㺡"),l11lll_l1_ (u"ࠫࠬ㺢"),l11lll_l1_ (u"ࠬ࠭㺣"),l11lll_l1_ (u"࠭ࠧ㺤"),l11lll_l1_ (u"ࠧࠨ㺥"),l11lll_l1_ (u"ࠨࠩ㺦"),l11lll_l1_ (u"ࠩࠪ㺧"),l11lll_l1_ (u"ࠪࠫ㺨"),l11lll_l1_ (u"ࠫࠬ㺩")
						type = l1ll1lll1l1l_l1_[0]
						name = l1ll1lll1l1l_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1ll1lll1l1l_l1_[2]
						mode = l1ll1lll1l1l_l1_[3]
						l11l_l1_ = l1ll1lll1l1l_l1_[4]
						l1l11l1_l1_ = l1ll1lll1l1l_l1_[5]
						if len(l1ll1lll1l1l_l1_)>6: text = l1ll1lll1l1l_l1_[6]
						if len(l1ll1lll1l1l_l1_)>7: context = l1ll1lll1l1l_l1_[7]
						if len(l1ll1lll1l1l_l1_)>8: l1ll11111l1_l1_ = l1ll1lll1l1l_l1_[8]
						if file==favoritesfile: l1l111lll1l1_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,l11lll_l1_ (u"ࠬ࠭㺪"),l1ll11111l1_l1_
						else: l1l111lll1l1_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_
						results[key].append(l1l111lll1l1_l1_)
			l11ll111111_l1_ = str(results)
			if kodi_version>18.99: l11ll111111_l1_ = l11ll111111_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㺫"))
			open(file,l11lll_l1_ (u"ࠧࡸࡤࠪ㺬")).write(l11ll111111_l1_)
	return results
def l1l1l11l111_l1_(l1l1l1l1l1l_l1_):
	l1l1l11ll1l_l1_ = l1l1l1l1l1l_l1_.split(l11lll_l1_ (u"ࠨ࠯ࠪ㺭"),1)[0]
	l1l1l11ll11_l1_,l1l1l1l1l11_l1_,l1l1ll1l1l1_l1_ = l11lll_l1_ (u"ࠩࠪ㺮"),l11lll_l1_ (u"ࠪࠫ㺯"),l11lll_l1_ (u"ࠫࠬ㺰")
	if   l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ㺱")		:	from l1l111l_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ㺲")	:	from l1l1l111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭㺳")		:	from l111111_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㺴")	:	from l111l1l1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㺵")	:	from l1ll11ll1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㺶")	: 	from l1l1ll111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㺷")	:	from l1l1l1lll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ㺸")	:	from l11l1l111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅࠬ㺹")		:	from l1111l11l_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㺺")	:	from l1llllllll_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㺻")	:	from l1lll11l1l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫ㺼")	:	from l1ll1lll1l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㺽")	:	from l1ll1ll11l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㺾"):	from l111ll1ll1l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡌࡏࡔࡖࡄࠫ㺿")		:	from l1l1ll1ll11_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㻀")		:	from l1ll1ll_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ㻁")	:	from l1l1llll1ll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㻂")	:	from l1lll11ll1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂࠩ㻃")	:	from l1lll1lll1ll_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㻄")	:	from l1111111l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ㻅")	:	from l1l111l11l1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㻆")	:	from l111111l1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㻇")		:	from l111llllll1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ㻈")	:	from l1l11l111ll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭㻉"):	from l1l11ll11_l1_	import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㻊")	:	from l111lll1l1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㻋")	:	from l1ll1l1lll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㻌"):	from l11lll1lll_l1_	import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭㻍")	:	from l11111ll1l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㻎")	:	from l1llll1l1ll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㻏")	:	from l1lll1l1l11_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ㻐")	:	from l1lll11l1l1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㻑")	:	from l1lll11l111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ㻒")	:	from l1ll1l1l1ll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㻓")	:	from l1ll1l1l1l1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㻔")	:	from l1l1llll111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㻕")	:	from l1l1l1111ll_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ㻖")	:	from l1lll1l111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㻗")		:	from l1l1l1111l1_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㻘")		:	from IPTV			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,menu_namee as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡑ࠸࡛ࠧ㻙")		:	from l1l11l1ll111_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ㻚")	:	from l1l11l1l11l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭㻛")	:	from l11l11ll11l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭㻜")	:	from l1l1ll111l1l_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ㻝")	:	from l1ll1111l1ll_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ㻞")	:	from l1l1l11ll11l_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ㻟")	:	from l1l1lll1ll1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ㻠")	:	from l1l1lll1111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㻡")		:	from l1111l111ll_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㻢")	:	from l1l1l11l11l1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ㻣")	:	from l1111l1l1l1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ㻤")	:	from l11l111l111_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ㻥")	:	from l1l11ll1l1l1_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㻦")		:	from l1lll11l1l11_l1_			import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㻧")	:	from l111llll11l_l1_		import MENU as l1l1l11ll11_l1_,SEARCH as l1l1l1l1l11_l1_,l111ll_l1_ as l1l1ll1l1l1_l1_
	elif l1l1l11ll1l_l1_==l11lll_l1_ (u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪ㻨"):	from l111l1lll1l_l1_	import MENU as l1l1l11ll11_l1_
	return l1l1l11ll11_l1_,l1l1l1l1l11_l1_,l1l1ll1l1l1_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l1111l111l_l1_,headers,l1ll_l1_):
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭㻩"),l11lll_l1_ (u"࠭ࠧ㻪"),l11lll_l1_ (u"ࠧࠨ㻫"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㻬"),l11lll_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ์็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠤࠫ㻭"))
	#if l1ll11l111_l1_!=1: return l11lll_l1_ (u"ࠪࠫ㻮")
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㻯"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪ㻰")+l1l1111l111l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩ㻱")+str(headers)+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㻲"))
	l11l1ll11l_l1_ = DIALOG_PROGRESS()
	l11l1ll11l_l1_.create(l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㻳"),l11lll_l1_ (u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫ㻴"))
	l11ll11ll1_l1_ = 1024*1024
	l111l1ll111_l1_ = bytes()
	chunk_size = 2*l11ll11ll1_l1_
	import requests
	response = requests.get(l1l1111l111l_l1_,stream=True,headers=headers)
	l1l11ll1l11l_l1_ = response.headers
	response.close()
	if not l1l11ll1l11l_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㻵"),l11lll_l1_ (u"ࠫࠬ㻶"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㻷"),l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩ㻸"))
		l11l1ll11l_l1_.close()
	else:
		if l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ㻹") not in list(l1l11ll1l11l_l1_.keys()): filesize = 0
		else: filesize = int(l1l11ll1l11l_l1_[l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ㻺")])
		l11ll11111_l1_ = str(int(1000*filesize/l11ll11ll1_l1_)/1000.0)
		l11l11l1ll_l1_ = int(filesize/chunk_size)+1
		if l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩ㻻") in list(l1l11ll1l11l_l1_.keys()) and filesize>l11ll11ll1_l1_:
			l1l1l1ll1ll1_l1_ = True
			ranges = []
			l1l1l11l1l1l_l1_ = 10
			ranges.append(str(0*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ㻼")+str(1*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(1*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠫ࠲࠭㻽")+str(2*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(2*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ㻾")+str(3*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(3*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"࠭࠭ࠨ㻿")+str(4*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(4*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠧ࠮ࠩ㼀")+str(5*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(5*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠨ࠯ࠪ㼁")+str(6*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(6*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠩ࠰ࠫ㼂")+str(7*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(7*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ㼃")+str(8*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(8*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠫ࠲࠭㼄")+str(9*filesize//l1l1l11l1l1l_l1_-1))
			ranges.append(str(9*filesize//l1l1l11l1l1l_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ㼅"))
			l111ll1l1ll_l1_ = float(l11l11l1ll_l1_)/l1l1l11l1l1l_l1_
			l1lll1111lll_l1_ = l111ll1l1ll_l1_/int(1+l111ll1l1ll_l1_)
		else:
			l1l1l1ll1ll1_l1_ = False
			l1l1l11l1l1l_l1_ = 1
			l1lll1111lll_l1_ = 1
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㼆"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨ㼇")+str(l1l1l1ll1ll1_l1_)+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ㼈")+str(filesize)+l11lll_l1_ (u"ࠩࠣࡡࠬ㼉"))
		l11ll111l1_l1_ = 0
		#t1 = time.time()-30
		for l1ll111ll111_l1_ in range(l1l1l11l1l1l_l1_):
			l1l1ll1ll_l1_ = headers
			if l1l1l1ll1ll1_l1_: l1l1ll1ll_l1_[l11lll_l1_ (u"ࠪࡖࡦࡴࡧࡦࠩ㼊")] = l11lll_l1_ (u"ࠫࡧࡿࡴࡦࡵࡀࠫ㼋")+ranges[l1ll111ll111_l1_]
			response = requests.get(l1l1111l111l_l1_,stream=True,headers=l1l1ll1ll_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1ll11l_l1_.iscanceled():
					LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㼌"),l11lll_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩ࠭㼍"))
					break
				l11ll111l1_l1_ += l1lll1111lll_l1_
				PROGRESS_UPDATE(l11l1ll11l_l1_,100*l11ll111l1_l1_//l11l11l1ll_l1_,l11lll_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠥอไอิฤࠤึ่ๅࠨ㼎"),str(int(100*l11ll111l1_l1_*chunk_size//l11ll11ll1_l1_)/100.0)+l11lll_l1_ (u"ࠨࠢ࠲ࠤࠬ㼏")+l11ll11111_l1_+l11lll_l1_ (u"ࠩࠣࡑࡇ࠭㼐"))
				l111l1ll111_l1_ += chunk
				#PROGRESS_UPDATE(l11l1ll11l_l1_,0+int(35*l11ll111l1_l1_/l11l11l1ll_l1_),l11lll_l1_ (u"ࠪะ้ฮࠠศๆ่่ๆࠦวๅำษ๎ุ๐࠺࠮ࠢส่ัุมࠡำๅ้ࠬ㼑")+l11lll_l1_ (u"ࠫࡡࡴࠧ㼒")+str(l11ll111l1_l1_*chunksize/l11ll11ll1_l1_)+l11lll_l1_ (u"ࠬࠦ࠯ࠡࠩ㼓")+l11ll11111_l1_+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ㼔")+time.strftime(l11lll_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ㼕")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㼖")+time.gmtime(l11l111l1l_l1_))+l11lll_l1_ (u"ࠩࠣไࠬ㼗"))
				#l11l1111l1_l1_ = time.time()
				#l111lllll1_l1_ = l11l1111l1_l1_-t1
				#l11l11111l_l1_ = l111lllll1_l1_/l11ll111l1_l1_
				#l11l1l11ll_l1_ = l11l11111l_l1_*(l11l11l1ll_l1_+1)
				#l11l111l1l_l1_ = l11l1l11ll_l1_-l111lllll1_l1_
			response.close()
		l11l1ll11l_l1_.close()
		if len(l111l1ll111_l1_)<filesize and filesize>0:
			LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㼘"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧ㼙")+str(len(l111l1ll111_l1_)//l11ll11ll1_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪ㼚")+l11ll11111_l1_+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠬ㼛"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ㼜"),l11lll_l1_ (u"ࠨว็฾ฬว้ࠠะิ์ั࠭㼝"),l11lll_l1_ (u"ࠩสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠩ㼞"),l11lll_l1_ (u"ࠪษ฾อฯสࠢฯ่อࠦวๅ็็ๅࠬ㼟"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㼠"),l11lll_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษࠢส่๊๊แࠡ࡞ࡱࠤ้๊ริใࠣัิัࠠฯูฦࠤๆ๐ࠠหฯ่๎้ࠦวๅ็็ๅࠥࡢ࡮ࠡฬ่ࠤั๊ศࠡࠩ㼡")+str(len(l111l1ll111_l1_)//l11ll11ll1_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊ห่๊๋ࠢࠥฬๆ๊฼ࠤࠬ㼢")+l11ll11111_l1_+l11lll_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣࡠࡳࠦฬาสࠣะ้ฮࠠศๆ่่ๆࠦๅาหࠣวำื้ࠡ࡞ࡱࠤ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠥลࠡࠢࠩ㼣"))
			if choice==2: l111l1ll111_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111l111l_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㼤"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ㼥"))
			else: return l11lll_l1_ (u"ࠪࠫ㼦")
			if not l111l1ll111_l1_: return l11lll_l1_ (u"ࠫࠬ㼧")
		else: LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㼨"),l11lll_l1_ (u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࠮ࠡࠢࠣࡊ࡮ࡲࡥࠡࡕ࡬ࡾࡪࡀࠠ࡜ࠢࠪ㼩")+l11ll11111_l1_+l11lll_l1_ (u"ࠧࠡࡏࡅࠤࡢ࠭㼪"))
	return l111l1ll111_l1_
def l1lll111l1ll_l1_(script_name):
	# old l1lll11ll11l_l1_ l1ll11l1l1ll_l1_ l1l1l1lll1ll_l1_
	# hit method:    https://l11ll111lll_l1_.google.com/l11llll11ll_l1_/l1ll1l1ll111_l1_/collection/protocol/l1l1l1lll1ll_l1_/l1ll1ll11111_l1_
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡥࡲࡱ࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠳ࠩࡸ࡮ࡪ࠽ࡖࡃ࠰࠵࠷࠽࠰࠵࠷࠴࠴࠹࠳࠵ࠧࡥ࡬ࡨࡂ࠭㼫")+l11llll1111_l1_(32)+l11lll_l1_ (u"ࠩࠩࡸࡂ࡫ࡶࡦࡰࡷࠪࡸࡩ࠽ࡦࡰࡧࠪࡪࡩ࠽ࠨ㼬")+l11l1llllll_l1_+l11lll_l1_ (u"ࠪࠪࡦࡼ࠽ࠨ㼭")+l11l1llllll_l1_+l11lll_l1_ (u"ࠫࠫࡧ࡮࠾ࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࡠࡐࡈ࡛ࡈࡒࡉࡆࡐࡗࡍࡉࠬࡥࡢ࠿ࠪ㼮")+script_name+l11lll_l1_ (u"ࠬࠬࡥ࡭࠿ࠪ㼯")+str(kodi_version)+l11lll_l1_ (u"࠭ࠦࡻ࠿ࠪ㼰")+l11ll11l11l_l1_
	#response = l11lll111ll_l1_(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㼱"),url,l11lll_l1_ (u"ࠨࠩ㼲"),l11lll_l1_ (u"ࠩࠪ㼳"),l11lll_l1_ (u"ࠪࠫ㼴"),l11lll_l1_ (u"ࠫࠬ㼵"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ㼶"))
	# new l1ll1ll1llll_l1_ l1ll11l1l1ll_l1_ 4
	# l1l1ll111111_l1_ test:    https://l111llll1ll_l1_-l1lll1lllll_l1_-l111l11l1l1_l1_.google/l1ll1111l11l_l1_/l1llll1ll1l1_l1_-l1l1l1ll1l11_l1_
	# l1l1ll111111_l1_ json method:    https://l11ll111lll_l1_.google.com/l11llll11ll_l1_/l1ll1l1ll111_l1_/collection/protocol/l1ll1111l11l_l1_/l1ll11lll1l1_l1_/l1l1ll111111_l1_
	# l1l1ll111111_l1_ json method:    https://l11ll111lll_l1_.google.com/l11llll11ll_l1_/l1ll1l1ll111_l1_/collection/protocol/l1ll1111l11l_l1_/l1ll11lll1l1_l1_?l1l11ll1l1ll_l1_=l1l11l111l1l_l1_
	# l1l1ll111111_l1_ hit method:   https://www.l1lll1ll11l1_l1_.com/l1ll1111l11l_l1_-l1llll1lll11_l1_-protocol-l1lll11111l1_l1_
	# l1l1ll111111_l1_ hit method:   https://www.l1lll1ll11l1_l1_.com/l111l1l1111_l1_-l111ll111l1_l1_-google-l11llll11ll_l1_-l1llll1lll11_l1_-protocol-version-2
	# l1l1ll111111_l1_ params:  https://data.l1l11l1l1lll_l1_.com
	# l1l1l1llll1l_l1_ json method
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳ࡲࡶ࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡣࡳ࡭ࡤࡹࡥࡤࡴࡨࡸࡂ࠶࠭ࡷ࠳࠸ࡅࡩࡩࡒࡈࡣࡓ࡫ࡶࡸ࡯ࡨ࡮࠸࠽ࡐࡇࠦ࡮ࡧࡤࡷࡺࡸࡥ࡮ࡧࡱࡸࡤ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠧ㼷")
	#headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㼸"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ㼹")}
	#params = {l11lll_l1_ (u"ࠩࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ㼺"):l11l1llllll_l1_,l11lll_l1_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭㼻"):kodi_version}
	#data = {l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡣ࡮ࡪࠧ㼼"):l11llll1111_l1_(32),l11lll_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡷࠬ㼽"):[{l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㼾"):script_name,l11lll_l1_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ㼿"):params}]}
	#response = l11lll111ll_l1_(l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㽀"),url,str(data),headers,l11lll_l1_ (u"ࠩࠪ㽁"),l11lll_l1_ (u"ࠪࠫ㽂"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘ࠲࠷ࡳࡵࠩ㽃"))
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࡩࡻ࡫࡮ࡵࡐࡤࡱࡪࠓࠊࠊࡣࡳࡴ࡛࡫ࡲࡴ࡫ࡲࡲࠒࠐࠉࡰࡲࡨࡶࡦࡺࡩ࡯ࡩࡖࡽࡸࡺࡥ࡮ࡘࡨࡶࡸ࡯࡯࡯ࠏࠍࠍࡺࡧࡰࡷࠏࠍࠍࡺࡹࡥࡳࡡ࡬ࡨࠒࠐࠉࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠒࠐࠉࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡡࡹࡩࡷࡹࡩࡰࡰࠐࠎࠎ࡫ࡶࡦࡰࡷࡣࡳࡧ࡭ࡦࠏࠍࠍࠧࠨࠢ㽄")
	# l1l1l1llll1l_l1_ hit method (l11l11llll_l1_ l11l1l1l111_l1_ l1l11ll1l111_l1_)
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡤ࡫ࡧࡁࠬ㽅")+l11llll1111_l1_(32)+l11lll_l1_ (u"ࠧࠧࡡࡶࡁ࠶ࠬࡥ࡯࠿ࠪ㽆")+script_name+l11lll_l1_ (u"ࠨࠨࡸࡴ࠳ࡧࡶࡠࡸࡨࡶࡂ࠭㽇")+l11l1llllll_l1_+l11lll_l1_ (u"ࠩࠩࡹࡵ࠴࡫ࡰࡦ࡬ࡣࡻ࡫ࡲ࠾ࠩ㽈")+str(kodi_version)
	#url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡠࡦࡥ࡫ࡂ࠷ࠦࡤ࡫ࡧࡁ࠶࠾࠵࠷࠲࠷࠼࠹࠿࠷࠯࠳࠹࠽࠵࠷࠴࠶࠶࠸࠻ࠬ㽉")
	#l11ll11l11l_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴࡭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡀࡸࡀ࠶ࠫࡺࡩࡥ࠿ࡊ࠱ࡗࡖ࠷ࡒ࡛ࡈࡎ࠾ࡍ࠹ࠧࡡࡧࡦ࡬ࡃ࠱ࠧࡥ࡬ࡨࡂ࠭㽊")+str(l11ll11l11l_l1_)+l11lll_l1_ (u"ࠬ࠴ࠧ㽋")+str(int(time.time()))
	#url += l11lll_l1_ (u"࠭ࠦࡶࡣࡳࡺࡂ࠷࠹࠯࠳ࠩࡨࡹࡃࡋࡐࡆࡌࠩ࠷࠶ࡅࡎࡃࡇࠪࡪࡴ࠽ࡱࡣࡪࡩࡤࡼࡩࡦࡹࠩࡣࡪ࡫࠽࠲ࠨࡸ࡭ࡩࡃ࠲࠳࠴࠵࠱࠷࠸࠲࠳࠯࠶࠷࠸࠹ࠦࡠࡵࡶࡁ࠶࠭㽌")
	#response = l11lll111ll_l1_(l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㽍"),url,l11lll_l1_ (u"ࠨࠩ㽎"),l11lll_l1_ (u"ࠩࠪ㽏"),l11lll_l1_ (u"ࠪࠫ㽐"),l11lll_l1_ (u"ࠫࠬ㽑"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࠳࠱ࡴࡶࠪ㽒"))
	# l1l1l1llll1l_l1_ modified (not good l1l111ll1l1l_l1_)
	#l11ll11l11l_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳࡬࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠵ࠪࡹ࡯ࡤ࠾ࡉ࠰ࡖࡕ࠽ࡑ࡚ࡇࡍ࠽ࡌ࠿ࠦࡤ࡫ࡧࡁࠬ㽓")+l11llll1111_l1_(32)+l11lll_l1_ (u"ࠧࠧࡡࡶࡁ࠶ࠬࡥ࡯࠿ࠪ㽔")+script_name+l11lll_l1_ (u"ࠨࠨࡸࡴ࠳ࡧࡶࡠࡸࡨࡶࡂ࠭㽕")+l11l1llllll_l1_+l11lll_l1_ (u"ࠩࠩࡹࡦࡶࡶ࠾ࠩ㽖")+str(kodi_version)+l11lll_l1_ (u"ࠪࠪࡤࡶ࠽ࠨ㽗")+l11ll11l11l_l1_
	#l11ll1lll1l_l1_ = l11l1l1llll_l1_()
	#l1l1ll1l1ll1_l1_ = l11ll1lll1l_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭㽘"),1)[0]
	return response
def l11l1l1llll_l1_(l1l1ll1l1ll1_l1_=l11lll_l1_ (u"ࠬ࠭㽙")):
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲ࡯ࡳࡨࡧࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㽚")
	# l1l1l1lll1ll_l1_   url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡻ࡭ࡵࡩࡴ࠰ࡤࡴࡵ࠵ࡪࡴࡱࡱ࠳ࠬ㽛")+l1l1ll1l1ll1_l1_
	# l11l1ll111l_l1_   url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿ࡦࡳࡳࡺࡩ࡯ࡧࡱࡸ࠱ࡩ࡯ࡶࡰࡷࡶࡾ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭㽜")
	l1l1l11l111l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡶࡸࡷ࠭㽝"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㽞"),l11lll_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ㽟"))
	if l1l1l11l111l_l1_: return l1l1l11l111l_l1_
	l1l1ll1l1ll1_l1_,l1l1l11ll1ll_l1_,l1ll111l1l11_l1_,l11l1l111l1_l1_,l1ll111l11ll_l1_,l1llll11l1ll_l1_,timezone = l11lll_l1_ (u"ࠬ࠭㽠"),l11lll_l1_ (u"࠭ࠧ㽡"),l11lll_l1_ (u"ࠧࠨ㽢"),l11lll_l1_ (u"ࠨࠩ㽣"),l11lll_l1_ (u"ࠩࠪ㽤"),l11lll_l1_ (u"ࠪࠫ㽥"),l11lll_l1_ (u"ࠫࠬ㽦")
	url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ㽧")+l1l1ll1l1ll1_l1_+l11lll_l1_ (u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㽨")
	headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㽩"):l11lll_l1_ (u"ࠨࠩ㽪")}
	response = l11lll111ll_l1_(l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㽫"),url,l11lll_l1_ (u"ࠪࠫ㽬"),headers,l11lll_l1_ (u"ࠫࠬ㽭"),l11lll_l1_ (u"ࠬ࠭㽮"),l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㽯"))
	if not response.succeeded: l1lll1ll1lll_l1_ = l1l1ll1l1ll1_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ㽰")+l1l1l11ll1ll_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ㽱")+l1ll111l1l11_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ㽲")+l1ll111l11ll_l1_+l11lll_l1_ (u"ࠪ࠰ࠬ㽳")+l1llll11l1ll_l1_+l11lll_l1_ (u"ࠫ࠱࠭㽴")+timezone
	else:
		html = response.content
		html = re.findall(l11lll_l1_ (u"ࠬࡢࡻ࠯ࠬࡂࡠࢂࡢࡽࠨ㽵"),html,re.DOTALL)
		if html:
			html = html[0]
			l11111ll111_l1_ = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ㽶"),html)
			if l11lll_l1_ (u"ࠧࡪࡲࠪ㽷") in list(l11111ll111_l1_.keys()): l1l1ll1l1ll1_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠨ࡫ࡳࠫ㽸")]
			if l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ㽹") in list(l11111ll111_l1_.keys()): l1l1l11ll1ll_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭㽺")]
			if l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㽻") in list(l11111ll111_l1_.keys()): l1ll111l1l11_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㽼")]
			if l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࠬ㽽") in list(l11111ll111_l1_.keys()): l11l1l111l1_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭㽾")]
			if l11lll_l1_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ㽿") in list(l11111ll111_l1_.keys()): l1ll111l11ll_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ㾀")]
			if l11lll_l1_ (u"ࠪࡧ࡮ࡺࡹࠨ㾁") in list(l11111ll111_l1_.keys()): l1llll11l1ll_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ㾂")]
			if l11lll_l1_ (u"ࠬࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ㾃") in list(l11111ll111_l1_.keys()):
				timezone = l11111ll111_l1_[l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㾄")][l11lll_l1_ (u"ࠧࡶࡶࡦࠫ㾅")]
				if timezone[0] not in [l11lll_l1_ (u"ࠨ࠯ࠪ㾆"),l11lll_l1_ (u"ࠩ࠮ࠫ㾇")]: timezone = l11lll_l1_ (u"ࠪ࠯ࠬ㾈")+timezone
			l1lll1ll1lll_l1_ = l1l1ll1l1ll1_l1_+l11lll_l1_ (u"ࠫ࠱࠭㾉")+l1l1l11ll1ll_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ㾊")+l1ll111l1l11_l1_+l11lll_l1_ (u"࠭ࠬࠨ㾋")+l1ll111l11ll_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ㾌")+l1llll11l1ll_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ㾍")+timezone
			if kodi_version>18.99: l1lll1ll1lll_l1_ = l1lll1ll1lll_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㾎")).decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㾏"))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㾐"),l11lll_l1_ (u"ࠬࡏࡐࡍࡑࡆࡅ࡙ࡏࡏࡏࠩ㾑"),l1lll1ll1lll_l1_,l1lll1111_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㾒"),l1lll1ll1lll_l1_)
	return l1lll1ll1lll_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11lll_l1_ (u"ࠧࠨ㾓"),True
	if search.count(l11lll_l1_ (u"ࠨࡡࠪ㾔"))>=2:
		search,options = search.split(l11lll_l1_ (u"ࠩࡢࠫ㾕"),1)
		options = l11lll_l1_ (u"ࠪࡣࠬ㾖")+options
		if l11lll_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ㾗") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㾘"),l11lll_l1_ (u"࠭ࠧ㾙"),search,options)
	return search,options,l1ll_l1_
def l1l11l111ll1_l1_():
	l1l1lll1l1l1_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㾚"))
	l1ll1ll1l111_l1_ = 0
	if os.path.exists(l1l1lll1l1l1_l1_):
		for filename in os.listdir(l1l1lll1l1l1_l1_):
			if l11lll_l1_ (u"ࠨ࠰ࡳࡽࡴ࠭㾛") in filename: continue
			if l11lll_l1_ (u"ࠩࡢࡣࡵࡿࡣࡢࡥ࡫ࡩࡤࡥࠧ㾜") in filename: continue
			l1l11l1l1l_l1_ = os.path.join(l1l1lll1l1l1_l1_,filename)
			size,count = l1l1l1l111_l1_(l1l11l1l1l_l1_)
			l1ll1ll1l111_l1_ += size
	return l1ll1ll1l111_l1_
def l11111l1ll1_l1_(l11llllll11_l1_,l1ll_l1_):
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㾝")][3]
	user = l11llll1111_l1_(32)
	l1lll1ll1lll_l1_ = l11l1l1llll_l1_()
	l1ll111l1l11_l1_ = l1lll1ll1lll_l1_.split(l11lll_l1_ (u"ࠫ࠱࠭㾞"))[2]
	l1ll1ll1l111_l1_ = l1l11l111ll1_l1_()
	payload = {l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ㾟"):user,l11lll_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ㾠"):l11l1llllll_l1_,l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ㾡"):l1ll111l1l11_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࡷࠬ㾢"):l1l1lll11l11_l1_(l1ll1ll1l111_l1_)}
	if not l11llllll11_l1_: DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ㾣"),(l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㾤"),url,payload,l11lll_l1_ (u"ࠫࠬ㾥"),l11lll_l1_ (u"ࠬ࠭㾦"),l11lll_l1_ (u"࠭ࠧ㾧")))
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㾨"),l11lll_l1_ (u"ࠨࠩ㾩"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㾪"),url,payload,l11lll_l1_ (u"ࠪࠫ㾫"),l11lll_l1_ (u"ࠫࠬ㾬"),l11lll_l1_ (u"ࠬ࠭㾭"),l11lll_l1_ (u"࠭ࡍࡆࡐࡘࡗ࠲࡙ࡈࡐ࡙ࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ㾮"),True,True)
	l11l1111l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㾯"))
	if not l11l1111l1l_l1_: l11l1111l1l_l1_ = l11lll_l1_ (u"ࠨࡐࡈ࡛ࠬ㾰")
	l1ll11111111_l1_ = l11l1111l1l_l1_
	if not response.succeeded: l1ll11111111_l1_ = l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࠨ㾱")
	else:
		l11ll11ll11_l1_,l1lll1llllll_l1_,l1llll11l1l1_l1_,l1llll11111l_l1_ = l11lll_l1_ (u"ࠪࠫ㾲"),l11lll_l1_ (u"ࠫࠬ㾳"),l11lll_l1_ (u"ࠬ࠭㾴"),[]
		newfile = response.content
		if newfile:
			l1llll11111l_l1_ = EVAL(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ㾵"),newfile)
			for l1ll1l11lll1_l1_,l1l1l1l111l1_l1_,message in l1llll11111l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㾶")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㾷"))
				if l1ll1l11lll1_l1_==l11lll_l1_ (u"ࠩ࠳ࠫ㾸"): l11ll11ll11_l1_ += message+l11lll_l1_ (u"ࠪ࠾࠿࠭㾹")
				else: l1lll1llllll_l1_ += message+l11lll_l1_ (u"ࠫࡡࡴࠧ㾺")
			l1lll1llllll_l1_ = l1lll1llllll_l1_.strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㾻"))
			l11ll11ll11_l1_ = l11ll11ll11_l1_.strip(l11lll_l1_ (u"࠭࠺࠻ࠩ㾼"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ㾽"),l11ll11ll11_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㾾"),l1l1lll11l11_l1_(now))
		if os.path.exists(l1l1111llll1_l1_): l1llll11l1l1_l1_ = open(l1l1111llll1_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ㾿")).read()
		if kodi_version>18.99: l1lll1llllll_l1_ = l1lll1llllll_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㿀"))
		if l1lll1llllll_l1_!=l1llll11l1l1_l1_:
			l1ll11111111_l1_ = l11lll_l1_ (u"ࠫࡓࡋࡗࠨ㿁")
			try: open(l1l1111llll1_l1_,l11lll_l1_ (u"ࠬࡽࡢࠨ㿂")).write(l1lll1llllll_l1_)
			except: pass
		if l1ll_l1_:
			l1llll11111l_l1_ = sorted(l1llll11111l_l1_,reverse=True,key=lambda key: int(key[0]))
			l1llll11l11l_l1_ = l11lll_l1_ (u"࠭ࠧ㿃")
			for l1ll1l11lll1_l1_,l1l1l1l111l1_l1_,message in l1llll11111l_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㿄")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㿅"))
				if l1llll11l11l_l1_: l1llll11l11l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪ㿆")
				if l1ll1l11lll1_l1_==l11lll_l1_ (u"ࠪ࠴ࠬ㿇"): continue
				date = message.split(l11lll_l1_ (u"ࠫࡡࡴࠧ㿈"))[0]
				l1lll1ll1_l1_ = l11lll_l1_ (u"ࠬ࠭㿉")
				if l1l1l1l111l1_l1_:
					l1lll1ll1_l1_ = l11lll_l1_ (u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪ㿊")
					if kodi_version>18.99: l1lll1ll1_l1_ = l1lll1ll1_l1_.encode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㿋")).decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㿌"))
				l1llll11l11l_l1_ += message.replace(date,l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㿍")+date+l1lll1ll1_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㿎"))+l11lll_l1_ (u"ࠫࡡࡴࠧ㿏")
			l1llll11l11l_l1_ = escapeUNICODE(l1llll11l11l_l1_)
			l11ll1l1l1_l1_(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㿐"),l11lll_l1_ (u"࠭ัิษษ่๋ࠥๆࠡษ็้อืๅอࠢศ่๎ࠦๅิฬัำ๊๐ࠠศๆหี๋อๅอࠩ㿑"),l1llll11l11l_l1_,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ㿒"))
			l1ll11111111_l1_ = l11lll_l1_ (u"ࠨࡑࡏࡈࠬ㿓")
	if l1ll11111111_l1_!=l11l1111l1l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㿔"),l1ll11111111_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㿕"))
	return l1ll11111111_l1_
def l11l1llll1_l1_(url,l1l1ll11_l1_=l11lll_l1_ (u"ࠫࠬ㿖")):
	l111llll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࡜࠯ࡣࡹ࡭ࢁࡢ࠮ࡵࡵࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭㿗"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111llll11_l1_: l111llll11_l1_ = l111llll11_l1_[0][0]
	else: l111llll11_l1_ = l11lll_l1_ (u"࠭ࠧ㿘")
	return l111llll11_l1_
	#elif not l111llll11_l1_ and l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ㿙") in l1l1ll11_l1_: l111llll11_l1_ = l11lll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭㿚")
	#elif not l111llll11_l1_ and l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ㿛") in l1l1ll11_l1_: l111llll11_l1_ = l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ㿜")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l11lllllll_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l11lllllll_l1_ = False
	l11l1111l1_l1_ = time.time()
	if l1l11lllllll_l1_: resp = l11l1111l1_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ㿝"),l11lll_l1_ (u"ࠬ࠭㿞"),l11lll_l1_ (u"࠭ࠧ㿟"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㿠"),l11lll_l1_ (u"ࠨี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฬส฻ไศฯࠣ์ฯ์ุ๋ใࠣะ๊๐ูࠡไ๋ห฾ีࠠศๆห๎ฬ์วห๋ࠢห้้วีࠢสู่๊สฯั่อࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎ู้ࠦๆๆํอࠥอไห่฻๎ๆࠦวๅฤ้ࠤฤࠧࠧ㿡"))
	else: l1ll11l111_l1_ = True
	if l1ll11l111_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11lll_l1_ (u"ࠩ࠱ࡨࡧ࠭㿢")) and l11lll_l1_ (u"ࠪࡨࡦࡺࡡࠨ㿣") in filename:
				l1l1ll11ll_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l11111l1l_l1_(l1l1ll11ll_l1_)
				except: return
				cc.execute(l11lll_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮ࡴࡴࡦࡩࡵ࡭ࡹࡿ࡟ࡤࡪࡨࡧࡰࡁࠧ㿤"))
				cc.execute(l11lll_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡵࡰࡵ࡫ࡰ࡭ࡿ࡫࠻ࠨ㿥"))
				cc.execute(l11lll_l1_ (u"࠭ࡖࡂࡅࡘ࡙ࡒࡁࠧ㿦"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㿧"),l11lll_l1_ (u"ࠨࠩ㿨"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㿩"),l11lll_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ㿪"))
	return
def l1l1lll1l111_l1_(word):
	if l11lll_l1_ (u"ࠫࡠ࠭㿫") in word and l11lll_l1_ (u"ࠬࡣࠧ㿬") in word:
		l111ll11ll1_l1_ = [l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㿭"),l11lll_l1_ (u"ࠧ࡜࠱ࡕࡘࡑࡣࠧ㿮"),l11lll_l1_ (u"ࠨ࡝࠲ࡐࡊࡌࡔ࡞ࠩ㿯"),l11lll_l1_ (u"ࠩ࡞࠳ࡗࡏࡇࡉࡖࡠࠫ㿰"),l11lll_l1_ (u"ࠪ࡟࠴ࡉࡅࡏࡖࡈࡖࡢ࠭㿱"),l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㿲"),l11lll_l1_ (u"ࠬࡡࡌࡆࡈࡗࡡࠬ㿳"),l11lll_l1_ (u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ㿴"),l11lll_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ㿵")]
		l1l1l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞࡞ࡇࡔࡒࡏࡓࠢ࠱࠮ࡄࡢ࡝ࠨ㿶"),word,re.DOTALL)
		l111l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠴ࠪࡀ࡞ࡠࠫ㿷"),word,re.DOTALL)
		l1l1l11llll1_l1_ = l111ll11ll1_l1_+l1l1l111ll1l_l1_+l111l1l111l_l1_
		for tag in l1l1l11llll1_l1_: word = word.replace(tag,l11lll_l1_ (u"ࠪࠫ㿸"))
	return word
def l1ll1l1l111l_l1_(l11l1l11lll_l1_,l1lll1l1111l_l1_,l1ll11l11l1l_l1_,l1l1ll11111l_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll1111l_l1_,l1111l1ll11_l1_,l1l11ll11l1l_l1_ = l11lll_l1_ (u"ࠫࠬ㿹"),0,15000
	l11l1l11lll_l1_ = l11l1l11lll_l1_.replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭㿺"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠩࠣࠤࠩ㿻"))
	l1l111lll111_l1_ = PIL.ImageFont.truetype(l1lll1l11lll_l1_,size=l1lll1l1111l_l1_)
	l1ll11l11l1l_l1_ -= l1lll1l1111l_l1_*2
	txt = PIL.Image.new(l11lll_l1_ (u"ࠧࡓࡉࡅࡅࠬ㿼"),(l1ll11l11l1l_l1_,99),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l1l1111l11_l1_ in l11l1l11lll_l1_.splitlines():
		l1111l1ll11_l1_ += l1l1ll11111l_l1_
		l1lll1l11l1l_l1_,newline = 0,l11lll_l1_ (u"ࠨࠩ㿽")
		for word in l1l1l1111l11_l1_.split(l11lll_l1_ (u"ࠩࠣࠫ㿾")):
			l1lllll11l11_l1_ = l1l1lll1l111_l1_(l11lll_l1_ (u"ࠪࠤࠬ㿿")+word)
			l1l1l1l111ll_l1_,l1lllll1l1ll_l1_ = l1llllll1lll_l1_.textsize(l1lllll11l11_l1_,font=l1l111lll111_l1_)
			if l1lll1l11l1l_l1_+l1l1l1l111ll_l1_<l1ll11l11l1l_l1_:
				if not newline: newline += word
				else: newline += l11lll_l1_ (u"ࠫࠥ࠭䀀")+word
				l1lll1l11l1l_l1_ += l1l1l1l111ll_l1_
			else:
				if l1l1l1l111ll_l1_<l1ll11l11l1l_l1_:
					newline += l11lll_l1_ (u"ࠬࡢ࡮ࠡࠩ䀁")+word
					l1111l1ll11_l1_ += l1l1ll11111l_l1_
					l1lll1l11l1l_l1_ = l1l1l1l111ll_l1_
				else:
					while l1l1l1l111ll_l1_>l1ll11l11l1l_l1_:
						for l11ll111l1_l1_ in range(1,len(l11lll_l1_ (u"࠭ࠠࠨ䀂")+word),1):
							l1lllllll1l1_l1_ = l11lll_l1_ (u"ࠧࠡࠩ䀃")+word[:l11ll111l1_l1_]
							l11111lll1_l1_ = word[l11ll111l1_l1_:]
							l1l11l1l11ll_l1_ = l1l1lll1l111_l1_(l1lllllll1l1_l1_)
							l111l1ll11l_l1_,l1llll1l1111_l1_ = l1llllll1lll_l1_.textsize(l1l11l1l11ll_l1_,font=l1l111lll111_l1_)
							if l1lll1l11l1l_l1_+l111l1ll11l_l1_>l1ll11l11l1l_l1_:
								l1ll111l111l_l1_ = l1l1l1l111ll_l1_-l111l1ll11l_l1_
								newline += l1lllllll1l1_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ䀄")
								l1111l1ll11_l1_ += l1l1ll11111l_l1_
								l1l1l1l111ll_l1_ = l1ll111l111l_l1_
								if l1ll111l111l_l1_>l1ll11l11l1l_l1_:
									l1lll1l11l1l_l1_ = 0
									word = l11111lll1_l1_
								else:
									l1lll1l11l1l_l1_ = l1ll111l111l_l1_
									newline += l11111lll1_l1_
								break
				if l1111l1ll11_l1_>l1l11ll11l1l_l1_: break
		l111ll1111l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ䀅")+newline
		if l1111l1ll11_l1_>l1l11ll11l1l_l1_: break
	l111ll1111l_l1_ = l111ll1111l_l1_[1:]
	l111ll1111l_l1_ = l111ll1111l_l1_.replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠭䀆"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ䀇"))
	return l111ll1111l_l1_
def l1111lll1l1_l1_(text):
	text = text.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䀈"),l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸ࡮࡬ࡲࡪࡥࠧ䀉"))
	text = text.replace(l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭䀊"),l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ䀋"))
	text = text.replace(l11lll_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ䀌"),l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ䀍"))
	text = text.replace(l11lll_l1_ (u"ࠫࡠࡘࡉࡈࡊࡗࡡࠬ䀎"),l11lll_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ䀏"))
	text = text.replace(l11lll_l1_ (u"࡛࠭ࡄࡇࡑࡘࡊࡘ࡝ࠨ䀐"),l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ䀑"))
	text = text.replace(l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䀒"),l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡧࡱࡨࡨࡵ࡬ࡰࡴࡢࠫ䀓"))
	l1ll1ll11l1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠭࠴ࠪࡀࠫ࡟ࡡࠬ䀔"),text,re.DOTALL)
	for l1ll1111l1l1_l1_ in l1ll1ll11l1l_l1_: text = text.replace(l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࠬ䀕")+l1ll1111l1l1_l1_+l11lll_l1_ (u"ࠬࡣࠧ䀖"),l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ䀗")+l1ll1111l1l1_l1_+l11lll_l1_ (u"ࠧࡠࠩ䀘"))
	return text
def l1l11ll11111_l1_(l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text,l1llllll111_l1_,l111l1llll1_l1_,l1l1lllll1ll_l1_,l1l1ll1ll111_l1_):
	l1lll1111l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ䀙"))
	if l1lll1111l11_l1_:
		results = LANGUAGE_TRANSLATE([l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text])
		if results: l1llll1l11l1_l1_,l1l1l111l1l1_l1_,l1llll1l1lll_l1_,header,text = results
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䀚"))
		header = header.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䀛"))
		l1llll1l11l1_l1_ = l1llll1l11l1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䀜"))
		l1l1l111l1l1_l1_ = l1l1l111l1l1_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䀝"))
		l1llll1l1lll_l1_ = l1llll1l1lll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䀞"))
	l1lllll1llll_l1_ = 5
	l1l111ll1l11_l1_ = 20
	l1ll1l111l1l_l1_ = 20
	l1ll111l1ll1_l1_ = 0
	l11l1l1l11l_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䀟")
	l1l11l1ll1l1_l1_ = 0
	l1l11lll1111_l1_ = 19
	l1111l1l1ll_l1_ = 30
	l1ll11lllll1_l1_ = 8
	l1ll1111lll1_l1_ = True
	l1l1l111l1ll_l1_ = 375
	l1l11l111111_l1_ = 410
	l1l1ll1l111l_l1_ = 50
	l1l1ll1111ll_l1_ = 280
	l1llll111lll_l1_ = 28
	l1l11l1l11l1_l1_ = 5
	l1lll11l11ll_l1_ = 0
	l1ll11l11l11_l1_ = 31
	l111111l1ll_l1_ = [36,32,28]
	if l1llllll111_l1_ in [l11lll_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ䀠"),l11lll_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ䀡")]:
		if l1llllll111_l1_==l11lll_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ䀢"):
			l11l1l11l11_l1_ = l11lll_l1_ (u"࡚ࠫࡖࡐࡆࡔࠪ䀣")
			l11l1l1l11l_l1_ = l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䀤")
			l1ll1111lll1_l1_ = True
			l1ll111l1ll1_l1_ = 10
		else:
			l11l1l11l11_l1_ = 97+20
			l11l1l1l11l_l1_ = l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ䀥")
			l1ll1111lll1_l1_ = False
		l111111l1ll_l1_ = [33,33,33]
		l1ll1l111l1l_l1_ = 20
		l1l111ll1l11_l1_ = 0
		l1111l1l1ll_l1_ = 20
		l1l11lll1111_l1_ = 25+10
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ䀦"): l111111l1ll_l1_ = [28,24,20] ; l11l1l11l11_l1_ = 500
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭䀧"): l111111l1ll_l1_ = [32,28,24] ; l11l1l11l11_l1_ = 500
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ䀨"): l111111l1ll_l1_ = [36,32,28] ; l11l1l11l11_l1_ = 500
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭䀩"): l11l1l11l11_l1_ = 740
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ䀪"): l11l1l11l11_l1_ = l11lll_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ䀫")
	elif l1llllll111_l1_==l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ䀬"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = 740
	elif l1llllll111_l1_==l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ䀭"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = l11lll_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ䀮")
	l1lll11llll1_l1_ = l111111l1ll_l1_[0]
	l11111ll1ll_l1_ = l111111l1ll_l1_[1]
	l11l11lll1l_l1_ = l111111l1ll_l1_[2]
	l1lll1l1l111_l1_ = PIL.ImageFont.truetype(l1lll1l11lll_l1_,size=l1lll11llll1_l1_)
	l1ll1l11l1ll_l1_ = PIL.ImageFont.truetype(l1lll1l11lll_l1_,size=l11111ll1ll_l1_)
	l1ll1ll11l11_l1_ = PIL.ImageFont.truetype(l1lll1l11lll_l1_,size=l11l11lll1l_l1_)
	txt = PIL.Image.new(l11lll_l1_ (u"ࠩࡕࡋࡇࡇࠧ䀯"),(100,100),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	l1lllll11lll_l1_,l1l1lll1l1ll_l1_ = l1llllll1lll_l1_.textsize(l11lll_l1_ (u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬ䀰"),font=l1ll1l11l1ll_l1_)
	l1l1l1111ll1_l1_,l1llll11ll1l_l1_ = l1llllll1lll_l1_.textsize(l11lll_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭䀱"),font=l1lll1l1l111_l1_)
	l1l11l1lll11_l1_ = header.count(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䀲"))+1
	l1l1ll1lll11_l1_ = l1l111ll1l11_l1_+l1l11l1lll11_l1_*(l1llll11ll1l_l1_+l1ll111l1ll1_l1_)-l1ll111l1ll1_l1_
	l1l11ll11ll1_l1_ = {l11lll_l1_ (u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡨࡢࡴࡤ࡯ࡦࡺࠧ䀳"):False,l11lll_l1_ (u"ࠧࡴࡷࡳࡴࡴࡸࡴࡠ࡮࡬࡫ࡦࡺࡵࡳࡧࡶࠫ䀴"):True,l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࠡࡎࡌࡋࡆ࡚ࡕࡓࡇࠣࡅࡑࡒࡁࡉࠩ䀵"):False}
	l111l1l1ll1_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l11ll11ll1_l1_)
	if text:
		l11l11ll1ll_l1_ = l1l1lllll1ll_l1_-l1111l1l1ll_l1_*2
		l1l11ll1lll1_l1_ = l1l1lll1l1ll_l1_+l1ll11lllll1_l1_
		l1ll111111l1_l1_ = l111l1l1ll1_l1_.reshape(text)
		if l1ll1111lll1_l1_:
			l1l1111l1ll1_l1_ = l1ll1l1l111l_l1_(l1ll111111l1_l1_,l11111ll1ll_l1_,l11l11ll1ll_l1_,l1l11ll1lll1_l1_)
			l1ll1llllll1_l1_ = l1l1lll1l111_l1_(l1l1111l1ll1_l1_)
			l1l1llllll1l_l1_ = l1ll1llllll1_l1_.count(l11lll_l1_ (u"ࠩ࡟ࡲࠬ䀶"))+1
			if l1l1llllll1l_l1_<6:
				#l1l1l111lll1_l1_ = int(0.8*l11l11ll1ll_l1_) if l1l1llllll1l_l1_<4 else int(0.9*l11l11ll1ll_l1_)
				l1l1l111lll1_l1_ = l11l11ll1ll_l1_
				l1l1111l1ll1_l1_ = l1ll1l1l111l_l1_(l1ll111111l1_l1_,l11111ll1ll_l1_,l1l1l111lll1_l1_,l1l11ll1lll1_l1_)
				l1ll1llllll1_l1_ = l1l1lll1l111_l1_(l1l1111l1ll1_l1_)
				l1l1llllll1l_l1_ = l1ll1llllll1_l1_.count(l11lll_l1_ (u"ࠪࡠࡳ࠭䀷"))+1
			l111lll1l1l_l1_ = l1l11lll1111_l1_+l1l1llllll1l_l1_*l1l11ll1lll1_l1_-l1ll11lllll1_l1_
		else:
			l111lll1l1l_l1_ = l1l11lll1111_l1_+l1l1lll1l1ll_l1_
			l1ll1llllll1_l1_ = l1ll111111l1_l1_.split(l11lll_l1_ (u"ࠫࡡࡴࠧ䀸"))[0]
			l1l1111l1ll1_l1_ = l1ll111111l1_l1_.split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䀹"))[0]
	else: l111lll1l1l_l1_ = l1l11lll1111_l1_
	l1ll111lll11_l1_ = l1lll11l11ll_l1_+l1ll11l11l11_l1_
	if l1l1ll1ll111_l1_:
		l1l1l1l1ll11_l1_ = l1l11l111111_l1_-l1l1l111l1ll_l1_
		l1ll111lll11_l1_ += l1l1l1l1ll11_l1_
	else: l1l1l1l1ll11_l1_ = 0
	if l1llll1l11l1_l1_ or l1l1l111l1l1_l1_ or l1llll1l1lll_l1_: l1ll111lll11_l1_ += l1l1ll1l111l_l1_
	if l11l1l11l11_l1_!=l11lll_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ䀺"): l1111111ll1_l1_ = l11l1l11l11_l1_
	else: l1111111ll1_l1_ = l1l1ll1lll11_l1_+l111lll1l1l_l1_+l1ll111lll11_l1_
	l1ll1lll11l1_l1_ = l1111111ll1_l1_-l1l1ll1lll11_l1_-l1ll111lll11_l1_-l1l11lll1111_l1_
	txt = PIL.Image.new(l11lll_l1_ (u"ࠧࡓࡉࡅࡅࠬ䀻"),(l1l1lllll1ll_l1_,l1111111ll1_l1_),(255,255,255,0))
	l1llllll1lll_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l1l111l1l1_l1_ and l1llll1l11l1_l1_ and l1llll1l1lll_l1_:
		l1llll111lll_l1_ += 105
		l1l11l1l11l1_l1_ -= 110
	if header:
		l1llllll1111_l1_ = l1l111ll1l11_l1_
		header = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1ll11111ll1_l1_ = l1llllll1lll_l1_.textsize(line,font=l1lll1l1l111_l1_)
				if l11l1l1l11l_l1_==l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䀼"): l1l1l11l11ll_l1_ = l1lllll1llll_l1_+(l1l1lllll1ll_l1_-width)/2
				elif l11l1l1l11l_l1_==l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ䀽"): l1l1l11l11ll_l1_ = l1lllll1llll_l1_+l1l1lllll1ll_l1_-width-l1ll1l111l1l_l1_
				elif l11l1l1l11l_l1_==l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ䀾"): l1l1l11l11ll_l1_ = l1lllll1llll_l1_+l1ll1l111l1l_l1_
				l1llllll1lll_l1_.text((l1l1l11l11ll_l1_,l1llllll1111_l1_),line,font=l1lll1l1l111_l1_,fill=l11lll_l1_ (u"ࠫࡾ࡫࡬࡭ࡱࡺࠫ䀿"))
			l1llllll1111_l1_ += l1lll11llll1_l1_+l1ll111l1ll1_l1_
	if l1llll1l11l1_l1_ or l1l1l111l1l1_l1_ or l1llll1l1lll_l1_:
		l1llll11l111_l1_ = l1l1ll1lll11_l1_+l1ll1lll11l1_l1_+l1l11lll1111_l1_+l1l1l1l1ll11_l1_+l1lll11l11ll_l1_
		if l1llll1l11l1_l1_:
			l1llll1l11l1_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1llll1l11l1_l1_))
			l1l1llll1111_l1_,l11111111l1_l1_ = l1llllll1lll_l1_.textsize(l1llll1l11l1_l1_,font=l1ll1ll11l11_l1_)
			l111111l1l1_l1_ = l1llll111lll_l1_+0*(l1l11l1l11l1_l1_+l1l1ll1111ll_l1_)+(l1l1ll1111ll_l1_-l1l1llll1111_l1_)/2
			l1llllll1lll_l1_.text((l111111l1l1_l1_,l1llll11l111_l1_),l1llll1l11l1_l1_,font=l1ll1ll11l11_l1_,fill=l11lll_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ䁀"))
		if l1l1l111l1l1_l1_:
			l1l1l111l1l1_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1l1l111l1l1_l1_))
			l1ll11llllll_l1_,l1ll11l1l11l_l1_ = l1llllll1lll_l1_.textsize(l1l1l111l1l1_l1_,font=l1ll1ll11l11_l1_)
			l11111ll1l1_l1_ = l1llll111lll_l1_+1*(l1l11l1l11l1_l1_+l1l1ll1111ll_l1_)+(l1l1ll1111ll_l1_-l1ll11llllll_l1_)/2
			l1llllll1lll_l1_.text((l11111ll1l1_l1_,l1llll11l111_l1_),l1l1l111l1l1_l1_,font=l1ll1ll11l11_l1_,fill=l11lll_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭䁁"))
		if l1llll1l1lll_l1_:
			l1llll1l1lll_l1_ = bidi.algorithm.get_display(l111l1l1ll1_l1_.reshape(l1llll1l1lll_l1_))
			l111l11l111_l1_,l11l11llll1_l1_ = l1llllll1lll_l1_.textsize(l1llll1l1lll_l1_,font=l1ll1ll11l11_l1_)
			l1lll11l1111_l1_ = l1llll111lll_l1_+2*(l1l11l1l11l1_l1_+l1l1ll1111ll_l1_)+(l1l1ll1111ll_l1_-l111l11l111_l1_)/2
			l1llllll1lll_l1_.text((l1lll11l1111_l1_,l1llll11l111_l1_),l1llll1l1lll_l1_,font=l1ll1ll11l11_l1_,fill=l11lll_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ䁂"))
	if text:
		l1l111l1ll11_l1_,l111l11llll_l1_ = [],[]
		l1l1111l1ll1_l1_ = l1111lll1l1_l1_(l1l1111l1ll1_l1_)
		l1l11ll1llll_l1_ = l1l1111l1ll1_l1_.split(l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ䁃"))
		for l1l11l11l11l_l1_ in l1l11ll1llll_l1_:
			l111llll1l1_l1_ = l111l1llll1_l1_
			if   l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ䁄") in l1l11l11l11l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ䁅")
			elif l11lll_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ䁆") in l1l11l11l11l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䁇")
			elif l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ䁈") in l1l11l11l11l_l1_: l111llll1l1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䁉")
			l11l11111l1_l1_ = l1l11l11l11l_l1_
			l111ll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࠯ࠬࡂࡣࠬ䁊"),l1l11l11l11l_l1_,re.DOTALL)
			for tag in l111ll11ll1_l1_: l11l11111l1_l1_ = l11l11111l1_l1_.replace(tag,l11lll_l1_ (u"ࠩࠪ䁋"))
			if l11l11111l1_l1_==l11lll_l1_ (u"ࠪࠫ䁌"): width,l1ll11111ll1_l1_ = 0,l1l11ll1lll1_l1_
			else: width,l1ll11111ll1_l1_ = l1llllll1lll_l1_.textsize(l11l11111l1_l1_,font=l1ll1l11l1ll_l1_)
			if   l111llll1l1_l1_==l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ䁍"): l1lll1lll11l_l1_ = l1l11l1ll1l1_l1_+l1111l1l1ll_l1_
			elif l111llll1l1_l1_==l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ䁎"): l1lll1lll11l_l1_ = l1l11l1ll1l1_l1_+l1111l1l1ll_l1_+l11l11ll1ll_l1_-width
			elif l111llll1l1_l1_==l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭䁏"): l1lll1lll11l_l1_ = l1l11l1ll1l1_l1_+l1111l1l1ll_l1_+(l11l11ll1ll_l1_-width)/2
			if l1lll1lll11l_l1_<l1111l1l1ll_l1_: l1lll1lll11l_l1_ = l1l11l1ll1l1_l1_+l1111l1l1ll_l1_
			l1l111l1ll11_l1_.append(l1lll1lll11l_l1_)
			l111l11llll_l1_.append(width)
		l1lll1lll11l_l1_ = l1l111l1ll11_l1_[0]
		l1l1l11l1111_l1_ = l1l1111l1ll1_l1_.split(l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤ࠭䁐"))
		l11l111ll1l_l1_ = (255,255,255,255)
		l1ll1l1l1111_l1_ = l11l111ll1l_l1_
		l1l11ll1ll11_l1_,l1ll11ll1lll_l1_ = 0,0
		l1lll111lll1_l1_ = False
		l1llll1llll1_l1_ = 0
		l1l11l1ll1ll_l1_ = l1l1ll1lll11_l1_+l1l11lll1111_l1_/2
		if l111lll1l1l_l1_<(l1ll1lll11l1_l1_+l1l11lll1111_l1_):
			l1lllll1ll11_l1_ = (l1ll1lll11l1_l1_+l1l11lll1111_l1_-l111lll1l1l_l1_)/2
			l1l11l1ll1ll_l1_ = l1l1ll1lll11_l1_+l1l11lll1111_l1_+l1lllll1ll11_l1_-l1l1lll1l1ll_l1_/2
		for line in l1l1l11l1111_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1l1l11lll_l1_ = line.split(l11lll_l1_ (u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ䁑"),1)
			l1l1l1l1l111_l1_ = line.split(l11lll_l1_ (u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ䁒"),1)
			l1l1l1l1l11l_l1_ = line.split(l11lll_l1_ (u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ䁓"),1)
			l1ll1l1llll1_l1_ = line.split(l11lll_l1_ (u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ䁔"),1)
			l1ll1ll1111l_l1_ = line.split(l11lll_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ䁕"),1)
			l1ll1ll111l1_l1_ = line.split(l11lll_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ䁖"),1)
			l1l1l1l11ll1_l1_ = line.split(l11lll_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭䁗"),1)
			if len(l1l1l1l11lll_l1_)>1:
				l1llll1llll1_l1_ += 1
				line = l1l1l1l11lll_l1_[1]
				l1l11ll1ll11_l1_ = 0
				l1lll1lll11l_l1_ = l1l111l1ll11_l1_[l1llll1llll1_l1_]
				l1ll11ll1lll_l1_ += l1l11ll1lll1_l1_
				l1lll111lll1_l1_ = False
			elif len(l1l1l1l1l111_l1_)>1:
				line = l1l1l1l1l111_l1_[1]
				l1ll1l1l1111_l1_ = line[0:8]
				l1ll1l1l1111_l1_ = l11lll_l1_ (u"ࠨࠥࠪ䁘")+l1ll1l1l1111_l1_[2:]
				line = line[9:]
			elif len(l1l1l1l1l11l_l1_)>1:
				line = l1l1l1l1l11l_l1_[1]
				l1ll1l1l1111_l1_ = l11l111ll1l_l1_
			elif len(l1ll1l1llll1_l1_)>1:
				line = l1ll1l1llll1_l1_[1]
				l1lll111lll1_l1_ = True
				l1l11ll1ll11_l1_ = l111l11llll_l1_[l1llll1llll1_l1_]
			elif len(l1ll1ll1111l_l1_)>1:
				line = l1ll1ll1111l_l1_[1]
			elif len(l1ll1ll111l1_l1_)>1:
				line = l1ll1ll111l1_l1_[1]
			elif len(l1l1l1l11ll1_l1_)>1:
				line = l1l1l1l11ll1_l1_[1]
			if line:
				l1l1ll1111l1_l1_ = l1l11l1ll1ll_l1_+l1ll11ll1lll_l1_
				line = bidi.algorithm.get_display(line)
				width,l1ll11111ll1_l1_ = l1llllll1lll_l1_.textsize(line,font=l1ll1l11l1ll_l1_)
				if l1lll111lll1_l1_: l1l11ll1ll11_l1_ -= width
				l1lll1lll111_l1_ = l1lll1lll11l_l1_+l1l11ll1ll11_l1_
				l1llllll1lll_l1_.text((l1lll1lll111_l1_,l1l1ll1111l1_l1_),line,font=l1ll1l11l1ll_l1_,fill=l1ll1l1l1111_l1_)
				if not l1lll111lll1_l1_: l1l11ll1ll11_l1_ += width
				if l1l1ll1111l1_l1_>l1ll1lll11l1_l1_+l1l11ll1lll1_l1_: break
	l1ll1lllll1l_l1_ = l1l111ll1ll1_l1_.replace(l11lll_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ䁙"),l11lll_l1_ (u"ࠪࡣࠬ䁚")+str(time.time())+l11lll_l1_ (u"ࠫࡤ࠭䁛"))
	l1ll1lllll1l_l1_ = l1ll1lllll1l_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ䁜"),l11lll_l1_ (u"࠭࡜࡝࡞࡟ࠫ䁝")).replace(l11lll_l1_ (u"ࠧ࠰࠱ࠪ䁞"),l11lll_l1_ (u"ࠨ࠱࠲࠳࠴࠭䁟"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1ll1lllll1l_l1_)
	return l1ll1lllll1l_l1_,l1111111ll1_l1_
def l11lll111ll_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll11_l1_=True):
	# should l1l1111ll111_l1_ ==l11lll_l1_ (u"ࠩࠪ䁠") l1111l1l1l_l1_ not l11l111ll1_l1_ it to l11lll_l1_ (u"ࠪࡲࡴࡺࠧ䁡")
	if allow_redirects==l11lll_l1_ (u"ࠫࠬ䁢"): allow_redirects = True
	if l1ll_l1_==l11lll_l1_ (u"ࠬ࠭䁣"): l1ll_l1_ = True
	if l111ll11lll_l1_==l11lll_l1_ (u"࠭ࠧ䁤"): l111ll11lll_l1_ = True
	if l1l1lll1ll11_l1_==l11lll_l1_ (u"ࠧࠨ䁥"): l1l1lll1ll11_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll1111ll1l_l1_ = list(headers.keys())
	if l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䁦") not in l1ll1111ll1l_l1_: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䁧")] = l11lll_l1_ (u"ࠪࡄࡅࡆࡓࡌࡋࡓࡣࡍࡋࡁࡅࡇࡕࡄࡅࡆࠧ䁨")
	#if l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䁩") not in l1ll1111ll1l_l1_: headers[l11lll_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧ䁪")] = l11lll_l1_ (u"࠭ࡧࡻ࡫ࡳ࠰ࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䁫")
	l11l11l_l1_,l1l11lll11ll_l1_,l1l1lll1llll_l1_,l1l1ll1l1111_l1_ = l1l1l111l111_l1_(url)
	l1l111ll11l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ䁬"))
	l1l11l1lllll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ䁭"))
	l1l1l111111l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䁮"))
	l1l111llll11_l1_ = (l1l11lll11ll_l1_==None and l1l1lll1llll_l1_==None and l1l1ll1l1111_l1_==None)
	l1lllll1ll1l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ䁯")]
	l1l11ll11l11_l1_ = l11l11l_l1_ in l1lllll1ll1l_l1_
	l1lllllll11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ䁰")]
	l111ll1ll11_l1_ = l11l11l_l1_ in l1lllllll11l_l1_
	l1llllllllll_l1_ = l1l11ll11l11_l1_ or l111ll1ll11_l1_
	if l1l111llll11_l1_ and l1llllllllll_l1_:
		if l1l11ll11l11_l1_:
			l1ll1ll1ll1l_l1_ = l1lllll1ll1l_l1_.index(l11l11l_l1_)
			l1lll1lll1l1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ䁱")][l1ll1ll1ll1l_l1_]
			l1llll1111l1_l1_ = [l11lll_l1_ (u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ䁲"),l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨ䁳"),l11lll_l1_ (u"ࠨࡇࡐࡅࡎࡒࡓࠨ䁴"),l11lll_l1_ (u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ䁵"),l11lll_l1_ (u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ䁶"),l11lll_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ䁷"),l11lll_l1_ (u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪ䁸"),l11lll_l1_ (u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ䁹")]
			l1llll1ll1l1_l1_ = l1llll1111l1_l1_[l1ll1ll1ll1l_l1_]
		elif l111ll1ll11_l1_:
			l1ll1ll1ll1l_l1_ = l1lllllll11l_l1_.index(l11l11l_l1_)
			l1lll1lll1l1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪ䁺")][l1ll1ll1ll1l_l1_]
			l1111l11l1l_l1_ = [l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࠨ䁻"),l11lll_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ䁼"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ䁽")]
			l1llll1ll1l1_l1_ = l1111l11l1l_l1_[l1ll1ll1ll1l_l1_]
	if l1l1lll1llll_l1_==l11lll_l1_ (u"ࠫࠬ䁾"): l1l1lll1llll_l1_ = l1l111ll11l1_l1_
	elif l1l1lll1llll_l1_==None and l1l11l1lllll_l1_ in [l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ䁿"),l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䂀")] and l111ll11lll_l1_: l1l1lll1llll_l1_ = l1l111ll11l1_l1_
	l1l1lll1ll1l_l1_ = l11l11l_l1_==l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ䂁")][7]
	if source==l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ䂂"): timeout = 120
	elif source==l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ䂃"): timeout = 20
	elif source==l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫ䂄"): timeout = 20
	elif source in l1lllllll111_l1_: timeout = 10
	elif l1l11ll11l11_l1_ or l111ll1ll11_l1_: timeout = 15
	elif l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭䂅") in source: timeout = 70
	elif l11lll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ䂆") in source: timeout = 75
	elif l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭䂇") in source: timeout = 25
	elif l11lll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭䂈") in source: timeout = 20
	elif l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ䂉") in source: timeout = 20
	elif l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ䂊") in source: timeout = 20
	elif l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䂋") in source: timeout = 25
	elif l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ䂌") in source: timeout = 30
	else: timeout = 15
	if l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ䂍") in source and not data and l11lll_l1_ (u"࠭ࠦࠨ䂎") not in l11l11l_l1_ and l11lll_l1_ (u"ࠧࡀࠩ䂏") not in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪ䂐"))+l11lll_l1_ (u"ࠩ࠲ࠫ䂑")
	l111lll1111_l1_ = (l1l11lll11ll_l1_!=None)
	l1l1lll111ll_l1_ = (l1l1lll1llll_l1_!=None and l1l11l1lllll_l1_!=l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ䂒"))
	if l111lll1111_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧ䂓"),l1l11lll11ll_l1_)
	elif l1l1lll111ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬ䂔"),l1l1lll1llll_l1_)
	if l111lll1111_l1_:
		proxies = {l11lll_l1_ (u"ࠨࡨࡵࡶࡳࠦ䂕"):l1l11lll11ll_l1_,l11lll_l1_ (u"ࠢࡩࡶࡷࡴࡸࠨ䂖"):l1l11lll11ll_l1_}
		l1ll1llll1l1_l1_ = l1l11lll11ll_l1_
	else: proxies,l1ll1llll1l1_l1_ = {},l11lll_l1_ (u"ࠨࠩ䂗")
	if l1l1lll111ll_l1_:
		import urllib3.util.connection as connection
		l11111l1lll_l1_ = l1l11l11l111_l1_(connection,l1l111ll11l1_l1_)
	verify = True
	l1lll1ll1ll1_l1_,l1lll11lllll_l1_,l11ll11ll_l1_,l11l111111l_l1_,l111ll1lll1_l1_ = allow_redirects,source,method,False,False
	if l1l1lll1ll1l_l1_: l111ll1lll1_l1_ = True
	#if l1llllllllll_l1_ or (method==l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䂘") and allow_redirects): l1lll1ll1ll1_l1_ = False
	if l1llllllllll_l1_ or allow_redirects: l1lll1ll1ll1_l1_ = False
	if l1l11ll11l11_l1_: l11ll11ll_l1_ = l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䂙")
	import requests
	code,reason = -1,l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫ䂚")
	for l11ll111l1_l1_ in range(9):
		l1ll1l11ll1l_l1_ = True
		succeeded = False
		try:
			if l11ll111l1_l1_: l1lll11lllll_l1_ = l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭䂛")
			if not l111lll1111_l1_: l11lll1ll1l_l1_(l11lll_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫ䂜"),l11l11l_l1_,data,headers,l1lll11lllll_l1_,l11ll11ll_l1_)
			try: response.close()
			except: pass
			l11l1l1_l1_ = l11l11l_l1_
			#LOG_THIS(l11lll_l1_ (u"ࠧࠨ䂝"),str(l11ll11ll_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ䂞")+str(l11l11l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭䂟")+str(data)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ䂠")+str(headers)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ䂡")+str(verify)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ䂢")+str(l1lll1ll1ll1_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ䂣")+str(timeout)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ䂤")+str(proxies))
			response = requests.request(l11ll11ll_l1_,l11l11l_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll1ll1ll1_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l111111l_l1_:
					l1ll1lllllll_l1_ = list(response.headers.keys())
					if l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䂥") in l1ll1lllllll_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䂦")]
					elif l11lll_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ䂧") in l1ll1lllllll_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭䂨")]
					else: l11l111111l_l1_ = True
					if l11l11l_l1_!=l11l1l1_l1_: l11l11l_l1_ = l11l11l_l1_.encode(l11lll_l1_ (u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭䂩"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭䂪")).decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䂫"),l11lll_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ䂬"))
					if l1llllllllll_l1_ and response.status_code==307:
						l1lll1ll1ll1_l1_ = allow_redirects
						l11ll11ll_l1_ = method
						l11l111111l_l1_ = True
						l1ll11111lll_l1_
				if not l11l111111l_l1_ or allow_redirects:
					if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䂭") not in l11l11l_l1_:
						server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ䂮"))
						l11l11l_l1_ = server+l11lll_l1_ (u"ࠫ࠴࠭䂯")+l11l11l_l1_
				if not l11l111111l_l1_ and allow_redirects:
					l111llll11_l1_ = l11l1llll1_l1_(l11l11l_l1_)
					if l111llll11_l1_ not in [l11lll_l1_ (u"ࠬ࠴ࡡࡷ࡫ࠪ䂰"),l11lll_l1_ (u"࠭࠮ࡵࡵࠪ䂱"),l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ䂲"),l11lll_l1_ (u"ࠨ࠰ࡰ࡯ࡻ࠭䂳"),l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠹ࠧ䂴"),l11lll_l1_ (u"ࠪ࠲ࡼ࡫ࡢ࡮ࠩ䂵")]: l1ll11111lll_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111ll1lll1_l1_ = True
			l11l1l1_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status l1ll1l1lllll_l1_ a log line: l11lll_l1_ (u"ࠦࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࠧ䂶")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l11lll_l1_ (u"ࠬࡀࠠࠨ䂷"))[1]
			else: reason = str(err).split(l11lll_l1_ (u"࠭࠺ࠡࠩ䂸"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l11lll_l1_ (u"ࠧࡆࡴࡵࡲࡴ࠭䂹") in error: code,reason = re.findall(l11lll_l1_ (u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥ䂺"),error)[0]
				elif l11lll_l1_ (u"ࠩ࠯ࠤࡪࡸࡲࡰࡴࠫࠫ䂻") in error: code,reason = re.findall(l11lll_l1_ (u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䂼"),error)[0]
				elif error.count(l11lll_l1_ (u"ࠫ࠿࠭䂽"))>=2: reason,code = re.findall(l11lll_l1_ (u"ࠬࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩࠨ䂾"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1ll1l11ll1l_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䂿"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ䃀")+str(code)+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ䃁")+reason+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ䃂")+source+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ䃃")+l11l11l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ䃄"))
		if l1ll1l11ll1l_l1_ and l1llllllllll_l1_ and not l111ll1lll1_l1_ and code!=200:
			l11l11l_l1_ = l1lll1lll1l1_l1_
			l111ll1lll1_l1_ = True
			continue
		if l1ll1l11ll1l_l1_: break
	if l1l1lll1llll_l1_!=None and l1l11l1lllll_l1_!=l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ䃅"): connection.create_connection = l11111l1lll_l1_
	if l1l11l1lllll_l1_==l11lll_l1_ (u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭䃆") and l111ll11lll_l1_: l1l1lll1llll_l1_ = None
	if not succeeded and l1l11lll11ll_l1_==None and source not in l1lllllll111_l1_:
		l1lll1lllll1_l1_ = traceback.format_exc()
		sys.stderr.write(l1lll1lllll1_l1_)
	l1ll111ll_l1_ = l1l1111l111_l1_()
	l11lll_l1_ (u"ࠢࠣࠤࠐࠎࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥ࠳࠰ࡵࡥࡼࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡶࡦࡽࠍࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩ࠷࠴ࡴࡦࡺࡷࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡶࡨࡼࡹࠓࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠳ࡰࡳࡰࡰࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮࡫ࡵࡲࡲ࠭࠯ࠍࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩ࠷࠴ࡨࡪࡵࡷࡳࡷࡿࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲࡭࡯ࡳࡵࡱࡵࡽࠒࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧ࠵࠲ࡪࡲࡡࡱࡵࡨࡨࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡨࡰࡦࡶࡳࡦࡦࠐࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥ࠳࠰ࡨࡲࡨࡵࡤࡪࡰࡪࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡧࡱࡧࡴࡪࡩ࡯ࡩࠐࠎࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠢࠣࠤ䃇")
	l1ll111ll_l1_.url = l11l1l1_l1_
	try: content = response.content
	except: content = l11lll_l1_ (u"ࠨࠩ䃈")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	try: content = content.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䃉"))
	except: pass
	code = int(code)
	l1ll111ll_l1_.code = code
	l1ll111ll_l1_.reason = reason
	l1ll111ll_l1_.content = content
	l1ll111ll_l1_.headers = headers
	l1ll111ll_l1_.cookies = cookies
	l1ll111ll_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1ll111ll_l1_.content,str): l1l11ll11lll_l1_ = l1ll111ll_l1_.content.lower()
	else: l1l11ll11lll_l1_ = l11lll_l1_ (u"ࠪࠫ䃊")
	l1ll11lll1ll_l1_ = (l11lll_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ䃋") in l1l11ll11lll_l1_ or l11lll_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬ䃌") in l1l11ll11lll_l1_) and l1l11ll11lll_l1_.count(l11lll_l1_ (u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ䃍"))>2 and l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ䃎") not in source and l11lll_l1_ (u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪ䃏") not in l1l11ll11lll_l1_
	if code==200 and l1ll11lll1ll_l1_: l1ll111ll_l1_.succeeded = False
	if l1ll111ll_l1_.succeeded and l1l111llll11_l1_ and l1llllllllll_l1_:
		if l1l1lll1ll1l_l1_: l1llll1ll1l1_l1_ = l11lll_l1_ (u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ䃐")+data[l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ䃑")].upper()
		l1ll111l1_l1_ = l1l1111l1ll_l1_(l1llll1ll1l1_l1_)
	if not l1ll111ll_l1_.succeeded and l1l111llll11_l1_:
		l1ll11lll11l_l1_ = (l11lll_l1_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ䃒") in l1l11ll11lll_l1_ and l11lll_l1_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ䃓") in l1l11ll11lll_l1_)
		l1lll1ll1111_l1_ = (l11lll_l1_ (u"࠭࠵ࠡࡵࡨࡧࠬ䃔") in l1l11ll11lll_l1_ and l11lll_l1_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ䃕") in l1l11ll11lll_l1_)
		l1ll11llll11_l1_ = (code in [403] and l11lll_l1_ (u"ࠨࡧࡵࡶࡴࡸࠠࡤࡱࡧࡩ࠿ࠦ࠱࠱࠴࠳ࠫ䃖") in l1l11ll11lll_l1_)
		l1ll11llll1l_l1_ = (l11lll_l1_ (u"ࠩࡢࡧ࡫ࡥࡣࡩ࡮ࡢࠫ䃗") in l1l11ll11lll_l1_ and l11lll_l1_ (u"ࠪࡧ࡭ࡧ࡬࡭ࡧࡱ࡫ࡪ࠳ࠧ䃘") in l1l11ll11lll_l1_)
		if   l1ll11lll1ll_l1_: reason = l11lll_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫ䃙")
		elif l1ll11lll11l_l1_: reason = l11lll_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭䃚")
		elif l1lll1ll1111_l1_: reason = l11lll_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭䃛")
		elif l1ll11llll11_l1_: reason = l11lll_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡣࡦࡧࡪࡹࡳࠡࡦࡨࡲ࡮࡫ࡤࠨ䃜")
		elif l1ll11llll1l_l1_: reason = l11lll_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ䃝")
		else: reason = str(reason)
		if source in l1lllllll111_l1_:
			LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ䃞"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ䃟")+str(code)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ䃠")+reason+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䃡")+source+l11lll_l1_ (u"࠭ࠠ࡞࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䃢")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䃣"))
		else: LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䃤"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭䃥")+str(code)+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ䃦")+reason+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭䃧")+source+l11lll_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䃨")+l11l11l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ䃩"))
		l1lll1l111ll_l1_ = l111l_l1_(l11l11l_l1_)
		if kodi_version<19 and isinstance(l1lll1l111ll_l1_,unicode): l1lll1l111ll_l1_ = l1lll1l111ll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䃪"))
		if l1llllllllll_l1_: l1lll1l111ll_l1_ = l1lll1l111ll_l1_.split(l11lll_l1_ (u"ࠨ࠱ࠪ䃫"))[-1]
		reason = str(reason)+l11lll_l1_ (u"ࠩ࡟ࡲ࠭ࠦࠧ䃬")+l1lll1l111ll_l1_+l11lll_l1_ (u"ࠪࠤ࠮࠭䃭")
		if l1ll11lll1ll_l1_ or l1ll11lll11l_l1_ or l1lll1ll1111_l1_ or l1ll11llll11_l1_ or l1ll11llll1l_l1_:
			code = -2
			l1ll111ll_l1_.code = code
			l1ll111ll_l1_.reason = reason
		l1ll11l111_l1_ = True
		if (l1l11l1lllll_l1_==l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䃮") or l1l1l111111l_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䃯")) and (l111ll11lll_l1_ or l1l1lll1ll11_l1_):
			l1ll11l111_l1_ = l1ll1l1l1l1l_l1_(code,reason,source,l1ll_l1_)
			if l1ll11l111_l1_ and l1l11l1lllll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䃰"): l1l11l1lllll_l1_ = l11lll_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ䃱")
			else: l1l11l1lllll_l1_ = l11lll_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ䃲")
			if l1ll11l111_l1_ and l1l1l111111l_l1_==l11lll_l1_ (u"ࠩࡄࡗࡐ࠭䃳"): l1l1l111111l_l1_ = l11lll_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ䃴")
			else: l1l1l111111l_l1_ = l11lll_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭䃵")
			settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ䃶"),l1l11l1lllll_l1_)
			settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ䃷"),l1l1l111111l_l1_)
		if l1ll11l111_l1_:
			l1lll1ll1l11_l1_ = True
			if code==8 and l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䃸") in l11l11l_l1_ and l1lll1ll1l11_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨฬไ฽๏๊ࠠโฯุࠤูํวะหࠣห้ะิโ์ิࠤࡘ࡙ࡌࠨ䃹"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䃺"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠪࢀࢁࡓࡹࡔࡕࡏ࡙ࡷࡲ࠽ࠨ䃻")
				l1ll111l1_l1_ = l11lll111ll_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ䃼"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䃽")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䃾")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䃿"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨ่ฯหาࠦศศีอาิอๅࠡࡕࡖࡐࠬ䄀"),l11lll_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ䄁"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䄂"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ䄃")+source+l11lll_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䄄")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ䄅"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪ䄆"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䄇"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l1l111111l_l1_ in [l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ䄈"),l11lll_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ䄉")] and l1l1lll1ll11_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫ䄊"),l11lll_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ䄋"),time=2000)
				l1ll111l1_l1_ = l111ll1l111_l1_(method,l11l11l_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ䄌"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䄍")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䄎")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䄏"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩ䄐"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䄑"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䄒"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ䄓")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭䄔")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ䄕"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ䄖"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䄗"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l11l1lllll_l1_ in [l11lll_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ䄘"),l11lll_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ䄙")] and l111ll11lll_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨ䄚"),l11lll_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ䄛"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭䄜")
				l1ll111l1_l1_ = l11lll111ll_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ䄝"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪ䄞")+l1l111ll11l1_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭䄟")+source+l11lll_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䄠")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ䄡"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨ䄢"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䄣"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䄤"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ䄥")+l1l111ll11l1_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭䄦")+source+l11lll_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ䄧")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ䄨"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧ䄩"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䄪"),time=2000)
		if l1l1l111111l_l1_==l11lll_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ䄫") or l1l11l1lllll_l1_==l11lll_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ䄬"): l1ll_l1_ = False
		if not l1ll111ll_l1_.succeeded:
			if l1ll_l1_: l11l1111l11_l1_ = l1ll1l1l1l1l_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l1111lll111_l1_ and l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨ䄭") not in source:
				l1lll111llll_l1_(l11lll_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡲࡪࡺࡷࡰࡴ࡮ࠤ࡮ࡹࡳࡶࡧࡶࠤࡼ࡯ࡴࡩ࠼ࠣࠫ䄮")+source)
	if settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䄯")) not in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ䄰"),l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭䄱"),l11lll_l1_ (u"ࠩࡄࡗࡐ࠭䄲")]: settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ䄳"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䄴"))
	if settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ䄵")) not in [l11lll_l1_ (u"࠭ࡁࡖࡖࡒࠫ䄶"),l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ䄷"),l11lll_l1_ (u"ࠨࡃࡖࡏࠬ䄸")]: settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䄹"),l11lll_l1_ (u"ࠪࡅࡘࡑࠧ䄺"))
	return l1ll111ll_l1_
def OPENURL_REQUESTS_CACHED(l11lll1l1ll_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_=True,l1l1lll1ll11_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	if l11lll1l1ll_l1_:
		response = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭䄻"),l11lll_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ䄼"),item)
		if response.succeeded:
			l11lll1ll1l_l1_(l11lll_l1_ (u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭䄽"),url,data,headers,source,method)
			return response
	response = l11lll111ll_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll11lll_l1_,l1l1lll1ll11_l1_)
	if response.succeeded:
		if l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ䄾") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l11lll1l1ll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫ䄿"),item,response,l11lll1l1ll_l1_)
	return response
def OPENURL_CACHED(l11lll1l1ll_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䅀")
	else:
		method = l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䅁")
		data = l111l_l1_(data)
		dummy,data = l1lll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l11lll1l1ll_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䅂"))
	html = str(html)
	return html
def l1l1l111l111_l1_(url):
	l1l11llllll1_l1_ = url.split(l11lll_l1_ (u"ࠬࢂࡼࠨ䅃"))
	l11l11l_l1_,l1l11lll11ll_l1_,l1l1lll1llll_l1_,l1l1ll1l1111_l1_ = l1l11llllll1_l1_[0],None,None,None
	for item in l1l11llllll1_l1_:
		if l11lll_l1_ (u"࠭ࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ䅄") in item: l1l11lll11ll_l1_ = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ䅅"))[1]
		elif l11lll_l1_ (u"ࠨࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ䅆") in item: l1l1lll1llll_l1_ = item.split(l11lll_l1_ (u"ࠩࡀࠫ䅇"))[1]
		elif l11lll_l1_ (u"ࠪࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭䅈") in item: l1l1ll1l1111_l1_ = item.split(l11lll_l1_ (u"ࠫࡂ࠭䅉"))[1]
	return l11l11l_l1_,l1l11lll11ll_l1_,l1l1lll1llll_l1_,l1l1ll1l1111_l1_
def RESTORE_PATH_NAME(name):
	start,l1l1l1l1l1l_l1_,modified = l11lll_l1_ (u"ࠬ࠭䅊"),l11lll_l1_ (u"࠭ࠧ䅋"),l11lll_l1_ (u"ࠧࠨ䅌")
	name = name.replace(ltr,l11lll_l1_ (u"ࠨࠩ䅍")).replace(rtl,l11lll_l1_ (u"ࠩࠪ䅎"))
	tmp = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠯࡜࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡞ࡠࠬࡡࡽ࡜ࡸ࡞ࡺ࠭ࠥ࠱࡜࡜࡞࠲ࡇࡔࡒࡏࡓ࡞ࡠࠬ࠳࠰࠿ࠪࠦࠪ䅏"),name,re.DOTALL)
	if tmp: start,l1l1l1l1l1l_l1_,name = tmp[0]
	if start not in [l11lll_l1_ (u"ࠫࠥ࠭䅐"),l11lll_l1_ (u"ࠬ࠲ࠧ䅑"),l11lll_l1_ (u"࠭ࠧ䅒")]: modified = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䅓")
	if l1l1l1l1l1l_l1_: l1l1l1l1l1l_l1_ = l11lll_l1_ (u"ࠨࡡࠪ䅔")+l1l1l1l1l1l_l1_+l11lll_l1_ (u"ࠩࡢࠫ䅕")
	#datetime = re.findall(l11lll_l1_ (u"ࠪࠬࡤࡢࡤ࡝ࡦ࡟࠲ࡡࡪ࡜ࡥࡡ࡟ࡨࡡࡪ࡜࠻࡞ࡧࡠࡩࡥࠩࠨ䅖"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11lll_l1_ (u"ࠫࠬ䅗"))
	name = l1l1l1l1l1l_l1_+modified+name
	return name
def l1l1lllll11_l1_(url,l1l1ll11l1l1_l1_,l1l1ll1llll1_l1_,l1ll1ll1l11l_l1_,headers={}):
	l1l111l11111_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䅘"))
	l1111l1ll1l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ䅙")+l1l1ll11l1l1_l1_)
	if l1111l1ll1l_l1_: l11l1l1_l1_ = url.replace(l1l111l11111_l1_,l1111l1ll1l_l1_)
	else:
		l11l1l1_l1_ = url
		l1111l1ll1l_l1_ = l1l111l11111_l1_
	l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䅚"),l11l1l1_l1_,l11lll_l1_ (u"ࠨࠩ䅛"),headers,l11lll_l1_ (u"ࠩࠪ䅜"),l11lll_l1_ (u"ࠪࠫ䅝"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ䅞"))
	html = l1ll111l1_l1_.content
	try: html = html.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䅟"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭䅠"))
	except: pass
	if not l1ll111l1_l1_.succeeded or l1ll1ll1l11l_l1_ not in html:
		l11l11l_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬ䅡")+l1l1ll1llll1_l1_
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䅢"):l11lll_l1_ (u"ࠩࠪ䅣")}
		l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䅤"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ䅥"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭䅦"),l11lll_l1_ (u"࠭ࠧ䅧"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠳ࡰࡧࠫ䅨"))
		if l1ll111ll_l1_.succeeded:
			html = l1ll111ll_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䅩"),l11lll_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ䅪"))
				except: pass
			links = re.findall(l11lll_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡵࡳ࡮࡟ࡃࡶࡃࠨ࠯ࠬࡂ࠭ࠧ࠭䅫"),html,re.DOTALL)
			l1lll1ll111l_l1_ = [l1111l1ll1l_l1_]
			for link in links:
				l1111l1ll1l_l1_ = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ䅬"))
				if l11lll_l1_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮ࠩ䅭") in link: continue
				if l1111l1ll1l_l1_ in l1lll1ll111l_l1_: continue
				if len(l1lll1ll111l_l1_)==9:
					LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䅮"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡨ࡮ࡪࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭䅯")+l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭䅰")+l1l111l11111_l1_+l11lll_l1_ (u"ࠩࠣࡡࠬ䅱"))
					settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ䅲")+l1l1ll11l1l1_l1_,l11lll_l1_ (u"ࠫࠬ䅳"))
					break
				l1lll1ll111l_l1_.append(l1111l1ll1l_l1_)
				l11l1l1_l1_ = url.replace(l1l111l11111_l1_,l1111l1ll1l_l1_)
				l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䅴"),l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ䅵"),headers,l11lll_l1_ (u"ࠧࠨ䅶"),l11lll_l1_ (u"ࠨࠩ䅷"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭䅸"))
				html = l1ll111l1_l1_.content
				if l1ll111l1_l1_.succeeded and l1ll1ll1l11l_l1_ in html:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ䅹"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡧࡱࡸࡲࡩࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䅺")+l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡒࡪࡽ࠺ࠡ࡝ࠣࠫ䅻")+l1111l1ll1l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫ䅼")+l1l111l11111_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䅽"))
					settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ䅾")+l1l1ll11l1l1_l1_,l1111l1ll1l_l1_)
					break
	return l1111l1ll1l_l1_,l11l1l1_l1_,l1ll111l1_l1_
def TRANSLATE(text):
	dict = {
	 l11lll_l1_ (u"ࠩࡲࡰࡩ࠭䅿")			:l11lll_l1_ (u"ࠪๆิ๐ๅࠨ䆀")
	,l11lll_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭䆁")		:l11lll_l1_ (u"๋ࠬส้ไไࠫ䆂")
	,l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ䆃")		:l11lll_l1_ (u"ࠧๆใๅ์ิ࠭䆄")
	,l11lll_l1_ (u"ࠨࡩࡲࡳࡩ࠭䆅")			:l11lll_l1_ (u"ࠩฯ๎ิ࠭䆆")
	,l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ䆇")		:l11lll_l1_ (u"ࠫๆฺไࠨ䆈")
	,l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䆉")		:l11lll_l1_ (u"࠭ๅอๆาࠫ䆊")
	,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䆋")		:l11lll_l1_ (u"ࠨใํำ๏๎ࠧ䆌")
	,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䆍")			:l11lll_l1_ (u"ࠪๆ๋อษࠨ䆎")
	,l11lll_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࠪ䆏")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩ䆐")
	,l11lll_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࠬ䆑")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫ䆒")
	,l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪ䆓")		:l11lll_l1_ (u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪ䆔")
	,l11lll_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ䆕")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫ䆖")
	,l11lll_l1_ (u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧ䆗")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬ䆘")
	,l11lll_l1_ (u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪ䆙")	:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫ䆚")
	,l11lll_l1_ (u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫ䆛")		:l11lll_l1_ (u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧ䆜")
	,l11lll_l1_ (u"ࠫࡦࡸࡢ࡭࡫ࡲࡲࡿ࠭䆝")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ฽ึฮࠠๅ์๋๊ื࠭䆞")
	,l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪ䆟")	:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡࡸ࡬ࡴࠬ䆠")
	,l11lll_l1_ (u"ࠨࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣࠪ䆡")		:l11lll_l1_ (u"่ࠩ์็฿ࠠศๆึ๎๋๋วࠨ䆢")
	,l11lll_l1_ (u"ࠪ࡬ࡪࡲࡡ࡭ࠩ䆣")		:l11lll_l1_ (u"๊ࠫ๎โฺ๊่ࠢฬ๊๋๊ࠠอ๎ํฮࠧ䆤")
	,l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡩࡥࡳࡹࠧ䆥")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧ䆦")
	,l11lll_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ䆧")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ䆨")
	,l11lll_l1_ (u"ࠩࡶ࡬ࡴࡵࡦ࡮ࡣࡻࠫ䆩")		:l11lll_l1_ (u"้ࠪํู่ࠡึ๋ๅ๋ࠥวไีࠪ䆪")
	,l11lll_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䆫")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ฽ึฮࠠิ์ํำࠬ䆬")
	,l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䆭")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧ䆮")
	,l11lll_l1_ (u"ࠨ࡭ࡤࡶࡧࡧ࡬ࡢࡶࡹࠫ䆯")	:l11lll_l1_ (u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬ䆰")
	,l11lll_l1_ (u"ࠪࡽࡹࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䆱")	:l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣ๎ํะ๊้สࠪ䆲")
	,l11lll_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ䆳")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭䆴")
	,l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ䆵")		:l11lll_l1_ (u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠧ䆶")
	,l11lll_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ䆷")		:l11lll_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅล๋่ࠬ䆸")
	,l11lll_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠷࠭䆹")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨ䆺")
	,l11lll_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ䆻")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮใาษࠪ䆼")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ䆽")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ฿ศะ๊ࠪ䆾")
	,l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࡵࡸࠪ䆿")		:l11lll_l1_ (u"๊๊ࠫแࠨ䇀")
	,l11lll_l1_ (u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠭䇁")		:l11lll_l1_ (u"࠭ๅๅใࠪ䇂")
	,l11lll_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䇃")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦๅ้ใีࠤๆ๎ั๋๊ࠪ䇄")
	,l11lll_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࡴࡪࡲࡻࠬ䇅")	:l11lll_l1_ (u"้ࠪํู่ࠡใฯีฺ่ࠥࠨ䇆")
	,l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䇇")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭䇈")
	,l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨ䇉")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠳ࠪ䇊")
	,l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠴ࠪ䇋")		:l11lll_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬ䇌")
	,l11lll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ䇍")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠹ࠧ䇎")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠺ࠧ䇏")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩ䇐")
	,l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ䇑")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪ䇒")
	,l11lll_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ䇓")		:l11lll_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦๆศ๊ࠪ䇔")
	,l11lll_l1_ (u"ࠫࡪ࡭ࡹࡥࡧࡤࡨࠬ䇕")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊ࠡัํำࠬ䇖")
	,l11lll_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ䇗")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧ䇘")
	,l11lll_l1_ (u"ࠨ࡮ࡲࡨࡾࡴࡥࡵࠩ䇙")		:l11lll_l1_ (u"่ࠩ์็฿ࠠๅ๊า๎ࠥ์สࠨ䇚")
	,l11lll_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ䇛")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ䇜")
	,l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨ䇝")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧ䇞")
	,l11lll_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫ䇟")	:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩ䇠")
	,l11lll_l1_ (u"ࠩࡩࡳࡸࡺࡡࠨ䇡")		:l11lll_l1_ (u"้ࠪํู่ࠡใ๋ืฯอࠧ䇢")
	,l11lll_l1_ (u"ࠫࡦ࡮ࡷࡢ࡭ࠪ䇣")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧ䇤")
	,l11lll_l1_ (u"࠭ࡦࡢࡤࡵࡥࡰࡧࠧ䇥")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็ศาๅฬࠫ䇦")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪ䇧")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪ䇨")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡵࡦࡩࡣࠪ䇩")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭䇪")
	,l11lll_l1_ (u"ࠬࡨࡲࡴࡶࡨ࡮ࠬ䇫")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫ䇬")
	,l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨ䇭")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨ䇮")
	,l11lll_l1_ (u"ࠩ࡯ࡥࡷࡵࡺࡢࠩ䇯")		:l11lll_l1_ (u"้ࠪํู่ࠡๆสีํุวࠨ䇰")
	,l11lll_l1_ (u"ࠫࡾࡧࡱࡰࡶࠪ䇱")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩ䇲")
	,l11lll_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䇳")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠫ䇴")
	,l11lll_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭䇵")	:l11lll_l1_ (u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫ䇶")
	,l11lll_l1_ (u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫ䇷")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫ䇸")
	,l11lll_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ䇹")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬ䇺")
	,l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ䇻")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩ䇼")
	,l11lll_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭ࠨ䇽")				:l11lll_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ䇾")
	,l11lll_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡥࡷࡧࡢࡪࡥࠪ䇿")			:l11lll_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧ䈀")
	,l11lll_l1_ (u"࠭ࡩࡧ࡫࡯ࡱ࠲࡫࡮ࡨ࡮࡬ࡷ࡭࠭䈁")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤฬ์ฬๅ์ี๎ࠬ䈂")
	,l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺࠧ䈃")				:l11lll_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭䈄")
	,l11lll_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䈅")			:l11lll_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧ䈆")
	,l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫ䈇")			:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫ䈈")
	,l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ䈉")				:l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อ࠭䈊")
	,l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪ䈋")		:l11lll_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪ䈌")
	,l11lll_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ䈍")	:l11lll_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆํอฦๆࠩ䈎")
	,l11lll_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䈏")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่ࠥๆ้ษอࠫ䈐")
	,l11lll_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨࠫ䈑")			:l11lll_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫ䈒")
	,l11lll_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧ䈓")	:l11lll_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫ䈔")
	,l11lll_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣ࡯ࡦࡺࡳࡳࠨ䈕")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡษ็ฬํ๋ࠧ䈖")
	,l11lll_l1_ (u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡺࡪࡩࡰࡵࠪ䈗")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪ䈘")
	,l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ䈙")			:l11lll_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠫ䈚")
	,l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩ䈛")	:l11lll_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨ䈜")
	,l11lll_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ䈝"):l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ๋หห๋ࠧ䈞")
	,l11lll_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨ䈟")	:l11lll_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆ๋๎วหࠩ䈠")
	,l11lll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡶࡲࡴ࡮ࡩࡳࠨ䈡")	:l11lll_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬ䈢")
	,l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ䈣")					:l11lll_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ䈤")
	,l11lll_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡲࡩࡷࡧࠪ䈥")			:l11lll_l1_ (u"ࠨࡋࡓࡘ࡛ࠦโ็๊สฮࠬ䈦")
	,l11lll_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䈧")			:l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠡลไ่ฬ๋ࠧ䈨")
	,l11lll_l1_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡶࡩࡷ࡯ࡥࡴࠩ䈩")			:l11lll_l1_ (u"ࠬࡏࡐࡕࡘุ้๊ࠣำๅษอࠫ䈪")
	,l11lll_l1_ (u"࠭࡭࠴ࡷࠪ䈫")					:l11lll_l1_ (u"ࠧࡎ࠵ࡘࠫ䈬")
	,l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡲࡩࡷࡧࠪ䈭")				:l11lll_l1_ (u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬ䈮")
	,l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䈯")			:l11lll_l1_ (u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧ䈰")
	,l11lll_l1_ (u"ࠬࡳ࠳ࡶ࠯ࡶࡩࡷ࡯ࡥࡴࠩ䈱")			:l11lll_l1_ (u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫ䈲")
	}
	try: result = dict[text.lower()]
	except: result = l11lll_l1_ (u"ࠧࠨ䈳")
	return result
def l1lll111llll_l1_(message=l11lll_l1_ (u"ࠨࠩ䈴")):
	l1l1lll11111_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11lll_l1_ (u"ࠩ࠽࠳ࠬ䈵")):
	return _1ll1l11l11l_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l111111llll_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠪࠫ䈶"),l11lll_l1_ (u"ࠫ࠵࠭䈷"),0]: return l11lll_l1_ (u"ࠬ࠭䈸")
	l1l11l11l_l1_ = int(l1l11l11l_l1_)
	first = l1l11l11l_l1_^l11111l_l1_
	second = l1l11l11l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l11l11l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1l11l11ll1l_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"࠭ࠧ䈹"),l11lll_l1_ (u"ࠧ࠱ࠩ䈺"),0]: return l11lll_l1_ (u"ࠨࠩ䈻")
	l1l11l11l_l1_ = str(l1l11l11l_l1_)
	result = l11lll_l1_ (u"ࠩࠪ䈼")
	if len(l1l11l11l_l1_)==15:
		first,second,l1lll111l_l1_ = l1l11l11l_l1_[0:4],l1l11l11l_l1_[4:9],l1l11l11l_l1_[9:]
		first = int(first)^l1lll1111_l1_
		second = int(second)^REGULAR_CACHE
		l1lll111l_l1_ = int(l1lll111l_l1_)^l11111l_l1_
		if first==second==l1lll111l_l1_: result = str(first*60)
	return result
def l1l1lll11l11_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"ࠪࠫ䈽"),l11lll_l1_ (u"ࠫ࠵࠭䈾"),0]: return l11lll_l1_ (u"ࠬ࠭䈿")
	l1l11l11l_l1_ = int(l1l11l11l_l1_)+63841823
	first = l1l11l11l_l1_^l11111l_l1_
	second = l1l11l11l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l11l11l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1lll111ll11_l1_(l1l11l11l_l1_):
	if l1l11l11l_l1_ in [l11lll_l1_ (u"࠭ࠧ䉀"),l11lll_l1_ (u"ࠧ࠱ࠩ䉁"),0]: return l11lll_l1_ (u"ࠨࠩ䉂")
	l1l11l11l_l1_ = str(l1l11l11l_l1_)
	length = int(len(l1l11l11l_l1_)/3)
	first = int(l1l11l11l_l1_[0:length])^l11111l_l1_
	second = int(l1l11l11l_l1_[length:2*length])^REGULAR_CACHE
	l1lll111l_l1_ = int(l1l11l11l_l1_[2*length:3*length])^l1lll1111_l1_
	result = l11lll_l1_ (u"ࠩࠪ䉃")
	if first==second==l1lll111l_l1_: result = str(int(first)-63841823)
	return result
def l1l1l1l111_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11ll1l_l1_(l1l1l1l11l1l_l1_,l1l1l11lll11_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ䉄"),l11lll_l1_ (u"ࠫࠬ䉅"),l11lll_l1_ (u"ࠬ࠭䉆"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䉇"),l1l1l1l11l1l_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䉈")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อ้ࠡำหࠥอไๆฮ็ำࠥลࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䉉"))
		if l1ll11l111_l1_!=1: return
	error = False
	if os.path.exists(l1l1l1l11l1l_l1_):
		#os.chmod(l1l1l1l11l1l_l1_,0o777)
		for root,dirs,files in os.walk(l1l1l1l11l1l_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䉊"),l11lll_l1_ (u"ࠪࠫ䉋"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䉌"),str(err))
					error = True
			if l1l1l11lll11_l1_:
				for dir in dirs:
					l1l1111lll11_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l1111lll11_l1_)
					except: pass
		if l1l1l11lll11_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䉍"),l11lll_l1_ (u"࠭ࠧ䉎"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䉏"),l11lll_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ䉐"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭䉑"),l11lll_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭䉒"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䉓"))
	return
def l1l1lll11111_l1_(l1lll1lllll1_l1_=l11lll_l1_ (u"ࠬ࠭䉔")):
	#if l1lll1lllll1_l1_:
	#	if l11lll_l1_ (u"࠭࡟ࡠࡈࡒࡖࡈࡋࡄࡠࡇ࡛ࡍ࡙ࡥ࡟ࠨ䉕") in l1lll1lllll1_l1_:
	#		message  = l1lll1lllll1_l1_.split(l11lll_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ䉖"))[1]
	#		LOG_THIS(l11lll_l1_ (u"ࠨࠩ䉗"),l11lll_l1_ (u"ࠩࡉࡓࡗࡉࡅࡅࠢࡈ࡜ࡎ࡚ࠠࠡࠢࠣ࠲ࠥࠦࠠࠨ䉘")+message)
	#		#sys.stderr.write(l11lll_l1_ (u"ࠪࡊࡔࡘࡃࡆࡆࠣࡉ࡝ࡏࡔ࠻࡞ࡱࠫ䉙")+message+l11lll_l1_ (u"ࠫࡡࡴ࡟ࠨ䉚"))
	#	else: l11l11l11l1_l1_(l1lll1lllll1_l1_)
	if l1lll1lllll1_l1_:
		l1lll1111l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭䉛"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ䉜"),l11lll_l1_ (u"ࠧࠨ䉝"))
		l11l11l11l1_l1_(l1lll1lllll1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ䉞"),l1lll1111l11_l1_)
	l1l1l11111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭䉟"))
	if l1l1l11111_l1_==l11lll_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭䉠"): settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ䉡"),l11lll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ䉢"))
	elif l1l1l11111_l1_==l11lll_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ䉣"): settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ䉤"),l11lll_l1_ (u"ࠨࠩ䉥"))
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ䉦")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䉧"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䉨"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䉩")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䉪"),l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䉫"))
	if settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ䉬")) not in [l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ䉭"),l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ䉮"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䉯")]: settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ䉰"),l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䉱"))
	l11l111ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ䉲"))
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ䉳"))
	if l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ䉴") in str(l11111lll1l_l1_) and l11l111ll11_l1_ in [l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭䉵"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ䉶")]:
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ࠭䉷"),l11l111ll11_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡖࡩࡹ࡜ࡩࡦࡹࡐࡳࡩ࡫ࠨ࠱ࠫࠪ䉸"))
	#l111ll11l11_l1_ = sys.version_info[0]
	#l11111l11l1_l1_ = sys.version_info[1]
	#if l111ll11l11_l1_==2: python_version = l11lll_l1_ (u"ࠧ࠳࠹ࠪ䉹")
	#else: python_version = str(l111ll11l11_l1_)+str(l11111l11l1_l1_)
	#l11l1111111_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ䉺")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䉻"),l11lll_l1_ (u"ࠪࠫ䉼"),l11lll_l1_ (u"ࠫࠬ䉽"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1llll11_l1_,l111ll1l1l1_l1_)
	return
from EXCLUDES import *
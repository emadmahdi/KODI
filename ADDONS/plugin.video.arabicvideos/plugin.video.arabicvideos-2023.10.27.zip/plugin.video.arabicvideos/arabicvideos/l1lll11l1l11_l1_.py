# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ沌")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ沍")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧษอ้ࠣออิาࠩ沎")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l1111l_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llllll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ沏"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ沐"),l11lll_l1_ (u"ࠪࠫ沑"),l11lll_l1_ (u"ࠫࠬ沒"),l11lll_l1_ (u"ࠬ࠭沓"),l11lll_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ沔"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沕"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ沖"),l11lll_l1_ (u"ࠩࠪ沗"),469,l11lll_l1_ (u"ࠪࠫ沘"),l11lll_l1_ (u"ࠫࠬ沙"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ沚"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭沛"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ沜")+l111ll_l1_+l11lll_l1_ (u"ࠨลัีࠥอไฮๆๅหฯ࠭沝"),l11ll1_l1_,461,l11lll_l1_ (u"ࠩࠪ沞"),l11lll_l1_ (u"ࠪࠫ沟"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ沠"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ没"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭沢"),l11lll_l1_ (u"ࠧࠨ沣"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ沤"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ沥"),block,re.DOTALL)
		for link,title in items:
			#if link==l11lll_l1_ (u"ࠪࠧࠬ沦"): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ沧") not in link: link = l11ll1_l1_+link
			if title==l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ沨"): title = l11lll_l1_ (u"࠭ฬะ์าࠤา๊โศฬࠣฮ๏็๊ࠡใส๊ࠬ沩")
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ沪"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ沫")+l111ll_l1_+title,link,461)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡊࡴࡵࡴࡦࡴࡆࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ沬"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ沭"),block,re.DOTALL)
	#	for link,title in items:
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ沮"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ沯")+l111ll_l1_+title,link,461)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"࠭ࠧ沰")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ沱"),l11lll_l1_ (u"ࠨࠩ沲"),l1lll1ll11_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭河"),url,l11lll_l1_ (u"ࠪࠫ沴"),l11lll_l1_ (u"ࠫࠬ沵"),l11lll_l1_ (u"ࠬ࠭沶"),l11lll_l1_ (u"࠭ࠧ沷"),l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ沸"))
	html = response.content
	#if l1lll1ll11_l1_==l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ油"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩฦาึࠦวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ沺"),html,re.DOTALL)
	#else:
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ治"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ沼"),block,re.DOTALL)
		l1l1_l1_ = []
		l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ沽"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ沾"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭沿"),l11lll_l1_ (u"ࠨๅ็๎อ࠭泀"),l11lll_l1_ (u"ࠩส฽้อๆࠨ況"),l11lll_l1_ (u"๋ࠪิอแࠨ泂"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ泃"),l11lll_l1_ (u"ࠬ฿ัืࠩ泄"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭泅"),l11lll_l1_ (u"ࠧศๆห์๊࠭泆")]
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭泇") not in link: link = l11ll1_l1_+link
			link = l111l_l1_(link)	#.strip(l11lll_l1_ (u"ࠩ࠲ࠫ泈"))
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭泉"),title,re.DOTALL)
			if any(value in title for value in l1lll1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ泊"),l111ll_l1_+title,link,462,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ泋") in title:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ泌") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ泍"),l111ll_l1_+title,link,463,l1llll_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ泎"),l111ll_l1_+title,link,463,l1llll_l1_)
	if l1lll1ll11_l1_!=l11lll_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ泏"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ泐"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ泑"),block,re.DOTALL)
			for link,title in items:
				link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ泒"))
				if link==l11lll_l1_ (u"ࠨࠢ泓"): continue
				if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ泔") not in link: link = l11ll1_l1_+link
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠨࠩ法"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ泖"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ泗")+title,link,461)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ泘"),l11lll_l1_ (u"ࠬ࠭泙"),l11lll_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࠨ泚"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ泛"),url,l11lll_l1_ (u"ࠨࠩ泜"),l11lll_l1_ (u"ࠩࠪ泝"),l11lll_l1_ (u"ࠪࠫ泞"),l11lll_l1_ (u"ࠫࠬ泟"),l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ泠"))
	html = response.content
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭泡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ波"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭泣") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ泤"),l111ll_l1_+title,link,462,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ泥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭泦"),block,re.DOTALL)
		for link,title in items:
			link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ泧"))
			if link==l11lll_l1_ (u"ࠨࠢ注"): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ泩") not in link: link = l11ll1_l1_+link
			#title = unescapeHTML(title)
			if title!=l11lll_l1_ (u"ࠨࠩ泪"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ泫"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ泬")+title,link,463)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ泭"),url,l11lll_l1_ (u"ࠬ࠭泮"),l11lll_l1_ (u"࠭ࠧ泯"),l11lll_l1_ (u"ࠧࠨ泰"),l11lll_l1_ (u"ࠨࠩ泱"),l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ泲"))
	html = response.content
	# l1l111lll_l1_ link
	l1111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ泳"),html,re.DOTALL)
	if l1111l1l11_l1_:
		l1111l1l11_l1_ = l1111l1l11_l1_[0]
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ泴") not in l1111l1l11_l1_:
			if l11lll_l1_ (u"ࠬ࠵࠯ࠨ泵") in l1111l1l11_l1_: l1111l1l11_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ泶")+l1111l1l11_l1_
			else: l1111l1l11_l1_ = l11ll1_l1_+l1111l1l11_l1_
		l1111l1l11_l1_ = l1111l1l11_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ泷")
		l1111_l1_.append(l1111l1l11_l1_)
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ泸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1ll1l1ll1111_l1_,l1ll1l1ll111l_l1_ = l1l1ll1_l1_[0]
		names = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ泹"),l1ll1l1ll1111_l1_,re.DOTALL)
		links = re.findall(l11lll_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ泺"),l1ll1l1ll111l_l1_,re.DOTALL)
		l1ll1l1l1llll_l1_ = zip(names,links)
		for name,l1llll1l1l111_l1_ in l1ll1l1l1llll_l1_:
			l1llll1l1l111_l1_ = l1llll1l1l111_l1_[2:]
			if kodi_version<19: l1llll1l1l111_l1_ = l1llll1l1l111_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ泻"))
			l1llll1l1l111_l1_ = base64.b64decode(l1llll1l1l111_l1_)
			if kodi_version>18.99: l1llll1l1l111_l1_ = l1llll1l1l111_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ泼"))
			link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ泽"),l1llll1l1l111_l1_,re.DOTALL)
			link = link[0]
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ泾") not in link:
				if l11lll_l1_ (u"ࠨ࠱࠲ࠫ泿") in link: link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ洀")+link
				else: link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ洁")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ洂")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ洃"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ洄"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11lll_l1_ (u"ࠧࠡࠩ洅") in search:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ洆"),l11lll_l1_ (u"ࠩࠪ洇"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ洈"),l11lll_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ洉"))
		return
	#search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ洊"),l11lll_l1_ (u"࠭࠭ࠨ洋"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ洌")+search
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡴ࠳ࠬ洍")+search+l11lll_l1_ (u"ࠩ࠲ࠫ洎")
	l1111l_l1_(url)
	return
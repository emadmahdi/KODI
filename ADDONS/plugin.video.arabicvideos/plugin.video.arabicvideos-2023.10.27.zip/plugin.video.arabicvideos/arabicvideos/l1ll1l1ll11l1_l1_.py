# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ沃"),l11lll_l1_ (u"࡙ࠫࡋࡓࡕࠩ沄"))
#url = l11lll_l1_ (u"ࠬࡉ࠺࡝࡞ࡓࡳࡷࡺࡡࡣ࡮ࡨࠤࡕࡸ࡯ࡨࡴࡤࡱࡸࡢ࡜ࡌࡑࡇࡍࡤࡼ࠱࠹ࡡ࠹࠸ࡧ࡯ࡴ࡝࡞ࡎࡳࡩ࡯࡜࡝ࡲࡲࡶࡹࡧࡢ࡭ࡧࡢࡨࡦࡺࡡ࡝࡞ࡦࡥࡨ࡮ࡥ࡝࡞ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࡜࡝ࡨ࡬ࡰࡪࡥ࠰࠹࠻࠹ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫ沅")
#url = l11lll_l1_ (u"࠭ࡣ࠻࡞࡟ࡥࡸࡪࡦ࠯࡯ࡳ࠷ࠬ沆")
#url = l11lll_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡷࡩ࡬࠮࡮ࡲ࠶ࠫ沇")
#url = l11lll_l1_ (u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ࡥࡸࡪࡦ࠯࡯ࡳ࠷ࠬ沈")
url = l11lll_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠๆำี࠯࡯ࡳ࠷ࠬ沉")
url = l11lll_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡ࡬ࡩ࡭ࡧࡢ࠸࠽࠹࠴ࡠࡕࡋ࡚ࡤุ๊ศำฬࡣฬ๊ัิ๊็ࡣฬ๊รฺฺ่ࡣ࠭฻ࠩࡠࠪฦฬฬึัࡠษ็ั้๎วอ์ࠬ࠲ࡲࡶ࠳ࠨ沊")
#url = url.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ沋"))
xbmc.Player().play(url)
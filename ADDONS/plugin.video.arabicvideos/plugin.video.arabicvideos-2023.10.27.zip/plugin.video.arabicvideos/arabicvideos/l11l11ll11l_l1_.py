# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ䎛")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡒࡄࡏࡡࠪ䎜")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ䎝"),l11lll_l1_ (u"࠭วิฬไืฬืสไ็ࠣ์ࠥอไุๆหหฯ࠭䎞")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1111l_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll1llll_l1_(url)
	elif mode==454: results = l1llllll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䎟"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ䎠"),l11lll_l1_ (u"ࠩࠪ䎡"),l11lll_l1_ (u"ࠪࠫ䎢"),l11lll_l1_ (u"ࠫࠬ䎣"),l11lll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䎤"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ䎥"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎦"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䎧"),l11lll_l1_ (u"ࠩࠪ䎨"),459,l11lll_l1_ (u"ࠪࠫ䎩"),l11lll_l1_ (u"ࠫࠬ䎪"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䎫"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎬"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䎭")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ฮฬฯอสࠡๆ๋ำ๏ࠦๆหࠩ䎮"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠩࠪ䎯"),l11lll_l1_ (u"ࠪࠫ䎰"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䎱"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎲"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䎳")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭䎴"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠨࠩ䎵"),l11lll_l1_ (u"ࠩࠪ䎶"),l11lll_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䎷"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎸"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䎹")+l111ll_l1_+l11lll_l1_ (u"࠭ๅๆอ็๎๋࠭䎺"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠧࠨ䎻"),l11lll_l1_ (u"ࠨࠩ䎼"),l11lll_l1_ (u"ࠩࡤࡧࡹࡵࡲࡴࠩ䎽"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎾"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䎿")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอࠬ䏀"),l1ll1l1_l1_,451,l11lll_l1_ (u"࠭ࠧ䏁"),l11lll_l1_ (u"ࠧࠨ䏂"),l11lll_l1_ (u"ࠨ࠲ࠪ䏃"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏄"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䏅")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥํๆะ์ฬࠤ๊ีศๅฮฬࠫ䏆"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠬ࠭䏇"),l11lll_l1_ (u"࠭ࠧ䏈"),l11lll_l1_ (u"ࠧ࠲ࠩ䏉"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䏊"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䏋")+l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆ๊๊ࠢิ๐ษࠨ䏌"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠫࠬ䏍"),l11lll_l1_ (u"ࠬ࠭䏎"),l11lll_l1_ (u"࠭࠲ࠨ䏏"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䏐"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䏑"),l11lll_l1_ (u"ࠩࠪ䏒"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠪ䏓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䏔"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠬࠩࠧ䏕"): continue
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䏖"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䏗")+l111ll_l1_+title,link,451)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"ࠨࠩ䏘")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䏙"),l11lll_l1_ (u"ࠪࠫ䏚"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䏛"),url,l11lll_l1_ (u"ࠬ࠭䏜"),l11lll_l1_ (u"࠭ࠧ䏝"),l11lll_l1_ (u"ࠧࠨ䏞"),l11lll_l1_ (u"ࠨࠩ䏟"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ䏠"))
	html = response.content
	if l1lll1ll11_l1_==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䏡"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠫࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡹࡤࡺࡪࡹࠢࠨ䏢"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l1lll1ll11_l1_==l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䏣"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡓࡧࡦࡩࡳࡺࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ䏤"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭䏥") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ䏦"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࠨࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䏧"),block,re.DOTALL)
	elif l1lll1ll11_l1_ in [l11lll_l1_ (u"ࠪ࠴ࠬ䏨"),l11lll_l1_ (u"ࠫ࠶࠭䏩"),l11lll_l1_ (u"ࠬ࠸ࠧ䏪")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪ䏫"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(l1lll1ll11_l1_)]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ䏬"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ䏭"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ䏮"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ䏯"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ䏰"),l11lll_l1_ (u"ࠬษฺ็์ฬࠫ䏱"),l11lll_l1_ (u"࠭ใๅ์หࠫ䏲"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭䏳"),l11lll_l1_ (u"ࠨ้าหๆ࠭䏴"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ䏵"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ䏶"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ䏷"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ䏸")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ䏹") in html and l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠬ䏺") in l1llll_l1_:
			l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䏻"),l1llll_l1_,re.DOTALL)
			l1llll_l1_ = l1llll_l1_[0]
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ䏼"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ䏽"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ䏾"),title,re.DOTALL)
		#if any(value in title for value in l1lll1_l1_):
		if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"๋ࠬำๅี็ࠫ䏿") not in title:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䐀"),l111ll_l1_+title,link,452,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧฮๆๅอࠬ䐁") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䐂") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䐃"),l111ll_l1_+title,link,453,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐄"),l111ll_l1_+title,link,453,l1llll_l1_)
	if l1lll1ll11_l1_ in [l11lll_l1_ (u"ࠫࠬ䐅"),l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䐆")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䐇"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐈"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠣࠤ䐉"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠩࠪ䐊"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐋"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ䐌")+title,link,451)
	return
def l1lll1llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䐍"),url,l11lll_l1_ (u"࠭ࠧ䐎"),l11lll_l1_ (u"ࠧࠨ䐏"),l11lll_l1_ (u"ࠨࠩ䐐"),l11lll_l1_ (u"ࠩࠪ䐑"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠷ࡳࡵࠩ䐒"))
	html = response.content
	# l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡉࡡࡵࡧࡪࡳࡷࡿࡓࡶࡤࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䐓"),html,re.DOTALL)
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫ䐔") in str(l1l1l11_l1_):
		title = re.findall(l11lll_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭࠲࠭䐕"),html,re.DOTALL)
		title = title[0].strip(l11lll_l1_ (u"ࠧࠡࠩ䐖"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐗"),l111ll_l1_+title,url,454)
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䐘"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐙"),l111ll_l1_+title,link,454)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䐚"),url,l11lll_l1_ (u"ࠬ࠭䐛"),l11lll_l1_ (u"࠭ࠧ䐜"),l11lll_l1_ (u"ࠧࠨ䐝"),l11lll_l1_ (u"ࠨࠩ䐞"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䐟"))
	html = response.content
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ䐠"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭䐡"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䐢"),l111ll_l1_+title,link,452,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䐣"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䐤"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠣࠤ䐥"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠩࠪ䐦"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐧"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ䐨")+title,link,454)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ䐩"),l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ䐪"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䐫"),l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䐬"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䐭"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ䐮"),l11lll_l1_ (u"ࠫࠬ䐯"),l11lll_l1_ (u"ࠬ࠭䐰"),l11lll_l1_ (u"࠭ࠧ䐱"),l11lll_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䐲"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ䐳"))
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡖ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡵ࡬ࡨࡪࡄࠧ䐴"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ䐵"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䐶")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䐷")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡳࡦ࡮ࡤࡶࡾࠨࠧ䐸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭䐹"),block,re.DOTALL)
		for link,name in items:
			name = unescapeHTML(name)
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䐺"),name,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧ䐻")+l11l111l_l1_[0]
				name = l11lll_l1_ (u"ࠪࠫ䐼")
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠫࠬ䐽")
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䐾")+name+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䐿")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䑀"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䑁"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ䑂"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ䑃"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭䑄"),l11lll_l1_ (u"ࠬ࠱ࠧ䑅"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ䑆")+search
	l1111l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ᅚ")
headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᅛ") : l11lll_l1_ (u"࠭ࠧᅜ") }
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡃࡕࡐࡤ࠭ᅝ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨ฻ิ์฻ࠦวๅ็ุหึ฿ษࠨᅞ"),l11lll_l1_ (u"ࠩส่่๊ࠧᅟ"),l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬᅠ"),l11lll_l1_ (u"ࠫฬู๊ศสࠪᅡ"),l11lll_l1_ (u"ࠬฮัศ็ฯࠤ่๋ศ๋๊อีࠬᅢ"),l11lll_l1_ (u"࠭ๅ้สส๎้่ࠦࠡฮ๋ห้࠭ᅣ"),l11lll_l1_ (u"ࠧศๆๅื๊ࠦวๅษึ่ฬ๋๊ࠨᅤ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l1111l_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l1llllll_l1_(url)
	elif mode==204: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬᅥ")+text)
	elif mode==205: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩᅦ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅧ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᅨ"),l11lll_l1_ (u"ࠬ࠭ᅩ"),209,l11lll_l1_ (u"࠭ࠧᅪ"),l11lll_l1_ (u"ࠧࠨᅫ"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᅬ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅭ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᅮ"),l11ll1_l1_,205)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅯ"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᅰ"),l11ll1_l1_,204)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᅱ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᅲ"),l11lll_l1_ (u"ࠨࠩᅳ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅴ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᅵ")+l111ll_l1_+l11lll_l1_ (u"๊๋๊ࠫำหࠪᅶ"),l11ll1_l1_+l11lll_l1_ (u"ࠬࡅ࠿ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩᅷ"),201)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅸ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᅹ")+l111ll_l1_+l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠๆ็ํึฮ࠭ᅺ"),l11ll1_l1_+l11lll_l1_ (u"ࠩࡂࡃࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᅻ"),201)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅼ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᅽ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬᅾ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡷࡪࡸࡩࡦࡵࠪᅿ"),201)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆀ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᆁ")+l111ll_l1_+l11lll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᆂ"),l11ll1_l1_+l11lll_l1_ (u"ࠪࡃࡄࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᆃ"),201)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᆄ"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭ᆅ"),headers,True,l11lll_l1_ (u"࠭ࠧᆆ"),l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᆇ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡺࡡࡣࡵࠫ࠲࠯ࡅࠩࡎࡣ࡬ࡲࡗࡵࡷࠨᆈ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᆉ"),block,re.DOTALL)
		for filter,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡫ࡳࡲ࡫࠯࡮ࡱࡵࡩࡄ࡬ࡩ࡭ࡶࡨࡶࡂ࠭ᆊ")+filter
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆋ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᆌ")+l111ll_l1_+title,link,201)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᆍ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᆎ"),l11lll_l1_ (u"ࠨࠩᆏ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᆐ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᆑ"),block,re.DOTALL)
	#l111l11l1_l1_ = [l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ࠭ᆒ"),l11lll_l1_ (u"ࠬอแๅษ่ࠤࠬᆓ"),l11lll_l1_ (u"࠭ศาษ่ะࠬᆔ"),l11lll_l1_ (u"ฺࠧำฺ๋ࠬᆕ"),l11lll_l1_ (u"ࠨๅ็๎ออสࠨᆖ"),l11lll_l1_ (u"ࠩส฾ฬ์้ࠨᆗ")]
	for link,title in items:
		if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᆘ") not in link: link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᆙ"))
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆚ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆛ")+l111ll_l1_+title,link,201)
	return html
def l1111l_l1_(url):
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠨࠦࡦࡰࡴࠣࡔࡔ࡙ࡔࠡࡨ࡬ࡰࡹ࡫ࡲ࠻ࠌࠌ࡭࡫ࠦࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࡷࡵࡰ࠷࠲ࡦࡪ࡮ࡷࡩࡷࡹ࠲ࠡ࠿ࠣࡹࡷࡲ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡀࠩࠬࠎࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࠩ࠯ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠦࡠࡥࡲࡹࡳࡺ࠽࠶࠲ࠪ࠭ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡷࡲ࠲࠭ࡨ࡬ࡰࡹ࡫ࡲࡴ࠴ࠬࠎࠎࠏࡤࡢࡶࡤ࠶ࠥࡃࠠࡼࠩࡩࡳࡷࡳࠧ࠻ࡨ࡬ࡰࡹ࡫ࡲࡴ࠴࠯ࠫࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤ࠾ࠩ࠽ࠫࠬࢃࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵ࠤࡂࠦࡨࡦࡣࡧࡩࡷࡹࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫࡢࠦ࠽ࠡࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩࠍࠍࠎ࡮ࡥࡢࡦࡨࡶࡸ࠸࡛ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫࡢࠦ࠽࡛ࠡࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡈ࡙ࡒࡇ࠯ࡗࡓࡐࡋࡎࠨ࡟ࠣࡁࠥ࠭ࡇ࡛࠶ࡒࡨ࠵ࡴࡪࡕࡅࡤࡋࡼࡩࡇࡲ࠶ࡌࡾࡌࡷࡈࡆࡴ࡜࠴ࡺࡠ࡯ࡢࡗ࡛࡞ࡈ࠼ࡈࡦ࡚ࡻࡼࠬࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴ࠴࡞ࠫࡈࡵ࡯࡬࡫ࡨࠫࡢࠦ࠽ࠡࠩࡺࡥࡷࡨ࡬ࡪࡱࡱࡾࡹࡼ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࡧࡼࡎࡵࡪࡩࡊ࠸ࡌࡱࡗ࠶ࡍ࡙ࡐࡍ࡝ࡱࡘࡌࡒ࡬ࡧࡥࡓࡊ࡫ࡹࡘࡱࡨࡌࡠ࠱ࡃ࠴࡜ࡰࡊ࠿ࡐࡔࡋࡶࡍࡳࡠࡨࡣࡊ࡙ࡰࡎࡰ࡯ࡪࡓࡗࡖࡗ࡜ࡘࡎ࠳ࡘ࡮ࡱࡍࡢࡇࡈࡵࡥ࡚ࡌ࡫ࡐࡇࡻࡉࡔ࡛ࡖࡒ࡛ࡘ࠸࠶ࡪ࠱ࡏ࡙ࡨࡌࡨࡽࡥ࡯ࡏࡼ࡚࡜ࡘࡆࡒ࡯࡯࠶࡚࡞ࡉ࠱ࡦ࡮ࡼࡱࡠ࠱ࡃࡰࡤ࠷ࡵ࡞ࡓ࠲ࡄ࡚ࡦ࡙ࡇ࠳ࡔ࡯ࡑ࡮ࡩࡌࡤ࠴࡙ࡆࡍࡸࡏ࡭࠲ࡪ࡜ࡽࡎ࠼ࡉ࡫ࡗࡻ࡞࡙࡭ࡹࡏ࡯ࡐࡽࡔࡍࡅࡺࡏ࡭ࡍ࠵ࡔࡄࡏ࡮࡝࡮࡭ࡲࡎ࠳ࡐ࡮࡞࡙ࡈ࡭ࡏ࡬ࡧࡱ࡞ࢀࡁ࠱ࡐ࡭ࡅࡼࡓࡔࡋ࡭ࡐࡾ࡟ࡰࡏࡅࡋࡽࡒ࡙࡟ࡹࡎࡼ࡮࠴ࡓࡊࡣ࠶ࡏࡗࡆ࡯ࡔࡗࡊࡻࡒࡘࡱࡰࡎ࡫ࡩ࡬ࡪࡖࡃ࠽ࠨࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࡺࡸ࡬࠳࠮ࡧࡥࡹࡧ࠲࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠴࠯ࡘࡷࡻࡥ࠭ࠩࠪ࠰ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠧ࠳࡫࡮ࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠣࠤࠥᆜ")
	if l11lll_l1_ (u"ࠨࡁࡂࠫᆝ") in url: url,type = url.split(l11lll_l1_ (u"ࠩࡂࡃࠬᆞ"))
	else: type = l11lll_l1_ (u"ࠪࠫᆟ")
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᆠ"),l11lll_l1_ (u"ࠬ࠭ᆡ"),url,type)
	#if url==l11ll1_l1_: url = url+l11lll_l1_ (u"࠭࠯ࡢ࡮ࡽࠫᆢ")
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᆣ"),l11lll_l1_ (u"ࠨࠩᆤ"),url,l11lll_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠩᆥ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᆦ"),url,l11lll_l1_ (u"ࠫࠬᆧ"),headers,True,l11lll_l1_ (u"ࠬ࠭ᆨ"),l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᆩ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᆪ"))
	#WRITE_THIS(html)
	if l11lll_l1_ (u"ࠨࡩࡨࡸࡵࡵࡳࡵࡵࠪᆫ") in url: l1l1ll1_l1_ = [html]
	elif type==l11lll_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࠫᆬ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡑࡦࡹࡴࡦࡴࡖࡰ࡮ࡪࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡢ࡮ࠡࠬ࠿࠳ࡩ࡯ࡶ࠿࡞ࡱࠤ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬᆭ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠫࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᆮ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠬ࡬ࡪࡦࡨࡶࡤ࠷ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᆯ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡴࡳࡧࡱࡨ࡮ࡴࡧࡠࡵࡨࡶ࡮࡫ࡳࠨᆰ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡔ࡮࡬ࡨࡪࡸ࡟࠳ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭ᆱ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨ࠳࠴࠵ࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᆲ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠥࡶࡡࡨࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡷࡥࡧࡹࠢࠨᆳ"),html,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱࡫ࡵ࡯ࡵࡧࡵࠫᆴ"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᆵ"),l11lll_l1_ (u"ࠬ࠭ᆶ"),l11lll_l1_ (u"࠭ࠧᆷ"),str(l1l1ll1_l1_))
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡱࡻ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫᆸ"),block,re.DOTALL)
	l111llll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨᆹ"),l11lll_l1_ (u"ࠩไ๎้๋ࠧᆺ"),l11lll_l1_ (u"ࠪห฿์๊สࠩᆻ"),l11lll_l1_ (u"่๊๊ࠫษࠩᆼ"),l11lll_l1_ (u"ࠬอูๅษ้ࠫᆽ"),l11lll_l1_ (u"࠭็ะษไࠫᆾ"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧᆿ"),l11lll_l1_ (u"ࠨ฻ิฺࠬᇀ"),l11lll_l1_ (u"่๋ࠩึาว็ࠩᇁ"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩᇂ")]
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᇃ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᇄ"),l11lll_l1_ (u"࠭ࠧᇅ"),9999)
	items = re.findall(l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇆ"),block,re.DOTALL)
	if not items:
		items = re.findall(l11lll_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡊࡶࡨࡱࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᇇ"),block,re.DOTALL)
		links,l111l111l_l1_,l1l111_l1_ = zip(*items)
		items = zip(l111l111l_l1_,links,l1l111_l1_)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		#link = escapeUNICODE(link)
		#link = QUOTE(link)
		if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᇈ") in link: continue
		link = link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᇉ"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᇊ"))
		if l11lll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬᇋ") in link or any(value in title for value in l111llll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᇌ"),l111ll_l1_+title,link,202,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪᇍ") in link and l11lll_l1_ (u"ࠨษ็ั้่ษࠨᇎ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᇏ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᇐ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᇑ"),l111ll_l1_+title,link,203,l1llll_l1_)
					l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠬ࠵ࡰࡢࡥ࡮࠳ࠬᇒ") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇓ"),l111ll_l1_+title,link+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧᇔ"),201,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇕ"),l111ll_l1_+title,link,203,l1llll_l1_)
	if type in [l11lll_l1_ (u"ࠩࠪᇖ"),l11lll_l1_ (u"ࠪࡱࡦ࡯࡮ࡱࡣࡪࡩࠬᇗ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᇘ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᇙ"),block,re.DOTALL)
			for link,title in items:
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				title = title.replace(l11lll_l1_ (u"࠭วๅืไัฮࠦࠧᇚ"),l11lll_l1_ (u"ࠧࠨᇛ"))
				if l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫᇜ") in url:
					l1111llll_l1_ = link.split(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨᇝ"))[1]
					l111ll11l_l1_ = url.split(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇞ"))[1]
					link = url.replace(l11lll_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᇟ")+l111ll11l_l1_,l11lll_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᇠ")+l1111llll_l1_)
				if title!=l11lll_l1_ (u"࠭ࠧᇡ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇢ"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧᇣ")+title,link,201)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᇤ"),l11lll_l1_ (u"ࠪࠫᇥ"),url,l11lll_l1_ (u"ࠫࠬᇦ"))
	l11l1111l_l1_,items,l111l11l_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᇧ"),url,l11lll_l1_ (u"࠭ࠧᇨ"),headers,True,l11lll_l1_ (u"ࠧࠨᇩ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᇪ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧᇫ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᇬ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11l_l1_ = []
		l111l11_l1_ = l11lll_l1_ (u"ࠫࠬᇭ").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᇮ"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧᇯ"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠧ࠰ࠩᇰ"))
		title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᇱ") + link.split(l11lll_l1_ (u"ࠩ࠲ࠫᇲ"))[-1].replace(l11lll_l1_ (u"ࠪ࠱ࠬᇳ"),l11lll_l1_ (u"ࠫࠥ࠭ᇴ"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫᇵ"),link.split(l11lll_l1_ (u"࠭࠯ࠨᇶ"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠧ࠱ࠩᇷ")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lllll_l1_ = str(items).count(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪᇸ"))
	l11l1111l_l1_ = str(items).count(l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬᇹ"))
	if l111lllll_l1_>1 and l11l1111l_l1_>0 and l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬᇺ") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᇻ") in link:
				#link = QUOTE(link)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇼ"),l111ll_l1_+title,link,203)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨᇽ") not in link:
				#if l11lll_l1_ (u"ࠧࠦࠩᇾ") not in link: link = QUOTE(link)
				#else: link = QUOTE(l111l_l1_(link))
				#link = l111l_l1_(link)
				title = l111l_l1_(title)
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᇿ"),l111ll_l1_+title,link,202)
	return
def PLAY(url):
	#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩሀ"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡ࠳࠴࠵ࠬሁ"))
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭ሂ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ሃ"),l11lll_l1_ (u"࠭ࠧሄ"),url,l11lll_l1_ (u"ࠧࡑࡎࡄ࡝࠲࠷ࡳࡵࠩህ"))
	#url = l111l_l1_(QUOTE(url))
	hostname = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬሆ"),url,l11lll_l1_ (u"ࠩࠪሇ"),headers,True,True,l11lll_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧለ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩሉ"))
	id = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሊ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧላ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩሌ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩል"),l11lll_l1_ (u"ࠩࠪሎ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ሏ"),l11lll_l1_ (u"ࠫ๏ืฬ๊ࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨሐ"))
	#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬሑ"),l11lll_l1_ (u"࠭ࡅࡎࡃࡇࠤࡘ࡚ࡁࡓࡖࠣࡘࡎࡓࡉࡏࡉࠣ࠵࠶࠷ࠧሒ"))
	if l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨሓ") in html:
		#parts = url.split(l11lll_l1_ (u"ࠨ࠱ࠪሔ"))
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨሕ"))
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧሖ"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬሗ"),headers,True,True,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩመ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫሙ"))
		l1111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሚ"),l11lll1l_l1_,re.DOTALL)
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩማ"),l11lll1l_l1_,re.DOTALL)
		l1111lll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ሜ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࡟ࡲ࠯࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫም"),l11lll1l_l1_)
		l1111l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬሞ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l111ll111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧሟ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		items = l1111ll1l_l1_+l1l1lll_l1_+l1111lll1_l1_+l1111l1ll_l1_+l1111l1l1_l1_+l111ll111_l1_
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሠ"),l11lll_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠹࠺࠴ࠨሡ"))
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሢ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l11lll_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧሣ") in server: continue
			if l11lll_l1_ (u"ࠪ࠲࡯ࡶࡧࠨሤ") in server: continue
			if l11lll_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫሥ") in server: continue
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ሦ"),title,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11l111l_l1_[0]
				if l11l111l_l1_ in title: title = title.replace(l11l111l_l1_+l11lll_l1_ (u"࠭ࡰࠨሧ"),l11lll_l1_ (u"ࠧࠨረ")).replace(l11l111l_l1_,l11lll_l1_ (u"ࠨࠩሩ")).strip(l11lll_l1_ (u"ࠩࠣࠫሪ"))
				l11l111l_l1_ = l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨራ")+l11l111l_l1_
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠫࠬሬ")
			#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬር"),l11lll_l1_ (u"࡛࠭ࠨሮ")+str(id)+l11lll_l1_ (u"ࠧ࡞ࠢࠣ࡟ࠬሯ")+str(hostname)+l11lll_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ሰ")+str(title)+l11lll_l1_ (u"ࠩࡠࠤࠥࡡࠧሱ")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠪࡡࠬሲ"))
			if server.isdigit():
				link = hostname+l11lll_l1_ (u"ࠫ࠴ࡅࡰࡰࡵࡷ࡭ࡩࡃࠧሳ")+id+l11lll_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩሴ")+server+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧስ")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨሶ")+l11l111l_l1_
			else:
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ሷ") not in server: server = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨሸ")+server
				l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫሹ"),title,re.DOTALL)
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩሺ")+l11l111l_l1_[0]
				else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭ሻ")
				link = server+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧሼ")+l11l111l_l1_
			l1111_l1_.append(link)
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧሽ"),l11lll_l1_ (u"ࠨ࡝ࠪሾ")+l11l111l_l1_+l11lll_l1_ (u"ࠩࡠࠤࠥࠦࠠ࡜ࠩሿ")+title+l11lll_l1_ (u"ࠪࡡࠬቀ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩቁ"), l1111_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ቂ"),l11lll_l1_ (u"࠭ࠧቃ"),l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࠦ࠱ࠨቄ"),	str(len(items)))
	if l11lll_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦࡑࡳࡼ࠭ቅ") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨቆ"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪቇ") }
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧቈ")
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ቉"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧቊ"),l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠧࠨቋ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬቌ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧቍ"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ቎"),l11lll_l1_ (u"ࠫࠬ቏"),l11l11l_l1_,l11lll1l_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ቐ"),l11lll1l_l1_,re.DOTALL)
		for block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨቑ"),block,re.DOTALL)
			for link,name,l11l111l_l1_ in items:
				link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨቒ")+name+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬቓ")+l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧቔ")+l11l111l_l1_
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧቕ") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨቖ"):l11lll_l1_ (u"ࠬ࠭቗") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩቘ"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ቙") }
		l11l11l_l1_ = hostname + l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫቚ")+id
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ቛ"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫቜ"),l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨቝ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ቞"))
		if l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤࡷࡲࡸ࠭቟") in l11lll1l_l1_:
			l1111lll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭በ"),l11lll1l_l1_,re.DOTALL)
			for l11l1l1_l1_ in l1111lll1_l1_:
				if l11lll_l1_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨቡ") not in l11l1l1_l1_ and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧቢ") in l11l1l1_l1_:
					l11l1l1_l1_ = l11l1l1_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧባ")
					l1111_l1_.append(l11l1l1_l1_)
				elif l11lll_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫቤ") in l11l1l1_l1_:
					l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭ብ")
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪቦ"),l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨቧ"),headers,True,True,l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬቨ"))
					l111l11ll_l1_ = response.content#.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧቩ"))
					l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡁࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࠫ࠰࠱࠲࠳࠭ࠨቪ"),l111l11ll_l1_,re.DOTALL)
					for l11l11111_l1_ in l111l11_l1_:
						l111l1l1l_l1_ = l11lll_l1_ (u"ࠫࠬቫ")
						l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧቬ"),l11l11111_l1_,re.DOTALL)
						for l111ll1l1_l1_ in l1111l1ll_l1_:
							item = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧቭ"),l111ll1l1_l1_,re.DOTALL)
							if item:
								l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬቮ")+item[0]
								break
						for l111ll1l1_l1_ in reversed(l1111l1ll_l1_):
							item = re.findall(l11lll_l1_ (u"ࠨ࡞ࡺࡠࡼ࠱ࠧቯ"),l111ll1l1_l1_,re.DOTALL)
							if item:
								l111l1l1l_l1_ = item[0]
								break
						l1111l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨተ"),l11l11111_l1_,re.DOTALL)
						for l111l1lll_l1_ in l1111l1l1_l1_:
							l111l1lll_l1_ = l111l1lll_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫቱ")+l111l1l1l_l1_+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨቲ")+l11l111l_l1_
							l1111_l1_.append(l111l1lll_l1_)
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ታ"),l11lll_l1_ (u"࠭ࠧቴ"),l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠢ࠴ࠫት"),	str(len(l1111_l1_))	)
		elif l11lll_l1_ (u"ࠨࡵ࡯ࡳࡼ࠳࡭ࡰࡶ࡬ࡳࡳ࠭ቶ") in l11lll1l_l1_:
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"ࠩ࠿࡬࠻ࠦࠧቷ"),l11lll_l1_ (u"ࠪࡁࡂࡋࡎࡅ࠿ࡀࠤࡂࡃࡓࡕࡃࡕࡘࡂࡃࠧቸ"))+l11lll_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠬቹ")
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"ࠬࡂࡨ࠴ࠢࠪቺ"),l11lll_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠠ࠾࠿ࡖࡘࡆࡘࡔ࠾࠿ࠪቻ"))+l11lll_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠨቼ")
			#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨች"),l11lll1l_l1_)
			#open(l11lll_l1_ (u"ࠩࡶ࠾ࡡࡢࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩቾ"),l11lll_l1_ (u"ࠪࡻࠬቿ")).write(l11lll1l_l1_)
			l1111ll11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡂࡃࡓࡕࡃࡕࡘࡂࡃࠨ࠯ࠬࡂ࠭ࡂࡃࡅࡏࡆࡀࡁࠬኀ"),l11lll1l_l1_,re.DOTALL)
			if l1111ll11_l1_:
				for l11l11111_l1_ in l1111ll11_l1_:
					if l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫኁ") not in l11l11111_l1_: continue
					#DIALOG_OK(l11lll_l1_ (u"࠭ࠧኂ"),l11lll_l1_ (u"ࠧࠨኃ"),l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵࠶࠷ࠧኄ"),	l11l11111_l1_	)
					l111ll1ll_l1_ = l11lll_l1_ (u"ࠩࠪኅ")
					l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩኆ"),l11l11111_l1_,re.DOTALL)
					for l111ll1l1_l1_ in l1111l1ll_l1_:
						item = re.findall(l11lll_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬኇ"),l111ll1l1_l1_,re.DOTALL)
						if item:
							l111ll1ll_l1_ = l11lll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪኈ")+item[0]
							break
					l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ኉"),l11l11111_l1_,re.DOTALL)
					if l1111l1ll_l1_:
						for l111l1l1l_l1_,l111l1ll1_l1_ in l1111l1ll_l1_:
							l111l1ll1_l1_ = l111l1ll1_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨኊ")+l111l1l1l_l1_+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬኋ")+l111ll1ll_l1_
							l1111_l1_.append(l111l1ll1_l1_)
					else:
						l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩኌ"),l11l11111_l1_,re.DOTALL)
						for l111l1ll1_l1_,l111l1l1l_l1_ in l1111l1ll_l1_:
							l111l1ll1_l1_ = l111l1ll1_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬኍ"))+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ኎")+l111l1l1l_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ኏")+l111ll1ll_l1_
							l1111_l1_.append(l111l1ll1_l1_)
			else:
				l1111l1ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࡟ࡻ࠰࠯࠼ࠨነ"),l11lll1l_l1_,re.DOTALL)
				for l111l1ll1_l1_,l111l1l1l_l1_ in l1111l1ll_l1_:
					l111l1ll1_l1_ = l111l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩኑ"))+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩኒ")+l111l1l1l_l1_+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ና")
					l1111_l1_.append(l111l1ll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨኔ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪን"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭ኖ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧኗ"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩኘ"),l11lll_l1_ (u"ࠨ࠭ࠪኙ"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ኚ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡲࡺࠨኛ"),l11lll_l1_ (u"ࠫࠬኜ"),headers,True,l11lll_l1_ (u"ࠬ࠭ኝ"),l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬኞ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬኟ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡶࡩࡱ࡫ࡣࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭አ"),html,re.DOTALL)
	if l1ll_l1_ and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬኡ"),block,re.DOTALL)
		l111lll11_l1_,l111l1l11_l1_ = [],[]
		for category,title in items:
			#if title in [l11lll_l1_ (u"ࠪี๏อึส๋ࠢࠤ๊฻วา฻๊ࠫኢ")]: continue
			l111lll11_l1_.append(category)
			l111l1l11_l1_.append(title)
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫኣ"), l111l1l11_l1_)
		if l1l_l1_ == -1 : return
		category = l111lll11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"ࠬ࠭ኤ")
	url = l11ll1_l1_ + l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪእ")+search+l11lll_l1_ (u"ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫኦ")+category+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽࠲ࠩኧ")
	l1111l_l1_(url)
	return
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫከ"),l11lll_l1_ (u"ࠪࠫኩ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬኪ"),l11lll_l1_ (u"ࠬ࠭ካ"),filter,url)
	# for l111l1111_l1_ filter:		l1l11lll_l1_ = [l11lll_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩኬ"),l11lll_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ክ"),l11lll_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨኮ"),l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫኯ")]
	l1l11lll_l1_ = [l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬኰ"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ኱"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫኲ"),l11lll_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧኳ")]
	if l11lll_l1_ (u"ࠧࡀࠩኴ") in url: url = url.split(l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬኵ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭኶"),1)
	if filter==l11lll_l1_ (u"ࠪࠫ኷"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬኸ"),l11lll_l1_ (u"ࠬ࠭ኹ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪኺ"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫኻ"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࠪኼ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠩࡀࠫኽ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬኾ")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ኿")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧዀ")+category+l11lll_l1_ (u"࠭࠽࠱ࠩ዁")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩዂ"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬዃ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫዄ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ዅ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ዆")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭዇"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨወ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨዉ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫዊ"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪዋ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࠧዌ")+l1l11l11_l1_
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫው"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨዎ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዏ"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧዐ")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧዑ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧዒ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪዓ"),l11lll_l1_ (u"ࠫࠬዔ"),9999)
	html = OPENURL_CACHED(l11111l_l1_,url+l11lll_l1_ (u"ࠬ࠵ࡡ࡭ࡼࠪዕ"),l11lll_l1_ (u"࠭ࠧዖ"),headers,l11lll_l1_ (u"ࠧࠨ዗"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ዘ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡄ࡮ࡦࡾࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡆࡤࡸࡦ࠮࠮ࠫࡁࠬࡊ࡮ࡲࡴࡦࡴ࡚ࡳࡷࡪࠧዙ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# for l111l1111_l1_ filter:		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂࡨ࠳ࠩዚ"),block,re.DOTALL)
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡨࡦࡺࡡ࠮ࡨࡲࡶ࡙ࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪዛ"),block,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ዜ"),l11lll_l1_ (u"࠭ࠧዝ"),l11lll_l1_ (u"ࠧࠨዞ"),str(l1lll11l_l1_))
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#name = name.replace(l11lll_l1_ (u"ࠨ࠯࠰ࠫዟ"),l11lll_l1_ (u"ࠩࠪዠ"))
		name = name.replace(l11lll_l1_ (u"ࠪหำะ๊ศำࠣࠫዡ"),l11lll_l1_ (u"ࠫࠬዢ"))
		name = name.replace(l11lll_l1_ (u"ูࠬๆสࠢส่ส์สศฮࠪዣ"),l11lll_l1_ (u"࠭วๅี้อࠬዤ"))
		items = re.findall(l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨዥ"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠨ࠿ࠪዦ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ዧ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪየ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫዩ"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭ዪ"),l11l11l_l1_,201)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ያ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨዬ"),l11l11l_l1_,205,l11lll_l1_ (u"ࠨࠩይ"),l11lll_l1_ (u"ࠩࠪዮ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫዯ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ደ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨዱ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨዲ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪዳ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬዴ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩድ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬዶ")+name,l11l11l_l1_,204,l11lll_l1_ (u"ࠫࠬዷ"),l11lll_l1_ (u"ࠬ࠭ዸ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨዹ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			option = option.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪዺ"),l11lll_l1_ (u"ࠨࠩዻ"))
			if option in l1l1l1_l1_: continue
			#if option==l11lll_l1_ (u"ࠩส่่๊ࠧዼ"): continue
			#option = l11lll_l1_ (u"ࠪ࡟ࠬዽ")+option+l11lll_l1_ (u"ࠫࡢ࠭ዾ")
			#if l11lll_l1_ (u"ࠬอไไๆࠪዿ") in option: DIALOG_OK(l11lll_l1_ (u"࠭ࠧጀ"),l11lll_l1_ (u"ࠧࠨጁ"),l11lll_l1_ (u"ࠨࠩጂ"),l11lll_l1_ (u"ࠩ࡞ࠫጃ")+str(option)+l11lll_l1_ (u"ࠪࡡࠬጄ"))
			#if l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪጅ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ጆ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨጇ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩገ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪጉ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫጊ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧጋ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧጌ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧግ")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩጎ")+name
			if type==l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨጏ"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጐ"),l111ll_l1_+title,url,204,l11lll_l1_ (u"ࠩࠪ጑"),l11lll_l1_ (u"ࠪࠫጒ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ጓ"))
			elif type==l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩጔ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨጕ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ጖"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬ጗")+l1l1111l_l1_
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩጘ"),l111ll_l1_+title,l11l1l1_l1_,201)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጙ"),l111ll_l1_+title,url,205,l11lll_l1_ (u"ࠫࠬጚ"),l11lll_l1_ (u"ࠬ࠭ጛ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧጜ"),l11lll_l1_ (u"ࠧࠨጝ"),filters,l11lll_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠱࠲ࠩጞ"))
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫጟ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ጠ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨጡ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.replace(l11lll_l1_ (u"ࠬࡃࠦࠨጢ"),l11lll_l1_ (u"࠭࠽࠱ࠨࠪጣ"))
	filters = filters.strip(l11lll_l1_ (u"ࠧࠧࠩጤ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠨ࠿ࠪጥ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠩࠩࠫጦ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠪࡁࠬጧ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠫࠬጨ")
	# for l111l1111_l1_ filter:		l1ll11ll_l1_ = [l11lll_l1_ (u"ࠬࡉࡡࡵࡧࡪࡳࡷࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጩ"),l11lll_l1_ (u"࡙࠭ࡦࡣࡵࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬጪ"),l11lll_l1_ (u"ࠧࡈࡧࡱࡶࡪࡉࡨࡦࡥ࡮ࡆࡴࡾࠧጫ"),l11lll_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪጬ")]
	l1ll11ll_l1_ = [l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫጭ"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩጮ"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪጯ"),l11lll_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭ጰ")]
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨጱ")
		if l11lll_l1_ (u"ࠧࠦࠩጲ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪጳ") and value!=l11lll_l1_ (u"ࠩ࠳ࠫጴ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧጵ")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧጶ") and value!=l11lll_l1_ (u"ࠬ࠶ࠧጷ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨጸ")+key+l11lll_l1_ (u"ࠧ࠾ࠩጹ")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬጺ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫጻ")+key+l11lll_l1_ (u"ࠪࡁࠬጼ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨጽ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧጾ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩጿ"),l11lll_l1_ (u"ࠧ࠾ࠩፀ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩፁ"),l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪፂ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫፃ"),l11lll_l1_ (u"ࠫࠬፄ"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ፅ"))
	return l1ll1l1l_l1_
l11lll_l1_ (u"ࠨࠢࠣࠌࡩ࡭ࡱࡺࡥࡳࡵ࠽ࠍ࠶ࡹࡴࠡ࡯ࡨࡸ࡭ࡵࡤࠊࠋࠫࡹࡸ࡫ࡤࠡࡰࡲࡻࠥ࡯࡮ࠡࡹࡨࡦࡸ࡯ࡴࡦࠫࠍࡥࡩࡪࡩ࡯ࡩࠣࡪ࡮ࡲࡴࡦࡴࠣࡸࡴࠦࡳࡦࡣࡵࡧ࡭ࠐࡐࡐࡕࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠦࡠࡥࡲࡹࡳࡺ࠽࠶࠲ࠍࠍࡩࡧࡴࡢ࠼ࠌ࡟ࠬࡉࡡࡵࡧࡪࡳࡷࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨ࠮ࠪ࡝ࡪࡧࡲࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫࡌ࡫࡮ࡳࡧࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫ࠱࠭ࡑࡶࡣ࡯࡭ࡹࡿࡃࡩࡧࡦ࡯ࡇࡵࡸࠨ࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷ࠿ࠏࡃࡰࡱ࡮࡭ࡪ࡚ࠦࠫࠡࡕࡉࡋ࠳ࡔࡐࡍࡈࡒࠏࠐࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠵ࡲࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡱ࡯ࡨࠥࡳࡥࡵࡪࡲࡨࠥࡨࡵࡵࠢࡶࡸ࡮ࡲ࡬ࠡࡹࡲࡶࡰ࡯࡮ࡨࠫࠌࠍ࠭ࡻࡳࡦࡦࠣ࡭ࡳࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠮ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡱࡶࡣ࡯࡭ࡹࡿ࠽ࡘࡇࡅ࠱ࡉࡒࠦࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷࡃ࠲࠱࠴࠳ࠎࠏࠐࠊࡧ࡫࡯ࡸࡪࡸࡳ࠻ࠋ࠶ࡶࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠏࠉࠩࡱ࡯ࡨࠥࡳࡥࡵࡪࡲࡨࠥࡨࡵࡵࠢࡶࡸ࡮ࡲ࡬ࠡࡹࡲࡶࡰ࡯࡮ࡨࠫࠍࡋࡊ࡚࠺ࠊࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡦࡸࡴ࠰ࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠯࠳࠲࠴࠽ࠏࡍࡅࡕ࠼ࠌ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴ࡡࡳࡶ࠲ࡵࡺࡧ࡬ࡪࡶࡼ࠳࠹ࡑࠥ࠳࠲ࡅࡰࡺࡘࡡࡺࠌࠥࠦࠧፆ")
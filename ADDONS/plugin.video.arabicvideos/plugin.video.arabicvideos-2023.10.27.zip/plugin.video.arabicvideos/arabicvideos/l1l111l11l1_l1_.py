# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㖺")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡎࡕ࡞ࡤ࠭㖻")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ㖼"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ㖽"),l11lll_l1_ (u"ࠪห้อโิษ่ࠫ㖾"),l11lll_l1_ (u"ࠫ฾ืึࠡษ็้ื๐ฯࠨ㖿")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l1111l_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l11111_l1_(url,text)
	elif mode==704: results = l1l11l_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡺࡪ࡭ࡤ࠲࠾࠭㗀")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㗁"),l1ll1l1_l1_,l11lll_l1_ (u"ࠧࠨ㗂"),l11lll_l1_ (u"ࠨࠩ㗃"),l11lll_l1_ (u"ࠩࠪ㗄"),l11lll_l1_ (u"ࠪࠫ㗅"),l11lll_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㗆"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㗇"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㗈"),l11lll_l1_ (u"ࠧࠨ㗉"),709,l11lll_l1_ (u"ࠨࠩ㗊"),l11lll_l1_ (u"ࠩࠪ㗋"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㗌"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㗍"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㗎"),l11lll_l1_ (u"࠭ࠧ㗏"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗐"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㗑")+l111ll_l1_+l11lll_l1_ (u"่้ࠩ๏ุࠧ㗒"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠪࠫ㗓"),l11lll_l1_ (u"ࠫࠬ㗔"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㗕"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㗖"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㗗")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ㗘"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠩࠪ㗙"),l11lll_l1_ (u"ࠪࠫ㗚"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㗛"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㗜"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㗝")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭㗞"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠨࠩ㗟"),l11lll_l1_ (u"ࠩࠪ㗠"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ㗡"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㗢"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㗣")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭㗤"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠧࠨ㗥"),l11lll_l1_ (u"ࠨࠩ㗦"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㗧"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㗨"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㗩"),l11lll_l1_ (u"ࠬ࠭㗪"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰ࡮࠯ࡷࡳࡵ࠳࡮ࡢࡸࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠨ㗫"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧ㗬"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠨ࠾ࡥࡂࠬ㗭"),l11lll_l1_ (u"ࠩࠪ㗮")).strip(l11lll_l1_ (u"ࠪࠤࠬ㗯"))
		if title in l1l1l1_l1_: continue
		if link.endswith(l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠪ㗰")): continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㗱"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㗲")+l111ll_l1_+title,link,704)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㗳"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗴"),l11lll_l1_ (u"ࠩࠪ㗵"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ㗶"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ㗷"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠬ࠭㗸"))
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ㗹"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	title = title.replace(l11lll_l1_ (u"ࠧ࠽ࡤࡁࠫ㗺"),l11lll_l1_ (u"ࠨࠩ㗻")).strip(l11lll_l1_ (u"ࠩࠣࠫ㗼"))
	#	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㗽"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㗾")+l111ll_l1_+title,link,704)
	return
def l1l11l_l1_(url):
	l1ll1ll1l_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㗿"),url,l11lll_l1_ (u"࠭ࠧ㘀"),l11lll_l1_ (u"ࠧࠨ㘁"),l11lll_l1_ (u"ࠨࠩ㘂"),l11lll_l1_ (u"ࠩࠪ㘃"),l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㘄"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡷࡵ࡬ࡦ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㘅"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭㘆"),l11lll_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ㘇"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㘈"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠨࠩ㘉"),block)]
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㘊"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㘋"),l11lll_l1_ (u"ࠫࠬ㘌"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㘍"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"࠭࠺ࠡࠩ㘎")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㘏"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㘐"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㘑"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㘒"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㘓"),l11lll_l1_ (u"ࠬ࠭㘔"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘕"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡪࡴࡵࡴࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㘖"),html,re.DOTALL)
	if l1l1l111l_l1_:
		block = l1l1l111l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㘗"),block,re.DOTALL)
		if 1:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㘘"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㘙"),l11lll_l1_ (u"ࠫࠬ㘚"),9999)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ㘛"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘜"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	if not l1ll1ll1l_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠧࠨ㘝")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㘞"),l11lll_l1_ (u"ࠩࠪ㘟"),request,url)
	if request==l11lll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ㘠"):
		url,search = url.split(l11lll_l1_ (u"ࠫࡄ࠭㘡"),1)
		data = l11lll_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ㘢")+search
		headers = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㘣"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ㘤")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㘥"),url,data,headers,l11lll_l1_ (u"ࠩࠪ㘦"),l11lll_l1_ (u"ࠪࠫ㘧"),l11lll_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ㘨"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㘩"),url,l11lll_l1_ (u"࠭ࠧ㘪"),l11lll_l1_ (u"ࠧࠨ㘫"),l11lll_l1_ (u"ࠨࠩ㘬"),l11lll_l1_ (u"ࠩࠪ㘭"),l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㘮"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠫࠬ㘯"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ㘰"))
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ㘱"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㘲"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠨࠩ㘳"),link,title))
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㘴"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㘵"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㘶"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㘷"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ㘸"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㘹"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ㘺"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡦࡦࠦ࡭ࡨࡤࠣࡸࡦࡨ࡬ࡦࠢࡩࡹࡱࡲࠢࠩ࠰࠭ࡃ࠮ࠨࡣ࡭ࡧࡤࡶ࡫࡯ࡸࠣࠩ㘻"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㘼"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬ㘽"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㘾"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㘿"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ㙀"),l11lll_l1_ (u"ࠨใํ่๊࠭㙁"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ㙂"),l11lll_l1_ (u"ࠪ็้๐ศࠨ㙃"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ㙄"),l11lll_l1_ (u"ࠬํฯศใࠪ㙅"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭㙆"),l11lll_l1_ (u"ฺࠧำูࠫ㙇"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ㙈"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ㙉"),l11lll_l1_ (u"ุ้ࠪือ๋หࠪ㙊")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭㙋"))
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㙌") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ㙍")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ㙎"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㙏") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㙐")+l1llll_l1_.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㙑"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭㙒"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ㙓"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㙔"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㙕"):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㙖"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㙗") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㙘"),l111ll_l1_+title,link,703,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ㙙") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㙚"),l111ll_l1_+title,link,701,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙛"),l111ll_l1_+title,link,703,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㙜"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ㙝")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㙞"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㙟"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠫࠨ࠭㙠"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ㙡")+link.strip(l11lll_l1_ (u"࠭࠯ࠨ㙢"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙣"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ㙤")+title,link,701)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㙥"),l11lll_l1_ (u"ࠪࠫ㙦"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ㙧"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㙨"),url,l11lll_l1_ (u"࠭ࠧ㙩"),l11lll_l1_ (u"ࠧࠨ㙪"),l11lll_l1_ (u"ࠨࠩ㙫"),l11lll_l1_ (u"ࠩࠪ㙬"),l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㙭"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧ㙮"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㙯"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"࠭ࠧ㙰")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࠨࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ㙱"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㙲"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠩࠦࠫ㙳"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㙴"),l111ll_l1_+title,url,703,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ㙵"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠭࠴ࠪࡀࠫ࠿ࡷࡨࡸࡩࡱࡶࡁࠫ㙶"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㙷"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࠬ㙸")+l1ll1_l1_+l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㙹"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨ㙺")+l1ll1_l1_+l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㙻"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡕࡨࡥࡸࡵ࡮ࠨ㙼")+l1ll1_l1_+l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ㙽"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃࡂ࡬ࡪࡀ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠧ㙾"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㙿"),l11lll_l1_ (u"ࠨࠩ㚀"),l11lll_l1_ (u"ࠩࠪ㚁"),l11lll_l1_ (u"ࠪ࠶࠷࠸࠲࠳ࠩ㚂"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ㚃"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㚄"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"࠭࠮࠰ࠩ㚅"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㚆")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ㚇"))
			title = title.replace(l11lll_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧ㚈"),l11lll_l1_ (u"ࠪࠤࠬ㚉"))
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㚊"),l111ll_l1_+title,link,702,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭㚋"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㚌") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㚍")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ㚎"))
		#		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㚏"),l111ll_l1_+title,link,702,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l11l1ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㚐"),l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ㚑"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㚒"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㚓"),l11lll_l1_ (u"ࠧࠨ㚔"),l11lll_l1_ (u"ࠨࠩ㚕"),l11lll_l1_ (u"ࠩࠪ㚖"),l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㚗"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ㚘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l111lll_l1_ link
		link = re.findall(l11lll_l1_ (u"ࠬࠨࡐ࡭ࡣࡼࡩࡷ࡮࡯࡭ࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㚙"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l11l1ll_l1_.append(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ㚚"))
			l1111_l1_.append(link)
		# l11l1ll1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨ㚛"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ㚜"))
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㚝")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ㚞"))
				l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡓࡦࡴࡹࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㚟"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㚠"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				title = title.strip(l11lll_l1_ (u"࠭࡜࡯ࠩ㚡"))
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㚢")+title+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㚣"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l11l1ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㚤"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㚥"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ㚦"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭㚧"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ㚨"),l11lll_l1_ (u"ࠧࠬࠩ㚩"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ㚪")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ㚫"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ㚬")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㚭"))
	return
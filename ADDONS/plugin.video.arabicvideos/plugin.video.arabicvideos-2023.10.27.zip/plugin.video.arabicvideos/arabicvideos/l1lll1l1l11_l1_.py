# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ⍕")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡉࡇ࠸࡟ࠨ⍖")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1lll1llll1_l1_.l1lll1lllll_l1_
# l1l1ll11_l1_	https://l1lll1ll111_l1_.l1lll1llll1_l1_.l1lll1ll1ll_l1_
# l1lll1lll11_l1_ content l1llll11lll_l1_ html	https://l1lll1lll1l_l1_.faselhd.l1lll1l1l1l_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/l1lll1l1ll1_l1_.l1llll1l1l1_l1_
# l1llll1111l_l1_	https://l1llll1111l_l1_.com/l1llll11ll1_l1_
# l1llll11l1l_l1_	https://www.l1llll11l1l_l1_.com/l1lll1llll1_l1_
# l1llll11l11_l1_	https://www.l1llll11l11_l1_.com/l1llll11111_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้๋ีศำ฼อࠥอไฮำฬࠫ⍗"),l11lll_l1_ (u"ࠫฬ๐ฬ๋ࠢห๎ุะࠧ⍘"),l11lll_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼อࠬ⍙"),l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ⍚"),l11lll_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่อี๊ๅࠩ⍛"),l11lll_l1_ (u"ࠨษํะ๎ࠦศิฬࠣห้าฯ๋ัࠪ⍜")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==780: results = MENU()
	elif mode==781: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==782: results = l1l11l_l1_(url)
	elif mode==783: results = PLAY(url)
	elif mode==784: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⍝")+text)
	elif mode==785: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⍞")+text)
	elif mode==786: results = l1lllll111l_l1_(url,l1l11l1_l1_)
	elif mode==789: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⍟"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⍠"),l11lll_l1_ (u"࠭ࠧ⍡"),789,l11lll_l1_ (u"ࠧࠨ⍢"),l11lll_l1_ (u"ࠨࠩ⍣"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⍤"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⍥"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⍦"),l11lll_l1_ (u"ࠬ࠭⍧"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⍨"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ⍩"),l11lll_l1_ (u"ࠨࠩ⍪"),l11lll_l1_ (u"ࠩࠪ⍫"),l11lll_l1_ (u"ࠪࠫ⍬"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⍭"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡲࡩࡴࡶ࠰ࡴࡦ࡭ࡥࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⍮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ⍯"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ⍰"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⍱") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⍲"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⍳")+l111ll_l1_+title,link,781)
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⍴"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⍵"),l11lll_l1_ (u"࠭ࠧ⍶"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࡷࡴࡩࡩࡢ࡮࠰ࡦࡴࡾࠧ⍷"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⍸"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⍹"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⍺") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⍻"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⍼")+l111ll_l1_+title,link,781,l11lll_l1_ (u"࠭ࠧ⍽"),l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠩ⍾"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⍿"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎀"),l11lll_l1_ (u"ࠪࠫ⎁"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⎂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⎃"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ⎄"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⎅") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎆"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⎇")+l111ll_l1_+title,link,781)
	return html
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠪࠫ⎈")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⎉"),l11lll_l1_ (u"ࠬ࠭⎊"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⎋"),url,l11lll_l1_ (u"ࠧࠨ⎌"),l11lll_l1_ (u"ࠨࠩ⎍"),l11lll_l1_ (u"ࠩࠪ⎎"),l11lll_l1_ (u"ࠪࠫ⎏"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⎐"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ⎑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"࠭ࠧ⎒"),l11lll_l1_ (u"ࠧࠨ⎓"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠨฯ็ๆฬะࠧ⎔") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"่ࠩ์ฬูๅࠨ⎕") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⎖"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎗"),l111ll_l1_+title,link,786,l1llll_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⎘"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⎙"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⎚"),l111ll_l1_+title,link,783,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⎛"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⎜"),l111ll_l1_+title,link,783)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠪࠫ⎝")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⎞"),l11lll_l1_ (u"ࠬ࠭⎟"),l11lll_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘ࠭⎠"),url)
	# next l1l11l1_l1_
	if l11lll_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ⎡") in type or l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ⎢") in type:
		l11l11l_l1_,data = url.split(l11lll_l1_ (u"ࠩࡂࡷࡪࡶࡡࡳࡣࡷࡳࡷࠬࠧ⎣"))
		headers = {l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⎤"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⎥")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ⎦"),l11l11l_l1_,data,headers,l11lll_l1_ (u"࠭ࠧ⎧"),l11lll_l1_ (u"ࠧࠨ⎨"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⎩"))
		html = response.content
		html = l11lll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠩ⎪")+html+l11lll_l1_ (u"ࠪࡥࡷࡺࡩࡤ࡮ࡨࠫ⎫")
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⎬"),url,l11lll_l1_ (u"ࠬ࠭⎭"),l11lll_l1_ (u"࠭ࠧ⎮"),l11lll_l1_ (u"ࠧࠨ⎯"),l11lll_l1_ (u"ࠨࠩ⎰"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⎱"))
		html = response.content
	items,l1lllll1lll_l1_,filters = [],False,False
	if not type:
		# l1lllll1lll_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⎲"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⎳"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ⎴"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎵"),l111ll_l1_+title,link,781,l11lll_l1_ (u"ࠧࠨ⎶"),l11lll_l1_ (u"ࠨࡵࡸࡦࡲ࡫࡮ࡶࠩ⎷"))
				l1lllll1lll_l1_ = True
	if not type:
		# filter
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡤࡰࡱ࠳ࡴࡢࡺࡨࡷ࠭࠴ࠪࡀࠫࠥࡰࡴࡧࡤࠣࠩ⎸"),html,re.DOTALL)
		if l1l1ll1_l1_ and type!=l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⎹"):
			if l1lllll1lll_l1_: addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⎺"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⎻"),l11lll_l1_ (u"࠭ࠧ⎼"),9999)
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎽"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ⎾"),url,785,l11lll_l1_ (u"ࠩࠪ⎿"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⏀"))
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏁"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ⏂"),url,784,l11lll_l1_ (u"࠭ࠧ⏃"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⏄"))
			filters = True
	if not l1lllll1lll_l1_ and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭⏅"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⏆"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠪࡠࡳ࠭⏇"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭⏈") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏉"),l111ll_l1_+title,link,781,l1llll_l1_)
				elif l11lll_l1_ (u"࠭ๅิๆึ่ࠬ⏊") in link and l11lll_l1_ (u"ࠧฮๆๅอࠬ⏋") not in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏌"),l111ll_l1_+title,link,786,l1llll_l1_)
				elif l11lll_l1_ (u"่ࠩ์ุ๋ࠧ⏍") in link and l11lll_l1_ (u"ࠪั้่ษࠨ⏎") not in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏏"),l111ll_l1_+title,link,786,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⏐"),l111ll_l1_+title,link,783,l1llll_l1_)
		# l1lllll11ll_l1_
		length = 12 if l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭⏑") in type else 16
		data = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠩ࡮ࡲࡥࡩ࠳࡭ࡰࡴࡨ࠲࠯ࡅࠩࠡ࠰࠭ࡃࡩࡧࡴࡢ࠯ࠫ࠲࠯ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⏒"),html,re.DOTALL)
		if len(items)==length and (data or l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ⏓") in type):
			if data:
				offset = length
				action,name,value = data[0]
				action = action.replace(l11lll_l1_ (u"ࠩ࡯ࡳࡦࡪࠧ⏔"),l11lll_l1_ (u"ࠪ࡫ࡪࡺࠧ⏕")).replace(l11lll_l1_ (u"ࠫ࠲࠭⏖"),l11lll_l1_ (u"ࠬࡥࠧ⏗")).replace(l11lll_l1_ (u"࠭ࠢࠨ⏘"),l11lll_l1_ (u"ࠧࠨ⏙"))
			else:
				data = re.findall(l11lll_l1_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯ࠦࡰࡨࡩࡷࡪࡺ࠽ࠩ࠰࠭ࡃ࠮ࠬࠨ࠯ࠬࡂ࠭ࡂ࠮࠮ࠫࡁࠬࠨࠬ⏚"),url,re.DOTALL)
				if data: action,offset,name,value = data[0]
				offset = int(offset)+length
			data = l11lll_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯࠿ࠪ⏛")+action+l11lll_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬ⏜")+str(offset)+l11lll_l1_ (u"ࠫࠫ࠭⏝")+name+l11lll_l1_ (u"ࠬࡃࠧ⏞")+value
			url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࡤࡨࡲ࡯࡮࠮ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࡂࡷࡪࡶࡡࡳࡣࡷࡳࡷࠬࠧ⏟")+data
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏠"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็้ื๐ฯࠨ⏡"),url,781,l11lll_l1_ (u"ࠩࠪ⏢"),l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࡟ࠨ⏣")+type)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⏤"),url,l11lll_l1_ (u"ࠬ࠭⏥"),l11lll_l1_ (u"࠭ࠧ⏦"),l11lll_l1_ (u"ࠧࠨ⏧"),l11lll_l1_ (u"ࠨࠩ⏨"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⏩"))
	html = response.content
	#l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡱࡧࡢࡦ࡮ࡁห้ะี็์ไࡀ࠴ࡲࡡࡣࡧ࡯ࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⏪"),html,re.DOTALL)
	#if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lllll1ll1_l1_ = [],[]
	# l11l1ll1l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵ࠱࡮ࡺࡥ࡮࠰࠭ࡃࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⏫"),html,re.DOTALL)
	for l1lll1l1lll_l1_ in items:
		l1lll1ll1l1_l1_ = base64.b64decode(l1lll1l1lll_l1_)
		if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⏬"))
		link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⏭"),l1lll1ll1l1_l1_,re.DOTALL)
		if link:
			link = link[0]
			if link not in l1lllll1ll1_l1_:
				l1lllll1ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ⏮"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⏯")+server+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⏰"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧ⏱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡪࡩࡷࡀ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯࠮࡜ࡥࡽ࠶࠰࠹ࢃࠩ࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࡀ࠴ࡪࡩࡷࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࡥࡱࡺࡲࡱࡵࡡࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ⏲"),block,re.DOTALL)
		for l11l111l_l1_,l1llll1l111_l1_ in items:
			link = base64.b64decode(l1llll1l111_l1_)
			if kodi_version>18.99: link = link.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⏳"))
			if link not in l1lllll1ll1_l1_:
				l1lllll1ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ⏴"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⏵")+server+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ⏶")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ⏷"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⏸"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠫࠥ࠭⏹"),l11lll_l1_ (u"ࠬ࠳ࠧ⏺"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫ࡱࡨ࠴ࡅࡱ࠾ࠩ⏻")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⏼"))
	return
# ===========================================
#     l1llll111l_l1_ l1llll1111_l1_ l1llll11l1_l1_ l1lllll1l_l1_ 2023-10-23
# ===========================================
def l1lllllll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⏽"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⏾"),url,l11lll_l1_ (u"ࠪࠫ⏿"),l11lll_l1_ (u"ࠫࠬ␀"),l11lll_l1_ (u"ࠬ࠭␁"),l11lll_l1_ (u"࠭ࠧ␂"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ␃"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ␄"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ␅"),block,re.DOTALL)
		l1llll1ll11_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1llll1ll11_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1llll1l1l_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ␆"),block,re.DOTALL)
	return items
def l1llll1l11l_l1_(url):
	if l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸࠧ␇") not in url: l11l11l_l1_,l1llll111l1_l1_ = url,l11lll_l1_ (u"ࠬ࠭␈")
	else: l11l11l_l1_,l1llll111l1_l1_ = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩ␉"))
	l11l1l1_l1_,l1llll111ll_l1_ = l1lll1l1ll_l1_(l1llll111l1_l1_)
	l1lll1ll11l_l1_ = l11lll_l1_ (u"ࠧࠨ␊")
	for key in list(l1llll111ll_l1_.keys()):
		l1lll1ll11l_l1_ += l11lll_l1_ (u"ࠨࠨࡤࡶ࡬ࡹࠥ࠶ࡄࠪ␋")+key+l11lll_l1_ (u"ࠩࠨ࠹ࡉࡃࠧ␌")+l1llll111ll_l1_[key]
	# filter final url
	l1111111_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ࠿ࡴࡧࡳࡥࡷࡧࡴࡰࡴࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟ࡧ࡫࡯ࡸࡪࡸࡤࡠࡤ࡯ࡳࡨࡱࡳࠨ␍")+l1lll1ll11l_l1_
	return l1111111_l1_
l1lllll1l11_l1_ = [l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ␎"),l11lll_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ␏"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ␐"),l11lll_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ␑"),l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ␒"),l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ␓"),l11lll_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ␔")]
l1lllll1l1l_l1_ = [l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ␕"),l11lll_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ␖"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ␗")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ␘"),l11lll_l1_ (u"ࠨࠩ␙"))
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭␚"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ␛"),1)
	if filter==l11lll_l1_ (u"ࠫࠬ␜"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠬ࠭␝"),l11lll_l1_ (u"࠭ࠧ␞")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ␟"))
	if type==l11lll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ␠"):
		if l1lllll1l1l_l1_[0]+l11lll_l1_ (u"ࠩࡀࠫ␡") not in l1l11l1l_l1_: category = l1lllll1l1l_l1_[0]
		for i in range(len(l1lllll1l1l_l1_[0:-1])):
			if l1lllll1l1l_l1_[i]+l11lll_l1_ (u"ࠪࡁࠬ␢") in l1l11l1l_l1_: category = l1lllll1l1l_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭␣")+category+l11lll_l1_ (u"ࠬࡃ࠰ࠨ␤")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ␥")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ␦")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪ␧"))+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭␨")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ␩"))
		# l1lllll11l1_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ␪"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ␫")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ␬"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ␭"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1llll1llll_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ␮"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭␯")+l1l11l11_l1_
		l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␰"),l111ll_l1_+l11lll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ␱"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠬ࠭␲"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭␳"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␴"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ␵")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ␶"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠪࠫ␷"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ␸"))
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ␹"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭␺"),l11lll_l1_ (u"ࠧࠨ␻"),9999)
	l1lll11l_l1_ = l1lllllll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠨๅ็ࠤࠬ␼"),l11lll_l1_ (u"ࠩࠪ␽"))
		items = l1llll1l1l_l1_(block)
		if l11lll_l1_ (u"ࠪࡁࠬ␾") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ␿"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_,l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⑀"))
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⑁")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lllll1l1l_l1_[-1]:
					l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑂"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ⑃"),l11l1l1_l1_,781,l11lll_l1_ (u"ࠩࠪ⑄"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⑅"))
				else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑆"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭⑇"),l11l11l_l1_,785,l11lll_l1_ (u"࠭ࠧ⑈"),l11lll_l1_ (u"ࠧࠨ⑉"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭⑊"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⑋")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁ࠵࠭⑌")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭⑍")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ⑎")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⑏")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑐"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ⑑")+name,l11l11l_l1_,784,l11lll_l1_ (u"ࠩࠪ⑒"),l11lll_l1_ (u"ࠪࠫ⑓"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭⑔"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ⑕")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨ⑖")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩ⑗")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ⑘")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭⑙")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠪࠤ࠿࠭⑚")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠫ࠵࠭⑛")]
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ⑜")+name
			if type==l11lll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ⑝"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑞"),l111ll_l1_+title,url,784,l11lll_l1_ (u"ࠨࠩ⑟"),l11lll_l1_ (u"ࠩࠪ①"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ②"))
			elif type==l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ③") and l1lllll1l1l_l1_[-2]+l11lll_l1_ (u"ࠬࡃࠧ④") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⑤"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⑥")+l1l1111l_l1_
				l11l1l1_l1_ = l1llll1l11l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⑦"),l111ll_l1_+title,l11l1l1_l1_,781,l11lll_l1_ (u"ࠩࠪ⑧"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ⑨"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⑩"),l111ll_l1_+title,url,785,l11lll_l1_ (u"ࠬ࠭⑪"),l11lll_l1_ (u"࠭ࠧ⑫"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⑬")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⑭")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭⑮")					all l1l1ll1l_l1_ & l1lllll1l1_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠪࡁࠫ࠭⑯"),l11lll_l1_ (u"ࠫࡂ࠶ࠦࠨ⑰"))
	filters = filters.strip(l11lll_l1_ (u"ࠬࠬࠧ⑱"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"࠭࠽ࠨ⑲") in filters:
		items = filters.split(l11lll_l1_ (u"ࠧࠧࠩ⑳"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠨ࠿ࠪ⑴"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠩࠪ⑵")
	for key in l1lllll1l11_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠪ࠴ࠬ⑶")
		if l11lll_l1_ (u"ࠫࠪ࠭⑷") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⑸") and value!=l11lll_l1_ (u"࠭࠰ࠨ⑹"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ⑺")+value
		elif mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⑻") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ⑼"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⑽")+key+l11lll_l1_ (u"ࠫࡂ࠭⑾")+value
		elif mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ⑿"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⒀")+key+l11lll_l1_ (u"ࠧ࠾ࠩ⒁")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ⒂"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫ⒃"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠪࡁ࠵࠭⒄"),l11lll_l1_ (u"ࠫࡂ࠭⒅"))
	return l1ll1l1l_l1_
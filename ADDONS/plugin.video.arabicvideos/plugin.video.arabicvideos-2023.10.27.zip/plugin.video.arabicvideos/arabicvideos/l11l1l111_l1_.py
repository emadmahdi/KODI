# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧྛ")
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྜ"):l11lll_l1_ (u"ࠧࠨྜྷ")}
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬྞ"):l1l11111l_l1_()}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨྟ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬྠ"),l11lll_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษ๎ࠫྡ"),l11lll_l1_ (u"๋ࠬีศำ฼๋ࠬྡྷ"),l11lll_l1_ (u"࠭วฺๆ้ࠤ๊฿ๆศࠢ⠖ࠤࡋࡵࡲࠡࡣࡧࡷࠬྣ"),l11lll_l1_ (u"ࠧๆ๊หห๏๊วหࠩྤ"),l11lll_l1_ (u"ࠨสิห๊าࠠไ็ห๎ํะัࠨྥ"),l11lll_l1_ (u"ࠩส่฾อศࠡๅ่ฬ๏๎สาࠩྦ"),l11lll_l1_ (u"ࠪหุ๊วๆ์สฮࠬྦྷ"),l11lll_l1_ (u"ࠫฬิั๊ࠩྨ"),l11lll_l1_ (u"ࠬอโิษ่ࠤฬิั๋ࠩྩ"),l11lll_l1_ (u"࠭วีฬิห่อสࠨྪ")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l1111l_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l1llllll_l1_(url)
	elif mode==254: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧྫ")+text)
	elif mode==255: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬྫྷ")+text)
	elif mode==256: results = l1l11l_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ྭ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩྮ"),l11lll_l1_ (u"ࠫࠬྯ"),headers,l11lll_l1_ (u"ࠬ࠭ྰ"),l11lll_l1_ (u"࠭ࠧྱ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫྲ"))
	html = response.content
	#l11l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧླ"),html,re.DOTALL)
	#if l11l1l1l_l1_: l11l1l1l_l1_ = SERVER(l11l1l1l_l1_[0],l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ྴ"))
	#else: l11l1l1l_l1_ = l11ll1_l1_
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྵ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫྶ"),l11lll_l1_ (u"ࠬ࠭ྷ"),259,l11lll_l1_ (u"࠭ࠧྸ"),l11lll_l1_ (u"ࠧࠨྐྵ"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬྺ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྻ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ྼ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬ྽"),254)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ྾"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ྿"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ࿀"),255)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭࿁"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࿂"),l11lll_l1_ (u"ࠪࠫ࿃"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿄"),l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭࿅"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲ࿆ࠬ"),251,l11lll_l1_ (u"ࠧࠨ࿇"),l11lll_l1_ (u"ࠨࠩ࿈"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩ࿉"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿊"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿋")+l111ll_l1_+l11lll_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ࿌"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿍"),251,l11lll_l1_ (u"ࠧࠨ࿎"),l11lll_l1_ (u"ࠨࠩ࿏"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭࿐"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿑"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿒")+l111ll_l1_+l11lll_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ࿓"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿔"),251,l11lll_l1_ (u"ࠧࠨ࿕"),l11lll_l1_ (u"ࠨࠩ࿖"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࿗"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿘"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿙")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬ࿚"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧ࿛"),251,l11lll_l1_ (u"ࠧࠨ࿜"),l11lll_l1_ (u"ࠨࠩ࿝"),l11lll_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪ࿞"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ࿟"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࿠"),l11lll_l1_ (u"ࠬ࠭࿡"),9999)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡦࡰࡸࡌࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࿢"),html,re.DOTALL)
	l11l1_l1_ = l1l11ll_l1_[0]
	l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࿣"),l11l1_l1_,re.DOTALL)
	for link,title in l1l1lll_l1_:
		title = unescapeHTML(title)
		if title not in l1l1l1_l1_ and title!=l11lll_l1_ (u"ࠨࠩ࿤"):
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ࿥") not in link: link = l11ll1_l1_+link
			#link = link.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬ࿦")).replace(SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ࿧")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿨"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࿩")+l111ll_l1_+title,link,256)
	return html
def l1l11l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ࿪"),l11lll_l1_ (u"ࠨࠩ࿫"),l11lll_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠣࠤࠥࠦࠠࠨ࿬")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ࿭"),url,l11lll_l1_ (u"ࠫࠬ࿮"),headers,l11lll_l1_ (u"ࠬ࠭࿯"),l11lll_l1_ (u"࠭ࠧ࿰"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ࿱"))
	html = response.content
	if l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠪ࿲") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿳"),l111ll_l1_+l11lll_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪ࿴"),url,251,l11lll_l1_ (u"ࠫࠬ࿵"),l11lll_l1_ (u"ࠬ࠭࿶"),l11lll_l1_ (u"࠭࡭ࡰࡵࡷࠫ࿷"))
	if l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠫ࿸") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿹"),l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ࿺"),url,251,l11lll_l1_ (u"ࠪࠫ࿻"),l11lll_l1_ (u"ࠫࠬ࿼"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ࿽"))
	if l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩ࿾") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭࿿"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			if len(l1l1ll1_l1_)>1 and type==l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧက"): block = l1l1ll1_l1_[1]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪခ"),block,re.DOTALL)
			for link,title in items:
				l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫဂ"),title,re.DOTALL)
				try: l11l1llll_l1_ = l1lll1lll_l1_[0][0]
				except: l11l1llll_l1_ = l11lll_l1_ (u"ࠫࠬဃ")
				try: l11ll1111_l1_ = l1lll1lll_l1_[0][1]
				except: l11ll1111_l1_ = l11lll_l1_ (u"ࠬ࠭င")
				l1lll1lll_l1_ = l11l1llll_l1_+l11ll1111_l1_
				l1lll1lll_l1_ = l1lll1lll_l1_.replace(l11lll_l1_ (u"࠭࡜࡯ࠩစ"),l11lll_l1_ (u"ࠧࠨဆ"))
				#LOG_THIS(l11lll_l1_ (u"ࠨࠩဇ"),str(l1lll1lll_l1_))
				if l11lll_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠫဈ") in title:
					l11l1l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧဉ"),title,re.DOTALL)
					if l11l1l1ll_l1_: l1lll1lll_l1_ = l11l1l1ll_l1_[0]
				if not l1lll1lll_l1_:
					l11l1l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩည"),title,re.DOTALL)
					if l11l1l1ll_l1_: l1lll1lll_l1_ = l11l1l1ll_l1_[0]
				if l1lll1lll_l1_:
					if l11lll_l1_ (u"ࠬࡱࡥࡺ࠿ࠪဋ") in link: type = link.split(l11lll_l1_ (u"࠭࡫ࡦࡻࡀࠫဌ"))[1]
					else: type = l11lll_l1_ (u"ࠧ࡯ࡧࡺࡩࡸࡺࠧဍ")
					#link = link.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪဎ")).replace(SERVER(link,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ဏ")),l11ll1_l1_)
					l1lll1lll_l1_ = l1lll1lll_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬတ"))
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫထ"),l111ll_l1_+l1lll1lll_l1_,link,251,l11lll_l1_ (u"ࠬ࠭ဒ"),l11lll_l1_ (u"࠭ࠧဓ"),type)
	return
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨန"),l11lll_l1_ (u"ࠨࠩပ"),l11lll_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠢࠣࠤࠥࠦࠧဖ")+type,url)
	method,data,items = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧဗ"),l11lll_l1_ (u"ࠫࠬဘ"),[]
	if type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭မ"):
		if l11lll_l1_ (u"࠭࠿ࠨယ") in url:
			l11ll11ll_l1_,l11ll1l11_l1_ = l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬရ"),{}
			l11l11l_l1_,l11ll1l1l_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࠪလ"))
			lines = l11ll1l1l_l1_.split(l11lll_l1_ (u"ࠩࠩࠫဝ"))
			for line in lines:
				key,value = line.split(l11lll_l1_ (u"ࠪࡁࠬသ"))
				l11ll1l11_l1_[key] = value
			if lines: method,url,data = l11ll11ll_l1_,l11l11l_l1_,l11ll1l11_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠫࠬဟ"),l11lll_l1_ (u"ࠬ࠭ဠ"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬအ"))
	html = response.content
	#html = html[99000:]
	if type==l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨဢ"): l1l1ll1_l1_ = [html]
	elif l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪဣ") in type: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭ဤ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧဥ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫัี๊ะࠢส่ฬ็ไศ็࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫဦ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫဧ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ဨ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧ࡮ࡱࡶࡸࠬဩ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪဪ"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡅࡰࡴࡩ࡫ࡴ࠯ࡘࡐࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡅࡧࡵࡅ࡭ࡕࡨࡩࡩࠨࠧါ"),html,re.DOTALL)
	if l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬာ") in type:
		block = l1l1ll1_l1_[0]
		zz = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡰࡦࢀࡹ࠯ࠬࡂࠤ࠭ࡹࡲࡤࡾࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨိ"),block,re.DOTALL)
		if zz:
			l1111_l1_,l1lll1ll_l1_,l11lll1ll_l1_,l1l111l11_l1_ = zip(*zz)
			items = zip(l1111_l1_,l1l111l11_l1_,l1lll1ll_l1_)
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࡇࡲࡦࡣ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳࡜ࡸࡽ࠶࠰࠺ࢃ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩီ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"࠭ࡗࡘࡇࠪု") in title: continue
		#link = link.rstrip(l11lll_l1_ (u"ࠧ࠰ࠩူ")).replace(SERVER(link,l11lll_l1_ (u"ࠨࡷࡵࡰࠬေ")),l11ll1_l1_)
		#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫဲ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧဳ")),l11ll1_l1_)
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠫฬ๊อๅไฬࠫဴ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨဵ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬံ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ့ࠧ"),l111ll_l1_+title,link,253,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧး"),l111ll_l1_+title,link,252,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲္ࠫ") in link or l11lll_l1_ (u"ุ้๊ࠪำๅ်ࠩ") in title:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫျ"),l111ll_l1_+title,link,253,l1llll_l1_)
		else:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫြ"),l111ll_l1_+title,link,252,l1llll_l1_)
	if type in [l11lll_l1_ (u"࠭࡮ࡦࡹࡨࡷࡹ࠭ွ"),l11lll_l1_ (u"ࠧࡣࡧࡶࡸࠬှ"),l11lll_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭ဿ")]:
		items = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠭࡯ࡷࡰࡦࡪࡸࡳࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၀"),html,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ၁"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ၂")+title,link,251,l11lll_l1_ (u"ࠬ࠭၃"),l11lll_l1_ (u"࠭ࠧ၄"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ၅"),url,l11lll_l1_ (u"ࠨࠩ၆"),headers,l11lll_l1_ (u"ࠩࠪ၇"),l11lll_l1_ (u"ࠪࠫ၈"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ၉"))
	html = response.content
	#items = re.findall(l11lll_l1_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡘ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ၊"),html,re.DOTALL)
	# the first 10000 character of the html file is l11ll111l_l1_ l11llll11_l1_ in l11lllll1_l1_ .. it l11lll11l_l1_ l11l1lll1_l1_
	html = html[10000:]
	items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ။"),html,re.DOTALL)
	if not items: return
	l1llll_l1_,name = items[0]
	if l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ၌") in name: name = name.split(l11lll_l1_ (u"ࠨษ็ั้่ษࠨ၍"))[0].strip(l11lll_l1_ (u"ࠩࠣࠫ၎"))
	elif l11lll_l1_ (u"ࠪั้่ษࠨ၏") in name: name = name.split(l11lll_l1_ (u"ࠫา๊โสࠩၐ"))[0].strip(l11lll_l1_ (u"ࠬࠦࠧၑ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࡇࡳ࡭ࡸࡵࡤࡦࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬၒ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩၓ"),block,re.DOTALL)
		for link,l1lll11_l1_ in items:
			title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤึ่ๅࠡࠩၔ")+l1lll11_l1_
			#link = link.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫၕ")).replace(SERVER(link,l11lll_l1_ (u"ࠪࡹࡷࡲࠧၖ")),l11ll1_l1_)
			#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠫ࠴࠭ၗ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩၘ")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬၙ"),l111ll_l1_+title,link,252,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ၚ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭ၛ"),url,252,l1llll_l1_)
	return
def l11l11ll1_l1_(title,link):
	l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡞ࡥ࠲ࢀࡁ࠮࡜࠰ࡡ࠰࠭ၜ"),title,re.DOTALL)
	if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
	else: title = title+l11lll_l1_ (u"ࠪࠤࠬၝ")+SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩၞ"))
	title = title.replace(l11lll_l1_ (u"ࠬ฿ัษࠢึ๎ิ࠭ၟ"),l11lll_l1_ (u"࠭ࠧၠ")).replace(l11lll_l1_ (u"ࠧๆสสุึ࠭ၡ"),l11lll_l1_ (u"ࠨࠩၢ")).replace(l11lll_l1_ (u"ุ่ࠩฬํฯสࠩၣ"),l11lll_l1_ (u"ࠪࠫၤ"))
	title = title.replace(l11lll_l1_ (u"ࠫ๒࠭ၥ"),l11lll_l1_ (u"ࠬ࠭ၦ"))
	title = title.replace(l11lll_l1_ (u"࠭ࠠࠡࠩၧ"),l11lll_l1_ (u"ࠧࠡࠩၨ")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫၩ"),l11lll_l1_ (u"ࠩࠣࠫၪ"))
	return title
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧၫ"),url,l11lll_l1_ (u"ࠫࠬၬ"),headers,l11lll_l1_ (u"ࠬ࠭ၭ"),l11lll_l1_ (u"࠭ࠧၮ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫၯ"))
	html = response.content
	l11l11l_l1_ = response.url
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬၰ"))
	headers[l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪၱ")] = server+l11lll_l1_ (u"ࠪ࠳ࠬၲ")
	l11l11l1l_l1_,l11lll111_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࠬၳ"),l11lll_l1_ (u"ࠬ࠭ၴ"),[]
	# l11l1ll1l_l1_ & download l11l1l11_l1_
	l1l1111ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡇࡻࡴࡵࡱࡱࡷࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡹࡤࡸࡨ࡮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࠨࡥࡱࡺࡲࡱࡵࡡࡥ࠰࠭ࡃ࠮ࠨࠧၵ"),html,re.DOTALL)
	if l1l1111ll_l1_: l11l11l1l_l1_,l11lll1l1_l1_,l11lll111_l1_,l11ll1ll1_l1_ = l1l1111ll_l1_[0]
	else:
		l1l1111ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨၶ"),html,re.DOTALL)
		if l1l1111ll_l1_:
			link,l11lll1l1_l1_ = l1l1111ll_l1_[0]
			if l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧၷ") in l11lll1l1_l1_: l11l11l1l_l1_ = link
			else: l11lll111_l1_ = link
	if l11l11l1l_l1_:
		# l11l1ll1l_l1_ links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ၸ"),l11l11l1l_l1_,l11lll_l1_ (u"ࠪࠫၹ"),headers,l11lll_l1_ (u"ࠫࠬၺ"),l11lll_l1_ (u"ࠬ࠭ၻ"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪၼ"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡫ࡲࡂࡴࡨࡥࠧ࠮࠮ࠫࡁ࠿࠳ࡺࡲ࠾ࠪࠩၽ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l111l1_l1_ = l1l1ll1_l1_[0]
			l11l111l1_l1_ = l11l111l1_l1_.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧၾ"),l11lll_l1_ (u"ࠩ࠿࡬࠸ࡄࠧၿ"))
			l11l111l1_l1_ = l11l111l1_l1_.replace(l11lll_l1_ (u"ࠪࡀ࡭࠹࠾ࠨႀ"),l11lll_l1_ (u"ࠫࡁ࡮࠳࠿࠾࡫࠷ࡃ࠭ႁ"))
			l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠴ࡀ࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠬ࠳࠰࠿ࠪ࠾࡫࠷ࡃ࠭ႂ"),l11l111l1_l1_,re.DOTALL)
			if not l111l11_l1_: l111l11_l1_ = [(l11lll_l1_ (u"࠭ࠧႃ"),l11l111l1_l1_)]
			for l11l111l_l1_,block in l111l11_l1_:
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬႄ")+l11l111l_l1_
				items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬႅ"),block,re.DOTALL)
				for link,name in items:
					if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧႆ") not in link: link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩႇ")+link
					#name = SERVER(link,l11lll_l1_ (u"ࠫ࡭ࡵࡳࡵࠩႈ"))
					link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ႉ")+name+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧႊ")+l11l111l_l1_
					l1111_l1_.append(link)
		# l1l111lll_l1_ link
		links = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡌࡪࡷࡧ࡭ࡦࠤ࠱࠮ࡄࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨႋ"),html,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡊࡈࡍࡌࡎࡔ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႌ"),html,re.DOTALL)
		if links:
			link,l11l111l_l1_ = links[0]
			name = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ႍࠧ"))
			if l11lll_l1_ (u"ࠪࠩࠬႎ") in l11l111l_l1_: link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬႏ")+name+l11lll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࠨ႐")
			else: link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ႑")+name+l11lll_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࡢࡣࠬ႒")+l11l111l_l1_
			l1111_l1_.append(link)
	if l11lll111_l1_:
		# download links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ႓"),l11lll111_l1_,l11lll_l1_ (u"ࠩࠪ႔"),headers,l11lll_l1_ (u"ࠪࠫ႕"),l11lll_l1_ (u"ࠫࠬ႖"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ႗"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡄࡰࡹࡱࡰࡴࡧࡤࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ႘"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ႙"),block,re.DOTALL)
			for link,title,l11l111l_l1_ in items:
				if not link: continue
				# l11ll11l1_l1_ l11l111ll_l1_ by l11l11lll_l1_ .. it l11llll1l_l1_ a l11l1l1l1_l1_ from l11l11lll_l1_ l1l111l1l_l1_
				if l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡴࡶࡤࡸ࡮ࡵ࡮ࠨႚ") in link: continue
				link = l111l_l1_(link)
				#title = l11l11ll1_l1_(title,link)
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪႛ")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫႜ")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩႝ"), l1111_l1_)
	l11l1l11l_l1_ = str(l1111_l1_)
	l11l111_l1_ = [l11lll_l1_ (u"ࠬ࠴ࡺࡪࡲࡂࠫ႞"),l11lll_l1_ (u"࠭࠮ࡳࡣࡵࡃࠬ႟"),l11lll_l1_ (u"ࠧ࠯ࡶࡻࡸࡄ࠭Ⴀ"),l11lll_l1_ (u"ࠨ࠰ࡳࡨ࡫ࡅࠧႡ"),l11lll_l1_ (u"ࠩ࠱ࡸࡦࡸ࠿ࠨႢ"),l11lll_l1_ (u"ࠪ࠲࡮ࡹ࡯ࡀࠩႣ"),l11lll_l1_ (u"ࠫ࠳ࢀࡩࡱ࠰ࠪႤ"),l11lll_l1_ (u"ࠬ࠴ࡲࡢࡴ࠱ࠫႥ"),l11lll_l1_ (u"࠭࠮ࡵࡺࡷ࠲ࠬႦ"),l11lll_l1_ (u"ࠧ࠯ࡲࡧࡪ࠳࠭Ⴇ"),l11lll_l1_ (u"ࠨ࠰ࡷࡥࡷ࠴ࠧႨ"),l11lll_l1_ (u"ࠩ࠱࡭ࡸࡵ࠮ࠨႩ")]
	if any(value in l11l1l11l_l1_ for value in l11l111_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫႪ"),l11lll_l1_ (u"ࠫࠬႫ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႬ"),l11lll_l1_ (u"࠭ฬาสࠣีฬฮืࠡ็ัฮ้็ࠠๅล้ࠤ์ึวࠡษ็ีฬฮืࠡๆํื๋ࠥๆ่๋ࠡ฽ࠥอไา๊สฬ฼ࠦวๅฬํࠤๆ๐็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰่ࠣศ์่ࠠาสࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡะา้ฬะࠠฤะิํࠥเ๊า่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩႭ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ⴎ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪႯ"),l11lll_l1_ (u"ࠩ࠮ࠫႰ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡯࡮ࡥ࠱ࡂࡪ࡮ࡴࡤ࠾ࠩႱ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫႲ"))
	return
def l1lll1l1_l1_(url,filter):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭Ⴓ"),l11lll_l1_ (u"࠭ࠧႴ"),filter,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨႵ"):url,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬႶ"):l11lll_l1_ (u"ࠩࠪႷ")}
	#l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࠫႸ")
	#filter = filter.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ⴙ"),l11lll_l1_ (u"ࠬ࠭Ⴚ"))
	if l11lll_l1_ (u"࠭࠿ࡀࠩႻ") in url: url = url.split(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭Ⴜ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬႽ"),1)
	if filter==l11lll_l1_ (u"ࠩࠪႾ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠪࠫႿ"),l11lll_l1_ (u"ࠫࠬჀ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩჁ"))
	if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪჂ"):
		if l1l111ll1_l1_[0]+l11lll_l1_ (u"ࠧ࠾࠿ࠪჃ") not in l1l11l1l_l1_: category = l1l111ll1_l1_[0]
		for i in range(len(l1l111ll1_l1_[0:-1])):
			if l1l111ll1_l1_[i]+l11lll_l1_ (u"ࠨ࠿ࡀࠫჄ") in l1l11l1l_l1_: category = l1l111ll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬჅ")+category+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧ჆")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧჇ")+category+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ჈")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"࠭ࠦࠧࠩ჉"))+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ჊")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠨࠨࠩࠫ჋"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ჌"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩჍ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ჎"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ჏"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"࠭ࠧა"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪბ"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠨࠩგ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨდ")+l1l11l11_l1_
		l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪე"),l111ll_l1_+l11lll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧვ"),l1111111_l1_,251,l11lll_l1_ (u"ࠬ࠭ზ"),l11lll_l1_ (u"࠭ࠧთ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨი"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨკ"),l111ll_l1_+l11lll_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩლ")+l11lll11_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩმ"),l1111111_l1_,251,l11lll_l1_ (u"ࠫࠬნ"),l11lll_l1_ (u"ࠬ࠭ო"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧპ"))
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬჟ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨრ"),l11lll_l1_ (u"ࠩࠪს"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨტ"),url,l11lll_l1_ (u"ࠫࠬუ"),headers,l11lll_l1_ (u"ࠬ࠭ფ"),l11lll_l1_ (u"࠭ࠧქ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬღ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡤࡼࡕࡧࡧࡦࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡔࡦࡴࡰࡆ࡙ࡔࡳࠣࠩყ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l111111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫშ"),block,re.DOTALL)
	l11llllll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡖࡦࡺࡩ࡯ࡩࡉ࡭ࡱࡺࡥࡳࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠴ࠪࡀࠪ࠿ࡹࡱࡄࠩࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫჩ"),block,re.DOTALL)
	l1lll11l_l1_ = l1l111111_l1_+l11llllll_l1_
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#if l11lll_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭ც") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ძ"),block,re.DOTALL)
		if name==l11lll_l1_ (u"࠭วฯำ์ࠫწ"): name = l11lll_l1_ (u"ࠧศๆสๆุอๅࠨჭ")
		if not items:
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡲࡢࡶࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨხ"),block,re.DOTALL)
			items = []
			for option,value in l1l1lll_l1_: items.append([option,l11lll_l1_ (u"ࠩࠪჯ"),value])
			l1ll1lll_l1_ = l11lll_l1_ (u"ࠪࡶࡦࡺࡥࠨჰ")
			name = l11lll_l1_ (u"ࠫฬ๊สใ์ํ้ࠬჱ")
		else: l1ll1lll_l1_ = items[0][1]
		if l11lll_l1_ (u"ࠬࡃ࠽ࠨჲ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪჳ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧჴ")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨჵ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪჶ"),l1111111_l1_,251,l11lll_l1_ (u"ࠪࠫჷ"),l11lll_l1_ (u"ࠫࠬჸ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ჹ"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ჺ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ჻"),l11l11l_l1_,254,l11lll_l1_ (u"ࠨࠩჼ"),l11lll_l1_ (u"ࠩࠪჽ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫჾ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧჿ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩᄀ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩᄁ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫᄂ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬᄃ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᄄ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᄅ")+name,l11l11l_l1_,255,l11lll_l1_ (u"ࠫࠬᄆ"),l11lll_l1_ (u"ࠬ࠭ᄇ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᄈ"))
		dict[l1ll1lll_l1_] = {}
		for option,dummy,value in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠧศๆๆ่ࠬᄉ") in option: continue
			option = unescapeHTML(option)
			#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᄊ") in option: continue
			#if l11lll_l1_ (u"ࠩࡱ࠱ࡦ࠭ᄋ") in value: continue
			l11l1ll11_l1_,l1lll1lll_l1_ = option,option
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠪ࠾ࠥ࠭ᄌ")+l11l1ll11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧᄍ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽ࠨᄎ")+l11l1ll11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩᄏ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿ࠪᄐ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬᄑ")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪᄒ"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄓ"),l111ll_l1_+l1lll1lll_l1_,url,255,l11lll_l1_ (u"ࠫࠬᄔ"),l11lll_l1_ (u"ࠬ࠭ᄕ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᄖ"))
			elif type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫᄗ") and l1l111ll1_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࡀࠫᄘ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᄙ"))
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᄚ"),l11lll_l1_ (u"ࠫࠬᄛ"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫᄜ")+l1l1111l_l1_
				l1111111_l1_ = l11ll1lll_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᄝ"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,251,l11lll_l1_ (u"ࠧࠨᄞ"),l11lll_l1_ (u"ࠨࠩᄟ"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪᄠ"))
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄡ"),l111ll_l1_+l1lll1lll_l1_,url,254,l11lll_l1_ (u"ࠫࠬᄢ"),l11lll_l1_ (u"ࠬ࠭ᄣ"),l1ll1ll1_l1_)
	return
l1l111ll1_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᄤ"),l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᄥ"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᄦ")]
l1l1111l1_l1_ = [l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᄧ"),l11lll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᄨ"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪᄩ"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᄪ"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨᄫ"),l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᄬ"),l11lll_l1_ (u"ࠨࡴࡤࡸࡪ࠭ᄭ")]
def l11ll1lll_l1_(url):
	l11l11l11_l1_ = l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠴࠳࠶࠶࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡈࡰ࡯ࡨ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡈࡰ࡯ࡨ࠲ࡵ࡮ࡰࠨᄮ")
	url = url.replace(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧᄯ"),l11l11l11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬᄰ"),l11lll_l1_ (u"ࠬ࠭ᄱ"))
	if l11l11l11_l1_ not in url: url = url+l11l11l11_l1_
	url = url.replace(l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄲ"),l11lll_l1_ (u"ࠧࡺࡧࡤࡶࠬᄳ"))
	url = url.replace(l11lll_l1_ (u"ࠨࡁࡂࠫᄴ"),l11lll_l1_ (u"ࠩࡂࠫᄵ"))
	url = url.replace(l11lll_l1_ (u"ࠪࠪࠫ࠭ᄶ"),l11lll_l1_ (u"ࠫࠫ࠭ᄷ"))
	url = url.replace(l11lll_l1_ (u"ࠬࡃ࠽ࠨᄸ"),l11lll_l1_ (u"࠭࠽ࠨᄹ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᄺ"),l11lll_l1_ (u"ࠨࠩᄻ"),l11lll_l1_ (u"ࠩࠪᄼ"),l11lll_l1_ (u"ࠪࡔࡗࡋࡐࡂࡔࡈࡣࡋࡏࡌࡕࡇࡕࡣࡋࡏࡎࡂࡎࡢ࡙ࡗࡒࠧᄽ"))
	return url
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᄾ"),l11lll_l1_ (u"ࠬ࠭ᄿ"),filters,l11lll_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭ᅀ")+mode)
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᅁ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᅂ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭ᅃ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠫ࠭ᅄ"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠫࠬᅅ")
	if l11lll_l1_ (u"ࠬࡃ࠽ࠨᅆ") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠧࠩᅇ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾࠿ࠪᅈ"))
			l1l11ll1_l1_[var] = value
	for key in l1l1111l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪᅉ")
		if l11lll_l1_ (u"ࠩࠨࠫᅊ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᅋ") and value!=l11lll_l1_ (u"ࠫ࠵࠭ᅌ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩᅍ")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᅎ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᅏ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫᅐ")+key+l11lll_l1_ (u"ࠩࡀࡁࠬᅑ")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᅒ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧᅓ")+key+l11lll_l1_ (u"ࠬࡃ࠽ࠨᅔ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪᅕ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪᅖ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᅗ"),l11lll_l1_ (u"ࠩࠪᅘ"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠪࡓ࡚࡚ࠧᅙ"))
	return l1ll1l1l_l1_
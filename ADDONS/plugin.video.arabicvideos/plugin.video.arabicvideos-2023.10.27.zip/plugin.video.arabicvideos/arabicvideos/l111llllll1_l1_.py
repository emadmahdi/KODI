# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ溓")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠ࡛ࡔࡘࡤ࠭溔")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ溕"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ準"),l11lll_l1_ (u"ࠪฮุา๊ๅࠩ溗"),l11lll_l1_ (u"ࠫฯูฬ๋ๆࠣห้ีฮ้ๆࠪ溘"),l11lll_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩ溙")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l1111l_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l11111_l1_(url,text)
	elif mode==664: results = l1l11l_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ溚"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ溛"),l11lll_l1_ (u"ࠨࠩ溜"),l11lll_l1_ (u"ࠩࠪ溝"),l11lll_l1_ (u"ࠪࠫ溞"),l11lll_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ溟"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ溠"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭溡"),l11lll_l1_ (u"ࠧࠨ溢"),669,l11lll_l1_ (u"ࠨࠩ溣"),l11lll_l1_ (u"ࠩࠪ溤"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ溥"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ溦"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ溧"),l11lll_l1_ (u"࠭ࠧ溨"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ溩"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ溪")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ溫"),l11ll1_l1_,661,l11lll_l1_ (u"ࠪࠫ溬"),l11lll_l1_ (u"ࠫࠬ溭"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ溮"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭溯"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ溰")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ溱"),l11ll1_l1_,661,l11lll_l1_ (u"ࠩࠪ溲"),l11lll_l1_ (u"ࠪࠫ溳"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ溴"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ溵"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ溶")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭溷"),l11ll1_l1_,661,l11lll_l1_ (u"ࠨࠩ溸"),l11lll_l1_ (u"ࠩࠪ溹"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ溺"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ溻"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ溼")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪ溽"),l11ll1_l1_,661,l11lll_l1_ (u"ࠧࠨ溾"),l11lll_l1_ (u"ࠨࠩ溿"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ滀"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ滁"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ滂"),l11lll_l1_ (u"ࠬ࠭滃"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ滄"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ滅"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ滆"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ滇")+l111ll_l1_+title,link,664)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ滈"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ滉"),l11lll_l1_ (u"ࠬ࠭滊"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ滋"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ滌"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠨࠩ滍"))
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ滎"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠪࡀࡧࡄࠧ滏"),l11lll_l1_ (u"ࠫࠬ滐")).replace(l11lll_l1_ (u"ࠬࡂ࠯ࡣࡀࠪ滑"),l11lll_l1_ (u"࠭ࠧ滒")).replace(l11lll_l1_ (u"ࠧ࠽ࡤࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡸࡥࡵࠤࡁࠫ滓"),l11lll_l1_ (u"ࠨࠩ滔")).replace(l11lll_l1_ (u"ࠩ࠿ࡦࡃ࠭滕"),l11lll_l1_ (u"ࠪࠫ滖")).strip(l11lll_l1_ (u"ࠫࠥ࠭滗"))
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ滘"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ滙")+l111ll_l1_+title,link,664)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ滚"),url,l11lll_l1_ (u"ࠨࠩ滛"),l11lll_l1_ (u"ࠩࠪ滜"),l11lll_l1_ (u"ࠪࠫ滝"),l11lll_l1_ (u"ࠫࠬ滞"),l11lll_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ滟"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ滠"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ满"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ滢"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭滣"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫ滤"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ滥"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ滦"),l11lll_l1_ (u"࠭ࠧ滧"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ滨"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫ滩")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ滪"),l111ll_l1_+title,link,661)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ滫"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭滬"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ滭"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭滮"),l11lll_l1_ (u"ࠧࠨ滯"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ滰"),l111ll_l1_+title,link,661)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪ滱")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ滲"),l11lll_l1_ (u"ࠫࠬ滳"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ滴"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨ滵"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭滶")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ滷"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ滸")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ滹"),url,data,headers,l11lll_l1_ (u"ࠫࠬ滺"),l11lll_l1_ (u"ࠬ࠭滻"),l11lll_l1_ (u"࡙࠭ࡂࡓࡒࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ滼"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ滽"),url,l11lll_l1_ (u"ࠨࠩ滾"),l11lll_l1_ (u"ࠩࠪ滿"),l11lll_l1_ (u"ࠪࠫ漀"),l11lll_l1_ (u"ࠫࠬ漁"),l11lll_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ漂"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧ漃"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ漄"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭漅"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ漆"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ漇"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭漈"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭漉"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ漊"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ漋"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ漌"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ漍"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ漎"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭漏"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ漐"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ漑"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ漒"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ漓"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ演"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ漕"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ漖"),l11lll_l1_ (u"้ࠬไ๋สࠪ漗"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ漘"),l11lll_l1_ (u"่ࠧัสๅࠬ漙"),l11lll_l1_ (u"ࠨ็หหึอษࠨ漚"),l11lll_l1_ (u"ࠩ฼ี฻࠭漛"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ漜"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ漝"),l11lll_l1_ (u"๋ࠬำาฯํอࠬ漞")]
	for l1llll_l1_,link,title in items:
		title = title.replace(l11lll_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠡࠩ漟"),l11lll_l1_ (u"ࠧࠨ漠")).replace(l11lll_l1_ (u"ࠨษ๋๊้อ๊็ࠢࠪ漡"),l11lll_l1_ (u"ࠩࠪ漢")).replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫ漣"),l11lll_l1_ (u"ࠫࠬ漤"))
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠬ࠵ࠧ漥"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ漦") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ漧")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ漨"))
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ漩") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ漪")+l1llll_l1_.strip(l11lll_l1_ (u"ࠫ࠴࠭漫"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ漬"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ漭"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭漮"),l111ll_l1_+title,link,662,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ漯"):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ漰"),l111ll_l1_+title,link,662,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ漱") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ漲"),l111ll_l1_+title,link,663,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ漳") in link:
		#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭漴"),l111ll_l1_+title,link,661,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ漵"),l111ll_l1_+title,link,663,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ漶"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ漷")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ漸"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ漹"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠬࠩࠧ漺"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ漻")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ漼"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ漽"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ漾")+title,link,661)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ漿"),l11lll_l1_ (u"ࠫࠬ潀"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ潁"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ潂"),url,l11lll_l1_ (u"ࠧࠨ潃"),l11lll_l1_ (u"ࠨࠩ潄"),l11lll_l1_ (u"ࠩࠪ潅"),l11lll_l1_ (u"ࠪࠫ潆"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ潇"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ潈"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ潉"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠧࠨ潊")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭潋"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠩࠦࠫ潌"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ潍"),l111ll_l1_+title,url,663,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ潎"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡳ࡫ࡨࡁࠧ࠭潏")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ潐"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ潑"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ潒"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ潓")+link.strip(l11lll_l1_ (u"ࠪ࠲࠴࠭潔"))
			title = title.replace(l11lll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ潕"),l11lll_l1_ (u"ࠬࠦࠧ潖"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ潗"),l111ll_l1_+title,link,662,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ潘"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭潙") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ潚")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ潛"))
		#		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ潜"),l111ll_l1_+title,link,662,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l11l1ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ潝"),l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ潞"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ潟"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ潠"),l11lll_l1_ (u"ࠩࠪ潡"),l11lll_l1_ (u"ࠪࠫ潢"),l11lll_l1_ (u"ࠫࠬ潣"),l11lll_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭潤"))
	html = response.content
	# l1l111lll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡔࡱࡧࡹࡦࡴ࡫ࡳࡱࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ潥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		link = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭潦"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ潧"))
			l1111_l1_.append(link)
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ潨"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ潩"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ潪")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭潫"))
				l1111_l1_.append(link)
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠧࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ࠰ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰ࡳ࡬ࡵ࠭ࠩࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠷࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࡟ࡁࡒࡑࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠿ࠐࠉࠊࠋࠌࡲࡦࡳࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ࠯ࠊࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ潬")
	l111l1_l1_ = zip(l1111_l1_,l1l11l1ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ潭"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ潮"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ潯"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ潰"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭潱"),l11lll_l1_ (u"ࠬ࠱ࠧ潲"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ潳")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ潴"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ潵")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ潶"))
	return
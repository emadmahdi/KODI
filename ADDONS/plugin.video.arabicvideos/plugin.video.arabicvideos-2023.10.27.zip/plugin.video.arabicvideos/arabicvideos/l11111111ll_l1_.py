# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭懏")
headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ懐") : l11lll_l1_ (u"ࠩࠪ懑") }
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ懒")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1111l_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llllll_l1_(url)
	elif mode==214: results = l1lll1lllll1l_l1_(url)
	elif mode==215: results = l1lll1llllll1_l1_(url)
	elif mode==218: results = l11l1ll111ll_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11l1ll111ll_l1_():
	message = l11lll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ懓")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭懔"),l11lll_l1_ (u"࠭ࠧ懕"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ懖"),l11lll_l1_ (u"ࠨษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠧ懗"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ懘"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ懙"),l11lll_l1_ (u"ࠫࠬ懚"),219,l11lll_l1_ (u"ࠬ࠭懛"),l11lll_l1_ (u"࠭ࠧ懜"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ懝"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ懞"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠧ懟"),l11lll_l1_ (u"ࠪࠫ懠"),114,l11ll1_l1_)
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࡐࡪࡰࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࡴ࡮ࡴࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠶ࠩ懡")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懢"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ懣")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ懤"),url,211)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ懥"),headers,l11lll_l1_ (u"ࠩࠪ懦"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ懧"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡋ࡯࡬ࡵࡧࡵࡷࡇࡻࡴࡵࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ懨"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡫ࡪࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ懩"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࠪ懪")+link
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ懫"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ懬")+l111ll_l1_+title,url,211)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ懭"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭懮"),block,re.DOTALL)
	l1l1l1_l1_ = [l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥอๆๆ์ࠪ懯"),l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ懰")]
	#l111l11l1_l1_ = [l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠࠨ懱"),l11lll_l1_ (u"ࠧศใ็ห๊ࠦࠧ懲"),l11lll_l1_ (u"ࠨสิห๊าࠧ懳"),l11lll_l1_ (u"ࠩ฼ีํ฼ࠧ懴"),l11lll_l1_ (u"ࠪ็้๐ศศฬࠪ懵"),l11lll_l1_ (u"ࠫฬเว็๋ࠪ懶")]
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ懷"))
		if not any(value in title for value in l1l1l1_l1_):
		#	if any(value in title for value in l111l11l1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭懸"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ懹")+l111ll_l1_+title,link,211)
	return html
def l1111l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ懺"),headers,l11lll_l1_ (u"ࠩࠪ懻"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭懼"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ懽"),l11lll_l1_ (u"ࠬ࠭懾"),url,html)
	if l11lll_l1_ (u"࠭ࡧࡦࡶࡳࡳࡸࡺࡳࠨ懿") in url or l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ戀") in url: block = html
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡏࡨࡨ࡮ࡧࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ戁"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: return
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ戂"),block,re.DOTALL)
	l1l1_l1_ = []
	l111llll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ戃"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ戄"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ戅"),l11lll_l1_ (u"࠭ใๅ์หࠫ戆"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭戇"),l11lll_l1_ (u"ࠨ้าหๆ࠭戈"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ戉"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ戊"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ戋"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ戌")]
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ戍") in link: continue
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩ戎"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ戏"))
		if l11lll_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ成") in link or any(value in title for value in l111llll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ我"),l111ll_l1_+title,link,212,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ戒") in link and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ戓") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ戔"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭戕") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ或"),l111ll_l1_+title,link,213,l1llll_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ戗"),l111ll_l1_+title,link,213,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ战"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ戙"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠬอไึใะอࠥ࠭戚"),l11lll_l1_ (u"࠭ࠧ戛"))
			if title!=l11lll_l1_ (u"ࠧࠨ戜"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ戝"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ戞")+title,link,211)
	return
def l1llllll_l1_(url):
	l11l1111l_l1_,items,l111l11l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫ戟"),headers,l11lll_l1_ (u"ࠫࠬ戠"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ戡"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡴࡪ࠯࡯࡭ࡸࡺ࠭࡯ࡷࡰࡦࡪࡸࡥࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭戢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11_l1_ = l11lll_l1_ (u"ࠧࠨ戣").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ戤"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ戥"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ戦"))
		title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ戧") + link.split(l11lll_l1_ (u"ࠬ࠵ࠧ戨"))[-1].replace(l11lll_l1_ (u"࠭࠭ࠨ戩"),l11lll_l1_ (u"ࠧࠡࠩ截"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨษ็ั้่ษ࠮ࠪ࡟ࡨ࠰࠯ࠧ戫"),link.split(l11lll_l1_ (u"ࠩ࠲ࠫ戬"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠪ࠴ࠬ戭")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l111lllll_l1_ = str(items).count(l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭戮"))
	l11l1111l_l1_ = str(items).count(l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ戯"))
	if l111lllll_l1_>1 and l11l1111l_l1_>0 and l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ戰") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ戱") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ戲"),l111ll_l1_+title,link,213)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ戳") not in link: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ戴"),l111ll_l1_+title,link,212)
	return
def PLAY(url):
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭戵"))
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭戶"),headers,l11lll_l1_ (u"࠭ࠧ户"),l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ戸"))
	# l11l1ll1l_l1_ links
	if l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ戹") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ戺"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ戻"),headers,l11lll_l1_ (u"ࠫࠬ戼"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭戽"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ戾"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ房"),block,re.DOTALL)
			if items:
				id = re.findall(l11lll_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ所"),l11lll1l_l1_,re.DOTALL)
				if id:
					l11lll1ll1_l1_ = id[0]
					for link,title in items:
						link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡃࡵࡵࡳࡵ࡫ࡧࡁࠬ扁")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ扂")+link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ扃")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭扄")
						l1111_l1_.append(link)
			else:
				# https://l1lll1lllllll_l1_.tv/l11l1ll1l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࠧࢂࠦࡲࡷࡲࡸࡀ࠯ࠧ扅"),block,re.DOTALL)
				for link,dummy in items:
					l1111_l1_.append(link)
	# download links
	if l11lll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ扆") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ扇"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ扈"),headers,l11lll_l1_ (u"ࠪࠫ扉"),l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ扊"))
		id = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡨ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭手"),l11lll1l_l1_,re.DOTALL)
		if id:
			l11lll1ll1_l1_ = id[0]
			l1l1ll1ll_l1_ = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ扌"):l11lll_l1_ (u"ࠧࠨ才") , l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ扎"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ扏") }
			l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡰ࡮ࡷࠫࡶ࡯ࡴࡶࡌࡨࡂ࠭扐")+l11lll1ll1_l1_
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ扑"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭扒"),l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ打"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠶࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ扔"),l11lll1l_l1_,re.DOTALL)
			if l1l1ll1_l1_:
				for resolution,block in l1l1ll1_l1_:
					items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭払"),block,re.DOTALL)
					for name,link in items:
						l1111_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ扖")+name+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ扗")+l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ托")+resolution)
			else:
				l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠷ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ扙"),l11lll1l_l1_,re.DOTALL)
				if not l1l1ll1_l1_: l1l1ll1_l1_ = [l11lll1l_l1_]
				for block in l1l1ll1_l1_:
					l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡥࡳࡸࡨࡶࡸ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠎࠎࠏࠉࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࡜࠯࠴ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧศๆาๆฮࠦࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡲࡦࡳࡥࠢ࠿ࠪࠫ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨࠤ࠰ࠦࠧࠡโࠣࠫࠏࠏࠉࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡱࡥࡲ࡫ࠠ࠾ࠢࠪࠫࠏࠏࠉࠊࠋࠌࠦࠧࠨ扚")
					name = l11lll_l1_ (u"ࠧࠨ扛")
					items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ扜"),block,re.DOTALL)
					for link in items:
						server = l11lll_l1_ (u"ࠩࠩࠪࠬ扝") + link.split(l11lll_l1_ (u"ࠪ࠳ࠬ扞"))[2].lower() + l11lll_l1_ (u"ࠫࠫࠬࠧ扟")
						server = server.replace(l11lll_l1_ (u"ࠬ࠴ࡣࡰ࡯ࠩࠪࠬ扠"),l11lll_l1_ (u"࠭ࠧ扡")).replace(l11lll_l1_ (u"ࠧ࠯ࡥࡲࠪࠫ࠭扢"),l11lll_l1_ (u"ࠨࠩ扣"))
						server = server.replace(l11lll_l1_ (u"ࠩ࠱ࡲࡪࡺࠦࠧࠩ扤"),l11lll_l1_ (u"ࠪࠫ扥")).replace(l11lll_l1_ (u"ࠫ࠳ࡵࡲࡨࠨࠩࠫ扦"),l11lll_l1_ (u"ࠬ࠭执"))
						server = server.replace(l11lll_l1_ (u"࠭࠮࡭࡫ࡹࡩࠫࠬࠧ扨"),l11lll_l1_ (u"ࠧࠨ扩")).replace(l11lll_l1_ (u"ࠨ࠰ࡲࡲࡱ࡯࡮ࡦࠨࠩࠫ扪"),l11lll_l1_ (u"ࠩࠪ扫"))
						server = server.replace(l11lll_l1_ (u"ࠪࠪࠫ࡮ࡤ࠯ࠩ扬"),l11lll_l1_ (u"ࠫࠬ扭")).replace(l11lll_l1_ (u"ࠬࠬࠦࡸࡹࡺ࠲ࠬ扮"),l11lll_l1_ (u"࠭ࠧ扯"))
						server = server.replace(l11lll_l1_ (u"ࠧࠧࠨࠪ扰"),l11lll_l1_ (u"ࠨࠩ扱"))
						link = link + l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ扲") + name + server + l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ扳")
						l1111_l1_.append(link)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ扴"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭扵"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ扶"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ扷"),l11lll_l1_ (u"ࠨ࠭ࠪ扸"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭批")+search
	l1111l_l1_(url)
	return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠤࡸ࡫ࡣࡰࡰࡧࡥࡷࡿࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣࡩࡧࡦ࡯ࡲࡧࡲ࡬࠯ࡥࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡥࡤࡸࡪ࡭࡯ࡳࡻࠬࠎࠎࠏࠉࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ࠲ࠠࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗ࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵ࠥࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡷࡂ࠭ࠫࡴࡧࡤࡶࡨ࡮ࠫࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ࠱ࡣࡢࡶࡨ࡫ࡴࡸࡹࠋࠋࠌࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ扺")
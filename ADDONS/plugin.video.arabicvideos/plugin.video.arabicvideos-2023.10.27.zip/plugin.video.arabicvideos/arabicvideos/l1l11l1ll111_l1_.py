# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡎ࠵ࡘࠫ䑇")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䑈")
l11lll11111l_l1_ = [
		 l11lll_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ䑉")
		,l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䑊"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䑋")
		,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䑌"),l11lll_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䑍")
		#,l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䑎"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡅࡑࡉࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䑏"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䑐")
		,l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䑑"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䑒")
		,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭䑓"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ䑔"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡌࡒࡐࡏࡢࡒࡆࡓࡅࡠࡕࡒࡖ࡙ࡋࡄࠨ䑕")
		,l11lll_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䑖"),l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䑗")
		,l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䑘"),l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䑙")
		,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䑚"),l11lll_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ䑛"),l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ䑜")
		]
l11ll1llll11_l1_ = 4
def MAIN(mode,url,text,type,l1l11l1_l1_,l1ll11111l1_l1_):
	global l111ll_l1_
	try:
		l11lllllll1l_l1_ = str(l1ll11111l1_l1_[l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑝")])
		l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡑ࡚࠭䑞")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠪࡣࠬ䑟")
	except: l11lllllll1l_l1_ = l11lll_l1_ (u"ࠫࠬ䑠")
	try: l111ll1l_l1_ = str(l1ll11111l1_l1_[l11lll_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ䑡")])
	except: l111ll1l_l1_ = l11lll_l1_ (u"࠭ࠧ䑢")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l11lllllll1l_l1_,l111ll1l_l1_)
	elif mode==712: results = l11llll11l1l_l1_(l11lllllll1l_l1_)
	elif mode==713: results = GROUPS(l11lllllll1l_l1_,url,text,l1l11l1_l1_)
	elif mode==714: results = ITEMS(l11lllllll1l_l1_,url,text,l1l11l1_l1_)
	elif mode==715: results = PLAY(l11lllllll1l_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l11lllllll1l_l1_,True)
	elif mode==717: results = l11llllllll1_l1_(l11lllllll1l_l1_,True)
	elif mode==718: results = EPG_ITEMS(l11lllllll1l_l1_,url,text)
	elif mode==719: results = SEARCH(text,l11lllllll1l_l1_,url,l1l11l1_l1_)
	elif mode==720: results = MENU(l11lllllll1l_l1_,True)
	elif mode==721: results = l11lll1l1l1l_l1_(l11lllllll1l_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l11lllllll1l_l1_)
	elif mode==723: results = ADD_USERAGENT(l11lllllll1l_l1_)
	elif mode==726: results = ADD_REFERER(l11lllllll1l_l1_)
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l11lllllll1l_l1_,url,l1l11l1_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
		l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡏࡘࠫ䑣")+str(l11lllllll1l_l1_)+l11lll_l1_ (u"ࠨࡡࠪ䑤")
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑥"),l111ll_l1_+l11lll_l1_ (u"ࠪๆฬฬๅส่ࠢะ้ีࠠࠨ䑦")+text_numbers[l11lllllll1l_l1_],l11lll_l1_ (u"ࠫࠬ䑧"),720,l11lll_l1_ (u"ࠬ࠭䑨"),l11lll_l1_ (u"࠭ࠧ䑩"),l11lll_l1_ (u"ࠧࠨ䑪"),l11lll_l1_ (u"ࠨࠩ䑫"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑬"):l11lllllll1l_l1_})
	return
def MENU(l11lllllll1l_l1_,l1ll_l1_):
	if l11lllllll1l_l1_:
		l11ll1l11l1l_l1_ = {l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑭"):l11lllllll1l_l1_}
		l11lll1111l1_l1_ = l11lll_l1_ (u"ࠫࠬ䑮")  # l11lll_l1_ (u"ࠬࠦࡍ࠴ࡗࠪ䑯")+str(l11lllllll1l_l1_)
	else:
		l11ll1l11l1l_l1_ = l11lll_l1_ (u"࠭ࠧ䑰")
		l11lll1111l1_l1_ = l11lll_l1_ (u"ࠧࠨ䑱")
	l11ll11lll11_l1_ = CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_)
	if not l11ll11lll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䑲"),l111ll_l1_+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠥหึศใฬࠤํะฺ๋์ิࠤึอศุࠩ䑳")+l11lll1111l1_l1_+l11lll_l1_ (u"ࠪࠤࠬ䑴")+text_numbers[1]+l11lll_l1_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䑵"),l11lll_l1_ (u"ࠬ࠭䑶"),711,l11lll_l1_ (u"࠭ࠧ䑷"),l11lll_l1_ (u"ࠧࠨ䑸"),l11lll_l1_ (u"ࠨࠩ䑹"),l11lll_l1_ (u"ࠩࠪ䑺"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑻"):l11lllllll1l_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭䑼"):1})
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䑽"),l111ll_l1_+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢฯ่อࠦๅๅใสฮࠬ䑾")+l11lll1111l1_l1_+l11lll_l1_ (u"ࠧࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䑿"),l11lll_l1_ (u"ࠨࠩ䒀"),712,l11lll_l1_ (u"ࠩࠪ䒁"),l11lll_l1_ (u"ࠪࠫ䒂"),l11lll_l1_ (u"ࠫࠬ䒃"),l11lll_l1_ (u"ࠬ࠭䒄"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䒅"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䒆"),l11lll_l1_ (u"ࠨࠩ䒇"),9999)
	else:
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䒈"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋ไโษอࠫ䒉")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠫࠬ䒊"),729,l11lll_l1_ (u"ࠬ࠭䒋"),l11lll_l1_ (u"࠭ࠧ䒌"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䒍"),l11lll_l1_ (u"ࠨࠩ䒎"),l11ll1l11l1l_l1_)
		#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䒏"),l111ll_l1_+l11lll_l1_ (u"ࠪๆฬฬๅสࠢฦๆุอๅࠨ䒐")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠫࠬ䒑"),165,l11lll_l1_ (u"ࠬ࠭䒒"),l11lll_l1_ (u"࠭ࠧ䒓"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䒔"),l11lll_l1_ (u"ࠨࠩ䒕"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䒖"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䒗"),l11lll_l1_ (u"ࠫࠬ䒘"),9999)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒙"),l111ll_l1_+l11lll_l1_ (u"࠭โ็๊สฮ๋ࠥี็ใฬࠤ๊ืสษหࠪ䒚")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䒛"),713,l11lll_l1_ (u"ࠨࠩ䒜"),l11lll_l1_ (u"ࠩࠪ䒝"),l11lll_l1_ (u"ࠪࠫ䒞"),l11lll_l1_ (u"ࠫࠬ䒟"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒠"),l111ll_l1_+l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡ็ุ๊ๆฯࠠๆำอฬฮ࠭䒡")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䒢"),713,l11lll_l1_ (u"ࠨࠩ䒣"),l11lll_l1_ (u"ࠩࠪ䒤"),l11lll_l1_ (u"ࠪࠫ䒥"),l11lll_l1_ (u"ࠫࠬ䒦"),l11ll1l11l1l_l1_)
		#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒧"),l111ll_l1_+l11lll_l1_ (u"࠭รโๆส้๋ࠥี็ใฬࠤ๊ืสษหࠪ䒨")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䒩"),713,l11lll_l1_ (u"ࠨࠩ䒪"),l11lll_l1_ (u"ࠩࠪ䒫"),l11lll_l1_ (u"ࠪࠫ䒬"),l11lll_l1_ (u"ࠫࠬ䒭"),l11ll1l11l1l_l1_)
		#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒮"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆื้ๅฮࠦๅาฬหอࠬ䒯")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䒰"),713,l11lll_l1_ (u"ࠨࠩ䒱"),l11lll_l1_ (u"ࠩࠪ䒲"),l11lll_l1_ (u"ࠪࠫ䒳"),l11lll_l1_ (u"ࠫࠬ䒴"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒵"),l111ll_l1_+l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠡ็ิฮอฯࠧ䒶")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䒷"),713,l11lll_l1_ (u"ࠨࠩ䒸"),l11lll_l1_ (u"ࠩࠪ䒹"),l11lll_l1_ (u"ࠪࠫ䒺"),l11lll_l1_ (u"ࠫࠬ䒻"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒼"),l111ll_l1_+l11lll_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อ๋ࠥัหสฬࠫ䒽")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䒾"),713,l11lll_l1_ (u"ࠨࠩ䒿"),l11lll_l1_ (u"ࠩࠪ䓀"),l11lll_l1_ (u"ࠪࠫ䓁"),l11lll_l1_ (u"ࠫࠬ䓂"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓃"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䓄"),l11lll_l1_ (u"ࠧࠨ䓅"),9999)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓆"),l111ll_l1_+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠠๆ่ࠣห้่ำๆࠩ䓇")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࠬ䓈"),713,l11lll_l1_ (u"ࠫࠬ䓉"),l11lll_l1_ (u"ࠬ࠭䓊"),l11lll_l1_ (u"࠭ࠧ䓋"),l11lll_l1_ (u"ࠧࠨ䓌"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓍"),l111ll_l1_+l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโหࠣห้่ำๆࠩ䓎")+l11lll1111l1_l1_,l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫ䓏"),713,l11lll_l1_ (u"ࠫࠬ䓐"),l11lll_l1_ (u"ࠬ࠭䓑"),l11lll_l1_ (u"࠭ࠧ䓒"),l11lll_l1_ (u"ࠧࠨ䓓"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䓔"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䓕"),l11lll_l1_ (u"ࠪࠫ䓖"),9999)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓗"),l111ll_l1_+l11lll_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโห้๋ࠣࠦวๅษึ้ࠬ䓘")+l11lll1111l1_l1_,l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ䓙"),713,l11lll_l1_ (u"ࠧࠨ䓚"),l11lll_l1_ (u"ࠨࠩ䓛"),l11lll_l1_ (u"ࠩࠪ䓜"),l11lll_l1_ (u"ࠪࠫ䓝"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓞"),l111ll_l1_+l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢส่ฬูๅࠨ䓟")+l11lll1111l1_l1_,l11lll_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭䓠"),713,l11lll_l1_ (u"ࠧࠨ䓡"),l11lll_l1_ (u"ࠨࠩ䓢"),l11lll_l1_ (u"ࠩࠪ䓣"),l11lll_l1_ (u"ࠪࠫ䓤"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䓥"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䓦"),l11lll_l1_ (u"࠭ࠧ䓧"),9999)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓨"),l111ll_l1_+l11lll_l1_ (u"ࠨไ้์ฬะࠠๆื้ๅฮࠦรึๆํอࠬ䓩")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䓪"),713,l11lll_l1_ (u"ࠪࠫ䓫"),l11lll_l1_ (u"ࠫࠬ䓬"),l11lll_l1_ (u"ࠬ࠭䓭"),l11lll_l1_ (u"࠭ࠧ䓮"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓯"),l111ll_l1_+l11lll_l1_ (u"ࠨใํำ๏๎็ศฬฺ้ࠣ์แสࠢฦู้๐ษࠨ䓰")+l11lll1111l1_l1_,l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䓱"),713,l11lll_l1_ (u"ࠪࠫ䓲"),l11lll_l1_ (u"ࠫࠬ䓳"),l11lll_l1_ (u"ࠬ࠭䓴"),l11lll_l1_ (u"࠭ࠧ䓵"),l11ll1l11l1l_l1_)
		#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓶"),l111ll_l1_+l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠๆื้ๅฮࠦรึๆํอࠬ䓷")+l11lll1111l1_l1_,l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䓸"),713,l11lll_l1_ (u"ࠪࠫ䓹"),l11lll_l1_ (u"ࠫࠬ䓺"),l11lll_l1_ (u"ࠬ࠭䓻"),l11lll_l1_ (u"࠭ࠧ䓼"),l11ll1l11l1l_l1_)
		#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓽"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหู่๋ࠢ็ษࠡลุ่๏ฯࠧ䓾")+l11lll1111l1_l1_,l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䓿"),713,l11lll_l1_ (u"ࠪࠫ䔀"),l11lll_l1_ (u"ࠫࠬ䔁"),l11lll_l1_ (u"ࠬ࠭䔂"),l11lll_l1_ (u"࠭ࠧ䔃"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔄"),l111ll_l1_+l11lll_l1_ (u"ࠨใํำ๏๎็ศฬ้ࠣัํ่ๅหࠣวฺ๊๊สࠩ䔅")+l11lll1111l1_l1_,l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䔆"),713,l11lll_l1_ (u"ࠪࠫ䔇"),l11lll_l1_ (u"ࠫࠬ䔈"),l11lll_l1_ (u"ࠬ࠭䔉"),l11lll_l1_ (u"࠭ࠧ䔊"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔋"),l111ll_l1_+l11lll_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯࠠฤื็๎ฮ࠭䔌")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䔍"),713,l11lll_l1_ (u"ࠪࠫ䔎"),l11lll_l1_ (u"ࠫࠬ䔏"),l11lll_l1_ (u"ࠬ࠭䔐"),l11lll_l1_ (u"࠭ࠧ䔑"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䔒"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䔓"),l11lll_l1_ (u"ࠩࠪ䔔"),9999)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔕"),l111ll_l1_+l11lll_l1_ (u"ࠫ็์่ศฬࠣวฺ๊๊สࠩ䔖")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭䔗"),713,l11lll_l1_ (u"࠭ࠧ䔘"),l11lll_l1_ (u"ࠧࠨ䔙"),l11lll_l1_ (u"ࠨࠩ䔚"),l11lll_l1_ (u"ࠩࠪ䔛"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔜"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦรึๆํอࠬ䔝")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䔞"),713,l11lll_l1_ (u"࠭ࠧ䔟"),l11lll_l1_ (u"ࠧࠨ䔠"),l11lll_l1_ (u"ࠨࠩ䔡"),l11lll_l1_ (u"ࠩࠪ䔢"),l11ll1l11l1l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䔣"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䔤"),l11lll_l1_ (u"ࠬ࠭䔥"),9999)
	for seq in range(1,l11ll1llll11_l1_+1):
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䔦"),l111ll_l1_+l11lll_l1_ (u"ࠧฦุสๅฮ่ࠦห฼ํ๎ึࠦัศสฺࠫ䔧")+l11lll1111l1_l1_+l11lll_l1_ (u"ࠨࠢࠪ䔨")+text_numbers[seq],l11lll_l1_ (u"ࠩࠪ䔩"),711,l11lll_l1_ (u"ࠪࠫ䔪"),l11lll_l1_ (u"ࠫࠬ䔫"),l11lll_l1_ (u"ࠬ࠭䔬"),l11lll_l1_ (u"࠭ࠧ䔭"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔮"):l11lllllll1l_l1_,l11lll_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࠪ䔯"):seq})
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔰"),l111ll_l1_+l11lll_l1_ (u"ࠪฬึอๅอࠢส่็์่ศฬࠣࠬัี่ๅࠢไๆ฼࠯ࠧ䔱")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䔲"),713,l11lll_l1_ (u"ࠬ࠭䔳"),l11lll_l1_ (u"࠭ࠧ䔴"),l11lll_l1_ (u"ࠧࠨ䔵"),l11lll_l1_ (u"ࠨࠩ䔶"),l11ll1l11l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔷"),l111ll_l1_+l11lll_l1_ (u"ࠪวึฺ๊โࠢส่็์่ศฬ่้ࠣษ๊ศ็ࠣห้๋วื์ฬࠫ䔸")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䔹"),713,l11lll_l1_ (u"ࠬ࠭䔺"),l11lll_l1_ (u"࠭ࠧ䔻"),l11lll_l1_ (u"ࠧࠨ䔼"),l11lll_l1_ (u"ࠨࠩ䔽"),l11ll1l11l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔾"),l111ll_l1_+l11lll_l1_ (u"ࠪวึฺ๊โࠢหีฬ๋ฬࠡษ็ๆ๋๎วหࠢ็่ศ๐วๆࠢส่๊อึ๋หࠪ䔿")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡄࡖࡈࡎࡉࡗࡇࡇࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䕀"),713,l11lll_l1_ (u"ࠬ࠭䕁"),l11lll_l1_ (u"࠭ࠧ䕂"),l11lll_l1_ (u"ࠧࠨ䕃"),l11lll_l1_ (u"ࠨࠩ䕄"),l11ll1l11l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䕅"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䕆"),l11lll_l1_ (u"ࠫࠬ䕇"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕈"),l111ll_l1_+l11lll_l1_ (u"࠭ลืษไอࠥษ่ࠡฬ฽๎๏ืࠠศึอีฬ้ࠧ䕉")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕊"),711,l11lll_l1_ (u"ࠨࠩ䕋"),l11lll_l1_ (u"ࠩࠪ䕌"),l11lll_l1_ (u"ࠪࠫ䕍"),l11lll_l1_ (u"ࠫࠬ䕎"),l11ll1l11l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕏"),l111ll_l1_+l11lll_l1_ (u"࠭ฬๅส้้ࠣ็วหࠩ䕐")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕑"),712,l11lll_l1_ (u"ࠨࠩ䕒"),l11lll_l1_ (u"ࠩࠪ䕓"),l11lll_l1_ (u"ࠪࠫ䕔"),l11lll_l1_ (u"ࠫࠬ䕕"),l11ll1l11l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕖"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠩ䕗")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕘"),717,l11lll_l1_ (u"ࠨࠩ䕙"),l11lll_l1_ (u"ࠩࠪ䕚"),l11lll_l1_ (u"ࠪࠫ䕛"),l11lll_l1_ (u"ࠫࠬ䕜"),l11ll1l11l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕝"),l111ll_l1_+l11lll_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠬ䕞")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕟"),721,l11lll_l1_ (u"ࠨࠩ䕠"),l11lll_l1_ (u"ࠩࠪ䕡"),l11lll_l1_ (u"ࠪࠫ䕢"),l11lll_l1_ (u"ࠫࠬ䕣"),l11ll1l11l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕤"),l111ll_l1_+l11lll_l1_ (u"࠭แฮืࠣหูะัศๅࠪ䕥")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕦"),716,l11lll_l1_ (u"ࠨࠩ䕧"),l11lll_l1_ (u"ࠩࠪ䕨"),l11lll_l1_ (u"ࠪࠫ䕩"),l11lll_l1_ (u"ࠫࠬ䕪"),l11ll1l11l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕫"),l111ll_l1_+l11lll_l1_ (u"࠭วิฬัำฬ๋ࠠศๆึ๎ึ็ัࠡษ็วุืูࠨ䕬")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕭"),722,l11lll_l1_ (u"ࠨࠩ䕮"),l11lll_l1_ (u"ࠩࠪ䕯"),l11lll_l1_ (u"ࠪࠫ䕰"),l11lll_l1_ (u"ࠫࠬ䕱"),l11ll1l11l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕲"),l111ll_l1_+l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣฮ฿๐๊าࠩ䕳")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕴"),723,l11lll_l1_ (u"ࠨࠩ䕵"),l11lll_l1_ (u"ࠩࠪ䕶"),l11lll_l1_ (u"ࠪࠫ䕷"),l11lll_l1_ (u"ࠫࠬ䕸"),l11ll1l11l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䕹"),l111ll_l1_+l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠠห฼ํ๎ึ࠭䕺")+l11lll1111l1_l1_,l11lll_l1_ (u"ࠧࠨ䕻"),726,l11lll_l1_ (u"ࠨࠩ䕼"),l11lll_l1_ (u"ࠩࠪ䕽"),l11lll_l1_ (u"ࠪࠫ䕾"),l11lll_l1_ (u"ࠫࠬ䕿"),l11ll1l11l1l_l1_)
	return
def CHECK_ACCOUNT(l11lllllll1l_l1_,l1ll_l1_=True):
	ok,status = False,l11lll_l1_ (u"ࠬ࠭䖀")
	l11ll1l111ll_l1_,l1l11111111l_l1_ = l11lll_l1_ (u"࠭ࠧ䖁"),l11lll_l1_ (u"ࠧࠨ䖂")
	l1l11111l11l_l1_,l11ll1lllll1_l1_,server,username,password = GET_URL(l11lllllll1l_l1_)
	if username==l11lll_l1_ (u"ࠨࠩ䖃"): return
	headers = GET_HEADERS(l11lllllll1l_l1_)
	if l1l11111l11l_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䖄"),l1l11111l11l_l1_,l11lll_l1_ (u"ࠪࠫ䖅"),headers,False,l11lll_l1_ (u"ࠫࠬ䖆"),l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡆࡌࡊࡉࡋࡠࡃࡆࡇࡔ࡛ࡎࡕ࠯࠴ࡷࡹ࠭䖇"))
		html = response.content
		if response.succeeded:
			timestamp,l11ll11llll1_l1_,l11ll11ll1l1_l1_,l11ll1111lll_l1_,l11lll111111_l1_ = 0,0,l11lll_l1_ (u"࠭ࠧ䖈"),l11lll_l1_ (u"ࠧࠨ䖉"),l11lll_l1_ (u"ࠨࠩ䖊")
			try:
				dict = EVAL(l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䖋"),html)
				status = dict[l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭䖌")][l11lll_l1_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ䖍")]
				ok = True
				l11ll11ll1l1_l1_ = dict[l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡤ࡯࡮ࡧࡱࠪ䖎")][l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡣࡳࡵࡷࠨ䖏")]
			except: pass
			if l11ll11ll1l1_l1_:
				try:
					struct = time.strptime(l11ll11ll1l1_l1_,l11lll_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ䖐"))
					timestamp = int(time.mktime(struct))
					l11ll11llll1_l1_ = int(now-timestamp)
					l11ll11llll1_l1_ = int((l11ll11llll1_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11lll_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ䖑")][l11lll_l1_ (u"ࠩࡦࡶࡪࡧࡴࡦࡦࡢࡥࡹ࠭䖒")]))
					l11ll1111lll_l1_ = time.strftime(l11lll_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ䖓"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䖔")][l11lll_l1_ (u"ࠬ࡫ࡸࡱࡡࡧࡥࡹ࡫ࠧ䖕")]))
					l11lll111111_l1_ = time.strftime(l11lll_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ䖖"),struct)
				except: pass
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡢࠫ䖗")+l11lllllll1l_l1_,str(now))
			settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࡢࠫ䖘")+l11lllllll1l_l1_,str(l11ll11llll1_l1_))
			try:
				l11lll111lll_l1_ = l11lll_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡢ࡭ࡳ࡬࡯ࠣ࠼ࠪ䖙")+html.split(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡴࡦࡰࠤ࠽ࠫ䖚"))[1]
				l11lll111lll_l1_ = l11lll111lll_l1_.replace(l11lll_l1_ (u"ࠫ࠿࠭䖛"),l11lll_l1_ (u"ࠬࡀࠠࠨ䖜")).replace(l11lll_l1_ (u"࠭ࠬࠨ䖝"),l11lll_l1_ (u"ࠧ࠭ࠢࠪ䖞")).replace(l11lll_l1_ (u"ࠨࡿࢀࠫ䖟"),l11lll_l1_ (u"ࠩࢀࠫ䖠"))
				new = re.findall(l11lll_l1_ (u"ࠪࠦࡺࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࠨࡰࡰࡴࡷࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䖡"),l11lll111lll_l1_,re.DOTALL)
				l11ll1l111ll_l1_,l1l11111111l_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧ䖢")][l11lll_l1_ (u"ࠬࡳࡡࡹࡡࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࡹࠧ䖣")]
				l11lll11lll1_l1_ = dict[l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ䖤")][l11lll_l1_ (u"ࠧࡢࡥࡷ࡭ࡻ࡫࡟ࡤࡱࡱࡷࠬ䖥")]
				l11lll1lll11_l1_ = dict[l11lll_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ䖦")][l11lll_l1_ (u"ࠩ࡬ࡷࡤࡺࡲࡪࡣ࡯ࠫ䖧")]
				parts = l1l11111l11l_l1_.split(l11lll_l1_ (u"ࠪࡃࠬ䖨"),1)
				message = l11lll_l1_ (u"࡚ࠫࡘࡌ࠻ࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䖩")+l1l11111l11l_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䖪")
				message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࡗࡹࡧࡴࡶࡵ࠽ࠤࠥ࠭䖫")+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䖬")+status+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䖭")
				message += l11lll_l1_ (u"ࠩ࡟ࡲ࡙ࡸࡩࡢ࡮࠽ࠤࠥࠦࠠࠨ䖮")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䖯")+str(l11lll1lll11_l1_==l11lll_l1_ (u"ࠫ࠶࠭䖰"))+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䖱")
				message += l11lll_l1_ (u"࠭࡜࡯ࡅࡵࡩࡦࡺࡥࡥࠢࠣࡅࡹࡀࠠࠡࠩ䖲")+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䖳")+l11ll1111lll_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䖴")
				message += l11lll_l1_ (u"ࠩ࡟ࡲࡊࡾࡰࡪࡴࡼࠤࡉࡧࡴࡦ࠼ࠣࠤࠬ䖵")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䖶")+l11lll111111_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䖷")
				message += l11lll_l1_ (u"ࠬࡢ࡮ࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࡷࠥࠦࠠࠩࠢࡄࡧࡹ࡯ࡶࡦࠢ࠲ࠤࡒࡧࡸࡪ࡯ࡸࡱࠥ࠯ࠠ࠻ࠢࠣࠫ䖸")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䖹")+l11lll11lll1_l1_+l11lll_l1_ (u"ࠧࠡ࠱ࠣࠫ䖺")+max+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䖻")
				message += l11lll_l1_ (u"ࠩ࡟ࡲࡆࡲ࡬ࡰࡹࡨࡨࠥࡕࡵࡵࡲࡸࡸࡸࡀࠠࠡࠢࠪ䖼")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䖽")+l11lll_l1_ (u"ࠦࠥ࠲ࠠࠣ䖾").join(dict[l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ䖿")][l11lll_l1_ (u"࠭ࡡ࡭࡮ࡲࡻࡪࡪ࡟ࡰࡷࡷࡴࡺࡺ࡟ࡧࡱࡵࡱࡦࡺࡳࠨ䗀")])+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䗁")
				message += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䗂")+l11lll111lll_l1_
				if status==l11lll_l1_ (u"ࠩࡄࡧࡹ࡯ࡶࡦࠩ䗃"): DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠪห้อิหำส็ࠥ๐ูๆๆࠣฬิ๎ๆࠡ็ืห่๊ࠧ䗄"),message)
				else: DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠫ๏ฮฯ้ࠢฦ๊ࠥํๆศๅู้้ࠣไสࠢไ๎ࠥอไศึอีฬ้ࠧ䗅"),message)
	if l1l11111l11l_l1_ and ok and status==l11lll_l1_ (u"ࠬࡇࡣࡵ࡫ࡹࡩࠬ䗆"):
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䗇"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥࡓ࠳ࡖࠢࡘࡖࡑࠦࠠࠡ࡝ࠣࡑ࠸࡛ࠠࡢࡥࡦࡳࡺࡴࡴࠡ࡫ࡶࠤࡔࡑࠠ࡞ࠢࠣࠤࡠࠦࠧ䗈")+l1l11111l11l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ䗉"))
		succeeded = True
	else:
		LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䗊"),l11lll_l1_ (u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥࡓ࠳ࡖࠢࡘࡖࡑࠦࠠࠡ࡝ࠣࡈࡴ࡫ࡳࠡࡰࡲࡸࠥࡽ࡯ࡳ࡭ࠣࡡࠥࠦࠠ࡜ࠢࠪ䗋")+l1l11111l11l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ䗌"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䗍"),l11lll_l1_ (u"࠭ࠧ䗎"),l11lll_l1_ (u"ࠧโฯุࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠩ䗏"),l11lll_l1_ (u"ࠨำสฬ฼ࠦวีฬิห่ࠦเࡎ࠵ࡘࠤฬ๊ะ๋ࠢๅ้ฯࠦว็ฬࠣฬส฼วโฬ๊ࠤส๊้ࠡษ็ฬึ์วๆฮ่ࠣฬฺ๊ࠦ็็ࠤศ๎ࠠศๆิหอ฽ࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣวีํศࠡว็ํ่ࠥวว็ฬࠤฬฺสาษๆࠤๅࡓ࠳ࡖ๋ࠢๆ๊ࠦศฦุสๅฮࠦัศสฺࠤๅࡓ࠳ࡖࠢฯำ๏ีࠠฤ๊ࠣๆ๊ࠦศฦื็หาࠦวๅำสฬ฼ࠦวๅไา๎๊࠭䗐"))
		succeeded = False
	return succeeded,l11ll1l111ll_l1_,l1l11111111l_l1_
def ITEMS(l11lllllll1l_l1_,l11lll11l11l_l1_,l11llll11ll1_l1_,l11ll1l1l111_l1_,l1ll_l1_=True):
	if not l11ll1l1l111_l1_: l11ll1l1l111_l1_ = l11lll_l1_ (u"ࠩ࠴ࠫ䗑")
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_): return
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll11l11l_l1_)
	l1ll111l1111_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䗒"),l11lll11l11l_l1_,l11llll11ll1_l1_)
	end = int(l11ll1l1l111_l1_)*100
	start = end-100
	for context,title,url,l1llll_l1_ in l1ll111l1111_l1_[start:end]:
		l1ll11lll1ll_l1_ = (l11lll_l1_ (u"ࠫࡌࡘࡏࡖࡒࡈࡈࠬ䗓") in l11lll11l11l_l1_ or l11lll11l11l_l1_==l11lll_l1_ (u"ࠬࡇࡌࡍࠩ䗔"))
		l1ll11lll11l_l1_ = (l11lll_l1_ (u"࠭ࡇࡓࡑࡘࡔࡊࡊࠧ䗕") not in l11lll11l11l_l1_ and l11lll11l11l_l1_!=l11lll_l1_ (u"ࠧࡂࡎࡏࠫ䗖"))
		if l1ll11lll1ll_l1_ or l1ll11lll11l_l1_:
			if   l11lll_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ䗗")  in l11lll11l11l_l1_: menuItemsLIST.append([l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗘"),l111ll_l1_+title,url,718,l1llll_l1_,l11lll_l1_ (u"ࠪࠫ䗙"),l11lll_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭䗚"),l11lll_l1_ (u"ࠬ࠭䗛"),{l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗜"):l11lllllll1l_l1_}])
			elif l11lll_l1_ (u"ࠧࡆࡒࡊࠫ䗝") 		 in l11lll11l11l_l1_: menuItemsLIST.append([l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗞"),l111ll_l1_+title,url,718,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ䗟"),l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ䗠"),l11lll_l1_ (u"ࠫࠬ䗡"),{l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗢"):l11lllllll1l_l1_}])
			elif l11lll_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ䗣") in l11lll11l11l_l1_: menuItemsLIST.append([l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗤"),l111ll_l1_+title,url,718,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ䗥"),l11lll_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䗦"),l11lll_l1_ (u"ࠪࠫ䗧"),{l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗨"):l11lllllll1l_l1_}])
			elif l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ䗩") 	 in l11lll11l11l_l1_: menuItemsLIST.append([l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䗪"),l111ll_l1_+title,url,715,l1llll_l1_,l11lll_l1_ (u"ࠧࠨ䗫"),l11lll_l1_ (u"ࠨࠩ䗬"),context,{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗭"):l11lllllll1l_l1_}])
			else: menuItemsLIST.append([l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䗮"),l111ll_l1_+title,url,715,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ䗯"),l11lll_l1_ (u"ࠬ࠭䗰"),l11lll_l1_ (u"࠭ࠧ䗱"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗲"):l11lllllll1l_l1_}])
	total = len(l1ll111l1111_l1_)
	PAGINATION(l11lllllll1l_l1_,l11ll1l1l111_l1_,l11lll11l11l_l1_,714,total,l11llll11ll1_l1_)
	return
def SHOW_EMPTY(l11ll11ll111_l1_):
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䗳"),l11ll11ll111_l1_+l11lll_l1_ (u"๊ࠩิ์ࠦวๅไสส๊ฯࠠฦ็สࠤๆอั฻หࠣวํฺ๋ࠦำ้ࠣํา่ะหࠪ䗴"),l11lll_l1_ (u"ࠪࠫ䗵"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䗶"),l11ll11ll111_l1_+l11lll_l1_ (u"ࠬษ่ࠡษ็าิ๋ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡษืฮึอใไࠩ䗷"),l11lll_l1_ (u"࠭ࠧ䗸"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䗹"),l11ll11ll111_l1_+l11lll_l1_ (u"ࠨล๋ࠤึอศุࠢࡐ࠷࡚ๆࠠศๆำ๎ࠥษๆหࠢฦฺๆะ็ࠡ฼ํีࠥ฻อ๋ฯࠪ䗺"),l11lll_l1_ (u"ࠩࠪ䗻"),9999)
	return
def GROUPS(l11lllllll1l_l1_,l11lll11l11l_l1_,l11llll11ll1_l1_,l11ll1l1l111_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ䗼"),l1ll_l1_=True):
	if not l11ll1l1l111_l1_: l11ll1l1l111_l1_ = l11lll_l1_ (u"ࠫ࠶࠭䗽")
	l11ll11ll111_l1_ = l111ll_l1_
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_): return False
	if l11lll_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䗾") in l11llll11ll1_l1_: l11ll1l1ll11_l1_,l11ll11l1l11_l1_ = l11llll11ll1_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䗿"))
	else: l11ll1l1ll11_l1_,l11ll11l1l11_l1_ = l11llll11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䘀")
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll11l11l_l1_)
	l11lll1l111l_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䘁"),l11lll11l11l_l1_,l11lll_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭䘂"))
	if not l11lll1l111l_l1_: return False
	l11lllll11ll_l1_ = []
	for group,l1llll_l1_ in l11lll1l111l_l1_:
		if l1l1ll11_l1_:
			if l11lll_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ䘃") in group: l11ll11ll111_l1_ = l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ䘄")
			elif l11lll_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ䘅") in group: l11ll11ll111_l1_ = l11lll_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧ䘆")
			elif l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ䘇") in l11lll11l11l_l1_: l11ll11ll111_l1_ = l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䘈")
			else: l11ll11ll111_l1_ = l11lll_l1_ (u"࡙ࠩࡍࡉࡋࡏࡔࠩ䘉")
			l11ll11ll111_l1_ = l11lll_l1_ (u"ࠪ࠰ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䘊")+l11ll11ll111_l1_+l11lll_l1_ (u"ࠫ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䘋")
		if l11lll_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䘌") in group: l11llll111l1_l1_,l11ll11111l1_l1_ = group.split(l11lll_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䘍"))
		else: l11llll111l1_l1_,l11ll11111l1_l1_ = group,l11lll_l1_ (u"ࠧࠨ䘎")
		if not l11llll11ll1_l1_:
			if l11llll111l1_l1_ in l11lllll11ll_l1_: continue
			l11lllll11ll_l1_.append(l11llll111l1_l1_)
			if l11lll_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࠨ䘏") in l1l1ll11_l1_: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘐"),l11ll11ll111_l1_+l11llll111l1_l1_,l11lll11l11l_l1_,168,l11lll_l1_ (u"ࠪࠫ䘑"),l11lll_l1_ (u"ࠫ࠶࠭䘒"),group,l11lll_l1_ (u"ࠬ࠭䘓"),{l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘔"):l11lllllll1l_l1_})
			elif l11lll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䘕") in group: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘖"),l11ll11ll111_l1_+l11llll111l1_l1_,l11lll11l11l_l1_,713,l11lll_l1_ (u"ࠩࠪ䘗"),l11lll_l1_ (u"ࠪ࠵ࠬ䘘"),group,l11lll_l1_ (u"ࠫࠬ䘙"),{l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘚"):l11lllllll1l_l1_})
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘛"),l11ll11ll111_l1_+l11llll111l1_l1_,l11lll11l11l_l1_,714,l11lll_l1_ (u"ࠧࠨ䘜"),l11lll_l1_ (u"ࠨ࠳ࠪ䘝"),group,l11lll_l1_ (u"ࠩࠪ䘞"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘟"):l11lllllll1l_l1_})
		elif l11lll_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ䘠") in group and l11llll111l1_l1_==l11ll1l1ll11_l1_:
			if l11ll11111l1_l1_ in l11lllll11ll_l1_: continue
			l11lllll11ll_l1_.append(l11ll11111l1_l1_)
			if l11lll_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࠬ䘡") in l1l1ll11_l1_: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䘢"),l11ll11ll111_l1_+l11ll11111l1_l1_,l11lll11l11l_l1_,168,l11lll_l1_ (u"ࠧࠨ䘣"),l11lll_l1_ (u"ࠨ࠳ࠪ䘤"),group,l11lll_l1_ (u"ࠩࠪ䘥"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘦"):l11lllllll1l_l1_})
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䘧"),l11ll11ll111_l1_+l11ll11111l1_l1_,l11lll11l11l_l1_,714,l1llll_l1_,l11lll_l1_ (u"ࠬ࠷ࠧ䘨"),group,l11lll_l1_ (u"࠭ࠧ䘩"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘪"):l11lllllll1l_l1_})
	#if l11lll_l1_ (u"ࠨࡕࡒࡖ࡙ࡋࡄࠨ䘫") in l11lll11l11l_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l1ll11_l1_:
		end = int(l11ll1l1l111_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l11lllllll1l_l1_,l11ll1l1l111_l1_,l11lll11l11l_l1_,713,total,l11llll11ll1_l1_)
	return True
def EPG_ITEMS(l11lllllll1l_l1_,url,function):
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,True): return
	headers = GET_HEADERS(l11lllllll1l_l1_)
	timestamp = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࡤ࠭䘬")+l11lllllll1l_l1_)
	if not timestamp or now-int(timestamp)>24*l11ll11l1ll1_l1_:
		succeeded,l11ll1l111ll_l1_,l1l11111111l_l1_ = CHECK_ACCOUNT(l11lllllll1l_l1_,False)
		if not succeeded: return
	l11ll11llll1_l1_ = int(settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡸ࡮ࡳࡥࡥ࡫ࡩࡪࡤ࠭䘭")+l11lllllll1l_l1_))
	server = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ䘮")+l11lllllll1l_l1_)
	username = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡱࡥࡲ࡫࡟ࠨ䘯")+l11lllllll1l_l1_)
	password = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡰࡢࡵࡶࡻࡴࡸࡤࡠࠩ䘰")+l11lllllll1l_l1_)
	l11ll1l1111l_l1_ = url.split(l11lll_l1_ (u"ࠧ࠰ࠩ䘱"))
	l11ll1111l1l_l1_ = l11ll1l1111l_l1_[-1].replace(l11lll_l1_ (u"ࠨ࠰ࡷࡷࠬ䘲"),l11lll_l1_ (u"ࠩࠪ䘳")).replace(l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䘴"),l11lll_l1_ (u"ࠫࠬ䘵"))
	if function==l11lll_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ䘶"): l11llllll11l_l1_ = l11lll_l1_ (u"࠭ࡧࡦࡶࡢࡷ࡭ࡵࡲࡵࡡࡨࡴ࡬࠭䘷")
	else: l11llllll11l_l1_ = l11lll_l1_ (u"ࠧࡨࡧࡷࡣࡸ࡯࡭ࡱ࡮ࡨࡣࡩࡧࡴࡢࡡࡷࡥࡧࡲࡥࠨ䘸")
	l1l11111l11l_l1_,l11ll1lllll1_l1_,server,username,password = GET_URL(l11lllllll1l_l1_)
	if not username: return
	l11ll1l1llll_l1_ = l1l11111l11l_l1_+l11lll_l1_ (u"ࠨࠨࡤࡧࡹ࡯࡯࡯࠿ࠪ䘹")+l11llllll11l_l1_+l11lll_l1_ (u"ࠩࠩࡷࡹࡸࡥࡢ࡯ࡢ࡭ࡩࡃࠧ䘺")+l11ll1111l1l_l1_
	html = OPENURL_CACHED(NO_CACHE,l11ll1l1llll_l1_,l11lll_l1_ (u"ࠪࠫ䘻"),headers,l11lll_l1_ (u"ࠫࠬ䘼"),l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡈࡔࡌࡥࡉࡕࡇࡐࡗ࠲࠸࡮ࡥࠩ䘽"))
	l11lll111ll1_l1_ = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ䘾"),html)
	l11ll11l11l1_l1_ = l11lll111ll1_l1_[l11lll_l1_ (u"ࠧࡦࡲࡪࡣࡱ࡯ࡳࡵ࡫ࡱ࡫ࡸ࠭䘿")]
	l11ll1ll1lll_l1_ = []
	if function in [l11lll_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ䙀"),l11lll_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ䙁")]:
		for dict in l11ll11l11l1_l1_:
			if dict[l11lll_l1_ (u"ࠪ࡬ࡦࡹ࡟ࡢࡴࡦ࡬࡮ࡼࡥࠨ䙂")]==1:
				l11ll1ll1lll_l1_.append(dict)
				if function in [l11lll_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䙃")]: break
		if not l11ll1ll1lll_l1_: return
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙄"),l111ll_l1_+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ษ็้้็วหࠢส่ศ๎ไ๋ࠢห๋ีํࠠศๆๅหห๋ษࠡไาࠤ้อࠠห฻่่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䙅"),l11lll_l1_ (u"ࠧࠨ䙆"),9999)
		if function in [l11lll_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䙇")]:
			l11lllllll11_l1_ = 2
			l11ll11l1l1l_l1_ = l11lllllll11_l1_*l11ll11l1ll1_l1_
			l11ll1ll1lll_l1_ = []
			l1l111111lll_l1_ = int(int(dict[l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡴࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ䙈")])/l11ll11l1l1l_l1_)*l11ll11l1l1l_l1_
			l11llll11111_l1_ = now+l11ll11l1l1l_l1_
			l11ll111l111_l1_ = int((l11llll11111_l1_-l1l111111lll_l1_)/l11ll11l1ll1_l1_)
			for count in range(l11ll111l111_l1_):
				if count>=6:
					if count%l11lllllll11_l1_!=0: continue
					l1l1l1111_l1_ = l11ll11l1l1l_l1_
				else: l1l1l1111_l1_ = l11ll11l1l1l_l1_//2
				l11ll111l1ll_l1_ = l1l111111lll_l1_+count*l11ll11l1ll1_l1_
				dict = {}
				dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䙉")] = l11lll_l1_ (u"ࠫࠬ䙊")
				struct = time.localtime(l11ll111l1ll_l1_-l11ll11llll1_l1_-l11ll11l1ll1_l1_)
				dict[l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ䙋")] = time.strftime(l11lll_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ䙌"),struct)
				dict[l11lll_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䙍")] = str(l11ll111l1ll_l1_)
				dict[l11lll_l1_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ䙎")] = str(l11ll111l1ll_l1_+l1l1l1111_l1_)
				l11ll1ll1lll_l1_.append(dict)
	elif function in [l11lll_l1_ (u"ࠩࡖࡌࡔࡘࡔࡠࡇࡓࡋࠬ䙏"),l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ䙐")]: l11ll1ll1lll_l1_ = l11ll11l11l1_l1_
	if function==l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭䙑") and len(l11ll1ll1lll_l1_)>0:
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙒"),l111ll_l1_+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้ำ๋่ࠥวว็ฬࠤอืวๆฮࠣห้่ๆ้ษอࠤ࠭าฯ้ๆࠣๅ็฽ࠩแ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䙓"),l11lll_l1_ (u"ࠧࠨ䙔"),9999)
	l11ll1ll1l11_l1_ = []
	l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡍࡨࡵ࡮ࠨ䙕"))
	for dict in l11ll1ll1lll_l1_:
		title = base64.b64decode(dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䙖")])
		if kodi_version>18.99: title = title.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䙗"))
		l11ll111l1ll_l1_ = int(dict[l11lll_l1_ (u"ࠫࡸࡺࡡࡳࡶࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭䙘")])
		l11llll1l111_l1_ = int(dict[l11lll_l1_ (u"ࠬࡹࡴࡰࡲࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭䙙")])
		l11llll111ll_l1_ = str(int((l11llll1l111_l1_-l11ll111l1ll_l1_+59)/60))
		l1l11111l1ll_l1_ = dict[l11lll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ䙚")].replace(l11lll_l1_ (u"ࠧࠡࠩ䙛"),l11lll_l1_ (u"ࠨ࠼ࠪ䙜"))
		struct = time.localtime(l11ll111l1ll_l1_-l11ll11l1ll1_l1_)
		l11lll1ll11l_l1_ = time.strftime(l11lll_l1_ (u"ࠩࠨࡌ࠿ࠫࡍࠨ䙝"),struct)
		l11llll11l11_l1_ = time.strftime(l11lll_l1_ (u"ࠪࠩࡦ࠭䙞"),struct)
		if function==l11lll_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ䙟"): title = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ䙠")+l11lll1ll11l_l1_+l11lll_l1_ (u"࠭ࠠแࠢࠪ䙡")+title+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䙢")
		elif function==l11lll_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䙣"): title = l11llll11l11_l1_+l11lll_l1_ (u"ࠩࠣࠫ䙤")+l11lll1ll11l_l1_+l11lll_l1_ (u"ࠪࠤ࠭࠭䙥")+l11llll111ll_l1_+l11lll_l1_ (u"ࠫࡲ࡯࡮ࠪࠩ䙦")
		else: title = l11llll11l11_l1_+l11lll_l1_ (u"ࠬࠦࠧ䙧")+l11lll1ll11l_l1_+l11lll_l1_ (u"࠭ࠠࠩࠩ䙨")+l11llll111ll_l1_+l11lll_l1_ (u"ࠧ࡮࡫ࡱ࠭ࠥࠦࠠࠨ䙩")+title+l11lll_l1_ (u"ࠨࠢใࠫ䙪")
		if function in [l11lll_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ䙫"),l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ䙬"),l11lll_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ䙭")]:
			l11ll111ll1l_l1_ = server+l11lll_l1_ (u"ࠬ࠵ࡴࡪ࡯ࡨࡷ࡭࡯ࡦࡵ࠱ࠪ䙮")+username+l11lll_l1_ (u"࠭࠯ࠨ䙯")+password+l11lll_l1_ (u"ࠧ࠰ࠩ䙰")+l11llll111ll_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ䙱")+l1l11111l1ll_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ䙲")+l11ll1111l1l_l1_+l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䙳")
			if function==l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭䙴"): addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䙵"),l111ll_l1_+title,l11ll111ll1l_l1_,9999,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ䙶"),l11lll_l1_ (u"ࠧࠨ䙷"),l11lll_l1_ (u"ࠨࠩ䙸"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䙹"):l11lllllll1l_l1_})
			else: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䙺"),l111ll_l1_+title,l11ll111ll1l_l1_,235,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ䙻"),l11lll_l1_ (u"ࠬ࠭䙼"),l11lll_l1_ (u"࠭ࠧ䙽"),{l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䙾"):l11lllllll1l_l1_})
		l11ll1ll1l11_l1_.append(title)
	if function==l11lll_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ䙿") and l11ll1ll1l11_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11ll1ll1l11_l1_)
	return l11ll1ll1l11_l1_
def USE_FASTER_SERVER(l11lllllll1l_l1_):
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,True): return
	server,l11ll1l111l1_l1_,l11ll11ll1ll_l1_ = l11lll_l1_ (u"ࠩࠪ䚀"),0,0
	succeeded,l11ll1l111ll_l1_,l1l11111111l_l1_ = CHECK_ACCOUNT(l11lllllll1l_l1_,False)
	if succeeded:
		l11llllll111_l1_ = DNS_RESOLVER(l11ll1l111ll_l1_)
		l11ll1l111l1_l1_ = PING(l11llllll111_l1_[0],int(l1l11111111l_l1_))
		l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䚁"))
		groups = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䚂"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ䚃"))
		l1ll111l1111_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ䚄"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭䚅"),groups[1])
		url = l1ll111l1111_l1_[0][2]
		l11lll1ll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫ䚆"),url,re.DOTALL)
		l11lll1ll1ll_l1_ = l11lll1ll1ll_l1_[0]
		if l11lll_l1_ (u"ࠩ࠽ࠫ䚇") in l11lll1ll1ll_l1_: l11lll11l1l1_l1_,l11llll1llll_l1_ = l11lll1ll1ll_l1_.split(l11lll_l1_ (u"ࠪ࠾ࠬ䚈"))
		else: l11lll11l1l1_l1_,l11llll1llll_l1_ = l11lll1ll1ll_l1_,l11lll_l1_ (u"ࠫ࠽࠶ࠧ䚉")
		l11ll111l11l_l1_ = DNS_RESOLVER(l11lll11l1l1_l1_)
		l11ll11ll1ll_l1_ = PING(l11ll111l11l_l1_[0],int(l11llll1llll_l1_))
	if l11ll1l111l1_l1_ and l11ll11ll1ll_l1_:
		message = l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆึ๎ึ็ัࠡษ็วฺ๊๊ࠡล่ࠤฬ๊ำ๋ำไีࠥอไฤีิ฽ࠥลࠡࠢࠩ䚊")
		message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ䚋")+l11lll_l1_ (u"้ࠧไอࠤ฻อฦฺࠢไ๎ࠥอไิ์ิๅึࠦวๅลุ่๏࠭䚌")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ䚍")+str(int(l11ll11ll1ll_l1_*1000))+l11lll_l1_ (u"้้ࠩࠣ๐ࠠฬษ้๎ฮ࠭䚎")
		message += l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䚏")+l11lll_l1_ (u"ࠫํ่สุࠡสส฾ࠦแ๋ࠢสุ่๐ัโำࠣห้ฮฯ๋ๆࠪ䚐")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ䚑")+str(int(l11ll1l111l1_l1_*1000))+l11lll_l1_ (u"࠭ࠠๆๆํࠤะอๆ๋หࠪ䚒")
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䚓"),l11lll_l1_ (u"ࠨษ็ื๏ืแาࠢส่ศ฻ไ๋ࠩ䚔"),l11lll_l1_ (u"ࠩสุ่๐ัโำࠣห้ษำา฻ࠪ䚕"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䚖"),message)
		if l1ll11l111_l1_==1 and l11ll1l111l1_l1_<l11ll11ll1ll_l1_: server = l11ll1l111ll_l1_+l11lll_l1_ (u"ࠫ࠿࠭䚗")+l1l11111111l_l1_
	else: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䚘"),l11lll_l1_ (u"࠭ࠧ䚙"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䚚"),l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦอัࠣหู้๊าใิࠤฬ๊ศะ์็ࠫ䚛"))
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ䚜")+l11lllllll1l_l1_,server)
	return
def PLAY(l11lllllll1l_l1_,url,type):
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ䚝")+l11lllllll1l_l1_)
	l11l11l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭䚞")+l11lllllll1l_l1_)
	if l111llll1l_l1_ or l11l11l11l_l1_:
		url += l11lll_l1_ (u"ࠬࢂࠧ䚟")
		if l111llll1l_l1_: url += l11lll_l1_ (u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ䚠")+l111llll1l_l1_
		if l11l11l11l_l1_: url += l11lll_l1_ (u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䚡")+l11l11l11l_l1_
		url = url.replace(l11lll_l1_ (u"ࠨࡾࠩࠫ䚢"),l11lll_l1_ (u"ࠩࡿࠫ䚣"))
	#l1111l1ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡷࡪࡸࡶࡦࡴࡢࠫ䚤")+l11lllllll1l_l1_)
	#if l1111l1ll1_l1_:
	#	l11lll1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ䚥"),url,re.DOTALL)
	#	url = url.replace(l11lll1l11ll_l1_[0],l1111l1ll1_l1_)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(l11lllllll1l_l1_):
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䚦"),l11lll_l1_ (u"࠭ࠧ䚧"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䚨"),l11lll_l1_ (u"ࠨฬะิ๏ืࠠๆ้่ࠤํํวๆࠢฯำฬࠦ࠮ࠡ์ิะ๎ูࠦะ็ࠣฮ฿๐๊า้ࠣษีอࠠไ่อࠤ้อࠠห฻ิๅ๋ࠥว้๋ࠡࠤ࠳้ࠦࠠ฻า้ࠥะฺ๋์ิ๋ࠥหไศࠢ฼๊ิࠦวๅุิ์ึฯࠠศๆๅูํ๏ࠠ࠯ࠢส่าอฬสࠢ็๋ีอࠠศๆอ฾๏๐ั้ࠡํࠤๆ่ืࠡวำหࠥ฽ไษฬ้๋้ࠣࠠีำๆอࠥๆࡍ࠴ࡗࠣว๋ࠦสฺ็็ࠤ์ึวࠡษ็ฮ฿๐๊าࠢ࠱ࠤํ็โุࠢ฼๊ิ๋วࠡฬึฮำีๅࠡะา้ฮࠦเࡎ࠵ࡘࠤฯำสศฮࠣไ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠡะสูࠬ䚩"))
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭䚪")+l11lllllll1l_l1_)
	l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䚫"),l11lll_l1_ (u"ࠫฬูสฯัส้ࠥอไฤื็๎ࠬ䚬"),l11lll_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ䚭"),l111llll1l_l1_,l11lll_l1_ (u"࠭็ัษ๋ࠣํࠦเࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤฬ๊ๅิฬัำ๊ࠦอศๆํหู๋ࠥࠡโࡐ࠷࡚ࠦวๅาํࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢอ฽ิ๐ไ่ࠢฦ้ࠥะั๋ัࠣษ฾อฯห้ࠣษ้๏ุ้ࠠ฼๎ฮࠦวๅฬฮฬ๏ะࠠศๆฦู้๐้ࠠษ็ฮ๏ࠦสใำํฬฬࠦส็ษึฬࠥาๅ๋฻ุࠣึ้วหࠢใࡑ࠸࡛ࠠภࠣࠪ䚮"))
	if l11111lll11_l1_==1: l111llll1l_l1_ = OPEN_KEYBOARD(l11lll_l1_ (u"ࠧฤๅอฬࠥๆࡍ࠴ࡗ࡙ࠣࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠอัํำࠬ䚯"),l111llll1l_l1_,True)
	else: l111llll1l_l1_ = l11lll_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ䚰")
	if l111llll1l_l1_==l11lll_l1_ (u"ࠩࠣࠫ䚱"):
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䚲"),l11lll_l1_ (u"ࠫࠬ䚳"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䚴"),l11lll_l1_ (u"ฺ๋࠭ำุ้๋่ࠣฮࠢฦืฯิฯศ็ࠣๅึอฺࠡๆ๋ัิํࠠฤ๊ࠣ฽ิฯࠠโำส฾ฬะࠠๅ๊ะำ์อࠠ࠯࠰࠱ࠤ๏าศࠡว่หࠥะัไ้ࠣๅฬืฺࠡฬ่ห๊อࠠฤ๊ࠣษ฻อแสࠢะีๆࠦร้ࠢฦ๎ฺ๊ࠥࠡฤัีู๋่ࠥษࠪ䚵"))
		return
	l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䚶"),l11lll_l1_ (u"ࠨࠩ䚷"),l11lll_l1_ (u"ࠩࠪ䚸"),l111llll1l_l1_,l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฬูสฯัส้ࠥํะศࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠษั็ห๋ࠥๆࠡࠢส่็ี๊ๆࠢยࠫ䚹"))
	if l11111lll11_l1_!=1:
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䚺"),l11lll_l1_ (u"ࠬ࠭䚻"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䚼"),l11lll_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ䚽"))
		return
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䚾")+l11lllllll1l_l1_,l111llll1l_l1_)
	#l11llll11l1l_l1_(l11lllllll1l_l1_)
	DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_)
	return
def ADD_REFERER(l11lllllll1l_l1_):
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䚿"),l11lll_l1_ (u"ࠪࠫ䛀"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䛁"),l11lll_l1_ (u"ࠬะอั์ิࠤ๊ํๅ๊๊ࠡห๊ࠦฬะษࠣ࠲ࠥ๐ัอ๋ࠣ฽ิ๋ࠠห฼ํ๎ึํࠠฦาสࠤ่์สࠡๆสࠤฯ฿ัโ่ࠢหࠥํ่ࠡ࠰ࠣࠤํ฿ฯๆࠢอ฾๏๐ั่ࠢศ่ฬูࠦ็ัࠣห้฼ั้ำฬࠤฬ๊โึ๊์ࠤ࠳ࠦวๅฯสะฮࠦไ่าสࠤฬ๊ส฻์ํีࠥํ๊ࠡใๅ฻ࠥหะศฺ่ࠢอะࠠๆ่ๆࠤูืใสࠢใࡑ࠸࡛ࠠฤ่ࠣฮ฾๋ไ้ࠡำหࠥอไห฼ํ๎ึࠦ࠮๊ࠡไๆ฼ูࠦ็ั่หࠥะำหะา้ࠥิฯๆหࠣไࡒ࠹ࡕࠡฬะฮฬาࠠแࡔࡨࡪࡪࡸࡥࡳࠢัหฺ࠭䛂"))
	l11l11l11l_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨ䛃")+l11lllllll1l_l1_)
	l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䛄"),l11lll_l1_ (u"ࠨษึฮำีวๆࠢส่ศ฻ไ๋ࠩ䛅"),l11lll_l1_ (u"ࠩอ฽ิ๐ไࠡษ็ๆิ๐ๅࠨ䛆"),l11l11l11l_l1_,l11lll_l1_ (u"๋ࠪีอ่๊ࠠࠣไࡗ࡫ࡦࡦࡴࡨࡶࠥอไๆีอาิ๋ࠠฮษ็๎ฬࠦๅฺࠢใࡑ࠸࡛ࠠศๆำ๎ࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠠ࠯๊่ࠢࠥะั๋ัࠣฮ฾ี๊ๅ้ࠣว๊ࠦสา์าࠤส฿วะฬ๊ࠤสู๊้๊ࠡ฽๏ฯࠠศๆอฯอ๐สࠡษ็วฺ๊๊๊ࠡส่ฯ๐ࠠหไิ๎ออࠠห่สือࠦฬๆ์฼ࠤูืใศฬࠣไࡒ࠹ࡕࠡมࠤࠫ䛇"))
	if l11111lll11_l1_==1: refererr = OPEN_KEYBOARD(l11lll_l1_ (u"ࠫศ้สษࠢใࡑ࠸࡛ࠠࡓࡧࡩࡩࡷ࡫ࡲࠡฮา๎ิ࠭䛈"),l11l11l11l_l1_,True)
	else: l11l11l11l_l1_ = l11lll_l1_ (u"ࠬ࠭䛉")
	if l11l11l11l_l1_==l11lll_l1_ (u"࠭ࠠࠨ䛊"):
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䛋"),l11lll_l1_ (u"ࠨࠩ䛌"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䛍"),l11lll_l1_ (u"ࠪ฾๏ืࠠๆี่์าࠦริฬัำฬ๋ࠠโำส฾๊่ࠥฮั๊ࠤศ๎ฺࠠัฬࠤๆืว฻ษอࠤ้๎อะ้สࠤ࠳࠴࠮ࠡ์ฯฬࠥหๅศࠢอี่ํࠠโษิ฾ࠥะๅศ็สࠤศ๎ࠠฦุสๅฮࠦอาใࠣวํࠦร๋ࠢื๎ࠥศฮา่ࠢ฽์อࠧ䛎"))
		return
	l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䛏"),l11lll_l1_ (u"ࠬ࠭䛐"),l11lll_l1_ (u"࠭ࠧ䛑"),l11l11l11l_l1_,l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆ๊ࠢิฬࠦเࡓࡧࡩࡩࡷ࡫ࡲࠡสา่ฬࠦๅ็ࠢࠣห้่ฯ๋็ࠣรࠬ䛒"))
	if l11111lll11_l1_!=1:
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䛓"),l11lll_l1_ (u"ࠩࠪ䛔"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䛕"),l11lll_l1_ (u"ࠫฯ๋ࠠศๆศ่฿อมࠨ䛖"))
		return
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧ䛗")+l11lllllll1l_l1_,l11l11l11l_l1_)
	DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_)
	return
def GET_URL(l11lllllll1l_l1_,l11ll11l11ll_l1_=l11lll_l1_ (u"࠭ࠧ䛘")):
	if not l11ll11l11ll_l1_: l11ll11l11ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ䛙")+l11lllllll1l_l1_)
	server = SERVER(l11ll11l11ll_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ䛚"))
	username = re.findall(l11lll_l1_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁ࠭࠴ࠪࡀࠫࠩࠫ䛛"),l11ll11l11ll_l1_+l11lll_l1_ (u"ࠪࠪࠬ䛜"),re.DOTALL)
	password = re.findall(l11lll_l1_ (u"ࠫࡵࡧࡳࡴࡹࡲࡶࡩࡃࠨ࠯ࠬࡂ࠭ࠫ࠭䛝"),l11ll11l11ll_l1_+l11lll_l1_ (u"ࠬࠬࠧ䛞"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䛟"),l11lll_l1_ (u"ࠧࠨ䛠"),l11lll_l1_ (u"ࠨใะูࠥอิหำส็ࠥๆࡍ࠴ࡗࠪ䛡"),l11lll_l1_ (u"ࠩิหอ฽ࠠศึอีฬ้ࠠแࡏ࠶࡙ࠥอไั์ࠣๆ๊ะࠠศ่อࠤอหึศใอ๋ࠥหไ๊ࠢส่อืๆศ็ฯࠤ้อ๋ࠠ฻่่ࠥษ่ࠡษ็ีฬฮืࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱ࠤศึ็ษࠢศ่๎ࠦโศศ่อࠥอิหำส็ࠥๆࡍ࠴ࡗࠣ์็๋ࠠษวูหๆฯࠠาษห฻ࠥๆࡍ࠴ࡗࠣะิ๐ฯࠡล๋ࠤ็๋ࠠษวุ่ฬำࠠศๆิหอ฽ࠠศๆๅำ๏๋ࠧ䛢"))
		return l11lll_l1_ (u"ࠪࠫ䛣"),l11lll_l1_ (u"ࠫࠬ䛤"),l11lll_l1_ (u"ࠬ࠭䛥"),l11lll_l1_ (u"࠭ࠧ䛦"),l11lll_l1_ (u"ࠧࠨ䛧")
	username = username[0]
	password = password[0]
	l1l11111l11l_l1_ = server+l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿࡥࡳࡡࡤࡴ࡮࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭䛨")+username+l11lll_l1_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭䛩")+password
	l11ll1lllll1_l1_ = server+l11lll_l1_ (u"ࠪ࠳࡬࡫ࡴ࠯ࡲ࡫ࡴࡄࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨ䛪")+username+l11lll_l1_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨ䛫")+password+l11lll_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࡲ࠹ࡵࡠࡲ࡯ࡹࡸ࠭䛬")
	return l1l11111l11l_l1_,l11ll1lllll1_l1_,server,username,password
def GET_FILENAME(l11lllllll1l_l1_,l11lllll1lll_l1_=l11lll_l1_ (u"࠭ࠧ䛭")):
	l11lll11ll1l_l1_ = l11lllll1lll_l1_.replace(l11lll_l1_ (u"ࠧ࠰ࠩ䛮"),l11lll_l1_ (u"ࠨࡡࠪ䛯")).replace(l11lll_l1_ (u"ࠩ࠽ࠫ䛰"),l11lll_l1_ (u"ࠪࡣࠬ䛱")).replace(l11lll_l1_ (u"ࠫ࠳࠭䛲"),l11lll_l1_ (u"ࠬࡥࠧ䛳"))
	l11lll11ll1l_l1_ = l11lll11ll1l_l1_.replace(l11lll_l1_ (u"࠭࠿ࠨ䛴"),l11lll_l1_ (u"ࠧࡠࠩ䛵")).replace(l11lll_l1_ (u"ࠨ࠿ࠪ䛶"),l11lll_l1_ (u"ࠩࡢࠫ䛷")).replace(l11lll_l1_ (u"ࠪࠪࠬ䛸"),l11lll_l1_ (u"ࠫࡤ࠭䛹"))
	l11lll11ll1l_l1_ = os.path.join(addoncachefolder,l11lll11ll1l_l1_).strip(l11lll_l1_ (u"ࠬ࠴࡭࠴ࡷࠪ䛺"))+l11lll_l1_ (u"࠭࠮࡮࠵ࡸࠫ䛻")
	return l11lll11ll1l_l1_
def ADD_ACCOUNT(l11lllllll1l_l1_,l111ll1l_l1_):
	l11lllll1l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ䛼")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠨࡡࠪ䛽")+l111ll1l_l1_)
	l11ll11l1lll_l1_ = True
	if l11lllll1l11_l1_:
		l11111lll11_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䛾"),l11lll_l1_ (u"ࠪ็ฯอศสࠢฯำ๏ีࠧ䛿"),l11lll_l1_ (u"ࠫฯ฿ฯ๋ๆࠣห้่ฯ๋็ࠪ䜀"),l11lll_l1_ (u"๋ࠬำฮࠢส่็ี๊ๆࠩ䜁"),l11lll_l1_ (u"࠭วๅำสฬ฼ࠦวๅฯส่๏ࠦ็้࠼ࠪ䜂"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䜃")+l11lllll1l11_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䜄")+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ่ࠠาสࠤ์๎ࠠาษห฻ࠥࡓ࠳ࡖࠢสู่๊ฬๅࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯ฿ฯ๋ๆ๊ࠤศ๋ࠠหำํำ้ࠥสศสฬࠤึอศุࠢฯำ๏ีࠠภࠣࠪ䜅"))
		if l11111lll11_l1_==-1: return
		elif l11111lll11_l1_==0: l11lllll1l11_l1_ = l11lll_l1_ (u"ࠪࠫ䜆")
		elif l11111lll11_l1_==2:
			l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ䜇"),l11lll_l1_ (u"ࠬ࠭䜈"),l11lll_l1_ (u"࠭ࠧ䜉"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䜊"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦวๅำสฬ฼ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧ䜋"))
			if l11111lll11_l1_ in [-1,0]: return
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䜌"),l11lll_l1_ (u"ࠪࠫ䜍"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䜎"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥอไาษห฻ࠬ䜏"))
			l11ll11l1lll_l1_ = False
			l11ll1ll1l1l_l1_ = l11lll_l1_ (u"࠭ࠧ䜐")
	if l11ll11l1lll_l1_:
		l11ll1ll1l1l_l1_ = OPEN_KEYBOARD(l11lll_l1_ (u"ࠧศๅอฬࠥืวษูࠣไࡒ࠹ࡕࠡๅส้้อࠧ䜑"),l11lllll1l11_l1_)
		l11ll1ll1l1l_l1_ = l11ll1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ䜒"))
		if not l11ll1ll1l1l_l1_:
			l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䜓"),l11lll_l1_ (u"ࠪࠫ䜔"),l11lll_l1_ (u"ࠫࠬ䜕"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䜖"),l11lll_l1_ (u"࠭ไใัࠣๆ๊ะࠠษวาาฬ๊ࠠาษห฻ࠥ็วา฼ࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆีะࠤฬ๊ัศสฺࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠬ䜗"))
			if l11111lll11_l1_ in [-1,0]: return
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䜘"),l11lll_l1_ (u"ࠨࠩ䜙"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䜚"),l11lll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣห้ืวษูࠪ䜛"))
		else:
			#l1l11111l11l_l1_,l11ll1lllll1_l1_,server,username,password = GET_URL(l11lllllll1l_l1_)
			#if not username: return
			message = l11lll_l1_ (u"ࠫ์ึ็ࠡษ็้฾๊่ๆษอࠤฯ๋ࠠฤะำ๋ฬࠦๅ็ࠢิหอ฽ࠠแࡏ࠶࡙ࠥอไั์ࠣห๋ะࠠไฬหฮ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊หࠥลࠡ࡝ࡰࠪ䜜")
			#message += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䜝")+server+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ฺ่๋ห๋ࠦวๅีํีๆื࠺ࠡࠩ䜞")
			#message += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ䜟")+username+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟สื๊ࠦวๅ็ึฮำีๅ࠻ࠢࠪ䜠")
			#message += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䜡")+password+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ่๊ๅสࠢสุ่ื࠺ࠡࠩ䜢")
			l11111lll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ䜣"),l11lll_l1_ (u"ࠬ࠭䜤"),l11lll_l1_ (u"࠭ࠧ䜥"),l11lll_l1_ (u"ࠧศๆิหอ฽ࠠศๆฯำ๏ี่๊ࠠ࠽ࠫ䜦"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䜧")+l11ll1ll1l1l_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䜨")+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䜩")+message)
			if l11111lll11_l1_!=1:
				DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䜪"),l11lll_l1_ (u"ࠬ࠭䜫"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䜬"),l11lll_l1_ (u"ࠧห็ࠣห้หไ฻ษฤࠫ䜭"))
				return
	settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭䜮")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠩࡢࠫ䜯")+l111ll1l_l1_,l11ll1ll1l1l_l1_)
	#settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ䜰")+l11lllllll1l_l1_,l11lll_l1_ (u"ࠫࠬ䜱"))
	#settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡺࡩ࡮ࡧࡧ࡭࡫࡬࡟ࠨ䜲")+l11lllllll1l_l1_,l11lll_l1_ (u"࠭ࠧ䜳"))
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ䜴")+l11lllllll1l_l1_)
	if not l111llll1l_l1_: settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䜵")+l11lllllll1l_l1_,l11lll_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ䜶"))
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䜷"),l11lll_l1_ (u"ࠫࠬ䜸"),l11lll_l1_ (u"ࠬ࠭䜹"),l11lll_l1_ (u"࠭ࠧ䜺"),l11ll1ll1l1l_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲฯ๋ࠠห฼ํีࠥืวษูࠣหูะัศๅࠣไࡒ࠹ࡕࠡว็ํࠥํะศࠢส่ึอศุࠢส่ัี๊ะࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤ์ึวࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨ䜻"))
	#if l1ll11l111_l1_==1: ok,l11ll1l111ll_l1_,l1l11111111l_l1_ = CHECK_ACCOUNT(l11lllllll1l_l1_,True)
	#l11llll11l1l_l1_(l11lllllll1l_l1_)
	DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_)
	return
def READ_ALL_LINES(lines,l11lllll1ll1_l1_,l11lll11l1ll_l1_,l11l1ll11l_l1_,length,l1ll111ll111_l1_,l11ll1lllll1_l1_):
	l1ll111l1111_l1_,l11ll11l111l_l1_ = [],[]
	vod_types = [l11lll_l1_ (u"ࠨ࠰ࡤࡺ࡮࠭䜼"),l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ䜽"),l11lll_l1_ (u"ࠪ࠲ࡲࡱࡶࠨ䜾"),l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠴ࠩ䜿"),l11lll_l1_ (u"ࠬ࠴ࡷࡦࡤࡰࠫ䝀")]
	for line in lines:
		if l1ll111ll111_l1_%473==0:
			PROGRESS_UPDATE(l11l1ll11l_l1_,40+int(10*l1ll111ll111_l1_/length),l11lll_l1_ (u"࠭โาษฤอࠥอไโ์า๎ํํวหࠩ䝁"),l11lll_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ䝂"),str(l1ll111ll111_l1_)+l11lll_l1_ (u"ࠨࠢ࠲ࠤࠬ䝃")+str(length))
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return None,None,None
		url = re.findall(l11lll_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࡞ࡱ࠯࠭࠮ࡨࡵࡶࡳࢀ࡭ࡺࡴࡱࡵࡿࡶࡹࡳࡰࠪ࠰࠭ࡃ࠮ࠪࠧ䝄"),line,re.DOTALL)
		if url:
			line,url,dummy = url[0]
			url = url.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭䝅"),l11lll_l1_ (u"ࠫࠬ䝆"))
			line = line.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䝇"),l11lll_l1_ (u"࠭ࠧ䝈"))
		else:
			l11ll11l111l_l1_.append({l11lll_l1_ (u"ࠧ࡭࡫ࡱࡩࠬ䝉"):line})
			continue
		l11lll1lll1l_l1_,context,group,title,type,is_vod_url = {},l11lll_l1_ (u"ࠨࠩ䝊"),l11lll_l1_ (u"ࠩࠪ䝋"),l11lll_l1_ (u"ࠪࠫ䝌"),l11lll_l1_ (u"ࠫࠬ䝍"),False
		try:
			line,title = line.rsplit(l11lll_l1_ (u"ࠬࠨࠬࠨ䝎"),1)
			line = line+l11lll_l1_ (u"࠭ࠢࠨ䝏")
		except:
			try: line,title = line.rsplit(l11lll_l1_ (u"ࠧ࠲࠮ࠪ䝐"),1)
			except: title = l11lll_l1_ (u"ࠨࠩ䝑")
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭䝒")] = url
		params = re.findall(l11lll_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䝓"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11lll_l1_ (u"ࠫࠧ࠭䝔"),l11lll_l1_ (u"ࠬ࠭䝕")).strip(l11lll_l1_ (u"࠭ࠠࠨ䝖"))
			l11lll1lll1l_l1_[key] = value.strip(l11lll_l1_ (u"ࠧࠡࠩ䝗"))
		keys = list(l11lll1lll1l_l1_.keys())
		if not title:
			if l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭䝘") in keys and l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䝙")]: title = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ䝚")]
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䝛")] = title.strip(l11lll_l1_ (u"ࠬࠦࠧ䝜")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ䝝"),l11lll_l1_ (u"ࠧࠡࠩ䝞")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ䝟"),l11lll_l1_ (u"ࠩࠣࠫ䝠"))
		if l11lll_l1_ (u"ࠪࡰࡴ࡭࡯ࠨ䝡") in keys:
			l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫ࡮ࡳࡧࠨ䝢")] = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠬࡲ࡯ࡨࡱࠪ䝣")]
			del l11lll1lll1l_l1_[l11lll_l1_ (u"࠭࡬ࡰࡩࡲࠫ䝤")]
		else: l11lll1lll1l_l1_[l11lll_l1_ (u"ࠧࡪ࡯ࡪࠫ䝥")] = l11lll_l1_ (u"ࠨࠩ䝦")
		if l11lll_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ䝧") in keys and l11lll1lll1l_l1_[l11lll_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࠩ䝨")]: group = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪ䝩")]
		if any(value in url.lower() for value in vod_types):
			is_vod_url = True if l11lll_l1_ (u"ࠬࡳ࠳ࡶࠩ䝪") not in url else False
		if is_vod_url or l11lll_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ䝫") in group or l11lll_l1_ (u"ࠧࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ䝬") in group:
			type = l11lll_l1_ (u"ࠨࡘࡒࡈࠬ䝭")
			if l11lll_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭䝮") in group: type = type+l11lll_l1_ (u"ࠪࡣࡘࡋࡒࡊࡇࡖࠫ䝯")
			elif l11lll_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ䝰") in group: type = type+l11lll_l1_ (u"ࠬࡥࡍࡐࡘࡌࡉࡘ࠭䝱")
			else: type = type+l11lll_l1_ (u"࠭࡟ࡖࡐࡎࡒࡔ࡝ࡎࠨ䝲")
			group = group.replace(l11lll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䝳"),l11lll_l1_ (u"ࠨࠩ䝴")).replace(l11lll_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭䝵"),l11lll_l1_ (u"ࠪࠫ䝶"))
		else:
			type = l11lll_l1_ (u"ࠫࡑࡏࡖࡆࠩ䝷")
			if title in l11lllll1ll1_l1_: context = context+l11lll_l1_ (u"ࠬࡥࡅࡑࡉࠪ䝸")
			if title in l11lll11l1ll_l1_: context = context+l11lll_l1_ (u"࠭࡟ࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䝹")
			if not group: type = type+l11lll_l1_ (u"ࠧࡠࡗࡑࡏࡓࡕࡗࡏࠩ䝺")
			else: type = type+context
		group = group.strip(l11lll_l1_ (u"ࠨࠢࠪ䝻")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ䝼"),l11lll_l1_ (u"ࠪࠤࠬ䝽")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ䝾"),l11lll_l1_ (u"ࠬࠦࠧ䝿"))
		if l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬ䞀") in type: group = l11lll_l1_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡒࡉࡗࡇࡢࡣࠦࠧࠧ䞁")
		elif l11lll_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭䞂") in type: group = l11lll_l1_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡗࡑࡇࡣࡤࠧࠡࠨ䞃")
		elif l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙ࠧ䞄") in type:
			l11lllll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࡟ࡘࡹ࡝࡝ࡦ࠮ࠤ࠰ࡡࡅࡦ࡟࡟ࡨ࠰࠭䞅"),l11lll1lll1l_l1_[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䞆")],re.DOTALL)
			if l11lllll11l1_l1_: l11lllll11l1_l1_ = l11lllll11l1_l1_[0]
			else: l11lllll11l1_l1_ = l11lll_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡘࡋࡒࡊࡇࡖࡣࡤࠧࠡࠨ䞇")
			group = group+l11lll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䞈")+l11lllll11l1_l1_
		if l11lll_l1_ (u"ࠨ࡫ࡧࠫ䞉") in keys: del l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩ࡬ࡨࠬ䞊")]
		if l11lll_l1_ (u"ࠪࡍࡉ࠭䞋") in keys: del l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫࡎࡊࠧ䞌")]
		if l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䞍") in keys: del l11lll1lll1l_l1_[l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䞎")]
		title = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䞏")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l1ll111l1l11_l1_,title = SPLIT_NAME(title)
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭䞐")] = type
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䞑")] = context
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࠩ䞒")] = group.upper()
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ䞓")] = title.upper()
		l11lll1lll1l_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䞔")] = l1ll111l1l11_l1_.upper()
		l11lll1lll1l_l1_[l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䞕")] = language.upper()
		l1ll111l1111_l1_.append(l11lll1lll1l_l1_)
		l1ll111ll111_l1_ += 1
	return l1ll111l1111_l1_,l1ll111ll111_l1_,l11ll11l111l_l1_
def CLEAN_NAME(title):
	title = title.replace(l11lll_l1_ (u"ࠧࠡࠢࠪ䞖"),l11lll_l1_ (u"ࠨࠢࠪ䞗")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ䞘"),l11lll_l1_ (u"ࠪࠤࠬ䞙")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ䞚"),l11lll_l1_ (u"ࠬࠦࠧ䞛"))
	title = title.replace(l11lll_l1_ (u"࠭ࡼࡽࠩ䞜"),l11lll_l1_ (u"ࠧࡽࠩ䞝")).replace(l11lll_l1_ (u"ࠨࡡࡢࡣࠬ䞞"),l11lll_l1_ (u"ࠩ࠽ࠫ䞟")).replace(l11lll_l1_ (u"ࠪ࠱࠲࠭䞠"),l11lll_l1_ (u"ࠫ࠲࠭䞡"))
	title = title.replace(l11lll_l1_ (u"ࠬࡡ࡛ࠨ䞢"),l11lll_l1_ (u"࡛࠭ࠨ䞣")).replace(l11lll_l1_ (u"ࠧ࡞࡟ࠪ䞤"),l11lll_l1_ (u"ࠨ࡟ࠪ䞥"))
	title = title.replace(l11lll_l1_ (u"ࠩࠫࠬࠬ䞦"),l11lll_l1_ (u"ࠪࠬࠬ䞧")).replace(l11lll_l1_ (u"ࠫ࠮࠯ࠧ䞨"),l11lll_l1_ (u"ࠬ࠯ࠧ䞩"))
	title = title.replace(l11lll_l1_ (u"࠭࠼࠽ࠩ䞪"),l11lll_l1_ (u"ࠧ࠽ࠩ䞫")).replace(l11lll_l1_ (u"ࠨࡀࡁࠫ䞬"),l11lll_l1_ (u"ࠩࡁࠫ䞭"))
	title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ䞮"))
	return title
def CREATE_GROUPED_STREAMS(l11ll1lll111_l1_,l11l1ll11l_l1_,l111ll1l_l1_):
	l11lll11ll11_l1_ = {}
	for l11lll1l1_l1_ in l11lll11111l_l1_: l11lll11ll11_l1_[l11lll1l1_l1_+l11lll_l1_ (u"ࠫࡤ࠭䞯")+l111ll1l_l1_] = []
	length = len(l11ll1lll111_l1_)
	l1l1l1ll1l_l1_ = str(length)
	l1ll111ll111_l1_ = 0
	l11ll11l111l_l1_ = []
	for l11lll1lll1l_l1_ in l11ll1lll111_l1_:
		if l1ll111ll111_l1_%873==0:
			PROGRESS_UPDATE(l11l1ll11l_l1_,50+int(5*l1ll111ll111_l1_/length),l11lll_l1_ (u"ࠬะี็์ไࠤฬ๊แ๋ัํ์์อสࠡษ็฾๏ืࠠๆำอฬฮ࠭䞰"),l11lll_l1_ (u"࠭วๅใํำ๏๎ࠠาไ่࠾࠲࠭䞱"),str(l1ll111ll111_l1_)+l11lll_l1_ (u"ࠧࠡ࠱ࠣࠫ䞲")+l1l1l1ll1l_l1_)
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return None,None
		group,context,title,url,l1llll_l1_ = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ䞳")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䞴")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䞵")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ䞶")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠬ࡯࡭ࡨࠩ䞷")]
		l1ll111l1l11_l1_,language,l11lll1l1_l1_ = l11lll1lll1l_l1_[l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ䞸")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䞹")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭䞺")]
		l11llll1ll11_l1_ = (group,context,title,url,l1llll_l1_)
		l1ll11lllll_l1_ = False
		if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䞻") in l11lll1l1_l1_:
			if l11lll_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ䞼") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ䞽")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			elif l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ䞾") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭䞿")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			else: l1ll11lllll_l1_ = True
			l11lll11ll11_l1_[l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䟀")+l111ll1l_l1_].append(l11llll1ll11_l1_)
		elif l11lll_l1_ (u"ࠨࡘࡒࡈࠬ䟁") in l11lll1l1_l1_:
			if l11lll_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䟂") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ䟃")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			elif l11lll_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫ䟄") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ䟅")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			elif l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭䟆") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭䟇")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			else: l1ll11lllll_l1_ = True
			l11lll11ll11_l1_[l11lll_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ䟈")+l111ll1l_l1_].append(l11llll1ll11_l1_)
		else: l1ll11lllll_l1_ = True
		if l1ll11lllll_l1_: l11ll11l111l_l1_.append(l11lll1lll1l_l1_)
		l1ll111ll111_l1_ += 1
	l11lll111l1l_l1_ = sorted(l11ll1lll111_l1_,reverse=False,key=lambda key: key[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䟉")].lower())
	del l11ll1lll111_l1_
	l1l1l1ll1l_l1_ = str(length)
	l1ll111ll111_l1_ = 0
	for l11lll1lll1l_l1_ in l11lll111l1l_l1_:
		l1ll111ll111_l1_ += 1
		if l1ll111ll111_l1_%873==0:
			PROGRESS_UPDATE(l11l1ll11l_l1_,55+int(5*l1ll111ll111_l1_/length),l11lll_l1_ (u"ࠪฮฺ์๊โࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ิฮอฯࠧ䟊"),l11lll_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ䟋"),str(l1ll111ll111_l1_)+l11lll_l1_ (u"ࠬࠦ࠯ࠡࠩ䟌")+l1l1l1ll1l_l1_)
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return None,None
		l11lll1l1_l1_ = l11lll1lll1l_l1_[l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ䟍")]
		group,context,title,url,l1llll_l1_ = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭䟎")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ䟏")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䟐")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ䟑")],l11lll1lll1l_l1_[l11lll_l1_ (u"ࠫ࡮ࡳࡧࠨ䟒")]
		l1ll111l1l11_l1_,language = l11lll1lll1l_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䟓")],l11lll1lll1l_l1_[l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ䟔")]
		l11llll1ll1l_l1_ = (group,context+l11lll_l1_ (u"ࠧࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ䟕"),title,url,l1llll_l1_)
		l11llll1ll11_l1_ = (group,context,title,url,l1llll_l1_)
		l11llll1l1ll_l1_ = (l1ll111l1l11_l1_,context,title,url,l1llll_l1_)
		l11llll1l1l1_l1_ = (language,context,title,url,l1llll_l1_)
		if l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭䟖") in l11lll1l1_l1_:
			if l11lll_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ䟗") in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䟘")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			else: l11lll11ll11_l1_[l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䟙")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			if l11lll_l1_ (u"ࠬࡋࡐࡈࠩ䟚")		in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡊࡖࡇࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䟛")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			if l11lll_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ䟜")	in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡁࡓࡅࡋࡍ࡛ࡋࡄࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ䟝")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			if l11lll_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ䟞")	in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䟟")+l111ll1l_l1_].append(l11llll1ll1l_l1_)
			l11lll11ll11_l1_[l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭䟠")+l111ll1l_l1_].append(l11llll1l1ll_l1_)
			l11lll11ll11_l1_[l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䟡")+l111ll1l_l1_].append(l11llll1l1l1_l1_)
		elif l11lll_l1_ (u"࠭ࡖࡐࡆࠪ䟢") in l11lll1l1_l1_:
			if   l11lll_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ䟣")	in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ䟤")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			elif l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏࡅࡔࠩ䟥")	in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䟦")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			elif l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖࠫ䟧")	in l11lll1l1_l1_: l11lll11ll11_l1_[l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ䟨")+l111ll1l_l1_].append(l11llll1ll11_l1_)
			l11lll11ll11_l1_[l11lll_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉࡥࠧ䟩")+l111ll1l_l1_].append(l11llll1l1ll_l1_)
			l11lll11ll11_l1_[l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ䟪")+l111ll1l_l1_].append(l11llll1l1l1_l1_)
	return l11lll11ll11_l1_,l11ll11l111l_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1l1llll1l1_l1_,sep = l11lll_l1_ (u"ࠨࠩ䟫"),l11lll_l1_ (u"ࠩࠪ䟬")
	l1lll1lll_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11lll_l1_ (u"ࠪࠬࠬ䟭"): sep = l11lll_l1_ (u"ࠫ࠮࠭䟮")
	elif first==l11lll_l1_ (u"ࠬࡡࠧ䟯"): sep = l11lll_l1_ (u"࠭࡝ࠨ䟰")
	elif first==l11lll_l1_ (u"ࠧ࠽ࠩ䟱"): sep = l11lll_l1_ (u"ࠨࡀࠪ䟲")
	elif first==l11lll_l1_ (u"ࠩࡿࠫ䟳"): sep = l11lll_l1_ (u"ࠪࢀࠬ䟴")
	if sep and (sep in rest):
		l1l1l1ll111l_l1_,l1l1l1ll1111_l1_ = rest.split(sep,1)
		l1l1llll1l1_l1_ = l1l1l1ll111l_l1_
		l1lll1lll_l1_ = first+l1l1l1ll111l_l1_+sep+l11lll_l1_ (u"ࠫࠥ࠭䟵")+l1l1l1ll1111_l1_
	elif title.count(l11lll_l1_ (u"ࠬࢂࠧ䟶"))>=2:
		l1l1l1ll111l_l1_,l1l1l1ll1111_l1_ = title.split(l11lll_l1_ (u"࠭ࡼࠨ䟷"),1)
		l1l1llll1l1_l1_ = l1l1l1ll111l_l1_
		l1lll1lll_l1_ = l1l1l1ll111l_l1_+l11lll_l1_ (u"ࠧࠡࡾࠪ䟸")+l1l1l1ll1111_l1_
	else:
		sep = re.findall(l11lll_l1_ (u"ࠨࡠ࡟ࡻࢀ࠸ࡽࠩࠢࡿࡠ࠿ࢂ࡜࠮ࡾ࡟ࢀࢁࡢ࡝ࡽ࡞ࠬࢀࡡࠩࡼ࡝࠰ࡿࡠ࠱ࢂ࡜ࠥࡾ࡟ࠫࢁࡢࠡࡽ࡞ࡃࢀࡡࠫࡼ࡝ࠨࡿࡠ࠯ࢂ࡜࡟ࠫࠪ䟹"),title,re.DOTALL)
		if not sep: sep = re.findall(l11lll_l1_ (u"ࠩࡡࡠࡼࢁ࠳ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ䟺"),title,re.DOTALL)
		if not sep: sep = re.findall(l11lll_l1_ (u"ࠪࡢࡡࡽࡻ࠵ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬ䟻"),title,re.DOTALL)
		if sep:
			l1l1l1ll111l_l1_,l1l1l1ll1111_l1_ = title.split(sep[0],1)
			l1l1llll1l1_l1_ = l1l1l1ll111l_l1_
			l1lll1lll_l1_ = l1l1l1ll111l_l1_+l11lll_l1_ (u"ࠫࠥ࠭䟼")+sep[0]+l11lll_l1_ (u"ࠬࠦࠧ䟽")+l1l1l1ll1111_l1_
	l1lll1lll_l1_ = l1lll1lll_l1_.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠪ䟾"),l11lll_l1_ (u"ࠧࠡࠩ䟿")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ䠀"),l11lll_l1_ (u"ࠩࠣࠫ䠁"))
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.replace(l11lll_l1_ (u"ࠪࠤࠥ࠭䠂"),l11lll_l1_ (u"ࠫࠥ࠭䠃"))
	if not l1l1llll1l1_l1_: l1l1llll1l1_l1_ = l11lll_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ䠄")
	l1l1llll1l1_l1_ = l1l1llll1l1_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ䠅"))
	l1lll1lll_l1_ = l1lll1lll_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩ䠆"))
	return l1l1llll1l1_l1_,l1lll1lll_l1_
def GET_HEADERS(l11lllllll1l_l1_):
	headers = {}
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ䠇")+l11lllllll1l_l1_)
	if l111llll1l_l1_: headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䠈")] = l111llll1l_l1_
	l11l11l11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡶࡪ࡬ࡥࡳࡧࡵࡣࠬ䠉")+l11lllllll1l_l1_)
	if l11l11l11l_l1_: headers[l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䠊")] = l11l11l11l_l1_
	return headers
def CREATE_STREAMS(l11lllllll1l_l1_,l111ll1l_l1_):
	global l11l1ll11l_l1_,l11lll11ll11_l1_,l11ll1111l11_l1_,l1l1111111l1_l1_,l11llllll1ll_l1_,groups,l11ll111llll_l1_,l11ll1l1ll1l_l1_,l11llllll1l1_l1_
	l11ll1lllll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ䠋")+l11lllllll1l_l1_+l11lll_l1_ (u"࠭࡟ࠨ䠌")+l111ll1l_l1_)
	#l1l11111l11l_l1_,l11ll1lllll1_l1_,server,username,password = GET_URL(l11lllllll1l_l1_)
	#if not username: return
	l111llll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ䠍")+l11lllllll1l_l1_)
	headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䠎"):l111llll1l_l1_}
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䠏"),l11lll_l1_ (u"ࠪࠫ䠐"),l11lll_l1_ (u"ࠫࠬ䠑"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䠒"),l11lll_l1_ (u"ู࠭ๆๆํอࠥาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอ่ࠥฯࠡฬะฮฬาฺࠠัฬࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ้ฮࠠศๆ่่ๆอสࠡษ็ฦ๋ࠦฟࠨ䠓"))
	#if l1ll11l111_l1_!=1: return
	l11lll11ll1l_l1_ = l1l11llll1l1_l1_.replace(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ䠔"),l11lll_l1_ (u"ࠨࡡࠪ䠕")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠩࡢࠫ䠖")+l111ll1l_l1_)
	if 1:
		succeeded,l11ll1l111ll_l1_,l1l11111111l_l1_ = True,l11lll_l1_ (u"ࠪࠫ䠗"),l11lll_l1_ (u"ࠫࠬ䠘")
		if not succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䠙"),l11lll_l1_ (u"࠭ࠧ䠚"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䠛"),l11lll_l1_ (u"ࠨใื่ࠥฮำฮส้้ࠣ็วหࠢใࡑ࠸࡛ࠠ࠯ࠢฦัฯ๋วๅࠢิหอ฽ࠠแࡏ࠶࡙ࠥเ๊าุࠢั๏ำࠠฤ๊ࠣๆิ๐ๅࠡล๋ࠤ้อ๋ࠠ฻่่ࠥ࠴࠮ࠡ฻็้ฬࠦร็๊ࠢิ์ࠦวๅะา้ฮࠦสฮฬสะࠥอิหำส็๋ࠥฯโ๊฼ࠤํ฻อ๋ฯࠣ์๏าศࠡล้ࠤฯ฼๊โࠢิหอ฽ࠠศๆสุฯืวไࠢห๊ๆูใࠡๆ็ฬึ์วๆฮࠣฬฬูสฯัส้่ࠥวว็ฬࠤๅࡓ࠳ࡖࠢส่๊๎ฬ้ัฬࠤอํะศࠢส่อืๆศ็ฯࠫ䠜"))
			if not l11ll1lllll1_l1_: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䠝"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡎࡰࠢࡐ࠷࡚ࠦࡕࡓࡎࠣࡪࡴࡻ࡮ࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࡵࠪ䠞"))
			else: LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䠟"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡍ࠴ࡗࠣࡪ࡮ࡲࡥࡴࠩ䠠"))
			return
		l1l11111l1l1_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11ll1lllll1_l1_,headers,True)
		if not l1l11111l1l1_l1_: return
		open(l11lll11ll1l_l1_,l11lll_l1_ (u"࠭ࡷࡣࠩ䠡")).write(l1l11111l1l1_l1_)
	else: l1l11111l1l1_l1_ = open(l11lll11ll1l_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ䠢")).read()
	if kodi_version>18.99 and l1l11111l1l1_l1_: l1l11111l1l1_l1_ = l1l11111l1l1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䠣"))
	#l1l11111l1l1_l1_ = l1l11111l1l1_l1_[33000111:77000111]
	l11l1ll11l_l1_ = DIALOG_PROGRESS()
	l11l1ll11l_l1_.create(l11lll_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠩ䠤"),l11lll_l1_ (u"ࠪࠫ䠥"))
	PROGRESS_UPDATE(l11l1ll11l_l1_,15,l11lll_l1_ (u"ࠫฯ์ุ๋ใࠣห้๋ไโࠢส่ึฬ๊ิ์ࠪ䠦"),l11lll_l1_ (u"ࠬ࠭䠧"))
	l1l11111l1l1_l1_ = l1l11111l1l1_l1_.replace(l11lll_l1_ (u"࠭ࠢࡵࡸࡪ࠱ࠬ䠨"),l11lll_l1_ (u"ࠧࠣࠢࡷࡺ࡬࠳ࠧ䠩"))
	l1l11111l1l1_l1_ = l1l11111l1l1_l1_.replace(l11lll_l1_ (u"ࠨ๐ࠪ䠪"),l11lll_l1_ (u"ࠩࠪ䠫")).replace(l11lll_l1_ (u"ࠪ๏ࠬ䠬"),l11lll_l1_ (u"ࠫࠬ䠭")).replace(l11lll_l1_ (u"ࠬ๕ࠧ䠮"),l11lll_l1_ (u"࠭ࠧ䠯")).replace(l11lll_l1_ (u"ࠧํࠩ䠰"),l11lll_l1_ (u"ࠨࠩ䠱"))
	l1l11111l1l1_l1_ = l1l11111l1l1_l1_.replace(l11lll_l1_ (u"ࠩ๔ࠫ䠲"),l11lll_l1_ (u"ࠪࠫ䠳")).replace(l11lll_l1_ (u"ࠫ๕࠭䠴"),l11lll_l1_ (u"ࠬ࠭䠵")).replace(l11lll_l1_ (u"࠭ํࠨ䠶"),l11lll_l1_ (u"ࠧࠨ䠷")).replace(l11lll_l1_ (u"ࠨ๔ࠪ䠸"),l11lll_l1_ (u"ࠩࠪ䠹"))
	l1l11111l1l1_l1_ = l1l11111l1l1_l1_.replace(l11lll_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠯ࡷ࡭ࡹࡲࡥ࠾ࠩ䠺"),l11lll_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡀࠫ䠻")).replace(l11lll_l1_ (u"ࠬࡺࡶࡨ࠯ࠪ䠼"),l11lll_l1_ (u"࠭ࠧ䠽"))
	l11lll11l1ll_l1_,l11lllll1ll1_l1_ = [],[]
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡕࡘࡏࡈࡔࡈࡗࡘࡥࡕࡑࡆࡄࡘࡊ࠮ࡰࡅ࡫ࡤࡰࡴ࡭ࠬ࠳࠲࠯ࠫั๊ศࠡษ็้้็วหࠢส่ะอๆ้์ฬࠫ࠱࠭วๅ็็ๅࠥืโๆ࠼࠰ࠫ࠱࠭࠱ࠡ࠱ࠣ࠷ࠬ࠯ࠊࠊ࡫ࡩࠤࡵࡊࡩࡢ࡮ࡲ࡫࠳࡯ࡳࡤࡣࡱࡧࡪࡲࡥࡥࠪࠬ࠾ࠏࠏࠉࡱࡆ࡬ࡥࡱࡵࡧ࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤ࡚ࡘࡌࡠࡲ࡯ࡥࡾ࡫ࡲࠬࠩࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟ࡴࡧࡵ࡭ࡪࡹ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠫࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡍ࠴ࡗ࠰ࡇࡗࡋࡁࡕࡇࡢࡗ࡙ࡘࡅࡂࡏࡖ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡪࡷࡱࡱ࠯ࠊࠊࡵࡨࡶ࡮࡫ࡳࡠࡩࡵࡳࡺࡶࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡢࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡥࡧ࡯ࠤ࡭ࡺ࡭࡭ࠌࠌࡪࡴࡸࠠࡨࡴࡲࡹࡵࠦࡩ࡯ࠢࡶࡩࡷ࡯ࡥࡴࡡࡪࡶࡴࡻࡰࡴ࠼ࠍࠍࠎ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡂ࠱࠺࠼ࠣ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉ࡮࠵ࡸࡣࡹ࡫ࡸࡵࠢࡀࠤࡲ࠹ࡵࡠࡶࡨࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡩࡵࡳࡺࡶ࠽ࠣࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠲ࠧࡨࡴࡲࡹࡵࡃࠢࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧࠪࠌࠌࡨࡪࡲࠠࡴࡧࡵ࡭ࡪࡹ࡟ࡨࡴࡲࡹࡵࡹࠊࠊࡒࡕࡓࡌࡘࡅࡔࡕࡢ࡙ࡕࡊࡁࡕࡇࠫࡴࡉ࡯ࡡ࡭ࡱࡪ࠰࠷࠻ࠬࠨฮ็ฬࠥอไๆๆไหฯࠦวๅอส๊ํ๐ษࠨ࠮ࠪห้๋ไโࠢิๆ๊ࡀ࠭ࠨ࠮ࠪ࠶ࠥ࠵ࠠ࠴ࠩࠬࠎࠎ࡯ࡦࠡࡲࡇ࡭ࡦࡲ࡯ࡨ࠰࡬ࡷࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠮ࠩ࠻ࠌࠌࠍࡵࡊࡩࡢ࡮ࡲ࡫࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࡸࡶࡱࠦ࠽ࠡࡗࡕࡐࡤࡶ࡬ࡢࡻࡨࡶ࠰࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡻࡵࡤࡠࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠬࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡎ࠵ࡘ࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩࠋࠋࡹࡳࡩࡥࡧࡳࡱࡸࡴࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡪࡥ࡭ࠢ࡫ࡸࡲࡲࠊࠊࡨࡲࡶࠥ࡭ࡲࡰࡷࡳࠤ࡮ࡴࠠࡷࡱࡧࡣ࡬ࡸ࡯ࡶࡲࡶ࠾ࠏࠏࠉࡨࡴࡲࡹࡵࠦ࠽ࠡࡩࡵࡳࡺࡶ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟࠳ࠬ࠲ࠧ࠰ࠩࠬࠎࠎࠏࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠽࠳࠼࠾ࠥ࡭ࡲࡰࡷࡳࠤࡂࠦࡧࡳࡱࡸࡴ࠳ࡪࡥࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࠋࡰ࠷ࡺࡥࡴࡦࡺࡷࠤࡂࠦ࡭࠴ࡷࡢࡸࡪࡾࡴ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࡫ࡷࡵࡵࡱ࠿ࠥࠫ࠰࡭ࡲࡰࡷࡳ࠯ࠬࠨࠧ࠭ࠩࡪࡶࡴࡻࡰ࠾ࠤࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭ࠫࡨࡴࡲࡹࡵ࠱ࠧࠣࠩࠬࠎࠎࡪࡥ࡭ࠢࡹࡳࡩࡥࡧࡳࡱࡸࡴࡸࠐࠉࡑࡔࡒࡋࡗࡋࡓࡔࡡࡘࡔࡉࡇࡔࡆࠪࡳࡈ࡮ࡧ࡬ࡰࡩ࠯࠷࠵࠲ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯࠧ࠭ࠩส่๊๊แࠡำๅ้࠿࠳ࠧ࠭ࠩ࠶ࠤ࠴ࠦ࠳ࠨࠫࠍࠍ࡮࡬ࠠࡱࡆ࡬ࡥࡱࡵࡧ࠯࡫ࡶࡧࡦࡴࡣࡦ࡮ࡨࡨ࠭࠯࠺ࠋࠋࠌࡴࡉ࡯ࡡ࡭ࡱࡪ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠉࡳࡧࡷࡹࡷࡴࠊࠊࡷࡵࡰࠥࡃࠠࡖࡔࡏࡣࡵࡲࡡࡺࡧࡵ࠯ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡢࡰ࡮ࡼࡥࡠࡵࡷࡶࡪࡧ࡭ࡴࠩࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡒ࠹ࡕ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠶ࡶࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸࡻࡥࡡࡳࡥ࡫࡭ࡻ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢࡱࡥࡲ࡫ࠬࡢࡴࡦ࡬࡮ࡼࡥࡥࠢ࡬ࡲࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨ࠿ࠐࠉࠊ࡫ࡩࠤࡦࡸࡣࡩ࡫ࡹࡩࡩࡃ࠽ࠨ࠳ࠪ࠾ࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨࡤࡩࡨࡢࡰࡱࡩࡱࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡯ࡣࡰࡩ࠮ࠐࠉࡥࡧ࡯ࠤࡱ࡯ࡶࡦࡡࡤࡶࡨ࡮ࡩࡷࡧࡧࠎࠎࡲࡩࡷࡧࡢࡩࡵ࡭ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡪࡶࡧࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣࡲࡦࡳࡥ࠭ࡧࡳ࡫ࠥ࡯࡮ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩ࠽ࠎࠎࠏࡩࡧࠢࡨࡴ࡬ࠧ࠽ࠨࡰࡸࡰࡱ࠭࠺ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡡ࡮ࡧࠬࠎࠎࡪࡥ࡭ࠢ࡯࡭ࡻ࡫࡟ࡦࡲࡪࠎࠎࠨࠢࠣ䠾")
	l1l11111l1l1_l1_ = l1l11111l1l1_l1_.replace(l11lll_l1_ (u"ࠨ࡞ࡵࠫ䠿"),l11lll_l1_ (u"ࠩ࡟ࡲࠬ䡀"))
	lines = re.findall(l11lll_l1_ (u"ࠪࡒࡋࡀࠨ࠯࠭ࡂ࠭ࠨࡋࡘࡕࡋࠪ䡁"),l1l11111l1l1_l1_+l11lll_l1_ (u"ࠫࡡࡴࠣࡆ࡚ࡗࡍࡓࡌ࠺ࠨ䡂"),re.DOTALL)
	if not lines:
		LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䡃"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡳࡱࡪࡥࡳ࠼ࠪ䡄")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠧࠡࠢࡖࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠬ䡅")+l111ll1l_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡓࡵࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࡷࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࠩ䡆"))
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䡇"),l11lll_l1_ (u"ࠪࠫ䡈"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䡉"),l11lll_l1_ (u"ࠬืวษูࠣไࡒ࠹ࡕࠡษ็ิ๏ࠦร็ฬࠣว฻็ส่ࠢ็หࠥะ่อัࠣๅ๏ํࠠโ์า๎ํํวหࠢ࠱࠲ࠥออห็ส่ࠥืวษูࠣไࡒ࠹ࡕࠡ฼ํีࠥ฻อ๋ฯࠪ䡊")+l11lll_l1_ (u"࠭࡜࡯ࠩ䡋")+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䡌")+l11lll_l1_ (u"ࠨ็ฯ่ิࠦัใ็ࠣࠫ䡍")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠠࠡำสฬ฼ࠦัใ็ࠣࠫ䡎")+l111ll1l_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䡏"))
		l11l1ll11l_l1_.close()
		return
	l11ll11l1111_l1_ = []
	for line in lines:
		l11ll1ll111l_l1_ = line.lower()
		if l11lll_l1_ (u"ࠫࡦࡪࡵ࡭ࡶࠪ䡐") in l11ll1ll111l_l1_: continue
		if l11lll_l1_ (u"ࠬࡾࡸࡹࠩ䡑") in l11ll1ll111l_l1_: continue
		l11ll11l1111_l1_.append(line)
	lines = l11ll11l1111_l1_
	del l11ll11l1111_l1_
	if 1 and l11lll_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡴࡸࡧࠨ䡒") in l11ll1lllll1_l1_:
		l11ll11l1111_l1_,l11ll111lll1_l1_ = [],[]
		for line in lines:
			groups = re.findall(l11lll_l1_ (u"ࠧࡨࡴࡲࡹࡵࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䡓"),line,re.DOTALL)
			if groups:
				groups = groups[0]
				l11ll1lll11l_l1_ = groups.split(l11lll_l1_ (u"ࠨ࠽ࠪ䡔"))
				for group in l11ll1lll11l_l1_:
					group = l11lll_l1_ (u"ࠩ࠱ࠫ䡕")+group
					l11111llll1_l1_ = line.replace(l11lll_l1_ (u"ࠪ࡫ࡷࡵࡵࡱ࠿ࠥࠫ䡖")+groups+l11lll_l1_ (u"ࠫࠧ࠭䡗"),l11lll_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡁࠧ࠭䡘")+group+l11lll_l1_ (u"࠭ࠢࠨ䡙"))
					l11ll11l1111_l1_.append(l11111llll1_l1_)
			else: l11ll11l1111_l1_.append(line)
		for line in l11ll11l1111_l1_:
			l1ll1ll1l_l1_ = False
			l11111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䡚"),line,re.DOTALL)
			groups = re.findall(l11lll_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䡛"),line,re.DOTALL)
			if l11111ll1_l1_ and groups:
				l11111ll1_l1_ = l11111ll1_l1_[0]
				groups = groups[0]
				if l11lll_l1_ (u"ࠩ࠱ࠫ䡜") in l11111ll1_l1_:
					l11lll1ll1_l1_,l11llll1lll1_l1_ = l11111ll1_l1_.rsplit(l11lll_l1_ (u"ࠪ࠲ࠬ䡝"),1)
					try:
						l11llll1lll1_l1_ = l1l111111111_l1_[l11llll1lll1_l1_.upper()]
						line2 = line.replace(l11lll_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡀࠦࠬ䡞")+groups+l11lll_l1_ (u"ࠬࠨࠧ䡟"),l11lll_l1_ (u"࠭ࡧࡳࡱࡸࡴࡂࠨࠧ䡠")+l11llll1lll1_l1_+l11lll_l1_ (u"ࠧࠣࠩ䡡"))
						l11ll111lll1_l1_.append(line2)
						line2 = line.replace(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭䡢")+l11111ll1_l1_+l11lll_l1_ (u"ࠩࠥࠫ䡣"),l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ䡤")+l11lll1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠭䡥"))
						l11ll111lll1_l1_.append(line2)
						l1ll1ll1l_l1_ = True
					except: pass
			if not l1ll1ll1l_l1_: l11ll111lll1_l1_.append(line)
		lines = l11ll111lll1_l1_
		del l11ll11l1111_l1_,l11ll111lll1_l1_
	l11ll11ll1_l1_ = 1024*1024
	l1l111l11l1l_l1_ = 1+len(l1l11111l1l1_l1_)//l11ll11ll1_l1_//10
	del l1l11111l1l1_l1_
	l11ll1111ll1_l1_ = len(lines)
	l11ll111lll1_l1_ = SPLIT_BIGLIST(lines,l1l111l11l1l_l1_)
	del lines
	for l11ll111l1_l1_ in range(l1l111l11l1l_l1_):
		PROGRESS_UPDATE(l11l1ll11l_l1_,35+int(5*l11ll111l1_l1_/l1l111l11l1l_l1_),l11lll_l1_ (u"ࠬะโุ์฼ࠤฬ๊ๅๅใࠣห้ืฦ๋ีํࠫ䡦"),l11lll_l1_ (u"࠭วๅฮีลࠥืโๆ࠼࠰ࠫ䡧"),str(l11ll111l1_l1_+1)+l11lll_l1_ (u"ࠧࠡ࠱ࠣࠫ䡨")+str(l1l111l11l1l_l1_))
		if l11l1ll11l_l1_.iscanceled():
			l11l1ll11l_l1_.close()
			return
		l11lll111l11_l1_ = str(l11ll111lll1_l1_[l11ll111l1_l1_])
		if kodi_version>18.99: l11lll111l11_l1_ = l11lll111l11_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䡩"))
		open(l11lll11ll1l_l1_+l11lll_l1_ (u"ࠩ࠱࠴࠵࠭䡪")+str(l11ll111l1_l1_),l11lll_l1_ (u"ࠪࡻࡧ࠭䡫")).write(l11lll111l11_l1_)
	del l11ll111lll1_l1_,l11lll111l11_l1_
	l11ll111l1l1_l1_,l11ll1lll111_l1_,l1ll111ll111_l1_ = [],[],0
	for l11ll111l1_l1_ in range(l1l111l11l1l_l1_):
		if l11l1ll11l_l1_.iscanceled():
			l11l1ll11l_l1_.close()
			return
		l11lll111l11_l1_ = open(l11lll11ll1l_l1_+l11lll_l1_ (u"ࠫ࠳࠶࠰ࠨ䡬")+str(l11ll111l1_l1_),l11lll_l1_ (u"ࠬࡸࡢࠨ䡭")).read()
		time.sleep(1)
		try: os.remove(l11lll11ll1l_l1_+l11lll_l1_ (u"࠭࠮࠱࠲ࠪ䡮")+str(l11ll111l1_l1_))
		except: pass
		if kodi_version>18.99: l11lll111l11_l1_ = l11lll111l11_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䡯"))
		lines = EVAL(l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䡰"),l11lll111l11_l1_)
		del l11lll111l11_l1_
		l1ll111l1111_l1_,l1ll111ll111_l1_,l11ll11l111l_l1_ = READ_ALL_LINES(lines,l11lllll1ll1_l1_,l11lll11l1ll_l1_,l11l1ll11l_l1_,l11ll1111ll1_l1_,l1ll111ll111_l1_,l11ll1lllll1_l1_)
		if l11l1ll11l_l1_.iscanceled():
			l11l1ll11l_l1_.close()
			return
		if not l1ll111l1111_l1_:
			l11l1ll11l_l1_.close()
			return
		l11ll1lll111_l1_ += l1ll111l1111_l1_
		l11ll111l1l1_l1_ += l11ll11l111l_l1_
	del lines,l1ll111l1111_l1_
	l11lll11ll11_l1_,l11ll11l111l_l1_ = CREATE_GROUPED_STREAMS(l11ll1lll111_l1_,l11l1ll11l_l1_,l111ll1l_l1_)
	if l11l1ll11l_l1_.iscanceled():
		l11l1ll11l_l1_.close()
		return
	l11ll111l1l1_l1_ += l11ll11l111l_l1_
	del l11ll1lll111_l1_,l11ll11l111l_l1_
	l1l1111111l1_l1_,l11llllll1ll_l1_,groups,l11ll111llll_l1_,l11ll1l1ll1l_l1_ = {},{},{},0,0
	l11ll1l11111_l1_ = list(l11lll11ll11_l1_.keys())
	l11llllll1l1_l1_ = len(l11ll1l11111_l1_)*3
	import threading
	if 1:
		threads = {}
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			threads[l11lll11l11l_l1_] = threading.Thread(target=CREATE_MENUS,args=(l11lll11l11l_l1_,))
			threads[l11lll11l11l_l1_].start()
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			threads[l11lll11l11l_l1_].join()
		if l11l1ll11l_l1_.iscanceled():
			l11l1ll11l_l1_.close()
			return
	else:
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			CREATE_MENUS(l11lll11l11l_l1_)
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return
	DELETE_FILES(l11lllllll1l_l1_,l111ll1l_l1_,False)
	l11ll1l11111_l1_ = list(l1l1111111l1_l1_.keys())
	l11ll1111l11_l1_ = 0
	if 1:
		threads = {}
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			threads[l11lll11l11l_l1_] = threading.Thread(target=SAVE_MENUS,args=(l11lllllll1l_l1_,l11lll11l11l_l1_))
			threads[l11lll11l11l_l1_].start()
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			threads[l11lll11l11l_l1_].join()
		if l11l1ll11l_l1_.iscanceled():
			l11l1ll11l_l1_.close()
			return
	else:
		for l11lll11l11l_l1_ in l11ll1l11111_l1_:
			SAVE_MENUS(l11lllllll1l_l1_,l11lll11l11l_l1_)
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return
	l11ll111l1_l1_ = 0
	l1l111111l11_l1_ = len(l11ll111l1l1_l1_)
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ䡱"))
	for stream in l11ll111l1l1_l1_:
		if l11ll111l1_l1_%27==0:
			PROGRESS_UPDATE(l11l1ll11l_l1_,95+int(5*l11ll111l1_l1_//l1l111111l11_l1_),l11lll_l1_ (u"ࠪฮำุ๊็ࠢส่๊ํๅๅหࠪ䡲"),l11lll_l1_ (u"ࠫฬ๊แ๋ัํ์ࠥืโๆ࠼࠰ࠫ䡳"),str(l11ll111l1_l1_)+l11lll_l1_ (u"ࠬࠦ࠯ࠡࠩ䡴")+str(l1l111111l11_l1_))
			if l11l1ll11l_l1_.iscanceled():
				l11l1ll11l_l1_.close()
				return
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊ࡟ࠨ䡵")+l111ll1l_l1_,str(stream),l11lll_l1_ (u"ࠧࠨ䡶"),PERMANENT_CACHE)
		l11ll111l1_l1_ += 1
	WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠨࡋࡊࡒࡔࡘࡅࡅࡡࠪ䡷")+l111ll1l_l1_,l11lll_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䡸"),str(l1l111111l11_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࡡࠪ䡹")+l111ll1l_l1_,l11lll_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ䡺"),l11lll_l1_ (u"ࠬ࠷ࠧ䡻"),PERMANENT_CACHE)
	#open(l1lll1l1llll_l1_,l11lll_l1_ (u"࠭ࡷࠨ䡼")).write(l11lll_l1_ (u"ࠧࠨ䡽"))
	l11l1ll11l_l1_.close()
	time.sleep(1)
	#l11ll1l1l11l_l1_ = COUNTS(l11lllllll1l_l1_,l111ll1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䡾"),l11lll_l1_ (u"ࠩࠪ䡿"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䢀"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ䢁")+l11lll_l1_ (u"ࠬะๅࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ䢂")+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ䢃")+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䢄")+l11ll1l1l11l_l1_)
	#xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䢅"))
	DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_)
	return
def CREATE_MENUS(l11lll11l11l_l1_):
	global l11l1ll11l_l1_,l11lll11ll11_l1_,l11ll1111l11_l1_,l1l1111111l1_l1_,l11llllll1ll_l1_,groups,l11ll111llll_l1_,l11ll1l1ll1l_l1_,l11llllll1l1_l1_
	l1l1111111l1_l1_[l11lll11l11l_l1_] = {}
	l11ll1l11ll1_l1_,l11lll1ll1l1_l1_ = {},[]
	l11ll111ll11_l1_ = len(l11lll11ll11_l1_[l11lll11l11l_l1_])
	l1l1111111l1_l1_[l11lll11l11l_l1_][l11lll_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䢆")] = l11ll111ll11_l1_
	if l11ll111ll11_l1_>0:
		l11llll11lll_l1_,l1l11111l111_l1_,l11ll1111111_l1_,l1l111111l1l_l1_,l11lll1l11l1_l1_ = zip(*l11lll11ll11_l1_[l11lll11l11l_l1_])
		del l1l11111l111_l1_,l11ll1111111_l1_,l1l111111l1l_l1_
		l11ll1lll11l_l1_ = list(set(l11llll11lll_l1_))
		for group in l11ll1lll11l_l1_:
			l11ll1l11ll1_l1_[group] = l11lll_l1_ (u"ࠪࠫ䢇")
			l1l1111111l1_l1_[l11lll11l11l_l1_][group] = []
		PROGRESS_UPDATE(l11l1ll11l_l1_,60+int(15*l11ll1l1ll1l_l1_//l11llllll1l1_l1_),l11lll_l1_ (u"ࠫฯ฻ๆ๋฻ࠣห้่่ศศ่ࠫ䢈"),l11lll_l1_ (u"ࠬอไอิฤࠤึ่ๅ࠻࠯ࠪ䢉"),str(l11ll1l1ll1l_l1_)+l11lll_l1_ (u"࠭ࠠ࠰ࠢࠪ䢊")+str(l11llllll1l1_l1_))
		if l11l1ll11l_l1_.iscanceled(): return
		l11ll1l1ll1l_l1_ += 1
		l11ll11lllll_l1_ = len(l11ll1lll11l_l1_)
		del l11ll1lll11l_l1_
		l11lll1ll1l1_l1_ = list(set(zip(l11llll11lll_l1_,l11lll1l11l1_l1_)))
		del l11llll11lll_l1_,l11lll1l11l1_l1_
		for group,l11l_l1_ in l11lll1ll1l1_l1_:
			if not l11ll1l11ll1_l1_[group] and l11l_l1_: l11ll1l11ll1_l1_[group] = l11l_l1_
		PROGRESS_UPDATE(l11l1ll11l_l1_,60+int(15*l11ll1l1ll1l_l1_//l11llllll1l1_l1_),l11lll_l1_ (u"ࠧหื้๎฾ࠦวๅไ๋หห๋ࠧ䢋"),l11lll_l1_ (u"ࠨษ็ะืวࠠาไ่࠾࠲࠭䢌"),str(l11ll1l1ll1l_l1_)+l11lll_l1_ (u"ࠩࠣ࠳ࠥ࠭䢍")+str(l11llllll1l1_l1_))
		if l11l1ll11l_l1_.iscanceled(): return
		l11ll1l1ll1l_l1_ += 1
		l11ll1ll11ll_l1_ = list(l11ll1l11ll1_l1_.keys())
		l11ll11lll1l_l1_ = list(l11ll1l11ll1_l1_.values())
		del l11ll1l11ll1_l1_
		l11lll1ll1l1_l1_ = list(zip(l11ll1ll11ll_l1_,l11ll11lll1l_l1_))
		del l11ll1ll11ll_l1_,l11ll11lll1l_l1_
		l11lll1ll1l1_l1_ = sorted(l11lll1ll1l1_l1_)
	else: l11ll1l1ll1l_l1_ += 2
	l1l1111111l1_l1_[l11lll11l11l_l1_][l11lll_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䢎")] = l11lll1ll1l1_l1_
	del l11lll1ll1l1_l1_
	for group,context,title,url,l1llll_l1_ in l11lll11ll11_l1_[l11lll11l11l_l1_]:
		l1l1111111l1_l1_[l11lll11l11l_l1_][group].append((context,title,url,l1llll_l1_))
	PROGRESS_UPDATE(l11l1ll11l_l1_,60+int(15*l11ll1l1ll1l_l1_//l11llllll1l1_l1_),l11lll_l1_ (u"ࠫฯ฻ๆ๋฻ࠣห้่่ศศ่ࠫ䢏"),l11lll_l1_ (u"ࠬอไอิฤࠤึ่ๅ࠻࠯ࠪ䢐"),str(l11ll1l1ll1l_l1_)+l11lll_l1_ (u"࠭ࠠ࠰ࠢࠪ䢑")+str(l11llllll1l1_l1_))
	if l11l1ll11l_l1_.iscanceled(): return
	l11ll1l1ll1l_l1_ += 1
	del l11lll11ll11_l1_[l11lll11l11l_l1_]
	groups[l11lll11l11l_l1_] = list(l1l1111111l1_l1_[l11lll11l11l_l1_].keys())
	l11llllll1ll_l1_[l11lll11l11l_l1_] = len(groups[l11lll11l11l_l1_])
	l11ll111llll_l1_ += l11llllll1ll_l1_[l11lll11l11l_l1_]
	return
def SAVE_MENUS(l11lllllll1l_l1_,l11lll11l11l_l1_):
	global l11l1ll11l_l1_,l11lll11ll11_l1_,l11ll1111l11_l1_,l1l1111111l1_l1_,l11llllll1ll_l1_,groups,l11ll111llll_l1_,l11ll1l1ll1l_l1_,l11llllll1l1_l1_
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll11l11l_l1_)
	for l1ll111ll111_l1_ in range(1+l11llllll1ll_l1_[l11lll11l11l_l1_]//273):
		l11ll11ll11l_l1_ = []
		l11lll1llll1_l1_ = groups[l11lll11l11l_l1_][:273]
		for group in l11lll1llll1_l1_:
			l11ll11ll11l_l1_.append(l1l1111111l1_l1_[l11lll11l11l_l1_][group])
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll11l11l_l1_,l11lll1llll1_l1_,l11ll11ll11l_l1_,PERMANENT_CACHE,True)
		l11ll1111l11_l1_ += len(l11lll1llll1_l1_)
		PROGRESS_UPDATE(l11l1ll11l_l1_,75+int(20*l11ll1111l11_l1_//l11ll111llll_l1_),l11lll_l1_ (u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠧ䢒"),l11lll_l1_ (u"ࠨษ็ๆฬฬๅสࠢิๆ๊ࡀ࠭ࠨ䢓"),str(l11ll1111l11_l1_)+l11lll_l1_ (u"ࠩࠣ࠳ࠥ࠭䢔")+str(l11ll111llll_l1_))
		if l11l1ll11l_l1_.iscanceled(): return
		del groups[l11lll11l11l_l1_][:273]
	del l1l1111111l1_l1_[l11lll11l11l_l1_],groups[l11lll11l11l_l1_],l11llllll1ll_l1_[l11lll11l11l_l1_]
	return
def COUNTS(l11lllllll1l_l1_,l111ll1l_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_): return
	l11lll1lllll_l1_ = l11lll_l1_ (u"ࠪ฽ิีࠠโ์า๎ํํวหࠢฯ้๏฿ࠠศๆิ์ฬฮืࠨ䢕")
	l11ll1l1l1l1_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䢖"))
	l11lll11llll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ䢗"))
	if l111ll1l_l1_:
		l11lll1lllll_l1_ = l11lll_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠥืวษูࠣࠫ䢘")+text_numbers[int(l111ll1l_l1_)]
		l111ll1l_l1_ = l11lll_l1_ (u"ࠧࡠࠩ䢙")+l111ll1l_l1_
	l1l111111l11_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"ࠨ࡫ࡱࡸࠬ䢚"),l11lll_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ䢛")+l111ll1l_l1_,l11lll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䢜"))
	l11lll1l1ll1_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"ࠫ࡮ࡴࡴࠨ䢝"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭䢞")+l111ll1l_l1_,l11lll_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䢟"))
	l11ll111111l_l1_ = READ_FROM_SQL3(l11lll11llll_l1_,l11lll_l1_ (u"ࠧࡪࡰࡷࠫ䢠"),l11lll_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䢡")+l111ll1l_l1_,l11lll_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ䢢"))
	l11lll11l111_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"ࠪ࡭ࡳࡺࠧ䢣"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䢤")+l111ll1l_l1_,l11lll_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䢥"))
	l11ll1l11l11_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"࠭ࡩ࡯ࡶࠪ䢦"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䢧")+l111ll1l_l1_,l11lll_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䢨"))
	l11llll1l11l_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"ࠩ࡬ࡲࡹ࠭䢩"),l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䢪")+l111ll1l_l1_,l11lll_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ䢫"))
	l1l1111111ll_l1_ = READ_FROM_SQL3(l11lll11llll_l1_,l11lll_l1_ (u"ࠬ࡯࡮ࡵࠩ䢬"),l11lll_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䢭")+l111ll1l_l1_,l11lll_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ䢮"))
	l11ll1ll11l1_l1_ = READ_FROM_SQL3(l11ll1l1l1l1_l1_,l11lll_l1_ (u"ࠨ࡫ࡱࡸࠬ䢯"),l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䢰")+l111ll1l_l1_,l11lll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䢱"))
	groups = READ_FROM_SQL3(l11lll11llll_l1_,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䢲"),l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䢳")+l111ll1l_l1_,l11lll_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ䢴"))
	l11ll1llllll_l1_ = []
	for group,l1llll_l1_ in groups:
		l11ll1lll1ll_l1_ = group.split(l11lll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ䢵"))[1]
		l11ll1llllll_l1_.append(l11ll1lll1ll_l1_)
	l11lll1l1111_l1_ = len(l11ll1llllll_l1_)
	total = int(l11llll1l11l_l1_)+int(l1l1111111ll_l1_)+int(l11ll1ll11l1_l1_)+int(l11ll1l11l11_l1_)+int(l11lll11l111_l1_)
	l11ll1l1l11l_l1_ = l11lll_l1_ (u"ࠨࠩ䢶")
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠩๅ๊ํอส࠻ࠢࠪ䢷")+str(l11lll11l111_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣวๆ๊วๆ࠼ࠣࠫ䢸")+str(l11llll1l11l_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠫࡡࡴๅิๆึ่ฬะ࠺ࠡࠩ䢹")+str(l11lll1l1111_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥำไใษอ࠾ࠥ࠭䢺")+str(l1l1111111ll_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"࠭࡜࡯ไ้์ฬะࠠๆฮ๊์้ฯ࠺ࠡࠩ䢻")+str(l11ll1l11l11_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠโ์า์์อสࠡ็ฯ๋ํ๊ษ࠻ࠢࠪ䢼")+str(l11ll1ll11l1_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ้ัฺ๋่ࠢส่็์่ศฬ࠽ࠤࠬ䢽")+str(l11lll1l1ll1_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠩࠣࠤࠥ࠴่ࠠࠡࠢะ๊๎ูࠡษ็ๅ๏ี๊้้สฮ࠿ࠦࠧ䢾")+str(l11ll111111l_l1_)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ๆฮ่์฾ࠦวๅ็ูหๆฯ࠺ࠡࠩ䢿")+str(total)
	l11ll1l1l11l_l1_ += l11lll_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤ๊าๅ้฻ࠣห้๋็ๆๆฬ࠾ࠥ࠭䣀")+str(l1l111111l11_l1_)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䣁"),l11lll_l1_ (u"࠭ࠧ䣂"),l11lll1lllll_l1_,l11ll1l1l11l_l1_)
	l11ll1ll1111_l1_ = l11ll1l1l11l_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䣃"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ䣄"))
	if not l111ll1l_l1_: l111ll1l_l1_ = l11lll_l1_ (u"ࠩࡄࡰࡱ࠭䣅")
	else: l111ll1l_l1_ = l111ll1l_l1_[1]
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䣆"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡄࡱࡸࡲࡹࡹࠠࡰࡨࠣࡑ࠸࡛ࠠࡷ࡫ࡧࡩࡴࡹࠠࠡࠢࡉࡳࡱࡪࡥࡳ࠼ࠣࠫ䣇")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ䣈")+l111ll1l_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ䣉")+l11ll1ll1111_l1_)
	return l11ll1l1l11l_l1_
def DELETE_FILES(l11lllllll1l_l1_,l111ll1l_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䣊"),l11lll_l1_ (u"ࠨࠩ䣋"),l11lll_l1_ (u"ࠩࠪ䣌"),l11lll_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ䣍"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠤ࠳࠴ฺࠠๆ่หࠥอๆไࠢอืฯ฽ฺ๊ࠢไ๎ࠥษ๊๊ࠡๅฮࠥอไะะ๋่ࠥหไ๊ࠢๅหห๋ษࠡโࡐ࠷่࡚ࠦอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ䣎"))
		if l1ll11l111_l1_!=1: return
		file = l1l11llll1l1_l1_.replace(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ䣏"),l11lll_l1_ (u"࠭࡟ࠨ䣐")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠧࡠࠩ䣑")+l111ll1l_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l11lll1l1lll_l1_)
	#except: pass
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠨࠩ䣒"))
	if l111ll1l_l1_:
		l11lll1111ll_l1_ = []
		for l11ll1ll1_l1_ in l11lll11111l_l1_:
			l11lll1111ll_l1_.append(l11ll1ll1_l1_+l11lll_l1_ (u"ࠩࡢࠫ䣓")+l111ll1l_l1_)
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ䣔")+l111ll1l_l1_)
	else:
		l11lll1111ll_l1_ = l11lll11111l_l1_
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ䣕"))
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠬࡍࡒࡐࡗࡓࡗࠬ䣖"))
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"࠭ࡉࡕࡇࡐࡗࠬ䣗"))
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ䣘"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ䣙"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ䣚")+l11lllllll1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ䣛"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ䣜"))
	for l11lll11l11l_l1_ in l11lll1111ll_l1_:
		DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lll11l11l_l1_)
	FIX_ALL_DATABASES(False)
	DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䣝"),l11lll_l1_ (u"࠭ࠧ䣞"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣟"),l11lll_l1_ (u"ࠨฬ่ࠤู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ䣠"))
	return
def CHECK_TABLES_EXIST(l11lllllll1l_l1_=l11lll_l1_ (u"ࠩࠪ䣡"),l1ll_l1_=True):
	if l11lllllll1l_l1_:
		l1l1ll11ll_l1_ = GET_DBFILE_NAME(str(l11lllllll1l_l1_),l11lll_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䣢"))
		dummy = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠫࡸࡺࡲࠨ䣣"),l11lll_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ䣤"),l11lll_l1_ (u"࠭࡟ࡠࡆࡘࡑࡒ࡟࡟ࡠࠩ䣥"))
		if dummy: return True
	else:
		l11lllllll1l_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ䣦")
		for l11lll1111l1_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1ll11ll_l1_ = GET_DBFILE_NAME(str(l11lll1111l1_l1_),l11lll_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ䣧"))
			dummy = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠩࡶࡸࡷ࠭䣨"),l11lll_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ䣩"),l11lll_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ䣪"))
			if dummy: return True
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䣫"),l11lll_l1_ (u"࠭ࠧ䣬"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䣭"),l11lll_l1_ (u"ࠨ้ำหࠥอไอิฤࠤ๊์ࠠศๆหี๋อๅอࠢํัฯอฬࠡำสฬ฼ࠦแ๋ัํ์์อส่๋ࠡ฽์ࠦࡍ࠴ࡗࠣ์์๎ࠠๆฬ๋ๅึࠦแ๋ࠢส่ส์สา่อࠤ๊าว็ษࠣ์ศ๐ึศ่้่ࠢ์ࠠีำสล์ࠦๅ็ࠢสู่ืใศฬࠣห้๋ฮหืฬࠤ࠳࠴ࠠศๆิหอ฽ࠠฤั้ห์ࠦๅฬษ็ࠤ้ะ่ื์ะࠤู้ไࠡษ็ีฬฮืࠡษ็้฼๊่ษࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡹࡼ࠭ࡰࡴࡪ࠲࡬࡯ࡴࡩࡷࡥ࠲࡮ࡵ࠯ࡪࡲࡷࡺ࠴࡯࡮ࡥࡧࡻ࠲ࡲ࠹ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆࠡษ็ีฬฮืࠡล฼่ฬํࠠๅ์ึࠤ๊๊ใࠡษ็้อืๅอูࠢࠫฬำศ้ࠡำหࠥอไษำ้ห๊าࠩࠡ࠰࠱ࠤํ๊วࠡ฻็ห็ฯࠠๅๆ่ฬึ๋ฬࠡส่ัฯ๎๊ศฬࠣห้ืวษูࠣว฾๊ว่ࠢ࠱࠲ࠥ๎วๅ็หี๊าࠠๅษࠣ๎ฯำๅๅࠢฦ๎๋ࠥำล๊็๎ฮࠦศิสหࠤฬูสฯัส้ࠥอไาษห฻ࠥษูๅษ๊ࠤศ๎ࠠฤ์ࠣีฬฮืࠡ฼ํี์ࠦ࠮࠯๋ࠢห้ืวษูࠣว฾๊ว่่ࠢะฬ์๊๊๊ࠡ์๋ࠥรฯ๊ำࠤ๊์ࠠศๆ่์็฿ࠠศๆ่ะฬ์๊ࠡลา๊ฬํࠠ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡮ࡴࡵࡲ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱࡬ࡴࡹࡼ࠭ࡰࡴࡪ࠳࡮ࡶࡴࡷ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䣮"),l1llllll111_l1_=l11lll_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ䣯"))
		l11lll1lllll_l1_ = l11lll_l1_ (u"ࠪษ฻อแส๋ࠢฮ฿๐๊าࠢิหอ฽ࠠࠨ䣰")+text_numbers[1]+l11lll_l1_ (u"ࠫࠥ࠮ๅอๆาࠤࠬ䣱")+text_numbers[int(l11lllllll1l_l1_)]+l11lll_l1_ (u"ࠬ࠯ࠧ䣲")
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ䣳"),l11lll_l1_ (u"ࠧࠨ䣴"),l11lll_l1_ (u"ࠨࠩ䣵"),l11lll1lllll_l1_,l11lll_l1_ (u"ࠩ็ษ฻อแสࠢิหอ฽ࠠࡎ࠵ࡘࠤ࠳࠴ࠠฤ๊็หࠥษแหฯࠣๆฬฬๅสࠢࡐ࠷࡚ࠦ࠮࠯๋ࠢฯฬ์๊ศࠢฦ๊็ืฺࠠๆ์ࠤส฼วโหࠣีฬฮืࠡล๋ࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠢ࠱࠲ࠥ๎หศๆฮหࠥษๆใำࠣ฽้๏ࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦุสๅฮࠦร้ࠢอ฾๏๐ัࠡำสฬ฼ࠦࡍ࠴ࡗࠣห้ศๆࠡมࠤࠫ䣶"))
		if l1ll11l111_l1_==1: ADD_ACCOUNT(l11lllllll1l_l1_,l11lll_l1_ (u"ࠪ࠵ࠬ䣷"))
		else: MENU(l11lllllll1l_l1_,False)
	#SHOW_EMPTY(l111ll_l1_)
	return False
def SEARCH(l1l1l1l1111_l1_,l11lllllll1l_l1_=l11lll_l1_ (u"ࠫࠬ䣸"),l11lll11l11l_l1_=l11lll_l1_ (u"ࠬ࠭䣹"),l11ll1l1l111_l1_=l11lll_l1_ (u"࠭ࠧ䣺")):
	if not l11ll1l1l111_l1_: l11ll1l1l111_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ䣻")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1111_l1_)
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1lll1l1_l1_ = [l11lll_l1_ (u"ࠨࠩ䣼"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䣽"),l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䣾"),l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䣿"),l11lll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䤀"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䤁")]
	if not l11lll11l11l_l1_:
		if not l1ll_l1_:
			if   l11lll_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡒࡉࡗࡇࡢࠫ䤂") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[1]
			elif l11lll_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭䤃") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[2]
			elif l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ䤄") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[3]
			else: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[0]
		else:
			l11lll1ll111_l1_ = [l11lll_l1_ (u"ࠪห้้ไࠨ䤅"),l11lll_l1_ (u"ࠫ็์่ศฬࠪ䤆"),l11lll_l1_ (u"ࠬษแๅษ่ࠫ䤇"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠧ䤈"),l11lll_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ䤉"),l11lll_l1_ (u"ࠨไ้์ฬะࠠๆฮ๊์้ฯࠧ䤊")]
			choice = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䤋"), l11lll1ll111_l1_)
			if choice==-1: return
			l11lll11l11l_l1_ = l11ll1lll1l1_l1_[choice]
	search = search+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䤌")
	if l11lllllll1l_l1_: SEARCH_ONE_FOLDER(search,l11lllllll1l_l1_,l11lll11l11l_l1_,l11ll1l1l111_l1_)
	else:
		for l11lllllll1l_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l11lllllll1l_l1_),l11lll11l11l_l1_,l11ll1l1l111_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1l1l1l1111_l1_,l11lllllll1l_l1_,l11lll11l11l_l1_=l11lll_l1_ (u"ࠫࠬ䤍"),l11ll1l1l111_l1_=l11lll_l1_ (u"ࠬ࠭䤎")):
	if not l11ll1l1l111_l1_: l11ll1l1l111_l1_ = l11lll_l1_ (u"࠭࠱ࠨ䤏")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1111_l1_)
	if not l11lllllll1l_l1_: return
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1lll1l1_l1_ = [l11lll_l1_ (u"ࠧࠨ䤐"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䤑"),l11lll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䤒"),l11lll_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䤓"),l11lll_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䤔"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䤕")]
	if not l11lll11l11l_l1_:
		if not l1ll_l1_:
			if   l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡑࡏࡖࡆࡡࠪ䤖") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[1]
			elif l11lll_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ䤗") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[2]
			elif l11lll_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭䤘") in options: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[3]
			else: l11lll11l11l_l1_ = l11ll1lll1l1_l1_[0]
		else:
			l11lll1ll111_l1_ = [l11lll_l1_ (u"ࠩส่่๊ࠧ䤙"),l11lll_l1_ (u"ࠪๆ๋๎วหࠩ䤚"),l11lll_l1_ (u"ࠫศ็ไศ็ࠪ䤛"),l11lll_l1_ (u"๋ࠬำๅี็หฯ࠭䤜"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠨ䤝"),l11lll_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ࠭䤞")]
			choice = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䤟"), l11lll1ll111_l1_)
			if choice==-1: return
			l11lll11l11l_l1_ = l11ll1lll1l1_l1_[choice]
	l11ll11111ll_l1_ = search.lower()
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࠩ䤠"))
	results = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䤡"),l11lll_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ䤢"),(l11lll11l11l_l1_,l11ll11111ll_l1_))
	if not results:
		l11lllll1l1l_l1_,l11ll1llll1l_l1_ = [],[]
		if not l11lll11l11l_l1_: l11ll1l1lll1_l1_ = [1,2,3,4,5]
		else: l11ll1l1lll1_l1_ = [l11ll1lll1l1_l1_.index(l11lll11l11l_l1_)]
		for l11ll111l1_l1_ in l11ll1l1lll1_l1_:
			#l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11ll1lll1l1_l1_[l11ll111l1_l1_])
			if l11ll111l1_l1_!=3:
				l1ll111l1111_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ䤣"),l11ll1lll1l1_l1_[l11ll111l1_l1_])
				del l1ll111l1111_l1_[l11lll_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ䤤")]
				del l1ll111l1111_l1_[l11lll_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ䤥")]
				del l1ll111l1111_l1_[l11lll_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ䤦")]
				groups = list(l1ll111l1111_l1_.keys())
				for group in groups:
					for context,title,url,l1llll_l1_ in l1ll111l1111_l1_[group]:
						if l11ll11111ll_l1_ in title.lower(): l11ll1llll1l_l1_.append((title,url,l1llll_l1_))
					del l1ll111l1111_l1_[group]
				del l1ll111l1111_l1_
			else: groups = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䤧"),l11ll1lll1l1_l1_[l11ll111l1_l1_],l11lll_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ䤨"))
			for group in groups:
				try: group,l1llll_l1_ = group
				except: l1llll_l1_ = l11lll_l1_ (u"ࠫࠬ䤩")
				if l11ll11111ll_l1_ in group.lower():
					if l11ll111l1_l1_!=3: l11llll1111l_l1_ = group
					else:
						l11llll111l1_l1_,l11ll11111l1_l1_ = group.split(l11lll_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ䤪"))
						if l11ll11111ll_l1_ in l11llll111l1_l1_.lower(): l11llll1111l_l1_ = l11llll111l1_l1_
						else: l11llll1111l_l1_ = l11ll11111l1_l1_
					l11lllll1l1l_l1_.append((group,l11llll1111l_l1_,l11ll1lll1l1_l1_[l11ll111l1_l1_],l1llll_l1_))
			del groups
		l11lllll1l1l_l1_ = set(l11lllll1l1l_l1_)
		l11ll1llll1l_l1_ = set(l11ll1llll1l_l1_)
		l11lllll1l1l_l1_ = sorted(l11lllll1l1l_l1_,reverse=False,key=lambda key: key[1])
		l11ll1llll1l_l1_ = sorted(l11ll1llll1l_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"࠭ࡓࡆࡃࡕࡇࡍ࠭䤫"),(l11lll11l11l_l1_,l11ll11111ll_l1_),(l11lllll1l1l_l1_,l11ll1llll1l_l1_),PERMANENT_CACHE)
	else: l11lllll1l1l_l1_,l11ll1llll1l_l1_ = results
	groups = len(l11lllll1l1l_l1_)
	l1l111_l1_ = len(l11ll1llll1l_l1_)
	l1l11l1_l1_ = int(l11ll1l1l111_l1_)
	s1 = max(0,(l1l11l1_l1_-1)*100)
	e1 = max(0,l1l11l1_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l11llll1111l_l1_,l11lllll111l_l1_,l1llll_l1_ in l11lllll1l1l_l1_[s1:e1]:
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䤬"),l111ll_l1_+l11llll1111l_l1_,l11lllll111l_l1_,714,l1llll_l1_,l11lll_l1_ (u"ࠨ࠳ࠪ䤭"),group,l11lll_l1_ (u"ࠩࠪ䤮"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䤯"):l11lllllll1l_l1_})
	del l11lllll1l1l_l1_
	for title,url,l1llll_l1_ in l11ll1llll1l_l1_[s2:e2]:
		l11lllll1111_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴࠭䤰"))[-1]
		if l11lll_l1_ (u"ࠬ࠴ࠧ䤱") in l11lllll1111_l1_ and l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䤲") not in l11lllll1111_l1_: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䤳"),l111ll_l1_+title,url,715,l1llll_l1_,l11lll_l1_ (u"ࠨࠩ䤴"),l11lll_l1_ (u"ࠩࠪ䤵"),l11lll_l1_ (u"ࠪࠫ䤶"),{l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䤷"):l11lllllll1l_l1_})
		else: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䤸"),l111ll_l1_+title,url,715,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ䤹"),l11lll_l1_ (u"ࠧࠨ䤺"),l11lll_l1_ (u"ࠨࠩ䤻"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䤼"):l11lllllll1l_l1_})
	del l11ll1llll1l_l1_
	PAGINATION(l11lllllll1l_l1_,l11ll1l1l111_l1_,l11lll11l11l_l1_,719,groups+l1l111_l1_,search+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䤽"))
	return
def PAGINATION(l11lllllll1l_l1_,l11ll1l1l111_l1_,l11lll11l11l_l1_,mode,total,text):
	if not l11ll1l1l111_l1_: l11ll1l1l111_l1_ = l11lll_l1_ (u"ࠫ࠶࠭䤾")
	if l11ll1l1l111_l1_!=l11lll_l1_ (u"ࠬ࠷ࠧ䤿"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䥀"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭䥁")+str(1),l11lll11l11l_l1_,mode,l11lll_l1_ (u"ࠨࠩ䥂"),str(1),text,l11lll_l1_ (u"ࠩࠪ䥃"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䥄"):l11lllllll1l_l1_})
	if not total: total = 0
	l1l1ll11l_l1_ = int(total/100)+1
	for l1l11l1_l1_ in range(2,l1l1ll11l_l1_):
		l1ll11lll1ll_l1_ = (l1l11l1_l1_%10==0 or int(l11ll1l1l111_l1_)-4<l1l11l1_l1_<int(l11ll1l1l111_l1_)+4)
		l1ll11lll11l_l1_ = (l1ll11lll1ll_l1_ and int(l11ll1l1l111_l1_)-40<l1l11l1_l1_<int(l11ll1l1l111_l1_)+40)
		if str(l1l11l1_l1_)!=l11ll1l1l111_l1_ and (l1l11l1_l1_%100==0 or l1ll11lll11l_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䥅"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䥆")+str(l1l11l1_l1_),l11lll11l11l_l1_,mode,l11lll_l1_ (u"࠭ࠧ䥇"),str(l1l11l1_l1_),text,l11lll_l1_ (u"ࠧࠨ䥈"),{l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䥉"):l11lllllll1l_l1_})
	if str(l1l1ll11l_l1_)!=l11ll1l1l111_l1_: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䥊"),l111ll_l1_+l11lll_l1_ (u"ࠪวำืࠠึใะอࠥ࠭䥋")+str(l1l1ll11l_l1_),l11lll11l11l_l1_,mode,l11lll_l1_ (u"ࠫࠬ䥌"),str(l1l1ll11l_l1_),text,l11lll_l1_ (u"ࠬ࠭䥍"),{l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䥎"):l11lllllll1l_l1_})
	return
def GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll11l11l_l1_):
	#if l11lll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ䥏") in l11lll11l11l_l1_ or l11lll_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒࠧ䥐") in l11lll11l11l_l1_: l1l1ll11ll_l1_ = l1l1l1lll1l1_l1_
	#else: l1l1ll11ll_l1_ = l1l1l1lll1l1_l1_
	l1l1ll11ll_l1_ = l1l1l1lll1l1_l1_.replace(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭䥑"),l11lll_l1_ (u"ࠪࡣࠬ䥒")+l11lllllll1l_l1_)
	return l1l1ll11ll_l1_
def l11llll11l1l_l1_(l11lllllll1l_l1_):
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠫࠬ䥓"))
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䥔"),l11lll_l1_ (u"࠭ࠧ䥕"),l11lll_l1_ (u"ࠧࠨ䥖"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䥗"),l11lll_l1_ (u"ࠩ฼้้๐ษࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠡไาࠤฯำสศฮࠣ฽ิฯࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๅสࠣห้๋ไโษอࠤฬ๊ย็ࠢยࠫ䥘"))
	if l1ll11l111_l1_!=1: return
	l11llllllll1_l1_(l11lllllll1l_l1_,False)
	counts = [0]
	for seq in range(1,l11ll1llll11_l1_+1):
		l11lllll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡷࡲ࡟ࠨ䥙")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠫࡤ࠭䥚")+str(seq))
		if l11lllll1lll_l1_: CREATE_STREAMS(l11lllllll1l_l1_,str(seq))
		counts.append(0)
	for l11lll11l11l_l1_ in l11lll11111l_l1_:
		l11ll1l11lll_l1_,l11ll1l1l1ll_l1_,l1l111111ll1_l1_,l11ll1ll1ll1_l1_,l11ll1l11ll1_l1_ = 0,{},[],[],[]
		for seq in range(1,l11ll1llll11_l1_+1):
			l11lllll111l_l1_ = l11lll11l11l_l1_+l11lll_l1_ (u"ࠬࡥࠧ䥛")+str(seq)
			l11lll11ll11_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ䥜"),l11lllll111l_l1_)
			try:
				l11lllllllll_l1_ = l11lll11ll11_l1_[l11lll_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ䥝")]
				count = l11lll11ll11_l1_[l11lll_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ䥞")]
			except: l11lllllllll_l1_,count = [],l11lll_l1_ (u"ࠩ࠳ࠫ䥟")
			for tuple in l11lllllllll_l1_:
				group,l11l_l1_ = tuple
				l1ll111l1111_l1_ = l11lll11ll11_l1_[group]
				if group not in l11ll1ll1ll1_l1_:
					l11ll1ll1ll1_l1_.append(group)
					l11ll1l11ll1_l1_.append(tuple)
					l11ll1l1l1ll_l1_[group] = []
				l11ll1l1l1ll_l1_[group] += l1ll111l1111_l1_
			DELETE_FROM_SQL3(l1l1ll11ll_l1_,l11lllll111l_l1_)
			WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lllll111l_l1_,l11lll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭䥠"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11ll1ll1ll1_l1_:
			l1ll111l1111_l1_ = list(set(l11ll1l1l1ll_l1_[group]))
			if l11lll_l1_ (u"ࠫࡘࡕࡒࡕࡇࡇࠫ䥡") in l11lll11l11l_l1_: l1ll111l1111_l1_ = sorted(l1ll111l1111_l1_,reverse=False,key=lambda key: key[1].lower())
			l11ll1l11lll_l1_ += len(l1ll111l1111_l1_)
			l1l111111ll1_l1_.append(l1ll111l1111_l1_)
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll11l11l_l1_,l11lll_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ䥢"),str(l11ll1l11lll_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll11l11l_l1_,l11lll_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ䥣"),l11ll1l11ll1_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll11l11l_l1_,l11ll1ll1ll1_l1_,l1l111111ll1_l1_,PERMANENT_CACHE,True)
	l11lll1l1l11_l1_ = False
	for seq in range(1,l11ll1llll11_l1_+1):
		if int(counts[seq])>0:
			l11lllll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡴ࡯ࡣࠬ䥤")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠨࡡࠪ䥥")+str(seq))
			WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠩࡏࡍࡓࡑ࡟ࠨ䥦")+str(seq),l11lll_l1_ (u"ࠪࡣࡤࡒࡉࡏࡍࡢࡣࠬ䥧"),l11lllll1lll_l1_,PERMANENT_CACHE)
			l11lll1l1l11_l1_ = True
	WRITE_TO_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ䥨"),l11lll_l1_ (u"ࠬࡥ࡟ࡅࡗࡐࡑ࡞ࡥ࡟ࠨ䥩"),l11lll_l1_ (u"࠭ࡄࡖࡏࡐ࡝ࠬ䥪"),PERMANENT_CACHE)
	if l11lll1l1l11_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䥫"),l11lll_l1_ (u"ࠨࠩ䥬"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䥭"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭䥮")+l11lll_l1_ (u"ࠫฯ๋ࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ䥯")+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䥰"))
		l11lll1l1l1l_l1_(l11lllllll1l_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ䥱"))
	else: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䥲"),l11lll_l1_ (u"ࠨࠩ䥳"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䥴"),l11lll_l1_ (u"ࠪๅู๊ࠠษีะฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢ࠱ࠤศำสๆษ็ࠤึ๎วษูࠣไࡒ࠹ࡕࠡษ็ฮ๏ࠦร็ฬࠣว฻็ส่ษ่้ࠣฮั็ษ่ะࠥเ๊าุࠢั๏ำษࠡ࠰࠱ࠤ฾๊ๅศࠢฦ๊ࠥํะ่ࠢส่ำีๅสࠢอัฯอฬࠡ็้็ࠥษๆࠡฬู๎ๆࠦวๅำสฬ฼ࠦศ็ใึ็๊ࠥไษำ้ห๊าࠠษษึฮำีวๆࠢๅหห๋ษࠡโࡐ࠷࡚ࠦวๅ็๋ะํีษࠡส๊ิฬࠦวๅสิ๊ฬ๋ฬࠨ䥵"))
	return
def l11lll1l1l1l_l1_(l11lllllll1l_l1_):
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠫࠬ䥶"))
	if not CHECK_TABLES_EXIST(l11lllllll1l_l1_,True): return
	for seq in range(1,l11ll1llll11_l1_+1):
		l11lllll1lll_l1_ = READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll_l1_ (u"ࠬࡹࡴࡳࠩ䥷"),l11lll_l1_ (u"࠭ࡌࡊࡐࡎࡣࠬ䥸")+str(seq),l11lll_l1_ (u"ࠧࡠࡡࡏࡍࡓࡑ࡟ࡠࠩ䥹"))
		if l11lllll1lll_l1_: l11ll1l1l11l_l1_ = COUNTS(l11lllllll1l_l1_,str(seq))
	COUNTS(l11lllllll1l_l1_,l11lll_l1_ (u"ࠨࠩ䥺"))
	return
def l11llllllll1_l1_(l11lllllll1l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䥻"),l11lll_l1_ (u"ࠪࠫ䥼"),l11lll_l1_ (u"ࠫࠬ䥽"),l11lll_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡโࡐ࠷࡚࠭䥾"),l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆล๊๋ࠥำฮࠢส่๊๊แศฬࠣห้่ฯ๋็ฬࠤฬ๊ๅฯิ้อࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠦࠦ࠮࠯ࠢ฼่๊อࠠศ่ๆࠤฯูสุ์฼ࠤๆ๐ࠠฤ์ࠣ์็ะࠠศๆาาํ๊ࠠฦๆ์ࠤ็อฦๆหࠣไࡒ࠹ࡕ๊ࠡฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠩ䥿"))
		if l1ll11l111_l1_!=1: return
	#for seq in range(1,l11ll1llll11_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11lll_l1_ (u"ࠧࠨ䦀"),False)
	l1l1ll11ll_l1_ = GET_DBFILE_NAME(l11lllllll1l_l1_,l11lll_l1_ (u"ࠨࠩ䦁"))
	try: os.remove(l1l1ll11ll_l1_)
	except: pass
	for seq in range(1,l11ll1llll11_l1_+1):
		filename = l1l11llll1l1_l1_.replace(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭䦂"),l11lll_l1_ (u"ࠪࡣࠬ䦃")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠫࡤ࠭䦄")+str(seq))
		l1ll1l1ll1ll_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1ll1l1ll1ll_l1_)
		except: pass
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䦅"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭䦆")+l11lllllll1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭䦇"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛࡟ࡂࡎࡏࠫ䦈"))
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䦉"),l11lll_l1_ (u"ࠪࠫ䦊"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䦋"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ䦌"))
	return
def DELETE_OLD_MENUS_CACHE(l11lllllll1l_l1_):
	trans_provider = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭䦍"))
	trans_code = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ䦎"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ䦏")+trans_provider+l11lll_l1_ (u"ࠩࡢࠫ䦐")+trans_code,l11lll_l1_ (u"ࠪࠩࡤࡓࡕࠨ䦑")+l11lllllll1l_l1_+l11lll_l1_ (u"ࠫࡤࠫࠧ䦒"))
	return
l1l111111111_l1_ = {
		 l11lll_l1_ (u"ࠬࡇࡆࠨ䦓"):l11lll_l1_ (u"࠭ࡁࡧࡩ࡫ࡥࡳ࡯ࡳࡵࡣࡱࠫ䦔")
		,l11lll_l1_ (u"ࠧࡂࡎࠪ䦕"):l11lll_l1_ (u"ࠨࡃ࡯ࡦࡦࡴࡩࡢࠩ䦖")
		,l11lll_l1_ (u"ࠩࡇ࡞ࠬ䦗"):l11lll_l1_ (u"ࠪࡅࡱ࡭ࡥࡳ࡫ࡤࠫ䦘")
		,l11lll_l1_ (u"ࠫࡆ࡙ࠧ䦙"):l11lll_l1_ (u"ࠬࡇ࡭ࡦࡴ࡬ࡧࡦࡴࠠࡔࡣࡰࡳࡦ࠭䦚")
		,l11lll_l1_ (u"࠭ࡁࡅࠩ䦛"):l11lll_l1_ (u"ࠧࡂࡰࡧࡳࡷࡸࡡࠨ䦜")
		,l11lll_l1_ (u"ࠨࡃࡒࠫ䦝"):l11lll_l1_ (u"ࠩࡄࡲ࡬ࡵ࡬ࡢࠩ䦞")
		,l11lll_l1_ (u"ࠪࡅࡎ࠭䦟"):l11lll_l1_ (u"ࠫࡆࡴࡧࡶ࡫࡯ࡰࡦ࠭䦠")
		,l11lll_l1_ (u"ࠬࡇࡑࠨ䦡"):l11lll_l1_ (u"࠭ࡁ࡯ࡶࡤࡶࡨࡺࡩࡤࡣࠪ䦢")
		,l11lll_l1_ (u"ࠧࡂࡉࠪ䦣"):l11lll_l1_ (u"ࠨࡃࡱࡸ࡮࡭ࡵࡢࠢࡤࡲࡩࠦࡂࡢࡴࡥࡹࡩࡧࠧ䦤")
		,l11lll_l1_ (u"ࠩࡄࡖࠬ䦥"):l11lll_l1_ (u"ࠪࡅࡷ࡭ࡥ࡯ࡶ࡬ࡲࡦ࠭䦦")
		,l11lll_l1_ (u"ࠫࡆࡓࠧ䦧"):l11lll_l1_ (u"ࠬࡇࡲ࡮ࡧࡱ࡭ࡦ࠭䦨")
		,l11lll_l1_ (u"࠭ࡁࡘࠩ䦩"):l11lll_l1_ (u"ࠧࡂࡴࡸࡦࡦ࠭䦪")
		,l11lll_l1_ (u"ࠨࡃࡘࠫ䦫"):l11lll_l1_ (u"ࠩࡄࡹࡸࡺࡲࡢ࡮࡬ࡥࠬ䦬")
		,l11lll_l1_ (u"ࠪࡅ࡙࠭䦭"):l11lll_l1_ (u"ࠫࡆࡻࡳࡵࡴ࡬ࡥࠬ䦮")
		,l11lll_l1_ (u"ࠬࡇ࡚ࠨ䦯"):l11lll_l1_ (u"࠭ࡁࡻࡧࡵࡦࡦ࡯ࡪࡢࡰࠪ䦰")
		,l11lll_l1_ (u"ࠧࡃࡕࠪ䦱"):l11lll_l1_ (u"ࠨࡄࡤ࡬ࡦࡳࡡࡴࠩ䦲")
		,l11lll_l1_ (u"ࠩࡅࡌࠬ䦳"):l11lll_l1_ (u"ࠪࡆࡦ࡮ࡲࡢ࡫ࡱࠫ䦴")
		,l11lll_l1_ (u"ࠫࡇࡊࠧ䦵"):l11lll_l1_ (u"ࠬࡈࡡ࡯ࡩ࡯ࡥࡩ࡫ࡳࡩࠩ䦶")
		,l11lll_l1_ (u"࠭ࡂࡃࠩ䦷"):l11lll_l1_ (u"ࠧࡃࡣࡵࡦࡦࡪ࡯ࡴࠩ䦸")
		,l11lll_l1_ (u"ࠨࡄ࡜ࠫ䦹"):l11lll_l1_ (u"ࠩࡅࡩࡱࡧࡲࡶࡵࠪ䦺")
		,l11lll_l1_ (u"ࠪࡆࡊ࠭䦻"):l11lll_l1_ (u"ࠫࡇ࡫࡬ࡨ࡫ࡸࡱࠬ䦼")
		,l11lll_l1_ (u"ࠬࡈ࡚ࠨ䦽"):l11lll_l1_ (u"࠭ࡂࡦ࡮࡬ࡾࡪ࠭䦾")
		,l11lll_l1_ (u"ࠧࡃࡌࠪ䦿"):l11lll_l1_ (u"ࠨࡄࡨࡲ࡮ࡴࠧ䧀")
		,l11lll_l1_ (u"ࠩࡅࡑࠬ䧁"):l11lll_l1_ (u"ࠪࡆࡪࡸ࡭ࡶࡦࡤࠫ䧂")
		,l11lll_l1_ (u"ࠫࡇ࡚ࠧ䧃"):l11lll_l1_ (u"ࠬࡈࡨࡶࡶࡤࡲࠬ䧄")
		,l11lll_l1_ (u"࠭ࡂࡐࠩ䧅"):l11lll_l1_ (u"ࠧࡃࡱ࡯࡭ࡻ࡯ࡡࠨ䧆")
		,l11lll_l1_ (u"ࠨࡄࡔࠫ䧇"):l11lll_l1_ (u"ࠩࡅࡳࡳࡧࡩࡳࡧࠪ䧈")
		,l11lll_l1_ (u"ࠪࡆࡆ࠭䧉"):l11lll_l1_ (u"ࠫࡇࡵࡳ࡯࡫ࡤࠤࡦࡴࡤࠡࡊࡨࡶࡿ࡫ࡧࡰࡸ࡬ࡲࡦ࠭䧊")
		,l11lll_l1_ (u"ࠬࡈࡗࠨ䧋"):l11lll_l1_ (u"࠭ࡂࡰࡶࡶࡻࡦࡴࡡࠨ䧌")
		,l11lll_l1_ (u"ࠧࡃࡘࠪ䧍"):l11lll_l1_ (u"ࠨࡄࡲࡹࡻ࡫ࡴࠡࡋࡶࡰࡦࡴࡤࠨ䧎")
		,l11lll_l1_ (u"ࠩࡅࡖࠬ䧏"):l11lll_l1_ (u"ࠪࡆࡷࡧࡺࡪ࡮ࠪ䧐")
		,l11lll_l1_ (u"ࠫࡎࡕࠧ䧑"):l11lll_l1_ (u"ࠬࡈࡲࡪࡶ࡬ࡷ࡭ࠦࡉ࡯ࡦ࡬ࡥࡳࠦࡏࡤࡧࡤࡲ࡚ࠥࡥࡳࡴ࡬ࡸࡴࡸࡹࠨ䧒")
		,l11lll_l1_ (u"࠭ࡖࡈࠩ䧓"):l11lll_l1_ (u"ࠧࡃࡴ࡬ࡸ࡮ࡹࡨࠡࡘ࡬ࡶ࡬࡯࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ䧔")
		,l11lll_l1_ (u"ࠨࡄࡑࠫ䧕"):l11lll_l1_ (u"ࠩࡅࡶࡺࡴࡥࡪࠩ䧖")
		,l11lll_l1_ (u"ࠪࡆࡌ࠭䧗"):l11lll_l1_ (u"ࠫࡇࡻ࡬ࡨࡣࡵ࡭ࡦ࠭䧘")
		,l11lll_l1_ (u"ࠬࡈࡆࠨ䧙"):l11lll_l1_ (u"࠭ࡂࡶࡴ࡮࡭ࡳࡧࠠࡇࡣࡶࡳࠬ䧚")
		,l11lll_l1_ (u"ࠧࡃࡋࠪ䧛"):l11lll_l1_ (u"ࠨࡄࡸࡶࡺࡴࡤࡪࠩ䧜")
		,l11lll_l1_ (u"ࠩࡎࡌࠬ䧝"):l11lll_l1_ (u"ࠪࡇࡦࡳࡢࡰࡦ࡬ࡥࠬ䧞")
		,l11lll_l1_ (u"ࠫࡈࡓࠧ䧟"):l11lll_l1_ (u"ࠬࡉࡡ࡮ࡧࡵࡳࡴࡴࠧ䧠")
		,l11lll_l1_ (u"࠭ࡃࡂࠩ䧡"):l11lll_l1_ (u"ࠧࡄࡣࡱࡥࡩࡧࠧ䧢")
		,l11lll_l1_ (u"ࠨࡅ࡙ࠫ䧣"):l11lll_l1_ (u"ࠩࡆࡥࡵ࡫ࠠࡗࡧࡵࡨࡪ࠭䧤")
		,l11lll_l1_ (u"ࠪࡏ࡞࠭䧥"):l11lll_l1_ (u"ࠫࡈࡧࡹ࡮ࡣࡱࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䧦")
		,l11lll_l1_ (u"ࠬࡉࡆࠨ䧧"):l11lll_l1_ (u"࠭ࡃࡦࡰࡷࡶࡦࡲࠠࡂࡨࡵ࡭ࡨࡧ࡮ࠡࡔࡨࡴࡺࡨ࡬ࡪࡥࠪ䧨")
		,l11lll_l1_ (u"ࠧࡕࡆࠪ䧩"):l11lll_l1_ (u"ࠨࡅ࡫ࡥࡩ࠭䧪")
		,l11lll_l1_ (u"ࠩࡆࡐࠬ䧫"):l11lll_l1_ (u"ࠪࡇ࡭࡯࡬ࡦࠩ䧬")
		,l11lll_l1_ (u"ࠫࡈࡔࠧ䧭"):l11lll_l1_ (u"ࠬࡉࡨࡪࡰࡤࠫ䧮")
		,l11lll_l1_ (u"࠭ࡃ࡙ࠩ䧯"):l11lll_l1_ (u"ࠧࡄࡪࡵ࡭ࡸࡺ࡭ࡢࡵࠣࡍࡸࡲࡡ࡯ࡦࠪ䧰")
		,l11lll_l1_ (u"ࠨࡅࡆࠫ䧱"):l11lll_l1_ (u"ࠩࡆࡳࡨࡵࡳࠡࠪࡎࡩࡪࡲࡩ࡯ࡩࠬࠤࡎࡹ࡬ࡢࡰࡧࡷࠬ䧲")
		,l11lll_l1_ (u"ࠪࡇࡔ࠭䧳"):l11lll_l1_ (u"ࠫࡈࡵ࡬ࡰ࡯ࡥ࡭ࡦ࠭䧴")
		,l11lll_l1_ (u"ࠬࡑࡍࠨ䧵"):l11lll_l1_ (u"࠭ࡃࡰ࡯ࡲࡶࡴࡹࠧ䧶")
		,l11lll_l1_ (u"ࠧࡄࡍࠪ䧷"):l11lll_l1_ (u"ࠨࡅࡲࡳࡰࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䧸")
		,l11lll_l1_ (u"ࠩࡆࡖࠬ䧹"):l11lll_l1_ (u"ࠪࡇࡴࡹࡴࡢࠢࡕ࡭ࡨࡧࠧ䧺")
		,l11lll_l1_ (u"ࠫࡍࡘࠧ䧻"):l11lll_l1_ (u"ࠬࡉࡲࡰࡣࡷ࡭ࡦ࠭䧼")
		,l11lll_l1_ (u"࠭ࡃࡖࠩ䧽"):l11lll_l1_ (u"ࠧࡄࡷࡥࡥࠬ䧾")
		,l11lll_l1_ (u"ࠨࡅ࡚ࠫ䧿"):l11lll_l1_ (u"ࠩࡆࡹࡷࡧࡣࡢࡱࠪ䨀")
		,l11lll_l1_ (u"ࠪࡇ࡞࠭䨁"):l11lll_l1_ (u"ࠫࡈࡿࡰࡳࡷࡶࠫ䨂")
		,l11lll_l1_ (u"ࠬࡉ࡚ࠨ䨃"):l11lll_l1_ (u"࠭ࡃࡻࡧࡦ࡬ࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䨄")
		,l11lll_l1_ (u"ࠧࡄࡆࠪ䨅"):l11lll_l1_ (u"ࠨࡆࡨࡱࡴࡩࡲࡢࡶ࡬ࡧࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠠࡰࡨࠣࡸ࡭࡫ࠠࡄࡱࡱ࡫ࡴ࠭䨆")
		,l11lll_l1_ (u"ࠩࡇࡏࠬ䨇"):l11lll_l1_ (u"ࠪࡈࡪࡴ࡭ࡢࡴ࡮ࠫ䨈")
		,l11lll_l1_ (u"ࠫࡉࡐࠧ䨉"):l11lll_l1_ (u"ࠬࡊࡪࡪࡤࡲࡹࡹ࡯ࠧ䨊")
		,l11lll_l1_ (u"࠭ࡄࡎࠩ䨋"):l11lll_l1_ (u"ࠧࡅࡱࡰ࡭ࡳ࡯ࡣࡢࠩ䨌")
		,l11lll_l1_ (u"ࠨࡆࡒࠫ䨍"):l11lll_l1_ (u"ࠩࡇࡳࡲ࡯࡮ࡪࡥࡤࡲࠥࡘࡥࡱࡷࡥࡰ࡮ࡩࠧ䨎")
		,l11lll_l1_ (u"ࠪࡘࡑ࠭䨏"):l11lll_l1_ (u"ࠫࡊࡧࡳࡵࠢࡗ࡭ࡲࡵࡲࠨ䨐")
		,l11lll_l1_ (u"ࠬࡋࡃࠨ䨑"):l11lll_l1_ (u"࠭ࡅࡤࡷࡤࡨࡴࡸࠧ䨒")
		,l11lll_l1_ (u"ࠧࡆࡉࠪ䨓"):l11lll_l1_ (u"ࠨࡇࡪࡽࡵࡺࠧ䨔")
		,l11lll_l1_ (u"ࠩࡖ࡚ࠬ䨕"):l11lll_l1_ (u"ࠪࡉࡱࠦࡓࡢ࡮ࡹࡥࡩࡵࡲࠨ䨖")
		,l11lll_l1_ (u"ࠫࡌࡗࠧ䨗"):l11lll_l1_ (u"ࠬࡋࡱࡶࡣࡷࡳࡷ࡯ࡡ࡭ࠢࡊࡹ࡮ࡴࡥࡢࠩ䨘")
		,l11lll_l1_ (u"࠭ࡅࡓࠩ䨙"):l11lll_l1_ (u"ࠧࡆࡴ࡬ࡸࡷ࡫ࡡࠨ䨚")
		,l11lll_l1_ (u"ࠨࡇࡈࠫ䨛"):l11lll_l1_ (u"ࠩࡈࡷࡹࡵ࡮ࡪࡣࠪ䨜")
		,l11lll_l1_ (u"ࠪࡉ࡙࠭䨝"):l11lll_l1_ (u"ࠫࡊࡺࡨࡪࡱࡳ࡭ࡦ࠭䨞")
		,l11lll_l1_ (u"ࠬࡌࡋࠨ䨟"):l11lll_l1_ (u"࠭ࡆࡢ࡮࡮ࡰࡦࡴࡤࠡࡋࡶࡰࡦࡴࡤࡴࠩ䨠")
		,l11lll_l1_ (u"ࠧࡇࡑࠪ䨡"):l11lll_l1_ (u"ࠨࡈࡤࡶࡴ࡫ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ䨢")
		,l11lll_l1_ (u"ࠩࡉࡎࠬ䨣"):l11lll_l1_ (u"ࠪࡊ࡮ࡰࡩࠨ䨤")
		,l11lll_l1_ (u"ࠫࡋࡏࠧ䨥"):l11lll_l1_ (u"ࠬࡌࡩ࡯࡮ࡤࡲࡩ࠭䨦")
		,l11lll_l1_ (u"࠭ࡆࡓࠩ䨧"):l11lll_l1_ (u"ࠧࡇࡴࡤࡲࡨ࡫ࠧ䨨")
		,l11lll_l1_ (u"ࠨࡉࡉࠫ䨩"):l11lll_l1_ (u"ࠩࡉࡶࡪࡴࡣࡩࠢࡊࡹ࡮ࡧ࡮ࡢࠩ䨪")
		,l11lll_l1_ (u"ࠪࡔࡋ࠭䨫"):l11lll_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡕࡵ࡬ࡺࡰࡨࡷ࡮ࡧࠧ䨬")
		,l11lll_l1_ (u"࡚ࠬࡆࠨ䨭"):l11lll_l1_ (u"࠭ࡆࡳࡧࡱࡧ࡭ࠦࡓࡰࡷࡷ࡬ࡪࡸ࡮ࠡࡖࡨࡶࡷ࡯ࡴࡰࡴ࡬ࡩࡸ࠭䨮")
		,l11lll_l1_ (u"ࠧࡈࡃࠪ䨯"):l11lll_l1_ (u"ࠨࡉࡤࡦࡴࡴࠧ䨰")
		,l11lll_l1_ (u"ࠩࡊࡑࠬ䨱"):l11lll_l1_ (u"ࠪࡋࡦࡳࡢࡪࡣࠪ䨲")
		,l11lll_l1_ (u"ࠫࡌࡋࠧ䨳"):l11lll_l1_ (u"ࠬࡍࡥࡰࡴࡪ࡭ࡦ࠭䨴")
		,l11lll_l1_ (u"࠭ࡄࡆࠩ䨵"):l11lll_l1_ (u"ࠧࡈࡧࡵࡱࡦࡴࡹࠨ䨶")
		,l11lll_l1_ (u"ࠨࡉࡋࠫ䨷"):l11lll_l1_ (u"ࠩࡊ࡬ࡦࡴࡡࠨ䨸")
		,l11lll_l1_ (u"ࠪࡋࡎ࠭䨹"):l11lll_l1_ (u"ࠫࡌ࡯ࡢࡳࡣ࡯ࡸࡦࡸࠧ䨺")
		,l11lll_l1_ (u"ࠬࡍࡒࠨ䨻"):l11lll_l1_ (u"࠭ࡇࡳࡧࡨࡧࡪ࠭䨼")
		,l11lll_l1_ (u"ࠧࡈࡎࠪ䨽"):l11lll_l1_ (u"ࠨࡉࡵࡩࡪࡴ࡬ࡢࡰࡧࠫ䨾")
		,l11lll_l1_ (u"ࠩࡊࡈࠬ䨿"):l11lll_l1_ (u"ࠪࡋࡷ࡫࡮ࡢࡦࡤࠫ䩀")
		,l11lll_l1_ (u"ࠫࡌࡖࠧ䩁"):l11lll_l1_ (u"ࠬࡍࡵࡢࡦࡨࡰࡴࡻࡰࡦࠩ䩂")
		,l11lll_l1_ (u"࠭ࡇࡖࠩ䩃"):l11lll_l1_ (u"ࠧࡈࡷࡤࡱࠬ䩄")
		,l11lll_l1_ (u"ࠨࡉࡗࠫ䩅"):l11lll_l1_ (u"ࠩࡊࡹࡦࡺࡥ࡮ࡣ࡯ࡥࠬ䩆")
		,l11lll_l1_ (u"ࠪࡋࡌ࠭䩇"):l11lll_l1_ (u"ࠫࡌࡻࡥࡳࡰࡶࡩࡾ࠭䩈")
		,l11lll_l1_ (u"ࠬࡍࡎࠨ䩉"):l11lll_l1_ (u"࠭ࡇࡶ࡫ࡱࡩࡦ࠭䩊")
		,l11lll_l1_ (u"ࠧࡈ࡙ࠪ䩋"):l11lll_l1_ (u"ࠨࡉࡸ࡭ࡳ࡫ࡡ࠮ࡄ࡬ࡷࡸࡧࡵࠨ䩌")
		,l11lll_l1_ (u"ࠩࡊ࡝ࠬ䩍"):l11lll_l1_ (u"ࠪࡋࡺࡿࡡ࡯ࡣࠪ䩎")
		,l11lll_l1_ (u"ࠫࡍ࡚ࠧ䩏"):l11lll_l1_ (u"ࠬࡎࡡࡪࡶ࡬ࠫ䩐")
		,l11lll_l1_ (u"࠭ࡈࡎࠩ䩑"):l11lll_l1_ (u"ࠧࡉࡧࡤࡶࡩࠦࡉࡴ࡮ࡤࡲࡩࠦࡡ࡯ࡦࠣࡑࡨࡊ࡯࡯ࡣ࡯ࡨࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䩒")
		,l11lll_l1_ (u"ࠨࡊࡑࠫ䩓"):l11lll_l1_ (u"ࠩࡋࡳࡳࡪࡵࡳࡣࡶࠫ䩔")
		,l11lll_l1_ (u"ࠪࡌࡐ࠭䩕"):l11lll_l1_ (u"ࠫࡍࡵ࡮ࡨࠢࡎࡳࡳ࡭ࠧ䩖")
		,l11lll_l1_ (u"ࠬࡎࡕࠨ䩗"):l11lll_l1_ (u"࠭ࡈࡶࡰࡪࡥࡷࡿࠧ䩘")
		,l11lll_l1_ (u"ࠧࡊࡕࠪ䩙"):l11lll_l1_ (u"ࠨࡋࡦࡩࡱࡧ࡮ࡥࠩ䩚")
		,l11lll_l1_ (u"ࠩࡌࡒࠬ䩛"):l11lll_l1_ (u"ࠪࡍࡳࡪࡩࡢࠩ䩜")
		,l11lll_l1_ (u"ࠫࡎࡊࠧ䩝"):l11lll_l1_ (u"ࠬࡏ࡮ࡥࡱࡱࡩࡸ࡯ࡡࠨ䩞")
		,l11lll_l1_ (u"࠭ࡉࡓࠩ䩟"):l11lll_l1_ (u"ࠧࡊࡴࡤࡲࠬ䩠")
		,l11lll_l1_ (u"ࠨࡋࡔࠫ䩡"):l11lll_l1_ (u"ࠩࡌࡶࡦࡷࠧ䩢")
		,l11lll_l1_ (u"ࠪࡍࡊ࠭䩣"):l11lll_l1_ (u"ࠫࡎࡸࡥ࡭ࡣࡱࡨࠬ䩤")
		,l11lll_l1_ (u"ࠬࡏࡍࠨ䩥"):l11lll_l1_ (u"࠭ࡉࡴ࡮ࡨࠤࡴ࡬ࠠࡎࡣࡱࠫ䩦")
		,l11lll_l1_ (u"ࠧࡊࡎࠪ䩧"):l11lll_l1_ (u"ࠨࡋࡶࡶࡦ࡫࡬ࠨ䩨")
		,l11lll_l1_ (u"ࠩࡌࡘࠬ䩩"):l11lll_l1_ (u"ࠪࡍࡹࡧ࡬ࡺࠩ䩪")
		,l11lll_l1_ (u"ࠫࡈࡏࠧ䩫"):l11lll_l1_ (u"ࠬࡏࡶࡰࡴࡼࠤࡈࡵࡡࡴࡶࠪ䩬")
		,l11lll_l1_ (u"࠭ࡊࡎࠩ䩭"):l11lll_l1_ (u"ࠧࡋࡣࡰࡥ࡮ࡩࡡࠨ䩮")
		,l11lll_l1_ (u"ࠨࡌࡓࠫ䩯"):l11lll_l1_ (u"ࠩࡍࡥࡵࡧ࡮ࠨ䩰")
		,l11lll_l1_ (u"ࠪࡎࡊ࠭䩱"):l11lll_l1_ (u"ࠫࡏ࡫ࡲࡴࡧࡼࠫ䩲")
		,l11lll_l1_ (u"ࠬࡐࡏࠨ䩳"):l11lll_l1_ (u"࠭ࡊࡰࡴࡧࡥࡳ࠭䩴")
		,l11lll_l1_ (u"ࠧࡌ࡜ࠪ䩵"):l11lll_l1_ (u"ࠨࡍࡤࡾࡦࡱࡨࡴࡶࡤࡲࠬ䩶")
		,l11lll_l1_ (u"ࠩࡎࡉࠬ䩷"):l11lll_l1_ (u"ࠪࡏࡪࡴࡹࡢࠩ䩸")
		,l11lll_l1_ (u"ࠫࡐࡏࠧ䩹"):l11lll_l1_ (u"ࠬࡑࡩࡳ࡫ࡥࡥࡹ࡯ࠧ䩺")
		,l11lll_l1_ (u"࠭ࡘࡌࠩ䩻"):l11lll_l1_ (u"ࠧࡌࡱࡶࡳࡻࡵࠧ䩼")
		,l11lll_l1_ (u"ࠨࡍ࡚ࠫ䩽"):l11lll_l1_ (u"ࠩࡎࡹࡼࡧࡩࡵࠩ䩾")
		,l11lll_l1_ (u"ࠪࡏࡌ࠭䩿"):l11lll_l1_ (u"ࠫࡐࡿࡲࡨࡻࡽࡷࡹࡧ࡮ࠨ䪀")
		,l11lll_l1_ (u"ࠬࡒࡁࠨ䪁"):l11lll_l1_ (u"࠭ࡌࡢࡱࡶࠫ䪂")
		,l11lll_l1_ (u"ࠧࡍࡘࠪ䪃"):l11lll_l1_ (u"ࠨࡎࡤࡸࡻ࡯ࡡࠨ䪄")
		,l11lll_l1_ (u"ࠩࡏࡆࠬ䪅"):l11lll_l1_ (u"ࠪࡐࡪࡨࡡ࡯ࡱࡱࠫ䪆")
		,l11lll_l1_ (u"ࠫࡑ࡙ࠧ䪇"):l11lll_l1_ (u"ࠬࡒࡥࡴࡱࡷ࡬ࡴ࠭䪈")
		,l11lll_l1_ (u"࠭ࡌࡓࠩ䪉"):l11lll_l1_ (u"ࠧࡍ࡫ࡥࡩࡷ࡯ࡡࠨ䪊")
		,l11lll_l1_ (u"ࠨࡎ࡜ࠫ䪋"):l11lll_l1_ (u"ࠩࡏ࡭ࡧࡿࡡࠨ䪌")
		,l11lll_l1_ (u"ࠪࡐࡎ࠭䪍"):l11lll_l1_ (u"ࠫࡑ࡯ࡥࡤࡪࡷࡩࡳࡹࡴࡦ࡫ࡱࠫ䪎")
		,l11lll_l1_ (u"ࠬࡒࡔࠨ䪏"):l11lll_l1_ (u"࠭ࡌࡪࡶ࡫ࡹࡦࡴࡩࡢࠩ䪐")
		,l11lll_l1_ (u"ࠧࡍࡗࠪ䪑"):l11lll_l1_ (u"ࠨࡎࡸࡼࡪࡳࡢࡰࡷࡵ࡫ࠬ䪒")
		,l11lll_l1_ (u"ࠩࡐࡓࠬ䪓"):l11lll_l1_ (u"ࠪࡑࡦࡩࡡࡰࠩ䪔")
		,l11lll_l1_ (u"ࠫࡒࡍࠧ䪕"):l11lll_l1_ (u"ࠬࡓࡡࡥࡣࡪࡥࡸࡩࡡࡳࠩ䪖")
		,l11lll_l1_ (u"࠭ࡍࡘࠩ䪗"):l11lll_l1_ (u"ࠧࡎࡣ࡯ࡥࡼ࡯ࠧ䪘")
		,l11lll_l1_ (u"ࠨࡏ࡜ࠫ䪙"):l11lll_l1_ (u"ࠩࡐࡥࡱࡧࡹࡴ࡫ࡤࠫ䪚")
		,l11lll_l1_ (u"ࠪࡑ࡛࠭䪛"):l11lll_l1_ (u"ࠫࡒࡧ࡬ࡥ࡫ࡹࡩࡸ࠭䪜")
		,l11lll_l1_ (u"ࠬࡓࡌࠨ䪝"):l11lll_l1_ (u"࠭ࡍࡢ࡮࡬ࠫ䪞")
		,l11lll_l1_ (u"ࠧࡎࡖࠪ䪟"):l11lll_l1_ (u"ࠨࡏࡤࡰࡹࡧࠧ䪠")
		,l11lll_l1_ (u"ࠩࡐࡌࠬ䪡"):l11lll_l1_ (u"ࠪࡑࡦࡸࡳࡩࡣ࡯ࡰࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䪢")
		,l11lll_l1_ (u"ࠫࡒࡗࠧ䪣"):l11lll_l1_ (u"ࠬࡓࡡࡳࡶ࡬ࡲ࡮ࡷࡵࡦࠩ䪤")
		,l11lll_l1_ (u"࠭ࡍࡓࠩ䪥"):l11lll_l1_ (u"ࠧࡎࡣࡸࡶ࡮ࡺࡡ࡯࡫ࡤࠫ䪦")
		,l11lll_l1_ (u"ࠨࡏࡘࠫ䪧"):l11lll_l1_ (u"ࠩࡐࡥࡺࡸࡩࡵ࡫ࡸࡷࠬ䪨")
		,l11lll_l1_ (u"ࠪ࡝࡙࠭䪩"):l11lll_l1_ (u"ࠫࡒࡧࡹࡰࡶࡷࡩࠬ䪪")
		,l11lll_l1_ (u"ࠬࡓࡘࠨ䪫"):l11lll_l1_ (u"࠭ࡍࡦࡺ࡬ࡧࡴ࠭䪬")
		,l11lll_l1_ (u"ࠧࡇࡏࠪ䪭"):l11lll_l1_ (u"ࠨࡏ࡬ࡧࡷࡵ࡮ࡦࡵ࡬ࡥࠬ䪮")
		,l11lll_l1_ (u"ࠩࡐࡈࠬ䪯"):l11lll_l1_ (u"ࠪࡑࡴࡲࡤࡰࡸࡤࠫ䪰")
		,l11lll_l1_ (u"ࠫࡒࡉࠧ䪱"):l11lll_l1_ (u"ࠬࡓ࡯࡯ࡣࡦࡳࠬ䪲")
		,l11lll_l1_ (u"࠭ࡍࡏࠩ䪳"):l11lll_l1_ (u"ࠧࡎࡱࡱ࡫ࡴࡲࡩࡢࠩ䪴")
		,l11lll_l1_ (u"ࠨࡏࡈࠫ䪵"):l11lll_l1_ (u"ࠩࡐࡳࡳࡺࡥ࡯ࡧࡪࡶࡴ࠭䪶")
		,l11lll_l1_ (u"ࠪࡑࡘ࠭䪷"):l11lll_l1_ (u"ࠫࡒࡵ࡮ࡵࡵࡨࡶࡷࡧࡴࠨ䪸")
		,l11lll_l1_ (u"ࠬࡓࡁࠨ䪹"):l11lll_l1_ (u"࠭ࡍࡰࡴࡲࡧࡨࡵࠧ䪺")
		,l11lll_l1_ (u"ࠧࡎ࡜ࠪ䪻"):l11lll_l1_ (u"ࠨࡏࡲࡾࡦࡳࡢࡪࡳࡸࡩࠬ䪼")
		,l11lll_l1_ (u"ࠩࡐࡑࠬ䪽"):l11lll_l1_ (u"ࠪࡑࡾࡧ࡮࡮ࡣࡵࠤ࠭ࡈࡵࡳ࡯ࡤ࠭ࠬ䪾")
		,l11lll_l1_ (u"ࠫࡓࡇࠧ䪿"):l11lll_l1_ (u"ࠬࡔࡡ࡮࡫ࡥ࡭ࡦ࠭䫀")
		,l11lll_l1_ (u"࠭ࡎࡓࠩ䫁"):l11lll_l1_ (u"ࠧࡏࡣࡸࡶࡺ࠭䫂")
		,l11lll_l1_ (u"ࠨࡐࡓࠫ䫃"):l11lll_l1_ (u"ࠩࡑࡩࡵࡧ࡬ࠨ䫄")
		,l11lll_l1_ (u"ࠪࡒࡑ࠭䫅"):l11lll_l1_ (u"ࠫࡓ࡫ࡴࡩࡧࡵࡰࡦࡴࡤࡴࠩ䫆")
		,l11lll_l1_ (u"ࠬࡔࡃࠨ䫇"):l11lll_l1_ (u"࠭ࡎࡦࡹࠣࡇࡦࡲࡥࡥࡱࡱ࡭ࡦ࠭䫈")
		,l11lll_l1_ (u"ࠧࡏ࡜ࠪ䫉"):l11lll_l1_ (u"ࠨࡐࡨࡻࠥࡠࡥࡢ࡮ࡤࡲࡩ࠭䫊")
		,l11lll_l1_ (u"ࠩࡑࡍࠬ䫋"):l11lll_l1_ (u"ࠪࡒ࡮ࡩࡡࡳࡣࡪࡹࡦ࠭䫌")
		,l11lll_l1_ (u"ࠫࡓࡋࠧ䫍"):l11lll_l1_ (u"ࠬࡔࡩࡨࡧࡵࠫ䫎")
		,l11lll_l1_ (u"࠭ࡎࡈࠩ䫏"):l11lll_l1_ (u"ࠧࡏ࡫ࡪࡩࡷ࡯ࡡࠨ䫐")
		,l11lll_l1_ (u"ࠨࡐࡘࠫ䫑"):l11lll_l1_ (u"ࠩࡑ࡭ࡺ࡫ࠧ䫒")
		,l11lll_l1_ (u"ࠪࡒࡋ࠭䫓"):l11lll_l1_ (u"ࠫࡓࡵࡲࡧࡱ࡯࡯ࠥࡏࡳ࡭ࡣࡱࡨࠬ䫔")
		,l11lll_l1_ (u"ࠬࡑࡐࠨ䫕"):l11lll_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ䫖")
		,l11lll_l1_ (u"ࠧࡎࡍࠪ䫗"):l11lll_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ䫘")
		,l11lll_l1_ (u"ࠩࡐࡔࠬ䫙"):l11lll_l1_ (u"ࠪࡒࡴࡸࡴࡩࡧࡵࡲࠥࡓࡡࡳ࡫ࡤࡲࡦࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䫚")
		,l11lll_l1_ (u"ࠫࡓࡕࠧ䫛"):l11lll_l1_ (u"ࠬࡔ࡯ࡳࡹࡤࡽࠬ䫜")
		,l11lll_l1_ (u"࠭ࡏࡎࠩ䫝"):l11lll_l1_ (u"ࠧࡐ࡯ࡤࡲࠬ䫞")
		,l11lll_l1_ (u"ࠨࡒࡎࠫ䫟"):l11lll_l1_ (u"ࠩࡓࡥࡰ࡯ࡳࡵࡣࡱࠫ䫠")
		,l11lll_l1_ (u"ࠪࡔ࡜࠭䫡"):l11lll_l1_ (u"ࠫࡕࡧ࡬ࡢࡷࠪ䫢")
		,l11lll_l1_ (u"ࠬࡖࡓࠨ䫣"):l11lll_l1_ (u"࠭ࡐࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䫤")
		,l11lll_l1_ (u"ࠧࡑࡃࠪ䫥"):l11lll_l1_ (u"ࠨࡒࡤࡲࡦࡳࡡࠨ䫦")
		,l11lll_l1_ (u"ࠩࡓࡋࠬ䫧"):l11lll_l1_ (u"ࠪࡔࡦࡶࡵࡢࠢࡑࡩࡼࠦࡇࡶ࡫ࡱࡩࡦ࠭䫨")
		,l11lll_l1_ (u"ࠫࡕ࡟ࠧ䫩"):l11lll_l1_ (u"ࠬࡖࡡࡳࡣࡪࡹࡦࡿࠧ䫪")
		,l11lll_l1_ (u"࠭ࡐࡆࠩ䫫"):l11lll_l1_ (u"ࠧࡑࡧࡵࡹࠬ䫬")
		,l11lll_l1_ (u"ࠨࡒࡋࠫ䫭"):l11lll_l1_ (u"ࠩࡓ࡬࡮ࡲࡩࡱࡲ࡬ࡲࡪࡹࠧ䫮")
		,l11lll_l1_ (u"ࠪࡔࡓ࠭䫯"):l11lll_l1_ (u"ࠫࡕ࡯ࡴࡤࡣ࡬ࡶࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䫰")
		,l11lll_l1_ (u"ࠬࡖࡌࠨ䫱"):l11lll_l1_ (u"࠭ࡐࡰ࡮ࡤࡲࡩ࠭䫲")
		,l11lll_l1_ (u"ࠧࡑࡖࠪ䫳"):l11lll_l1_ (u"ࠨࡒࡲࡶࡹࡻࡧࡢ࡮ࠪ䫴")
		,l11lll_l1_ (u"ࠩࡓࡖࠬ䫵"):l11lll_l1_ (u"ࠪࡔࡺ࡫ࡲࡵࡱࠣࡖ࡮ࡩ࡯ࠨ䫶")
		,l11lll_l1_ (u"ࠫࡖࡇࠧ䫷"):l11lll_l1_ (u"ࠬࡗࡡࡵࡣࡵࠫ䫸")
		,l11lll_l1_ (u"࠭ࡃࡈࠩ䫹"):l11lll_l1_ (u"ࠧࡓࡧࡳࡹࡧࡲࡩࡤࠢࡲࡪࠥࡺࡨࡦࠢࡆࡳࡳ࡭࡯ࠨ䫺")
		,l11lll_l1_ (u"ࠨࡔࡒࠫ䫻"):l11lll_l1_ (u"ࠩࡕࡳࡲࡧ࡮ࡪࡣࠪ䫼")
		,l11lll_l1_ (u"ࠪࡖ࡚࠭䫽"):l11lll_l1_ (u"ࠫࡗࡻࡳࡴ࡫ࡤࠫ䫾")
		,l11lll_l1_ (u"ࠬࡘࡗࠨ䫿"):l11lll_l1_ (u"࠭ࡒࡸࡣࡱࡨࡦ࠭䬀")
		,l11lll_l1_ (u"ࠧࡓࡇࠪ䬁"):l11lll_l1_ (u"ࠨࡔ࣬ࡹࡳ࡯࡯࡯ࠩ䬂")
		,l11lll_l1_ (u"ࠩࡅࡐࠬ䬃"):l11lll_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡅࡥࡷࡺࡨ࣪࡮ࡨࡱࡾ࠭䬄")
		,l11lll_l1_ (u"ࠫࡘࡎࠧ䬅"):l11lll_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡍ࡫࡬ࡦࡰࡤࠫ䬆")
		,l11lll_l1_ (u"࠭ࡋࡏࠩ䬇"):l11lll_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡋࡪࡶࡷࡷࠥࡧ࡮ࡥࠢࡑࡩࡻ࡯ࡳࠨ䬈")
		,l11lll_l1_ (u"ࠨࡎࡆࠫ䬉"):l11lll_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡎࡸࡧ࡮ࡧࠧ䬊")
		,l11lll_l1_ (u"ࠪࡑࡋ࠭䬋"):l11lll_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡑࡦࡸࡴࡪࡰࠪ䬌")
		,l11lll_l1_ (u"ࠬࡖࡍࠨ䬍"):l11lll_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡖࡩࡦࡴࡵࡩࠥࡧ࡮ࡥࠢࡐ࡭ࡶࡻࡥ࡭ࡱࡱࠫ䬎")
		,l11lll_l1_ (u"ࠧࡗࡅࠪ䬏"):l11lll_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡗ࡫ࡱࡧࡪࡴࡴࠡࡣࡱࡨࠥࡺࡨࡦࠢࡊࡶࡪࡴࡡࡥ࡫ࡱࡩࡸ࠭䬐")
		,l11lll_l1_ (u"࡚ࠩࡗࠬ䬑"):l11lll_l1_ (u"ࠪࡗࡦࡳ࡯ࡢࠩ䬒")
		,l11lll_l1_ (u"ࠫࡘࡓࠧ䬓"):l11lll_l1_ (u"࡙ࠬࡡ࡯ࠢࡐࡥࡷ࡯࡮ࡰࠩ䬔")
		,l11lll_l1_ (u"࠭ࡓࡂࠩ䬕"):l11lll_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭䬖")
		,l11lll_l1_ (u"ࠨࡕࡑࠫ䬗"):l11lll_l1_ (u"ࠩࡖࡩࡳ࡫ࡧࡢ࡮ࠪ䬘")
		,l11lll_l1_ (u"ࠪࡖࡘ࠭䬙"):l11lll_l1_ (u"ࠫࡘ࡫ࡲࡣ࡫ࡤࠫ䬚")
		,l11lll_l1_ (u"࡙ࠬࡃࠨ䬛"):l11lll_l1_ (u"࠭ࡓࡦࡻࡦ࡬ࡪࡲ࡬ࡦࡵࠪ䬜")
		,l11lll_l1_ (u"ࠧࡔࡎࠪ䬝"):l11lll_l1_ (u"ࠨࡕ࡬ࡩࡷࡸࡡࠡࡎࡨࡳࡳ࡫ࠧ䬞")
		,l11lll_l1_ (u"ࠩࡖࡋࠬ䬟"):l11lll_l1_ (u"ࠪࡗ࡮ࡴࡧࡢࡲࡲࡶࡪ࠭䬠")
		,l11lll_l1_ (u"ࠫࡘ࡞ࠧ䬡"):l11lll_l1_ (u"࡙ࠬࡩ࡯ࡶࠣࡑࡦࡧࡲࡵࡧࡱࠫ䬢")
		,l11lll_l1_ (u"࠭ࡓࡌࠩ䬣"):l11lll_l1_ (u"ࠧࡔ࡮ࡲࡺࡦࡱࡩࡢࠩ䬤")
		,l11lll_l1_ (u"ࠨࡕࡌࠫ䬥"):l11lll_l1_ (u"ࠩࡖࡰࡴࡼࡥ࡯࡫ࡤࠫ䬦")
		,l11lll_l1_ (u"ࠪࡗࡇ࠭䬧"):l11lll_l1_ (u"ࠫࡘࡵ࡬ࡰ࡯ࡲࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䬨")
		,l11lll_l1_ (u"࡙ࠬࡏࠨ䬩"):l11lll_l1_ (u"࠭ࡓࡰ࡯ࡤࡰ࡮ࡧࠧ䬪")
		,l11lll_l1_ (u"࡛ࠧࡃࠪ䬫"):l11lll_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡂࡨࡵ࡭ࡨࡧࠧ䬬")
		,l11lll_l1_ (u"ࠩࡊࡗࠬ䬭"):l11lll_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡊࡩࡴࡸࡧࡪࡣࠣࡥࡳࡪࠠࡵࡪࡨࠤࡘࡵࡵࡵࡪࠣࡗࡦࡴࡤࡸ࡫ࡦ࡬ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䬮")
		,l11lll_l1_ (u"ࠫࡐࡘࠧ䬯"):l11lll_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡐࡵࡲࡦࡣࠪ䬰")
		,l11lll_l1_ (u"࠭ࡓࡔࠩ䬱"):l11lll_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡓࡶࡦࡤࡲࠬ䬲")
		,l11lll_l1_ (u"ࠨࡇࡖࠫ䬳"):l11lll_l1_ (u"ࠩࡖࡴࡦ࡯࡮ࠨ䬴")
		,l11lll_l1_ (u"ࠪࡐࡐ࠭䬵"):l11lll_l1_ (u"ࠫࡘࡸࡩࠡࡎࡤࡲࡰࡧࠧ䬶")
		,l11lll_l1_ (u"࡙ࠬࡄࠨ䬷"):l11lll_l1_ (u"࠭ࡓࡶࡦࡤࡲࠬ䬸")
		,l11lll_l1_ (u"ࠧࡔࡔࠪ䬹"):l11lll_l1_ (u"ࠨࡕࡸࡶ࡮ࡴࡡ࡮ࡧࠪ䬺")
		,l11lll_l1_ (u"ࠩࡖࡎࠬ䬻"):l11lll_l1_ (u"ࠪࡗࡻࡧ࡬ࡣࡣࡵࡨࠥࡧ࡮ࡥࠢࡍࡥࡳࠦࡍࡢࡻࡨࡲࠬ䬼")
		,l11lll_l1_ (u"ࠫࡘࡠࠧ䬽"):l11lll_l1_ (u"࡙ࠬࡷࡢࡼ࡬ࡰࡦࡴࡤࠨ䬾")
		,l11lll_l1_ (u"࠭ࡓࡆࠩ䬿"):l11lll_l1_ (u"ࠧࡔࡹࡨࡨࡪࡴࠧ䭀")
		,l11lll_l1_ (u"ࠨࡅࡋࠫ䭁"):l11lll_l1_ (u"ࠩࡖࡻ࡮ࡺࡺࡦࡴ࡯ࡥࡳࡪࠧ䭂")
		,l11lll_l1_ (u"ࠪࡗ࡞࠭䭃"):l11lll_l1_ (u"ࠫࡘࡿࡲࡪࡣࠪ䭄")
		,l11lll_l1_ (u"࡙ࠬࡔࠨ䭅"):l11lll_l1_ (u"࠭ࡓࣤࡱࠣࡘࡴࡳࣩࠡࡣࡱࡨࠥࡖࡲ࣮ࡰࡦ࡭ࡵ࡫ࠧ䭆")
		,l11lll_l1_ (u"ࠧࡕ࡙ࠪ䭇"):l11lll_l1_ (u"ࠨࡖࡤ࡭ࡼࡧ࡮ࠨ䭈")
		,l11lll_l1_ (u"ࠩࡗࡎࠬ䭉"):l11lll_l1_ (u"ࠪࡘࡦࡰࡩ࡬࡫ࡶࡸࡦࡴࠧ䭊")
		,l11lll_l1_ (u"࡙ࠫࡠࠧ䭋"):l11lll_l1_ (u"࡚ࠬࡡ࡯ࡼࡤࡲ࡮ࡧࠧ䭌")
		,l11lll_l1_ (u"࠭ࡔࡉࠩ䭍"):l11lll_l1_ (u"ࠧࡕࡪࡤ࡭ࡱࡧ࡮ࡥࠩ䭎")
		,l11lll_l1_ (u"ࠨࡖࡊࠫ䭏"):l11lll_l1_ (u"ࠩࡗࡳ࡬ࡵࠧ䭐")
		,l11lll_l1_ (u"ࠪࡘࡐ࠭䭑"):l11lll_l1_ (u"࡙ࠫࡵ࡫ࡦ࡮ࡤࡹࠬ䭒")
		,l11lll_l1_ (u"࡚ࠬࡏࠨ䭓"):l11lll_l1_ (u"࠭ࡔࡰࡰࡪࡥࠬ䭔")
		,l11lll_l1_ (u"ࠧࡕࡖࠪ䭕"):l11lll_l1_ (u"ࠨࡖࡵ࡭ࡳ࡯ࡤࡢࡦࠣࡥࡳࡪࠠࡕࡱࡥࡥ࡬ࡵࠧ䭖")
		,l11lll_l1_ (u"ࠩࡗࡒࠬ䭗"):l11lll_l1_ (u"ࠪࡘࡺࡴࡩࡴ࡫ࡤࠫ䭘")
		,l11lll_l1_ (u"࡙ࠫࡘࠧ䭙"):l11lll_l1_ (u"࡚ࠬࡵࡳ࡭ࡨࡽࠬ䭚")
		,l11lll_l1_ (u"࠭ࡔࡎࠩ䭛"):l11lll_l1_ (u"ࠧࡕࡷࡵ࡯ࡲ࡫࡮ࡪࡵࡷࡥࡳ࠭䭜")
		,l11lll_l1_ (u"ࠨࡖࡆࠫ䭝"):l11lll_l1_ (u"ࠩࡗࡹࡷࡱࡳࠡࡣࡱࡨࠥࡉࡡࡪࡥࡲࡷࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䭞")
		,l11lll_l1_ (u"ࠪࡘ࡛࠭䭟"):l11lll_l1_ (u"࡙ࠫࡻࡶࡢ࡮ࡸࠫ䭠")
		,l11lll_l1_ (u"࡛ࠬࡍࠨ䭡"):l11lll_l1_ (u"࠭ࡕ࠯ࡕ࠱ࠤࡒ࡯࡮ࡰࡴࠣࡓࡺࡺ࡬ࡺ࡫ࡱ࡫ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭䭢")
		,l11lll_l1_ (u"ࠧࡗࡋࠪ䭣"):l11lll_l1_ (u"ࠨࡗ࠱ࡗ࠳ࠦࡖࡪࡴࡪ࡭ࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ䭤")
		,l11lll_l1_ (u"ࠩࡘࡋࠬ䭥"):l11lll_l1_ (u"࡙ࠪ࡬ࡧ࡮ࡥࡣࠪ䭦")
		,l11lll_l1_ (u"࡚ࠫࡇࠧ䭧"):l11lll_l1_ (u"࡛ࠬ࡫ࡳࡣ࡬ࡲࡪ࠭䭨")
		,l11lll_l1_ (u"࠭ࡁࡆࠩ䭩"):l11lll_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧ䭪")
		,l11lll_l1_ (u"ࠨࡗࡎࠫ䭫"):l11lll_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ䭬")
		,l11lll_l1_ (u"࡙ࠪࡘ࠭䭭"):l11lll_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ䭮")
		,l11lll_l1_ (u"࡛࡙ࠬࠨ䭯"):l11lll_l1_ (u"࠭ࡕࡳࡷࡪࡹࡦࡿࠧ䭰")
		,l11lll_l1_ (u"ࠧࡖ࡜ࠪ䭱"):l11lll_l1_ (u"ࠨࡗࡽࡦࡪࡱࡩࡴࡶࡤࡲࠬ䭲")
		,l11lll_l1_ (u"࡙࡙ࠩࠬ䭳"):l11lll_l1_ (u"࡚ࠪࡦࡴࡵࡢࡶࡸࠫ䭴")
		,l11lll_l1_ (u"࡛ࠫࡇࠧ䭵"):l11lll_l1_ (u"ࠬ࡜ࡡࡵ࡫ࡦࡥࡳࠦࡃࡪࡶࡼࠫ䭶")
		,l11lll_l1_ (u"࠭ࡖࡆࠩ䭷"):l11lll_l1_ (u"ࠧࡗࡧࡱࡩࡿࡻࡥ࡭ࡣࠪ䭸")
		,l11lll_l1_ (u"ࠨࡘࡑࠫ䭹"):l11lll_l1_ (u"࡙ࠩ࡭ࡪࡺ࡮ࡢ࡯ࠪ䭺")
		,l11lll_l1_ (u"࡛ࠪࡋ࠭䭻"):l11lll_l1_ (u"ࠫ࡜ࡧ࡬࡭࡫ࡶࠤࡦࡴࡤࠡࡈࡸࡸࡺࡴࡡࠨ䭼")
		,l11lll_l1_ (u"ࠬࡋࡈࠨ䭽"):l11lll_l1_ (u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ䭾")
		,l11lll_l1_ (u"࡚ࠧࡇࠪ䭿"):l11lll_l1_ (u"ࠨ࡛ࡨࡱࡪࡴࠧ䮀")
		,l11lll_l1_ (u"ࠩ࡝ࡑࠬ䮁"):l11lll_l1_ (u"ࠪ࡞ࡦࡳࡢࡪࡣࠪ䮂")
		,l11lll_l1_ (u"ࠫ࡟࡝ࠧ䮃"):l11lll_l1_ (u"ࠬࡠࡩ࡮ࡤࡤࡦࡼ࡫ࠧ䮄")
		,l11lll_l1_ (u"࠭ࡁ࡙ࠩ䮅"):l11lll_l1_ (u"ࠧࣆ࡮ࡤࡲࡩ࠭䮆")
		}
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3
#import l11ll11l111_l1_ as pickle
script_name = l11lll_l1_ (u"ࠬࡒࡉࡃࡕࡒࡒࡊ࠭㚮")
l11lll1l1l1_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"࠭ࡰࡢࡶ࡫ࠫ㚯"))
l11l1ll11l1_l1_ = os.path.join(l11lll1l1l1_l1_,l11lll_l1_ (u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩ㚰"))
sys.path.append(l11l1ll11l1_l1_)
l11lll111l1_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢ㚱"))
kodi_version = re.findall(l11lll_l1_ (u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭㚲"),l11lll111l1_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11l1l1lll1_l1_ = xbmc.LOGINFO
	ltr,rtl = l11lll_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫ㚳"),l11lll_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ㚴")
	l11ll1ll11l_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭㚵"))
	from urllib.parse import unquote as _11lll1111l_l1_
else:
	l11l1l1lll1_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l11lll_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ㚶").encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚷")),l11lll_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩ㚸").encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚹"))
	l11ll1ll11l_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ㚺"))
	from urllib import unquote as _11lll1111l_l1_
l11lllllll1_l1_ = 60
HOUR = 60*l11lllllll1_l1_
l11l1ll1lll_l1_ = 24*HOUR
l11lllll111_l1_ = 30*l11l1ll1lll_l1_
l11111l_l1_ = 3*l11l1ll1lll_l1_
PERMANENT_CACHE = 12*l11lllll111_l1_
addon_id = sys.argv[0].split(l11lll_l1_ (u"ࠫ࠴࠭㚻"))[2]	# plugin.video.l11l1ll1l1l_l1_
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
l1l111111l1_l1_ = addon_id.split(l11lll_l1_ (u"ࠬ࠴ࠧ㚼"))[2]		# l11l1ll1l1l_l1_
l11l1llllll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭㚽")+addon_id+l11lll_l1_ (u"ࠧࠪࠩ㚾"))
addoncachefolder = os.path.join(l11ll1ll11l_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡪࡡࡵࡣ࠱ࡨࡧ࠭㚿"))
l11ll1lllll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪ㛀"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1lll1l1ll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㛁"),l11lll_l1_ (u"ࠫࠬ㛂"),url,l11lll_l1_ (u"࡛ࠬࡒࡍࡆࡈࡇࡔࡊࡅࠨ㛃"))
	if l11lll_l1_ (u"࠭࠽ࠨ㛄") in url:
		if l11lll_l1_ (u"ࠧࡀࠩ㛅") in url: l11l11l_l1_,filters = url.split(l11lll_l1_ (u"ࠨࡁࠪ㛆"),1)
		else: l11l11l_l1_,filters = l11lll_l1_ (u"ࠩࠪ㛇"),url
		filters = filters.split(l11lll_l1_ (u"ࠪࠪࠬ㛈"))
		l11ll1l11_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㛉"),l11lll_l1_ (u"ࠬ࠭㛊"),filter,str(filters))
			key,value = filter.split(l11lll_l1_ (u"࠭࠽ࠨ㛋"),1)
			l11ll1l11_l1_[key] = value
	else: l11l11l_l1_,l11ll1l11_l1_ = url,{}
	return l11l11l_l1_,l11ll1l11_l1_
def l111l_l1_(urll):
	return _11lll1111l_l1_(urll)
	#return urllib2.unquote(urll)
def EXTRACT_KODI_PATH(l11l1ll1ll1_l1_):
	l1l1111lll1_l1_ = {l11lll_l1_ (u"ࠧࡵࡻࡳࡩࠬ㛌"):l11lll_l1_ (u"ࠨࠩ㛍"),l11lll_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ㛎"):l11lll_l1_ (u"ࠪࠫ㛏"),l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ㛐"):l11lll_l1_ (u"ࠬ࠭㛑"),l11lll_l1_ (u"࠭ࡴࡦࡺࡷࠫ㛒"):l11lll_l1_ (u"ࠧࠨ㛓"),l11lll_l1_ (u"ࠨࡲࡤ࡫ࡪ࠭㛔"):l11lll_l1_ (u"ࠩࠪ㛕"),l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ㛖"):l11lll_l1_ (u"ࠫࠬ㛗"),l11lll_l1_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ㛘"):l11lll_l1_ (u"࠭ࠧ㛙"),l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ㛚"):l11lll_l1_ (u"ࠨࠩ㛛"),l11lll_l1_ (u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ㛜"):l11lll_l1_ (u"ࠪࠫ㛝")}
	if l11lll_l1_ (u"ࠫࡄ࠭㛞") in l11l1ll1ll1_l1_: l11l1ll1ll1_l1_ = l11l1ll1ll1_l1_.split(l11lll_l1_ (u"ࠬࡅࠧ㛟"),1)[1]
	l11l11l_l1_,l1l1111ll1l_l1_ = l1lll1l1ll_l1_(l11l1ll1ll1_l1_)
	args = dict(list(l1l1111lll1_l1_.items())+list(l1l1111ll1l_l1_.items()))
	l11l1ll11ll_l1_ = args[l11lll_l1_ (u"࠭࡭ࡰࡦࡨࠫ㛠")]
	l11lll11ll1_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ㛡")])
	l11ll1l11l1_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭㛢")])
	l11l1l1ll11_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ㛣")])
	l11l1l1l1ll_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠪࡸࡾࡶࡥࠨ㛤")])
	l11ll1l11ll_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㛥")])
	l11lll1llll_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ㛦")])
	l11ll1l1111_l1_ = args[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ㛧")]
	l11lll11111_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ㛨")])
	if l11lll11111_l1_: l11lll11111_l1_ = eval(l11lll11111_l1_)
	else: l11lll11111_l1_ = {}
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ㛩"))
	#l11l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ㛪"))
	if not l11l1ll11ll_l1_: l11l1l1l1ll_l1_ = l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㛫") ; l11l1ll11ll_l1_ = l11lll_l1_ (u"ࠫ࠷࠼࠰ࠨ㛬")
	return l11l1l1l1ll_l1_,l11ll1l11ll_l1_,l11lll11ll1_l1_,l11l1ll11ll_l1_,l11lll1llll_l1_,l11l1l1ll11_l1_,l11ll1l11l1_l1_,l11ll1l1111_l1_,l11lll11111_l1_
def LOGGING(script_name):
	l11ll1l111l_l1_ = sys._getframe(1).f_code.co_name
	if not script_name or not l11ll1l111l_l1_ or l11ll1l111l_l1_==l11lll_l1_ (u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧ㛭"):
		return l11lll_l1_ (u"࡛࠭ࠡࠩ㛮")+l1l111111l1_l1_.upper()+l11lll_l1_ (u"ࠧ࠮ࠩ㛯")+l11l1llllll_l1_+l11lll_l1_ (u"ࠨ࠯ࠪ㛰")+str(kodi_version)+l11lll_l1_ (u"ࠩࠣࡡࠬ㛱")
	return l11lll_l1_ (u"ࠪ࠲ࠥࠦࠧ㛲")+l11ll1l111l_l1_
def LOG_THIS(level,message):
	if kodi_version<19: message = message.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㛳")).encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㛴"))
	l11ll11111l_l1_ = l11l1l1lll1_l1_
	lines = [l11lll_l1_ (u"࠭ࠧ㛵"),l11lll_l1_ (u"ࠧࠨ㛶")]
	if level: message = message.replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㛷"),l11lll_l1_ (u"ࠩࠪ㛸")).replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㛹"),l11lll_l1_ (u"ࠫࠬ㛺")).replace(l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㛻"),l11lll_l1_ (u"࠭ࠧ㛼"))
	else: level = l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㛽")
	l111l1lll1_l1_,sep,shift = l11lll_l1_ (u"ࠨࠢࠣࠤࠥ࠭㛾"),l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㛿"),l11lll_l1_ (u"ࠪࠫ㜀")
	if l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㜁") in level: l11ll11111l_l1_ = xbmc.LOGERROR
	if level==l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㜂"):
		message = message+sep
		lines = message.split(sep)
		shift = l111l1lll1_l1_
	elif level==l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ㜃"):
		message = message.replace(l11lll_l1_ (u"ࠧ࠯ࠩ㜄")+sep,l11lll_l1_ (u"ࠨ࠰ࠣࠤࠬ㜅"))
		lines = message.split(sep)
		lines[0] = l11lll_l1_ (u"ࠩ࠱ࠫ㜆")+lines[0][1:]
		shift = l111l1lll1_l1_+sep
	elif level in [l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㜇"),l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㜈")]: lines = message.split(l111l1lll1_l1_)
	shift += 6*l111l1lll1_l1_
	l11ll111l1l_l1_ = 3*l111l1lll1_l1_
	if kodi_version>17.99: shift += 11*l11lll_l1_ (u"ࠬࠦࠧ㜉")
	l11llll1lll_l1_ = lines[0]
	for line in lines[1:]:
		if l11lll_l1_ (u"࠭࡜࡯ࠩ㜊") in line: line = line.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ㜋"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ㜌")+l111l1lll1_l1_+l111l1lll1_l1_)
		l11ll111l1l_l1_ += l111l1lll1_l1_
		l11llll1lll_l1_ += l11lll_l1_ (u"ࠩ࡟ࡶࠬ㜍")+shift+l11ll111l1l_l1_+line
	l11llll1lll_l1_ += l11lll_l1_ (u"ࠪࠤࡤ࠭㜎")
	if l11lll_l1_ (u"ࠫࠪ࠭㜏") in l11llll1lll_l1_: l11llll1lll_l1_ = l111l_l1_(l11llll1lll_l1_)
	xbmc.log(l11llll1lll_l1_,level=l11ll11111l_l1_)
	return
def l1l11111l1l_l1_(l1l1ll11ll_l1_):
	conn = sqlite3.connect(l1l1ll11ll_l1_)
	cc = conn.cursor()
	cc.execute(l11lll_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱ࠾ࠫ㜐"))
	cc.execute(l11lll_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡦࡰࡴࡨ࡭࡬ࡴ࡟࡬ࡧࡼࡷࡂࡴ࡯࠼ࠩ㜑"))
	cc.execute(l11lll_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡩࡱࡳࡷ࡫࡟ࡤࡪࡨࡧࡰࡥࡣࡰࡰࡶࡸࡷࡧࡩ࡯ࡶࡶࡁࡾ࡫ࡳ࠼ࠩ㜒"))
	cc.execute(l11lll_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫࠽ࡐࡈࡉ࠿ࠬ㜓"))
	cc.execute(l11lll_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧ㜔"))
	cc.execute(l11lll_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡷࡾࡴࡣࡩࡴࡲࡲࡴࡻࡳ࠾ࡑࡉࡊࡀ࠭㜕"))
	conn.text_factory = str
	return conn,cc
def DELETE_FROM_SQL3(l1l1ll11ll_l1_,table,l11lll11l1l_l1_=None):
	try: conn,cc = l1l11111l1l_l1_(l1l1ll11ll_l1_)
	except: return
	if l11lll11l1l_l1_==None: cc.execute(l11lll_l1_ (u"ࠫࡉࡘࡏࡑࠢࡗࡅࡇࡒࡅࠡࡋࡉࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㜖")+table+l11lll_l1_ (u"ࠬࠨࠠ࠼ࠩ㜗"))
	else:
		tt = (str(l11lll11l1l_l1_),)
		try:
			if l11lll_l1_ (u"࠭ࠥࠨ㜘") in l11lll11l1l_l1_: cc.execute(l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㜙")+table+l11lll_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢ࡯࡭ࡰ࡫ࠠࡀࠢ࠾ࠫ㜚"),tt)
			else: cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㜛")+table+l11lll_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㜜"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l11lllll11l_l1_(): pass
class l1l1111l111_l1_(l11lllll11l_l1_):
	def __init__(self):
		self.url = l11lll_l1_ (u"ࠫࠬ㜝")
		self.code = -99
		self.reason = l11lll_l1_ (u"ࠬ࠭㜞")
		self.content = l11lll_l1_ (u"࠭ࠧ㜟")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l11lll11l11_l1_(type):
	if type==l11lll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㜠"): data = {}
	elif type==l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㜡"): data = []
	elif type==l11lll_l1_ (u"ࠩࡶࡸࡷ࠭㜢"): data = l11lll_l1_ (u"ࠪࠫ㜣")
	elif type==l11lll_l1_ (u"ࠫ࡮ࡴࡴࠨ㜤"): data = 0
	elif type==l11lll_l1_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ㜥"): data = l1l1111l111_l1_()
	elif not type: data = None
	else: data = None
	return data
def READ_FROM_SQL3(l1l1ll11ll_l1_,l11lll1ll11_l1_,table,l11lll11l1l_l1_=None):
	data = l11lll11l11_l1_(l11lll1ll11_l1_)
	cache = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㜦"))
	if table!=l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㜧") and l1l1ll11ll_l1_==main_dbfile:
		if cache==l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭㜨"): return data
		l1l1l11111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㜩"))
		if l1l1l11111_l1_==l11lll_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㜪"):
			DELETE_FROM_SQL3(l1l1ll11ll_l1_,table,l11lll11l1l_l1_)
			return data
	l1l111l111l_l1_ = 0
	if cache==l11lll_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ㜫"): l1l111l111l_l1_ = l11l1lllll1_l1_
	try: conn,cc = l1l11111l1l_l1_(l1l1ll11ll_l1_)
	except: return data
	l11ll1llll1_l1_ = True
	try: cc.execute(l11lll_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥࠨࠧ㜬")+table+l11lll_l1_ (u"࠭ࠢࠡࡎࡌࡑࡎ࡚ࠠ࠲ࠢ࠾ࠫ㜭"))
	except: l11ll1llll1_l1_ = False
	if l11ll1llll1_l1_:
		if l1l111l111l_l1_: cc.execute(l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㜮")+table+l11lll_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺࡀࠪ㜯")+str(now+l1l111l111l_l1_)+l11lll_l1_ (u"ࠩࠣ࠿ࠬ㜰"))
		conn.commit()
		cc.execute(l11lll_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㜱")+table+l11lll_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡁ࠭㜲")+str(now)+l11lll_l1_ (u"ࠬࠦ࠻ࠨ㜳"))
		conn.commit()
		if l11lll11l1l_l1_:
			tt = (str(l11lll11l1l_l1_),)
			cc.execute(l11lll_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ㜴")+table+l11lll_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㜵"),tt)
			l11ll1ll111_l1_ = cc.fetchall()
			if l11ll1ll111_l1_:
				try:
					text = zlib.decompress(l11ll1ll111_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11lll_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㜶")+table+l11lll_l1_ (u"ࠩࠥࠤࡀ࠭㜷"))
			l11ll1ll111_l1_ = cc.fetchall()
			if l11ll1ll111_l1_:
				data,l1l11111l11_l1_ = {},[]
				for l11llll1ll1_l1_,l11ll1l11_l1_ in l11ll1ll111_l1_:
					l1l1l1lll1_l1_ = zlib.decompress(l11ll1l11_l1_)
					l11ll1l11_l1_ = pickle.loads(l1l1l1lll1_l1_)
					data[l11llll1ll1_l1_] = l11ll1l11_l1_
					l1l11111l11_l1_.append(l11llll1ll1_l1_)
				if l1l11111l11_l1_:
					data[l11lll_l1_ (u"ࠪࡣࡤ࡙ࡅࡒࡗࡈࡒࡈࡋࡄࡠࡅࡒࡐ࡚ࡓࡎࡔࡡࡢࠫ㜸")] = l1l11111l11_l1_
					if l11lll1ll11_l1_==l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㜹"): data = l1l11111l11_l1_
	conn.close()
	return data
def l11ll1lll11_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l11llll1111_l1_(length,l11llllll11_l1_=True):
	#return l11lll_l1_ (u"ࠬ࠿࠹࠱࠸࠰࠺࠵࠺࠳࠮࠵࠼࠺࠻࠳࠶࠱࠸࠺࠱࠷࠹࠲࠸ࠩ㜺")
	l11l1l1ll1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡊࡒࡄࡨࡩࡸࡥࡴࡵࠪ㜻"))
	l11llll11l1_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭㜼"))
	if l11llllll11_l1_:
		try: l11llll1ll_l1_,l1l11111111_l1_,l11ll111l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㜽"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㜾"),l11lll_l1_ (u"ࠪࡍࡉ࡙ࠧ㜿"))
		except: l11llll1ll_l1_,l1l11111111_l1_,l11ll111l11_l1_ = l11lll_l1_ (u"ࠫࠬ㝀"),l11lll_l1_ (u"ࠬ࠭㝁"),l11lll_l1_ (u"࠭ࠧ㝂")
		if l11llll1ll_l1_ and l11l1l1ll1l_l1_==l1l11111111_l1_ and l11llll11l1_l1_==l11ll111l11_l1_: return l11llll1ll_l1_
	#import uuid
	#node = str(uuid.getnode())
	#l11llll1l11_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡏࡧࡷࡻࡴࡸ࡫࠯ࡏࡤࡧࡆࡪࡤࡳࡧࡶࡷࠬ㝃"))
	#if l11llll1l11_l1_.count(l11lll_l1_ (u"ࠨ࠼ࠪ㝄"))==5 and l11llll1l11_l1_.count(l11lll_l1_ (u"ࠩ࠳ࠫ㝅"))<9: l11ll111ll1_l1_ = l11llll1l11_l1_
	global mac
	length = length//2
	import threading
	l11l1lll1l1_l1_ = threading.Thread(target=l11ll1lll11_l1_,args=())
	l11l1lll1l1_l1_.start()
	mac = l11lll_l1_ (u"ࠪࠫ㝆")
	for l11ll111l1_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11lll_l1_ (u"ࠫ࠵࠶࠱࠲࠴࠵࠷࠸࠺࠴࠶࠷࠹࠺࠼࠽ࠧ㝇")
	else:
		mac = mac.replace(l11lll_l1_ (u"ࠬࡀࠧ㝈"),l11lll_l1_ (u"࠭ࠧ㝉"))
		node = str(int(mac,16))
	node = re.findall(l11lll_l1_ (u"ࠧ࡜࠲࠰࠽ࡢ࠱ࠧ㝊"),node,re.DOTALL)
	node = length*l11lll_l1_ (u"ࠨ࠲ࠪ㝋")+node[0]
	node = node[-length:]
	mm,ss = l11lll_l1_ (u"ࠩࠪ㝌"),l11lll_l1_ (u"ࠪࠫ㝍")
	l11ll1l1l1l_l1_ = str(int(l11lll_l1_ (u"ࠫ࠾࠭㝎")*(length+1))-int(node))[-length:]
	for l11ll111l1_l1_ in list(range(0,length,4)):
		l11l1llll1l_l1_ = l11ll1l1l1l_l1_[l11ll111l1_l1_:l11ll111l1_l1_+4]
		mm += l11l1llll1l_l1_+l11lll_l1_ (u"ࠬ࠳ࠧ㝏")
		ss += str(sum(map(int,node[l11ll111l1_l1_:l11ll111l1_l1_+4]))%10)
	l1l1111l11l_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㝐"),l11lll_l1_ (u"ࠧࡊࡆࡖࠫ㝑"),[l1l1111l11l_l1_,l11l1l1ll1l_l1_,l11llll11l1_l1_],l11111l_l1_)
	return l1l1111l11l_l1_
def l11l1llll11_l1_(l1l1111ll11_l1_):
	l11ll11ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㝒"))
	#l1l1111ll11_l1_ = l1l1111ll11_l1_.encode(l11lll_l1_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ㝓")).replace(l11lll_l1_ (u"ࠪࡠࡳ࠭㝔"),l11lll_l1_ (u"ࠫࠬ㝕"))
	user = l11llll1111_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11lll_l1_ (u"ࠬ࡞࠱࠺ࠩ㝖")+l1l1111ll11_l1_+l11lll_l1_ (u"࠭࠱࠹࠿ࠪ㝗")+user).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㝘"))).hexdigest()[0:32]
	if md5 in l11ll11ll11_l1_: return True
	return False
class l11lll1l11l_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11lll_l1_ (u"ࠨࠩ㝙")
		if l11l1llll11_l1_(l11lll_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㝚")) or not l11l1llll11_l1_(l11lll_l1_ (u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫ㝛")):
			self.status = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㝜")
			import l11ll1ll1l1_l1_
			l11ll1ll1l1_l1_.l11lll1l111_l1_(False)
	def onPlayBackStopped(self):
		self.status=l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㝝")
	def onPlayBackStarted(self):
		self.status = l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㝞")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㝟")
	def onPlayBackEnded(self):
		self.status = l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㝠")
def l11lll1ll1l_l1_(type,url,data,headers,source,method):
	l1l1ll1ll_l1_ = str(headers)[0:250].replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ㝡"),l11lll_l1_ (u"ࠪࡠࡡࡴࠧ㝢")).replace(l11lll_l1_ (u"ࠫࡡࡸࠧ㝣"),l11lll_l1_ (u"ࠬࡢ࡜ࡳࠩ㝤")).replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ㝥"),l11lll_l1_ (u"ࠧࠡࠩ㝦")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㝧"),l11lll_l1_ (u"ࠩࠣࠫ㝨"))
	if len(str(headers))>250: l1l1ll1ll_l1_ = l1l1ll1ll_l1_+l11lll_l1_ (u"ࠪࠤ࠳࠴࠮ࠨ㝩")
	l11ll1l11_l1_ = str(data)[0:250].replace(l11lll_l1_ (u"ࠫࡡࡴࠧ㝪"),l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ㝫")).replace(l11lll_l1_ (u"࠭࡜ࡳࠩ㝬"),l11lll_l1_ (u"ࠧ࡝࡞ࡵࠫ㝭")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠥ࠭㝮"),l11lll_l1_ (u"ࠩࠣࠫ㝯")).replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠧ㝰"),l11lll_l1_ (u"ࠫࠥ࠭㝱"))
	if len(str(data))>250: l11ll1l11_l1_ = l11ll1l11_l1_+l11lll_l1_ (u"ࠬࠦ࠮࠯࠰ࠪ㝲")
	LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㝳"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣࠬ㝴")+type+l11lll_l1_ (u"ࠨ࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㝵")+url+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㝶")+source+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬ㝷")+method+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ㝸")+str(l1l1ll1ll_l1_)+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬ㝹")+l11ll1l11_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㝺"))
	return
def l1lllll11l_l1_(method,url,data=l11lll_l1_ (u"ࠧࠨ㝻"),headers=l11lll_l1_ (u"ࠨࠩ㝼"),source=l11lll_l1_ (u"ࠩࠪ㝽")):
	l11lll1ll1l_l1_(l11lll_l1_ (u"࡙ࠪࡗࡒࡌࡊࡄࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭㝾"),url,data,headers,source,method)
	if kodi_version>18.99: import urllib.request as l11lllll1ll_l1_
	else: import urllib2 as l11lllll1ll_l1_
	if not headers: headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㝿"):l11lll_l1_ (u"ࠬ࠭㞀")}
	if not data: data = {}
	if method==l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㞁"):
		url = url+l11lll_l1_ (u"ࠧࡀࠩ㞂")+l1ll1l1ll_l1_(data)
		data = None
	elif method==l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㞃"): data = data.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㞄"))
	try:
		req = l11lllll1ll_l1_.Request(url,headers=headers,data=data)
		response = l11lllll1ll_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l11lll_l1_ (u"ࠪࡓࡐ࠭㞅")
	except:
		html = l11lll_l1_ (u"ࠫࠬ㞆")
		code,reason = -1,l11lll_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ㞇")
	LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㞈"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠤࠥࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ㞉")+str(code)+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㞊")+reason+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㞋")+source+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㞌")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㞍"))
	#try:
	#	req = l11lllll1ll_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	response = l11lllll1ll_l1_.urlopen(req)
	#	html = response.read()
	#except: html = l11lll_l1_ (u"ࠬ࠭㞎")
	return html
def l1l1111l1ll_l1_(script_name):
	# https://www.l1l1111111l_l1_.l11ll111lll_l1_.l11ll11l1l1_l1_.com/l11llll11ll_l1_/l11ll11llll_l1_/http-l11l1ll111l_l1_-l11ll1ll1ll_l1_
	# https://help.l11ll11l1l1_l1_.com/l11ll11ll1l_l1_/l11llll1l1l_l1_-l1ll1l1ll1l_l1_/l11llllll1l_l1_/215562387-l11ll1l1l11_l1_-property-l11l1l1l1l1_l1_
	# https://www.l1l1111111l_l1_.l11ll111lll_l1_.l11ll11l1l1_l1_.com/l11llll11ll_l1_/l11ll11llll_l1_/l11ll11l1ll_l1_-rest-l11ll1ll1ll_l1_
	l11ll11l11l_l1_ = str(random.randrange(111111111111,999999999999))
	#l11ll1lll1l_l1_ = l11l1l1llll_l1_()
	#l1l1111l1l1_l1_ = l11ll1lll1l_l1_.split(l11lll_l1_ (u"࠭ࠬࠨ㞏"),1)[0]
	headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㞐"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ㞑")}
	data = {l11lll_l1_ (u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ㞒"):l11lll_l1_ (u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ㞓"),
			l11lll_l1_ (u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ㞔"):l11ll11l11l_l1_,
			l11lll_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ㞕"): [{
				l11lll_l1_ (u"ࠨࡵࡴࡧࡵࡣ࡮ࡪࠢ㞖"):l11llll1111_l1_(32),
				l11lll_l1_ (u"ࠢࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠦ㞗"):str(kodi_version),
				l11lll_l1_ (u"ࠣࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ㞘"):l11l1llllll_l1_,
				l11lll_l1_ (u"ࠤࡦࡥࡷࡸࡩࡦࡴࠥ㞙"):l11l1llllll_l1_,
				l11lll_l1_ (u"ࠥࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠢ㞚"):script_name,
				l11lll_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠢ㞛"):{l11lll_l1_ (u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㞜"):script_name},
				l11lll_l1_ (u"ࠨࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠣ㞝"): {l11lll_l1_ (u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤ㞞"):script_name},
				l11lll_l1_ (u"ࠣࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠥ㞟"): l11lll_l1_ (u"ࠤࡄࡖࡆࡈࡉࡄࡡ࡙ࡍࡉࡋࡏࡔࠤ㞠"),
				l11lll_l1_ (u"ࠥࠨࡸࡱࡩࡱࡡࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࡣࡸࡿ࡮ࡤࠤ㞡"):False,
				l11lll_l1_ (u"ࠦ࡮ࡶࠢ㞢"): l11lll_l1_ (u"ࠧࠪࡲࡦ࡯ࡲࡸࡪࠨ㞣")
			}]
		}
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ㞤")
	import json
	data = json.dumps(data)
	#response = l11lll111ll_l1_(l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㞥"),url,data,headers,l11lll_l1_ (u"ࠨࠩ㞦"),l11lll_l1_ (u"ࠩࠪ㞧"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ㞨"),False,False)
	response = l1lllll11l_l1_(l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ㞩"),url,data,headers,script_name)
	return response
def l11llll111l_l1_(url,script_name,type):
	l11l1ll1111_l1_ = xbmcgui.ListItem()
	l11ll1l1ll1_l1_ = l11lll1l11l_l1_()
	if l11ll1l1ll1_l1_.status: LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㞪"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㞫")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㞬"))
	else:
		if type==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㞭"):
			l11l1ll1111_l1_.setPath(url)
			LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㞮"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡓࡪ࡯ࡳࡰࡪࠦࡶࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㞯")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㞰"))
			xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll1111_l1_)
		else:
			LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㞱"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖ࡭ࡲࡶ࡬ࡦࠢ࡯࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㞲")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㞳"))
			l11ll1l1ll1_l1_.play(url,l11l1ll1111_l1_)
		l11lll1lll1_l1_()
		timeout = 5
		for l11ll111l1_l1_ in range(timeout):
			# l11l1ll1l11_l1_ l1l11111lll_l1_
			#	if using time.sleep() l11l1lll11l_l1_ of xbmc.sleep() l1l111111ll_l1_ the l11ll1111l1_l1_ status
			#	l11lll_l1_ (u"ࠣ࡯ࡼࡴࡱࡧࡹࡦࡴ࠱ࡷࡹࡧࡴࡶࡵࠥ㞴") will stop l11ll1l1lll_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l1111_l1_ = l11ll1l1ll1_l1_.status
			if l1l111l1111_l1_ in [l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㞵"),l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㞶")]: break
		if l1l111l1111_l1_==l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㞷"): response = l1l1111l1ll_l1_(script_name)
	return
def EVAL(l11lll1ll11_l1_,text):
	#text = text.replace(l11lll_l1_ (u"ࠧࡻࠧࠣ㞸"),l11lll_l1_ (u"ࠨࠧࠣ㞹"))
	text = text.replace(l11lll_l1_ (u"ࠧ࡯ࡷ࡯ࡰࠬ㞺"),l11lll_l1_ (u"ࠨࡐࡲࡲࡪ࠭㞻"))
	text = text.replace(l11lll_l1_ (u"ࠩࡷࡶࡺ࡫ࠧ㞼"),l11lll_l1_ (u"ࠪࡘࡷࡻࡥࠨ㞽"))
	text = text.replace(l11lll_l1_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ㞾"),l11lll_l1_ (u"ࠬࡌࡡ࡭ࡵࡨࠫ㞿"))
	text = text.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ㟀"),l11lll_l1_ (u"ࠧ࠰ࠩ㟁"))
	try: l1l1l1lll1_l1_ = eval(text)
	except: l1l1l1lll1_l1_ = l11lll11l11_l1_(l11lll1ll11_l1_)
	return l1l1l1lll1_l1_
def l11lll1lll1_l1_():
	type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ㟂"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11lll_l1_ (u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ㟃"),time.localtime(now))
	name = name+datetime
	l1l1l1l11l1_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll11111l1_l1_
	if os.path.exists(l11ll1lllll_l1_):
		l11ll11lll1_l1_ = open(l11ll1lllll_l1_,l11lll_l1_ (u"ࠪࡶࡧ࠭㟄")).read()
		if kodi_version>18.99: l11ll11lll1_l1_ = l11ll11lll1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㟅"))
		l11ll11lll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ㟆"),l11ll11lll1_l1_)
	else: l11ll11lll1_l1_ = {}
	l11ll111111_l1_ = {}
	for l11llllllll_l1_ in list(l11ll11lll1_l1_.keys()):
		if l11llllllll_l1_!=type: l11ll111111_l1_[l11llllllll_l1_] = l11ll11lll1_l1_[l11llllllll_l1_]
		else:
			if name and name!=l11lll_l1_ (u"࠭࠮࠯ࠩ㟇"):
				l11l1lll1ll_l1_ = l11ll11lll1_l1_[l11llllllll_l1_]
				if l1l1l1l11l1_l1_ in l11l1lll1ll_l1_:
					index = l11l1lll1ll_l1_.index(l1l1l1l11l1_l1_)
					del l11l1lll1ll_l1_[index]
				l1ll1ll1l11_l1_ = [l1l1l1l11l1_l1_]+l11l1lll1ll_l1_
				l1ll1ll1l11_l1_ = l1ll1ll1l11_l1_[:50]
				l11ll111111_l1_[l11llllllll_l1_] = l1ll1ll1l11_l1_
			else: l11ll111111_l1_[l11llllllll_l1_] = l11ll11lll1_l1_[l11llllllll_l1_]
	if type not in list(l11ll111111_l1_.keys()): l11ll111111_l1_[type] = [l1l1l1l11l1_l1_]
	l11ll111111_l1_ = str(l11ll111111_l1_)
	if kodi_version>18.99: l11ll111111_l1_ = l11ll111111_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㟈"))
	open(l11ll1lllll_l1_,l11lll_l1_ (u"ࠨࡹࡥࠫ㟉")).write(l11ll111111_l1_)
	return
def WRITE_TO_SQL3(l1l1ll11ll_l1_,table,l11lll11l1l_l1_,data,l11lll1l1ll_l1_,l11lllll1l1_l1_=False):
	cache = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㟊"))
	if cache==l11lll_l1_ (u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫ㟋") and l11lll1l1ll_l1_>l11l1lllll1_l1_: l11lll1l1ll_l1_ = l11l1lllll1_l1_
	if l11lllll1l1_l1_:
		l11l1llll_l1_,l11ll1111_l1_ = [],[]
		for l11ll111l1_l1_ in range(len(l11lll11l1l_l1_)):
			text = pickle.dumps(data[l11ll111l1_l1_])
			l11ll1111ll_l1_ = zlib.compress(text)
			l11l1llll_l1_.append((l11lll11l1l_l1_[l11ll111l1_l1_],))
			l11ll1111_l1_.append((l11lll1l1ll_l1_+now,str(l11lll11l1l_l1_[l11ll111l1_l1_]),l11ll1111ll_l1_))
	else:
		text = pickle.dumps(data)
		l11lll11lll_l1_ = zlib.compress(text)
	try: conn,cc = l1l11111l1l_l1_(l1l1ll11ll_l1_)
	except: return
	while True:
		try:
			cc.execute(l11lll_l1_ (u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭㟌"))
			break
		except: time.sleep(0.5)
	cc.execute(l11lll_l1_ (u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭㟍")+table+l11lll_l1_ (u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪ㟎"))
	if l11lllll1l1_l1_:
		cc.executemany(l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧ㟏")+table+l11lll_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㟐"),l11l1llll_l1_)
		cc.executemany(l11lll_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ㟑")+table+l11lll_l1_ (u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨ㟒"),l11ll1111_l1_)
	else:
		if l11lll1l1ll_l1_:
			tt = (str(l11lll11l1l_l1_),)
			cc.execute(l11lll_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㟓")+table+l11lll_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㟔"),tt)
			tt = (l11lll1l1ll_l1_+now,str(l11lll11l1l_l1_),l11lll11lll_l1_)
			cc.execute(l11lll_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭㟕")+table+l11lll_l1_ (u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ㟖"),tt)
		else:
			tt = (l11lll11lll_l1_,str(l11lll11l1l_l1_))
			cc.execute(l11lll_l1_ (u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ㟗")+table+l11lll_l1_ (u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ㟘"),tt)
	conn.commit()
	conn.close()
	return
def l1ll1l1ll_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l11111ll1_l1_
	else: import urllib as l1l11111ll1_l1_
	l1l1111llll_l1_ = l1l11111ll1_l1_.urlencode(data)
	return l1l1111llll_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ洏")
headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ洐"):l11lll_l1_ (u"ࠬ࠭洑")}
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ洒")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ洓"),l11lll_l1_ (u"ࠨࡹࡺࡩࠬ洔")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1111l_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llllll_l1_(url,text)
	elif mode==564: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ洕")+text)
	elif mode==565: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ洖")+text)
	elif mode==566: results = l1l11l_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ洗"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭洘"),l11lll_l1_ (u"࠭ࠧ洙"),False,l11lll_l1_ (u"ࠧࠨ洚"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ洛"))
	#hostname = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ洜")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠪ࠳ࠬ洝"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ洞")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ洟"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ洠"),l11lll_l1_ (u"ࠧࠨ洡"),l11lll_l1_ (u"ࠨࠩ洢"),l11lll_l1_ (u"ࠩࠪ洣"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ洤"))
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ津"),l111ll_l1_+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ洦"),l11lll_l1_ (u"࠭ࠧ洧"),8)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ洨"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ洩"),l11lll_l1_ (u"ࠩࠪ洪"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ洫"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ洬"),l11ll1_l1_,569,l11lll_l1_ (u"ࠬ࠭洭"),l11lll_l1_ (u"࠭ࠧ洮"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ洯"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ洰"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ洱"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ洲"),564)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ洳"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ洴"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭洵"),565)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ洶"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ洷"),l11lll_l1_ (u"ࠩࠪ洸"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ洹"):hostname,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ洺"):l11lll_l1_ (u"ࠬ࠭活")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ洼"),l11lll_l1_ (u"ࠧ࠰ࠩ洽"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࡢࡢࡴࠫ࠲࠯ࡅࠩࡧ࡫࡯ࡸࡪࡸࠧ派"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ洿"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠪࠩࡩ࠿ࠥ࠹࠷ࠨࡨ࠽ࠫࡢ࠶ࠧࡧ࠼ࠪࡧ࠷ࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡦ࠾ࠫࡤ࠹ࠧࡤ࠽࠲ࠫࡤ࠹ࠧࡤࡨࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡢ࠻ࠪ浀") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ流"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ浂")+l111ll_l1_+title,link,566)
	#	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ浃"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ浄"),l11lll_l1_ (u"ࠨࠩ浅"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭浆"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ浇"),l11lll_l1_ (u"ࠫࠬ浈"),l11lll_l1_ (u"ࠬ࠭浉"),l11lll_l1_ (u"࠭ࠧ浊"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ测"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡷࡑ࡯ࡳࡵࡄࡸࡸࡹࡵ࡮ࠣࠩ浌"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭浍"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ济") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ浏"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠬ࠭浐"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭浑"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ浒")+l111ll_l1_+title,link,566)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭浓"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ浔"),l11lll_l1_ (u"ࠪࠫ浕"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭浖"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ浗"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭浘"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ浙")+l111ll_l1_+title,link,566,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ浚"),l11lll_l1_ (u"ࠩࠪ浛"),url,l11lll_l1_ (u"ࠪࠫ浜"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ浝"):url,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ浞"):l11lll_l1_ (u"࠭ࠧ浟")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ浠"),url,l11lll_l1_ (u"ࠨࠩ浡"),l11lll_l1_ (u"ࠩࠪ浢"),l11lll_l1_ (u"ࠪࠫ浣"),l11lll_l1_ (u"ࠫࠬ浤"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ浥"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭浦"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ浧"),url,564)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ浨"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ浩"),url,565)
	if l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ浪") in html:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ浫"),l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭浬"),url,561,l11lll_l1_ (u"࠭ࠧ浭"),l11lll_l1_ (u"ࠧࠨ浮"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ浯"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ浰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭浱"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ浲"),l111ll_l1_+title,link,561)
	return
def l1111l_l1_(l1ll11l111l1_l1_,type=l11lll_l1_ (u"ࠬ࠭浳")):
	if l11lll_l1_ (u"࠭࠺࠻ࠩ浴") in l1ll11l111l1_l1_:
		l11l1l1_l1_,url = l1ll11l111l1_l1_.split(l11lll_l1_ (u"ࠧ࠻࠼ࠪ浵"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ浶"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l111l1_l1_,l1ll11l111l1_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ海"):l11l1l1_l1_,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ浸"):l11lll_l1_ (u"ࠫࠬ浹")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ浺"),url,l11lll_l1_ (u"࠭ࠧ浻"),l11lll_l1_ (u"ࠧࠨ浼"),l11lll_l1_ (u"ࠨࠩ浽"),l11lll_l1_ (u"ࠩࠪ浾"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ浿"))
	html = response.content
	if type==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭涀"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠩ涁"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ涂"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ涃"),l11lll_l1_ (u"ࠨ࠱ࠪ涄")).replace(l11lll_l1_ (u"ࠩ࡟ࡠࠧ࠭涅"),l11lll_l1_ (u"ࠪࠦࠬ涆"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ涇"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ消"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ涉"),l11lll_l1_ (u"ࠧࠨ涊"))
			if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ涋") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ涌"),l111ll_l1_+title,link,563,l1llll_l1_)
			elif l11lll_l1_ (u"ࠪั้่ษࠨ涍") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠯า๊โสࠢ࠮ࡠࡩ࠱ࠧ涎"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ涏") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涐"),l111ll_l1_+title,link,563,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭涑"),l111ll_l1_+title,link,562,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ涒"):
			l1lll111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ涓"),block,re.DOTALL)
			if l1lll111ll1_l1_:
				count = l1lll111ll1_l1_[0]
				link = url+l11lll_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ涔")+count
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ涕"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ涖"),link,561,l11lll_l1_ (u"࠭ࠧ涗"),l11lll_l1_ (u"ࠧࠨ涘"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ涙"))
		elif type==l11lll_l1_ (u"ࠩࠪ涚"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ涛"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ涜"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ涝")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涞"),l111ll_l1_+title,link,561)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠧࠨ涟")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ涠"),l11lll_l1_ (u"ࠩࠪ涡"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ涢"),url,l11lll_l1_ (u"ࠫࠬ涣"),l11lll_l1_ (u"ࠬ࠭涤"),l11lll_l1_ (u"࠭ࠧ涥"),l11lll_l1_ (u"ࠧࠨ润"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ涧"))
	html = response.content
	html = l111l_l1_(html)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࡡ࠭࠲࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠳ࠧ࠭ࠩࠣࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍ࡮࡬ࠠࠨ็๋ื๊࠭ࠠࡪࡰࠣࡲࡦࡳࡥࠡࡣࡱࡨࠥࡴ࡯ࡵࠢࡷࡽࡵ࡫࠺ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨ็๋ื๊࠭ࠩ࡜࠲ࡠࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ๅีษ๊ำฮ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࡨࡰ࡮࡬ࠠࠨฯ็ๆฮ࠭ࠠࡪࡰࠣࡲࡦࡳࡥ࠻ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩะ่็ฯࠧࠪ࡝࠳ࡡࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧๆึส๋ิฯࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠦࠧࠨ涨")
	# l1lllll_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ涩"),html,re.DOTALL)
	if not type and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭涪"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ涫")+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭涬"),l111ll_l1_+title,link,563,l11lll_l1_ (u"ࠧࠨ涭"),l11lll_l1_ (u"ࠨࠩ涮"),l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ涯"))
			return
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࡵࡁࠫ涰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ涱"),block)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭液"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ涳"),str(items))
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ涴"))
			#title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ涵")+title
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ涶"),l111ll_l1_+title,link,562)
	if not menuItemsLIST:
		title = re.findall(l11lll_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ涷"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠫࠥ࠳ࠠๆษํࠤุ๐ๅศࠩ涸"),l11lll_l1_ (u"ࠬ࠭涹")).replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ涺"),l11lll_l1_ (u"ࠧࠨ涻"))
		else: title = l11lll_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭涼")
		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ涽"),l111ll_l1_+title,url,562)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ涾"),url,l11lll_l1_ (u"ࠫࠬ涿"),l11lll_l1_ (u"ࠬ࠭淀"),l11lll_l1_ (u"࠭ࠧ淁"),l11lll_l1_ (u"ࠧࠨ淂"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ淃"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ษ็ฮฺ์๊โ࠾࠱࠮ࡄࡂࡡ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ淄"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡈࡱࡧ࡫ࡤࠣࠩ淅"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ淆"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ淇") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"࠭ำ๋ำไีࠥ๎๊ࠡีํ้ฬ࠭淈"): name = l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ淉")
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ淊")+name+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ淋")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡹࡴ࠮࠯ࡇࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ淌"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ淍"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ淎") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ淏"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬ淐")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠨࠩ淑")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡺࡩࡨ࡯࡭ࡢࠩ淒")+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ淓")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ淔"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ淕"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"࠭ࠧ淖")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ淗"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ淘"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ淙"),l11lll_l1_ (u"ࠪ࠯ࠬ淚"))
	l1111_l1_ = [l11lll_l1_ (u"ࠫ࠴࠭淛"),l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ淜"),l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ淝"),l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ淞"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ淟")]
	l1l11l1ll_l1_ = [l11lll_l1_ (u"ࠩฦๅ้อๅࠨ淠"),l11lll_l1_ (u"ุ้๊ࠪำๅษอࠫ淡"),l11lll_l1_ (u"ࠫศ์๊ๆ์ࠣ์่ืส้่ࠪ淢"),l11lll_l1_ (u"ࠬฮัศ็ฯࠤฯ๊๊โิํ์๋࠭淣"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠล้๎๊๐ࠧ淤")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅุๆ๋ฬ࠿࠭淥"), l1l11l1ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11ll1_l1_
		#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ淦"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ淧"),l11lll_l1_ (u"ࠪࠫ淨"),False,l11lll_l1_ (u"ࠫࠬ淩"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ淪"))
		#hostname = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ淫")]
		#hostname = response.url
		#hostname = hostname.strip(l11lll_l1_ (u"ࠧ࠰ࠩ淬"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ淭")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l111l1_l1_,filter):
	if l11lll_l1_ (u"ࠩࡂࡃࠬ淮") in l1ll11l111l1_l1_: url = l1ll11l111l1_l1_.split(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ淯"))[0]
	else: url = l1ll11l111l1_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ淰"):l1ll11l111l1_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ深"):l11lll_l1_ (u"࠭ࠧ淲")}
	filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ淳"),l11lll_l1_ (u"ࠨࠩ淴"))
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭淵"),1)
	if filter==l11lll_l1_ (u"ࠪࠫ淶"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬ混"),l11lll_l1_ (u"ࠬ࠭淸")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ淹"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ淺"):
		if l1l111ll1_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࡀࠫ添") not in l1l11l1l_l1_: category = l1l111ll1_l1_[0]
		for i in range(len(l1l111ll1_l1_[0:-1])):
			if l1l111ll1_l1_[i]+l11lll_l1_ (u"ࠩࡀࡁࠬ淼") in l1l11l1l_l1_: category = l1l111ll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭淽")+category+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨ淾")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ淿")+category+l11lll_l1_ (u"࠭࠽࠾࠲ࠪ渀")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ渁"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ渂")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ渃"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭渄"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ清")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭渆"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ渇"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨ済"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ渉"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪ渊"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ渋")+l1l11l11_l1_
		l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111l1_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ渌"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ渍"),l1111111_l1_,561,l11lll_l1_ (u"࠭ࠧ渎"),l11lll_l1_ (u"ࠧࠨ渏"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ渐"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ渑"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ渒")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ渓"),l1111111_l1_,561,l11lll_l1_ (u"ࠬ࠭渔"),l11lll_l1_ (u"࠭ࠧ渕"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ渖"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭渗"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ渘"),l11lll_l1_ (u"ࠪࠫ渙"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ渚"),url,l11lll_l1_ (u"ࠬ࠭減"),l11lll_l1_ (u"࠭ࠧ渜"),l11lll_l1_ (u"ࠧࠨ渝"),l11lll_l1_ (u"ࠨࠩ渞"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ渟"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ渠"),l11lll_l1_ (u"ࠫࠧ࠭渡")).replace(l11lll_l1_ (u"ࠬࡢ࡜࠰ࠩ渢"),l11lll_l1_ (u"࠭࠯ࠨ渣"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ渤"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭渥"),block+l11lll_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭渦"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ渧") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭渨"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠬࡃ࠽ࠨ温") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ渪"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ渫")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111l1_l1_)
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ測"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩ渭"),l1111111_l1_,561,l11lll_l1_ (u"ࠪࠫ渮"),l11lll_l1_ (u"ࠫࠬ港"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭渰"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭渱"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ渲"),l11l11l_l1_,564,l11lll_l1_ (u"ࠨࠩ渳"),l11lll_l1_ (u"ࠩࠪ渴"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ渵"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ渶")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ渷")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ游")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ渹")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ渺")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ渻"),l111ll_l1_+name+l11lll_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ渼"),l11l11l_l1_,565,l11lll_l1_ (u"ࠫࠬ渽"),l11lll_l1_ (u"ࠬ࠭渾"),l1l1l11l_l1_+l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ渿"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠧࡳࠩ湀") or value==l11lll_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ湁"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ湂") in option: continue
			if l11lll_l1_ (u"ࠪห้้ไࠨ湃") in option: continue
			if l11lll_l1_ (u"ࠫࡳ࠳ࡡࠨ湄") in value: continue
			#if value in [l11lll_l1_ (u"ࠬࡸࠧ湅"),l11lll_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ湆"),l11lll_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭湇")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ湈"): option = value
			if option==l11lll_l1_ (u"ࠩࠪ湉"): option = value
			l11l1ll11_l1_ = option
			l1l11l1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ湊"),option,re.DOTALL)
			if l1l11l1lll1_l1_: l11l1ll11_l1_ = l1l11l1lll1_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠫ࠿ࠦࠧ湋")+l11l1ll11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ湌")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩ湍")+l11l1ll11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ湎")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫ湏")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭湐")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ湑"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ湒"),l111ll_l1_+l1lll1lll_l1_,url,565,l11lll_l1_ (u"ࠬ࠭湓"),l11lll_l1_ (u"࠭ࠧ湔"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ湕"))
			elif type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ湖") and l1l111ll1_l1_[-2]+l11lll_l1_ (u"ࠩࡀࡁࠬ湗") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭湘"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ湙"),l11lll_l1_ (u"ࠬ࠭湚"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ湛")+l1l1111l_l1_
				l1111111_l1_ = l11ll1lll_l1_(l11l1l1_l1_,l1ll11l111l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ湜"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,561,l11lll_l1_ (u"ࠨࠩ湝"),l11lll_l1_ (u"ࠩࠪ湞"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ湟"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ湠"),l111ll_l1_+l1lll1lll_l1_,url,564,l11lll_l1_ (u"ࠬ࠭湡"),l11lll_l1_ (u"࠭ࠧ湢"),l1ll1ll1_l1_)
	return
l1l111ll1_l1_ = [l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭湣"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ湤"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ湥")]
l1l1111l1_l1_ = [l11lll_l1_ (u"ࠪࡱࡵࡧࡡࠨ湦"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ湧"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ湨"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ湩"),l11lll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ湪"),l11lll_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ湫"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ湬"),l11lll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ湭")]
def l11ll1lll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ湮") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ湯"),l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ湰"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭湱"),l11lll_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ湲"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩࡀࡁࠬ湳"),l11lll_l1_ (u"ࠪ࠳ࠬ湴"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫࠫࠬࠧ湵"),l11lll_l1_ (u"ࠬ࠵ࠧ湶"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ湷"),l11lll_l1_ (u"ࠧࠨ湸"),filters,l11lll_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ湹")+mode)
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ湺")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭湻")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ湼")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ湽"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"࠭ࠧ湾")
	if l11lll_l1_ (u"ࠧ࠾࠿ࠪ湿") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠩࠫ満"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࡁࠬ溁"))
			l1l11ll1_l1_[var] = value
	for key in l1l1111l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠪ࠴ࠬ溂")
		if l11lll_l1_ (u"ࠫࠪ࠭溃") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ溄") and value!=l11lll_l1_ (u"࠭࠰ࠨ溅"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ溆")+value
		elif mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ溇") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ溈"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭溉")+key+l11lll_l1_ (u"ࠫࡂࡃࠧ溊")+value
		elif mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ溋"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ溌")+key+l11lll_l1_ (u"ࠧ࠾࠿ࠪ溍")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ溎"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ溏"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ源"),l11lll_l1_ (u"ࠫࠬ溑"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠬࡕࡕࡕࠩ溒"))
	return l1ll1l1l_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ勭")
headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ勮"):l11lll_l1_ (u"ࠧࠨ勯")}
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ勰")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭勱"),l11lll_l1_ (u"ࠪࡻࡼ࡫ࠧ勲")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1111l_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llllll_l1_(url,text)
	elif mode==364: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ勳")+text)
	elif mode==365: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ勴")+text)
	elif mode==366: results = l1l11l_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ勵"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ勶"),l11lll_l1_ (u"ࠨࠩ勷"),False,l11lll_l1_ (u"ࠩࠪ勸"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ勹"))
	#hostname = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭勺")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠬ࠵ࠧ勻"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭勼")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ勽"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ勾"),l11lll_l1_ (u"ࠩࠪ勿"),l11lll_l1_ (u"ࠪࠫ匀"),l11lll_l1_ (u"ࠫࠬ匁"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ匂"))
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ匃"),l111ll_l1_+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ匄"),l11lll_l1_ (u"ࠨࠩ包"),8)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ匆"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ匇"),l11lll_l1_ (u"ࠫࠬ匈"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ匉"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭匊"),l11ll1_l1_,369,l11lll_l1_ (u"ࠧࠨ匋"),l11lll_l1_ (u"ࠨࠩ匌"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭匍"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ匎"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ匏"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ匐"),364)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭匑"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ匒"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ匓"),365)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ匔"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ匕"),l11lll_l1_ (u"ࠫࠬ化"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭北"):hostname,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ匘"):l11lll_l1_ (u"ࠧࠨ匙")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ匚"),l11lll_l1_ (u"ࠩ࠲ࠫ匛"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࡤࡤࡶ࠭࠴ࠪࡀࠫࡩ࡭ࡱࡺࡥࡳࠩ匜"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ匝"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠬࠫࡤ࠺ࠧ࠻࠹ࠪࡪ࠸ࠦࡤ࠸ࠩࡩ࠾ࠥࡢ࠹ࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡨ࠹ࠦࡦ࠻ࠩࡦ࠿࠭ࠦࡦ࠻ࠩࡦࡪࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡤ࠽ࠬ匞") in link: continue
	#		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭匟"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ匠")+l111ll_l1_+title,link,366)
	#	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭匡"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ匢"),l11lll_l1_ (u"ࠪࠫ匣"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ匤"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭匥"),l11lll_l1_ (u"࠭ࠧ匦"),l11lll_l1_ (u"ࠧࠨ匧"),l11lll_l1_ (u"ࠨࠩ匨"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ匩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ匪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ匫"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ匬") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ匭"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠧࠨ匮"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ匯"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ匰")+l111ll_l1_+title,link,366)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ匱"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ匲"),l11lll_l1_ (u"ࠬ࠭匳"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ匴"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ匵"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ匶"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ匷")+l111ll_l1_+title,link,366,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ匸"),l11lll_l1_ (u"ࠫࠬ匹"),url,l11lll_l1_ (u"ࠬ࠭区"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ医"):url,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ匼"):l11lll_l1_ (u"ࠨࠩ匽")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭匾"),url,l11lll_l1_ (u"ࠪࠫ匿"),l11lll_l1_ (u"ࠫࠬ區"),l11lll_l1_ (u"ࠬ࠭十"),l11lll_l1_ (u"࠭ࠧ卂"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ千"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ卄"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ卅"),url,364)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ卆"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ升"),url,365)
	if l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦࠬ午") in html:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭卉"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ半"),url,361,l11lll_l1_ (u"ࠨࠩ卋"),l11lll_l1_ (u"ࠩࠪ卌"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ卍"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ华"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ协"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭卐"),l111ll_l1_+title,link,361)
	return
def l1111l_l1_(l1ll11l111l1_l1_,type=l11lll_l1_ (u"ࠧࠨ卑")):
	if l11lll_l1_ (u"ࠨ࠼࠽ࠫ卒") in l1ll11l111l1_l1_:
		l11l1l1_l1_,url = l1ll11l111l1_l1_.split(l11lll_l1_ (u"ࠩ࠽࠾ࠬ卓"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ協"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll11l111l1_l1_,l1ll11l111l1_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ单"):l11l1l1_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ卖"):l11lll_l1_ (u"࠭ࠧ南")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ単"),url,l11lll_l1_ (u"ࠨࠩ卙"),l11lll_l1_ (u"ࠩࠪ博"),l11lll_l1_ (u"ࠪࠫ卛"),l11lll_l1_ (u"ࠫࠬ卜"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ卝"))
	html = response.content
	if type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ卞"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ卟"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ占"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠩ࡟ࡠ࠴࠭卡"),l11lll_l1_ (u"ࠪ࠳ࠬ卢")).replace(l11lll_l1_ (u"ࠫࡡࡢࠢࠨ卣"),l11lll_l1_ (u"ࠬࠨࠧ卤"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲ࡓࡹࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ卥"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭卦"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠡࠩ卧"),l11lll_l1_ (u"ࠩࠪ卨"))
			if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ卩") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ卪"),l111ll_l1_+title,link,363,l1llll_l1_)
			elif l11lll_l1_ (u"ࠬำไใหࠪ卫") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ卬"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭卭") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ卮"),l111ll_l1_+title,link,363,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ卯"),l111ll_l1_+title,link,362,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ印"):
			l1lll111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ危"),block,re.DOTALL)
			if l1lll111ll1_l1_:
				count = l1lll111ll1_l1_[0]
				link = url+l11lll_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ卲")+count
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭即"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ却"),link,361,l11lll_l1_ (u"ࠨࠩ卵"),l11lll_l1_ (u"ࠩࠪ卶"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ卷"))
		elif type==l11lll_l1_ (u"ࠫࠬ卸"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭卹"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ卺"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ࠧึใะอࠥ࠭卻")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ卼"),l111ll_l1_+title,link,361)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠩࠪ卽")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ卾"),url,l11lll_l1_ (u"ࠫࠬ卿"),l11lll_l1_ (u"ࠬ࠭厀"),l11lll_l1_ (u"࠭ࠧ厁"),l11lll_l1_ (u"ࠧࠨ厂"),l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ厃"))
	html = response.content
	html = l111l_l1_(html)
	name = re.findall(l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ厄"),html,re.DOTALL)
	if name: name = name[-1].replace(l11lll_l1_ (u"ࠪ࠱ࠬ厅"),l11lll_l1_ (u"ࠫࠥ࠭历")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ厇"))
	if l11lll_l1_ (u"࠭ๅ้ี่ࠫ厈") in name and type==l11lll_l1_ (u"ࠧࠨ厉"):
		name = name.split(l11lll_l1_ (u"ࠨ็๋ื๊࠭厊"))[0]
		name = name.replace(l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ压"),l11lll_l1_ (u"ࠪࠫ厌")).strip(l11lll_l1_ (u"ࠫࠥ࠭厍"))
	elif l11lll_l1_ (u"ࠬำไใหࠪ厎") in name:
		name = name.split(l11lll_l1_ (u"࠭อๅไฬࠫ厏"))[0]
		name = name.replace(l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ厐"),l11lll_l1_ (u"ࠨࠩ厑")).strip(l11lll_l1_ (u"ࠩࠣࠫ厒"))
	else: name = name
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࠧ厓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if type==l11lll_l1_ (u"ࠫࠬ厔"):
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ厕"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ厖") in title: continue
				if l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ厗") in title: continue
				title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ厘")+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ厙"),l111ll_l1_+title,link,363,l11lll_l1_ (u"ࠪࠫ厚"),l11lll_l1_ (u"ࠫࠬ厛"),l11lll_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ厜"))
		if len(menuItemsLIST)==0:
			l11l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࠯ࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠫࠬࠧ厝"),block+l11lll_l1_ (u"ࠧࠧࠨࠪ厞"),re.DOTALL)
			if l11l1_l1_: block = l11l1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ原"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ厠"))
				title = name+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ厡")+title
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ厢"),l111ll_l1_+title,link,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ厣"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ厤"),l11lll_l1_ (u"ࠧࠨ厥")).replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠡࠩ厦"),l11lll_l1_ (u"ࠩࠪ厧"))
		else: title = l11lll_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ厨")
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ厩"),l111ll_l1_+title,url,362)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ厪"),url,l11lll_l1_ (u"࠭ࠧ厫"),l11lll_l1_ (u"ࠧࠨ厬"),l11lll_l1_ (u"ࠨࠩ厭"),l11lll_l1_ (u"ࠩࠪ厮"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ厯"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ厰"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ厱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ厲"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ厳") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"ࠨีํีๆืࠠๆษํࠤุ๐ๅศࠩ厴"): name = l11lll_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ厵")
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ厶")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ厷")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ厸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ厹"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ厺") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ去"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧ厼")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠪࠫ厽")
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡲࡿࡣࡪ࡯ࡤࠫ厾")+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ县")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ叀"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭叁"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"ࠨࠩ参")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ參"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ叄"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭叅"),l11lll_l1_ (u"ࠬ࠱ࠧ叆"))
	l1111_l1_ = [l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ叇"),l11lll_l1_ (u"ࠧ࠰ࠩ又"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡴࡧࡵ࡭ࡪࡹࠧ叉"),l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡣࡱ࡭ࡲ࡫ࠧ及"),l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡷࡺࠬ友")]
	l1l11l1ll_l1_ = [l11lll_l1_ (u"ࠫฬ๊ใๅࠩ双"),l11lll_l1_ (u"ࠬอไฤใ็ห๊࠭反"),l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠩ収"),l11lll_l1_ (u"ࠧศๆส๊๏๋๊๊ࠡࠣห้้ัห๊้ࠫ叏"),l11lll_l1_ (u"ࠨษ็ฬึอๅอࠢอ่๏็า๋๊้๎ฮ࠭叐")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ发"), l1l11l1ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11lll_l1_ (u"ࠪࠫ叒"):
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ叓"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭叔"),l11lll_l1_ (u"࠭ࠧ叕"),False,l11lll_l1_ (u"ࠧࠨ取"),l11lll_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ受"))
		hostname = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ变")]
		hostname = hostname.strip(l11lll_l1_ (u"ࠪ࠳ࠬ叙"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭叚")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll11l111l1_l1_,filter):
	if l11lll_l1_ (u"ࠬࡅ࠿ࠨ叛") in l1ll11l111l1_l1_: url = l1ll11l111l1_l1_.split(l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ叜"))[0]
	else: url = l1ll11l111l1_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ叝"):l1ll11l111l1_l1_,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ叞"):l11lll_l1_ (u"ࠩࠪ叟")}
	filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ叠"),l11lll_l1_ (u"ࠫࠬ叡"))
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ叢"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ口"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ古"),l11lll_l1_ (u"ࠨࠩ句")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭另"))
	if type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ叧"):
		if l1l111ll1_l1_[0]+l11lll_l1_ (u"ࠫࡂࡃࠧ叨") not in l1l11l1l_l1_: category = l1l111ll1_l1_[0]
		for i in range(len(l1l111ll1_l1_[0:-1])):
			if l1l111ll1_l1_[i]+l11lll_l1_ (u"ࠬࡃ࠽ࠨ叩") in l1l11l1l_l1_: category = l1l111ll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ只")+category+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ叫")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ召")+category+l11lll_l1_ (u"ࠩࡀࡁ࠵࠭叭")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠫ࠭叮"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ可")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ台"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ叱"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭史")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ右"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ叴"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠪࠫ叵"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ叶"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠬ࠭号"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ司")+l1l11l11_l1_
		l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111l1_l1_)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ叹"),l111ll_l1_+l11lll_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ叺"),l1111111_l1_,361,l11lll_l1_ (u"ࠩࠪ叻"),l11lll_l1_ (u"ࠪࠫ叼"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ叽"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ叾"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭叿")+l11lll11_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭吀"),l1111111_l1_,361,l11lll_l1_ (u"ࠨࠩ吁"),l11lll_l1_ (u"ࠩࠪ吂"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ吃"))
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ各"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ吅"),l11lll_l1_ (u"࠭ࠧ吆"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ吇"),url,l11lll_l1_ (u"ࠨࠩ合"),l11lll_l1_ (u"ࠩࠪ吉"),l11lll_l1_ (u"ࠪࠫ吊"),l11lll_l1_ (u"ࠫࠬ吋"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ同"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"࠭࡜࡝ࠤࠪ名"),l11lll_l1_ (u"ࠧࠣࠩ后")).replace(l11lll_l1_ (u"ࠨ࡞࡟࠳ࠬ吏"),l11lll_l1_ (u"ࠩ࠲ࠫ吐"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭向"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ吒"),block+l11lll_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ吓"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ吔") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ吕"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠨ࠿ࡀࠫ吖") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭吗"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ吘")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11ll1lll_l1_(l11l11l_l1_,l1ll11l111l1_l1_)
				if l1ll1lll_l1_==l1l111ll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ吙"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠬ吚"),l1111111_l1_,361,l11lll_l1_ (u"࠭ࠧ君"),l11lll_l1_ (u"ࠧࠨ吜"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ吝"))
				else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ吞"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠪ吟"),l11l11l_l1_,364,l11lll_l1_ (u"ࠫࠬ吠"),l11lll_l1_ (u"ࠬ࠭吡"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ吢"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ吣")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀ࠴ࠬ吤")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ吥")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧ否")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ吧")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ吨"),l111ll_l1_+name+l11lll_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ吩"),l11l11l_l1_,365,l11lll_l1_ (u"ࠧࠨ吪"),l11lll_l1_ (u"ࠨࠩ含"),l1l1l11l_l1_+l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ听"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠪࡶࠬ吭") or value==l11lll_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ吮"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ启") in option: continue
			if l11lll_l1_ (u"࠭วๅๅ็ࠫ吰") in option: continue
			if l11lll_l1_ (u"ࠧ࡯࠯ࡤࠫ吱") in value: continue
			#if value in [l11lll_l1_ (u"ࠨࡴࠪ吲"),l11lll_l1_ (u"ࠩࡱࡧ࠲࠷࠷ࠨ吳"),l11lll_l1_ (u"ࠪࡸࡻ࠳࡭ࡢࠩ吴")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ吵"): option = value
			if option==l11lll_l1_ (u"ࠬ࠭吶"): option = value
			l11l1ll11_l1_ = option
			l1l11l1lll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼࡯ࡣࡰࡩࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡ࡮ࡧࡁࠫ吷"),option,re.DOTALL)
			if l1l11l1lll1_l1_: l11l1ll11_l1_ = l1l11l1lll1_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠧ࠻ࠢࠪ吸")+l11l1ll11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ吹")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࡁࠬ吺")+l11l1ll11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭吻")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂࡃࠧ吼")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ吽")+l1l1llll_l1_
			if type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ吾"):
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ吿"),l111ll_l1_+l1lll1lll_l1_,url,365,l11lll_l1_ (u"ࠨࠩ呀"),l11lll_l1_ (u"ࠩࠪ呁"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ呂"))
			elif type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ呃") and l1l111ll1_l1_[-2]+l11lll_l1_ (u"ࠬࡃ࠽ࠨ呄") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ呅"))
				#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ呆"),l11lll_l1_ (u"ࠨࠩ呇"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ呈")+l1l1111l_l1_
				l1111111_l1_ = l11ll1lll_l1_(l11l1l1_l1_,l1ll11l111l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ呉"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,361,l11lll_l1_ (u"ࠫࠬ告"),l11lll_l1_ (u"ࠬ࠭呋"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ呌"))
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ呍"),l111ll_l1_+l1lll1lll_l1_,url,364,l11lll_l1_ (u"ࠨࠩ呎"),l11lll_l1_ (u"ࠩࠪ呏"),l1ll1ll1_l1_)
	return
l1l111ll1_l1_ = [l11lll_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ呐"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ呑"),l11lll_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ呒")]
l1l1111l1_l1_ = [l11lll_l1_ (u"࠭࡭ࡱࡣࡤࠫ呓"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭呔"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ呕"),l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ呖"),l11lll_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫ呗"),l11lll_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭员"),l11lll_l1_ (u"ࠬࡴࡡࡵ࡫ࡲࡲࠬ呙"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ呚")]
def l11ll1lll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ呛") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ呜"),l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࠪ呝"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ呞"),l11lll_l1_ (u"ࠫ࠿ࡀ࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭࠯ࠨ呟"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬࡃ࠽ࠨ呠"),l11lll_l1_ (u"࠭࠯ࠨ呡"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧࠧࠨࠪ呢"),l11lll_l1_ (u"ࠨ࠱ࠪ呣"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ呤"),l11lll_l1_ (u"ࠪࠫ呥"),filters,l11lll_l1_ (u"ࠫࡎࡔࠠࠡࠢࠣࠫ呦")+mode)
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ呧")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ周")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ呩")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠩࠫ呪"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠩࠪ呫")
	if l11lll_l1_ (u"ࠪࡁࡂ࠭呬") in filters:
		items = filters.split(l11lll_l1_ (u"ࠫࠫࠬࠧ呭"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠬࡃ࠽ࠨ呮"))
			l1l11ll1_l1_[var] = value
	for key in l1l1111l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ呯")
		if l11lll_l1_ (u"ࠧࠦࠩ呰") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ呱") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ呲"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ味")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ呴") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ呵"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ呶")+key+l11lll_l1_ (u"ࠧ࠾࠿ࠪ呷")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ呸"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ呹")+key+l11lll_l1_ (u"ࠪࡁࡂ࠭呺")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ呻"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ呼"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ命"),l11lll_l1_ (u"ࠧࠨ呾"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠨࡑࡘࡘࠬ呿"))
	return l1ll1l1l_l1_
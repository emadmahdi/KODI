# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭扻")
def MAIN(mode,text=l11lll_l1_ (u"ࠬ࠭扼")):
	if   mode==  0: l1lll111lll1l_l1_(text)
	elif mode==  2: l1l1lll1111l_l1_(text)
	elif mode==  3: l1lll1l1l111l_l1_()
	elif mode==  4: l1ll1lllll11_l1_(text)
	elif mode==  5: l1lll111ll11l_l1_()
	elif mode==  6: l1lll1l1l1ll1_l1_()
	elif mode==  7: l1ll111llll1_l1_()
	elif mode==  8: l1lll111l11l1_l1_()
	elif mode==  9: l1lll111l1l11_l1_()
	elif mode==150: l1lll11111lll_l1_()
	elif mode==151: l1ll1ll1l1111_l1_()
	elif mode==152: l1lll11ll111l_l1_()
	elif mode==153: l1lll1lll1ll1_l1_()
	elif mode==154: l1lll1ll11111_l1_()
	elif mode==155: l1lll11l1111l_l1_()
	elif mode==156: l1ll1ll11ll1l_l1_()
	elif mode==157: l1lll1l1l1lll_l1_()
	elif mode==158: l1lll11ll11l1_l1_()
	elif mode==159: l1ll1llllllll_l1_(True)
	elif mode==170: l1lll1111111l_l1_()
	elif mode==171: l1lll1l111111_l1_()
	elif mode==172: l1ll1llll111l_l1_(text,True,True)
	elif mode==173: l111ll1l11l_l1_(l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭扽"),True)
	elif mode==174: l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ找"),True)
	elif mode==175: l1lll11l1l111_l1_()
	elif mode==176: l1ll1llll11l1_l1_()
	elif mode==177: l1lll1l1lll1l_l1_(l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ承"))
	elif mode==178: l1lll1l1lll1l_l1_(l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭技"))
	elif mode==179: l1lll1l1lll1l_l1_(l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ抁"))
	elif mode==190: l1lll111lll11_l1_()
	elif mode==191: l1ll1lll11ll1_l1_()
	elif mode==192: l1ll1llll11ll_l1_()
	elif mode==193: l1lll1l1111l1_l1_()
	elif mode==194: l1ll1lll1lll1_l1_()
	elif mode==195: l1lll11111ll1_l1_()
	elif mode==196: l1lll111ll111_l1_()
	elif mode==197: l1lll1111ll1l_l1_()
	elif mode==198: l1lll11lllll1_l1_()
	elif mode==199: l1lll1111l1ll_l1_()
	elif mode==340: l1ll1lll11111_l1_(text)
	elif mode==341: l1l1l11111l1_l1_()
	elif mode==342: l1lll11l11l11_l1_()
	elif mode==343: l1lll1111lll1_l1_()
	elif mode==344: l1ll1lll11lll_l1_(True)
	elif mode==345: l1lll11ll1lll_l1_()
	elif mode==346: l11lll1l111_l1_(False)
	elif mode==347: l1l11lll1ll1_l1_(True)
	elif mode==348: l1lll1l11111l_l1_()
	elif mode==349: l1lll1l11llll_l1_(l1l1111llll1_l1_)
	elif mode==500: l1ll1lll1l111_l1_()
	elif mode==501: l1ll1ll1ll11l_l1_()
	elif mode==502: l1lll11llll1l_l1_(l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ抂"),True)
	elif mode==503: l1lll1l11llll_l1_(l11ll1lllll_l1_)
	elif mode==504: l1lll1l11llll_l1_(favoritesfile)
	elif mode==505: l1lll11l11ll1_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1l1111111_l1_(text,l11lll_l1_ (u"ࠬ࠭抃"),True)
	elif mode==508: l1lll11llllll_l1_()
	elif mode==509: l1lll1lll11ll_l1_()
	return
def l1lll1lll11ll_l1_():
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ抄"),l11lll_l1_ (u"ࠧࠨ抅"),l11lll_l1_ (u"ࠨࠩ抆"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ抇"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬ抈"))
	if l1ll11l111_l1_:
		l1ll1lll11lll_l1_(False)
		l1ll11ll1l_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ抉"),l11lll_l1_ (u"ࠬ࠭把"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ抋"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩ抌"))
	return
def l1l1l1111111_l1_(addon_id,function,l1ll_l1_):
	# function: l11lll_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ抍"),l11lll_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࠪ抎"),l11lll_l1_ (u"ࠪࠫ抏")
	conn = sqlite3.connect(l1l1l11ll111_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1ll1llll1ll1_l1_ = l11lll_l1_ (u"ࠫࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠧ抐")
	else: l1ll1llll1ll1_l1_ = l11lll_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠫ抑")
	cc.execute(l11lll_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠧ抒")+l1ll1llll1ll1_l1_+l11lll_l1_ (u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ抓")+addon_id+l11lll_l1_ (u"ࠨࠤࠣ࠿ࠬ抔"))
	l11ll1ll111_l1_ = cc.fetchall()
	if l11ll1ll111_l1_ and function in [l11lll_l1_ (u"ࠩࠪ投"),l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ抖")]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ抗"),l11lll_l1_ (u"ࠬ࠭折"),l11lll_l1_ (u"࠭ࠧ抙"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ抚"),l11lll_l1_ (u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬ抛")+addon_id+l11lll_l1_ (u"ࠩࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ抜"))
		if l1ll11l111_l1_!=1: return
		cc.execute(l11lll_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩ抝")+l1ll1llll1ll1_l1_+l11lll_l1_ (u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ択")+addon_id+l11lll_l1_ (u"ࠬࠨࠠ࠼ࠩ抟"))
	elif function in [l11lll_l1_ (u"࠭ࠧ抠"),l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨ抡")]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ抢"),l11lll_l1_ (u"ࠩࠪ抣"),l11lll_l1_ (u"ࠪࠫ护"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ报"),l11lll_l1_ (u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩ抦")+addon_id+l11lll_l1_ (u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็ไ฽้่๋ࠦ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศ๎็อแ่ࠢส่ว์ࠠภࠣࠤࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤฯ็ู๋ๆ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ抧"))
		if l1ll11l111_l1_!=1: return
		if kodi_version<19: cc.execute(l11lll_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧ抨")+addon_id+l11lll_l1_ (u"ࠨࠤࠬࠤࡀ࠭抩"))
		else: cc.execute(l11lll_l1_ (u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩ抪")+addon_id+l11lll_l1_ (u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪ披"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11lll_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ抬"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭抭"),l11lll_l1_ (u"࠭ࠧ抮"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ抯"),l11lll_l1_ (u"ࠨฬ่ฮࠥอไฺ็็๎ฮࠦศ็ฮสัࠬ抰"))
	if function in [l11lll_l1_ (u"ࠩࠪ抱"),l11lll_l1_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࠪ抲")]: l1ll1llllllll_l1_(l1ll_l1_)
	return
def l1lll11l11ll1_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ抳"),l11lll_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ抴"))
	l1l1l11lllll_l1_ = l11l1111ll1_l1_(False)
	l1llll11l11l_l1_ = l11lll_l1_ (u"࠭࡜࡯ࠩ抵")
	l1lll1llll111_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱࠲࠳ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ抶")
	l1lll1lll1lll_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ抷")
	for id,l1l1111ll1ll_l1_,l1l11l1111l1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason in reversed(l1l1l11lllll_l1_):
		if id==l11lll_l1_ (u"ࠩ࠳ࠫ抸"):
			l1lll1l1ll11_l1_,l1lll1l1ll1l_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ抹"))
			continue
		if l1llll11l11l_l1_!=l11lll_l1_ (u"ࠫࡡࡴࠧ抺"): l1llll11l11l_l1_ += l1lll1lll1lll_l1_
		l1l1ll11111_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭抻")+id+l11lll_l1_ (u"࠭ࠠ࠻ࠢࠪ押")+l11lll_l1_ (u"ࠧศๆึศฬ๊ࠠ࠻ࠢࠪ抽")+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ抾")+l1l11l1111l1_l1_
		l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ抿")+l11111lll11_l1_
		l1111llll1ll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭拀")+l11111l1l11_l1_
		l1111lllll11_l1_ = l11lll_l1_ (u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅีหฬࠥࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ拁")+reason
		l1llll11l11l_l1_ += l1l1ll11111_l1_+l1l1ll1111l_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ拂")+l1lll1llll111_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ拃")+l1111llll1ll_l1_+l1111lllll11_l1_+l11lll_l1_ (u"ࠧ࡝ࡰࠪ拄")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ担"),l1lll1l1ll1l_l1_,l1llll11l11l_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ拆"))
	return
def l1lll1l11llll_l1_(file):
	if file==favoritesfile: l1lll11l1l1ll_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ拇")
	elif file==l1l1111llll1_l1_: l1lll11l1l1ll_l1_ = l11lll_l1_ (u"ࠫฬ๊ัิษษ่ࠬ拈")
	elif file==l11ll1lllll_l1_: l1lll11l1l1ll_l1_ = l11lll_l1_ (u"่่ࠬศศ่ࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬ拉")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭拊"),l11lll_l1_ (u"ࠧๆีะࠫ拋"),l11lll_l1_ (u"ࠨวุ่ฬำࠧ拌"),l11lll_l1_ (u"ࠩัีําࠧ拍"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭拎"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหีๅษะࠤ๊๊แࠡࠩ拏")+l1lll11l1l1ll_l1_+l11lll_l1_ (u"ࠬࠦรๆࠢอี๏ีࠠๆีะࠤฬ๊ๅๅใࠣรࠬ拐"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ拑"),l11lll_l1_ (u"ࠧࠨ拒"),l11lll_l1_ (u"ࠨࠩ拓"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ拔"),l11lll_l1_ (u"ࠪࠫ拕"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ拖"),l11lll_l1_ (u"ࠬะๅࠡ็ึั๋ࠥไโࠢࠪ拗")+l1lll11l1l1ll_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ拘"),l11lll_l1_ (u"ࠧࠨ拙"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ拚"),l11lll_l1_ (u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩ招")+l1lll11l1l1ll_l1_)
	return
def l1ll1ll1ll11l_l1_():
	if kodi_version<18:
		message = l11lll_l1_ (u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭拜")+str(kodi_version)+l11lll_l1_ (u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬ拝")
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭拞"),l11lll_l1_ (u"࠭ࠧ拟"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ拠"),message)
		return
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ拡"))
	l1l111ll1111_l1_ = l1ll1lll1l11_l1_([l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ拢")])
	l1l1111l11l1_l1_,l1lll1l11ll11_l1_,l1lll1l11lll1_l1_,l1lll1l11ll1l_l1_,l1lll1l11l1l1_l1_,l1ll1ll1lllll_l1_,l1lll1l11l1ll_l1_ = l1l111ll1111_l1_[l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ拣")]
	if l1l1111l11l1_l1_ or l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ拤") not in str(l11111lll1l_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭拥"),l11lll_l1_ (u"࠭ࠧ拦"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ拧"),l11lll_l1_ (u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭拨"))
		succeeded = l1lll11llll1l_l1_(l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ择"),True)
		if not succeeded: return
	l111lll11l1_l1_(True)
	return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠫ࠮ࠐࠉࡪࡨࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊ࠽࠾ࠩ࠸࠸࠹࠭࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้ࠥอไไฬสฬฮ࠭ࠊࠊࡧ࡯࡭࡫ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࡀࡁࠬ࠻࠵࠶ࠩ࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠦ࠽ࠡࠩๅ์ฬฬๅࠡษ็ูํืࠧࠋࠋࡨࡰࡸ࡫࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠣࡁࠥ࠭โ้ษษ้๋ࠥฬ่๊็อࠬࠐࠉࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠵ࡀࠉࠊࠥࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡶࡪࡧࡺࡸࡾࡶࡥࠋࠋࠌࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪࠫࠏࠏࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡶࡪࡧࡺࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࠊࡥࡦࠤࡂࠦࡣࡰࡰࡱ࠲ࡨࡻࡲࡴࡱࡵࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࡺ࡮࡫ࡷ࡚ࠣࠢࡌࡊࡘࡅࠡࡸ࡬ࡩࡼࡓ࡯ࡥࡧࠣࡁࠥ࠷࠹࠸࠳࠴࠻ࠥࡁࠧࠪࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠺࠻࠶࠸࠱ࠢ࠾ࠫ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣࡰ࡯ࡰ࡭ࡹ࠮ࠩࠋࠋࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࡩࡱ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠴࠾ࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࠬ࠻࠴࠵ࠩࠌࠧࠥࠨࡌࡪࡵࡷࠤࡊࡳࡡࡥࠤࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠏࠏࡥ࡭࡫ࡩࠤࡨ࡮࡯ࡪࡥࡨࡁࡂ࠸࠺ࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨ࠷࠸࠹ࠬࠏࠣࠡࠤࡊࡥࡱࡲࡥࡳࡻࡢࡉࡲࡧࡤࠣࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠪ࠰ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠪࠌࠌࠦࠧࠨ拪")
def l111lll11l1_l1_(l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧ拫"))
	if l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ括") not in str(l11111lll1l_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ拭"),l11lll_l1_ (u"ࠧࠨ拮"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ拯"),l11lll_l1_ (u"ࠩ็่ศูแࠡฮ๊หื้ࠠๅษࠣ๎ุะฮะ็ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯ࠢส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧ拰"))
		return
	l1lll1l1l1l11_l1_ = os.path.join(l1l1l111l1_l1_,l11lll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ拱"),l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ拲"),l11lll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ拳"),l11lll_l1_ (u"࠭ࡍࡺࡘ࡬ࡨࡪࡵࡎࡢࡸ࠱ࡼࡲࡲࠧ拴"))
	if not os.path.exists(l1lll1l1l1l11_l1_): return
	l11ll11lll1_l1_ = open(l1lll1l1l1l11_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ拵")).read()
	if kodi_version>18.99: l11ll11lll1_l1_ = l11ll11lll1_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭拶"))
	l1ll1ll1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩ拷"),l11ll11lll1_l1_,re.DOTALL)
	l1ll1lll111l1_l1_,l1lll1lll1l1l_l1_ = l1ll1ll1l1ll1_l1_[0]
	l1lll1ll111ll_l1_ = l11lll_l1_ (u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫ拸")+l1ll1lll111l1_l1_+l11lll_l1_ (u"ࠫ࠱࠭拹")+l1lll1lll1l1l_l1_+l11lll_l1_ (u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ拺")
	if l1ll_l1_:
		l1lll1ll11l1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫ拻"))
		if l1lll1ll11l1l_l1_==l11lll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ拼"): l11l111ll11_l1_ = l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨ拽")
		elif l1lll1ll11l1l_l1_==l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ拾"): l11l111ll11_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢสฺ่๎ัࠨ拿")
		else: l11l111ll11_l1_ = l11lll_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ挀")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ持"),l11lll_l1_ (u"࠭โ้ษษ้ࠥษฮา๋ࠪ挂"),l11lll_l1_ (u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ挃"),l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭挄"),l11lll_l1_ (u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭挅")+l11l111ll11_l1_,l11lll_l1_ (u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡลัฮึࠦวๅฤ้ࠤ๋๎ูࠡษ็ๆํอฦๆࠢส่ฯ๐ࠠหำํำࠥษำหะาห๊ํวࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挆"))
		if choice==1: l1lll11l1l11l_l1_ = l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧ指")
		elif choice==2: l1lll11l1l11l_l1_ = l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡋࡦࡲ࡬ࡦࡴࡼࠫ挈")
		else: l1lll11l1l11l_l1_ = l11lll_l1_ (u"࠭ࠧ按")
	else:
		l1lll1ll11l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ挊"))
		if   l1lll1ll11l1l_l1_==l11lll_l1_ (u"ࠨࠩ挋"): choice = 0
		elif l1lll1ll11l1l_l1_==l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ挌"): choice = 1
		elif l1lll1ll11l1l_l1_==l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ挍"): choice = 2
		l1lll11l1l11l_l1_ = l1lll1ll11l1l_l1_
	if   choice==0: l1lll111ll1ll_l1_ = l11lll_l1_ (u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨ挎")
	elif choice==1: l1lll111ll1ll_l1_ = l11lll_l1_ (u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩ挏")
	elif choice==2: l1lll111ll1ll_l1_ = l11lll_l1_ (u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪ挐")
	else: return
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ挑"),l1lll11l1l11l_l1_)
	l1ll1lll1l1l1_l1_ = l11lll_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ挒")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ挓")+l1lll1lll1l1l_l1_+l11lll_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ挔")
	l11ll111111_l1_ = l11ll11lll1_l1_.replace(l1lll1ll111ll_l1_,l1ll1lll1l1l1_l1_)
	if kodi_version>18.99: l11ll111111_l1_ = l11ll111111_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ挕"))
	open(l1lll1l1l1l11_l1_,l11lll_l1_ (u"ࠬࡽࡢࠨ挖")).write(l11ll111111_l1_)
	LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭挗"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬ挘")+l1lll111ll1ll_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ挙"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡕࡩࡱࡵࡡࡥࡕ࡮࡭ࡳ࠮ࠩࠨ挚"))
	return
def l1ll1lll1l111_l1_():
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ挛"),l11lll_l1_ (u"่๊ࠫวࠨ挜"),l11lll_l1_ (u"ࠬ์ูๆࠩ挝"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ挞"),l11lll_l1_ (u"ࠧษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษࠡ฻้ำ่ࠦ࠮࠯࠰ࠣษ๊อࠠฤๆศูิอัࠡไา๎๊ࠦ࠮࠯࠰ࠣวํࠦว็ฬ้๊ࠣ์ฺ่่๊ࠢࠥอำหะาห๊ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥษ่ࠡๆา๎่ࠦๅีๅ็อࠥษฮา๋ࠣฮำ฻ࠠอ้สึ่ࠦร็ฬࠣ์้อࠠหะุࠤอ่๊สࠢั่็ࠦวๅๆ๊ࠤࡡࡴ࡜࡯ࠢะหํ๊ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡล๋ࠤฬะีๅࠢหห้๋ศา็ฯࠤู้๋าใฬࠤุฮศࠡษ็ู้้ไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึࠢส่ฯำฯ๋อสฮࠥอไร่ࠣรࠬ挟"))
	if l1ll11l111_l1_==1: l1ll111llll1_l1_()
	return
def l1lll111l11l1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ挠"),l11lll_l1_ (u"ࠩࠪ挡"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭挢"),l11lll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧ挣"))
	return
def l1lll1l11111l_l1_():
	l1l1ll11111_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ห฻าหิࠦิ๋฻ฬࠤว๊ࠠๆฯ่ำ๊ࠥำ็หࠣ࠶࠵࠸࠱ࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挤")
	l1l1ll11111_l1_ += l11lll_l1_ (u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬ挥")
	l1l1ll11111_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵ࡳࡩ࡫ࡤࡧࡴࡻ࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ挦")
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮุࠣึ๐ืࠡษ็ุ้๊ๅࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ挧")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭挨")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡰࡹࡸࡲࡩ࡮ࡴࡸࡰࡪࡸ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ挩")
	message = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ挪")+l1l1ll11111_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪ挫")+l1l1ll1111l_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ挬"),l11lll_l1_ (u"ࠧࠨ挭"),message)
	return
def l11lll1l111_l1_(l11llllll11_l1_):
	try: status = l11111l1ll1_l1_(l11llllll11_l1_,False)
	except: pass
	l1l1l11lllll_l1_ = l11l1111ll1_l1_(l11llllll11_l1_)
	id,l1l1111ll1ll_l1_,l1l11l1111l1_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11lllll_l1_[0]
	l1lll1l1ll11_l1_,l1lll1l1ll1l_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭挮"))
	l1l1ll1111l_l1_,l1111llll1ll_l1_,l1111lllll11_l1_ = l11111l1l11_l1_.split(l11lll_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ振"))
	l1l1111ll111_l1_ = True
	while l1l1111ll111_l1_:
		l1lll111l1ll1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ挰"),l11lll_l1_ (u"ࠫำื่อࠩ挱"),l11lll_l1_ (u"ࠬหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ挲"),l11lll_l1_ (u"࠭โศศ่อࠥอไหสิ฽ฬะࠧ挳"),l11lll_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣ࠾ࠥࠦสษำ฼ࠤศ๎ࠠศ็ึัࠥอไษำ้ห๊าࠧ挴"),l1l1ll1111l_l1_)
		if l1lll111l1ll1_l1_==2: l1lll111l1l1l_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ挵"),l11lll_l1_ (u"ࠩࠪ挶"),l11lll_l1_ (u"ࠪ฽ํีษࠨ挷"),l11lll_l1_ (u"ࠫࠬ挸"),l11lll_l1_ (u"๋ࠬศะลࠣห้ะศา฻ࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ挹"),l1111llll1ll_l1_,l11lll_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࠪ挺"))
		elif l1lll111l1ll1_l1_==1: l1l1lll1111l_l1_()
		else: l1l1111ll111_l1_ = False
	settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ挻"),l1l1lll11l11_l1_(now))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ挼"))
	return
def l1ll1lll11lll_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ挽"),l11lll_l1_ (u"ࠪࠫ挾"),l11lll_l1_ (u"ࠫࠬ挿"),l11lll_l1_ (u"ูࠬฤศๆࠪ捀"),l11lll_l1_ (u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧ捁"))
	else: l1ll11l111_l1_ = True
	if l1ll11l111_l1_:
		succeeded = True
		if os.path.exists(l1l1ll1l11l1_l1_):
			try: os.remove(l1l1ll1l11l1_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ捂"),l11lll_l1_ (u"ࠨࠩ捃"),l11lll_l1_ (u"ࠩࠪ捄"),l11lll_l1_ (u"ࠪฮ๊ࠦศ็ฮสั๋ࠥำฮ๋ࠢฮฺ็๊า่่ࠢๆࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ捅"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ捆"),l11lll_l1_ (u"ࠬ࠭捇"),l11lll_l1_ (u"࠭ࠧ捈"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หุ้ࠣำࠠๆๆไࠤฬ๊ลฺัสำฬะࠧ捉"))
	return
def l1lll11ll1lll_l1_():
	l1lll111lll11_l1_()
	l1lll1ll1l1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ捊"))
	message = {}
	message[l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ捋")] = l11lll_l1_ (u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩ捌")
	message[l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ捍")] = l11lll_l1_ (u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ捎")
	message[l11lll_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ捏")] = l11lll_l1_ (u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨ捐")+str(l11l1lllll1_l1_/60)+l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬ捑")
	l1ll1lllllll1_l1_ = message[l1lll1ll1l1l1_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ捒"),l11lll_l1_ (u"ࠪ็ฬฺࠠࠨ捓")+str(l11l1lllll1_l1_/60)+l11lll_l1_ (u"ࠫࠥีโ๋ไฬࠫ捔"),l11lll_l1_ (u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ捕"),l11lll_l1_ (u"࠭ล๋ไสๅ้ࠥวๆๆࠪ捖"),l1ll1lllllll1_l1_,l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪ捗"))
	if choice==0: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ捘")
	elif choice==1: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ捙")
	elif choice==2: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ捚")
	else: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠫࠬ捛")
	if l1ll1lllll1ll_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ捜"),l1ll1lllll1ll_l1_)
		l1ll1llll1111_l1_ = message[l1ll1lllll1ll_l1_]
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ捝"),l11lll_l1_ (u"ࠧࠨ捞"),l11lll_l1_ (u"ࠨࠩ损"),l1ll1llll1111_l1_)
	return
def l1lll1111lll1_l1_():
	message = {}
	message[l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ捠")] = l11lll_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨ捡")
	message[l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ换")] = l11lll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩ捣")
	message[l11lll_l1_ (u"࠭ࡓࡕࡑࡓࠫ捤")] = l11lll_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ捥")
	l1lll1l1ll11l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ捦"))
	l1lll1ll1l1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ捧"))
	l1ll1lllllll1_l1_ = message[l1lll1ll1l1l1_l1_]+l1lll1l1ll11l_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ捨"),l11lll_l1_ (u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩ捩"),l11lll_l1_ (u"ࠬะิ฻์็ࠤฯ๊โศศํࠫ捪"),l11lll_l1_ (u"࠭ล๋ไสๅ้ࠥวๆๆࠪ捫"),l1ll1lllllll1_l1_,l11lll_l1_ (u"ࠧิ์ิๅึࠦࡄࡏࡕ๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎็๎ๅࠡสอัํ๐ไࠡลึ้ฬวࠠศๆ่์ฬู่๊ࠡสุ่๐ัโำสฮࠥหไ๊ࠢฦี็อๅ๊ࠡ฼๊ิࠦศฺุࠣห้์วิࠢํๆํ๋ࠠษฯฯฬࠥ๎ๅ็฻ࠣ์า฼ัࠡส฼ฺࠥอไๆ๊สๆ฾ࠦ࠮ࠡๆอุ฿๐ไࠡีํีๆืࠠࡅࡐࡖࠤ็๋ࠠษษัฮ๏อัࠡษ็ื๏ืแาࠢส่๊์วิสࠣวํࠦโๆࠢหษ๏่วโ้ࠣฬฬ๊ใศ็็ࠫ捬"))
	if choice==0: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠨࡃࡖࡏࠬ捭")
	elif choice==1: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ据")
	elif choice==2: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ捯")
	if choice in [0,1]:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ捰"),l11lll_l1_ (u"ู๊ࠬาใิ࠾ࠥ࠭捱")+l1lll1l11ll1_l1_[1],l11lll_l1_ (u"࠭ำ๋ำไี࠿ࠦࠧ捲")+l1lll1l11ll1_l1_[0],l11lll_l1_ (u"ࠧࠨ捳"),l11lll_l1_ (u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧ捴"))
		if l1ll11l111_l1_==1: l1111l1ll1l_l1_ = l1lll1l11ll1_l1_[0]
		else: l1111l1ll1l_l1_ = l1lll1l11ll1_l1_[1]
	elif choice==2: l1111l1ll1l_l1_ = l11lll_l1_ (u"ࠩࠪ捵")
	else: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ捶")
	if l1ll1lllll1ll_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ捷"),l1ll1lllll1ll_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ捸"),l1111l1ll1l_l1_)
		l1ll1llll1111_l1_ = message[l1ll1lllll1ll_l1_]+l1111l1ll1l_l1_
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ捹"),l11lll_l1_ (u"ࠧࠨ捺"),l11lll_l1_ (u"ࠨࠩ捻"),l1ll1llll1111_l1_)
	return
def l1lll11l11l11_l1_():
	l1lll1ll1l1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ捼"))
	message = {}
	message[l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ捽")] = l11lll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬ捾")
	message[l11lll_l1_ (u"ࠬࡇࡓࡌࠩ捿")] = l11lll_l1_ (u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧ掀")
	message[l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ掁")] = l11lll_l1_ (u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ掂")
	l1ll1lllllll1_l1_ = message[l1lll1ll1l1l1_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ掃"),l11lll_l1_ (u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ掄"),l11lll_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ掅"),l11lll_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ掆"),l1ll1lllllll1_l1_,l11lll_l1_ (u"࠭วๅสิ์ู่๊้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์฼้้่ࠦิ์ฺࠤอ๐ๆࠡฮ๊หื้้ࠠษ็ษ๋ะั็์อࠤ࠳ࠦ็้ࠢํืฯ๊ๅูࠡ็ฬฬะใ๊ࠡํๆํ๋ࠠษีะฬ์อࠠษั็ห๋ࠥๆไࠢฮ้ࠥ๐ศฺอ๊ห๊ࠥใࠡ࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣว๊ࠦล๋ไสๅࠥอไษำ๋็ุ๐ࠠภࠩ掇"))
	if choice==0: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠧࡂࡕࡎࠫ授")
	elif choice==1: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠨࡃࡘࡘࡔ࠭掉")
	elif choice==2: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ掊")
	else: l1ll1lllll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ掋")
	if l1ll1lllll1ll_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭掌"),l1ll1lllll1ll_l1_)
		l1ll1llll1111_l1_ = message[l1ll1lllll1ll_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭掍"),l11lll_l1_ (u"࠭ࠧ掎"),l11lll_l1_ (u"ࠧࠨ掏"),l1ll1llll1111_l1_)
	return
def l1lll11llllll_l1_():
	l1l111l111ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ掐"))
	if l1l111l111ll_l1_==l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ掑"): header = l11lll_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣฯ๎โโࠩ排")
	else: header = l11lll_l1_ (u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊็ูๅࠩ掓")
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭掔"),l11lll_l1_ (u"࠭ล๋ไสๅࠬ掕"),l11lll_l1_ (u"ࠧหใ฼๎้࠭掖"),header,l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆหี๋อๅอࠢํฮ๊ࠦสฮัํฯ์อࠠฤ๊อ์๊อส๋ๅํหࠥฮูะࠢ࠴࠺ูࠥวฺห้๋ࠣࠦร้ๆࠣวุะฮะษ่ࠤ࠳࠴้ࠠวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋๋ࠠฦา๎ࠥหไ๊ࠢอัิ๐ห่ษࠣๅ๏ࠦใๅ่ࠢีฮ๊ࠦห็ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥ࠴࠮๊๊ࠡิฬ๊ࠦิสหࠤอ฽ฦࠡใํࠤๆะอࠡไ๋หห๋ࠠศๆหี๋อๅอ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠠภࠣࠤࠫ掗"))
	if l1ll11l111_l1_==-1: return
	elif l1ll11l111_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ掘"),l11lll_l1_ (u"ࠪࠫ掙"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ掚"),l11lll_l1_ (u"ࠬ࠭掛"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ掜"),l11lll_l1_ (u"ࠧห็ࠣฮๆ฿๊ๅࠢอาื๐ๆࠡษ็ๆํอฦๆࠩ掝"))
	else:
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ掞"),l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ掟"))
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ掠"),l11lll_l1_ (u"ࠫࠬ採"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ探"),l11lll_l1_ (u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ掣"))
	return
def l1lll111lll1l_l1_(text):
	if text!=l11lll_l1_ (u"ࠧࠨ掤"):
		text = l1l111ll1l1_l1_(text)
		text = text.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭接")).encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ掦"))
		l1l111lll1l_l1_ = 10103
		l1l111ll1ll_l1_ = xbmcgui.l1l111l11ll_l1_(l1l111lll1l_l1_)
		l1l111ll1ll_l1_.getControl(311).l1l11l11111_l1_(text)
		#l1l11l1l1l1l_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡎࡩࡾࡨ࡯ࡢࡴࡧ࠶࠷࠴ࡸ࡮࡮ࠪ控"), xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠫࡵࡧࡴࡩࠩ推")).decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ掩")),l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ措"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ掫"))
		#l1l11l1l1l1l_l1_.show()
		#l1l11l1l1l1l_l1_.getControl(99991).setPosition(0,0)
		#l1l11l1l1l1l_l1_.getControl(311).l1l11l11111_l1_(text)
		#l1l11l1l1l1l_l1_.getControl(5).l1ll1ll1lll1_l1_(l1lll1l1l1l1l_l1_)
		#width = xbmcgui.l1ll1lllll111_l1_()
		#l1ll11111ll1_l1_ = xbmcgui.l1lll11ll1111_l1_()
		#resolution = (0.0+width)/l1ll11111ll1_l1_
		#l1l11l1l1l1l_l1_.getControl(5).l1l11l111lll_l1_(width-180)
		#l1l11l1l1l1l_l1_.getControl(5).setHeight(l1ll11111ll1_l1_-180)
		#l1l11l1l1l1l_l1_.doModal()
		#del l1l11l1l1l1l_l1_
	return
l1ll1lll11l11_l1_ = [
			 l11lll_l1_ (u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࠬ࠭ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨ掬")
			,l11lll_l1_ (u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬ掭")
			,l11lll_l1_ (u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬ掮")
			,l11lll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭掯")
			,l11lll_l1_ (u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭掰")
			,l11lll_l1_ (u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨ掱")
			,l11lll_l1_ (u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱࠩࡳࡴ࡮࠰ࡻࡦࡸ࡮ࡪࡰࡪࡷࠬ掲")
			,l11lll_l1_ (u"ࠨࡋࡱࡷࡪࡩࡵࡳࡧࡕࡩࡶࡻࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩ࠯ࠫ掳")
			,l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࠲ࡃࡲࡵࡤࡦ࠿࠳ࠪࡹ࡫ࡸࡵ࠿ࠪ掴")
			,l11lll_l1_ (u"ࠪࡻࡦࡸ࡮ࡪࡰࡪࡷ࠳ࡽࡡࡳࡰࠫࠫ掵")
			,l11lll_l1_ (u"ࠫࡣࡤ࡞࡟ࡠࠪ掶")
			,l11lll_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪ掷")
			]
def l1lll111l111l_l1_(line):
	if l11lll_l1_ (u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫ掸") in line and l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ掹") in line: return True
	for text in l1ll1lll11l11_l1_:
		if text in line: return True
	return False
def l1ll1ll1l11ll_l1_(data):
	data = data.replace(l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭掺")+51*l11lll_l1_ (u"ࠩࠣࠫ掻")+l11lll_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ掼"),l11lll_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ掽"))
	data = data.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ掾")+51*l11lll_l1_ (u"࠭ࠠࠨ掿")+l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ揀"),l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭揁"))
	data = data.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ揂")+51*l11lll_l1_ (u"ࠪࠤࠬ揃")+l11lll_l1_ (u"ࠫࡡࡴࠧ揄"),l11lll_l1_ (u"ࠬࡢ࡮ࠨ揅"))
	data = data.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ揆")+51*l11lll_l1_ (u"ࠧࠡࠩ揇"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ揈")+31*l11lll_l1_ (u"ࠩࠣࠫ揉"))
	#data = data.replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢ࠰ࡵࡷࡳࡷࡧࡧࡦ࠱ࡨࡱࡺࡲࡡࡵࡧࡧ࠳࠵࠵ࡁ࡯ࡦࡵࡳ࡮ࡪ࠯ࡥࡣࡷࡥ࠴ࡵࡲࡨ࠰ࡻࡦࡲࡩ࠮࡬ࡱࡧ࡭࠴࡬ࡩ࡭ࡧࡶ࠳࠳ࡱ࡯ࡥ࡫࠲ࡥࡩࡪ࡯࡯ࡵ࠲ࠫ揊"),l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠩ揋"))
	data = data.replace(l11lll_l1_ (u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫ揌"),l11lll_l1_ (u"࠭࠺ࠡࠩ揍"))
	l11ll1l11_l1_ = l11lll_l1_ (u"ࠧࠨ揎")
	for line in data.splitlines():
		delete = re.findall(l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ描"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11lll_l1_ (u"ࠩࠪ提"))
		l11ll1l11_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭揑")+line
	#WRITE_THIS(l11lll_l1_ (u"ࠫࠬ插"),l11ll1l11_l1_)
	return l11ll1l11_l1_
def l1ll1lll11111_l1_(l1lll11l1l1l1_l1_):
	if l11lll_l1_ (u"ࠬࡕࡌࡅࠩ揓") in l1lll11l1l1l1_l1_:
		l1lll1l1ll1l1_l1_ = l1ll1llll111_l1_
		header = l11lll_l1_ (u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭揔")
	else:
		l1lll1l1ll1l1_l1_ = l1ll1l11ll11_l1_
		header = l11lll_l1_ (u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧ揕")
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ揖"),l11lll_l1_ (u"ࠩࠪ揗"),l11lll_l1_ (u"ࠪࠫ揘"),header,l11lll_l1_ (u"ุࠫาไࠡษ็วำ฽วยࠢํัฯ๎๊ࠡลํฺฬูࠦๅ๋ࠣืั๊ࠠศๆสืฯิฯศ็ࠣ࠲ࠥ๎วๅษฮ๊๏์ࠠืำ๋ี๏ฯࠠๅ็฼ีๆฯࠠไ์ไࠤาีหหࠢสฺ่๊ใๅหࠣ์๊อ่๊ࠠࠣห้๋ใศ่ࠣห้ึ๊ࠡีหฬࠥำฯ้อࠣห้๋ิไๆฬࠤ࠳ࠦใ้ัํࠤ๏ำสโฺࠣฬุาไ๋่ࠣ࠲ࠥอไฤ๊็ࠤ์๎ࠠศๆึะ้ࠦวๅฯส่๏่ࠦโ์๊ࠤ๊฿ไ้็สฮࠥะศะล้๋ࠣึࠠษัส๎ฮࠦวๅฬื฾๏๊ࠠศๆะห้๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦศๆ์ࠤฬ๊ย็ࠢ࠱ࠤศ๋วࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠโ้๋ࠤฬ๊ำอๆࠣหู้วษไࠣห้ึ๊ࠡฬ่ࠤัู๋่่๊ࠢࠥฮั็ษ่ะ้่ࠥะ์ࠣๆอ๊ࠠระิࠤส฽แศร่ࠣ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ揙"))
	if l1ll11l111_l1_!=1: return
	l1ll1ll1l1lll_l1_,counts = [],0
	size,count = l1l1l1l111_l1_(l1lll1l1ll1l1_l1_)
	#size = os.path.getsize(l1lll1l1ll1l1_l1_)
	file = open(l1lll1l1ll1l1_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ揚"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ換"))
	data = l1ll1ll1l11ll_l1_(data)
	lines = data.split(l11lll_l1_ (u"ࠧ࡝ࡰࠪ揜"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭揝"))
		#if line.strip(l11lll_l1_ (u"ࠩࠣࠫ揞"))==l11lll_l1_ (u"ࠪࠫ揟"): continue
		ignore = l1lll111l111l_l1_(line)
		if ignore: continue
		line = line.replace(l11lll_l1_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡢࠫ揠"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭握"))
		line = line.replace(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖ࠿࠭揢"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࡈࡖࡗࡕࡒ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ揣"))
		l1lll11l1ll11_l1_ = l11lll_l1_ (u"ࠨࠩ揤")
		l1ll1lll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ揥"),line,re.DOTALL)
		if l1ll1lll111ll_l1_:
			line = line.replace(l1ll1lll111ll_l1_[0][0],l1ll1lll111ll_l1_[0][1]).replace(l1ll1lll111ll_l1_[0][2],l11lll_l1_ (u"ࠪࠫ揦"))
			l1lll11l1ll11_l1_ = l1ll1lll111ll_l1_[0][1]
		else:
			l1ll1lll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ揧"),line,re.DOTALL)
			if l1ll1lll111ll_l1_:
				line = line.replace(l1ll1lll111ll_l1_[0][1],l11lll_l1_ (u"ࠬ࠭揨"))
				l1lll11l1ll11_l1_ = l1ll1lll111ll_l1_[0][0]
		if l1lll11l1ll11_l1_: line = line.replace(l1lll11l1ll11_l1_,l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ揩")+l1lll11l1ll11_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ揪"))
		l1ll1ll1l1lll_l1_.append(line)
		if len(str(l1ll1ll1l1lll_l1_))>50100: break
	l1ll1ll1l1lll_l1_ = reversed(l1ll1ll1l1lll_l1_)
	l1lll1l1l1l1l_l1_ = l11lll_l1_ (u"ࠨ࡞ࡱࠫ揫").join(l1ll1ll1l1lll_l1_)
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ揬"),l11lll_l1_ (u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ揭"),l1lll1l1l1l1l_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ揮"))
	return
def l1lll1111l1ll_l1_():
	l1lll1l1ll1ll_l1_ = open(l1l1ll1lllll_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ揯")).read()
	if kodi_version>18.99: l1lll1l1ll1ll_l1_ = l1lll1l1ll1ll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ揰"))
	l1lll1l1ll1ll_l1_ = l1lll1l1ll1ll_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡶࠪ揱"),l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠪ揲"))
	l1l111ll1111_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡺࡡࡪ࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ揳"),l1lll1l1ll1ll_l1_,re.DOTALL)
	for line in l1l111ll1111_l1_:
		l1lll1l1ll1ll_l1_ = l1lll1l1ll1ll_l1_.replace(line,l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭援")+line+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭揵"))
	DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭揶"),l1lll1l1ll1ll_l1_)
	return
def l1lll11lllll1_l1_():
	l1l1ll11111_l1_ = l11lll_l1_ (u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ揷")
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ揸")
	l1111llll1ll_l1_ = l11lll_l1_ (u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ揹")
	message = l1l1ll11111_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬ揺")+l1l1ll1111l_l1_+l11lll_l1_ (u"ࠪࠤ࠳ࠦࠧ揻")+l1111llll1ll_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ揼"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ揽"),message,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ揾"))
	return
def l1111l1lll1_l1_(type,message,l1ll_l1_=True,url=l11lll_l1_ (u"ࠧࠨ揿"),source=l11lll_l1_ (u"ࠨࠩ搀"),text=l11lll_l1_ (u"ࠩࠪ搁"),l111l1ll11l1_l1_=l11lll_l1_ (u"ࠪࠫ搂")):
	l1ll1ll11lll1_l1_ = True
	if not l11l1llll11_l1_(l11lll_l1_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ搃")):
		if l1ll_l1_:
			#if message.count(l11lll_l1_ (u"ࠬࡢ࡜࡯ࠩ搄"))>1: l1l1llll1ll1_l1_ = l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ搅")
			#else: l1l1llll1ll1_l1_ = l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ搆")
			l1ll1lll1l1ll_l1_ = (l11lll_l1_ (u"ࠨษ็ื฼ื࠺ࠨ搇") in message and l11lll_l1_ (u"ࠩส่๊้ว็࠼ࠪ搈") in message and l11lll_l1_ (u"ࠪห้๋ไโ࠼ࠪ搉") in message and l11lll_l1_ (u"ࠫฬ๊ฮุลࠪ搊") in message and l11lll_l1_ (u"ࠬอไๆืาี࠿࠭搋") in message)
			if not l1ll1lll1l1ll_l1_: l1ll1ll11lll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭搌"),l11lll_l1_ (u"ࠧࠨ損"),l11lll_l1_ (u"ࠨࠩ搎"),l11lll_l1_ (u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭搏"),message.replace(l11lll_l1_ (u"ࠪࡠࡡࡴࠧ搐"),l11lll_l1_ (u"ࠫࡡࡴࠧ搑")))
	elif l1ll_l1_:
		message = l11lll_l1_ (u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬ搒")
		l1lll1ll1ll1l_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭搓"),l11lll_l1_ (u"ࠧࠨ搔"),l11lll_l1_ (u"ࠨࠩ搕"),l11lll_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ搖")+l11lll_l1_ (u"ࠪࠤࠥ࠷࠯࠶ࠩ搗"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ搘"))
		l1lll1ll1ll11_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ搙"),l11lll_l1_ (u"࠭ࠧ搚"),l11lll_l1_ (u"ࠧࠨ搛"),l11lll_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ搜")+l11lll_l1_ (u"ࠩࠣࠤ࠷࠵࠵ࠨ搝"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ搞"))
		l1lll1ll1l1ll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ搟"),l11lll_l1_ (u"ࠬ࠭搠"),l11lll_l1_ (u"࠭ࠧ搡"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ搢")+l11lll_l1_ (u"ࠨࠢࠣ࠷࠴࠻ࠧ搣"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ搤"))
		l1lll1lll1111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ搥"),l11lll_l1_ (u"ࠫࠬ搦"),l11lll_l1_ (u"ࠬ࠭搧"),l11lll_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭搨")+l11lll_l1_ (u"ࠧࠡࠢ࠷࠳࠺࠭搩"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭搪"))
		l1ll1ll11lll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ搫"),l11lll_l1_ (u"ࠪࠫ搬"),l11lll_l1_ (u"ࠫࠬ搭"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ搮")+l11lll_l1_ (u"࠭ࠠࠡ࠷࠲࠹ࠬ搯"),l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ搰"))
	user = l11llll1111_l1_(32,False)
	l1lll1l11l11l_l1_ = l11lll_l1_ (u"ࠨࡃ࡙࠾ࠥ࠭搱")+user+l11lll_l1_ (u"ࠩ࠰ࠫ搲")+type
	l1l111l1l1l1_l1_ = True if l11lll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭搳") in text else False
	if not l1ll1ll11lll1_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ搴"),l11lll_l1_ (u"ࠬ࠭搵"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ搶"),l11lll_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪ搷"))
		return False
	l1lll1lll111l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧ搸"))
	message += l11lll_l1_ (u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨ搹")+l11l1llllll_l1_+l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ携")
	message += l11lll_l1_ (u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬ搻")+user+l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫ搼")+l11lll111l1_l1_+l11lll_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ搽")
	message += l11lll_l1_ (u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬ搾")+l1lll1lll111l_l1_
	#l11ll1lll1l_l1_ = l11l1l1llll_l1_(l11lll_l1_ (u"ࠨ࠹࠹࠲࠻࠻࠮࠲࠵࠻࠲࠷࠹࠰ࠨ搿"))
	l1lll1ll1lll_l1_ = l11l1l1llll_l1_()
	l1lll1ll1lll_l1_ = QUOTE(l1lll1ll1lll_l1_)
	if l1lll1ll1lll_l1_: message += l11lll_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡍࡱࡦࡥࡹ࡯࡯࡯࠼ࠣࠫ摀")+l1lll1ll1lll_l1_
	if url: message += l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡗࡕࡐ࠿ࠦࠧ摁")+url
	if source: message += l11lll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡖࡳࡺࡸࡣࡦ࠼ࠣࠫ摂")+source
	message += l11lll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ摃")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ฬศำํࠤฬ๊ลาีส่ࠬ摄"),l11lll_l1_ (u"ࠧศๆิะฬวࠠศๆส๊ฯ฾วาࠩ摅"))
	if l111l1ll11l1_l1_:
		l1lll1l1l1l1l_l1_ = l111l1ll11l1_l1_
		if kodi_version>18.99: l1lll1l1l1l1l_l1_ = l1lll1l1l1l1l_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭摆"))
		l1lll1l1l1l1l_l1_ = base64.b64encode(l1lll1l1l1l1l_l1_)
	elif l1l111l1l1l1_l1_:
		if l11lll_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩ摇") in text: l1lll1ll1l11l_l1_ = l1ll1llll111_l1_
		else: l1lll1ll1l11l_l1_ = l1ll1l11ll11_l1_
		if not os.path.exists(l1lll1ll1l11l_l1_):
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ摈"),l11lll_l1_ (u"ࠫࠬ摉"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ摊"),l11lll_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าࠫ摋"))
			return False
		l1ll1ll1l1lll_l1_,counts = [],0
		size,count = l1l1l1l111_l1_(l1lll1ll1l11l_l1_)
		#size = os.path.getsize(l1lll1ll1l11l_l1_)
		file = open(l1lll1ll1l11l_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ摌"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭摍"))
		data = l1ll1ll1l11ll_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ摎"))
			ignore = l1lll111l111l_l1_(line)
			if ignore: continue
			l1ll1lll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ摏"),line,re.DOTALL)
			if l1ll1lll111ll_l1_:
				line = line.replace(l1ll1lll111ll_l1_[0][0],l1ll1lll111ll_l1_[0][1]).replace(l1ll1lll111ll_l1_[0][2],l11lll_l1_ (u"ࠫࠬ摐"))
			else:
				l1ll1lll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ摑"),line,re.DOTALL)
				if l1ll1lll111ll_l1_: line = line.replace(l1ll1lll111ll_l1_[0][1],l11lll_l1_ (u"࠭ࠧ摒"))
			l1ll1ll1l1lll_l1_.append(line)
			if len(str(l1ll1ll1l1lll_l1_))>121000: break
		l1ll1ll1l1lll_l1_ = reversed(l1ll1ll1l1lll_l1_)
		l1lll1l1l1l1l_l1_ = l11lll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ摓").join(l1ll1ll1l1lll_l1_)
		l1lll1l1l1l1l_l1_ = l1lll1l1l1l1l_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭摔"))
		l1lll1l1l1l1l_l1_ = base64.b64encode(l1lll1l1l1l1l_l1_)
	else: l1lll1l1l1l1l_l1_ = l11lll_l1_ (u"ࠩࠪ摕")
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ摖")][2]
	payload = {l11lll_l1_ (u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬ摗"):l1lll1l11l11l_l1_,l11lll_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭摘"):message,l11lll_l1_ (u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧ摙"):l1lll1l1l1l1l_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ摚"),url,payload,l11lll_l1_ (u"ࠨࠩ摛"),l11lll_l1_ (u"ࠩࠪ摜"),l11lll_l1_ (u"ࠪࠫ摝"),l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ摞"))
	#succeeded = response.succeeded
	html = response.content
	if l11lll_l1_ (u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧ摟") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สๆࠢส่สืำศๆࠪ摠"),l11lll_l1_ (u"ࠧษ่ฯหา࠭摡"))
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ摢"),l11lll_l1_ (u"ࠩࠪ摣"),l11lll_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩ摤"),l11lll_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭摥"))
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"๊ࠬไฤีไࠫ摦"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦวๅวิืฬ๊ࠧ摧"))
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ摨"),l11lll_l1_ (u"ࠨࠩ摩"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ摪"),l11lll_l1_ (u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨ摫"))
	return succeeded
def l1ll1ll1l1111_l1_():
	l1l1ll11111_l1_ = l11lll_l1_ (u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ摬")
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠศๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ摭")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ摮"),l11lll_l1_ (u"ࠧࠨ摯"),l11lll_l1_ (u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ摰"),l1l1ll11111_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ摱")+l1l1ll1111l_l1_)
	l1l1ll11111_l1_ = l11lll_l1_ (u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩ摲")
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦวๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ摳")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭摴"),l11lll_l1_ (u"࠭ࠧ摵"),l11lll_l1_ (u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭摶"),l1l1ll11111_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭摷")+l1l1ll1111l_l1_)
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ摸"),l11lll_l1_ (u"ࠪࠫ摹"),l11lll_l1_ (u"ࠫࠬ摺"),l11lll_l1_ (u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ摻"),l11lll_l1_ (u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪ摼")+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ摽")+l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨ摾"))
	if l1ll11l111_l1_==1: l1lll1l1l1ll1_l1_()
	return
def l1lll1lll1ll1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ摿"),l11lll_l1_ (u"ࠪࠫ撀"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ撁"),l11lll_l1_ (u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ撂"))
	return
def l1lll1ll11111_l1_():
	message = l11lll_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭撃")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ撄"),l11lll_l1_ (u"ࠨࠩ撅"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ撆"),message)
	return
def l1lll11l1111l_l1_():
	message = l11lll_l1_ (u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧ撇")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ撈"),l11lll_l1_ (u"ࠬ࠭撉"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ撊"),message)
	return
def l1ll1ll11ll1l_l1_():
	message = l11lll_l1_ (u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫ撋")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ撌"),l11lll_l1_ (u"ࠩࠪ撍"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭撎"),l11lll_l1_ (u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭撏"),message)
	return
def l1lll1l1l1lll_l1_():
	message = l11lll_l1_ (u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ撐")
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭撑"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ撒"),message,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ撓"))
	return
def l1lll11ll11l1_l1_():
	l1l1ll11111_l1_ = l11lll_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪ撔")
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬ撕")
	l1111llll1ll_l1_ = l11lll_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ撖")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭撗"),l11lll_l1_ (u"࠭ࠧ撘"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ撙"),l1l1ll11111_l1_,l1l1ll1111l_l1_,l1111llll1ll_l1_)
	return
def l1lll111lll11_l1_():
	l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩ撚")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ撛") + l11lll_l1_ (u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩ撜") + str(PERMANENT_CACHE/60/60/24/30) + l11lll_l1_ (u"ฺࠫࠥ็าࠩ撝")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ撞") + l11lll_l1_ (u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ撟") + str(VERYLONG_CACHE/60/60/24) + l11lll_l1_ (u"ࠧࠡ์๋้ࠬ撠")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ撡") + l11lll_l1_ (u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭撢") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠪࠤ๏๎ๅࠨ撣")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ撤") + l11lll_l1_ (u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ撥") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"࠭ࠠิษ฼อࠬ撦")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࠪ撧") + l11lll_l1_ (u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬ撨") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ࠩࠣืฬ฿ษࠨ撩")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭撪") + l11lll_l1_ (u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ撫") + str(l1ll111111ll_l1_/60) + l11lll_l1_ (u"ࠬࠦฯใ์ๅอࠬ撬")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ播") + l11lll_l1_ (u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩ撮") + str(NO_CACHE) + l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠨ撯")
	l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ撰") + l11lll_l1_ (u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧ撱") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬ撲") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫ撳") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪ撴") + str(l1ll111111ll_l1_/60) + l11lll_l1_ (u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩ撵") + str(NO_CACHE) + l11lll_l1_ (u"ࠨࠢาๆ๏่ษࠨ撶")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ撷"),l11lll_l1_ (u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ撸"),l1l1ll1111l_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ撹"))
	return
def l1ll1lll11ll1_l1_():
	message = l11lll_l1_ (u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨ撺")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ撻"),l11lll_l1_ (u"ࠧࠨ撼"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ撽"),message)
	return
def l1ll1llll11ll_l1_():
	message = l11lll_l1_ (u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪ撾")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ撿"),l11lll_l1_ (u"ࠫࠬ擀"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ擁"),message)
	return
def l1lll1l1111l1_l1_():
	message = l11lll_l1_ (u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ擂")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ擃"),l11lll_l1_ (u"ࠨࠩ擄"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ擅"),message)
	return
def l1ll1lll1lll1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ擆"),l11lll_l1_ (u"ࠫࠬ擇"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ擈"),l11lll_l1_ (u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ擉"))
	l111ll1l11l_l1_(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ擊"),True)
	return
def l1lll11111ll1_l1_():
	message  = l11lll_l1_ (u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪ擋")
	#message += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ่่าสࠤฬู๊ศศๅࠤ์๎ࠠࡳࡧࡆࡅࡕ࡚ࡃࡉࡃࠣห้ิวึࠢหุึ้ษࠡฮ๋ะ้ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ擌")
	#message += l11lll_l1_ (u"ࠪ์ฬ๊ะุ๋๊ࠢ฾ะ็ࠡึิ็ฮࠦฬ้ฮ็ࠤำ฻๊ึษ่๊ࠣ์ูࠡสิห๊าࠠๆอ็ࠤ่๎ฯ๋่๊ࠢࠥะีโฯࠣห้หๆหำ้ฮࠬ操")
	message += l11lll_l1_ (u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ擎")
	message += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ擏")
	message += l11lll_l1_ (u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭擐")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭擑"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ擒"),message,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ擓"))
	message = l11lll_l1_ (u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭擔")
	message += l11lll_l1_ (u"ࠫࡡࡴࠧ擕")+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ擖")
	message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ擗")+l11lll_l1_ (u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ擘")
	message += l11lll_l1_ (u"ࠨ࡞ࡱࠫ擙")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊฻ัࠡࠢส่่๎๊หࠢࠣว๊๐ัไษࠣࠤ่์ฯศࠢࠣๅึ์ำศࠢࠣห้๐่็ษ้ࠤࠥฮัู๋ส๊๏อࠠศๆศ้ฬืวหࠢฦ่๊อๆ๋ษࠣีํู๊ศࠢส่๏อศศ่ࠣหูู้้ัํอࠥื่ๆษ้๎ฬࠦ็้ๆ้ำฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ據")
	message += l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ擛")+l11lll_l1_ (u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬ擜")
	message += l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ศำึ่ࠥืำศๆฬࠤ๊สฯษหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡส็ฯฮࠠโ์๊หࠥอำๆࠢห่ิ้้ࠠลึ้ฬวࠠศๆ่์ฬู่ࠡษ็ฮ๏ࠦไศࠢอืฯ฽ฺ๊ࠢาาํ๊็ศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ擝")
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ擞"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ擟"),message,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ擠"))
	#l1l1lll1111l_l1_(l11lll_l1_ (u"ࠩࡌࡷࡕࡸ࡯ࡣ࡮ࡨࡱࡂࡌࡡ࡭ࡵࡨࠫ擡"))
	#message = l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ擢")+l11lll_l1_ (u"ࠫํ๊โะࠢ็หา฾ๆศࠢส๎฻อࠠฤ่ࠣห้๋่ศไ฼ࠤฬ๊ๅฺษๅอࠥะฮหๆไࠤออฮหๆสๅࠥอไษๆาࠤํะฮหๆไࠤออฮหๆสๅฺࠥัไหࠣห้อๆหำ้๎ฯࠦแ๋ࠢำ่่ࠦวๅส็ำࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊์ࠦอห๋่ࠣํࠦสๆࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣࡔࡷࡵࡸࡺࠢฦ์ࠥษ๊๊ࠡึ๎้ฯࠠศะิํࠥ็ว็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤุ๎แࠡฬัฮ้็้ࠠๆๆ๊์อࠠๅ่ࠣฮ฾๋ไࠡฮ่๎฾ํวࠨ擣")
	#message += l11lll_l1_ (u"๊ࠬอๅࠢสฺ่๊ใๅหࠣๆ๊ࠦศฺ็็๎๋ࡀࠠࠡࠢࠣห้ษ่ๅ࠼ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮่ࠦศๅอฬู๋่ࠥࠢสื๊ࠦศๅัๆࠤํอำๆࠢืี่ฯࠠศๆศ๊ฯืๆ๋ฬࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะูๆๆࠣ฽๋ีใࠨ擤")
	#message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ擥")+l11lll_l1_ (u"้ࠧษ็ฯฬ์๊࠻ࠢฯีอࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤํ฿ๆะࠢส่อ฿ึࠡไาࠤฯำสศฮࠣๅ็฽ࠠห฼ํ๎ึࠦࡄࡏࡕࠣ์ฬ๊รฮี้ࠤศ์๋ࠠๅ๋๊ࠥ็๊ࠡส็ำࠥอฮาࠢ฼่๊อࠠศ่ࠣหุะฮะษ่ࠤࡕࡸ࡯ࡹࡻࠣๆิ๊ࠦฮๆู้้ࠣไสࠢห฽฻ࠦวๅ็๋ห็฿้ࠠๆๆ๊๊๊ࠥิࠢไ๎ࠥาๅ๋฻ࠣห้ี่ๅࠩ擦")
	#DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠨ็ื็้ฯฺ่ࠠาࠤอ฿ึࠡษ็๊ฬูࠧ擧"),message)
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ擨"),l11lll_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭擩"),l11lll_l1_ (u"ࠫ์ึวࠡษ็ๅา฻่๊่๊ࠠࠣ฿ัโห๋้ࠣࠦวๅ็ื็้ฯࠠๆ่ࠣ฽๋ีใࠡษ่ࠤ๊์ࠠศๆหี๋อๅอ࠰ࠣื๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหๅา฻ࠠๆ๊สๆ฾ํࠠๆำอ๎๋ࠦวๅล๋่๎ࠦศุ้฼็ࠥอไุสํ฽๏่ࠦศๆฮห๋๐ษࠡสสืฯิฯศ็ࠣฬึ๎ใิ์้ࠣัอๆ๋ࠢส๊ฯࠦสฯฬสี์ࠦๅ็ࠢส่็อฦๆหࠣห้ะ๊ࠡีอ฼์ืࠠๅษะๆฬ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิรࠬ擪"),l11lll_l1_ (u"ࠬ࠭擫"),l11lll_l1_ (u"࠭ࠧ擬"),l11lll_l1_ (u"ࠧไๆสࠫ擭"),l11lll_l1_ (u"ࠨ่฼้ࠬ擮"))
	#if l1ll11l111_l1_==1:
	#l1lll11l1l111_l1_()
	return
def l1lll111ll111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ擯"),l11lll_l1_ (u"ࠪࠫ擰"),l11lll_l1_ (u"ࠫะ๊วฬฺࠢี็ࠦไๅฬ๋หฺ๊ࠠๆ฻ࠣห้๋ศา็ฯࠫ擱"),l11lll_l1_ (u"ࠬษัิๆࠣีุอไสࠢฦ์๋ࠥิไๆฬࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥํะศࠢส่อืๆศ็ฯࡠࡳࡢ࡮ฤ๊ࠣฬฬูสฯัส้ࠥอไโ์ึฬํ้ࠠฤั้ห์ࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ล๋ࠤออัิษ็ࠤฬ๐ๅ๋ๆࠣห้๏ࠠฤั้ห์ࠦࠠ࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸ࡁࡩࡰࡥ࡮ࡲ࠮ࡤࡱࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ擲"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ擳"),l11lll_l1_ (u"ࠧࠨ擴"),l11lll_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ擵"),l11lll_l1_ (u"ࠩ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࡡࡴ࡜࡯࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࡤ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࡡࡍࡎࡏࡐࡊ࠲ࡡࡎࡏࡐࡑࡋ࠲ࡡࡏࡐࡑࡒࡌ࠲ࡡࡐࡑࡒࡓࡍ࠲ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤࡆࡇࡁࡂࡃ࠵ࡣࡇࡈࡂࡃࡄ࠵ࡣࡈࡉࡃࡄࡅ࠵ࡣࡉࡊࡄࡅࡆ࠵ࡣࡊࡋࡅࡆࡇ࠵ࡣࡋࡌࡆࡇࡈ࠵ࡣࡌࡍࡇࡈࡉ࠵ࡣࡍࡎࡈࡉࡊ࠵ࡣࡎࡏࡉࡊࡋ࠵ࡣࡏࡐࡊࡋࡌ࠵ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࠤ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇࠠࡃࡄࡅࡆࡇ࠭擶"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ擷"),l11lll_l1_ (u"ࠫࠬ擸"),l11lll_l1_ (u"ࠬࡈࡂࡃࡄࡅࡆࡇࡈࡂࡃࠢࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ擹"),l11lll_l1_ (u"࠭࠰ࠡ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠿ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ擺"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ擻"),l11lll_l1_ (u"ࠨࠩ擼"),l11lll_l1_ (u"ࠩࡅࡆࡇࡈࡂࡃࡄࡅࡆࡇࠦࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ擽"),l11lll_l1_ (u"ࠪ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠩ擾"))
	#text = l11lll_l1_ (u"ࠫ࠭ࠦࡁࡂࡃࡄࡅ࠶ࡥࡂࡃࡄࡅࡆ࠶ࡥࡃࡄࡅࡆࡇ࠶ࡥࡄࡅࡆࡇࡈ࠶ࡥࡅࡆࡇࡈࡉ࠶ࡥࡆࡇࡈࡉࡊ࠶ࡥࡇࡈࡉࡊࡋ࠶ࡥࡈࡉࡊࡋࡌ࠶ࡥࡉࡊࡋࡌࡍ࠶ࠦࠩࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠧ擿")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭攀"),l11lll_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ攁"),l11lll_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ攂"),l11lll_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ攃"),l11lll_l1_ (u"ࠩ࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶࠷࠸࠲࠳࠴ࠪ攄"),text,l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ攅"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࠬ攆"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ攇"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭攈"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ攉"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ攊"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭攋"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ攌"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攍"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ攎"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭攏"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攐"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ攑"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ攒"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ攓"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攔"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ攕"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攖"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攗"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ攘"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ攙"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ攚"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ攛"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈ࡝ࡰࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ攜"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ攝"))
	return
def l1lll111l1l11_l1_():
	l1lll111lll11_l1_()
	l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ攞"),l11lll_l1_ (u"ࠨࠩ攟"),l11lll_l1_ (u"ࠩࠪ攠"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤู๊อࠡฮ่๎฾ࠦวๅๅสุࠥลࠧ攡"),l11lll_l1_ (u"ࠫฬ๊ใศึࠣ๎ุืูࠡ฻่่ࠥอไษำ้ห๊า้ࠠ็ึั์ฺ๊ࠦ์าࠤุำศࠡษ็ูๆำวห่๊ࠢࠥอไฦ่อี๋ะฺ่ࠠาࠤฬ๊อศฮฬࠤส๊๊่ษࠣ์ฬ๊ๅิฯࠣ๎ฯ๋ࠠหๆๅหห๐วࠡ฻้ำࠥอๆห้สลࠥ฿ๅาࠢสฺ่็อศฬࠣ์ฬ๊ๅิฯ่ࠣฬ๊ࠦืำࠣ์๊๋ใ็ࠢํั้ࠦศฺุࠣห้๋ิศๅ็ࠫ攢"))
	if l1ll11l111_l1_==1:
		l111l11ll11_l1_(True)
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭攣"),l11lll_l1_ (u"࠭ࠧ攤"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧ攥"),l11lll_l1_ (u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩ攦"))
	return l1ll11l111_l1_
def l1ll1lllll11_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭攧"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩ攨"),l11lll_l1_ (u"ࠫࠬ攩"),l11lll_l1_ (u"ࠬ࠭攪"),False,l11lll_l1_ (u"࠭ࠧ攫"),l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ攬"))
	#html = response.content
	if not response.succeeded:
		l1lll111111ll_l1_ = False
		l11l1lllll_l1_ = l11l1ll111_l1_()
		LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭攭"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧ攮")+l11l1lllll_l1_+l11lll_l1_ (u"ࠪࡡࠬ支"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ攰"),l11lll_l1_ (u"ࠬ࠭攱"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ攲"),l11lll_l1_ (u"ࠧโฯุࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠴࠮࠯ุ่่๊ࠢษࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯ࠠๅษࠣ๎฾๋ไࠡ฻้ำู่ࠦๅ๋ࠣ็ํี๊ࠡ࠰࠱࠲ࠥ๎ู็ัๆࠤ่๎ฯ๋ࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ攳"))
	else:
		l1lll111111ll_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ攴"),l11lll_l1_ (u"ࠩࠪ攵"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭收"),l11lll_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ攷"))
	if not l1lll111111ll_l1_ and l1ll_l1_: l1lll11ll111l_l1_()
	return l1lll111111ll_l1_
def l1lll11ll111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭攸"),l11lll_l1_ (u"࠭ࠧ改"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ攺"),l11lll_l1_ (u"ࠨส฼ฺࠥอไๆ๊สๆ฾ࠦสฮฬสะࠥืศุุ่ࠢๆื้ࠠไาࠤ๏้่็ࠢฯ๋ฬุใࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศๆิฬ฼ࠦวๅ็ืๅึࠦร้๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢื๋ฬีษࠡษ็ฮู็๊าࠢส่ำอีสࠢห็ํี๊ࠡ฻้ำู่ࠦๅ็สࠤฬ์็ࠡฬ่ࠤๆำีࠡษ็ฬึ์วๆฮࠣ฽้๏ࠠไ๊า๎ࠥอไฦืาหึอสࠡ࡞ࡱࠤ࠶࠽࠮࠷ࠢࠣࠪࠥࠦ࠱࠹࠰࡞࠴࠲࠿࡝ࠡࠢࠩࠤࠥ࠷࠹࠯࡝࠳࠱࠸ࡣࠧ攻"))
	#l1l1ll1111l_l1_ = l11lll_l1_ (u"ࠩื๋ฬีษࠡษ็ฮู็๊า๊ࠢ๎๋ࠥไโࠢํัฯ๎๊ࠡ฻็ํฺࠥแาหࠣาฬ฻ษࠡล๋ࠤฯ๎วใ์฼ࠤำอีสࠢ็ุึ้วห่ࠢ฽ึ๎แส๋่ࠢ์ࠦสศำําࠥ฻ไศฯํอࠥ๎ๆโษำࠤํอไ฻ำูࠤ๊์็้๋ࠡࠤฯฮวะๆࠣหู้๋ๅ๊่หฯࠦศุำํๆฮࠦๅีใิอࠥ๐ีฺสࠣหำะัศไ๊หࠥ๎แ่็๊หࠬ攼")
	l1lll1l1111ll_l1_()
	return
def l1l1lll1111l_l1_(text=l11lll_l1_ (u"ࠪࠫ攽")):
	l1l111l1l1l1_l1_ = True
	if l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ放") not in text:
		l1l111l1l1l1_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ政"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ敀"),l11lll_l1_ (u"ࠧฦำึห้ࠦๅีๅ็อࠬ敁"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠาีส่ฮ࠭敂"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ敃"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤส๊้ࠡษ็้อืๅอࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠๆึๆ่ฮࠦๅ้ฮ๋ำฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤ࠭敄"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l111l1l1l1_l1_ = True
			text = l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ故")
	if l1l111l1l1l1_l1_:
		#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ敆"),l11lll_l1_ (u"࠭ࠧ敇"),l11lll_l1_ (u"ࠧࠨ效"),l11lll_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ敉"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ敊"))
		#if not l1ll11l111_l1_:
		#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ敋"),l11lll_l1_ (u"ࠫࠬ敌"),l11lll_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ敍"),l11lll_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ敎"))
		#	return
		l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ敏")
		if l11lll_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ敐") not in text:
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ救"),l11lll_l1_ (u"ࠪࠫ敒"),l11lll_l1_ (u"ࠫࠬ敓"),l11lll_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ敔"),l11lll_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭敕"))
			if l1ll11l111_l1_!=1:
				DIALOG_OK(l11lll_l1_ (u"ࠧࠨ敖"),l11lll_l1_ (u"ࠨࠩ敗"),l11lll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ敘"),l11lll_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭教"))
				return
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ敚"),l11lll_l1_ (u"ࠬ࠭敛"),l11lll_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ敜"),l11lll_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ敝"))
	search = OPEN_KEYBOARD(header=l11lll_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ敞"),source=script_name)
	if not search: return
	message = search
	if l1l111l1l1l1_l1_: type = l11lll_l1_ (u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪ敟")
	else: type = l11lll_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫ敠")
	succeeded = l1111l1lll1_l1_(type,message,True,l11lll_l1_ (u"ࠫࠬ敡"),l11lll_l1_ (u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡘࡗࡊࡘࡓࠨ敢"),text)
	#	url = l11lll_l1_ (u"࠭࡭ࡺࠢࡄࡔࡎࠦࡡ࡯ࡦ࠲ࡳࡷࠦࡓࡎࡖࡓࠤࡸ࡫ࡲࡷࡧࡵࠫ散")
	#	payload = l11lll_l1_ (u"ࠧࡼࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ࠾ࠧࡓ࡙ࠡࡃࡓࡍࠥࡑࡅ࡚ࠤ࠯ࠦࡹࡵࠢ࠻࡝ࠥࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠤࡠ࠰ࠧࡹࡥ࡯ࡦࡨࡶࠧࡀࠢ࡮ࡧࡃࡩࡲࡧࡩ࡭࠰ࡦࡳࡲࠨࠬࠣࡵࡸࡦ࡯࡫ࡣࡵࠤ࠽ࠦࡋࡸ࡯࡮ࠢࡄࡶࡦࡨࡩࡤ࡙ࠢ࡭ࡩ࡫࡯ࡴࠤ࠯ࠦࡹ࡫ࡸࡵࡡࡥࡳࡩࡿࠢ࠻ࠤࠪ敤")+message+l11lll_l1_ (u"ࠨࠤࢀࠫ敥")
	#	#auth=(l11lll_l1_ (u"ࠤࡤࡴ࡮ࠨ敦"), l11lll_l1_ (u"ࠥࡱࡾࠦࡰࡦࡴࡶࡳࡳࡧ࡬ࠡࡣࡳ࡭ࠥࡱࡥࡺࠤ敧")),
	#	import requests
	#	response = requests.request(l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ敨"),url, data=payload, headers=l11lll_l1_ (u"ࠬ࠭敩"), auth=l11lll_l1_ (u"࠭ࠧ敪"))
	#	response = requests.post(url, data=payload, headers=l11lll_l1_ (u"ࠧࠨ敫"), auth=l11lll_l1_ (u"ࠨࠩ敬"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ敭"),l11lll_l1_ (u"ࠪࠫ敮"),l11lll_l1_ (u"ࠫࠬ敯"),l11lll_l1_ (u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨ数"))
	#	else:
	#		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ敱"),l11lll_l1_ (u"ࠧࠨ敲"),l11lll_l1_ (u"ࠨะฺวࠥ็๊ࠡษ็ษึูวๅࠩ敳"),l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࡽࢀ࠾ࠥࢁࠡࡳࡿࠪ整").format(response.status_code, response.content))
	#	l1ll1llllll11_l1_ = l11lll_l1_ (u"ࠪࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩ敵")
	#	l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ敶")
	#	header = l11lll_l1_ (u"ࠬ࠭敷")
	#	#header += l11lll_l1_ (u"࠭ࡆࡳࡱࡰ࠾ࠥ࠭數") + l1ll1llllll11_l1_
	#	#header += l11lll_l1_ (u"ࠧ࡝ࡰࡗࡳ࠿ࠦࠧ敹") + l1ll1ll11ll11_l1_
	#	#header += l11lll_l1_ (u"ࠨ࡞ࡱࡇࡨࡀࠠࠨ敺") + l1ll1ll11ll11_l1_
	#	header += l11lll_l1_ (u"ࠩ࡟ࡲࡘࡻࡢ࡫ࡧࡦࡸ࠿ࠦๅ็ࠢๆ์ิ๐ࠠศๆไ๎ิ๐่ࠡษ็฽ึฮ๊ࠨ敻")
	#	server = l1lll1ll11ll1_l1_.l1lll1111l111_l1_(l11lll_l1_ (u"ࠪࡷࡲࡺࡰ࠮ࡵࡨࡶࡻ࡫ࡲࠨ敼"),25)
	#	#server.l1lll11l111ll_l1_()
	#	server.l1lll11l11lll_l1_(l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪ࠭敽"),l11lll_l1_ (u"ࠬࡶࡡࡴࡵࡺࡳࡷࡪࠧ敾"))
	#	response = server.l1lll11lll11l_l1_(l1ll1llllll11_l1_,l1lll111l1lll_l1_, header + l11lll_l1_ (u"࠭࡜࡯ࠩ敿") + message)
	#	server.quit()
	return
def l1lll1l1l111l_l1_():
	text = l11lll_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫ斀")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ斁"),l11lll_l1_ (u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩ斂"),text,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭斃"))
	text = l11lll_l1_ (u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧ斄")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ斅"),l11lll_l1_ (u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫ斆"),text,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ文"))
	return
def l1lll11l11l1l_l1_(addon_id):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ斈"),l11lll_l1_ (u"ࠩࠪ斉"),l11lll_l1_ (u"ࠪࠫ斊"),addon_id)
	result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ斋")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡪࡦࡲࡳࡦࡿࢀࠫ斌"))
	l1l1l11111_l1_ = True
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡷ࡭ࡻࡴࡪ࡮ࠍࠍࡽࡨ࡭ࡤࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡹࡤࡰࡧ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡧࡤࡥࡱࡱࡷࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠌࠌ࡭࡫ࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫ࠽ࠎࠎࠏࡳࡩࡷࡷ࡭ࡱ࠴ࡲ࡮ࡶࡵࡩࡪ࠮ࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠪࠌࠌࠍࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡃࠠࡕࡴࡸࡩࠏࠏࡵࡴࡧࡵࡪ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡸࡷࡪࡸࡦࡰ࡮ࡧࡩࡷ࠲ࠧࡢࡦࡧࡳࡳࡹࠧ࠭ࡣࡧࡨࡴࡴ࡟ࡪࡦࠬࠎࠎ࡯ࡦࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰ࡨࡼ࡮ࡹࡴࡴࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭࠿ࠐࠉࠊࡵ࡫ࡹࡹ࡯࡬࠯ࡴࡰࡸࡷ࡫ࡥࠩࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡲࡦࡨࡵࡩࡸ࡮ࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࠥ࡬ࡱࡵࡵࡲࡵࠢࡶࡵࡱ࡯ࡴࡦ࠵ࠍࠍࡨࡵ࡮࡯ࠢࡀࠤࡸࡷ࡬ࡪࡶࡨ࠷࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡡࡥࡦࡲࡲࡸࡥࡤࡣࡨ࡬ࡰࡪ࠯ࠊࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࡩࡣࠡ࠿ࠣࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫࠍࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫࠧࠦ࠻ࠨࠫࠍࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡢࡦࡧࡳࡳࡹࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ࠰ࡧࡤࡥࡱࡱࡣ࡮ࡪࠫࠨࠤࠣ࠿ࠬ࠯ࠊࠊࠥࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡸࡥࡱࡱࡶࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡴࡳ࡭ࡪࡶࠫ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠢࠣࠤ斍")
	if l1l1l11111_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ斎"))
		time.sleep(1)
	return
def l1lll1l111111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ斏"),l11lll_l1_ (u"ࠩࠪ斐"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭斑"),l11lll_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩ斒"))
	l1lll1l1111l1_l1_()
	return
def l1lll1l1111ll_l1_():
	#	https://l1111ll111l_l1_.tv/download/849
	#   https://play.google.com/l1lll111l1111_l1_/l1lll11l111l1_l1_/details?id=l1ll1ll111l_l1_.xbmc.l1111ll111l_l1_
	#	http://mirror.l1lll11llll11_l1_.l1ll1llllll1l_l1_.l1lll1lll1l11_l1_/l1lll11ll1l1l_l1_/xbmc/l1lll1111ll11_l1_/l1ll1ll1l11l1_l1_/l1lll11lll111_l1_
	#	http://l1ll1lll1llll_l1_.l1ll1ll1lll1l_l1_.l1lll1lll1l11_l1_/l1111ll111l_l1_/l1lll1111ll11_l1_/l1ll1ll1l11l1_l1_/l1lll11lll111_l1_
	url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳࡩࡳࡴࡲࡶࡸ࠴࡫ࡰࡦ࡬࠲ࡹࡼ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡴ࠱ࡺ࡭ࡳࡪ࡯ࡸࡵ࠲ࡻ࡮ࡴ࠶࠵࠱ࠪ斓")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ斔"),url,l11lll_l1_ (u"ࠧࠨ斕"),l11lll_l1_ (u"ࠨࠩ斖"),l11lll_l1_ (u"ࠩࠪ斗"),l11lll_l1_ (u"ࠪࠫ斘"),l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡉࡑ࡚ࡣࡑࡇࡔࡆࡕࡗࡣࡐࡕࡄࡊࡡ࡙ࡉࡗ࡙ࡉࡐࡐ࠰࠵ࡸࡺࠧ料"))
	html = response.content
	l1ll1ll1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࡁࠧࡱ࡯ࡥ࡫࠰ࠬࡡࡪࠫ࡝࠰࡟ࡨ࠰࠳࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠫ࠰ࠫ斚"),html,re.DOTALL)
	l1ll1ll1ll1l1_l1_ = l1ll1ll1ll1l1_l1_[0].split(l11lll_l1_ (u"࠭࠭ࠨ斛"))[0]
	l1lll1ll1llll_l1_ = str(kodi_version)
	#l1111lllll11_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ斜")+l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮ่ࠣฬฺ๊ࠦ็็ࠤ๊฿ࠠไ๊า๎ࠥหีะษิࠤ࠶࠿้ࠠ็สࠤอ฿ฯ่ࠩ斝")+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ斞")
	l1111lllll11_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไฤะํีࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ斟")+l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ斠")+l1ll1ll1ll1l1_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ斡")
	l1111lllll11_l1_ += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ斢")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭斣")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ斤")+l1lll1ll1llll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ斥")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ斦"),l11lll_l1_ (u"ࠫࠬ斧"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ斨"),l1111lllll11_l1_)
	return
def l1ll1llll11l1_l1_():
	# https://l111llll1ll_l1_-l1lll1lllll_l1_-l111l11l1l1_l1_.l1lll1llll1l1_l1_.com/request-l1lll111llll1_l1_
	# https://l111llll1ll_l1_-l1lll1lllll_l1_-l111l11l1l1_l1_.l1lll1llll1l1_l1_.com/query-l1ll1ll1ll1ll_l1_
	l1l1ll11111_l1_,l1l1ll1111l_l1_,l1111llll1ll_l1_,l1111lllll11_l1_,l1lll1l111l1l_l1_,l1ll1ll1l111l_l1_,l1lll1111l11l_l1_ = l11lll_l1_ (u"࠭ࠧ斩"),l11lll_l1_ (u"ࠧࠨ斪"),l11lll_l1_ (u"ࠨࠩ斫"),l11lll_l1_ (u"ࠩࠪ斬"),l11lll_l1_ (u"ࠪࠫ断"),l11lll_l1_ (u"ࠫࠬ斮"),l11lll_l1_ (u"ࠬ࠭斯")
	payload,l1ll1ll1lll11_l1_,l1lll11ll1l11_l1_,l1ll1ll1l1l11_l1_ = {l11lll_l1_ (u"࠭ࡡࠨ新"):l11lll_l1_ (u"ࠧࡢࠩ斱")},{},[],{}
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ斲")][1]
	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ斳"),url,payload,l11lll_l1_ (u"ࠪࠫ斴"),l11lll_l1_ (u"ࠫࠬ斵"),l11lll_l1_ (u"ࠬ࠭斶"),l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫ斷"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡔࡶࡤࡸࡪࡹࠧ斸"),l11lll_l1_ (u"ࠨࡗࡖࡅࠬ方"))
	html = html.replace(l11lll_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪ斺"),l11lll_l1_ (u"࡙ࠪࡐ࠭斻"))
	html = html.replace(l11lll_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡆࡸࡡࡣࠢࡈࡱ࡮ࡸࡡࡵࡧࡶࠫ於"),l11lll_l1_ (u"࡛ࠬࡁࡆࠩ施"))
	html = html.replace(l11lll_l1_ (u"࠭ࡓࡢࡷࡧ࡭ࠥࡇࡲࡢࡤ࡬ࡥࠬ斾"),l11lll_l1_ (u"ࠧࡌࡕࡄࠫ斿"))
	html = html.replace(l11lll_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ旀"),l11lll_l1_ (u"ࠩࡑ࠲ࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧ旁"))
	html = html.replace(l11lll_l1_ (u"࡛ࠪࡪࡹࡴࡦࡴࡱࠤࡘࡧࡨࡢࡴࡤࠫ旂"),l11lll_l1_ (u"ࠫ࡜࠴ࡓࡢࡪࡤࡶࡦ࠭旃"))
	html = html.replace(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ旄"),l11lll_l1_ (u"࠭ࠠࠡࠩ旅"))
	try: l1lll11ll11ll_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ旆"),html)
	except:
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ旇"),l11lll_l1_ (u"ࠩࠪ旈"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭旉"),l11lll_l1_ (u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫ旊"))
		return
	l1lll1l1llll1_l1_,l1lll1lll11l1_l1_,l1lll111ll1l1_l1_ = l1lll11ll11ll_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭旋"),str(l1lll1l1llll1_l1_))
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ旌"),str(l1lll1lll11l1_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ旍"),str(l1lll111ll1l1_l1_))
	l1ll1ll1l1l11_l1_ = {}
	l1111l11l1l_l1_ = [l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࠨ旎"),l11lll_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ族"),l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ旐")]
	l1llll1111l1_l1_ = [l11lll_l1_ (u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭旑"),l11lll_l1_ (u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭旒"),l11lll_l1_ (u"࠭ࡅࡎࡃࡌࡐࡘ࠭旓"),l11lll_l1_ (u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ旔"),l11lll_l1_ (u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪ旕"),l11lll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ旖"),l11lll_l1_ (u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨ旗"),l11lll_l1_ (u"ࠫࡈࡇࡐࡕࡅࡋࡅࡌࡋࡔࡊࡆࠪ旘"),l11lll_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡖࡒࡏࡊࡔࠧ旙")]
	l1lll1llll1ll_l1_ = [l11lll_l1_ (u"࠭ࡁࡍࡎࠪ旚"),l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ旛"),l11lll_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ旜"),l11lll_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭旝"),l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ旞")]+l1llll1111l1_l1_+l1111l11l1l_l1_
	for l1l1l1l1l1l_l1_,l1lll1ll11lll_l1_,l1lll1l1lll11_l1_ in l1lll1lll11l1_l1_:
		l1lll1l1lll11_l1_ = escapeUNICODE(l1lll1l1lll11_l1_)
		l1lll1l1lll11_l1_ = l1lll1l1lll11_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭旟")).strip(l11lll_l1_ (u"ࠬࠦ࠮ࠨ无"))
		l1111lllll11_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ旡")+l1l1l1l1l1l_l1_+l11lll_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ既")+l1lll1l1lll11_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ旣")
		if l1lll1ll11lll_l1_.isdigit():
			l1ll1ll1l1l11_l1_[l1l1l1l1l1l_l1_] = int(l1lll1ll11lll_l1_)
			if int(l1lll1ll11lll_l1_)>100: l1lll1ll11lll_l1_ = l11lll_l1_ (u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ旤")
			else: l1lll1ll11lll_l1_ = l11lll_l1_ (u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬ日")
		if l1l1l1l1l1l_l1_ not in l1lll1llll1ll_l1_:
			if   l1lll1ll11lll_l1_==l11lll_l1_ (u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧ旦"): l1l1ll11111_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠨ旧")+l1l1l1l1l1l_l1_
			elif l1lll1ll11lll_l1_==l11lll_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ旨"): l1l1ll1111l_l1_ += l11lll_l1_ (u"ࠧࠡࠢࠪ早")+l1l1l1l1l1l_l1_
	l1lll1llll11l_l1_,l1lll11111l11_l1_,l1lll1111l1l1_l1_ = list(zip(*l1lll1lll11l1_l1_))
	for l1l1l1l1l1l_l1_ in sorted(l1l1ll111lll_l1_):
		if l1l1l1l1l1l_l1_ not in l1lll1llll11l_l1_:
			l1111lllll11_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭旪")+l1l1l1l1l1l_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭旫")+l11lll_l1_ (u"่ࠪฬ๊้ࠦฮาࠫ旬")+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ旭")
			if l1l1l1l1l1l_l1_ not in l1lll1llll1ll_l1_: l1111llll1ll_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠨ旮")+l1l1l1l1l1l_l1_
	for l1lll1l1lll11_l1_,counts in l1lll1l1llll1_l1_:
		l1lll1l1lll11_l1_ = escapeUNICODE(l1lll1l1lll11_l1_)
		l1lll1l111l1l_l1_ += l1lll1l1lll11_l1_+l11lll_l1_ (u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ旯")+str(counts)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬ旰")
	l1l1ll11111_l1_ = l1l1ll11111_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ旱"))
	l1l1ll1111l_l1_ = l1l1ll1111l_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ旲"))
	l1111llll1ll_l1_ = l1111llll1ll_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ旳"))
	l1111llllll1_l1_ = l1l1ll11111_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ旴")+l1l1ll1111l_l1_
	#l1lllllll11l1_l1_  = l11lll_l1_ (u"ࠬࡢ࡮ࡉ࡫ࡪ࡬࡚ࡹࡡࡨࡧ࠽ࠤࡠࠦࠧ旵")+l1l1ll11111_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ时")
	#l1lllllll11l1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࡏࡳࡼ࡛ࡳࡢࡩࡨࠤ࠿࡛ࠦࠡࠩ旷")+l1l1ll1111l_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ旸")
	#l1lllllll11l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡓࡵࡕࡴࡣࡪࡩࠥࠦ࠺ࠡ࡝ࠣࠫ旹")+l1111llll1ll_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭旺")
	l1111lllll1l_l1_  = l11lll_l1_ (u"๊ࠫ๎วใ฻๊ࠣัำࠠศๆหี๋อๅอࠢหฮูเ๊ๅࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ旻")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ旼")+l11lll_l1_ (u"่่࠭าสࠤ๊฿ๆศ้ࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠫ旽")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ旾")
	l1111lllll1l_l1_ += l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ旿")+l1111llllll1_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ昀")
	l1111lllll1l_l1_ += l11lll_l1_ (u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩ昁")+l11lll_l1_ (u"ࠫࡡࡴࠧ昂")+l11lll_l1_ (u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩ昃")+l11lll_l1_ (u"࠭࡜࡯ࠩ昄")
	l1111lllll1l_l1_ += l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ昅")+l1111llll1ll_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ昆")
	l1llllll11l1_l1_,l1ll1llll1l11_l1_,l1lll11lll1ll_l1_,l1ll1lll1ll1l_l1_ = 0,0,0,0
	all = l1ll1ll1l1l11_l1_[l11lll_l1_ (u"ࠩࡄࡐࡑ࠭昇")]
	if l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ昈") in list(l1ll1ll1l1l11_l1_.keys()): l1llllll11l1_l1_ = l1ll1ll1l1l11_l1_[l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ昉")]
	if l11lll_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭昊") in list(l1ll1ll1l1l11_l1_.keys()): l1ll1llll1l11_l1_ = l1ll1ll1l1l11_l1_[l11lll_l1_ (u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ昋")]
	if l11lll_l1_ (u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ昌") in list(l1ll1ll1l1l11_l1_.keys()): l1lll11lll1ll_l1_ = l1ll1ll1l1l11_l1_[l11lll_l1_ (u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬ昍")]
	if l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ明") in list(l1ll1ll1l1l11_l1_.keys()): l1ll1lll1ll1l_l1_ = l1ll1ll1l1l11_l1_[l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ昏")]
	l11ll111l111_l1_ = all-l1llllll11l1_l1_-l1ll1llll1l11_l1_-l1lll11lll1ll_l1_-l1ll1lll1ll1l_l1_
	dummy,l1lll11l1llll_l1_ = l1lll111ll1l1_l1_[0]
	dummy,l1ll1lll11l1l_l1_ = l1lll111ll1l1_l1_[1]
	l1ll1lllll11l_l1_ = l1lll11l1llll_l1_-l1ll1lll11l1l_l1_
	l1lll1111l11l_l1_ += l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ昐")+str(l1ll1lll11l1l_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ昑")+l11lll_l1_ (u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪ昒")
	l1lll1111l11l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ易")+str(l1ll1lllll11l_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ昔")+l11lll_l1_ (u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭昕")
	l1lll1111l11l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ昖")+str(l1lll11l1llll_l1_)+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭昗")+l11lll_l1_ (u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾ࠥ࠭昘")
	l1lll1111l11l_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ昙")+str(len(l1lll111ll1l1_l1_[2:]))+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ昚")+l11lll_l1_ (u"ࠨ฻าำࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎์อࠠฤฮ๊ึฮࠦ࠺ࠡ࡞ࡱࡠࡳ࠭昛")
	for l1ll111l1l11_l1_,l1l1111ll1ll_l1_ in l1lll111ll1l1_l1_[2:]:
		l1ll111l1l11_l1_ = escapeUNICODE(l1ll111l1l11_l1_)
		l1ll111l1l11_l1_ = l1ll111l1l11_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ昜")).strip(l11lll_l1_ (u"ࠪࠤ࠳࠭昝"))
		l1lll1111l11l_l1_ += l1ll111l1l11_l1_+l11lll_l1_ (u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ昞")+str(l1l1111ll1ll_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠪ星")
	#l1lll1111l11l_l1_ += l11lll_l1_ (u"࠭࡜࡯࠰ࠪ映")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ昡")+str(l11ll111l111_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ昢")+l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧ昣")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ昤")+str(l1llllll11l1_l1_)+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭春")+l11lll_l1_ (u"ࠬ฽ไษษอࠤุ๐ัโำࠣฬฬ๐ห้่ࠣ࠾ࠥ࠭昦")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ昧")+str(l1ll1lll1ll1l_l1_)+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ昨")+l11lll_l1_ (u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫ昩")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ昪")+str(l1ll1llll1l11_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ昫")+l11lll_l1_ (u"ࠫฯัศ๋ฬࠣฮ฼ฮ๊ใࠢๆ์ิ๐ฺࠠ็สำࠥࡀࠠࠨ昬")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ昭")+str(l1lll11lll1ll_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ昮")+l11lll_l1_ (u"ࠧหอห๎ฯࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠾ࠥ࠭是")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭昰")+str(len(l1lll1l1llll1_l1_))+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ昱")+l11lll_l1_ (u"ࠪำํ๊ࠠี฼็ฮࠥ็๊ะ์๋๋ฬะࠠ࠻ࠢࠪ昲")
	#l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ昳")+l11lll_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤูเไ่ษ๋ࠣีอࠠศๆหี๋อๅอࠢไ๎ࠥอไฺษ็้ࠥ๐่ๆࠢฦุ้ࠦࠨศๆหหึำษࠪࠩ昴")+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ昵")
	l1ll1ll1l111l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ昶")+l1lll1l111l1l_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ昷"),l11lll_l1_ (u"ࠩ฼ำิࠦวๅลฯ๋ืฯࠠศๆอ๎ࠥอำหะา้ฯࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ昸"),l1lll1111l11l_l1_,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭昹"))
	#l11ll1l1l1_l1_(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ昺"),l11lll_l1_ (u"ࠬาๅ๋฻๋ࠣีํࠠศๆฦี็อๅࠡฬัูࠥษำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥࠦแใูࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ昻"),l1ll1ll1l111l_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ昼"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ昽"),l11lll_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩ显"),l1ll1ll1l111l_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ昿"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ晀"),l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ晁"),l1111lllll1l_l1_,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ時"))
	l11ll1l1l1_l1_(l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ晃"),l11lll_l1_ (u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩ晄"),l1111lllll11_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ晅"))
	return
def l1lll1111ll1l_l1_():
	message = l11lll_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨ晆")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ晇"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ晈"),message,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ晉"))
	return
def l1l1l11111l1_l1_():
	message = l11lll_l1_ (u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫ晊")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ晋")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ晌")+l1ll11l_l1_[l11lll_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ晍")][0]+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ晎")+l1ll11l_l1_[l11lll_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ晏")][1]+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ晐")
	message += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ晑")+l1ll11l_l1_[l11lll_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ晒")][1]+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ晓")
	message += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬ晔")+l11lll_l1_ (u"ࠪࡠࡳ࠭晕")+l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ晖")+l1ll11l_l1_[l11lll_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭晗")][2]+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ晘")
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ晙"),l11lll_l1_ (u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ晚"),message,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ晛"))
	return
def l1lll1l1lll1l_l1_(l1lll1l1lllll_l1_):
	xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩ晜")+l1lll1l1lllll_l1_+l11lll_l1_ (u"ࠫ࠮࠭晝"), True)
	return
def l1lll1l1l1ll1_l1_():
	l1ll11l11_l1_(l11lll_l1_ (u"ࠬࡹࡴࡰࡲࠪ晞"))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧ晟"))
	return
def l1lll111ll11l_l1_():
	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭晠"), True)
	return
def l1ll1llllllll_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll11l111_l1_ = True
	else: l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ晡"),l11lll_l1_ (u"ࠩࠪ晢"),l11lll_l1_ (u"ࠪࠫ晣"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ晤"),l11lll_l1_ (u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥอไร่ࠣรࠬ晥"))
	if l1ll11l111_l1_==1:
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩ晦"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ晧"),l11lll_l1_ (u"ࠨࠩ晨"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ晩"),l11lll_l1_ (u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪ晪"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ晫"))
	return
def l1lll1111111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭晬"),l11lll_l1_ (u"࠭ࠧ晭"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ普"),l11lll_l1_ (u"ࠨๆ่ืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้่วว็ฬࠤฬ๊ส๋ࠢอี๏ีࠠๆีะ๋ฬ่ࠦๅษࠣฮิิไࠡว็๎์อ้ࠠๆๆ๊ࠥฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥษ่ࠡษึฮำีๅࠡࠤส่่๐ศ้ำาࠦࠥ๎วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢสฺ฿฽ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨ景"))
	return
def l1lll11111lll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ晰"),l11lll_l1_ (u"ࠪࠫ晱"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ晲"),l11lll_l1_ (u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨ晳"))
	return
#l1lll1ll1111l_l1_ 	  required	and l1lll1ll1111l_l1_     installed	and		not l1l1111l11l1_l1_		ignore
#l1lll1ll1111l_l1_ not required	and	l1lll1ll1111l_l1_ not installed 	and 	    l1l1111l11l1_l1_		ignore
#l1lll1ll1111l_l1_ not required	and	l1lll1ll1111l_l1_ not installed 	and 	not l1l1111l11l1_l1_		ignore
#l1lll1ll1111l_l1_ not required	and	l1lll1ll1111l_l1_     installed 	and 	not l1l1111l11l1_l1_		ignore
#l1lll1ll1111l_l1_     required	and	l1lll1ll1111l_l1_ not installed 	and 	    l1l1111l11l1_l1_		l11111l11l_l1_ l1ll1llll1l11_l1_	l1lll1l111ll1_l1_
#l1lll1ll1111l_l1_     required	and	l1lll1ll1111l_l1_ not installed 	and 	not l1l1111l11l1_l1_		l11111l11l_l1_ l1ll1llll1l11_l1_	l1lll1l111ll1_l1_
#l1lll1ll1111l_l1_     required 	and l1lll1ll1111l_l1_     installed 	and 	    l1l1111l11l1_l1_		l11111l11l_l1_ l1lll1ll1lll1_l1_	l1lll1l111ll1_l1_
#l1lll1ll1111l_l1_ not required	and	l1lll1ll1111l_l1_     installed 	and 	    l1l1111l11l1_l1_		l11111l11l_l1_ l1lll1ll1lll1_l1_	l1lll1l111ll1_l1_
#l1ll11lll1ll_l1_: required and not installed: l11111l11l_l1_ l1ll1llll1l11_l1_
#l1ll11lll11l_l1_: installed and l11111l11l_l1_ update: l11111l11l_l1_ l1lll1ll1lll1_l1_
def l1l11lll1ll1_l1_(l1ll_l1_=True):
	l1lll11l1ll1l_l1_ = [l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨ晴"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨ晵"),l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫ晶"),l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫ晷"),l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ晸"),l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨ晹")]
	l1lll11ll1ll1_l1_ = l1lll11l1ll1l_l1_+[l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ智"),l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ晻"),l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭晼"),l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡰࡩࡧࡱࡳࡲ࡫࡮ࡢ࡮ࡈࡑࡆࡊࠧ晽"),l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭晾"),l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ晿")]		# ,l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰࡬ࡲࡸࡺࡡ࡭࡮ࡈࡑࡆࡊࠧ暀")
	l1l111ll1111_l1_ = l1ll1lll1l11_l1_([l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ暁")])
	l1lll11lll1l1_l1_ = []
	for addon_id in [l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ暂")]:
		if addon_id not in list(l1l111ll1111_l1_.keys()): continue
		l1l1111l11l1_l1_,l1llll111111_l1_,l1lll1l11lll1_l1_,l1lll1l11ll1l_l1_,l1lll1l11l1l1_l1_,l1ll1ll1lllll_l1_,l1lll1l11l1ll_l1_ = l1l111ll1111_l1_[addon_id]
		if not l1llll111111_l1_ or (l1llll111111_l1_ and l1l1111l11l1_l1_): l1lll11lll1l1_l1_.append(addon_id)
	l1ll1ll11llll_l1_ = len(l1lll11lll1l1_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1l11ll111_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1lll1l1l11ll_l1_ = []
	for addon_id in l1lll11l1ll1l_l1_:
		cc.execute(l11lll_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥࠨ࠱ࠣࠢࡤࡲࡩࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ暃")+addon_id+l11lll_l1_ (u"ࠨࠤࠣ࠿ࠬ暄"))
		l11ll1ll111_l1_ = cc.fetchall()
		if l11ll1ll111_l1_: l1lll1l1l11ll_l1_.append(addon_id)
	l1lll111l11ll_l1_ = len(l1lll1l1l11ll_l1_)>0
	for addon_id in l1lll11ll1ll1_l1_:
		cc.execute(l11lll_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ暅")+addon_id+l11lll_l1_ (u"ࠪࠦࠥࡁࠧ暆"))
		l1lll1lllll11_l1_ = cc.fetchall()
		if l1lll1lllll11_l1_ and l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭暇") not in str(l1lll1lllll11_l1_): l1lll11lll1l1_l1_.append(addon_id)
	l1ll1llll1lll_l1_ = len(l1lll11lll1l1_l1_)>0
	l1lll11lll1l1_l1_ = list(set(l1lll11lll1l1_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭暈"),l11lll_l1_ (u"࠭࡮ࡦࡧࡧࡣ࡫࡯ࡸࡪࡰࡪࡣࡷ࡫ࡰࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱ࠾ࠥࠦࠧ暉")+str(l1ll1ll11llll_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ暊"),l11lll_l1_ (u"ࠨࡰࡨࡩࡩࡥࡤࡦ࡮ࡨࡸ࡮ࡴࡧࡠࡱ࡯ࡨࡤࡧࡤࡥࡱࡱࡷ࠿ࠦࠠࠨ暋")+str(l1lll111l11ll_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ暌"),l11lll_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡨ࡬ࡼ࡮ࡴࡧࡠࡱࡵ࡭࡬࡯࡮࠻ࠢࠣࠫ暍")+str(l1ll1llll1lll_l1_))
	l1l1111l11l1_l1_ = False
	if l1lll111l11ll_l1_ or l1ll1llll1lll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ暎"),l11lll_l1_ (u"ࠬ࠭暏"),l11lll_l1_ (u"࠭ࠧ暐"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ暑"),l11lll_l1_ (u"ࠨษ็ฬึ์วๆฮࠣ์ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤู๊้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦวๅฤ้ࠤฤࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ暒"))
		if l1ll11l111_l1_==1:
			l1lll1ll1l111_l1_ = True
			if l1ll1ll11llll_l1_:
				l1lll1ll1l111_l1_ = l1ll1llll111l_l1_(l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ暓"),False,False)
			l1ll1lll1l11l_l1_ = True
			if l1lll111l11ll_l1_:
				for addon_id in l1lll1l1l11ll_l1_: l1lll11l11l1l_l1_(addon_id)
				l1ll1lll1l11l_l1_ = True
			l1ll1lll1ll11_l1_ = True
			if l1ll1llll1lll_l1_:
				conn = sqlite3.connect(l1l1l11ll111_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1lll11lll1l1_l1_:
					if l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࠭暔") in addon_id: l1lll1lllll11_l1_ = addon_id
					else: l1lll1lllll11_l1_ = l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭暕")
					try: cc.execute(l11lll_l1_ (u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩ暖")+l1lll1lllll11_l1_+l11lll_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ暗")+addon_id+l11lll_l1_ (u"ࠧࠣࠢ࠾ࠫ暘"))
					except: l1ll1lll1ll11_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ暙"))
			time.sleep(1)
			if l1lll1ll1l111_l1_ or l1ll1lll1l11l_l1_ or l1ll1lll1ll11_l1_:
				l1l1111l11l1_l1_ = False
				DIALOG_OK(l11lll_l1_ (u"ࠩࠪ暚"),l11lll_l1_ (u"ࠪࠫ暛"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ暜"),l11lll_l1_ (u"ࠬา๊ะࠢ࠱࠲ࠥะๅࠡส้ะฬำࠠหใ฼๎้่ࠦฦื็หาࠦวๅ็ึฮํีู๊ࠡส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥฬๆ์฼ࠤส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩ暝"))
			else:
				l1l1111l11l1_l1_ = True
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧ暞"),l11lll_l1_ (u"ࠧࠨ暟"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ暠"),l11lll_l1_ (u"ࠩ็่ศูแࠡ࠰࠱ࠤๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎ลึๆสัࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ暡"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ暢"),l11lll_l1_ (u"ࠫࠬ暣"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ暤"),l11lll_l1_ (u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥษ่ࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭暥"))
	return l1l1111l11l1_l1_
def l1ll1llll1l1l_l1_():
	l1ll1ll1l1l1l_l1_,l1lll1ll11l11_l1_,l1lll1l111lll_l1_ = False,l11lll_l1_ (u"ࠧࠨ暦"),l11lll_l1_ (u"ࠨࠩ暧")
	l1lll1ll111l1_l1_,l1lll11l11111_l1_,l1lll11l1lll1_l1_ = False,l11lll_l1_ (u"ࠩࠪ暨"),l11lll_l1_ (u"ࠪࠫ暩")
	l1l111ll1111_l1_ = l1ll1lll1l11_l1_([l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ暪"),l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ暫"),l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ暬")])
	for addon_id in [l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ暭"),l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ暮"),l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ暯")]:
		if addon_id not in list(l1l111ll1111_l1_.keys()): continue
		l1l1111l11l1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l111lll_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1111_l1_ = l1l111ll1111_l1_[addon_id]
		if addon_id==l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ暰"):
			l1lll1ll111l1_l1_ = l1l1111l11l1_l1_
			l1lll11l11111_l1_ = l11lll_l1_ (u"ࠫ࠭࠭暱")+l1llll111111_l1_+l11lll_l1_ (u"ࠬࠦࠧ暲")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"࠭ࠩࠨ暳")
			l1lll11l1lll1_l1_ = l1ll1l111lll_l1_
		elif addon_id==l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ暴"):
			l1ll1ll1l1l1l_l1_ = l1ll1ll1l1l1l_l1_ or l1l1111l11l1_l1_
			l1lll1ll11l11_l1_ += l11lll_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠨࠨ暵")+l1llll111111_l1_+l11lll_l1_ (u"ࠩࠣࠫ暶")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"ࠪ࠭ࠬ暷")
			l1lll1l111lll_l1_ += l11lll_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ暸")+l1ll1l111lll_l1_
		elif addon_id==l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ暹"):
			l1lll1111llll_l1_ = l1l1111l11l1_l1_
			l1lll11111l1l_l1_ = l11lll_l1_ (u"࠭ࠨࠨ暺")+l1llll111111_l1_+l11lll_l1_ (u"ࠧࠡࠩ暻")+TRANSLATE(l11l11lllll_l1_)+l11lll_l1_ (u"ࠨࠫࠪ暼")
			l1lll1l111l11_l1_ = l1ll1l111lll_l1_
	l1lll1ll11l11_l1_ = l1lll1ll11l11_l1_.strip(l11lll_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ暽"))
	l1lll1l111lll_l1_ = l1lll1l111lll_l1_.strip(l11lll_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠩ暾"))
	l1l11lll11_l1_  = l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ暿")+l1lll11l1lll1_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ曀")
	l1l11lll11_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ曁")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ曂")+l1lll11l11111_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ曃")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ曄")+l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ曅")+l1lll1l111lll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭曆")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ曇")+l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ曈")+l1lll1ll11l11_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ曉")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭曊")+l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ曋")+l1lll1l111l11_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ曌")
	l1l11lll11_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ曍")+l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ曎")+l1lll11111l1l_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ曏")
	l1l1111l11l1_l1_ = (l1lll1ll111l1_l1_ or l1ll1ll1l1l1l_l1_)
	if l1l1111l11l1_l1_:
		header = l11lll_l1_ (u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩ曐")
		l1l1l1lll1_l1_ = l11lll_l1_ (u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠩ曑")
	else:
		header = l11lll_l1_ (u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪ曒")
		l1l1l1lll1_l1_ = l11lll_l1_ (u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬ曓")
	l1l1l1ll1l_l1_ = l11lll_l1_ (u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ曔")
	l1ll11llll_l1_ = l1l11lll11_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ曕")+l1l1l1lll1_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ曖")+l1l1l1ll1l_l1_
	l11ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭曗"),header,l1ll11llll_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ曘"))
	return
def l1ll111llll1_l1_(l1ll_l1_=True,l1ll1lllll1l1_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ曙"),l11lll_l1_ (u"ࠪࡉࡒࡇࡄࡠࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ曚"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ曛"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭曜"))
	if l1ll_l1_:
		l1ll1llll1l1l_l1_()
		l1lll1l1111ll_l1_()
	if l1ll1lllll1l1_l1_:
		l1l11lll1ll1_l1_(False)
		l1l11lllllll_l1_ = []
		l1lll1l1l1111_l1_ = [l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ曝"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ曞"),l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ曟"),l11lll_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭曠")]
		for l1lll11111111_l1_ in l1lll1l1l1111_l1_:
			succeeded,l1lll1l11l111_l1_,l1llll111111_l1_ = l1ll1llll111l_l1_(l1lll11111111_l1_,True,False)
			l1l11lllllll_l1_.append(succeeded)
		l1ll1llllllll_l1_(l1ll_l1_)
		l11l1llll11l_l1_ = l11lll_l1_ (u"ࠪࠫ曡") if all(l1l11lllllll_l1_) else l11lll_l1_ (u"ࠫ࠶࠭曢")
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡴࡴࡹ࠮࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩࠬ曣"),l11l1llll11l_l1_)
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩࡵࡵࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ曤"),str(now))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ曥"))
	return
def l1lll11llll1l_l1_(l1lll1l1ll111_l1_=l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ曦"),l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ曧"))
	import json
	data = json.loads(l11111lll1l_l1_)
	l1ll1ll1llll1_l1_ = data[l11lll_l1_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ曨")][l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ曩")]
	if kodi_version<19: l1ll1ll1llll1_l1_ = l1ll1ll1llll1_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ曪"))
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ曫"),l11lll_l1_ (u"ࠧࠨ曬"),l11lll_l1_ (u"ࠨࠩ曭"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ曮"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฯเ๊๋ำࠣะ้ีࠠࠨ曯")+l1ll1ll1llll1_l1_+l11lll_l1_ (u"ࠫࠥอไั์ุ้ࠣะฮะ็ࠣห้ศๆࠡใํࠤ่๎ฯ๋ࠢศ่๎ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำࠥ࠭曰")+l1lll1l1ll111_l1_+l11lll_l1_ (u"ࠬࠦฟࠢࠩ曱"))
		if l1ll11l111_l1_!=1: return False
	succeeded,l1lll1l11l111_l1_,l1ll1lll1111l_l1_ = l1ll1llll111l_l1_(l1lll1l1ll111_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ曲"),l11lll_l1_ (u"ࠧࠨ曳"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ更"),l11lll_l1_ (u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫ曵"))
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧ曶")+l1lll1l1ll111_l1_+l11lll_l1_ (u"ࠫࠧࢃࡽࠨ曷"))
		if l11lll_l1_ (u"ࠬࡕࡋࠨ書") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭曹"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ曺"),l11lll_l1_ (u"ࠨࠩ曻"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ曼"),l11lll_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥ๎สโ฻ํ่ࠥอไอๆาࠤฬ๊ๅุๆ๋ฬࠬ曽"))
	return succeeded
def l111ll1l11l_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11lll_l1_ (u"ࠫࠬ曾"): l1ll_l1_ = True
	#l1ll1l1l1lll_l1_ = xbmc.getCondVisibility(l11lll_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠨ替")+addon_id+l11lll_l1_ (u"࠭ࠩࠨ最"))
	l111lllll11_l1_ = l1l1ll1ll11l_l1_([addon_id])
	l111l11ll1l_l1_,l1ll1l1l1lll_l1_ = l111lllll11_l1_[addon_id]
	if l1ll1l1l1lll_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ朁"),l11lll_l1_ (u"ࠨࠩ朂"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ會"),l11lll_l1_ (u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬ朄")+addon_id+l11lll_l1_ (u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧ朅"))
	else:
		succeeded = False
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ朆"),l11lll_l1_ (u"࠭ࠧ朇"),l11lll_l1_ (u"ࠧࠨ月"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ有"),l11lll_l1_ (u"ࠩࠪ朊")+addon_id+l11lll_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨ朋"))
		if l1ll11l111_l1_==1:
			xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫ朌")+addon_id+l11lll_l1_ (u"ࠬ࠯ࠧ服"))
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭朎"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11lll_l1_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ朏")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ朐")+addon_id+l11lll_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ朑"))
			if l11lll_l1_ (u"ࠪࡓࡐ࠭朒") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ朓"),l11lll_l1_ (u"ࠬ࠭朔"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ朕"),l11lll_l1_ (u"ࠧห็ࠣๅา฻ࠠฤ๊ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศส๋๋ࠢ๏ࠦวๅฤ้ࠤัอ็ำห่้ࠣอำหะาห๊࠭朖"))
			elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ朗"),l11lll_l1_ (u"ࠩࠪ朘"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭朙"),l11lll_l1_ (u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭朚"))
	return succeeded
def l1lll111111l1_l1_(addon_id,l1l1111l1111_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭望"),l11lll_l1_ (u"࠭ࠧ朜"),l11lll_l1_ (u"ࠧࠨ朝"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ朞"),l11lll_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣห้ศๆࠡฮ็ฬࠥอไๆๆไࠤฬ๊ๅื฼๋฻๊ࠥไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡๆๆ๎ࠥ๐สๆࠢอฯอ๐ส่ࠢ฼่๎ࠦใ้ัํࠤ࠳ࠦวๅ็็ๅ่ࠥฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ย็ࠢยࠥࠬ期"))
		if l1ll11l111_l1_!=1: return False
	l1ll1ll1ll111_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111l1111_l1_,{},l1ll_l1_)
	if l1ll1ll1ll111_l1_:
		l1l1111lll11_l1_ = os.path.join(l1ll1l111l_l1_,addon_id)
		l1ll11ll1l_l1_(l1l1111lll11_l1_,True,False)
		import zipfile,io
		l1lll111lllll_l1_ = io.BytesIO(l1ll1ll1ll111_l1_)
		zf = zipfile.ZipFile(l1lll111lllll_l1_)
		zf.extractall(l1ll1l111l_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ朠"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ朡")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ朢"))
		if l11lll_l1_ (u"࠭ࡏࡌࠩ朣") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ朤"),l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓࡠࡆࡈࡘࡆࡏࡌࡔࠩ朥"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ朦"),l11lll_l1_ (u"ࠪࠫ朧"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ木"),l11lll_l1_ (u"ࠬะๅࠡส้ะฬำࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ朩"))
		else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ未"),l11lll_l1_ (u"ࠧࠨ末"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ本"),l11lll_l1_ (u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ札"))
	return succeeded
def l1ll1llll111l_l1_(addon_id,l1ll_l1_,l1lll1l1l11l1_l1_):
	l1ll11l111_l1_,succeeded,l1lll1l11l111_l1_,l1llll111111_l1_ = True,False,l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ朮"),l11lll_l1_ (u"ࠫࠬ术")
	l1l111ll1111_l1_ = l1ll1lll1l11_l1_([addon_id])
	if addon_id in list(l1l111ll1111_l1_.keys()):
		l1l1111l11l1_l1_,l1llll111111_l1_,l111111ll11_l1_,l1ll1l111lll_l1_,l111lll111l_l1_,l11l11lllll_l1_,l1l1111l1111_l1_ = l1l111ll1111_l1_[addon_id]
		if l11l11lllll_l1_==l11lll_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ朰"):
			succeeded,l1lll1l11l111_l1_ = True,l11lll_l1_ (u"࠭࡮ࡰࡶ࡫࡭ࡳ࡭ࠧ朱")
			if l1lll1l1l11l1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ朲"),l11lll_l1_ (u"ࠨࠩ朳"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ朴"),l11lll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠไ๊า๎ࠥ๐ำหะา้ࠥษฮาࠢศูิอัࠡ็อ์ๆืࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠๅ้ำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ朵")+addon_id)
		else:
			if l1ll_l1_:
				if l11l11lllll_l1_==l11lll_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭朶"): message = l11lll_l1_ (u"๋ࠬส้ไไอࠬ朷")
				elif l11l11lllll_l1_==l11lll_l1_ (u"࠭࡯࡭ࡦࠪ朸"): message = l11lll_l1_ (u"ࠧใัํ้ฮ࠭朹")
				elif l11l11lllll_l1_==l11lll_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ机"): message = l11lll_l1_ (u"ࠩ฽๎ึࠦๅฬสออࠬ朻")
				l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ朼"),l11lll_l1_ (u"ࠫࠬ朽"),l11lll_l1_ (u"ࠬ࠭朾"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ朿"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭杀")+message+l11lll_l1_ (u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪ杁")+addon_id)
			if not l1ll11l111_l1_: l1lll1l11l111_l1_ = l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫ杂")
			else:
				if l11l11lllll_l1_==l11lll_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ权"):
					results = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ杄")+addon_id+l11lll_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ杅"))
					if l11lll_l1_ (u"࠭ࡏࡌࠩ杆") in results:
						succeeded,l1lll1l11l111_l1_ = True,l11lll_l1_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨ杇")
						if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ杈"),l11lll_l1_ (u"ࠩࠪ杉"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭杊"),l11lll_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩ杋")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭杌"),l11lll_l1_ (u"࠭ࠧ杍"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ李"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫ杏")+addon_id)
				elif l11l11lllll_l1_ in [l11lll_l1_ (u"ࠩࡲࡰࡩ࠭材"),l11lll_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ村")]:
					succeeded = l1lll111111l1_l1_(addon_id,l1l1111l1111_l1_,False)
					if succeeded:
						if l11l11lllll_l1_==l11lll_l1_ (u"ࠫࡴࡲࡤࠨ杒"): l1lll1l11l111_l1_ = l11lll_l1_ (u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭杓")
						elif l11l11lllll_l1_==l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ杔"): l1lll1l11l111_l1_ = l11lll_l1_ (u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪ杕")
						l1llll111111_l1_ = l1ll1l111lll_l1_
						if l1ll_l1_:
							if l1lll1l11l111_l1_==l11lll_l1_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩ杖"): DIALOG_OK(l11lll_l1_ (u"ࠩࠪ杗"),l11lll_l1_ (u"ࠪࠫ杘"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ杙"),l11lll_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡไา๎๊ฯࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ杚")+addon_id)
							elif l1lll1l11l111_l1_==l11lll_l1_ (u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ杛"): DIALOG_OK(l11lll_l1_ (u"ࠧࠨ杜"),l11lll_l1_ (u"ࠨࠩ杝"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ杞"),l11lll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫ束")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ杠"),l11lll_l1_ (u"ࠬ࠭条"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ杢"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪ杣")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ杤"),l11lll_l1_ (u"ࠩࠪ来"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭杦"),l11lll_l1_ (u"้๊ࠫริใࠣ࠲࠳ࠦ็ั้ࠣห้หึศใฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨ杧")+addon_id)
	return succeeded,l1lll1l11l111_l1_,l1llll111111_l1_
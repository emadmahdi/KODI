# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭槻")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭槼")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ槽"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ槾"),l11lll_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭槿")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1111l_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11111_l1_(url,text)
	elif mode==644: results = l1l11l_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ樀"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭樁"),l11lll_l1_ (u"࠭ࠧ樂"),l11lll_l1_ (u"ࠧࠨ樃"),l11lll_l1_ (u"ࠨࠩ樄"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ樅"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樆"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ樇"),l11lll_l1_ (u"ࠬ࠭樈"),649,l11lll_l1_ (u"࠭ࠧ樉"),l11lll_l1_ (u"ࠧࠨ樊"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ樋"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ樌"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ樍"),l11lll_l1_ (u"ࠫࠬ樎"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樏"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ樐")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ樑"),l11ll1_l1_,641,l11lll_l1_ (u"ࠨࠩ樒"),l11lll_l1_ (u"ࠩࠪ樓"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ樔"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ樕"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ樖")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫ樗"),l11ll1_l1_,641,l11lll_l1_ (u"ࠧࠨ樘"),l11lll_l1_ (u"ࠨࠩ標"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ樚"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ樛"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ樜"),l11lll_l1_ (u"ࠬ࠭樝"),9999)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樞"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ樟")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧ樠"),l11ll1_l1_,641,l11lll_l1_ (u"ࠩࠪ模"),l11lll_l1_ (u"ࠪࠫ樢"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ樣"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樤"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ樥")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫ樦"),l11ll1_l1_,641,l11lll_l1_ (u"ࠨࠩ樧"),l11lll_l1_ (u"ࠩࠪ樨"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ権"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ横"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭樫"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樬"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ樭")+l111ll_l1_+title,link,644)
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭樮"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ樯"),l11lll_l1_ (u"ࠪࠫ樰"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ樱"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ樲"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"࠭ࠧ樳"))
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ樴"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樵"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ樶")+l111ll_l1_+title,link,644)
	return
def l1l11l_l1_(url):
	l1111ll1l_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ樷"),url,l11lll_l1_ (u"ࠫࠬ樸"),l11lll_l1_ (u"ࠬ࠭樹"),l11lll_l1_ (u"࠭ࠧ樺"),l11lll_l1_ (u"ࠧࠨ樻"),l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭樼"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭樽"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ樾"),l11lll_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ樿"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ橀"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"࠭ࠧ橁"),block)]
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ橂"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭橃"),l11lll_l1_ (u"ࠩࠪ橄"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			l1111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ橅"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠫ࠿ࠦࠧ橆")
			for link,title in l1111ll1l_l1_:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ橇"),l111ll_l1_+title,link,641)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ橈"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ橉"),block,re.DOTALL)
		if len(l1l1lll_l1_)<30:
			if l1111ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭橊"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ橋"),l11lll_l1_ (u"ࠪࠫ橌"),9999)
			for link,title in l1l1lll_l1_:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ橍"),l111ll_l1_+title,link,641)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠬ࠭橎")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ橏"),l11lll_l1_ (u"ࠧࠨ橐"),request,url)
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭橑"):
		url,search = url.split(l11lll_l1_ (u"ࠩࡂࠫ橒"),1)
		data = l11lll_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ橓")+search
		headers = {l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ橔"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ橕")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ橖"),url,data,headers,l11lll_l1_ (u"ࠧࠨ橗"),l11lll_l1_ (u"ࠨࠩ橘"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭橙"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ橚"),url,l11lll_l1_ (u"ࠫࠬ橛"),l11lll_l1_ (u"ࠬ࠭橜"),l11lll_l1_ (u"࠭ࠧ橝"),l11lll_l1_ (u"ࠧࠨ橞"),l11lll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ機"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠩࠪ橠"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ橡"))
	if request==l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ橢"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ橣"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ橤"),link,title))
	elif request==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ橥"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ橦"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ橧"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ橨"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ橩"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ橪"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ橫"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ橬"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ橭"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠩࠪ橮"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ橯"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭橰"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ橱"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ橲"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭橳"),l11lll_l1_ (u"ࠨๅ็๎อ࠭橴"),l11lll_l1_ (u"ࠩส฽้อๆࠨ橵"),l11lll_l1_ (u"๋ࠪิอแࠨ橶"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ橷"),l11lll_l1_ (u"ࠬ฿ัืࠩ橸"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭橹"),l11lll_l1_ (u"ࠧศๆห์๊࠭橺"),l11lll_l1_ (u"ࠨ็ึีา๐ษࠨ橻")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ橼"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ橽") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭橾")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ橿"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ檀") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ檁")+l1llll_l1_.strip(l11lll_l1_ (u"ࠨ࠱ࠪ檂"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ檃"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭檄"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ檅"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ檆"):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ檇"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭檈") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檉"),l111ll_l1_+title,link,643,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ檊") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ檋"),l111ll_l1_+title,link,641,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ檌"),l111ll_l1_+title,link,643,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ檍"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ檎")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ檏"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭檐"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠩࠦࠫ檑"): continue
				if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ檒") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭檓")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ檔"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檕"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭檖")+title,link,641)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ檗"),l11lll_l1_ (u"ࠩࠪ檘"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ檙"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ檚"),url,l11lll_l1_ (u"ࠬ࠭檛"),l11lll_l1_ (u"࠭ࠧ檜"),l11lll_l1_ (u"ࠧࠨ檝"),l11lll_l1_ (u"ࠨࠩ檞"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ檟"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭檠"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭檡"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠬ࠭檢")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ檣"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠤࠩ檤"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ檥"),l111ll_l1_+title,url,643,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ檦"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ檧")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ檨"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ檩"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ檪"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ檫") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ檬")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ檭"))
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࡀࡪࡳ࠾ࠨ檮"),l11lll_l1_ (u"ࠫࠥ࠭檯"))
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ檰"),l111ll_l1_+title,link,642,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ檱"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ檲") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ檳")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ檴"))
		#		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ檵"),l111ll_l1_+title,link,642,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l11l1ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ檶"),l11lll_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠲ࡵ࡮ࡰࠨ檷"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ檸"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ檹"),l11lll_l1_ (u"ࠨࠩ檺"),l11lll_l1_ (u"ࠩࠪ檻"),l11lll_l1_ (u"ࠪࠫ檼"),l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭檽"))
	html = response.content
	# l1l111lll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ檾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ檿"),block,re.DOTALL)
		if links:
			link = links[0]
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ櫀"))
				l1111_l1_.append(link)
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ櫁"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11111ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ櫂"),block,re.DOTALL)
		block = block.replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ櫃"),l11lll_l1_ (u"ࠫࠧ࠭櫄")).replace(l11lll_l1_ (u"ࠬࡢ࠯ࠨ櫅"),l11lll_l1_ (u"࠭࠯ࠨ櫆"))
		links = re.findall(l11lll_l1_ (u"ࠧࠣ࠾࡬ࡪࡷࡧ࡭ࡦ࠰ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ櫇"),block,re.DOTALL)
		if len(l11111ll1_l1_)==len(links):
			for id,title in l11111ll1_l1_:
				link = links[int(id)]
				if link not in l1111_l1_:
					l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ櫈")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ櫉"))
					l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡉࡵࡷ࡯࡮ࡲࡥࡩ࡙ࡥࡳࡸࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ櫊"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ櫋"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l11l1ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭櫌")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ櫍"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l11l1ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ櫎"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ櫏"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ櫐"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ櫑"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭櫒"),l11lll_l1_ (u"ࠬ࠱ࠧ櫓"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ櫔")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ櫕"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬ櫖")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ櫗"))
	return
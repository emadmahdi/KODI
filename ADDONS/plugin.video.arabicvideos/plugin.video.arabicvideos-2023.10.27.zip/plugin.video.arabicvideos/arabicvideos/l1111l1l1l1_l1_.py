# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ楍")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ楎")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭楏"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1111l_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1ll1ll1111l1_l1_(url)
	elif mode==314: results = l1lllll1l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楐"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ楑"),l11lll_l1_ (u"ࠬ࠭楒"),319,l11lll_l1_ (u"࠭ࠧ楓"),l11lll_l1_ (u"ࠧࠨ楔"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ楕"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ楖"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠨ楗"),l11lll_l1_ (u"ࠫࠬ楘"),114,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ楙"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ楚"),l11lll_l1_ (u"ࠧࠨ楛"),l11lll_l1_ (u"ࠨࠩ楜"),l11lll_l1_ (u"ࠩࠪ楝"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ楞"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ楟"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ楠"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭楡"),l11lll_l1_ (u"ࠧࠨ楢"),9999)
	items = re.findall(l11lll_l1_ (u"ࠨ࠾࡫࠹ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠵࠿ࠩ楣"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11lll_l1_ (u"ࠩࠣࠫ楤"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ楥"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭楦")+l111ll_l1_+title,l11ll1_l1_,314,l11lll_l1_ (u"ࠬ࠭楧"),l11lll_l1_ (u"࠭ࠧ楨"),str(seq+1))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ楩"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ楪")+l111ll_l1_+l11lll_l1_ (u"่ࠩๆฬ฽ูࠡึ๊ีࠬ楫"),l11ll1_l1_,314,l11lll_l1_ (u"ࠪࠫ楬"),l11lll_l1_ (u"ࠫࠬ業"),l11lll_l1_ (u"ࠬ࠶ࠧ楮"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ楯"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ楰"),l11lll_l1_ (u"ࠨࠩ楱"),9999)
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡇࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂ࠿ࠩ楲"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ楳")+link
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭楴"))
		#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫ極")
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭楶"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ楷")+l111ll_l1_+title,link,311)
	return html
def l1lllll1l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ楸"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ楹"),l11lll_l1_ (u"ࠪࠫ楺"),l11lll_l1_ (u"ࠫࠬ楻"),l11lll_l1_ (u"ࠬ࠭楼"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭楽"))
	html = response.content
	if seq==l11lll_l1_ (u"ࠧ࠱ࠩ楾"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭楿"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ榀"),block,re.DOTALL)
		for link,name,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ榁")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭概"))
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ榃"))
			title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ榄")+name+l11lll_l1_ (u"ࠧࠪࠩ榅")
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ榆"),l111ll_l1_+title,link,312)
	elif seq in [l11lll_l1_ (u"ࠩ࠴ࠫ榇"),l11lll_l1_ (u"ࠪ࠶ࠬ榈"),l11lll_l1_ (u"ࠫ࠸࠭榉")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ榊"),html,re.DOTALL)
		l1ll1ll11111l_l1_ = int(seq)-1
		block = l1l1ll1_l1_[l1ll1ll11111l_l1_]
		if seq==l11lll_l1_ (u"࠭࠱ࠨ榋"): items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ榌"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ榍"),block,re.DOTALL)
		for link,l1llll_l1_,title,name in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ榎")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ榏")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭榐"))
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ榑"))
			title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ榒")+name+l11lll_l1_ (u"ࠧࠪࠩ榓")
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ榔"),l111ll_l1_+title,link,311,l1llll_l1_)
	elif seq in [l11lll_l1_ (u"ࠩ࠷ࠫ榕"),l11lll_l1_ (u"ࠪ࠹ࠬ榖"),l11lll_l1_ (u"ࠫ࠻࠭榗")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ榘"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1ll1_l1_[seq]
		items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ榙"),block,re.DOTALL)
		for l1llll_l1_,link,l1l11l1lll1_l1_,title,l1ll111l111_l1_ in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ榚")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ榛")+link
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ榜"))
			l1l11l1lll1_l1_ = l1l11l1lll1_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ榝"))
			l1ll111l111_l1_ = l1ll111l111_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭榞"))
			if l1l11l1lll1_l1_: name = l1l11l1lll1_l1_
			else: name = l1ll111l111_l1_
			title = title+l11lll_l1_ (u"ࠬࠦࠨࠨ榟")+name+l11lll_l1_ (u"࠭ࠩࠨ榠")
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭榡"),l111ll_l1_+title,link,312,l1llll_l1_)
	return
def l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ榢"),url,l11lll_l1_ (u"ࠩࠪ榣"),l11lll_l1_ (u"ࠪࠫ榤"),l11lll_l1_ (u"ࠫࠬ榥"),l11lll_l1_ (u"ࠬ࠭榦"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭榧"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ榨"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	if l11lll_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ榩") in block:
		items = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ榪"),block,re.DOTALL)
		if items:
			for l1llll_l1_,link,title,count in items:
				l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ榫")+l1llll_l1_
				link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭榬")+link
				count = count.replace(l11lll_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ榭"),l11lll_l1_ (u"࠭࠺ࠨ榮"))
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ榯"))
				title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ榰")+count+l11lll_l1_ (u"ࠩࠬࠫ榱")
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ榲"),l111ll_l1_+title,link,311,l1llll_l1_)
	else:
		items = re.findall(l11lll_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ榳"),block,re.DOTALL)
		for link,title,l1ll1ll1111ll_l1_,l1l1l1111_l1_ in items:
			if title==l11lll_l1_ (u"ࠬ࠭榴") or l1ll1ll1111ll_l1_==l11lll_l1_ (u"࠭ࠧ榵"): continue
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ榶")+link
			title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ榷")+l1l1l1111_l1_+l11lll_l1_ (u"ࠩࠬࠫ榸")
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ榹"),l111ll_l1_+title,link,312)
	if not items: l1llllll_l1_(html)
	return
def l1llllll_l1_(html):
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ榺"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ榻"),block,re.DOTALL)
	for link,title,name,count,l1l1l1111_l1_ in items:
		link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ榼")+link
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ榽"))
		name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ榾"))
		title = title+l11lll_l1_ (u"ࠩࠣࠬࠬ榿")+name+l11lll_l1_ (u"ࠪ࠭ࠬ槀")
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ槁"),l111ll_l1_+title,link,312,l11lll_l1_ (u"ࠬ࠭槂"),l1l1l1111_l1_)
	return
def l1ll1ll1111l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ槃"),url,l11lll_l1_ (u"ࠧࠨ槄"),l11lll_l1_ (u"ࠨࠩ槅"),l11lll_l1_ (u"ࠩࠪ槆"),l11lll_l1_ (u"ࠪࠫ槇"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ槈"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭槉"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		l1111l_l1_(url)
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ槊"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ構")+link
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ槌"))
		if l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ槍") in link: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ槎"),l111ll_l1_+title,link,312)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ槏"),l111ll_l1_+title,link,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ槐"),url,l11lll_l1_ (u"࠭ࠧ槑"),l11lll_l1_ (u"ࠧࠨ槒"),l11lll_l1_ (u"ࠨࠩ槓"),l11lll_l1_ (u"ࠩࠪ槔"),l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ槕"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ槖"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ槗"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ様"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ槙"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ槚"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ槛"),l11lll_l1_ (u"ࠪ࠯ࠬ槜"))
	l11ll1lll1l1_l1_ = [l11lll_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ槝"),l11lll_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ槞"),l11lll_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ槟")]
	if l1ll_l1_:
		l11lll1ll111_l1_ = [l11lll_l1_ (u"ࠧใษิสࠬ槠"),l11lll_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ槡"),l11lll_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ槢")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ槣"), l11lll1ll111_l1_)
		if l1l_l1_ == -1: return
	elif l11lll_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ槤") in options: l1l_l1_ = 0
	elif l11lll_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ槥") in options: l1l_l1_ = 1
	elif l11lll_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ槦") in options: l1l_l1_ = 2
	else: return
	type = l11ll1lll1l1_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ槧")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ槨"),url,l11lll_l1_ (u"ࠩࠪ槩"),l11lll_l1_ (u"ࠪࠫ槪"),l11lll_l1_ (u"ࠫࠬ槫"),l11lll_l1_ (u"ࠬ࠭槬"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭槭"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ槮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ槯"),block,re.DOTALL)
			for link,l1llll_l1_,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ槰"))
				name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ槱"))
				title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ槲")+name+l11lll_l1_ (u"ࠬ࠯ࠧ槳")
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭槴"),l111ll_l1_+title,link,313,l1llll_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭槵"),block,re.DOTALL)
			for link,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ槶"))
				name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ槷"))
				title = title+l11lll_l1_ (u"ࠪࠤ࠭࠭槸")+name+l11lll_l1_ (u"ࠫ࠮࠭槹")
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ槺"),l111ll_l1_+title,link,312)
	return
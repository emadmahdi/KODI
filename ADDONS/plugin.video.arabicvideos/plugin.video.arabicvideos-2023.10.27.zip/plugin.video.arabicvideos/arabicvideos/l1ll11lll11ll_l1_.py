# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ牎")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ牏")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠫࠬ牐")
#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ牑"):l11lll_l1_ (u"࠭ࠧ牒")}
def MAIN(mode,url,text,type,l1l11l1_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l1111l1l_l1_(url)
	#elif mode==142: results = l1ll11ll1llll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l11l1_l1_)
	elif mode==145: results = l1ll1l1l1l11l_l1_(url)
	elif mode==146: results = l1ll11ll1l1l1_l1_(url)
	elif mode==147: results = l1ll1l11l1l1l_l1_()
	elif mode==148: results = l1ll1l11l1lll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡊ࠳࡙ࡥ࡛ࡏࡇ࡛ࡳࡻ࡮ࡅࡸࡒ࡙ࡷࡇࡨ࡝࡞࡛࡚ࡌࡑࡍࡽࡾࡵࡸࡸࡐࡕࠪ牓")
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ牔"),l111ll_l1_+l11lll_l1_ (u"ࠩࡗࡉࡘ࡚࡚ࠠࡑࡘࡘ࡚ࡈࡅࠨ牕"),url,144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ牖"),l111ll_l1_+l11lll_l1_ (u"ࠫࡴࡲࡤࡦࡴࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࠥࡴ࡯ࡵࠢ࡯࡭ࡸࡺࡩ࡯ࡩࠣࡲࡪࡽࡥࡳࠢࡳࡰࡾࡧ࡬ࡪࡵࡷࠫ牗"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡊࡵࡷࡥ࡚ࡼ࡛࡞࡫ࡱࠦ࡭࡫ࡶࡸࡂࡘࡄࡒࡏ࠹࠷ࡻࡎࡪࡑ࠲࡫ࡩ࡙ࡹࠧ牘"),144)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭牙"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วา฼ࠪ牚"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡺࡏࡷࡱࡱ࡮࠹ࡍࡹࡰࡲࡐࡘࡒࡈࡡ࠳࠵ࡴ࡙ࡨࡽࠧ牛"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ牜"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ牝"),l11lll_l1_ (u"ࠫࠬ牞"),149,l11lll_l1_ (u"ࠬ࠭牟"),l11lll_l1_ (u"࠭ࠧ牠"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ牡"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ牢"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ牣")+l11lll_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ牤")+l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ牥"),l11lll_l1_ (u"ࠬ࠭牦"),290)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭牧"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ牨")+l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ物"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ牪"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ牫"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭牬")+l111ll_l1_+l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ牭"),l11ll1_l1_,144,l11lll_l1_ (u"࠭ࠧ牮"),l11lll_l1_ (u"ࠧࠨ牯"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ牰"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ牱"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ牲")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ牳"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭牴"),146)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ牵"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ牶"),l11lll_l1_ (u"ࠨࠩ牷"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ牸"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ特")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ牺"),l11lll_l1_ (u"ࠬ࠭牻"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭牼"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ牽")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ牾"),l11lll_l1_ (u"ࠩࠪ牿"),148)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ犀"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭犁")+l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ犂"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ犃"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ犄"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ犅")+l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭犆"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ犇"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ犈"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ犉")+l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ犊"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ犋"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ犌"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ犍")+l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ犎"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ犏"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ犐"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ犑")+l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭犒"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ犓"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ犔"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ犕")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ犖"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ犗"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭犘"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ犙")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭犚"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭犛"),144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ犜"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭犝")+l111ll_l1_+l11lll_l1_ (u"ࠬอไฺำสๆࠥิืษหࠣห้๋ัอ฻ํอࠬ犞"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎ࠷࡮࡚ࡷ࠶ࡱࡰࡊ࠷࠻ࡗࡪࡶ࡚ࡇ࡬ࡓࡴࡉ࡭ࡴ࡬ࡹࡿࡸ࡯ࡕࡈࡷࡱ࡫ࡸࠧ犟"),144)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ犠"),l111ll_l1_+l11lll_l1_ (u"ࠨษ฼ำฬีวหࠢสฺฬ็ษࠡ์๋ฮ๏๎ศࠨ犡"),l11lll_l1_ (u"ࠩࠪ犢"),144)
	#l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ犣"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ犤"),l11lll_l1_ (u"ࠬํะศࠢส่ฬิส๋ษิࠤุ๎แࠡ์ัีั้ࠠๆ่ࠣห้ฮั็ษ่ะࠬ犥"),l11lll_l1_ (u"࠭ไฤ่๊ࠤุ๎แࠡ์ๅ์๊ࠦศหึ฽๎้ࠦศา่ส้ั๊้ࠦฬํ์อ࠭犦"))
	#if l1ll11l111_l1_==1:
	#	url = l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ犧")
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ犨"))
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡕࡩࡵࡲࡡࡤࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡹ࡭ࡩ࡫࡯ࡴ࠮ࠪ犩")+url+l11lll_l1_ (u"ࠪ࠭ࠬ犪"))
	#	#xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡗࡻ࡮ࡂࡦࡧࡳࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ犫"))
	return
l11lll_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡓࡁࡊࡐࡓࡅࡌࡋࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰ࠱ࡩࡣ࠭ࡦࡤࡸࡦࠦ࠽ࠡࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁࠩࡷࡵࡰ࠮ࠐࠉࡪࡨࠣࠫࡗ࡫ࡦࡢࡣࡷࠤࡆࡲ࠭ࡈࡣࡰࡱࡦࡲࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡽࡪࡹࠧࠪࠌࠌࡨࡩࠦ࠽ࠡࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠎࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡰࡤ࡫ࡪ࠮࡬ࡦࡰࠫࡨࡩ࠯ࠩ࠻ࠌࠌࠍ࡮ࡺࡥ࡮ࠢࡀࠤࡩࡪ࡛ࡪ࡟ࠍࠍࠎࡏࡎࡔࡇࡕࡘࡤࡏࡔࡆࡏࡢࡘࡔࡥࡍࡆࡐࡘࠬ࡮ࡺࡥ࡮ࠫࠍࠍࡎ࡚ࡅࡎࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ犬")
def l1ll1l11l1l1l_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭犭"))
	return
def l1ll1l11l1lll_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ犮"))
	return
def PLAY(url,type):
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ犯")
	#items = re.findall(l11lll_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ犰"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ犱")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ犲"))
	#return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ犳")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll11ll1l1l1_l1_(url):
	html,cc,data = l1ll1l11l1111_l1_(url)
	dd = cc[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ犴")][l11lll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ犵")][l11lll_l1_ (u"ࠨࡶࡤࡦࡸ࠭状")]
	for l11ll111l1_l1_ in range(len(dd)):
		item = dd[l11ll111l1_l1_]
		l1ll1l1l11l11_l1_(item,url,str(l11ll111l1_l1_))
	ee = dd[0][l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ犷")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ犸")][l11lll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ犹")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ犺")]
	s = 0
	for l11ll111l1_l1_ in range(len(ee)):
		item = ee[l11ll111l1_l1_][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ犻")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ犼")][0]
		if list(item[l11lll_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ犽")][l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ犾")].keys())[0]==l11lll_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ犿"): continue
		succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_ = l1ll1l1l1ll1l_l1_(item)
		if not title:
			s += 1
			title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭狀")+str(s)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ狁"),l111ll_l1_+title,url,144,l11lll_l1_ (u"࠭ࠧ狂"),str(l11ll111l1_l1_))
	key = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ狃"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭狄")+key[0]
	html,cc,l11ll1l11_l1_ = l1ll1l11l1111_l1_(l11l11l_l1_)
	for l1ll111ll111_l1_ in range(3,4):
		dd = cc[l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ狅")][l1ll111ll111_l1_][l11lll_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ狆")][l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ狇")]
		for l11ll111l1_l1_ in range(len(dd)):
			item = dd[l11ll111l1_l1_]
			if l11lll_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ狈") in str(item): continue
			l1ll1l1l11l11_l1_(item)
	return
def ITEMS(url,data=l11lll_l1_ (u"࠭ࠧ狉"),index=0):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ狊"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ狋"),l11lll_l1_ (u"ࠩࠪ狌"))
	html,cc,l11ll1l11_l1_ = l1ll1l11l1111_l1_(url,data)
	l1l11111l1_l1_,ff = l11lll_l1_ (u"ࠪࠫ狍"),l11lll_l1_ (u"ࠫࠬ狎")
	#if l11lll_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠫ狏") in html.lower(): DIALOG_OK(l11lll_l1_ (u"࠭ࠧ狐"),l11lll_l1_ (u"ࠧࠨ狑"),l11lll_l1_ (u"ࠨࡱࡺࡲࡪࡸࠠࡦࡺ࡬ࡷࡹ࠭狒"),l11lll_l1_ (u"ࠩ࡬ࡲࠥ࡮ࡴ࡮࡮ࠪ狓"))
	owner = re.findall(l11lll_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ狔"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ狕"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ狖"),html,re.DOTALL)
	if owner:
		l1l11111l1_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ狗")+owner[0][0]+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ狘")
		link = owner[0][1]
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭狙") not in link: link = l11ll1_l1_+link
		#if l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭狚") in url and l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭狛") not in url and l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ狜") not in url and l11lll_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ狝") not in url:
		if l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ狞") in url: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ狟"),l111ll_l1_+l1l11111l1_l1_,link,144)
	#if cc==l11lll_l1_ (u"ࠨࠩ狠"): l1ll11ll1lll1_l1_(url,html) ; return
	l1ll11ll1ll11_l1_ = [l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ狡"),l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ狢"),l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ狣"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ狤"),l11lll_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ狥"),l11lll_l1_ (u"ࠧࡴࡵࡀࠫ狦"),l11lll_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ狧"),l11lll_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ狨"),l11lll_l1_ (u"ࠪࡦࡵࡃࠧ狩"),l11lll_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ狪")]
	l1ll11ll1l111_l1_ = not any(value in url for value in l1ll11ll1ll11_l1_)
	if l1ll11ll1l111_l1_ and l1l11111l1_l1_:
		l11l1ll11_l1_ = l11lll_l1_ (u"ࠬอไษฯฮࠫ狫")
		l1lll1lll_l1_ = l11lll_l1_ (u"࠭โ้ษษ้ࠥอไหึ฽๎้࠭独")
		l11l1l1ll_l1_ = l11lll_l1_ (u"ࠧศๆไ๎ิ๐่่ษอࠫ狭")
		l1ll11ll1l11l_l1_ = l11lll_l1_ (u"ࠨษ็ๆ๋๎วหࠩ狮")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ狯"),l111ll_l1_+l1l11111l1_l1_,url,9999)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧฮอฬࠤࠪ狰") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ狱"),l111ll_l1_+l11l1ll11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭狲"),l11lll_l1_ (u"࠭ࠧ狳"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ狴"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ狵") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ狶"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ狷"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ狸") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ狹"),l111ll_l1_+l11l1l1ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ狺"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ狻") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ狼"),l111ll_l1_+l1ll11ll1l11l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ狽"),144)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾࡙ࠧࡥࡢࡴࡦ࡬ࠧ࠭狾") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ狿"),l111ll_l1_+l11l1ll11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭猀"),l11lll_l1_ (u"࠭ࠧ猁"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ猂"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ猃") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ猄"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ猅"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ猆") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ猇"),l111ll_l1_+l11l1l1ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ猈"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ猉") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ猊"),l111ll_l1_+l1ll11ll1l11l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ猋"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ猌"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ猍"),l11lll_l1_ (u"ࠬ࠭猎"),9999)
	if l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ猏") in url:
		dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ猐")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ猑")][l11lll_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ猒")][l11lll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ猓")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭猔")]
		l1ll11ll11lll_l1_ = 0
		for i in range(len(dd)):
			if l11lll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ猕") in list(dd[i].keys()):
				l1ll11ll11ll1_l1_ = dd[i][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ猖")]
				length = len(str(l1ll11ll11ll1_l1_))
				if length>l1ll11ll11lll_l1_:
					l1ll11ll11lll_l1_ = length
					ff = l1ll11ll11ll1_l1_
		if l1ll11ll11lll_l1_==0: return
	elif l11lll_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ猗") in url or l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ猘") in url or l11lll_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ猙") in url or l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ猚") in url or l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ猛") in url or url==l11ll1_l1_:
		l1ll11lllll1l_l1_ = []
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ猜"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ猝"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ猞"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ猟"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ猠"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠲࠷࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ猡"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ猢"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰ࡚ࡥࡹࡩࡨࡏࡧࡻࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟ࠥ猣"))
		l1ll11ll1l1ll_l1_,ff = l1ll11lll11l1_l1_(cc,l11lll_l1_ (u"࠭ࠧ猤"),l1ll11lllll1l_l1_)
	if not ff:
		try:
			dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ猥")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ猦")][l11lll_l1_ (u"ࠩࡷࡥࡧࡹࠧ猧")]
			l1ll11lll1ll_l1_ = l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ猨") in url or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ猩") in url or l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ猪") in url
			l1ll11lll1ll1_l1_ = l11lll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭猫") in html or l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ猬") in html or l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ猭") in html
			l1ll11lll1l1l_l1_ = l11lll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ献") in html or l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ猯") in html or l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ猰") in html
			if l1ll11lll1ll_l1_ and (l1ll11lll1ll1_l1_ or l1ll11lll1l1l_l1_):
				for l11ll111l1_l1_ in range(len(dd)):
					if l11lll_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ猱") not in list(dd[l11ll111l1_l1_].keys()): continue
					ee = dd[l11ll111l1_l1_][l11lll_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ猲")]
					try: gg = ee[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ猳")][l11lll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ猴")][l11lll_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ猵")][l11lll_l1_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ猶")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ猷")][l11ll111l1_l1_]
					except: gg = ee
					try: link = gg[l11lll_l1_ (u"ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ猸")][l11lll_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ猹")][l11lll_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ猺")][l11lll_l1_ (u"ࠨࡷࡵࡰࠬ猻")]
					except: continue
					if   l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ猼")		in link	and l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ猽")		in url: ee = dd[l11ll111l1_l1_] ; break
					elif l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ猾")	in link	and l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ猿")	in url: ee = dd[l11ll111l1_l1_] ; break
					elif l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ獀")	in link	and l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ獁")		in url: ee = dd[l11ll111l1_l1_] ; break
					else: ee = dd[0]
			elif l11lll_l1_ (u"ࠨࡤࡳࡁࠬ獂") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ獃")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ獄")]
		except: pass
	if not ff: return
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ獅"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ獆"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ獇"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ獈"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ獉"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ獊"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ獋"))
	if l11lll_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ獌") not in url: l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡻࡢࡎࡧࡱࡹࠬࡣ࡛ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩࡠࠦ獍"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ獎"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ獏"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ獐"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ獑"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ獒"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ獓"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ獔"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ獕"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨࠥ獖"))
	l1111l1111l_l1_ = l1l11lllll11_l1_(l11lll_l1_ (u"ࡶࠩๆ่่่ࠥศศ่ࠤฬ๊สี฼ํ่ࠬ獗"))
	l1111l111l1_l1_ = l1l11lllll11_l1_(l11lll_l1_ (u"ࡷࠪ็้ࠦวๅใํำ๏๎็ศฬࠪ獘"))
	l1ll11lll1111_l1_ = l1l11lllll11_l1_(l11lll_l1_ (u"ࡸ่๊ࠫࠠศๆๅ๊ํอสࠨ獙"))
	l11l11l1l1l1_l1_ = [l1111l1111l_l1_,l1111l111l1_l1_,l1ll11lll1111_l1_,l11lll_l1_ (u"ࠫࡆࡲ࡬ࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ獚"),l11lll_l1_ (u"ࠬࡇ࡬࡭ࠢࡹ࡭ࡩ࡫࡯ࡴࠩ獛"),l11lll_l1_ (u"࠭ࡁ࡭࡮ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ獜")]
	l1ll11ll1ll1l_l1_,gg = l1ll11lll11l1_l1_(ff,index,l1ll11lllll1l_l1_)
	if l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ獝") in str(type(gg)) and any(value in str(gg[0]) for value in l11l11l1l1l1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll11lllll1l_l1_ = []
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ獞"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ獟"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ獠"))
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ獡"))		#4
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ獢"))		#7
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ獣"))		#6
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ獤"))		#5
		l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ獥"))
		l1ll11ll1l1ll_l1_,item = l1ll11lll11l1_l1_(gg,index2,l1ll11lllll1l_l1_)
		#if l1ll11ll1l1ll_l1_ not in [l11lll_l1_ (u"ࠩ࠵ࠫ獦"),l11lll_l1_ (u"ࠪ࠸ࠬ獧"),l11lll_l1_ (u"ࠫ࠺࠭獨")]: l1ll1l1l11l11_l1_(item)		# 2,4,7
		#else: l1ll1l1l11l11_l1_(item,url,str(index2))
		l1ll1l1l11l11_l1_(item,url,str(index2))
		if l1ll11ll1l1ll_l1_==l11lll_l1_ (u"ࠬ࠺ࠧ獩"):
			try:
				hh = item[l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭獪")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ獫")][l11lll_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ獬")][l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ獭")]
				for l1ll1l11l11ll_l1_ in range(len(hh)):
					l11l11lll1ll_l1_ = hh[l1ll1l11l11ll_l1_]
					l1ll1l1l11l11_l1_(l11l11lll1ll_l1_)
			except: pass
	l1lllll1lll_l1_ = False
	if l11lll_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ獮") not in url and l1ll11ll1ll1l_l1_==l11lll_l1_ (u"ࠫ࠽࠭獯"): l1lllll1lll_l1_ = True
	if l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ獰") in l11ll1l11_l1_: l1ll1l11lll11_l1_,key,l1ll1l1l1ll11_l1_,l1ll1l11l1ll1_l1_,token,l1ll1l111l111_l1_ = l11ll1l11_l1_.split(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ獱"))
	else: l1ll1l11lll11_l1_,key,l1ll1l1l1ll11_l1_,l1ll1l11l1ll1_l1_,token,l1ll1l111l111_l1_ = l11lll_l1_ (u"ࠧࠨ獲"),l11lll_l1_ (u"ࠨࠩ獳"),l11lll_l1_ (u"ࠩࠪ獴"),l11lll_l1_ (u"ࠪࠫ獵"),l11lll_l1_ (u"ࠫࠬ獶"),l11lll_l1_ (u"ࠬ࠭獷")
	l11l11l_l1_,l1lll111ll1_l1_ = l11lll_l1_ (u"࠭ࠧ獸"),l11lll_l1_ (u"ࠧࠨ獹")
	if menuItemsLIST:
		l1ll11lll1l11_l1_ = str(menuItemsLIST[-1][1])
		if   l111ll_l1_+l11lll_l1_ (u"ࠨࡅࡋࡒࡑ࠭獺") in l1ll11lll1l11_l1_: l1lll111ll1_l1_ = l11lll_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ獻")
		elif l111ll_l1_+l11lll_l1_ (u"࡙ࠪࡘࡋࡒࠨ獼") in l1ll11lll1l11_l1_: l1lll111ll1_l1_ = l11lll_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭獽")
		elif l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ獾") in l1ll11lll1l11_l1_: l1lll111ll1_l1_ = l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ獿")
	if l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ玀") in html and l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ玁") not in url and not l1lllll1lll_l1_ and l11lll_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ玂") not in url:	# and (index!=l11lll_l1_ (u"ࠪࠫ玃") or l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ玄") in url or l11lll_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ玅") in url or l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭玆") in url or l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭率") in url):
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ玈")+l1ll1l1l1ll11_l1_
	elif l11lll_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ玉") in html and l11lll_l1_ (u"ࠪࡦࡵࡃࠧ玊") not in url and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ王") in url or l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ玌") in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ玍")+key
	elif l11lll_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ玎") in html and l11lll_l1_ (u"ࠨࡤࡳࡁࠬ玏") not in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭玐")+key
	if l11l11l_l1_: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ玑"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ玒"),l11l11l_l1_,144,l1lll111ll1_l1_,l11lll_l1_ (u"ࠬ࠭玓"),l11ll1l11_l1_)
	return
def l1ll11lll11l1_l1_(l11l1l1ll111_l1_,l11l1ll11l11_l1_,l1ll1l1111l1l_l1_):
	cc = l11l1l1ll111_l1_
	ff,index = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	gg,index2 = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	item,render = l11l1l1ll111_l1_,l11l1ll11l11_l1_
	count = len(l1ll1l1111l1l_l1_)
	for l11ll111l1_l1_ in range(count):
		try:
			out = eval(l1ll1l1111l1l_l1_[l11ll111l1_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"࠭ࠧ玔")
			return str(l11ll111l1_l1_+1),out
		except: pass
	return l11lll_l1_ (u"ࠧࠨ玕"),l11lll_l1_ (u"ࠨࠩ玖")
def l1ll1l1l1ll1l_l1_(item):
	try: l1ll1l1l11111_l1_ = list(item.keys())[0]
	except: return False,l11lll_l1_ (u"ࠩࠪ玗"),l11lll_l1_ (u"ࠪࠫ玘"),l11lll_l1_ (u"ࠫࠬ玙"),l11lll_l1_ (u"ࠬ࠭玚"),l11lll_l1_ (u"࠭ࠧ玛"),l11lll_l1_ (u"ࠧࠨ玜"),l11lll_l1_ (u"ࠨࠩ玝")
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_ = False,l11lll_l1_ (u"ࠩࠪ玞"),l11lll_l1_ (u"ࠪࠫ玟"),l11lll_l1_ (u"ࠫࠬ玠"),l11lll_l1_ (u"ࠬ࠭玡"),l11lll_l1_ (u"࠭ࠧ玢"),l11lll_l1_ (u"ࠧࠨ玣"),l11lll_l1_ (u"ࠨࠩ玤")
	#WRITE_THIS(l11lll_l1_ (u"ࠩࠪ玥"),str(item))
	render = item[l1ll1l1l11111_l1_]
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ玦"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ玧"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ玨"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ玩"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ玪"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ玫"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ玬"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ玭"))
	l1ll11ll1l1ll_l1_,title = l1ll11lll11l1_l1_(item,render,l1ll11lllll1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ玮"),l11lll_l1_ (u"ࠬ࠭环"),l11lll_l1_ (u"࠭ࠧ现"),title)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ玱"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ玲"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ玳"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ玴")) # required for l11l1l11l1ll_l1_ l1lllll1lll_l1_
	l1ll11ll1l1ll_l1_,link = l1ll11lll11l1_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ玵"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ玶"))
	l1ll11ll1l1ll_l1_,l1llll_l1_ = l1ll11lll11l1_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ玷"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ玸"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ玹"))
	l1ll11ll1l1ll_l1_,count = l1ll11lll11l1_l1_(item,render,l1ll11lllll1l_l1_)
	l1ll11lllll1l_l1_ = []
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ玺"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ玻"))
	l1ll11lllll1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ玼"))
	l1ll11ll1l1ll_l1_,l1l1l1111_l1_ = l1ll11lll11l1_l1_(item,render,l1ll11lllll1l_l1_)
	if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ玽") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ玾"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ玿")
	if l11lll_l1_ (u"ࠨ็หหูืࠧ珀") in l1l1l1111_l1_: l1l1l1111_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠩࠪ珁"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ珂")
	if l11lll_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ珃") in list(render.keys()):
		l1ll1l1l11l1l_l1_ = str(render[l11lll_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ珄")])
		if l11lll_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭珅") in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠧࠥ࠼ࠪ珆")
		if l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ珇") in l1ll1l1l11l1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ珈")
		if l11lll_l1_ (u"ࠪࡆࡺࡿࠧ珉") in l1ll1l1l11l1l_l1_ or l11lll_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ珊") in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠬࠪࠤ࠻ࠩ珋")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡻࠧๆสสุึ࠭珌")) in l1ll1l1l11l1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ珍")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡶࠩืีฬวࠧ珎")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿࠭珏")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡸࠫฬูสวฮสีࠬ珐")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"ࠫࠩࠪ࠺ࠨ珑")
		if l1l11lllll11_l1_(l11lll_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ珒")) in l1ll1l1l11l1l_l1_: l1ll1l11l111l_l1_ = l11lll_l1_ (u"࠭ࠤ࠻ࠩ珓")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ珔") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠨࡁࠪ珕"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ珖") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ珗")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1ll1l11l111l_l1_: title = l1ll1l11l111l_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ珘")+title
	#title = unescapeHTML(title)
	l1l1l1111_l1_ = l1l1l1111_l1_.replace(l11lll_l1_ (u"ࠬ࠲ࠧ珙"),l11lll_l1_ (u"࠭ࠧ珚"))
	count = count.replace(l11lll_l1_ (u"ࠧ࠭ࠩ珛"),l11lll_l1_ (u"ࠨࠩ珜"))
	count = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭珝"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"ࠪࠫ珞")
	return True,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_
def l1ll1l1l11l11_l1_(item,url=l11lll_l1_ (u"ࠫࠬ珟"),index=l11lll_l1_ (u"ࠬ࠭珠")):
	succeeded,title,link,l1llll_l1_,count,l1l1l1111_l1_,l1111llllll_l1_,l1ll1l11l111l_l1_ = l1ll1l1l1ll1l_l1_(item)
	#if l11lll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ珡") in url and index==l11lll_l1_ (u"ࠧ࠱ࠩ珢"):
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ珣"),l111ll_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭珤") in str(item): return	# l1ll1l1l1ll11_l1_ not items
	elif l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ珥") in str(item): return			# l1ll1l1l111l1_l1_ not items
	elif not link and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ珦") in url: return			# separator l1ll11ll11l1l_l1_ list not items
	elif title and not link and (l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ珧") in url or l11lll_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭珨") in str(item) or url==l11ll1_l1_):
		title = l11lll_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ珩")+title+l11lll_l1_ (u"ࠨࠢࡀࡁࡂ࠭珪")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ珫"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ珬"),9999)
	elif title and l11lll_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭班") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ珮"),l111ll_l1_+title,l11lll_l1_ (u"࠭ࠧ珯"),9999)
	elif l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ珰") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ珱"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif not title: return
	elif l1111llllll_l1_: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ珲"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	#elif l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ珳") in link and l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ珴") not in link and l11lll_l1_ (u"ࠬࡺ࠽࠱ࠩ珵") not in link:
	#	l1ll1l11l11l1_l1_ = re.findall(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ珶"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ珷")+l1ll1l11l11l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ珸"),l111ll_l1_+l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ珹")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ珺")+title,link,144,l1llll_l1_)
	elif l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭珻") in link or l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ珼") in link:
		if l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭珽") in link and l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ現") not in link:
			l1ll1l11l11l1_l1_ = link.split(l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ珿"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ琀")+l1ll1l11l11l1_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ琁"),l111ll_l1_+l11lll_l1_ (u"ࠫࡑࡏࡓࡕࠩ琂")+count+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ球")+title,link,144,l1llll_l1_)
		else:
			link = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭琄"),1)[0]
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭琅"),l111ll_l1_+title,link,143,l1llll_l1_,l1l1l1111_l1_)
	else:
		type = l11lll_l1_ (u"ࠨࠩ理")
		if not link: link = url
		#if l11lll_l1_ (u"ࠩࡶࡷࡂ࠭琇") in link: link = url
		#elif l11lll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭琈") in link: link = url		# not needed it will stop l1ll11lll111l_l1_ l11l1l11l1ll_l1_ l1lllll1lll_l1_
		elif not any(value in link for value in [l11lll_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ琉"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ琊"),l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ琋"),l11lll_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ琌"),l11lll_l1_ (u"ࠨࡵࡶࡁࠬ琍"),l11lll_l1_ (u"ࠩࡥࡴࡂ࠭琎")]):
			if l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭琏")	in link or l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ琐") in link: type = l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ琑")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ琒")
			if l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ琓") in link: type = l11lll_l1_ (u"ࠨࡗࡖࡉࡗ࠭琔")+count+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭琕")
			index,l1ll1l11ll1l1_l1_ = l11lll_l1_ (u"ࠪࠫ琖"),l11lll_l1_ (u"ࠫࠬ琗")
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ琘"),l111ll_l1_+type+title,link,144,l1llll_l1_,index)
	return
def l1ll1l11l1111_l1_(url,data=l11lll_l1_ (u"࠭ࠧ琙"),request=l11lll_l1_ (u"ࠧࠨ琚")):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ琛"))
	#if l11lll_l1_ (u"ࠩࡢࡣࠬ琜") in l1ll1l11ll1l1_l1_: l1ll1l11ll1l1_l1_ = l11lll_l1_ (u"ࠪࠫ琝")
	#if l11lll_l1_ (u"ࠫࡸࡹ࠽ࠨ琞") in url: url = url.split(l11lll_l1_ (u"ࠬࡹࡳ࠾ࠩ琟"))[0]
	if request==l11lll_l1_ (u"࠭ࠧ琠"): request = l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ琡")
	l111llll1l_l1_ = l1l11111l_l1_()
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ琢"):l111llll1l_l1_,l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ琣"):l11lll_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ琤")}
	#l1l1ll1ll_l1_ = headers.copy()
	if l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ琥") in data: l1ll1l11lll11_l1_,key,l1ll1l1l1ll11_l1_,l1ll1l11l1ll1_l1_,token,l1ll1l111l111_l1_ = data.split(l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ琦"))
	else: l1ll1l11lll11_l1_,key,l1ll1l1l1ll11_l1_,l1ll1l11l1ll1_l1_,token,l1ll1l111l111_l1_ = l11lll_l1_ (u"࠭ࠧ琧"),l11lll_l1_ (u"ࠧࠨ琨"),l11lll_l1_ (u"ࠨࠩ琩"),l11lll_l1_ (u"ࠩࠪ琪"),l11lll_l1_ (u"ࠪࠫ琫"),l11lll_l1_ (u"ࠫࠬ琬")
	if l11lll_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ琭") in url:
		l11ll1l11_l1_ = {}
		l11ll1l11_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ琮")] = {l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ琯"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ琰"):l11lll_l1_ (u"ࠤࡤࡶࠧ琱"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ琲"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ琳"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ琴"):l1ll1l11l1ll1_l1_}}
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ琵"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ琶"))
	elif l11lll_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭琷") in url and l1ll1l11lll11_l1_:
		l11ll1l11_l1_ = {l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ琸"):token}
		l11ll1l11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ琹")] = {l11lll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ琺"):{l11lll_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ琻"):l1ll1l11lll11_l1_,l11lll_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ琼"):l11lll_l1_ (u"ࠢࡘࡇࡅࠦ琽"),l11lll_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ琾"):l1ll1l11l1ll1_l1_}}
		l11ll1l11_l1_ = str(l11ll1l11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ琿"),url,l11ll1l11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ瑀"))
	elif l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ瑁") in url and l1ll1l111l111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭瑂"):l11lll_l1_ (u"࠭࠱ࠨ瑃"),l11lll_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ瑄"):l1ll1l11l1ll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ瑅"):l11lll_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ瑆")+l1ll1l111l111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ瑇"),url,l11lll_l1_ (u"ࠫࠬ瑈"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭瑉"),l11lll_l1_ (u"࠭ࠧ瑊"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ瑋"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ瑌"),url,l11lll_l1_ (u"ࠩࠪ瑍"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ瑎"),l11lll_l1_ (u"ࠫࠬ瑏"),l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ瑐"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭瑑"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭瑒"),html,re.DOTALL|re.I)
	if tmp: l1ll1l11l1ll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ瑓"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ瑔"),html,re.DOTALL|re.I)
	if tmp: l1ll1l11lll11_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ瑕"),html,re.DOTALL|re.I)
	if tmp: l1ll1l1l1ll11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ瑖") in list(cookies.keys()): l1ll1l111l111_l1_ = cookies[l11lll_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ瑗")]
	data = l1ll1l11lll11_l1_+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ瑘")+key+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ瑙")+l1ll1l1l1ll11_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ瑚")+l1ll1l11l1ll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭瑛")+token+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ瑜")+l1ll1l111l111_l1_
	if request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ瑝") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ瑞") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ瑟"),html,re.DOTALL)
		if not l111lll11l_l1_: l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ瑠"),html,re.DOTALL)
		l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠨࡵࡷࡶࠬ瑡"),l111lll11l_l1_[0])
	elif request==l11lll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ瑢") and l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ瑣") in html:
		l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ瑤"),html,re.DOTALL)
		l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡹࡴࡳࠩ瑥"),l111lll11l_l1_[0])
	elif l11lll_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ瑦") not in html: l1ll11llllll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ瑧"),html)
	else: l1ll11llllll1_l1_ = l11lll_l1_ (u"ࠨࠩ瑨")
	#open(l11lll_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭瑩"),l11lll_l1_ (u"ࠪࡻࠬ瑪")).write(str(l1ll11llllll1_l1_))
	#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ瑫"),l11lll_l1_ (u"ࠬࡽࠧ瑬")).write(html)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ瑭"),data)
	return html,l1ll11llllll1_l1_,data
def l1ll1l1l1l11l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ瑮"),l11lll_l1_ (u"ࠨ࠭ࠪ瑯"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ瑰")+search
	ITEMS(l11l11l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ瑱"),l11lll_l1_ (u"ࠫ࠰࠭瑲"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ瑳")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ瑴") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ瑵")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ瑶") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ瑷")
		elif l11lll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ瑸") in options: l1ll1l111l1l1_l1_ = l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ瑹")
		l11l1l1_l1_ = l11l11l_l1_+l1ll1l111l1l1_l1_
	else:
		l1ll1l111l11l_l1_,l1ll11llll1l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠬ࠭瑺")
		l1ll11lllll11_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ瑻"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭瑼"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ瑽"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ瑾"),l11lll_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ瑿")]
		l1ll1l1l1111l_l1_ = [l11lll_l1_ (u"ࠫࠬ璀"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ璁"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ璂"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭璃"),l11lll_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ璄")]
		l1ll1l1l11ll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ璅"),l1ll11lllll11_l1_)
		if l1ll1l1l11ll1_l1_ == -1: return
		l1ll1l1111lll_l1_ = l1ll1l1l1111l_l1_[l1ll1l1l11ll1_l1_]
		html,c,data = l1ll1l11l1111_l1_(l11l11l_l1_+l1ll1l1111lll_l1_)
		if c:
			d = c[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ璆")][l11lll_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ璇")][l11lll_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ璈")][l11lll_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ璉")][l11lll_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ璊")][l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ璋")][l11lll_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ璌")]
			for l1ll11llll11l_l1_ in range(len(d)):
				group = d[l1ll11llll11l_l1_][l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ璍")][l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ璎")]
				for l1ll1l1l1l1l1_l1_ in range(len(group)):
					render = group[l1ll1l1l1l1l1_l1_][l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ璏")]
					if l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ璐") in list(render.keys()):
						link = render[l11lll_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ璑")][l11lll_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ璒")][l11lll_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ璓")][l11lll_l1_ (u"ࠪࡹࡷࡲࠧ璔")]
						link = link.replace(l11lll_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ璕"),l11lll_l1_ (u"ࠬࠬࠧ璖"))
						title = render[l11lll_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ璗")]
						title = title.replace(l11lll_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ璘"),l11lll_l1_ (u"ࠨࠩ璙"))
						if l11lll_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ璚") in title: continue
						if l11lll_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ璛") in title:
							title = l11lll_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ璜")+title
							l1lll1lll_l1_ = title
							l1lllll1ll_l1_ = link
						if l11lll_l1_ (u"ࠬะัห์หࠤาูศࠨ璝") in title: continue
						title = title.replace(l11lll_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ璞"),l11lll_l1_ (u"ࠧࠨ璟"))
						if l11lll_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ璠") in title: continue
						if l11lll_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ璡") in title:
							title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ璢")+title
							l1lll1lll_l1_ = title
							l1lllll1ll_l1_ = link
						if l11lll_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ璣") in title: continue
						l1ll1l111l11l_l1_.append(escapeUNICODE(title))
						l1ll11llll1l1_l1_.append(link)
		if not l1lll1lll_l1_: l1ll1l11llll1_l1_ = l11lll_l1_ (u"ࠬ࠭璤")
		else:
			l1ll1l111l11l_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ璥"),l1lll1lll_l1_]+l1ll1l111l11l_l1_
			l1ll11llll1l1_l1_ = [l11lll_l1_ (u"ࠧࠨ璦"),l1lllll1ll_l1_]+l1ll11llll1l1_l1_
			l1ll1l1l1l111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭璧"),l1ll1l111l11l_l1_)
			if l1ll1l1l1l111_l1_ == -1: return
			l1ll1l11llll1_l1_ = l1ll11llll1l1_l1_[l1ll1l1l1l111_l1_]
		if l1ll1l11llll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1ll1l11llll1_l1_
		elif l1ll1l1111lll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1ll1l1111lll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡓࡧࡰࡳࡻ࡫ࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠩ࠯ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬ࡯ࡳࡶࠣࡦࡾ࠭ࠬࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠦࠧࠨ璨")
	ITEMS(l11l1l1_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ⒆")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡆࡄ࠶ࡣࠬ⒇")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1lll1llll1_l1_.l1lll1l1111_l1_
# l1llll1lll1_l1_	https://www.l1llll1lll1_l1_.com/l1lll1l11l1_l1_
# l1lll1l111l_l1_	https://t.me/l1lll11ll1l_l1_
# l1lll11l1ll_l1_	https://l1llll1111l_l1_.com/l1lll11ll1l_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧศๆู่ฬืูสࠢส่าืษࠨ⒈"),l11lll_l1_ (u"ࠨษํะ๏ࠦศิฬࠪ⒉"),l11lll_l1_ (u"ࠩส่ฯ฻ๅ๋็ࠣห้าฯ๋ัࠪ⒊"),l11lll_l1_ (u"ࠪ฽ึ๎ึࠡษ็ฺ้อัฺหࠪ⒋"),l11lll_l1_ (u"๊้ࠫสษฬํࠫ⒌"),l11lll_l1_ (u"ࠬอ๊อ์ࠣฬุะࠠศๆฯำ๏ีࠧ⒍"),l11lll_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็ฬิ๐ไࠨ⒎"),l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ⒏"),l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอูสࠨ⒐"),l11lll_l1_ (u"่ࠩ์็฿ࠠ็ฬไ่๏้ำࠨ⒑")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==790: results = MENU()
	elif mode==791: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==792: results = l1l11l_l1_(url)
	elif mode==793: results = PLAY(url)
	elif mode==796: results = l1lllll111l_l1_(url,l1l11l1_l1_)
	elif mode==799: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒒"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⒓"),l11lll_l1_ (u"ࠬ࠭⒔"),799,l11lll_l1_ (u"࠭ࠧ⒕"),l11lll_l1_ (u"ࠧࠨ⒖"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⒗"))
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⒘"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⒙"),l11lll_l1_ (u"ࠫࠬ⒚"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⒛"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ⒜"),l11lll_l1_ (u"ࠧࠨ⒝"),l11lll_l1_ (u"ࠨࠩ⒞"),l11lll_l1_ (u"ࠩࠪ⒟"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⒠"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵ࠯ࡳࡥ࡬࡫ࡳࠩ࠰࠭ࡃ࠮࡬ࡡ࠮ࡨࡲࡰࡩ࡫ࡲࠨ⒡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ⒢"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ⒣"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⒤") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒥"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⒦")+l111ll_l1_+title,link,791)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⒧"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⒨"),l11lll_l1_ (u"ࠬ࠭⒩"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩ࠭࠴ࠪࡀࠫࡶࡳࡨ࡯ࡡ࡭࠯ࡥࡳࡽ࠭⒪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡺࡩࡵ࡮ࡨ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⒫"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⒬"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⒭") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒮"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⒯")+l111ll_l1_+title,link,791,l11lll_l1_ (u"ࠬ࠭⒰"),l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࡱࡪࡴࡵࠨ⒱"))
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⒲"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⒳"),l11lll_l1_ (u"ࠩࠪ⒴"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⒵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪⒶ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧⒷ"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫⒸ") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⒹ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⒺ")+l111ll_l1_+title,link,791)
	return html
def l1lllll111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪⒻ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫⒼ"),l11lll_l1_ (u"ࠫࠬⒽ"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⒾ"),url,l11lll_l1_ (u"࠭ࠧⒿ"),l11lll_l1_ (u"ࠧࠨⓀ"),l11lll_l1_ (u"ࠨࠩⓁ"),l11lll_l1_ (u"ࠩࠪⓂ"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࡙ࡅࡂࡕࡒࡒࡘࡥࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬⓃ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡤࡶࡹ࡯ࡣ࡭ࡧࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡧࡲࡵ࡫ࡦࡰࡪ࠭Ⓞ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠬ࠭Ⓟ"),l11lll_l1_ (u"࠭ࠧⓆ"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠧฮๆๅหฯ࠭Ⓡ") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"ࠨ็๋หุ๋ࠧⓈ") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩⓉ"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓊ"),l111ll_l1_+title,link,796,l1llll_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫⓋ"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫⓌ"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⓍ"),l111ll_l1_+title,link,793,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭Ⓨ"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⓏ"),l111ll_l1_+title,link,793)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪⓐ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫⓑ"),l11lll_l1_ (u"ࠫࠬⓒ"),l11lll_l1_ (u"࡚ࠬࡉࡕࡎࡈࡗࠬⓓ"),url)
	limit,start,l11ll1ll1_l1_,select,l1lll11llll_l1_ = 0,0,l11lll_l1_ (u"࠭ࠧⓔ"),l11lll_l1_ (u"ࠧࠨⓕ"),l11lll_l1_ (u"ࠨࠩⓖ")
	if l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ⓗ") in type:
		# next l1l11l1_l1_
		l1lll1l11ll_l1_,data = l1lll1l1ll_l1_(url)
		limit = int(data[l11lll_l1_ (u"ࠪࡰ࡮ࡳࡩࡵࠩⓘ")])
		start = int(data[l11lll_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪⓙ")])
		l11ll1ll1_l1_ = data[l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪⓚ")]
		select = data[l11lll_l1_ (u"࠭ࡳࡦ࡮ࡨࡧࡹ࠭ⓛ")]
		l11ll1l11_l1_ = l11lll_l1_ (u"ࠧ࡭࡫ࡰ࡭ࡹࡃࠧⓜ")+str(limit)+l11lll_l1_ (u"ࠨࠨࡶࡸࡦࡸࡴ࠾ࠩⓝ")+str(start)+l11lll_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࠩⓞ")+l11ll1ll1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡫࡬ࡦࡥࡷࡁࠬⓟ")+select
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪⓠ"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫⓡ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫⓢ"),l1lll1l11ll_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠧࠨⓣ"),l11lll_l1_ (u"ࠨࠩⓤ"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨⓥ"))
		html = response.content
		l11lll1l_l1_ = l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠪⓦ")+html+l11lll_l1_ (u"ࠫࡦࡸࡴࡪࡥ࡯ࡩࠬⓧ")
	else:
		# l11ll1l111_l1_ html
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩⓨ"),url,l11lll_l1_ (u"࠭ࠧⓩ"),l11lll_l1_ (u"ࠧࠨ⓪"),l11lll_l1_ (u"ࠨࠩ⓫"),l11lll_l1_ (u"ࠩࠪ⓬"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⓭"))
		html = response.content
		l11lll1l_l1_ = html
		code = re.findall(l11lll_l1_ (u"ࠦࡁࡹࡣࡳ࡫ࡳࡸࡃ࠮ࡶࡢࡴ࠱࠮ࡄࡃ࠮ࠫࡁ࠾ࡺࡦࡸ࠮ࠫࡁࡀ࠲࠯ࡅ࠻ࡷࡣࡵ࠲࠯ࡅ࠽࠯ࠬࡂ࠿ࡻࡧࡲ࠯ࠬࡂࡁ࠳࠰࠿࠼ࡸࡤࡶ࠳࠰࠿࠾࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠤ⓮"),html,re.DOTALL)
		if code:
			code = code[0].replace(l11lll_l1_ (u"ࠬࡼࡡࡳࠩ⓯"),l11lll_l1_ (u"࠭ࠧ⓰")).replace(l11lll_l1_ (u"ࠧࠡࠩ⓱"),l11lll_l1_ (u"ࠨࠩ⓲")).replace(l11lll_l1_ (u"ࠤࠪࠦ⓳"),l11lll_l1_ (u"ࠪࠫ⓴")).replace(l11lll_l1_ (u"ࠫࡀ࠭⓵"),l11lll_l1_ (u"ࠬࠬࠧ⓶"))
			dummy,data = l1lll1l1ll_l1_(l11lll_l1_ (u"࠭࠿ࠨ⓷")+code)
			limit = int(data[l11lll_l1_ (u"ࠧ࡭࡫ࡰ࡭ࡹ࠭⓸")])
			start = int(data[l11lll_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ⓹")])
			l11ll1ll1_l1_ = data[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⓺")]
			select = data[l11lll_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶࠪ⓻")]
			l1lll11llll_l1_ = data[l11lll_l1_ (u"ࠫࡦࡰࡡࡹࡷࡵࡰࠬ⓼")]
			l11ll1l11_l1_ = l11lll_l1_ (u"ࠬࡲࡩ࡮࡫ࡷࡁࠬ⓽")+str(limit)+l11lll_l1_ (u"࠭ࠦࡴࡶࡤࡶࡹࡃࠧ⓾")+str(start)+l11lll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧ⓿")+l11ll1ll1_l1_+l11lll_l1_ (u"ࠨࠨࡶࡩࡱ࡫ࡣࡵ࠿ࠪ─")+select
			l1lll1l11ll_l1_ = l11ll1_l1_+l1lll11llll_l1_
			l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ━"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ│")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ┃"),l1lll1l11ll_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭┄"),l11lll_l1_ (u"࠭ࠧ┅"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭┆"))
			l11lll1l_l1_ = response.content
			l11lll1l_l1_ = l11lll_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡳࠨ┇")+l11lll1l_l1_+l11lll_l1_ (u"ࠩࡤࡶࡹ࡯ࡣ࡭ࡧࠪ┈")
	items,l1lllll1lll_l1_,filters = [],False,False
	if not type:
		# l1lllll1lll_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭┉"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ┊"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ┋"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┌"),l111ll_l1_+title,link,791,l11lll_l1_ (u"ࠧࠨ┍"),l11lll_l1_ (u"ࠨࡵࡸࡦࡲ࡫࡮ࡶࠩ┎"))
				l1lllll1lll_l1_ = True
	if not type:
		# filter
		filters = l1lll11ll11_l1_(html)
	if not l1lllll1lll_l1_ and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ┏"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ┐"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠫࡡࡴࠧ┑"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧ┒") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┓"),l111ll_l1_+title,link,791,l1llll_l1_)
				elif l11lll_l1_ (u"ࠧๆี็ื้࠭└") in link and l11lll_l1_ (u"ࠨฯ็ๆฮ࠭┕") not in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┖"),l111ll_l1_+title,link,796,l1llll_l1_)
				elif l11lll_l1_ (u"้ࠪํูๅࠨ┗") in link and l11lll_l1_ (u"ࠫา๊โสࠩ┘") not in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┙"),l111ll_l1_+title,link,796,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ┚"),l111ll_l1_+title,link,793,l1llll_l1_)
		# l1lllll11ll_l1_
		length = 12
		data = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࠩ࡮ࡲࡥࡩ࠳࡭ࡰࡴࡨ࠲࠯ࡅࠩ࠽ࠩ┛"),html,re.DOTALL)
		if len(items)==length and (data or l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ├") in type):
			l11ll1l11_l1_ = l11lll_l1_ (u"ࠩ࡯࡭ࡲ࡯ࡴ࠾ࠩ┝")+str(length)+l11lll_l1_ (u"ࠪࠪࡸࡺࡡࡳࡶࡀࠫ┞")+str(start+length)+l11lll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࠫ┟")+l11ll1ll1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡦ࡮ࡨࡧࡹࡃࠧ┠")+select
			l11l11l_l1_ = l1lll1l11ll_l1_+l11lll_l1_ (u"࠭࠿࡯ࡧࡻࡸࡂࡶࡡࡨࡧࠩࠫ┡")+l11ll1l11_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┢"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็้ื๐ฯࠨ┣"),l11l11l_l1_,791,l11lll_l1_ (u"ࠩࠪ┤"),l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࡟ࠨ┥")+type)
	return
def l1lll11ll11_l1_(html):
	filters = False
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ┦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ┧"),block,re.DOTALL)
		if l111l11_l1_: addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ┨"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ┩"),l11lll_l1_ (u"ࠨࠩ┪"),9999)
		for category,name,block in l111l11_l1_:
			name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ┫"))
			# link & value
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ┬"),block,re.DOTALL)
			for link,value in items:
				title = name+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ┭")+value
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┮"),l111ll_l1_+title,link,791,l11lll_l1_ (u"࠭ࠧ┯"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ┰"))
				filters = True
	return filters
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ┱"),url,l11lll_l1_ (u"ࠩࠪ┲"),l11lll_l1_ (u"ࠪࠫ┳"),l11lll_l1_ (u"ࠫࠬ┴"),l11lll_l1_ (u"ࠬ࠭┵"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ┶"))
	html = response.content
	#l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽࡮ࡤࡦࡪࡲ࠾ศๆอู๋๐แ࠽࠱࡯ࡥࡧ࡫࡬࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭┷"),html,re.DOTALL)
	#if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lllll1ll1_l1_ = [],[]
	# l11l1ll1l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲ࠮࡫ࡷࡩࡲ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┸"),html,re.DOTALL)
	for l1lll1l1lll_l1_ in items:
		l1lll1ll1l1_l1_ = base64.b64decode(l1lll1l1lll_l1_)
		if kodi_version>18.99: l1lll1ll1l1_l1_ = l1lll1ll1l1_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ┹"))
		link = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ┺"),l1lll1ll1l1_l1_,re.DOTALL)
		if link:
			link = link[0]
			if link not in l1lllll1ll1_l1_:
				l1lllll1ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ┻"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭┼")+server+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ┽"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡱࡺࡲࡱࡵࡡࡥࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ┾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡶࠥ࡬࡬ࡦࡺ࠰ࡷࡹࡧࡲࡵࠤ࠱࠮ࡄࡂࡤࡪࡸࡁ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰ࠨ࡝ࡦࡾ࠷࠱࠺ࡽࠪ࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮ࡁ࠵ࡤࡪࡸࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┿"),block,re.DOTALL)
		for l11l111l_l1_,link in items:
			if link not in l1lllll1ll1_l1_:
				if l11lll_l1_ (u"ࠩ࠲ࡃࡺࡸ࡬࠾ࠩ╀") in link: link = link.split(l11lll_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ╁"))[1]
				l1lllll1ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ╂"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭╃")+server+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡤࡥࠧ╄")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ╅"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ╆"),url)
	return
def SEARCH():
	# needed for l1lll11lll1_l1_
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᝒ")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ᝓ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ᝔")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l1111l_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l1llllll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭᝕"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩ᝖"),l11lll_l1_ (u"ࠫࠬ᝗"),l11lll_l1_ (u"ࠬ࠭᝘"),l11lll_l1_ (u"࠭ࠧ᝙"),l11lll_l1_ (u"ࠧࠨ᝚"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᝛"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭᝜"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᝝"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ᝞"),l11lll_l1_ (u"ࠬ࠭᝟"),559,l11lll_l1_ (u"࠭ࠧᝠ"),l11lll_l1_ (u"ࠧࠨᝡ"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᝢ"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᝣ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᝤ"),l11lll_l1_ (u"ࠫࠬᝥ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᝦ"),l111ll_l1_+l11lll_l1_ (u"࠭วฯฬิ๊ฬࠦไไࠩᝧ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭ᝨ"),551,l11lll_l1_ (u"ࠨࠩᝩ"),l11lll_l1_ (u"ࠩࠪᝪ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᝫ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᝬ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᝭"),block,re.DOTALL)
	for l1lll1ll11_l1_,title in items:
		link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲࡅࡩࡵࡧࡰࡁࠬᝮ")+l1lll1ll11_l1_+l11lll_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨᝯ")
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᝰ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᝱")+l111ll_l1_+title,link,551)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᝲ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᝳ"),l11lll_l1_ (u"ࠬ࠭᝴"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹ࠱ࡲࡧࡩ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡻࡄࠧ᝵"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᝶"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠨࠥࠪ᝷"): continue
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"่ࠩืู้ไࠡࠩ᝸") in title: continue
		if l11lll_l1_ (u"ࠪวาีหࠨ᝹") in title: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᝺"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᝻")+l111ll_l1_+title,link,551)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᝼"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᝽"),l11lll_l1_ (u"ࠨࠩ᝾"),9999)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠩࠦࠫ᝿"): continue
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪក") in title: continue
		if l11lll_l1_ (u"ࠫศำฯฬࠩខ") not in title: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬគ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨឃ")+l111ll_l1_+title,link,551)
	return
def l1111l_l1_(url,l1lll1ll11_l1_=l11lll_l1_ (u"ࠧࠨង")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩច"),l11lll_l1_ (u"ࠩࠪឆ"),url)
	items = []
	# l1lll1l11l_l1_ l1lll1l1l1_l1_
	if l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪជ") in url or l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬឈ") in url:
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫញ"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ដ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬឋ"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩឌ"),l11lll_l1_ (u"ࠩࠪឍ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩណ"))
		html = response.content
		l1l1ll1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨត"),url,l11lll_l1_ (u"ࠬ࠭ថ"),l11lll_l1_ (u"࠭ࠧទ"),l11lll_l1_ (u"ࠧࠨធ"),l11lll_l1_ (u"ࠨࠩន"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨប"))
		html = response.content
		# l1lll1ll11_l1_ items
		if l1lll1ll11_l1_==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬផ"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫព"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫភ"),block,re.DOTALL)
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧម"),l11lll_l1_ (u"ࠧࠨយ"),l11lll_l1_ (u"ࠨࠩរ"))
		# l1llll1l11_l1_ l111ll11_l1_
		elif l11lll_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠩល") in html:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬវ"),html,re.DOTALL)
		else:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩឝ"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	if not items:
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡴࡸࡩࡨ࡫ࡱࡥࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧឞ"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬស"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧហ"),l11lll_l1_ (u"ࠨใํ่๊࠭ឡ"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨអ"),l11lll_l1_ (u"ࠪ็้๐ศࠨឣ"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪឤ"),l11lll_l1_ (u"ࠬํฯศใࠪឥ"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭ឦ"),l11lll_l1_ (u"ฺࠧำูࠫឧ"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨឨ"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨឩ")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬឪ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧឫ"),title,re.DOTALL)
		if l11lll_l1_ (u"ูࠬไศี็ࠫឬ") not in url and any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬឭ"),l111ll_l1_+title,link,552,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧศๆะ่็ฯࠧឮ") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧឯ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩឰ"),l111ll_l1_+title,link,553,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬឱ") in link:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឲ"),l111ll_l1_+title,link,551,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឳ"),l111ll_l1_+title,link,553,l1llll_l1_)
	if l1lll1ll11_l1_==l11lll_l1_ (u"࠭ࠧ឴"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫ឵"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪា"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠤࠥិ"): continue
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠪࠫី"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឹ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫឺ")+title,link,551)
	if l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ុ") in url or l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨូ") in url:
		if l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨួ") in url:
			url = url.replace(l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩើ"),l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫឿ"))+l11lll_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨៀ")
		elif l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭េ") in url:
			url,offset = url.split(l11lll_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨែ"))
			offset = int(offset)+20
			url = url+l11lll_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩៃ")+str(offset)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨោ"),l111ll_l1_+l11lll_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧៅ"),url,551)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧំ"),url,l11lll_l1_ (u"ࠫࠬះ"),l11lll_l1_ (u"ࠬ࠭ៈ"),l11lll_l1_ (u"࠭ࠧ៉"),l11lll_l1_ (u"ࠧࠨ៊"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ់"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪ៌"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ៍"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭៎") not in url:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៏"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭័"),l111ll_l1_+title,link,553,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭៑"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ្ࠧ"),block,re.DOTALL)
		for link,title in items:
			#title = title.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ៓"),l11lll_l1_ (u"ࠪࠫ។")).strip(l11lll_l1_ (u"ࠫࠥ࠭៕"))
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ៖"),l111ll_l1_+title,link,552,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨៗ"),l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ៘"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ៙"),l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ៚"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ៛"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬៜ"),l11lll_l1_ (u"ࠬ࠭៝"),l11lll_l1_ (u"࠭ࠧ៞"),l11lll_l1_ (u"ࠧࠨ៟"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ០"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭១"))
	l1111_l1_ = []
	# l11l1ll1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ២"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11llll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡵࡳࡵࡋࡇࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ៣"),html,re.DOTALL)
		l11llll1_l1_ = l11llll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲ࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ៤"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ៥"),l11lll_l1_ (u"ࠧࠨ៦")).strip(l11lll_l1_ (u"ࠨࠢࠪ៧"))
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡃࡸ࡫ࡲࡷࡧࡵࡁࠬ៨")+server+l11lll_l1_ (u"ࠪࠪࡵࡵࡳࡵࡋࡇࡁࠬ៩")+l11llll1_l1_+l11lll_l1_ (u"ࠫࠫࡇࡪࡢࡺࡀ࠵ࠬ៪")
				link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭៫")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ៬")
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠢࡨࡧࡷࡔࡱࡧࡹࡦࡴࡅࡽࡓࡧ࡭ࡦ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࡝ࠤࡶࡩࡷࡼࡥࡳ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ៭"),block,re.DOTALL)
			for server,l1lll11lll_l1_,title in items:
				title = title.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ៮"),l11lll_l1_ (u"ࠩࠪ៯")).strip(l11lll_l1_ (u"ࠪࠤࠬ៰"))
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡈࡹࡏࡣࡰࡩࡄࡹࡥࡳࡸࡨࡶࡂ࠭៱")+server+l11lll_l1_ (u"ࠬࠬ࡭ࡶ࡮ࡷ࡭ࡵࡲࡥࡔࡧࡵࡺࡪࡸࡳ࠾ࠩ៲")+l1lll11lll_l1_+l11lll_l1_ (u"࠭ࠦࡱࡱࡶࡸࡎࡊ࠽ࠨ៳")+l11llll1_l1_+l11lll_l1_ (u"ࠧࠧࡃ࡭ࡥࡽࡃ࠱ࠨ៴")
				link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ៵")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ៶")
				l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡵࡷ࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ៷"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ៸"),block,re.DOTALL)
		for link,name in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭៹")+name+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ៺")
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ៻") not in link: link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ៼")+link
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ៽"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ៾"),url)
	return
l11lll_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡕࡒࡁ࡚ࡡࡒࡐࡉ࠮ࡵࡳ࡮ࠬ࠾ࠏࠏࡤࡢࡶࡤࠤࡂࠦࡻࠨࡘ࡬ࡩࡼ࠭࠺࠲ࡿࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ࠼ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩࢀࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠮ࡧࡥࡹࡧࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࡡࠏࠏࠣࠡࡹࡤࡸࡨ࡮ࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡷࡢࡶࡦ࡬ࡆࡸࡥࡢࡏࡤࡷࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫࠏࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠧࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࡭࡫ࡱ࡯ࡸࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡤࡰࡰࡺࡰࡴࡧࡤ࠮ࡵࡨࡶࡻ࡫ࡲࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡶࡩࡷ࠳࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡵࡺࡧ࡬ࡪࡶࡼ࠰ࡱ࡯࡮࡬ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡱࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ࠯ࠬࡥ࡟ࡠࡡࠪ࠯ࡶࡻࡡ࡭࡫ࡷࡽࠏࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠧࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ࠮࡯࡭ࡳࡱࡌࡊࡕࡗ࠭ࠏࠏࡩࡧࠢ࡯ࡩࡳ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪ࠿ࡀ࠴࠿ࠦࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࠲ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐็ࠡใํำ๏๎ࠧࠪࠌࠌࡩࡱࡹࡥ࠻ࠌࠌࠍ࡮ࡳࡰࡰࡴࡷࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠊࠊࠋࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࠧࡷ࡫ࡧࡩࡴ࠭ࠬࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤ៿")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭᠀"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ᠁"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ᠂"),l11lll_l1_ (u"ࠨ࠯ࠪ᠃"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ᠄")+search+l11lll_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ᠅")
	l1111l_l1_(url)
	return
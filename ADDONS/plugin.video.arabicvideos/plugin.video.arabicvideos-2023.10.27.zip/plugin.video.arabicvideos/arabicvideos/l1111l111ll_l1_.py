# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࠲ࡵࡧ࡮ࡦࡶ࠱ࡧࡴ࠴ࡩ࡭ࠩ咀")
headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ咁"):l11lll_l1_ (u"ࠫࠬ咂")}
script_name = l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ咃")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ咄")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11lll_l1_ (u"ࠧ࠴ࠩ咅"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11lll_l1_ (u"ࠨ࠳ࠪ咆"))
	elif mode==36: results = CATEGORIES(url,l11lll_l1_ (u"ࠩ࠵ࠫ咇"))
	elif mode==37: results = CATEGORIES(url,l11lll_l1_ (u"ࠪ࠸ࠬ咈"))
	elif mode==38: results = l1l1lll1l_l1_()
	elif mode==39: results = SEARCH(text,l1l11l1_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ咉"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ咊"),l11lll_l1_ (u"࠭ࠧ咋"),39,l11lll_l1_ (u"ࠧࠨ和"),l11lll_l1_ (u"ࠨࠩ咍"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭咎"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ咏"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ咐"),l11lll_l1_ (u"ࠬ࠭咑"),9999)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ咒"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ咓")+l111ll_l1_+l11lll_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ咔"),l11lll_l1_ (u"ࠩࠪ咕"),38)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ咖"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭咗")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯ่ࠦษำส้ั࠭咘"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ咙"),31)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ咚"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ咛")+l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไศๅฮี๋ࠥิศ้าอࠬ咜"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ咝"),37)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ咞"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ咟")+l111ll_l1_+l11lll_l1_ (u"࠭วโๆส้ࠥำำษࠢส่๋๎ูࠨ咠"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ咡"),35)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ咢"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ咣")+l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠢะือࠦวๅ็่ฯ้࠭咤"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ咥"),36)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ咦"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ咧")+l111ll_l1_+l11lll_l1_ (u"ࠧศฯาฯࠥอไศใ็ห๊࠭咨"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ咩"),32)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ咪"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ咫")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫัฮ์สฮࠬ咬"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡧࡦࡰࡵࡩ࠴࠺࠯࠲ࠩ咭"),32)
	return l11lll_l1_ (u"࠭ࠧ咮")
def CATEGORIES(url,select=l11lll_l1_ (u"ࠧࠨ咯")):
	type = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ咰"))[3]
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ咱"),l11lll_l1_ (u"ࠪࠫ咲"),type, url)
	if type==l11lll_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ咳"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭咴"),headers,l11lll_l1_ (u"࠭ࠧ咵"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ咶"))
		if select==l11lll_l1_ (u"ࠨ࠵ࠪ咷"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸࡓࡥ࡯ࡷࠫ࠲࠯ࡅࠩࡴࡧࡵ࡭ࡪࡹࡆࡰࡴࡰࠫ咸"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ咹"),block,re.DOTALL)
			for link,name in items:
				if l11lll_l1_ (u"่๊๊ࠫษษอࠤ๊฼อไหࠪ咺") in name: continue
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ咻"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭咼"),l111ll_l1_+name,url,32)
		if select==l11lll_l1_ (u"ࠧ࠵ࠩ咽"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡥࡧࡷࡥ࡮ࡲࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡻࡄ࠼࠰ࡣࡁࡀ࠴ࡪࡩࡷࡀࠪ咾"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ咿"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				url = l11ll1_l1_ + link
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ哀"))
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ品"),l111ll_l1_+title,url,32,l1llll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭哂"),l11lll_l1_ (u"࠭ࠧ哃"),url,l11lll_l1_ (u"ࠧࠨ哄"))
	if type==l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ哅"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ哆"),headers,l11lll_l1_ (u"ࠪࠫ哇"),l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠳ࡰࡧࠫ哈"))
		if select==l11lll_l1_ (u"ࠬ࠷ࠧ哉"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡍࡥ࡯ࡦࡨࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ哊"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ哋"),block,re.DOTALL)
			for value,name in items:
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰ࠩ哌") + value
				name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ响"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ哎"),l111ll_l1_+name,url,32)
		elif select==l11lll_l1_ (u"ࠫ࠷࠭哏"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡆࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡴࡧ࡯ࡩࡨࡺࠧ哐"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ哑"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ哒"))
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡤࡧࡹࡵࡲ࠰ࠩ哓") + value
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ哔"),l111ll_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ哕"),l11lll_l1_ (u"ࠫࠬ哖"),url,l11lll_l1_ (u"ࠬ࠭哗"))
	type = url.split(l11lll_l1_ (u"࠭࠯ࠨ哘"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ哙"),headers,l11lll_l1_ (u"ࠨࠩ哚"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ哛"))
	if l11lll_l1_ (u"ࠪ࡬ࡴࡳࡥࠨ哜") in url: type=l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭哝")
	if type==l11lll_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ哞"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠪ࠱࠮ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ哟"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ哠"),block,re.DOTALL)
			for link,l1llll_l1_,name in items:
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ員"))
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ哢"),l111ll_l1_+name,url,32,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ哣"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ哤"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠰ࡅࠩࠣࠩ哥"),block,re.DOTALL)
		for link,l1llll_l1_,name in items:
			name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ哦"))
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭哧"),l111ll_l1_+name,url,33,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ哨"):
		l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ哩"))[-1]
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ哪"),l11lll_l1_ (u"ࠫࠬ哫"),url,l11lll_l1_ (u"ࠬ࠭哬"))
		if l1l11l1_l1_==l11lll_l1_ (u"࠭࠱ࠨ哭"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷࠬ哮"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࠩ哯"),block,re.DOTALL)
			count = 0
			for link,l1llll_l1_,l1lll11_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭哰") + l1lll11_l1_
				url = l11ll1_l1_ + link
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ哱"),l111ll_l1_+name,url,33,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳ࠯ࠬࡂࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ哲"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷࠭哳"),block,re.DOTALL)
		for link,l1llll_l1_,title,l1lll11_l1_ in items:
			l1lll11_l1_ = l1lll11_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ哴"))
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ哵"))
			name = title + l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ哶") + l1lll11_l1_
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ哷"),l111ll_l1_+name,url,33,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡫ࡱࡿࡰࡩ࡫ࡦࡳࡳ࠳ࡣࡩࡧࡹࡶࡴࡴ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠬࡁࠬࡨࡦࡺࡡ࠮ࡴࡨࡺ࡮ࡼࡥ࠮ࡼࡲࡲࡪ࡯ࡤ࠾ࠤ࠷ࠦࠬ哸"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ哹"),block,re.DOTALL)
	for link,l1l11l1_l1_ in items:
		url = l11ll1_l1_ + link
		name = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ哺") + l1l11l1_l1_
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭哻"),l111ll_l1_+name,url,32)
	return
def PLAY(url):
	if l11lll_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ哼") in url:
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࡶ࠲࠱ࡶࡩࡷ࡯ࡥࡴࡎ࡬ࡲࡰ࠵ࠧ哽") + url.split(l11lll_l1_ (u"ࠩ࠲ࠫ哾"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ哿"),url,l11lll_l1_ (u"ࠫࠬ唀"),headers,l11lll_l1_ (u"ࠬ࠭唁"),l11lll_l1_ (u"࠭ࠧ唂"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ唃"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠨࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ唄"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11lll_l1_ (u"ࠩ࡟࠳ࠬ唅"),l11lll_l1_ (u"ࠪ࠳ࠬ唆"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ唇"),url,l11lll_l1_ (u"ࠬ࠭唈"),headers,l11lll_l1_ (u"࠭ࠧ唉"),l11lll_l1_ (u"ࠧࠨ唊"),l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ唋"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ唌"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ唍"))
	return
def SEARCH(search,l1l11l1_l1_=l11lll_l1_ (u"ࠫࠬ唎")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ唏"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ唐"))
	l1ll1111l_l1_ = [l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ唑"),l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ唒")]
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠩ࠴ࠫ唓")
	else: l1l11l1_l1_,type = l1l11l1_l1_.split(l11lll_l1_ (u"ࠪ࠳ࠬ唔"))
	if l1ll_l1_:
		l1l11l1ll_l1_ = [ l11lll_l1_ (u"ࠫอำหࠡ฻้ࠤฬ็ไศ็ࠪ唕") , l11lll_l1_ (u"ࠬฮอฬࠢ฼๊๋ࠥำๅี็หฯ࠭唖")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣ࠱ࠥอฮหำࠣห้ฮอฬࠩ唗"), l1l11l1ll_l1_)
		if l1l_l1_ == -1 : return
		type = l1ll1111l_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠧࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨ唘") in options: type = l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ唙")
		elif l11lll_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࡡࠪ唚") in options: type = l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ唛")
		else: return
	headers[l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ唜")] = l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ唝")
	data = {l11lll_l1_ (u"࠭ࡱࡶࡧࡵࡽࠬ唞"):l111l1l_l1_ , l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡄࡰ࡯ࡤ࡭ࡳ࠭唟"):type}
	if l1l11l1_l1_!=l11lll_l1_ (u"ࠨ࠳ࠪ唠"): data[l11lll_l1_ (u"ࠩࡩࡶࡴࡳࠧ唡")] = l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ唢"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ唣"),data,headers,l11lll_l1_ (u"ࠬ࠭唤"),l11lll_l1_ (u"࠭ࠧ唥"),l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ唦"))
	html = response.content
	items=re.findall(l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ唧"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l11ll1_l1_ + link.replace(l11lll_l1_ (u"ࠩ࡟࠳ࠬ唨"),l11lll_l1_ (u"ࠪ࠳ࠬ唩"))
			if l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭唪") in url: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ唫"),l111ll_l1_+l11lll_l1_ (u"࠭แ๋ๆ่ࠤࠬ唬")+title,url,33)
			elif l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ唭") in url:
				url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ售"),l11lll_l1_ (u"ࠩ࠲ࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺ࠯ࠨ唯"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唰"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆࠣࠫ唱")+title,url+l11lll_l1_ (u"ࠬ࠵࠱ࠨ唲"),32)
	count=re.findall(l11lll_l1_ (u"࠭ࠢࡵࡱࡷࡥࡱࠨ࠺ࠩ࠰࠭ࡃ࠮ࢃࠧ唳"),html,re.DOTALL)
	if count:
		l1l1ll11l_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll11l1l_l1_ in range(1,l1l1ll11l_l1_):
			l1ll11l1l_l1_ = str(l1ll11l1l_l1_)
			if l1ll11l1l_l1_!=l1l11l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ唴"),l11lll_l1_ (u"ࠨืไัฮࠦࠧ唵")+l1ll11l1l_l1_,l11lll_l1_ (u"ࠩࠪ唶"),39,l11lll_l1_ (u"ࠪࠫ唷"),l1ll11l1l_l1_+l11lll_l1_ (u"ࠫ࠴࠭唸")+type,search)
	return
def l1l1lll1l_l1_():
	link = l11lll_l1_ (u"ࠬࡧࡈࡓ࠲ࡦࡈࡴࡼࡌ࠳ࡦࡽࡨࡍࡐ࡬࡚࡙࠳࠴ࡑࡴࡂࡩࡤࡰ࡚࠵ࡒ࡭ࡏࡸࡏࡱࡱࡹࡌ࠳ࡘ࡮࡞࠷࡜ࡦ࡚࡙ࡍࡽࡑ࠸ࡨࡩࡤࡊࡊ࡚࡜ࡩ࠺ࡹࡥࡋࡋ࠻ࡢࡈ࡮ࡽࡨࡈ࠻ࡴࡎ࠵ࡘ࠸ࠬ唹")
	link = base64.b64decode(link)
	link = link.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ唺"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ唻"))
	return
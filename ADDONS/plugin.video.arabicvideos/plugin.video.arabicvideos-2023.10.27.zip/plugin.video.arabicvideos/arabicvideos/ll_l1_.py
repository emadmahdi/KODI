# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ堬")
#l1111ll1l1l1_l1_ = [ l11lll_l1_ (u"ࠬࡳࡹࡴࡶࡵࡩࡦࡳࠧ堭"),l11lll_l1_ (u"࠭ࡶࡪ࡯ࡳࡰࡪ࠭堮"),l11lll_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡳࠧ堯"),l11lll_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭堰") ]
l1111ll1l1l1_l1_ = []
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭報"):l11lll_l1_ (u"ࠪࠫ堲")}
def l11_l1_(l1lllll1_l1_,source,type,url):
	#DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่ึอศุࠢส่๊์วิสࠪ堳"),l1lllll1_l1_)
	if not l1lllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ場"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭堵")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨ堶")+type+l11lll_l1_ (u"ࠨࠢࡠࠫ堷"))
		l111l1ll1111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ堸"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭堹"),l11lll_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ堺"))
		datetime = time.strftime(l11lll_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭堻"),time.gmtime(now))
		line = datetime,url
		key = source+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ堼")+l11l1llllll_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠬ堽")+str(kodi_version)
		message = l11lll_l1_ (u"ࠨࠩ堾")
		if key not in list(l111l1ll1111_l1_.keys()): l111l1ll1111_l1_[key] = [line]
		else:
			if url not in str(l111l1ll1111_l1_[key]): l111l1ll1111_l1_[key].append(line)
			else: message = l11lll_l1_ (u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧ堿")
		total = 0
		for key in list(l111l1ll1111_l1_.keys()):
			l111l1ll1111_l1_[key] = list(set(l111l1ll1111_l1_[key]))
			total += len(l111l1ll1111_l1_[key])
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ塀"),l11lll_l1_ (u"ࠫࠬ塁"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ塂"),l11lll_l1_ (u"࠭ไๅลึๅࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ塃")+message+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲ๊ࠥไฺๆ่ࠤฬ๊ศา่ส้ั๊ࠦใ๊่ࠤอาๅฺࠢๅหห๋ษࠡสส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋๋ࠠฮาࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํ่ࠦิ๊ไࠤ๏฿ัืࠢ฼่๏้ࠠศๆหี๋อๅอࠢฦ๊ࠥะัิๆ๋ࠣีํࠠศๆๅหห๋ษࠡว็ํࠥอไๆสิ้ัูࠦ็ั่หࠥ๐ีษฯࠣ฽ิี็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯ࠭塄")+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭塅")+l11lll_l1_ (u"ࠩ฼ำิࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦวๅไสส๊ฯࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠬ塆")+str(total))
		if total>=5:
			l1ll11l111_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ塇"),l11lll_l1_ (u"ࠫࠬ塈"),l11lll_l1_ (u"ࠬ࠭塉"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ塊"),l11lll_l1_ (u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨ塋"))
			if l1ll11l111_l1_==1:
				l111l1ll11l1_l1_ = l11lll_l1_ (u"ࠨࠩ塌")
				for key in list(l111l1ll1111_l1_.keys()):
					l111l1ll11l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ塍")+key
					l1lllll1l1111_l1_ = sorted(l111l1ll1111_l1_[key],reverse=False,key=lambda l11ll1l1ll1l_l1_: l11ll1l1ll1l_l1_[0])
					for datetime,url in l1lllll1l1111_l1_:
						l111l1ll11l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭塎")+datetime+l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠩ塏")+l111l_l1_(url)
					l111l1ll11l1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ塐")
				import l11ll1ll1l1_l1_
				succeeded = l11ll1ll1l1_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"࠭ࡖࡪࡦࡨࡳࡸ࠭塑"),l11lll_l1_ (u"ࠧࠨ塒"),False,l11lll_l1_ (u"ࠨࠩ塓"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭塔"),l11lll_l1_ (u"ࠪࠫ塕"),l111l1ll11l1_l1_)
				if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ塖"),l11lll_l1_ (u"ࠬ࠭塗"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ塘"),l11lll_l1_ (u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ塙"))
				else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ塚"),l11lll_l1_ (u"ࠩࠪ塛"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭塜"),l11lll_l1_ (u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩ塝"))
			if l1ll11l111_l1_!=-1:
				l111l1ll1111_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ塞"),l11lll_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ塟"))
		if l111l1ll1111_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ塠"),l11lll_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ塡"),l111l1ll1111_l1_,PERMANENT_CACHE)
		return
	l1lllll1_l1_ = list(set(l1lllll1_l1_))
	l1lll1ll_l1_,l1111_l1_ = l1llllll11lll_l1_(l1lllll1_l1_,source)
	l1lllll11lll1_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ塢"))
	l1llllll1ll11_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ塣"))
	l1lllll1l11l1_l1_ = len(l1111_l1_)-l1lllll11lll1_l1_-l1llllll1ll11_l1_
	l1lllllll1l1l_l1_ = l11lll_l1_ (u"ฺ๊ࠫว่ัฬ࠾ࠬ塤")+str(l1lllll11lll1_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠢอั๊๐ไ࠻ࠩ塥")+str(l1llllll1ll11_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠣวำื้࠻ࠩ塦")+str(l1lllll1l11l1_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ塧"),l11lll_l1_ (u"ࠨࠩ塨"),str(l1lllll11lll1_l1_),str(l1llllll1ll11_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1lllllll1l1l_l1_, l1111_l1_)
	if not l1111_l1_: result,l111llll1lll_l1_ = l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭塩"),l11lll_l1_ (u"ࠪࠫ塪")
	else:
		while True:
			l111llll1lll_l1_ = l11lll_l1_ (u"ࠫࠬ填")
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1lllllll1l1l_l1_,l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ塬")
			else:
				title = l1lll1ll_l1_[l1l_l1_]
				link = l1111_l1_[l1l_l1_]
				#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ塭"),l11lll_l1_ (u"ࠧࠨ塮"),title,link)
				if l11lll_l1_ (u"ࠨีํีๆืࠧ塯") in title and l11lll_l1_ (u"ࠩ࠵้ัํ่ๅ࠴ࠪ塰") in title:
					LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ塱"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ塲")+title+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ塳")+link+l11lll_l1_ (u"࠭ࠠ࡞ࠩ塴"))
					import l11ll1ll1l1_l1_
					l11ll1ll1l1_l1_.MAIN(156)
					result = l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ塵")
				else:
					LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ塶"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡕࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧ塷")+title+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ塸")+link+l11lll_l1_ (u"ࠫࠥࡣࠧ塹"))
					result,l111llll1lll_l1_,l11l1l1llll1_l1_ = l11111111111_l1_(link,source,type)
					#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭塺"),l11lll_l1_ (u"࠭ࠧ塻"),result,l111llll1lll_l1_)
			if l11lll_l1_ (u"ࠧ࡝ࡰࠪ塼") not in l111llll1lll_l1_: l111lll11111_l1_,l111l1ll1ll_l1_ = l111llll1lll_l1_,l11lll_l1_ (u"ࠨࠩ塽")
			else: l111lll11111_l1_,l111l1ll1ll_l1_ = l111llll1lll_l1_.split(l11lll_l1_ (u"ࠩ࡟ࡲࠬ塾"),1)
			if result in [l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ塿"),l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭墀"),l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭墁"),l11lll_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ墂")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ境"),l11lll_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ墄"),l11lll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ墅")]: break
			elif result not in [l11lll_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ墆"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ墇")]: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭墈"),l11lll_l1_ (u"࠭ࠧ墉"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ墊"),l11lll_l1_ (u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࠫ墋")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ墌")+l111lll11111_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭墍")+l111l1ll1ll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ墎"),l11lll_l1_ (u"ࠬ࠭墏"),l11lll_l1_ (u"࠭ࠧ墐"),str(l11l1l1llll1_l1_))
	if result==l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ墑") and len(l1lll1ll_l1_)>0: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ墒"),l11lll_l1_ (u"ࠩࠪ墓"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭墔"),l11lll_l1_ (u"ุࠫ๐ัโำ๋ࠣีอࠠศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦแ๋ัํ์ࠥเ๊า้ࠪ墕")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ墖")+l111llll1lll_l1_)
	elif result in [l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭増"),l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ墘")] and l111llll1lll_l1_!=l11lll_l1_ (u"ࠨࠩ墙"): DIALOG_OK(l11lll_l1_ (u"ࠩࠪ墚"),l11lll_l1_ (u"ࠪࠫ墛"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ墜"),l111llll1lll_l1_)
	#elif l111llll1lll_l1_==l11lll_l1_ (u"ࠬࡘࡅࡕࡗࡕࡒࡤ࡚ࡏࡠ࡛ࡒ࡙࡙࡛ࡂࡆࠩ墝"): result = l11l1l1llll1_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡱࠤࡠ࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ࠰ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩࡠ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࡗࡩࡸࡺ࠺ࠡࠢࠣࠫ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠱࡟࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠸࡝ࠪࠌࠌࠍࡽࡨ࡭ࡤࡲ࡯ࡹ࡬࡯࡮࠯ࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࡤࡨࡩࡵ࡮ࡠࡪࡤࡲࡩࡲࡥ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠢࡻࡦࡲࡩࡧࡶ࡫࠱ࡐ࡮ࡹࡴࡊࡶࡨࡱ࠭࠯ࠩࠋࠋࠌࡴࡱࡧࡹࡠ࡫ࡷࡩࡲࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬࡵࡧࡴࡩ࠿ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠲ࡃࡲࡵࡤࡦ࠿࠴࠸࠸ࠬࡵࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࠪ࠹ࡆࡷࠧ࠶ࡈ࡬ࡽࡢ࠲ࡲࡻ࡚ࡹࡽ࠹ࡒࠩࠬࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡰ࡭ࡣࡼࠬࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࡭ࡸ࠴࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰࡫ࡳ࡬ࡴࡴࡥ࠰࠳࠵࠷࠹࠺࠷࠯࡯ࡳ࠸ࠬ࠲ࡰ࡭ࡣࡼࡣ࡮ࡺࡥ࡮ࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไศๆ฽หฦ࠭ࠬࠨࠩࠬࠎࠎࠨࠢࠣ增")
	return result
	#if source==l11lll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ墟"): l111ll_l1_ = l11lll_l1_ (u"ࠨࡊࡏࡅࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ墠")
	#elif source==l11lll_l1_ (u"ࠩ࠷ࡌࡊࡒࡁࡍࠩ墡"): l111ll_l1_ = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡎࡅࡍࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ墢")
	#elif source==l11lll_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ墣"): l111ll_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡂࡍࡐࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭墤")
	#elif source==l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ墥"): l111ll_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡖࡌ࠹ࠦࠧ墦")
	#size = len(l1ll1lll11_l1_)
	#for i in range(0,size):
	#	title = l111llll1l1l_l1_[i]
	#	link = l1ll1lll11_l1_[i]
	#	addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ墧"),l111ll_l1_+title,link,160,l11lll_l1_ (u"ࠩࠪ墨"),l11lll_l1_ (u"ࠪࠫ墩"),source)
def l11111111111_l1_(url,source,type=l11lll_l1_ (u"ࠫࠬ墪")):
	url = url.strip(l11lll_l1_ (u"ࠬࠦࠧ墫")).strip(l11lll_l1_ (u"࠭ࠦࠨ墬")).strip(l11lll_l1_ (u"ࠧࡀࠩ墭")).strip(l11lll_l1_ (u"ࠨ࠱ࠪ墮"))
	l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1lllll1_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ墯"),l11lll_l1_ (u"ࠪࠫ墰"),url,l111llll1lll_l1_)
	if l111llll1lll_l1_==l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ墱"): return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_:
		while True:
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ墲"), l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ墳")
			else:
				l11111lllll1_l1_ = l1111_l1_[l1l_l1_]
				title = l1lll1ll_l1_[l1l_l1_]
				LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ墴"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫ࠥࡹࡥ࡭ࡧࡦࡸࡪࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ墵")+title+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ墶")+str(l11111lllll1_l1_)+l11lll_l1_ (u"ࠪࠤࡢ࠭墷"))
				if l11lll_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ墸") in l11111lllll1_l1_ and l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ墹") in l11111lllll1_l1_:
					l1111l1lll1l_l1_,l11l1l1l1ll1_l1_,l11l1l1llll1_l1_ = l111ll111111_l1_(l11111lllll1_l1_)
					if l11l1l1llll1_l1_: l11111lllll1_l1_ = l11l1l1llll1_l1_[0]
					else: l11111lllll1_l1_ = l11lll_l1_ (u"࠭ࠧ墺")
				if not l11111lllll1_l1_: result = l11lll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ墻")
				else: result = PLAY_VIDEO(l11111lllll1_l1_,source,type)
			if result in [l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ墼"),l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭墽")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ墾"),l11lll_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ墿"),l11lll_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ壀")]: break
			else: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ壁"),l11lll_l1_ (u"ࠧࠨ壂"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ壃"),l11lll_l1_ (u"ࠩส่๊๊แࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦๅๅใࠣ฾๏ื็ࠨ壄"))
	else:
		result = l11lll_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ壅")
		l111llll11_l1_ = l11l1llll1_l1_(url)
		if l111llll11_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l111llll1lll_l1_,l1111_l1_
	#title = xbmc.getInfoLabel( l11lll_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ壆") )
	#if l11lll_l1_ (u"ู๊ࠬาใิࠤ฾อๅࠡ็ฯ๋ํ๊ࠧ壇") in title:
	#	import l11ll1ll1l1_l1_
	#	l11ll1ll1l1_l1_.MAIN(156)
	#	return l11lll_l1_ (u"࠭ࠧ壈")
def l1llll1l11ll1_l1_(url,source):
	# url = url+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ壉")+name+l11lll_l1_ (u"ࠨࡡࡢࠫ壊")+type+l11lll_l1_ (u"ࠩࡢࡣࠬ壋")+l1l1111_l1_+l11lll_l1_ (u"ࠪࡣࡤ࠭壌")+l11l111l_l1_
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺ࠿࡯ࡣࡰࡩࡩࡃࡡ࡬ࡹࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣ࠼࠸࠰ࠨ壍")
	l11l11l_l1_,l111ll11ll11_l1_,server,l1111l11l111_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = url,l11lll_l1_ (u"ࠬ࠭壎"),l11lll_l1_ (u"࠭ࠧ壏"),l11lll_l1_ (u"ࠧࠨ壐"),l11lll_l1_ (u"ࠨࠩ壑"),l11lll_l1_ (u"ࠩࠪ壒"),l11lll_l1_ (u"ࠪࠫ壓"),l11lll_l1_ (u"ࠫࠬ壔")
	#source = source.lower()
	if l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭壕") in url:
		l11l11l_l1_,l111ll11ll11_l1_ = url.split(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ壖"),1)
		l111ll11ll11_l1_ = l111ll11ll11_l1_+l11lll_l1_ (u"ࠧࡠࡡࠪ壗")+l11lll_l1_ (u"ࠨࡡࡢࠫ壘")+l11lll_l1_ (u"ࠩࡢࡣࠬ壙")+l11lll_l1_ (u"ࠪࡣࡤ࠭壚")
		l111ll11ll11_l1_ = l111ll11ll11_l1_.lower()
		name,type,l1l1111_l1_,l11l111l_l1_,l1lll11lllll_l1_ = l111ll11ll11_l1_.split(l11lll_l1_ (u"ࠫࡤࡥࠧ壛"))[:5]
	if l11l111l_l1_==l11lll_l1_ (u"ࠬ࠭壜"): l11l111l_l1_ = l11lll_l1_ (u"࠭࠰ࠨ壝")
	else: l11l111l_l1_ = l11l111l_l1_.replace(l11lll_l1_ (u"ࠧࡱࠩ壞"),l11lll_l1_ (u"ࠨࠩ壟")).replace(l11lll_l1_ (u"ࠩࠣࠫ壠"),l11lll_l1_ (u"ࠪࠫ壡"))
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠫࡄ࠭壢")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ壣")).strip(l11lll_l1_ (u"࠭ࠦࠨ壤"))
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠧࡩࡱࡶࡸࠬ壥"))
	if name: l1111l11l111_l1_ = name
	#elif source: l1111l11l111_l1_ = source
	else: l1111l11l111_l1_ = server
	l1111l11l111_l1_ = SERVER(l1111l11l111_l1_,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭壦"))
	name = name.replace(l11lll_l1_ (u"่ࠩฬฬฺัࠨ壧"),l11lll_l1_ (u"ࠪࠫ壨")).replace(l11lll_l1_ (u"ุࠫ๐ัโำࠪ壩"),l11lll_l1_ (u"ࠬ࠭壪")).replace(l11lll_l1_ (u"࠭วๅࠢࠪ士"),l11lll_l1_ (u"ࠧࠡࠩ壬")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ壭"),l11lll_l1_ (u"ࠩࠣࠫ壮"))
	l111ll11ll11_l1_ = l111ll11ll11_l1_.replace(l11lll_l1_ (u"้ࠪออิาࠩ壯"),l11lll_l1_ (u"ࠫࠬ声")).replace(l11lll_l1_ (u"ู๊ࠬาใิࠫ壱"),l11lll_l1_ (u"࠭ࠧ売")).replace(l11lll_l1_ (u"ࠧศๆࠣࠫ壳"),l11lll_l1_ (u"ࠨࠢࠪ壴")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ壵"),l11lll_l1_ (u"ࠪࠤࠬ壶"))
	l1111l11l111_l1_ = l1111l11l111_l1_.replace(l11lll_l1_ (u"๊ࠫฮวีำࠪ壷"),l11lll_l1_ (u"ࠬ࠭壸")).replace(l11lll_l1_ (u"࠭ำ๋ำไีࠬ壹"),l11lll_l1_ (u"ࠧࠨ壺")).replace(l11lll_l1_ (u"ࠨษ็ࠤࠬ壻"),l11lll_l1_ (u"ࠩࠣࠫ壼")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭壽"),l11lll_l1_ (u"ࠫࠥ࠭壾"))
	return l11l11l_l1_,l111ll11ll11_l1_,server,l1111l11l111_l1_,name,type,l1l1111_l1_,l11l111l_l1_
def l111lll1llll_l1_(url,source):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭壿"),l11lll_l1_ (u"࠭ࠧ夀"),url,l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ夁"))
	# l1lll1ll1_l1_	: سيرفر خاص
	# l111ll1ll11l_l1_		: سيرفر محدد
	# l111ll11l1l1_l1_		: سيرفر عام معروف
	# l1ll1ll11_l1_	: سيرفر عام خارجي
	# l1lllll1l1ll1_l1_	: سيرفر عام خارجي
	l11111ll1ll1_l1_,name,l1lll1ll1_l1_,l111ll11l1l1_l1_,l1ll1ll11_l1_,l111ll1ll11l_l1_,l1lllll1l1ll1_l1_ = l11lll_l1_ (u"ࠨࠩ夂"),l11lll_l1_ (u"ࠩࠪ夃"),None,None,None,None,None
	l11l11l_l1_,l111ll11ll11_l1_,server,l1111l11l111_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l1llll1l11ll1_l1_(url,source)
	if l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ处") in url:
		if   type==l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦࠪ夅"): type = l11lll_l1_ (u"ࠬࠦࠧ夆")+l11lll_l1_ (u"࠭ๅโุ็ࠫ备")
		elif type==l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭夈"): type = l11lll_l1_ (u"ࠨࠢࠪ変")+l11lll_l1_ (u"ࠩࠨู้อ็ะหࠪ夊")
		elif type==l11lll_l1_ (u"ࠪࡦࡴࡺࡨࠨ夋"): type = l11lll_l1_ (u"ࠫࠥ࠭夌")+l11lll_l1_ (u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ复")
		elif type==l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ夎"): type = l11lll_l1_ (u"ࠧࠡࠩ夏")+l11lll_l1_ (u"ࠨࠧࠨࠩฯำๅ๋ๆࠪ夐")
		elif type==l11lll_l1_ (u"ࠩࠪ夑"): type = l11lll_l1_ (u"ࠪࠤࠬ夒")+l11lll_l1_ (u"ࠫࠪࠫࠥࠦࠩ夓")
		if l1l1111_l1_!=l11lll_l1_ (u"ࠬ࠭夔"):
			if l11lll_l1_ (u"࠭࡭ࡱ࠶ࠪ夕") not in l1l1111_l1_: l1l1111_l1_ = l11lll_l1_ (u"ࠧࠦࠩ外")+l1l1111_l1_
			l1l1111_l1_ = l11lll_l1_ (u"ࠨࠢࠪ夗")+l1l1111_l1_
		if l11l111l_l1_!=l11lll_l1_ (u"ࠩࠪ夘"):
			l11l111l_l1_ = l11lll_l1_ (u"ࠪࠩࠪࠫࠥࠦࠧࠨࠩࠪ࠭夙")+l11l111l_l1_
			l11l111l_l1_ = l11lll_l1_ (u"ࠫࠥ࠭多")+l11l111l_l1_[-9:]
	#if any(value in server for value in l1111ll1l1l1_l1_): return l11lll_l1_ (u"ࠬ࠭夛")
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ夜"),l11lll_l1_ (u"ࠧࠨ夝"),name,l1111l11l111_l1_)
	if   l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ夞")		in source: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ够")		in source: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ夠")
	elif l11lll_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭夡")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫ࠧ夢")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬ夣")	in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡴࡧࡨࡩࡪࡪࠧ夤")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ夥")
	#elif l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ夦") in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ大")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ夨")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	#elif l11lll_l1_ (u"ࠬࡶࡣࡳࡧࡹ࡭ࡪࡽࠧ天")	in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ太")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ夫")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ夬")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ夭")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ央")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ夯")	in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ夰")
	elif l11lll_l1_ (u"࠭แอำࠪ失")			in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭夲")
	elif l11lll_l1_ (u"ࠨใ็ื฼๐ๆࠨ夳")		in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬ头")
	elif l11lll_l1_ (u"ࠪ࡫ࡩࡸࡩࡷࡧࠪ夵")		in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ夶")
	elif l11lll_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ夷")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭夸")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ夹")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ夺")		in name:   l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ夻")	in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ夼")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ夽")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ夾")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ夿")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ奀")		in server: l1lll1ll1_l1_	= l1111l11l111_l1_
	#elif l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸ࠰ࡱࡩࡹ࠭奁")	in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࠣࠫ奂")
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ奃")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭奄")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬ奅")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭奆")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩ奇")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ奈")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ奉")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ奊")
	elif l11lll_l1_ (u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ奋")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭奌")
	elif l11lll_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ奍")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫ奎")
	elif l11lll_l1_ (u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ奏")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ奐")
	elif l11lll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ契")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭奒")
	#elif l11lll_l1_ (u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧ奓")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ奔")
	elif l11lll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ奕")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ奖")
	elif l11lll_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ套")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ奘")
	elif l11lll_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ奙")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱࠬ奚")
	elif l11lll_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ奛")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ奜")
	elif l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ奝")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ奞")
	elif l11lll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ奟")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ奠")
	elif l11lll_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ奡")	 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"࠭ࡣࡢࡶࡦ࡬ࠬ奢")
	elif l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ奣")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ奤")
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ奥")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ奦")
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ奧")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠬࡳࡹࡷ࡫ࡧࠫ奨")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"࠭࡭ࡺࡸ࡬࡭ࡩ࠭奩")		in server: l111ll1ll11l_l1_	= l1111l11l111_l1_
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ奪")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ奫")
	elif l11lll_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ奬")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ奭")
	elif l11lll_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭奮") 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ奯")
	elif l11lll_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ奰")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ奱")
	elif l11lll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭奲")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ女")
	elif l11lll_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ奴") 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ奵")
	elif l11lll_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭奶")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ奷")
	elif l11lll_l1_ (u"ࠧࡶࡲࡳࠫ奸") 			in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠨࡷࡳࡦࡴࡳࠧ她")
	elif l11lll_l1_ (u"ࠩࡸࡴࡧ࠭奺") 			in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ奻")
	elif l11lll_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ奼") 		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ好")
	elif l11lll_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ奾") 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ奿")
	elif l11lll_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ妀")		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ妁")
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ如") 		in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ妃")
	elif l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ妄") 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ妅")
	elif l11lll_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ妆")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ妇")
	elif l11lll_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭妈")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ妉")
	#elif l11lll_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ妊") 	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭妋")
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ妌")	in server: l111ll11l1l1_l1_	= l11lll_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ妍")
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡺࡸ࡬ࠬࠩࡀࡁࡂ࠭ࠫࡶࡴ࡯࠶࠮ࠐࠉࠊࡶࡵࡽ࠿ࠐࠉࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱࠐࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮࠱ࡌࡴࡹࡴࡦࡦࡐࡩࡩ࡯ࡡࡇ࡫࡯ࡩ࠭ࡻࡲ࡭࠴ࠬ࠲ࡻࡧ࡬ࡪࡦࡢࡹࡷࡲࠨࠪࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠋࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠵࠶࠷࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡉࡥࡱࡹࡥࠋࠋࠌࠍࠨࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠲ࡴࡸࡧࠋࠋࠌࠍࡱ࡯ࡳࡵࡡࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡹࡪ࡬࠮ࡱࡵ࡫࠳࡭ࡩࡵࡪࡸࡦ࠳࡯࡯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡧࡰ࠴ࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࡴ࡫ࡷࡩࡸ࠴ࡨࡵ࡯࡯ࠫࠏࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲࡬ࡪࡵࡷࡣࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈ࠱࠶ࡹࡴࠨࠫࠍࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡩࡶࡰࡰ࠿ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࡜࠲ࡠ࠲ࡱࡵࡷࡦࡴࠫ࠭ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿ࡰ࡮ࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽ࡤࡁࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰࡮࡬ࡂࠬ࠲ࠧࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠷࠸࠲࠳ࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨࠫࠍࠍࠎࠏࠉࡱࡣࡵࡸࡸࠦ࠽ࠡࡵࡨࡶࡻ࡫ࡲ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠰ࠪ࠭ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡱࡣࡵࡸࡸࡀࠊࠊࠋࠌࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡶࡡࡳࡶࠬࡀ࠹ࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࠉࡦ࡮࡬ࡪࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠎࠎࠨࠢࠣ妎")
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ妏"),l11lll_l1_ (u"ࠪࠫ妐"),url,l11l11l_l1_)
	if   l1lll1ll1_l1_:	l11111ll1ll1_l1_,name = l11lll_l1_ (u"ࠫำอีࠨ妑"),l1lll1ll1_l1_
	elif l111ll1ll11l_l1_:		l11111ll1ll1_l1_,name = l11lll_l1_ (u"ࠬࠫๅฮัาࠫ妒"),l111ll1ll11l_l1_
	elif l111ll11l1l1_l1_:		l11111ll1ll1_l1_,name = l11lll_l1_ (u"࠭ࠥࠦ฻สู้๋ࠥา๊ไࠫ妓"),l111ll11l1l1_l1_
	elif l1ll1ll11_l1_:	l11111ll1ll1_l1_,name = l11lll_l1_ (u"ࠧࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭妔"),l1ll1ll11_l1_
	elif l1lllll1l1ll1_l1_:	l11111ll1ll1_l1_,name = l11lll_l1_ (u"ࠨࠧࠨࠩࠪ฿วๆࠢัหึา๊ࠨ妕"),l1111l11l111_l1_
	else:			l11111ll1ll1_l1_,name = l11lll_l1_ (u"ࠩࠨฺࠩࠪࠫࠥษ่ࠤ๊า็้ๆࠪ妖"),l1111l11l111_l1_
	return l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡰ࡭ࡣࡼࡶ࠳࠺ࡨࡦ࡮ࡤࡰࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡵࡸࡩࡷࡣࡷࡩࠥࡃࠠࠨࡪࡨࡰࡦࡲࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠏࠏࡥ࡭࡫ࡩࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡴࡩࡧࡹ࡭ࡩ࡫࡯ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹࡩࡻ࠴ࡩࡰࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡥࡷࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡢࡰ࡯ࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡤࡲࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡸ࡬ࡨ࡭ࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡼࡩࡥࡵ࡫ࡥࡷ࡫ࠧࠋࠋࠥࠦࠧ妗")
def l1111111lll1_l1_(url,source):
	l11l11l_l1_,l111ll11ll11_l1_,server,l1111l11l111_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l1llll1l11ll1_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ妘"),l11lll_l1_ (u"ࠬ࠭妙"),l111ll1ll11l_l1_,server)
	#if l11lll_l1_ (u"࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫ妚")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ妛"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ妜"))
	#if any(value in server for value in l1111ll1l1l1_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡉࡘࡕࡌࡗࡇࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࠦࡴࡩ࡫ࡶࠤࡸ࡫ࡲࡷࡧࡵࠫ妝")],[]
	if   l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ妞")		in source: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l111l_l1_(l11l11l_l1_,name)
	elif l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ妟")		in source: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111_l1_(l11l11l_l1_,type,l11l111l_l1_)
	elif l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ妠")		in source: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lll1ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭妡")		in source: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llllllll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ妢")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11l111ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫ妣")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ妤")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll11ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ妥")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭妦")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢࠨ妧")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡥࡨࡻࡱࡳࡼ࠭妨")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭妩")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ妪")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫ妫")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ妬")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l1111ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭妭")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ妮")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11ll1l1l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ妯")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡷࡵ࠷ࡹࠬ妰")			in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1ll111l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ妱")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1llll111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ妲")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ妳")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨ妴")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨ妵")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭妶")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1111l1ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ妷")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ妸")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ妹")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ妺")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ妻")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡹ࡫ࡣࡩࠩ妼")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡧࡶ࡮ࡩࡸࡪࡩࡨࠨ妽")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡲࡢࡶࡨࠫ妾")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡲࡦࡶࡪࡼࡩࡦࡹࠪ妿")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࠩ姀")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ姁")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ姂")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭姃"),[l11lll_l1_ (u"࠭ࠧ姄")],[l11l11l_l1_]
	#elif l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ姅")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ姆")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ姇")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11l1l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩ姈")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111111ll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࡢ࡯ࠪ姉") 		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭姊"),[l11lll_l1_ (u"࠭ࠧ始")],[l11l11l_l1_]
	else: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ姌"),[l11lll_l1_ (u"ࠨࠩ姍")],[l11l11l_l1_]
	return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
def l111ll11l111_l1_(url,source):
	server = SERVER(url,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ姎"))
	#if l11lll_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ姏")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ姐"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ姑"))
	#if any(value in server for value in l1111ll1l1l1_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ姒")],[]
	l1111111ll1l_l1_ = False
	if   l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭姓")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll11l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ委")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll11l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠭姕") in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11ll11_l1_(url)
	elif l11lll_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ姖")	in url: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111ll1ll11_l1_(url)
	elif l11lll_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭姗")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(url)
	elif l11lll_l1_ (u"ࠬࡸࡥࡷ࡫ࡨࡻࡷࡧࡴࡦࠩ姘")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111_l1_(url)
	elif l11lll_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ姙")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1lll_l1_(url)
	elif l11lll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ姚")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll111111_l1_(url)
	elif l11lll_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ姛")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ姜")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l111l1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ姝")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll111ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬ姞")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll11l1_l1_(url)
	elif l11lll_l1_ (u"ࠬ࡫࠵ࡵࡵࡤࡶࠬ姟")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l11l11_l1_(url)
	elif l11lll_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ姠")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1l11l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ姡")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1l11l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ姢")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ姣")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ姤")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡩࡦࠪ姥")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡦ࡮ࡴࠧ姦")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"࠭࡬ࡪ࡫࡬ࡺ࡮ࡪࡥࡰࠩ姧")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡳࡧࡧࠧ姨")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l111ll_l1_(url)
	elif l11lll_l1_ (u"ࠨࡸ࡬ࡨࡸࡶࡥࡦࡦࠪ姩")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l111ll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ姪") 		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠪࠫ姫"),[l11lll_l1_ (u"ࠫࠬ姬")],[url]
	#elif l11lll_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ姭")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll111ll11_l1_(url)
	elif l11lll_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ姮") 	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111ll11lll_l1_(url)
	elif l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ姯")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l111l11l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࡮࡯ࠨ姰")in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1111ll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭姱") 	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1ll1ll1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫ姲")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111l1lll_l1_(url)
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࠨ姳") 			in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll11111l1_l1_(url)
	elif l11lll_l1_ (u"ࠬࡻࡰࡱࠩ姴") 			in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll11111l1_l1_(url)
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ姵") 	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1ll1l_l1_(url)
	#elif l11lll_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ姶")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ姷") 		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llllll11ll1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ姸") 	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111ll11111_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ姹")		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111111l111_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ姺") 		in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llllllll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ姻") 	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111lllllll_l1_(url)
	elif l11lll_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ姼")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llllll1l1l1_l1_(url)
	elif l11lll_l1_ (u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫ姽")	in server: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll111l_l1_(url)
	else: l1111111ll1l_l1_ = True
	if l1111111ll1l_l1_ or l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ姾") in l111llll1lll_l1_:
		l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ姿"),[],[]
	return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈࡗ࡙ࡘࡅࡂࡏࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡇࡐࡗࡑࡐࡎࡓࡉࡕࡇࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩ࡬ࡲࡹࡵࡵࡱ࡮ࡲࡥࡩ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡊࡐࡗࡓ࡚ࡖࡌࡐࡃࡇࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡷ࡬ࡪࡼࡩࡥࡧࡲࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁ࡚ࠥࡈࡆࡘࡌࡈࡊࡕࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡥࡷ࠰࡬ࡳࠬࠏࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡇ࡙ࡍࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡵࡲࡡࡺࡴ࠱࠸࡭࡫࡬ࡢ࡮ࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡌࡊࡒࡁࡍࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡘࡌࡈࡇࡕࡍࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦ࡫ࡨࠬࠦࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡌࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠠࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡗࡍࡇࡒࡆࠪࡸࡶࡱ࠯ࠊࠊࠤࠥࠦ娀")
def l1111l1ll11l_l1_(l11l1ll11ll1_l1_):
	if l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ威") in str(type(l11l1ll11ll1_l1_)):
		links = []
		for link in l11l1ll11ll1_l1_:
			if l11lll_l1_ (u"ࠬࡹࡴࡳࠩ娂") in str(type(link)):
				link = link.replace(l11lll_l1_ (u"࠭࡜ࡳࠩ娃"),l11lll_l1_ (u"ࠧࠨ娄")).replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ娅"),l11lll_l1_ (u"ࠩࠪ娆")).strip(l11lll_l1_ (u"ࠪࠤࠬ娇"))
			links.append(link)
	else: links = l11l1ll11ll1_l1_.replace(l11lll_l1_ (u"ࠫࡡࡸࠧ娈"),l11lll_l1_ (u"ࠬ࠭娉")).replace(l11lll_l1_ (u"࠭࡜࡯ࠩ娊"),l11lll_l1_ (u"ࠧࠨ娋")).strip(l11lll_l1_ (u"ࠨࠢࠪ娌"))
	return links
def l1llll1lllll1_l1_(url,source):
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ娍"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ娎")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ娏"))
	l1lllll1l1ll1_l1_,link,l1111l1ll1l1_l1_ = l11lll_l1_ (u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩ娐"),l11lll_l1_ (u"࠭ࠧ娑"),l11lll_l1_ (u"ࠧࠨ娒")
	l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111111lll1_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ娓"),l11lll_l1_ (u"ࠩࠪ娔"),l11lll_l1_ (u"ࠪࠫ娕"),l111llll1lll_l1_)
	l1111_l1_ = l1111l1ll11l_l1_(l1111_l1_)
	if l111llll1lll_l1_==l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ娖"): return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_: link = l1111_l1_[0]
	if l111llll1lll_l1_==l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ娗"):
		#l111llll1lll_l1_ = l111llll1lll_l1_.replace(l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ娘"),l11lll_l1_ (u"ࠧࠨ娙"))
		l1lllll1l1ll1_l1_ = l11lll_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ娚")
		l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll11l111_l1_(link,source)
		l1111_l1_ = l1111l1ll11l_l1_(l1111_l1_)
		if l111llll1lll_l1_==l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ娛"): return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
		elif l11lll_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ娜") in l111llll1lll_l1_:
			l1111l1ll1l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠳࠽ࠤࠬ娝")+l111llll1lll_l1_
			l1lllll1l1ll1_l1_ = l11lll_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠫ娞")
			l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll111lll_l1_(link,source)
			l1111_l1_ = l1111l1ll11l_l1_(l1111_l1_)
			if l111llll1lll_l1_==l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ娟"): return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
			elif l11lll_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭娠") in l111llll1lll_l1_:
				l1111l1ll1l1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠸࠺ࠡࠩ娡")+l111llll1lll_l1_
				l1lllll1l1ll1_l1_ = l11lll_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠨ娢")
				l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll111ll1_l1_(link,source)
				l1111_l1_ = l1111l1ll11l_l1_(l1111_l1_)
				if l111llll1lll_l1_==l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ娣"): return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
				elif l11lll_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ娤") in l111llll1lll_l1_:
					l1111l1ll1l1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥ࠭娥")+l111llll1lll_l1_
	elif l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠨ娦") in l111llll1lll_l1_: l1111l1ll1l1_l1_ = l11lll_l1_ (u"ࠧࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠳࠾ࠥ࠭娧")+l111llll1lll_l1_
	if l1111_l1_: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ娨"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ娩")+l1lllll1l1ll1_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ娪")+url+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ娫")+link+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹࡵ࡭ࡶࡶ࠾ࠥࡡࠠࠨ娬")+str(l1111_l1_)+l11lll_l1_ (u"࠭ࠠ࡞ࠩ娭"))
	else: LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ娮"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ娯")+url+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ娰")+link+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡇࡵࡶࡴࡸࡳ࠻ࠢ࡞ࠤࠬ娱")+l1111l1ll1l1_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ娲"))
	l1111l1ll1l1_l1_ = l111l_l1_(l1111l1ll1l1_l1_)
	return l1111l1ll1l1_l1_,l1lll1ll_l1_,l1111_l1_
def l1llllll11lll_l1_(l11l1l1llll1_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ娳"),l11l1l1llll1_l1_)
	l11lll1l1ll_l1_ = l11111l_l1_
	data = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ娴"),l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ娵"),l11l1l1llll1_l1_)
	if data:
		l1lll1ll_l1_,l1111_l1_ = list(zip(*data))
		return l1lll1ll_l1_,l1111_l1_
	l1lll1ll_l1_,l1111_l1_,l111llll1l1l_l1_ = [],[],[]
	for link in l11l1l1llll1_l1_:
		if l11lll_l1_ (u"ࠨ࠱࠲ࠫ娶") not in link: continue
		l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l111lll1llll_l1_(link,source)
		l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭娷"),l11l111l_l1_,re.DOTALL)
		if l11l111l_l1_: l11l111l_l1_ = int(l11l111l_l1_[0])
		else: l11l111l_l1_ = 0
		#if l11l111l_l1_:
		#	l111l1llll1l_l1_ = sorted(l11l111l_l1_,reverse=True,key=lambda key: int(key))
		#	l11l111l_l1_ = int(l111l1llll1l_l1_[0])
		#else: l11l111l_l1_ = 0
		server = SERVER(link,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ娸"))
		l111llll1l1l_l1_.append([l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server])
	if l111llll1l1l_l1_:
		#l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link = zip(*l111llll1l1l_l1_)
		#name = reversed(name)
		#l111llll1l1l_l1_ = zip(l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link)
		l1lll11ll1l1_l1_ = sorted(l111llll1l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1111l1l11ll_l1_ = []
		for line in l1lll11ll1l1_l1_:
			if line not in l1111l1l11ll_l1_:
				l1111l1l11ll_l1_.append(line)
				#LOG_THIS(l11lll_l1_ (u"ࠫࠬ娹"),str(line))
		for l11111ll1ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server in l1111l1l11ll_l1_:
			if l11l111l_l1_: l11l111l_l1_ = str(l11l111l_l1_)
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭娺")
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ娻"),l11lll_l1_ (u"ࠧࠨ娼"),name,link)
			title = l11lll_l1_ (u"ࠨีํีๆืࠧ娽")+l11lll_l1_ (u"ࠩࠣࠫ娾")+type+l11lll_l1_ (u"ࠪࠤࠬ娿")+l11111ll1ll1_l1_+l11lll_l1_ (u"ࠫࠥ࠭婀")+l11l111l_l1_+l11lll_l1_ (u"ࠬࠦࠧ婁")+l1l1111_l1_+l11lll_l1_ (u"࠭ࠠࠨ婂")+name
			if server not in title: title = title+l11lll_l1_ (u"ࠧࠡࠩ婃")+server
			title = title.replace(l11lll_l1_ (u"ࠨࠧࠪ婄"),l11lll_l1_ (u"ࠩࠪ婅")).strip(l11lll_l1_ (u"ࠪࠤࠬ婆")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ婇"),l11lll_l1_ (u"ࠬࠦࠧ婈")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ婉"),l11lll_l1_ (u"ࠧࠡࠩ婊")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ婋"),l11lll_l1_ (u"ࠩࠣࠫ婌"))
			if link not in l1111_l1_:
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		if l1111_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ婍"),l1111_l1_)
			data = list(zip(l1lll1ll_l1_,l1111_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ婎"),l11l1l1llll1_l1_,data,l11lll1l1ll_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭婏"),l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠾࠷ࡀࠠࠡࠢࠪ婐")+str(data))
	return l1lll1ll_l1_,l1111_l1_
def l111ll111lll_l1_(url,source):
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡆࡦ࡝࡟࡫ࡧࡱࡳࡿࡑࡣࠨ婑")
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ婒")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l111ll1ll1l1_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lll1lllll1_l1_ = str(error)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ婓"),l11lll_l1_ (u"ࠪࠫ婔"),l11lll_l1_ (u"ࠫࠬ婕"),str(results))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭婖"),l11lll_l1_ (u"࠭ࠧ婗"),l11lll_l1_ (u"ࠧࠨ婘"),str(l1lll1lllll1_l1_))
	# resolveurl l1111l1lll_l1_ l1ll11lllll_l1_ l1lllll1l111l_l1_ with l1llll11ll1l1_l1_ error or l1111l1lllll_l1_ value False
	if not results:
		if l1lll1lllll1_l1_==l11lll_l1_ (u"ࠨࠩ婙"):
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ婚"),l11lll_l1_ (u"ࠪࠫ婛"),l11lll_l1_ (u"ࠫࠬ婜"),str(l1lll1lllll1_l1_))
		l111llll1lll_l1_ = l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠤࡋࡧࡩ࡭ࡧࡧࠫ婝")
		l111llll1lll_l1_ += l11lll_l1_ (u"࠭ࠠࠨ婞")+l1lll1lllll1_l1_.splitlines()[-1]
		return l111llll1lll_l1_,[],[]
	return l11lll_l1_ (u"ࠧࠨ婟"),[l11lll_l1_ (u"ࠨࠩ婠")],[results]
def l111ll111ll1_l1_(url,source):
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡈࡡࡘࡡ࡭ࡩࡳࡵࡺࡌࡥࠪ婡")
	#url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯࠲ࡺ࡮ࡪࡥࡰ࠱ࡻ࠻ࡾࡿ࠴࠲ࡵࠪ婢")
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ婣"),l11lll_l1_ (u"ࠬ࠭婤"),url,l11lll_l1_ (u"࠭ࠧ婥"))
	#return l11lll_l1_ (u"ࠧࠨ婦"),[],[]
	l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ婧")
	results = False
	try:
		import youtube_dl
		l111lll1l111_l1_ = youtube_dl.YoutubeDL({l11lll_l1_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ婨"): True})
		results = l111lll1l111_l1_.extract_info(url,download=False)
	except Exception as error: l1lll1lllll1_l1_ = str(error)
	# youtube_dl l1111l1lll_l1_ l1ll11lllll_l1_ l1lllll1l111l_l1_ with l1llll11ll1l1_l1_ error or l1111l1lllll_l1_ value False
	if not results or l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ婩") not in list(results.keys()):
		if l1lll1lllll1_l1_==l11lll_l1_ (u"ࠫࠬ婪"):
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭婫"),l11lll_l1_ (u"࠭ࠧ婬"),l11lll_l1_ (u"ࠧࠨ婭"),l1lll1lllll1_l1_)
		l111llll1lll_l1_ = l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠠࡇࡣ࡬ࡰࡪࡪࠧ婮")
		l111llll1lll_l1_ += l11lll_l1_ (u"ࠩࠣࠫ婯")+l1lll1lllll1_l1_.splitlines()[-1]
		return l111llll1lll_l1_,[],[]
	else:
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link in results[l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ婰")]:
			l1lll1ll_l1_.append(link[l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࠫ婱")])
			l1111_l1_.append(link[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ婲")])
		return l11lll_l1_ (u"࠭ࠧ婳"),l1lll1ll_l1_,l1111_l1_
def l111lll11ll1_l1_(url):
	if l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭婴") in url:
		l1lll1ll_l1_,l1111_l1_ = l11ll11lll_l1_(url)
		if l1111_l1_: return l11lll_l1_ (u"ࠨࠩ婵"),l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡁࡓࡃࡅࠫ婶"),[],[]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭婷"),[l11lll_l1_ (u"ࠫࠬ婸")],[url]
def l1l11l111ll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭婹"),l11lll_l1_ (u"࠭ࠧ婺"),l11lll_l1_ (u"ࠧࠨ婻"),url)
	l1lllll1_l1_,l1llll1ll1l_l1_ = [],[]
	if l11lll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴ࠰ࡰࡴ࠹ࡅࡶࡪࡦࡀࠫ婼") in url:
		# l111l1111ll1_l1_:
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1lllll1ll111_l1_.html
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l11ll1l111_l1_.l1111lll_l1_?l1l11l11lll_l1_=49e3a27b4
		# l11111l11ll1_l1_: https://l1111ll111ll_l1_.l1ll1l1ll1l_l1_.l1llll11l11ll_l1_.l1ll1ll111l_l1_/15/items/40animeHD/l1111l1ll1ll_l1_.l1111lll_l1_
		# l111l1111ll1_l1_:
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1llllllll1ll_l1_-l1111lll11ll_l1_.html
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l11ll1l111_l1_.l1111lll_l1_?l1l11l11lll_l1_=l1llll1ll1111_l1_
		# l11111l11ll1_l1_: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l11ll1l111_l1_/l1111l11lll1_l1_%20.l1111lll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭婽"),url,l11lll_l1_ (u"ࠪࠫ婾"),l11lll_l1_ (u"ࠫࠬ婿"),False,l11lll_l1_ (u"ࠬ࠭媀"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨ媁"))
		if l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ媂") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ媃")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ媄"))
			l1llll1ll1l_l1_.append(server)
	elif l11lll_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ媅") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l111l1111ll1_l1_:
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_111ll1lllll_l1_.html
		# link: https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l111lll1l1ll_l1_/?link=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l111ll11llll_l1_&l1llll1l1l11l_l1_=
		# l111l1111ll1_l1_:
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# link: https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l1l111lll_l1_.l1ll1lllll_l1_?url=l1llll11lll1l_l1_==&sub=https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l111l111ll11_l1_/l1llll11ll1ll_l1_.l1llll1ll1ll1_l1_&l1llll1l1l11l_l1_=https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l1llllll1111l_l1_/l1llll1111ll1_l1_-1.l1lllllll1lll_l1_
		# l111l1111ll1_l1_:
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1111l11l1l1_l1_.html
		# link: https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l11111ll11ll_l1_/?url=https://photos.l111l1l1111_l1_.l111l11111l1_l1_.l11l1111l1ll_l1_/l1111ll111l1_l1_&sub=&l1llll1l1l11l_l1_=http://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l1llllll1111l_l1_/4723b8ebe-1.l1lllllll1lll_l1_
		# l111l1111ll1_l1_:
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l111lll11l11_l1_.html
		# https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l111lll1l1ll_l1_/?link=https://l1l1111111l_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l111ll11llll_l1_&sub=&l1llll1l1l11l_l1_=https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l1llllll1111l_l1_/2e8bc4c34-1.l1lllllll1lll_l1_
		# l111l1111ll1_l1_:
		# https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1111111l1l1_l1_.html
		# https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l111lll1l1ll_l1_/?link=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l111ll1l111l_l1_=l111ll11lll1_l1_&l1llll1l1l11l_l1_=https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l1llllll1111l_l1_/l111l1111l1l_l1_-1.l1lllllll1lll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ媆"),url,l11lll_l1_ (u"ࠬ࠭媇"),l11lll_l1_ (u"࠭ࠧ媈"),l11lll_l1_ (u"ࠧࠨ媉"),l11lll_l1_ (u"ࠨࠩ媊"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠳ࡰࡧࠫ媋"))
		html = response.content
		l1ll11l1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࡧࡠ࠮࠴ࠪࡀ࡞ࠬࡠ࠮࠯࠮࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ媌"),html,re.DOTALL)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ媍"),str(l1ll11l1lll1_l1_))
		if l1ll11l1lll1_l1_:
			l1ll11l1lll1_l1_ = l1ll11l1lll1_l1_[0]
			l1l1l1ll11ll_l1_ = l1l1ll1lll1l_l1_(l1ll11l1lll1_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭媎"),str(l1l1l1ll11ll_l1_))
			l1l1l1l1111l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫ࠯ࠫ媏"),l1l1l1ll11ll_l1_,re.DOTALL)
			if l1l1l1l1111l_l1_:
				l1l1l1l1111l_l1_ = l1l1l1l1111l_l1_[0]
				l1l1l1l1111l_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ媐"),l1l1l1l1111l_l1_)
				for dict in l1l1l1l1111l_l1_:
					link = dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪ࠭媑")]
					l11l111l_l1_ = dict[l11lll_l1_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ媒")]
					#link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࡣࡤ࠭媓")+l11l111l_l1_
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ媔"))
					l1llll1ll1l_l1_.append(l11l111l_l1_+l11lll_l1_ (u"ࠬࠦࠧ媕")+server)
		elif l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ媖") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ媗")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭媘"))
			l1llll1ll1l_l1_.append(server)
		# l111l1111ll1_l1_: 5
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1111l11l1l1_l1_.html
		# link: https://www.l1l11l11l1l_l1_.com/l1llll1l1llll_l1_/l11111ll11ll_l1_/?url=https://photos.l111l1l1111_l1_.l111l11111l1_l1_.l11l1111l1ll_l1_/l1111ll111l1_l1_&sub=&l1llll1l1l11l_l1_=http://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l1lllll111111_l1_/l1llllll1111l_l1_/4723b8ebe-1.l1lllllll1lll_l1_
		if l11lll_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭࡯ࡰࠩ媙") in url:
			link = url.split(l11lll_l1_ (u"ࠪࡃࡺࡸ࡬࠾ࠩ媚"))[1]
			link = link.split(l11lll_l1_ (u"ࠫࠫ࠭媛"))[0]
			if link:
				l1lllll1_l1_.append(link)
				l1llll1ll1l_l1_.append(l11lll_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷࠥ࡭࡯ࡰࡩ࡯ࡩࠬ媜"))
	else:
		# l111l1111ll1_l1_:
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1llll1l11lll_l1_.html
		# link: http://ok.l111l11111ll_l1_/l111l1l11111_l1_/1676019108395
		# l111l1111ll1_l1_:
		# url: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1llll1l1lll1_l1_.html
		# link: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l111ll11llll_l1_
		l1lllll1_l1_.append(url)
		server = SERVER(url,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ媝"))
		l1llll1ll1l_l1_.append(server)
	if not l1lllll1_l1_: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ媞"),[],[]
	elif len(l1lllll1_l1_)==1: link = l1lllll1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭媟"),l1llll1ll1l_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ媠"),[],[]
		link = l1lllll1_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭媡"),[l11lll_l1_ (u"ࠫࠬ媢")],[link]
def l1111l11ll11_l1_(url):
	# test from: https://www.l1l11l11l1l_l1_.com/l11l1ll1l_l1_/l111ll1l11ll_l1_-l1111l11llll_l1_-l11111l11lll_l1_-l1llllll1llll_l1_-l1lllllll1ll1_l1_-l11ll1l111_l1_-1-date.html
	# url = https://l111l1ll11ll_l1_.l1llll1111lll_l1_.com/l11111l1111l_l1_=l1111lll1111_l1_
	headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ媣"):l11lll_l1_ (u"࠭ࡋࡰࡦ࡬࠳ࠬ媤")+str(kodi_version)}
	for l11ll111l1_l1_ in range(50):
		time.sleep(0.100)
		response = l11lll111ll_l1_(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ媥"),url,l11lll_l1_ (u"ࠨࠩ媦"),headers,False,l11lll_l1_ (u"ࠩࠪ媧"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧ媨"))
		if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭媩") in list(response.headers.keys()):
			link = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ媪")]
			link = link+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ媫")+headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ媬")]
			return l11lll_l1_ (u"ࠨࠩ媭"),[l11lll_l1_ (u"ࠩࠪ媮")],[link]
		if response.code!=429: break
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕࠩ媯"),[],[]
def l1111ll1ll11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ媰"),l11lll_l1_ (u"ࠬ࠭媱"),l11lll_l1_ (u"࠭ࠧ媲"),url)
	# https://photos.l111l1l1111_l1_.l111l11111l1_l1_.l11l1111l1ll_l1_/l1111ll111l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ媳"),url,l11lll_l1_ (u"ࠨࠩ媴"),l11lll_l1_ (u"ࠩࠪ媵"),l11lll_l1_ (u"ࠪࠫ媶"),l11lll_l1_ (u"ࠫࠬ媷"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡋࡓ࡙ࡕࡓࡈࡑࡒࡋࡑࡋ࠭࠲ࡵࡷࠫ媸"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠮ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲࠯ࡅࠩࠣ࠮࠱࠮ࡄ࠲࠮ࠫࡁ࠯ࠬ࠳࠰࠿ࠪ࠮ࠪ媹"),html,re.DOTALL)
	if link:
		link,l11l111l_l1_ = link[0]
		return l11lll_l1_ (u"ࠧࠨ媺"),[l11l111l_l1_],[link]
	return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆࠩ媻"),[],[]
def l1l1lll1ll1_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ媼"),l11lll_l1_ (u"ࠪࠫ媽"),l11lll_l1_ (u"ࠫࠬ媾"),url)
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡴࡴࡥ࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡪ࡫ࡨ࠷࠱࠺ࡦ࠵࠾࠸ࡣ࠳࠺ࡧ࠵࠶࠸࠰࠳ࡣࡧ࠵࠽ࡪࡤ࠲࠴ࡦ࠺࠽࠶࠶ࠨ媿")
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡶࡩࡱ࡮ࡤ࠮ࡧࡰࡦࡪࡪ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡸ࡬ࡨࡪࡵ࡟ࡱ࡮ࡤࡽࡪࡸ࠿ࡶ࡫ࡧࡁ࠵ࠬࡶࡪࡦࡀࡦ࠵࠷࠵࠺࠲࠷ࡥ࠽ࡧࡣࡧ࠹࠼࠹࠻ࡪ࠱ࡦ࠹࠹࠷࠵ࡨࡥ࠲࠹࠹࠹࠽࠽࠳ࠨ嫀")
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ嫁"),url,l11lll_l1_ (u"ࠨࠩ嫂"),l11lll_l1_ (u"ࠩࠪ嫃"),l11lll_l1_ (u"ࠪࠫ嫄"),l11lll_l1_ (u"ࠫࠬ嫅"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ嫆"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ嫇"),html)
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嫈"),html,re.DOTALL)
	if link: return l11lll_l1_ (u"ࠨࠩ嫉"),[l11lll_l1_ (u"ࠩࠪ嫊")],[link[0]]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ嫋"),[],[]
def l1llllllll_l1_(url):
	if l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ嫌") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ嫍"),url,l11lll_l1_ (u"࠭ࠧ嫎"),l11lll_l1_ (u"ࠧࠨ嫏"),l11lll_l1_ (u"ࠨࠩ嫐"),l11lll_l1_ (u"ࠩࠪ嫑"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪ嫒"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嫓"),html,re.DOTALL)
		link = link[0]
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ嫔") in link: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嫕"),[l11lll_l1_ (u"ࠧࠨ嫖")],[link]
		return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪ嫗"),[],[]
	else: return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嫘"),[l11lll_l1_ (u"ࠪࠫ嫙")],[url]
def l1ll1l1l1l1_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ嫚"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭嫛"),l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ嫜"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ嫝")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭嫞"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ嫟"),l11lll_l1_ (u"ࠪࠫ嫠"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡒࡔ࡝࠭࠲ࡵࡷࠫ嫡"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嫢"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡊ࡝ࡓࡕࡗࠨ嫣"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嫤"),[l11lll_l1_ (u"ࠨࠩ嫥")],[link]
def l1l11ll1l1l1_l1_(url):
	headers = {l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ嫦"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ嫧")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ嫨"),url,l11lll_l1_ (u"ࠬ࠭嫩"),headers,l11lll_l1_ (u"࠭ࠧ嫪"),l11lll_l1_ (u"ࠧࠨ嫫"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪ嫬"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嫭"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧ嫮"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ嫯"),[l11lll_l1_ (u"ࠬ࠭嫰")],[link]
def l1l1l1111ll_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ嫱"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ嫲")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭嫳"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ嫴"),l11lll_l1_ (u"ࠪࠫ嫵"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡉࡃࡏࡅࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭嫶"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ嫷"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡊࡄࡐࡆࡉࡉࡎࡃࠪ嫸"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫹") not in link: link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ嫺")+link
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嫻"),l11lll_l1_ (u"ࠪࠫ嫼"),l11lll_l1_ (u"ࠫࠬ嫽"),link)
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嫾"),[l11lll_l1_ (u"࠭ࠧ嫿")],[link]
def l1lll1l111_l1_(url):
	l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭嬀"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ嬁")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ嬂"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ嬃"),l11lll_l1_ (u"ࠫࠬ嬄"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ嬅"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ嬆"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡁࡃࡆࡒࠫ嬇"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嬈"),[l11lll_l1_ (u"ࠩࠪ嬉")],[link]
def l1lll11l1l11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嬊"),l11lll_l1_ (u"ࠫࠬ嬋"),l11lll_l1_ (u"ࠬ࠭嬌"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ嬍"),url,l11lll_l1_ (u"ࠧࠨ嬎"),l11lll_l1_ (u"ࠨࠩ嬏"),l11lll_l1_ (u"ࠩࠪ嬐"),l11lll_l1_ (u"ࠪࠫ嬑"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡕࡘࡉ࡙ࡓ࠳࠱ࡴࡶࠪ嬒"))
	html = response.content
	l1llll1l1l111_l1_ = re.findall(l11lll_l1_ (u"ࠧࡼࡡࡳࠢࡩࡷࡪࡸࡶࠡ࠿࠱࠮ࡄ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ嬓"),html,re.DOTALL|re.IGNORECASE)
	if l1llll1l1l111_l1_:
		l1llll1l1l111_l1_ = l1llll1l1l111_l1_[0][2:]
		#l1llll1l1l111_l1_ = l1llll1l1l111_l1_.decode(l11lll_l1_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭嬔"))
		l1llll1l1l111_l1_ = base64.b64decode(l1llll1l1l111_l1_)
		if kodi_version>18.99: l1llll1l1l111_l1_ = l1llll1l1l111_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ嬕"))
		link = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嬖"),l1llll1l1l111_l1_,re.DOTALL)
	else: link = l11lll_l1_ (u"ࠩࠪ嬗")
	if not link: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫ嬘"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬙") not in link: link = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ嬚")+link
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嬛"),[l11lll_l1_ (u"ࠧࠨ嬜")],[link]
def l1lllll111lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ嬝"),url,l11lll_l1_ (u"ࠩࠪ嬞"),l11lll_l1_ (u"ࠪࠫ嬟"),l11lll_l1_ (u"ࠫࠬ嬠"),l11lll_l1_ (u"ࠬ࠭嬡"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡊࡍ࡙ࡗࡋࡓ࠱࠶ࡹࡴࠨ嬢"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡸࡳ࠭࠲࠴ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嬣"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡋࡇ࡚ࡘࡌࡔࠬ嬤"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嬥"),[l11lll_l1_ (u"ࠪࠫ嬦")],[link]
def l11lll1lll_l1_(url):
	id = url.split(l11lll_l1_ (u"ࠫ࠴࠭嬧"))[-1]
	if l11lll_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ嬨") in url: url = url.replace(l11lll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭嬩"),l11lll_l1_ (u"ࠧࠨ嬪"))
	url = url.replace(l11lll_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࠧ嬫"),l11lll_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪ嬬"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嬭"),url,l11lll_l1_ (u"ࠫࠬ嬮"),l11lll_l1_ (u"ࠬ࠭嬯"),l11lll_l1_ (u"࠭ࠧ嬰"),l11lll_l1_ (u"ࠧࠨ嬱"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭嬲"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ嬳"),url)
	l111llll1lll_l1_ = l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ嬴")
	error = re.findall(l11lll_l1_ (u"ࠫࠧ࡫ࡲࡳࡱࡵࠦ࠳࠰࠿ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嬵"),html,re.DOTALL)
	if error: l111llll1lll_l1_ = error[0]
	url = re.findall(l11lll_l1_ (u"ࠬࡾ࠭࡮ࡲࡨ࡫࡚ࡘࡌࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ嬶"),html,re.DOTALL)
	if not url and l111llll1lll_l1_:
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嬷"),l11lll_l1_ (u"ࠧࠨ嬸"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠪ嬹"),l111llll1lll_l1_)
		return l111llll1lll_l1_,[],[]
	link = url[0].replace(l11lll_l1_ (u"ࠩ࡟ࡠࠬ嬺"),l11lll_l1_ (u"ࠪࠫ嬻"))
	l11l1l1l1ll1_l1_,l11l1l1llll1_l1_ = l11ll11lll_l1_(link)
	owner = re.findall(l11lll_l1_ (u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿ࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡳࡤࡴࡨࡩࡳࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嬼"),html,re.DOTALL)
	if owner: l111111lllll_l1_,l111lll11lll_l1_,l111l11ll111_l1_ = owner[0]
	else: l111111lllll_l1_,l111lll11lll_l1_,l111l11ll111_l1_ = l11lll_l1_ (u"ࠬ࠭嬽"),l11lll_l1_ (u"࠭ࠧ嬾"),l11lll_l1_ (u"ࠧࠨ嬿")
	l111l11ll111_l1_ = l111l11ll111_l1_.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ孀"),l11lll_l1_ (u"ࠩ࠲ࠫ孁"))
	l111lll11lll_l1_ = escapeUNICODE(l111lll11lll_l1_)
	l1lll1ll_l1_ = [l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ孂")+l111lll11lll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭孃")]+l11l1l1l1ll1_l1_
	l1111_l1_ = [l111l11ll111_l1_]+l11l1l1llll1_l1_
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭孄")+str(len(l1111_l1_)-1)+l11lll_l1_ (u"࠭ࠠๆๆไ࠭ࠬ孅"),l1lll1ll_l1_)
	if l1l_l1_==-1: return l11lll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ孆"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11lll_l1_ (u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠺࠰࠳ࠨࡸࡶࡱࡃࠧ孇")+l111l11ll111_l1_+l11lll_l1_ (u"ࠩࠩࡸࡪࡾࡴ࠾ࠩ孈")+l111lll11lll_l1_
		xbmc.executebuiltin(l11lll_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ孉")+new_path+l11lll_l1_ (u"ࠦ࠮ࠨ孊"))
		return l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ孋"),[],[]
	link =  l1111_l1_[l1l_l1_]
	return l11lll_l1_ (u"࠭ࠧ孌"),[l11lll_l1_ (u"ࠧࠨ孍")],[link]
def l1111l11l_l1_(link):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ孎"),link,l11lll_l1_ (u"ࠩࠪ孏"),l11lll_l1_ (u"ࠪࠫ子"),l11lll_l1_ (u"ࠫࠬ孑"),l11lll_l1_ (u"ࠬ࠭孒"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅࡓࡐࡘࡁ࠮࠳ࡶࡸࠬ孓"))
	html = response.content
	if l11lll_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭孔") in link: url = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ孕"),html,re.DOTALL)
	else: url = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ孖"),html,re.DOTALL)
	if not url: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡈࡏࡌࡔࡄࠫ字"),[],[]
	url = url[0]
	if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ存") not in url: url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ孙")+url
	return l11lll_l1_ (u"࠭ࠧ孚"),[l11lll_l1_ (u"ࠧࠨ孛")],[url]
def l111ll111111_l1_(url):
	# http://l111111l1111_l1_.l1lll1111111_l1_/l111lll1lll1_l1_.html?l111ll1ll11l_l1_=l1111l1l111l_l1_
	# http://l111111l1111_l1_.l1lll1111111_l1_/l111l1llllll_l1_?op=l1llll11l1ll1_l1_&id=l111lll1lll1_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ孜") : l11lll_l1_ (u"ࠩࠪ孝") }
	if l11lll_l1_ (u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭孞") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ孟"),headers,l11lll_l1_ (u"ࠬ࠭孠"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠶ࡹࡴࠨ孡"))
		#xbmc.log(html)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ孢"),l11lll_l1_ (u"ࠨࠩ季"),url,html)
		items = re.findall(l11lll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ孤"),html,re.DOTALL)
		if items: return l11lll_l1_ (u"ࠪࠫ孥"),[l11lll_l1_ (u"ࠫࠬ学")],[items[0]]
		else:
			message = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡲࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ孧"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧ孨"),l11lll_l1_ (u"ࠧࠨ孩"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ孪"),message[0])
				return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ孫")+message[0],[],[]
	else:
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ孬"),l11lll_l1_ (u"ࠫࠬ孭"),link,l11lll_l1_ (u"ࠬ࠭孮"))
		#url,l1ll111l111_l1_ = url.split(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ孯"))
		#l1ll111l111_l1_ = l1ll111l111_l1_.lower()
		l1ll111l111_l1_ = l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ孰")
		# l11l1ll1l_l1_ links
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ孱"),headers,l11lll_l1_ (u"ࠩࠪ孲"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬ孳"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭孴"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ孵"),[],[]
		l1lllll1ll_l1_ = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		if l11lll_l1_ (u"࠭࠮ࡳࡣࡵࠫ孶") in block or l11lll_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ孷") in block: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭學"),[],[]
		items = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ孹"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l1ll_l1_(payload)
		html = OPENURL_CACHED(l1lll1111_l1_,l1lllll1ll_l1_,data,headers,l11lll_l1_ (u"ࠪࠫ孺"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭孻"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ孼"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ孽"),[],[]
		download = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		items = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ孾"),block,re.DOTALL)
		l111l1l11lll_l1_,l1lll1ll_l1_,l111ll11ll1l_l1_,l1111_l1_,l1lllllllll1l_l1_ = [],[],[],[],[]
		for link,title in items:
			if l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ孿") in link:
				l111l1l11lll_l1_,l111ll11ll1l_l1_ = l11ll11lll_l1_(link)
				l1111_l1_ = l1111_l1_ + l111ll11ll1l_l1_
				if l111l1l11lll_l1_[0]==l11lll_l1_ (u"ࠩ࠰࠵ࠬ宀"): l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ宁")+l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ宂")+l1ll111l111_l1_)
				else:
					for title in l111l1l11lll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ它")+l11lll_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ宄")+l1ll111l111_l1_+l11lll_l1_ (u"ࠧࠡࠩ宅")+title)
			else:
				title = title.replace(l11lll_l1_ (u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪ宆"),l11lll_l1_ (u"ࠩࠪ宇"))
				title = title.strip(l11lll_l1_ (u"ࠪࠦࠬ守"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ安"),l11lll_l1_ (u"ࠬ࠭宊"),title,str(l1lllllllll1l_l1_))
				title = l11lll_l1_ (u"࠭ࠠิ์ิๅึࠦࠠฯษุࠤࠬ宋")+l11lll_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭完")+l1ll111l111_l1_+l11lll_l1_ (u"ࠨࠢࠪ宍")+title
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		# download links
		link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨࠫ宎") + download
		html = OPENURL_CACHED(l1lll1111_l1_,link,l11lll_l1_ (u"ࠪࠫ宏"),headers,l11lll_l1_ (u"ࠫࠬ宐"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧ宑"))
		items = re.findall(l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥ宒"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11lll_l1_ (u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫ宓")+l11lll_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ宔")+l1ll111l111_l1_+l11lll_l1_ (u"ࠩࠣࠫ宕")+resolution.split(l11lll_l1_ (u"ࠪࡼࠬ宖"))[1]
			link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ宗")+id+l11lll_l1_ (u"ࠬࠬ࡭ࡰࡦࡨࡁࠬ官")+mode+l11lll_l1_ (u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭宙")+hash
			l1lllllllll1l_l1_.append(resolution)
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		l1lllllllll1l_l1_ = set(l1lllllllll1l_l1_)
		l111111l1l11_l1_,l111l11lll11_l1_ = [],[]
		for title in l1lll1ll_l1_:
			#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ定"),l11lll_l1_ (u"ࠨࠩ宛"),title,l11lll_l1_ (u"ࠩࠪ宜"))
			res = re.findall(l11lll_l1_ (u"ࠥࠤ࠭ࡢࡤࠫࡺࡿࡠࡩ࠰ࠩࠧࠨࠥ宝"),title+l11lll_l1_ (u"ࠫࠫࠬࠧ实"),re.DOTALL)
			for resolution in l1lllllllll1l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11lll_l1_ (u"ࠬࡾࠧ実"))[1])
			l111111l1l11_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1111_l1_)):
			items = re.findall(l11lll_l1_ (u"ࠨࠦࠧࠪ࠱࠮ࡄ࠯ࠨ࡝ࡦ࠭࠭ࠫࠬࠢ宠"),l11lll_l1_ (u"ࠧࠧࠨࠪ审")+l111111l1l11_l1_[i]+l11lll_l1_ (u"ࠨࠨࠩࠫ客"),re.DOTALL)
			l111l11lll11_l1_.append( [l111111l1l11_l1_[i],l1111_l1_[i],items[0][0],items[0][1]] )
		l111l11lll11_l1_ = sorted(l111l11lll11_l1_, key=lambda x: x[3], reverse=True)
		l111l11lll11_l1_ = sorted(l111l11lll11_l1_, key=lambda x: x[2], reverse=False)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for i in range(len(l111l11lll11_l1_)):
			l1lll1ll_l1_.append(l111l11lll11_l1_[i][0])
			l1111_l1_.append(l111l11lll11_l1_[i][1])
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭宣"),[],[]
	return l11lll_l1_ (u"ࠪࠫ室"),l1lll1ll_l1_,l1111_l1_
def l111l1l11l11_l1_(url):
	# http://l1llll11l1l1l_l1_.com/717254
	parts = url.split(l11lll_l1_ (u"ࠫࡄ࠭宥"))
	l11l11l_l1_ = parts[0]
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ宦") : l11lll_l1_ (u"࠭ࠧ宧") }
	html = OPENURL_CACHED(l1lll1111_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ宨"),headers,l11lll_l1_ (u"ࠨࠩ宩"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩ宪"))
	items = re.findall(l11lll_l1_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ宫"),html,re.DOTALL)
	url = items[0]
	#l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111l11_l1_(url)
	#return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ宬"),[l11lll_l1_ (u"ࠬ࠭宭")],[url]
def l11111ll11l1_l1_(url):
	# https://l1ll1lllll1_l1_.l1ll1ll111l_l1_/l1lll11111l_l1_
	# https://l1ll1ll11l1_l1_.cc/l1lll11111l_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ宮") : l11lll_l1_ (u"ࠧࠨ宯") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠨࠩ宰"),headers,l11lll_l1_ (u"ࠩࠪ宱"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ宲"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡵࡳ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ害"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠬ࠭宴"),[l11lll_l1_ (u"࠭ࠧ宵")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪ家"),[],[]
def l111l1l1l11l_l1_(url):
	# https://l1ll1lllll1_l1_.l1ll1ll111l_l1_/l1lll11111l_l1_
	# https://l1ll1ll11l1_l1_.cc/l1lll11111l_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ宷") : l11lll_l1_ (u"ࠩࠪ宸") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠪࠫ容"),headers,l11lll_l1_ (u"ࠫࠬ宺"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ宻"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠦ࠱ࠨࠨࡩࡶࡷ࠲࠯ࡅࠩࠣࠩ宼"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠧࠨ宽"),[l11lll_l1_ (u"ࠨࠩ宾")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕࠪ宿"),[],[]
def l1l1llll111_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ寀"),l11lll_l1_ (u"ࠫࠬ寁"),l11lll_l1_ (u"ࠬ࠭寂"),url)
	# l11l1ll1l_l1_    https://show.l11111l111ll_l1_.com/l111111ll11l_l1_-l111111l1l1l_l1_/l111111l1l1l_l1_-l1111lll1l1l_l1_.l1ll1lllll_l1_?action=l1llllllllll1_l1_&post=32513&l1l1llll11l_l1_=1&type=l1ll1llllll_l1_
	# download https://show.l11111l111ll_l1_.com/links/l1lllll11111l_l1_
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"࠭ࠧ寃")
	# l11l1ll1l_l1_
	if l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࠫ寄") in url:
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ寅"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ密")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ寇"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ寈"),l11lll_l1_ (u"ࠬ࠭寉"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠸࡮ࡥࠩ寊"))
		l11lll1l_l1_ = response.content
		if l11lll1l_l1_.startswith(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ寋")): l11l11l_l1_ = l11lll1l_l1_
		else:
			l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣࠧࠨࠩ富"),l11lll1l_l1_,re.DOTALL)
			if l11l1l1_l1_:
				l11l11l_l1_ = l11l1l1_l1_[0]
				l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫ࠲࠯ࡅࠩࠥࠩ寍"),l11l11l_l1_,re.DOTALL)
				if l11l1l1_l1_:
					l11l11l_l1_ = l111l_l1_(l11l1l1_l1_[0])
					return l11lll_l1_ (u"ࠪࠫ寎"),[l11lll_l1_ (u"ࠫࠬ寏")],[l11l11l_l1_]
	# download
	elif l11lll_l1_ (u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࠭寐") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ寑"),url,l11lll_l1_ (u"ࠧࠨ寒"),l11lll_l1_ (u"ࠨࠩ寓"),True,l11lll_l1_ (u"ࠩࠪ寔"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠴ࡷࡹ࠭寕"))
		l11lll1l_l1_ = response.content
		if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭寖") in list(response.headers.keys()): l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ寗")]
		else: l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ寘"),l11lll1l_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ寙"),l11lll_l1_ (u"ࠨࠩ寚"),l11l11l_l1_,str(2222))
	if l11lll_l1_ (u"ࠩ࠲ࡺ࠴࠭寛") in l11l11l_l1_ or l11lll_l1_ (u"ࠪ࠳࡫࠵ࠧ寜") in l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࠴࡬࠯ࠨ寝"),l11lll_l1_ (u"ࠬ࠵ࡡࡱ࡫࠲ࡷࡴࡻࡲࡤࡧ࠲ࠫ寞"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭࠯ࡷ࠱ࠪ察"),l11lll_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭寠"))
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ寡"),l11lll_l1_ (u"ࠩࠪ寢"),l11l11l_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ寣"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ寤"),l11lll_l1_ (u"ࠬ࠭寥"),l11lll_l1_ (u"࠭ࠧ實"),l11lll_l1_ (u"ࠧࠨ寧"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠴ࡴࡧࠫ寨"))
		l11lll1l_l1_ = response.content
		items = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡱࡧࡢࡦ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ審"),l11lll1l_l1_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l11lll_l1_ (u"ࠪࡠࡡ࠭寪"),l11lll_l1_ (u"ࠫࠬ寫"))
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭寬"),l11lll1l_l1_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l11lll_l1_ (u"࠭࡜࡝ࠩ寭"),l11lll_l1_ (u"ࠧࠨ寮"))
				l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨࠩ寯"))
				l1111_l1_.append(link)
	else: return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ寰"),[l11lll_l1_ (u"ࠪࠫ寱")],[l11l11l_l1_]
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ寲"),l11lll_l1_ (u"ࠬ࠭寳"),str(l11ll1l11_l1_),l11l11l_l1_)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ寴"),[],[]
	return l11lll_l1_ (u"ࠧࠨ寵"),l1lll1ll_l1_,l1111_l1_
def l1l1ll111l1l_l1_(url):
	# l11l1ll1l_l1_ l1111lll_l1_  https://l1111l111lll_l1_.l111ll11l1ll_l1_.l1ll1ll111l_l1_/l11ll1111l1_l1_/l1llll11111ll_l1_.l1ll1lllll_l1_?s=07&id=l111lllll1l1_l1_,&l1llll_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1lllllll1lll_l1_&l111l11l11l1_l1_=l1llll1l11l1l_l1_&l11111l1ll11_l1_=l1llll111lll1_l1_
	# l11l1ll1l_l1_ l1llll1l1_l1_ https://l111ll1l1111_l1_.l111ll11l1ll_l1_.l1ll1ll111l_l1_/l11ll1111l1_l1_/l1llll1ll11ll_l1_.l1ll1lllll_l1_?l111l1ll111l_l1_=l111111l111l_l1_&l1111l1lll11_l1_=8a26a6cc61a884e89076504130c71626&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1lllllll1lll_l1_&l111l11l11l1_l1_=l1llll1l11l1l_l1_&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1lllllll1lll_l1_&l111l11l11l1_l1_=l1llll1l11l1l_l1_&l11111l1ll11_l1_=l111111l11l1_l1_
	# download https://www.l111l1lllll1_l1_.l111111ll1l1_l1_/l111l11ll11l_l1_?server=l1llll1ll111l_l1_&id=l1111ll1lll1_l1_,,
	# l1l111lll_l1_ https://l111l1lllll1_l1_.l1lll111ll_l1_/l1l111lll_l1_/l111l111l1ll_l1_
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ寶"),url,l11lll_l1_ (u"ࠩࠪ寷"),l11lll_l1_ (u"ࠪࠫ寸"),l11lll_l1_ (u"ࠫࠬ对"),l11lll_l1_ (u"ࠬ࠭寺"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭寻"))
	html = response.content
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠧࠨ导")
	if l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ寽") in url or l11lll_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ対") in url:
		if l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭寿") in url:
			l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ尀"),html,re.DOTALL)
			l11l11l_l1_ = l11l11l_l1_[0]
		else: l11l11l_l1_ = url
		if l11lll_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ封") not in l11l11l_l1_: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ専"),[l11lll_l1_ (u"ࠧࠨ尃")],[l11l11l_l1_]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ射"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ尅"),l11lll_l1_ (u"ࠪࠫ将"),l11lll_l1_ (u"ࠫࠬ將"),l11lll_l1_ (u"ࠬ࠭專"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭尉"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪ尊"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ尋"),block,re.DOTALL)
		if items:
			for link,l1ll11l1l111_l1_ in items:
				l1lll1ll_l1_.append(l1ll11l1l111_l1_)
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫ尌") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ對"),html,re.DOTALL)
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ導"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭小"),l11lll_l1_ (u"࠭ࠧ尐"),l11lll_l1_ (u"ࠧࠨ少"),l11lll_l1_ (u"ࠨࠩ尒"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ尓"))
		html = response.content
		l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ尔"),html,re.DOTALL)
		l11l1l1_l1_ = l11l1l1_l1_[0]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࠬ尕"))
		l1111_l1_.append(l11l1l1_l1_)
	elif l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬ尖") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ尗"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ尘"),[l11lll_l1_ (u"ࠨࠩ尙")],[l11l11l_l1_]
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ尚"),[],[]
	return l11lll_l1_ (u"ࠪࠫ尛"),l1lll1ll_l1_,l1111_l1_
def l1llll1l1ll_l1_(url):
	l1llll1ll1l_l1_,l1lllll1_l1_ = [],[]
	if l11lll_l1_ (u"ࠫ࠴࠷࠯ࠨ尜") in url:
		link = url.replace(l11lll_l1_ (u"ࠬ࠵࠱࠰ࠩ尝"),l11lll_l1_ (u"࠭࠯࠵࠱ࠪ尞"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ尟"),link,l11lll_l1_ (u"ࠨࠩ尠"),l11lll_l1_ (u"ࠩࠪ尡"),False,l11lll_l1_ (u"ࠪࠫ尢"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠴ࡷࡹ࠭尣"))
		l11lll1l_l1_ = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡤࡦࡱࡁࠫ尤"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ尥"),block,re.DOTALL)
			for link,l11l111l_l1_ in items:
				if link not in l1lllll1_l1_:
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ尦"))
					l1llll1ll1l_l1_.append(server+l11lll_l1_ (u"ࠨࠢࠣࠫ尧")+l11l111l_l1_)
			return l11lll_l1_ (u"ࠩࠪ尨"),l1llll1ll1l_l1_,l1lllll1_l1_
	elif l11lll_l1_ (u"ࠪ࠳ࡩ࠵ࠧ尩") in url:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ尪"),url,l11lll_l1_ (u"ࠬ࠭尫"),l11lll_l1_ (u"࠭ࠧ尬"),l11lll_l1_ (u"ࠧࠨ尭"),l11lll_l1_ (u"ࠨࠩ尮"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠳ࡰࡧࠫ尯"))
		l11lll1l_l1_ = response.content
		link = re.findall(l11lll_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ尰"),l11lll1l_l1_,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"ࠫ࠴࠷࠯ࠨ就"),l11lll_l1_ (u"ࠬ࠵࠴࠰ࠩ尲"))
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ尳"),link,l11lll_l1_ (u"ࠧࠨ尴"),l11lll_l1_ (u"ࠨࠩ尵"),False,l11lll_l1_ (u"ࠩࠪ尶"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࠬ尷"))
			l11lll1l_l1_ = response.content
			link = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ尸"),l11lll1l_l1_,re.DOTALL)
			if link: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ尹"),[l11lll_l1_ (u"࠭ࠧ尺")],[link[0]]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ尻"),[],[]
def l1lll11l1l1_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ尼"),l11lll_l1_ (u"ࠩࠪ尽"),l11lll_l1_ (u"ࠪࠫ尾"),url)
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ尿"),url,l11lll_l1_ (u"ࠬ࠭局"),l11lll_l1_ (u"࠭ࠧ屁"),l11lll_l1_ (u"ࠧࠨ层"),l11lll_l1_ (u"ࠨࠩ屃"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠹࠭࠲ࡵࡷࠫ屄"))
	html = response.content
	data = re.findall(l11lll_l1_ (u"ࠪࠦࡦࡩࡴࡪࡱࡱࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ居"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l11lll_l1_ (u"ࠫࡴࡶ࠽ࠨ屆")+op+l11lll_l1_ (u"ࠬࠬࡩࡥ࠿ࠪ屇")+id+l11lll_l1_ (u"࠭ࠦࡧࡰࡤࡱࡪࡃࠧ屈")+fname
		headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭屉"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ届")}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ屋"),url,data,headers,l11lll_l1_ (u"ࠪࠫ屌"),l11lll_l1_ (u"ࠫࠬ屍"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠶ࡳࡪࠧ屎"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡧࡩࡩࡷ࡫ࡲࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ屏"),html,re.DOTALL)
		if link: return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ屐"),[l11lll_l1_ (u"ࠨࠩ屑")],[link[0]]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭屒"),[],[]
def l11111ll1l_l1_(url):
	# https://l1lllll1111_l1_.l1llll1l1l1_l1_/l11ll1ll1ll_l1_?call=l111l111lll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l111ll1ll11l_l1_=l1111l11ll1l_l1_
	# https://l1lllll1111_l1_.l1llll1l1l1_l1_/l11ll1ll1ll_l1_?call=l111l111lll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l111ll1ll11l_l1_=l111111ll111_l1_
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ屓"),1)[0].strip(l11lll_l1_ (u"ࠫࡄ࠭屔")).strip(l11lll_l1_ (u"ࠬ࠵ࠧ展")).strip(l11lll_l1_ (u"࠭ࠦࠨ屖"))
	l1lll1ll_l1_,l1111_l1_,items,l11l1l1_l1_ = [],[],[],l11lll_l1_ (u"ࠧࠨ屗")
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ屘"):l11lll_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩ屙") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ屚"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ屛"),headers,True,l11lll_l1_ (u"ࠬ࠭屜"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠵ࡸࡺࠧ屝"))
	if l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ属") in list(response.headers.keys()): l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ屟")]
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭屠"),l11l1l1_l1_,l11lll_l1_ (u"ࠪࠫ屡"),headers,False,l11lll_l1_ (u"ࠫࠬ屢"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠵ࡲࡩ࠭屣"))
	#if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ層") in response.headers: l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ履")]
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ屦"),l11lll_l1_ (u"ࠩࠪ屧"),l11l1l1_l1_,response.content)
	if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ屨") in l11l1l1_l1_:
		# https://l1111l11ll_l1_.top/f/l1111llll1l1_l1_/?l111ll11l1_l1_=l11l11111ll1_l1_
		# https://l1111l11ll_l1_.top/v/l1111llll1l1_l1_/?l111ll11l1_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ屩") in url: l11l1l1_l1_ = l11l1l1_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ屪"),l11lll_l1_ (u"࠭࠯ࡷ࠱ࠪ屫"))
		l111ll1llll1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ屬"))[1]
		headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ屭"):headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭屮")] , l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ屯"):l11lll_l1_ (u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ屰")+l111ll1llll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ山"),l11l1l1_l1_,l11lll_l1_ (u"࠭ࠧ屲"),headers,False,l11lll_l1_ (u"ࠧࠨ屳"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ屴"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1lll1111_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠩࠪ屵"),headers,l11lll_l1_ (u"ࠪࠫ屶"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠵ࡵࡨࠬ屷"))
		if l11lll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ屸") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ屹"),html,re.DOTALL)
		elif l11lll_l1_ (u"ࠧ࠰ࡸ࠲ࠫ屺") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ屻"),html,re.DOTALL)
		if items: return [],[l11lll_l1_ (u"ࠩࠪ屼")],[ items[0] ]
		elif l11lll_l1_ (u"ࠪࡀ࡭࠷࠾࠵࠲࠷ࡀ࠴࡮࠱࠿ࠩ屽") in html:
			return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤุ๐ัโำࠣห้็๊ะ์๋ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏่ࠦๆืาี์ࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืฬࠤอ้ࠧ屾"),[],[]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔࠨ屿"),[],[]
	#xbmc.log(html)
def l11111111ll_l1_(link):
	# https://l11l1111l11l_l1_.net/?l11llll1_l1_=147043&l1l11111_l1_=5
	parts = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ岀"),link+l11lll_l1_ (u"ࠧࠧࠨࠪ岁"),re.DOTALL|re.IGNORECASE)
	l11llll1_l1_,l1l11111_l1_ = parts[0]
	url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ岂")+l11llll1_l1_+l11lll_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭岃")+l1l11111_l1_
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ岄"):l11lll_l1_ (u"ࠫࠬ岅") , l11lll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ岆"):l11lll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ岇") }
	l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ岈"),headers,l11lll_l1_ (u"ࠨࠩ岉"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱࠶ࡹࡴࠨ岊"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ岋"),l11lll_l1_ (u"ࠫࠬ岌"),url,l11l11l_l1_)
	#l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111l11_l1_(l11l11l_l1_)
	#return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ岍"),[l11lll_l1_ (u"࠭ࠧ岎")],[l11l11l_l1_]
def l1ll1111l1ll_l1_(url):
	# https://l1llll11l11l1_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1111llll11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111l1l111l1_l1_=1608181746
	server = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ岏"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ岐"):server,l11lll_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ岑"):l11lll_l1_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ岒")}
	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ岓"),url,l11lll_l1_ (u"ࠬ࠭岔"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ岕"),l11lll_l1_ (u"ࠧࠨ岖"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ岗"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ岘"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠪࠫ岙")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ岚"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ岛"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࠧ岜"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ岝"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑ࡞ࡉࡉࡎࡃࠪ岞"),[],[]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ岟"),[l11lll_l1_ (u"ࠪࠫ岠")],[l11l11l_l1_]
def l1l1l11ll11l_l1_(url):
	# https://l11l1111l1l1_l1_.l1lllll111ll1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1111llll11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111l1l111l1_l1_=1608181746
	# https://l11l1111l1l1_l1_.l1llll1l1l1_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l1111llll11l_l1_=l111llll111l_l1_&l111l1l111l1_l1_=1684182121
	server = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ岡"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭岢"):server,l11lll_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ岣"):l11lll_l1_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ岤")}
	response = OPENURL_REQUESTS_CACHED(l1ll111111ll_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ岥"),url,l11lll_l1_ (u"ࠩࠪ岦"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ岧"),l11lll_l1_ (u"ࠫࠬ岨"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡈࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ岩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ岪"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠧࠨ岫")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴ࠻ࠢ࡟ࠫ࠭ࡢࡤ࠯ࠬࡂ࠭ࡡ࠭ࠬࠡࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ岬"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧ岭"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠪࠫ岮"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	if not l11l11l_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ岯"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡇࡆࡍࡒࡇࠧ岰"),[],[]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ岱"),[l11lll_l1_ (u"ࠧࠨ岲")],[l11l11l_l1_]
def l1l1l111_l1_(link):
	# https://w.l1111111l11l_l1_.l1lll1ll1ll_l1_/l111111ll11l_l1_-content/l111lllll11l_l1_/l11111111l11_l1_/l111ll1111l1_l1_/l111111111ll_l1_/l1111l111ll1_l1_/l111111lll11_l1_.l1ll1lllll_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ岳"),l11lll_l1_ (u"ࠩࠪ岴"),link,html)
	parts = re.findall(l11lll_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ岵"),link+l11lll_l1_ (u"ࠫࠫࠬࠧ岶"),re.DOTALL)
	url,l11llll1_l1_,l1l11111_l1_ = parts[0]
	data = {l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭岷"):l11llll1_l1_,l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭岸"):l1l11111_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ岹"),url,data,l11lll_l1_ (u"ࠨࠩ岺"),l11lll_l1_ (u"ࠩࠪ岻"),l11lll_l1_ (u"ࠪࠫ岼"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭岽"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ岾"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ岿"),[l11lll_l1_ (u"ࠧࠨ峀")],[l11l11l_l1_]
def l1ll1ll11l_l1_(url):
	# https://l111l11llll1_l1_.l1lll111l1_l1_-l111l1l1l1l1_l1_.com/l1l111lll_l1_.l1ll1lllll_l1_?l1l11l11lll_l1_=l11111l1lll1_l1_
	# https://l.l111111lll1l_l1_.l111111ll1l1_l1_/l1l111lll_l1_.l1ll1lllll_l1_?l1l11l11lll_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ峁"),url,l11lll_l1_ (u"ࠩࠪ峂"),l11lll_l1_ (u"ࠪࠫ峃"),l11lll_l1_ (u"ࠫࠬ峄"),l11lll_l1_ (u"ࠬ࠭峅"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࠷ࡳࡵࠩ峆"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ峇"),html,re.DOTALL)
	if link:
		link = link[0]
		if link: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ峈"),[l11lll_l1_ (u"ࠩࠪ峉")],[link]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ峊"),[],[]
def l1lll11l1l_l1_(url):
	# https://l1lll1111l_l1_.l1lll111l1_l1_-l1lll111ll_l1_.l1lll111ll_l1_/l111111ll11l_l1_-content/l111lllll11l_l1_/old/l1llll1_l1_/server.l1ll1lllll_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ峋"),url,l11lll_l1_ (u"ࠬ࠭峌"),l11lll_l1_ (u"࠭ࠧ峍"),l11lll_l1_ (u"ࠧࠨ峎"),l11lll_l1_ (u"ࠨࠩ峏"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ峐"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ峑"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ峒"),[l11lll_l1_ (u"ࠬ࠭峓")],[link]
def l1ll1l1lll_l1_(url):
	# https://l11llll1l1l_l1_.l1l111lll11l_l1_.cc/l111111ll11l_l1_-content/l111lllll11l_l1_/l1lllll1ll1l1_l1_%20Now%20New/l1llll1llllll_l1_.l1ll1lllll_l1_?action=l111l1l11l1l_l1_&index=00&id=58504
	# https://l1111llll111_l1_.l1l111lll11l_l1_.net/l1lllll111111_l1_/2021/04/05/_11111ll1111_l1_-l11l11111l11_l1_.l1llll1111l1l_l1_ 200.l1llll1ll1lll_l1_.2020.l1lllll11l1l1_l1_/[l1lllll1ll1l1_l1_-l11l11111l11_l1_.l1llllll1l11l_l1_] 200.l1llll1ll1lll_l1_.2020.l1lllll11l1l1_l1_-360p.l1111lll_l1_
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ峔"))
	if l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ峕") in url:
		headers = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ峖"):l1llllll11_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭峗"),url,l11lll_l1_ (u"ࠪࠫ峘"),headers,l11lll_l1_ (u"ࠫࠬ峙"),l11lll_l1_ (u"ࠬ࠭峚"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ峛"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ峜"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			if l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ峝") in l11l11l_l1_:
				l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ峞"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ峟"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ峠"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭峡"),headers,l11lll_l1_ (u"࠭ࠧ峢"),l11lll_l1_ (u"ࠧࠨ峣"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ峤"))
				l11lll1l_l1_ = response.content
				items = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ峥"),l11lll1l_l1_,re.DOTALL)
				l1lll1ll_l1_,l1111_l1_ = [],[]
				l1llll1lll_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ峦"))
				for link,l11l111l_l1_ in reversed(items):
					link = l1llll1lll_l1_+link+l11lll_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ峧")+l1llll1lll_l1_
					l1lll1ll_l1_.append(l11l111l_l1_)
					l1111_l1_.append(link)
				return l11lll_l1_ (u"ࠬ࠭峨"),l1lll1ll_l1_,l1111_l1_
			else: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ峩"),[l11lll_l1_ (u"ࠧࠨ峪")],[l11l11l_l1_]
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ峫")+l1llllll11_l1_
	return l11lll_l1_ (u"ࠩࠪ峬"),[l11lll_l1_ (u"ࠪࠫ峭")],[l11l11l_l1_]
def l1111l1ll111_l1_(link):
	# https://l1l111lll11l_l1_.l1lll1ll1ll_l1_/l111111ll11l_l1_-content/l111lllll11l_l1_/l111l1l111ll_l1_/l1lllll1111l1_l1_/server.l1ll1lllll_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	# https://l111ll1l11l1_l1_.l1l111lll11l_l1_.net/l1lllll111111_l1_/2020/08/14/_11111ll1111_l1_-l11l11111l11_l1_.l1llll1111l1l_l1_ l1lllll1l1lll_l1_.l1111l1l1111_l1_.2020.l11111lll11l_l1_-l1111l1l1l1l_l1_/[l1lllll1ll1l1_l1_-l11l11111l11_l1_.l1llllll1l11l_l1_] l1lllll1l1lll_l1_.l1111l1l1111_l1_.2020.l11111lll11l_l1_-l1111l1l1l1l_l1_-1080p.l1111lll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ峮"),l11lll_l1_ (u"ࠬ࠭峯"),url,html)
	l1llllll11_l1_ = SERVER(link,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ峰"))
	if l11lll_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪࠧ峱") in link:
		parts = re.findall(l11lll_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ峲"),link+l11lll_l1_ (u"ࠩࠩࠪࠬ峳"),re.DOTALL)
		url,l11llll1_l1_,l1l11111_l1_ = parts[0]
		data = {l11lll_l1_ (u"ࠪ࡭ࡩ࠭峴"):l11llll1_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ峵"):l1l11111_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ島"),url,data,l11lll_l1_ (u"࠭ࠧ峷"),l11lll_l1_ (u"ࠧࠨ峸"),l11lll_l1_ (u"ࠨࠩ峹"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ峺"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ峻"),html,re.DOTALL)[0]
		if l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ峼") in l11l11l_l1_:
			headers = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭峽"):l1llllll11_l1_,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ峾"):l11lll_l1_ (u"ࠧࠨ峿")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ崀"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ崁"),headers,l11lll_l1_ (u"ࠪࠫ崂"),l11lll_l1_ (u"ࠫࠬ崃"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠵ࡲࡩ࠭崄"))
			l11lll1l_l1_ = response.content
			items = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ崅"),l11lll1l_l1_,re.DOTALL)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			l1llll1lll_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ崆"))
			for link,l11l111l_l1_ in reversed(items):
				link = l1llll1lll_l1_+link+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ崇")+l1llll1lll_l1_
				l1lll1ll_l1_.append(l11l111l_l1_)
				l1111_l1_.append(link)
			return l11lll_l1_ (u"ࠩࠪ崈"),l1lll1ll_l1_,l1111_l1_
		else: return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭崉"),[l11lll_l1_ (u"ࠫࠬ崊")],[l11l11l_l1_]
	else:
		link = link+l11lll_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ崋")+l1llllll11_l1_
		return l11lll_l1_ (u"࠭ࠧ崌"),[l11lll_l1_ (u"ࠧࠨ崍")],[link]
def l111lll1l_l1_(link):
	# http://l111lll1ll1l_l1_.tv/?l11llll1_l1_=159485&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤࠨ崎") in link:
		parts = re.findall(l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ崏"),link+l11lll_l1_ (u"ࠪࠪࠫ࠭崐"),re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		host = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ崑"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭崒"),l11lll_l1_ (u"࠭ࠧ崓"),link,host)
		url = host+l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ崔")+l11llll1_l1_+l11lll_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ崕")+l1l11111_l1_
		headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭崖"):l11lll_l1_ (u"ࠪࠫ崗") , l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ崘"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭崙") }
		l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ崚"),headers,l11lll_l1_ (u"ࠧࠨ崛"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ崜"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ崝"),l11lll_l1_ (u"ࠪࠫ崞")).replace(l11lll_l1_ (u"ࠫࡡࡸࠧ崟"),l11lll_l1_ (u"ࠬ࠭崠"))
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ崡"),l11lll_l1_ (u"ࠧࠨ崢"),url,l11l11l_l1_)
		#l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111l11_l1_(l11l11l_l1_)
		#return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ崣"),[l11lll_l1_ (u"ࠩࠪ崤")],[l11l11l_l1_]
	elif l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠵ࠧ崥") in link:
		counts = 0
		while l11lll_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ崦") in link and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ崧"),link,l11lll_l1_ (u"࠭ࠧ崨"),l11lll_l1_ (u"ࠧࠨ崩"),l11lll_l1_ (u"ࠨࠩ崪"),l11lll_l1_ (u"ࠩࠪ崫"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬ崬"))
			if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭崭") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ崮")]
			counts += 1
		return l11lll_l1_ (u"࠭ࠧ崯"),[l11lll_l1_ (u"ࠧࠨ崰")],[link]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ崱"),[],[]
def l11l1l111_l1_(url):
	# https://l11111l11l1l_l1_.l1llllll11l1l_l1_.me/l/l111llll1l11_l1_=
	# https://l111l11l1111_l1_.l1lllll11ll11_l1_.net/l1l111lll_l1_-l1l111lll_l1_-l1lllll1l11ll_l1_.html
	# https://m.l1lllll11ll11_l1_.net/l1lllll1l11ll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ崲"),l11lll_l1_ (u"ࠪࠫ崳"),l11lll_l1_ (u"ࠫࠬ崴"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ崵"))
	if l11lll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ崶") in url and l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ崷") not in url: url = server+l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ崸")+url.split(l11lll_l1_ (u"ࠩ࠲ࠫ崹"))[-1]+l11lll_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ崺")
	headers = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ崻"):server,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ崼"):l1l11111l_l1_()}
	if l11lll_l1_ (u"࠭࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ崽") in url:
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭崾"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ崿")}
		l11l11l_l1_,l11ll1l11_l1_ = l1lll1l1ll_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ嵀"),l11l11l_l1_,l11ll1l11_l1_,l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠪࠫ嵁"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠴ࡷࡹ࠭嵂"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࡙ࠬࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嵃"),html,re.DOTALL|re.IGNORECASE)
		if link: return l11lll_l1_ (u"࠭ࠧ嵄"),[l11lll_l1_ (u"ࠧࠨ嵅")],[link[0]]
	elif l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ嵆") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ嵇"),headers,l11lll_l1_ (u"ࠪࠫ嵈"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭嵉"))
		link = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嵊"),html,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ嵋"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ嵌"))
			return l11lll_l1_ (u"ࠨࠩ嵍"),[l11lll_l1_ (u"ࠩࠪ嵎")],[link]
	else:
		l11111l1l111_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嵏"),url,l11lll_l1_ (u"ࠫࠬ嵐"),headers,l11lll_l1_ (u"ࠬ࠭嵑"),l11lll_l1_ (u"࠭ࠧ嵒"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠹ࡲࡥࠩ嵓"))
		html = l11111l1l111_l1_.content
		link = re.findall(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫ嵔"),html,re.DOTALL)
		if link:
			link = l111l_l1_(link[0])+l11lll_l1_ (u"ࠩࠩࡨࡂ࠷ࠧ嵕")
			l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嵖"),link,l11lll_l1_ (u"ࠫࠬ嵗"),headers,l11lll_l1_ (u"ࠬ࠭嵘"),l11lll_l1_ (u"࠭ࠧ嵙"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡔࡇࡈࡈ࠲࠺ࡴࡩࠩ嵚"))
			html = l1ll111ll_l1_.content
			link = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡨࡴ࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嵛"),html,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠩࠪ嵜"),[l11lll_l1_ (u"ࠪࠫ嵝")],[link]
		if l11lll_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ嵞") in list(l11111l1l111_l1_.headers.keys()):
			cookies = l11111l1l111_l1_.headers[l11lll_l1_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ嵟")]
			link = re.findall(l11lll_l1_ (u"࠭࡟࡭ࡰ࡮ࡣ࠳࠰࠿࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ嵠"),cookies,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嵡"),[l11lll_l1_ (u"ࠨࠩ嵢")],[link]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡕࡈࡉࡉ࠭嵣"),[],[]
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠥࠣࡲࡴࡺࠠࡸࡱࡵ࡯࡮ࡴࡧࠋࠋࠌࠧࠥ࡯ࡴࠡࡰࡨࡩࡩࡹࠠࡤࡱࡲ࡯࡮࡫ࠠࡧࡴࡲࡱࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠌࠌࠍࠨࠦࡃࡰࡱ࡮࡭ࡪࡀࠠࡤࡨࡢࡧࡱ࡫ࡡࡳࡣࡱࡧࡪࡃࡃࡎࡧ࠱ࡌࡐࡍࡑ࡬࡯ࡺࡲࡘ࡜ࡵ࡯ࡼ࡙ࡍࡵࡷ࡯ࡸࡳࡖࡅ࡟ࡩࡰ࡯ࡈ࠺࡮ࡇࡖࡕࡐࡓࡥ࡝ࡇࡌ࠰࠮࠳࠹࠺࠸࠷࠱࠳࠲࠳࠺࠲࠶࠭࠳࠷࠳ࠎࠎࠏࡳࡦࡴࡹࡩࡷࠦ࠽ࠡࡕࡈࡖ࡛ࡋࡒࠩࡷࡵࡰ࠱࠭ࡵࡳ࡮ࠪ࠭ࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࠽ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠮ࠩ࠭ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡸ࡫ࡲࡷࡧࡵࢁࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠊ࡮࡬ࡲࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࡭࡫ࡱ࡯࠳࡮ࡲࡦࡨࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࡽࡴࡨ࠲ࡎࡍࡎࡐࡔࡈࡇࡆ࡙ࡅࠪࠌࠌࠍ࡮࡬ࠠ࡭࡫ࡱ࡯ࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡫࡭ࡣࡧࡧ࠱ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭࡝ࠪࠫࡢ࠲࡛࡭࡫ࡱ࡯ࡢࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠡࡷࡵࡰࠥࡃࠠ࡭࡫ࡱ࡯ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠬࡩࡶࡰࡰ࠮ࠐࠉࠊࠥ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍࠎࠩࡩࡧࠢࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠤࠋࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠣࠊࡴࡨࡸࡺࡸ࡮ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠋࠋࠌࠧࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠤࠥࠦ嵤")
	#if l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵࠰࡫ࡸࡲࡲࠧ嵥") in url:
	#	l1ll11ll111l_l1_ = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ嵦"))
	#	url = l11lll_l1_ (u"࠭࠯ࠨ嵧").join(l1ll11ll111l_l1_[:4])
	#	tmp = re.findall(l11lll_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀ࠱࠲࠲࠯ࡅ࠯ࠪࠪ࠱࠮ࡄ࠯ࠤࠨ嵨"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11lll_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ嵩")+tmp[0][1]+l11lll_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ嵪")
	#	#return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭嵫"),[l11lll_l1_ (u"ࠫࠬ嵬")],[url]
	#	#l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1l1l1ll_l1_(url)
	#	#return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
	# l1l111lll_l1_ link
	#return l11lll_l1_ (u"ࠬ࠭嵭"),[l11lll_l1_ (u"࠭ࠧ嵮")],[link]
def l1l1l11l11l1_l1_(link):
	# https://l1111l111111_l1_.l1111l1l1lll_l1_/l1llll1111111_l1_?_1llllll1ll1l_l1_=l1llll11lll11_l1_&_1111111111l_l1_=86046&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠧࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠫ嵯") in link:
		headers = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ嵰"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ嵱")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嵲"),link,l11lll_l1_ (u"ࠫࠬ嵳"),headers,l11lll_l1_ (u"ࠬ࠭嵴"),l11lll_l1_ (u"࠭ࠧ嵵"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠷ࡳࡵࠩ嵶"))
		url = response.content
		if url: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嵷"),[l11lll_l1_ (u"ࠩࠪ嵸")],[url]
	else:
		# https://l1lllll11ll1l_l1_.net/?l11llll1_l1_=142302&l1l11111_l1_=4
		parts = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ嵹"),link,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11lll_l1_ (u"ࠫࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ嵺"),link,re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		server = SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嵻"))
		#url = server+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡘ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ嵼")
		url = server+l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ嵽")
		#url = server+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭嵾")+l11llll1_l1_+l11lll_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭嵿")+l1l11111_l1_
		#data = {l11lll_l1_ (u"ࠪ࡭ࡩ࠭嶀"):l11llll1_l1_,l11lll_l1_ (u"ࠫ࡮࠭嶁"):l1l11111_l1_,l11lll_l1_ (u"ࠬࡳࡥࡵࡣࠪ嶂"):l11lll_l1_ (u"࠭࡯࡭ࡦࡢࡷࡪࡸࡶࡦࡴࡶࠫ嶃"),l11lll_l1_ (u"ࠧࡵࡻࡳࡩࠬ嶄"):l11lll_l1_ (u"ࠨࡱ࡯ࡨࠬ嶅")}
		data = {l11lll_l1_ (u"ࠩ࡬ࡨࠬ嶆"):l11llll1_l1_,l11lll_l1_ (u"ࠪ࡭ࠬ嶇"):l1l11111_l1_}
		headers = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ嶈"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭嶉"),l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ嶊"):link}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ嶋"),url,data,headers,l11lll_l1_ (u"ࠨࠩ嶌"),l11lll_l1_ (u"ࠩࠪ嶍"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬ嶎"))
		l11lll1l_l1_ = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嶏"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嶐"),[l11lll_l1_ (u"࠭ࠧ嶑")],[l11l11l_l1_]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ嶒"),[],[]
def l111l111111l_l1_(l1llll1ll1l1l_l1_):
	l11l1l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡵࡷࡶࠬ嶓"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ嶔"),l11lll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࡡ࡙ࡉࡗࡏࡆࡊࡅࡄࡘࡎࡕࡎࠨ嶕"))
	headers = {l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ嶖"):l11l1l1l1_l1_} if l11l1l1l1_l1_ else l11lll_l1_ (u"ࠬ࠭嶗")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ嶘"),l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠧࠨ嶙"),headers,l11lll_l1_ (u"ࠨࠩ嶚"),l11lll_l1_ (u"ࠩࠪ嶛"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪ嶜"))
	l1llll1lll1l1_l1_ = response.content
	l1lllll1l1l1l_l1_ = str(response.headers)
	l1llllll1l1ll_l1_ = l1lllll1l1l1l_l1_+l1llll1lll1l1_l1_
	if l11lll_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ嶝") in l1llllll1l1ll_l1_: l1ll1ll1l_l1_ = True
	else:
		l1llll11lllll_l1_,token,l111l1l1l111_l1_,l1llll1lll11l_l1_,l1ll1ll1l_l1_ = l11lll_l1_ (u"ࠬ࠭嶞"),l11lll_l1_ (u"࠭ࠧ嶟"),l11lll_l1_ (u"ࠧࠨ嶠"),l11lll_l1_ (u"ࠨࠩ嶡"),False
		l111l1llll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠭ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠰࠭ࡃࡦࡩࡴࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡩࡵࡧ࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嶢"),l1llll1lll1l1_l1_,re.DOTALL)
		if l111l1llll11_l1_: l111l1l1l111_l1_,l1llll1lll11l_l1_ = l111l1llll11_l1_[0]
		l11111lll111_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ嶣")][7]
		user = l11llll1111_l1_(32)
		if 0:
			data = {l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ嶤"):user,l11lll_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭嶥"):l11l1llllll_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ嶦"):l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠧ࡬ࡧࡼࠫ嶧"):l1llll1lll11l_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࠫ嶨"):l11lll_l1_ (u"ࠩࠪ嶩"),l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ嶪"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡶࡴ࡯ࡷࠬ嶫")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ嶬"),l11111lll111_l1_,data,l11lll_l1_ (u"࠭ࠧ嶭"),l11lll_l1_ (u"ࠧࠨ嶮"),l11lll_l1_ (u"ࠨࠩ嶯"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠸࡮ࡥࠩ嶰"))
			html = response.content
		html = l11lll_l1_ (u"ࠪࠫ嶱")
		if html.startswith(l11lll_l1_ (u"࡚ࠫࡘࡌࡔ࠿ࠪ嶲")):
			l11l1ll11ll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ嶳"),html.split(l11lll_l1_ (u"࠭ࡕࡓࡎࡖࡁࠬ嶴"),1)[1])
			for request in l11l1ll11ll1_l1_:
				url = request[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ嶵")]
				method = request[l11lll_l1_ (u"ࠨ࡯ࡨࡸ࡭ࡵࡤࠨ嶶")]
				data = request[l11lll_l1_ (u"ࠩࡧࡥࡹࡧࠧ嶷")]
				headers = request[l11lll_l1_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫ嶸")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠫࠬ嶹"),l11lll_l1_ (u"ࠬ࠭嶺"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠶ࡶࡩ࠭嶻"))
				l1llll1lll1l1_l1_ = response.content
				if l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ嶼") in l1llll1lll1l1_l1_:
					l1ll1ll1l_l1_ = True
					break
				l1lllll1l1l1l_l1_ = str(response.headers)
				l1llllll1l1ll_l1_ = l1lllll1l1l1l_l1_+l1llll1lll1l1_l1_
				l1llll11lllll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡤ࡯ࡼࡧ࡭ࡗࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡢࡷࠬࠫ࠱࠮ࡄࠨࠨࡦࡻࡍ࠲࠯ࡅࠩࠣࠩ嶽"),l1llllll1l1ll_l1_,re.DOTALL)
				token = re.findall(l11lll_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡺ࡯࡬ࡧࡱ࠲࠯ࡅࠢࠩ࠲࠶ࡅ࠳࠰࠿ࠪࠤࠪ嶾"),l1llllll1l1ll_l1_,re.DOTALL)
				if token: token = token[0]
				if l1llll11lllll_l1_ or token: break
		if not l1ll1ll1l_l1_:
			if not l1llll11lllll_l1_:
				if not token and l111l1llll11_l1_:
					if 1 and not html.startswith(l11lll_l1_ (u"ࠪࡍࡉࡃࠧ嶿")):
						data = {l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ巀"):user,l11lll_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭巁"):l11l1llllll_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ巂"):l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠧ࡬ࡧࡼࠫ巃"):l1llll1lll11l_l1_,l11lll_l1_ (u"ࠨ࡫ࡧࠫ巄"):l11lll_l1_ (u"ࠩࠪ巅"),l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ巆"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡪࡦࠪ巇")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ巈"),l11111lll111_l1_,data,l11lll_l1_ (u"࠭ࠧ巉"),l11lll_l1_ (u"ࠧࠨ巊"),l11lll_l1_ (u"ࠨࠩ巋"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩ巌"))
						html = response.content
					else: html = l11lll_l1_ (u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫ巍")
					if html.startswith(l11lll_l1_ (u"ࠫࡎࡊ࠽ࠨ巎")):
						l1llllll1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫ巏"),html,re.DOTALL)
						l1lllllllllll_l1_,timeout = l1llllll1lll1_l1_[0]
						message = l11lll_l1_ (u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫ巐")+timeout+l11lll_l1_ (u"ࠧࠡอส๊๏ฯࠧ巑")
						l11l1ll11l_l1_ = DIALOG_PROGRESS()
						l11l1ll11l_l1_.create(l11lll_l1_ (u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧ巒"),message)
						t1 = time.time()
						l111ll1l1l11_l1_,l111l1ll1l11_l1_ = 0,0
						while l111ll1l1l11_l1_<int(timeout):
							PROGRESS_UPDATE(l11l1ll11l_l1_,int(l111ll1l1l11_l1_/int(timeout)*100),message,l11lll_l1_ (u"ࠩࠪ巓"),timeout+l11lll_l1_ (u"ࠪࠤ࠴ࠦࠧ巔")+str(int(l111ll1l1l11_l1_))+l11lll_l1_ (u"ࠫࠥࠦหศ่ํอࠬ巕"))
							#if l11l1ll11l_l1_.iscanceled(): break
							if l111ll1l1l11_l1_>l111l1ll1l11_l1_+10:
								data = {l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ巖"):user,l11lll_l1_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧ巗"):l11l1llllll_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ巘"):l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠨ࡭ࡨࡽࠬ巙"):l1llll1lll11l_l1_,l11lll_l1_ (u"ࠩ࡬ࡨࠬ巚"):l1lllllllllll_l1_,l11lll_l1_ (u"ࠪ࡮ࡴࡨࠧ巛"):l11lll_l1_ (u"ࠫ࡬࡫ࡴࡵࡱ࡮ࡩࡳ࠭巜")}
								response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ川"),l11111lll111_l1_,data,l11lll_l1_ (u"࠭ࠧ州"),l11lll_l1_ (u"ࠧࠨ巟"),l11lll_l1_ (u"ࠨࠩ巠"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩ巡"))
								html = response.content
								if html.startswith(l11lll_l1_ (u"ࠪࡘࡔࡑࡅࡏ࠿ࠪ巢")):
									token = html.split(l11lll_l1_ (u"࡙ࠫࡕࡋࡆࡐࡀࠫ巣"),1)[1]
									break
								l111l1ll1l11_l1_ = l111ll1l1l11_l1_
							else: time.sleep(1)
							l111ll1l1l11_l1_ = time.time()-t1
						l11l1ll11l_l1_.close()
				if token:
					l111l1l1l1ll_l1_ = response.cookies
					l1l11111lll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠮࠮ࠫࡁࠬ࠿ࠬ巤"),l1llllll1l1ll_l1_,re.DOTALL)
					if l11lll_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭工") in list(l111l1l1l1ll_l1_.keys()): l1l11111lll1_l1_ = l111l1l1l1ll_l1_[l11lll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ左")]
					elif l1l11111lll1_l1_: l1l11111lll1_l1_ = l1l11111lll1_l1_[0]
					l111l1llll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭巧"),l1llll1lll1l1_l1_,re.DOTALL)
					if l111l1llll11_l1_: l111l1l1l111_l1_,l1llll1lll11l_l1_ = l111l1llll11_l1_[0]
					if l1l11111lll1_l1_ and l111l1llll11_l1_:
						headers = {l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ巨"):l11lll_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠫ巩")+l1l11111lll1_l1_,l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ巪"):l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ巫"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ巬")}
						data = l11lll_l1_ (u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫࠽ࠨ巭")+token
						response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭差"),l111l1l1l111_l1_,data,headers,False,l11lll_l1_ (u"ࠩࠪ巯"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠶ࡵࡪࠪ巰"))
						l1llll1lll1l1_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l1llll11lllll_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬ࠮ࡡ࡬ࡹࡤࡱ࡛࡫ࡲࡪࡨ࡬ࡧࡦࡺࡩࡰࡰ࠱࠮ࡄ࠯ࠧ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ己"),str(cookies),re.DOTALL)
			if l1llll11lllll_l1_:
				name,l1llll11lllll_l1_ = l1llll11lllll_l1_[0]
				l11l1l1l1_l1_ = name+l11lll_l1_ (u"ࠬࡃࠧ已")+l1llll11lllll_l1_
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ巳"),l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒࡥࡖࡆࡔࡌࡊࡎࡉࡁࡕࡋࡒࡒࠬ巴"),l11l1l1l1_l1_,PERMANENT_CACHE)
				DIALOG_OK(l11lll_l1_ (u"ࠨࠩ巵"),l11lll_l1_ (u"ࠩࠪ巶"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭巷"),l11lll_l1_ (u"๋ࠫาอหࠢ฼้้๐ษࠡใะูࠥษๆศࠢศุ๊อๆࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอิา็้ࠢฮฬฬฬ้ࠡำหࠥอไโฯุࠤ้้๊ࠡ์ึฮำีๅ่ษ่ࠣฬำโศࠢ࠱࠲ࠥ๎ไศࠢอ์ัีࠠฮษฯอ๊ࠥลฺษาอࠥํะศࠢส่ๆำีࠡๆ฼ำฮࠦรี้ิࠤࡡࡴ࡜࡯ࠢ฼่๊อࠠฤ่๋ࠣีอࠠศๆไัฺࠦำ้ใࠣ๎ฯ้ัาࠢไ๎ࠥำวๅหࠣฮ฿๐ัࠡำห฻ࠥอไอ้สึࠥฮวๅว้ฮึ์สࠡ࠰࠱ࠤศ๎ࠠฦูไหฦࠦัศ๊อีࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦแึๆࠣื้้ࠠศๆิหํะัࠡ࠰࠱ࠤศ๎ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡสิ์ู่๊ࠨ巸"))
				if l11lll_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ巹") not in l1llll1lll1l1_l1_:
					headers = {l11lll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭巺"):l11l1l1l1_l1_}
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ巻"),l1llll1ll1l1l_l1_,l11lll_l1_ (u"ࠨࠩ巼"),headers,l11lll_l1_ (u"ࠩࠪ巽"),l11lll_l1_ (u"ࠪࠫ巾"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠸ࡶ࡫ࠫ巿"))
					l1llll1lll1l1_l1_ = response.content
	if not l1ll1ll1l_l1_ and not l11l1l1l1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭帀"),l11lll_l1_ (u"࠭ࠧ币"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ市"),l11lll_l1_ (u"ࠨ฻่่๏ฯࠠโฯุࠤศ์วࠡล้ืฬ์ࠠโึ็ฮࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨ布"))
	return l1llll1lll1l1_l1_
def l111111_l1_(url,type,l11l111l_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ帄"),l11lll_l1_ (u"ࠪࠫ帅"),url,type)
	# http://l11111l11l11_l1_.l111ll1lll1l_l1_.io/link/136530
	l1lllll1_l1_,l1llll1ll1l_l1_ = [],[]
	#l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ帆"),l11lll_l1_ (u"ࠬ࠭帇"),True,l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍ࠮࠳ࡶࡸࠬ师"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ帉"),url,l11lll_l1_ (u"ࠨࠩ帊"),l11lll_l1_ (u"ࠩࠪ帋"),l11lll_l1_ (u"ࠪࠫ希"),l11lll_l1_ (u"ࠫࠬ帍"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ帎"))
	l11lll1l_l1_ = response.content
	l111l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࡁ࠵ࡡ࠿ࠩ帏"),l11lll1l_l1_,re.DOTALL)
	for block in l111l11_l1_:
		links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ帐"),block,re.DOTALL)
		for link,title in links:
			if link in l1lllll1_l1_: continue
			if l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ帑") not in link and l11lll_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭帒") not in link: continue
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫ帓"),l11lll_l1_ (u"ࠫࠬ帔")).replace(l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ帕"),l11lll_l1_ (u"࠭ࠧ帖")).strip(l11lll_l1_ (u"ࠧࠡࠩ帗")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ帘"),l11lll_l1_ (u"ࠩࠣࠫ帙"))
			l1lllll1_l1_.append(link)
			l1llll1ll1l_l1_.append(title)
	if len(l1lllll1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪฬ฾฼็ศࠢํัฯอฬࠡ࠸࠳ࠤะอๆ๋หࠪ帚"),l1llll1ll1l_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ帛"),[],[]
	elif len(l1lllll1_l1_)==1: l1l_l1_ = 0
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭帜"),[],[]
	l1llll1ll1l1l_l1_ = l1lllll1_l1_[l1l_l1_]
	l1llll1lll1l1_l1_ = l111l111111l_l1_(l1llll1ll1l1l_l1_)
	l1111_l1_,l1lll1ll_l1_ = [],[]
	if type==l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ帝"):
		l11111l11111_l1_ = re.findall(l11lll_l1_ (u"ࠧࡣࡶࡱ࠱ࡱࡵࡡࡥࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ帞"),l1llll1lll1l1_l1_,re.DOTALL)
		if l11111l11111_l1_:
			link = l111l_l1_(l11111l11111_l1_[0])
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(l11l111l_l1_)
	elif type==l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ帟"):
		links = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ帠"),l1llll1lll1l1_l1_,re.DOTALL)
		for link,size in links:
			if not link: continue
			if l11l111l_l1_ in size:
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
				break
		if not l1111_l1_:
			for link,size in links:
				if not link: continue
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ帡"),l1111_l1_)
	if not l1111_l1_: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ帢"),[],[]
	return l11lll_l1_ (u"ࠬ࠭帣"),l1lll1ll_l1_,l1111_l1_
def l1l111l_l1_(url,name):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ帤"),l11lll_l1_ (u"ࠧࠨ帥"),url,l111ll1ll11l_l1_)
	# http://l11l1l11111_l1_.l1111111l11l_l1_.net/5cf68c23e6e79			?l111ll1ll11l_l1_=			__11l1111111l_l1_
	# http://w.l11ll1l1_l1_.l1ll1ll111l_l1_/5e14fd0a2806e			?l111ll1ll11l_l1_=			ok.l11111l1l1ll_l1_
	#l111ll1ll11l_l1_ = l111ll1ll11l_l1_.replace(l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࡟ࡠࠩ带"),l11lll_l1_ (u"ࠩࠪ帧")).split(l11lll_l1_ (u"ࠪࡣࡤ࠭帨"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ帩"),url,l11lll_l1_ (u"ࠬ࠭帪"),l11lll_l1_ (u"࠭ࠧ師"),True,l11lll_l1_ (u"ࠧࠨ帬"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧ席"))
	html = response.content
	cookies = response.cookies
	if l11lll_l1_ (u"ࠩࡪࡳࡱ࡯࡮࡬ࠩ帮") in list(cookies.keys()):
		l11l1l1l1_l1_ = cookies[l11lll_l1_ (u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪ帯")]
		l11l1l1l1_l1_ = l111l_l1_(escapeUNICODE(l11l1l1l1_l1_))
		items = re.findall(l11lll_l1_ (u"ࠫࡷࡵࡵࡵࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ帰"),l11l1l1l1_l1_,re.DOTALL)
		l11l11l_l1_ = items[0].replace(l11lll_l1_ (u"ࠬࡢ࠯ࠨ帱"),l11lll_l1_ (u"࠭࠯ࠨ帲"))
		l11l11l_l1_ = escapeUNICODE(l11l11l_l1_)
	else: l11l11l_l1_ = url
	if l11lll_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ帳") in l11l11l_l1_:
		id = l11l11l_l1_.split(l11lll_l1_ (u"ࠨࠧ࠵ࡊࠬ帴"))[-1]
		l11l11l_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡥࡹࡩࡨ࠯࡫ࡶ࠳ࠬ帵")+id
		return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭帶"),[l11lll_l1_ (u"ࠫࠬ帷")],[l11l11l_l1_]
	else:
		l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ常")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ帹"),l1l1ll11_l1_,l11lll_l1_ (u"ࠧࠨ帺"),l11lll_l1_ (u"ࠨࠩ帻"),True,l11lll_l1_ (u"ࠩࠪ帼"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠸࡮ࡥࠩ帽"))
		l111ll1l1lll_l1_ = response.url
		#l111ll1l1lll_l1_ = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭帾")]
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭帿"),l11lll_l1_ (u"࠭ࠧ幀"),response.url,l1l1ll11_l1_)
		l11111lll1l1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠧ࠰ࠩ幁"))[2]#.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭幂"))
		l11l1111ll11_l1_ = l111ll1l1lll_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ幃"))[2]#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幄"))
		l11l1l1_l1_ = l11l11l_l1_.replace(l11111lll1l1_l1_,l11l1111ll11_l1_)
		headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ幅"):l11lll_l1_ (u"ࠬ࠭幆") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ幇"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ幈") , l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ幉"):l11l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ幊"), l11l1l1_l1_, l11lll_l1_ (u"ࠪࠫ幋"), headers, False,l11lll_l1_ (u"ࠫࠬ幌"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠴ࡴࡧࠫ幍"))
		html = response.content
		#xbmc.log(str(l11l1l1_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭幎"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ幏"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡨࡱࡧ࡫ࡤ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ幐"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ幑"),l11lll_l1_ (u"ࠪࠫ幒"),str(items),html)
		if items:
			link = items[0].replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ幓"),l11lll_l1_ (u"ࠬ࠵ࠧ幔"))
			link = link.rstrip(l11lll_l1_ (u"࠭࠯ࠨ幕"))
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ幖") not in link: link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ幗") + link
			link = link.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ幘"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ幙"))
			if name==l11lll_l1_ (u"ࠫࠬ幚"): l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭幛"),[l11lll_l1_ (u"࠭ࠧ幜")],[link]
			else: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ幝"),[l11lll_l1_ (u"ࠨࠩ幞")],[link]
		else: l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡏࡂࡏࠪ幟"),[],[]
		return l111llll1lll_l1_,l1lll1ll_l1_,l1111_l1_
def l111l1ll1ll1_l1_(url):
	# https://www.l111ll111l1l_l1_.com/e/l1lllll1l1l11_l1_
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ幠") : l11lll_l1_ (u"ࠫࠬ幡") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭幢"),headers,l11lll_l1_ (u"࠭ࠧ幣"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ幤"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ幥"),l11lll_l1_ (u"ࠩࠪ幦"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ幧"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠫࠬ幨")
	if items:
		for link,l1ll11l1l111_l1_ in items:
			l1lll1ll_l1_.append(l1ll11l1l111_l1_)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒࠫ幩"),[],[]
	return l11lll_l1_ (u"࠭ࠧ幪"),l1lll1ll_l1_,l1111_l1_
def l1llllll11ll1_l1_(url):
	# https://l111111l11ll_l1_.io/l1l111lll_l1_-l1llllll1l111_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ幫"),l11lll_l1_ (u"ࠨࠩ幬"))
	headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭幭"):l11lll_l1_ (u"ࠪࠫ幮")}
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ幯"),headers,l11lll_l1_ (u"ࠬ࠭幰"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡕࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭幱"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ干"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ平"),l11lll_l1_ (u"ࠩࠪ年"),url,items[0])
	if items:
		url = items[0]+l11lll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭幵")+url
		return l11lll_l1_ (u"ࠫࠬ并"),[l11lll_l1_ (u"ࠬ࠭幷")],[url]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨ幸"),[],[]
def l1111ll11111_l1_(url):
	# https://l1llll111111l_l1_.to/l1l111lll_l1_/5c83f14297d62
	url = url.strip(l11lll_l1_ (u"ࠧ࠰ࠩ幹"))
	if l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ幺") in url: id = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ幻"))[4]
	else: id = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ幼"))[-1]
	url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ幽") + id
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ幾") : l11lll_l1_ (u"࠭ࠧ广") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ庀"),headers,l11lll_l1_ (u"ࠨࠩ庁"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡃࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ庂"))
	html = html.replace(l11lll_l1_ (u"ࠪࡠࡡ࠭広"),l11lll_l1_ (u"ࠫࠬ庄"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭庅"),l11lll_l1_ (u"࠭ࠧ庆"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ庇"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠨࠩ庈"),[l11lll_l1_ (u"ࠩࠪ庉")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧ床"),[],[]
def l1llllllll1l1_l1_(url):
	# https://l111lll1l1l1_l1_.net/l1l111lll_l1_-l111l1l1111l_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ庋"),l11lll_l1_ (u"ࠬ࠭庌"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ庍"),l11lll_l1_ (u"ࠧࠨ庎"),l11lll_l1_ (u"ࠨࠩ序"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡑ࡝ࡅ࠲࠷ࡳࡵࠩ庐"))
	items = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠥࡸࡥࡴ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ庑"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for link,l1ll11l1l111_l1_,res in items:
		l1lll1ll_l1_.append(l1ll11l1l111_l1_+l11lll_l1_ (u"ࠫࠥ࠭庒")+res)
		l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧ库"),[],[]
	return l11lll_l1_ (u"࠭ࠧ应"),l1lll1ll_l1_,l1111_l1_
def l1111lllllll_l1_(url):
	# https://l111lllll111_l1_.l1ll1l1ll1l_l1_/l1l111lll_l1_-l11111111lll_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ底"),l11lll_l1_ (u"ࠨࠩ庖"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ店"),l11lll_l1_ (u"ࠪࠫ庘"),l11lll_l1_ (u"ࠫࠬ庙"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ庚"))
	items = re.findall(l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡂ࠯ࡵࡦࡁࠦ庛"),html,re.DOTALL)
	items = set(items)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for id,mode,hash,l1ll11l1l111_l1_,res in items:
		url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳ࠳ࡻࡳ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ府")+id+l11lll_l1_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ庝")+mode+l11lll_l1_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ庞")+hash
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ废"),l11lll_l1_ (u"ࠫࠬ庠"),l11lll_l1_ (u"ࠬ࠭庡"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪ庢"))
		items = re.findall(l11lll_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭庣"),html,re.DOTALL)
		for link in items:
			l1lll1ll_l1_.append(l1ll11l1l111_l1_+l11lll_l1_ (u"ࠨࠢࠪ庤")+res)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏࠨ庥"),[],[]
	return l11lll_l1_ (u"ࠪࠫ度"),l1lll1ll_l1_,l1111_l1_
def l1llll11111l1_l1_(url):
	# https://l1llll11llll1_l1_.com:2053/l1llll1l111l1_l1_/l111111111l1_l1_.l111l111ll1l_l1_.l11l11111lll_l1_.1080p.l111llllllll_l1_.l111ll1ll111_l1_.l1llll11l111l_l1_.l1111lll_l1_.html?l1111llll11l_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111l1l111l1_l1_=1624070560
	# http://l1llll1llll11_l1_.l1111llllll_l1_/l111l1111lll_l1_/l111l11l111l_l1_.l1111l11l11l_l1_.l111l11lll1l_l1_.2018.1080p.l11111lll11l_l1_-l1111l1l1l1l_l1_.l1111ll11l1l_l1_.l1111lll_l1_.html
	link = l11lll_l1_ (u"ࠫࠬ座")
	if 1 or l11lll_l1_ (u"ࠬࡑࡥࡺ࠿ࠪ庨") not in url:
		l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭ࡵࡱࡤࡲࡱ࠳ࡲࡩࡷࡧࠪ庩"),l11lll_l1_ (u"ࠧࡶࡲࡳࡳࡲ࠴࡬ࡪࡸࡨࠫ庪"))
		l11l11l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠨ࠱ࠪ庫"))
		id = l11l11l_l1_[3]
		l11l11l_l1_ = l11lll_l1_ (u"ࠩ࠲ࠫ庬").join(l11l11l_l1_[0:4])
		#headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ庭"):l1l11111l_l1_(),l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ庮"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ庯")}
		payload = {l11lll_l1_ (u"࠭ࡩࡥࠩ庰"):id,l11lll_l1_ (u"ࠧࡰࡲࠪ庱"):l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ庲"),l11lll_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧ庳"):l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪ庴")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ庵"),l11l11l_l1_,payload,l11lll_l1_ (u"ࠬ࠭庶"),l11lll_l1_ (u"࠭ࠧ康"),l11lll_l1_ (u"ࠧࠨ庸"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠵ࡸࡺࠧ庹"))
		if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ庺") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ庻")]
		if not link and response.succeeded:
			html = response.content
			link = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ庼"),html,re.DOTALL)
			if link: link = link[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ庽"),url,l11lll_l1_ (u"࠭ࠧ庾"),l11lll_l1_ (u"ࠧࠨ庿"),l11lll_l1_ (u"ࠨࠩ廀"),l11lll_l1_ (u"ࠩࠪ廁"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩ廂"))
		if l11lll_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭廃") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ廄")]
	if link: return l11lll_l1_ (u"࠭ࠧ廅"),[l11lll_l1_ (u"ࠧࠨ廆")],[link]
	return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡕࡈࡏࡎࠩ廇"),[],[]
def l1111ll11lll_l1_(url):
	# https://www.l1111l1111l1_l1_.com/012ocyw9li6g.html
	headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭廈") : l11lll_l1_ (u"ࠪࠫ廉") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ廊"),headers,l11lll_l1_ (u"ࠬ࠭廋"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ廌"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭廍"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	if items:
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨ࡯ࡳ࠸ࠬ廎"))
		l1111_l1_.append(items[0][1])
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ廏"))
		l1111_l1_.append(items[0][0])
		return l11lll_l1_ (u"ࠪࠫ廐"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ廑"),[],[]
def l111llll11l_l1_(url):
	# l111l111ll11_l1_ l111ll1111ll_l1_			url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡜࠻࡜࠺࠱ࡗࡏࡻࡽࡖࡋࠧ廒")
	# l1llll1l1ll11_l1_ .l11l111111l1_l1_ l111ll1111ll_l1_		url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡜ࡻࡳࡓࡏࡃࡼࡩࡾࡌࡉࠨ廓")
	# l111l111l111_l1_ l11l1l1lll_l1_ .l1llll1l1_l1_ l111ll1111ll_l1_		url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡌ࡬࠲࠮ࡐࡖࡸࡘࡹࡎࡸࠩ廔")
	# l1111ll1ll1l_l1_ l111ll1111ll_l1_			url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡫࡟ࡔ࠻࡙ࡺࡏࡓ࠱ࡑࡋࠪ廕")
	# l111l11lll_l1_ files have l1111ll1111l_l1_ l1l111l1l1l1_l1_		url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃ࠱ࡸࡆࡕ࡙࡛ࡩࡓࡺࡡࡔࠫ廖")
	# url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ廗")
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾ࠸ࡵ࠯ࡤࡨ࠳ࡪࡊ࡬࡛࠷ࡹࡅࡓࡗࡕࡨࠩ廘")
	# url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡧࡰࡦࡪࡪ࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ廙")
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨ廚")
	# url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡵࡌࡅ࡭࡭࡬ࡣࡏ࠷࡙࡬ࠨࡤࡦࡤࡩࡨࡢࡰࡱࡩࡱࡃࡇࡰ࡮ࡧࡩࡳࡒࡩ࡯ࡧࡩࡳࡷ࡚ࡖࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡥࡳࡪࡄࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡄࡹࡹ࡯ࡦ࡬ࡧࡦࡺࡩࡰࡰࡀ࠶࠼࠽࠵࠸࠷ࠪ廛")
	# l1ll1llll_l1_ l1llllll111l1_l1_ details   https://l11111111ll1_l1_.me/l1llll11ll11l_l1_/l1llll111l1l1_l1_-l1llll11ll111_l1_-l1lllll1lllll_l1_
	id = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ廜"))[-1]
	id = id.split(l11lll_l1_ (u"ࠩࠩࠫ廝"))[0]
	id = id.replace(l11lll_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ廞"),l11lll_l1_ (u"ࠫࠬ廟"))
	#id = l11lll_l1_ (u"ࠬ࡫࡟ࡔ࠻࡙ࡺࡏࡓ࠱ࡑࡋࠪ廠")
	#url = l11lll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ廡")+id
	#return l11lll_l1_ (u"ࠧࠨ廢"),[l11lll_l1_ (u"ࠨࠩ廣")],[url]
	l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ廤")][0]+l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭廥")+id
	l1llll1111l11_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࠧ廦")+id
	l1111l11l1ll_l1_,l1llll1l1111l_l1_,l11l1111l111_l1_,l1llll1ll11l1_l1_ = l11lll_l1_ (u"ࠬ࠭廧"),l11lll_l1_ (u"࠭ࠧ廨"),l11lll_l1_ (u"ࠧࠨ廩"),l11lll_l1_ (u"ࠨࠩ廪")
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠩࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࡟ࠫ࠱࠭ࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡲ࡯ࡥࡾ࡫ࡲࡄࡣࡳࡸ࡮ࡵ࡮ࡴࡖࡵࡥࡨࡱ࡬ࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶ࠭࠴ࠪࡀࠫࡧࡩ࡫ࡧࡵ࡭ࡶࡄࡹࡩ࡯࡯ࡕࡴࡤࡧࡰࡏ࡮ࡥࡧࡻࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠫ࠭ࠩࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡾࠦࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡉ࡯ࡥࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠ࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪࡡ࠱ࡡࠧࠨ࡟ࠍࠍࠎࠏࡦࡰࡴࠣࡰࡦࡴࡧ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯ࡥࡳ࡭ࠩࠋࠋࠌࠍࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ࠲ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࠬࠎࠎࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࡮ࡰࡶࠣ࡭ࡳ࡛ࠦ࠱࠮࠰࠵ࡢࡀࠊࠊࠋࠌࠍࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࠏࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏ࡟࠵ࡣࠫࠨࠨࡩࡱࡹࡃࡶࡵࡶࠩࡸࡾࡶࡥ࠾ࡶࡵࡥࡨࡱࠦࡵ࡮ࡤࡲ࡬ࡃࠧࠬ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࠴࠭ࠠࡪࡰࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠾ࠥࡪࡡࡴࡪࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡨࡦࡹࡨࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡷ࠴࠭ࠬࠨ࠱ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࠴࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍ࡭ࡲࡳࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠦ࡬ࡹࡳ࡬࠳ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯࡬ࡱࡹࡕࡓࡎ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧࠪࠌࠌࠍࠨ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡝࠳ࡍࡆࡆࡌࡅ࠿࡛ࡒࡊ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖ࠰ࡌࡘࡏࡖࡒ࠰ࡍࡉࡃࠢࡷࡶࡷࠫ࠱࡮ࡴ࡮࡮࠵࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠠࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠥ࠮ࠫࠫ࡬࡭ࡵ࠿ࡹࡸࡹࠬࡴࡺࡲࡨࡁࡹࡸࡡࡤ࡭ࠩࡸࡱࡧ࡮ࡨ࠿ࠪࠎࠎࡨ࡬ࡰࡥ࡮ࡷ࠱ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠱࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲ࡻࡾࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡷࡵࡰࡤ࡫࡮ࡤࡱࡧࡩࡩࡥࡦ࡮ࡶࡢࡷࡹࡸࡥࡢ࡯ࡢࡱࡦࡶࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡤࡨࡦࡶࡴࡪࡸࡨࡣ࡫ࡳࡴࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡩࡧࠢࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪࡲࡺ࡟࡭࡫ࡶࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠢ࠿࡞ࠫࠬࡣ࠺ࠋࠋࠌࠍ࡫ࡳࡴࡠ࡮࡬ࡷࡹࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡬࡭ࡵࡡ࡬ࡸࡦ࡭ࡳࠡ࠿ࠣࡪࡲࡺ࡟࡭࡫ࡶࡸ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠲ࠧࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣࡪࡲࡺ࡟ࡪࡶࡤ࡫ࡸࡀࠊࠊࠋࠌࠍ࡮ࡺࡡࡨ࠮ࡶ࡭ࡿ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬࠎࠎࠏࠉࠊࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴ࡜࡫ࡷࡥ࡬ࡣࠠ࠾ࠢࡶ࡭ࡿ࡫ࠊࠊࡨࡲࡶࠥࡨ࡬ࡰࡥ࡮ࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡭࡫ࠦ࡮ࡰࡶࠣࡦࡱࡵࡣ࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉ࡭࡫ࡱࡩࡸࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠭ࠩࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴࡥࠡ࡫ࡱࠤࡱ࡯࡮ࡦࡵ࠽ࠎࠎࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࠫࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠬ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋࠌࠍࠨࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨ࡭࡫ࡱࡩ࠱ࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࠊࠋ࡯࡭ࡳ࡫ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡰ࡮ࡴࡥࠪࠌࠌࠍࠎࡪࡩࡤࡶࠣࡁࠥࢁࡽࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡲࡩ࡯ࡧ࠱ࡷࡵࡲࡩࡵࠪࠪࠪࠫ࠭ࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏ࡫ࡦࡻ࠯ࡺࡦࡲࡵࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩࡀࠫ࠱࠷ࠩࠋࠋࠌࠍࠎࡪࡩࡤࡶ࡞࡯ࡪࡿ࡝ࠡ࠿ࠣࡺࡦࡲࡵࡦࠌࠌࠍࠎ࡯ࡦࠡࠩࡶ࡭ࡿ࡫ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭ࠥࡧ࡮ࡥࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠎࠎࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡽࡩࠬࡣࠠ࠾ࠢࡩࡱࡹࡥࡳࡪࡼࡨࡣࡩ࡯ࡣࡵ࡝ࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝࡞ࠌࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶࠬࠎࠎࡨ࡬ࡰࡥ࡮ࡷ࠱ࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠶ࠥࡃࠠ࡜࡟࠯࡟ࡢࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡦࡰࡴࡰࡥࡹࡹࠢ࠻࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠢ࠻࡞࡞ࠬ࠳࠰࠿ࠪ࡞ࡠࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࠪࠫ࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡤ࡯ࡳࡨࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡀࠦࠬ࠲ࠧ࠾ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠢࠣࠩ࠯ࠫࠧ࠭ࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡀࡴࡳࡷࡨࠫ࠱࠭࠺ࡕࡴࡸࡩࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠽ࡪࡦࡲࡳࡦࠩ࠯ࠫ࠿ࡌࡡ࡭ࡵࡨࠫ࠮ࠐࠉࠊ࡫ࡩࠤࠬࡡࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡤ࡯ࡳࡨࡱࠠ࠾ࠢࠪ࡟ࠬ࠱ࡢ࡭ࡱࡦ࡯࠰࠭࡝ࠨࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡦࡱࡵࡣ࡬ࠫࠍࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺࠠࡪࡰࠣࡦࡱࡵࡣ࡬࠼ࠍࠍࠎࠏࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠬࠎࠎࠏࠉࡥ࡫ࡦࡸࡠ࠭ࡴࡺࡲࡨࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩࡠ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠽ࠨ࠮ࠪࡁࠧ࠭ࠩࠬࠩࠥࠫࠏࠏࠉࠊ࡫ࡩࠤࠬ࡬ࡰࡴࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡪࡵࡹࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡧࡲࡶࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ࡞ࠢࡀࠤࡸࡺࡲࠩࡦ࡬ࡧࡹࡡࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡻ࡮ࡪࡴࡩࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡷ࡮ࢀࡥࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡹ࡬ࡨࡹ࡮ࠧ࡞ࠫ࠮ࠫࡽ࠭ࠫࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪ࡬ࡪ࡯ࡧࡩࡶࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࠨ࡟ࠣࡁࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡷࡹࡧࡲࡵࠩࡠ࠯ࠬ࠳ࠧࠬࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡥ࡯ࡦࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࡠ࡟ࠬࡹࡴࡢࡴࡷࠫࡢ࠱ࠧ࠮ࠩ࠮ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡨࡲࡩ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭ࠥࡧ࡮ࡥࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࡂ࠶࠷࠱࠳࠴࠵࠷࠸࠹࠺ࠡࡦࡨࡰࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫ࠽ࠎࠎࠏࠉࠊࡥ࡬ࡴ࡭࡫ࡲࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠦࠨࠫࠍࠍࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥࡩࡩࡱࡪࡨࡶ࠿ࠐࠉࠊࠋࠌࠍࡰ࡫ࡹ࠭ࡸࡤࡰࡺ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠾ࠩ࠯࠵࠮ࠐࠉࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝࡮ࡩࡾࡣࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡺࡦࡲࡵࡦࠫࠍࠍࠎࠏࠣࡪࡨࠣࠫࡺࡸ࡬ࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡸࡶࡱ࠭࡝ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࡝ࠪࡹࡷࡲࠧ࡞ࠫࠍࠍࠎࠏࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷࠴ࡡࡱࡲࡨࡲࡩ࠮ࡤࡪࡥࡷ࠭ࠏࠏࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠲࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠵࠱ࡹࡴࡳࡧࡤࡱࡸ࠸ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠊࠊ࡫ࡩࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴ࠤࡦࡴࡤࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠻ࠌࠌࠍ࡫ࡵࡲࠡࡦ࡬ࡧࡹ࠷ࠠࡪࡰࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠽ࠎࠎࠏࠉࡶࡴ࡯࠵ࠥࡃࠠࡥ࡫ࡦࡸ࠶ࡡࠧࡶࡴ࡯ࠫࡢࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠥࡸࡶࡱ࠷ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇ࡙ࠫࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࠳࡞ࠫࡺࡸ࡬ࠨ࡟ࠬ࠭ࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵ࠴ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࡀࠊࠊࠋࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡩ࡯ࡣࡵ࠴࡞ࠫࡺࡸ࡬ࠨ࡟࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎࠏࠣࡶࡴ࡯࠶ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࠲࡜ࠩࡸࡶࡱ࠭࡝ࠪࠫ࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎࠏࡩࡧࠢࡸࡶࡱ࠷࠽࠾ࡷࡵࡰ࠷ࠦࡡ࡯ࡦࠣࡹࡷࡲ࠱ࠡࡰࡲࡸࠥ࡯࡮ࠡࡷࡵࡰࡤࡲࡩࡴࡶ࠽ࠎࠎࠏࠉࠊࠋࡸࡶࡱࡥ࡬ࡪࡵࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡺࡸ࡬࠲ࠫࠍࠍࠎࠏࠉࠊࡦ࡬ࡧࡹ࠷࠮ࡶࡲࡧࡥࡹ࡫ࠨࡥ࡫ࡦࡸ࠷࠯ࠊࠊࠋࠌࠍࠎࡹࡴࡳࡧࡤࡱࡸ࠶࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠶࠯ࠊࠊࡧ࡯ࡷࡪࡀࠠࡴࡶࡵࡩࡦࡳࡳ࠱ࠢࡀࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠴࠯ࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵ࠎࠎࠨࠢࠣ廫")
	# l1llll1lll111_l1_ json data
	# l1l111lll_l1_ url l111ll1111ll_l1_:    https://www.l1ll1llll_l1_.com/l1l111lll_l1_/l111l11ll1ll_l1_
	# list of l111ll111l11_l1_ & l1l111ll1111_l1_
	# https://github.com/l1lllll1llll1_l1_-l11111llll1l_l1_/l1lllll1llll1_l1_-l11111llll1l_l1_/blob/master/l111l1ll1lll_l1_/l1111l111l11_l1_/l1ll1llll_l1_.py
	# all the below l1llllllll111_l1_ were l1111ll11ll1_l1_ using:	https://www.l1ll1llll_l1_.com/l111lll1111l_l1_/l1l1l1lll1ll_l1_/l11ll1111l1_l1_?l1llll111l11l_l1_=l1llll1l11l1l_l1_	&	l111l1l1ll1l_l1_ = l111l11ll1ll_l1_
	# 3 l1ll111l1111_l1_:	13KB:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ廬"): l11lll_l1_ (u"ࠫࡎࡕࡓࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ廭"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ廮"): l11lll_l1_ (u"࠭࠲࠳࠰࠶࠷࠳࠷࠰࠲ࠩ廯")
	# 7 l1ll111l1111_l1_		44KB:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ廰"): l11lll_l1_ (u"ࠨࡋࡒࡗࡤࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡆ࡚ࡗࡉࡓ࡙ࡉࡐࡐࠪ廱"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ廲"): l11lll_l1_ (u"ࠪ࠵࠼࠴࠳࠴࠰࠵ࠫ廳")
	# 7 l1ll111l1111_l1_		58KB:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ廴"): l11lll_l1_ (u"ࠬࡏࡏࡔࠩ廵"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭延"): l11lll_l1_ (u"ࠧ࠲࠹࠱࠷࠸࠴࠲ࠨ廷")
	# 9 l1ll111l1111_l1_		24KB:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ廸"): l11lll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡇࡗࡋࡁࡕࡑࡕࠫ廹"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ建"): l11lll_l1_ (u"ࠫ࠷࠸࠮࠴࠲࠱࠵࠵࠶ࠧ廻")
	# no json file:		21 l1ll111l1111_l1_	95KB:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ廼"): l11lll_l1_ (u"࠭ࡗࡆࡄࡢࡇࡗࡋࡁࡕࡑࡕࠫ廽"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ廾"): l11lll_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠵࠺࠳࠶࠰࠯࠲࠳ࠫ廿")
	# no json file:		21 l1ll111l1111_l1_	121KB:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭开"): l11lll_l1_ (u"࡛ࠪࡊࡈࠧ弁"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ异"): l11lll_l1_ (u"ࠬ࠸࠮࠳࠲࠵࠶࠵࠾࠰࠲࠰࠳࠴࠳࠶࠰ࠨ弃")
	# no json file: 	26 l1ll111l1111_l1_	115KB:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ弄"): l11lll_l1_ (u"ࠧࡎ࡙ࡈࡆࠬ弅"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ弆"): l11lll_l1_ (u"ࠩ࠵࠲࠷࠶࠲࠳࠲࠻࠴࠶࠴࠰࠱࠰࠳࠴ࠬ弇")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ弈"): l11lll_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࠬ弉"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ弊"): l11lll_l1_ (u"࠭࠱࠸࠰࠶࠵࠳࠹࠵ࠨ弋")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ弌"): l11lll_l1_ (u"ࠨ࡙ࡈࡆࡤࡘࡅࡎࡋ࡛ࠫ弍"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ弎"): l11lll_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠷࠽࠮࠱࠳࠱࠴࠵࠭式")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ弐"): l11lll_l1_ (u"ࠬ࡝ࡅࡃࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ弑"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭弒"): l11lll_l1_ (u"ࠧ࠲࠰࠵࠴࠷࠸࠰࠸࠵࠴࠲࠵࠶࠮࠱࠲ࠪ弓")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ弔"): l11lll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡉࡒࡈࡅࡅࡆࡈࡈࡤࡖࡌࡂ࡛ࡈࡖࠬ引"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ弖"): l11lll_l1_ (u"ࠫ࠶࠽࠮࠴࠳࠱࠷࠺࠭弗")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ弘"): l11lll_l1_ (u"࠭ࡁࡏࡆࡕࡓࡎࡊ࡟ࡎࡗࡖࡍࡈ࠭弙"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ弚"): l11lll_l1_ (u"ࠨ࠷࠱࠵࠻࠴࠵࠲ࠩ弛")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭弜"): l11lll_l1_ (u"ࠪࡘ࡛ࡎࡔࡎࡎ࠸ࡣࡘࡏࡍࡑࡎ࡜ࡣࡊࡓࡂࡆࡆࡇࡉࡉࡥࡐࡍࡃ࡜ࡉࡗ࠭弝"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ弞"): l11lll_l1_ (u"ࠬ࠸࠮࠱ࠩ弟")
	# l11l11ll1l1l_l1_:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ张"): l11lll_l1_ (u"ࠧࡊࡑࡖࡣࡒ࡛ࡓࡊࡅࠪ弡"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ弢"): l11lll_l1_ (u"ࠩ࠸࠲࠷࠷ࠧ弣")
	# l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ弤")][0]+l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡴࡱࡧࡹࡦࡴࡂࡴࡷ࡫ࡴࡵࡻࡓࡶ࡮ࡴࡴ࠾ࡶࡵࡹࡪ࠭弥")  # l1llll1l11l1l_l1_ l1ll1l1l1ll1_l1_ l1llll1l11l11_l1_ and l1llllll11l11_l1_ l1ll11l1ll11_l1_ l1l1l1llll_l1_ l1lllll11l1ll_l1_ file size
	#l11ll1l11_l1_ = l11lll_l1_ (u"ࠬࢁࠧ弦")l1llll111l111_l1_ (u"࠭࠺ࡪࡦ࠯ࠫ弧")l11111lll1ll_l1_ (u"ࠧ࠻ࡽࠥࡧࡱ࡯ࡥ࡯ࡶࠥ࠾ࢀࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ࠾ࠧࡇࡎࡅࡔࡒࡍࡉࠨࠬࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠥ࠵࠼࠴࠳࠲࠰࠶࠹ࠧࢃࡽࡾࠩ弨")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭弩"),l11l11l_l1_,l11ll1l11_l1_,l11lll_l1_ (u"ࠩࠪ弪"),l11lll_l1_ (u"ࠪࠫ弫"),l11lll_l1_ (u"ࠫࠬ弬"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭弭"))
	#html = response.content
	for l11ll111l1_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭วๅ็ะหํ๊ษࠡำๅ้࠿ࠦࠠࠨ弮")+str(l11ll111l1_l1_+1),l11lll_l1_ (u"ࠧࠨ弯"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ弰"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ弱"),l11lll_l1_ (u"ࠪࠫ弲"),l11lll_l1_ (u"ࠫࠬ弳"),l11lll_l1_ (u"ࠬ࠭弴"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ張"))
		html = response.content
		if l11lll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ弶") in html: break
		time.sleep(2)
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ強"),html)
	l11lll1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡒ࡯ࡥࡾ࡫ࡲࡓࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭弸"),html,re.DOTALL)
	if l11lll1l11_l1_: l11lll1l11_l1_ = l11lll1l11_l1_[0]
	else: l11lll1l11_l1_ = html
	l11lll1l11_l1_ = l11lll1l11_l1_.replace(l11lll_l1_ (u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ弹"),l11lll_l1_ (u"ࠫࠫ࠭强"))
	l1lllll1ll1ll_l1_ = EVAL(l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ弻"),l11lll1l11_l1_)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ弼"),str(l1lllll1ll1ll_l1_))
	# l1llll1lll111_l1_ l111l11lllll_l1_ & l111llllll1l_l1_
	# l1ll1llll_l1_ l111l111ll11_l1_ link l11llll1l_l1_ l11lll_l1_ (u"ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠩ弽") to l111l1l1l1_l1_ on l1111ll111l_l1_
	l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬ弾")],[l11lll_l1_ (u"ࠩࠪ弿")]
	try:
		l111l11lllll_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬ彀")][l11lll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彁")][l11lll_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬ彂")]
		for l1111ll1llll_l1_ in l111l11lllll_l1_:
			link = l1111ll1llll_l1_[l11lll_l1_ (u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧ彃")]
			try: title = l1111ll1llll_l1_[l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ彄")][l11lll_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬ彅")]
			except: title = l1111ll1llll_l1_[l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ彆")][l11lll_l1_ (u"ࠪࡶࡺࡴࡳࠨ彇")][0][l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ彈")]
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(title)
	except: pass
	if len(l1lll1ll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ彉"), l1lll1ll_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ彊"),[],[]
		elif l1l_l1_!=0:
			link = l1111_l1_[l1l_l1_]+l11lll_l1_ (u"ࠧࠧࠩ彋")
			l1111111llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭彌"),link)
			if l1111111llll_l1_: link = link.replace(l1111111llll_l1_[0],l11lll_l1_ (u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪ彍"))
			else: link = link+l11lll_l1_ (u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫ彎")
			l1111l11l1ll_l1_ = link.strip(l11lll_l1_ (u"ࠫࠫ࠭彏"))
	formats,l111lllll1ll_l1_,l111l1lll11l_l1_,l111l1lll1l1_l1_,l111l1lll111_l1_ = [],[],[],[],[]
	# l1llll1lll111_l1_ l1111l1l11l1_l1_ l1ll111l1111_l1_
	try: l1llll1l1111l_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ彐")][l11lll_l1_ (u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨ彑")]
	except: pass
	# l1llll1lll111_l1_ l111l111l111_l1_ stream
	try: l11l1111l111_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ归")][l11lll_l1_ (u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩ当")]
	except: pass
	# l1llll1lll111_l1_ l1ll1l1l1l_l1_ l1111lll_l1_ l1ll111l1111_l1_
	try: formats = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ彔")][l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ录")]
	except: pass
	# l1llll1lll111_l1_ l1ll1l1l1l_l1_ l11l111111l1_l1_ l1ll111l1111_l1_
	try: l111lllll1ll_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ彖")][l11lll_l1_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧ彗")]
	except: pass
	l111l1111l11_l1_ = formats+l111lllll1ll_l1_
	for dict in l111l1111l11_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ彘"),str(dict))
		if l11lll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ彙") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭彚")] = str(dict[l11lll_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ彛")])
		if l11lll_l1_ (u"ࠪࡪࡵࡹࠧ彜") in list(dict.keys()): dict[l11lll_l1_ (u"ࠫ࡫ࡶࡳࠨ彝")] = str(dict[l11lll_l1_ (u"ࠬ࡬ࡰࡴࠩ彞")])
		if l11lll_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ彟") in list(dict.keys()): dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩࠬ彠")] = dict[l11lll_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ彡")]		#.replace(l11lll_l1_ (u"ࠩࡀࠫ形"),l11lll_l1_ (u"ࠪࡁࠬ彣"))+l11lll_l1_ (u"ࠫࠧ࠭彤")
		if l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ彥") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪ彦")] = str(dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ彧")])
		if l11lll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ彨") in list(dict.keys()): dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ彩")] = str(dict[l11lll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ彪")])
		if l11lll_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ彫") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬࡹࡩࡻࡧࠪ彬")] = str(dict[l11lll_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ彭")])+l11lll_l1_ (u"ࠧࡹࠩ彮")+str(dict[l11lll_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ彯")])
		if l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ彰") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ影")] = dict[l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ彲")][l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ彳")]+l11lll_l1_ (u"࠭࠭ࠨ彴")+dict[l11lll_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ彵")][l11lll_l1_ (u"ࠨࡧࡱࡨࠬ彶")]
		if l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭彷") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ彸")] = dict[l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ役")][l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ彺")]+l11lll_l1_ (u"࠭࠭ࠨ彻")+dict[l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ彼")][l11lll_l1_ (u"ࠨࡧࡱࡨࠬ彽")]
		if l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ彾") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ彿")] = dict[l11lll_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬ往")]
		if l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭征") in list(dict.keys()) and int(dict[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ徂")])>111222333: del dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ徃")]
		if l11lll_l1_ (u"ࠨࡵ࡬࡫ࡳࡧࡴࡶࡴࡨࡇ࡮ࡶࡨࡦࡴࠪ径") in list(dict.keys()):
			cipher = dict[l11lll_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ待")].split(l11lll_l1_ (u"ࠪࠪࠬ徆"))
			for item in cipher:
				key,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭徇"),1)
				dict[key] = l111l_l1_(value)
		if l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ很") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ徉")] = l111l_l1_(dict[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ徊")])
		#if l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳ࠾ࠩ律") in dict[l11lll_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ後")]: dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ徍")] = dict[l11lll_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭徎")].split(l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࡂࡢࠢࠨ徏"))[1].strip(l11lll_l1_ (u"࠭࡜ࠣࠩ徐"))
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ徑"),dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭徒")]+l11lll_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢࠪ従")+dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥࠨ徔")])
		l111l1lll11l_l1_.append(dict)
	l11l1lll1_l1_ = l11lll_l1_ (u"ࠫࠬ徕")
	if l11lll_l1_ (u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬ徖") in l11lll1l11_l1_:
		#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡹࡵࡵ࠲࡮ࡸࡨࡩ࡯࠱ࡳࡰࡦࡿࡥࡳࡡ࠱࠮ࡄ࠯ࠢࠨ得"),html,re.DOTALL)
		# l111ll1111ll_l1_:	/s/l11ll1111l1_l1_/6dde7fb4/l1lllll11l11l_l1_.l11111ll1l1l_l1_/l1111l1l1ll1_l1_/base.l1lllll111l1l_l1_
		#l1lllll11llll_l1_ = [l11lll_l1_ (u"ࠧ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡨ࠽࠽ࡤ࠶࠺࠴ࡪ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࡯ࡡࡴ࠰ࡹࡪࡱࡹࡥࡵ࠱ࡨࡲࡤ࡛ࡓ࠰ࡤࡤࡷࡪ࠴ࡪࡴࠩ徘")]
		l1lllll11llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡵ࠲ࡴࡱࡧࡹࡦࡴ࠲ࡠࡼ࠰࠿࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠ࠰࠱࠳ࡧࡧࡳࡦ࠰࡭ࡷ࠮ࠨࠧ徙"),html,re.DOTALL)
		if l1lllll11llll_l1_:
			l1lllll11llll_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ徚")][0]+l1lllll11llll_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ徛"),l1lllll11llll_l1_,l11lll_l1_ (u"ࠫࠬ徜"),l11lll_l1_ (u"ࠬ࠭徝"),l11lll_l1_ (u"࠭ࠧ從"),l11lll_l1_ (u"ࠧࠨ徟"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩ徠"))
			l11l1lll1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1llll1llll1l_l1_ = cipher._load_javascript(l11l1lll1_l1_)
			l1llll1l11111_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭御"),str(l1llll1llll1l_l1_))
			l1lllllll11ll_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1llll1l11111_l1_)
	for dict in l111l1lll11l_l1_:
		url = dict[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ徢")]
		if l11lll_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠽ࠨ徣") in url or url.count(l11lll_l1_ (u"ࠬࡹࡩࡨ࠿ࠪ徤"))>1:
			l111l1lll1l1_l1_.append(dict)
		elif l11l1lll1_l1_ and l11lll_l1_ (u"࠭ࡳࠨ徥") in list(dict.keys()) and l11lll_l1_ (u"ࠧࡴࡲࠪ徦") in list(dict.keys()):
			l1111ll1ll1l_l1_ = l1lllllll11ll_l1_.execute(dict[l11lll_l1_ (u"ࠨࡵࠪ徧")])
			if l1111ll1ll1l_l1_!=dict[l11lll_l1_ (u"ࠩࡶࠫ徨")]:
				dict[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ復")] = url+l11lll_l1_ (u"ࠫࠫ࠭循")+dict[l11lll_l1_ (u"ࠬࡹࡰࠨ徫")]+l11lll_l1_ (u"࠭࠽ࠨ徬")+l1111ll1ll1l_l1_
				l111l1lll1l1_l1_.append(dict)
	for dict in l111l1lll1l1_l1_:
		l1l1111_l1_,l1lllll1lll11_l1_,l1llllll11111_l1_,l11ll1ll1_l1_,codecs,l111l1lllll_l1_ = l11lll_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ徭"),l11lll_l1_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ微"),l11lll_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ徯"),l11lll_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ徰"),l11lll_l1_ (u"ࠫࠬ徱"),l11lll_l1_ (u"ࠬ࠶ࠧ徲")
		try:
			l111l1lll1ll_l1_ = dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ徳")]
			l111l1lll1ll_l1_ = l111l1lll1ll_l1_.replace(l11lll_l1_ (u"ࠧࠬࠩ徴"),l11lll_l1_ (u"ࠨࠩ徵"))
			items = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ徶"),l111l1lll1ll_l1_,re.DOTALL)
			l11ll1ll1_l1_,l1l1111_l1_,codecs = items[0]
			l111llll11l1_l1_ = codecs.split(l11lll_l1_ (u"ࠪ࠰ࠬ德"))
			l1lllll1lll11_l1_ = l11lll_l1_ (u"ࠫࠬ徸")
			for item in l111llll11l1_l1_: l1lllll1lll11_l1_ += item.split(l11lll_l1_ (u"ࠬ࠴ࠧ徹"))[0]+l11lll_l1_ (u"࠭ࠬࠨ徺")
			l1lllll1lll11_l1_ = l1lllll1lll11_l1_.strip(l11lll_l1_ (u"ࠧ࠭ࠩ徻"))
			if l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ徼") in list(dict.keys()): l111l1lllll_l1_ = str(float(dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ徽")]*10)//1024/10)+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ徾")
			else: l111l1lllll_l1_ = l11lll_l1_ (u"ࠫࠬ徿")
			if l11ll1ll1_l1_==l11lll_l1_ (u"ࠬࡺࡥࡹࡶࠪ忀"): continue
			elif l11lll_l1_ (u"࠭ࠬࠨ忁") in l111l1lll1ll_l1_:
				l11ll1ll1_l1_ = l11lll_l1_ (u"ࠧࡂ࡙࠭ࠫ忂")
				l1llllll11111_l1_ = l1l1111_l1_+l11lll_l1_ (u"ࠨࠢࠣࠫ心")+l111l1lllll_l1_+dict[l11lll_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ忄")].split(l11lll_l1_ (u"ࠪࡼࠬ必"))[1]
			elif l11ll1ll1_l1_==l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ忆"):
				l11ll1ll1_l1_ = l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ忇")
				l1llllll11111_l1_ = l111l1lllll_l1_+dict[l11lll_l1_ (u"࠭ࡳࡪࡼࡨࠫ忈")].split(l11lll_l1_ (u"ࠧࡹࠩ忉"))[1]+l11lll_l1_ (u"ࠨࠢࠣࠫ忊")+dict[l11lll_l1_ (u"ࠩࡩࡴࡸ࠭忋")]+l11lll_l1_ (u"ࠪࡪࡵࡹࠧ忌")+l11lll_l1_ (u"ࠫࠥࠦࠧ忍")+l1l1111_l1_
			elif l11ll1ll1_l1_==l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ忎"):
				l11ll1ll1_l1_ = l11lll_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ忏")
				l1llllll11111_l1_ = l111l1lllll_l1_+str(int(dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫ忐")])/1000)+l11lll_l1_ (u"ࠨ࡭࡫ࡾࠥࠦࠧ忑")+dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ忒")]+l11lll_l1_ (u"ࠪࡧ࡭࠭忓")+l11lll_l1_ (u"ࠫࠥࠦࠧ忔")+l1l1111_l1_
		except:
			l1lll1lllll1_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lllll1_l1_)
		if l11lll_l1_ (u"ࠬࡪࡵࡳ࠿ࠪ忕") in dict[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ忖")]: l1l1l1111_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ志")].split(l11lll_l1_ (u"ࠨࡦࡸࡶࡂ࠭忘"),1)[1].split(l11lll_l1_ (u"ࠩࠩࠫ忙"),1)[0]))
		elif l11lll_l1_ (u"ࠪࡥࡵࡶࡲࡰࡺࡇࡹࡷࡧࡴࡪࡱࡱࡑࡸ࠭忚") in list(dict.keys()): l1l1l1111_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧ忛")])/1000)
		else: l1l1l1111_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ応")
		if l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ忝") not in list(dict.keys()): l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ忞")].split(l11lll_l1_ (u"ࠨࡺࠪ忟"))[1]
		else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ忠")]
		if l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ忡") not in list(dict.keys()): dict[l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ忢")] = l11lll_l1_ (u"ࠬ࠶࠭࠱ࠩ忣")
		dict[l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ忤")] = l11ll1ll1_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ忥")+l1llllll11111_l1_+l11lll_l1_ (u"ࠨࠢࠣࠬࠬ忦")+l1lllll1lll11_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ忧")+dict[l11lll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ忨")]+l11lll_l1_ (u"ࠫ࠮࠭忩")
		dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭忪")] = l1llllll11111_l1_.split(l11lll_l1_ (u"࠭ࠠࠡࠩ快"))[0].split(l11lll_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ忬"))[0]
		dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ忭")] = l11ll1ll1_l1_
		dict[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ忮")] = l1l1111_l1_
		dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ忯")] = codecs
		dict[l11lll_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭忰")] = l1l1l1111_l1_
		dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭忱")] = l111l1lllll_l1_
		l111l1lll111_l1_.append(dict)
	l111l1111111_l1_,l111ll1l1l1l_l1_,l11l111111ll_l1_,l11111llll11_l1_,l111l1l11ll1_l1_ = [],[],[],[],[]
	l11111l1l1l1_l1_,l111ll11111l_l1_,l111111l1ll1_l1_,l111llll1111_l1_,l111lllllll1_l1_ = [],[],[],[],[]
	if l1llll1l1111l_l1_:
		dict = {}
		dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ忲")] = l11lll_l1_ (u"ࠧࡂ࡙࠭ࠫ忳")
		dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ忴")] = l11lll_l1_ (u"ࠩࡰࡴࡩ࠭念")
		dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ忶")] = dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ忷")]+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ忸")+dict[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ忹")]+l11lll_l1_ (u"ࠧࠡࠢࠪ忺")+l11lll_l1_ (u"ࠨฮ๋ำฮࠦะไ์ฬࠫ忻")
		dict[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭忼")] = l1llll1l1111l_l1_
		dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ忽")] = l11lll_l1_ (u"ࠫ࠵࠭忾") # for l11l1l1l11_l1_ l1llll1l1111l_l1_ any l1l11l11l_l1_ will l111l1l1ll11_l1_ l1lll1lll11_l1_ sort l1l11l1l1l1_l1_
		dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭忿")] = l11lll_l1_ (u"࠭࠹࠹࠹࠹࠹࠹࠹࠲࠲࠲ࠪ怀") # 20
		l111l1lll111_l1_.append(dict)
	if l11l1111l111_l1_:
		l111l1l11lll_l1_,l111ll11ll1l_l1_ = l11ll11lll_l1_(l11l1111l111_l1_)
		l111lll111l1_l1_ = list(zip(l111l1l11lll_l1_,l111ll11ll1l_l1_))
		for title,link in l111lll111l1_l1_:
			dict = {}
			dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭态")] = l11lll_l1_ (u"ࠨࡃ࠮࡚ࠬ怂")
			dict[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ怃")] = l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ怄")
			dict[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ怅")] = link
			#if l11lll_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ怆") in title: dict[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ怇")] = title.split(l11lll_l1_ (u"ࠧࠡࠢࠪ怈"))[1].split(l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭怉"))[0]
			#if l11lll_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ怊") in title: dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ怋")] = title.split(l11lll_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ怌"))[1]
			# title = l11lll_l1_ (u"ࠧ࠺࠲࠷࠹࡮ࡦࡵࡹࠠࠡ࠹࠵࠴ࠥࠦ࠮࡮࠵ࡸ࠼ࠧ怍")
			if l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠫ怎") in title: dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ怏")] = title.split(l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭怐"))[0].rsplit(l11lll_l1_ (u"ࠩࠣࠤࠬ怑"))[-1]
			else: dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ怒")] = l11lll_l1_ (u"ࠫ࠶࠶ࠧ怓")
			if title.count(l11lll_l1_ (u"ࠬࠦࠠࠨ怔"))>1:
				l11l111l_l1_ = title.rsplit(l11lll_l1_ (u"࠭ࠠࠡࠩ怕"))[-3]
				if l11l111l_l1_.isdigit(): dict[l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ怖")] = l11l111l_l1_
				else: dict[l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ怗")] = l11lll_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ怘")
			#dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ怙")] = title
			if title==l11lll_l1_ (u"ࠫ࠲࠷ࠧ怚"): dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ怛")] = dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ怜")]+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ思")+dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ怞")]+l11lll_l1_ (u"ࠩࠣࠤࠬ怟")+l11lll_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭怠")
			else: dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ怡")] = dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ怢")]+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ怣")+dict[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ怤")]+l11lll_l1_ (u"ࠨࠢࠣࠫ急")+dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ怦")]+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ性")+dict[l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ怨")]
			l111l1lll111_l1_.append(dict)
	l111l1lll111_l1_ = sorted(l111l1lll111_l1_,reverse=True,key=lambda key: float(key[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭怩")]))
	if not l111l1lll111_l1_:
		l1l1ll11111_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ怪"),html,re.DOTALL)
		l1l1ll1111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻࡞ࡾࠦࡷࡻ࡮ࡴࠤ࠽ࡠࡠࡢࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ怫"),html,re.DOTALL)
		l1111llll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ怬"),html,re.DOTALL)
		l1111lllll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡿࠧࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ怭"),html,re.DOTALL)
		try: l1111lllll1l_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ怮")][l11lll_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ怯")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怰")][l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ怱")][l11lll_l1_ (u"ࠧࡳࡷࡱࡷࠬ怲")][0][l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭怳")]
		except: l1111lllll1l_l1_ = l11lll_l1_ (u"ࠩࠪ怴")
		try: l1111llllll1_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ怵")][l11lll_l1_ (u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩ怶")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭怷")][l11lll_l1_ (u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧ怸")][0][l11lll_l1_ (u"ࠧࡳࡷࡱࡷࠬ怹")][0][l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭怺")]
		except: l1111llllll1_l1_ = l11lll_l1_ (u"ࠩࠪ总")
		try: l1lllllll11l1_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ怼")][l11lll_l1_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ怽")]
		except: l1lllllll11l1_l1_ = l11lll_l1_ (u"ࠬ࠭怾")
		if l1l1ll11111_l1_ or l1l1ll1111l_l1_ or l1111llll1ll_l1_ or l1111lllll11_l1_ or l1111lllll1l_l1_ or l1111llllll1_l1_ or l1lllllll11l1_l1_:
			if   l1l1ll11111_l1_: message = l1l1ll11111_l1_[0]
			elif l1l1ll1111l_l1_: message = l1l1ll1111l_l1_[0]
			elif l1111llll1ll_l1_: message = l1111llll1ll_l1_[0]
			elif l1111lllll11_l1_: message = l1111lllll11_l1_[0]
			elif l1111lllll1l_l1_: message = l1111lllll1l_l1_
			elif l1111llllll1_l1_: message = l1111llllll1_l1_
			elif l1lllllll11l1_l1_: message = l1lllllll11l1_l1_
			l1111111l1ll_l1_ = message.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ怿"),l11lll_l1_ (u"ࠧࠨ恀")).strip(l11lll_l1_ (u"ࠨࠢࠪ恁"))
			l111l11ll1l1_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦๅีๅ็อࠥ๎โะࠢํ็ํ์ࠠ฻์ิࠤ๊๊วว็่ࠣอ฿ึࠡษ็ุ้ะฮะ็ํ๊ࠥษ่ࠡ฼ํี๋ࠥส้ใิࠤฬ๊ย็࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ恂")
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ恃"),l11lll_l1_ (u"ࠫࠬ恄"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿้ࠠษ็้อืๅอࠩ恅"),l111l11ll1l1_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ恆")+l1111111l1ll_l1_)
			return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠩ恇")+l1111111l1ll_l1_,[],[]
		else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ恈"),[],[]
	l1lllllll1l11_l1_,l1llll111llll_l1_,l1111ll1l11l_l1_ = [],[],[]
	for dict in l111l1lll111_l1_:
		if dict[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ恉")]==l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ恊"):
			l111l1111111_l1_.append(dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ恋")])
			l11111l1l1l1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ恌")]==l11lll_l1_ (u"࠭ࡁࡶࡦ࡬ࡳࠬ恍"):
			l111ll1l1l1l_l1_.append(dict[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭恎")])
			l111ll11111l_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ恏")]==l11lll_l1_ (u"ࠩࡰࡴࡩ࠭恐"):
			title = dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ恑")].replace(l11lll_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ恒"),l11lll_l1_ (u"ࠬ࠭恓"))
			if l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ恔") not in list(dict.keys()): l111l1lllll_l1_ = l11lll_l1_ (u"ࠧ࠱ࠩ恕")
			else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ恖")]
			l1lllllll1l11_l1_.append([dict,{},title,l111l1lllll_l1_])
		else:
			title = dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ恗")].replace(l11lll_l1_ (u"ࠪࡅ࠰࡜࠺ࠡࠢࠪ恘"),l11lll_l1_ (u"ࠫࠬ恙"))
			if l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭恚") not in list(dict.keys()): l111l1lllll_l1_ = l11lll_l1_ (u"࠭࠰ࠨ恛")
			else: l111l1lllll_l1_ = dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ恜")]
			l1lllllll1l11_l1_.append([dict,{},title,l111l1lllll_l1_])
			l11l111111ll_l1_.append(title)
			l111111l1ll1_l1_.append(dict)
		l111lll11l1l_l1_ = True
		if l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ恝") in list(dict.keys()):
			if l11lll_l1_ (u"ࠩࡤࡺ࠵࠭恞") in dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ恟")]: l111lll11l1l_l1_ = False
			elif kodi_version<18:
				if l11lll_l1_ (u"ࠫࡦࡼࡣࠨ恠") not in dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ恡")] and l11lll_l1_ (u"࠭࡭ࡱ࠶ࡤࠫ恢") not in dict[l11lll_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ恣")]: l111lll11l1l_l1_ = False
		if dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ恤")]==l11lll_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ恥") and dict[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ恦")]!=l11lll_l1_ (u"ࠫ࠵࠳࠰ࠨ恧") and l111lll11l1l_l1_==True:
			l111l1l11ll1_l1_.append(dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ恨")])
			l111lllllll1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ恩")]==l11lll_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭恪") and dict[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭恫")]!=l11lll_l1_ (u"ࠩ࠳࠱࠵࠭恬") and l111lll11l1l_l1_==True:
			l11111llll11_l1_.append(dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ恭")])
			l111llll1111_l1_.append(dict)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ恮"),l11lll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ息")+dict[l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭恰")])
	for l111ll1lll11_l1_ in l111llll1111_l1_:
		l11111llllll_l1_ = l111ll1lll11_l1_[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ恱")]
		for l1111lll1ll1_l1_ in l111lllllll1_l1_:
			l1llllll111ll_l1_ = l1111lll1ll1_l1_[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ恲")]
			l111l1lllll_l1_ = l1llllll111ll_l1_+l11111llllll_l1_
			title = l1111lll1ll1_l1_[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ恳")].replace(l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬ恴"),l11lll_l1_ (u"ࠫࡲࡶࡤࠡࠢࠪ恵"))
			title = title.replace(l1111lll1ll1_l1_[l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ恶")]+l11lll_l1_ (u"࠭ࠠࠡࠩ恷"),l11lll_l1_ (u"ࠧࠨ恸"))
			title = title.replace(str((float(l1llllll111ll_l1_*10)//1024/10))+l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭恹"),str((float(l111l1lllll_l1_*10)//1024/10))+l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ恺"))
			title = title+l11lll_l1_ (u"ࠪࠬࠬ恻")+l111ll1lll11_l1_[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ恼")].split(l11lll_l1_ (u"ࠬ࠮ࠧ恽"),1)[1]
			l1lllllll1l11_l1_.append([l1111lll1ll1_l1_,l111ll1lll11_l1_,title,l111l1lllll_l1_])
	l1lllllll1l11_l1_ = sorted(l1lllllll1l11_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1111lll1ll1_l1_,l111ll1lll11_l1_,title,l111l1lllll_l1_ in l1lllllll1l11_l1_:
		l111l1ll1l1l_l1_ = l1111lll1ll1_l1_[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ恾")]
		if l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ恿") in list(l111ll1lll11_l1_.keys()):
			l111l1ll1l1l_l1_ = l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ悀")
			#l111l1ll1l1l_l1_ = l111l1ll1l1l_l1_+l111ll1lll11_l1_[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ悁")]
		if l111l1ll1l1l_l1_ not in l1111ll1l11l_l1_:
			l1111ll1l11l_l1_.append(l111l1ll1l1l_l1_)
			l1llll111llll_l1_.append([l1111lll1ll1_l1_,l111ll1lll11_l1_,title,l111l1lllll_l1_])
			#LOG_THIS(l11lll_l1_ (u"ࠪࠫ悂"),str(l111l1lllll_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ悃")+title)
	#l1llll111llll_l1_ = sorted(l1llll111llll_l1_, reverse=True, key=lambda key: int(key[3]))
	l1lllllll111l_l1_,l11111ll1l11_l1_,shift = [],[],0
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࡷ࡭࡯ࡦࡵࠢ࠮ࡁࠥ࠷ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ࠭ࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠳ࡠࠎࠎࠏࡳࡦ࡮ࡨࡧࡹࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡩࡨࡰ࡫ࡦࡩࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ悄")
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࡳࡼࡴࡥࡳࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭ࡡ࡭ࡷࡴࡴࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡥࡺࡺࡨࡰࡴࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰࡤࡰࡳࡰࡰ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴࡢࡲࡦࡳࡥ࠻ࠌࠌࠍ࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠤࠫ࠲࠯ࡅࠩࠣࡣ࡯ࡰࡴࡽࡒࡢࡶ࡬ࡲ࡬ࡹࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡩࡧࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࠏࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡺࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬࠻ࠢ࡬ࡱࡦ࡭ࡥࠡ࠿ࠣ࡭ࡲࡧࡧࡦࡵࡢࡹࡷࡲ࡛࠮࠳ࡠࠎࠎࠏ࡯ࡸࡰࡨࡶࠥࡃࠠࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨ࡟࠵ࡣࠊࠊࠋࡶ࡬࡮࡬ࡴࠡ࠭ࡀࠤ࠶ࠐࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧࠬࡱࡺࡲࡪࡸࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦࡗࡆࡄࡖࡍ࡙ࡋࡓ࡜ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪࡡࡠ࠶࡝ࠬࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ࠱࡯ࡸࡰࡨࡶࡤࡩࡨࡢࡰࡱࡩࡱࡡ࠰࡞ࠌࠌࠍࡸ࡫࡬ࡦࡥࡷࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡧ࡭ࡵࡩࡤࡧࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ悅")
	l111lll11lll_l1_,l111l1l1lll1_l1_ = l11lll_l1_ (u"ࠧࠨ悆"),l11lll_l1_ (u"ࠨࠩ悇")
	try: l111lll11lll_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ悈")][l11lll_l1_ (u"ࠪࡥࡺࡺࡨࡰࡴࠪ悉")]
	except: l111lll11lll_l1_ = l11lll_l1_ (u"ࠫࠬ悊")
	try: l1111111ll11_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ悋")][l11lll_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ悌")]
	except: l1111111ll11_l1_ = l11lll_l1_ (u"ࠧࠨ悍")
	if l111lll11lll_l1_ and l1111111ll11_l1_:
		shift += 1
		title = l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ悎")+l111lll11lll_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ悏")
		link = l1ll11l_l1_[l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ悐")][0]+l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ悑")+l1111111ll11_l1_
		l1lllllll111l_l1_.append(title)
		l11111ll1l11_l1_.append(link)
		try: l111l1l1lll1_l1_ = l1lllll1ll1ll_l1_[l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ悒")][l11lll_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ悓")][l11lll_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ悔")][-1][l11lll_l1_ (u"ࠨࡷࡵࡰࠬ悕")]
		except: pass
	#if l1llll1l1111l_l1_:
	#	shift += 1
	#	l1lllllll111l_l1_.append(l11lll_l1_ (u"ࠩࡰࡴࡩࠦฬ้ัฬࠤี้๊สࠩ悖")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠪࡨࡦࡹࡨࠨ悗"))
	for l1111lll1ll1_l1_,l111ll1lll11_l1_,title,l111l1lllll_l1_ in l1llll111llll_l1_:
		l1lllllll111l_l1_.append(title) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ悘"))
	if l11l111111ll_l1_: l1lllllll111l_l1_.append(l11lll_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧ悙")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ悚"))
	if l1lllllll1l11_l1_: l1lllllll111l_l1_.append(l11lll_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫ悛")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ悜"))
	if l111l1l11ll1_l1_: l1lllllll111l_l1_.append(l11lll_l1_ (u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ悝")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠪࡱࡵࡪࠧ悞"))
	if l111l1111111_l1_: l1lllllll111l_l1_.append(l11lll_l1_ (u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫ悟")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ悠"))
	if l111ll1l1l1l_l1_: l1lllllll111l_l1_.append(l11lll_l1_ (u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭悡")) ; l11111ll1l11_l1_.append(l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭悢"))
	l11l11111l1l_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1llll1111l11_l1_, l1lllllll111l_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭患"),[],[]
		elif l1l_l1_==0 and l111lll11lll_l1_:
			link = l11111ll1l11_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11lll_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩ悤")+QUOTE(l111lll11lll_l1_)+l11lll_l1_ (u"ࠪࠪࡺࡸ࡬࠾ࠩ悥")+link
			if l111l1l1lll1_l1_: new_path = new_path+l11lll_l1_ (u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬ悦")+QUOTE(l111l1l1lll1_l1_)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ悧")+new_path+l11lll_l1_ (u"ࠨࠩࠣ您"))
			return l11lll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ悩"),[],[]
		choice = l11111ll1l11_l1_[l1l_l1_]
		l1lllll11l111_l1_ = l1lllllll111l_l1_[l1l_l1_]
		if choice==l11lll_l1_ (u"ࠨࡦࡤࡷ࡭࠭悪"):
			l1llll1ll11l1_l1_ = l1llll1l1111l_l1_
			break
		elif choice in [l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ悫"),l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ悬"),l11lll_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ悭")]:
			if choice==l11lll_l1_ (u"ࠬࡳࡵࡹࡧࡧࠫ悮"): l1lll1ll_l1_,l111111ll1ll_l1_ = l11l111111ll_l1_,l111111l1ll1_l1_
			elif choice==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ悯"): l1lll1ll_l1_,l111111ll1ll_l1_ = l111l1111111_l1_,l11111l1l1l1_l1_
			elif choice==l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭悰"): l1lll1ll_l1_,l111111ll1ll_l1_ = l111ll1l1l1l_l1_,l111ll11111l_l1_
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ悱"), l1lll1ll_l1_)
			if l1l_l1_!=-1:
				l1llll1ll11l1_l1_ = l111111ll1ll_l1_[l1l_l1_][l11lll_l1_ (u"ࠩࡸࡶࡱ࠭悲")]
				l1lllll11l111_l1_ = l1lll1ll_l1_[l1l_l1_]
				break
		elif choice==l11lll_l1_ (u"ࠪࡱࡵࡪࠧ悳"):
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯ࠺ࠨ悴"), l111l1l11ll1_l1_)
			if l1l_l1_!=-1:
				l1lllll11l111_l1_ = l111l1l11ll1_l1_[l1l_l1_]
				l111l1l1llll_l1_ = l111lllllll1_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣะํีษࠡษ็ูํะ࠺ࠨ悵"), l11111llll11_l1_)
				if l1l_l1_!=-1:
					l1lllll11l111_l1_ += l11lll_l1_ (u"࠭ࠠࠬࠢࠪ悶")+l11111llll11_l1_[l1l_l1_]
					l1111lll1l11_l1_ = l111llll1111_l1_[l1l_l1_]
					l11l11111l1l_l1_ = True
					break
		elif choice==l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ悷"):
			l111ll11l11l_l1_,l1111l111l1l_l1_,l1llll11l1l11_l1_,l111l11l1ll1_l1_ = list(zip(*l1lllllll1l11_l1_))
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧ悸"), l1llll11l1l11_l1_)
			if l1l_l1_!=-1:
				l1lllll11l111_l1_ = l1llll11l1l11_l1_[l1l_l1_]
				l111l1l1llll_l1_ = l111ll11l11l_l1_[l1l_l1_]
				if l11lll_l1_ (u"ࠩࡰࡴࡩ࠭悹") in l1llll11l1l11_l1_[l1l_l1_] and l111l1l1llll_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ悺")]!=l1llll1l1111l_l1_:
					l1111lll1l11_l1_ = l1111l111l1l_l1_[l1l_l1_]
					l11l11111l1l_l1_ = True
				else: l1llll1ll11l1_l1_ = l111l1l1llll_l1_[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ悻")]
				break
		elif choice==l11lll_l1_ (u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭悼"):
			#shift += 1
			l111ll11l11l_l1_,l1111l111l1l_l1_,l1llll11l1l11_l1_,l111l11l1ll1_l1_ = list(zip(*l1llll111llll_l1_))
			l111l1l1llll_l1_ = l111ll11l11l_l1_[l1l_l1_-shift]
			if l11lll_l1_ (u"࠭࡭ࡱࡦࠪ悽") in l1llll11l1l11_l1_[l1l_l1_-shift] and l111l1l1llll_l1_[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ悾")]!=l1llll1l1111l_l1_:
				l1111lll1l11_l1_ = l1111l111l1l_l1_[l1l_l1_-shift]
				l11l11111l1l_l1_ = True
			else: l1llll1ll11l1_l1_ = l111l1l1llll_l1_[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ悿")]
			l1lllll11l111_l1_ = l1llll11l1l11_l1_[l1l_l1_-shift]
			break
	if not l11l11111l1l_l1_: l1llll1l1ll1l_l1_ = l1llll1ll11l1_l1_
	else: l1llll1l1ll1l_l1_ = l11lll_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪ惀")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ惁")]+l11lll_l1_ (u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨ惂")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ惃")]
	if l11l11111l1l_l1_:
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ惄"),l11lll_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ情")+str(l111l1l1llll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ惆"),l11lll_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭惇")+str(l1111lll1l11_l1_))
		#if l111llllll11_l1_>l1111ll11l11_l1_: l1l1l1111_l1_ = str(l111llllll11_l1_)
		#else: l1l1l1111_l1_ = str(l1111ll11l11_l1_)
		#l1l1l1111_l1_ = str(l111llllll11_l1_) if l111llllll11_l1_>l1111ll11l11_l1_ else str(l1111ll11l11_l1_)
		l111llllll11_l1_ = int(l111l1l1llll_l1_[l11lll_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ惈")])
		l1111ll11l11_l1_ = int(l1111lll1l11_l1_[l11lll_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭惉")])
		l1l1l1111_l1_ = str(max(l111llllll11_l1_,l1111ll11l11_l1_))
		l1111l1l1l11_l1_ = l111l1l1llll_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ惊")].replace(l11lll_l1_ (u"࠭ࠦࠨ惋"),l11lll_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭惌"))		# +l11lll_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ惍")
		l111ll1l1ll1_l1_ = l1111lll1l11_l1_[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭惎")].replace(l11lll_l1_ (u"ࠪࠪࠬ惏"),l11lll_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ惐"))		# +l11lll_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠲࠳࠴࠵࠶࠰࠱ࠩ惑")
		l11l111111l1_l1_ = l11lll_l1_ (u"࠭࠼ࡀࡺࡰࡰࠥࡼࡥࡳࡵ࡬ࡳࡳࡃࠢ࠲࠰࠳ࠦࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࠣࡗࡗࡊ࠲࠾ࠢࡀࡀ࡟ࡲࠬ惒")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡏࡓࡈࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡹࡩ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠲࠱࠲࠴࠳࡝ࡓࡌࡔࡥ࡫ࡩࡲࡧ࠭ࡪࡰࡶࡸࡦࡴࡣࡦࠤࠣࡼࡲࡲ࡮ࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠧࠦࡸ࡮࡮ࡱࡷ࠿ࡾ࡬ࡪࡰ࡮ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠴࠽࠾࠿࠯ࡹ࡮࡬ࡲࡰࠨࠠࡹࡵ࡬࠾ࡸࡩࡨࡦ࡯ࡤࡐࡴࡩࡡࡵ࡫ࡲࡲࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠡࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡳࡪࡡࡳࡦࡶ࠲࡮ࡹ࡯࠯ࡱࡵ࡫࠴࡯ࡴࡵࡨ࠲ࡔࡺࡨ࡬ࡪࡥ࡯ࡽࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࡓࡵࡣࡱࡨࡦࡸࡤࡴ࠱ࡐࡔࡊࡍ࠭ࡅࡃࡖࡌࡤࡹࡣࡩࡧࡰࡥࡤ࡬ࡩ࡭ࡧࡶ࠳ࡉࡇࡓࡉ࠯ࡐࡔࡉ࠴ࡸࡴࡦࠥࠤࡲ࡯࡮ࡃࡷࡩࡪࡪࡸࡔࡪ࡯ࡨࡁࠧࡖࡔ࠲࠰࠸ࡗࠧࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨ惓")+l1l1l1111_l1_+l11lll_l1_ (u"ࠨࡕࠥࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࡂࡡࡴࠧ惔")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭惕")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠲ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡷ࡫ࡧࡩࡴ࠵ࠧ惖")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭惗")]+l11lll_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ惘")		# l1111ll1l1ll_l1_=l11lll_l1_ (u"ࠨ࠱ࠣ惙") l11l11111111_l1_=l11lll_l1_ (u"ࠢࡵࡴࡸࡩࠧ惚") default=l11lll_l1_ (u"ࠣࡶࡵࡹࡪࠨ惛")>\n
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ惜")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ惝")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ惞")]+l11lll_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ惟")+l111l1l1llll_l1_[l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭惠")]+l11lll_l1_ (u"ࠧࠣࠢࡶࡸࡦࡸࡴࡘ࡫ࡷ࡬ࡘࡇࡐ࠾ࠤ࠴ࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤࠪ惡")+str(l111l1l1llll_l1_[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ惢")])+l11lll_l1_ (u"ࠩࠥࠤࡼ࡯ࡤࡵࡪࡀࠦࠬ惣")+str(l111l1l1llll_l1_[l11lll_l1_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ惤")])+l11lll_l1_ (u"ࠫࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢࠨ惥")+str(l111l1l1llll_l1_[l11lll_l1_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ惦")])+l11lll_l1_ (u"࠭ࠢࠡࡨࡵࡥࡲ࡫ࡒࡢࡶࡨࡁࠧ࠭惧")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠧࡧࡲࡶࠫ惨")]+l11lll_l1_ (u"ࠨࠤࡁࡠࡳ࠭惩")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬ惪")+l1111l1l1l11_l1_+l11lll_l1_ (u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ惫")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ惬")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ惭")]+l11lll_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ惮")	# l1llll11l1111_l1_=l11lll_l1_ (u"ࠢࡵࡴࡸࡩࠧ惯")>\n
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫ惰")+l111l1l1llll_l1_[l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ惱")]+l11lll_l1_ (u"ࠪࠦࠥ࠵࠾࡝ࡰࠪ惲")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴࠧ想")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ惴")
		l11l111111l1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ惵")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠷ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫ惶")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ惷")]+l11lll_l1_ (u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ࠭惸")		# l1111ll1l1ll_l1_=l11lll_l1_ (u"ࠥ࠵ࠧ惹") l11l11111111_l1_=l11lll_l1_ (u"ࠦࡹࡸࡵࡦࠤ惺") default=l11lll_l1_ (u"ࠧࡺࡲࡶࡧࠥ惻")>\n
		l11l111111l1_l1_ += l11lll_l1_ (u"࠭࠼ࡓࡱ࡯ࡩࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡄࡂࡕࡋ࠾ࡷࡵ࡬ࡦ࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣ࡯ࡤ࡭ࡳࠨ࠯࠿࡞ࡱࠫ惼")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠢ࡬ࡨࡂࠨࠧ惽")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭惾")]+l11lll_l1_ (u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭惿")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ愀")]+l11lll_l1_ (u"ࠫࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥ࠵࠸࠶࠴࠸࠷ࠥࡂࡡࡴࠧ愁")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠬࡂࡁࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽࠶࠸࠶࠰࠴࠼࠶࠾ࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠫ愂")+l1111lll1l11_l1_[l11lll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ愃")]+l11lll_l1_ (u"ࠧࠣ࠱ࡁࡠࡳ࠭愄")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠨ࠾ࡅࡥࡸ࡫ࡕࡓࡎࡁࠫ愅")+l111ll1l1ll1_l1_+l11lll_l1_ (u"ࠩ࠿࠳ࡇࡧࡳࡦࡗࡕࡐࡃࡢ࡮ࠨ愆")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠪࡀࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࠢ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪࡃࠢࠨ愇")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ愈")]+l11lll_l1_ (u"ࠬࠨ࠾࡝ࡰࠪ愉")	# l1llll11l1111_l1_=l11lll_l1_ (u"ࠨࡴࡳࡷࡨࠦ愊")>\n
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ愋")+l1111lll1l11_l1_[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭愌")]+l11lll_l1_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ愍")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭愎")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ意")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ愐")
		l11l111111l1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ愑")
		l11l111111l1_l1_ += l11lll_l1_ (u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ愒")
		#open(l11lll_l1_ (u"ࠨࡵ࠽ࡠࡡࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ愓"),l11lll_l1_ (u"ࠩࡺࡦࠬ愔")).write(l11l111111l1_l1_)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ愕"),l11l111111l1_l1_)
		#l11l111111l1_l1_ = OPENURL_CACHED(NO_CACHE,l1llll1l1111l_l1_,l11lll_l1_ (u"ࠫࠬ愖"),l11lll_l1_ (u"ࠬ࠭愗"),l11lll_l1_ (u"࠭ࠧ愘"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠾ࡺࡨࠨ愙"))
		if kodi_version>18.99:
			import http.server as l111l111l1l1_l1_
			import http.client as l1lllllll1111_l1_
		else:
			import BaseHTTPServer as l111l111l1l1_l1_
			import httplib as l1lllllll1111_l1_
		class l1lllll1111ll_l1_(l111l111l1l1_l1_.HTTPServer):
			#l11l111111l1_l1_ = l11lll_l1_ (u"ࠨ࠾ࡁࠫ愚")
			def __init__(self,l1l1ll1l1ll1_l1_=l11lll_l1_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸࠬ愛"),port=55055,l11l111111l1_l1_=l11lll_l1_ (u"ࠪࡀࡃ࠭愜")):
				self.l1l1ll1l1ll1_l1_ = l1l1ll1l1ll1_l1_
				self.port = port
				self.l11l111111l1_l1_ = l11l111111l1_l1_
				l111l111l1l1_l1_.HTTPServer.__init__(self,(self.l1l1ll1l1ll1_l1_,self.port),l11111ll1lll_l1_)
				self.l1llll1lll1ll_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ愝")+l1l1ll1l1ll1_l1_+l11lll_l1_ (u"ࠬࡀࠧ愞")+str(port)+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ感")
				#print(l11lll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡹࡵࠦ࡮ࡰࡹࠣࡰ࡮ࡹࡴࡦࡰ࡬ࡲ࡬ࠦ࡯࡯ࠢࡳࡳࡷࡺ࠺ࠡࠩ愠")+str(port))
			def start(self):
				self.threads = l11111lllll_l1_(False)
				self.threads.start_new_thread(1,self.l1111l1llll1_l1_)
			def l1111l1llll1_l1_(self):
				#print(l11lll_l1_ (u"ࠨࡵࡨࡶࡻ࡯࡮ࡨࠢࡵࡩࡶࡻࡥࡴࡶࡶࠤࡸࡺࡡࡳࡶࡨࡨࠬ愡"))
				self.l1llll111l1ll_l1_ = True
				#l1l11l1ll11_l1_ = 0
				while self.l1llll111l1ll_l1_:
					#l1l11l1ll11_l1_ += 1
					#print(l11lll_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠣࡥࠥࡹࡩ࡯ࡩ࡯ࡩࠥ࡮ࡡ࡯ࡦ࡯ࡩࡤࡸࡥࡲࡷࡨࡷࡹ࠮ࠩࠡࡰࡲࡻ࠿ࠦࠧ愢")+str(l1l11l1ll11_l1_)+l11lll_l1_ (u"ࠪࠫ愣"))
					#settimeout l1111lll1l_l1_ not l111l1l1l1_l1_ l11111111l1l_l1_ to error message if it l1lllll1ll11l_l1_ l1llll11ll1l1_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l1111l1llll1_l1_ l1111ll1l111_l1_ request l1llll1ll1l11_l1_ 60 seconds)
					self.handle_request()
				#print(l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡲࡴࡵ࡫ࡤ࡝ࡰࠪ愤"))
			def stop(self):
				self.l1llll111l1ll_l1_ = False
				self.l1111lll1lll_l1_()	# needed to l111llll11ll_l1_ self.handle_request() to l1111l1llll1_l1_ l1lllllll1ll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳࠦ࡮ࡰࡹ࡟ࡲࠬ愥"))
			def load(self,l11l111111l1_l1_):
				self.l11l111111l1_l1_ = l11l111111l1_l1_
			def l1111lll1lll_l1_(self):
				conn = l1lllllll1111_l1_.HTTPConnection(self.l1l1ll1l1ll1_l1_+l11lll_l1_ (u"࠭࠺ࠨ愦")+str(self.port))
				conn.request(l11lll_l1_ (u"ࠢࡉࡇࡄࡈࠧ愧"), l11lll_l1_ (u"ࠣ࠱ࠥ愨"))
		class l11111ll1lll_l1_(l111l111l1l1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11lll_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡉࡈࡘࠥࠦࠧ愩")+self.path)
				self.send_response(200)
				self.send_header(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ愪"),l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵ࠱ࡳࡰࡦ࡯࡮ࠨ愫"))
				self.end_headers()
				#self.wfile.write(self.path+l11lll_l1_ (u"ࠬࡢ࡮ࠨ愬"))
				self.wfile.write(self.server.l11l111111l1_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ愭")))
				time.sleep(1)
				if self.path==l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭愮"): self.server.shutdown()
				if self.path==l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ愯"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11lll_l1_ (u"ࠩࡧࡳ࡮ࡴࡧࠡࡊࡈࡅࡉࠦࠠࠨ愰")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1lllll1111ll_l1_(l11lll_l1_ (u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭愱"),55055,l11l111111l1_l1_)
		#httpd.load(l11l111111l1_l1_)
		l1llll1ll11l1_l1_ = httpd.l1llll1lll1ll_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1llll1ll11l1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠴ࡤࡢࡵ࡫࡭࡫࠴࡯ࡳࡩ࠲ࡰ࡮ࡼࡥࡴ࡫ࡰ࠳ࡨ࡮ࡵ࡯࡭ࡧࡹࡷࡥ࠱࠰ࡣࡷࡳࡤ࠽࠯ࡵࡧࡶࡸࡵ࡯ࡣ࠵ࡡ࠻ࡷ࠴ࡓࡡ࡯࡫ࡩࡩࡸࡺ࠮࡮ࡲࡧࠫ愲")
		#l1llll1ll11l1_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡢࡵ࡫࠲ࡦࡱࡡ࡮ࡣ࡬ࡾࡪࡪ࠮࡯ࡧࡷ࠳ࡩࡧࡳࡩ࠴࠹࠸࠴࡚ࡥࡴࡶࡆࡥࡸ࡫ࡳ࠰࠴ࡦ࠳ࡶࡻࡡ࡭ࡥࡲࡱࡲ࠵࠱࠰ࡏࡸࡰࡹ࡯ࡒࡦࡵࡐࡔࡊࡍ࠲࠯࡯ࡳࡨࠬ愳")
		#l1llll1ll11l1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡶࡶ࡭࠳ࡺࡥ࡭ࡧࡦࡳࡲ࠳ࡰࡢࡴ࡬ࡷࡹ࡫ࡣࡩ࠰ࡩࡶ࠴࡭ࡰࡢࡥ࠲ࡈࡆ࡙ࡈࡠࡅࡒࡒࡋࡕࡒࡎࡃࡑࡇࡊ࠵ࡔࡦ࡮ࡨࡧࡴࡳࡐࡢࡴ࡬ࡷ࡙࡫ࡣࡩ࠱ࡰࡴ࠹࠳࡬ࡪࡸࡨ࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠳࡭ࡱࡦ࠰ࡅ࡛࠳ࡂࡔ࠰ࡰࡴࡩ࠭愴")
		#l1llll1ll11l1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡳࡦࡰࡩࡩ࡯ࡡ࠯ࡤࡥࡧ࠳ࡩ࡯࠯ࡷ࡮࠳ࡩࡧࡳࡩ࠱ࡲࡲࡩ࡫࡭ࡢࡰࡧ࠳ࡹ࡫ࡳࡵࡥࡤࡶࡩ࠵࠱࠰ࡥ࡯࡭ࡪࡴࡴࡠ࡯ࡤࡲ࡮࡬ࡥࡴࡶ࠰ࡩࡻ࡫࡮ࡵࡵ࠰ࡱࡺࡲࡴࡪ࡮ࡤࡲ࡬࠴࡭ࡱࡦࠪ愵")
		#l1llll1ll11l1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ愶")
	else: httpd = l11lll_l1_ (u"ࠩࠪ愷")
	if not l1llll1ll11l1_l1_: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ愸"),[],[]
	return l11lll_l1_ (u"ࠫࠬ愹"),[l11lll_l1_ (u"ࠬ࠭愺")],[[l1llll1ll11l1_l1_,l1111l11l1ll_l1_,httpd]]
def l1111111l111_l1_(url):
	# https://l111lll1ll11_l1_.com/l11111l1l11l_l1_
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ愻") : l11lll_l1_ (u"ࠧࠨ愼") }
	#url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ愽"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ愾"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ愿"),headers,l11lll_l1_ (u"ࠫࠬ慀"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬ慁"))
	items = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪ慂"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l111l1l11lll_l1_,l1lll1ll_l1_,l111ll11ll1l_l1_,l1111_l1_ = [],[],[],[]
	if items:
		for link,dummy,l1ll11l1l111_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ慃"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ慄"))
			if l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ慅") in link:
				l111l1l11lll_l1_,l111ll11ll1l_l1_ = l11ll11lll_l1_(link)
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ慆"),l11lll_l1_ (u"ࠫࠬ慇"),str(l1111_l1_),str(l111ll11ll1l_l1_))
				l1111_l1_ = l1111_l1_ + l111ll11ll1l_l1_
				if l111l1l11lll_l1_[0]==l11lll_l1_ (u"ࠬ࠳࠱ࠨ慈"): l1lll1ll_l1_.append(l11lll_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ慉")+l11lll_l1_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ慊"))
				else:
					for title in l111l1l11lll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨีํีๆืࠠฯษุࠫ態")+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭慌")+title)
			else:
				title = l11lll_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭慍")+l11lll_l1_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ慎")+l1ll11l1l111_l1_
				l1111_l1_.append(link)
				l1lll1ll_l1_.append(title)
		return l11lll_l1_ (u"ࠬ࠭慏"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨ慐"),[],[]
def l1llll1l111ll_l1_(url):
	# https://l111llll1ll1_l1_.cc/l1l111lll_l1_-1qrpoobdg7bu.html
	# https://l1111lll11l1_l1_.cc//l1l111lll_l1_-l111l11l1lll_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ慑"),url,l11lll_l1_ (u"ࠨࠩ慒"),l11lll_l1_ (u"ࠩࠪ慓"),l11lll_l1_ (u"ࠪࠫ慔"),l11lll_l1_ (u"ࠫࠬ慕"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚࡙ࡍࡉࡋࡏࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ慖"))
	html = response.content
	links = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ慗"),html,re.DOTALL)
	if links:
		link = links[0]
		return l11lll_l1_ (u"ࠧࠨ慘"),[l11lll_l1_ (u"ࠨࠩ慙")],[link]
	return l11lll_l1_ (u"ࠩࠪ慚"),[],[]
def l1llll1l1l1ll_l1_(url):
	# https://l1llll1l1l1l1_l1_.in/l1lllll1lll1l_l1_
	# https://l1llll1l1l1l1_l1_.in/l1l111lll_l1_-l1lllll1lll1l_l1_.html
	# https://l111l111llll_l1_.l1llllllll11l_l1_/l111lll111ll_l1_
	# https://l111l111llll_l1_.l1llllllll11l_l1_/l1l111lll_l1_-l111lll111ll_l1_.html
	# https://www.l111lll1l11l_l1_.com/l1l111lll_l1_-l1111l11111l_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ慛"),l11lll_l1_ (u"ࠫࠬ慜")).replace(l11lll_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ慝"),l11lll_l1_ (u"࠭ࠧ慞"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ慟"),url,l11lll_l1_ (u"ࠨࠩ慠"),l11lll_l1_ (u"ࠩࠪ慡"),l11lll_l1_ (u"ࠪࠫ慢"),l11lll_l1_ (u"ࠫࠬ慣"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡉࡍࡑࡋࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ慤"))
	html = response.content
	l1ll11l1lll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪ࡞ࠬ࠭ࠬ慥"),html,re.DOTALL)
	if l1ll11l1lll1_l1_:
		l1ll11l1lll1_l1_ = l1ll11l1lll1_l1_[0]
		l1l1l1ll11ll_l1_ = l1l1ll1lll1l_l1_(l1ll11l1lll1_l1_)
		links = re.findall(l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭慦"),l1l1l1ll11ll_l1_,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨࠪࡿࠪ慧"),l1l1l1ll11ll_l1_,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link,title in links:
			if not title: title = link.rsplit(l11lll_l1_ (u"ࠩ࠱ࠫ慨"),1)[1]
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		return l11lll_l1_ (u"ࠪࠫ慩"),l1lll1ll_l1_,l1111_l1_
	id = url.split(l11lll_l1_ (u"ࠫ࠴࠭慪"))[3]
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ慫"):l11lll_l1_ (u"࠭ࠧ慬") , l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭慭"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ慮") }
	payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ慯"):id , l11lll_l1_ (u"ࠪࡳࡵ࠭慰"):l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ慱") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ慲"),url,payload,headers,l11lll_l1_ (u"࠭ࠧ慳"),l11lll_l1_ (u"ࠧࠨ慴"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ慵"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ慶"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠪࠫ慷"),[l11lll_l1_ (u"ࠫࠬ慸")],[ items[0] ]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠭慹"),[],[]
l11lll_l1_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡇࡐࡘࡌࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡲࡺ࡮ࡪ࠮ࡤࡱ࠲ࡺ࡮ࡪࡥࡰ࠱ࡳࡰࡦࡿ࠯ࡂࡃ࡙ࡉࡓࡪࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀࠦࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࠥࡀࠠࠨࠩࠣࢁࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒ࡚ࡎࡊ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻ࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡹ࡫࡭ࡱ࡝࠳ࡡࡂࡃࠧ࠮࠳ࠪ࠾ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨࠫࠍࠍࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗࡸࡪࡳࡰ࠻ࠌࠌࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥ࠭ࠫࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥ࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠ࡮ࡲ࠷ࠫࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣࠫࠬ࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑ࡙ࡍࡉ࠭ࠬ࡜࡟࠯࡟ࡢࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠶ࡳ࠮ࡨࡱࡹ࡭ࡩ࠴ࡣࡰ࠱ࡶࡸࡷ࡫ࡡ࡮࠱࠵࠶࠾࠴࡭࠴ࡷ࠻ࠎࠧࠨࠢ慺")
#####################################################
#    l111ll1ll1ll_l1_ l11111l1llll_l1_ l1lllllllll11_l1_
#    16-06-2019
#####################################################
def l11111l111l1_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ慻"),l11lll_l1_ (u"ࠨࠩ慼"),l11lll_l1_ (u"ࠩࠪ慽"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭慾"))
	items = re.findall(l11lll_l1_ (u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ慿"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠬ࠭憀"),[l11lll_l1_ (u"࠭ࠧ憁")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬ憂"),[],[]
def l111111l1lll_l1_(url):
	return l11lll_l1_ (u"ࠨࠩ憃"),[l11lll_l1_ (u"ࠩࠪ憄")],[ url ]
def l11111ll111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ憅"),l11lll_l1_ (u"ࠫࠬ憆"),url,l11lll_l1_ (u"ࠬ࠭憇"))
	server = url.split(l11lll_l1_ (u"࠭࠯ࠨ憈"))
	basename = l11lll_l1_ (u"ࠧ࠰ࠩ憉").join(server[0:3])
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ憊"),l11lll_l1_ (u"ࠩࠪ憋"),l11lll_l1_ (u"ࠪࠫ憌"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡛࠭ࡋࡓࡔ࡞࡙ࡈࡂࡔࡈ࠱࠶ࡹࡴࠨ憍"))
	items = re.findall(l11lll_l1_ (u"ࠬࡪ࡬ࡣࡷࡷࡸࡴࡴ࡜ࠨ࡞ࠬ࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠥࡢࠫࠡ࡞ࠫࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࠤࡡ࠱ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩ࡝ࠫࠣࡠ࠰ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ憎"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ憏"),l11lll_l1_ (u"ࠧࠨ憐"),url,str(var))
	if items:
		l11l1l1ll111_l1_,l11l1ll11l11_l1_,l11l1ll11l1l_l1_,l111l11l1l11_l1_,l111l11l1l1l_l1_,l111l11l11ll_l1_ = items[0]
		var = int(l11l1ll11l11_l1_) % int(l11l1ll11l1l_l1_) + int(l111l11l1l11_l1_) % int(l111l11l1l1l_l1_)
		url = basename + l11l1l1ll111_l1_ + str(var) + l111l11l11ll_l1_
		return l11lll_l1_ (u"ࠨࠩ憑"),[l11lll_l1_ (u"ࠩࠪ憒")],[url]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩ憓"),[],[]
def l111l111l11l_l1_(url):
	url = url.replace(l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ憔"),l11lll_l1_ (u"ࠬ࠭憕"))
	url = url.replace(l11lll_l1_ (u"࠭࠮ࡩࡶࡰࡰࠬ憖"),l11lll_l1_ (u"ࠧࠨ憗"))
	id = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ憘"))[-1]
	headers = { l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ憙") : l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ憚") }
	payload = { l11lll_l1_ (u"ࠦ࡮ࡪࠢ憛"):id , l11lll_l1_ (u"ࠧࡵࡰࠣ憜"):l11lll_l1_ (u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤ憝") }
	request = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ憞"), url, payload, headers, l11lll_l1_ (u"ࠨࠩ憟"),l11lll_l1_ (u"ࠩࠪ憠"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡑ࠶ࡘࡔࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭憡"))
	if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭憢") in list(request.headers.keys()): link = request.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ憣")]
	else: link = url
	if link: return l11lll_l1_ (u"࠭ࠧ憤"),[l11lll_l1_ (u"ࠧࠨ憥")],[link]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡕ࠺ࡕࡑࡎࡒࡅࡉ࠭憦"),[],[]
def l1llllll1l1l1_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ憧"),l11lll_l1_ (u"ࠪࠫ憨"),l11lll_l1_ (u"ࠫࠬ憩"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ憪"))
	items = re.findall(l11lll_l1_ (u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ憫"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠧࠨ憬"),[l11lll_l1_ (u"ࠨࠩ憭")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋࠧ憮"),[],[]
def l1llll111ll1l_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ憯"),l11lll_l1_ (u"ࠫࠬ憰"),l11lll_l1_ (u"ࠬ࠭憱"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧ憲"))
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ憳"),html,re.DOTALL)
	#l1111lll111l_l1_.l1llll11l1lll_l1_(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧ憴") + items[0])
	if items:
		url = url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ憵") + items[0]
		return l11lll_l1_ (u"ࠪࠫ憶"),[l11lll_l1_ (u"ࠫࠬ憷")],[ url ]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨ憸"),[],[]
def l1111l1111ll_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ憹"),l11lll_l1_ (u"ࠧࠨ憺"),l11lll_l1_ (u"ࠨࠩ憻"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚࠭࠲ࡵࡷࠫ憼"))
	items = re.findall(l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ憽"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ憾"),l11lll_l1_ (u"ࠬ࠭憿"),str(items),html)
	if items: return l11lll_l1_ (u"࠭ࠧ懀"),[l11lll_l1_ (u"ࠧࠨ懁")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘࠬ懂"),[],[]
def l111111llll1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ懃"),l11lll_l1_ (u"ࠪࠫ懄"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ懅"),l11lll_l1_ (u"ࠬ࠭懆"),l11lll_l1_ (u"࠭ࠧ懇"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨ懈"))
	items = re.findall(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠠࡱࡴࡨࡰࡴࡧࡤ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ應"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ懊"),l11lll_l1_ (u"ࠪࠫ懋"),items[0],items[0])
	if items: return l11lll_l1_ (u"ࠫࠬ懌"),[l11lll_l1_ (u"ࠬ࠭懍")],[ items[0] ]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡇࡖࡘࡗࡋࡁࡎࠩ懎"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ櫘")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪ櫙")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllllll_l1_ = l1ll11l_l1_[script_name][1]
l1l11ll1ll1_l1_ = l1ll11l_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1111l_l1_(url)
	elif mode==52: results = l1llllll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1ll1ll111111_l1_()
	elif mode==56: results = l1ll1l1llll1l_l1_()
	elif mode==57: results = l1lll11ll11_l1_(url,1)
	elif mode==58: results = l1lll11ll11_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ櫚"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭櫛"),l11lll_l1_ (u"ࠧࠨ櫜"),59,l11lll_l1_ (u"ࠨࠩ櫝"),l11lll_l1_ (u"ࠩࠪ櫞"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ櫟"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ櫠"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ櫡"),l11lll_l1_ (u"࠭ࠧ櫢"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ櫣"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ櫤")+l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠬ櫥"),l11lll_l1_ (u"ࠪࠫ櫦"),56)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ櫧"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ櫨")+l111ll_l1_+l11lll_l1_ (u"࠭วๅษไ่ฬ๋ࠧ櫩"),l11lll_l1_ (u"ࠧࠨ櫪"),55)
	return l11lll_l1_ (u"ࠨࠩ櫫")
def l1ll1ll111111_l1_():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ櫬"),l111ll_l1_+l11lll_l1_ (u"ࠪหาีหࠡษ็หๆ๊วๆࠩ櫭"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵࡮ࡦࡹࡨࡷࡹ࠭櫮"),51)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ櫯"),l111ll_l1_+l11lll_l1_ (u"࠭วโๆส้ࠥืววฮฬࠫ櫰"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪ櫱"),51)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ櫲"),l111ll_l1_+l11lll_l1_ (u"ࠩสาึࠦวืษไหฯࠦวๅษไ่ฬ๋ࠧ櫳"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡲࡡࡵࡧࡶࡸࠬ櫴"),51)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ櫵"),l111ll_l1_+l11lll_l1_ (u"ࠬอแๅษ่ࠤ่๊วิ์ๆ๎ฮ࠭櫶"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡥ࡯ࡥࡸࡹࡩࡤࠩ櫷"),51)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ櫸"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ櫹"),l11lll_l1_ (u"ࠩࠪ櫺"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ櫻"),l111ll_l1_+l11lll_l1_ (u"ࠫฬิส๋ษิࠤฬ็ไศ็้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ櫼"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡺࡱࡳࠫ櫽"),57)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭櫾"),l111ll_l1_+l11lll_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ櫿"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡶࡪࡼࡩࡦࡹࠪ欀"),57)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欁"),l111ll_l1_+l11lll_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ欂"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡶࡪࡧࡺࡷࠬ欃"),57)
	return
def l1ll1l1llll1l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ欄"),l111ll_l1_+l11lll_l1_ (u"࠭วฮัฮࠤฬ๊ๅิๆึ่ฬะࠧ欅"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡲࡪࡽࡥࡴࡶࠪ欆"),51)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ欇"),l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠣีฬฬฬสࠩ欈"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡰࡰࡲࡸࡰࡦࡸࠧ欉"),51)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ權"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮาࠢสฺฬ็วหࠢสู่๊ไิๆสฮࠬ欋"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱࡯ࡥࡹ࡫ࡳࡵࠩ欌"),51)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ欍"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢๆ่ฬู๊ไ์ฬࠫ欎"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡩ࡬ࡢࡵࡶ࡭ࡨ࠭欏"),51)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ欐"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ欑"),l11lll_l1_ (u"ࠬ࠭欒"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭欓"),l111ll_l1_+l11lll_l1_ (u"ࠧศะอ๎ฬืࠠๆี็ื้อสࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭欔"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡾࡵࡰࠨ欕"),57)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欖"),l111ll_l1_+l11lll_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ欗"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡳࡧࡹ࡭ࡪࡽࠧ欘"),57)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ欙"),l111ll_l1_+l11lll_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ欚"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡺ࡮࡫ࡷࡴࠩ欛"),57)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ欜"),l11lll_l1_ (u"ࠩࠪ欝"),url,url)
	if l11lll_l1_ (u"ࠪࡃࠬ欞") in url:
		parts = url.split(l11lll_l1_ (u"ࠫࡄ࠭欟"))
		url = parts[0]
		filter = l11lll_l1_ (u"ࠬࡅࠧ欠") + QUOTE(parts[1],l11lll_l1_ (u"࠭࠽ࠧ࠼࠲ࠩࠬ次"))
	else: filter = l11lll_l1_ (u"ࠧࠨ欢")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ欣"),l11lll_l1_ (u"ࠩࠪ欤"),filter,l11lll_l1_ (u"ࠪࠫ欥"))
	parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭欦"))
	sort,l1l11l1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11lll_l1_ (u"ࠬࡿ࡯ࡱࠩ欧"),l11lll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼ࠭欨"),l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡸ࠭欩")]:
		if type==l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ欪"): l11lll1l1_l1_=l11lll_l1_ (u"ࠩไ๎้๋ࠧ欫")
		elif type==l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ欬"): l11lll1l1_l1_=l11lll_l1_ (u"ู๊ࠫไิๆࠪ欭")
		#url = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡷࡩࡷ࠳ࡰࡳࡱࡪࡶࡦࡳࡳ࠰ࠩ欮") + QUOTE(l11lll1l1_l1_) + l11lll_l1_ (u"࠭࠯ࠨ欯") + l1l11l1_l1_ + l11lll_l1_ (u"ࠧ࠰ࠩ欰") + sort + filter
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩ欱") + QUOTE(l11lll1l1_l1_) + l11lll_l1_ (u"ࠩ࠲ࠫ欲") + l1l11l1_l1_ + l11lll_l1_ (u"ࠪ࠳ࠬ欳") + sort + filter
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ欴"),l11lll_l1_ (u"ࠬ࠭欵"),l11lll_l1_ (u"࠭ࠧ欶"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠧࠨ欷"),l11lll_l1_ (u"ࠨࠩ欸"),l11lll_l1_ (u"ࠩࠪ欹"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ欺"))
		#items = re.findall(l11lll_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡲࡺࡳࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡶࡪࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ欻"),html,re.DOTALL)
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡱࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡶࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠤࡳࡶࡪࡹࡢࡢࡵࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭欼"),html,re.DOTALL)
		l1l11l1l1ll_l1_=0
		for id,title,l1ll1l1lll11l_l1_,l1llll_l1_ in items:
			l1l11l1l1ll_l1_ += 1
			#l1llll_l1_ = l11lllllll_l1_ + l11lll_l1_ (u"࠭࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭欽") + l1llll_l1_ + l11lll_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ款")
			l1llll_l1_ = l1l11ll1ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡹ࠶࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࡱࡦ࡯࡮࠰ࠩ欿") + l1llll_l1_ + l11lll_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ歀")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭歁") + id
			if type==l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ歂"): addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ歃"),l111ll_l1_+title,link,53,l1llll_l1_)
			if type==l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭歄"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歅"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊ࠠࠨ歆")+title,link+l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ歇")+l1ll1l1lll11l_l1_+l11lll_l1_ (u"ࠪࡁࠬ歈")+title+l11lll_l1_ (u"ࠫࡂ࠭歉")+l1llll_l1_,52,l1llll_l1_)
	else:
		if type==l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ歊"): l11lll1l1_l1_=l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭歋")
		elif type==l11lll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ歌"): l11lll1l1_l1_=l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ歍")
		url = l11lllllll_l1_ + l11lll_l1_ (u"ࠩ࠲࡮ࡸࡵ࡮࠰ࡵࡨࡰࡪࡩࡴࡦࡦ࠲ࠫ歎") + sort + l11lll_l1_ (u"ࠪ࠱ࠬ歏") + l11lll1l1_l1_ + l11lll_l1_ (u"ࠫ࠲࡝ࡗ࠯࡬ࡶࡳࡳ࠭歐")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭歑"),l11lll_l1_ (u"࠭ࠧ歒"),l11lll_l1_ (u"ࠧࠨ歓"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ歔"))
		items = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡨࡡࡴࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ歕"),html,re.DOTALL)
		l1l11l1l1ll_l1_=0
		for id,l1ll1l1lll11l_l1_,l1llll_l1_,title in items:
			l1l11l1l1ll_l1_ += 1
			l1llll_l1_ = l11lllllll_l1_ + l11lll_l1_ (u"ࠪ࠳࡮ࡳࡧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ歖") + l1llll_l1_ + l11lll_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ歗")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ歘") + id
			if type==l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ歙"): addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭歚"),l111ll_l1_+title,link,53,l1llll_l1_)
			elif type==l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ歛"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ歜"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪ歝")+title,link+l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ歞")+l1ll1l1lll11l_l1_+l11lll_l1_ (u"ࠬࡃࠧ歟")+title+l11lll_l1_ (u"࠭࠽ࠨ歠")+l1llll_l1_,52,l1llll_l1_)
	title=l11lll_l1_ (u"ࠧึใะอࠥ࠭歡")
	if l1l11l1l1ll_l1_==16:
		for l1l11ll1lll_l1_ in range(1,13) :
			if not l1l11l1_l1_==str(l1l11ll1lll_l1_):
				#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠯ࡳࡶࡴ࡭ࡲࡢ࡯ࡶ࠳ࠬ止")+type+l11lll_l1_ (u"ࠩ࠲ࠫ正")+str(l1l11ll1lll_l1_)+l11lll_l1_ (u"ࠪ࠳ࠬ此")+sort + filter
				url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ步")+type+l11lll_l1_ (u"ࠬ࠵ࠧ武")+str(l1l11ll1lll_l1_)+l11lll_l1_ (u"࠭࠯ࠨ歧")+sort + filter
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ歨"),l111ll_l1_+title+str(l1l11ll1lll_l1_),url,51)
	return
def l1llllll_l1_(url):
	parts = url.split(l11lll_l1_ (u"ࠨ࠿ࠪ歩"))
	l1ll1l1lll11l_l1_ = int(parts[1])
	name = l111l_l1_(parts[2])
	name = name.replace(l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ歪"),l11lll_l1_ (u"ࠪࠫ歫"))
	l1llll_l1_ = parts[3]
	url = url.split(l11lll_l1_ (u"ࠫࡄ࠭歬"))[0]
	if l1ll1l1lll11l_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭歭"),l11lll_l1_ (u"࠭ࠧ歮"),l11lll_l1_ (u"ࠧࠨ歯"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ歰"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ歱"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ歲"),block,re.DOTALL)
		l1ll1l1lll11l_l1_ = int(items[-1])
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ歳"),l11lll_l1_ (u"ࠬ࠭歴"),l1ll1l1lll11l_l1_,l11lll_l1_ (u"࠭ࠧ歵"))
	#name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠣ歶") )
	#l1llll_l1_ = xbmc.getInfoLabel( l11lll_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠤ歷") )
	for l1lll11_l1_ in range(l1ll1l1lll11l_l1_,0,-1):
		link = url + l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ歸") + str(l1lll11_l1_)
		title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ歹")+name+l11lll_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ歺")+str(l1lll11_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ死"),l111ll_l1_+title,link,53,l1llll_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧ歼"),l11lll_l1_ (u"ࠧࠨ歽"),l11lll_l1_ (u"ࠨࠩ歾"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭歿"))
	l1ll1l1llll11_l1_ = re.findall(l11lll_l1_ (u"้ࠪฯ๎แาࠢ฼่๎ࠦิ้ใ้ࠣฬ้ำࠡส฼ำ࠳࠰࠿࡮ࡱࡰࡩࡳࡺ࡜ࠩࠤࠫ࠲࠯ࡅࠩࠣࠩ殀"),html,re.DOTALL)
	if l1ll1l1llll11_l1_:
		time = l1ll1l1llll11_l1_[1].replace(l11lll_l1_ (u"࡙ࠫ࠭殁"),l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ殂"))
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ殃"),l11lll_l1_ (u"ࠧࠨ殄"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠪ殅"),l11lll_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠิ์ๆ์๋ࠦๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ้ࠡำหࠥอไ้ไอࠫ殆")+l11lll_l1_ (u"ࠪࡠࡳ࠭殇")+time)
		return
	#if l11lll_l1_ (u"๋ࠫ฿สัำࠣ฽้๏้ࠠไ๋฽ࠥิืฤࠩ殈") in html:
	#	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭殉"),l11lll_l1_ (u"࠭ࠧ殊"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩ残"),l11lll_l1_ (u"ࠨ่฼ฮีืฺࠠๆ์ࠤํฺ่่ࠢั฻ศ࠭殌"))
	#	return
	l1ll1l1ll1lll_l1_,l1ll1l1lllll1_l1_ = [],[]
	l1ll1l1llllll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦ࡯ࡳ࡫ࡪ࡭ࡳࡥ࡬ࡪࡰ࡮ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ殍"),html,re.DOTALL)[0]
	l1ll1l1lll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡸࠠࡣࡣࡦ࡯ࡺࡶ࡟ࡰࡴ࡬࡫࡮ࡴ࡟࡭࡫ࡱ࡯ࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ殎"),html,re.DOTALL)[0]
	# l1llll1l1_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡲࡳ࠻ࠢࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ殏"),html,re.DOTALL)
	for server,link in links:
		if l11lll_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠬ殐") in server:
			server = l11lll_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵࠦࡳࡦࡴࡹࡩࡷ࠭殑")
			url = l1ll1l1lll1ll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࠥࡹࡥࡳࡸࡨࡶࠬ殒")
			url = l1ll1l1llllll_l1_ + link
		if l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ殓") in url:
			l1ll1l1ll1lll_l1_.append(url)
			l1ll1l1lllll1_l1_.append(l11lll_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠡࠩ殔")+server)
		l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸ࠩࡷࡵࡰ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࡜࠲ࡠࡁࡂ࠭࠭࠲ࠩ࠽ࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟ࡶࡴ࡯࠲ࡦࡶࡰࡦࡰࡧࠬࡺࡸ࡬ࠪࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡴࡡ࡮ࡧ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫࡲ࠹ࡵ࠹ࠢࠣࠫ࠰ࡹࡥࡳࡸࡨࡶ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡣࡱ࡫ࡪ࠮࡬ࡦࡰࠫࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠩ࠻ࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥࡵࡳ࡮࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡠ࡯࡝ࠪࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹࡿࡰࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡷࡵࡲࡩࡵࠪࠪࠤࠬ࠯࡛࠱࡟ࠍࠍࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࡩ࡭ࡱ࡫ࡴࡺࡲࡨ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࠡࠢࠣࠫ࠱࠭ࠠࠡࠩࠬࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡰࡤࡱࡪ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡦࡪ࡮ࡨࡸࡾࡶࡥࠬࠩࠣࠤࠬ࠱ࡳࡦࡴࡹࡩࡷ࠱ࠧࠡࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࠢࠣࠤ殕")
	# l1111lll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫࡲࡶ࠴࠻࠰࠭ࡃࡤࡲࡩ࡯࡭࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭殖"),html,re.DOTALL)
	links += re.findall(l11lll_l1_ (u"ࠬࡳࡰ࠵࠼࠱࠮ࡄࡢࡴࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭殗"),html,re.DOTALL)
	for server,link in links:
		filename = link.split(l11lll_l1_ (u"࠭࠯ࠨ殘"))[-1]
		filename = filename.replace(l11lll_l1_ (u"ࠧࡧࡣ࡯ࡰࡧࡧࡣ࡬ࠩ殙"),l11lll_l1_ (u"ࠨࠩ殚"))
		filename = filename.replace(l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ殛"),l11lll_l1_ (u"ࠪࠫ殜"))
		filename = filename.replace(l11lll_l1_ (u"ࠫ࠲࠭殝"),l11lll_l1_ (u"ࠬ࠭殞"))
		if l11lll_l1_ (u"࠭ࡢࡢࡥ࡮ࡹࡵ࠭殟") in server:
			server = l11lll_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠠࡴࡧࡵࡺࡪࡸࠧ殠")
			url = l1ll1l1lll1ll_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠭殡")
			url = l1ll1l1llllll_l1_ + link
		l1ll1l1ll1lll_l1_.append(url)
		l1ll1l1lllll1_l1_.append(l11lll_l1_ (u"ࠩࡰࡴ࠹ࠦࠠࠨ殢")+server+l11lll_l1_ (u"ࠪࠤࠥ࠭殣")+filename)
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫࡘ࡫࡬ࡦࡥࡷࠤ࡛࡯ࡤࡦࡱࠣࡕࡺࡧ࡬ࡪࡶࡼ࠾ࠬ殤"), l1ll1l1lllll1_l1_)
	if l1l_l1_ == -1 : return
	url = l1ll1l1ll1lll_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ殥"))
	return
def l1lll11ll11_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ殦"),l11lll_l1_ (u"ࠧࠨ殧"),url,url)
	if l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ殨") in url: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ殩")
	else: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ殪")
	l11l11l_l1_ = QUOTE(l11l11l_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ殫"),l11lll_l1_ (u"ࠬ࠭殬"),l11lll_l1_ (u"࠭ࠧ殭"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ殮"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ殯"),l11lll_l1_ (u"ࠩࠪ殰"),url,html)
	if type==1: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡺࡨࡧࡦࡰࡵࡩ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭殱"),html,re.DOTALL)
	elif type==2: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭殲"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࠬ殳"),block,re.DOTALL)
	if type==1:
		for l1ll1l1lll111_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭殴"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠧࡀࡵࡸࡦ࡬࡫࡮ࡳࡧࡀࠫ段")+l1ll1l1lll111_l1_,58)
	elif type==2:
		url,l1ll1l1lll111_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࠪ殶"))
		for l1ll111l1l11_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ殷"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠪࡃࡨࡵࡵ࡯ࡶࡵࡽࡂ࠭殸")+l1ll111l1l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭殹")+l1ll1l1lll111_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭殺"),l11lll_l1_ (u"࠭ࠧ殻"),search,search)
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ殼"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ殽"))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭殾"), l11ll1_l1_, l11lll_l1_ (u"ࠪࠫ殿"), l11lll_l1_ (u"ࠫࠬ毀"), True,l11lll_l1_ (u"ࠬ࠭毁"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ毂"))
	#html = response.content
	#cookies = response.cookies
	#l11l1l1l1_l1_ = cookies[l11lll_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࠨ毃")]
	#l1ll1l1lll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡥࡶࡶ࡫ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ毄"),html,re.DOTALL)
	#l1ll1l1lll1l1_l1_ = l1ll1l1lll1l1_l1_[0]
	#payload = l11lll_l1_ (u"ࠩࡢࡧࡸࡸࡦ࠾ࠩ毅") + l1ll1l1lll1l1_l1_ + l11lll_l1_ (u"ࠪࠪࡶࡃࠧ毆") + QUOTE(l111l1l_l1_)
	#headers = { l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ毇"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ毈") , l11lll_l1_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭毉"):l11lll_l1_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠩ毊")+l11l1l1l1_l1_ }
	#url = l11ll1_l1_ + l11lll_l1_ (u"ࠣ࠱ࡶࡩࡦࡸࡣࡩࠤ毋")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ毌"), url, payload, headers, True,l11lll_l1_ (u"ࠪࠫ母"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠲࡯ࡦࠪ毎"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ每")+l111l1l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ毐"),url,l11lll_l1_ (u"ࠧࠨ毑"),l11lll_l1_ (u"ࠨࠩ毒"),True,l11lll_l1_ (u"ࠩࠪ毓"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ比"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ毕"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ毖"),block,re.DOTALL)
	if items:
		for link,l1llll_l1_,title in items:
			#title = title.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ毗")).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ毘"))
			url = l11ll1_l1_ + link
			if l11lll_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ毙") in url:
				if l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ毚") in url:
					title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ毛")+title
					url = url.replace(l11lll_l1_ (u"ࠫࡄ࡫ࡰ࠾࠳ࠪ毜"),l11lll_l1_ (u"ࠬࡅࡥࡱ࠿࠳ࠫ毝"))
					url = url+l11lll_l1_ (u"࠭࠽ࠨ毞")+QUOTE(title)+l11lll_l1_ (u"ࠧ࠾ࠩ毟")+l1llll_l1_
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毠"),l111ll_l1_+title,url,52,l1llll_l1_)
				else:
					title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟โ์็้ࠥ࠭毡")+title
					addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ毢"),l111ll_l1_+title,url,53,l1llll_l1_)
	#else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ毣"),l11lll_l1_ (u"ࠬ࠭毤"),l11lll_l1_ (u"࠭࡮ࡰࠢࡵࡩࡸࡻ࡬ࡵࡵࠪ毥"),l11lll_l1_ (u"ࠧๅษࠣฮําฯ่ࠡอหหาࠠๅๆหัะ࠭毦"))
	return
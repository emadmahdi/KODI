# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from skIgoAvZ9t import *
nO6ukabcldeU = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨᶎ")
def F5M9LsnokGPEQ2XYfO7cuyr(EHnSrqQ7BvmGlOgYZdhTbCRtswA,yv8XxUjorzB2CRA4Jife73VMklHp=N9olEh0ZMtpOivVfBLK(u"ࠧࠨᶏ")):
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==  h5huy6MiXPNfQJF8(u"࠶ৗ"): tVurhaxeE2(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  HVibA2ES8lY(u"࠲৘"): fh904xAZLIjSWJGO3U(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  WmaPChRdQk3YcXwI6zS(u"࠴৙"): iuzEyP1jNa89DLM2Aex7v5BgH()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  ZhqJoOtcmTVID65HwnLj(u"࠶৚"): QceuJfq72gU6MPWzVdDLi3Kkv(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  h5huy6MiXPNfQJF8(u"࠸৛"): zzQtMflsiw()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠺ড়"): ZERUfKJBIvbeq03DoCSz()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠼ঢ়"): GT8XWZULDtz7sYlhIfVnE12rOK(vatyjK4hHAoZJ7rOq2lis(u"ࡗࡶࡺ࡫ઊ"),vatyjK4hHAoZJ7rOq2lis(u"ࡗࡶࡺ࡫ઊ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  N9olEh0ZMtpOivVfBLK(u"࠾৞"): TTzYj3ui8M5df7NF()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==  EEvLoMzFqrlKce(u"࠹য়"): gaAdytMl8wE()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==vatyjK4hHAoZJ7rOq2lis(u"࠲࠷࠳ৠ"): uKTvYFsa6z()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳࠸࠵ৡ"): JEb7sZe08huDkX2()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠴࠹࠷ৢ"): C7WR6c2en4b()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠵࠺࠹ৣ"): NN16ROQuHBLkV7nvqycxSFDwJ5()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶࠻࠴৤"): yPsEBgu9x2clFKL0z()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==PiFkQ5pCJy7fbX(u"࠷࠵࠶৥"): PKc3Opd5lhQk70()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠱࠶࠸০"): sLwcqUvWGBxmCJuRK8()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠲࠷࠺১"): eRvocs9nEDQTiSYmyBhaA()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠳࠸࠼২"): dNJD7LiuvmRosQHlCPr()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠴࠹࠾৩"): ABhni7W3m2u8IFYT1blE(f5uqIoSJzWBOFyrY78RXmVb(u"ࡘࡷࡻࡥઋ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==f5uqIoSJzWBOFyrY78RXmVb(u"࠵࠼࠶৪"): eOmTpqsU3KZLxMk2yDPJHz58Ri()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠶࠽࠱৫"): eG2scIZNdSKb4tYzJy70EgXMQPaFA()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠷࠷࠳৬"): TslhbYQgjWKB4GkneMc(yv8XxUjorzB2CRA4Jife73VMklHp,h5huy6MiXPNfQJF8(u"࡙ࡸࡵࡦઌ"),h5huy6MiXPNfQJF8(u"࡙ࡸࡵࡦઌ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==Xl3drKyI9HkDiPEf8RTjwu(u"࠱࠸࠵৭"): PKyL2wI9WdZEbzs4t5muq(VH9MDo5z1kxNF07uRJI(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨᶐ"),sDiKwnHcSlYFgWCy1Ak(u"࡚ࡲࡶࡧઍ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WmaPChRdQk3YcXwI6zS(u"࠲࠹࠷৮"): PKyL2wI9WdZEbzs4t5muq(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬᶑ"),l5mQdjWyczr7UJVnTp(u"ࡔࡳࡷࡨ઎"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==Xl3drKyI9HkDiPEf8RTjwu(u"࠳࠺࠹৯"): UhOq7M8WFpeYcbf4()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==h5huy6MiXPNfQJF8(u"࠴࠻࠻ৰ"): WG5T4EVpBciP1hb6()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠵࠼࠽ৱ"): W4xJfvuEX9b1D(EmK3ObA0cwv9Wy(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧᶒ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HVibA2ES8lY(u"࠶࠽࠸৲"): W4xJfvuEX9b1D(h5huy6MiXPNfQJF8(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨᶓ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==PiFkQ5pCJy7fbX(u"࠷࠷࠺৳"): W4xJfvuEX9b1D(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬᶔ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==ZhqJoOtcmTVID65HwnLj(u"࠱࠺࠲৴"): ddob1Mnwhm()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==FIHNSc5iuoZanQ2Ytl(u"࠲࠻࠴৵"): TT4cPAntjHQzpIR7F6Cye8fGLxhr5S()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==N9olEh0ZMtpOivVfBLK(u"࠳࠼࠶৶"): a9puCmZe8rgwqT4Vj2YGfNOUM0o()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==ZEiR0StquOzca9lvPAndYIX(u"࠴࠽࠸৷"): xd5HP0crFRLDbOsyEUv7KpuIqm()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EEvLoMzFqrlKce(u"࠵࠾࠺৸"): QjKShaOF03Y()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==oAXJCYqPgyGDtT(u"࠶࠿࠵৹"): PPjr5pBNOeM62gs()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EmK3ObA0cwv9Wy(u"࠷࠹࠷৺"): imMR2GLhKzEqW5kQjNx4DTr1()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱࠺࠹৻"): JJsjzVfwAuW3y9cmh6BtikraECT()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠲࠻࠻ৼ"): GRb39sL4Ym5g6PQcSXZz2A18DKO()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠳࠼࠽৽"): ECa7coilkxUZPMLFXNpKYe94()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==TWexH5PhS1(u"࠶࠸࠵৾"): fKNrbvcQ5EMqjlaBIzukX8nd(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==ZEiR0StquOzca9lvPAndYIX(u"࠷࠹࠷৿"): haHi7X9cIxTqslOg()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠸࠺࠲਀"): s6QR7FMlT8KHBSmfNa2Jq()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EEvLoMzFqrlKce(u"࠹࠴࠴ਁ"): ffyHSwtdljLoAWepB9O4zV2mNx()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳࠵࠶ਂ"): SSrFti7KLjqdYOCG4QXlBPfvIa(N9olEh0ZMtpOivVfBLK(u"ࡕࡴࡸࡩએ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==l5mQdjWyczr7UJVnTp(u"࠴࠶࠸ਃ"): DKzmZRFQaiMsd8nqv()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠵࠷࠺਄"): zzFuUXiBPOKfxvYAjH(Xl3drKyI9HkDiPEf8RTjwu(u"ࡈࡤࡰࡸ࡫ઐ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶࠸࠼ਅ"): woiPZbJMcS2Ee3D(EmK3ObA0cwv9Wy(u"ࡗࡶࡺ࡫ઑ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HVibA2ES8lY(u"࠷࠹࠾ਆ"): h3mxrocJMPK2W40BsRLI()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EEvLoMzFqrlKce(u"࠸࠺࠹ਇ"): pass
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠻࠰࠱ਈ"): v93oXyk5uN1FmZ()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠵࠱࠳ਉ"): NdLzqSV5pZmoElnKwAF()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶࠲࠵ਊ"): dVRNUoSrXi8HlKp4zmgqc9(TWexH5PhS1(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᶕ"),ttOu147wErcBvPaSMUY(u"ࡘࡷࡻࡥ઒"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HVibA2ES8lY(u"࠷࠳࠷਋"): a1eYzGNI9yDVF8P(oQjDxLF9fdtyCaJ5ZTO860ri1s)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==ZEiR0StquOzca9lvPAndYIX(u"࠸࠴࠹਌"): a1eYzGNI9yDVF8P(Yy5epgPqo7D2vT4mQREiuX)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==l5mQdjWyczr7UJVnTp(u"࠹࠵࠻਍"): pg9TfFdQ04ByUVxO()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==FIHNSc5iuoZanQ2Ytl(u"࠺࠶࠶਎"): bkfanGl0mAz8hM6(HH4JMrUDp3lq6hQ(u"࡙ࡸࡵࡦઓ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠻࠰࠸ਏ"): UUBtkHi6syZIDJluXmxr9g(yv8XxUjorzB2CRA4Jife73VMklHp,PiFkQ5pCJy7fbX(u"ࠧࠨᶖ"),Xl3drKyI9HkDiPEf8RTjwu(u"࡚ࡲࡶࡧઔ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==FIHNSc5iuoZanQ2Ytl(u"࠵࠱࠺ਐ"): m6EuNTYOlJ2ca0feSd5I4GrxZptC()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HVibA2ES8lY(u"࠶࠲࠼਑"): UB3C65zAD4hbI7()
	return
def UB3C65zAD4hbI7():
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࠩᶗ"),PiFkQ5pCJy7fbX(u"ࠩࠪᶘ"),VOq8Ekue4F(u"ࠪࠫᶙ"),PiFkQ5pCJy7fbX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶚ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧᶛ"))
	if VjwKs4GNQZ518kCl:
		SSrFti7KLjqdYOCG4QXlBPfvIa(h5huy6MiXPNfQJF8(u"ࡆࡢ࡮ࡶࡩક"))
		P8vtuTghFN7lWIS(jNhH3xrnWkFUqv8c09OybXRTl,sDiKwnHcSlYFgWCy1Ak(u"ࡖࡵࡹࡪગ"),sbgu4D2RFMYKm(u"ࡇࡣ࡯ࡷࡪખ"))
		KK47FGdX1TDfkb3AjHOQqghE(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࠧᶜ"),ttOu147wErcBvPaSMUY(u"ࠧࠨᶝ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᶞ"),ZhqJoOtcmTVID65HwnLj(u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤฬ๊ๅึ่฼ࠫᶟ"))
	return
def UUBtkHi6syZIDJluXmxr9g(x7NwSuz5ft4e,ZZDlzKqtL4ANVUcr,showDialogs):
	kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(n3xWSEN58XZl9eFydUmCfs2ArH)
	kC7JunVyQdExXTaB.text_factory = str
	SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
	if ggl6zFuXNdYTDieHCqGKRnVx: BuJEC9eURHGvAnPKbw06F7f8xZO5 = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ᶠ")
	else: BuJEC9eURHGvAnPKbw06F7f8xZO5 = f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪᶡ")
	SCnhp2blgkLJrvcqKmXdE.execute(VH9MDo5z1kxNF07uRJI(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ᶢ")+BuJEC9eURHGvAnPKbw06F7f8xZO5+sbgu4D2RFMYKm(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫᶣ")+x7NwSuz5ft4e+HH4JMrUDp3lq6hQ(u"ࠧࠣࠢ࠾ࠫᶤ"))
	UNrkdT39f5 = SCnhp2blgkLJrvcqKmXdE.fetchall()
	if UNrkdT39f5 and ZZDlzKqtL4ANVUcr in [HVibA2ES8lY(u"ࠨࠩᶥ"),TWexH5PhS1(u"ࠩࡨࡲࡦࡨ࡬ࡦࠩᶦ")]:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(ZhqJoOtcmTVID65HwnLj(u"ࠪࠫᶧ"),h5huy6MiXPNfQJF8(u"ࠫࠬᶨ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬ࠭ᶩ"),ZEiR0StquOzca9lvPAndYIX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᶪ"),VH9MDo5z1kxNF07uRJI(u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫᶫ")+x7NwSuz5ft4e+VOq8Ekue4F(u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩᶬ"))
		if VjwKs4GNQZ518kCl!=Xl3drKyI9HkDiPEf8RTjwu(u"࠳਒"): return
		SCnhp2blgkLJrvcqKmXdE.execute(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨᶭ")+BuJEC9eURHGvAnPKbw06F7f8xZO5+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨᶮ")+x7NwSuz5ft4e+ttOu147wErcBvPaSMUY(u"ࠫࠧࠦ࠻ࠨᶯ"))
	elif ZZDlzKqtL4ANVUcr in [uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬ࠭ᶰ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࠧᶱ")]:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠨᶲ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠩᶳ"),l5mQdjWyczr7UJVnTp(u"ࠩࠪᶴ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᶵ"),PiFkQ5pCJy7fbX(u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨᶶ")+x7NwSuz5ft4e+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩᶷ"))
		if VjwKs4GNQZ518kCl!=cbngtp9sqYi0DjeEMLRHJruKxm(u"࠴ਓ"): return
		if ggl6zFuXNdYTDieHCqGKRnVx: SCnhp2blgkLJrvcqKmXdE.execute(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭ᶸ")+x7NwSuz5ft4e+Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠣࠫࠣ࠿ࠬᶹ"))
		else: SCnhp2blgkLJrvcqKmXdE.execute(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨᶺ")+x7NwSuz5ft4e+ZhqJoOtcmTVID65HwnLj(u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩᶻ"))
	kC7JunVyQdExXTaB.commit()
	kC7JunVyQdExXTaB.close()
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵ਔ"))
	EO9Rts0AaGuk1qpPLXCY.executebuiltin(h5huy6MiXPNfQJF8(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧᶼ"))
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(l5mQdjWyczr7UJVnTp(u"࠶ਕ"))
	if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(sDiKwnHcSlYFgWCy1Ak(u"ࠫࠬᶽ"),EmK3ObA0cwv9Wy(u"ࠬ࠭ᶾ"),Xl3drKyI9HkDiPEf8RTjwu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᶿ"),ZhqJoOtcmTVID65HwnLj(u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ᷀"))
	if ZZDlzKqtL4ANVUcr in [EEvLoMzFqrlKce(u"ࠨࠩ᷁"),h5huy6MiXPNfQJF8(u"ࠩࡨࡲࡦࡨ࡬ࡦ᷂ࠩ")]: ABhni7W3m2u8IFYT1blE(showDialogs)
	return
def pg9TfFdQ04ByUVxO():
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,l5mQdjWyczr7UJVnTp(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭᷃"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ᷄"))
	KieXfJOBZmz0S3V = wk1vqFgrYO4WDu5(PiFkQ5pCJy7fbX(u"ࡉࡥࡱࡹࡥઘ"))
	YYJpewiy6A1v3ZkFWugsr9o = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡢ࡮ࠨ᷅")
	u8ulj14MTeOF = oAXJCYqPgyGDtT(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᷆")
	M3Igf41boWxHewTQvB0FO = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭᷇")
	for id,mXzxhH68tSFg,QWEuJVATdizDg8679CjxLOn,gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR,reason in reversed(KieXfJOBZmz0S3V):
		if id==ZEiR0StquOzca9lvPAndYIX(u"ࠨ࠲ࠪ᷈"):
			xZw9Ai5IXsD6ur1ORTHKMoeE,zz8cBaSUFifyLl59mDkV4p2 = gQCu6NU0q5n3K7myZ.split(f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡟ࡲࡀࡁࠧ᷉"))
			continue
		if YYJpewiy6A1v3ZkFWugsr9o!=Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡠࡳ᷊࠭"): YYJpewiy6A1v3ZkFWugsr9o += M3Igf41boWxHewTQvB0FO
		n9GNlZCisxWpEb1rqX5RAUjScJuT = vatyjK4hHAoZJ7rOq2lis(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ᷋")+id+TWexH5PhS1(u"ࠬࠦ࠺ࠡࠩ᷌")+PiFkQ5pCJy7fbX(u"࠭วๅีวห้ࠦ࠺ࠡࠩ᷍")+N9olEh0ZMtpOivVfBLK(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞᷎ࠩ")+QWEuJVATdizDg8679CjxLOn
		SR7NUj9vYW2B5lLai0DqF = f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ᷏ࠧ")+gQCu6NU0q5n3K7myZ
		O3PvLtuErnZygxlBzUI = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽รࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡ᷐ࠬ")+JobKQ5hDkIYC0iu48dGlTR
		yNXrMl0Q3w5uOIJZcizxKLC = TWexH5PhS1(u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิสหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᷑")+reason
		YYJpewiy6A1v3ZkFWugsr9o += n9GNlZCisxWpEb1rqX5RAUjScJuT+SR7NUj9vYW2B5lLai0DqF+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡡࡴࠧ᷒")+u8ulj14MTeOF+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬࡢ࡮ࠨᷓ")+O3PvLtuErnZygxlBzUI+yNXrMl0Q3w5uOIJZcizxKLC+cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭࡜࡯ࠩᷔ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(vatyjK4hHAoZJ7rOq2lis(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᷕ"),zz8cBaSUFifyLl59mDkV4p2,YYJpewiy6A1v3ZkFWugsr9o,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩᷖ"))
	return
def a1eYzGNI9yDVF8P(file):
	if file==Yy5epgPqo7D2vT4mQREiuX: PBGE5o9v8ghUnZTQF04JesVk = HH4JMrUDp3lq6hQ(u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩᷗ")
	elif file==oQjDxLF9fdtyCaJ5ZTO860ri1s: PBGE5o9v8ghUnZTQF04JesVk = PiFkQ5pCJy7fbX(u"ࠪๆํอฦๆࠢลาึࠦวๅใํำ๏๎็ศฬࠪᷘ")
	IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫᷙ"),ZEiR0StquOzca9lvPAndYIX(u"๋ࠬำฮࠩᷚ"),h5huy6MiXPNfQJF8(u"࠭ลึๆสัࠬᷛ"),ZhqJoOtcmTVID65HwnLj(u"ࠧฯำ๋ะࠬᷜ"),PiFkQ5pCJy7fbX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᷝ"),EEvLoMzFqrlKce(u"๊่ࠩࠥะั๋ัࠣษฺ๊วฮ่่ࠢๆࠦࠧᷞ")+PBGE5o9v8ghUnZTQF04JesVk+ZEiR0StquOzca9lvPAndYIX(u"ࠪࠤศ๋ࠠหำํำ๋ࠥำฮࠢส่๊๊แࠡมࠪᷟ"))
	if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==vatyjK4hHAoZJ7rOq2lis(u"࠶ਖ"):
		if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(file):
			try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(file)
			except: pass
		KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࠬᷠ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬ࠭ᷡ"),h5huy6MiXPNfQJF8(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᷢ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠧห็ุ้ࠣำࠠๆๆไࠤࠬᷣ")+PBGE5o9v8ghUnZTQF04JesVk)
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠱ਗ"):
		data = JOhs5QkibGTnZ0CD9dL(file)
		KK47FGdX1TDfkb3AjHOQqghE(sbgu4D2RFMYKm(u"ࠨࠩᷤ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࠪᷥ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᷦ"),N9olEh0ZMtpOivVfBLK(u"ࠫฯ๋ࠠฦื็หาࠦๅๅใࠣࠫᷧ")+PBGE5o9v8ghUnZTQF04JesVk)
	return
def NdLzqSV5pZmoElnKwAF():
	if XK3HqaTnjpyIAuhw67CmdvBM<g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲࠺ਘ"):
		F67qZAgMjPukRfJ = ZEiR0StquOzca9lvPAndYIX(u"๊ࠬไฤีไࠤศ์สࠡฬึฮำีๅࠡวุำฬืࠠไ๊า๎่ࠥฯ๋็ࠣี็๋ࠠࠨᷨ")+str(XK3HqaTnjpyIAuhw67CmdvBM)+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"้࠭ࠠๆ๊ิฬࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡๆสࠤฯ฿ๅๅࠢ฼๊ิ้ࠠ࠯๊ࠢิ์ࠦวๅ็ํึฮࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥอไโ์า๎ํํวหࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠠ࠯ࠢ็ษฺ๊วฮࠢสฺ่๊ใๅหࠣๆ๊ࠦศหฯา๎ะࠦศา่ส้ัࠦใ้ัํࠤส๊้ࠡวํࠤส฻ฯศำࠣี็๋็ࠡล฼่๎ࠦๅ็ࠢ࠴࠼࠳࠶ࠧᷩ")
		KK47FGdX1TDfkb3AjHOQqghE(PiFkQ5pCJy7fbX(u"ࠧࠨᷪ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨࠩᷫ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷬ"),F67qZAgMjPukRfJ)
		return
	yPYItiEgxhwB9TmWN6cAU = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(ZhqJoOtcmTVID65HwnLj(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ᷭ"))
	VXp2ouLAg5Mz8jct1hf6m = tnmgjKPYByiL0q([PiFkQ5pCJy7fbX(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᷮ")])
	PgjqxZL23vFVYUfDe7RBOrS5n,Vm3HhzSb7ga1PpuK0Cdko,zPaNi29AO6sU,hIwRXGs92bEOS4AUMiD,XNmE8qVa2Li56x3hIdtv,C0CEPae4ID,RRYUotMfpSxKd4QnyFi = VXp2ouLAg5Mz8jct1hf6m[EEvLoMzFqrlKce(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᷯ")]
	if PgjqxZL23vFVYUfDe7RBOrS5n or N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬᷰ") not in str(yPYItiEgxhwB9TmWN6cAU):
		KK47FGdX1TDfkb3AjHOQqghE(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨᷱ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠩᷲ"),l5mQdjWyczr7UJVnTp(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷳ"),VH9MDo5z1kxNF07uRJI(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨᷴ"))
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = dVRNUoSrXi8HlKp4zmgqc9(f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ᷵"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡘࡷࡻࡥઙ"))
		if not UkYj1KP0ou4q9rVfEgn2JQHI56BG: return
	tDfC9YHmrwBF(Xl3drKyI9HkDiPEf8RTjwu(u"࡙ࡸࡵࡦચ"))
	return
def tDfC9YHmrwBF(showDialogs=sbgu4D2RFMYKm(u"࡚ࡲࡶࡧછ")):
	yPYItiEgxhwB9TmWN6cAU = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(vatyjK4hHAoZJ7rOq2lis(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨ᷶"))
	if N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ᷷ࠬ") not in str(yPYItiEgxhwB9TmWN6cAU):
		if showDialogs:
			KK47FGdX1TDfkb3AjHOQqghE(WmaPChRdQk3YcXwI6zS(u"ࠧࠨ᷸"),ZEiR0StquOzca9lvPAndYIX(u"ࠨ᷹ࠩ"),l5mQdjWyczr7UJVnTp(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ᷺ࠬ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"่้ࠪษำโࠢฯ๋ฬุใࠡๆสࠤ๏ูสฯั่ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ᷻"))
		return
	m7ofvTiQnU9wL1IVJaRKA42NbeXxMB = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,l5mQdjWyczr7UJVnTp(u"ࠫࡦࡪࡤࡰࡰࡶࠫ᷼"),l5mQdjWyczr7UJVnTp(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ᷽ࠫ"),HH4JMrUDp3lq6hQ(u"࠭࠷࠳࠲ࡳࠫ᷾"),ttOu147wErcBvPaSMUY(u"ࠧࡎࡻ࡙࡭ࡩ࡫࡯ࡏࡣࡹ࠲ࡽࡳ࡬ࠨ᷿"))
	if not isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(m7ofvTiQnU9wL1IVJaRKA42NbeXxMB): return
	xOnG9rbvo6mYRU5y0dKBj = open(m7ofvTiQnU9wL1IVJaRKA42NbeXxMB,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡴࡥࠫḀ")).read()
	if mmIKCGujwM: xOnG9rbvo6mYRU5y0dKBj = xOnG9rbvo6mYRU5y0dKBj.decode(l5mQdjWyczr7UJVnTp(u"ࠩࡸࡸ࡫࠾ࠧḁ"))
	JNH6ImYoZUgB5lWMRCTO0s17w = T072lCzjYiuaeFtmJGV.findall(FIHNSc5iuoZanQ2Ytl(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠬࡡࡪࠫ࠭࡞ࡧ࠯࠱ࡢࡤࠬࠫ࠯ࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪḂ"),xOnG9rbvo6mYRU5y0dKBj,T072lCzjYiuaeFtmJGV.DOTALL)
	wF8n0L7Nja5YiQM2vcfWk,tLjCucZksW = JNH6ImYoZUgB5lWMRCTO0s17w[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠲ਙ")]
	Vq4xehz1TtvnAZkrBQN = sDiKwnHcSlYFgWCy1Ak(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬḃ")+wF8n0L7Nja5YiQM2vcfWk+l5mQdjWyczr7UJVnTp(u"ࠬ࠲ࠧḄ")+tLjCucZksW+l5mQdjWyczr7UJVnTp(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨḅ")
	if showDialogs:
		eesOSM24ETmrdCH8fuB = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡚࡮࡫ࡷ࡮ࡱࡧࡩࠬḆ"))
		if eesOSM24ETmrdCH8fuB==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫḇ"): qn4OFHeGVWjwJf3h1E2ZR = N9olEh0ZMtpOivVfBLK(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩḈ")
		elif eesOSM24ETmrdCH8fuB==HH4JMrUDp3lq6hQ(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩḉ"): qn4OFHeGVWjwJf3h1E2ZR = FIHNSc5iuoZanQ2Ytl(u"ࠫ็๎วว็ࠣห้฻่าࠩḊ")
		else: qn4OFHeGVWjwJf3h1E2ZR = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"่่ࠬศศ่ࠤศิั๊ࠩḋ")
		IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ḍ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧใ๊สส๊ࠦรฯำ์ࠫḍ"),ZhqJoOtcmTVID65HwnLj(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨḎ"),oAXJCYqPgyGDtT(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧḏ"),WmaPChRdQk3YcXwI6zS(u"ࠪห๋ะࠠฮษ็๎ฬࠦสิฬัำ๊ࠦࠧḐ")+qn4OFHeGVWjwJf3h1E2ZR,oAXJCYqPgyGDtT(u"ࠫฬ์สࠡษ็ฦ๋ࠦสิฬัำ๊ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์ใࠡฬึฮ฼๐ูࠡษึฮำีวๆࠢส่็๎วว็ࠣห้๋ี้ำฬࠤอีไศ่๊่่ࠢࠥศศ่ࠤฬ๊ใหษหอࠥ࠴้ࠠลํฺฬࠦสิฬฺ๎฾ࠦล๋ไสๅ์อࠠโ์ࠣว๏่ࠦใฬࠣฮูอมࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ḑ"))
		if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==PiFkQ5pCJy7fbX(u"࠴ਚ"): NYDfWbzp2T9wKtMimE = ttOu147wErcBvPaSMUY(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨḒ")
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶ਛ"): NYDfWbzp2T9wKtMimE = ZEiR0StquOzca9lvPAndYIX(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬḓ")
		else: NYDfWbzp2T9wKtMimE = EmK3ObA0cwv9Wy(u"ࠧࠨḔ")
	else:
		eesOSM24ETmrdCH8fuB = YTPut68WBVUNCvsEzg.getSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭ḕ"))
		if   eesOSM24ETmrdCH8fuB==N9olEh0ZMtpOivVfBLK(u"ࠩࠪḖ"): IXT3PBU82c54ekwMFZhQKy9t0d7ROb = ZEiR0StquOzca9lvPAndYIX(u"࠵ਜ")
		elif eesOSM24ETmrdCH8fuB==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ḗ"): IXT3PBU82c54ekwMFZhQKy9t0d7ROb = ZhqJoOtcmTVID65HwnLj(u"࠷ਝ")
		elif eesOSM24ETmrdCH8fuB==mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪḘ"): IXT3PBU82c54ekwMFZhQKy9t0d7ROb = oAXJCYqPgyGDtT(u"࠲ਞ")
		NYDfWbzp2T9wKtMimE = eesOSM24ETmrdCH8fuB
	if   IXT3PBU82c54ekwMFZhQKy9t0d7ROb==ZEiR0StquOzca9lvPAndYIX(u"࠱ਟ"): LVS2m8QxUZoRC36qgcthyB5DOJHN = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩḙ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠳ਠ"): LVS2m8QxUZoRC36qgcthyB5DOJHN = EEvLoMzFqrlKce(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪḚ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==HH4JMrUDp3lq6hQ(u"࠵ਡ"): LVS2m8QxUZoRC36qgcthyB5DOJHN = vatyjK4hHAoZJ7rOq2lis(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫḛ")
	else: return
	YTPut68WBVUNCvsEzg.setSetting(FIHNSc5iuoZanQ2Ytl(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭Ḝ"),NYDfWbzp2T9wKtMimE)
	hdMVw8fnkp5s6bvCZUHB = WmaPChRdQk3YcXwI6zS(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪḝ")+LVS2m8QxUZoRC36qgcthyB5DOJHN+l5mQdjWyczr7UJVnTp(u"ࠪ࠰ࠬḞ")+tLjCucZksW+sDiKwnHcSlYFgWCy1Ak(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ḟ")
	gmoEyP1szUOAFwfMdDGhXxb7W = xOnG9rbvo6mYRU5y0dKBj.replace(Vq4xehz1TtvnAZkrBQN,hdMVw8fnkp5s6bvCZUHB)
	if mmIKCGujwM: gmoEyP1szUOAFwfMdDGhXxb7W = gmoEyP1szUOAFwfMdDGhXxb7W.encode(VOq8Ekue4F(u"ࠬࡻࡴࡧ࠺ࠪḠ"))
	open(m7ofvTiQnU9wL1IVJaRKA42NbeXxMB,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࡷࡣࠩḡ")).write(gmoEyP1szUOAFwfMdDGhXxb7W)
	GZvEITHSg5U3rVwQ(vatyjK4hHAoZJ7rOq2lis(u"ࠧࡏࡑࡗࡍࡈࡋࠧḢ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨ࠰ࠣࠤࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭ḣ")+LVS2m8QxUZoRC36qgcthyB5DOJHN+sDiKwnHcSlYFgWCy1Ak(u"ࠩࠣࡡࠬḤ"))
	if showDialogs: EO9Rts0AaGuk1qpPLXCY.executebuiltin(Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩḥ"))
	return
def v93oXyk5uN1FmZ():
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(sbgu4D2RFMYKm(u"ࠫࠬḦ"),l5mQdjWyczr7UJVnTp(u"ࠬ࠭ḧ"),FIHNSc5iuoZanQ2Ytl(u"࠭ࠧḨ"),VOq8Ekue4F(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪḩ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨสิ๊ฬ๋ฬࠡ฻่หิࠦแู๋้้้ࠣไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤส๋วࠡล็ษฺีวาࠢๅำ๏๋ࠠ࠯࠰࠱ࠤศ๎ࠠศ่อࠤ๊๋ๆ้฻้๋ࠣࠦวิฬัำฬ๋ࠠศๆหี๋อๅอࠢ࠱࠲࠳ࠦร้ࠢ็ำ๏้ࠠๆึๆ่ฮࠦรฯำ์ࠤฯิีࠡฮ๊หื้ࠠฤ่อࠤํ๊วࠡฬัูࠥฮโ๋หࠣา้่ࠠศๆ็๋ࠥࡢ࡮࡝ࡰࠣัฬ๎ไࠡฬะำ๏ัࠠศๆหี๋อๅอࠢฦ์ࠥอสึๆࠣฬฬ๊ๅษำ่ะ๊ࠥๅฺำไอูࠥศษࠢสฺ่๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦแฮืࠣห้ะอะ์ฮหฯࠦวๅฤ้ࠤฤ࠭Ḫ"))
	if VjwKs4GNQZ518kCl==PiFkQ5pCJy7fbX(u"࠵ਢ"): GT8XWZULDtz7sYlhIfVnE12rOK(EEvLoMzFqrlKce(u"ࡔࡳࡷࡨજ"),EEvLoMzFqrlKce(u"ࡔࡳࡷࡨજ"))
	return
def TTzYj3ui8M5df7NF():
	KK47FGdX1TDfkb3AjHOQqghE(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࠪḫ"),oAXJCYqPgyGDtT(u"ࠪࠫḬ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧḭ"),h5huy6MiXPNfQJF8(u"ࠬํะศࠢส่๊๎โฺ่ࠢ฾้่ࠠๆ่ࠣห้๋ีะำࠣ์฿๐ัࠡ็฼ีํ็ࠠๆฬํࠤ๏ืฬฺࠢ็่฾๋ไࠨḮ"))
	return
def h3mxrocJMPK2W40BsRLI():
	n9GNlZCisxWpEb1rqX5RAUjScJuT = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ฼ำฬีࠠี์฼อࠥศไࠡ็ะ้ิࠦไิ่ฬࠤ࠷࠶࠲࠲ࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ḯ")
	n9GNlZCisxWpEb1rqX5RAUjScJuT += EmK3ObA0cwv9Wy(u"ࠧศๆ่์็฿ࠠฤั้ห์ࠦแ๋้ࠣษา฻วว์ฬࠤ้฿ฯะࠢสู่๐ูสࠢไ๎ࠥอไฺษ็้ࠥะๅࠡฮ่฽์อࠠๆ่ࠣะ๊๐ูࠡษ็ฺ้อฯาࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่็ี๊ๆหࠣ์ฬ๊ฬะ์าอࠥอไฮๅ๋้๏ฯ้ࠠษ็฾๏ืࠠฮๅ๋้๏ฯ้ࠠ็้ࠤัฺ๋๊ࠢา์้ࠦวๅ฻ส่๊ࠦหๆࠢอ้ࠥะ่ฮ์า๋ฬ่ࠦฮีสฬࠥอไๆ฻า่ࠥำำษࠢึ็ฬ์ࠠะ๊็ࠤฬู๊ศๆ่ࠤู้ๆสࠢ࠵࠴࠷࠷้้ࠠํࠤฬ๊ลฮืสส๏ฯࠠศๆฦัิั้ࠠษ็วู๋ไࠡษ็ฮ๏ࠦสๆࠢ฼้้ํวࠡใํࠤฬ๊ำ็๊สฮࠥอไฺึิอࠥอไๆษู๎ฮ࠭Ḱ")
	n9GNlZCisxWpEb1rqX5RAUjScJuT += ttOu147wErcBvPaSMUY(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯ࡴࡪ࡬ࡥࡨࡵࡵ࡯ࡶ࡞࠳ࡈࡕࡌࡐࡔࡠࠫḱ")
	SR7NUj9vYW2B5lLai0DqF = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡอืๆศ็ฯࠤูืุ๊ࠢสู่๊ไๆࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ḳ")
	SR7NUj9vYW2B5lLai0DqF += PiFkQ5pCJy7fbX(u"๋ࠪํูࠦษษิอࠥ฿ๆࠡสิ๊ฬ๋ฬࠡ์๋ๅึࠦๅฺๆ๋้ฬะࠠฮีสฬ๏ฯࠠไอํีฮࠦส่็ࠣะ๊๐ูࠡษ็ุ้๊ๅ๋่้ࠣะ๊ࠠฤ๊ๅหฯࠦวๅื็หฮ่ࠦฤ๊ๅหฯࠦวๅๅึ์ๆ่ࠦศๆัืํ็้ࠠึๆ่ࠥอไใ็ิࠤํษ่ใษอࠤฬ๊โๆำࠣ์ศ๐ึศࠢํ์ๆืࠠาฦํอࠥอไ่ๆส่ࠥ็๊ࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣ์ศ๐ึศࠢไ๎์ࠦสใ๊ํ้๋๊ࠥๅษา๎ࠥ๎็อำํࠤํ็๊่ࠢฦ๎฻อࠠษฯฮࠤํ่ัศรฬࠤฬ๊โาฤ้ࠤํษ๊ืษࠣๅ๏ํࠠศีอาฬืษ๊ࠡอๅฬสไ๊ࠡไ๎์ࠦรใ๊ส่๋ࠥๆิ๊หอ๊ࠥไฤ็ส้ࠥ฿ไ๋๋ࠢว๊๎ัࠡลัี๎ࠦส่็ࠣ็้ࠦๅิๆ่ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ็ๆฮํฮࠠษๆ฽อࠥาวโษࠣื่ืศห๋ࠢ๎ุะฮะ็๊ࠣ฽อๅ๊ࠡํ๊ิ๎าࠡฬะฮࠥฮ๊วหࠣ์๏์ฯ้ิࠣ็ฬา๊ห๋้ࠢำ฻ีࠡใๅ฻๊ࠥรอ้ีอࠥอไ้์้ำํุࠠ࠯ࠢส่๊๎โฺࠢส่ึูๅ๋ࠢ็่อืๆศ็ฯࠤ์๎ࠧḳ")
	SR7NUj9vYW2B5lLai0DqF += N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲ࡱࡺࡹ࡬ࡪ࡯ࡵࡹࡱ࡫ࡲ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩḴ")
	F67qZAgMjPukRfJ = EmK3ObA0cwv9Wy(u"ࠬࡡࡒࡕࡎࡠࠫḵ")+n9GNlZCisxWpEb1rqX5RAUjScJuT+EmK3ObA0cwv9Wy(u"࠭࡜࡯࡞ࡱࡠࡳࡡࡒࡕࡎࡠࠫḶ")+SR7NUj9vYW2B5lLai0DqF
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(TWexH5PhS1(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ḷ"),ZEiR0StquOzca9lvPAndYIX(u"ࠨࠩḸ"),F67qZAgMjPukRfJ)
	return
def zzFuUXiBPOKfxvYAjH(jDSoFcA19T):
	ktfQu3jy0hq5mTC4RON(jDSoFcA19T,ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪઝ"))
	KieXfJOBZmz0S3V = wk1vqFgrYO4WDu5(jDSoFcA19T)
	id,mXzxhH68tSFg,QWEuJVATdizDg8679CjxLOn,gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR,reason = KieXfJOBZmz0S3V[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠵ਣ")]
	xZw9Ai5IXsD6ur1ORTHKMoeE,zz8cBaSUFifyLl59mDkV4p2 = gQCu6NU0q5n3K7myZ.split(WmaPChRdQk3YcXwI6zS(u"ࠩ࡟ࡲࡀࡁࠧḹ"))
	SR7NUj9vYW2B5lLai0DqF,O3PvLtuErnZygxlBzUI,yNXrMl0Q3w5uOIJZcizxKLC = JobKQ5hDkIYC0iu48dGlTR.split(HVibA2ES8lY(u"ࠪࡠࡳࡁ࠻ࠨḺ"))
	vvEKkNf5AgFYLlI8MozrCBs7m = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡖࡵࡹࡪઞ")
	while vvEKkNf5AgFYLlI8MozrCBs7m:
		bUoeP0Z38Tptfqi = GNX3qVRf4oBdtkEi5u(HH4JMrUDp3lq6hQ(u"ࠫࠬḻ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬิั้ฮࠪḼ"),FIHNSc5iuoZanQ2Ytl(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬḽ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧใษษ้ฮࠦวๅฬหี฾อสࠨḾ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨๆศ๎็อแࠡษ็ษ฾๊ว็ษอࠤ࠿ࠦࠠหสิ฽ࠥษ่ࠡษ่ืาࠦวๅสิ๊ฬ๋ฬࠨḿ"),SR7NUj9vYW2B5lLai0DqF)
		if bUoeP0Z38Tptfqi==ZEiR0StquOzca9lvPAndYIX(u"࠸ਤ"): Iv3DaLEHBTu7QdJmVMRYCxzq6KSpF = GNX3qVRf4oBdtkEi5u(oAXJCYqPgyGDtT(u"ࠩࠪṀ"),ZEiR0StquOzca9lvPAndYIX(u"ࠪࠫṁ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫ฾๎ฯสࠩṂ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬ࠭ṃ"),WmaPChRdQk3YcXwI6zS(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭Ṅ"),O3PvLtuErnZygxlBzUI,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫṅ"))
		elif bUoeP0Z38Tptfqi==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠱ਥ"): fh904xAZLIjSWJGO3U()
		else: vvEKkNf5AgFYLlI8MozrCBs7m = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡉࡥࡱࡹࡥટ")
	EO9Rts0AaGuk1qpPLXCY.executebuiltin(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬṆ"))
	return
def SSrFti7KLjqdYOCG4QXlBPfvIa(showDialogs):
	VjwKs4GNQZ518kCl = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡘࡷࡻࡥઠ")
	if showDialogs: VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(h5huy6MiXPNfQJF8(u"ࠩࡦࡩࡳࡺࡥࡳࠩṇ"),EmK3ObA0cwv9Wy(u"ࠪࠫṈ"),EEvLoMzFqrlKce(u"ࠫࠬṉ"),VOq8Ekue4F(u"ูࠬฤศๆࠪṊ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭็ๅࠢฦ๊ฯࠦๅหลๆำࠥ๎สา์าࠤู๊อ๊ࠡอูๆ๐ัࠡฮ่๎฾ࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥำ๊ฬࠢอ฽ํีࠠอ็ํ฽ࠥอไฦ฻าหิอสࠡว็ํࠥ๎ึฺ์ฬࠤฯัศ๋ฬࠣห้ฮั็ษ่ะࠥลࠧṋ"))
	if VjwKs4GNQZ518kCl:
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࡙ࡸࡵࡦડ")
		if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(h8sqctmx4oFT76NHuQpKdOB9RPEiI):
			try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(h8sqctmx4oFT76NHuQpKdOB9RPEiI)
			except: UkYj1KP0ou4q9rVfEgn2JQHI56BG = VH9MDo5z1kxNF07uRJI(u"ࡌࡡ࡭ࡵࡨઢ")
		if showDialogs:
			if UkYj1KP0ou4q9rVfEgn2JQHI56BG: KK47FGdX1TDfkb3AjHOQqghE(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨṌ"),FIHNSc5iuoZanQ2Ytl(u"ࠨࠩṍ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࠪṎ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪฮ๊ࠦศ็ฮสั๋ࠥำฮ๋ࠢฮฺ็๊า่่ࠢๆࠦลฺัสำฬะࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪṏ"))
			else: KK47FGdX1TDfkb3AjHOQqghE(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬṐ"),EEvLoMzFqrlKce(u"ࠬ࠭ṑ"),N9olEh0ZMtpOivVfBLK(u"࠭ࠧṒ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หุ้ࠣำࠠๆๆไࠤฬ๊ลฺัสำฬะࠧṓ"))
	return
def DKzmZRFQaiMsd8nqv():
	ddob1Mnwhm()
	ZaEXhgyGSoJRn = YTPut68WBVUNCvsEzg.getSetting(Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧṔ"))
	F67qZAgMjPukRfJ = {}
	F67qZAgMjPukRfJ[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡄ࡙࡙ࡕࠧṕ")] = VH9MDo5z1kxNF07uRJI(u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩṖ")
	F67qZAgMjPukRfJ[l5mQdjWyczr7UJVnTp(u"ࠫࡘ࡚ࡏࡑࠩṗ")] = HVibA2ES8lY(u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫṘ")
	F67qZAgMjPukRfJ[ttOu147wErcBvPaSMUY(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧṙ")] = l5mQdjWyczr7UJVnTp(u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨṚ")+str(GGkgJ2RMcEZ/WmaPChRdQk3YcXwI6zS(u"࠷࠲ਦ"))+FIHNSc5iuoZanQ2Ytl(u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬṛ")
	ffBvxFX80HUywYDI5jO2 = F67qZAgMjPukRfJ[ZaEXhgyGSoJRn]
	IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࠪṜ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪ็ฬฺࠠࠨṝ")+str(GGkgJ2RMcEZ/EmK3ObA0cwv9Wy(u"࠸࠳ਧ"))+Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࠥีโ๋ไฬࠫṞ"),l5mQdjWyczr7UJVnTp(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫṟ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ล๋ไสๅ้ࠥวๆๆࠪṠ"),ffBvxFX80HUywYDI5jO2,sDiKwnHcSlYFgWCy1Ak(u"่ࠧๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่่อิࠡษ็ิ่๐ࠠศๆอ่็อฦ๋ࠢฦ้ࠥะั๋ัࠣษ๏่วโࠢส่่อิࠡสส่่อๅๅࠢฦ้ࠥะั๋ัࠣ็ฬฺฺࠠ็ิ๋่ࠥี๋ำࠣะิอࠠภࠣࠪṡ"))
	if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠳ਨ"): MsStKG321Y5CeX0JpIOQAZ9lHP = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩṢ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵਩"): MsStKG321Y5CeX0JpIOQAZ9lHP = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡄ࡙࡙ࡕࠧṣ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠷ਪ"): MsStKG321Y5CeX0JpIOQAZ9lHP = Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡗ࡙ࡕࡐࠨṤ")
	else: MsStKG321Y5CeX0JpIOQAZ9lHP = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࠬṥ")
	if MsStKG321Y5CeX0JpIOQAZ9lHP:
		YTPut68WBVUNCvsEzg.setSetting(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫṦ"),MsStKG321Y5CeX0JpIOQAZ9lHP)
		QQn7jCsa4Yw8AyVRpk5rUhXMzvt = F67qZAgMjPukRfJ[MsStKG321Y5CeX0JpIOQAZ9lHP]
		KK47FGdX1TDfkb3AjHOQqghE(EmK3ObA0cwv9Wy(u"࠭ࠧṧ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠨṨ"),ttOu147wErcBvPaSMUY(u"ࠨࠩṩ"),QQn7jCsa4Yw8AyVRpk5rUhXMzvt)
	return
def ffyHSwtdljLoAWepB9O4zV2mNx():
	F67qZAgMjPukRfJ = {}
	F67qZAgMjPukRfJ[ZEiR0StquOzca9lvPAndYIX(u"ࠩࡄ࡙࡙ࡕࠧṪ")] = ZEiR0StquOzca9lvPAndYIX(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨṫ")
	F67qZAgMjPukRfJ[EmK3ObA0cwv9Wy(u"ࠫࡆ࡙ࡋࠨṬ")] = N9olEh0ZMtpOivVfBLK(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩṭ")
	F67qZAgMjPukRfJ[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡓࡕࡑࡓࠫṮ")] = ZEiR0StquOzca9lvPAndYIX(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪṯ")
	C9SFIbNslx7Tt4KiM = YTPut68WBVUNCvsEzg.getSetting(HVibA2ES8lY(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨṰ"))
	ZaEXhgyGSoJRn = YTPut68WBVUNCvsEzg.getSetting(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬṱ"))
	ffBvxFX80HUywYDI5jO2 = F67qZAgMjPukRfJ[ZaEXhgyGSoJRn]+C9SFIbNslx7Tt4KiM
	IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠫṲ"),EEvLoMzFqrlKce(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩṳ"),ttOu147wErcBvPaSMUY(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫṴ"),EEvLoMzFqrlKce(u"࠭ล๋ไสๅ้ࠥวๆๆࠪṵ"),ffBvxFX80HUywYDI5jO2,VOq8Ekue4F(u"ࠧิ์ิๅึࠦࡄࡏࡕ๋ࠣํࠦฬ่ษีࠤๆ๐ࠠศๆศ๊ฯืๆ๋ฬࠣ๎็๎ๅࠡสอัํ๐ไࠡลึ้ฬวࠠศๆ่์ฬู่๊ࠡสุ่๐ัโำสฮࠥหไ๊ࠢฦี็อๅ๊ࠡ฼๊ิࠦศฺุࠣห้์วิࠢํๆํ๋ࠠษฯฯฬࠥ๎ๅ็฻ࠣ์า฼ัࠡส฼ฺࠥอไๆ๊สๆ฾ࠦ࠮ࠡๆอุ฿๐ไࠡีํีๆืࠠࡅࡐࡖࠤ็๋ࠠษษัฮ๏อัࠡษ็ื๏ืแาࠢส่๊์วิสࠣวํࠦโๆࠢหษ๏่วโ้ࠣฬฬ๊ใศ็็ࠫṶ"))
	if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==HVibA2ES8lY(u"࠶ਫ"): MsStKG321Y5CeX0JpIOQAZ9lHP = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡃࡖࡏࠬṷ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==WmaPChRdQk3YcXwI6zS(u"࠱ਬ"): MsStKG321Y5CeX0JpIOQAZ9lHP = sbgu4D2RFMYKm(u"ࠩࡄ࡙࡙ࡕࠧṸ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==VH9MDo5z1kxNF07uRJI(u"࠳ਭ"): MsStKG321Y5CeX0JpIOQAZ9lHP = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡗ࡙ࡕࡐࠨṹ")
	if IXT3PBU82c54ekwMFZhQKy9t0d7ROb in [vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ਯ"),l5mQdjWyczr7UJVnTp(u"࠳ਮ")]:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(FIHNSc5iuoZanQ2Ytl(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫṺ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ู๊ࠬาใิ࠾ࠥ࠭ṻ")+xfhCjTXRaFBGOE[Xl3drKyI9HkDiPEf8RTjwu(u"࠵ਰ")],l5mQdjWyczr7UJVnTp(u"࠭ำ๋ำไี࠿ࠦࠧṼ")+xfhCjTXRaFBGOE[Xl3drKyI9HkDiPEf8RTjwu(u"࠵਱")],uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠨṽ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧṾ"))
		if VjwKs4GNQZ518kCl==N9olEh0ZMtpOivVfBLK(u"࠷ਲ"): cVxeDAtMOL0JkPpX75R = xfhCjTXRaFBGOE[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠰ਲ਼")]
		else: cVxeDAtMOL0JkPpX75R = xfhCjTXRaFBGOE[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠲਴")]
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==Xl3drKyI9HkDiPEf8RTjwu(u"࠴ਵ"): cVxeDAtMOL0JkPpX75R = TWexH5PhS1(u"ࠩࠪṿ")
	else: MsStKG321Y5CeX0JpIOQAZ9lHP = VH9MDo5z1kxNF07uRJI(u"ࠪࠫẀ")
	if MsStKG321Y5CeX0JpIOQAZ9lHP:
		YTPut68WBVUNCvsEzg.setSetting(f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧẁ"),MsStKG321Y5CeX0JpIOQAZ9lHP)
		YTPut68WBVUNCvsEzg.setSetting(VOq8Ekue4F(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬẂ"),cVxeDAtMOL0JkPpX75R)
		QQn7jCsa4Yw8AyVRpk5rUhXMzvt = F67qZAgMjPukRfJ[MsStKG321Y5CeX0JpIOQAZ9lHP]+cVxeDAtMOL0JkPpX75R
		KK47FGdX1TDfkb3AjHOQqghE(oAXJCYqPgyGDtT(u"࠭ࠧẃ"),ttOu147wErcBvPaSMUY(u"ࠧࠨẄ"),l5mQdjWyczr7UJVnTp(u"ࠨࠩẅ"),QQn7jCsa4Yw8AyVRpk5rUhXMzvt)
	return
def s6QR7FMlT8KHBSmfNa2Jq():
	ZaEXhgyGSoJRn = YTPut68WBVUNCvsEzg.getSetting(EmK3ObA0cwv9Wy(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧẆ"))
	F67qZAgMjPukRfJ = {}
	F67qZAgMjPukRfJ[vatyjK4hHAoZJ7rOq2lis(u"ࠪࡅ࡚࡚ࡏࠨẇ")] = ZhqJoOtcmTVID65HwnLj(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬẈ")
	F67qZAgMjPukRfJ[h5huy6MiXPNfQJF8(u"ࠬࡇࡓࡌࠩẉ")] = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧẊ")
	F67qZAgMjPukRfJ[N9olEh0ZMtpOivVfBLK(u"ࠧࡔࡖࡒࡔࠬẋ")] = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪẌ")
	ffBvxFX80HUywYDI5jO2 = F67qZAgMjPukRfJ[ZaEXhgyGSoJRn]
	IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(oAXJCYqPgyGDtT(u"ࠩࠪẍ"),HVibA2ES8lY(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨẎ"),HVibA2ES8lY(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪẏ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬห๊ใษไࠤ่อๅๅࠩẐ"),ffBvxFX80HUywYDI5jO2,EmK3ObA0cwv9Wy(u"࠭วๅสิ์ู่๊้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์฼้้่ࠦิ์ฺࠤอ๐ๆࠡฮ๊หื้้ࠠษ็ษ๋ะั็์อࠤ࠳ࠦ็้ࠢํืฯ๊ๅูࠡ็ฬฬะใ๊ࠡํๆํ๋ࠠษีะฬ์อࠠษั็ห๋ࠥๆไࠢฮ้ࠥ๐ศฺอ๊ห๊ࠥใࠡ࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣว๊ࠦล๋ไสๅࠥอไษำ๋็ุ๐ࠠภࠩẑ"))
	if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==sDiKwnHcSlYFgWCy1Ak(u"࠳ਸ਼"): MsStKG321Y5CeX0JpIOQAZ9lHP = HH4JMrUDp3lq6hQ(u"ࠧࡂࡕࡎࠫẒ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==l5mQdjWyczr7UJVnTp(u"࠵਷"): MsStKG321Y5CeX0JpIOQAZ9lHP = ttOu147wErcBvPaSMUY(u"ࠨࡃࡘࡘࡔ࠭ẓ")
	elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷ਸ"): MsStKG321Y5CeX0JpIOQAZ9lHP = HH4JMrUDp3lq6hQ(u"ࠩࡖࡘࡔࡖࠧẔ")
	else: MsStKG321Y5CeX0JpIOQAZ9lHP = ZhqJoOtcmTVID65HwnLj(u"ࠪࠫẕ")
	if MsStKG321Y5CeX0JpIOQAZ9lHP:
		YTPut68WBVUNCvsEzg.setSetting(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩẖ"),MsStKG321Y5CeX0JpIOQAZ9lHP)
		QQn7jCsa4Yw8AyVRpk5rUhXMzvt = F67qZAgMjPukRfJ[MsStKG321Y5CeX0JpIOQAZ9lHP]
		KK47FGdX1TDfkb3AjHOQqghE(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬ࠭ẗ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠧẘ"),FIHNSc5iuoZanQ2Ytl(u"ࠧࠨẙ"),QQn7jCsa4Yw8AyVRpk5rUhXMzvt)
	return
def m6EuNTYOlJ2ca0feSd5I4GrxZptC():
	QVmqy4xbelgnkFzYp = YTPut68WBVUNCvsEzg.getSetting(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨẚ"))
	if QVmqy4xbelgnkFzYp==ttOu147wErcBvPaSMUY(u"ࠩࡖࡘࡔࡖࠧẛ"): header = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣฯ๎โโࠩẜ")
	else: header = vatyjK4hHAoZJ7rOq2lis(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊็ูๅࠩẝ")
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬ࠭ẞ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ล๋ไสๅࠬẟ"),ttOu147wErcBvPaSMUY(u"ࠧหใ฼๎้࠭Ạ"),header,EEvLoMzFqrlKce(u"ࠨไ๋หห๋ࠠศๆหี๋อๅอࠢํฮ๊ࠦสฮัํฯ์อࠠฤ๊อ์๊อส๋ๅํหࠥฮูะࠢ࠴࠺ูࠥวฺห้๋ࠣࠦร้ๆࠣวุะฮะษ่ࠤ࠳࠴้ࠠวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋๋ࠠฦา๎ࠥหไ๊ࠢอัิ๐ห่ษࠣๅ๏ࠦใๅ่ࠢีฮ๊ࠦห็ࠣหุะฮะษ่ࠤฬ๊โ้ษษ้ࠥ࠴࠮๊๊ࠡิฬ๊ࠦิสหࠤอ฽ฦࠡใํࠤๆะอࠡไ๋หห๋ࠠศๆหี๋อๅอ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠหใ฼๎้ࠦรๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡมࠤࠥࠬạ"))
	if VjwKs4GNQZ518kCl==-TWexH5PhS1(u"࠷ਹ"): return
	elif VjwKs4GNQZ518kCl:
		YTPut68WBVUNCvsEzg.setSetting(sDiKwnHcSlYFgWCy1Ak(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩẢ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࡅ࡚࡚ࡏࠨả"))
		KK47FGdX1TDfkb3AjHOQqghE(l5mQdjWyczr7UJVnTp(u"ࠫࠬẤ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࠭ấ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩẦ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧห็ࠣฮๆ฿๊ๅࠢอาื๐ๆࠡษ็ๆํอฦๆࠩầ"))
	else:
		YTPut68WBVUNCvsEzg.setSetting(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨẨ"),N9olEh0ZMtpOivVfBLK(u"ࠩࡖࡘࡔࡖࠧẩ"))
		KK47FGdX1TDfkb3AjHOQqghE(WmaPChRdQk3YcXwI6zS(u"ࠪࠫẪ"),sDiKwnHcSlYFgWCy1Ak(u"ࠫࠬẫ"),ZhqJoOtcmTVID65HwnLj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨẬ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭สๆࠢศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨậ"))
	return
def tVurhaxeE2(yv8XxUjorzB2CRA4Jife73VMklHp):
	if yv8XxUjorzB2CRA4Jife73VMklHp!=h5huy6MiXPNfQJF8(u"ࠧࠨẮ"):
		yv8XxUjorzB2CRA4Jife73VMklHp = epacjZzdVL5IMrHASuvgqBRkxNnXQJ(yv8XxUjorzB2CRA4Jife73VMklHp)
		yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.decode(HH4JMrUDp3lq6hQ(u"ࠨࡷࡷࡪ࠽࠭ắ")).encode(VOq8Ekue4F(u"ࠩࡸࡸ࡫࠾ࠧẰ"))
		PAtf8I5Vz6xNSOk4M3iqUnLW0EF = l5mQdjWyczr7UJVnTp(u"࠱࠱࠳࠳࠷਺")
		T4mKNWUFaIgoGBJXESy6QMq = Ko1p5u9jwG6rF.Window(PAtf8I5Vz6xNSOk4M3iqUnLW0EF)
		T4mKNWUFaIgoGBJXESy6QMq.getControl(HVibA2ES8lY(u"࠴࠳࠴਻")).setLabel(yv8XxUjorzB2CRA4Jife73VMklHp)
	return
arWfzJnTNiVAXYyqkso = [
			 N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠥࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࠧࠨࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡦࡹࡷࡸࡥ࡯ࡶ࡯ࡽࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠣằ")
			,ttOu147wErcBvPaSMUY(u"ࠫࡈ࡮ࡥࡤ࡭࡬ࡲ࡬ࠦࡦࡰࡴࠣࡑࡦࡲࡩࡤ࡫ࡲࡹࡸࠦࡳࡤࡴ࡬ࡴࡹࡹࠧẲ")
			,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺࠧẳ")
			,FIHNSc5iuoZanQ2Ytl(u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡗ࡫ࡧࡩࡴࠦࡉ࡯ࡨࡲࠤࡐ࡫ࡹࠨẴ")
			,VH9MDo5z1kxNF07uRJI(u"ࠧࡵࡪ࡬ࡷࠥ࡮ࡡࡴࡪࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡤࡵࡳࡰ࡫࡮ࠨẵ")
			,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡷࡶࡩࡸࠦࡰ࡭ࡣ࡬ࡲࠥࡎࡔࡕࡒࠣࡪࡴࡸࠠࡢࡦࡧ࠱ࡴࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࡵࠪẶ")
			,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡺࡹࡡࡨࡧ࠱࡬ࡹࡳ࡬ࠨặ")+TWexH5PhS1(u"ࠪࠧࠬẸ")+Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪẹ")
			,HVibA2ES8lY(u"ࠬࡏ࡮ࡴࡧࡦࡹࡷ࡫ࡒࡦࡳࡸࡩࡸࡺࡗࡢࡴࡱ࡭ࡳ࡭ࠬࠨẺ")
			,HH4JMrUDp3lq6hQ(u"࠭ࡅࡳࡴࡲࡶࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࠯ࡀ࡯ࡲࡨࡪ࡫࠽࠱ࠨࡷࡩࡽࡺࡴ࠾ࠩẻ")
			,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡸࡣࡵࡲ࡮ࡴࡧࡴ࠰ࡺࡥࡷࡴࠨࠨẼ")
			,ZEiR0StquOzca9lvPAndYIX(u"ࠨࡠࡡࡢࡣࡤࠧẽ")
			,HH4JMrUDp3lq6hQ(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧẾ")
			]
def aaLgjkYip3qu4ryFvOxc(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g):
	if mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨế") in GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g and FIHNSc5iuoZanQ2Ytl(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩỀ") in GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g: return EmK3ObA0cwv9Wy(u"ࡔࡳࡷࡨણ")
	for yv8XxUjorzB2CRA4Jife73VMklHp in arWfzJnTNiVAXYyqkso:
		if yv8XxUjorzB2CRA4Jife73VMklHp in GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g: return l5mQdjWyczr7UJVnTp(u"ࡕࡴࡸࡩત")
	return VH9MDo5z1kxNF07uRJI(u"ࡈࡤࡰࡸ࡫થ")
def ccvOmI7Fg50GQLbhpH(data):
	data = data.replace(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡢࡲ࡝ࡰࠪề")+mNkfJnpOrad7hT6PYyciwsSDQ(u"࠷࠴਼")*vatyjK4hHAoZJ7rOq2lis(u"࠭ࠠࠨỂ")+VH9MDo5z1kxNF07uRJI(u"ࠧ࡝ࡴ࡟ࡲࠬể"),oAXJCYqPgyGDtT(u"ࠨ࡞ࡵࡠࡳ࠭Ễ"))
	data = data.replace(VH9MDo5z1kxNF07uRJI(u"ࠩ࡟ࡲࠬễ")+ZEiR0StquOzca9lvPAndYIX(u"࠸࠵਽")*sDiKwnHcSlYFgWCy1Ak(u"ࠪࠤࠬỆ")+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡡࡸ࡜࡯ࠩệ"),WmaPChRdQk3YcXwI6zS(u"ࠬࡢࡲ࡝ࡰࠪỈ"))
	data = data.replace(N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࡜࡯ࠩỉ")+h5huy6MiXPNfQJF8(u"࠹࠶ਾ")*WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࠡࠩỊ")+FIHNSc5iuoZanQ2Ytl(u"ࠨ࡞ࡱࠫị"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࡟ࡲࠬỌ"))
	data = data.replace(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡠࡳ࠭ọ")+VOq8Ekue4F(u"࠻࠱ੀ")*S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࠥ࠭Ỏ"),VH9MDo5z1kxNF07uRJI(u"ࠬࡢ࡮ࠨỏ")+Xl3drKyI9HkDiPEf8RTjwu(u"࠸࠷ਿ")*EmK3ObA0cwv9Wy(u"࠭ࠠࠨỐ"))
	data = data.replace(EmK3ObA0cwv9Wy(u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭ố"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨ࠼ࠣࠫỒ"))
	vf78LSlJQOnCsatrIH2P1iW = sbgu4D2RFMYKm(u"ࠩࠪồ")
	for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in data.splitlines():
		odgLC1UG5xIm6ZHnzqvNMRwpEh42et = T072lCzjYiuaeFtmJGV.findall(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩỔ"),GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,T072lCzjYiuaeFtmJGV.DOTALL)
		if odgLC1UG5xIm6ZHnzqvNMRwpEh42et: GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(odgLC1UG5xIm6ZHnzqvNMRwpEh42et[vatyjK4hHAoZJ7rOq2lis(u"࠰ੁ")],vatyjK4hHAoZJ7rOq2lis(u"ࠫࠬổ"))
		vf78LSlJQOnCsatrIH2P1iW += PiFkQ5pCJy7fbX(u"ࠬࡢ࡮ࠨỖ")+GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g
	return vf78LSlJQOnCsatrIH2P1iW
def fKNrbvcQ5EMqjlaBIzukX8nd(v832Nc5WqksZ):
	if QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡏࡍࡆࠪỗ") in v832Nc5WqksZ:
		XAfTWJrOIj1PYK6NM = UOqR1bCTXD4VisWrgeL
		header = HVibA2ES8lY(u"ࠧใำสลฮࠦวๅีฯ่ࠥอไใัํ้ࠥลࠧỘ")
	else:
		XAfTWJrOIj1PYK6NM = aHPguvxqCjOmAwsF
		header = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅฯส่๏ࠦฟࠨộ")
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(h5huy6MiXPNfQJF8(u"ࠩࠪỚ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠫớ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬỜ"),header,HVibA2ES8lY(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨờ"))
	if VjwKs4GNQZ518kCl!=TWexH5PhS1(u"࠲ੂ"): return
	RgGHl1ZfUxvVudLws85PQzbITA9,oqiYRLNObxnI2sZW3Bcgh = [],WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠲੃")
	size,count = qtKQXi2C9V7JrEyWD61Lns(XAfTWJrOIj1PYK6NM)
	file = open(XAfTWJrOIj1PYK6NM,FIHNSc5iuoZanQ2Ytl(u"࠭ࡲࡣࠩỞ"))
	if size>uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠵࠵࠶࠲࠱࠲੅"): file.seek(-l5mQdjWyczr7UJVnTp(u"࠴࠴࠵࠷࠰࠱੄"),isWjwHOERYXhAp0ZuNdKUgkCM7.SEEK_END)
	data = file.read()
	file.close()
	if mmIKCGujwM: data = data.decode(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡶࡶࡩ࠼ࠬở"))
	data = ccvOmI7Fg50GQLbhpH(data)
	SXOJtRiHqaUFCp2e = data.split(vatyjK4hHAoZJ7rOq2lis(u"ࠨ࡞ࡱࠫỠ"))
	for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in reversed(SXOJtRiHqaUFCp2e):
		QTWCOwaHvLgPIe8s2U = aaLgjkYip3qu4ryFvOxc(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
		if QTWCOwaHvLgPIe8s2U: continue
		GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡢࠫỡ"),HVibA2ES8lY(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩỢ"))
		GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫợ"),TWexH5PhS1(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈ࠳࠴࠵࠶࡝ࡆࡔࡕࡓࡗࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨỤ"))
		kgYqlmWAn42M0 = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠧụ")
		k4kWPoKSAc7FL0bZH1N = T072lCzjYiuaeFtmJGV.findall(N9olEh0ZMtpOivVfBLK(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧỦ"),GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,T072lCzjYiuaeFtmJGV.DOTALL)
		if k4kWPoKSAc7FL0bZH1N:
			GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(k4kWPoKSAc7FL0bZH1N[ttOu147wErcBvPaSMUY(u"࠶ੇ")][ttOu147wErcBvPaSMUY(u"࠶ੇ")],k4kWPoKSAc7FL0bZH1N[ttOu147wErcBvPaSMUY(u"࠶ੇ")][uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠶੆")]).replace(k4kWPoKSAc7FL0bZH1N[ttOu147wErcBvPaSMUY(u"࠶ੇ")][FIHNSc5iuoZanQ2Ytl(u"࠲ੈ")],N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠩủ"))
			kgYqlmWAn42M0 = k4kWPoKSAc7FL0bZH1N[sbgu4D2RFMYKm(u"࠲੊")][weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠲੉")]
		else:
			k4kWPoKSAc7FL0bZH1N = T072lCzjYiuaeFtmJGV.findall(EmK3ObA0cwv9Wy(u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩỨ"),GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,T072lCzjYiuaeFtmJGV.DOTALL)
			if k4kWPoKSAc7FL0bZH1N:
				GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(k4kWPoKSAc7FL0bZH1N[VH9MDo5z1kxNF07uRJI(u"࠴ੌ")][N0Kvne8UYar9fhRxboWsXJCVzid(u"࠴ੋ")],N9olEh0ZMtpOivVfBLK(u"ࠪࠫứ"))
				kgYqlmWAn42M0 = k4kWPoKSAc7FL0bZH1N[VOq8Ekue4F(u"࠵੍")][VOq8Ekue4F(u"࠵੍")]
		if kgYqlmWAn42M0: GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(kgYqlmWAn42M0,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧỪ")+kgYqlmWAn42M0+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧừ"))
		RgGHl1ZfUxvVudLws85PQzbITA9.append(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
		if len(str(RgGHl1ZfUxvVudLws85PQzbITA9))>ZhqJoOtcmTVID65HwnLj(u"࠻࠰࠲࠲࠳੎"): break
	RgGHl1ZfUxvVudLws85PQzbITA9 = reversed(RgGHl1ZfUxvVudLws85PQzbITA9)
	Rsya4CbJIe1UkEXZjuP5Bzx = oAXJCYqPgyGDtT(u"࠭࡜࡯ࠩỬ").join(RgGHl1ZfUxvVudLws85PQzbITA9)
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(EmK3ObA0cwv9Wy(u"ࠧ࡭ࡧࡩࡸࠬử"),EEvLoMzFqrlKce(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬỮ"),Rsya4CbJIe1UkEXZjuP5Bzx,EmK3ObA0cwv9Wy(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬữ"))
	return
def ECa7coilkxUZPMLFXNpKYe94():
	W8omDV5zTAyKiZN9qSdl7Rs = open(zJNSdZn57DjIqhYo2TXH,vatyjK4hHAoZJ7rOq2lis(u"ࠪࡶࡧ࠭Ự")).read()
	if mmIKCGujwM: W8omDV5zTAyKiZN9qSdl7Rs = W8omDV5zTAyKiZN9qSdl7Rs.decode(EmK3ObA0cwv9Wy(u"ࠫࡺࡺࡦ࠹ࠩự"))
	W8omDV5zTAyKiZN9qSdl7Rs = W8omDV5zTAyKiZN9qSdl7Rs.replace(sbgu4D2RFMYKm(u"ࠬࡢࡴࠨỲ"),ZEiR0StquOzca9lvPAndYIX(u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠨỳ"))
	VXp2ouLAg5Mz8jct1hf6m = T072lCzjYiuaeFtmJGV.findall(h5huy6MiXPNfQJF8(u"ࠧࠩࡸ࡟ࡨ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨỴ"),W8omDV5zTAyKiZN9qSdl7Rs,T072lCzjYiuaeFtmJGV.DOTALL)
	for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in VXp2ouLAg5Mz8jct1hf6m:
		W8omDV5zTAyKiZN9qSdl7Rs = W8omDV5zTAyKiZN9qSdl7Rs.replace(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫỵ")+GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g+FIHNSc5iuoZanQ2Ytl(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫỶ"))
	JdTOfC6BRIKoGu(EmK3ObA0cwv9Wy(u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫỷ"),W8omDV5zTAyKiZN9qSdl7Rs)
	return
def GRb39sL4Ym5g6PQcSXZz2A18DKO():
	n9GNlZCisxWpEb1rqX5RAUjScJuT = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭Ỹ")
	SR7NUj9vYW2B5lLai0DqF = mNkfJnpOrad7hT6PYyciwsSDQ(u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩỹ")
	O3PvLtuErnZygxlBzUI = N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩỺ")
	F67qZAgMjPukRfJ = n9GNlZCisxWpEb1rqX5RAUjScJuT+f5uqIoSJzWBOFyrY78RXmVb(u"ࠧ࠻ࠢࠪỻ")+SR7NUj9vYW2B5lLai0DqF+ZhqJoOtcmTVID65HwnLj(u"ࠨࠢ࠱ࠤࠬỼ")+O3PvLtuErnZygxlBzUI
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(HH4JMrUDp3lq6hQ(u"ࠩࡦࡩࡳࡺࡥࡳࠩỽ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ỿ"),F67qZAgMjPukRfJ,sDiKwnHcSlYFgWCy1Ak(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧỿ"))
	return
def YYKFsUfhQctD1bjpEzZagd(type,F67qZAgMjPukRfJ,showDialogs=h5huy6MiXPNfQJF8(u"ࡗࡶࡺ࡫દ"),url=vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠭ἀ"),nnN6lPjWb0xVQqDKwo3=l5mQdjWyczr7UJVnTp(u"࠭ࠧἁ"),yv8XxUjorzB2CRA4Jife73VMklHp=TWexH5PhS1(u"ࠧࠨἂ"),JGYq2yBf36xojVb8Rd=HVibA2ES8lY(u"ࠨࠩἃ")):
	bKJUhjkGtnXma81u49p = oAXJCYqPgyGDtT(u"ࡘࡷࡻࡥધ")
	if not wTpW3nbIgPckqCl9ohi(ZhqJoOtcmTVID65HwnLj(u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪἄ")):
		if showDialogs:
			ToI97DBYlbJpanPAvHQi2k = (HVibA2ES8lY(u"ࠪหู้ืา࠼ࠪἅ") in F67qZAgMjPukRfJ and l5mQdjWyczr7UJVnTp(u"ࠫฬ๊ๅไษ้࠾ࠬἆ") in F67qZAgMjPukRfJ and ZhqJoOtcmTVID65HwnLj(u"ࠬอไๆๆไ࠾ࠬἇ") in F67qZAgMjPukRfJ and PiFkQ5pCJy7fbX(u"࠭วๅะฺวࠬἈ") in F67qZAgMjPukRfJ and oAXJCYqPgyGDtT(u"ࠧศๆู่ิื࠺ࠨἉ") in F67qZAgMjPukRfJ)
			if not ToI97DBYlbJpanPAvHQi2k: bKJUhjkGtnXma81u49p = KGEAmiZ9Jq0sTXR(h5huy6MiXPNfQJF8(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἊ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠪἋ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠫἌ"),ZhqJoOtcmTVID65HwnLj(u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨἍ"),F67qZAgMjPukRfJ.replace(ttOu147wErcBvPaSMUY(u"ࠬࡢ࡜࡯ࠩἎ"),FIHNSc5iuoZanQ2Ytl(u"࠭࡜࡯ࠩἏ")))
	elif showDialogs:
		F67qZAgMjPukRfJ = Xl3drKyI9HkDiPEf8RTjwu(u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧἐ")
		uuvo7EIB2WHbAdnf = KGEAmiZ9Jq0sTXR(sDiKwnHcSlYFgWCy1Ak(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨἑ"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࠪἒ"),ZEiR0StquOzca9lvPAndYIX(u"ࠪࠫἓ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫἔ")+WmaPChRdQk3YcXwI6zS(u"ࠬࠦࠠ࠲࠱࠸ࠫἕ"),HH4JMrUDp3lq6hQ(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ἖"))
		ZwTMkni1v35cPDx7OWKogazFJ = KGEAmiZ9Jq0sTXR(f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡤࡧࡱࡸࡪࡸࠧ἗"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࠩἘ"),sbgu4D2RFMYKm(u"ࠩࠪἙ"),HVibA2ES8lY(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪἚ")+WmaPChRdQk3YcXwI6zS(u"ࠫࠥࠦ࠲࠰࠷ࠪἛ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪἜ"))
		WPpIuGXkEwqJ4o6cxeHZn0VvgC1Yr = KGEAmiZ9Jq0sTXR(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭Ἕ"),vatyjK4hHAoZJ7rOq2lis(u"ࠧࠨ἞"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࠩ἟"),HVibA2ES8lY(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩἠ")+HVibA2ES8lY(u"ࠪࠤࠥ࠹࠯࠶ࠩἡ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩἢ"))
		ZD5Q6mONYx3M4aXnyTJdhWtke2zj = KGEAmiZ9Jq0sTXR(sbgu4D2RFMYKm(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬἣ"),sbgu4D2RFMYKm(u"࠭ࠧἤ"),vatyjK4hHAoZJ7rOq2lis(u"ࠧࠨἥ"),TWexH5PhS1(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨἦ")+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࠣࠤ࠹࠵࠵ࠨἧ"),PiFkQ5pCJy7fbX(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨἨ"))
		bKJUhjkGtnXma81u49p = KGEAmiZ9Jq0sTXR(sbgu4D2RFMYKm(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫἩ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࠭Ἢ"),TWexH5PhS1(u"࠭ࠧἫ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧἬ")+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠢࠣ࠹࠴࠻ࠧἭ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧἮ"))
	mXzxhH68tSFg = au8Umt9dq1KLSYb(HH4JMrUDp3lq6hQ(u"࠳࠳੏"),EEvLoMzFqrlKce(u"ࡋࡧ࡬ࡴࡧન"))
	yzN2cLsUYgCH0xenm76KR = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡅ࡛ࡀࠠࠨἯ")+mXzxhH68tSFg+oAXJCYqPgyGDtT(u"ࠫ࠲࠭ἰ")+type
	QQTqHdRmAn3YKtB = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡔࡳࡷࡨપ") if PiFkQ5pCJy7fbX(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨἱ") in yv8XxUjorzB2CRA4Jife73VMklHp else N9olEh0ZMtpOivVfBLK(u"ࡌࡡ࡭ࡵࡨ઩")
	if not bKJUhjkGtnXma81u49p:
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࠧἲ"),oAXJCYqPgyGDtT(u"ࠧࠨἳ"),HVibA2ES8lY(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫἴ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠥฮๆศรࠣ฽้๏ุࠠๆห็ࠬἵ"))
		return HVibA2ES8lY(u"ࡇࡣ࡯ࡷࡪફ")
	zzim4GZeg3kVosAfS6FPM = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩἶ"))
	F67qZAgMjPukRfJ += l5mQdjWyczr7UJVnTp(u"ࠫࠥࡢ࡜࡯࡞࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡢ࡜࡯ࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪἷ")+pQmoyUJBNaf72A+EEvLoMzFqrlKce(u"ࠬࠦ࠺࡝࡞ࡱࠫἸ")
	F67qZAgMjPukRfJ += HH4JMrUDp3lq6hQ(u"࠭ࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧἹ")+mXzxhH68tSFg+TWexH5PhS1(u"ࠧࠡ࠼࡟ࡠࡳࡑ࡯ࡥ࡫࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭Ἲ")+wK1R0Up3rH+N9olEh0ZMtpOivVfBLK(u"ࠨࠢ࠽ࡠࡡࡴࠧἻ")
	F67qZAgMjPukRfJ += sDiKwnHcSlYFgWCy1Ak(u"ࠩࡎࡳࡩ࡯ࠠࡏࡣࡰࡩ࠿ࠦࠧἼ")+zzim4GZeg3kVosAfS6FPM
	VTknBvs0QNLUOGr7h9wZ = EAeKCYbwXqJRODh3vyxB()
	VTknBvs0QNLUOGr7h9wZ = K3PukgCEDY(VTknBvs0QNLUOGr7h9wZ)
	if VTknBvs0QNLUOGr7h9wZ: F67qZAgMjPukRfJ += l5mQdjWyczr7UJVnTp(u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬἽ")+VTknBvs0QNLUOGr7h9wZ
	if url: F67qZAgMjPukRfJ += HVibA2ES8lY(u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨἾ")+url
	if nnN6lPjWb0xVQqDKwo3: F67qZAgMjPukRfJ += cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬἿ")+nnN6lPjWb0xVQqDKwo3
	F67qZAgMjPukRfJ += WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࠠ࠻࡞࡟ࡲࠬὀ")
	if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(WmaPChRdQk3YcXwI6zS(u"ࠧอษิ๎ࠥอไฦำึห้࠭ὁ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪὂ"))
	if JGYq2yBf36xojVb8Rd:
		Rsya4CbJIe1UkEXZjuP5Bzx = JGYq2yBf36xojVb8Rd
		if mmIKCGujwM: Rsya4CbJIe1UkEXZjuP5Bzx = Rsya4CbJIe1UkEXZjuP5Bzx.encode(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡸࡸ࡫࠾ࠧὃ"))
		Rsya4CbJIe1UkEXZjuP5Bzx = eJ4h7nOpguFMH6z1IUEV2i.b64encode(Rsya4CbJIe1UkEXZjuP5Bzx)
	elif QQTqHdRmAn3YKtB:
		if ZEiR0StquOzca9lvPAndYIX(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪὄ") in yv8XxUjorzB2CRA4Jife73VMklHp: lT6toWRq2YrBGnEjA = UOqR1bCTXD4VisWrgeL
		else: lT6toWRq2YrBGnEjA = aHPguvxqCjOmAwsF
		if not isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(lT6toWRq2YrBGnEjA):
			KK47FGdX1TDfkb3AjHOQqghE(VH9MDo5z1kxNF07uRJI(u"ࠫࠬὅ"),PiFkQ5pCJy7fbX(u"ࠬ࠭὆"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ὇"),HVibA2ES8lY(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬὈ"))
			return N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡈࡤࡰࡸ࡫બ")
		RgGHl1ZfUxvVudLws85PQzbITA9,oqiYRLNObxnI2sZW3Bcgh = [],WmaPChRdQk3YcXwI6zS(u"࠱੐")
		size,count = qtKQXi2C9V7JrEyWD61Lns(lT6toWRq2YrBGnEjA)
		file = open(lT6toWRq2YrBGnEjA,vatyjK4hHAoZJ7rOq2lis(u"ࠨࡴࡥࠫὉ"))
		if size>sbgu4D2RFMYKm(u"࠵࠹࠵࠸࠰࠱੒"): file.seek(-HVibA2ES8lY(u"࠴࠸࠴࠶࠶࠰ੑ"),isWjwHOERYXhAp0ZuNdKUgkCM7.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(ZEiR0StquOzca9lvPAndYIX(u"ࠩࡸࡸ࡫࠾ࠧὊ"))
		data = ccvOmI7Fg50GQLbhpH(data)
		SXOJtRiHqaUFCp2e = data.splitlines()
		for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in reversed(SXOJtRiHqaUFCp2e):
			QTWCOwaHvLgPIe8s2U = aaLgjkYip3qu4ryFvOxc(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
			if QTWCOwaHvLgPIe8s2U: continue
			k4kWPoKSAc7FL0bZH1N = T072lCzjYiuaeFtmJGV.findall(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪὋ"),GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,T072lCzjYiuaeFtmJGV.DOTALL)
			if k4kWPoKSAc7FL0bZH1N:
				GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(k4kWPoKSAc7FL0bZH1N[WmaPChRdQk3YcXwI6zS(u"࠵੔")][WmaPChRdQk3YcXwI6zS(u"࠵੔")],k4kWPoKSAc7FL0bZH1N[WmaPChRdQk3YcXwI6zS(u"࠵੔")][weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵੓")]).replace(k4kWPoKSAc7FL0bZH1N[WmaPChRdQk3YcXwI6zS(u"࠵੔")][h5huy6MiXPNfQJF8(u"࠸੕")],WmaPChRdQk3YcXwI6zS(u"ࠫࠬὌ"))
			else:
				k4kWPoKSAc7FL0bZH1N = T072lCzjYiuaeFtmJGV.findall(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬὍ"),GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g,T072lCzjYiuaeFtmJGV.DOTALL)
				if k4kWPoKSAc7FL0bZH1N: GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.replace(k4kWPoKSAc7FL0bZH1N[EEvLoMzFqrlKce(u"࠱੗")][EmK3ObA0cwv9Wy(u"࠱੖")],Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࠧ὎"))
			RgGHl1ZfUxvVudLws85PQzbITA9.append(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
			if len(str(RgGHl1ZfUxvVudLws85PQzbITA9))>BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠳࠵࠵࠵࠶࠰੘"): break
		RgGHl1ZfUxvVudLws85PQzbITA9 = reversed(RgGHl1ZfUxvVudLws85PQzbITA9)
		Rsya4CbJIe1UkEXZjuP5Bzx = FIHNSc5iuoZanQ2Ytl(u"ࠧ࡝ࡴ࡟ࡲࠬ὏").join(RgGHl1ZfUxvVudLws85PQzbITA9)
		Rsya4CbJIe1UkEXZjuP5Bzx = Rsya4CbJIe1UkEXZjuP5Bzx.encode(ZEiR0StquOzca9lvPAndYIX(u"ࠨࡷࡷࡪ࠽࠭ὐ"))
		Rsya4CbJIe1UkEXZjuP5Bzx = eJ4h7nOpguFMH6z1IUEV2i.b64encode(Rsya4CbJIe1UkEXZjuP5Bzx)
	else: Rsya4CbJIe1UkEXZjuP5Bzx = ttOu147wErcBvPaSMUY(u"ࠩࠪὑ")
	url = tOnYIHVk4xydqwoLEBKiDN0hX[h5huy6MiXPNfQJF8(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪὒ")][weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵ਖ਼")]
	y7PU6am9Z3I = {cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬὓ"):yzN2cLsUYgCH0xenm76KR,sDiKwnHcSlYFgWCy1Ak(u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠧὔ"):F67qZAgMjPukRfJ,HH4JMrUDp3lq6hQ(u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧὕ"):Rsya4CbJIe1UkEXZjuP5Bzx}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡑࡑࡖࡘࠬὖ"),url,y7PU6am9Z3I,ttOu147wErcBvPaSMUY(u"ࠨࠩὗ"),oAXJCYqPgyGDtT(u"ࠩࠪ὘"),sbgu4D2RFMYKm(u"ࠪࠫὙ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ὚"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if HH4JMrUDp3lq6hQ(u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧὛ") in qQXuaKpVrGLF3e5oidJ8YwDT0: UkYj1KP0ou4q9rVfEgn2JQHI56BG = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡗࡶࡺ࡫ભ")
	else: UkYj1KP0ou4q9rVfEgn2JQHI56BG = N9olEh0ZMtpOivVfBLK(u"ࡊࡦࡲࡳࡦમ")
	if showDialogs:
		if UkYj1KP0ou4q9rVfEgn2JQHI56BG:
			fYPz7RldWQVHBktZAexwvCL8Np3D(FIHNSc5iuoZanQ2Ytl(u"࠭สๆࠢส่สืำศๆࠪ὜"),oAXJCYqPgyGDtT(u"ࠧษ่ฯหา࠭Ὕ"))
			KK47FGdX1TDfkb3AjHOQqghE(h5huy6MiXPNfQJF8(u"ࠨࠩ὞"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࠪὟ"),l5mQdjWyczr7UJVnTp(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩὠ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭ὡ"))
		else:
			fYPz7RldWQVHBktZAexwvCL8Np3D(sbgu4D2RFMYKm(u"๊ࠬไฤีไࠫὢ"),vatyjK4hHAoZJ7rOq2lis(u"࠭แีๆࠣๅ๏ࠦวๅวิืฬ๊ࠧὣ"))
			KK47FGdX1TDfkb3AjHOQqghE(oAXJCYqPgyGDtT(u"ࠧࠨὤ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨࠩὥ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬὦ"),oAXJCYqPgyGDtT(u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨὧ"))
	return UkYj1KP0ou4q9rVfEgn2JQHI56BG
def JEb7sZe08huDkX2():
	n9GNlZCisxWpEb1rqX5RAUjScJuT = ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࡸࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪὨ")
	SR7NUj9vYW2B5lLai0DqF = l5mQdjWyczr7UJVnTp(u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧὩ")
	KK47FGdX1TDfkb3AjHOQqghE(f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࠧὪ"),EEvLoMzFqrlKce(u"ࠧࠨὫ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩὬ"),n9GNlZCisxWpEb1rqX5RAUjScJuT+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩ࡟ࡲࡡࡴࠧὭ")+SR7NUj9vYW2B5lLai0DqF)
	n9GNlZCisxWpEb1rqX5RAUjScJuT = HH4JMrUDp3lq6hQ(u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩὮ")
	SR7NUj9vYW2B5lLai0DqF = PiFkQ5pCJy7fbX(u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦลๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫὯ")
	KK47FGdX1TDfkb3AjHOQqghE(N9olEh0ZMtpOivVfBLK(u"ࠬ࠭ὰ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࠧά"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭ὲ"),n9GNlZCisxWpEb1rqX5RAUjScJuT+ZEiR0StquOzca9lvPAndYIX(u"ࠨ࡞ࡱࡠࡳ࠭έ")+SR7NUj9vYW2B5lLai0DqF)
	n9GNlZCisxWpEb1rqX5RAUjScJuT = WmaPChRdQk3YcXwI6zS(u"ࠩ࠶࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡥࡱࡱࡠࠬࡺࠠࡩࡣࡹࡩࠥࡇࡲࡢࡤ࡬ࡧࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡵࡪࡨࡲࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡤࡲࡩࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡶࡪ࡭ࡩࡰࡰࡤࡰࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧὴ")
	SR7NUj9vYW2B5lLai0DqF = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪ࠷࠳ࠦࠠࠡวำห๊ࠥๅࠡ์ๆ๊๊ࠥฯ๋ๅ่ࠣํำษࠡ็ไหฯ๐อࠡ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡว฼ำฬีวหࠢส่๊์ืใหࠣห้าฺาษไ๎ฮ࠭ή")
	KK47FGdX1TDfkb3AjHOQqghE(ZEiR0StquOzca9lvPAndYIX(u"ࠫࠬὶ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࠭ί"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬὸ"),n9GNlZCisxWpEb1rqX5RAUjScJuT+EmK3ObA0cwv9Wy(u"ࠧ࡝ࡰ࡟ࡲࠬό")+SR7NUj9vYW2B5lLai0DqF)
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(HH4JMrUDp3lq6hQ(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨὺ"),PiFkQ5pCJy7fbX(u"ࠩࠪύ"),EEvLoMzFqrlKce(u"ࠪࠫὼ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡋࡵ࡮ࡵࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠫώ"),vatyjK4hHAoZJ7rOq2lis(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡲࡴࡽࠠࡀࠩ὾")+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭࡜࡯࡞ࡱࠫ὿")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"่ࠧๆࠣฮึ๐ฯࠡษ็ิ์อศࠡว็ํ๊่ࠥฮหࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡล็ฦ๋ลࠧᾀ"))
	if VjwKs4GNQZ518kCl==FIHNSc5iuoZanQ2Ytl(u"࠵ਗ਼"): ZERUfKJBIvbeq03DoCSz()
	return
def NN16ROQuHBLkV7nvqycxSFDwJ5():
	KK47FGdX1TDfkb3AjHOQqghE(EEvLoMzFqrlKce(u"ࠨࠩᾁ"),ttOu147wErcBvPaSMUY(u"ࠩࠪᾂ"),TWexH5PhS1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᾃ"),N9olEh0ZMtpOivVfBLK(u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪᾄ"))
	return
def yPsEBgu9x2clFKL0z():
	F67qZAgMjPukRfJ = WmaPChRdQk3YcXwI6zS(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬᾅ")
	KK47FGdX1TDfkb3AjHOQqghE(PiFkQ5pCJy7fbX(u"࠭ࠧᾆ"),oAXJCYqPgyGDtT(u"ࠧࠨᾇ"),ZEiR0StquOzca9lvPAndYIX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᾈ"),F67qZAgMjPukRfJ)
	return
def PKc3Opd5lhQk70():
	F67qZAgMjPukRfJ = VH9MDo5z1kxNF07uRJI(u"ࠩส่ึ๎วษูࠣห้ฮื๋ศฬࠤ้อฺࠠๆสๆฮࠦไ่ษࠣฬฬ๊ศา่ส้ั่ࠦ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั࠭ᾉ")
	KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࠫᾊ"),VOq8Ekue4F(u"ࠫࠬᾋ"),VOq8Ekue4F(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᾌ"),F67qZAgMjPukRfJ)
	return
def sLwcqUvWGBxmCJuRK8():
	F67qZAgMjPukRfJ = EEvLoMzFqrlKce(u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪᾍ")
	KK47FGdX1TDfkb3AjHOQqghE(HVibA2ES8lY(u"ࠧࠨᾎ"),PiFkQ5pCJy7fbX(u"ࠨࠩᾏ"),HH4JMrUDp3lq6hQ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᾐ"),PiFkQ5pCJy7fbX(u"ࠪื๏ืแาษอࠤุ๐ฦสࠢฦ์๋ࠥฬ่๊็อࠬᾑ"),F67qZAgMjPukRfJ)
	return
def eRvocs9nEDQTiSYmyBhaA():
	F67qZAgMjPukRfJ = PiFkQ5pCJy7fbX(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆ฼ห๊ฯ่ࠠ์ࠣื๏ืแาษอࠤำอัอ์ฬࠤํเ๊าࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊ࠡฯ้๏฿ࠠศๆ่์ฬู่ࠡฬึฮำีๅ่ษࠣ์฾อฯสࠢอ็ํ์ࠠๆฮส๊๏ฯ้ࠠ็ืห่๊็ศࠢๆฯ๏ืษࠡๆส๊ࠥอไโ์า๎ํํวหࠢไ๎์อࠠฦ็สࠤอ฽๊วหࠣวํࠦๅๆ่๋฽ฮࠦร้่ࠢัี๎แสࠢฦ์ࠥ็๊่ษู้้ࠣไสࠢะๆํ่ࠠศๆ่่่๐ษ࡝ࡰ࡟ࡲࡡࡴวๅีํีๆืวหࠢส่ำอีส๊ࠢ๎ู๊ࠥาใิหฯࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ๅิฬัำ๊ฯࠠโ์้ࠣํอโฺࠢๅ่๏๊ษࠡฮาหࠥ๎ูศัฬࠤฯ้่็่ࠢำๆ๎ูสࠢส่ศาัࠡล๋ࠤ๏๋ไไ้สࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๊็ัษࠣๅ์๐ࠠอ์าอࠥ์ำษ์สࠤํูั๋฻ฬࠤํ๋ิศๅ็๋ฬࠦโๅ์็อࠥาฯศࠩᾒ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(h5huy6MiXPNfQJF8(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬᾓ"),l5mQdjWyczr7UJVnTp(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾔ"),F67qZAgMjPukRfJ,l5mQdjWyczr7UJVnTp(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪᾕ"))
	return
def dNJD7LiuvmRosQHlCPr():
	n9GNlZCisxWpEb1rqX5RAUjScJuT = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ิ่ษࠡษ็฽ฬ๊๊สࠩᾖ")
	SR7NUj9vYW2B5lLai0DqF = HVibA2ES8lY(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣว้ࠦ࡭࠴ࡷ࠻ࠫᾗ")
	O3PvLtuErnZygxlBzUI = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠥ๎วๅัส์๋๊่ะࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᾘ")
	KK47FGdX1TDfkb3AjHOQqghE(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠬᾙ"),HVibA2ES8lY(u"ࠬ࠭ᾚ"),ttOu147wErcBvPaSMUY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾛ"),n9GNlZCisxWpEb1rqX5RAUjScJuT,SR7NUj9vYW2B5lLai0DqF,O3PvLtuErnZygxlBzUI)
	return
def ddob1Mnwhm():
	SR7NUj9vYW2B5lLai0DqF = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧศๆๆหูࠦ็้่ࠢาื์ࠠๆฦๅฮ๊ࠥไๆ฻็์๊อสࠡ์ึฮำีๅ่ࠢส่อืๆศ็ฯࠤ้ิา็ุࠢๅาอสࠡษ็ษ๋ะั็์อࠤํื่ศสฺࠤฬ๊แ๋ัํ์์อสࠡๆ็์ฺ๎ไࠡว็๎์อࠠษีิ฽ฮ่ࠦษั๋๊ࠥหๆหำ้๎ฯ่ࠦศๆหี๋อๅอࠢํุ้ำ็ศࠢอ่็อฦ๋ษࠣฬ฾ีࠠศ่อ๋ฬวฺࠠ็ิ๋ฬ่ࠦฤ์ูหࠥ฿ๆะࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣ࠲ࠥ๎็ัษࠣห้ฮั็ษ่ะࠥ๐ำหะาู้ࠥศฺหࠣว๋๎วฺࠢ็฽๊ืࠠศๆๆหูࠦ࠺ࠨᾜ")
	SR7NUj9vYW2B5lLai0DqF += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࡞ࡱࡠࡳ࠭ᾝ") + HVibA2ES8lY(u"ࠩ࠴࠲ࠥัวษฬ่้ࠣ฻แฮษอࠤฬ๊ส๋่ࠢ฽ึ๎แࠡล้๋ฬࠦไศࠢอฮ฿๐ั่๊ࠡหห๐ว๊่ࠡำฯํࠠࠨᾞ") + str(U6y1OBwzfkEuRGVNrpYFv/f5uqIoSJzWBOFyrY78RXmVb(u"࠻࠶ਜ਼")/f5uqIoSJzWBOFyrY78RXmVb(u"࠻࠶ਜ਼")/f5uqIoSJzWBOFyrY78RXmVb(u"࠸࠴ੜ")/sDiKwnHcSlYFgWCy1Ak(u"࠳࠱੝")) + WmaPChRdQk3YcXwI6zS(u"ࠪࠤูํัࠨᾟ")
	SR7NUj9vYW2B5lLai0DqF += vatyjK4hHAoZJ7rOq2lis(u"ࠫࡡࡴࠧᾠ") + PiFkQ5pCJy7fbX(u"ࠬ࠸࠮ࠡฮาหࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้๋แาู๊ࠤศ์็ศࠢ็หࠥะส฻์ิࠤํ๋ฯห้ࠣࠫᾡ") + str(l7S6tnfTxVX4QyHohFMCrOW15Em/FIHNSc5iuoZanQ2Ytl(u"࠷࠲ਫ਼")/FIHNSc5iuoZanQ2Ytl(u"࠷࠲ਫ਼")/mNkfJnpOrad7hT6PYyciwsSDQ(u"࠴࠷੟")) + cbngtp9sqYi0DjeEMLRHJruKxm(u"๋๊่࠭ࠠࠫᾢ")
	SR7NUj9vYW2B5lLai0DqF += ZEiR0StquOzca9lvPAndYIX(u"ࠧ࡝ࡰࠪᾣ") + S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬᾤ") + str(CC89Q23uNDmIKWHAs/cbngtp9sqYi0DjeEMLRHJruKxm(u"࠹࠴੠")/cbngtp9sqYi0DjeEMLRHJruKxm(u"࠹࠴੠")/Xl3drKyI9HkDiPEf8RTjwu(u"࠶࠹੡")) + HVibA2ES8lY(u"ࠩࠣ๎ํ๋ࠧᾥ")
	SR7NUj9vYW2B5lLai0DqF += N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡠࡳ࠭ᾦ") + uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭ᾧ") + str(GGXxhdg3JCamPIFepybjZ/QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠻࠶੢")/QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠻࠶੢")) + weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࠦำศ฻ฬࠫᾨ")
	SR7NUj9vYW2B5lLai0DqF += N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࡜࡯ࠩᾩ") + cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧ࠶࠰ࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥีวว็สࠤํ๋ฯห้ࠣࠫᾪ") + str(j9t7FmfZiE6pYGI8V4u/VOq8Ekue4F(u"࠼࠰੣")/VOq8Ekue4F(u"࠼࠰੣")) + N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠢึห฾ฯࠧᾫ")
	SR7NUj9vYW2B5lLai0DqF += f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡟ࡲࠬᾬ") + Xl3drKyI9HkDiPEf8RTjwu(u"ࠪ࠺࠳ࠦฬะษࠣๆฺ๐ัࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํี้ࠥห๋ำสࠤํ๋ฯห้ࠣࠫᾭ") + str(BZ5D43mGxLAItEUYTv/vatyjK4hHAoZJ7rOq2lis(u"࠶࠱੤")) + WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠥีโ๋ไฬࠫᾮ")
	SR7NUj9vYW2B5lLai0DqF += EEvLoMzFqrlKce(u"ࠬࡢ࡮ࠨᾯ") + ZEiR0StquOzca9lvPAndYIX(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨᾰ") + str(vZs8PpIdBUNQTjnbEymoYx6X) + TWexH5PhS1(u"ࠧࠡัๅ๎็ฯࠧᾱ")
	SR7NUj9vYW2B5lLai0DqF += ZEiR0StquOzca9lvPAndYIX(u"ࠨ࡞ࡱࡠࡳ࠭ᾲ") + PiFkQ5pCJy7fbX(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭ᾳ") + str(GGXxhdg3JCamPIFepybjZ/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")) + TWexH5PhS1(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫᾴ") + str(CC89Q23uNDmIKWHAs/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")/EmK3ObA0cwv9Wy(u"࠴࠷੦")) + Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪ᾵") + str(j9t7FmfZiE6pYGI8V4u/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")) + VOq8Ekue4F(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩᾶ") + str(BZ5D43mGxLAItEUYTv/S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲੥")) + l5mQdjWyczr7UJVnTp(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨᾷ") + str(vZs8PpIdBUNQTjnbEymoYx6X) + ZEiR0StquOzca9lvPAndYIX(u"ࠧࠡัๅ๎็ฯࠧᾸ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡴ࡬࡫࡭ࡺࠧᾹ"),sbgu4D2RFMYKm(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧᾺ"),SR7NUj9vYW2B5lLai0DqF,sbgu4D2RFMYKm(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭Ά"))
	return
def TT4cPAntjHQzpIR7F6Cye8fGLxhr5S():
	F67qZAgMjPukRfJ = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧᾼ")
	KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬ࠭᾽"),WmaPChRdQk3YcXwI6zS(u"࠭ࠧι"),oAXJCYqPgyGDtT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᾿"),F67qZAgMjPukRfJ)
	return
def a9puCmZe8rgwqT4Vj2YGfNOUM0o():
	F67qZAgMjPukRfJ = EEvLoMzFqrlKce(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩ῀")
	KK47FGdX1TDfkb3AjHOQqghE(ZhqJoOtcmTVID65HwnLj(u"ࠩࠪ῁"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠫῂ"),sDiKwnHcSlYFgWCy1Ak(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧῃ"),F67qZAgMjPukRfJ)
	return
def xd5HP0crFRLDbOsyEUv7KpuIqm():
	F67qZAgMjPukRfJ = VOq8Ekue4F(u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩῄ")
	KK47FGdX1TDfkb3AjHOQqghE(HVibA2ES8lY(u"࠭ࠧ῅"),h5huy6MiXPNfQJF8(u"ࠧࠨῆ"),PiFkQ5pCJy7fbX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫῇ"),F67qZAgMjPukRfJ)
	return
def QjKShaOF03Y():
	KK47FGdX1TDfkb3AjHOQqghE(N9olEh0ZMtpOivVfBLK(u"ࠩࠪῈ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠫΈ"),HH4JMrUDp3lq6hQ(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧῊ"),ttOu147wErcBvPaSMUY(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪΉ"))
	PKyL2wI9WdZEbzs4t5muq(h5huy6MiXPNfQJF8(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ῌ"),WmaPChRdQk3YcXwI6zS(u"࡙ࡸࡵࡦય"))
	return
def PPjr5pBNOeM62gs():
	F67qZAgMjPukRfJ  = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩ῍")
	F67qZAgMjPukRfJ += VH9MDo5z1kxNF07uRJI(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨ῎")
	F67qZAgMjPukRfJ += uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣเ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ࠭῏")
	F67qZAgMjPukRfJ += Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪῐ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡷ࡯ࡧࡩࡶࠪῑ"),oAXJCYqPgyGDtT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨῒ"),F67qZAgMjPukRfJ,N9olEh0ZMtpOivVfBLK(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩΐ"))
	F67qZAgMjPukRfJ = PiFkQ5pCJy7fbX(u"ࠧศๆ่์ฬู่ࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ῔")
	F67qZAgMjPukRfJ += QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࡞ࡱࠫ῕")+sDiKwnHcSlYFgWCy1Ak(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࡞࠳ࡈࡕࡌࡐࡔࡠࠫῖ")
	F67qZAgMjPukRfJ += sDiKwnHcSlYFgWCy1Ak(u"ࠪࡠࡳࡢ࡮ࠨῗ")+l5mQdjWyczr7UJVnTp(u"ࠫฬ๊ฯ้ๆࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬῘ")
	F67qZAgMjPukRfJ += h5huy6MiXPNfQJF8(u"ࠬࡢ࡮ࠨῙ")+HVibA2ES8lY(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫῚ")
	F67qZAgMjPukRfJ += TWexH5PhS1(u"ࠧ࡝ࡰ࡟ࡲࠬΊ")+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨษ็้อืๅอ๋ࠢะิࠦืา์ๅอ๊ࠥสอษ๋ึࠥอไฺษษๆࠥ๎ไไ่๊หࠥะอหษฯࠤัํฯࠡๅห๎ึ่ࠦศๆ่ฬึ๋ฬࠡ์฻๊ࠥอไๆึๆ่ฮࠦี฻์ิอࠥ๎ไศࠢอืฯำโࠡษ็ฮ฾ฮࠠโวำห๊ࠥฯ๋ๅู้้ࠣไสࠢหห้ีฮ้ๆ่ࠣอ฿ึࠡษ็้ํอโฺ๋ࠢว๏฼วࠡๆๆ๎ࠥ๐สืฯࠣัั๋ࠠศๆุ่่๊ษࠡࠩ῜")
	F67qZAgMjPukRfJ += ZhqJoOtcmTVID65HwnLj(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ῝")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(sDiKwnHcSlYFgWCy1Ak(u"ࠪࡶ࡮࡭ࡨࡵࠩ῞"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ῟"),F67qZAgMjPukRfJ,f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨῠ"))
	return
def imMR2GLhKzEqW5kQjNx4DTr1():
	KK47FGdX1TDfkb3AjHOQqghE(cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࠧῡ"),ZEiR0StquOzca9lvPAndYIX(u"ࠧࠨῢ"),ZhqJoOtcmTVID65HwnLj(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨΰ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡨࡵࡶࡳ࠾࠴࠵ࡦࡢࡥࡨࡦࡴࡵ࡫࠯ࡥࡲࡱ࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳษ่ࠡสสีุอไࠡษํ้๏๊ࠠศๆ์ࠤศีๆศ้ࠣࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡅ࡭࡭ࡢ࡫࡯࠲ࡨࡵ࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩῤ"))
	return
def gaAdytMl8wE():
	ddob1Mnwhm()
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(HH4JMrUDp3lq6hQ(u"ࠪࡧࡪࡴࡴࡦࡴࠪῥ"),oAXJCYqPgyGDtT(u"ࠫࠬῦ"),EmK3ObA0cwv9Wy(u"ࠬ࠭ῧ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪῨ"),EmK3ObA0cwv9Wy(u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬ่ࠦศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯ่ࠦศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧῩ"))
	if VjwKs4GNQZ518kCl==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠴੧"):
		R1JaOzyTLxfMvBigeYuhn(mNkfJnpOrad7hT6PYyciwsSDQ(u"࡚ࡲࡶࡧર"))
		KK47FGdX1TDfkb3AjHOQqghE(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠩῪ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࠪΎ"),EEvLoMzFqrlKce(u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪῬ"),oAXJCYqPgyGDtT(u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ῭"))
	return VjwKs4GNQZ518kCl
def QceuJfq72gU6MPWzVdDLi3Kkv(showDialogs=EEvLoMzFqrlKce(u"ࡔࡳࡷࡨ઱")):
	if not showDialogs: showDialogs = WmaPChRdQk3YcXwI6zS(u"ࡕࡴࡸࡩલ")
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡍࡅࡕࠩ΅"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬ`"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨ῰"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩ῱"),l5mQdjWyczr7UJVnTp(u"ࡈࡤࡰࡸ࡫ળ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࠪῲ"),ZhqJoOtcmTVID65HwnLj(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ῳ"))
	if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
		EHlzaSoZjcKGfOV41QyX = vatyjK4hHAoZJ7rOq2lis(u"ࡉࡥࡱࡹࡥ઴")
		ADGaJxoXtdLcSsC5R4WNj = CycHPIbdjsO7hKg93uaxTRvW4ti5X1()
		GZvEITHSg5U3rVwQ(h5huy6MiXPNfQJF8(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩῴ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+vatyjK4hHAoZJ7rOq2lis(u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝ࠪ῵")+ADGaJxoXtdLcSsC5R4WNj+N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࡝ࠨῶ"))
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࠨῷ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࠩῸ"),HVibA2ES8lY(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬΌ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧῺ"))
	else:
		EHlzaSoZjcKGfOV41QyX = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡘࡷࡻࡥવ")
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࠬΏ"),sbgu4D2RFMYKm(u"ࠬ࠭ῼ"),h5huy6MiXPNfQJF8(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ´"),TWexH5PhS1(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫ῾"))
	if not EHlzaSoZjcKGfOV41QyX and showDialogs: C7WR6c2en4b()
	return EHlzaSoZjcKGfOV41QyX
def C7WR6c2en4b():
	KK47FGdX1TDfkb3AjHOQqghE(EmK3ObA0cwv9Wy(u"ࠨࠩ῿"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬࠀ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࠁ"),HH4JMrUDp3lq6hQ(u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬࠂ"))
	wkuBsGxyVEvdYgFWARDN7()
	return
def fh904xAZLIjSWJGO3U(yv8XxUjorzB2CRA4Jife73VMklHp=WmaPChRdQk3YcXwI6zS(u"ࠧࠨࠃ")):
	QQTqHdRmAn3YKtB = PiFkQ5pCJy7fbX(u"࡙ࡸࡵࡦશ")
	if vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫࠄ") not in yv8XxUjorzB2CRA4Jife73VMklHp:
		QQTqHdRmAn3YKtB = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࡌࡡ࡭ࡵࡨષ")
		IXT3PBU82c54ekwMFZhQKy9t0d7ROb = GNX3qVRf4oBdtkEi5u(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡦࡩࡳࡺࡥࡳࠩࠅ"),h5huy6MiXPNfQJF8(u"ࠪาึ๎ฬࠨࠆ"),WmaPChRdQk3YcXwI6zS(u"ࠫสืำศๆู้้ࠣไสࠩࠇ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬหัิษ็ࠤึูวๅหࠪࠈ"),FIHNSc5iuoZanQ2Ytl(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠉ"),oAXJCYqPgyGDtT(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤฯืำๅࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ัࠦ࠮࠯ࠢฦ้ࠥะั๋ัࠣว๋ࠦสาี็ࠤฺ๊ใๅห้ࠣํา่ะหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠪࠊ"))
		if IXT3PBU82c54ekwMFZhQKy9t0d7ROb in [-PiFkQ5pCJy7fbX(u"࠵੨"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵੩")]: return
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb==EmK3ObA0cwv9Wy(u"࠷੪"):
			QQTqHdRmAn3YKtB = ZhqJoOtcmTVID65HwnLj(u"ࡔࡳࡷࡨસ")
			yv8XxUjorzB2CRA4Jife73VMklHp = VOq8Ekue4F(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫࠋ")
	if QQTqHdRmAn3YKtB:
		if HH4JMrUDp3lq6hQ(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩࠌ") not in yv8XxUjorzB2CRA4Jife73VMklHp:
			VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡧࡪࡴࡴࡦࡴࠪࠍ"),HVibA2ES8lY(u"ࠫࠬࠎ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࠭ࠏ"),HH4JMrUDp3lq6hQ(u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭ࠐ"),ttOu147wErcBvPaSMUY(u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧࠑ"))
			if VjwKs4GNQZ518kCl!=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠱੫"):
				KK47FGdX1TDfkb3AjHOQqghE(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠩࠒ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࠪࠓ"),EmK3ObA0cwv9Wy(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭ࠔ"),sbgu4D2RFMYKm(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧࠕ"))
				return
	KK47FGdX1TDfkb3AjHOQqghE(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬ࠭ࠖ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠧࠗ"),VH9MDo5z1kxNF07uRJI(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠘"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨใํࠤฬ๊ิศึฬࠤฬ๊โศั่อࠥำว้ๆࠣว๋ࠦสไฬหࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡสุึำࠠโ์๊หࠥอไๆึๆ่ฮࠦร้ࠢส่๊๎ึ้฻ࠣ์สึวࠡลิำฯࠦฬ้ษหࠤ๊์ࠠศๆ่ฬึ๋ฬࠡใศิ๋ࠦรไฬหࠤ฾์่ศ่ࠣฬึ๐ฯไࠢฦ่ส๊ใหำ๋๊๏ࠦวๅวํ้๏๊้ࠠฬำ็ึ่ࠦๅษࠣฮู๋้ࠡล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠙"))
	search = NWs7KpjXGnxYylofHtd5U3wDh(header=WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࡚ࠩࡶ࡮ࡺࡥࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࡩࠥࠦࠠศๅอฬࠥืำศๆฬࠫࠚ"),source=nO6ukabcldeU)
	if not search: return
	F67qZAgMjPukRfJ = search
	if QQTqHdRmAn3YKtB: type = oAXJCYqPgyGDtT(u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠫࠛ")
	else: type = WmaPChRdQk3YcXwI6zS(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠬࠜ")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG = YYKFsUfhQctD1bjpEzZagd(type,F67qZAgMjPukRfJ,EEvLoMzFqrlKce(u"ࡕࡴࡸࡩહ"),l5mQdjWyczr7UJVnTp(u"ࠬ࠭ࠝ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩࠞ"),yv8XxUjorzB2CRA4Jife73VMklHp)
	return
def iuzEyP1jNa89DLM2Aex7v5BgH():
	yv8XxUjorzB2CRA4Jife73VMklHp = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"่ࠧาสࠤฬ๊ศา่ส้ัࠦไศࠢํ์ัีࠠๅ้ࠣว๏ࠦำ๋ำไีࠥ๐ำหุํๅࠥษ๊ࠡ็ะฮํ๐วห࠰ࠣห้ฮั็ษ่ะࠥ๐ำหะา้ࠥื่ศสฺࠤํะึๆ์้ࠤ้๋อห๊ํหฯࠦๅาใ๋฽ฮูࠦๅ๋ࠣื๏ืแาษอࠤำอัอ์ฬ࠲ࠥอไษำ้ห๊าࠠ฻์ิࠤู๊ฤ้ๆࠣ฽๋ࠦร๋่ࠢัฯ๎๊ศฬࠣฮ๊ࠦสฮ็ํ่์อฺࠠๆ์ࠤุ๐ัโำสฮࠥ๎ๅ้ษๅ฽ࠥิวาฮํอࠥࠨๅ้ษๅ฽ࠥ฽ัโࠢฮห้ัࠢ࠯ࠢฯ้๏฿ࠠศๆฦื๊อม๊ࠡส่๊อัไษอࠤํอไึ๊ิࠤํอไๆ่ื์ึอส้ࠡํࠤำอีสࠢหหฺำวษ้ส࠲ࠥอไษำ้ห๊าࠠๅษࠣ๎๋ะ็ไࠢะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠢࡇࡑࡈࡇࠠฦาสࠤ่อๆࠡๆา๎่ࠦิไ๊์ࠤำอีสࠢหห้ื่ศสฺࠤํอไหุส้๏์ࠠศๆัหึา๊สࠢไห้ืฬศรࠣห้ะ่ศื็ࠤ๊฿ࠠฦัสีฮࠦ็ั้ࠣหู้๊าใิหฯ่ࠦศๆ่์ฬู่ࠡษ็าฬืฬ๋ห࠱ࠤ์ึวࠡษ็ฬึ์วๆฮ๋ࠣํࠦศษีส฻ฮࠦๅหืไั๊ࠥๅ้ษๅ฽ࠥอไ้์หࠫࠟ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡴ࡬࡫࡭ࡺࠧࠠ"),l5mQdjWyczr7UJVnTp(u"ࠩะๆํ่ࠠศๆฺฬ฾่ࠦศๆุ้ึ่ࠦใษ้์๋ࠦวๅล็ๅ๏ฯࠠๅๆ่่่๐ษࠡษ็ี็๋๊สࠩࠡ"),yv8XxUjorzB2CRA4Jife73VMklHp,FIHNSc5iuoZanQ2Ytl(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ࠢ"))
	yv8XxUjorzB2CRA4Jife73VMklHp = sDiKwnHcSlYFgWCy1Ak(u"࡙ࠫ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡮࡯ࡴࡶࠣࡥࡳࡿࠠࡤࡱࡱࡸࡪࡴࡴࠡࡱࡱࠤࡦࡴࡹࠡࡵࡨࡶࡻ࡫ࡲ࠯ࠢࡌࡸࠥࡵ࡮࡭ࡻࠣࡹࡸ࡫ࡳࠡ࡮࡬ࡲࡰࡹࠠࡵࡱࠣࡩࡲࡨࡥࡥࡦࡨࡨࠥࡩ࡯࡯ࡶࡨࡲࡹࠦࡴࡩࡣࡷࠤࡼࡧࡳࠡࡷࡳࡰࡴࡧࡤࡦࡦࠣࡸࡴࠦࡰࡰࡲࡸࡰࡦࡸࠠࡰࡰ࡯࡭ࡳ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡨࡰࡵࡷ࡭ࡳ࡭ࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡂ࡮࡯ࠤࡹࡸࡡࡥࡧࡰࡥࡷࡱࡳ࠭ࠢࡹ࡭ࡩ࡫࡯ࡴ࠮ࠣࡸࡷࡧࡤࡦࠢࡱࡥࡲ࡫ࡳ࠭ࠢࡶࡩࡷࡼࡩࡤࡧࠣࡱࡦࡸ࡫ࡴ࠮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹ࡫ࡤࠡࡹࡲࡶࡰ࠲ࠠ࡭ࡱࡪࡳࡸࠦࡲࡦࡨࡨࡶࡪࡴࡣࡦࡦࠣ࡬ࡪࡸࡥࡪࡰࠣࡦࡪࡲ࡯࡯ࡩࠣࡸࡴࠦࡴࡩࡧ࡬ࡶࠥࡸࡥࡴࡲࡨࡧࡹ࡯ࡶࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤࡨࡵ࡭ࡱࡣࡱ࡭ࡪࡹ࠮ࠡࡖ࡫ࡩࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡱࡳࡹࠦࡲࡦࡵࡳࡳࡳࡹࡩࡣ࡮ࡨࠤ࡫ࡵࡲࠡࡹ࡫ࡥࡹࠦ࡯ࡵࡪࡨࡶࠥࡶࡥࡰࡲ࡯ࡩࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡ࠵ࡵࡨࠥࡶࡡࡳࡶࡼࠤࡸ࡯ࡴࡦࡵ࠱ࠤ࡜࡫ࠠࡶࡴࡪࡩࠥࡧ࡬࡭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡵࡷ࡯ࡧࡵࡷ࠱ࠦࡴࡰࠢࡵࡩࡨࡵࡧ࡯࡫ࡽࡩࠥࡺࡨࡢࡶࠣࡸ࡭࡫ࠠ࡭࡫ࡱ࡯ࡸࠦࡣࡰࡰࡷࡥ࡮ࡴࡥࡥࠢࡺ࡭ࡹ࡮ࡩ࡯ࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡣࡵࡩࠥࡲ࡯ࡤࡣࡷࡩࡩࠦࡳࡰ࡯ࡨࡻ࡭࡫ࡲࡦࠢࡨࡰࡸ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡸࡧࡥࠤࡴࡸࠠࡷ࡫ࡧࡩࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡣࡵࡩࠥ࡬ࡲࡰ࡯ࠣࡳࡹ࡮ࡥࡳࠢࡹࡥࡷ࡯࡯ࡶࡵࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣ࡬ࡦࡼࡥࠡࡣࡱࡽࠥࡲࡥࡨࡣ࡯ࠤ࡮ࡹࡳࡶࡧࡶࠤࡵࡲࡥࡢࡵࡨࠤࡨࡵ࡮ࡵࡣࡦࡸࠥࡧࡰࡱࡴࡲࡴࡷ࡯ࡡࡵࡧࠣࡱࡪࡪࡩࡢࠢࡩ࡭ࡱ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢ࡫ࡳࡸࡺࡥࡳࡵ࠱ࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡳࡪ࡯ࡳࡰࡾࠦࡡࠡࡹࡨࡦࠥࡨࡲࡰࡹࡶࡩࡷ࠴ࠧࠣ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(ZhqJoOtcmTVID65HwnLj(u"ࠬࡲࡥࡧࡶࠪࠤ"),PiFkQ5pCJy7fbX(u"࠭ࡄࡪࡩ࡬ࡸࡦࡲࠠࡎ࡫࡯ࡰࡪࡴ࡮ࡪࡷࡰࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡂࡥࡷࠤ࠭ࡊࡍࡄࡃࠬࠫࠥ"),yv8XxUjorzB2CRA4Jife73VMklHp,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪࠦ"))
	return
def wwVx6hRf2Uy9oStgdXb(x7NwSuz5ft4e):
	hrgtXiSNu72 = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(FIHNSc5iuoZanQ2Ytl(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫࠧ")+x7NwSuz5ft4e+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡧࡣ࡯ࡷࡪࢃࡽࠨࠨ"))
	B6B7iVh1qW5Py = l5mQdjWyczr7UJVnTp(u"ࡖࡵࡹࡪ઺")
	if B6B7iVh1qW5Py:
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(EEvLoMzFqrlKce(u"࠲੬"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(WmaPChRdQk3YcXwI6zS(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧࠩ"))
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(EEvLoMzFqrlKce(u"࠳੭"))
	return
def eG2scIZNdSKb4tYzJy70EgXMQPaFA():
	KK47FGdX1TDfkb3AjHOQqghE(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬࠪ"),ZhqJoOtcmTVID65HwnLj(u"ࠬ࠭ࠫ"),EEvLoMzFqrlKce(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࠬ"),vatyjK4hHAoZJ7rOq2lis(u"ࠧศๆหี๋อๅอࠢ็หࠥ๐แฮืุࠣ์อฯสࠢส่ฯฺแ๋ำࠣ฽๋ีࠠศๆสฮฺอไࠡสส่๊๎วใ฻ࠣห้๋ิโำฬࠤํ๊็ัษࠣๅ๏ࠦอศๆࠣ์ั๎ฯࠡึ๊หิฯࠠ฻์ิࠤฺำ๊ฮหࠣวํࠦๅ็ฬ๊๎ฮࠦวๅื็หา๐ษࠡล๋ࠤุ๊๊โหࠣๅฬ์่ࠠาสࠤ้์๋๊ࠠๅๅࠥอไาสฺࠤฬ๊ๅีใิࠤํ๊ๆࠡ์๋ๆๆูࠦๆๆࠣห้ฮั็ษ่ะࠬ࠭"))
	xd5HP0crFRLDbOsyEUv7KpuIqm()
	return
def wkuBsGxyVEvdYgFWARDN7():
	url = Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࡬ࡶࡷࡵࡲࡴ࠰࡮ࡳࡩ࡯࠮ࡵࡸ࠲ࡶࡪࡲࡥࡢࡵࡨࡷ࠴ࡽࡩ࡯ࡦࡲࡻࡸ࠵ࡷࡪࡰ࠹࠸࠴࠭࠮")
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡊࡉ࡙࠭࠯"),url,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࠫ࠰"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࠬ࠱"),vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠭࠲"),sbgu4D2RFMYKm(u"࠭ࠧ࠳"),VH9MDo5z1kxNF07uRJI(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡖࡌࡔ࡝࡟ࡍࡃࡗࡉࡘ࡚࡟ࡌࡑࡇࡍࡤ࡜ࡅࡓࡕࡌࡓࡓ࠳࠱ࡴࡶࠪ࠴"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	xuj6MTyzQrkDen = T072lCzjYiuaeFtmJGV.findall(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣ࡭ࡲࡨ࡮࠳ࠨ࡝ࡦ࠮ࡠ࠳ࡢࡤࠬ࠯࡞ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯࠮࠳ࠧ࠵"),qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	xuj6MTyzQrkDen = xuj6MTyzQrkDen[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠳੮")].split(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࠰ࠫ࠶"))[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠳੮")]
	kElXrZoe2DagG9f1SC7QLFY3Uy = str(XK3HqaTnjpyIAuhw67CmdvBM)
	yNXrMl0Q3w5uOIJZcizxKLC = FIHNSc5iuoZanQ2Ytl(u"ࠪ࡟ࡗ࡚ࡌ࡞วุำฬืࠠไ๊า๎ࠥอไฤะํีࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ࠷")+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ࠸")+xuj6MTyzQrkDen+l5mQdjWyczr7UJVnTp(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠹")
	yNXrMl0Q3w5uOIJZcizxKLC += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭࡜࡯࡞ࡱࠫ࠺")+ZhqJoOtcmTVID65HwnLj(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋ࠥํ่ࠡ࠼ࠣࠤࠥ࠭࠻")+VOq8Ekue4F(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ࠼")+kElXrZoe2DagG9f1SC7QLFY3Uy+EmK3ObA0cwv9Wy(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠽")
	KK47FGdX1TDfkb3AjHOQqghE(vatyjK4hHAoZJ7rOq2lis(u"ࠪࠫ࠾"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࠬ࠿"),ZEiR0StquOzca9lvPAndYIX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡀ"),yNXrMl0Q3w5uOIJZcizxKLC)
	return
def WG5T4EVpBciP1hb6():
	n9GNlZCisxWpEb1rqX5RAUjScJuT,SR7NUj9vYW2B5lLai0DqF,O3PvLtuErnZygxlBzUI,yNXrMl0Q3w5uOIJZcizxKLC,ccLx9sNWQizTGalPOrvSdn,Ckjw1bzUlAWvpEd,gWobv6rLVXFAKpC = ZEiR0StquOzca9lvPAndYIX(u"࠭ࠧࡁ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠨࡂ"),HH4JMrUDp3lq6hQ(u"ࠨࠩࡃ"),oAXJCYqPgyGDtT(u"ࠩࠪࡄ"),HVibA2ES8lY(u"ࠪࠫࡅ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࠬࡆ"),N9olEh0ZMtpOivVfBLK(u"ࠬ࠭ࡇ")
	y7PU6am9Z3I,P1cLV8ZwRvp93UkTo6fb,N5NEBlIhVgwZ28mdYervMbKzxUP,jD3OnqZsTB0oF = {g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡡࠨࡈ"):VOq8Ekue4F(u"ࠧࡢࠩࡉ")},{},[],{}
	url = tOnYIHVk4xydqwoLEBKiDN0hX[h5huy6MiXPNfQJF8(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨࡊ")][Xl3drKyI9HkDiPEf8RTjwu(u"࠵੯")]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(BZ5D43mGxLAItEUYTv,vatyjK4hHAoZJ7rOq2lis(u"ࠩࡓࡓࡘ࡚ࠧࡋ"),url,y7PU6am9Z3I,f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠫࡌ"),sDiKwnHcSlYFgWCy1Ak(u"ࠫࠬࡍ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࠭ࡎ"),N9olEh0ZMtpOivVfBLK(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫࡏ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(EmK3ObA0cwv9Wy(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡔࡶࡤࡸࡪࡹࠧࡐ"),N9olEh0ZMtpOivVfBLK(u"ࠨࡗࡖࡅࠬࡑ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(ZhqJoOtcmTVID65HwnLj(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪࡒ"),N9olEh0ZMtpOivVfBLK(u"࡙ࠪࡐ࠭ࡓ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(N9olEh0ZMtpOivVfBLK(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡆࡸࡡࡣࠢࡈࡱ࡮ࡸࡡࡵࡧࡶࠫࡔ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࡛ࠬࡁࡆࠩࡕ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡓࡢࡷࡧ࡭ࠥࡇࡲࡢࡤ࡬ࡥࠬࡖ"),h5huy6MiXPNfQJF8(u"ࠧࡌࡕࡄࠫࡗ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(VOq8Ekue4F(u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪࡘ"),VH9MDo5z1kxNF07uRJI(u"ࠩࡑ࠲ࡒࡧࡣࡦࡦࡲࡲ࡮ࡧ࡙ࠧ"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(mNkfJnpOrad7hT6PYyciwsSDQ(u"࡛ࠪࡪࡹࡴࡦࡴࡱࠤࡘࡧࡨࡢࡴࡤ࡚ࠫ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫ࡜࠴ࡓࡢࡪࡤࡶࡦ࡛࠭"))
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace(ZhqJoOtcmTVID65HwnLj(u"ࠬࡥ࡟ࡠࠩ࡜"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠠࠡࠩ࡝"))
	try: FJxf674u9An1tROVTB = cwiLy4IAVJj0pWCl7FGxokR(HVibA2ES8lY(u"ࠧ࡭࡫ࡶࡸࠬ࡞"),qQXuaKpVrGLF3e5oidJ8YwDT0)
	except:
		KK47FGdX1TDfkb3AjHOQqghE(l5mQdjWyczr7UJVnTp(u"ࠨࠩ࡟"),TWexH5PhS1(u"ࠩࠪࡠ"),VOq8Ekue4F(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡡ"),TWexH5PhS1(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫࡢ"))
		return
	nUe6JLwGms9V5P,dYSLHNryzFiGBwMI,BtLG7DfwFSibPy0Xms4uRK1grc = FJxf674u9An1tROVTB
	jD3OnqZsTB0oF = {}
	AtXanGc95VTvR7mZBdOL24xQbou = [vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨࡣ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬࡤ")]
	dNZY9h5jFI2HWkUD4MEALvtVXb = [WmaPChRdQk3YcXwI6zS(u"ࠧࡂࡎࡏࠫࡥ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨࡦ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪࡧ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧࡨ"),WmaPChRdQk3YcXwI6zS(u"ࠫࡗࡋࡐࡐࡕࠪࡩ")]+AtXanGc95VTvR7mZBdOL24xQbou+uuKXHhOMlYzfQVR+ZzyLYF3OidfSkKa79nhPecgjxIJE
	for vuyTFsAd72wDBiUPSnft5obMjErR6,hREIwc1zygVqrZsuP,YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ in dYSLHNryzFiGBwMI:
		YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ = Bd2o0J6aOASWvuD9HzY(YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ)
		YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ = YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ.strip(oAXJCYqPgyGDtT(u"ࠬࠦࠧࡪ")).strip(ttOu147wErcBvPaSMUY(u"࠭ࠠ࠯ࠩ࡫"))
		yNXrMl0Q3w5uOIJZcizxKLC += vatyjK4hHAoZJ7rOq2lis(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࡬")+vuyTFsAd72wDBiUPSnft5obMjErR6+oAXJCYqPgyGDtT(u"ࠨ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࡭")+YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ+TWexH5PhS1(u"ࠩ࡟ࡲࠬ࡮")
		if hREIwc1zygVqrZsuP.isdigit():
			jD3OnqZsTB0oF[vuyTFsAd72wDBiUPSnft5obMjErR6] = int(hREIwc1zygVqrZsuP)
			if int(hREIwc1zygVqrZsuP)>cbngtp9sqYi0DjeEMLRHJruKxm(u"࠶࠶࠰ੰ"): hREIwc1zygVqrZsuP = l5mQdjWyczr7UJVnTp(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭࡯")
			else: hREIwc1zygVqrZsuP = PiFkQ5pCJy7fbX(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭ࡰ")
		if vuyTFsAd72wDBiUPSnft5obMjErR6 not in dNZY9h5jFI2HWkUD4MEALvtVXb:
			if   hREIwc1zygVqrZsuP==l5mQdjWyczr7UJVnTp(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨࡱ"): n9GNlZCisxWpEb1rqX5RAUjScJuT += WmaPChRdQk3YcXwI6zS(u"࠭ࠠࠡࠩࡲ")+vuyTFsAd72wDBiUPSnft5obMjErR6
			elif hREIwc1zygVqrZsuP==ZEiR0StquOzca9lvPAndYIX(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩࡳ"): SR7NUj9vYW2B5lLai0DqF += N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠢࠣࠫࡴ")+vuyTFsAd72wDBiUPSnft5obMjErR6
	AASLcw69lDFq02zib,tHFrTufxXEU10Zy94oO,fDOeyxVE7KSRbrq4gad3NZjWmA6 = list(zip(*dYSLHNryzFiGBwMI))
	for vuyTFsAd72wDBiUPSnft5obMjErR6 in sorted(TLu7gCmS0Kk2lnP1cO):
		if vuyTFsAd72wDBiUPSnft5obMjErR6 not in AASLcw69lDFq02zib:
			yNXrMl0Q3w5uOIJZcizxKLC += WmaPChRdQk3YcXwI6zS(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧࡵ")+vuyTFsAd72wDBiUPSnft5obMjErR6+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡶ")+mNkfJnpOrad7hT6PYyciwsSDQ(u"้ࠫอ๋๊ࠠฯำࠬࡷ")+HVibA2ES8lY(u"ࠬࡢ࡮࡝ࡰࠪࡸ")
			if vuyTFsAd72wDBiUPSnft5obMjErR6 not in dNZY9h5jFI2HWkUD4MEALvtVXb: O3PvLtuErnZygxlBzUI += ZhqJoOtcmTVID65HwnLj(u"࠭ࠠࠡࠩࡹ")+vuyTFsAd72wDBiUPSnft5obMjErR6
	for YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ,oqiYRLNObxnI2sZW3Bcgh in nUe6JLwGms9V5P:
		YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ = Bd2o0J6aOASWvuD9HzY(YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ)
		ccLx9sNWQizTGalPOrvSdn += YYqmhsRQ9WtPvlxAnd8CaHj35z4bJ+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬࡺ")+str(oqiYRLNObxnI2sZW3Bcgh)+sbgu4D2RFMYKm(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭ࡻ")
	n9GNlZCisxWpEb1rqX5RAUjScJuT = n9GNlZCisxWpEb1rqX5RAUjScJuT.strip(h5huy6MiXPNfQJF8(u"ࠩࠣࠫࡼ"))
	SR7NUj9vYW2B5lLai0DqF = SR7NUj9vYW2B5lLai0DqF.strip(HH4JMrUDp3lq6hQ(u"ࠪࠤࠬࡽ"))
	O3PvLtuErnZygxlBzUI = O3PvLtuErnZygxlBzUI.strip(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࠥ࠭ࡾ"))
	BAwihJsX781nUyTaGfV = n9GNlZCisxWpEb1rqX5RAUjScJuT+f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࠦࠠࠨࡿ")+SR7NUj9vYW2B5lLai0DqF
	fU2XgPWBisSyKM  = EEvLoMzFqrlKce(u"࠭ๅ้ษๅ฽ࠥ์ฬฮࠢส่อืๆศ็ฯࠤอะิ฻์็ࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪࢀ")+l5mQdjWyczr7UJVnTp(u"ࠧ࡝ࡰࠪࢁ")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ่์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ั࠭ࢂ")+FIHNSc5iuoZanQ2Ytl(u"ࠩ࡟ࡲࠬࢃ")
	fU2XgPWBisSyKM += Xl3drKyI9HkDiPEf8RTjwu(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࢄ")+BAwihJsX781nUyTaGfV+EEvLoMzFqrlKce(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪࢅ")
	fU2XgPWBisSyKM += HVibA2ES8lY(u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫࢆ")+vatyjK4hHAoZJ7rOq2lis(u"࠭࡜࡯ࠩࢇ")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"้้ࠧำหู๋ࠥ็ษ๊ࠤฬำสๆษ็ࠤ่ฮ๊า๋ࠢะํีࠠๆึๆ่ฮࠦแ๋ࠢส่อืๆศ็ฯࠫ࢈")+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨ࡞ࡱࠫࢉ")
	fU2XgPWBisSyKM += N9olEh0ZMtpOivVfBLK(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬࢊ")+O3PvLtuErnZygxlBzUI+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢋ")
	HJBWjkw5rylL,WoZRIw81f2hmSuPUKMTyADH9E,vv6JLpSqGzjkhTIOMd,WGcvAqMLiaHnBwh6mltECYegX783 = TWexH5PhS1(u"࠶ੱ"),TWexH5PhS1(u"࠶ੱ"),TWexH5PhS1(u"࠶ੱ"),TWexH5PhS1(u"࠶ੱ")
	all = jD3OnqZsTB0oF[N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡆࡒࡌࠨࢌ")]
	if N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬࢍ") in list(jD3OnqZsTB0oF.keys()): HJBWjkw5rylL = jD3OnqZsTB0oF[EEvLoMzFqrlKce(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ࢎ")]
	if ZEiR0StquOzca9lvPAndYIX(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ࢏") in list(jD3OnqZsTB0oF.keys()): WoZRIw81f2hmSuPUKMTyADH9E = jD3OnqZsTB0oF[HVibA2ES8lY(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ࢐")]
	if Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭࢑") in list(jD3OnqZsTB0oF.keys()): vv6JLpSqGzjkhTIOMd = jD3OnqZsTB0oF[FIHNSc5iuoZanQ2Ytl(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ࢒")]
	if VOq8Ekue4F(u"ࠫࡗࡋࡐࡐࡕࠪ࢓") in list(jD3OnqZsTB0oF.keys()): WGcvAqMLiaHnBwh6mltECYegX783 = jD3OnqZsTB0oF[ttOu147wErcBvPaSMUY(u"ࠬࡘࡅࡑࡑࡖࠫ࢔")]
	L9R8vDCIi7nByzX = all-HJBWjkw5rylL-WoZRIw81f2hmSuPUKMTyADH9E-vv6JLpSqGzjkhTIOMd-WGcvAqMLiaHnBwh6mltECYegX783
	O578ENGbr6PYnLJzi,R8BQvDJp2x3PyZcNLVwAUo5r = BtLG7DfwFSibPy0Xms4uRK1grc[vatyjK4hHAoZJ7rOq2lis(u"࠰ੲ")]
	O578ENGbr6PYnLJzi,NQO4sEAxvf1BrUbtdC5giMkq = BtLG7DfwFSibPy0Xms4uRK1grc[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲ੳ")]
	REyI93bfX81rBSCs = R8BQvDJp2x3PyZcNLVwAUo5r-NQO4sEAxvf1BrUbtdC5giMkq
	gWobv6rLVXFAKpC += weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ࢕")+str(NQO4sEAxvf1BrUbtdC5giMkq)+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢖")+l5mQdjWyczr7UJVnTp(u"ࠨษ็฽ิีࠠศๆะๆ๏่๊ࠡๆ็วัําสࠢ࠽ࠤࠬࢗ")
	gWobv6rLVXFAKpC += Xl3drKyI9HkDiPEf8RTjwu(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ࢘")+str(REyI93bfX81rBSCs)+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࢙ࠬ")+h5huy6MiXPNfQJF8(u"ࠫออำหะาห๊ࠦࡰࡳࡱࡻࡽࠥษ่ࠡࡸࡳࡲࠥࡀࠠࠨ࢚")
	gWobv6rLVXFAKpC += h5huy6MiXPNfQJF8(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࢛ࠪ")+str(R8BQvDJp2x3PyZcNLVwAUo5r)+mNkfJnpOrad7hT6PYyciwsSDQ(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ࢜")+oAXJCYqPgyGDtT(u"ࠧศๆ฼ำิࠦวๅๅ็๎๊ࠥฬๆ์฼ࠤฬ๊รอ้ีอࠥࡀࠠࠨ࢝")
	gWobv6rLVXFAKpC += vatyjK4hHAoZJ7rOq2lis(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭࢞")+str(len(BtLG7DfwFSibPy0Xms4uRK1grc[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴ੴ"):]))+sDiKwnHcSlYFgWCy1Ak(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ฽ิีࠠศๆา์้ࠦวๅฬํࠤๆ๐็ศࠢฦะ์ุษࠡ࠼ࠣࡠࡳࡢ࡮ࠨࢠ")
	for jOxCyaFu0HoKVPi425htBsvmgGJe,mXzxhH68tSFg in BtLG7DfwFSibPy0Xms4uRK1grc[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵ੵ"):]:
		jOxCyaFu0HoKVPi425htBsvmgGJe = Bd2o0J6aOASWvuD9HzY(jOxCyaFu0HoKVPi425htBsvmgGJe)
		jOxCyaFu0HoKVPi425htBsvmgGJe = jOxCyaFu0HoKVPi425htBsvmgGJe.strip(WmaPChRdQk3YcXwI6zS(u"ࠫࠥ࠭ࢡ")).strip(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࠦ࠮ࠨࢢ"))
		gWobv6rLVXFAKpC += jOxCyaFu0HoKVPi425htBsvmgGJe+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࢣ")+str(mXzxhH68tSFg)+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠬࢤ")
	Ckjw1bzUlAWvpEd += VOq8Ekue4F(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫࢥ")+str(L9R8vDCIi7nByzX)+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢦ")+HH4JMrUDp3lq6hQ(u"ࠪๅ๏ี๊้้สฮࠥอิห฼็ฮࠥࡀࠠࠨࢧ")
	Ckjw1bzUlAWvpEd += BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢨ")+str(HJBWjkw5rylL)+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢩ")+oAXJCYqPgyGDtT(u"࠭ืๅสสฮู๊ࠥาใิࠤออ๊ฬ๊้ࠤ࠿ࠦࠧࢪ")
	Ckjw1bzUlAWvpEd += N9olEh0ZMtpOivVfBLK(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢫ")+str(WGcvAqMLiaHnBwh6mltECYegX783)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢬ")+sbgu4D2RFMYKm(u"ฺ่ࠩออสࠡีํีๆืࠠศๆ่ืฯ๎ฯฺࠢ࠽ࠤࠬࢭ")
	Ckjw1bzUlAWvpEd += mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨࢮ")+str(WoZRIw81f2hmSuPUKMTyADH9E)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢯ")+oAXJCYqPgyGDtT(u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩࢰ")
	Ckjw1bzUlAWvpEd += vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫࢱ")+str(vv6JLpSqGzjkhTIOMd)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢲ")+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨฬฮฬ๏ะࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠿ࠦࠧࢳ")
	Ckjw1bzUlAWvpEd += EmK3ObA0cwv9Wy(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧࢴ")+str(len(nUe6JLwGms9V5P))+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢵ")+HH4JMrUDp3lq6hQ(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫࢶ")
	Ckjw1bzUlAWvpEd += WmaPChRdQk3YcXwI6zS(u"ࠬࡢ࡮࡝ࡰࠪࢷ")+ccLx9sNWQizTGalPOrvSdn
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(EEvLoMzFqrlKce(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ࢸ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ฺࠧัาࠤฬ๊รอ้ีอࠥอไห์ࠣหุะฮะ็อࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧࢹ"),gWobv6rLVXFAKpC,sbgu4D2RFMYKm(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࢺ"))
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢻ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫࢼ"),Ckjw1bzUlAWvpEd,l5mQdjWyczr7UJVnTp(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧࢽ"))
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(FIHNSc5iuoZanQ2Ytl(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬࢾ"),l5mQdjWyczr7UJVnTp(u"࠭ๅ้ษๅ฽ࠥอิห฼็ฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩࢿ"),fU2XgPWBisSyKM,FIHNSc5iuoZanQ2Ytl(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪࣀ"))
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࡮ࡨࡪࡹ࠭ࣁ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩฦ฽้๏ࠠศๆา์้ࠦวๅฬํࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡษึฮำีๅหࠢส่อืๆศ็ฯࠫࣂ"),yNXrMl0Q3w5uOIJZcizxKLC,ttOu147wErcBvPaSMUY(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫࣃ"))
	return
def JJsjzVfwAuW3y9cmh6BtikraECT():
	F67qZAgMjPukRfJ = FIHNSc5iuoZanQ2Ytl(u"ࠫ์ึวࠡษ็ฬึ์วๆฮࠣ๎฾๋ไࠡษไฺ้ࠦศศีอาิอๅࠡฮ็ำ้่ࠥะ์ࠣࠬࡐࡵࡤࡪࠢࡖ࡯࡮ࡴࠩࠡษ็ิ๏ࠦวิ็๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࡠࡳ่ࠦๆ็ๆ๊ࠥะหษ์อ๋ࠥฮวิฬัำฬ๋ࠠๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠠฤ๊ࠣฮา๋๊ๅ้้๋ࠣࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮࡝ࡰ๋ࠣีํࠠศๆิืฬ๊ษ๊ࠡ฽๎ึํวࠡๅฮ๎ึࠦๅ้ฮ๋ำฮࠦแ๋ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอ๋ࠢห้๋า๋ัࠣว๏฼วࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢฦะํฮษࠡษ็ฬึ์วๆฮࠪࣄ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬࣅ"),VOq8Ekue4F(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࣆ"),F67qZAgMjPukRfJ,PiFkQ5pCJy7fbX(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪࣇ"))
	return
def haHi7X9cIxTqslOg():
	F67qZAgMjPukRfJ = vatyjK4hHAoZJ7rOq2lis(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ࣈ")+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࡟ࡲࠬࣉ")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭࣊")+tOnYIHVk4xydqwoLEBKiDN0hX[mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ࣋")][ttOu147wErcBvPaSMUY(u"࠵੷")]+EEvLoMzFqrlKce(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠣࠤࠥษ่ࠡࠢࠣࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ࣌")+tOnYIHVk4xydqwoLEBKiDN0hX[EmK3ObA0cwv9Wy(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ࣍")][g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠵੶")]+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࣎")
	F67qZAgMjPukRfJ += QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࡞ࡱࡠࡳࡢ࡮ศๆิหอ฽ࠠฤั้ห์ࠦ็้ࠢสุ่๎ัิࠢส่ี๐๋ࠠฯอหัํࠠๆัํี๋ࠥไโษอࠤ่๎ฯ๋ࠢ็ฮะฮ๊หࠢหี๋อๅอࠢ฼้ฬีࠠษษ็฻ึ๐โสࠢส่ฯ่ไ๋ัํอࠥอไใัํ้ฮࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࣏ࠪ")+tOnYIHVk4xydqwoLEBKiDN0hX[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡖࡓ࡚ࡘࡃࡆࡕ࣐ࠪ")][l5mQdjWyczr7UJVnTp(u"࠷੸")]+Xl3drKyI9HkDiPEf8RTjwu(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡ࣑ࠬ")
	F67qZAgMjPukRfJ += ZhqJoOtcmTVID65HwnLj(u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํ࣒ࠧ")+ZhqJoOtcmTVID65HwnLj(u"ࠬࡢ࡮ࠨ࣓")+mNkfJnpOrad7hT6PYyciwsSDQ(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩࣔ")+tOnYIHVk4xydqwoLEBKiDN0hX[sbgu4D2RFMYKm(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨࣕ")][cbngtp9sqYi0DjeEMLRHJruKxm(u"࠲੹")]+f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣖ")
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࡦࡩࡳࡺࡥࡳࠩࣗ"),vatyjK4hHAoZJ7rOq2lis(u"ࠪห้๋่ศไ฼ࠤฬ๊ัิ็ํอ๊ࠥศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩࣘ"),F67qZAgMjPukRfJ,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧࣙ"))
	return
def W4xJfvuEX9b1D(MFcaDxLkKOPh6fi1ETo57):
	EO9Rts0AaGuk1qpPLXCY.executebuiltin(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫࠫࣚ")+MFcaDxLkKOPh6fi1ETo57+HH4JMrUDp3lq6hQ(u"࠭ࠩࠨࣛ"), ZEiR0StquOzca9lvPAndYIX(u"ࡗࡶࡺ࡫઻"))
	return
def ZERUfKJBIvbeq03DoCSz():
	inrDtz8mJqLpkPSldeyYjsEaBwA(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡴࡶࡲࡴࠬࣜ"))
	EO9Rts0AaGuk1qpPLXCY.executebuiltin(oAXJCYqPgyGDtT(u"ࠣࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡌࡲࡹ࡫ࡲࡧࡣࡦࡩࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠯ࠢࣝ"))
	return
def zzQtMflsiw():
	EO9Rts0AaGuk1qpPLXCY.executebuiltin(HH4JMrUDp3lq6hQ(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠩࠨࣞ"), uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡘࡷࡻࡥ઼"))
	return
def ABhni7W3m2u8IFYT1blE(showDialogs):
	if not showDialogs: VjwKs4GNQZ518kCl = ZhqJoOtcmTVID65HwnLj(u"࡙ࡸࡵࡦઽ")
	else: VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡧࡪࡴࡴࡦࡴࠪࣟ"),FIHNSc5iuoZanQ2Ytl(u"ࠫࠬ࣠"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࠭࣡"),HVibA2ES8lY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࣢"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣฬ฾๋ไ๋หࠣฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢอ่็อฦ๋ษࠣ็้ࠦ࠲࠵ࠢึห฾ฯ้ࠠๆๆ๊๋ࠥๅไ่ࠣษัืวย้สࠤฬ๊ย็ࠢ࠱ࠤ์๊ࠠหำํำࠥะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠศๆล๊ࠥลࣣࠧ"))
	if VjwKs4GNQZ518kCl==g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲੺"):
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(l5mQdjWyczr7UJVnTp(u"ࠨࡗࡳࡨࡦࡺࡥࡂࡦࡧࡳࡳࡘࡥࡱࡱࡶࠫࣤ"))
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(N9olEh0ZMtpOivVfBLK(u"ࠩࠪࣥ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࣦࠪࠫ"),TWexH5PhS1(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣧ"),EEvLoMzFqrlKce(u"ࠬะๅࠡวิืฬุ๊ࠠๆหࠤส๊้ࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦวๅาํࠤๆ๐ࠠอ้สึ่ࠦไไ์ࠣ๎็๎ๅࠡสอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤ࠳ࠦศๆษࠣๅ๏ํวࠡฬะำ๏ั่ࠠาสࠤฬ๊ศา่ส้ั่ࠦหฯา๎ะࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳๊ࠦาฮ์ࠤส฿ืศรࠣ็ํี๊ࠡ࠷ࠣำ็อฦใࠢฦ์ࠥษใฬำ่่ࠣ๐๋่๊ࠠ๎ࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠬࣨ"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(ZhqJoOtcmTVID65HwnLj(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࣩࠪ"))
	return
def eOmTpqsU3KZLxMk2yDPJHz58Ri():
	KK47FGdX1TDfkb3AjHOQqghE(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠨ࣪"),ZhqJoOtcmTVID65HwnLj(u"ࠨࠩ࣫"),WmaPChRdQk3YcXwI6zS(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࣬"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ู่๊ࠪอࠡ็ะฮํ๐วหࠢๅหห๋ษࠡ࠰ࠣหีํศࠡว็ํࠥอไใษษ้ฮࠦวๅฬํࠤฯื๊ะ่ࠢืาํว๊ࠡ็หࠥะฯฯๆࠣษ้๐็ศ๋่่ࠢ์ࠠษษึฮำีวๆࠢࠥห้๋ว้ีࠥࠤศ๎ࠠࠣษ็ี๏๋่หࠤࠣห฻เืࠡ฻็ํࠥอไำำࠣะ์ฯࠠศๆํ้๏์ࠠฤ๊ࠣหุะฮะ็ࠣࠦฬ๊ใ๋ส๋ีิࠨ้ࠠษู฾฼ูࠦๅ๋ࠣัึ็ࠠࠣࡅࠥࠤศ๎ฺࠠๆ์ࠤฬ฼ฺุࠢ฼่๎ࠦาาࠢࠥห้่วว็ฬࠦࠥอไั์ࠣๅ๏ࠦฬ่หࠣห้๐ๅ๋่࣭ࠪ"))
	return
def uKTvYFsa6z():
	KK47FGdX1TDfkb3AjHOQqghE(vatyjK4hHAoZJ7rOq2lis(u"࣮ࠫࠬ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࣯ࠬ࠭"),HVibA2ES8lY(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࣰࠩ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧๅๆอ฽ฬ๋ไࠡ็฼ࠤฬ๊ๅโุ็อࠥ࠴ࠠศา๊ฬࠥหไ๊ࠢส่ึอศุࠢส่ี๐ࠠหำํำࠥหึศใอ๋ࠥษ่ࠡ็ึั์ࠦๅ็ࠢࠣๆฬฬๅสࠢส่๊็ึๅหࠣ์้้ๆࠡๆสࠤฯ์โาࠢ฼่๏ํ้ࠠๆสࠤฯฺฺๅ้ࠣ࠲ࠥ๎ศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊ࠡฦ้ฬࠦศศีอาิอๅࠡࠤส่่๐ศ้ำาࠦࠥ็วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋ࠦ࠮๊้ࠡๅุࠦวๅๅ็ห๊่ࠦศๆฺี๏่ษࠡ฻้ำࠥอไห฻ส้้ࠦๅฺ่ࠢัฯ๎๊ศฬࠣๆํอฦๆࠢส่๊็ึๅหࣱࠪ"))
	return
def woiPZbJMcS2Ee3D(showDialogs=l5mQdjWyczr7UJVnTp(u"࡚ࡲࡶࡧા")):
	OOCF4oyqAlkw2jKGdrLJz7Ei = [HVibA2ES8lY(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࣲࠪ"),vatyjK4hHAoZJ7rOq2lis(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪࣳ"),l5mQdjWyczr7UJVnTp(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭ࣴ"),l5mQdjWyczr7UJVnTp(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭ࣵ"),oAXJCYqPgyGDtT(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦࣶ࠭"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪࣷ")]
	IQF2itGZEHPo0vRK3VwTLyqW5nljmp = OOCF4oyqAlkw2jKGdrLJz7Ei+[HVibA2ES8lY(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࣸ"),EEvLoMzFqrlKce(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸࣹ࠭"),HVibA2ES8lY(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨࣺ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩࣻ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡸࡱࡩ࡯࠰ࡳ࡬ࡪࡴ࡯࡮ࡧࡱࡥࡱࡋࡍࡂࡆࠪࣼ"),ZhqJoOtcmTVID65HwnLj(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩࣽ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪࣾ")]
	VXp2ouLAg5Mz8jct1hf6m = tnmgjKPYByiL0q([h5huy6MiXPNfQJF8(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩࣿ")])
	ZUVD3oP9AfxGNR5CtvdXy07He = []
	for x7NwSuz5ft4e in [vatyjK4hHAoZJ7rOq2lis(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪऀ")]:
		if x7NwSuz5ft4e not in list(VXp2ouLAg5Mz8jct1hf6m.keys()): continue
		PgjqxZL23vFVYUfDe7RBOrS5n,h2ldCUQZJ74k6EjrPLo,zPaNi29AO6sU,hIwRXGs92bEOS4AUMiD,XNmE8qVa2Li56x3hIdtv,C0CEPae4ID,RRYUotMfpSxKd4QnyFi = VXp2ouLAg5Mz8jct1hf6m[x7NwSuz5ft4e]
		if not h2ldCUQZJ74k6EjrPLo or (h2ldCUQZJ74k6EjrPLo and PgjqxZL23vFVYUfDe7RBOrS5n): ZUVD3oP9AfxGNR5CtvdXy07He.append(x7NwSuz5ft4e)
	TilmEsrF4xZG3k2XPo = len(ZUVD3oP9AfxGNR5CtvdXy07He)>WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠲੻")
	kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(n3xWSEN58XZl9eFydUmCfs2ArH)
	kC7JunVyQdExXTaB.text_factory = str
	SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
	UIKCn7mg8Oz1PRZoWlsS = []
	for x7NwSuz5ft4e in OOCF4oyqAlkw2jKGdrLJz7Ei:
		SCnhp2blgkLJrvcqKmXdE.execute(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡪࡴࡡࡣ࡮ࡨࡨࠥࡃࠠࠣ࠳ࠥࠤࡦࡴࡤࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ँ")+x7NwSuz5ft4e+sDiKwnHcSlYFgWCy1Ak(u"ࠪࠦࠥࡁࠧं"))
		UNrkdT39f5 = SCnhp2blgkLJrvcqKmXdE.fetchall()
		if UNrkdT39f5: UIKCn7mg8Oz1PRZoWlsS.append(x7NwSuz5ft4e)
	AFVuJgmHnKt4bSrP6M03Y7a = len(UIKCn7mg8Oz1PRZoWlsS)>S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠳੼")
	for x7NwSuz5ft4e in IQF2itGZEHPo0vRK3VwTLyqW5nljmp:
		SCnhp2blgkLJrvcqKmXdE.execute(sDiKwnHcSlYFgWCy1Ak(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩः")+x7NwSuz5ft4e+N9olEh0ZMtpOivVfBLK(u"ࠬࠨࠠ࠼ࠩऄ"))
		KA68g2rMQIWuSJ5zODHLN = SCnhp2blgkLJrvcqKmXdE.fetchall()
		if KA68g2rMQIWuSJ5zODHLN and oAXJCYqPgyGDtT(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨअ") not in str(KA68g2rMQIWuSJ5zODHLN): ZUVD3oP9AfxGNR5CtvdXy07He.append(x7NwSuz5ft4e)
	uwDYU2164dBelr5o = len(ZUVD3oP9AfxGNR5CtvdXy07He)>h5huy6MiXPNfQJF8(u"࠴੽")
	ZUVD3oP9AfxGNR5CtvdXy07He = list(set(ZUVD3oP9AfxGNR5CtvdXy07He))
	kC7JunVyQdExXTaB.close()
	PgjqxZL23vFVYUfDe7RBOrS5n = Xl3drKyI9HkDiPEf8RTjwu(u"ࡆࡢ࡮ࡶࡩિ")
	if AFVuJgmHnKt4bSrP6M03Y7a or uwDYU2164dBelr5o:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(sbgu4D2RFMYKm(u"ࠧࡤࡧࡱࡸࡪࡸࠧआ"),ZEiR0StquOzca9lvPAndYIX(u"ࠨࠩइ"),VOq8Ekue4F(u"ࠩࠪई"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭उ"),VOq8Ekue4F(u"ࠫฬ๊ศา่ส้ั่ࠦอัู้้ࠣไสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣวํࠦๅีๅ็อࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠣࡠࡳࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢส่ว์ࠠภ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪऊ"))
		if VjwKs4GNQZ518kCl==ZhqJoOtcmTVID65HwnLj(u"࠶੾"):
			HjZnSg2zBd0ka5uQUDItl8Eph = HVibA2ES8lY(u"ࡕࡴࡸࡩી")
			if TilmEsrF4xZG3k2XPo:
				HjZnSg2zBd0ka5uQUDItl8Eph = TslhbYQgjWKB4GkneMc(ZhqJoOtcmTVID65HwnLj(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧऋ"),l5mQdjWyczr7UJVnTp(u"ࡈࡤࡰࡸ࡫ુ"),l5mQdjWyczr7UJVnTp(u"ࡈࡤࡰࡸ࡫ુ"))
			E41slhvMob3r = HH4JMrUDp3lq6hQ(u"ࡗࡶࡺ࡫ૂ")
			if AFVuJgmHnKt4bSrP6M03Y7a:
				for x7NwSuz5ft4e in UIKCn7mg8Oz1PRZoWlsS: wwVx6hRf2Uy9oStgdXb(x7NwSuz5ft4e)
				E41slhvMob3r = HVibA2ES8lY(u"ࡘࡷࡻࡥૃ")
			SYf7i3o9xsVzZ = oAXJCYqPgyGDtT(u"࡙ࡸࡵࡦૄ")
			if uwDYU2164dBelr5o:
				kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(n3xWSEN58XZl9eFydUmCfs2ArH)
				kC7JunVyQdExXTaB.text_factory = str
				SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
				for x7NwSuz5ft4e in ZUVD3oP9AfxGNR5CtvdXy07He:
					if WmaPChRdQk3YcXwI6zS(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࠩऌ") in x7NwSuz5ft4e: KA68g2rMQIWuSJ5zODHLN = x7NwSuz5ft4e
					else: KA68g2rMQIWuSJ5zODHLN = f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩऍ")
					try: SCnhp2blgkLJrvcqKmXdE.execute(VH9MDo5z1kxNF07uRJI(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡘࡋࡔࠡࡱࡵ࡭࡬࡯࡮ࠡ࠿ࠣࠦࠬऎ")+KA68g2rMQIWuSJ5zODHLN+FIHNSc5iuoZanQ2Ytl(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨए")+x7NwSuz5ft4e+HH4JMrUDp3lq6hQ(u"ࠪࠦࠥࡁࠧऐ"))
					except: SYf7i3o9xsVzZ = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡌࡡ࡭ࡵࡨૅ")
				kC7JunVyQdExXTaB.commit()
				kC7JunVyQdExXTaB.close()
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(VH9MDo5z1kxNF07uRJI(u"࠷੿"))
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(cbngtp9sqYi0DjeEMLRHJruKxm(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨऑ"))
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠱઀"))
			if HjZnSg2zBd0ka5uQUDItl8Eph or E41slhvMob3r or SYf7i3o9xsVzZ:
				PgjqxZL23vFVYUfDe7RBOrS5n = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡆࡢ࡮ࡶࡩ૆")
				KK47FGdX1TDfkb3AjHOQqghE(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࠭ऒ"),EEvLoMzFqrlKce(u"࠭ࠧओ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪऔ"),EEvLoMzFqrlKce(u"ࠨฮํำࠥ࠴࠮ࠡฬ่ࠤอ์ฬศฯࠣฮๆ฿๊ๅ๋ࠢษฺ๊วฮࠢสู่๊ส้ั฼ࠤํอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆฯ้๏฿ࠠฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬक"))
			else:
				PgjqxZL23vFVYUfDe7RBOrS5n = vatyjK4hHAoZJ7rOq2lis(u"ࡕࡴࡸࡩે")
				KK47FGdX1TDfkb3AjHOQqghE(TWexH5PhS1(u"ࠩࠪख"),ZhqJoOtcmTVID65HwnLj(u"ࠪࠫग"),ZhqJoOtcmTVID65HwnLj(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧघ"),EEvLoMzFqrlKce(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤส฻ไศฯุ้ࠣะ่ะ฻ࠣ฽๊อฯ๊ࠡศู้ออࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪङ"))
	elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࠧच"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࠨछ"),HVibA2ES8lY(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫज"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็ื็้ฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡล๋ࠤๆ๐ࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣส฼วโษอࠤอืๆศ็ฯࠤ฾๋วะࠩझ"))
	return PgjqxZL23vFVYUfDe7RBOrS5n
def DclrfqpKCeS8tMy9B():
	GDki7Y1cRoTe64Hn2CEI,TsrukAfnY9y,qofBCEl1keRGDyXHmt2bO6 = WmaPChRdQk3YcXwI6zS(u"ࡈࡤࡰࡸ࡫ૈ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࠫञ"),FIHNSc5iuoZanQ2Ytl(u"ࠫࠬट")
	x0rTDfIwnhH,B64q5XFSwOhsAlCZWIRv,pcmEGTkuRoq0MBiz = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࡉࡥࡱࡹࡥૉ"),EmK3ObA0cwv9Wy(u"ࠬ࠭ठ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࠧड")
	S4SlZukyYG0AhmvOUoTWDBwrc9d = [TWexH5PhS1(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬढ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧण"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫत"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩथ")]
	VXp2ouLAg5Mz8jct1hf6m = tnmgjKPYByiL0q(S4SlZukyYG0AhmvOUoTWDBwrc9d)
	for x7NwSuz5ft4e in S4SlZukyYG0AhmvOUoTWDBwrc9d:
		if x7NwSuz5ft4e not in list(VXp2ouLAg5Mz8jct1hf6m.keys()): continue
		PgjqxZL23vFVYUfDe7RBOrS5n,h2ldCUQZJ74k6EjrPLo,VoCapUKBIz3YWw8,NvPW3YMhR1zZkFtHKOQBipy0wTrxb7,M2uhU3GIW8jwJazHO,NgH1U80knyI2P,uckGrZOIv6HxD2ytjNWsXdm = VXp2ouLAg5Mz8jct1hf6m[x7NwSuz5ft4e]
		if x7NwSuz5ft4e==TWexH5PhS1(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩद"):
			x0rTDfIwnhH = PgjqxZL23vFVYUfDe7RBOrS5n
			B64q5XFSwOhsAlCZWIRv = EEvLoMzFqrlKce(u"ࠬ࠮ࠧध")+h2ldCUQZJ74k6EjrPLo+vatyjK4hHAoZJ7rOq2lis(u"࠭ࠠࠨन")+hqWB0vmTcxR8d3oukL(NgH1U80knyI2P)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠪࠩऩ")
			pcmEGTkuRoq0MBiz = NvPW3YMhR1zZkFtHKOQBipy0wTrxb7
		elif x7NwSuz5ft4e==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪप"):
			GDki7Y1cRoTe64Hn2CEI = GDki7Y1cRoTe64Hn2CEI or PgjqxZL23vFVYUfDe7RBOrS5n
			TsrukAfnY9y += N9olEh0ZMtpOivVfBLK(u"ࠩࠣࠤ࠱ࠦࠠࠩࠩफ")+h2ldCUQZJ74k6EjrPLo+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࠤࠬब")+hqWB0vmTcxR8d3oukL(NgH1U80knyI2P)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠫ࠮࠭भ")
			qofBCEl1keRGDyXHmt2bO6 += VH9MDo5z1kxNF07uRJI(u"ࠬࠦࠠ࠭ࠢࠣࠫम")+NvPW3YMhR1zZkFtHKOQBipy0wTrxb7
		elif x7NwSuz5ft4e==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬय"):
			JX4EcF2bGkVDASuft = PgjqxZL23vFVYUfDe7RBOrS5n
			WIvk0ay7g1ZPiudAz4MxmsUC = EEvLoMzFqrlKce(u"ࠧࠩࠩर")+h2ldCUQZJ74k6EjrPLo+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࠢࠪऱ")+hqWB0vmTcxR8d3oukL(NgH1U80knyI2P)+l5mQdjWyczr7UJVnTp(u"ࠩࠬࠫल")
			HHFdJCBPX8tRk02 = NvPW3YMhR1zZkFtHKOQBipy0wTrxb7
	TsrukAfnY9y = TsrukAfnY9y.strip(EEvLoMzFqrlKce(u"ࠪࠤࠥ࠲ࠠࠡࠩळ"))
	qofBCEl1keRGDyXHmt2bO6 = qofBCEl1keRGDyXHmt2bO6.strip(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࠥࠦࠬࠡࠢࠪऴ"))
	UW0e2HGDvj  = vatyjK4hHAoZJ7rOq2lis(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬव")+pcmEGTkuRoq0MBiz+HVibA2ES8lY(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨश")
	UW0e2HGDvj += EmK3ObA0cwv9Wy(u"ࠧ࡝ࡰࠪष")+sDiKwnHcSlYFgWCy1Ak(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣอืๆศ็ฯࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬस")+B64q5XFSwOhsAlCZWIRv+TWexH5PhS1(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫह")
	UW0e2HGDvj += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡠࡳࡢ࡮ࠨऺ")+WmaPChRdQk3YcXwI6zS(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำู่๊ࠣส้ั฼ࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫऻ")+qofBCEl1keRGDyXHmt2bO6+ZhqJoOtcmTVID65HwnLj(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ़ࠧ")
	UW0e2HGDvj += EEvLoMzFqrlKce(u"࠭࡜࡯ࠩऽ")+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ุ้ะ่ะ฻ࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫा")+TsrukAfnY9y+TWexH5PhS1(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪि")
	UW0e2HGDvj += sDiKwnHcSlYFgWCy1Ak(u"ࠩ࡟ࡲࡡࡴࠧी")+l5mQdjWyczr7UJVnTp(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩु")+HHFdJCBPX8tRk02+TWexH5PhS1(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ू")
	UW0e2HGDvj += WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬࡢ࡮ࠨृ")+h5huy6MiXPNfQJF8(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩॄ")+WIvk0ay7g1ZPiudAz4MxmsUC+HH4JMrUDp3lq6hQ(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॅ")
	PgjqxZL23vFVYUfDe7RBOrS5n = (x0rTDfIwnhH or GDki7Y1cRoTe64Hn2CEI)
	if PgjqxZL23vFVYUfDe7RBOrS5n:
		header = l5mQdjWyczr7UJVnTp(u"ࠨษ็ีัอมࠡฬะำ๏ัࠠฦุสๅฬะࠠไ๊า๎๊ࠥอๅࠢสฺ่๊วไๆࠪॆ")
		Xl5KI3hzio8QvZVySd0RcDsnM4 = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩส๊ฯࠦศฮษฯอ๊ࠥสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣวํࠦสฮัํฯ๋ࠥำห๊า฽ࠥ฿ๅศัࠪे")
	else:
		header = HH4JMrUDp3lq6hQ(u"ࠪัฬ๊๊ศࠢ็หࠥ๐่อัࠣฮาี๊ฬษอࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣวํࠦๅิฬ๋ำ฾ูࠦๆษาࠫै")
		Xl5KI3hzio8QvZVySd0RcDsnM4 = oAXJCYqPgyGDtT(u"ࠫฬ๊ัอษฤࠤสฮไศ฼ࠣห้๋ศา็ฯࠤ฾์ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦส้ษฯ๋่࠭ॉ")
	xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3 = N9olEh0ZMtpOivVfBLK(u"๊ࠬใ๋ࠢํ฽ฺ๊๊่ࠠา็ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡ์ฯฬࠥษๆࠡ์ๆ์๋ࠦไะ์ๆࠤๆ๐ࠠไ๊า๎ࡡࡴๅิฬ๋ำ฾ูࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠭ॊ")
	wwKgAeurE84hojczWYUiHF = UW0e2HGDvj+l5mQdjWyczr7UJVnTp(u"࠭࡜࡯࡞ࡱࠫो")+Xl5KI3hzio8QvZVySd0RcDsnM4+ZEiR0StquOzca9lvPAndYIX(u"ࠧ࡝ࡰ࡟ࡲࠬौ")+xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3
	WWZfqplYBUhn6oxiXOmCe24bI0RA9(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡴ࡬࡫࡭ࡺ्ࠧ"),header,wwKgAeurE84hojczWYUiHF,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬॎ"))
	return
def GT8XWZULDtz7sYlhIfVnE12rOK(showDialogs,PtAgyCewKU7Wl4NH1fERYIs5jmx):
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,ZEiR0StquOzca9lvPAndYIX(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ॏ"),HVibA2ES8lY(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬॐ"))
	if showDialogs:
		DclrfqpKCeS8tMy9B()
		wkuBsGxyVEvdYgFWARDN7()
	if PtAgyCewKU7Wl4NH1fERYIs5jmx:
		woiPZbJMcS2Ee3D(ttOu147wErcBvPaSMUY(u"ࡊࡦࡲࡳࡦ૊"))
		s5swfZIAXgNxvu1k6yqFEQhC4MtWze = [Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ॑"),WmaPChRdQk3YcXwI6zS(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ॒ࠬ"),TWexH5PhS1(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ॓"),VH9MDo5z1kxNF07uRJI(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ॔"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭ॕ")]
		for o982knwuHAUhIdFGsYcqmjNS in s5swfZIAXgNxvu1k6yqFEQhC4MtWze:
			UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH,h2ldCUQZJ74k6EjrPLo = TslhbYQgjWKB4GkneMc(o982knwuHAUhIdFGsYcqmjNS,l5mQdjWyczr7UJVnTp(u"࡚ࡲࡶࡧૌ"),ZhqJoOtcmTVID65HwnLj(u"ࡋࡧ࡬ࡴࡧો"))
		ABhni7W3m2u8IFYT1blE(showDialogs)
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧॖ"))
	return
def dVRNUoSrXi8HlKp4zmgqc9(XZhdFMWQ1kfDiJPqVHO=EmK3ObA0cwv9Wy(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪॗ"),showDialogs=sbgu4D2RFMYKm(u"ࡔࡳࡷࡨ્")):
	yPYItiEgxhwB9TmWN6cAU = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(VH9MDo5z1kxNF07uRJI(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨक़"))
	import json as ZcJHDYM7OuKkIhBVSzoxgjp8r
	data = ZcJHDYM7OuKkIhBVSzoxgjp8r.loads(yPYItiEgxhwB9TmWN6cAU)
	rMFeZRE9VtaHqAlUzs = data[TWexH5PhS1(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ख़")][g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡷࡣ࡯ࡹࡪ࠭ग़")]
	if ggl6zFuXNdYTDieHCqGKRnVx: rMFeZRE9VtaHqAlUzs = rMFeZRE9VtaHqAlUzs.encode(EmK3ObA0cwv9Wy(u"ࠨࡷࡷࡪ࠽࠭ज़"))
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(VOq8Ekue4F(u"ࠩࠪड़"),ZhqJoOtcmTVID65HwnLj(u"ࠪࠫढ़"),TWexH5PhS1(u"ࠫࠬफ़"),VH9MDo5z1kxNF07uRJI(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨय़"),N9olEh0ZMtpOivVfBLK(u"࠭็ๅࠢอี๏ีࠠห฼ํ๎ึࠦฬๅัࠣࠫॠ")+rMFeZRE9VtaHqAlUzs+ZhqJoOtcmTVID65HwnLj(u"ࠧࠡษ็ิ๏ࠦๅิฬัำ๊ࠦวๅฤ้ࠤๆ๐ࠠไ๊า๎ࠥหไ๊ࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡࠩॡ")+XZhdFMWQ1kfDiJPqVHO+PiFkQ5pCJy7fbX(u"ࠨࠢยࠥࠬॢ"))
		if VjwKs4GNQZ518kCl!=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲ઁ"): return g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡇࡣ࡯ࡷࡪ૎")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH,AQqfryVGeTiIdBFkhDgZR7u3 = TslhbYQgjWKB4GkneMc(XZhdFMWQ1kfDiJPqVHO,oAXJCYqPgyGDtT(u"ࡈࡤࡰࡸ࡫૏"),oAXJCYqPgyGDtT(u"ࡈࡤࡰࡸ࡫૏"))
	if UkYj1KP0ou4q9rVfEgn2JQHI56BG:
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࠪॣ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠫ।"),HVibA2ES8lY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ॥"),TWexH5PhS1(u"ࠬะๅหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆฯ่ิࠦวๅฮา๎ิ่่๊ࠦࠣะฬําࠡๆ็หุะฮะษ่ࠤ࠳ࠦำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥะฺ๋์ิࠤส฿ฯศัสฮ้่ࠥะ์่่ࠣ๐๋ࠠีอ฽๊๊ࠠศๆฯ่ิࠦวๅฮา๎ิࠦศะๆสࠤ๊์ࠠศๆๅำ๏๋ࠧ०"))
		hrgtXiSNu72 = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(EEvLoMzFqrlKce(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡔࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠤࠪ१")+XZhdFMWQ1kfDiJPqVHO+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠣࡿࢀࠫ२"))
		if uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡑࡎࠫ३") in hrgtXiSNu72: UkYj1KP0ou4q9rVfEgn2JQHI56BG = h5huy6MiXPNfQJF8(u"ࡗࡶࡺ࡫ૐ")
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠳ં"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(EEvLoMzFqrlKce(u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩ४"))
	elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(VH9MDo5z1kxNF07uRJI(u"ࠪࠫ५"),l5mQdjWyczr7UJVnTp(u"ࠫࠬ६"),N9olEh0ZMtpOivVfBLK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ७"),ttOu147wErcBvPaSMUY(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡษ็ะ้ีࠠศๆ่฻้๎ศࠨ८"))
	return UkYj1KP0ou4q9rVfEgn2JQHI56BG
def PKyL2wI9WdZEbzs4t5muq(x7NwSuz5ft4e,showDialogs=h5huy6MiXPNfQJF8(u"ࡘࡷࡻࡥ૑")):
	if showDialogs==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨ९"): showDialogs = VH9MDo5z1kxNF07uRJI(u"࡙ࡸࡵࡦ૒")
	rs4JmUMwkF7cCRAItLhp9i = IYGBRJjmO6n([x7NwSuz5ft4e])
	WqwuGUjxHnz6cr4SL7mT5A,UUT3znrMvS6FxwHfKIuOo7kR9ELg = rs4JmUMwkF7cCRAItLhp9i[x7NwSuz5ft4e]
	if UUT3znrMvS6FxwHfKIuOo7kR9ELg:
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࡚ࡲࡶࡧ૓")
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࠩ॰"),TWexH5PhS1(u"ࠩࠪॱ"),VOq8Ekue4F(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ॲ"),ZhqJoOtcmTVID65HwnLj(u"ࠫๆำีࠡษ็ษ฻อแสࠢ࡟ࡲࠥ࠭ॳ")+x7NwSuz5ft4e+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࠦ࡜࡯๊ࠢิ์ࠦรๅวูหๆฯฺ่ࠠา็๋่ࠥอ๊าอࠥ๎ๅโ฻็อࠥ๎ฬศ้ีอ๊ࠥไศีอาิอๅࠨॴ"))
	else:
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡆࡢ࡮ࡶࡩ૔")
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(vatyjK4hHAoZJ7rOq2lis(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ॵ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࠨॶ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࠩॷ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬॸ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࠫॹ")+x7NwSuz5ft4e+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ฿๐ัࠡ็ไ฽้ฯࠠฤ๊ࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠ࠯ࠢํะอࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศࠢ็็๏ฺ๊ࠦ็็ࠤฬ๊ศา่ส้ัูࠦ็ัๆࠤอ฻่าหูࠣา๐อสࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩॺ"))
		if VjwKs4GNQZ518kCl==Xl3drKyI9HkDiPEf8RTjwu(u"࠴ઃ"):
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(VOq8Ekue4F(u"ࠬࡏ࡮ࡴࡶࡤࡰࡱࡇࡤࡥࡱࡱࠬࠬॻ")+x7NwSuz5ft4e+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠩࠨॼ"))
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠵઄"))
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(TWexH5PhS1(u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧॽ"))
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(ZEiR0StquOzca9lvPAndYIX(u"࠶અ"))
			while EO9Rts0AaGuk1qpPLXCY.getCondVisibility(Xl3drKyI9HkDiPEf8RTjwu(u"ࠨ࡙࡬ࡲࡩࡵࡷ࠯ࡋࡶࡅࡨࡺࡩࡷࡧࠫࡴࡷࡵࡧࡳࡧࡶࡷࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬॾ")): D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(EEvLoMzFqrlKce(u"࠷આ"))
			hrgtXiSNu72 = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬॿ")+x7NwSuz5ft4e+h5huy6MiXPNfQJF8(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨঀ"))
			if uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡔࡑࠧঁ") in hrgtXiSNu72:
				UkYj1KP0ou4q9rVfEgn2JQHI56BG = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡕࡴࡸࡩ૕")
				if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(VOq8Ekue4F(u"ࠬ࠭ং"),VOq8Ekue4F(u"࠭ࠧঃ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ঄"),sbgu4D2RFMYKm(u"ࠨฬ่ࠤๆำีࠡล๋ࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ์์๐ࠠศๆล๊ࠥาว่ิฬࠤ้๊วิฬัำฬ๋ࠧঅ"))
			elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࠪআ"),sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫই"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧঈ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ็ิๅࠢไ๎ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ࠳่ࠦศๆะ่ࠥํ่ࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ๊์ࠠฯษิะࠥอไษำ้ห๊าࠧউ"))
	return UkYj1KP0ou4q9rVfEgn2JQHI56BG
def NNTELmoz5GBWf(x7NwSuz5ft4e,uckGrZOIv6HxD2ytjNWsXdm,showDialogs):
	UkYj1KP0ou4q9rVfEgn2JQHI56BG = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡈࡤࡰࡸ࡫૖")
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(VOq8Ekue4F(u"࠭ࠧঊ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨঋ"),h5huy6MiXPNfQJF8(u"ࠨࠩঌ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ঍"),oAXJCYqPgyGDtT(u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆุ฽์฼ࠦไๅวูหๆฯࠠศๆ่฻้๎ศสࠢ็็๏๊ࠦห็ࠣฮะฮ๊ห้ࠣ฽้๏ࠠไ๊า๎ࠥ࠴ࠠศๆ่่ๆࠦโะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥอไร่ࠣรࠦ࠭঎"))
		if VjwKs4GNQZ518kCl!=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠱ઇ"): return TWexH5PhS1(u"ࡉࡥࡱࡹࡥ૗")
	xzAqZMdT06f = de5ZW2bFQ64CPgG(uckGrZOIv6HxD2ytjNWsXdm,{},showDialogs)
	if xzAqZMdT06f:
		EQNv8ODh6mcjpsgWU = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(yyJSUbRVMEdCABecYH8F,x7NwSuz5ft4e)
		P8vtuTghFN7lWIS(EQNv8ODh6mcjpsgWU,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࡙ࡸࡵࡦ૙"),ZhqJoOtcmTVID65HwnLj(u"ࡊࡦࡲࡳࡦ૘"))
		import zipfile as Iv6aub4pOxNld8h9neE2CUyBmXsF,io as bvFkaIMne5x0hzHUAGqYOpCy
		TUBEfXpvrYWC = bvFkaIMne5x0hzHUAGqYOpCy.BytesIO(xzAqZMdT06f)
		try:
			D14REP7CW0B6Zm2kjMV3hlU5ueIL = Iv6aub4pOxNld8h9neE2CUyBmXsF.ZipFile(TUBEfXpvrYWC)
			D14REP7CW0B6Zm2kjMV3hlU5ueIL.extractall(yyJSUbRVMEdCABecYH8F)
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(ttOu147wErcBvPaSMUY(u"࠲ઈ"))
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(f5uqIoSJzWBOFyrY78RXmVb(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨএ"))
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(FIHNSc5iuoZanQ2Ytl(u"࠴ઉ"))
			hrgtXiSNu72 = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(sbgu4D2RFMYKm(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨঐ")+x7NwSuz5ft4e+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ঑"))
			if mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡐࡍࠪ঒") in hrgtXiSNu72: UkYj1KP0ou4q9rVfEgn2JQHI56BG = sDiKwnHcSlYFgWCy1Ak(u"࡚ࡲࡶࡧ૚")
			Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,HH4JMrUDp3lq6hQ(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫও"),EmK3ObA0cwv9Wy(u"ࠩࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪঔ"))
		except: UkYj1KP0ou4q9rVfEgn2JQHI56BG = WmaPChRdQk3YcXwI6zS(u"ࡆࡢ࡮ࡶࡩ૛")
	if showDialogs:
		if UkYj1KP0ou4q9rVfEgn2JQHI56BG: KK47FGdX1TDfkb3AjHOQqghE(sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫক"),sbgu4D2RFMYKm(u"ࠫࠬখ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨগ"),EEvLoMzFqrlKce(u"࠭สๆࠢห๊ัออࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪঘ"))
		else: KK47FGdX1TDfkb3AjHOQqghE(ZEiR0StquOzca9lvPAndYIX(u"ࠧࠨঙ"),EEvLoMzFqrlKce(u"ࠨࠩচ"),PiFkQ5pCJy7fbX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬছ"),HH4JMrUDp3lq6hQ(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨজ"))
	return UkYj1KP0ou4q9rVfEgn2JQHI56BG
def TslhbYQgjWKB4GkneMc(x7NwSuz5ft4e,showDialogs,jHiJrUxn0wRpIQKWtCLSydo934cMGe):
	VjwKs4GNQZ518kCl,UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH,h2ldCUQZJ74k6EjrPLo = PiFkQ5pCJy7fbX(u"ࡖࡵࡹࡪ૝"),ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪ૜"),vatyjK4hHAoZJ7rOq2lis(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫঝ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬ࠭ঞ")
	VXp2ouLAg5Mz8jct1hf6m = tnmgjKPYByiL0q([x7NwSuz5ft4e])
	if x7NwSuz5ft4e in list(VXp2ouLAg5Mz8jct1hf6m.keys()):
		PgjqxZL23vFVYUfDe7RBOrS5n,h2ldCUQZJ74k6EjrPLo,VoCapUKBIz3YWw8,NvPW3YMhR1zZkFtHKOQBipy0wTrxb7,M2uhU3GIW8jwJazHO,NgH1U80knyI2P,uckGrZOIv6HxD2ytjNWsXdm = VXp2ouLAg5Mz8jct1hf6m[x7NwSuz5ft4e]
		if NgH1U80knyI2P==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡧࡰࡱࡧࠫট"):
			UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH = FIHNSc5iuoZanQ2Ytl(u"ࡗࡶࡺ࡫૞"),TWexH5PhS1(u"ࠧ࡯ࡱࡷ࡬࡮ࡴࡧࠨঠ")
			if jHiJrUxn0wRpIQKWtCLSydo934cMGe: KK47FGdX1TDfkb3AjHOQqghE(ZhqJoOtcmTVID65HwnLj(u"ࠨࠩড"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࠪঢ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ণ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡๅ๋ำ๏๊ࠦิฬัำ๊ࠦรฯำࠣษฺีวา่ࠢฮํ็ัࠡใํࠤ๊๎วใ฻ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡๆ๊ิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫত")+x7NwSuz5ft4e)
		else:
			if showDialogs:
				if NgH1U80knyI2P==WmaPChRdQk3YcXwI6zS(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧথ"): F67qZAgMjPukRfJ = sbgu4D2RFMYKm(u"࠭ๅห๊ๅๅฮ࠭দ")
				elif NgH1U80knyI2P==l5mQdjWyczr7UJVnTp(u"ࠧࡰ࡮ࡧࠫধ"): F67qZAgMjPukRfJ = EEvLoMzFqrlKce(u"ࠨไา๎๊ฯࠧন")
				elif NgH1U80knyI2P==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ঩"): F67qZAgMjPukRfJ = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪ฾๏ืࠠๆอหฮฮ࠭প")
				VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(WmaPChRdQk3YcXwI6zS(u"ࠫࠬফ"),WmaPChRdQk3YcXwI6zS(u"ࠬ࠭ব"),Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࠧভ"),ZEiR0StquOzca9lvPAndYIX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪম"),HH4JMrUDp3lq6hQ(u"ࠨ้ำ๋ࠥอไฦุสๅฮࠦࠧয")+F67qZAgMjPukRfJ+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฤࠧ࡜࡯࡞ࡱࠫর")+x7NwSuz5ft4e)
			if not VjwKs4GNQZ518kCl: eArL6XSu708qMBpnJ3RfZjy1UH = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬ঱")
			else:
				if NgH1U80knyI2P==WmaPChRdQk3YcXwI6zS(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ল"):
					cLCisPE3lX = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(oAXJCYqPgyGDtT(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ঳")+x7NwSuz5ft4e+N9olEh0ZMtpOivVfBLK(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ঴"))
					if ttOu147wErcBvPaSMUY(u"ࠧࡐࡍࠪ঵") in cLCisPE3lX:
						UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH = WmaPChRdQk3YcXwI6zS(u"ࡘࡷࡻࡥ૟"),FIHNSc5iuoZanQ2Ytl(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩশ")
						if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࠪষ"),TWexH5PhS1(u"ࠪࠫস"),WmaPChRdQk3YcXwI6zS(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧহ"),PiFkQ5pCJy7fbX(u"ࠬา๊ะࠢฯำฬࠦ࠮࠯ࠢส่ส฼วโหࠣ็ฬ์สࠡ็อ์็็ษࠡ࠰࠱ࠤํ่วๆࠢส่อืๆศ็ฯࠤอะิ฻์็๋ฬࡢ࡮࡝ࡰࠪ঺")+x7NwSuz5ft4e)
					elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࠧ঻"),HH4JMrUDp3lq6hQ(u"ࠧࠨ়"),ZhqJoOtcmTVID65HwnLj(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫঽ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ลืษไอ๋ࠥส้ไไอࠥ࠴࠮๊ࠡ็้ࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠหึ฽๎้ํว࡝ࡰ࡟ࡲࠬা")+x7NwSuz5ft4e)
				elif NgH1U80knyI2P in [N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡳࡱࡪࠧি"),PiFkQ5pCJy7fbX(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬী")]:
					UkYj1KP0ou4q9rVfEgn2JQHI56BG = NNTELmoz5GBWf(x7NwSuz5ft4e,uckGrZOIv6HxD2ytjNWsXdm,Xl3drKyI9HkDiPEf8RTjwu(u"ࡋࡧ࡬ࡴࡧૠ"))
					if UkYj1KP0ou4q9rVfEgn2JQHI56BG:
						if NgH1U80knyI2P==N9olEh0ZMtpOivVfBLK(u"ࠬࡵ࡬ࡥࠩু"): eArL6XSu708qMBpnJ3RfZjy1UH = cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧূ")
						elif NgH1U80knyI2P==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨৃ"): eArL6XSu708qMBpnJ3RfZjy1UH = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫৄ")
						h2ldCUQZJ74k6EjrPLo = NvPW3YMhR1zZkFtHKOQBipy0wTrxb7
						if showDialogs:
							if eArL6XSu708qMBpnJ3RfZjy1UH==sbgu4D2RFMYKm(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪ৅"): KK47FGdX1TDfkb3AjHOQqghE(EEvLoMzFqrlKce(u"ࠪࠫ৆"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࠬে"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨৈ"),WmaPChRdQk3YcXwI6zS(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪ৉")+x7NwSuz5ft4e)
							elif eArL6XSu708qMBpnJ3RfZjy1UH==VOq8Ekue4F(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪ৊"): KK47FGdX1TDfkb3AjHOQqghE(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࠩো"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࠪৌ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั্࠭"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢ็้ࠥะใ็่ࠢ์ั๎ฯสࠢไ๎้่ࠥะ์ࠣ࠲࠳่ࠦศๆหี๋อๅอࠢๅห๊ࠦศหอห๎ฯํว࡝ࡰ࡟ࡲࠬৎ")+x7NwSuz5ft4e)
					elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(HVibA2ES8lY(u"ࠬ࠭৏"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧ৐"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৑"),VH9MDo5z1kxNF07uRJI(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫ৒")+x7NwSuz5ft4e)
	elif showDialogs: KK47FGdX1TDfkb3AjHOQqghE(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠪ৓"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠫ৔"),FIHNSc5iuoZanQ2Ytl(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ৕"),f5uqIoSJzWBOFyrY78RXmVb(u"๊ࠬไฤีไࠤ࠳࠴่ࠠา๊ࠤฬ๊ลืษไอࠥเ๊า่ࠢ์ั๎ฯสࠢไ๎๋่ࠥศไ฼ࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱࠲ࠥ๎ไ่าสࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢฦ๊ࠥ๐โ้็ࠣฬฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡล๋ࠤฯำฯ๋อ๊หࡡࡴ࡜࡯ࠩ৖")+x7NwSuz5ft4e)
	return UkYj1KP0ou4q9rVfEgn2JQHI56BG,eArL6XSu708qMBpnJ3RfZjy1UH,h2ldCUQZJ74k6EjrPLo
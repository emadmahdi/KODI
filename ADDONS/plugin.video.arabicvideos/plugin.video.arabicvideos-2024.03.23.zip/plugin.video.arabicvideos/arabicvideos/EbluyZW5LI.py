# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'ALFATIMI'
JJCLnkX4TozH7Bsjivfe = '_FTM_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
jaCAfpodX28RNVnD4t0mySgwB9 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
MyGQqcn0p5L = ['3030','628']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==60: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==61: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==62: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==63: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==64: cLCisPE3lX = KK6i7TgSEsQI8rfwWtkVDq(text)
	elif mode==69: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'ما يتم مشاهدته الان',HbiLZQKalC,64,'','','recent_viewed_vids')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الاكثر مشاهدة',HbiLZQKalC,64,'','','most_viewed_vids')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'اضيفت مؤخرا',HbiLZQKalC,64,'','','recently_added_vids')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'فيديو عشوائي',HbiLZQKalC,64,'','','random_vids')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'افلام ومسلسلات',HbiLZQKalC,61,'','','-1')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'البرامج الدينية',HbiLZQKalC,61,'','','-2')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'English Videos',HbiLZQKalC,61,'','','-3')
	return ''
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ZecS1yJOzVutgX0qiH3NER):
	hh84fQPcKsBIiGC16kj = ''
	if ZecS1yJOzVutgX0qiH3NER not in ['-1','-2','-3']: hh84fQPcKsBIiGC16kj = '?cat='+ZecS1yJOzVutgX0qiH3NER
	ll9khUfx3MjZ = HbiLZQKalC+'/menu_level.php'+hh84fQPcKsBIiGC16kj
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','ALFATIMI-TITLES-1st')
	items = T072lCzjYiuaeFtmJGV.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	CB9vzFJVicxsgG3OKN0,C4aOhQx81J = False,False
	for i8sFwPqo1vpEXR2VdHU5BmW,title,count in items:
		title = Nkuqp0boKj41i9(title)
		title = title.strip(' ')
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
		hh84fQPcKsBIiGC16kj = T072lCzjYiuaeFtmJGV.findall('cat=(.*?)&',i8sFwPqo1vpEXR2VdHU5BmW,T072lCzjYiuaeFtmJGV.DOTALL)[0]
		if ZecS1yJOzVutgX0qiH3NER==hh84fQPcKsBIiGC16kj: CB9vzFJVicxsgG3OKN0 = True
		elif CB9vzFJVicxsgG3OKN0 	or (ZecS1yJOzVutgX0qiH3NER=='-1' and hh84fQPcKsBIiGC16kj in jaCAfpodX28RNVnD4t0mySgwB9)  						or (ZecS1yJOzVutgX0qiH3NER=='-2' and hh84fQPcKsBIiGC16kj not in MyGQqcn0p5L and hh84fQPcKsBIiGC16kj not in jaCAfpodX28RNVnD4t0mySgwB9)  						or (ZecS1yJOzVutgX0qiH3NER=='-3' and hh84fQPcKsBIiGC16kj in MyGQqcn0p5L):
							if count=='1': QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,63)
							else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,61,'','',hh84fQPcKsBIiGC16kj)
							C4aOhQx81J = True
	if not C4aOhQx81J: UAB8vizclM6XG4Pw(url)
	return
def UAB8vizclM6XG4Pw(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','',True,'ALFATIMI-EPISODES-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('pagination(.*?)id="footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	i8sFwPqo1vpEXR2VdHU5BmW = ''
	for o3gHuBtrRN,title,i8sFwPqo1vpEXR2VdHU5BmW in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,63,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('(.*?)div',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR=tmEVko4qsghUX6WLx8KG7fOTB[0]
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR=T072lCzjYiuaeFtmJGV.findall('pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	items=T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = url.split('?')[0]
	for i8sFwPqo1vpEXR2VdHU5BmW,KhRP2beyNfv in items:
		i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ + i8sFwPqo1vpEXR2VdHU5BmW
		title = Nkuqp0boKj41i9(KhRP2beyNfv)
		title = 'صفحة ' + title
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,62)
	return i8sFwPqo1vpEXR2VdHU5BmW
def JwYEQUDupG2WLPzHndc(url):
	if 'videos.php' in url: url = UAB8vizclM6XG4Pw(url)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'','',True,'ALFATIMI-PLAY-1st')
	items = T072lCzjYiuaeFtmJGV.findall('playlistfile:"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	pidYDcjvhgVfqb3GeWSAOH5J(url,nO6ukabcldeU,'video')
	return
def KK6i7TgSEsQI8rfwWtkVDq(ZecS1yJOzVutgX0qiH3NER):
	y7PU6am9Z3I = { 'mode' : ZecS1yJOzVutgX0qiH3NER }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(y7PU6am9Z3I)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
		title = title.strip(' ')
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,63,o3gHuBtrRN)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	url = HbiLZQKalC + '/search_result.php?query=' + xC2GuEcJKk3t4Uh
	UAB8vizclM6XG4Pw(url)
	return
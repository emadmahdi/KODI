# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from pjZisTuDH7 import *
nO6ukabcldeU = l5mQdjWyczr7UJVnTp(u"࠭ࡉࡏࡋࡗࠫ૨")
GZvEITHSg5U3rVwQ(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡏࡑࡗࡍࡈࡋࠧ૩"),HVibA2ES8lY(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨ૪"))
MMVPRsn2G4YK6byiwvO = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = MMVPRsn2G4YK6byiwvO
B23DvidbEG0TwXFnexpftIs = int(DkjbIhZoVd7F52r6Ew)
uUeNnkywGtlj36V2dX7L = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(vatyjK4hHAoZJ7rOq2lis(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ૫"))
uUeNnkywGtlj36V2dX7L = uUeNnkywGtlj36V2dX7L.replace(sfquhCGUwdvRl96izX,WmaPChRdQk3YcXwI6zS(u"ࠪࠫ૬")).replace(zWyErX8YHiLsemj9G6lb2p1,vatyjK4hHAoZJ7rOq2lis(u"ࠫࠬ૭"))
if B23DvidbEG0TwXFnexpftIs==Xl3drKyI9HkDiPEf8RTjwu(u"࠴࠹࠴କ"): kg1pK9CEwGaTI0ReMP4crBL8tshHy = HVibA2ES8lY(u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭૮")+pQmoyUJBNaf72A+mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭૯")+wK1R0Up3rH+VOq8Ekue4F(u"ࠧࠡ࡟ࠪ૰")
else:
	dIhbGxjeML7A6OUSyRcsDwgE = rygO0TzuEdiPcQDWZ8awSjm(pyDQJ34XlhL6OmuoPk5UvSjN08MVG).replace(WmaPChRdQk3YcXwI6zS(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ૱"),sbgu4D2RFMYKm(u"ࠩࠪ૲")).replace(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭૳"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬ૴"))
	dIhbGxjeML7A6OUSyRcsDwgE = dIhbGxjeML7A6OUSyRcsDwgE.replace(FIHNSc5iuoZanQ2Ytl(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ૵"),sbgu4D2RFMYKm(u"࠭ࠧ૶")).strip(Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠡࠩ૷"))
	dIhbGxjeML7A6OUSyRcsDwgE = dIhbGxjeML7A6OUSyRcsDwgE.replace(h5huy6MiXPNfQJF8(u"ࠨࠢࠣࠤࠥ࠭૸"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࠣࠫૹ")).replace(ZEiR0StquOzca9lvPAndYIX(u"ࠪࠤࠥࠦࠧૺ"),oAXJCYqPgyGDtT(u"ࠫࠥ࠭ૻ")).replace(vatyjK4hHAoZJ7rOq2lis(u"ࠬࠦࠠࠨૼ"),WmaPChRdQk3YcXwI6zS(u"࠭ࠠࠨ૽"))
	kg1pK9CEwGaTI0ReMP4crBL8tshHy = ttOu147wErcBvPaSMUY(u"ࠧࠡࠢࠣࡐࡦࡨࡥ࡭࠼ࠣ࡟ࠥ࠭૾")+uUeNnkywGtlj36V2dX7L+VH9MDo5z1kxNF07uRJI(u"ࠨࠢࡠࠤࠥࠦࡍࡰࡦࡨ࠾ࠥࡡࠠࠨ૿")+DkjbIhZoVd7F52r6Ew+TWexH5PhS1(u"ࠩࠣࡡࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ଀")+dIhbGxjeML7A6OUSyRcsDwgE+Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࠤࡢ࠭ଁ")
GZvEITHSg5U3rVwQ(HH4JMrUDp3lq6hQ(u"ࠫࡓࡕࡔࡊࡅࡈࠫଂ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+kg1pK9CEwGaTI0ReMP4crBL8tshHy)
FeJkKctiN0rwxvlg2C8G4oyq = YTPut68WBVUNCvsEzg.getSetting(VH9MDo5z1kxNF07uRJI(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩଃ"))
v05aJEsnIF = Xl3drKyI9HkDiPEf8RTjwu(u"ࡇࡣ࡯ࡷࡪଛ") if FeJkKctiN0rwxvlg2C8G4oyq==pQmoyUJBNaf72A else uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡔࡳࡷࡨଚ")
if not v05aJEsnIF and B23DvidbEG0TwXFnexpftIs in [h5huy6MiXPNfQJF8(u"࠵࠷࠺ଖ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠻࠶࠻ଗ")]:
	xDfZGsilBXPVgdF427SeQkaE = str(RLg3NjAdqfTMl[l5mQdjWyczr7UJVnTp(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭଄")])
	nO6ukabcldeU = vatyjK4hHAoZJ7rOq2lis(u"ࠧࡪࡲࡷࡺࠬଅ") if B23DvidbEG0TwXFnexpftIs==N9olEh0ZMtpOivVfBLK(u"࠷࠹࠵ଘ") else FIHNSc5iuoZanQ2Ytl(u"ࠨ࡯࠶ࡹࠬଆ")
	zslrWLD38jgdn = YTPut68WBVUNCvsEzg.getSetting(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡤࡺ࠳࠭ଇ")+nO6ukabcldeU+TWexH5PhS1(u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨଈ")+xDfZGsilBXPVgdF427SeQkaE)
	Zf5QgUxKW7FCOuBIdMh8swkn = YTPut68WBVUNCvsEzg.getSetting(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࡦࡼ࠮ࠨଉ")+nO6ukabcldeU+vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨଊ")+xDfZGsilBXPVgdF427SeQkaE)
	if zslrWLD38jgdn or Zf5QgUxKW7FCOuBIdMh8swkn:
		gz1flZwncVutokL59RaGS3WeK += HVibA2ES8lY(u"࠭ࡼࠨଋ")
		if zslrWLD38jgdn: gz1flZwncVutokL59RaGS3WeK += N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ଌ")+zslrWLD38jgdn
		if Zf5QgUxKW7FCOuBIdMh8swkn: gz1flZwncVutokL59RaGS3WeK += WmaPChRdQk3YcXwI6zS(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ଍")+Zf5QgUxKW7FCOuBIdMh8swkn
		gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK.replace(VH9MDo5z1kxNF07uRJI(u"ࠩࡿࠪࠬ଎"),VOq8Ekue4F(u"ࠪࢀࠬଏ"))
	RRSDtmy2kX1ElcqOa8x3eBu6Z = YTPut68WBVUNCvsEzg.getSetting(ZhqJoOtcmTVID65HwnLj(u"ࠫࡦࡼ࠮ࠨଐ")+nO6ukabcldeU+PiFkQ5pCJy7fbX(u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ଑")+xDfZGsilBXPVgdF427SeQkaE)
	if RRSDtmy2kX1ElcqOa8x3eBu6Z:
		XXVzwBpDrbjP = T072lCzjYiuaeFtmJGV.findall(cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩ଒"),gz1flZwncVutokL59RaGS3WeK,T072lCzjYiuaeFtmJGV.DOTALL)
		gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK.replace(XXVzwBpDrbjP[FIHNSc5iuoZanQ2Ytl(u"࠶ଙ")],RRSDtmy2kX1ElcqOa8x3eBu6Z)
	nO6ukabcldeU = nO6ukabcldeU.upper()
	pidYDcjvhgVfqb3GeWSAOH5J(gz1flZwncVutokL59RaGS3WeK,nO6ukabcldeU,otciIUKlyb6)
else:
	from skIgoAvZ9t import inrDtz8mJqLpkPSldeyYjsEaBwA,rS3V6a9s8vl,Ysrnya0A9CTWb4Bh2UHf5wv3EDP
	WzeExBTV6h = WmaPChRdQk3YcXwI6zS(u"ࠧࠨଓ")
	inrDtz8mJqLpkPSldeyYjsEaBwA(ZEiR0StquOzca9lvPAndYIX(u"ࠨࡵࡷࡥࡷࡺࠧଔ"))
	try: rS3V6a9s8vl(MMVPRsn2G4YK6byiwvO,uUeNnkywGtlj36V2dX7L)
	except Exception as g3gh0rZF6Bp1X8UmaWe9: WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
	Ysrnya0A9CTWb4Bh2UHf5wv3EDP(WzeExBTV6h)
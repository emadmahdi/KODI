# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'RESOLVERS'
uBmNdsHwlpWI = []
headers = {'User-Agent':''}
ZpBaY0L93zPi8JAuynwDUhmo56 = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,source,type,url):
	if not MfIDplCLUGK91vjO:
		GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		ZZNOMuxvEgWFJfr26oH1XPbGU8jK = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'dict','MISC_PERM','SITES_ERRORS')
		r3FTmIhP8v6A4Qb0RX = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%Y.%m.%d %H:%M',D1vBJgya85Yh4cRTCkIMKtWLSeH.gmtime(EEd0FZyfticlDPAMp2HbNesx))
		GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g = r3FTmIhP8v6A4Qb0RX,url
		key = source+'    '+pQmoyUJBNaf72A+'    '+str(XK3HqaTnjpyIAuhw67CmdvBM)
		F67qZAgMjPukRfJ = ''
		if key not in list(ZZNOMuxvEgWFJfr26oH1XPbGU8jK.keys()): ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key] = [GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g]
		else:
			if url not in str(ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key]): ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key].append(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
			else: F67qZAgMjPukRfJ = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		Y8Iy2qOBXhMNlzZW6s1S3t = 0
		for key in list(ZZNOMuxvEgWFJfr26oH1XPbGU8jK.keys()):
			ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key] = list(set(ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key]))
			Y8Iy2qOBXhMNlzZW6s1S3t += len(ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key])
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+F67qZAgMjPukRfJ+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(Y8Iy2qOBXhMNlzZW6s1S3t))
		if Y8Iy2qOBXhMNlzZW6s1S3t>=5:
			VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if VjwKs4GNQZ518kCl==1:
				JGYq2yBf36xojVb8Rd = ''
				for key in list(ZZNOMuxvEgWFJfr26oH1XPbGU8jK.keys()):
					JGYq2yBf36xojVb8Rd += '\n'+key
					CCmyKwHEAx4pfiRNDbFqXvJ7 = sorted(ZZNOMuxvEgWFJfr26oH1XPbGU8jK[key],reverse=False,key=lambda PRWbeQ84fkMdGBE9r: PRWbeQ84fkMdGBE9r[0])
					for r3FTmIhP8v6A4Qb0RX,url in CCmyKwHEAx4pfiRNDbFqXvJ7:
						JGYq2yBf36xojVb8Rd += '\n'+r3FTmIhP8v6A4Qb0RX+'    '+rygO0TzuEdiPcQDWZ8awSjm(url)
					JGYq2yBf36xojVb8Rd += '\n\n'
				import TRa6GJnHO1
				UkYj1KP0ou4q9rVfEgn2JQHI56BG = TRa6GJnHO1.YYKFsUfhQctD1bjpEzZagd('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',JGYq2yBf36xojVb8Rd)
				if UkYj1KP0ou4q9rVfEgn2JQHI56BG: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if VjwKs4GNQZ518kCl!=-1:
				ZZNOMuxvEgWFJfr26oH1XPbGU8jK = {}
				Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'MISC_PERM','SITES_ERRORS')
		if ZZNOMuxvEgWFJfr26oH1XPbGU8jK: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'MISC_PERM','SITES_ERRORS',ZZNOMuxvEgWFJfr26oH1XPbGU8jK,U6y1OBwzfkEuRGVNrpYFv)
		return
	MfIDplCLUGK91vjO = list(set(MfIDplCLUGK91vjO))
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = qFljOr6p5KGVhAB71Yw3nUgmMf(MfIDplCLUGK91vjO,source)
	NQ6PjGx0OtkKrB2ZVAUcDTMn8Fbg9q = str(M7oS6tLhdx3ke8qPX4mFA).count('__watch')
	KJMlW3kcw12h45LpQo = str(M7oS6tLhdx3ke8qPX4mFA).count('__download')
	ONUX4Ji89zMxKpjWwGf5R3Bh = len(M7oS6tLhdx3ke8qPX4mFA)-NQ6PjGx0OtkKrB2ZVAUcDTMn8Fbg9q-KJMlW3kcw12h45LpQo
	ggEOlrqsfm7dvDR = 'مشاهدة:'+str(NQ6PjGx0OtkKrB2ZVAUcDTMn8Fbg9q)+'    تحميل:'+str(KJMlW3kcw12h45LpQo)+'    أخرى:'+str(ONUX4Ji89zMxKpjWwGf5R3Bh)
	if not M7oS6tLhdx3ke8qPX4mFA: hrgtXiSNu72,cdCjtIBh0LwFUfpEYvby1oHWG = 'unresolved',''
	else:
		add = 0
		if not any(EYn2siOeDvQTk8KpS0Jl in source for EYn2siOeDvQTk8KpS0Jl in ZpBaY0L93zPi8JAuynwDUhmo56):
			add = 1
			M7oS6tLhdx3ke8qPX4mFA = ['RESOLVE_ALL_LINKS']+list(M7oS6tLhdx3ke8qPX4mFA)
			n7CuHMSJpiR9fP0jvNEIyDUL = ['فحص جميع السيرفرات']+list(n7CuHMSJpiR9fP0jvNEIyDUL)
		while True:
			cdCjtIBh0LwFUfpEYvby1oHWG,hrgtXiSNu72 = '',''
			if add and len(M7oS6tLhdx3ke8qPX4mFA)==2: tzgWIKy5xQL2kjm = 1
			else: tzgWIKy5xQL2kjm = sSOy1pju5PJ(ggEOlrqsfm7dvDR,n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm==-1: hrgtXiSNu72 = 'canceled_1st_menu'
			elif add and tzgWIKy5xQL2kjm==0:
				hrgtXiSNu72 = 'canceled_2nd_menu'
				cLCisPE3lX = D7ENe80rvbqGWAjS(n7CuHMSJpiR9fP0jvNEIyDUL[add:],M7oS6tLhdx3ke8qPX4mFA[add:],source)
				if cLCisPE3lX:
					e5mS39E1JQwTqz720g4 = []
					for qVPikX2KLyo94HdT1mDWIpFhA,ddaXOACLHSWo4r,nq61iewN8PWRGXT3shHk2vMJQ,f32rLDolMviVQAzXK5SWh4jHkgs,BrkwqcMxIe2RVO7oC83Q5m in cLCisPE3lX:
						if BrkwqcMxIe2RVO7oC83Q5m: e5mS39E1JQwTqz720g4.append((qVPikX2KLyo94HdT1mDWIpFhA,ddaXOACLHSWo4r,nq61iewN8PWRGXT3shHk2vMJQ,f32rLDolMviVQAzXK5SWh4jHkgs,BrkwqcMxIe2RVO7oC83Q5m))
					if e5mS39E1JQwTqz720g4: n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,errors,lNwOdSoA6E,kkH5sRPxhASFowLONy4 = zip(*e5mS39E1JQwTqz720g4)
					else:
						KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						hrgtXiSNu72 = 'failed'
						break
					ggEOlrqsfm7dvDR = 'السيرفرات الجيدة ( '+str(len(M7oS6tLhdx3ke8qPX4mFA))+' )'
					add = 0
					continue
			else:
				cLCisPE3lX = D7ENe80rvbqGWAjS([n7CuHMSJpiR9fP0jvNEIyDUL[tzgWIKy5xQL2kjm]],[M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]],source)
				if cLCisPE3lX:
					title,i8sFwPqo1vpEXR2VdHU5BmW,errors,lNwOdSoA6E,kkH5sRPxhASFowLONy4 = cLCisPE3lX[0]
					if not kkH5sRPxhASFowLONy4 and not any(EYn2siOeDvQTk8KpS0Jl in source for EYn2siOeDvQTk8KpS0Jl in ZpBaY0L93zPi8JAuynwDUhmo56):
						errors,lNwOdSoA6E,kkH5sRPxhASFowLONy4 = DQ4RVLiSgkfp2r(i8sFwPqo1vpEXR2VdHU5BmW,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+i8sFwPqo1vpEXR2VdHU5BmW+' ]')
						import TRa6GJnHO1
						TRa6GJnHO1.sLwcqUvWGBxmCJuRK8()
						hrgtXiSNu72 = 'unresolved'
					else:
						GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+i8sFwPqo1vpEXR2VdHU5BmW+' ]')
						hrgtXiSNu72,cdCjtIBh0LwFUfpEYvby1oHWG,Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR = Sas4gBZMnXQxKjNhL(title,i8sFwPqo1vpEXR2VdHU5BmW,errors,lNwOdSoA6E,kkH5sRPxhASFowLONy4,source,type)
			if hrgtXiSNu72 in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(M7oS6tLhdx3ke8qPX4mFA)==1+add: break
			elif hrgtXiSNu72 in ['failed','timeout','tried']: break
			elif hrgtXiSNu72 not in ['canceled_2nd_menu','https']:
				if '\n' in cdCjtIBh0LwFUfpEYvby1oHWG: cdCjtIBh0LwFUfpEYvby1oHWG = '[LEFT]  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','\n[LEFT]  ')
				KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+cdCjtIBh0LwFUfpEYvby1oHWG,profile='confirm_mediumfont')
	if hrgtXiSNu72=='unresolved' and len(n7CuHMSJpiR9fP0jvNEIyDUL)>0: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+cdCjtIBh0LwFUfpEYvby1oHWG,profile='confirm_mediumfont')
	elif hrgtXiSNu72 in ['failed','timeout'] and cdCjtIBh0LwFUfpEYvby1oHWG!='': KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج',cdCjtIBh0LwFUfpEYvby1oHWG,profile='confirm_mediumfont')
	return hrgtXiSNu72
def D7ENe80rvbqGWAjS(TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO,source):
	global dUN7OmQwC4Ft8B9PTyES
	dUN7OmQwC4Ft8B9PTyES,cLCisPE3lX,DUsZBv8kcF52Xr3WM4RuG,new = [],[],[],[]
	TuLb46ZoWU85Vt3laJGEhvRyIKwrz(False,False,False)
	count = len(MfIDplCLUGK91vjO)
	for NvZ3WnyDcGUbegBqx4zJrsdQAaH in range(count):
		dUN7OmQwC4Ft8B9PTyES.append(None)
		title = TBPSh6qZpsiHoe4w[NvZ3WnyDcGUbegBqx4zJrsdQAaH]
		i8sFwPqo1vpEXR2VdHU5BmW = MfIDplCLUGK91vjO[NvZ3WnyDcGUbegBqx4zJrsdQAaH].strip(' ').strip('&').strip('?').strip('/')
		if count>1: fYPz7RldWQVHBktZAexwvCL8Np3D('فحص سيرفر رقم  '+str(NvZ3WnyDcGUbegBqx4zJrsdQAaH+1),title)
		GA8bxgZuQ5iSFOlkCR = i8sFwPqo1vpEXR2VdHU5BmW.split('?named=',1)[0]
		TTNS2yH31vQ0qRB = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','RESOLVED',GA8bxgZuQ5iSFOlkCR)
		if TTNS2yH31vQ0qRB and 'AKWAM' not in source:
			dUN7OmQwC4Ft8B9PTyES[NvZ3WnyDcGUbegBqx4zJrsdQAaH] = TTNS2yH31vQ0qRB
		else:
			D28DBSvG64jCRUfuhNmXn5ixas0r9b = RZxCcFI8fw31NKP.Thread(target=DQ4RVLiSgkfp2r,args=(i8sFwPqo1vpEXR2VdHU5BmW,source,NvZ3WnyDcGUbegBqx4zJrsdQAaH))
			D28DBSvG64jCRUfuhNmXn5ixas0r9b.start()
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(0.5)
			DUsZBv8kcF52Xr3WM4RuG.append(D28DBSvG64jCRUfuhNmXn5ixas0r9b)
			new.append(NvZ3WnyDcGUbegBqx4zJrsdQAaH)
	timeout = 60 if source=='AKWAM' else 20
	for D28DBSvG64jCRUfuhNmXn5ixas0r9b in DUsZBv8kcF52Xr3WM4RuG: D28DBSvG64jCRUfuhNmXn5ixas0r9b.join(timeout)
	for NvZ3WnyDcGUbegBqx4zJrsdQAaH in range(count):
		title = TBPSh6qZpsiHoe4w[NvZ3WnyDcGUbegBqx4zJrsdQAaH]
		i8sFwPqo1vpEXR2VdHU5BmW = MfIDplCLUGK91vjO[NvZ3WnyDcGUbegBqx4zJrsdQAaH].strip(' ').strip('&').strip('?').strip('/')
		if dUN7OmQwC4Ft8B9PTyES[NvZ3WnyDcGUbegBqx4zJrsdQAaH]: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = dUN7OmQwC4Ft8B9PTyES[NvZ3WnyDcGUbegBqx4zJrsdQAaH]
		else: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		cLCisPE3lX.append([title,i8sFwPqo1vpEXR2VdHU5BmW,cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA])
		if NvZ3WnyDcGUbegBqx4zJrsdQAaH in new:
			GA8bxgZuQ5iSFOlkCR = i8sFwPqo1vpEXR2VdHU5BmW.split('?named=',1)[0]
			rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'RESOLVED',GA8bxgZuQ5iSFOlkCR,[cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA],GGXxhdg3JCamPIFepybjZ)
	TuLb46ZoWU85Vt3laJGEhvRyIKwrz('','','')
	return cLCisPE3lX
def DQ4RVLiSgkfp2r(url,source,g80O9QtN6lbRcPiu=0):
	global dUN7OmQwC4Ft8B9PTyES
	GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Resolving started   Original: [ '+url+' ]')
	i8sFwPqo1vpEXR2VdHU5BmW,yCJ1ZcpBXk40 = url,''
	ww2TmW4Xav = 'INTERNAL_RESOLVER'
	cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ntp47VsQyC9(url,source)
	if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER':
		yCJ1ZcpBXk40 = '\nResolver 1:  Exit'
		dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		return yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	elif 'NEED_EXTERNAL_RESOLVERS' in cdCjtIBh0LwFUfpEYvby1oHWG:
		yCJ1ZcpBXk40 = '\nResolver 1:  Need External Resolver'
		i8sFwPqo1vpEXR2VdHU5BmW = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)[0]
		dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		ww2TmW4Xav,yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = sPCkBTWjEFXHwSvdO0r28V4lbRKg7(yCJ1ZcpBXk40,i8sFwPqo1vpEXR2VdHU5BmW,source,g80O9QtN6lbRcPiu)
	elif cdCjtIBh0LwFUfpEYvby1oHWG: yCJ1ZcpBXk40 = 'Resolver 1:  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','').replace('\r','')[:80]
	if M7oS6tLhdx3ke8qPX4mFA:
		M7oS6tLhdx3ke8qPX4mFA = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Resolving succeeded   Resolver: [ '+ww2TmW4Xav+' ]   Original: [ '+url+' ]   Link: [ '+i8sFwPqo1vpEXR2VdHU5BmW+' ]   Results: [ '+str(M7oS6tLhdx3ke8qPX4mFA)+' ]')
	else: GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+i8sFwPqo1vpEXR2VdHU5BmW+' ]   Errors: [ '+yCJ1ZcpBXk40+' ]')
	yCJ1ZcpBXk40 = rygO0TzuEdiPcQDWZ8awSjm(yCJ1ZcpBXk40)
	dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	return yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def sPCkBTWjEFXHwSvdO0r28V4lbRKg7(yCJ1ZcpBXk40,url,source,g80O9QtN6lbRcPiu):
	global dUN7OmQwC4Ft8B9PTyES
	ww2TmW4Xav = 'EXTERNAL_RESOLVER_2'
	cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = xx0Hub9fwq3Odor(url,source)
	M7oS6tLhdx3ke8qPX4mFA = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)
	dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	elif 'Failed:' in cdCjtIBh0LwFUfpEYvby1oHWG:
		yCJ1ZcpBXk40 += '\nResolver 2:  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','').replace('\r','')[:80]
		ww2TmW4Xav = 'EXTERNAL_RESOLVER_3'
		cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ACc82W1djpDls0xSZrTL3NUJVo(url,source)
		M7oS6tLhdx3ke8qPX4mFA = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)
		dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		elif 'Failed:' in cdCjtIBh0LwFUfpEYvby1oHWG:
			yCJ1ZcpBXk40 += '\nResolver 3:  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','').replace('\r','')[:80]
			ww2TmW4Xav = 'EXTERNAL_RESOLVER_4'
			cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = goZ1fI9tLYp0eBuVKPbOHRdAh(url,source)
			M7oS6tLhdx3ke8qPX4mFA = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)
			dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
			if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
			elif 'Failed:' in cdCjtIBh0LwFUfpEYvby1oHWG:
				yCJ1ZcpBXk40 += '\nResolver 4:  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','').replace('\r','')[:80]
				ww2TmW4Xav = 'EXTERNAL_RESOLVER_5'
				cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = PWEo0fgyCh5Bp3IdMVnOj(url,source)
				M7oS6tLhdx3ke8qPX4mFA = szifrHu9jYIkoMFdK5aEv(M7oS6tLhdx3ke8qPX4mFA)
				dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
				if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
				elif 'Failed:' in cdCjtIBh0LwFUfpEYvby1oHWG:
					yCJ1ZcpBXk40 += '\nResolver 5:  '+cdCjtIBh0LwFUfpEYvby1oHWG.replace('\n','').replace('\r','')[:80]
	dUN7OmQwC4Ft8B9PTyES[g80O9QtN6lbRcPiu] = yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	return ww2TmW4Xav,yCJ1ZcpBXk40,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def Sas4gBZMnXQxKjNhL(title,i8sFwPqo1vpEXR2VdHU5BmW,cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,source,type=''):
	if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	elif M7oS6tLhdx3ke8qPX4mFA:
		while True:
			if len(M7oS6tLhdx3ke8qPX4mFA)==1: tzgWIKy5xQL2kjm = 0
			else: tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الملف المناسب:', n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm==-1: hrgtXiSNu72 = 'tried'
			else:
				wwG2zrkcpW = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
				title = n7CuHMSJpiR9fP0jvNEIyDUL[tzgWIKy5xQL2kjm]
				GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(wwG2zrkcpW)+' ]')
				if 'moshahda.' in wwG2zrkcpW and 'download_orig' in wwG2zrkcpW:
					FqjwUvGBsgpNkPVW3btn,JajuNYsFR1IH6cZ4mVnKMy8AOpD0,Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR = dKf2SY8GDV3H(wwG2zrkcpW)
					if Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR: wwG2zrkcpW = Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR[0]
					else: wwG2zrkcpW = ''
				if not wwG2zrkcpW: hrgtXiSNu72 = 'unresolved'
				else: hrgtXiSNu72 = pidYDcjvhgVfqb3GeWSAOH5J(wwG2zrkcpW,source,type)
			if hrgtXiSNu72 in ['playing','testing','canceled_2nd_menu'] or len(M7oS6tLhdx3ke8qPX4mFA)==1: break
			elif hrgtXiSNu72 in ['failed','timeout','tried']: break
			else: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		hrgtXiSNu72 = 'unresolved'
		rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(i8sFwPqo1vpEXR2VdHU5BmW)
		if rUTwZXB4AoFRzdjnEPD2iNJKs: hrgtXiSNu72 = pidYDcjvhgVfqb3GeWSAOH5J(i8sFwPqo1vpEXR2VdHU5BmW,source,type)
	return hrgtXiSNu72,cdCjtIBh0LwFUfpEYvby1oHWG,M7oS6tLhdx3ke8qPX4mFA
def HHkrpO2gqN9GY5yu3UtBcIm(url,source):
	ll9khUfx3MjZ,cDgK6v1zerl8pU7hHJ3LC,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,rLMcaXNnTPjGkR5lw,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD = url,'','','','','','',''
	if '?named=' in url:
		ll9khUfx3MjZ,cDgK6v1zerl8pU7hHJ3LC = url.split('?named=',1)
		cDgK6v1zerl8pU7hHJ3LC = cDgK6v1zerl8pU7hHJ3LC+'__'+'__'+'__'+'__'
		cDgK6v1zerl8pU7hHJ3LC = cDgK6v1zerl8pU7hHJ3LC.lower()
		XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD,nUEkWtT7yoMQPFDhAYCsrd = cDgK6v1zerl8pU7hHJ3LC.split('__')[:5]
	if Q5OAspyiXV1lx8930qLGD=='': Q5OAspyiXV1lx8930qLGD = '0'
	else: Q5OAspyiXV1lx8930qLGD = Q5OAspyiXV1lx8930qLGD.replace('p','').replace(' ','')
	ll9khUfx3MjZ = ll9khUfx3MjZ.strip('?').strip('/').strip('&')
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,'host')
	if XLVqPOIzGJl6KUyQ23d9: rLMcaXNnTPjGkR5lw = XLVqPOIzGJl6KUyQ23d9
	else: rLMcaXNnTPjGkR5lw = dATnilvcrXxmZ1k5EP0KgBFDqYpy6
	rLMcaXNnTPjGkR5lw = ClNwy8MJfjoTq4ZFxYvmasD(rLMcaXNnTPjGkR5lw,'name')
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	cDgK6v1zerl8pU7hHJ3LC = cDgK6v1zerl8pU7hHJ3LC.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	rLMcaXNnTPjGkR5lw = rLMcaXNnTPjGkR5lw.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return ll9khUfx3MjZ,cDgK6v1zerl8pU7hHJ3LC,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,rLMcaXNnTPjGkR5lw,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD
def d8MKVyxPmtCj3LND6S(url,source):
	ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9,olVt7YiMBQIpDFaRdxGL2y6,BzstTI60VmvhW8rdfN5YUegHx,yKPLticgSpF4,M1jiNX25vYytATO4WfRq,ww2TmW4Xav = '','',None,None,None,None,None
	ll9khUfx3MjZ,cDgK6v1zerl8pU7hHJ3LC,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,rLMcaXNnTPjGkR5lw,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD = HHkrpO2gqN9GY5yu3UtBcIm(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if UuygfPcTR0zC!='':
			if 'mp4' not in UuygfPcTR0zC: UuygfPcTR0zC = '%'+UuygfPcTR0zC
			UuygfPcTR0zC = ' '+UuygfPcTR0zC
		if Q5OAspyiXV1lx8930qLGD!='':
			Q5OAspyiXV1lx8930qLGD = '%%%%%%%%%'+Q5OAspyiXV1lx8930qLGD
			Q5OAspyiXV1lx8930qLGD = ' '+Q5OAspyiXV1lx8930qLGD[-9:]
	if   'AKOAM'		in source: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'AKWAM'		in source: olVt7YiMBQIpDFaRdxGL2y6	= 'akwam'
	elif 'katkoute'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'photos.app.g'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'arabseed'		in source: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'alarab'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'fasel'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 't7meel'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'movs4u'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'myegyvip'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'fajer'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'فجر'			in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= 'fajer'
	elif 'فلسطين'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= 'palestine'
	elif 'gdrive'		in ll9khUfx3MjZ:   olVt7YiMBQIpDFaRdxGL2y6	= 'google'
	elif 'mycima'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'wecima'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'cimanow'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'newcima'		in XLVqPOIzGJl6KUyQ23d9:   olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'dailymotion'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'bokra'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'tvfun'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'tvksa'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'anavidz'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'shoofpro'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= rLMcaXNnTPjGkR5lw
	elif 'shahid4u'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'shahed4u'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'cima4u'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'egynow'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'halacima'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'cimaabdo'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'youtu'	 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'youtube'
	elif 'y2u.be'	 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'youtube'
	elif 'd.egybest.d'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'egybestvip'
	elif 'egy.best'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'egybest1'
	elif 'egybest'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'egybest3'
	elif 'moshahda'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'moshahda'
	elif 'facultybooks'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'facultybooks'
	elif 'inflam.cc'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'inflam'
	elif 'buzzvrl'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: olVt7YiMBQIpDFaRdxGL2y6	= 'buzzvrl'
	elif 'arabloads'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'arabloads'
	elif 'archive'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'archive'
	elif 'catch.is'	 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'catch'
	elif 'filerio'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'filerio'
	elif 'vidbm'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'vidbm'
	elif 'vidhd'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'myvid'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'myviid'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: M1jiNX25vYytATO4WfRq	= rLMcaXNnTPjGkR5lw
	elif 'videobin'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'videobin'
	elif 'govid'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'govid'
	elif 'liivideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'liivideo'
	elif 'mp4upload'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'mp4upload'
	elif 'publicvideo'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'publicvideo'
	elif 'rapidvideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'rapidvideo'
	elif 'top4top'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'top4top'
	elif 'upp' 			in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'upbom'
	elif 'upb' 			in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'upbom'
	elif 'uqload' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'uqload'
	elif 'vcstream' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'vcstream'
	elif 'vidbob'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'vidbob'
	elif 'vidoza' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'vidoza'
	elif 'watchvideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'watchvideo'
	elif 'wintv.live'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'wintv.live'
	elif 'zippyshare'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'zippyshare'
	elif 'hd-cdn'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: BzstTI60VmvhW8rdfN5YUegHx	= 'hd-cdn'
	if   olVt7YiMBQIpDFaRdxGL2y6:	ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = 'خاص',olVt7YiMBQIpDFaRdxGL2y6
	elif M1jiNX25vYytATO4WfRq:		ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = '%محدد',M1jiNX25vYytATO4WfRq
	elif BzstTI60VmvhW8rdfN5YUegHx:		ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = '%%عام معروف',BzstTI60VmvhW8rdfN5YUegHx
	elif yKPLticgSpF4:	ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = '%%%عام خارجي',yKPLticgSpF4
	elif ww2TmW4Xav:	ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = '%%%%عام خارجي',rLMcaXNnTPjGkR5lw
	else:			ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9 = '%%%%%عام مجهول',rLMcaXNnTPjGkR5lw
	return ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD
def ntp47VsQyC9(url,source):
	ll9khUfx3MjZ,M1jiNX25vYytATO4WfRq,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,rLMcaXNnTPjGkR5lw,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD = HHkrpO2gqN9GY5yu3UtBcIm(url,source)
	if   'AKOAM'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = zzSmHfGRh1(ll9khUfx3MjZ,XLVqPOIzGJl6KUyQ23d9)
	elif 'AKWAM'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = IqinpDkyKl(ll9khUfx3MjZ,type,Q5OAspyiXV1lx8930qLGD)
	elif 'FASELHD1'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = gC4dqk9SLB(ll9khUfx3MjZ)
	elif 'CIMA4U'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = BLdv9gUfaA(ll9khUfx3MjZ)
	elif 'CIMACLUB'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = LHZqFm32BY(ll9khUfx3MjZ)
	elif 'ARABSEED'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = vCtl0ns45z(ll9khUfx3MjZ)
	elif 'CIMAABDO'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = wBonpRSNeM(ll9khUfx3MjZ)
	elif 'SHOFHA'		in source: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = hCe8APomMv(ll9khUfx3MjZ)
	elif 'katkoute'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = g96gjGpAJ0(ll9khUfx3MjZ)
	elif 'akoam.cam'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = sp0ci7URFg(ll9khUfx3MjZ)
	elif 'alarab'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = c3LvVrAltm7WsdDTqHwpE9OXj5oC(ll9khUfx3MjZ)
	elif 'shahid4u'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = DIHBeTNura(ll9khUfx3MjZ)
	elif 'shahed4u'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = DIHBeTNura(ll9khUfx3MjZ)
	elif 'egynow'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = eJK6akm4Wr(ll9khUfx3MjZ)
	elif 'tvfun'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = F7tRBq8g52(ll9khUfx3MjZ)
	elif 'tvksa'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = F7tRBq8g52(ll9khUfx3MjZ)
	elif 'tv-f.com'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = F7tRBq8g52(ll9khUfx3MjZ)
	elif 'halacima'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = isINJdkS0c(ll9khUfx3MjZ)
	elif 'shoofpro'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ZW6geGYkMJ(ll9khUfx3MjZ)
	elif 'myegyvip'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = UZEDrCs5FXoQ2az(ll9khUfx3MjZ)
	elif 'vs4u'			in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = RebLZS85Mr(ll9khUfx3MjZ)
	elif 'fajer'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = N2LfsEFw0l(ll9khUfx3MjZ)
	elif 'cimanow'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = coLpZ1IUQX(ll9khUfx3MjZ)
	elif 'newcima'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = coLpZ1IUQX(ll9khUfx3MjZ)
	elif 'cima-light'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = IzDwgOdRve(ll9khUfx3MjZ)
	elif 'cimalight'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = IzDwgOdRve(ll9khUfx3MjZ)
	elif 'mycima'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = JZ9alXQ134(ll9khUfx3MjZ)
	elif 'wecima'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = aNYf1hSZV0(ll9khUfx3MjZ)
	elif 'bokra'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = MJgi5GqtY1(ll9khUfx3MjZ)
	elif 'dailymotion'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = LEZ1hMoasH(ll9khUfx3MjZ)
	elif 'arblionz'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ifSd1M9kgR(ll9khUfx3MjZ)
	elif 'd.egybest.d'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '',[''],[ll9khUfx3MjZ]
	elif 'egy.best'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = TgIVM3sG2w(url)
	elif 'egybest'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = MM7Ygkxlt3(ll9khUfx3MjZ)
	elif 'series4watch'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Njz2f70qrX(ll9khUfx3MjZ)
	elif 'upbam' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '',[''],[ll9khUfx3MjZ]
	else: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	return 'Failed:  '+cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def xx0Hub9fwq3Odor(url,source):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'name')
	M7oS6tLhdx3ke8qPX4mFA = []
	if   'youtu'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = sSG0U5DEax(url)
	elif 'y2u.be'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = sSG0U5DEax(url)
	elif 'googleuserco' in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = fChgvXquOcWkT7SbFQsB6(url)
	elif 'photos.app.g'	in url   : cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = H0UwpkYrdmZIFcnTL5Xh7bxfS(url)
	elif 'dailymotion'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = LEZ1hMoasH(url)
	elif 'moshahda'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = dKf2SY8GDV3H(url)
	elif 'faselhd'		in url   : cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = gC4dqk9SLB(url)
	elif 'arabloads'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = hKiRs9zZ1Qp6GjTDF3O(url)
	elif 'archive'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Z4UjIzq3ntWbOFeJxfMChDdl(url)
	elif 'buzzvrl'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = LcYxJAK9iur(url)
	elif 'e5tsar'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = rrzPNBbWUtRu39sVoFAMqaY1nhl(url)
	elif 'facultybooks'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = gq4V1sLvQnETD9ap8yU3hiuGP(url)
	elif 'inflam.cc'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = gq4V1sLvQnETD9ap8yU3hiuGP(url)
	elif 'upbam' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '',[''],[url]
	elif 'liivideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = DCOb3kRXpoLcQhvGIzg(url)
	elif 'mp4upload'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = XdP3eguvyl6Ww2rHokZQf(url)
	elif 'rapidvideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Xzw72IlZKTcEGN6pQnDk(url)
	elif 'top4top'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = QHt0YRzA4k9U(url)
	elif 'upb' 			in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Td8UMu7Q0f(url)
	elif 'upp' 			in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Td8UMu7Q0f(url)
	elif 'uqload' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = l2gPqG6EF7uIB8zrLeH9UxYo(url)
	elif 'vcstream' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ccABREnheoKGz(url)
	elif 'vidbob'		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = pfIKjkBwqX1veutcA4F(url)
	elif 'vidoza' 		in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = UAn95Z7gX0p(url)
	elif 'watchvideo' 	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Rlw0K2T9gYAsm5SNbEJpvyO73W(url)
	elif 'wintv.live'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = J2J3amkXfxjcg(url)
	elif 'zippyshare'	in dATnilvcrXxmZ1k5EP0KgBFDqYpy6: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = R3qtrDJ0XiShkof65wOd4mgP(url)
	if M7oS6tLhdx3ke8qPX4mFA: return 'Failed: '+cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	return 'Failed:  ',[],[]
def ACc82W1djpDls0xSZrTL3NUJVo(url,source):
	cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Y8YFEzwKf7L2mVrHPkpIQ0xt1bW5Xi(url)
	if M7oS6tLhdx3ke8qPX4mFA: return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	if cdCjtIBh0LwFUfpEYvby1oHWG=='EXIT_RESOLVER': cdCjtIBh0LwFUfpEYvby1oHWG = ''
	return 'Failed:  '+cdCjtIBh0LwFUfpEYvby1oHWG,[],[]
def szifrHu9jYIkoMFdK5aEv(fRUZX4eznc6x2C9d8aptBWuiTS):
	if 'list' in str(type(fRUZX4eznc6x2C9d8aptBWuiTS)):
		kkH5sRPxhASFowLONy4 = []
		for i8sFwPqo1vpEXR2VdHU5BmW in fRUZX4eznc6x2C9d8aptBWuiTS:
			if 'str' in str(type(i8sFwPqo1vpEXR2VdHU5BmW)):
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\r','').replace('\n','').strip(' ')
			kkH5sRPxhASFowLONy4.append(i8sFwPqo1vpEXR2VdHU5BmW)
	else: kkH5sRPxhASFowLONy4 = fRUZX4eznc6x2C9d8aptBWuiTS.replace('\r','').replace('\n','').strip(' ')
	return kkH5sRPxhASFowLONy4
def qFljOr6p5KGVhAB71Yw3nUgmMf(Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR,source):
	efTYtsigQALPBJm3pa2w1q6OnK = CC89Q23uNDmIKWHAs
	data = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SERVERS',Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR)
	if data:
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = list(zip(*data))
		return n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,TADaewb8r9O3yK = [],[],[]
	for i8sFwPqo1vpEXR2VdHU5BmW in Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR:
		if '//' not in i8sFwPqo1vpEXR2VdHU5BmW: continue
		ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD = d8MKVyxPmtCj3LND6S(i8sFwPqo1vpEXR2VdHU5BmW,source)
		Q5OAspyiXV1lx8930qLGD = T072lCzjYiuaeFtmJGV.findall('\d+',Q5OAspyiXV1lx8930qLGD,T072lCzjYiuaeFtmJGV.DOTALL)
		if Q5OAspyiXV1lx8930qLGD: Q5OAspyiXV1lx8930qLGD = int(Q5OAspyiXV1lx8930qLGD[0])
		else: Q5OAspyiXV1lx8930qLGD = 0
		dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
		TADaewb8r9O3yK.append([ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD,i8sFwPqo1vpEXR2VdHU5BmW,dATnilvcrXxmZ1k5EP0KgBFDqYpy6])
	if TADaewb8r9O3yK:
		ZiH2DfRBbQ7Vy = sorted(TADaewb8r9O3yK,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		QE4rxJl6AyeKVCj = []
		for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in ZiH2DfRBbQ7Vy:
			if GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g not in QE4rxJl6AyeKVCj:
				QE4rxJl6AyeKVCj.append(GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g)
		for ffsO4CXnbjSdNQ9ipzZmGAtxewvYI,XLVqPOIzGJl6KUyQ23d9,type,UuygfPcTR0zC,Q5OAspyiXV1lx8930qLGD,i8sFwPqo1vpEXR2VdHU5BmW,dATnilvcrXxmZ1k5EP0KgBFDqYpy6 in QE4rxJl6AyeKVCj:
			if Q5OAspyiXV1lx8930qLGD: Q5OAspyiXV1lx8930qLGD = str(Q5OAspyiXV1lx8930qLGD)
			else: Q5OAspyiXV1lx8930qLGD = ''
			title = 'سيرفر'+' '+type+' '+ffsO4CXnbjSdNQ9ipzZmGAtxewvYI+' '+Q5OAspyiXV1lx8930qLGD+' '+UuygfPcTR0zC+' '+XLVqPOIzGJl6KUyQ23d9
			if dATnilvcrXxmZ1k5EP0KgBFDqYpy6 not in title: title = title+' '+dATnilvcrXxmZ1k5EP0KgBFDqYpy6
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if i8sFwPqo1vpEXR2VdHU5BmW not in M7oS6tLhdx3ke8qPX4mFA:
				n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		if M7oS6tLhdx3ke8qPX4mFA:
			data = list(zip(n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA))
			if data: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SERVERS',Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR,data,efTYtsigQALPBJm3pa2w1q6OnK)
	return n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def goZ1fI9tLYp0eBuVKPbOHRdAh(url,source):
	WzeExBTV6h = ''
	cLCisPE3lX = False
	try:
		import resolveurl as nG1g9fo6McviZCzFd
		cLCisPE3lX = nG1g9fo6McviZCzFd.resolve(url)
	except Exception as NePVOoSMkFKApCtr: WzeExBTV6h = str(NePVOoSMkFKApCtr)
	if not cLCisPE3lX:
		if WzeExBTV6h=='':
			WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
			if WzeExBTV6h!='NoneType: None\n': CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
		cdCjtIBh0LwFUfpEYvby1oHWG = WzeExBTV6h.splitlines()[-1]
		return 'Failed:  '+cdCjtIBh0LwFUfpEYvby1oHWG,[],[]
	return '',[''],[cLCisPE3lX]
def PWEo0fgyCh5Bp3IdMVnOj(url,source):
	WzeExBTV6h = ''
	cLCisPE3lX = False
	try:
		import youtube_dl as URHaPVQd40bqnFh2elv
		iYafmEp9bKR4GzIMDxZguV = URHaPVQd40bqnFh2elv.YoutubeDL({'no_color': True})
		cLCisPE3lX = iYafmEp9bKR4GzIMDxZguV.extract_info(url,download=False)
	except Exception as NePVOoSMkFKApCtr: WzeExBTV6h = str(NePVOoSMkFKApCtr)
	if not cLCisPE3lX or 'formats' not in list(cLCisPE3lX.keys()):
		if WzeExBTV6h=='':
			WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
			if WzeExBTV6h!='NoneType: None\n': CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
		cdCjtIBh0LwFUfpEYvby1oHWG = WzeExBTV6h.splitlines()[-1]
		return 'Failed:  '+cdCjtIBh0LwFUfpEYvby1oHWG,[],[]
	else:
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
		for i8sFwPqo1vpEXR2VdHU5BmW in cLCisPE3lX['formats']:
			n7CuHMSJpiR9fP0jvNEIyDUL.append(i8sFwPqo1vpEXR2VdHU5BmW['format'])
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW['url'])
		return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def c3LvVrAltm7WsdDTqHwpE9OXj5oC(url):
	if '.m3u8' in url:
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = w7py6bdKn1jqMSfh(url)
		if M7oS6tLhdx3ke8qPX4mFA: return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def g96gjGpAJ0(url):
	MfIDplCLUGK91vjO,TBPSh6qZpsiHoe4w = [],[]
	if '/videos.mp4?vid=' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in WM1buqXnzf3Ba6Vp29l4gFD.headers:
			i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
			TBPSh6qZpsiHoe4w.append(dATnilvcrXxmZ1k5EP0KgBFDqYpy6)
	elif 'katkoute.com' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		x9AlD75zbKLkUECh = T072lCzjYiuaeFtmJGV.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if x9AlD75zbKLkUECh:
			x9AlD75zbKLkUECh = x9AlD75zbKLkUECh[0]
			IwglpjXx0hoi1kLPCA = Dy9cvU05WMY(x9AlD75zbKLkUECh)
			iihTqnQIpjc15oR0AUadVYZ = T072lCzjYiuaeFtmJGV.findall('sources:(\[.*?\]),',IwglpjXx0hoi1kLPCA,T072lCzjYiuaeFtmJGV.DOTALL)
			if iihTqnQIpjc15oR0AUadVYZ:
				iihTqnQIpjc15oR0AUadVYZ = iihTqnQIpjc15oR0AUadVYZ[0]
				iihTqnQIpjc15oR0AUadVYZ = cwiLy4IAVJj0pWCl7FGxokR('list',iihTqnQIpjc15oR0AUadVYZ)
				for dict in iihTqnQIpjc15oR0AUadVYZ:
					i8sFwPqo1vpEXR2VdHU5BmW = dict['file']
					Q5OAspyiXV1lx8930qLGD = dict['label']
					MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
					dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
					TBPSh6qZpsiHoe4w.append(Q5OAspyiXV1lx8930qLGD+' '+dATnilvcrXxmZ1k5EP0KgBFDqYpy6)
		elif 'Location' in WM1buqXnzf3Ba6Vp29l4gFD.headers:
			i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
			TBPSh6qZpsiHoe4w.append(dATnilvcrXxmZ1k5EP0KgBFDqYpy6)
		if '?url=https://photos.app.goo' in url:
			i8sFwPqo1vpEXR2VdHU5BmW = url.split('?url=')[1]
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&')[0]
			if i8sFwPqo1vpEXR2VdHU5BmW:
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
				TBPSh6qZpsiHoe4w.append('photos google')
	else:
		MfIDplCLUGK91vjO.append(url)
		dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'name')
		TBPSh6qZpsiHoe4w.append(dATnilvcrXxmZ1k5EP0KgBFDqYpy6)
	if not MfIDplCLUGK91vjO: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(MfIDplCLUGK91vjO)==1: i8sFwPqo1vpEXR2VdHU5BmW = MfIDplCLUGK91vjO[0]
	else:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('أختر الملف المناسب',TBPSh6qZpsiHoe4w)
		if tzgWIKy5xQL2kjm==-1: return 'EXIT_RESOLVER',[],[]
		i8sFwPqo1vpEXR2VdHU5BmW = MfIDplCLUGK91vjO[tzgWIKy5xQL2kjm]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def fChgvXquOcWkT7SbFQsB6(url):
	headers = {'User-Agent':'Kodi/'+str(XK3HqaTnjpyIAuhw67CmdvBM)}
	for H3ABEcMzfyqwF4Ug2ZYtK in range(50):
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(0.100)
		WM1buqXnzf3Ba6Vp29l4gFD = rQhCtPmne9SIJcw4M('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()):
			i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'|User-Agent='+headers['User-Agent']
			return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
		if WM1buqXnzf3Ba6Vp29l4gFD.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def H0UwpkYrdmZIFcnTL5Xh7bxfS(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD = i8sFwPqo1vpEXR2VdHU5BmW[0]
		return '',[Q5OAspyiXV1lx8930qLGD],[i8sFwPqo1vpEXR2VdHU5BmW]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def gC4dqk9SLB(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qQXuaKpVrGLF3e5oidJ8YwDT0 = BJxFdCcqYyK96TS50MP3jav(qQXuaKpVrGLF3e5oidJ8YwDT0)
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"file":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW: return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def hCe8APomMv(url):
	if '/down.php' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('video-wrapper.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		url = i8sFwPqo1vpEXR2VdHU5BmW[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def BLdv9gUfaA(url):
	if 'server.php' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		if 'http' in i8sFwPqo1vpEXR2VdHU5BmW: return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def eJK6akm4Wr(url):
	ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
	JKf4Tsxu9S23FI7mV5DGLk = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-EGYNOW-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: return 'Error: Resolver Failed EGYNOW',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def ZW6geGYkMJ(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if not i8sFwPqo1vpEXR2VdHU5BmW: return 'Error: Resolver Failed SHOOFPRO',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def isINJdkS0c(url):
	ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
	JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-HALACIMA-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('''<iframe src=["'](.*?)["']''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if not i8sFwPqo1vpEXR2VdHU5BmW: return 'Error: Resolver Failed HALACIMA',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def wBonpRSNeM(url):
	ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
	JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-CIMAABDO-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('''<iframe src=["'](.*?)["']''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	else: i8sFwPqo1vpEXR2VdHU5BmW = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def F7tRBq8g52(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	vd6whFjQn8f5eXcugoHUbOKkPW = T072lCzjYiuaeFtmJGV.findall("var fserv =.*?'(.*?)'",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if vd6whFjQn8f5eXcugoHUbOKkPW:
		vd6whFjQn8f5eXcugoHUbOKkPW = vd6whFjQn8f5eXcugoHUbOKkPW[0][2:]
		vd6whFjQn8f5eXcugoHUbOKkPW = eJ4h7nOpguFMH6z1IUEV2i.b64decode(vd6whFjQn8f5eXcugoHUbOKkPW)
		if mmIKCGujwM: vd6whFjQn8f5eXcugoHUbOKkPW = vd6whFjQn8f5eXcugoHUbOKkPW.decode('utf8')
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',vd6whFjQn8f5eXcugoHUbOKkPW,T072lCzjYiuaeFtmJGV.DOTALL)
	else: i8sFwPqo1vpEXR2VdHU5BmW = ''
	if not i8sFwPqo1vpEXR2VdHU5BmW: return 'Error: Resolver Failed TVFUN',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def UZEDrCs5FXoQ2az(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('class="col-sm-12".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: return 'Error: Resolver Failed MYEGYVIP',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def LEZ1hMoasH(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	cdCjtIBh0LwFUfpEYvby1oHWG = 'Error: Resolver Failed DAILYMOTION'
	NePVOoSMkFKApCtr = T072lCzjYiuaeFtmJGV.findall('"error".*?"messagee":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if NePVOoSMkFKApCtr: cdCjtIBh0LwFUfpEYvby1oHWG = NePVOoSMkFKApCtr[0]
	url = T072lCzjYiuaeFtmJGV.findall('x-mpegURL","url":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not url and cdCjtIBh0LwFUfpEYvby1oHWG:
		return cdCjtIBh0LwFUfpEYvby1oHWG,[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = url[0].replace('\\','')
	JajuNYsFR1IH6cZ4mVnKMy8AOpD0,Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR = w7py6bdKn1jqMSfh(i8sFwPqo1vpEXR2VdHU5BmW)
	jjcUIZ6zfqJx = T072lCzjYiuaeFtmJGV.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if jjcUIZ6zfqJx: QJS1yNpeKiM,bYkhtroEl5dg6ViHxeB0vuDp4I,X4dj0zyZCmferESvusYbOk = jjcUIZ6zfqJx[0]
	else: QJS1yNpeKiM,bYkhtroEl5dg6ViHxeB0vuDp4I,X4dj0zyZCmferESvusYbOk = '','',''
	X4dj0zyZCmferESvusYbOk = X4dj0zyZCmferESvusYbOk.replace('\/','/')
	bYkhtroEl5dg6ViHxeB0vuDp4I = Bd2o0J6aOASWvuD9HzY(bYkhtroEl5dg6ViHxeB0vuDp4I)
	n7CuHMSJpiR9fP0jvNEIyDUL = ['[COLOR FFC89008]OWNER:  '+bYkhtroEl5dg6ViHxeB0vuDp4I+'[/COLOR]']+JajuNYsFR1IH6cZ4mVnKMy8AOpD0
	M7oS6tLhdx3ke8qPX4mFA = [X4dj0zyZCmferESvusYbOk]+Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR
	tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الملف المناسب: ('+str(len(M7oS6tLhdx3ke8qPX4mFA)-1)+' ملف)',n7CuHMSJpiR9fP0jvNEIyDUL)
	if tzgWIKy5xQL2kjm==-1: return 'EXIT_RESOLVER',[],[]
	elif tzgWIKy5xQL2kjm==0:
		ZN1A9DvqdociFsz5eVftYH4rbEgLaS = CJwTBit4NPQMu.argv[0]+'?type=folder&mode=402&url='+X4dj0zyZCmferESvusYbOk+'&textt='+bYkhtroEl5dg6ViHxeB0vuDp4I
		EO9Rts0AaGuk1qpPLXCY.executebuiltin("Container.Update("+ZN1A9DvqdociFsz5eVftYH4rbEgLaS+")")
		return 'EXIT_RESOLVER',[],[]
	i8sFwPqo1vpEXR2VdHU5BmW =  M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def MJgi5GqtY1(i8sFwPqo1vpEXR2VdHU5BmW):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'','','','','RESOLVERS-BOKRA-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if '.json' in i8sFwPqo1vpEXR2VdHU5BmW: url = T072lCzjYiuaeFtmJGV.findall('"src":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: url = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def dKf2SY8GDV3H(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = T072lCzjYiuaeFtmJGV.findall('direct link.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			F67qZAgMjPukRfJ = T072lCzjYiuaeFtmJGV.findall('class="err">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if F67qZAgMjPukRfJ:
				KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من الموقع الاصلي',F67qZAgMjPukRfJ[0])
				return 'Error: '+F67qZAgMjPukRfJ[0],[],[]
	else:
		dFEpvGRU73W6TowXj5xV8 = 'movizland'
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('Form method="POST" action=\'(.*?)\'(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: return 'Error: Resolver Failed MOSHAHDA',[],[]
		K9K307bTvRVtO6i = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][1]
		if '.rar' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR or '.zip' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR: return 'Error: MOSHAHDA Not a video file',[],[]
		items = T072lCzjYiuaeFtmJGV.findall('name="(.*?)".*?value="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		y7PU6am9Z3I = {}
		for XLVqPOIzGJl6KUyQ23d9,EYn2siOeDvQTk8KpS0Jl in items:
			y7PU6am9Z3I[XLVqPOIzGJl6KUyQ23d9] = EYn2siOeDvQTk8KpS0Jl
		data = YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(y7PU6am9Z3I)
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,K9K307bTvRVtO6i,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][1]
		items = T072lCzjYiuaeFtmJGV.findall('file:"(.*?)"(,label:".*?"|)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		xb5kh8zmf4XscY3NFG7awMDJIq1y,n7CuHMSJpiR9fP0jvNEIyDUL,K9KRlBXQmO0bfFMhaPY2czwvJynpr,M7oS6tLhdx3ke8qPX4mFA,MTGeOj2rnJ90WoVuaCcBPZRIFNk7i = [],[],[],[],[]
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if '.m3u8' in i8sFwPqo1vpEXR2VdHU5BmW:
				xb5kh8zmf4XscY3NFG7awMDJIq1y,K9KRlBXQmO0bfFMhaPY2czwvJynpr = w7py6bdKn1jqMSfh(i8sFwPqo1vpEXR2VdHU5BmW)
				M7oS6tLhdx3ke8qPX4mFA = M7oS6tLhdx3ke8qPX4mFA + K9KRlBXQmO0bfFMhaPY2czwvJynpr
				if xb5kh8zmf4XscY3NFG7awMDJIq1y[0]=='-1': n7CuHMSJpiR9fP0jvNEIyDUL.append(' سيرفر خاص '+'m3u8 '+dFEpvGRU73W6TowXj5xV8)
				else:
					for title in xb5kh8zmf4XscY3NFG7awMDJIq1y:
						n7CuHMSJpiR9fP0jvNEIyDUL.append(' سيرفر خاص '+'m3u8 '+dFEpvGRU73W6TowXj5xV8+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+dFEpvGRU73W6TowXj5xV8+' '+title
				n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		i8sFwPqo1vpEXR2VdHU5BmW = 'http://moshahda.online' + download
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,i8sFwPqo1vpEXR2VdHU5BmW,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = T072lCzjYiuaeFtmJGV.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,EHnSrqQ7BvmGlOgYZdhTbCRtswA,hash,ayh3UqDOn2tN958MlbjKVmzcBS in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+dFEpvGRU73W6TowXj5xV8+' '+ayh3UqDOn2tN958MlbjKVmzcBS.split('x')[1]
			i8sFwPqo1vpEXR2VdHU5BmW = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+EHnSrqQ7BvmGlOgYZdhTbCRtswA+'&hash='+hash
			MTGeOj2rnJ90WoVuaCcBPZRIFNk7i.append(ayh3UqDOn2tN958MlbjKVmzcBS)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		MTGeOj2rnJ90WoVuaCcBPZRIFNk7i = set(MTGeOj2rnJ90WoVuaCcBPZRIFNk7i)
		P78JW2TpaG6OumCUf3jq,xVtbdKXiCH9Ic2qvg = [],[]
		for title in n7CuHMSJpiR9fP0jvNEIyDUL:
			tPdemXOVBsUW8bK42rRJ3CxyLv = T072lCzjYiuaeFtmJGV.findall(" (\d*x|\d*)&&",title+'&&',T072lCzjYiuaeFtmJGV.DOTALL)
			for ayh3UqDOn2tN958MlbjKVmzcBS in MTGeOj2rnJ90WoVuaCcBPZRIFNk7i:
				if tPdemXOVBsUW8bK42rRJ3CxyLv[0] in ayh3UqDOn2tN958MlbjKVmzcBS:
					title = title.replace(tPdemXOVBsUW8bK42rRJ3CxyLv[0],ayh3UqDOn2tN958MlbjKVmzcBS.split('x')[1])
			P78JW2TpaG6OumCUf3jq.append(title)
		for jV1Z7MWOa80gbwJY64nL5 in range(len(M7oS6tLhdx3ke8qPX4mFA)):
			items = T072lCzjYiuaeFtmJGV.findall("&&(.*?)(\d*)&&",'&&'+P78JW2TpaG6OumCUf3jq[jV1Z7MWOa80gbwJY64nL5]+'&&',T072lCzjYiuaeFtmJGV.DOTALL)
			xVtbdKXiCH9Ic2qvg.append( [P78JW2TpaG6OumCUf3jq[jV1Z7MWOa80gbwJY64nL5],M7oS6tLhdx3ke8qPX4mFA[jV1Z7MWOa80gbwJY64nL5],items[0][0],items[0][1]] )
		xVtbdKXiCH9Ic2qvg = sorted(xVtbdKXiCH9Ic2qvg, key=lambda qa0fA26EyCoSkjKnrh: qa0fA26EyCoSkjKnrh[3], reverse=True)
		xVtbdKXiCH9Ic2qvg = sorted(xVtbdKXiCH9Ic2qvg, key=lambda qa0fA26EyCoSkjKnrh: qa0fA26EyCoSkjKnrh[2], reverse=False)
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(xVtbdKXiCH9Ic2qvg)):
			n7CuHMSJpiR9fP0jvNEIyDUL.append(xVtbdKXiCH9Ic2qvg[jV1Z7MWOa80gbwJY64nL5][0])
			M7oS6tLhdx3ke8qPX4mFA.append(xVtbdKXiCH9Ic2qvg[jV1Z7MWOa80gbwJY64nL5][1])
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def rrzPNBbWUtRu39sVoFAMqaY1nhl(url):
	eHquV9G0n2wlLjOvC5PUW = url.split('?')
	ll9khUfx3MjZ = eHquV9G0n2wlLjOvC5PUW[0]
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,ll9khUfx3MjZ,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = T072lCzjYiuaeFtmJGV.findall('Please wait.*?href=\'(.*?)\'',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def LcYxJAK9iur(url):
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('redirect_url.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ: return '',[''],[ll9khUfx3MjZ[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def gq4V1sLvQnETD9ap8yU3hiuGP(url):
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('href","(htt.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ: return '',[''],[ll9khUfx3MjZ[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def N2LfsEFw0l(url):
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,errno = [],[],''
	if '/wp-admin/' in url:
		ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
		JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-FAJERSHOW-2nd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		if IIV0pUlqMoKDC9r8wy1EGT7OesJQBS.startswith('http'): ll9khUfx3MjZ = IIV0pUlqMoKDC9r8wy1EGT7OesJQBS
		else:
			dCmKxk9BW310AXu4bJUHfY = T072lCzjYiuaeFtmJGV.findall('''src=['"](.*?)['"]''',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if dCmKxk9BW310AXu4bJUHfY:
				ll9khUfx3MjZ = dCmKxk9BW310AXu4bJUHfY[0]
				dCmKxk9BW310AXu4bJUHfY = T072lCzjYiuaeFtmJGV.findall('source=(.*?)[&$]',ll9khUfx3MjZ,T072lCzjYiuaeFtmJGV.DOTALL)
				if dCmKxk9BW310AXu4bJUHfY:
					ll9khUfx3MjZ = rygO0TzuEdiPcQDWZ8awSjm(dCmKxk9BW310AXu4bJUHfY[0])
					return '',[''],[ll9khUfx3MjZ]
	elif '/links/' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		if 'Location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()): ll9khUfx3MjZ = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		else: ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('id="link".*?href="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	if '/v/' in ll9khUfx3MjZ or '/f/' in ll9khUfx3MjZ:
		ll9khUfx3MjZ = ll9khUfx3MjZ.replace('/f/','/api/source/')
		ll9khUfx3MjZ = ll9khUfx3MjZ.replace('/v/','/api/source/')
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',ll9khUfx3MjZ,'','','','','RESOLVERS-FAJERSHOW-3rd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		items = T072lCzjYiuaeFtmJGV.findall('"file":"(.*?)","label":"(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\\','')
				n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		else:
			items = T072lCzjYiuaeFtmJGV.findall('"file":"(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if items:
				i8sFwPqo1vpEXR2VdHU5BmW = items[0]
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\\','')
				n7CuHMSJpiR9fP0jvNEIyDUL.append('')
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def RebLZS85Mr(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			ll9khUfx3MjZ = ll9khUfx3MjZ[0]
		else: ll9khUfx3MjZ = url
		if 'movs4u' not in ll9khUfx3MjZ: return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',ll9khUfx3MjZ,'','','','','RESOLVERS-MOVS4U-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="player"(.*?)videojs',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<source src="(.*?)".*?label="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for i8sFwPqo1vpEXR2VdHU5BmW,uUeNnkywGtlj36V2dX7L in items:
				n7CuHMSJpiR9fP0jvNEIyDUL.append(uUeNnkywGtlj36V2dX7L)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	elif 'main_player.php' in url:
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('url=(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		ll9khUfx3MjZ = ll9khUfx3MjZ[0]
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',ll9khUfx3MjZ,'','','','','RESOLVERS-MOVS4U-3rd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		dCmKxk9BW310AXu4bJUHfY = T072lCzjYiuaeFtmJGV.findall('"file": "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		dCmKxk9BW310AXu4bJUHfY = dCmKxk9BW310AXu4bJUHfY[0]
		n7CuHMSJpiR9fP0jvNEIyDUL.append('')
		M7oS6tLhdx3ke8qPX4mFA.append(dCmKxk9BW310AXu4bJUHfY)
	elif 'download_link' in url:
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('<center><a href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if ll9khUfx3MjZ:
			ll9khUfx3MjZ = ll9khUfx3MjZ[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def LHZqFm32BY(url):
	website = tOnYIHVk4xydqwoLEBKiDN0hX['CIMACLUB'][0]
	headers = {'Referer':website}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('download=.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall("sources: \['(.*?)'",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall("file:'(.*?)'",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]+'|Referer='+website
		return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	if 'name="Xtoken"' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		x7dSnObot9NQr5GAYmJwaUW24h = T072lCzjYiuaeFtmJGV.findall('name="Xtoken" content="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if x7dSnObot9NQr5GAYmJwaUW24h:
			i8sFwPqo1vpEXR2VdHU5BmW = x7dSnObot9NQr5GAYmJwaUW24h[0]
			i8sFwPqo1vpEXR2VdHU5BmW = eJ4h7nOpguFMH6z1IUEV2i.b64decode(i8sFwPqo1vpEXR2VdHU5BmW)
			if mmIKCGujwM: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.decode('utf8','ignore')
			i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('http.*?(http.*?),',i8sFwPqo1vpEXR2VdHU5BmW,T072lCzjYiuaeFtmJGV.DOTALL)
			if i8sFwPqo1vpEXR2VdHU5BmW:
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]+'|Referer='+website
				return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def TgIVM3sG2w(url):
	TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO = [],[]
	if '/1/' in url:
		i8sFwPqo1vpEXR2VdHU5BmW = url.replace('/1/','/4/')
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'','',False,'','RESOLVERS-EGYBEST1-1st')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<video(.*?)</video>',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?size="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in items:
				if i8sFwPqo1vpEXR2VdHU5BmW not in MfIDplCLUGK91vjO:
					MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
					dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
					TBPSh6qZpsiHoe4w.append(dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'  '+Q5OAspyiXV1lx8930qLGD)
			return '',TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO
	elif '/d/' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<iframe.*?src="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if i8sFwPqo1vpEXR2VdHU5BmW:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0].replace('/1/','/4/')
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
			i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('class.*?href="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if i8sFwPqo1vpEXR2VdHU5BmW: return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def MM7Ygkxlt3(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	data = T072lCzjYiuaeFtmJGV.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if data:
		nnCFMV9Ayqo5dPRtGmBxgXhOJv,id,oexNO6r4JGkQL = data[0]
		data = 'op='+nnCFMV9Ayqo5dPRtGmBxgXhOJv+'&id='+id+'&fname='+oexNO6r4JGkQL
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"referer" value="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if i8sFwPqo1vpEXR2VdHU5BmW: return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def gGTiHbNksh(url):
	ll9khUfx3MjZ = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,items,dCmKxk9BW310AXu4bJUHfY = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',ll9khUfx3MjZ,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()): dCmKxk9BW310AXu4bJUHfY = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
	if 'http' in dCmKxk9BW310AXu4bJUHfY:
		if '__watch' in url: dCmKxk9BW310AXu4bJUHfY = dCmKxk9BW310AXu4bJUHfY.replace('/f/','/v/')
		ffbtu31Xy7YrzRL4oFipKgZdJe0kA = ll9khUfx3MjZ.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+ffbtu31Xy7YrzRL4oFipKgZdJe0kA }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',dCmKxk9BW310AXu4bJUHfY,'',headers,False,'','EGYBEST-PLAY-3rd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		if '/f/' in dCmKxk9BW310AXu4bJUHfY: items = T072lCzjYiuaeFtmJGV.findall('<h2>.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		elif '/v/' in dCmKxk9BW310AXu4bJUHfY: items = T072lCzjYiuaeFtmJGV.findall('id="video".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in qQXuaKpVrGLF3e5oidJ8YwDT0:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def Njz2f70qrX(i8sFwPqo1vpEXR2VdHU5BmW):
	eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('postid=(.*?)&serverid=(.*?)&&',i8sFwPqo1vpEXR2VdHU5BmW+'&&',T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	GdflFVny9zZNjP1kX2hIY,Q3JykLsCBquDPihaMNV = eHquV9G0n2wlLjOvC5PUW[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+GdflFVny9zZNjP1kX2hIY+'&serverid='+Q3JykLsCBquDPihaMNV
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	ll9khUfx3MjZ = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
def JZ9alXQ134(url):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	JKf4Tsxu9S23FI7mV5DGLk = {'Referer':dATnilvcrXxmZ1k5EP0KgBFDqYpy6,'Accept-Encoding':'gzip, deflate'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(BZ5D43mGxLAItEUYTv,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-MYCIMA-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('player.qualityselector(.*?)formats:',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = ''
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('format: \'(\d.*?)\', src: "(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		if len(M7oS6tLhdx3ke8qPX4mFA)==1: ll9khUfx3MjZ = M7oS6tLhdx3ke8qPX4mFA[0]
		elif len(M7oS6tLhdx3ke8qPX4mFA)>1:
			tzgWIKy5xQL2kjm = sSOy1pju5PJ('أختر الملف المناسب', n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm==-1: return '',[],[]
			ll9khUfx3MjZ = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: ll9khUfx3MjZ = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not ll9khUfx3MjZ: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
def aNYf1hSZV0(url):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	JKf4Tsxu9S23FI7mV5DGLk = {'Referer':dATnilvcrXxmZ1k5EP0KgBFDqYpy6,'Accept-Encoding':'gzip, deflate'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(BZ5D43mGxLAItEUYTv,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-WECIMA-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('player.qualityselector(.*?)formats:',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = ''
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('format: \'(\d.*?)\', src: "(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		if len(M7oS6tLhdx3ke8qPX4mFA)==1: ll9khUfx3MjZ = M7oS6tLhdx3ke8qPX4mFA[0]
		elif len(M7oS6tLhdx3ke8qPX4mFA)>1:
			tzgWIKy5xQL2kjm = sSOy1pju5PJ('أختر الملف المناسب', n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm==-1: return '',[],[]
			ll9khUfx3MjZ = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	if not ll9khUfx3MjZ:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: ll9khUfx3MjZ = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not ll9khUfx3MjZ: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
def sp0ci7URFg(i8sFwPqo1vpEXR2VdHU5BmW):
	eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',i8sFwPqo1vpEXR2VdHU5BmW+'&&',T072lCzjYiuaeFtmJGV.DOTALL)
	url,GdflFVny9zZNjP1kX2hIY,Q3JykLsCBquDPihaMNV = eHquV9G0n2wlLjOvC5PUW[0]
	data = {'post_id':GdflFVny9zZNjP1kX2hIY,'server':Q3JykLsCBquDPihaMNV}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('iframe src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
def IzDwgOdRve(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<iframe.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		if i8sFwPqo1vpEXR2VdHU5BmW: return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def l5liAXKZoO(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<IFRAME SRC="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def coLpZ1IUQX(url):
	Oa38pfHe5x2FPCKRwbJ6mhVG = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	if 'index=' in url:
		headers = {'Referer':Oa38pfHe5x2FPCKRwbJ6mhVG}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if ll9khUfx3MjZ:
			ll9khUfx3MjZ = ll9khUfx3MjZ[0]
			if 'cimanow' in ll9khUfx3MjZ:
				ll9khUfx3MjZ = ll9khUfx3MjZ.replace('https://','http://')
				WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
				items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)".*?size="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
				n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
				i4sAb9xNqmGp2hCXUJtvuy7zkSW = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,'url')
				for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in reversed(items):
					i8sFwPqo1vpEXR2VdHU5BmW = i4sAb9xNqmGp2hCXUJtvuy7zkSW+i8sFwPqo1vpEXR2VdHU5BmW+'|Referer='+i4sAb9xNqmGp2hCXUJtvuy7zkSW
					n7CuHMSJpiR9fP0jvNEIyDUL.append(Q5OAspyiXV1lx8930qLGD)
					M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
				return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	ll9khUfx3MjZ = url+'|Referer='+Oa38pfHe5x2FPCKRwbJ6mhVG
	return '',[''],[ll9khUfx3MjZ]
def zT6J2CkHB1IQjYSXieUEKr(i8sFwPqo1vpEXR2VdHU5BmW):
	Oa38pfHe5x2FPCKRwbJ6mhVG = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'url')
	if 'postid' in i8sFwPqo1vpEXR2VdHU5BmW:
		eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',i8sFwPqo1vpEXR2VdHU5BmW+'&&',T072lCzjYiuaeFtmJGV.DOTALL)
		url,GdflFVny9zZNjP1kX2hIY,Q3JykLsCBquDPihaMNV = eHquV9G0n2wlLjOvC5PUW[0]
		data = {'id':GdflFVny9zZNjP1kX2hIY,'server':Q3JykLsCBquDPihaMNV}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('iframe src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
		if 'cimanow' in ll9khUfx3MjZ:
			headers = {'Referer':Oa38pfHe5x2FPCKRwbJ6mhVG,'User-Agent':''}
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
			items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?size="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
			i4sAb9xNqmGp2hCXUJtvuy7zkSW = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,'url')
			for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in reversed(items):
				i8sFwPqo1vpEXR2VdHU5BmW = i4sAb9xNqmGp2hCXUJtvuy7zkSW+i8sFwPqo1vpEXR2VdHU5BmW+'|Referer='+i4sAb9xNqmGp2hCXUJtvuy7zkSW
				n7CuHMSJpiR9fP0jvNEIyDUL.append(Q5OAspyiXV1lx8930qLGD)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	else:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'|Referer='+Oa38pfHe5x2FPCKRwbJ6mhVG
		return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
def ifSd1M9kgR(i8sFwPqo1vpEXR2VdHU5BmW):
	if 'postid' in i8sFwPqo1vpEXR2VdHU5BmW:
		eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('postid=(.*?)&serverid=(.*?)&&',i8sFwPqo1vpEXR2VdHU5BmW+'&&',T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		GdflFVny9zZNjP1kX2hIY,Q3JykLsCBquDPihaMNV = eHquV9G0n2wlLjOvC5PUW[0]
		a7HWcL08nC1q2JMPYIKkv4epXUSyf = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'url')
		url = a7HWcL08nC1q2JMPYIKkv4epXUSyf+'/ajaxCenter?_action=getserver&_post_id='+GdflFVny9zZNjP1kX2hIY+'&serverid='+Q3JykLsCBquDPihaMNV
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		ll9khUfx3MjZ = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		ll9khUfx3MjZ = ll9khUfx3MjZ.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	elif '/redirect/' in i8sFwPqo1vpEXR2VdHU5BmW:
		oqiYRLNObxnI2sZW3Bcgh = 0
		while '/redirect/' in i8sFwPqo1vpEXR2VdHU5BmW and oqiYRLNObxnI2sZW3Bcgh<5:
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()): i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
			oqiYRLNObxnI2sZW3Bcgh += 1
		return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def vCtl0ns45z(url):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	headers = {'Referer':dATnilvcrXxmZ1k5EP0KgBFDqYpy6,'User-Agent':diwUZMEagkFDlS()}
	if '/embed-' in url:
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if i8sFwPqo1vpEXR2VdHU5BmW:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0].replace('https','http')
			return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	else:
		vqxYErWcCBmzJGQ4MRT = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = vqxYErWcCBmzJGQ4MRT.content
		JKf4Tsxu9S23FI7mV5DGLk = headers.copy()
		if '_lnk_' in str(vqxYErWcCBmzJGQ4MRT.cookies):
			cookies = vqxYErWcCBmzJGQ4MRT.cookies
			JKf4Tsxu9S23FI7mV5DGLk['Cookie'] = rygO0TzuEdiPcQDWZ8awSjm(YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(cookies))
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('link.href = "(http.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not i8sFwPqo1vpEXR2VdHU5BmW: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW[0])+'&d=1'
			mnV8BCoXEJxyAZtQhU62RpbraOY = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'',JKf4Tsxu9S23FI7mV5DGLk,'','','RESOLVERS-ARABSEED-4th')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = mnV8BCoXEJxyAZtQhU62RpbraOY.content
			i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('id="btn".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if i8sFwPqo1vpEXR2VdHU5BmW:
				i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW[0])
				if 'mp4' in i8sFwPqo1vpEXR2VdHU5BmW and '/d/' in i8sFwPqo1vpEXR2VdHU5BmW: return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	return 'Error: Resolver Failed ARABSEED',[],[]
def DIHBeTNura(i8sFwPqo1vpEXR2VdHU5BmW):
	if '_action=getserver' in i8sFwPqo1vpEXR2VdHU5BmW:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',i8sFwPqo1vpEXR2VdHU5BmW,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = WM1buqXnzf3Ba6Vp29l4gFD.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('postid=(.*?)&serverid=(.*?)$',i8sFwPqo1vpEXR2VdHU5BmW,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		if not eHquV9G0n2wlLjOvC5PUW: eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('_post_id=(.*?)&serverid=(.*?)$',i8sFwPqo1vpEXR2VdHU5BmW,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		GdflFVny9zZNjP1kX2hIY,Q3JykLsCBquDPihaMNV = eHquV9G0n2wlLjOvC5PUW[0]
		dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'url')
		url = dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':GdflFVny9zZNjP1kX2hIY,'i':Q3JykLsCBquDPihaMNV}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':i8sFwPqo1vpEXR2VdHU5BmW}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		if ll9khUfx3MjZ:
			ll9khUfx3MjZ = ll9khUfx3MjZ[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def pIfz6dFPvoNqV(o34xXcfyhs5nU6EbOSNGkYQCWlJLtF):
	PPFUe5Zl9TiNC1BOqMWLnHkRtE = YTPut68WBVUNCvsEzg.getSetting('av.akwam.verification')
	headers = {'Cookie':PPFUe5Zl9TiNC1BOqMWLnHkRtE} if PPFUe5Zl9TiNC1BOqMWLnHkRtE else ''
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	PipCYfuKX9x5EoTODWZdmgU = WM1buqXnzf3Ba6Vp29l4gFD.content
	nY3gKELh2d8XzaRGkvsHW = str(WM1buqXnzf3Ba6Vp29l4gFD.headers)
	Df0KwutoyVrIcTzHF6xNXOg = nY3gKELh2d8XzaRGkvsHW+PipCYfuKX9x5EoTODWZdmgU
	if '.mp4' in Df0KwutoyVrIcTzHF6xNXOg: C4aOhQx81J = True
	else:
		lzQ5FEUab7hvtVMT1HCAksK2,cGaExo7bmhAn2QwIgMpWfzO,d20HRlF9nXEIarJDo3vS,Jjr9GPXqV5auth0meLHd1g4KU,C4aOhQx81J = '','','','',False
		captcha = T072lCzjYiuaeFtmJGV.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',PipCYfuKX9x5EoTODWZdmgU,T072lCzjYiuaeFtmJGV.DOTALL)
		if captcha: d20HRlF9nXEIarJDo3vS,Jjr9GPXqV5auth0meLHd1g4KU = captcha[0]
		TREqzG41s7Pelw3YcJHA8dILXCOSU = tOnYIHVk4xydqwoLEBKiDN0hX['PYTHON'][7]
		mXzxhH68tSFg = au8Umt9dq1KLSYb(32)
		if 0:
			data = {'user':mXzxhH68tSFg,'version':pQmoyUJBNaf72A,'url':o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'key':Jjr9GPXqV5auth0meLHd1g4KU,'id':'','job':'geturls'}
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',TREqzG41s7Pelw3YcJHA8dILXCOSU,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		qQXuaKpVrGLF3e5oidJ8YwDT0 = ''
		if qQXuaKpVrGLF3e5oidJ8YwDT0.startswith('URLS='):
			fRUZX4eznc6x2C9d8aptBWuiTS = cwiLy4IAVJj0pWCl7FGxokR('list',qQXuaKpVrGLF3e5oidJ8YwDT0.split('URLS=',1)[1])
			for iYvJPtR357SbyQf1 in fRUZX4eznc6x2C9d8aptBWuiTS:
				url = iYvJPtR357SbyQf1['url']
				p8IuEO9xYm6PgHJri = iYvJPtR357SbyQf1['method']
				data = iYvJPtR357SbyQf1['data']
				headers = iYvJPtR357SbyQf1['headers']
				WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,p8IuEO9xYm6PgHJri,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				PipCYfuKX9x5EoTODWZdmgU = WM1buqXnzf3Ba6Vp29l4gFD.content
				if '.mp4' in PipCYfuKX9x5EoTODWZdmgU:
					C4aOhQx81J = True
					break
				nY3gKELh2d8XzaRGkvsHW = str(WM1buqXnzf3Ba6Vp29l4gFD.headers)
				Df0KwutoyVrIcTzHF6xNXOg = nY3gKELh2d8XzaRGkvsHW+PipCYfuKX9x5EoTODWZdmgU
				lzQ5FEUab7hvtVMT1HCAksK2 = T072lCzjYiuaeFtmJGV.findall('(akwamVerification\w+).*?"(eyJ.*?)"',Df0KwutoyVrIcTzHF6xNXOg,T072lCzjYiuaeFtmJGV.DOTALL)
				cGaExo7bmhAn2QwIgMpWfzO = T072lCzjYiuaeFtmJGV.findall('recaptcha-token.*?"(03A.*?)"',Df0KwutoyVrIcTzHF6xNXOg,T072lCzjYiuaeFtmJGV.DOTALL)
				if cGaExo7bmhAn2QwIgMpWfzO: cGaExo7bmhAn2QwIgMpWfzO = cGaExo7bmhAn2QwIgMpWfzO[0]
				if lzQ5FEUab7hvtVMT1HCAksK2 or cGaExo7bmhAn2QwIgMpWfzO: break
		if not C4aOhQx81J:
			if not lzQ5FEUab7hvtVMT1HCAksK2:
				if captcha and not cGaExo7bmhAn2QwIgMpWfzO:
					if 1: cGaExo7bmhAn2QwIgMpWfzO = MMamWDNQ3POk9n4Z5htplgFXCJE(Jjr9GPXqV5auth0meLHd1g4KU,'ar',o34xXcfyhs5nU6EbOSNGkYQCWlJLtF)
					else:
						if not qQXuaKpVrGLF3e5oidJ8YwDT0.startswith('ID='):
							data = {'user':mXzxhH68tSFg,'version':pQmoyUJBNaf72A,'url':o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'key':Jjr9GPXqV5auth0meLHd1g4KU,'id':'','job':'getid'}
							WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',TREqzG41s7Pelw3YcJHA8dILXCOSU,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
						else: qQXuaKpVrGLF3e5oidJ8YwDT0 = 'ID=1234::::TIMEOUT=45'
						if qQXuaKpVrGLF3e5oidJ8YwDT0.startswith('ID='):
							pr5vDZygqMz2L = T072lCzjYiuaeFtmJGV.findall('ID=(.*?)::::TIMEOUT=(.*?)$',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
							ll3Zi9rnDJTYvCsMwdh0GRX,hZYTKSaABQCofcrFlgsI = pr5vDZygqMz2L[0]
							F67qZAgMjPukRfJ = 'هذه العملية تحتاج وقت من 10 إلى '+hZYTKSaABQCofcrFlgsI+' ثانية'
							GwL9s6vAgzS0naR5Yc7ETm2xFO = RNrYlESg2f0OLJnG7wQ()
							GwL9s6vAgzS0naR5Yc7ETm2xFO.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',F67qZAgMjPukRfJ)
							dLr6KtnqZsPXY3OHp5bD = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
							hhIdbw4FCUArg9MJ7Kpvtou,s3JAf7CwnLYH1aDeIl = 0,0
							while hhIdbw4FCUArg9MJ7Kpvtou<int(hZYTKSaABQCofcrFlgsI):
								pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,int(hhIdbw4FCUArg9MJ7Kpvtou/int(hZYTKSaABQCofcrFlgsI)*100),F67qZAgMjPukRfJ,'',hZYTKSaABQCofcrFlgsI+' / '+str(int(hhIdbw4FCUArg9MJ7Kpvtou))+'  ثانية')
								if hhIdbw4FCUArg9MJ7Kpvtou>s3JAf7CwnLYH1aDeIl+10:
									data = {'user':mXzxhH68tSFg,'version':pQmoyUJBNaf72A,'url':o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'key':Jjr9GPXqV5auth0meLHd1g4KU,'id':ll3Zi9rnDJTYvCsMwdh0GRX,'job':'gettoken'}
									WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',TREqzG41s7Pelw3YcJHA8dILXCOSU,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
									if qQXuaKpVrGLF3e5oidJ8YwDT0.startswith('TOKEN='):
										cGaExo7bmhAn2QwIgMpWfzO = qQXuaKpVrGLF3e5oidJ8YwDT0.split('TOKEN=',1)[1]
										break
									s3JAf7CwnLYH1aDeIl = hhIdbw4FCUArg9MJ7Kpvtou
								else: D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(1)
								hhIdbw4FCUArg9MJ7Kpvtou = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()-dLr6KtnqZsPXY3OHp5bD
							GwL9s6vAgzS0naR5Yc7ETm2xFO.close()
				if cGaExo7bmhAn2QwIgMpWfzO:
					Ci3cQ6bLZfT28ewJtx1U7NrEDhR = WM1buqXnzf3Ba6Vp29l4gFD.cookies
					d7JzUectu63V9M = T072lCzjYiuaeFtmJGV.findall('akwam_session=(.*?);',Df0KwutoyVrIcTzHF6xNXOg,T072lCzjYiuaeFtmJGV.DOTALL)
					if 'akwam_session' in list(Ci3cQ6bLZfT28ewJtx1U7NrEDhR.keys()): d7JzUectu63V9M = Ci3cQ6bLZfT28ewJtx1U7NrEDhR['akwam_session']
					elif d7JzUectu63V9M: d7JzUectu63V9M = d7JzUectu63V9M[0]
					captcha = T072lCzjYiuaeFtmJGV.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',PipCYfuKX9x5EoTODWZdmgU,T072lCzjYiuaeFtmJGV.DOTALL)
					if captcha: d20HRlF9nXEIarJDo3vS,Jjr9GPXqV5auth0meLHd1g4KU = captcha[0]
					if d7JzUectu63V9M and captcha:
						headers = {'Cookie':'akwam_session='+d7JzUectu63V9M,'Referer':o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+cGaExo7bmhAn2QwIgMpWfzO
						WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'POST',d20HRlF9nXEIarJDo3vS,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						PipCYfuKX9x5EoTODWZdmgU = WM1buqXnzf3Ba6Vp29l4gFD.content
						try: cookies = WM1buqXnzf3Ba6Vp29l4gFD.cookies
						except: cookies = {}
						lzQ5FEUab7hvtVMT1HCAksK2 = T072lCzjYiuaeFtmJGV.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),T072lCzjYiuaeFtmJGV.DOTALL)
			if lzQ5FEUab7hvtVMT1HCAksK2:
				XLVqPOIzGJl6KUyQ23d9,lzQ5FEUab7hvtVMT1HCAksK2 = lzQ5FEUab7hvtVMT1HCAksK2[0]
				PPFUe5Zl9TiNC1BOqMWLnHkRtE = XLVqPOIzGJl6KUyQ23d9+'='+lzQ5FEUab7hvtVMT1HCAksK2
				YTPut68WBVUNCvsEzg.setSetting('av.akwam.verification',PPFUe5Zl9TiNC1BOqMWLnHkRtE)
				KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in PipCYfuKX9x5EoTODWZdmgU:
					headers = {'Cookie':PPFUe5Zl9TiNC1BOqMWLnHkRtE}
					WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',o34xXcfyhs5nU6EbOSNGkYQCWlJLtF,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					PipCYfuKX9x5EoTODWZdmgU = WM1buqXnzf3Ba6Vp29l4gFD.content
	if not C4aOhQx81J and not PPFUe5Zl9TiNC1BOqMWLnHkRtE: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return PipCYfuKX9x5EoTODWZdmgU
def IqinpDkyKl(url,type,Q5OAspyiXV1lx8930qLGD):
	MfIDplCLUGK91vjO,TBPSh6qZpsiHoe4w = [],[]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
	uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('<a href=".*?</a>',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in kkH5sRPxhASFowLONy4:
			if i8sFwPqo1vpEXR2VdHU5BmW in MfIDplCLUGK91vjO: continue
			if '/watch/' not in i8sFwPqo1vpEXR2VdHU5BmW and '/download/' not in i8sFwPqo1vpEXR2VdHU5BmW: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
			TBPSh6qZpsiHoe4w.append(title)
	if len(MfIDplCLUGK91vjO)>1:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('بعضها يحتاج 60 ثانية',TBPSh6qZpsiHoe4w)
		if tzgWIKy5xQL2kjm==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(MfIDplCLUGK91vjO)==1: tzgWIKy5xQL2kjm = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	o34xXcfyhs5nU6EbOSNGkYQCWlJLtF = MfIDplCLUGK91vjO[tzgWIKy5xQL2kjm]
	PipCYfuKX9x5EoTODWZdmgU = pIfz6dFPvoNqV(o34xXcfyhs5nU6EbOSNGkYQCWlJLtF)
	M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL = [],[]
	if type=='download':
		Bs1X8LGUDJHjfO2g = T072lCzjYiuaeFtmJGV.findall('btn-loader.*?href="(.*?)"',PipCYfuKX9x5EoTODWZdmgU,T072lCzjYiuaeFtmJGV.DOTALL)
		if Bs1X8LGUDJHjfO2g:
			i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(Bs1X8LGUDJHjfO2g[0])
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(Q5OAspyiXV1lx8930qLGD)
	elif type=='watch':
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('<source.*?src="(.*?)".*?size="(.*?)"',PipCYfuKX9x5EoTODWZdmgU,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,size in kkH5sRPxhASFowLONy4:
			if not i8sFwPqo1vpEXR2VdHU5BmW: continue
			if Q5OAspyiXV1lx8930qLGD in size:
				n7CuHMSJpiR9fP0jvNEIyDUL.append(size)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
				break
		if not M7oS6tLhdx3ke8qPX4mFA:
			for i8sFwPqo1vpEXR2VdHU5BmW,size in kkH5sRPxhASFowLONy4:
				if not i8sFwPqo1vpEXR2VdHU5BmW: continue
				n7CuHMSJpiR9fP0jvNEIyDUL.append(size)
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if not M7oS6tLhdx3ke8qPX4mFA: return 'Error: Resolver Failed AKWAM',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def zzSmHfGRh1(url,XLVqPOIzGJl6KUyQ23d9):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	cookies = WM1buqXnzf3Ba6Vp29l4gFD.cookies
	if 'golink' in list(cookies.keys()):
		PPFUe5Zl9TiNC1BOqMWLnHkRtE = cookies['golink']
		PPFUe5Zl9TiNC1BOqMWLnHkRtE = rygO0TzuEdiPcQDWZ8awSjm(Bd2o0J6aOASWvuD9HzY(PPFUe5Zl9TiNC1BOqMWLnHkRtE))
		items = T072lCzjYiuaeFtmJGV.findall('route":"(.*?)"',PPFUe5Zl9TiNC1BOqMWLnHkRtE,T072lCzjYiuaeFtmJGV.DOTALL)
		ll9khUfx3MjZ = items[0].replace('\/','/')
		ll9khUfx3MjZ = Bd2o0J6aOASWvuD9HzY(ll9khUfx3MjZ)
	else: ll9khUfx3MjZ = url
	if 'catch.is' in ll9khUfx3MjZ:
		id = ll9khUfx3MjZ.split('%2F')[-1]
		ll9khUfx3MjZ = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[ll9khUfx3MjZ]
	else:
		website = tOnYIHVk4xydqwoLEBKiDN0hX['AKOAM'][0]
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		xVc1uIH46j8hDKZJEBFOWNCq = WM1buqXnzf3Ba6Vp29l4gFD.url
		UUvlE7xNyOFpneaw9z82s45I = ll9khUfx3MjZ.split('/')[2]
		ee8Bi1g5OPrl0h6bjV = xVc1uIH46j8hDKZJEBFOWNCq.split('/')[2]
		dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ.replace(UUvlE7xNyOFpneaw9z82s45I,ee8Bi1g5OPrl0h6bjV)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':dCmKxk9BW310AXu4bJUHfY }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST', dCmKxk9BW310AXu4bJUHfY, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		items = T072lCzjYiuaeFtmJGV.findall('direct_link":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		if not items:
			items = T072lCzjYiuaeFtmJGV.findall('<iframe.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
			if not items:
				items = T072lCzjYiuaeFtmJGV.findall('<embed.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		if items:
			i8sFwPqo1vpEXR2VdHU5BmW = items[0].replace('\/','/')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.rstrip('/')
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:' + i8sFwPqo1vpEXR2VdHU5BmW
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('http://','https://')
			if XLVqPOIzGJl6KUyQ23d9=='': cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
			else: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = 'NEED_EXTERNAL_RESOLVERS',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
		else: cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = 'Error: Resolver Failed AKOAM',[],[]
		return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def Xzw72IlZKTcEGN6pQnDk(url):
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = T072lCzjYiuaeFtmJGV.findall('<source src="(.*?)".*?label="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,errno = [],[],''
	if items:
		for i8sFwPqo1vpEXR2VdHU5BmW,uUeNnkywGtlj36V2dX7L in items:
			n7CuHMSJpiR9fP0jvNEIyDUL.append(uUeNnkywGtlj36V2dX7L)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def l2gPqG6EF7uIB8zrLeH9UxYo(url):
	headers = {'User-Agent':''}
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = T072lCzjYiuaeFtmJGV.findall('sources: \["(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def ccABREnheoKGz(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('\\','')
	items = T072lCzjYiuaeFtmJGV.findall('file":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def UAn95Z7gX0p(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-VIDOZA-1st')
	items = T072lCzjYiuaeFtmJGV.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	for i8sFwPqo1vpEXR2VdHU5BmW,uUeNnkywGtlj36V2dX7L,tPdemXOVBsUW8bK42rRJ3CxyLv in items:
		n7CuHMSJpiR9fP0jvNEIyDUL.append(uUeNnkywGtlj36V2dX7L+' '+tPdemXOVBsUW8bK42rRJ3CxyLv)
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def Rlw0K2T9gYAsm5SNbEJpvyO73W(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = T072lCzjYiuaeFtmJGV.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	items = set(items)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	for id,EHnSrqQ7BvmGlOgYZdhTbCRtswA,hash,uUeNnkywGtlj36V2dX7L,tPdemXOVBsUW8bK42rRJ3CxyLv in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+EHnSrqQ7BvmGlOgYZdhTbCRtswA+'&hash='+hash
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = T072lCzjYiuaeFtmJGV.findall('direct link.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in items:
			n7CuHMSJpiR9fP0jvNEIyDUL.append(uUeNnkywGtlj36V2dX7L+' '+tPdemXOVBsUW8bK42rRJ3CxyLv)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if len(M7oS6tLhdx3ke8qPX4mFA)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def Td8UMu7Q0f(url):
	i8sFwPqo1vpEXR2VdHU5BmW = ''
	if 1 or 'Key=' not in url:
		ll9khUfx3MjZ = url.replace('upbom.live','uppom.live')
		ll9khUfx3MjZ = ll9khUfx3MjZ.split('/')
		id = ll9khUfx3MjZ[3]
		ll9khUfx3MjZ = '/'.join(ll9khUfx3MjZ[0:4])
		y7PU6am9Z3I = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',ll9khUfx3MjZ,y7PU6am9Z3I,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()): i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		if not i8sFwPqo1vpEXR2VdHU5BmW and WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
			i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('id="direct_link".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(WM1buqXnzf3Ba6Vp29l4gFD.headers.keys()): i8sFwPqo1vpEXR2VdHU5BmW = WM1buqXnzf3Ba6Vp29l4gFD.headers['location']
	if i8sFwPqo1vpEXR2VdHU5BmW: return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	return 'Error: Resolver Failed UPBOM',[],[]
def DCOb3kRXpoLcQhvGIzg(url):
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = T072lCzjYiuaeFtmJGV.findall('sources:.*?"(.*?)","(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	if items:
		n7CuHMSJpiR9fP0jvNEIyDUL.append('mp4')
		M7oS6tLhdx3ke8qPX4mFA.append(items[0][1])
		n7CuHMSJpiR9fP0jvNEIyDUL.append('m3u8')
		M7oS6tLhdx3ke8qPX4mFA.append(items[0][0])
		return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def sSG0U5DEax(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	ll9khUfx3MjZ = tOnYIHVk4xydqwoLEBKiDN0hX['YOUTUBE'][0]+'/watch?v='+id
	dgjZx9tLUFe8K5TA2GOJRlPbqDcm1 = 'http://youtu.be/'+id
	QocqnxjM0Yulh7LaGPNv,UxKO9HjaJSoWeLN1gtMZXcpF,ploPztDGMX85FV6QJRW14yOiC,bUOdEqWCnXTosx2paHf08VJPKFzL3 = '','','',''
	for H3ABEcMzfyqwF4Ug2ZYtK in range(5):
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',ll9khUfx3MjZ,'','','','','RESOLVERS-YOUTUBE-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		if 'itag' in qQXuaKpVrGLF3e5oidJ8YwDT0: break
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(2)
	OOvdzRcrlZwA7i3J = T072lCzjYiuaeFtmJGV.findall('var ytInitialPlayerResponse = (.*?);</script>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if OOvdzRcrlZwA7i3J: OOvdzRcrlZwA7i3J = OOvdzRcrlZwA7i3J[0]
	else: OOvdzRcrlZwA7i3J = qQXuaKpVrGLF3e5oidJ8YwDT0
	OOvdzRcrlZwA7i3J = OOvdzRcrlZwA7i3J.replace('\\u0026','&')
	U1UnP5T2cFeENbgpXfrWVBihmIvAzK = cwiLy4IAVJj0pWCl7FGxokR('dict',OOvdzRcrlZwA7i3J)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = ['بدون ترجمة يوتيوب'],['']
	try:
		Yn1Ojc7HGvaS8buk0W4e6m3lpxt5fD = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for ftElFqynru5UXaKjk0Q4b7g6M3 in Yn1Ojc7HGvaS8buk0W4e6m3lpxt5fD:
			i8sFwPqo1vpEXR2VdHU5BmW = ftElFqynru5UXaKjk0Q4b7g6M3['baseUrl']
			try: title = ftElFqynru5UXaKjk0Q4b7g6M3['name']['simpleText']
			except: title = ftElFqynru5UXaKjk0Q4b7g6M3['name']['runs'][0]['textt']
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
	except: pass
	if len(n7CuHMSJpiR9fP0jvNEIyDUL)>1:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الترجمة المناسبة:', n7CuHMSJpiR9fP0jvNEIyDUL)
		if tzgWIKy5xQL2kjm==-1: return 'EXIT_RESOLVER',[],[]
		elif tzgWIKy5xQL2kjm!=0:
			i8sFwPqo1vpEXR2VdHU5BmW = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]+'&'
			SK1zBoJwYrjEFuN6DsAMfdq3k = T072lCzjYiuaeFtmJGV.findall('&(fmt=.*?)&',i8sFwPqo1vpEXR2VdHU5BmW)
			if SK1zBoJwYrjEFuN6DsAMfdq3k: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace(SK1zBoJwYrjEFuN6DsAMfdq3k[0],'fmt=vtt')
			else: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'fmt=vtt'
			QocqnxjM0Yulh7LaGPNv = i8sFwPqo1vpEXR2VdHU5BmW.strip('&')
	ta4LwZDRY0WUdl7J,kURXt1AFoPJYqBGsi2bD08,AcPu3TMfI8,DOHYvCnWyJqZwRThe0A3ptVQ4zPB,WmrJ2ydMKzugoqHX8sR05YLT = [],[],[],[],[]
	try: UxKO9HjaJSoWeLN1gtMZXcpF = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['streamingData']['dashManifestUrl']
	except: pass
	try: ploPztDGMX85FV6QJRW14yOiC = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['streamingData']['hlsManifestUrl']
	except: pass
	try: ta4LwZDRY0WUdl7J = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['streamingData']['formats']
	except: pass
	try: kURXt1AFoPJYqBGsi2bD08 = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['streamingData']['adaptiveFormats']
	except: pass
	YWGqbdjnQ0aplI = ta4LwZDRY0WUdl7J+kURXt1AFoPJYqBGsi2bD08
	for dict in YWGqbdjnQ0aplI:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			usiZTXNk84HJwDgCM3f1r = dict['signatureCipher'].split('&')
			for Lw8JjEfuiW0VN9qHAcgRpMBdICS in usiZTXNk84HJwDgCM3f1r:
				key,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=',1)
				dict[key] = rygO0TzuEdiPcQDWZ8awSjm(EYn2siOeDvQTk8KpS0Jl)
		if 'url' in list(dict.keys()): dict['url'] = rygO0TzuEdiPcQDWZ8awSjm(dict['url'])
		AcPu3TMfI8.append(dict)
	iqdJQresmv1GwfaFNhK3xuE4n = ''
	if 'sp=sig' in OOvdzRcrlZwA7i3J:
		k0kK23tuoD = T072lCzjYiuaeFtmJGV.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if k0kK23tuoD:
			k0kK23tuoD = tOnYIHVk4xydqwoLEBKiDN0hX['YOUTUBE'][0]+k0kK23tuoD[0]
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',k0kK23tuoD,'','','','','RESOLVERS-YOUTUBE-2nd')
			iqdJQresmv1GwfaFNhK3xuE4n = WM1buqXnzf3Ba6Vp29l4gFD.content
			import youtube_signature.cipher as fIb9xZXVEi4dQ5t,youtube_signature.json_script_engine as WX4Uup2EdRGAtDSi6zIOYhsP8bHFJq
			usiZTXNk84HJwDgCM3f1r = V2v0Bwo6Ea4OPR7.usiZTXNk84HJwDgCM3f1r.Cipher()
			usiZTXNk84HJwDgCM3f1r._object_cache = {}
			L0LfmTP36tUHXqN1ZIrkBg = usiZTXNk84HJwDgCM3f1r._load_javascript(iqdJQresmv1GwfaFNhK3xuE4n)
			h8GerI6Qi9upJPKM0S4Z5Y7LoaDV = cwiLy4IAVJj0pWCl7FGxokR('str',str(L0LfmTP36tUHXqN1ZIrkBg))
			ahbUvwKZDVgG0LPzC = V2v0Bwo6Ea4OPR7.eXRCsHmEyuvnqB2NYL.JsonScriptEngine(h8GerI6Qi9upJPKM0S4Z5Y7LoaDV)
	for dict in AcPu3TMfI8:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			DOHYvCnWyJqZwRThe0A3ptVQ4zPB.append(dict)
		elif iqdJQresmv1GwfaFNhK3xuE4n and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			ooXZVULYITr9lFbgOPj1hpRkNxW5f7 = ahbUvwKZDVgG0LPzC.execute(dict['s'])
			if ooXZVULYITr9lFbgOPj1hpRkNxW5f7!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+ooXZVULYITr9lFbgOPj1hpRkNxW5f7
				DOHYvCnWyJqZwRThe0A3ptVQ4zPB.append(dict)
	for dict in DOHYvCnWyJqZwRThe0A3ptVQ4zPB:
		UuygfPcTR0zC,xxkHN9ChlSMgfroy,A1tJaolOLMQZcDF4gn,zgs5N10mMd9PVTRuHA4GWJDycpeLl,xGc9DBLieM4aoXS1yNOIU3TrZ,eJa6sZqgoNpGXT = 'unknown','unknown','unknown','Unknown','','0'
		try:
			dxWow29IzS = dict['type']
			dxWow29IzS = dxWow29IzS.replace('+','')
			items = T072lCzjYiuaeFtmJGV.findall('(.*?)/(.*?);.*?"(.*?)"',dxWow29IzS,T072lCzjYiuaeFtmJGV.DOTALL)
			zgs5N10mMd9PVTRuHA4GWJDycpeLl,UuygfPcTR0zC,xGc9DBLieM4aoXS1yNOIU3TrZ = items[0]
			YY5dAkNS9V = xGc9DBLieM4aoXS1yNOIU3TrZ.split(',')
			xxkHN9ChlSMgfroy = ''
			for Lw8JjEfuiW0VN9qHAcgRpMBdICS in YY5dAkNS9V: xxkHN9ChlSMgfroy += Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('.')[0]+','
			xxkHN9ChlSMgfroy = xxkHN9ChlSMgfroy.strip(',')
			if 'bitrate' in list(dict.keys()): eJa6sZqgoNpGXT = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: eJa6sZqgoNpGXT = ''
			if zgs5N10mMd9PVTRuHA4GWJDycpeLl=='textt': continue
			elif ',' in dxWow29IzS:
				zgs5N10mMd9PVTRuHA4GWJDycpeLl = 'A+V'
				A1tJaolOLMQZcDF4gn = UuygfPcTR0zC+'  '+eJa6sZqgoNpGXT+dict['size'].split('x')[1]
			elif zgs5N10mMd9PVTRuHA4GWJDycpeLl=='video':
				zgs5N10mMd9PVTRuHA4GWJDycpeLl = 'Video'
				A1tJaolOLMQZcDF4gn = eJa6sZqgoNpGXT+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+UuygfPcTR0zC
			elif zgs5N10mMd9PVTRuHA4GWJDycpeLl=='audio':
				zgs5N10mMd9PVTRuHA4GWJDycpeLl = 'Audio'
				A1tJaolOLMQZcDF4gn = eJa6sZqgoNpGXT+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+UuygfPcTR0zC
		except:
			WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
			if WzeExBTV6h!='NoneType: None\n': CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
		if 'dur=' in dict['url']: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = round(0.5+float(dict['approxDurationMs'])/1000)
		else: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = '0'
		if 'bitrate' not in list(dict.keys()): eJa6sZqgoNpGXT = dict['size'].split('x')[1]
		else: eJa6sZqgoNpGXT = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = zgs5N10mMd9PVTRuHA4GWJDycpeLl+':  '+A1tJaolOLMQZcDF4gn+'  ('+xxkHN9ChlSMgfroy+','+dict['itag']+')'
		dict['quality'] = A1tJaolOLMQZcDF4gn.split('  ')[0].split('kbps')[0]
		dict['type2'] = zgs5N10mMd9PVTRuHA4GWJDycpeLl
		dict['filetype'] = UuygfPcTR0zC
		dict['codecs'] = xGc9DBLieM4aoXS1yNOIU3TrZ
		dict['duration'] = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab
		dict['bitrate'] = eJa6sZqgoNpGXT
		WmrJ2ydMKzugoqHX8sR05YLT.append(dict)
	Pcd10gh2DVBuRUwTLplIOkK,usQIAFPh2mvZ7194oRBVG8lJpw,nRcaQZT72OKWC0GiVwtHx3oJdg8,PK63uYqpUanxMTEVDWBgo,hFMKVu6NJRvjDTXYLI = [],[],[],[],[]
	T76TvqHIX5caL29oFm8,uFizC1T7UXLBJb,alKMufYRZIqWG0d1PbSi,pizM5jhw8UR7Z,ffMJrXSQPUqmpt8ZFC9I = [],[],[],[],[]
	if UxKO9HjaJSoWeLN1gtMZXcpF:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = UxKO9HjaJSoWeLN1gtMZXcpF
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		WmrJ2ydMKzugoqHX8sR05YLT.append(dict)
	if ploPztDGMX85FV6QJRW14yOiC:
		xb5kh8zmf4XscY3NFG7awMDJIq1y,K9KRlBXQmO0bfFMhaPY2czwvJynpr = w7py6bdKn1jqMSfh(ploPztDGMX85FV6QJRW14yOiC)
		N5Ju6lo0HvRip2CDgT = list(zip(xb5kh8zmf4XscY3NFG7awMDJIq1y,K9KRlBXQmO0bfFMhaPY2czwvJynpr))
		for title,i8sFwPqo1vpEXR2VdHU5BmW in N5Ju6lo0HvRip2CDgT:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = i8sFwPqo1vpEXR2VdHU5BmW
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				Q5OAspyiXV1lx8930qLGD = title.rsplit('  ')[-3]
				if Q5OAspyiXV1lx8930qLGD.isdigit(): dict['quality'] = Q5OAspyiXV1lx8930qLGD
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			WmrJ2ydMKzugoqHX8sR05YLT.append(dict)
	WmrJ2ydMKzugoqHX8sR05YLT = sorted(WmrJ2ydMKzugoqHX8sR05YLT,reverse=True,key=lambda key: float(key['bitrate']))
	if not WmrJ2ydMKzugoqHX8sR05YLT:
		n9GNlZCisxWpEb1rqX5RAUjScJuT = T072lCzjYiuaeFtmJGV.findall('class="messagee">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		SR7NUj9vYW2B5lLai0DqF = T072lCzjYiuaeFtmJGV.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		O3PvLtuErnZygxlBzUI = T072lCzjYiuaeFtmJGV.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		yNXrMl0Q3w5uOIJZcizxKLC = T072lCzjYiuaeFtmJGV.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		try: fU2XgPWBisSyKM = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: fU2XgPWBisSyKM = ''
		try: BAwihJsX781nUyTaGfV = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: BAwihJsX781nUyTaGfV = ''
		try: k3sYylIq0DFE = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['playabilityStatus']['reason']
		except: k3sYylIq0DFE = ''
		if n9GNlZCisxWpEb1rqX5RAUjScJuT or SR7NUj9vYW2B5lLai0DqF or O3PvLtuErnZygxlBzUI or yNXrMl0Q3w5uOIJZcizxKLC or fU2XgPWBisSyKM or BAwihJsX781nUyTaGfV or k3sYylIq0DFE:
			if   n9GNlZCisxWpEb1rqX5RAUjScJuT: F67qZAgMjPukRfJ = n9GNlZCisxWpEb1rqX5RAUjScJuT[0]
			elif SR7NUj9vYW2B5lLai0DqF: F67qZAgMjPukRfJ = SR7NUj9vYW2B5lLai0DqF[0]
			elif O3PvLtuErnZygxlBzUI: F67qZAgMjPukRfJ = O3PvLtuErnZygxlBzUI[0]
			elif yNXrMl0Q3w5uOIJZcizxKLC: F67qZAgMjPukRfJ = yNXrMl0Q3w5uOIJZcizxKLC[0]
			elif fU2XgPWBisSyKM: F67qZAgMjPukRfJ = fU2XgPWBisSyKM
			elif BAwihJsX781nUyTaGfV: F67qZAgMjPukRfJ = BAwihJsX781nUyTaGfV
			elif k3sYylIq0DFE: F67qZAgMjPukRfJ = k3sYylIq0DFE
			aKuDt7orOT354Ws9CPBFxHkpmeg = F67qZAgMjPukRfJ.replace('\n','').strip(' ')
			LS3sy8gwAbrlkZtWTuhDzJCxX6 = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من الموقع والمبرمج',LS3sy8gwAbrlkZtWTuhDzJCxX6+'\n\n'+aKuDt7orOT354Ws9CPBFxHkpmeg)
			return 'Error    : Resolver YOUTUBE Failed: '+aKuDt7orOT354Ws9CPBFxHkpmeg,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	hzub3vIrs6OmnwZok8F,vvNmHwfZlxATyMUPteC,Jy6CzobDq3hBwVct1FRs2p = [],[],[]
	for dict in WmrJ2ydMKzugoqHX8sR05YLT:
		if dict['type2']=='Video':
			Pcd10gh2DVBuRUwTLplIOkK.append(dict['title'])
			T76TvqHIX5caL29oFm8.append(dict)
		elif dict['type2']=='Audio':
			usQIAFPh2mvZ7194oRBVG8lJpw.append(dict['title'])
			uFizC1T7UXLBJb.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): eJa6sZqgoNpGXT = '0'
			else: eJa6sZqgoNpGXT = dict['bitrate']
			hzub3vIrs6OmnwZok8F.append([dict,{},title,eJa6sZqgoNpGXT])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): eJa6sZqgoNpGXT = '0'
			else: eJa6sZqgoNpGXT = dict['bitrate']
			hzub3vIrs6OmnwZok8F.append([dict,{},title,eJa6sZqgoNpGXT])
			nRcaQZT72OKWC0GiVwtHx3oJdg8.append(title)
			alKMufYRZIqWG0d1PbSi.append(dict)
		KbONlmvUpsSzYEVc8wjC = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: KbONlmvUpsSzYEVc8wjC = False
			elif XK3HqaTnjpyIAuhw67CmdvBM<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: KbONlmvUpsSzYEVc8wjC = False
		if dict['type2']=='Video' and dict['init']!='0-0' and KbONlmvUpsSzYEVc8wjC==True:
			hFMKVu6NJRvjDTXYLI.append(dict['title'])
			ffMJrXSQPUqmpt8ZFC9I.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and KbONlmvUpsSzYEVc8wjC==True:
			PK63uYqpUanxMTEVDWBgo.append(dict['title'])
			pizM5jhw8UR7Z.append(dict)
	for VVuC180pjtDsfAZvLHKibhg7I45FG in pizM5jhw8UR7Z:
		njf31EqHM5msOKGIS27yCPFAVR = VVuC180pjtDsfAZvLHKibhg7I45FG['bitrate']
		for YsSVQaIBrfPxW1v7byL6AOpdtl in ffMJrXSQPUqmpt8ZFC9I:
			UVjxtw9Lua4PAJ3iGs5WfHQg7hymN2 = YsSVQaIBrfPxW1v7byL6AOpdtl['bitrate']
			eJa6sZqgoNpGXT = UVjxtw9Lua4PAJ3iGs5WfHQg7hymN2+njf31EqHM5msOKGIS27yCPFAVR
			title = YsSVQaIBrfPxW1v7byL6AOpdtl['title'].replace('Video:  ','mpd  ')
			title = title.replace(YsSVQaIBrfPxW1v7byL6AOpdtl['filetype']+'  ','')
			title = title.replace(str((float(UVjxtw9Lua4PAJ3iGs5WfHQg7hymN2*10)//1024/10))+'kbps',str((float(eJa6sZqgoNpGXT*10)//1024/10))+'kbps')
			title = title+'('+VVuC180pjtDsfAZvLHKibhg7I45FG['title'].split('(',1)[1]
			hzub3vIrs6OmnwZok8F.append([YsSVQaIBrfPxW1v7byL6AOpdtl,VVuC180pjtDsfAZvLHKibhg7I45FG,title,eJa6sZqgoNpGXT])
	hzub3vIrs6OmnwZok8F = sorted(hzub3vIrs6OmnwZok8F, reverse=True, key=lambda key: float(key[3]))
	for YsSVQaIBrfPxW1v7byL6AOpdtl,VVuC180pjtDsfAZvLHKibhg7I45FG,title,eJa6sZqgoNpGXT in hzub3vIrs6OmnwZok8F:
		rzIL3aWpjyDdkYAMXo6cVq5C2Os = YsSVQaIBrfPxW1v7byL6AOpdtl['filetype']
		if 'filetype' in list(VVuC180pjtDsfAZvLHKibhg7I45FG.keys()):
			rzIL3aWpjyDdkYAMXo6cVq5C2Os = 'mpd'
		if rzIL3aWpjyDdkYAMXo6cVq5C2Os not in Jy6CzobDq3hBwVct1FRs2p:
			Jy6CzobDq3hBwVct1FRs2p.append(rzIL3aWpjyDdkYAMXo6cVq5C2Os)
			vvNmHwfZlxATyMUPteC.append([YsSVQaIBrfPxW1v7byL6AOpdtl,VVuC180pjtDsfAZvLHKibhg7I45FG,title,eJa6sZqgoNpGXT])
	n54pjDbVSg0TyoFzt39C7KqGQArUM,Tp83QCcOPs,TGWmQq0OdBPzIAD8lJcpNorwga = [],[],0
	bYkhtroEl5dg6ViHxeB0vuDp4I,obYjv8lQgDdnrMOSVxW1s3qT = '',''
	try: bYkhtroEl5dg6ViHxeB0vuDp4I = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['videoDetails']['author']
	except: bYkhtroEl5dg6ViHxeB0vuDp4I = ''
	try: yJ0GrohNzKaltv9Ug6WkdH2w48cQB = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['videoDetails']['channelId']
	except: yJ0GrohNzKaltv9Ug6WkdH2w48cQB = ''
	if bYkhtroEl5dg6ViHxeB0vuDp4I and yJ0GrohNzKaltv9Ug6WkdH2w48cQB:
		TGWmQq0OdBPzIAD8lJcpNorwga += 1
		title = '[COLOR FFC89008]OWNER:  '+bYkhtroEl5dg6ViHxeB0vuDp4I+'[/COLOR]'
		i8sFwPqo1vpEXR2VdHU5BmW = tOnYIHVk4xydqwoLEBKiDN0hX['YOUTUBE'][0]+'/channel/'+yJ0GrohNzKaltv9Ug6WkdH2w48cQB
		n54pjDbVSg0TyoFzt39C7KqGQArUM.append(title)
		Tp83QCcOPs.append(i8sFwPqo1vpEXR2VdHU5BmW)
		try: obYjv8lQgDdnrMOSVxW1s3qT = U1UnP5T2cFeENbgpXfrWVBihmIvAzK['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for YsSVQaIBrfPxW1v7byL6AOpdtl,VVuC180pjtDsfAZvLHKibhg7I45FG,title,eJa6sZqgoNpGXT in vvNmHwfZlxATyMUPteC:
		n54pjDbVSg0TyoFzt39C7KqGQArUM.append(title) ; Tp83QCcOPs.append('highest')
	if nRcaQZT72OKWC0GiVwtHx3oJdg8: n54pjDbVSg0TyoFzt39C7KqGQArUM.append('صورة وصوت محددة') ; Tp83QCcOPs.append('muxed')
	if hzub3vIrs6OmnwZok8F: n54pjDbVSg0TyoFzt39C7KqGQArUM.append('صورة وصوت المتوفر') ; Tp83QCcOPs.append('all')
	if hFMKVu6NJRvjDTXYLI: n54pjDbVSg0TyoFzt39C7KqGQArUM.append('mpd اختر الصورة والصوت') ; Tp83QCcOPs.append('mpd')
	if Pcd10gh2DVBuRUwTLplIOkK: n54pjDbVSg0TyoFzt39C7KqGQArUM.append('صورة بدون صوت') ; Tp83QCcOPs.append('video')
	if usQIAFPh2mvZ7194oRBVG8lJpw: n54pjDbVSg0TyoFzt39C7KqGQArUM.append('صوت بدون صورة') ; Tp83QCcOPs.append('audio')
	YIQACuLnf0a = False
	while True:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ(dgjZx9tLUFe8K5TA2GOJRlPbqDcm1, n54pjDbVSg0TyoFzt39C7KqGQArUM)
		if tzgWIKy5xQL2kjm==-1: return 'EXIT_RESOLVER',[],[]
		elif tzgWIKy5xQL2kjm==0 and bYkhtroEl5dg6ViHxeB0vuDp4I:
			i8sFwPqo1vpEXR2VdHU5BmW = Tp83QCcOPs[tzgWIKy5xQL2kjm]
			ZN1A9DvqdociFsz5eVftYH4rbEgLaS = CJwTBit4NPQMu.argv[0]+'?type=folder&mode=141&name='+K3PukgCEDY(bYkhtroEl5dg6ViHxeB0vuDp4I)+'&url='+i8sFwPqo1vpEXR2VdHU5BmW
			if obYjv8lQgDdnrMOSVxW1s3qT: ZN1A9DvqdociFsz5eVftYH4rbEgLaS = ZN1A9DvqdociFsz5eVftYH4rbEgLaS+'&image='+K3PukgCEDY(obYjv8lQgDdnrMOSVxW1s3qT)
			EO9Rts0AaGuk1qpPLXCY.executebuiltin("Container.Update("+ZN1A9DvqdociFsz5eVftYH4rbEgLaS+")")
			return 'EXIT_RESOLVER',[],[]
		IXT3PBU82c54ekwMFZhQKy9t0d7ROb = Tp83QCcOPs[tzgWIKy5xQL2kjm]
		N9BXT5SsdCJ = n54pjDbVSg0TyoFzt39C7KqGQArUM[tzgWIKy5xQL2kjm]
		if IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='dash':
			bUOdEqWCnXTosx2paHf08VJPKFzL3 = UxKO9HjaJSoWeLN1gtMZXcpF
			break
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb in ['audio','video','muxed']:
			if IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='muxed': n7CuHMSJpiR9fP0jvNEIyDUL,TIB4WgZhF58DYSXvnx = nRcaQZT72OKWC0GiVwtHx3oJdg8,alKMufYRZIqWG0d1PbSi
			elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='video': n7CuHMSJpiR9fP0jvNEIyDUL,TIB4WgZhF58DYSXvnx = Pcd10gh2DVBuRUwTLplIOkK,T76TvqHIX5caL29oFm8
			elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='audio': n7CuHMSJpiR9fP0jvNEIyDUL,TIB4WgZhF58DYSXvnx = usQIAFPh2mvZ7194oRBVG8lJpw,uFizC1T7UXLBJb
			tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الملف المناسب:', n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm!=-1:
				bUOdEqWCnXTosx2paHf08VJPKFzL3 = TIB4WgZhF58DYSXvnx[tzgWIKy5xQL2kjm]['url']
				N9BXT5SsdCJ = n7CuHMSJpiR9fP0jvNEIyDUL[tzgWIKy5xQL2kjm]
				break
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='mpd':
			tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر جودة الصورة:', hFMKVu6NJRvjDTXYLI)
			if tzgWIKy5xQL2kjm!=-1:
				N9BXT5SsdCJ = hFMKVu6NJRvjDTXYLI[tzgWIKy5xQL2kjm]
				LQ1E2oMC5ZsYypdKN = ffMJrXSQPUqmpt8ZFC9I[tzgWIKy5xQL2kjm]
				tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر جودة الصوت:', PK63uYqpUanxMTEVDWBgo)
				if tzgWIKy5xQL2kjm!=-1:
					N9BXT5SsdCJ += ' + '+PK63uYqpUanxMTEVDWBgo[tzgWIKy5xQL2kjm]
					JJ9vk73jCEOwscaFldnM6Y = pizM5jhw8UR7Z[tzgWIKy5xQL2kjm]
					YIQACuLnf0a = True
					break
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='all':
			PENjQyxDO1kB8wHZArgq9mXsTpIM,N80NHLRnvZD,c3g65bXG8oNWk9LFTEnUQCAZJStRd,whHEe7z1oLSsrWAmaY84duN3fpkgQ = list(zip(*hzub3vIrs6OmnwZok8F))
			tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الملف المناسب:', c3g65bXG8oNWk9LFTEnUQCAZJStRd)
			if tzgWIKy5xQL2kjm!=-1:
				N9BXT5SsdCJ = c3g65bXG8oNWk9LFTEnUQCAZJStRd[tzgWIKy5xQL2kjm]
				LQ1E2oMC5ZsYypdKN = PENjQyxDO1kB8wHZArgq9mXsTpIM[tzgWIKy5xQL2kjm]
				if 'mpd' in c3g65bXG8oNWk9LFTEnUQCAZJStRd[tzgWIKy5xQL2kjm] and LQ1E2oMC5ZsYypdKN['url']!=UxKO9HjaJSoWeLN1gtMZXcpF:
					JJ9vk73jCEOwscaFldnM6Y = N80NHLRnvZD[tzgWIKy5xQL2kjm]
					YIQACuLnf0a = True
				else: bUOdEqWCnXTosx2paHf08VJPKFzL3 = LQ1E2oMC5ZsYypdKN['url']
				break
		elif IXT3PBU82c54ekwMFZhQKy9t0d7ROb=='highest':
			PENjQyxDO1kB8wHZArgq9mXsTpIM,N80NHLRnvZD,c3g65bXG8oNWk9LFTEnUQCAZJStRd,whHEe7z1oLSsrWAmaY84duN3fpkgQ = list(zip(*vvNmHwfZlxATyMUPteC))
			LQ1E2oMC5ZsYypdKN = PENjQyxDO1kB8wHZArgq9mXsTpIM[tzgWIKy5xQL2kjm-TGWmQq0OdBPzIAD8lJcpNorwga]
			if 'mpd' in c3g65bXG8oNWk9LFTEnUQCAZJStRd[tzgWIKy5xQL2kjm-TGWmQq0OdBPzIAD8lJcpNorwga] and LQ1E2oMC5ZsYypdKN['url']!=UxKO9HjaJSoWeLN1gtMZXcpF:
				JJ9vk73jCEOwscaFldnM6Y = N80NHLRnvZD[tzgWIKy5xQL2kjm-TGWmQq0OdBPzIAD8lJcpNorwga]
				YIQACuLnf0a = True
			else: bUOdEqWCnXTosx2paHf08VJPKFzL3 = LQ1E2oMC5ZsYypdKN['url']
			N9BXT5SsdCJ = c3g65bXG8oNWk9LFTEnUQCAZJStRd[tzgWIKy5xQL2kjm-TGWmQq0OdBPzIAD8lJcpNorwga]
			break
	if not YIQACuLnf0a: HGgAmStudL1lCiJMIDoWON = bUOdEqWCnXTosx2paHf08VJPKFzL3
	else: HGgAmStudL1lCiJMIDoWON = 'Video: '+LQ1E2oMC5ZsYypdKN['url']+' + Audio: '+JJ9vk73jCEOwscaFldnM6Y['url']
	if YIQACuLnf0a:
		ciatxLvhyIU5KzOY = int(LQ1E2oMC5ZsYypdKN['duration'])
		vNTfWEjk6qy = int(JJ9vk73jCEOwscaFldnM6Y['duration'])
		fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = str(max(ciatxLvhyIU5KzOY,vNTfWEjk6qy))
		xwRZCVyFOi5BoMz = LQ1E2oMC5ZsYypdKN['url'].replace('&','&amp;')
		T3qyauZUpcNJQkiCYEeGzgA = JJ9vk73jCEOwscaFldnM6Y['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+fOFNhC5n6laPDvK1Mtz9QYxZ0Ab+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+LQ1E2oMC5ZsYypdKN['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+LQ1E2oMC5ZsYypdKN['itag']+'" codecs="'+LQ1E2oMC5ZsYypdKN['codecs']+'" startWithSAP="1" bandwidth="'+str(LQ1E2oMC5ZsYypdKN['bitrate'])+'" width="'+str(LQ1E2oMC5ZsYypdKN['width'])+'" height="'+str(LQ1E2oMC5ZsYypdKN['height'])+'" frameRate="'+LQ1E2oMC5ZsYypdKN['fps']+'">\n'
		mpd += '<BaseURL>'+xwRZCVyFOi5BoMz+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+LQ1E2oMC5ZsYypdKN['index']+'">\n'
		mpd += '<Initialization range="'+LQ1E2oMC5ZsYypdKN['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+JJ9vk73jCEOwscaFldnM6Y['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+JJ9vk73jCEOwscaFldnM6Y['itag']+'" codecs="'+JJ9vk73jCEOwscaFldnM6Y['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+JJ9vk73jCEOwscaFldnM6Y['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+T3qyauZUpcNJQkiCYEeGzgA+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+JJ9vk73jCEOwscaFldnM6Y['index']+'">\n'
		mpd += '<Initialization range="'+JJ9vk73jCEOwscaFldnM6Y['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if mmIKCGujwM:
			import http.server as r1axtF6U9kylpY0eVq
			import http.client as AAgmFtEcjS3RkClpa
		else:
			import BaseHTTPServer as r1axtF6U9kylpY0eVq
			import httplib as AAgmFtEcjS3RkClpa
		class Sk19jTaCOJAQgDdL(r1axtF6U9kylpY0eVq.HTTPServer):
			def __init__(f1WyXHcIKdJZgUE23MOs6ST,ip='localhost',port=55055,mpd='<>'):
				f1WyXHcIKdJZgUE23MOs6ST.ip = ip
				f1WyXHcIKdJZgUE23MOs6ST.port = port
				f1WyXHcIKdJZgUE23MOs6ST.mpd = mpd
				r1axtF6U9kylpY0eVq.HTTPServer.__init__(f1WyXHcIKdJZgUE23MOs6ST,(f1WyXHcIKdJZgUE23MOs6ST.ip,f1WyXHcIKdJZgUE23MOs6ST.port),akCbJ1HAQf428xEWB)
				f1WyXHcIKdJZgUE23MOs6ST.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.threads = Zeq6ARs9joiXNQ(False)
				f1WyXHcIKdJZgUE23MOs6ST.threads.ng0pbr1xPzOWfil4ao(1,f1WyXHcIKdJZgUE23MOs6ST.Xa5IYSnBi1AU23MuCdN)
			def Xa5IYSnBi1AU23MuCdN(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.keeprunning = True
				while f1WyXHcIKdJZgUE23MOs6ST.keeprunning:
					f1WyXHcIKdJZgUE23MOs6ST.handle_request()
			def stop(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.keeprunning = False
				f1WyXHcIKdJZgUE23MOs6ST.p8Z6P4xbMi25fr()
			def xECUlywhsIHMtzc2b5Q(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.stop()
				f1WyXHcIKdJZgUE23MOs6ST.b0Y9mt5kN7ezPES.close()
				f1WyXHcIKdJZgUE23MOs6ST.server_close()
			def Ewjt7qPvdrAOKQbNB2UgYLpxi9C(f1WyXHcIKdJZgUE23MOs6ST,mpd):
				f1WyXHcIKdJZgUE23MOs6ST.mpd = mpd
			def p8Z6P4xbMi25fr(f1WyXHcIKdJZgUE23MOs6ST):
				kC7JunVyQdExXTaB = AAgmFtEcjS3RkClpa.HTTPConnection(f1WyXHcIKdJZgUE23MOs6ST.ip+':'+str(f1WyXHcIKdJZgUE23MOs6ST.port))
				kC7JunVyQdExXTaB.request("HEAD", "/")
		class akCbJ1HAQf428xEWB(r1axtF6U9kylpY0eVq.BaseHTTPRequestHandler):
			def jq9g5CGMaAZeEKYw18FJ6l03x7(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.send_response(200)
				f1WyXHcIKdJZgUE23MOs6ST.send_header('Content-type','textt/plain')
				f1WyXHcIKdJZgUE23MOs6ST.end_headers()
				f1WyXHcIKdJZgUE23MOs6ST.wfile.write(f1WyXHcIKdJZgUE23MOs6ST.dATnilvcrXxmZ1k5EP0KgBFDqYpy6.mpd.encode('utf8'))
				D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(1)
				if f1WyXHcIKdJZgUE23MOs6ST.path=='/youtube.mpd': f1WyXHcIKdJZgUE23MOs6ST.dATnilvcrXxmZ1k5EP0KgBFDqYpy6.xECUlywhsIHMtzc2b5Q()
				if f1WyXHcIKdJZgUE23MOs6ST.path=='/shutdown': f1WyXHcIKdJZgUE23MOs6ST.dATnilvcrXxmZ1k5EP0KgBFDqYpy6.xECUlywhsIHMtzc2b5Q()
			def vAX6nOWblemFd2(f1WyXHcIKdJZgUE23MOs6ST):
				f1WyXHcIKdJZgUE23MOs6ST.send_response(200)
				f1WyXHcIKdJZgUE23MOs6ST.end_headers()
		f7c9BhSi4ZjqWMDYFK1x = Sk19jTaCOJAQgDdL('127.0.0.1',55055,mpd)
		bUOdEqWCnXTosx2paHf08VJPKFzL3 = f7c9BhSi4ZjqWMDYFK1x.mpdurl
		f7c9BhSi4ZjqWMDYFK1x.start()
	else: f7c9BhSi4ZjqWMDYFK1x = ''
	if not bUOdEqWCnXTosx2paHf08VJPKFzL3: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[bUOdEqWCnXTosx2paHf08VJPKFzL3,QocqnxjM0Yulh7LaGPNv,f7c9BhSi4ZjqWMDYFK1x]]
def pfIKjkBwqX1veutcA4F(url):
	headers = { 'User-Agent' : '' }
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = T072lCzjYiuaeFtmJGV.findall('file:"(.*?)"(,label:"(.*?)"|)\}',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	xb5kh8zmf4XscY3NFG7awMDJIq1y,n7CuHMSJpiR9fP0jvNEIyDUL,K9KRlBXQmO0bfFMhaPY2czwvJynpr,M7oS6tLhdx3ke8qPX4mFA = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for i8sFwPqo1vpEXR2VdHU5BmW,O578ENGbr6PYnLJzi,uUeNnkywGtlj36V2dX7L in items:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('https:','http:')
		if '.m3u8' in i8sFwPqo1vpEXR2VdHU5BmW:
			xb5kh8zmf4XscY3NFG7awMDJIq1y,K9KRlBXQmO0bfFMhaPY2czwvJynpr = w7py6bdKn1jqMSfh(i8sFwPqo1vpEXR2VdHU5BmW)
			M7oS6tLhdx3ke8qPX4mFA = M7oS6tLhdx3ke8qPX4mFA + K9KRlBXQmO0bfFMhaPY2czwvJynpr
			if xb5kh8zmf4XscY3NFG7awMDJIq1y[0]=='-1': n7CuHMSJpiR9fP0jvNEIyDUL.append('سيرفر خاص'+'   m3u8')
			else:
				for title in xb5kh8zmf4XscY3NFG7awMDJIq1y:
					n7CuHMSJpiR9fP0jvNEIyDUL.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+uUeNnkywGtlj36V2dX7L
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
	return '',n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
def QY4sEt5AmWX2D(url,qQXuaKpVrGLF3e5oidJ8YwDT0):
	TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO,HHTf21d8OjDt,kk10UWmPHCF38aNVOdSpRIbQj6xE2,kkH5sRPxhASFowLONy4 = [],[],[],[],[]
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<video preload.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('direct_link.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		title = i8sFwPqo1vpEXR2VdHU5BmW.rsplit('.',1)[1]
		TBPSh6qZpsiHoe4w.append(title)
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	else:
		uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('sources: *(\[.*?\])',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not uuPG8BO037eSynUNE: uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('var sources = (\{.*?\})',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not uuPG8BO037eSynUNE: uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('var jw = (\{.*?\})',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not uuPG8BO037eSynUNE: uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('var player = .*?\((\{.*?\})\)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if uuPG8BO037eSynUNE:
			uuPG8BO037eSynUNE = uuPG8BO037eSynUNE[0]
			z8zfVSKTXux9rRQv6W4cos = T072lCzjYiuaeFtmJGV.findall('[,\{] *(\w+):',uuPG8BO037eSynUNE,T072lCzjYiuaeFtmJGV.DOTALL)
			for key in list(set(z8zfVSKTXux9rRQv6W4cos)): uuPG8BO037eSynUNE = uuPG8BO037eSynUNE.replace(key+':','"'+key+'":')
			uuPG8BO037eSynUNE = eval(uuPG8BO037eSynUNE)
			if isinstance(uuPG8BO037eSynUNE,dict): uuPG8BO037eSynUNE = [uuPG8BO037eSynUNE]
			for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
				if isinstance(Zsh7mUdwjHobLyMz6WKJGVl1cgeR,dict):
					keys = list(Zsh7mUdwjHobLyMz6WKJGVl1cgeR.keys())
					if 'file' in keys: i8sFwPqo1vpEXR2VdHU5BmW = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['file']
					elif 'hls' in keys: i8sFwPqo1vpEXR2VdHU5BmW = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['hls']
					if 'label' in keys: title = str(Zsh7mUdwjHobLyMz6WKJGVl1cgeR['label'])
					elif 'video_height' in keys: title = str(Zsh7mUdwjHobLyMz6WKJGVl1cgeR['video_height'])
					else: title = i8sFwPqo1vpEXR2VdHU5BmW.rsplit('.',1)[1]
				elif isinstance(Zsh7mUdwjHobLyMz6WKJGVl1cgeR,str):
					i8sFwPqo1vpEXR2VdHU5BmW = Zsh7mUdwjHobLyMz6WKJGVl1cgeR
					title = i8sFwPqo1vpEXR2VdHU5BmW.rsplit('.',1)[1]
				TBPSh6qZpsiHoe4w.append(title)
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in zip(MfIDplCLUGK91vjO,TBPSh6qZpsiHoe4w):
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\\/','/')
		Zf5QgUxKW7FCOuBIdMh8swkn = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
		zslrWLD38jgdn = diwUZMEagkFDlS()
		if '.m3u8' in i8sFwPqo1vpEXR2VdHU5BmW:
			headers = {'User-Agent':zslrWLD38jgdn,'Referer':Zf5QgUxKW7FCOuBIdMh8swkn}
			ErPhwV7bD9OxSKa18uTB2qoCkzj3J,vhG1p0aQUWefwy3FmtYr5 = w7py6bdKn1jqMSfh(i8sFwPqo1vpEXR2VdHU5BmW,headers)
			kk10UWmPHCF38aNVOdSpRIbQj6xE2 += vhG1p0aQUWefwy3FmtYr5
			HHTf21d8OjDt += ErPhwV7bD9OxSKa18uTB2qoCkzj3J
		else:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'|User-Agent='+zslrWLD38jgdn+'&Referer='+Zf5QgUxKW7FCOuBIdMh8swkn
			kk10UWmPHCF38aNVOdSpRIbQj6xE2.append(i8sFwPqo1vpEXR2VdHU5BmW)
			HHTf21d8OjDt.append(title)
	cdCjtIBh0LwFUfpEYvby1oHWG,TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO = '',[],[]
	if kk10UWmPHCF38aNVOdSpRIbQj6xE2: cdCjtIBh0LwFUfpEYvby1oHWG,TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO = '',HHTf21d8OjDt,kk10UWmPHCF38aNVOdSpRIbQj6xE2
	else:
		if '<' not in qQXuaKpVrGLF3e5oidJ8YwDT0 and len(qQXuaKpVrGLF3e5oidJ8YwDT0)<100 and qQXuaKpVrGLF3e5oidJ8YwDT0: cdCjtIBh0LwFUfpEYvby1oHWG = qQXuaKpVrGLF3e5oidJ8YwDT0
		else:
			msg = T072lCzjYiuaeFtmJGV.findall('<div style=".*?">(File.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if not msg: msg = T072lCzjYiuaeFtmJGV.findall('<div class="vp_video_stub_txt">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if not msg: msg = T072lCzjYiuaeFtmJGV.findall('<h2>(Sorry.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if msg: cdCjtIBh0LwFUfpEYvby1oHWG = msg[0]
	return cdCjtIBh0LwFUfpEYvby1oHWG,TBPSh6qZpsiHoe4w,MfIDplCLUGK91vjO
def czXi2dp6ykJeBY0Hx(GcQflu2kHhxUE6TROj5D0eosJ7n1w3,url):
	global xJb7KHOliWpmkEMCIT
	url = url.strip('/')
	IwglpjXx0hoi1kLPCA,y7PU6am9Z3I = '',{}
	headers = {'User-Agent':diwUZMEagkFDlS(),'Accept-Language':'en-US,en;q=0.9'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	CQjp7guRA1z0DXhSeFivnyxbK8Mw = WM1buqXnzf3Ba6Vp29l4gFD.code
	if not isinstance(qQXuaKpVrGLF3e5oidJ8YwDT0,str): qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		x9AlD75zbKLkUECh = T072lCzjYiuaeFtmJGV.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if x9AlD75zbKLkUECh:
			try: IwglpjXx0hoi1kLPCA = Dy9cvU05WMY(x9AlD75zbKLkUECh[0])
			except: IwglpjXx0hoi1kLPCA = ''
	IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = qQXuaKpVrGLF3e5oidJ8YwDT0+IwglpjXx0hoi1kLPCA
	if '"id2"' in IIV0pUlqMoKDC9r8wy1EGT7OesJQBS or '"id"' in IIV0pUlqMoKDC9r8wy1EGT7OesJQBS:
		ADUVCYnQjoTWyOHNt1cZPFifhwbR2 = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in IIV0pUlqMoKDC9r8wy1EGT7OesJQBS: y7PU6am9Z3I = {'id2':ADUVCYnQjoTWyOHNt1cZPFifhwbR2,'op':'download2'}
		elif '"id"' in IIV0pUlqMoKDC9r8wy1EGT7OesJQBS: y7PU6am9Z3I = {'id':ADUVCYnQjoTWyOHNt1cZPFifhwbR2,'op':'download2'}
		JKf4Tsxu9S23FI7mV5DGLk = headers.copy()
		JKf4Tsxu9S23FI7mV5DGLk['Content-Type'] = 'application/x-www-form-urlencoded'
		mnV8BCoXEJxyAZtQhU62RpbraOY = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,y7PU6am9Z3I,JKf4Tsxu9S23FI7mV5DGLk,'',False,'RESOLVERS-XSHARING-2nd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = mnV8BCoXEJxyAZtQhU62RpbraOY.content
	U7TI13cnYvqaKdueoQGsz,VV9PnJzr8OetoWTUDSAh,mhqJvAWCawLuo3OdHZyGjzr0bkD4Is = QY4sEt5AmWX2D(url,IIV0pUlqMoKDC9r8wy1EGT7OesJQBS)
	xJb7KHOliWpmkEMCIT[GcQflu2kHhxUE6TROj5D0eosJ7n1w3] = U7TI13cnYvqaKdueoQGsz,VV9PnJzr8OetoWTUDSAh,mhqJvAWCawLuo3OdHZyGjzr0bkD4Is,CQjp7guRA1z0DXhSeFivnyxbK8Mw
	return
xJb7KHOliWpmkEMCIT,mnLWRSJjCYAcBgN40sv5dk = {},0
def Y8YFEzwKf7L2mVrHPkpIQ0xt1bW5Xi(url):
	global xJb7KHOliWpmkEMCIT,mnLWRSJjCYAcBgN40sv5dk
	kkH5sRPxhASFowLONy4,threads = [],[]
	mnLWRSJjCYAcBgN40sv5dk += 100
	WzkjI1xegGbUqMsuOPcf = mnLWRSJjCYAcBgN40sv5dk
	kkH5sRPxhASFowLONy4.append([1,url])
	xJb7KHOliWpmkEMCIT[WzkjI1xegGbUqMsuOPcf+1] = [None,None,None,None]
	DFLKZyQtzIu9pYSHsmUW = RZxCcFI8fw31NKP.Thread(target=czXi2dp6ykJeBY0Hx,args=(WzkjI1xegGbUqMsuOPcf+1,url))
	DFLKZyQtzIu9pYSHsmUW.start()
	DFLKZyQtzIu9pYSHsmUW.join(10)
	if not xJb7KHOliWpmkEMCIT[WzkjI1xegGbUqMsuOPcf+1][2]:
		ll9khUfx3MjZ = url.replace('/embed-','/')
		eHquV9G0n2wlLjOvC5PUW = T072lCzjYiuaeFtmJGV.findall('^(.*?://.*?)/(.*?)/(.*?)$',ll9khUfx3MjZ+'/',T072lCzjYiuaeFtmJGV.DOTALL)
		start,eLixM3GwnOmW6DkC2bJSBzf,end = eHquV9G0n2wlLjOvC5PUW[0]
		end = end.strip('/')
		d81SYGQZm4Ogc29CnFXA3b = len(eLixM3GwnOmW6DkC2bJSBzf)<4 or eLixM3GwnOmW6DkC2bJSBzf in ['file','video','videoembed']
		if not d81SYGQZm4Ogc29CnFXA3b: kkH5sRPxhASFowLONy4.append([2,start+'/embed-'+eLixM3GwnOmW6DkC2bJSBzf+'/'+end])
		if end: kkH5sRPxhASFowLONy4.append([3,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'/embed-'+end])
		if '.html' in eLixM3GwnOmW6DkC2bJSBzf:
			Wi0B9fyroz6G5t3NDkgUEnqjO = eLixM3GwnOmW6DkC2bJSBzf.replace('.html','')
			kkH5sRPxhASFowLONy4.append([4,start+'/'+Wi0B9fyroz6G5t3NDkgUEnqjO+'/'+end])
			kkH5sRPxhASFowLONy4.append([5,start+'/embed-'+Wi0B9fyroz6G5t3NDkgUEnqjO+'/'+end])
			if end: kkH5sRPxhASFowLONy4.append([6,start+'/'+Wi0B9fyroz6G5t3NDkgUEnqjO+'/embed-'+end])
		elif '.html' in end:
			H67XZMGVkOSsh4w = end.replace('.html','')
			kkH5sRPxhASFowLONy4.append([7,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'/'+H67XZMGVkOSsh4w])
			if not d81SYGQZm4Ogc29CnFXA3b: kkH5sRPxhASFowLONy4.append([8,start+'/embed-'+eLixM3GwnOmW6DkC2bJSBzf+'/'+H67XZMGVkOSsh4w])
			kkH5sRPxhASFowLONy4.append([9,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'/embed-'+H67XZMGVkOSsh4w])
		else:
			if not d81SYGQZm4Ogc29CnFXA3b: kkH5sRPxhASFowLONy4.append([10,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'.html'])
			if not d81SYGQZm4Ogc29CnFXA3b: kkH5sRPxhASFowLONy4.append([11,start+'/embed-'+eLixM3GwnOmW6DkC2bJSBzf+'.html'])
			if end: kkH5sRPxhASFowLONy4.append([12,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'/'+end+'.html'])
			if end: kkH5sRPxhASFowLONy4.append([13,start+'/'+eLixM3GwnOmW6DkC2bJSBzf+'/embed-'+end+'.html'])
		if d81SYGQZm4Ogc29CnFXA3b and end:
			end = end.replace('/embed-','/')
			kkH5sRPxhASFowLONy4.append([14,start+'/'+end])
			kkH5sRPxhASFowLONy4.append([15,start+'/embed-'+end])
			if '.html' in end:
				H67XZMGVkOSsh4w = end.replace('.html','')
				kkH5sRPxhASFowLONy4.append([16,start+'/'+H67XZMGVkOSsh4w])
				kkH5sRPxhASFowLONy4.append([17,start+'/embed-'+H67XZMGVkOSsh4w])
			else:
				kkH5sRPxhASFowLONy4.append([18,start+'/'+end+'.html'])
				kkH5sRPxhASFowLONy4.append([19,start+'/embed-'+end+'.html'])
		for WpHryfYS0dNkc9bJlgoI8ueAj3n,i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4[1:]:
			xJb7KHOliWpmkEMCIT[WzkjI1xegGbUqMsuOPcf+WpHryfYS0dNkc9bJlgoI8ueAj3n] = [None,None,None,None]
			DFLKZyQtzIu9pYSHsmUW = RZxCcFI8fw31NKP.Thread(target=czXi2dp6ykJeBY0Hx,args=(WzkjI1xegGbUqMsuOPcf+WpHryfYS0dNkc9bJlgoI8ueAj3n,i8sFwPqo1vpEXR2VdHU5BmW))
			DFLKZyQtzIu9pYSHsmUW.start()
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(0.5)
			threads.append(DFLKZyQtzIu9pYSHsmUW)
		for DFLKZyQtzIu9pYSHsmUW in threads: DFLKZyQtzIu9pYSHsmUW.join(10)
	cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = '',[],[]
	JQLDHd63Wr8FGT = []
	for WpHryfYS0dNkc9bJlgoI8ueAj3n,i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
		zXwJQjVLYFAZ51497SToy3nHcRtPua,Dj0o4Jn3kEmrHxTeaOhv6W,NN3CVkE6WpgSKOvUz,llrpRxYsyB = xJb7KHOliWpmkEMCIT[WzkjI1xegGbUqMsuOPcf+WpHryfYS0dNkc9bJlgoI8ueAj3n]
		if not M7oS6tLhdx3ke8qPX4mFA and NN3CVkE6WpgSKOvUz: n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = Dj0o4Jn3kEmrHxTeaOhv6W,NN3CVkE6WpgSKOvUz
		if not cdCjtIBh0LwFUfpEYvby1oHWG and zXwJQjVLYFAZ51497SToy3nHcRtPua: cdCjtIBh0LwFUfpEYvby1oHWG = zXwJQjVLYFAZ51497SToy3nHcRtPua
		if llrpRxYsyB: JQLDHd63Wr8FGT.append(llrpRxYsyB)
	JQLDHd63Wr8FGT = list(set(JQLDHd63Wr8FGT))
	if not cdCjtIBh0LwFUfpEYvby1oHWG and len(JQLDHd63Wr8FGT)==1:
		CQjp7guRA1z0DXhSeFivnyxbK8Mw = JQLDHd63Wr8FGT[0]
		if CQjp7guRA1z0DXhSeFivnyxbK8Mw!=200:
			if CQjp7guRA1z0DXhSeFivnyxbK8Mw<0: cdCjtIBh0LwFUfpEYvby1oHWG = 'Video page/server is not accessible'
			else:
				cdCjtIBh0LwFUfpEYvby1oHWG = 'HTTP Error: '+str(CQjp7guRA1z0DXhSeFivnyxbK8Mw)
				if mmIKCGujwM: import http.client as AAgmFtEcjS3RkClpa
				else: import httplib as AAgmFtEcjS3RkClpa
				cdCjtIBh0LwFUfpEYvby1oHWG += ' ( '+AAgmFtEcjS3RkClpa.responses[CQjp7guRA1z0DXhSeFivnyxbK8Mw]+' )'
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(1)
	return cdCjtIBh0LwFUfpEYvby1oHWG,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA
class YgionrulIyA0Uj9(Ko1p5u9jwG6rF.WindowDialog):
	def __init__(f1WyXHcIKdJZgUE23MOs6ST, *args, **oath1QSqOAzuCjpGPZDE8n):
		dZGDM8Ku0Rrk = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA, 'resources', 'images', 'DialogBack2.png')
		ARyV7d1euk6f9P = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA, 'resources', 'images', 'checked.png')
		rqxTp6IPbDWaNvR4VOsy = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA, 'resources', 'skins', 'Default', 'media', 'button-fo.png')
		Kyv1CrYk0jH5ASNRQBM3qahG6 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA, 'resources', 'skins', 'Default', 'media', 'button-nofo.png')
		f1WyXHcIKdJZgUE23MOs6ST.cancelled = False
		f1WyXHcIKdJZgUE23MOs6ST.chk = [0] * 9
		f1WyXHcIKdJZgUE23MOs6ST.chkbutton = [0] * 9
		f1WyXHcIKdJZgUE23MOs6ST.chkstate = [False] * 9
		Soqcw2JeFh, UUzkKCBWp6gseaZGDlr75dAv, PIKN8b1dxXRetGmuhynAJV, FNZQKotnBEiRjwzkOq = 436, 210, 408, 300
		KEgYcGz39yW0aRCX1qsv4wk58Ip, sDy2RZPbzYmMrxtHQF10 = FNZQKotnBEiRjwzkOq // 3, PIKN8b1dxXRetGmuhynAJV // 3
		fXOszq4cemkpA1QV5IdFa6RGE = 70
		LL68ZCiz9eUVf527 = 70
		WRxoY3N0Dt1JkFI2eSgqfvmc = 40
		IIuz0HKvbTadYFCskmnM5pQqBxieNL = 40
		hIDnBkXHq37C1KWQ4ZFexu8MbOS = UUzkKCBWp6gseaZGDlr75dAv + FNZQKotnBEiRjwzkOq + WRxoY3N0Dt1JkFI2eSgqfvmc
		eLixM3GwnOmW6DkC2bJSBzf = Soqcw2JeFh + (PIKN8b1dxXRetGmuhynAJV // 2)
		gWQo9hUmsF3auCXRY = Soqcw2JeFh - fXOszq4cemkpA1QV5IdFa6RGE
		FMlVU8TZ7QEpeI2cWCqhxjL0YA = UUzkKCBWp6gseaZGDlr75dAv - LL68ZCiz9eUVf527
		hIxPmEB93Mw6R = FNZQKotnBEiRjwzkOq + 2 * LL68ZCiz9eUVf527 + IIuz0HKvbTadYFCskmnM5pQqBxieNL + WRxoY3N0Dt1JkFI2eSgqfvmc
		B1QLxYRoJO3dk6 = PIKN8b1dxXRetGmuhynAJV + 2 * fXOszq4cemkpA1QV5IdFa6RGE
		sv3AipUGFKdxQlnEOoh9CRLk4q = Ko1p5u9jwG6rF.ControlImage(gWQo9hUmsF3auCXRY, FMlVU8TZ7QEpeI2cWCqhxjL0YA, B1QLxYRoJO3dk6, hIxPmEB93Mw6R, dZGDM8Ku0Rrk)
		f1WyXHcIKdJZgUE23MOs6ST.addControl(sv3AipUGFKdxQlnEOoh9CRLk4q)
		f1WyXHcIKdJZgUE23MOs6ST.msg = '[COLOR FFFFFF00]'+oath1QSqOAzuCjpGPZDE8n.get('msg')+'[/COLOR]'
		f1WyXHcIKdJZgUE23MOs6ST.strActionInfo = Ko1p5u9jwG6rF.ControlLabel(Soqcw2JeFh - 20 , UUzkKCBWp6gseaZGDlr75dAv - 40, PIKN8b1dxXRetGmuhynAJV + 40 , 20, f1WyXHcIKdJZgUE23MOs6ST.msg, 'font13')
		f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.strActionInfo)
		o3gHuBtrRN = Ko1p5u9jwG6rF.ControlImage(Soqcw2JeFh, UUzkKCBWp6gseaZGDlr75dAv, PIKN8b1dxXRetGmuhynAJV, FNZQKotnBEiRjwzkOq, oath1QSqOAzuCjpGPZDE8n.get('captcha'))
		f1WyXHcIKdJZgUE23MOs6ST.addControl(o3gHuBtrRN)
		f1WyXHcIKdJZgUE23MOs6ST.iteration = oath1QSqOAzuCjpGPZDE8n.get('iteration')
		f1WyXHcIKdJZgUE23MOs6ST.strActionInfo = Ko1p5u9jwG6rF.ControlLabel(Soqcw2JeFh, UUzkKCBWp6gseaZGDlr75dAv + FNZQKotnBEiRjwzkOq, PIKN8b1dxXRetGmuhynAJV, 20, 'المحاولة رقم: '+str(f1WyXHcIKdJZgUE23MOs6ST.iteration), 'font40')
		f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.strActionInfo)
		f1WyXHcIKdJZgUE23MOs6ST.cancelbutton = Ko1p5u9jwG6rF.ControlButton(eLixM3GwnOmW6DkC2bJSBzf - 110, hIDnBkXHq37C1KWQ4ZFexu8MbOS, 100, IIuz0HKvbTadYFCskmnM5pQqBxieNL, 'خروج', focusTexture=rqxTp6IPbDWaNvR4VOsy, noFocusTexture=Kyv1CrYk0jH5ASNRQBM3qahG6, alignment=2)
		f1WyXHcIKdJZgUE23MOs6ST.okbutton = Ko1p5u9jwG6rF.ControlButton(eLixM3GwnOmW6DkC2bJSBzf + 10, hIDnBkXHq37C1KWQ4ZFexu8MbOS, 100, IIuz0HKvbTadYFCskmnM5pQqBxieNL, 'استمرار', focusTexture=rqxTp6IPbDWaNvR4VOsy, noFocusTexture=Kyv1CrYk0jH5ASNRQBM3qahG6, alignment=2)
		f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
		f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.cancelbutton)
		for jV1Z7MWOa80gbwJY64nL5 in range(9):
			LacAekY7I6wpWsojTQMP = jV1Z7MWOa80gbwJY64nL5 // 3
			SgzZvuMh6HlA0Q9VmGtPd1ekWyNB = jV1Z7MWOa80gbwJY64nL5 % 3
			PUEi5ZRa9OLjWopYB8nc73vJm = Soqcw2JeFh + (sDy2RZPbzYmMrxtHQF10 * SgzZvuMh6HlA0Q9VmGtPd1ekWyNB)
			Nr5SBhyQsiTjbxKqLGFud = UUzkKCBWp6gseaZGDlr75dAv + (KEgYcGz39yW0aRCX1qsv4wk58Ip * LacAekY7I6wpWsojTQMP)
			f1WyXHcIKdJZgUE23MOs6ST.chk[jV1Z7MWOa80gbwJY64nL5] = Ko1p5u9jwG6rF.ControlImage(PUEi5ZRa9OLjWopYB8nc73vJm-10, Nr5SBhyQsiTjbxKqLGFud-15, sDy2RZPbzYmMrxtHQF10+20, KEgYcGz39yW0aRCX1qsv4wk58Ip+30, ARyV7d1euk6f9P)
			f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.chk[jV1Z7MWOa80gbwJY64nL5])
			f1WyXHcIKdJZgUE23MOs6ST.chk[jV1Z7MWOa80gbwJY64nL5].setVisible(False)
			f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5] = Ko1p5u9jwG6rF.ControlButton(PUEi5ZRa9OLjWopYB8nc73vJm-10, Nr5SBhyQsiTjbxKqLGFud-15, sDy2RZPbzYmMrxtHQF10+20, KEgYcGz39yW0aRCX1qsv4wk58Ip+30, str(jV1Z7MWOa80gbwJY64nL5 + 1), font='font1', focusTexture=rqxTp6IPbDWaNvR4VOsy, noFocusTexture=Kyv1CrYk0jH5ASNRQBM3qahG6)
			f1WyXHcIKdJZgUE23MOs6ST.addControl(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5])
		for jV1Z7MWOa80gbwJY64nL5 in range(9):
			k1LuEVh37UWb = (jV1Z7MWOa80gbwJY64nL5 // 3) * 3
			vwgchWZ3asHToAQkUy1zI7lbXi = k1LuEVh37UWb + (jV1Z7MWOa80gbwJY64nL5 + 1) % 3
			e7RLjcBU4MZ6J9uhSYC = k1LuEVh37UWb + (jV1Z7MWOa80gbwJY64nL5 - 1) % 3
			h5A4ZbEnmCa6LQ31M = (jV1Z7MWOa80gbwJY64nL5 - 3) % 9
			ssteULTfJh = (jV1Z7MWOa80gbwJY64nL5 + 3) % 9
			f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlRight(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[vwgchWZ3asHToAQkUy1zI7lbXi])
			f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlLeft(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[e7RLjcBU4MZ6J9uhSYC])
			if jV1Z7MWOa80gbwJY64nL5 <= 2:
				f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlUp(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
			else:
				f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlUp(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[h5A4ZbEnmCa6LQ31M])
			if jV1Z7MWOa80gbwJY64nL5 >= 6:
				f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlDown(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
			else:
				f1WyXHcIKdJZgUE23MOs6ST.chkbutton[jV1Z7MWOa80gbwJY64nL5].controlDown(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[ssteULTfJh])
		f1WyXHcIKdJZgUE23MOs6ST.okbutton.controlLeft(f1WyXHcIKdJZgUE23MOs6ST.cancelbutton)
		f1WyXHcIKdJZgUE23MOs6ST.okbutton.controlRight(f1WyXHcIKdJZgUE23MOs6ST.cancelbutton)
		f1WyXHcIKdJZgUE23MOs6ST.cancelbutton.controlLeft(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
		f1WyXHcIKdJZgUE23MOs6ST.cancelbutton.controlRight(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
		f1WyXHcIKdJZgUE23MOs6ST.okbutton.controlDown(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[2])
		f1WyXHcIKdJZgUE23MOs6ST.okbutton.controlUp(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[8])
		f1WyXHcIKdJZgUE23MOs6ST.cancelbutton.controlDown(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[0])
		f1WyXHcIKdJZgUE23MOs6ST.cancelbutton.controlUp(f1WyXHcIKdJZgUE23MOs6ST.chkbutton[6])
		f1WyXHcIKdJZgUE23MOs6ST.setFocus(f1WyXHcIKdJZgUE23MOs6ST.okbutton)
	def get(f1WyXHcIKdJZgUE23MOs6ST):
		f1WyXHcIKdJZgUE23MOs6ST.doModal()
		f1WyXHcIKdJZgUE23MOs6ST.close()
		if not f1WyXHcIKdJZgUE23MOs6ST.cancelled:
			return [jV1Z7MWOa80gbwJY64nL5 for jV1Z7MWOa80gbwJY64nL5 in range(9) if f1WyXHcIKdJZgUE23MOs6ST.chkstate[jV1Z7MWOa80gbwJY64nL5]]
	def zJIPBAVpRjHr7vYSQD4XLmGwKday(f1WyXHcIKdJZgUE23MOs6ST, ptfwoaiA1ue0XIWHQcTF4NDSLj):
		if ptfwoaiA1ue0XIWHQcTF4NDSLj.getId() == f1WyXHcIKdJZgUE23MOs6ST.okbutton.getId() and any(f1WyXHcIKdJZgUE23MOs6ST.chkstate):
			f1WyXHcIKdJZgUE23MOs6ST.close()
		elif ptfwoaiA1ue0XIWHQcTF4NDSLj.getId() == f1WyXHcIKdJZgUE23MOs6ST.cancelbutton.getId():
			f1WyXHcIKdJZgUE23MOs6ST.cancelled = True
			f1WyXHcIKdJZgUE23MOs6ST.close()
		else:
			uUeNnkywGtlj36V2dX7L = ptfwoaiA1ue0XIWHQcTF4NDSLj.getLabel()
			if uUeNnkywGtlj36V2dX7L.isnumeric():
				index = int(uUeNnkywGtlj36V2dX7L) - 1
				f1WyXHcIKdJZgUE23MOs6ST.chkstate[index] = not f1WyXHcIKdJZgUE23MOs6ST.chkstate[index]
				f1WyXHcIKdJZgUE23MOs6ST.chk[index].setVisible(f1WyXHcIKdJZgUE23MOs6ST.chkstate[index])
	def aaEy9oMncXjDZVSrl8YzBw(f1WyXHcIKdJZgUE23MOs6ST, h1TjpURlEnxKH):
		if h1TjpURlEnxKH == 10:
			f1WyXHcIKdJZgUE23MOs6ST.cancelled = True
			f1WyXHcIKdJZgUE23MOs6ST.close()
def MMamWDNQ3POk9n4Z5htplgFXCJE(key,epouLG68wMUYWC91aRhKmn4xA,url):
	headers = {'Referer':url,'Accept-Language':epouLG68wMUYWC91aRhKmn4xA}
	lVCta2ZxnkYqXjfURdo = 'http://www.google.com/recaptcha/api/fallback?k='+key
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',lVCta2ZxnkYqXjfURdo,'',headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	cGaExo7bmhAn2QwIgMpWfzO,iteration = '',0
	while True:
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		y7PU6am9Z3I = T072lCzjYiuaeFtmJGV.findall('"(/recaptcha/api2/payload[^"]+)', qQXuaKpVrGLF3e5oidJ8YwDT0)
		iteration += 1
		message = T072lCzjYiuaeFtmJGV.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', qQXuaKpVrGLF3e5oidJ8YwDT0)
		if not message: message = T072lCzjYiuaeFtmJGV.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', qQXuaKpVrGLF3e5oidJ8YwDT0)
		if not message:
			cGaExo7bmhAn2QwIgMpWfzO = T072lCzjYiuaeFtmJGV.findall('readonly>(.*?)<', qQXuaKpVrGLF3e5oidJ8YwDT0)[0]
			break
		else:
			message = message[0]
			y7PU6am9Z3I = y7PU6am9Z3I[0]
		P7tpiD3K1urI9AGbHoXMvLZVzRYThx = T072lCzjYiuaeFtmJGV.findall(r'name="c"\s+value="([^"]+)', qQXuaKpVrGLF3e5oidJ8YwDT0)[0]
		zl4xDPBR1pdY = 'https://www.google.com%s' % (y7PU6am9Z3I.replace('&amp;', '&'))
		message = T072lCzjYiuaeFtmJGV.sub('</?(div|strong)[^>]*>', '', message)
		pFKDodLUeE3NAuVjB2ZcsR6rf = YgionrulIyA0Uj9(captcha=zl4xDPBR1pdY, msg=message, iteration=iteration)
		KjiSVgw9kbYXsq = pFKDodLUeE3NAuVjB2ZcsR6rf.get()
		if not KjiSVgw9kbYXsq: break
		data = {'c': P7tpiD3K1urI9AGbHoXMvLZVzRYThx, 'response': KjiSVgw9kbYXsq}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'POST',lVCta2ZxnkYqXjfURdo,data,headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return cGaExo7bmhAn2QwIgMpWfzO
def hKiRs9zZ1Qp6GjTDF3O(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = T072lCzjYiuaeFtmJGV.findall('color="red">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def QHt0YRzA4k9U(url):
	return '',[''],[ url ]
def R3qtrDJ0XiShkof65wOd4mgP(url):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = url.split('/')
	j6jeLAMbDUtN092SzFTsd3kKCg = '/'.join(dATnilvcrXxmZ1k5EP0KgBFDqYpy6[0:3])
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = T072lCzjYiuaeFtmJGV.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,fcQ2I84FpMSvUCt05ldNjeD,mmuHB5zZno14tFrkidc6SPaVYyAvE,kd1SNJ9KqT5ZDm,wQJZjCTFzAKgEDN4s3YMUxrvo8SI = items[0]
		X17rpnZfBT9msy0ltMo4bg = int(dTeA53v4wIscoMEGl2YUkF) % int(fcQ2I84FpMSvUCt05ldNjeD) + int(mmuHB5zZno14tFrkidc6SPaVYyAvE) % int(kd1SNJ9KqT5ZDm)
		url = j6jeLAMbDUtN092SzFTsd3kKCg + INqwL4fDcG6reb5Oay + str(X17rpnZfBT9msy0ltMo4bg) + wQJZjCTFzAKgEDN4s3YMUxrvo8SI
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def XdP3eguvyl6Ww2rHokZQf(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	y7PU6am9Z3I = { "id":id , "op":"download2" }
	iYvJPtR357SbyQf1 = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST', url, y7PU6am9Z3I, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(iYvJPtR357SbyQf1.headers.keys()): i8sFwPqo1vpEXR2VdHU5BmW = iYvJPtR357SbyQf1.headers['Location']
	else: i8sFwPqo1vpEXR2VdHU5BmW = url
	if i8sFwPqo1vpEXR2VdHU5BmW: return '',[''],[i8sFwPqo1vpEXR2VdHU5BmW]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def J2J3amkXfxjcg(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = T072lCzjYiuaeFtmJGV.findall('mp4: \[\'(.*?)\'',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def Z4UjIzq3ntWbOFeJxfMChDdl(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def HHNUXLIakeiOQ9Tqw3ryZ(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'','','','RESOLVERS-ESTREAM-1st')
	items = T072lCzjYiuaeFtmJGV.findall('video preload.*?src=.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'KARBALATV'
JJCLnkX4TozH7Bsjivfe = '_KRB_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
headers = {'User-Agent':''}
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==320: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==321: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==322: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==329: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',329,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/video.php','',headers,'','','KARBALATV-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="icono-plus"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title=='المكتبة المرئية': continue
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,321)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','KARBALATV-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="container"(.*?)class="footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,title in items:
		count = count.replace('عدد ','').replace(' ','')
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('/','')
		o3gHuBtrRN = o3gHuBtrRN.replace("'",'')
		if '.php' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'video.php'+i8sFwPqo1vpEXR2VdHU5BmW
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		o3gHuBtrRN = HbiLZQKalC+o3gHuBtrRN
		title = title.strip(' ')
		title = title+' ('+count+')'
		if 'video.php' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,321,o3gHuBtrRN)
		elif 'watch.php' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,322,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)class="footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video.php'+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,321)
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',headers,'','','KARBALATV-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<video.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW[0]
	pidYDcjvhgVfqb3GeWSAOH5J(i8sFwPqo1vpEXR2VdHU5BmW,nO6ukabcldeU,'video')
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/search.php?q='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
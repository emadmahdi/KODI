# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'GLOBALSEARCH'
JJCLnkX4TozH7Bsjivfe = '_GLS_'
def F5M9LsnokGPEQ2XYfO7cuyr(EHnSrqQ7BvmGlOgYZdhTbCRtswA,HHPwg71GEVju,yv8XxUjorzB2CRA4Jife73VMklHp,ffGe7cURW0lhJVvQAiw8IB):
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==540: cLCisPE3lX = lD8xr3zag19KuC()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==541: cLCisPE3lX = tPpcBoOWdvymM4e8(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==542: cLCisPE3lX = yLOWfcotnlxwGuP04b(yv8XxUjorzB2CRA4Jife73VMklHp,HHPwg71GEVju,ffGe7cURW0lhJVvQAiw8IB)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==549: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(yv8XxUjorzB2CRA4Jife73VMklHp)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','بحث جديد','',549)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	F9FKl1Q0PharbEds6B = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'dict','GLOBALSEARCH_SITES')
	if F9FKl1Q0PharbEds6B:
		F9FKl1Q0PharbEds6B = F9FKl1Q0PharbEds6B['__SEQUENCED_COLUMNS__']
		for NkA8uQ3zHaRq in reversed(F9FKl1Q0PharbEds6B):
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',NkA8uQ3zHaRq,'',549,'','',NkA8uQ3zHaRq)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(NkA8uQ3zHaRq):
	if not NkA8uQ3zHaRq:
		NkA8uQ3zHaRq = NWs7KpjXGnxYylofHtd5U3wDh()
		if not NkA8uQ3zHaRq: return
		NkA8uQ3zHaRq = NkA8uQ3zHaRq.lower()
	BRr98n5Uduzh = NkA8uQ3zHaRq.replace(JJCLnkX4TozH7Bsjivfe,'')
	HKCobLcsG1(BRr98n5Uduzh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','عمل بحث جماعي - '+BRr98n5Uduzh,'search_sites',542,'','',BRr98n5Uduzh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','نتائج البحث مفصلة - '+BRr98n5Uduzh,'opened_sites',542,'','',BRr98n5Uduzh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','نتائج البحث مقسمة - '+BRr98n5Uduzh,'listed_sites',542,'','',BRr98n5Uduzh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','بحث منفرد - '+BRr98n5Uduzh,'',541,'','',BRr98n5Uduzh)
	return
def HKCobLcsG1(ctWbzVZC1xRhi0j):
	LVeZRKW9x74Y0mOb = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_SITES',ctWbzVZC1xRhi0j)
	I3kcaLtjKzrqD2dEGe7b = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_SITES',JJCLnkX4TozH7Bsjivfe+ctWbzVZC1xRhi0j)
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES',ctWbzVZC1xRhi0j)
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES',JJCLnkX4TozH7Bsjivfe+ctWbzVZC1xRhi0j)
	f0fzA1Y9PCsdHoQ7agI5FpBWXK6 = LVeZRKW9x74Y0mOb+I3kcaLtjKzrqD2dEGe7b
	if f0fzA1Y9PCsdHoQ7agI5FpBWXK6: ctWbzVZC1xRhi0j = JJCLnkX4TozH7Bsjivfe+ctWbzVZC1xRhi0j
	rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES',ctWbzVZC1xRhi0j,f0fzA1Y9PCsdHoQ7agI5FpBWXK6,l7S6tnfTxVX4QyHohFMCrOW15Em)
	return
def a4axKfpszNO():
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if VjwKs4GNQZ518kCl!=1: return
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES')
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_OPENED')
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_CLOSED')
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def yLOWfcotnlxwGuP04b(qyo3PujHMZwe7pLTRKrvXhd2BGCS9l,wg9O0kUl2Qf5sdhHBe1n,vuyTFsAd72wDBiUPSnft5obMjErR6=''):
	bat9kDIyhSOQX,llhXq0ouG36JZEbdVL8IYygU,IRMQ2kSh8xzL,qqcB6rCIRso1SZbwv4uKHx,SnC1UPKdZYxe,UmQGwrTec423oR,BOkCIbYEmHpLj = [],[],[],{},{},{},{}
	if wg9O0kUl2Qf5sdhHBe1n!='search_sites':
		if wg9O0kUl2Qf5sdhHBe1n=='listed_sites': IRMQ2kSh8xzL = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_SITES',JJCLnkX4TozH7Bsjivfe+qyo3PujHMZwe7pLTRKrvXhd2BGCS9l)
		elif wg9O0kUl2Qf5sdhHBe1n=='opened_sites': IRMQ2kSh8xzL = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_OPENED',qyo3PujHMZwe7pLTRKrvXhd2BGCS9l)
		elif wg9O0kUl2Qf5sdhHBe1n=='closed_sites': IRMQ2kSh8xzL = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_CLOSED',(vuyTFsAd72wDBiUPSnft5obMjErR6,qyo3PujHMZwe7pLTRKrvXhd2BGCS9l))
	if not IRMQ2kSh8xzL:
		n9GNlZCisxWpEb1rqX5RAUjScJuT = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		SR7NUj9vYW2B5lLai0DqF = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+qyo3PujHMZwe7pLTRKrvXhd2BGCS9l+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if wg9O0kUl2Qf5sdhHBe1n=='search_sites': F67qZAgMjPukRfJ = SR7NUj9vYW2B5lLai0DqF
		else: F67qZAgMjPukRfJ = n9GNlZCisxWpEb1rqX5RAUjScJuT+SR7NUj9vYW2B5lLai0DqF
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR('','','','رسالة من المبرمج',F67qZAgMjPukRfJ)
		if VjwKs4GNQZ518kCl!=1: return
		TuLb46ZoWU85Vt3laJGEhvRyIKwrz(False,False,False)
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Search For: [ '+qyo3PujHMZwe7pLTRKrvXhd2BGCS9l+' ]')
		ZrnTNwjIxfQVSh4eWXki7 = 1
		for vuyTFsAd72wDBiUPSnft5obMjErR6 in yqHNLWzGFIVwRTu:
			qqcB6rCIRso1SZbwv4uKHx[vuyTFsAd72wDBiUPSnft5obMjErR6] = []
			qpXBSH0v2uyR7lEiIftkeKYMcCD = '_NODIALOGS_'
			if '-' in vuyTFsAd72wDBiUPSnft5obMjErR6: qpXBSH0v2uyR7lEiIftkeKYMcCD = qpXBSH0v2uyR7lEiIftkeKYMcCD+'_REMEMBERRESULTS__'+vuyTFsAd72wDBiUPSnft5obMjErR6+'_'
			VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac = F9CkIURDtc3wy2N8z5VdLuH7p(vuyTFsAd72wDBiUPSnft5obMjErR6)
			if ZrnTNwjIxfQVSh4eWXki7:
				D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(0.5)
				BOkCIbYEmHpLj[vuyTFsAd72wDBiUPSnft5obMjErR6] = RZxCcFI8fw31NKP.Thread(target=c0a1XqysA6duSxvCH9Twi2bD,args=(qyo3PujHMZwe7pLTRKrvXhd2BGCS9l+qpXBSH0v2uyR7lEiIftkeKYMcCD,))
				BOkCIbYEmHpLj[vuyTFsAd72wDBiUPSnft5obMjErR6].start()
			else: c0a1XqysA6duSxvCH9Twi2bD(qyo3PujHMZwe7pLTRKrvXhd2BGCS9l+qpXBSH0v2uyR7lEiIftkeKYMcCD)
			fYPz7RldWQVHBktZAexwvCL8Np3D(hqWB0vmTcxR8d3oukL(vuyTFsAd72wDBiUPSnft5obMjErR6),'',D1vBJgya85Yh4cRTCkIMKtWLSeH=1000)
		if ZrnTNwjIxfQVSh4eWXki7:
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(2)
			for vuyTFsAd72wDBiUPSnft5obMjErR6 in yqHNLWzGFIVwRTu:
				BOkCIbYEmHpLj[vuyTFsAd72wDBiUPSnft5obMjErR6].join(10)
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(2)
		for vuyTFsAd72wDBiUPSnft5obMjErR6 in yqHNLWzGFIVwRTu:
			VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac = F9CkIURDtc3wy2N8z5VdLuH7p(vuyTFsAd72wDBiUPSnft5obMjErR6)
			for MMVPRsn2G4YK6byiwvO in a26IqBkAXRPrwCOgFDb:
				ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = MMVPRsn2G4YK6byiwvO
				if GhPbjTIufD1JQMgEHSY4LqzAac in XLVqPOIzGJl6KUyQ23d9:
					if 'IPTV-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and (239>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=230 or 289>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=280):
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['IPTV-LIVE']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['IPTV-MOVIES']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['IPTV-SERIES']: continue
						if 'صفحة' not in XLVqPOIzGJl6KUyQ23d9:
							if   ga4p3IxqUXMjTRPQZfH9J5E=='live': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-LIVE'
							elif ga4p3IxqUXMjTRPQZfH9J5E=='video': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-MOVIES'
							elif ga4p3IxqUXMjTRPQZfH9J5E=='folder': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-SERIES'
						else:
							if   'LIVE' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-LIVE'
							elif 'MOVIES' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-MOVIES'
							elif 'SERIES' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IPTV-SERIES'
					elif 'M3U-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and 729>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=710:
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['M3U-LIVE']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['M3U-MOVIES']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['M3U-SERIES']: continue
						if 'صفحة' not in XLVqPOIzGJl6KUyQ23d9:
							if   ga4p3IxqUXMjTRPQZfH9J5E=='live': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-LIVE'
							elif ga4p3IxqUXMjTRPQZfH9J5E=='video': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-MOVIES'
							elif ga4p3IxqUXMjTRPQZfH9J5E=='folder': vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-SERIES'
						else:
							if   'LIVE' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-LIVE'
							elif 'MOVIES' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-MOVIES'
							elif 'SERIES' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'M3U-SERIES'
					elif 'YOUTUBE-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and 149>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=140:
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['YOUTUBE-CHANNELS']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['YOUTUBE-PLAYLISTS']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in XLVqPOIzGJl6KUyQ23d9 or ':: ' in XLVqPOIzGJl6KUyQ23d9:
							continue
						else:
							if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==144 and 'USER' in XLVqPOIzGJl6KUyQ23d9: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'YOUTUBE-CHANNELS'
							elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==144 and 'CHNL' in XLVqPOIzGJl6KUyQ23d9: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'YOUTUBE-CHANNELS'
							elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==144 and 'LIST' in XLVqPOIzGJl6KUyQ23d9: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'YOUTUBE-PLAYLISTS'
							elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==143: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and 419>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=400:
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['DAILYMOTION-PLAYLISTS']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['DAILYMOTION-CHANNELS']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['DAILYMOTION-VIDEOS']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['DAILYMOTION-TOPICS']: continue
						if   EHnSrqQ7BvmGlOgYZdhTbCRtswA in [401,405]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'DAILYMOTION-PLAYLISTS'
						elif EHnSrqQ7BvmGlOgYZdhTbCRtswA in [402,406]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'DAILYMOTION-CHANNELS'
						elif EHnSrqQ7BvmGlOgYZdhTbCRtswA in [404]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'DAILYMOTION-VIDEOS'
						elif EHnSrqQ7BvmGlOgYZdhTbCRtswA in [415]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'DAILYMOTION-LIVES'
						elif EHnSrqQ7BvmGlOgYZdhTbCRtswA in [412,413]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and 39>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=30:
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['PANET-SERIES']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['PANET-MOVIES']: continue
						if   EHnSrqQ7BvmGlOgYZdhTbCRtswA in [32,39]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'PANET-SERIES'
						elif EHnSrqQ7BvmGlOgYZdhTbCRtswA in [33,39]: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'PANET-MOVIES'
					elif 'IFILM-' in vuyTFsAd72wDBiUPSnft5obMjErR6 and 29>=EHnSrqQ7BvmGlOgYZdhTbCRtswA>=20:
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['IFILM-ARABIC']: continue
						if MMVPRsn2G4YK6byiwvO in qqcB6rCIRso1SZbwv4uKHx['IFILM-ENGLISH']: continue
						if   '/ar.' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IFILM-ARABIC'
						elif '/en.' in HHPwg71GEVju: vuyTFsAd72wDBiUPSnft5obMjErR6 = 'IFILM-ENGLISH'
					qqcB6rCIRso1SZbwv4uKHx[vuyTFsAd72wDBiUPSnft5obMjErR6].append(MMVPRsn2G4YK6byiwvO)
		a26IqBkAXRPrwCOgFDb[:] = []
		for vuyTFsAd72wDBiUPSnft5obMjErR6 in list(qqcB6rCIRso1SZbwv4uKHx.keys()):
			SnC1UPKdZYxe[vuyTFsAd72wDBiUPSnft5obMjErR6] = []
			UmQGwrTec423oR[vuyTFsAd72wDBiUPSnft5obMjErR6] = []
			for ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in qqcB6rCIRso1SZbwv4uKHx[vuyTFsAd72wDBiUPSnft5obMjErR6]:
				MMVPRsn2G4YK6byiwvO = (ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
				if 'صفحة' in XLVqPOIzGJl6KUyQ23d9 and ga4p3IxqUXMjTRPQZfH9J5E=='folder': UmQGwrTec423oR[vuyTFsAd72wDBiUPSnft5obMjErR6].append(MMVPRsn2G4YK6byiwvO)
				else: SnC1UPKdZYxe[vuyTFsAd72wDBiUPSnft5obMjErR6].append(MMVPRsn2G4YK6byiwvO)
		xIR9hOoBbNj0lsY5EWzrv23VC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for vuyTFsAd72wDBiUPSnft5obMjErR6 in GpeCN7LBKAUta4z8jPwY5ocxv0M:
			if vuyTFsAd72wDBiUPSnft5obMjErR6==QlMXWvubywKLZJa1zH[0]: xIR9hOoBbNj0lsY5EWzrv23VC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif vuyTFsAd72wDBiUPSnft5obMjErR6==QC3x0upNc4[0]: xIR9hOoBbNj0lsY5EWzrv23VC = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif vuyTFsAd72wDBiUPSnft5obMjErR6==HcECdU8G1iFh7I[0]: xIR9hOoBbNj0lsY5EWzrv23VC = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if vuyTFsAd72wDBiUPSnft5obMjErR6 not in SnC1UPKdZYxe.keys(): continue
			if SnC1UPKdZYxe[vuyTFsAd72wDBiUPSnft5obMjErR6]:
				IIZmulynP4V8eLHBSE6DJCRkT = hqWB0vmTcxR8d3oukL(vuyTFsAd72wDBiUPSnft5obMjErR6)
				QZMefdFkgrpL19HE7oSN5tz = [('link','[COLOR FFFFFF00]===== '+IIZmulynP4V8eLHBSE6DJCRkT+' =====[/COLOR]','',9999,'','','','','')]
				if 0: sERfpArD8GhvgKt5B = qyo3PujHMZwe7pLTRKrvXhd2BGCS9l+' - '+'بحث'+' '+IIZmulynP4V8eLHBSE6DJCRkT
				else: sERfpArD8GhvgKt5B = 'بحث'+' '+IIZmulynP4V8eLHBSE6DJCRkT+' - '+qyo3PujHMZwe7pLTRKrvXhd2BGCS9l
				if len(SnC1UPKdZYxe[vuyTFsAd72wDBiUPSnft5obMjErR6])<8: m2SIEcVDoxuegWlFrN3q0nGj = []
				else:
					E1EI7PCLafK = '[COLOR FFC89008]'+sERfpArD8GhvgKt5B+'[/COLOR]'
					m2SIEcVDoxuegWlFrN3q0nGj = [('folder',JJCLnkX4TozH7Bsjivfe+E1EI7PCLafK,'closed_sites',542,'',vuyTFsAd72wDBiUPSnft5obMjErR6,qyo3PujHMZwe7pLTRKrvXhd2BGCS9l,'','')]
				ywIg3AHtfmxspTdW71RE4KZ = SnC1UPKdZYxe[vuyTFsAd72wDBiUPSnft5obMjErR6]+UmQGwrTec423oR[vuyTFsAd72wDBiUPSnft5obMjErR6]
				llhXq0ouG36JZEbdVL8IYygU += xIR9hOoBbNj0lsY5EWzrv23VC+QZMefdFkgrpL19HE7oSN5tz+ywIg3AHtfmxspTdW71RE4KZ[:7]+m2SIEcVDoxuegWlFrN3q0nGj
				ZnhGETqU7KCOopF8ku2jLJel5P6Ar = [('folder',JJCLnkX4TozH7Bsjivfe+sERfpArD8GhvgKt5B,'closed_sites',542,'',vuyTFsAd72wDBiUPSnft5obMjErR6,qyo3PujHMZwe7pLTRKrvXhd2BGCS9l,'','')]
				bat9kDIyhSOQX += xIR9hOoBbNj0lsY5EWzrv23VC+ZnhGETqU7KCOopF8ku2jLJel5P6Ar
				xIR9hOoBbNj0lsY5EWzrv23VC = []
				rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_CLOSED',(vuyTFsAd72wDBiUPSnft5obMjErR6,qyo3PujHMZwe7pLTRKrvXhd2BGCS9l),ywIg3AHtfmxspTdW71RE4KZ,l7S6tnfTxVX4QyHohFMCrOW15Em)
		rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_OPENED',qyo3PujHMZwe7pLTRKrvXhd2BGCS9l,llhXq0ouG36JZEbdVL8IYygU,l7S6tnfTxVX4QyHohFMCrOW15Em)
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES',qyo3PujHMZwe7pLTRKrvXhd2BGCS9l)
		rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'GLOBALSEARCH_SITES',JJCLnkX4TozH7Bsjivfe+qyo3PujHMZwe7pLTRKrvXhd2BGCS9l,bat9kDIyhSOQX,l7S6tnfTxVX4QyHohFMCrOW15Em)
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if wg9O0kUl2Qf5sdhHBe1n=='listed_sites' and bat9kDIyhSOQX: IRMQ2kSh8xzL = bat9kDIyhSOQX
		else: IRMQ2kSh8xzL = llhXq0ouG36JZEbdVL8IYygU
	if wg9O0kUl2Qf5sdhHBe1n!='search_sites':
		for ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in IRMQ2kSh8xzL:
			if wg9O0kUl2Qf5sdhHBe1n in ['listed_sites','opened_sites'] and 'صفحة' in XLVqPOIzGJl6KUyQ23d9 and ga4p3IxqUXMjTRPQZfH9J5E=='folder': continue
			QQmLIZC8uas9fNiJWOnhdGvgFR(ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
	TuLb46ZoWU85Vt3laJGEhvRyIKwrz('','','')
	return
def tPpcBoOWdvymM4e8(qyo3PujHMZwe7pLTRKrvXhd2BGCS9l=''):
	NkA8uQ3zHaRq,qpXBSH0v2uyR7lEiIftkeKYMcCD,showDialogs = o0Vixfg9ANze1OshdmaX(qyo3PujHMZwe7pLTRKrvXhd2BGCS9l)
	if not NkA8uQ3zHaRq:
		NkA8uQ3zHaRq = NWs7KpjXGnxYylofHtd5U3wDh()
		if not NkA8uQ3zHaRq: return
		NkA8uQ3zHaRq = NkA8uQ3zHaRq.lower()
	GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Search For: [ '+NkA8uQ3zHaRq+' ]')
	xC2GuEcJKk3t4Uh = NkA8uQ3zHaRq+qpXBSH0v2uyR7lEiIftkeKYMcCD
	if 0: MtyCR0IDdUrbYevFG9WQm7nKxNkZ8,BRr98n5Uduzh = NkA8uQ3zHaRq+' - ',''
	else: MtyCR0IDdUrbYevFG9WQm7nKxNkZ8,BRr98n5Uduzh = '',' - '+NkA8uQ3zHaRq
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_M3U_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث M3U'+BRr98n5Uduzh,'',719,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_IPT_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث IPTV'+BRr98n5Uduzh,'',239,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_BKR_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع بكرا'+BRr98n5Uduzh,'',379,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_KLA_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع كل العرب'+BRr98n5Uduzh,'',19,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_ART_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع تونز عربية'+BRr98n5Uduzh,'',739,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_KRB_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع قناة كربلاء'+BRr98n5Uduzh,'',329,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_FH1_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع فاصل الأول'+BRr98n5Uduzh,'',579,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_KTV_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع كتكوت تيفي'+BRr98n5Uduzh,'',819,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_EB1_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع ايجي بيست 1'+BRr98n5Uduzh,'',779,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_EB2_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع ايجي بيست 2'+BRr98n5Uduzh,'',789,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_IFL_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'  بحث موقع قناة آي فيلم'+BRr98n5Uduzh+'  ','',29,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_AKO_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع أكوام القديم'+BRr98n5Uduzh,'',79,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_AKW_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع أكوام الجديد'+BRr98n5Uduzh,'',249,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_MRF_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع قناة المعارف'+BRr98n5Uduzh,'',49,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_SHM_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع شوف ماكس'+BRr98n5Uduzh,'',59,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_FJS_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+' بحث موقع فجر شو'+BRr98n5Uduzh+' ','',399,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TVF_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع تيفي فان'+BRr98n5Uduzh,'',469,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_LDN_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع لودي نت'+BRr98n5Uduzh,'',459,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_CMN_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما ناو'+BRr98n5Uduzh,'',309,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_WCM_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع وي سيما'+BRr98n5Uduzh,'',569,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_SHN_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع شاهد نيوز'+BRr98n5Uduzh,'',589,'','',xC2GuEcJKk3t4Uh+'_NODIALOGS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_ARS_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع عرب سييد'+BRr98n5Uduzh,'',259,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_CCB_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما كلوب'+BRr98n5Uduzh,'',829,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_SH4_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع شاهد فوريو'+BRr98n5Uduzh,'',119,'','',xC2GuEcJKk3t4Uh+'_NODIALOGS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_SHT_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع شوفها تيفي'+BRr98n5Uduzh,'',649,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_FST_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع فوستا'+BRr98n5Uduzh,'',609,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_FBK_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع فبركة'+BRr98n5Uduzh,'',629,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_YQT_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع ياقوت'+BRr98n5Uduzh,'',669,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_BRS_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع برستيج'+BRr98n5Uduzh,'',659,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_HLC_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع هلا سيما'+BRr98n5Uduzh,'',89,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_DR7_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع دراما صح'+BRr98n5Uduzh,'',689,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_CMF_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما فانز'+BRr98n5Uduzh,'',99,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_CML_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما لايت'+BRr98n5Uduzh,'',479,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_ABD_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما عبدو'+BRr98n5Uduzh,'',559,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_C4H_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع سيما 400'+BRr98n5Uduzh,'',699,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_AHK_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع أهواك تيفي'+BRr98n5Uduzh,'',619,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_EB4_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع ايجي بيست 4'+BRr98n5Uduzh,'',809,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_YUT_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع يوتيوب'+BRr98n5Uduzh,'',149,'','',xC2GuEcJKk3t4Uh)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_DLM_'+MtyCR0IDdUrbYevFG9WQm7nKxNkZ8+'بحث موقع ديلي موشن'+BRr98n5Uduzh,'',409,'','',xC2GuEcJKk3t4Uh)
	return
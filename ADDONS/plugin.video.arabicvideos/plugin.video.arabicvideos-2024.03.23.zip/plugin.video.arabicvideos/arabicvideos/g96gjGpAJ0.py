# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'KATKOUTE'
JJCLnkX4TozH7Bsjivfe = '_KTK_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['الصفحة الرئيسية','Sign in','الأقسام']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==670: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==671: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==672: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==673: cLCisPE3lX = GWX3pPEBCl7(url,text)
	elif mode==674: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==679: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','KATKOUTE-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',679,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"navslide-divider"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title in OZYvGX7EMx05KH1fI: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,mode)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = QBJX6Z3vPmIVwUuCcnioMxYb47d(HbiLZQKalC+'/watch/browse.html')
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,674,o3gHuBtrRN)
	return
def QBJX6Z3vPmIVwUuCcnioMxYb47d(url):
	JNSvF8Egp0xCHOR2b3 = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','KATKOUTE','CATEGORIES')
	if JNSvF8Egp0xCHOR2b3: return JNSvF8Egp0xCHOR2b3
	JNSvF8Egp0xCHOR2b3 = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'','','','','KATKOUTE-CATEGORIES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"category-header"(.*?)<footer>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		JNSvF8Egp0xCHOR2b3 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if JNSvF8Egp0xCHOR2b3: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'KATKOUTE','CATEGORIES',JNSvF8Egp0xCHOR2b3,CC89Q23uNDmIKWHAs)
	return JNSvF8Egp0xCHOR2b3
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOUTE-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"caret"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('"presentation"','</ul>')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = [('',Zsh7mUdwjHobLyMz6WKJGVl1cgeR)]
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for YvGlnjICiDMQz,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if YvGlnjICiDMQz: YvGlnjICiDMQz = YvGlnjICiDMQz+': '
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = YvGlnjICiDMQz+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,671)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"pm-category-subcats"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(items)<30:
			QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,671)
	if not GVznW0jE3yMFaqK2uZvw1HBrtC and not q9OCkWn6ruAvQLKDFUyxBME0: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,iYvJPtR357SbyQf1=''):
	if iYvJPtR357SbyQf1=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,headers,'','','KATKOUTE-TITLES-1st')
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOUTE-TITLES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR,items = '',[]
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	if iYvJPtR357SbyQf1=='ajax-search':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
		uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr: items.append(('',i8sFwPqo1vpEXR2VdHU5BmW,title))
	elif iYvJPtR357SbyQf1=='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pm-video-watch-featured"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	elif iYvJPtR357SbyQf1=='new_episodes':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-ul-browse-videos(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	elif iYvJPtR357SbyQf1=='new_movies':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-ul-browse-videos(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(tmEVko4qsghUX6WLx8KG7fOTB)>1: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[1]
	elif iYvJPtR357SbyQf1=='featured_series':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr: items.append(('',i8sFwPqo1vpEXR2VdHU5BmW,title))
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(data-echo=".*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if Zsh7mUdwjHobLyMz6WKJGVl1cgeR and not items: items = T072lCzjYiuaeFtmJGV.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: return
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|حلقة).\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,672,o3gHuBtrRN)
		elif iYvJPtR357SbyQf1=='new_episodes':
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,672,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,673,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/movseries/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,671,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,673,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW:
				ll9khUfx3MjZ = url.rsplit('/',1)[0]
				i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,671,'','',iYvJPtR357SbyQf1)
	return
def GWX3pPEBCl7(url,owZaqWpIcVhyDHXliB4dgRUr):
	QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+'تشغيل الفيديو',url,672)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	JNSvF8Egp0xCHOR2b3 = QBJX6Z3vPmIVwUuCcnioMxYb47d(HbiLZQKalC+'/watch/browse.html')
	yb5JFCm3YId2t,ulexGimo0UcKVn2Y4357bzPh,CCuzN3jy9kZ27JASwfoxqcrs5geFKE = zip(*JNSvF8Egp0xCHOR2b3)
	TTDLaUfdo6cCOXnJARM = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOUTE-EPISODES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-video-heading"(.*?)id="player"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in kkH5sRPxhASFowLONy4:
			if i8sFwPqo1vpEXR2VdHU5BmW not in yb5JFCm3YId2t:
				Lw8JjEfuiW0VN9qHAcgRpMBdICS = (i8sFwPqo1vpEXR2VdHU5BmW,title)
				TTDLaUfdo6cCOXnJARM.append(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
		if len(TTDLaUfdo6cCOXnJARM)==1:
			i8sFwPqo1vpEXR2VdHU5BmW,title = TTDLaUfdo6cCOXnJARM[0]
			Dhm1GLpdYu4xwZzSQlEtvNC3ga(i8sFwPqo1vpEXR2VdHU5BmW,'new_episodes')
			return
		else:
			for i8sFwPqo1vpEXR2VdHU5BmW,title in TTDLaUfdo6cCOXnJARM:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,671,'','','new_episodes')
	if not TTDLaUfdo6cCOXnJARM: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'new_episodes')
	return
def JwYEQUDupG2WLPzHndc(url):
	MfIDplCLUGK91vjO = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOUTE-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('sources:(.*?)flashplayer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('file: "(.*?)".*?label: "(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in kkH5sRPxhASFowLONy4:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named=__watch__'+Q5OAspyiXV1lx8930qLGD
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('"embedded-video".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not kkH5sRPxhASFowLONy4: kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall("file: '(.*?)'",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if kkH5sRPxhASFowLONy4:
		i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[0]
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=__embed')
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/watch/search.php?keywords='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
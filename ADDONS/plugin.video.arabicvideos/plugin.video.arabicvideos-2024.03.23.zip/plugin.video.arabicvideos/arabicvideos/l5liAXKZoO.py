# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'CIMACLUP'
JJCLnkX4TozH7Bsjivfe = '_CMC_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['موقع نتفليكس']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==490: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==491: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==492: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==493: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==494: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==499: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text,url)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','CIMACLUP-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	LL2d9tanw0mrxJBKAT63buD = LL2d9tanw0mrxJBKAT63buD[0].strip('/')
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(LL2d9tanw0mrxJBKAT63buD,'url')
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"filter AjaxifyFilter"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-filter="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title in OZYvGX7EMx05KH1fI: continue
			i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/old/filter/'+i8sFwPqo1vpEXR2VdHU5BmW+'.php'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,491)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أفلام',LL2d9tanw0mrxJBKAT63buD+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات',LL2d9tanw0mrxJBKAT63buD+'/category/مسلسلات/مسلسلات-اجنبى',494,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="navigation-menu"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if i8sFwPqo1vpEXR2VdHU5BmW=='/': continue
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
		if title in OZYvGX7EMx05KH1fI: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,491)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUP-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"filter"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title in OZYvGX7EMx05KH1fI: continue
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,491)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,xQ7XawG9M3grVTo=''):
	items = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUP-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = ''
	if '.php' in url: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
	elif '?s=' in url:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"blocks(.*?)"manifest"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"Blocks(.*?)"manifest"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not Zsh7mUdwjHobLyMz6WKJGVl1cgeR: return
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		title = Nkuqp0boKj41i9(title)
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) حلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if not XSCYbwaqRBtopUc9H2QZu86gA5N: XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if not XSCYbwaqRBtopUc9H2QZu86gA5N or any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,492,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'حلقة' in title:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,493,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,493,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<li><a href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			title = title.replace('الصفحة ','')
			if title!='': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,491)
	return
def UAB8vizclM6XG4Pw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUP-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('"ButtonsBarCo".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ:
		ll9khUfx3MjZ = ll9khUfx3MjZ[0]
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMACLUP-EPISODES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('"img-responsive" src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN[0]
	else: o3gHuBtrRN = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Thumb')
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"filter"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"Blocks(.*?)class="pagination"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC and '/series/' not in url:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,493,o3gHuBtrRN)
	elif q9OCkWn6ruAvQLKDFUyxBME0:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
				title = title.strip(' ')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,492,o3gHuBtrRN)
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = Nkuqp0boKj41i9(title)
				title = title.replace('الصفحة ','')
				if title!='': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,491)
	return
def JwYEQUDupG2WLPzHndc(url):
	ll9khUfx3MjZ = url.strip('/')+'/?view=1'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMACLUP-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	M7oS6tLhdx3ke8qPX4mFA = []
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	CXUSgmQjGvJzKWYr7BckR2I = T072lCzjYiuaeFtmJGV.findall("data: 'q=(.*?)&",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	CXUSgmQjGvJzKWYr7BckR2I = CXUSgmQjGvJzKWYr7BckR2I[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"serversList"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-server="(.*?)">(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for RRQsVzCrc6iEqKlxFamo,title in items:
			title = title.strip(' ')
			i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/old/servers/server.php?q='+CXUSgmQjGvJzKWYr7BckR2I+'&i='+RRQsVzCrc6iEqKlxFamo+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"embedServer".*?SRC="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		title = 'مفضل'
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]+'?named=__embed__'+title
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"downloadsList"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<td>(.*?)</td>.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			title = title.strip(' ')
			if 'anavidz' in i8sFwPqo1vpEXR2VdHU5BmW: tKBSN4Zgn9CDb = '__خاص'
			else: tKBSN4Zgn9CDb = ''
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'+tKBSN4Zgn9CDb
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search,LL2d9tanw0mrxJBKAT63buD=''):
	if not LL2d9tanw0mrxJBKAT63buD: LL2d9tanw0mrxJBKAT63buD = HbiLZQKalC
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	search = search.replace(' ','+')
	url = LL2d9tanw0mrxJBKAT63buD+'/index.php?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
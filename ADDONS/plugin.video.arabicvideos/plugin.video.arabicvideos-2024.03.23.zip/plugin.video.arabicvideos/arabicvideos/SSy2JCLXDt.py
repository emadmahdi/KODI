# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'LIVETV'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX['PYTHON'][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url):
	if   mode==100: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==101: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('0',True)
	elif mode==102: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('1',True)
	elif mode==103: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('2',True)
	elif mode==104: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('3',True)
	elif mode==105: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==106: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('4',True)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	QQmLIZC8uas9fNiJWOnhdGvgFR('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	QQmLIZC8uas9fNiJWOnhdGvgFR('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(vAujiEeLZbowS2Xgp5830Yc,showDialogs=True):
	JJCLnkX4TozH7Bsjivfe = '_TV'+vAujiEeLZbowS2Xgp5830Yc+'_'
	mXzxhH68tSFg = au8Umt9dq1KLSYb(32)
	y7PU6am9Z3I = {'id':'','user':mXzxhH68tSFg,'function':'list','menu':vAujiEeLZbowS2Xgp5830Yc}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',HbiLZQKalC,y7PU6am9Z3I,'','','','LIVETV-ITEMS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		for jV1Z7MWOa80gbwJY64nL5 in range(len(items)):
			name = items[jV1Z7MWOa80gbwJY64nL5][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[jV1Z7MWOa80gbwJY64nL5] = items[jV1Z7MWOa80gbwJY64nL5][0],items[jV1Z7MWOa80gbwJY64nL5][1],items[jV1Z7MWOa80gbwJY64nL5][2],name,items[jV1Z7MWOa80gbwJY64nL5][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for nnN6lPjWb0xVQqDKwo3,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,WpHryfYS0dNkc9bJlgoI8ueAj3n,name,o3gHuBtrRN in items:
			if '#' in nnN6lPjWb0xVQqDKwo3: continue
			if nnN6lPjWb0xVQqDKwo3!='URL': name = name+'[COLOR FFC89008]   '+nnN6lPjWb0xVQqDKwo3+'[/COLOR]'
			url = nnN6lPjWb0xVQqDKwo3+';;'+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+';;'+WpHryfYS0dNkc9bJlgoI8ueAj3n+';;'+vAujiEeLZbowS2Xgp5830Yc
			QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+''+name,url,105,o3gHuBtrRN)
	else:
		if showDialogs: QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def JwYEQUDupG2WLPzHndc(id):
	nnN6lPjWb0xVQqDKwo3,dATnilvcrXxmZ1k5EP0KgBFDqYpy6,WpHryfYS0dNkc9bJlgoI8ueAj3n,vAujiEeLZbowS2Xgp5830Yc = id.split(';;')
	url = ''
	mXzxhH68tSFg = au8Umt9dq1KLSYb(32)
	if nnN6lPjWb0xVQqDKwo3=='URL': url = WpHryfYS0dNkc9bJlgoI8ueAj3n
	elif nnN6lPjWb0xVQqDKwo3=='YOUTUBE':
		url = tOnYIHVk4xydqwoLEBKiDN0hX['YOUTUBE'][0]+'/watch?v='+WpHryfYS0dNkc9bJlgoI8ueAj3n
		import d3obAhVeNX
		d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U([url],nO6ukabcldeU,'live',url)
		return
	elif nnN6lPjWb0xVQqDKwo3=='GA':
		y7PU6am9Z3I = { 'id' : '', 'user' : mXzxhH68tSFg , 'function' : 'playGA1' , 'menu' : '' }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,y7PU6am9Z3I,'',False,'','LIVETV-PLAY-1st')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		cookies = WM1buqXnzf3Ba6Vp29l4gFD.cookies
		d7JzUectu63V9M = cookies['ASP.NET_SessionId']
		url = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		y7PU6am9Z3I = { 'id' : WpHryfYS0dNkc9bJlgoI8ueAj3n , 'user' : mXzxhH68tSFg , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+d7JzUectu63V9M }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,y7PU6am9Z3I,headers,'','','LIVETV-PLAY-2nd')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		url = T072lCzjYiuaeFtmJGV.findall('resp":"(http.*?m3u8)(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		i8sFwPqo1vpEXR2VdHU5BmW = url[0][0]
		A7cSC2V4hLItdMglP = url[0][1]
		c1tgy8SjLDvFHaAeispzTGV = 'http://38.'+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'777/'+WpHryfYS0dNkc9bJlgoI8ueAj3n+'_HD.m3u8'+A7cSC2V4hLItdMglP
		XU1ZePi6DfJrl7bxCYQdhRO = c1tgy8SjLDvFHaAeispzTGV.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		XphAbNZLa2Dy04RTP7l3GFzwds = c1tgy8SjLDvFHaAeispzTGV.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		n7CuHMSJpiR9fP0jvNEIyDUL = ['HD','SD1','SD2']
		M7oS6tLhdx3ke8qPX4mFA = [c1tgy8SjLDvFHaAeispzTGV,XU1ZePi6DfJrl7bxCYQdhRO,XphAbNZLa2Dy04RTP7l3GFzwds]
		tzgWIKy5xQL2kjm = 0
		if tzgWIKy5xQL2kjm == -1: return
		else: url = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	elif nnN6lPjWb0xVQqDKwo3=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		y7PU6am9Z3I = { 'id' : WpHryfYS0dNkc9bJlgoI8ueAj3n , 'user' : mXzxhH68tSFg , 'function' : 'playNT' , 'menu' : vAujiEeLZbowS2Xgp5830Yc }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST', HbiLZQKalC, y7PU6am9Z3I, headers, False,'','LIVETV-PLAY-3rd')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		url = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in WpHryfYS0dNkc9bJlgoI8ueAj3n:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif nnN6lPjWb0xVQqDKwo3=='PL':
		y7PU6am9Z3I = { 'id' : WpHryfYS0dNkc9bJlgoI8ueAj3n , 'user' : mXzxhH68tSFg , 'function' : 'playPL' , 'menu' : vAujiEeLZbowS2Xgp5830Yc }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST', HbiLZQKalC, y7PU6am9Z3I, '',False,'','LIVETV-PLAY-4th')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		url = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		headers = {'Referer':WM1buqXnzf3Ba6Vp29l4gFD.headers['Referer']}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		url = items[0]
	elif nnN6lPjWb0xVQqDKwo3 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if nnN6lPjWb0xVQqDKwo3=='TA': WpHryfYS0dNkc9bJlgoI8ueAj3n = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		y7PU6am9Z3I = { 'id' : WpHryfYS0dNkc9bJlgoI8ueAj3n , 'user' : mXzxhH68tSFg , 'function' : 'play'+nnN6lPjWb0xVQqDKwo3 , 'menu' : vAujiEeLZbowS2Xgp5830Yc }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',HbiLZQKalC,y7PU6am9Z3I,headers,'','','LIVETV-PLAY-6th')
		if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		url = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		if nnN6lPjWb0xVQqDKwo3=='FM':
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
			url = url.replace('https','http')
	pidYDcjvhgVfqb3GeWSAOH5J(url,nO6ukabcldeU,'live')
	return
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'YOUTUBE'
JJCLnkX4TozH7Bsjivfe = '_YUT_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text,type,ffGe7cURW0lhJVvQAiw8IB):
	if	 mode==140: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==143: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url,type)
	elif mode==144: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(url,text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==145: cLCisPE3lX = Qls1PoHZJGD4wmfpAV3cMxn567e(url)
	elif mode==146: cLCisPE3lX = w9teA8p02dnmjvsiSbql4R7orzhF3D(url)
	elif mode==147: cLCisPE3lX = OOVrMCWoiQPnJgGaTfxBL672Uk()
	elif mode==148: cLCisPE3lX = V3PiCE8LschINYlD6MZXb()
	elif mode==149: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مواقع اختارها يوتيوب',HbiLZQKalC+'/feed/guide_builder',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الصفحة الرئيسية',HbiLZQKalC,144,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المحتوى الرائج',HbiLZQKalC+'/feed/trending',146)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: قنوات عربية','',147)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: قنوات أجنبية','',148)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: افلام عربية',HbiLZQKalC+'/results?search_query=فيلم',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: افلام اجنبية',HbiLZQKalC+'/results?search_query=movie',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: مسرحيات عربية',HbiLZQKalC+'/results?search_query=مسرحية',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات عربية',HbiLZQKalC+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات اجنبية',HbiLZQKalC+'/results?search_query=series&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات كارتون',HbiLZQKalC+'/results?search_query=كارتون&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بحث: خطبة المرجعية',HbiLZQKalC+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def OOVrMCWoiQPnJgGaTfxBL672Uk():
	yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(HbiLZQKalC+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def V3PiCE8LschINYlD6MZXb():
	yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(HbiLZQKalC+'/results?search_query=tv&sp=EgJAAQ==')
	return
def JwYEQUDupG2WLPzHndc(url,type):
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U([url],nO6ukabcldeU,type,url)
	return
def w9teA8p02dnmjvsiSbql4R7orzhF3D(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0,SCnhp2blgkLJrvcqKmXdE,data = PdRNrfFxjV(url)
	utnohcjDlPiTa8QKAJ7pgVf = SCnhp2blgkLJrvcqKmXdE['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for H3ABEcMzfyqwF4Ug2ZYtK in range(len(utnohcjDlPiTa8QKAJ7pgVf)):
		Lw8JjEfuiW0VN9qHAcgRpMBdICS = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK]
		rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,str(H3ABEcMzfyqwF4Ug2ZYtK))
	Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	ggC9tJksOa8BuxXjMbDN5 = 0
	for H3ABEcMzfyqwF4Ug2ZYtK in range(len(Q84ZlvcweP6)):
		Lw8JjEfuiW0VN9qHAcgRpMBdICS = Q84ZlvcweP6[H3ABEcMzfyqwF4Ug2ZYtK]['itemSectionRenderer']['contents'][0]
		if list(Lw8JjEfuiW0VN9qHAcgRpMBdICS['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		JzGp5aDTFHMe1nNKZRAoLu7Q,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV = EX8tudg02NvU9b67yoZRkDS(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
		if not title:
			ggC9tJksOa8BuxXjMbDN5 += 1
			title = 'فيديوهات رائجة '+str(ggC9tJksOa8BuxXjMbDN5)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,144,'',str(H3ABEcMzfyqwF4Ug2ZYtK))
	key = T072lCzjYiuaeFtmJGV.findall('"innertubeApiKey":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	qQXuaKpVrGLF3e5oidJ8YwDT0,SCnhp2blgkLJrvcqKmXdE,vf78LSlJQOnCsatrIH2P1iW = PdRNrfFxjV(ll9khUfx3MjZ)
	for xB1k7v8jIeQ5lfoTDHFPbydm4 in range(3,4):
		utnohcjDlPiTa8QKAJ7pgVf = SCnhp2blgkLJrvcqKmXdE['items'][xB1k7v8jIeQ5lfoTDHFPbydm4]['guideSectionRenderer']['items']
		for H3ABEcMzfyqwF4Ug2ZYtK in range(len(utnohcjDlPiTa8QKAJ7pgVf)):
			Lw8JjEfuiW0VN9qHAcgRpMBdICS = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK]
			if 'YouTube Premium' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS): continue
			rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
	return
def yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(url,data='',index=0):
	global YTPut68WBVUNCvsEzg
	if not data: data = YTPut68WBVUNCvsEzg.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	qQXuaKpVrGLF3e5oidJ8YwDT0,SCnhp2blgkLJrvcqKmXdE,vf78LSlJQOnCsatrIH2P1iW = PdRNrfFxjV(url,data)
	xsTmMQuR5naiJIBY,ssOBHwNRIj8qugmKEbZlYcGLh6MzV = '',''
	jjcUIZ6zfqJx = T072lCzjYiuaeFtmJGV.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not jjcUIZ6zfqJx: jjcUIZ6zfqJx = T072lCzjYiuaeFtmJGV.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not jjcUIZ6zfqJx: jjcUIZ6zfqJx = T072lCzjYiuaeFtmJGV.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if jjcUIZ6zfqJx:
		xsTmMQuR5naiJIBY = '[COLOR FFC89008]'+jjcUIZ6zfqJx[0][0]+'[/COLOR]'
		i8sFwPqo1vpEXR2VdHU5BmW = jjcUIZ6zfqJx[0][1]
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
		if 'list=' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+xsTmMQuR5naiJIBY,i8sFwPqo1vpEXR2VdHU5BmW,144)
	KTY0XuQ2DjzC = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	GwsJfnt05CAqdKBI6O = not any(EYn2siOeDvQTk8KpS0Jl in url for EYn2siOeDvQTk8KpS0Jl in KTY0XuQ2DjzC)
	if GwsJfnt05CAqdKBI6O and xsTmMQuR5naiJIBY:
		UliDv052e7j = 'البحث'
		tKBSN4Zgn9CDb = 'قوائم التشغيل'
		qVPikX2KLyo94HdT1mDWIpFhA = 'الفيديوهات'
		Dj0o4Jn3kEmrHxTeaOhv6W = 'القنوات'
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+xsTmMQuR5naiJIBY,url,9999)
		if '"title":"بحث"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+UliDv052e7j,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url+'/playlists',144)
		if '"title":"الفيديوهات"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+qVPikX2KLyo94HdT1mDWIpFhA,url+'/videos',144)
		if '"title":"القنوات"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+Dj0o4Jn3kEmrHxTeaOhv6W,url+'/channels',144)
		if '"title":"Search"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+UliDv052e7j,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url+'/playlists',144)
		if '"title":"Videos"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+qVPikX2KLyo94HdT1mDWIpFhA,url+'/videos',144)
		if '"title":"Channels"' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+Dj0o4Jn3kEmrHxTeaOhv6W,url+'/channels',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		utnohcjDlPiTa8QKAJ7pgVf = SCnhp2blgkLJrvcqKmXdE['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		VQKyi740FuYS91bpLswocdOGDBkN = 0
		for jV1Z7MWOa80gbwJY64nL5 in range(len(utnohcjDlPiTa8QKAJ7pgVf)):
			if 'itemSectionRenderer' in list(utnohcjDlPiTa8QKAJ7pgVf[jV1Z7MWOa80gbwJY64nL5].keys()):
				Xv1UuinTaOWfDxm3l2z0YyNCg = utnohcjDlPiTa8QKAJ7pgVf[jV1Z7MWOa80gbwJY64nL5]['itemSectionRenderer']
				Aa43rGtLqgzKP90VjZsyEn = len(str(Xv1UuinTaOWfDxm3l2z0YyNCg))
				if Aa43rGtLqgzKP90VjZsyEn>VQKyi740FuYS91bpLswocdOGDBkN:
					VQKyi740FuYS91bpLswocdOGDBkN = Aa43rGtLqgzKP90VjZsyEn
					ssOBHwNRIj8qugmKEbZlYcGLh6MzV = Xv1UuinTaOWfDxm3l2z0YyNCg
		if VQKyi740FuYS91bpLswocdOGDBkN==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==HbiLZQKalC:
		Vo7hifxLTQnUR4Yr = []
		Vo7hifxLTQnUR4Yr.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		Vo7hifxLTQnUR4Yr.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		Vo7hifxLTQnUR4Yr.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		Vo7hifxLTQnUR4Yr.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		Vo7hifxLTQnUR4Yr.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		Vo7hifxLTQnUR4Yr.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		Vo7hifxLTQnUR4Yr.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		Vo7hifxLTQnUR4Yr.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		fABCHXzVGSWOLp,ssOBHwNRIj8qugmKEbZlYcGLh6MzV = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(SCnhp2blgkLJrvcqKmXdE,'',Vo7hifxLTQnUR4Yr)
	if not ssOBHwNRIj8qugmKEbZlYcGLh6MzV:
		try:
			utnohcjDlPiTa8QKAJ7pgVf = SCnhp2blgkLJrvcqKmXdE['contents']['twoColumnBrowseResultsRenderer']['tabs']
			nAmfSN0Y93jC14Fa5T8oe = '/videos' in url or '/playlists' in url or '/channels' in url
			oML3DHJZryT6XqbBhiP87lAk2xIdS = '"title":"الفيديوهات"' in qQXuaKpVrGLF3e5oidJ8YwDT0 or '"title":"قوائم التشغيل"' in qQXuaKpVrGLF3e5oidJ8YwDT0 or '"title":"القنوات"' in qQXuaKpVrGLF3e5oidJ8YwDT0
			ttLUfDwdFhHqCNls0v7mPSuyxezjA = '"title":"Videos"' in qQXuaKpVrGLF3e5oidJ8YwDT0 or '"title":"Playlists"' in qQXuaKpVrGLF3e5oidJ8YwDT0 or '"title":"Channels"' in qQXuaKpVrGLF3e5oidJ8YwDT0
			if nAmfSN0Y93jC14Fa5T8oe and (oML3DHJZryT6XqbBhiP87lAk2xIdS or ttLUfDwdFhHqCNls0v7mPSuyxezjA):
				for H3ABEcMzfyqwF4Ug2ZYtK in range(len(utnohcjDlPiTa8QKAJ7pgVf)):
					if 'tabRenderer' not in list(utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK].keys()): continue
					Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK]['tabRenderer']
					try: YlI2aWMnTEXGmrZ3FJ = Q84ZlvcweP6['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][H3ABEcMzfyqwF4Ug2ZYtK]
					except: YlI2aWMnTEXGmrZ3FJ = Q84ZlvcweP6
					try: i8sFwPqo1vpEXR2VdHU5BmW = YlI2aWMnTEXGmrZ3FJ['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in i8sFwPqo1vpEXR2VdHU5BmW	and '/videos'		in url: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK] ; break
					elif '/playlists'	in i8sFwPqo1vpEXR2VdHU5BmW	and '/playlists'	in url: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK] ; break
					elif '/channels'	in i8sFwPqo1vpEXR2VdHU5BmW	and '/channels'		in url: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[H3ABEcMzfyqwF4Ug2ZYtK] ; break
					else: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[0]
			elif 'bp=' in url: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[index]
			else: Q84ZlvcweP6 = utnohcjDlPiTa8QKAJ7pgVf[0]
			ssOBHwNRIj8qugmKEbZlYcGLh6MzV = Q84ZlvcweP6['tabRenderer']['content']
		except: pass
	if not ssOBHwNRIj8qugmKEbZlYcGLh6MzV: return
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("ff['sectionListRenderer']")
	Vo7hifxLTQnUR4Yr.append("ff['richGridRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("ff['contents']")
	Vo7hifxLTQnUR4Yr.append("ff")
	bJ2vRxC30VdwKQl5er9Dnaj = y357f08uQISUGLr6qOwdTBCcnWsv(u'كل قوائم التشغيل')
	CWabGc5dKv6U9RiE = y357f08uQISUGLr6qOwdTBCcnWsv(u'كل الفيديوهات')
	vRE67eKrTkQhqW8MP05SCizajIoHu = y357f08uQISUGLr6qOwdTBCcnWsv(u'كل القنوات')
	QXpMOdew5IqLo0GncW = [bJ2vRxC30VdwKQl5er9Dnaj,CWabGc5dKv6U9RiE,vRE67eKrTkQhqW8MP05SCizajIoHu,'All playlists','All videos','All channels']
	J075hAkRSlXWoxnq,YlI2aWMnTEXGmrZ3FJ = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(ssOBHwNRIj8qugmKEbZlYcGLh6MzV,index,Vo7hifxLTQnUR4Yr)
	if 'list' in str(type(YlI2aWMnTEXGmrZ3FJ)) and any(EYn2siOeDvQTk8KpS0Jl in str(YlI2aWMnTEXGmrZ3FJ[0]) for EYn2siOeDvQTk8KpS0Jl in QXpMOdew5IqLo0GncW): del YlI2aWMnTEXGmrZ3FJ[0]
	for aS861DtepGP in range(len(YlI2aWMnTEXGmrZ3FJ)):
		Vo7hifxLTQnUR4Yr = []
		Vo7hifxLTQnUR4Yr.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['itemSectionRenderer']['header']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['horizontalCardListRenderer']['header']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['richSectionRenderer']['content']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['richItemRenderer']['content']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]['gameCardRenderer']['game']")
		Vo7hifxLTQnUR4Yr.append("gg[index2]")
		fABCHXzVGSWOLp,Lw8JjEfuiW0VN9qHAcgRpMBdICS = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(YlI2aWMnTEXGmrZ3FJ,aS861DtepGP,Vo7hifxLTQnUR4Yr)
		rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,str(aS861DtepGP))
		if fABCHXzVGSWOLp=='4':
			try:
				NwrIaSOCGVxQT = Lw8JjEfuiW0VN9qHAcgRpMBdICS['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for ZGnvFShrNbB in range(len(NwrIaSOCGVxQT)):
					c5UI9LDgKosPCbhaJ = NwrIaSOCGVxQT[ZGnvFShrNbB]
					rcN12ObjvUWAKLPFTey(c5UI9LDgKosPCbhaJ)
			except: pass
	x2dbytYP1qriwCmTc = False
	if 'view=' not in url and J075hAkRSlXWoxnq=='8': x2dbytYP1qriwCmTc = True
	if ':::' in vf78LSlJQOnCsatrIH2P1iW: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,X0RnBVjhsPHYlNSLOatw4CJ,vCMOKk7Y2hqfcx53Ni9IRsem,cGaExo7bmhAn2QwIgMpWfzO,PI628YnaNF = vf78LSlJQOnCsatrIH2P1iW.split(':::')
	else: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,X0RnBVjhsPHYlNSLOatw4CJ,vCMOKk7Y2hqfcx53Ni9IRsem,cGaExo7bmhAn2QwIgMpWfzO,PI628YnaNF = '','','','','',''
	ll9khUfx3MjZ,re8PLYqIQ6hN1vk503OTJng = '',''
	if a26IqBkAXRPrwCOgFDb:
		BXjPRi5MwSKNveZ1UVD = str(a26IqBkAXRPrwCOgFDb[-1][1])
		if   JJCLnkX4TozH7Bsjivfe+'CHNL' in BXjPRi5MwSKNveZ1UVD: re8PLYqIQ6hN1vk503OTJng = 'CHANNELS'
		elif JJCLnkX4TozH7Bsjivfe+'USER' in BXjPRi5MwSKNveZ1UVD: re8PLYqIQ6hN1vk503OTJng = 'CHANNELS'
		elif JJCLnkX4TozH7Bsjivfe+'LIST' in BXjPRi5MwSKNveZ1UVD: re8PLYqIQ6hN1vk503OTJng = 'PLAYLISTS'
	if '"continuations"' in qQXuaKpVrGLF3e5oidJ8YwDT0 and '&list=' not in url and not x2dbytYP1qriwCmTc and 'shelf_id' not in url:
		ll9khUfx3MjZ = HbiLZQKalC+'/browse_ajax?ctoken='+X0RnBVjhsPHYlNSLOatw4CJ
	elif '"token"' in qQXuaKpVrGLF3e5oidJ8YwDT0 and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		ll9khUfx3MjZ = HbiLZQKalC+'/youtubei/v1/search?key='+key
	elif '"token"' in qQXuaKpVrGLF3e5oidJ8YwDT0 and 'bp=' not in url:
		ll9khUfx3MjZ = HbiLZQKalC+'/youtubei/v1/browse?key='+key
	if ll9khUfx3MjZ: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة أخرى',ll9khUfx3MjZ,144,re8PLYqIQ6hN1vk503OTJng,'',vf78LSlJQOnCsatrIH2P1iW)
	return
def QNtD5X2FuvzCgwiSrOxbAHjWsnJ(INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,n0tEuRyjYcxNAH):
	SCnhp2blgkLJrvcqKmXdE = INqwL4fDcG6reb5Oay
	ssOBHwNRIj8qugmKEbZlYcGLh6MzV,index = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	YlI2aWMnTEXGmrZ3FJ,aS861DtepGP = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	count = len(n0tEuRyjYcxNAH)
	for H3ABEcMzfyqwF4Ug2ZYtK in range(count):
		try:
			vvSNrxh3fm5lC = eval(n0tEuRyjYcxNAH[H3ABEcMzfyqwF4Ug2ZYtK])
			return str(H3ABEcMzfyqwF4Ug2ZYtK+1),vvSNrxh3fm5lC
		except: pass
	return '',''
def EX8tudg02NvU9b67yoZRkDS(Lw8JjEfuiW0VN9qHAcgRpMBdICS):
	try: YMXkRA2jOHDy0IgLSrJVaNqhTWZ = list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys())[0]
	except: return False,'','','','','','',''
	JzGp5aDTFHMe1nNKZRAoLu7Q,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV = False,'','','','','','',''
	eHdnm1G2PjBlED = Lw8JjEfuiW0VN9qHAcgRpMBdICS[YMXkRA2jOHDy0IgLSrJVaNqhTWZ]
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("render['unplayableText']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['formattedTitle']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['title']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['title']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("render['text']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['text']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("render['title']")
	Vo7hifxLTQnUR4Yr.append("item['title']")
	fABCHXzVGSWOLp,title = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	fABCHXzVGSWOLp,i8sFwPqo1vpEXR2VdHU5BmW = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("render['thumbnail']['thumbnails'][0]['url']")
	Vo7hifxLTQnUR4Yr.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	fABCHXzVGSWOLp,o3gHuBtrRN = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("render['videoCount']")
	Vo7hifxLTQnUR4Yr.append("render['videoCountText']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	fABCHXzVGSWOLp,count = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("render['lengthText']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	fABCHXzVGSWOLp,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = QNtD5X2FuvzCgwiSrOxbAHjWsnJ(Lw8JjEfuiW0VN9qHAcgRpMBdICS,eHdnm1G2PjBlED,Vo7hifxLTQnUR4Yr)
	if 'LIVE' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj = '','LIVE:  '
	if 'مباشر' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj = '','LIVE:  '
	if 'badges' in list(eHdnm1G2PjBlED.keys()):
		dWURt1bqeKDkAZiM4uc72rCNJ9sfIL = str(eHdnm1G2PjBlED['badges'])
		if 'Free with Ads' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$:'
		if 'LIVE NOW' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: hhuOs8xl1wSj = 'LIVE:  '
		if 'Buy' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL or 'Rent' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:'
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'مباشر') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: hhuOs8xl1wSj = 'LIVE:  '
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'شراء') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:'
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'استئجار') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:'
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'إعلانات') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$:'
	i8sFwPqo1vpEXR2VdHU5BmW = Bd2o0J6aOASWvuD9HzY(i8sFwPqo1vpEXR2VdHU5BmW)
	if i8sFwPqo1vpEXR2VdHU5BmW and 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
	o3gHuBtrRN = o3gHuBtrRN.split('?')[0]
	if  o3gHuBtrRN and 'http' not in o3gHuBtrRN: o3gHuBtrRN = 'https:'+o3gHuBtrRN
	title = Bd2o0J6aOASWvuD9HzY(title)
	if fojP2LBizNGFK4ctQ9UV: title = fojP2LBizNGFK4ctQ9UV+'  '+title
	fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace(',','')
	count = count.replace(',','')
	count = T072lCzjYiuaeFtmJGV.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV
def rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS,url='',index=''):
	JzGp5aDTFHMe1nNKZRAoLu7Q,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV = EX8tudg02NvU9b67yoZRkDS(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
	if not JzGp5aDTFHMe1nNKZRAoLu7Q: return
	elif 'continuationItemRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS): return
	elif 'searchPyvRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS): return
	elif not i8sFwPqo1vpEXR2VdHU5BmW and 'search_query' in url: return
	elif title and not i8sFwPqo1vpEXR2VdHU5BmW and ('search_query' in url or 'horizontalMovieListRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS) or url==HbiLZQKalC):
		title = '=== '+title+' ==='
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+title,'',9999)
	elif title and 'messageRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS):
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+title,'',9999)
	elif '/feed/trending' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,index)
	elif not title: return
	elif hhuOs8xl1wSj: QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+hhuOs8xl1wSj+title,i8sFwPqo1vpEXR2VdHU5BmW,143,o3gHuBtrRN)
	elif 'watch?v=' in i8sFwPqo1vpEXR2VdHU5BmW or '/shorts/' in i8sFwPqo1vpEXR2VdHU5BmW:
		if '&list=' in i8sFwPqo1vpEXR2VdHU5BmW and 'index=' not in i8sFwPqo1vpEXR2VdHU5BmW:
			WvyHJwCMuKZd = i8sFwPqo1vpEXR2VdHU5BmW.split('&list=',1)[1]
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/playlist?list='+WvyHJwCMuKZd
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'LIST'+count+':  '+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN)
		else:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&list=',1)[0]
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,143,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	else:
		type = ''
		if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = url
		elif not any(EYn2siOeDvQTk8KpS0Jl in i8sFwPqo1vpEXR2VdHU5BmW for EYn2siOeDvQTk8KpS0Jl in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in i8sFwPqo1vpEXR2VdHU5BmW or '/c/' in i8sFwPqo1vpEXR2VdHU5BmW: type = 'CHNL'+count+':  '
			if '/user/' in i8sFwPqo1vpEXR2VdHU5BmW: type = 'USER'+count+':  '
			index,S5g8QHFWknGvqIexMK1ObY3r47TD6 = '',''
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+type+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,index)
	return
def PdRNrfFxjV(url,data='',iYvJPtR357SbyQf1=''):
	global YTPut68WBVUNCvsEzg
	if not data: data = YTPut68WBVUNCvsEzg.getSetting('av.youtube.data')
	if iYvJPtR357SbyQf1=='': iYvJPtR357SbyQf1 = 'ytInitialData'
	zslrWLD38jgdn = diwUZMEagkFDlS()
	JKf4Tsxu9S23FI7mV5DGLk = {'User-Agent':zslrWLD38jgdn,'Cookie':'PREF=hl=ar'}
	if ':::' in data: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,X0RnBVjhsPHYlNSLOatw4CJ,vCMOKk7Y2hqfcx53Ni9IRsem,cGaExo7bmhAn2QwIgMpWfzO,PI628YnaNF = data.split(':::')
	else: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,X0RnBVjhsPHYlNSLOatw4CJ,vCMOKk7Y2hqfcx53Ni9IRsem,cGaExo7bmhAn2QwIgMpWfzO,PI628YnaNF = '','','','','',''
	if 'guide?key=' in url:
		vf78LSlJQOnCsatrIH2P1iW = {}
		vf78LSlJQOnCsatrIH2P1iW['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":vCMOKk7Y2hqfcx53Ni9IRsem}}
		vf78LSlJQOnCsatrIH2P1iW = str(vf78LSlJQOnCsatrIH2P1iW)
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and TrME71fOa2lNRFoQVSnBd8etqJZXC:
		vf78LSlJQOnCsatrIH2P1iW = {'continuation':cGaExo7bmhAn2QwIgMpWfzO}
		vf78LSlJQOnCsatrIH2P1iW['context'] = {"client":{"visitorData":TrME71fOa2lNRFoQVSnBd8etqJZXC,"clientName":"WEB","clientVersion":vCMOKk7Y2hqfcx53Ni9IRsem}}
		vf78LSlJQOnCsatrIH2P1iW = str(vf78LSlJQOnCsatrIH2P1iW)
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and PI628YnaNF:
		JKf4Tsxu9S23FI7mV5DGLk.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':vCMOKk7Y2hqfcx53Ni9IRsem})
		JKf4Tsxu9S23FI7mV5DGLk.update({'Cookie':'VISITOR_INFO1_LIVE='+PI628YnaNF})
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','YOUTUBE-GET_PAGE_DATA-4th')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qqjfau6OAG5yp7ictMWXFD9EB4r = T072lCzjYiuaeFtmJGV.findall('"innertubeApiKey".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if qqjfau6OAG5yp7ictMWXFD9EB4r: key = qqjfau6OAG5yp7ictMWXFD9EB4r[0]
	qqjfau6OAG5yp7ictMWXFD9EB4r = T072lCzjYiuaeFtmJGV.findall('"cver".*?"value".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if qqjfau6OAG5yp7ictMWXFD9EB4r: vCMOKk7Y2hqfcx53Ni9IRsem = qqjfau6OAG5yp7ictMWXFD9EB4r[0]
	qqjfau6OAG5yp7ictMWXFD9EB4r = T072lCzjYiuaeFtmJGV.findall('"token".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if qqjfau6OAG5yp7ictMWXFD9EB4r: cGaExo7bmhAn2QwIgMpWfzO = qqjfau6OAG5yp7ictMWXFD9EB4r[0]
	qqjfau6OAG5yp7ictMWXFD9EB4r = T072lCzjYiuaeFtmJGV.findall('"visitorData".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if qqjfau6OAG5yp7ictMWXFD9EB4r: TrME71fOa2lNRFoQVSnBd8etqJZXC = qqjfau6OAG5yp7ictMWXFD9EB4r[0]
	qqjfau6OAG5yp7ictMWXFD9EB4r = T072lCzjYiuaeFtmJGV.findall('"continuation".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if qqjfau6OAG5yp7ictMWXFD9EB4r: X0RnBVjhsPHYlNSLOatw4CJ = qqjfau6OAG5yp7ictMWXFD9EB4r[0]
	cookies = WM1buqXnzf3Ba6Vp29l4gFD.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): PI628YnaNF = cookies['VISITOR_INFO1_LIVE']
	data = TrME71fOa2lNRFoQVSnBd8etqJZXC+':::'+key+':::'+X0RnBVjhsPHYlNSLOatw4CJ+':::'+vCMOKk7Y2hqfcx53Ni9IRsem+':::'+cGaExo7bmhAn2QwIgMpWfzO+':::'+PI628YnaNF
	if iYvJPtR357SbyQf1=='ytInitialData' and 'ytInitialData' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('window\["ytInitialData"\] = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not b6iohEnHy4zM: b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('var ytInitialData = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',b6iohEnHy4zM[0])
	elif iYvJPtR357SbyQf1=='ytInitialGuideData' and 'ytInitialGuideData' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('var ytInitialGuideData = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',b6iohEnHy4zM[0])
	elif '</script>' not in qQXuaKpVrGLF3e5oidJ8YwDT0: kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',qQXuaKpVrGLF3e5oidJ8YwDT0)
	else: kRscYlFxGTCMrU = ''
	YTPut68WBVUNCvsEzg.setSetting('av.youtube.data',data)
	return qQXuaKpVrGLF3e5oidJ8YwDT0,kRscYlFxGTCMrU,data
def Qls1PoHZJGD4wmfpAV3cMxn567e(url):
	search = NWs7KpjXGnxYylofHtd5U3wDh()
	if not search: return
	search = search.replace(' ','+')
	ll9khUfx3MjZ = url+'/search?query='+search
	yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(ll9khUfx3MjZ)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	search = search.replace(' ','+')
	ll9khUfx3MjZ = HbiLZQKalC+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAg%253D%253D'
		dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+RXEDMq1wdne2kIQ7mGgJLhvV
	else:
		pRDZxuqijwB2cH,XaFPemq5UC,tKBSN4Zgn9CDb = [],[],''
		yGm8WdY9Cka6N3w5r1 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		oejZysl0QMLT2Y8aUFmfnhCNb = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		uulRAafXCtceoDY = sSOy1pju5PJ('موقع يوتيوب - اختر الترتيب',yGm8WdY9Cka6N3w5r1)
		if uulRAafXCtceoDY == -1: return
		DXpBL6TNzIt1U8u2bGo9xaRdVs0m = oejZysl0QMLT2Y8aUFmfnhCNb[uulRAafXCtceoDY]
		qQXuaKpVrGLF3e5oidJ8YwDT0,ZonORjX61Mm,data = PdRNrfFxjV(ll9khUfx3MjZ+DXpBL6TNzIt1U8u2bGo9xaRdVs0m)
		if ZonORjX61Mm:
			WnLsKcpfaYR2ZrJ9GotbVMv = ZonORjX61Mm['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for pqaxMNGvlH in range(len(WnLsKcpfaYR2ZrJ9GotbVMv)):
				group = WnLsKcpfaYR2ZrJ9GotbVMv[pqaxMNGvlH]['searchFilterGroupRenderer']['filters']
				for N7DULISGiyX8ouBVJ2PwMnHr49a in range(len(group)):
					eHdnm1G2PjBlED = group[N7DULISGiyX8ouBVJ2PwMnHr49a]['searchFilterRenderer']
					if 'navigationEndpoint' in list(eHdnm1G2PjBlED.keys()):
						i8sFwPqo1vpEXR2VdHU5BmW = eHdnm1G2PjBlED['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\u0026','&')
						title = eHdnm1G2PjBlED['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							tKBSN4Zgn9CDb = title
							K9K307bTvRVtO6i = i8sFwPqo1vpEXR2VdHU5BmW
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							tKBSN4Zgn9CDb = title
							K9K307bTvRVtO6i = i8sFwPqo1vpEXR2VdHU5BmW
						if 'Sort by' in title: continue
						pRDZxuqijwB2cH.append(Bd2o0J6aOASWvuD9HzY(title))
						XaFPemq5UC.append(i8sFwPqo1vpEXR2VdHU5BmW)
		if not tKBSN4Zgn9CDb: Uzf7r6tg3QjkdbLTaqZ0 = ''
		else:
			pRDZxuqijwB2cH = ['بدون فلتر',tKBSN4Zgn9CDb]+pRDZxuqijwB2cH
			XaFPemq5UC = ['',K9K307bTvRVtO6i]+XaFPemq5UC
			fZT9IHMakwXv = sSOy1pju5PJ('موقع يوتيوب - اختر الفلتر',pRDZxuqijwB2cH)
			if fZT9IHMakwXv == -1: return
			Uzf7r6tg3QjkdbLTaqZ0 = XaFPemq5UC[fZT9IHMakwXv]
		if Uzf7r6tg3QjkdbLTaqZ0: dCmKxk9BW310AXu4bJUHfY = HbiLZQKalC+Uzf7r6tg3QjkdbLTaqZ0
		elif DXpBL6TNzIt1U8u2bGo9xaRdVs0m: dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+DXpBL6TNzIt1U8u2bGo9xaRdVs0m
		else: dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ
	yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(dCmKxk9BW310AXu4bJUHfY)
	return
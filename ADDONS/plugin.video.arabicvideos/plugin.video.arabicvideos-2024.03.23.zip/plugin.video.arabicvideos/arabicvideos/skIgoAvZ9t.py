# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from pjZisTuDH7 import *
import bidi.algorithm as xAK6z48JXSbmultUw2BY,bidi.mirror as R5dhKZmoNf8rSOewTP2,base64 as eJ4h7nOpguFMH6z1IUEV2i,requests as CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5
nO6ukabcldeU = VH9MDo5z1kxNF07uRJI(u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ౫")
JZ8q3iIuOMam6QyPK0k5 = {}
a26IqBkAXRPrwCOgFDb = []
if mmIKCGujwM:
	z6oycmT807knMXqxCSIsAWKOP = lYmjeUrHgx1RDWzLN.translatePath(ttOu147wErcBvPaSMUY(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ౬"))
	QAqRhweFzL5D6d1sjfvY = lYmjeUrHgx1RDWzLN.translatePath(PiFkQ5pCJy7fbX(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ౭"))
	UEo2XO1pBtrNFV8GZC4mlQTS75de = lYmjeUrHgx1RDWzLN.translatePath(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ౮"))
	n3xWSEN58XZl9eFydUmCfs2ArH = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ౯"),EEvLoMzFqrlKce(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ౰"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ౱"))
	a2jRNkAitWzxLc35V = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,ZhqJoOtcmTVID65HwnLj(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ౲"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ౳"),VH9MDo5z1kxNF07uRJI(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ౴"))
	kkoV2vIem3BEOyp7w8CDNhHZAd = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,EmK3ObA0cwv9Wy(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౵"),ZEiR0StquOzca9lvPAndYIX(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౶"),Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭౷"))
	ZhR6zf92IPocOL0sC = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ౸")
	from urllib.parse import quote as _nQhElmPsC
else:
	z6oycmT807knMXqxCSIsAWKOP = EO9Rts0AaGuk1qpPLXCY.translatePath(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ౹"))
	QAqRhweFzL5D6d1sjfvY = EO9Rts0AaGuk1qpPLXCY.translatePath(EEvLoMzFqrlKce(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ౺"))
	UEo2XO1pBtrNFV8GZC4mlQTS75de = EO9Rts0AaGuk1qpPLXCY.translatePath(N9olEh0ZMtpOivVfBLK(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ౻"))
	n3xWSEN58XZl9eFydUmCfs2ArH = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,oAXJCYqPgyGDtT(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭౼"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ౽"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ౾"))
	a2jRNkAitWzxLc35V = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ౿"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪಀ"),f5uqIoSJzWBOFyrY78RXmVb(u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩಁ"))
	kkoV2vIem3BEOyp7w8CDNhHZAd = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,ZhqJoOtcmTVID65HwnLj(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),oAXJCYqPgyGDtT(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),HVibA2ES8lY(u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ಄"))
	ZhR6zf92IPocOL0sC = ttOu147wErcBvPaSMUY(u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧಅ").encode(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡶࡶࡩ࠼ࠬಆ"))
	from urllib import quote as _nQhElmPsC
aHPguvxqCjOmAwsF = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(UEo2XO1pBtrNFV8GZC4mlQTS75de,oAXJCYqPgyGDtT(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪಇ"))
UOqR1bCTXD4VisWrgeL = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(UEo2XO1pBtrNFV8GZC4mlQTS75de,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨಈ"))
uQwF9zNsc2S = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,FIHNSc5iuoZanQ2Ytl(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಉ"))
S0iVzW8Y9RrflbQ = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,oAXJCYqPgyGDtT(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ಊ"))
kzp9ocjCYM1wQaldAtGNvIL = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬಋ"))
Yy5epgPqo7D2vT4mQREiuX = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧಌ"))
H5ZNtUayYc10iI = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ಍"))
vHYUae4cO1XlpwWIziyCdA6Q = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,TWexH5PhS1(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩಎ"))
UIl7EzK48anPkH = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,VOq8Ekue4F(u"ࠩ࡬ࡱࡦ࡭ࡥࡴࠩಏ"))
TvgpYaGDFC3bVkErUS = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(UIl7EzK48anPkH,sDiKwnHcSlYFgWCy1Ak(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫಐ"))
Any0C7sBJTuiGW = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(TvgpYaGDFC3bVkErUS,VH9MDo5z1kxNF07uRJI(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ಑"))
mmry7DBuMdxCOPkeA = zzWKEDg14fbwQ5X7G.Addon().getAddonInfo(sbgu4D2RFMYKm(u"ࠬࡶࡡࡵࡪࠪಒ"))
ETky3OeIGb = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,vatyjK4hHAoZJ7rOq2lis(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨಓ"))
aa2bIiRVDqjeyL9OPMUmc08n4Y6xz = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪಔ"))
nGAmW9F4K1pEbi0YDOkHu3 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,N9olEh0ZMtpOivVfBLK(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬಕ"))
tt4gFWD0Am5 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,HVibA2ES8lY(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭ಖ"))
V8VcoHpu15anD9LmShwYZxTylM3 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪಗ"))
Fwd9kuV5NLP2go = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨಘ"))
yHDOwzZWqbtAR = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬಙ"))
r5XEa9VW0tBe6HKM4UQqpIOklTPyC = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬಚ"))
LdQHkenaBCP5 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,sbgu4D2RFMYKm(u"ࠧ࡮ࡧࡱࡹ࠳ࡶ࡮ࡨࠩಛ"))
zJNSdZn57DjIqhYo2TXH = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨಜ"))
yyJSUbRVMEdCABecYH8F = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩಝ"))
h8sqctmx4oFT76NHuQpKdOB9RPEiI = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,sDiKwnHcSlYFgWCy1Ak(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಞ"),PiFkQ5pCJy7fbX(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨಟ"),x7NwSuz5ft4e,TWexH5PhS1(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫಠ"))
KKfeItdkzh7XV = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(z6oycmT807knMXqxCSIsAWKOP,vatyjK4hHAoZJ7rOq2lis(u"࠭࡭ࡦࡦ࡬ࡥࠬಡ"),oAXJCYqPgyGDtT(u"ࠧࡇࡱࡱࡸࡸ࠭ಢ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫಣ"))
U1UsphAegPmDYZXfTW = l5mQdjWyczr7UJVnTp(u"࠶ᒟ")
Yrb603795v = [PiFkQ5pCJy7fbX(u"ุࠩๅึ࠭ತ"),EmK3ObA0cwv9Wy(u"ࠪวํ๊ࠧಥ"),h5huy6MiXPNfQJF8(u"ࠫะอๆ๋ࠩದ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬัวๅอࠪಧ"),h5huy6MiXPNfQJF8(u"࠭ัศส฼ࠫನ"),HH4JMrUDp3lq6hQ(u"ࠧฯษ่ืࠬ಩"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨีสำุ࠭ಪ"),vatyjK4hHAoZJ7rOq2lis(u"ࠩึหอ฿ࠧಫ"),VOq8Ekue4F(u"ࠪฯฬ๋ๆࠨಬ"),N9olEh0ZMtpOivVfBLK(u"ࠫฯอำฺࠩಭ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬ฿วีำࠪಮ")]
dFGi8L47RAaTBZh0UOj = sbgu4D2RFMYKm(u"࠭⸻ࠡ⼟ࠣ⸮ࠥ⹁ࠧಯ")
vZs8PpIdBUNQTjnbEymoYx6X = sbgu4D2RFMYKm(u"࠲ᒠ")
BZ5D43mGxLAItEUYTv = VOq8Ekue4F(u"࠶࠴ᒡ")*p2TglCv9raVJxSMBUi0em
j9t7FmfZiE6pYGI8V4u = sbgu4D2RFMYKm(u"࠶ᒢ")*fxunVecQRNTGHb2LJtkBylF5
l7S6tnfTxVX4QyHohFMCrOW15Em = PiFkQ5pCJy7fbX(u"࠸࠶ᒣ")*pyLSeGvtZu
GGkgJ2RMcEZ = VOq8Ekue4F(u"࠷ᒤ")*fxunVecQRNTGHb2LJtkBylF5
Quz6XWDsTZriPvCKlJ240mgnMIb3H = [PiFkQ5pCJy7fbX(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ರ")]
zjnYla4f5bLTDcupXmo9PAgZd2BO = [PiFkQ5pCJy7fbX(u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪಱ"),EEvLoMzFqrlKce(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬಲ"),VOq8Ekue4F(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧಳ"),VH9MDo5z1kxNF07uRJI(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ಴"),N9olEh0ZMtpOivVfBLK(u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨವ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡍࡐࡘࡖ࠸࡚࠭ಶ"),PiFkQ5pCJy7fbX(u"ࠧࡎ࡛ࡆࡍࡒࡇࠧಷ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡎࡄࡖࡔࡠࡁࠨಸ"),oAXJCYqPgyGDtT(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫಹ"),ZhqJoOtcmTVID65HwnLj(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ಺")]
zjnYla4f5bLTDcupXmo9PAgZd2BO += [sDiKwnHcSlYFgWCy1Ak(u"ࠫࡍࡋࡌࡂࡎࠪ಻"),EmK3ObA0cwv9Wy(u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ಼ࠫ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨಽ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨಾ"),VOq8Ekue4F(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪಿ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩೀ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬು"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡕࡇࡎࡆࡖࠪೂ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬೃ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬೄ")]
PrOzMBeAvauREUKXhiW = [ZhqJoOtcmTVID65HwnLj(u"ࠧࡊࡒࡗ࡚ࠬ೅"),VH9MDo5z1kxNF07uRJI(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫೆ"),PiFkQ5pCJy7fbX(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧೇ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨೈ")]
PrOzMBeAvauREUKXhiW += [l5mQdjWyczr7UJVnTp(u"ࠫࡒ࠹ࡕࠨ೉"),sbgu4D2RFMYKm(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧೊ"),oAXJCYqPgyGDtT(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪೋ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫೌ")]
PrOzMBeAvauREUKXhiW += [weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡋࡉࡍࡑࡓ್ࠧ"),FIHNSc5iuoZanQ2Ytl(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ೎"),oAXJCYqPgyGDtT(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ೏")]
PrOzMBeAvauREUKXhiW += [S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡆࡒࡁࡓࡃࡅࠫ೐"),EEvLoMzFqrlKce(u"ࠬࡇࡋࡘࡃࡐࠫ೑"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ೒"),VH9MDo5z1kxNF07uRJI(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ೓"),oAXJCYqPgyGDtT(u"ࠨࡃࡎࡓࡆࡓࠧ೔"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫೕ")]
PrOzMBeAvauREUKXhiW += [N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ೖ"),N9olEh0ZMtpOivVfBLK(u"ࠫࡇࡕࡋࡓࡃࠪ೗"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ೘"),oAXJCYqPgyGDtT(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ೙"),FIHNSc5iuoZanQ2Ytl(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ೚"),h5huy6MiXPNfQJF8(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ೛")]
HcECdU8G1iFh7I = [FIHNSc5iuoZanQ2Ytl(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ೜"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫೝ"),HVibA2ES8lY(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨೞ"),TWexH5PhS1(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ೟")]
HcECdU8G1iFh7I += [vatyjK4hHAoZJ7rOq2lis(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫೠ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬೡ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩೢ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩೣ"),VH9MDo5z1kxNF07uRJI(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ೤"),HVibA2ES8lY(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨ೥")]
QlMXWvubywKLZJa1zH = [mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ೦"),sbgu4D2RFMYKm(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ೧"),WmaPChRdQk3YcXwI6zS(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ೨"),ZEiR0StquOzca9lvPAndYIX(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ೩"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭೪")]
QlMXWvubywKLZJa1zH += [BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ೫"),Xl3drKyI9HkDiPEf8RTjwu(u"࡙ࠫ࡜ࡆࡖࡐࠪ೬"),N9olEh0ZMtpOivVfBLK(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ೭"),PiFkQ5pCJy7fbX(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ೮")]
QC3x0upNc4 = [VOq8Ekue4F(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ೯"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ೰"),TWexH5PhS1(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬೱ"),HH4JMrUDp3lq6hQ(u"ࠪࡊࡔ࡙ࡔࡂࠩೲ"),l5mQdjWyczr7UJVnTp(u"ࠫࡆࡎࡗࡂࡍࠪೳ"),h5huy6MiXPNfQJF8(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭೴")]
QC3x0upNc4 += [l5mQdjWyczr7UJVnTp(u"࠭ࡓࡉࡑࡉࡌࡆ࠭೵"),WmaPChRdQk3YcXwI6zS(u"ࠧࡃࡔࡖࡘࡊࡐࠧ೶"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ೷"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ೸"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ೹"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭೺"),TWexH5PhS1(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ೻")]
MEaGcxnP8r3F1u2NoqLKYCpA9mT4  = [Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡁࡌ࡙ࡄࡑࠬ೼"),FIHNSc5iuoZanQ2Ytl(u"ࠧࡂࡎࡄࡖࡆࡈࠧ೽"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ೾"),ttOu147wErcBvPaSMUY(u"ࠩࡅࡓࡐࡘࡁࠨ೿"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡅࡐࡕࡁࡎࠩഀ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ഁ"),oAXJCYqPgyGDtT(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧം"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧഃ")]
MEaGcxnP8r3F1u2NoqLKYCpA9mT4 += [PiFkQ5pCJy7fbX(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩഄ"),FIHNSc5iuoZanQ2Ytl(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫഅ"),FIHNSc5iuoZanQ2Ytl(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪആ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࡛ࠪࡊࡉࡉࡎࡃࠪഇ"),FIHNSc5iuoZanQ2Ytl(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨഈ"),h5huy6MiXPNfQJF8(u"ࠬࡌࡏࡔࡖࡄࠫഉ"),HVibA2ES8lY(u"࠭ࡁࡉ࡙ࡄࡏࠬഊ")]
MEaGcxnP8r3F1u2NoqLKYCpA9mT4 += [ZEiR0StquOzca9lvPAndYIX(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪഋ"),l5mQdjWyczr7UJVnTp(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫഌ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ഍"),EmK3ObA0cwv9Wy(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬഎ"),l5mQdjWyczr7UJVnTp(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ഏ"),EEvLoMzFqrlKce(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧഐ")]
MEaGcxnP8r3F1u2NoqLKYCpA9mT4 += [sbgu4D2RFMYKm(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ഑"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩഒ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪഓ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡗ࡚ࡋ࡛ࡎࠨഔ"),WmaPChRdQk3YcXwI6zS(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬക"),WmaPChRdQk3YcXwI6zS(u"ࠫࡘࡎࡏࡇࡊࡄࠫഖ")]
MEaGcxnP8r3F1u2NoqLKYCpA9mT4 += [N9olEh0ZMtpOivVfBLK(u"ࠬࡈࡒࡔࡖࡈࡎࠬഗ"),ZEiR0StquOzca9lvPAndYIX(u"࡙࠭ࡂࡓࡒࡘࠬഘ"),ttOu147wErcBvPaSMUY(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨങ"),ttOu147wErcBvPaSMUY(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩച"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧഛ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬജ"),l5mQdjWyczr7UJVnTp(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ഝ")]
uugqKIGhF7TyfQb5ncei0YEdps  = [N9olEh0ZMtpOivVfBLK(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪഞ"),WmaPChRdQk3YcXwI6zS(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧട"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧഠ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭ഡ"),VH9MDo5z1kxNF07uRJI(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭ഢ")]
uugqKIGhF7TyfQb5ncei0YEdps += [ZhqJoOtcmTVID65HwnLj(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩണ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫത")]
uugqKIGhF7TyfQb5ncei0YEdps += [QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭ഥ"),FIHNSc5iuoZanQ2Ytl(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪദ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪധ")]
uugqKIGhF7TyfQb5ncei0YEdps += [Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫന"),ZhqJoOtcmTVID65HwnLj(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧഩ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨപ")]
uugqKIGhF7TyfQb5ncei0YEdps += [vatyjK4hHAoZJ7rOq2lis(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ഫ"),sDiKwnHcSlYFgWCy1Ak(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩബ"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪഭ")]
TzLFE26MZ4j = [sbgu4D2RFMYKm(u"ࠧࡎ࠵ࡘࠫമ"),FIHNSc5iuoZanQ2Ytl(u"ࠨࡋࡓࡘ࡛࠭യ"),EEvLoMzFqrlKce(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧര"),oAXJCYqPgyGDtT(u"ࠪࡍࡋࡏࡌࡎࠩറ"),ZEiR0StquOzca9lvPAndYIX(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬല")]
yqHNLWzGFIVwRTu = MEaGcxnP8r3F1u2NoqLKYCpA9mT4+uugqKIGhF7TyfQb5ncei0YEdps
TLu7gCmS0Kk2lnP1cO = MEaGcxnP8r3F1u2NoqLKYCpA9mT4+TzLFE26MZ4j
zpf5CZtSa32UnHrJV1d8vD9hLP7YG = MEaGcxnP8r3F1u2NoqLKYCpA9mT4+uugqKIGhF7TyfQb5ncei0YEdps
GpeCN7LBKAUta4z8jPwY5ocxv0M = PrOzMBeAvauREUKXhiW+QlMXWvubywKLZJa1zH+QC3x0upNc4+HcECdU8G1iFh7I
VfLOSt67XB2JNsnYx = [
						ZEiR0StquOzca9lvPAndYIX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧള")
						,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨഴ")
						,PiFkQ5pCJy7fbX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡚ࡒࡔࡊࡡ࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨവ")
						]
MyfG164jLWzXKitYQTUqeDvrdSu0F = [
						VH9MDo5z1kxNF07uRJI(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭ശ")
						,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭ഷ")
						,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫസ")
						,EmK3ObA0cwv9Wy(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬഹ")
						,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧഺ")
						,N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵ഻ࠩ")
						,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷ഼ࠫ")
						,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬഽ")
						,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭ാ")
						,h5huy6MiXPNfQJF8(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧി")
						,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫീ")
						,FIHNSc5iuoZanQ2Ytl(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬു")
						,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬൂ")
						]
qqxtuBsgdSk = MyfG164jLWzXKitYQTUqeDvrdSu0F+[
				 g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡕࡓ࡝࡟࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩൃ")
				,FIHNSc5iuoZanQ2Ytl(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡌ࡙࡚ࡐࡔࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ൄ")
				,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ൅")
				,Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝ࡏࡅࡔ࠯࠵ࡲࡩ࠭െ")
				,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠵ࡸࡺࠧേ")
				,oAXJCYqPgyGDtT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠷ࡴࡤࠨൈ")
				,vatyjK4hHAoZJ7rOq2lis(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠶ࡹࡴࠨ൉")
				,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩൊ")
				,PiFkQ5pCJy7fbX(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠳ࡳࡦࠪോ")
				,f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡇࡍࡋࡃࡌࡡࡋࡘ࡙ࡖࡓࡠࡒࡕࡓ࡝ࡏࡅࡔ࠯࠴ࡷࡹ࠭ൌ")
				,EmK3ObA0cwv9Wy(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ്࠭")
				,WmaPChRdQk3YcXwI6zS(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧൎ")
				,HVibA2ES8lY(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠷ࡴࡤࠨ൏")
				,N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷࠫ൐")
				,h5huy6MiXPNfQJF8(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ൑")
				,VH9MDo5z1kxNF07uRJI(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ൒")
				]
xfhCjTXRaFBGOE = [Xl3drKyI9HkDiPEf8RTjwu(u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ൓"),ZhqJoOtcmTVID65HwnLj(u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫൔ"),EEvLoMzFqrlKce(u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬൕ"),ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭ൖ"),PiFkQ5pCJy7fbX(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧൗ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ൘")]
tOnYIHVk4xydqwoLEBKiDN0hX = {
			 N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࡃࡎࡓࡆࡓࠧ൙")		:[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰ࠴ࡳࡷ࠱ࡲࡰࡩ࠭൚")]
			,sDiKwnHcSlYFgWCy1Ak(u"ࠪࡅࡍ࡝ࡁࡌࠩ൛")		:[EEvLoMzFqrlKce(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭൜")]
			,Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡇࡋࡘࡃࡐࠫ൝")		:[h5huy6MiXPNfQJF8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭࠱ࡷࡻ࠭൞")]
			,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡂࡎࡄࡖࡆࡈࠧൟ")		:[EEvLoMzFqrlKce(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪൠ")]
			,ttOu147wErcBvPaSMUY(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫൡ")		:[WmaPChRdQk3YcXwI6zS(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶࠨൢ")]
			,ZhqJoOtcmTVID65HwnLj(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭ൣ")		:[EmK3ObA0cwv9Wy(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ൤")]
			,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ൥")	:[EmK3ObA0cwv9Wy(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ൦")]
			,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ൧")		:[TWexH5PhS1(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ൨")]
			,l5mQdjWyczr7UJVnTp(u"ࠪࡆࡔࡑࡒࡂࠩ൩")		:[EEvLoMzFqrlKce(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ൪")]
			,HH4JMrUDp3lq6hQ(u"ࠬࡈࡒࡔࡖࡈࡎࠬ൫")		:[h5huy6MiXPNfQJF8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ൬")]
			,EmK3ObA0cwv9Wy(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ൭")		:[VOq8Ekue4F(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ൮")]
			,WmaPChRdQk3YcXwI6zS(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ൯")		:[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ൰")]
			,WmaPChRdQk3YcXwI6zS(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭൱")		:[ZEiR0StquOzca9lvPAndYIX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤ࠷ࡧࡪ࡯࠯ࡥࡲࡱࠬ൲")]
			,mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ൳")		:[N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡩ࡬ࡶࡤ࠱ࡷࡰ࡯࡮ࠨ൴")]
			,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ൵")	:[N9olEh0ZMtpOivVfBLK(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡻࡼ࠮ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡶ࡬ࡴࡶࠧ൶")]
			,h5huy6MiXPNfQJF8(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ൷")		:[mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦ࡭ࡲࡧࡦࡢࡰࡶ࠲ࡨࡵ࡭ࠨ൸")]
			,sDiKwnHcSlYFgWCy1Ak(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ൹")	:[PiFkQ5pCJy7fbX(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠹࠲ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵࠩൺ")]
			,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨൻ")		:[VOq8Ekue4F(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࡮ࡰࡹ࠱ࡧࡨ࠭ർ")]
			,oAXJCYqPgyGDtT(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧൽ")	:[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪൾ"),VH9MDo5z1kxNF07uRJI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡭ࡲࡢࡲ࡫ࡵࡱ࠴ࡡࡱ࡫࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬൿ")]
			,sbgu4D2RFMYKm(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭඀")		:[EmK3ObA0cwv9Wy(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡥ࠱ࡨࡷࡧ࡭ࡢࡵ࠺࠲ࡨࡵ࡭ࠨඁ")]
			,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩං")		:[TWexH5PhS1(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱ࠱ࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭ඃ")]
			,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠵ࠫ඄")		:[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡧࡣࡵࡱࡵࠫඅ")]
			,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ආ")		:[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡦࡩࡼࡦࡪࡹࡴ࠯ࡤ࡬ࡨࠬඇ")]
			,VOq8Ekue4F(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨඈ")		:[HH4JMrUDp3lq6hQ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠲ࡨࡥࡴࡶ࠱ࡲࡪࡺࠧඉ")]
			,ttOu147wErcBvPaSMUY(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩඊ")		:[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡤࡦࡣࡧ࠲ࡱ࡯ࡶࡦࠩඋ")]
			,vatyjK4hHAoZJ7rOq2lis(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬඌ")		:[EEvLoMzFqrlKce(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡬ࡤ࡫ࡱࡩࡲࡧ࠮ࡤࡱࡰࠫඍ")]
			,WmaPChRdQk3YcXwI6zS(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ඎ")		:[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣࡥࡶࡰࡧ࠮ࡤࡱࡰࠫඏ")]
			,TWexH5PhS1(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪඐ")	:[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࡯࡫ࡲ࠯ࡵ࡫ࡳࡼ࠭එ")]
			,ttOu147wErcBvPaSMUY(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫඒ")		:[N9olEh0ZMtpOivVfBLK(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡤࡷࡪࡲࡨࡥ࠰࡯࡭ࡳࡱࠧඓ")]
			,sbgu4D2RFMYKm(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ඔ")		:[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࡮ࡤ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡩ࡬ࡰࡷࡧࠫඕ")]
			,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡆࡐࡕࡗࡅࠬඖ")		:[sDiKwnHcSlYFgWCy1Ak(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺ࡮࠳࡬࡯ࡴࡶࡤ࠱ࡹࡼ࠮࡯ࡧࡷࠫ඗")]
			,PiFkQ5pCJy7fbX(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ඘")		:[f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡳࡥࡥ࡫ࡤࠫ඙")]
			,N9olEh0ZMtpOivVfBLK(u"ࠪࡍࡋࡏࡌࡎࠩක")		:[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬඛ"),ttOu147wErcBvPaSMUY(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭ග"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧඝ"),ttOu147wErcBvPaSMUY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩඞ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨඟ")]
			,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬච")	:[TWexH5PhS1(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡧࡲࡣࡣ࡯ࡥ࠲ࡺࡶ࠯࡫ࡴࠫඡ")]
			,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ජ")		:[EmK3ObA0cwv9Wy(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡰࡱ࠱࡯࡮ࡺ࡫ࡰࡶ࠱ࡸࡻ࠭ඣ")]
			,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬඤ")	:[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫඥ"),WmaPChRdQk3YcXwI6zS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࠲࡫ࡽࡳ࠯ࡵࡷࡳࡷ࡫ࠧඦ")]
			,ZEiR0StquOzca9lvPAndYIX(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪට")		:[mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡩࡡ࡮ࠩඨ")]
			,f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡕࡇࡎࡆࡖࠪඩ")		:[ZEiR0StquOzca9lvPAndYIX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧඪ")]
			,EEvLoMzFqrlKce(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨණ")		:[FIHNSc5iuoZanQ2Ytl(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥࡦ࠴ࡣࡢ࡯ࠪඬ")]
			,VH9MDo5z1kxNF07uRJI(u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬත")	:[VH9MDo5z1kxNF07uRJI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࠳ࡹࡨ࠵ࡷ࠱ࡲࡪࡽࡳࠨථ")]
			,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡗࡍࡕࡆࡉࡃࠪද")		:[PiFkQ5pCJy7fbX(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡥ࠰ࡶ࡬ࡴ࡬ࡨࡢ࠰ࡷࡺࠬධ")]
			,N0Kvne8UYar9fhRxboWsXJCVzid(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧන")		:[mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭඲"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧඳ"),h5huy6MiXPNfQJF8(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫප")]
			,WmaPChRdQk3YcXwI6zS(u"ࠩࡗ࡚ࡋ࡛ࡎࠨඵ")		:[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨබ")]
			,f5uqIoSJzWBOFyrY78RXmVb(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫභ")		:[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡸ࡯࠯࠰࠱࠲࠳࠭࡯ࡼࡨࡦࡨࡧ࠵ࡨࡦ࠺ࡳࡩ࡫࠰ࡣ࡫ࡪࡰ࡭࠴࡭ࡺࡥ࡬࡭ࡲࡧ࠭ࡸࡧࡦ࡭࡮ࡳࡡ࠯ࡵ࡫ࡳࡵ࠭ම")]
			,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࡙࠭ࡂࡓࡒࡘࠬඹ")		:[EEvLoMzFqrlKce(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬය")]
			,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩර")		:[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ඼")]
			,EEvLoMzFqrlKce(u"ࠪࡖࡊࡖࡏࡔࠩල")		:[sDiKwnHcSlYFgWCy1Ak(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ඾"),ZhqJoOtcmTVID65HwnLj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ඿"),VH9MDo5z1kxNF07uRJI(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪව")]
			,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪශ")	:[mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ෂ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠼࠴ࡧࡤࡥࡱࡱࡷ࠶࠾࠮ࡹ࡯࡯ࠫස"),h5huy6MiXPNfQJF8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠾࠵ࡡࡥࡦࡲࡲࡸ࠷࠹࠯ࡺࡰࡰࠬහ")]
			,VOq8Ekue4F(u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬළ")		:[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬෆ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫ࠫ෇"),TWexH5PhS1(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑࠪ෈")]
			}
if sbgu4D2RFMYKm(u"࠱ᒥ"):
	tOnYIHVk4xydqwoLEBKiDN0hX[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ෉")] = [N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼ්ࠫ"),PiFkQ5pCJy7fbX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ෋"),N9olEh0ZMtpOivVfBLK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ෌"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ෍"),HH4JMrUDp3lq6hQ(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ෎"),sDiKwnHcSlYFgWCy1Ak(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ා"),VOq8Ekue4F(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩැ"),ttOu147wErcBvPaSMUY(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡦࡥࡵࡺࡣࡩࡣࠪෑ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡸࡪࡹࡴࡪࡰࡪࠫි")]
	tOnYIHVk4xydqwoLEBKiDN0hX[HH4JMrUDp3lq6hQ(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨී")] = [PiFkQ5pCJy7fbX(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨු"),ZEiR0StquOzca9lvPAndYIX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ෕"),sbgu4D2RFMYKm(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫූ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ෗"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧෘ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪෙ"),FIHNSc5iuoZanQ2Ytl(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭ේ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧෛ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨො")]
else:
	tOnYIHVk4xydqwoLEBKiDN0hX[EEvLoMzFqrlKce(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧෝ")] = [VH9MDo5z1kxNF07uRJI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫෞ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨෟ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ෠"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ෡"),HVibA2ES8lY(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ෢"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭෣"),TWexH5PhS1(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ෤"),HH4JMrUDp3lq6hQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡦࡥࡵࡺࡣࡩࡣࠪ෥"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡸࡪࡹࡴࡪࡰࡪࠫ෦")]
	tOnYIHVk4xydqwoLEBKiDN0hX[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧ෧")] = [g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ෨"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ෩"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ෪"),PiFkQ5pCJy7fbX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭෫"),PiFkQ5pCJy7fbX(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭෬"),EEvLoMzFqrlKce(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ෭"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ෮"),VOq8Ekue4F(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭෯"),EEvLoMzFqrlKce(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ෰")]
uuKXHhOMlYzfQVR = [h5huy6MiXPNfQJF8(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ෱"),EmK3ObA0cwv9Wy(u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨෲ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡇࡐࡅࡎࡒࡓࠨෳ"),sbgu4D2RFMYKm(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ෴"),sDiKwnHcSlYFgWCy1Ak(u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ෵"),VOq8Ekue4F(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ෶"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪ෷"),WmaPChRdQk3YcXwI6zS(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ෸"),ttOu147wErcBvPaSMUY(u"ࠧࡕࡇࡖࡘࡎࡔࡇࠨ෹")]
ZzyLYF3OidfSkKa79nhPecgjxIJE = [HVibA2ES8lY(u"ࠨࡃࡇࡈࡔࡔࡓࠨ෺"),VH9MDo5z1kxNF07uRJI(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ෻"),h5huy6MiXPNfQJF8(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ෼")]
class GY39Leqb7SoO(awRv8kI51963jzSpLAUNb):
	def __init__(Q0GaWbo7qn12dgsfcNUT5IjElR,*aargs,**kkwargs):
		Q0GaWbo7qn12dgsfcNUT5IjElR.choiceID = -g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲ᒦ")
	def onClick(Q0GaWbo7qn12dgsfcNUT5IjElR,Ow5pCEv2QfD490UxtsFRlWgSyJk):
		if Ow5pCEv2QfD490UxtsFRlWgSyJk>=cbngtp9sqYi0DjeEMLRHJruKxm(u"࠻࠳࠵࠵ᒧ"): Q0GaWbo7qn12dgsfcNUT5IjElR.choiceID = Ow5pCEv2QfD490UxtsFRlWgSyJk-cbngtp9sqYi0DjeEMLRHJruKxm(u"࠻࠳࠵࠵ᒧ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.odgLC1UG5xIm6ZHnzqvNMRwpEh42et()
	def yivr3DA9pgdFu62m1e5TPNHlIw(Q0GaWbo7qn12dgsfcNUT5IjElR,*aargs):
		Q0GaWbo7qn12dgsfcNUT5IjElR.button0,Q0GaWbo7qn12dgsfcNUT5IjElR.button1,Q0GaWbo7qn12dgsfcNUT5IjElR.button2 = aargs[mNkfJnpOrad7hT6PYyciwsSDQ(u"࠴ᒩ")],aargs[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠴ᒨ")],aargs[N9olEh0ZMtpOivVfBLK(u"࠷ᒪ")]
		Q0GaWbo7qn12dgsfcNUT5IjElR.header,Q0GaWbo7qn12dgsfcNUT5IjElR.text = aargs[l5mQdjWyczr7UJVnTp(u"࠹ᒫ")],aargs[HH4JMrUDp3lq6hQ(u"࠴ᒬ")]
		Q0GaWbo7qn12dgsfcNUT5IjElR.profile,Q0GaWbo7qn12dgsfcNUT5IjElR.direction = aargs[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶ᒭ")],aargs[Xl3drKyI9HkDiPEf8RTjwu(u"࠸ᒮ")]
		Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout,Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout = aargs[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠻ᒰ")],aargs[N9olEh0ZMtpOivVfBLK(u"࠻ᒯ")]
		if Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout>uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠵ᒱ") or Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout>uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠵ᒱ"): Q0GaWbo7qn12dgsfcNUT5IjElR.enable_progressbar = Xl3drKyI9HkDiPEf8RTjwu(u"ࡘࡷࡻࡥᛮ")
		else: Q0GaWbo7qn12dgsfcNUT5IjElR.enable_progressbar = ttOu147wErcBvPaSMUY(u"ࡋࡧ࡬ࡴࡧᛯ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename = Any0C7sBJTuiGW.replace(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ෽"),HH4JMrUDp3lq6hQ(u"ࠬࡥࠧ෾")+str(D1vBJgya85Yh4cRTCkIMKtWLSeH.time())+ttOu147wErcBvPaSMUY(u"࠭࡟ࠨ෿"))
		Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename = Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename.replace(HH4JMrUDp3lq6hQ(u"ࠧ࡝࡞ࠪ฀"),WmaPChRdQk3YcXwI6zS(u"ࠨ࡞࡟ࡠࡡ࠭ก")).replace(HVibA2ES8lY(u"ࠩ࠲࠳ࠬข"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪ࠳࠴࠵࠯ࠨฃ"))
		Q0GaWbo7qn12dgsfcNUT5IjElR.image_height = WmJZHlzfcbuqFd6(Q0GaWbo7qn12dgsfcNUT5IjElR.button0,Q0GaWbo7qn12dgsfcNUT5IjElR.button1,Q0GaWbo7qn12dgsfcNUT5IjElR.button2,Q0GaWbo7qn12dgsfcNUT5IjElR.header,Q0GaWbo7qn12dgsfcNUT5IjElR.text,Q0GaWbo7qn12dgsfcNUT5IjElR.profile,Q0GaWbo7qn12dgsfcNUT5IjElR.direction,Q0GaWbo7qn12dgsfcNUT5IjElR.enable_progressbar,Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename)
		Q0GaWbo7qn12dgsfcNUT5IjElR.show()
		Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(ZhqJoOtcmTVID65HwnLj(u"࠿࠰࠶࠲ᒲ")).setImage(Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename)
		Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(PiFkQ5pCJy7fbX(u"࠹࠱࠷࠳ᒳ")).setHeight(Q0GaWbo7qn12dgsfcNUT5IjElR.image_height)
		if not Q0GaWbo7qn12dgsfcNUT5IjElR.button1 and Q0GaWbo7qn12dgsfcNUT5IjElR.button0 and Q0GaWbo7qn12dgsfcNUT5IjElR.button2: Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(Xl3drKyI9HkDiPEf8RTjwu(u"࠻࠳࠵࠷ᒵ")).setPosition(-HVibA2ES8lY(u"࠵࠶࠵ᒶ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠱ᒴ"))
		return Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename,Q0GaWbo7qn12dgsfcNUT5IjElR.image_height
	def vtry9jNZi8xP0JIuXUHqFgsA(Q0GaWbo7qn12dgsfcNUT5IjElR):
		if Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout:
			Q0GaWbo7qn12dgsfcNUT5IjElR.th1 = RZxCcFI8fw31NKP.Thread(target=Q0GaWbo7qn12dgsfcNUT5IjElR.nEB2j6LDKg0OupW4UTxbFZ,args=())
			Q0GaWbo7qn12dgsfcNUT5IjElR.th1.start()
		else: Q0GaWbo7qn12dgsfcNUT5IjElR.DhOQRryqHYApc9F()
	def nEB2j6LDKg0OupW4UTxbFZ(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(sDiKwnHcSlYFgWCy1Ak(u"࠽࠵࠸࠰ᒷ")).setEnabled(mNkfJnpOrad7hT6PYyciwsSDQ(u"࡚ࡲࡶࡧᛰ"))
		for H3ABEcMzfyqwF4Ug2ZYtK in range(oAXJCYqPgyGDtT(u"࠶ᒸ"),Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout+oAXJCYqPgyGDtT(u"࠶ᒸ")):
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(WmaPChRdQk3YcXwI6zS(u"࠷ᒹ"))
			rnO1Hxh0MYDVZEifj = int(N9olEh0ZMtpOivVfBLK(u"࠱࠱࠲ᒺ")*H3ABEcMzfyqwF4Ug2ZYtK/Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout)
			Q0GaWbo7qn12dgsfcNUT5IjElR.llWvebTduX(rnO1Hxh0MYDVZEifj)
			if Q0GaWbo7qn12dgsfcNUT5IjElR.choiceID>h5huy6MiXPNfQJF8(u"࠱ᒻ"): break
		Q0GaWbo7qn12dgsfcNUT5IjElR.DhOQRryqHYApc9F()
	def dwxVfqIcpKC5nO0ALyj(Q0GaWbo7qn12dgsfcNUT5IjElR):
		if Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout:
			Q0GaWbo7qn12dgsfcNUT5IjElR.th2 = RZxCcFI8fw31NKP.Thread(target=Q0GaWbo7qn12dgsfcNUT5IjElR.dMkQV2pHTAf70Cgbwyc49Ys5ae,args=())
			Q0GaWbo7qn12dgsfcNUT5IjElR.th2.start()
		else: Q0GaWbo7qn12dgsfcNUT5IjElR.DhOQRryqHYApc9F()
	def dMkQV2pHTAf70Cgbwyc49Ys5ae(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(oAXJCYqPgyGDtT(u"࠻࠳࠶࠵ᒼ")).setEnabled(ZhqJoOtcmTVID65HwnLj(u"ࡔࡳࡷࡨᛱ"))
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(Q0GaWbo7qn12dgsfcNUT5IjElR.buttonstimeout)
		for H3ABEcMzfyqwF4Ug2ZYtK in range(Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout-FIHNSc5iuoZanQ2Ytl(u"࠴ᒽ"),-FIHNSc5iuoZanQ2Ytl(u"࠴ᒽ"),-FIHNSc5iuoZanQ2Ytl(u"࠴ᒽ")):
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠵ᒾ"))
			rnO1Hxh0MYDVZEifj = int(vatyjK4hHAoZJ7rOq2lis(u"࠶࠶࠰ᒿ")*H3ABEcMzfyqwF4Ug2ZYtK/Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout)
			Q0GaWbo7qn12dgsfcNUT5IjElR.llWvebTduX(rnO1Hxh0MYDVZEifj)
			if Q0GaWbo7qn12dgsfcNUT5IjElR.choiceID>sDiKwnHcSlYFgWCy1Ak(u"࠶ᓀ"): break
		if Q0GaWbo7qn12dgsfcNUT5IjElR.closetimeout>EEvLoMzFqrlKce(u"࠰ᓁ"): Q0GaWbo7qn12dgsfcNUT5IjElR.choiceID = ZhqJoOtcmTVID65HwnLj(u"࠲࠲ᓂ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.odgLC1UG5xIm6ZHnzqvNMRwpEh42et()
	def llWvebTduX(Q0GaWbo7qn12dgsfcNUT5IjElR,rnO1Hxh0MYDVZEifj):
		Q0GaWbo7qn12dgsfcNUT5IjElR.precent = rnO1Hxh0MYDVZEifj
		Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(oAXJCYqPgyGDtT(u"࠻࠳࠶࠵ᓃ")).setPercent(Q0GaWbo7qn12dgsfcNUT5IjElR.precent)
	def DhOQRryqHYApc9F(Q0GaWbo7qn12dgsfcNUT5IjElR):
		if Q0GaWbo7qn12dgsfcNUT5IjElR.button0: Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(sDiKwnHcSlYFgWCy1Ak(u"࠼࠴࠶࠶ᓄ")).setEnabled(EEvLoMzFqrlKce(u"ࡕࡴࡸࡩᛲ"))
		if Q0GaWbo7qn12dgsfcNUT5IjElR.button1: Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠽࠵࠷࠱ᓅ")).setEnabled(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡖࡵࡹࡪᛳ"))
		if Q0GaWbo7qn12dgsfcNUT5IjElR.button2: Q0GaWbo7qn12dgsfcNUT5IjElR.getControl(ZhqJoOtcmTVID65HwnLj(u"࠾࠶࠱࠳ᓆ")).setEnabled(ZEiR0StquOzca9lvPAndYIX(u"ࡗࡶࡺ࡫ᛴ"))
	def odgLC1UG5xIm6ZHnzqvNMRwpEh42et(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.close()
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(Q0GaWbo7qn12dgsfcNUT5IjElR.image_filename)
		except: pass
class Zeq6ARs9joiXNQ():
	def __init__(Q0GaWbo7qn12dgsfcNUT5IjElR,showDialogs=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡋࡧ࡬ࡴࡧᛶ"),logErrors=N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡘࡷࡻࡥᛵ")):
		Q0GaWbo7qn12dgsfcNUT5IjElR.showDialogs = showDialogs
		Q0GaWbo7qn12dgsfcNUT5IjElR.logErrors = logErrors
		Q0GaWbo7qn12dgsfcNUT5IjElR.finishedLIST,Q0GaWbo7qn12dgsfcNUT5IjElR.failedLIST = [],[]
		Q0GaWbo7qn12dgsfcNUT5IjElR.statusDICT,Q0GaWbo7qn12dgsfcNUT5IjElR.resultsDICT = {},{}
		Q0GaWbo7qn12dgsfcNUT5IjElR.processesLIST = []
		Q0GaWbo7qn12dgsfcNUT5IjElR.starttimeDICT,Q0GaWbo7qn12dgsfcNUT5IjElR.finishtimeDICT,Q0GaWbo7qn12dgsfcNUT5IjElR.elpasedtimeDICT = {},{},{}
	def hIL3twQ4mE2G1RYKcW(Q0GaWbo7qn12dgsfcNUT5IjElR,kUVqWbOTsMBI8iL26RpD9YuzJl0,FjLgvY9G5S7yU42VkTfPJwN8,*aargs):
		kUVqWbOTsMBI8iL26RpD9YuzJl0 = str(kUVqWbOTsMBI8iL26RpD9YuzJl0)
		Q0GaWbo7qn12dgsfcNUT5IjElR.statusDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬค")
		if Q0GaWbo7qn12dgsfcNUT5IjElR.showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(VOq8Ekue4F(u"ࠬ࠭ฅ"),kUVqWbOTsMBI8iL26RpD9YuzJl0)
		tGuBrszwxTkWA3OIc = RZxCcFI8fw31NKP.Thread(target=Q0GaWbo7qn12dgsfcNUT5IjElR.E5zdtgx2O38MfSFG7v,args=(kUVqWbOTsMBI8iL26RpD9YuzJl0,FjLgvY9G5S7yU42VkTfPJwN8,aargs))
		Q0GaWbo7qn12dgsfcNUT5IjElR.processesLIST.append(tGuBrszwxTkWA3OIc)
		return tGuBrszwxTkWA3OIc
	def ng0pbr1xPzOWfil4ao(Q0GaWbo7qn12dgsfcNUT5IjElR,kUVqWbOTsMBI8iL26RpD9YuzJl0,FjLgvY9G5S7yU42VkTfPJwN8,*aargs):
		tGuBrszwxTkWA3OIc = Q0GaWbo7qn12dgsfcNUT5IjElR.hIL3twQ4mE2G1RYKcW(kUVqWbOTsMBI8iL26RpD9YuzJl0,FjLgvY9G5S7yU42VkTfPJwN8,*aargs)
		tGuBrszwxTkWA3OIc.start()
	def E5zdtgx2O38MfSFG7v(Q0GaWbo7qn12dgsfcNUT5IjElR,kUVqWbOTsMBI8iL26RpD9YuzJl0,FjLgvY9G5S7yU42VkTfPJwN8,aargs):
		kUVqWbOTsMBI8iL26RpD9YuzJl0 = str(kUVqWbOTsMBI8iL26RpD9YuzJl0)
		Q0GaWbo7qn12dgsfcNUT5IjElR.starttimeDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
		try:
			Q0GaWbo7qn12dgsfcNUT5IjElR.resultsDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = FjLgvY9G5S7yU42VkTfPJwN8(*aargs)
			if cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧฆ") in str(FjLgvY9G5S7yU42VkTfPJwN8) and not Q0GaWbo7qn12dgsfcNUT5IjElR.resultsDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0].succeeded:
				v9BiEYVb3fcZrql0(ZEiR0StquOzca9lvPAndYIX(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡺࡨࡳࡧࡤࡨࡪࡪࠠࡐࡒࡈࡒ࡚ࡘࡌࠡࡨࡤ࡭ࡱ࠭ง"))
			Q0GaWbo7qn12dgsfcNUT5IjElR.finishedLIST.append(kUVqWbOTsMBI8iL26RpD9YuzJl0)
			Q0GaWbo7qn12dgsfcNUT5IjElR.statusDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = N9olEh0ZMtpOivVfBLK(u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪจ")
		except Exception as RKq8Hda7ENycxDT1iZz9A3sLU5:
			if Q0GaWbo7qn12dgsfcNUT5IjElR.logErrors:
				WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
				if WzeExBTV6h!=WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬฉ"): CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
			Q0GaWbo7qn12dgsfcNUT5IjElR.failedLIST.append(kUVqWbOTsMBI8iL26RpD9YuzJl0)
			Q0GaWbo7qn12dgsfcNUT5IjElR.statusDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = N9olEh0ZMtpOivVfBLK(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪช")
		Q0GaWbo7qn12dgsfcNUT5IjElR.finishtimeDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
		Q0GaWbo7qn12dgsfcNUT5IjElR.elpasedtimeDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] = Q0GaWbo7qn12dgsfcNUT5IjElR.finishtimeDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0] - Q0GaWbo7qn12dgsfcNUT5IjElR.starttimeDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0]
	def XqxkFKEmSaoMV4JrOu2IYPiRh7lsC(Q0GaWbo7qn12dgsfcNUT5IjElR):
		for iqzhk2QBfF8 in Q0GaWbo7qn12dgsfcNUT5IjElR.processesLIST:
			iqzhk2QBfF8.start()
	def Lag8UeJ9CPylkIp5XHOb(Q0GaWbo7qn12dgsfcNUT5IjElR):
		while vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬซ") in list(Q0GaWbo7qn12dgsfcNUT5IjElR.statusDICT.values()): D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(PiFkQ5pCJy7fbX(u"࠷࠮࠱࠲࠳ᓇ"))
def c2cBdOWIa7():
	FeJkKctiN0rwxvlg2C8G4oyq = YTPut68WBVUNCvsEzg.getSetting(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩฌ"))
	if FeJkKctiN0rwxvlg2C8G4oyq==pQmoyUJBNaf72A:
		oDGfiM8qKTZYIF4kadmJLr,v05aJEsnIF = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࡎࡐࡡࡘࡔࡉࡇࡔࡆࠩญ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡌࡡ࡭ࡵࡨᛷ")
		return oDGfiM8qKTZYIF4kadmJLr,v05aJEsnIF
	try: isWjwHOERYXhAp0ZuNdKUgkCM7.makedirs(jNhH3xrnWkFUqv8c09OybXRTl)
	except: pass
	oDGfiM8qKTZYIF4kadmJLr,v05aJEsnIF = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡇࡗࡏࡐࡤ࡛ࡐࡅࡃࡗࡉࠬฎ"),WmaPChRdQk3YcXwI6zS(u"ࡔࡳࡷࡨᛸ")
	RbqmycMhW7njtozVLgd9UCBI2 = [N9olEh0ZMtpOivVfBLK(u"ࠨ࠺࠱࠹࠳࠶ࠧฏ"),sDiKwnHcSlYFgWCy1Ak(u"ࠩ࠵࠴࠷࠷࠮࠲࠲࠱࠵࠾࠭ฐ"),h5huy6MiXPNfQJF8(u"ࠪ࠶࠵࠸࠱࠯࠳࠴࠲࠷࠺ࡡࠨฑ"),HH4JMrUDp3lq6hQ(u"ࠫ࠷࠶࠲࠲࠰࠴࠶࠳࠹࠰ࠨฒ"),TWexH5PhS1(u"ࠬ࠸࠰࠳࠴࠱࠴࠷࠴࠰࠳ࠩณ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࠲࠱࠴࠵࠲࠶࠶࠮࠳࠴ࠪด"),N9olEh0ZMtpOivVfBLK(u"ࠧ࠳࠲࠵࠷࠳࠶࠳࠯࠲࠹ࠫต"),VOq8Ekue4F(u"ࠨ࠴࠳࠶࠸࠴࠰࠶࠰࠴࠺ࠬถ"),EmK3ObA0cwv9Wy(u"ࠩ࠵࠴࠷࠹࠮࠱࠸࠱࠴࠻࠭ท"),sDiKwnHcSlYFgWCy1Ak(u"ࠪ࠶࠵࠸࠳࠯࠳࠳࠲࠷࠾ࠧธ"),ttOu147wErcBvPaSMUY(u"ࠫ࠷࠶࠲࠵࠰࠳࠵࠳࠷࠴ࠨน")]
	kvDQFP8xdZ = RbqmycMhW7njtozVLgd9UCBI2[-HVibA2ES8lY(u"࠱ᓈ")]
	GG9khe1sS6H3rmyi4VBvYL = EX7zl3J1Ph8fOWpxQTdZboLNF4(kvDQFP8xdZ)
	a4PjEnedtYq2GM6VNu = EX7zl3J1Ph8fOWpxQTdZboLNF4(pQmoyUJBNaf72A)
	if a4PjEnedtYq2GM6VNu>GG9khe1sS6H3rmyi4VBvYL:
		oDGfiM8qKTZYIF4kadmJLr = N0Kvne8UYar9fhRxboWsXJCVzid(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬบ")
	return oDGfiM8qKTZYIF4kadmJLr,v05aJEsnIF
def RzTlDFk1Zdj29e6CX():
	if g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲ᓉ"):
		FFSVwRQNBjneGOH3IMboK7gm9L = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠲ᓊ")
		for BBRzg6M9rsDEjJ,D8eY6yCT4gIpbXKRrkGBQ3SP,M8x7cvbo3JjtsQF in isWjwHOERYXhAp0ZuNdKUgkCM7.walk(UIl7EzK48anPkH,topdown=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡇࡣ࡯ࡷࡪ᛹")):
			FFSVwRQNBjneGOH3IMboK7gm9L += len(M8x7cvbo3JjtsQF)
	if FFSVwRQNBjneGOH3IMboK7gm9L>HVibA2ES8lY(u"࠸࠴࠵࠶ᓋ"): P8vtuTghFN7lWIS(UIl7EzK48anPkH,HVibA2ES8lY(u"ࡗࡶࡺ࡫᛻"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡈࡤࡰࡸ࡫᛺"))
	return
def rS3V6a9s8vl(MMVPRsn2G4YK6byiwvO,uUeNnkywGtlj36V2dX7L):
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࡙ࡸࡵࡦ᛽"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࡊࡦࡲࡳࡦ᛼"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࡊࡦࡲࡳࡦ᛼")
	otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,ZZ6GOtiQdngANT,DkjbIhZoVd7F52r6Ew,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = MMVPRsn2G4YK6byiwvO
	MGedk8WjmRIxFEC0bVOy = otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,ZZ6GOtiQdngANT,DkjbIhZoVd7F52r6Ew,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,N9olEh0ZMtpOivVfBLK(u"࠭ࠧป"),RLg3NjAdqfTMl
	B23DvidbEG0TwXFnexpftIs = int(DkjbIhZoVd7F52r6Ew)
	R8lD7usCLfZSPAvBz = int(B23DvidbEG0TwXFnexpftIs%vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠵࠵ᓌ"))
	VoJz4e67SfIUB5th = int(B23DvidbEG0TwXFnexpftIs/sDiKwnHcSlYFgWCy1Ak(u"࠶࠶ᓍ"))
	QVmqy4xbelgnkFzYp = YTPut68WBVUNCvsEzg.getSetting(HH4JMrUDp3lq6hQ(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧผ"))
	if not QVmqy4xbelgnkFzYp: YTPut68WBVUNCvsEzg.setSetting(l5mQdjWyczr7UJVnTp(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨฝ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡄ࡙࡙ࡕࠧพ"))
	FYZhrd2tOSEu3,v05aJEsnIF = c2cBdOWIa7()
	if v05aJEsnIF:
		KK47FGdX1TDfkb3AjHOQqghE(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠫฟ"),h5huy6MiXPNfQJF8(u"ࠫࠬภ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨม"),TWexH5PhS1(u"࠭สๆࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣๅ๏ࠦฬ่ษี็ࡡࡴลๅ๋ࠣห้หีะษิࠤึ่ๅ࠻࡞ࡱࡠࡳ࠭ย")+pQmoyUJBNaf72A)
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,ZEiR0StquOzca9lvPAndYIX(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪร"),sDiKwnHcSlYFgWCy1Ak(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫฤ"))
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,PiFkQ5pCJy7fbX(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬล"),l5mQdjWyczr7UJVnTp(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫฦ"))
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,oAXJCYqPgyGDtT(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧว"),sbgu4D2RFMYKm(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪศ"))
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,sDiKwnHcSlYFgWCy1Ak(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩษ"),HH4JMrUDp3lq6hQ(u"ࠧࡔࡋࡗࡉࡘࡥࡃࡉࡇࡆࡏࠬส"))
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,FIHNSc5iuoZanQ2Ytl(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫห"),HH4JMrUDp3lq6hQ(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨฬ"))
		YTPut68WBVUNCvsEzg.setSetting(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡵࡳࡵࡣࠪอ"),VH9MDo5z1kxNF07uRJI(u"ࠫࠬฮ"))
		YTPut68WBVUNCvsEzg.setSetting(PiFkQ5pCJy7fbX(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡤࡵࡥࡰࡧࠧฯ"),VOq8Ekue4F(u"࠭ࠧะ"))
		YTPut68WBVUNCvsEzg.setSetting(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪั"),VH9MDo5z1kxNF07uRJI(u"ࠨࠩา"))
		YTPut68WBVUNCvsEzg.setSetting(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬำ"),sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫิ"))
		YTPut68WBVUNCvsEzg.setSetting(sbgu4D2RFMYKm(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ี"),HVibA2ES8lY(u"ࠬ࠭ึ"))
		YTPut68WBVUNCvsEzg.setSetting(N9olEh0ZMtpOivVfBLK(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨื"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠨุ"))
		YTPut68WBVUNCvsEzg.setSetting(HVibA2ES8lY(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ูࠬ"),EmK3ObA0cwv9Wy(u"ฺࠩࠪ"))
		YTPut68WBVUNCvsEzg.setSetting(HVibA2ES8lY(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪ฻"),TWexH5PhS1(u"ࠫࠬ฼"))
		YTPut68WBVUNCvsEzg.setSetting(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭฽"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠧ฾"))
		YTPut68WBVUNCvsEzg.setSetting(VH9MDo5z1kxNF07uRJI(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ฿"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩเ"))
		import TRa6GJnHO1
		if FYZhrd2tOSEu3==WmaPChRdQk3YcXwI6zS(u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩแ"):
			GZvEITHSg5U3rVwQ(vatyjK4hHAoZJ7rOq2lis(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪโ"),ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠳ࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪใ")+pyDQJ34XlhL6OmuoPk5UvSjN08MVG+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࠦ࡝ࠨไ"))
			Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,EmK3ObA0cwv9Wy(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧๅ"))
			Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,EmK3ObA0cwv9Wy(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧๆ"))
			Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ็"))
			R1JaOzyTLxfMvBigeYuhn(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࡚ࡲࡶࡧ᛾"),[ttbwouYhASpBDJiHZEaLkegM3G])
		else:
			GZvEITHSg5U3rVwQ(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡑࡓ࡙ࡏࡃࡆ่ࠩ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪ࠲ࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤࠥࡌࡕࡍࡎ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠ้ࠦࠧ")+pyDQJ34XlhL6OmuoPk5UvSjN08MVG+VH9MDo5z1kxNF07uRJI(u"ࠫࠥࡣ๊ࠧ"))
			KK47FGdX1TDfkb3AjHOQqghE(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"๋ࠬ࠭"),sDiKwnHcSlYFgWCy1Ak(u"࠭ࠧ์"),ZEiR0StquOzca9lvPAndYIX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪํ"),vatyjK4hHAoZJ7rOq2lis(u"ࠨฬ่ࠤฯัศ๋ฬࠣวํࠦสฮัํฯࠥอไฦืาหึࠦวๅฮา๎ิࠦไษำ้ห๊าࠠศๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฤ๊ࠣฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ࡟ࡲࡡࡴࠠิ์ๅ์๊ࠦวๅฤ้ࠤฬ๊ศา่ส้ัࠦศษ฻ูࠤฬ๊แฮุ๊หฯࠦไื็ส๊ࠥ฿ๅๅࠢส่อืๆศ็ฯࠤอ฻่าหูࠣา๐อส๋้ࠢฯ้วๆๆฬࠫ๎"))
			R1JaOzyTLxfMvBigeYuhn(VH9MDo5z1kxNF07uRJI(u"ࡆࡢ࡮ࡶࡩ᛿"),[])
			bkfanGl0mAz8hM6(FIHNSc5iuoZanQ2Ytl(u"ࡇࡣ࡯ࡷࡪᜀ"))
			TRa6GJnHO1.haHi7X9cIxTqslOg()
			TRa6GJnHO1.PKyL2wI9WdZEbzs4t5muq(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ๏"),sDiKwnHcSlYFgWCy1Ak(u"ࡈࡤࡰࡸ࡫ᜁ"))
			TRa6GJnHO1.PKyL2wI9WdZEbzs4t5muq(VOq8Ekue4F(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠭๐"),h5huy6MiXPNfQJF8(u"ࡉࡥࡱࡹࡥᜂ"))
			TRa6GJnHO1.QceuJfq72gU6MPWzVdDLi3Kkv(FIHNSc5iuoZanQ2Ytl(u"ࡊࡦࡲࡳࡦᜃ"))
			TRa6GJnHO1.woiPZbJMcS2Ee3D(EmK3ObA0cwv9Wy(u"ࡋࡧ࡬ࡴࡧᜄ"))
			TRa6GJnHO1.UUBtkHi6syZIDJluXmxr9g(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ๑"),EmK3ObA0cwv9Wy(u"ࠬ࡫࡮ࡢࡤ࡯ࡩࠬ๒"),f5uqIoSJzWBOFyrY78RXmVb(u"ࡌࡡ࡭ࡵࡨᜅ"))
			try:
				ZLpJh0GYEfc4l2tUkCrMv = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ๓"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ๔"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ๕"),VH9MDo5z1kxNF07uRJI(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ๖"))
				H7f413XdsvunglexiWpNEoK09z6P5 = zzWKEDg14fbwQ5X7G.Addon(id=sbgu4D2RFMYKm(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ๗"))
				H7f413XdsvunglexiWpNEoK09z6P5.setSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪ๘"),oAXJCYqPgyGDtT(u"ࠬ࡬ࡡ࡭ࡵࡨࠫ๙"))
			except: pass
			try:
				ZLpJh0GYEfc4l2tUkCrMv = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,TWexH5PhS1(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ๚"),ZhqJoOtcmTVID65HwnLj(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ๛"),h5huy6MiXPNfQJF8(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ๜"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ๝"))
				H7f413XdsvunglexiWpNEoK09z6P5 = zzWKEDg14fbwQ5X7G.Addon(id=f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ๞"))
				H7f413XdsvunglexiWpNEoK09z6P5.setSetting(PiFkQ5pCJy7fbX(u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧ๟"),ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠹ࠧ๠"))
			except: pass
			try:
				ZLpJh0GYEfc4l2tUkCrMv = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,ZhqJoOtcmTVID65HwnLj(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ๡"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ๢"),EEvLoMzFqrlKce(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๣"),VH9MDo5z1kxNF07uRJI(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ๤"))
				H7f413XdsvunglexiWpNEoK09z6P5 = zzWKEDg14fbwQ5X7G.Addon(id=EmK3ObA0cwv9Wy(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ๥"))
				H7f413XdsvunglexiWpNEoK09z6P5.setSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩ๦"),FIHNSc5iuoZanQ2Ytl(u"ࠬ࠸ࠧ๧"))
			except: pass
		Z402tBVhQi = JOhs5QkibGTnZ0CD9dL(oQjDxLF9fdtyCaJ5ZTO860ri1s)
		Z402tBVhQi = JOhs5QkibGTnZ0CD9dL(Yy5epgPqo7D2vT4mQREiuX)
		YTPut68WBVUNCvsEzg.setSetting(sbgu4D2RFMYKm(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ๨"),pQmoyUJBNaf72A)
		TRa6GJnHO1.tDfC9YHmrwBF(ZhqJoOtcmTVID65HwnLj(u"ࡆࡢ࡮ࡶࡩᜆ"))
		return
	B6B7iVh1qW5Py = YTPut68WBVUNCvsEzg.getSetting(sbgu4D2RFMYKm(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ๩"))
	ADGaJxoXtdLcSsC5R4WNj = nhuP4q9F1lmRIjdHUBWaQg(uUeNnkywGtlj36V2dX7L)
	M2WHwz4yUIF = nhuP4q9F1lmRIjdHUBWaQg(eENPgSDsKvOH24QpIbGjZtwnYoFl)
	vjlLNoPe8d5gIstH1X = [HVibA2ES8lY(u"࠶ᓕ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠱࠶ᓏ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠲࠹ᓐ"),PiFkQ5pCJy7fbX(u"࠳࠼ᓑ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸࠶ᓎ"),ZEiR0StquOzca9lvPAndYIX(u"࠸࠺ᓔ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠸࠴ᓒ"),FIHNSc5iuoZanQ2Ytl(u"࠹࠸ᓓ")]
	qMSf0XblF8i1Th297zZrH = [EmK3ObA0cwv9Wy(u"࠰ᓝ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠲࠷ᓗ"),PiFkQ5pCJy7fbX(u"࠳࠺ᓘ"),HH4JMrUDp3lq6hQ(u"࠴࠽ᓙ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠲࠷ᓖ"),vatyjK4hHAoZJ7rOq2lis(u"࠹࠴ᓜ"),l5mQdjWyczr7UJVnTp(u"࠹࠵ᓚ"),EEvLoMzFqrlKce(u"࠺࠹ᓛ")]
	A1E5ayJOn2B = VoJz4e67SfIUB5th not in qMSf0XblF8i1Th297zZrH
	zi56bPTHAhvDE4aULx9Qjftg = VoJz4e67SfIUB5th in [h5huy6MiXPNfQJF8(u"࠶࠸ᓡ"),TWexH5PhS1(u"࠳࠺ᓞ"),EmK3ObA0cwv9Wy(u"࠺࠵ᓠ"),l5mQdjWyczr7UJVnTp(u"࠹࠵ᓟ")]
	wWLf5b16tDqoRBVFrlkQXy = B23DvidbEG0TwXFnexpftIs in [sbgu4D2RFMYKm(u"࠸࠶࠶ᓣ"),vatyjK4hHAoZJ7rOq2lis(u"࠷࠽࠰ᓢ")]
	PqcMbUID6sXpi = (A1E5ayJOn2B or zi56bPTHAhvDE4aULx9Qjftg) and not wWLf5b16tDqoRBVFrlkQXy
	V2FDB4KaHwQMd = B6B7iVh1qW5Py!=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫ๪") and (B6B7iVh1qW5Py or not ytsdYhu8qpWc6nwJlDr32bBPmj)
	jZM9WV4BxNSYzGasEJ = PiFkQ5pCJy7fbX(u"ࠩࡷࡽࡵ࡫࠽ࠨ๫") in B6B7iVh1qW5Py
	wz0EQnxko7 = B23DvidbEG0TwXFnexpftIs in [FIHNSc5iuoZanQ2Ytl(u"࠴࠺࠶ᓮ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵࠻࠸ᓯ"),oAXJCYqPgyGDtT(u"࠶࠼࠳ᓰ"),HH4JMrUDp3lq6hQ(u"࠷࠶࠵ᓪ"),vatyjK4hHAoZJ7rOq2lis(u"࠱࠷࠷ᓫ"),FIHNSc5iuoZanQ2Ytl(u"࠲࠸࠹ᓬ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠳࠹࠻ᓭ"),sbgu4D2RFMYKm(u"࠶࠼࠸ᓩ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠹࠹࠵ᓦ"),sDiKwnHcSlYFgWCy1Ak(u"࠷࠷࠴ᓤ"),EmK3ObA0cwv9Wy(u"࠸࠸࠶ᓥ"),HVibA2ES8lY(u"࠺࠺࠹ᓧ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠻࠻࠻ᓨ")]
	CXz8MpZeQigHAjw47TlbhdcPYoaWG = R8lD7usCLfZSPAvBz==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠿ᓱ") or B23DvidbEG0TwXFnexpftIs in [N9olEh0ZMtpOivVfBLK(u"࠲࠶࠸ᓳ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠸࠵࠻ᓵ"),VOq8Ekue4F(u"࠷࠵࠷ᓴ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠴࠶ᓲ")]
	WStdbCE0u6nk = not wz0EQnxko7
	cceJgqyshvY8dnwZ1WjQ = not CXz8MpZeQigHAjw47TlbhdcPYoaWG
	NZ5zgRxhOnGa6j7C3yHl = ADGaJxoXtdLcSsC5R4WNj in [sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫ๬"),ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠳࠴ࠧ๭")]
	CCFKXBoELWQw0zT8u6Ytk = NZ5zgRxhOnGa6j7C3yHl or WStdbCE0u6nk
	zzrFiComlM6Hu9BQUp8s = NZ5zgRxhOnGa6j7C3yHl or cceJgqyshvY8dnwZ1WjQ or jZM9WV4BxNSYzGasEJ
	SxaR1NyA9QuJZH = B23DvidbEG0TwXFnexpftIs not in [Xl3drKyI9HkDiPEf8RTjwu(u"࠳࠸࠳ᓺ"),ttOu147wErcBvPaSMUY(u"࠶࠻࠷ᓶ"),FIHNSc5iuoZanQ2Ytl(u"࠴࠹࠹ᓻ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"࠸࠷࠱ᓸ"),vatyjK4hHAoZJ7rOq2lis(u"࠸࠹࠰ᓷ"),sbgu4D2RFMYKm(u"࠵࠵࠲ᓹ")]
	if QVmqy4xbelgnkFzYp==l5mQdjWyczr7UJVnTp(u"࡙ࠬࡔࡐࡒࠪ๮"): C4Vo62KHlexZ8UnQfd = CXz8MpZeQigHAjw47TlbhdcPYoaWG or wz0EQnxko7
	else: C4Vo62KHlexZ8UnQfd = sbgu4D2RFMYKm(u"ࡕࡴࡸࡩᜇ")
	otnwkPZ6RV = VoJz4e67SfIUB5th in [Xl3drKyI9HkDiPEf8RTjwu(u"࠻࠹ᓽ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"࠺࠹ᓼ")]
	EEgvFQdexo0MR = B23DvidbEG0TwXFnexpftIs in [g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠷࠾࠰ᓾ"),ZEiR0StquOzca9lvPAndYIX(u"࠽࠲࠱ᓿ")]
	QIiaUkZOyqKV13YFuJSdHMxhNro6nf = not otnwkPZ6RV and not EEgvFQdexo0MR
	DDWuoMHFAXgQKsYl = CCFKXBoELWQw0zT8u6Ytk and zzrFiComlM6Hu9BQUp8s and SxaR1NyA9QuJZH and C4Vo62KHlexZ8UnQfd and QIiaUkZOyqKV13YFuJSdHMxhNro6nf
	WxEvzYVOcgnGq = SxaR1NyA9QuJZH and C4Vo62KHlexZ8UnQfd and QIiaUkZOyqKV13YFuJSdHMxhNro6nf
	GhMiWYeE4U3HzPKjF0tusr5 = WxEvzYVOcgnGq
	ihw1zPdAp6ZUurQclBfOskGYMxyWHL = YTPut68WBVUNCvsEzg.getSetting(EmK3ObA0cwv9Wy(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭๯"))
	yyb6qzJk1PSg = YTPut68WBVUNCvsEzg.getSetting(ZhqJoOtcmTVID65HwnLj(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡩ࡯ࡥࡧࠪ๰"))
	if HH4JMrUDp3lq6hQ(u"࠱ᔀ") and V2FDB4KaHwQMd and DDWuoMHFAXgQKsYl:
		uZMG81vjgFYoB9z6bVHS = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨ࡮࡬ࡷࡹ࠭๱"),HVibA2ES8lY(u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋ࡟ࠨ๲")+ihw1zPdAp6ZUurQclBfOskGYMxyWHL+N9olEh0ZMtpOivVfBLK(u"ࠪࡣࠬ๳")+yyb6qzJk1PSg,MGedk8WjmRIxFEC0bVOy)
		if uZMG81vjgFYoB9z6bVHS:
			GZvEITHSg5U3rVwQ(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬ๴"),ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠴ࠠࠡࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ๵")+ihw1zPdAp6ZUurQclBfOskGYMxyWHL+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭࡟ࠨ๶")+yyb6qzJk1PSg+sDiKwnHcSlYFgWCy1Ak(u"ࠧࠡࠢࠣࡐࡴࡧࡤࡪࡰࡪࠤࡲ࡫࡮ࡶࠢࡩࡶࡴࡳࠠࡤࡣࡦ࡬ࡪ࠭๷"))
			if TWexH5PhS1(u"࠲ᔁ") and jZM9WV4BxNSYzGasEJ:
				RM2bLnKFTHW4k3pvtxmo0SB9 = []
				from JgNmcHTt84 import CHgKVL3m0fv84TdnqPluQwFzjB
				from sGBzntv5FT import sK85VIGrwg0FZcWJ1E7,Rsd7jOX0rvLqQ61kwp8JFBoz4Kf
				LLlHKq6aQSdEJjy07n8gRXTZhmw = CHgKVL3m0fv84TdnqPluQwFzjB
				nAiGMYDVyHT5 = sK85VIGrwg0FZcWJ1E7()
				eoisML5IZTKQyDraEJUO8Xh4wlkmpd = B6B7iVh1qW5Py
				OOMlGbs2yPCZLYnpBVSRo,R04Xx1n7hH3WaOkyJ5NVzmsCiQIeA,DsaTBuMeVh180LSw,oEYiqjgNHGVlcUuf,ltr8k7boGvu1WUsa,wwCbAJrpgieIfNP0,wUVdLK48yYhaW9DmPSoxuiZ,ZDcp0kSVXE,w3W9szu7RXKf6Nni2D05oaqlhM = LsBXYAO5g8fyu0iPkV9(eoisML5IZTKQyDraEJUO8Xh4wlkmpd)
				ddGKEjy8eiQI = OOMlGbs2yPCZLYnpBVSRo,R04Xx1n7hH3WaOkyJ5NVzmsCiQIeA,DsaTBuMeVh180LSw,oEYiqjgNHGVlcUuf,ltr8k7boGvu1WUsa,wwCbAJrpgieIfNP0,wUVdLK48yYhaW9DmPSoxuiZ,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࠩ๸"),w3W9szu7RXKf6Nni2D05oaqlhM
				for mhj1G9WZ4qw5vr in uZMG81vjgFYoB9z6bVHS:
					RBx7HXhcgo24s6zkLY = mhj1G9WZ4qw5vr[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡰࡩࡳࡻࡉࡵࡧࡰࠫ๹")]
					if RBx7HXhcgo24s6zkLY==ddGKEjy8eiQI or mhj1G9WZ4qw5vr[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࡱࡴࡪࡥࠨ๺")] in [VOq8Ekue4F(u"࠵࠺࠺ᔃ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠴࠺࠴ᔂ")]:
						mhj1G9WZ4qw5vr = zmxdfPbJ6AjN52ekGTD4IBEM(RBx7HXhcgo24s6zkLY,LLlHKq6aQSdEJjy07n8gRXTZhmw,nAiGMYDVyHT5)
						if mhj1G9WZ4qw5vr[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ๻")]:
							yOjpvshl1qwrfIGnd6ePTQX4uicN = Rsd7jOX0rvLqQ61kwp8JFBoz4Kf(nAiGMYDVyHT5,RBx7HXhcgo24s6zkLY,mhj1G9WZ4qw5vr[HVibA2ES8lY(u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭๼")])
							mhj1G9WZ4qw5vr[l5mQdjWyczr7UJVnTp(u"࠭ࡣࡰࡰࡷࡩࡽࡺ࡟࡮ࡧࡱࡹࠬ๽")] = yOjpvshl1qwrfIGnd6ePTQX4uicN+mhj1G9WZ4qw5vr[sbgu4D2RFMYKm(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭๾")]
					RM2bLnKFTHW4k3pvtxmo0SB9.append(mhj1G9WZ4qw5vr)
				YTPut68WBVUNCvsEzg.setSetting(sDiKwnHcSlYFgWCy1Ak(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ๿"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࠪ຀"))
				if otciIUKlyb6==FIHNSc5iuoZanQ2Ytl(u"ࠪࡪࡴࡲࡤࡦࡴࠪກ"): rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,VOq8Ekue4F(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪຂ")+ihw1zPdAp6ZUurQclBfOskGYMxyWHL+PiFkQ5pCJy7fbX(u"ࠬࡥࠧ຃")+yyb6qzJk1PSg,MGedk8WjmRIxFEC0bVOy,RM2bLnKFTHW4k3pvtxmo0SB9,GGXxhdg3JCamPIFepybjZ)
			else: RM2bLnKFTHW4k3pvtxmo0SB9 = uZMG81vjgFYoB9z6bVHS
			if otciIUKlyb6==ttOu147wErcBvPaSMUY(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ຄ") and ADGaJxoXtdLcSsC5R4WNj!=sDiKwnHcSlYFgWCy1Ak(u"ࠧ࠯࠰ࠪ຅") and PqcMbUID6sXpi: PHMnCmaZ94fJ8gFl2dzLyvsrA()
			haqtY2PuQKsE6mMk7ZF5y = ivk2tGTsBEV5WpwQ7j8Dex3CouF(MGedk8WjmRIxFEC0bVOy,RM2bLnKFTHW4k3pvtxmo0SB9,UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ)
			return
	elif otciIUKlyb6==cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨຆ") and B6B7iVh1qW5Py==VH9MDo5z1kxNF07uRJI(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬງ") and WxEvzYVOcgnGq:
		Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩຈ")+ihw1zPdAp6ZUurQclBfOskGYMxyWHL+VH9MDo5z1kxNF07uRJI(u"ࠫࡤ࠭ຉ")+yyb6qzJk1PSg,MGedk8WjmRIxFEC0bVOy)
	if ytsdYhu8qpWc6nwJlDr32bBPmj:
		if WmaPChRdQk3YcXwI6zS(u"ࠬࡥࠧຊ") in ytsdYhu8qpWc6nwJlDr32bBPmj: htiNPECHKyzqXTpFx,FFt7GNIEx4q23y = ytsdYhu8qpWc6nwJlDr32bBPmj.split(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭࡟ࠨ຋"),N9olEh0ZMtpOivVfBLK(u"࠵ᔄ"))
		else: htiNPECHKyzqXTpFx,FFt7GNIEx4q23y = ytsdYhu8qpWc6nwJlDr32bBPmj,l5mQdjWyczr7UJVnTp(u"ࠧࠨຌ")
		if htiNPECHKyzqXTpFx in [mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨ࠳ࠪຍ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩ࠵ࠫຎ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪ࠷ࠬຏ"),HVibA2ES8lY(u"ࠫ࠹࠭ຐ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬ࠻ࠧຑ")] and FFt7GNIEx4q23y:
			from sGBzntv5FT import qsR0bXZLNAJk
			qsR0bXZLNAJk(ytsdYhu8qpWc6nwJlDr32bBPmj)
			YTPut68WBVUNCvsEzg.setSetting(f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪຒ"),pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(HVibA2ES8lY(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫຓ"))
			return
		elif htiNPECHKyzqXTpFx==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨ࠸ࠪດ"):
			if FFt7GNIEx4q23y==mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫຕ"): fYPz7RldWQVHBktZAexwvCL8Np3D(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪ๎ึา้ࠡษ็ห๋ะุศำࠪຖ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠫัอั๋ࠢไัฺࠦๅๅใࠣห้ะอๆ์็ࠫທ"))
			elif FFt7GNIEx4q23y==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬࡊࡅࡍࡇࡗࡉࠬຘ"): B23DvidbEG0TwXFnexpftIs = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸࠹࠴ᔅ")
			cLCisPE3lX = WS9BILoVdyriqvp8(otciIUKlyb6,M2WHwz4yUIF,ZZ6GOtiQdngANT,B23DvidbEG0TwXFnexpftIs,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(VOq8Ekue4F(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪນ"))
			return
		elif ytsdYhu8qpWc6nwJlDr32bBPmj==ZhqJoOtcmTVID65HwnLj(u"ࠧ࠸ࠩບ"):
			from E9jOJBma65 import a4axKfpszNO
			a4axKfpszNO()
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(ZhqJoOtcmTVID65HwnLj(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬປ"))
			return
		elif ytsdYhu8qpWc6nwJlDr32bBPmj==Xl3drKyI9HkDiPEf8RTjwu(u"ࠩ࠻ࠫຜ"):
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(oAXJCYqPgyGDtT(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩຝ")+x7NwSuz5ft4e+VOq8Ekue4F(u"ࠫࡄࡳ࡯ࡥࡧࡀࠫພ")+str(DkjbIhZoVd7F52r6Ew)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࠬࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵ࠭ࠬຟ"))
			return
		elif ytsdYhu8qpWc6nwJlDr32bBPmj==vatyjK4hHAoZJ7rOq2lis(u"࠭࠹ࠨຠ"):
			YTPut68WBVUNCvsEzg.setSetting(sDiKwnHcSlYFgWCy1Ak(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫມ"),oAXJCYqPgyGDtT(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫຢ"))
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(sbgu4D2RFMYKm(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ຣ"))
			return
	if YTPut68WBVUNCvsEzg.getSetting(sbgu4D2RFMYKm(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ຤")) not in [mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡆ࡛ࡔࡐࠩລ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࡙ࠬࡔࡐࡒࠪ຦"),EEvLoMzFqrlKce(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧວ")]:
		YTPut68WBVUNCvsEzg.setSetting(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭ຨ"),EmK3ObA0cwv9Wy(u"ࠨࡃࡘࡘࡔ࠭ຩ"))
	if not YTPut68WBVUNCvsEzg.getSetting(oAXJCYqPgyGDtT(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩສ")): YTPut68WBVUNCvsEzg.setSetting(ttOu147wErcBvPaSMUY(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪຫ"),xfhCjTXRaFBGOE[VH9MDo5z1kxNF07uRJI(u"࠶ᔆ")])
	lXs13cn0E8IkRBKLWt5ouGQrfJZhqC = YTPut68WBVUNCvsEzg.getSetting(sbgu4D2RFMYKm(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫຬ"))
	lXs13cn0E8IkRBKLWt5ouGQrfJZhqC = sDiKwnHcSlYFgWCy1Ak(u"࠰ᔇ") if not lXs13cn0E8IkRBKLWt5ouGQrfJZhqC else int(lXs13cn0E8IkRBKLWt5ouGQrfJZhqC)
	if not lXs13cn0E8IkRBKLWt5ouGQrfJZhqC or not uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠱ᔈ")<=EEd0FZyfticlDPAMp2HbNesx-lXs13cn0E8IkRBKLWt5ouGQrfJZhqC<=GGXxhdg3JCamPIFepybjZ:
		tGuBrszwxTkWA3OIc = RZxCcFI8fw31NKP.Thread(target=RzTlDFk1Zdj29e6CX)
		tGuBrszwxTkWA3OIc.start()
		YTPut68WBVUNCvsEzg.setSetting(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬອ"),str(EEd0FZyfticlDPAMp2HbNesx))
	CXowtgqBhJMjid3Vr5nz = YTPut68WBVUNCvsEzg.getSetting(h5huy6MiXPNfQJF8(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪຮ"))
	CXowtgqBhJMjid3Vr5nz = N9olEh0ZMtpOivVfBLK(u"࠲ᔉ") if not CXowtgqBhJMjid3Vr5nz else int(CXowtgqBhJMjid3Vr5nz)
	if not CXowtgqBhJMjid3Vr5nz or not S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠳ᔊ")<=EEd0FZyfticlDPAMp2HbNesx-CXowtgqBhJMjid3Vr5nz<=CC89Q23uNDmIKWHAs:
		import TRa6GJnHO1
		TRa6GJnHO1.GT8XWZULDtz7sYlhIfVnE12rOK(oAXJCYqPgyGDtT(u"ࡉࡥࡱࡹࡥᜉ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡖࡵࡹࡪᜈ"))
		YTPut68WBVUNCvsEzg.setSetting(oAXJCYqPgyGDtT(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫຯ"),str(EEd0FZyfticlDPAMp2HbNesx))
	m3m47EkFKLMzNASO0HsPhp2ov = YTPut68WBVUNCvsEzg.getSetting(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ະ"))
	jRvyZdMzxL3VWANO94 = nt3lgK2RBZHJAb(YTPut68WBVUNCvsEzg.getSetting(VH9MDo5z1kxNF07uRJI(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪັ")))
	jRvyZdMzxL3VWANO94 = ZhqJoOtcmTVID65HwnLj(u"࠴ᔋ") if not jRvyZdMzxL3VWANO94 else int(jRvyZdMzxL3VWANO94)
	if m3m47EkFKLMzNASO0HsPhp2ov in [HH4JMrUDp3lq6hQ(u"ࠪࠫາ"),HVibA2ES8lY(u"ࠫࡊࡘࡒࡐࡔࠪຳ")] or not jRvyZdMzxL3VWANO94 or not vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠵ᔌ")<=EEd0FZyfticlDPAMp2HbNesx-jRvyZdMzxL3VWANO94<=j9t7FmfZiE6pYGI8V4u:
		pTULMqz73ClkJB19Z62tch0xyv5j = ktfQu3jy0hq5mTC4RON(sDiKwnHcSlYFgWCy1Ak(u"ࡊࡦࡲࡳࡦᜊ"),sDiKwnHcSlYFgWCy1Ak(u"ࡊࡦࡲࡳࡦᜊ"))
		YTPut68WBVUNCvsEzg.setSetting(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ິ"),zNx5bYlAyeLvtOpXfwK(EEd0FZyfticlDPAMp2HbNesx))
		if pTULMqz73ClkJB19Z62tch0xyv5j:
			fYPz7RldWQVHBktZAexwvCL8Np3D(l5mQdjWyczr7UJVnTp(u"࠭ฬาส้ࠣึฯࠠฤะิํࠬີ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡕࡴࡼࠤࡦ࡭ࡡࡪࡰࠪຶ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=f5uqIoSJzWBOFyrY78RXmVb(u"࠷࠰࠱࠲ᔍ"))
			return
	QX0pymMLrWfVEcHAoFBJONxUs = nt3lgK2RBZHJAb(YTPut68WBVUNCvsEzg.getSetting(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪື")))
	QX0pymMLrWfVEcHAoFBJONxUs = N0Kvne8UYar9fhRxboWsXJCVzid(u"࠰ᔎ") if not QX0pymMLrWfVEcHAoFBJONxUs else int(QX0pymMLrWfVEcHAoFBJONxUs)
	Y1gJsTROa4efWQl = nt3lgK2RBZHJAb(YTPut68WBVUNCvsEzg.getSetting(ZhqJoOtcmTVID65HwnLj(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶຸࠫ")))
	Y1gJsTROa4efWQl = ttOu147wErcBvPaSMUY(u"࠱ᔏ") if not Y1gJsTROa4efWQl else int(Y1gJsTROa4efWQl)
	if not QX0pymMLrWfVEcHAoFBJONxUs or not Y1gJsTROa4efWQl or not PiFkQ5pCJy7fbX(u"࠲ᔐ")<=EEd0FZyfticlDPAMp2HbNesx-Y1gJsTROa4efWQl<=QX0pymMLrWfVEcHAoFBJONxUs:
		qZI0kgjPWzUGepBcEsw7MONF9X5iu = f5uqIoSJzWBOFyrY78RXmVb(u"࠴ᔑ")
		DIfqKpTBMCewR = N9olEh0ZMtpOivVfBLK(u"ࡌࡡ࡭ࡵࡨᜌ") if wTpW3nbIgPckqCl9ohi(HH4JMrUDp3lq6hQ(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆູ࡛ࠫ")) else uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࡙ࡸࡵࡦᜋ")
		if DIfqKpTBMCewR:
			KieXfJOBZmz0S3V = wk1vqFgrYO4WDu5(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡔࡳࡷࡨᜍ"))
			if len(KieXfJOBZmz0S3V)>BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠵ᔒ"):
				GZvEITHSg5U3rVwQ(ZhqJoOtcmTVID65HwnLj(u"ࠫࡓࡕࡔࡊࡅࡈ຺ࠫ"),h5huy6MiXPNfQJF8(u"ࠬ࠴ࠠࠡࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨົ")+pyDQJ34XlhL6OmuoPk5UvSjN08MVG+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠠ࡞ࠩຼ"))
				kUVqWbOTsMBI8iL26RpD9YuzJl0,mXzxhH68tSFg,QWEuJVATdizDg8679CjxLOn,gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR,rreason = KieXfJOBZmz0S3V[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠵ᔓ")]
				xZw9Ai5IXsD6ur1ORTHKMoeE,zz8cBaSUFifyLl59mDkV4p2 = gQCu6NU0q5n3K7myZ.split(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧ࡝ࡰ࠾࠿ࠬຽ"))
				del KieXfJOBZmz0S3V[PiFkQ5pCJy7fbX(u"࠶ᔔ")]
				k5aYDqNtHv98T = XIjYJW8qbtv63.sample(KieXfJOBZmz0S3V,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠱ᔕ"))
				kUVqWbOTsMBI8iL26RpD9YuzJl0,mXzxhH68tSFg,QWEuJVATdizDg8679CjxLOn,gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR,rreason = k5aYDqNtHv98T[sbgu4D2RFMYKm(u"࠱ᔖ")]
				QWEuJVATdizDg8679CjxLOn = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ຾")+kUVqWbOTsMBI8iL26RpD9YuzJl0+h5huy6MiXPNfQJF8(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ຿")+QWEuJVATdizDg8679CjxLOn
				JobKQ5hDkIYC0iu48dGlTR = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩເ")
				dFGi8L47RAaTBZh0UOj = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫฬ๊สษำ฼หฯ࠭ແ")
				button0,button1 = gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR
				n7tr6RZl4xh1viBpzK5uYVc = [button0,button1,dFGi8L47RAaTBZh0UOj]
				CCxaTvpD1b = FIHNSc5iuoZanQ2Ytl(u"࠳ᔗ") if wTpW3nbIgPckqCl9ohi(FIHNSc5iuoZanQ2Ytl(u"ࠬ࡝ࡓࡖࡔࡉࡘ࠶࠿ࡑࡕࡇࡉ࡞࡝࠭ໂ")) else ttOu147wErcBvPaSMUY(u"࠴࠴ᔘ")
				ElsZrgRneL = -vatyjK4hHAoZJ7rOq2lis(u"࠽ᔙ")
				while ElsZrgRneL<HVibA2ES8lY(u"࠵ᔚ"):
					WA4tnFYx2p = XIjYJW8qbtv63.sample(n7tr6RZl4xh1viBpzK5uYVc,h5huy6MiXPNfQJF8(u"࠹ᔛ"))
					ElsZrgRneL = GNX3qVRf4oBdtkEi5u(FIHNSc5iuoZanQ2Ytl(u"࠭ࠧໃ"),WA4tnFYx2p[EEvLoMzFqrlKce(u"࠱ᔝ")],WA4tnFYx2p[vatyjK4hHAoZJ7rOq2lis(u"࠱ᔜ")],WA4tnFYx2p[sDiKwnHcSlYFgWCy1Ak(u"࠴ᔞ")],xZw9Ai5IXsD6ur1ORTHKMoeE,QWEuJVATdizDg8679CjxLOn,ttOu147wErcBvPaSMUY(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩໄ"),CCxaTvpD1b,VH9MDo5z1kxNF07uRJI(u"࠹࠴ᔟ"))
					if ElsZrgRneL==EmK3ObA0cwv9Wy(u"࠵࠵ᔠ"): break
					from TRa6GJnHO1 import fh904xAZLIjSWJGO3U,zzFuUXiBPOKfxvYAjH
					if ElsZrgRneL>=oAXJCYqPgyGDtT(u"࠶ᔢ") and WA4tnFYx2p[ElsZrgRneL]==n7tr6RZl4xh1viBpzK5uYVc[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠶ᔡ")]:
						fh904xAZLIjSWJGO3U()
						if ElsZrgRneL>=weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠱ᔤ"): ElsZrgRneL = -WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠹ᔣ")
					elif ElsZrgRneL>=h5huy6MiXPNfQJF8(u"࠲ᔥ") and WA4tnFYx2p[ElsZrgRneL]==n7tr6RZl4xh1viBpzK5uYVc[HH4JMrUDp3lq6hQ(u"࠵ᔦ")]:
						zzFuUXiBPOKfxvYAjH(ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪᜎ"))
					if ElsZrgRneL==-N9olEh0ZMtpOivVfBLK(u"࠵ᔧ"): KK47FGdX1TDfkb3AjHOQqghE(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩ໅"),HH4JMrUDp3lq6hQ(u"ࠩࠪໆ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭໇"),oAXJCYqPgyGDtT(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ່࠭"))
				qZI0kgjPWzUGepBcEsw7MONF9X5iu = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠶ᔨ")
			else: qZI0kgjPWzUGepBcEsw7MONF9X5iu = HH4JMrUDp3lq6hQ(u"࠶ᔩ")
		rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ້"),ZhqJoOtcmTVID65HwnLj(u"࠭ࡓࡊࡖࡈࡗࡤࡔࡁࡎࡇࡖ໊ࠫ"),qZI0kgjPWzUGepBcEsw7MONF9X5iu,U6y1OBwzfkEuRGVNrpYFv)
	cLCisPE3lX = WS9BILoVdyriqvp8(otciIUKlyb6,M2WHwz4yUIF,ZZ6GOtiQdngANT,DkjbIhZoVd7F52r6Ew,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
	if FIHNSc5iuoZanQ2Ytl(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠ໋ࠩ") in BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry: dqNLiYGAf7wWkOs1T6mRPp = FIHNSc5iuoZanQ2Ytl(u"ࡖࡵࡹࡪᜏ")
	if otciIUKlyb6==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໌"):
		if ADGaJxoXtdLcSsC5R4WNj!=oAXJCYqPgyGDtT(u"ࠩ࠱࠲ࠬໍ") and PqcMbUID6sXpi: PHMnCmaZ94fJ8gFl2dzLyvsrA()
		if SMfClzGKOB12H3r9sRPvAJgwq6>-BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠱ᔪ"):
			if (IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,l5mQdjWyczr7UJVnTp(u"ࠪ࡭ࡳࡺࠧ໎"),sDiKwnHcSlYFgWCy1Ak(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໏"),sDiKwnHcSlYFgWCy1Ak(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໐")) or B23DvidbEG0TwXFnexpftIs not in vjlLNoPe8d5gIstH1X) and not wTpW3nbIgPckqCl9ohi(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ໑")):
				from JgNmcHTt84 import CHgKVL3m0fv84TdnqPluQwFzjB
				uZMG81vjgFYoB9z6bVHS = cUXR35dAj2TxhWqn8veSQNyDYH(CHgKVL3m0fv84TdnqPluQwFzjB)
				haqtY2PuQKsE6mMk7ZF5y = ivk2tGTsBEV5WpwQ7j8Dex3CouF(MGedk8WjmRIxFEC0bVOy,uZMG81vjgFYoB9z6bVHS,UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ)
				if VH9MDo5z1kxNF07uRJI(u"࠲ᔫ") and uZMG81vjgFYoB9z6bVHS and GhMiWYeE4U3HzPKjF0tusr5:
					rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,sbgu4D2RFMYKm(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭໒")+ihw1zPdAp6ZUurQclBfOskGYMxyWHL+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡡࠪ໓")+yyb6qzJk1PSg,MGedk8WjmRIxFEC0bVOy,uZMG81vjgFYoB9z6bVHS,GGXxhdg3JCamPIFepybjZ)
			else:
				I2XjYiNOlmyKG1EhR70q53vZ.addDirectoryItem(SMfClzGKOB12H3r9sRPvAJgwq6,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ໔")+x7NwSuz5ft4e+sbgu4D2RFMYKm(u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰ࡮ࡴ࡫ࠧ࡯ࡲࡨࡪࡃ࠵࠱࠲ࠪ໕"),Ko1p5u9jwG6rF.ListItem(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"้ࠫี๊ไุ่่๊ࠢษࠡ็้ࠤัํวำๅࠪ໖")))
				I2XjYiNOlmyKG1EhR70q53vZ.addDirectoryItem(SMfClzGKOB12H3r9sRPvAJgwq6,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ໗")+x7NwSuz5ft4e+h5huy6MiXPNfQJF8(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭໘"),Ko1p5u9jwG6rF.ListItem(ZEiR0StquOzca9lvPAndYIX(u"ࠧฤใอั๊ࠥสใำฦࠤฬ๊สโษุ๎้࠭໙")))
			I2XjYiNOlmyKG1EhR70q53vZ.endOfDirectory(SMfClzGKOB12H3r9sRPvAJgwq6,UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ)
	return
def WS9BILoVdyriqvp8(otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl):
	B23DvidbEG0TwXFnexpftIs = int(DkjbIhZoVd7F52r6Ew)
	VoJz4e67SfIUB5th = int(B23DvidbEG0TwXFnexpftIs//f5uqIoSJzWBOFyrY78RXmVb(u"࠳࠳ᔬ"))
	if   VoJz4e67SfIUB5th==HH4JMrUDp3lq6hQ(u"࠳ᔭ"):  from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠵ᔮ"):  from K836yHGimB 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠷ᔯ"):  from Ur91T3bdnp 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠹ᔰ"):  from bapyhOnfBF 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠴ᔱ"):  from GgVQnpyiCL 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ffGe7cURW0lhJVvQAiw8IB)
	elif VoJz4e67SfIUB5th==N9olEh0ZMtpOivVfBLK(u"࠶ᔲ"):  from ovKfrHj8bu 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==PiFkQ5pCJy7fbX(u"࠸ᔳ"):  from EbluyZW5LI 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ZhqJoOtcmTVID65HwnLj(u"࠺ᔴ"):  from zzSmHfGRh1 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==l5mQdjWyczr7UJVnTp(u"࠼ᔵ"):  from isINJdkS0c 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ttOu147wErcBvPaSMUY(u"࠾ᔶ"):  from s2mgB7XGTt		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==Xl3drKyI9HkDiPEf8RTjwu(u"࠷࠰ᔷ"): from SSy2JCLXDt 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK)
	elif VoJz4e67SfIUB5th==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱࠲ᔸ"): from DIHBeTNura 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠲࠴ᔹ"): from gGTiHbNksh 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==EmK3ObA0cwv9Wy(u"࠳࠶ᔺ"): from kkITS5N91U		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ZEiR0StquOzca9lvPAndYIX(u"࠴࠸ᔻ"): from sSG0U5DEax 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB,eENPgSDsKvOH24QpIbGjZtwnYoFl,BB5dqMe8jgLxwSvk)
	elif VoJz4e67SfIUB5th==Xl3drKyI9HkDiPEf8RTjwu(u"࠵࠺ᔼ"): from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠶࠼ᔽ"): from wz0EQnxko7		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==ZEiR0StquOzca9lvPAndYIX(u"࠷࠷ᔾ"): from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠱࠹ᔿ"): from CaHv0LUGxr		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==EmK3ObA0cwv9Wy(u"࠲࠻ᕀ"): from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴࠳ᕁ"): from ifSd1M9kgR		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠵࠵ᕂ"): from Njz2f70qrX	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==l5mQdjWyczr7UJVnTp(u"࠶࠷ᕃ"): from c5cyCBKX0A		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==vatyjK4hHAoZJ7rOq2lis(u"࠷࠹ᕄ"): from ll13jcxerk	import QoegtqjHpENh	; cLCisPE3lX = QoegtqjHpENh(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠸࠴ᕅ"): from IqinpDkyKl 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N9olEh0ZMtpOivVfBLK(u"࠲࠶ᕆ"): from vCtl0ns45z 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==PiFkQ5pCJy7fbX(u"࠳࠸ᕇ"): from JgNmcHTt84 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==PiFkQ5pCJy7fbX(u"࠴࠺ᕈ"): from sGBzntv5FT	import QoegtqjHpENh	; cLCisPE3lX = QoegtqjHpENh(B23DvidbEG0TwXFnexpftIs,ytsdYhu8qpWc6nwJlDr32bBPmj)
	elif VoJz4e67SfIUB5th==HVibA2ES8lY(u"࠵࠼ᕉ"): from ll13jcxerk	import QoegtqjHpENh	; cLCisPE3lX = QoegtqjHpENh(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==vatyjK4hHAoZJ7rOq2lis(u"࠶࠾ᕊ"): from iN7I2Kvdet	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸࠶ᕋ"): from coLpZ1IUQX		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠹࠱ᕌ"): from ugn3FVAUmb		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳࠳ᕍ"): from dCaTxDr5ny		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==PiFkQ5pCJy7fbX(u"࠴࠵ᕎ"): from fNZBsRdigo		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK)
	elif VoJz4e67SfIUB5th==HVibA2ES8lY(u"࠵࠷ᕏ"): from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠶࠹ᕐ"): from sp0ci7URFg		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==f5uqIoSJzWBOFyrY78RXmVb(u"࠷࠻ᕑ"): from JZ9alXQ134			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠸࠽ᕒ"): from MJgi5GqtY1			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠹࠸ᕓ"): from RebLZS85Mr 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳࠺ᕔ"): from N2LfsEFw0l		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==HH4JMrUDp3lq6hQ(u"࠵࠲ᕕ"): from LEZ1hMoasH	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB)
	elif VoJz4e67SfIUB5th==f5uqIoSJzWBOFyrY78RXmVb(u"࠶࠴ᕖ"): from LEZ1hMoasH	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠷࠶ᕗ"): from BLdv9gUfaA			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸࠸ᕘ"): from eJK6akm4Wr			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==VH9MDo5z1kxNF07uRJI(u"࠹࠺ᕙ"): from yyYVjqbT8o		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ZEiR0StquOzca9lvPAndYIX(u"࠺࠵ᕚ"): from BBSGVEY06O		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠴࠷ᕛ"): from F7tRBq8g52			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==Xl3drKyI9HkDiPEf8RTjwu(u"࠵࠹ᕜ"): from IzDwgOdRve		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==FIHNSc5iuoZanQ2Ytl(u"࠶࠻ᕝ"): from ZW6geGYkMJ		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠷࠽ᕞ"): from l5liAXKZoO		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ttOu147wErcBvPaSMUY(u"࠹࠵ᕟ"): from TRa6GJnHO1 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==EEvLoMzFqrlKce(u"࠺࠷ᕠ"): from tDbsuKLmTC 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠻࠲ᕡ"): from tDbsuKLmTC 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵࠴ᕢ"): from JgNmcHTt84 			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==EmK3ObA0cwv9Wy(u"࠶࠶ᕣ"): from E9jOJBma65	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ffGe7cURW0lhJVvQAiw8IB)
	elif VoJz4e67SfIUB5th==WmaPChRdQk3YcXwI6zS(u"࠷࠸ᕤ"): from wBonpRSNeM 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N9olEh0ZMtpOivVfBLK(u"࠸࠺ᕥ"): from aNYf1hSZV0			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠹࠼ᕦ"): from gC4dqk9SLB		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠺࠾ᕧ"): from Z23NoP4Rdg		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==h5huy6MiXPNfQJF8(u"࠻࠹ᕨ"): from yyCXvj7tkU		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠶࠱ᕩ"): from m2lN5dr0pP			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠷࠳ᕪ"): from GEOZPCczq3			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠸࠵ᕫ"): from qbRa5OA9mK		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==WmaPChRdQk3YcXwI6zS(u"࠹࠷ᕬ"): from Nf7bUWmz6O	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==f5uqIoSJzWBOFyrY78RXmVb(u"࠺࠹ᕭ"): from hCe8APomMv			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠻࠻ᕮ"): from TrcyRUH3vi			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠼࠶ᕯ"): from FXdQ6O4EWN			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==ZhqJoOtcmTVID65HwnLj(u"࠶࠸ᕰ"): from g96gjGpAJ0		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠷࠺ᕱ"): from FEh0iRAMns		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠸࠼ᕲ"): from ERBPf8ATQn		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠺࠴ᕳ"): from xtZ9DkcH7d			import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==sDiKwnHcSlYFgWCy1Ak(u"࠻࠶ᕴ"): from DqKuc961xM	import QoegtqjHpENh	; cLCisPE3lX = QoegtqjHpENh(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠼࠸ᕵ"): from DqKuc961xM	import QoegtqjHpENh	; cLCisPE3lX = QoegtqjHpENh(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,otciIUKlyb6,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠽࠳ᕶ"): from XT3uYtnVfO	import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠷࠵ᕷ"): from otnwkPZ6RV		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs)
	elif VoJz4e67SfIUB5th==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠸࠷ᕸ"): from otnwkPZ6RV		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs)
	elif VoJz4e67SfIUB5th==ZEiR0StquOzca9lvPAndYIX(u"࠹࠹ᕹ"): from wz0EQnxko7		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl)
	elif VoJz4e67SfIUB5th==PiFkQ5pCJy7fbX(u"࠺࠻ᕺ"): from TgIVM3sG2w 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==EEvLoMzFqrlKce(u"࠻࠽ᕻ"): from PP1JntxOQD 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==Xl3drKyI9HkDiPEf8RTjwu(u"࠼࠿ᕼ"): from MM7Ygkxlt3 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==HH4JMrUDp3lq6hQ(u"࠾࠰ᕽ"): from PnNvU5y6ZL 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠸࠲ᕾ"): from siVGafBrbO 		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	elif VoJz4e67SfIUB5th==sbgu4D2RFMYKm(u"࠹࠴ᕿ"): from LHZqFm32BY		import F5M9LsnokGPEQ2XYfO7cuyr	; cLCisPE3lX = F5M9LsnokGPEQ2XYfO7cuyr(B23DvidbEG0TwXFnexpftIs,gz1flZwncVutokL59RaGS3WeK,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	else: cLCisPE3lX = None
	return cLCisPE3lX
def a4oGEfmk9UAHvnFDZRg(yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason,nnN6lPjWb0xVQqDKwo3,showDialogs):
	JtqNjwFpevRmG9nDBlz5g0V = YTPut68WBVUNCvsEzg.getSetting(f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ໚"))
	YTPut68WBVUNCvsEzg.setSetting(PiFkQ5pCJy7fbX(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ໛"),vatyjK4hHAoZJ7rOq2lis(u"ࠪࠫໜ"))
	if vatyjK4hHAoZJ7rOq2lis(u"ࠫ࠲࠭ໝ") in nnN6lPjWb0xVQqDKwo3: vuyTFsAd72wDBiUPSnft5obMjErR6 = nnN6lPjWb0xVQqDKwo3.split(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࠳ࠧໞ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠳ᖀ"))[HVibA2ES8lY(u"࠳ᖁ")]
	else: vuyTFsAd72wDBiUPSnft5obMjErR6 = nnN6lPjWb0xVQqDKwo3
	owEJMbnBFGj0XATr9DvhtZ = yxkqChFvLOnj1TKZMHSUdrA9bGN in [l5mQdjWyczr7UJVnTp(u"࠷ᖅ"),l5mQdjWyczr7UJVnTp(u"࠶࠷࠰࠱࠳ᖃ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵࠶࠶࠰࠳ᖂ"),HVibA2ES8lY(u"࠷࠰࠱࠷࠷ᖄ")]
	h6tcU39TyzSwPWOlu = rreason.lower()
	O0fZc29dxT5EsaCW = yxkqChFvLOnj1TKZMHSUdrA9bGN in [Xl3drKyI9HkDiPEf8RTjwu(u"࠱ᖆ"),WmaPChRdQk3YcXwI6zS(u"࠵࠵࠺ᖉ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠳࠳࠴࠻࠷ᖇ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠴࠵࠶ᖈ")]
	Ii4hczlbuFrBY2WZdpw = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧໟ") in h6tcU39TyzSwPWOlu
	oU0Y7Idia9KcnbAEBsGHCN = ZhqJoOtcmTVID65HwnLj(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ໠") in h6tcU39TyzSwPWOlu
	oo6BJcI9kLvdAfQs8TXWiK7rx = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ໡") in h6tcU39TyzSwPWOlu
	AX1KHoJ3uqFwN = Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ໢") in h6tcU39TyzSwPWOlu
	JnPGZ5EAfV = YTPut68WBVUNCvsEzg.getSetting(ttOu147wErcBvPaSMUY(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨ໣"))
	mA4tykubSDozlpcdvnP2ihjMZ0XCq = YTPut68WBVUNCvsEzg.getSetting(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ໤"))
	X35XSZjn8RUczgCoE4JLtPfq1lvW = l5mQdjWyczr7UJVnTp(u"ࠬ็ิๅࠢไ๎ูࠥอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ໥")
	FWQbuCq9MxARrVY07cUn4 = cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡅࡳࡴࡲࡶࠥ࠭໦")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+sbgu4D2RFMYKm(u"ࠧ࠻ࠢࠪ໧")+rreason
	FWQbuCq9MxARrVY07cUn4 = rygO0TzuEdiPcQDWZ8awSjm(FWQbuCq9MxARrVY07cUn4)
	if O0fZc29dxT5EsaCW or Ii4hczlbuFrBY2WZdpw or oU0Y7Idia9KcnbAEBsGHCN or oo6BJcI9kLvdAfQs8TXWiK7rx or AX1KHoJ3uqFwN:
		X35XSZjn8RUczgCoE4JLtPfq1lvW += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥฮวๅ็๋ๆ฾ࡢ࡮ࠨ໨")
	if owEJMbnBFGj0XATr9DvhtZ: X35XSZjn8RUczgCoE4JLtPfq1lvW += QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࠣ࠲๊ࠥฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํ࡜࡯ࠩ໩")
	FWQbuCq9MxARrVY07cUn4 = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ໪")+FWQbuCq9MxARrVY07cUn4+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭໫")
	if JnPGZ5EAfV==vatyjK4hHAoZJ7rOq2lis(u"ࠬࡇࡓࡌࠩ໬") or mA4tykubSDozlpcdvnP2ihjMZ0XCq==TWexH5PhS1(u"࠭ࡁࡔࡍࠪ໭"):
		X35XSZjn8RUczgCoE4JLtPfq1lvW += EmK3ObA0cwv9Wy(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ໮")
	lntJcpdr2f1kI = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡉࡥࡱࡹࡥᜐ")
	if showDialogs and nnN6lPjWb0xVQqDKwo3 not in MyfG164jLWzXKitYQTUqeDvrdSu0F:
		if JnPGZ5EAfV==cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡃࡖࡏࠬ໯") or mA4tykubSDozlpcdvnP2ihjMZ0XCq==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡄࡗࡐ࠭໰"):
			ElsZrgRneL = GNX3qVRf4oBdtkEi5u(oAXJCYqPgyGDtT(u"ࠪࡧࡪࡴࡴࡦࡴࠪ໱"),HH4JMrUDp3lq6hQ(u"ࠫำื่อࠩ໲"),VOq8Ekue4F(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫ໳"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ลึๆสัࠥอไๆึๆ่ฮ࠭໴"),vuyTFsAd72wDBiUPSnft5obMjErR6+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠡࠢࠣࠫ໵")+hqWB0vmTcxR8d3oukL(vuyTFsAd72wDBiUPSnft5obMjErR6),X35XSZjn8RUczgCoE4JLtPfq1lvW+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨ࡞ࡱࠫ໶")+FWQbuCq9MxARrVY07cUn4)
			if ElsZrgRneL==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠶ᖊ"):
				from TRa6GJnHO1 import fh904xAZLIjSWJGO3U
				fh904xAZLIjSWJGO3U()
			elif ElsZrgRneL==PiFkQ5pCJy7fbX(u"࠸ᖋ"): lntJcpdr2f1kI = ttOu147wErcBvPaSMUY(u"ࡘࡷࡻࡥᜑ")
		else: KK47FGdX1TDfkb3AjHOQqghE(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࠪ໷"),sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫ໸"),vuyTFsAd72wDBiUPSnft5obMjErR6+WmaPChRdQk3YcXwI6zS(u"ࠫࠥࠦࠠࠨ໹")+hqWB0vmTcxR8d3oukL(vuyTFsAd72wDBiUPSnft5obMjErR6),X35XSZjn8RUczgCoE4JLtPfq1lvW,FWQbuCq9MxARrVY07cUn4)
	YTPut68WBVUNCvsEzg.setSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭໺"),JtqNjwFpevRmG9nDBlz5g0V)
	return lntJcpdr2f1kI
def R1JaOzyTLxfMvBigeYuhn(sXJTLEAWlj9Mkm=VOq8Ekue4F(u"ࡋࡧ࡬ࡴࡧᜒ"),nAwRpP26KX=[]):
	wsYFhUrT8EOGI3cBJNt9 = [oQjDxLF9fdtyCaJ5ZTO860ri1s,Yy5epgPqo7D2vT4mQREiuX]+nAwRpP26KX
	for qK2aImeBfl98EgMDQ in isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(jNhH3xrnWkFUqv8c09OybXRTl):
		if sXJTLEAWlj9Mkm and (qK2aImeBfl98EgMDQ.startswith(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࡩࡱࡶࡹࠫ໻")) or qK2aImeBfl98EgMDQ.startswith(N9olEh0ZMtpOivVfBLK(u"ࠧ࡮࠵ࡸࠫ໼"))): continue
		if qK2aImeBfl98EgMDQ.startswith(VOq8Ekue4F(u"ࠨࡨ࡬ࡰࡪࡥࠧ໽")): continue
		ctefUCibYDVoK2gjaWr804F = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,qK2aImeBfl98EgMDQ)
		if ctefUCibYDVoK2gjaWr804F in wsYFhUrT8EOGI3cBJNt9: continue
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(ctefUCibYDVoK2gjaWr804F)
		except: pass
	if UIl7EzK48anPkH not in wsYFhUrT8EOGI3cBJNt9: P8vtuTghFN7lWIS(UIl7EzK48anPkH,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡔࡳࡷࡨ᜔"),PiFkQ5pCJy7fbX(u"ࡌࡡ࡭ࡵࡨᜓ"))
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(Xl3drKyI9HkDiPEf8RTjwu(u"࠱ᖌ"))
	return
def QQmFO5epag8G97yMB1XlU(RJj675QpyAnI,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,nnN6lPjWb0xVQqDKwo3,wAT9BZmYf4O5uPgG=sDiKwnHcSlYFgWCy1Ak(u"ࡕࡴࡸࡩ᜕"),o48agNivFQYRWsqcSftZP1=sDiKwnHcSlYFgWCy1Ak(u"ࡕࡴࡸࡩ᜕")):
	gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+h5huy6MiXPNfQJF8(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ໾")+RJj675QpyAnI
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,nnN6lPjWb0xVQqDKwo3,wAT9BZmYf4O5uPgG,o48agNivFQYRWsqcSftZP1)
	if gz1flZwncVutokL59RaGS3WeK in z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content: z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded = vatyjK4hHAoZJ7rOq2lis(u"ࡈࡤࡰࡸ࡫᜖")
	if not z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
		v9BiEYVb3fcZrql0(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ໿"))
	return z8zCauMw6AGm7ZRDFO4NeJ0xrLt
def MnqPeaVH4cDZ7xhN(gz1flZwncVutokL59RaGS3WeK):
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡌࡋࡔࠨༀ"),gz1flZwncVutokL59RaGS3WeK,vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠭༁"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠧ༂"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࡘࡷࡻࡥ᜘"),vatyjK4hHAoZJ7rOq2lis(u"ࠧࠨ༃"),sbgu4D2RFMYKm(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ༄"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࡘࡷࡻࡥ᜘"),sbgu4D2RFMYKm(u"ࡉࡥࡱࡹࡥ᜗"))
	RMhODWdVcgsfCSpj = []
	if z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
		KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
		uUFNCDA0dkVYPf83ri = T072lCzjYiuaeFtmJGV.findall(TWexH5PhS1(u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬ༅"),KLxMkaVlguvqPcF)
		if uUFNCDA0dkVYPf83ri: KLxMkaVlguvqPcF = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡠࡳ࠭༆").join(uUFNCDA0dkVYPf83ri)
		bNsDLHrj9SVRzwd5P6 = KLxMkaVlguvqPcF.replace(f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡡࡸࠧ༇"),EmK3ObA0cwv9Wy(u"ࠬ࠭༈")).strip(PiFkQ5pCJy7fbX(u"࠭࡜࡯ࠩ༉")).split(FIHNSc5iuoZanQ2Ytl(u"ࠧ࡝ࡰࠪ༊"))
		RMhODWdVcgsfCSpj = []
		for RJj675QpyAnI in bNsDLHrj9SVRzwd5P6:
			if RJj675QpyAnI.count(EmK3ObA0cwv9Wy(u"ࠨ࠰ࠪ་"))==g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠴ᖍ"): RMhODWdVcgsfCSpj.append(RJj675QpyAnI)
	return RMhODWdVcgsfCSpj
def g9gwp0dWDmjR1QaN(*aargs):
	DWC3E5QqyR8Lrib9U = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ༌")
	e9AjhIPYOMDuEVyw5pWlQ8v7 = oAXJCYqPgyGDtT(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ།")
	GnyPHZtmaJF8vhgMwoNKX64Rdi = MnqPeaVH4cDZ7xhN(e9AjhIPYOMDuEVyw5pWlQ8v7)
	RMhODWdVcgsfCSpj = MnqPeaVH4cDZ7xhN(DWC3E5QqyR8Lrib9U)
	cVLgN9prh4PHaRFGo2qk3CiMfZ6w = GnyPHZtmaJF8vhgMwoNKX64Rdi+RMhODWdVcgsfCSpj
	GZvEITHSg5U3rVwQ(sbgu4D2RFMYKm(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ༎"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+HH4JMrUDp3lq6hQ(u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫ༏")+str(len(GnyPHZtmaJF8vhgMwoNKX64Rdi))+vatyjK4hHAoZJ7rOq2lis(u"࠭ࠫࠨ༐")+str(len(RMhODWdVcgsfCSpj))+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࠡ࡟ࠪ༑"))
	RJj675QpyAnI = YTPut68WBVUNCvsEzg.getSetting(l5mQdjWyczr7UJVnTp(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༒"))
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = B5Cv0E1zyTFw()
	YTPut68WBVUNCvsEzg.setSetting(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ༓"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࠫ༔"))
	if RJj675QpyAnI or cVLgN9prh4PHaRFGo2qk3CiMfZ6w:
		kUVqWbOTsMBI8iL26RpD9YuzJl0,hZYTKSaABQCofcrFlgsI = HVibA2ES8lY(u"࠲ᖎ"),sbgu4D2RFMYKm(u"࠴࠴ᖏ")
		ij6Yo0V7m2XJtHRuGN3eUF = len(cVLgN9prh4PHaRFGo2qk3CiMfZ6w)
		KApnk39sP25o6bUqRNOMfYzvuFLQ = hZYTKSaABQCofcrFlgsI
		if ij6Yo0V7m2XJtHRuGN3eUF>KApnk39sP25o6bUqRNOMfYzvuFLQ: h6EuyOF5Jna = KApnk39sP25o6bUqRNOMfYzvuFLQ
		else: h6EuyOF5Jna = ij6Yo0V7m2XJtHRuGN3eUF
		M4FS7pZwboWlUa2 = XIjYJW8qbtv63.sample(cVLgN9prh4PHaRFGo2qk3CiMfZ6w,h6EuyOF5Jna)
		if RJj675QpyAnI: M4FS7pZwboWlUa2 = [RJj675QpyAnI]+M4FS7pZwboWlUa2
		cim6r1psatSgOhCJf48Nn5 = Zeq6ARs9joiXNQ(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡋࡧ࡬ࡴࡧ᜙"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡋࡧ࡬ࡴࡧ᜙"))
		yvuYVFPClBd03mc8 = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
		while D1vBJgya85Yh4cRTCkIMKtWLSeH.time()-yvuYVFPClBd03mc8<=hZYTKSaABQCofcrFlgsI and not cim6r1psatSgOhCJf48Nn5.finishedLIST:
			if kUVqWbOTsMBI8iL26RpD9YuzJl0<h6EuyOF5Jna:
				RJj675QpyAnI = M4FS7pZwboWlUa2[kUVqWbOTsMBI8iL26RpD9YuzJl0]
				cim6r1psatSgOhCJf48Nn5.ng0pbr1xPzOWfil4ao(kUVqWbOTsMBI8iL26RpD9YuzJl0,QQmFO5epag8G97yMB1XlU,RJj675QpyAnI,*aargs)
			D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(l5mQdjWyczr7UJVnTp(u"࠵ᖐ"))
			kUVqWbOTsMBI8iL26RpD9YuzJl0 += cbngtp9sqYi0DjeEMLRHJruKxm(u"࠶ᖑ")
			GZvEITHSg5U3rVwQ(PiFkQ5pCJy7fbX(u"ࠫࡓࡕࡔࡊࡅࡈࠫ༕"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+sDiKwnHcSlYFgWCy1Ak(u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ༖")+RJj675QpyAnI+TWexH5PhS1(u"࠭ࠠ࡞ࠩ༗"))
		finishedLIST = cim6r1psatSgOhCJf48Nn5.finishedLIST
		if finishedLIST:
			resultsDICT = cim6r1psatSgOhCJf48Nn5.resultsDICT
			FdU1pYXLBsw2yfCVO = finishedLIST[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠶ᖒ")]
			z8zCauMw6AGm7ZRDFO4NeJ0xrLt = resultsDICT[FdU1pYXLBsw2yfCVO]
			RJj675QpyAnI = M4FS7pZwboWlUa2[int(FdU1pYXLBsw2yfCVO)]
			YTPut68WBVUNCvsEzg.setSetting(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺ༘ࠧ"),RJj675QpyAnI)
			if FdU1pYXLBsw2yfCVO!=f5uqIoSJzWBOFyrY78RXmVb(u"࠰ᖓ"): GZvEITHSg5U3rVwQ(ZEiR0StquOzca9lvPAndYIX(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙༙ࠧ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ༚")+RJj675QpyAnI+ttOu147wErcBvPaSMUY(u"ࠪࠤࡢ࠭༛"))
			else: GZvEITHSg5U3rVwQ(sbgu4D2RFMYKm(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ༜"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ༝")+RJj675QpyAnI+EEvLoMzFqrlKce(u"࠭ࠠ࡞ࠩ༞"))
	return z8zCauMw6AGm7ZRDFO4NeJ0xrLt
def S6SvQ5ouXjxghUOeMlYNERJK(P3R6TOkojarB0lVWIyJDM8qsxeXY,yySB3TiHgxzsJQKfFmEq92t7V):
	RfjT5Om8viuCY7 = P3R6TOkojarB0lVWIyJDM8qsxeXY.create_connection
	def obT3cxDXPWv819VfR6u(mE8Lj62vnqOWUBbVsJDxcZX,*aargs,**kkwargs):
		YMhlFSnErVXD1,QJEXoC7NbyjHs = mE8Lj62vnqOWUBbVsJDxcZX
		ip = ksgT5Go6BqpNwDjyMbUiOI3rQxfa7A(YMhlFSnErVXD1,yySB3TiHgxzsJQKfFmEq92t7V)
		if ip: YMhlFSnErVXD1 = ip[EmK3ObA0cwv9Wy(u"࠱ᖔ")]
		else:
			if yySB3TiHgxzsJQKfFmEq92t7V in xfhCjTXRaFBGOE: xfhCjTXRaFBGOE.remove(yySB3TiHgxzsJQKfFmEq92t7V)
			if xfhCjTXRaFBGOE:
				fKcgpdWDOHiMUq = xfhCjTXRaFBGOE[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠲ᖕ")]
				ip = ksgT5Go6BqpNwDjyMbUiOI3rQxfa7A(YMhlFSnErVXD1,fKcgpdWDOHiMUq)
				if ip: YMhlFSnErVXD1 = ip[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᖖ")]
		mE8Lj62vnqOWUBbVsJDxcZX = (YMhlFSnErVXD1,QJEXoC7NbyjHs)
		return RfjT5Om8viuCY7(mE8Lj62vnqOWUBbVsJDxcZX,*aargs,**kkwargs)
	P3R6TOkojarB0lVWIyJDM8qsxeXY.create_connection = obT3cxDXPWv819VfR6u
	return RfjT5Om8viuCY7
def iI5BZfv7dWP1Uh(gz1flZwncVutokL59RaGS3WeK):
	hSYw67EcIXQy4pqov0LjCAF,yGtrphCufF47Z = gz1flZwncVutokL59RaGS3WeK.split(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧ࠰ࠩ༟"))[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠷ᖘ")],QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠼࠵ᖗ")
	if WmaPChRdQk3YcXwI6zS(u"ࠨ࠼ࠪ༠") in hSYw67EcIXQy4pqov0LjCAF: hSYw67EcIXQy4pqov0LjCAF,yGtrphCufF47Z = hSYw67EcIXQy4pqov0LjCAF.split(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩ࠽ࠫ༡"))
	HHgi1ZvT7LYKmw = VOq8Ekue4F(u"ࠪ࠳ࠬ༢")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫ࠴࠭༣").join(gz1flZwncVutokL59RaGS3WeK.split(N9olEh0ZMtpOivVfBLK(u"ࠬ࠵ࠧ༤"))[ZEiR0StquOzca9lvPAndYIX(u"࠹ᖙ"):])
	iYvJPtR357SbyQf1 = N9olEh0ZMtpOivVfBLK(u"࠭ࡇࡆࡖࠣࠫ༥")+HHgi1ZvT7LYKmw+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ༦")
	iYvJPtR357SbyQf1 += VOq8Ekue4F(u"ࠨࡊࡲࡷࡹࡀࠠࠨ༧")+hSYw67EcIXQy4pqov0LjCAF+vatyjK4hHAoZJ7rOq2lis(u"ࠩ࡟ࡶࡡࡴࠧ༨")
	iYvJPtR357SbyQf1 += HH4JMrUDp3lq6hQ(u"ࠪࡠࡷࡢ࡮ࠨ༩")
	from socket import socket as b0Y9mt5kN7ezPES,AF_INET as zP8A0c3YCN7oq9ElMdevh,SOCK_STREAM as dxirsWfnmcZVC2vMPtTewlH3RQ
	try:
		dfb7FulQRjxhTJtco = b0Y9mt5kN7ezPES(zP8A0c3YCN7oq9ElMdevh,dxirsWfnmcZVC2vMPtTewlH3RQ)
		dfb7FulQRjxhTJtco.connect((hSYw67EcIXQy4pqov0LjCAF,yGtrphCufF47Z))
		dfb7FulQRjxhTJtco.send(iYvJPtR357SbyQf1.encode(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡺࡺࡦ࠹ࠩ༪")))
		Pg6eVf8im10 = dfb7FulQRjxhTJtco.recv(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵࠲࠼࠺ᖛ")*sbgu4D2RFMYKm(u"࠱࠱࠴࠷ᖚ"))
		KLxMkaVlguvqPcF = repr(Pg6eVf8im10)
	except: KLxMkaVlguvqPcF = oAXJCYqPgyGDtT(u"ࠬ࠭༫")
	return KLxMkaVlguvqPcF
def ClNwy8MJfjoTq4ZFxYvmasD(y2x6dqF8kQHXYpLa7rnWVD4heRu,otciIUKlyb6):
	if TWexH5PhS1(u"࠭࠮ࠨ༬") not in y2x6dqF8kQHXYpLa7rnWVD4heRu: return y2x6dqF8kQHXYpLa7rnWVD4heRu
	y2x6dqF8kQHXYpLa7rnWVD4heRu = y2x6dqF8kQHXYpLa7rnWVD4heRu+ZEiR0StquOzca9lvPAndYIX(u"ࠧ࠰ࠩ༭")
	vxA3iKfjtF1nCPWZU,FtO3Njcb6r5BT1PqZ = y2x6dqF8kQHXYpLa7rnWVD4heRu.split(vatyjK4hHAoZJ7rOq2lis(u"ࠨ࠰ࠪ༮"),EEvLoMzFqrlKce(u"࠳ᖜ"))
	w08fLZT97ygbSxABrIQHoX,MI5dkLHK3FuPer4pCG = FtO3Njcb6r5BT1PqZ.split(vatyjK4hHAoZJ7rOq2lis(u"ࠩ࠲ࠫ༯"),EEvLoMzFqrlKce(u"࠴ᖝ"))
	wlFhnG5JOULs6f8qzr4CXMYiNSavuP = vxA3iKfjtF1nCPWZU+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪ࠲ࠬ༰")+w08fLZT97ygbSxABrIQHoX
	if otciIUKlyb6 in [f5uqIoSJzWBOFyrY78RXmVb(u"ࠫ࡭ࡵࡳࡵࠩ༱"),h5huy6MiXPNfQJF8(u"ࠬࡴࡡ࡮ࡧࠪ༲")] and VH9MDo5z1kxNF07uRJI(u"࠭࠯ࠨ༳") in wlFhnG5JOULs6f8qzr4CXMYiNSavuP: wlFhnG5JOULs6f8qzr4CXMYiNSavuP = wlFhnG5JOULs6f8qzr4CXMYiNSavuP.rsplit(EEvLoMzFqrlKce(u"ࠧ࠰ࠩ༴"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠵ᖞ"))[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠵ᖞ")]
	if otciIUKlyb6==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡰࡤࡱࡪ༵࠭") and EEvLoMzFqrlKce(u"ࠩ࠱ࠫ༶") in wlFhnG5JOULs6f8qzr4CXMYiNSavuP:
		lRKwqG5z8r9vMfxSjQZWhN7i = wlFhnG5JOULs6f8qzr4CXMYiNSavuP.split(vatyjK4hHAoZJ7rOq2lis(u"ࠪ࠲༷ࠬ"))
		PPezI3c1TXMHyfERlNOsWB2bmrKoU = len(lRKwqG5z8r9vMfxSjQZWhN7i)
		if PPezI3c1TXMHyfERlNOsWB2bmrKoU<=ZEiR0StquOzca9lvPAndYIX(u"࠸ᖠ") or g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ༸") in wlFhnG5JOULs6f8qzr4CXMYiNSavuP: lRKwqG5z8r9vMfxSjQZWhN7i = lRKwqG5z8r9vMfxSjQZWhN7i[HH4JMrUDp3lq6hQ(u"࠵ᖟ")]
		elif PPezI3c1TXMHyfERlNOsWB2bmrKoU>=vatyjK4hHAoZJ7rOq2lis(u"࠴ᖢ"): lRKwqG5z8r9vMfxSjQZWhN7i = lRKwqG5z8r9vMfxSjQZWhN7i[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠱ᖡ")]
		if len(lRKwqG5z8r9vMfxSjQZWhN7i)>ttOu147wErcBvPaSMUY(u"࠳ᖣ"): wlFhnG5JOULs6f8qzr4CXMYiNSavuP = lRKwqG5z8r9vMfxSjQZWhN7i
	return wlFhnG5JOULs6f8qzr4CXMYiNSavuP
def y357f08uQISUGLr6qOwdTBCcnWsv(bJ2vRxC30VdwKQl5er9Dnaj):
	CWabGc5dKv6U9RiE = repr(bJ2vRxC30VdwKQl5er9Dnaj.encode(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡻࡴࡧ࠺༹ࠪ"))).replace(vatyjK4hHAoZJ7rOq2lis(u"ࠨࠧࠣ༺"),EmK3ObA0cwv9Wy(u"ࠧࠨ༻"))
	return CWabGc5dKv6U9RiE
def epacjZzdVL5IMrHASuvgqBRkxNnXQJ(ib1oudwVx6kcNf7JZApESQY4W):
	yJzhQrF3W7Bbc1wPvAfqVM0T4 = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࠩ༼")
	if ggl6zFuXNdYTDieHCqGKRnVx: ib1oudwVx6kcNf7JZApESQY4W = ib1oudwVx6kcNf7JZApESQY4W.decode(N9olEh0ZMtpOivVfBLK(u"ࠩࡸࡸ࡫࠾ࠧ༽"))
	from unicodedata import decomposition as pqeG1hsSZXD0lvT7P
	for iisCWPIVbR in ib1oudwVx6kcNf7JZApESQY4W:
		if   iisCWPIVbR==FIHNSc5iuoZanQ2Ytl(u"ࡸࠫว࠭༾"): Lix3yOwdjTe0MQAzXDsI25CKVuS = N9olEh0ZMtpOivVfBLK(u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ༿")
		elif iisCWPIVbR==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡺ࠭รࠨཀ"): Lix3yOwdjTe0MQAzXDsI25CKVuS = sbgu4D2RFMYKm(u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧཁ")
		elif iisCWPIVbR==N9olEh0ZMtpOivVfBLK(u"ࡵࠨฦࠪག"): Lix3yOwdjTe0MQAzXDsI25CKVuS = VH9MDo5z1kxNF07uRJI(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩགྷ")
		elif iisCWPIVbR==EEvLoMzFqrlKce(u"ࡷࠪษࠬང"): Lix3yOwdjTe0MQAzXDsI25CKVuS = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫཅ")
		elif iisCWPIVbR==h5huy6MiXPNfQJF8(u"ࡹࠬฬࠧཆ"): Lix3yOwdjTe0MQAzXDsI25CKVuS = sDiKwnHcSlYFgWCy1Ak(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭ཇ")
		else:
			wp5t6Bo2ITd9V3rsHz8E = pqeG1hsSZXD0lvT7P(iisCWPIVbR)
			if PiFkQ5pCJy7fbX(u"࠭ࠠࠨ཈") in wp5t6Bo2ITd9V3rsHz8E: Lix3yOwdjTe0MQAzXDsI25CKVuS = FIHNSc5iuoZanQ2Ytl(u"ࠧ࡝࡞ࡸࠫཉ")+wp5t6Bo2ITd9V3rsHz8E.split(EEvLoMzFqrlKce(u"ࠨࠢࠪཊ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠴ᖤ"))[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠴ᖤ")]
			else:
				Lix3yOwdjTe0MQAzXDsI25CKVuS = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ࠳࠴࠵࠶ࠧཋ")+hex(ord(iisCWPIVbR)).replace(N9olEh0ZMtpOivVfBLK(u"ࠪ࠴ࡽ࠭ཌ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࠬཌྷ"))
				Lix3yOwdjTe0MQAzXDsI25CKVuS = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡢ࡜ࡶࠩཎ")+Lix3yOwdjTe0MQAzXDsI25CKVuS[-QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠸ᖥ"):]
		yJzhQrF3W7Bbc1wPvAfqVM0T4 += Lix3yOwdjTe0MQAzXDsI25CKVuS
	yJzhQrF3W7Bbc1wPvAfqVM0T4 = yJzhQrF3W7Bbc1wPvAfqVM0T4.replace(h5huy6MiXPNfQJF8(u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧཏ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨཐ"))
	if ggl6zFuXNdYTDieHCqGKRnVx: yJzhQrF3W7Bbc1wPvAfqVM0T4 = yJzhQrF3W7Bbc1wPvAfqVM0T4.decode(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩད")).encode(ZhqJoOtcmTVID65HwnLj(u"ࠩࡸࡸ࡫࠾ࠧདྷ"))
	else: yJzhQrF3W7Bbc1wPvAfqVM0T4 = yJzhQrF3W7Bbc1wPvAfqVM0T4.encode(sDiKwnHcSlYFgWCy1Ak(u"ࠪࡹࡹ࡬࠸ࠨན")).decode(EmK3ObA0cwv9Wy(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬཔ"))
	return yJzhQrF3W7Bbc1wPvAfqVM0T4
def NWs7KpjXGnxYylofHtd5U3wDh(header=vatyjK4hHAoZJ7rOq2lis(u"๊่ࠬฮหࠣห้๋แศฬํัࠬཕ"),default=WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࠧབ"),iwJqF1n0WU3ahozlsru925QgjOX7p=S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡌࡡ࡭ࡵࡨ᜚"),source=ZhqJoOtcmTVID65HwnLj(u"ࠧࠨབྷ")):
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = ZFPkCOboImgG8SzE0h6u(header,default,type=Ko1p5u9jwG6rF.INPUT_ALPHANUM)
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࠢࠣࠫམ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࠣࠫཙ")).replace(EEvLoMzFqrlKce(u"ࠪࠤࠥ࠭ཚ"),PiFkQ5pCJy7fbX(u"ࠫࠥ࠭ཛ")).replace(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࠦࠠࠨཛྷ"),ZhqJoOtcmTVID65HwnLj(u"࠭ࠠࠨཝ"))
	if not BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry and not iwJqF1n0WU3ahozlsru925QgjOX7p:
		GZvEITHSg5U3rVwQ(HVibA2ES8lY(u"ࠧࡏࡑࡗࡍࡈࡋࠧཞ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬཟ")+BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry+FIHNSc5iuoZanQ2Ytl(u"ࠩࠥࠫའ"))
		KK47FGdX1TDfkb3AjHOQqghE(HVibA2ES8lY(u"ࠪࠫཡ"),HH4JMrUDp3lq6hQ(u"ࠫࠬར"),vatyjK4hHAoZJ7rOq2lis(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨལ"),FIHNSc5iuoZanQ2Ytl(u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩཤ"))
		return VOq8Ekue4F(u"ࠧࠨཥ")
	if BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry not in [vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࠩས"),HVibA2ES8lY(u"ࠩࠣࠫཧ")]:
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.strip(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࠤࠬཨ"))
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = epacjZzdVL5IMrHASuvgqBRkxNnXQJ(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	if source!=FIHNSc5iuoZanQ2Ytl(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ཀྵ") and j06m14qSVXJR8o3pBtdv9YzgAn(HH4JMrUDp3lq6hQ(u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧཪ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࠧཫ"),[BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry],HH4JMrUDp3lq6hQ(u"ࡆࡢ࡮ࡶࡩ᜛")):
		GZvEITHSg5U3rVwQ(l5mQdjWyczr7UJVnTp(u"ࠧࡏࡑࡗࡍࡈࡋࠧཬ"),TWexH5PhS1(u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ཭")+BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࠥࠫ཮"))
		KK47FGdX1TDfkb3AjHOQqghE(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠫ཯"),l5mQdjWyczr7UJVnTp(u"ࠫࠬ཰"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨཱ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨི"))
		return N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨཱི")
	GZvEITHSg5U3rVwQ(vatyjK4hHAoZJ7rOq2lis(u"ࠨࡐࡒࡘࡎࡉࡅࠨུ"),EEvLoMzFqrlKce(u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ཱུࠡࠢࠣࠦࠬ")+BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry+FIHNSc5iuoZanQ2Ytl(u"ࠪࠦࠬྲྀ"))
	return BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry
def w7py6bdKn1jqMSfh(ll9khUfx3MjZ,JKf4Tsxu9S23FI7mV5DGLk={}):
	gz1flZwncVutokL59RaGS3WeK,IIz2gyNbGrJ53i,tS6hejGbHUXLvnVcg8,p9jMdHBJ5yV = ll9khUfx3MjZ,{},{},g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬཷ")
	if EEvLoMzFqrlKce(u"ࠬࢂࠧླྀ") in ll9khUfx3MjZ: gz1flZwncVutokL59RaGS3WeK,IIz2gyNbGrJ53i = y2dmjAuhlfboLe(ll9khUfx3MjZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡼࠨཹ"))
	RbZO60ipNtGgUMBJdv = list(set(list(JKf4Tsxu9S23FI7mV5DGLk.keys())+list(IIz2gyNbGrJ53i.keys())))
	for TRBlwxbQJUZaKL1s86SIAze in RbZO60ipNtGgUMBJdv:
		if TRBlwxbQJUZaKL1s86SIAze in list(IIz2gyNbGrJ53i.keys()): tS6hejGbHUXLvnVcg8[TRBlwxbQJUZaKL1s86SIAze] = IIz2gyNbGrJ53i[TRBlwxbQJUZaKL1s86SIAze]
		else: tS6hejGbHUXLvnVcg8[TRBlwxbQJUZaKL1s86SIAze] = JKf4Tsxu9S23FI7mV5DGLk[TRBlwxbQJUZaKL1s86SIAze]
	if N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷེࠫ") not in RbZO60ipNtGgUMBJdv: tS6hejGbHUXLvnVcg8[EmK3ObA0cwv9Wy(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸཻࠬ")] = diwUZMEagkFDlS()
	if weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴོࠪ") not in RbZO60ipNtGgUMBJdv: tS6hejGbHUXLvnVcg8[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵཽࠫ")] = ClNwy8MJfjoTq4ZFxYvmasD(gz1flZwncVutokL59RaGS3WeK,ZEiR0StquOzca9lvPAndYIX(u"ࠫࡺࡸ࡬ࠨཾ"))
	for TRBlwxbQJUZaKL1s86SIAze in list(tS6hejGbHUXLvnVcg8.keys()): p9jMdHBJ5yV += vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࠬࠧཿ")+TRBlwxbQJUZaKL1s86SIAze+f5uqIoSJzWBOFyrY78RXmVb(u"࠭࠽ࠨྀ")+tS6hejGbHUXLvnVcg8[TRBlwxbQJUZaKL1s86SIAze]
	if p9jMdHBJ5yV: p9jMdHBJ5yV = h5huy6MiXPNfQJF8(u"ࠧࡽཱྀࠩ")+p9jMdHBJ5yV[vatyjK4hHAoZJ7rOq2lis(u"࠶ᖦ"):]
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(BZ5D43mGxLAItEUYTv,HH4JMrUDp3lq6hQ(u"ࠨࡉࡈࡘࠬྂ"),gz1flZwncVutokL59RaGS3WeK,TWexH5PhS1(u"ࠩࠪྃ"),tS6hejGbHUXLvnVcg8,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"྄ࠪࠫ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬ྅"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ྆"),ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪ᜜"),ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪ᜜"))
	KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
	if ttOu147wErcBvPaSMUY(u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ྇") not in KLxMkaVlguvqPcF: return [WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧ࠮࠳ࠪྈ")],[gz1flZwncVutokL59RaGS3WeK+p9jMdHBJ5yV]
	if ZEiR0StquOzca9lvPAndYIX(u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬྉ") in KLxMkaVlguvqPcF: return [EmK3ObA0cwv9Wy(u"ࠩ࠰࠵ࠬྊ")],[gz1flZwncVutokL59RaGS3WeK+p9jMdHBJ5yV]
	if uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧྋ") in KLxMkaVlguvqPcF: return [Xl3drKyI9HkDiPEf8RTjwu(u"ࠫ࠲࠷ࠧྌ")],[gz1flZwncVutokL59RaGS3WeK+p9jMdHBJ5yV]
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,VqMm083xeXLzPj6HEuJ,XHBu9aZwi1QRLnfDY3TFg7hKpvt = [],[],[],[]
	SXOJtRiHqaUFCp2e = T072lCzjYiuaeFtmJGV.findall(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࠩࡅ࡙ࡖ࠰࡜࠲࡙ࡔࡓࡇࡄࡑ࠲ࡏࡎࡇ࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭ྍ"),KLxMkaVlguvqPcF+TWexH5PhS1(u"࠭࡜࡯ࠩྎ"),T072lCzjYiuaeFtmJGV.DOTALL)
	if not SXOJtRiHqaUFCp2e: return [vatyjK4hHAoZJ7rOq2lis(u"ࠧ࠮࠳ࠪྏ")],[gz1flZwncVutokL59RaGS3WeK+p9jMdHBJ5yV]
	for TTjZMRAUezcia,y2x6dqF8kQHXYpLa7rnWVD4heRu in SXOJtRiHqaUFCp2e:
		WFwqMstraH,eJa6sZqgoNpGXT,Q5OAspyiXV1lx8930qLGD = {},-WmaPChRdQk3YcXwI6zS(u"࠷ᖧ"),-WmaPChRdQk3YcXwI6zS(u"࠷ᖧ")
		AABtIsJ1uwgG9c0iWh8PMVmk3YCr = PiFkQ5pCJy7fbX(u"ࠨࠩྐ")
		wTh1iyANZn0txGBgoPk = TTjZMRAUezcia.split(oAXJCYqPgyGDtT(u"ࠩ࠯ࠫྑ"))
		for hLYopVN51jn0T6 in wTh1iyANZn0txGBgoPk:
			if HVibA2ES8lY(u"ࠪࡁࠬྒ") in hLYopVN51jn0T6:
				TRBlwxbQJUZaKL1s86SIAze,qqk6TvmXIdJAxi9t1MDaz = hLYopVN51jn0T6.split(sDiKwnHcSlYFgWCy1Ak(u"ࠫࡂ࠭ྒྷ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠱ᖨ"))
				WFwqMstraH[TRBlwxbQJUZaKL1s86SIAze.lower()] = qqk6TvmXIdJAxi9t1MDaz
		if EEvLoMzFqrlKce(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྔ") in TTjZMRAUezcia.lower():
			eJa6sZqgoNpGXT = int(WFwqMstraH[FIHNSc5iuoZanQ2Ytl(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྕ")])//N0Kvne8UYar9fhRxboWsXJCVzid(u"࠲࠲࠵࠸ᖩ")
			AABtIsJ1uwgG9c0iWh8PMVmk3YCr += str(eJa6sZqgoNpGXT)+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧྖ")
		elif FIHNSc5iuoZanQ2Ytl(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫྗ") in TTjZMRAUezcia.lower():
			eJa6sZqgoNpGXT = int(WFwqMstraH[N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ྘")])//WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳࠳࠶࠹ᖪ")
			AABtIsJ1uwgG9c0iWh8PMVmk3YCr += str(eJa6sZqgoNpGXT)+ttOu147wErcBvPaSMUY(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪྙ")
		if PiFkQ5pCJy7fbX(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨྚ") in TTjZMRAUezcia.lower():
			Q5OAspyiXV1lx8930qLGD = int(WFwqMstraH[ZhqJoOtcmTVID65HwnLj(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩྛ")].split(l5mQdjWyczr7UJVnTp(u"࠭ࡸࠨྜ"))[N9olEh0ZMtpOivVfBLK(u"࠴ᖫ")])
			AABtIsJ1uwgG9c0iWh8PMVmk3YCr += str(Q5OAspyiXV1lx8930qLGD)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠡࠢࠪྜྷ")
		AABtIsJ1uwgG9c0iWh8PMVmk3YCr = AABtIsJ1uwgG9c0iWh8PMVmk3YCr.strip(EmK3ObA0cwv9Wy(u"ࠨࠢࠣࠫྞ"))
		if not AABtIsJ1uwgG9c0iWh8PMVmk3YCr: AABtIsJ1uwgG9c0iWh8PMVmk3YCr = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪྟ")
		if not y2x6dqF8kQHXYpLa7rnWVD4heRu.startswith(EmK3ObA0cwv9Wy(u"ࠪ࡬ࡹࡺࡰࠨྠ")):
			if y2x6dqF8kQHXYpLa7rnWVD4heRu.startswith(PiFkQ5pCJy7fbX(u"ࠫ࠴࠵ࠧྡ")): y2x6dqF8kQHXYpLa7rnWVD4heRu = gz1flZwncVutokL59RaGS3WeK.split(VOq8Ekue4F(u"ࠬࡀࠧྡྷ"),ZhqJoOtcmTVID65HwnLj(u"࠵ᖬ"))[ZhqJoOtcmTVID65HwnLj(u"࠵ᖭ")]+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭࠺ࠨྣ")+y2x6dqF8kQHXYpLa7rnWVD4heRu
			elif y2x6dqF8kQHXYpLa7rnWVD4heRu.startswith(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࠰ࠩྤ")): y2x6dqF8kQHXYpLa7rnWVD4heRu = ClNwy8MJfjoTq4ZFxYvmasD(gz1flZwncVutokL59RaGS3WeK,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࡷࡵࡰࠬྥ"))+y2x6dqF8kQHXYpLa7rnWVD4heRu
			else: y2x6dqF8kQHXYpLa7rnWVD4heRu = gz1flZwncVutokL59RaGS3WeK.rsplit(ZEiR0StquOzca9lvPAndYIX(u"ࠩ࠲ࠫྦ"),PiFkQ5pCJy7fbX(u"࠷ᖮ"))[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠰ᖯ")]+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪ࠳ࠬྦྷ")+y2x6dqF8kQHXYpLa7rnWVD4heRu
		if h5huy6MiXPNfQJF8(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ྨ") in list(WFwqMstraH.keys()):
			K9K307bTvRVtO6i = WFwqMstraH[ZhqJoOtcmTVID65HwnLj(u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧྩ")]
			K9K307bTvRVtO6i = K9K307bTvRVtO6i.replace(ZEiR0StquOzca9lvPAndYIX(u"࠭ࠢࠨྪ"),VOq8Ekue4F(u"ࠧࠨྫ")).replace(TWexH5PhS1(u"ࠣࠩࠥྫྷ"),N9olEh0ZMtpOivVfBLK(u"ࠩࠪྭ")).split(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࠧࠬྮ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠲ᖰ"))[mNkfJnpOrad7hT6PYyciwsSDQ(u"࠲ᖱ")]
			rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(K9K307bTvRVtO6i)
			if rUTwZXB4AoFRzdjnEPD2iNJKs: tKBSN4Zgn9CDb = AABtIsJ1uwgG9c0iWh8PMVmk3YCr+PiFkQ5pCJy7fbX(u"ࠫࠥࠦࠧྯ")+rUTwZXB4AoFRzdjnEPD2iNJKs
			else: tKBSN4Zgn9CDb = AABtIsJ1uwgG9c0iWh8PMVmk3YCr
			tKBSN4Zgn9CDb = tKBSN4Zgn9CDb+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࠦࠠࡑࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩࠬྰ")
			tKBSN4Zgn9CDb = tKBSN4Zgn9CDb+N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠠࠡࠩྱ")+ClNwy8MJfjoTq4ZFxYvmasD(K9K307bTvRVtO6i,VOq8Ekue4F(u"ࠧ࡯ࡣࡰࡩࠬྲ"))
			n7CuHMSJpiR9fP0jvNEIyDUL.append(tKBSN4Zgn9CDb)
			M7oS6tLhdx3ke8qPX4mFA.append(K9K307bTvRVtO6i)
			VqMm083xeXLzPj6HEuJ.append(Q5OAspyiXV1lx8930qLGD)
			XHBu9aZwi1QRLnfDY3TFg7hKpvt.append(eJa6sZqgoNpGXT)
		y2x6dqF8kQHXYpLa7rnWVD4heRu = y2x6dqF8kQHXYpLa7rnWVD4heRu.split(VH9MDo5z1kxNF07uRJI(u"ࠨࠥࠪླ"),VH9MDo5z1kxNF07uRJI(u"࠴ᖲ"))[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴ᖳ")]
		rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(y2x6dqF8kQHXYpLa7rnWVD4heRu)
		if rUTwZXB4AoFRzdjnEPD2iNJKs: AABtIsJ1uwgG9c0iWh8PMVmk3YCr = AABtIsJ1uwgG9c0iWh8PMVmk3YCr+HH4JMrUDp3lq6hQ(u"ࠩࠣࠤࠬྴ")+rUTwZXB4AoFRzdjnEPD2iNJKs
		AABtIsJ1uwgG9c0iWh8PMVmk3YCr = AABtIsJ1uwgG9c0iWh8PMVmk3YCr+EmK3ObA0cwv9Wy(u"ࠪࠤࠥ࠭ྵ")+ClNwy8MJfjoTq4ZFxYvmasD(y2x6dqF8kQHXYpLa7rnWVD4heRu,ZEiR0StquOzca9lvPAndYIX(u"ࠫࡳࡧ࡭ࡦࠩྶ"))
		n7CuHMSJpiR9fP0jvNEIyDUL.append(AABtIsJ1uwgG9c0iWh8PMVmk3YCr)
		M7oS6tLhdx3ke8qPX4mFA.append(y2x6dqF8kQHXYpLa7rnWVD4heRu)
		VqMm083xeXLzPj6HEuJ.append(Q5OAspyiXV1lx8930qLGD)
		XHBu9aZwi1QRLnfDY3TFg7hKpvt.append(eJa6sZqgoNpGXT)
	EvepJ1lSmD = list(zip(n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,VqMm083xeXLzPj6HEuJ,XHBu9aZwi1QRLnfDY3TFg7hKpvt))
	EvepJ1lSmD = sorted(EvepJ1lSmD, reverse=N9olEh0ZMtpOivVfBLK(u"ࡖࡵࡹࡪ᜝"), key=lambda key: key[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸ᖴ")])
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA,VqMm083xeXLzPj6HEuJ,XHBu9aZwi1QRLnfDY3TFg7hKpvt = list(zip(*EvepJ1lSmD))
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = list(n7CuHMSJpiR9fP0jvNEIyDUL),list(M7oS6tLhdx3ke8qPX4mFA)
	Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR = []
	for y2x6dqF8kQHXYpLa7rnWVD4heRu in M7oS6tLhdx3ke8qPX4mFA: Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR.append(y2x6dqF8kQHXYpLa7rnWVD4heRu+p9jMdHBJ5yV)
	return n7CuHMSJpiR9fP0jvNEIyDUL,Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR
def ksgT5Go6BqpNwDjyMbUiOI3rQxfa7A(YMhlFSnErVXD1,yySB3TiHgxzsJQKfFmEq92t7V=EEvLoMzFqrlKce(u"ࠬ࠭ྷ")):
	if not yySB3TiHgxzsJQKfFmEq92t7V: yySB3TiHgxzsJQKfFmEq92t7V = xfhCjTXRaFBGOE[h5huy6MiXPNfQJF8(u"࠶ᖵ")]
	if YMhlFSnErVXD1.replace(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭࠮ࠨྸ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠨྐྵ")).isdigit(): return [YMhlFSnErVXD1]
	from struct import pack as Rl07dZoipsDAc,unpack_from as hJB7Lzcf65Et8GxHaq1kCIVou20
	from socket import socket as b0Y9mt5kN7ezPES,AF_INET as zP8A0c3YCN7oq9ElMdevh,SOCK_DGRAM as LaM1XYRbIhvDgFUJZe0uQTC4Gfjiw
	try:
		npw9WjBM2O = Rl07dZoipsDAc(HH4JMrUDp3lq6hQ(u"ࠣࡀࡋࠦྺ"), N0Kvne8UYar9fhRxboWsXJCVzid(u"࠱࠳࠲࠷࠽ᖶ"))
		npw9WjBM2O += Rl07dZoipsDAc(ZhqJoOtcmTVID65HwnLj(u"ࠤࡁࡌࠧྻ"), WmaPChRdQk3YcXwI6zS(u"࠳࠷࠹ᖷ"))
		npw9WjBM2O += Rl07dZoipsDAc(oAXJCYqPgyGDtT(u"ࠥࡂࡍࠨྼ"), oAXJCYqPgyGDtT(u"࠳ᖸ"))
		npw9WjBM2O += Rl07dZoipsDAc(vatyjK4hHAoZJ7rOq2lis(u"ࠦࡃࡎࠢ྽"), vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᖹ"))
		npw9WjBM2O += Rl07dZoipsDAc(ttOu147wErcBvPaSMUY(u"ࠧࡄࡈࠣ྾"), uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠴ᖺ"))
		npw9WjBM2O += Rl07dZoipsDAc(VOq8Ekue4F(u"ࠨ࠾ࡉࠤ྿"), weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠵ᖻ"))
		if mmIKCGujwM: DoJH8O7VYIxQrm = YMhlFSnErVXD1.split(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧ࠯ࠩ࿀"))
		else: DoJH8O7VYIxQrm = YMhlFSnErVXD1.decode(ttOu147wErcBvPaSMUY(u"ࠨࡷࡷࡪ࠽࠭࿁")).split(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࠱ࠫ࿂"))
		for zbwWvaCRAPo in DoJH8O7VYIxQrm:
			ZVhR1T504MdOYipfW = zbwWvaCRAPo.encode(PiFkQ5pCJy7fbX(u"ࠪࡹࡹ࡬࠸ࠨ࿃"))
			npw9WjBM2O += Rl07dZoipsDAc(HH4JMrUDp3lq6hQ(u"ࠦࡇࠨ࿄"), len(zbwWvaCRAPo))
			for RB4WQPDJ5flT1 in zbwWvaCRAPo:
				npw9WjBM2O += Rl07dZoipsDAc(WmaPChRdQk3YcXwI6zS(u"ࠧࡩࠢ࿅"), RB4WQPDJ5flT1.encode(ttOu147wErcBvPaSMUY(u"࠭ࡵࡵࡨ࠻࿆ࠫ")))
		npw9WjBM2O += Rl07dZoipsDAc(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠢࡃࠤ࿇"), h5huy6MiXPNfQJF8(u"࠶ᖼ"))
		npw9WjBM2O += Rl07dZoipsDAc(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠣࡀࡋࠦ࿈"), WmaPChRdQk3YcXwI6zS(u"࠱ᖽ"))
		npw9WjBM2O += Rl07dZoipsDAc(f5uqIoSJzWBOFyrY78RXmVb(u"ࠤࡁࡌࠧ࿉"), vatyjK4hHAoZJ7rOq2lis(u"࠲ᖾ"))
		FOvAJ3zpcwUGhb = b0Y9mt5kN7ezPES(zP8A0c3YCN7oq9ElMdevh,LaM1XYRbIhvDgFUJZe0uQTC4Gfjiw)
		FOvAJ3zpcwUGhb.sendto(bytes(npw9WjBM2O), (yySB3TiHgxzsJQKfFmEq92t7V, EmK3ObA0cwv9Wy(u"࠷࠶ᖿ")))
		FOvAJ3zpcwUGhb.settimeout(l5mQdjWyczr7UJVnTp(u"࠹ᗀ"))
		Z402tBVhQi, aIvEDMZzTmQfXl = FOvAJ3zpcwUGhb.recvfrom(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠵࠵࠸࠴ᗁ"))
		FOvAJ3zpcwUGhb.close()
		hyboJWMm5vClXswjQT481D3 = hJB7Lzcf65Et8GxHaq1kCIVou20(VH9MDo5z1kxNF07uRJI(u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ࿊"), Z402tBVhQi, VOq8Ekue4F(u"࠵ᗂ"))
		YFDMOvSH20eoG8w = hyboJWMm5vClXswjQT481D3[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠹ᗃ")]
		S04m1BvxghObQapUc9zHRrTGuel = len(YMhlFSnErVXD1)+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠱࠹ᗄ")
		gQCu6NU0q5n3K7myZ = []
		for _mhIe7yExwo in range(YFDMOvSH20eoG8w):
			DwGxWS8QAc0KYPg = S04m1BvxghObQapUc9zHRrTGuel
			leFjtaysGHoM4gfr8z0R5O3qTQJ1px = VH9MDo5z1kxNF07uRJI(u"࠲ᗅ")
			YYKmkrIR4Ppnjdg = FIHNSc5iuoZanQ2Ytl(u"ࡉࡥࡱࡹࡥ᜞")
			while sbgu4D2RFMYKm(u"ࡘࡷࡻࡥᜟ"):
				RB4WQPDJ5flT1 = hJB7Lzcf65Et8GxHaq1kCIVou20(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠦࡃࡈࠢ࿋"), Z402tBVhQi, DwGxWS8QAc0KYPg)[VOq8Ekue4F(u"࠲ᗆ")]
				if RB4WQPDJ5flT1 == WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳ᗇ"):
					DwGxWS8QAc0KYPg += EEvLoMzFqrlKce(u"࠵ᗈ")
					break
				if RB4WQPDJ5flT1 >= BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠶࠿࠲ᗉ"):
					MwzrgpdPiUHaxsKED2f6Qo = hJB7Lzcf65Et8GxHaq1kCIVou20(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡄࡂࠣ࿌"), Z402tBVhQi, DwGxWS8QAc0KYPg + Xl3drKyI9HkDiPEf8RTjwu(u"࠷ᗊ"))[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠰ᗋ")]
					DwGxWS8QAc0KYPg = ((RB4WQPDJ5flT1 << BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠺ᗍ")) + MwzrgpdPiUHaxsKED2f6Qo - 0xc000) - ZhqJoOtcmTVID65HwnLj(u"࠲ᗌ")
					YYKmkrIR4Ppnjdg = h5huy6MiXPNfQJF8(u"࡙ࡸࡵࡦᜠ")
				DwGxWS8QAc0KYPg += weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠴ᗎ")
				if YYKmkrIR4Ppnjdg == WmaPChRdQk3YcXwI6zS(u"ࡌࡡ࡭ࡵࡨᜡ"): leFjtaysGHoM4gfr8z0R5O3qTQJ1px += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠵ᗏ")
			if YYKmkrIR4Ppnjdg == VH9MDo5z1kxNF07uRJI(u"ࡔࡳࡷࡨᜢ"): leFjtaysGHoM4gfr8z0R5O3qTQJ1px += ttOu147wErcBvPaSMUY(u"࠶ᗐ")
			S04m1BvxghObQapUc9zHRrTGuel = S04m1BvxghObQapUc9zHRrTGuel + leFjtaysGHoM4gfr8z0R5O3qTQJ1px
			ZCP1cgvjyQpGri5mo = hJB7Lzcf65Et8GxHaq1kCIVou20(ZhqJoOtcmTVID65HwnLj(u"ࠨ࠾ࡉࡊࡌࡌࠧ࿍"), Z402tBVhQi, S04m1BvxghObQapUc9zHRrTGuel)
			S04m1BvxghObQapUc9zHRrTGuel = S04m1BvxghObQapUc9zHRrTGuel + PiFkQ5pCJy7fbX(u"࠷࠰ᗑ")
			eOgTPjlAx0qynIa1hSDQu4GW32wZcr = ZCP1cgvjyQpGri5mo[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠰ᗒ")]
			rVSbaXmG2IUchWiD = ZCP1cgvjyQpGri5mo[TWexH5PhS1(u"࠴ᗓ")]
			if eOgTPjlAx0qynIa1hSDQu4GW32wZcr == S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠳ᗔ"):
				mmuqDFsPEzl7LKZXNpbf2 = hJB7Lzcf65Et8GxHaq1kCIVou20(FIHNSc5iuoZanQ2Ytl(u"ࠢ࠿ࠤ࿎")+h5huy6MiXPNfQJF8(u"ࠣࡄࠥ࿏")*rVSbaXmG2IUchWiD, Z402tBVhQi, S04m1BvxghObQapUc9zHRrTGuel)
				ip = EmK3ObA0cwv9Wy(u"ࠩࠪ࿐")
				for RB4WQPDJ5flT1 in mmuqDFsPEzl7LKZXNpbf2: ip += str(RB4WQPDJ5flT1) + Xl3drKyI9HkDiPEf8RTjwu(u"ࠪ࠲ࠬ࿑")
				ip = ip[Xl3drKyI9HkDiPEf8RTjwu(u"࠴ᗖ"):-oAXJCYqPgyGDtT(u"࠴ᗕ")]
				gQCu6NU0q5n3K7myZ.append(ip)
			if eOgTPjlAx0qynIa1hSDQu4GW32wZcr in [f5uqIoSJzWBOFyrY78RXmVb(u"࠱ᗙ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠳ᗚ"),EEvLoMzFqrlKce(u"࠷ᗛ"),Xl3drKyI9HkDiPEf8RTjwu(u"࠹ᗜ"),ZhqJoOtcmTVID65HwnLj(u"࠶࠻ᗗ"),VH9MDo5z1kxNF07uRJI(u"࠸࠸ᗘ")]: S04m1BvxghObQapUc9zHRrTGuel = S04m1BvxghObQapUc9zHRrTGuel + rVSbaXmG2IUchWiD
	except: gQCu6NU0q5n3K7myZ = []
	if not gQCu6NU0q5n3K7myZ: GZvEITHSg5U3rVwQ(EEvLoMzFqrlKce(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ࿒"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ࿓")+YMhlFSnErVXD1+Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࠠ࡞ࠩ࿔"))
	return gQCu6NU0q5n3K7myZ
def j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,gz1flZwncVutokL59RaGS3WeK,Y9xGJcRLIBNOftSQ5HE1jTysl,showDialogs=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡕࡴࡸࡩᜣ")):
	if Y9xGJcRLIBNOftSQ5HE1jTysl:
		dGrfa2O8Jo1ZgeLIlxBFNCQjT5 = [vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧไสสีࠬ࿕"),EEvLoMzFqrlKce(u"ࠨสส่฿࠭࿖"),TWexH5PhS1(u"ࠩࡤࡨࡺࡲࡴࠨ࿗"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡼࡽ࠭࿘"),l5mQdjWyczr7UJVnTp(u"ࠫࡸ࡫ࡸࠨ࿙")]
		if nO6ukabcldeU!=VH9MDo5z1kxNF07uRJI(u"ࠬࡈࡏࡌࡔࡄࠫ࿚"):
			dGrfa2O8Jo1ZgeLIlxBFNCQjT5 += [S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡲ࠻ࠩ࿛"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡳ࠯ࠪ࿜"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨ࠯ࡰࡥࠬ࿝")]
			dGrfa2O8Jo1ZgeLIlxBFNCQjT5 += [VH9MDo5z1kxNF07uRJI(u"ࠩ࠽ࡶࠬ࿞"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪ࠱ࡷ࠭࿟"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡲࡧ࠭ࠨ࿠")]
		for IvHFpy1M8n06g in Y9xGJcRLIBNOftSQ5HE1jTysl:
			if VOq8Ekue4F(u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ࿡") in IvHFpy1M8n06g: continue
			if ZhqJoOtcmTVID65HwnLj(u"࠭อๅไฬࠫ࿢") in IvHFpy1M8n06g: continue
			IvHFpy1M8n06g = IvHFpy1M8n06g.lower()
			if ggl6zFuXNdYTDieHCqGKRnVx: IvHFpy1M8n06g = IvHFpy1M8n06g.decode(HH4JMrUDp3lq6hQ(u"ࠧࡶࡶࡩ࠼ࠬ࿣")).encode(vatyjK4hHAoZJ7rOq2lis(u"ࠨࡷࡷࡪ࠽࠭࿤"))
			IvHFpy1M8n06g = IvHFpy1M8n06g.replace(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ࠽ࠫ࿥"),TWexH5PhS1(u"ࠪࠫ࿦"))
			WWeCogxvL1 = T072lCzjYiuaeFtmJGV.findall(PiFkQ5pCJy7fbX(u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ࿧"),IvHFpy1M8n06g,T072lCzjYiuaeFtmJGV.DOTALL)
			UJNAmr4ndkbI = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡈࡤࡰࡸ࡫ᜤ")
			for UeWNzkXiLDY0K5Bqh3cur in WWeCogxvL1:
				if len(UeWNzkXiLDY0K5Bqh3cur)==VOq8Ekue4F(u"࠶ᗝ"):
					UJNAmr4ndkbI = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡗࡶࡺ࡫ᜥ")
					break
			if TWexH5PhS1(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ࿨") in IvHFpy1M8n06g: continue
			elif oAXJCYqPgyGDtT(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ࿩") in IvHFpy1M8n06g: continue
			elif HH4JMrUDp3lq6hQ(u"ࠧ฻์ิࠤ๊฻ๆโࠩ࿪") in IvHFpy1M8n06g: continue
			elif wTpW3nbIgPckqCl9ohi(WmaPChRdQk3YcXwI6zS(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ࿫")): continue
			elif IvHFpy1M8n06g in [f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡵࠫ࿬")] or UJNAmr4ndkbI or any(EYn2siOeDvQTk8KpS0Jl in IvHFpy1M8n06g for EYn2siOeDvQTk8KpS0Jl in dGrfa2O8Jo1ZgeLIlxBFNCQjT5):
				GZvEITHSg5U3rVwQ(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࿭"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+PiFkQ5pCJy7fbX(u"ࠫࠥࠦࠠࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡣࡧࡹࡱࡺࡳࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ࿮")+gz1flZwncVutokL59RaGS3WeK+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࠦ࡝ࠨ࿯"))
				if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿰"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧศๆไ๎ิ๐่ࠡๆ็็ออัࠡใๅ฻ࠥ๎ร็ษ้๋ࠣ฿ส่ࠩ࿱"))
				return mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡘࡷࡻࡥᜦ")
	return VH9MDo5z1kxNF07uRJI(u"ࡋࡧ࡬ࡴࡧᜧ")
def KK47FGdX1TDfkb3AjHOQqghE(*aargs,**kkwargs):
	if aargs:
		direction = aargs[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠵ᗞ")]
		UerviYn3kJqNEu6IfHpm7TR4 = aargs[VOq8Ekue4F(u"࠷ᗟ")]
		if not direction: direction = ZhqJoOtcmTVID65HwnLj(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࿲")
		if not UerviYn3kJqNEu6IfHpm7TR4: UerviYn3kJqNEu6IfHpm7TR4 = h5huy6MiXPNfQJF8(u"ࠩสืฯ๋ัศำࠪ࿳")
		giEdr0D19uz = aargs[N0Kvne8UYar9fhRxboWsXJCVzid(u"࠲ᗠ")]
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡠࡳ࠭࿴").join(aargs[N9olEh0ZMtpOivVfBLK(u"࠴ᗡ"):])
	else: direction,UerviYn3kJqNEu6IfHpm7TR4,giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = HVibA2ES8lY(u"ࠫࠬ࿵"),FIHNSc5iuoZanQ2Ytl(u"ࠬࡕࡋࠨ࿶"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧ࿷"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࠨ࿸")
	GNX3qVRf4oBdtkEi5u(direction,sDiKwnHcSlYFgWCy1Ak(u"ࠨࠩ࿹"),UerviYn3kJqNEu6IfHpm7TR4,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠪ࿺"),giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,**kkwargs)
	return
def KGEAmiZ9Jq0sTXR(*aargs,**kkwargs):
	direction = aargs[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠲ᗢ")]
	NN7Ui1HJPAKkWZYXGE = aargs[N0Kvne8UYar9fhRxboWsXJCVzid(u"࠴ᗣ")]
	j8CAJGLa0YSlrPfp = aargs[Xl3drKyI9HkDiPEf8RTjwu(u"࠶ᗤ")]
	if j8CAJGLa0YSlrPfp or NN7Ui1HJPAKkWZYXGE: BruLjvKO3Q48WITowPmzfkblyGac = PiFkQ5pCJy7fbX(u"࡚ࡲࡶࡧᜨ")
	else: BruLjvKO3Q48WITowPmzfkblyGac = TWexH5PhS1(u"ࡆࡢ࡮ࡶࡩᜩ")
	giEdr0D19uz = aargs[EmK3ObA0cwv9Wy(u"࠸ᗥ")]
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = aargs[vatyjK4hHAoZJ7rOq2lis(u"࠺ᗦ")]
	if not direction: direction = FIHNSc5iuoZanQ2Ytl(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࿻")
	if not NN7Ui1HJPAKkWZYXGE: NN7Ui1HJPAKkWZYXGE = sDiKwnHcSlYFgWCy1Ak(u"่๊ࠫวࠡࠢࡑࡳࠬ࿼")
	if not j8CAJGLa0YSlrPfp: j8CAJGLa0YSlrPfp = N9olEh0ZMtpOivVfBLK(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ࿽")
	if len(aargs)>=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠷ᗨ"): BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry += TWexH5PhS1(u"࠭࡜࡯ࠩ࿾")+aargs[HH4JMrUDp3lq6hQ(u"࠵ᗧ")]
	if len(aargs)>=VOq8Ekue4F(u"࠹ᗩ"): BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧ࡝ࡰࠪ࿿")+aargs[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠹ᗪ")]
	ElsZrgRneL = GNX3qVRf4oBdtkEi5u(direction,NN7Ui1HJPAKkWZYXGE,HVibA2ES8lY(u"ࠨࠩက"),j8CAJGLa0YSlrPfp,giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,**kkwargs)
	if ElsZrgRneL==-Xl3drKyI9HkDiPEf8RTjwu(u"࠵ᗫ") and BruLjvKO3Q48WITowPmzfkblyGac: ElsZrgRneL = -Xl3drKyI9HkDiPEf8RTjwu(u"࠵ᗫ")
	elif ElsZrgRneL==-g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶ᗬ") and not BruLjvKO3Q48WITowPmzfkblyGac: ElsZrgRneL = ZhqJoOtcmTVID65HwnLj(u"ࡇࡣ࡯ࡷࡪᜪ")
	elif ElsZrgRneL==oAXJCYqPgyGDtT(u"࠶ᗭ"): ElsZrgRneL = HVibA2ES8lY(u"ࡈࡤࡰࡸ࡫ᜫ")
	elif ElsZrgRneL==EmK3ObA0cwv9Wy(u"࠲ᗮ"): ElsZrgRneL = EEvLoMzFqrlKce(u"ࡗࡶࡺ࡫ᜬ")
	return ElsZrgRneL
def sSOy1pju5PJ(*aargs,**kkwargs):
	return Ko1p5u9jwG6rF.Dialog().select(*aargs,**kkwargs)
def fYPz7RldWQVHBktZAexwvCL8Np3D(*aargs,**kkwargs):
	giEdr0D19uz = aargs[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠱ᗯ")]
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = aargs[PiFkQ5pCJy7fbX(u"࠳ᗰ")]
	if S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡷ࡭ࡲ࡫ࠧခ") in list(kkwargs.keys()): MtAb48XPm0g6LxelJdG9oFvqR = kkwargs[ZEiR0StquOzca9lvPAndYIX(u"ࠪࡸ࡮ࡳࡥࠨဂ")]
	else: MtAb48XPm0g6LxelJdG9oFvqR = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠴࠴࠵࠶ᗱ")
	if len(aargs)>EEvLoMzFqrlKce(u"࠶ᗲ") and HVibA2ES8lY(u"ࠫࡹ࡯࡭ࡦࠩဃ") not in aargs[EEvLoMzFqrlKce(u"࠶ᗲ")]: profile = aargs[EEvLoMzFqrlKce(u"࠶ᗲ")]
	else: profile = VOq8Ekue4F(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫင")
	pWVOlx1ZqBhkyLo7jzJA8 = awRv8kI51963jzSpLAUNb(oAXJCYqPgyGDtT(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭စ"),mmry7DBuMdxCOPkeA,HVibA2ES8lY(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨဆ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨ࠹࠵࠴ࡵ࠭ဇ"))
	image_filename = Any0C7sBJTuiGW.replace(ZEiR0StquOzca9lvPAndYIX(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩဈ"),VOq8Ekue4F(u"ࠪࡣࠬဉ")+str(D1vBJgya85Yh4cRTCkIMKtWLSeH.time())+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡤ࠭ည"))
	image_filename = image_filename.replace(TWexH5PhS1(u"ࠬࡢ࡜ࠨဋ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭࡜࡝࡞࡟ࠫဌ")).replace(oAXJCYqPgyGDtT(u"ࠧ࠰࠱ࠪဍ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࠱࠲࠳࠴࠭ဎ"))
	image_height = WmJZHlzfcbuqFd6(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࠪဏ"),sbgu4D2RFMYKm(u"ࠪࠫတ"),l5mQdjWyczr7UJVnTp(u"ࠫࠬထ"),giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile,WmaPChRdQk3YcXwI6zS(u"ࠬࡲࡥࡧࡶࠪဒ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡊࡦࡲࡳࡦᜭ"),image_filename)
	pWVOlx1ZqBhkyLo7jzJA8.show()
	if profile==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧဓ"):
		pWVOlx1ZqBhkyLo7jzJA8.getControl(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠿࠰࠵࠲ᗴ")).setHeight(ZEiR0StquOzca9lvPAndYIX(u"࠷࠷࠵ᗳ"))
		pWVOlx1ZqBhkyLo7jzJA8.getControl(ZhqJoOtcmTVID65HwnLj(u"࠻࠳࠸࠵ᗷ")).setPosition(ZEiR0StquOzca9lvPAndYIX(u"࠵࠶ᗵ"),-BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠹࠲ᗶ"))
		pWVOlx1ZqBhkyLo7jzJA8.getControl(f5uqIoSJzWBOFyrY78RXmVb(u"࠼࠴࠺࠶ᗸ")).setPosition(l5mQdjWyczr7UJVnTp(u"࠵࠷࠶ᗹ"),-HH4JMrUDp3lq6hQ(u"࠻࠶ᗺ"))
		pWVOlx1ZqBhkyLo7jzJA8.getControl(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵࠲࠳ᗽ")).setPosition(N9olEh0ZMtpOivVfBLK(u"࠿࠰ᗻ"),-g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠳࠶ᗼ"))
	pWVOlx1ZqBhkyLo7jzJA8.getControl(PiFkQ5pCJy7fbX(u"࠶࠳࠵ᗾ")).setVisible(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡋࡧ࡬ࡴࡧᜮ"))
	pWVOlx1ZqBhkyLo7jzJA8.getControl(vatyjK4hHAoZJ7rOq2lis(u"࠷࠴࠷ᗿ")).setVisible(l5mQdjWyczr7UJVnTp(u"ࡌࡡ࡭ࡵࡨᜯ"))
	pWVOlx1ZqBhkyLo7jzJA8.getControl(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠽࠵࠻࠰ᘀ")).setImage(image_filename)
	pWVOlx1ZqBhkyLo7jzJA8.getControl(TWexH5PhS1(u"࠾࠶࠵࠱ᘁ")).setHeight(image_height)
	tGuBrszwxTkWA3OIc = RZxCcFI8fw31NKP.Thread(target=pKfXRniQSjy05AV,args=(pWVOlx1ZqBhkyLo7jzJA8,image_filename,MtAb48XPm0g6LxelJdG9oFvqR))
	tGuBrszwxTkWA3OIc.start()
	return
def pKfXRniQSjy05AV(pWVOlx1ZqBhkyLo7jzJA8,image_filename,MtAb48XPm0g6LxelJdG9oFvqR):
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(MtAb48XPm0g6LxelJdG9oFvqR//oAXJCYqPgyGDtT(u"࠷࠰࠱࠲࠱࠴ᘂ"))
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(Xl3drKyI9HkDiPEf8RTjwu(u"࠰࠯࠳࠳࠴ᘃ"))
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(image_filename):
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(image_filename)
		except: pass
	return
def JdTOfC6BRIKoGu(*aargs,**kkwargs):
	giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile,direction = h5huy6MiXPNfQJF8(u"ࠧࠨန"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࠩပ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪဖ"),vatyjK4hHAoZJ7rOq2lis(u"ࠪࡰࡪ࡬ࡴࠨဗ")
	if len(aargs)>=HVibA2ES8lY(u"࠲ᘄ"): giEdr0D19uz = aargs[EmK3ObA0cwv9Wy(u"࠲ᘅ")]
	if len(aargs)>=VH9MDo5z1kxNF07uRJI(u"࠶ᘇ"): BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = aargs[HVibA2ES8lY(u"࠴ᘆ")]
	if len(aargs)>=WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠸ᘈ"): profile = aargs[h5huy6MiXPNfQJF8(u"࠸ᘉ")]
	if len(aargs)>=vatyjK4hHAoZJ7rOq2lis(u"࠵ᘋ"): direction = aargs[TWexH5PhS1(u"࠳ᘊ")]
	return WWZfqplYBUhn6oxiXOmCe24bI0RA9(direction,giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile)
def FfDSUcBCGtevnqLPKxd(*aargs,**kkwargs):
	return Ko1p5u9jwG6rF.Dialog().contextmenu(*aargs,**kkwargs)
def EGry4B7kMg1TpuYcNmn(*aargs,**kkwargs):
	return Ko1p5u9jwG6rF.Dialog().browseSingle(*aargs,**kkwargs)
def ZFPkCOboImgG8SzE0h6u(*aargs,**kkwargs):
	return Ko1p5u9jwG6rF.Dialog().input(*aargs,**kkwargs)
def RNrYlESg2f0OLJnG7wQ(*aargs,**kkwargs):
	return Ko1p5u9jwG6rF.DialogProgress(*aargs,**kkwargs)
def inrDtz8mJqLpkPSldeyYjsEaBwA(V5WNor2kmtwedbOyU3n0qsT):
	if XK3HqaTnjpyIAuhw67CmdvBM>PiFkQ5pCJy7fbX(u"࠳࠺࠲࠾࠿ᘌ"): pWVOlx1ZqBhkyLo7jzJA8 = ZEiR0StquOzca9lvPAndYIX(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩဘ")
	else: pWVOlx1ZqBhkyLo7jzJA8 = FIHNSc5iuoZanQ2Ytl(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩမ")
	V5WNor2kmtwedbOyU3n0qsT = V5WNor2kmtwedbOyU3n0qsT.lower()
	if V5WNor2kmtwedbOyU3n0qsT==sDiKwnHcSlYFgWCy1Ak(u"࠭ࡳࡵࡣࡵࡸࠬယ"): EO9Rts0AaGuk1qpPLXCY.executebuiltin(HVibA2ES8lY(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩရ")+pWVOlx1ZqBhkyLo7jzJA8+Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࠫࠪလ"))
	elif V5WNor2kmtwedbOyU3n0qsT==WmaPChRdQk3YcXwI6zS(u"ࠩࡶࡸࡴࡶࠧဝ"): EO9Rts0AaGuk1qpPLXCY.executebuiltin(WmaPChRdQk3YcXwI6zS(u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪသ")+pWVOlx1ZqBhkyLo7jzJA8+FIHNSc5iuoZanQ2Ytl(u"ࠫ࠮࠭ဟ"))
	return
def GNX3qVRf4oBdtkEi5u(direction,button0=EEvLoMzFqrlKce(u"ࠬ࠭ဠ"),button1=EmK3ObA0cwv9Wy(u"࠭ࠧအ"),button2=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠨဢ"),giEdr0D19uz=VOq8Ekue4F(u"ࠨࠩဣ"),BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry=N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࠪဤ"),profile=EEvLoMzFqrlKce(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬဥ"),b1MTPhUkWgscCiN6uYOy=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᘍ"),N1hRtzFwOxieSnHlQvrDEMaW=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᘍ")):
	if not direction: direction = VOq8Ekue4F(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫဦ")
	pWVOlx1ZqBhkyLo7jzJA8 = GY39Leqb7SoO(ttOu147wErcBvPaSMUY(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧဧ"),mmry7DBuMdxCOPkeA,sDiKwnHcSlYFgWCy1Ak(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧဨ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠧ࠸࠴࠳ࡴࠬဩ"))
	pWVOlx1ZqBhkyLo7jzJA8.yivr3DA9pgdFu62m1e5TPNHlIw(button0,button1,button2,giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile,direction,b1MTPhUkWgscCiN6uYOy,N1hRtzFwOxieSnHlQvrDEMaW)
	if b1MTPhUkWgscCiN6uYOy>EEvLoMzFqrlKce(u"࠴ᘎ"): pWVOlx1ZqBhkyLo7jzJA8.vtry9jNZi8xP0JIuXUHqFgsA()
	if N1hRtzFwOxieSnHlQvrDEMaW>ZEiR0StquOzca9lvPAndYIX(u"࠵ᘏ"): pWVOlx1ZqBhkyLo7jzJA8.dwxVfqIcpKC5nO0ALyj()
	if b1MTPhUkWgscCiN6uYOy==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶ᘐ") and N1hRtzFwOxieSnHlQvrDEMaW==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶ᘐ"): pWVOlx1ZqBhkyLo7jzJA8.DhOQRryqHYApc9F()
	pWVOlx1ZqBhkyLo7jzJA8.doModal()
	ElsZrgRneL = pWVOlx1ZqBhkyLo7jzJA8.choiceID
	return ElsZrgRneL
def WWZfqplYBUhn6oxiXOmCe24bI0RA9(direction,giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile=QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩဪ")):
	if not direction: direction = oAXJCYqPgyGDtT(u"ࠩ࡯ࡩ࡫ࡺࠧါ")
	pWVOlx1ZqBhkyLo7jzJA8 = awRv8kI51963jzSpLAUNb(VH9MDo5z1kxNF07uRJI(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭ာ"),mmry7DBuMdxCOPkeA,ttOu147wErcBvPaSMUY(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬိ"),oAXJCYqPgyGDtT(u"ࠬ࠽࠲࠱ࡲࠪီ"))
	image_filename = Any0C7sBJTuiGW.replace(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ု"),l5mQdjWyczr7UJVnTp(u"ࠧࡠࠩူ")+str(D1vBJgya85Yh4cRTCkIMKtWLSeH.time())+HVibA2ES8lY(u"ࠨࡡࠪေ"))
	image_filename = image_filename.replace(vatyjK4hHAoZJ7rOq2lis(u"ࠩ࡟ࡠࠬဲ"),VH9MDo5z1kxNF07uRJI(u"ࠪࡠࡡࡢ࡜ࠨဳ")).replace(h5huy6MiXPNfQJF8(u"ࠫ࠴࠵ࠧဴ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࠵࠯࠰࠱ࠪဵ"))
	image_height = WmJZHlzfcbuqFd6(HH4JMrUDp3lq6hQ(u"࠭ࠧံ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠨ့"),PiFkQ5pCJy7fbX(u"ࠨࠩး"),giEdr0D19uz,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,profile,direction,f5uqIoSJzWBOFyrY78RXmVb(u"ࡆࡢ࡮ࡶࡩᜰ"),image_filename)
	pWVOlx1ZqBhkyLo7jzJA8.show()
	pWVOlx1ZqBhkyLo7jzJA8.getControl(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠹࠱࠷࠳ᘑ")).setHeight(image_height)
	pWVOlx1ZqBhkyLo7jzJA8.getControl(ttOu147wErcBvPaSMUY(u"࠺࠲࠸࠴ᘒ")).setImage(image_filename)
	aaTNWVv1zR8b0dwY = pWVOlx1ZqBhkyLo7jzJA8.doModal()
	try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(image_filename)
	except: pass
	return aaTNWVv1zR8b0dwY
def diwUZMEagkFDlS(a7oyXkJbYhduLzgiQINO=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡕࡴࡸࡩᜱ")):
	if a7oyXkJbYhduLzgiQINO:
		zslrWLD38jgdn = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡶࡸࡷ္࠭"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ်࠭"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧျ"))
		if zslrWLD38jgdn: return zslrWLD38jgdn
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = N9olEh0ZMtpOivVfBLK(u"ࠬ࠭ြ")
	if PiFkQ5pCJy7fbX(u"࠲ᘓ") and z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
		KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
		TnOEcKMSxN = KLxMkaVlguvqPcF.count(HH4JMrUDp3lq6hQ(u"࠭ࡍࡰࡼ࡬ࡰࡱࡧࠧွ"))
		if TnOEcKMSxN>VH9MDo5z1kxNF07uRJI(u"࠻࠴ᘔ"):
			BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = T072lCzjYiuaeFtmJGV.findall(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡨࡧࡷ࠱ࡹ࡮ࡥ࠮࡮࡬ࡷࡹ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩှ"),KLxMkaVlguvqPcF,T072lCzjYiuaeFtmJGV.DOTALL)
			BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry[PiFkQ5pCJy7fbX(u"࠴ᘕ")]
	if not BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry:
		ktPpVv9QzmxrLEMnGiZwCU6S0ql1yA = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,EEvLoMzFqrlKce(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧဿ"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶࠪ၀"))
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = open(ktPpVv9QzmxrLEMnGiZwCU6S0ql1yA,EmK3ObA0cwv9Wy(u"ࠪࡶࡧ࠭၁")).read()
		if mmIKCGujwM: BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.decode(ZhqJoOtcmTVID65HwnLj(u"ࠫࡺࡺࡦ࠹ࠩ၂"))
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(HVibA2ES8lY(u"ࠬࡢࡲࠨ၃"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧ၄"))
	VoKlREB9xjNI2nvr = T072lCzjYiuaeFtmJGV.findall(vatyjK4hHAoZJ7rOq2lis(u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨ၅"),BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,T072lCzjYiuaeFtmJGV.DOTALL)
	XWerRHDCFqE = []
	for TTjZMRAUezcia in VoKlREB9xjNI2nvr:
		XU0JFfpmayw3eRdNMQSjvObrKBA = TTjZMRAUezcia.lower()
		if vatyjK4hHAoZJ7rOq2lis(u"ࠨࡣࡱࡨࡷࡵࡩࡥࠩ၆") in XU0JFfpmayw3eRdNMQSjvObrKBA: continue
		if mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡸࡦࡺࡴࡴࡶࠩ၇") in XU0JFfpmayw3eRdNMQSjvObrKBA: continue
		if f5uqIoSJzWBOFyrY78RXmVb(u"ࠪ࡭ࡵ࡮࡯࡯ࡧࠪ၈") in XU0JFfpmayw3eRdNMQSjvObrKBA: continue
		if TWexH5PhS1(u"ࠫࡨࡸ࡯ࡴࠩ၉") in XU0JFfpmayw3eRdNMQSjvObrKBA: continue
		XWerRHDCFqE.append(TTjZMRAUezcia)
	zslrWLD38jgdn = XIjYJW8qbtv63.sample(XWerRHDCFqE,EEvLoMzFqrlKce(u"࠶ᘖ"))
	zslrWLD38jgdn = zslrWLD38jgdn[N9olEh0ZMtpOivVfBLK(u"࠶ᘗ")]
	rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,ZhqJoOtcmTVID65HwnLj(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ၊"),ttOu147wErcBvPaSMUY(u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ။"),zslrWLD38jgdn,GGXxhdg3JCamPIFepybjZ)
	return zslrWLD38jgdn
def lmX9WoCBVcaysrT3NgkzbFtJUxw(WzeExBTV6h=weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨ၌")):
	if not WzeExBTV6h: WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
	if WzeExBTV6h!=Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ၍"): CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
	SXOJtRiHqaUFCp2e = WzeExBTV6h.splitlines()
	g3gh0rZF6Bp1X8UmaWe9 = SXOJtRiHqaUFCp2e[-ttOu147wErcBvPaSMUY(u"࠱ᘘ")]
	fINB4QRLPytZTGgxqClMoU = open(aHPguvxqCjOmAwsF,ttOu147wErcBvPaSMUY(u"ࠩࡵࡦࠬ၎")).read()
	if mmIKCGujwM: fINB4QRLPytZTGgxqClMoU = fINB4QRLPytZTGgxqClMoU.decode(Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡹࡹ࡬࠸ࠨ၏"))
	fINB4QRLPytZTGgxqClMoU = fINB4QRLPytZTGgxqClMoU[-EmK3ObA0cwv9Wy(u"࠹࠲࠳࠴ᘙ"):]
	rDZWqIkJl5ywX1iO37gBo4YcLjn = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡂ࠭ၐ")*vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳࠳࠴ᘚ")
	if rDZWqIkJl5ywX1iO37gBo4YcLjn in fINB4QRLPytZTGgxqClMoU: fINB4QRLPytZTGgxqClMoU = fINB4QRLPytZTGgxqClMoU.rsplit(rDZWqIkJl5ywX1iO37gBo4YcLjn,PiFkQ5pCJy7fbX(u"࠴ᘛ"))[PiFkQ5pCJy7fbX(u"࠴ᘛ")]
	if g3gh0rZF6Bp1X8UmaWe9 in fINB4QRLPytZTGgxqClMoU: fINB4QRLPytZTGgxqClMoU = fINB4QRLPytZTGgxqClMoU.rsplit(g3gh0rZF6Bp1X8UmaWe9,l5mQdjWyczr7UJVnTp(u"࠵ᘜ"))[mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵ᘝ")]
	iihTqnQIpjc15oR0AUadVYZ = T072lCzjYiuaeFtmJGV.findall(Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫၑ"),fINB4QRLPytZTGgxqClMoU,T072lCzjYiuaeFtmJGV.DOTALL)
	for QktNZWropcaqA57u,nnN6lPjWb0xVQqDKwo3 in reversed(iihTqnQIpjc15oR0AUadVYZ):
		if nnN6lPjWb0xVQqDKwo3: break
	else: nnN6lPjWb0xVQqDKwo3 = TWexH5PhS1(u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭ၒ")
	QrXa1M59APiDRvHL6GJOgd7Et4,TTjZMRAUezcia,FjLgvY9G5S7yU42VkTfPJwN8 = ZhqJoOtcmTVID65HwnLj(u"ࠧࠨၓ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠩၔ"),TWexH5PhS1(u"ࠩࠪၕ")
	VVbvI7Jyqrw5UK1YkE = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၖ")+g3gh0rZF6Bp1X8UmaWe9
	nUEkWtT7yoMQPFDhAYCsrd = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅึัิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨၗ")+nnN6lPjWb0xVQqDKwo3
	for PAd3J5vGVTYgtI in reversed(SXOJtRiHqaUFCp2e):
		if g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࡌࡩ࡭ࡧࠣࠦࠬၘ") in PAd3J5vGVTYgtI and cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬၙ") in PAd3J5vGVTYgtI: break
	PAd3J5vGVTYgtI = T072lCzjYiuaeFtmJGV.findall(WmaPChRdQk3YcXwI6zS(u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪၚ"),PAd3J5vGVTYgtI,T072lCzjYiuaeFtmJGV.DOTALL)
	if PAd3J5vGVTYgtI:
		QrXa1M59APiDRvHL6GJOgd7Et4,TTjZMRAUezcia,FjLgvY9G5S7yU42VkTfPJwN8 = PAd3J5vGVTYgtI[ZhqJoOtcmTVID65HwnLj(u"࠶ᘞ")]
		if h5huy6MiXPNfQJF8(u"ࠨ࠱ࠪၛ") in QrXa1M59APiDRvHL6GJOgd7Et4: QrXa1M59APiDRvHL6GJOgd7Et4 = QrXa1M59APiDRvHL6GJOgd7Et4.rsplit(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࠲ࠫၜ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱ᘟ"))[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱ᘟ")]
		else: QrXa1M59APiDRvHL6GJOgd7Et4 = QrXa1M59APiDRvHL6GJOgd7Et4.rsplit(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡠࡡ࠭ၝ"),oAXJCYqPgyGDtT(u"࠲ᘠ"))[oAXJCYqPgyGDtT(u"࠲ᘠ")]
		WIZBpuKl3emOb = VH9MDo5z1kxNF07uRJI(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅๅใ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧၞ")+QrXa1M59APiDRvHL6GJOgd7Et4
		qY9zWCa1l7LcpB8gPI3GQ0s = FIHNSc5iuoZanQ2Ytl(u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิูิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨၟ")+TTjZMRAUezcia
		JLk5w068toFxTUNceAvabsiX = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ๆห๋ࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪၠ")+FjLgvY9G5S7yU42VkTfPJwN8
		OB4K37tmMUDEv6eY = WIZBpuKl3emOb+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧ࡝ࡰࠪၡ")+qY9zWCa1l7LcpB8gPI3GQ0s+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࡞ࡱࠫၢ")+JLk5w068toFxTUNceAvabsiX+ttOu147wErcBvPaSMUY(u"ࠩ࡟ࡲࠬၣ")+nUEkWtT7yoMQPFDhAYCsrd+EEvLoMzFqrlKce(u"ࠪࡠࡳ࠭ၤ")+VVbvI7Jyqrw5UK1YkE
		yHicpJS4xaTBWC = qY9zWCa1l7LcpB8gPI3GQ0s+HH4JMrUDp3lq6hQ(u"ࠫࡡࡴࠧၥ")+nUEkWtT7yoMQPFDhAYCsrd+ttOu147wErcBvPaSMUY(u"ࠬࡢ࡮ࠨၦ")+VVbvI7Jyqrw5UK1YkE+FIHNSc5iuoZanQ2Ytl(u"࠭࡜࡯ࠩၧ")+WIZBpuKl3emOb+N9olEh0ZMtpOivVfBLK(u"ࠧ࡝ࡰࠪၨ")+JLk5w068toFxTUNceAvabsiX
		vgS4X3Q7LDEaeMk068r1UH = qY9zWCa1l7LcpB8gPI3GQ0s+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨ࡞ࡱࠫၩ")+VVbvI7Jyqrw5UK1YkE+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩ࡟ࡲࠬၪ")+WIZBpuKl3emOb+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡠࡳ࠭ၫ")+JLk5w068toFxTUNceAvabsiX
	else:
		WIZBpuKl3emOb,qY9zWCa1l7LcpB8gPI3GQ0s,JLk5w068toFxTUNceAvabsiX = ZhqJoOtcmTVID65HwnLj(u"ࠫࠬၬ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࠭ၭ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࠧၮ")
		OB4K37tmMUDEv6eY = nUEkWtT7yoMQPFDhAYCsrd+EmK3ObA0cwv9Wy(u"ࠧ࡝ࡰ࡟ࡲࠬၯ")+VVbvI7Jyqrw5UK1YkE
		yHicpJS4xaTBWC = nUEkWtT7yoMQPFDhAYCsrd+HH4JMrUDp3lq6hQ(u"ࠨ࡞ࡱࡠࡳ࠭ၰ")+VVbvI7Jyqrw5UK1YkE
		vgS4X3Q7LDEaeMk068r1UH = VVbvI7Jyqrw5UK1YkE
	hhBiMA3stZlCVv = VH9MDo5z1kxNF07uRJI(u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭ၱ")+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡠࡳ࠭ၲ")
	pcHqaluDUz = YVfiJ2RjBTI9FvkG1KA5sMZhaPl()
	ww0jck4JqXQxKd3IW = []
	cLCisPE3lX = pcHqaluDUz[oAXJCYqPgyGDtT(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩၳ")]
	a4PjEnedtYq2GM6VNu = EX7zl3J1Ph8fOWpxQTdZboLNF4(pQmoyUJBNaf72A)
	if cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၴ") in list(pcHqaluDUz.keys()):
		for FeJkKctiN0rwxvlg2C8G4oyq,VVHFqnMS9C5NEsrmAOvygJdwU,Ahz6Ma0ndWuQLwsFD in cLCisPE3lX: ww0jck4JqXQxKd3IW = max(ww0jck4JqXQxKd3IW,VVHFqnMS9C5NEsrmAOvygJdwU)
		if a4PjEnedtYq2GM6VNu<ww0jck4JqXQxKd3IW:
			giEdr0D19uz = HVibA2ES8lY(u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩၵ")
			ElsZrgRneL = GNX3qVRf4oBdtkEi5u(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ၶ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬၷ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩอัิ๐หࠨၸ"),ZEiR0StquOzca9lvPAndYIX(u"ࠪาึ๎ฬࠨၹ"),hhBiMA3stZlCVv+giEdr0D19uz,OB4K37tmMUDEv6eY)
			if ElsZrgRneL==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠲ᘡ"):
				VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(FIHNSc5iuoZanQ2Ytl(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫၺ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬิั้ฮࠪၻ"),VOq8Ekue4F(u"࠭สฮัํฯࠬၼ"),VH9MDo5z1kxNF07uRJI(u"ࠧࠨၽ"),giEdr0D19uz)
				if VjwKs4GNQZ518kCl==ZEiR0StquOzca9lvPAndYIX(u"࠴ᘢ"): ElsZrgRneL = ZEiR0StquOzca9lvPAndYIX(u"࠴ᘢ")
			if ElsZrgRneL==ttOu147wErcBvPaSMUY(u"࠵ᘣ"):
				import TRa6GJnHO1
				TRa6GJnHO1.GT8XWZULDtz7sYlhIfVnE12rOK(HVibA2ES8lY(u"ࡖࡵࡹࡪᜲ"),HVibA2ES8lY(u"ࡖࡵࡹࡪᜲ"))
			return
	se20auIUdcMwK8ZtHbr = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࡮࡬ࡷࡹ࠭ၾ"),VOq8Ekue4F(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬၿ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬႀ"))
	if not se20auIUdcMwK8ZtHbr: se20auIUdcMwK8ZtHbr = []
	yHicpJS4xaTBWC = yHicpJS4xaTBWC.replace(TWexH5PhS1(u"ࠫࡡࡴࠧႁ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡢ࡜࡯ࠩႂ")).replace(ZEiR0StquOzca9lvPAndYIX(u"࡛࠭ࡓࡖࡏࡡࠬႃ"),WmaPChRdQk3YcXwI6zS(u"ࠧࠨႄ")).replace(WmaPChRdQk3YcXwI6zS(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫႅ"),h5huy6MiXPNfQJF8(u"ࠩࠪႆ")).replace(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬႇ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠬႈ"))
	vgS4X3Q7LDEaeMk068r1UH = vgS4X3Q7LDEaeMk068r1UH.replace(EEvLoMzFqrlKce(u"ࠬࡢ࡮ࠨႉ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭࡜࡝ࡰࠪႊ")).replace(EmK3ObA0cwv9Wy(u"ࠧ࡜ࡔࡗࡐࡢ࠭ႋ"),HH4JMrUDp3lq6hQ(u"ࠨࠩႌ")).replace(ttOu147wErcBvPaSMUY(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡႍࠬ"),PiFkQ5pCJy7fbX(u"ࠪࠫႎ")).replace(ZEiR0StquOzca9lvPAndYIX(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ႏ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࠭႐"))
	uupH0bJEket6 = pQmoyUJBNaf72A+N9olEh0ZMtpOivVfBLK(u"࠭࠺࠻ࠩ႑")+vgS4X3Q7LDEaeMk068r1UH
	if uupH0bJEket6 in se20auIUdcMwK8ZtHbr:
		giEdr0D19uz = WmaPChRdQk3YcXwI6zS(u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ႒")
		KK47FGdX1TDfkb3AjHOQqghE(vatyjK4hHAoZJ7rOq2lis(u"ࠨࡴ࡬࡫࡭ࡺࠧ႓"),EmK3ObA0cwv9Wy(u"ࠩࠪ႔"),hhBiMA3stZlCVv+giEdr0D19uz,OB4K37tmMUDEv6eY)
		return
	veb3ISjfA9XE6so8 = str(XK3HqaTnjpyIAuhw67CmdvBM).split(VH9MDo5z1kxNF07uRJI(u"ࠪ࠲ࠬ႕"))[EEvLoMzFqrlKce(u"࠵ᘤ")]
	gz1flZwncVutokL59RaGS3WeK = tOnYIHVk4xydqwoLEBKiDN0hX[FIHNSc5iuoZanQ2Ytl(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ႖")][HVibA2ES8lY(u"࠼ᘥ")]
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,N9olEh0ZMtpOivVfBLK(u"ࠬࡖࡏࡔࡖࠪ႗"),gz1flZwncVutokL59RaGS3WeK,ZhqJoOtcmTVID65HwnLj(u"࠭ࠧ႘"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧࠨ႙"),HH4JMrUDp3lq6hQ(u"ࠨࠩႚ"),oAXJCYqPgyGDtT(u"ࠩࠪႛ"),ZEiR0StquOzca9lvPAndYIX(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫႜ"),sDiKwnHcSlYFgWCy1Ak(u"ࡉࡥࡱࡹࡥᜳ"),sDiKwnHcSlYFgWCy1Ak(u"ࡉࡥࡱࡹࡥᜳ"))
	KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
	zvrlJf4OXboWi6e8m57gDQ = T072lCzjYiuaeFtmJGV.findall(FIHNSc5iuoZanQ2Ytl(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫႝ"),KLxMkaVlguvqPcF,T072lCzjYiuaeFtmJGV.DOTALL)
	for LDzN7Th80vAG,Y0eEoDTJa7H4csuM32C9ifAqIK,ejw2CdEkJgFrZsB1tO,KEMvALlTZ1PYk9oIpU5m in zvrlJf4OXboWi6e8m57gDQ:
		LDzN7Th80vAG = LDzN7Th80vAG.split(TWexH5PhS1(u"ࠬ࠱ࠧ႞"))
		ejw2CdEkJgFrZsB1tO = ejw2CdEkJgFrZsB1tO.split(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠫࠨ႟"))
		KEMvALlTZ1PYk9oIpU5m = KEMvALlTZ1PYk9oIpU5m.split(oAXJCYqPgyGDtT(u"ࠧࠬࠩႠ"))
		if TTjZMRAUezcia in LDzN7Th80vAG and g3gh0rZF6Bp1X8UmaWe9==Y0eEoDTJa7H4csuM32C9ifAqIK and pQmoyUJBNaf72A in ejw2CdEkJgFrZsB1tO and veb3ISjfA9XE6so8 in KEMvALlTZ1PYk9oIpU5m:
			giEdr0D19uz = PiFkQ5pCJy7fbX(u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭Ⴁ")
			VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(oAXJCYqPgyGDtT(u"ࠩࡵ࡭࡬࡮ࡴࠨႢ"),VOq8Ekue4F(u"ࠪาึ๎ฬࠨႣ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨႤ"),hhBiMA3stZlCVv+giEdr0D19uz,OB4K37tmMUDEv6eY)
			if VjwKs4GNQZ518kCl==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱ᘦ"): KK47FGdX1TDfkb3AjHOQqghE(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬႥ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧႦ"),EEvLoMzFqrlKce(u"ࠧࠨႧ"),giEdr0D19uz)
			return
	giEdr0D19uz = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨႨ")
	KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡵ࡭࡬࡮ࡴࠨႩ"),FIHNSc5iuoZanQ2Ytl(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧႪ"),hhBiMA3stZlCVv+giEdr0D19uz,OB4K37tmMUDEv6eY)
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႫ"),FIHNSc5iuoZanQ2Ytl(u"ࠬ࠭Ⴌ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠧႭ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪႮ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩႯ"))
	if VjwKs4GNQZ518kCl==sbgu4D2RFMYKm(u"࠲ᘧ"): QQTqHdRmAn3YKtB = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬႰ")
	else:
		KK47FGdX1TDfkb3AjHOQqghE(VH9MDo5z1kxNF07uRJI(u"ࠪࡧࡪࡴࡴࡦࡴࠪႱ"),N9olEh0ZMtpOivVfBLK(u"ࠫࠬႲ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႳ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫႴ"))
		return
	kg1pK9CEwGaTI0ReMP4crBL8tshHy = yHicpJS4xaTBWC
	from TRa6GJnHO1 import YYKFsUfhQctD1bjpEzZagd
	UkYj1KP0ou4q9rVfEgn2JQHI56BG = YYKFsUfhQctD1bjpEzZagd(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡆࡴࡵࡳࡷࡹࠧႵ"),kg1pK9CEwGaTI0ReMP4crBL8tshHy,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡘࡷࡻࡥ᜴"),WmaPChRdQk3YcXwI6zS(u"ࠨࠩႶ"),PiFkQ5pCJy7fbX(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩႷ"),QQTqHdRmAn3YKtB)
	if UkYj1KP0ou4q9rVfEgn2JQHI56BG and QQTqHdRmAn3YKtB:
		se20auIUdcMwK8ZtHbr.append(uupH0bJEket6)
		rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭Ⴘ"),VH9MDo5z1kxNF07uRJI(u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭Ⴙ"),se20auIUdcMwK8ZtHbr,U6y1OBwzfkEuRGVNrpYFv)
	return
def J1rkOml5eSi64Ij9gwP(Z402tBVhQi):
	if mmIKCGujwM: Z402tBVhQi = Z402tBVhQi.encode(WmaPChRdQk3YcXwI6zS(u"ࠬࡻࡴࡧ࠺ࠪႺ"))
	qK2aImeBfl98EgMDQ = h5huy6MiXPNfQJF8(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭Ⴛ")+str(D1vBJgya85Yh4cRTCkIMKtWLSeH.time())+EEvLoMzFqrlKce(u"ࠧ࠯ࡦࡤࡸࠬႼ")
	open(qK2aImeBfl98EgMDQ,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡹࡥࠫႽ")).write(Z402tBVhQi)
	return
def wk1vqFgrYO4WDu5(jDSoFcA19T):
	if jDSoFcA19T:
		KieXfJOBZmz0S3V = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,EEvLoMzFqrlKce(u"ࠩ࡯࡭ࡸࡺࠧႾ"),h5huy6MiXPNfQJF8(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭Ⴟ"),WmaPChRdQk3YcXwI6zS(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧჀ"))
		if KieXfJOBZmz0S3V: return KieXfJOBZmz0S3V
	gz1flZwncVutokL59RaGS3WeK = tOnYIHVk4xydqwoLEBKiDN0hX[TWexH5PhS1(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬჁ")][g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠷ᘨ")]
	mXzxhH68tSFg = au8Umt9dq1KLSYb(EmK3ObA0cwv9Wy(u"࠶࠶ᘩ"),jDSoFcA19T)
	VTknBvs0QNLUOGr7h9wZ = EAeKCYbwXqJRODh3vyxB()
	jOxCyaFu0HoKVPi425htBsvmgGJe = VTknBvs0QNLUOGr7h9wZ.split(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠬࠨჂ"))[N9olEh0ZMtpOivVfBLK(u"࠶ᘪ")]
	AtCixIG4HuhL7wbUm2vc = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,EEvLoMzFqrlKce(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭Ⴣ"))
	dIE8vyse3xYfKG79RWZl = APxF1loHQnaCzMZqGrcT7O()
	LqWNfDO1dEvxBJih = {BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡷࡶࡩࡷ࠭Ⴤ"):mXzxhH68tSFg,EEvLoMzFqrlKce(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪჅ"):pQmoyUJBNaf72A,ZhqJoOtcmTVID65HwnLj(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ჆"):jOxCyaFu0HoKVPi425htBsvmgGJe,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫ࡮ࡪࡳࠨჇ"):zNx5bYlAyeLvtOpXfwK(dIE8vyse3xYfKG79RWZl)}
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,sbgu4D2RFMYKm(u"ࠬࡖࡏࡔࡖࠪ჈"),gz1flZwncVutokL59RaGS3WeK,LqWNfDO1dEvxBJih,N9olEh0ZMtpOivVfBLK(u"࠭ࠧ჉"),HVibA2ES8lY(u"ࠧࠨ჊"),EEvLoMzFqrlKce(u"ࠨࠩ჋"),l5mQdjWyczr7UJVnTp(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ჌"))
	KieXfJOBZmz0S3V = []
	if z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
		KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
		KieXfJOBZmz0S3V = KLxMkaVlguvqPcF.replace(oAXJCYqPgyGDtT(u"ࠪࡠࡡࡸࠧჍ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡡࡴࠧ჎")).replace(ZEiR0StquOzca9lvPAndYIX(u"ࠬࡢ࡜࡯ࠩ჏"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭࡜࡯ࠩა")).replace(sDiKwnHcSlYFgWCy1Ak(u"ࠧ࡝ࡴ࡟ࡲࠬბ"),N9olEh0ZMtpOivVfBLK(u"ࠨ࡞ࡱࠫგ")).replace(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࡟ࡶࠬდ"),l5mQdjWyczr7UJVnTp(u"ࠪࡠࡳ࠭ე"))
		KieXfJOBZmz0S3V = T072lCzjYiuaeFtmJGV.findall(sbgu4D2RFMYKm(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧვ"),KieXfJOBZmz0S3V,T072lCzjYiuaeFtmJGV.DOTALL)
		if KieXfJOBZmz0S3V:
			KieXfJOBZmz0S3V = sorted(KieXfJOBZmz0S3V,reverse=weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡋࡧ࡬ࡴࡧ᜵"),key=lambda key: int(key[f5uqIoSJzWBOFyrY78RXmVb(u"࠵ᘫ")]))
			kUVqWbOTsMBI8iL26RpD9YuzJl0,mXzxhH68tSFg,QWEuJVATdizDg8679CjxLOn,gQCu6NU0q5n3K7myZ,JobKQ5hDkIYC0iu48dGlTR,rreason = KieXfJOBZmz0S3V[Xl3drKyI9HkDiPEf8RTjwu(u"࠶ᘬ")]
			fl9ZwxiOTFyCm0 = rreason if wTpW3nbIgPckqCl9ohi(HH4JMrUDp3lq6hQ(u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫზ")) else QWEuJVATdizDg8679CjxLOn
			YTPut68WBVUNCvsEzg.setSetting(EEvLoMzFqrlKce(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨთ"),fl9ZwxiOTFyCm0)
			rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,ZhqJoOtcmTVID65HwnLj(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪი"),N9olEh0ZMtpOivVfBLK(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫკ"),KieXfJOBZmz0S3V,GGXxhdg3JCamPIFepybjZ)
			YTPut68WBVUNCvsEzg.setSetting(ttOu147wErcBvPaSMUY(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫლ"),zNx5bYlAyeLvtOpXfwK(EEd0FZyfticlDPAMp2HbNesx))
	return KieXfJOBZmz0S3V
def Pfl6pNBAE7YsU(wTh1iyANZn0txGBgoPk,Wpd4eEsyixrBc3mo=EmK3ObA0cwv9Wy(u"࠰ᘭ"),fQ4D29zYUchRFlXuLx=EmK3ObA0cwv9Wy(u"࠰ᘭ")):
	if Wpd4eEsyixrBc3mo and not fQ4D29zYUchRFlXuLx: fQ4D29zYUchRFlXuLx = len(wTh1iyANZn0txGBgoPk)//Wpd4eEsyixrBc3mo
	pFr3fyjJgvIPBa,H3ABEcMzfyqwF4Ug2ZYtK,xB1k7v8jIeQ5lfoTDHFPbydm4 = [],-mNkfJnpOrad7hT6PYyciwsSDQ(u"࠲ᘮ"),WmaPChRdQk3YcXwI6zS(u"࠲ᘯ")
	for hLYopVN51jn0T6 in wTh1iyANZn0txGBgoPk:
		if xB1k7v8jIeQ5lfoTDHFPbydm4%fQ4D29zYUchRFlXuLx==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳ᘰ"):
			H3ABEcMzfyqwF4Ug2ZYtK += S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠵ᘱ")
			pFr3fyjJgvIPBa.append([])
		pFr3fyjJgvIPBa[H3ABEcMzfyqwF4Ug2ZYtK].append(hLYopVN51jn0T6)
		xB1k7v8jIeQ5lfoTDHFPbydm4 += vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠶ᘲ")
	return pFr3fyjJgvIPBa
def OVj5W9AxhgR(qK2aImeBfl98EgMDQ,Z402tBVhQi):
	Ia9tjrpLcAyNuKvTxOnBWz7Z = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,qK2aImeBfl98EgMDQ)
	if Xl3drKyI9HkDiPEf8RTjwu(u"࠷ᘳ") or N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡍࡕ࡚ࡖࡠࠩმ") not in qK2aImeBfl98EgMDQ or weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠫࡒ࠹ࡕࡠࠩნ") not in qK2aImeBfl98EgMDQ: BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = str(Z402tBVhQi)
	else:
		pFr3fyjJgvIPBa = Pfl6pNBAE7YsU(Z402tBVhQi,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠸ᘴ"))
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = sbgu4D2RFMYKm(u"ࠬ࠭ო")
		for cyP41oLgeuV0 in pFr3fyjJgvIPBa:
			BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry += str(cyP41oLgeuV0)+N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬპ")
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.strip(vatyjK4hHAoZJ7rOq2lis(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ჟ"))
	xtwO1UCjBpsKEG32RrLzfMv06b = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.compress(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	open(Ia9tjrpLcAyNuKvTxOnBWz7Z,f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡹࡥࠫრ")).write(xtwO1UCjBpsKEG32RrLzfMv06b)
	return
def S5c1pLEO0Da(lAekNQf4FDj62iPCJ,qK2aImeBfl98EgMDQ):
	if lAekNQf4FDj62iPCJ==VH9MDo5z1kxNF07uRJI(u"ࠩࡧ࡭ࡨࡺࠧს"): Z402tBVhQi = {}
	elif lAekNQf4FDj62iPCJ==cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡰ࡮ࡹࡴࠨტ"): Z402tBVhQi = []
	elif lAekNQf4FDj62iPCJ==h5huy6MiXPNfQJF8(u"ࠫࡸࡺࡲࠨუ"): Z402tBVhQi = l5mQdjWyczr7UJVnTp(u"ࠬ࠭ფ")
	elif lAekNQf4FDj62iPCJ==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡩ࡯ࡶࠪქ"): Z402tBVhQi = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠱ᘵ")
	else: Z402tBVhQi = None
	Ia9tjrpLcAyNuKvTxOnBWz7Z = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,qK2aImeBfl98EgMDQ)
	xtwO1UCjBpsKEG32RrLzfMv06b = open(Ia9tjrpLcAyNuKvTxOnBWz7Z,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡳࡤࠪღ")).read()
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.decompress(xtwO1UCjBpsKEG32RrLzfMv06b)
	if VH9MDo5z1kxNF07uRJI(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧყ") not in BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry: Z402tBVhQi = eval(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	else:
		pFr3fyjJgvIPBa = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.split(h5huy6MiXPNfQJF8(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨშ"))
		del BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry
		Z402tBVhQi = []
		YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4 = Zeq6ARs9joiXNQ()
		kUVqWbOTsMBI8iL26RpD9YuzJl0 = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠲ᘶ")
		for cyP41oLgeuV0 in pFr3fyjJgvIPBa:
			YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4.hIL3twQ4mE2G1RYKcW(str(kUVqWbOTsMBI8iL26RpD9YuzJl0),eval,cyP41oLgeuV0)
			kUVqWbOTsMBI8iL26RpD9YuzJl0 += uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠴ᘷ")
		del pFr3fyjJgvIPBa
		YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4.XqxkFKEmSaoMV4JrOu2IYPiRh7lsC()
		YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4.Lag8UeJ9CPylkIp5XHOb()
		WWVPDEzJ7ToauBHk3tgKLGncYj = list(YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4.resultsDICT.keys())
		HHUDmTQMEIqKFsvOJk0nh4oYLtPgf7 = sorted(WWVPDEzJ7ToauBHk3tgKLGncYj,reverse=WmaPChRdQk3YcXwI6zS(u"ࡌࡡ࡭ࡵࡨ᜶"),key=lambda key: int(key))
		for kUVqWbOTsMBI8iL26RpD9YuzJl0 in HHUDmTQMEIqKFsvOJk0nh4oYLtPgf7:
			Z402tBVhQi += YyaPk9QdERZ2zJD3GCFHAs1ItrUhw4.resultsDICT[kUVqWbOTsMBI8iL26RpD9YuzJl0]
	return Z402tBVhQi
def O6adxiLzJ94KVyr20BoYHwqvIGX(x7NwSuz5ft4e):
	jsYC9NHbwxayO4ti0cmo78 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,WmaPChRdQk3YcXwI6zS(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪჩ"),x7NwSuz5ft4e,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧც"))
	try: Xiy35mLhABEtjo = open(jsYC9NHbwxayO4ti0cmo78,h5huy6MiXPNfQJF8(u"ࠬࡸࡢࠨძ")).read()
	except:
		YFwRuV7PksASI2dx = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(z6oycmT807knMXqxCSIsAWKOP,oAXJCYqPgyGDtT(u"࠭ࡡࡥࡦࡲࡲࡸ࠭წ"),x7NwSuz5ft4e,PiFkQ5pCJy7fbX(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪჭ"))
		try: Xiy35mLhABEtjo = open(YFwRuV7PksASI2dx,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࡴࡥࠫხ")).read()
		except: return TWexH5PhS1(u"ࠩࠪჯ"),[]
	if mmIKCGujwM: Xiy35mLhABEtjo = Xiy35mLhABEtjo.decode(N9olEh0ZMtpOivVfBLK(u"ࠪࡹࡹ࡬࠸ࠨჰ"))
	zH0vJYdWUg9GREX1 = T072lCzjYiuaeFtmJGV.findall(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨჱ"),Xiy35mLhABEtjo,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if not zH0vJYdWUg9GREX1: return S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬ࠭ჲ"),[]
	jvTAU4WmoIKJ2hftOsPE5in,GG3c7RPdaV5Tvi2 = zH0vJYdWUg9GREX1[f5uqIoSJzWBOFyrY78RXmVb(u"࠴ᘸ")],EX7zl3J1Ph8fOWpxQTdZboLNF4(zH0vJYdWUg9GREX1[f5uqIoSJzWBOFyrY78RXmVb(u"࠴ᘸ")])
	return jvTAU4WmoIKJ2hftOsPE5in,GG3c7RPdaV5Tvi2
def YVfiJ2RjBTI9FvkG1KA5sMZhaPl():
	MMTCya7p82U = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,ttOu147wErcBvPaSMUY(u"࠭ࡤࡪࡥࡷࠫჳ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪჴ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩჵ"))
	if MMTCya7p82U: return MMTCya7p82U
	pcHqaluDUz,MMTCya7p82U = {},{}
	iihTqnQIpjc15oR0AUadVYZ = [tOnYIHVk4xydqwoLEBKiDN0hX[TWexH5PhS1(u"ࠩࡕࡉࡕࡕࡓࠨჶ")][oAXJCYqPgyGDtT(u"࠵ᘹ")]]
	if XK3HqaTnjpyIAuhw67CmdvBM>VH9MDo5z1kxNF07uRJI(u"࠱࠸࠰࠼࠽ᘻ"): iihTqnQIpjc15oR0AUadVYZ.append(tOnYIHVk4xydqwoLEBKiDN0hX[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡖࡊࡖࡏࡔࠩჷ")][WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠷ᘺ")])
	if mmIKCGujwM: iihTqnQIpjc15oR0AUadVYZ.append(tOnYIHVk4xydqwoLEBKiDN0hX[VOq8Ekue4F(u"ࠫࡗࡋࡐࡐࡕࠪჸ")][f5uqIoSJzWBOFyrY78RXmVb(u"࠳ᘼ")])
	for mQsuK1Zl6p in iihTqnQIpjc15oR0AUadVYZ:
		z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,WmaPChRdQk3YcXwI6zS(u"ࠬࡍࡅࡕࠩჹ"),mQsuK1Zl6p,VH9MDo5z1kxNF07uRJI(u"࠭ࠧჺ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨ჻"),vatyjK4hHAoZJ7rOq2lis(u"ࠨࠩჼ"),N9olEh0ZMtpOivVfBLK(u"ࠩࠪჽ"),N9olEh0ZMtpOivVfBLK(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧჾ"))
		if z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
			KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
			VV6GtZQURudivgno2Y7kjMX = mQsuK1Zl6p.rsplit(ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠴࠭ჿ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠳ᘽ"))[vatyjK4hHAoZJ7rOq2lis(u"࠳ᘾ")]
			F7PnwCjDrYczgtBM9aAvSy3kTpX = T072lCzjYiuaeFtmJGV.findall(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᄀ"),KLxMkaVlguvqPcF,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
			for x7NwSuz5ft4e,YdRF31ryDutoVJli in F7PnwCjDrYczgtBM9aAvSy3kTpX:
				JhESfylXUBYVsqHP9 = VV6GtZQURudivgno2Y7kjMX+ZEiR0StquOzca9lvPAndYIX(u"࠭࠯ࠨᄁ")+x7NwSuz5ft4e+EEvLoMzFqrlKce(u"ࠧ࠰ࠩᄂ")+x7NwSuz5ft4e+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࠯ࠪᄃ")+YdRF31ryDutoVJli+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࠱ࡾ࡮ࡶࠧᄄ")
				if x7NwSuz5ft4e not in list(pcHqaluDUz.keys()):
					pcHqaluDUz[x7NwSuz5ft4e] = []
					MMTCya7p82U[x7NwSuz5ft4e] = []
				SS9soXIF2c4qeO1Pz = EX7zl3J1Ph8fOWpxQTdZboLNF4(YdRF31ryDutoVJli)
				pcHqaluDUz[x7NwSuz5ft4e].append((YdRF31ryDutoVJli,SS9soXIF2c4qeO1Pz,JhESfylXUBYVsqHP9))
	for x7NwSuz5ft4e in list(pcHqaluDUz.keys()):
		MMTCya7p82U[x7NwSuz5ft4e] = sorted(pcHqaluDUz[x7NwSuz5ft4e],reverse=EEvLoMzFqrlKce(u"ࡔࡳࡷࡨ᜷"),key=lambda key: key[ttOu147wErcBvPaSMUY(u"࠵ᘿ")])
	rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,EmK3ObA0cwv9Wy(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᄅ"),EmK3ObA0cwv9Wy(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬᄆ"),MMTCya7p82U,GGXxhdg3JCamPIFepybjZ)
	return MMTCya7p82U
def EX7zl3J1Ph8fOWpxQTdZboLNF4(YdRF31ryDutoVJli):
	SS9soXIF2c4qeO1Pz = []
	GSkb1Z2up37EPzDvWQT = YdRF31ryDutoVJli.split(N9olEh0ZMtpOivVfBLK(u"ࠬ࠴ࠧᄇ"))
	for NrOlMdAR0sLXcUa5DzP4mGE3I in GSkb1Z2up37EPzDvWQT:
		ZVhR1T504MdOYipfW = T072lCzjYiuaeFtmJGV.findall(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪᄈ"),NrOlMdAR0sLXcUa5DzP4mGE3I,T072lCzjYiuaeFtmJGV.DOTALL)
		ePcp0jyNV24Cg7KQlv19xm = []
		for zbwWvaCRAPo in ZVhR1T504MdOYipfW:
			if zbwWvaCRAPo.isdigit(): zbwWvaCRAPo = int(zbwWvaCRAPo)
			ePcp0jyNV24Cg7KQlv19xm.append(zbwWvaCRAPo)
		SS9soXIF2c4qeO1Pz.append(ePcp0jyNV24Cg7KQlv19xm)
	return SS9soXIF2c4qeO1Pz
def ZzGgUWlFO02m6XN(SS9soXIF2c4qeO1Pz):
	YdRF31ryDutoVJli = EmK3ObA0cwv9Wy(u"ࠧࠨᄉ")
	for NrOlMdAR0sLXcUa5DzP4mGE3I in SS9soXIF2c4qeO1Pz:
		for zbwWvaCRAPo in NrOlMdAR0sLXcUa5DzP4mGE3I: YdRF31ryDutoVJli += str(zbwWvaCRAPo)
		YdRF31ryDutoVJli += Xl3drKyI9HkDiPEf8RTjwu(u"ࠨ࠰ࠪᄊ")
	YdRF31ryDutoVJli = YdRF31ryDutoVJli.strip(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࠱ࠫᄋ"))
	return YdRF31ryDutoVJli
def tnmgjKPYByiL0q(S4SlZukyYG0AhmvOUoTWDBwrc9d):
	VXp2ouLAg5Mz8jct1hf6m = {}
	pcHqaluDUz = YVfiJ2RjBTI9FvkG1KA5sMZhaPl()
	rs4JmUMwkF7cCRAItLhp9i = IYGBRJjmO6n(S4SlZukyYG0AhmvOUoTWDBwrc9d)
	for x7NwSuz5ft4e in S4SlZukyYG0AhmvOUoTWDBwrc9d:
		if x7NwSuz5ft4e not in list(pcHqaluDUz.keys()): continue
		MMTCya7p82U = pcHqaluDUz[x7NwSuz5ft4e]
		NvPW3YMhR1zZkFtHKOQBipy0wTrxb7,M2uhU3GIW8jwJazHO,uckGrZOIv6HxD2ytjNWsXdm = MMTCya7p82U[HH4JMrUDp3lq6hQ(u"࠵ᙀ")]
		h2ldCUQZJ74k6EjrPLo,VoCapUKBIz3YWw8 = O6adxiLzJ94KVyr20BoYHwqvIGX(x7NwSuz5ft4e)
		WqwuGUjxHnz6cr4SL7mT5A,UUT3znrMvS6FxwHfKIuOo7kR9ELg = rs4JmUMwkF7cCRAItLhp9i[x7NwSuz5ft4e]
		IIK9ceBtuZUTQG5hRaCnziWp = M2uhU3GIW8jwJazHO>VoCapUKBIz3YWw8 and WqwuGUjxHnz6cr4SL7mT5A
		PgjqxZL23vFVYUfDe7RBOrS5n = ttOu147wErcBvPaSMUY(u"ࡕࡴࡸࡩ᜸")
		if not WqwuGUjxHnz6cr4SL7mT5A: NgH1U80knyI2P = N9olEh0ZMtpOivVfBLK(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫᄌ")
		elif not UUT3znrMvS6FxwHfKIuOo7kR9ELg: NgH1U80knyI2P = PiFkQ5pCJy7fbX(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭ᄍ")
		elif IIK9ceBtuZUTQG5hRaCnziWp: NgH1U80knyI2P = ttOu147wErcBvPaSMUY(u"ࠬࡵ࡬ࡥࠩᄎ")
		else:
			NgH1U80knyI2P = ZEiR0StquOzca9lvPAndYIX(u"࠭ࡧࡰࡱࡧࠫᄏ")
			PgjqxZL23vFVYUfDe7RBOrS5n = sbgu4D2RFMYKm(u"ࡈࡤࡰࡸ࡫᜹")
		VXp2ouLAg5Mz8jct1hf6m[x7NwSuz5ft4e] = (PgjqxZL23vFVYUfDe7RBOrS5n,h2ldCUQZJ74k6EjrPLo,VoCapUKBIz3YWw8,NvPW3YMhR1zZkFtHKOQBipy0wTrxb7,M2uhU3GIW8jwJazHO,NgH1U80knyI2P,uckGrZOIv6HxD2ytjNWsXdm)
	return VXp2ouLAg5Mz8jct1hf6m
def pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,c8RuAmF1yHI4tvZDPjiTq,Z0fFKNy67w=sDiKwnHcSlYFgWCy1Ak(u"ࠧࠨᄐ"),qY9zWCa1l7LcpB8gPI3GQ0s=HH4JMrUDp3lq6hQ(u"ࠨࠩᄑ"),LDzN7Th80vAG=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࠪᄒ")):
	if ggl6zFuXNdYTDieHCqGKRnVx: GwL9s6vAgzS0naR5Yc7ETm2xFO.update(c8RuAmF1yHI4tvZDPjiTq,Z0fFKNy67w,qY9zWCa1l7LcpB8gPI3GQ0s,LDzN7Th80vAG)
	else: GwL9s6vAgzS0naR5Yc7ETm2xFO.update(c8RuAmF1yHI4tvZDPjiTq,Z0fFKNy67w+WmaPChRdQk3YcXwI6zS(u"ࠪࡠࡳ࠭ᄓ")+qY9zWCa1l7LcpB8gPI3GQ0s+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡡࡴࠧᄔ")+LDzN7Th80vAG)
	return
def Dy9cvU05WMY(x9AlD75zbKLkUECh):
	def NBxdC1pkKOrvoQq4yHFauRP8DtLYI(gHhVvzPqOmTK2,HHJgKtT3a5Ew62oIAvxLk,pQaB26KhDi3OoFqyuMsjkJUX=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧᄕ")):
		return ((gHhVvzPqOmTK2 == g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶ᙁ")) and pQaB26KhDi3OoFqyuMsjkJUX[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶ᙁ")]) or (NBxdC1pkKOrvoQq4yHFauRP8DtLYI(gHhVvzPqOmTK2 // HHJgKtT3a5Ew62oIAvxLk, HHJgKtT3a5Ew62oIAvxLk, pQaB26KhDi3OoFqyuMsjkJUX).lstrip(pQaB26KhDi3OoFqyuMsjkJUX[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶ᙁ")]) + pQaB26KhDi3OoFqyuMsjkJUX[gHhVvzPqOmTK2 % HHJgKtT3a5Ew62oIAvxLk])
	def Woly2kIVsH80jcZL1TBmqwAuDa95vi(hGry2vzcACpeB, yy8YXhNF3Un6AewzDS, ZonORjX61Mm, jNqARDk5G8ieTau9xwO, saLhZVE2PxqnSWDJfO7yT1UI=None, WnLsKcpfaYR2ZrJ9GotbVMv=None, QFiEgPbtKj=None):
		while (ZonORjX61Mm):
			ZonORjX61Mm-=N9olEh0ZMtpOivVfBLK(u"࠱ᙂ")
			if (jNqARDk5G8ieTau9xwO[ZonORjX61Mm]): hGry2vzcACpeB = T072lCzjYiuaeFtmJGV.sub(VOq8Ekue4F(u"ࠨ࡜࡝ࡤࠥᄖ") + NBxdC1pkKOrvoQq4yHFauRP8DtLYI(ZonORjX61Mm, yy8YXhNF3Un6AewzDS) + N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠢ࡝࡞ࡥࠦᄗ"),  jNqARDk5G8ieTau9xwO[ZonORjX61Mm], hGry2vzcACpeB)
		return hGry2vzcACpeB
	x9AlD75zbKLkUECh = x9AlD75zbKLkUECh.split(l5mQdjWyczr7UJVnTp(u"ࠨࡿࠫࠫᄘ"))[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠲ᙃ")]
	x9AlD75zbKLkUECh = x9AlD75zbKLkUECh.rsplit(HVibA2ES8lY(u"ࠩࡶࡴࡱ࡯ࡴࠨᄙ"))[ttOu147wErcBvPaSMUY(u"࠲ᙄ")]+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠥࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠩࠣᄚ")
	IwglpjXx0hoi1kLPCA = eval(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡺࡴࡰࡢࡥ࡮ࠬࠬᄛ")+x9AlD75zbKLkUECh,{EmK3ObA0cwv9Wy(u"ࠬࡨࡡࡴࡧࡑࠫᄜ"):NBxdC1pkKOrvoQq4yHFauRP8DtLYI,HVibA2ES8lY(u"࠭ࡵ࡯ࡲࡤࡧࡰ࠭ᄝ"):Woly2kIVsH80jcZL1TBmqwAuDa95vi})
	return IwglpjXx0hoi1kLPCA
def rd1CAlONqnV2Hc3(gz1flZwncVutokL59RaGS3WeK,vnRO0xeFr5QCuPyaWmUD7Ntso=f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࠨᄞ")):
	if vnRO0xeFr5QCuPyaWmUD7Ntso==Xl3drKyI9HkDiPEf8RTjwu(u"ࠨ࡮ࡲࡻࡪࡸࠧᄟ"): gz1flZwncVutokL59RaGS3WeK = T072lCzjYiuaeFtmJGV.sub(vatyjK4hHAoZJ7rOq2lis(u"ࡴࠪࠩࡠ࠶࠭࠺ࡃ࠰࡞ࡢࢁ࠲ࡾࠩᄠ"),lambda w3AJ6fq89uLYWyPne5v: w3AJ6fq89uLYWyPne5v.group(h5huy6MiXPNfQJF8(u"࠳ᙅ")).lower(),gz1flZwncVutokL59RaGS3WeK)
	elif vnRO0xeFr5QCuPyaWmUD7Ntso==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡹࡵࡶࡥࡳࠩᄡ"): gz1flZwncVutokL59RaGS3WeK = T072lCzjYiuaeFtmJGV.sub(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡥ࠲ࢀ࡝ࡼ࠴ࢀࠫᄢ"),lambda w3AJ6fq89uLYWyPne5v: w3AJ6fq89uLYWyPne5v.group(h5huy6MiXPNfQJF8(u"࠴ᙆ")).upper(),gz1flZwncVutokL59RaGS3WeK)
	return gz1flZwncVutokL59RaGS3WeK
def IYGBRJjmO6n(S4SlZukyYG0AhmvOUoTWDBwrc9d):
	rSTP74dwpKyUtZIRfBE3,ORDdHlLoVB = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡉࡥࡱࡹࡥ᜺"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡉࡥࡱࡹࡥ᜺")
	kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(n3xWSEN58XZl9eFydUmCfs2ArH)
	kC7JunVyQdExXTaB.text_factory = str
	SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
	if len(S4SlZukyYG0AhmvOUoTWDBwrc9d)==ZhqJoOtcmTVID65HwnLj(u"࠶ᙇ"): kvsS6E80Vx4giyZm5QIFaGAR3hnM = oAXJCYqPgyGDtT(u"ࠬ࠮ࠢࠨᄣ")+S4SlZukyYG0AhmvOUoTWDBwrc9d[EmK3ObA0cwv9Wy(u"࠶ᙈ")]+sDiKwnHcSlYFgWCy1Ak(u"࠭ࠢࠪࠩᄤ")
	else: kvsS6E80Vx4giyZm5QIFaGAR3hnM = str(tuple(S4SlZukyYG0AhmvOUoTWDBwrc9d))
	SCnhp2blgkLJrvcqKmXdE.execute(vatyjK4hHAoZJ7rOq2lis(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡢࡦࡧࡳࡳࡏࡄ࠭ࡧࡱࡥࡧࡲࡥࡥࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡍࡓࠦࠧᄥ")+kvsS6E80Vx4giyZm5QIFaGAR3hnM+EEvLoMzFqrlKce(u"ࠨࠢ࠾ࠫᄦ"))
	UNrkdT39f5 = SCnhp2blgkLJrvcqKmXdE.fetchall()
	rs4JmUMwkF7cCRAItLhp9i = {}
	for x7NwSuz5ft4e in S4SlZukyYG0AhmvOUoTWDBwrc9d: rs4JmUMwkF7cCRAItLhp9i[x7NwSuz5ft4e] = (sbgu4D2RFMYKm(u"ࡊࡦࡲࡳࡦ᜻"),sbgu4D2RFMYKm(u"ࡊࡦࡲࡳࡦ᜻"))
	for x7NwSuz5ft4e,ORDdHlLoVB in UNrkdT39f5:
		rSTP74dwpKyUtZIRfBE3 = HVibA2ES8lY(u"࡙ࡸࡵࡦ᜼")
		ORDdHlLoVB = ORDdHlLoVB==Xl3drKyI9HkDiPEf8RTjwu(u"࠱ᙉ")
		rs4JmUMwkF7cCRAItLhp9i[x7NwSuz5ft4e] = (rSTP74dwpKyUtZIRfBE3,ORDdHlLoVB)
	kC7JunVyQdExXTaB.close()
	return rs4JmUMwkF7cCRAItLhp9i
def JOhs5QkibGTnZ0CD9dL(QrXa1M59APiDRvHL6GJOgd7Et4):
	cLCisPE3lX = EEvLoMzFqrlKce(u"ࠩࠪᄧ")
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(QrXa1M59APiDRvHL6GJOgd7Et4):
		xOnG9rbvo6mYRU5y0dKBj = open(QrXa1M59APiDRvHL6GJOgd7Et4,ZhqJoOtcmTVID65HwnLj(u"ࠪࡶࡧ࠭ᄨ")).read()
		if mmIKCGujwM: xOnG9rbvo6mYRU5y0dKBj = xOnG9rbvo6mYRU5y0dKBj.decode(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡺࡺࡦ࠹ࠩᄩ"))
		fxr2C7zTn1BHFs8gVySX = cwiLy4IAVJj0pWCl7FGxokR(h5huy6MiXPNfQJF8(u"ࠬࡪࡩࡤࡶࠪᄪ"),xOnG9rbvo6mYRU5y0dKBj)
		if fxr2C7zTn1BHFs8gVySX:
			cLCisPE3lX = {}
			for TRBlwxbQJUZaKL1s86SIAze in fxr2C7zTn1BHFs8gVySX.keys():
				cLCisPE3lX[TRBlwxbQJUZaKL1s86SIAze] = []
				for beiXSjYGOMpxI7tLNRsH1 in fxr2C7zTn1BHFs8gVySX[TRBlwxbQJUZaKL1s86SIAze]:
					otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = EEvLoMzFqrlKce(u"࠭ࠧᄫ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨᄬ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠩᄭ"),N9olEh0ZMtpOivVfBLK(u"ࠩࠪᄮ"),vatyjK4hHAoZJ7rOq2lis(u"ࠪࠫᄯ"),ZEiR0StquOzca9lvPAndYIX(u"ࠫࠬᄰ"),EEvLoMzFqrlKce(u"ࠬ࠭ᄱ"),sbgu4D2RFMYKm(u"࠭ࠧᄲ"),HH4JMrUDp3lq6hQ(u"ࠧࠨᄳ")
					otciIUKlyb6 = beiXSjYGOMpxI7tLNRsH1[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠱ᙊ")]
					eENPgSDsKvOH24QpIbGjZtwnYoFl = beiXSjYGOMpxI7tLNRsH1[vatyjK4hHAoZJ7rOq2lis(u"࠳ᙋ")]
					eENPgSDsKvOH24QpIbGjZtwnYoFl = nhuP4q9F1lmRIjdHUBWaQg(eENPgSDsKvOH24QpIbGjZtwnYoFl)
					gz1flZwncVutokL59RaGS3WeK = beiXSjYGOMpxI7tLNRsH1[f5uqIoSJzWBOFyrY78RXmVb(u"࠵ᙌ")]
					DkjbIhZoVd7F52r6Ew = beiXSjYGOMpxI7tLNRsH1[TWexH5PhS1(u"࠷ᙍ")]
					BB5dqMe8jgLxwSvk = beiXSjYGOMpxI7tLNRsH1[Xl3drKyI9HkDiPEf8RTjwu(u"࠹ᙎ")]
					ffGe7cURW0lhJVvQAiw8IB = beiXSjYGOMpxI7tLNRsH1[sDiKwnHcSlYFgWCy1Ak(u"࠻ᙏ")]
					if len(beiXSjYGOMpxI7tLNRsH1)>vatyjK4hHAoZJ7rOq2lis(u"࠶ᙐ"): BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = beiXSjYGOMpxI7tLNRsH1[vatyjK4hHAoZJ7rOq2lis(u"࠶ᙐ")]
					if len(beiXSjYGOMpxI7tLNRsH1)>cbngtp9sqYi0DjeEMLRHJruKxm(u"࠸ᙑ"): ytsdYhu8qpWc6nwJlDr32bBPmj = beiXSjYGOMpxI7tLNRsH1[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠸ᙑ")]
					if len(beiXSjYGOMpxI7tLNRsH1)>weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠺ᙒ"): RLg3NjAdqfTMl = beiXSjYGOMpxI7tLNRsH1[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠺ᙒ")]
					if QrXa1M59APiDRvHL6GJOgd7Et4==Yy5epgPqo7D2vT4mQREiuX: VRrnEH2F0mu8U1asA = otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,N9olEh0ZMtpOivVfBLK(u"ࠨࠩᄴ"),RLg3NjAdqfTMl
					else: VRrnEH2F0mu8U1asA = otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl
					cLCisPE3lX[TRBlwxbQJUZaKL1s86SIAze].append(VRrnEH2F0mu8U1asA)
		gmoEyP1szUOAFwfMdDGhXxb7W = str(cLCisPE3lX)
		if mmIKCGujwM: gmoEyP1szUOAFwfMdDGhXxb7W = gmoEyP1szUOAFwfMdDGhXxb7W.encode(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡸࡸ࡫࠾ࠧᄵ"))
		open(QrXa1M59APiDRvHL6GJOgd7Et4,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡻࡧ࠭ᄶ")).write(gmoEyP1szUOAFwfMdDGhXxb7W)
	return cLCisPE3lX
def F9CkIURDtc3wy2N8z5VdLuH7p(vuyTFsAd72wDBiUPSnft5obMjErR6):
	vPrO2AUg5Qoql0 = vuyTFsAd72wDBiUPSnft5obMjErR6.split(ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠲࠭ᄷ"),vatyjK4hHAoZJ7rOq2lis(u"࠴ᙓ"))[N9olEh0ZMtpOivVfBLK(u"࠴ᙔ")]
	VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬ࠭ᄸ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠧᄹ"),EEvLoMzFqrlKce(u"ࠧࠨᄺ")
	if   vPrO2AUg5Qoql0==EmK3ObA0cwv9Wy(u"ࠨࡃࡋ࡛ࡆࡑࠧᄻ")		:	from GEOZPCczq3			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡄࡏࡔࡇࡍࠨᄼ")		:	from zzSmHfGRh1			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==HH4JMrUDp3lq6hQ(u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬᄽ")	:	from sp0ci7URFg		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==VOq8Ekue4F(u"ࠫࡆࡑࡗࡂࡏࠪᄾ")		:	from IqinpDkyKl			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==EEvLoMzFqrlKce(u"ࠬࡇࡌࡂࡔࡄࡆࠬᄿ")	:	from K836yHGimB			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨᅀ")	:	from EbluyZW5LI		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==TWexH5PhS1(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪᅁ")	: 	from kkITS5N91U		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪᅂ")	:	from GgVQnpyiCL		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧᅃ"):	from XT3uYtnVfO	import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬᅄ")	:	from vCtl0ns45z		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡇࡕࡋࡓࡃࠪᅅ")		:	from MJgi5GqtY1			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==N9olEh0ZMtpOivVfBLK(u"ࠬࡈࡒࡔࡖࡈࡎࠬᅆ")	:	from TrcyRUH3vi			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==ttOu147wErcBvPaSMUY(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧᅇ")	:	from ERBPf8ATQn		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᅈ")	:	from BLdv9gUfaA			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==VOq8Ekue4F(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪᅉ")	:	from wBonpRSNeM		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨᅊ"):	from Nf7bUWmz6O	import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==FIHNSc5iuoZanQ2Ytl(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬᅋ"):		from LHZqFm32BY		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭ᅌ")	:	from l5liAXKZoO		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧᅍ")	:	from s2mgB7XGTt		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==HH4JMrUDp3lq6hQ(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᅎ")	:	from IzDwgOdRve		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨᅏ")	:	from coLpZ1IUQX		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==ZEiR0StquOzca9lvPAndYIX(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ᅐ"):	from LEZ1hMoasH	import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==ttOu147wErcBvPaSMUY(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪᅑ")	:	from FEh0iRAMns		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==WmaPChRdQk3YcXwI6zS(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫᅒ")	:	from gGTiHbNksh		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==HVibA2ES8lY(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ᅓ")	:	from TgIVM3sG2w		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==EEvLoMzFqrlKce(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧᅔ")	:	from PP1JntxOQD		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==sDiKwnHcSlYFgWCy1Ak(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨᅕ")	:	from MM7Ygkxlt3		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==EEvLoMzFqrlKce(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩᅖ")	:	from PnNvU5y6ZL		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩᅗ")	:	from yyYVjqbT8o		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩᅘ")	:	from eJK6akm4Wr			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫᅙ")	:	from qbRa5OA9mK		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧᅚ")	:	from N2LfsEFw0l		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==HVibA2ES8lY(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧᅛ")	:	from gC4dqk9SLB		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==ttOu147wErcBvPaSMUY(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨᅜ")	:	from yyCXvj7tkU		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡇࡑࡖࡘࡆ࠭ᅝ")		:	from m2lN5dr0pP			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==oAXJCYqPgyGDtT(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪᅞ")	:	from isINJdkS0c		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࡌࡊࡎࡒࡍࠨᅟ")		:	from Ur91T3bdnp			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡍࡕ࡚ࡖࠨᅠ")		:	from ll13jcxerk	import HbNpCDWgIQywk12ucivJXm4UqZ as VVN1EA7KFvGSq,RYW8dS3E1GVjzsLPcku as c0a1XqysA6duSxvCH9Twi2bD,I5ZiQhtuXSmd96BNLoPwGU as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==sbgu4D2RFMYKm(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧᅡ")	:	from dCaTxDr5ny		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==h5huy6MiXPNfQJF8(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧᅢ")	:	from siVGafBrbO		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==HVibA2ES8lY(u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨᅣ")	:	from g96gjGpAJ0		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==sbgu4D2RFMYKm(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧᅤ")	:	from xtZ9DkcH7d			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==FIHNSc5iuoZanQ2Ytl(u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩᅥ")	:	from BBSGVEY06O		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡐ࠷࡚࠭ᅦ")		:	from DqKuc961xM	import HbNpCDWgIQywk12ucivJXm4UqZ as VVN1EA7KFvGSq,RYW8dS3E1GVjzsLPcku as c0a1XqysA6duSxvCH9Twi2bD,I5ZiQhtuXSmd96BNLoPwGU as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪᅧ")	:	from RebLZS85Mr			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡒ࡟ࡃࡊࡏࡄࠫᅨ")	:	from JZ9alXQ134			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==sDiKwnHcSlYFgWCy1Ak(u"ࠬࡖࡁࡏࡇࡗࠫᅩ")		:	from bapyhOnfBF			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==sbgu4D2RFMYKm(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨᅪ")	:	from DIHBeTNura		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==vatyjK4hHAoZJ7rOq2lis(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫᅫ"):	from Z23NoP4Rdg		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==TWexH5PhS1(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫᅬ")	:	from ugn3FVAUmb		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡖࡌࡔࡌࡈࡂࠩᅭ")	:	from hCe8APomMv			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬᅮ")	:	from ovKfrHj8bu		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==N9olEh0ZMtpOivVfBLK(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ᅯ")	:	from ZW6geGYkMJ		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==cbngtp9sqYi0DjeEMLRHJruKxm(u"࡚ࠬࡖࡇࡗࡑࠫᅰ")		:	from F7tRBq8g52			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==PiFkQ5pCJy7fbX(u"࠭ࡗࡆࡅࡌࡑࡆ࠭ᅱ")	:	from aNYf1hSZV0			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࡚ࠧࡃࡔࡓ࡙࠭ᅲ")		:	from FXdQ6O4EWN			import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==N9olEh0ZMtpOivVfBLK(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩᅳ")	:	from sSG0U5DEax		import lD8xr3zag19KuC as VVN1EA7KFvGSq,CXz8MpZeQigHAjw47TlbhdcPYoaWG as c0a1XqysA6duSxvCH9Twi2bD,JJCLnkX4TozH7Bsjivfe as GhPbjTIufD1JQMgEHSY4LqzAac
	elif vPrO2AUg5Qoql0==f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨᅴ"):	from iN7I2Kvdet	import lD8xr3zag19KuC as VVN1EA7KFvGSq
	return VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac
def de5ZW2bFQ64CPgG(WLmJboYtCkPlF3,YYmX6s9ieC4N3TuoVxnRApZ,showDialogs):
	GZvEITHSg5U3rVwQ(h5huy6MiXPNfQJF8(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᅵ"),WmaPChRdQk3YcXwI6zS(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫࠿࡛ࠦࠡࠩᅶ")+WLmJboYtCkPlF3+sDiKwnHcSlYFgWCy1Ak(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨᅷ")+str(YYmX6s9ieC4N3TuoVxnRApZ)+VH9MDo5z1kxNF07uRJI(u"࠭ࠠ࡞ࠩᅸ"))
	GwL9s6vAgzS0naR5Yc7ETm2xFO = RNrYlESg2f0OLJnG7wQ()
	GwL9s6vAgzS0naR5Yc7ETm2xFO.create(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᅹ"),h5huy6MiXPNfQJF8(u"ࠨ์ฯี๏ࠦวๅฤ้ࠤๆำีࠡษ็้้็ࠠศๆ่฻้๎ศࠡฬะ้๏๊็๊ࠡห฽ิํวࠡี๋ๅࠥะศะลࠣ฽๊๊๊สࠢฯ่อࠦวๅ็็ๅ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪᅺ"))
	o14XhPQE6gpbnk = mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶࠶࠲࠵ᙕ")*mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶࠶࠲࠵ᙕ")
	hKQ6Wgia2DBZ = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷ᙖ")*o14XhPQE6gpbnk
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.get(WLmJboYtCkPlF3,stream=N0Kvne8UYar9fhRxboWsXJCVzid(u"࡚ࡲࡶࡧ᜽"),headers=YYmX6s9ieC4N3TuoVxnRApZ)
	g1xDMjrKAqi5WQFRe7uPIET = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.headers
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt.close()
	oPaXeEdfvjVgTnmZwqJk = bytes()
	if not g1xDMjrKAqi5WQFRe7uPIET:
		if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࠪᅻ"),oAXJCYqPgyGDtT(u"ࠪࠫᅼ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᅽ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨᅾ"))
		GwL9s6vAgzS0naR5Yc7ETm2xFO.close()
	else:
		if h5huy6MiXPNfQJF8(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧᅿ") not in list(g1xDMjrKAqi5WQFRe7uPIET.keys()): scCqF6wYJzPr9bH3L1pgAMXax = f5uqIoSJzWBOFyrY78RXmVb(u"࠰ᙗ")
		else: scCqF6wYJzPr9bH3L1pgAMXax = int(g1xDMjrKAqi5WQFRe7uPIET[mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨᆀ")])
		WWVcIMHwjXanC0qOJ = str(int(oAXJCYqPgyGDtT(u"࠳࠳࠴࠵ᙙ")*scCqF6wYJzPr9bH3L1pgAMXax/o14XhPQE6gpbnk)/BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠲࠲࠳࠴࠳࠶ᙘ"))
		zhYRHq4NmT = int(scCqF6wYJzPr9bH3L1pgAMXax/hKQ6Wgia2DBZ)+l5mQdjWyczr7UJVnTp(u"࠴ᙚ")
		if f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡕࡥࡳ࡭ࡥࠨᆁ") in list(g1xDMjrKAqi5WQFRe7uPIET.keys()) and scCqF6wYJzPr9bH3L1pgAMXax>o14XhPQE6gpbnk:
			qDWVIKtHb8Ma9CAN4vwl = EEvLoMzFqrlKce(u"ࡔࡳࡷࡨ᜾")
			FdpftSPzHL1T = []
			qX3EdTvAbBQY16gaPL5ieRcwu8nO4C = f5uqIoSJzWBOFyrY78RXmVb(u"࠵࠵ᙛ")
			FdpftSPzHL1T.append(str(f5uqIoSJzWBOFyrY78RXmVb(u"࠶ᙝ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+h5huy6MiXPNfQJF8(u"ࠩ࠰ࠫᆂ")+str(PiFkQ5pCJy7fbX(u"࠶ᙜ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-PiFkQ5pCJy7fbX(u"࠶ᙜ")))
			FdpftSPzHL1T.append(str(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠱ᙞ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪ࠱ࠬᆃ")+str(WmaPChRdQk3YcXwI6zS(u"࠳ᙟ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠱ᙞ")))
			FdpftSPzHL1T.append(str(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶ᙢ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+ZhqJoOtcmTVID65HwnLj(u"ࠫ࠲࠭ᆄ")+str(VOq8Ekue4F(u"࠶ᙡ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳ᙠ")))
			FdpftSPzHL1T.append(str(HH4JMrUDp3lq6hQ(u"࠹ᙤ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠳ࠧᆅ")+str(sbgu4D2RFMYKm(u"࠴ᙥ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠶ᙣ")))
			FdpftSPzHL1T.append(str(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠷ᙨ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+FIHNSc5iuoZanQ2Ytl(u"࠭࠭ࠨᆆ")+str(EmK3ObA0cwv9Wy(u"࠷ᙧ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-PiFkQ5pCJy7fbX(u"࠲ᙦ")))
			FdpftSPzHL1T.append(str(TWexH5PhS1(u"࠺ᙪ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+f5uqIoSJzWBOFyrY78RXmVb(u"ࠧ࠮ࠩᆇ")+str(EmK3ObA0cwv9Wy(u"࠼ᙫ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-EEvLoMzFqrlKce(u"࠵ᙩ")))
			FdpftSPzHL1T.append(str(vatyjK4hHAoZJ7rOq2lis(u"࠸᙮")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+l5mQdjWyczr7UJVnTp(u"ࠨ࠯ࠪᆈ")+str(vatyjK4hHAoZJ7rOq2lis(u"࠸᙭")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠱ᙬ")))
			FdpftSPzHL1T.append(str(sDiKwnHcSlYFgWCy1Ak(u"࠼ᙱ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+WmaPChRdQk3YcXwI6zS(u"ࠩ࠰ࠫᆉ")+str(ZEiR0StquOzca9lvPAndYIX(u"࠼ᙰ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-TWexH5PhS1(u"࠴ᙯ")))
			FdpftSPzHL1T.append(str(oAXJCYqPgyGDtT(u"࠸ᙳ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+HVibA2ES8lY(u"ࠪ࠱ࠬᆊ")+str(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠿ᙲ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C-N9olEh0ZMtpOivVfBLK(u"࠲ᙴ")))
			FdpftSPzHL1T.append(str(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠻ᙵ")*scCqF6wYJzPr9bH3L1pgAMXax//qX3EdTvAbBQY16gaPL5ieRcwu8nO4C)+ttOu147wErcBvPaSMUY(u"ࠫ࠲࠭ᆋ"))
			bxmycC30slF8JWjKN2ApwaUGdV = float(zhYRHq4NmT)/qX3EdTvAbBQY16gaPL5ieRcwu8nO4C
			Rc9dEINZfOb26KiBqMS4mT7y5G8w = bxmycC30slF8JWjKN2ApwaUGdV/int(VH9MDo5z1kxNF07uRJI(u"࠴ᙶ")+bxmycC30slF8JWjKN2ApwaUGdV)
		else:
			qDWVIKtHb8Ma9CAN4vwl = TWexH5PhS1(u"ࡇࡣ࡯ࡷࡪ᜿")
			qX3EdTvAbBQY16gaPL5ieRcwu8nO4C = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠵ᙷ")
			Rc9dEINZfOb26KiBqMS4mT7y5G8w = FIHNSc5iuoZanQ2Ytl(u"࠶ᙸ")
		GZvEITHSg5U3rVwQ(HH4JMrUDp3lq6hQ(u"ࠬࡔࡏࡕࡋࡆࡉࠬᆌ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭࠮ࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧᆍ")+str(qDWVIKtHb8Ma9CAN4vwl)+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩᆎ")+str(scCqF6wYJzPr9bH3L1pgAMXax)+EmK3ObA0cwv9Wy(u"ࠨࠢࡠࠫᆏ"))
		H3ABEcMzfyqwF4Ug2ZYtK,NKy8Dmjb9oepT = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶ᙹ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶ᙹ")
		for xB1k7v8jIeQ5lfoTDHFPbydm4 in range(qX3EdTvAbBQY16gaPL5ieRcwu8nO4C):
			JKf4Tsxu9S23FI7mV5DGLk = YYmX6s9ieC4N3TuoVxnRApZ.copy()
			if qDWVIKtHb8Ma9CAN4vwl: JKf4Tsxu9S23FI7mV5DGLk[sDiKwnHcSlYFgWCy1Ak(u"ࠩࡕࡥࡳ࡭ࡥࠨᆐ")] = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪᆑ")+FdpftSPzHL1T[xB1k7v8jIeQ5lfoTDHFPbydm4]
			z8zCauMw6AGm7ZRDFO4NeJ0xrLt = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.get(WLmJboYtCkPlF3,stream=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡖࡵࡹࡪᝀ"),headers=JKf4Tsxu9S23FI7mV5DGLk,timeout=N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳࠱࠲ᙺ"))
			for YxgiIhz7jnuTqRN in z8zCauMw6AGm7ZRDFO4NeJ0xrLt.iter_content(chunk_size=hKQ6Wgia2DBZ):
				if GwL9s6vAgzS0naR5Yc7ETm2xFO.iscanceled():
					GZvEITHSg5U3rVwQ(ZEiR0StquOzca9lvPAndYIX(u"ࠫࡓࡕࡔࡊࡅࡈࠫᆒ"),FIHNSc5iuoZanQ2Ytl(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬᆓ"))
					break
				H3ABEcMzfyqwF4Ug2ZYtK += Rc9dEINZfOb26KiBqMS4mT7y5G8w
				oPaXeEdfvjVgTnmZwqJk += YxgiIhz7jnuTqRN
				if not NKy8Dmjb9oepT: NKy8Dmjb9oepT = len(YxgiIhz7jnuTqRN)
				if scCqF6wYJzPr9bH3L1pgAMXax: pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,cbngtp9sqYi0DjeEMLRHJruKxm(u"࠲࠲࠳ᙻ")*H3ABEcMzfyqwF4Ug2ZYtK//zhYRHq4NmT,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᆔ"),str(sbgu4D2RFMYKm(u"࠳࠳࠴࠳࠶ᙼ")*NKy8Dmjb9oepT*H3ABEcMzfyqwF4Ug2ZYtK//hKQ6Wgia2DBZ//sbgu4D2RFMYKm(u"࠳࠳࠴࠳࠶ᙼ"))+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠡ࠱ࠣࠫᆕ")+WWVcIMHwjXanC0qOJ+PiFkQ5pCJy7fbX(u"ࠨࠢࡐࡆࠬᆖ"))
				else: pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,NKy8Dmjb9oepT*H3ABEcMzfyqwF4Ug2ZYtK//hKQ6Wgia2DBZ,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧᆗ"),str(PiFkQ5pCJy7fbX(u"࠴࠴࠵࠴࠰ᙽ")*NKy8Dmjb9oepT*H3ABEcMzfyqwF4Ug2ZYtK//hKQ6Wgia2DBZ//PiFkQ5pCJy7fbX(u"࠴࠴࠵࠴࠰ᙽ"))+oAXJCYqPgyGDtT(u"ࠪࠤࡒࡈࠧᆘ"))
			z8zCauMw6AGm7ZRDFO4NeJ0xrLt.close()
		GwL9s6vAgzS0naR5Yc7ETm2xFO.close()
		if len(oPaXeEdfvjVgTnmZwqJk)<scCqF6wYJzPr9bH3L1pgAMXax and scCqF6wYJzPr9bH3L1pgAMXax>BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠴ᙾ"):
			GZvEITHSg5U3rVwQ(l5mQdjWyczr7UJVnTp(u"ࠫࡓࡕࡔࡊࡅࡈࠫᆙ"),FIHNSc5iuoZanQ2Ytl(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣࡳࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡣࡷ࠾ࠥࡡࠠࠨᆚ")+str(len(oPaXeEdfvjVgTnmZwqJk)//o14XhPQE6gpbnk)+sbgu4D2RFMYKm(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇࡴࡲࡱࠥࡺ࡯ࡵࡣ࡯ࠤࡴ࡬࠺ࠡ࡝ࠣࠫᆛ")+WWVcIMHwjXanC0qOJ+TWexH5PhS1(u"ࠧࠡࡏࡅࠤࡢ࠭ᆜ"))
			ElsZrgRneL = GNX3qVRf4oBdtkEi5u(ZEiR0StquOzca9lvPAndYIX(u"ࠨࠩᆝ"),VOq8Ekue4F(u"ࠩศ่฿อม๊ࠡัีําࠧᆞ"),N9olEh0ZMtpOivVfBLK(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪᆟ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭ᆠ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆡ"),ZhqJoOtcmTVID65HwnLj(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪᆢ")+str(len(oPaXeEdfvjVgTnmZwqJk)//o14XhPQE6gpbnk)+VH9MDo5z1kxNF07uRJI(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭ᆣ")+WWVcIMHwjXanC0qOJ+Xl3drKyI9HkDiPEf8RTjwu(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪᆤ"))
			if ElsZrgRneL==ZEiR0StquOzca9lvPAndYIX(u"࠷ᙿ"): oPaXeEdfvjVgTnmZwqJk = de5ZW2bFQ64CPgG(WLmJboYtCkPlF3,YYmX6s9ieC4N3TuoVxnRApZ,showDialogs)
			elif ElsZrgRneL==PiFkQ5pCJy7fbX(u"࠷ "): GZvEITHSg5U3rVwQ(HH4JMrUDp3lq6hQ(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᆥ"),EEvLoMzFqrlKce(u"ࠪ࠲ࠥࠦࡎࡰࡶࠣࡧࡴࡳࡰ࡭ࡧࡷࡩࡩࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡦࡩࡣࡦࡲࡷࡩࡩࠦࡡ࡯ࡦࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡥࠩᆦ"))
			else: return vatyjK4hHAoZJ7rOq2lis(u"ࠫࠬᆧ")
			if not oPaXeEdfvjVgTnmZwqJk: return WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬ࠭ᆨ")
		else: GZvEITHSg5U3rVwQ(WmaPChRdQk3YcXwI6zS(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᆩ"),ZhqJoOtcmTVID65HwnLj(u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᆪ")+WWVcIMHwjXanC0qOJ+N9olEh0ZMtpOivVfBLK(u"ࠨࠢࡐࡆࠥࡣࠧᆫ"))
	return oPaXeEdfvjVgTnmZwqJk
def SShWj48NoAZcrwKXlxYM1J(nO6ukabcldeU):
	return z8zCauMw6AGm7ZRDFO4NeJ0xrLt
def EAeKCYbwXqJRODh3vyxB(ip=N9olEh0ZMtpOivVfBLK(u"ࠩࠪᆬ")):
	OY9gt5P86ih3dDLafuKpzMIkT7SFoB,jOxCyaFu0HoKVPi425htBsvmgGJe,VkcnM8DGbt1ZaHvUCzK40FTLXq,PM5K8I7gzxADZ1UE,zUjlB7OT5b0WC8i4RmcFatEyrHnhd,bb9uoNpWEqSVt7CcIw3iGXlhPneMvm = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࠫᆭ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࠬᆮ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠬ࠭ᆯ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠧᆰ"),sDiKwnHcSlYFgWCy1Ak(u"ࠧࠨᆱ"),EmK3ObA0cwv9Wy(u"ࠨࠩᆲ")
	gz1flZwncVutokL59RaGS3WeK = h5huy6MiXPNfQJF8(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬᆳ")+ip+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨᆴ")
	YYmX6s9ieC4N3TuoVxnRApZ = {FIHNSc5iuoZanQ2Ytl(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᆵ"):QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࠭ᆶ")}
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡇࡆࡖࠪᆷ"),gz1flZwncVutokL59RaGS3WeK,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨᆸ"),YYmX6s9ieC4N3TuoVxnRApZ,ZEiR0StquOzca9lvPAndYIX(u"ࠨࠩᆹ"),WmaPChRdQk3YcXwI6zS(u"ࠩࠪᆺ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭ᆻ"))
	if not z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded: VTknBvs0QNLUOGr7h9wZ = ip+sDiKwnHcSlYFgWCy1Ak(u"ࠫ࠱࠭ᆼ")+OY9gt5P86ih3dDLafuKpzMIkT7SFoB+FIHNSc5iuoZanQ2Ytl(u"ࠬ࠲ࠧᆽ")+jOxCyaFu0HoKVPi425htBsvmgGJe+h5huy6MiXPNfQJF8(u"࠭ࠬࠨᆾ")+PM5K8I7gzxADZ1UE+WmaPChRdQk3YcXwI6zS(u"ࠧ࠭ࠩᆿ")+zUjlB7OT5b0WC8i4RmcFatEyrHnhd+HVibA2ES8lY(u"ࠨ࠮ࠪᇀ")+bb9uoNpWEqSVt7CcIw3iGXlhPneMvm
	else:
		KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
		KLxMkaVlguvqPcF = T072lCzjYiuaeFtmJGV.findall(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩ࡟ࡿ࠳࠰࠿࡝ࡿ࡟ࢁࠬᇁ"),KLxMkaVlguvqPcF,T072lCzjYiuaeFtmJGV.DOTALL)
		if KLxMkaVlguvqPcF:
			KLxMkaVlguvqPcF = KLxMkaVlguvqPcF[sbgu4D2RFMYKm(u"࠰ᚁ")]
			dWKgFucQMaRxeVmS6 = cwiLy4IAVJj0pWCl7FGxokR(FIHNSc5iuoZanQ2Ytl(u"ࠪࡨ࡮ࡩࡴࠨᇂ"),KLxMkaVlguvqPcF)
			ZTz57Ybn0Jgm = list(dWKgFucQMaRxeVmS6.keys())
			if sbgu4D2RFMYKm(u"ࠫ࡮ࡶࠧᇃ") in ZTz57Ybn0Jgm: ip = dWKgFucQMaRxeVmS6[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬ࡯ࡰࠨᇄ")]
			if S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᇅ") in ZTz57Ybn0Jgm: OY9gt5P86ih3dDLafuKpzMIkT7SFoB = dWKgFucQMaRxeVmS6[Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪᇆ")]
			if l5mQdjWyczr7UJVnTp(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᇇ") in ZTz57Ybn0Jgm: jOxCyaFu0HoKVPi425htBsvmgGJe = dWKgFucQMaRxeVmS6[WmaPChRdQk3YcXwI6zS(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᇈ")]
			if QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᇉ") in ZTz57Ybn0Jgm: VkcnM8DGbt1ZaHvUCzK40FTLXq = dWKgFucQMaRxeVmS6[EEvLoMzFqrlKce(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪᇊ")]
			if oAXJCYqPgyGDtT(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᇋ") in ZTz57Ybn0Jgm: PM5K8I7gzxADZ1UE = dWKgFucQMaRxeVmS6[N9olEh0ZMtpOivVfBLK(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ᇌ")]
			if uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࡤ࡫ࡷࡽࠬᇍ") in ZTz57Ybn0Jgm: zUjlB7OT5b0WC8i4RmcFatEyrHnhd = dWKgFucQMaRxeVmS6[N9olEh0ZMtpOivVfBLK(u"ࠨࡥ࡬ࡸࡾ࠭ᇎ")]
			if sbgu4D2RFMYKm(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᇏ") in ZTz57Ybn0Jgm:
				bb9uoNpWEqSVt7CcIw3iGXlhPneMvm = dWKgFucQMaRxeVmS6[vatyjK4hHAoZJ7rOq2lis(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬᇐ")][N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡺࡺࡣࠨᇑ")]
				if bb9uoNpWEqSVt7CcIw3iGXlhPneMvm[ZhqJoOtcmTVID65HwnLj(u"࠱ᚂ")] not in [vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࠳ࠧᇒ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࠫࠨᇓ")]: bb9uoNpWEqSVt7CcIw3iGXlhPneMvm = ZhqJoOtcmTVID65HwnLj(u"ࠧࠬࠩᇔ")+bb9uoNpWEqSVt7CcIw3iGXlhPneMvm
			VTknBvs0QNLUOGr7h9wZ = ip+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨ࠮ࠪᇕ")+OY9gt5P86ih3dDLafuKpzMIkT7SFoB+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࠯ࠫᇖ")+jOxCyaFu0HoKVPi425htBsvmgGJe+ZEiR0StquOzca9lvPAndYIX(u"ࠪ࠰ࠬᇗ")+PM5K8I7gzxADZ1UE+N9olEh0ZMtpOivVfBLK(u"ࠫ࠱࠭ᇘ")+zUjlB7OT5b0WC8i4RmcFatEyrHnhd+EEvLoMzFqrlKce(u"ࠬ࠲ࠧᇙ")+bb9uoNpWEqSVt7CcIw3iGXlhPneMvm
			if mmIKCGujwM: VTknBvs0QNLUOGr7h9wZ = VTknBvs0QNLUOGr7h9wZ.encode(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡵࡵࡨ࠻ࠫᇚ")).decode(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨᇛ"))
	VTknBvs0QNLUOGr7h9wZ = Bd2o0J6aOASWvuD9HzY(VTknBvs0QNLUOGr7h9wZ)
	return VTknBvs0QNLUOGr7h9wZ
def o0Vixfg9ANze1OshdmaX(rc1H6zfLwjR4VQx7dTsbv8):
	FtLHmTODvV,showDialogs = Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࠩᇜ"),WmaPChRdQk3YcXwI6zS(u"ࡗࡶࡺ࡫ᝁ")
	if rc1H6zfLwjR4VQx7dTsbv8.count(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡢࠫᇝ"))>=N9olEh0ZMtpOivVfBLK(u"࠴ᚃ"):
		rc1H6zfLwjR4VQx7dTsbv8,FtLHmTODvV = rc1H6zfLwjR4VQx7dTsbv8.split(ZhqJoOtcmTVID65HwnLj(u"ࠪࡣࠬᇞ"),HH4JMrUDp3lq6hQ(u"࠴ᚄ"))
		FtLHmTODvV = sDiKwnHcSlYFgWCy1Ak(u"ࠫࡤ࠭ᇟ")+FtLHmTODvV
		if ZEiR0StquOzca9lvPAndYIX(u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪᇠ") in FtLHmTODvV: showDialogs = N9olEh0ZMtpOivVfBLK(u"ࡊࡦࡲࡳࡦᝂ")
		else: showDialogs = N0Kvne8UYar9fhRxboWsXJCVzid(u"࡙ࡸࡵࡦᝃ")
	return rc1H6zfLwjR4VQx7dTsbv8,FtLHmTODvV,showDialogs
def APxF1loHQnaCzMZqGrcT7O():
	AtCixIG4HuhL7wbUm2vc = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,TWexH5PhS1(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬᇡ"))
	dIE8vyse3xYfKG79RWZl = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠴ᚅ")
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(AtCixIG4HuhL7wbUm2vc):
		for qK2aImeBfl98EgMDQ in isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(AtCixIG4HuhL7wbUm2vc):
			if FIHNSc5iuoZanQ2Ytl(u"ࠧ࠯ࡲࡼࡳࠬᇢ") in qK2aImeBfl98EgMDQ: continue
			if sDiKwnHcSlYFgWCy1Ak(u"ࠨࡡࡢࡴࡾࡩࡡࡤࡪࡨࡣࡤ࠭ᇣ") in qK2aImeBfl98EgMDQ: continue
			AJ6Vz7qy4rYpcm9HhGotsB = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(AtCixIG4HuhL7wbUm2vc,qK2aImeBfl98EgMDQ)
			d0dafJYyF4P6GLs,TnOEcKMSxN = qtKQXi2C9V7JrEyWD61Lns(AJ6Vz7qy4rYpcm9HhGotsB)
			dIE8vyse3xYfKG79RWZl += d0dafJYyF4P6GLs
	return dIE8vyse3xYfKG79RWZl
def ktfQu3jy0hq5mTC4RON(jDSoFcA19T,showDialogs):
	myL3ZBkPKI0tA = YTPut68WBVUNCvsEzg.getSetting(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧᇤ"))
	Xmqocj4C2azOUG = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,ZhqJoOtcmTVID65HwnLj(u"ࠪࡷࡹࡸࠧᇥ"),TWexH5PhS1(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᇦ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧᇧ"))
	an9qvoxPBHNIYkQOcj6e0rh5SlVy,fUc5Pa4bdGARWso0iFTw7M = myL3ZBkPKI0tA,Xmqocj4C2azOUG
	GRPxp98gvD3sqOIJ1w,xgaZRVP79e = mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࠧᇨ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࠨᇩ")
	if not jDSoFcA19T or not Xmqocj4C2azOUG or myL3ZBkPKI0tA in [FIHNSc5iuoZanQ2Ytl(u"ࠨࠩᇪ"),VOq8Ekue4F(u"ࠩࡈࡖࡗࡕࡒࠨᇫ")]:
		gz1flZwncVutokL59RaGS3WeK = tOnYIHVk4xydqwoLEBKiDN0hX[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᇬ")][ZhqJoOtcmTVID65HwnLj(u"࠸ᚆ")]
		mXzxhH68tSFg = au8Umt9dq1KLSYb(cbngtp9sqYi0DjeEMLRHJruKxm(u"࠹࠲ᚇ"),jDSoFcA19T)
		VTknBvs0QNLUOGr7h9wZ = EAeKCYbwXqJRODh3vyxB()
		jOxCyaFu0HoKVPi425htBsvmgGJe = VTknBvs0QNLUOGr7h9wZ.split(ZEiR0StquOzca9lvPAndYIX(u"ࠫ࠱࠭ᇭ"))[N0Kvne8UYar9fhRxboWsXJCVzid(u"࠲ᚈ")]
		dIE8vyse3xYfKG79RWZl = APxF1loHQnaCzMZqGrcT7O()
		LqWNfDO1dEvxBJih = {EEvLoMzFqrlKce(u"ࠬࡻࡳࡦࡴࠪᇮ"):mXzxhH68tSFg,HVibA2ES8lY(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧᇯ"):pQmoyUJBNaf72A,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᇰ"):jOxCyaFu0HoKVPi425htBsvmgGJe,VOq8Ekue4F(u"ࠨ࡫ࡧࡷࠬᇱ"):zNx5bYlAyeLvtOpXfwK(dIE8vyse3xYfKG79RWZl)}
		z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,vatyjK4hHAoZJ7rOq2lis(u"ࠩࡓࡓࡘ࡚ࠧᇲ"),gz1flZwncVutokL59RaGS3WeK,LqWNfDO1dEvxBJih,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࠫᇳ"),oAXJCYqPgyGDtT(u"ࠫࠬᇴ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬ࠭ᇵ"),Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪᇶ"))
		if not z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded: an9qvoxPBHNIYkQOcj6e0rh5SlVy = HVibA2ES8lY(u"ࠧࡆࡔࡕࡓࡗ࠭ᇷ")
		else:
			XPIQ9iY3Fa = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
			XPIQ9iY3Fa = cwiLy4IAVJj0pWCl7FGxokR(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨ࡮࡬ࡷࡹ࠭ᇸ"),XPIQ9iY3Fa)
			XPIQ9iY3Fa = sorted(XPIQ9iY3Fa,reverse=HH4JMrUDp3lq6hQ(u"࡚ࡲࡶࡧᝄ"),key=lambda key: int(key[ZEiR0StquOzca9lvPAndYIX(u"࠱ᚉ")]))
			xgaZRVP79e,fUc5Pa4bdGARWso0iFTw7M = vatyjK4hHAoZJ7rOq2lis(u"ࠩࠪᇹ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࠫᇺ")
			for k9ktNW4nHzwYoyKp1,djw7rpnLPu8kJVYBQfFaUiC2HO3mD,kg1pK9CEwGaTI0ReMP4crBL8tshHy in XPIQ9iY3Fa:
				if k9ktNW4nHzwYoyKp1==sbgu4D2RFMYKm(u"ࠫ࠵࠭ᇻ"):
					xgaZRVP79e += kg1pK9CEwGaTI0ReMP4crBL8tshHy+oAXJCYqPgyGDtT(u"ࠬࡀ࠺ࠨᇼ")
					continue
				if fUc5Pa4bdGARWso0iFTw7M: fUc5Pa4bdGARWso0iFTw7M += N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧᇽ")
				QN58s1Xkcj62FMrhWpBHn4Kxg = kg1pK9CEwGaTI0ReMP4crBL8tshHy.split(sDiKwnHcSlYFgWCy1Ak(u"ࠧ࡝ࡰࠪᇾ"))[vatyjK4hHAoZJ7rOq2lis(u"࠲ᚊ")]
				olVt7YiMBQIpDFaRdxGL2y6 = EEvLoMzFqrlKce(u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬᇿ") if djw7rpnLPu8kJVYBQfFaUiC2HO3mD else ZhqJoOtcmTVID65HwnLj(u"ࠩࠪሀ")
				fUc5Pa4bdGARWso0iFTw7M += kg1pK9CEwGaTI0ReMP4crBL8tshHy.replace(QN58s1Xkcj62FMrhWpBHn4Kxg,sbgu4D2RFMYKm(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ሁ")+QN58s1Xkcj62FMrhWpBHn4Kxg+olVt7YiMBQIpDFaRdxGL2y6+ZEiR0StquOzca9lvPAndYIX(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ሂ"))+N9olEh0ZMtpOivVfBLK(u"ࠬࡢ࡮ࠨሃ")
			fUc5Pa4bdGARWso0iFTw7M = f5uqIoSJzWBOFyrY78RXmVb(u"࠭࡜࡯ࠩሄ")+fUc5Pa4bdGARWso0iFTw7M+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧ࡝ࡰ࡟ࡲࠬህ")
			xgaZRVP79e = xgaZRVP79e.strip(EEvLoMzFqrlKce(u"ࠨ࠼࠽ࠫሆ"))
			GRPxp98gvD3sqOIJ1w = YTPut68WBVUNCvsEzg.getSetting(VOq8Ekue4F(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶࠫሇ"))
			if fUc5Pa4bdGARWso0iFTw7M!=Xmqocj4C2azOUG or myL3ZBkPKI0tA in [sDiKwnHcSlYFgWCy1Ak(u"ࠪࠫለ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡊࡘࡒࡐࡔࠪሉ")]: an9qvoxPBHNIYkQOcj6e0rh5SlVy = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬࡔࡅࡘࠩሊ")
			rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,FIHNSc5iuoZanQ2Ytl(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩላ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩሌ"),fUc5Pa4bdGARWso0iFTw7M,U6y1OBwzfkEuRGVNrpYFv)
			YTPut68WBVUNCvsEzg.setSetting(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵࠪል"),xgaZRVP79e)
			YTPut68WBVUNCvsEzg.setSetting(ttOu147wErcBvPaSMUY(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪሎ"),zNx5bYlAyeLvtOpXfwK(EEd0FZyfticlDPAMp2HbNesx))
	if showDialogs:
		if an9qvoxPBHNIYkQOcj6e0rh5SlVy==l5mQdjWyczr7UJVnTp(u"ࠪࡉࡗࡘࡏࡓࠩሏ"):
			KK47FGdX1TDfkb3AjHOQqghE(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࠬሐ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬ࠭ሑ"),VOq8Ekue4F(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩሒ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"่่ࠧส็๋ࠥิไๆฬࠤๆ๐ࠠอ้สึ่่่ࠦ์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ัࠦ࠮࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣ๎่๎ๆࠡีหฬ์อࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠศๆิหํะัࠡษ็าฬ฻ࠠษๅࠣวํࠦๅีๅ็อࠥ็๊ࠡษ็วุ๊วไࠢ฼๊ิ้ࠧሓ"))
		else:
			WWZfqplYBUhn6oxiXOmCe24bI0RA9(h5huy6MiXPNfQJF8(u"ࠨࡴ࡬࡫࡭ࡺࠧሔ"),FIHNSc5iuoZanQ2Ytl(u"ࠩิืฬฬไࠡ็้ࠤฬ๊ๅษำ่ะࠥหไ๊่ࠢืฯิฯๆ์ࠣห้ฮั็ษ่ะࠬሕ"),fUc5Pa4bdGARWso0iFTw7M,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫሖ"))
			an9qvoxPBHNIYkQOcj6e0rh5SlVy = sDiKwnHcSlYFgWCy1Ak(u"ࠫࡔࡒࡄࠨሗ")
	if an9qvoxPBHNIYkQOcj6e0rh5SlVy!=myL3ZBkPKI0tA:
		YTPut68WBVUNCvsEzg.setSetting(ZhqJoOtcmTVID65HwnLj(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪመ"),an9qvoxPBHNIYkQOcj6e0rh5SlVy)
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(WmaPChRdQk3YcXwI6zS(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪሙ"))
	pTULMqz73ClkJB19Z62tch0xyv5j = TWexH5PhS1(u"ࡕࡴࡸࡩᝆ") if xgaZRVP79e!=GRPxp98gvD3sqOIJ1w else vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࡆࡢ࡮ࡶࡩᝅ")
	return pTULMqz73ClkJB19Z62tch0xyv5j
def B7k3U2LXMaqP9dEf(YMhlFSnErVXD1,QJEXoC7NbyjHs):
	from socket import socket as b0Y9mt5kN7ezPES,AF_INET as zP8A0c3YCN7oq9ElMdevh,SOCK_STREAM as dxirsWfnmcZVC2vMPtTewlH3RQ
	FOvAJ3zpcwUGhb = b0Y9mt5kN7ezPES(zP8A0c3YCN7oq9ElMdevh,dxirsWfnmcZVC2vMPtTewlH3RQ)
	FOvAJ3zpcwUGhb.settimeout(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠴ᚋ"))
	O4iyumrz1QjMnUDeTk3,erM2FXBN7lH = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡖࡵࡹࡪᝇ"),VH9MDo5z1kxNF07uRJI(u"࠴ᚌ")
	yvuYVFPClBd03mc8 = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
	try: FOvAJ3zpcwUGhb.connect((YMhlFSnErVXD1,QJEXoC7NbyjHs))
	except: O4iyumrz1QjMnUDeTk3 = vatyjK4hHAoZJ7rOq2lis(u"ࡉࡥࡱࡹࡥᝈ")
	uuZoc27DKUW = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
	if O4iyumrz1QjMnUDeTk3: erM2FXBN7lH = uuZoc27DKUW-yvuYVFPClBd03mc8
	return erM2FXBN7lH
def bkfanGl0mAz8hM6(showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠨሚ"),h5huy6MiXPNfQJF8(u"ࠨࠩማ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࠪሜ"),sDiKwnHcSlYFgWCy1Ak(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ም"),FIHNSc5iuoZanQ2Ytl(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪሞ"))
	else: VjwKs4GNQZ518kCl = EmK3ObA0cwv9Wy(u"ࡘࡷࡻࡥᝉ")
	if VjwKs4GNQZ518kCl==HH4JMrUDp3lq6hQ(u"࠶ᚍ"):
		for qK2aImeBfl98EgMDQ in isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(jNhH3xrnWkFUqv8c09OybXRTl):
			if qK2aImeBfl98EgMDQ.endswith(WmaPChRdQk3YcXwI6zS(u"ࠬ࠴ࡤࡣࠩሟ")) and oAXJCYqPgyGDtT(u"࠭ࡤࡢࡶࡤࠫሠ") in qK2aImeBfl98EgMDQ:
				OHuCxbAZaE45jUGwcrpldz3vDBh0qg = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,qK2aImeBfl98EgMDQ)
				try: kC7JunVyQdExXTaB,SCnhp2blgkLJrvcqKmXdE = nIQHkPemMvAWusCczU9ZgY(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
				except: return
				SCnhp2blgkLJrvcqKmXdE.execute(VH9MDo5z1kxNF07uRJI(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪሡ"))
				SCnhp2blgkLJrvcqKmXdE.execute(HH4JMrUDp3lq6hQ(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫሢ"))
				SCnhp2blgkLJrvcqKmXdE.execute(WmaPChRdQk3YcXwI6zS(u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪሣ"))
				kC7JunVyQdExXTaB.commit()
				kC7JunVyQdExXTaB.close()
		if showDialogs:
			KK47FGdX1TDfkb3AjHOQqghE(EEvLoMzFqrlKce(u"ࠪࠫሤ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࠬሥ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨሦ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧሧ"))
	return
def TuLb46ZoWU85Vt3laJGEhvRyIKwrz(axeDMJh9vw1tzAynUjbI,zzUQ7dxGkReYs8,showDialogs):
	if axeDMJh9vw1tzAynUjbI!=None:
		global jsbhMN7iCdH8A2ZEoJK3
		jsbhMN7iCdH8A2ZEoJK3 = axeDMJh9vw1tzAynUjbI
	if zzUQ7dxGkReYs8!=None:
		global wwSb6auEYHQULCO
		wwSb6auEYHQULCO = zzUQ7dxGkReYs8
	if showDialogs!=None:
		global o4BxafMjOdQAP
		o4BxafMjOdQAP = showDialogs
	return
jsbhMN7iCdH8A2ZEoJK3,wwSb6auEYHQULCO,o4BxafMjOdQAP = PiFkQ5pCJy7fbX(u"ࠧࠨረ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩሩ"),sbgu4D2RFMYKm(u"ࠩࠪሪ")
def rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,nnN6lPjWb0xVQqDKwo3,wAT9BZmYf4O5uPgG=WmaPChRdQk3YcXwI6zS(u"ࠪࠫራ"),o48agNivFQYRWsqcSftZP1=ZhqJoOtcmTVID65HwnLj(u"ࠫࠬሬ")):
	global tOnYIHVk4xydqwoLEBKiDN0hX
	if showDialogs==h5huy6MiXPNfQJF8(u"ࠬ࠭ር"): showDialogs = HVibA2ES8lY(u"࡙ࡸࡵࡦᝊ") if o4BxafMjOdQAP==TWexH5PhS1(u"࠭ࠧሮ") else o4BxafMjOdQAP
	if o48agNivFQYRWsqcSftZP1==N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨሯ"): o48agNivFQYRWsqcSftZP1 = FIHNSc5iuoZanQ2Ytl(u"࡚ࡲࡶࡧᝋ") if wwSb6auEYHQULCO==ttOu147wErcBvPaSMUY(u"ࠨࠩሰ") else wwSb6auEYHQULCO
	if wAT9BZmYf4O5uPgG==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࠪሱ"): wAT9BZmYf4O5uPgG = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡔࡳࡷࡨᝌ") if jsbhMN7iCdH8A2ZEoJK3==ZhqJoOtcmTVID65HwnLj(u"ࠪࠫሲ") else jsbhMN7iCdH8A2ZEoJK3
	if J4ETawPbd6==WmaPChRdQk3YcXwI6zS(u"ࠫࠬሳ"): yyJvuD24qMemIR59fH67cZQdE = HVibA2ES8lY(u"ࡕࡴࡸࡩᝍ")
	else: yyJvuD24qMemIR59fH67cZQdE = J4ETawPbd6
	if Z402tBVhQi==None: vf78LSlJQOnCsatrIH2P1iW = None
	elif Z402tBVhQi==f5uqIoSJzWBOFyrY78RXmVb(u"ࠬ࠭ሴ"): vf78LSlJQOnCsatrIH2P1iW = {}
	else: vf78LSlJQOnCsatrIH2P1iW = Z402tBVhQi
	if YYmX6s9ieC4N3TuoVxnRApZ==None: JKf4Tsxu9S23FI7mV5DGLk = None
	elif YYmX6s9ieC4N3TuoVxnRApZ==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧስ"): JKf4Tsxu9S23FI7mV5DGLk = {}
	else: JKf4Tsxu9S23FI7mV5DGLk = YYmX6s9ieC4N3TuoVxnRApZ
	FIz5brNxC0 = list(JKf4Tsxu9S23FI7mV5DGLk.keys())
	if f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫሶ") not in FIz5brNxC0: JKf4Tsxu9S23FI7mV5DGLk[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬሷ")] = TWexH5PhS1(u"ࠩࡃࡄࡅ࡙ࡋࡊࡒࡢࡌࡊࡇࡄࡆࡔࡃࡄࡅ࠭ሸ")
	ll9khUfx3MjZ,xB2HvGaMhZ1u,KzriWR2sPTbwpEeZ,SexFNJLoXtDdpRHws8lZfYEO = hxg062nspYHPSuVKfkdC(gz1flZwncVutokL59RaGS3WeK)
	yySB3TiHgxzsJQKfFmEq92t7V = YTPut68WBVUNCvsEzg.getSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪሹ"))
	mA4tykubSDozlpcdvnP2ihjMZ0XCq = YTPut68WBVUNCvsEzg.getSetting(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧሺ"))
	JnPGZ5EAfV = YTPut68WBVUNCvsEzg.getSetting(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪሻ"))
	CXsNmARywK4p0ZrtVWnbf2xUc = (xB2HvGaMhZ1u==None and KzriWR2sPTbwpEeZ==None)
	mIk8vs2nNUlSDG = tOnYIHVk4xydqwoLEBKiDN0hX[VH9MDo5z1kxNF07uRJI(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ሼ")]
	w13gbecGO5iWK2Fq7r0Y = ll9khUfx3MjZ in mIk8vs2nNUlSDG
	T0BMqytYLaXvHuSpFKg = tOnYIHVk4xydqwoLEBKiDN0hX[oAXJCYqPgyGDtT(u"ࠧࡓࡇࡓࡓࡘ࠭ሽ")]
	F3GQCWU6aIBAHb09S2JKwD7YgZNjx = ll9khUfx3MjZ in T0BMqytYLaXvHuSpFKg
	rrM0AzQYO8Wn5 = w13gbecGO5iWK2Fq7r0Y or F3GQCWU6aIBAHb09S2JKwD7YgZNjx
	if CXsNmARywK4p0ZrtVWnbf2xUc and rrM0AzQYO8Wn5:
		if w13gbecGO5iWK2Fq7r0Y:
			w7nPk6Ku3l52J = mIk8vs2nNUlSDG.index(ll9khUfx3MjZ)
			nnc7vxhiEGDpQfs = tOnYIHVk4xydqwoLEBKiDN0hX[N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬሾ")][w7nPk6Ku3l52J]
			gYHe5zsT3N1lcRIy = uuKXHhOMlYzfQVR[w7nPk6Ku3l52J]
		elif F3GQCWU6aIBAHb09S2JKwD7YgZNjx:
			w7nPk6Ku3l52J = T0BMqytYLaXvHuSpFKg.index(ll9khUfx3MjZ)
			nnc7vxhiEGDpQfs = tOnYIHVk4xydqwoLEBKiDN0hX[HH4JMrUDp3lq6hQ(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬሿ")][w7nPk6Ku3l52J]
			gYHe5zsT3N1lcRIy = ZzyLYF3OidfSkKa79nhPecgjxIJE[w7nPk6Ku3l52J]
	if KzriWR2sPTbwpEeZ==cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࠫቀ"): KzriWR2sPTbwpEeZ = yySB3TiHgxzsJQKfFmEq92t7V
	elif KzriWR2sPTbwpEeZ==None and mA4tykubSDozlpcdvnP2ihjMZ0XCq in [N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡆ࡛ࡔࡐࠩቁ"),VH9MDo5z1kxNF07uRJI(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧቂ")] and wAT9BZmYf4O5uPgG: KzriWR2sPTbwpEeZ = yySB3TiHgxzsJQKfFmEq92t7V
	r9nz0YXobvLF328J6qIWkAQ = ll9khUfx3MjZ==tOnYIHVk4xydqwoLEBKiDN0hX[FIHNSc5iuoZanQ2Ytl(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ቃ")][g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠽ᚎ")]
	afoLXbP3cnp = xB2HvGaMhZ1u and ttOu147wErcBvPaSMUY(u"ࠧࡴࡥࡵࡥࡵ࡫ࠧቄ") in xB2HvGaMhZ1u
	if afoLXbP3cnp: hZYTKSaABQCofcrFlgsI = ZhqJoOtcmTVID65HwnLj(u"࠶࠱ᚏ")
	elif w13gbecGO5iWK2Fq7r0Y or F3GQCWU6aIBAHb09S2JKwD7YgZNjx: hZYTKSaABQCofcrFlgsI = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠲࠷ᚐ")
	elif nnN6lPjWb0xVQqDKwo3 in MyfG164jLWzXKitYQTUqeDvrdSu0F: hZYTKSaABQCofcrFlgsI = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠳࠳ᚑ")
	elif nnN6lPjWb0xVQqDKwo3==VH9MDo5z1kxNF07uRJI(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪቅ"): hZYTKSaABQCofcrFlgsI = oAXJCYqPgyGDtT(u"࠵࠴ᚒ")
	elif nnN6lPjWb0xVQqDKwo3==TWexH5PhS1(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪቆ"): hZYTKSaABQCofcrFlgsI = oAXJCYqPgyGDtT(u"࠶࠵ᚓ")
	elif ttOu147wErcBvPaSMUY(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑࠬቇ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = HVibA2ES8lY(u"࠼࠶ᚔ")
	elif l5mQdjWyczr7UJVnTp(u"ࠫࡘࡎࡏࡇࡊࡄࠫቈ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = vatyjK4hHAoZJ7rOq2lis(u"࠽࠵ᚕ")
	elif mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ቉") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠲࠶ᚖ")
	elif TWexH5PhS1(u"࠭ࡁࡉ࡙ࡄࡏࠬቊ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = FIHNSc5iuoZanQ2Ytl(u"࠳࠲ᚗ")
	elif Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪቋ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = mNkfJnpOrad7hT6PYyciwsSDQ(u"࠴࠳ᚘ")
	elif TWexH5PhS1(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧቌ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = HVibA2ES8lY(u"࠶࠴ᚙ")
	elif mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡄࡏࡔࡇࡍࠨቍ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = f5uqIoSJzWBOFyrY78RXmVb(u"࠶࠺ᚚ")
	elif S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡅࡐ࡝ࡁࡎࠩ቎") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠸࠶᚛")
	elif Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭቏") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = cbngtp9sqYi0DjeEMLRHJruKxm(u"࠸࠰᚜")
	elif S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧቐ") in nnN6lPjWb0xVQqDKwo3: hZYTKSaABQCofcrFlgsI = PiFkQ5pCJy7fbX(u"࠶࠱᚝")
	else: hZYTKSaABQCofcrFlgsI = PiFkQ5pCJy7fbX(u"࠲࠷᚞")
	if ZhqJoOtcmTVID65HwnLj(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨቑ") in nnN6lPjWb0xVQqDKwo3 and not vf78LSlJQOnCsatrIH2P1iW and QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࠧࠩቒ") not in ll9khUfx3MjZ and BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡁࠪቓ") not in ll9khUfx3MjZ: ll9khUfx3MjZ = ll9khUfx3MjZ.rstrip(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩ࠲ࠫቔ"))+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪ࠳ࠬቕ")
	Vh14yzZUPJAsNmIe2Ho7u8bO0DT = (xB2HvGaMhZ1u!=None)
	ruoMBCLXPtVWx5l1cYfkQI2n3G8eU = (KzriWR2sPTbwpEeZ!=None and mA4tykubSDozlpcdvnP2ihjMZ0XCq!=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡘ࡚ࡏࡑࠩቖ"))
	if Vh14yzZUPJAsNmIe2Ho7u8bO0DT and not afoLXbP3cnp: fYPz7RldWQVHBktZAexwvCL8Np3D(h5huy6MiXPNfQJF8(u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨ቗"),xB2HvGaMhZ1u)
	elif ruoMBCLXPtVWx5l1cYfkQI2n3G8eU: fYPz7RldWQVHBktZAexwvCL8Np3D(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭ቘ"),KzriWR2sPTbwpEeZ)
	if Vh14yzZUPJAsNmIe2Ho7u8bO0DT:
		bNsDLHrj9SVRzwd5P6 = {HH4JMrUDp3lq6hQ(u"ࠢࡩࡶࡷࡴࠧ቙"):xB2HvGaMhZ1u,ZhqJoOtcmTVID65HwnLj(u"ࠣࡪࡷࡸࡵࡹࠢቚ"):xB2HvGaMhZ1u}
		UtjQwPnmi5J3S6H0YcCIW8 = xB2HvGaMhZ1u
	else: bNsDLHrj9SVRzwd5P6,UtjQwPnmi5J3S6H0YcCIW8 = {},HVibA2ES8lY(u"ࠩࠪቛ")
	if ruoMBCLXPtVWx5l1cYfkQI2n3G8eU:
		import urllib3.util.connection as P3R6TOkojarB0lVWIyJDM8qsxeXY
		RfjT5Om8viuCY7 = S6SvQ5ouXjxghUOeMlYNERJK(P3R6TOkojarB0lVWIyJDM8qsxeXY,yySB3TiHgxzsJQKfFmEq92t7V)
	SPsU1TynjmWvo3kxarfRB,nUEkWtT7yoMQPFDhAYCsrd,RgvdIclD5i3T0L8UEkBWAV1PX,LLYF9Q8TjHfd,Q8Fe9TVM4c,verify = yyJvuD24qMemIR59fH67cZQdE,nnN6lPjWb0xVQqDKwo3,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡈࡤࡰࡸ࡫ᝎ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡈࡤࡰࡸ࡫ᝎ"),SexFNJLoXtDdpRHws8lZfYEO
	if r9nz0YXobvLF328J6qIWkAQ: Q8Fe9TVM4c = vatyjK4hHAoZJ7rOq2lis(u"ࡗࡶࡺ࡫ᝏ")
	if rrM0AzQYO8Wn5 or yyJvuD24qMemIR59fH67cZQdE: SPsU1TynjmWvo3kxarfRB = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡊࡦࡲࡳࡦᝐ")
	if w13gbecGO5iWK2Fq7r0Y: RgvdIclD5i3T0L8UEkBWAV1PX = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡔࡔ࡙ࡔࠨቜ")
	yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = -HH4JMrUDp3lq6hQ(u"࠳᚟"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫቝ")
	for H3ABEcMzfyqwF4Ug2ZYtK in range(HVibA2ES8lY(u"࠼ᚠ")):
		RNVKoyhSGW1C3YfPi0QOBs = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࡙ࡸࡵࡦᝑ")
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = h5huy6MiXPNfQJF8(u"ࡌࡡ࡭ࡵࡨᝒ")
		try:
			if H3ABEcMzfyqwF4Ug2ZYtK: nUEkWtT7yoMQPFDhAYCsrd = FIHNSc5iuoZanQ2Ytl(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭቞")
			if afoLXbP3cnp or not Vh14yzZUPJAsNmIe2Ho7u8bO0DT: wZWH4u8XUFt3V5reszRQIcLvfiopO(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡓࠡࠢࡒࡔࡊࡔ࡟ࡖࡔࡏࠫ቟"),ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,nUEkWtT7yoMQPFDhAYCsrd,RgvdIclD5i3T0L8UEkBWAV1PX)
			try: z8zCauMw6AGm7ZRDFO4NeJ0xrLt.close()
			except: pass
			dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ
			z8zCauMw6AGm7ZRDFO4NeJ0xrLt = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.request(RgvdIclD5i3T0L8UEkBWAV1PX,ll9khUfx3MjZ,data=vf78LSlJQOnCsatrIH2P1iW,headers=JKf4Tsxu9S23FI7mV5DGLk,verify=verify,allow_redirects=SPsU1TynjmWvo3kxarfRB,timeout=hZYTKSaABQCofcrFlgsI,proxies=bNsDLHrj9SVRzwd5P6)
			if sDiKwnHcSlYFgWCy1Ak(u"࠷࠵࠶ᚡ")<=z8zCauMw6AGm7ZRDFO4NeJ0xrLt.status_code<=TWexH5PhS1(u"࠸࠿࠹ᚢ"):
				if not LLYF9Q8TjHfd:
					W7lsTxGDipXbK = list(z8zCauMw6AGm7ZRDFO4NeJ0xrLt.headers.keys())
					if ZEiR0StquOzca9lvPAndYIX(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩበ") in W7lsTxGDipXbK: ll9khUfx3MjZ = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.headers[cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪቡ")]
					elif sDiKwnHcSlYFgWCy1Ak(u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫቢ") in W7lsTxGDipXbK: ll9khUfx3MjZ = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.headers[l5mQdjWyczr7UJVnTp(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬባ")]
					else: LLYF9Q8TjHfd = sDiKwnHcSlYFgWCy1Ak(u"ࡔࡳࡷࡨᝓ")
					if not LLYF9Q8TjHfd: ll9khUfx3MjZ = ll9khUfx3MjZ.encode(HH4JMrUDp3lq6hQ(u"ࠫࡱࡧࡴࡪࡰ࠰࠵ࠬቤ"),l5mQdjWyczr7UJVnTp(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬብ")).decode(vatyjK4hHAoZJ7rOq2lis(u"࠭ࡵࡵࡨ࠻ࠫቦ"),HVibA2ES8lY(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧቧ"))
					if rrM0AzQYO8Wn5 and z8zCauMw6AGm7ZRDFO4NeJ0xrLt.status_code==Xl3drKyI9HkDiPEf8RTjwu(u"࠹࠰࠸ᚣ"):
						SPsU1TynjmWvo3kxarfRB = yyJvuD24qMemIR59fH67cZQdE
						RgvdIclD5i3T0L8UEkBWAV1PX = XhtVsaQU5r1cfgLDRMjO4EI9ouPT2
						LLYF9Q8TjHfd = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡕࡴࡸࡩ᝔")
						UBs3rWmqIiL5Mcbpd0Gy
				if not LLYF9Q8TjHfd or yyJvuD24qMemIR59fH67cZQdE:
					if ZEiR0StquOzca9lvPAndYIX(u"ࠨࡪࡷࡸࡵ࠭ቨ") not in ll9khUfx3MjZ:
						wlFhnG5JOULs6f8qzr4CXMYiNSavuP = ClNwy8MJfjoTq4ZFxYvmasD(dCmKxk9BW310AXu4bJUHfY,VH9MDo5z1kxNF07uRJI(u"ࠩࡸࡶࡱ࠭ቩ"))
						ll9khUfx3MjZ = wlFhnG5JOULs6f8qzr4CXMYiNSavuP+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪ࠳ࠬቪ")+ll9khUfx3MjZ.lstrip(sDiKwnHcSlYFgWCy1Ak(u"ࠫ࠴࠭ቫ"))
				if not LLYF9Q8TjHfd and yyJvuD24qMemIR59fH67cZQdE:
					rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(ll9khUfx3MjZ)
					if rUTwZXB4AoFRzdjnEPD2iNJKs not in [QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࠴ࡡࡷ࡫ࠪቬ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭࠮ࡵࡵࠪቭ"),HH4JMrUDp3lq6hQ(u"ࠧ࠯࡯ࡳ࠸ࠬቮ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨ࠰ࡤࡥࡨ࠭ቯ"),PiFkQ5pCJy7fbX(u"ࠩ࠱ࡱࡰࡼࠧተ"),EmK3ObA0cwv9Wy(u"ࠪ࠲ࡲࡶ࠳ࠨቱ"),sDiKwnHcSlYFgWCy1Ak(u"ࠫ࠳ࡽࡥࡣ࡯ࠪቲ")]: UBs3rWmqIiL5Mcbpd0Gy
			elif weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠶࠷࠳ᚥ")<=z8zCauMw6AGm7ZRDFO4NeJ0xrLt.status_code<=h5huy6MiXPNfQJF8(u"࠵࠺࠻ᚤ"):
				z8zCauMw6AGm7ZRDFO4NeJ0xrLt.rreason = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
				Q8Fe9TVM4c = l5mQdjWyczr7UJVnTp(u"ࡖࡵࡹࡪ᝕")
			dCmKxk9BW310AXu4bJUHfY = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.url
			yxkqChFvLOnj1TKZMHSUdrA9bGN = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.status_code
			rreason = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.reason
			z8zCauMw6AGm7ZRDFO4NeJ0xrLt.raise_for_status()
			UkYj1KP0ou4q9rVfEgn2JQHI56BG = HH4JMrUDp3lq6hQ(u"ࡗࡶࡺ࡫᝖")
		except CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.exceptions.HTTPError as RKq8Hda7ENycxDT1iZz9A3sLU5:
			pass
		except CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.exceptions.Timeout as RKq8Hda7ENycxDT1iZz9A3sLU5:
			if ggl6zFuXNdYTDieHCqGKRnVx: rreason = str(RKq8Hda7ENycxDT1iZz9A3sLU5.message).split(l5mQdjWyczr7UJVnTp(u"ࠬࡀࠠࠨታ"))[ZhqJoOtcmTVID65HwnLj(u"࠳ᚦ")]
			else: rreason = str(RKq8Hda7ENycxDT1iZz9A3sLU5).split(sbgu4D2RFMYKm(u"࠭࠺ࠡࠩቴ"))[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠴ᚧ")]
		except CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.exceptions.ConnectionError as RKq8Hda7ENycxDT1iZz9A3sLU5:
			try:
				g3gh0rZF6Bp1X8UmaWe9 = RKq8Hda7ENycxDT1iZz9A3sLU5.message[TWexH5PhS1(u"࠴ᚨ")]
				rreason = g3gh0rZF6Bp1X8UmaWe9
				if VOq8Ekue4F(u"ࠧࡆࡴࡵࡲࡴ࠭ት") in g3gh0rZF6Bp1X8UmaWe9: yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = T072lCzjYiuaeFtmJGV.findall(oAXJCYqPgyGDtT(u"ࠣ࡞࡞ࡉࡷࡸ࡮ࡰࠢࠫࡠࡩ࠱ࠩ࡝࡟ࠣࠬ࠳࠰࠿ࠪࠩࠥቶ"),g3gh0rZF6Bp1X8UmaWe9)[EmK3ObA0cwv9Wy(u"࠵ᚩ")]
				elif QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩ࠯ࠤࡪࡸࡲࡰࡴࠫࠫቷ") in g3gh0rZF6Bp1X8UmaWe9: yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = T072lCzjYiuaeFtmJGV.findall(VOq8Ekue4F(u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨቸ"),g3gh0rZF6Bp1X8UmaWe9)[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠶ᚪ")]
				elif g3gh0rZF6Bp1X8UmaWe9.count(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫ࠿࠭ቹ"))>=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᚬ"): rreason,yxkqChFvLOnj1TKZMHSUdrA9bGN = T072lCzjYiuaeFtmJGV.findall(h5huy6MiXPNfQJF8(u"ࠬࡀࠠࠩ࠰࠭ࡃ࠮ࡀ࠮ࠫࡁࠫࡠࡩ࠱ࠩࠨቺ"),g3gh0rZF6Bp1X8UmaWe9)[sbgu4D2RFMYKm(u"࠰ᚫ")]
			except: pass
		except CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.exceptions.RequestException as RKq8Hda7ENycxDT1iZz9A3sLU5:
			if ggl6zFuXNdYTDieHCqGKRnVx: rreason = RKq8Hda7ENycxDT1iZz9A3sLU5.message
			else: rreason = str(RKq8Hda7ENycxDT1iZz9A3sLU5)
		except:
			RNVKoyhSGW1C3YfPi0QOBs = WmaPChRdQk3YcXwI6zS(u"ࡊࡦࡲࡳࡦ᝗")
			try: yxkqChFvLOnj1TKZMHSUdrA9bGN = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.status_code
			except: pass
			try: rreason = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.reason
			except: pass
		rreason = str(rreason)
		GZvEITHSg5U3rVwQ(VH9MDo5z1kxNF07uRJI(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ቻ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧ࠯ࠢࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬቼ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+oAXJCYqPgyGDtT(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪች")+rreason+h5huy6MiXPNfQJF8(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫቾ")+nnN6lPjWb0xVQqDKwo3+WmaPChRdQk3YcXwI6zS(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩቿ")+gz1flZwncVutokL59RaGS3WeK+vatyjK4hHAoZJ7rOq2lis(u"ࠫࠥࡣࠧኀ"))
		if CXsNmARywK4p0ZrtVWnbf2xUc and rrM0AzQYO8Wn5 and RNVKoyhSGW1C3YfPi0QOBs and not Q8Fe9TVM4c and yxkqChFvLOnj1TKZMHSUdrA9bGN!=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠴࠳࠴ᚭ"):
			ll9khUfx3MjZ = nnc7vxhiEGDpQfs
			Q8Fe9TVM4c = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࡙ࡸࡵࡦ᝘")
			continue
		if RNVKoyhSGW1C3YfPi0QOBs: break
	if KzriWR2sPTbwpEeZ!=None and mA4tykubSDozlpcdvnP2ihjMZ0XCq!=ZEiR0StquOzca9lvPAndYIX(u"࡙ࠬࡔࡐࡒࠪኁ"): P3R6TOkojarB0lVWIyJDM8qsxeXY.create_connection = RfjT5Om8viuCY7
	if mA4tykubSDozlpcdvnP2ihjMZ0XCq==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭ኂ") and wAT9BZmYf4O5uPgG: KzriWR2sPTbwpEeZ = None
	if not UkYj1KP0ou4q9rVfEgn2JQHI56BG and xB2HvGaMhZ1u==None and nnN6lPjWb0xVQqDKwo3 not in MyfG164jLWzXKitYQTUqeDvrdSu0F:
		WzeExBTV6h = uz8Hlh4InqK7v0S6eQryomEjgb.format_exc()
		if WzeExBTV6h!=N9olEh0ZMtpOivVfBLK(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪኃ"): CJwTBit4NPQMu.stderr.write(WzeExBTV6h)
	mnV8BCoXEJxyAZtQhU62RpbraOY = B5Cv0E1zyTFw()
	mnV8BCoXEJxyAZtQhU62RpbraOY.url = dCmKxk9BW310AXu4bJUHfY
	try: B3bgDuFqXCs8 = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
	except: B3bgDuFqXCs8 = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠩኄ")
	try: tS6hejGbHUXLvnVcg8 = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.headers
	except: tS6hejGbHUXLvnVcg8 = {}
	try: a9u8iAeQsn0XT = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.cookies.get_dict()
	except: a9u8iAeQsn0XT = {}
	try: z8zCauMw6AGm7ZRDFO4NeJ0xrLt.close()
	except: pass
	if mmIKCGujwM:
		try: B3bgDuFqXCs8 = B3bgDuFqXCs8.decode(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡸࡸ࡫࠾ࠧኅ"))
		except: pass
	yxkqChFvLOnj1TKZMHSUdrA9bGN = int(yxkqChFvLOnj1TKZMHSUdrA9bGN)
	mnV8BCoXEJxyAZtQhU62RpbraOY.code = yxkqChFvLOnj1TKZMHSUdrA9bGN
	mnV8BCoXEJxyAZtQhU62RpbraOY.reason = rreason
	mnV8BCoXEJxyAZtQhU62RpbraOY.content = B3bgDuFqXCs8
	mnV8BCoXEJxyAZtQhU62RpbraOY.headers = tS6hejGbHUXLvnVcg8
	mnV8BCoXEJxyAZtQhU62RpbraOY.cookies = a9u8iAeQsn0XT
	mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded = UkYj1KP0ou4q9rVfEgn2JQHI56BG
	if ggl6zFuXNdYTDieHCqGKRnVx or isinstance(mnV8BCoXEJxyAZtQhU62RpbraOY.content,str): BbTcYUSntXAOw = mnV8BCoXEJxyAZtQhU62RpbraOY.content.lower()
	else: BbTcYUSntXAOw = l5mQdjWyczr7UJVnTp(u"ࠪࠫኆ")
	nAmfSN0Y93jC14Fa5T8oe = (sDiKwnHcSlYFgWCy1Ak(u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨኇ") in BbTcYUSntXAOw or BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬ࡭࡯ࡰࡩ࡯ࡩࠬኈ") in BbTcYUSntXAOw) and BbTcYUSntXAOw.count(oAXJCYqPgyGDtT(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ኉"))>VOq8Ekue4F(u"࠵ᚮ") and WmaPChRdQk3YcXwI6zS(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩኊ") not in nnN6lPjWb0xVQqDKwo3 and VOq8Ekue4F(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰࠪኋ") not in BbTcYUSntXAOw and not afoLXbP3cnp
	if yxkqChFvLOnj1TKZMHSUdrA9bGN==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶࠵࠶ᚯ") and nAmfSN0Y93jC14Fa5T8oe: mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡌࡡ࡭ࡵࡨ᝙")
	if mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded and CXsNmARywK4p0ZrtVWnbf2xUc and rrM0AzQYO8Wn5:
		if r9nz0YXobvLF328J6qIWkAQ: gYHe5zsT3N1lcRIy = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪኌ")+vf78LSlJQOnCsatrIH2P1iW[TWexH5PhS1(u"ࠪ࡮ࡴࡨࠧኍ")].upper().replace(PiFkQ5pCJy7fbX(u"ࠫࡌࡋࡔࠨ኎"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬ࠭኏"))
		J3CvlL2NVUOAwta6Pry1 = cH3wtyn51rUbuWOdLo89Z(gYHe5zsT3N1lcRIy)
	if not mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded and CXsNmARywK4p0ZrtVWnbf2xUc:
		lZXnrY7EFm4o8UQh1B = (S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪነ") in BbTcYUSntXAOw and cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡳࡣࡼࠤ࡮ࡪ࠺ࠡࠩኑ") in BbTcYUSntXAOw)
		rXaZTeEFVxnqsjQtPz5hY = (h5huy6MiXPNfQJF8(u"ࠨ࠷ࠣࡷࡪࡩࠧኒ") in BbTcYUSntXAOw and N9olEh0ZMtpOivVfBLK(u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪና") in BbTcYUSntXAOw)
		lPLI9zYb6iNhZU30AsvuVD2C8Ftr1 = (yxkqChFvLOnj1TKZMHSUdrA9bGN in [EEvLoMzFqrlKce(u"࠹࠶࠳ᚰ")] and h5huy6MiXPNfQJF8(u"ࠪࡩࡷࡸ࡯ࡳࠢࡦࡳࡩ࡫࠺ࠡ࠳࠳࠶࠵࠭ኔ") in BbTcYUSntXAOw)
		VV0ngZypu3lx4 = (vatyjK4hHAoZJ7rOq2lis(u"ࠫࡤࡩࡦࡠࡥ࡫ࡰࡤ࠭ን") in BbTcYUSntXAOw and FIHNSc5iuoZanQ2Ytl(u"ࠬࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࠩኖ") in BbTcYUSntXAOw)
		if   nAmfSN0Y93jC14Fa5T8oe: rreason = f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ኗ")
		elif lZXnrY7EFm4o8UQh1B: rreason = ttOu147wErcBvPaSMUY(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨኘ")
		elif rXaZTeEFVxnqsjQtPz5hY: rreason = ttOu147wErcBvPaSMUY(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨኙ")
		elif lPLI9zYb6iNhZU30AsvuVD2C8Ftr1: rreason = EEvLoMzFqrlKce(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡥࡨࡩࡥࡴࡵࠣࡨࡪࡴࡩࡦࡦࠪኚ")
		elif VV0ngZypu3lx4: rreason = vatyjK4hHAoZJ7rOq2lis(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬኛ")
		else: rreason = str(rreason)
		if nnN6lPjWb0xVQqDKwo3 in VfLOSt67XB2JNsnYx: pass
		elif nnN6lPjWb0xVQqDKwo3 in MyfG164jLWzXKitYQTUqeDvrdSu0F:
			GZvEITHSg5U3rVwQ(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪኜ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨኝ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+TWexH5PhS1(u"࠭ࠠ࡞ࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧኞ")+rreason+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩኟ")+nnN6lPjWb0xVQqDKwo3+h5huy6MiXPNfQJF8(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧአ")+ll9khUfx3MjZ+ZhqJoOtcmTVID65HwnLj(u"ࠩࠣࡡࠬኡ"))
		else: GZvEITHSg5U3rVwQ(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨኢ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࠥࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨኣ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+N9olEh0ZMtpOivVfBLK(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ኤ")+rreason+VH9MDo5z1kxNF07uRJI(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨእ")+nnN6lPjWb0xVQqDKwo3+VOq8Ekue4F(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ኦ")+ll9khUfx3MjZ+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠢࡠࠫኧ"))
		oxfAZ2ESTm65p = rygO0TzuEdiPcQDWZ8awSjm(ll9khUfx3MjZ)
		if ggl6zFuXNdYTDieHCqGKRnVx and isinstance(oxfAZ2ESTm65p,unicode): oxfAZ2ESTm65p = oxfAZ2ESTm65p.encode(f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡸࡸ࡫࠾ࠧከ"))
		if rrM0AzQYO8Wn5: oxfAZ2ESTm65p = oxfAZ2ESTm65p.split(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪ࠳ࠬኩ"))[-vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠷ᚱ")]
		TsdBOqxXHJCRoPfrhz = rreason
		rreason = str(rreason)+oAXJCYqPgyGDtT(u"ࠫࡡࡴࠨࠡࠩኪ")+oxfAZ2ESTm65p+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࠦࠩࠨካ")
		if nAmfSN0Y93jC14Fa5T8oe or lZXnrY7EFm4o8UQh1B or rXaZTeEFVxnqsjQtPz5hY or lPLI9zYb6iNhZU30AsvuVD2C8Ftr1 or VV0ngZypu3lx4:
			yxkqChFvLOnj1TKZMHSUdrA9bGN = -S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠲ᚲ")
			mnV8BCoXEJxyAZtQhU62RpbraOY.code = yxkqChFvLOnj1TKZMHSUdrA9bGN
			mnV8BCoXEJxyAZtQhU62RpbraOY.reason = rreason
			if o48agNivFQYRWsqcSftZP1:
				GZvEITHSg5U3rVwQ(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬኬ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+VOq8Ekue4F(u"ࠧࠡࠢࠣࠤ࡙ࡸࡹࡪࡰࡪࠤࡧࡿࡰࡢࡵࡶࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩክ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩኮ")+TsdBOqxXHJCRoPfrhz+WmaPChRdQk3YcXwI6zS(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫኯ")+nnN6lPjWb0xVQqDKwo3+ttOu147wErcBvPaSMUY(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩኰ")+ll9khUfx3MjZ+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࠥࡣࠧ኱"))
				fYPz7RldWQVHBktZAexwvCL8Np3D(WmaPChRdQk3YcXwI6zS(u"๋ࠬอศ๊็อࠥะฬศ๊ีࠤฬ๊แฮืࠣห้ษๅ็์ࠪኲ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࠧኳ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠲࠷࠳࠴ᚳ"))
				XXxcjlIzDwZEQr3eWkUNoY0Gm = YTPut68WBVUNCvsEzg.getSetting(h5huy6MiXPNfQJF8(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠵ࠬኴ"))
				glvr926KTmsBc7yUaAECMwZ1hVROJ = YTPut68WBVUNCvsEzg.getSetting(h5huy6MiXPNfQJF8(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠷࠭ኵ"))
				XXxcjlIzDwZEQr3eWkUNoY0Gm = VH9MDo5z1kxNF07uRJI(u"࠻࠼࠽࠾ᚴ") if not XXxcjlIzDwZEQr3eWkUNoY0Gm else int(XXxcjlIzDwZEQr3eWkUNoY0Gm)
				glvr926KTmsBc7yUaAECMwZ1hVROJ = Xl3drKyI9HkDiPEf8RTjwu(u"࠼࠽࠾࠿ᚵ") if not glvr926KTmsBc7yUaAECMwZ1hVROJ else int(glvr926KTmsBc7yUaAECMwZ1hVROJ)
				T3LJVYAEZIP6i29spFeHmXtDwokfg = []
				if XXxcjlIzDwZEQr3eWkUNoY0Gm>g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶࠶ᚷ"): T3LJVYAEZIP6i29spFeHmXtDwokfg.append(ZhqJoOtcmTVID65HwnLj(u"࠵ᚶ"))
				if glvr926KTmsBc7yUaAECMwZ1hVROJ>g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠷࠰ᚸ"): T3LJVYAEZIP6i29spFeHmXtDwokfg.append(l5mQdjWyczr7UJVnTp(u"࠲ᚹ"))
				T3LJVYAEZIP6i29spFeHmXtDwokfg.append(ZhqJoOtcmTVID65HwnLj(u"࠴ᚺ"))
				nRZVkcGM62p = XIjYJW8qbtv63.sample(T3LJVYAEZIP6i29spFeHmXtDwokfg,Xl3drKyI9HkDiPEf8RTjwu(u"࠳ᚻ"))[cbngtp9sqYi0DjeEMLRHJruKxm(u"࠳ᚼ")]
				if nRZVkcGM62p==HH4JMrUDp3lq6hQ(u"࠵ᚽ"):
					gmen85C6OZFKQSJi39hdjI = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡧ࠷࠼࠳ࡢࡤ࠴ࡩ࠺࠶࠴࠵ࡦ࠵ࡧࡦ࠻ࡤ࠶ࡦ࠶ࡪ࠾࡫࠳ࡤ࠵࠻࠺ࡪࡩࡡ࠲࠳࠳࠼࠸࠾࠹ࡢ࠹࠶࠾ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠺࠹࠲࠻࠴ࠬ኶")
					zFHuCf5Gpms8XE2MbI0Tc = ll9khUfx3MjZ+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ኷")+gmen85C6OZFKQSJi39hdjI+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫኸ")
					UL6ovIQ2TiD8MdkAY50wbZ4 = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,zFHuCf5Gpms8XE2MbI0Tc,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡆࡢ࡮ࡶࡩ᝚"),N9olEh0ZMtpOivVfBLK(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠵ࡲࡩ࠭ኹ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡆࡢ࡮ࡶࡩ᝚"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡆࡢ࡮ࡶࡩ᝚"))
				elif nRZVkcGM62p==ttOu147wErcBvPaSMUY(u"࠷ᚾ"):
					gmen85C6OZFKQSJi39hdjI = Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱ࡤ࠵ࡧ࠷ࡦ࡫࠱࠹࠷ࡧࡪ࠹ࡨࡦ࠷ࡣࡩ࠹࠸࠹ࡣ࠸࠲࠷࠴ࡧ࠹࠴࠸ࡥ࠼ࡩ࠾࠿ࡢࡦ࠶࠹࠺ࡦ࡫࠹࠻ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥ࠯ࡦࡲ࠾࠽࠶࠸࠱ࠩኺ")
					zFHuCf5Gpms8XE2MbI0Tc = ll9khUfx3MjZ+ZhqJoOtcmTVID65HwnLj(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧኻ")+gmen85C6OZFKQSJi39hdjI+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨኼ")
					UL6ovIQ2TiD8MdkAY50wbZ4 = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,zFHuCf5Gpms8XE2MbI0Tc,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,EEvLoMzFqrlKce(u"ࡇࡣ࡯ࡷࡪ᝛"),vatyjK4hHAoZJ7rOq2lis(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠳࠳ࡳࡦࠪኽ"),EEvLoMzFqrlKce(u"ࡇࡣ࡯ࡷࡪ᝛"),EEvLoMzFqrlKce(u"ࡇࡣ࡯ࡷࡪ᝛"))
				elif nRZVkcGM62p==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠹ᚿ"):
					gmen85C6OZFKQSJi39hdjI = ZhqJoOtcmTVID65HwnLj(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠺࠸࠸ࡥ࠸࡫ࡩ࠳࠵ࡨࡦࡨ࠶࠿ࡤ࠺ࡥ࠸࠹ࡦ࠷࠵ࡧ࠵࠹࠴࠹ࡩࡤ࠺࠳࠷ࡧࡅࡶࡲࡰࡺࡼ࠱ࡸ࡫ࡲࡷࡧࡵ࠲ࡸࡩࡲࡢࡲࡨࡶࡦࡶࡩ࠯ࡥࡲࡱ࠿࠾࠰࠱࠳ࠪኾ")
					zFHuCf5Gpms8XE2MbI0Tc = ll9khUfx3MjZ+vatyjK4hHAoZJ7rOq2lis(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ኿")+gmen85C6OZFKQSJi39hdjI+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዀ")
					UL6ovIQ2TiD8MdkAY50wbZ4 = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,zFHuCf5Gpms8XE2MbI0Tc,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠸ࡹ࡮ࠧ዁"),EmK3ObA0cwv9Wy(u"ࡈࡤࡰࡸ࡫᝜"),EmK3ObA0cwv9Wy(u"ࡈࡤࡰࡸ࡫᝜"))
				else: UL6ovIQ2TiD8MdkAY50wbZ4 = mnV8BCoXEJxyAZtQhU62RpbraOY
				yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = UL6ovIQ2TiD8MdkAY50wbZ4.code,UL6ovIQ2TiD8MdkAY50wbZ4.reason
				if not UL6ovIQ2TiD8MdkAY50wbZ4.succeeded:
					GZvEITHSg5U3rVwQ(VOq8Ekue4F(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ዂ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+HH4JMrUDp3lq6hQ(u"ࠨࠢࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪዃ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+VH9MDo5z1kxNF07uRJI(u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪዄ")+rreason+VOq8Ekue4F(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬዅ")+nnN6lPjWb0xVQqDKwo3+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ዆")+zFHuCf5Gpms8XE2MbI0Tc+TWexH5PhS1(u"ࠬࠦ࡝ࠨ዇"))
					fYPz7RldWQVHBktZAexwvCL8Np3D(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ไๅลึๅࠥ็ิๅࠢส่ๆำีࠡษ็ว๊์๊ࠨወ"),h5huy6MiXPNfQJF8(u"ࠧอำหࠤ๊ืษࠡลัี๎࠭ዉ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=Xl3drKyI9HkDiPEf8RTjwu(u"࠲࠱࠲࠳ᛀ"))
				else:
					GZvEITHSg5U3rVwQ(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧዊ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+EEvLoMzFqrlKce(u"ࠩࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡣࡻࡳࡥࡸࡹࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዋ")+nnN6lPjWb0xVQqDKwo3+PiFkQ5pCJy7fbX(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩዌ")+zFHuCf5Gpms8XE2MbI0Tc+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠥࡣࠧው"))
					if nRZVkcGM62p in [sbgu4D2RFMYKm(u"࠲ᛁ"),HVibA2ES8lY(u"࠴ᛂ")]:
						QeYHPKONM3AwjVRInst2p = UL6ovIQ2TiD8MdkAY50wbZ4.headers[N0Kvne8UYar9fhRxboWsXJCVzid(u"࡙ࠬࡣࡳࡣࡳࡩ࠳ࡪ࡯࠮ࡔࡨࡱࡦ࡯࡮ࡪࡰࡪ࠱ࡈࡸࡥࡥ࡫ࡷࡷࠬዎ")]
						if nRZVkcGM62p==EmK3ObA0cwv9Wy(u"࠴ᛃ"): YTPut68WBVUNCvsEzg.setSetting(EmK3ObA0cwv9Wy(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡥࡱ࠴ࠫዏ"),QeYHPKONM3AwjVRInst2p)
						if nRZVkcGM62p==sDiKwnHcSlYFgWCy1Ak(u"࠶ᛄ"): YTPut68WBVUNCvsEzg.setSetting(Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡦࡲ࠶ࠬዐ"),QeYHPKONM3AwjVRInst2p)
					fYPz7RldWQVHBktZAexwvCL8Np3D(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨ่ฯัࠥอไโฯุࠤฬ๊รๆ่ํࠫዑ"),WmaPChRdQk3YcXwI6zS(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪዒ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=h5huy6MiXPNfQJF8(u"࠷࠶࠰࠱ᛅ"))
					return UL6ovIQ2TiD8MdkAY50wbZ4
		VjwKs4GNQZ518kCl = sDiKwnHcSlYFgWCy1Ak(u"ࡗࡶࡺ࡫᝝")
		if (mA4tykubSDozlpcdvnP2ihjMZ0XCq==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࡅࡘࡑࠧዓ") or JnPGZ5EAfV==VH9MDo5z1kxNF07uRJI(u"ࠫࡆ࡙ࡋࠨዔ")) and (wAT9BZmYf4O5uPgG or o48agNivFQYRWsqcSftZP1):
			VjwKs4GNQZ518kCl = a4oGEfmk9UAHvnFDZRg(yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason,nnN6lPjWb0xVQqDKwo3,showDialogs)
			if VjwKs4GNQZ518kCl and mA4tykubSDozlpcdvnP2ihjMZ0XCq==h5huy6MiXPNfQJF8(u"ࠬࡇࡓࡌࠩዕ"): mA4tykubSDozlpcdvnP2ihjMZ0XCq = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨዖ")
			else: mA4tykubSDozlpcdvnP2ihjMZ0XCq = ZhqJoOtcmTVID65HwnLj(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ዗")
			if VjwKs4GNQZ518kCl and JnPGZ5EAfV==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡃࡖࡏࠬዘ"): JnPGZ5EAfV = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫዙ")
			else: JnPGZ5EAfV = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬዚ")
			YTPut68WBVUNCvsEzg.setSetting(VOq8Ekue4F(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧዛ"),mA4tykubSDozlpcdvnP2ihjMZ0XCq)
			YTPut68WBVUNCvsEzg.setSetting(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪዜ"),JnPGZ5EAfV)
		if VjwKs4GNQZ518kCl:
			w2TCBgLV3teEyIMpWh6KciDjAGrUJ = f5uqIoSJzWBOFyrY78RXmVb(u"ࡘࡷࡻࡥ᝞")
			if yxkqChFvLOnj1TKZMHSUdrA9bGN==EEvLoMzFqrlKce(u"࠾ᛆ") and sDiKwnHcSlYFgWCy1Ak(u"࠭ࡨࡵࡶࡳࡷࠬዝ") in ll9khUfx3MjZ and w2TCBgLV3teEyIMpWh6KciDjAGrUJ:
				if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(VH9MDo5z1kxNF07uRJI(u"ࠧหใ฼๎้ࠦแฮืุࠣ์อฯสࠢส่ฯฺแ๋ำࠣࡗࡘࡒࠧዞ"),ttOu147wErcBvPaSMUY(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪዟ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=HH4JMrUDp3lq6hQ(u"࠲࠱࠲࠳ᛇ"))
				dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩዠ")
				J3CvlL2NVUOAwta6Pry1 = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,dCmKxk9BW310AXu4bJUHfY,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,vatyjK4hHAoZJ7rOq2lis(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠶ࡶ࡫ࠫዡ"))
				if J3CvlL2NVUOAwta6Pry1.succeeded:
					mnV8BCoXEJxyAZtQhU62RpbraOY = J3CvlL2NVUOAwta6Pry1
					GZvEITHSg5U3rVwQ(oAXJCYqPgyGDtT(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪዢ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዣ")+nnN6lPjWb0xVQqDKwo3+oAXJCYqPgyGDtT(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬዤ")+gz1flZwncVutokL59RaGS3WeK+TWexH5PhS1(u"ࠧࠡ࡟ࠪዥ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨ่ฯหาࠦศศีอาิอๅࠡࡕࡖࡐࠬዦ"),WmaPChRdQk3YcXwI6zS(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫዧ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=VOq8Ekue4F(u"࠳࠲࠳࠴ᛈ"))
				else:
					GZvEITHSg5U3rVwQ(FIHNSc5iuoZanQ2Ytl(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨየ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዩ")+nnN6lPjWb0xVQqDKwo3+ZEiR0StquOzca9lvPAndYIX(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫዪ")+gz1flZwncVutokL59RaGS3WeK+PiFkQ5pCJy7fbX(u"࠭ࠠ࡞ࠩያ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(TWexH5PhS1(u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪዬ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪይ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=ZhqJoOtcmTVID65HwnLj(u"࠴࠳࠴࠵ᛉ"))
			if not mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded and JnPGZ5EAfV in [TWexH5PhS1(u"ࠩࡄ࡙࡙ࡕࠧዮ"),vatyjK4hHAoZJ7rOq2lis(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬዯ")] and o48agNivFQYRWsqcSftZP1:
				if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(HVibA2ES8lY(u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫደ"),HVibA2ES8lY(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧዱ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=VOq8Ekue4F(u"࠵࠴࠵࠶ᛊ"))
				J3CvlL2NVUOAwta6Pry1 = g9gwp0dWDmjR1QaN(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,ll9khUfx3MjZ,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,l5mQdjWyczr7UJVnTp(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠺ࡹ࡮ࠧዲ"))
				if J3CvlL2NVUOAwta6Pry1.succeeded:
					mnV8BCoXEJxyAZtQhU62RpbraOY = J3CvlL2NVUOAwta6Pry1
					GZvEITHSg5U3rVwQ(PiFkQ5pCJy7fbX(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ዳ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+EmK3ObA0cwv9Wy(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨዴ")+nnN6lPjWb0xVQqDKwo3+WmaPChRdQk3YcXwI6zS(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨድ")+gz1flZwncVutokL59RaGS3WeK+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠤࡢ࠭ዶ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(cbngtp9sqYi0DjeEMLRHJruKxm(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪዷ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧዸ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=EmK3ObA0cwv9Wy(u"࠶࠵࠶࠰ᛋ"))
				else:
					GZvEITHSg5U3rVwQ(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫዹ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫዺ")+nnN6lPjWb0xVQqDKwo3+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧዻ")+gz1flZwncVutokL59RaGS3WeK+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠣࡡࠬዼ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(ZEiR0StquOzca9lvPAndYIX(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨዽ"),FIHNSc5iuoZanQ2Ytl(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ዾ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=h5huy6MiXPNfQJF8(u"࠷࠶࠰࠱ᛌ"))
			if not mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded and mA4tykubSDozlpcdvnP2ihjMZ0XCq in [ttOu147wErcBvPaSMUY(u"ࠬࡇࡕࡕࡑࠪዿ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨጀ")] and wAT9BZmYf4O5uPgG:
				if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩጁ"),FIHNSc5iuoZanQ2Ytl(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪጂ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=Xl3drKyI9HkDiPEf8RTjwu(u"࠸࠰࠱࠲ᛍ"))
				dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+N9olEh0ZMtpOivVfBLK(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧጃ")
				J3CvlL2NVUOAwta6Pry1 = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,dCmKxk9BW310AXu4bJUHfY,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,ZEiR0StquOzca9lvPAndYIX(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠸ࡶ࡫ࠫጄ"))
				if J3CvlL2NVUOAwta6Pry1.succeeded:
					mnV8BCoXEJxyAZtQhU62RpbraOY = J3CvlL2NVUOAwta6Pry1
					GZvEITHSg5U3rVwQ(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪጅ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+ZhqJoOtcmTVID65HwnLj(u"ࠬࠦࠠࠡࡆࡑࡗࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬጆ")+yySB3TiHgxzsJQKfFmEq92t7V+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጇ")+nnN6lPjWb0xVQqDKwo3+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ገ")+gz1flZwncVutokL59RaGS3WeK+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠢࡠࠫጉ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"้ࠩะฬำࠠิ์ิๅึࠦࡄࡏࡕࠪጊ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬጋ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=sbgu4D2RFMYKm(u"࠲࠱࠲࠳ᛎ"))
				else:
					GZvEITHSg5U3rVwQ(PiFkQ5pCJy7fbX(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩጌ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+HH4JMrUDp3lq6hQ(u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩግ")+yySB3TiHgxzsJQKfFmEq92t7V+vatyjK4hHAoZJ7rOq2lis(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጎ")+nnN6lPjWb0xVQqDKwo3+f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ጏ")+gz1flZwncVutokL59RaGS3WeK+VH9MDo5z1kxNF07uRJI(u"ࠨࠢࡠࠫጐ"))
					if showDialogs: fYPz7RldWQVHBktZAexwvCL8Np3D(l5mQdjWyczr7UJVnTp(u"ࠩไุ้ࠦำ๋ำไีࠥࡊࡎࡔࠩ጑"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬጒ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=HVibA2ES8lY(u"࠳࠲࠳࠴ᛏ"))
		if JnPGZ5EAfV==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ጓ") or mA4tykubSDozlpcdvnP2ihjMZ0XCq==EEvLoMzFqrlKce(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧጔ"): showDialogs = HVibA2ES8lY(u"ࡋࡧ࡬ࡴࡧ᝟")
		if not mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded:
			if showDialogs: lntJcpdr2f1kI = a4oGEfmk9UAHvnFDZRg(yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason,nnN6lPjWb0xVQqDKwo3,showDialogs)
			if yxkqChFvLOnj1TKZMHSUdrA9bGN!=ZEiR0StquOzca9lvPAndYIX(u"࠴࠳࠴ᛐ") and nnN6lPjWb0xVQqDKwo3 not in qqxtuBsgdSk and QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪጕ") not in nnN6lPjWb0xVQqDKwo3:
				v9BiEYVb3fcZrql0(Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡴࡥࡵࡹࡲࡶࡰࠦࡩࡴࡵࡸࡩࡸࠦࡷࡪࡶ࡫࠾ࠥ࠭጖")+nnN6lPjWb0xVQqDKwo3)
	if YTPut68WBVUNCvsEzg.getSetting(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ጗")) not in [EmK3ObA0cwv9Wy(u"ࠩࡄ࡙࡙ࡕࠧጘ"),VOq8Ekue4F(u"ࠪࡗ࡙ࡕࡐࠨጙ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡆ࡙ࡋࠨጚ")]: YTPut68WBVUNCvsEzg.setSetting(N9olEh0ZMtpOivVfBLK(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨጛ"),l5mQdjWyczr7UJVnTp(u"࠭ࡁࡔࡍࠪጜ"))
	if YTPut68WBVUNCvsEzg.getSetting(TWexH5PhS1(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬጝ")) not in [HH4JMrUDp3lq6hQ(u"ࠨࡃࡘࡘࡔ࠭ጞ"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࡖࡘࡔࡖࠧጟ"),sbgu4D2RFMYKm(u"ࠪࡅࡘࡑࠧጠ")]: YTPut68WBVUNCvsEzg.setSetting(HH4JMrUDp3lq6hQ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩጡ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬࡇࡓࡌࠩጢ"))
	return mnV8BCoXEJxyAZtQhU62RpbraOY
def lSFHaMs1enNVw7biRYOG90UcPjQz(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,nnN6lPjWb0xVQqDKwo3,wAT9BZmYf4O5uPgG=oAXJCYqPgyGDtT(u"࠭ࠧጣ"),o48agNivFQYRWsqcSftZP1=HVibA2ES8lY(u"ࠧࠨጤ")):
	ll9khUfx3MjZ,xB2HvGaMhZ1u,KzriWR2sPTbwpEeZ,SexFNJLoXtDdpRHws8lZfYEO = hxg062nspYHPSuVKfkdC(gz1flZwncVutokL59RaGS3WeK)
	hLYopVN51jn0T6 = XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,ll9khUfx3MjZ,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6
	if A4fgbO6kxXRhVZ2sMLjuN:
		z8zCauMw6AGm7ZRDFO4NeJ0xrLt = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,TWexH5PhS1(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪጥ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬጦ"),hLYopVN51jn0T6)
		if z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
			wZWH4u8XUFt3V5reszRQIcLvfiopO(TWexH5PhS1(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪጧ"),ll9khUfx3MjZ,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2)
			return z8zCauMw6AGm7ZRDFO4NeJ0xrLt
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = rQhCtPmne9SIJcw4M(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,J4ETawPbd6,showDialogs,nnN6lPjWb0xVQqDKwo3,wAT9BZmYf4O5uPgG,o48agNivFQYRWsqcSftZP1)
	if z8zCauMw6AGm7ZRDFO4NeJ0xrLt.succeeded:
		if TWexH5PhS1(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬጨ") in nnN6lPjWb0xVQqDKwo3: z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content = BJxFdCcqYyK96TS50MP3jav(z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content)
		if A4fgbO6kxXRhVZ2sMLjuN: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,l5mQdjWyczr7UJVnTp(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨጩ"),hLYopVN51jn0T6,z8zCauMw6AGm7ZRDFO4NeJ0xrLt,A4fgbO6kxXRhVZ2sMLjuN)
	return z8zCauMw6AGm7ZRDFO4NeJ0xrLt
def j8ieg546LG2rUaksfnNMcI1lb(A4fgbO6kxXRhVZ2sMLjuN,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,showDialogs,nnN6lPjWb0xVQqDKwo3):
	if not Z402tBVhQi or isinstance(Z402tBVhQi,dict): XhtVsaQU5r1cfgLDRMjO4EI9ouPT2 = ttOu147wErcBvPaSMUY(u"࠭ࡇࡆࡖࠪጪ")
	else:
		XhtVsaQU5r1cfgLDRMjO4EI9ouPT2 = EmK3ObA0cwv9Wy(u"ࠧࡑࡑࡖࡘࠬጫ")
		Z402tBVhQi = rygO0TzuEdiPcQDWZ8awSjm(Z402tBVhQi)
		DSkrYHNU3gIj6FcBCR5wfvamGdx2i,Z402tBVhQi = y2dmjAuhlfboLe(Z402tBVhQi)
	z8zCauMw6AGm7ZRDFO4NeJ0xrLt = lSFHaMs1enNVw7biRYOG90UcPjQz(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,EmK3ObA0cwv9Wy(u"࡚ࡲࡶࡧᝠ"),showDialogs,nnN6lPjWb0xVQqDKwo3)
	KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.content
	KLxMkaVlguvqPcF = str(KLxMkaVlguvqPcF)
	return KLxMkaVlguvqPcF
def hxg062nspYHPSuVKfkdC(gz1flZwncVutokL59RaGS3WeK):
	pZmjv12OV7cx4Fh6Ky9LDkeiUXlRr = gz1flZwncVutokL59RaGS3WeK.split(l5mQdjWyczr7UJVnTp(u"ࠨࡾࡿࠫጬ"))
	ll9khUfx3MjZ,xB2HvGaMhZ1u,KzriWR2sPTbwpEeZ,SexFNJLoXtDdpRHws8lZfYEO = pZmjv12OV7cx4Fh6Ky9LDkeiUXlRr[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠳ᛑ")],None,None,vatyjK4hHAoZJ7rOq2lis(u"ࡔࡳࡷࡨᝡ")
	for hLYopVN51jn0T6 in pZmjv12OV7cx4Fh6Ky9LDkeiUXlRr:
		if weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧጭ") in hLYopVN51jn0T6: xB2HvGaMhZ1u = hLYopVN51jn0T6.split(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡁࠬጮ"))[TWexH5PhS1(u"࠵ᛒ")]
		elif sDiKwnHcSlYFgWCy1Ak(u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧጯ") in hLYopVN51jn0T6: KzriWR2sPTbwpEeZ = hLYopVN51jn0T6.split(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࡃࠧጰ"))[sbgu4D2RFMYKm(u"࠶ᛓ")]
		elif f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫጱ") in hLYopVN51jn0T6: SexFNJLoXtDdpRHws8lZfYEO = VH9MDo5z1kxNF07uRJI(u"ࡇࡣ࡯ࡷࡪᝢ")
	return ll9khUfx3MjZ,xB2HvGaMhZ1u,KzriWR2sPTbwpEeZ,SexFNJLoXtDdpRHws8lZfYEO
def nhuP4q9F1lmRIjdHUBWaQg(eENPgSDsKvOH24QpIbGjZtwnYoFl):
	IRjrO2kFqKVLXND01e,vuyTFsAd72wDBiUPSnft5obMjErR6,pnEy8Xb9fcjml4Y6rwDQZzKSgo = N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࠨጲ"),ttOu147wErcBvPaSMUY(u"ࠨࠩጳ"),sDiKwnHcSlYFgWCy1Ak(u"ࠩࠪጴ")
	eENPgSDsKvOH24QpIbGjZtwnYoFl = eENPgSDsKvOH24QpIbGjZtwnYoFl.replace(sfquhCGUwdvRl96izX,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠫጵ")).replace(zWyErX8YHiLsemj9G6lb2p1,PiFkQ5pCJy7fbX(u"ࠫࠬጶ"))
	mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall(TWexH5PhS1(u"ࠬ࠮࠮ࠪ࡞࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡠࡢ࠮࡜ࡸ࡞ࡺࡠࡼ࠯ࠠࠬ࡞࡞ࡠ࠴ࡉࡏࡍࡑࡕࡠࡢ࠮࠮ࠫࡁࠬࠨࠬጷ"),eENPgSDsKvOH24QpIbGjZtwnYoFl,T072lCzjYiuaeFtmJGV.DOTALL)
	if mnN8GgS1XEePILK0DC49qky6UzZ: IRjrO2kFqKVLXND01e,vuyTFsAd72wDBiUPSnft5obMjErR6,eENPgSDsKvOH24QpIbGjZtwnYoFl = mnN8GgS1XEePILK0DC49qky6UzZ[HVibA2ES8lY(u"࠶ᛔ")]
	if IRjrO2kFqKVLXND01e not in [QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠠࠨጸ"),HVibA2ES8lY(u"ࠧ࠭ࠩጹ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࠩጺ")]: pnEy8Xb9fcjml4Y6rwDQZzKSgo = HH4JMrUDp3lq6hQ(u"ࠩࡢࡑࡔࡊ࡟ࠨጻ")
	if vuyTFsAd72wDBiUPSnft5obMjErR6: vuyTFsAd72wDBiUPSnft5obMjErR6 = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡣࠬጼ")+vuyTFsAd72wDBiUPSnft5obMjErR6+FIHNSc5iuoZanQ2Ytl(u"ࠫࡤ࠭ጽ")
	eENPgSDsKvOH24QpIbGjZtwnYoFl = vuyTFsAd72wDBiUPSnft5obMjErR6+pnEy8Xb9fcjml4Y6rwDQZzKSgo+eENPgSDsKvOH24QpIbGjZtwnYoFl
	return eENPgSDsKvOH24QpIbGjZtwnYoFl
def NJviWdaAUb(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,YYNQD2FpWSVbXKtd,VBg5KmvcnZwuEbN7AMhtYySl30Qkjf,xvtAaZQ8MJoVRcYpnryHd,YYmX6s9ieC4N3TuoVxnRApZ=HVibA2ES8lY(u"ࠬ࠭ጾ")):
	slZg49DNdPfJGMrRhLc = ClNwy8MJfjoTq4ZFxYvmasD(gz1flZwncVutokL59RaGS3WeK,vatyjK4hHAoZJ7rOq2lis(u"࠭ࡵࡳ࡮ࠪጿ"))
	cVxeDAtMOL0JkPpX75R = YTPut68WBVUNCvsEzg.getSetting(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩፀ")+YYNQD2FpWSVbXKtd)
	if slZg49DNdPfJGMrRhLc==cVxeDAtMOL0JkPpX75R: YTPut68WBVUNCvsEzg.setSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪፁ")+YYNQD2FpWSVbXKtd,VH9MDo5z1kxNF07uRJI(u"ࠩࠪፂ"))
	if cVxeDAtMOL0JkPpX75R: dCmKxk9BW310AXu4bJUHfY = gz1flZwncVutokL59RaGS3WeK.replace(slZg49DNdPfJGMrRhLc,cVxeDAtMOL0JkPpX75R)
	else:
		dCmKxk9BW310AXu4bJUHfY = gz1flZwncVutokL59RaGS3WeK
		cVxeDAtMOL0JkPpX75R = slZg49DNdPfJGMrRhLc
	J3CvlL2NVUOAwta6Pry1 = lSFHaMs1enNVw7biRYOG90UcPjQz(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,dCmKxk9BW310AXu4bJUHfY,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࠫፃ"),YYmX6s9ieC4N3TuoVxnRApZ,FIHNSc5iuoZanQ2Ytl(u"ࠫࠬፄ"),PiFkQ5pCJy7fbX(u"ࠬ࠭ፅ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪፆ"))
	KLxMkaVlguvqPcF = J3CvlL2NVUOAwta6Pry1.content
	if mmIKCGujwM:
		try: KLxMkaVlguvqPcF = KLxMkaVlguvqPcF.decode(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡶࡶࡩ࠼ࠬፇ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨፈ"))
		except: pass
	yxkqChFvLOnj1TKZMHSUdrA9bGN = J3CvlL2NVUOAwta6Pry1.code
	if yxkqChFvLOnj1TKZMHSUdrA9bGN!=-N9olEh0ZMtpOivVfBLK(u"࠲ᛕ") and (not J3CvlL2NVUOAwta6Pry1.succeeded or xvtAaZQ8MJoVRcYpnryHd not in KLxMkaVlguvqPcF):
		VBg5KmvcnZwuEbN7AMhtYySl30Qkjf = VBg5KmvcnZwuEbN7AMhtYySl30Qkjf.replace(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࠣࠫፉ"),HH4JMrUDp3lq6hQ(u"ࠪ࠯ࠬፊ"))
		ll9khUfx3MjZ = FIHNSc5iuoZanQ2Ytl(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩፋ")+VBg5KmvcnZwuEbN7AMhtYySl30Qkjf
		JKf4Tsxu9S23FI7mV5DGLk = {BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩፌ"):N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠧፍ")}
		mnV8BCoXEJxyAZtQhU62RpbraOY = lSFHaMs1enNVw7biRYOG90UcPjQz(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,ll9khUfx3MjZ,EEvLoMzFqrlKce(u"ࠧࠨፎ"),JKf4Tsxu9S23FI7mV5DGLk,l5mQdjWyczr7UJVnTp(u"ࠨࠩፏ"),FIHNSc5iuoZanQ2Ytl(u"ࠩࠪፐ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧፑ"))
		if mnV8BCoXEJxyAZtQhU62RpbraOY.succeeded:
			KLxMkaVlguvqPcF = mnV8BCoXEJxyAZtQhU62RpbraOY.content
			if mmIKCGujwM:
				try: KLxMkaVlguvqPcF = KLxMkaVlguvqPcF.decode(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡺࡺࡦ࠹ࠩፒ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬፓ"))
				except: pass
			kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall(Xl3drKyI9HkDiPEf8RTjwu(u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱࡟ࡻ࠯ࡢ࠿࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧፔ"),KLxMkaVlguvqPcF,T072lCzjYiuaeFtmJGV.DOTALL)
			yyjlcMgZr7KTtFvLCR = [cVxeDAtMOL0JkPpX75R]
			g9QKj62ThfE4 = [f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡢࡲ࡮ࠫፕ"),EmK3ObA0cwv9Wy(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨፖ"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࡷࡻ࡮ࡺࡴࡦࡴࠪፗ"),N9olEh0ZMtpOivVfBLK(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫፘ"),HH4JMrUDp3lq6hQ(u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭ፙ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡶࡨࡱࠩፚ"),ZEiR0StquOzca9lvPAndYIX(u"࠭ࡡࡵ࡮ࡤࡵࠬ፛"),FIHNSc5iuoZanQ2Ytl(u"ࠧࡴ࡫ࡷࡩ࡮ࡴࡤࡪࡥࡨࡷࠬ፜"),HH4JMrUDp3lq6hQ(u"ࠨࡵࡸࡶ࠳ࡲࡹࠨ፝"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࡥࡰࡴ࡭ࡳࡱࡱࡷࠫ፞"),EmK3ObA0cwv9Wy(u"ࠪ࡭ࡳ࡬࡯ࡳ࡯ࡨࡶࠬ፟"),sbgu4D2RFMYKm(u"ࠫࡸ࡯ࡴࡦ࡮࡬࡯ࡪ࠭፠"),HH4JMrUDp3lq6hQ(u"ࠬ࡯࡮ࡴࡶࡤ࡫ࡷࡧ࡭ࠨ፡"),oAXJCYqPgyGDtT(u"࠭ࡳ࡯ࡣࡳࡧ࡭ࡧࡴࠨ።"),vatyjK4hHAoZJ7rOq2lis(u"ࠧࡩࡶࡷࡴ࠲࡫ࡱࡶ࡫ࡹࠫ፣"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡨࡤࡷࡪࡲࡰ࡭ࡷࡶࠫ፤")]
			for y2x6dqF8kQHXYpLa7rnWVD4heRu in kkH5sRPxhASFowLONy4:
				if any(EYn2siOeDvQTk8KpS0Jl in y2x6dqF8kQHXYpLa7rnWVD4heRu for EYn2siOeDvQTk8KpS0Jl in g9QKj62ThfE4): continue
				cVxeDAtMOL0JkPpX75R = ClNwy8MJfjoTq4ZFxYvmasD(y2x6dqF8kQHXYpLa7rnWVD4heRu,ZEiR0StquOzca9lvPAndYIX(u"ࠩࡸࡶࡱ࠭፥"))
				if cVxeDAtMOL0JkPpX75R in yyjlcMgZr7KTtFvLCR: continue
				if len(yyjlcMgZr7KTtFvLCR)==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠺ᛖ"):
					GZvEITHSg5U3rVwQ(ZhqJoOtcmTVID65HwnLj(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ፦"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+TWexH5PhS1(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫ፧")+YYNQD2FpWSVbXKtd+h5huy6MiXPNfQJF8(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪ፨")+slZg49DNdPfJGMrRhLc+ZhqJoOtcmTVID65HwnLj(u"࠭ࠠ࡞ࠩ፩"))
					YTPut68WBVUNCvsEzg.setSetting(TWexH5PhS1(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩ፪")+YYNQD2FpWSVbXKtd,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠩ፫"))
					break
				yyjlcMgZr7KTtFvLCR.append(cVxeDAtMOL0JkPpX75R)
				dCmKxk9BW310AXu4bJUHfY = gz1flZwncVutokL59RaGS3WeK.replace(slZg49DNdPfJGMrRhLc,cVxeDAtMOL0JkPpX75R)
				J3CvlL2NVUOAwta6Pry1 = lSFHaMs1enNVw7biRYOG90UcPjQz(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,dCmKxk9BW310AXu4bJUHfY,vatyjK4hHAoZJ7rOq2lis(u"ࠩࠪ፬"),YYmX6s9ieC4N3TuoVxnRApZ,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠫ፭"),vatyjK4hHAoZJ7rOq2lis(u"ࠫࠬ፮"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ፯"))
				KLxMkaVlguvqPcF = J3CvlL2NVUOAwta6Pry1.content
				if J3CvlL2NVUOAwta6Pry1.succeeded and xvtAaZQ8MJoVRcYpnryHd in KLxMkaVlguvqPcF:
					GZvEITHSg5U3rVwQ(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ፰"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+HVibA2ES8lY(u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡤࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ፱")+YYNQD2FpWSVbXKtd+PiFkQ5pCJy7fbX(u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ፲")+cVxeDAtMOL0JkPpX75R+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ፳")+slZg49DNdPfJGMrRhLc+Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࠤࡢ࠭፴"))
					YTPut68WBVUNCvsEzg.setSetting(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭፵")+YYNQD2FpWSVbXKtd,cVxeDAtMOL0JkPpX75R)
					break
	return cVxeDAtMOL0JkPpX75R,dCmKxk9BW310AXu4bJUHfY,J3CvlL2NVUOAwta6Pry1
def hqWB0vmTcxR8d3oukL(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry):
	EM3VDyrzUAq8W = {
	 vatyjK4hHAoZJ7rOq2lis(u"ࠬࡵ࡬ࡥࠩ፶")			:vatyjK4hHAoZJ7rOq2lis(u"࠭โะ์่ࠫ፷")
	,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ፸")		:uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠨ็อ์็็ࠧ፹")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ፺")		:sDiKwnHcSlYFgWCy1Ak(u"้ࠪๆ่่ะࠩ፻")
	,WmaPChRdQk3YcXwI6zS(u"ࠫ࡬ࡵ࡯ࡥࠩ፼")			:sbgu4D2RFMYKm(u"ࠬา๊ะࠩ፽")
	,ZhqJoOtcmTVID65HwnLj(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭፾")		:vatyjK4hHAoZJ7rOq2lis(u"ࠧโึ็ࠫ፿")
	,HH4JMrUDp3lq6hQ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎀ")		:WmaPChRdQk3YcXwI6zS(u"่ࠩะ้ีࠧᎁ")
	,HVibA2ES8lY(u"ࠪࡺ࡮ࡪࡥࡰࠩᎂ")		:VOq8Ekue4F(u"ࠫๆ๐ฯ๋๊ࠪᎃ")
	,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࡲࡩࡷࡧࠪᎄ")			:EEvLoMzFqrlKce(u"࠭โ็ษฬࠫᎅ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡢ࡭ࡲࡥࡲ࠭ᎆ")		:QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬᎇ")
	,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡤ࡯ࡼࡧ࡭ࠨᎈ")		:oAXJCYqPgyGDtT(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧᎉ")
	,HH4JMrUDp3lq6hQ(u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭ᎊ")		:HVibA2ES8lY(u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭ᎋ")
	,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ᎌ")		:WmaPChRdQk3YcXwI6zS(u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧᎍ")
	,WmaPChRdQk3YcXwI6zS(u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪᎎ")		:BWh0PmauYpSA9JHxnGV6O8KFc3q(u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨᎏ")
	,TWexH5PhS1(u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭᎐")	:VH9MDo5z1kxNF07uRJI(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ᎑")
	,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ᎒")		:vatyjK4hHAoZJ7rOq2lis(u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ᎓")
	,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ᎔")		:h5huy6MiXPNfQJF8(u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ᎕")
	,HH4JMrUDp3lq6hQ(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭᎖")	:HH4JMrUDp3lq6hQ(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ᎗")
	,Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭᎘")		:oAXJCYqPgyGDtT(u"๋่ࠬใ฻ࠣหู้๊็็สࠫ᎙")
	,l5mQdjWyczr7UJVnTp(u"࠭ࡨࡦ࡮ࡤࡰࠬ᎚")		:ZhqJoOtcmTVID65HwnLj(u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ᎛")
	,VOq8Ekue4F(u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ᎜")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ᎝")
	,oAXJCYqPgyGDtT(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ᎞")		:VOq8Ekue4F(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭᎟")
	,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧᎠ")		:WmaPChRdQk3YcXwI6zS(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭Ꭱ")
	,VOq8Ekue4F(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩᎢ")		:vatyjK4hHAoZJ7rOq2lis(u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨᎣ")
	,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᎤ")		:ttOu147wErcBvPaSMUY(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪᎥ")
	,EEvLoMzFqrlKce(u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧᎦ")	:vatyjK4hHAoZJ7rOq2lis(u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨᎧ")
	,sbgu4D2RFMYKm(u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᎨ")	:mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭Ꭹ")
	,HH4JMrUDp3lq6hQ(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨᎪ")		:sDiKwnHcSlYFgWCy1Ak(u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩᎫ")
	,TWexH5PhS1(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪᎬ")		:Xl3drKyI9HkDiPEf8RTjwu(u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪᎭ")
	,N9olEh0ZMtpOivVfBLK(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧᎮ")		:TWexH5PhS1(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨᎯ")
	,sDiKwnHcSlYFgWCy1Ak(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩᎰ")		:f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫᎱ")
	,PiFkQ5pCJy7fbX(u"ࠩࡥࡳࡰࡸࡡࠨᎲ")		:l5mQdjWyczr7UJVnTp(u"้ࠪํู่ࠡสๆีฬ࠭Ꮃ")
	,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭Ꮄ")		:sDiKwnHcSlYFgWCy1Ak(u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭Ꮅ")
	,VOq8Ekue4F(u"࠭࡬ࡪࡸࡨࡸࡻ࠭Ꮆ")		:FIHNSc5iuoZanQ2Ytl(u"ࠧๆๆไࠫᎷ")
	,l5mQdjWyczr7UJVnTp(u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩᎸ")		:oAXJCYqPgyGDtT(u"่่ࠩๆ࠭Ꮉ")
	,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪᎺ")		:VH9MDo5z1kxNF07uRJI(u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭Ꮋ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨᎼ")	:sDiKwnHcSlYFgWCy1Ak(u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫᎽ")
	,f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨᎾ")		:h5huy6MiXPNfQJF8(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩᎿ")
	,FIHNSc5iuoZanQ2Ytl(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫᏀ")		:ZhqJoOtcmTVID65HwnLj(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭Ꮑ")
	,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭Ꮒ")		:WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨᏃ")
	,sbgu4D2RFMYKm(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨᏄ")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪᏅ")
	,VH9MDo5z1kxNF07uRJI(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪᏆ")		:vatyjK4hHAoZJ7rOq2lis(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬᏇ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪᏈ")		:VH9MDo5z1kxNF07uRJI(u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭Ꮙ")
	,HVibA2ES8lY(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬᏊ")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭Ꮛ")
	,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨᏌ")		:sDiKwnHcSlYFgWCy1Ak(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨᏍ")
	,f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫᏎ")		:l5mQdjWyczr7UJVnTp(u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪᏏ")
	,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬᏐ")		:vatyjK4hHAoZJ7rOq2lis(u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫᏑ")
	,mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࡴࡷࡨࡸࡲࠬᏒ")		:Xl3drKyI9HkDiPEf8RTjwu(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧᏓ")
	,ZEiR0StquOzca9lvPAndYIX(u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫᏔ")	:TWexH5PhS1(u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪᏕ")
	,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧᏖ")	:WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬᏗ")
	,EEvLoMzFqrlKce(u"ࠬ࡬࡯ࡴࡶࡤࠫᏘ")		:mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪᏙ")
	,N9olEh0ZMtpOivVfBLK(u"ࠧࡢࡪࡺࡥࡰ࠭Ꮪ")		:ZhqJoOtcmTVID65HwnLj(u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪᏛ")
	,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪᏜ")		:weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"้ࠪํู่ࠡใหี่ฯࠧᏝ")
	,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧࡽ࡯ࡳ࡭ࠪᏞ")	:N0Kvne8UYar9fhRxboWsXJCVzid(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อูࠦๆๆࠪᏟ")
	,ZhqJoOtcmTVID65HwnLj(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨᏠ")		:N9olEh0ZMtpOivVfBLK(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᏡ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡵ࡫ࡳ࡫࡮ࡡࠨᏢ")		:uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"่ࠩ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫᏣ")
	,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡦࡷࡹࡴࡦ࡬ࠪᏤ")		:HH4JMrUDp3lq6hQ(u"๊ࠫ๎โฺࠢหีุะ๊อࠩᏥ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࡩࡩ࡮ࡣ࠷࠴࠵࠭Ꮶ")		:sDiKwnHcSlYFgWCy1Ak(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭Ꮷ")
	,sbgu4D2RFMYKm(u"ࠧ࡭ࡣࡵࡳࡿࡧࠧᏨ")		:PiFkQ5pCJy7fbX(u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭Ꮹ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡼࡥࡶࡵࡴࠨᏪ")		:Xl3drKyI9HkDiPEf8RTjwu(u"้ࠪํู่ࠡ์สๆํะࠧᏫ")
	,Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭Ꮼ")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"๋่ࠬใ฻ࠣ็ฯ้่หࠩᏭ")
	,h5huy6MiXPNfQJF8(u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨᏮ")		:mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩᏯ")
	,VH9MDo5z1kxNF07uRJI(u"ࠨࡣࡵࡥࡧ࡯ࡣࡵࡱࡲࡲࡸ࠭Ᏸ")	:TWexH5PhS1(u"่ࠩ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫᏱ")
	,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫᏲ")		:FIHNSc5iuoZanQ2Ytl(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫᏳ")
	,FIHNSc5iuoZanQ2Ytl(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧᏴ")		:Xl3drKyI9HkDiPEf8RTjwu(u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬᏵ")
	,EEvLoMzFqrlKce(u"ࠧࡪࡨ࡬ࡰࡲ࠭᏶")				:N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ᏷")
	,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨᏸ")			:l5mQdjWyczr7UJVnTp(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬᏹ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫᏺ")		:HH4JMrUDp3lq6hQ(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪᏻ")
	,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡰࡢࡰࡨࡸࠬᏼ")				:vatyjK4hHAoZJ7rOq2lis(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫᏽ")
	,VOq8Ekue4F(u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ᏾")			:VH9MDo5z1kxNF07uRJI(u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ᏿")
	,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩ᐀")			:HVibA2ES8lY(u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩᐁ")
	,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ᐂ")				:TWexH5PhS1(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫᐃ")
	,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨᐄ")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨᐅ")
	,HVibA2ES8lY(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭ᐆ")	:HH4JMrUDp3lq6hQ(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧᐇ")
	,ZEiR0StquOzca9lvPAndYIX(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧᐈ")		:l5mQdjWyczr7UJVnTp(u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩᐉ")
	,oAXJCYqPgyGDtT(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩᐊ")			:Xl3drKyI9HkDiPEf8RTjwu(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩᐋ")
	,EmK3ObA0cwv9Wy(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬᐌ")	:oAXJCYqPgyGDtT(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩᐍ")
	,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭ᐎ")		:cbngtp9sqYi0DjeEMLRHJruKxm(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬᐏ")
	,TWexH5PhS1(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨᐐ")		:VH9MDo5z1kxNF07uRJI(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨᐑ")
	,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬᐒ")			:WmaPChRdQk3YcXwI6zS(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩᐓ")
	,oAXJCYqPgyGDtT(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧᐔ")	:sbgu4D2RFMYKm(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭ᐕ")
	,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬᐖ"):S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬᐗ")
	,PiFkQ5pCJy7fbX(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᐘ")	:Xl3drKyI9HkDiPEf8RTjwu(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧᐙ")
	,ZEiR0StquOzca9lvPAndYIX(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭ᐚ")	:ttOu147wErcBvPaSMUY(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪᐛ")
	,N9olEh0ZMtpOivVfBLK(u"ࠪ࡭ࡵࡺࡶࠨᐜ")					:ZhqJoOtcmTVID65HwnLj(u"ࠫࡎࡖࡔࡗࠩᐝ")
	,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨᐞ")			:h5huy6MiXPNfQJF8(u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪᐟ")
	,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᐠ")			:sbgu4D2RFMYKm(u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬᐡ")
	,h5huy6MiXPNfQJF8(u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧᐢ")			:Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩᐣ")
	,ZhqJoOtcmTVID65HwnLj(u"ࠫࡲ࠹ࡵࠨᐤ")					:Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡓ࠳ࡖࠩᐥ")
	,PiFkQ5pCJy7fbX(u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨᐦ")				:EmK3ObA0cwv9Wy(u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪᐧ")
	,N9olEh0ZMtpOivVfBLK(u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᐨ")			:vatyjK4hHAoZJ7rOq2lis(u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬᐩ")
	,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧᐪ")			:N9olEh0ZMtpOivVfBLK(u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩᐫ")
	}
	try: aaTNWVv1zR8b0dwY = EM3VDyrzUAq8W[BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.lower()]
	except: aaTNWVv1zR8b0dwY = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬ࠭ᐬ")
	return aaTNWVv1zR8b0dwY
def v9BiEYVb3fcZrql0(kg1pK9CEwGaTI0ReMP4crBL8tshHy=f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࠧᐭ")):
	Ysrnya0A9CTWb4Bh2UHf5wv3EDP()
	if not kg1pK9CEwGaTI0ReMP4crBL8tshHy: kg1pK9CEwGaTI0ReMP4crBL8tshHy = vatyjK4hHAoZJ7rOq2lis(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡆࡺ࡬ࡸࠬᐮ")
	GZvEITHSg5U3rVwQ(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࠩᐯ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩ࡟ࡲࠬᐰ")+kg1pK9CEwGaTI0ReMP4crBL8tshHy+VH9MDo5z1kxNF07uRJI(u"ࠪࡠࡳ࠭ᐱ"))
	try: CJwTBit4NPQMu.exit()
	except: pass
	return
def K3PukgCEDY(gz1flZwncVutokL59RaGS3WeK,SScBEXuvy3hJebm60HYoMaI5TtCVD=WmaPChRdQk3YcXwI6zS(u"ࠫ࠿࠵ࠧᐲ")):
	return _nQhElmPsC(gz1flZwncVutokL59RaGS3WeK,SScBEXuvy3hJebm60HYoMaI5TtCVD)
def MkOgZ6j9qU1iRTeK(CAg0pwIrLonlxtJkThQqSX3):
	if CAg0pwIrLonlxtJkThQqSX3 in [ttOu147wErcBvPaSMUY(u"ࠬ࠭ᐳ"),FIHNSc5iuoZanQ2Ytl(u"࠭࠰ࠨᐴ"),EEvLoMzFqrlKce(u"࠲ᛗ")]: return WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࠨᐵ")
	CAg0pwIrLonlxtJkThQqSX3 = int(CAg0pwIrLonlxtJkThQqSX3)
	vJqHoX04wDdCKB2FG6hmZr3ScWb = CAg0pwIrLonlxtJkThQqSX3^CC89Q23uNDmIKWHAs
	FYNZota6luUBIsLKcdTJfHD4gEy1 = CAg0pwIrLonlxtJkThQqSX3^GGXxhdg3JCamPIFepybjZ
	Oq7LZDlJy2YVretgd3sMU = CAg0pwIrLonlxtJkThQqSX3^j9t7FmfZiE6pYGI8V4u
	aaTNWVv1zR8b0dwY = str(vJqHoX04wDdCKB2FG6hmZr3ScWb)+str(FYNZota6luUBIsLKcdTJfHD4gEy1)+str(Oq7LZDlJy2YVretgd3sMU)
	return aaTNWVv1zR8b0dwY
def nof9ztvAKb6WS1jPhFluwe2BQZMkIc(CAg0pwIrLonlxtJkThQqSX3):
	if CAg0pwIrLonlxtJkThQqSX3 in [EmK3ObA0cwv9Wy(u"ࠨࠩᐶ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࠳ࠫᐷ"),ttOu147wErcBvPaSMUY(u"࠳ᛘ")]: return weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠫᐸ")
	CAg0pwIrLonlxtJkThQqSX3 = str(CAg0pwIrLonlxtJkThQqSX3)
	aaTNWVv1zR8b0dwY = sbgu4D2RFMYKm(u"ࠫࠬᐹ")
	if len(CAg0pwIrLonlxtJkThQqSX3)==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠵࠺ᛙ"):
		vJqHoX04wDdCKB2FG6hmZr3ScWb,FYNZota6luUBIsLKcdTJfHD4gEy1,Oq7LZDlJy2YVretgd3sMU = CAg0pwIrLonlxtJkThQqSX3[TWexH5PhS1(u"࠶ᛛ"):QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴ᛜ")],CAg0pwIrLonlxtJkThQqSX3[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴ᛜ"):N0Kvne8UYar9fhRxboWsXJCVzid(u"࠾ᛚ")],CAg0pwIrLonlxtJkThQqSX3[N0Kvne8UYar9fhRxboWsXJCVzid(u"࠾ᛚ"):]
		vJqHoX04wDdCKB2FG6hmZr3ScWb = int(vJqHoX04wDdCKB2FG6hmZr3ScWb)^j9t7FmfZiE6pYGI8V4u
		FYNZota6luUBIsLKcdTJfHD4gEy1 = int(FYNZota6luUBIsLKcdTJfHD4gEy1)^GGXxhdg3JCamPIFepybjZ
		Oq7LZDlJy2YVretgd3sMU = int(Oq7LZDlJy2YVretgd3sMU)^CC89Q23uNDmIKWHAs
		if vJqHoX04wDdCKB2FG6hmZr3ScWb==FYNZota6luUBIsLKcdTJfHD4gEy1==Oq7LZDlJy2YVretgd3sMU: aaTNWVv1zR8b0dwY = str(vJqHoX04wDdCKB2FG6hmZr3ScWb*oAXJCYqPgyGDtT(u"࠷࠲ᛝ"))
	return aaTNWVv1zR8b0dwY
def zNx5bYlAyeLvtOpXfwK(CAg0pwIrLonlxtJkThQqSX3,QQhw9eOKGYNZvUnTVcj2kD1rJpPs5o=cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧᐺ")):
	if CAg0pwIrLonlxtJkThQqSX3==N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࠧᐻ"): return TWexH5PhS1(u"ࠧࠨᐼ")
	CAg0pwIrLonlxtJkThQqSX3 = int(CAg0pwIrLonlxtJkThQqSX3)+int(QQhw9eOKGYNZvUnTVcj2kD1rJpPs5o)
	vJqHoX04wDdCKB2FG6hmZr3ScWb = CAg0pwIrLonlxtJkThQqSX3^CC89Q23uNDmIKWHAs
	FYNZota6luUBIsLKcdTJfHD4gEy1 = CAg0pwIrLonlxtJkThQqSX3^GGXxhdg3JCamPIFepybjZ
	Oq7LZDlJy2YVretgd3sMU = CAg0pwIrLonlxtJkThQqSX3^j9t7FmfZiE6pYGI8V4u
	aaTNWVv1zR8b0dwY = str(vJqHoX04wDdCKB2FG6hmZr3ScWb)+str(FYNZota6luUBIsLKcdTJfHD4gEy1)+str(Oq7LZDlJy2YVretgd3sMU)
	return aaTNWVv1zR8b0dwY
def nt3lgK2RBZHJAb(CAg0pwIrLonlxtJkThQqSX3,QQhw9eOKGYNZvUnTVcj2kD1rJpPs5o=QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪᐽ")):
	if CAg0pwIrLonlxtJkThQqSX3==N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࠪᐾ"): return cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࠫᐿ")
	CAg0pwIrLonlxtJkThQqSX3 = str(CAg0pwIrLonlxtJkThQqSX3)
	PPezI3c1TXMHyfERlNOsWB2bmrKoU = int(len(CAg0pwIrLonlxtJkThQqSX3)/vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠵ᛞ"))
	vJqHoX04wDdCKB2FG6hmZr3ScWb = int(CAg0pwIrLonlxtJkThQqSX3[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠳ᛟ"):PPezI3c1TXMHyfERlNOsWB2bmrKoU])^CC89Q23uNDmIKWHAs
	FYNZota6luUBIsLKcdTJfHD4gEy1 = int(CAg0pwIrLonlxtJkThQqSX3[PPezI3c1TXMHyfERlNOsWB2bmrKoU:vatyjK4hHAoZJ7rOq2lis(u"࠶ᛠ")*PPezI3c1TXMHyfERlNOsWB2bmrKoU])^GGXxhdg3JCamPIFepybjZ
	Oq7LZDlJy2YVretgd3sMU = int(CAg0pwIrLonlxtJkThQqSX3[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠸ᛢ")*PPezI3c1TXMHyfERlNOsWB2bmrKoU:g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠸ᛡ")*PPezI3c1TXMHyfERlNOsWB2bmrKoU])^j9t7FmfZiE6pYGI8V4u
	aaTNWVv1zR8b0dwY = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬᑀ")
	if vJqHoX04wDdCKB2FG6hmZr3ScWb==FYNZota6luUBIsLKcdTJfHD4gEy1==Oq7LZDlJy2YVretgd3sMU: aaTNWVv1zR8b0dwY = str(int(vJqHoX04wDdCKB2FG6hmZr3ScWb)-int(QQhw9eOKGYNZvUnTVcj2kD1rJpPs5o))
	return aaTNWVv1zR8b0dwY
def IwMkQbtRaygHBVF7dK9ipNU5rfYAS(F4F72NVUlhugr):
	ndDOiHfVwey3rqBSksPtj0mMR2JuGE = tOnYIHVk4xydqwoLEBKiDN0hX[VH9MDo5z1kxNF07uRJI(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᑁ")][HVibA2ES8lY(u"࠸ᛣ")]
	MIL2UWV9BSRq = au8Umt9dq1KLSYb(VH9MDo5z1kxNF07uRJI(u"࠴࠴ᛤ"))
	CSJuex3OXpayrl1dTN = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩᑂ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡴ࡭࡬ࡲࡸ࠭ᑃ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩᑄ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࠺࠶࠵ࡶࠧᑅ"),vatyjK4hHAoZJ7rOq2lis(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬᑆ"))
	lcCp6xWQghrLPuYqo9GRMNHOdsIf,RdmXgYfLw5T0zA2lh = qtKQXi2C9V7JrEyWD61Lns(CSJuex3OXpayrl1dTN)
	lcCp6xWQghrLPuYqo9GRMNHOdsIf = zNx5bYlAyeLvtOpXfwK(lcCp6xWQghrLPuYqo9GRMNHOdsIf,sbgu4D2RFMYKm(u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧᑇ"))
	oUI9ycu2zZEShGbWF7VeKdRgwB = {VH9MDo5z1kxNF07uRJI(u"ࠬ࡯ࡤࡴࠩᑈ"):VH9MDo5z1kxNF07uRJI(u"࠭ࡄࡊࡃࡏࡓࡌ࠭ᑉ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡶࡵࡵࠫᑊ"):MIL2UWV9BSRq,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࡸࡨࡶࠬᑋ"):pQmoyUJBNaf72A,Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡶࡧࡷ࠭ᑌ"):F4F72NVUlhugr,h5huy6MiXPNfQJF8(u"ࠪࡷ࡮ࢀࠧᑍ"):lcCp6xWQghrLPuYqo9GRMNHOdsIf}
	nzAogLK4Gey8D7ETRN = {BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᑎ"):N9olEh0ZMtpOivVfBLK(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫᑏ")}
	WVDeEoUwKzbx1mH = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡐࡐࡕࡗࠫᑐ"),ndDOiHfVwey3rqBSksPtj0mMR2JuGE,oUI9ycu2zZEShGbWF7VeKdRgwB,nzAogLK4Gey8D7ETRN,WmaPChRdQk3YcXwI6zS(u"ࠧࠨᑑ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩᑒ"),N9olEh0ZMtpOivVfBLK(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪᑓ"))
	bn38FU9Y4ufLe = WVDeEoUwKzbx1mH.content
	try:
		if not bn38FU9Y4ufLe: viAdEj7JR6aolXLSTgVN
		O2AVtRNZr9agpm3E1F0Bzix = cwiLy4IAVJj0pWCl7FGxokR(vatyjK4hHAoZJ7rOq2lis(u"ࠪࡨ࡮ࡩࡴࠨᑔ"),bn38FU9Y4ufLe)
		NN4Xca9kI51o2DiFd7pA = O2AVtRNZr9agpm3E1F0Bzix[WmaPChRdQk3YcXwI6zS(u"ࠫࡲࡹࡧࠨᑕ")]
		JrDbeI5ldkOLS27BGNYhpV = O2AVtRNZr9agpm3E1F0Bzix[Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡹࡥࡤࠩᑖ")]
		PQKIucx5fY3FCr = O2AVtRNZr9agpm3E1F0Bzix[VOq8Ekue4F(u"࠭ࡳࡵࡲࠪᑗ")]
		JrDbeI5ldkOLS27BGNYhpV = int(nt3lgK2RBZHJAb(JrDbeI5ldkOLS27BGNYhpV,FIHNSc5iuoZanQ2Ytl(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪᑘ")))
		PQKIucx5fY3FCr = int(nt3lgK2RBZHJAb(PQKIucx5fY3FCr,l5mQdjWyczr7UJVnTp(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫᑙ")))
		for JrAcKbftU3pQ451EaXsgjDyeq in range(JrDbeI5ldkOLS27BGNYhpV,l5mQdjWyczr7UJVnTp(u"࠲ᛥ"),-PQKIucx5fY3FCr):
			if not eval(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬᑚ"),{VOq8Ekue4F(u"ࠪࡼࡧࡳࡣࠨᑛ"):EO9Rts0AaGuk1qpPLXCY}): viAdEj7JR6aolXLSTgVN
			fYPz7RldWQVHBktZAexwvCL8Np3D(oAXJCYqPgyGDtT(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪᑜ"),str(JrAcKbftU3pQ451EaXsgjDyeq)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬࠦࠠฬษ้๎ฮ࠭ᑝ"),D1vBJgya85Yh4cRTCkIMKtWLSeH=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠶࠴࠵ᛦ")*PQKIucx5fY3FCr)
			EO9Rts0AaGuk1qpPLXCY.sleep(VOq8Ekue4F(u"࠵࠵࠶࠰ᛧ")*PQKIucx5fY3FCr)
		if eval(EEvLoMzFqrlKce(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࡘ࡬ࡨࡪࡵࠨࠪࠩᑞ"),{uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࡹࡤࡰࡧࠬᑟ"):EO9Rts0AaGuk1qpPLXCY}):
			NN4Xca9kI51o2DiFd7pA = NN4Xca9kI51o2DiFd7pA.replace(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨ࡞ࡱࠫᑠ"),VOq8Ekue4F(u"ࠩ࡟ࡠࡳ࠭ᑡ")).replace(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡠࡷ࠭ᑢ"),VOq8Ekue4F(u"ࠫࡡࡢࡲࠨᑣ"))
			KK47FGdX1TDfkb3AjHOQqghE(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬ࠭ᑤ"),VOq8Ekue4F(u"࠭ฮา๊ฯࠫᑥ"),ZhqJoOtcmTVID65HwnLj(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᑦ"),NN4Xca9kI51o2DiFd7pA)
		viAdEj7JR6aolXLSTgVN
	except: exec(FIHNSc5iuoZanQ2Ytl(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨᑧ"),{sbgu4D2RFMYKm(u"ࠩࡻࡦࡲࡩࠧᑨ"):EO9Rts0AaGuk1qpPLXCY})
	return
def hK6ziN5kmMZr8ops2qD():
	exec(HVibA2ES8lY(u"ࠪࠫࠬࠓࠊࡵࡴࡼ࠾ࠒࠐࠉࡸ࡫ࡱࡨࡴࡽ࠱࠳࠵ࠣࡁࠥࡾࡢ࡮ࡥࡪࡹ࡮࠴ࡗࡪࡰࡧࡳࡼ࠮࠱࠱࠲࠵࠹࠮ࠓࠊࠊࡹ࡫࡭ࡱ࡫ࠠࡕࡴࡸࡩ࠿ࠓࠊࠊࠋࡻࡦࡲࡩ࠮ࡴ࡮ࡨࡩࡵ࠮࠱࠱࠲࠳࠭ࠒࠐࠉࠊࡶࡵࡽ࠿ࠦࡷࡪࡰࡧࡳࡼ࠷࠲࠴࠰ࡪࡩࡹࡌ࡯ࡤࡷࡶࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡤࡵࡩࡦࡱࠍࠋࠋࡽࡧࡷ࡫ࡡࡵࡧࡢࡩࡷࡵࡲࡳࠏࠍࡩࡽࡩࡥࡱࡶ࠽ࠤࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠑࠏ࠭ࠧࠨᑩ"),{l5mQdjWyczr7UJVnTp(u"ࠫࡽࡨ࡭ࡤࡩࡸ࡭ࠬᑪ"):Ko1p5u9jwG6rF,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡾࡢ࡮ࡥࠪᑫ"):EO9Rts0AaGuk1qpPLXCY})
	return
def qtKQXi2C9V7JrEyWD61Lns(QrXa1M59APiDRvHL6GJOgd7Et4):
	d0dafJYyF4P6GLs,TnOEcKMSxN = vatyjK4hHAoZJ7rOq2lis(u"࠵ᛨ"),vatyjK4hHAoZJ7rOq2lis(u"࠵ᛨ")
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(QrXa1M59APiDRvHL6GJOgd7Et4):
		try: d0dafJYyF4P6GLs = isWjwHOERYXhAp0ZuNdKUgkCM7.path.getsize(QrXa1M59APiDRvHL6GJOgd7Et4)
		except: pass
		if not d0dafJYyF4P6GLs:
			try: d0dafJYyF4P6GLs = isWjwHOERYXhAp0ZuNdKUgkCM7.stat(QrXa1M59APiDRvHL6GJOgd7Et4).st_size
			except: pass
		if not d0dafJYyF4P6GLs:
			try:
				from pathlib import Path as lQoSOvFRes7Gd0qxpkYybaU3WNEr
				d0dafJYyF4P6GLs = lQoSOvFRes7Gd0qxpkYybaU3WNEr(QrXa1M59APiDRvHL6GJOgd7Et4).stat().st_size
			except: pass
		if d0dafJYyF4P6GLs: TnOEcKMSxN = oAXJCYqPgyGDtT(u"࠷ᛩ")
	return d0dafJYyF4P6GLs,TnOEcKMSxN
def P8vtuTghFN7lWIS(lUf17GAIR9eXrCwjVNDk8ps452,IpXWS7FYhOTJfzcwGDK5o1bd,showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(h5huy6MiXPNfQJF8(u"࠭ࠧᑬ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࠨᑭ"),vatyjK4hHAoZJ7rOq2lis(u"ࠨࠩᑮ"),N9olEh0ZMtpOivVfBLK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᑯ"),lUf17GAIR9eXrCwjVNDk8ps452+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡠࡳࡢ࡮ࠨᑰ")+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᑱ"))
		if VjwKs4GNQZ518kCl!=EmK3ObA0cwv9Wy(u"࠱ᛪ"): return
	g3gh0rZF6Bp1X8UmaWe9 = HVibA2ES8lY(u"ࡈࡤࡰࡸ࡫ᝣ")
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(lUf17GAIR9eXrCwjVNDk8ps452):
		for BBRzg6M9rsDEjJ,D8eY6yCT4gIpbXKRrkGBQ3SP,M8x7cvbo3JjtsQF in isWjwHOERYXhAp0ZuNdKUgkCM7.walk(lUf17GAIR9eXrCwjVNDk8ps452,topdown=l5mQdjWyczr7UJVnTp(u"ࡉࡥࡱࡹࡥᝤ")):
			for QrXa1M59APiDRvHL6GJOgd7Et4 in M8x7cvbo3JjtsQF:
				Ia9tjrpLcAyNuKvTxOnBWz7Z = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(BBRzg6M9rsDEjJ,QrXa1M59APiDRvHL6GJOgd7Et4)
				try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(Ia9tjrpLcAyNuKvTxOnBWz7Z)
				except Exception as RKq8Hda7ENycxDT1iZz9A3sLU5:
					if showDialogs and not g3gh0rZF6Bp1X8UmaWe9: KK47FGdX1TDfkb3AjHOQqghE(ZhqJoOtcmTVID65HwnLj(u"ࠬ࠭ᑲ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠧᑳ"),PiFkQ5pCJy7fbX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᑴ"),str(RKq8Hda7ENycxDT1iZz9A3sLU5))
					g3gh0rZF6Bp1X8UmaWe9 = ZEiR0StquOzca9lvPAndYIX(u"ࡘࡷࡻࡥᝥ")
			if IpXWS7FYhOTJfzcwGDK5o1bd:
				for dir in D8eY6yCT4gIpbXKRrkGBQ3SP:
					EQNv8ODh6mcjpsgWU = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(BBRzg6M9rsDEjJ,dir)
					try: isWjwHOERYXhAp0ZuNdKUgkCM7.rmdir(EQNv8ODh6mcjpsgWU)
					except: pass
		if IpXWS7FYhOTJfzcwGDK5o1bd:
			try: isWjwHOERYXhAp0ZuNdKUgkCM7.rmdir(BBRzg6M9rsDEjJ)
			except: pass
	if showDialogs and not g3gh0rZF6Bp1X8UmaWe9:
		KK47FGdX1TDfkb3AjHOQqghE(ttOu147wErcBvPaSMUY(u"ࠨࠩᑵ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠪᑶ"),PiFkQ5pCJy7fbX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᑷ"),PiFkQ5pCJy7fbX(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᑸ"))
		YTPut68WBVUNCvsEzg.setSetting(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᑹ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᑺ"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(WmaPChRdQk3YcXwI6zS(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᑻ"))
	return
def Ysrnya0A9CTWb4Bh2UHf5wv3EDP(WzeExBTV6h=N9olEh0ZMtpOivVfBLK(u"ࠨࠩᑼ")):
	inrDtz8mJqLpkPSldeyYjsEaBwA(PiFkQ5pCJy7fbX(u"ࠩࡶࡸࡴࡶࠧᑽ"))
	if WzeExBTV6h:
		JtqNjwFpevRmG9nDBlz5g0V = YTPut68WBVUNCvsEzg.getSetting(h5huy6MiXPNfQJF8(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫᑾ"))
		YTPut68WBVUNCvsEzg.setSetting(TWexH5PhS1(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᑿ"),ZhqJoOtcmTVID65HwnLj(u"ࠬ࠭ᒀ"))
		lmX9WoCBVcaysrT3NgkzbFtJUxw(WzeExBTV6h)
		YTPut68WBVUNCvsEzg.setSetting(N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧᒁ"),JtqNjwFpevRmG9nDBlz5g0V)
	B6B7iVh1qW5Py = YTPut68WBVUNCvsEzg.getSetting(ttOu147wErcBvPaSMUY(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᒂ"))
	if B6B7iVh1qW5Py==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫᒃ"): YTPut68WBVUNCvsEzg.setSetting(l5mQdjWyczr7UJVnTp(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ᒄ"),sbgu4D2RFMYKm(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭ᒅ"))
	elif B6B7iVh1qW5Py==h5huy6MiXPNfQJF8(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧᒆ"): YTPut68WBVUNCvsEzg.setSetting(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᒇ"),HH4JMrUDp3lq6hQ(u"࠭ࠧᒈ"))
	if YTPut68WBVUNCvsEzg.getSetting(FIHNSc5iuoZanQ2Ytl(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᒉ")) not in [l5mQdjWyczr7UJVnTp(u"ࠨࡃࡘࡘࡔ࠭ᒊ"),N9olEh0ZMtpOivVfBLK(u"ࠩࡖࡘࡔࡖࠧᒋ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࡅࡘࡑࠧᒌ")]: YTPut68WBVUNCvsEzg.setSetting(HVibA2ES8lY(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧᒍ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡇࡓࡌࠩᒎ"))
	if YTPut68WBVUNCvsEzg.getSetting(h5huy6MiXPNfQJF8(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᒏ")) not in [g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡂࡗࡗࡓࠬᒐ"),VH9MDo5z1kxNF07uRJI(u"ࠨࡕࡗࡓࡕ࠭ᒑ"),WmaPChRdQk3YcXwI6zS(u"ࠩࡄࡗࡐ࠭ᒒ")]: YTPut68WBVUNCvsEzg.setSetting(HH4JMrUDp3lq6hQ(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᒓ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࡆ࡙ࡋࠨᒔ"))
	qn4OFHeGVWjwJf3h1E2ZR = YTPut68WBVUNCvsEzg.getSetting(VOq8Ekue4F(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪᒕ"))
	yPYItiEgxhwB9TmWN6cAU = EO9Rts0AaGuk1qpPLXCY.executeJSONRPC(VH9MDo5z1kxNF07uRJI(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩᒖ"))
	if S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ᒗ") in str(yPYItiEgxhwB9TmWN6cAU) and qn4OFHeGVWjwJf3h1E2ZR in [QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫᒘ"),TWexH5PhS1(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨᒙ")]:
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(oAXJCYqPgyGDtT(u"࠱࠰࠴࠴࠵᛫"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(ttOu147wErcBvPaSMUY(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧᒚ"))
	if N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳᛭") and SMfClzGKOB12H3r9sRPvAJgwq6>-WmaPChRdQk3YcXwI6zS(u"࠳᛬"):
		I2XjYiNOlmyKG1EhR70q53vZ.setResolvedUrl(SMfClzGKOB12H3r9sRPvAJgwq6,EEvLoMzFqrlKce(u"ࡋࡧ࡬ࡴࡧᝦ"),Ko1p5u9jwG6rF.ListItem())
		UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡌࡡ࡭ࡵࡨᝧ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡌࡡ࡭ࡵࡨᝧ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࡌࡡ࡭ࡵࡨᝧ")
		I2XjYiNOlmyKG1EhR70q53vZ.endOfDirectory(SMfClzGKOB12H3r9sRPvAJgwq6,UkYj1KP0ou4q9rVfEgn2JQHI56BG,dqNLiYGAf7wWkOs1T6mRPp,Ng2qaFu7MTQ)
	return
def GPdwgNOcx9SLTD2(A4fgbO6kxXRhVZ2sMLjuN,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3):
	ll9khUfx3MjZ,xB2HvGaMhZ1u,KzriWR2sPTbwpEeZ,SexFNJLoXtDdpRHws8lZfYEO = hxg062nspYHPSuVKfkdC(gz1flZwncVutokL59RaGS3WeK)
	hLYopVN51jn0T6 = XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,ll9khUfx3MjZ,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ
	if A4fgbO6kxXRhVZ2sMLjuN:
		KLxMkaVlguvqPcF = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡸࡺࡲࠨᒛ"),VH9MDo5z1kxNF07uRJI(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᒜ"),hLYopVN51jn0T6)
		if KLxMkaVlguvqPcF:
			wZWH4u8XUFt3V5reszRQIcLvfiopO(sbgu4D2RFMYKm(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫᒝ"),gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2)
			return KLxMkaVlguvqPcF
	KLxMkaVlguvqPcF = dXM2DkYvVZ(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3)
	if KLxMkaVlguvqPcF and A4fgbO6kxXRhVZ2sMLjuN: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,PiFkQ5pCJy7fbX(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨᒞ"),hLYopVN51jn0T6,KLxMkaVlguvqPcF,A4fgbO6kxXRhVZ2sMLjuN)
	return KLxMkaVlguvqPcF
from RoLFk6gC81 import *
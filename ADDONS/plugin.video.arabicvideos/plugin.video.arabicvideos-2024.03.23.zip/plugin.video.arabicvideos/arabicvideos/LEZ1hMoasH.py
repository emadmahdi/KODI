# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'DAILYMOTION'
JJCLnkX4TozH7Bsjivfe = '_DLM_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
m0nJ6xfD21QG3FyNP4WlT7u = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][1]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text,type,ffGe7cURW0lhJVvQAiw8IB):
	if	 mode==400: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==401: cLCisPE3lX = ekRxU1Zb89PlVyYfSWQ(url,text)
	elif mode==402: cLCisPE3lX = nJOsHo5qdAa30TSRlb7w(url,text)
	elif mode==403: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url,text)
	elif mode==404: cLCisPE3lX = tNjwgv1Ys0SzDl9(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==405: cLCisPE3lX = Om3bd6CI2LiFvclJXz4tSh(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==406: cLCisPE3lX = uuHT4Gv0x6VFwmjznsNrMiy37PZJ(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==407: cLCisPE3lX = KLCh0Zs8p3X25YuDHF74aExJMyB(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==408: cLCisPE3lX = R5zJ1aTMAjcZPl(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==409: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==411: cLCisPE3lX = ydxPCv5btNjr0aDg8mQ(url,text)
	elif mode==412: cLCisPE3lX = YOXyBuP4HkZN3EWm6(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==413: cLCisPE3lX = yJK8TnLItS1Hw9Gp02ardfDWU(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==414: cLCisPE3lX = tmNvyTa8S3kK(text)
	elif mode==415: cLCisPE3lX = awR2VPrhEjLN3H4sxJBQmM7Dt(text,ffGe7cURW0lhJVvQAiw8IB)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الرئيسية','',414)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def nJOsHo5qdAa30TSRlb7w(url,xsTmMQuR5naiJIBY):
	if '/dm_' in url:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = WM1buqXnzf3Ba6Vp29l4gFD.headers
		if 'Location' in list(headers.keys()): url = HbiLZQKalC+headers['Location']
	xsTmMQuR5naiJIBY = '[COLOR FFC89008]'+xsTmMQuR5naiJIBY+'[/COLOR]'
	xsTmMQuR5naiJIBY = pKlkxV6UB13CIdgOP9FwDZzLqyn2(xsTmMQuR5naiJIBY)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: بث حي',url,411,'','','channel_lives_now')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: آخر الفيديوهات',url+'/videos',408)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: المميزة',url,411,'','','channel_featured_videos')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: قوائم التشغيل',url+'/playlists',407)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def pKlkxV6UB13CIdgOP9FwDZzLqyn2(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = Bd2o0J6aOASWvuD9HzY(title)
	return title
def JwYEQUDupG2WLPzHndc(url,jjcUIZ6zfqJx):
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U([url],nO6ukabcldeU,'video',url)
	return
def tNjwgv1Ys0SzDl9(search,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	iYvJPtR357SbyQf1 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysearchwords',search)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	if sort=='': iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysortmethod','')
	else: iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = HbiLZQKalC+'/search/'+search+'/videos'
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"videos"(.*?)"VideoConnection"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,title,zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,o3gHuBtrRN in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
			if '"' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace('"','')
			if '"' in zIPTQSjZFO4qnXADK1UvYwucgEW0t: zIPTQSjZFO4qnXADK1UvYwucgEW0t = zIPTQSjZFO4qnXADK1UvYwucgEW0t.replace('"','')
			if '"' in xsTmMQuR5naiJIBY: xsTmMQuR5naiJIBY = xsTmMQuR5naiJIBY.replace('"','')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+id
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			jjcUIZ6zfqJx = zIPTQSjZFO4qnXADK1UvYwucgEW0t+'::'+xsTmMQuR5naiJIBY
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,jjcUIZ6zfqJx)
		if '"hasNextPage":true' in qQXuaKpVrGLF3e5oidJ8YwDT0:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,404,'',ffGe7cURW0lhJVvQAiw8IB,search)
	return
def Om3bd6CI2LiFvclJXz4tSh(search,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	iYvJPtR357SbyQf1 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysearchwords',search)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	url = HbiLZQKalC+'/search/'+search+'/playlists'
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	items = T072lCzjYiuaeFtmJGV.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for id,name,fcv2EPdjt49pYl,zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY,o3gHuBtrRN,count in items:
		if '"' in fcv2EPdjt49pYl: fcv2EPdjt49pYl = fcv2EPdjt49pYl.replace('"','')
		if '"' in zIPTQSjZFO4qnXADK1UvYwucgEW0t: zIPTQSjZFO4qnXADK1UvYwucgEW0t = zIPTQSjZFO4qnXADK1UvYwucgEW0t.replace('"','')
		if '"' in xsTmMQuR5naiJIBY: xsTmMQuR5naiJIBY = xsTmMQuR5naiJIBY.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
		if '"' in count: count = count.replace('"','')
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
		jjcUIZ6zfqJx = zIPTQSjZFO4qnXADK1UvYwucgEW0t+'::'+xsTmMQuR5naiJIBY
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,401,o3gHuBtrRN,'',jjcUIZ6zfqJx)
	if '"hasNextPage":true' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,405,'',ffGe7cURW0lhJVvQAiw8IB,search)
	return
def uuHT4Gv0x6VFwmjznsNrMiy37PZJ(search,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	iYvJPtR357SbyQf1 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysearchwords',search)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	url = HbiLZQKalC+'/search/'+search+'/channels'
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"channels"(.*?)"ChannelConnection"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,name,o3gHuBtrRN in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+id
			title = 'CHNL:  '+name
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,402,o3gHuBtrRN,'',name)
		if '"hasNextPage":true' in qQXuaKpVrGLF3e5oidJ8YwDT0:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,406,'',ffGe7cURW0lhJVvQAiw8IB,search)
	return
def tmNvyTa8S3kK(WaPGxwlIKJo2qnz7MZ):
	iYvJPtR357SbyQf1 = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	OOvdzRcrlZwA7i3J = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	if OOvdzRcrlZwA7i3J:
		w4LBMXb9OYiTZtszx = cwiLy4IAVJj0pWCl7FGxokR('dict',OOvdzRcrlZwA7i3J)
		KDWFguoTPN8hHB2JpbZI1naLlXEfMV = w4LBMXb9OYiTZtszx['data']['home']['neon']['sections']['edges']
		if not WaPGxwlIKJo2qnz7MZ:
			n5p4V1xWM6ojgOkNEebqCGwQlT = []
			for OvhAXlE04xVD6cHKZqmfQC98e52snG in KDWFguoTPN8hHB2JpbZI1naLlXEfMV:
				NrOlMdAR0sLXcUa5DzP4mGE3I = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['title']
				if NrOlMdAR0sLXcUa5DzP4mGE3I not in n5p4V1xWM6ojgOkNEebqCGwQlT: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+NrOlMdAR0sLXcUa5DzP4mGE3I,'',414,'','',NrOlMdAR0sLXcUa5DzP4mGE3I)
				n5p4V1xWM6ojgOkNEebqCGwQlT.append(NrOlMdAR0sLXcUa5DzP4mGE3I)
		else:
			for OvhAXlE04xVD6cHKZqmfQC98e52snG in KDWFguoTPN8hHB2JpbZI1naLlXEfMV:
				NrOlMdAR0sLXcUa5DzP4mGE3I = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['title']
				if NrOlMdAR0sLXcUa5DzP4mGE3I==WaPGxwlIKJo2qnz7MZ:
					ajMV47CZyJW2d0SfDzIU = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['components']['edges']
					for eewCYL7TGzdxWrtVaA25F in ajMV47CZyJW2d0SfDzIU:
						fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = str(eewCYL7TGzdxWrtVaA25F['node']['duration'])
						title = Bd2o0J6aOASWvuD9HzY(eewCYL7TGzdxWrtVaA25F['node']['title'])
						title = title.replace('\/','/')
						OSIoG8zwkdhNyuQJrt = eewCYL7TGzdxWrtVaA25F['node']['xid']
						o3gHuBtrRN = eewCYL7TGzdxWrtVaA25F['node']['thumbnailx480']
						o3gHuBtrRN = o3gHuBtrRN.replace('\/','/')
						i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+OSIoG8zwkdhNyuQJrt
						QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	return
def awR2VPrhEjLN3H4sxJBQmM7Dt(search,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	iYvJPtR357SbyQf1 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysearchwords',search)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	url = HbiLZQKalC+'/search/'+search+'/lives'
	OOvdzRcrlZwA7i3J = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	if OOvdzRcrlZwA7i3J:
		w4LBMXb9OYiTZtszx = cwiLy4IAVJj0pWCl7FGxokR('dict',OOvdzRcrlZwA7i3J)
		try: KDWFguoTPN8hHB2JpbZI1naLlXEfMV = w4LBMXb9OYiTZtszx['data']['search']['lives']['edges']
		except: KDWFguoTPN8hHB2JpbZI1naLlXEfMV = []
		for OvhAXlE04xVD6cHKZqmfQC98e52snG in KDWFguoTPN8hHB2JpbZI1naLlXEfMV:
			name = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['title']
			OSIoG8zwkdhNyuQJrt = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['xid']
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+OSIoG8zwkdhNyuQJrt
			QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'LIVE: '+name,i8sFwPqo1vpEXR2VdHU5BmW,403)
		if '"hasNextPage":true' in OOvdzRcrlZwA7i3J:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,415,'',ffGe7cURW0lhJVvQAiw8IB,search)
	return
def YOXyBuP4HkZN3EWm6(search,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	iYvJPtR357SbyQf1 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysearchwords',search)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	url = HbiLZQKalC+'/search/'+search+'/topics'
	OOvdzRcrlZwA7i3J = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	if OOvdzRcrlZwA7i3J:
		w4LBMXb9OYiTZtszx = cwiLy4IAVJj0pWCl7FGxokR('dict',OOvdzRcrlZwA7i3J)
		try: KDWFguoTPN8hHB2JpbZI1naLlXEfMV = w4LBMXb9OYiTZtszx['data']['search']['topics']['edges']
		except: KDWFguoTPN8hHB2JpbZI1naLlXEfMV = []
		for OvhAXlE04xVD6cHKZqmfQC98e52snG in KDWFguoTPN8hHB2JpbZI1naLlXEfMV:
			name = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['name']
			OSIoG8zwkdhNyuQJrt = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['xid']
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/topic/'+OSIoG8zwkdhNyuQJrt
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'TOPIC: '+name,i8sFwPqo1vpEXR2VdHU5BmW,413)
		if '"hasNextPage":true' in OOvdzRcrlZwA7i3J:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,412,'',ffGe7cURW0lhJVvQAiw8IB,search)
	return
def yJK8TnLItS1Hw9Gp02ardfDWU(url,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	OSIoG8zwkdhNyuQJrt = url.split('/')[-1]
	iYvJPtR357SbyQf1 = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mytopicid',OSIoG8zwkdhNyuQJrt)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	OOvdzRcrlZwA7i3J = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	if OOvdzRcrlZwA7i3J:
		w4LBMXb9OYiTZtszx = cwiLy4IAVJj0pWCl7FGxokR('dict',OOvdzRcrlZwA7i3J)
		KDWFguoTPN8hHB2JpbZI1naLlXEfMV = w4LBMXb9OYiTZtszx['data']['topic']['videos']['edges']
		for OvhAXlE04xVD6cHKZqmfQC98e52snG in KDWFguoTPN8hHB2JpbZI1naLlXEfMV:
			fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = str(OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['duration'])
			title = Bd2o0J6aOASWvuD9HzY(OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['title'])
			title = title.replace('\/','/')
			OSIoG8zwkdhNyuQJrt = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['xid']
			o3gHuBtrRN = OvhAXlE04xVD6cHKZqmfQC98e52snG['node']['thumbnailx480']
			o3gHuBtrRN = o3gHuBtrRN.replace('\/','/')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+OSIoG8zwkdhNyuQJrt
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
		if '"hasNextPage":true' in OOvdzRcrlZwA7i3J:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,413,'',ffGe7cURW0lhJVvQAiw8IB)
	return
def ekRxU1Zb89PlVyYfSWQ(url,jjcUIZ6zfqJx):
	id = url.split('/')[-1]
	zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY = jjcUIZ6zfqJx.split('::',1)
	i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+zIPTQSjZFO4qnXADK1UvYwucgEW0t
	xsTmMQuR5naiJIBY = pKlkxV6UB13CIdgOP9FwDZzLqyn2(xsTmMQuR5naiJIBY)
	title = '[COLOR FFC89008]OWNER:  '+xsTmMQuR5naiJIBY+'[/COLOR]'
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,402,'','',xsTmMQuR5naiJIBY)
	iYvJPtR357SbyQf1 = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('myplaylistid',id)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"collection_videos"(.*?)"SectionEdge"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,title,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,o3gHuBtrRN,zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
			if '"' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace('"','')
			if '"' in zIPTQSjZFO4qnXADK1UvYwucgEW0t: zIPTQSjZFO4qnXADK1UvYwucgEW0t = zIPTQSjZFO4qnXADK1UvYwucgEW0t.replace('"','')
			if '"' in xsTmMQuR5naiJIBY: xsTmMQuR5naiJIBY = xsTmMQuR5naiJIBY.replace('"','')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+id
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			jjcUIZ6zfqJx = zIPTQSjZFO4qnXADK1UvYwucgEW0t+'::'+xsTmMQuR5naiJIBY
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,jjcUIZ6zfqJx)
	return
def R5zJ1aTMAjcZPl(url,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	WpHryfYS0dNkc9bJlgoI8ueAj3n = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	iYvJPtR357SbyQf1 = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mychannelid',WpHryfYS0dNkc9bJlgoI8ueAj3n)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysortmethod',sort)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,title,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY,o3gHuBtrRN in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
			if '"' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace('"','')
			if '"' in zIPTQSjZFO4qnXADK1UvYwucgEW0t: zIPTQSjZFO4qnXADK1UvYwucgEW0t = zIPTQSjZFO4qnXADK1UvYwucgEW0t.replace('"','')
			if '"' in xsTmMQuR5naiJIBY: xsTmMQuR5naiJIBY = xsTmMQuR5naiJIBY.replace('"','')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+id
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			jjcUIZ6zfqJx = zIPTQSjZFO4qnXADK1UvYwucgEW0t+'::'+xsTmMQuR5naiJIBY
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,jjcUIZ6zfqJx)
		if '"hasNextPage":true' in qQXuaKpVrGLF3e5oidJ8YwDT0:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,408,'',ffGe7cURW0lhJVvQAiw8IB)
	return
def KLCh0Zs8p3X25YuDHF74aExJMyB(url,ffGe7cURW0lhJVvQAiw8IB=''):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	WpHryfYS0dNkc9bJlgoI8ueAj3n = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	iYvJPtR357SbyQf1 = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mychannelid',WpHryfYS0dNkc9bJlgoI8ueAj3n)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagelimit','40')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mypagenumber',ffGe7cURW0lhJVvQAiw8IB)
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mysortmethod',sort)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,name,o3gHuBtrRN,count,fcv2EPdjt49pYl,zIPTQSjZFO4qnXADK1UvYwucgEW0t,xsTmMQuR5naiJIBY in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in fcv2EPdjt49pYl: fcv2EPdjt49pYl = fcv2EPdjt49pYl.replace('"','')
			if '"' in zIPTQSjZFO4qnXADK1UvYwucgEW0t: zIPTQSjZFO4qnXADK1UvYwucgEW0t = zIPTQSjZFO4qnXADK1UvYwucgEW0t.replace('"','')
			if '"' in xsTmMQuR5naiJIBY: xsTmMQuR5naiJIBY = xsTmMQuR5naiJIBY.replace('"','')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			jjcUIZ6zfqJx = zIPTQSjZFO4qnXADK1UvYwucgEW0t+'::'+xsTmMQuR5naiJIBY
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,401,o3gHuBtrRN,'',jjcUIZ6zfqJx)
		if '"hasNextPage":true' in qQXuaKpVrGLF3e5oidJ8YwDT0:
			ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)+1)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+ffGe7cURW0lhJVvQAiw8IB,url,407,'',ffGe7cURW0lhJVvQAiw8IB)
	return
def ydxPCv5btNjr0aDg8mQ(url,tJp8KQ6DmqIFVjbrBzn):
	WpHryfYS0dNkc9bJlgoI8ueAj3n = url.split('/')[3]
	iYvJPtR357SbyQf1 = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('mychannelid',WpHryfYS0dNkc9bJlgoI8ueAj3n)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1)
	import json as ZcJHDYM7OuKkIhBVSzoxgjp8r
	d7qCnMcW0TxkFvBJ5Z = ZcJHDYM7OuKkIhBVSzoxgjp8r.loads(qQXuaKpVrGLF3e5oidJ8YwDT0)
	try: items = d7qCnMcW0TxkFvBJ5Z['data']['channel'][tJp8KQ6DmqIFVjbrBzn]['edges']
	except: items = []
	if not items: QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'لا توجد نتائج','',9999)
	else:
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			UXKrs7JMbBD = Lw8JjEfuiW0VN9qHAcgRpMBdICS['node']
			OSIoG8zwkdhNyuQJrt = UXKrs7JMbBD['xid']
			keys = list(UXKrs7JMbBD.keys())
			d1rhOJbD8itYnMT06C9qyISK53f = UXKrs7JMbBD['__typename'].lower()
			if d1rhOJbD8itYnMT06C9qyISK53f=='channel':
				name = UXKrs7JMbBD['name']
				gaVrcKdiqO = UXKrs7JMbBD['displayName']
				title = 'CHNL:  '+gaVrcKdiqO
				o3gHuBtrRN = UXKrs7JMbBD['coverURLx375']
			else:
				name = UXKrs7JMbBD['channel']['name']
				gaVrcKdiqO = UXKrs7JMbBD['channel']['displayName']
				title = UXKrs7JMbBD['title']
				o3gHuBtrRN = UXKrs7JMbBD['thumbnailx360']
				if d1rhOJbD8itYnMT06C9qyISK53f=='live': title = 'LIVE:  '+title
			title = pKlkxV6UB13CIdgOP9FwDZzLqyn2(title)
			jjcUIZ6zfqJx = name+'::'+gaVrcKdiqO
			if ggl6zFuXNdYTDieHCqGKRnVx:
				title = title.encode('utf8')
				jjcUIZ6zfqJx = jjcUIZ6zfqJx.encode('utf8')
			if d1rhOJbD8itYnMT06C9qyISK53f=='channel':
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+OSIoG8zwkdhNyuQJrt
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,402,o3gHuBtrRN,'',jjcUIZ6zfqJx)
			else:
				if d1rhOJbD8itYnMT06C9qyISK53f=='video': fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = str(UXKrs7JMbBD['duration'])
				else: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = ''
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/video/'+OSIoG8zwkdhNyuQJrt
				QQmLIZC8uas9fNiJWOnhdGvgFR(d1rhOJbD8itYnMT06C9qyISK53f,JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,403,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,jjcUIZ6zfqJx)
	return
def vCFaW4Ab3PgZUJTLqNw0r5Efo2(iYvJPtR357SbyQf1):
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace(' \"',' \\"')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('\", ','\\", ')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('\n','\\n')
	iYvJPtR357SbyQf1 = iYvJPtR357SbyQf1.replace('")','\\")')
	hw1yQtzrBKnEY8X4PlgDveWT = QQmzKU9kGExpBdevhjwrTLl()
	headers = {"Authorization":hw1yQtzrBKnEY8X4PlgDveWT,"Origin":HbiLZQKalC}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',m0nJ6xfD21QG3FyNP4WlT7u,iYvJPtR357SbyQf1,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def QQmzKU9kGExpBdevhjwrTLl():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	wfzDEkWU95uI8qoFKJNd01Lcp2T = T072lCzjYiuaeFtmJGV.findall('var r="(.*?)",o="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	KFXdjyzQxC0EgMmH1S,hDeyBx60cvValM1p8LEzP = wfzDEkWU95uI8qoFKJNd01Lcp2T[-1]
	G7FDTxeJoNRS4O9lgMZ = 'https://graphql.api.dailymotion.com/oauth/token'
	gd1xLFRMPyIjWHOGzKV = 'client_credentials'
	data = {'client_id':KFXdjyzQxC0EgMmH1S,'client_secret':hDeyBx60cvValM1p8LEzP,'grant_type':gd1xLFRMPyIjWHOGzKV}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',G7FDTxeJoNRS4O9lgMZ,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	wfzDEkWU95uI8qoFKJNd01Lcp2T = T072lCzjYiuaeFtmJGV.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	jCqT183ydmOkcJ,ogpQaA5WZiylbFe2JECI = wfzDEkWU95uI8qoFKJNd01Lcp2T[0]
	hw1yQtzrBKnEY8X4PlgDveWT = ogpQaA5WZiylbFe2JECI+" "+jCqT183ydmOkcJ
	return hw1yQtzrBKnEY8X4PlgDveWT
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search,type=''):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not type and showDialogs:
		pbTw2WD1Gg0O = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('موقع ديلي موشن - اختر البحث',pbTw2WD1Gg0O)
		if tzgWIKy5xQL2kjm==-1: return
		elif tzgWIKy5xQL2kjm==0: type = 'videos?sortBy='
		elif tzgWIKy5xQL2kjm==1: type = 'videos?sortBy=RECENT'
		elif tzgWIKy5xQL2kjm==2: type = 'videos?sortBy=VIEW_COUNT'
		elif tzgWIKy5xQL2kjm==3: type = 'playlists'
		elif tzgWIKy5xQL2kjm==4: type = 'channels'
		elif tzgWIKy5xQL2kjm==5: type = 'topics'
		elif tzgWIKy5xQL2kjm==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in ZNpFGHa28C9WcoRb: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in ZNpFGHa28C9WcoRb: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in ZNpFGHa28C9WcoRb: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in ZNpFGHa28C9WcoRb: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in ZNpFGHa28C9WcoRb: type = 'lives'
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	if mmIKCGujwM: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: tNjwgv1Ys0SzDl9(search+'/'+type)
	elif 'playlists' in type: Om3bd6CI2LiFvclJXz4tSh(search)
	elif 'channels' in type: uuHT4Gv0x6VFwmjznsNrMiy37PZJ(search)
	elif 'topics' in type: YOXyBuP4HkZN3EWm6(search)
	elif 'lives' in type: awR2VPrhEjLN3H4sxJBQmM7Dt(search)
	return
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'MYCIMA'
headers = {'User-Agent':''}
JJCLnkX4TozH7Bsjivfe = '_MCM_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['مصارعة حرة','wwe']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==360: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==361: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==362: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==363: cLCisPE3lX = UAB8vizclM6XG4Pw(url,text)
	elif mode==364: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'CATEGORIES___'+text)
	elif mode==365: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'FILTERS___'+text)
	elif mode==366: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==369: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text,url)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع',HbiLZQKalC,369,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',HbiLZQKalC+'/AjaxCenter/RightBar',364)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',HbiLZQKalC+'/AjaxCenter/RightBar',365)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','MYCIMA-MENU-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('class="menu-item.*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title=='': continue
			if any(EYn2siOeDvQTk8KpS0Jl in title.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,366)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('hoverable activable(.*?)hoverable activable',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,366,o3gHuBtrRN)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','MYCIMA-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if 'class="Slider--Grid"' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',url,361,'','','featured')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="list--Tabsui"(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,361)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(DsaTBuMeVh180LSw,type=''):
	if '::' in DsaTBuMeVh180LSw:
		dCmKxk9BW310AXu4bJUHfY,url = DsaTBuMeVh180LSw.split('::')
		dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(dCmKxk9BW310AXu4bJUHfY,'url')
		url = dATnilvcrXxmZ1k5EP0KgBFDqYpy6+url
	else: url,dCmKxk9BW310AXu4bJUHfY = DsaTBuMeVh180LSw,DsaTBuMeVh180LSw
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','MYCIMA-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if type=='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='filters':
		tmEVko4qsghUX6WLx8KG7fOTB = [qQXuaKpVrGLF3e5oidJ8YwDT0.replace('\\/','/').replace('\\"','"')]
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
			if any(EYn2siOeDvQTk8KpS0Jl in title.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			o3gHuBtrRN = Bd2o0J6aOASWvuD9HzY(o3gHuBtrRN)
			title = Nkuqp0boKj41i9(title)
			title = Bd2o0J6aOASWvuD9HzY(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,363,o3gHuBtrRN)
			elif 'حلقة' in title:
				XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) +حلقة +\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
				if XSCYbwaqRBtopUc9H2QZu86gA5N: title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					BBRwQhFnJ08q9YVxOSya.append(title)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,363,o3gHuBtrRN)
			else:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,362,o3gHuBtrRN)
		if type=='filters':
			re8PLYqIQ6hN1vk503OTJng = T072lCzjYiuaeFtmJGV.findall('"more_button_page":(.*?),',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if re8PLYqIQ6hN1vk503OTJng:
				count = re8PLYqIQ6hN1vk503OTJng[0]
				i8sFwPqo1vpEXR2VdHU5BmW = url+'/offset/'+count
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة أخرى',i8sFwPqo1vpEXR2VdHU5BmW,361,'','','filters')
		elif type=='':
			tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if tmEVko4qsghUX6WLx8KG7fOTB:
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
				items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
					title = 'صفحة '+Nkuqp0boKj41i9(title)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,361)
	return
def UAB8vizclM6XG4Pw(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','MYCIMA-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qQXuaKpVrGLF3e5oidJ8YwDT0 = rygO0TzuEdiPcQDWZ8awSjm(qQXuaKpVrGLF3e5oidJ8YwDT0)
	name = T072lCzjYiuaeFtmJGV.findall('itemprop="item" href=".*?/series/(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if name: name = name[-1].replace('-',' ').strip('/')
	if 'موسم' in name and type=='':
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة','').strip(' ')
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة','').strip(' ')
	else: name = name
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="Seasons--Episodes"(.*?)</singlesection',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		if type=='':
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,363,'','','episodes')
		if len(a26IqBkAXRPrwCOgFDb)==0:
			MwELA7bGROd1uohvUNKpsrDVWnSyf4 = T072lCzjYiuaeFtmJGV.findall('class="Episodes--Seasons--Episodes"(.*?)&&',Zsh7mUdwjHobLyMz6WKJGVl1cgeR+'&&',T072lCzjYiuaeFtmJGV.DOTALL)
			if MwELA7bGROd1uohvUNKpsrDVWnSyf4: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = MwELA7bGROd1uohvUNKpsrDVWnSyf4[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<episodeTitle>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				title = name+' - '+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,362)
	if len(a26IqBkAXRPrwCOgFDb)==0:
		title = T072lCzjYiuaeFtmJGV.findall('<title>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,url,362)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','MYCIMA-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl:
		Y9xGJcRLIBNOftSQ5HE1jTysl = [Y9xGJcRLIBNOftSQ5HE1jTysl[0][0],Y9xGJcRLIBNOftSQ5HE1jTysl[0][1]]
		if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-url="(.*?)".*?strong>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if name=='سيرفر ماي سيما': name = 'mycima'
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="List--Download(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in items:
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			Q5OAspyiXV1lx8930qLGD = T072lCzjYiuaeFtmJGV.findall('\d\d\d+',Q5OAspyiXV1lx8930qLGD,T072lCzjYiuaeFtmJGV.DOTALL)
			if Q5OAspyiXV1lx8930qLGD: Q5OAspyiXV1lx8930qLGD = '____'+Q5OAspyiXV1lx8930qLGD[0]
			else: Q5OAspyiXV1lx8930qLGD = ''
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named=mycima'+'__download'+Q5OAspyiXV1lx8930qLGD
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search,Q1kl3GceHmtxBS7quzpPia=''):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	M7oS6tLhdx3ke8qPX4mFA = ['/list','/','/list/series','/list/anime','/list/tv']
	FOqwn36QHCgpI8SXRNT1P2mdE = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر النوع المطلوب:', FOqwn36QHCgpI8SXRNT1P2mdE)
		if tzgWIKy5xQL2kjm==-1: return
	else: tzgWIKy5xQL2kjm = 0
	if Q1kl3GceHmtxBS7quzpPia=='':
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,'','',False,'','MYCIMA-SEARCH-1st')
		Q1kl3GceHmtxBS7quzpPia = WM1buqXnzf3Ba6Vp29l4gFD.headers['Location']
		Q1kl3GceHmtxBS7quzpPia = Q1kl3GceHmtxBS7quzpPia.strip('/')
	ll9khUfx3MjZ = Q1kl3GceHmtxBS7quzpPia+'/search/'+search+M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
	return
def hr0qteMSui7ZzxCoE(DsaTBuMeVh180LSw,filter):
	if '??' in DsaTBuMeVh180LSw: url = DsaTBuMeVh180LSw.split('//getposts??')[0]
	else: url = DsaTBuMeVh180LSw
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='CATEGORIES':
		if gdCckvHqSI7Ms1OptGaRhuWfeoQ[0]+'==' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = gdCckvHqSI7Ms1OptGaRhuWfeoQ[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(gdCckvHqSI7Ms1OptGaRhuWfeoQ[0:-1])):
			if gdCckvHqSI7Ms1OptGaRhuWfeoQ[jV1Z7MWOa80gbwJY64nL5]+'==' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = gdCckvHqSI7Ms1OptGaRhuWfeoQ[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+ZecS1yJOzVutgX0qiH3NER+'==0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+ZecS1yJOzVutgX0qiH3NER+'==0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		ll9khUfx3MjZ = url+'//getposts??'+YupaFCoAIicOnZNd
	elif type=='FILTERS':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'//getposts??'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(ll9khUfx3MjZ,DsaTBuMeVh180LSw)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها ',zFHuCf5Gpms8XE2MbI0Tc,361,'','','filters')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',zFHuCf5Gpms8XE2MbI0Tc,361,'','','filters')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','MYCIMA-FILTERS_MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('\\"','"').replace('\\/','/')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<mycima--filter(.*?)</mycima--filter>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',Zsh7mUdwjHobLyMz6WKJGVl1cgeR+'<filterbox',T072lCzjYiuaeFtmJGV.DOTALL)
	dict = {}
	for cfWiG8bKuYoq32vDE51hCUxPT,name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		name = Bd2o0J6aOASWvuD9HzY(name)
		if 'interest' in cfWiG8bKuYoq32vDE51hCUxPT: continue
		items = T072lCzjYiuaeFtmJGV.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if '==' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='CATEGORIES':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<=1:
				if cfWiG8bKuYoq32vDE51hCUxPT==gdCckvHqSI7Ms1OptGaRhuWfeoQ[-1]: Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'CATEGORIES___'+Dwqu0Ws9eK)
				return
			else:
				zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(ll9khUfx3MjZ,DsaTBuMeVh180LSw)
				if cfWiG8bKuYoq32vDE51hCUxPT==gdCckvHqSI7Ms1OptGaRhuWfeoQ[-1]:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',zFHuCf5Gpms8XE2MbI0Tc,361,'','','filters')
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,364,'','',Dwqu0Ws9eK)
		elif type=='FILTERS':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'==0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'==0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name+': الجميع',ll9khUfx3MjZ,365,'','',Dwqu0Ws9eK+'_FORGETRESULTS_')
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			name = Bd2o0J6aOASWvuD9HzY(name)
			jwanU8orZtdFLNvM4EkHphWKzP = Bd2o0J6aOASWvuD9HzY(jwanU8orZtdFLNvM4EkHphWKzP)
			if EYn2siOeDvQTk8KpS0Jl=='r' or EYn2siOeDvQTk8KpS0Jl=='nc-17': continue
			if any(EYn2siOeDvQTk8KpS0Jl in jwanU8orZtdFLNvM4EkHphWKzP.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			if 'الكل' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			if 'n-a' in EYn2siOeDvQTk8KpS0Jl: continue
			if jwanU8orZtdFLNvM4EkHphWKzP=='': jwanU8orZtdFLNvM4EkHphWKzP = EYn2siOeDvQTk8KpS0Jl
			UliDv052e7j = jwanU8orZtdFLNvM4EkHphWKzP
			gBQxOqabPovs7y = T072lCzjYiuaeFtmJGV.findall('<name>(.*?)</name>',jwanU8orZtdFLNvM4EkHphWKzP,T072lCzjYiuaeFtmJGV.DOTALL)
			if gBQxOqabPovs7y: UliDv052e7j = gBQxOqabPovs7y[0]
			tKBSN4Zgn9CDb = name+': '+UliDv052e7j
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = tKBSN4Zgn9CDb
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'=='+UliDv052e7j
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'=='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			if type=='FILTERS':
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url,365,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and gdCckvHqSI7Ms1OptGaRhuWfeoQ[-2]+'==' in cghHqoyS13upLUdz8bkXO7wlPK:
				YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'modified_filters')
				dCmKxk9BW310AXu4bJUHfY = url+'//getposts??'+YupaFCoAIicOnZNd
				zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(dCmKxk9BW310AXu4bJUHfY,DsaTBuMeVh180LSw)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,zFHuCf5Gpms8XE2MbI0Tc,361,'','','filters')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url,364,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
gdCckvHqSI7Ms1OptGaRhuWfeoQ = ['genre','release-year','nation']
XXVdjvcBrSY1yNKf = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def N1GlK9FfkpJTcmRjrO8qUM(ll9khUfx3MjZ,dCmKxk9BW310AXu4bJUHfY):
	if '/AjaxCenter/RightBar' in ll9khUfx3MjZ: ll9khUfx3MjZ = ll9khUfx3MjZ.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	ll9khUfx3MjZ = ll9khUfx3MjZ.replace('//getposts??','::/AjaxCenter/Filtering/')
	ll9khUfx3MjZ = ll9khUfx3MjZ.replace('==','/')
	ll9khUfx3MjZ = ll9khUfx3MjZ.replace('&&','/')
	return ll9khUfx3MjZ
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&&')
	H5y1ofSbMzmN7JI,lZrWcL5Ts4SK78wXChVy16DPRkv9 = {},''
	if '==' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('==')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	for key in XXVdjvcBrSY1yNKf:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if '%' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = K3PukgCEDY(EYn2siOeDvQTk8KpS0Jl)
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&&'+key+'=='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&&'+key+'=='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&&')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
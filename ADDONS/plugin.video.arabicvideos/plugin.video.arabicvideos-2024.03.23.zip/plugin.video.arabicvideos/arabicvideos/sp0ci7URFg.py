# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
headers = { 'User-Agent' : '' }
nO6ukabcldeU = 'AKOAMCAM'
JJCLnkX4TozH7Bsjivfe = '_AKC_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['مصارعة']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==350: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==351: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==352: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==353: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==354: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'FILTERS___'+text)
	elif mode==355: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'CATEGORIES___'+text)
	elif mode==356: cLCisPE3lX = mNJ2Vln3r5uEhqzk8(url)
	elif mode==357: cLCisPE3lX = wil7QqY43Pv(url)
	elif mode==359: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',HbiLZQKalC,356)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',HbiLZQKalC,357)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,HbiLZQKalC,'',headers,'','AKOAMCAM-MENU-1st')
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('recently-container.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ: ll9khUfx3MjZ = ll9khUfx3MjZ[0]
	else: ll9khUfx3MjZ = HbiLZQKalC
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'اضيف حديثا',ll9khUfx3MjZ,351)
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('@id":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ: ll9khUfx3MjZ = ll9khUfx3MjZ[0]
	else: ll9khUfx3MjZ = HbiLZQKalC
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',ll9khUfx3MjZ,351,'','','featured')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-categories-list(.*?)main-categories-list',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?class="font.*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,351)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="categories-box(.*?)<footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
			if title not in OZYvGX7EMx05KH1fI: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,351)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def mNJ2Vln3r5uEhqzk8(website=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','AKOAMCAM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu(.*?)<nav',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?text">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI:
				title = title+' مصنفة'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,355)
		if website=='': QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def wil7QqY43Pv(website=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','AKOAMCAM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu(.*?)<nav',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?text">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI:
				title = title+' مفلترة'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,354)
		if website=='': QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(vZs8PpIdBUNQTjnbEymoYx6X,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('swiper-container(.*?)swiper-button-prev',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="container"(.*?)main-footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		BBRwQhFnJ08q9YVxOSya = []
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|الحلقه) \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
				if XSCYbwaqRBtopUc9H2QZu86gA5N:
					title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
					if title not in BBRwQhFnJ08q9YVxOSya:
						QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,352,o3gHuBtrRN)
						BBRwQhFnJ08q9YVxOSya.append(title)
			elif 'مسلسل' in title:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,352,o3gHuBtrRN)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,353,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href=["\'](.*?)["\'].*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,351)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	url = HbiLZQKalC + '/?s='+xC2GuEcJKk3t4Uh
	cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def UAB8vizclM6XG4Pw(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('text-white">الحلقات(.*?)<header',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		Ad5sCEYHjxzg3yK = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in Ad5sCEYHjxzg3yK:
			if 'الحلقة' in title or 'الحلقه' in title: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,353,o3gHuBtrRN)
	else:
		o3gHuBtrRN = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Icon')
		if qQXuaKpVrGLF3e5oidJ8YwDT0.count('<title>')>1: title = T072lCzjYiuaeFtmJGV.findall('<title>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[1]
		else: title = 'رابط التشغيل'
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,url,353,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL = [],[]
	eZEUu7NtroqJ2 = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = eZEUu7NtroqJ2.content
	GdflFVny9zZNjP1kX2hIY = T072lCzjYiuaeFtmJGV.findall('post_id=(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GdflFVny9zZNjP1kX2hIY:
		GdflFVny9zZNjP1kX2hIY = GdflFVny9zZNjP1kX2hIY[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':GdflFVny9zZNjP1kX2hIY}
		ll9khUfx3MjZ = HbiLZQKalC+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		IluSp7QVbq5KCiFx0WXARa = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'POST',ll9khUfx3MjZ,data,headers,'','','AKOAMCAM-PLAY-1st')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = IluSp7QVbq5KCiFx0WXARa.content
		items = T072lCzjYiuaeFtmJGV.findall('data-server="(.*?)".*?class="text">(.*?)<',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		for Q3JykLsCBquDPihaMNV,name in items:
			i8sFwPqo1vpEXR2VdHU5BmW = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?postid='+GdflFVny9zZNjP1kX2hIY+'&serverid='+Q3JykLsCBquDPihaMNV+'?named='+name+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(name)
		ll9khUfx3MjZ = HbiLZQKalC+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		IluSp7QVbq5KCiFx0WXARa = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'POST',ll9khUfx3MjZ,data,headers,'','','AKOAMCAM-PLAY-1st')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = IluSp7QVbq5KCiFx0WXARa.content
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?class="text">(.*?)<',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.strip(' ')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def hr0qteMSui7ZzxCoE(url,filter):
	aKqQ1yXlIcDoxtdCmunE = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='CATEGORIES':
		if aKqQ1yXlIcDoxtdCmunE[0]+'=' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(aKqQ1yXlIcDoxtdCmunE[0:-1])):
			if aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5]+'=' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'all')
		ll9khUfx3MjZ = url+'?'+YupaFCoAIicOnZNd
	elif type=='FILTERS':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'all')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'?'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها',ll9khUfx3MjZ,351,'','1')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',ll9khUfx3MjZ,351,'','1')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<form id(.*?)</form>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	dict = {}
	for cfWiG8bKuYoq32vDE51hCUxPT,name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		items = T072lCzjYiuaeFtmJGV.findall('<option(.*?)>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if '=' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='CATEGORIES':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<=1:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'CATEGORIES___'+Dwqu0Ws9eK)
				return
			else:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,351,'','1')
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,355,'','',Dwqu0Ws9eK)
		elif type=='FILTERS':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع : '+name,ll9khUfx3MjZ,354,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			if 'value' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = jwanU8orZtdFLNvM4EkHphWKzP
			else: EYn2siOeDvQTk8KpS0Jl = T072lCzjYiuaeFtmJGV.findall('"(.*?)"',EYn2siOeDvQTk8KpS0Jl,T072lCzjYiuaeFtmJGV.DOTALL)[0]
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = jwanU8orZtdFLNvM4EkHphWKzP
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+jwanU8orZtdFLNvM4EkHphWKzP
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			title = jwanU8orZtdFLNvM4EkHphWKzP+' : '#+dict[cfWiG8bKuYoq32vDE51hCUxPT]['0']
			title = jwanU8orZtdFLNvM4EkHphWKzP+' : '+name
			if type=='FILTERS': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,354,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='CATEGORIES' and aKqQ1yXlIcDoxtdCmunE[-2]+'=' in cghHqoyS13upLUdz8bkXO7wlPK:
				YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'all')
				dCmKxk9BW310AXu4bJUHfY = url+'?'+YupaFCoAIicOnZNd
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,dCmKxk9BW310AXu4bJUHfY,351,'','1')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,355,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&')
	H5y1ofSbMzmN7JI = {}
	if '=' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = ''
	Dx5lzy4Anw63Lt1SsNm2rhk = ['cat','genre','release-year','quality','orderby']
	for key in Dx5lzy4Anw63Lt1SsNm2rhk:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
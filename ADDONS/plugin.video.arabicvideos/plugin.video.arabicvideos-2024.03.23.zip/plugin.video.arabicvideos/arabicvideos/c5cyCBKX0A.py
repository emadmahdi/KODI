# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'EGYBESTVIP'
JJCLnkX4TozH7Bsjivfe = '_EGV_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,ffGe7cURW0lhJVvQAiw8IB,text):
	if   mode==220: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==221: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==222: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==223: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==224: cLCisPE3lX = hr0qteMSui7ZzxCoE(url)
	elif mode==229: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','EGYBEST-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="i i-home"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,222)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="ba(.*?)<script',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,221)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if 'html' not in i8sFwPqo1vpEXR2VdHU5BmW: continue
			if not i8sFwPqo1vpEXR2VdHU5BmW.endswith('/'): QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,221)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="rs_scroll"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,224)
	return
def hr0qteMSui7ZzxCoE(url):
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',url,221)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="sub_nav(.*?)id="movies',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".+?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if i8sFwPqo1vpEXR2VdHU5BmW=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,221)
	else: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB='1'):
	if ffGe7cURW0lhJVvQAiw8IB=='': ffGe7cURW0lhJVvQAiw8IB = '1'
	if '/search' in url or '?' in url: ll9khUfx3MjZ = url + '&'
	else: ll9khUfx3MjZ = url + '?'
	ll9khUfx3MjZ = ll9khUfx3MjZ + 'page=' + ffGe7cURW0lhJVvQAiw8IB
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('class="pda"(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[-1]
	elif '/series/' in url:
		tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('class="owl-carousel owl-carousel(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	else:
		tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('id="movies(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[-1]
	items = T072lCzjYiuaeFtmJGV.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		title = Nkuqp0boKj41i9(title)
		if '/movie/' in i8sFwPqo1vpEXR2VdHU5BmW or '/episode' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW.rstrip('/'),223,o3gHuBtrRN)
		else:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,221,o3gHuBtrRN)
	if len(items)>=16:
		WPb0YhHqkgvMVK = ['/movies','/tv','/search','/trending']
		ffGe7cURW0lhJVvQAiw8IB = int(ffGe7cURW0lhJVvQAiw8IB)
		if any(EYn2siOeDvQTk8KpS0Jl in url for EYn2siOeDvQTk8KpS0Jl in WPb0YhHqkgvMVK):
			for T0T6I8Jqo4jwQNFRsUbtr in range(0,1000,100):
				if int(ffGe7cURW0lhJVvQAiw8IB/100)*100==T0T6I8Jqo4jwQNFRsUbtr:
					for jV1Z7MWOa80gbwJY64nL5 in range(T0T6I8Jqo4jwQNFRsUbtr,T0T6I8Jqo4jwQNFRsUbtr+100,10):
						if int(ffGe7cURW0lhJVvQAiw8IB/10)*10==jV1Z7MWOa80gbwJY64nL5:
							for fLnhm7qCejV4ciIvAk in range(jV1Z7MWOa80gbwJY64nL5,jV1Z7MWOa80gbwJY64nL5+10,1):
								if not ffGe7cURW0lhJVvQAiw8IB==fLnhm7qCejV4ciIvAk and fLnhm7qCejV4ciIvAk!=0:
									QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+str(fLnhm7qCejV4ciIvAk),url,221,'',str(fLnhm7qCejV4ciIvAk))
						elif jV1Z7MWOa80gbwJY64nL5!=0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+str(jV1Z7MWOa80gbwJY64nL5),url,221,'',str(jV1Z7MWOa80gbwJY64nL5))
						else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+str(1),url,221,'',str(1))
				elif T0T6I8Jqo4jwQNFRsUbtr!=0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+str(T0T6I8Jqo4jwQNFRsUbtr),url,221,'',str(T0T6I8Jqo4jwQNFRsUbtr))
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+str(1),url,221)
	return
def JwYEQUDupG2WLPzHndc(url):
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'','','','EGYBESTVIP-PLAY-1st')
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('<td>التصنيف</td>.*?">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	sYbhAigGJdnS3Nk7VpD0TZx1FPao8,zLjwTA0QUJ = '',''
	GTkZFxNtYijUc10m,Ls1iRgGr7KMXejkZ0D3m6HJ2FWl4ox = qQXuaKpVrGLF3e5oidJ8YwDT0,qQXuaKpVrGLF3e5oidJ8YwDT0
	VXR5IGMoH6sUihSmpW1Fgwy = T072lCzjYiuaeFtmJGV.findall('show_dl api" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if VXR5IGMoH6sUihSmpW1Fgwy:
		for i8sFwPqo1vpEXR2VdHU5BmW in VXR5IGMoH6sUihSmpW1Fgwy:
			if '/watch/' in i8sFwPqo1vpEXR2VdHU5BmW: sYbhAigGJdnS3Nk7VpD0TZx1FPao8 = i8sFwPqo1vpEXR2VdHU5BmW
			elif '/download/' in i8sFwPqo1vpEXR2VdHU5BmW: zLjwTA0QUJ = i8sFwPqo1vpEXR2VdHU5BmW
		if sYbhAigGJdnS3Nk7VpD0TZx1FPao8!='': GTkZFxNtYijUc10m = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,sYbhAigGJdnS3Nk7VpD0TZx1FPao8,'','','','EGYBESTVIP-PLAY-2nd')
		if zLjwTA0QUJ!='': Ls1iRgGr7KMXejkZ0D3m6HJ2FWl4ox = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,zLjwTA0QUJ,'','','','EGYBESTVIP-PLAY-3rd')
	VuqcBkfJUKEFyOTpzPW186dYjl0D = T072lCzjYiuaeFtmJGV.findall('id="video".*?data-src="(.*?)"',GTkZFxNtYijUc10m,T072lCzjYiuaeFtmJGV.DOTALL)
	if VuqcBkfJUKEFyOTpzPW186dYjl0D:
		ll9khUfx3MjZ = VuqcBkfJUKEFyOTpzPW186dYjl0D[0]
		if ll9khUfx3MjZ!='' and 'uploaded.egybest.download' in ll9khUfx3MjZ and '/?id=_' not in ll9khUfx3MjZ:
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'','','','EGYBESTVIP-PLAY-4th')
			ZZYFNtWoD3u = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)" title="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if ZZYFNtWoD3u:
				for i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD in ZZYFNtWoD3u:
					M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=ed.egybest.do__watch__mp4__'+Q5OAspyiXV1lx8930qLGD)
			else:
				dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ll9khUfx3MjZ.split('/')[2]
				M7oS6tLhdx3ke8qPX4mFA.append(ll9khUfx3MjZ+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__watch')
		elif ll9khUfx3MjZ!='':
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ll9khUfx3MjZ.split('/')[2]
			M7oS6tLhdx3ke8qPX4mFA.append(ll9khUfx3MjZ+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__watch')
	iiscz82unobTW = T072lCzjYiuaeFtmJGV.findall('<table class="dls_table(.*?)</table>',Ls1iRgGr7KMXejkZ0D3m6HJ2FWl4ox,T072lCzjYiuaeFtmJGV.DOTALL)
	if iiscz82unobTW:
		iiscz82unobTW = iiscz82unobTW[0]
		FmapVdZU1tswESB8 = T072lCzjYiuaeFtmJGV.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',iiscz82unobTW,T072lCzjYiuaeFtmJGV.DOTALL)
		if FmapVdZU1tswESB8:
			for Q5OAspyiXV1lx8930qLGD,i8sFwPqo1vpEXR2VdHU5BmW in FmapVdZU1tswESB8:
				if 'myegyvip' not in i8sFwPqo1vpEXR2VdHU5BmW: continue
				if i8sFwPqo1vpEXR2VdHU5BmW.count('/')>=2:
					dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = i8sFwPqo1vpEXR2VdHU5BmW.split('/')[2]
					M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__download__mp4__'+Q5OAspyiXV1lx8930qLGD)
	onDef3aEjYX5lhq = []
	for i8sFwPqo1vpEXR2VdHU5BmW in M7oS6tLhdx3ke8qPX4mFA:
		onDef3aEjYX5lhq.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(onDef3aEjYX5lhq,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,HbiLZQKalC,'','','','EGYBESTVIP-SEARCH-1st')
	cGaExo7bmhAn2QwIgMpWfzO = T072lCzjYiuaeFtmJGV.findall('name="_token" value="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if cGaExo7bmhAn2QwIgMpWfzO:
		url = HbiLZQKalC+'/search?_token='+cGaExo7bmhAn2QwIgMpWfzO[0]+'&q='+xC2GuEcJKk3t4Uh
		Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
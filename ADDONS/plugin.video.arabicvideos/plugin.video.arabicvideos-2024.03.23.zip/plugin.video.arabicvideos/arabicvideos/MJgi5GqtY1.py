# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'BOKRA'
JJCLnkX4TozH7Bsjivfe = '_BKR_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
headers = {'User-Agent':''}
OZYvGX7EMx05KH1fI = ['افلام للكبار','بكرا TV']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==370: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==371: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==372: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==374: cLCisPE3lX = ppBAD3ol4m1T(url)
	elif mode==375: cLCisPE3lX = VREj4tUeWohpb2FT(url)
	elif mode==376: cLCisPE3lX = i8iUFOpVJIgoRLysr9z6TKaG(0,url)
	elif mode==377: cLCisPE3lX = i8iUFOpVJIgoRLysr9z6TKaG(1,url)
	elif mode==379: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','BOKRA-MENU-1st')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('right-side(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',HbiLZQKalC,375)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الأحدث',HbiLZQKalC,376)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'قائمة الممثلين',HbiLZQKalC,374)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="container"(.*?)top-menu',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items[7:]:
			title = title.strip(' ')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items[0:7]:
			title = title.strip(' ')
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371)
	return
def ppBAD3ol4m1T(website=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','BOKRA-ACTORSMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="row cat Tags"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)" title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if 'http' in i8sFwPqo1vpEXR2VdHU5BmW: continue
			else: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371)
	return
def VREj4tUeWohpb2FT(website=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,'','','','','BOKRA-FEATURED-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"MainContent"(.*?)main-title2',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				o3gHuBtrRN = o3gHuBtrRN.replace('://',':///').replace('//','/').replace(' ','%20')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,372,o3gHuBtrRN)
	return
def i8iUFOpVJIgoRLysr9z6TKaG(id,website=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,'','','','','BOKRA-WATCHINGNOW-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-title2(.*?)class="row',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[id]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
				o3gHuBtrRN = o3gHuBtrRN.replace('://',':///').replace('//','/').replace(' ','%20')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,372,o3gHuBtrRN)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,yc2P5uiMAe0=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','BOKRA-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if 'vidpage_' in url:
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('href="(/Album-.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if i8sFwPqo1vpEXR2VdHU5BmW:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW[0]
			Dhm1GLpdYu4xwZzSQlEtvNC3ga(i8sFwPqo1vpEXR2VdHU5BmW)
			return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class=" subcats"(.*?)class="col-md-3',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if yc2P5uiMAe0=='' and tmEVko4qsghUX6WLx8KG7fOTB and tmEVko4qsghUX6WLx8KG7fOTB[0].count('href')>1:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',url,371,'','','titles')
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)" title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title.strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371)
	else:
		BBRwQhFnJ08q9YVxOSya = []
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="col-md-3(.*?)col-xs-12',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="col-sm-8"(.*?)col-xs-12',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
				title = title.strip(' ')
				o3gHuBtrRN = o3gHuBtrRN.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in i8sFwPqo1vpEXR2VdHU5BmW:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371,o3gHuBtrRN)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) - +الحلقة +\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
					if XSCYbwaqRBtopUc9H2QZu86gA5N: title = '_MOD_مسلسل '+XSCYbwaqRBtopUc9H2QZu86gA5N[0]
					if title not in BBRwQhFnJ08q9YVxOSya:
						BBRwQhFnJ08q9YVxOSya.append(title)
						QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371,o3gHuBtrRN)
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,372,o3gHuBtrRN)
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('class="".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
				title = 'صفحة '+Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,371,'','','titles')
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','BOKRA-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('label-success mrg-btm-5 ">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	dCmKxk9BW310AXu4bJUHfY = ''
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('var url = "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ: ll9khUfx3MjZ = ll9khUfx3MjZ[0]
	else: ll9khUfx3MjZ = url.replace('/vidpage_','/Play/')
	if 'http' not in ll9khUfx3MjZ: ll9khUfx3MjZ = HbiLZQKalC+ll9khUfx3MjZ
	ll9khUfx3MjZ = ll9khUfx3MjZ.strip('-')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',ll9khUfx3MjZ,'','','','','BOKRA-PLAY-2nd')
	IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
	dCmKxk9BW310AXu4bJUHfY = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
	if dCmKxk9BW310AXu4bJUHfY:
		dCmKxk9BW310AXu4bJUHfY = dCmKxk9BW310AXu4bJUHfY[-1]
		if 'http' not in dCmKxk9BW310AXu4bJUHfY: dCmKxk9BW310AXu4bJUHfY = 'http:'+dCmKxk9BW310AXu4bJUHfY
		if '/PLAY/' not in ll9khUfx3MjZ:
			if 'embed.min.js' in dCmKxk9BW310AXu4bJUHfY:
				UUT4N8BngoQ7EO3lV9iwRfebA = T072lCzjYiuaeFtmJGV.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
				if UUT4N8BngoQ7EO3lV9iwRfebA:
					QB1k7FiwT8Kr2SczGCHfM, z9FwJbVcXT6s2xO = UUT4N8BngoQ7EO3lV9iwRfebA[0]
					dCmKxk9BW310AXu4bJUHfY = ClNwy8MJfjoTq4ZFxYvmasD(dCmKxk9BW310AXu4bJUHfY,'url')+'/v2/'+QB1k7FiwT8Kr2SczGCHfM+'/config/'+z9FwJbVcXT6s2xO+'.json'
		import d3obAhVeNX
		d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U([dCmKxk9BW310AXu4bJUHfY],nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/Search/'+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
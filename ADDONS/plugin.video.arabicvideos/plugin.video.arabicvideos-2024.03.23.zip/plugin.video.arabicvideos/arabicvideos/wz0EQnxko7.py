# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'RANDOMS'
JJCLnkX4TozH7Bsjivfe = '_LST_'
SSDhoMgbviPWlQpTYFxVE = 4
KHpnOsTAjv4 = 10
def F5M9LsnokGPEQ2XYfO7cuyr(EHnSrqQ7BvmGlOgYZdhTbCRtswA,url,yv8XxUjorzB2CRA4Jife73VMklHp,ffGe7cURW0lhJVvQAiw8IB,RLg3NjAdqfTMl):
	try: xDfZGsilBXPVgdF427SeQkaE = str(RLg3NjAdqfTMl['folder'])
	except: xDfZGsilBXPVgdF427SeQkaE = ''
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==160: cLCisPE3lX = lD8xr3zag19KuC()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==161: cLCisPE3lX = uYEMRodmJp3(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==162: cLCisPE3lX = g2NJdvoyTEGsj(yv8XxUjorzB2CRA4Jife73VMklHp,162)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==163: cLCisPE3lX = g2NJdvoyTEGsj(yv8XxUjorzB2CRA4Jife73VMklHp,163)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==164: cLCisPE3lX = lFArQV3CuLoe4kN6gOaHq(yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==165: cLCisPE3lX = L5yEeTISQU7VxcqKkZ8f0s(url,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==166: cLCisPE3lX = f70G6lTizaW3nXKhg1Avqp95IUFL(url,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==167: cLCisPE3lX = fVUmasELgbZF0kSOYWMejhy5BTD(url,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==168: cLCisPE3lX = OOwPMbm8akBQre6sy(url,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==761: cLCisPE3lX = CGnUQR6sA82YBK5yFVDPox7E4J()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==762: cLCisPE3lX = dKcJAmIFiZklhNaEv()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==763: cLCisPE3lX = Z27o5eO4uNKrB(xDfZGsilBXPVgdF427SeQkaE,yv8XxUjorzB2CRA4Jife73VMklHp,ffGe7cURW0lhJVvQAiw8IB)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==764: cLCisPE3lX = XXnJrBHex3jqa74YFM(xDfZGsilBXPVgdF427SeQkaE,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==765: cLCisPE3lX = f2fyre70bTAWY9Vp1O(xDfZGsilBXPVgdF427SeQkaE,yv8XxUjorzB2CRA4Jife73VMklHp)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def CGnUQR6sA82YBK5yFVDPox7E4J():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
		JJCLnkX4TozH7Bsjivfe = '_IP'+str(xDfZGsilBXPVgdF427SeQkaE)+'_'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' فيديوهات مجلد '+Yrb603795v[xDfZGsilBXPVgdF427SeQkaE],'',764,'','','','',{'folder':xDfZGsilBXPVgdF427SeQkaE})
	return
def dKcJAmIFiZklhNaEv():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
		JJCLnkX4TozH7Bsjivfe = '_MU'+str(xDfZGsilBXPVgdF427SeQkaE)+'_'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' فيديوهات مجلد '+Yrb603795v[xDfZGsilBXPVgdF427SeQkaE],'',765,'','','','',{'folder':xDfZGsilBXPVgdF427SeQkaE})
	return
def UBtVKW54XA78(vuyTFsAd72wDBiUPSnft5obMjErR6):
	global kK8pNIAOJB7Ye,U9GscZrqC3uA8YKej64FRt0mNz
	VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac = F9CkIURDtc3wy2N8z5VdLuH7p(vuyTFsAd72wDBiUPSnft5obMjErR6)
	try:
		if 'IFILM' in vuyTFsAd72wDBiUPSnft5obMjErR6: VVN1EA7KFvGSq(vuyTFsAd72wDBiUPSnft5obMjErR6)
		else: VVN1EA7KFvGSq()
		Y2hN5IWsP3Ltp1DqixzyRv = False
	except:
		lmX9WoCBVcaysrT3NgkzbFtJUxw()
		Y2hN5IWsP3Ltp1DqixzyRv = True
	vuyTFsAd72wDBiUPSnft5obMjErR6 = hqWB0vmTcxR8d3oukL(vuyTFsAd72wDBiUPSnft5obMjErR6)
	if Y2hN5IWsP3Ltp1DqixzyRv:
		fYPz7RldWQVHBktZAexwvCL8Np3D(vuyTFsAd72wDBiUPSnft5obMjErR6,'فشل للأسف',D1vBJgya85Yh4cRTCkIMKtWLSeH=2000)
		kK8pNIAOJB7Ye += 1
		U9GscZrqC3uA8YKej64FRt0mNz += ' '+vuyTFsAd72wDBiUPSnft5obMjErR6
	else: fYPz7RldWQVHBktZAexwvCL8Np3D(vuyTFsAd72wDBiUPSnft5obMjErR6,'',D1vBJgya85Yh4cRTCkIMKtWLSeH=1000)
	return
def ppV0x3bIWzGXSr7LMZYoaEjt6PCch(NfOGycZPIi9aKMxtsXYgJ1lA=True):
	global kK8pNIAOJB7Ye,U9GscZrqC3uA8YKej64FRt0mNz
	if not NfOGycZPIi9aKMxtsXYgJ1lA:
		global JZ8q3iIuOMam6QyPK0k5
		cLCisPE3lX = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if cLCisPE3lX:
			JZ8q3iIuOMam6QyPK0k5 = cLCisPE3lX
			return
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if VjwKs4GNQZ518kCl!=1: return
	TuLb46ZoWU85Vt3laJGEhvRyIKwrz(False,False,False)
	UlxZ1HfeVic = a26IqBkAXRPrwCOgFDb
	kK8pNIAOJB7Ye,U9GscZrqC3uA8YKej64FRt0mNz,threads = 0,'',{}
	for vuyTFsAd72wDBiUPSnft5obMjErR6 in zpf5CZtSa32UnHrJV1d8vD9hLP7YG:
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(0.5)
		threads[vuyTFsAd72wDBiUPSnft5obMjErR6] = RZxCcFI8fw31NKP.Thread(target=UBtVKW54XA78,args=(vuyTFsAd72wDBiUPSnft5obMjErR6,))
		threads[vuyTFsAd72wDBiUPSnft5obMjErR6].start()
		if kK8pNIAOJB7Ye>=KHpnOsTAjv4: break
	else:
		for vuyTFsAd72wDBiUPSnft5obMjErR6 in list(threads.keys()):
			threads[vuyTFsAd72wDBiUPSnft5obMjErR6].join()
	a26IqBkAXRPrwCOgFDb[:] = UlxZ1HfeVic
	if kK8pNIAOJB7Ye>=KHpnOsTAjv4: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','لديك مشكلة في '+str(kK8pNIAOJB7Ye)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+U9GscZrqC3uA8YKej64FRt0mNz)
	else:
		rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_SITES','SECTIONS_SITES_ALL',JZ8q3iIuOMam6QyPK0k5,U6y1OBwzfkEuRGVNrpYFv)
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	TuLb46ZoWU85Vt3laJGEhvRyIKwrz('','','')
	return
def mHEQqbnrYFLuVTjNiKf83A1dP(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	jDSoFcA19T = False
	NWAgIFeDu1rCVnGY5p4xKmLH = a26IqBkAXRPrwCOgFDb
	a26IqBkAXRPrwCOgFDb[:] = []
	if jDSoFcA19T and '_CREATENEW_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		cLCisPE3lX = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+xDfZGsilBXPVgdF427SeQkaE)
	elif '_LIVE_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD or '_VOD_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		import ll13jcxerk
		F67qZAgMjPukRfJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			try: ll13jcxerk.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_UNKNOWN_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـIPTV للفيديوهات',F67qZAgMjPukRfJ)
			try: ll13jcxerk.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_MOVIES_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـIPTV للفيديوهات',F67qZAgMjPukRfJ)
			try: ll13jcxerk.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_SERIES_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـIPTV للفيديوهات',F67qZAgMjPukRfJ)
		if '_VOD_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			try: ll13jcxerk.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'LIVE_UNKNOWN_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـIPTV للقنوات',F67qZAgMjPukRfJ)
			try: ll13jcxerk.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'LIVE_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـIPTV للقنوات',F67qZAgMjPukRfJ)
		cLCisPE3lX = a26IqBkAXRPrwCOgFDb
		if jDSoFcA19T: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_IPTV','SECTIONS_IPTV_'+xDfZGsilBXPVgdF427SeQkaE,cLCisPE3lX,U6y1OBwzfkEuRGVNrpYFv)
	a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH
	return cLCisPE3lX
def yt4QKq6GVJODgskmXWY2(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	jDSoFcA19T = False
	NWAgIFeDu1rCVnGY5p4xKmLH = a26IqBkAXRPrwCOgFDb
	a26IqBkAXRPrwCOgFDb[:] = []
	if jDSoFcA19T and '_CREATENEW_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		cLCisPE3lX = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS_M3U','SECTIONS_M3U_'+xDfZGsilBXPVgdF427SeQkaE)
	elif '_LIVE_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD or '_VOD_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		import DqKuc961xM
		F67qZAgMjPukRfJ = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			try: DqKuc961xM.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_UNKNOWN_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـM3U للفيديوهات',F67qZAgMjPukRfJ)
			try: DqKuc961xM.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_MOVIES_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـM3U للفيديوهات',F67qZAgMjPukRfJ)
			try: DqKuc961xM.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'VOD_SERIES_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـM3U للفيديوهات',F67qZAgMjPukRfJ)
		if '_VOD_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			try: DqKuc961xM.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'LIVE_UNKNOWN_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـM3U للقنوات',F67qZAgMjPukRfJ)
			try: DqKuc961xM.jIXo9UYHyliZsMkh7(xDfZGsilBXPVgdF427SeQkaE,'LIVE_GROUPED_SORTED','','',qpXBSH0v2uyR7lEiIftkeKYMcCD+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: KK47FGdX1TDfkb3AjHOQqghE('','','موقع ـM3U للقنوات',F67qZAgMjPukRfJ)
		cLCisPE3lX = a26IqBkAXRPrwCOgFDb
		if jDSoFcA19T: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_'+xDfZGsilBXPVgdF427SeQkaE,cLCisPE3lX,U6y1OBwzfkEuRGVNrpYFv)
	a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH
	return cLCisPE3lX
def Z27o5eO4uNKrB(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD,wwXVn5zyi4pK2AWb8Ta):
	if '_CREATENEW_' in qpXBSH0v2uyR7lEiIftkeKYMcCD and wwXVn5zyi4pK2AWb8Ta=='': ppV0x3bIWzGXSr7LMZYoaEjt6PCch(True)
	elif wwXVn5zyi4pK2AWb8Ta: ppV0x3bIWzGXSr7LMZYoaEjt6PCch(False)
	H2dyAoIe3DE5Lq6bwtPU = qpXBSH0v2uyR7lEiIftkeKYMcCD.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not wwXVn5zyi4pK2AWb8Ta:
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+H2dyAoIe3DE5Lq6bwtPU,'',{'folder':xDfZGsilBXPVgdF427SeQkaE})
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	JNSvF8Egp0xCHOR2b3 = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	sGgKdbYSfXxWqaRt89OlNr = ['افلام','movie','فيلم','فلم']
	sLjwXDR3mn4odYCa7EIiVKeZN5UgP = ['مسلسل','series']
	vSoV7Ew0N6TLdkcuPJ91 = ['مسارح','مسرحيات']
	eq4fF5SAaBXTGLhI = ['برامج','show','تلفزيون','تليفزيون']
	BCeOSjMGZVQomaTc7JtW48 = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	ot9gmHj2af5UxrCYFpA80 = ['رمضان']
	lTDhLSWw0YXprJzxfZNejCmO = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	scot9TA0zyNnvmjxaqhfdR = ['سلاسل','سلسله']
	TFJqmA9hHuY = ['اغاني','موسيقى','كليب','حفل','music']
	VREj4tUeWohpb2FT = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	BibGhPuElT3Mwe = ['الان','حالي','مثبت','رائج']
	tp4QDq2MZSEVFseBTW = ['ضحك','كوميدي']
	RA2kHd4vNLfoZsGbrMp7SwhUDyJ1OY = ['رياضه','كوره','مصارعه','شوت','رياضة']
	csXu07SDBlbCifkMYar = ['نيتفلكس','netflix','نيتفليكس']
	UUizVeZmBM6ESa9k5oD02PY = ['ممثلين','اشخاص','نجوم']
	Dzi0rPWaLn45GIfdCy762 = ['بث حي','live','قناه','قنوات']
	UavZ9DHVcNEu7mq5wRWd0oi1fs = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	PhmbeWFlJVu1zK6jfyNAR2LQ = ['19','20','21','22','23','24','25','26']
	if not wwXVn5zyi4pK2AWb8Ta:
		wwXVn5zyi4pK2AWb8Ta = 0
		for bG4g0Di6u35rWLwjfKnZNkTPMQX1A7 in JNSvF8Egp0xCHOR2b3:
			wwXVn5zyi4pK2AWb8Ta += 1
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+bG4g0Di6u35rWLwjfKnZNkTPMQX1A7,'',763,'',str(wwXVn5zyi4pK2AWb8Ta),H2dyAoIe3DE5Lq6bwtPU,'',{'folder':xDfZGsilBXPVgdF427SeQkaE})
	else:
		for XLVqPOIzGJl6KUyQ23d9 in sorted(list(JZ8q3iIuOMam6QyPK0k5.keys())):
			dFEpvGRU73W6TowXj5xV8 = XLVqPOIzGJl6KUyQ23d9.lower()
			ZecS1yJOzVutgX0qiH3NER = []
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in sGgKdbYSfXxWqaRt89OlNr): ZecS1yJOzVutgX0qiH3NER.append(1)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in sLjwXDR3mn4odYCa7EIiVKeZN5UgP): ZecS1yJOzVutgX0qiH3NER.append(2)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in vSoV7Ew0N6TLdkcuPJ91): ZecS1yJOzVutgX0qiH3NER.append(3)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in eq4fF5SAaBXTGLhI): ZecS1yJOzVutgX0qiH3NER.append(4)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in BCeOSjMGZVQomaTc7JtW48): ZecS1yJOzVutgX0qiH3NER.append(5)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in ot9gmHj2af5UxrCYFpA80): ZecS1yJOzVutgX0qiH3NER.append(6)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in lTDhLSWw0YXprJzxfZNejCmO) and dFEpvGRU73W6TowXj5xV8 not in ['اخرى']: ZecS1yJOzVutgX0qiH3NER.append(7)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in scot9TA0zyNnvmjxaqhfdR): ZecS1yJOzVutgX0qiH3NER.append(8)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in TFJqmA9hHuY): ZecS1yJOzVutgX0qiH3NER.append(9)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in VREj4tUeWohpb2FT): ZecS1yJOzVutgX0qiH3NER.append(10)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in BibGhPuElT3Mwe): ZecS1yJOzVutgX0qiH3NER.append(11)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in tp4QDq2MZSEVFseBTW): ZecS1yJOzVutgX0qiH3NER.append(12)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in RA2kHd4vNLfoZsGbrMp7SwhUDyJ1OY): ZecS1yJOzVutgX0qiH3NER.append(13)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in csXu07SDBlbCifkMYar): ZecS1yJOzVutgX0qiH3NER.append(14)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in UUizVeZmBM6ESa9k5oD02PY): ZecS1yJOzVutgX0qiH3NER.append(15)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in Dzi0rPWaLn45GIfdCy762): ZecS1yJOzVutgX0qiH3NER.append(16)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in UavZ9DHVcNEu7mq5wRWd0oi1fs): ZecS1yJOzVutgX0qiH3NER.append(17)
			if any(EYn2siOeDvQTk8KpS0Jl in dFEpvGRU73W6TowXj5xV8 for EYn2siOeDvQTk8KpS0Jl in PhmbeWFlJVu1zK6jfyNAR2LQ): ZecS1yJOzVutgX0qiH3NER.append(18)
			if not ZecS1yJOzVutgX0qiH3NER: ZecS1yJOzVutgX0qiH3NER = [19]
			for hh84fQPcKsBIiGC16kj in ZecS1yJOzVutgX0qiH3NER:
				if str(hh84fQPcKsBIiGC16kj)==wwXVn5zyi4pK2AWb8Ta:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+XLVqPOIzGJl6KUyQ23d9,XLVqPOIzGJl6KUyQ23d9,166,'','',H2dyAoIe3DE5Lq6bwtPU+'_REMEMBERRESULTS_')
	return
def XXnJrBHex3jqa74YFM(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	jDSoFcA19T = False
	if jDSoFcA19T:
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':xDfZGsilBXPVgdF427SeQkaE})
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NWAgIFeDu1rCVnGY5p4xKmLH = a26IqBkAXRPrwCOgFDb[:]
	import ll13jcxerk
	if xDfZGsilBXPVgdF427SeQkaE:
		if not ll13jcxerk.TPcrCe0UH6JVdMgSLxuQvX7R4(xDfZGsilBXPVgdF427SeQkaE,True): return
		oJkVFbwyNUBZ87adjlchuHzSmf6K9 = mHEQqbnrYFLuVTjNiKf83A1dP(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD)
		onDef3aEjYX5lhq = sorted(oJkVFbwyNUBZ87adjlchuHzSmf6K9,reverse=False,key=lambda key: key[1].lower())
	else:
		if not ll13jcxerk.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
		if jDSoFcA19T and '_CREATENEW_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			onDef3aEjYX5lhq = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			RXWBEdbjIU3Kx0z1Ga,onDef3aEjYX5lhq,oJkVFbwyNUBZ87adjlchuHzSmf6K9 = [],[],[]
			for OTDjsHt78G in range(1,U1UsphAegPmDYZXfTW+1):
				onDef3aEjYX5lhq += mHEQqbnrYFLuVTjNiKf83A1dP(str(OTDjsHt78G),qpXBSH0v2uyR7lEiIftkeKYMcCD)
			for type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in onDef3aEjYX5lhq:
				if yv8XxUjorzB2CRA4Jife73VMklHp not in RXWBEdbjIU3Kx0z1Ga:
					RXWBEdbjIU3Kx0z1Ga.append(yv8XxUjorzB2CRA4Jife73VMklHp)
					D2zUu6RPyOCwgWVvx = type,XLVqPOIzGJl6KUyQ23d9,yv8XxUjorzB2CRA4Jife73VMklHp,165,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,qpXBSH0v2uyR7lEiIftkeKYMcCD,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl
					oJkVFbwyNUBZ87adjlchuHzSmf6K9.append(D2zUu6RPyOCwgWVvx)
			onDef3aEjYX5lhq = sorted(oJkVFbwyNUBZ87adjlchuHzSmf6K9,reverse=False,key=lambda key: key[1].lower())
			if jDSoFcA19T: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',onDef3aEjYX5lhq,U6y1OBwzfkEuRGVNrpYFv)
	a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+onDef3aEjYX5lhq
	EO9Rts0AaGuk1qpPLXCY.executebuiltin('Container.Refresh')
	return
def f2fyre70bTAWY9Vp1O(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	jDSoFcA19T = False
	if jDSoFcA19T:
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':xDfZGsilBXPVgdF427SeQkaE})
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NWAgIFeDu1rCVnGY5p4xKmLH = a26IqBkAXRPrwCOgFDb[:]
	import DqKuc961xM
	if xDfZGsilBXPVgdF427SeQkaE:
		if not DqKuc961xM.TPcrCe0UH6JVdMgSLxuQvX7R4(xDfZGsilBXPVgdF427SeQkaE,True): return
		oJkVFbwyNUBZ87adjlchuHzSmf6K9 = yt4QKq6GVJODgskmXWY2(xDfZGsilBXPVgdF427SeQkaE,qpXBSH0v2uyR7lEiIftkeKYMcCD)
		onDef3aEjYX5lhq = sorted(oJkVFbwyNUBZ87adjlchuHzSmf6K9,reverse=False,key=lambda key: key[1].lower())
	else:
		if not DqKuc961xM.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
		if jDSoFcA19T and '_CREATENEW_' not in qpXBSH0v2uyR7lEiIftkeKYMcCD:
			onDef3aEjYX5lhq = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			RXWBEdbjIU3Kx0z1Ga,onDef3aEjYX5lhq,oJkVFbwyNUBZ87adjlchuHzSmf6K9 = [],[],[]
			for OTDjsHt78G in range(1,U1UsphAegPmDYZXfTW+1):
				onDef3aEjYX5lhq += yt4QKq6GVJODgskmXWY2(str(OTDjsHt78G),qpXBSH0v2uyR7lEiIftkeKYMcCD)
			for type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in onDef3aEjYX5lhq:
				if yv8XxUjorzB2CRA4Jife73VMklHp not in RXWBEdbjIU3Kx0z1Ga:
					RXWBEdbjIU3Kx0z1Ga.append(yv8XxUjorzB2CRA4Jife73VMklHp)
					D2zUu6RPyOCwgWVvx = type,XLVqPOIzGJl6KUyQ23d9,yv8XxUjorzB2CRA4Jife73VMklHp,165,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,qpXBSH0v2uyR7lEiIftkeKYMcCD,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl
					oJkVFbwyNUBZ87adjlchuHzSmf6K9.append(D2zUu6RPyOCwgWVvx)
			onDef3aEjYX5lhq = sorted(oJkVFbwyNUBZ87adjlchuHzSmf6K9,reverse=False,key=lambda key: key[1].lower())
			if jDSoFcA19T: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_ALL',onDef3aEjYX5lhq,U6y1OBwzfkEuRGVNrpYFv)
	a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+onDef3aEjYX5lhq
	EO9Rts0AaGuk1qpPLXCY.executebuiltin('Container.Refresh')
	return
def L5yEeTISQU7VxcqKkZ8f0s(group,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	jDSoFcA19T = False
	cLCisPE3lX = []
	jVUgOhfCeqYa8mQMlB5WDES61crRx = '_IPTV_' if 'IPTV' in qpXBSH0v2uyR7lEiIftkeKYMcCD else '_M3U_'
	if jDSoFcA19T: cLCisPE3lX = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS'+jVUgOhfCeqYa8mQMlB5WDES61crRx[:-1],group)
	if not cLCisPE3lX:
		for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
			if jDSoFcA19T: cLCisPE3lX += IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','SECTIONS'+jVUgOhfCeqYa8mQMlB5WDES61crRx[:-1],'SECTIONS'+jVUgOhfCeqYa8mQMlB5WDES61crRx+str(xDfZGsilBXPVgdF427SeQkaE))
			elif jVUgOhfCeqYa8mQMlB5WDES61crRx=='_IPTV_': cLCisPE3lX += mHEQqbnrYFLuVTjNiKf83A1dP(str(xDfZGsilBXPVgdF427SeQkaE),'_CREATENEW_')
			elif jVUgOhfCeqYa8mQMlB5WDES61crRx=='_M3U_': cLCisPE3lX += yt4QKq6GVJODgskmXWY2(str(xDfZGsilBXPVgdF427SeQkaE),'_CREATENEW_')
		for type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in cLCisPE3lX:
			if yv8XxUjorzB2CRA4Jife73VMklHp==group: WS9BILoVdyriqvp8(type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
		items,uuNm2btCehYgvsIQlODr = [],[]
		for type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in a26IqBkAXRPrwCOgFDb:
			c5UI9LDgKosPCbhaJ = type,XLVqPOIzGJl6KUyQ23d9[4:],url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,''
			if c5UI9LDgKosPCbhaJ not in uuNm2btCehYgvsIQlODr:
				uuNm2btCehYgvsIQlODr.append(c5UI9LDgKosPCbhaJ)
				Lw8JjEfuiW0VN9qHAcgRpMBdICS = type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl
				items.append(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
		cLCisPE3lX = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if jDSoFcA19T: rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS'+jVUgOhfCeqYa8mQMlB5WDES61crRx[:-1],group,cLCisPE3lX,U6y1OBwzfkEuRGVNrpYFv)
	if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD and len(cLCisPE3lX)>SSDhoMgbviPWlQpTYFxVE:
		a26IqBkAXRPrwCOgFDb[:] = []
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',jVUgOhfCeqYa8mQMlB5WDES61crRx+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',jVUgOhfCeqYa8mQMlB5WDES61crRx+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		cLCisPE3lX = a26IqBkAXRPrwCOgFDb+XIjYJW8qbtv63.sample(cLCisPE3lX,SSDhoMgbviPWlQpTYFxVE)
	a26IqBkAXRPrwCOgFDb[:] = cLCisPE3lX
	EO9Rts0AaGuk1qpPLXCY.executebuiltin('Container.Refresh')
	return
def uYEMRodmJp3(qpXBSH0v2uyR7lEiIftkeKYMcCD):
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	EWz7DVX2LIxQa8bTh0 = a26IqBkAXRPrwCOgFDb[:]
	a26IqBkAXRPrwCOgFDb[:] = []
	import SSy2JCLXDt
	SSy2JCLXDt.yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('0',False)
	SSy2JCLXDt.yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('1',False)
	SSy2JCLXDt.yWFgU1ATZmnbeVt0CoJhz4Edwsj78P('2',False)
	if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		a26IqBkAXRPrwCOgFDb[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
		if len(a26IqBkAXRPrwCOgFDb)>SSDhoMgbviPWlQpTYFxVE: a26IqBkAXRPrwCOgFDb[:] = XIjYJW8qbtv63.sample(a26IqBkAXRPrwCOgFDb,SSDhoMgbviPWlQpTYFxVE)
	a26IqBkAXRPrwCOgFDb[:] = EWz7DVX2LIxQa8bTh0+a26IqBkAXRPrwCOgFDb
	return
def lFArQV3CuLoe4kN6gOaHq(qpXBSH0v2uyR7lEiIftkeKYMcCD):
	qpXBSH0v2uyR7lEiIftkeKYMcCD = qpXBSH0v2uyR7lEiIftkeKYMcCD.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(data)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(BZ5D43mGxLAItEUYTv,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="content"(.*?)class="clearfix"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	zHt7cZ3oKjqrp54mVOiSnY0v,KndvuRxH3jGzybwsVOJ1c2Zm = list(zip(*items))
	nP86RHMSGxIJWUZ9y = []
	oxh2fCB7sZ5PM3mubJY0U = [' ','"','`',',','.',':',';',"'",'-']
	dIUMvcgxNDoRELFQfYGz = KndvuRxH3jGzybwsVOJ1c2Zm+zHt7cZ3oKjqrp54mVOiSnY0v
	for D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA in dIUMvcgxNDoRELFQfYGz:
		if D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA in KndvuRxH3jGzybwsVOJ1c2Zm: FO5GZTRyYMwXKtjN1I93nudc = 2
		if D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA in zHt7cZ3oKjqrp54mVOiSnY0v: FO5GZTRyYMwXKtjN1I93nudc = 4
		AfaZKoCGe0XDBFgkOwi6W = [jV1Z7MWOa80gbwJY64nL5 in D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA for jV1Z7MWOa80gbwJY64nL5 in oxh2fCB7sZ5PM3mubJY0U]
		if any(AfaZKoCGe0XDBFgkOwi6W):
			prZUeN9FojstVTxf0EJQBRq4zdb = AfaZKoCGe0XDBFgkOwi6W.index(True)
			NN3aETHsFv2J70nyKipGZWP4b59kxO = oxh2fCB7sZ5PM3mubJY0U[prZUeN9FojstVTxf0EJQBRq4zdb]
			FF2u7Qxmszk8DH6tbh = ''
			if D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.count(NN3aETHsFv2J70nyKipGZWP4b59kxO)>1: X0fWeGuH9NasF,lpIxF2CUaAGHS,FF2u7Qxmszk8DH6tbh = D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.split(NN3aETHsFv2J70nyKipGZWP4b59kxO,2)
			else: X0fWeGuH9NasF,lpIxF2CUaAGHS = D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.split(NN3aETHsFv2J70nyKipGZWP4b59kxO,1)
			if len(X0fWeGuH9NasF)>FO5GZTRyYMwXKtjN1I93nudc: nP86RHMSGxIJWUZ9y.append(X0fWeGuH9NasF.lower())
			if len(lpIxF2CUaAGHS)>FO5GZTRyYMwXKtjN1I93nudc: nP86RHMSGxIJWUZ9y.append(lpIxF2CUaAGHS.lower())
			if len(FF2u7Qxmszk8DH6tbh)>FO5GZTRyYMwXKtjN1I93nudc: nP86RHMSGxIJWUZ9y.append(FF2u7Qxmszk8DH6tbh.lower())
		elif len(D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA)>FO5GZTRyYMwXKtjN1I93nudc: nP86RHMSGxIJWUZ9y.append(D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.lower())
	for jV1Z7MWOa80gbwJY64nL5 in range(9): XIjYJW8qbtv63.shuffle(nP86RHMSGxIJWUZ9y)
	if '_SITES_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		NGBonqJfDXzywKHREY7e = TLu7gCmS0Kk2lnP1cO
	elif '_IPTV_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		NGBonqJfDXzywKHREY7e = ['IPTV']
		import ll13jcxerk
		if not ll13jcxerk.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
	elif '_M3U_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		NGBonqJfDXzywKHREY7e = ['M3U']
		import DqKuc961xM
		if not DqKuc961xM.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
	count,YV1UKbr5WuntNciAvaqL8Mg0 = 0,0
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	CKTOdfNl4DUz5SAqit = a26IqBkAXRPrwCOgFDb[:]
	a26IqBkAXRPrwCOgFDb[:] = []
	W10pTaNCyeZ9AgSRO5 = []
	for D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA in nP86RHMSGxIJWUZ9y:
		lpIxF2CUaAGHS = T072lCzjYiuaeFtmJGV.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA,T072lCzjYiuaeFtmJGV.DOTALL)
		if lpIxF2CUaAGHS: D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA = D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.split(lpIxF2CUaAGHS[0],1)[0]
		Y5rnGO0j2zgl = D9DKXGsiYb2N5yW7pQOC1hSnHRdUxA.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		Y5rnGO0j2zgl = Y5rnGO0j2zgl.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if Y5rnGO0j2zgl: W10pTaNCyeZ9AgSRO5.append(Y5rnGO0j2zgl)
	HxzdRisvJ59wN7GU2lV = []
	for H3ABEcMzfyqwF4Ug2ZYtK in range(0,20):
		search = XIjYJW8qbtv63.sample(W10pTaNCyeZ9AgSRO5,1)[0]
		if search in HxzdRisvJ59wN7GU2lV: continue
		HxzdRisvJ59wN7GU2lV.append(search)
		vuyTFsAd72wDBiUPSnft5obMjErR6 = XIjYJW8qbtv63.sample(NGBonqJfDXzywKHREY7e,1)[0]
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Random Video Search   site:'+str(vuyTFsAd72wDBiUPSnft5obMjErR6)+'  search:'+search)
		VVN1EA7KFvGSq,c0a1XqysA6duSxvCH9Twi2bD,GhPbjTIufD1JQMgEHSY4LqzAac = F9CkIURDtc3wy2N8z5VdLuH7p(vuyTFsAd72wDBiUPSnft5obMjErR6)
		c0a1XqysA6duSxvCH9Twi2bD(search+'_NODIALOGS_')
		if len(a26IqBkAXRPrwCOgFDb)>0: break
	search = search.replace('_MOD_','')
	CKTOdfNl4DUz5SAqit[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	a26IqBkAXRPrwCOgFDb[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
	if len(a26IqBkAXRPrwCOgFDb)>SSDhoMgbviPWlQpTYFxVE: a26IqBkAXRPrwCOgFDb[:] = XIjYJW8qbtv63.sample(a26IqBkAXRPrwCOgFDb,SSDhoMgbviPWlQpTYFxVE)
	a26IqBkAXRPrwCOgFDb[:] = CKTOdfNl4DUz5SAqit+a26IqBkAXRPrwCOgFDb
	return
def f70G6lTizaW3nXKhg1Avqp95IUFL(x7xpFKwlRj1eWrUYdAtZqS3BEomPg,qpXBSH0v2uyR7lEiIftkeKYMcCD):
	x7xpFKwlRj1eWrUYdAtZqS3BEomPg = x7xpFKwlRj1eWrUYdAtZqS3BEomPg.replace('_MOD_','')
	qpXBSH0v2uyR7lEiIftkeKYMcCD = qpXBSH0v2uyR7lEiIftkeKYMcCD.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	ppV0x3bIWzGXSr7LMZYoaEjt6PCch(False)
	if JZ8q3iIuOMam6QyPK0k5=={}: return
	if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[[COLOR FFC89008]'+x7xpFKwlRj1eWrUYdAtZqS3BEomPg+'[/COLOR] :القسم]',x7xpFKwlRj1eWrUYdAtZqS3BEomPg,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة الطلب العشوائي من نفس القسم',x7xpFKwlRj1eWrUYdAtZqS3BEomPg,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(JZ8q3iIuOMam6QyPK0k5[x7xpFKwlRj1eWrUYdAtZqS3BEomPg].keys())):
		type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = JZ8q3iIuOMam6QyPK0k5[x7xpFKwlRj1eWrUYdAtZqS3BEomPg][website]
		if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD or len(JZ8q3iIuOMam6QyPK0k5[x7xpFKwlRj1eWrUYdAtZqS3BEomPg])==1:
			WS9BILoVdyriqvp8(type,'',url,VoJz4e67SfIUB5th,'',ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,'','')
			a26IqBkAXRPrwCOgFDb[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
			NWAgIFeDu1rCVnGY5p4xKmLH,onDef3aEjYX5lhq = a26IqBkAXRPrwCOgFDb[:3],a26IqBkAXRPrwCOgFDb[3:]
			for jV1Z7MWOa80gbwJY64nL5 in range(9): XIjYJW8qbtv63.shuffle(onDef3aEjYX5lhq)
			if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD: a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+onDef3aEjYX5lhq[:SSDhoMgbviPWlQpTYFxVE]
			else: a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+onDef3aEjYX5lhq
		elif '_SITES_' in qpXBSH0v2uyR7lEiIftkeKYMcCD: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',website,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
	return
def g2NJdvoyTEGsj(qpXBSH0v2uyR7lEiIftkeKYMcCD,EHnSrqQ7BvmGlOgYZdhTbCRtswA):
	qpXBSH0v2uyR7lEiIftkeKYMcCD = qpXBSH0v2uyR7lEiIftkeKYMcCD.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	XLVqPOIzGJl6KUyQ23d9,JRDl3aUpBmYkf7zMHnxdshgLtcAQ = '',[]
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[[COLOR FFC89008]'+XLVqPOIzGJl6KUyQ23d9+'[/COLOR] :القسم]','',EHnSrqQ7BvmGlOgYZdhTbCRtswA,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة طلب قسم عشوائي','',EHnSrqQ7BvmGlOgYZdhTbCRtswA,'','','_FORGETRESULTS__REMEMBERRESULTS_'+qpXBSH0v2uyR7lEiIftkeKYMcCD)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	NWAgIFeDu1rCVnGY5p4xKmLH = a26IqBkAXRPrwCOgFDb[:]
	a26IqBkAXRPrwCOgFDb[:] = []
	cLCisPE3lX = []
	if '_SITES_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		ppV0x3bIWzGXSr7LMZYoaEjt6PCch(False)
		if JZ8q3iIuOMam6QyPK0k5=={}: return
		QXpMOdew5IqLo0GncW = list(JZ8q3iIuOMam6QyPK0k5.keys())
		x7xpFKwlRj1eWrUYdAtZqS3BEomPg = XIjYJW8qbtv63.sample(QXpMOdew5IqLo0GncW,1)[0]
		nP86RHMSGxIJWUZ9y = list(JZ8q3iIuOMam6QyPK0k5[x7xpFKwlRj1eWrUYdAtZqS3BEomPg].keys())
		website = XIjYJW8qbtv63.sample(nP86RHMSGxIJWUZ9y,1)[0]
		type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = JZ8q3iIuOMam6QyPK0k5[x7xpFKwlRj1eWrUYdAtZqS3BEomPg][website]
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Random Category   website: '+website+'   name: '+XLVqPOIzGJl6KUyQ23d9+'   url: '+url+'   mode: '+str(VoJz4e67SfIUB5th))
	elif '_IPTV_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		import ll13jcxerk
		if not ll13jcxerk.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
		for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
			cLCisPE3lX += mHEQqbnrYFLuVTjNiKf83A1dP(str(xDfZGsilBXPVgdF427SeQkaE),qpXBSH0v2uyR7lEiIftkeKYMcCD)
		if not cLCisPE3lX: return
		type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = XIjYJW8qbtv63.sample(cLCisPE3lX,1)[0]
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Random Category   name: '+XLVqPOIzGJl6KUyQ23d9+'   url: '+url+'   mode: '+str(VoJz4e67SfIUB5th))
	elif '_M3U_' in qpXBSH0v2uyR7lEiIftkeKYMcCD:
		import DqKuc961xM
		if not DqKuc961xM.TPcrCe0UH6JVdMgSLxuQvX7R4('',True): return
		for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
			cLCisPE3lX += yt4QKq6GVJODgskmXWY2(str(xDfZGsilBXPVgdF427SeQkaE),qpXBSH0v2uyR7lEiIftkeKYMcCD)
		if not cLCisPE3lX: return
		type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = XIjYJW8qbtv63.sample(cLCisPE3lX,1)[0]
		GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Random Category   name: '+XLVqPOIzGJl6KUyQ23d9+'   url: '+url+'   mode: '+str(VoJz4e67SfIUB5th))
	iRo6XB2rqA5xWhL3Tmza7Zb40EMdfY = XLVqPOIzGJl6KUyQ23d9
	gfoO9FkncyAMz7S8u0CmhY6vBUW = []
	for jV1Z7MWOa80gbwJY64nL5 in range(0,10):
		if jV1Z7MWOa80gbwJY64nL5>0: GZvEITHSg5U3rVwQ('NOTICE',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   Random Category   name: '+XLVqPOIzGJl6KUyQ23d9+'   url: '+url+'   mode: '+str(VoJz4e67SfIUB5th))
		a26IqBkAXRPrwCOgFDb[:] = []
		if VoJz4e67SfIUB5th==234 and '__IPTVSeries__' in yv8XxUjorzB2CRA4Jife73VMklHp: VoJz4e67SfIUB5th = 233
		if VoJz4e67SfIUB5th==714 and '__M3USeries__' in yv8XxUjorzB2CRA4Jife73VMklHp: VoJz4e67SfIUB5th = 713
		if VoJz4e67SfIUB5th==144: VoJz4e67SfIUB5th = 291
		O578ENGbr6PYnLJzi = WS9BILoVdyriqvp8(type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl)
		if '_IPTV_' in qpXBSH0v2uyR7lEiIftkeKYMcCD and VoJz4e67SfIUB5th==167: del a26IqBkAXRPrwCOgFDb[:3]
		if '_M3U_' in qpXBSH0v2uyR7lEiIftkeKYMcCD and VoJz4e67SfIUB5th==168: del a26IqBkAXRPrwCOgFDb[:3]
		JRDl3aUpBmYkf7zMHnxdshgLtcAQ[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
		if gfoO9FkncyAMz7S8u0CmhY6vBUW and y357f08uQISUGLr6qOwdTBCcnWsv(u'حلقة') in str(JRDl3aUpBmYkf7zMHnxdshgLtcAQ) or y357f08uQISUGLr6qOwdTBCcnWsv(u'حلقه') in str(JRDl3aUpBmYkf7zMHnxdshgLtcAQ):
			XLVqPOIzGJl6KUyQ23d9 = iRo6XB2rqA5xWhL3Tmza7Zb40EMdfY
			JRDl3aUpBmYkf7zMHnxdshgLtcAQ[:] = gfoO9FkncyAMz7S8u0CmhY6vBUW
			break
		iRo6XB2rqA5xWhL3Tmza7Zb40EMdfY = XLVqPOIzGJl6KUyQ23d9
		gfoO9FkncyAMz7S8u0CmhY6vBUW = JRDl3aUpBmYkf7zMHnxdshgLtcAQ
		if str(JRDl3aUpBmYkf7zMHnxdshgLtcAQ).count('video')>0: break
		if str(JRDl3aUpBmYkf7zMHnxdshgLtcAQ).count('live')>0: break
		if VoJz4e67SfIUB5th==233: break
		if VoJz4e67SfIUB5th==713: break
		if VoJz4e67SfIUB5th==291: break
		if JRDl3aUpBmYkf7zMHnxdshgLtcAQ: type,XLVqPOIzGJl6KUyQ23d9,url,VoJz4e67SfIUB5th,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = XIjYJW8qbtv63.sample(JRDl3aUpBmYkf7zMHnxdshgLtcAQ,1)[0]
	if not XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = '....'
	elif XLVqPOIzGJl6KUyQ23d9.count('_')>1: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.split('_',2)[2]
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('UNKNOWN: ','')
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('_MOD_','')
	NWAgIFeDu1rCVnGY5p4xKmLH[0][1] = '[[COLOR FFC89008]'+XLVqPOIzGJl6KUyQ23d9+'[/COLOR] :القسم]'
	for jV1Z7MWOa80gbwJY64nL5 in range(9): XIjYJW8qbtv63.shuffle(JRDl3aUpBmYkf7zMHnxdshgLtcAQ)
	if '_RANDOM_' in qpXBSH0v2uyR7lEiIftkeKYMcCD: a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+JRDl3aUpBmYkf7zMHnxdshgLtcAQ[:SSDhoMgbviPWlQpTYFxVE]
	else: a26IqBkAXRPrwCOgFDb[:] = NWAgIFeDu1rCVnGY5p4xKmLH+JRDl3aUpBmYkf7zMHnxdshgLtcAQ
	return
def fVUmasELgbZF0kSOYWMejhy5BTD(ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx):
	V0ATKOdFS7bjx = V0ATKOdFS7bjx.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	DFzX5uRCnZi = V0ATKOdFS7bjx
	if '__IPTVSeries__' in V0ATKOdFS7bjx:
		DFzX5uRCnZi = V0ATKOdFS7bjx.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in ihxz2OGNVJAdrjpsRgfIm9Uv0C: type = ',VIDEOS: '
	elif 'LIVE' in ihxz2OGNVJAdrjpsRgfIm9Uv0C: type = ',LIVE: '
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[[COLOR FFC89008]'+type+DFzX5uRCnZi+'[/COLOR] :القسم]',ihxz2OGNVJAdrjpsRgfIm9Uv0C,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+V0ATKOdFS7bjx)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة الطلب العشوائي من نفس القسم',ihxz2OGNVJAdrjpsRgfIm9Uv0C,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+V0ATKOdFS7bjx)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import ll13jcxerk
	for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
		if '__IPTVSeries__' in V0ATKOdFS7bjx: ll13jcxerk.jIXo9UYHyliZsMkh7(str(xDfZGsilBXPVgdF427SeQkaE),ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx,'',False)
		else: ll13jcxerk.yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(str(xDfZGsilBXPVgdF427SeQkaE),ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx,'',False)
	a26IqBkAXRPrwCOgFDb[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
	if len(a26IqBkAXRPrwCOgFDb)>(SSDhoMgbviPWlQpTYFxVE+3): a26IqBkAXRPrwCOgFDb[:] = a26IqBkAXRPrwCOgFDb[:3]+XIjYJW8qbtv63.sample(a26IqBkAXRPrwCOgFDb[3:],SSDhoMgbviPWlQpTYFxVE)
	return
def OOwPMbm8akBQre6sy(ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx):
	V0ATKOdFS7bjx = V0ATKOdFS7bjx.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	DFzX5uRCnZi = V0ATKOdFS7bjx
	if '__M3USeries__' in V0ATKOdFS7bjx:
		DFzX5uRCnZi = V0ATKOdFS7bjx.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in ihxz2OGNVJAdrjpsRgfIm9Uv0C: type = ',VIDEOS: '
	elif 'LIVE' in ihxz2OGNVJAdrjpsRgfIm9Uv0C: type = ',LIVE: '
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','[[COLOR FFC89008]'+type+DFzX5uRCnZi+'[/COLOR] :القسم]',ihxz2OGNVJAdrjpsRgfIm9Uv0C,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+V0ATKOdFS7bjx)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder','إعادة الطلب العشوائي من نفس القسم',ihxz2OGNVJAdrjpsRgfIm9Uv0C,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+V0ATKOdFS7bjx)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import DqKuc961xM
	for xDfZGsilBXPVgdF427SeQkaE in range(1,U1UsphAegPmDYZXfTW+1):
		if '__M3USeries__' in V0ATKOdFS7bjx: DqKuc961xM.jIXo9UYHyliZsMkh7(str(xDfZGsilBXPVgdF427SeQkaE),ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx,'',False)
		else: DqKuc961xM.yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(str(xDfZGsilBXPVgdF427SeQkaE),ihxz2OGNVJAdrjpsRgfIm9Uv0C,V0ATKOdFS7bjx,'',False)
	a26IqBkAXRPrwCOgFDb[:] = AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb)
	if len(a26IqBkAXRPrwCOgFDb)>(SSDhoMgbviPWlQpTYFxVE+3): a26IqBkAXRPrwCOgFDb[:] = a26IqBkAXRPrwCOgFDb[:3]+XIjYJW8qbtv63.sample(a26IqBkAXRPrwCOgFDb[3:],SSDhoMgbviPWlQpTYFxVE)
	return
def AY0IolPtdfiy1vHwnZg(a26IqBkAXRPrwCOgFDb):
	JRDl3aUpBmYkf7zMHnxdshgLtcAQ = []
	for type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl in a26IqBkAXRPrwCOgFDb:
		if 'صفحة' in XLVqPOIzGJl6KUyQ23d9 or 'صفحه' in XLVqPOIzGJl6KUyQ23d9 or 'page' in XLVqPOIzGJl6KUyQ23d9.lower(): continue
		JRDl3aUpBmYkf7zMHnxdshgLtcAQ.append([type,XLVqPOIzGJl6KUyQ23d9,url,EHnSrqQ7BvmGlOgYZdhTbCRtswA,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,yv8XxUjorzB2CRA4Jife73VMklHp,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl])
	return JRDl3aUpBmYkf7zMHnxdshgLtcAQ
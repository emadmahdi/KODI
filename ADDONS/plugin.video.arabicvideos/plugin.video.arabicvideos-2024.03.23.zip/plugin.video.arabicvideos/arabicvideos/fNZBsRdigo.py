# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from skIgoAvZ9t import *
nO6ukabcldeU = FIHNSc5iuoZanQ2Ytl(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def F5M9LsnokGPEQ2XYfO7cuyr(EHnSrqQ7BvmGlOgYZdhTbCRtswA,HHPwg71GEVju):
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==EmK3ObA0cwv9Wy(u"࠷࠸࠶৪"): cLCisPE3lX = p6QFyNM8ZV()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠸࠹࠱৫"): cLCisPE3lX = JwYEQUDupG2WLPzHndc(HHPwg71GEVju)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==Xl3drKyI9HkDiPEf8RTjwu(u"࠹࠳࠳৬"): cLCisPE3lX = yyrXqMPC3xIEd9uOYcNF()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==f5uqIoSJzWBOFyrY78RXmVb(u"࠳࠴࠵৭"): cLCisPE3lX = gjwHnSviXYy6cl()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴࠵࠷৮"): cLCisPE3lX = pxzZSe9Bjc6EsCq(HHPwg71GEVju)
	else: cLCisPE3lX = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࡋࡧ࡬ࡴࡧਜ")
	return cLCisPE3lX
def pxzZSe9Bjc6EsCq(nRsoaHrzAvPN4):
	try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(nRsoaHrzAvPN4.decode(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(nRsoaHrzAvPN4)
	return
def JwYEQUDupG2WLPzHndc(HHPwg71GEVju):
	pidYDcjvhgVfqb3GeWSAOH5J(HHPwg71GEVju,nO6ukabcldeU,sDiKwnHcSlYFgWCy1Ak(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def gjwHnSviXYy6cl():
	F67qZAgMjPukRfJ = ZEiR0StquOzca9lvPAndYIX(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	KK47FGdX1TDfkb3AjHOQqghE(vatyjK4hHAoZJ7rOq2lis(u"ࠬ࠭ठ"),ZhqJoOtcmTVID65HwnLj(u"࠭ࠧड"),PiFkQ5pCJy7fbX(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),F67qZAgMjPukRfJ)
	return
def p6QFyNM8ZV():
	QQmLIZC8uas9fNiJWOnhdGvgFR(WmaPChRdQk3YcXwI6zS(u"ࠨ࡮࡬ࡲࡰ࠭ण"),oAXJCYqPgyGDtT(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࠫथ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"࠵࠶࠷৯"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(PiFkQ5pCJy7fbX(u"ࠫࡱ࡯࡮࡬ࠩद"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),N9olEh0ZMtpOivVfBLK(u"࠭ࠧन"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠶࠷࠷ৰ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(h5huy6MiXPNfQJF8(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),vatyjK4hHAoZJ7rOq2lis(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩࠪफ"),ZEiR0StquOzca9lvPAndYIX(u"࠽࠾࠿࠹ৱ"))
	OOyYgPK57Ex6fq4XkrQ8Ml9cZp = OO6b35eNBQiuEzytphGa()
	VlreD97dS4m6NvsAoXK3h1MG0O = isWjwHOERYXhAp0ZuNdKUgkCM7.stat(OOyYgPK57Ex6fq4XkrQ8Ml9cZp).st_mtime
	M8x7cvbo3JjtsQF = []
	if mmIKCGujwM: bUvtj7rO2Qa = isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(OOyYgPK57Ex6fq4XkrQ8Ml9cZp.encode(VH9MDo5z1kxNF07uRJI(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: bUvtj7rO2Qa = isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(OOyYgPK57Ex6fq4XkrQ8Ml9cZp.decode(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for CG0rXeItomMwO3vjcFslKSYT in bUvtj7rO2Qa:
		if mmIKCGujwM: CG0rXeItomMwO3vjcFslKSYT = CG0rXeItomMwO3vjcFslKSYT.decode(EEvLoMzFqrlKce(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not CG0rXeItomMwO3vjcFslKSYT.startswith(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		G6ifUknM2AgSj = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(OOyYgPK57Ex6fq4XkrQ8Ml9cZp,CG0rXeItomMwO3vjcFslKSYT)
		VlreD97dS4m6NvsAoXK3h1MG0O = isWjwHOERYXhAp0ZuNdKUgkCM7.path.getmtime(G6ifUknM2AgSj)
		M8x7cvbo3JjtsQF.append([CG0rXeItomMwO3vjcFslKSYT,VlreD97dS4m6NvsAoXK3h1MG0O])
	M8x7cvbo3JjtsQF = sorted(M8x7cvbo3JjtsQF,reverse=vatyjK4hHAoZJ7rOq2lis(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶৲")])
	for CG0rXeItomMwO3vjcFslKSYT,VlreD97dS4m6NvsAoXK3h1MG0O in M8x7cvbo3JjtsQF:
		if ggl6zFuXNdYTDieHCqGKRnVx:
			try: CG0rXeItomMwO3vjcFslKSYT = CG0rXeItomMwO3vjcFslKSYT.decode(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			CG0rXeItomMwO3vjcFslKSYT = CG0rXeItomMwO3vjcFslKSYT.encode(f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		G6ifUknM2AgSj = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(OOyYgPK57Ex6fq4XkrQ8Ml9cZp,CG0rXeItomMwO3vjcFslKSYT)
		QQmLIZC8uas9fNiJWOnhdGvgFR(TWexH5PhS1(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),CG0rXeItomMwO3vjcFslKSYT,G6ifUknM2AgSj,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠹࠳࠲৳"))
	return
def OO6b35eNBQiuEzytphGa():
	OOyYgPK57Ex6fq4XkrQ8Ml9cZp = YTPut68WBVUNCvsEzg.getSetting(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if OOyYgPK57Ex6fq4XkrQ8Ml9cZp: return OOyYgPK57Ex6fq4XkrQ8Ml9cZp
	YTPut68WBVUNCvsEzg.setSetting(vatyjK4hHAoZJ7rOq2lis(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),jNhH3xrnWkFUqv8c09OybXRTl)
	return jNhH3xrnWkFUqv8c09OybXRTl
def yyrXqMPC3xIEd9uOYcNF():
	OOyYgPK57Ex6fq4XkrQ8Ml9cZp = OO6b35eNBQiuEzytphGa()
	wfbrGDlsz473NkdHWtYm = KGEAmiZ9Jq0sTXR(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),ZhqJoOtcmTVID65HwnLj(u"࠭ࠧश"),WmaPChRdQk3YcXwI6zS(u"ࠧࠨष"),sDiKwnHcSlYFgWCy1Ak(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),EmK3ObA0cwv9Wy(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+OOyYgPK57Ex6fq4XkrQ8Ml9cZp+ZhqJoOtcmTVID65HwnLj(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if wfbrGDlsz473NkdHWtYm==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠱৴"):
		sEGpc2rQgxjUdV9YPzLAqHoItfh = EGry4B7kMg1TpuYcNmn(N9olEh0ZMtpOivVfBLK(u"࠴৵"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࠧऽ"),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡇࡣ࡯ࡷࡪਟ"),ZEiR0StquOzca9lvPAndYIX(u"ࡔࡳࡷࡨਞ"),OOyYgPK57Ex6fq4XkrQ8Ml9cZp)
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),FIHNSc5iuoZanQ2Ytl(u"ࠨࠩि"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࠪी"),ZEiR0StquOzca9lvPAndYIX(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+OOyYgPK57Ex6fq4XkrQ8Ml9cZp+ttOu147wErcBvPaSMUY(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if VjwKs4GNQZ518kCl==ZEiR0StquOzca9lvPAndYIX(u"࠳৶"):
			YTPut68WBVUNCvsEzg.setSetting(PiFkQ5pCJy7fbX(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),sEGpc2rQgxjUdV9YPzLAqHoItfh)
			KK47FGdX1TDfkb3AjHOQqghE(EEvLoMzFqrlKce(u"ࠧࠨॅ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠩॆ"),TWexH5PhS1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),ttOu147wErcBvPaSMUY(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def DDRAbXNJH8FZcewailvokCyOz94x(HHPwg71GEVju,rUTwZXB4AoFRzdjnEPD2iNJKs=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬॉ"),website=N9olEh0ZMtpOivVfBLK(u"ࠬ࠭ॊ")):
	GZvEITHSg5U3rVwQ(HH4JMrUDp3lq6hQ(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+EEvLoMzFqrlKce(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+HHPwg71GEVju+PiFkQ5pCJy7fbX(u"ࠨࠢࡠ्ࠫ"))
	if not rUTwZXB4AoFRzdjnEPD2iNJKs: rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(HHPwg71GEVju)
	OOyYgPK57Ex6fq4XkrQ8Ml9cZp = OO6b35eNBQiuEzytphGa()
	ADGaJxoXtdLcSsC5R4WNj = CycHPIbdjsO7hKg93uaxTRvW4ti5X1()
	CG0rXeItomMwO3vjcFslKSYT = ADGaJxoXtdLcSsC5R4WNj.replace(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࠣࠫॎ"),l5mQdjWyczr7UJVnTp(u"ࠪࡣࠬॏ"))
	CG0rXeItomMwO3vjcFslKSYT = U5HoT3c86ZkXu927(CG0rXeItomMwO3vjcFslKSYT)
	CG0rXeItomMwO3vjcFslKSYT = sbgu4D2RFMYKm(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(EEd0FZyfticlDPAMp2HbNesx))[-l5mQdjWyczr7UJVnTp(u"࠷৷"):]+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡥࠧ॑")+CG0rXeItomMwO3vjcFslKSYT+rUTwZXB4AoFRzdjnEPD2iNJKs
	hhSwsN0YRAgrDF2HBb = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(OOyYgPK57Ex6fq4XkrQ8Ml9cZp,CG0rXeItomMwO3vjcFslKSYT)
	z1megRlwFGk6B = {}
	z1megRlwFGk6B[f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧࠨ॓")
	z1megRlwFGk6B[h5huy6MiXPNfQJF8(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩ࠭࠳࠯࠭ॕ")
	HHPwg71GEVju = HHPwg71GEVju.replace(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),EEvLoMzFqrlKce(u"ࠫࠬॗ"))
	if N0Kvne8UYar9fhRxboWsXJCVzid(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in HHPwg71GEVju:
		ll9khUfx3MjZ,zslrWLD38jgdn = HHPwg71GEVju.rsplit(WmaPChRdQk3YcXwI6zS(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),f5uqIoSJzWBOFyrY78RXmVb(u"࠵৸"))
		zslrWLD38jgdn = zslrWLD38jgdn.replace(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࡽࠩग़"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩज़")).replace(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࠩࠫड़"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࠫढ़"))
	else: ll9khUfx3MjZ,zslrWLD38jgdn = HHPwg71GEVju,None
	if not zslrWLD38jgdn: zslrWLD38jgdn = diwUZMEagkFDlS()
	if zslrWLD38jgdn: z1megRlwFGk6B[oAXJCYqPgyGDtT(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = zslrWLD38jgdn
	if WmaPChRdQk3YcXwI6zS(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in ll9khUfx3MjZ: ll9khUfx3MjZ,Zf5QgUxKW7FCOuBIdMh8swkn = ll9khUfx3MjZ.rsplit(ZhqJoOtcmTVID65HwnLj(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),FIHNSc5iuoZanQ2Ytl(u"࠶৹"))
	else: ll9khUfx3MjZ,Zf5QgUxKW7FCOuBIdMh8swkn = ll9khUfx3MjZ,N9olEh0ZMtpOivVfBLK(u"ࠧࠨॡ")
	ll9khUfx3MjZ = ll9khUfx3MjZ.strip(WmaPChRdQk3YcXwI6zS(u"ࠨࡾࠪॢ")).strip(l5mQdjWyczr7UJVnTp(u"ࠩࠩࠫॣ")).strip(HVibA2ES8lY(u"ࠪࢀࠬ।")).strip(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫࠫ࠭॥"))
	Zf5QgUxKW7FCOuBIdMh8swkn = Zf5QgUxKW7FCOuBIdMh8swkn.replace(EmK3ObA0cwv9Wy(u"ࠬࢂࠧ०"),HH4JMrUDp3lq6hQ(u"࠭ࠧ१")).replace(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧࠧࠩ२"),PiFkQ5pCJy7fbX(u"ࠨࠩ३"))
	if Zf5QgUxKW7FCOuBIdMh8swkn:	z1megRlwFGk6B[f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = Zf5QgUxKW7FCOuBIdMh8swkn
	GZvEITHSg5U3rVwQ(h5huy6MiXPNfQJF8(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+WmaPChRdQk3YcXwI6zS(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+ll9khUfx3MjZ+N9olEh0ZMtpOivVfBLK(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(z1megRlwFGk6B)+ttOu147wErcBvPaSMUY(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+hhSwsN0YRAgrDF2HBb+N9olEh0ZMtpOivVfBLK(u"ࠧࠡ࡟ࠪ९"))
	o14XhPQE6gpbnk = ttOu147wErcBvPaSMUY(u"࠷࠰࠳࠶৺")*ttOu147wErcBvPaSMUY(u"࠷࠰࠳࠶৺")
	Faq1tGzTC3k5gAbwlB8uOQU = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠰৻")
	try:
		Tpqfu6hm2akNbcY1z7xWoE5n8 =	EO9Rts0AaGuk1qpPLXCY.getInfoLabel(PiFkQ5pCJy7fbX(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		Tpqfu6hm2akNbcY1z7xWoE5n8 = T072lCzjYiuaeFtmJGV.findall(EmK3ObA0cwv9Wy(u"ࠩ࡟ࡨ࠰࠭ॱ"),Tpqfu6hm2akNbcY1z7xWoE5n8)
		Faq1tGzTC3k5gAbwlB8uOQU = int(Tpqfu6hm2akNbcY1z7xWoE5n8[Xl3drKyI9HkDiPEf8RTjwu(u"࠱ৼ")])
	except: pass
	if not Faq1tGzTC3k5gAbwlB8uOQU:
		try:
			zzdi5FoDEGeM8w1 = isWjwHOERYXhAp0ZuNdKUgkCM7.statvfs(OOyYgPK57Ex6fq4XkrQ8Ml9cZp)
			Faq1tGzTC3k5gAbwlB8uOQU = zzdi5FoDEGeM8w1.f_frsize*zzdi5FoDEGeM8w1.f_bavail//o14XhPQE6gpbnk
		except: pass
	if not Faq1tGzTC3k5gAbwlB8uOQU:
		try:
			zzdi5FoDEGeM8w1 = isWjwHOERYXhAp0ZuNdKUgkCM7.fstatvfs(OOyYgPK57Ex6fq4XkrQ8Ml9cZp)
			Faq1tGzTC3k5gAbwlB8uOQU = zzdi5FoDEGeM8w1.f_frsize*zzdi5FoDEGeM8w1.f_bavail//o14XhPQE6gpbnk
		except: pass
	if not Faq1tGzTC3k5gAbwlB8uOQU:
		try:
			import shutil as Aab7TduM1HzGLctB
			Y8Iy2qOBXhMNlzZW6s1S3t,reVgN5EkRU,ars0KVju9DiZx5AlHyNb = Aab7TduM1HzGLctB.disk_usage(OOyYgPK57Ex6fq4XkrQ8Ml9cZp)
			Faq1tGzTC3k5gAbwlB8uOQU = ars0KVju9DiZx5AlHyNb//o14XhPQE6gpbnk
		except: pass
	if not Faq1tGzTC3k5gAbwlB8uOQU:
		WWZfqplYBUhn6oxiXOmCe24bI0RA9(WmaPChRdQk3YcXwI6zS(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),f5uqIoSJzWBOFyrY78RXmVb(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),sDiKwnHcSlYFgWCy1Ak(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		GZvEITHSg5U3rVwQ(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+ttOu147wErcBvPaSMUY(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return N9olEh0ZMtpOivVfBLK(u"ࡈࡤࡰࡸ࡫ਠ")
	if rUTwZXB4AoFRzdjnEPD2iNJKs==PiFkQ5pCJy7fbX(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = w7py6bdKn1jqMSfh(ll9khUfx3MjZ,z1megRlwFGk6B)
		if len(n7CuHMSJpiR9fP0jvNEIyDUL)==HH4JMrUDp3lq6hQ(u"࠲৽"):
			fYPz7RldWQVHBktZAexwvCL8Np3D(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),h5huy6MiXPNfQJF8(u"ࠫࠬॺ"))
			return VH9MDo5z1kxNF07uRJI(u"ࡉࡥࡱࡹࡥਡ")
		elif len(n7CuHMSJpiR9fP0jvNEIyDUL)==FIHNSc5iuoZanQ2Ytl(u"࠴৾"): tzgWIKy5xQL2kjm = Xl3drKyI9HkDiPEf8RTjwu(u"࠴৿")
		elif len(n7CuHMSJpiR9fP0jvNEIyDUL)>oAXJCYqPgyGDtT(u"࠶਀"):
			tzgWIKy5xQL2kjm = sSOy1pju5PJ(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), n7CuHMSJpiR9fP0jvNEIyDUL)
			if tzgWIKy5xQL2kjm == -BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠷ਁ") :
				fYPz7RldWQVHBktZAexwvCL8Np3D(ZhqJoOtcmTVID65HwnLj(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧࠨॽ"))
				return WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡊࡦࡲࡳࡦਢ")
		ll9khUfx3MjZ = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	wwjnar5I3oQFq40LBAHUePW = sbgu4D2RFMYKm(u"࠰ਂ")
	if rUTwZXB4AoFRzdjnEPD2iNJKs==l5mQdjWyczr7UJVnTp(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		hhSwsN0YRAgrDF2HBb = hhSwsN0YRAgrDF2HBb.rsplit(EEvLoMzFqrlKce(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠱ਃ")]+ZhqJoOtcmTVID65HwnLj(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		LDJp21bZXjxVEmtK = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,sDiKwnHcSlYFgWCy1Ak(u"ࠫࡌࡋࡔࠨঁ"),ll9khUfx3MjZ,VH9MDo5z1kxNF07uRJI(u"ࠬ࠭ং"),z1megRlwFGk6B,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠧঃ"),oAXJCYqPgyGDtT(u"ࠧࠨ঄"),N9olEh0ZMtpOivVfBLK(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		gIEBHAqtvb3uZcrJCwVMfe1 = LDJp21bZXjxVEmtK.content
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall(WmaPChRdQk3YcXwI6zS(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),gIEBHAqtvb3uZcrJCwVMfe1+Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡠࡳࡢࡲࠨই"),T072lCzjYiuaeFtmJGV.DOTALL)
		if not kkH5sRPxhASFowLONy4:
			GZvEITHSg5U3rVwQ(VH9MDo5z1kxNF07uRJI(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+FIHNSc5iuoZanQ2Ytl(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+ll9khUfx3MjZ+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠠ࡞ࠩঊ"))
			return h5huy6MiXPNfQJF8(u"ࡋࡧ࡬ࡴࡧਣ")
		i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[h5huy6MiXPNfQJF8(u"࠲਄")]
		if not i8sFwPqo1vpEXR2VdHU5BmW.startswith(vatyjK4hHAoZJ7rOq2lis(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if i8sFwPqo1vpEXR2VdHU5BmW.startswith(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨ࠱࠲ࠫঌ")): i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ.split(FIHNSc5iuoZanQ2Ytl(u"ࠩ࠽ࠫ঍"),ZEiR0StquOzca9lvPAndYIX(u"࠴ਅ"))[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴ਆ")]+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪ࠾ࠬ঎")+i8sFwPqo1vpEXR2VdHU5BmW
			elif i8sFwPqo1vpEXR2VdHU5BmW.startswith(sbgu4D2RFMYKm(u"ࠫ࠴࠭এ")): i8sFwPqo1vpEXR2VdHU5BmW = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,h5huy6MiXPNfQJF8(u"ࠬࡻࡲ࡭ࠩঐ"))+i8sFwPqo1vpEXR2VdHU5BmW
			else: i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ.rsplit(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭࠯ࠨ঑"),VH9MDo5z1kxNF07uRJI(u"࠶ਇ"))[ZEiR0StquOzca9lvPAndYIX(u"࠶ਈ")]+Xl3drKyI9HkDiPEf8RTjwu(u"ࠧ࠰ࠩ঒")+i8sFwPqo1vpEXR2VdHU5BmW
		LDJp21bZXjxVEmtK = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.request(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡉࡈࡘࠬও"),i8sFwPqo1vpEXR2VdHU5BmW,headers=z1megRlwFGk6B,verify=PiFkQ5pCJy7fbX(u"ࡌࡡ࡭ࡵࡨਤ"))
		kg2o6T7WvBsFnZ5h = LDJp21bZXjxVEmtK.content
		evZ8K63CyX9kfPUdwARianojh = len(kg2o6T7WvBsFnZ5h)
		zhYRHq4NmT = len(kkH5sRPxhASFowLONy4)
		wwjnar5I3oQFq40LBAHUePW = evZ8K63CyX9kfPUdwARianojh*zhYRHq4NmT
	else:
		evZ8K63CyX9kfPUdwARianojh = ZhqJoOtcmTVID65HwnLj(u"࠱ਉ")*o14XhPQE6gpbnk
		LDJp21bZXjxVEmtK = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.request(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࡊࡉ࡙࠭ঔ"),ll9khUfx3MjZ,headers=z1megRlwFGk6B,verify=ZEiR0StquOzca9lvPAndYIX(u"ࡇࡣ࡯ࡷࡪਦ"),stream=EEvLoMzFqrlKce(u"ࡔࡳࡷࡨਥ"))
		if vatyjK4hHAoZJ7rOq2lis(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in LDJp21bZXjxVEmtK.headers: wwjnar5I3oQFq40LBAHUePW = int(LDJp21bZXjxVEmtK.headers[N9olEh0ZMtpOivVfBLK(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		zhYRHq4NmT = int(wwjnar5I3oQFq40LBAHUePW//evZ8K63CyX9kfPUdwARianojh)
	WWVcIMHwjXanC0qOJ = int(wwjnar5I3oQFq40LBAHUePW//o14XhPQE6gpbnk)+WmaPChRdQk3YcXwI6zS(u"࠲ਊ")
	if wwjnar5I3oQFq40LBAHUePW<TWexH5PhS1(u"࠴࠴࠴࠵࠶਋"):
		GZvEITHSg5U3rVwQ(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+l5mQdjWyczr7UJVnTp(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+ll9khUfx3MjZ+VOq8Ekue4F(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(WWVcIMHwjXanC0qOJ)+l5mQdjWyczr7UJVnTp(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(Faq1tGzTC3k5gAbwlB8uOQU)+EEvLoMzFqrlKce(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+hhSwsN0YRAgrDF2HBb+h5huy6MiXPNfQJF8(u"ࠪࠤࡢ࠭জ"))
		KK47FGdX1TDfkb3AjHOQqghE(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠬঝ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࠭ঞ"),ZEiR0StquOzca9lvPAndYIX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),VOq8Ekue4F(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return EmK3ObA0cwv9Wy(u"ࡈࡤࡰࡸ࡫ਧ")
	jpvqr8zmL5BAC = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠷࠴࠵਌")
	iACaMKDOBRHvYIXjfz8TnLr7cue40W = Faq1tGzTC3k5gAbwlB8uOQU-WWVcIMHwjXanC0qOJ
	if iACaMKDOBRHvYIXjfz8TnLr7cue40W<jpvqr8zmL5BAC:
		GZvEITHSg5U3rVwQ(oAXJCYqPgyGDtT(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+VH9MDo5z1kxNF07uRJI(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+ll9khUfx3MjZ+EEvLoMzFqrlKce(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(WWVcIMHwjXanC0qOJ)+sbgu4D2RFMYKm(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(Faq1tGzTC3k5gAbwlB8uOQU)+ZhqJoOtcmTVID65HwnLj(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(jpvqr8zmL5BAC)+sbgu4D2RFMYKm(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+hhSwsN0YRAgrDF2HBb+sDiKwnHcSlYFgWCy1Ak(u"ࠧࠡ࡟ࠪধ"))
		KK47FGdX1TDfkb3AjHOQqghE(EEvLoMzFqrlKce(u"ࠨࠩন"),h5huy6MiXPNfQJF8(u"ࠩࠪ঩"),EEvLoMzFqrlKce(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(WWVcIMHwjXanC0qOJ)+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(Faq1tGzTC3k5gAbwlB8uOQU)+EEvLoMzFqrlKce(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(jpvqr8zmL5BAC)+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return cbngtp9sqYi0DjeEMLRHJruKxm(u"ࡉࡥࡱࡹࡥਨ")
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࠪর"),sbgu4D2RFMYKm(u"ࠪࠫ঱"),FIHNSc5iuoZanQ2Ytl(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),EEvLoMzFqrlKce(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(WWVcIMHwjXanC0qOJ)+VOq8Ekue4F(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(Faq1tGzTC3k5gAbwlB8uOQU)+ZEiR0StquOzca9lvPAndYIX(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if VjwKs4GNQZ518kCl!=EEvLoMzFqrlKce(u"࠵਍"):
		KK47FGdX1TDfkb3AjHOQqghE(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠩশ"),PiFkQ5pCJy7fbX(u"ࠩࠪষ"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࠫস"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		GZvEITHSg5U3rVwQ(WmaPChRdQk3YcXwI6zS(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+ll9khUfx3MjZ+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+hhSwsN0YRAgrDF2HBb+ZhqJoOtcmTVID65HwnLj(u"ࠨࠢࡠࠫঽ"))
		return S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡊࡦࡲࡳࡦ਩")
	GZvEITHSg5U3rVwQ(HVibA2ES8lY(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	GwL9s6vAgzS0naR5Yc7ETm2xFO = RNrYlESg2f0OLJnG7wQ()
	GwL9s6vAgzS0naR5Yc7ETm2xFO.create(hhSwsN0YRAgrDF2HBb,EEvLoMzFqrlKce(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	Ouq1Ef3r8oJl6Vwpb = TWexH5PhS1(u"࡙ࡸࡵࡦਪ")
	yvuYVFPClBd03mc8 = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
	if mmIKCGujwM: mP5G0bUs1KC9onekY = open(hhSwsN0YRAgrDF2HBb,VH9MDo5z1kxNF07uRJI(u"ࠬࡽࡢࠨু"))
	else: mP5G0bUs1KC9onekY = open(hhSwsN0YRAgrDF2HBb.decode(HVibA2ES8lY(u"࠭ࡵࡵࡨ࠻ࠫূ")),ttOu147wErcBvPaSMUY(u"ࠧࡸࡤࠪৃ"))
	if rUTwZXB4AoFRzdjnEPD2iNJKs==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for H3ABEcMzfyqwF4Ug2ZYtK in range(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶਎"),zhYRHq4NmT+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶਎")):
			i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[H3ABEcMzfyqwF4Ug2ZYtK-Xl3drKyI9HkDiPEf8RTjwu(u"࠷ਏ")]
			if not i8sFwPqo1vpEXR2VdHU5BmW.startswith(EEvLoMzFqrlKce(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if i8sFwPqo1vpEXR2VdHU5BmW.startswith(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪ࠳࠴࠭৆")): i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ.split(sbgu4D2RFMYKm(u"ࠫ࠿࠭ে"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠱ਐ"))[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠱਑")]+VH9MDo5z1kxNF07uRJI(u"ࠬࡀࠧৈ")+i8sFwPqo1vpEXR2VdHU5BmW
				elif i8sFwPqo1vpEXR2VdHU5BmW.startswith(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭࠯ࠨ৉")): i8sFwPqo1vpEXR2VdHU5BmW = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡶࡴ࡯ࠫ৊"))+i8sFwPqo1vpEXR2VdHU5BmW
				else: i8sFwPqo1vpEXR2VdHU5BmW = ll9khUfx3MjZ.rsplit(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨ࠱ࠪো"),PiFkQ5pCJy7fbX(u"࠳਒"))[VH9MDo5z1kxNF07uRJI(u"࠳ਓ")]+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠩ࠲ࠫৌ")+i8sFwPqo1vpEXR2VdHU5BmW
			LDJp21bZXjxVEmtK = CXkpD6Z1VSmqKleB8TfOFU4R7zdyh5.request(WmaPChRdQk3YcXwI6zS(u"ࠪࡋࡊ্࡚ࠧ"),i8sFwPqo1vpEXR2VdHU5BmW,headers=z1megRlwFGk6B,verify=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࡌࡡ࡭ࡵࡨਫ"))
			kg2o6T7WvBsFnZ5h = LDJp21bZXjxVEmtK.content
			LDJp21bZXjxVEmtK.close()
			mP5G0bUs1KC9onekY.write(kg2o6T7WvBsFnZ5h)
			uuZoc27DKUW = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
			AQKuISltW9x = uuZoc27DKUW-yvuYVFPClBd03mc8
			GGculYOiNytf8V5CshmnE = AQKuISltW9x//H3ABEcMzfyqwF4Ug2ZYtK
			G78GOSB36KA0ILn9tMekH = GGculYOiNytf8V5CshmnE*(zhYRHq4NmT+f5uqIoSJzWBOFyrY78RXmVb(u"࠵ਔ"))
			KRsBL2Xj7VAovJzQnkTSmNa9GpC6M = G78GOSB36KA0ILn9tMekH-AQKuISltW9x
			pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,int(N9olEh0ZMtpOivVfBLK(u"࠷࠰࠱ਖ")*H3ABEcMzfyqwF4Ug2ZYtK//(zhYRHq4NmT+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠶ਕ"))),sDiKwnHcSlYFgWCy1Ak(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(H3ABEcMzfyqwF4Ug2ZYtK*evZ8K63CyX9kfPUdwARianojh//o14XhPQE6gpbnk)+l5mQdjWyczr7UJVnTp(u"࠭࠯ࠨ৐")+str(WWVcIMHwjXanC0qOJ)+WmaPChRdQk3YcXwI6zS(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime(oAXJCYqPgyGDtT(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),D1vBJgya85Yh4cRTCkIMKtWLSeH.gmtime(KRsBL2Xj7VAovJzQnkTSmNa9GpC6M))+ZhqJoOtcmTVID65HwnLj(u"ࠩࠣไࠬ৓"))
			if GwL9s6vAgzS0naR5Yc7ETm2xFO.iscanceled():
				Ouq1Ef3r8oJl6Vwpb = l5mQdjWyczr7UJVnTp(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		H3ABEcMzfyqwF4Ug2ZYtK = ZEiR0StquOzca9lvPAndYIX(u"࠰ਗ")
		for kg2o6T7WvBsFnZ5h in LDJp21bZXjxVEmtK.iter_content(chunk_size=evZ8K63CyX9kfPUdwARianojh):
			mP5G0bUs1KC9onekY.write(kg2o6T7WvBsFnZ5h)
			H3ABEcMzfyqwF4Ug2ZYtK = H3ABEcMzfyqwF4Ug2ZYtK+WmaPChRdQk3YcXwI6zS(u"࠲ਘ")
			uuZoc27DKUW = D1vBJgya85Yh4cRTCkIMKtWLSeH.time()
			AQKuISltW9x = uuZoc27DKUW-yvuYVFPClBd03mc8
			GGculYOiNytf8V5CshmnE = AQKuISltW9x/H3ABEcMzfyqwF4Ug2ZYtK
			G78GOSB36KA0ILn9tMekH = GGculYOiNytf8V5CshmnE*(zhYRHq4NmT+vatyjK4hHAoZJ7rOq2lis(u"࠳ਙ"))
			KRsBL2Xj7VAovJzQnkTSmNa9GpC6M = G78GOSB36KA0ILn9tMekH-AQKuISltW9x
			pGEkoTq6MimvXUVf34tBrhAuHW0O(GwL9s6vAgzS0naR5Yc7ETm2xFO,int(VH9MDo5z1kxNF07uRJI(u"࠵࠵࠶ਛ")*H3ABEcMzfyqwF4Ug2ZYtK/(zhYRHq4NmT+oAXJCYqPgyGDtT(u"࠴ਚ"))),PiFkQ5pCJy7fbX(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),TWexH5PhS1(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(H3ABEcMzfyqwF4Ug2ZYtK*evZ8K63CyX9kfPUdwARianojh//o14XhPQE6gpbnk)+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬ࠵ࠧ৖")+str(WWVcIMHwjXanC0qOJ)+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),D1vBJgya85Yh4cRTCkIMKtWLSeH.gmtime(KRsBL2Xj7VAovJzQnkTSmNa9GpC6M))+VOq8Ekue4F(u"ࠨࠢใࠫ৙"))
			if GwL9s6vAgzS0naR5Yc7ETm2xFO.iscanceled():
				Ouq1Ef3r8oJl6Vwpb = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		LDJp21bZXjxVEmtK.close()
	mP5G0bUs1KC9onekY.close()
	GwL9s6vAgzS0naR5Yc7ETm2xFO.close()
	if not Ouq1Ef3r8oJl6Vwpb:
		GZvEITHSg5U3rVwQ(sbgu4D2RFMYKm(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+ll9khUfx3MjZ+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+hhSwsN0YRAgrDF2HBb+WmaPChRdQk3YcXwI6zS(u"ࠬࠦ࡝ࠨঢ়"))
		KK47FGdX1TDfkb3AjHOQqghE(EmK3ObA0cwv9Wy(u"࠭ࠧ৞"),ttOu147wErcBvPaSMUY(u"ࠧࠨয়"),N9olEh0ZMtpOivVfBLK(u"ࠨࠩৠ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return oAXJCYqPgyGDtT(u"ࡖࡵࡹࡪਮ")
	GZvEITHSg5U3rVwQ(WmaPChRdQk3YcXwI6zS(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+oAXJCYqPgyGDtT(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+ll9khUfx3MjZ+vatyjK4hHAoZJ7rOq2lis(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+hhSwsN0YRAgrDF2HBb+vatyjK4hHAoZJ7rOq2lis(u"࠭ࠠ࡞ࠩ৥"))
	KK47FGdX1TDfkb3AjHOQqghE(HH4JMrUDp3lq6hQ(u"ࠧࠨ০"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠨࠩ১"),oAXJCYqPgyGDtT(u"ࠩࠪ২"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return ttOu147wErcBvPaSMUY(u"ࡗࡶࡺ࡫ਯ")
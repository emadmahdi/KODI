# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'CIMAFANS'
headers = { 'User-Agent' : '' }
JJCLnkX4TozH7Bsjivfe = '_CMF_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==90: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==91: cLCisPE3lX = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(url)
	elif mode==92: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==94: cLCisPE3lX = lTDhLSWw0YXprJzxfZNejCmO()
	elif mode==95: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==99: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المضاف حديثا','',94)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الأحدث',HbiLZQKalC+'/?type=latest',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الأعلى تقيماً',HbiLZQKalC+'/?type=imdb',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الأكثر مشاهدة',HbiLZQKalC+'/?type=view',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المثبت',HbiLZQKalC+'/?type=pin',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'جديد الأفلام',HbiLZQKalC+'/?type=newMovies',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'جديد الحلقات',HbiLZQKalC+'/?type=newEpisodes',91)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','CIMAFANS-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="mainmenu(.*?)nav',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('<li><a href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	OZYvGX7EMx05KH1fI = ['افلام للكبار فقط']
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = title.strip(' ')
		if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,91)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	else:
		headers = { 'User-Agent' : '' }
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="movies-items(.*?)class="listfoot"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	else: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = ''
	items = T072lCzjYiuaeFtmJGV.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة [0-9]+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if XSCYbwaqRBtopUc9H2QZu86gA5N:
				title = '_MOD_'+XSCYbwaqRBtopUc9H2QZu86gA5N[0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,95,o3gHuBtrRN)
					BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/video/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,92,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,91,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<a href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			title = title.replace('الصفحة ','')
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,91)
	return
def UAB8vizclM6XG4Pw(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','CIMAFANS-EPISODES-1st')
	o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	o3gHuBtrRN = o3gHuBtrRN[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="episodes-panel(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		name = T072lCzjYiuaeFtmJGV.findall('itemprop="title">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if name: name = name[1]
		else:
			name = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?name">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+name+' - '+title,i8sFwPqo1vpEXR2VdHU5BmW,92,o3gHuBtrRN)
	else:
		mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('class="movietitle"><a href="(.*?)">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if mnN8GgS1XEePILK0DC49qky6UzZ: i8sFwPqo1vpEXR2VdHU5BmW,title = mnN8GgS1XEePILK0DC49qky6UzZ[0]
		else: i8sFwPqo1vpEXR2VdHU5BmW,title = url,name
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,92,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA,UmCMRfwcVPdaSW1uIXzkEO = [],[]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','CIMAFANS-PLAY-1st')
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('text-shadow: none;">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="links-panel(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?__download'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('nav-tabs"(.*?)video-panel-more',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('id="(.*?)".*?embed src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,i8sFwPqo1vpEXR2VdHU5BmW in items:
			title = 'سيرفر '+id
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		items = T072lCzjYiuaeFtmJGV.findall('data-server-src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in items:
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
			i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def lTDhLSWw0YXprJzxfZNejCmO():
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,HbiLZQKalC,'',headers,'','CIMAFANS-LATEST-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="index-last-movie(.*?)id="index-slider-movie',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if '/video/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,92,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,91,o3gHuBtrRN)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC + '/search.php?t='+search
	yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(url)
	return
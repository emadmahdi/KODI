# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
from PIL import ImageDraw as AAUsBktvRdn,ImageFont as zP8A0c3YCN7oq9ElMdevh,Image as dxirsWfnmcZVC2vMPtTewlH3RQ
from arabic_reshaper import ArabicReshaper as pqeG1hsSZXD0lvT7P
eNv8QX5p0UAnMx6sdk = 'EXCLUDES'
def fhCmDOqLUEu49r8Z3Y7Ra(XLVqPOIzGJl6KUyQ23d9,yyubWejrMZsO):
	yyubWejrMZsO = yyubWejrMZsO.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	LDnoj5l47OyGmpvdJMZ = T072lCzjYiuaeFtmJGV.findall('[a-zA-Z]',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
	if 'بحث IPTV - ' in XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('بحث IPTV - ',zWyErX8YHiLsemj9G6lb2p1+'بحث IPTV - '+zWyErX8YHiLsemj9G6lb2p1)
	elif ' IPTV' in XLVqPOIzGJl6KUyQ23d9 and yyubWejrMZsO=='IPT': XLVqPOIzGJl6KUyQ23d9 = zWyErX8YHiLsemj9G6lb2p1+XLVqPOIzGJl6KUyQ23d9
	elif 'بحث M3U - ' in XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('بحث M3U - ',zWyErX8YHiLsemj9G6lb2p1+'بحث M3U - '+zWyErX8YHiLsemj9G6lb2p1)
	elif ' M3U' in XLVqPOIzGJl6KUyQ23d9 and yyubWejrMZsO=='M3U': XLVqPOIzGJl6KUyQ23d9 = zWyErX8YHiLsemj9G6lb2p1+XLVqPOIzGJl6KUyQ23d9
	elif 'بحث ' in XLVqPOIzGJl6KUyQ23d9 and ' - ' in XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = zWyErX8YHiLsemj9G6lb2p1+XLVqPOIzGJl6KUyQ23d9
	elif not LDnoj5l47OyGmpvdJMZ:
		UUdyvD3wtHr9IEcVeK6JQa7xpG = T072lCzjYiuaeFtmJGV.findall('^( *?)(.*?)( *?)$',XLVqPOIzGJl6KUyQ23d9)
		M8mI034SOHkEdPDy,VnRs7myh45pAEMXFdc6aK,Cc7aIxpDZqT9yUi0EfYeF6 = UUdyvD3wtHr9IEcVeK6JQa7xpG[0]
		l9t8yH02obXB = T072lCzjYiuaeFtmJGV.findall('^([!-~])',VnRs7myh45pAEMXFdc6aK)
		if l9t8yH02obXB: XLVqPOIzGJl6KUyQ23d9 = M8mI034SOHkEdPDy+sfquhCGUwdvRl96izX+VnRs7myh45pAEMXFdc6aK+Cc7aIxpDZqT9yUi0EfYeF6
		else: XLVqPOIzGJl6KUyQ23d9 = Cc7aIxpDZqT9yUi0EfYeF6+zWyErX8YHiLsemj9G6lb2p1+VnRs7myh45pAEMXFdc6aK+M8mI034SOHkEdPDy
	else:
		if 1:
			QO0b4qfEVNI6AT3S = XLVqPOIzGJl6KUyQ23d9
			sQXn2chpbmOEjv8N6dSu3r = xAK6z48JXSbmultUw2BY.get_display(XLVqPOIzGJl6KUyQ23d9,base_dir='L')
			if ggl6zFuXNdYTDieHCqGKRnVx: QO0b4qfEVNI6AT3S = QO0b4qfEVNI6AT3S.decode('utf8')
			if ggl6zFuXNdYTDieHCqGKRnVx: sQXn2chpbmOEjv8N6dSu3r = sQXn2chpbmOEjv8N6dSu3r.decode('utf8')
			mZ8ebRBx6I0oGX23wvlrQTC = QO0b4qfEVNI6AT3S.split(' ')
			ORuX4nZbYymvUVpotWche80 = sQXn2chpbmOEjv8N6dSu3r.split(' ')
			W7dXV5xlqpY2ThM,nNuV8y4lkUTbiawLtZmG,XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f,QhzGaDPmBAjbgci = [],[],'',''
			zTgDCGJ8RjO0Kb462ZoQ5mUIYHc = zip(mZ8ebRBx6I0oGX23wvlrQTC,ORuX4nZbYymvUVpotWche80)
			for e59Q0gsav78Lm,t1toKjb2TPxO3dCReSpGABI68gQXNv in zTgDCGJ8RjO0Kb462ZoQ5mUIYHc:
				if e59Q0gsav78Lm==t1toKjb2TPxO3dCReSpGABI68gQXNv=='' and QhzGaDPmBAjbgci:
					XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f += ' '
					continue
				if e59Q0gsav78Lm==t1toKjb2TPxO3dCReSpGABI68gQXNv:
					LB7j16vfXy5RlZ8 = 'EN'
					if QhzGaDPmBAjbgci==LB7j16vfXy5RlZ8: XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f += ' '+e59Q0gsav78Lm
					elif e59Q0gsav78Lm:
						if XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f:
							nNuV8y4lkUTbiawLtZmG.append(XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f)
							W7dXV5xlqpY2ThM.append('')
						XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f = e59Q0gsav78Lm
				else:
					LB7j16vfXy5RlZ8 = 'AR'
					if QhzGaDPmBAjbgci==LB7j16vfXy5RlZ8: XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f += ' '+e59Q0gsav78Lm
					elif e59Q0gsav78Lm:
						if XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f:
							W7dXV5xlqpY2ThM.append(XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f)
							nNuV8y4lkUTbiawLtZmG.append('')
						XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f = e59Q0gsav78Lm
				QhzGaDPmBAjbgci = LB7j16vfXy5RlZ8
			if LB7j16vfXy5RlZ8=='EN':
				W7dXV5xlqpY2ThM.append(XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f)
				nNuV8y4lkUTbiawLtZmG.append('')
			else:
				nNuV8y4lkUTbiawLtZmG.append(XJgjMZ8Q0hbc3q9CYiBVyKLGzoH1f)
				W7dXV5xlqpY2ThM.append('')
			hm03LDo24snUIiAbVFcxQeE = ''
			zTgDCGJ8RjO0Kb462ZoQ5mUIYHc = zip(W7dXV5xlqpY2ThM,nNuV8y4lkUTbiawLtZmG)
			for gF2y9pMRVQ6tvzCh1B04UeHaE5XS,e7e6qYSoTiyxVJlKnt in zTgDCGJ8RjO0Kb462ZoQ5mUIYHc:
				if gF2y9pMRVQ6tvzCh1B04UeHaE5XS: hm03LDo24snUIiAbVFcxQeE += ' '+gF2y9pMRVQ6tvzCh1B04UeHaE5XS
				else:
					l9t8yH02obXB = T072lCzjYiuaeFtmJGV.findall('([!-~]) *$',e7e6qYSoTiyxVJlKnt)
					if l9t8yH02obXB:
						l9t8yH02obXB = l9t8yH02obXB[0]
						try:
							qyYUjGOfvh7WrdX = R5dhKZmoNf8rSOewTP2.MIRRORED[l9t8yH02obXB]
							UUdyvD3wtHr9IEcVeK6JQa7xpG = T072lCzjYiuaeFtmJGV.findall('^( *?)(.*?)( *?)$',e7e6qYSoTiyxVJlKnt)
							if UUdyvD3wtHr9IEcVeK6JQa7xpG: M8mI034SOHkEdPDy,e7e6qYSoTiyxVJlKnt,Cc7aIxpDZqT9yUi0EfYeF6 = UUdyvD3wtHr9IEcVeK6JQa7xpG[0]
							e7e6qYSoTiyxVJlKnt = M8mI034SOHkEdPDy+qyYUjGOfvh7WrdX+e7e6qYSoTiyxVJlKnt[:-1]+Cc7aIxpDZqT9yUi0EfYeF6
						except: pass
					hm03LDo24snUIiAbVFcxQeE += ' '+e7e6qYSoTiyxVJlKnt
			XLVqPOIzGJl6KUyQ23d9 = hm03LDo24snUIiAbVFcxQeE[1:]
			if ggl6zFuXNdYTDieHCqGKRnVx: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.encode('utf8')
		else:
			if ggl6zFuXNdYTDieHCqGKRnVx: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.decode('utf8')
			XLVqPOIzGJl6KUyQ23d9 = xAK6z48JXSbmultUw2BY.get_display(XLVqPOIzGJl6KUyQ23d9)
			QO0b4qfEVNI6AT3S,sQXn2chpbmOEjv8N6dSu3r = XLVqPOIzGJl6KUyQ23d9,XLVqPOIzGJl6KUyQ23d9
			if 1:
				QhzGaDPmBAjbgci,f0w1jFaKJzqYOTQvsDu = '',[]
				xeYFdwAlCgPibW2TI = XLVqPOIzGJl6KUyQ23d9.split(' ')
				for ntDYuUdCW69Av24KpiTNMgZk in xeYFdwAlCgPibW2TI:
					if not ntDYuUdCW69Av24KpiTNMgZk:
						if f0w1jFaKJzqYOTQvsDu: f0w1jFaKJzqYOTQvsDu[-1] += ' '
						else: f0w1jFaKJzqYOTQvsDu.append('')
						continue
					w5wcrA7UJmOHV6ZohCPz9q8GjYDW = T072lCzjYiuaeFtmJGV.findall('[!-~]',ntDYuUdCW69Av24KpiTNMgZk[0])
					if w5wcrA7UJmOHV6ZohCPz9q8GjYDW==QhzGaDPmBAjbgci and f0w1jFaKJzqYOTQvsDu: f0w1jFaKJzqYOTQvsDu[-1] += ' '+ntDYuUdCW69Av24KpiTNMgZk
					else:
						if f0w1jFaKJzqYOTQvsDu:
							ZZLWXt2sfrFkPBSOjuRVpY = T072lCzjYiuaeFtmJGV.findall('[^!-~]',f0w1jFaKJzqYOTQvsDu[-1])
							if ZZLWXt2sfrFkPBSOjuRVpY:
								f0w1jFaKJzqYOTQvsDu[-1] = xAK6z48JXSbmultUw2BY.get_display(f0w1jFaKJzqYOTQvsDu[-1])
								ldVTmyKZEM63A7XwvDP8Hn = T072lCzjYiuaeFtmJGV.findall('^ +',f0w1jFaKJzqYOTQvsDu[-1])
								if ldVTmyKZEM63A7XwvDP8Hn: f0w1jFaKJzqYOTQvsDu[-1] = f0w1jFaKJzqYOTQvsDu[-1].lstrip(' ')+ldVTmyKZEM63A7XwvDP8Hn[0]
						f0w1jFaKJzqYOTQvsDu.append(ntDYuUdCW69Av24KpiTNMgZk)
					QhzGaDPmBAjbgci = w5wcrA7UJmOHV6ZohCPz9q8GjYDW
				if f0w1jFaKJzqYOTQvsDu: f0w1jFaKJzqYOTQvsDu[-1] = xAK6z48JXSbmultUw2BY.get_display(f0w1jFaKJzqYOTQvsDu[-1])
				XLVqPOIzGJl6KUyQ23d9 = ' '.join(f0w1jFaKJzqYOTQvsDu)
			if ggl6zFuXNdYTDieHCqGKRnVx: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.encode('utf8')
	return XLVqPOIzGJl6KUyQ23d9
def zmxdfPbJ6AjN52ekGTD4IBEM(a8urgUhxk3b0,ZJeO07Cipq9UPIDXYTEfVbo,ZUtCBaFAQdyzk1DRG25j9meEM3):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,LBjTYkOzKcPsUoVeZIQAJud4,AG7n5jd4sXMzyZ2wFhi6uEkKx,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = a8urgUhxk3b0
	EHnSrqQ7BvmGlOgYZdhTbCRtswA = int(EHnSrqQ7BvmGlOgYZdhTbCRtswA)
	HrRJ8kXGvL5TWfZ21B6Mu9zsE = T072lCzjYiuaeFtmJGV.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
	if HrRJ8kXGvL5TWfZ21B6Mu9zsE:
		HrRJ8kXGvL5TWfZ21B6Mu9zsE,BBfJPlu6O0oYveHdEgM3pX9ixZRS,OCU0RkWn7INDPd9zX1LcAyeq = HrRJ8kXGvL5TWfZ21B6Mu9zsE[0]
		XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace(HrRJ8kXGvL5TWfZ21B6Mu9zsE,'')
	jfngacrQFzTwYK8yq = XLVqPOIzGJl6KUyQ23d9
	yyubWejrMZsO = T072lCzjYiuaeFtmJGV.findall('^_(\w\w\w)_(.*?)$',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
	if yyubWejrMZsO:
		yyubWejrMZsO,XLVqPOIzGJl6KUyQ23d9 = yyubWejrMZsO[0]
		mhiFv1OIEc = '_MOD_' in XLVqPOIzGJl6KUyQ23d9
		kQ3iPAjXHKCWe = ga4p3IxqUXMjTRPQZfH9J5E=='folder'
		if mhiFv1OIEc and kQ3iPAjXHKCWe: kk7tQHZxGD9fse8pymJU3lrCY2 = ';'
		elif mhiFv1OIEc and not kQ3iPAjXHKCWe: kk7tQHZxGD9fse8pymJU3lrCY2 = ZhR6zf92IPocOL0sC
		elif not mhiFv1OIEc and kQ3iPAjXHKCWe: kk7tQHZxGD9fse8pymJU3lrCY2 = ','
		elif not mhiFv1OIEc and not kQ3iPAjXHKCWe: kk7tQHZxGD9fse8pymJU3lrCY2 = ' '
		XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('_MOD_','')
		yyubWejrMZsO = kk7tQHZxGD9fse8pymJU3lrCY2+'[COLOR FFC89008]'+yyubWejrMZsO+' [/COLOR]'
	else: yyubWejrMZsO = ''
	if HrRJ8kXGvL5TWfZ21B6Mu9zsE:
		if ggl6zFuXNdYTDieHCqGKRnVx:
			HrRJ8kXGvL5TWfZ21B6Mu9zsE = '[COLOR FFFFFF00]'+BBfJPlu6O0oYveHdEgM3pX9ixZRS+' '+OCU0RkWn7INDPd9zX1LcAyeq+'[/COLOR]'
			if yyubWejrMZsO: XLVqPOIzGJl6KUyQ23d9 = HrRJ8kXGvL5TWfZ21B6Mu9zsE+' '+zWyErX8YHiLsemj9G6lb2p1+yyubWejrMZsO+XLVqPOIzGJl6KUyQ23d9
			else: XLVqPOIzGJl6KUyQ23d9 = HrRJ8kXGvL5TWfZ21B6Mu9zsE+zWyErX8YHiLsemj9G6lb2p1+XLVqPOIzGJl6KUyQ23d9+' '
		elif mmIKCGujwM:
			if yyubWejrMZsO:
				HrRJ8kXGvL5TWfZ21B6Mu9zsE = '[COLOR FFFFFF00]'+BBfJPlu6O0oYveHdEgM3pX9ixZRS+' '+OCU0RkWn7INDPd9zX1LcAyeq+'[/COLOR]'
				XLVqPOIzGJl6KUyQ23d9 = HrRJ8kXGvL5TWfZ21B6Mu9zsE+' '+yyubWejrMZsO+XLVqPOIzGJl6KUyQ23d9
			else:
				HrRJ8kXGvL5TWfZ21B6Mu9zsE = '[COLOR FFFFFF00]'+OCU0RkWn7INDPd9zX1LcAyeq+' '+BBfJPlu6O0oYveHdEgM3pX9ixZRS+'[/COLOR]'
				XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9+' '+zWyErX8YHiLsemj9G6lb2p1+HrRJ8kXGvL5TWfZ21B6Mu9zsE
	elif yyubWejrMZsO:
		XLVqPOIzGJl6KUyQ23d9 = fhCmDOqLUEu49r8Z3Y7Ra(XLVqPOIzGJl6KUyQ23d9,yyubWejrMZsO)
		XLVqPOIzGJl6KUyQ23d9 = yyubWejrMZsO+XLVqPOIzGJl6KUyQ23d9
	a8urgUhxk3b0 = ga4p3IxqUXMjTRPQZfH9J5E,jfngacrQFzTwYK8yq,HHPwg71GEVju,str(EHnSrqQ7BvmGlOgYZdhTbCRtswA),rHC4l56cOGQ9sX0Mj,LBjTYkOzKcPsUoVeZIQAJud4,AG7n5jd4sXMzyZ2wFhi6uEkKx,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw
	ZZMzXw8D06gc = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	ZZMzXw8D06gc['name'] = K3PukgCEDY(jfngacrQFzTwYK8yq)
	ZZMzXw8D06gc['type'] = ga4p3IxqUXMjTRPQZfH9J5E.strip(' ')
	ZZMzXw8D06gc['mode'] = str(EHnSrqQ7BvmGlOgYZdhTbCRtswA).strip(' ')
	if ga4p3IxqUXMjTRPQZfH9J5E=='folder' and LBjTYkOzKcPsUoVeZIQAJud4: ZZMzXw8D06gc['page'] = K3PukgCEDY(LBjTYkOzKcPsUoVeZIQAJud4.strip(' '))
	if c60Epz1qjmHiKMl9BY: ZZMzXw8D06gc['context'] = c60Epz1qjmHiKMl9BY.strip(' ')
	if AG7n5jd4sXMzyZ2wFhi6uEkKx: ZZMzXw8D06gc['text'] = K3PukgCEDY(AG7n5jd4sXMzyZ2wFhi6uEkKx.strip(' '))
	if rHC4l56cOGQ9sX0Mj: ZZMzXw8D06gc['image'] = K3PukgCEDY(rHC4l56cOGQ9sX0Mj.strip(' '))
	if fKFIOvsD0QVzUGLliAyw:
		fKFIOvsD0QVzUGLliAyw = str(fKFIOvsD0QVzUGLliAyw)
		ZZMzXw8D06gc['infodict'] = K3PukgCEDY(fKFIOvsD0QVzUGLliAyw.strip(' '))
		fKFIOvsD0QVzUGLliAyw = eval(fKFIOvsD0QVzUGLliAyw)
	else: fKFIOvsD0QVzUGLliAyw = {}
	if HHPwg71GEVju: ZZMzXw8D06gc['url'] = K3PukgCEDY(HHPwg71GEVju.strip(' '))
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	JuqNQDaIOtl5HGTSjpdyCE9 = []
	kFXyMG8gqZz0BD5eP6 = 'plugin://'+x7NwSuz5ft4e+'/?type='+ZZMzXw8D06gc['type']+'&mode='+ZZMzXw8D06gc['mode']
	if ZZMzXw8D06gc['page']: kFXyMG8gqZz0BD5eP6 += '&page='+ZZMzXw8D06gc['page']
	if ZZMzXw8D06gc['name']: kFXyMG8gqZz0BD5eP6 += '&name='+ZZMzXw8D06gc['name']
	if ZZMzXw8D06gc['text']: kFXyMG8gqZz0BD5eP6 += '&text='+ZZMzXw8D06gc['text']
	if ZZMzXw8D06gc['infodict']: kFXyMG8gqZz0BD5eP6 += '&infodict='+ZZMzXw8D06gc['infodict']
	if ZZMzXw8D06gc['image']: kFXyMG8gqZz0BD5eP6 += '&image='+ZZMzXw8D06gc['image']
	if ZZMzXw8D06gc['url']: kFXyMG8gqZz0BD5eP6 += '&url='+ZZMzXw8D06gc['url']
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA!=265: CGbDOtpozLTUQn0l2qfJigjsmVvcwW['favorites'] = True
	else: CGbDOtpozLTUQn0l2qfJigjsmVvcwW['favorites'] = False
	if ZZMzXw8D06gc['context']: kFXyMG8gqZz0BD5eP6 += '&context='+ZZMzXw8D06gc['context']
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA in [235,238] and ga4p3IxqUXMjTRPQZfH9J5E=='live' and 'EPG' in c60Epz1qjmHiKMl9BY:
		rIwkaoKEDFg7 = 'plugin://'+x7NwSuz5ft4e+'?mode=238&text=SHORT_EPG&url='+HHPwg71GEVju
		VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
		JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA==265:
		ePWfkMVOIjUmpuBJ = ZJeO07Cipq9UPIDXYTEfVbo(AG7n5jd4sXMzyZ2wFhi6uEkKx,True)
		if ePWfkMVOIjUmpuBJ>0:
			rIwkaoKEDFg7 = 'plugin://'+x7NwSuz5ft4e+'?mode=266&text='+AG7n5jd4sXMzyZ2wFhi6uEkKx
			VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+hqWB0vmTcxR8d3oukL(AG7n5jd4sXMzyZ2wFhi6uEkKx)+'[/COLOR]'
			iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
			JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	if ga4p3IxqUXMjTRPQZfH9J5E=='video' and EHnSrqQ7BvmGlOgYZdhTbCRtswA!=331:
		rIwkaoKEDFg7 = kFXyMG8gqZz0BD5eP6+'&context=6_DOWNLOAD'
		VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
		JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA==331:
		rIwkaoKEDFg7 = kFXyMG8gqZz0BD5eP6+'&context=6_DELETE'
		VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
		JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	if ga4p3IxqUXMjTRPQZfH9J5E=='folder' and EHnSrqQ7BvmGlOgYZdhTbCRtswA==540:
		jyTkFO7pzPYEb0sXJvUWa35hZD = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','GLOBALSEARCH_SITES')
		if jyTkFO7pzPYEb0sXJvUWa35hZD:
			rIwkaoKEDFg7 = 'plugin://'+x7NwSuz5ft4e+'?context=7'
			VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
			JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	V90Qhmp5MGJzOU3awsKC = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA not in V90Qhmp5MGJzOU3awsKC:
		rIwkaoKEDFg7 = 'plugin://'+x7NwSuz5ft4e+'?context=8&mode=260'
		VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
		JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	Ue7oLyCABasEuJ0xPSj3l = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA%10 and EHnSrqQ7BvmGlOgYZdhTbCRtswA!=9990:
		LL3oMTQCEhtmrXO6jUpb5 = EHnSrqQ7BvmGlOgYZdhTbCRtswA-EHnSrqQ7BvmGlOgYZdhTbCRtswA%10
		if LL3oMTQCEhtmrXO6jUpb5==280: LL3oMTQCEhtmrXO6jUpb5 = 230
		if LL3oMTQCEhtmrXO6jUpb5==410: LL3oMTQCEhtmrXO6jUpb5 = 400
		if LL3oMTQCEhtmrXO6jUpb5==520: LL3oMTQCEhtmrXO6jUpb5 = 510
		if LL3oMTQCEhtmrXO6jUpb5 not in Ue7oLyCABasEuJ0xPSj3l:
			rIwkaoKEDFg7 = 'plugin://'+x7NwSuz5ft4e+'?context=8&mode='+str(LL3oMTQCEhtmrXO6jUpb5)
			VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
			JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	rIwkaoKEDFg7 = kFXyMG8gqZz0BD5eP6+'&context=9'
	VVR4JD1beFIlBUQCHscAoOh7Tjn9t = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	iRozPeA05nSyIUJZukmt = (VVR4JD1beFIlBUQCHscAoOh7Tjn9t,'RunPlugin('+rIwkaoKEDFg7+')')
	JuqNQDaIOtl5HGTSjpdyCE9.append(iRozPeA05nSyIUJZukmt)
	if ga4p3IxqUXMjTRPQZfH9J5E in ['link','video','live']: jGxlsRhA1CpZoyLet9HK7EMX0YSWO = False
	elif ga4p3IxqUXMjTRPQZfH9J5E=='folder': jGxlsRhA1CpZoyLet9HK7EMX0YSWO = True
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['name'] = XLVqPOIzGJl6KUyQ23d9
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['context_menu'] = JuqNQDaIOtl5HGTSjpdyCE9
	if 'plot' in list(fKFIOvsD0QVzUGLliAyw.keys()): CGbDOtpozLTUQn0l2qfJigjsmVvcwW['plot'] = fKFIOvsD0QVzUGLliAyw['plot']
	if 'stars' in list(fKFIOvsD0QVzUGLliAyw.keys()): CGbDOtpozLTUQn0l2qfJigjsmVvcwW['stars'] = fKFIOvsD0QVzUGLliAyw['stars']
	if rHC4l56cOGQ9sX0Mj: CGbDOtpozLTUQn0l2qfJigjsmVvcwW['image'] = rHC4l56cOGQ9sX0Mj
	if ga4p3IxqUXMjTRPQZfH9J5E=='video' and LBjTYkOzKcPsUoVeZIQAJud4:
		o8oTABfnCwS6pvl3Ja = T072lCzjYiuaeFtmJGV.findall('[\d:]+',LBjTYkOzKcPsUoVeZIQAJud4,T072lCzjYiuaeFtmJGV.DOTALL)
		if o8oTABfnCwS6pvl3Ja:
			o8oTABfnCwS6pvl3Ja = '0:0:0:0:0:'+o8oTABfnCwS6pvl3Ja[0]
			K5d3YZes0JaHjGSfcVmpW,E6i84v0ewx7fhRDHFBQdrSznAl9m,vjeJaZAVLsnuo8gqSrRFptwQkh3,o8o0ayVkF9dfA,AvuMVFZbPzTQeJws6CY = o8oTABfnCwS6pvl3Ja.rsplit(':',4)
			cQsFYIMHOeJtSZhVo58AUn0Nyma9 = int(E6i84v0ewx7fhRDHFBQdrSznAl9m)*24*fxunVecQRNTGHb2LJtkBylF5+int(vjeJaZAVLsnuo8gqSrRFptwQkh3)*fxunVecQRNTGHb2LJtkBylF5+int(o8o0ayVkF9dfA)*60+int(AvuMVFZbPzTQeJws6CY)
			CGbDOtpozLTUQn0l2qfJigjsmVvcwW['duration'] = cQsFYIMHOeJtSZhVo58AUn0Nyma9
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['type'] = ga4p3IxqUXMjTRPQZfH9J5E
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['isFolder'] = jGxlsRhA1CpZoyLet9HK7EMX0YSWO
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['newpath'] = kFXyMG8gqZz0BD5eP6
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['menuItem'] = a8urgUhxk3b0
	CGbDOtpozLTUQn0l2qfJigjsmVvcwW['mode'] = EHnSrqQ7BvmGlOgYZdhTbCRtswA
	return CGbDOtpozLTUQn0l2qfJigjsmVvcwW
def cUXR35dAj2TxhWqn8veSQNyDYH(ZJeO07Cipq9UPIDXYTEfVbo):
	ygsQVv42iYDaWZ0FAI9xBLHpNehE86 = []
	from sGBzntv5FT import sK85VIGrwg0FZcWJ1E7,Rsd7jOX0rvLqQ61kwp8JFBoz4Kf
	ZUtCBaFAQdyzk1DRG25j9meEM3 = sK85VIGrwg0FZcWJ1E7()
	for a8urgUhxk3b0 in a26IqBkAXRPrwCOgFDb:
		CGbDOtpozLTUQn0l2qfJigjsmVvcwW = zmxdfPbJ6AjN52ekGTD4IBEM(a8urgUhxk3b0,ZJeO07Cipq9UPIDXYTEfVbo,ZUtCBaFAQdyzk1DRG25j9meEM3)
		if CGbDOtpozLTUQn0l2qfJigjsmVvcwW['favorites']:
			x7xyK1ArIwcWJMbftOqEu8 = Rsd7jOX0rvLqQ61kwp8JFBoz4Kf(ZUtCBaFAQdyzk1DRG25j9meEM3,CGbDOtpozLTUQn0l2qfJigjsmVvcwW['menuItem'],CGbDOtpozLTUQn0l2qfJigjsmVvcwW['newpath'])
			CGbDOtpozLTUQn0l2qfJigjsmVvcwW['context_menu'] = x7xyK1ArIwcWJMbftOqEu8+CGbDOtpozLTUQn0l2qfJigjsmVvcwW['context_menu']
		ygsQVv42iYDaWZ0FAI9xBLHpNehE86.append(CGbDOtpozLTUQn0l2qfJigjsmVvcwW)
	return ygsQVv42iYDaWZ0FAI9xBLHpNehE86
def Gljr634dWvE(yoVRGZgKlA2):
	kk7tQHZxGD9fse8pymJU3lrCY2,Q8dN2l36hAtzL7HmwjgiJox0, = [],''
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		if not vWN8xonyO4BUsEpcYqaJSGt2PL3jMw: kk7tQHZxGD9fse8pymJU3lrCY2.append('')
		else: break
	yoVRGZgKlA2 = yoVRGZgKlA2[len(kk7tQHZxGD9fse8pymJU3lrCY2):]
	yv8XxUjorzB2CRA4Jife73VMklHp = '\n\n\n\n'.join(yoVRGZgKlA2)
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('===== ===== =====','000001')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFC89008]','000002')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFFFFF00]','000003')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[/COLOR]','000004')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RIGHT]','000005')
	g80O9QtN6lbRcPiu = 100000
	xxc0L7AhBWeKXybVYSaUlPtwOrvo = {}
	uvCqjKWwmo847FaXnf0BYHepOk6 = T072lCzjYiuaeFtmJGV.findall('http.*?[\r\n ]',yv8XxUjorzB2CRA4Jife73VMklHp,T072lCzjYiuaeFtmJGV.DOTALL)
	for utQwPdAvUkrqEIFSMNblZe7sn in uvCqjKWwmo847FaXnf0BYHepOk6:
		g80O9QtN6lbRcPiu += 1
		yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace(utQwPdAvUkrqEIFSMNblZe7sn,str(g80O9QtN6lbRcPiu))
		xxc0L7AhBWeKXybVYSaUlPtwOrvo[str(g80O9QtN6lbRcPiu)] = utQwPdAvUkrqEIFSMNblZe7sn
	for hU3gvdkbXl5HVAYecR6sJGyB in range(0,len(yv8XxUjorzB2CRA4Jife73VMklHp),4800):
		pdzfkRXmVU1 = yv8XxUjorzB2CRA4Jife73VMklHp[hU3gvdkbXl5HVAYecR6sJGyB:hU3gvdkbXl5HVAYecR6sJGyB+4800]
		WkrPZXjHD9oQRtOV = YTPut68WBVUNCvsEzg.getSetting('av.language.code')
		HHPwg71GEVju = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+WkrPZXjHD9oQRtOV
		z1megRlwFGk6B = {'Content-Type':'text/plain'}
		Laf5bWDqkhyv0Er3gV1lw9josGQ = pdzfkRXmVU1.encode('utf8')
		LDJp21bZXjxVEmtK = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',HHPwg71GEVju,Laf5bWDqkhyv0Er3gV1lw9josGQ,z1megRlwFGk6B,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if LDJp21bZXjxVEmtK.succeeded:
			oJW87jcST1 = LDJp21bZXjxVEmtK.content
			HRcdu6T5owsObnE7KlDp4IvX = cwiLy4IAVJj0pWCl7FGxokR('str',oJW87jcST1)
			if HRcdu6T5owsObnE7KlDp4IvX:
				HRcdu6T5owsObnE7KlDp4IvX = HRcdu6T5owsObnE7KlDp4IvX['translation']
				HRcdu6T5owsObnE7KlDp4IvX = Bd2o0J6aOASWvuD9HzY(HRcdu6T5owsObnE7KlDp4IvX)
				for q95KQaVBR21MLxPYNsbHDl in range(len(HRcdu6T5owsObnE7KlDp4IvX)):
					Q8dN2l36hAtzL7HmwjgiJox0 += HRcdu6T5owsObnE7KlDp4IvX[q95KQaVBR21MLxPYNsbHDl][0]
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000001','===== ===== =====')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000002','[COLOR FFC89008]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000003','[COLOR FFFFFF00]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000004','[/COLOR]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000005','[RIGHT]')
	for g80O9QtN6lbRcPiu in list(xxc0L7AhBWeKXybVYSaUlPtwOrvo.keys()):
		utQwPdAvUkrqEIFSMNblZe7sn = xxc0L7AhBWeKXybVYSaUlPtwOrvo[g80O9QtN6lbRcPiu]
		Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace(g80O9QtN6lbRcPiu,utQwPdAvUkrqEIFSMNblZe7sn)
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.split('\n\n\n\n')
	return kk7tQHZxGD9fse8pymJU3lrCY2+Q8dN2l36hAtzL7HmwjgiJox0
def puxNlaZV0o4HWvyBwQ(yoVRGZgKlA2):
	kk7tQHZxGD9fse8pymJU3lrCY2,Q8dN2l36hAtzL7HmwjgiJox0, = [],''
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		if not vWN8xonyO4BUsEpcYqaJSGt2PL3jMw: kk7tQHZxGD9fse8pymJU3lrCY2.append('')
		else: break
	yoVRGZgKlA2 = yoVRGZgKlA2[len(kk7tQHZxGD9fse8pymJU3lrCY2):]
	yv8XxUjorzB2CRA4Jife73VMklHp = '\\n\\n\\n\\n'.join(yoVRGZgKlA2)
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('كلا','no')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('استمرار','continue')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('===== ===== =====','000001')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFC89008]','000002')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFFFFF00]','000003')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[/COLOR]','000004')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RIGHT]','000005')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[CENTER]','000006')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RTL]','000007')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace("'","\\\\\\'")
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('"','\\\\\\"')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('\n','\\n')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('\r','\\\\r')
	for hU3gvdkbXl5HVAYecR6sJGyB in range(0,len(yv8XxUjorzB2CRA4Jife73VMklHp),4800):
		pdzfkRXmVU1 = yv8XxUjorzB2CRA4Jife73VMklHp[hU3gvdkbXl5HVAYecR6sJGyB:hU3gvdkbXl5HVAYecR6sJGyB+4800]
		HHPwg71GEVju = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		z1megRlwFGk6B = {'Content-Type':'application/x-www-form-urlencoded'}
		WkrPZXjHD9oQRtOV = YTPut68WBVUNCvsEzg.getSetting('av.language.code')
		Laf5bWDqkhyv0Er3gV1lw9josGQ = 'f.req='+K3PukgCEDY('[[["MkEWBc","[[\\"'+pdzfkRXmVU1+'\\",\\"ar\\",\\"'+WkrPZXjHD9oQRtOV+'\\",1],[]]",null,"generic"]]]','')
		Laf5bWDqkhyv0Er3gV1lw9josGQ = Laf5bWDqkhyv0Er3gV1lw9josGQ.replace('%5Cn','%5C%5Cn')
		LDJp21bZXjxVEmtK = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',HHPwg71GEVju,Laf5bWDqkhyv0Er3gV1lw9josGQ,z1megRlwFGk6B,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if LDJp21bZXjxVEmtK.succeeded:
			oJW87jcST1 = LDJp21bZXjxVEmtK.content
			oJW87jcST1 = oJW87jcST1.split('\n')[-1]
			HRcdu6T5owsObnE7KlDp4IvX = cwiLy4IAVJj0pWCl7FGxokR('str',oJW87jcST1)[0][2]
			if HRcdu6T5owsObnE7KlDp4IvX:
				HRcdu6T5owsObnE7KlDp4IvX = cwiLy4IAVJj0pWCl7FGxokR('str',HRcdu6T5owsObnE7KlDp4IvX)[1][0][0][5]
				HRcdu6T5owsObnE7KlDp4IvX = Bd2o0J6aOASWvuD9HzY(HRcdu6T5owsObnE7KlDp4IvX)
				for q95KQaVBR21MLxPYNsbHDl in range(len(HRcdu6T5owsObnE7KlDp4IvX)):
					Q8dN2l36hAtzL7HmwjgiJox0 += HRcdu6T5owsObnE7KlDp4IvX[q95KQaVBR21MLxPYNsbHDl][0]
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('00000','0000').replace('0000','000')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0001','===== ===== =====')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0002','[COLOR FFC89008]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0003','[COLOR FFFFFF00]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0004','[/COLOR]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0005','[RIGHT]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0006','[CENTER]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0007','[RTL]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.split('\n\n\n\n')
	return kk7tQHZxGD9fse8pymJU3lrCY2+Q8dN2l36hAtzL7HmwjgiJox0
def u9lUYcMypIx(yoVRGZgKlA2):
	kk7tQHZxGD9fse8pymJU3lrCY2,wwgMhol3vsXCkzperPyVY1id = [],[]
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		if not vWN8xonyO4BUsEpcYqaJSGt2PL3jMw: kk7tQHZxGD9fse8pymJU3lrCY2.append('')
		else: break
	yoVRGZgKlA2 = yoVRGZgKlA2[len(kk7tQHZxGD9fse8pymJU3lrCY2):]
	yv8XxUjorzB2CRA4Jife73VMklHp = '\n\n\n\n'.join(yoVRGZgKlA2)
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('كلا','no')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('استمرار','continue')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('أدناه','below')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFC89008]','00001')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR FFFFFF00]','00002')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[/COLOR]','00003')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('=====','00004')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace(',','00005')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RTL]','00009')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[CENTER]','0000A')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('\r','0000B')
	yoVRGZgKlA2 = yv8XxUjorzB2CRA4Jife73VMklHp.split('\n')
	yv8XxUjorzB2CRA4Jife73VMklHp,Q8dN2l36hAtzL7HmwjgiJox0 = '',''
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		if len(yv8XxUjorzB2CRA4Jife73VMklHp+vWN8xonyO4BUsEpcYqaJSGt2PL3jMw)<1800: yv8XxUjorzB2CRA4Jife73VMklHp += '\n'+vWN8xonyO4BUsEpcYqaJSGt2PL3jMw
		else:
			wwgMhol3vsXCkzperPyVY1id.append(yv8XxUjorzB2CRA4Jife73VMklHp)
			yv8XxUjorzB2CRA4Jife73VMklHp = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw
	wwgMhol3vsXCkzperPyVY1id.append(yv8XxUjorzB2CRA4Jife73VMklHp)
	from json import dumps as Rl07dZoipsDAc
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in wwgMhol3vsXCkzperPyVY1id:
		z1megRlwFGk6B = {'Content-Type':'application/json','User-Agent':''}
		HHPwg71GEVju = 'https://api.reverso.net/translate/v1/translation'
		WkrPZXjHD9oQRtOV = YTPut68WBVUNCvsEzg.getSetting('av.language.code')
		Laf5bWDqkhyv0Er3gV1lw9josGQ = {"format":"text","from":"ara","to":WkrPZXjHD9oQRtOV,"input":vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		Laf5bWDqkhyv0Er3gV1lw9josGQ = Rl07dZoipsDAc(Laf5bWDqkhyv0Er3gV1lw9josGQ)
		LDJp21bZXjxVEmtK = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'POST',HHPwg71GEVju,Laf5bWDqkhyv0Er3gV1lw9josGQ,z1megRlwFGk6B,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if LDJp21bZXjxVEmtK.succeeded:
			oJW87jcST1 = LDJp21bZXjxVEmtK.content
			oJW87jcST1 = cwiLy4IAVJj0pWCl7FGxokR('dict',oJW87jcST1)
			Q8dN2l36hAtzL7HmwjgiJox0 += '\n'+''.join(oJW87jcST1['translation'])
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0[2:]
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000000','00000').replace('00000','0000').replace('0000','000')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0001','[COLOR FFC89008]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0002','[COLOR FFFFFF00]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0003','[/COLOR]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0004','=====')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0005',',')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('0009','[RTL]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000A','[CENTER]')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.replace('000B','\r')
	Q8dN2l36hAtzL7HmwjgiJox0 = Q8dN2l36hAtzL7HmwjgiJox0.split('\n\n\n\n')
	return kk7tQHZxGD9fse8pymJU3lrCY2+Q8dN2l36hAtzL7HmwjgiJox0
def RYmMI90awrHb8x3nf5VSXjZpK6sBo2(yoVRGZgKlA2):
	aaBWub5jtJA0rR13zNnVhHgkXwL2qE = YTPut68WBVUNCvsEzg.getSetting('av.language.translate')
	if not aaBWub5jtJA0rR13zNnVhHgkXwL2qE or not yoVRGZgKlA2: return yoVRGZgKlA2
	BTnmD1GqVNWIKORFx7ulfoQ46Mhtg = YTPut68WBVUNCvsEzg.getSetting('av.language.provider')
	WkrPZXjHD9oQRtOV = YTPut68WBVUNCvsEzg.getSetting('av.language.code')
	Nm8MnqQTrzBV2bvoFsyWdAk = WkrPZXjHD9oQRtOV+'__'+str(yoVRGZgKlA2)
	YTPut68WBVUNCvsEzg.setSetting('av.language.translate','')
	Q8dN2l36hAtzL7HmwjgiJox0 = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,'list','TRANSLATE_'+BTnmD1GqVNWIKORFx7ulfoQ46Mhtg,Nm8MnqQTrzBV2bvoFsyWdAk)
	if not Q8dN2l36hAtzL7HmwjgiJox0:
		if BTnmD1GqVNWIKORFx7ulfoQ46Mhtg=='GOOGLE': Q8dN2l36hAtzL7HmwjgiJox0 = puxNlaZV0o4HWvyBwQ(yoVRGZgKlA2)
		elif BTnmD1GqVNWIKORFx7ulfoQ46Mhtg=='REVERSO': Q8dN2l36hAtzL7HmwjgiJox0 = u9lUYcMypIx(yoVRGZgKlA2)
		elif BTnmD1GqVNWIKORFx7ulfoQ46Mhtg=='GLOSBE': Q8dN2l36hAtzL7HmwjgiJox0 = Gljr634dWvE(yoVRGZgKlA2)
		if len(yoVRGZgKlA2)==len(Q8dN2l36hAtzL7HmwjgiJox0):
			rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,'TRANSLATE_'+BTnmD1GqVNWIKORFx7ulfoQ46Mhtg,Nm8MnqQTrzBV2bvoFsyWdAk,Q8dN2l36hAtzL7HmwjgiJox0,l7S6tnfTxVX4QyHohFMCrOW15Em)
		else:
			Q8dN2l36hAtzL7HmwjgiJox0 = yoVRGZgKlA2
			fYPz7RldWQVHBktZAexwvCL8Np3D('الترجمة فشلت','Translation Failed')
	YTPut68WBVUNCvsEzg.setSetting('av.language.translate','1')
	return Q8dN2l36hAtzL7HmwjgiJox0
def ivk2tGTsBEV5WpwQ7j8Dex3CouF(a8urgUhxk3b0,ygsQVv42iYDaWZ0FAI9xBLHpNehE86,JzGp5aDTFHMe1nNKZRAoLu7Q,pOtaQuNWnESlj1RK4w7TMsb,QGl5vbqZH1uAB0y):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = a8urgUhxk3b0
	xV4PLm8U5w0q3TeZ = []
	aaBWub5jtJA0rR13zNnVhHgkXwL2qE = YTPut68WBVUNCvsEzg.getSetting('av.language.translate')
	if aaBWub5jtJA0rR13zNnVhHgkXwL2qE:
		jjTGefitB6ISFl52vRCnY0b,MbDGZqi1poU6tC0AILaBvP,mt5K9DClMYgvRuaUzpPNEQcTXHwjZ = [],[],[]
		if not xV4PLm8U5w0q3TeZ:
			for CGbDOtpozLTUQn0l2qfJigjsmVvcwW in ygsQVv42iYDaWZ0FAI9xBLHpNehE86:
				XLVqPOIzGJl6KUyQ23d9 = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['name'].replace(zWyErX8YHiLsemj9G6lb2p1,'').replace(sfquhCGUwdvRl96izX,'')
				HrRJ8kXGvL5TWfZ21B6Mu9zsE = T072lCzjYiuaeFtmJGV.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
				if HrRJ8kXGvL5TWfZ21B6Mu9zsE:
					kk7tQHZxGD9fse8pymJU3lrCY2,BBfJPlu6O0oYveHdEgM3pX9ixZRS,OCU0RkWn7INDPd9zX1LcAyeq,ooKiPTblFuzOryQ6j4cfXgaWxw,XLVqPOIzGJl6KUyQ23d9 = HrRJ8kXGvL5TWfZ21B6Mu9zsE[0]
					HrRJ8kXGvL5TWfZ21B6Mu9zsE = kk7tQHZxGD9fse8pymJU3lrCY2+BBfJPlu6O0oYveHdEgM3pX9ixZRS+' '+OCU0RkWn7INDPd9zX1LcAyeq+ooKiPTblFuzOryQ6j4cfXgaWxw+' '
				else:
					HrRJ8kXGvL5TWfZ21B6Mu9zsE = T072lCzjYiuaeFtmJGV.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
					if HrRJ8kXGvL5TWfZ21B6Mu9zsE:
						XLVqPOIzGJl6KUyQ23d9,kk7tQHZxGD9fse8pymJU3lrCY2,OCU0RkWn7INDPd9zX1LcAyeq,BBfJPlu6O0oYveHdEgM3pX9ixZRS,ooKiPTblFuzOryQ6j4cfXgaWxw = HrRJ8kXGvL5TWfZ21B6Mu9zsE[0]
						HrRJ8kXGvL5TWfZ21B6Mu9zsE = kk7tQHZxGD9fse8pymJU3lrCY2+BBfJPlu6O0oYveHdEgM3pX9ixZRS+' '+OCU0RkWn7INDPd9zX1LcAyeq+ooKiPTblFuzOryQ6j4cfXgaWxw+' '
					else: HrRJ8kXGvL5TWfZ21B6Mu9zsE = ''
				yyubWejrMZsO = T072lCzjYiuaeFtmJGV.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
				if yyubWejrMZsO: yyubWejrMZsO,XLVqPOIzGJl6KUyQ23d9 = yyubWejrMZsO[0]
				else: yyubWejrMZsO = ''
				jjTGefitB6ISFl52vRCnY0b.append(HrRJ8kXGvL5TWfZ21B6Mu9zsE+yyubWejrMZsO)
				MbDGZqi1poU6tC0AILaBvP.append(XLVqPOIzGJl6KUyQ23d9)
			mt5K9DClMYgvRuaUzpPNEQcTXHwjZ = RYmMI90awrHb8x3nf5VSXjZpK6sBo2(MbDGZqi1poU6tC0AILaBvP)
			if mt5K9DClMYgvRuaUzpPNEQcTXHwjZ:
				for hU3gvdkbXl5HVAYecR6sJGyB in range(len(ygsQVv42iYDaWZ0FAI9xBLHpNehE86)):
					CGbDOtpozLTUQn0l2qfJigjsmVvcwW = ygsQVv42iYDaWZ0FAI9xBLHpNehE86[hU3gvdkbXl5HVAYecR6sJGyB]
					CGbDOtpozLTUQn0l2qfJigjsmVvcwW['name'] = jjTGefitB6ISFl52vRCnY0b[hU3gvdkbXl5HVAYecR6sJGyB]+mt5K9DClMYgvRuaUzpPNEQcTXHwjZ[hU3gvdkbXl5HVAYecR6sJGyB]
					xV4PLm8U5w0q3TeZ.append(CGbDOtpozLTUQn0l2qfJigjsmVvcwW)
	if xV4PLm8U5w0q3TeZ: ygsQVv42iYDaWZ0FAI9xBLHpNehE86 = xV4PLm8U5w0q3TeZ
	ecPiqhjKpf7gJR,a7SmkgYiAf,KdUFPa5JO1R = [],0,0
	rSIGZwYNmubQy3jidC4W = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(UIl7EzK48anPkH,EHnSrqQ7BvmGlOgYZdhTbCRtswA)
	try: aTAciICeN9FnLPWkoqxgtuswhBvDE1 = isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(rSIGZwYNmubQy3jidC4W)
	except:
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.makedirs(rSIGZwYNmubQy3jidC4W)
		except: pass
		aTAciICeN9FnLPWkoqxgtuswhBvDE1 = []
	upIhcSszjHiVrGeYd5D9 = ZxiGjvendb('menu_item')
	for CGbDOtpozLTUQn0l2qfJigjsmVvcwW in ygsQVv42iYDaWZ0FAI9xBLHpNehE86:
		XLVqPOIzGJl6KUyQ23d9 = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['name']
		JuqNQDaIOtl5HGTSjpdyCE9 = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['context_menu']
		G5QOep2rMhESFKZqPLA = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['plot']
		dkziDvOUELZBaAcFYr = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['stars']
		rHC4l56cOGQ9sX0Mj = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['image']
		ga4p3IxqUXMjTRPQZfH9J5E = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['type']
		o8oTABfnCwS6pvl3Ja = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['duration']
		jGxlsRhA1CpZoyLet9HK7EMX0YSWO = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['isFolder']
		kFXyMG8gqZz0BD5eP6 = CGbDOtpozLTUQn0l2qfJigjsmVvcwW['newpath']
		e1VyKQiuLpMOmaUsEnqAG6W = Ko1p5u9jwG6rF.ListItem(XLVqPOIzGJl6KUyQ23d9)
		e1VyKQiuLpMOmaUsEnqAG6W.addContextMenuItems(JuqNQDaIOtl5HGTSjpdyCE9)
		if rHC4l56cOGQ9sX0Mj: e1VyKQiuLpMOmaUsEnqAG6W.setArt({'icon':rHC4l56cOGQ9sX0Mj,'thumb':rHC4l56cOGQ9sX0Mj,'fanart':rHC4l56cOGQ9sX0Mj,'banner':rHC4l56cOGQ9sX0Mj,'clearart':rHC4l56cOGQ9sX0Mj,'poster':rHC4l56cOGQ9sX0Mj,'clearlogo':rHC4l56cOGQ9sX0Mj,'landscape':rHC4l56cOGQ9sX0Mj})
		else:
			XLVqPOIzGJl6KUyQ23d9 = CycHPIbdjsO7hKg93uaxTRvW4ti5X1(XLVqPOIzGJl6KUyQ23d9)
			XLVqPOIzGJl6KUyQ23d9 = U5HoT3c86ZkXu927(XLVqPOIzGJl6KUyQ23d9)
			ii6EM3JowDK8aA1N = XLVqPOIzGJl6KUyQ23d9+'.png'
			default = True
			if ii6EM3JowDK8aA1N in aTAciICeN9FnLPWkoqxgtuswhBvDE1:
				Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(rSIGZwYNmubQy3jidC4W,ii6EM3JowDK8aA1N)
				e1VyKQiuLpMOmaUsEnqAG6W.setArt({'icon':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'thumb':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'fanart':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'banner':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'clearart':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'poster':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'clearlogo':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'landscape':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y})
				default = False
			elif a7SmkgYiAf<60 and KdUFPa5JO1R<5:
				Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(rSIGZwYNmubQy3jidC4W,ii6EM3JowDK8aA1N)
				try:
					ONQra5zHWtLuCiBE9V = MyRaCbKjZSQ(upIhcSszjHiVrGeYd5D9,'','','','',XLVqPOIzGJl6KUyQ23d9,'menu_item','center',False,Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y)
					e1VyKQiuLpMOmaUsEnqAG6W.setArt({'icon':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'thumb':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'fanart':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'banner':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'clearart':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'poster':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'clearlogo':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y,'landscape':Boq8I9lQwfiHSWMARa0gCE2Jh1L5Y})
					a7SmkgYiAf += 1
					default = False
				except: KdUFPa5JO1R += 1
			if default: e1VyKQiuLpMOmaUsEnqAG6W.setArt({'icon':ETky3OeIGb,'thumb':aa2bIiRVDqjeyL9OPMUmc08n4Y6xz,'fanart':nGAmW9F4K1pEbi0YDOkHu3,'banner':tt4gFWD0Am5,'clearart':r5XEa9VW0tBe6HKM4UQqpIOklTPyC,'poster':Fwd9kuV5NLP2go,'clearlogo':yHDOwzZWqbtAR,'landscape':V8VcoHpu15anD9LmShwYZxTylM3})
		if XK3HqaTnjpyIAuhw67CmdvBM<20:
			if G5QOep2rMhESFKZqPLA: e1VyKQiuLpMOmaUsEnqAG6W.setInfo('video',{'Plot':G5QOep2rMhESFKZqPLA,'PlotOutline':G5QOep2rMhESFKZqPLA})
			if dkziDvOUELZBaAcFYr: e1VyKQiuLpMOmaUsEnqAG6W.setInfo('video',{'Rating':dkziDvOUELZBaAcFYr})
			if not rHC4l56cOGQ9sX0Mj:
				e1VyKQiuLpMOmaUsEnqAG6W.setInfo('video',{'Title':XLVqPOIzGJl6KUyQ23d9})
			if ga4p3IxqUXMjTRPQZfH9J5E=='video':
				e1VyKQiuLpMOmaUsEnqAG6W.setInfo('video',{'mediatype':'movie'})
				if o8oTABfnCwS6pvl3Ja: e1VyKQiuLpMOmaUsEnqAG6W.setInfo('video',{'duration':o8oTABfnCwS6pvl3Ja})
				e1VyKQiuLpMOmaUsEnqAG6W.setProperty('IsPlayable','true')
		else:
			RTfjpm9QKFkWEJyaA = e1VyKQiuLpMOmaUsEnqAG6W.getVideoInfoTag()
			if dkziDvOUELZBaAcFYr: RTfjpm9QKFkWEJyaA.setRating(float(dkziDvOUELZBaAcFYr))
			if not rHC4l56cOGQ9sX0Mj:
				RTfjpm9QKFkWEJyaA.setTitle(XLVqPOIzGJl6KUyQ23d9)
			if ga4p3IxqUXMjTRPQZfH9J5E=='video':
				RTfjpm9QKFkWEJyaA.setMediaType('tvshow')
				if o8oTABfnCwS6pvl3Ja: RTfjpm9QKFkWEJyaA.setDuration(o8oTABfnCwS6pvl3Ja)
				e1VyKQiuLpMOmaUsEnqAG6W.setProperty('IsPlayable','true')
		ecPiqhjKpf7gJR.append((kFXyMG8gqZz0BD5eP6,e1VyKQiuLpMOmaUsEnqAG6W,jGxlsRhA1CpZoyLet9HK7EMX0YSWO))
	I2XjYiNOlmyKG1EhR70q53vZ.setContent(SMfClzGKOB12H3r9sRPvAJgwq6,'tvshows')
	Zeit3fjUzgNhSrG1J8KM = I2XjYiNOlmyKG1EhR70q53vZ.addDirectoryItems(SMfClzGKOB12H3r9sRPvAJgwq6,ecPiqhjKpf7gJR)
	I2XjYiNOlmyKG1EhR70q53vZ.endOfDirectory(SMfClzGKOB12H3r9sRPvAJgwq6,JzGp5aDTFHMe1nNKZRAoLu7Q,pOtaQuNWnESlj1RK4w7TMsb,QGl5vbqZH1uAB0y)
	return Zeit3fjUzgNhSrG1J8KM
def QQmLIZC8uas9fNiJWOnhdGvgFR(ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj='',Fa9EIfiBzwm13QhVUr='',yv8XxUjorzB2CRA4Jife73VMklHp='',c60Epz1qjmHiKMl9BY='',fKFIOvsD0QVzUGLliAyw={}):
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('\r','').replace('\n','').replace('\t','')
	HHPwg71GEVju = HHPwg71GEVju.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in XLVqPOIzGJl6KUyQ23d9: eNv8QX5p0UAnMx6sdk,XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.split('_SCRIPT_',1)
	else: eNv8QX5p0UAnMx6sdk,XLVqPOIzGJl6KUyQ23d9 = '',XLVqPOIzGJl6KUyQ23d9
	if eNv8QX5p0UAnMx6sdk:
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = XLVqPOIzGJl6KUyQ23d9
		if not tG64YpcHCLaxEv7dFVuh3PQXlyTIN: tG64YpcHCLaxEv7dFVuh3PQXlyTIN = '....'
		elif tG64YpcHCLaxEv7dFVuh3PQXlyTIN.count('_')>1: tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.split('_',2)[2]
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace(' ','')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('|','').replace('~','')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('اون لاين','').replace('سيما لايت','')
		oaTebQrRmitqLBK = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(RKNzmZkCPHwM5pB7XF in tG64YpcHCLaxEv7dFVuh3PQXlyTIN for RKNzmZkCPHwM5pB7XF in oaTebQrRmitqLBK): tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('ال','')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		tG64YpcHCLaxEv7dFVuh3PQXlyTIN = tG64YpcHCLaxEv7dFVuh3PQXlyTIN.replace('  ',' ').strip(' ')
		eNv8QX5p0UAnMx6sdk = '_LST_'+hqWB0vmTcxR8d3oukL(eNv8QX5p0UAnMx6sdk)
		if tG64YpcHCLaxEv7dFVuh3PQXlyTIN not in list(JZ8q3iIuOMam6QyPK0k5.keys()): JZ8q3iIuOMam6QyPK0k5[tG64YpcHCLaxEv7dFVuh3PQXlyTIN] = {}
		JZ8q3iIuOMam6QyPK0k5[tG64YpcHCLaxEv7dFVuh3PQXlyTIN][eNv8QX5p0UAnMx6sdk] = [ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw]
	a26IqBkAXRPrwCOgFDb.append([ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw])
	return
def Nkuqp0boKj41i9(FFA9ZexvbmiXjBSy):
	if mmIKCGujwM: from html import unescape as _QYWf2U3qPLZ7bREt
	else:
		from HTMLParser import HTMLParser as usgb7nkSj4qrfEwHm81UOBCP29
		_QYWf2U3qPLZ7bREt = usgb7nkSj4qrfEwHm81UOBCP29().unescape
	if '&' in FFA9ZexvbmiXjBSy and ';' in FFA9ZexvbmiXjBSy:
		if ggl6zFuXNdYTDieHCqGKRnVx: FFA9ZexvbmiXjBSy = FFA9ZexvbmiXjBSy.decode('utf8')
		FFA9ZexvbmiXjBSy = _QYWf2U3qPLZ7bREt(FFA9ZexvbmiXjBSy)
		if ggl6zFuXNdYTDieHCqGKRnVx: FFA9ZexvbmiXjBSy = FFA9ZexvbmiXjBSy.encode('utf8')
	return FFA9ZexvbmiXjBSy
def Bd2o0J6aOASWvuD9HzY(FFA9ZexvbmiXjBSy):
	if '\\u' in FFA9ZexvbmiXjBSy:
		if ggl6zFuXNdYTDieHCqGKRnVx: FFA9ZexvbmiXjBSy = FFA9ZexvbmiXjBSy.decode('unicode_escape','ignore').encode('utf8')
		elif mmIKCGujwM: FFA9ZexvbmiXjBSy = FFA9ZexvbmiXjBSy.encode('utf8').decode('unicode_escape','ignore')
	return FFA9ZexvbmiXjBSy
def WmJZHlzfcbuqFd6(X4G7WhrkQtSuNFEyR,TSLtrgVKO2m8,JJfU9xiTzgCMNmhbdKajF,N5FeKnz8LHR4s7,yv8XxUjorzB2CRA4Jife73VMklHp,dt8PwsbrfkNB3xmR,BBwMH7ajz0Fx1fPNSiIrW6Q2,jhn3AgXmfCVWq6eTtkld,DD3sgriT7ZqVd):
	l0rAioyOMT8suxF4bkRnZLU = ZxiGjvendb(dt8PwsbrfkNB3xmR)
	ONQra5zHWtLuCiBE9V = MyRaCbKjZSQ(l0rAioyOMT8suxF4bkRnZLU,X4G7WhrkQtSuNFEyR,TSLtrgVKO2m8,JJfU9xiTzgCMNmhbdKajF,N5FeKnz8LHR4s7,yv8XxUjorzB2CRA4Jife73VMklHp,dt8PwsbrfkNB3xmR,BBwMH7ajz0Fx1fPNSiIrW6Q2,jhn3AgXmfCVWq6eTtkld,DD3sgriT7ZqVd)
	return ONQra5zHWtLuCiBE9V
def ZxiGjvendb(dt8PwsbrfkNB3xmR):
	Qs4qBYiKPSH9O = 5
	rgbIYJEn1id35UNT2Fsy9hPfDvqckG = 20
	ppoa5mTZfEBMKyXhlPsrIk734D = 20
	zMi2hevOywb0t6qKaJADldTHmfgIcL = 0
	aabc6fTIvXwpNG2COmWZVLhFe = 'center'
	ClT1vtyoG7UqB02JRwWPZInNH = 0
	td43rkhV7jJzSZYbBinXAIg = 19
	rrTu9FdvNimloDfKBgj0kH42cW8E = 30
	kZ5WIPhsoUMaA = 8
	idn3ro9zcCSKUGukT = True
	THrVp0Ee4j7yBAMn2xLWilqJ5 = 375
	HchMtNRq0v = 410
	llTbur8AkJCWhS10gpqPED3G2 = 50
	QQzXnRCqHSAOE58sJxt = 280
	H6HRQASfCwytbZciq0prlUux2hG = 28
	zcGOxqJ9I84osu = 5
	OrY3UWXMVND4 = 0
	abUdpQyfoIOvVtW1ChG0Dej9 = 31
	WcUsE2RNBgF1 = [36,32,28]
	if dt8PwsbrfkNB3xmR in ['notification','notification_twohalfs']:
		if dt8PwsbrfkNB3xmR=='notification_twohalfs':
			JntO0H8zcAImje,anvg32kX4FU = 'UPPER',720
			aabc6fTIvXwpNG2COmWZVLhFe = 'right'
			idn3ro9zcCSKUGukT = True
			zMi2hevOywb0t6qKaJADldTHmfgIcL = 10
		else:
			JntO0H8zcAImje,anvg32kX4FU = 97+20,720
			aabc6fTIvXwpNG2COmWZVLhFe = 'left'
			idn3ro9zcCSKUGukT = False
		WcUsE2RNBgF1 = [33,33,33]
		ppoa5mTZfEBMKyXhlPsrIk734D = 20
		rgbIYJEn1id35UNT2Fsy9hPfDvqckG = 0
		rrTu9FdvNimloDfKBgj0kH42cW8E = 20
		td43rkhV7jJzSZYbBinXAIg = 25+10
	elif dt8PwsbrfkNB3xmR=='menu_item':
		WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [48,44,40],200,400
		rrTu9FdvNimloDfKBgj0kH42cW8E,td43rkhV7jJzSZYbBinXAIg,rgbIYJEn1id35UNT2Fsy9hPfDvqckG = 0,0,-16
		KPrGAsC154wBQzxXJmIogyqdFjcvY = dxirsWfnmcZVC2vMPtTewlH3RQ.open(LdQHkenaBCP5)
		tVjvJCYabR1oWiZsFUHSBT5rQluw6 = dxirsWfnmcZVC2vMPtTewlH3RQ.new('RGBA',(200,200),(255,0,0,255))
	elif dt8PwsbrfkNB3xmR=='confirm_smallfont': WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [28,24,20],500,900
	elif dt8PwsbrfkNB3xmR=='confirm_mediumfont': WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [32,28,24],500,900
	elif dt8PwsbrfkNB3xmR=='confirm_bigfont': WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [36,32,28],500,900
	elif dt8PwsbrfkNB3xmR=='textview_bigfont': JntO0H8zcAImje,anvg32kX4FU = 740,1270
	elif dt8PwsbrfkNB3xmR=='textview_bigfont_long': JntO0H8zcAImje,anvg32kX4FU = 'UPPER',1270
	elif dt8PwsbrfkNB3xmR=='textview_smallfont': WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [28,23,18],740,1270
	elif dt8PwsbrfkNB3xmR=='textview_smallfont_long': WcUsE2RNBgF1,JntO0H8zcAImje,anvg32kX4FU = [28,23,18],'UPPER',1270
	WqVwv3NdpGJ = WcUsE2RNBgF1[0]
	dzZMa1VqsC = WcUsE2RNBgF1[1]
	jUC0R56PH2MIbEh9xBQWTvXLGKtcyg = WcUsE2RNBgF1[2]
	Wo24U0f716nXCStvL = zP8A0c3YCN7oq9ElMdevh.truetype(KKfeItdkzh7XV,size=WqVwv3NdpGJ)
	TocFODgqy1B = zP8A0c3YCN7oq9ElMdevh.truetype(KKfeItdkzh7XV,size=dzZMa1VqsC)
	PVlOmoir2Qz5U69wKIbF3pNGyvM = zP8A0c3YCN7oq9ElMdevh.truetype(KKfeItdkzh7XV,size=jUC0R56PH2MIbEh9xBQWTvXLGKtcyg)
	zvQRSOD3yHTpF0 = dxirsWfnmcZVC2vMPtTewlH3RQ.new('RGBA',(100,100),(255,255,255,0))
	c6cvJVF3HeRKwjq5M = AAUsBktvRdn.Draw(zvQRSOD3yHTpF0)
	Mas0PjOAmkb4HTU,v6lSuWtnVecr0 = c6cvJVF3HeRKwjq5M.textsize('HHH BBB 888 000',font=TocFODgqy1B)
	YPeOH59vd2i,RR4CtazVpcAKguNkWZIq6xlSfhLj2 = c6cvJVF3HeRKwjq5M.textsize('HHH BBB 888 000',font=Wo24U0f716nXCStvL)
	eeEQiZtAX3CH1VRKb658onl09ukpaD = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	lmdaLv78ribZy = pqeG1hsSZXD0lvT7P(configuration=eeEQiZtAX3CH1VRKb658onl09ukpaD)
	l0rAioyOMT8suxF4bkRnZLU = {}
	XRyN4nuqHDEkLGtJBQxjM6 = locals()
	for HHhysw8NOZj3 in XRyN4nuqHDEkLGtJBQxjM6: l0rAioyOMT8suxF4bkRnZLU[HHhysw8NOZj3] = XRyN4nuqHDEkLGtJBQxjM6[HHhysw8NOZj3]
	return l0rAioyOMT8suxF4bkRnZLU
def MyRaCbKjZSQ(l0rAioyOMT8suxF4bkRnZLU,X4G7WhrkQtSuNFEyR,TSLtrgVKO2m8,JJfU9xiTzgCMNmhbdKajF,N5FeKnz8LHR4s7,yv8XxUjorzB2CRA4Jife73VMklHp,dt8PwsbrfkNB3xmR,BBwMH7ajz0Fx1fPNSiIrW6Q2,jhn3AgXmfCVWq6eTtkld,DD3sgriT7ZqVd):
	for HHhysw8NOZj3 in l0rAioyOMT8suxF4bkRnZLU: globals()[HHhysw8NOZj3] = l0rAioyOMT8suxF4bkRnZLU[HHhysw8NOZj3]
	global H6HRQASfCwytbZciq0prlUux2hG,zcGOxqJ9I84osu
	aaBWub5jtJA0rR13zNnVhHgkXwL2qE = YTPut68WBVUNCvsEzg.getSetting('av.language.translate')
	if aaBWub5jtJA0rR13zNnVhHgkXwL2qE:
		if X4G7WhrkQtSuNFEyR=='نعم  Yes': X4G7WhrkQtSuNFEyR = 'Yes'
		elif X4G7WhrkQtSuNFEyR=='كلا  No': X4G7WhrkQtSuNFEyR = 'No'
		if TSLtrgVKO2m8=='نعم  Yes': TSLtrgVKO2m8 = 'Yes'
		elif TSLtrgVKO2m8=='كلا  No': TSLtrgVKO2m8 = 'No'
		if JJfU9xiTzgCMNmhbdKajF=='نعم  Yes': JJfU9xiTzgCMNmhbdKajF = 'Yes'
		elif JJfU9xiTzgCMNmhbdKajF=='كلا  No': JJfU9xiTzgCMNmhbdKajF = 'No'
		XVFsOLPmZiK0zN1bkr5 = RYmMI90awrHb8x3nf5VSXjZpK6sBo2([X4G7WhrkQtSuNFEyR,TSLtrgVKO2m8,JJfU9xiTzgCMNmhbdKajF,N5FeKnz8LHR4s7,yv8XxUjorzB2CRA4Jife73VMklHp])
		if XVFsOLPmZiK0zN1bkr5: X4G7WhrkQtSuNFEyR,TSLtrgVKO2m8,JJfU9xiTzgCMNmhbdKajF,N5FeKnz8LHR4s7,yv8XxUjorzB2CRA4Jife73VMklHp = XVFsOLPmZiK0zN1bkr5
	if ggl6zFuXNdYTDieHCqGKRnVx:
		yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.decode('utf8')
		N5FeKnz8LHR4s7 = N5FeKnz8LHR4s7.decode('utf8')
		X4G7WhrkQtSuNFEyR = X4G7WhrkQtSuNFEyR.decode('utf8')
		TSLtrgVKO2m8 = TSLtrgVKO2m8.decode('utf8')
		JJfU9xiTzgCMNmhbdKajF = JJfU9xiTzgCMNmhbdKajF.decode('utf8')
	PKLpOl6CNZvJgAwE10FoIGWt53sXRY = N5FeKnz8LHR4s7.count('\n')+1
	MMfPuACqFvpXiD9hEw8ZWtIJH = rgbIYJEn1id35UNT2Fsy9hPfDvqckG+PKLpOl6CNZvJgAwE10FoIGWt53sXRY*(RR4CtazVpcAKguNkWZIq6xlSfhLj2+zMi2hevOywb0t6qKaJADldTHmfgIcL)-zMi2hevOywb0t6qKaJADldTHmfgIcL
	if yv8XxUjorzB2CRA4Jife73VMklHp:
		owMv2YQbAxjCBczaWd1KkRUOLEhqu5 = anvg32kX4FU-rrTu9FdvNimloDfKBgj0kH42cW8E*2
		FhbGpvnTgOV = v6lSuWtnVecr0+kZ5WIPhsoUMaA
		OYkRlVXK4vADLpWzM = lmdaLv78ribZy.reshape(yv8XxUjorzB2CRA4Jife73VMklHp)
		if idn3ro9zcCSKUGukT:
			JCio1dpV9zWY4HEvPgqSNDa6L = jIeum6ZXW7zbxTFJn(OYkRlVXK4vADLpWzM,dzZMa1VqsC,owMv2YQbAxjCBczaWd1KkRUOLEhqu5,FhbGpvnTgOV)
			PoQ9pv6fE5V = mT5sQSXEA6yCUYBncW7vpJq(JCio1dpV9zWY4HEvPgqSNDa6L)
			YSvbnPKT2MailF = PoQ9pv6fE5V.count('\n')+1
			if YSvbnPKT2MailF<6:
				Dmc75kl1XN = owMv2YQbAxjCBczaWd1KkRUOLEhqu5
				JCio1dpV9zWY4HEvPgqSNDa6L = jIeum6ZXW7zbxTFJn(OYkRlVXK4vADLpWzM,dzZMa1VqsC,Dmc75kl1XN,FhbGpvnTgOV)
				PoQ9pv6fE5V = mT5sQSXEA6yCUYBncW7vpJq(JCio1dpV9zWY4HEvPgqSNDa6L)
				YSvbnPKT2MailF = PoQ9pv6fE5V.count('\n')+1
			Ywd4M1LmhzfiZV5DtIA7n89yq6 = td43rkhV7jJzSZYbBinXAIg+YSvbnPKT2MailF*FhbGpvnTgOV-kZ5WIPhsoUMaA
		else:
			Ywd4M1LmhzfiZV5DtIA7n89yq6 = td43rkhV7jJzSZYbBinXAIg+v6lSuWtnVecr0
			PoQ9pv6fE5V = OYkRlVXK4vADLpWzM.split('\n')[0]
			JCio1dpV9zWY4HEvPgqSNDa6L = OYkRlVXK4vADLpWzM.split('\n')[0]
	else: Ywd4M1LmhzfiZV5DtIA7n89yq6 = td43rkhV7jJzSZYbBinXAIg
	K3kDpwqJVNo495WrXYQAm = OrY3UWXMVND4+abUdpQyfoIOvVtW1ChG0Dej9
	if jhn3AgXmfCVWq6eTtkld:
		CEnAlgiOV8uWX2 = HchMtNRq0v-THrVp0Ee4j7yBAMn2xLWilqJ5
		K3kDpwqJVNo495WrXYQAm += CEnAlgiOV8uWX2
	else: CEnAlgiOV8uWX2 = 0
	if X4G7WhrkQtSuNFEyR or TSLtrgVKO2m8 or JJfU9xiTzgCMNmhbdKajF: K3kDpwqJVNo495WrXYQAm += llTbur8AkJCWhS10gpqPED3G2
	if JntO0H8zcAImje!='UPPER': ONQra5zHWtLuCiBE9V = JntO0H8zcAImje
	else: ONQra5zHWtLuCiBE9V = MMfPuACqFvpXiD9hEw8ZWtIJH+Ywd4M1LmhzfiZV5DtIA7n89yq6+K3kDpwqJVNo495WrXYQAm
	ffzlmWQ0BoEJTvpHCM4Y = ONQra5zHWtLuCiBE9V-MMfPuACqFvpXiD9hEw8ZWtIJH-K3kDpwqJVNo495WrXYQAm-td43rkhV7jJzSZYbBinXAIg
	zvQRSOD3yHTpF0 = dxirsWfnmcZVC2vMPtTewlH3RQ.new('RGBA',(anvg32kX4FU,ONQra5zHWtLuCiBE9V),(255,255,255,0))
	c6cvJVF3HeRKwjq5M = AAUsBktvRdn.Draw(zvQRSOD3yHTpF0)
	if not TSLtrgVKO2m8 and X4G7WhrkQtSuNFEyR and JJfU9xiTzgCMNmhbdKajF:
		H6HRQASfCwytbZciq0prlUux2hG += 105
		zcGOxqJ9I84osu -= 110
	if N5FeKnz8LHR4s7:
		vVEhYngiOJDGrPyI = rgbIYJEn1id35UNT2Fsy9hPfDvqckG
		N5FeKnz8LHR4s7 = xAK6z48JXSbmultUw2BY.get_display(lmdaLv78ribZy.reshape(N5FeKnz8LHR4s7))
		yoVRGZgKlA2 = N5FeKnz8LHR4s7.splitlines()
		for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
			if vWN8xonyO4BUsEpcYqaJSGt2PL3jMw:
				clhHqIpibzFRTQYdO0J17,xxMWnAlB9QYZw7qc = c6cvJVF3HeRKwjq5M.textsize(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,font=Wo24U0f716nXCStvL)
				if aabc6fTIvXwpNG2COmWZVLhFe=='center': FCGlqdP8NiW1 = Qs4qBYiKPSH9O+(anvg32kX4FU-clhHqIpibzFRTQYdO0J17)/2
				elif aabc6fTIvXwpNG2COmWZVLhFe=='right': FCGlqdP8NiW1 = Qs4qBYiKPSH9O+anvg32kX4FU-clhHqIpibzFRTQYdO0J17-ppoa5mTZfEBMKyXhlPsrIk734D
				elif aabc6fTIvXwpNG2COmWZVLhFe=='left': FCGlqdP8NiW1 = Qs4qBYiKPSH9O+ppoa5mTZfEBMKyXhlPsrIk734D
				c6cvJVF3HeRKwjq5M.text((FCGlqdP8NiW1,vVEhYngiOJDGrPyI),vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,font=Wo24U0f716nXCStvL,fill='yellow')
			vVEhYngiOJDGrPyI += WqVwv3NdpGJ+zMi2hevOywb0t6qKaJADldTHmfgIcL
	if X4G7WhrkQtSuNFEyR or TSLtrgVKO2m8 or JJfU9xiTzgCMNmhbdKajF:
		aaTdrnk5sEyvNx6 = MMfPuACqFvpXiD9hEw8ZWtIJH+ffzlmWQ0BoEJTvpHCM4Y+td43rkhV7jJzSZYbBinXAIg+CEnAlgiOV8uWX2+OrY3UWXMVND4
		if X4G7WhrkQtSuNFEyR:
			X4G7WhrkQtSuNFEyR = xAK6z48JXSbmultUw2BY.get_display(lmdaLv78ribZy.reshape(X4G7WhrkQtSuNFEyR))
			TrKL6kAlEQysNFIonvic9bh2wRt,C3CPVtiLsfhI6XjGAmM9zgHBwJ = c6cvJVF3HeRKwjq5M.textsize(X4G7WhrkQtSuNFEyR,font=PVlOmoir2Qz5U69wKIbF3pNGyvM)
			SGE3dtl6u8b0UJ4rz1LXZRBMsOyTHw = H6HRQASfCwytbZciq0prlUux2hG+0*(zcGOxqJ9I84osu+QQzXnRCqHSAOE58sJxt)+(QQzXnRCqHSAOE58sJxt-TrKL6kAlEQysNFIonvic9bh2wRt)/2
			c6cvJVF3HeRKwjq5M.text((SGE3dtl6u8b0UJ4rz1LXZRBMsOyTHw,aaTdrnk5sEyvNx6),X4G7WhrkQtSuNFEyR,font=PVlOmoir2Qz5U69wKIbF3pNGyvM,fill='yellow')
		if TSLtrgVKO2m8:
			TSLtrgVKO2m8 = xAK6z48JXSbmultUw2BY.get_display(lmdaLv78ribZy.reshape(TSLtrgVKO2m8))
			X87xAYlSFq,tAVwnoRCM4xhicry5qNeBvE = c6cvJVF3HeRKwjq5M.textsize(TSLtrgVKO2m8,font=PVlOmoir2Qz5U69wKIbF3pNGyvM)
			oneGCR8OfwjhtQx4ic1q2aL = H6HRQASfCwytbZciq0prlUux2hG+1*(zcGOxqJ9I84osu+QQzXnRCqHSAOE58sJxt)+(QQzXnRCqHSAOE58sJxt-X87xAYlSFq)/2
			c6cvJVF3HeRKwjq5M.text((oneGCR8OfwjhtQx4ic1q2aL,aaTdrnk5sEyvNx6),TSLtrgVKO2m8,font=PVlOmoir2Qz5U69wKIbF3pNGyvM,fill='yellow')
		if JJfU9xiTzgCMNmhbdKajF:
			JJfU9xiTzgCMNmhbdKajF = xAK6z48JXSbmultUw2BY.get_display(lmdaLv78ribZy.reshape(JJfU9xiTzgCMNmhbdKajF))
			kMJv5eUt6YmjpbldBQPKhfZxgn18,tgCU97Vqjxm3f = c6cvJVF3HeRKwjq5M.textsize(JJfU9xiTzgCMNmhbdKajF,font=PVlOmoir2Qz5U69wKIbF3pNGyvM)
			wHWgYzZJdrR6NbS23mfi = H6HRQASfCwytbZciq0prlUux2hG+2*(zcGOxqJ9I84osu+QQzXnRCqHSAOE58sJxt)+(QQzXnRCqHSAOE58sJxt-kMJv5eUt6YmjpbldBQPKhfZxgn18)/2
			c6cvJVF3HeRKwjq5M.text((wHWgYzZJdrR6NbS23mfi,aaTdrnk5sEyvNx6),JJfU9xiTzgCMNmhbdKajF,font=PVlOmoir2Qz5U69wKIbF3pNGyvM,fill='yellow')
	if yv8XxUjorzB2CRA4Jife73VMklHp:
		OdhnyGfp6qTtrXZUsNC,O2oL7k6w3mCj8xcvYyGPrJ = [],[]
		JCio1dpV9zWY4HEvPgqSNDa6L = ttvc7TuXzCLYPW89bxrdRs0(JCio1dpV9zWY4HEvPgqSNDa6L)
		elp3QiRo6FztVLNUAuWB92KmkY = JCio1dpV9zWY4HEvPgqSNDa6L.split('_sss__newline_')
		for V6DX1du2eN4gEOZMxYmPoHvAliKnw in elp3QiRo6FztVLNUAuWB92KmkY:
			ggWholU1ux7GIVqEn5fm2 = BBwMH7ajz0Fx1fPNSiIrW6Q2
			if   '_sss__lineleft_' in V6DX1du2eN4gEOZMxYmPoHvAliKnw: ggWholU1ux7GIVqEn5fm2 = 'left'
			elif '_sss__lineright_' in V6DX1du2eN4gEOZMxYmPoHvAliKnw: ggWholU1ux7GIVqEn5fm2 = 'right'
			elif '_sss__linecenter_' in V6DX1du2eN4gEOZMxYmPoHvAliKnw: ggWholU1ux7GIVqEn5fm2 = 'center'
			BGiqA3kg5XvscDwFUexP = V6DX1du2eN4gEOZMxYmPoHvAliKnw
			Bv16i5eZcJTyl89NnVOCRDA0 = T072lCzjYiuaeFtmJGV.findall('_sss__.*?_',V6DX1du2eN4gEOZMxYmPoHvAliKnw,T072lCzjYiuaeFtmJGV.DOTALL)
			for zrotuLsDyOP0T in Bv16i5eZcJTyl89NnVOCRDA0: BGiqA3kg5XvscDwFUexP = BGiqA3kg5XvscDwFUexP.replace(zrotuLsDyOP0T,'')
			if BGiqA3kg5XvscDwFUexP=='': clhHqIpibzFRTQYdO0J17,xxMWnAlB9QYZw7qc = 0,FhbGpvnTgOV
			else: clhHqIpibzFRTQYdO0J17,xxMWnAlB9QYZw7qc = c6cvJVF3HeRKwjq5M.textsize(BGiqA3kg5XvscDwFUexP,font=TocFODgqy1B)
			if   ggWholU1ux7GIVqEn5fm2=='left': yzcnA6iwIJkBOtLWX4dNrgM = ClT1vtyoG7UqB02JRwWPZInNH+rrTu9FdvNimloDfKBgj0kH42cW8E
			elif ggWholU1ux7GIVqEn5fm2=='right': yzcnA6iwIJkBOtLWX4dNrgM = ClT1vtyoG7UqB02JRwWPZInNH+rrTu9FdvNimloDfKBgj0kH42cW8E+owMv2YQbAxjCBczaWd1KkRUOLEhqu5-clhHqIpibzFRTQYdO0J17
			elif ggWholU1ux7GIVqEn5fm2=='center': yzcnA6iwIJkBOtLWX4dNrgM = ClT1vtyoG7UqB02JRwWPZInNH+rrTu9FdvNimloDfKBgj0kH42cW8E+(owMv2YQbAxjCBczaWd1KkRUOLEhqu5-clhHqIpibzFRTQYdO0J17)/2
			if yzcnA6iwIJkBOtLWX4dNrgM<rrTu9FdvNimloDfKBgj0kH42cW8E: yzcnA6iwIJkBOtLWX4dNrgM = ClT1vtyoG7UqB02JRwWPZInNH+rrTu9FdvNimloDfKBgj0kH42cW8E
			OdhnyGfp6qTtrXZUsNC.append(yzcnA6iwIJkBOtLWX4dNrgM)
			O2oL7k6w3mCj8xcvYyGPrJ.append(clhHqIpibzFRTQYdO0J17)
		yzcnA6iwIJkBOtLWX4dNrgM = OdhnyGfp6qTtrXZUsNC[0]
		KK45Jo2Z9BLRC0MjXQPkz8 = JCio1dpV9zWY4HEvPgqSNDa6L.split('_sss_')
		WWsunyXaMfT04IoiK5DwSLV = (255,255,255,255)
		yGDURLQFmxv3CK = WWsunyXaMfT04IoiK5DwSLV
		tpLXsAqhFBQzMTgYNUal0,hhlYtfNZmHeb1ydCKJnjrsTgv6p = 0,0
		dNYatSBqQ1e3gvGh = False
		ztgbRwvno0MCdulima2JPqQsx = 0
		yp4JRP2wO6Meb7 = MMfPuACqFvpXiD9hEw8ZWtIJH+td43rkhV7jJzSZYbBinXAIg/2
		if Ywd4M1LmhzfiZV5DtIA7n89yq6<(ffzlmWQ0BoEJTvpHCM4Y+td43rkhV7jJzSZYbBinXAIg):
			DK9hnVaCOy6f4ZWS = (ffzlmWQ0BoEJTvpHCM4Y+td43rkhV7jJzSZYbBinXAIg-Ywd4M1LmhzfiZV5DtIA7n89yq6)/2
			yp4JRP2wO6Meb7 = MMfPuACqFvpXiD9hEw8ZWtIJH+td43rkhV7jJzSZYbBinXAIg+DK9hnVaCOy6f4ZWS-v6lSuWtnVecr0/2
		for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in KK45Jo2Z9BLRC0MjXQPkz8:
			if not vWN8xonyO4BUsEpcYqaJSGt2PL3jMw or (vWN8xonyO4BUsEpcYqaJSGt2PL3jMw and ord(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw[0])==65279): continue
			GDu3UtZ82Tr1iIlNCbhEfM = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_newline_',1)
			BnETpf1iPX2wbvu0j8Gs3QA = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_newcolor',1)
			eHkoIYTvfm64bhNt = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_endcolor_',1)
			fsx6GmWhABUp4Kvi5QPoaRuSFeLzO = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_linertl_',1)
			BbWQhjfoKu9nPwGyUlRaYr41 = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_lineleft_',1)
			SWR8MjLoHcJm0 = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_lineright_',1)
			P9qoabY5wQ3dTkvch0Bi = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.split('_linecenter_',1)
			if len(GDu3UtZ82Tr1iIlNCbhEfM)>1:
				ztgbRwvno0MCdulima2JPqQsx += 1
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = GDu3UtZ82Tr1iIlNCbhEfM[1]
				tpLXsAqhFBQzMTgYNUal0 = 0
				yzcnA6iwIJkBOtLWX4dNrgM = OdhnyGfp6qTtrXZUsNC[ztgbRwvno0MCdulima2JPqQsx]
				hhlYtfNZmHeb1ydCKJnjrsTgv6p += FhbGpvnTgOV
				dNYatSBqQ1e3gvGh = False
			elif len(BnETpf1iPX2wbvu0j8Gs3QA)>1:
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = BnETpf1iPX2wbvu0j8Gs3QA[1]
				yGDURLQFmxv3CK = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw[0:8]
				yGDURLQFmxv3CK = '#'+yGDURLQFmxv3CK[2:]
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw[9:]
			elif len(eHkoIYTvfm64bhNt)>1:
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = eHkoIYTvfm64bhNt[1]
				yGDURLQFmxv3CK = WWsunyXaMfT04IoiK5DwSLV
			elif len(fsx6GmWhABUp4Kvi5QPoaRuSFeLzO)>1:
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = fsx6GmWhABUp4Kvi5QPoaRuSFeLzO[1]
				dNYatSBqQ1e3gvGh = True
				tpLXsAqhFBQzMTgYNUal0 = O2oL7k6w3mCj8xcvYyGPrJ[ztgbRwvno0MCdulima2JPqQsx]
			elif len(BbWQhjfoKu9nPwGyUlRaYr41)>1: vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = BbWQhjfoKu9nPwGyUlRaYr41[1]
			elif len(SWR8MjLoHcJm0)>1: vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = SWR8MjLoHcJm0[1]
			elif len(P9qoabY5wQ3dTkvch0Bi)>1: vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = P9qoabY5wQ3dTkvch0Bi[1]
			if vWN8xonyO4BUsEpcYqaJSGt2PL3jMw:
				I5GRQ2EcXtwvsF = yp4JRP2wO6Meb7+hhlYtfNZmHeb1ydCKJnjrsTgv6p
				vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = xAK6z48JXSbmultUw2BY.get_display(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw)
				clhHqIpibzFRTQYdO0J17,xxMWnAlB9QYZw7qc = c6cvJVF3HeRKwjq5M.textsize(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,font=TocFODgqy1B)
				if dNYatSBqQ1e3gvGh: tpLXsAqhFBQzMTgYNUal0 -= clhHqIpibzFRTQYdO0J17
				ZFCywaK0zeiWuUDbcGSjhfIRHE = yzcnA6iwIJkBOtLWX4dNrgM+tpLXsAqhFBQzMTgYNUal0
				c6cvJVF3HeRKwjq5M.text((ZFCywaK0zeiWuUDbcGSjhfIRHE,I5GRQ2EcXtwvsF),vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,font=TocFODgqy1B,fill=yGDURLQFmxv3CK)
				if dt8PwsbrfkNB3xmR=='menu_item':
					c6cvJVF3HeRKwjq5M.text((ZFCywaK0zeiWuUDbcGSjhfIRHE+1,I5GRQ2EcXtwvsF+1),vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,font=TocFODgqy1B,fill=yGDURLQFmxv3CK)
				if not dNYatSBqQ1e3gvGh: tpLXsAqhFBQzMTgYNUal0 += clhHqIpibzFRTQYdO0J17
				if I5GRQ2EcXtwvsF>ffzlmWQ0BoEJTvpHCM4Y+FhbGpvnTgOV: break
	if dt8PwsbrfkNB3xmR=='menu_item':
		zvQRSOD3yHTpF0 = zvQRSOD3yHTpF0.resize((200,200))
		JJWLZkI31Ud7T8CbYamOvAKMrztsg = KPrGAsC154wBQzxXJmIogyqdFjcvY.copy()
		JJWLZkI31Ud7T8CbYamOvAKMrztsg.paste(tVjvJCYabR1oWiZsFUHSBT5rQluw6,(0,0),mask=zvQRSOD3yHTpF0)
	else: JJWLZkI31Ud7T8CbYamOvAKMrztsg = zvQRSOD3yHTpF0
	if ggl6zFuXNdYTDieHCqGKRnVx: DD3sgriT7ZqVd = DD3sgriT7ZqVd.decode('utf8')
	try: JJWLZkI31Ud7T8CbYamOvAKMrztsg.save(DD3sgriT7ZqVd)
	except:
		GdXtyNvqfoKVxjcHpkE4 = isWjwHOERYXhAp0ZuNdKUgkCM7.path.dirname(DD3sgriT7ZqVd)
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.makedirs(GdXtyNvqfoKVxjcHpkE4)
		except: pass
		JJWLZkI31Ud7T8CbYamOvAKMrztsg.save(DD3sgriT7ZqVd)
	return ONQra5zHWtLuCiBE9V
def jIeum6ZXW7zbxTFJn(MAthyLIdVrPbvSu7qx,pY4uHNW9jldLBkQ0VPtOgXz3ZeS2f,q3pzcy7MtLvdbISWOBwFiCmjK0,NFmK1TOHSo6t78MaLqrzCPk25):
	jlvD6K1Zkw2E9bMLf,pJTil7M1vezn,BxqZ8bsgRmDeHuG79l = '',0,15000
	MAthyLIdVrPbvSu7qx = MAthyLIdVrPbvSu7qx.replace('[COLOR ','[COLOR:::')
	MRgCdzxOUHaKBXo4nGQI9r8 = zP8A0c3YCN7oq9ElMdevh.truetype(KKfeItdkzh7XV,size=pY4uHNW9jldLBkQ0VPtOgXz3ZeS2f)
	q3pzcy7MtLvdbISWOBwFiCmjK0 -= pY4uHNW9jldLBkQ0VPtOgXz3ZeS2f*2
	zvQRSOD3yHTpF0 = dxirsWfnmcZVC2vMPtTewlH3RQ.new('RGBA',(q3pzcy7MtLvdbISWOBwFiCmjK0,99),(255,255,255,0))
	c6cvJVF3HeRKwjq5M = AAUsBktvRdn.Draw(zvQRSOD3yHTpF0)
	for Ay7tg2Bl5K in MAthyLIdVrPbvSu7qx.splitlines():
		pJTil7M1vezn += NFmK1TOHSo6t78MaLqrzCPk25
		uNxtr4Hy5niEKV67mYqWf,xyAtuid06NJ1TpDUhGYVn2 = 0,''
		for ntDYuUdCW69Av24KpiTNMgZk in Ay7tg2Bl5K.split(' '):
			IbFxzpnwfvX7PTrk = mT5sQSXEA6yCUYBncW7vpJq(' '+ntDYuUdCW69Av24KpiTNMgZk)
			vO5ZRiJ48Lcz9BUoIwS3,WD9lHXYZ1z = c6cvJVF3HeRKwjq5M.textsize(IbFxzpnwfvX7PTrk,font=MRgCdzxOUHaKBXo4nGQI9r8)
			if uNxtr4Hy5niEKV67mYqWf+vO5ZRiJ48Lcz9BUoIwS3<q3pzcy7MtLvdbISWOBwFiCmjK0:
				if not xyAtuid06NJ1TpDUhGYVn2: xyAtuid06NJ1TpDUhGYVn2 += ntDYuUdCW69Av24KpiTNMgZk
				else: xyAtuid06NJ1TpDUhGYVn2 += ' '+ntDYuUdCW69Av24KpiTNMgZk
				uNxtr4Hy5niEKV67mYqWf += vO5ZRiJ48Lcz9BUoIwS3
			else:
				if vO5ZRiJ48Lcz9BUoIwS3<q3pzcy7MtLvdbISWOBwFiCmjK0:
					xyAtuid06NJ1TpDUhGYVn2 += '\n '+ntDYuUdCW69Av24KpiTNMgZk
					pJTil7M1vezn += NFmK1TOHSo6t78MaLqrzCPk25
					uNxtr4Hy5niEKV67mYqWf = vO5ZRiJ48Lcz9BUoIwS3
				else:
					while vO5ZRiJ48Lcz9BUoIwS3>q3pzcy7MtLvdbISWOBwFiCmjK0:
						for hU3gvdkbXl5HVAYecR6sJGyB in range(1,len(' '+ntDYuUdCW69Av24KpiTNMgZk),1):
							zA1SjTcVEBJh57iKNeFf6sygO = ' '+ntDYuUdCW69Av24KpiTNMgZk[:hU3gvdkbXl5HVAYecR6sJGyB]
							gTPWKX8u3o1MfFGJ = ntDYuUdCW69Av24KpiTNMgZk[hU3gvdkbXl5HVAYecR6sJGyB:]
							m9rRTDaWhtNX2fsEYA68zd = mT5sQSXEA6yCUYBncW7vpJq(zA1SjTcVEBJh57iKNeFf6sygO)
							RJT9Di0Qts8xyhLSmrXpCzUaYdOo5V,DBIJQwSLYiAyelmrq4UOM = c6cvJVF3HeRKwjq5M.textsize(m9rRTDaWhtNX2fsEYA68zd,font=MRgCdzxOUHaKBXo4nGQI9r8)
							if uNxtr4Hy5niEKV67mYqWf+RJT9Di0Qts8xyhLSmrXpCzUaYdOo5V>q3pzcy7MtLvdbISWOBwFiCmjK0:
								yM9i3YC0Oxhlv4uJF = vO5ZRiJ48Lcz9BUoIwS3-RJT9Di0Qts8xyhLSmrXpCzUaYdOo5V
								xyAtuid06NJ1TpDUhGYVn2 += zA1SjTcVEBJh57iKNeFf6sygO+'\n'
								pJTil7M1vezn += NFmK1TOHSo6t78MaLqrzCPk25
								vO5ZRiJ48Lcz9BUoIwS3 = yM9i3YC0Oxhlv4uJF
								if yM9i3YC0Oxhlv4uJF>q3pzcy7MtLvdbISWOBwFiCmjK0:
									uNxtr4Hy5niEKV67mYqWf = 0
									ntDYuUdCW69Av24KpiTNMgZk = gTPWKX8u3o1MfFGJ
								else:
									uNxtr4Hy5niEKV67mYqWf = yM9i3YC0Oxhlv4uJF
									xyAtuid06NJ1TpDUhGYVn2 += gTPWKX8u3o1MfFGJ
								break
				if pJTil7M1vezn>BxqZ8bsgRmDeHuG79l: break
		jlvD6K1Zkw2E9bMLf += '\n'+xyAtuid06NJ1TpDUhGYVn2
		if pJTil7M1vezn>BxqZ8bsgRmDeHuG79l: break
	jlvD6K1Zkw2E9bMLf = jlvD6K1Zkw2E9bMLf[1:]
	jlvD6K1Zkw2E9bMLf = jlvD6K1Zkw2E9bMLf.replace('[COLOR:::','[COLOR ')
	return jlvD6K1Zkw2E9bMLf
def mT5sQSXEA6yCUYBncW7vpJq(ntDYuUdCW69Av24KpiTNMgZk):
	if '[' in ntDYuUdCW69Av24KpiTNMgZk and ']' in ntDYuUdCW69Av24KpiTNMgZk:
		Bv16i5eZcJTyl89NnVOCRDA0 = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		JarqDt0pfvTHkWLGnmudMVZbCSAR = T072lCzjYiuaeFtmJGV.findall('\[COLOR .*?\]',ntDYuUdCW69Av24KpiTNMgZk,T072lCzjYiuaeFtmJGV.DOTALL)
		fuo43DpgiN2OeRBHAZ8m6tXxFqT = T072lCzjYiuaeFtmJGV.findall('\[COLOR:::.*?\]',ntDYuUdCW69Av24KpiTNMgZk,T072lCzjYiuaeFtmJGV.DOTALL)
		LxZ3FOD8NQC = Bv16i5eZcJTyl89NnVOCRDA0+JarqDt0pfvTHkWLGnmudMVZbCSAR+fuo43DpgiN2OeRBHAZ8m6tXxFqT
		for zrotuLsDyOP0T in LxZ3FOD8NQC: ntDYuUdCW69Av24KpiTNMgZk = ntDYuUdCW69Av24KpiTNMgZk.replace(zrotuLsDyOP0T,'')
	return ntDYuUdCW69Av24KpiTNMgZk
def ttvc7TuXzCLYPW89bxrdRs0(yv8XxUjorzB2CRA4Jife73VMklHp):
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('\n','_sss__newline_')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RTL]','_sss__linertl_')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[LEFT]','_sss__lineleft_')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[RIGHT]','_sss__lineright_')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[CENTER]','_sss__linecenter_')
	yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[/COLOR]','_sss__endcolor_')
	oAqT6xIsLkVFUWe09XtBym = T072lCzjYiuaeFtmJGV.findall('\[COLOR (.*?)\]',yv8XxUjorzB2CRA4Jife73VMklHp,T072lCzjYiuaeFtmJGV.DOTALL)
	for huDzVRIdNfqUsK in oAqT6xIsLkVFUWe09XtBym: yv8XxUjorzB2CRA4Jife73VMklHp = yv8XxUjorzB2CRA4Jife73VMklHp.replace('[COLOR '+huDzVRIdNfqUsK+']','_sss__newcolor'+huDzVRIdNfqUsK+'_')
	return yv8XxUjorzB2CRA4Jife73VMklHp
def CycHPIbdjsO7hKg93uaxTRvW4ti5X1(XLVqPOIzGJl6KUyQ23d9=''):
	if not XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Label')
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('[/COLOR]','')
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	Q1q9Gy6ktgjaxvY3C7ip = T072lCzjYiuaeFtmJGV.findall('\d\d:\d\d ',XLVqPOIzGJl6KUyQ23d9,T072lCzjYiuaeFtmJGV.DOTALL)
	if Q1q9Gy6ktgjaxvY3C7ip: XLVqPOIzGJl6KUyQ23d9 = XLVqPOIzGJl6KUyQ23d9.split(Q1q9Gy6ktgjaxvY3C7ip[0],1)[1]
	if not XLVqPOIzGJl6KUyQ23d9: XLVqPOIzGJl6KUyQ23d9 = 'Main Menu'
	return XLVqPOIzGJl6KUyQ23d9
def U5HoT3c86ZkXu927(CG0rXeItomMwO3vjcFslKSYT):
	se189q0TSF45dh7XmMiKUzlnjyHvG = ''.join(hU3gvdkbXl5HVAYecR6sJGyB for hU3gvdkbXl5HVAYecR6sJGyB in CG0rXeItomMwO3vjcFslKSYT if hU3gvdkbXl5HVAYecR6sJGyB not in '\/":*?<>|'+ZhR6zf92IPocOL0sC)
	return se189q0TSF45dh7XmMiKUzlnjyHvG
def BJxFdCcqYyK96TS50MP3jav(Laf5bWDqkhyv0Er3gV1lw9josGQ):
	Fa9EIfiBzwm13QhVUr = Laf5bWDqkhyv0Er3gV1lw9josGQ
	if 'adilbo_HTML_encoder' in Laf5bWDqkhyv0Er3gV1lw9josGQ:
		VAuZKEfOzesFb8ImcjUJ1vB = T072lCzjYiuaeFtmJGV.findall('<script.*?;.*?\'(.*?);', Laf5bWDqkhyv0Er3gV1lw9josGQ, T072lCzjYiuaeFtmJGV.S)
		JwSpeN6O3dQ1hlxyGiF2PRVB5E = T072lCzjYiuaeFtmJGV.findall('/g.....(.*?)\)', Laf5bWDqkhyv0Er3gV1lw9josGQ, T072lCzjYiuaeFtmJGV.S)
		if VAuZKEfOzesFb8ImcjUJ1vB and JwSpeN6O3dQ1hlxyGiF2PRVB5E:
			NNziIqGUHkmw = VAuZKEfOzesFb8ImcjUJ1vB[0].replace("'",'')
			NNziIqGUHkmw = NNziIqGUHkmw.replace("+",'')
			NNziIqGUHkmw = NNziIqGUHkmw.replace("\n",'')
			OcjLUECJfIkNRD5t6zi = NNziIqGUHkmw.split('.')
			Fa9EIfiBzwm13QhVUr = ''
			for rQkiH354zGh0qSV9sCPBxYbvuNap in OcjLUECJfIkNRD5t6zi:
				HQzbZ7KyT40pJD2MBChkuXfVe = eJ4h7nOpguFMH6z1IUEV2i.b64decode(rQkiH354zGh0qSV9sCPBxYbvuNap+'==').decode('utf8')
				H84SoN1zikfByax7KFLQEI = T072lCzjYiuaeFtmJGV.findall('\d+', HQzbZ7KyT40pJD2MBChkuXfVe, T072lCzjYiuaeFtmJGV.S)
				if H84SoN1zikfByax7KFLQEI:
					GBodO9VirWNxn6j1FQ5fu4l2PZHTX = int(H84SoN1zikfByax7KFLQEI[0])+int(JwSpeN6O3dQ1hlxyGiF2PRVB5E[0])
					Fa9EIfiBzwm13QhVUr = Fa9EIfiBzwm13QhVUr + chr(GBodO9VirWNxn6j1FQ5fu4l2PZHTX)
			if mmIKCGujwM: Fa9EIfiBzwm13QhVUr = Fa9EIfiBzwm13QhVUr.encode('iso-8859-1').decode('utf8')
	return Fa9EIfiBzwm13QhVUr
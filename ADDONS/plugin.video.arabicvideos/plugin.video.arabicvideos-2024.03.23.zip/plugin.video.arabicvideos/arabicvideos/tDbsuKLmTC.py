# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
import bs4 as b6HI1EL95gSlVF
nO6ukabcldeU = 'ELCINEMA'
JJCLnkX4TozH7Bsjivfe = '_ELC_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
headers = {'Referer':HbiLZQKalC}
OZYvGX7EMx05KH1fI = []
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==510: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==511: cLCisPE3lX = Xf4wTyQKshuGzdxCZn219HcWAFrJ(url)
	elif mode==512: cLCisPE3lX = C3uTzABW1pQs8DvEZfYlGLaXn0jod(url)
	elif mode==513: cLCisPE3lX = gLnZAzIF8E9UKYsPtcCMQdk(url)
	elif mode==514: cLCisPE3lX = ShzHKIXUFlj9GwMYm(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: cLCisPE3lX = ShzHKIXUFlj9GwMYm(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: cLCisPE3lX = oCxG0fRjO6KuV(text)
	elif mode==517: cLCisPE3lX = gg6LZBnNMoeCw(url)
	elif mode==518: cLCisPE3lX = wKmTZfvYXSzgRQoh9rndt0(url)
	elif mode==519: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	elif mode==520: cLCisPE3lX = JLxBibOcZduNCfzvtjIF(url)
	elif mode==521: cLCisPE3lX = XOlERqYJci3DjzukSVF5WveH(url)
	elif mode==522: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==523: cLCisPE3lX = kJcx8qF9bEzU3psIP4D(text)
	elif mode==524: cLCisPE3lX = BwXphMQO2ZlJGxC()
	elif mode==525: cLCisPE3lX = gihZnCraVcRbYFHzDq7fXBvlp2E0()
	elif mode==526: cLCisPE3lX = wfVnk1UBAi6vP9btxDyl4()
	elif mode==527: cLCisPE3lX = Bh3nsbOTrxyNE5HwMzvWZSl94XYQL()
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث بموسوعة السينما','',519)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'موسوعة الأعمال','',525)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'موسوعة الأشخاص','',526)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'موسوعة المصنفات','',527)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'موسوعة المنوعات','',524)
	return
def BwXphMQO2ZlJGxC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' فيديوهات - خاصة',HbiLZQKalC+'/video',520)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فيديوهات - أحدث',HbiLZQKalC+'/video/latest',521)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فيديوهات - أقدم',HbiLZQKalC+'/video/oldest',521)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فيديوهات - أكثر مشاهدة',HbiLZQKalC+'/video/views',521)
	return
def gihZnCraVcRbYFHzDq7fXBvlp2E0():
	WWhNbJZ6LPM9aSecK = HbiLZQKalC+'/lineup?utf8=%E2%9C%93'
	CBd5iSMIU82xaF1tl = WWhNbJZ6LPM9aSecK+'&type=2&category=1&foreign=false&tag='
	zisyZ2wSNdoVm6rRDUlQIu = WWhNbJZ6LPM9aSecK+'&type=2&category=3&foreign=false&tag='
	zzHBWeQCTY68OvGuVd0pS1ws9RiNc = WWhNbJZ6LPM9aSecK+'&type=2&category=1&foreign=true&tag='
	LPuNT2RnXZY8vsMUjg1kJ65oS3Qc4 = WWhNbJZ6LPM9aSecK+'&type=2&category=3&foreign=true&tag='
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات أفلام عربي',CBd5iSMIU82xaF1tl,511)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات مسلسلات عربي',zisyZ2wSNdoVm6rRDUlQIu,511)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات أفلام اجنبي',zzHBWeQCTY68OvGuVd0pS1ws9RiNc,511)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات مسلسلات اجنبي',LPuNT2RnXZY8vsMUjg1kJ65oS3Qc4,511)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس أعمال أبجدي',HbiLZQKalC+'/index/work/alphabet',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس  بلد الإنتاج',HbiLZQKalC+'/index/work/country',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس اللغة',HbiLZQKalC+'/index/work/language',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس مصنفات العمل',HbiLZQKalC+'/index/work/genre',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس سنة الإصدار',HbiLZQKalC+'/index/work/release_year',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مواسم - فلتر محدد',HbiLZQKalC+'/seasonals',515)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مواسم - فلتر كامل',HbiLZQKalC+'/seasonals',514)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات - فلتر محدد',HbiLZQKalC+'/lineup',515)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات - فلتر كامل',HbiLZQKalC+'/lineup',514)
	return
def Bh3nsbOTrxyNE5HwMzvWZSl94XYQL():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find('select',attrs={'name':'tag'})
	ZNpFGHa28C9WcoRb = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('option')
	for jwanU8orZtdFLNvM4EkHphWKzP in ZNpFGHa28C9WcoRb:
		EYn2siOeDvQTk8KpS0Jl = jwanU8orZtdFLNvM4EkHphWKzP.get('value')
		if not EYn2siOeDvQTk8KpS0Jl: continue
		title = jwanU8orZtdFLNvM4EkHphWKzP.text
		if ggl6zFuXNdYTDieHCqGKRnVx:
			title = title.encode('utf8')
			EYn2siOeDvQTk8KpS0Jl = EYn2siOeDvQTk8KpS0Jl.encode('utf8')
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+EYn2siOeDvQTk8KpS0Jl
		title = title.replace('قائمة ','')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,511)
	return
def wfVnk1UBAi6vP9btxDyl4():
	WWhNbJZ6LPM9aSecK = HbiLZQKalC+'/lineup?utf8=%E2%9C%93'
	Dl5ZUFfeTrHSRWwzCJK04cv = WWhNbJZ6LPM9aSecK+'&type=1&category=&foreign=&tag='
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات أشخاص',Dl5ZUFfeTrHSRWwzCJK04cv,511)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس أشخاص أبجدي',HbiLZQKalC+'/index/person/alphabet',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس موطن',HbiLZQKalC+'/index/person/nationality',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس  تاريخ الميلاد',HbiLZQKalC+'/index/person/birth_year',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فهرس  تاريخ الوفاة',HbiLZQKalC+'/index/person/death_year',517)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات - فلتر محدد',HbiLZQKalC+'/lineup',515)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مصنفات - فلتر كامل',HbiLZQKalC+'/lineup',514)
	return
def Xf4wTyQKshuGzdxCZn219HcWAFrJ(url):
	if '/seasonals' in url: prZUeN9FojstVTxf0EJQBRq4zdb = 0
	elif '/lineup' in url: prZUeN9FojstVTxf0EJQBRq4zdb = 1
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	uuPG8BO037eSynUNE = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all(class_='jumbo-theater clearfix')
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		title = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('a')[prZUeN9FojstVTxf0EJQBRq4zdb].text
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('a')[prZUeN9FojstVTxf0EJQBRq4zdb].get('href')
		if ggl6zFuXNdYTDieHCqGKRnVx:
			title = title.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
		if not uuPG8BO037eSynUNE:
			C3uTzABW1pQs8DvEZfYlGLaXn0jod(i8sFwPqo1vpEXR2VdHU5BmW)
			return
		else:
			title = title.replace('قائمة ','')
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,512)
	L1JqTz6nCfBjGP3SWAmd(B1wDYa3hsTSRkExN8upyIitA06Pf7q,511)
	return
def L1JqTz6nCfBjGP3SWAmd(B1wDYa3hsTSRkExN8upyIitA06Pf7q,mode):
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find(class_='pagination')
	if Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
		hhXnoWaD1Npzx = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('a')
		jjsbghADrk5d70UuGXKwiRSnqYN = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('li')
		NN3dTMIexjcKmFn1PO7 = list(zip(hhXnoWaD1Npzx,jjsbghADrk5d70UuGXKwiRSnqYN))
		H3ABEcMzfyqwF4Ug2ZYtK = -1
		Aa43rGtLqgzKP90VjZsyEn = len(NN3dTMIexjcKmFn1PO7)
		for KhRP2beyNfv,uugt4LSQ0jeBHFm in NN3dTMIexjcKmFn1PO7:
			H3ABEcMzfyqwF4Ug2ZYtK += 1
			uugt4LSQ0jeBHFm = uugt4LSQ0jeBHFm['class']
			if 'unavailable' in uugt4LSQ0jeBHFm or 'current' in uugt4LSQ0jeBHFm: continue
			dFEpvGRU73W6TowXj5xV8 = KhRP2beyNfv.text
			K9K307bTvRVtO6i = HbiLZQKalC+KhRP2beyNfv.get('href')
			if ggl6zFuXNdYTDieHCqGKRnVx:
				dFEpvGRU73W6TowXj5xV8 = dFEpvGRU73W6TowXj5xV8.encode('utf8')
				K9K307bTvRVtO6i = K9K307bTvRVtO6i.encode('utf8')
			if   H3ABEcMzfyqwF4Ug2ZYtK==0: dFEpvGRU73W6TowXj5xV8 = 'أولى'
			elif H3ABEcMzfyqwF4Ug2ZYtK==1: dFEpvGRU73W6TowXj5xV8 = 'سابقة'
			elif H3ABEcMzfyqwF4Ug2ZYtK==Aa43rGtLqgzKP90VjZsyEn-2: dFEpvGRU73W6TowXj5xV8 = 'لاحقة'
			elif H3ABEcMzfyqwF4Ug2ZYtK==Aa43rGtLqgzKP90VjZsyEn-1: dFEpvGRU73W6TowXj5xV8 = 'أخيرة'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+dFEpvGRU73W6TowXj5xV8,K9K307bTvRVtO6i,mode)
	return
def C3uTzABW1pQs8DvEZfYlGLaXn0jod(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	uuPG8BO037eSynUNE = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all(class_='row')
	items,ye8iWwASlpUFt = [],True
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		if not Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='thumbnail-wrapper'): continue
		if ye8iWwASlpUFt: ye8iWwASlpUFt = False ; continue
		tVCwnHmhUiYu = []
		t0zGjRDpAr4E6gSuWVi = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all(class_=['censorship red','censorship purple'])
		for q8ahW7sne0T4tRcDko in t0zGjRDpAr4E6gSuWVi:
			IvHFpy1M8n06g = q8ahW7sne0T4tRcDko.find_all('li')[1].text
			if ggl6zFuXNdYTDieHCqGKRnVx:
				IvHFpy1M8n06g = IvHFpy1M8n06g.encode('utf8')
			tVCwnHmhUiYu.append(IvHFpy1M8n06g)
		if not j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,'',tVCwnHmhUiYu,False):
			BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('data-src')
			title = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('h3')
			name = title.find('a').text
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+title.find('a').get('href')
			DrMi0RZ3kPaFUXxhHITc5tJqg1vS = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='no-margin')
			xxV0cuShJ5a9if6tXnD4ILzbAReEy = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='legend')
			if DrMi0RZ3kPaFUXxhHITc5tJqg1vS: DrMi0RZ3kPaFUXxhHITc5tJqg1vS = DrMi0RZ3kPaFUXxhHITc5tJqg1vS.text
			if xxV0cuShJ5a9if6tXnD4ILzbAReEy: xxV0cuShJ5a9if6tXnD4ILzbAReEy = xxV0cuShJ5a9if6tXnD4ILzbAReEy.text
			if ggl6zFuXNdYTDieHCqGKRnVx:
				BB5dqMe8jgLxwSvk = BB5dqMe8jgLxwSvk.encode('utf8')
				name = name.encode('utf8')
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
				if DrMi0RZ3kPaFUXxhHITc5tJqg1vS: DrMi0RZ3kPaFUXxhHITc5tJqg1vS = DrMi0RZ3kPaFUXxhHITc5tJqg1vS.encode('utf8')
			RLg3NjAdqfTMl = {}
			if xxV0cuShJ5a9if6tXnD4ILzbAReEy: RLg3NjAdqfTMl['stars'] = xxV0cuShJ5a9if6tXnD4ILzbAReEy
			if DrMi0RZ3kPaFUXxhHITc5tJqg1vS:
				DrMi0RZ3kPaFUXxhHITc5tJqg1vS = DrMi0RZ3kPaFUXxhHITc5tJqg1vS.replace('\n',' .. ')
				RLg3NjAdqfTMl['plot'] = DrMi0RZ3kPaFUXxhHITc5tJqg1vS.replace('...اقرأ المزيد','')
			if '/work/' in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,516,BB5dqMe8jgLxwSvk,'',name,'',RLg3NjAdqfTMl)
			elif '/person/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,513,BB5dqMe8jgLxwSvk,'',name,'',RLg3NjAdqfTMl)
	L1JqTz6nCfBjGP3SWAmd(B1wDYa3hsTSRkExN8upyIitA06Pf7q,512)
	return
def gLnZAzIF8E9UKYsPtcCMQdk(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	uuPG8BO037eSynUNE = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all('li')
	vXn9i1j8RkC2DrVua5TcBAOYQHW0S,items = [],[]
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		if not Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='thumbnail-wrapper'): continue
		if not Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_=['unstyled','unstyled text-center']): continue
		if Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='hide'): continue
		title = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in vXn9i1j8RkC2DrVua5TcBAOYQHW0S: continue
		vXn9i1j8RkC2DrVua5TcBAOYQHW0S.append(name)
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+title.find('a').get('href')
		if '/search/work/' in url: BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('src')
		elif '/search/person/' in url: BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('data-src')
		elif '/search/video/' in url: BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('data-src')
		else: BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('src')
		if ggl6zFuXNdYTDieHCqGKRnVx:
			name = name.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
			BB5dqMe8jgLxwSvk = BB5dqMe8jgLxwSvk.encode('utf8')
		name = name.strip(' ')
		items.append((name,i8sFwPqo1vpEXR2VdHU5BmW,BB5dqMe8jgLxwSvk))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,i8sFwPqo1vpEXR2VdHU5BmW,BB5dqMe8jgLxwSvk in items:
		if '/search/video/' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,522,BB5dqMe8jgLxwSvk)
		elif '/search/person/' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,513,BB5dqMe8jgLxwSvk,'',name)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,516,BB5dqMe8jgLxwSvk,'',name)
	return
def oCxG0fRjO6KuV(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	ooLf3EnIUrcilMeqW4a = text.count(' ')+1
	if ooLf3EnIUrcilMeqW4a==1:
		kJcx8qF9bEzU3psIP4D(text)
		return
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	r5GVAKqeDiEyRP = text.split(' ')
	KKGCiZbzaJUH = pow(2,ooLf3EnIUrcilMeqW4a)
	CeancZ3PvjOmh4Y1EQ5F = []
	def GTrYQaqP25wURsVC9J7(yy8YXhNF3Un6AewzDS,HHJgKtT3a5Ew62oIAvxLk):
		if yy8YXhNF3Un6AewzDS=='1': return HHJgKtT3a5Ew62oIAvxLk
		return ''
	for H3ABEcMzfyqwF4Ug2ZYtK in range(KKGCiZbzaJUH,0,-1):
		fXWhvOxMaBz4tgQniDCc2Fo10E = list(ooLf3EnIUrcilMeqW4a*'0'+bin(H3ABEcMzfyqwF4Ug2ZYtK)[2:])[-ooLf3EnIUrcilMeqW4a:]
		fXWhvOxMaBz4tgQniDCc2Fo10E = reversed(fXWhvOxMaBz4tgQniDCc2Fo10E)
		hrgtXiSNu72 = map(GTrYQaqP25wURsVC9J7,fXWhvOxMaBz4tgQniDCc2Fo10E,r5GVAKqeDiEyRP)
		title = ' '.join(filter(None,hrgtXiSNu72))
		if ggl6zFuXNdYTDieHCqGKRnVx: tKBSN4Zgn9CDb = title.decode('utf8')
		else: tKBSN4Zgn9CDb = title
		if len(tKBSN4Zgn9CDb)>2 and title not in CeancZ3PvjOmh4Y1EQ5F:
			CeancZ3PvjOmh4Y1EQ5F.append(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,'',523,'','',title)
	return
def kJcx8qF9bEzU3psIP4D(BRr98n5Uduzh):
	if ggl6zFuXNdYTDieHCqGKRnVx:
		BRr98n5Uduzh = BRr98n5Uduzh.decode('utf8')
		import arabic_reshaper as deYCO4iISzVun7Dc
		BRr98n5Uduzh = deYCO4iISzVun7Dc.ArabicReshaper().reshape(BRr98n5Uduzh)
		BRr98n5Uduzh = xAK6z48JXSbmultUw2BY.get_display(BRr98n5Uduzh)
	import E9jOJBma65
	BRr98n5Uduzh = NWs7KpjXGnxYylofHtd5U3wDh(default=BRr98n5Uduzh)
	E9jOJBma65.CXz8MpZeQigHAjw47TlbhdcPYoaWG(BRr98n5Uduzh)
	return
def gg6LZBnNMoeCw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find(class_='list-separator list-title')
	lNwOdSoA6E = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('a')
	items = []
	for title in lNwOdSoA6E:
		name = title.text
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+title.get('href')
		if ggl6zFuXNdYTDieHCqGKRnVx:
			name = name.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
		if '#' not in i8sFwPqo1vpEXR2VdHU5BmW: items.append((name,i8sFwPqo1vpEXR2VdHU5BmW))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
		name,i8sFwPqo1vpEXR2VdHU5BmW = Lw8JjEfuiW0VN9qHAcgRpMBdICS
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,518)
	return
def wKmTZfvYXSzgRQoh9rndt0(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	uuPG8BO037eSynUNE = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find(class_='expand').find_all('tr')
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		IWR6mz7kKElC9NpVinc28Xt13 = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find_all('a')
		if not IWR6mz7kKElC9NpVinc28Xt13: continue
		BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('data-src')
		name = IWR6mz7kKElC9NpVinc28Xt13[1].text
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+IWR6mz7kKElC9NpVinc28Xt13[1].get('href')
		xxV0cuShJ5a9if6tXnD4ILzbAReEy = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='legend')
		if xxV0cuShJ5a9if6tXnD4ILzbAReEy: xxV0cuShJ5a9if6tXnD4ILzbAReEy = xxV0cuShJ5a9if6tXnD4ILzbAReEy.text
		if ggl6zFuXNdYTDieHCqGKRnVx:
			name = name.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
			BB5dqMe8jgLxwSvk = BB5dqMe8jgLxwSvk.encode('utf8')
		RLg3NjAdqfTMl = {}
		if xxV0cuShJ5a9if6tXnD4ILzbAReEy: RLg3NjAdqfTMl['stars'] = xxV0cuShJ5a9if6tXnD4ILzbAReEy
		if '/work/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,516,BB5dqMe8jgLxwSvk,'',name,'',RLg3NjAdqfTMl)
		elif '/person/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,513,BB5dqMe8jgLxwSvk,'',name,'',RLg3NjAdqfTMl)
	L1JqTz6nCfBjGP3SWAmd(B1wDYa3hsTSRkExN8upyIitA06Pf7q,518)
	return
def JLxBibOcZduNCfzvtjIF(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	lNwOdSoA6E = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all(class_='section-title inline')
	kkH5sRPxhASFowLONy4 = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all(class_='button green small right')
	items = zip(lNwOdSoA6E,kkH5sRPxhASFowLONy4)
	for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
		title = title.text
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW.get('href')
		if ggl6zFuXNdYTDieHCqGKRnVx:
			title = title.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,521)
	return
def XOlERqYJci3DjzukSVF5WveH(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	iiGPoT04vhjz = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	uuPG8BO037eSynUNE = iiGPoT04vhjz.find_all('li')
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		title = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='title').text
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('a').get('href')
		BB5dqMe8jgLxwSvk = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find('img').get('data-src')
		fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.find(class_='duration').text
		if ggl6zFuXNdYTDieHCqGKRnVx:
			title = title.encode('utf8')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
			BB5dqMe8jgLxwSvk = BB5dqMe8jgLxwSvk.encode('utf8')
			fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.encode('utf8')
		fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace('\n','').strip(' ')
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,522,BB5dqMe8jgLxwSvk,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	L1JqTz6nCfBjGP3SWAmd(B1wDYa3hsTSRkExN8upyIitA06Pf7q,521)
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	i8sFwPqo1vpEXR2VdHU5BmW = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find(class_='flex-video').find('iframe').get('src')
	if ggl6zFuXNdYTDieHCqGKRnVx: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.encode('utf8')
	pidYDcjvhgVfqb3GeWSAOH5J(i8sFwPqo1vpEXR2VdHU5BmW,nO6ukabcldeU,'video')
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','%20')
	url = HbiLZQKalC+'/search/?q='+search
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not WM1buqXnzf3Ba6Vp29l4gFD.succeeded:
		Dl5ZUFfeTrHSRWwzCJK04cv = HbiLZQKalC+'/search_entity/?q='+search+'&entity=work'
		K9K307bTvRVtO6i = HbiLZQKalC+'/search_entity/?q='+search+'&entity=person'
		ddaXOACLHSWo4r = HbiLZQKalC+'/search_entity/?q='+search+'&entity=video'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن أعمال',Dl5ZUFfeTrHSRWwzCJK04cv,513,'',search)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن أشخاص',K9K307bTvRVtO6i,513,'',search)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث عن فيديوهات',ddaXOACLHSWo4r,513,'',search)
		return
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	B1wDYa3hsTSRkExN8upyIitA06Pf7q = b6HI1EL95gSlVF.BeautifulSoup(qQXuaKpVrGLF3e5oidJ8YwDT0,'html.parser',multi_valued_attributes=None)
	uuPG8BO037eSynUNE = B1wDYa3hsTSRkExN8upyIitA06Pf7q.find_all(class_='section-title left')
	for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
		title = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.text
		if ggl6zFuXNdYTDieHCqGKRnVx:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: i8sFwPqo1vpEXR2VdHU5BmW = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: i8sFwPqo1vpEXR2VdHU5BmW = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: i8sFwPqo1vpEXR2VdHU5BmW = url.replace('/search/','/search/video/')
		else: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,513)
	return
def ShzHKIXUFlj9GwMYm(url,text):
	global aKqQ1yXlIcDoxtdCmunE,Dx5lzy4Anw63Lt1SsNm2rhk
	if '/seasonals' in url:
		aKqQ1yXlIcDoxtdCmunE = ['seasonal','year','category']
		Dx5lzy4Anw63Lt1SsNm2rhk = ['seasonal','year','category']
	elif '/lineup' in url:
		aKqQ1yXlIcDoxtdCmunE = ['category','foreign','type']
		Dx5lzy4Anw63Lt1SsNm2rhk = ['category','foreign','type']
	hr0qteMSui7ZzxCoE(url,text)
	return
def fr0hRyYNE14zx(url):
	url = url.split('/smartemadfilter?')[0]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('form action="/(.*?)</form>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	return ZlLpkRV3E5JQdX7AWPOaiFuy0zs
def jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR):
	items = T072lCzjYiuaeFtmJGV.findall('<option value="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	return items
def QQMP0rV7x3IcgE4D9jW6JBy(url):
	Oa38pfHe5x2FPCKRwbJ6mhVG = url.split('/smartemadfilter?')[0]
	i4sAb9xNqmGp2hCXUJtvuy7zkSW = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def VSf4n8CLvRiuQh(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,url):
	YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'all_filters')
	dCmKxk9BW310AXu4bJUHfY = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
	dCmKxk9BW310AXu4bJUHfY = QQMP0rV7x3IcgE4D9jW6JBy(dCmKxk9BW310AXu4bJUHfY)
	return dCmKxk9BW310AXu4bJUHfY
def hr0qteMSui7ZzxCoE(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if aKqQ1yXlIcDoxtdCmunE[0]+'=' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(aKqQ1yXlIcDoxtdCmunE[0:-1])):
			if aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5]+'=' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		ll9khUfx3MjZ = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
	elif type=='ALL_ITEMS_FILTER':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'/smartemadfilter?'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		ll9khUfx3MjZ = QQMP0rV7x3IcgE4D9jW6JBy(ll9khUfx3MjZ)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها ',ll9khUfx3MjZ,511)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',ll9khUfx3MjZ,511)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = fr0hRyYNE14zx(url)
	dict = {}
	for name,cfWiG8bKuYoq32vDE51hCUxPT,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		name = name.replace('--','')
		items = jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
		if '=' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='SPECIFIED_FILTER':
			if cfWiG8bKuYoq32vDE51hCUxPT not in aKqQ1yXlIcDoxtdCmunE: continue
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<2:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]:
					url = QQMP0rV7x3IcgE4D9jW6JBy(url)
					C3uTzABW1pQs8DvEZfYlGLaXn0jod(url)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'SPECIFIED_FILTER___'+Dwqu0Ws9eK)
				return
			else:
				ll9khUfx3MjZ = QQMP0rV7x3IcgE4D9jW6JBy(ll9khUfx3MjZ)
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,511)
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,515,'','',Dwqu0Ws9eK)
		elif type=='ALL_ITEMS_FILTER':
			if cfWiG8bKuYoq32vDE51hCUxPT not in Dx5lzy4Anw63Lt1SsNm2rhk: continue
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع: '+name,ll9khUfx3MjZ,514,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			if 'مصنفات أخرى' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			if 'الكل' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			if 'اللغة' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			jwanU8orZtdFLNvM4EkHphWKzP = jwanU8orZtdFLNvM4EkHphWKzP.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = jwanU8orZtdFLNvM4EkHphWKzP
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+jwanU8orZtdFLNvM4EkHphWKzP
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			if name: title = jwanU8orZtdFLNvM4EkHphWKzP+' :'+name
			else: title = jwanU8orZtdFLNvM4EkHphWKzP
			if type=='ALL_ITEMS_FILTER': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,514,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='SPECIFIED_FILTER' and aKqQ1yXlIcDoxtdCmunE[-2]+'=' in cghHqoyS13upLUdz8bkXO7wlPK:
				dCmKxk9BW310AXu4bJUHfY = VSf4n8CLvRiuQh(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,url)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,dCmKxk9BW310AXu4bJUHfY,511)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,515,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.replace('=&','=0&')
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&')
	H5y1ofSbMzmN7JI = {}
	if '=' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = ''
	for key in Dx5lzy4Anw63Lt1SsNm2rhk:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if '%' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = K3PukgCEDY(EYn2siOeDvQTk8KpS0Jl)
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all_filters': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.replace('=0','=')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
aKqQ1yXlIcDoxtdCmunE = []
Dx5lzy4Anw63Lt1SsNm2rhk = []
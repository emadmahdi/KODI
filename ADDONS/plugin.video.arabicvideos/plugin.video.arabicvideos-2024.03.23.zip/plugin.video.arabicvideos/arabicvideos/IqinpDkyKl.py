# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
headers = { 'User-Agent' : '' }
nO6ukabcldeU = 'AKWAM'
JJCLnkX4TozH7Bsjivfe = '_AKW_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
zzuy0oRIfB3ZSimQ1L9jNXvrGcgs = ''
OZYvGX7EMx05KH1fI = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==240: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==241: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==242: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==243: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==244: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'FILTERS___'+text)
	elif mode==245: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'CATEGORIES___'+text)
	elif mode==246: cLCisPE3lX = mNJ2Vln3r5uEhqzk8(url)
	elif mode==247: cLCisPE3lX = wil7QqY43Pv(url)
	elif mode==248: cLCisPE3lX = yOSJwc9Pubr()
	elif mode==249: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def yOSJwc9Pubr():
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'',headers,'','','AKWAM-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	OOKslEqda2uQFCXR54mGbS = T072lCzjYiuaeFtmJGV.findall('home-site-btn-container.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if OOKslEqda2uQFCXR54mGbS: OOKslEqda2uQFCXR54mGbS = OOKslEqda2uQFCXR54mGbS[0]
	else: OOKslEqda2uQFCXR54mGbS = HbiLZQKalC
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',OOKslEqda2uQFCXR54mGbS,'',headers,'','','AKWAM-MENU-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',249,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',HbiLZQKalC,246)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',HbiLZQKalC,247)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',OOKslEqda2uQFCXR54mGbS,241,'','','featured')
	recent = T072lCzjYiuaeFtmJGV.findall('recently-container.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	i8sFwPqo1vpEXR2VdHU5BmW = recent[0]
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أضيف حديثا',i8sFwPqo1vpEXR2VdHU5BmW,241)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
		if name in OZYvGX7EMx05KH1fI: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+name,i8sFwPqo1vpEXR2VdHU5BmW,241)
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title in OZYvGX7EMx05KH1fI: continue
			title = name+' '+title
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,241)
	return
def mNJ2Vln3r5uEhqzk8(website=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','AKWAM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu(.*?)<nav',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?text">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI:
				title = title+' مصنفة'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,245)
		if website=='': QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def wil7QqY43Pv(website=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','AKWAM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu(.*?)<nav',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?text">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI:
				title = title+' مفلترة'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,244)
		if website=='': QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'AKWAM-TITLES-1st')
	if type=='featured': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('swiper-container(.*?)swiper-button-prev',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="widget"(.*?)main-footer',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if not items:
			items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if '/series/' in i8sFwPqo1vpEXR2VdHU5BmW or '/shows/' in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,242,o3gHuBtrRN)
			elif '/movies/' in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,243,o3gHuBtrRN)
			elif '/games/' not in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,243,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,241)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','%20')
	url = HbiLZQKalC + '/search?q='+xC2GuEcJKk3t4Uh
	cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def UAB8vizclM6XG4Pw(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in qQXuaKpVrGLF3e5oidJ8YwDT0:
		o3gHuBtrRN = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Icon')
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+'رابط التشغيل',url,243,o3gHuBtrRN)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('-episodes">(.*?)<div class="widget-4',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		Ad5sCEYHjxzg3yK = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in Ad5sCEYHjxzg3yK:
			title = title.replace('  ',' ')
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,242,o3gHuBtrRN)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,243,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,True,'AKWAM-PLAY-1st')
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('badge-danger.*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	n7tr6RZl4xh1viBpzK5uYVc = T072lCzjYiuaeFtmJGV.findall('li><a href="#(.*?)".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL,uuPG8BO037eSynUNE,hbu37pS1DZjEmQGWO9iUvFk2L = [],[],[],[]
	if n7tr6RZl4xh1viBpzK5uYVc:
		UuygfPcTR0zC = 'mp4'
		for UerviYn3kJqNEu6IfHpm7TR4,Q5OAspyiXV1lx8930qLGD in n7tr6RZl4xh1viBpzK5uYVc:
			tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('tab-content quality" id="'+UerviYn3kJqNEu6IfHpm7TR4+'".*?</div>.\s*</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			uuPG8BO037eSynUNE.append(Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
			hbu37pS1DZjEmQGWO9iUvFk2L.append(Q5OAspyiXV1lx8930qLGD)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="qualities(.*?)<h3.*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR,filename = tmEVko4qsghUX6WLx8KG7fOTB[0]
			NhfwnFEGJabTR4Mx = ['zip','rar','txt','pdf','htm','tar','iso','html']
			UuygfPcTR0zC = filename.rsplit('.',1)[1].strip(' ')
			if UuygfPcTR0zC in NhfwnFEGJabTR4Mx:
				KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		uuPG8BO037eSynUNE.append(Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
		hbu37pS1DZjEmQGWO9iUvFk2L.append('')
	for jV1Z7MWOa80gbwJY64nL5 in range(len(uuPG8BO037eSynUNE)):
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?icon-(.*?)"',uuPG8BO037eSynUNE[jV1Z7MWOa80gbwJY64nL5],T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,FFUEgCi8ZHnzbwv7hO0MtqpAWL2GI in kkH5sRPxhASFowLONy4:
			if 'torrent' in FFUEgCi8ZHnzbwv7hO0MtqpAWL2GI: continue
			elif 'download' in FFUEgCi8ZHnzbwv7hO0MtqpAWL2GI: type = 'download'
			elif 'play' in FFUEgCi8ZHnzbwv7hO0MtqpAWL2GI: type = 'watch'
			else: type = 'unknown'
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named=__'+type+'____'+hbu37pS1DZjEmQGWO9iUvFk2L[jV1Z7MWOa80gbwJY64nL5]+'__akwam'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def hr0qteMSui7ZzxCoE(url,filter):
	aKqQ1yXlIcDoxtdCmunE = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='CATEGORIES':
		if aKqQ1yXlIcDoxtdCmunE[0]+'=' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(aKqQ1yXlIcDoxtdCmunE[0:-1])):
			if aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5]+'=' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'all')
		ll9khUfx3MjZ = url+'?'+YupaFCoAIicOnZNd
	elif type=='FILTERS':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'all')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'?'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها',ll9khUfx3MjZ,241,'','1')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',ll9khUfx3MjZ,241,'','1')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,True,'AKWAM-FILTERS_MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<form id(.*?)</form>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	dict = {}
	for cfWiG8bKuYoq32vDE51hCUxPT,name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		items = T072lCzjYiuaeFtmJGV.findall('<option(.*?)>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if '=' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='CATEGORIES':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<=1:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'CATEGORIES___'+Dwqu0Ws9eK)
				return
			else:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,241,'','1')
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,245,'','',Dwqu0Ws9eK)
		elif type=='FILTERS':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع : '+name,ll9khUfx3MjZ,244,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			if 'value' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = jwanU8orZtdFLNvM4EkHphWKzP
			else: EYn2siOeDvQTk8KpS0Jl = T072lCzjYiuaeFtmJGV.findall('"(.*?)"',EYn2siOeDvQTk8KpS0Jl,T072lCzjYiuaeFtmJGV.DOTALL)[0]
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = jwanU8orZtdFLNvM4EkHphWKzP
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+jwanU8orZtdFLNvM4EkHphWKzP
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			title = jwanU8orZtdFLNvM4EkHphWKzP+' : '#+dict[cfWiG8bKuYoq32vDE51hCUxPT]['0']
			title = jwanU8orZtdFLNvM4EkHphWKzP+' : '+name
			if type=='FILTERS': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,244,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='CATEGORIES' and aKqQ1yXlIcDoxtdCmunE[-2]+'=' in cghHqoyS13upLUdz8bkXO7wlPK:
				YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'all')
				dCmKxk9BW310AXu4bJUHfY = url+'?'+YupaFCoAIicOnZNd
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,dCmKxk9BW310AXu4bJUHfY,241,'','1')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,245,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&')
	H5y1ofSbMzmN7JI = {}
	if '=' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = ''
	Dx5lzy4Anw63Lt1SsNm2rhk = ['section','category','rating','year','language','formats','quality']
	for key in Dx5lzy4Anw63Lt1SsNm2rhk:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
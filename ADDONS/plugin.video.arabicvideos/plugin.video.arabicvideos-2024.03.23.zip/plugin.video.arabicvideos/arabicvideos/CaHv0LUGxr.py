# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
JJCLnkX4TozH7Bsjivfe = '_MVZ_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
m0nJ6xfD21QG3FyNP4WlT7u = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][1]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==180: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==181: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==182: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==183: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==188: cLCisPE3lX = Mp4nZPkVhub5Hjcvz8xF7iT3()
	elif mode==189: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def Mp4nZPkVhub5Hjcvz8xF7iT3():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج',message)
	return
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'بوكس اوفيس موفيز لاند',HbiLZQKalC,181,'','','box-office')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أحدث الافلام',HbiLZQKalC,181,'','','latest-movies')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'تليفزيون موفيز لاند',HbiLZQKalC,181,'','','tv')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الاكثر مشاهدة',HbiLZQKalC,181,'','','top-views')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أقوى الافلام الحالية',HbiLZQKalC,181,'','','top-movies')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','MOVIZLAND-MENU-1st')
	items = T072lCzjYiuaeFtmJGV.findall('<h2><a href="(.*?)".*?">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,181)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	elif type=='box-office': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	elif type=='top-movies': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('btn-2-overlay(.*?)<style>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	elif type=='top-views': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	elif type=='tv': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	else: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
	if type in ['top-views','top-movies']:
		items = T072lCzjYiuaeFtmJGV.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	else: items = T072lCzjYiuaeFtmJGV.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	ii0ST7oQxM = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for o3gHuBtrRN,INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,fcQ2I84FpMSvUCt05ldNjeD in items:
		if type in ['top-views','top-movies']:
			o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,K9K307bTvRVtO6i,title = o3gHuBtrRN,INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,fcQ2I84FpMSvUCt05ldNjeD
		else: o3gHuBtrRN,title,i8sFwPqo1vpEXR2VdHU5BmW,K9K307bTvRVtO6i = o3gHuBtrRN,INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,fcQ2I84FpMSvUCt05ldNjeD
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('?view=true','')
		title = Nkuqp0boKj41i9(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|الحلقه) \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if XSCYbwaqRBtopUc9H2QZu86gA5N:
				title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,183,o3gHuBtrRN)
					BBRwQhFnJ08q9YVxOSya.append(title)
		elif any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in ii0ST7oQxM):
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW + '?servers=' + K9K307bTvRVtO6i
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,182,o3gHuBtrRN)
		else:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW + '?servers=' + K9K307bTvRVtO6i
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,183,o3gHuBtrRN)
	if type=='':
		items = T072lCzjYiuaeFtmJGV.findall('\n<li><a href="(.*?)".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			title = title.replace('الصفحة ','')
			if title!='':
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,181)
	return
def UAB8vizclM6XG4Pw(url):
	ll9khUfx3MjZ = url.split('?servers=')[0]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'',headers,'','MOVIZLAND-EPISODES-1st')
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = T072lCzjYiuaeFtmJGV.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	title,O578ENGbr6PYnLJzi,o3gHuBtrRN = Zsh7mUdwjHobLyMz6WKJGVl1cgeR[0]
	name = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,T072lCzjYiuaeFtmJGV.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="episodesNumbers"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in items:
			i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
			title = T072lCzjYiuaeFtmJGV.findall('(الحلقة|الحلقه)-([0-9]+)',i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-2],T072lCzjYiuaeFtmJGV.DOTALL)
			if not title: title = T072lCzjYiuaeFtmJGV.findall('()-([0-9]+)',i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-2],T072lCzjYiuaeFtmJGV.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,182,o3gHuBtrRN)
	if not items:
		title = Nkuqp0boKj41i9(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,url,182,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	fRUZX4eznc6x2C9d8aptBWuiTS = url.split('?servers=')
	ll9khUfx3MjZ = fRUZX4eznc6x2C9d8aptBWuiTS[0]
	del fRUZX4eznc6x2C9d8aptBWuiTS[0]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'',headers,'','MOVIZLAND-PLAY-1st')
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('font-size: 25px;" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	if i8sFwPqo1vpEXR2VdHU5BmW not in fRUZX4eznc6x2C9d8aptBWuiTS: fRUZX4eznc6x2C9d8aptBWuiTS.append(i8sFwPqo1vpEXR2VdHU5BmW)
	M7oS6tLhdx3ke8qPX4mFA = []
	for i8sFwPqo1vpEXR2VdHU5BmW in fRUZX4eznc6x2C9d8aptBWuiTS:
		if '://moshahda.' in i8sFwPqo1vpEXR2VdHU5BmW:
			k6AKpT9fBCn = i8sFwPqo1vpEXR2VdHU5BmW
			M7oS6tLhdx3ke8qPX4mFA.append(k6AKpT9fBCn+'?named=Main')
	for i8sFwPqo1vpEXR2VdHU5BmW in fRUZX4eznc6x2C9d8aptBWuiTS:
		if '://vb.movizland.' in i8sFwPqo1vpEXR2VdHU5BmW:
			qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,i8sFwPqo1vpEXR2VdHU5BmW,'',headers,'','MOVIZLAND-PLAY-2nd')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.decode('windows-1256').encode('utf8')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if tmEVko4qsghUX6WLx8KG7fOTB:
				JajuNYsFR1IH6cZ4mVnKMy8AOpD0,Kz7rh4lCoLEdxDJwIOsMuQjX38T0yR = [],[]
				if len(tmEVko4qsghUX6WLx8KG7fOTB)==1:
					title = ''
					Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
				else:
					for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
						MwELA7bGROd1uohvUNKpsrDVWnSyf4 = T072lCzjYiuaeFtmJGV.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
						if MwELA7bGROd1uohvUNKpsrDVWnSyf4: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = 'src="/uploads/13721411411.png"  \n  ' + MwELA7bGROd1uohvUNKpsrDVWnSyf4[0][1]
						MwELA7bGROd1uohvUNKpsrDVWnSyf4 = T072lCzjYiuaeFtmJGV.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
						if MwELA7bGROd1uohvUNKpsrDVWnSyf4: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = 'src="/uploads/13721411411.png"  \n  ' + MwELA7bGROd1uohvUNKpsrDVWnSyf4[0]
						MwELA7bGROd1uohvUNKpsrDVWnSyf4 = T072lCzjYiuaeFtmJGV.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
						if MwELA7bGROd1uohvUNKpsrDVWnSyf4: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = MwELA7bGROd1uohvUNKpsrDVWnSyf4[0] + '  \n  src="/uploads/13721411411.png"'
						J39JVs8jarA1U2 = T072lCzjYiuaeFtmJGV.findall('<(.*?)http://up.movizland.(online|com)/uploads/',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
						title = T072lCzjYiuaeFtmJGV.findall('> *([^<>]+) *<',J39JVs8jarA1U2[0][0],T072lCzjYiuaeFtmJGV.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						JajuNYsFR1IH6cZ4mVnKMy8AOpD0.append(title)
					tzgWIKy5xQL2kjm = sSOy1pju5PJ('أختر الفيديو المطلوب:', JajuNYsFR1IH6cZ4mVnKMy8AOpD0)
					if tzgWIKy5xQL2kjm == -1 : return
					title = JajuNYsFR1IH6cZ4mVnKMy8AOpD0[tzgWIKy5xQL2kjm]
					Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[tzgWIKy5xQL2kjm]
				i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('href="(http://moshahda\..*?/\w+.html)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				Zus7J0xI1dD3K5jkClrvo2RQ = i8sFwPqo1vpEXR2VdHU5BmW[0]
				M7oS6tLhdx3ke8qPX4mFA.append(Zus7J0xI1dD3K5jkClrvo2RQ+'?named=Forum')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('ـ','')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				oGuJQzYgdnya = T072lCzjYiuaeFtmJGV.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for D03J8FL94gHwvr in oGuJQzYgdnya:
					type = T072lCzjYiuaeFtmJGV.findall(' typetype="(.*?)" ',D03J8FL94gHwvr)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = T072lCzjYiuaeFtmJGV.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',D03J8FL94gHwvr,T072lCzjYiuaeFtmJGV.DOTALL)
					for I1I3phgnD7ePSLf8JdOK4NuMCB,i8sFwPqo1vpEXR2VdHU5BmW in items:
						title = T072lCzjYiuaeFtmJGV.findall('(\w+[ \w]*)<',I1I3phgnD7ePSLf8JdOK4NuMCB)
						title = title[-1]
						i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW + '?named=' + title + type
						M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ.replace(HbiLZQKalC,m0nJ6xfD21QG3FyNP4WlT7u)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,dCmKxk9BW310AXu4bJUHfY,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = T072lCzjYiuaeFtmJGV.findall('" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		h2cMwXugQn5 = items[-1]
		M7oS6tLhdx3ke8qPX4mFA.append(h2cMwXugQn5+'?named=Mobile')
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,HbiLZQKalC,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = T072lCzjYiuaeFtmJGV.findall('<option value="(.*?)">(.*?)</option>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	u1uygNoZ4a = [ '' ]
	JJmPeYt6s7nFWcx = [ 'الكل وبدون فلتر' ]
	for ZecS1yJOzVutgX0qiH3NER,title in items:
		u1uygNoZ4a.append(ZecS1yJOzVutgX0qiH3NER)
		JJmPeYt6s7nFWcx.append(title)
	if ZecS1yJOzVutgX0qiH3NER:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الفلتر المناسب:', JJmPeYt6s7nFWcx)
		if tzgWIKy5xQL2kjm == -1 : return
		ZecS1yJOzVutgX0qiH3NER = u1uygNoZ4a[tzgWIKy5xQL2kjm]
	else: ZecS1yJOzVutgX0qiH3NER = ''
	url = HbiLZQKalC + '/?s='+search+'&mcat='+ZecS1yJOzVutgX0qiH3NER
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
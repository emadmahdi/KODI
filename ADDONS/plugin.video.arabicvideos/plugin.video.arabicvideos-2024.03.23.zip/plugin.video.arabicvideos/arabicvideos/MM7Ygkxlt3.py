# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'EGYBEST3'
JJCLnkX4TozH7Bsjivfe = '_EB3_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,ffGe7cURW0lhJVvQAiw8IB,text):
	if   mode==790: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==791: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==792: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==793: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==796: cLCisPE3lX = HNseQUBuMGwfXmRoqIkgjt5Z2V(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==799: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','EGYBEST3-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('list-pages(.*?)fa-folder',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<span>(.*?)</span>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-article(.*?)social-box',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('main-title.*?">(.*?)<.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791,'','mainmenu')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-menu(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def HNseQUBuMGwfXmRoqIkgjt5Z2V(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-article".*?">(.*?)<(.*?)article',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		i80ehylRFvHDAbXBpkIr,Ad5sCEYHjxzg3yK,items = '','',[]
		for name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			if 'حلقات' in name: Ad5sCEYHjxzg3yK = Zsh7mUdwjHobLyMz6WKJGVl1cgeR
			if 'مواسم' in name: i80ehylRFvHDAbXBpkIr = Zsh7mUdwjHobLyMz6WKJGVl1cgeR
		if i80ehylRFvHDAbXBpkIr and not type:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',i80ehylRFvHDAbXBpkIr,T072lCzjYiuaeFtmJGV.DOTALL)
			if len(items)>1:
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,796,o3gHuBtrRN,'season')
		if Ad5sCEYHjxzg3yK and len(items)<2:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',Ad5sCEYHjxzg3yK,T072lCzjYiuaeFtmJGV.DOTALL)
			if items:
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,793,o3gHuBtrRN)
			else:
				items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Ad5sCEYHjxzg3yK,T072lCzjYiuaeFtmJGV.DOTALL)
				for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,793)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	cd9Um4xeAzgvZBPTjIithDqa7,start,zgs5N10mMd9PVTRuHA4GWJDycpeLl,select,GGMtXDqi57IaEW2FSeulNzkmJ8 = 0,0,'','',''
	if 'pagination' in type:
		xc2ltn65KjUez,data = y2dmjAuhlfboLe(url)
		cd9Um4xeAzgvZBPTjIithDqa7 = int(data['limit'])
		start = int(data['start'])
		zgs5N10mMd9PVTRuHA4GWJDycpeLl = data['type']
		select = data['select']
		vf78LSlJQOnCsatrIH2P1iW = 'limit='+str(cd9Um4xeAzgvZBPTjIithDqa7)+'&start='+str(start)+'&type='+zgs5N10mMd9PVTRuHA4GWJDycpeLl+'&select='+select
		JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',xc2ltn65KjUez,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','EGYBEST3-TITLES-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = 'blocks'+qQXuaKpVrGLF3e5oidJ8YwDT0+'article'
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = qQXuaKpVrGLF3e5oidJ8YwDT0
		code = T072lCzjYiuaeFtmJGV.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			O578ENGbr6PYnLJzi,data = y2dmjAuhlfboLe('?'+code)
			cd9Um4xeAzgvZBPTjIithDqa7 = int(data['limit'])
			start = int(data['start'])
			zgs5N10mMd9PVTRuHA4GWJDycpeLl = data['type']
			select = data['select']
			GGMtXDqi57IaEW2FSeulNzkmJ8 = data['ajaxurl']
			vf78LSlJQOnCsatrIH2P1iW = 'limit='+str(cd9Um4xeAzgvZBPTjIithDqa7)+'&start='+str(start)+'&type='+zgs5N10mMd9PVTRuHA4GWJDycpeLl+'&select='+select
			xc2ltn65KjUez = HbiLZQKalC+GGMtXDqi57IaEW2FSeulNzkmJ8
			JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded'}
			WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',xc2ltn65KjUez,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','EGYBEST3-TITLES-3rd')
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = 'blocks'+IIV0pUlqMoKDC9r8wy1EGT7OesJQBS+'article'
	items,x2dbytYP1qriwCmTc,RowfG8LnD9IvTg34Ue2WVbBXa0O5u = [],False,False
	if not type:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-content(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791,'','submenu')
				x2dbytYP1qriwCmTc = True
	if not type:
		RowfG8LnD9IvTg34Ue2WVbBXa0O5u = Zpf05iQWjnIOw(qQXuaKpVrGLF3e5oidJ8YwDT0)
	if not x2dbytYP1qriwCmTc and not RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('blocks(.*?)article',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
				o3gHuBtrRN = o3gHuBtrRN.strip('\n')
				i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
				if '/selary/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791,o3gHuBtrRN)
				elif 'مسلسل' in i8sFwPqo1vpEXR2VdHU5BmW and 'حلقة' not in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,796,o3gHuBtrRN)
				elif 'موسم' in i8sFwPqo1vpEXR2VdHU5BmW and 'حلقة' not in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,796,o3gHuBtrRN)
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,793,o3gHuBtrRN)
		Aa43rGtLqgzKP90VjZsyEn = 12
		data = T072lCzjYiuaeFtmJGV.findall('class="(load-more.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(items)==Aa43rGtLqgzKP90VjZsyEn and (data or 'pagination' in type):
			vf78LSlJQOnCsatrIH2P1iW = 'limit='+str(Aa43rGtLqgzKP90VjZsyEn)+'&start='+str(start+Aa43rGtLqgzKP90VjZsyEn)+'&type='+zgs5N10mMd9PVTRuHA4GWJDycpeLl+'&select='+select
			ll9khUfx3MjZ = xc2ltn65KjUez+'?next=page&'+vf78LSlJQOnCsatrIH2P1iW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المزيد',ll9khUfx3MjZ,791,'','pagination_'+type)
	return
def Zpf05iQWjnIOw(qQXuaKpVrGLF3e5oidJ8YwDT0):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = False
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-article(.*?)article',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if uuPG8BO037eSynUNE: QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for ZecS1yJOzVutgX0qiH3NER,name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
			name = name.strip(' ')
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,EYn2siOeDvQTk8KpS0Jl in items:
				title = name+':  '+EYn2siOeDvQTk8KpS0Jl
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,791,'','filter')
				RowfG8LnD9IvTg34Ue2WVbBXa0O5u = True
	return RowfG8LnD9IvTg34Ue2WVbBXa0O5u
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	MfIDplCLUGK91vjO,lmsz7vjDrfqH5XhJ1CY = [],[]
	items = T072lCzjYiuaeFtmJGV.findall('server-item.*?data-code="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for mdqDWPQYu4iBHswMZ5rFE in items:
		xOCFfnUvQhBpqoKa = eJ4h7nOpguFMH6z1IUEV2i.b64decode(mdqDWPQYu4iBHswMZ5rFE)
		if mmIKCGujwM: xOCFfnUvQhBpqoKa = xOCFfnUvQhBpqoKa.decode('utf8')
		i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',xOCFfnUvQhBpqoKa,T072lCzjYiuaeFtmJGV.DOTALL)
		if i8sFwPqo1vpEXR2VdHU5BmW:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
			if i8sFwPqo1vpEXR2VdHU5BmW not in lmsz7vjDrfqH5XhJ1CY:
				lmsz7vjDrfqH5XhJ1CY.append(i8sFwPqo1vpEXR2VdHU5BmW)
				dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__watch')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="downloads(.*?)</section>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for Q5OAspyiXV1lx8930qLGD,i8sFwPqo1vpEXR2VdHU5BmW in items:
			if i8sFwPqo1vpEXR2VdHU5BmW not in lmsz7vjDrfqH5XhJ1CY:
				if '/?url=' in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('/?url=')[1]
				lmsz7vjDrfqH5XhJ1CY.append(i8sFwPqo1vpEXR2VdHU5BmW)
				dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__download____'+Q5OAspyiXV1lx8930qLGD)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(text):
	return
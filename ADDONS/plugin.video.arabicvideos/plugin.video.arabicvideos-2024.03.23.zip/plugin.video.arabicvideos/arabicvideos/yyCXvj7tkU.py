# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'FASELHD2'
headers = {'User-Agent':''}
JJCLnkX4TozH7Bsjivfe = '_FH2_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['wwe']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==590: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==591: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==592: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==593: cLCisPE3lX = HNseQUBuMGwfXmRoqIkgjt5Z2V(url,text)
	elif mode==599: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	LL2d9tanw0mrxJBKAT63buD = HbiLZQKalC
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',LL2d9tanw0mrxJBKAT63buD,'','','','','FASELHD2-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع',LL2d9tanw0mrxJBKAT63buD,599,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',LL2d9tanw0mrxJBKAT63buD,591,'','','featured1')
	items = T072lCzjYiuaeFtmJGV.findall('<strong>(.*?)</strong>.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,591,'','','details1')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-menu"(.*?)header-social',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		ggBx2ykcHhZdVmeNQFnfs = T072lCzjYiuaeFtmJGV.findall('<li (.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for vAujiEeLZbowS2Xgp5830Yc in ggBx2ykcHhZdVmeNQFnfs:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',vAujiEeLZbowS2Xgp5830Yc,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,591,'','','details2')
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FASELHD2-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ttGcvALMEaQR71OI0mFJuw = 0
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"archive-slider(.*?)<h4>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0: MwELA7bGROd1uohvUNKpsrDVWnSyf4 = q9OCkWn6ruAvQLKDFUyxBME0[0]
	else: MwELA7bGROd1uohvUNKpsrDVWnSyf4 = ''
	if type=='featured1':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"slider-carousel"(.*?)</container>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		kMpzodri5XQTF3uN,lNwOdSoA6E,kkH5sRPxhASFowLONy4 = zip(*items)
		items = zip(kkH5sRPxhASFowLONy4,kMpzodri5XQTF3uN,lNwOdSoA6E)
	elif type=='featured2':
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',MwELA7bGROd1uohvUNKpsrDVWnSyf4,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='filters':
		tmEVko4qsghUX6WLx8KG7fOTB = [qQXuaKpVrGLF3e5oidJ8YwDT0.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in MwELA7bGROd1uohvUNKpsrDVWnSyf4:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<h4>(.*?)</h4>(.*?)</container>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مميزة',url,591,'','','featured2')
		title = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,591,'','','details3')
		return
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<h4>(.*?)</h4>(.*?)</container>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		title,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	BBRwQhFnJ08q9YVxOSya = []
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if any(EYn2siOeDvQTk8KpS0Jl in title.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
		title = title.strip(' ')
		title = Nkuqp0boKj41i9(title)
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|حلقة).\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if '/movseries/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,591,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and type=='':
			title = '_MOD_'+XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,593,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,592,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,593,o3gHuBtrRN)
	if type=='filters':
		re8PLYqIQ6hN1vk503OTJng = T072lCzjYiuaeFtmJGV.findall('"more_button_page":(.*?),',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if re8PLYqIQ6hN1vk503OTJng:
			count = re8PLYqIQ6hN1vk503OTJng[0]
			i8sFwPqo1vpEXR2VdHU5BmW = url+'/offset/'+count
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة أخرى',i8sFwPqo1vpEXR2VdHU5BmW,591,'','','filters')
	elif 'details' in type:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = 'صفحة '+Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,591,'','','details4')
	return
def HNseQUBuMGwfXmRoqIkgjt5Z2V(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i80ehylRFvHDAbXBpkIr = False
	if not type:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<seasons(.*?)</seasons>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if len(items)>1:
				LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
				i80ehylRFvHDAbXBpkIr = True
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
					title = Nkuqp0boKj41i9(title)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,593,o3gHuBtrRN,'','episodes')
	if type=='episodes' or not i80ehylRFvHDAbXBpkIr:
		BB5dqMe8jgLxwSvk = T072lCzjYiuaeFtmJGV.findall('<bkز*?image:url\((.*?)\)"></bk>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if BB5dqMe8jgLxwSvk: o3gHuBtrRN = BB5dqMe8jgLxwSvk[0]
		else: o3gHuBtrRN = ''
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<all-episodes(.*?)</all-episodes>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				title = Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,592,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	MfIDplCLUGK91vjO,f9BQszg5ZIV1xeAjY,kk10UWmPHCF38aNVOdSpRIbQj6xE2 = [],[],[]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','FASELHD2-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ycfig7QNelWkS8Xm = T072lCzjYiuaeFtmJGV.findall('العمر :.*?<strong">(.*?)</strong>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ycfig7QNelWkS8Xm and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,ycfig7QNelWkS8Xm): return
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<iframe src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=__embed')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<slice-title(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-url="(.*?)".*?</i>(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			name = name.strip(' ')
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__watch')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<downloads(.*?)</downloads>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</div>(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__download')
	for U4PJWex3u72NlFXoO1fqAmh in MfIDplCLUGK91vjO:
		i8sFwPqo1vpEXR2VdHU5BmW,name = U4PJWex3u72NlFXoO1fqAmh.split('?named')
		if i8sFwPqo1vpEXR2VdHU5BmW not in f9BQszg5ZIV1xeAjY:
			f9BQszg5ZIV1xeAjY.append(i8sFwPqo1vpEXR2VdHU5BmW)
			kk10UWmPHCF38aNVOdSpRIbQj6xE2.append(U4PJWex3u72NlFXoO1fqAmh)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(kk10UWmPHCF38aNVOdSpRIbQj6xE2,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	LL2d9tanw0mrxJBKAT63buD = HbiLZQKalC
	url = LL2d9tanw0mrxJBKAT63buD+'/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'details5')
	return
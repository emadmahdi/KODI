# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
headers = { 'User-Agent' : '' }
nO6ukabcldeU = 'AKOAM'
JJCLnkX4TozH7Bsjivfe = '_AKO_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
ZpagQmfLTIM7F2PYOiK = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==70: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==71: cLCisPE3lX = QBJX6Z3vPmIVwUuCcnioMxYb47d(url)
	elif mode==72: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==73: cLCisPE3lX = my2ACY8kQwEhPTd4u7GKljLtDqi1sN(url)
	elif mode==74: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==79: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'سلسلة افلام','',79,'','','سلسلة افلام')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'سلاسل منوعة','',79,'','','سلسلة')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	OZYvGX7EMx05KH1fI = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','AKOAM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="partions"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title not in OZYvGX7EMx05KH1fI:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,71)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def QBJX6Z3vPmIVwUuCcnioMxYb47d(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,'','AKOAM-CATEGORIES-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('sect_parts(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,72)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'جميع الفروع',url,72)
	else: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'')
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('section_title featured_title(.*?)subjects-crousel',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='search':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('akoam_result(.*?)<script',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='more':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('section_title more_title(.*?)footer_bottom_services',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('navigation(.*?)<script',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items and tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = Nkuqp0boKj41i9(title)
		if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in ZpagQmfLTIM7F2PYOiK): QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,73,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,73,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall("</li><li >.*?href='(.*?)'>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,72,'','',type)
	return
def WW5QO8Frgw3sVakM(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('"href","(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = ll9khUfx3MjZ[1]
	return ll9khUfx3MjZ
def my2ACY8kQwEhPTd4u7GKljLtDqi1sN(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'AKOAM-SECTIONS-1st')
	u7OeoYDzs0E = T072lCzjYiuaeFtmJGV.findall('"(https*://akwam.net/\w+.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	v9KP62hiZD0yqzj = T072lCzjYiuaeFtmJGV.findall('"(https*://underurl.com/\w+.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if u7OeoYDzs0E or v9KP62hiZD0yqzj:
		if u7OeoYDzs0E: dCmKxk9BW310AXu4bJUHfY = u7OeoYDzs0E[0]
		elif v9KP62hiZD0yqzj: dCmKxk9BW310AXu4bJUHfY = WW5QO8Frgw3sVakM(v9KP62hiZD0yqzj[0])
		dCmKxk9BW310AXu4bJUHfY = rygO0TzuEdiPcQDWZ8awSjm(dCmKxk9BW310AXu4bJUHfY)
		import IqinpDkyKl
		if '/series/' in dCmKxk9BW310AXu4bJUHfY or '/shows/' in dCmKxk9BW310AXu4bJUHfY: IqinpDkyKl.UAB8vizclM6XG4Pw(dCmKxk9BW310AXu4bJUHfY)
		else: IqinpDkyKl.JwYEQUDupG2WLPzHndc(dCmKxk9BW310AXu4bJUHfY)
		return
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	items = T072lCzjYiuaeFtmJGV.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = Nkuqp0boKj41i9(title)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,73)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB:
		fYPz7RldWQVHBktZAexwvCL8Np3D('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,o3gHuBtrRN,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
		items = T072lCzjYiuaeFtmJGV.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	else:
		mArnKk8D7atliCTNyu64hHXP2F = T072lCzjYiuaeFtmJGV.findall('sub_file_title\'>(.*?) - <i>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		items = []
		for filename in mArnKk8D7atliCTNyu64hHXP2F:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	n7CuHMSJpiR9fP0jvNEIyDUL,plbcxFn8jBXKkzC = [],[]
	size = len(items)
	for title,filename in items:
		UuygfPcTR0zC = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: UuygfPcTR0zC = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		n7CuHMSJpiR9fP0jvNEIyDUL.append(title)
		plbcxFn8jBXKkzC.append(count)
		count += 1
	if size>0:
		if any(EYn2siOeDvQTk8KpS0Jl in name for EYn2siOeDvQTk8KpS0Jl in ZpagQmfLTIM7F2PYOiK):
			if size==1:
				tzgWIKy5xQL2kjm = 0
			else:
				tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الفيديو المناسب:', n7CuHMSJpiR9fP0jvNEIyDUL)
				if tzgWIKy5xQL2kjm == -1: return
			JwYEQUDupG2WLPzHndc(url+'?section='+str(1+plbcxFn8jBXKkzC[size-tzgWIKy5xQL2kjm-1]))
		else:
			for jV1Z7MWOa80gbwJY64nL5 in reversed(range(size)):
				title = name + ' - ' + n7CuHMSJpiR9fP0jvNEIyDUL[jV1Z7MWOa80gbwJY64nL5]
				title = title.replace('\n','').strip(' ')
				i8sFwPqo1vpEXR2VdHU5BmW = url + '?section='+str(size-jV1Z7MWOa80gbwJY64nL5)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,74,o3gHuBtrRN)
	else:
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+'الرابط ليس فيديو','',9999,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	ll9khUfx3MjZ,XSCYbwaqRBtopUc9H2QZu86gA5N = url.split('?section=')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	V0o1ZJwvCcpb5tdEBhk9GXO4IRe = tmEVko4qsghUX6WLx8KG7fOTB[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	V0o1ZJwvCcpb5tdEBhk9GXO4IRe = V0o1ZJwvCcpb5tdEBhk9GXO4IRe + 'direct_link_box'
	uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('epsoide_box(.*?)direct_link_box',V0o1ZJwvCcpb5tdEBhk9GXO4IRe,T072lCzjYiuaeFtmJGV.DOTALL)
	XSCYbwaqRBtopUc9H2QZu86gA5N = len(uuPG8BO037eSynUNE)-int(XSCYbwaqRBtopUc9H2QZu86gA5N)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = uuPG8BO037eSynUNE[XSCYbwaqRBtopUc9H2QZu86gA5N]
	MfIDplCLUGK91vjO = []
	ZPhbof6CeAt7gLsV3qKH1WpTr = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = T072lCzjYiuaeFtmJGV.findall("class='download_btn.*?href='(.*?)'",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW in items:
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=________akoam')
	items = T072lCzjYiuaeFtmJGV.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for w1waV3vpXzlsSBqMDQ,i8sFwPqo1vpEXR2VdHU5BmW in items:
		w1waV3vpXzlsSBqMDQ = w1waV3vpXzlsSBqMDQ.split('/')[-1]
		w1waV3vpXzlsSBqMDQ = w1waV3vpXzlsSBqMDQ.split('.')[0]
		if w1waV3vpXzlsSBqMDQ in ZPhbof6CeAt7gLsV3qKH1WpTr:
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+ZPhbof6CeAt7gLsV3qKH1WpTr[w1waV3vpXzlsSBqMDQ]+'________akoam')
		else: MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+w1waV3vpXzlsSBqMDQ+'________akoam')
	if not MfIDplCLUGK91vjO:
		message = T072lCzjYiuaeFtmJGV.findall('sub-no-file.*?\n(.*?)\n',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if message: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من الموقع الاصلي',message[0])
	else:
		import d3obAhVeNX
		d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','%20')
	url = HbiLZQKalC + '/search/'+xC2GuEcJKk3t4Uh
	cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
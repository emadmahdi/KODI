# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'EGYBEST4'
JJCLnkX4TozH7Bsjivfe = '_EB4_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,ffGe7cURW0lhJVvQAiw8IB,text):
	if   mode==800: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==801: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==802: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==803: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==804: cLCisPE3lX = Zpf05iQWjnIOw(url)
	elif mode==806: cLCisPE3lX = HNseQUBuMGwfXmRoqIkgjt5Z2V(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==809: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر',HbiLZQKalC+'/trending',804,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','EGYBEST4-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('nav-categories(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('mainContent(.*?)<footer>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801,'','mainmenu')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('main-menu(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.strip(' ')
			if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def HNseQUBuMGwfXmRoqIkgjt5Z2V(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('mainTitle.*?>(.*?)<(.*?)pageContent',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		i80ehylRFvHDAbXBpkIr,Ad5sCEYHjxzg3yK,items = '','',[]
		for name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			if 'حلقات' in name: Ad5sCEYHjxzg3yK = Zsh7mUdwjHobLyMz6WKJGVl1cgeR
			if 'مواسم' in name: i80ehylRFvHDAbXBpkIr = Zsh7mUdwjHobLyMz6WKJGVl1cgeR
		if i80ehylRFvHDAbXBpkIr and not type:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',i80ehylRFvHDAbXBpkIr,T072lCzjYiuaeFtmJGV.DOTALL)
			if len(items)>1:
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,806,o3gHuBtrRN,'season')
		if Ad5sCEYHjxzg3yK and len(items)<2:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Ad5sCEYHjxzg3yK,T072lCzjYiuaeFtmJGV.DOTALL)
			if items:
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,803,o3gHuBtrRN)
			else:
				items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Ad5sCEYHjxzg3yK,T072lCzjYiuaeFtmJGV.DOTALL)
				for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
					QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,803)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	cd9Um4xeAzgvZBPTjIithDqa7,start,zgs5N10mMd9PVTRuHA4GWJDycpeLl,select,GGMtXDqi57IaEW2FSeulNzkmJ8 = 0,0,'','',''
	if 'pagination' in type:
		xc2ltn65KjUez,vf78LSlJQOnCsatrIH2P1iW = url.split('?next=page&')
		JKf4Tsxu9S23FI7mV5DGLk = {'Content-Type':'application/x-www-form-urlencoded'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',xc2ltn65KjUez,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','EGYBEST4-TITLES-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = 'secContent'+qQXuaKpVrGLF3e5oidJ8YwDT0+'<footer>'
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = qQXuaKpVrGLF3e5oidJ8YwDT0
	items,x2dbytYP1qriwCmTc,RowfG8LnD9IvTg34Ue2WVbBXa0O5u = [],False,False
	if not type and '/collections' not in url:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('mainContent(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801,'','submenu')
				x2dbytYP1qriwCmTc = True
	if not x2dbytYP1qriwCmTc:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('secContent(.*?)mainContent',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
				o3gHuBtrRN = o3gHuBtrRN.strip('\n')
				title = Nkuqp0boKj41i9(title)
				if '/series/' in i8sFwPqo1vpEXR2VdHU5BmW and type=='season': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,806,o3gHuBtrRN,'season')
				elif '/series/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,806,o3gHuBtrRN)
				elif '/seasons/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801,o3gHuBtrRN,'season')
				elif '/collections' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801,o3gHuBtrRN,'collections')
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,803,o3gHuBtrRN)
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('loadMoreParams = (.*?);',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			A7cSC2V4hLItdMglP = cwiLy4IAVJj0pWCl7FGxokR('dict',Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
			GGMtXDqi57IaEW2FSeulNzkmJ8 = A7cSC2V4hLItdMglP['ajaxurl']
			re8PLYqIQ6hN1vk503OTJng = int(A7cSC2V4hLItdMglP['current_page'])+1
			ywfmWsk9I6uoX3 = int(A7cSC2V4hLItdMglP['max_page'])
			SjQtnblRTVMoqzLEwixGu8e9C2 = A7cSC2V4hLItdMglP['posts'].replace('False','false').replace('True','true').replace('None','null')
			if re8PLYqIQ6hN1vk503OTJng<ywfmWsk9I6uoX3:
				vf78LSlJQOnCsatrIH2P1iW = 'action=loadmore&query='+K3PukgCEDY(SjQtnblRTVMoqzLEwixGu8e9C2,'')+'&page='+str(re8PLYqIQ6hN1vk503OTJng)
				ll9khUfx3MjZ = GGMtXDqi57IaEW2FSeulNzkmJ8+'?next=page&'+vf78LSlJQOnCsatrIH2P1iW
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'جلب المزيد',ll9khUfx3MjZ,801,'','pagination_'+type)
		elif '?next=page&' in url:
			vf78LSlJQOnCsatrIH2P1iW,KhRP2beyNfv = vf78LSlJQOnCsatrIH2P1iW.rsplit('=',1)
			KhRP2beyNfv = int(KhRP2beyNfv)+1
			ll9khUfx3MjZ = xc2ltn65KjUez+'?next=page&'+vf78LSlJQOnCsatrIH2P1iW+'='+str(KhRP2beyNfv)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'جلب المزيد',ll9khUfx3MjZ,801,'','pagination_'+type)
	return
def Zpf05iQWjnIOw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('sub_nav(.*?)secContent ',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('"current_opt">(.*?)<(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,EYn2siOeDvQTk8KpS0Jl in items:
				title = name+':  '+EYn2siOeDvQTk8KpS0Jl
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,801,'','filter')
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('<td>التصنيف</td>.*?">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	MfIDplCLUGK91vjO,lmsz7vjDrfqH5XhJ1CY = [],[]
	mdqDWPQYu4iBHswMZ5rFE = T072lCzjYiuaeFtmJGV.findall('postEmbed.*?post=(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if mdqDWPQYu4iBHswMZ5rFE:
		kkH5sRPxhASFowLONy4 = eJ4h7nOpguFMH6z1IUEV2i.b64decode(mdqDWPQYu4iBHswMZ5rFE[0])
		if mmIKCGujwM: kkH5sRPxhASFowLONy4 = kkH5sRPxhASFowLONy4.decode('utf8')
		kkH5sRPxhASFowLONy4 = cwiLy4IAVJj0pWCl7FGxokR('dict',kkH5sRPxhASFowLONy4)
		kkH5sRPxhASFowLONy4 = list(kkH5sRPxhASFowLONy4.values())
		for i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
			if i8sFwPqo1vpEXR2VdHU5BmW not in lmsz7vjDrfqH5XhJ1CY:
				lmsz7vjDrfqH5XhJ1CY.append(i8sFwPqo1vpEXR2VdHU5BmW)
				dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__watch')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('pageContentDown(.*?)</table>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for Q5OAspyiXV1lx8930qLGD,i8sFwPqo1vpEXR2VdHU5BmW in items:
			if i8sFwPqo1vpEXR2VdHU5BmW not in lmsz7vjDrfqH5XhJ1CY:
				if '/?url=' in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('/?url=')[1]
				lmsz7vjDrfqH5XhJ1CY.append(i8sFwPqo1vpEXR2VdHU5BmW)
				dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'__download____'+Q5OAspyiXV1lx8930qLGD)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search: search = NWs7KpjXGnxYylofHtd5U3wDh()
	if not search: return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	url = HbiLZQKalC+'/?s='+xC2GuEcJKk3t4Uh
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
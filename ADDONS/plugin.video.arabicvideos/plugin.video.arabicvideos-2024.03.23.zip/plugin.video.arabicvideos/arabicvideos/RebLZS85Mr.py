# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'MOVS4U'
JJCLnkX4TozH7Bsjivfe = '_M4U_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['انواع افلام','جودات افلام']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==380: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==381: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==382: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==383: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==389: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',HbiLZQKalC,381,'','','featured')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الجانبية',HbiLZQKalC,381,'','','sider')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','MOVS4U-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('<header>.*?<h2>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for F1FBMcYyaNIJ in range(len(items)):
		title = items[F1FBMcYyaNIJ]
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,HbiLZQKalC,381,'','','latest'+str(F1FBMcYyaNIJ))
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = ''
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu"(.*?)id="contenedor"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR += tmEVko4qsghUX6WLx8KG7fOTB[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="sidebar(.*?)aside',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR += tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ye8iWwASlpUFt = True
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = Nkuqp0boKj41i9(title)
		if title=='الأعلى مشاهدة':
			if ye8iWwASlpUFt:
				title = 'الافلام '+title
				ye8iWwASlpUFt = False
			else: title = 'المسلسلات '+title
		if title not in OZYvGX7EMx05KH1fI:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,381)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type):
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR,items = [],[]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','MOVS4U-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if type=='search':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="search-page"(.*?)class="sidebar',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='sider':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="widget(.*?)class="widget',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		ERgevjTpn4dKMB = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		M7oS6tLhdx3ke8qPX4mFA,jxEQ2Yd01g9MSuDVJ,n7CuHMSJpiR9fP0jvNEIyDUL = zip(*ERgevjTpn4dKMB)
		items = zip(jxEQ2Yd01g9MSuDVJ,M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL)
	elif type=='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="slider-movies-tvshows"(.*?)<header>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif 'latest' in type:
		F1FBMcYyaNIJ = int(type[-1:])
		qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('<header>','<end><start>')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('<div class="sidebar','<end><div class="sidebar')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<start>(.*?)<end>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[F1FBMcYyaNIJ]
		if F1FBMcYyaNIJ==2: items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="content"(.*?)class="(pagination|sidebar)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
			if '/collection/' in url:
				items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			elif '/quality/' in url:
				items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items and Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
		items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if 'serie' in title:
			title = T072lCzjYiuaeFtmJGV.findall('^(.*?)<.*?serie">(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
			title = title[0][1]
			if title in BBRwQhFnJ08q9YVxOSya: continue
			BBRwQhFnJ08q9YVxOSya.append(title)
			title = '_MOD_'+title
		tKBSN4Zgn9CDb = T072lCzjYiuaeFtmJGV.findall('^(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if tKBSN4Zgn9CDb: title = tKBSN4Zgn9CDb[0]
		title = Nkuqp0boKj41i9(title)
		if '/tvshows/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,383,o3gHuBtrRN)
		elif '/episodes/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,383,o3gHuBtrRN)
		elif '/seasons/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,383,o3gHuBtrRN)
		elif '/collection/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,381,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,382,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		TMrSqo2OQ931J8g4kVwszf5imDW = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		t5shZ0rc8gi4BC2uJ6fy = tmEVko4qsghUX6WLx8KG7fOTB[0][1]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][2]
		items = T072lCzjYiuaeFtmJGV.findall("href='(.*?)'.*?>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if title=='' or title==t5shZ0rc8gi4BC2uJ6fy: continue
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,381,'','',type)
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('/page/'+title+'/','/page/'+t5shZ0rc8gi4BC2uJ6fy+'/')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اخر صفحة '+t5shZ0rc8gi4BC2uJ6fy,i8sFwPqo1vpEXR2VdHU5BmW,381,'','',type)
	return
def UAB8vizclM6XG4Pw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('class="C rated".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl,False):
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('''class='item'><a href="(.*?)"''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if ll9khUfx3MjZ:
			ll9khUfx3MjZ = ll9khUfx3MjZ[1]
			UAB8vizclM6XG4Pw(ll9khUfx3MjZ)
			return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('''class='episodios'(.*?)id="cast"''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for o3gHuBtrRN,XSCYbwaqRBtopUc9H2QZu86gA5N,i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			title = XSCYbwaqRBtopUc9H2QZu86gA5N+' : '+name+' الحلقة'
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,382)
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','MOVS4U-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('class="C rated".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	M7oS6tLhdx3ke8qPX4mFA = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		items = T072lCzjYiuaeFtmJGV.findall("data-url='(.*?)'.*?class='server'>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="remodal"(.*?)class="remodal-close"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
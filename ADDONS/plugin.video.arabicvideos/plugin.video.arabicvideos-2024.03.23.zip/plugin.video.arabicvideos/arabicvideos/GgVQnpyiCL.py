﻿# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'ALMAAREF'
headers = {'User-Agent':''}
JJCLnkX4TozH7Bsjivfe = '_MRF_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text,ffGe7cURW0lhJVvQAiw8IB):
	if   mode==40: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==41: cLCisPE3lX = Dzi0rPWaLn45GIfdCy762()
	elif mode==42: cLCisPE3lX = xVIU9JCSBp(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==43: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==44: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(text,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==49: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'البث الحي لقناة المعارف','',41)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',49)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xVIU9JCSBp('','1')
	return
def MMVma2fkPlUJCOWuoj4FG(ZNpFGHa28C9WcoRb,Sm3Nrfu4Y8wtdlovb6yCWLQaIpO):
	search,sort,GJL1Ps7XWte3hjTy5ckDrZonFYAlp,ZecS1yJOzVutgX0qiH3NER,CjoDwBYx4OdgyLc1Zu89NAUsM6 = '',[],[],[],[]
	O578ENGbr6PYnLJzi,U5elrTZ2jYJKuc9D640Xkn = y2dmjAuhlfboLe(ZNpFGHa28C9WcoRb)
	for jwanU8orZtdFLNvM4EkHphWKzP in list(U5elrTZ2jYJKuc9D640Xkn.keys()):
		EYn2siOeDvQTk8KpS0Jl = U5elrTZ2jYJKuc9D640Xkn[jwanU8orZtdFLNvM4EkHphWKzP]
		if not EYn2siOeDvQTk8KpS0Jl: continue
		if   jwanU8orZtdFLNvM4EkHphWKzP=='sort': sort = [EYn2siOeDvQTk8KpS0Jl]
		elif jwanU8orZtdFLNvM4EkHphWKzP=='series': GJL1Ps7XWte3hjTy5ckDrZonFYAlp = [EYn2siOeDvQTk8KpS0Jl]
		elif jwanU8orZtdFLNvM4EkHphWKzP=='search': search = EYn2siOeDvQTk8KpS0Jl
		elif jwanU8orZtdFLNvM4EkHphWKzP=='category': ZecS1yJOzVutgX0qiH3NER = [EYn2siOeDvQTk8KpS0Jl]
		elif jwanU8orZtdFLNvM4EkHphWKzP=='specialist': CjoDwBYx4OdgyLc1Zu89NAUsM6 = [EYn2siOeDvQTk8KpS0Jl]
	y7PU6am9Z3I = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":ZecS1yJOzVutgX0qiH3NER,"specialist":CjoDwBYx4OdgyLc1Zu89NAUsM6,"series":GJL1Ps7XWte3hjTy5ckDrZonFYAlp,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(Sm3Nrfu4Y8wtdlovb6yCWLQaIpO)}}
	import json as ZcJHDYM7OuKkIhBVSzoxgjp8r
	y7PU6am9Z3I = ZcJHDYM7OuKkIhBVSzoxgjp8r.dumps(y7PU6am9Z3I)
	i8sFwPqo1vpEXR2VdHU5BmW = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',i8sFwPqo1vpEXR2VdHU5BmW,y7PU6am9Z3I,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	data = cwiLy4IAVJj0pWCl7FGxokR('dict',qQXuaKpVrGLF3e5oidJ8YwDT0)
	return data
def xVIU9JCSBp(ZNpFGHa28C9WcoRb,level):
	uuPG8BO037eSynUNE = MMVma2fkPlUJCOWuoj4FG(ZNpFGHa28C9WcoRb,'1')
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = uuPG8BO037eSynUNE['facets']
	if level=='1':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['video_categories']
		items = T072lCzjYiuaeFtmJGV.findall('<div(.*?)/div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',Lw8JjEfuiW0VN9qHAcgRpMBdICS+'<',T072lCzjYiuaeFtmJGV.DOTALL)
			if not mnN8GgS1XEePILK0DC49qky6UzZ: mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('data-value=\\"(.*?)\\">(.*?)<',Lw8JjEfuiW0VN9qHAcgRpMBdICS+'<',T072lCzjYiuaeFtmJGV.DOTALL)
			ZecS1yJOzVutgX0qiH3NER,title = mnN8GgS1XEePILK0DC49qky6UzZ[0]
			if not ZNpFGHa28C9WcoRb: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,'',42,'','2','?category='+ZecS1yJOzVutgX0qiH3NER)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,'',42,'','2',ZNpFGHa28C9WcoRb+'&category='+ZecS1yJOzVutgX0qiH3NER)
	if level=='2':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['specialist']
		items = T072lCzjYiuaeFtmJGV.findall('value="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for CjoDwBYx4OdgyLc1Zu89NAUsM6,title in items:
			if not CjoDwBYx4OdgyLc1Zu89NAUsM6: title = title = 'الجميع'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,'',42,'','3',ZNpFGHa28C9WcoRb+'&specialist='+CjoDwBYx4OdgyLc1Zu89NAUsM6)
	elif level=='3':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['series']
		items = T072lCzjYiuaeFtmJGV.findall('value="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for GJL1Ps7XWte3hjTy5ckDrZonFYAlp,title in items:
			if not GJL1Ps7XWte3hjTy5ckDrZonFYAlp: title = title = 'الجميع'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,'',42,'','4',ZNpFGHa28C9WcoRb+'&series='+GJL1Ps7XWte3hjTy5ckDrZonFYAlp)
	elif level=='4':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR['sort_video']
		items = T072lCzjYiuaeFtmJGV.findall('value="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for sort,title in items:
			if not sort: continue
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,'',44,'','1',ZNpFGHa28C9WcoRb+'&sort='+sort)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(ZNpFGHa28C9WcoRb,Sm3Nrfu4Y8wtdlovb6yCWLQaIpO):
	uuPG8BO037eSynUNE = MMVma2fkPlUJCOWuoj4FG(ZNpFGHa28C9WcoRb,Sm3Nrfu4Y8wtdlovb6yCWLQaIpO)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = uuPG8BO037eSynUNE['template']
	items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,43,o3gHuBtrRN)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = uuPG8BO037eSynUNE['facets']['pagination']
	items = T072lCzjYiuaeFtmJGV.findall('data-page="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for ffGe7cURW0lhJVvQAiw8IB,title in items:
		if Sm3Nrfu4Y8wtdlovb6yCWLQaIpO==ffGe7cURW0lhJVvQAiw8IB: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,'',44,'',ffGe7cURW0lhJVvQAiw8IB,ZNpFGHa28C9WcoRb)
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<video src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('youtube_url.*?(http.*?)&',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	MfIDplCLUGK91vjO = []
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0].replace('\/','/')
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def Dzi0rPWaLn45GIfdCy762():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	url = rygO0TzuEdiPcQDWZ8awSjm(items[0])
	pidYDcjvhgVfqb3GeWSAOH5J(url,nO6ukabcldeU,'live')
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	vYxH0LmAJdcoO94wy7zTk3 = False
	if search=='':
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		vYxH0LmAJdcoO94wy7zTk3 = True
	if search=='': return
	if not vYxH0LmAJdcoO94wy7zTk3: Dhm1GLpdYu4xwZzSQlEtvNC3ga('?search='+search,'1')
	else: xVIU9JCSBp('?search='+search,'1')
	return
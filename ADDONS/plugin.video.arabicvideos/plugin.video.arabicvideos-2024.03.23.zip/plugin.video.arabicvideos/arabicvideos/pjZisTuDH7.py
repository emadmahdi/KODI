# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
import xbmc as EO9Rts0AaGuk1qpPLXCY,re as T072lCzjYiuaeFtmJGV,sys as CJwTBit4NPQMu,xbmcaddon as zzWKEDg14fbwQ5X7G,random as XIjYJW8qbtv63,os as isWjwHOERYXhAp0ZuNdKUgkCM7,xbmcvfs as lYmjeUrHgx1RDWzLN,time as D1vBJgya85Yh4cRTCkIMKtWLSeH,pickle as gBUfVK5GtLjhD0,zlib as VVZfqbyzauDFwc1KCx3PEjhk7sm6i,xbmcgui as Ko1p5u9jwG6rF,xbmcplugin as I2XjYiNOlmyKG1EhR70q53vZ,sqlite3 as EVGFixbHrhvCo67OtpYmnWa3Dy8NSA,traceback as uz8Hlh4InqK7v0S6eQryomEjgb,threading as RZxCcFI8fw31NKP
nO6ukabcldeU = EmK3ObA0cwv9Wy(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
mmry7DBuMdxCOPkeA = zzWKEDg14fbwQ5X7G.Addon().getAddonInfo(TWexH5PhS1(u"ࠬࡶࡡࡵࡪࠪ਱"))
PyobIkGOsRdTn8K04wYrpzqcZ5Si = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(mmry7DBuMdxCOPkeA,VH9MDo5z1kxNF07uRJI(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
CJwTBit4NPQMu.path.append(PyobIkGOsRdTn8K04wYrpzqcZ5Si)
wK1R0Up3rH = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
XK3HqaTnjpyIAuhw67CmdvBM = T072lCzjYiuaeFtmJGV.findall(HVibA2ES8lY(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),wK1R0Up3rH,T072lCzjYiuaeFtmJGV.DOTALL)
XK3HqaTnjpyIAuhw67CmdvBM = float(XK3HqaTnjpyIAuhw67CmdvBM[HH4JMrUDp3lq6hQ(u"࠱௴")])
BS1y8diLjcY6mbFszV450n2UEgq = EO9Rts0AaGuk1qpPLXCY.Player
awRv8kI51963jzSpLAUNb = Ko1p5u9jwG6rF.WindowXMLDialog
ggl6zFuXNdYTDieHCqGKRnVx = XK3HqaTnjpyIAuhw67CmdvBM<f5uqIoSJzWBOFyrY78RXmVb(u"࠳࠼௵")
mmIKCGujwM = XK3HqaTnjpyIAuhw67CmdvBM>sbgu4D2RFMYKm(u"࠴࠼࠳࠿࠹௶")
if mmIKCGujwM:
	qfIh09cCd6 = EO9Rts0AaGuk1qpPLXCY.LOGINFO
	sfquhCGUwdvRl96izX,zWyErX8YHiLsemj9G6lb2p1 = TWexH5PhS1(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	fOHib3V2YaBGQJcRIS6tnCL8wFMWK = lYmjeUrHgx1RDWzLN.translatePath(vatyjK4hHAoZJ7rOq2lis(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _GtUsQIaoESBrKyb1Zz
else:
	qfIh09cCd6 = EO9Rts0AaGuk1qpPLXCY.LOGNOTICE
	sfquhCGUwdvRl96izX,zWyErX8YHiLsemj9G6lb2p1 = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࡵࡵࡨ࠻ࠫਹ")),uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(ttOu147wErcBvPaSMUY(u"ࠨࡷࡷࡪ࠽࠭਻"))
	fOHib3V2YaBGQJcRIS6tnCL8wFMWK = EO9Rts0AaGuk1qpPLXCY.translatePath(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _GtUsQIaoESBrKyb1Zz
p2TglCv9raVJxSMBUi0em = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠺࠵௷")
fxunVecQRNTGHb2LJtkBylF5 = TWexH5PhS1(u"࠻࠶௸")*p2TglCv9raVJxSMBUi0em
pyLSeGvtZu = WmaPChRdQk3YcXwI6zS(u"࠸࠴௹")*fxunVecQRNTGHb2LJtkBylF5
YYkWNTsxe42b9B71O3CXFymwUP = N0Kvne8UYar9fhRxboWsXJCVzid(u"࠳࠱௺")*pyLSeGvtZu
GGXxhdg3JCamPIFepybjZ = TWexH5PhS1(u"࠲࠸௻")*fxunVecQRNTGHb2LJtkBylF5
CC89Q23uNDmIKWHAs = EEvLoMzFqrlKce(u"࠵௼")*pyLSeGvtZu
U6y1OBwzfkEuRGVNrpYFv = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠴࠶௽")*YYkWNTsxe42b9B71O3CXFymwUP
x7NwSuz5ft4e = CJwTBit4NPQMu.argv[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠴௾")].split(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪ࠳ࠬ਽"))[g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠷௿")]
SMfClzGKOB12H3r9sRPvAJgwq6 = int(CJwTBit4NPQMu.argv[ZhqJoOtcmTVID65HwnLj(u"࠷ఀ")])
pyDQJ34XlhL6OmuoPk5UvSjN08MVG = CJwTBit4NPQMu.argv[sDiKwnHcSlYFgWCy1Ak(u"࠲ఁ")]
usnfCHyeoaSbh2JWR = x7NwSuz5ft4e.split(f5uqIoSJzWBOFyrY78RXmVb(u"ࠫ࠳࠭ਾ"))[WmaPChRdQk3YcXwI6zS(u"࠳ం")]
pQmoyUJBNaf72A = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(HH4JMrUDp3lq6hQ(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+x7NwSuz5ft4e+mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭ࠩࠨੀ"))
jNhH3xrnWkFUqv8c09OybXRTl = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(fOHib3V2YaBGQJcRIS6tnCL8wFMWK,x7NwSuz5ft4e)
ttbwouYhASpBDJiHZEaLkegM3G = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
oQjDxLF9fdtyCaJ5ZTO860ri1s = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
EEd0FZyfticlDPAMp2HbNesx = int(D1vBJgya85Yh4cRTCkIMKtWLSeH.time())
YTPut68WBVUNCvsEzg = zzWKEDg14fbwQ5X7G.Addon(id=x7NwSuz5ft4e)
def y2dmjAuhlfboLe(gz1flZwncVutokL59RaGS3WeK,rDZWqIkJl5ywX1iO37gBo4YcLjn=S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡂࠫ੃")):
	if sDiKwnHcSlYFgWCy1Ak(u"ࠪࡁࠬ੄") in gz1flZwncVutokL59RaGS3WeK:
		if rDZWqIkJl5ywX1iO37gBo4YcLjn in gz1flZwncVutokL59RaGS3WeK: ll9khUfx3MjZ,mxwA6kplHejX8P = gz1flZwncVutokL59RaGS3WeK.split(rDZWqIkJl5ywX1iO37gBo4YcLjn,WmaPChRdQk3YcXwI6zS(u"࠳ః"))
		else: ll9khUfx3MjZ,mxwA6kplHejX8P = sbgu4D2RFMYKm(u"ࠫࠬ੅"),gz1flZwncVutokL59RaGS3WeK
		mxwA6kplHejX8P = mxwA6kplHejX8P.split(WmaPChRdQk3YcXwI6zS(u"ࠬࠬࠧ੆"))
		vf78LSlJQOnCsatrIH2P1iW = {}
		for bbf0AtuBPHXJFhpWq in mxwA6kplHejX8P:
			TRBlwxbQJUZaKL1s86SIAze,qqk6TvmXIdJAxi9t1MDaz = bbf0AtuBPHXJFhpWq.split(ttOu147wErcBvPaSMUY(u"࠭࠽ࠨੇ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠴ఄ"))
			vf78LSlJQOnCsatrIH2P1iW[TRBlwxbQJUZaKL1s86SIAze] = qqk6TvmXIdJAxi9t1MDaz
	else: ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = gz1flZwncVutokL59RaGS3WeK,{}
	return ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW
def rygO0TzuEdiPcQDWZ8awSjm(gz1flZwncVutokL59RaGS3WeK):
	return _GtUsQIaoESBrKyb1Zz(gz1flZwncVutokL59RaGS3WeK)
def LsBXYAO5g8fyu0iPkV9(NyAFspmIO8z):
	nT7LroB259x8NlJhQ60Fsjb3XwSRk = {VOq8Ekue4F(u"ࠧࡵࡻࡳࡩࠬੈ"):g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠩ੉"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡰࡳࡩ࡫ࠧ੊"):FIHNSc5iuoZanQ2Ytl(u"ࠪࠫੋ"),HH4JMrUDp3lq6hQ(u"ࠫࡺࡸ࡬ࠨੌ"):VOq8Ekue4F(u"੍ࠬ࠭"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡴࡦࡺࡷࠫ੎"):HH4JMrUDp3lq6hQ(u"ࠧࠨ੏"),ZEiR0StquOzca9lvPAndYIX(u"ࠨࡲࡤ࡫ࡪ࠭੐"):HH4JMrUDp3lq6hQ(u"ࠩࠪੑ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠪࡲࡦࡳࡥࠨ੒"):N9olEh0ZMtpOivVfBLK(u"ࠫࠬ੓"),VH9MDo5z1kxNF07uRJI(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࠧ੕"),sDiKwnHcSlYFgWCy1Ak(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):PiFkQ5pCJy7fbX(u"ࠨࠩ੗"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠪࠫਖ਼")}
	if weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠫࡄ࠭ਗ਼") in NyAFspmIO8z: NyAFspmIO8z = NyAFspmIO8z.split(sbgu4D2RFMYKm(u"ࠬࡅࠧਜ਼"),FIHNSc5iuoZanQ2Ytl(u"࠵అ"))[FIHNSc5iuoZanQ2Ytl(u"࠵అ")]
	ll9khUfx3MjZ,ff0cpz7UhIlQFDATV = y2dmjAuhlfboLe(NyAFspmIO8z)
	aargs = dict(list(nT7LroB259x8NlJhQ60Fsjb3XwSRk.items())+list(ff0cpz7UhIlQFDATV.items()))
	LpFs39kBG4KDqAQ16t8mYe5v = aargs[QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭࡭ࡰࡦࡨࠫੜ")]
	ZZ6GOtiQdngANT = rygO0TzuEdiPcQDWZ8awSjm(aargs[oAXJCYqPgyGDtT(u"ࠧࡶࡴ࡯ࠫ੝")])
	jdyz6niLR94Hx = rygO0TzuEdiPcQDWZ8awSjm(aargs[HVibA2ES8lY(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	wKQdIUxYCPvh9fkTleu = rygO0TzuEdiPcQDWZ8awSjm(aargs[EmK3ObA0cwv9Wy(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	NeAPH6nUIXcCskioGTO87 = rygO0TzuEdiPcQDWZ8awSjm(aargs[sbgu4D2RFMYKm(u"ࠪࡸࡾࡶࡥࠨ੠")])
	M2WHwz4yUIF = rygO0TzuEdiPcQDWZ8awSjm(aargs[vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	LEITsRo5fbG3 = rygO0TzuEdiPcQDWZ8awSjm(aargs[ZhqJoOtcmTVID65HwnLj(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	VV8quHYD2SZxs = aargs[WmaPChRdQk3YcXwI6zS(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	oWGHs0vkTKb97X1m6iPAU = rygO0TzuEdiPcQDWZ8awSjm(aargs[ZhqJoOtcmTVID65HwnLj(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if oWGHs0vkTKb97X1m6iPAU: oWGHs0vkTKb97X1m6iPAU = eval(oWGHs0vkTKb97X1m6iPAU)
	else: oWGHs0vkTKb97X1m6iPAU = {}
	if not LpFs39kBG4KDqAQ16t8mYe5v: NeAPH6nUIXcCskioGTO87 = FIHNSc5iuoZanQ2Ytl(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; LpFs39kBG4KDqAQ16t8mYe5v = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩ࠵࠺࠵࠭੦")
	return NeAPH6nUIXcCskioGTO87,M2WHwz4yUIF,ZZ6GOtiQdngANT,LpFs39kBG4KDqAQ16t8mYe5v,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,jdyz6niLR94Hx,VV8quHYD2SZxs,oWGHs0vkTKb97X1m6iPAU
def G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU):
	bnmHfZjwQu86VxpldRghG937zyXN = CJwTBit4NPQMu._getframe(WmaPChRdQk3YcXwI6zS(u"࠶ఆ")).f_code.co_name
	if not nO6ukabcldeU or not bnmHfZjwQu86VxpldRghG937zyXN or bnmHfZjwQu86VxpldRghG937zyXN==ZhqJoOtcmTVID65HwnLj(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return HH4JMrUDp3lq6hQ(u"ࠫࡠࠦࠧ੨")+usnfCHyeoaSbh2JWR.upper()+HVibA2ES8lY(u"ࠬ࠳ࠧ੩")+pQmoyUJBNaf72A+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭࠭ࠨ੪")+str(XK3HqaTnjpyIAuhw67CmdvBM)+HH4JMrUDp3lq6hQ(u"ࠧࠡ࡟ࠪ੫")
	return f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ࠰ࠣࠤࠬ੬")+bnmHfZjwQu86VxpldRghG937zyXN
def GZvEITHSg5U3rVwQ(ujFbU7CdDch,kg1pK9CEwGaTI0ReMP4crBL8tshHy):
	if ggl6zFuXNdYTDieHCqGKRnVx: kg1pK9CEwGaTI0ReMP4crBL8tshHy = kg1pK9CEwGaTI0ReMP4crBL8tshHy.decode(ZhqJoOtcmTVID65HwnLj(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	V9rRebhB8M47SyjKp2dWFwUPA05T = qfIh09cCd6
	SXOJtRiHqaUFCp2e = [sbgu4D2RFMYKm(u"ࠫࠬ੯"),TWexH5PhS1(u"ࠬ࠭ੰ")]
	if ujFbU7CdDch: kg1pK9CEwGaTI0ReMP4crBL8tshHy = kg1pK9CEwGaTI0ReMP4crBL8tshHy.replace(cbngtp9sqYi0DjeEMLRHJruKxm(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),HH4JMrUDp3lq6hQ(u"ࠧࠨੲ")).replace(f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),vatyjK4hHAoZJ7rOq2lis(u"ࠩࠪੴ")).replace(l5mQdjWyczr7UJVnTp(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),oAXJCYqPgyGDtT(u"ࠫࠬ੶"))
	else: ujFbU7CdDch = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	A6bztufEaYNThpJ7v2RqKQDrsk,rDZWqIkJl5ywX1iO37gBo4YcLjn,TGWmQq0OdBPzIAD8lJcpNorwga = VH9MDo5z1kxNF07uRJI(u"࠭ࠠࠡࠢࠣࠫ੸"),ZhqJoOtcmTVID65HwnLj(u"ࠧࠡࠢࠣࠫ੹"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠨࠩ੺")
	if g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in ujFbU7CdDch: V9rRebhB8M47SyjKp2dWFwUPA05T = EO9Rts0AaGuk1qpPLXCY.LOGERROR
	if ujFbU7CdDch==WmaPChRdQk3YcXwI6zS(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		kg1pK9CEwGaTI0ReMP4crBL8tshHy = kg1pK9CEwGaTI0ReMP4crBL8tshHy+rDZWqIkJl5ywX1iO37gBo4YcLjn
		SXOJtRiHqaUFCp2e = kg1pK9CEwGaTI0ReMP4crBL8tshHy.split(rDZWqIkJl5ywX1iO37gBo4YcLjn)
		TGWmQq0OdBPzIAD8lJcpNorwga = A6bztufEaYNThpJ7v2RqKQDrsk
	elif ujFbU7CdDch==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		kg1pK9CEwGaTI0ReMP4crBL8tshHy = kg1pK9CEwGaTI0ReMP4crBL8tshHy.replace(EEvLoMzFqrlKce(u"ࠬ࠴ࠧ੾")+rDZWqIkJl5ywX1iO37gBo4YcLjn,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭࠮ࠡࠢࠪ੿"))
		SXOJtRiHqaUFCp2e = kg1pK9CEwGaTI0ReMP4crBL8tshHy.split(rDZWqIkJl5ywX1iO37gBo4YcLjn)
		SXOJtRiHqaUFCp2e[l5mQdjWyczr7UJVnTp(u"࠰ఈ")] = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧ࠯ࠩ઀")+SXOJtRiHqaUFCp2e[l5mQdjWyczr7UJVnTp(u"࠰ఈ")][vatyjK4hHAoZJ7rOq2lis(u"࠷ఇ"):]
		TGWmQq0OdBPzIAD8lJcpNorwga = A6bztufEaYNThpJ7v2RqKQDrsk+rDZWqIkJl5ywX1iO37gBo4YcLjn
	elif ujFbU7CdDch in [oAXJCYqPgyGDtT(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡈࡖࡗࡕࡒࠨં")]: SXOJtRiHqaUFCp2e = kg1pK9CEwGaTI0ReMP4crBL8tshHy.split(A6bztufEaYNThpJ7v2RqKQDrsk)
	TGWmQq0OdBPzIAD8lJcpNorwga += ttOu147wErcBvPaSMUY(u"࠷ఉ")*A6bztufEaYNThpJ7v2RqKQDrsk
	ooBHbA5RkDUf = ttOu147wErcBvPaSMUY(u"࠵ఊ")*A6bztufEaYNThpJ7v2RqKQDrsk
	if XK3HqaTnjpyIAuhw67CmdvBM>cbngtp9sqYi0DjeEMLRHJruKxm(u"࠵࠼࠴࠹࠺ఌ"): TGWmQq0OdBPzIAD8lJcpNorwga += WmaPChRdQk3YcXwI6zS(u"࠴࠵ఋ")*weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠤࠬઃ")
	faOproKHmhWuM9vPkI5LwR0F3 = SXOJtRiHqaUFCp2e[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠵఍")]
	for TTjZMRAUezcia in SXOJtRiHqaUFCp2e[l5mQdjWyczr7UJVnTp(u"࠷ఎ"):]:
		if QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࡡࡴࠧ઄") in TTjZMRAUezcia: TTjZMRAUezcia = TTjZMRAUezcia.replace(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬࡢ࡮ࠨઅ"),h5huy6MiXPNfQJF8(u"࠭࡜࡯ࠩઆ")+A6bztufEaYNThpJ7v2RqKQDrsk+A6bztufEaYNThpJ7v2RqKQDrsk)
		ooBHbA5RkDUf += A6bztufEaYNThpJ7v2RqKQDrsk
		faOproKHmhWuM9vPkI5LwR0F3 += WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧ࡝ࡴࠪઇ")+TGWmQq0OdBPzIAD8lJcpNorwga+ooBHbA5RkDUf+TTjZMRAUezcia
	faOproKHmhWuM9vPkI5LwR0F3 += l5mQdjWyczr7UJVnTp(u"ࠨࠢࡢࠫઈ")
	if HVibA2ES8lY(u"ࠩࠨࠫઉ") in faOproKHmhWuM9vPkI5LwR0F3: faOproKHmhWuM9vPkI5LwR0F3 = rygO0TzuEdiPcQDWZ8awSjm(faOproKHmhWuM9vPkI5LwR0F3)
	EO9Rts0AaGuk1qpPLXCY.log(faOproKHmhWuM9vPkI5LwR0F3,level=V9rRebhB8M47SyjKp2dWFwUPA05T)
	return
def nIQHkPemMvAWusCczU9ZgY(OHuCxbAZaE45jUGwcrpldz3vDBh0qg):
	kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
	SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
	SCnhp2blgkLJrvcqKmXdE.execute(VOq8Ekue4F(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	SCnhp2blgkLJrvcqKmXdE.execute(ZhqJoOtcmTVID65HwnLj(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	SCnhp2blgkLJrvcqKmXdE.execute(HVibA2ES8lY(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	SCnhp2blgkLJrvcqKmXdE.execute(l5mQdjWyczr7UJVnTp(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	SCnhp2blgkLJrvcqKmXdE.execute(f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	SCnhp2blgkLJrvcqKmXdE.execute(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	kC7JunVyQdExXTaB.text_factory = str
	return kC7JunVyQdExXTaB,SCnhp2blgkLJrvcqKmXdE
def Nmkj7L5VEo(OHuCxbAZaE45jUGwcrpldz3vDBh0qg,d06F4MY9cKw5CrvAoNU,fYkGUQ4d5z=None):
	try: kC7JunVyQdExXTaB,SCnhp2blgkLJrvcqKmXdE = nIQHkPemMvAWusCczU9ZgY(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
	except: return
	if fYkGUQ4d5z==None: SCnhp2blgkLJrvcqKmXdE.execute(sbgu4D2RFMYKm(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+d06F4MY9cKw5CrvAoNU+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		gpHzj2W130xYMmtlsFCU8udIAQw = (str(fYkGUQ4d5z),)
		try:
			if HH4JMrUDp3lq6hQ(u"ࠫࠪ࠭઒") in fYkGUQ4d5z: SCnhp2blgkLJrvcqKmXdE.execute(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+d06F4MY9cKw5CrvAoNU+ZhqJoOtcmTVID65HwnLj(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),gpHzj2W130xYMmtlsFCU8udIAQw)
			else: SCnhp2blgkLJrvcqKmXdE.execute(ZhqJoOtcmTVID65HwnLj(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+d06F4MY9cKw5CrvAoNU+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),gpHzj2W130xYMmtlsFCU8udIAQw)
		except: pass
	kC7JunVyQdExXTaB.commit()
	kC7JunVyQdExXTaB.close()
	return
class eXb8B0sfcvCZ3rY7pWAFS2JOgVa(): pass
class B5Cv0E1zyTFw(eXb8B0sfcvCZ3rY7pWAFS2JOgVa):
	def __init__(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.url = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࠪગ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.code = -sDiKwnHcSlYFgWCy1Ak(u"࠹࠺ఏ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.reason = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠫઘ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.content = oAXJCYqPgyGDtT(u"ࠫࠬઙ")
		Q0GaWbo7qn12dgsfcNUT5IjElR.headers = {}
		Q0GaWbo7qn12dgsfcNUT5IjElR.cookies = {}
		Q0GaWbo7qn12dgsfcNUT5IjElR.succeeded = WmaPChRdQk3YcXwI6zS(u"ࡇࡣ࡯ࡷࡪౖ")
def m9fzrq3pxGEDi(otciIUKlyb6):
	if otciIUKlyb6==ttOu147wErcBvPaSMUY(u"ࠬࡪࡩࡤࡶࠪચ"): Z402tBVhQi = {}
	elif otciIUKlyb6==cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭࡬ࡪࡵࡷࠫછ"): Z402tBVhQi = []
	elif otciIUKlyb6==ZEiR0StquOzca9lvPAndYIX(u"ࠧࡴࡶࡵࠫજ"): Z402tBVhQi = EmK3ObA0cwv9Wy(u"ࠨࠩઝ")
	elif otciIUKlyb6==l5mQdjWyczr7UJVnTp(u"ࠩ࡬ࡲࡹ࠭ઞ"): Z402tBVhQi = VH9MDo5z1kxNF07uRJI(u"࠱ఐ")
	elif otciIUKlyb6==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): Z402tBVhQi = B5Cv0E1zyTFw()
	elif not otciIUKlyb6: Z402tBVhQi = None
	else: Z402tBVhQi = None
	return Z402tBVhQi
def wTpW3nbIgPckqCl9ohi(QTm3we64ojrRiLc1UO0lBAG):
	from hashlib import md5 as AAUsBktvRdn
	x8PaX3mvd7NUOG = YTPut68WBVUNCvsEzg.getSetting(FIHNSc5iuoZanQ2Ytl(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	q5SUfzV7ij3Gs18PHYmlnerCMxaOQ = au8Umt9dq1KLSYb(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠵࠵఑")).splitlines()
	hQzWT1Km0LVenpUEJHy7uCdXIMbSB3 = str(EEd0FZyfticlDPAMp2HbNesx*VH9MDo5z1kxNF07uRJI(u"࠶࠶࠰࠱࠲࠳࠲࠵ఔ")/EEvLoMzFqrlKce(u"࠸࠸࠸࠰࠱࠲ఓ"))[VH9MDo5z1kxNF07uRJI(u"࠳ఒ"):ZhqJoOtcmTVID65HwnLj(u"࠺క")]
	for WsK2hixD9YZnF3GgO6CSRf1AmpHcv in q5SUfzV7ij3Gs18PHYmlnerCMxaOQ:
		QxlFHEVDzOg6 = VH9MDo5z1kxNF07uRJI(u"ࠬ࡞࠱࠺ࠩડ")+QTm3we64ojrRiLc1UO0lBAG+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭࠱࠹࠿ࠪઢ")+WsK2hixD9YZnF3GgO6CSRf1AmpHcv[-cbngtp9sqYi0DjeEMLRHJruKxm(u"࠲࠵ఖ"):]+pQmoyUJBNaf72A+hQzWT1Km0LVenpUEJHy7uCdXIMbSB3
		QxlFHEVDzOg6 = AAUsBktvRdn(QxlFHEVDzOg6.encode(sDiKwnHcSlYFgWCy1Ak(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:f5uqIoSJzWBOFyrY78RXmVb(u"࠴࠴గ")]
		if QxlFHEVDzOg6 in x8PaX3mvd7NUOG: return VH9MDo5z1kxNF07uRJI(u"ࡖࡵࡹࡪ౗")
	return sDiKwnHcSlYFgWCy1Ak(u"ࡉࡥࡱࡹࡥౘ")
def IBxvzdjXCgS(OHuCxbAZaE45jUGwcrpldz3vDBh0qg,lAekNQf4FDj62iPCJ,d06F4MY9cKw5CrvAoNU,fYkGUQ4d5z=None):
	Z402tBVhQi = m9fzrq3pxGEDi(lAekNQf4FDj62iPCJ)
	A4fgbO6kxXRhVZ2sMLjuN = YTPut68WBVUNCvsEzg.getSetting(WmaPChRdQk3YcXwI6zS(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if d06F4MY9cKw5CrvAoNU!=EEvLoMzFqrlKce(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and OHuCxbAZaE45jUGwcrpldz3vDBh0qg==ttbwouYhASpBDJiHZEaLkegM3G:
		if A4fgbO6kxXRhVZ2sMLjuN==oAXJCYqPgyGDtT(u"ࠪࡗ࡙ࡕࡐࠨદ"): return Z402tBVhQi
		B6B7iVh1qW5Py = YTPut68WBVUNCvsEzg.getSetting(sbgu4D2RFMYKm(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if B6B7iVh1qW5Py==sbgu4D2RFMYKm(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			Nmkj7L5VEo(OHuCxbAZaE45jUGwcrpldz3vDBh0qg,d06F4MY9cKw5CrvAoNU,fYkGUQ4d5z)
			return Z402tBVhQi
	DvX7F0UoTYZRfMmsW5Vq = EEvLoMzFqrlKce(u"࠲ఘ")
	if A4fgbO6kxXRhVZ2sMLjuN==ZhqJoOtcmTVID65HwnLj(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): DvX7F0UoTYZRfMmsW5Vq = GGkgJ2RMcEZ
	try: kC7JunVyQdExXTaB,SCnhp2blgkLJrvcqKmXdE = nIQHkPemMvAWusCczU9ZgY(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
	except: return Z402tBVhQi
	lWvjdVUfPQtS5gaco6 = VOq8Ekue4F(u"ࡘࡷࡻࡥౙ")
	try: SCnhp2blgkLJrvcqKmXdE.execute(HVibA2ES8lY(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+d06F4MY9cKw5CrvAoNU+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: lWvjdVUfPQtS5gaco6 = VH9MDo5z1kxNF07uRJI(u"ࡋࡧ࡬ࡴࡧౚ")
	if lWvjdVUfPQtS5gaco6:
		if DvX7F0UoTYZRfMmsW5Vq: SCnhp2blgkLJrvcqKmXdE.execute(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+d06F4MY9cKw5CrvAoNU+TWexH5PhS1(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(EEd0FZyfticlDPAMp2HbNesx+DvX7F0UoTYZRfMmsW5Vq)+h5huy6MiXPNfQJF8(u"ࠫࠥࡁࠧમ"))
		kC7JunVyQdExXTaB.commit()
		SCnhp2blgkLJrvcqKmXdE.execute(l5mQdjWyczr7UJVnTp(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+d06F4MY9cKw5CrvAoNU+ttOu147wErcBvPaSMUY(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(EEd0FZyfticlDPAMp2HbNesx)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠧࠡ࠽ࠪ઱"))
		kC7JunVyQdExXTaB.commit()
		if fYkGUQ4d5z:
			gpHzj2W130xYMmtlsFCU8udIAQw = (str(fYkGUQ4d5z),)
			SCnhp2blgkLJrvcqKmXdE.execute(PiFkQ5pCJy7fbX(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+d06F4MY9cKw5CrvAoNU+FIHNSc5iuoZanQ2Ytl(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),gpHzj2W130xYMmtlsFCU8udIAQw)
			UNrkdT39f5 = SCnhp2blgkLJrvcqKmXdE.fetchall()
			if UNrkdT39f5:
				try:
					BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.decompress(UNrkdT39f5[VH9MDo5z1kxNF07uRJI(u"࠳ఙ")][VH9MDo5z1kxNF07uRJI(u"࠳ఙ")])
					Z402tBVhQi = gBUfVK5GtLjhD0.loads(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
				except: pass
		else:
			SCnhp2blgkLJrvcqKmXdE.execute(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+d06F4MY9cKw5CrvAoNU+vatyjK4hHAoZJ7rOq2lis(u"ࠫࠧࠦ࠻ࠨવ"))
			UNrkdT39f5 = SCnhp2blgkLJrvcqKmXdE.fetchall()
			if UNrkdT39f5:
				Z402tBVhQi,Rv2D6K8h4OStFLqmN7PU1xZlzBAed = {},[]
				for wwOI3TPeSx1nhVMAatFfY,vf78LSlJQOnCsatrIH2P1iW in UNrkdT39f5:
					Xl5KI3hzio8QvZVySd0RcDsnM4 = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.decompress(vf78LSlJQOnCsatrIH2P1iW)
					vf78LSlJQOnCsatrIH2P1iW = gBUfVK5GtLjhD0.loads(Xl5KI3hzio8QvZVySd0RcDsnM4)
					Z402tBVhQi[wwOI3TPeSx1nhVMAatFfY] = vf78LSlJQOnCsatrIH2P1iW
					Rv2D6K8h4OStFLqmN7PU1xZlzBAed.append(wwOI3TPeSx1nhVMAatFfY)
				if Rv2D6K8h4OStFLqmN7PU1xZlzBAed:
					Z402tBVhQi[sbgu4D2RFMYKm(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = Rv2D6K8h4OStFLqmN7PU1xZlzBAed
					if lAekNQf4FDj62iPCJ==vatyjK4hHAoZJ7rOq2lis(u"࠭࡬ࡪࡵࡷࠫષ"): Z402tBVhQi = Rv2D6K8h4OStFLqmN7PU1xZlzBAed
	kC7JunVyQdExXTaB.close()
	return Z402tBVhQi
class nRzPZsb3VILaWq6M7h4jo1ESCk0(BS1y8diLjcY6mbFszV450n2UEgq):
	def __init__(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.FJ50WqfeXmrb8OQGAEonU3Y = wTpW3nbIgPckqCl9ohi(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		Q0GaWbo7qn12dgsfcNUT5IjElR.NEHo5y17i8vqFbktae = wTpW3nbIgPckqCl9ohi(HVibA2ES8lY(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		Q0GaWbo7qn12dgsfcNUT5IjElR.C1kcEbPS7f4em93YsLINDaMZBtd = wTpW3nbIgPckqCl9ohi(VH9MDo5z1kxNF07uRJI(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if Q0GaWbo7qn12dgsfcNUT5IjElR.FJ50WqfeXmrb8OQGAEonU3Y else weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"઼ࠫࠬ")
	def mRfsQA9hItb8olWTxeHPwJjO2iCrkV(Q0GaWbo7qn12dgsfcNUT5IjElR,F4F72NVUlhugr): Q0GaWbo7qn12dgsfcNUT5IjElR.F4F72NVUlhugr = F4F72NVUlhugr
	def onPlayBackStopped(Q0GaWbo7qn12dgsfcNUT5IjElR): Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = sDiKwnHcSlYFgWCy1Ak(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(Q0GaWbo7qn12dgsfcNUT5IjElR): Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(Q0GaWbo7qn12dgsfcNUT5IjElR): Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(Q0GaWbo7qn12dgsfcNUT5IjElR):
		Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = VOq8Ekue4F(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		Hx4l8w0omAgc = RZxCcFI8fw31NKP.Thread(target=Q0GaWbo7qn12dgsfcNUT5IjElR.xxpsKw79bzIn1goHVLv8WteS,args=())
		Hx4l8w0omAgc.start()
	def onAVStarted(Q0GaWbo7qn12dgsfcNUT5IjElR):
		if Q0GaWbo7qn12dgsfcNUT5IjElR.NEHo5y17i8vqFbktae: Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = N9olEh0ZMtpOivVfBLK(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def xxpsKw79bzIn1goHVLv8WteS(Q0GaWbo7qn12dgsfcNUT5IjElR):
		from skIgoAvZ9t import IwMkQbtRaygHBVF7dK9ipNU5rfYAS,hK6ziN5kmMZr8ops2qD,inrDtz8mJqLpkPSldeyYjsEaBwA
		inrDtz8mJqLpkPSldeyYjsEaBwA(PiFkQ5pCJy7fbX(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		NgePKtSIL5dZOciRw7HC0 = TWexH5PhS1(u"࠴చ")
		while not eval(sbgu4D2RFMYKm(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{vatyjK4hHAoZJ7rOq2lis(u"࠭ࡸࡣ࡯ࡦࠫૅ"):EO9Rts0AaGuk1qpPLXCY}) and Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p==ZhqJoOtcmTVID65HwnLj(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			EO9Rts0AaGuk1qpPLXCY.sleep(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶࠶࠰࠱ఛ"))
			NgePKtSIL5dZOciRw7HC0 += mNkfJnpOrad7hT6PYyciwsSDQ(u"࠷జ")
			if NgePKtSIL5dZOciRw7HC0>VH9MDo5z1kxNF07uRJI(u"࠶࠱ఝ"): return
		if Q0GaWbo7qn12dgsfcNUT5IjElR.FJ50WqfeXmrb8OQGAEonU3Y: Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif Q0GaWbo7qn12dgsfcNUT5IjElR.NEHo5y17i8vqFbktae: Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = sDiKwnHcSlYFgWCy1Ak(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif Q0GaWbo7qn12dgsfcNUT5IjElR.C1kcEbPS7f4em93YsLINDaMZBtd:
			Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = oAXJCYqPgyGDtT(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			h2fvF04sMN = RZxCcFI8fw31NKP.Thread(target=IwMkQbtRaygHBVF7dK9ipNU5rfYAS,args=(Q0GaWbo7qn12dgsfcNUT5IjElR.F4F72NVUlhugr,))
			h2fvF04sMN.start()
			KhrTkUjnMlPuXE1 = RZxCcFI8fw31NKP.Thread(target=hK6ziN5kmMZr8ops2qD,args=())
			KhrTkUjnMlPuXE1.start()
		else: Q0GaWbo7qn12dgsfcNUT5IjElR.etDHUWmj75gkduPCaZGJw9X1p = EEvLoMzFqrlKce(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def s0DZdYa2vkczqt9ob5l1OifGAXMEnw():
	odMYW9uKnC,JwmR87YoObIgUHseN1Z = Xl3drKyI9HkDiPEf8RTjwu(u"ࠬ࠭ો"),EEvLoMzFqrlKce(u"࠭ࠧૌ")
	i2itdx73JTcKuPF58QXfDOr = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		CjAdYPM4O05 = open(FIHNSc5iuoZanQ2Ytl(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),PiFkQ5pCJy7fbX(u"ࠩࡵࡦࠬ૏")).read()
		if mmIKCGujwM: CjAdYPM4O05 = CjAdYPM4O05.decode(N9olEh0ZMtpOivVfBLK(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		A3AD7NfVtuCvP = T072lCzjYiuaeFtmJGV.findall(PiFkQ5pCJy7fbX(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),CjAdYPM4O05,T072lCzjYiuaeFtmJGV.IGNORECASE)
		if A3AD7NfVtuCvP: odMYW9uKnC = A3AD7NfVtuCvP[VH9MDo5z1kxNF07uRJI(u"࠱ఞ")]
	except: pass
	try:
		import subprocess as KwFx2rLtTBDduNjzUkv
		iqzhk2QBfF8 = KwFx2rLtTBDduNjzUkv.Popen(N9olEh0ZMtpOivVfBLK(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=PiFkQ5pCJy7fbX(u"࡚ࡲࡶࡧ౛"),stdin=KwFx2rLtTBDduNjzUkv.PIPE,stdout=KwFx2rLtTBDduNjzUkv.PIPE,stderr=KwFx2rLtTBDduNjzUkv.PIPE)
		yQRN9g4cTYE0zbWXFL = iqzhk2QBfF8.stdout.read()
		if yQRN9g4cTYE0zbWXFL:
			if mmIKCGujwM:
				yQRN9g4cTYE0zbWXFL = yQRN9g4cTYE0zbWXFL.decode(ZEiR0StquOzca9lvPAndYIX(u"࠭ࡵࡵࡨ࠻ࠫ૓"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			SDAoRCGK8mjYs6TIhMqE0wr = T072lCzjYiuaeFtmJGV.findall(VH9MDo5z1kxNF07uRJI(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),yQRN9g4cTYE0zbWXFL,T072lCzjYiuaeFtmJGV.IGNORECASE)
			if SDAoRCGK8mjYs6TIhMqE0wr: JwmR87YoObIgUHseN1Z = min(SDAoRCGK8mjYs6TIhMqE0wr)
	except: pass
	return i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z
def au8Umt9dq1KLSYb(PPezI3c1TXMHyfERlNOsWB2bmrKoU,Qi290YUnCHar51c8wuFjK3M=HVibA2ES8lY(u"ࡔࡳࡷࡨ౜")):
	z6M0F4idrEsXD7BQ3evg8Kth2NcT = PiFkQ5pCJy7fbX(u"ࡕࡴࡸࡩౝ")
	if Qi290YUnCHar51c8wuFjK3M:
		YTIsEJDeC0fFLGBXaQbxj = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩ࡯࡭ࡸࡺࠧ૖"),VOq8Ekue4F(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),PiFkQ5pCJy7fbX(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if YTIsEJDeC0fFLGBXaQbxj:
			q5SUfzV7ij3Gs18PHYmlnerCMxaOQ,LAEoz3FsutJX,O7ulszyGY28ewnQcxCkMt,QWoJ3C7pzFqStkgK4xdT = YTIsEJDeC0fFLGBXaQbxj
			z6M0F4idrEsXD7BQ3evg8Kth2NcT = IBxvzdjXCgS(ttbwouYhASpBDJiHZEaLkegM3G,oAXJCYqPgyGDtT(u"ࠬࡲࡩࡴࡶࠪ૙"),l5mQdjWyczr7UJVnTp(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),VH9MDo5z1kxNF07uRJI(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if z6M0F4idrEsXD7BQ3evg8Kth2NcT: i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z = z6M0F4idrEsXD7BQ3evg8Kth2NcT
			else: i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z = s0DZdYa2vkczqt9ob5l1OifGAXMEnw()
			if (LAEoz3FsutJX,O7ulszyGY28ewnQcxCkMt,QWoJ3C7pzFqStkgK4xdT)==(i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z): return FIHNSc5iuoZanQ2Ytl(u"ࠨ࡞ࡱࠫ૜").join(q5SUfzV7ij3Gs18PHYmlnerCMxaOQ)
	if z6M0F4idrEsXD7BQ3evg8Kth2NcT: i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z = s0DZdYa2vkczqt9ob5l1OifGAXMEnw()
	global haH0q75FWoQliBI,Cu6QIs1hVykrM
	haH0q75FWoQliBI,Cu6QIs1hVykrM,MjgKmxbFEkTsYi = EmK3ObA0cwv9Wy(u"ࠩࠪ૝"),EmK3ObA0cwv9Wy(u"ࠪࠫ૞"),HVibA2ES8lY(u"ࠫࠬ૟")
	PPezI3c1TXMHyfERlNOsWB2bmrKoU = PPezI3c1TXMHyfERlNOsWB2bmrKoU//l5mQdjWyczr7UJVnTp(u"࠴ట")
	RZxCcFI8fw31NKP.Thread(target=HH31hmVIM4iQltq6STUnbyvpXDaG).start()
	RZxCcFI8fw31NKP.Thread(target=GoRC01mL8IXhD4gJVBnQAvOq).start()
	for H3ABEcMzfyqwF4Ug2ZYtK in range(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠴࠴ఠ")):
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(oAXJCYqPgyGDtT(u"࠴࠳࠻డ"))
		if not MjgKmxbFEkTsYi:
			try:
				hSq2YGF0DZB6LgTiPWU8A = EO9Rts0AaGuk1qpPLXCY.getInfoLabel(ZEiR0StquOzca9lvPAndYIX(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if hSq2YGF0DZB6LgTiPWU8A.count(FIHNSc5iuoZanQ2Ytl(u"࠭࠺ࠨૡ"))==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠻ణ") and hSq2YGF0DZB6LgTiPWU8A.count(WmaPChRdQk3YcXwI6zS(u"ࠧ࠱ࠩૢ"))<sDiKwnHcSlYFgWCy1Ak(u"࠾ఢ"):
					hSq2YGF0DZB6LgTiPWU8A = hSq2YGF0DZB6LgTiPWU8A.lower().replace(WmaPChRdQk3YcXwI6zS(u"ࠨ࠼ࠪૣ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࠪ૤"))
					MjgKmxbFEkTsYi = str(int(hSq2YGF0DZB6LgTiPWU8A,mNkfJnpOrad7hT6PYyciwsSDQ(u"࠱࠷త")))
			except: pass
		if haH0q75FWoQliBI and Cu6QIs1hVykrM and MjgKmxbFEkTsYi: break
	hLDpJasPQzKNlOcVCd9HxXTk2 = [haH0q75FWoQliBI,Cu6QIs1hVykrM,MjgKmxbFEkTsYi,S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࠫ૥"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࠬ૦"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if odMYW9uKnC or JwmR87YoObIgUHseN1Z:
		from hashlib import md5 as AAUsBktvRdn
		znXo7PrJZL9Ag8ikM0Cl = [(mNkfJnpOrad7hT6PYyciwsSDQ(u"࠶ద"),odMYW9uKnC),(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠶థ"),JwmR87YoObIgUHseN1Z)]
		for TRBlwxbQJUZaKL1s86SIAze,qqk6TvmXIdJAxi9t1MDaz in znXo7PrJZL9Ag8ikM0Cl:
			qqk6TvmXIdJAxi9t1MDaz = qqk6TvmXIdJAxi9t1MDaz.strip(sbgu4D2RFMYKm(u"࠭࠰ࠨ૨"))
			if qqk6TvmXIdJAxi9t1MDaz:
				if mmIKCGujwM: qqk6TvmXIdJAxi9t1MDaz = qqk6TvmXIdJAxi9t1MDaz.encode(FIHNSc5iuoZanQ2Ytl(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				qqk6TvmXIdJAxi9t1MDaz = str(int(AAUsBktvRdn(qqk6TvmXIdJAxi9t1MDaz).hexdigest(),FIHNSc5iuoZanQ2Ytl(u"࠶࠺ధ")))
				W7K2b1vpfUOD3 = [int(qqk6TvmXIdJAxi9t1MDaz[VBrLDcjzXwfOHQh1C:VBrLDcjzXwfOHQh1C+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶࠻఩")]) for VBrLDcjzXwfOHQh1C in range(len(qqk6TvmXIdJAxi9t1MDaz)) if VBrLDcjzXwfOHQh1C%WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠶࠻఩")==vatyjK4hHAoZJ7rOq2lis(u"࠴న")]
				hLDpJasPQzKNlOcVCd9HxXTk2[TRBlwxbQJUZaKL1s86SIAze-f5uqIoSJzWBOFyrY78RXmVb(u"࠷ప")] = str(sum(W7K2b1vpfUOD3))
	q5SUfzV7ij3Gs18PHYmlnerCMxaOQ,me3zBv2pChHwYr7JXDkZEulia9Aj = [],EmK3ObA0cwv9Wy(u"ࡈࡤࡰࡸ࡫౞")
	for KlM61bJWLf in range(len(hLDpJasPQzKNlOcVCd9HxXTk2)):
		W7K2b1vpfUOD3 = hLDpJasPQzKNlOcVCd9HxXTk2[KlM61bJWLf]
		if not W7K2b1vpfUOD3: continue
		if me3zBv2pChHwYr7JXDkZEulia9Aj and W7K2b1vpfUOD3==hLDpJasPQzKNlOcVCd9HxXTk2[-ttOu147wErcBvPaSMUY(u"࠱ఫ")]: continue
		me3zBv2pChHwYr7JXDkZEulia9Aj = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࡗࡶࡺ࡫౟")
		W7K2b1vpfUOD3 = PPezI3c1TXMHyfERlNOsWB2bmrKoU*mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨ࠲ࠪ૪")+W7K2b1vpfUOD3
		W7K2b1vpfUOD3 = W7K2b1vpfUOD3[-PPezI3c1TXMHyfERlNOsWB2bmrKoU:]
		uL018HpR2okG79OVNaYTtsCgXZ,jUk02N1FMRGyptr3f = WmaPChRdQk3YcXwI6zS(u"ࠩࠪ૫"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࠫ૬")
		I7O52dPls8NqbUBXyDkE61 = str(int(ZhqJoOtcmTVID65HwnLj(u"ࠫ࠾࠭૭")*(PPezI3c1TXMHyfERlNOsWB2bmrKoU+PiFkQ5pCJy7fbX(u"࠲బ")))-int(W7K2b1vpfUOD3))[-PPezI3c1TXMHyfERlNOsWB2bmrKoU:]
		for NvZ3WnyDcGUbegBqx4zJrsdQAaH in list(range(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠲భ"),PPezI3c1TXMHyfERlNOsWB2bmrKoU,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠷మ"))):
			vBzNSkRwQMKdnV7JE2 = I7O52dPls8NqbUBXyDkE61[NvZ3WnyDcGUbegBqx4zJrsdQAaH:NvZ3WnyDcGUbegBqx4zJrsdQAaH+oAXJCYqPgyGDtT(u"࠸య")]
			uL018HpR2okG79OVNaYTtsCgXZ += vBzNSkRwQMKdnV7JE2+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬ࠳ࠧ૮")
			jUk02N1FMRGyptr3f += str(sum(map(int,W7K2b1vpfUOD3[NvZ3WnyDcGUbegBqx4zJrsdQAaH:NvZ3WnyDcGUbegBqx4zJrsdQAaH+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠺ఱ")]))%VH9MDo5z1kxNF07uRJI(u"࠶࠶ర"))
		WsK2hixD9YZnF3GgO6CSRf1AmpHcv = str(KlM61bJWLf)+uL018HpR2okG79OVNaYTtsCgXZ+jUk02N1FMRGyptr3f
		q5SUfzV7ij3Gs18PHYmlnerCMxaOQ.append(WsK2hixD9YZnF3GgO6CSRf1AmpHcv)
	rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,oAXJCYqPgyGDtT(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),VH9MDo5z1kxNF07uRJI(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z],GGXxhdg3JCamPIFepybjZ)
	rrz7vWj1sdwU0qa(ttbwouYhASpBDJiHZEaLkegM3G,cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),HVibA2ES8lY(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[q5SUfzV7ij3Gs18PHYmlnerCMxaOQ,i2itdx73JTcKuPF58QXfDOr,odMYW9uKnC,JwmR87YoObIgUHseN1Z],CC89Q23uNDmIKWHAs)
	return HVibA2ES8lY(u"ࠪࡠࡳ࠭૳").join(q5SUfzV7ij3Gs18PHYmlnerCMxaOQ)
def wZWH4u8XUFt3V5reszRQIcLvfiopO(otciIUKlyb6,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2):
	JKf4Tsxu9S23FI7mV5DGLk = str(YYmX6s9ieC4N3TuoVxnRApZ)[HVibA2ES8lY(u"࠰ల"):WmaPChRdQk3YcXwI6zS(u"࠳࠷࠳ళ")].replace(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠫࡡࡴࠧ૴"),PiFkQ5pCJy7fbX(u"ࠬࡢ࡜࡯ࠩ૵")).replace(PiFkQ5pCJy7fbX(u"࠭࡜ࡳࠩ૶"),WmaPChRdQk3YcXwI6zS(u"ࠧ࡝࡞ࡵࠫ૷")).replace(l5mQdjWyczr7UJVnTp(u"ࠨࠢࠣࠤࠥ࠭૸"),ZhqJoOtcmTVID65HwnLj(u"ࠩࠣࠫૹ")).replace(f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠤࠥࠦࠧૺ"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࠥ࠭ૻ"))
	if len(str(YYmX6s9ieC4N3TuoVxnRApZ))>HH4JMrUDp3lq6hQ(u"࠴࠸࠴ఴ"): JKf4Tsxu9S23FI7mV5DGLk = JKf4Tsxu9S23FI7mV5DGLk+sDiKwnHcSlYFgWCy1Ak(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	vf78LSlJQOnCsatrIH2P1iW = str(Z402tBVhQi)[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠳వ"):WmaPChRdQk3YcXwI6zS(u"࠶࠺࠶శ")].replace(h5huy6MiXPNfQJF8(u"࠭࡜࡯ࠩ૽"),PiFkQ5pCJy7fbX(u"ࠧ࡝࡞ࡱࠫ૾")).replace(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨ࡞ࡵࠫ૿"),WmaPChRdQk3YcXwI6zS(u"ࠩ࡟ࡠࡷ࠭଀")).replace(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࠤࠥࠦࠠࠨଁ"),ttOu147wErcBvPaSMUY(u"ࠫࠥ࠭ଂ")).replace(mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬࠦࠠࠡࠩଃ"),ZEiR0StquOzca9lvPAndYIX(u"࠭ࠠࠨ଄"))
	if len(str(Z402tBVhQi))>EmK3ObA0cwv9Wy(u"࠷࠻࠰ష"): vf78LSlJQOnCsatrIH2P1iW = vf78LSlJQOnCsatrIH2P1iW+VOq8Ekue4F(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	GZvEITHSg5U3rVwQ(f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),TWexH5PhS1(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+otciIUKlyb6+VH9MDo5z1kxNF07uRJI(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+gz1flZwncVutokL59RaGS3WeK+WmaPChRdQk3YcXwI6zS(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+nnN6lPjWb0xVQqDKwo3+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+XhtVsaQU5r1cfgLDRMjO4EI9ouPT2+EEvLoMzFqrlKce(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(JKf4Tsxu9S23FI7mV5DGLk)+TWexH5PhS1(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+vf78LSlJQOnCsatrIH2P1iW+h5huy6MiXPNfQJF8(u"ࠨࠢࡠࠫ଍"))
	return
def HH31hmVIM4iQltq6STUnbyvpXDaG():
	global haH0q75FWoQliBI
	import getmac82 as uQs84vS3hfZwgKbnA5WeR2Ep
	try:
		HFjYpB5otS4i3CfGsXa = uQs84vS3hfZwgKbnA5WeR2Ep.get_mac_address()
		if HFjYpB5otS4i3CfGsXa.count(vatyjK4hHAoZJ7rOq2lis(u"ࠩ࠽ࠫ଎"))==ZhqJoOtcmTVID65HwnLj(u"࠵హ") and HFjYpB5otS4i3CfGsXa.count(sbgu4D2RFMYKm(u"ࠪ࠴ࠬଏ"))<f5uqIoSJzWBOFyrY78RXmVb(u"࠿స"):
			HFjYpB5otS4i3CfGsXa = HFjYpB5otS4i3CfGsXa.lower().replace(ZhqJoOtcmTVID65HwnLj(u"ࠫ࠿࠭ଐ"),HH4JMrUDp3lq6hQ(u"ࠬ࠭଑"))
			haH0q75FWoQliBI = str(int(HFjYpB5otS4i3CfGsXa,HH4JMrUDp3lq6hQ(u"࠲࠸఺")))
	except: pass
	return
def GoRC01mL8IXhD4gJVBnQAvOq():
	global Cu6QIs1hVykrM
	import getmac94 as u5AJh8q7dcgKfMtszIX3elba
	try:
		A8IceyxO6V3M4UmBtuDasz = u5AJh8q7dcgKfMtszIX3elba.get_mac_address()
		if A8IceyxO6V3M4UmBtuDasz.count(vatyjK4hHAoZJ7rOq2lis(u"࠭࠺ࠨ଒"))==mNkfJnpOrad7hT6PYyciwsSDQ(u"࠸఼") and A8IceyxO6V3M4UmBtuDasz.count(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧ࠱ࠩଓ"))<sDiKwnHcSlYFgWCy1Ak(u"࠻఻"):
			A8IceyxO6V3M4UmBtuDasz = A8IceyxO6V3M4UmBtuDasz.lower().replace(TWexH5PhS1(u"ࠨ࠼ࠪଔ"),sbgu4D2RFMYKm(u"ࠩࠪକ"))
			Cu6QIs1hVykrM = str(int(A8IceyxO6V3M4UmBtuDasz,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠵࠻ఽ")))
	except: pass
	return
def dXM2DkYvVZ(XhtVsaQU5r1cfgLDRMjO4EI9ouPT2,gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi=VH9MDo5z1kxNF07uRJI(u"ࠪࠫଖ"),YYmX6s9ieC4N3TuoVxnRApZ=WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࠬଗ"),nnN6lPjWb0xVQqDKwo3=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࠭ଘ")):
	wZWH4u8XUFt3V5reszRQIcLvfiopO(ZhqJoOtcmTVID65HwnLj(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,nnN6lPjWb0xVQqDKwo3,XhtVsaQU5r1cfgLDRMjO4EI9ouPT2)
	if mmIKCGujwM: import urllib.request as HNI3aySTt6FcYhM
	else: import urllib2 as HNI3aySTt6FcYhM
	if not YYmX6s9ieC4N3TuoVxnRApZ: YYmX6s9ieC4N3TuoVxnRApZ = {TWexH5PhS1(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):TWexH5PhS1(u"ࠨࠩଛ")}
	if not Z402tBVhQi: Z402tBVhQi = {}
	if XhtVsaQU5r1cfgLDRMjO4EI9ouPT2==HH4JMrUDp3lq6hQ(u"ࠩࡊࡉ࡙࠭ଜ"):
		gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+ZEiR0StquOzca9lvPAndYIX(u"ࠪࡃࠬଝ")+YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(Z402tBVhQi)
		Z402tBVhQi = None
	elif XhtVsaQU5r1cfgLDRMjO4EI9ouPT2==EEvLoMzFqrlKce(u"ࠫࡕࡕࡓࡕࠩଞ") and WmaPChRdQk3YcXwI6zS(u"ࠬࡰࡳࡰࡰࠪଟ") in str(YYmX6s9ieC4N3TuoVxnRApZ):
		from json import dumps as zP8A0c3YCN7oq9ElMdevh
		Z402tBVhQi = zP8A0c3YCN7oq9ElMdevh(Z402tBVhQi)
		Z402tBVhQi = str(Z402tBVhQi).encode(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif XhtVsaQU5r1cfgLDRMjO4EI9ouPT2==f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡑࡑࡖࡘࠬଡ"):
		Z402tBVhQi = YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(Z402tBVhQi)
		Z402tBVhQi = Z402tBVhQi.encode(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		UME087PSczBFiQ4d3YyJ1uwRaDshK = HNI3aySTt6FcYhM.Request(gz1flZwncVutokL59RaGS3WeK,headers=YYmX6s9ieC4N3TuoVxnRApZ,data=Z402tBVhQi)
		z8zCauMw6AGm7ZRDFO4NeJ0xrLt = HNI3aySTt6FcYhM.urlopen(UME087PSczBFiQ4d3YyJ1uwRaDshK)
		KLxMkaVlguvqPcF = z8zCauMw6AGm7ZRDFO4NeJ0xrLt.read()
		yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = EEvLoMzFqrlKce(u"࠷࠶࠰ా"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡒࡏࠬଣ")
	except:
		KLxMkaVlguvqPcF = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠫତ")
		yxkqChFvLOnj1TKZMHSUdrA9bGN,rreason = -S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷ి"),sbgu4D2RFMYKm(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	GZvEITHSg5U3rVwQ(vatyjK4hHAoZJ7rOq2lis(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),l5mQdjWyczr7UJVnTp(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(yxkqChFvLOnj1TKZMHSUdrA9bGN)+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+rreason+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+nnN6lPjWb0xVQqDKwo3+TWexH5PhS1(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+gz1flZwncVutokL59RaGS3WeK+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠪࠤࡢ࠭ଫ"))
	if KLxMkaVlguvqPcF and mmIKCGujwM: KLxMkaVlguvqPcF = KLxMkaVlguvqPcF.decode(FIHNSc5iuoZanQ2Ytl(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return KLxMkaVlguvqPcF
def cH3wtyn51rUbuWOdLo89Z(Dey0Yu2msrJzn8fEFO4Hl7NcWoGUa,wwAY7gno94k6OVExHaKZW2lTdMhy=VOq8Ekue4F(u"ࠬ࠭ଭ")):
	k3n9jWDYrwNHcBezSJ78XTdG = str(XIjYJW8qbtv63.randrange(WmaPChRdQk3YcXwI6zS(u"࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵ీ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾ు")))
	YYmX6s9ieC4N3TuoVxnRApZ = {HVibA2ES8lY(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):HVibA2ES8lY(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	V4j2RyWYwvkz = {	ZEiR0StquOzca9lvPAndYIX(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):au8Umt9dq1KLSYb(h5huy6MiXPNfQJF8(u"࠶࠶ృ")).splitlines()[weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠴ౄ")][-N9olEh0ZMtpOivVfBLK(u"࠴࠷ూ"):],
				VH9MDo5z1kxNF07uRJI(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(XK3HqaTnjpyIAuhw67CmdvBM),
				vatyjK4hHAoZJ7rOq2lis(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):pQmoyUJBNaf72A,
				cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):pQmoyUJBNaf72A,
				EmK3ObA0cwv9Wy(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):Dey0Yu2msrJzn8fEFO4Hl7NcWoGUa,
				EEvLoMzFqrlKce(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): pQmoyUJBNaf72A,
				PiFkQ5pCJy7fbX(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):TWexH5PhS1(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				WmaPChRdQk3YcXwI6zS(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):Dey0Yu2msrJzn8fEFO4Hl7NcWoGUa},
				h5huy6MiXPNfQJF8(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {N9olEh0ZMtpOivVfBLK(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):Dey0Yu2msrJzn8fEFO4Hl7NcWoGUa},
				sbgu4D2RFMYKm(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):l5mQdjWyczr7UJVnTp(u"ࡊࡦࡲࡳࡦౠ"),
				HH4JMrUDp3lq6hQ(u"ࠢࡪࡲࠥଽ"): WmaPChRdQk3YcXwI6zS(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not wwAY7gno94k6OVExHaKZW2lTdMhy: iPUVOnzgLsABuv0yHj = [V4j2RyWYwvkz]
	else:
		y8OzbGqYNmwgCZFjhEKtsiv0p = V4j2RyWYwvkz.copy()
		y8OzbGqYNmwgCZFjhEKtsiv0p[BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = wwAY7gno94k6OVExHaKZW2lTdMhy
		y8OzbGqYNmwgCZFjhEKtsiv0p[uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {WmaPChRdQk3YcXwI6zS(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):wwAY7gno94k6OVExHaKZW2lTdMhy}
		y8OzbGqYNmwgCZFjhEKtsiv0p[ttOu147wErcBvPaSMUY(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):wwAY7gno94k6OVExHaKZW2lTdMhy}
		iPUVOnzgLsABuv0yHj = [V4j2RyWYwvkz,y8OzbGqYNmwgCZFjhEKtsiv0p]
	Z402tBVhQi = {g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):ZhqJoOtcmTVID65HwnLj(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			ttOu147wErcBvPaSMUY(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):k3n9jWDYrwNHcBezSJ78XTdG,
			FIHNSc5iuoZanQ2Ytl(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): iPUVOnzgLsABuv0yHj
		}
	gz1flZwncVutokL59RaGS3WeK = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	KLxMkaVlguvqPcF = dXM2DkYvVZ(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡖࡏࡔࡖࠪ୉"),gz1flZwncVutokL59RaGS3WeK,Z402tBVhQi,YYmX6s9ieC4N3TuoVxnRApZ,sDiKwnHcSlYFgWCy1Ak(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return KLxMkaVlguvqPcF
def cwiLy4IAVJj0pWCl7FGxokR(lAekNQf4FDj62iPCJ,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry):
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(HH4JMrUDp3lq6hQ(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),sDiKwnHcSlYFgWCy1Ak(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(VOq8Ekue4F(u"ࠩࡷࡶࡺ࡫୍ࠧ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪࡘࡷࡻࡥࠨ୎"))
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(HVibA2ES8lY(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),HVibA2ES8lY(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry.replace(h5huy6MiXPNfQJF8(u"࠭࡜࠰ࠩ୑"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧ࠰ࠩ୒"))
	try: Xl5KI3hzio8QvZVySd0RcDsnM4 = eval(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	except: Xl5KI3hzio8QvZVySd0RcDsnM4 = m9fzrq3pxGEDi(lAekNQf4FDj62iPCJ)
	return Xl5KI3hzio8QvZVySd0RcDsnM4
def PHMnCmaZ94fJ8gFl2dzLyvsrA():
	otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
	mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),eENPgSDsKvOH24QpIbGjZtwnYoFl,T072lCzjYiuaeFtmJGV.DOTALL)
	if mnN8GgS1XEePILK0DC49qky6UzZ: eENPgSDsKvOH24QpIbGjZtwnYoFl = eENPgSDsKvOH24QpIbGjZtwnYoFl.split(mnN8GgS1XEePILK0DC49qky6UzZ[VOq8Ekue4F(u"࠶ె")],N9olEh0ZMtpOivVfBLK(u"࠶౅"))[N9olEh0ZMtpOivVfBLK(u"࠶౅")]
	r3FTmIhP8v6A4Qb0RX = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),D1vBJgya85Yh4cRTCkIMKtWLSeH.localtime(EEd0FZyfticlDPAMp2HbNesx))
	eENPgSDsKvOH24QpIbGjZtwnYoFl = eENPgSDsKvOH24QpIbGjZtwnYoFl+r3FTmIhP8v6A4Qb0RX
	MMVPRsn2G4YK6byiwvO = otciIUKlyb6,eENPgSDsKvOH24QpIbGjZtwnYoFl,gz1flZwncVutokL59RaGS3WeK,DkjbIhZoVd7F52r6Ew,BB5dqMe8jgLxwSvk,ffGe7cURW0lhJVvQAiw8IB,BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry,ytsdYhu8qpWc6nwJlDr32bBPmj,RLg3NjAdqfTMl
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(oQjDxLF9fdtyCaJ5ZTO860ri1s):
		xOnG9rbvo6mYRU5y0dKBj = open(oQjDxLF9fdtyCaJ5ZTO860ri1s,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠪࡶࡧ࠭୕")).read()
		if mmIKCGujwM: xOnG9rbvo6mYRU5y0dKBj = xOnG9rbvo6mYRU5y0dKBj.decode(EmK3ObA0cwv9Wy(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		xOnG9rbvo6mYRU5y0dKBj = cwiLy4IAVJj0pWCl7FGxokR(ZEiR0StquOzca9lvPAndYIX(u"ࠬࡪࡩࡤࡶࠪୗ"),xOnG9rbvo6mYRU5y0dKBj)
	else: xOnG9rbvo6mYRU5y0dKBj = {}
	gmoEyP1szUOAFwfMdDGhXxb7W = {}
	for yzPpOFLI4K9 in list(xOnG9rbvo6mYRU5y0dKBj.keys()):
		if yzPpOFLI4K9!=otciIUKlyb6: gmoEyP1szUOAFwfMdDGhXxb7W[yzPpOFLI4K9] = xOnG9rbvo6mYRU5y0dKBj[yzPpOFLI4K9]
		else:
			if eENPgSDsKvOH24QpIbGjZtwnYoFl and eENPgSDsKvOH24QpIbGjZtwnYoFl!=ZhqJoOtcmTVID65HwnLj(u"࠭࠮࠯ࠩ୘"):
				N1oQTdYOkH5PSeibfmrlUXKBg = xOnG9rbvo6mYRU5y0dKBj[yzPpOFLI4K9]
				if MMVPRsn2G4YK6byiwvO in N1oQTdYOkH5PSeibfmrlUXKBg:
					prZUeN9FojstVTxf0EJQBRq4zdb = N1oQTdYOkH5PSeibfmrlUXKBg.index(MMVPRsn2G4YK6byiwvO)
					del N1oQTdYOkH5PSeibfmrlUXKBg[prZUeN9FojstVTxf0EJQBRq4zdb]
				onDef3aEjYX5lhq = [MMVPRsn2G4YK6byiwvO]+N1oQTdYOkH5PSeibfmrlUXKBg
				onDef3aEjYX5lhq = onDef3aEjYX5lhq[:VOq8Ekue4F(u"࠵࠱ే")]
				gmoEyP1szUOAFwfMdDGhXxb7W[yzPpOFLI4K9] = onDef3aEjYX5lhq
			else: gmoEyP1szUOAFwfMdDGhXxb7W[yzPpOFLI4K9] = xOnG9rbvo6mYRU5y0dKBj[yzPpOFLI4K9]
	if otciIUKlyb6 not in list(gmoEyP1szUOAFwfMdDGhXxb7W.keys()): gmoEyP1szUOAFwfMdDGhXxb7W[otciIUKlyb6] = [MMVPRsn2G4YK6byiwvO]
	gmoEyP1szUOAFwfMdDGhXxb7W = str(gmoEyP1szUOAFwfMdDGhXxb7W)
	if mmIKCGujwM: gmoEyP1szUOAFwfMdDGhXxb7W = gmoEyP1szUOAFwfMdDGhXxb7W.encode(VH9MDo5z1kxNF07uRJI(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(oQjDxLF9fdtyCaJ5ZTO860ri1s,EEvLoMzFqrlKce(u"ࠨࡹࡥࠫ୚")).write(gmoEyP1szUOAFwfMdDGhXxb7W)
	return
def rrz7vWj1sdwU0qa(OHuCxbAZaE45jUGwcrpldz3vDBh0qg,d06F4MY9cKw5CrvAoNU,fYkGUQ4d5z,Z402tBVhQi,efTYtsigQALPBJm3pa2w1q6OnK,y0xjlrJhM954=ZhqJoOtcmTVID65HwnLj(u"ࡋࡧ࡬ࡴࡧౡ")):
	A4fgbO6kxXRhVZ2sMLjuN = YTPut68WBVUNCvsEzg.getSetting(HH4JMrUDp3lq6hQ(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if A4fgbO6kxXRhVZ2sMLjuN==HVibA2ES8lY(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and efTYtsigQALPBJm3pa2w1q6OnK>GGkgJ2RMcEZ: efTYtsigQALPBJm3pa2w1q6OnK = GGkgJ2RMcEZ
	if y0xjlrJhM954:
		yvuYVFPClBd03mc8,SS7cKmHlzATRB5CoYVkrjbLM8e2xJ = [],[]
		for H3ABEcMzfyqwF4Ug2ZYtK in range(len(fYkGUQ4d5z)):
			BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = gBUfVK5GtLjhD0.dumps(Z402tBVhQi[H3ABEcMzfyqwF4Ug2ZYtK])
			Em8kqxbSD67whCXBWo = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.compress(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
			yvuYVFPClBd03mc8.append((fYkGUQ4d5z[H3ABEcMzfyqwF4Ug2ZYtK],))
			SS7cKmHlzATRB5CoYVkrjbLM8e2xJ.append((efTYtsigQALPBJm3pa2w1q6OnK+EEd0FZyfticlDPAMp2HbNesx,str(fYkGUQ4d5z[H3ABEcMzfyqwF4Ug2ZYtK]),Em8kqxbSD67whCXBWo))
	else:
		BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry = gBUfVK5GtLjhD0.dumps(Z402tBVhQi)
		xtwO1UCjBpsKEG32RrLzfMv06b = VVZfqbyzauDFwc1KCx3PEjhk7sm6i.compress(BWa9vHSXf2UF1Gke7VCNOZhYTA8Ry)
	try: kC7JunVyQdExXTaB,SCnhp2blgkLJrvcqKmXdE = nIQHkPemMvAWusCczU9ZgY(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
	except: return
	while ttOu147wErcBvPaSMUY(u"࡚ࡲࡶࡧౢ"):
		try:
			SCnhp2blgkLJrvcqKmXdE.execute(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠱࠰࠸ై"))
	SCnhp2blgkLJrvcqKmXdE.execute(WmaPChRdQk3YcXwI6zS(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+d06F4MY9cKw5CrvAoNU+VH9MDo5z1kxNF07uRJI(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if y0xjlrJhM954:
		SCnhp2blgkLJrvcqKmXdE.executemany(EEvLoMzFqrlKce(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+d06F4MY9cKw5CrvAoNU+ttOu147wErcBvPaSMUY(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),yvuYVFPClBd03mc8)
		SCnhp2blgkLJrvcqKmXdE.executemany(l5mQdjWyczr7UJVnTp(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+d06F4MY9cKw5CrvAoNU+PiFkQ5pCJy7fbX(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),SS7cKmHlzATRB5CoYVkrjbLM8e2xJ)
	else:
		if efTYtsigQALPBJm3pa2w1q6OnK:
			gpHzj2W130xYMmtlsFCU8udIAQw = (str(fYkGUQ4d5z),)
			SCnhp2blgkLJrvcqKmXdE.execute(VH9MDo5z1kxNF07uRJI(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+d06F4MY9cKw5CrvAoNU+HH4JMrUDp3lq6hQ(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),gpHzj2W130xYMmtlsFCU8udIAQw)
			gpHzj2W130xYMmtlsFCU8udIAQw = (efTYtsigQALPBJm3pa2w1q6OnK+EEd0FZyfticlDPAMp2HbNesx,str(fYkGUQ4d5z),xtwO1UCjBpsKEG32RrLzfMv06b)
			SCnhp2blgkLJrvcqKmXdE.execute(vatyjK4hHAoZJ7rOq2lis(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+d06F4MY9cKw5CrvAoNU+sbgu4D2RFMYKm(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),gpHzj2W130xYMmtlsFCU8udIAQw)
		else:
			gpHzj2W130xYMmtlsFCU8udIAQw = (xtwO1UCjBpsKEG32RrLzfMv06b,str(fYkGUQ4d5z))
			SCnhp2blgkLJrvcqKmXdE.execute(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+d06F4MY9cKw5CrvAoNU+Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),gpHzj2W130xYMmtlsFCU8udIAQw)
	kC7JunVyQdExXTaB.commit()
	kC7JunVyQdExXTaB.close()
	return
def YFKUsh8z1kpE4u3OWZ0VyCXIacH9d(Z402tBVhQi):
	if mmIKCGujwM: import urllib.parse as PmubI8yBjkSt5RvAZnsOGL
	else: import urllib as PmubI8yBjkSt5RvAZnsOGL
	NB3Ku9rsiE8M = PmubI8yBjkSt5RvAZnsOGL.urlencode(Z402tBVhQi)
	return NB3Ku9rsiE8M
etDHUWmj75gkduPCaZGJw9X1p = EEvLoMzFqrlKce(u"ࠪࠫ୪")
def pidYDcjvhgVfqb3GeWSAOH5J(dCmKxk9BW310AXu4bJUHfY,VXb3zNxluwGApD2HhWP8dJfLIYj=vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࠬ୫"),NeAPH6nUIXcCskioGTO87=PiFkQ5pCJy7fbX(u"ࠬ࠭୬")):
	sfxP0pzQeG4rl89ZuAbYoBW7F1T = VXb3zNxluwGApD2HhWP8dJfLIYj not in [oAXJCYqPgyGDtT(u"࠭ࡍ࠴ࡗࠪ୭"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global etDHUWmj75gkduPCaZGJw9X1p
	if not NeAPH6nUIXcCskioGTO87: NeAPH6nUIXcCskioGTO87 = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	etDHUWmj75gkduPCaZGJw9X1p,baWPgk0EKs,f7c9BhSi4ZjqWMDYFK1x = HVibA2ES8lY(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),WmaPChRdQk3YcXwI6zS(u"ࠪࠫୱ"),EmK3ObA0cwv9Wy(u"ࠫࠬ୲")
	if len(dCmKxk9BW310AXu4bJUHfY)==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠵౉"):
		gz1flZwncVutokL59RaGS3WeK,RR7b6zJOCs2Gfmhjen8DQH0,f7c9BhSi4ZjqWMDYFK1x = dCmKxk9BW310AXu4bJUHfY
		if RR7b6zJOCs2Gfmhjen8DQH0: baWPgk0EKs = VOq8Ekue4F(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+RR7b6zJOCs2Gfmhjen8DQH0+sDiKwnHcSlYFgWCy1Ak(u"࠭ࠠ࡞ࠩ୴")
	else: gz1flZwncVutokL59RaGS3WeK,RR7b6zJOCs2Gfmhjen8DQH0,f7c9BhSi4ZjqWMDYFK1x = dCmKxk9BW310AXu4bJUHfY,EEvLoMzFqrlKce(u"ࠧࠨ୵"),EEvLoMzFqrlKce(u"ࠨࠩ୶")
	gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK.replace(N9olEh0ZMtpOivVfBLK(u"ࠩࠨ࠶࠵࠭୷"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠪࠤࠬ୸"))
	rUTwZXB4AoFRzdjnEPD2iNJKs = WFNUBRjloE1(gz1flZwncVutokL59RaGS3WeK)
	if VXb3zNxluwGApD2HhWP8dJfLIYj not in [l5mQdjWyczr7UJVnTp(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),VH9MDo5z1kxNF07uRJI(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if VXb3zNxluwGApD2HhWP8dJfLIYj!=BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK.replace(h5huy6MiXPNfQJF8(u"ࠧࠡࠩ୼"),FIHNSc5iuoZanQ2Ytl(u"ࠨࠧ࠵࠴ࠬ୽"))
		GZvEITHSg5U3rVwQ(ttOu147wErcBvPaSMUY(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+HVibA2ES8lY(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+gz1flZwncVutokL59RaGS3WeK+f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࠥࡣࠧ஀")+baWPgk0EKs)
		if rUTwZXB4AoFRzdjnEPD2iNJKs==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and VXb3zNxluwGApD2HhWP8dJfLIYj not in [BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࡉࡑࡖ࡙ࠫஂ"),ttOu147wErcBvPaSMUY(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from skIgoAvZ9t import w7py6bdKn1jqMSfh,sSOy1pju5PJ,fYPz7RldWQVHBktZAexwvCL8Np3D
			n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = w7py6bdKn1jqMSfh(gz1flZwncVutokL59RaGS3WeK)
			TnOEcKMSxN = len(M7oS6tLhdx3ke8qPX4mFA)
			if TnOEcKMSxN>oAXJCYqPgyGDtT(u"࠴ొ"):
				tzgWIKy5xQL2kjm = sSOy1pju5PJ(vatyjK4hHAoZJ7rOq2lis(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(TnOEcKMSxN)+EEvLoMzFqrlKce(u"้้ࠩࠣ็ࠩࠨஅ"), n7CuHMSJpiR9fP0jvNEIyDUL)
				if tzgWIKy5xQL2kjm==-HH4JMrUDp3lq6hQ(u"࠵ో"):
					fYPz7RldWQVHBktZAexwvCL8Np3D(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),EmK3ObA0cwv9Wy(u"ࠫࠬஇ"))
					return etDHUWmj75gkduPCaZGJw9X1p
			else: tzgWIKy5xQL2kjm = h5huy6MiXPNfQJF8(u"࠵ౌ")
			gz1flZwncVutokL59RaGS3WeK = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
			if n7CuHMSJpiR9fP0jvNEIyDUL[S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠶్")]!=ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠳࠱ࠨஈ"):
				GZvEITHSg5U3rVwQ(EmK3ObA0cwv9Wy(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+PiFkQ5pCJy7fbX(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+n7CuHMSJpiR9fP0jvNEIyDUL[tzgWIKy5xQL2kjm]+oAXJCYqPgyGDtT(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+gz1flZwncVutokL59RaGS3WeK+HH4JMrUDp3lq6hQ(u"ࠩࠣࡡࠬ஌"))
		if ttOu147wErcBvPaSMUY(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in gz1flZwncVutokL59RaGS3WeK: gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+ttOu147wErcBvPaSMUY(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࡮ࡴࡵࡲࠪஏ") in gz1flZwncVutokL59RaGS3WeK.lower() and mNkfJnpOrad7hT6PYyciwsSDQ(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in gz1flZwncVutokL59RaGS3WeK and ZhqJoOtcmTVID65HwnLj(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in gz1flZwncVutokL59RaGS3WeK:
			if mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in gz1flZwncVutokL59RaGS3WeK and f5uqIoSJzWBOFyrY78RXmVb(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in gz1flZwncVutokL59RaGS3WeK.lower():
				if HVibA2ES8lY(u"ࠪࢀࠬஔ") not in gz1flZwncVutokL59RaGS3WeK: gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+h5huy6MiXPNfQJF8(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if HVibA2ES8lY(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in gz1flZwncVutokL59RaGS3WeK.lower() and VXb3zNxluwGApD2HhWP8dJfLIYj not in [sDiKwnHcSlYFgWCy1Ak(u"ࠧࡊࡒࡗ࡚ࠬ஘"),VH9MDo5z1kxNF07uRJI(u"ࠨࡏ࠶࡙ࠬங")]:
				if f5uqIoSJzWBOFyrY78RXmVb(u"ࠩࡿࠫச") not in gz1flZwncVutokL59RaGS3WeK: gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: gz1flZwncVutokL59RaGS3WeK = gz1flZwncVutokL59RaGS3WeK+f5uqIoSJzWBOFyrY78RXmVb(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	GZvEITHSg5U3rVwQ(N9olEh0ZMtpOivVfBLK(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+sDiKwnHcSlYFgWCy1Ak(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+gz1flZwncVutokL59RaGS3WeK+VH9MDo5z1kxNF07uRJI(u"ࠧࠡ࡟ࠪட"))
	BLSwaQtFfdRPE = Ko1p5u9jwG6rF.ListItem()
	NeAPH6nUIXcCskioGTO87,M2WHwz4yUIF,ZZ6GOtiQdngANT,LpFs39kBG4KDqAQ16t8mYe5v,LEITsRo5fbG3,wKQdIUxYCPvh9fkTleu,jdyz6niLR94Hx,VV8quHYD2SZxs,oWGHs0vkTKb97X1m6iPAU = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
	if VXb3zNxluwGApD2HhWP8dJfLIYj not in [cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if ggl6zFuXNdYTDieHCqGKRnVx: CMH4osYT06Q3B9 = cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: CMH4osYT06Q3B9 = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		BLSwaQtFfdRPE.setProperty(CMH4osYT06Q3B9, sDiKwnHcSlYFgWCy1Ak(u"ࠬ࠭த"))
		BLSwaQtFfdRPE.setMimeType(TWexH5PhS1(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if XK3HqaTnjpyIAuhw67CmdvBM<EEvLoMzFqrlKce(u"࠲࠱౎"): BLSwaQtFfdRPE.setInfo(sDiKwnHcSlYFgWCy1Ak(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			AqFE42O83N6f = BLSwaQtFfdRPE.getVideoInfoTag()
			AqFE42O83N6f.setMediaType(h5huy6MiXPNfQJF8(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		BLSwaQtFfdRPE.setArt({VOq8Ekue4F(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):LEITsRo5fbG3,l5mQdjWyczr7UJVnTp(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):LEITsRo5fbG3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):LEITsRo5fbG3,EmK3ObA0cwv9Wy(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):LEITsRo5fbG3,N9olEh0ZMtpOivVfBLK(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):LEITsRo5fbG3,ZhqJoOtcmTVID65HwnLj(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):LEITsRo5fbG3,f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):LEITsRo5fbG3,vatyjK4hHAoZJ7rOq2lis(u"ࠫ࡮ࡩ࡯࡯ࠩற"):LEITsRo5fbG3})
		if rUTwZXB4AoFRzdjnEPD2iNJKs in [mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࠴࡭ࡱࡦࠪல"),FIHNSc5iuoZanQ2Ytl(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: BLSwaQtFfdRPE.setContentLookup(N9olEh0ZMtpOivVfBLK(u"ࡔࡳࡷࡨౣ"))
		else: BLSwaQtFfdRPE.setContentLookup(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡇࡣ࡯ࡷࡪ౤"))
		from TRa6GJnHO1 import PKyL2wI9WdZEbzs4t5muq
		if EEvLoMzFqrlKce(u"ࠧࡳࡶࡰࡴࠬழ") in gz1flZwncVutokL59RaGS3WeK:
			PKyL2wI9WdZEbzs4t5muq(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡈࡤࡰࡸ࡫౥"))
		elif rUTwZXB4AoFRzdjnEPD2iNJKs==BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩ࠱ࡱࡵࡪࠧஶ") or PiFkQ5pCJy7fbX(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in gz1flZwncVutokL59RaGS3WeK:
			PKyL2wI9WdZEbzs4t5muq(ZhqJoOtcmTVID65HwnLj(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),sbgu4D2RFMYKm(u"ࡉࡥࡱࡹࡥ౦"))
			BLSwaQtFfdRPE.setProperty(CMH4osYT06Q3B9,VOq8Ekue4F(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			BLSwaQtFfdRPE.setProperty(cbngtp9sqYi0DjeEMLRHJruKxm(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧ࡮ࡲࡧࠫ஻"))
		if RR7b6zJOCs2Gfmhjen8DQH0:
			BLSwaQtFfdRPE.setSubtitles([RR7b6zJOCs2Gfmhjen8DQH0])
	if NeAPH6nUIXcCskioGTO87==EEvLoMzFqrlKce(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and VXb3zNxluwGApD2HhWP8dJfLIYj==sbgu4D2RFMYKm(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		etDHUWmj75gkduPCaZGJw9X1p = VH9MDo5z1kxNF07uRJI(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		VXb3zNxluwGApD2HhWP8dJfLIYj = ZhqJoOtcmTVID65HwnLj(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif NeAPH6nUIXcCskioGTO87==N9olEh0ZMtpOivVfBLK(u"ࠬࡼࡩࡥࡧࡲࠫீ") and VV8quHYD2SZxs.startswith(VH9MDo5z1kxNF07uRJI(u"࠭࠶ࠨு")):
		etDHUWmj75gkduPCaZGJw9X1p = vatyjK4hHAoZJ7rOq2lis(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		VXb3zNxluwGApD2HhWP8dJfLIYj = VXb3zNxluwGApD2HhWP8dJfLIYj+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨࡡࡇࡐࠬ௃")
	if etDHUWmj75gkduPCaZGJw9X1p!=g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): PHMnCmaZ94fJ8gFl2dzLyvsrA()
	heQwLGOqfntsVdAZCvbHxk14 = nRzPZsb3VILaWq6M7h4jo1ESCk0()
	if heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p: return TWexH5PhS1(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	heQwLGOqfntsVdAZCvbHxk14.mRfsQA9hItb8olWTxeHPwJjO2iCrkV(VXb3zNxluwGApD2HhWP8dJfLIYj)
	if NeAPH6nUIXcCskioGTO87==l5mQdjWyczr7UJVnTp(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not VV8quHYD2SZxs.startswith(ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠼ࠧே")):
		BLSwaQtFfdRPE.setPath(gz1flZwncVutokL59RaGS3WeK)
		GZvEITHSg5U3rVwQ(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+TWexH5PhS1(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+gz1flZwncVutokL59RaGS3WeK+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠨࠢࡠࠫொ"))
		I2XjYiNOlmyKG1EhR70q53vZ.setResolvedUrl(SMfClzGKOB12H3r9sRPvAJgwq6,vatyjK4hHAoZJ7rOq2lis(u"ࡘࡷࡻࡥ౧"),BLSwaQtFfdRPE)
	elif NeAPH6nUIXcCskioGTO87==EEvLoMzFqrlKce(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		GZvEITHSg5U3rVwQ(WmaPChRdQk3YcXwI6zS(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+oAXJCYqPgyGDtT(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+gz1flZwncVutokL59RaGS3WeK+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࠦ࡝ࠨ௎"))
		heQwLGOqfntsVdAZCvbHxk14.play(gz1flZwncVutokL59RaGS3WeK,BLSwaQtFfdRPE)
	UkYj1KP0ou4q9rVfEgn2JQHI56BG = EEvLoMzFqrlKce(u"ࡋࡧ࡬ࡴࡧ౨")
	if etDHUWmj75gkduPCaZGJw9X1p==WmaPChRdQk3YcXwI6zS(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from fNZBsRdigo import DDRAbXNJH8FZcewailvokCyOz94x
		UkYj1KP0ou4q9rVfEgn2JQHI56BG = DDRAbXNJH8FZcewailvokCyOz94x(gz1flZwncVutokL59RaGS3WeK,rUTwZXB4AoFRzdjnEPD2iNJKs,VXb3zNxluwGApD2HhWP8dJfLIYj)
		if UkYj1KP0ou4q9rVfEgn2JQHI56BG: PHMnCmaZ94fJ8gFl2dzLyvsrA()
	else:
		hZYTKSaABQCofcrFlgsI,etDHUWmj75gkduPCaZGJw9X1p,VDYE9Sp4MGyBOb0zdAtjLgPn,CPAWwTr2hjcz8Z9EdFD6gMXGfa,CaNJAcMBOpY = l5mQdjWyczr7UJVnTp(u"࠱౏"),PiFkQ5pCJy7fbX(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),oAXJCYqPgyGDtT(u"ࡌࡡ࡭ࡵࡨ౩"),N9olEh0ZMtpOivVfBLK(u"࠴࠴࠵࠶౑"),f5uqIoSJzWBOFyrY78RXmVb(u"࠵࠳࠴࠵࠶౐")
		if sfxP0pzQeG4rl89ZuAbYoBW7F1T: from skIgoAvZ9t import fYPz7RldWQVHBktZAexwvCL8Np3D
		while hZYTKSaABQCofcrFlgsI<CaNJAcMBOpY:
			EO9Rts0AaGuk1qpPLXCY.sleep(CPAWwTr2hjcz8Z9EdFD6gMXGfa)
			hZYTKSaABQCofcrFlgsI += CPAWwTr2hjcz8Z9EdFD6gMXGfa
			if heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p==EmK3ObA0cwv9Wy(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not VDYE9Sp4MGyBOb0zdAtjLgPn:
				if sfxP0pzQeG4rl89ZuAbYoBW7F1T: fYPz7RldWQVHBktZAexwvCL8Np3D(Xl3drKyI9HkDiPEf8RTjwu(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࠫ௓"),D1vBJgya85Yh4cRTCkIMKtWLSeH=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠻࠺࠶౒"))
				GZvEITHSg5U3rVwQ(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+ZEiR0StquOzca9lvPAndYIX(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+gz1flZwncVutokL59RaGS3WeK+WmaPChRdQk3YcXwI6zS(u"࠭ࠠ࡞ࠩ௖")+baWPgk0EKs)
				VDYE9Sp4MGyBOb0zdAtjLgPn = EEvLoMzFqrlKce(u"ࡔࡳࡷࡨ౪")
			elif heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p in [f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),f5uqIoSJzWBOFyrY78RXmVb(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				GZvEITHSg5U3rVwQ(HVibA2ES8lY(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+vatyjK4hHAoZJ7rOq2lis(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+gz1flZwncVutokL59RaGS3WeK+h5huy6MiXPNfQJF8(u"ࠫࠥࡣࠧ௛")+baWPgk0EKs)
				break
			elif heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p==WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				GZvEITHSg5U3rVwQ(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+oAXJCYqPgyGDtT(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+gz1flZwncVutokL59RaGS3WeK+HH4JMrUDp3lq6hQ(u"ࠨࠢࡠࠫ௟")+baWPgk0EKs)
				if sfxP0pzQeG4rl89ZuAbYoBW7F1T: fYPz7RldWQVHBktZAexwvCL8Np3D(TWexH5PhS1(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠫ௡"),D1vBJgya85Yh4cRTCkIMKtWLSeH=WmaPChRdQk3YcXwI6zS(u"࠶࠸࠵࠱౓"))
				break
			elif heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p==EEvLoMzFqrlKce(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				GZvEITHSg5U3rVwQ(f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+ttOu147wErcBvPaSMUY(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+gz1flZwncVutokL59RaGS3WeK+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if sfxP0pzQeG4rl89ZuAbYoBW7F1T: fYPz7RldWQVHBktZAexwvCL8Np3D(oAXJCYqPgyGDtT(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠩࠪ௧"),D1vBJgya85Yh4cRTCkIMKtWLSeH=S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠲࠶࠲౔"))
			GZvEITHSg5U3rVwQ(WmaPChRdQk3YcXwI6zS(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+EmK3ObA0cwv9Wy(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+gz1flZwncVutokL59RaGS3WeK+sbgu4D2RFMYKm(u"ࠬࠦ࡝ࠨ௪")+baWPgk0EKs)
			etDHUWmj75gkduPCaZGJw9X1p = EmK3ObA0cwv9Wy(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if etDHUWmj75gkduPCaZGJw9X1p in [EEvLoMzFqrlKce(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p in [ZhqJoOtcmTVID65HwnLj(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or UkYj1KP0ou4q9rVfEgn2JQHI56BG:
		if heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p==ZhqJoOtcmTVID65HwnLj(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): VXb3zNxluwGApD2HhWP8dJfLIYj = VXb3zNxluwGApD2HhWP8dJfLIYj+WmaPChRdQk3YcXwI6zS(u"ࠫࡤ࡚ࡓࠨ௰")
		z8zCauMw6AGm7ZRDFO4NeJ0xrLt = cH3wtyn51rUbuWOdLo89Z(VXb3zNxluwGApD2HhWP8dJfLIYj)
	else: exec(ZEiR0StquOzca9lvPAndYIX(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return heQwLGOqfntsVdAZCvbHxk14.etDHUWmj75gkduPCaZGJw9X1p
def WFNUBRjloE1(gz1flZwncVutokL59RaGS3WeK):
	rUTwZXB4AoFRzdjnEPD2iNJKs = T072lCzjYiuaeFtmJGV.findall(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭௲"),gz1flZwncVutokL59RaGS3WeK.lower(),T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	if rUTwZXB4AoFRzdjnEPD2iNJKs: rUTwZXB4AoFRzdjnEPD2iNJKs = rUTwZXB4AoFRzdjnEPD2iNJKs[HVibA2ES8lY(u"࠰ౕ")][HVibA2ES8lY(u"࠰ౕ")]
	else: rUTwZXB4AoFRzdjnEPD2iNJKs = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠨ௳")
	return rUTwZXB4AoFRzdjnEPD2iNJKs
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'CIMANOW'
JJCLnkX4TozH7Bsjivfe = '_CMN_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['قائمتي']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==300: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==301: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==302: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==303: cLCisPE3lX = qEsyT1NwX3BfbhQZkl5vMH(url)
	elif mode==304: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==305: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==306: cLCisPE3lX = KX1gtPyHnD0()
	elif mode==309: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'لماذا الموقع بطيء','',306)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/home','','','','','CIMANOW-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<header>(.*?)</header>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('<li><a href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = title.strip(' ')
		if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,301)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	rzgXD1OfZMh0bp4A5P(HbiLZQKalC+'/home',qQXuaKpVrGLF3e5oidJ8YwDT0)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def KX1gtPyHnD0():
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def rzgXD1OfZMh0bp4A5P(url,qQXuaKpVrGLF3e5oidJ8YwDT0=''):
	if not qQXuaKpVrGLF3e5oidJ8YwDT0:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	F1FBMcYyaNIJ = 0
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(<section>.*?</section>)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			F1FBMcYyaNIJ += 1
			items = T072lCzjYiuaeFtmJGV.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for title,dJ6jKLompr,i8sFwPqo1vpEXR2VdHU5BmW in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in dJ6jKLompr:
					if Zsh7mUdwjHobLyMz6WKJGVl1cgeR.count('/category/')>0:
						JNSvF8Egp0xCHOR2b3 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
						for i8sFwPqo1vpEXR2VdHU5BmW in JNSvF8Egp0xCHOR2b3:
							title = i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-2]
							QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,301)
						continue
					else: i8sFwPqo1vpEXR2VdHU5BmW = url+'?sequence='+str(F1FBMcYyaNIJ)
				if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,302)
	else: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,qQXuaKpVrGLF3e5oidJ8YwDT0)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,qQXuaKpVrGLF3e5oidJ8YwDT0=''):
	if qQXuaKpVrGLF3e5oidJ8YwDT0=='':
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMANOW-TITLES-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if '?sequence=' in url:
		url,F1FBMcYyaNIJ = url.split('?sequence=')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(<section>.*?</section>)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[int(F1FBMcYyaNIJ)-1]
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"posts"(.*?)</body>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for i8sFwPqo1vpEXR2VdHU5BmW,data,o3gHuBtrRN in items:
		title = T072lCzjYiuaeFtmJGV.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,T072lCzjYiuaeFtmJGV.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = T072lCzjYiuaeFtmJGV.findall('title">.*?</em>(.*?)<',data,T072lCzjYiuaeFtmJGV.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = T072lCzjYiuaeFtmJGV.findall('title">(.*?)<',data,T072lCzjYiuaeFtmJGV.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = Nkuqp0boKj41i9(title)
		if title not in BBRwQhFnJ08q9YVxOSya:
			BBRwQhFnJ08q9YVxOSya.append(title)
			MwELA7bGROd1uohvUNKpsrDVWnSyf4 = i8sFwPqo1vpEXR2VdHU5BmW+data+o3gHuBtrRN
			if '/selary/' in MwELA7bGROd1uohvUNKpsrDVWnSyf4 or 'مسلسل' in MwELA7bGROd1uohvUNKpsrDVWnSyf4 or '"episode"' in MwELA7bGROd1uohvUNKpsrDVWnSyf4:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,303,o3gHuBtrRN)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,305,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<li><a href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,302)
	return
def qEsyT1NwX3BfbhQZkl5vMH(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	name = T072lCzjYiuaeFtmJGV.findall('<title>(.*?)</title>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<section(.*?)</section>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(items)>1:
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,304)
		else: UAB8vizclM6XG4Pw(url)
	return
def UAB8vizclM6XG4Pw(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if '/selary/' not in url:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"episodes"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,305)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"details"(.*?)"related"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			title = title.replace('\n','').strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,305,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	ll9khUfx3MjZ = url+'watching/'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',ll9khUfx3MjZ,'','','','','CIMANOW-PLAY-5th')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	M7oS6tLhdx3ke8qPX4mFA = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"download"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.replace('\n','').strip(' ')
			Q5OAspyiXV1lx8930qLGD = T072lCzjYiuaeFtmJGV.findall('\d\d\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if Q5OAspyiXV1lx8930qLGD:
				Q5OAspyiXV1lx8930qLGD = '____'+Q5OAspyiXV1lx8930qLGD[0]
				title = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
			else: Q5OAspyiXV1lx8930qLGD = ''
			K9K307bTvRVtO6i = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'+Q5OAspyiXV1lx8930qLGD
			M7oS6tLhdx3ke8qPX4mFA.append(K9K307bTvRVtO6i)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"watch"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('"embed".*?src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
			title = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__embed'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		kkH5sRPxhASFowLONy4 = [HbiLZQKalC+'/wp-content/themes/Cima%20Now%20New/core.php']
		if kkH5sRPxhASFowLONy4:
			items = T072lCzjYiuaeFtmJGV.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for prZUeN9FojstVTxf0EJQBRq4zdb,id,title in items:
				title = title.replace('\n','').strip(' ')
				i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[0]+'?action=switch&index='+prZUeN9FojstVTxf0EJQBRq4zdb+'&id='+id+'?named='+title+'__watch'
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC + '/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
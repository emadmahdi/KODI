# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'FASELHD1'
headers = {'User-Agent':''}
JJCLnkX4TozH7Bsjivfe = '_FH1_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['جوائز الأوسكار','المراجعات','wwe']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==570: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==571: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==572: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==573: cLCisPE3lX = HNseQUBuMGwfXmRoqIkgjt5Z2V(url,text)
	elif mode==576: cLCisPE3lX = KX1gtPyHnD0()
	elif mode==579: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+'لماذا الموقع بطيء','',576)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	LL2d9tanw0mrxJBKAT63buD,url,WM1buqXnzf3Ba6Vp29l4gFD = NJviWdaAUb(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'faselhd1','فاصل إعلاني','dubbed-movies')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع',LL2d9tanw0mrxJBKAT63buD,579,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',LL2d9tanw0mrxJBKAT63buD,571,'','','featured1')
	items = T072lCzjYiuaeFtmJGV.findall('class="h3">(.*?)<.*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items:
		KK47FGdX1TDfkb3AjHOQqghE('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,571,'','','details1')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"menu-primary"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		ggBx2ykcHhZdVmeNQFnfs = T072lCzjYiuaeFtmJGV.findall('<li (.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		GSkb1Z2up37EPzDvWQT = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		H3ABEcMzfyqwF4Ug2ZYtK = 0
		for vAujiEeLZbowS2Xgp5830Yc in ggBx2ykcHhZdVmeNQFnfs:
			if H3ABEcMzfyqwF4Ug2ZYtK>0: QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',vAujiEeLZbowS2Xgp5830Yc,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
				if title=='': continue
				if any(EYn2siOeDvQTk8KpS0Jl in title.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
				title = GSkb1Z2up37EPzDvWQT[H3ABEcMzfyqwF4Ug2ZYtK]+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,571,'','','details2')
			H3ABEcMzfyqwF4Ug2ZYtK += 1
	return
def KX1gtPyHnD0():
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FASELHD1-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('class="h4">(.*?)</div>(.*?)"container"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not q9OCkWn6ruAvQLKDFUyxBME0: return
	if type=='filters':
		tmEVko4qsghUX6WLx8KG7fOTB = [qQXuaKpVrGLF3e5oidJ8YwDT0.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"homeSlide"(.*?)"container"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		kMpzodri5XQTF3uN,kkH5sRPxhASFowLONy4,lNwOdSoA6E = zip(*items)
		items = zip(kkH5sRPxhASFowLONy4,kMpzodri5XQTF3uN,lNwOdSoA6E)
	elif type=='featured2':
		title,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='details2' and len(q9OCkWn6ruAvQLKDFUyxBME0)>1:
		title = q9OCkWn6ruAvQLKDFUyxBME0[0][0]
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,571,'','','featured2')
		title = q9OCkWn6ruAvQLKDFUyxBME0[1][0]
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,571,'','','details3')
		return
	else:
		title,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[-1]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if any(EYn2siOeDvQTk8KpS0Jl in title.lower() for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI): continue
		o3gHuBtrRN = Bd2o0J6aOASWvuD9HzY(o3gHuBtrRN)
		o3gHuBtrRN = o3gHuBtrRN.split('?resize=')[0]
		title = Nkuqp0boKj41i9(title)
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|حلقة).\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if '/collections/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,571,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and type=='':
			title = '_MOD_'+XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
			title = title.strip(' –')
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,573,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif 'episodes/' in i8sFwPqo1vpEXR2VdHU5BmW or 'movies/' in i8sFwPqo1vpEXR2VdHU5BmW or 'hindi/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,572,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,573,o3gHuBtrRN)
	if type=='filters':
		re8PLYqIQ6hN1vk503OTJng = T072lCzjYiuaeFtmJGV.findall('"more_button_page":(.*?),',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if re8PLYqIQ6hN1vk503OTJng:
			count = re8PLYqIQ6hN1vk503OTJng[0]
			i8sFwPqo1vpEXR2VdHU5BmW = url+'/offset/'+count
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة أخرى',i8sFwPqo1vpEXR2VdHU5BmW,571,'','','filters')
	elif 'details' in type:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("class='pagination(.*?)</div>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall("href='(.*?)'.*?>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = 'صفحة '+Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,571,'','','details4')
	return
def HNseQUBuMGwfXmRoqIkgjt5Z2V(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i80ehylRFvHDAbXBpkIr = False
	if not type:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"seasonList"(.*?)"container"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if len(items)>1:
				LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
				i80ehylRFvHDAbXBpkIr = True
				for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,name,title in items:
					name = Nkuqp0boKj41i9(name)
					if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
					title = name+' - '+title
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,573,o3gHuBtrRN,'','episodes')
	if type=='episodes' or not i80ehylRFvHDAbXBpkIr:
		BB5dqMe8jgLxwSvk = T072lCzjYiuaeFtmJGV.findall('"posterImg".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if BB5dqMe8jgLxwSvk: o3gHuBtrRN = BB5dqMe8jgLxwSvk[0]
		else: o3gHuBtrRN = ''
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"epAll"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				title = Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,572,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	MfIDplCLUGK91vjO,f9BQszg5ZIV1xeAjY,kk10UWmPHCF38aNVOdSpRIbQj6xE2 = [],[],[]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','FASELHD1-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ycfig7QNelWkS8Xm = T072lCzjYiuaeFtmJGV.findall('مستوى المشاهدة.*?">(.*?)</span>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ycfig7QNelWkS8Xm:
		Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('"tag">(.*?)</a>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"videoRow"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&img=')[0]
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=__embed')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="streamHeader(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall("href = '(.*?)'.*?</i>(.*?)</a>",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&img=')[0]
			name = name.strip(' ')
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__watch')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="downloadLinks(.*?)blackwindow',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</span>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&img=')[0]
			MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__download')
	for U4PJWex3u72NlFXoO1fqAmh in MfIDplCLUGK91vjO:
		i8sFwPqo1vpEXR2VdHU5BmW,name = U4PJWex3u72NlFXoO1fqAmh.split('?named')
		if i8sFwPqo1vpEXR2VdHU5BmW not in f9BQszg5ZIV1xeAjY:
			f9BQszg5ZIV1xeAjY.append(i8sFwPqo1vpEXR2VdHU5BmW)
			kk10UWmPHCF38aNVOdSpRIbQj6xE2.append(U4PJWex3u72NlFXoO1fqAmh)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(kk10UWmPHCF38aNVOdSpRIbQj6xE2,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/?s='+search
	LL2d9tanw0mrxJBKAT63buD,ll9khUfx3MjZ,mnV8BCoXEJxyAZtQhU62RpbraOY = NJviWdaAUb(GGXxhdg3JCamPIFepybjZ,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ,'details5')
	return
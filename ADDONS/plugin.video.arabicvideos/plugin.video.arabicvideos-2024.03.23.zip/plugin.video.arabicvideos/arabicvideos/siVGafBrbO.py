# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'KATKOTTV'
JJCLnkX4TozH7Bsjivfe = '_KTV_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = []
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==810: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==811: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==812: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==813: cLCisPE3lX = sLjwXDR3mn4odYCa7EIiVKeZN5UgP(url)
	elif mode==819: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','KATKOTTV-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"primary-links"(.*?)"most-viewed"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<span>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,811)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"home-content"(.*?)"footer"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		BBRwQhFnJ08q9YVxOSya = []
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|حلقة).\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if 'episodes' not in type and XSCYbwaqRBtopUc9H2QZu86gA5N:
				title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
				title = title.replace('اون لاين','')
				if title not in BBRwQhFnJ08q9YVxOSya:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,813,o3gHuBtrRN)
					BBRwQhFnJ08q9YVxOSya.append(title)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,812,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("'pagination'(.*?)footer",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,811,'','',type)
	return
def sLjwXDR3mn4odYCa7EIiVKeZN5UgP(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"category".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW: Dhm1GLpdYu4xwZzSQlEtvNC3ga(i8sFwPqo1vpEXR2VdHU5BmW[0],'episodes')
	return
def JwYEQUDupG2WLPzHndc(url):
	MfIDplCLUGK91vjO = []
	ll9khUfx3MjZ = url+'?do=watch'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','KATKOTTV-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('" src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		fE9lhXGsySY5kH2CQ = T072lCzjYiuaeFtmJGV.findall('post=(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if fE9lhXGsySY5kH2CQ:
			fE9lhXGsySY5kH2CQ = eJ4h7nOpguFMH6z1IUEV2i.b64decode(fE9lhXGsySY5kH2CQ[0])
			if mmIKCGujwM: fE9lhXGsySY5kH2CQ = fE9lhXGsySY5kH2CQ.decode('utf8')
			fE9lhXGsySY5kH2CQ = cwiLy4IAVJj0pWCl7FGxokR('dict',fE9lhXGsySY5kH2CQ)
			kkH5sRPxhASFowLONy4 = fE9lhXGsySY5kH2CQ['servers']
			lNwOdSoA6E = list(kkH5sRPxhASFowLONy4.keys())
			kkH5sRPxhASFowLONy4 = list(kkH5sRPxhASFowLONy4.values())
			EvepJ1lSmD = zip(lNwOdSoA6E,kkH5sRPxhASFowLONy4)
			for title,i8sFwPqo1vpEXR2VdHU5BmW in EvepJ1lSmD:
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
				MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
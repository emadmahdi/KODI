# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SHOOFMAX'
JJCLnkX4TozH7Bsjivfe = '_SHM_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
m0nJ6xfD21QG3FyNP4WlT7u = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][1]
Sc5G6syLeHohmZvd0IMCQpPBgu = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][2]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==50: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==51: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==52: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==53: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==55: cLCisPE3lX = GyPIhn3jTW1l()
	elif mode==56: cLCisPE3lX = cb7Tt89aJGZYmO0Xl()
	elif mode==57: cLCisPE3lX = Zpf05iQWjnIOw(url,1)
	elif mode==58: cLCisPE3lX = Zpf05iQWjnIOw(url,2)
	elif mode==59: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المسلسلات','',56)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'الافلام','',55)
	return ''
def GyPIhn3jTW1l():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'احدث الافلام',HbiLZQKalC+'/movie/1/newest',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'افلام رائجة',HbiLZQKalC+'/movie/1/popular',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اخر اضافات الافلام',HbiLZQKalC+'/movie/1/latest',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'افلام كلاسيكية',HbiLZQKalC+'/movie/1/classic',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار افلام مرتبة بسنة الانتاج',HbiLZQKalC+'/movie/1/yop',57)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار افلام مرتبة بالافضل تقييم',HbiLZQKalC+'/movie/1/review',57)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار افلام مرتبة بالاكثر مشاهدة',HbiLZQKalC+'/movie/1/views',57)
	return
def cb7Tt89aJGZYmO0Xl():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'احدث المسلسلات',HbiLZQKalC+'/series/1/newest',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رائجة',HbiLZQKalC+'/series/1/popular',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اخر اضافات المسلسلات',HbiLZQKalC+'/series/1/latest',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات كلاسيكية',HbiLZQKalC+'/series/1/classic',51)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار مسلسلات مرتبة بسنة الانتاج',HbiLZQKalC+'/series/1/yop',57)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار مسلسلات مرتبة بالافضل تقييم',HbiLZQKalC+'/series/1/review',57)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'اختيار مسلسلات مرتبة بالاكثر مشاهدة',HbiLZQKalC+'/series/1/views',57)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	if '?' in url:
		eHquV9G0n2wlLjOvC5PUW = url.split('?')
		url = eHquV9G0n2wlLjOvC5PUW[0]
		filter = '?' + K3PukgCEDY(eHquV9G0n2wlLjOvC5PUW[1],'=&:/%')
	else: filter = ''
	eHquV9G0n2wlLjOvC5PUW = url.split('/')
	sort,ffGe7cURW0lhJVvQAiw8IB,type = eHquV9G0n2wlLjOvC5PUW[-1],eHquV9G0n2wlLjOvC5PUW[-2],eHquV9G0n2wlLjOvC5PUW[-3]
	if sort in ['yop','review','views']:
		if type=='movie': yc2P5uiMAe0='فيلم'
		elif type=='series': yc2P5uiMAe0='مسلسل'
		url = HbiLZQKalC + '/genre/filter/' + K3PukgCEDY(yc2P5uiMAe0) + '/' + ffGe7cURW0lhJVvQAiw8IB + '/' + sort + filter
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','SHOOFMAX-TITLES-1st')
		items = T072lCzjYiuaeFtmJGV.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		uqGkDJpiln9UayVQzvj0h=0
		for id,title,Kz5ksgWDoMc7RJ9,o3gHuBtrRN in items:
			uqGkDJpiln9UayVQzvj0h += 1
			o3gHuBtrRN = Sc5G6syLeHohmZvd0IMCQpPBgu + '/v2/img/program/main/' + o3gHuBtrRN + '-2.jpg'
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC + '/program/' + id
			if type=='movie': QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,53,o3gHuBtrRN)
			if type=='series': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسل '+title,i8sFwPqo1vpEXR2VdHU5BmW+'?ep='+Kz5ksgWDoMc7RJ9+'='+title+'='+o3gHuBtrRN,52,o3gHuBtrRN)
	else:
		if type=='movie': yc2P5uiMAe0='movies'
		elif type=='series': yc2P5uiMAe0='series'
		url = m0nJ6xfD21QG3FyNP4WlT7u + '/json/selected/' + sort + '-' + yc2P5uiMAe0 + '-WW.json'
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','SHOOFMAX-TITLES-2nd')
		items = T072lCzjYiuaeFtmJGV.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		uqGkDJpiln9UayVQzvj0h=0
		for id,Kz5ksgWDoMc7RJ9,o3gHuBtrRN,title in items:
			uqGkDJpiln9UayVQzvj0h += 1
			o3gHuBtrRN = m0nJ6xfD21QG3FyNP4WlT7u + '/img/program/' + o3gHuBtrRN + '-2.jpg'
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC + '/program/' + id
			if type=='movie': QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,53,o3gHuBtrRN)
			elif type=='series': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسل '+title,i8sFwPqo1vpEXR2VdHU5BmW+'?ep='+Kz5ksgWDoMc7RJ9+'='+title+'='+o3gHuBtrRN,52,o3gHuBtrRN)
	title='صفحة '
	if uqGkDJpiln9UayVQzvj0h==16:
		for I5fxZD42mz9MludrRhQPOSo in range(1,13) :
			if not ffGe7cURW0lhJVvQAiw8IB==str(I5fxZD42mz9MludrRhQPOSo):
				url = HbiLZQKalC+'/genre/filter/'+type+'/'+str(I5fxZD42mz9MludrRhQPOSo)+'/'+sort + filter
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title+str(I5fxZD42mz9MludrRhQPOSo),url,51)
	return
def UAB8vizclM6XG4Pw(url):
	eHquV9G0n2wlLjOvC5PUW = url.split('=')
	Kz5ksgWDoMc7RJ9 = int(eHquV9G0n2wlLjOvC5PUW[1])
	name = rygO0TzuEdiPcQDWZ8awSjm(eHquV9G0n2wlLjOvC5PUW[2])
	name = name.replace('_MOD_مسلسل ','')
	o3gHuBtrRN = eHquV9G0n2wlLjOvC5PUW[3]
	url = url.split('?')[0]
	if Kz5ksgWDoMc7RJ9==0:
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','SHOOFMAX-EPISODES-1st')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<select(.*?)</select>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('option value="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		Kz5ksgWDoMc7RJ9 = int(items[-1])
	for XSCYbwaqRBtopUc9H2QZu86gA5N in range(Kz5ksgWDoMc7RJ9,0,-1):
		i8sFwPqo1vpEXR2VdHU5BmW = url + '?ep=' + str(XSCYbwaqRBtopUc9H2QZu86gA5N)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(XSCYbwaqRBtopUc9H2QZu86gA5N)
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,53,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'','','','SHOOFMAX-PLAY-1st')
	OI1cMz6LSHf4wuKj = T072lCzjYiuaeFtmJGV.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if OI1cMz6LSHf4wuKj:
		D1vBJgya85Yh4cRTCkIMKtWLSeH = OI1cMz6LSHf4wuKj[1].replace('T','    ')
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+D1vBJgya85Yh4cRTCkIMKtWLSeH)
		return
	FvtAYhnMKmJSTLoI9G8a3y,jWqXyEKowt85RCOvYcnV0PuBD2IL = [],[]
	Dv6LexiBl7MpWqP3THZdKyNI0 = T072lCzjYiuaeFtmJGV.findall('var origin_link = "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	M8RKYBCTQj4WxNrsobztn91UH = T072lCzjYiuaeFtmJGV.findall('var backup_origin_link = "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('hls: (.*?)_link\+"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for dATnilvcrXxmZ1k5EP0KgBFDqYpy6,i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
		if 'backup' in dATnilvcrXxmZ1k5EP0KgBFDqYpy6:
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = 'backup server'
			url = M8RKYBCTQj4WxNrsobztn91UH + i8sFwPqo1vpEXR2VdHU5BmW
		else:
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = 'main server'
			url = Dv6LexiBl7MpWqP3THZdKyNI0 + i8sFwPqo1vpEXR2VdHU5BmW
		if '.m3u8' in url:
			FvtAYhnMKmJSTLoI9G8a3y.append(url)
			jWqXyEKowt85RCOvYcnV0PuBD2IL.append('m3u8  '+dATnilvcrXxmZ1k5EP0KgBFDqYpy6)
	kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	kkH5sRPxhASFowLONy4 += T072lCzjYiuaeFtmJGV.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for dATnilvcrXxmZ1k5EP0KgBFDqYpy6,i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
		filename = i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in dATnilvcrXxmZ1k5EP0KgBFDqYpy6:
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = 'backup server'
			url = M8RKYBCTQj4WxNrsobztn91UH + i8sFwPqo1vpEXR2VdHU5BmW
		else:
			dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = 'main server'
			url = Dv6LexiBl7MpWqP3THZdKyNI0 + i8sFwPqo1vpEXR2VdHU5BmW
		FvtAYhnMKmJSTLoI9G8a3y.append(url)
		jWqXyEKowt85RCOvYcnV0PuBD2IL.append('mp4  '+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'  '+filename)
	tzgWIKy5xQL2kjm = sSOy1pju5PJ('Select Video Quality:', jWqXyEKowt85RCOvYcnV0PuBD2IL)
	if tzgWIKy5xQL2kjm == -1 : return
	url = FvtAYhnMKmJSTLoI9G8a3y[tzgWIKy5xQL2kjm]
	pidYDcjvhgVfqb3GeWSAOH5J(url,nO6ukabcldeU,'video')
	return
def Zpf05iQWjnIOw(url,type):
	if 'series' in url: ll9khUfx3MjZ = HbiLZQKalC + '/genre/مسلسل'
	else: ll9khUfx3MjZ = HbiLZQKalC + '/genre/فيلم'
	ll9khUfx3MjZ = K3PukgCEDY(ll9khUfx3MjZ)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('subgenre(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type==2: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('country(.*?)div',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('option value="(.*?)">(.*?)</option',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if type==1:
		for C0FGQJnAumfvOZLoaq1bVtR5MP,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url+'?subgenre='+C0FGQJnAumfvOZLoaq1bVtR5MP,58)
	elif type==2:
		url,C0FGQJnAumfvOZLoaq1bVtR5MP = url.split('?')
		for jOxCyaFu0HoKVPi425htBsvmgGJe,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url+'?country='+jOxCyaFu0HoKVPi425htBsvmgGJe+'&'+C0FGQJnAumfvOZLoaq1bVtR5MP,51)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search: search = NWs7KpjXGnxYylofHtd5U3wDh()
	if not search: return
	xC2GuEcJKk3t4Uh = search.replace(' ','%20')
	url = HbiLZQKalC+'/search?q='+xC2GuEcJKk3t4Uh
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('general-body(.*?)search-bottom-padding',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			url = HbiLZQKalC + i8sFwPqo1vpEXR2VdHU5BmW
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+K3PukgCEDY(title)+'='+o3gHuBtrRN
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,52,o3gHuBtrRN)
				else:
					title = '_MOD_فيلم '+title
					QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,url,53,o3gHuBtrRN)
	return
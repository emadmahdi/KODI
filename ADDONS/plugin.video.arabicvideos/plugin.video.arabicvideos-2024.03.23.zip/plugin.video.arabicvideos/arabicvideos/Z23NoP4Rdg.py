# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SHAHIDNEWS'
JJCLnkX4TozH7Bsjivfe = '_SHN_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['قنوات فضائية','فارسكو','Show more']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==580: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==581: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==582: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==583: cLCisPE3lX = UAB8vizclM6XG4Pw(url,text)
	elif mode==584: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==589: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','SHAHIDNEWS-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',589,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('/category.php">(.*?)"navslide-divider"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("'dropdown-menu'(.*?)</ul>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for MwELA7bGROd1uohvUNKpsrDVWnSyf4 in tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace(MwELA7bGROd1uohvUNKpsrDVWnSyf4,'')
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,584)
	return
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHAHIDNEWS-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"caret"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('"presentation"','</ul>')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = [('',Zsh7mUdwjHobLyMz6WKJGVl1cgeR)]
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for YvGlnjICiDMQz,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if YvGlnjICiDMQz: YvGlnjICiDMQz = YvGlnjICiDMQz+': '
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = YvGlnjICiDMQz+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,581)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"pm-category-subcats"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(items)<30:
			QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,581)
	if not GVznW0jE3yMFaqK2uZvw1HBrtC and not q9OCkWn6ruAvQLKDFUyxBME0: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,iYvJPtR357SbyQf1=''):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHAHIDNEWS-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(data-echo=".*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"BlocksList"(.*?)"titleSectionCon"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="pm-grid"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="pm-related"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not items: items = T072lCzjYiuaeFtmJGV.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW).strip('/')
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
		if 'http' not in o3gHuBtrRN: o3gHuBtrRN = LL2d9tanw0mrxJBKAT63buD+'/'+o3gHuBtrRN.strip('/')
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,582,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'الحلقة' in title:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,583,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/movseries/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,581,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,583,o3gHuBtrRN)
	if iYvJPtR357SbyQf1 not in ['featured_movies','featured_series']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				title = Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,581)
		sc8WJeUnfo6MuLH1ZiOkhVdgP7 = T072lCzjYiuaeFtmJGV.findall('showmore" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if sc8WJeUnfo6MuLH1ZiOkhVdgP7:
			i8sFwPqo1vpEXR2VdHU5BmW = sc8WJeUnfo6MuLH1ZiOkhVdgP7[0]
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مشاهدة المزيد',i8sFwPqo1vpEXR2VdHU5BmW,581)
	return
def UAB8vizclM6XG4Pw(url,owZaqWpIcVhyDHXliB4dgRUr):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHAHIDNEWS-EPISODES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('nav-seasons"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	items = []
	oNiP81JuMIzwT = False
	if GVznW0jE3yMFaqK2uZvw1HBrtC and not owZaqWpIcVhyDHXliB4dgRUr:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for owZaqWpIcVhyDHXliB4dgRUr,title in items:
			owZaqWpIcVhyDHXliB4dgRUr = owZaqWpIcVhyDHXliB4dgRUr.strip('#')
			if len(items)>1: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,583,'','',owZaqWpIcVhyDHXliB4dgRUr)
			else: oNiP81JuMIzwT = True
	else: oNiP81JuMIzwT = True
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('id="'+owZaqWpIcVhyDHXliB4dgRUr+'"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0 and oNiP81JuMIzwT:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,582)
		else:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,582)
	return
def JwYEQUDupG2WLPzHndc(url):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	M7oS6tLhdx3ke8qPX4mFA = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHAHIDNEWS-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"Playerholder".*?href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
	if i8sFwPqo1vpEXR2VdHU5BmW and 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
	hash = i8sFwPqo1vpEXR2VdHU5BmW.split('hash=')[1]
	eHquV9G0n2wlLjOvC5PUW = hash.split('__')
	ePcp0jyNV24Cg7KQlv19xm = []
	for q3WQyouHmYFkisZNM in eHquV9G0n2wlLjOvC5PUW:
		try:
			q3WQyouHmYFkisZNM = eJ4h7nOpguFMH6z1IUEV2i.b64decode(q3WQyouHmYFkisZNM+'=')
			if mmIKCGujwM: q3WQyouHmYFkisZNM = q3WQyouHmYFkisZNM.decode('utf8')
			ePcp0jyNV24Cg7KQlv19xm.append(q3WQyouHmYFkisZNM)
		except: pass
	kkH5sRPxhASFowLONy4 = '>'.join(ePcp0jyNV24Cg7KQlv19xm)
	kkH5sRPxhASFowLONy4 = kkH5sRPxhASFowLONy4.splitlines()
	if 'farsol' not in str(kkH5sRPxhASFowLONy4):
		for i8sFwPqo1vpEXR2VdHU5BmW in kkH5sRPxhASFowLONy4:
			title,i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split(' => ')
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		import d3obAhVeNX
		d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	else:
		title,i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[0].split(' => ')
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','هذا الفيديو غير متوفر الآن'+'\n'+'يرجى المحاولة لاحقا'+'\n\n'+title)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/search.php?keywords='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
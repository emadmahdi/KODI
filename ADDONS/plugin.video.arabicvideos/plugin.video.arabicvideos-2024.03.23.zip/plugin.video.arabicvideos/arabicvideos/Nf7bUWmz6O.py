# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'CIMACLUBWORK'
JJCLnkX4TozH7Bsjivfe = '_CCW_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['الصفحة الرئيسية','Sign in','تسجيل','عروض مصارعة']
headers = {'Referer':HbiLZQKalC}
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==630: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==631: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==632: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==633: cLCisPE3lX = GWX3pPEBCl7(url,text)
	elif mode==634: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==639: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC+'/index.php','','','','','CIMACLUBWORK-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',639,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',HbiLZQKalC+'/index.php',631,'','','featured')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"navslide-wrap"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		if title=='أحدث الحلقات': mode,iYvJPtR357SbyQf1 = 631,'new_episodes'
		else: mode,iYvJPtR357SbyQf1 = 634,''
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,mode,'','',iYvJPtR357SbyQf1)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('/category.php">(.*?)"navslide-divider"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("'dropdown-menu'(.*?)</ul>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for MwELA7bGROd1uohvUNKpsrDVWnSyf4 in tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace(MwELA7bGROd1uohvUNKpsrDVWnSyf4,'')
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,634)
	return
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUBWORK-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"caret"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.replace('"presentation"','</ul>')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = [('',Zsh7mUdwjHobLyMz6WKJGVl1cgeR)]
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for YvGlnjICiDMQz,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if YvGlnjICiDMQz: YvGlnjICiDMQz = YvGlnjICiDMQz+': '
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = YvGlnjICiDMQz+title
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,631)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"pm-category-subcats"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(items)<30:
			QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,631)
	if not GVznW0jE3yMFaqK2uZvw1HBrtC and not q9OCkWn6ruAvQLKDFUyxBME0: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,iYvJPtR357SbyQf1=''):
	if iYvJPtR357SbyQf1=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',url,data,headers,'','','CIMACLUBWORK-TITLES-1st')
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUBWORK-TITLES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR,items = '',[]
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	if iYvJPtR357SbyQf1=='ajax-search':
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
		uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr: items.append((i8sFwPqo1vpEXR2VdHU5BmW,title,''))
	elif iYvJPtR357SbyQf1=='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pm-carousel_featured"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('''"postBlock".*?href="(.*?)" title="(.*?)".*?image:url\('(.*?)'\)''',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif iYvJPtR357SbyQf1=='new_episodes':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-ul-browse-videos(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	elif iYvJPtR357SbyQf1=='new_movies':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-ul-browse-videos(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if len(tmEVko4qsghUX6WLx8KG7fOTB)>1: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[1]
	elif iYvJPtR357SbyQf1=='featured_series':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr: items.append((i8sFwPqo1vpEXR2VdHU5BmW,title,''))
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"row pm-ul-browse-videos(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if Zsh7mUdwjHobLyMz6WKJGVl1cgeR and not items: items = T072lCzjYiuaeFtmJGV.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: return
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
		title = title.replace(' سيما كلوب','')
		title = title.replace(' اون لاين','')
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) (الحلقة|حلقة).\d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if 'WWE' in title: continue
		elif any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,632,o3gHuBtrRN)
		elif iYvJPtR357SbyQf1=='new_episodes':
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,632,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0][0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,633,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,633,o3gHuBtrRN)
	if 1:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				title = Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,631)
	return
def GWX3pPEBCl7(url,owZaqWpIcVhyDHXliB4dgRUr):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMACLUBWORK-EPISODES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	BB5dqMe8jgLxwSvk = T072lCzjYiuaeFtmJGV.findall('"series-header".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if BB5dqMe8jgLxwSvk: o3gHuBtrRN = BB5dqMe8jgLxwSvk[0]
	else: o3gHuBtrRN = ''
	items = []
	oNiP81JuMIzwT = False
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC and not owZaqWpIcVhyDHXliB4dgRUr:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('''onclick="openCity\(event,.'(.*?)'\)">(.*?)</button>''',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for owZaqWpIcVhyDHXliB4dgRUr,title in items:
			owZaqWpIcVhyDHXliB4dgRUr = owZaqWpIcVhyDHXliB4dgRUr.strip('#')
			if len(items)>1: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,633,o3gHuBtrRN,'',owZaqWpIcVhyDHXliB4dgRUr)
			else: oNiP81JuMIzwT = True
	else: oNiP81JuMIzwT = True
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('id="'+owZaqWpIcVhyDHXliB4dgRUr+'"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if q9OCkWn6ruAvQLKDFUyxBME0 and oNiP81JuMIzwT:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		items = []
		for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr: items.append((i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN))
		if not items: items = T072lCzjYiuaeFtmJGV.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
			title = title.replace('</em><span>',' ').strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,632,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA,FOqwn36QHCgpI8SXRNT1P2mdE,MfIDplCLUGK91vjO = [],[],[]
	ll9khUfx3MjZ = url.replace('/watch.php','/play.php')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMACLUBWORK-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="player"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall("src='(.*?)'.*?<strong>(.*?)</strong>",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in kkH5sRPxhASFowLONy4:
			if i8sFwPqo1vpEXR2VdHU5BmW not in M7oS6tLhdx3ke8qPX4mFA:
				FOqwn36QHCgpI8SXRNT1P2mdE.append('?named='+title+'__watch')
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	ll9khUfx3MjZ = url.replace('/watch.php','/downloads.php')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMACLUBWORK-PLAY-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="pm-download"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<strong>(.*?)</strong>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in kkH5sRPxhASFowLONy4:
			if i8sFwPqo1vpEXR2VdHU5BmW not in M7oS6tLhdx3ke8qPX4mFA:
				FOqwn36QHCgpI8SXRNT1P2mdE.append('?named='+title+'__download')
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	EvepJ1lSmD = zip(M7oS6tLhdx3ke8qPX4mFA,FOqwn36QHCgpI8SXRNT1P2mdE)
	for i8sFwPqo1vpEXR2VdHU5BmW,name in EvepJ1lSmD: MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+name)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/search.php?keywords='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
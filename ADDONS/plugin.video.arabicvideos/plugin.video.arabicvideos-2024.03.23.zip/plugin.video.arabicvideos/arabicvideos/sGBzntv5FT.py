# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
eNv8QX5p0UAnMx6sdk = 'FAVORITES'
def QoegtqjHpENh(EHnSrqQ7BvmGlOgYZdhTbCRtswA,KDS4rGfptgxAwmcPkvqLZQbyXed8O):
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==270: XVFsOLPmZiK0zN1bkr5 = HbNpCDWgIQywk12ucivJXm4UqZ(KDS4rGfptgxAwmcPkvqLZQbyXed8O)
	else: XVFsOLPmZiK0zN1bkr5 = False
	return XVFsOLPmZiK0zN1bkr5
def qsR0bXZLNAJk(c60Epz1qjmHiKMl9BY):
	if not c60Epz1qjmHiKMl9BY: return
	if '_' in c60Epz1qjmHiKMl9BY: KDS4rGfptgxAwmcPkvqLZQbyXed8O,eyVdNI3Cf7KoMAw52DmiFgpnPZSGH = c60Epz1qjmHiKMl9BY.split('_',1)
	else: KDS4rGfptgxAwmcPkvqLZQbyXed8O,eyVdNI3Cf7KoMAw52DmiFgpnPZSGH = c60Epz1qjmHiKMl9BY,''
	if   eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='UP1'	: eecLfAVXYu9(KDS4rGfptgxAwmcPkvqLZQbyXed8O,True,1)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='DOWN1'	: eecLfAVXYu9(KDS4rGfptgxAwmcPkvqLZQbyXed8O,False,1)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='UP4'	: eecLfAVXYu9(KDS4rGfptgxAwmcPkvqLZQbyXed8O,True,4)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='DOWN4'	: eecLfAVXYu9(KDS4rGfptgxAwmcPkvqLZQbyXed8O,False,4)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='ADD1'	: ltQ61xhB0aHPcf2Jz8RXTDjyUeG4O(KDS4rGfptgxAwmcPkvqLZQbyXed8O)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='REMOVE1': izDgdA9cJNtESTHIF(KDS4rGfptgxAwmcPkvqLZQbyXed8O)
	elif eyVdNI3Cf7KoMAw52DmiFgpnPZSGH=='DELETELIST': GbLVi8H3Kp72YTc54WAajJDROQz(KDS4rGfptgxAwmcPkvqLZQbyXed8O)
	return
def HbNpCDWgIQywk12ucivJXm4UqZ(KDS4rGfptgxAwmcPkvqLZQbyXed8O):
	bnEkLs0gXryJ9w = sK85VIGrwg0FZcWJ1E7()
	if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()):
		try:
			SOI2lfjLwBQY5KdTeyoJsmb = bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]
			for ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw in SOI2lfjLwBQY5KdTeyoJsmb:
				QQmLIZC8uas9fNiJWOnhdGvgFR(ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw)
		except:
			bnEkLs0gXryJ9w = JOhs5QkibGTnZ0CD9dL(Yy5epgPqo7D2vT4mQREiuX)
			SOI2lfjLwBQY5KdTeyoJsmb = bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]
			for ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw in SOI2lfjLwBQY5KdTeyoJsmb:
				QQmLIZC8uas9fNiJWOnhdGvgFR(ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw)
	return
def ltQ61xhB0aHPcf2Jz8RXTDjyUeG4O(KDS4rGfptgxAwmcPkvqLZQbyXed8O):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
	a8urgUhxk3b0 = ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,'',fKFIOvsD0QVzUGLliAyw
	bnEkLs0gXryJ9w = sK85VIGrwg0FZcWJ1E7()
	YhFwAmTPWHpbG = {}
	for ph73iNUACdt9 in list(bnEkLs0gXryJ9w.keys()):
		if ph73iNUACdt9!=KDS4rGfptgxAwmcPkvqLZQbyXed8O: YhFwAmTPWHpbG[ph73iNUACdt9] = bnEkLs0gXryJ9w[ph73iNUACdt9]
		else:
			if XLVqPOIzGJl6KUyQ23d9 and XLVqPOIzGJl6KUyQ23d9!='..':
				byEHU9RLFOaulQXv0heWi7px = bnEkLs0gXryJ9w[ph73iNUACdt9]
				if a8urgUhxk3b0 in byEHU9RLFOaulQXv0heWi7px:
					EgyQkApTasJVu = byEHU9RLFOaulQXv0heWi7px.index(a8urgUhxk3b0)
					del byEHU9RLFOaulQXv0heWi7px[EgyQkApTasJVu]
				LjiwUb1VrfeWcAYC5vlBsMdI = byEHU9RLFOaulQXv0heWi7px+[a8urgUhxk3b0]
				YhFwAmTPWHpbG[ph73iNUACdt9] = LjiwUb1VrfeWcAYC5vlBsMdI
			else: YhFwAmTPWHpbG[ph73iNUACdt9] = bnEkLs0gXryJ9w[ph73iNUACdt9]
	if KDS4rGfptgxAwmcPkvqLZQbyXed8O not in list(YhFwAmTPWHpbG.keys()): YhFwAmTPWHpbG[KDS4rGfptgxAwmcPkvqLZQbyXed8O] = [a8urgUhxk3b0]
	Ccje1nZ7lqUOy = str(YhFwAmTPWHpbG)
	if mmIKCGujwM: Ccje1nZ7lqUOy = Ccje1nZ7lqUOy.encode('utf8')
	open(Yy5epgPqo7D2vT4mQREiuX,'wb').write(Ccje1nZ7lqUOy)
	return
def izDgdA9cJNtESTHIF(KDS4rGfptgxAwmcPkvqLZQbyXed8O):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
	a8urgUhxk3b0 = ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,'',fKFIOvsD0QVzUGLliAyw
	bnEkLs0gXryJ9w = sK85VIGrwg0FZcWJ1E7()
	if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()) and a8urgUhxk3b0 in bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]:
		bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O].remove(a8urgUhxk3b0)
		if len(bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O])==0: del bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]
		Ccje1nZ7lqUOy = str(bnEkLs0gXryJ9w)
		if mmIKCGujwM: Ccje1nZ7lqUOy = Ccje1nZ7lqUOy.encode('utf8')
		open(Yy5epgPqo7D2vT4mQREiuX,'wb').write(Ccje1nZ7lqUOy)
	return
def eecLfAVXYu9(KDS4rGfptgxAwmcPkvqLZQbyXed8O,NonB1pKzhjG3,g96JE0NIfm2zTDi):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = LsBXYAO5g8fyu0iPkV9(pyDQJ34XlhL6OmuoPk5UvSjN08MVG)
	a8urgUhxk3b0 = ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,'',fKFIOvsD0QVzUGLliAyw
	bnEkLs0gXryJ9w = sK85VIGrwg0FZcWJ1E7()
	if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()):
		byEHU9RLFOaulQXv0heWi7px = bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]
		if a8urgUhxk3b0 not in byEHU9RLFOaulQXv0heWi7px: return
		ogsEOdPQaNCHpSlwWn2K = len(byEHU9RLFOaulQXv0heWi7px)
		for hU3gvdkbXl5HVAYecR6sJGyB in range(0,g96JE0NIfm2zTDi):
			dBfr0kyH8gPUOnRmZ = byEHU9RLFOaulQXv0heWi7px.index(a8urgUhxk3b0)
			if NonB1pKzhjG3: dmbiZ1t5kQ8PXrwljN = dBfr0kyH8gPUOnRmZ-1
			else: dmbiZ1t5kQ8PXrwljN = dBfr0kyH8gPUOnRmZ+1
			if dmbiZ1t5kQ8PXrwljN>=ogsEOdPQaNCHpSlwWn2K: dmbiZ1t5kQ8PXrwljN = dmbiZ1t5kQ8PXrwljN-ogsEOdPQaNCHpSlwWn2K
			if dmbiZ1t5kQ8PXrwljN<0: dmbiZ1t5kQ8PXrwljN = dmbiZ1t5kQ8PXrwljN+ogsEOdPQaNCHpSlwWn2K
			byEHU9RLFOaulQXv0heWi7px.insert(dmbiZ1t5kQ8PXrwljN, byEHU9RLFOaulQXv0heWi7px.pop(dBfr0kyH8gPUOnRmZ))
		bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O] = byEHU9RLFOaulQXv0heWi7px
		Ccje1nZ7lqUOy = str(bnEkLs0gXryJ9w)
		if mmIKCGujwM: Ccje1nZ7lqUOy = Ccje1nZ7lqUOy.encode('utf8')
		open(Yy5epgPqo7D2vT4mQREiuX,'wb').write(Ccje1nZ7lqUOy)
	return
def GbLVi8H3Kp72YTc54WAajJDROQz(KDS4rGfptgxAwmcPkvqLZQbyXed8O):
	eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+KDS4rGfptgxAwmcPkvqLZQbyXed8O+' ؟!')
	if eZId7XMDvV6Jno938!=1: return
	bnEkLs0gXryJ9w = sK85VIGrwg0FZcWJ1E7()
	if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()):
		del bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]
		Ccje1nZ7lqUOy = str(bnEkLs0gXryJ9w)
		if mmIKCGujwM: Ccje1nZ7lqUOy = Ccje1nZ7lqUOy.encode('utf8')
		open(Yy5epgPqo7D2vT4mQREiuX,'wb').write(Ccje1nZ7lqUOy)
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+KDS4rGfptgxAwmcPkvqLZQbyXed8O)
	return
def sK85VIGrwg0FZcWJ1E7():
	bnEkLs0gXryJ9w = {}
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(Yy5epgPqo7D2vT4mQREiuX):
		XXkxy6DcRw = open(Yy5epgPqo7D2vT4mQREiuX,'rb').read()
		if mmIKCGujwM: XXkxy6DcRw = XXkxy6DcRw.decode('utf8')
		bnEkLs0gXryJ9w = cwiLy4IAVJj0pWCl7FGxokR('dict',XXkxy6DcRw)
	return bnEkLs0gXryJ9w
def Rsd7jOX0rvLqQ61kwp8JFBoz4Kf(bnEkLs0gXryJ9w,a8urgUhxk3b0,F8hJHD4gr7my2adOK):
	ga4p3IxqUXMjTRPQZfH9J5E,XLVqPOIzGJl6KUyQ23d9,HHPwg71GEVju,EHnSrqQ7BvmGlOgYZdhTbCRtswA,rHC4l56cOGQ9sX0Mj,Fa9EIfiBzwm13QhVUr,yv8XxUjorzB2CRA4Jife73VMklHp,c60Epz1qjmHiKMl9BY,fKFIOvsD0QVzUGLliAyw = a8urgUhxk3b0
	if not EHnSrqQ7BvmGlOgYZdhTbCRtswA: ga4p3IxqUXMjTRPQZfH9J5E,EHnSrqQ7BvmGlOgYZdhTbCRtswA = 'folder','260'
	BMY3aHkpUmlj7ZAhitd,KDS4rGfptgxAwmcPkvqLZQbyXed8O = [],''
	if 'context=' in pyDQJ34XlhL6OmuoPk5UvSjN08MVG:
		Q1q9Gy6ktgjaxvY3C7ip = T072lCzjYiuaeFtmJGV.findall('context=(\d+)',pyDQJ34XlhL6OmuoPk5UvSjN08MVG,T072lCzjYiuaeFtmJGV.DOTALL)
		if Q1q9Gy6ktgjaxvY3C7ip: KDS4rGfptgxAwmcPkvqLZQbyXed8O = str(Q1q9Gy6ktgjaxvY3C7ip[0])
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA=='270':
		KDS4rGfptgxAwmcPkvqLZQbyXed8O = c60Epz1qjmHiKMl9BY
		if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()):
			BMY3aHkpUmlj7ZAhitd.append(('مسح قائمة مفضلة '+KDS4rGfptgxAwmcPkvqLZQbyXed8O,'RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_DELETELIST'+')'))
	else:
		if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()):
			count = len(bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O])
			if count>1: BMY3aHkpUmlj7ZAhitd.append(('تحريك 1 للأعلى','RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_UP1)'))
			if count>4: BMY3aHkpUmlj7ZAhitd.append(('تحريك 4 للأعلى','RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_UP4)'))
			if count>1: BMY3aHkpUmlj7ZAhitd.append(('تحريك 1 للأسفل','RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_DOWN1)'))
			if count>4: BMY3aHkpUmlj7ZAhitd.append(('تحريك 4 للأسفل','RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_DOWN4)'))
		for KDS4rGfptgxAwmcPkvqLZQbyXed8O in ['1','2','3','4','5']:
			if KDS4rGfptgxAwmcPkvqLZQbyXed8O in list(bnEkLs0gXryJ9w.keys()) and a8urgUhxk3b0 in bnEkLs0gXryJ9w[KDS4rGfptgxAwmcPkvqLZQbyXed8O]:
				BMY3aHkpUmlj7ZAhitd.append(('مسح من مفضلة '+KDS4rGfptgxAwmcPkvqLZQbyXed8O,'RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_REMOVE1)'))
			else: BMY3aHkpUmlj7ZAhitd.append(('إضافة إلى مفضلة '+KDS4rGfptgxAwmcPkvqLZQbyXed8O,'RunPlugin('+F8hJHD4gr7my2adOK+'&context='+KDS4rGfptgxAwmcPkvqLZQbyXed8O+'_ADD1)'))
	eUCLr9NJDE7y06f = []
	for XO2WAlPUyVcFT9Hd0GoLjEgNQSp,zcIBZvA0EsJr4 in BMY3aHkpUmlj7ZAhitd:
		XO2WAlPUyVcFT9Hd0GoLjEgNQSp = '[COLOR FFFFFF00]'+XO2WAlPUyVcFT9Hd0GoLjEgNQSp+'[/COLOR]'
		eUCLr9NJDE7y06f.append((XO2WAlPUyVcFT9Hd0GoLjEgNQSp,zcIBZvA0EsJr4,))
	return eUCLr9NJDE7y06f
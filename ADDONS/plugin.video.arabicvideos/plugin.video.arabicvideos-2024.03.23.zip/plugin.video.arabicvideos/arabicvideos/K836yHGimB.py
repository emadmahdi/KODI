# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'ALARAB'
headers = {'User-Agent':''}
JJCLnkX4TozH7Bsjivfe = '_KLA_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==10: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==11: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==12: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==13: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==14: cLCisPE3lX = lTDhLSWw0YXprJzxfZNejCmO()
	elif mode==15: cLCisPE3lX = Wtp2BnsvXl0uhz()
	elif mode==16: cLCisPE3lX = ot9gmHj2af5UxrCYFpA80()
	elif mode==19: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'آخر الإضافات','',14)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان','',15)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','ALARAB-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('id="nav-slider"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	KtOB963m51U = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',KtOB963m51U,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
		title = title.strip(' ')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="navbar"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	MwELA7bGROd1uohvUNKpsrDVWnSyf4 = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',MwELA7bGROd1uohvUNKpsrDVWnSyf4,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,11)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Wtp2BnsvXl0uhz():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'جميع المسلسلات العربية',HbiLZQKalC+'/view-8/مسلسلات-عربية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات السنة الأخيرة','',16)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان الأخيرة 1',HbiLZQKalC+'/view-8/مسلسلات-رمضان-2022',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان الأخيرة 2',HbiLZQKalC+'/view-8/مسلسلات-رمضان-2023',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2023',HbiLZQKalC+'/ramadan2023/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2022',HbiLZQKalC+'/ramadan2022/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2021',HbiLZQKalC+'/ramadan2021/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2020',HbiLZQKalC+'/ramadan2020/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2019',HbiLZQKalC+'/ramadan2019/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2018',HbiLZQKalC+'/ramadan2018/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2017',HbiLZQKalC+'/ramadan2017/مصرية',11)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مسلسلات رمضان 2016',HbiLZQKalC+'/ramadan2016/مصرية',11)
	return
def lTDhLSWw0YXprJzxfZNejCmO():
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,HbiLZQKalC,'',headers,True,'ALARAB-LATEST-1st')
	tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('heading-top(.*?)div class=',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]+tmEVko4qsghUX6WLx8KG7fOTB[1]
	items=T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		url = HbiLZQKalC + i8sFwPqo1vpEXR2VdHU5BmW
		if 'series' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,11,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,url,12,o3gHuBtrRN)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('video-category(.*?)right_content',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	C4aOhQx81J = False
	items = T072lCzjYiuaeFtmJGV.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya,Ip1ihmjOJoNPAbw = [],[]
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if title=='': title = i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-1].replace('-',' ')
		IMC3E9dFHnu2QSTy6DUPczBi0qk = T072lCzjYiuaeFtmJGV.findall('(\d+)',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if IMC3E9dFHnu2QSTy6DUPczBi0qk: IMC3E9dFHnu2QSTy6DUPczBi0qk = int(IMC3E9dFHnu2QSTy6DUPczBi0qk[0])
		else: IMC3E9dFHnu2QSTy6DUPczBi0qk = 0
		Ip1ihmjOJoNPAbw.append([o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title,IMC3E9dFHnu2QSTy6DUPczBi0qk])
	Ip1ihmjOJoNPAbw = sorted(Ip1ihmjOJoNPAbw, reverse=True, key=lambda key: key[3])
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title,IMC3E9dFHnu2QSTy6DUPczBi0qk in Ip1ihmjOJoNPAbw:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC + i8sFwPqo1vpEXR2VdHU5BmW
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		tKBSN4Zgn9CDb = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if XSCYbwaqRBtopUc9H2QZu86gA5N: tKBSN4Zgn9CDb = XSCYbwaqRBtopUc9H2QZu86gA5N[0]
		if tKBSN4Zgn9CDb not in BBRwQhFnJ08q9YVxOSya:
			BBRwQhFnJ08q9YVxOSya.append(tKBSN4Zgn9CDb)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,i8sFwPqo1vpEXR2VdHU5BmW,13,o3gHuBtrRN)
				C4aOhQx81J = True
			elif 'series' in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,11,o3gHuBtrRN)
				C4aOhQx81J = True
			else:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,12,o3gHuBtrRN)
				C4aOhQx81J = True
	if C4aOhQx81J:
		items = T072lCzjYiuaeFtmJGV.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,ffGe7cURW0lhJVvQAiw8IB in items:
			url = HbiLZQKalC + i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+ffGe7cURW0lhJVvQAiw8IB,url,11)
	return
def UAB8vizclM6XG4Pw(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,True,'ALARAB-EPISODES-1st')
	GJL1Ps7XWte3hjTy5ckDrZonFYAlp = T072lCzjYiuaeFtmJGV.findall('href="(/series.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	ll9khUfx3MjZ = HbiLZQKalC+GJL1Ps7XWte3hjTy5ckDrZonFYAlp[0]
	cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA = []
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(j9t7FmfZiE6pYGI8V4u,url,'',headers,True,'ALARAB-PLAY-1st')
	ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('class="resp-iframe" src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if ll9khUfx3MjZ:
		ll9khUfx3MjZ = ll9khUfx3MjZ[0]
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('^(http.*?)(http.*?)$',ll9khUfx3MjZ,T072lCzjYiuaeFtmJGV.DOTALL)
		if kkH5sRPxhASFowLONy4:
			ye8iWwASlpUFt = kkH5sRPxhASFowLONy4[0][0]
			VV7NR0W4DIJGH,Oq7LZDlJy2YVretgd3sMU = kkH5sRPxhASFowLONy4[0][1].rsplit('/',1)
			dCmKxk9BW310AXu4bJUHfY = VV7NR0W4DIJGH+'?named=__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(dCmKxk9BW310AXu4bJUHfY)
			zFHuCf5Gpms8XE2MbI0Tc = ye8iWwASlpUFt+Oq7LZDlJy2YVretgd3sMU
		else:
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'',headers,False,'ALARAB-PLAY-2nd')
			ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('"src": "(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if ll9khUfx3MjZ:
				ll9khUfx3MjZ = ll9khUfx3MjZ[0]+'?named=__watch__m3u8'
				M7oS6tLhdx3ke8qPX4mFA.append(ll9khUfx3MjZ)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('searchBox(.*?)<style>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		ll9khUfx3MjZ = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if ll9khUfx3MjZ:
			ll9khUfx3MjZ = ll9khUfx3MjZ[0]+'?named=__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(ll9khUfx3MjZ)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def ot9gmHj2af5UxrCYFpA80():
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,True,'ALARAB-RAMADAN-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="content_sec"(.*?)id="left_content"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	eDj8K0sE5HNTIqu = T072lCzjYiuaeFtmJGV.findall('/ramadan([0-9]+)/',str(items),T072lCzjYiuaeFtmJGV.DOTALL)
	eDj8K0sE5HNTIqu = eDj8K0sE5HNTIqu[0]
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		url = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
		title = title.strip(' ')+' '+eDj8K0sE5HNTIqu
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,11)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	url = HbiLZQKalC + "/q/" + xC2GuEcJKk3t4Uh
	cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
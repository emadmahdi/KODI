# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from skIgoAvZ9t import *
nO6ukabcldeU = uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
JJCLnkX4TozH7Bsjivfe = f5uqIoSJzWBOFyrY78RXmVb(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
m7mE4RGSTLH0MsvZnkIrFuB82yYw = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(yyJSUbRVMEdCABecYH8F,EmK3ObA0cwv9Wy(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
FF7JuRlgZpOLAIbhyQfrdan98z1q = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(yyJSUbRVMEdCABecYH8F,TWexH5PhS1(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
B2WjloumZDaw9VKtnAhEL7s = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(QAqRhweFzL5D6d1sjfvY,FIHNSc5iuoZanQ2Ytl(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
mV8GsI4bwEY = kkoV2vIem3BEOyp7w8CDNhHZAd
ylhYXwSNniOvtbad0sTZxKgQ = f5uqIoSJzWBOFyrY78RXmVb(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
MxJkGEZ0uovBjR6QS5XanrYDhyA = vatyjK4hHAoZJ7rOq2lis(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
VnKQUEv3X6bBghqWO9 = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
PP5JhNZMAR9oH7K8dbpVCYT6W23z = g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
E8tTLH5guPVh0 = FIHNSc5iuoZanQ2Ytl(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
aPY2e7nwRBNsQyVd0Tb1GICvlDExz6 = weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def F5M9LsnokGPEQ2XYfO7cuyr(mode):
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==sbgu4D2RFMYKm(u"࠹࠷࠴ࣉ"): cLCisPE3lX = v2nRfdprmtTs0geUcL()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠺࠸࠶࣊"): cLCisPE3lX = P8vtuTghFN7lWIS(m7mE4RGSTLH0MsvZnkIrFuB82yYw,sbgu4D2RFMYKm(u"ࡖࡵࡹࡪࣳ"),sbgu4D2RFMYKm(u"ࡖࡵࡹࡪࣳ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==HH4JMrUDp3lq6hQ(u"࠻࠹࠸࣋"): cLCisPE3lX = P8vtuTghFN7lWIS(FF7JuRlgZpOLAIbhyQfrdan98z1q,weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡗࡶࡺ࡫ࣴ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࡗࡶࡺ࡫ࣴ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EEvLoMzFqrlKce(u"࠼࠺࠳࣌"): cLCisPE3lX = P8vtuTghFN7lWIS(B2WjloumZDaw9VKtnAhEL7s,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࡋࡧ࡬ࡴࡧࣶ"),WmaPChRdQk3YcXwI6zS(u"ࡘࡷࡻࡥࣵ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==TWexH5PhS1(u"࠽࠴࠵࣍"): cLCisPE3lX = UGzEr0oSR21KDJgiZQuLYsyHAad(mV8GsI4bwEY,f5uqIoSJzWBOFyrY78RXmVb(u"࡚ࡲࡶࡧࣷ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==FIHNSc5iuoZanQ2Ytl(u"࠷࠵࠷࣎"): cLCisPE3lX = f8fnKShoBFpCmLAgv0dZYsND(VOq8Ekue4F(u"ࡔࡳࡷࡨࣸ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠸࠷࠳࣏"): cLCisPE3lX = VZuoXxa73N5QcTLA()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==WmaPChRdQk3YcXwI6zS(u"࠹࠸࠵࣐"): cLCisPE3lX = P8vtuTghFN7lWIS(ylhYXwSNniOvtbad0sTZxKgQ,VOq8Ekue4F(u"ࡈࡤࡰࡸ࡫ࣺ"),TWexH5PhS1(u"ࡕࡴࡸࡩࣹ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==PiFkQ5pCJy7fbX(u"࠺࠹࠷࣑"): cLCisPE3lX = P8vtuTghFN7lWIS(MxJkGEZ0uovBjR6QS5XanrYDhyA,FIHNSc5iuoZanQ2Ytl(u"ࡊࡦࡲࡳࡦࣼ"),ZhqJoOtcmTVID65HwnLj(u"ࡗࡶࡺ࡫ࣻ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠻࠺࠹࣒"): cLCisPE3lX = P8vtuTghFN7lWIS(VnKQUEv3X6bBghqWO9,WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡌࡡ࡭ࡵࡨࣾ"),oAXJCYqPgyGDtT(u"࡙ࡸࡵࡦࣽ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==EEvLoMzFqrlKce(u"࠼࠻࠴࣓"): cLCisPE3lX = P8vtuTghFN7lWIS(PP5JhNZMAR9oH7K8dbpVCYT6W23z,EmK3ObA0cwv9Wy(u"ࡇࡣ࡯ࡷࡪऀ"),ttOu147wErcBvPaSMUY(u"ࡔࡳࡷࡨࣿ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==ZhqJoOtcmTVID65HwnLj(u"࠽࠵࠶ࣔ"): cLCisPE3lX = P8vtuTghFN7lWIS(E8tTLH5guPVh0,ZhqJoOtcmTVID65HwnLj(u"ࡉࡥࡱࡹࡥं"),WmaPChRdQk3YcXwI6zS(u"ࡖࡵࡹࡪँ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==f5uqIoSJzWBOFyrY78RXmVb(u"࠷࠶࠸ࣕ"): cLCisPE3lX = P8vtuTghFN7lWIS(aPY2e7nwRBNsQyVd0Tb1GICvlDExz6,ttOu147wErcBvPaSMUY(u"ࡋࡧ࡬ࡴࡧऄ"),EmK3ObA0cwv9Wy(u"ࡘࡷࡻࡥः"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠸࠷࠺ࣖ"): cLCisPE3lX = F8krLCHVbnp31sxg5(WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࡚ࡲࡶࡧअ"))
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠹࠸࠼ࣗ"): cLCisPE3lX = GNlE12kTc0IsHSfhP()
	else: cLCisPE3lX = ZhqJoOtcmTVID65HwnLj(u"ࡆࡢ࡮ࡶࡩआ")
	return cLCisPE3lX
def v2nRfdprmtTs0geUcL():
	wkLI3yb0WUAnu5zP6cfogv2HN17DGr,WHOp2fLzuxw0 = LlpsF1WBXrQhK3T(m7mE4RGSTLH0MsvZnkIrFuB82yYw)
	Cps2IGvE3xOHhu5l9,CElKTRWY8vg3zXI6h = LlpsF1WBXrQhK3T(FF7JuRlgZpOLAIbhyQfrdan98z1q)
	Jr3TPWu9f41YQIUyS,w3nxBMaryO26U0SqPFi = LlpsF1WBXrQhK3T(B2WjloumZDaw9VKtnAhEL7s)
	HuRcrhCkYPKv58,ZuwSkeqIAY3CDh6Qr1tz9aj = qtKQXi2C9V7JrEyWD61Lns(mV8GsI4bwEY)
	HuRcrhCkYPKv58 -= sbgu4D2RFMYKm(u"࠶࠺࠽࠼࠴ࣘ")
	ZuwSkeqIAY3CDh6Qr1tz9aj -= HH4JMrUDp3lq6hQ(u"࠵ࣙ")
	UW0e2HGDvj = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࠣࠬࠬࠌ")+Cyio5AbRQFB2Pav(wkLI3yb0WUAnu5zP6cfogv2HN17DGr)+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠪࠤ࠲ࠦࠧࠍ")+str(WHOp2fLzuxw0)+Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	Xl5KI3hzio8QvZVySd0RcDsnM4 = EEvLoMzFqrlKce(u"ࠬࠦࠨࠨࠏ")+Cyio5AbRQFB2Pav(Cps2IGvE3xOHhu5l9)+VOq8Ekue4F(u"࠭ࠠ࠮ࠢࠪࠐ")+str(CElKTRWY8vg3zXI6h)+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3 = ZhqJoOtcmTVID65HwnLj(u"ࠨࠢࠫࠫࠒ")+Cyio5AbRQFB2Pav(Jr3TPWu9f41YQIUyS)+N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(w3nxBMaryO26U0SqPFi)+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	wwKgAeurE84hojczWYUiHF = HVibA2ES8lY(u"ࠫࠥ࠮ࠧࠕ")+Cyio5AbRQFB2Pav(HuRcrhCkYPKv58)+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠬ࠯ࠧࠖ")
	ogsEOdPQaNCHpSlwWn2K = wkLI3yb0WUAnu5zP6cfogv2HN17DGr+Cps2IGvE3xOHhu5l9+Jr3TPWu9f41YQIUyS+HuRcrhCkYPKv58
	llCODaWngtvoGQsmq = WHOp2fLzuxw0+CElKTRWY8vg3zXI6h+w3nxBMaryO26U0SqPFi+ZuwSkeqIAY3CDh6Qr1tz9aj
	yv8XxUjorzB2CRA4Jife73VMklHp = f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࠠࠩࠩࠗ")+Cyio5AbRQFB2Pav(ogsEOdPQaNCHpSlwWn2K)+vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧࠡ࠯ࠣࠫ࠘")+str(llCODaWngtvoGQsmq)+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	QQmLIZC8uas9fNiJWOnhdGvgFR(vatyjK4hHAoZJ7rOq2lis(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),JJCLnkX4TozH7Bsjivfe+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+yv8XxUjorzB2CRA4Jife73VMklHp,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࠬࠜ"),sbgu4D2RFMYKm(u"࠼࠺࠵ࣚ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(Xl3drKyI9HkDiPEf8RTjwu(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),VH9MDo5z1kxNF07uRJI(u"ࠧࠨࠟ"),PiFkQ5pCJy7fbX(u"࠿࠹࠺࠻ࣛ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(HVibA2ES8lY(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),JJCLnkX4TozH7Bsjivfe+ZhqJoOtcmTVID65HwnLj(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+UW0e2HGDvj,EmK3ObA0cwv9Wy(u"ࠪࠫࠢ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"࠷࠵࠳ࣜ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(oAXJCYqPgyGDtT(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),JJCLnkX4TozH7Bsjivfe+g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+Xl5KI3hzio8QvZVySd0RcDsnM4,vNasL0yiB2AdPgZSlRcmJ6xnjI(u"࠭ࠧࠥ"),HVibA2ES8lY(u"࠸࠶࠵ࣝ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),JJCLnkX4TozH7Bsjivfe+f5uqIoSJzWBOFyrY78RXmVb(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3,QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩࠪࠨ"),h5huy6MiXPNfQJF8(u"࠹࠷࠷ࣞ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(TWexH5PhS1(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),JJCLnkX4TozH7Bsjivfe+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+wwKgAeurE84hojczWYUiHF,HH4JMrUDp3lq6hQ(u"ࠬ࠭ࠫ"),sDiKwnHcSlYFgWCy1Ak(u"࠺࠸࠹ࣟ"))
	YTPut68WBVUNCvsEzg.setSetting(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),HH4JMrUDp3lq6hQ(u"ࠧࠨ࠭"))
	return
def VZuoXxa73N5QcTLA():
	LqHUN2agMbizSZQ3KTxYPlv5R1wp = oAXJCYqPgyGDtT(u"ࡖࡵࡹࡪई") if ttOu147wErcBvPaSMUY(u"ࠨ࠱ࠪ࠮") in QAqRhweFzL5D6d1sjfvY else EmK3ObA0cwv9Wy(u"ࡇࡣ࡯ࡷࡪइ")
	if not LqHUN2agMbizSZQ3KTxYPlv5R1wp:
		KK47FGdX1TDfkb3AjHOQqghE(Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࠪ࠯"),PiFkQ5pCJy7fbX(u"ࠪࠫ࠰"),ttOu147wErcBvPaSMUY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),l5mQdjWyczr7UJVnTp(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	B6B7iVh1qW5Py = YTPut68WBVUNCvsEzg.getSetting(N0Kvne8UYar9fhRxboWsXJCVzid(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not B6B7iVh1qW5Py: GNlE12kTc0IsHSfhP()
	wkLI3yb0WUAnu5zP6cfogv2HN17DGr,WHOp2fLzuxw0 = LlpsF1WBXrQhK3T(ylhYXwSNniOvtbad0sTZxKgQ)
	Cps2IGvE3xOHhu5l9,CElKTRWY8vg3zXI6h = LlpsF1WBXrQhK3T(MxJkGEZ0uovBjR6QS5XanrYDhyA)
	Jr3TPWu9f41YQIUyS,w3nxBMaryO26U0SqPFi = LlpsF1WBXrQhK3T(VnKQUEv3X6bBghqWO9)
	HuRcrhCkYPKv58,ZuwSkeqIAY3CDh6Qr1tz9aj = LlpsF1WBXrQhK3T(PP5JhNZMAR9oH7K8dbpVCYT6W23z)
	yT0nHQpiB6fZmUF,zUhapR9HNJwB8KA3jl2nX1tQg = LlpsF1WBXrQhK3T(E8tTLH5guPVh0)
	oLbASsgfYG1Z7wQ4HcPpj0Jm8KeRF,LtA3jVHMScsqx4a6lhgQpK1eW8ODzN = LlpsF1WBXrQhK3T(aPY2e7nwRBNsQyVd0Tb1GICvlDExz6)
	UW0e2HGDvj = S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧࠡࠪࠪ࠴")+Cyio5AbRQFB2Pav(wkLI3yb0WUAnu5zP6cfogv2HN17DGr)+HVibA2ES8lY(u"ࠨࠢ࠰ࠤࠬ࠵")+str(WHOp2fLzuxw0)+ZEiR0StquOzca9lvPAndYIX(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	Xl5KI3hzio8QvZVySd0RcDsnM4 = ttOu147wErcBvPaSMUY(u"ࠪࠤ࠭࠭࠷")+Cyio5AbRQFB2Pav(Cps2IGvE3xOHhu5l9)+QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠫࠥ࠳ࠠࠨ࠸")+str(CElKTRWY8vg3zXI6h)+TWexH5PhS1(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3 = QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"࠭ࠠࠩࠩ࠺")+Cyio5AbRQFB2Pav(Jr3TPWu9f41YQIUyS)+mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠧࠡ࠯ࠣࠫ࠻")+str(w3nxBMaryO26U0SqPFi)+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	wwKgAeurE84hojczWYUiHF = HVibA2ES8lY(u"ࠩࠣࠬࠬ࠽")+Cyio5AbRQFB2Pav(HuRcrhCkYPKv58)+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠤ࠲ࠦࠧ࠾")+str(ZuwSkeqIAY3CDh6Qr1tz9aj)+TWexH5PhS1(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	gMkvF8uRbdBPzKLl3yYO2sHr5q0 = N9olEh0ZMtpOivVfBLK(u"ࠬࠦࠨࠨࡀ")+Cyio5AbRQFB2Pav(yT0nHQpiB6fZmUF)+uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࠭ࠠ࠮ࠢࠪࡁ")+str(zUhapR9HNJwB8KA3jl2nX1tQg)+PiFkQ5pCJy7fbX(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	e3ITdw65D1xL8BEUjNbWv2l0pMf = EEvLoMzFqrlKce(u"ࠨࠢࠫࠫࡃ")+Cyio5AbRQFB2Pav(oLbASsgfYG1Z7wQ4HcPpj0Jm8KeRF)+weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(LtA3jVHMScsqx4a6lhgQpK1eW8ODzN)+ZhqJoOtcmTVID65HwnLj(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	ogsEOdPQaNCHpSlwWn2K = wkLI3yb0WUAnu5zP6cfogv2HN17DGr+Cps2IGvE3xOHhu5l9+Jr3TPWu9f41YQIUyS+HuRcrhCkYPKv58+yT0nHQpiB6fZmUF+oLbASsgfYG1Z7wQ4HcPpj0Jm8KeRF
	llCODaWngtvoGQsmq = WHOp2fLzuxw0+CElKTRWY8vg3zXI6h+w3nxBMaryO26U0SqPFi+ZuwSkeqIAY3CDh6Qr1tz9aj+zUhapR9HNJwB8KA3jl2nX1tQg+LtA3jVHMScsqx4a6lhgQpK1eW8ODzN
	yv8XxUjorzB2CRA4Jife73VMklHp = mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠫࠥ࠮ࠧࡆ")+Cyio5AbRQFB2Pav(ogsEOdPQaNCHpSlwWn2K)+N9olEh0ZMtpOivVfBLK(u"ࠬࠦ࠭ࠡࠩࡇ")+str(llCODaWngtvoGQsmq)+FIHNSc5iuoZanQ2Ytl(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	QQmLIZC8uas9fNiJWOnhdGvgFR(S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),JJCLnkX4TozH7Bsjivfe+PiFkQ5pCJy7fbX(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),ZEiR0StquOzca9lvPAndYIX(u"ࠩࠪࡋ"),l5mQdjWyczr7UJVnTp(u"࠻࠺࠾࣠"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(sbgu4D2RFMYKm(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),JJCLnkX4TozH7Bsjivfe+PiFkQ5pCJy7fbX(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+yv8XxUjorzB2CRA4Jife73VMklHp,FIHNSc5iuoZanQ2Ytl(u"ࠬ࠭ࡎ"),HVibA2ES8lY(u"࠼࠻࠷࣡"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(sDiKwnHcSlYFgWCy1Ak(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),HH4JMrUDp3lq6hQ(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),l5mQdjWyczr7UJVnTp(u"ࠨࠩࡑ"),VH9MDo5z1kxNF07uRJI(u"࠿࠹࠺࠻࣢"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),JJCLnkX4TozH7Bsjivfe+ZhqJoOtcmTVID65HwnLj(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+UW0e2HGDvj,g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠫࠬࡔ"),oAXJCYqPgyGDtT(u"࠷࠶࠳ࣣ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),JJCLnkX4TozH7Bsjivfe+BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+Xl5KI3hzio8QvZVySd0RcDsnM4,ttOu147wErcBvPaSMUY(u"ࠧࠨࡗ"),TWexH5PhS1(u"࠸࠷࠵ࣤ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(ZhqJoOtcmTVID65HwnLj(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),JJCLnkX4TozH7Bsjivfe+HVibA2ES8lY(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+xD1rCKHkRdN7BJ9qI2ZuXcoE5Pbgs3,WmaPChRdQk3YcXwI6zS(u"࡚ࠪࠫ"),FIHNSc5iuoZanQ2Ytl(u"࠹࠸࠷ࣥ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),JJCLnkX4TozH7Bsjivfe+N9olEh0ZMtpOivVfBLK(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+wwKgAeurE84hojczWYUiHF,FIHNSc5iuoZanQ2Ytl(u"࠭ࠧ࡝"),f5uqIoSJzWBOFyrY78RXmVb(u"࠺࠹࠹ࣦ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),JJCLnkX4TozH7Bsjivfe+sbgu4D2RFMYKm(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+gMkvF8uRbdBPzKLl3yYO2sHr5q0,sbgu4D2RFMYKm(u"ࠩࠪࡠ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠻࠺࠻ࣧ"))
	QQmLIZC8uas9fNiJWOnhdGvgFR(HVibA2ES8lY(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),JJCLnkX4TozH7Bsjivfe+Xl3drKyI9HkDiPEf8RTjwu(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+e3ITdw65D1xL8BEUjNbWv2l0pMf,mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠬ࠭ࡣ"),l5mQdjWyczr7UJVnTp(u"࠼࠻࠶ࣨ"))
	YTPut68WBVUNCvsEzg.setSetting(Xl3drKyI9HkDiPEf8RTjwu(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),N9olEh0ZMtpOivVfBLK(u"ࠧࠨࡥ"))
	return
def GNlE12kTc0IsHSfhP():
	VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(WmaPChRdQk3YcXwI6zS(u"ࠨࠩࡦ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩࠪࡧ"),WmaPChRdQk3YcXwI6zS(u"ࠪࠫࡨ"),sbgu4D2RFMYKm(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),EEvLoMzFqrlKce(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if VjwKs4GNQZ518kCl==-N9olEh0ZMtpOivVfBLK(u"࠷ࣩ"): return
	if VjwKs4GNQZ518kCl:
		import subprocess as KwFx2rLtTBDduNjzUkv
		try:
			KwFx2rLtTBDduNjzUkv.Popen(ZEiR0StquOzca9lvPAndYIX(u"࠭ࡳࡶࠩ࡫"))
			Yt2vRc7GNasEiKSUZMCpT95wAOry = N9olEh0ZMtpOivVfBLK(u"ࡗࡶࡺ࡫उ")
		except: Yt2vRc7GNasEiKSUZMCpT95wAOry = FIHNSc5iuoZanQ2Ytl(u"ࡊࡦࡲࡳࡦऊ")
		if Yt2vRc7GNasEiKSUZMCpT95wAOry:
			HgX2qj0cPamv3UNtfQZKGDbkJo = ylhYXwSNniOvtbad0sTZxKgQ+HVibA2ES8lY(u"ࠧࠡࠩ࡬")+MxJkGEZ0uovBjR6QS5XanrYDhyA+HH4JMrUDp3lq6hQ(u"ࠨࠢࠪ࡭")+VnKQUEv3X6bBghqWO9+HH4JMrUDp3lq6hQ(u"ࠩࠣࠫ࡮")+PP5JhNZMAR9oH7K8dbpVCYT6W23z+f5uqIoSJzWBOFyrY78RXmVb(u"ࠪࠤࠬ࡯")+E8tTLH5guPVh0+Xl3drKyI9HkDiPEf8RTjwu(u"ࠫࠥ࠭ࡰ")+aPY2e7nwRBNsQyVd0Tb1GICvlDExz6
			HRL2bGaKng5im = KwFx2rLtTBDduNjzUkv.Popen(N9olEh0ZMtpOivVfBLK(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+HgX2qj0cPamv3UNtfQZKGDbkJo+TWexH5PhS1(u"࠭ࠢࠨࡲ"),shell=uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"࡙ࡸࡵࡦऋ"),stdin=KwFx2rLtTBDduNjzUkv.PIPE,stdout=KwFx2rLtTBDduNjzUkv.PIPE,stderr=KwFx2rLtTBDduNjzUkv.PIPE)
			KK47FGdX1TDfkb3AjHOQqghE(f5uqIoSJzWBOFyrY78RXmVb(u"ࠧࠨࡳ"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠨࠩࡴ"),sbgu4D2RFMYKm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),f5uqIoSJzWBOFyrY78RXmVb(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			YTPut68WBVUNCvsEzg.setSetting(ZEiR0StquOzca9lvPAndYIX(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),ttOu147wErcBvPaSMUY(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			EO9Rts0AaGuk1qpPLXCY.executebuiltin(FIHNSc5iuoZanQ2Ytl(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: KK47FGdX1TDfkb3AjHOQqghE(BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠧࠨࡺ"),EEvLoMzFqrlKce(u"ࠨࠩࡻ"),ZhqJoOtcmTVID65HwnLj(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),cbngtp9sqYi0DjeEMLRHJruKxm(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def Cyio5AbRQFB2Pav(ogsEOdPQaNCHpSlwWn2K):
	for qa0fA26EyCoSkjKnrh in [ttOu147wErcBvPaSMUY(u"ࠫࡇ࠭ࡾ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬࡑࡂࠨࡿ"),vatyjK4hHAoZJ7rOq2lis(u"࠭ࡍࡃࠩࢀ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠧࡈࡄࠪࢁ"),EEvLoMzFqrlKce(u"ࠨࡖࡅࠫࢂ")]:
		if ogsEOdPQaNCHpSlwWn2K<HVibA2ES8lY(u"࠱࠱࠴࠷࣪"): break
		else: ogsEOdPQaNCHpSlwWn2K /= vatyjK4hHAoZJ7rOq2lis(u"࠲࠲࠵࠸࠳࠶࣫")
	yv8XxUjorzB2CRA4Jife73VMklHp = BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(ogsEOdPQaNCHpSlwWn2K,qa0fA26EyCoSkjKnrh)
	return yv8XxUjorzB2CRA4Jife73VMklHp
def LlpsF1WBXrQhK3T(VwQ9stRm5jkJScvoYyKfT1euXbErAD=EmK3ObA0cwv9Wy(u"ࠪ࠲ࠬࢄ")):
	global PGih0FujMVYBdARN4pl7wco5,FFSVwRQNBjneGOH3IMboK7gm9L
	PGih0FujMVYBdARN4pl7wco5,FFSVwRQNBjneGOH3IMboK7gm9L = TWexH5PhS1(u"࠲࣬"),TWexH5PhS1(u"࠲࣬")
	def Dm3g5nxS4G(VwQ9stRm5jkJScvoYyKfT1euXbErAD):
		global PGih0FujMVYBdARN4pl7wco5,FFSVwRQNBjneGOH3IMboK7gm9L
		if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(VwQ9stRm5jkJScvoYyKfT1euXbErAD):
			if ZEiR0StquOzca9lvPAndYIX(u"࠳࣭") and f5uqIoSJzWBOFyrY78RXmVb(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(isWjwHOERYXhAp0ZuNdKUgkCM7):
				for CC8wEgtFYi in isWjwHOERYXhAp0ZuNdKUgkCM7.scandir(VwQ9stRm5jkJScvoYyKfT1euXbErAD):
					if CC8wEgtFYi.is_dir(follow_symlinks=ZhqJoOtcmTVID65HwnLj(u"ࡌࡡ࡭ࡵࡨऌ")):
						Dm3g5nxS4G(CC8wEgtFYi.path)
					elif CC8wEgtFYi.is_file(follow_symlinks=N9olEh0ZMtpOivVfBLK(u"ࡆࡢ࡮ࡶࡩऍ")):
						PGih0FujMVYBdARN4pl7wco5 += CC8wEgtFYi.stat().st_size
						FFSVwRQNBjneGOH3IMboK7gm9L += TWexH5PhS1(u"࠵࣮")
			else:
				for CC8wEgtFYi in isWjwHOERYXhAp0ZuNdKUgkCM7.listdir(VwQ9stRm5jkJScvoYyKfT1euXbErAD):
					AJ6Vz7qy4rYpcm9HhGotsB = isWjwHOERYXhAp0ZuNdKUgkCM7.path.abspath(isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(VwQ9stRm5jkJScvoYyKfT1euXbErAD,CC8wEgtFYi))
					if isWjwHOERYXhAp0ZuNdKUgkCM7.path.isdir(AJ6Vz7qy4rYpcm9HhGotsB):
						Dm3g5nxS4G(AJ6Vz7qy4rYpcm9HhGotsB)
					elif isWjwHOERYXhAp0ZuNdKUgkCM7.path.isfile(AJ6Vz7qy4rYpcm9HhGotsB):
						ogsEOdPQaNCHpSlwWn2K,llCODaWngtvoGQsmq = qtKQXi2C9V7JrEyWD61Lns(AJ6Vz7qy4rYpcm9HhGotsB)
						PGih0FujMVYBdARN4pl7wco5 += ogsEOdPQaNCHpSlwWn2K
						FFSVwRQNBjneGOH3IMboK7gm9L += llCODaWngtvoGQsmq
		return
	try: Dm3g5nxS4G(VwQ9stRm5jkJScvoYyKfT1euXbErAD)
	except: pass
	return PGih0FujMVYBdARN4pl7wco5,FFSVwRQNBjneGOH3IMboK7gm9L
def pxzZSe9Bjc6EsCq(NX7IZ2o9gmn4MARJWqHbx0s,showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(ZEiR0StquOzca9lvPAndYIX(u"ࠬ࠭ࢆ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠧࢇ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠧࠨ࢈"),VH9MDo5z1kxNF07uRJI(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),NX7IZ2o9gmn4MARJWqHbx0s+S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+WmaPChRdQk3YcXwI6zS(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if VjwKs4GNQZ518kCl!=sDiKwnHcSlYFgWCy1Ak(u"࠶࣯"): return
	erpxS1nj9JWN = h5huy6MiXPNfQJF8(u"ࡇࡣ࡯ࡷࡪऎ")
	if isWjwHOERYXhAp0ZuNdKUgkCM7.path.exists(NX7IZ2o9gmn4MARJWqHbx0s):
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(NX7IZ2o9gmn4MARJWqHbx0s)
		except Exception as JuyDmCElpF7HdcYniGwRXxz46:
			if showDialogs: KK47FGdX1TDfkb3AjHOQqghE(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࠬࢌ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"ࠬ࠭ࢍ"),FIHNSc5iuoZanQ2Ytl(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(JuyDmCElpF7HdcYniGwRXxz46))
			erpxS1nj9JWN = WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࡖࡵࡹࡪए")
	if showDialogs and not erpxS1nj9JWN:
		KK47FGdX1TDfkb3AjHOQqghE(l5mQdjWyczr7UJVnTp(u"ࠧࠨ࢏"),vatyjK4hHAoZJ7rOq2lis(u"ࠨࠩ࢐"),mNkfJnpOrad7hT6PYyciwsSDQ(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),VOq8Ekue4F(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		YTPut68WBVUNCvsEzg.setSetting(uneTx8rbQsJE7KR5Okq0l6dU3V29N(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),vatyjK4hHAoZJ7rOq2lis(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def f8fnKShoBFpCmLAgv0dZYsND(showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࠨ࢖"),oAXJCYqPgyGDtT(u"ࠨࠩࢗ"),S870SR2MoAIgLxzbpFDeKH9XmiZQ3(u"ࠩࠪ࢘"),ZhqJoOtcmTVID65HwnLj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),VH9MDo5z1kxNF07uRJI(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+VOq8Ekue4F(u"ࠬࡢ࡮ࠨ࢛")+WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+sDiKwnHcSlYFgWCy1Ak(u"ࠧ࡝ࡰࠪ࢝")+sbgu4D2RFMYKm(u"ࠨมࠤࠥࠬ࢞")+N9olEh0ZMtpOivVfBLK(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if VjwKs4GNQZ518kCl!=N0Kvne8UYar9fhRxboWsXJCVzid(u"࠷ࣰ"): return
	P8vtuTghFN7lWIS(m7mE4RGSTLH0MsvZnkIrFuB82yYw,EmK3ObA0cwv9Wy(u"ࡘࡷࡻࡥऑ"),Xl3drKyI9HkDiPEf8RTjwu(u"ࡉࡥࡱࡹࡥऐ"))
	P8vtuTghFN7lWIS(FF7JuRlgZpOLAIbhyQfrdan98z1q,VOq8Ekue4F(u"࡚ࡲࡶࡧओ"),EmK3ObA0cwv9Wy(u"ࡋࡧ࡬ࡴࡧऒ"))
	P8vtuTghFN7lWIS(B2WjloumZDaw9VKtnAhEL7s,N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡆࡢ࡮ࡶࡩऔ"),N0Kvne8UYar9fhRxboWsXJCVzid(u"ࡆࡢ࡮ࡶࡩऔ"))
	UGzEr0oSR21KDJgiZQuLYsyHAad(mV8GsI4bwEY,WmaPChRdQk3YcXwI6zS(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		KK47FGdX1TDfkb3AjHOQqghE(PiFkQ5pCJy7fbX(u"ࠪࠫࢠ"),ZEiR0StquOzca9lvPAndYIX(u"ࠫࠬࢡ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),BWh0PmauYpSA9JHxnGV6O8KFc3q(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		YTPut68WBVUNCvsEzg.setSetting(QR0w9rgDN3d8ZMcaveXhSJB2EAViy(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),N9olEh0ZMtpOivVfBLK(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def F8krLCHVbnp31sxg5(showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠪࠫࢧ"),VOq8Ekue4F(u"ࠫࠬࢨ"),HVibA2ES8lY(u"ࠬ࠭ࢩ"),f5uqIoSJzWBOFyrY78RXmVb(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),VOq8Ekue4F(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+sbgu4D2RFMYKm(u"ࠨ࡞ࡱࠫࢬ")+Xl3drKyI9HkDiPEf8RTjwu(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+HVibA2ES8lY(u"ࠪࡠࡳ࠭ࢮ")+N9olEh0ZMtpOivVfBLK(u"ࠫࡄࠧࠡࠨࢯ")+sDiKwnHcSlYFgWCy1Ak(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if VjwKs4GNQZ518kCl!=EEvLoMzFqrlKce(u"࠱ࣱ"): return
	P8vtuTghFN7lWIS(ylhYXwSNniOvtbad0sTZxKgQ,sDiKwnHcSlYFgWCy1Ak(u"ࡈࡤࡰࡸ࡫ख"),sDiKwnHcSlYFgWCy1Ak(u"ࡈࡤࡰࡸ࡫ख"))
	P8vtuTghFN7lWIS(MxJkGEZ0uovBjR6QS5XanrYDhyA,ZEiR0StquOzca9lvPAndYIX(u"ࡉࡥࡱࡹࡥग"),ZEiR0StquOzca9lvPAndYIX(u"ࡉࡥࡱࡹࡥग"))
	P8vtuTghFN7lWIS(VnKQUEv3X6bBghqWO9,oAXJCYqPgyGDtT(u"ࡊࡦࡲࡳࡦघ"),oAXJCYqPgyGDtT(u"ࡊࡦࡲࡳࡦघ"))
	P8vtuTghFN7lWIS(PP5JhNZMAR9oH7K8dbpVCYT6W23z,N9olEh0ZMtpOivVfBLK(u"ࡋࡧ࡬ࡴࡧङ"),N9olEh0ZMtpOivVfBLK(u"ࡋࡧ࡬ࡴࡧङ"))
	P8vtuTghFN7lWIS(E8tTLH5guPVh0,HVibA2ES8lY(u"ࡌࡡ࡭ࡵࡨच"),HVibA2ES8lY(u"ࡌࡡ࡭ࡵࡨच"))
	P8vtuTghFN7lWIS(aPY2e7nwRBNsQyVd0Tb1GICvlDExz6,sDiKwnHcSlYFgWCy1Ak(u"ࡆࡢ࡮ࡶࡩछ"),sDiKwnHcSlYFgWCy1Ak(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		KK47FGdX1TDfkb3AjHOQqghE(VH9MDo5z1kxNF07uRJI(u"࠭ࠧࢱ"),oAXJCYqPgyGDtT(u"ࠧࠨࢲ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		YTPut68WBVUNCvsEzg.setSetting(Xl3drKyI9HkDiPEf8RTjwu(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def UGzEr0oSR21KDJgiZQuLYsyHAad(OHuCxbAZaE45jUGwcrpldz3vDBh0qg,showDialogs):
	if showDialogs:
		VjwKs4GNQZ518kCl = KGEAmiZ9Jq0sTXR(weC96SDJHrtoaGEKO2zPsAYmbZgN1(u"࠭ࠧࢸ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠧࠨࢹ"),vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࠩࢺ"),N9olEh0ZMtpOivVfBLK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),WmaPChRdQk3YcXwI6zS(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+EmK3ObA0cwv9Wy(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if VjwKs4GNQZ518kCl!=l5mQdjWyczr7UJVnTp(u"࠲ࣲ"): return
	kC7JunVyQdExXTaB = EVGFixbHrhvCo67OtpYmnWa3Dy8NSA.connect(OHuCxbAZaE45jUGwcrpldz3vDBh0qg)
	kC7JunVyQdExXTaB.text_factory = str
	SCnhp2blgkLJrvcqKmXdE = kC7JunVyQdExXTaB.cursor()
	SCnhp2blgkLJrvcqKmXdE.execute(N0Kvne8UYar9fhRxboWsXJCVzid(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	SCnhp2blgkLJrvcqKmXdE.execute(TWexH5PhS1(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	SCnhp2blgkLJrvcqKmXdE.execute(EEvLoMzFqrlKce(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	kC7JunVyQdExXTaB.commit()
	SCnhp2blgkLJrvcqKmXdE.execute(EEvLoMzFqrlKce(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	kC7JunVyQdExXTaB.close()
	if showDialogs:
		KK47FGdX1TDfkb3AjHOQqghE(oAXJCYqPgyGDtT(u"ࠩࠪࣂ"),WmaPChRdQk3YcXwI6zS(u"ࠪࠫࣃ"),oAXJCYqPgyGDtT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),WYx8H7qCz1glKj6RrFuAyUGo93DPhE(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		YTPut68WBVUNCvsEzg.setSetting(VH9MDo5z1kxNF07uRJI(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),VH9MDo5z1kxNF07uRJI(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		EO9Rts0AaGuk1qpPLXCY.executebuiltin(g1gqKebNPOTGxi68cEoIwH30tpJvZ(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
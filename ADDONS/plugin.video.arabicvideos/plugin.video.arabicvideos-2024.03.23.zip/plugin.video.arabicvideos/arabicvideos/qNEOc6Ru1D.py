﻿# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
def F5M9LsnokGPEQ2XYfO7cuyr(EHnSrqQ7BvmGlOgYZdhTbCRtswA,WoURenSbtZG8aO3iP2m9Ew):
	if WoURenSbtZG8aO3iP2m9Ew=='': return
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA==1:
		PAtf8I5Vz6xNSOk4M3iqUnLW0EF = Ko1p5u9jwG6rF.getCurrentWindowDialogId()
		T4mKNWUFaIgoGBJXESy6QMq = Ko1p5u9jwG6rF.Window(PAtf8I5Vz6xNSOk4M3iqUnLW0EF)
		WoURenSbtZG8aO3iP2m9Ew = epacjZzdVL5IMrHASuvgqBRkxNnXQJ(WoURenSbtZG8aO3iP2m9Ew)
		T4mKNWUFaIgoGBJXESy6QMq.getControl(311).setLabel(WoURenSbtZG8aO3iP2m9Ew)
	if EHnSrqQ7BvmGlOgYZdhTbCRtswA==0:
		otciIUKlyb6='X'
		if mmIKCGujwM: geJY2oFP0RNU8Q5DzKSnZjL4vCTE = isinstance(WoURenSbtZG8aO3iP2m9Ew,str)
		else: geJY2oFP0RNU8Q5DzKSnZjL4vCTE = isinstance(WoURenSbtZG8aO3iP2m9Ew,unicode)
		if geJY2oFP0RNU8Q5DzKSnZjL4vCTE==True: otciIUKlyb6='U'
		m4cjNgzMAOv8Uu92CIsrikETd756f=str(type(WoURenSbtZG8aO3iP2m9Ew))+' '+WoURenSbtZG8aO3iP2m9Ew+' '+otciIUKlyb6+' '
		for jV1Z7MWOa80gbwJY64nL5 in range(0,len(WoURenSbtZG8aO3iP2m9Ew),1):
			m4cjNgzMAOv8Uu92CIsrikETd756f += hex(ord(WoURenSbtZG8aO3iP2m9Ew[jV1Z7MWOa80gbwJY64nL5])).replace('0x','')+' '
		WoURenSbtZG8aO3iP2m9Ew = epacjZzdVL5IMrHASuvgqBRkxNnXQJ(WoURenSbtZG8aO3iP2m9Ew)
		otciIUKlyb6='X'
		if mmIKCGujwM: geJY2oFP0RNU8Q5DzKSnZjL4vCTE = isinstance(WoURenSbtZG8aO3iP2m9Ew, str)
		else: geJY2oFP0RNU8Q5DzKSnZjL4vCTE = isinstance(WoURenSbtZG8aO3iP2m9Ew, unicode)
		if geJY2oFP0RNU8Q5DzKSnZjL4vCTE==True: otciIUKlyb6='U'
		RfU67TbHgnQ94u0CGk8qPrN3lJdcO=str(type(WoURenSbtZG8aO3iP2m9Ew))+' '+WoURenSbtZG8aO3iP2m9Ew+' '+otciIUKlyb6+' '
		for jV1Z7MWOa80gbwJY64nL5 in range(0,len(WoURenSbtZG8aO3iP2m9Ew),1):
			RfU67TbHgnQ94u0CGk8qPrN3lJdcO += hex(ord(WoURenSbtZG8aO3iP2m9Ew[jV1Z7MWOa80gbwJY64nL5])).replace('0x','')+' '
	return
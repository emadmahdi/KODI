# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'ARABSEED'
headers = {'User-Agent':diwUZMEagkFDlS()}
JJCLnkX4TozH7Bsjivfe = '_ARS_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==250: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==251: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==252: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==253: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==254: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'CATEGORIES___'+text)
	elif mode==255: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'FILTERS___'+text)
	elif mode==256: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url,text)
	elif mode==259: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/main','',headers,'','','ARABSEED-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',HbiLZQKalC+'/category/اخرى',254)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',HbiLZQKalC+'/category/اخرى',255)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',HbiLZQKalC+'/main',251,'','','featured_main')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'جديد الأفلام',HbiLZQKalC+'/main',251,'','','new_movies')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'جديد الحلقات',HbiLZQKalC+'/main',251,'','','new_episodes')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المضاف حديثاً',HbiLZQKalC+'/latest',251,'','','lastest')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('class="MenuHeader"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	MwELA7bGROd1uohvUNKpsrDVWnSyf4 = q9OCkWn6ruAvQLKDFUyxBME0[0]
	uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',MwELA7bGROd1uohvUNKpsrDVWnSyf4,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in uuNm2btCehYgvsIQlODr:
		title = Nkuqp0boKj41i9(title)
		if title not in OZYvGX7EMx05KH1fI and title!='':
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,256)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def rzgXD1OfZMh0bp4A5P(url,type):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if 'class="SliderInSection' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in qQXuaKpVrGLF3e5oidJ8YwDT0: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="LinksList(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			if len(tmEVko4qsghUX6WLx8KG7fOTB)>1 and type=='new_episodes': Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[1]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				tKBSN4Zgn9CDb = T072lCzjYiuaeFtmJGV.findall('</i>(.*?)<span>(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
				try: yvuYVFPClBd03mc8 = tKBSN4Zgn9CDb[0][0]
				except: yvuYVFPClBd03mc8 = ''
				try: SS7cKmHlzATRB5CoYVkrjbLM8e2xJ = tKBSN4Zgn9CDb[0][1]
				except: SS7cKmHlzATRB5CoYVkrjbLM8e2xJ = ''
				tKBSN4Zgn9CDb = yvuYVFPClBd03mc8+SS7cKmHlzATRB5CoYVkrjbLM8e2xJ
				tKBSN4Zgn9CDb = tKBSN4Zgn9CDb.replace('\n','')
				if '<strong>' in title:
					qVPikX2KLyo94HdT1mDWIpFhA = T072lCzjYiuaeFtmJGV.findall('</i>(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
					if qVPikX2KLyo94HdT1mDWIpFhA: tKBSN4Zgn9CDb = qVPikX2KLyo94HdT1mDWIpFhA[0]
				if not tKBSN4Zgn9CDb:
					qVPikX2KLyo94HdT1mDWIpFhA = T072lCzjYiuaeFtmJGV.findall('alt="(.*?)"',title,T072lCzjYiuaeFtmJGV.DOTALL)
					if qVPikX2KLyo94HdT1mDWIpFhA: tKBSN4Zgn9CDb = qVPikX2KLyo94HdT1mDWIpFhA[0]
				if tKBSN4Zgn9CDb:
					if 'key=' in i8sFwPqo1vpEXR2VdHU5BmW: type = i8sFwPqo1vpEXR2VdHU5BmW.split('key=')[1]
					else: type = 'newest'
					tKBSN4Zgn9CDb = tKBSN4Zgn9CDb.strip(' ')
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,i8sFwPqo1vpEXR2VdHU5BmW,251,'','',type)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type):
	p8IuEO9xYm6PgHJri,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			RgvdIclD5i3T0L8UEkBWAV1PX,vf78LSlJQOnCsatrIH2P1iW = 'POST',{}
			ll9khUfx3MjZ,a0EhiOzZL8Ktk4y = url.split('?')
			SXOJtRiHqaUFCp2e = a0EhiOzZL8Ktk4y.split('&')
			for GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g in SXOJtRiHqaUFCp2e:
				key,EYn2siOeDvQTk8KpS0Jl = GtPfOYbsW6mXI0DRu8cx5qrpVyQk1g.split('=')
				vf78LSlJQOnCsatrIH2P1iW[key] = EYn2siOeDvQTk8KpS0Jl
			if SXOJtRiHqaUFCp2e: p8IuEO9xYm6PgHJri,url,data = RgvdIclD5i3T0L8UEkBWAV1PX,ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,p8IuEO9xYm6PgHJri,url,data,headers,'','','ARABSEED-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if type=='filters': tmEVko4qsghUX6WLx8KG7fOTB = [qQXuaKpVrGLF3e5oidJ8YwDT0]
	elif 'featured' in type: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="MainSlides(.*?)class="LinksList',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='new_movies': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='new_episodes': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='most': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="SliderInSection(.*?)class="LinksList',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="Blocks-UL"(.*?)class="AboElSeed"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if 'featured' in type:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		qOoBk5C34pJHFAhY = T072lCzjYiuaeFtmJGV.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if qOoBk5C34pJHFAhY:
			M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL,fJ0Xriqp9eKaVnhw8bLuPxd16s,jxEQ2Yd01g9MSuDVJ = zip(*qOoBk5C34pJHFAhY)
			items = zip(M7oS6tLhdx3ke8qPX4mFA,jxEQ2Yd01g9MSuDVJ,n7CuHMSJpiR9fP0jvNEIyDUL)
	else:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if 'WWE' in title: continue
		title = Nkuqp0boKj41i9(title)
		if 'الحلقة' in title:
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if XSCYbwaqRBtopUc9H2QZu86gA5N:
				title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					BBRwQhFnJ08q9YVxOSya.append(title)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,253,o3gHuBtrRN)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,252,o3gHuBtrRN)
		elif '/selary/' in i8sFwPqo1vpEXR2VdHU5BmW or 'مسلسل' in title:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,253,o3gHuBtrRN)
		else:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,252,o3gHuBtrRN)
	if type in ['newest','best','most']:
		items = T072lCzjYiuaeFtmJGV.findall('page-numbers" href="(.*?)">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
			i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,251,'','',type)
	return
def UAB8vizclM6XG4Pw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0[10000:]
	items = T072lCzjYiuaeFtmJGV.findall('data-src="(.*?)".*?alt="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: return
	o3gHuBtrRN,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="ContainerEpisodesList"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<em>(.*?)</em>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,XSCYbwaqRBtopUc9H2QZu86gA5N in items:
			title = name+' - الحلقة رقم '+XSCYbwaqRBtopUc9H2QZu86gA5N
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,252,o3gHuBtrRN)
	else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+'ملف التشغيل',url,252,o3gHuBtrRN)
	return
def dyO2MU85RAKG3TqzuwtbQChrBxJp6(title,i8sFwPqo1vpEXR2VdHU5BmW):
	tKBSN4Zgn9CDb = T072lCzjYiuaeFtmJGV.findall('[a-zA-Z-]+',title,T072lCzjYiuaeFtmJGV.DOTALL)
	if tKBSN4Zgn9CDb: title = tKBSN4Zgn9CDb[0]
	else: title = title+' '+ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ll9khUfx3MjZ = WM1buqXnzf3Ba6Vp29l4gFD.url
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,'url')
	headers['Referer'] = dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'/'
	sYbhAigGJdnS3Nk7VpD0TZx1FPao8,zLjwTA0QUJ,M7oS6tLhdx3ke8qPX4mFA = '','',[]
	BQzdXV7DkZHREguc = T072lCzjYiuaeFtmJGV.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if BQzdXV7DkZHREguc: sYbhAigGJdnS3Nk7VpD0TZx1FPao8,yc2P5uiMAe0,zLjwTA0QUJ,zgs5N10mMd9PVTRuHA4GWJDycpeLl = BQzdXV7DkZHREguc[0]
	else:
		BQzdXV7DkZHREguc = T072lCzjYiuaeFtmJGV.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if BQzdXV7DkZHREguc:
			i8sFwPqo1vpEXR2VdHU5BmW,yc2P5uiMAe0 = BQzdXV7DkZHREguc[0]
			if 'watch' in yc2P5uiMAe0: sYbhAigGJdnS3Nk7VpD0TZx1FPao8 = i8sFwPqo1vpEXR2VdHU5BmW
			else: zLjwTA0QUJ = i8sFwPqo1vpEXR2VdHU5BmW
	if sYbhAigGJdnS3Nk7VpD0TZx1FPao8:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',sYbhAigGJdnS3Nk7VpD0TZx1FPao8,'',headers,'','','ARABSEED-PLAY-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="WatcherArea"(.*?</ul>)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			WaeQ82J7hg = tmEVko4qsghUX6WLx8KG7fOTB[0]
			WaeQ82J7hg = WaeQ82J7hg.replace('</ul>','<h3>')
			WaeQ82J7hg = WaeQ82J7hg.replace('<h3>','<h3><h3>')
			uuPG8BO037eSynUNE = T072lCzjYiuaeFtmJGV.findall('<h3>.*?(\d+)(.*?)<h3>',WaeQ82J7hg,T072lCzjYiuaeFtmJGV.DOTALL)
			if not uuPG8BO037eSynUNE: uuPG8BO037eSynUNE = [('',WaeQ82J7hg)]
			for Q5OAspyiXV1lx8930qLGD,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in uuPG8BO037eSynUNE:
				if Q5OAspyiXV1lx8930qLGD: Q5OAspyiXV1lx8930qLGD = '____'+Q5OAspyiXV1lx8930qLGD
				items = T072lCzjYiuaeFtmJGV.findall('data-link="(.*?)".*?<span>(.*?)</span>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for i8sFwPqo1vpEXR2VdHU5BmW,name in items:
					if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
					i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__watch'+Q5OAspyiXV1lx8930qLGD
					M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
		kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not kkH5sRPxhASFowLONy4: kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if kkH5sRPxhASFowLONy4:
			i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD = kkH5sRPxhASFowLONy4[0]
			name = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW,'name')
			if '%' in Q5OAspyiXV1lx8930qLGD: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__embed__'
			else: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__embed____'+Q5OAspyiXV1lx8930qLGD
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if zLjwTA0QUJ:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',zLjwTA0QUJ,'',headers,'','','ARABSEED-PLAY-3rd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="DownloadArea"(.*?)function',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title,Q5OAspyiXV1lx8930qLGD in items:
				if not i8sFwPqo1vpEXR2VdHU5BmW: continue
				if 'reviewstation' in i8sFwPqo1vpEXR2VdHU5BmW: continue
				i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW)
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download____'+Q5OAspyiXV1lx8930qLGD
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	Ck9VgesT5Xu4h1z0JnS2UcELMy = str(M7oS6tLhdx3ke8qPX4mFA)
	NhfwnFEGJabTR4Mx = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(EYn2siOeDvQTk8KpS0Jl in Ck9VgesT5Xu4h1z0JnS2UcELMy for EYn2siOeDvQTk8KpS0Jl in NhfwnFEGJabTR4Mx):
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search: search = NWs7KpjXGnxYylofHtd5U3wDh()
	if not search: return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/find/?find='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
def hr0qteMSui7ZzxCoE(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='CATEGORIES':
		if gdCckvHqSI7Ms1OptGaRhuWfeoQ[0]+'==' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = gdCckvHqSI7Ms1OptGaRhuWfeoQ[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(gdCckvHqSI7Ms1OptGaRhuWfeoQ[0:-1])):
			if gdCckvHqSI7Ms1OptGaRhuWfeoQ[jV1Z7MWOa80gbwJY64nL5]+'==' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = gdCckvHqSI7Ms1OptGaRhuWfeoQ[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+ZecS1yJOzVutgX0qiH3NER+'==0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+ZecS1yJOzVutgX0qiH3NER+'==0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		ll9khUfx3MjZ = url+'//getposts??'+YupaFCoAIicOnZNd
	elif type=='FILTERS':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'//getposts??'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(ll9khUfx3MjZ)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها ',zFHuCf5Gpms8XE2MbI0Tc,251,'','','filters')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',zFHuCf5Gpms8XE2MbI0Tc,251,'','','filters')
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	iyjH8SAYvkw07 = T072lCzjYiuaeFtmJGV.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	p0wnrhJtkOQP6a9dZ5glusMvUCW = T072lCzjYiuaeFtmJGV.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = iyjH8SAYvkw07+p0wnrhJtkOQP6a9dZ5glusMvUCW
	dict = {}
	for name,cfWiG8bKuYoq32vDE51hCUxPT,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		items = T072lCzjYiuaeFtmJGV.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('data-rate="(.*?)".*?<em>(.*?)</em>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			items = []
			for jwanU8orZtdFLNvM4EkHphWKzP,EYn2siOeDvQTk8KpS0Jl in uuNm2btCehYgvsIQlODr: items.append([jwanU8orZtdFLNvM4EkHphWKzP,'',EYn2siOeDvQTk8KpS0Jl])
			cfWiG8bKuYoq32vDE51hCUxPT = 'rate'
			name = 'التقييم'
		else: cfWiG8bKuYoq32vDE51hCUxPT = items[0][1]
		if '==' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='CATEGORIES':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<=1:
				if cfWiG8bKuYoq32vDE51hCUxPT==gdCckvHqSI7Ms1OptGaRhuWfeoQ[-1]: Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'CATEGORIES___'+Dwqu0Ws9eK)
				return
			else:
				zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(ll9khUfx3MjZ)
				if cfWiG8bKuYoq32vDE51hCUxPT==gdCckvHqSI7Ms1OptGaRhuWfeoQ[-1]: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع ',zFHuCf5Gpms8XE2MbI0Tc,251,'','','filters')
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع ',ll9khUfx3MjZ,254,'','',Dwqu0Ws9eK)
		elif type=='FILTERS':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'==0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'==0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع :'+name,ll9khUfx3MjZ,255,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for jwanU8orZtdFLNvM4EkHphWKzP,O578ENGbr6PYnLJzi,EYn2siOeDvQTk8KpS0Jl in items:
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			if 'الكل' in jwanU8orZtdFLNvM4EkHphWKzP: continue
			jwanU8orZtdFLNvM4EkHphWKzP = Nkuqp0boKj41i9(jwanU8orZtdFLNvM4EkHphWKzP)
			UliDv052e7j,tKBSN4Zgn9CDb = jwanU8orZtdFLNvM4EkHphWKzP,jwanU8orZtdFLNvM4EkHphWKzP
			tKBSN4Zgn9CDb = name+': '+UliDv052e7j
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = tKBSN4Zgn9CDb
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'=='+UliDv052e7j
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&&'+cfWiG8bKuYoq32vDE51hCUxPT+'=='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			if type=='FILTERS':
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url,255,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='CATEGORIES' and gdCckvHqSI7Ms1OptGaRhuWfeoQ[-2]+'==' in cghHqoyS13upLUdz8bkXO7wlPK:
				YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'modified_filters')
				dCmKxk9BW310AXu4bJUHfY = url+'//getposts??'+YupaFCoAIicOnZNd
				zFHuCf5Gpms8XE2MbI0Tc = N1GlK9FfkpJTcmRjrO8qUM(dCmKxk9BW310AXu4bJUHfY)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,zFHuCf5Gpms8XE2MbI0Tc,251,'','','filters')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+tKBSN4Zgn9CDb,url,254,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
gdCckvHqSI7Ms1OptGaRhuWfeoQ = ['category','country','release-year']
XXVdjvcBrSY1yNKf = ['category','country','genre','release-year','language','quality','rate']
def N1GlK9FfkpJTcmRjrO8qUM(url):
	N2Ndq4DCw95WgZ = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',N2Ndq4DCw95WgZ)
	url = url.replace('/category/اخرى','')
	if N2Ndq4DCw95WgZ not in url: url = url+N2Ndq4DCw95WgZ
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&&')
	H5y1ofSbMzmN7JI,lZrWcL5Ts4SK78wXChVy16DPRkv9 = {},''
	if '==' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('==')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	for key in XXVdjvcBrSY1yNKf:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if '%' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = K3PukgCEDY(EYn2siOeDvQTk8KpS0Jl)
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&&'+key+'=='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&&'+key+'=='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&&')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
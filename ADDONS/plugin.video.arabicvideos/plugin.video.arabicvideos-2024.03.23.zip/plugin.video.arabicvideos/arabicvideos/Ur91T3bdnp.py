# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'IFILM'
JJCLnkX4TozH7Bsjivfe = '_IFL_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
m0nJ6xfD21QG3FyNP4WlT7u = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][1]
Sc5G6syLeHohmZvd0IMCQpPBgu = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][2]
YYgkfBsu31WcVTiSqLQx8ZvhtwJ = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][3]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,ffGe7cURW0lhJVvQAiw8IB,text):
	if   mode==20: cLCisPE3lX = OLYz1t2FDhqeySHXPuWUT0rMB()
	elif mode==21: cLCisPE3lX = lD8xr3zag19KuC(url)
	elif mode==22: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==23: cLCisPE3lX = UAB8vizclM6XG4Pw(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==24: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url,text)
	elif mode==25: cLCisPE3lX = mmifIJZlHKwFdshU1ESox8gzA93TpG(url)
	elif mode==27: cLCisPE3lX = Dzi0rPWaLn45GIfdCy762(url)
	elif mode==28: cLCisPE3lX = uRGYvSPqJzgfsyj4aXKhwMkOn()
	elif mode==29: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def OLYz1t2FDhqeySHXPuWUT0rMB():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'عربي',HbiLZQKalC,21,'','101')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'English',m0nJ6xfD21QG3FyNP4WlT7u,21,'','101')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فارسى',Sc5G6syLeHohmZvd0IMCQpPBgu,21,'','101')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فارسى 2',YYgkfBsu31WcVTiSqLQx8ZvhtwJ,21,'','101')
	return
def uRGYvSPqJzgfsyj4aXKhwMkOn():
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'عربي',HbiLZQKalC,27)
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'English',m0nJ6xfD21QG3FyNP4WlT7u,27)
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'فارسى',Sc5G6syLeHohmZvd0IMCQpPBgu,27)
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+'فارسى 2',YYgkfBsu31WcVTiSqLQx8ZvhtwJ,27)
	return
def lD8xr3zag19KuC(IMH4SbeVkWaO):
	nO6ukabcldeU = IMH4SbeVkWaO
	if IMH4SbeVkWaO=='IFILM-ARABIC': IMH4SbeVkWaO = HbiLZQKalC
	elif IMH4SbeVkWaO=='IFILM-ENGLISH': IMH4SbeVkWaO = m0nJ6xfD21QG3FyNP4WlT7u
	else: nO6ukabcldeU = ''
	epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(IMH4SbeVkWaO)
	if epouLG68wMUYWC91aRhKmn4xA=='ar' or nO6ukabcldeU=='IFILM-ARABIC':
		BLV1MnHahScyrzf3X4w0mKep2ud7x = 'بحث في الموقع'
		gBQxOqabPovs7y = 'مسلسلات - حالية'
		dFEpvGRU73W6TowXj5xV8 = 'مسلسلات - أحدث'
		eeaoML3QBw9d = 'مسلسلات - أبجدي'
		kUev3Pgdw4HZcTp8IsmE56YWaJAqMF = 'بث حي آي فيلم'
		jtDgak0dym2rsY = 'أفلام'
		mmOwP7zaVFCcEhJZ = 'موسيقى'
		yN1UTRkHXMaEW = 'برامج'
	elif epouLG68wMUYWC91aRhKmn4xA=='en' or nO6ukabcldeU=='IFILM-ENGLISH':
		BLV1MnHahScyrzf3X4w0mKep2ud7x = 'Search in site'
		gBQxOqabPovs7y = 'Series - Current'
		dFEpvGRU73W6TowXj5xV8 = 'Series - Latest'
		eeaoML3QBw9d = 'Series - Alphabet'
		kUev3Pgdw4HZcTp8IsmE56YWaJAqMF = 'Live iFilm channel'
		jtDgak0dym2rsY = 'Movies'
		mmOwP7zaVFCcEhJZ = 'Music'
		yN1UTRkHXMaEW = 'Shows'
	elif epouLG68wMUYWC91aRhKmn4xA in ['fa','fa2']:
		BLV1MnHahScyrzf3X4w0mKep2ud7x = 'جستجو در سایت'
		gBQxOqabPovs7y = 'سريال - جاری'
		dFEpvGRU73W6TowXj5xV8 = 'سريال - آخرین'
		eeaoML3QBw9d = 'سريال - الفبا'
		kUev3Pgdw4HZcTp8IsmE56YWaJAqMF = 'پخش زنده اي فيلم'
		jtDgak0dym2rsY = 'فيلم'
		mmOwP7zaVFCcEhJZ = 'موسيقى'
		yN1UTRkHXMaEW = 'برنامه ها'
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+BLV1MnHahScyrzf3X4w0mKep2ud7x,IMH4SbeVkWaO,29,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('live',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+kUev3Pgdw4HZcTp8IsmE56YWaJAqMF,IMH4SbeVkWaO,27)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	vAujiEeLZbowS2Xgp5830Yc = ['Series','Program','Music']
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,IMH4SbeVkWaO+'/home','','','','IFILM-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB=T072lCzjYiuaeFtmJGV.findall('button-menu(.*?)/Contact',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if any(EYn2siOeDvQTk8KpS0Jl in i8sFwPqo1vpEXR2VdHU5BmW for EYn2siOeDvQTk8KpS0Jl in vAujiEeLZbowS2Xgp5830Yc):
				url = IMH4SbeVkWaO+i8sFwPqo1vpEXR2VdHU5BmW
				if 'Series' in i8sFwPqo1vpEXR2VdHU5BmW:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,url,22,'','100')
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+dFEpvGRU73W6TowXj5xV8,url,22,'','101')
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+eeaoML3QBw9d,url,22,'','201')
				elif 'Film' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+jtDgak0dym2rsY,url,22,'','100')
				elif 'Music' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+mmOwP7zaVFCcEhJZ,url,25,'','101')
				elif 'Program' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+yN1UTRkHXMaEW,url,22,'','101')
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def mmifIJZlHKwFdshU1ESox8gzA93TpG(url):
	IMH4SbeVkWaO = Y9gazsycKe4nQqHp6(url)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'','','','IFILM-MUSIC_MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('Music-tools-header(.*?)Music-body',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	title = T072lCzjYiuaeFtmJGV.findall('<p>(.*?)</p>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)[0]
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,22,'','101')
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = IMH4SbeVkWaO + i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,23,'','101')
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB):
	IMH4SbeVkWaO = Y9gazsycKe4nQqHp6(url)
	epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(url)
	type = url.split('/')[-1]
	MatQs4VANWnZrodDLIvHB = str(int(ffGe7cURW0lhJVvQAiw8IB)//100)
	ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)%100)
	if type=='Series' and ffGe7cURW0lhJVvQAiw8IB=='0':
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','IFILM-TITLES-1st')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('serial-body(.*?)class="row',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			title = Bd2o0J6aOASWvuD9HzY(title)
			title = Nkuqp0boKj41i9(title)
			i8sFwPqo1vpEXR2VdHU5BmW = IMH4SbeVkWaO + i8sFwPqo1vpEXR2VdHU5BmW
			o3gHuBtrRN = IMH4SbeVkWaO + K3PukgCEDY(o3gHuBtrRN)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,23,o3gHuBtrRN,MatQs4VANWnZrodDLIvHB+'01')
	uqGkDJpiln9UayVQzvj0h=0
	if type=='Series': ZecS1yJOzVutgX0qiH3NER='3'
	if type=='Film': ZecS1yJOzVutgX0qiH3NER='5'
	if type=='Program': ZecS1yJOzVutgX0qiH3NER='7'
	if type in ['Series','Program','Film'] and ffGe7cURW0lhJVvQAiw8IB!='0':
		ll9khUfx3MjZ = IMH4SbeVkWaO+'/Home/PageingItem?category='+ZecS1yJOzVutgX0qiH3NER+'&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&orderby='+MatQs4VANWnZrodDLIvHB
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-TITLES-2nd')
		items = T072lCzjYiuaeFtmJGV.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for id,title,o3gHuBtrRN in items:
			title = Bd2o0J6aOASWvuD9HzY(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			uqGkDJpiln9UayVQzvj0h += 1
			i8sFwPqo1vpEXR2VdHU5BmW = IMH4SbeVkWaO + '/' + type + '/Content/' + id
			o3gHuBtrRN = IMH4SbeVkWaO + K3PukgCEDY(o3gHuBtrRN)
			if type=='Film': QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,24,o3gHuBtrRN,MatQs4VANWnZrodDLIvHB+'01')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,23,o3gHuBtrRN,MatQs4VANWnZrodDLIvHB+'01')
	if type=='Music':
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,IMH4SbeVkWaO+'/Music/Index?page='+ffGe7cURW0lhJVvQAiw8IB,'','','','IFILM-TITLES-3rd')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('pagination-demo(.*?)pagination-demo',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
			uqGkDJpiln9UayVQzvj0h += 1
			o3gHuBtrRN = IMH4SbeVkWaO + o3gHuBtrRN
			i8sFwPqo1vpEXR2VdHU5BmW = IMH4SbeVkWaO + i8sFwPqo1vpEXR2VdHU5BmW
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,23,o3gHuBtrRN,'101')
	if uqGkDJpiln9UayVQzvj0h>20:
		title='صفحة '
		if epouLG68wMUYWC91aRhKmn4xA=='en': title = 'Page '
		if epouLG68wMUYWC91aRhKmn4xA=='fa': title = 'صفحه '
		if epouLG68wMUYWC91aRhKmn4xA=='fa2': title = 'صفحه '
		for I5fxZD42mz9MludrRhQPOSo in range(1,11) :
			if not ffGe7cURW0lhJVvQAiw8IB==str(I5fxZD42mz9MludrRhQPOSo):
				jcAzKmQgBDd3IkyNoqhEP0sMYxC = '0'+str(I5fxZD42mz9MludrRhQPOSo)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title+str(I5fxZD42mz9MludrRhQPOSo),url,22,'',MatQs4VANWnZrodDLIvHB+jcAzKmQgBDd3IkyNoqhEP0sMYxC[-2:])
	return
def UAB8vizclM6XG4Pw(url,ffGe7cURW0lhJVvQAiw8IB):
	if not ffGe7cURW0lhJVvQAiw8IB: ffGe7cURW0lhJVvQAiw8IB = 0
	IMH4SbeVkWaO = Y9gazsycKe4nQqHp6(url)
	VXb3zNxluwGApD2HhWP8dJfLIYj = Y9gazsycKe4nQqHp6(url)
	epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(url)
	eHquV9G0n2wlLjOvC5PUW = url.split('/')
	id,type = eHquV9G0n2wlLjOvC5PUW[-1],eHquV9G0n2wlLjOvC5PUW[3]
	MatQs4VANWnZrodDLIvHB = str(int(ffGe7cURW0lhJVvQAiw8IB)//100)
	ffGe7cURW0lhJVvQAiw8IB = str(int(ffGe7cURW0lhJVvQAiw8IB)%100)
	uqGkDJpiln9UayVQzvj0h = 0
	if type=='Series':
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','IFILM-EPISODES-1st')
		items = T072lCzjYiuaeFtmJGV.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		title = ' - الحلقة '
		if epouLG68wMUYWC91aRhKmn4xA=='en': title = ' - Episode '
		if epouLG68wMUYWC91aRhKmn4xA=='fa': title = ' - قسمت '
		if epouLG68wMUYWC91aRhKmn4xA=='fa2': title = ' - قسمت '
		if epouLG68wMUYWC91aRhKmn4xA=='fa': WkPLlxbJywahC = ''
		else: WkPLlxbJywahC = epouLG68wMUYWC91aRhKmn4xA
		vdPhexayS4GZjuT97BqQbzWcFOV = T072lCzjYiuaeFtmJGV.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		for name,count,o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW in items:
			for XSCYbwaqRBtopUc9H2QZu86gA5N in range(int(count),0,-1):
				xvOTRFiIJbU43E = o3gHuBtrRN + WkPLlxbJywahC + id + '/' + str(XSCYbwaqRBtopUc9H2QZu86gA5N) + '.png'
				gBQxOqabPovs7y = name + title + str(XSCYbwaqRBtopUc9H2QZu86gA5N)
				gBQxOqabPovs7y = Nkuqp0boKj41i9(gBQxOqabPovs7y)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,url,24,xvOTRFiIJbU43E,'',str(XSCYbwaqRBtopUc9H2QZu86gA5N))
	elif type=='Program':
		ll9khUfx3MjZ = IMH4SbeVkWaO+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&orderby=1'
		qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-EPISODES-2nd')
		items = T072lCzjYiuaeFtmJGV.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		title = ' - الحلقة '
		if epouLG68wMUYWC91aRhKmn4xA=='en': title = ' - Episode '
		if epouLG68wMUYWC91aRhKmn4xA=='fa': title = ' - قسمت '
		if epouLG68wMUYWC91aRhKmn4xA=='fa2': title = ' - قسمت '
		for XSCYbwaqRBtopUc9H2QZu86gA5N,o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,NNEkwrvhMx,name in items:
			uqGkDJpiln9UayVQzvj0h += 1
			xvOTRFiIJbU43E = VXb3zNxluwGApD2HhWP8dJfLIYj + K3PukgCEDY(o3gHuBtrRN)
			name = Bd2o0J6aOASWvuD9HzY(name)
			gBQxOqabPovs7y = name + title + str(XSCYbwaqRBtopUc9H2QZu86gA5N)
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,ll9khUfx3MjZ,24,xvOTRFiIJbU43E,'',str(uqGkDJpiln9UayVQzvj0h))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			ll9khUfx3MjZ = IMH4SbeVkWaO+'/Music/GetTracksBy?id='+str(id)+'&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&type=0'
			qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-EPISODES-3rd')
			items = T072lCzjYiuaeFtmJGV.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,name,title in items:
				uqGkDJpiln9UayVQzvj0h += 1
				xvOTRFiIJbU43E = VXb3zNxluwGApD2HhWP8dJfLIYj + K3PukgCEDY(o3gHuBtrRN)
				gBQxOqabPovs7y = name + ' - ' + title
				gBQxOqabPovs7y = gBQxOqabPovs7y.strip(' ')
				gBQxOqabPovs7y = Bd2o0J6aOASWvuD9HzY(gBQxOqabPovs7y)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,ll9khUfx3MjZ,24,xvOTRFiIJbU43E,'',str(uqGkDJpiln9UayVQzvj0h))
		elif 'Clips' in url:
			ll9khUfx3MjZ = IMH4SbeVkWaO+'/Music/GetTracksBy?id=0&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&type=15'
			qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-EPISODES-4th')
			items = T072lCzjYiuaeFtmJGV.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			for o3gHuBtrRN,title,i8sFwPqo1vpEXR2VdHU5BmW in items:
				uqGkDJpiln9UayVQzvj0h += 1
				xvOTRFiIJbU43E = VXb3zNxluwGApD2HhWP8dJfLIYj + K3PukgCEDY(o3gHuBtrRN)
				gBQxOqabPovs7y = title.strip(' ')
				gBQxOqabPovs7y = Bd2o0J6aOASWvuD9HzY(gBQxOqabPovs7y)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,ll9khUfx3MjZ,24,xvOTRFiIJbU43E,'',str(uqGkDJpiln9UayVQzvj0h))
		elif 'category' in url:
			if 'category=6' in url:
				ll9khUfx3MjZ = IMH4SbeVkWaO+'/Music/GetTracksBy?id=0&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&type=6'
				qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				ll9khUfx3MjZ = IMH4SbeVkWaO+'/Music/GetTracksBy?id=0&page='+ffGe7cURW0lhJVvQAiw8IB+'&size=30&type=4'
				qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-EPISODES-6th')
			items = T072lCzjYiuaeFtmJGV.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,name,title in items:
				uqGkDJpiln9UayVQzvj0h += 1
				xvOTRFiIJbU43E = VXb3zNxluwGApD2HhWP8dJfLIYj + K3PukgCEDY(o3gHuBtrRN)
				gBQxOqabPovs7y = name + ' - ' + title
				gBQxOqabPovs7y = gBQxOqabPovs7y.strip(' ')
				gBQxOqabPovs7y = Bd2o0J6aOASWvuD9HzY(gBQxOqabPovs7y)
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+gBQxOqabPovs7y,ll9khUfx3MjZ,24,xvOTRFiIJbU43E,'',str(uqGkDJpiln9UayVQzvj0h))
	if type=='Music' or type=='Program':
		if uqGkDJpiln9UayVQzvj0h>25:
			title='صفحة '
			if epouLG68wMUYWC91aRhKmn4xA=='en': title = ' Page '
			if epouLG68wMUYWC91aRhKmn4xA=='fa': title = ' صفحه '
			if epouLG68wMUYWC91aRhKmn4xA=='fa2': title = ' صفحه '
			for I5fxZD42mz9MludrRhQPOSo in range(1,11):
				if not ffGe7cURW0lhJVvQAiw8IB==str(I5fxZD42mz9MludrRhQPOSo):
					jcAzKmQgBDd3IkyNoqhEP0sMYxC = '0'+str(I5fxZD42mz9MludrRhQPOSo)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title+str(I5fxZD42mz9MludrRhQPOSo),url,23,'',MatQs4VANWnZrodDLIvHB+jcAzKmQgBDd3IkyNoqhEP0sMYxC[-2:])
	return
def JwYEQUDupG2WLPzHndc(url,XSCYbwaqRBtopUc9H2QZu86gA5N):
	VXb3zNxluwGApD2HhWP8dJfLIYj = Y9gazsycKe4nQqHp6(url)
	n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = [],[]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'','','','IFILM-PLAY-1st')
	items = T072lCzjYiuaeFtmJGV.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(url)
		eHquV9G0n2wlLjOvC5PUW = url.split('/')
		id,type = eHquV9G0n2wlLjOvC5PUW[-1],eHquV9G0n2wlLjOvC5PUW[3]
		i8sFwPqo1vpEXR2VdHU5BmW = items[0][0]+epouLG68wMUYWC91aRhKmn4xA+id+'/,'+XSCYbwaqRBtopUc9H2QZu86gA5N+','+XSCYbwaqRBtopUc9H2QZu86gA5N+'_'+items[0][2]
		n7CuHMSJpiR9fP0jvNEIyDUL.append('m3u8')
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	items = T072lCzjYiuaeFtmJGV.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(url)
		eHquV9G0n2wlLjOvC5PUW = url.split('/')
		id,type = eHquV9G0n2wlLjOvC5PUW[-1],eHquV9G0n2wlLjOvC5PUW[3]
		i8sFwPqo1vpEXR2VdHU5BmW = items[0][0]+epouLG68wMUYWC91aRhKmn4xA+id+'/'+XSCYbwaqRBtopUc9H2QZu86gA5N+items[0][2]
		n7CuHMSJpiR9fP0jvNEIyDUL.append('mp4 url')
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW in items:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('//','/')
		n7CuHMSJpiR9fP0jvNEIyDUL.append('mp4 src')
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	items = T072lCzjYiuaeFtmJGV.findall('VideoAddress":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		i8sFwPqo1vpEXR2VdHU5BmW = items[int(XSCYbwaqRBtopUc9H2QZu86gA5N)-1]
		i8sFwPqo1vpEXR2VdHU5BmW = VXb3zNxluwGApD2HhWP8dJfLIYj+K3PukgCEDY(i8sFwPqo1vpEXR2VdHU5BmW)
		n7CuHMSJpiR9fP0jvNEIyDUL.append('mp4 address')
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	items = T072lCzjYiuaeFtmJGV.findall('VoiceAddress":"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		i8sFwPqo1vpEXR2VdHU5BmW = items[int(XSCYbwaqRBtopUc9H2QZu86gA5N)-1]
		i8sFwPqo1vpEXR2VdHU5BmW = VXb3zNxluwGApD2HhWP8dJfLIYj+K3PukgCEDY(i8sFwPqo1vpEXR2VdHU5BmW)
		n7CuHMSJpiR9fP0jvNEIyDUL.append('mp3 address')
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if len(M7oS6tLhdx3ke8qPX4mFA)==1: i8sFwPqo1vpEXR2VdHU5BmW = M7oS6tLhdx3ke8qPX4mFA[0]
	else:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر الفيديو المناسب:', n7CuHMSJpiR9fP0jvNEIyDUL)
		if tzgWIKy5xQL2kjm == -1 : return
		i8sFwPqo1vpEXR2VdHU5BmW = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	pidYDcjvhgVfqb3GeWSAOH5J(i8sFwPqo1vpEXR2VdHU5BmW,nO6ukabcldeU,'video')
	return
def Y9gazsycKe4nQqHp6(url):
	if HbiLZQKalC in url: vuyTFsAd72wDBiUPSnft5obMjErR6 = HbiLZQKalC
	elif m0nJ6xfD21QG3FyNP4WlT7u in url: vuyTFsAd72wDBiUPSnft5obMjErR6 = m0nJ6xfD21QG3FyNP4WlT7u
	elif Sc5G6syLeHohmZvd0IMCQpPBgu in url: vuyTFsAd72wDBiUPSnft5obMjErR6 = Sc5G6syLeHohmZvd0IMCQpPBgu
	elif YYgkfBsu31WcVTiSqLQx8ZvhtwJ in url: vuyTFsAd72wDBiUPSnft5obMjErR6 = YYgkfBsu31WcVTiSqLQx8ZvhtwJ
	else: vuyTFsAd72wDBiUPSnft5obMjErR6 = ''
	return vuyTFsAd72wDBiUPSnft5obMjErR6
def riypYLfA5Pn6GsMIuUwKm3Z2(url):
	if   HbiLZQKalC in url: epouLG68wMUYWC91aRhKmn4xA = 'ar'
	elif m0nJ6xfD21QG3FyNP4WlT7u in url: epouLG68wMUYWC91aRhKmn4xA = 'en'
	elif Sc5G6syLeHohmZvd0IMCQpPBgu in url: epouLG68wMUYWC91aRhKmn4xA = 'fa'
	elif YYgkfBsu31WcVTiSqLQx8ZvhtwJ in url: epouLG68wMUYWC91aRhKmn4xA = 'fa2'
	else: epouLG68wMUYWC91aRhKmn4xA = ''
	return epouLG68wMUYWC91aRhKmn4xA
def Dzi0rPWaLn45GIfdCy762(url):
	epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(url)
	ll9khUfx3MjZ = url + '/Home/Live'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',ll9khUfx3MjZ,'','','','','IFILM-LIVE-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	dCmKxk9BW310AXu4bJUHfY = items[0]
	pidYDcjvhgVfqb3GeWSAOH5J(dCmKxk9BW310AXu4bJUHfY,nO6ukabcldeU,'live')
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	xC2GuEcJKk3t4Uh = search.replace(' ','+')
	if showDialogs:
		UmCMRfwcVPdaSW1uIXzkEO = [ HbiLZQKalC , m0nJ6xfD21QG3FyNP4WlT7u , Sc5G6syLeHohmZvd0IMCQpPBgu , YYgkfBsu31WcVTiSqLQx8ZvhtwJ ]
		FOqwn36QHCgpI8SXRNT1P2mdE = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر اللغة المناسبة:', FOqwn36QHCgpI8SXRNT1P2mdE)
		if tzgWIKy5xQL2kjm == -1 : return
		website = UmCMRfwcVPdaSW1uIXzkEO[tzgWIKy5xQL2kjm]
	else:
		if '_IFILM-ARABIC_' in ZNpFGHa28C9WcoRb: website = HbiLZQKalC
		elif '_IFILM-ENGLISH_' in ZNpFGHa28C9WcoRb: website = m0nJ6xfD21QG3FyNP4WlT7u
		else: website = ''
	if not website: return
	epouLG68wMUYWC91aRhKmn4xA = riypYLfA5Pn6GsMIuUwKm3Z2(website)
	ll9khUfx3MjZ = website + "/Home/Search?searchstring=" + xC2GuEcJKk3t4Uh
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,ll9khUfx3MjZ,'','','','IFILM-SEARCH-1st')
	items = T072lCzjYiuaeFtmJGV.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if items:
		for o3gHuBtrRN,ZecS1yJOzVutgX0qiH3NER,id,title in items:
			if ZecS1yJOzVutgX0qiH3NER in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if ZecS1yJOzVutgX0qiH3NER=='3':
					type = 'Series'
					if epouLG68wMUYWC91aRhKmn4xA=='ar': name = 'مسلسل : '
					elif epouLG68wMUYWC91aRhKmn4xA=='en': name = 'Series : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa': name = 'سريال ها : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa2': name = 'سريال ها : '
				elif ZecS1yJOzVutgX0qiH3NER=='5':
					type = 'Film'
					if epouLG68wMUYWC91aRhKmn4xA=='ar': name = 'فيلم : '
					elif epouLG68wMUYWC91aRhKmn4xA=='en': name = 'Movie : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa': name = 'فيلم : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa2': name = 'فلم ها : '
				elif ZecS1yJOzVutgX0qiH3NER=='7':
					type = 'Program'
					if epouLG68wMUYWC91aRhKmn4xA=='ar': name = 'برنامج : '
					elif epouLG68wMUYWC91aRhKmn4xA=='en': name = 'Program : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa': name = 'برنامه ها : '
					elif epouLG68wMUYWC91aRhKmn4xA=='fa2': name = 'برنامه ها : '
				title = name + title
				i8sFwPqo1vpEXR2VdHU5BmW = website + '/' + type + '/Content/' + id
				o3gHuBtrRN = K3PukgCEDY(o3gHuBtrRN)
				o3gHuBtrRN = website+o3gHuBtrRN
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,23,o3gHuBtrRN,'101')
	return
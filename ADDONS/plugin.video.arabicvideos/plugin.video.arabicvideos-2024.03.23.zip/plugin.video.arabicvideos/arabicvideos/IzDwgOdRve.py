# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'CIMALIGHT'
JJCLnkX4TozH7Bsjivfe = '_CML_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['قنوات فضائية']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==470: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==471: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==472: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==473: cLCisPE3lX = UAB8vizclM6XG4Pw(url,text)
	elif mode==474: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==479: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','CIMALIGHT-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = T072lCzjYiuaeFtmJGV.findall('"url": "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	LL2d9tanw0mrxJBKAT63buD = LL2d9tanw0mrxJBKAT63buD[0].strip('/')
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(LL2d9tanw0mrxJBKAT63buD,'url')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',479,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أفلام مميزة',LL2d9tanw0mrxJBKAT63buD,471,'','','featured_movies')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"content"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = title.replace('  ','').strip(' ')
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('cat=online-movies1','cat=online-movies')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,474)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('/category.php">(.*?)"navslide-divider"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("'dropdown-menu'(.*?)</ul>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,474)
	return
def rzgXD1OfZMh0bp4A5P(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if 'topvideos.php' in url: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"caret"(.*?)id="pm-grid"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"caret"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if 'topvideos.php' in i8sFwPqo1vpEXR2VdHU5BmW:
				if 'topvideos.php?c=english-movies' in i8sFwPqo1vpEXR2VdHU5BmW: continue
				if 'topvideos.php?c=online-movies1' in i8sFwPqo1vpEXR2VdHU5BmW: continue
				if 'topvideos.php?c=misc' in i8sFwPqo1vpEXR2VdHU5BmW: continue
				if 'topvideos.php?c=tv-channel' in i8sFwPqo1vpEXR2VdHU5BmW: continue
				if 'منذ البداية' in title and 'do=rating' not in i8sFwPqo1vpEXR2VdHU5BmW: continue
			else: title = 'ترتيب باستخدام:  '+title
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,471)
	else: Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,iYvJPtR357SbyQf1=''):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMALIGHT-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = []
	if iYvJPtR357SbyQf1=='featured_movies':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"container-fluid"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		kkH5sRPxhASFowLONy4,lNwOdSoA6E,RygfmUZGhsPWr = zip(*items)
		items = zip(RygfmUZGhsPWr,kkH5sRPxhASFowLONy4,lNwOdSoA6E)
	elif iYvJPtR357SbyQf1=='featured_series':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('المسلسلات المميزة(.*?)<style>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		kkH5sRPxhASFowLONy4,lNwOdSoA6E,RygfmUZGhsPWr = zip(*items)
		items = zip(RygfmUZGhsPWr,kkH5sRPxhASFowLONy4,lNwOdSoA6E)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(data-echo=".*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"BlocksList"(.*?)"titleSectionCon"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="pm-grid"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="pm-related"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: return
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not items: items = T072lCzjYiuaeFtmJGV.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items: items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW).strip('/')
		title = title.replace('ماي سيما','').replace('مشاهدة','').strip(' ').replace('  ',' ')
		if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
		if 'http' not in o3gHuBtrRN: o3gHuBtrRN = LL2d9tanw0mrxJBKAT63buD+'/'+o3gHuBtrRN.strip('/')
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			title = '_MOD_'+title
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,472,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'الحلقة' in title:
			title = '_MOD_'+XSCYbwaqRBtopUc9H2QZu86gA5N[0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,473,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/movseries/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,471,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,473,o3gHuBtrRN)
	if iYvJPtR357SbyQf1 not in ['featured_movies','featured_series']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				title = Nkuqp0boKj41i9(title)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,471)
		sc8WJeUnfo6MuLH1ZiOkhVdgP7 = T072lCzjYiuaeFtmJGV.findall('showmore" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if sc8WJeUnfo6MuLH1ZiOkhVdgP7:
			i8sFwPqo1vpEXR2VdHU5BmW = sc8WJeUnfo6MuLH1ZiOkhVdgP7[0]
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مشاهدة المزيد',i8sFwPqo1vpEXR2VdHU5BmW,471)
	return
def UAB8vizclM6XG4Pw(url,owZaqWpIcVhyDHXliB4dgRUr):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMALIGHT-EPISODES-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"SeasonsBox"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('id="'+owZaqWpIcVhyDHXliB4dgRUr+'"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	items = []
	if GVznW0jE3yMFaqK2uZvw1HBrtC and not owZaqWpIcVhyDHXliB4dgRUr:
		o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('"series-header".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		o3gHuBtrRN = o3gHuBtrRN[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('openCity\(event\, \'(.*?)\'\)">(.*?)</button>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for owZaqWpIcVhyDHXliB4dgRUr,title in items: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,473,o3gHuBtrRN,'',owZaqWpIcVhyDHXliB4dgRUr)
	elif q9OCkWn6ruAvQLKDFUyxBME0:
		o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('"series-header".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		o3gHuBtrRN = o3gHuBtrRN[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall("title='(.*?)' href='(.*?)'",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,472,o3gHuBtrRN)
		else:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/'+i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,472,o3gHuBtrRN)
	if 'id="pm-related"' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		if items: QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مواضيع ذات صلة',url,471)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','CIMALIGHT-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<div itemprop="description">(.*?)href=',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('<p>(.*?)</p>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl,True): return
	ll9khUfx3MjZ = url.replace('/watch.php','/play.php')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMALIGHT-PLAY-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	HELzjS4wZO7QDB5d93eNa = []
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"embedURL" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]
		if i8sFwPqo1vpEXR2VdHU5BmW and i8sFwPqo1vpEXR2VdHU5BmW not in HELzjS4wZO7QDB5d93eNa:
			HELzjS4wZO7QDB5d93eNa.append(i8sFwPqo1vpEXR2VdHU5BmW)
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named=__embed'
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	items = T072lCzjYiuaeFtmJGV.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if i8sFwPqo1vpEXR2VdHU5BmW not in HELzjS4wZO7QDB5d93eNa:
			HELzjS4wZO7QDB5d93eNa.append(i8sFwPqo1vpEXR2VdHU5BmW)
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	ll9khUfx3MjZ = url.replace('/watch.php','/downloads.php')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','CIMALIGHT-PLAY-3rd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"downloadlist"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<strong>(.*?)</strong>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if i8sFwPqo1vpEXR2VdHU5BmW not in HELzjS4wZO7QDB5d93eNa:
				HELzjS4wZO7QDB5d93eNa.append(i8sFwPqo1vpEXR2VdHU5BmW)
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = 'http:'+i8sFwPqo1vpEXR2VdHU5BmW
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/search.php?keywords='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
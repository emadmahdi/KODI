# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
eNv8QX5p0UAnMx6sdk = 'M3U'
I5ZiQhtuXSmd96BNLoPwGU = '_M3U_'
MENHxhV1f6JI3o2pO54D9gbuyGakiT = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
ddskb1JG9RjTK0wzAo5VEhZXFHc6 = 4
def QoegtqjHpENh(EHnSrqQ7BvmGlOgYZdhTbCRtswA,HHPwg71GEVju,yv8XxUjorzB2CRA4Jife73VMklHp,ga4p3IxqUXMjTRPQZfH9J5E,Fa9EIfiBzwm13QhVUr,fKFIOvsD0QVzUGLliAyw):
	global I5ZiQhtuXSmd96BNLoPwGU
	try:
		kQ3iPAjXHKCWe = str(fKFIOvsD0QVzUGLliAyw['folder'])
		I5ZiQhtuXSmd96BNLoPwGU = '_MU'+kQ3iPAjXHKCWe+'_'
	except: kQ3iPAjXHKCWe = ''
	try: m3GDX2bd7jku1KQrZeNwABcUEP4ynV = str(fKFIOvsD0QVzUGLliAyw['sequence'])
	except: m3GDX2bd7jku1KQrZeNwABcUEP4ynV = ''
	if   EHnSrqQ7BvmGlOgYZdhTbCRtswA==710: XVFsOLPmZiK0zN1bkr5 = ps7eoTRi0hdwzJgq1tYlS9NKaO()
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==711: XVFsOLPmZiK0zN1bkr5 = l7kbyVTqoJcsiUtePwKu(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==712: XVFsOLPmZiK0zN1bkr5 = tQ1EyGcl0Su(kQ3iPAjXHKCWe)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==713: XVFsOLPmZiK0zN1bkr5 = jIXo9UYHyliZsMkh7(kQ3iPAjXHKCWe,HHPwg71GEVju,yv8XxUjorzB2CRA4Jife73VMklHp,Fa9EIfiBzwm13QhVUr)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==714: XVFsOLPmZiK0zN1bkr5 = yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(kQ3iPAjXHKCWe,HHPwg71GEVju,yv8XxUjorzB2CRA4Jife73VMklHp,Fa9EIfiBzwm13QhVUr)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==715: XVFsOLPmZiK0zN1bkr5 = JwYEQUDupG2WLPzHndc(kQ3iPAjXHKCWe,HHPwg71GEVju,ga4p3IxqUXMjTRPQZfH9J5E)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==716: XVFsOLPmZiK0zN1bkr5 = BG5z7FudReJjH1w80D2(kQ3iPAjXHKCWe,True)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==717: XVFsOLPmZiK0zN1bkr5 = iisQZamj86E7vSD5(kQ3iPAjXHKCWe,True)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==718: XVFsOLPmZiK0zN1bkr5 = S273CuiTWX9rAfoEqxYM(kQ3iPAjXHKCWe,HHPwg71GEVju,yv8XxUjorzB2CRA4Jife73VMklHp)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==719: XVFsOLPmZiK0zN1bkr5 = RYW8dS3E1GVjzsLPcku(yv8XxUjorzB2CRA4Jife73VMklHp,kQ3iPAjXHKCWe,HHPwg71GEVju,Fa9EIfiBzwm13QhVUr)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==720: XVFsOLPmZiK0zN1bkr5 = HbNpCDWgIQywk12ucivJXm4UqZ(kQ3iPAjXHKCWe,True)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==721: XVFsOLPmZiK0zN1bkr5 = wqfTenDyNSmc1bO2aAJQWpERCIX3K(kQ3iPAjXHKCWe)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==722: XVFsOLPmZiK0zN1bkr5 = dlHvA5m7hk8UNTjiEObu4(kQ3iPAjXHKCWe)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==723: XVFsOLPmZiK0zN1bkr5 = n2XBGIMWcpbiAJ5(kQ3iPAjXHKCWe)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==726: XVFsOLPmZiK0zN1bkr5 = OQobVj09yXKnD3LUwc(kQ3iPAjXHKCWe)
	elif EHnSrqQ7BvmGlOgYZdhTbCRtswA==729: XVFsOLPmZiK0zN1bkr5 = ZTwXKRtB3his2CdopeF40ULn(yv8XxUjorzB2CRA4Jife73VMklHp,kQ3iPAjXHKCWe,HHPwg71GEVju,Fa9EIfiBzwm13QhVUr)
	else: XVFsOLPmZiK0zN1bkr5 = False
	return XVFsOLPmZiK0zN1bkr5
def ps7eoTRi0hdwzJgq1tYlS9NKaO():
	for kQ3iPAjXHKCWe in range(1,U1UsphAegPmDYZXfTW+1):
		I5ZiQhtuXSmd96BNLoPwGU = '_MU'+str(kQ3iPAjXHKCWe)+'_'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قائمة مجلد '+Yrb603795v[kQ3iPAjXHKCWe],'',720,'','','','',{'folder':kQ3iPAjXHKCWe})
	return
def HbNpCDWgIQywk12ucivJXm4UqZ(kQ3iPAjXHKCWe='',jH5UCJQ4v7VPwqlmYy0XRcALzWn=''):
	if kQ3iPAjXHKCWe:
		ppIOWK8UYZNE = {'folder':kQ3iPAjXHKCWe}
		JubO84F3UHk9cdQemgRMl = ''
	else:
		ppIOWK8UYZNE = ''
		JubO84F3UHk9cdQemgRMl = ''
	s7rGkb9HqTot = TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn)
	if not s7rGkb9HqTot:
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'[COLOR FFFFFF00] إضافة وتغيير رابط'+JubO84F3UHk9cdQemgRMl+' '+Yrb603795v[1]+' [/COLOR]','',711,'','','','',{'folder':kQ3iPAjXHKCWe,'sequence':1})
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'[COLOR FFFFFF00] جلب ملفات'+JubO84F3UHk9cdQemgRMl+' [/COLOR]','',712,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'بحث في الملفات'+JubO84F3UHk9cdQemgRMl,'',729,'','','_REMEMBERRESULTS_','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مصنفة مرتبة'+JubO84F3UHk9cdQemgRMl,'LIVE_GROUPED_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مصنفة من القسم'+JubO84F3UHk9cdQemgRMl,'LIVE_FROM_GROUP_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مصنفة من الاسم'+JubO84F3UHk9cdQemgRMl,'LIVE_FROM_NAME_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مصنفة بلا ترتيب'+JubO84F3UHk9cdQemgRMl,'LIVE_GROUPED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات بلا ترتيب'+JubO84F3UHk9cdQemgRMl,'LIVE_ORIGINAL_GROUPED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مجهولة مرتبة'+JubO84F3UHk9cdQemgRMl,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'قنوات مجهولة بلا ترتيب'+JubO84F3UHk9cdQemgRMl,'LIVE_UNKNOWN_GROUPED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'فيديوهات بلا ترتيب'+JubO84F3UHk9cdQemgRMl,'VOD_ORIGINAL_GROUPED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'فيديوهات مصنفة القسم'+JubO84F3UHk9cdQemgRMl,'VOD_FROM_GROUP_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'فيديوهات مصنفة من الاسم'+JubO84F3UHk9cdQemgRMl,'VOD_FROM_NAME_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'فيديوهات مجهولة بلا ترتيب'+JubO84F3UHk9cdQemgRMl,'VOD_UNKNOWN_GROUPED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'فيديوهات مجهولة مرتبة'+JubO84F3UHk9cdQemgRMl,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',ppIOWK8UYZNE)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'إضافة وتغيير رابط'+JubO84F3UHk9cdQemgRMl+' '+Yrb603795v[g80O9QtN6lbRcPiu],'',711,'','','','',{'folder':kQ3iPAjXHKCWe,'sequence':g80O9QtN6lbRcPiu})
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'جلب ملفات'+JubO84F3UHk9cdQemgRMl,'',712,'','','','',ppIOWK8UYZNE)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'مسح ملفات'+JubO84F3UHk9cdQemgRMl,'',717,'','','','',ppIOWK8UYZNE)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'عدد فيديوهات'+JubO84F3UHk9cdQemgRMl,'',721,'','','','',ppIOWK8UYZNE)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'Referer تغيير'+JubO84F3UHk9cdQemgRMl,'',726,'','','','',ppIOWK8UYZNE)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'User-Agent تغيير'+JubO84F3UHk9cdQemgRMl,'',723,'','','','',ppIOWK8UYZNE)
	return
def BG5z7FudReJjH1w80D2(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	nFJO4xzi7lrEkBNYoI1Z2pbc68yXm,iNbWDvkjFQa9lGE84B5Ss0IfpXRqZ = False,''
	UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7 = '',''
	GW3SQ2cmyXat1KVFCb85iTNA,N6TBv2QuoRCmXi,pI6zUwMTvZXNKmBs,tGgqMEz7PDH0u2nZvCcUbS5XhYTQ,xxD2kzrX9b3BOwf6EYG = NiZnEd8sukyrwbBDHoS24UQAYp(kQ3iPAjXHKCWe)
	if tGgqMEz7PDH0u2nZvCcUbS5XhYTQ=='': return False,'',''
	z1megRlwFGk6B = yObVNhRgQ8pdxCo9k6(kQ3iPAjXHKCWe)
	if GW3SQ2cmyXat1KVFCb85iTNA:
		LDJp21bZXjxVEmtK = lSFHaMs1enNVw7biRYOG90UcPjQz(vZs8PpIdBUNQTjnbEymoYx6X,'GET',GW3SQ2cmyXat1KVFCb85iTNA,'',z1megRlwFGk6B,False,'','M3U-CHECK_ACCOUNT-1st')
		oJW87jcST1 = LDJp21bZXjxVEmtK.content
		if LDJp21bZXjxVEmtK.succeeded:
			vS2FEVLmRKYdIwi0clsnAHUJC,TkvHyRtiYdjnSWJQzmGgPUX,kIYBp1ViUQ,ZTepHcSNjz7qmOQxy3artg8FYb,Pan48GCw9oRY7zshATvIlrmtFHO6Mg = 0,0,'','',''
			try:
				RbZv5mauqH8l4odzshKcw2CDS = cwiLy4IAVJj0pWCl7FGxokR('dict',oJW87jcST1)
				iNbWDvkjFQa9lGE84B5Ss0IfpXRqZ = RbZv5mauqH8l4odzshKcw2CDS['user_info']['status']
				nFJO4xzi7lrEkBNYoI1Z2pbc68yXm = True
				kIYBp1ViUQ = RbZv5mauqH8l4odzshKcw2CDS['server_info']['time_now']
			except: pass
			if kIYBp1ViUQ:
				try:
					Q6gpj3ulX2qbYMrKnT8NoBEPFLc4 = D1vBJgya85Yh4cRTCkIMKtWLSeH.strptime(kIYBp1ViUQ,'%Y.%m.%d %H:%M:%S')
					vS2FEVLmRKYdIwi0clsnAHUJC = int(D1vBJgya85Yh4cRTCkIMKtWLSeH.mktime(Q6gpj3ulX2qbYMrKnT8NoBEPFLc4))
					TkvHyRtiYdjnSWJQzmGgPUX = int(EEd0FZyfticlDPAMp2HbNesx-vS2FEVLmRKYdIwi0clsnAHUJC)
					TkvHyRtiYdjnSWJQzmGgPUX = int((TkvHyRtiYdjnSWJQzmGgPUX+900)/1800)*1800
				except: pass
				try:
					Q6gpj3ulX2qbYMrKnT8NoBEPFLc4 = D1vBJgya85Yh4cRTCkIMKtWLSeH.localtime(int(RbZv5mauqH8l4odzshKcw2CDS['user_info']['created_at']))
					ZTepHcSNjz7qmOQxy3artg8FYb = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%Y.%m.%d %H:%M:%S',Q6gpj3ulX2qbYMrKnT8NoBEPFLc4)
				except: pass
				try:
					Q6gpj3ulX2qbYMrKnT8NoBEPFLc4 = D1vBJgya85Yh4cRTCkIMKtWLSeH.localtime(int(RbZv5mauqH8l4odzshKcw2CDS['user_info']['exp_date']))
					Pan48GCw9oRY7zshATvIlrmtFHO6Mg = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%Y.%m.%d %H:%M:%S',Q6gpj3ulX2qbYMrKnT8NoBEPFLc4)
				except: pass
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.timestamp_'+kQ3iPAjXHKCWe,str(EEd0FZyfticlDPAMp2HbNesx))
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.timediff_'+kQ3iPAjXHKCWe,str(TkvHyRtiYdjnSWJQzmGgPUX))
			try:
				e09JmcIRzfMSnQb62Yg = '"server_info":'+oJW87jcST1.split('"server_info":')[1]
				e09JmcIRzfMSnQb62Yg = e09JmcIRzfMSnQb62Yg.replace(':',': ').replace(',',', ').replace('}}','}')
				a0BRvzFfIg = T072lCzjYiuaeFtmJGV.findall('"url": "(.*?)", "port": "(.*?)"',e09JmcIRzfMSnQb62Yg,T072lCzjYiuaeFtmJGV.DOTALL)
				UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7 = a0BRvzFfIg[0]
			except: nFJO4xzi7lrEkBNYoI1Z2pbc68yXm = False
			if nFJO4xzi7lrEkBNYoI1Z2pbc68yXm and jH5UCJQ4v7VPwqlmYy0XRcALzWn:
				max = RbZv5mauqH8l4odzshKcw2CDS['user_info']['max_connections']
				J7kGlqBTN1rDY = RbZv5mauqH8l4odzshKcw2CDS['user_info']['active_cons']
				aGLD3C6pnAy84Z = RbZv5mauqH8l4odzshKcw2CDS['user_info']['is_trial']
				JP91BhjDAVS7TwFxXcK3qU8 = GW3SQ2cmyXat1KVFCb85iTNA.split('?',1)
				F67qZAgMjPukRfJ = 'URL:  [COLOR FFC89008]'+GW3SQ2cmyXat1KVFCb85iTNA+'[/COLOR]'
				F67qZAgMjPukRfJ += '\n\nStatus:  '+'[COLOR FFC89008]'+iNbWDvkjFQa9lGE84B5Ss0IfpXRqZ+'[/COLOR]'
				F67qZAgMjPukRfJ += '\nTrial:    '+'[COLOR FFC89008]'+str(aGLD3C6pnAy84Z=='1')+'[/COLOR]'
				F67qZAgMjPukRfJ += '\nCreated  At:  '+'[COLOR FFC89008]'+ZTepHcSNjz7qmOQxy3artg8FYb+'[/COLOR]'
				F67qZAgMjPukRfJ += '\nExpiry Date:  '+'[COLOR FFC89008]'+Pan48GCw9oRY7zshATvIlrmtFHO6Mg+'[/COLOR]'
				F67qZAgMjPukRfJ += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+J7kGlqBTN1rDY+' / '+max+'[/COLOR]'
				F67qZAgMjPukRfJ += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(RbZv5mauqH8l4odzshKcw2CDS['user_info']['allowed_output_formats'])+'[/COLOR]'
				F67qZAgMjPukRfJ += '\n\n'+e09JmcIRzfMSnQb62Yg
				if iNbWDvkjFQa9lGE84B5Ss0IfpXRqZ=='Active': JdTOfC6BRIKoGu('الاشتراك يعمل بدون مشاكل',F67qZAgMjPukRfJ)
				else: JdTOfC6BRIKoGu('يبدو أن هناك مشكلة في الاشتراك',F67qZAgMjPukRfJ)
	if GW3SQ2cmyXat1KVFCb85iTNA and nFJO4xzi7lrEkBNYoI1Z2pbc68yXm and iNbWDvkjFQa9lGE84B5Ss0IfpXRqZ=='Active':
		GZvEITHSg5U3rVwQ('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+GW3SQ2cmyXat1KVFCb85iTNA+' ]')
		JzGp5aDTFHMe1nNKZRAoLu7Q = True
	else:
		GZvEITHSg5U3rVwQ('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+GW3SQ2cmyXat1KVFCb85iTNA+' ]')
		if jH5UCJQ4v7VPwqlmYy0XRcALzWn: KK47FGdX1TDfkb3AjHOQqghE('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		JzGp5aDTFHMe1nNKZRAoLu7Q = False
	return JzGp5aDTFHMe1nNKZRAoLu7Q,UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7
def yWFgU1ATZmnbeVt0CoJhz4Edwsj78P(kQ3iPAjXHKCWe,KQABSErcIo,nn6wi9vE2ZrMBzjIsOtqaX8,iir30yaXElzYc7KC9uPNbo,jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	if not iir30yaXElzYc7KC9uPNbo: iir30yaXElzYc7KC9uPNbo = '1'
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn): return
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,KQABSErcIo)
	mN1F4bAGHlUzjRQV2p = IBxvzdjXCgS(uuamKczE4h8,'list',KQABSErcIo,nn6wi9vE2ZrMBzjIsOtqaX8)
	ooKiPTblFuzOryQ6j4cfXgaWxw = int(iir30yaXElzYc7KC9uPNbo)*100
	kk7tQHZxGD9fse8pymJU3lrCY2 = ooKiPTblFuzOryQ6j4cfXgaWxw-100
	for c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu in mN1F4bAGHlUzjRQV2p[kk7tQHZxGD9fse8pymJU3lrCY2:ooKiPTblFuzOryQ6j4cfXgaWxw]:
		eiHbE4TXr0JRYfakFQot6AZhOG = ('GROUPED' in KQABSErcIo or KQABSErcIo=='ALL')
		aUJ0GnB7TDv = ('GROUPED' not in KQABSErcIo and KQABSErcIo!='ALL')
		if eiHbE4TXr0JRYfakFQot6AZhOG or aUJ0GnB7TDv:
			if   'ARCHIVED'  in KQABSErcIo: a26IqBkAXRPrwCOgFDb.append(['folder',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,718,pwm2PdsA5cTagHOeCu,'','ARCHIVED','',{'folder':kQ3iPAjXHKCWe}])
			elif 'EPG' 		 in KQABSErcIo: a26IqBkAXRPrwCOgFDb.append(['folder',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,718,pwm2PdsA5cTagHOeCu,'','FULL_EPG','',{'folder':kQ3iPAjXHKCWe}])
			elif 'TIMESHIFT' in KQABSErcIo: a26IqBkAXRPrwCOgFDb.append(['folder',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,718,pwm2PdsA5cTagHOeCu,'','TIMESHIFT','',{'folder':kQ3iPAjXHKCWe}])
			elif 'LIVE' 	 in KQABSErcIo: a26IqBkAXRPrwCOgFDb.append(['live',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,715,pwm2PdsA5cTagHOeCu,'','',c60Epz1qjmHiKMl9BY,{'folder':kQ3iPAjXHKCWe}])
			else: a26IqBkAXRPrwCOgFDb.append(['video',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,715,pwm2PdsA5cTagHOeCu,'','','',{'folder':kQ3iPAjXHKCWe}])
	GZtThAxePiQJuwmdN2K0Rcj6VWbk = len(mN1F4bAGHlUzjRQV2p)
	L1JqTz6nCfBjGP3SWAmd(kQ3iPAjXHKCWe,iir30yaXElzYc7KC9uPNbo,KQABSErcIo,714,GZtThAxePiQJuwmdN2K0Rcj6VWbk,nn6wi9vE2ZrMBzjIsOtqaX8)
	return
def ppqGf0Lzwuy4aWl9bk1IFU8crVig(AWyZBRUb9SJIk6KHvO3Qh5eqlrPj):
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+'أو الخدمة غير موجودة في اشتراكك','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def jIXo9UYHyliZsMkh7(kQ3iPAjXHKCWe,KQABSErcIo,nn6wi9vE2ZrMBzjIsOtqaX8,iir30yaXElzYc7KC9uPNbo,zgVDOQyCmvkrdI8Jh5F4Te='',jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	if not iir30yaXElzYc7KC9uPNbo: iir30yaXElzYc7KC9uPNbo = '1'
	AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = I5ZiQhtuXSmd96BNLoPwGU
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn): return False
	if '__SERIES__' in nn6wi9vE2ZrMBzjIsOtqaX8: FYKu5XzM3igWV,NO70Y3wjXI4nbdacuTWUC = nn6wi9vE2ZrMBzjIsOtqaX8.split('__SERIES__')
	else: FYKu5XzM3igWV,NO70Y3wjXI4nbdacuTWUC = nn6wi9vE2ZrMBzjIsOtqaX8,''
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,KQABSErcIo)
	y8yN3upHrYnbgXqLDfIjSAOUeQVax = IBxvzdjXCgS(uuamKczE4h8,'list',KQABSErcIo,'__GROUPS__')
	if not y8yN3upHrYnbgXqLDfIjSAOUeQVax: return False
	vmwpLo3eCjqRI1 = []
	for yyp5uq1HZTWwmtd,pwm2PdsA5cTagHOeCu in y8yN3upHrYnbgXqLDfIjSAOUeQVax:
		if '===== ===== =====' in yyp5uq1HZTWwmtd:
			QQmLIZC8uas9fNiJWOnhdGvgFR('link',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+yyp5uq1HZTWwmtd,'',9999)
			QQmLIZC8uas9fNiJWOnhdGvgFR('link',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+yyp5uq1HZTWwmtd,'',9999)
			continue
		if zgVDOQyCmvkrdI8Jh5F4Te:
			if '__SERIES__' in yyp5uq1HZTWwmtd: AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = 'SERIES'
			elif '!!__UNKNOWN__!!' in yyp5uq1HZTWwmtd: AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = 'UNKNOWN'
			elif 'LIVE' in KQABSErcIo: AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = 'LIVE'
			else: AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = 'VIDEOS'
			AWyZBRUb9SJIk6KHvO3Qh5eqlrPj = ',[COLOR FFC89008]'+AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+': [/COLOR]'
		if '__SERIES__' in yyp5uq1HZTWwmtd: E4Z75aL3XmrzOKywCGfIQxF1JonTpA,kAZjmxSCUXVw = yyp5uq1HZTWwmtd.split('__SERIES__')
		else: E4Z75aL3XmrzOKywCGfIQxF1JonTpA,kAZjmxSCUXVw = yyp5uq1HZTWwmtd,''
		if not nn6wi9vE2ZrMBzjIsOtqaX8:
			if E4Z75aL3XmrzOKywCGfIQxF1JonTpA in vmwpLo3eCjqRI1: continue
			vmwpLo3eCjqRI1.append(E4Z75aL3XmrzOKywCGfIQxF1JonTpA)
			if 'RANDOM' in zgVDOQyCmvkrdI8Jh5F4Te: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+E4Z75aL3XmrzOKywCGfIQxF1JonTpA,KQABSErcIo,168,'','1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
			elif '__SERIES__' in yyp5uq1HZTWwmtd: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+E4Z75aL3XmrzOKywCGfIQxF1JonTpA,KQABSErcIo,713,'','1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+E4Z75aL3XmrzOKywCGfIQxF1JonTpA,KQABSErcIo,714,'','1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
		elif '__SERIES__' in yyp5uq1HZTWwmtd and E4Z75aL3XmrzOKywCGfIQxF1JonTpA==FYKu5XzM3igWV:
			if kAZjmxSCUXVw in vmwpLo3eCjqRI1: continue
			vmwpLo3eCjqRI1.append(kAZjmxSCUXVw)
			if 'RANDOM' in zgVDOQyCmvkrdI8Jh5F4Te: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+kAZjmxSCUXVw,KQABSErcIo,168,'','1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',AWyZBRUb9SJIk6KHvO3Qh5eqlrPj+kAZjmxSCUXVw,KQABSErcIo,714,pwm2PdsA5cTagHOeCu,'1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
	a26IqBkAXRPrwCOgFDb[:] = sorted(a26IqBkAXRPrwCOgFDb,reverse=False,key=lambda HHhysw8NOZj3: HHhysw8NOZj3[1].lower())
	if not zgVDOQyCmvkrdI8Jh5F4Te:
		ooKiPTblFuzOryQ6j4cfXgaWxw = int(iir30yaXElzYc7KC9uPNbo)*100
		kk7tQHZxGD9fse8pymJU3lrCY2 = ooKiPTblFuzOryQ6j4cfXgaWxw-100
		GZtThAxePiQJuwmdN2K0Rcj6VWbk = len(a26IqBkAXRPrwCOgFDb)
		a26IqBkAXRPrwCOgFDb[:] = a26IqBkAXRPrwCOgFDb[kk7tQHZxGD9fse8pymJU3lrCY2:ooKiPTblFuzOryQ6j4cfXgaWxw]
		L1JqTz6nCfBjGP3SWAmd(kQ3iPAjXHKCWe,iir30yaXElzYc7KC9uPNbo,KQABSErcIo,713,GZtThAxePiQJuwmdN2K0Rcj6VWbk,nn6wi9vE2ZrMBzjIsOtqaX8)
	return True
def S273CuiTWX9rAfoEqxYM(kQ3iPAjXHKCWe,HHPwg71GEVju,E4HwOBtaVTbrYvRu5m1IF0gP2G):
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,True): return
	z1megRlwFGk6B = yObVNhRgQ8pdxCo9k6(kQ3iPAjXHKCWe)
	vS2FEVLmRKYdIwi0clsnAHUJC = YTPut68WBVUNCvsEzg.getSetting('av.m3u.timestamp_'+kQ3iPAjXHKCWe)
	if not vS2FEVLmRKYdIwi0clsnAHUJC or EEd0FZyfticlDPAMp2HbNesx-int(vS2FEVLmRKYdIwi0clsnAHUJC)>24*fxunVecQRNTGHb2LJtkBylF5:
		JzGp5aDTFHMe1nNKZRAoLu7Q,UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7 = BG5z7FudReJjH1w80D2(kQ3iPAjXHKCWe,False)
		if not JzGp5aDTFHMe1nNKZRAoLu7Q: return
	TkvHyRtiYdjnSWJQzmGgPUX = int(YTPut68WBVUNCvsEzg.getSetting('av.m3u.timediff_'+kQ3iPAjXHKCWe))
	pI6zUwMTvZXNKmBs = YTPut68WBVUNCvsEzg.getSetting('av.m3u.server_'+kQ3iPAjXHKCWe)
	tGgqMEz7PDH0u2nZvCcUbS5XhYTQ = YTPut68WBVUNCvsEzg.getSetting('av.m3u.username_'+kQ3iPAjXHKCWe)
	xxD2kzrX9b3BOwf6EYG = YTPut68WBVUNCvsEzg.getSetting('av.m3u.password_'+kQ3iPAjXHKCWe)
	OzqfDM5ApQ7T0duKvIrZ = HHPwg71GEVju.split('/')
	AF6nV2jtvUrJyIN8BQDLM7o = OzqfDM5ApQ7T0duKvIrZ[-1].replace('.ts','').replace('.m3u8','')
	if E4HwOBtaVTbrYvRu5m1IF0gP2G=='SHORT_EPG': Mrx5N7KjlCV0ig9w = 'get_short_epg'
	else: Mrx5N7KjlCV0ig9w = 'get_simple_data_table'
	GW3SQ2cmyXat1KVFCb85iTNA,N6TBv2QuoRCmXi,pI6zUwMTvZXNKmBs,tGgqMEz7PDH0u2nZvCcUbS5XhYTQ,xxD2kzrX9b3BOwf6EYG = NiZnEd8sukyrwbBDHoS24UQAYp(kQ3iPAjXHKCWe)
	if not tGgqMEz7PDH0u2nZvCcUbS5XhYTQ: return
	Da9L6fEkJ4QwXdy3c5Bl = GW3SQ2cmyXat1KVFCb85iTNA+'&action='+Mrx5N7KjlCV0ig9w+'&stream_id='+AF6nV2jtvUrJyIN8BQDLM7o
	oJW87jcST1 = BhonF8v9ZytPswdm1CzHU7M3uf(vZs8PpIdBUNQTjnbEymoYx6X,Da9L6fEkJ4QwXdy3c5Bl,'',z1megRlwFGk6B,'','M3U-EPG_ITEMS-2nd')
	fzlFi7a9SYduLEJgCAbrn = cwiLy4IAVJj0pWCl7FGxokR('dict',oJW87jcST1)
	YuHRjDKm4E86CtisSrwhzln = fzlFi7a9SYduLEJgCAbrn['epg_listings']
	mWUy2t0spHNw1aVf = []
	if E4HwOBtaVTbrYvRu5m1IF0gP2G in ['ARCHIVED','TIMESHIFT']:
		for RbZv5mauqH8l4odzshKcw2CDS in YuHRjDKm4E86CtisSrwhzln:
			if RbZv5mauqH8l4odzshKcw2CDS['has_archive']==1:
				mWUy2t0spHNw1aVf.append(RbZv5mauqH8l4odzshKcw2CDS)
				if E4HwOBtaVTbrYvRu5m1IF0gP2G in ['TIMESHIFT']: break
		if not mWUy2t0spHNw1aVf: return
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if E4HwOBtaVTbrYvRu5m1IF0gP2G in ['TIMESHIFT']:
			jvuYNOBnlAEVhC3FaU4freqoR8 = 2
			LqQJ4Vb9YE = jvuYNOBnlAEVhC3FaU4freqoR8*fxunVecQRNTGHb2LJtkBylF5
			mWUy2t0spHNw1aVf = []
			kCLoVlytWBsJ = int(int(RbZv5mauqH8l4odzshKcw2CDS['start_timestamp'])/LqQJ4Vb9YE)*LqQJ4Vb9YE
			knv3XYzJN6Mr = EEd0FZyfticlDPAMp2HbNesx+LqQJ4Vb9YE
			TxWO9YdjQmrawo0N5GBlIzvRqVy = int((knv3XYzJN6Mr-kCLoVlytWBsJ)/fxunVecQRNTGHb2LJtkBylF5)
			for llCODaWngtvoGQsmq in range(TxWO9YdjQmrawo0N5GBlIzvRqVy):
				if llCODaWngtvoGQsmq>=6:
					if llCODaWngtvoGQsmq%jvuYNOBnlAEVhC3FaU4freqoR8!=0: continue
					o8oTABfnCwS6pvl3Ja = LqQJ4Vb9YE
				else: o8oTABfnCwS6pvl3Ja = LqQJ4Vb9YE//2
				Lck3KMyFqrxG = kCLoVlytWBsJ+llCODaWngtvoGQsmq*fxunVecQRNTGHb2LJtkBylF5
				RbZv5mauqH8l4odzshKcw2CDS = {}
				RbZv5mauqH8l4odzshKcw2CDS['title'] = ''
				Q6gpj3ulX2qbYMrKnT8NoBEPFLc4 = D1vBJgya85Yh4cRTCkIMKtWLSeH.localtime(Lck3KMyFqrxG-TkvHyRtiYdjnSWJQzmGgPUX-fxunVecQRNTGHb2LJtkBylF5)
				RbZv5mauqH8l4odzshKcw2CDS['start'] = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%Y.%m.%d %H:%M:%S',Q6gpj3ulX2qbYMrKnT8NoBEPFLc4)
				RbZv5mauqH8l4odzshKcw2CDS['start_timestamp'] = str(Lck3KMyFqrxG)
				RbZv5mauqH8l4odzshKcw2CDS['stop_timestamp'] = str(Lck3KMyFqrxG+o8oTABfnCwS6pvl3Ja)
				mWUy2t0spHNw1aVf.append(RbZv5mauqH8l4odzshKcw2CDS)
	elif E4HwOBtaVTbrYvRu5m1IF0gP2G in ['SHORT_EPG','FULL_EPG']: mWUy2t0spHNw1aVf = YuHRjDKm4E86CtisSrwhzln
	if E4HwOBtaVTbrYvRu5m1IF0gP2G=='FULL_EPG' and len(mWUy2t0spHNw1aVf)>0:
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	ZgBE03nhf8sGCUxrPclb4dwOIKAMV = []
	pwm2PdsA5cTagHOeCu = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Icon')
	for RbZv5mauqH8l4odzshKcw2CDS in mWUy2t0spHNw1aVf:
		co7xPMVtuYQvy = eJ4h7nOpguFMH6z1IUEV2i.b64decode(RbZv5mauqH8l4odzshKcw2CDS['title'])
		if mmIKCGujwM: co7xPMVtuYQvy = co7xPMVtuYQvy.decode('utf8')
		Lck3KMyFqrxG = int(RbZv5mauqH8l4odzshKcw2CDS['start_timestamp'])
		VtOhyS3a2kq4oWQ1x9Dc = int(RbZv5mauqH8l4odzshKcw2CDS['stop_timestamp'])
		fXgLeJq4Vd6zlcAEumD0IQ2r9SHxPt = str(int((VtOhyS3a2kq4oWQ1x9Dc-Lck3KMyFqrxG+59)/60))
		m3T7V2DzlWFtIgGEUOK9fn8xdQ4Jb = RbZv5mauqH8l4odzshKcw2CDS['start'].replace(' ',':')
		Q6gpj3ulX2qbYMrKnT8NoBEPFLc4 = D1vBJgya85Yh4cRTCkIMKtWLSeH.localtime(Lck3KMyFqrxG-fxunVecQRNTGHb2LJtkBylF5)
		iJnrHqp1jCQdWLmkV47TNGDZs3EI = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%H:%M',Q6gpj3ulX2qbYMrKnT8NoBEPFLc4)
		PPJdnj5uY0t6Uk = D1vBJgya85Yh4cRTCkIMKtWLSeH.strftime('%a',Q6gpj3ulX2qbYMrKnT8NoBEPFLc4)
		if E4HwOBtaVTbrYvRu5m1IF0gP2G=='SHORT_EPG': co7xPMVtuYQvy = '[COLOR FFFFFF00]'+iJnrHqp1jCQdWLmkV47TNGDZs3EI+' ـ '+co7xPMVtuYQvy+'[/COLOR]'
		elif E4HwOBtaVTbrYvRu5m1IF0gP2G=='TIMESHIFT': co7xPMVtuYQvy = PPJdnj5uY0t6Uk+' '+iJnrHqp1jCQdWLmkV47TNGDZs3EI+' ('+fXgLeJq4Vd6zlcAEumD0IQ2r9SHxPt+'min)'
		else: co7xPMVtuYQvy = PPJdnj5uY0t6Uk+' '+iJnrHqp1jCQdWLmkV47TNGDZs3EI+' ('+fXgLeJq4Vd6zlcAEumD0IQ2r9SHxPt+'min)   '+co7xPMVtuYQvy+' ـ'
		if E4HwOBtaVTbrYvRu5m1IF0gP2G in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			eLrFx2R5QH4soYgCzTcf0EMGw9yd = pI6zUwMTvZXNKmBs+'/timeshift/'+tGgqMEz7PDH0u2nZvCcUbS5XhYTQ+'/'+xxD2kzrX9b3BOwf6EYG+'/'+fXgLeJq4Vd6zlcAEumD0IQ2r9SHxPt+'/'+m3T7V2DzlWFtIgGEUOK9fn8xdQ4Jb+'/'+AF6nV2jtvUrJyIN8BQDLM7o+'.m3u8'
			if E4HwOBtaVTbrYvRu5m1IF0gP2G=='FULL_EPG': QQmLIZC8uas9fNiJWOnhdGvgFR('link',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,eLrFx2R5QH4soYgCzTcf0EMGw9yd,9999,pwm2PdsA5cTagHOeCu,'','','',{'folder':kQ3iPAjXHKCWe})
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,eLrFx2R5QH4soYgCzTcf0EMGw9yd,715,pwm2PdsA5cTagHOeCu,'','','',{'folder':kQ3iPAjXHKCWe})
		ZgBE03nhf8sGCUxrPclb4dwOIKAMV.append(co7xPMVtuYQvy)
	if E4HwOBtaVTbrYvRu5m1IF0gP2G=='SHORT_EPG' and ZgBE03nhf8sGCUxrPclb4dwOIKAMV: BlAwCEFx83oIdnvVhZKryR = FfDSUcBCGtevnqLPKxd(ZgBE03nhf8sGCUxrPclb4dwOIKAMV)
	return ZgBE03nhf8sGCUxrPclb4dwOIKAMV
def dlHvA5m7hk8UNTjiEObu4(kQ3iPAjXHKCWe):
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,True): return
	pI6zUwMTvZXNKmBs,C52iRvxQOhz,TTFnrYOXD2S = '',0,0
	JzGp5aDTFHMe1nNKZRAoLu7Q,UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7 = BG5z7FudReJjH1w80D2(kQ3iPAjXHKCWe,False)
	if JzGp5aDTFHMe1nNKZRAoLu7Q:
		C6Tp2klgjE = ksgT5Go6BqpNwDjyMbUiOI3rQxfa7A(UqgEZYnFXDBKAVc67duaLbk2oyjv)
		C52iRvxQOhz = B7k3U2LXMaqP9dEf(C6Tp2klgjE[0],int(f81gXe3ysjtlckibaNY0QxAEW7))
		uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'LIVE_GROUPED')
		Q2z0ELKMtdk = IBxvzdjXCgS(uuamKczE4h8,'list','LIVE_GROUPED')
		mN1F4bAGHlUzjRQV2p = IBxvzdjXCgS(uuamKczE4h8,'list','LIVE_GROUPED',Q2z0ELKMtdk[1])
		HHPwg71GEVju = mN1F4bAGHlUzjRQV2p[0][2]
		vOMcfjK6H8xu7PskBDZR4SLaN = T072lCzjYiuaeFtmJGV.findall('://(.*?)/',HHPwg71GEVju,T072lCzjYiuaeFtmJGV.DOTALL)
		vOMcfjK6H8xu7PskBDZR4SLaN = vOMcfjK6H8xu7PskBDZR4SLaN[0]
		if ':' in vOMcfjK6H8xu7PskBDZR4SLaN: OlJzXMdEwY4Qft,EHjwk8DTzf = vOMcfjK6H8xu7PskBDZR4SLaN.split(':')
		else: OlJzXMdEwY4Qft,EHjwk8DTzf = vOMcfjK6H8xu7PskBDZR4SLaN,'80'
		DDqkbRCZj73WNlcsnHv = ksgT5Go6BqpNwDjyMbUiOI3rQxfa7A(OlJzXMdEwY4Qft)
		TTFnrYOXD2S = B7k3U2LXMaqP9dEf(DDqkbRCZj73WNlcsnHv[0],int(EHjwk8DTzf))
	if C52iRvxQOhz and TTFnrYOXD2S:
		F67qZAgMjPukRfJ = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		F67qZAgMjPukRfJ += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(TTFnrYOXD2S*1000))+' ملي ثانية'
		F67qZAgMjPukRfJ += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(C52iRvxQOhz*1000))+' ملي ثانية'
		eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',F67qZAgMjPukRfJ)
		if eZId7XMDvV6Jno938==1 and C52iRvxQOhz<TTFnrYOXD2S: pI6zUwMTvZXNKmBs = UqgEZYnFXDBKAVc67duaLbk2oyjv+':'+f81gXe3ysjtlckibaNY0QxAEW7
	else: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	YTPut68WBVUNCvsEzg.setSetting('av.m3u.server_'+kQ3iPAjXHKCWe,pI6zUwMTvZXNKmBs)
	return
def JwYEQUDupG2WLPzHndc(kQ3iPAjXHKCWe,HHPwg71GEVju,ga4p3IxqUXMjTRPQZfH9J5E):
	blzqcYFMOuTZDAftPNv0kJr6nGm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe)
	rfQqZmwdLn5RaY = YTPut68WBVUNCvsEzg.getSetting('av.m3u.referer_'+kQ3iPAjXHKCWe)
	if blzqcYFMOuTZDAftPNv0kJr6nGm or rfQqZmwdLn5RaY:
		HHPwg71GEVju += '|'
		if blzqcYFMOuTZDAftPNv0kJr6nGm: HHPwg71GEVju += '&User-Agent='+blzqcYFMOuTZDAftPNv0kJr6nGm
		if rfQqZmwdLn5RaY: HHPwg71GEVju += '&Referer='+rfQqZmwdLn5RaY
		HHPwg71GEVju = HHPwg71GEVju.replace('|&','|')
	pidYDcjvhgVfqb3GeWSAOH5J(HHPwg71GEVju,eNv8QX5p0UAnMx6sdk,ga4p3IxqUXMjTRPQZfH9J5E)
	return
def n2XBGIMWcpbiAJ5(kQ3iPAjXHKCWe):
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	blzqcYFMOuTZDAftPNv0kJr6nGm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe)
	XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','استخدام الأصلي','تعديل القديم',blzqcYFMOuTZDAftPNv0kJr6nGm,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if XXcAN32a7TnrKuEgVs9t==1: blzqcYFMOuTZDAftPNv0kJr6nGm = NWs7KpjXGnxYylofHtd5U3wDh('أكتب ـM3U User-Agent جديد',blzqcYFMOuTZDAftPNv0kJr6nGm,True)
	else: blzqcYFMOuTZDAftPNv0kJr6nGm = 'Unknown'
	if blzqcYFMOuTZDAftPNv0kJr6nGm==' ':
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','','',blzqcYFMOuTZDAftPNv0kJr6nGm,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if XXcAN32a7TnrKuEgVs9t!=1:
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم الإلغاء')
		return
	YTPut68WBVUNCvsEzg.setSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe,blzqcYFMOuTZDAftPNv0kJr6nGm)
	o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe)
	return
def OQobVj09yXKnD3LUwc(kQ3iPAjXHKCWe):
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	rfQqZmwdLn5RaY = YTPut68WBVUNCvsEzg.getSetting('av.m3u.referer_'+kQ3iPAjXHKCWe)
	XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','استخدام الأصلي','تعديل القديم',rfQqZmwdLn5RaY,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if XXcAN32a7TnrKuEgVs9t==1: rfQqZmwdLn5RaY = NWs7KpjXGnxYylofHtd5U3wDh('أكتب ـM3U Referer جديد',rfQqZmwdLn5RaY,True)
	else: rfQqZmwdLn5RaY = ''
	if rfQqZmwdLn5RaY==' ':
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','','',rfQqZmwdLn5RaY,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if XXcAN32a7TnrKuEgVs9t!=1:
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم الإلغاء')
		return
	YTPut68WBVUNCvsEzg.setSetting('av.m3u.referer_'+kQ3iPAjXHKCWe,rfQqZmwdLn5RaY)
	o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe)
	return
def NiZnEd8sukyrwbBDHoS24UQAYp(kQ3iPAjXHKCWe,ZAL14vKCTU2r7dON59Dki=''):
	if not quCIN7V1MYpwUfsiOcJEzPrDeyAdS5: quCIN7V1MYpwUfsiOcJEzPrDeyAdS5 = YTPut68WBVUNCvsEzg.getSetting('av.m3u.url_'+kQ3iPAjXHKCWe)
	pI6zUwMTvZXNKmBs = ClNwy8MJfjoTq4ZFxYvmasD(quCIN7V1MYpwUfsiOcJEzPrDeyAdS5,'url')
	tGgqMEz7PDH0u2nZvCcUbS5XhYTQ = T072lCzjYiuaeFtmJGV.findall('username=(.*?)&',quCIN7V1MYpwUfsiOcJEzPrDeyAdS5+'&',T072lCzjYiuaeFtmJGV.DOTALL)
	xxD2kzrX9b3BOwf6EYG = T072lCzjYiuaeFtmJGV.findall('password=(.*?)&',quCIN7V1MYpwUfsiOcJEzPrDeyAdS5+'&',T072lCzjYiuaeFtmJGV.DOTALL)
	if not tGgqMEz7PDH0u2nZvCcUbS5XhYTQ or not xxD2kzrX9b3BOwf6EYG:
		KK47FGdX1TDfkb3AjHOQqghE('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	tGgqMEz7PDH0u2nZvCcUbS5XhYTQ = tGgqMEz7PDH0u2nZvCcUbS5XhYTQ[0]
	xxD2kzrX9b3BOwf6EYG = xxD2kzrX9b3BOwf6EYG[0]
	GW3SQ2cmyXat1KVFCb85iTNA = pI6zUwMTvZXNKmBs+'/player_api.php?username='+tGgqMEz7PDH0u2nZvCcUbS5XhYTQ+'&password='+xxD2kzrX9b3BOwf6EYG
	N6TBv2QuoRCmXi = pI6zUwMTvZXNKmBs+'/get.php?username='+tGgqMEz7PDH0u2nZvCcUbS5XhYTQ+'&password='+xxD2kzrX9b3BOwf6EYG+'&type=m3u_plus'
	return GW3SQ2cmyXat1KVFCb85iTNA,N6TBv2QuoRCmXi,pI6zUwMTvZXNKmBs,tGgqMEz7PDH0u2nZvCcUbS5XhYTQ,xxD2kzrX9b3BOwf6EYG
def DDXFKq4kBRgr6HVxA8e(kQ3iPAjXHKCWe,TW26SLGEVMArza9DRfOYx3ydHm=''):
	FEY9qnd4GM2w = TW26SLGEVMArza9DRfOYx3ydHm.replace('/','_').replace(':','_').replace('.','_')
	FEY9qnd4GM2w = FEY9qnd4GM2w.replace('?','_').replace('=','_').replace('&','_')
	FEY9qnd4GM2w = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,FEY9qnd4GM2w).strip('.m3u')+'.m3u'
	return FEY9qnd4GM2w
def l7kbyVTqoJcsiUtePwKu(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV):
	OnAtmQhMNvDIobe1VdgK = YTPut68WBVUNCvsEzg.getSetting('av.m3u.url_'+kQ3iPAjXHKCWe+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	lUEaV9i23nhFZqW1eLYwxtzN0 = True
	if OnAtmQhMNvDIobe1VdgK:
		XXcAN32a7TnrKuEgVs9t = GNX3qVRf4oBdtkEi5u('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+OnAtmQhMNvDIobe1VdgK+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if XXcAN32a7TnrKuEgVs9t==-1: return
		elif XXcAN32a7TnrKuEgVs9t==0: OnAtmQhMNvDIobe1VdgK = ''
		elif XXcAN32a7TnrKuEgVs9t==2:
			XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if XXcAN32a7TnrKuEgVs9t in [-1,0]: return
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم مسح الرابط')
			lUEaV9i23nhFZqW1eLYwxtzN0 = False
			kSuaGROw6BUxcEJL3I1mozjeCHV9A = ''
	if lUEaV9i23nhFZqW1eLYwxtzN0:
		kSuaGROw6BUxcEJL3I1mozjeCHV9A = NWs7KpjXGnxYylofHtd5U3wDh('اكتب رابط M3U كاملا',OnAtmQhMNvDIobe1VdgK)
		kSuaGROw6BUxcEJL3I1mozjeCHV9A = kSuaGROw6BUxcEJL3I1mozjeCHV9A.strip(' ')
		if not kSuaGROw6BUxcEJL3I1mozjeCHV9A:
			XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if XXcAN32a7TnrKuEgVs9t in [-1,0]: return
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			F67qZAgMjPukRfJ = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			XXcAN32a7TnrKuEgVs9t = KGEAmiZ9Jq0sTXR('','','','الرابط الجديد هو:','[COLOR FFC89008]'+kSuaGROw6BUxcEJL3I1mozjeCHV9A+'[/COLOR]'+'\n\n'+F67qZAgMjPukRfJ)
			if XXcAN32a7TnrKuEgVs9t!=1:
				KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم الإلغاء')
				return
	YTPut68WBVUNCvsEzg.setSetting('av.m3u.url_'+kQ3iPAjXHKCWe+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,kSuaGROw6BUxcEJL3I1mozjeCHV9A)
	blzqcYFMOuTZDAftPNv0kJr6nGm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe)
	if not blzqcYFMOuTZDAftPNv0kJr6nGm: YTPut68WBVUNCvsEzg.setSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe,'Unknown')
	o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe)
	return
def EqS3hPD6kiKcBa(yoVRGZgKlA2,VMHfWrwhpF,nQ3vm1Xh8yUVM,cZda3h1mtDNTIUEf8,ePWfkMVOIjUmpuBJ,q95KQaVBR21MLxPYNsbHDl,N6TBv2QuoRCmXi):
	mN1F4bAGHlUzjRQV2p,OreMF6UhQXnbByPo587S0lEN1 = [],[]
	rUGP2dZR8tLXneqYywi = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		if q95KQaVBR21MLxPYNsbHDl%473==0:
			pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,40+int(10*q95KQaVBR21MLxPYNsbHDl/ePWfkMVOIjUmpuBJ),'قراءة الفيديوهات','الفيديو رقم:-',str(q95KQaVBR21MLxPYNsbHDl)+' / '+str(ePWfkMVOIjUmpuBJ))
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return None,None,None
		HHPwg71GEVju = T072lCzjYiuaeFtmJGV.findall('^(.*?)\n+((http|https|rtmp).*?)$',vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,T072lCzjYiuaeFtmJGV.DOTALL)
		if HHPwg71GEVju:
			vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,HHPwg71GEVju,K5d3YZes0JaHjGSfcVmpW = HHPwg71GEVju[0]
			HHPwg71GEVju = HHPwg71GEVju.replace('\n','')
			vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.replace('\n','')
		else:
			OreMF6UhQXnbByPo587S0lEN1.append({'line':vWN8xonyO4BUsEpcYqaJSGt2PL3jMw})
			continue
		urNGsnAhiE3VBYgtaF0W5z69qcXlx,c60Epz1qjmHiKMl9BY,yyp5uq1HZTWwmtd,co7xPMVtuYQvy,ga4p3IxqUXMjTRPQZfH9J5E,CYpPEQs9coNRrfa7bJ8d = {},'','','','',False
		try:
			vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,co7xPMVtuYQvy = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.rsplit('",',1)
			vWN8xonyO4BUsEpcYqaJSGt2PL3jMw = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw+'"'
		except:
			try: vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,co7xPMVtuYQvy = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.rsplit('1,',1)
			except: co7xPMVtuYQvy = ''
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['url'] = HHPwg71GEVju
		HUs3N6RmIL1wlK0aZ2yGzhCxpJ = T072lCzjYiuaeFtmJGV.findall(' (.*?)="(.*?)"',vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,T072lCzjYiuaeFtmJGV.DOTALL)
		for HHhysw8NOZj3,RKNzmZkCPHwM5pB7XF in HUs3N6RmIL1wlK0aZ2yGzhCxpJ:
			HHhysw8NOZj3 = HHhysw8NOZj3.replace('"','').strip(' ')
			urNGsnAhiE3VBYgtaF0W5z69qcXlx[HHhysw8NOZj3] = RKNzmZkCPHwM5pB7XF.strip(' ')
		uSEg1N5Q0obPsH = list(urNGsnAhiE3VBYgtaF0W5z69qcXlx.keys())
		if not co7xPMVtuYQvy:
			if 'name' in uSEg1N5Q0obPsH and urNGsnAhiE3VBYgtaF0W5z69qcXlx['name']: co7xPMVtuYQvy = urNGsnAhiE3VBYgtaF0W5z69qcXlx['name']
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['title'] = co7xPMVtuYQvy.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in uSEg1N5Q0obPsH:
			urNGsnAhiE3VBYgtaF0W5z69qcXlx['img'] = urNGsnAhiE3VBYgtaF0W5z69qcXlx['logo']
			del urNGsnAhiE3VBYgtaF0W5z69qcXlx['logo']
		else: urNGsnAhiE3VBYgtaF0W5z69qcXlx['img'] = ''
		if 'group' in uSEg1N5Q0obPsH and urNGsnAhiE3VBYgtaF0W5z69qcXlx['group']: yyp5uq1HZTWwmtd = urNGsnAhiE3VBYgtaF0W5z69qcXlx['group']
		if any(EYn2siOeDvQTk8KpS0Jl in HHPwg71GEVju.lower() for EYn2siOeDvQTk8KpS0Jl in rUGP2dZR8tLXneqYywi):
			CYpPEQs9coNRrfa7bJ8d = True if 'm3u' not in HHPwg71GEVju else False
		if CYpPEQs9coNRrfa7bJ8d or '__SERIES__' in yyp5uq1HZTWwmtd or '__MOVIES__' in yyp5uq1HZTWwmtd:
			ga4p3IxqUXMjTRPQZfH9J5E = 'VOD'
			if '__SERIES__' in yyp5uq1HZTWwmtd: ga4p3IxqUXMjTRPQZfH9J5E = ga4p3IxqUXMjTRPQZfH9J5E+'_SERIES'
			elif '__MOVIES__' in yyp5uq1HZTWwmtd: ga4p3IxqUXMjTRPQZfH9J5E = ga4p3IxqUXMjTRPQZfH9J5E+'_MOVIES'
			else: ga4p3IxqUXMjTRPQZfH9J5E = ga4p3IxqUXMjTRPQZfH9J5E+'_UNKNOWN'
			yyp5uq1HZTWwmtd = yyp5uq1HZTWwmtd.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			ga4p3IxqUXMjTRPQZfH9J5E = 'LIVE'
			if co7xPMVtuYQvy in VMHfWrwhpF: c60Epz1qjmHiKMl9BY = c60Epz1qjmHiKMl9BY+'_EPG'
			if co7xPMVtuYQvy in nQ3vm1Xh8yUVM: c60Epz1qjmHiKMl9BY = c60Epz1qjmHiKMl9BY+'_ARCHIVED'
			if not yyp5uq1HZTWwmtd: ga4p3IxqUXMjTRPQZfH9J5E = ga4p3IxqUXMjTRPQZfH9J5E+'_UNKNOWN'
			else: ga4p3IxqUXMjTRPQZfH9J5E = ga4p3IxqUXMjTRPQZfH9J5E+c60Epz1qjmHiKMl9BY
		yyp5uq1HZTWwmtd = yyp5uq1HZTWwmtd.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in ga4p3IxqUXMjTRPQZfH9J5E: yyp5uq1HZTWwmtd = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in ga4p3IxqUXMjTRPQZfH9J5E: yyp5uq1HZTWwmtd = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in ga4p3IxqUXMjTRPQZfH9J5E:
			IHufxTLDPldt9b2SJFmVUvEYO = T072lCzjYiuaeFtmJGV.findall('(.*?) [Ss]\d+ +[Ee]\d+',urNGsnAhiE3VBYgtaF0W5z69qcXlx['title'],T072lCzjYiuaeFtmJGV.DOTALL)
			if IHufxTLDPldt9b2SJFmVUvEYO: IHufxTLDPldt9b2SJFmVUvEYO = IHufxTLDPldt9b2SJFmVUvEYO[0]
			else: IHufxTLDPldt9b2SJFmVUvEYO = '!!__UNKNOWN_SERIES__!!'
			yyp5uq1HZTWwmtd = yyp5uq1HZTWwmtd+'__SERIES__'+IHufxTLDPldt9b2SJFmVUvEYO
		if 'id' in uSEg1N5Q0obPsH: del urNGsnAhiE3VBYgtaF0W5z69qcXlx['id']
		if 'ID' in uSEg1N5Q0obPsH: del urNGsnAhiE3VBYgtaF0W5z69qcXlx['ID']
		if 'name' in uSEg1N5Q0obPsH: del urNGsnAhiE3VBYgtaF0W5z69qcXlx['name']
		co7xPMVtuYQvy = urNGsnAhiE3VBYgtaF0W5z69qcXlx['title']
		co7xPMVtuYQvy = Bd2o0J6aOASWvuD9HzY(co7xPMVtuYQvy)
		co7xPMVtuYQvy = ewiIKxoDT4nrLkq6Ch8O(co7xPMVtuYQvy)
		Ce53cyAaoRYdXr9,yyp5uq1HZTWwmtd = RISNAf2U1BhxbvCW8FKutr0V9XYEon(yyp5uq1HZTWwmtd)
		LJjK3WNfS07TH6syFpGlt9,co7xPMVtuYQvy = RISNAf2U1BhxbvCW8FKutr0V9XYEon(co7xPMVtuYQvy)
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['type'] = ga4p3IxqUXMjTRPQZfH9J5E
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['context'] = c60Epz1qjmHiKMl9BY
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['group'] = yyp5uq1HZTWwmtd.upper()
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['title'] = co7xPMVtuYQvy.upper()
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['country'] = LJjK3WNfS07TH6syFpGlt9.upper()
		urNGsnAhiE3VBYgtaF0W5z69qcXlx['language'] = Ce53cyAaoRYdXr9.upper()
		mN1F4bAGHlUzjRQV2p.append(urNGsnAhiE3VBYgtaF0W5z69qcXlx)
		q95KQaVBR21MLxPYNsbHDl += 1
	return mN1F4bAGHlUzjRQV2p,q95KQaVBR21MLxPYNsbHDl,OreMF6UhQXnbByPo587S0lEN1
def ewiIKxoDT4nrLkq6Ch8O(co7xPMVtuYQvy):
	co7xPMVtuYQvy = co7xPMVtuYQvy.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	co7xPMVtuYQvy = co7xPMVtuYQvy.replace('||','|').replace('___',':').replace('--','-')
	co7xPMVtuYQvy = co7xPMVtuYQvy.replace('[[','[').replace(']]',']')
	co7xPMVtuYQvy = co7xPMVtuYQvy.replace('((','(').replace('))',')')
	co7xPMVtuYQvy = co7xPMVtuYQvy.replace('<<','<').replace('>>','>')
	co7xPMVtuYQvy = co7xPMVtuYQvy.strip(' ')
	return co7xPMVtuYQvy
def NV4qHk3cmIhrgwvBCfjSApxu59F(jKDgi057UGY,cZda3h1mtDNTIUEf8,m3GDX2bd7jku1KQrZeNwABcUEP4ynV):
	PYh6gqjxsunUBtc2zyJ3Ve = {}
	for bPK92VZ3Ju in MENHxhV1f6JI3o2pO54D9gbuyGakiT: PYh6gqjxsunUBtc2zyJ3Ve[bPK92VZ3Ju+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV] = []
	ePWfkMVOIjUmpuBJ = len(jKDgi057UGY)
	tWUxnRKpJfFTqOCDjgXy0cs1z = str(ePWfkMVOIjUmpuBJ)
	q95KQaVBR21MLxPYNsbHDl = 0
	OreMF6UhQXnbByPo587S0lEN1 = []
	for urNGsnAhiE3VBYgtaF0W5z69qcXlx in jKDgi057UGY:
		if q95KQaVBR21MLxPYNsbHDl%873==0:
			pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,50+int(5*q95KQaVBR21MLxPYNsbHDl/ePWfkMVOIjUmpuBJ),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(q95KQaVBR21MLxPYNsbHDl)+' / '+tWUxnRKpJfFTqOCDjgXy0cs1z)
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return None,None
		yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu = urNGsnAhiE3VBYgtaF0W5z69qcXlx['group'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['context'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['title'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['url'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['img']
		LJjK3WNfS07TH6syFpGlt9,Ce53cyAaoRYdXr9,bPK92VZ3Ju = urNGsnAhiE3VBYgtaF0W5z69qcXlx['country'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['language'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['type']
		bbSHlp6syo0ZJCu9qn = (yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu)
		AIHdrOLPm8oT9i = False
		if 'LIVE' in bPK92VZ3Ju:
			if 'UNKNOWN' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_UNKNOWN_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			elif 'LIVE' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			else: AIHdrOLPm8oT9i = True
			PYh6gqjxsunUBtc2zyJ3Ve['LIVE_ORIGINAL_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
		elif 'VOD' in bPK92VZ3Ju:
			if 'UNKNOWN' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_UNKNOWN_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			elif 'MOVIES' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_MOVIES_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			elif 'SERIES' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_SERIES_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			else: AIHdrOLPm8oT9i = True
			PYh6gqjxsunUBtc2zyJ3Ve['VOD_ORIGINAL_GROUPED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
		else: AIHdrOLPm8oT9i = True
		if AIHdrOLPm8oT9i: OreMF6UhQXnbByPo587S0lEN1.append(urNGsnAhiE3VBYgtaF0W5z69qcXlx)
		q95KQaVBR21MLxPYNsbHDl += 1
	F1cO5ayB09rwQUg36KGdopsV = sorted(jKDgi057UGY,reverse=False,key=lambda HHhysw8NOZj3: HHhysw8NOZj3['title'].lower())
	del jKDgi057UGY
	tWUxnRKpJfFTqOCDjgXy0cs1z = str(ePWfkMVOIjUmpuBJ)
	q95KQaVBR21MLxPYNsbHDl = 0
	for urNGsnAhiE3VBYgtaF0W5z69qcXlx in F1cO5ayB09rwQUg36KGdopsV:
		q95KQaVBR21MLxPYNsbHDl += 1
		if q95KQaVBR21MLxPYNsbHDl%873==0:
			pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,55+int(5*q95KQaVBR21MLxPYNsbHDl/ePWfkMVOIjUmpuBJ),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(q95KQaVBR21MLxPYNsbHDl)+' / '+tWUxnRKpJfFTqOCDjgXy0cs1z)
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return None,None
		bPK92VZ3Ju = urNGsnAhiE3VBYgtaF0W5z69qcXlx['type']
		yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu = urNGsnAhiE3VBYgtaF0W5z69qcXlx['group'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['context'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['title'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['url'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['img']
		LJjK3WNfS07TH6syFpGlt9,Ce53cyAaoRYdXr9 = urNGsnAhiE3VBYgtaF0W5z69qcXlx['country'],urNGsnAhiE3VBYgtaF0W5z69qcXlx['language']
		ttrnpSKjVNzDxFQb5il4qo3 = (yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY+'_TIMESHIFT',co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu)
		bbSHlp6syo0ZJCu9qn = (yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu)
		OX0by5ZMWNVFUEma4Hpj = (LJjK3WNfS07TH6syFpGlt9,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu)
		AAl97kvM6eIVj2JZL = (Ce53cyAaoRYdXr9,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu)
		if 'LIVE' in bPK92VZ3Ju:
			if 'UNKNOWN' in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_UNKNOWN_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			else: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			if 'EPG'		in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_EPG_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			if 'ARCHIVED'	in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_ARCHIVED_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			if 'ARCHIVED'	in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['LIVE_TIMESHIFT_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(ttrnpSKjVNzDxFQb5il4qo3)
			PYh6gqjxsunUBtc2zyJ3Ve['LIVE_FROM_NAME_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(OX0by5ZMWNVFUEma4Hpj)
			PYh6gqjxsunUBtc2zyJ3Ve['LIVE_FROM_GROUP_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(AAl97kvM6eIVj2JZL)
		elif 'VOD' in bPK92VZ3Ju:
			if   'UNKNOWN'	in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_UNKNOWN_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			elif 'MOVIES'	in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_MOVIES_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			elif 'SERIES'	in bPK92VZ3Ju: PYh6gqjxsunUBtc2zyJ3Ve['VOD_SERIES_GROUPED_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(bbSHlp6syo0ZJCu9qn)
			PYh6gqjxsunUBtc2zyJ3Ve['VOD_FROM_NAME_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(OX0by5ZMWNVFUEma4Hpj)
			PYh6gqjxsunUBtc2zyJ3Ve['VOD_FROM_GROUP_SORTED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV].append(AAl97kvM6eIVj2JZL)
	return PYh6gqjxsunUBtc2zyJ3Ve,OreMF6UhQXnbByPo587S0lEN1
def RISNAf2U1BhxbvCW8FKutr0V9XYEon(co7xPMVtuYQvy):
	if len(co7xPMVtuYQvy)<3: return co7xPMVtuYQvy,co7xPMVtuYQvy
	LB7j16vfXy5RlZ8,DMSf7napugIBszWNy35Z = '',''
	F76f4YUbRAWtzly8h9Z = co7xPMVtuYQvy
	Ypx5EtAVQcvMlPIj = co7xPMVtuYQvy[:1]
	YreMZtJB48bROlDpQcyXxzPKETnF = co7xPMVtuYQvy[1:]
	if   Ypx5EtAVQcvMlPIj=='(': DMSf7napugIBszWNy35Z = ')'
	elif Ypx5EtAVQcvMlPIj=='[': DMSf7napugIBszWNy35Z = ']'
	elif Ypx5EtAVQcvMlPIj=='<': DMSf7napugIBszWNy35Z = '>'
	elif Ypx5EtAVQcvMlPIj=='|': DMSf7napugIBszWNy35Z = '|'
	if DMSf7napugIBszWNy35Z and (DMSf7napugIBszWNy35Z in YreMZtJB48bROlDpQcyXxzPKETnF):
		A6GDiUqKov2,njqdrgGQHPL8IoERYFlsMB4ezWyTmh = YreMZtJB48bROlDpQcyXxzPKETnF.split(DMSf7napugIBszWNy35Z,1)
		LB7j16vfXy5RlZ8 = A6GDiUqKov2
		F76f4YUbRAWtzly8h9Z = Ypx5EtAVQcvMlPIj+A6GDiUqKov2+DMSf7napugIBszWNy35Z+' '+njqdrgGQHPL8IoERYFlsMB4ezWyTmh
	elif co7xPMVtuYQvy.count('|')>=2:
		A6GDiUqKov2,njqdrgGQHPL8IoERYFlsMB4ezWyTmh = co7xPMVtuYQvy.split('|',1)
		LB7j16vfXy5RlZ8 = A6GDiUqKov2
		F76f4YUbRAWtzly8h9Z = A6GDiUqKov2+' |'+njqdrgGQHPL8IoERYFlsMB4ezWyTmh
	else:
		DMSf7napugIBszWNy35Z = T072lCzjYiuaeFtmJGV.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',co7xPMVtuYQvy,T072lCzjYiuaeFtmJGV.DOTALL)
		if not DMSf7napugIBszWNy35Z: DMSf7napugIBszWNy35Z = T072lCzjYiuaeFtmJGV.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',co7xPMVtuYQvy,T072lCzjYiuaeFtmJGV.DOTALL)
		if not DMSf7napugIBszWNy35Z: DMSf7napugIBszWNy35Z = T072lCzjYiuaeFtmJGV.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',co7xPMVtuYQvy,T072lCzjYiuaeFtmJGV.DOTALL)
		if DMSf7napugIBszWNy35Z:
			A6GDiUqKov2,njqdrgGQHPL8IoERYFlsMB4ezWyTmh = co7xPMVtuYQvy.split(DMSf7napugIBszWNy35Z[0],1)
			LB7j16vfXy5RlZ8 = A6GDiUqKov2
			F76f4YUbRAWtzly8h9Z = A6GDiUqKov2+' '+DMSf7napugIBszWNy35Z[0]+' '+njqdrgGQHPL8IoERYFlsMB4ezWyTmh
	F76f4YUbRAWtzly8h9Z = F76f4YUbRAWtzly8h9Z.replace('   ',' ').replace('  ',' ')
	LB7j16vfXy5RlZ8 = LB7j16vfXy5RlZ8.replace('  ',' ')
	if not LB7j16vfXy5RlZ8: LB7j16vfXy5RlZ8 = '!!__UNKNOWN__!!'
	LB7j16vfXy5RlZ8 = LB7j16vfXy5RlZ8.strip(' ')
	F76f4YUbRAWtzly8h9Z = F76f4YUbRAWtzly8h9Z.strip(' ')
	return LB7j16vfXy5RlZ8,F76f4YUbRAWtzly8h9Z
def yObVNhRgQ8pdxCo9k6(kQ3iPAjXHKCWe):
	z1megRlwFGk6B = {}
	blzqcYFMOuTZDAftPNv0kJr6nGm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe)
	if blzqcYFMOuTZDAftPNv0kJr6nGm: z1megRlwFGk6B['User-Agent'] = blzqcYFMOuTZDAftPNv0kJr6nGm
	rfQqZmwdLn5RaY = YTPut68WBVUNCvsEzg.getSetting('av.m3u.referer_'+kQ3iPAjXHKCWe)
	if rfQqZmwdLn5RaY: z1megRlwFGk6B['Referer'] = rfQqZmwdLn5RaY
	return z1megRlwFGk6B
def H8AO0LqXf4DVbPyM(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV):
	global cZda3h1mtDNTIUEf8,PYh6gqjxsunUBtc2zyJ3Ve,lJWm12hocI3g5QerDPyjXC,WzJ0vuHB2fEkxrKY5VeinN1tZUl7,qX46OAV0N7WDYHZ1PKSjTR8n,Q2z0ELKMtdk,T6C7021MG9vdIbeQ8rYEoP,gWYtf3MvZQqpXl42K,aY3MxSuJqF4gBTvde
	N6TBv2QuoRCmXi = YTPut68WBVUNCvsEzg.getSetting('av.m3u.url_'+kQ3iPAjXHKCWe+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	blzqcYFMOuTZDAftPNv0kJr6nGm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.useragent_'+kQ3iPAjXHKCWe)
	z1megRlwFGk6B = {'User-Agent':blzqcYFMOuTZDAftPNv0kJr6nGm}
	FEY9qnd4GM2w = vHYUae4cO1XlpwWIziyCdA6Q.replace('___','_'+kQ3iPAjXHKCWe+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	if 1:
		JzGp5aDTFHMe1nNKZRAoLu7Q,UqgEZYnFXDBKAVc67duaLbk2oyjv,f81gXe3ysjtlckibaNY0QxAEW7 = True,'',''
		if not JzGp5aDTFHMe1nNKZRAoLu7Q:
			KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not N6TBv2QuoRCmXi: GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(nO6ukabcldeU)+'   No M3U URL found to download M3U files')
			else: GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(eNv8QX5p0UAnMx6sdk)+'   Failed to download M3U files')
			return
		qZJ103fIjVDNHK = de5ZW2bFQ64CPgG(N6TBv2QuoRCmXi,z1megRlwFGk6B,True)
		if not qZJ103fIjVDNHK: return
		open(FEY9qnd4GM2w,'wb').write(qZJ103fIjVDNHK)
	else: qZJ103fIjVDNHK = open(FEY9qnd4GM2w,'rb').read()
	if mmIKCGujwM and qZJ103fIjVDNHK: qZJ103fIjVDNHK = qZJ103fIjVDNHK.decode('utf8')
	cZda3h1mtDNTIUEf8 = RNrYlESg2f0OLJnG7wQ()
	cZda3h1mtDNTIUEf8.create('جلب ملفات M3U جديدة','')
	pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,15,'تنظيف الملف الرئيسي','')
	qZJ103fIjVDNHK = qZJ103fIjVDNHK.replace('"tvg-','" tvg-')
	qZJ103fIjVDNHK = qZJ103fIjVDNHK.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	qZJ103fIjVDNHK = qZJ103fIjVDNHK.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	qZJ103fIjVDNHK = qZJ103fIjVDNHK.replace('group-title=','group=').replace('tvg-','')
	nQ3vm1Xh8yUVM,VMHfWrwhpF = [],[]
	qZJ103fIjVDNHK = qZJ103fIjVDNHK.replace('\r','\n')
	yoVRGZgKlA2 = T072lCzjYiuaeFtmJGV.findall('NF:(.+?)'+'#'+'EXTI',qZJ103fIjVDNHK+'\n+'+'#'+'EXTINF:',T072lCzjYiuaeFtmJGV.DOTALL)
	if not yoVRGZgKlA2:
		GZvEITHSg5U3rVwQ('ERROR_LINES',G3xFBWM9vw42DNKQA57YSl(eNv8QX5p0UAnMx6sdk)+'   Folder:'+kQ3iPAjXHKCWe+'  Sequence:'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV+'   No video links found in M3U file')
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+kQ3iPAjXHKCWe+'      رابط رقم '+m3GDX2bd7jku1KQrZeNwABcUEP4ynV+'[/COLOR]')
		cZda3h1mtDNTIUEf8.close()
		return
	wwhSDBPvXFCLAbNTG = []
	for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
		R7R3WE4ud08zv = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.lower()
		if 'adult' in R7R3WE4ud08zv: continue
		if 'xxx' in R7R3WE4ud08zv: continue
		wwhSDBPvXFCLAbNTG.append(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw)
	yoVRGZgKlA2 = wwhSDBPvXFCLAbNTG
	del wwhSDBPvXFCLAbNTG
	if 'iptv-org' in N6TBv2QuoRCmXi:
		wwhSDBPvXFCLAbNTG,tKWchCapQ4Yg9sAOxViD = [],[]
		for vWN8xonyO4BUsEpcYqaJSGt2PL3jMw in yoVRGZgKlA2:
			Q2z0ELKMtdk = T072lCzjYiuaeFtmJGV.findall('group="(.*?)"',vWN8xonyO4BUsEpcYqaJSGt2PL3jMw,T072lCzjYiuaeFtmJGV.DOTALL)
			if Q2z0ELKMtdk:
				Q2z0ELKMtdk = Q2z0ELKMtdk[0]
				nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7 = Q2z0ELKMtdk.split(';')
				if 'region' in N6TBv2QuoRCmXi: G0qTORQ7rBk1PximvzJ = '1_'
				elif 'category' in N6TBv2QuoRCmXi: G0qTORQ7rBk1PximvzJ = '2_'
				elif 'language' in N6TBv2QuoRCmXi: G0qTORQ7rBk1PximvzJ = '3_'
				elif 'country' in N6TBv2QuoRCmXi: G0qTORQ7rBk1PximvzJ = '4_'
				else: G0qTORQ7rBk1PximvzJ = '5_'
				bQMkJKStjq1u20s9ZWLdz83m5G6ecX = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.replace('group="'+Q2z0ELKMtdk+'"','group="'+G0qTORQ7rBk1PximvzJ+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				wwhSDBPvXFCLAbNTG.append(bQMkJKStjq1u20s9ZWLdz83m5G6ecX)
				for yyp5uq1HZTWwmtd in nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7:
					bQMkJKStjq1u20s9ZWLdz83m5G6ecX = vWN8xonyO4BUsEpcYqaJSGt2PL3jMw.replace('group="'+Q2z0ELKMtdk+'"','group="'+G0qTORQ7rBk1PximvzJ+yyp5uq1HZTWwmtd+'"')
					wwhSDBPvXFCLAbNTG.append(bQMkJKStjq1u20s9ZWLdz83m5G6ecX)
			else: wwhSDBPvXFCLAbNTG.append(vWN8xonyO4BUsEpcYqaJSGt2PL3jMw)
		yoVRGZgKlA2 = wwhSDBPvXFCLAbNTG
		del wwhSDBPvXFCLAbNTG,tKWchCapQ4Yg9sAOxViD
	M65bxQjLYX8arNgKSmdVe7AB20 = 1024*1024
	yXpVNWuRneQxvD2 = 1+len(qZJ103fIjVDNHK)//M65bxQjLYX8arNgKSmdVe7AB20//10
	del qZJ103fIjVDNHK
	ZqlG1UvpBAYkNOFgdow3M6iaL9ef = len(yoVRGZgKlA2)
	tKWchCapQ4Yg9sAOxViD = Pfl6pNBAE7YsU(yoVRGZgKlA2,yXpVNWuRneQxvD2)
	del yoVRGZgKlA2
	for hU3gvdkbXl5HVAYecR6sJGyB in range(yXpVNWuRneQxvD2):
		pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,35+int(5*hU3gvdkbXl5HVAYecR6sJGyB/yXpVNWuRneQxvD2),'تقطيع الملف الرئيسي','الجزء رقم:-',str(hU3gvdkbXl5HVAYecR6sJGyB+1)+' / '+str(yXpVNWuRneQxvD2))
		if cZda3h1mtDNTIUEf8.iscanceled():
			cZda3h1mtDNTIUEf8.close()
			return
		vcK9fDro7P0QBtAUs4jdmbZgFIVEx = str(tKWchCapQ4Yg9sAOxViD[hU3gvdkbXl5HVAYecR6sJGyB])
		if mmIKCGujwM: vcK9fDro7P0QBtAUs4jdmbZgFIVEx = vcK9fDro7P0QBtAUs4jdmbZgFIVEx.encode('utf8')
		open(FEY9qnd4GM2w+'.00'+str(hU3gvdkbXl5HVAYecR6sJGyB),'wb').write(vcK9fDro7P0QBtAUs4jdmbZgFIVEx)
	del tKWchCapQ4Yg9sAOxViD,vcK9fDro7P0QBtAUs4jdmbZgFIVEx
	pXvEtVGZ98NdJibsogKknCUeMhy,jKDgi057UGY,q95KQaVBR21MLxPYNsbHDl = [],[],0
	for hU3gvdkbXl5HVAYecR6sJGyB in range(yXpVNWuRneQxvD2):
		if cZda3h1mtDNTIUEf8.iscanceled():
			cZda3h1mtDNTIUEf8.close()
			return
		vcK9fDro7P0QBtAUs4jdmbZgFIVEx = open(FEY9qnd4GM2w+'.00'+str(hU3gvdkbXl5HVAYecR6sJGyB),'rb').read()
		D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(1)
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(FEY9qnd4GM2w+'.00'+str(hU3gvdkbXl5HVAYecR6sJGyB))
		except: pass
		if mmIKCGujwM: vcK9fDro7P0QBtAUs4jdmbZgFIVEx = vcK9fDro7P0QBtAUs4jdmbZgFIVEx.decode('utf8')
		llPBsSvgN7kA = cwiLy4IAVJj0pWCl7FGxokR('list',vcK9fDro7P0QBtAUs4jdmbZgFIVEx)
		del vcK9fDro7P0QBtAUs4jdmbZgFIVEx
		mN1F4bAGHlUzjRQV2p,q95KQaVBR21MLxPYNsbHDl,OreMF6UhQXnbByPo587S0lEN1 = EqS3hPD6kiKcBa(llPBsSvgN7kA,VMHfWrwhpF,nQ3vm1Xh8yUVM,cZda3h1mtDNTIUEf8,ZqlG1UvpBAYkNOFgdow3M6iaL9ef,q95KQaVBR21MLxPYNsbHDl,N6TBv2QuoRCmXi)
		if cZda3h1mtDNTIUEf8.iscanceled():
			cZda3h1mtDNTIUEf8.close()
			return
		if not mN1F4bAGHlUzjRQV2p:
			cZda3h1mtDNTIUEf8.close()
			return
		jKDgi057UGY += mN1F4bAGHlUzjRQV2p
		pXvEtVGZ98NdJibsogKknCUeMhy += OreMF6UhQXnbByPo587S0lEN1
	del llPBsSvgN7kA,mN1F4bAGHlUzjRQV2p
	PYh6gqjxsunUBtc2zyJ3Ve,OreMF6UhQXnbByPo587S0lEN1 = NV4qHk3cmIhrgwvBCfjSApxu59F(jKDgi057UGY,cZda3h1mtDNTIUEf8,m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	if cZda3h1mtDNTIUEf8.iscanceled():
		cZda3h1mtDNTIUEf8.close()
		return
	pXvEtVGZ98NdJibsogKknCUeMhy += OreMF6UhQXnbByPo587S0lEN1
	del jKDgi057UGY,OreMF6UhQXnbByPo587S0lEN1
	WzJ0vuHB2fEkxrKY5VeinN1tZUl7,qX46OAV0N7WDYHZ1PKSjTR8n,Q2z0ELKMtdk,T6C7021MG9vdIbeQ8rYEoP,gWYtf3MvZQqpXl42K = {},{},{},0,0
	AnBaqveY2os0XiDrEu = list(PYh6gqjxsunUBtc2zyJ3Ve.keys())
	aY3MxSuJqF4gBTvde = len(AnBaqveY2os0XiDrEu)*3
	if 1:
		BOkCIbYEmHpLj = {}
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			BOkCIbYEmHpLj[KQABSErcIo] = RZxCcFI8fw31NKP.Thread(target=w8whemrlZgy,args=(KQABSErcIo,))
			BOkCIbYEmHpLj[KQABSErcIo].start()
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			BOkCIbYEmHpLj[KQABSErcIo].join()
		if cZda3h1mtDNTIUEf8.iscanceled():
			cZda3h1mtDNTIUEf8.close()
			return
	else:
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			w8whemrlZgy(KQABSErcIo)
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return
	m8K0yvJzb2OntT(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV,False)
	AnBaqveY2os0XiDrEu = list(WzJ0vuHB2fEkxrKY5VeinN1tZUl7.keys())
	lJWm12hocI3g5QerDPyjXC = 0
	if 1:
		BOkCIbYEmHpLj = {}
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			BOkCIbYEmHpLj[KQABSErcIo] = RZxCcFI8fw31NKP.Thread(target=ttlg1J50MEZOKLWns3Toad97FADp6,args=(kQ3iPAjXHKCWe,KQABSErcIo))
			BOkCIbYEmHpLj[KQABSErcIo].start()
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			BOkCIbYEmHpLj[KQABSErcIo].join()
		if cZda3h1mtDNTIUEf8.iscanceled():
			cZda3h1mtDNTIUEf8.close()
			return
	else:
		for KQABSErcIo in AnBaqveY2os0XiDrEu:
			ttlg1J50MEZOKLWns3Toad97FADp6(kQ3iPAjXHKCWe,KQABSErcIo)
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return
	hU3gvdkbXl5HVAYecR6sJGyB = 0
	rckXMTaGIseW5zpn7UBxKdAN4v0gt8 = len(pXvEtVGZ98NdJibsogKknCUeMhy)
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'IGNORED')
	for YHEokXjlUzgu5F90pbsaIhLGJ2qyZv in pXvEtVGZ98NdJibsogKknCUeMhy:
		if hU3gvdkbXl5HVAYecR6sJGyB%27==0:
			pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,95+int(5*hU3gvdkbXl5HVAYecR6sJGyB//rckXMTaGIseW5zpn7UBxKdAN4v0gt8),'تخزين المهملة','الفيديو رقم:-',str(hU3gvdkbXl5HVAYecR6sJGyB)+' / '+str(rckXMTaGIseW5zpn7UBxKdAN4v0gt8))
			if cZda3h1mtDNTIUEf8.iscanceled():
				cZda3h1mtDNTIUEf8.close()
				return
		rrz7vWj1sdwU0qa(uuamKczE4h8,'IGNORED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,str(YHEokXjlUzgu5F90pbsaIhLGJ2qyZv),'',U6y1OBwzfkEuRGVNrpYFv)
		hU3gvdkbXl5HVAYecR6sJGyB += 1
	rrz7vWj1sdwU0qa(uuamKczE4h8,'IGNORED_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__',str(rckXMTaGIseW5zpn7UBxKdAN4v0gt8),U6y1OBwzfkEuRGVNrpYFv)
	cZda3h1mtDNTIUEf8.close()
	D1vBJgya85Yh4cRTCkIMKtWLSeH.sleep(1)
	o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe)
	return
def w8whemrlZgy(KQABSErcIo):
	global cZda3h1mtDNTIUEf8,PYh6gqjxsunUBtc2zyJ3Ve,lJWm12hocI3g5QerDPyjXC,WzJ0vuHB2fEkxrKY5VeinN1tZUl7,qX46OAV0N7WDYHZ1PKSjTR8n,Q2z0ELKMtdk,T6C7021MG9vdIbeQ8rYEoP,gWYtf3MvZQqpXl42K,aY3MxSuJqF4gBTvde
	WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo] = {}
	egsHmhoJvAIFQqft7aNMW2Vl91d,DDPO5Grzad1SIBcTwL = {},[]
	fZ5lvHeYuI = len(PYh6gqjxsunUBtc2zyJ3Ve[KQABSErcIo])
	WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo]['__COUNT__'] = fZ5lvHeYuI
	if fZ5lvHeYuI>0:
		HxcWU3MFirskaqb,ffYwRv6uDaI8sFhHV1TEAmdyrZS9PQ,VoKUIRMlCTmswhkObDqzeH,zpZDF97CSJUfmrKPsaNiuIc,wwNTAK3ORlF = zip(*PYh6gqjxsunUBtc2zyJ3Ve[KQABSErcIo])
		del ffYwRv6uDaI8sFhHV1TEAmdyrZS9PQ,VoKUIRMlCTmswhkObDqzeH,zpZDF97CSJUfmrKPsaNiuIc
		nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7 = list(set(HxcWU3MFirskaqb))
		for yyp5uq1HZTWwmtd in nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7:
			egsHmhoJvAIFQqft7aNMW2Vl91d[yyp5uq1HZTWwmtd] = ''
			WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo][yyp5uq1HZTWwmtd] = []
		pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,60+int(15*gWYtf3MvZQqpXl42K//aY3MxSuJqF4gBTvde),'تصنيع القوائم','الجزء رقم:-',str(gWYtf3MvZQqpXl42K)+' / '+str(aY3MxSuJqF4gBTvde))
		if cZda3h1mtDNTIUEf8.iscanceled(): return
		gWYtf3MvZQqpXl42K += 1
		noAmP1D6rbQTEHq = len(nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7)
		del nyBc8SjEzKGaTwFeMdXbkPQqCZp6f7
		DDPO5Grzad1SIBcTwL = list(set(zip(HxcWU3MFirskaqb,wwNTAK3ORlF)))
		del HxcWU3MFirskaqb,wwNTAK3ORlF
		for yyp5uq1HZTWwmtd,rHC4l56cOGQ9sX0Mj in DDPO5Grzad1SIBcTwL:
			if not egsHmhoJvAIFQqft7aNMW2Vl91d[yyp5uq1HZTWwmtd] and rHC4l56cOGQ9sX0Mj: egsHmhoJvAIFQqft7aNMW2Vl91d[yyp5uq1HZTWwmtd] = rHC4l56cOGQ9sX0Mj
		pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,60+int(15*gWYtf3MvZQqpXl42K//aY3MxSuJqF4gBTvde),'تصنيع القوائم','الجزء رقم:-',str(gWYtf3MvZQqpXl42K)+' / '+str(aY3MxSuJqF4gBTvde))
		if cZda3h1mtDNTIUEf8.iscanceled(): return
		gWYtf3MvZQqpXl42K += 1
		AuFb0HOQmntGT2ga9LVsZJo3NYx = list(egsHmhoJvAIFQqft7aNMW2Vl91d.keys())
		XYd0HkgNbx3WPsCQzvRL = list(egsHmhoJvAIFQqft7aNMW2Vl91d.values())
		del egsHmhoJvAIFQqft7aNMW2Vl91d
		DDPO5Grzad1SIBcTwL = list(zip(AuFb0HOQmntGT2ga9LVsZJo3NYx,XYd0HkgNbx3WPsCQzvRL))
		del AuFb0HOQmntGT2ga9LVsZJo3NYx,XYd0HkgNbx3WPsCQzvRL
		DDPO5Grzad1SIBcTwL = sorted(DDPO5Grzad1SIBcTwL)
	else: gWYtf3MvZQqpXl42K += 2
	WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo]['__GROUPS__'] = DDPO5Grzad1SIBcTwL
	del DDPO5Grzad1SIBcTwL
	for yyp5uq1HZTWwmtd,c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu in PYh6gqjxsunUBtc2zyJ3Ve[KQABSErcIo]:
		WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo][yyp5uq1HZTWwmtd].append((c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu))
	pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,60+int(15*gWYtf3MvZQqpXl42K//aY3MxSuJqF4gBTvde),'تصنيع القوائم','الجزء رقم:-',str(gWYtf3MvZQqpXl42K)+' / '+str(aY3MxSuJqF4gBTvde))
	if cZda3h1mtDNTIUEf8.iscanceled(): return
	gWYtf3MvZQqpXl42K += 1
	del PYh6gqjxsunUBtc2zyJ3Ve[KQABSErcIo]
	Q2z0ELKMtdk[KQABSErcIo] = list(WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo].keys())
	qX46OAV0N7WDYHZ1PKSjTR8n[KQABSErcIo] = len(Q2z0ELKMtdk[KQABSErcIo])
	T6C7021MG9vdIbeQ8rYEoP += qX46OAV0N7WDYHZ1PKSjTR8n[KQABSErcIo]
	return
def ttlg1J50MEZOKLWns3Toad97FADp6(kQ3iPAjXHKCWe,KQABSErcIo):
	global cZda3h1mtDNTIUEf8,PYh6gqjxsunUBtc2zyJ3Ve,lJWm12hocI3g5QerDPyjXC,WzJ0vuHB2fEkxrKY5VeinN1tZUl7,qX46OAV0N7WDYHZ1PKSjTR8n,Q2z0ELKMtdk,T6C7021MG9vdIbeQ8rYEoP,gWYtf3MvZQqpXl42K,aY3MxSuJqF4gBTvde
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,KQABSErcIo)
	for q95KQaVBR21MLxPYNsbHDl in range(1+qX46OAV0N7WDYHZ1PKSjTR8n[KQABSErcIo]//273):
		comntkFs64IGJ = []
		MgpEicNk60vPF2DKL7hAa = Q2z0ELKMtdk[KQABSErcIo][0:273]
		for yyp5uq1HZTWwmtd in MgpEicNk60vPF2DKL7hAa:
			comntkFs64IGJ.append(WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo][yyp5uq1HZTWwmtd])
		rrz7vWj1sdwU0qa(uuamKczE4h8,KQABSErcIo,MgpEicNk60vPF2DKL7hAa,comntkFs64IGJ,U6y1OBwzfkEuRGVNrpYFv,True)
		lJWm12hocI3g5QerDPyjXC += len(MgpEicNk60vPF2DKL7hAa)
		pGEkoTq6MimvXUVf34tBrhAuHW0O(cZda3h1mtDNTIUEf8,75+int(20*lJWm12hocI3g5QerDPyjXC//T6C7021MG9vdIbeQ8rYEoP),'تخزين القوائم','القائمة رقم:-',str(lJWm12hocI3g5QerDPyjXC)+' / '+str(T6C7021MG9vdIbeQ8rYEoP))
		if cZda3h1mtDNTIUEf8.iscanceled(): return
		del Q2z0ELKMtdk[KQABSErcIo][0:273]
	del WzJ0vuHB2fEkxrKY5VeinN1tZUl7[KQABSErcIo],Q2z0ELKMtdk[KQABSErcIo],qX46OAV0N7WDYHZ1PKSjTR8n[KQABSErcIo]
	return
def li20yx4pHT6bqBdk(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV,jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	gJ7l8O4ZhFz6dqGCcm = 'عدد فيديوهات جميع الروابط'
	fQ5GCsrn4xiEPOLpAgBSkclbe6dT1 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'LIVE_ORIGINAL_GROUPED')
	bzZ7RO9dcKNFoHIjSXGxrvfiCwan = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'VOD_ORIGINAL_GROUPED')
	if m3GDX2bd7jku1KQrZeNwABcUEP4ynV:
		gJ7l8O4ZhFz6dqGCcm = 'عدد فيديوهات رابط '+Yrb603795v[int(m3GDX2bd7jku1KQrZeNwABcUEP4ynV)]
		m3GDX2bd7jku1KQrZeNwABcUEP4ynV = '_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV
	rckXMTaGIseW5zpn7UBxKdAN4v0gt8 = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','IGNORED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	oozEfauIhQGM9sD3bAPWlTFCSKe4L = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','LIVE_ORIGINAL_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	kzaCwZlXvJu = IBxvzdjXCgS(bzZ7RO9dcKNFoHIjSXGxrvfiCwan,'int','VOD_ORIGINAL_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	S28QgAs0ZJGirhd = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','LIVE_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	jO2pERLz34qCHoaftNKWZni = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','LIVE_UNKNOWN_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	A6ZHr9Yz43i = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','VOD_MOVIES_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	gjDKzNYhGdQ4SRs = IBxvzdjXCgS(bzZ7RO9dcKNFoHIjSXGxrvfiCwan,'int','VOD_SERIES_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	fJbBpR1lmHsgU269Aiw3LNejSE0 = IBxvzdjXCgS(fQ5GCsrn4xiEPOLpAgBSkclbe6dT1,'int','VOD_UNKNOWN_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__COUNT__')
	Q2z0ELKMtdk = IBxvzdjXCgS(bzZ7RO9dcKNFoHIjSXGxrvfiCwan,'list','VOD_SERIES_GROUPED'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV,'__GROUPS__')
	LS4Zj2PCtYBnpE = []
	for yyp5uq1HZTWwmtd,pwm2PdsA5cTagHOeCu in Q2z0ELKMtdk:
		K34KL2qbw5RuHSUc9YCNPtJlv = yyp5uq1HZTWwmtd.split('__SERIES__')[1]
		LS4Zj2PCtYBnpE.append(K34KL2qbw5RuHSUc9YCNPtJlv)
	FPufBIRtgoUJqdWy = len(LS4Zj2PCtYBnpE)
	GZtThAxePiQJuwmdN2K0Rcj6VWbk = int(A6ZHr9Yz43i)+int(gjDKzNYhGdQ4SRs)+int(fJbBpR1lmHsgU269Aiw3LNejSE0)+int(jO2pERLz34qCHoaftNKWZni)+int(S28QgAs0ZJGirhd)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW = ''
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += 'قنوات: '+str(S28QgAs0ZJGirhd)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '   .   أفلام: '+str(A6ZHr9Yz43i)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '\nمسلسلات: '+str(FPufBIRtgoUJqdWy)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '   .   حلقات: '+str(gjDKzNYhGdQ4SRs)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '\nقنوات مجهولة: '+str(jO2pERLz34qCHoaftNKWZni)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '   .   فيدوهات مجهولة: '+str(fJbBpR1lmHsgU269Aiw3LNejSE0)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '\nمجموع القنوات: '+str(oozEfauIhQGM9sD3bAPWlTFCSKe4L)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '   .   مجموع الفيديوهات: '+str(kzaCwZlXvJu)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '\n\nمجموع المضافة: '+str(GZtThAxePiQJuwmdN2K0Rcj6VWbk)
	zhP5E6nZl2i8ICGNwxXpgqHfjbW += '   .   مجموع المهملة: '+str(rckXMTaGIseW5zpn7UBxKdAN4v0gt8)
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn: KK47FGdX1TDfkb3AjHOQqghE('center','',gJ7l8O4ZhFz6dqGCcm,zhP5E6nZl2i8ICGNwxXpgqHfjbW)
	vw6TQVj7o2kg0Dc = zhP5E6nZl2i8ICGNwxXpgqHfjbW.replace('\n\n','\n')
	if not m3GDX2bd7jku1KQrZeNwABcUEP4ynV: m3GDX2bd7jku1KQrZeNwABcUEP4ynV = 'All'
	else: m3GDX2bd7jku1KQrZeNwABcUEP4ynV = m3GDX2bd7jku1KQrZeNwABcUEP4ynV[1]
	GZvEITHSg5U3rVwQ('NOTICE','.  Counts of M3U videos   Folder: '+kQ3iPAjXHKCWe+'   Sequence: '+m3GDX2bd7jku1KQrZeNwABcUEP4ynV+'\n'+vw6TQVj7o2kg0Dc)
	return zhP5E6nZl2i8ICGNwxXpgqHfjbW
def m8K0yvJzb2OntT(kQ3iPAjXHKCWe,m3GDX2bd7jku1KQrZeNwABcUEP4ynV,jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn:
		eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if eZId7XMDvV6Jno938!=1: return
		mP5G0bUs1KC9onekY = vHYUae4cO1XlpwWIziyCdA6Q.replace('___','_'+kQ3iPAjXHKCWe+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(mP5G0bUs1KC9onekY)
		except: pass
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'')
	if m3GDX2bd7jku1KQrZeNwABcUEP4ynV:
		ASi2hrfXVkEPLIp6lgceWsMBo = []
		for MX7dKztesp5UDv0 in MENHxhV1f6JI3o2pO54D9gbuyGakiT:
			ASi2hrfXVkEPLIp6lgceWsMBo.append(MX7dKztesp5UDv0+'_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
		Nmkj7L5VEo(uuamKczE4h8,'LINK_'+m3GDX2bd7jku1KQrZeNwABcUEP4ynV)
	else:
		ASi2hrfXVkEPLIp6lgceWsMBo = MENHxhV1f6JI3o2pO54D9gbuyGakiT
		Nmkj7L5VEo(uuamKczE4h8,'DUMMY')
		Nmkj7L5VEo(uuamKczE4h8,'GROUPS')
		Nmkj7L5VEo(uuamKczE4h8,'ITEMS')
		Nmkj7L5VEo(uuamKczE4h8,'SEARCH')
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_'+kQ3iPAjXHKCWe)
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for KQABSErcIo in ASi2hrfXVkEPLIp6lgceWsMBo:
		Nmkj7L5VEo(uuamKczE4h8,KQABSErcIo)
	bkfanGl0mAz8hM6(False)
	o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe)
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn: KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe='',jH5UCJQ4v7VPwqlmYy0XRcALzWn=True):
	if kQ3iPAjXHKCWe:
		uuamKczE4h8 = CBzpaugA80bq3sxe24(str(kQ3iPAjXHKCWe),'DUMMY')
		K5d3YZes0JaHjGSfcVmpW = IBxvzdjXCgS(uuamKczE4h8,'str','DUMMY','__DUMMY__')
		if K5d3YZes0JaHjGSfcVmpW: return True
	else:
		kQ3iPAjXHKCWe = '1'
		for JubO84F3UHk9cdQemgRMl in range(1,U1UsphAegPmDYZXfTW+1):
			uuamKczE4h8 = CBzpaugA80bq3sxe24(str(JubO84F3UHk9cdQemgRMl),'DUMMY')
			K5d3YZes0JaHjGSfcVmpW = IBxvzdjXCgS(uuamKczE4h8,'str','DUMMY','__DUMMY__')
			if K5d3YZes0JaHjGSfcVmpW: return True
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn:
		LEeMkDIcg9 = 'https://iptv-org.github.io/iptv/index.region.m3u'
		zP4LsDqJNw = 'https://iptv-org.github.io/iptv/index.category.m3u'
		eQpF3LzNHtgasvbU8nfGlqu = 'https://iptv-org.github.io/iptv/index.language.m3u'
		PypDBm5fML8cAOg = 'https://iptv-org.github.io/iptv/index.country.m3u'
		bBygIt9z3mVZPo = LEeMkDIcg9+'\n'+zP4LsDqJNw+'\n'+eQpF3LzNHtgasvbU8nfGlqu+'\n'+PypDBm5fML8cAOg
		eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+bBygIt9z3mVZPo+'[/COLOR]',profile='confirm_mediumfont')
		if eZId7XMDvV6Jno938==1:
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.url_'+str(kQ3iPAjXHKCWe)+'_1',LEeMkDIcg9)
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.url_'+str(kQ3iPAjXHKCWe)+'_2',zP4LsDqJNw)
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.url_'+str(kQ3iPAjXHKCWe)+'_3',eQpF3LzNHtgasvbU8nfGlqu)
			YTPut68WBVUNCvsEzg.setSetting('av.m3u.url_'+str(kQ3iPAjXHKCWe)+'_4',PypDBm5fML8cAOg)
			eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if eZId7XMDvV6Jno938==1:
				bKSDhmtcfaIvQgCw03WEde = tQ1EyGcl0Su(kQ3iPAjXHKCWe)
				return bKSDhmtcfaIvQgCw03WEde
		else:
			gJ7l8O4ZhFz6dqGCcm = 'إضافة وتغيير رابط '+Yrb603795v[1]+' (مجلد '+Yrb603795v[int(kQ3iPAjXHKCWe)]+')'
			eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('','','',gJ7l8O4ZhFz6dqGCcm,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if eZId7XMDvV6Jno938==1: l7kbyVTqoJcsiUtePwKu(kQ3iPAjXHKCWe,'1')
	return False
def RYW8dS3E1GVjzsLPcku(BJvPC1LuWZUEobzfdqQAcXkxGSRF,kQ3iPAjXHKCWe='',KQABSErcIo='',iir30yaXElzYc7KC9uPNbo=''):
	if not iir30yaXElzYc7KC9uPNbo: iir30yaXElzYc7KC9uPNbo = '1'
	NkA8uQ3zHaRq,qpXBSH0v2uyR7lEiIftkeKYMcCD,jH5UCJQ4v7VPwqlmYy0XRcALzWn = o0Vixfg9ANze1OshdmaX(BJvPC1LuWZUEobzfdqQAcXkxGSRF)
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn): return
	if not NkA8uQ3zHaRq:
		NkA8uQ3zHaRq = NWs7KpjXGnxYylofHtd5U3wDh()
		if not NkA8uQ3zHaRq: return
	TIudyhxqkrCzJK96fsEU0FVLc = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not KQABSErcIo:
		if not jH5UCJQ4v7VPwqlmYy0XRcALzWn:
			if   '_M3U-LIVE_' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[1]
			elif '_M3U-MOVIES' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[2]
			elif '_M3U-SERIES' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[3]
			else: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[0]
		else:
			lp6gNAIhVwxP7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			IXT3PBU82c54ekwMFZhQKy9t0d7ROb = sSOy1pju5PJ('أختر البحث المناسب', lp6gNAIhVwxP7)
			if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==-1: return
			KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[IXT3PBU82c54ekwMFZhQKy9t0d7ROb]
	NkA8uQ3zHaRq = NkA8uQ3zHaRq+'_NODIALOGS_'
	if kQ3iPAjXHKCWe: ZTwXKRtB3his2CdopeF40ULn(NkA8uQ3zHaRq,kQ3iPAjXHKCWe,KQABSErcIo,iir30yaXElzYc7KC9uPNbo)
	else:
		for kQ3iPAjXHKCWe in range(1,U1UsphAegPmDYZXfTW+1):
			ZTwXKRtB3his2CdopeF40ULn(NkA8uQ3zHaRq,str(kQ3iPAjXHKCWe),KQABSErcIo,iir30yaXElzYc7KC9uPNbo)
		a26IqBkAXRPrwCOgFDb[:] = sorted(a26IqBkAXRPrwCOgFDb,reverse=False,key=lambda HHhysw8NOZj3: HHhysw8NOZj3[1].lower())
	return
def ZTwXKRtB3his2CdopeF40ULn(BJvPC1LuWZUEobzfdqQAcXkxGSRF,kQ3iPAjXHKCWe,KQABSErcIo='',iir30yaXElzYc7KC9uPNbo=''):
	if not iir30yaXElzYc7KC9uPNbo: iir30yaXElzYc7KC9uPNbo = '1'
	NkA8uQ3zHaRq,qpXBSH0v2uyR7lEiIftkeKYMcCD,jH5UCJQ4v7VPwqlmYy0XRcALzWn = o0Vixfg9ANze1OshdmaX(BJvPC1LuWZUEobzfdqQAcXkxGSRF)
	if not kQ3iPAjXHKCWe: return
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn): return
	if not NkA8uQ3zHaRq:
		NkA8uQ3zHaRq = NWs7KpjXGnxYylofHtd5U3wDh()
		if not NkA8uQ3zHaRq: return
	TIudyhxqkrCzJK96fsEU0FVLc = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not KQABSErcIo:
		if not jH5UCJQ4v7VPwqlmYy0XRcALzWn:
			if   '_M3U-LIVE_' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[1]
			elif '_M3U-MOVIES' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[2]
			elif '_M3U-SERIES' in qpXBSH0v2uyR7lEiIftkeKYMcCD: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[3]
			else: KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[0]
		else:
			lp6gNAIhVwxP7 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			IXT3PBU82c54ekwMFZhQKy9t0d7ROb = sSOy1pju5PJ('أختر البحث المناسب', lp6gNAIhVwxP7)
			if IXT3PBU82c54ekwMFZhQKy9t0d7ROb==-1: return
			KQABSErcIo = TIudyhxqkrCzJK96fsEU0FVLc[IXT3PBU82c54ekwMFZhQKy9t0d7ROb]
	QlZtxnJ50y7 = NkA8uQ3zHaRq.lower()
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'SEARCH')
	XVFsOLPmZiK0zN1bkr5 = IBxvzdjXCgS(uuamKczE4h8,'list','SEARCH',(KQABSErcIo,QlZtxnJ50y7))
	if not XVFsOLPmZiK0zN1bkr5:
		YfNwrndeZiy0MXK,YgtN4HGU7RBdVmuejZ3wznKIS = [],[]
		if not KQABSErcIo: aYxCiTkr1nOsZbvfWlMep = [1,2,3,4,5]
		else: aYxCiTkr1nOsZbvfWlMep = [TIudyhxqkrCzJK96fsEU0FVLc.index(KQABSErcIo)]
		for hU3gvdkbXl5HVAYecR6sJGyB in aYxCiTkr1nOsZbvfWlMep:
			if hU3gvdkbXl5HVAYecR6sJGyB!=3:
				mN1F4bAGHlUzjRQV2p = IBxvzdjXCgS(uuamKczE4h8,'dict',TIudyhxqkrCzJK96fsEU0FVLc[hU3gvdkbXl5HVAYecR6sJGyB])
				del mN1F4bAGHlUzjRQV2p['__COUNT__']
				del mN1F4bAGHlUzjRQV2p['__GROUPS__']
				del mN1F4bAGHlUzjRQV2p['__SEQUENCED_COLUMNS__']
				Q2z0ELKMtdk = list(mN1F4bAGHlUzjRQV2p.keys())
				for yyp5uq1HZTWwmtd in Q2z0ELKMtdk:
					for c60Epz1qjmHiKMl9BY,co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu in mN1F4bAGHlUzjRQV2p[yyp5uq1HZTWwmtd]:
						if QlZtxnJ50y7 in co7xPMVtuYQvy.lower(): YgtN4HGU7RBdVmuejZ3wznKIS.append((co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu))
					del mN1F4bAGHlUzjRQV2p[yyp5uq1HZTWwmtd]
				del mN1F4bAGHlUzjRQV2p
			else: Q2z0ELKMtdk = IBxvzdjXCgS(uuamKczE4h8,'list',TIudyhxqkrCzJK96fsEU0FVLc[hU3gvdkbXl5HVAYecR6sJGyB],'__GROUPS__')
			for yyp5uq1HZTWwmtd in Q2z0ELKMtdk:
				try: yyp5uq1HZTWwmtd,pwm2PdsA5cTagHOeCu = yyp5uq1HZTWwmtd
				except: pwm2PdsA5cTagHOeCu = ''
				if QlZtxnJ50y7 in yyp5uq1HZTWwmtd.lower():
					if hU3gvdkbXl5HVAYecR6sJGyB!=3: DUbgsG285dxKY3l0aJEVO = yyp5uq1HZTWwmtd
					else:
						E4Z75aL3XmrzOKywCGfIQxF1JonTpA,kAZjmxSCUXVw = yyp5uq1HZTWwmtd.split('__SERIES__')
						if QlZtxnJ50y7 in E4Z75aL3XmrzOKywCGfIQxF1JonTpA.lower(): DUbgsG285dxKY3l0aJEVO = E4Z75aL3XmrzOKywCGfIQxF1JonTpA
						else: DUbgsG285dxKY3l0aJEVO = kAZjmxSCUXVw
					YfNwrndeZiy0MXK.append((yyp5uq1HZTWwmtd,DUbgsG285dxKY3l0aJEVO,TIudyhxqkrCzJK96fsEU0FVLc[hU3gvdkbXl5HVAYecR6sJGyB],pwm2PdsA5cTagHOeCu))
			del Q2z0ELKMtdk
		YfNwrndeZiy0MXK = set(YfNwrndeZiy0MXK)
		YgtN4HGU7RBdVmuejZ3wznKIS = set(YgtN4HGU7RBdVmuejZ3wznKIS)
		YfNwrndeZiy0MXK = sorted(YfNwrndeZiy0MXK,reverse=False,key=lambda HHhysw8NOZj3: HHhysw8NOZj3[1])
		YgtN4HGU7RBdVmuejZ3wznKIS = sorted(YgtN4HGU7RBdVmuejZ3wznKIS,reverse=False,key=lambda HHhysw8NOZj3: HHhysw8NOZj3[0])
		rrz7vWj1sdwU0qa(uuamKczE4h8,'SEARCH',(KQABSErcIo,QlZtxnJ50y7),(YfNwrndeZiy0MXK,YgtN4HGU7RBdVmuejZ3wznKIS),U6y1OBwzfkEuRGVNrpYFv)
	else: YfNwrndeZiy0MXK,YgtN4HGU7RBdVmuejZ3wznKIS = XVFsOLPmZiK0zN1bkr5
	Q2z0ELKMtdk = len(YfNwrndeZiy0MXK)
	jvmw3ANPhFHDS8ELQrzp = len(YgtN4HGU7RBdVmuejZ3wznKIS)
	Fa9EIfiBzwm13QhVUr = int(iir30yaXElzYc7KC9uPNbo)
	r3WBuctKmQ6PR = max(0,(Fa9EIfiBzwm13QhVUr-1)*100)
	dwOhkbJ36Q2nDVEFz9slUX = max(0,Fa9EIfiBzwm13QhVUr*100)
	NnDz67REI8qrQtOlM50Ape23Gsf1jd = max(0,r3WBuctKmQ6PR-Q2z0ELKMtdk)
	LJpglTKd2cnoVubtEr5W = max(0,dwOhkbJ36Q2nDVEFz9slUX-Q2z0ELKMtdk)
	for yyp5uq1HZTWwmtd,DUbgsG285dxKY3l0aJEVO,ssijAtUkpCluYaoQnK7w9qrH3TXWJ,pwm2PdsA5cTagHOeCu in YfNwrndeZiy0MXK[r3WBuctKmQ6PR:dwOhkbJ36Q2nDVEFz9slUX]:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+DUbgsG285dxKY3l0aJEVO,ssijAtUkpCluYaoQnK7w9qrH3TXWJ,714,pwm2PdsA5cTagHOeCu,'1',yyp5uq1HZTWwmtd,'',{'folder':kQ3iPAjXHKCWe})
	del YfNwrndeZiy0MXK
	for co7xPMVtuYQvy,HHPwg71GEVju,pwm2PdsA5cTagHOeCu in YgtN4HGU7RBdVmuejZ3wznKIS[NnDz67REI8qrQtOlM50Ape23Gsf1jd:LJpglTKd2cnoVubtEr5W]:
		usN4FOfhKWaHrELSR3Zd89p6ozgG7 = WFNUBRjloE1(HHPwg71GEVju)
		ga4p3IxqUXMjTRPQZfH9J5E = 'live'
		if '.mkv' in usN4FOfhKWaHrELSR3Zd89p6ozgG7 or 'VOD' in KQABSErcIo: ga4p3IxqUXMjTRPQZfH9J5E = 'video'
		QQmLIZC8uas9fNiJWOnhdGvgFR(ga4p3IxqUXMjTRPQZfH9J5E,I5ZiQhtuXSmd96BNLoPwGU+co7xPMVtuYQvy,HHPwg71GEVju,715,pwm2PdsA5cTagHOeCu,'','','',{'folder':kQ3iPAjXHKCWe})
	del YgtN4HGU7RBdVmuejZ3wznKIS
	L1JqTz6nCfBjGP3SWAmd(kQ3iPAjXHKCWe,iir30yaXElzYc7KC9uPNbo,KQABSErcIo,719,Q2z0ELKMtdk+jvmw3ANPhFHDS8ELQrzp,NkA8uQ3zHaRq+'_NODIALOGS_')
	return
def L1JqTz6nCfBjGP3SWAmd(kQ3iPAjXHKCWe,iir30yaXElzYc7KC9uPNbo,KQABSErcIo,EHnSrqQ7BvmGlOgYZdhTbCRtswA,GZtThAxePiQJuwmdN2K0Rcj6VWbk,yv8XxUjorzB2CRA4Jife73VMklHp):
	if not iir30yaXElzYc7KC9uPNbo: iir30yaXElzYc7KC9uPNbo = '1'
	if iir30yaXElzYc7KC9uPNbo!='1': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'صفحة '+str(1),KQABSErcIo,EHnSrqQ7BvmGlOgYZdhTbCRtswA,'',str(1),yv8XxUjorzB2CRA4Jife73VMklHp,'',{'folder':kQ3iPAjXHKCWe})
	if not GZtThAxePiQJuwmdN2K0Rcj6VWbk: GZtThAxePiQJuwmdN2K0Rcj6VWbk = 0
	AZjdK2qfV9wlNIceG1WQrS = int(GZtThAxePiQJuwmdN2K0Rcj6VWbk/100)+1
	for Fa9EIfiBzwm13QhVUr in range(2,AZjdK2qfV9wlNIceG1WQrS):
		eiHbE4TXr0JRYfakFQot6AZhOG = (Fa9EIfiBzwm13QhVUr%10==0 or int(iir30yaXElzYc7KC9uPNbo)-4<Fa9EIfiBzwm13QhVUr<int(iir30yaXElzYc7KC9uPNbo)+4)
		aUJ0GnB7TDv = (eiHbE4TXr0JRYfakFQot6AZhOG and int(iir30yaXElzYc7KC9uPNbo)-40<Fa9EIfiBzwm13QhVUr<int(iir30yaXElzYc7KC9uPNbo)+40)
		if str(Fa9EIfiBzwm13QhVUr)!=iir30yaXElzYc7KC9uPNbo and (Fa9EIfiBzwm13QhVUr%100==0 or aUJ0GnB7TDv):
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'صفحة '+str(Fa9EIfiBzwm13QhVUr),KQABSErcIo,EHnSrqQ7BvmGlOgYZdhTbCRtswA,'',str(Fa9EIfiBzwm13QhVUr),yv8XxUjorzB2CRA4Jife73VMklHp,'',{'folder':kQ3iPAjXHKCWe})
	if str(AZjdK2qfV9wlNIceG1WQrS)!=iir30yaXElzYc7KC9uPNbo: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',I5ZiQhtuXSmd96BNLoPwGU+'أخر صفحة '+str(AZjdK2qfV9wlNIceG1WQrS),KQABSErcIo,EHnSrqQ7BvmGlOgYZdhTbCRtswA,'',str(AZjdK2qfV9wlNIceG1WQrS),yv8XxUjorzB2CRA4Jife73VMklHp,'',{'folder':kQ3iPAjXHKCWe})
	return
def CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,KQABSErcIo):
	uuamKczE4h8 = kzp9ocjCYM1wQaldAtGNvIL.replace('___','_'+kQ3iPAjXHKCWe)
	return uuamKczE4h8
def tQ1EyGcl0Su(kQ3iPAjXHKCWe):
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'')
	eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if eZId7XMDvV6Jno938!=1: return False
	iisQZamj86E7vSD5(kQ3iPAjXHKCWe,False)
	iKjvR0IuEUHWaLPbm75qkS = [0]
	for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
		TW26SLGEVMArza9DRfOYx3ydHm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.url_'+kQ3iPAjXHKCWe+'_'+str(g80O9QtN6lbRcPiu))
		if TW26SLGEVMArza9DRfOYx3ydHm: H8AO0LqXf4DVbPyM(kQ3iPAjXHKCWe,str(g80O9QtN6lbRcPiu))
		iKjvR0IuEUHWaLPbm75qkS.append(0)
	for KQABSErcIo in MENHxhV1f6JI3o2pO54D9gbuyGakiT:
		V726OmWUeRGBtg,ela10qRZXPB9LkV,q6W7fTPUz8vAcd3,tSlJDWaCsv0qTnGzKR,egsHmhoJvAIFQqft7aNMW2Vl91d = 0,{},[],[],[]
		for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
			ssijAtUkpCluYaoQnK7w9qrH3TXWJ = KQABSErcIo+'_'+str(g80O9QtN6lbRcPiu)
			PYh6gqjxsunUBtc2zyJ3Ve = IBxvzdjXCgS(uuamKczE4h8,'dict',ssijAtUkpCluYaoQnK7w9qrH3TXWJ)
			try:
				QHszEGxlDBrPFV045WkhTq = PYh6gqjxsunUBtc2zyJ3Ve['__GROUPS__']
				llCODaWngtvoGQsmq = PYh6gqjxsunUBtc2zyJ3Ve['__COUNT__']
			except: QHszEGxlDBrPFV045WkhTq,llCODaWngtvoGQsmq = [],'0'
			for eUOjWh1RCXl2ztscpuiy8E in QHszEGxlDBrPFV045WkhTq:
				yyp5uq1HZTWwmtd,rHC4l56cOGQ9sX0Mj = eUOjWh1RCXl2ztscpuiy8E
				mN1F4bAGHlUzjRQV2p = PYh6gqjxsunUBtc2zyJ3Ve[yyp5uq1HZTWwmtd]
				if yyp5uq1HZTWwmtd not in tSlJDWaCsv0qTnGzKR:
					tSlJDWaCsv0qTnGzKR.append(yyp5uq1HZTWwmtd)
					egsHmhoJvAIFQqft7aNMW2Vl91d.append(eUOjWh1RCXl2ztscpuiy8E)
					ela10qRZXPB9LkV[yyp5uq1HZTWwmtd] = []
				ela10qRZXPB9LkV[yyp5uq1HZTWwmtd] += mN1F4bAGHlUzjRQV2p
			Nmkj7L5VEo(uuamKczE4h8,ssijAtUkpCluYaoQnK7w9qrH3TXWJ)
			rrz7vWj1sdwU0qa(uuamKczE4h8,ssijAtUkpCluYaoQnK7w9qrH3TXWJ,'__COUNT__',llCODaWngtvoGQsmq,U6y1OBwzfkEuRGVNrpYFv)
			iKjvR0IuEUHWaLPbm75qkS[g80O9QtN6lbRcPiu] += int(llCODaWngtvoGQsmq)
		for yyp5uq1HZTWwmtd in tSlJDWaCsv0qTnGzKR:
			mN1F4bAGHlUzjRQV2p = list(set(ela10qRZXPB9LkV[yyp5uq1HZTWwmtd]))
			if 'SORTED' in KQABSErcIo: mN1F4bAGHlUzjRQV2p = sorted(mN1F4bAGHlUzjRQV2p,reverse=False,key=lambda key: key[1].lower())
			V726OmWUeRGBtg += len(mN1F4bAGHlUzjRQV2p)
			q6W7fTPUz8vAcd3.append(mN1F4bAGHlUzjRQV2p)
		rrz7vWj1sdwU0qa(uuamKczE4h8,KQABSErcIo,'__COUNT__',str(V726OmWUeRGBtg),U6y1OBwzfkEuRGVNrpYFv)
		rrz7vWj1sdwU0qa(uuamKczE4h8,KQABSErcIo,'__GROUPS__',egsHmhoJvAIFQqft7aNMW2Vl91d,U6y1OBwzfkEuRGVNrpYFv)
		rrz7vWj1sdwU0qa(uuamKczE4h8,KQABSErcIo,tSlJDWaCsv0qTnGzKR,q6W7fTPUz8vAcd3,U6y1OBwzfkEuRGVNrpYFv,True)
	pb9RW5n23BsdAJgcuD = False
	for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
		if int(iKjvR0IuEUHWaLPbm75qkS[g80O9QtN6lbRcPiu])>0:
			TW26SLGEVMArza9DRfOYx3ydHm = YTPut68WBVUNCvsEzg.getSetting('av.m3u.url_'+kQ3iPAjXHKCWe+'_'+str(g80O9QtN6lbRcPiu))
			rrz7vWj1sdwU0qa(uuamKczE4h8,'LINK_'+str(g80O9QtN6lbRcPiu),'__LINK__',TW26SLGEVMArza9DRfOYx3ydHm,U6y1OBwzfkEuRGVNrpYFv)
			pb9RW5n23BsdAJgcuD = True
	rrz7vWj1sdwU0qa(uuamKczE4h8,'DUMMY','__DUMMY__','DUMMY',U6y1OBwzfkEuRGVNrpYFv)
	if not pb9RW5n23BsdAJgcuD:
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	wqfTenDyNSmc1bO2aAJQWpERCIX3K(kQ3iPAjXHKCWe)
	EO9Rts0AaGuk1qpPLXCY.executebuiltin('Container.Refresh')
	return True
def wqfTenDyNSmc1bO2aAJQWpERCIX3K(kQ3iPAjXHKCWe):
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'')
	if not TPcrCe0UH6JVdMgSLxuQvX7R4(kQ3iPAjXHKCWe,True): return
	for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
		TW26SLGEVMArza9DRfOYx3ydHm = IBxvzdjXCgS(uuamKczE4h8,'str','LINK_'+str(g80O9QtN6lbRcPiu),'__LINK__')
		if TW26SLGEVMArza9DRfOYx3ydHm: zhP5E6nZl2i8ICGNwxXpgqHfjbW = li20yx4pHT6bqBdk(kQ3iPAjXHKCWe,str(g80O9QtN6lbRcPiu))
	li20yx4pHT6bqBdk(kQ3iPAjXHKCWe,'')
	return
def iisQZamj86E7vSD5(kQ3iPAjXHKCWe,jH5UCJQ4v7VPwqlmYy0XRcALzWn):
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn:
		eZId7XMDvV6Jno938 = KGEAmiZ9Jq0sTXR('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if eZId7XMDvV6Jno938!=1: return
	uuamKczE4h8 = CBzpaugA80bq3sxe24(kQ3iPAjXHKCWe,'')
	try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(uuamKczE4h8)
	except: pass
	for g80O9QtN6lbRcPiu in range(1,ddskb1JG9RjTK0wzAo5VEhZXFHc6+1):
		CG0rXeItomMwO3vjcFslKSYT = vHYUae4cO1XlpwWIziyCdA6Q.replace('___','_'+kQ3iPAjXHKCWe+'_'+str(g80O9QtN6lbRcPiu))
		lNRuWhJ3dyKTjU = isWjwHOERYXhAp0ZuNdKUgkCM7.path.join(jNhH3xrnWkFUqv8c09OybXRTl,CG0rXeItomMwO3vjcFslKSYT)
		try: isWjwHOERYXhAp0ZuNdKUgkCM7.remove(lNRuWhJ3dyKTjU)
		except: pass
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_'+kQ3iPAjXHKCWe)
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if jH5UCJQ4v7VPwqlmYy0XRcALzWn:
		KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		EO9Rts0AaGuk1qpPLXCY.executebuiltin('Container.Refresh')
	return
def o3YHAGiLSK5P7ts(kQ3iPAjXHKCWe):
	BTnmD1GqVNWIKORFx7ulfoQ46Mhtg = YTPut68WBVUNCvsEzg.getSetting('av.language.provider')
	WkrPZXjHD9oQRtOV = YTPut68WBVUNCvsEzg.getSetting('av.language.code')
	Nmkj7L5VEo(ttbwouYhASpBDJiHZEaLkegM3G,'MENUS_CACHE_'+BTnmD1GqVNWIKORFx7ulfoQ46Mhtg+'_'+WkrPZXjHD9oQRtOV,'%_MU'+kQ3iPAjXHKCWe+'_%')
	return
g75rFuoTNzjnq4bp = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
# -*- coding: utf-8 -*-
import sys as CJwTBit4NPQMu
p9G4Y7QXMxPo = CJwTBit4NPQMu.version_info [0] == 2
U5nirbtq9G7yLoflBFYQxH4 = 2048
SiFQbkzTDpfgRYerH6xnOhV7vL = 7
def vd8MGxLk9r (JJVmUHl0wc6Lk):
	global Fxej9TzNucgMXQ0RS3
	POEVj4790UW5JIxnmZ = ord (JJVmUHl0wc6Lk [-1])
	NS7fTK2l4IsivGn8PWH1OgYcQw = JJVmUHl0wc6Lk [:-1]
	kR3rX7Z2Y4OwDA0s = POEVj4790UW5JIxnmZ % len (NS7fTK2l4IsivGn8PWH1OgYcQw)
	qq9xWcDkNlHtU52bjnK1s = NS7fTK2l4IsivGn8PWH1OgYcQw [:kR3rX7Z2Y4OwDA0s] + NS7fTK2l4IsivGn8PWH1OgYcQw [kR3rX7Z2Y4OwDA0s:]
	if p9G4Y7QXMxPo:
		tx5NhQiu29SO47ljn0YH = unicode () .join ([unichr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	else:
		tx5NhQiu29SO47ljn0YH = str () .join ([chr (ord (mzHRBGSbPLlEdcjx60uat) - U5nirbtq9G7yLoflBFYQxH4 - (h3UDz7LQ1So9M2O5qtN + POEVj4790UW5JIxnmZ) % SiFQbkzTDpfgRYerH6xnOhV7vL) for h3UDz7LQ1So9M2O5qtN, mzHRBGSbPLlEdcjx60uat in enumerate (qq9xWcDkNlHtU52bjnK1s)])
	return eval (tx5NhQiu29SO47ljn0YH)
WmaPChRdQk3YcXwI6zS,cbngtp9sqYi0DjeEMLRHJruKxm,BWh0PmauYpSA9JHxnGV6O8KFc3q=vd8MGxLk9r,vd8MGxLk9r,vd8MGxLk9r
S870SR2MoAIgLxzbpFDeKH9XmiZQ3,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,weC96SDJHrtoaGEKO2zPsAYmbZgN1=BWh0PmauYpSA9JHxnGV6O8KFc3q,cbngtp9sqYi0DjeEMLRHJruKxm,WmaPChRdQk3YcXwI6zS
HVibA2ES8lY,h5huy6MiXPNfQJF8,PiFkQ5pCJy7fbX=weC96SDJHrtoaGEKO2zPsAYmbZgN1,WYx8H7qCz1glKj6RrFuAyUGo93DPhE,S870SR2MoAIgLxzbpFDeKH9XmiZQ3
mNkfJnpOrad7hT6PYyciwsSDQ,TWexH5PhS1,FIHNSc5iuoZanQ2Ytl=PiFkQ5pCJy7fbX,h5huy6MiXPNfQJF8,HVibA2ES8lY
VOq8Ekue4F,uneTx8rbQsJE7KR5Okq0l6dU3V29N,g1gqKebNPOTGxi68cEoIwH30tpJvZ=FIHNSc5iuoZanQ2Ytl,TWexH5PhS1,mNkfJnpOrad7hT6PYyciwsSDQ
EmK3ObA0cwv9Wy,VH9MDo5z1kxNF07uRJI,vatyjK4hHAoZJ7rOq2lis=g1gqKebNPOTGxi68cEoIwH30tpJvZ,uneTx8rbQsJE7KR5Okq0l6dU3V29N,VOq8Ekue4F
Xl3drKyI9HkDiPEf8RTjwu,ttOu147wErcBvPaSMUY,EEvLoMzFqrlKce=vatyjK4hHAoZJ7rOq2lis,VH9MDo5z1kxNF07uRJI,EmK3ObA0cwv9Wy
HH4JMrUDp3lq6hQ,N9olEh0ZMtpOivVfBLK,ZEiR0StquOzca9lvPAndYIX=EEvLoMzFqrlKce,ttOu147wErcBvPaSMUY,Xl3drKyI9HkDiPEf8RTjwu
f5uqIoSJzWBOFyrY78RXmVb,N0Kvne8UYar9fhRxboWsXJCVzid,vNasL0yiB2AdPgZSlRcmJ6xnjI=ZEiR0StquOzca9lvPAndYIX,N9olEh0ZMtpOivVfBLK,HH4JMrUDp3lq6hQ
QR0w9rgDN3d8ZMcaveXhSJB2EAViy,oAXJCYqPgyGDtT,sDiKwnHcSlYFgWCy1Ak=vNasL0yiB2AdPgZSlRcmJ6xnjI,N0Kvne8UYar9fhRxboWsXJCVzid,f5uqIoSJzWBOFyrY78RXmVb
sbgu4D2RFMYKm,ZhqJoOtcmTVID65HwnLj,l5mQdjWyczr7UJVnTp=sDiKwnHcSlYFgWCy1Ak,oAXJCYqPgyGDtT,QR0w9rgDN3d8ZMcaveXhSJB2EAViy
from skIgoAvZ9t import *
fYPz7RldWQVHBktZAexwvCL8Np3D(f5uqIoSJzWBOFyrY78RXmVb(u"࠭ࡔࡆࡕࡗࠫૡ"),sbgu4D2RFMYKm(u"ࠧࡕࡇࡖࡘࠬૢ"))
WLmJboYtCkPlF3 = vNasL0yiB2AdPgZSlRcmJ6xnjI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡺ࠹࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡶ࡫࡭ࡳࡱࡢࡳࡱࡤࡨࡧࡧ࡮ࡥ࠰ࡦࡳࡲ࠵࠱࠱ࡏࡅ࠲ࡿ࡯ࡰࠨૣ")
WLmJboYtCkPlF3 = sbgu4D2RFMYKm(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴࡪ࡫ࡤࡵࡧࡶࡸ࠳࡬ࡴࡱ࠰ࡲࡸࡪࡴࡥࡵ࠰ࡪࡶ࠴࡬ࡩ࡭ࡧࡶ࠳ࡹ࡫ࡳࡵ࠳࠳࠴ࡰ࠴ࡤࡣࠩ૤")
de5ZW2bFQ64CPgG(WLmJboYtCkPlF3,{},vatyjK4hHAoZJ7rOq2lis(u"࡙ࡸࡵࡦ૧"))
HHPwg71GEVju = h5huy6MiXPNfQJF8(u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡ็อึ࠰ࡰࡴ࠸࠭૥")
HHPwg71GEVju = ZhqJoOtcmTVID65HwnLj(u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢࡦࡪ࡮ࡨࡣ࠹࠾࠳࠵ࡡࡖࡌ࡛ࡥา๋ษิอࡤอไาี๋่ࡤอไฤ฻฻้ࡤ࠮ีࠪࡡࠫวออะาࡡส่า๊่ศฮํ࠭࠳ࡳࡰ࠴ࠩ૦")
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'FAJERSHOW'
JJCLnkX4TozH7Bsjivfe = '_FJS_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==390: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==391: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==392: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==393: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==399: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',399,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','FAJERSHOW-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('<header>.*?<h2>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for F1FBMcYyaNIJ in range(len(items)):
		title = items[F1FBMcYyaNIJ]
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,HbiLZQKalC,391,'','','latest'+str(F1FBMcYyaNIJ))
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مختارات عشوائية',HbiLZQKalC,391,'','','randoms')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أعلى الأفلام تقييماً',HbiLZQKalC,391,'','','top_imdb_movies')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أعلى المسلسلات تقييماً',HbiLZQKalC,391,'','','top_imdb_series')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أفلام مميزة',HbiLZQKalC+'/movies',391,'','','featured_movies')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات مميزة',HbiLZQKalC+'/tvshows',391,'','','featured_tvshows')
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = ''
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="menu"(.*?)id="contenedor"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR += tmEVko4qsghUX6WLx8KG7fOTB[0]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC+'/movies','','','','','FAJERSHOW-MENU-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="releases"(.*?)aside',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR += tmEVko4qsghUX6WLx8KG7fOTB[0]
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	ye8iWwASlpUFt = True
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = Nkuqp0boKj41i9(title)
		if title=='الأعلى مشاهدة':
			if ye8iWwASlpUFt:
				title = 'الافلام '+title
				ye8iWwASlpUFt = False
			else: title = 'المسلسلات '+title
		if title not in OZYvGX7EMx05KH1fI:
			if title=='أفلام': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,HbiLZQKalC+'/movies',391,'','','all_movies_tvshows')
			elif title=='مسلسلات': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,HbiLZQKalC+'/tvshows',391,'','','all_movies_tvshows')
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,391)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,type):
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR,items = [],[]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FAJERSHOW-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if type in ['featured_movies','featured_tvshows']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="content"(.*?)id="archive-content"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	elif type=='all_movies_tvshows':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="archive-content"(.*?)class="pagination"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	elif type=='top_imdb_movies':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='top_imdb_series':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("class='top-imdb-list tright(.*?)footer",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='search':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="search-page"(.*?)class="sidebar',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif type=='sider':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="widget(.*?)class="widget',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		EvepJ1lSmD = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		M7oS6tLhdx3ke8qPX4mFA,jxEQ2Yd01g9MSuDVJ,n7CuHMSJpiR9fP0jvNEIyDUL = zip(*EvepJ1lSmD)
		items = zip(jxEQ2Yd01g9MSuDVJ,M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL)
	elif type=='randoms':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="slider-movies-tvshows"(.*?)<header>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	elif 'latest' in type:
		F1FBMcYyaNIJ = int(type[-1:])
		qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('<header>','<end><start>')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = qQXuaKpVrGLF3e5oidJ8YwDT0.replace('</div></div></div>','</div></div></div><end>')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<start>(.*?)<end>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[F1FBMcYyaNIJ]
		if F1FBMcYyaNIJ==6:
			EvepJ1lSmD = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			jxEQ2Yd01g9MSuDVJ,n7CuHMSJpiR9fP0jvNEIyDUL,M7oS6tLhdx3ke8qPX4mFA = zip(*EvepJ1lSmD)
			items = zip(jxEQ2Yd01g9MSuDVJ,M7oS6tLhdx3ke8qPX4mFA,n7CuHMSJpiR9fP0jvNEIyDUL)
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="content"(.*?)class="(pagination|sidebar)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
			if '/collection/' in url:
				items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			elif '/quality/' in url:
				items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	if not items and Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
		items = T072lCzjYiuaeFtmJGV.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = T072lCzjYiuaeFtmJGV.findall('^(.*?)<.*?serie">(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
			title = title[0][1]
			if title in BBRwQhFnJ08q9YVxOSya: continue
			BBRwQhFnJ08q9YVxOSya.append(title)
			title = '_MOD_'+title
		tKBSN4Zgn9CDb = T072lCzjYiuaeFtmJGV.findall('^(.*?)<',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if tKBSN4Zgn9CDb: title = tKBSN4Zgn9CDb[0]
		title = Nkuqp0boKj41i9(title)
		if '/tvshows/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,393,o3gHuBtrRN)
		elif '/episodes/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,393,o3gHuBtrRN)
		elif '/seasons/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,393,o3gHuBtrRN)
		elif '/collection/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,391,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,392,o3gHuBtrRN)
	if type not in ['featured_movies','featured_tvshows']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,391,'','',type)
	return
def UAB8vizclM6XG4Pw(url):
	dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	url = url.replace(dATnilvcrXxmZ1k5EP0KgBFDqYpy6,HbiLZQKalC)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','FAJERSHOW-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('class="C rated".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<ul class="episodios">(.*?)</ul></div></div></div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,392,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = GPdwgNOcx9SLTD2(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','FAJERSHOW-PLAY-1st')
	Y9xGJcRLIBNOftSQ5HE1jTysl = T072lCzjYiuaeFtmJGV.findall('class="C rated".*?>(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if Y9xGJcRLIBNOftSQ5HE1jTysl and j06m14qSVXJR8o3pBtdv9YzgAn(nO6ukabcldeU,url,Y9xGJcRLIBNOftSQ5HE1jTysl): return
	M7oS6tLhdx3ke8qPX4mFA = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0][0]
		items = T072lCzjYiuaeFtmJGV.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for type,fE9lhXGsySY5kH2CQ,ILCfGJgwTMDK9dkmoZFYxeR1unpr,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+fE9lhXGsySY5kH2CQ+'&nume='+ILCfGJgwTMDK9dkmoZFYxeR1unpr+'&type='+type
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,Q5OAspyiXV1lx8930qLGD,epouLG68wMUYWC91aRhKmn4xA in items:
			if '=' in o3gHuBtrRN:
				a7HWcL08nC1q2JMPYIKkv4epXUSyf = o3gHuBtrRN.split('=')[1]
				title = ClNwy8MJfjoTq4ZFxYvmasD(a7HWcL08nC1q2JMPYIKkv4epXUSyf,'host')
			else: title = ''
			title = epouLG68wMUYWC91aRhKmn4xA+' '+title
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download____'+Q5OAspyiXV1lx8930qLGD
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'search')
	return
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'ARABICTOONS'
JJCLnkX4TozH7Bsjivfe = '_ART_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==730: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==731: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==732: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==733: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==734: cLCisPE3lX = TRsNVwEifK(url)
	elif mode==735: cLCisPE3lX = ZCgAi129DF43PonVJu8flQWySkvd(url)
	elif mode==739: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات مميزة',HbiLZQKalC+'/top.php',735)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات',HbiLZQKalC+'/cartoon.php',734)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'افلام',HbiLZQKalC+'/movies.php',731)
	return
def TRsNVwEifK(url):
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الكل',url,731)
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('label="navigation"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall("href='(.*?)'>(.*?)</a>",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = 'حرف '+title
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,731)
	return
def ZCgAi129DF43PonVJu8flQWySkvd(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="slider"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
			title = title.strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,733,o3gHuBtrRN)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("class='moviesBlocks(.*?)navigation",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
		title = title.strip(' ')
		if 'movies.php' in url: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,732,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,733,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[-1]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title.strip(' ')
			title = Nkuqp0boKj41i9(title)
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,731)
	return
def UAB8vizclM6XG4Pw(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("class='moviesBlocks(.*?)script",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,CAg0pwIrLonlxtJkThQqSX3 in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
			title = title.strip(' ')
			title = title+' '+CAg0pwIrLonlxtJkThQqSX3.strip(' ')
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,732,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	MfIDplCLUGK91vjO = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('source src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if kkH5sRPxhASFowLONy4:
		i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[0]
		if 'Referer=' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'|Referer=https://www.arabic-toons.com'
		MfIDplCLUGK91vjO.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named=__embed')
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(MfIDplCLUGK91vjO,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','%20')
	M7oS6tLhdx3ke8qPX4mFA = ['','m']
	FOqwn36QHCgpI8SXRNT1P2mdE = ['مسلسلات','افلام']
	if showDialogs:
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('اختر النوع المطلوب:', FOqwn36QHCgpI8SXRNT1P2mdE)
		if tzgWIKy5xQL2kjm==-1: return
	else: tzgWIKy5xQL2kjm = 0
	type = M7oS6tLhdx3ke8qPX4mFA[tzgWIKy5xQL2kjm]
	url = HbiLZQKalC+'/livesearch.php?'+type+'&q='+search
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		title = title.strip(' ')
		if type=='m': QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,732)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,733)
	return
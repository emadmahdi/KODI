# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SHOOFPRO'
JJCLnkX4TozH7Bsjivfe = '_SHP_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['مصارعة','بث مباشر']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==480: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==481: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==482: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==483: cLCisPE3lX = UAB8vizclM6XG4Pw(url,text)
	elif mode==489: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text,url)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC,'','','','','SHOOFPRO-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	LL2d9tanw0mrxJBKAT63buD = LL2d9tanw0mrxJBKAT63buD[0].strip('/')
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(LL2d9tanw0mrxJBKAT63buD,'url')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع',LL2d9tanw0mrxJBKAT63buD,489,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'أحدث المواضيع',LL2d9tanw0mrxJBKAT63buD,481)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"navigation"(.*?)"myAccount"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</span>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if i8sFwPqo1vpEXR2VdHU5BmW=='#': continue
		if title in OZYvGX7EMx05KH1fI: continue
		title = Nkuqp0boKj41i9(title)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,481)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,qbQRfhdVyW8):
	items = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"post(.*?)"footer"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	uynilVkchUBZjwt = '/'.join(qbQRfhdVyW8.strip('/').split('/')[4:]).split('-')
	for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
		title = Nkuqp0boKj41i9(title)
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) حلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if qbQRfhdVyW8:
			K9K307bTvRVtO6i = '/'.join(i8sFwPqo1vpEXR2VdHU5BmW.strip('/').split('/')[4:]).split('-')
			bQaXMWJBiAsuSPdw = len([qa0fA26EyCoSkjKnrh for qa0fA26EyCoSkjKnrh in uynilVkchUBZjwt if qa0fA26EyCoSkjKnrh in K9K307bTvRVtO6i])
			if bQaXMWJBiAsuSPdw>2 and '/episodes/' in i8sFwPqo1vpEXR2VdHU5BmW:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,482,o3gHuBtrRN)
		else:
			if not XSCYbwaqRBtopUc9H2QZu86gA5N: XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if set(title.split()) & set(RNlnkarue2AW3Um8Q0) and 'مسلسل' not in title:
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,482,o3gHuBtrRN)
			elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'حلقة' in title:
				title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,483,o3gHuBtrRN,'',url)
					BBRwQhFnJ08q9YVxOSya.append(title)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,483,o3gHuBtrRN,'',url)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall("'pagination'(.*?)</div>",qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall("href='(.*?)'.*?>(.*?)</a>",Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = Nkuqp0boKj41i9(title)
			title = title.replace('الصفحة ','')
			if title!='': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,481,'','',qbQRfhdVyW8)
	return
def UAB8vizclM6XG4Pw(url,ll9khUfx3MjZ):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('"img-responsive" src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if o3gHuBtrRN: o3gHuBtrRN = o3gHuBtrRN[0]
	else: o3gHuBtrRN = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Thumb')
	xjv6X7tWPsIEghCBcQO = True
	GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"listSeasons(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC and '/ajax/seasons' not in url:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		count = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.count('data-slug=')
		if count==0: count = Zsh7mUdwjHobLyMz6WKJGVl1cgeR.count('data-season=')
		if count>1:
			xjv6X7tWPsIEghCBcQO = False
			if 'data-slug="' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
				items = T072lCzjYiuaeFtmJGV.findall('data-slug="(.*?)">(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for id,title in items:
					i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,483,o3gHuBtrRN)
			else:
				items = T072lCzjYiuaeFtmJGV.findall('data-season="(.*?)">(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for id,title in items:
					i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,483,o3gHuBtrRN)
	if xjv6X7tWPsIEghCBcQO:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = ''
		if '/ajax/seasons' in url: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
		else:
			q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"eplist"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
			if q9OCkWn6ruAvQLKDFUyxBME0: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)" title="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				title = title.strip(' ')
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,482,o3gHuBtrRN)
	if not a26IqBkAXRPrwCOgFDb: Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ,url)
	return
def JwYEQUDupG2WLPzHndc(url):
	ll9khUfx3MjZ = url.strip('/')+'/?do=watch'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','SHOOFPRO-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	M7oS6tLhdx3ke8qPX4mFA = []
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	CXUSgmQjGvJzKWYr7BckR2I = T072lCzjYiuaeFtmJGV.findall('vo_postID = "(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not CXUSgmQjGvJzKWYr7BckR2I: CXUSgmQjGvJzKWYr7BckR2I = T072lCzjYiuaeFtmJGV.findall('\(this\.id\,0\,(.*?)\)',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	CXUSgmQjGvJzKWYr7BckR2I = CXUSgmQjGvJzKWYr7BckR2I[0]
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"serversList"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('id="(.*?)".*?">(.*?)</li>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for RRQsVzCrc6iEqKlxFamo,title in items:
			title = title.strip(' ')
			i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+CXUSgmQjGvJzKWYr7BckR2I+'&video='+RRQsVzCrc6iEqKlxFamo[2:]+'?named='+title+'__watch'
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('"getEmbed".*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if i8sFwPqo1vpEXR2VdHU5BmW:
		title = ClNwy8MJfjoTq4ZFxYvmasD(i8sFwPqo1vpEXR2VdHU5BmW[0],'url')
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW[0]+'?named='+title+'__embed'
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	ll9khUfx3MjZ = url.strip('/')+'/?do=download'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','SHOOFPRO-PLAY-2nd')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"table-responsive"(.*?)</table>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<td>(.*?)</td>.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for title,i8sFwPqo1vpEXR2VdHU5BmW in items:
			title = title.strip(' ')
			if 'anavidz' in i8sFwPqo1vpEXR2VdHU5BmW: tKBSN4Zgn9CDb = '__خاص'
			else: tKBSN4Zgn9CDb = ''
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'+tKBSN4Zgn9CDb
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search,LL2d9tanw0mrxJBKAT63buD=''):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	if LL2d9tanw0mrxJBKAT63buD=='': LL2d9tanw0mrxJBKAT63buD = HbiLZQKalC
	url = LL2d9tanw0mrxJBKAT63buD+'/search/'+search+'/'
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,'')
	return
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SHAHID4U'
headers = ''
JJCLnkX4TozH7Bsjivfe = '_SH4_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==110: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==111: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==112: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==113: cLCisPE3lX = UAB8vizclM6XG4Pw(url,True)
	elif mode==114: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'FULL_FILTER___'+text)
	elif mode==115: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'DEFINED_FILTER___'+text)
	elif mode==116: cLCisPE3lX = UAB8vizclM6XG4Pw(url,False)
	elif mode==119: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	LL2d9tanw0mrxJBKAT63buD,url,WM1buqXnzf3Ba6Vp29l4gFD = NJviWdaAUb(vZs8PpIdBUNQTjnbEymoYx6X,'GET',HbiLZQKalC,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',LL2d9tanw0mrxJBKAT63buD,115)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',LL2d9tanw0mrxJBKAT63buD,114)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'المميزة',LL2d9tanw0mrxJBKAT63buD,111,'','','featured')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('simple-filter(.*?)adv-filter',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB:
		KK47FGdX1TDfkb3AjHOQqghE('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for filter,o3gHuBtrRN,title in items:
			url = LL2d9tanw0mrxJBKAT63buD+filter
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,url,111,o3gHuBtrRN,'',filter)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="dropdown"(.*?)<script>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in OZYvGX7EMx05KH1fI: continue
			if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
			if 'netflix' in i8sFwPqo1vpEXR2VdHU5BmW: title = 'نيتفلكس'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,111)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,xQ7XawG9M3grVTo='',WM1buqXnzf3Ba6Vp29l4gFD=''):
	if not WM1buqXnzf3Ba6Vp29l4gFD: WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB,items,BBRwQhFnJ08q9YVxOSya = [],[],[]
	if xQ7XawG9M3grVTo=='featured': tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('glide__slides(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	else: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('shows-container(.*?)pagination',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not items: items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title in items:
		if 'javascript' in i8sFwPqo1vpEXR2VdHU5BmW: continue
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW).strip('/')
		title = Nkuqp0boKj41i9(title)
		title = title.strip(' ')
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if '/film/' in i8sFwPqo1vpEXR2VdHU5BmW or 'فيلم' in i8sFwPqo1vpEXR2VdHU5BmW or any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,112,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,113,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/actor/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,111,o3gHuBtrRN)
		elif '/series/' in i8sFwPqo1vpEXR2VdHU5BmW and '/list' not in url:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'/list'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,111,o3gHuBtrRN)
		elif '/list' in url and 'حلقة' in title:
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,112,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,113,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"pagination"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		if xQ7XawG9M3grVTo!='search': items = T072lCzjYiuaeFtmJGV.findall('(updateQuery).*?>(.+?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		else: items = T072lCzjYiuaeFtmJGV.findall('<li>.*?href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			if xQ7XawG9M3grVTo!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: i8sFwPqo1vpEXR2VdHU5BmW = url+'&page='+title
				else: i8sFwPqo1vpEXR2VdHU5BmW = url+'?page='+title
			title = Nkuqp0boKj41i9(title)
			if title: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,111,'','',xQ7XawG9M3grVTo)
	return
def UAB8vizclM6XG4Pw(url,pI9mdJWjGP8oeaOQAwnzu):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('items d-flex(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if len(tmEVko4qsghUX6WLx8KG7fOTB)>1:
		if '/season/' in tmEVko4qsghUX6WLx8KG7fOTB[0]: i80ehylRFvHDAbXBpkIr,Ad5sCEYHjxzg3yK = tmEVko4qsghUX6WLx8KG7fOTB[0],tmEVko4qsghUX6WLx8KG7fOTB[1]
		else: i80ehylRFvHDAbXBpkIr,Ad5sCEYHjxzg3yK = tmEVko4qsghUX6WLx8KG7fOTB[1],tmEVko4qsghUX6WLx8KG7fOTB[0]
	else: i80ehylRFvHDAbXBpkIr,Ad5sCEYHjxzg3yK = tmEVko4qsghUX6WLx8KG7fOTB[0],tmEVko4qsghUX6WLx8KG7fOTB[0]
	for H3ABEcMzfyqwF4Ug2ZYtK in range(2):
		if pI9mdJWjGP8oeaOQAwnzu: mode,type,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = 116,'folder',i80ehylRFvHDAbXBpkIr
		else: mode,type,Zsh7mUdwjHobLyMz6WKJGVl1cgeR = 112,'video',Ad5sCEYHjxzg3yK
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if pI9mdJWjGP8oeaOQAwnzu and len(items)<2:
			pI9mdJWjGP8oeaOQAwnzu = False
			continue
		for i8sFwPqo1vpEXR2VdHU5BmW,UliDv052e7j,tKBSN4Zgn9CDb in items:
			title = UliDv052e7j+' '+tKBSN4Zgn9CDb
			QQmLIZC8uas9fNiJWOnhdGvgFR(type,JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,mode)
		break
	if not items and '/episodes' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		qgehjLaD4KY1R7FCZcQ = T072lCzjYiuaeFtmJGV.findall('class="breadcrumb"(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if qgehjLaD4KY1R7FCZcQ:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qgehjLaD4KY1R7FCZcQ[0]
			kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if len(kkH5sRPxhASFowLONy4)>2:
				i8sFwPqo1vpEXR2VdHU5BmW = kkH5sRPxhASFowLONy4[2]+'list'
				Dhm1GLpdYu4xwZzSQlEtvNC3ga(i8sFwPqo1vpEXR2VdHU5BmW)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA = []
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="actions(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB: return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	kkH5sRPxhASFowLONy4 = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	tzo3ISsVJdefxr5jEvNY18gqpwTk = '/watch/' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR
	download = '/download/' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR
	if   tzo3ISsVJdefxr5jEvNY18gqpwTk and not download: p9syu6HZK4VbndXtTU7JGcRL2hFxmW,tMW0EZang1IDp = kkH5sRPxhASFowLONy4[0],''
	elif not tzo3ISsVJdefxr5jEvNY18gqpwTk and download: p9syu6HZK4VbndXtTU7JGcRL2hFxmW,tMW0EZang1IDp = '',kkH5sRPxhASFowLONy4[0]
	elif tzo3ISsVJdefxr5jEvNY18gqpwTk and download: p9syu6HZK4VbndXtTU7JGcRL2hFxmW,tMW0EZang1IDp = kkH5sRPxhASFowLONy4[0],kkH5sRPxhASFowLONy4[1]
	else: p9syu6HZK4VbndXtTU7JGcRL2hFxmW,tMW0EZang1IDp = '',''
	if tzo3ISsVJdefxr5jEvNY18gqpwTk:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',p9syu6HZK4VbndXtTU7JGcRL2hFxmW,'',headers,'','','SHAHID4U-PLAY-2nd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('let servers(.*?)player',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
		if q9OCkWn6ruAvQLKDFUyxBME0:
			MwELA7bGROd1uohvUNKpsrDVWnSyf4 = q9OCkWn6ruAvQLKDFUyxBME0[0]
			uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('"name":"(.*?)".*?"url":"(.*?)"',MwELA7bGROd1uohvUNKpsrDVWnSyf4,T072lCzjYiuaeFtmJGV.DOTALL)
			for title,i8sFwPqo1vpEXR2VdHU5BmW in uuNm2btCehYgvsIQlODr:
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\\/','/')
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if download:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',tMW0EZang1IDp,'',headers,'','','SHAHID4U-PLAY-3rd')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = WM1buqXnzf3Ba6Vp29l4gFD.content
		q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"servers"(.*?)info-container',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if q9OCkWn6ruAvQLKDFUyxBME0:
			MwELA7bGROd1uohvUNKpsrDVWnSyf4 = q9OCkWn6ruAvQLKDFUyxBME0[0]
			uuNm2btCehYgvsIQlODr = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',MwELA7bGROd1uohvUNKpsrDVWnSyf4,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title,Q5OAspyiXV1lx8930qLGD in uuNm2btCehYgvsIQlODr:
				i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'+'____'+Q5OAspyiXV1lx8930qLGD
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	search = search.replace(' ','+')
	url = HbiLZQKalC+'/search?s='+search
	LL2d9tanw0mrxJBKAT63buD,ll9khUfx3MjZ,mnV8BCoXEJxyAZtQhU62RpbraOY = NJviWdaAUb(vZs8PpIdBUNQTjnbEymoYx6X,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ,'search',mnV8BCoXEJxyAZtQhU62RpbraOY)
	return
def fr0hRyYNE14zx(url):
	url = url.split('/smartemadfilter?')[0]
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = []
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('adv-filter(.*?)shows-container',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		rlfYwZ6gq1i9R8Fta7J,vXn9i1j8RkC2DrVua5TcBAOYQHW0S,uuPG8BO037eSynUNE = zip(*ZlLpkRV3E5JQdX7AWPOaiFuy0zs)
		ZlLpkRV3E5JQdX7AWPOaiFuy0zs = zip(vXn9i1j8RkC2DrVua5TcBAOYQHW0S,rlfYwZ6gq1i9R8Fta7J,uuPG8BO037eSynUNE)
	return ZlLpkRV3E5JQdX7AWPOaiFuy0zs
def jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR):
	items = T072lCzjYiuaeFtmJGV.findall('value="(.*?)".*?>\s*(.*?)\s*<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	return items
def kIGOlCdasPe78Ty9UFfB1bhj2uNQMt(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	Oa38pfHe5x2FPCKRwbJ6mhVG = url.split('/smartemadfilter?')[0]
	i4sAb9xNqmGp2hCXUJtvuy7zkSW = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	url = url.replace(Oa38pfHe5x2FPCKRwbJ6mhVG,i4sAb9xNqmGp2hCXUJtvuy7zkSW)
	url = url.replace('/smartemadfilter?','/?')
	return url
Fih1RwkVGln8dLXSz = ['quality','year','genre','category']
BAvWKkoDJQXIc12dSfnRwrtagL0 = ['category','genre','year']
def hr0qteMSui7ZzxCoE(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='DEFINED_FILTER':
		if BAvWKkoDJQXIc12dSfnRwrtagL0[0]+'=' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = BAvWKkoDJQXIc12dSfnRwrtagL0[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(BAvWKkoDJQXIc12dSfnRwrtagL0[0:-1])):
			if BAvWKkoDJQXIc12dSfnRwrtagL0[jV1Z7MWOa80gbwJY64nL5]+'=' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = BAvWKkoDJQXIc12dSfnRwrtagL0[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		ll9khUfx3MjZ = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
	elif type=='FULL_FILTER':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'/smartemadfilter?'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		dCmKxk9BW310AXu4bJUHfY = kIGOlCdasPe78Ty9UFfB1bhj2uNQMt(ll9khUfx3MjZ)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها ',dCmKxk9BW310AXu4bJUHfY,111)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',dCmKxk9BW310AXu4bJUHfY,111)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = fr0hRyYNE14zx(url)
	dict = {}
	for name,cfWiG8bKuYoq32vDE51hCUxPT,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		name = name.replace('كل ','')
		items = jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
		if '=' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='DEFINED_FILTER':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<2:
				if cfWiG8bKuYoq32vDE51hCUxPT==BAvWKkoDJQXIc12dSfnRwrtagL0[-1]:
					dCmKxk9BW310AXu4bJUHfY = kIGOlCdasPe78Ty9UFfB1bhj2uNQMt(ll9khUfx3MjZ)
					Dhm1GLpdYu4xwZzSQlEtvNC3ga(dCmKxk9BW310AXu4bJUHfY)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'DEFINED_FILTER___'+Dwqu0Ws9eK)
				return
			else:
				if cfWiG8bKuYoq32vDE51hCUxPT==BAvWKkoDJQXIc12dSfnRwrtagL0[-1]:
					dCmKxk9BW310AXu4bJUHfY = kIGOlCdasPe78Ty9UFfB1bhj2uNQMt(ll9khUfx3MjZ)
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',dCmKxk9BW310AXu4bJUHfY,111)
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',ll9khUfx3MjZ,115,'','',Dwqu0Ws9eK)
		elif type=='FULL_FILTER':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع :'+name,ll9khUfx3MjZ,114,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			if EYn2siOeDvQTk8KpS0Jl=='196533': jwanU8orZtdFLNvM4EkHphWKzP = 'أفلام نيتفلكس'
			elif EYn2siOeDvQTk8KpS0Jl=='196531': jwanU8orZtdFLNvM4EkHphWKzP = 'مسلسلات نيتفلكس'
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = jwanU8orZtdFLNvM4EkHphWKzP
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+jwanU8orZtdFLNvM4EkHphWKzP
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			title = jwanU8orZtdFLNvM4EkHphWKzP+' :'#+dict[cfWiG8bKuYoq32vDE51hCUxPT]['0']
			title = jwanU8orZtdFLNvM4EkHphWKzP+' :'+name
			if type=='FULL_FILTER': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,114,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='DEFINED_FILTER' and BAvWKkoDJQXIc12dSfnRwrtagL0[-2]+'=' in cghHqoyS13upLUdz8bkXO7wlPK:
				YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'modified_filters')
				ll9khUfx3MjZ = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
				dCmKxk9BW310AXu4bJUHfY = kIGOlCdasPe78Ty9UFfB1bhj2uNQMt(ll9khUfx3MjZ)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,dCmKxk9BW310AXu4bJUHfY,111)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,115,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.replace('=&','=0&')
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&')
	H5y1ofSbMzmN7JI = {}
	if '=' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = ''
	for key in Fih1RwkVGln8dLXSz:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if '%' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = K3PukgCEDY(EYn2siOeDvQTk8KpS0Jl)
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.replace('=0','=')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'EGYNOW'
JJCLnkX4TozH7Bsjivfe = '_EGN_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
OZYvGX7EMx05KH1fI = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==430: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==431: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,text)
	elif mode==432: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==433: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==434: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: cLCisPE3lX = hr0qteMSui7ZzxCoE(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: cLCisPE3lX = rzgXD1OfZMh0bp4A5P(url)
	elif mode==437: cLCisPE3lX = jjh3Uvi8JV4eQpRaIyPYSGm1tXM(url)
	elif mode==439: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',HbiLZQKalC+'/films','','','','','EGYNOW-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = T072lCzjYiuaeFtmJGV.findall('"canonical" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	LL2d9tanw0mrxJBKAT63buD = LL2d9tanw0mrxJBKAT63buD[0].strip('/')
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(LL2d9tanw0mrxJBKAT63buD,'url')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر محدد',LL2d9tanw0mrxJBKAT63buD,435)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'فلتر كامل',LL2d9tanw0mrxJBKAT63buD,434)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المضاف حديثا',LL2d9tanw0mrxJBKAT63buD,431)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'افلام اون لاين',LL2d9tanw0mrxJBKAT63buD+'/films1',436)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مسلسلات اون لاين',LL2d9tanw0mrxJBKAT63buD+'/series-all1',436)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'قائمة تفصيلية',LL2d9tanw0mrxJBKAT63buD,437)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"SiteNavigation"(.*?)"Search"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,431)
	return
def jjh3Uvi8JV4eQpRaIyPYSGm1tXM(website=''):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	LL2d9tanw0mrxJBKAT63buD = T072lCzjYiuaeFtmJGV.findall('"canonical" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	LL2d9tanw0mrxJBKAT63buD = LL2d9tanw0mrxJBKAT63buD[0].strip('/')
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(LL2d9tanw0mrxJBKAT63buD,'url')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"ListDroped"(.*?)"SearchingMaster"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for ZecS1yJOzVutgX0qiH3NER,EYn2siOeDvQTk8KpS0Jl,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		i8sFwPqo1vpEXR2VdHU5BmW = website+'/explore/?'+ZecS1yJOzVutgX0qiH3NER+'='+EYn2siOeDvQTk8KpS0Jl
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,431)
	return
def rzgXD1OfZMh0bp4A5P(url):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع',url,431)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"titleSectionCon"(.*?)</div></div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('data-key="(.*?)".*?<em>(.*?)</em>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for xQ7XawG9M3grVTo,title in items:
		if title in OZYvGX7EMx05KH1fI: continue
		ll9khUfx3MjZ = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+xQ7XawG9M3grVTo
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,ll9khUfx3MjZ,431)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,iYvJPtR357SbyQf1=''):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
		JKf4Tsxu9S23FI7mV5DGLk = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','EGYNOW-TITLES-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
	elif iYvJPtR357SbyQf1=='featured':
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"MainSlider"(.*?)"MatchesTable"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"BlocksList"(.*?)"Paginate"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"BlocksList"(.*?)"titleSectionCon"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if not items: items = T072lCzjYiuaeFtmJGV.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	RNlnkarue2AW3Um8Q0 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for i8sFwPqo1vpEXR2VdHU5BmW,title,o3gHuBtrRN in items:
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW).strip('/')
		title = Nkuqp0boKj41i9(title)
		XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
		if any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in RNlnkarue2AW3Um8Q0):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,432,o3gHuBtrRN)
		elif XSCYbwaqRBtopUc9H2QZu86gA5N and 'الحلقة' in title:
			title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
			if title not in BBRwQhFnJ08q9YVxOSya:
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,433,o3gHuBtrRN)
				BBRwQhFnJ08q9YVxOSya.append(title)
		elif '/movseries/' in i8sFwPqo1vpEXR2VdHU5BmW:
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,431,o3gHuBtrRN)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,433,o3gHuBtrRN)
	if iYvJPtR357SbyQf1!='featured':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"Paginate"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
				if 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+i8sFwPqo1vpEXR2VdHU5BmW
				i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
				title = Nkuqp0boKj41i9(title)
				if title!='': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,431)
		sc8WJeUnfo6MuLH1ZiOkhVdgP7 = T072lCzjYiuaeFtmJGV.findall('showmore" href="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if sc8WJeUnfo6MuLH1ZiOkhVdgP7:
			i8sFwPqo1vpEXR2VdHU5BmW = sc8WJeUnfo6MuLH1ZiOkhVdgP7[0]
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مشاهدة المزيد',i8sFwPqo1vpEXR2VdHU5BmW,431)
	return
def UAB8vizclM6XG4Pw(url):
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	GVznW0jE3yMFaqK2uZvw1HBrtC,q9OCkWn6ruAvQLKDFUyxBME0 = [],[]
	if 'Episodes.php' in url:
		ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW = y2dmjAuhlfboLe(url)
		JKf4Tsxu9S23FI7mV5DGLk = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'POST',ll9khUfx3MjZ,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,'','','EGYNOW-EPISODES-1st')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		q9OCkWn6ruAvQLKDFUyxBME0 = [qQXuaKpVrGLF3e5oidJ8YwDT0]
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
		GVznW0jE3yMFaqK2uZvw1HBrtC = T072lCzjYiuaeFtmJGV.findall('"SeasonsList"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		q9OCkWn6ruAvQLKDFUyxBME0 = T072lCzjYiuaeFtmJGV.findall('"EpisodesList"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if GVznW0jE3yMFaqK2uZvw1HBrtC:
		o3gHuBtrRN = T072lCzjYiuaeFtmJGV.findall('"og:image" content="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		o3gHuBtrRN = o3gHuBtrRN[0]
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = GVznW0jE3yMFaqK2uZvw1HBrtC[0]
		items = T072lCzjYiuaeFtmJGV.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for fE9lhXGsySY5kH2CQ,IP2SXBrdLot5xMv6,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+IP2SXBrdLot5xMv6+'&post_id='+fE9lhXGsySY5kH2CQ
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,433,o3gHuBtrRN)
	elif q9OCkWn6ruAvQLKDFUyxBME0:
		o3gHuBtrRN = EO9Rts0AaGuk1qpPLXCY.getInfoLabel('ListItem.Thumb')
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = q9OCkWn6ruAvQLKDFUyxBME0[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,XSCYbwaqRBtopUc9H2QZu86gA5N in items:
			title = title+' '+XSCYbwaqRBtopUc9H2QZu86gA5N
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,432,o3gHuBtrRN)
	return
def JwYEQUDupG2WLPzHndc(url):
	ll9khUfx3MjZ = url+'/watch/'
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',ll9khUfx3MjZ,'','','','','EGYNOW-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	M7oS6tLhdx3ke8qPX4mFA = []
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(ll9khUfx3MjZ,'url')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"container-servers"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		CXUSgmQjGvJzKWYr7BckR2I = T072lCzjYiuaeFtmJGV.findall('data-id="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if CXUSgmQjGvJzKWYr7BckR2I:
			CXUSgmQjGvJzKWYr7BckR2I = CXUSgmQjGvJzKWYr7BckR2I[0]
			items = T072lCzjYiuaeFtmJGV.findall('data-server="(.*?)".*?<span>(.*?)</span>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for dATnilvcrXxmZ1k5EP0KgBFDqYpy6,title in items:
				i8sFwPqo1vpEXR2VdHU5BmW = LL2d9tanw0mrxJBKAT63buD+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+dATnilvcrXxmZ1k5EP0KgBFDqYpy6+'&post_id='+CXUSgmQjGvJzKWYr7BckR2I+'?named='+title+'__watch'
				M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	f1ecMmtLsXNUHBAaoTn = T072lCzjYiuaeFtmJGV.findall('"container-iframe"><iframe src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if f1ecMmtLsXNUHBAaoTn:
		f1ecMmtLsXNUHBAaoTn = f1ecMmtLsXNUHBAaoTn[0].replace('\n','')
		title = ClNwy8MJfjoTq4ZFxYvmasD(f1ecMmtLsXNUHBAaoTn,'name')
		i8sFwPqo1vpEXR2VdHU5BmW = f1ecMmtLsXNUHBAaoTn+'?named='+title+'__embed'
		M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('"container-download"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,Q5OAspyiXV1lx8930qLGD in items:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\n','')
			if Q5OAspyiXV1lx8930qLGD!='': Q5OAspyiXV1lx8930qLGD = '____'+Q5OAspyiXV1lx8930qLGD
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__download'+Q5OAspyiXV1lx8930qLGD
			M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','%20')
	url = HbiLZQKalC+'/?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
def fr0hRyYNE14zx(url):
	url = url.split('/smartemadfilter?')[0]
	LL2d9tanw0mrxJBKAT63buD = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',LL2d9tanw0mrxJBKAT63buD,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('("dropdown-button".*?)"SearchingMaster"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = T072lCzjYiuaeFtmJGV.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	return ZlLpkRV3E5JQdX7AWPOaiFuy0zs
def jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR):
	items = T072lCzjYiuaeFtmJGV.findall('data-term="(\d+)" data-name="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	return items
def QQMP0rV7x3IcgE4D9jW6JBy(url):
	Oa38pfHe5x2FPCKRwbJ6mhVG = url.split('/smartemadfilter?')[0]
	i4sAb9xNqmGp2hCXUJtvuy7zkSW = ClNwy8MJfjoTq4ZFxYvmasD(url,'url')
	url = url.replace(Oa38pfHe5x2FPCKRwbJ6mhVG,i4sAb9xNqmGp2hCXUJtvuy7zkSW)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def zz5S1qFBTsx8L(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,url):
	YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,'modified_filters')
	dCmKxk9BW310AXu4bJUHfY = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
	dCmKxk9BW310AXu4bJUHfY = QQMP0rV7x3IcgE4D9jW6JBy(dCmKxk9BW310AXu4bJUHfY)
	return dCmKxk9BW310AXu4bJUHfY
aKqQ1yXlIcDoxtdCmunE = ['category','country','genre','release-year']
Dx5lzy4Anw63Lt1SsNm2rhk = ['quality','release-year','genre','category','language','country']
def hr0qteMSui7ZzxCoE(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = '',''
	else: cghHqoyS13upLUdz8bkXO7wlPK,BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if aKqQ1yXlIcDoxtdCmunE[0]+'=' not in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[0]
		for jV1Z7MWOa80gbwJY64nL5 in range(len(aKqQ1yXlIcDoxtdCmunE[0:-1])):
			if aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5]+'=' in cghHqoyS13upLUdz8bkXO7wlPK: ZecS1yJOzVutgX0qiH3NER = aKqQ1yXlIcDoxtdCmunE[jV1Z7MWOa80gbwJY64nL5+1]
		VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+ZecS1yJOzVutgX0qiH3NER+'=0'
		Dwqu0Ws9eK = VkaTM5SiJ6KG.strip('&')+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r.strip('&')
		YupaFCoAIicOnZNd = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		ll9khUfx3MjZ = url+'/smartemadfilter?'+YupaFCoAIicOnZNd
	elif type=='ALL_ITEMS_FILTER':
		Bo3K6UX2LiVMbImdhv908YWP51wut = L5vMb9jiwVCz1ISDch(cghHqoyS13upLUdz8bkXO7wlPK,'modified_values')
		Bo3K6UX2LiVMbImdhv908YWP51wut = rygO0TzuEdiPcQDWZ8awSjm(Bo3K6UX2LiVMbImdhv908YWP51wut)
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm!='': BBXLHwaR3jxC6ocVNi8D7blMIOZgfm = L5vMb9jiwVCz1ISDch(BBXLHwaR3jxC6ocVNi8D7blMIOZgfm,'modified_filters')
		if BBXLHwaR3jxC6ocVNi8D7blMIOZgfm=='': ll9khUfx3MjZ = url
		else: ll9khUfx3MjZ = url+'/smartemadfilter?'+BBXLHwaR3jxC6ocVNi8D7blMIOZgfm
		ll9khUfx3MjZ = QQMP0rV7x3IcgE4D9jW6JBy(ll9khUfx3MjZ)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'أظهار قائمة الفيديو التي تم اختيارها ',ll9khUfx3MjZ,431)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+' [[   '+Bo3K6UX2LiVMbImdhv908YWP51wut+'   ]]',ll9khUfx3MjZ,431)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ZlLpkRV3E5JQdX7AWPOaiFuy0zs = fr0hRyYNE14zx(url)
	dict = {}
	for name,Zsh7mUdwjHobLyMz6WKJGVl1cgeR,cfWiG8bKuYoq32vDE51hCUxPT in ZlLpkRV3E5JQdX7AWPOaiFuy0zs:
		name = name.replace('--','')
		items = jjw6faKn0liCEhymBPRDOtkIFb4TY(Zsh7mUdwjHobLyMz6WKJGVl1cgeR)
		if '=' not in ll9khUfx3MjZ: ll9khUfx3MjZ = url
		if type=='SPECIFIED_FILTER':
			if ZecS1yJOzVutgX0qiH3NER!=cfWiG8bKuYoq32vDE51hCUxPT: continue
			elif len(items)<2:
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]:
					url = QQMP0rV7x3IcgE4D9jW6JBy(url)
					Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
				else: hr0qteMSui7ZzxCoE(ll9khUfx3MjZ,'SPECIFIED_FILTER___'+Dwqu0Ws9eK)
				return
			else:
				ll9khUfx3MjZ = QQMP0rV7x3IcgE4D9jW6JBy(ll9khUfx3MjZ)
				if cfWiG8bKuYoq32vDE51hCUxPT==aKqQ1yXlIcDoxtdCmunE[-1]: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع ',ll9khUfx3MjZ,431)
				else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع ',ll9khUfx3MjZ,435,'','',Dwqu0Ws9eK)
		elif type=='ALL_ITEMS_FILTER':
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'=0'
			Dwqu0Ws9eK = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الجميع :'+name,ll9khUfx3MjZ,434,'','',Dwqu0Ws9eK)
		dict[cfWiG8bKuYoq32vDE51hCUxPT] = {}
		for EYn2siOeDvQTk8KpS0Jl,jwanU8orZtdFLNvM4EkHphWKzP in items:
			if EYn2siOeDvQTk8KpS0Jl=='196533': jwanU8orZtdFLNvM4EkHphWKzP = 'أفلام نيتفلكس'
			elif EYn2siOeDvQTk8KpS0Jl=='196531': jwanU8orZtdFLNvM4EkHphWKzP = 'مسلسلات نيتفلكس'
			if jwanU8orZtdFLNvM4EkHphWKzP in OZYvGX7EMx05KH1fI: continue
			dict[cfWiG8bKuYoq32vDE51hCUxPT][EYn2siOeDvQTk8KpS0Jl] = jwanU8orZtdFLNvM4EkHphWKzP
			VkaTM5SiJ6KG = cghHqoyS13upLUdz8bkXO7wlPK+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+jwanU8orZtdFLNvM4EkHphWKzP
			J5C2DNeoAXWGqyHVs1ZfP47mBvt0r = BBXLHwaR3jxC6ocVNi8D7blMIOZgfm+'&'+cfWiG8bKuYoq32vDE51hCUxPT+'='+EYn2siOeDvQTk8KpS0Jl
			L1V6lkbTGopQ3gYzH4OmrafPwEi = VkaTM5SiJ6KG+'___'+J5C2DNeoAXWGqyHVs1ZfP47mBvt0r
			title = jwanU8orZtdFLNvM4EkHphWKzP+' :'#+dict[cfWiG8bKuYoq32vDE51hCUxPT]['0']
			title = jwanU8orZtdFLNvM4EkHphWKzP+' :'+name
			if type=='ALL_ITEMS_FILTER': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,434,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
			elif type=='SPECIFIED_FILTER' and aKqQ1yXlIcDoxtdCmunE[-2]+'=' in cghHqoyS13upLUdz8bkXO7wlPK:
				dCmKxk9BW310AXu4bJUHfY = zz5S1qFBTsx8L(J5C2DNeoAXWGqyHVs1ZfP47mBvt0r,url)
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,dCmKxk9BW310AXu4bJUHfY,431)
			else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,435,'','',L1V6lkbTGopQ3gYzH4OmrafPwEi)
	return
def L5vMb9jiwVCz1ISDch(RowfG8LnD9IvTg34Ue2WVbBXa0O5u,mode):
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.replace('=&','=0&')
	RowfG8LnD9IvTg34Ue2WVbBXa0O5u = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.strip('&')
	H5y1ofSbMzmN7JI = {}
	if '=' in RowfG8LnD9IvTg34Ue2WVbBXa0O5u:
		items = RowfG8LnD9IvTg34Ue2WVbBXa0O5u.split('&')
		for Lw8JjEfuiW0VN9qHAcgRpMBdICS in items:
			X17rpnZfBT9msy0ltMo4bg,EYn2siOeDvQTk8KpS0Jl = Lw8JjEfuiW0VN9qHAcgRpMBdICS.split('=')
			H5y1ofSbMzmN7JI[X17rpnZfBT9msy0ltMo4bg] = EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = ''
	for key in Dx5lzy4Anw63Lt1SsNm2rhk:
		if key in list(H5y1ofSbMzmN7JI.keys()): EYn2siOeDvQTk8KpS0Jl = H5y1ofSbMzmN7JI[key]
		else: EYn2siOeDvQTk8KpS0Jl = '0'
		if '%' not in EYn2siOeDvQTk8KpS0Jl: EYn2siOeDvQTk8KpS0Jl = K3PukgCEDY(EYn2siOeDvQTk8KpS0Jl)
		if mode=='modified_values' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+' + '+EYn2siOeDvQTk8KpS0Jl
		elif mode=='modified_filters' and EYn2siOeDvQTk8KpS0Jl!='0': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
		elif mode=='all_filters': lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9+'&'+key+'='+EYn2siOeDvQTk8KpS0Jl
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip(' + ')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.strip('&')
	lZrWcL5Ts4SK78wXChVy16DPRkv9 = lZrWcL5Ts4SK78wXChVy16DPRkv9.replace('=0','=')
	return lZrWcL5Ts4SK78wXChVy16DPRkv9
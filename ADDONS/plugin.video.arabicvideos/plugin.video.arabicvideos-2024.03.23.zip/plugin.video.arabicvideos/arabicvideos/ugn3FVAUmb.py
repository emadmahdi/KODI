# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SHIAVOICE'
JJCLnkX4TozH7Bsjivfe = '_SHV_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
headers = {'User-Agent':None}
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==310: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==311: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==312: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==313: cLCisPE3lX = raiMw56H3mbT7AZvJPUcLI(url)
	elif mode==314: cLCisPE3lX = lTDhLSWw0YXprJzxfZNejCmO(text)
	elif mode==319: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(CC89Q23uNDmIKWHAs,'GET',HbiLZQKalC,'','','','','SHIAVOICE-MENU-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('id="menulinks"(.*?)</ul>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = T072lCzjYiuaeFtmJGV.findall('<h5>(.*?)</h5>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.IGNORECASE)
	for F1FBMcYyaNIJ in range(len(items)):
		title = items[F1FBMcYyaNIJ].strip(' ')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,HbiLZQKalC,314,'','',str(F1FBMcYyaNIJ+1))
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'مقاطع شهر',HbiLZQKalC,314,'','','0')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<B>(.*?)</B>',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,311)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def lTDhLSWw0YXprJzxfZNejCmO(F1FBMcYyaNIJ):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',HbiLZQKalC,'','','','','SHIAVOICE-LATEST-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	if F1FBMcYyaNIJ=='0':
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="tab-content"(.*?)</table>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,name,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312)
	elif F1FBMcYyaNIJ in ['1','2','3']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(<h5>.*?)<div class="col-lg',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		LXVE4iox1KksWhNMwRa5 = int(F1FBMcYyaNIJ)-1
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[LXVE4iox1KksWhNMwRa5]
		if F1FBMcYyaNIJ=='1': items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		else: items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title,name in items:
			o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,311,o3gHuBtrRN)
	elif F1FBMcYyaNIJ in ['4','5','6']:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('(<h5>.*?)</table>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		F1FBMcYyaNIJ = int(F1FBMcYyaNIJ)-4
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[F1FBMcYyaNIJ]
		items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,gBQxOqabPovs7y,title,dFEpvGRU73W6TowXj5xV8 in items:
			o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title.strip(' ')
			gBQxOqabPovs7y = gBQxOqabPovs7y.strip(' ')
			dFEpvGRU73W6TowXj5xV8 = dFEpvGRU73W6TowXj5xV8.strip(' ')
			if gBQxOqabPovs7y: name = gBQxOqabPovs7y
			else: name = dFEpvGRU73W6TowXj5xV8
			title = title+' ('+name+')'
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312,o3gHuBtrRN)
	return
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('ibox-heading"(.*?)class="float-right',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	if 'catsum-mobile' in Zsh7mUdwjHobLyMz6WKJGVl1cgeR:
		items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		if items:
			for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title,count in items:
				o3gHuBtrRN = HbiLZQKalC+'/'+o3gHuBtrRN
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,311,o3gHuBtrRN)
	else:
		items = T072lCzjYiuaeFtmJGV.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title,wwme0MkA8iP,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab in items:
			if title=='' or wwme0MkA8iP=='': continue
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
			title = title+' ('+fOFNhC5n6laPDvK1Mtz9QYxZ0Ab+')'
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312)
	if not items: UAB8vizclM6XG4Pw(qQXuaKpVrGLF3e5oidJ8YwDT0)
	return
def UAB8vizclM6XG4Pw(qQXuaKpVrGLF3e5oidJ8YwDT0):
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="ibox-content"(.*?)class="pagination',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title,name,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312,'',fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	return
def raiMw56H3mbT7AZvJPUcLI(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="ibox-content p-1"(.*?)class="ibox-content"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not tmEVko4qsghUX6WLx8KG7fOTB:
		Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
		return
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?<strong>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/'+i8sFwPqo1vpEXR2VdHU5BmW
		title = title.strip(' ')
		if '/play-' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,311)
	return
def JwYEQUDupG2WLPzHndc(url):
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<audio.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = T072lCzjYiuaeFtmJGV.findall('<video.*?src="(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW[0]
	pidYDcjvhgVfqb3GeWSAOH5J(i8sFwPqo1vpEXR2VdHU5BmW,nO6ukabcldeU,'video')
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	TaEPpsbdVNrkiLSmCHehf = ['&t=a','&t=c','&t=s']
	if showDialogs:
		Bnw1yEm7PK8fVYgh = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		tzgWIKy5xQL2kjm = sSOy1pju5PJ('موقع صوت الشيعة - أختر البحث', Bnw1yEm7PK8fVYgh)
		if tzgWIKy5xQL2kjm == -1: return
	elif '_SHIAVOICE-PERSONS_' in ZNpFGHa28C9WcoRb: tzgWIKy5xQL2kjm = 0
	elif '_SHIAVOICE-ALBUMS_' in ZNpFGHa28C9WcoRb: tzgWIKy5xQL2kjm = 1
	elif '_SHIAVOICE-AUDIOS_' in ZNpFGHa28C9WcoRb: tzgWIKy5xQL2kjm = 2
	else: return
	type = TaEPpsbdVNrkiLSmCHehf[tzgWIKy5xQL2kjm]
	url = HbiLZQKalC+'/search.php?q='+search+type
	WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(GGXxhdg3JCamPIFepybjZ,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="ibox-content"(.*?)class="ibox-content"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		if tzgWIKy5xQL2kjm in [0,1]:
			items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,313,o3gHuBtrRN)
		elif tzgWIKy5xQL2kjm==2:
			items = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			for i8sFwPqo1vpEXR2VdHU5BmW,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,312)
	return
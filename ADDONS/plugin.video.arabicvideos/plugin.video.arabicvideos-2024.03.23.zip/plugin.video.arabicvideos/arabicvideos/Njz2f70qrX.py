# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
JJCLnkX4TozH7Bsjivfe = '_SFW_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text):
	if   mode==210: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==211: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	elif mode==212: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url)
	elif mode==213: cLCisPE3lX = UAB8vizclM6XG4Pw(url)
	elif mode==214: cLCisPE3lX = xG2h389jMKYlADXQIin05CwUakyrf(url)
	elif mode==215: cLCisPE3lX = NyEDuGYnILTMsRhvBt72i50egaV(url)
	elif mode==218: cLCisPE3lX = Mp4nZPkVhub5Hjcvz8xF7iT3()
	elif mode==219: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def Mp4nZPkVhub5Hjcvz8xF7iT3():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	KK47FGdX1TDfkb3AjHOQqghE('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def lD8xr3zag19KuC():
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = HbiLZQKalC+'/getpostsPin?type=one&data=pin&limit=25'
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+'المميزة',url,211)
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,HbiLZQKalC,'',headers,'','SERIES4WATCH-MENU-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('FiltersButtons(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('data-get="(.*?)".*?</i>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		url = HbiLZQKalC+'/getposts?type=one&data='+i8sFwPqo1vpEXR2VdHU5BmW
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,url,211)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('navigation-menu(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
	items = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)">(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	OZYvGX7EMx05KH1fI = ['مسلسلات انمي','الرئيسية']
	for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		title = title.strip(' ')
		if not any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in OZYvGX7EMx05KH1fI):
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',nO6ukabcldeU+'_SCRIPT_'+JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,211)
	return qQXuaKpVrGLF3e5oidJ8YwDT0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url):
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = qQXuaKpVrGLF3e5oidJ8YwDT0
	else:
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('MediaGrid"(.*?)class="pagination"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB: Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		else: return
	items = T072lCzjYiuaeFtmJGV.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
	BBRwQhFnJ08q9YVxOSya = []
	ii0ST7oQxM = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for o3gHuBtrRN,i8sFwPqo1vpEXR2VdHU5BmW,title in items:
		if '/series/' in i8sFwPqo1vpEXR2VdHU5BmW: continue
		i8sFwPqo1vpEXR2VdHU5BmW = rygO0TzuEdiPcQDWZ8awSjm(i8sFwPqo1vpEXR2VdHU5BmW).strip('/')
		title = Nkuqp0boKj41i9(title)
		title = title.strip(' ')
		if '/film/' in i8sFwPqo1vpEXR2VdHU5BmW or any(EYn2siOeDvQTk8KpS0Jl in title for EYn2siOeDvQTk8KpS0Jl in ii0ST7oQxM):
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,212,o3gHuBtrRN)
		elif '/episode/' in i8sFwPqo1vpEXR2VdHU5BmW and 'الحلقة' in title:
			XSCYbwaqRBtopUc9H2QZu86gA5N = T072lCzjYiuaeFtmJGV.findall('(.*?) الحلقة \d+',title,T072lCzjYiuaeFtmJGV.DOTALL)
			if XSCYbwaqRBtopUc9H2QZu86gA5N:
				title = '_MOD_' + XSCYbwaqRBtopUc9H2QZu86gA5N[0]
				if title not in BBRwQhFnJ08q9YVxOSya:
					QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,213,o3gHuBtrRN)
					BBRwQhFnJ08q9YVxOSya.append(title)
		else: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,213,o3gHuBtrRN)
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="pagination(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
		items = T072lCzjYiuaeFtmJGV.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
		for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
			i8sFwPqo1vpEXR2VdHU5BmW = Nkuqp0boKj41i9(i8sFwPqo1vpEXR2VdHU5BmW)
			title = Nkuqp0boKj41i9(title)
			title = title.replace('الصفحة ','')
			if title!='': QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'صفحة '+title,i8sFwPqo1vpEXR2VdHU5BmW,211)
	return
def UAB8vizclM6XG4Pw(url):
	Rp1w5YK6atSUxZizvMbsG0Nuh,items,Ip1ihmjOJoNPAbw = -1,[],[]
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(GGXxhdg3JCamPIFepybjZ,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('ti-list-numbered(.*?)</div>',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
	if tmEVko4qsghUX6WLx8KG7fOTB:
		uuPG8BO037eSynUNE = ''.join(tmEVko4qsghUX6WLx8KG7fOTB)
		items = T072lCzjYiuaeFtmJGV.findall('href="(.*?)"',uuPG8BO037eSynUNE,T072lCzjYiuaeFtmJGV.DOTALL)
	items.append(url)
	items = set(items)
	for i8sFwPqo1vpEXR2VdHU5BmW in items:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.strip('/')
		title = '_MOD_' + i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-1].replace('-',' ')
		IMC3E9dFHnu2QSTy6DUPczBi0qk = T072lCzjYiuaeFtmJGV.findall('الحلقة-(\d+)',i8sFwPqo1vpEXR2VdHU5BmW.split('/')[-1],T072lCzjYiuaeFtmJGV.DOTALL)
		if IMC3E9dFHnu2QSTy6DUPczBi0qk: IMC3E9dFHnu2QSTy6DUPczBi0qk = IMC3E9dFHnu2QSTy6DUPczBi0qk[0]
		else: IMC3E9dFHnu2QSTy6DUPczBi0qk = '0'
		Ip1ihmjOJoNPAbw.append([i8sFwPqo1vpEXR2VdHU5BmW,title,IMC3E9dFHnu2QSTy6DUPczBi0qk])
	items = sorted(Ip1ihmjOJoNPAbw, reverse=False, key=lambda key: int(key[2]))
	RQikSAmNdsu5 = str(items).count('/season/')
	Rp1w5YK6atSUxZizvMbsG0Nuh = str(items).count('/episode/')
	if RQikSAmNdsu5>1 and Rp1w5YK6atSUxZizvMbsG0Nuh>0 and '/season/' not in url:
		for i8sFwPqo1vpEXR2VdHU5BmW,title,IMC3E9dFHnu2QSTy6DUPczBi0qk in items:
			if '/season/' in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,213)
	else:
		for i8sFwPqo1vpEXR2VdHU5BmW,title,IMC3E9dFHnu2QSTy6DUPczBi0qk in items:
			if '/season/' not in i8sFwPqo1vpEXR2VdHU5BmW: QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,212)
	return
def JwYEQUDupG2WLPzHndc(url):
	M7oS6tLhdx3ke8qPX4mFA = []
	eHquV9G0n2wlLjOvC5PUW = url.split('/')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		ll9khUfx3MjZ = url.replace(eHquV9G0n2wlLjOvC5PUW[3],'watch')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'',headers,'','SERIES4WATCH-PLAY-2nd')
		tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('class="servers-list(.*?)</div>',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if tmEVko4qsghUX6WLx8KG7fOTB:
			Zsh7mUdwjHobLyMz6WKJGVl1cgeR = tmEVko4qsghUX6WLx8KG7fOTB[0]
			items = T072lCzjYiuaeFtmJGV.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
			if items:
				id = T072lCzjYiuaeFtmJGV.findall('post_id=(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
				if id:
					WpHryfYS0dNkc9bJlgoI8ueAj3n = id[0]
					for i8sFwPqo1vpEXR2VdHU5BmW,title in items:
						i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/?postid='+WpHryfYS0dNkc9bJlgoI8ueAj3n+'&serverid='+i8sFwPqo1vpEXR2VdHU5BmW+'?named='+title+'__watch'
						M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
			else:
				items = T072lCzjYiuaeFtmJGV.findall('data-embedd=".*?(http.*?)("|&quot;)',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
				for i8sFwPqo1vpEXR2VdHU5BmW,O578ENGbr6PYnLJzi in items:
					M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	if '/download/' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		ll9khUfx3MjZ = url.replace(eHquV9G0n2wlLjOvC5PUW[3],'download')
		IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = T072lCzjYiuaeFtmJGV.findall('postId:"(.*?)"',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
		if id:
			WpHryfYS0dNkc9bJlgoI8ueAj3n = id[0]
			JKf4Tsxu9S23FI7mV5DGLk = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			ll9khUfx3MjZ = HbiLZQKalC + '/ajaxCenter?_action=getdownloadlinks&postId='+WpHryfYS0dNkc9bJlgoI8ueAj3n
			IIV0pUlqMoKDC9r8wy1EGT7OesJQBS = j8ieg546LG2rUaksfnNMcI1lb(CC89Q23uNDmIKWHAs,ll9khUfx3MjZ,'',JKf4Tsxu9S23FI7mV5DGLk,'','SERIES4WATCH-PLAY-4th')
			tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<h3.*?(\d+)(.*?)</div>',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
			if tmEVko4qsghUX6WLx8KG7fOTB:
				for ayh3UqDOn2tN958MlbjKVmzcBS,Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
					items = T072lCzjYiuaeFtmJGV.findall('<td>(.*?)<.*?href="(.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
					for name,i8sFwPqo1vpEXR2VdHU5BmW in items:
						M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW+'?named='+name+'__download'+'____'+ayh3UqDOn2tN958MlbjKVmzcBS)
			else:
				tmEVko4qsghUX6WLx8KG7fOTB = T072lCzjYiuaeFtmJGV.findall('<h6(.*?)</table>',IIV0pUlqMoKDC9r8wy1EGT7OesJQBS,T072lCzjYiuaeFtmJGV.DOTALL)
				if not tmEVko4qsghUX6WLx8KG7fOTB: tmEVko4qsghUX6WLx8KG7fOTB = [IIV0pUlqMoKDC9r8wy1EGT7OesJQBS]
				for Zsh7mUdwjHobLyMz6WKJGVl1cgeR in tmEVko4qsghUX6WLx8KG7fOTB:
					name = ''
					items = T072lCzjYiuaeFtmJGV.findall('href="(http.*?)"',Zsh7mUdwjHobLyMz6WKJGVl1cgeR,T072lCzjYiuaeFtmJGV.DOTALL)
					for i8sFwPqo1vpEXR2VdHU5BmW in items:
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = '&&' + i8sFwPqo1vpEXR2VdHU5BmW.split('/')[2].lower() + '&&'
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = dATnilvcrXxmZ1k5EP0KgBFDqYpy6.replace('.com&&','').replace('.co&&','')
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = dATnilvcrXxmZ1k5EP0KgBFDqYpy6.replace('.net&&','').replace('.org&&','')
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = dATnilvcrXxmZ1k5EP0KgBFDqYpy6.replace('.live&&','').replace('.online&&','')
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = dATnilvcrXxmZ1k5EP0KgBFDqYpy6.replace('&&hd.','').replace('&&www.','')
						dATnilvcrXxmZ1k5EP0KgBFDqYpy6 = dATnilvcrXxmZ1k5EP0KgBFDqYpy6.replace('&&','')
						i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW + '?named=' + name + dATnilvcrXxmZ1k5EP0KgBFDqYpy6 + '__download'
						M7oS6tLhdx3ke8qPX4mFA.append(i8sFwPqo1vpEXR2VdHU5BmW)
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U(M7oS6tLhdx3ke8qPX4mFA,nO6ukabcldeU,'video',url)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if search=='': search = NWs7KpjXGnxYylofHtd5U3wDh()
	if search=='': return
	search = search.replace(' ','+')
	url = HbiLZQKalC + '/search?s='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(url)
	return
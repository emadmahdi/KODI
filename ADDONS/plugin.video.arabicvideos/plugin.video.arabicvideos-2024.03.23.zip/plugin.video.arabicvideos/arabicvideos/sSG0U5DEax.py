# -*- coding: utf-8 -*-
from skIgoAvZ9t import *
nO6ukabcldeU = 'YOUTUBE'
JJCLnkX4TozH7Bsjivfe = '_YUT_'
HbiLZQKalC = tOnYIHVk4xydqwoLEBKiDN0hX[nO6ukabcldeU][0]
cjqX9vFRix3Udo0htaWQ1COYm2 = 0
def F5M9LsnokGPEQ2XYfO7cuyr(mode,url,text,type,ffGe7cURW0lhJVvQAiw8IB,name,BB5dqMe8jgLxwSvk):
	if	 mode==140: cLCisPE3lX = lD8xr3zag19KuC()
	elif mode==141: cLCisPE3lX = AvCRxpLtoVh(url,name,BB5dqMe8jgLxwSvk)
	elif mode==143: cLCisPE3lX = JwYEQUDupG2WLPzHndc(url,type)
	elif mode==144: cLCisPE3lX = Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,ffGe7cURW0lhJVvQAiw8IB,text)
	elif mode==145: cLCisPE3lX = Qls1PoHZJGD4wmfpAV3cMxn567e(url,ffGe7cURW0lhJVvQAiw8IB)
	elif mode==147: cLCisPE3lX = OOVrMCWoiQPnJgGaTfxBL672Uk()
	elif mode==148: cLCisPE3lX = V3PiCE8LschINYlD6MZXb()
	elif mode==149: cLCisPE3lX = CXz8MpZeQigHAjw47TlbhdcPYoaWG(text)
	else: cLCisPE3lX = False
	return cLCisPE3lX
def lD8xr3zag19KuC():
	if 0:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'قائمة',HbiLZQKalC+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'شخص',HbiLZQKalC+'/user/TCNofficial',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'موقع',HbiLZQKalC+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'حساب',HbiLZQKalC+'/@TheSocialCTV',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'العاب',HbiLZQKalC+'/gaming',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'افلام',HbiLZQKalC+'/feed/storefront',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مختارات',HbiLZQKalC+'/feed/guide_builder',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'قصيرة',HbiLZQKalC+'/shorts',144,'','','_REMEMBERRESULTS_')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'تصفح',HbiLZQKalC+'/youtubei/v1/guide?key=',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'رئيسية',HbiLZQKalC+'',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'رائج',HbiLZQKalC+'/feed/trending?bp=',144)
		QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الرئيسية',HbiLZQKalC+'',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'الرائجة',HbiLZQKalC+'/feed/trending',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'التصفح',HbiLZQKalC+'/youtubei/v1/guide?key=',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'القصيرة',HbiLZQKalC+'/shorts',144,'','','_REMEMBERRESULTS_')
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مختارات يوتيوب',HbiLZQKalC+'/feed/guide_builder',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'مختارات البرنامج','',290)
	QQmLIZC8uas9fNiJWOnhdGvgFR('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: قنوات عربية','',147)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: قنوات أجنبية','',148)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: افلام عربية',HbiLZQKalC+'/results?search_query=فيلم',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: افلام اجنبية',HbiLZQKalC+'/results?search_query=movie',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: مسرحيات عربية',HbiLZQKalC+'/results?search_query=مسرحية',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات عربية',HbiLZQKalC+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات اجنبية',HbiLZQKalC+'/results?search_query=series&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: مسلسلات كارتون',HbiLZQKalC+'/results?search_query=كارتون&sp=EgIQAw==',144)
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'بحث: خطبة المرجعية',HbiLZQKalC+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def AvCRxpLtoVh(url,name,BB5dqMe8jgLxwSvk):
	QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'CHNL:  '+name,url,144,BB5dqMe8jgLxwSvk)
	return
def OOVrMCWoiQPnJgGaTfxBL672Uk():
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(HbiLZQKalC+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def V3PiCE8LschINYlD6MZXb():
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(HbiLZQKalC+'/results?search_query=tv&sp=EgJAAQ==')
	return
def JwYEQUDupG2WLPzHndc(url,type):
	url = url.split('&',1)[0]
	import d3obAhVeNX
	d3obAhVeNX.OosDL7R1fGNB2eT3MtSqY9U([url],nO6ukabcldeU,type,url)
	return
def CGVAdK5yXjok7isuceOzwbhtxLZvBp(k9mjxFK3buTyeUqRMndsXB,url,prZUeN9FojstVTxf0EJQBRq4zdb):
	level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = prZUeN9FojstVTxf0EJQBRq4zdb.split('::')
	Vo7hifxLTQnUR4Yr,waIqZX2u7zgS4CrH = [],[]
	if '/youtubei/v1/browse' in url: Vo7hifxLTQnUR4Yr.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: Vo7hifxLTQnUR4Yr.append("yccc['onResponseReceivedCommands']")
	if level=='1': Vo7hifxLTQnUR4Yr.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	Vo7hifxLTQnUR4Yr.append("yccc['entries']")
	Vo7hifxLTQnUR4Yr.append("yccc['items'][3]['guideSectionRenderer']['items']")
	K0zcx1abElRUgIkjAfJHT5yBF,BnusDqyxU1WpN5K,tjB9zfExLwgKCJbd26opu = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(k9mjxFK3buTyeUqRMndsXB,'',Vo7hifxLTQnUR4Yr)
	if level=='1' and K0zcx1abElRUgIkjAfJHT5yBF:
		if len(BnusDqyxU1WpN5K)>1 and 'search_query' not in url:
			for qOoBk5C34pJHFAhY in range(len(BnusDqyxU1WpN5K)):
				TQC80zSMLtx = str(qOoBk5C34pJHFAhY)
				Vo7hifxLTQnUR4Yr = []
				Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['reloadContinuationItemsCommand']['continuationItems']")
				Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['command']")
				Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]")
				UkYj1KP0ou4q9rVfEgn2JQHI56BG,Lw8JjEfuiW0VN9qHAcgRpMBdICS,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(BnusDqyxU1WpN5K,'',Vo7hifxLTQnUR4Yr)
				if UkYj1KP0ou4q9rVfEgn2JQHI56BG: waIqZX2u7zgS4CrH.append([Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,'2::'+TQC80zSMLtx+'::0::0'])
			Vo7hifxLTQnUR4Yr.append("yccc['continuationEndpoint']")
			UkYj1KP0ou4q9rVfEgn2JQHI56BG,Lw8JjEfuiW0VN9qHAcgRpMBdICS,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(k9mjxFK3buTyeUqRMndsXB,'',Vo7hifxLTQnUR4Yr)
			if UkYj1KP0ou4q9rVfEgn2JQHI56BG and waIqZX2u7zgS4CrH and 'continuationCommand' in list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys()):
				i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/my_main_page_shorts_link'
				waIqZX2u7zgS4CrH.append([Lw8JjEfuiW0VN9qHAcgRpMBdICS,i8sFwPqo1vpEXR2VdHU5BmW,'1::0::0::0'])
	return BnusDqyxU1WpN5K,K0zcx1abElRUgIkjAfJHT5yBF,waIqZX2u7zgS4CrH,tjB9zfExLwgKCJbd26opu
def D7pI0swuGVMkbaqnX1NS8(k9mjxFK3buTyeUqRMndsXB,BnusDqyxU1WpN5K,url,prZUeN9FojstVTxf0EJQBRq4zdb):
	level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = prZUeN9FojstVTxf0EJQBRq4zdb.split('::')
	Vo7hifxLTQnUR4Yr,QFVKSsCg5AeN4x0mwL19M = [],[]
	Vo7hifxLTQnUR4Yr.append("yddd[0]['itemSectionRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['reloadContinuationItemsCommand']['continuationItems']")
	Vo7hifxLTQnUR4Yr.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: Vo7hifxLTQnUR4Yr.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: Vo7hifxLTQnUR4Yr.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yddd["+TQC80zSMLtx+"]")
	Q7MGl5hPgXzB26c,rp03JXomkTOFYLU4EDzViWK7P,m4mY7F1MNc28rvqSXs3ukDpOy = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(BnusDqyxU1WpN5K,'',Vo7hifxLTQnUR4Yr)
	if level=='2' and Q7MGl5hPgXzB26c:
		if len(rp03JXomkTOFYLU4EDzViWK7P)>1:
			for qOoBk5C34pJHFAhY in range(len(rp03JXomkTOFYLU4EDzViWK7P)):
				aS861DtepGP = str(qOoBk5C34pJHFAhY)
				Vo7hifxLTQnUR4Yr = []
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['richSectionRenderer']['content']")
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]")
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['richItemRenderer']['content']")
				Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]")
				UkYj1KP0ou4q9rVfEgn2JQHI56BG,Lw8JjEfuiW0VN9qHAcgRpMBdICS,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(rp03JXomkTOFYLU4EDzViWK7P,'',Vo7hifxLTQnUR4Yr)
				if UkYj1KP0ou4q9rVfEgn2JQHI56BG: QFVKSsCg5AeN4x0mwL19M.append([Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,'3::'+TQC80zSMLtx+'::'+aS861DtepGP+'::0'])
			Vo7hifxLTQnUR4Yr.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			Vo7hifxLTQnUR4Yr.append("yddd[1]")
			UkYj1KP0ou4q9rVfEgn2JQHI56BG,Lw8JjEfuiW0VN9qHAcgRpMBdICS,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(BnusDqyxU1WpN5K,'',Vo7hifxLTQnUR4Yr)
			if UkYj1KP0ou4q9rVfEgn2JQHI56BG and QFVKSsCg5AeN4x0mwL19M and 'continuationItemRenderer' in list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys()):
				QFVKSsCg5AeN4x0mwL19M.append([Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,'3::0::0::0'])
	return rp03JXomkTOFYLU4EDzViWK7P,Q7MGl5hPgXzB26c,QFVKSsCg5AeN4x0mwL19M,m4mY7F1MNc28rvqSXs3ukDpOy
def JfGY8xOpzaXo(k9mjxFK3buTyeUqRMndsXB,rp03JXomkTOFYLU4EDzViWK7P,url,prZUeN9FojstVTxf0EJQBRq4zdb):
	level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = prZUeN9FojstVTxf0EJQBRq4zdb.split('::')
	Vo7hifxLTQnUR4Yr,gd96KVIAXPjc52R3aWhCnfeHokEi = [],[]
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['reelShelfRenderer']['items']")
	Vo7hifxLTQnUR4Yr.append("yeee["+aS861DtepGP+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Vo7hifxLTQnUR4Yr.append("yeee")
	DZ3eAhSrpa9kvG8,XVbGq8DYI42im5MTKON,fTURN1LhXltKqxAb = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(rp03JXomkTOFYLU4EDzViWK7P,'',Vo7hifxLTQnUR4Yr)
	if level=='3' and DZ3eAhSrpa9kvG8:
		if len(XVbGq8DYI42im5MTKON)>0:
			for qOoBk5C34pJHFAhY in range(len(XVbGq8DYI42im5MTKON)):
				ZGnvFShrNbB = str(qOoBk5C34pJHFAhY)
				Vo7hifxLTQnUR4Yr = []
				Vo7hifxLTQnUR4Yr.append("yfff["+ZGnvFShrNbB+"]['richItemRenderer']['content']")
				Vo7hifxLTQnUR4Yr.append("yfff["+ZGnvFShrNbB+"]['gameCardRenderer']['game']")
				Vo7hifxLTQnUR4Yr.append("yfff["+ZGnvFShrNbB+"]['itemSectionRenderer']['contents'][0]")
				Vo7hifxLTQnUR4Yr.append("yfff["+ZGnvFShrNbB+"]")
				UkYj1KP0ou4q9rVfEgn2JQHI56BG,Lw8JjEfuiW0VN9qHAcgRpMBdICS,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(XVbGq8DYI42im5MTKON,'',Vo7hifxLTQnUR4Yr)
				if UkYj1KP0ou4q9rVfEgn2JQHI56BG: gd96KVIAXPjc52R3aWhCnfeHokEi.append([Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,'4::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB])
	return XVbGq8DYI42im5MTKON,DZ3eAhSrpa9kvG8,gd96KVIAXPjc52R3aWhCnfeHokEi,fTURN1LhXltKqxAb
def B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF,n0tEuRyjYcxNAH):
	k9mjxFK3buTyeUqRMndsXB,dTeA53v4wIscoMEGl2YUkF = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	BnusDqyxU1WpN5K,dTeA53v4wIscoMEGl2YUkF = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	rp03JXomkTOFYLU4EDzViWK7P,dTeA53v4wIscoMEGl2YUkF = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	XVbGq8DYI42im5MTKON,dTeA53v4wIscoMEGl2YUkF = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ = INqwL4fDcG6reb5Oay,dTeA53v4wIscoMEGl2YUkF
	count = len(n0tEuRyjYcxNAH)
	for H3ABEcMzfyqwF4Ug2ZYtK in range(count):
		try:
			vvSNrxh3fm5lC = eval(n0tEuRyjYcxNAH[H3ABEcMzfyqwF4Ug2ZYtK])
			return True,vvSNrxh3fm5lC,H3ABEcMzfyqwF4Ug2ZYtK+1
		except: pass
	return False,'',0
def Dhm1GLpdYu4xwZzSQlEtvNC3ga(url,prZUeN9FojstVTxf0EJQBRq4zdb='',data=''):
	waIqZX2u7zgS4CrH,QFVKSsCg5AeN4x0mwL19M,gd96KVIAXPjc52R3aWhCnfeHokEi = [],[],[]
	if '::' not in prZUeN9FojstVTxf0EJQBRq4zdb: prZUeN9FojstVTxf0EJQBRq4zdb = '1::0::0::0'
	level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = prZUeN9FojstVTxf0EJQBRq4zdb.split('::')
	if level=='4': level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = '1',TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB
	data = data.replace('_REMEMBERRESULTS_','')
	qQXuaKpVrGLF3e5oidJ8YwDT0,k9mjxFK3buTyeUqRMndsXB,vf78LSlJQOnCsatrIH2P1iW = PdRNrfFxjV(url,data)
	prZUeN9FojstVTxf0EJQBRq4zdb = level+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
	if level in ['1','2','3']:
		BnusDqyxU1WpN5K,K0zcx1abElRUgIkjAfJHT5yBF,waIqZX2u7zgS4CrH,tjB9zfExLwgKCJbd26opu = CGVAdK5yXjok7isuceOzwbhtxLZvBp(k9mjxFK3buTyeUqRMndsXB,url,prZUeN9FojstVTxf0EJQBRq4zdb)
		if not K0zcx1abElRUgIkjAfJHT5yBF: return
		WHOp2fLzuxw0 = len(waIqZX2u7zgS4CrH)
		if WHOp2fLzuxw0<2:
			if level=='1': level = '2'
			waIqZX2u7zgS4CrH = []
	prZUeN9FojstVTxf0EJQBRq4zdb = level+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
	if level in ['2','3']:
		rp03JXomkTOFYLU4EDzViWK7P,Q7MGl5hPgXzB26c,QFVKSsCg5AeN4x0mwL19M,m4mY7F1MNc28rvqSXs3ukDpOy = D7pI0swuGVMkbaqnX1NS8(k9mjxFK3buTyeUqRMndsXB,BnusDqyxU1WpN5K,url,prZUeN9FojstVTxf0EJQBRq4zdb)
		if not Q7MGl5hPgXzB26c: return
		CElKTRWY8vg3zXI6h = len(QFVKSsCg5AeN4x0mwL19M)
		if CElKTRWY8vg3zXI6h<2:
			if level=='2': level = '3'
			QFVKSsCg5AeN4x0mwL19M = []
	prZUeN9FojstVTxf0EJQBRq4zdb = level+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
	if level in ['3']:
		XVbGq8DYI42im5MTKON,DZ3eAhSrpa9kvG8,gd96KVIAXPjc52R3aWhCnfeHokEi,fTURN1LhXltKqxAb = JfGY8xOpzaXo(k9mjxFK3buTyeUqRMndsXB,rp03JXomkTOFYLU4EDzViWK7P,url,prZUeN9FojstVTxf0EJQBRq4zdb)
		if not DZ3eAhSrpa9kvG8: return
		w3nxBMaryO26U0SqPFi = len(gd96KVIAXPjc52R3aWhCnfeHokEi)
	for Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,prZUeN9FojstVTxf0EJQBRq4zdb in waIqZX2u7zgS4CrH+QFVKSsCg5AeN4x0mwL19M+gd96KVIAXPjc52R3aWhCnfeHokEi:
		O4iyumrz1QjMnUDeTk3 = rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS,url,prZUeN9FojstVTxf0EJQBRq4zdb)
	return
def rcN12ObjvUWAKLPFTey(Lw8JjEfuiW0VN9qHAcgRpMBdICS,url='',prZUeN9FojstVTxf0EJQBRq4zdb=''):
	if '::' in prZUeN9FojstVTxf0EJQBRq4zdb: level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = prZUeN9FojstVTxf0EJQBRq4zdb.split('::')
	else: level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = '1','0','0','0'
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV,CAcx1g9QbMdSEyphFf706slBz5iIP = EX8tudg02NvU9b67yoZRkDS(Lw8JjEfuiW0VN9qHAcgRpMBdICS)
	nAmfSN0Y93jC14Fa5T8oe = '/videos?' in i8sFwPqo1vpEXR2VdHU5BmW or '/streams?' in i8sFwPqo1vpEXR2VdHU5BmW or '/playlists?' in i8sFwPqo1vpEXR2VdHU5BmW
	lZXnrY7EFm4o8UQh1B = '/channels?' in i8sFwPqo1vpEXR2VdHU5BmW or '/shorts?' in i8sFwPqo1vpEXR2VdHU5BmW
	if nAmfSN0Y93jC14Fa5T8oe or lZXnrY7EFm4o8UQh1B: i8sFwPqo1vpEXR2VdHU5BmW = url
	nAmfSN0Y93jC14Fa5T8oe = 'watch?v=' not in i8sFwPqo1vpEXR2VdHU5BmW and '/playlist?list=' not in i8sFwPqo1vpEXR2VdHU5BmW
	lZXnrY7EFm4o8UQh1B = '/gaming' not in i8sFwPqo1vpEXR2VdHU5BmW  and '/feed/storefront' not in i8sFwPqo1vpEXR2VdHU5BmW
	if prZUeN9FojstVTxf0EJQBRq4zdb[0:5]=='3::0::' and nAmfSN0Y93jC14Fa5T8oe and lZXnrY7EFm4o8UQh1B: i8sFwPqo1vpEXR2VdHU5BmW = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in i8sFwPqo1vpEXR2VdHU5BmW:
		level,TQC80zSMLtx,aS861DtepGP,ZGnvFShrNbB = '1','0','0','0'
		prZUeN9FojstVTxf0EJQBRq4zdb = ''
	vf78LSlJQOnCsatrIH2P1iW = ''
	if '/youtubei/v1/browse' in i8sFwPqo1vpEXR2VdHU5BmW or '/youtubei/v1/search' in i8sFwPqo1vpEXR2VdHU5BmW or '/my_main_page_shorts_link' in url:
		data = YTPut68WBVUNCvsEzg.getSetting('av.youtube.data')
		if data.count(':::')==4:
			TrME71fOa2lNRFoQVSnBd8etqJZXC,key,vCMOKk7Y2hqfcx53Ni9IRsem,PI628YnaNF,cGaExo7bmhAn2QwIgMpWfzO = data.split(':::')
			vf78LSlJQOnCsatrIH2P1iW = TrME71fOa2lNRFoQVSnBd8etqJZXC+':::'+key+':::'+vCMOKk7Y2hqfcx53Ni9IRsem+':::'+PI628YnaNF+':::'+CAcx1g9QbMdSEyphFf706slBz5iIP
			if '/my_main_page_shorts_link' in url and not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = url
			else: i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW+'?key='+key
	if not title:
		global cjqX9vFRix3Udo0htaWQ1COYm2
		cjqX9vFRix3Udo0htaWQ1COYm2 += 1
		title = 'فيديوهات '+str(cjqX9vFRix3Udo0htaWQ1COYm2)
		prZUeN9FojstVTxf0EJQBRq4zdb = '3'+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
	if not UkYj1KP0ou4q9rVfEgn2JQHI56BG: return False
	elif 'searchPyvRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS): return False
	elif '/about' in i8sFwPqo1vpEXR2VdHU5BmW: return False
	elif '/community' in i8sFwPqo1vpEXR2VdHU5BmW: return False
	elif 'continuationItemRenderer' in list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys()) or 'continuationCommand' in list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys()):
		if int(level)>1: level = str(int(level)-1)
		prZUeN9FojstVTxf0EJQBRq4zdb = level+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+':: '+'صفحة أخرى',i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb,vf78LSlJQOnCsatrIH2P1iW)
	elif '/search' in i8sFwPqo1vpEXR2VdHU5BmW:
		title = ':: '+title
		prZUeN9FojstVTxf0EJQBRq4zdb = '3'+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
		url = url.replace('/search','')
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,145,'',prZUeN9FojstVTxf0EJQBRq4zdb,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not i8sFwPqo1vpEXR2VdHU5BmW:
		prZUeN9FojstVTxf0EJQBRq4zdb = '3'+'::'+TQC80zSMLtx+'::'+aS861DtepGP+'::'+ZGnvFShrNbB
		title = ':: '+title
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb,vf78LSlJQOnCsatrIH2P1iW)
	elif '/browse' in i8sFwPqo1vpEXR2VdHU5BmW and url==HbiLZQKalC:
		title = ':: '+title
		prZUeN9FojstVTxf0EJQBRq4zdb = '2::0::0::0'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb,vf78LSlJQOnCsatrIH2P1iW)
	elif not i8sFwPqo1vpEXR2VdHU5BmW and 'horizontalMovieListRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS):
		title = ':: '+title
		prZUeN9FojstVTxf0EJQBRq4zdb = '3::0::0::0'
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,url,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb)
	elif 'messageRenderer' in str(Lw8JjEfuiW0VN9qHAcgRpMBdICS):
		QQmLIZC8uas9fNiJWOnhdGvgFR('link',JJCLnkX4TozH7Bsjivfe+title,'',9999)
	elif hhuOs8xl1wSj:
		QQmLIZC8uas9fNiJWOnhdGvgFR('live',JJCLnkX4TozH7Bsjivfe+hhuOs8xl1wSj+title,i8sFwPqo1vpEXR2VdHU5BmW,143,o3gHuBtrRN)
	elif '/playlist?list=' in i8sFwPqo1vpEXR2VdHU5BmW:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'LIST'+count+':  '+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb)
	elif '/shorts/' in i8sFwPqo1vpEXR2VdHU5BmW:
		i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&list=',1)[0]
		QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,143,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	elif '/watch?v=' in i8sFwPqo1vpEXR2VdHU5BmW:
		if '&list=' in i8sFwPqo1vpEXR2VdHU5BmW and count:
			WvyHJwCMuKZd = i8sFwPqo1vpEXR2VdHU5BmW.split('&list=',1)[1]
			i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+'/playlist?list='+WvyHJwCMuKZd
			prZUeN9FojstVTxf0EJQBRq4zdb = '3::0::0::0'
			QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'LIST'+count+':  '+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb)
		else:
			i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.split('&list=',1)[0]
			QQmLIZC8uas9fNiJWOnhdGvgFR('video',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,143,o3gHuBtrRN,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab)
	elif '/channel/' in i8sFwPqo1vpEXR2VdHU5BmW or '/c/' in i8sFwPqo1vpEXR2VdHU5BmW or ('/@' in i8sFwPqo1vpEXR2VdHU5BmW and i8sFwPqo1vpEXR2VdHU5BmW.count('/')==3):
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'CHNL'+count+':  '+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb)
	elif '/user/' in i8sFwPqo1vpEXR2VdHU5BmW:
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+'USER'+count+':  '+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb)
	else:
		if not i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = url
		title = ':: '+title
		QQmLIZC8uas9fNiJWOnhdGvgFR('folder',JJCLnkX4TozH7Bsjivfe+title,i8sFwPqo1vpEXR2VdHU5BmW,144,o3gHuBtrRN,prZUeN9FojstVTxf0EJQBRq4zdb,vf78LSlJQOnCsatrIH2P1iW)
	return True
def EX8tudg02NvU9b67yoZRkDS(Lw8JjEfuiW0VN9qHAcgRpMBdICS):
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV,cGaExo7bmhAn2QwIgMpWfzO = False,'','','','','','','',''
	if not isinstance(Lw8JjEfuiW0VN9qHAcgRpMBdICS,dict): return UkYj1KP0ou4q9rVfEgn2JQHI56BG,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV,cGaExo7bmhAn2QwIgMpWfzO
	for YMXkRA2jOHDy0IgLSrJVaNqhTWZ in list(Lw8JjEfuiW0VN9qHAcgRpMBdICS.keys()):
		jsbu6rShT24aZ = Lw8JjEfuiW0VN9qHAcgRpMBdICS[YMXkRA2jOHDy0IgLSrJVaNqhTWZ]
		if isinstance(jsbu6rShT24aZ,dict): break
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['header']['richListHeaderRenderer']['title']")
	Vo7hifxLTQnUR4Yr.append("yrender['headline']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['unplayableText']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['formattedTitle']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['title']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['title']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("yrender['text']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['text']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("yrender['title']")
	Vo7hifxLTQnUR4Yr.append("item['title']")
	Vo7hifxLTQnUR4Yr.append("item['reelWatchEndpoint']['videoId']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,title,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Vo7hifxLTQnUR4Yr.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Vo7hifxLTQnUR4Yr.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vo7hifxLTQnUR4Yr.append("item['commandMetadata']['webCommandMetadata']['url']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,i8sFwPqo1vpEXR2VdHU5BmW,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnail']['thumbnails'][0]['url']")
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	Vo7hifxLTQnUR4Yr.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,o3gHuBtrRN,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['videoCount']")
	Vo7hifxLTQnUR4Yr.append("yrender['videoCountText']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,count,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['lengthText']['simpleText']")
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	Vo7hifxLTQnUR4Yr.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	Vo7hifxLTQnUR4Yr = []
	Vo7hifxLTQnUR4Yr.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	Vo7hifxLTQnUR4Yr.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	UkYj1KP0ou4q9rVfEgn2JQHI56BG,cGaExo7bmhAn2QwIgMpWfzO,IMC3E9dFHnu2QSTy6DUPczBi0qk = B1zMX4ibgtwxJ8Lk9a5Yvh6OWA(Lw8JjEfuiW0VN9qHAcgRpMBdICS,jsbu6rShT24aZ,Vo7hifxLTQnUR4Yr)
	if 'LIVE' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj = '','LIVE:  '
	if 'مباشر' in fOFNhC5n6laPDvK1Mtz9QYxZ0Ab: fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj = '','LIVE:  '
	if 'badges' in list(jsbu6rShT24aZ.keys()):
		dWURt1bqeKDkAZiM4uc72rCNJ9sfIL = str(jsbu6rShT24aZ['badges'])
		if 'Free with Ads' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$:  '
		if 'LIVE' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: hhuOs8xl1wSj = 'LIVE:  '
		if 'Buy' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL or 'Rent' in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:  '
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'مباشر') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: hhuOs8xl1wSj = 'LIVE:  '
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'شراء') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:  '
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'استئجار') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$$:  '
		if y357f08uQISUGLr6qOwdTBCcnWsv(u'إعلانات') in dWURt1bqeKDkAZiM4uc72rCNJ9sfIL: fojP2LBizNGFK4ctQ9UV = '$:  '
	i8sFwPqo1vpEXR2VdHU5BmW = Bd2o0J6aOASWvuD9HzY(i8sFwPqo1vpEXR2VdHU5BmW)
	if i8sFwPqo1vpEXR2VdHU5BmW and 'http' not in i8sFwPqo1vpEXR2VdHU5BmW: i8sFwPqo1vpEXR2VdHU5BmW = HbiLZQKalC+i8sFwPqo1vpEXR2VdHU5BmW
	o3gHuBtrRN = o3gHuBtrRN.split('?')[0]
	if  o3gHuBtrRN and 'http' not in o3gHuBtrRN: o3gHuBtrRN = 'https:'+o3gHuBtrRN
	title = Bd2o0J6aOASWvuD9HzY(title)
	if fojP2LBizNGFK4ctQ9UV: title = fojP2LBizNGFK4ctQ9UV+title
	fOFNhC5n6laPDvK1Mtz9QYxZ0Ab = fOFNhC5n6laPDvK1Mtz9QYxZ0Ab.replace(',','')
	count = count.replace(',','')
	count = T072lCzjYiuaeFtmJGV.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,i8sFwPqo1vpEXR2VdHU5BmW,o3gHuBtrRN,count,fOFNhC5n6laPDvK1Mtz9QYxZ0Ab,hhuOs8xl1wSj,fojP2LBizNGFK4ctQ9UV,cGaExo7bmhAn2QwIgMpWfzO
def PdRNrfFxjV(url,data='',iYvJPtR357SbyQf1=''):
	if iYvJPtR357SbyQf1=='': iYvJPtR357SbyQf1 = 'ytInitialData'
	zslrWLD38jgdn = diwUZMEagkFDlS()
	JKf4Tsxu9S23FI7mV5DGLk = {'User-Agent':zslrWLD38jgdn,'Cookie':'PREF=hl=ar'}
	global YTPut68WBVUNCvsEzg
	if not data: data = YTPut68WBVUNCvsEzg.getSetting('av.youtube.data')
	if data.count(':::')==4: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,vCMOKk7Y2hqfcx53Ni9IRsem,PI628YnaNF,cGaExo7bmhAn2QwIgMpWfzO = data.split(':::')
	else: TrME71fOa2lNRFoQVSnBd8etqJZXC,key,vCMOKk7Y2hqfcx53Ni9IRsem,PI628YnaNF,cGaExo7bmhAn2QwIgMpWfzO = '','','','',''
	vf78LSlJQOnCsatrIH2P1iW = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":vCMOKk7Y2hqfcx53Ni9IRsem}}}
	if url==HbiLZQKalC+'/shorts' or '/my_main_page_shorts_link' in url:
		url = HbiLZQKalC+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		vf78LSlJQOnCsatrIH2P1iW['sequenceParams'] = TrME71fOa2lNRFoQVSnBd8etqJZXC
		vf78LSlJQOnCsatrIH2P1iW = str(vf78LSlJQOnCsatrIH2P1iW)
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = HbiLZQKalC+'/youtubei/v1/guide?key='+key
		vf78LSlJQOnCsatrIH2P1iW = str(vf78LSlJQOnCsatrIH2P1iW)
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and TrME71fOa2lNRFoQVSnBd8etqJZXC:
		vf78LSlJQOnCsatrIH2P1iW['continuation'] = cGaExo7bmhAn2QwIgMpWfzO
		vf78LSlJQOnCsatrIH2P1iW['context']['client']['visitorData'] = TrME71fOa2lNRFoQVSnBd8etqJZXC
		vf78LSlJQOnCsatrIH2P1iW = str(vf78LSlJQOnCsatrIH2P1iW)
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'POST',url,vf78LSlJQOnCsatrIH2P1iW,JKf4Tsxu9S23FI7mV5DGLk,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and PI628YnaNF:
		JKf4Tsxu9S23FI7mV5DGLk.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':vCMOKk7Y2hqfcx53Ni9IRsem})
		JKf4Tsxu9S23FI7mV5DGLk.update({'Cookie':'VISITOR_INFO1_LIVE='+PI628YnaNF})
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		WM1buqXnzf3Ba6Vp29l4gFD = lSFHaMs1enNVw7biRYOG90UcPjQz(j9t7FmfZiE6pYGI8V4u,'GET',url,'',JKf4Tsxu9S23FI7mV5DGLk,'','','YOUTUBE-GET_PAGE_DATA-6th')
	qQXuaKpVrGLF3e5oidJ8YwDT0 = WM1buqXnzf3Ba6Vp29l4gFD.content
	mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('"innertubeApiKey".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if mnN8GgS1XEePILK0DC49qky6UzZ: key = mnN8GgS1XEePILK0DC49qky6UzZ[0]
	mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('"cver".*?"value".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if mnN8GgS1XEePILK0DC49qky6UzZ: vCMOKk7Y2hqfcx53Ni9IRsem = mnN8GgS1XEePILK0DC49qky6UzZ[0]
	mnN8GgS1XEePILK0DC49qky6UzZ = T072lCzjYiuaeFtmJGV.findall('"visitorData".*?"(.*?)"',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL|T072lCzjYiuaeFtmJGV.I)
	if mnN8GgS1XEePILK0DC49qky6UzZ: TrME71fOa2lNRFoQVSnBd8etqJZXC = mnN8GgS1XEePILK0DC49qky6UzZ[0]
	cookies = WM1buqXnzf3Ba6Vp29l4gFD.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): PI628YnaNF = cookies['VISITOR_INFO1_LIVE']
	a0EhiOzZL8Ktk4y = TrME71fOa2lNRFoQVSnBd8etqJZXC+':::'+key+':::'+vCMOKk7Y2hqfcx53Ni9IRsem+':::'+PI628YnaNF+':::'+cGaExo7bmhAn2QwIgMpWfzO
	if iYvJPtR357SbyQf1=='ytInitialData' and 'ytInitialData' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('window\["ytInitialData"\] = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		if not b6iohEnHy4zM: b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('var ytInitialData = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',b6iohEnHy4zM[0])
	elif iYvJPtR357SbyQf1=='ytInitialGuideData' and 'ytInitialGuideData' in qQXuaKpVrGLF3e5oidJ8YwDT0:
		b6iohEnHy4zM = T072lCzjYiuaeFtmJGV.findall('var ytInitialGuideData = ({.*?});',qQXuaKpVrGLF3e5oidJ8YwDT0,T072lCzjYiuaeFtmJGV.DOTALL)
		kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',b6iohEnHy4zM[0])
	elif '</script>' not in qQXuaKpVrGLF3e5oidJ8YwDT0: kRscYlFxGTCMrU = cwiLy4IAVJj0pWCl7FGxokR('str',qQXuaKpVrGLF3e5oidJ8YwDT0)
	else: kRscYlFxGTCMrU = ''
	if 0:
		k9mjxFK3buTyeUqRMndsXB = str(kRscYlFxGTCMrU)
		if mmIKCGujwM: k9mjxFK3buTyeUqRMndsXB = k9mjxFK3buTyeUqRMndsXB.encode('utf8')
		open('S:\\0000emad.dat','wb').write(k9mjxFK3buTyeUqRMndsXB)
	YTPut68WBVUNCvsEzg.setSetting('av.youtube.data',a0EhiOzZL8Ktk4y)
	return qQXuaKpVrGLF3e5oidJ8YwDT0,kRscYlFxGTCMrU,a0EhiOzZL8Ktk4y
def Qls1PoHZJGD4wmfpAV3cMxn567e(url,prZUeN9FojstVTxf0EJQBRq4zdb):
	search = NWs7KpjXGnxYylofHtd5U3wDh()
	if not search: return
	search = search.replace(' ','+')
	ll9khUfx3MjZ = url+'/search?query='+search
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(ll9khUfx3MjZ,prZUeN9FojstVTxf0EJQBRq4zdb)
	return
def CXz8MpZeQigHAjw47TlbhdcPYoaWG(search):
	search,ZNpFGHa28C9WcoRb,showDialogs = o0Vixfg9ANze1OshdmaX(search)
	if not search:
		search = NWs7KpjXGnxYylofHtd5U3wDh()
		if not search: return
	search = search.replace(' ','+')
	ll9khUfx3MjZ = HbiLZQKalC+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in ZNpFGHa28C9WcoRb: RXEDMq1wdne2kIQ7mGgJLhvV = '&sp=EgIQAg%253D%253D'
		else: RXEDMq1wdne2kIQ7mGgJLhvV = ''
		dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+RXEDMq1wdne2kIQ7mGgJLhvV
	else:
		pRDZxuqijwB2cH,XaFPemq5UC,tKBSN4Zgn9CDb = [],[],''
		yGm8WdY9Cka6N3w5r1 = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		oejZysl0QMLT2Y8aUFmfnhCNb = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		uulRAafXCtceoDY = sSOy1pju5PJ('موقع يوتيوب - اختر الترتيب',yGm8WdY9Cka6N3w5r1)
		if uulRAafXCtceoDY == -1: return
		DXpBL6TNzIt1U8u2bGo9xaRdVs0m = oejZysl0QMLT2Y8aUFmfnhCNb[uulRAafXCtceoDY]
		qQXuaKpVrGLF3e5oidJ8YwDT0,ZonORjX61Mm,data = PdRNrfFxjV(ll9khUfx3MjZ+DXpBL6TNzIt1U8u2bGo9xaRdVs0m)
		if ZonORjX61Mm:
			try:
				WnLsKcpfaYR2ZrJ9GotbVMv = ZonORjX61Mm['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for pqaxMNGvlH in range(len(WnLsKcpfaYR2ZrJ9GotbVMv)):
					group = WnLsKcpfaYR2ZrJ9GotbVMv[pqaxMNGvlH]['searchFilterGroupRenderer']['filters']
					for N7DULISGiyX8ouBVJ2PwMnHr49a in range(len(group)):
						jsbu6rShT24aZ = group[N7DULISGiyX8ouBVJ2PwMnHr49a]['searchFilterRenderer']
						if 'navigationEndpoint' in list(jsbu6rShT24aZ.keys()):
							i8sFwPqo1vpEXR2VdHU5BmW = jsbu6rShT24aZ['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							i8sFwPqo1vpEXR2VdHU5BmW = i8sFwPqo1vpEXR2VdHU5BmW.replace('\u0026','&')
							title = jsbu6rShT24aZ['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								tKBSN4Zgn9CDb = title
								K9K307bTvRVtO6i = i8sFwPqo1vpEXR2VdHU5BmW
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								tKBSN4Zgn9CDb = title
								K9K307bTvRVtO6i = i8sFwPqo1vpEXR2VdHU5BmW
							if 'Sort by' in title: continue
							pRDZxuqijwB2cH.append(Bd2o0J6aOASWvuD9HzY(title))
							XaFPemq5UC.append(i8sFwPqo1vpEXR2VdHU5BmW)
			except: pass
		if not tKBSN4Zgn9CDb: Uzf7r6tg3QjkdbLTaqZ0 = ''
		else:
			pRDZxuqijwB2cH = ['بدون فلتر',tKBSN4Zgn9CDb]+pRDZxuqijwB2cH
			XaFPemq5UC = ['',K9K307bTvRVtO6i]+XaFPemq5UC
			fZT9IHMakwXv = sSOy1pju5PJ('موقع يوتيوب - اختر الفلتر',pRDZxuqijwB2cH)
			if fZT9IHMakwXv == -1: return
			Uzf7r6tg3QjkdbLTaqZ0 = XaFPemq5UC[fZT9IHMakwXv]
		if Uzf7r6tg3QjkdbLTaqZ0: dCmKxk9BW310AXu4bJUHfY = HbiLZQKalC+Uzf7r6tg3QjkdbLTaqZ0
		elif DXpBL6TNzIt1U8u2bGo9xaRdVs0m: dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ+DXpBL6TNzIt1U8u2bGo9xaRdVs0m
		else: dCmKxk9BW310AXu4bJUHfY = ll9khUfx3MjZ
	Dhm1GLpdYu4xwZzSQlEtvNC3ga(dCmKxk9BW310AXu4bJUHfY)
	return
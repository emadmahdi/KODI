# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ䳢")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬ䳣")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧศ่๋ห฾ࠦวโๆส้ࠬ䳤"),l11lll_l1_ (u"ࠨฮ๋ำฬะࠠศใ็ห๊࠭䳥")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1111l_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1llllll_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䳦"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䳧"),l11lll_l1_ (u"ࠫࠬ䳨"),389,l11lll_l1_ (u"ࠬ࠭䳩"),l11lll_l1_ (u"࠭ࠧ䳪"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䳫"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䳬"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䳭"),l11lll_l1_ (u"ࠪࠫ䳮"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䳯"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䳰")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ䳱"),l11ll1_l1_,381,l11lll_l1_ (u"ࠧࠨ䳲"),l11lll_l1_ (u"ࠨࠩ䳳"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ䳴"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䳵"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䳶")+l111ll_l1_+l11lll_l1_ (u"ࠬอไอษ้ฬ๏ฯࠧ䳷"),l11ll1_l1_,381,l11lll_l1_ (u"࠭ࠧ䳸"),l11lll_l1_ (u"ࠧࠨ䳹"),l11lll_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ䳺"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䳻"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ䳼"),l11lll_l1_ (u"ࠫࠬ䳽"),l11lll_l1_ (u"ࠬ࠭䳾"),l11lll_l1_ (u"࠭ࠧ䳿"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䴀"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴁"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䴂"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䴃")+l111ll_l1_+title,l11ll1_l1_,381,l11lll_l1_ (u"ࠫࠬ䴄"),l11lll_l1_ (u"ࠬ࠭䴅"),l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䴆")+str(seq))
	block = l11lll_l1_ (u"ࠧࠨ䴇")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡦࡦࡲࡶࠧ࠭䴈"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭䴉"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䴊"),block,re.DOTALL)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䴋"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䴌"),l11lll_l1_ (u"࠭ࠧ䴍"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠧศๆฦ฽้๏ࠠๆึส๋ิฯࠧ䴎"):
			if first:
				title = l11lll_l1_ (u"ࠨษ็หๆ๊วๆࠢࠪ䴏")+title
				first = False
			else: title = l11lll_l1_ (u"ࠩสู่๊ไิๆสฮࠥ࠭䴐")+title
		if title not in l1l1l1_l1_:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䴑"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䴒")+l111ll_l1_+title,link,381)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䴓"),l11lll_l1_ (u"࠭ࠧ䴔"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䴕"),url,l11lll_l1_ (u"ࠨࠩ䴖"),l11lll_l1_ (u"ࠩࠪ䴗"),l11lll_l1_ (u"ࠪࠫ䴘"),l11lll_l1_ (u"ࠫࠬ䴙"),l11lll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䴚"))
	html = response.content
	if type==l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䴛"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡤࡶࡨ࡮࠭ࡱࡣࡪࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ䴜"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䴝"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ䴞"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠧ䴟"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		z = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䴠"),block,re.DOTALL)
		l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_ = zip(*z)
		items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䴡"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࡵ࠰ࡸࡻࡹࡨࡰࡹࡶࠦ࠭࠴ࠪࡀࠫ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䴢"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䴣"),block,re.DOTALL)
	elif l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ䴤") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ䴥"),l11lll_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡶࡸࡦࡸࡴ࠿ࠩ䴦"))
		html = html.replace(l11lll_l1_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䴧"),l11lll_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䴨"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡶࡤࡶࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡮ࡥࡀࠪ䴩"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==2: items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䴪"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠩࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࢁࡹࡩࡥࡧࡥࡥࡷ࠯ࠧ䴫"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ䴬") in url:
				items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䴭"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠫ࠴ࡷࡵࡢ࡮࡬ࡸࡾ࠵ࠧ䴮") in url:
				items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䴯"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䴰"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭䴱") in title:
			title = re.findall(l11lll_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䴲"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭䴳")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䴴")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ䴵"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ䴶") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䴷"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䴸") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䴹"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ䴺") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䴻"),l111ll_l1_+title,link,383,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ䴼") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䴽"),l111ll_l1_+title,link,381,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䴾"),l111ll_l1_+title,link,382,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࡑࡣࡪࡩࠥ࠮࠮ࠫࡁࠬࠤࡴ࡬ࠠࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䴿"),html,re.DOTALL)
	if l1l1ll1_l1_:
		current = l1l1ll1_l1_[0][0]
		last = l1l1ll1_l1_[0][1]
		block = l1l1ll1_l1_[0][2]
		items = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥ䵀"),block,re.DOTALL)
		for link,title in items:
			if title==l11lll_l1_ (u"ࠩࠪ䵁") or title==last: continue
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䵂"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ䵃")+title,link,381,l11lll_l1_ (u"ࠬ࠭䵄"),l11lll_l1_ (u"࠭ࠧ䵅"),type)
		#if title==last:
		link = link.replace(l11lll_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ䵆")+title+l11lll_l1_ (u"ࠨ࠱ࠪ䵇"),l11lll_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ䵈")+last+l11lll_l1_ (u"ࠪ࠳ࠬ䵉"))
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䵊"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮาุࠢๅาฯࠠࠨ䵋")+last,link,381,l11lll_l1_ (u"࠭ࠧ䵌"),l11lll_l1_ (u"ࠧࠨ䵍"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䵎"),url,l11lll_l1_ (u"ࠩࠪ䵏"),l11lll_l1_ (u"ࠪࠫ䵐"),l11lll_l1_ (u"ࠫࠬ䵑"),l11lll_l1_ (u"ࠬ࠭䵒"),l11lll_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䵓"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ䵔"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,False):
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䵕"),l111ll_l1_+l11lll_l1_ (u"ࠩสู่๊ไิๆ่้้ࠣศศำࠣ์ฬ๊ๅษำ่ะ๋ࠥๆฺ้ࠪ䵖"),l11lll_l1_ (u"ࠪࠫ䵗"),9999)
		return
	if l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ䵘") in url or l11lll_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ䵙") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨ࡫ࡷࡩࡲ࠭࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ䵚"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[1]
			l1llllll_l1_(l11l11l_l1_)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠬ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡣࡶࡸࠧ࠭ࠧࠨ䵛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡲࡺࡳࡥࡳࡣࡱࡨࡴ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ䵜"),block,re.DOTALL)
		for l1llll_l1_,l1lll11_l1_,link,name in items:
			title = l1lll11_l1_+l11lll_l1_ (u"ࠩࠣ࠾ࠥ࠭䵝")+name+l11lll_l1_ (u"ࠪࠤฬ๊อๅไฬࠫ䵞")
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䵟"),l111ll_l1_+title,link,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䵠"),url,l11lll_l1_ (u"࠭ࠧ䵡"),l11lll_l1_ (u"ࠧࠨ䵢"),l11lll_l1_ (u"ࠨࠩ䵣"),l11lll_l1_ (u"ࠩࠪ䵤"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䵥"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䵦"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠨࠢࡪࡦࡀࠫࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶࠭ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠬࠧࡹࡨࡦࡣࡧࡩࡷࠨࡼࠨࡲࡤ࡫ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧࠪࠤࠥࠦ䵧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠨࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡸ࡫ࡲࡷࡧࡵࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ䵨"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䵩")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䵪")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭࠯ࡦࡰࡴࡹࡥࠣࠩ䵫"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡣࡤࡥࡤ࡭ࡡࡪࡨࡷ࡯ࡶࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䵬"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䵭")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䵮")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ䵯"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䵰"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩ䵱"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪ䵲"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ䵳"),l11lll_l1_ (u"ࠫ࠰࠭䵴"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ䵵")+search
	l1111l_l1_(url,l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭䵶"))
	return
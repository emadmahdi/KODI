# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨྕ")
#headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫྖ"):l11lll_l1_ (u"ࠨࠩྗ")}
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭྘"):l1l11l11l_l1_()}
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡆࡘࡓࡠࠩྙ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ྚ"),l11lll_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬྛ"),l11lll_l1_ (u"࠭ๅึษิ฽์࠭ྜ"),l11lll_l1_ (u"ࠧศ฻็ู๊๋ࠥ็ษࠣ⠗ࠥࡌ࡯ࡳࠢࡤࡨࡸ࠭ྜྷ"),l11lll_l1_ (u"ࠨ็๋ฬฬ๐ไศฬࠪྞ"),l11lll_l1_ (u"ࠩหีฬ๋ฬࠡๅ่ฬ๏๎สาࠩྟ"),l11lll_l1_ (u"ࠪห้฿วษࠢๆ้อ๐่หำࠪྠ"),l11lll_l1_ (u"ࠫฬูไศ็ํหฯ࠭ྡ"),l11lll_l1_ (u"ࠬอฮา๋ࠪྡྷ"),l11lll_l1_ (u"࠭วใีส้ࠥอฮา์ࠪྣ"),l11lll_l1_ (u"ࠧศึอีฬ้วหࠩྤ")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l1111l_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l1llllll_l1_(url)
	elif mode==254: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨྥ")+text)
	elif mode==255: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ྦ")+text)
	elif mode==256: results = l1l11l_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧྦྷ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳࡡࡪࡰࠪྨ"),l11lll_l1_ (u"ࠬ࠭ྩ"),headers,l11lll_l1_ (u"࠭ࠧྪ"),l11lll_l1_ (u"ࠧࠨྫ"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬྫྷ"))
	html = response.content
	#l11l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨྭ"),html,re.DOTALL)
	#if l11l1l1l_l1_: l11l1l1l_l1_ = SERVER(l11l1l1l_l1_[0],l11lll_l1_ (u"ࠪࡹࡷࡲࠧྮ"))
	#else: l11l1l1l_l1_ = l11ll1_l1_
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫྯ"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬྰ"),l11lll_l1_ (u"࠭ࠧྱ"),259,l11lll_l1_ (u"ࠧࠨྲ"),l11lll_l1_ (u"ࠨࠩླ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ྴ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྵ"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧྶ"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭ྷ"),254)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ྸ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪྐྵ"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ฬิั๊ࠩྺ"),255)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧྻ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪྼ"),l11lll_l1_ (u"ࠫࠬ྽"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ྾"),l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ྿"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡤ࡭ࡳ࠭࿀"),251,l11lll_l1_ (u"ࠨࠩ࿁"),l11lll_l1_ (u"ࠩࠪ࿂"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳࡡࡪࡰࠪ࿃"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿄"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ࿅")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้࿆ࠬ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡤ࡭ࡳ࠭࿇"),251,l11lll_l1_ (u"ࠨࠩ࿈"),l11lll_l1_ (u"ࠩࠪ࿉"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ࿊"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿋"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ࿌")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬ࿍"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡤ࡭ࡳ࠭࿎"),251,l11lll_l1_ (u"ࠨࠩ࿏"),l11lll_l1_ (u"ࠩࠪ࿐"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ࿑"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿒"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ࿓")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮห๐࠭࿔"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡮ࡤࡸࡪࡹࡴࠨ࿕"),251,l11lll_l1_ (u"ࠨࠩ࿖"),l11lll_l1_ (u"ࠩࠪ࿗"),l11lll_l1_ (u"ࠪࡰࡦࡹࡴࡦࡵࡷࠫ࿘"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ࿙"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࿚"),l11lll_l1_ (u"࠭ࠧ࿛"),9999)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡧࡱࡹࡍ࡫ࡡࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࿜"),html,re.DOTALL)
	l11l1_l1_ = l1l11ll_l1_[0]
	l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࿝"),l11l1_l1_,re.DOTALL)
	for link,title in l1l1lll_l1_:
		title = unescapeHTML(title)
		if title not in l1l1l1_l1_ and title!=l11lll_l1_ (u"ࠩࠪ࿞"):
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ࿟") not in link: link = l11ll1_l1_+link
			#link = link.rstrip(l11lll_l1_ (u"ࠫ࠴࠭࿠")).replace(SERVER(link,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ࿡")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࿢"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ࿣")+l111ll_l1_+title,link,256)
	return html
def l1l11l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ࿤"),l11lll_l1_ (u"ࠩࠪ࿥"),l11lll_l1_ (u"ࠪࡗ࡚ࡈࡍࡆࡐࡘࠤࠥࠦࠠࠡࠩ࿦")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ࿧"),url,l11lll_l1_ (u"ࠬ࠭࿨"),headers,l11lll_l1_ (u"࠭ࠧ࿩"),l11lll_l1_ (u"ࠧࠨ࿪"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ࿫"))
	html = response.content
	if l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠫ࿬") in html: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿭"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊รไอิࠤฺ๊ว่ัฬࠫ࿮"),url,251,l11lll_l1_ (u"ࠬ࠭࿯"),l11lll_l1_ (u"࠭ࠧ࿰"),l11lll_l1_ (u"ࠧ࡮ࡱࡶࡸࠬ࿱"))
	if l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡏࡤ࡭ࡳ࡙࡬ࡪࡦࡨࡷࠬ࿲") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿳"),l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ࿴"),url,251,l11lll_l1_ (u"ࠫࠬ࿵"),l11lll_l1_ (u"ࠬ࠭࿶"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ࿷"))
	if l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪ࿸") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࿹"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			if len(l1l1ll1_l1_)>1 and type==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࿺"): block = l1l1ll1_l1_[1]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ࿻"),block,re.DOTALL)
			for link,title in items:
				l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ࿼"),title,re.DOTALL)
				try: l11ll1lll_l1_ = l1lll1lll_l1_[0][0]
				except: l11ll1lll_l1_ = l11lll_l1_ (u"ࠬ࠭࿽")
				try: l11lll111_l1_ = l1lll1lll_l1_[0][1]
				except: l11lll111_l1_ = l11lll_l1_ (u"࠭ࠧ࿾")
				l1lll1lll_l1_ = l11ll1lll_l1_+l11lll111_l1_
				l1lll1lll_l1_ = l1lll1lll_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ࿿"),l11lll_l1_ (u"ࠨࠩက"))
				#LOG_THIS(l11lll_l1_ (u"ࠩࠪခ"),str(l1lll1lll_l1_))
				if l11lll_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂࠬဂ") in title:
					l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨဃ"),title,re.DOTALL)
					if l11ll11ll_l1_: l1lll1lll_l1_ = l11ll11ll_l1_[0]
				if not l1lll1lll_l1_:
					l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪင"),title,re.DOTALL)
					if l11ll11ll_l1_: l1lll1lll_l1_ = l11ll11ll_l1_[0]
				if l1lll1lll_l1_:
					if l11lll_l1_ (u"࠭࡫ࡦࡻࡀࠫစ") in link: type = link.split(l11lll_l1_ (u"ࠧ࡬ࡧࡼࡁࠬဆ"))[1]
					else: type = l11lll_l1_ (u"ࠨࡰࡨࡻࡪࡹࡴࠨဇ")
					#link = link.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫဈ")).replace(SERVER(link,l11lll_l1_ (u"ࠪࡹࡷࡲࠧဉ")),l11ll1_l1_)
					l1lll1lll_l1_ = l1lll1lll_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭ည"))
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဋ"),l111ll_l1_+l1lll1lll_l1_,link,251,l11lll_l1_ (u"࠭ࠧဌ"),l11lll_l1_ (u"ࠧࠨဍ"),type)
	return
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩဎ"),l11lll_l1_ (u"ࠩࠪဏ"),l11lll_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠣࠤࠥࠦࠠࠨတ")+type,url)
	method,data,items = l11lll_l1_ (u"ࠫࡌࡋࡔࠨထ"),l11lll_l1_ (u"ࠬ࠭ဒ"),[]
	if type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧဓ"):
		if l11lll_l1_ (u"ࠧࡀࠩန") in url:
			l11lll1ll_l1_,l11llll11_l1_ = l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭ပ"),{}
			l11l11l_l1_,l11llll1l_l1_ = url.split(l11lll_l1_ (u"ࠩࡂࠫဖ"))
			lines = l11llll1l_l1_.split(l11lll_l1_ (u"ࠪࠪࠬဗ"))
			for line in lines:
				key,value = line.split(l11lll_l1_ (u"ࠫࡂ࠭ဘ"))
				l11llll11_l1_[key] = value
			if lines: method,url,data = l11lll1ll_l1_,l11l11l_l1_,l11llll11_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠬ࠭မ"),l11lll_l1_ (u"࠭ࠧယ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ရ"))
	html = response.content
	#html = html[99000:]
	if type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩလ"): l1l1ll1_l1_ = [html]
	elif l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫဝ") in type: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠧသ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨဟ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬาฯ๋ัࠣห้อแๅษ่࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬဠ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬအ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧဢ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭ဣ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳࡋࡱࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡲࡰࡹࡌࡪࡵࡷࠫဤ"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡆࡱࡵࡣ࡬ࡵ࠰࡙ࡑࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡆࡨ࡯ࡆ࡮ࡖࡩࡪࡪࠢࠨဥ"),html,re.DOTALL)
	if l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ဦ") in type:
		block = l1l1ll1_l1_[0]
		zz = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡱࡧࡺࡺ࠰࠭ࡃࠥ࠮ࡳࡳࡥࡿࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫ࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩဧ"),block,re.DOTALL)
		if zz:
			l1111_l1_,l1lll1ll_l1_,l1l1111ll_l1_,l1l11ll11_l1_ = zip(*zz)
			items = zip(l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_)
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࡁࡳࡧࡤ࠲࠯ࡅࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭࡝ࡹࡾ࠷࠱࠻ࡽ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪဨ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠧࡘ࡙ࡈࠫဩ") in title: continue
		#link = link.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪဪ")).replace(SERVER(link,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ါ")),l11ll1_l1_)
		#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬာ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨိ")),l11ll1_l1_)
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠬอไฮๆๅอࠬီ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩု"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ူ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨေ"),l111ll_l1_+title,link,253,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨဲ"),l111ll_l1_+title,link,252,l1llll_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬဳ") in link or l11lll_l1_ (u"ู๊ࠫไิๆࠪဴ") in title:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဵ"),l111ll_l1_+title,link,253,l1llll_l1_)
		else:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬံ"),l111ll_l1_+title,link,252,l1llll_l1_)
	if type in [l11lll_l1_ (u"ࠧ࡯ࡧࡺࡩࡸࡺ့ࠧ"),l11lll_l1_ (u"ࠨࡤࡨࡷࡹ࠭း"),l11lll_l1_ (u"ࠩࡰࡳࡸࡺ္ࠧ")]:
		items = re.findall(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡰࡸࡱࡧ࡫ࡲࡴࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽်ࠩ"),html,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫျ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫြ")+title,link,251,l11lll_l1_ (u"࠭ࠧွ"),l11lll_l1_ (u"ࠧࠨှ"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬဿ"),url,l11lll_l1_ (u"ࠩࠪ၀"),headers,l11lll_l1_ (u"ࠪࠫ၁"),l11lll_l1_ (u"ࠫࠬ၂"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭၃"))
	html = response.content
	#items = re.findall(l11lll_l1_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡨࡲࡡࡴࡵࡀ࡙ࠦ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ၄"),html,re.DOTALL)
	# the first 10000 character of the html file is l11lll11l_l1_ l1l111l11_l1_ in l1l111ll1_l1_ .. it l1l11111l_l1_ l11ll1ll1_l1_
	html = html[10000:]
	items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ၅"),html,re.DOTALL)
	if not items: return
	l1llll_l1_,name = items[0]
	if l11lll_l1_ (u"ࠨษ็ั้่ษࠨ၆") in name: name = name.split(l11lll_l1_ (u"ࠩส่า๊โสࠩ၇"))[0].strip(l11lll_l1_ (u"ࠪࠤࠬ၈"))
	elif l11lll_l1_ (u"ࠫา๊โสࠩ၉") in name: name = name.split(l11lll_l1_ (u"ࠬำไใหࠪ၊"))[0].strip(l11lll_l1_ (u"࠭ࠠࠨ။"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭၌"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪ၍"),block,re.DOTALL)
		for link,l1lll11_l1_ in items:
			title = name+l11lll_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥืโๆࠢࠪ၎")+l1lll11_l1_
			#link = link.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬ၏")).replace(SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨၐ")),l11ll1_l1_)
			#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠬ࠵ࠧၑ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪၒ")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ၓ"),l111ll_l1_+title,link,252,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧၔ"),l111ll_l1_+l11lll_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧၕ"),url,252,l1llll_l1_)
	return
def l11l1lll1_l1_(title,link):
	l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡟ࡦ࠳ࡺࡂ࠯࡝࠱ࡢ࠱ࠧၖ"),title,re.DOTALL)
	if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
	else: title = title+l11lll_l1_ (u"ࠫࠥ࠭ၗ")+SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪၘ"))
	title = title.replace(l11lll_l1_ (u"ู࠭าสࠣื๏ีࠧၙ"),l11lll_l1_ (u"ࠧࠨၚ")).replace(l11lll_l1_ (u"ࠨ็หหูืࠧၛ"),l11lll_l1_ (u"ࠩࠪၜ")).replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠪၝ"),l11lll_l1_ (u"ࠫࠬၞ"))
	title = title.replace(l11lll_l1_ (u"ࠬ๓ࠧၟ"),l11lll_l1_ (u"࠭ࠧၠ"))
	title = title.replace(l11lll_l1_ (u"ࠧࠡࠢࠪၡ"),l11lll_l1_ (u"ࠨࠢࠪၢ")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬၣ"),l11lll_l1_ (u"ࠪࠤࠬၤ"))
	return title
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨၥ"),url,l11lll_l1_ (u"ࠬ࠭ၦ"),headers,l11lll_l1_ (u"࠭ࠧၧ"),l11lll_l1_ (u"ࠧࠨၨ"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬၩ"))
	html = response.content
	l11l11l_l1_ = response.url
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ၪ"))
	headers[l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫၫ")] = server+l11lll_l1_ (u"ࠫ࠴࠭ၬ")
	l11l1ll1l_l1_,l1l111111_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭ၭ"),l11lll_l1_ (u"࠭ࠧၮ"),[]
	# l11ll1l1l_l1_ & download l11l1l11_l1_
	l1l11l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡺࡥࡹࡩࡨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱࠮ࡄ࠯ࠢࠨၯ"),html,re.DOTALL)
	if l1l11l1ll_l1_: l11l1ll1l_l1_,l1l1111l1_l1_,l1l111111_l1_,l11lllll1_l1_ = l1l11l1ll_l1_[0]
	else:
		l1l11l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡂࡶࡶࡷࡳࡳࡹࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩၰ"),html,re.DOTALL)
		if l1l11l1ll_l1_:
			link,l1l1111l1_l1_ = l1l11l1ll_l1_[0]
			if l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨၱ") in l1l1111l1_l1_: l11l1ll1l_l1_ = link
			else: l1l111111_l1_ = link
	if l11l1ll1l_l1_:
		# l11ll1l1l_l1_ links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧၲ"),l11l1ll1l_l1_,l11lll_l1_ (u"ࠫࠬၳ"),headers,l11lll_l1_ (u"ࠬ࠭ၴ"),l11lll_l1_ (u"࠭ࠧၵ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫၶ"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡥࡳࡃࡵࡩࡦࠨࠨ࠯ࠬࡂࡀ࠴ࡻ࡬࠿ࠫࠪၷ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l1l1l1_l1_ = l1l1ll1_l1_[0]
			l11l1l1l1_l1_ = l11l1l1l1_l1_.replace(l11lll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨၸ"),l11lll_l1_ (u"ࠪࡀ࡭࠹࠾ࠨၹ"))
			l11l1l1l1_l1_ = l11l1l1l1_l1_.replace(l11lll_l1_ (u"ࠫࡁ࡮࠳࠿ࠩၺ"),l11lll_l1_ (u"ࠬࡂࡨ࠴ࡀ࠿࡬࠸ࡄࠧၻ"))
			l111l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡩ࠵ࡁ࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠭࠴ࠪࡀࠫ࠿࡬࠸ࡄࠧၼ"),l11l1l1l1_l1_,re.DOTALL)
			if not l111l11_l1_: l111l11_l1_ = [(l11lll_l1_ (u"ࠧࠨၽ"),l11l1l1l1_l1_)]
			for l11l111l_l1_,block in l111l11_l1_:
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠨࡡࡢࡣࡤ࠭ၾ")+l11l111l_l1_
				items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡭࡫ࡱ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ၿ"),block,re.DOTALL)
				for link,name in items:
					if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨႀ") not in link: link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪႁ")+link
					#name = SERVER(link,l11lll_l1_ (u"ࠬ࡮࡯ࡴࡶࠪႂ"))
					link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧႃ")+name+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨႄ")+l11l111l_l1_
					l1111_l1_.append(link)
		# l1l11llll_l1_ link
		links = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႅ"),html,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࡎ࡬ࡲࡢ࡯ࡨࠦ࠳࠰࠿ࠡࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡋࡉࡎࡍࡈࡕ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪႆ"),html,re.DOTALL)
		if links:
			link,l11l111l_l1_ = links[0]
			name = SERVER(link,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨႇ"))
			if l11lll_l1_ (u"ࠫࠪ࠭ႈ") in l11l111l_l1_: link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ႉ")+name+l11lll_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ࡟ࡠࠩႊ")
			else: link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨႋ")+name+l11lll_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࡡࡢࡣࡤ࠭ႌ")+l11l111l_l1_
			l1111_l1_.append(link)
	if l1l111111_l1_:
		# download links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙ႍ࠭"),l1l111111_l1_,l11lll_l1_ (u"ࠪࠫႎ"),headers,l11lll_l1_ (u"ࠫࠬႏ"),l11lll_l1_ (u"ࠬ࠭႐"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ႑"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡅࡱࡺࡲࡱࡵࡡࡥࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭႒"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ႓"),block,re.DOTALL)
			for link,title,l11l111l_l1_ in items:
				if not link: continue
				# l11lll1l1_l1_ l11l1l1ll_l1_ by l11l1llll_l1_ .. it l1l111l1l_l1_ a l11ll11l1_l1_ from l11l1llll_l1_ l1l11ll1l_l1_
				if l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡵࡷࡥࡹ࡯࡯࡯ࠩ႔") in link: continue
				link = l111l_l1_(link)
				#title = l11l1lll1_l1_(title,link)
				link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ႕")+title+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬ႖")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ႗"), l1111_l1_)
	l11ll111l_l1_ = str(l1111_l1_)
	l11l111_l1_ = [l11lll_l1_ (u"࠭࠮ࡻ࡫ࡳࡃࠬ႘"),l11lll_l1_ (u"ࠧ࠯ࡴࡤࡶࡄ࠭႙"),l11lll_l1_ (u"ࠨ࠰ࡷࡼࡹࡅࠧႚ"),l11lll_l1_ (u"ࠩ࠱ࡴࡩ࡬࠿ࠨႛ"),l11lll_l1_ (u"ࠪ࠲ࡹࡧࡲࡀࠩႜ"),l11lll_l1_ (u"ࠫ࠳࡯ࡳࡰࡁࠪႝ"),l11lll_l1_ (u"ࠬ࠴ࡺࡪࡲ࠱ࠫ႞"),l11lll_l1_ (u"࠭࠮ࡳࡣࡵ࠲ࠬ႟"),l11lll_l1_ (u"ࠧ࠯ࡶࡻࡸ࠳࠭Ⴀ"),l11lll_l1_ (u"ࠨ࠰ࡳࡨ࡫࠴ࠧႡ"),l11lll_l1_ (u"ࠩ࠱ࡸࡦࡸ࠮ࠨႢ"),l11lll_l1_ (u"ࠪ࠲࡮ࡹ࡯࠯ࠩႣ")]
	if any(value in l11ll111l_l1_ for value in l11l111_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬႤ"),l11lll_l1_ (u"ࠬ࠭Ⴅ"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩႦ"),l11lll_l1_ (u"ࠧอำหࠤึอศุ่ࠢาฯ๊แࠡๆฦ๊ࠥํะศࠢส่ึอศุࠢ็๎ุࠦๅ็้ࠢ์฾ࠦวๅำ๋หอ฽ࠠศๆอ๎ࠥ็๊่ษ้้ࠣ็วหࠢไ๎ิ๐่ࠡ࠰࠱ࠤ้ษๆ้ࠡำหࠥอไๆ๊ๅ฽ࠥ็๊่ࠢัำ๊อสࠡลัี๎ฺ๋ࠦำ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪႧ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧႨ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫႩ"),l11lll_l1_ (u"ࠪ࠯ࠬႪ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡬ࡩ࡯ࡦ࠲ࡃ࡫࡯࡮ࡥ࠿ࠪႫ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬႬ"))
	return
def l1lll1l1_l1_(url,filter):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧႭ"),l11lll_l1_ (u"ࠧࠨႮ"),filter,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩႯ"):url,l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ⴐ"):l11lll_l1_ (u"ࠪࠫႱ")}
	#l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࠬႲ")
	#filter = filter.replace(l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧႳ"),l11lll_l1_ (u"࠭ࠧႴ"))
	if l11lll_l1_ (u"ࠧࡀࡁࠪႵ") in url: url = url.split(l11lll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧႶ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭Ⴗ"),1)
	if filter==l11lll_l1_ (u"ࠪࠫႸ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬႹ"),l11lll_l1_ (u"ࠬ࠭Ⴚ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪႻ"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫႼ"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࡀࠫႽ") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"ࠩࡀࡁࠬႾ") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭Ⴟ")+category+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨჀ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨჁ")+category+l11lll_l1_ (u"࠭࠽࠾࠲ࠪჂ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪჃ"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬჄ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬჅ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭჆"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪჇ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭჈"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ჉"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨ჊"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ჋"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪ჌"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩჍ")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ჎"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ჏"),l1111111_l1_,251,l11lll_l1_ (u"࠭ࠧა"),l11lll_l1_ (u"ࠧࠨბ"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩგ"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩდ"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪე")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪვ"),l1111111_l1_,251,l11lll_l1_ (u"ࠬ࠭ზ"),l11lll_l1_ (u"࠭ࠧთ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨი"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭კ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩლ"),l11lll_l1_ (u"ࠪࠫმ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩნ"),url,l11lll_l1_ (u"ࠬ࠭ო"),headers,l11lll_l1_ (u"࠭ࠧპ"),l11lll_l1_ (u"ࠧࠨჟ"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭რ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡕࡧࡵࡱࡇ࡚ࡎࡴࠤࠪს"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l11l111_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡘࡦࡾࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࡌࡸࡪࡳࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬტ"),block,re.DOTALL)
	l1l111lll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡗࡧࡴࡪࡰࡪࡊ࡮ࡲࡴࡦࡴࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄ࠮ࠫࡁࠫࡀࡺࡲ࠾ࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬუ"),block,re.DOTALL)
	l1lll11l_l1_ = l1l11l111_l1_+l1l111lll_l1_
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#if l11lll_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧფ") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧქ"),block,re.DOTALL)
		if name==l11lll_l1_ (u"ࠧศะิํࠬღ"): name = l11lll_l1_ (u"ࠨษ็ห็ูวๆࠩყ")
		if not items:
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩშ"),block,re.DOTALL)
			items = []
			for option,value in l1l1lll_l1_: items.append([option,l11lll_l1_ (u"ࠪࠫჩ"),value])
			l1ll1lll_l1_ = l11lll_l1_ (u"ࠫࡷࡧࡴࡦࠩც")
			name = l11lll_l1_ (u"ࠬอไหไํ๎๊࠭ძ")
		else: l1ll1lll_l1_ = items[0][1]
		if l11lll_l1_ (u"࠭࠽࠾ࠩწ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫჭ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨხ")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩჯ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣࠫჰ"),l1111111_l1_,251,l11lll_l1_ (u"ࠫࠬჱ"),l11lll_l1_ (u"ࠬ࠭ჲ"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧჳ"))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧჴ"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩჵ"),l11l11l_l1_,254,l11lll_l1_ (u"ࠩࠪჶ"),l11lll_l1_ (u"ࠪࠫჷ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬჸ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨჹ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾࠲ࠪჺ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ჻")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀ࠴ࠬჼ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ჽ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪჾ"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ჿ")+name,l11l11l_l1_,255,l11lll_l1_ (u"ࠬ࠭ᄀ"),l11lll_l1_ (u"࠭ࠧᄁ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᄂ"))
		dict[l1ll1lll_l1_] = {}
		for option,dummy,value in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠨษ็็้࠭ᄃ") in option: continue
			option = unescapeHTML(option)
			#if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᄄ") in option: continue
			#if l11lll_l1_ (u"ࠪࡲ࠲ࡧࠧᄅ") in value: continue
			l11ll1l11_l1_,l1lll1lll_l1_ = option,option
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠫ࠿ࠦࠧᄆ")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨᄇ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩᄈ")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪᄉ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫᄊ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ᄋ")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᄌ"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄍ"),l111ll_l1_+l1lll1lll_l1_,url,255,l11lll_l1_ (u"ࠬ࠭ᄎ"),l11lll_l1_ (u"࠭ࠧᄏ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᄐ"))
			elif type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬᄑ") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"ࠩࡀࡁࠬᄒ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᄓ"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᄔ"),l11lll_l1_ (u"ࠬ࠭ᄕ"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬᄖ")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᄗ"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,251,l11lll_l1_ (u"ࠨࠩᄘ"),l11lll_l1_ (u"ࠩࠪᄙ"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫᄚ"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄛ"),l111ll_l1_+l1lll1lll_l1_,url,254,l11lll_l1_ (u"ࠬ࠭ᄜ"),l11lll_l1_ (u"࠭ࠧᄝ"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᄞ"),l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᄟ"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᄠ")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᄡ"),l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬᄢ"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫᄣ"),l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄤ"),l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩᄥ"),l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩᄦ"),l11lll_l1_ (u"ࠩࡵࡥࡹ࡫ࠧᄧ")]
def l11llllll_l1_(url):
	l11l1ll11_l1_ = l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠵࠴࠷࠷࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩᄨ")
	url = url.replace(l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࠨᄩ"),l11l1ll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษัี๎࠭ᄪ"),l11lll_l1_ (u"࠭ࠧᄫ"))
	if l11l1ll11_l1_ not in url: url = url+l11l1ll11_l1_
	url = url.replace(l11lll_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ᄬ"),l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭ᄭ"))
	url = url.replace(l11lll_l1_ (u"ࠩࡂࡃࠬᄮ"),l11lll_l1_ (u"ࠪࡃࠬᄯ"))
	url = url.replace(l11lll_l1_ (u"ࠫࠫࠬࠧᄰ"),l11lll_l1_ (u"ࠬࠬࠧᄱ"))
	url = url.replace(l11lll_l1_ (u"࠭࠽࠾ࠩᄲ"),l11lll_l1_ (u"ࠧ࠾ࠩᄳ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᄴ"),l11lll_l1_ (u"ࠩࠪᄵ"),l11lll_l1_ (u"ࠪࠫᄶ"),l11lll_l1_ (u"ࠫࡕࡘࡅࡑࡃࡕࡉࡤࡌࡉࡍࡖࡈࡖࡤࡌࡉࡏࡃࡏࡣ࡚ࡘࡌࠨᄷ"))
	return url
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᄸ"),l11lll_l1_ (u"࠭ࠧᄹ"),filters,l11lll_l1_ (u"ࠧࡊࡐࠣࠤࠥࠦࠧᄺ")+mode)
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᄻ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᄼ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᄽ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠫࠫࠬࠧᄾ"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠬ࠭ᄿ")
	if l11lll_l1_ (u"࠭࠽࠾ࠩᅀ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠧࠧࠨࠪᅁ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠨ࠿ࡀࠫᅂ"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠩ࠳ࠫᅃ")
		if l11lll_l1_ (u"ࠪࠩࠬᅄ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᅅ") and value!=l11lll_l1_ (u"ࠬ࠶ࠧᅆ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠠࠬࠢࠪᅇ")+value
		elif mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᅈ") and value!=l11lll_l1_ (u"ࠨ࠲ࠪᅉ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬᅊ")+key+l11lll_l1_ (u"ࠪࡁࡂ࠭ᅋ")+value
		elif mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨᅌ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨᅍ")+key+l11lll_l1_ (u"࠭࠽࠾ࠩᅎ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫᅏ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠨࠩࠫᅐ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᅑ"),l11lll_l1_ (u"ࠪࠫᅒ"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠫࡔ࡛ࡔࠨᅓ"))
	return l1ll1l1l_l1_
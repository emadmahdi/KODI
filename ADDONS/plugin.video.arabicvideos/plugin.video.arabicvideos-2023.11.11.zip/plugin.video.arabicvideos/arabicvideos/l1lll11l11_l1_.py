# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨᤙ")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡅࡆࡆࡤ࠭ᤚ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪᤛ"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪᤜ"),l11lll_l1_ (u"ࠪฮุา๊ๅࠩᤝ"),l11lll_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩᤞ")]
headers = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭᤟"):l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥ࠯ࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮ࠩᤠ")}
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l1111l_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l11111_l1_(url,text)
	elif mode==634: results = l1l11l_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᤡ"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᤢ"),headers,l11lll_l1_ (u"ࠩࠪᤣ"),l11lll_l1_ (u"ࠪࠫᤤ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᤥ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤦ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᤧ"),l11lll_l1_ (u"ࠧࠨᤨ"),639,l11lll_l1_ (u"ࠨࠩᤩ"),l11lll_l1_ (u"ࠩࠪᤪ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᤫ"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᤬"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᤭"),l11lll_l1_ (u"࠭ࠧ᤮"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᤯"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᤰ")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪᤱ"),l11ll1_l1_,631,l11lll_l1_ (u"ࠪࠫᤲ"),l11lll_l1_ (u"ࠫࠬᤳ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᤴ"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᤵ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᤶ")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᤷ"),l11ll1_l1_,631,l11lll_l1_ (u"ࠩࠪᤸ"),l11lll_l1_ (u"᤹ࠪࠫ"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ᤺"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ᤻ࠬ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᤼")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭᤽"),l11ll1_l1_,631,l11lll_l1_ (u"ࠨࠩ᤾"),l11lll_l1_ (u"ࠩࠪ᤿"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ᥀"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᥁"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᥂")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪ᥃"),l11ll1_l1_,631,l11lll_l1_ (u"ࠧࠨ᥄"),l11lll_l1_ (u"ࠨࠩ᥅"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ᥆"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᥇"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᥈"),l11lll_l1_ (u"ࠬ࠭᥉"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᥊"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᥋"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if title==l11lll_l1_ (u"ࠨละำะࠦวๅฯ็ๆฬะࠧ᥌"): mode,request = 631,l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ᥍")
		else: mode,request = 634,l11lll_l1_ (u"ࠪࠫ᥎")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᥏"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᥐ")+l111ll_l1_+title,link,mode,l11lll_l1_ (u"࠭ࠧᥑ"),l11lll_l1_ (u"ࠧࠨᥒ"),request)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᥓ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᥔ"),l11lll_l1_ (u"ࠪࠫᥕ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᥖ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥᥗ"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"࠭ࠧᥘ"))
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᥙ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᥚ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᥛ")+l111ll_l1_+title,link,634)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᥜ"),url,l11lll_l1_ (u"ࠫࠬᥝ"),l11lll_l1_ (u"ࠬ࠭ᥞ"),l11lll_l1_ (u"࠭ࠧᥟ"),l11lll_l1_ (u"ࠧࠨᥠ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᥡ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᥢ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫᥣ"),l11lll_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪᥤ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᥥ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"࠭ࠧᥦ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᥧ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᥨ"),l11lll_l1_ (u"ࠩࠪᥩ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᥪ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠫ࠿ࠦࠧᥫ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥬ"),l111ll_l1_+title,link,631)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᥭ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᥮"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᥯"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᥰ"),l11lll_l1_ (u"ࠪࠫᥱ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥲ"),l111ll_l1_+title,link,631)
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠳ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡳࡱ࠲ࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡨࡦࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠳࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩ࡫ࡷࡩࡲࡹࠩ࠽࠵࠳࠾ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠻࠹࠱ࠪࠌࠌ࡭࡫ࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠲ࠢࡤࡲࡩࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠳ࠢࡤࡲࡩࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠴࠼ࠣࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࠥࠦࠧᥳ")
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"࠭ࠧᥴ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ᥵"),l11lll_l1_ (u"ࠨࠩ᥶"),request,url)
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ᥷"):
		url,search = url.split(l11lll_l1_ (u"ࠪࡃࠬ᥸"),1)
		data = l11lll_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪ᥹")+search
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ᥺"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭᥻")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ᥼"),url,data,headers,l11lll_l1_ (u"ࠨࠩ᥽"),l11lll_l1_ (u"ࠩࠪ᥾"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ᥿"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᦀ"),url,l11lll_l1_ (u"ࠬ࠭ᦁ"),l11lll_l1_ (u"࠭ࠧᦂ"),l11lll_l1_ (u"ࠧࠨᦃ"),l11lll_l1_ (u"ࠨࠩᦄ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᦅ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠪࠫᦆ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᦇ"))
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᦈ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᦉ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((link,title,l11lll_l1_ (u"ࠧࠨᦊ")))
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᦋ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࡠࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᦌ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪࠫࠬࠨࡰࡰࡵࡷࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮࠭ࠧࠨᦍ"),block,re.DOTALL)
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᦎ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᦏ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪᦐ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᦑ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᦒ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫᦓ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᦔ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((link,title,l11lll_l1_ (u"ࠫࠬᦕ")))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᦖ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᦗ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧᦘ"),l11lll_l1_ (u"ࠨใํ่๊࠭ᦙ"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨᦚ"),l11lll_l1_ (u"ࠪ็้๐ศࠨᦛ"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪᦜ"),l11lll_l1_ (u"ࠬํฯศใࠪᦝ"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭ᦞ"),l11lll_l1_ (u"ฺࠧำูࠫᦟ"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨᦠ"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨᦡ"),l11lll_l1_ (u"ุ้ࠪือ๋หࠪᦢ")]
	for link,title,l1llll_l1_ in items:
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬᦣ"),link)
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠬ࠵ࠧᦤ"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫᦥ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩᦦ")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪᦧ"))
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᦨ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᦩ")+l1llll_l1_.strip(l11lll_l1_ (u"ࠫ࠴࠭ᦪ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᦫ"))
		title = title.replace(l11lll_l1_ (u"࠭ࠠิ์่ห้ࠥไ้สࠪ᦬"),l11lll_l1_ (u"ࠧࠨ᦭"))
		title = title.replace(l11lll_l1_ (u"ࠨࠢส์๋ࠦไศ์้ࠫ᦮"),l11lll_l1_ (u"ࠩࠪ᦯"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ᦰ"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠫ࡜࡝ࡅࠨᦱ") in title: continue
		elif any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᦲ"),l111ll_l1_+title,link,632,l1llll_l1_)
		elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᦳ"):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᦴ"),l111ll_l1_+title,link,632,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᦵ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᦶ"),l111ll_l1_+title,link,633,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨᦷ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦸ"),l111ll_l1_+title,link,631,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦹ"),l111ll_l1_+title,link,633,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᦺ"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᦻ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᦼ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᦽ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠪࠧࠬᦾ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ᦿ")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧᧀ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᧁ"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ᧂ")+title,link,631)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᧃ"),l11lll_l1_ (u"ࠩࠪᧄ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧᧅ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᧆ"),url,l11lll_l1_ (u"ࠬ࠭ᧇ"),l11lll_l1_ (u"࠭ࠧᧈ"),l11lll_l1_ (u"ࠧࠨᧉ"),l11lll_l1_ (u"ࠨࠩ᧊"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ᧋"))
	html = response.content
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᧌"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠫࠬ᧍")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ᧎"),html,re.DOTALL)
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡱࡱࡧࡱ࡯ࡣ࡬࠿ࠥࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸ࠱࠴ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭᧏"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠤࠩ᧐"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧑"),l111ll_l1_+title,url,633,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ᧒"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ᧓")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧔"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᧕"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᧖"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			#link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ᧗")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ᧘"))
			link = link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ᧙"))
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨ᧚"),l11lll_l1_ (u"ࠫࠥ࠭᧛"))
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧜"),l111ll_l1_+title,link,632,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ᧝"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ᧞") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ᧟")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ᧠"))
		#		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᧡"),l111ll_l1_+title,link,632,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	# l11ll1l1l_l1_ links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ᧢"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠲ࡵ࡮ࡰࠨ᧣"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᧤"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ᧥"),l11lll_l1_ (u"ࠨࠩ᧦"),l11lll_l1_ (u"ࠩࠪ᧧"),l11lll_l1_ (u"ࠪࠫ᧨"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ᧩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᧪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠨࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠣ᧫"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᧬")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᧭"))
				l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭᧮"),l11lll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࡱࡪࡳࠫ᧯"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ᧰"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭᧱"),l11lll_l1_ (u"࠭ࠧ᧲"),l11lll_l1_ (u"ࠧࠨ᧳"),l11lll_l1_ (u"ࠨࠩ᧴"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭᧵"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ᧷"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᧸")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ᧹"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ᧺"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᧻"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ᧼"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ᧽"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭᧾"),l11lll_l1_ (u"ࠬ࠱ࠧ᧿"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧᨀ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧᨁ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬᨂ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᨃ"))
	return
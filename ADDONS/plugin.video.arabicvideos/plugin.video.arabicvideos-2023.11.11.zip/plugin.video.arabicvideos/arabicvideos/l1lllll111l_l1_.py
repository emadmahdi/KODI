# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ⍲")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡊࡈ࠱ࡠࠩ⍳")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#l1l1ll11_l1_: https://n-l1lllll1l11_l1_.l1lllll1111_l1_
#l1lllll11ll_l1_: https://www.l1lllll11ll_l1_.com/profile.l1ll1lll1l_l1_?id=100091282963836
l1l1l1_l1_ = [l11lll_l1_ (u"๊้ࠫสษฬํࠫ⍴"),l11lll_l1_ (u"ࠬอ๊อ์ࠣฬุะࠧ⍵")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==770: results = MENU()
	elif mode==771: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==772: results = l1l11l_l1_(url)
	elif mode==773: results = PLAY(url)
	elif mode==774: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⍶")+text)
	elif mode==775: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⍷")+text)
	elif mode==776: results = l1lll1l1l1_l1_(url,l1l11l1_l1_)
	elif mode==779: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍸"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⍹"),l11lll_l1_ (u"ࠪࠫ⍺"),779,l11lll_l1_ (u"ࠫࠬ⍻"),l11lll_l1_ (u"ࠬ࠭⍼"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⍽"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⍾"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⍿"),l11lll_l1_ (u"ࠩࠪ⎀"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⎁"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ⎂"),l11lll_l1_ (u"ࠬ࠭⎃"),l11lll_l1_ (u"࠭ࠧ⎄"),l11lll_l1_ (u"ࠧࠨ⎅"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⎆"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡱࡥࡻ࠳࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⎇"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⎈"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭⎉"))
			if any(value in title for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎊"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⎋")+l111ll_l1_+title,link,771)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎌"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎍"),l11lll_l1_ (u"ࠩࠪ⎎"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡣࡵࡸ࡮ࡩ࡬ࡦࠪ࠱࠮ࡄ࠯ࡳࡰࡥ࡬ࡥࡱ࠳ࡢࡰࡺࠪ⎏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⎐"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ⎑"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎒"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎓")+l111ll_l1_+title,link,771,l11lll_l1_ (u"ࠨࠩ⎔"),l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴ࡭ࡦࡰࡸࠫ⎕"))
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⎖"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⎗"),l11lll_l1_ (u"ࠬ࠭⎘"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⎙"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⎚"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⎛"))
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎜"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⎝")+l111ll_l1_+title,link,771)
	return html
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠫࠬ⎞")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⎟"),l11lll_l1_ (u"࠭ࠧ⎠"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⎡"),url,l11lll_l1_ (u"ࠨࠩ⎢"),l11lll_l1_ (u"ࠩࠪ⎣"),l11lll_l1_ (u"ࠪࠫ⎤"),l11lll_l1_ (u"ࠫࠬ⎥"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⎦"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ⎧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠧࠨ⎨"),l11lll_l1_ (u"ࠨࠩ⎩"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠩะ่็อสࠨ⎪") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"้ࠪํอำๆࠩ⎫") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⎬"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎭"),l111ll_l1_+title,link,776,l1llll_l1_,l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⎮"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⎯"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⎰"),l111ll_l1_+title,link,773,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⎱"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⎲"),l111ll_l1_+title,link,773)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠫࠬ⎳")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⎴"),l11lll_l1_ (u"࠭ࠧ⎵"),l11lll_l1_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠧ⎶"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⎷"),url,l11lll_l1_ (u"ࠩࠪ⎸"),l11lll_l1_ (u"ࠪࠫ⎹"),l11lll_l1_ (u"ࠫࠬ⎺"),l11lll_l1_ (u"ࠬ࠭⎻"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⎼"))
	html = response.content
	items,l1lllll1l1l_l1_,filters = [],False,False
	if not type:
		# l1lllll1l1l_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⎽"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⎾"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⎿"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⏀"),l111ll_l1_+title,link,771,l11lll_l1_ (u"ࠫࠬ⏁"),l11lll_l1_ (u"ࠬࡹࡵࡣ࡯ࡨࡲࡺ࠭⏂"))
				l1lllll1l1l_l1_ = True
	if not type and l11lll_l1_ (u"࠭ࡰ࠾ࠩ⏃") not in url:
		# filter
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡦࡰࡴࡰࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ⏄"),html,re.DOTALL)
		if l1l1ll1_l1_:
			if l1lllll1l1l_l1_: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⏅"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⏆"),l11lll_l1_ (u"ࠪࠫ⏇"),9999)
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏈"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ⏉"),url,775,l11lll_l1_ (u"࠭ࠧ⏊"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ⏋"))
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏌"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⏍"),url,774,l11lll_l1_ (u"ࠪࠫ⏎"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⏏"))
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏐"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠪ⏑"),url,779)
			addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⏒"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⏓"),l11lll_l1_ (u"ࠩࠪ⏔"),9999)
			filters = True
	if not l1lllll1l1l_l1_:		# and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ⏕"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⏖"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨ⏗"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪ࠵ࠧ⏘") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏙"),l111ll_l1_+title,link,776,l1llll_l1_,l11lll_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⏚"))
				else: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⏛"),l111ll_l1_+title,link,773,l1llll_l1_)
		# l1lll1lll1_l1_
			l1l11l1_l1_ = l11lll_l1_ (u"ࠪ࠵ࠬ⏜")
			if l11lll_l1_ (u"ࠫࡵࡃࠧ⏝") in url: url,l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠬࡶ࠽ࠨ⏞"),1)
			conn = l11lll_l1_ (u"࠭ࠦࠨ⏟") if l11lll_l1_ (u"ࠧࡀࠩ⏠") in url else l11lll_l1_ (u"ࠨࡁࠪ⏡")
			url = url+conn
			url = url.replace(l11lll_l1_ (u"ࠩࡂࠪࠬ⏢"),l11lll_l1_ (u"ࠪࡃࠬ⏣"))
			if len(items)==40:
				url = url+l11lll_l1_ (u"ࠫࡵࡃࠧ⏤")+str(int(l1l11l1_l1_)+1)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏥"),l111ll_l1_+l11lll_l1_ (u"࠭วๅืไัฮࠦวๅฬส่๏ฯࠧ⏦"),url,771)
			elif l1l11l1_l1_!=l11lll_l1_ (u"ࠧ࠲ࠩ⏧"):
				url = url+l11lll_l1_ (u"ࠨࡲࡀࠫ⏨")+str(int(l1l11l1_l1_)-1)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏩"),l111ll_l1_+l11lll_l1_ (u"ࠪห้฻แฮหࠣหู้วษไฬࠫ⏪"),url,771)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⏫"),url,l11lll_l1_ (u"ࠬ࠭⏬"),l11lll_l1_ (u"࠭ࠧ⏭"),l11lll_l1_ (u"ࠧࠨ⏮"),l11lll_l1_ (u"ࠨࠩ⏯"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⏰"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡱࡧࡢࡦ࡮ࡁห้ะี็์ไࡀ࠴ࡲࡡࡣࡧ࡯ࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⏱"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll11l1_l1_,l1lllll1_l1_,l1lll11ll1_l1_ = [],[],[]
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡴࡱࡧࡹ࠮࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⏲"),html,re.DOTALL)
	if link:
		link = link[0]
		if link not in l1lll11ll1_l1_:
			l1lll11ll1_l1_.append(link)
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⏳"))
	# download links
	items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡴࠣࡪࡱ࡫ࡸ࠮ࡵࡷࡥࡷࡺࠢ࠯ࠬࡂࡀࡩ࡯ࡶ࠿࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮࠭ࡢࡤࡼ࠵࠯࠸ࢂ࠯࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⏴"),html,re.DOTALL)
	for l11l111l_l1_,link in items:
		if link not in l1lll11ll1_l1_:
			l1lll11ll1_l1_.append(link)
			l11l111l_l1_ = l11l111l_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩ⏵"))
			server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭⏶"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⏷")+server+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫ⏸")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬ⏹"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⏺"),url)
	return
def SEARCH(search,url=l11lll_l1_ (u"࠭ࠧ⏻")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ⏼"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ⏽"))
	if not url: url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ⏾")+l111l1l_l1_
	else: url = url+l11lll_l1_ (u"ࠪࡃࡹ࡯ࡴ࡭ࡧࡀࠫ⏿")+l111l1l_l1_+l11lll_l1_ (u"ࠫࠫ࡭ࡥ࡯ࡴࡨࡁࠫࡿࡥࡢࡴࡀࠪࡱࡧ࡮ࡨ࠿ࠪ␀")
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ␁"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_ l1lllll1l_l1_ 2023-10-22
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ␂"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ␃"),url,l11lll_l1_ (u"ࠨࠩ␄"),l11lll_l1_ (u"ࠩࠪ␅"),l11lll_l1_ (u"ࠪࠫ␆"),l11lll_l1_ (u"ࠫࠬ␇"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ␈"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡦࡰࡴࡰ࠱ࡷࡵࡷࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭␉"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠠ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦ࡮ࡨࡧࡹ࠭␊"),block,re.DOTALL)
		l1lll1l111_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ␋"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	# filter url
	url = url.replace(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭␌"),l11lll_l1_ (u"ࠪࡃࡹ࡯ࡴ࡭ࡧࡀࠪࠬ␍"))
	return url
l1lll11lll_l1_ = [l11lll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ␎"),l11lll_l1_ (u"ࠬࡲࡡ࡯ࡩࠪ␏"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ␐")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"ࠧࡺࡧࡤࡶࠬ␑"),l11lll_l1_ (u"ࠨ࡮ࡤࡲ࡬࠭␒"),l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ␓")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ␔"),l11lll_l1_ (u"ࠫࠬ␕"))
	url = url.split(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ␖"))[0]
	type,filter = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ␗"),1)
	if filter==l11lll_l1_ (u"ࠧࠨ␘"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠨࠩ␙"),l11lll_l1_ (u"ࠩࠪ␚")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ␛"))
	if type==l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ␜"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"ࠬࡃࠧ␝") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"࠭࠽ࠨ␞") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ␟")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫ␠")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ␡")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭␢")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭␣"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ␤")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨ␥"))
		# l1lll1l1ll_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ␦"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ␧")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ␨"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ␩"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1lll1ll1l_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ␪"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ␫")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␬"),l111ll_l1_+l11lll_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ␭"),l11l1l1_l1_,771,l11lll_l1_ (u"ࠨࠩ␮"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ␯"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␰"),l111ll_l1_+l11lll_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ␱")+l11lll11_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ␲"),l11l1l1_l1_,771,l11lll_l1_ (u"࠭ࠧ␳"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧ␴"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭␵"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ␶"),l11lll_l1_ (u"ࠪࠫ␷"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"่๊ࠫࠠࠨ␸"),l11lll_l1_ (u"ࠬ࠭␹"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"࠭࠽ࠨ␺") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ␻"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ␼")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␽"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ␾"),l11l1l1_l1_,771,l11lll_l1_ (u"ࠫࠬ␿"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ⑀"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⑁"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ⑂"),l11l11l_l1_,775,l11lll_l1_ (u"ࠨࠩ⑃"),l11lll_l1_ (u"ࠩࠪ⑄"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ⑅"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭⑆")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ⑇")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ⑈")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ⑉")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ⑊")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⑋"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ⑌")+name,l11l11l_l1_,774,l11lll_l1_ (u"ࠫࠬ⑍"),l11lll_l1_ (u"ࠬ࠭⑎"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⑏"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ⑐")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ⑑")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ⑒")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ⑓")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⑔")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ⑕")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"࠭࠰ࠨ⑖")]
			title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ⑗")+name
			if type==l11lll_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭⑘"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⑙"),l111ll_l1_+title,url,774,l11lll_l1_ (u"ࠪࠫ⑚"),l11lll_l1_ (u"ࠫࠬ⑛"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⑜"))
			elif type==l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⑝") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"ࠧ࠾ࠩ⑞") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⑟"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭①")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ②"),l111ll_l1_+title,l11l1l1_l1_,771,l11lll_l1_ (u"ࠫࠬ③"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬ④"))
			elif type==l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⑤"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⑥"),l111ll_l1_+title,url,775,l11lll_l1_ (u"ࠨࠩ⑦"),l11lll_l1_ (u"ࠩࠪ⑧"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⑨")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⑩")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ⑪")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩ⑫"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫ⑬"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪ⑭"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫ⑮") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬ⑯"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭⑰"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭⑱")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ⑲")
		if l11lll_l1_ (u"ࠧࠦࠩ⑳") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⑴") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ⑵"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ⑶")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⑷") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ⑸"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⑹")+key+l11lll_l1_ (u"ࠧ࠾ࠩ⑺")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ⑻"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⑼")+key+l11lll_l1_ (u"ࠪࡁࠬ⑽")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ⑾"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⑿"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩ⒀"),l11lll_l1_ (u"ࠧ࠾ࠩ⒁"))
	return l1ll1l1l_l1_
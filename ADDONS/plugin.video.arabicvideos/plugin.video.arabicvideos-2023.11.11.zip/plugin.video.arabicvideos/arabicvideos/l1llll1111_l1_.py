# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩᝌ")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧᝍ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫᝎ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l1111l_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l1llllll_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᝏ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᝐ"),l11lll_l1_ (u"ࠬ࠭ᝑ"),l11lll_l1_ (u"࠭ࠧᝒ"),l11lll_l1_ (u"ࠧࠨᝓ"),l11lll_l1_ (u"ࠨࠩ᝔"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᝕"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ᝖"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᝗"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ᝘"),l11lll_l1_ (u"࠭ࠧ᝙"),559,l11lll_l1_ (u"ࠧࠨ᝚"),l11lll_l1_ (u"ࠨࠩ᝛"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᝜"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᝝"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᝞"),l11lll_l1_ (u"ࠬ࠭᝟"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝠ"),l111ll_l1_+l11lll_l1_ (u"ࠧศะอี๋อࠠๅๅࠪᝡ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᝢ"),551,l11lll_l1_ (u"ࠩࠪᝣ"),l11lll_l1_ (u"ࠪࠫᝤ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᝥ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᝦ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᝧ"),block,re.DOTALL)
	for l1111l111_l1_,title in items:
		link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳ࠿ࡪࡶࡨࡱࡂ࠭ᝨ")+l1111l111_l1_+l11lll_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩᝩ")
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᝪ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᝫ")+l111ll_l1_+title,link,551)
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᝬ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᝭"),l11lll_l1_ (u"࠭ࠧᝮ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡰࡤࡺ࠲ࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡼ࠾ࠨᝯ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᝰ"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠩࠦࠫ᝱"): continue
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪᝲ") in title: continue
		if l11lll_l1_ (u"ࠫศำฯฬࠩᝳ") in title: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᝴"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᝵")+l111ll_l1_+title,link,551)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᝶"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᝷"),l11lll_l1_ (u"ࠩࠪ᝸"),9999)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠪࠧࠬ᝹"): continue
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ู๊ࠫไิๆࠣࠫ᝺") in title: continue
		if l11lll_l1_ (u"ࠬษอะอࠪ᝻") not in title: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᝼"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᝽")+l111ll_l1_+title,link,551)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠨࠩ᝾")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ᝿"),l11lll_l1_ (u"ࠪࠫក"),url)
	items = []
	# l1llll111l_l1_ l1llll11l1_l1_
	if l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫខ") in url or l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭គ") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬឃ"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧង")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭ច"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪឆ"),l11lll_l1_ (u"ࠪࠫជ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪឈ"))
		html = response.content
		l1l1ll1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩញ"),url,l11lll_l1_ (u"࠭ࠧដ"),l11lll_l1_ (u"ࠧࠨឋ"),l11lll_l1_ (u"ࠨࠩឌ"),l11lll_l1_ (u"ࠩࠪឍ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩណ"))
		html = response.content
		# l1111l111_l1_ items
		if l1111l111_l1_==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ត"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬថ"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬទ"),block,re.DOTALL)
			#DIALOG_OK(l11lll_l1_ (u"ࠧࠨធ"),l11lll_l1_ (u"ࠨࠩន"),l11lll_l1_ (u"ࠩࠪប"))
		# l1llll1ll1_l1_ l111ll11_l1_
		elif l11lll_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠪផ") in html:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭ព"),html,re.DOTALL)
		else:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪភ"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	if not items:
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨម"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭យ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨរ"),l11lll_l1_ (u"ࠩไ๎้๋ࠧល"),l11lll_l1_ (u"ࠪห฿์๊สࠩវ"),l11lll_l1_ (u"่๊๊ࠫษࠩឝ"),l11lll_l1_ (u"ࠬอูๅษ้ࠫឞ"),l11lll_l1_ (u"࠭็ะษไࠫស"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧហ"),l11lll_l1_ (u"ࠨ฻ิฺࠬឡ"),l11lll_l1_ (u"่๋ࠩึาว็ࠩអ"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩឣ")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭ឤ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨឥ"),title,re.DOTALL)
		if l11lll_l1_ (u"࠭ำๅษึ่ࠬឦ") not in url and any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ឧ"),l111ll_l1_+title,link,552,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠨษ็ั้่ษࠨឨ") in title:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨឩ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឪ"),l111ll_l1_+title,link,553,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ឫ") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឬ"),l111ll_l1_+title,link,551,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឭ"),l111ll_l1_+title,link,553,l1llll_l1_)
	if l1111l111_l1_==l11lll_l1_ (u"ࠧࠨឮ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࠬឯ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫឰ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠥࠦឱ"): continue
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠫࠬឲ"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឳ"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ឴")+title,link,551)
	if l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧ឵") in url or l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩា") in url:
		if l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩិ") in url:
			url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪី"),l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬឹ"))+l11lll_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃ࠲࠱ࠩឺ")
		elif l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧុ") in url:
			url,offset = url.split(l11lll_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩូ"))
			offset = int(offset)+20
			url = url+l11lll_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪួ")+str(offset)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩើ"),l111ll_l1_+l11lll_l1_ (u"๋๋ࠪอใࠡษ็้ื๐ฯࠨឿ"),url,551)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨៀ"),url,l11lll_l1_ (u"ࠬ࠭េ"),l11lll_l1_ (u"࠭ࠧែ"),l11lll_l1_ (u"ࠧࠨៃ"),l11lll_l1_ (u"ࠨࠩោ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪៅ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࡃࡻࡖࡩࡷ࡯ࡥࡴࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫំ"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡲࡩࡴࡶ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨះ"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧៈ") not in url:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ៉"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ៊"),l111ll_l1_+title,link,553,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤ࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ់"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៌"),block,re.DOTALL)
		for link,title in items:
			#title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭៍"),l11lll_l1_ (u"ࠫࠬ៎")).strip(l11lll_l1_ (u"ࠬࠦࠧ៏"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ័"),l111ll_l1_+title,link,552,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ៑"),l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠ࡯ࡲࡺ࡮࡫ࡳ࠰្ࠩ"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭៓"),l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡢࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭។"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ៕"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭៖"),l11lll_l1_ (u"࠭ࠧៗ"),l11lll_l1_ (u"ࠧࠨ៘"),l11lll_l1_ (u"ࠨࠩ៙"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭៚"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ៛"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪៜ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11llll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡌࡈࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៝"),html,re.DOTALL)
		l11llll1_l1_ = l11llll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡧࡦࡶࡓࡰࡦࡿࡥࡳ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ៞"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ៟"),l11lll_l1_ (u"ࠨࠩ០")).strip(l11lll_l1_ (u"ࠩࠣࠫ១"))
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡄࡹࡥࡳࡸࡨࡶࡂ࠭២")+server+l11lll_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭៣")+l11llll1_l1_+l11lll_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭៤")
				link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៥")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ៦")
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠣࡩࡨࡸࡕࡲࡡࡺࡧࡵࡆࡾࡔࡡ࡮ࡧ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࡞ࠥࡷࡪࡸࡶࡦࡴ࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ៧"),block,re.DOTALL)
			for server,l1lll1llll_l1_,title in items:
				title = title.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ៨"),l11lll_l1_ (u"ࠪࠫ៩")).strip(l11lll_l1_ (u"ࠫࠥ࠭៪"))
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡑ࡮ࡤࡽࡪࡸࡂࡺࡐࡤࡱࡪࡅࡳࡦࡴࡹࡩࡷࡃࠧ៫")+server+l11lll_l1_ (u"࠭ࠦ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦࡕࡨࡶࡻ࡫ࡲࡴ࠿ࠪ៬")+l1lll1llll_l1_+l11lll_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩ៭")+l11llll1_l1_+l11lll_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ៮")
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ៯")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ៰")
				l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ៱"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៲"),block,re.DOTALL)
		for link,name in items:
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៳")+name+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ៴")
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭៵") not in link: link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ៶")+link
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ៷"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ៸"),url)
	return
l11lll_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡖࡌࡂ࡛ࡢࡓࡑࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࡥࡣࡷࡥࠥࡃࠠࡼ࡙ࠩ࡭ࡪࡽࠧ࠻࠳ࢀࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ࠽ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪࢁࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡑࡑࡖࡘࠬ࠲ࡵࡳ࡮࠯ࡨࡦࡺࡡ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡁࡃࡆࡒ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢࠐࠉࠤࠢࡺࡥࡹࡩࡨࠡ࡮࡬ࡲࡰࡹࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡸࡣࡷࡧ࡭ࡇࡲࡦࡣࡐࡥࡸࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡨࡦࡺࡡ࠮࡮࡬ࡲࡰࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠨࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡ࡮࡬ࡲࡰࡹࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡥࡱࡱࡻࡱࡵࡡࡥ࠯ࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡷࡪࡸ࠭࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨ࠰ࡶࡻࡡ࡭࡫ࡷࡽ࠱ࡲࡩ࡯࡭ࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ࠰࠭࡟ࡠࡡࡢࠫ࠰ࡷࡵࡢ࡮࡬ࡸࡾࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠨࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࡪࡨࠣࡰࡪࡴࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࡀࡁ࠵ࡀࠠࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࠬࠨษ็ีฬฮืࠡๆํืࠥ็๊่ࠢไ๎ิ๐่ࠨࠫࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࠌࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠬࠨࡸ࡬ࡨࡪࡵࠧ࠭ࡷࡵࡰ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠣࠤࠥ៹")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ៺"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ៻"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ៼"),l11lll_l1_ (u"ࠩ࠰ࠫ៽"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ៾")+search+l11lll_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ៿")
	l1111l_l1_(url)
	return
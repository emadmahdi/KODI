# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ✷")
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠱࠯ࡤࡨࡷࡹ࠭✸")
#l11ll1_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠶࠴ࡣࡰ࡯ࠪ✹")
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡶࡪࡲࠪ✺")
#l11ll1_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠷ࡦࡪࡹࡴ࠯ࡥࡲࡱࠬ✻")
#l11ll1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠮ࡸ࡬ࡴ࠳ࡹࡨࡰࡨࡧࡥ࠳ࡩ࡯࡮ࠩ✼")
#l11ll1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡲࡱࡪ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮࡯࡮ࠪ✽")
#l11ll1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡶࡪࡲࠪ✾")
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡨࡩࡥࠩ✿")
#l11ll1_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳ࠳ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ❀")
script_name = l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ❁")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡅࡈࡘࡢࠫ❂")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==222: results = l1l11l_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1lll1l1_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❃"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ❄"),l11lll_l1_ (u"ࠨࠩ❅"),229,l11lll_l1_ (u"ࠩࠪ❆"),l11lll_l1_ (u"ࠪࠫ❇"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ❈"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❉"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ❊"),l11ll1_l1_,226,l11lll_l1_ (u"ࠧࠨ❋"),l11lll_l1_ (u"ࠨࠩ❌"),l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ❍"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❎"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ❏"),l11ll1_l1_,226,l11lll_l1_ (u"ࠬ࠭❐"),l11lll_l1_ (u"࠭ࠧ❑"),l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ❒"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭❓"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ❔"),l11lll_l1_ (u"ࠪࠫ❕"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ❖"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭❗"),l11lll_l1_ (u"࠭ࠧ❘"),l11lll_l1_ (u"ࠧࠨ❙"),l11lll_l1_ (u"ࠨࠩ❚"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ❛"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࠥ࡯࠭ࡩࡱࡰࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ❜"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ❝"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠬࡂ࠯ࡪࡀࠪ❞") in title: title = title.split(l11lll_l1_ (u"࠭࠼࠰࡫ࡁࠫ❟"))[1]
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❠"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❡")+l111ll_l1_+title,link,222)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ❢"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ❣"),l11lll_l1_ (u"ࠫࠬ❤"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹ࠭❥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ❦"),html,re.DOTALL)
		for title,link in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❧"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ❨")+l111ll_l1_+title,link,221)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ❩"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ❪"),l11lll_l1_ (u"ࠫࠬ❫"),9999)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ❬"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"࠭ࡨࡵ࡯࡯ࠫ❭") not in link: continue
			if not link.endswith(l11lll_l1_ (u"ࠧ࠰ࠩ❮")): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❯"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ❰")+l111ll_l1_+title,link,221)
	return html
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠤࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอึ฻ู๋๋ࠣอࠠๅษูหๆฯࠠศี่ࠤิิ่ๅ๋ࠢ็้๋ษࠡษ็ืึ࠭ࠬࠨࠩ࠯࠶࠷࠻ࠩࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧหฯำ๎ึ࠭ࠬࠨࠩ࠯࠶࠷࠼ࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠢ࡫ࡸࡲࡲࠩࠋࠋࠦ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱࡐࡴࡧࡤࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠦ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࡞ࡱࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡪࡴࡸࠠࡶࡴ࡯࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠤࠋ࡬ࡪࠥࡻࡲ࡭ࠣࡀࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮ࡸࡶࡱ࠲࠲࠳࠶ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ࠯ࠫࠬ࠲࠲࠳࠻࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่ศ้หาุ่ࠢฬํฯสࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ࠰࠷࠸࠱ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่ฬ็ไศ็ࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ࠯࠶࠷࠺ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ุ้๊ำๅษอࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲ࡸࡻ࠭ࠬ࠳࠴࠷࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬࡲࡩ࡯࡭ࠪ࠰ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠲ࠧࠨ࠮࠼࠽࠾࠿ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠠ࡮ࡩࡥࠬ࠳࠰࠿ࠪࡀࡈ࡫ࡾࡈࡥࡴࡶ࠿࠳ࡦࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤ࡭ࡺ࡭࡭ࠌࠌࠧࠥ࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠥ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡠ࠷࠯࡞࡝࡬ࠦࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࠩࡷࡳࡷࡸࡥ࡯ࡶࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠶࠷࠷ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫࡹࡵࡲࡳࡧࡱࡸࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠸࠲࠲ࠫࠍࠍࠧࠨࠢ❱")
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ❲"),url,l11lll_l1_ (u"ࠬ࠭❳"),l11lll_l1_ (u"࠭ࠧ❴"),l11lll_l1_ (u"ࠧࠨ❵"),l11lll_l1_ (u"ࠨࠩ❶"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ❷"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡸࡥࡳࡤࡴࡲࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ❸"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ❹"),block,re.DOTALL)
	for link,title in items:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❺"),l111ll_l1_+title,link,224)
	return
def l1lll1l1_l1_(url):
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❻"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ❼"),url,221)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠨࠩ❽"),l11lll_l1_ (u"ࠩࠪ❾"),l11lll_l1_ (u"ࠪࠫ❿"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ➀"))
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠶࠷࠷ࠩࠋࠋࠥࠦࠧ➁")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤࡢࡲࡦࡼࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠨ➂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠫࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ➃"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠨࠥࠪ➄"): name = title
			else:
				title = title + l11lll_l1_ (u"ࠩࠣࠤ࠿ࠦࠠࠨ➅") + l11lll_l1_ (u"ࠪๅ้ะัࠡࠩ➆") + name
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➇"),l111ll_l1_+title,link,221)
	else: l1111l_l1_(url)
	return
def l1111l_l1_(url,l1l11l1_l1_=l11lll_l1_ (u"ࠬ࠷ࠧ➈")):
	if l1l11l1_l1_==l11lll_l1_ (u"࠭ࠧ➉"): l1l11l1_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ➊")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ➋"),l11lll_l1_ (u"ࠩࠪ➌"),str(url), str(l1l11l1_l1_))
	if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ➍") in url or l11lll_l1_ (u"ࠫࡄ࠭➎") in url: l11l11l_l1_ = url + l11lll_l1_ (u"ࠬࠬࠧ➏")
	else: l11l11l_l1_ = url + l11lll_l1_ (u"࠭࠿ࠨ➐")
	#l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"ࠧࡰࡷࡷࡴࡺࡺ࡟ࡧࡱࡵࡱࡦࡺ࠽࡫ࡵࡲࡲࠫࡵࡵࡵࡲࡸࡸࡤࡳ࡯ࡥࡧࡀࡱࡴࡼࡩࡦࡵࡢࡰ࡮ࡹࡴࠧࡲࡤ࡫ࡪࡃࠧ➑")+l1l11l1_l1_
	l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"ࠨࡲࡤ࡫ࡪࡃࠧ➒") + l1l11l1_l1_
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ➓"),l11lll_l1_ (u"ࠪࠫ➔"),l11lll_l1_ (u"ࠫࠬ➕"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭➖"))
	#name = l11lll_l1_ (u"࠭ࠧ➗")
	#if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨ➘") in url:
	#	name = re.findall(l11lll_l1_ (u"ࠨ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀࠬ➙"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l11lll_l1_ (u"ࠩࠣࠫ➚")) + l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ➛")
	#	else: name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ➜") ) + l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ➝")
	if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࠧ➞") in url:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡦࡤࠦ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭➟"),html,re.DOTALL)
		block = l1l1ll1_l1_[-1]
	# l1ll1ll1ll1_l1_ l1lllll_l1_
	elif l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ➠") in url:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠡࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ➡"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	else:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ➢"),html,re.DOTALL)
		block = l1l1ll1_l1_[-1]
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ➣"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡵࡨࡶ࡮࡫ࡳࠨࠢ࡬ࡲࠥࡻࡲ࡭ࠢࡤࡲࡩࠦࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎ࡯ࡦࠡࠩ࠲ࡷࡪࡧࡳࡰࡰࠪࠤ࡮ࡴࠠࡶࡴ࡯ࠤࡦࡴࡤࠡࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࠤࡸࡺࡲࠩ࡮࡬ࡲࡰ࠯ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡳࡧ࡭ࡦࠢ࠮ࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠦࠧࠨ➤")
		title = unescapeHTML(title)
		l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟࠳ࠬ࠲ࠧ࠰ࠩࠬࠎࠎࠏࡩ࡮ࡩࠣࡁࠥ࡯࡭ࡨ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࠊ࡫ࡩࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤ࡮ࡳࡧ࠻ࠢ࡬ࡱ࡬ࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺ࠨࠢ࠮ࠤ࡮ࡳࡧࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡓࡕࡔࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠫ࡭ࡲ࡭ࠬࠨࠩࠬࠎࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࡱ࡯࡮࡬ࠌࠌࠍࠧࠨࠢ➥")
		if l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯ࠨ➦") in link or l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࠪ➧") in link:
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ➨"),l111ll_l1_+title,link.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬ➩")),223,l1llll_l1_)
		else:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➪"),l111ll_l1_+title,link,221,l1llll_l1_)
	if len(items)>=16:
		l1111ll111_l1_ = [l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭➫"),l11lll_l1_ (u"࠭࠯ࡵࡸࠪ➬"),l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ➭"),l11lll_l1_ (u"ࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ➮")]
		l1l11l1_l1_ = int(l1l11l1_l1_)
		if any(value in url for value in l1111ll111_l1_):
			for n in range(0,1000,100):
				if int(l1l11l1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1l11l1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1l11l1_l1_==j and j!=0:
									addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➯"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ➰")+str(j),url,221,l11lll_l1_ (u"ࠫࠬ➱"),str(j))
						elif i!=0: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➲"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ➳")+str(i),url,221,l11lll_l1_ (u"ࠧࠨ➴"),str(i))
						else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➵"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ➶")+str(1),url,221,l11lll_l1_ (u"ࠪࠫ➷"),str(1))
				elif n!=0: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➸"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ➹")+str(n),url,221,l11lll_l1_ (u"࠭ࠧ➺"),str(n))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➻"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ➼")+str(1),url,221)
	return
def PLAY(url):
	#global l11lll_l1_ (u"ࠩࠪ➽")
	l1lll1ll_l1_,l1111_l1_ = [],[]
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ➾"),l11lll_l1_ (u"ࠫࠬ➿"),url, url[-45:])
	# https://l1lll11111l_l1_.com/l1lll111ll1_l1_/فيلم-the-l1lll11l1l1_l1_-l1ll1ll1lll_l1_-2019-مترجم
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭⟀"),l11lll_l1_ (u"࠭ࠧ⟁"),l11lll_l1_ (u"ࠧࠨ⟂"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⟃"))
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡸࡩࡄวๅฬุ๊๏็࠼࠰ࡶࡧࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⟄"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# https://l111l11l1l_l1_.l1ll1ll1l1l_l1_/l1lll111ll1_l1_/فيلم-the-l1lll11l1l1_l1_-l1ll1ll1lll_l1_-2019-مترجم
	l11l1ll1l_l1_,l1l111111_l1_ = l11lll_l1_ (u"ࠪࠫ⟅"),l11lll_l1_ (u"ࠫࠬ⟆")
	l1lll11l1ll_l1_,l1ll1lllll1_l1_ = html,html
	l1lll1111ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡨࡰࡹࡢࡨࡱࠦࡡࡱ࡫ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⟇"),html,re.DOTALL)
	if l1lll1111ll_l1_:
		for link in l1lll1111ll_l1_:
			if l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ⟈") in link: l11l1ll1l_l1_ = link
			elif l11lll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ⟉") in link: l1l111111_l1_ = link
		if l11l1ll1l_l1_!=l11lll_l1_ (u"ࠨࠩ⟊"): l1lll11l1ll_l1_ = OPENURL_CACHED(l11111l_l1_,l11l1ll1l_l1_,l11lll_l1_ (u"ࠩࠪ⟋"),l11lll_l1_ (u"ࠪࠫ⟌"),l11lll_l1_ (u"ࠫࠬ⟍"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ⟎"))
		if l1l111111_l1_!=l11lll_l1_ (u"࠭ࠧ⟏"): l1ll1lllll1_l1_ = OPENURL_CACHED(l11111l_l1_,l1l111111_l1_,l11lll_l1_ (u"ࠧࠨ⟐"),l11lll_l1_ (u"ࠨࠩ⟑"),l11lll_l1_ (u"ࠩࠪ⟒"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ⟓"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⟔"),l11lll_l1_ (u"ࠬ࠭⟕"),l1l111111_l1_,l11l1ll1l_l1_)
	# https://l1ll1llll1l_l1_.l111l11l1l_l1_.download/?id=__1lll11l11l_l1_
	l1lll111l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⟖"),l1lll11l1ll_l1_,re.DOTALL)
	if l1lll111l11_l1_:
		l11l11l_l1_ = l1lll111l11_l1_[0]#+l11lll_l1_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵࠷࠺࠰࠴࠺࠺࠴࠲࠵࠴࠱࠼࠹ࡀ࠴࠲࠶࠸ࠫ⟗")
		if l11l11l_l1_!=l11lll_l1_ (u"ࠨࠩ⟘") and l11lll_l1_ (u"ࠩࡸࡴࡱࡵࡡࡥࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⟙") in l11l11l_l1_ and l11lll_l1_ (u"ࠪ࠳ࡄ࡯ࡤ࠾ࡡࠪ⟚") not in l11l11l_l1_:
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ⟛"),l11lll_l1_ (u"ࠬ࠭⟜"),l11lll_l1_ (u"࠭ࠧ⟝"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭⟞"))
			l1ll1ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⟟"),l11lll1l_l1_,re.DOTALL)
			if l1ll1ll11ll_l1_:
				for link,l11l111l_l1_ in l1ll1ll11ll_l1_:
					l1111_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡨࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࡰࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱࡵ࠺࡟ࡠࠩ⟠")+l11l111l_l1_)
			else:
				server = l11l11l_l1_.split(l11lll_l1_ (u"ࠪ࠳ࠬ⟡"))[2]
				l1111_l1_.append(l11l11l_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⟢")+server+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⟣"))
		elif l11l11l_l1_!=l11lll_l1_ (u"࠭ࠧ⟤"):
			#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⟥"),l11lll_l1_ (u"ࠨࠩ⟦"),l11l11l_l1_,str(l1lll111l11_l1_))
			server = l11l11l_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ⟧"))[2]
			l1111_l1_.append(l11l11l_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⟨")+server+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⟩"))
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	l1ll1llll11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡢࡤ࡯ࡩࠥࡩ࡬ࡢࡵࡶࡁࠧࡪ࡬ࡴࡡࡷࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ⟪"),l1ll1lllll1_l1_,re.DOTALL)
	if l1ll1llll11_l1_:
		l1ll1llll11_l1_ = l1ll1llll11_l1_[0]
		l1lll1111l1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⟫"),l1ll1llll11_l1_,re.DOTALL)
		if l1lll1111l1_l1_:
			for l11l111l_l1_,link in l1lll1111l1_l1_:
				if l11lll_l1_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ⟬") not in link: continue
				if link.count(l11lll_l1_ (u"ࠨ࠱ࠪ⟭"))>=2:
					server = link.split(l11lll_l1_ (u"ࠩ࠲ࠫ⟮"))[2]
					l1111_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⟯")+server+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡰࡴ࠹ࡥ࡟ࠨ⟰")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭⟱"), l1111_l1_)
	#if l1l_l1_ == -1 : return
	l1ll1lll1ll_l1_ = []
	for link in l1111_l1_:
		# faselhd	https://l1llll1ll1_l1_.l111l11l1l_l1_.l1ll1ll1l1l_l1_/l1lll111ll1_l1_/l11ll1l1l_l1_/فيلم-the-l1lll111lll_l1_-l1lll111111_l1_-l1ll1ll1l11_l1_-2017-مترجم/l1ll1llllll_l1_
		#if l11lll_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ⟲") in link: continue
		#if l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࡄࡴࡡ࡮ࡧࠪ⟳") in link: continue
		#if l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭⟴") in link: continue
		#if l11lll_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ⟵") not in link: continue
		l1ll1lll1ll_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ⟶"), l1ll1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1ll1lll1ll_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⟷"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭⟸"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ⟹"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ⟺"),l11lll_l1_ (u"ࠨ࠭ࠪ⟻"))
	html = OPENURL_CACHED(l1lll1111_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ⟼"),l11lll_l1_ (u"ࠪࠫ⟽"),l11lll_l1_ (u"ࠫࠬ⟾"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭⟿"))
	token = re.findall(l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡴࡰ࡭ࡨࡲࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠀"),html,re.DOTALL)
	if token:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡡࡷࡳࡰ࡫࡮࠾ࠩ⠁")+token[0]+l11lll_l1_ (u"ࠨࠨࡴࡁࠬ⠂")+l111l1l_l1_
		l1111l_l1_(url)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⠃"),l11lll_l1_ (u"ࠪࠫ⠄"),l11lll_l1_ (u"ࠫࠬ⠅"), l11lll_l1_ (u"ࠬ࠭⠆"))
	return
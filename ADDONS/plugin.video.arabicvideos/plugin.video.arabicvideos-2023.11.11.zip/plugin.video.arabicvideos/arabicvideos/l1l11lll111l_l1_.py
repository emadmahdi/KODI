# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫ俆")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡒࡓࡕࡡࠪ俇")
l11lll1111l1_l1_ = 4
l11ll1lllll1_l1_ = 10
def MAIN(mode,url,text,l1l11l1_l1_,l1ll111l111_l1_):
	try: l11ll1l1llll_l1_ = str(l1ll111l111_l1_[l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俈")])
	except: l11ll1l1llll_l1_ = l11lll_l1_ (u"࠭ࠧ俉")
	if   mode==160: results = MENU()
	elif mode==161: results = l11lll1l11l1_l1_(text)
	elif mode==162: results = l11ll1l11l11_l1_(text,162)
	elif mode==163: results = l11ll1l11l11_l1_(text,163)
	elif mode==164: results = l11lll1l1111_l1_(text)
	elif mode==165: results = l11ll11ll11l_l1_(url,text)
	elif mode==166: results = l11lll111lll_l1_(url,text)
	elif mode==167: results = l11ll11ll111_l1_(url,text)
	elif mode==168: results = l11ll111ll1l_l1_(url,text)
	elif mode==761: results = l11lll11ll1l_l1_()
	elif mode==762: results = l11ll1ll1l11_l1_()
	elif mode==763: results = l11ll1ll11l1_l1_(l11ll1l1llll_l1_,text,l1l11l1_l1_)
	elif mode==764: results = l11lll111111_l1_(l11ll1l1llll_l1_,text)
	elif mode==765: results = l11lll11l1ll_l1_(l11ll1l1llll_l1_,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ俊"),l11lll_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆࠡ฻ื์ฬฬ๊สࠩ俋"),l11lll_l1_ (u"ࠩࠪ俌"),161,l11lll_l1_ (u"ࠪࠫ俍"),l11lll_l1_ (u"ࠫࠬ俎"),l11lll_l1_ (u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ俏"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭俐"),l11lll_l1_ (u"ࠧใี่ࠤ฾ฺ่ศศํࠫ俑"),l11lll_l1_ (u"ࠨࠩ俒"),162,l11lll_l1_ (u"ࠩࠪ俓"),l11lll_l1_ (u"ࠪࠫ俔"),l11lll_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俕"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俖"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩ俗"),l11lll_l1_ (u"ࠧࠨ俘"),163,l11lll_l1_ (u"ࠨࠩ俙"),l11lll_l1_ (u"ࠩࠪ俚"),l11lll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ俛"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ俜"),l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํࠫ保"),l11lll_l1_ (u"࠭ࠧ俞"),164,l11lll_l1_ (u"ࠧࠨ俟"),l11lll_l1_ (u"ࠨࠩ俠"),l11lll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ信"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俢"),l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ俣"),l11lll_l1_ (u"ࠬ࠭俤"),763,l11lll_l1_ (u"࠭ࠧ俥"),l11lll_l1_ (u"ࠧࠨ俦"),l11lll_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ俧"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ俨"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ俩"),l11lll_l1_ (u"ࠫࠬ俪"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ俫"),l11lll_l1_ (u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ俬"),l11lll_l1_ (u"ࠧࠨ俭"),163,l11lll_l1_ (u"ࠨࠩ修"),l11lll_l1_ (u"ࠩࠪ俯"),l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ俰"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ俱"),l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ俲"),l11lll_l1_ (u"࠭ࠧ俳"),163,l11lll_l1_ (u"ࠧࠨ俴"),l11lll_l1_ (u"ࠨࠩ俵"),l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ俶"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ俷"),l11lll_l1_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ俸"),l11lll_l1_ (u"ࠬ࠭俹"),162,l11lll_l1_ (u"࠭ࠧ俺"),l11lll_l1_ (u"ࠧࠨ俻"),l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ俼"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ俽"),l11lll_l1_ (u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ俾"),l11lll_l1_ (u"ࠫࠬ俿"),162,l11lll_l1_ (u"ࠬ࠭倀"),l11lll_l1_ (u"࠭ࠧ倁"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ倂"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倃"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡสะฯࠥ฿ิ้ษษ๎ࠬ倄"),l11lll_l1_ (u"ࠪࠫ倅"),164,l11lll_l1_ (u"ࠫࠬ倆"),l11lll_l1_ (u"ࠬ࠭倇"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ倈"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ倉"),l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ倊"),l11lll_l1_ (u"ࠩࠪ個"),765,l11lll_l1_ (u"ࠪࠫ倌"),l11lll_l1_ (u"ࠫࠬ倍"),l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ倎"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ倏"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ倐"),l11lll_l1_ (u"ࠨࠩ們"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ倒"),l11lll_l1_ (u"ࠪๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ倓"),l11lll_l1_ (u"ࠫࠬ倔"),163,l11lll_l1_ (u"ࠬ࠭倕"),l11lll_l1_ (u"࠭ࠧ倖"),l11lll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ倗"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ倘"),l11lll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ候"),l11lll_l1_ (u"ࠪࠫ倚"),163,l11lll_l1_ (u"ࠫࠬ倛"),l11lll_l1_ (u"ࠬ࠭倜"),l11lll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ倝"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ倞"),l11lll_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ借"),l11lll_l1_ (u"ࠩࠪ倠"),162,l11lll_l1_ (u"ࠪࠫ倡"),l11lll_l1_ (u"ࠫࠬ倢"),l11lll_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ倣"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭値"),l11lll_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ倥"),l11lll_l1_ (u"ࠨࠩ倦"),162,l11lll_l1_ (u"ࠩࠪ倧"),l11lll_l1_ (u"ࠪࠫ倨"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ倩"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ倪"),l11lll_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘ࡛ࠦศฮอࠣ฽ู๎วว์ࠪ倫"),l11lll_l1_ (u"ࠧࠨ倬"),164,l11lll_l1_ (u"ࠨࠩ倭"),l11lll_l1_ (u"ࠩࠪ倮"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ倯"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ倰"),l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭倱"),l11lll_l1_ (u"࠭ࠧ倲"),764,l11lll_l1_ (u"ࠧࠨ倳"),l11lll_l1_ (u"ࠨࠩ倴"),l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭倵"))
	return
def l11lll11ll1l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ倶"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪ倷")+l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪ倸"),l11lll_l1_ (u"࠭ࠧ倹"),764)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ债"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ倻"),l11lll_l1_ (u"ࠩࠪ值"),9999)
	for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
		l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡎࡖࠧ倽")+str(l11ll1l1llll_l1_)+l11lll_l1_ (u"ࠫࡤ࠭倾")
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ倿"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨ偀")+text_numbers[l11ll1l1llll_l1_],l11lll_l1_ (u"ࠧࠨ偁"),764,l11lll_l1_ (u"ࠨࠩ偂"),l11lll_l1_ (u"ࠩࠪ偃"),l11lll_l1_ (u"ࠪࠫ偄"),l11lll_l1_ (u"ࠫࠬ偅"),{l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ偆"):l11ll1l1llll_l1_})
	return
def l11ll1ll1l11_l1_():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭假"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭偈")+l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬ偉"),l11lll_l1_ (u"ࠩࠪ偊"),765)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ偋"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ偌"),l11lll_l1_ (u"ࠬ࠭偍"),9999)
	for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
		#l11ll1l1l1ll_l1_ = l11lll_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ偎")+str(l11ll1l1llll_l1_)
		l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡏࡘࠫ偏")+str(l11ll1l1llll_l1_)+l11lll_l1_ (u"ࠨࡡࠪ偐")
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偑"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬ偒")+text_numbers[l11ll1l1llll_l1_],l11lll_l1_ (u"ࠫࠬ偓"),765,l11lll_l1_ (u"ࠬ࠭偔"),l11lll_l1_ (u"࠭ࠧ偕"),l11lll_l1_ (u"ࠧࠨ偖"),l11lll_l1_ (u"ࠨࠩ偗"),{l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ偘"):l11ll1l1llll_l1_})
	return
def l11lll11ll11_l1_(l1l1l1ll1ll_l1_):
	l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
	try:
		if l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ偙") in l1l1l1ll1ll_l1_: l1l1l1l11l1_l1_(l1l1l1ll1ll_l1_)
		else: l1l1l1l11l1_l1_()
		l11ll1ll11ll_l1_ = False
	except: l11ll1ll11ll_l1_ = True
	l1l1l1ll1ll_l1_ = TRANSLATE(l1l1l1ll1ll_l1_)
	if l11ll1ll11ll_l1_: DIALOG_NOTIFICATION(l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫๆฺไࠡส๊ิฬࠦวๅ็๋ๆ฾࠭做"),time=2000)
	else: DIALOG_NOTIFICATION(l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬะๅࠡฮ็ฬࠥอไฤไึห๊࠭偛"),time=2000)
	return l11ll1ll11ll_l1_
def l11ll1l1ll1l_l1_(l11ll1ll1l1l_l1_=True):
	if not l11ll1ll1l1l_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ停"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ偝"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭偞"))
		if results:
			contentsDICT = results
			return
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ偟"),l11lll_l1_ (u"ࠪࠫ偠"),l11lll_l1_ (u"ࠫࠬ偡"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ偢"),l11lll_l1_ (u"࠭ไไ์ࠣฮ๊๊ฦ้ࠡำ๋ࠥอไใษษ้ฮࠦ࠮ࠡษ็ฬึ์วๆฮࠣ๎าะวอࠢฦ๊ࠥ๐แฮืࠣะ๊๐ูࠡ็๋ห็฿ࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦแ๋ࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ึฮำืฬࠡ็้๋ฬࠦแใูࠣห้ษโิษ่ࠤฬ๊ัว์ึ๎ฮࠦ࠮ࠡอ่ࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอิา็๊ࠢิ์ࠦวๅลๅืฬ๋ࠠฮฬ์ࠤ้อࠠหฯอหัࠦร็ࠢอ้้ฬ็ศ่ࠢีฮࠦรฯำ์ࠤ࠳ูࠦๆๆํอ๋ࠥไวࠢฯ้๏฿ࠠศๆฦๆุอๅࠡฬะฮฬาฺࠠษาอࠥษโๅ่๊ࠢࠥ࠹ࠠะไสส็ࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦ๊ࠥะฬๆ฻ࠣๆฬฬๅสࠢส่ศ่ำศ็ࠣห้ศๆࠡมࠪ偣"))
	if l1ll111ll1_l1_!=1: return
	l11ll11l11l1_l1_ = menuItemsLIST
	l11ll1l1l1l1_l1_,l11ll1l1l111_l1_ = 0,l11lll_l1_ (u"ࠧࠨ偤")
	for l1l1l1ll1ll_l1_ in l11l1l11ll1_l1_:
		time.sleep(0.5)
		l11ll1ll11ll_l1_ = l11lll11ll11_l1_(l1l1l1ll1ll_l1_)
		if l11ll1ll11ll_l1_:
			l11ll1l1l1l1_l1_ += 1
			l11ll1l1l111_l1_ += l11lll_l1_ (u"ࠨࠢࠪ健")+l1l1l1ll1ll_l1_
			if l11ll1l1l1l1_l1_>=l11ll1lllll1_l1_: break
	menuItemsLIST[:] = l11ll11l11l1_l1_
	if l11ll1l1l1l1_l1_>=l11ll1lllll1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ偦"),l11lll_l1_ (u"ࠪࠫ偧"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ偨"),l11lll_l1_ (u"๊ࠬฯ๋ๅู้้ࠣไสࠢไ๎ࠥ࠭偩")+str(l11ll1l1l1l1_l1_)+l11lll_l1_ (u"࠭ࠠๆ๊สๆ฾ࠦๅ็่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴้ࠠีหฬ์อࠠใัࠣ๎่๎ๆࠡ฻า้ࠥ๎ฬ้ัࠣษ๋ะั็์อࠤๆ๐ࠠอ้สึ่่่ࠦ์࠽ࠫ偪")+l11ll1l1l111_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ偫"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭偬"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ偭"),l11lll_l1_ (u"ࠪࠫ偮"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ偯"),l11lll_l1_ (u"ࠬะๅࠡฮ็ฬࠥาๅ๋฻ࠣห้ษโิษ่ࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่อืๆศ็ฯࠫ偰"))
	return
def l11ll1l1111l_l1_(l11ll1l1llll_l1_,options):
	l11llllllll_l1_ = False
	l11ll111lll1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllllll_l1_ and l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ偱") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ偲"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ偳"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ側")+l11ll1l1llll_l1_)
	elif l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ偵") not in options or l11lll_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ偶") not in options:
		import IPTV
		message = l11lll_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ偷")
		if l11lll_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭偸") not in options:
			try: IPTV.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭偹"),l11lll_l1_ (u"ࠨࠩ偺"),l11lll_l1_ (u"ࠩࠪ偻"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ偼"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ偽"),l11lll_l1_ (u"ࠬ࠭偾"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ偿"),message)
			try: IPTV.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ傀"),l11lll_l1_ (u"ࠨࠩ傁"),l11lll_l1_ (u"ࠩࠪ傂"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傃"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ傄"),l11lll_l1_ (u"ࠬ࠭傅"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ傆"),message)
			try: IPTV.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ傇"),l11lll_l1_ (u"ࠨࠩ傈"),l11lll_l1_ (u"ࠩࠪ傉"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傊"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ傋"),l11lll_l1_ (u"ࠬ࠭傌"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡏࡐࡕࡘ่้ࠣ็๊ะ์๋๋ฬะࠧ傍"),message)
		if l11lll_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭傎") not in options:
			try: IPTV.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ傏"),l11lll_l1_ (u"ࠩࠪ傐"),l11lll_l1_ (u"ࠪࠫ傑"),options+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ傒"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭傓"),l11lll_l1_ (u"࠭ࠧ傔"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ傕"),message)
			try: IPTV.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ傖"),l11lll_l1_ (u"ࠩࠪ傗"),l11lll_l1_ (u"ࠪࠫ傘"),options+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ備"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭傚"),l11lll_l1_ (u"࠭ࠧ傛"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ傜"),message)
		results = menuItemsLIST
		if l11llllllll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ傝"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ傞")+l11ll1l1llll_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll111lll1_l1_
	return results
def l11ll1ll111l_l1_(l11ll1l1llll_l1_,options):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ傟"),l11lll_l1_ (u"ࠫࠬ傠"),l11lll_l1_ (u"ࠬ࠭傡"),options)
	l11llllllll_l1_ = False
	l11ll111lll1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l11llllllll_l1_ and l11lll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ傢") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ傣"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ傤"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ傥")+l11ll1l1llll_l1_)
	elif l11lll_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ傦") not in options or l11lll_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ傧") not in options:
		import M3U
		message = l11lll_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ储")
		if l11lll_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭傩") not in options:
			try: M3U.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭傪"),l11lll_l1_ (u"ࠨࠩ傫"),l11lll_l1_ (u"ࠩࠪ催"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傭"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ傮"),l11lll_l1_ (u"ࠬ࠭傯"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭傰"),message)
			try: M3U.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ傱"),l11lll_l1_ (u"ࠨࠩ傲"),l11lll_l1_ (u"ࠩࠪ傳"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傴"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ債"),l11lll_l1_ (u"ࠬ࠭傶"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭傷"),message)
			try: M3U.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ傸"),l11lll_l1_ (u"ࠨࠩ傹"),l11lll_l1_ (u"ࠩࠪ傺"),options+l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ傻"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ傼"),l11lll_l1_ (u"ࠬ࠭傽"),l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭傾"),message)
		if l11lll_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭傿") not in options:
			try: M3U.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ僀"),l11lll_l1_ (u"ࠩࠪ僁"),l11lll_l1_ (u"ࠪࠫ僂"),options+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ僃"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭僄"),l11lll_l1_ (u"࠭ࠧ僅"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ僆"),message)
			try: M3U.GROUPS(l11ll1l1llll_l1_,l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ僇"),l11lll_l1_ (u"ࠩࠪ僈"),l11lll_l1_ (u"ࠪࠫ僉"),options+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ僊"),False)
			except: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭僋"),l11lll_l1_ (u"࠭ࠧ僌"),l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ働"),message)
		results = menuItemsLIST
		if l11llllllll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ僎"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ像")+l11ll1l1llll_l1_,results,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll111lll1_l1_
	return results
def l11ll1ll11l1_l1_(l11ll1l1llll_l1_,options,l11ll11ll1ll_l1_):
	if l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ僐") in options and l11ll11ll1ll_l1_==l11lll_l1_ (u"ࠫࠬ僑"): l11ll1l1ll1l_l1_(True)
	elif l11ll11ll1ll_l1_: l11ll1l1ll1l_l1_(False)
	l11ll11llll1_l1_ = options.replace(l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ僒"),l11lll_l1_ (u"࠭ࠧ僓")).replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ僔"),l11lll_l1_ (u"ࠨࠩ僕")).replace(l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭僖"),l11lll_l1_ (u"ࠪࠫ僗"))
	if not l11ll11ll1ll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ僘"),l11lll_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ僙"),l11lll_l1_ (u"࠭ࠧ僚"),763,l11lll_l1_ (u"ࠧࠨ僛"),l11lll_l1_ (u"ࠨࠩ僜"),l11lll_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ僝")+l11ll11llll1_l1_,l11lll_l1_ (u"ࠪࠫ僞"),{l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僟"):l11ll1l1llll_l1_})
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ僠"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭僡"),l11lll_l1_ (u"ࠧࠨ僢"),9999)
	l1ll1l1111_l1_ = [l11lll_l1_ (u"ࠨลไ่ฬ๋ࠧ僣"),l11lll_l1_ (u"่ࠩืู้ไศฬࠪ僤"),l11lll_l1_ (u"ุ้ࠪือ๋ษอࠫ僥"),l11lll_l1_ (u"ࠫอืวๆฮࠪ僦"),l11lll_l1_ (u"ࠬษืโษ็ࠤํ้ัห๊้ࠫ僧"),l11lll_l1_ (u"࠭ัๆุส๊ࠬ僨"),l11lll_l1_ (u"ࠧฤฯาฯ࠲ษฮาࠩ僩"),l11lll_l1_ (u"ࠨี็หุ๊ࠧ僪"),l11lll_l1_ (u"่ࠩ์ุ๐โ๊ࠩ僫"),l11lll_l1_ (u"ࠪวูํั࠮ลๆฯึ࠭僬"),l11lll_l1_ (u"ࠫฬ๊ย็ࠩ僭"),l11lll_l1_ (u"ࠬ฼อไࠩ僮"),l11lll_l1_ (u"࠭ั๋ษูอࠬ僯"),l11lll_l1_ (u"ࠧ็์อๅ้้ำࠨ僰"),l11lll_l1_ (u"ࠨ็่ฯ้๐ๆࠨ僱"),l11lll_l1_ (u"ࠩหฯࠥำ๊ࠨ僲"),l11lll_l1_ (u"ࠪำ๏์๊สࠩ僳"),l11lll_l1_ (u"ุࠫ์่ศฬࠪ僴"),l11lll_l1_ (u"ࠬษฮา๋ࠪ僵")]
	l11ll11l11ll_l1_ = [l11lll_l1_ (u"࠭วโๆส้ࠬ僶"),l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭僷"),l11lll_l1_ (u"ࠨใํ่๊࠭僸"),l11lll_l1_ (u"ࠩไ่๊࠭價")]
	l1l11l1ll11_l1_ = [l11lll_l1_ (u"ุ้๊ࠪำๅࠩ僺"),l11lll_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ僻")]
	l11lll1l111l_l1_ = [l11lll_l1_ (u"๋ࠬำศำะࠫ僼"),l11lll_l1_ (u"࠭ๅิำะ๎ฬะࠧ僽")]
	l11ll11lll1l_l1_ = [l11lll_l1_ (u"ࠧษำส้ั࠭僾"),l11lll_l1_ (u"ࠨࡵ࡫ࡳࡼ࠭僿"),l11lll_l1_ (u"ࠩอ่ๆุ๊้่ࠪ儀"),l11lll_l1_ (u"ࠪฮ้๐แำ์๋๊ࠬ儁")]
	l11ll1llll11_l1_ = [l11lll_l1_ (u"ࠫฬ์ๅ๋ࠩ儂"),l11lll_l1_ (u"้ࠬัห๊้ࠫ儃"),l11lll_l1_ (u"࠭ใศำอ์๋࠭億"),l11lll_l1_ (u"ࠧ࡬࡫ࡧࡷࠬ儅"),l11lll_l1_ (u"ࠨูไ่ࠬ儆"),l11lll_l1_ (u"ࠩส฻ๆอไࠨ儇")]
	l111l111_l1_ = [l11lll_l1_ (u"ࠪี๊฼ว็ࠩ儈")]
	l1lllll1l_l1_ = [l11lll_l1_ (u"ࠫฬำฯฬࠩ儉"),l11lll_l1_ (u"ࠬอฮาࠩ儊"),l11lll_l1_ (u"࠭ๅ้ะิࠫ儋"),l11lll_l1_ (u"ࠧอัํำࠬ儌"),l11lll_l1_ (u"ࠨ็ูหๆ࠭儍"),l11lll_l1_ (u"ࠩะำ๏ัࠧ儎")]
	l11ll1l111l1_l1_ = [l11lll_l1_ (u"ࠪื้อำๅࠩ儏"),l11lll_l1_ (u"ุ๊ࠫำๅ้ࠪ儐")]
	l11ll111ll11_l1_ = [l11lll_l1_ (u"ࠬอฺศ่ํࠫ儑"),l11lll_l1_ (u"࠭ๅ้ีํๆ๎࠭儒"),l11lll_l1_ (u"ࠧไๆํฬࠬ儓"),l11lll_l1_ (u"ࠨฯไ่ࠬ儔"),l11lll_l1_ (u"ࠩࡰࡹࡸ࡯ࡣࠨ儕")]
	l1111ll1l_l1_ = [l11lll_l1_ (u"ࠪห่ััࠨ儖"),l11lll_l1_ (u"ࠫฬฺ็าࠩ儗"),l11lll_l1_ (u"๋ࠬๅ๋ิ๊ࠫ儘"),l11lll_l1_ (u"࠭วฺๆ์ࠫ儙"),l11lll_l1_ (u"ࠧๆะอหึํࠧ儚"),l11lll_l1_ (u"ࠨ็ัฮฬืวหࠩ儛"),l11lll_l1_ (u"ࠩสๆํ๏ࠧ儜")]
	l11ll111l1ll_l1_ = [l11lll_l1_ (u"ࠪห้อๆࠨ儝"),l11lll_l1_ (u"ࠫาอไ๋ࠩ儞"),l11lll_l1_ (u"๋ࠬหษฬࠪ償"),l11lll_l1_ (u"࠭ัศศฯࠫ儠")]
	l11ll111llll_l1_ = [l11lll_l1_ (u"ࠧืฯๆࠫ儡"),l11lll_l1_ (u"ࠨๅ๋้๏ี๊ࠨ儢")]
	l11lll111ll1_l1_ = [l11lll_l1_ (u"ࠩิ๎ฬ฼็ࠨ儣"),l11lll_l1_ (u"ࠪ็ํื็ࠨ儤"),l11lll_l1_ (u"๊ࠫ฻วา฻๊ࠫ儥"),l11lll_l1_ (u"ฺ่ࠬหࠩ儦"),l11lll_l1_ (u"࠭ั๋ษูอࠬ儧")]
	l11ll1ll1lll_l1_ = [l11lll_l1_ (u"ࠧ็์อๅ้้ำࠨ儨"),l11lll_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ儩"),l11lll_l1_ (u"้ࠩ๎ฯ็ไ๋ๅึࠫ優")]
	l11ll11l111l_l1_ = [l11lll_l1_ (u"้๊ࠪัไ๋่ࠪ儫"),l11lll_l1_ (u"ࠫฬฺฮศืࠪ儬"),l11lll_l1_ (u"ࠬ์ฬ้็ࠪ儭")]
	l1l1lll1l_l1_ = [l11lll_l1_ (u"࠭ศฬࠢะ๎ࠬ儮"),l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ儯"),l11lll_l1_ (u"ࠨไ้ห์࠭儰"),l11lll_l1_ (u"ࠩๅ๊ํอสࠨ儱")]
	l11ll1lll1l1_l1_ = [l11lll_l1_ (u"ࠪำ๏์ࠧ儲"),l11lll_l1_ (u"ࠫฬีู๋้ࠪ儳"),l11lll_l1_ (u"ุ๊ࠬศำสฮࠬ儴"),l11lll_l1_ (u"࠭ไุ็ํหฯ࠭儵"),l11lll_l1_ (u"ࠧะ฻สลࠬ儶"),l11lll_l1_ (u"ࠨไิห๋࠭儷"),l11lll_l1_ (u"ࠩๅูฬฬฯࠨ儸"),l11lll_l1_ (u"ࠪีะอมࠨ儹"),l11lll_l1_ (u"๊ࠫืฬฺ์๊ࠫ儺"),l11lll_l1_ (u"ࠬอะศ่ࠪ儻"),l11lll_l1_ (u"࠭วิๆส้ࠬ儼"),l11lll_l1_ (u"ࠧห๊สุ๏ำࠧ儽"),l11lll_l1_ (u"ࠨะฺฬࠬ儾"),l11lll_l1_ (u"ࠩะ์ื๎๊ࠨ儿"),l11lll_l1_ (u"ࠪ฽ฯฮวหࠩ兀"),l11lll_l1_ (u"๊ࠫ๎วๅ์าࠫ允"),l11lll_l1_ (u"ࠬ์่ศ฻ํࠫ兂"),l11lll_l1_ (u"ู࠭ใษษำࠬ元"),l11lll_l1_ (u"ࠧศ่สุ๏ีࠧ兄")]
	l11ll11l1l11_l1_ = [l11lll_l1_ (u"ࠨ࠳࠼ࠫ充"),l11lll_l1_ (u"ࠩ࠵࠴ࠬ兆"),l11lll_l1_ (u"ࠪ࠶࠶࠭兇"),l11lll_l1_ (u"ࠫ࠷࠸ࠧ先"),l11lll_l1_ (u"ࠬ࠸࠳ࠨ光"),l11lll_l1_ (u"࠭࠲࠵ࠩ兊"),l11lll_l1_ (u"ࠧ࠳࠷ࠪ克"),l11lll_l1_ (u"ࠨ࠴࠹ࠫ兌")]
	if not l11ll11ll1ll_l1_:
		l11ll11ll1ll_l1_ = 0
		for l11ll1l1lll1_l1_ in l1ll1l1111_l1_:
			l11ll11ll1ll_l1_ += 1
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ免"),l111ll_l1_+l11ll1l1lll1_l1_,l11lll_l1_ (u"ࠪࠫ兎"),763,l11lll_l1_ (u"ࠫࠬ兏"),str(l11ll11ll1ll_l1_),l11ll11llll1_l1_,l11lll_l1_ (u"ࠬ࠭児"),{l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭兑"):l11ll1l1llll_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1ll111lll1_l1_ = name.lower()
			category = []
			if any(value in l1ll111lll1_l1_ for value in l11ll11l11ll_l1_): category.append(1)
			if any(value in l1ll111lll1_l1_ for value in l1l11l1ll11_l1_): category.append(2)
			if any(value in l1ll111lll1_l1_ for value in l11lll1l111l_l1_): category.append(3)
			if any(value in l1ll111lll1_l1_ for value in l11ll11lll1l_l1_): category.append(4)
			if any(value in l1ll111lll1_l1_ for value in l11ll1llll11_l1_): category.append(5)
			if any(value in l1ll111lll1_l1_ for value in l111l111_l1_): category.append(6)
			if any(value in l1ll111lll1_l1_ for value in l1lllll1l_l1_) and l1ll111lll1_l1_ not in [l11lll_l1_ (u"ࠧศะิํࠬ兒")]: category.append(7)
			if any(value in l1ll111lll1_l1_ for value in l11ll1l111l1_l1_): category.append(8)
			if any(value in l1ll111lll1_l1_ for value in l11ll111ll11_l1_): category.append(9)
			if any(value in l1ll111lll1_l1_ for value in l1111ll1l_l1_): category.append(10)
			if any(value in l1ll111lll1_l1_ for value in l11ll111l1ll_l1_): category.append(11)
			if any(value in l1ll111lll1_l1_ for value in l11ll111llll_l1_): category.append(12)
			if any(value in l1ll111lll1_l1_ for value in l11lll111ll1_l1_): category.append(13)
			if any(value in l1ll111lll1_l1_ for value in l11ll1ll1lll_l1_): category.append(14)
			if any(value in l1ll111lll1_l1_ for value in l11ll11l111l_l1_): category.append(15)
			if any(value in l1ll111lll1_l1_ for value in l1l1lll1l_l1_): category.append(16)
			if any(value in l1ll111lll1_l1_ for value in l11ll1lll1l1_l1_): category.append(17)
			if any(value in l1ll111lll1_l1_ for value in l11ll11l1l11_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l11ll11ll1ll_l1_:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ兓"),l111ll_l1_+name,name,166,l11lll_l1_ (u"ࠩࠪ兔"),l11lll_l1_ (u"ࠪࠫ兕"),l11ll11llll1_l1_+l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ兖"))
	return
def l11lll111111_l1_(l11ll1l1llll_l1_,options):
	l11llllllll_l1_ = False
	if l11llllllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ兗"),l11lll_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ兘"),l11lll_l1_ (u"ࠧࠨ兙"),764,l11lll_l1_ (u"ࠨࠩ党"),l11lll_l1_ (u"ࠩࠪ兛"),l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ兜"),l11lll_l1_ (u"ࠫࠬ兝"),{l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ兞"):l11ll1l1llll_l1_})
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ兟"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ兠"),l11lll_l1_ (u"ࠨࠩ兡"),9999)
	l11ll111lll1_l1_ = menuItemsLIST[:]
	import IPTV
	if l11ll1l1llll_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l11ll1l1llll_l1_,True): return
		l11ll1l111ll_l1_ = l11ll1l1111l_l1_(l11ll1l1llll_l1_,options)
		l1ll1lll1ll_l1_ = sorted(l11ll1l111ll_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠩࠪ兢"),True): return
		if l11llllllll_l1_ and l11lll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ兣") not in options:
			l1ll1lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ兤"),l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ入"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪ兦"))
		else:
			l11ll11l1l1l_l1_,l1ll1lll1ll_l1_,l11ll1l111ll_l1_ = [],[],[]
			for l11ll1l1l1ll_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1lll1ll_l1_ += l11ll1l1111l_l1_(str(l11ll1l1l1ll_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1ll1lll1ll_l1_:
				if text not in l11ll11l1l1l_l1_:
					l11ll11l1l1l_l1_.append(text)
					l11lll11l111_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll111l111_l1_
					l11ll1l111ll_l1_.append(l11lll11l111_l1_)
			l1ll1lll1ll_l1_ = sorted(l11ll1l111ll_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllllll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧ內"),l11lll_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬ全"),l1ll1lll1ll_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll111lll1_l1_+l1ll1lll1ll_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭兩"))
	return
def l11lll11l1ll_l1_(l11ll1l1llll_l1_,options):
	l11llllllll_l1_ = False
	if l11llllllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ兪"),l11lll_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ八"),l11lll_l1_ (u"ࠬ࠭公"),765,l11lll_l1_ (u"࠭ࠧ六"),l11lll_l1_ (u"ࠧࠨ兮"),l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭兯"),l11lll_l1_ (u"ࠩࠪ兰"),{l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ共"):l11ll1l1llll_l1_})
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ兲"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ关"),l11lll_l1_ (u"࠭ࠧ兴"),9999)
	l11ll111lll1_l1_ = menuItemsLIST[:]
	import M3U
	if l11ll1l1llll_l1_:
		if not M3U.CHECK_TABLES_EXIST(l11ll1l1llll_l1_,True): return
		l11ll1l111ll_l1_ = l11ll1ll111l_l1_(l11ll1l1llll_l1_,options)
		l1ll1lll1ll_l1_ = sorted(l11ll1l111ll_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠧࠨ兵"),True): return
		if l11llllllll_l1_ and l11lll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭其") not in options:
			l1ll1lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ具"),l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ典"),l11lll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ兹"))
		else:
			l11ll11l1l1l_l1_,l1ll1lll1ll_l1_,l11ll1l111ll_l1_ = [],[],[]
			for l11ll1l1l1ll_l1_ in range(1,FOLDERS_COUNT+1):
				l1ll1lll1ll_l1_ += l11ll1ll111l_l1_(str(l11ll1l1l1ll_l1_),options)
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1ll1lll1ll_l1_:
				if text not in l11ll11l1l1l_l1_:
					l11ll11l1l1l_l1_.append(text)
					l11lll11l111_l1_ = type,name,text,165,l11l_l1_,l1l11l1_l1_,options,context,l1ll111l111_l1_
					l11ll1l111ll_l1_.append(l11lll11l111_l1_)
			l1ll1lll1ll_l1_ = sorted(l11ll1l111ll_l1_,reverse=False,key=lambda key: key[1].lower())
			if l11llllllll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ兺"),l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩ养"),l1ll1lll1ll_l1_,PERMANENT_CACHE)
	menuItemsLIST[:] = l11ll111lll1_l1_+l1ll1lll1ll_l1_
	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ兼"))
	return
def l11ll11ll11l_l1_(group,options):
	# l11ll11l1lll_l1_ & iptv
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ兽"),l11lll_l1_ (u"ࠩࠪ兾"),group,options)
	l11llllllll_l1_ = False
	results = []
	l11ll1ll1111_l1_ = l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ兿") if l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ冀") in options else l11lll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ冁")
	if l11llllllll_l1_: results = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ冂"),l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ冃")+l11ll1ll1111_l1_[:-1],group)
	if not results:
		for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
			if l11llllllll_l1_: results += READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭冄"),l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ内")+l11ll1ll1111_l1_[:-1],l11lll_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬ円")+l11ll1ll1111_l1_+str(l11ll1l1llll_l1_))
			elif l11ll1ll1111_l1_==l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ冇"): results += l11ll1l1111l_l1_(str(l11ll1l1llll_l1_),l11lll_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ冈"))
			elif l11ll1ll1111_l1_==l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ冉"): results += l11ll1ll111l_l1_(str(l11ll1l1llll_l1_),l11lll_l1_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬ冊"))
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in results:
			if text==group: l1l1l11l1l1l_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
		items,l1l1lll_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in menuItemsLIST:
			l11ll1lll11l_l1_ = type,name[4:],url,mode,l11l_l1_,l1l11l1_l1_,text,context,l11lll_l1_ (u"ࠨࠩ冋")
			if l11ll1lll11l_l1_ not in l1l1lll_l1_:
				l1l1lll_l1_.append(l11ll1lll11l_l1_)
				item = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_
				items.append(item)
		results = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l11llllllll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫ册")+l11ll1ll1111_l1_[:-1],group,results,PERMANENT_CACHE)
	if l11lll_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ再") in options and len(results)>l11lll1111l1_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ冎"),l11lll_l1_ (u"ࠬࡡ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ冏")+group+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡ࠼ส่็ูๅ࡞ࠩ冐"),group,165,l11lll_l1_ (u"ࠧࠨ冑"),l11lll_l1_ (u"ࠨࠩ冒"),l11ll1ll1111_l1_+l11lll_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ冓"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ冔"),l11lll_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ冕"),group,165,l11lll_l1_ (u"ࠬ࠭冖"),l11lll_l1_ (u"࠭ࠧ冗"),l11ll1ll1111_l1_+l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭冘"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭写"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ冚"),l11lll_l1_ (u"ࠪࠫ军"),9999)
		results = menuItemsLIST+random.sample(results,l11lll1111l1_l1_)
	menuItemsLIST[:] = results
	xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ农"))
	return
def l11lll1l11l1_l1_(options):
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ冝"),l11lll_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ冞"),l11lll_l1_ (u"ࠧࠨ冟"),161,l11lll_l1_ (u"ࠨࠩ冠"),l11lll_l1_ (u"ࠩࠪ冡"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ冢"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ冣"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冤"),l11lll_l1_ (u"࠭ࠧ冥"),9999)
	l1l1l111llll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ冦"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ࡞࡛ࡔࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冧")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ冨"),l11lll_l1_ (u"ࠪࠫ冩"),147)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ冪"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ冫")+l11lll_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ冬"),l11lll_l1_ (u"ࠧࠨ冭"),148)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ冮"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡏࡆࡍࠢࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ冯")+l11lll_l1_ (u"ࠪๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠬ冰"),l11lll_l1_ (u"ࠫࠬ冱"),28)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ冲"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡐࡖࡋࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ决")+l11lll_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ冴"),l11lll_l1_ (u"ࠨࠩ况"),41)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ冶"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡋࡘࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭冷")+l11lll_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ冸"),l11lll_l1_ (u"ࠬ࠭冹"),135)
	import l1ll111lll11_l1_
	l1ll111lll11_l1_.ITEMS(l11lll_l1_ (u"࠭࠰ࠨ冺"),False)
	l1ll111lll11_l1_.ITEMS(l11lll_l1_ (u"ࠧ࠲ࠩ冻"),False)
	l1ll111lll11_l1_.ITEMS(l11lll_l1_ (u"ࠨ࠴ࠪ冼"),False)
	#l1ll111lll11_l1_.ITEMS(l11lll_l1_ (u"ࠩ࠶ࠫ冽"),False)
	if l11lll_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ冾") in options:
		menuItemsLIST[:] = l11ll1l11lll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11lll1111l1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1111l1_l1_)
	menuItemsLIST[:] = l1l1l111llll_l1_+menuItemsLIST
	return
def l11lll1l1111_l1_(options):
	options = options.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭冿"),l11lll_l1_ (u"ࠬ࠭净")).replace(l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ凁"),l11lll_l1_ (u"ࠧࠨ凂"))
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ凃") : l11lll_l1_ (u"ࠩࠪ凄") }
	url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩ凅")
	data = {l11lll_l1_ (u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭准"):l11lll_l1_ (u"ࠬ࠻࠰ࠨ凇")}
	data = l1ll1l1ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ凈"),url,data,headers,l11lll_l1_ (u"ࠧࠨ凉"),l11lll_l1_ (u"ࠨࠩ凊"),l11lll_l1_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕࡢࡊࡗࡕࡍࡠ࡙ࡒࡖࡉ࡙࠭࠲ࡵࡷࠫ凋"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬ凌"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ凍"),block,re.DOTALL)
	l11ll111l11l_l1_,l11ll11l1ll1_l1_ = list(zip(*items))
	l11lll11l1l1_l1_ = []
	l11lll11llll_l1_ = [l11lll_l1_ (u"ࠬࠦࠧ凎"),l11lll_l1_ (u"࠭ࠢࠨ减"),l11lll_l1_ (u"ࠧࡡࠩ凐"),l11lll_l1_ (u"ࠨ࠮ࠪ凑"),l11lll_l1_ (u"ࠩ࠱ࠫ凒"),l11lll_l1_ (u"ࠪ࠾ࠬ凓"),l11lll_l1_ (u"ࠫࡀ࠭凔"),l11lll_l1_ (u"ࠧ࠭ࠢ凕"),l11lll_l1_ (u"࠭࠭ࠨ凖")]
	l11ll1llllll_l1_ = l11ll11l1ll1_l1_+l11ll111l11l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ凗"),l11lll_l1_ (u"ࠨࠩ凘"),l11lll_l1_ (u"ࠩࠪ凙"),str(l11ll1llllll_l1_))
	for word in l11ll1llllll_l1_:
		if word in l11ll11l1ll1_l1_: l11ll1ll1ll1_l1_ = 2
		if word in l11ll111l11l_l1_: l11ll1ll1ll1_l1_ = 4
		l11ll1l11111_l1_ = [i in word for i in l11lll11llll_l1_]
		if any(l11ll1l11111_l1_):
			index = l11ll1l11111_l1_.index(True)
			l11ll11lll11_l1_ = l11lll11llll_l1_[index]
			l11lll111l11_l1_ = l11lll_l1_ (u"ࠪࠫ凚")
			if word.count(l11ll11lll11_l1_)>1: l11lll111l1l_l1_,l11lll1111ll_l1_,l11lll111l11_l1_ = word.split(l11ll11lll11_l1_,2)
			else: l11lll111l1l_l1_,l11lll1111ll_l1_ = word.split(l11ll11lll11_l1_,1)
			if len(l11lll111l1l_l1_)>l11ll1ll1ll1_l1_: l11lll11l1l1_l1_.append(l11lll111l1l_l1_.lower())
			if len(l11lll1111ll_l1_)>l11ll1ll1ll1_l1_: l11lll11l1l1_l1_.append(l11lll1111ll_l1_.lower())
			if len(l11lll111l11_l1_)>l11ll1ll1ll1_l1_: l11lll11l1l1_l1_.append(l11lll111l11_l1_.lower())
		elif len(word)>l11ll1ll1ll1_l1_: l11lll11l1l1_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11lll11l1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11lll11l1l1_l1_)),l11lll11l1l1_l1_)
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊ࡮࡬ࡷࡹࠦ࠽ࠡ࡝ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣ฽ึฮ๊สࠩ࠯่๊ࠫๅศฬࠣ฽ู๎วว์ฬࠤส์ใๅ์ี๎ฮ࠭࡝ࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠵࠭ࠏࠏ࡬ࡪࡵࡷ࠵ࠥࡃࠠ࡜࡟ࠍࠍࡨࡵࡵ࡯ࡶࡶࠤࡂࠦ࡬ࡦࡰࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡩ࡯ࡶࡰࡷࡷ࠯࠻ࠩ࠻ࠢࡵࡥࡳࡪ࡯࡮࠰ࡶ࡬ࡺ࡬ࡦ࡭ࡧࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࡩࡷ࡬࠮ࡀࠠ࡭࡫ࡶࡸ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧไๆ่อࠥ฿ิ้ษษ๎ฮࠦัใ็ࠣࠫ࠰ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠏࠏࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไๅ฼ฬ࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࠧࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡂࡃ࠰࠻ࠢ࡯࡭ࡸࡺ࠲ࠡ࠿ࠣࡥࡷࡨࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡦࡰࡪࡐࡎ࡙ࡔࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠴࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠡ࠾ࠢ࠰࠵࠿ࠦࡢࡳࡧࡤ࡯ࠏࠏࠉࡦ࡮࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡶࡩࡦࡸࡣࡩࠢࡀࠤࡱ࡯ࡳࡵ࠴࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠤࠥࠦ凛")
	if l11lll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭凜") in options:
		l11ll11l1111_l1_ = l1l1l1lll1ll_l1_
	elif l11lll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭凝") in options:
		l11ll11l1111_l1_ = [l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ凞")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠨࠩ凟"),True): return
	elif l11lll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ几") in options:
		l11ll11l1111_l1_ = [l11lll_l1_ (u"ࠪࡑ࠸࡛ࠧ凡")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠫࠬ凢"),True): return
	count,l11ll1l1ll11_l1_ = 0,0
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ凣"),l11lll_l1_ (u"࡛࠭ࠡࠢࡠࠤ࠿อไษฯฮࠤ฾์ࠧ凤"),l11lll_l1_ (u"ࠧࠨ凥"),164,l11lll_l1_ (u"ࠨࠩ処"),l11lll_l1_ (u"ࠩࠪ凧"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ凨")+options)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ凩"),l11lll_l1_ (u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬ凪"),l11lll_l1_ (u"࠭ࠧ凫"),164,l11lll_l1_ (u"ࠧࠨ凬"),l11lll_l1_ (u"ࠨࠩ凭"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ凮")+options)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ凯"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ凰"),l11lll_l1_ (u"ࠬ࠭凱"),9999)
	l11ll111l111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l11lll11lll1_l1_ = []
	for word in l11lll11l1l1_l1_:
		l11lll1111ll_l1_ = re.findall(l11lll_l1_ (u"࡛࠭ࠡ࡞࠯ࡠࡀࡢ࠺࡝࠯࡟࠯ࡡࡃ࡜ࠣ࡞ࠪࡠࡠࡢ࡝࡝ࠪ࡟࠭ࡡࢁ࡜ࡾ࡞ࠤࡠࡅࡢࠣ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫ凲"),word,re.DOTALL)
		if l11lll1111ll_l1_: word = word.split(l11lll1111ll_l1_[0],1)[0]
		l11ll1llll1l_l1_ = word.replace(l11lll_l1_ (u"ࠧ๒ࠩ凳"),l11lll_l1_ (u"ࠨࠩ凴")).replace(l11lll_l1_ (u"ࠩ๑ࠫ凵"),l11lll_l1_ (u"ࠪࠫ凶")).replace(l11lll_l1_ (u"ࠫ๐࠭凷"),l11lll_l1_ (u"ࠬ࠭凸")).replace(l11lll_l1_ (u"࠭๏ࠨ凹"),l11lll_l1_ (u"ࠧࠨ出")).replace(l11lll_l1_ (u"ࠨ๎ࠪ击"),l11lll_l1_ (u"ࠩࠪ凼"))
		l11ll1llll1l_l1_ = l11ll1llll1l_l1_.replace(l11lll_l1_ (u"ࠪ๔ࠬ函"),l11lll_l1_ (u"ࠫࠬ凾")).replace(l11lll_l1_ (u"ࠬ๓ࠧ凿"),l11lll_l1_ (u"࠭ࠧ刀")).replace(l11lll_l1_ (u"ࠧ๓ࠩ刁"),l11lll_l1_ (u"ࠨࠩ刂")).replace(l11lll_l1_ (u"ࠩฏࠫ刃"),l11lll_l1_ (u"ࠪࠫ刄")).replace(l11lll_l1_ (u"ࠫๅ࠭刅"),l11lll_l1_ (u"ࠬ࠭分"))
		if l11ll1llll1l_l1_: l11lll11lll1_l1_.append(l11ll1llll1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l11lll11lll1_l1_)),l11lll11lll1_l1_)
	l11ll1lll1ll_l1_ = []
	for l11l1lllll_l1_ in range(0,20):
		search = random.sample(l11lll11lll1_l1_,1)[0]
		if search in l11ll1lll1ll_l1_: continue
		l11ll1lll1ll_l1_.append(search)
		l1l1l1ll1ll_l1_ = random.sample(l11ll11l1111_l1_,1)[0]
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭切"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ刈")+str(l1l1l1ll1ll_l1_)+l11lll_l1_ (u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ刉")+search)
		#results = l1l1l11l1l1l_l1_(l11lll_l1_ (u"ࠩࠪ刊"),l11lll_l1_ (u"ࠪࠫ刋"),l11lll_l1_ (u"ࠫࠬ刌"),l1l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭刍"),l11lll_l1_ (u"࠭ࠧ刎"),search+l11lll_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ刏"),l11lll_l1_ (u"ࠨࠩ刐"),l11lll_l1_ (u"ࠩࠪ刑"))
		l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
		l1l1l1ll1l1_l1_(search+l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ划"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ刓"),l11lll_l1_ (u"ࠬ࠭刔"))
	l11ll111l111_l1_[0][1] = l11lll_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ刕")+search+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ฬาัฺ่ࠠࡠࠫ刖")
	menuItemsLIST[:] = l11ll1l11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11lll1111l1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11lll1111l1_l1_)
	menuItemsLIST[:] = l11ll111l111_l1_+menuItemsLIST
	#import l1ll1l1111l_l1_
	#l1ll1l1111l_l1_.SEARCH(search)
	return
def l11lll111lll_l1_(l11ll11ll1l1_l1_,options):
	l11ll11ll1l1_l1_ = l11ll11ll1l1_l1_.replace(l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ列"),l11lll_l1_ (u"ࠩࠪ刘"))
	options = options.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ则"),l11lll_l1_ (u"ࠫࠬ刚")).replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ创"),l11lll_l1_ (u"࠭ࠧ刜"))
	l11ll1l1ll1l_l1_(False)
	if contentsDICT=={}: return
	if l11lll_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ初") in options:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ刞"),l11lll_l1_ (u"ࠩ࡞࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭刟")+l11ll11ll1l1_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡀวๅไึ้ࡢ࠭删"),l11ll11ll1l1_l1_,166,l11lll_l1_ (u"ࠫࠬ刡"),l11lll_l1_ (u"ࠬ࠭刢"),l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ刣")+options)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ判"),l11lll_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ別"),l11ll11ll1l1_l1_,166,l11lll_l1_ (u"ࠩࠪ刦"),l11lll_l1_ (u"ࠪࠫ刧"),l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ刨")+options)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ利"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭刪"),l11lll_l1_ (u"ࠧࠨ别"),9999)
	for l1l1ll11_l1_ in sorted(list(contentsDICT[l11ll11ll1l1_l1_].keys())):
		type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = contentsDICT[l11ll11ll1l1_l1_][l1l1ll11_l1_]
		if l11lll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ刬") in options or len(contentsDICT[l11ll11ll1l1_l1_])==1:
			l1l1l11l1l1l_l1_(type,l11lll_l1_ (u"ࠩࠪ刭"),url,l1l1ll11111l_l1_,l11lll_l1_ (u"ࠪࠫ刮"),l1l11l1_l1_,text,l11lll_l1_ (u"ࠫࠬ刯"),l11lll_l1_ (u"ࠬ࠭到"))
			menuItemsLIST[:] = l11ll1l11lll_l1_(menuItemsLIST)
			l11ll111lll1_l1_,l1ll1lll1ll_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1ll1lll1ll_l1_)
			if l11lll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ刱") in options: menuItemsLIST[:] = l11ll111lll1_l1_+l1ll1lll1ll_l1_[:l11lll1111l1_l1_]
			else: menuItemsLIST[:] = l11ll111lll1_l1_+l1ll1lll1ll_l1_
		elif l11lll_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ刲") in options: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ刳"),l1l1ll11_l1_,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
	return
def l11ll1l11l11_l1_(options,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ刴"),l11lll_l1_ (u"ࠪࠫ刵"),l11lll_l1_ (u"ࠫࠬ制"),options)
	options = options.replace(l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ刷"),l11lll_l1_ (u"࠭ࠧ券")).replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ刹"),l11lll_l1_ (u"ࠨࠩ刺"))
	name,l11ll11lllll_l1_ = l11lll_l1_ (u"ࠩࠪ刻"),[]
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ刼"),l11lll_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ刽")+name+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ刾"),l11lll_l1_ (u"࠭ࠧ刿"),mode,l11lll_l1_ (u"ࠧࠨ剀"),l11lll_l1_ (u"ࠨࠩ剁"),l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ剂")+options)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ剃"),l11lll_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫ剄"),l11lll_l1_ (u"ࠬ࠭剅"),mode,l11lll_l1_ (u"࠭ࠧ剆"),l11lll_l1_ (u"ࠧࠨ則"),l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭剈")+options)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ剉"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ削"),l11lll_l1_ (u"ࠫࠬ剋"),9999)
	l11ll111lll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	results = []
	if l11lll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭剌") in options:
		l11ll1l1ll1l_l1_(False)
		if contentsDICT=={}: return
		l11ll1l11ll1_l1_ = list(contentsDICT.keys())
		l11ll11ll1l1_l1_ = random.sample(l11ll1l11ll1_l1_,1)[0]
		l11lll11l1l1_l1_ = list(contentsDICT[l11ll11ll1l1_l1_].keys())
		l1l1ll11_l1_ = random.sample(l11lll11l1l1_l1_,1)[0]
		type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = contentsDICT[l11ll11ll1l1_l1_][l1l1ll11_l1_]
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭前"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠࡸࡧࡥࡷ࡮ࡺࡥ࠻ࠢࠪ剎")+l1l1ll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ剏")+name+l11lll_l1_ (u"ࠩࠣࠤࠥࡻࡲ࡭࠼ࠣࠫ剐")+url+l11lll_l1_ (u"ࠪࠤࠥࠦ࡭ࡰࡦࡨ࠾ࠥ࠭剑")+str(l1l1ll11111l_l1_))
	elif l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ剒") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠬ࠭剓"),True): return
		for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11ll1l1111l_l1_(str(l11ll1l1llll_l1_),options)
		if not results: return
		type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭剔"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ剕")+name+l11lll_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ剖")+url+l11lll_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ剗")+str(l1l1ll11111l_l1_))
	elif l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ剘") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l11lll_l1_ (u"ࠫࠬ剙"),True): return
		for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
			results += l11ll1ll111l_l1_(str(l11ll1l1llll_l1_),options)
		if not results: return
		type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(results,1)[0]
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ剚"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭剛")+name+l11lll_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ剜")+url+l11lll_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ剝")+str(l1l1ll11111l_l1_))
	l11ll1lll111_l1_ = name
	l11ll1l1l11l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ剞"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ剟")+name+l11lll_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭剠")+url+l11lll_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ剡")+str(l1l1ll11111l_l1_))
		menuItemsLIST[:] = []
		if l1l1ll11111l_l1_==234 and l11lll_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ剢") in text: l1l1ll11111l_l1_ = 233
		if l1l1ll11111l_l1_==714 and l11lll_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ剣") in text: l1l1ll11111l_l1_ = 713
		if l1l1ll11111l_l1_==144: l1l1ll11111l_l1_ = 291
		dummy = l1l1l11l1l1l_l1_(type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
		#if l11lll_l1_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤ࠭剤") in html: l11ll1l11l11_l1_(options,mode)
		if l11lll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ剥") in options and l1l1ll11111l_l1_==167: del menuItemsLIST[:3]
		if l11lll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ剦") in options and l1l1ll11111l_l1_==168: del menuItemsLIST[:3]
		l11ll11lllll_l1_[:] = l11ll1l11lll_l1_(menuItemsLIST)
		if l11ll1l1l11l_l1_ and l1l11lll11l1_l1_(l11lll_l1_ (u"ࡹࠬำไใหࠪ剧")) in str(l11ll11lllll_l1_) or l1l11lll11l1_l1_(l11lll_l1_ (u"ࡺ࠭อๅไ๊ࠫ剨")) in str(l11ll11lllll_l1_):
			name = l11ll1lll111_l1_
			l11ll11lllll_l1_[:] = l11ll1l1l11l_l1_
			break
		l11ll1lll111_l1_ = name
		l11ll1l1l11l_l1_ = l11ll11lllll_l1_
		if str(l11ll11lllll_l1_).count(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ剩"))>0: break
		if str(l11ll11lllll_l1_).count(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ剪"))>0: break
		if l1l1ll11111l_l1_==233: break	# iptv l111ll11_l1_ names l11l1lll1l1_l1_ of l1l1l_l1_ name
		if l1l1ll11111l_l1_==713: break	# l11ll11l1lll_l1_ l111ll11_l1_ names l11l1lll1l1_l1_ of l1l1l_l1_ name
		if l1l1ll11111l_l1_==291: break	# l1ll1llll_l1_ l11lll11l11l_l1_ names l11l1lll1l1_l1_ of l1ll1llll_l1_ l11lll11l11l_l1_ contents
		if l11ll11lllll_l1_: type,name,url,l1l1ll11111l_l1_,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = random.sample(l11ll11lllll_l1_,1)[0]
	if not name: name = l11lll_l1_ (u"ࠨ࠰࠱࠲࠳࠭剫")
	elif name.count(l11lll_l1_ (u"ࠩࡢࠫ剬"))>1: name = name.split(l11lll_l1_ (u"ࠪࡣࠬ剭"),2)[2]
	name = name.replace(l11lll_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒ࠿ࠦࠧ剮"),l11lll_l1_ (u"ࠬ࠭副"))#.replace(l11lll_l1_ (u"࠭ࠬࡎࡑ࡙ࡍࡊ࡙࠺ࠡࠩ剰"),l11lll_l1_ (u"ࠧࠨ剱")).replace(l11lll_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ割"),l11lll_l1_ (u"ࠩࠪ剳")).replace(l11lll_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ剴"),l11lll_l1_ (u"ࠫࠬ創"))
	name = name.replace(l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ剶"),l11lll_l1_ (u"࠭ࠧ剷"))
	l11ll111lll1_l1_[0][1] = l11lll_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ剸")+name+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ剹")
	for i in range(9): random.shuffle(l11ll11lllll_l1_)
	if l11lll_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ剺") in options: menuItemsLIST[:] = l11ll111lll1_l1_+l11ll11lllll_l1_[:l11lll1111l1_l1_]
	else: menuItemsLIST[:] = l11ll111lll1_l1_+l11ll11lllll_l1_
	return
def l11ll11ll111_l1_(l11ll111l1l1_l1_,l11lll11111l_l1_):
	l11lll11111l_l1_ = l11lll11111l_l1_.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ剻"),l11lll_l1_ (u"ࠫࠬ剼")).replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ剽"),l11lll_l1_ (u"࠭ࠧ剾"))
	l11ll1l11l1l_l1_ = l11lll11111l_l1_
	if l11lll_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ剿") in l11lll11111l_l1_:
		l11ll1l11l1l_l1_ = l11lll11111l_l1_.split(l11lll_l1_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ劀"))[0]
		type = l11lll_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ劁")
	elif l11lll_l1_ (u"࡚ࠪࡔࡊࠧ劂") in l11ll111l1l1_l1_: type = l11lll_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ劃")
	elif l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ劄") in l11ll111l1l1_l1_: type = l11lll_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ劅")
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ劆"),l11lll_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ劇")+type+l11ll1l11l1l_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ劈"),l11ll111l1l1_l1_,167,l11lll_l1_ (u"ࠪࠫ劉"),l11lll_l1_ (u"ࠫࠬ劊"),l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ劋")+l11lll11111l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭劌"),l11lll_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭劍"),l11ll111l1l1_l1_,167,l11lll_l1_ (u"ࠨࠩ劎"),l11lll_l1_ (u"ࠩࠪ劏"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ劐")+l11lll11111l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ劑"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ劒"),l11lll_l1_ (u"࠭ࠧ劓"),9999)
	import IPTV
	for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ劔") in l11lll11111l_l1_: IPTV.GROUPS(str(l11ll1l1llll_l1_),l11ll111l1l1_l1_,l11lll11111l_l1_,l11lll_l1_ (u"ࠨࠩ劕"),False)
		else: IPTV.ITEMS(str(l11ll1l1llll_l1_),l11ll111l1l1_l1_,l11lll11111l_l1_,l11lll_l1_ (u"ࠩࠪ劖"),False)
	menuItemsLIST[:] = l11ll1l11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1111l1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1111l1_l1_)
	return
def l11ll111ll1l_l1_(l11ll111l1l1_l1_,l11lll11111l_l1_):
	l11lll11111l_l1_ = l11lll11111l_l1_.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ劗"),l11lll_l1_ (u"ࠫࠬ劘")).replace(l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ劙"),l11lll_l1_ (u"࠭ࠧ劚"))
	l11ll1l11l1l_l1_ = l11lll11111l_l1_
	if l11lll_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ力") in l11lll11111l_l1_:
		l11ll1l11l1l_l1_ = l11lll11111l_l1_.split(l11lll_l1_ (u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ劜"))[0]
		type = l11lll_l1_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ劝")
	elif l11lll_l1_ (u"࡚ࠪࡔࡊࠧ办") in l11ll111l1l1_l1_: type = l11lll_l1_ (u"ࠫ࠱࡜ࡉࡅࡇࡒࡗ࠿ࠦࠧ功")
	elif l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ加") in l11ll111l1l1_l1_: type = l11lll_l1_ (u"࠭ࠬࡍࡋ࡙ࡉ࠿ࠦࠧ务")
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ劢"),l11lll_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ劣")+type+l11ll1l11l1l_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿อไใี่ࡡࠬ劤"),l11ll111l1l1_l1_,168,l11lll_l1_ (u"ࠪࠫ劥"),l11lll_l1_ (u"ࠫࠬ劦"),l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ劧")+l11lll11111l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭动"),l11lll_l1_ (u"ࠧฦ฻สำฮࠦวๅู็ฬࠥอไฺึ๋หห๐ࠠๆ่๊ࠣๆูࠠศๆๅื๊࠭助"),l11ll111l1l1_l1_,168,l11lll_l1_ (u"ࠨࠩ努"),l11lll_l1_ (u"ࠩࠪ劫"),l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ劬")+l11lll11111l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ劭"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ劮"),l11lll_l1_ (u"࠭ࠧ劯"),9999)
	import M3U
	for l11ll1l1llll_l1_ in range(1,FOLDERS_COUNT+1):
		if l11lll_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ劰") in l11lll11111l_l1_: M3U.GROUPS(str(l11ll1l1llll_l1_),l11ll111l1l1_l1_,l11lll11111l_l1_,l11lll_l1_ (u"ࠨࠩ励"),False)
		else: M3U.ITEMS(str(l11ll1l1llll_l1_),l11ll111l1l1_l1_,l11lll11111l_l1_,l11lll_l1_ (u"ࠩࠪ劲"),False)
	menuItemsLIST[:] = l11ll1l11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11lll1111l1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11lll1111l1_l1_)
	return
def l11ll1l11lll_l1_(menuItemsLIST):
	l11ll11lllll_l1_ = []
	for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in menuItemsLIST:
		if l11lll_l1_ (u"ูࠪๆำษࠨ劳") in name or l11lll_l1_ (u"ฺࠫ็อ่ࠩ労") in name or l11lll_l1_ (u"ࠬࡶࡡࡨࡧࠪ劵") in name.lower(): continue
		l11ll11lllll_l1_.append([type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_])
	return l11ll11lllll_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᨄ")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡉࡍࡄࡡࠪᨅ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๋่ࠬใ฻๊ࠣฯ็ไ๋ๅึࠫᨆ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l1111l_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l1llllll_l1_(url)
	elif mode==494: results = l1l11l_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᨇ"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨᨈ"),l11lll_l1_ (u"ࠨࠩᨉ"),l11lll_l1_ (u"ࠩࠪᨊ"),l11lll_l1_ (u"ࠪࠫᨋ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᨌ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᨍ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"࠭࠯ࠨᨎ"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᨏ"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᨐ"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᨑ"),l1ll1l1_l1_,499,l11lll_l1_ (u"ࠪࠫᨒ"),l11lll_l1_ (u"ࠫࠬᨓ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᨔ"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨕ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᨖ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧᨗ"),l1ll1l1_l1_,491,l11lll_l1_ (u"ᨘࠩࠪ"),l11lll_l1_ (u"ࠪࠫᨙ"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᨚ"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨛ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᨜"),l11lll_l1_ (u"ࠧࠨ᨝"),9999)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠢࡄ࡮ࡦࡾࡩࡧࡻࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ᨞"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡧ࡫࡯ࡸࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᨟"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡱ࡯ࡨ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ᨠ")+link+l11lll_l1_ (u"ࠫ࠳ࡶࡨࡱࠩᨡ")
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᨢ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᨣ")+l111ll_l1_+title,link,491)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨤ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᨥ"),l11lll_l1_ (u"ࠩࠪᨦ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨧ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᨨ")+l111ll_l1_+l11lll_l1_ (u"ࠬษแๅษ่ࠫᨩ"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สๅ้อๅ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡨ࡬ࡰࡲ࡫࠯ࡧࡱࡵࡩ࡮࡭࡮࠮ࡪࡧ࠱ฬ็ไศ็࠰หั์ศ๊࠯࠵ࠫᨪ"),494,l11lll_l1_ (u"ࠧࠨᨫ"),l11lll_l1_ (u"ࠨࠩᨬ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨭ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨮ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᨯ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯ࠭ᨰ"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱่ืู้ไศฬ࠲ุ้๊ำๅษอ࠱ฬาๆษ๋ࠪᨱ"),494,l11lll_l1_ (u"ࠧࠨᨲ"),l11lll_l1_ (u"ࠨࠩᨳ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨴ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨵ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᨶ"),l11lll_l1_ (u"ࠬ࠭ᨷ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᨸ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᨹ"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠨ࠱ࠪᨺ"): continue
		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᨻ") not in link: link = l1ll1l1_l1_+link
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨼ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᨽ")+l111ll_l1_+title,link,491)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᨾ"),l11lll_l1_ (u"࠭ࠧᨿ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᩀ"),url,l11lll_l1_ (u"ࠨࠩᩁ"),l11lll_l1_ (u"ࠩࠪᩂ"),l11lll_l1_ (u"ࠪࠫᩃ"),l11lll_l1_ (u"ࠫࠬᩄ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᩅ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᩆ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᩇ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩈ"),l111ll_l1_+title,link,491)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠩࠪᩉ")):
	items = []
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧᩊ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᩋ"),url,l11lll_l1_ (u"ࠬ࠭ᩌ"),l11lll_l1_ (u"࠭ࠧᩍ"),l11lll_l1_ (u"ࠧࠨᩎ"),l11lll_l1_ (u"ࠨࠩᩏ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᩐ"))
	html = response.content
	block = l11lll_l1_ (u"ࠪࠫᩑ")
	if l11lll_l1_ (u"ࠫ࠳ࡶࡨࡱࠩᩒ") in url: block = html
	elif l11lll_l1_ (u"ࠬࡅࡳ࠾ࠩᩓ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࠧࡳࡡ࡯࡫ࡩࡩࡸࡺࠢࠨᩔ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᩕ"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࠢ࡮ࡣࡱ࡭࡫࡫ࡳࡵࠤࠪᩖ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
	if not block: return
	#if not items: items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࡞࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࠧࡨ࡯ࡹࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᩗ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪᩘ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩᩙ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫᩚ"),l11lll_l1_ (u"࠭ร฻่ํอࠬᩛ"),l11lll_l1_ (u"ࠧไๆํฬࠬᩜ"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧᩝ"),l11lll_l1_ (u"๊ࠩำฬ็ࠧᩞ"),l11lll_l1_ (u"้ࠪออัศหࠪ᩟"),l11lll_l1_ (u"ࠫ฾ืึࠨ᩠"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬᩡ"),l11lll_l1_ (u"࠭วๅส๋้ࠬᩢ"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧᩣ")]
	for link,l1llll_l1_,title in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩᩤ"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᩥ"),title,re.DOTALL)
		if not l1lll11_l1_ or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᩦ"),l111ll_l1_+title,link,492,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠫา๊โสࠩᩧ") in title:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᩨ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩩ"),l111ll_l1_+title,link,493,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᩪ"),l111ll_l1_+title,link,493,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᩫ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᩬ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠪห้฻แฮหࠣࠫᩭ"),l11lll_l1_ (u"ࠫࠬᩮ"))
			if title!=l11lll_l1_ (u"ࠬ࠭ᩯ"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩰ"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭ᩱ")+title,link,491)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᩲ"),url,l11lll_l1_ (u"ࠩࠪᩳ"),l11lll_l1_ (u"ࠪࠫᩴ"),l11lll_l1_ (u"ࠫࠬ᩵"),l11lll_l1_ (u"ࠬ࠭᩶"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ᩷"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡄࡸࡸࡹࡵ࡮ࡴࡄࡤࡶࡈࡵࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᩸"),html,re.DOTALL)
	if l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᩹"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ᩺"),l11lll_l1_ (u"ࠪࠫ᩻"),l11lll_l1_ (u"ࠫࠬ᩼"),l11lll_l1_ (u"ࠬ࠭᩽"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ᩾"))
		html = response.content
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᩿"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ᪀"))
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ᪁"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭᪂"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭᪃") not in url:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᪄"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪅"),l111ll_l1_+title,link,493,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࡜࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡦࡴࡾࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᪆"),block,re.DOTALL)
		if items:
			for link,l1llll_l1_,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ᪇"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᪈"),l111ll_l1_+title,link,492,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᪉"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᪊"),block,re.DOTALL)
			for link,title in items:
				title = unescapeHTML(title)
				title = title.replace(l11lll_l1_ (u"ࠬอไึใะอࠥ࠭᪋"),l11lll_l1_ (u"࠭ࠧ᪌"))
				if title!=l11lll_l1_ (u"ࠧࠨ᪍"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪎"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ᪏")+title,link,491)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ᪐"))+l11lll_l1_ (u"ࠫ࠴ࡅࡶࡪࡧࡺࡁ࠶࠭᪑")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᪒"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᪓"),l11lll_l1_ (u"ࠧࠨ᪔"),l11lll_l1_ (u"ࠨࠩ᪕"),l11lll_l1_ (u"ࠩࠪ᪖"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ᪗"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ᪘"))
	l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡡࡵࡣ࠽ࠤࠬࡷ࠽ࠩ࠰࠭ࡃ࠮ࠬࠢ᪙"),html,re.DOTALL)
	#if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ᪚"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᪛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ᪜"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ᪝"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡱ࡯ࡨ࠴ࡹࡥࡳࡸࡨࡶࡸ࠵ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂࡵࡂ࠭᪞")+l1ll1llll1_l1_+l11lll_l1_ (u"ࠫࠫ࡯࠽ࠨ᪟")+l1lll111l1_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᪠")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ᪡")
			l1111_l1_.append(link)
	# l1l11llll_l1_ l11ll1l1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡓࡦࡴࡹࡩࡷࠨ࠮ࠫࡁࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᪢"),html,re.DOTALL)
	if link:
		title = l11lll_l1_ (u"ࠨ็ไฺ้࠭᪣")
		link = link[0]+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࡢࡣࠬ᪤")+title
		l1111_l1_.append(link)
	# download links
	#l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ᪥"))+l11lll_l1_ (u"ࠫ࠴ࡅࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠳ࠪ᪦")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᪧ"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᪨"),l11lll_l1_ (u"ࠧࠨ᪩"),l11lll_l1_ (u"ࠨࠩ᪪"),l11lll_l1_ (u"ࠩࠪ᪫"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ᪬"))
	#html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ᪭"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᪮"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ᪯"))
			if l11lll_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ᪰") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠨࡡࡢาฬ฻ࠧ᪱")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠩࠪ᪲")
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᪳")+title+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ᪴")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิส᪵ࠪ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ᪶ࠬ"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠧࠨ᪷")):
	if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨ᪸ࠢࠪ"),l11lll_l1_ (u"ࠩ࠮᪹ࠫ"))
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶ࠿ࡴ࠿᪺ࠪ")+search
	l1111l_l1_(url)
	return
#   search is l11lll11l_l1_ l1l111l11_l1_ in l1111l_l1_()
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/?s=the+l1ll1lll11_l1_
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/search/the+l1ll1lll11_l1_/
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
#	https://l1lll11111_l1_-l1lll1111l_l1_.io/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
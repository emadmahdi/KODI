# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ䯸")
headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䯹") : l11lll_l1_ (u"ࠫࠬ䯺") }
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫ䯻")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l1111l_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1llllll_l1_(url)
	elif mode==188: results = l11llll1111l_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11llll1111l_l1_():
	message = l11lll_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ䯼")
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䯽"),l11lll_l1_ (u"ࠨࠩ䯾"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䯿"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䰀"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䰁"),l11lll_l1_ (u"ࠬ࠭䰂"),189,l11lll_l1_ (u"࠭ࠧ䰃"),l11lll_l1_ (u"ࠧࠨ䰄"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䰅"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䰆"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䰇")+l111ll_l1_+l11lll_l1_ (u"ࠫอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࠬ䰈"),l11ll1_l1_,181,l11lll_l1_ (u"ࠬ࠭䰉"),l11lll_l1_ (u"࠭ࠧ䰊"),l11lll_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ䰋"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䰌"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䰍")+l111ll_l1_+l11lll_l1_ (u"ࠪวาีหࠡษ็หๆ๊วๆࠩ䰎"),l11ll1_l1_,181,l11lll_l1_ (u"ࠫࠬ䰏"),l11lll_l1_ (u"ࠬ࠭䰐"),l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䰑"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䰒"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䰓")+l111ll_l1_+l11lll_l1_ (u"ࠩอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ䰔"),l11ll1_l1_,181,l11lll_l1_ (u"ࠪࠫ䰕"),l11lll_l1_ (u"ࠫࠬ䰖"),l11lll_l1_ (u"ࠬࡺࡶࠨ䰗"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䰘"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䰙")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨ䰚"),l11ll1_l1_,181,l11lll_l1_ (u"ࠩࠪ䰛"),l11lll_l1_ (u"ࠪࠫ䰜"),l11lll_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ䰝"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䰞"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䰟")+l111ll_l1_+l11lll_l1_ (u"ࠧฤไ๋ํࠥอไศใ็ห๊ࠦวๅฯส่๏ฯࠧ䰠"),l11ll1_l1_,181,l11lll_l1_ (u"ࠨࠩ䰡"),l11lll_l1_ (u"ࠩࠪ䰢"),l11lll_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䰣"))
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ䰤"),headers,l11lll_l1_ (u"ࠬ࠭䰥"),l11lll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䰦"))
	items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䰧"),html,re.DOTALL)
	for link,title in items:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䰨"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䰩")+l111ll_l1_+title,link,181)
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠪࠫ䰪")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠫࠬ䰫"),headers,l11lll_l1_ (u"ࠬ࠭䰬"),l11lll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䰭"))
	if type==l11lll_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䰮"): block = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ละำะࠦวๅลไ่ฬ๋࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭䰯"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭䰰"): block = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ䰱"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䰲"): block = re.findall(l11lll_l1_ (u"ࠬࡨࡴ࡯࠯࠵࠱ࡴࡼࡥࡳ࡮ࡤࡽ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ䰳"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䰴"): block = re.findall(l11lll_l1_ (u"ࠧࡣࡶࡱ࠱࠶ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠫ࠲࠯ࡅࠩࡣࡶࡱ࠱࠷ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠪ䰵"),html,re.DOTALL)[0]
	elif type==l11lll_l1_ (u"ࠨࡶࡹࠫ䰶"): block = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡩࠥࠫ䰷"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11lll_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䰸"),l11lll_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䰹")]:
		items = re.findall(l11lll_l1_ (u"ࠬࡹࡴࡺ࡮ࡨࡁࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䰺"),block,re.DOTALL)
	else: items = re.findall(l11lll_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠴࡝࠳࠱࠾ࡣࠫࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䰻"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l11ll1_l1_ = [l11lll_l1_ (u"ࠧโ์็้ࠬ䰼"),l11lll_l1_ (u"ࠨษ็ั้่ษࠨ䰽"),l11lll_l1_ (u"ࠩส่า๊โ่ࠩ䰾"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ䰿"),l11lll_l1_ (u"ࠫࡗࡧࡷࠨ䱀"),l11lll_l1_ (u"࡙ࠬ࡭ࡢࡥ࡮ࡈࡴࡽ࡮ࠨ䱁"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ䱂"),l11lll_l1_ (u"ࠧศฮีหฦ࠭䱃")]
	for l1llll_l1_,l11lll1l1ll1_l1_,l11llll111l1_l1_,l11llll111ll_l1_ in items:
		if type in [l11lll_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䱄"),l11lll_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭䱅")]:
			l1llll_l1_,link,l1lllllll1_l1_,title = l1llll_l1_,l11lll1l1ll1_l1_,l11llll111l1_l1_,l11llll111ll_l1_
		else: l1llll_l1_,title,link,l1lllllll1_l1_ = l1llll_l1_,l11lll1l1ll1_l1_,l11llll111l1_l1_,l11llll111ll_l1_
		link = l111l_l1_(link)
		link = link.replace(l11lll_l1_ (u"ࠪࡃࡻ࡯ࡥࡸ࠿ࡷࡶࡺ࡫ࠧ䱆"),l11lll_l1_ (u"ࠫࠬ䱇"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䱈"),l11lll_l1_ (u"࠭ࠧ䱉"),link,l1lllllll1_l1_)
		title = unescapeHTML(title)
		#l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠮ศอ๊าอࢁฮฬ้ั๊࠭ࠬ䱊"),title,re.DOTALL)
		#if l1lll1lll_l1_: title = l1lll1lll_l1_[0][0]
		if l11lll_l1_ (u"ࠨสฯ์ิฯࠠࠨ䱋") in title or l11lll_l1_ (u"ࠩหะํี็ࠡࠩ䱌") in title:
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䱍") + title.replace(l11lll_l1_ (u"ࠫอา่ะหࠣࠫ䱎"),l11lll_l1_ (u"ࠬ࠭䱏")).replace(l11lll_l1_ (u"࠭ศอ๊า๋ࠥ࠭䱐"),l11lll_l1_ (u"ࠧࠨ䱑"))
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ䱒"))
		if l11lll_l1_ (u"ࠩส่า๊โสࠩ䱓") in title or l11lll_l1_ (u"ࠪห้ำไใ้ࠪ䱔") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ䱕"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䱖") + l1lll11_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䱗"),l111ll_l1_+title,link,183,l1llll_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l11l11ll1_l1_):
			link = link + l11lll_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ䱘") + l1lllllll1_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䱙"),l111ll_l1_+title,link,182,l1llll_l1_)
		else:
			link = link + l11lll_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ䱚") + l1lllllll1_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䱛"),l111ll_l1_+title,link,183,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠫࠬ䱜"):
		items = re.findall(l11lll_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䱝"),html,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"࠭วๅืไัฮࠦࠧ䱞"),l11lll_l1_ (u"ࠧࠨ䱟"))
			if title!=l11lll_l1_ (u"ࠨࠩ䱠"):
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䱡"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ䱢")+title,link,181)
	return
def l1llllll_l1_(url):
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䱣"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭䱤"),headers,l11lll_l1_ (u"࠭ࠧ䱥"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䱦"))
	block = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䱧"),html,re.DOTALL)
	title,dummy,l1llll_l1_ = block[0]
	name = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ䱨"),title,re.DOTALL)
	if name: name = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䱩") + name[0][0]
	else: name = title
	items = []
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ䱪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䱫"),l11lll_l1_ (u"࠭ࠧ䱬"),l11l11l_l1_,str(l1l1ll1_l1_))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䱭"),block,re.DOTALL)
		for link in items:
			link = l111l_l1_(link)
			title = re.findall(l11lll_l1_ (u"ࠨࠪส่า๊โสࡾส่า๊โ่ࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ䱮"),link.split(l11lll_l1_ (u"ࠩ࠲ࠫ䱯"))[-2],re.DOTALL)
			if not title: title = re.findall(l11lll_l1_ (u"ࠪࠬ࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ䱰"),link.split(l11lll_l1_ (u"ࠫ࠴࠭䱱"))[-2],re.DOTALL)
			if title: title = l11lll_l1_ (u"ࠬࠦࠧ䱲") + title[0][1]
			else: title = l11lll_l1_ (u"࠭ࠧ䱳")
			title = name + l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ䱴") + l11lll_l1_ (u"ࠨษ็ั้่ษࠨ䱵") + title
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䱶"),l111ll_l1_+title,link,182,l1llll_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠪฬั๎ฯสࠢࠪ䱷") in title or l11lll_l1_ (u"ࠫอา่ะ้ࠣࠫ䱸") in title:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ䱹") + title.replace(l11lll_l1_ (u"࠭ศอ๊าอࠥ࠭䱺"),l11lll_l1_ (u"ࠧࠨ䱻")).replace(l11lll_l1_ (u"ࠨสฯ์ิํࠠࠨ䱼"),l11lll_l1_ (u"ࠩࠪ䱽"))
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䱾"),l111ll_l1_+title,url,182,l1llll_l1_)
	return
def PLAY(url):
	l11llll11l11_l1_ = url.split(l11lll_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ䱿"))
	l11l11l_l1_ = l11llll11l11_l1_[0]
	del l11llll11l11_l1_[0]
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭䲀"),headers,l11lll_l1_ (u"࠭ࠧ䲁"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䲂"))
	link = re.findall(l11lll_l1_ (u"ࠨࡨࡲࡲࡹ࠳ࡳࡪࡼࡨ࠾ࠥ࠸࠵ࡱࡺ࠾ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䲃"),html,re.DOTALL)[0]
	if link not in l11llll11l11_l1_: l11llll11l11_l1_.append(link)
	l1111_l1_ = []
	# l11lll1llll1_l1_
	for link in l11llll11l11_l1_:
		if l11lll_l1_ (u"ࠩ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䲄") in link:
			l11lll1llll1_l1_ = link
			l1111_l1_.append(l11lll1llll1_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡦ࡯࡮ࠨ䲅"))
	# l11lll1lll1l_l1_
	for link in l11llll11l11_l1_:
		if l11lll_l1_ (u"ࠫ࠿࠵࠯ࡷࡤ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠧ䲆") in link:
			html = OPENURL_CACHED(l11111l_l1_,link,l11lll_l1_ (u"ࠬ࠭䲇"),headers,l11lll_l1_ (u"࠭ࠧ䲈"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䲉"))
			html = html.decode(l11lll_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴ࠯࠴࠶࠺࠼ࠧ䲊")).encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䲋"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l11lll1l1l1l_l1_><l11lll1ll11l_l1_ /><l11lll1l1l1l_l1_ l11llll11111_l1_=l11lll_l1_ (u"ࠥࡧࡪࡴࡴࡦࡴࠥ䲌")>(\*\*\*\*\*\*\*\*|13721411411.l11lll1l11ll_l1_|)
			html = html.replace(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䲍"),l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䲎"))
			html = html.replace(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䲏"),l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䲐"))
			html = html.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࡁࡨࡲࠡ࠱ࡁࡀࡩ࡯ࡶࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࡀࠪ䲑"),l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䲒"))
			html = html.replace(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡧࡵࡲࡥࡧࡵࠦࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧ࠭䲓"),l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䲔"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䲕"),html,re.DOTALL)
			if l1l1ll1_l1_:
				#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䲖"),l11lll_l1_ (u"ࠧࠨ䲗"),url,str(len(l1l1ll1_l1_)))
				l11lll1l1l11_l1_,l11lll1lll11_l1_ = [],[]
				if len(l1l1ll1_l1_)==1:
					title = l11lll_l1_ (u"ࠨࠩ䲘")
					block = html
				else:
					for block in l1l1ll1_l1_:
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠮ࠫࡁ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࠮ࠬ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ䲙"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ䲚") + l11l1_l1_[0][1]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䲛"),block,re.DOTALL)
						if l11l1_l1_: block = l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ䲜") + l11l1_l1_[0]
						l11l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࠬࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䲝"),block,re.DOTALL)
						if l11l1_l1_: block = l11l1_l1_[0] + l11lll_l1_ (u"ࠧࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ䲞")
						l11lll1lllll_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࠫ࠲࠯ࡅࠩࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵ࠧ䲟"),block,re.DOTALL)
						title = re.findall(l11lll_l1_ (u"ࠩࡁࠤ࠯࠮࡛࡟࠾ࡁࡡ࠰࠯ࠠࠫ࠾ࠪ䲠"),l11lll1lllll_l1_[0][0],re.DOTALL)
						title = l11lll_l1_ (u"ࠪࠤࠬ䲡").join(title)
						title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭䲢"))
						title = title.replace(l11lll_l1_ (u"ࠬࠦࠠࠨ䲣"),l11lll_l1_ (u"࠭ࠠࠨ䲤")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ䲥"),l11lll_l1_ (u"ࠨࠢࠪ䲦")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ䲧"),l11lll_l1_ (u"ࠪࠤࠬ䲨")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ䲩"),l11lll_l1_ (u"ࠬࠦࠧ䲪")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ䲫"),l11lll_l1_ (u"ࠧࠡࠩ䲬"))
						l11lll1l1l11_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศ࠻ࠩ䲭"), l11lll1l1l11_l1_)
					if l1l_l1_ == -1 : return
					title = l11lll1l1l11_l1_[l1l_l1_]
					block = l1l1ll1_l1_[l1l_l1_]
				link = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯࠭ࠧ࠭䲮"),block,re.DOTALL)
				l11lll1ll1l1_l1_ = link[0]
				l1111_l1_.append(l11lll1ll1l1_l1_+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡊࡴࡸࡵ࡮ࠩ䲯"))
				block = block.replace(l11lll_l1_ (u"ࠫๅ࠭䲰"),l11lll_l1_ (u"ࠬ࠭䲱"))
				block = block.replace(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ䲲"),l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ䲳"))
				block = block.replace(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ䲴"),l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䲵"))
				block = block.replace(l11lll_l1_ (u"ࠪื๏ืแาษอࠤฬ๊สฮ็ํ่ࠬ䲶"),l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ䲷"))
				block = block.replace(l11lll_l1_ (u"ࠬื่ศสฺࠤฬ๊สฮ็ํ่ࠬ䲸"),l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭䲹"))
				block = block.replace(l11lll_l1_ (u"ࠧิ์ิๅึอสࠡษ็ู้อ็ะࠩ䲺"),l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䲻"))
				block = block.replace(l11lll_l1_ (u"ࠩิ์ฬฮืࠡษ็ู้อ็ะࠩ䲼"),l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䲽"))
				l11lll1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࡜ࡥ࠭ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ䲾"),block,re.DOTALL)
				for l11lll1ll1ll_l1_ in l11lll1l1lll_l1_:
					#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䲿"),l11lll_l1_ (u"࠭ࠧ䳀"),l11lll_l1_ (u"ࠧࠨ䳁"),str(l11lll1ll1ll_l1_))
					type = re.findall(l11lll_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭䳂"),l11lll1ll1ll_l1_)
					if type:
						if type[0]!=l11lll_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䳃"): type = l11lll_l1_ (u"ࠪࡣࡤ࠭䳄")+type[0]
						else: type = l11lll_l1_ (u"ࠫࠬ䳅")
					items = re.findall(l11lll_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ䳆"),l11lll1ll1ll_l1_,re.DOTALL)
					for l11lll1ll111_l1_,link in items:
						title = re.findall(l11lll_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ䳇"),l11lll1ll111_l1_)
						title = title[-1]
						link = link + l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䳈") + title + type
						l1111_l1_.append(link)
	# l11llll11l1l_l1_
	l11l1l1_l1_ = l11l11l_l1_.replace(l11ll1_l1_,l11lllll11_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠨࠩ䳉"),headers,l11lll_l1_ (u"ࠩࠪ䳊"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ䳋"))
	items = re.findall(l11lll_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䳌"),html,re.DOTALL)
	#l11lll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯ࡦ࡯ࡥࡩࡩࡓ࠭ࠩ࡞ࡺ࠯࠮࠳࠮ࠫࡁ࠱࡬ࡹࡳ࡬ࠪࠩ䳍"),html,re.DOTALL)
	#if l11lll11ll_l1_:
	if items:
		#l11llll11l1l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࠩ䳎") + l11lll11ll_l1_[-1] + l11lll_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭䳏")
		l11llll11l1l_l1_ = items[-1]
		l1111_l1_.append(l11llll11l1l_l1_+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡲࡦ࡮ࡲࡥࠨ䳐"))
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䳑"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ䳒"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ䳓"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ䳔"),l11lll_l1_ (u"࠭ࠫࠨ䳕"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䳖"),headers,l11lll_l1_ (u"ࠨࠩ䳗"),l11lll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䳘"))
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࡂࠬ䳙"),html,re.DOTALL)
	l11l11l11_l1_ = [ l11lll_l1_ (u"ࠫࠬ䳚") ]
	l111lll11_l1_ = [ l11lll_l1_ (u"ࠬอไไๆࠣ์อี่็ࠢไ่ฯืࠧ䳛") ]
	for category,title in items:
		l11l11l11_l1_.append(category)
		l111lll11_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭䳜"), l111lll11_l1_)
		if l1l_l1_ == -1 : return
		category = l11l11l11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"ࠧࠨ䳝")
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭䳞")+search+l11lll_l1_ (u"ࠩࠩࡱࡨࡧࡴ࠾ࠩ䳟")+category
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䳠"),l11lll_l1_ (u"ࠫࠬ䳡"),url,url)
	l1111l_l1_(url)
	return
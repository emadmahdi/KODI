# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ䵷")
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䵸"):l11lll_l1_ (u"ࠩࠪ䵹")}
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩ䵺")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ䵻"),l11lll_l1_ (u"ࠬࡽࡷࡦࠩ䵼")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1111l_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1llllll_l1_(url,text)
	elif mode==364: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭䵽")+text)
	elif mode==365: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ䵾")+text)
	elif mode==366: results = l1l11l_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䵿"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ䶀"),l11lll_l1_ (u"ࠪࠫ䶁"),False,l11lll_l1_ (u"ࠫࠬ䶂"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䶃"))
	#hostname = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䶄")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠧ࠰ࠩ䶅"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䶆")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䶇"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ䶈"),l11lll_l1_ (u"ࠫࠬ䶉"),l11lll_l1_ (u"ࠬ࠭䶊"),l11lll_l1_ (u"࠭ࠧ䶋"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䶌"))
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䶍"),l111ll_l1_+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䶎"),l11lll_l1_ (u"ࠪࠫ䶏"),8)
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䶐"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䶑"),l11lll_l1_ (u"࠭ࠧ䶒"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䶓"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䶔"),l11ll1_l1_,369,l11lll_l1_ (u"ࠩࠪ䶕"),l11lll_l1_ (u"ࠪࠫ䶖"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䶗"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䶘"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䶙"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ䶚"),364)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶛"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ䶜"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䶝"),365)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䶞"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䶟"),l11lll_l1_ (u"࠭ࠧ䶠"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䶡"):hostname,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䶢"):l11lll_l1_ (u"ࠩࠪ䶣")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"ࠪࡠ࠴࠭䶤"),l11lll_l1_ (u"ࠫ࠴࠭䶥"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ䶦"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ䶧"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ䶨") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䶩"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䶪")+l111ll_l1_+title,link,366)
	#	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䶫"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䶬"),l11lll_l1_ (u"ࠬ࠭䶭"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䶮"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ䶯"),l11lll_l1_ (u"ࠨࠩ䶰"),l11lll_l1_ (u"ࠩࠪ䶱"),l11lll_l1_ (u"ࠪࠫ䶲"),l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䶳"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䶴"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶵"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ䶶") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ䶷"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠩࠪ䶸"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶹"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䶺")+l111ll_l1_+title,link,366)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䶻"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䶼"),l11lll_l1_ (u"ࠧࠨ䶽"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ䶾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䶿"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷀"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䷁")+l111ll_l1_+title,link,366,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䷂"),l11lll_l1_ (u"࠭ࠧ䷃"),url,l11lll_l1_ (u"ࠧࠨ䷄"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䷅"):url,l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䷆"):l11lll_l1_ (u"ࠪࠫ䷇")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䷈"),url,l11lll_l1_ (u"ࠬ࠭䷉"),l11lll_l1_ (u"࠭ࠧ䷊"),l11lll_l1_ (u"ࠧࠨ䷋"),l11lll_l1_ (u"ࠨࠩ䷌"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䷍"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷎"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䷏"),url,364)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷐"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䷑"),url,365)
	if l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ䷒") in html:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷓"),l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ䷔"),url,361,l11lll_l1_ (u"ࠪࠫ䷕"),l11lll_l1_ (u"ࠫࠬ䷖"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䷗"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䷘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䷙"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷚"),l111ll_l1_+title,link,361)
	return
def l1111l_l1_(l1ll111ll111_l1_,type=l11lll_l1_ (u"ࠩࠪ䷛")):
	if l11lll_l1_ (u"ࠪ࠾࠿࠭䷜") in l1ll111ll111_l1_:
		l11l1l1_l1_,url = l1ll111ll111_l1_.split(l11lll_l1_ (u"ࠫ࠿ࡀࠧ䷝"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䷞"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll111ll111_l1_,l1ll111ll111_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䷟"):l11l1l1_l1_,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䷠"):l11lll_l1_ (u"ࠨࠩ䷡")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䷢"),url,l11lll_l1_ (u"ࠪࠫ䷣"),l11lll_l1_ (u"ࠫࠬ䷤"),l11lll_l1_ (u"ࠬ࠭䷥"),l11lll_l1_ (u"࠭ࠧ䷦"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䷧"))
	html = response.content
	if type==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䷨"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭䷩"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䷪"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠫࡡࡢ࠯ࠨ䷫"),l11lll_l1_ (u"ࠬ࠵ࠧ䷬")).replace(l11lll_l1_ (u"࠭࡜࡝ࠤࠪ䷭"),l11lll_l1_ (u"ࠧࠣࠩ䷮"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡎࡻࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䷯"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ䷰"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫ䷱"),l11lll_l1_ (u"ࠫࠬ䷲"))
			if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䷳") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷴"),l111ll_l1_+title,link,363,l1llll_l1_)
			elif l11lll_l1_ (u"ࠧฮๆๅอࠬ䷵") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ䷶"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䷷") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䷸"),l111ll_l1_+title,link,363,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䷹"),l111ll_l1_+title,link,362,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䷺"):
			l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ䷻"),block,re.DOTALL)
			if l1lll11ll1l_l1_:
				count = l1lll11ll1l_l1_[0]
				link = url+l11lll_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ䷼")+count
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䷽"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ䷾"),link,361,l11lll_l1_ (u"ࠪࠫ䷿"),l11lll_l1_ (u"ࠫࠬ一"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭丁"))
		elif type==l11lll_l1_ (u"࠭ࠧ丂"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ七"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ丄"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ุࠩๅาฯࠠࠨ丅")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丆"),l111ll_l1_+title,link,361)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠫࠬ万")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ丈"),url,l11lll_l1_ (u"࠭ࠧ三"),l11lll_l1_ (u"ࠧࠨ上"),l11lll_l1_ (u"ࠨࠩ下"),l11lll_l1_ (u"ࠩࠪ丌"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ不"))
	html = response.content
	html = l111l_l1_(html)
	name = re.findall(l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ与"),html,re.DOTALL)
	if name: name = name[-1].replace(l11lll_l1_ (u"ࠬ࠳ࠧ丏"),l11lll_l1_ (u"࠭ࠠࠨ丐")).strip(l11lll_l1_ (u"ࠧ࠰ࠩ丑"))
	if l11lll_l1_ (u"ࠨ็๋ื๊࠭丒") in name and type==l11lll_l1_ (u"ࠩࠪ专"):
		name = name.split(l11lll_l1_ (u"้ࠪํูๅࠨ且"))[0]
		name = name.replace(l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫ丕"),l11lll_l1_ (u"ࠬ࠭世")).strip(l11lll_l1_ (u"࠭ࠠࠨ丗"))
	elif l11lll_l1_ (u"ࠧฮๆๅอࠬ丘") in name:
		name = name.split(l11lll_l1_ (u"ࠨฯ็ๆฮ࠭丙"))[0]
		name = name.replace(l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ业"),l11lll_l1_ (u"ࠪࠫ丛")).strip(l11lll_l1_ (u"ࠫࠥ࠭东"))
	else: name = name
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࠩ丝"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if type==l11lll_l1_ (u"࠭ࠧ丞"):
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ丟"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ丠") in title: continue
				if l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ両") in title: continue
				title = name+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ丢")+title
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ丣"),l111ll_l1_+title,link,363,l11lll_l1_ (u"ࠬ࠭两"),l11lll_l1_ (u"࠭ࠧ严"),l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ並"))
		if len(menuItemsLIST)==0:
			l11l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠦࠧࠩ丧"),block+l11lll_l1_ (u"ࠩࠩࠪࠬ丨"),re.DOTALL)
			if l11l1_l1_: block = l11l1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ丩"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭个"))
				title = name+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ丫")+title
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ丬"),l111ll_l1_+title,link,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ中"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭丮"),l11lll_l1_ (u"ࠩࠪ丯")).replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣࠫ丰"),l11lll_l1_ (u"ࠫࠬ丱"))
		else: title = l11lll_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ串")
		addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ丳"),l111ll_l1_+title,url,362)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ临"),url,l11lll_l1_ (u"ࠨࠩ丵"),l11lll_l1_ (u"ࠩࠪ丶"),l11lll_l1_ (u"ࠪࠫ丷"),l11lll_l1_ (u"ࠫࠬ丸"),l11lll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ丹"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭为"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭主"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭丼"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ丽") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"ࠪื๏ืแา่ࠢห๏ࠦำ๋็สࠫ举"): name = l11lll_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ丿")
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭乀")+name+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ乁")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ乂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭乃"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ乄") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ久"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ乆")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭乇")
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡭ࡺࡥ࡬ࡱࡦ࠭么")+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ义")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭乊"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ之"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"ࠪࠫ乌")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ乍"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭乎"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ乏"),l11lll_l1_ (u"ࠧࠬࠩ乐"))
	l1111_l1_ = [l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ乑"),l11lll_l1_ (u"ࠩ࠲ࠫ乒"),l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ乓"),l11lll_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ乔"),l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ乕")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"࠭วๅๅ็ࠫ乖"),l11lll_l1_ (u"ࠧศๆฦๅ้อๅࠨ乗"),l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ乘"),l11lll_l1_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭乙"),l11lll_l1_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ乚")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ乛"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11lll_l1_ (u"ࠬ࠭乜"):
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ九"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ乞"),l11lll_l1_ (u"ࠨࠩ也"),False,l11lll_l1_ (u"ࠩࠪ习"),l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ乡"))
		hostname = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭乢")]
		hostname = hostname.strip(l11lll_l1_ (u"ࠬ࠵ࠧ乣"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ乤")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll111ll111_l1_,filter):
	if l11lll_l1_ (u"ࠧࡀࡁࠪ乥") in l1ll111ll111_l1_: url = l1ll111ll111_l1_.split(l11lll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ书"))[0]
	else: url = l1ll111ll111_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ乧"):l1ll111ll111_l1_,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ乨"):l11lll_l1_ (u"ࠫࠬ乩")}
	filter = filter.replace(l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ乪"),l11lll_l1_ (u"࠭ࠧ乫"))
	type,filter = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ乬"),1)
	if filter==l11lll_l1_ (u"ࠨࠩ乭"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠩࠪ乮"),l11lll_l1_ (u"ࠪࠫ乯")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ买"))
	if type==l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ乱"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"࠭࠽࠾ࠩ乲") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"ࠧ࠾࠿ࠪ乳") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ乴")+category+l11lll_l1_ (u"ࠩࡀࡁ࠵࠭乵")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭乶")+category+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨ乷")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ乸"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ乹")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ乺"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ乻"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ乼")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ乽"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭乾"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠬ࠭乿"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ亀"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠧࠨ亁"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ亂")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll111ll111_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ亃"),l111ll_l1_+l11lll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭亄"),l1111111_l1_,361,l11lll_l1_ (u"ࠫࠬ亅"),l11lll_l1_ (u"ࠬ࠭了"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ亇"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ予"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ争")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ亊"),l1111111_l1_,361,l11lll_l1_ (u"ࠪࠫ事"),l11lll_l1_ (u"ࠫࠬ二"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭亍"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ于"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ亏"),l11lll_l1_ (u"ࠨࠩ亐"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭云"),url,l11lll_l1_ (u"ࠪࠫ互"),l11lll_l1_ (u"ࠫࠬ亓"),l11lll_l1_ (u"ࠬ࠭五"),l11lll_l1_ (u"࠭ࠧ井"),l11lll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ亖"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠨ࡞࡟ࠦࠬ亗"),l11lll_l1_ (u"ࠩࠥࠫ亘")).replace(l11lll_l1_ (u"ࠪࡠࡡ࠵ࠧ亙"),l11lll_l1_ (u"ࠫ࠴࠭亚"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂ࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ些"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ亜"),block+l11lll_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ亝"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ亞") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ亟"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠪࡁࡂ࠭亠") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ亡"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ亢")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll111ll111_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭亣"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ交"),l1111111_l1_,361,l11lll_l1_ (u"ࠨࠩ亥"),l11lll_l1_ (u"ࠩࠪ亦"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ产"))
				else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ亨"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠬ亩"),l11l11l_l1_,364,l11lll_l1_ (u"࠭ࠧ亪"),l11lll_l1_ (u"ࠧࠨ享"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ京"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ亭")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧ亮")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ亯")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ亰")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ亱")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ亲"),l111ll_l1_+name+l11lll_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ亳"),l11l11l_l1_,365,l11lll_l1_ (u"ࠩࠪ亴"),l11lll_l1_ (u"ࠪࠫ亵"),l1l1l11l_l1_+l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭亶"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠬࡸࠧ亷") or value==l11lll_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ亸"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ亹") in option: continue
			if l11lll_l1_ (u"ࠨษ็็้࠭人") in option: continue
			if l11lll_l1_ (u"ࠩࡱ࠱ࡦ࠭亻") in value: continue
			#if value in [l11lll_l1_ (u"ࠪࡶࠬ亼"),l11lll_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ亽"),l11lll_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ亾")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ亿"): option = value
			if option==l11lll_l1_ (u"ࠧࠨ什"): option = value
			l11ll1l11_l1_ = option
			l1l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭仁"),option,re.DOTALL)
			if l1l11ll11ll_l1_: l11ll1l11_l1_ = l1l11ll11ll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠩ࠽ࠤࠬ仂")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭仃")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂࡃࠧ仄")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ仅")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩ仆")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ仇")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ仈"):
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ仉"),l111ll_l1_+l1lll1lll_l1_,url,365,l11lll_l1_ (u"ࠪࠫ今"),l11lll_l1_ (u"ࠫࠬ介"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ仌"))
			elif type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ仍") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"ࠧ࠾࠿ࠪ从") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ仏"))
				#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ仐"),l11lll_l1_ (u"ࠪࠫ仑"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ仒")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_,l1ll111ll111_l1_)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ仓"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,361,l11lll_l1_ (u"࠭ࠧ仔"),l11lll_l1_ (u"ࠧࠨ仕"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ他"))
			else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ仗"),l111ll_l1_+l1lll1lll_l1_,url,364,l11lll_l1_ (u"ࠪࠫ付"),l11lll_l1_ (u"ࠫࠬ仙"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ仚"),l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ仛"),l11lll_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ仜")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭仝"),l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ仞"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ仟"),l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭仠"),l11lll_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭仡"),l11lll_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ仢"),l11lll_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ代"),l11lll_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ令")]
def l11llllll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ以") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ仦"),l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ仧"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ仨"),l11lll_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ仩"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠾࠿ࠪ仪"),l11lll_l1_ (u"ࠨ࠱ࠪ仫"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩࠩࠪࠬ们"),l11lll_l1_ (u"ࠪ࠳ࠬ仭"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ仮"),l11lll_l1_ (u"ࠬ࠭仯"),filters,l11lll_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭仰")+mode)
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ仱")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ仲")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭仳")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠫ࠭仴"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠫࠬ仵")
	if l11lll_l1_ (u"ࠬࡃ࠽ࠨ件") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠧࠩ价"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾࠿ࠪ仸"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪ仹")
		if l11lll_l1_ (u"ࠩࠨࠫ仺") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ任") and value!=l11lll_l1_ (u"ࠫ࠵࠭仼"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩ份")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ仾") and value!=l11lll_l1_ (u"ࠧ࠱ࠩ仿"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫ伀")+key+l11lll_l1_ (u"ࠩࡀࡁࠬ企")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧ伂"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ伃")+key+l11lll_l1_ (u"ࠬࡃ࠽ࠨ伄")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪ伅"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ伆"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ伇"),l11lll_l1_ (u"ࠩࠪ伈"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠪࡓ࡚࡚ࠧ伉"))
	return l1ll1l1l_l1_
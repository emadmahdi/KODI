# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ䕛")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡒࡄࡏࡡࠪ䕜")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ䕝"),l11lll_l1_ (u"࠭วิฬไืฬืสไ็ࠣ์ࠥอไุๆหหฯ࠭䕞")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1111l_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1llll1l11_l1_(url)
	elif mode==454: results = l1llllll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䕟"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ䕠"),l11lll_l1_ (u"ࠩࠪ䕡"),l11lll_l1_ (u"ࠪࠫ䕢"),l11lll_l1_ (u"ࠫࠬ䕣"),l11lll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䕤"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ䕥"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䕦"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ䕧"),l11lll_l1_ (u"ࠩࠪ䕨"),459,l11lll_l1_ (u"ࠪࠫ䕩"),l11lll_l1_ (u"ࠫࠬ䕪"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䕫"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䕬"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䕭")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ฮฬฯอสࠡๆ๋ำ๏ࠦๆหࠩ䕮"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠩࠪ䕯"),l11lll_l1_ (u"ࠪࠫ䕰"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䕱"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕲"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䕳")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭䕴"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠨࠩ䕵"),l11lll_l1_ (u"ࠩࠪ䕶"),l11lll_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ䕷"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕸"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䕹")+l111ll_l1_+l11lll_l1_ (u"࠭ๅๆอ็๎๋࠭䕺"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠧࠨ䕻"),l11lll_l1_ (u"ࠨࠩ䕼"),l11lll_l1_ (u"ࠩࡤࡧࡹࡵࡲࡴࠩ䕽"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䕾"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䕿")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอࠬ䖀"),l1ll1l1_l1_,451,l11lll_l1_ (u"࠭ࠧ䖁"),l11lll_l1_ (u"ࠧࠨ䖂"),l11lll_l1_ (u"ࠨ࠲ࠪ䖃"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䖄"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䖅")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥํๆะ์ฬࠤ๊ีศๅฮฬࠫ䖆"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠬ࠭䖇"),l11lll_l1_ (u"࠭ࠧ䖈"),l11lll_l1_ (u"ࠧ࠲ࠩ䖉"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䖊"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䖋")+l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆ๊๊ࠢิ๐ษࠨ䖌"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠫࠬ䖍"),l11lll_l1_ (u"ࠬ࠭䖎"),l11lll_l1_ (u"࠭࠲ࠨ䖏"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䖐"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䖑"),l11lll_l1_ (u"ࠩࠪ䖒"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠪ䖓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䖔"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠬࠩࠧ䖕"): continue
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖖"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䖗")+l111ll_l1_+title,link,451)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠨࠩ䖘")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䖙"),l11lll_l1_ (u"ࠪࠫ䖚"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䖛"),url,l11lll_l1_ (u"ࠬ࠭䖜"),l11lll_l1_ (u"࠭ࠧ䖝"),l11lll_l1_ (u"ࠧࠨ䖞"),l11lll_l1_ (u"ࠨࠩ䖟"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ䖠"))
	html = response.content
	if l1111l111_l1_==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䖡"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠫࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡹࡤࡺࡪࡹࠢࠨ䖢"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l1111l111_l1_==l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䖣"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡓࡧࡦࡩࡳࡺࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ䖤"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭䖥") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ䖦"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࠨࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䖧"),block,re.DOTALL)
	elif l1111l111_l1_ in [l11lll_l1_ (u"ࠪ࠴ࠬ䖨"),l11lll_l1_ (u"ࠫ࠶࠭䖩"),l11lll_l1_ (u"ࠬ࠸ࠧ䖪")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪ䖫"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(l1111l111_l1_)]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ䖬"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ䖭"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ䖮"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ䖯"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ䖰"),l11lll_l1_ (u"ࠬษฺ็์ฬࠫ䖱"),l11lll_l1_ (u"࠭ใๅ์หࠫ䖲"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭䖳"),l11lll_l1_ (u"ࠨ้าหๆ࠭䖴"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ䖵"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ䖶"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ䖷"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ䖸")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ䖹") in html and l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠬ䖺") in l1llll_l1_:
			l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䖻"),l1llll_l1_,re.DOTALL)
			l1llll_l1_ = l1llll_l1_[0]
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠩ࠲ࠫ䖼"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ䖽"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ䖾"),title,re.DOTALL)
		#if any(value in title for value in l1lll1_l1_):
		if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"๋ࠬำๅี็ࠫ䖿") not in title:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䗀"),l111ll_l1_+title,link,452,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧฮๆๅอࠬ䗁") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䗂") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗃"),l111ll_l1_+title,link,453,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗄"),l111ll_l1_+title,link,453,l1llll_l1_)
	if l1111l111_l1_ in [l11lll_l1_ (u"ࠫࠬ䗅"),l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ䗆")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䗇"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䗈"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠣࠤ䗉"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠩࠪ䗊"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗋"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ䗌")+title,link,451)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䗍"),url,l11lll_l1_ (u"࠭ࠧ䗎"),l11lll_l1_ (u"ࠧࠨ䗏"),l11lll_l1_ (u"ࠨࠩ䗐"),l11lll_l1_ (u"ࠩࠪ䗑"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡘࡋࡁࡔࡑࡑࡗ࠲࠷ࡳࡵࠩ䗒"))
	html = response.content
	# l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡉࡡࡵࡧࡪࡳࡷࡿࡓࡶࡤࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䗓"),html,re.DOTALL)
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫ䗔") in str(l1l1l11_l1_):
		title = re.findall(l11lll_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭࠲࠭䗕"),html,re.DOTALL)
		title = title[0].strip(l11lll_l1_ (u"ࠧࠡࠩ䗖"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗗"),l111ll_l1_+title,url,454)
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䗘"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗙"),l111ll_l1_+title,link,454)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ䗚"),url,l11lll_l1_ (u"ࠬ࠭䗛"),l11lll_l1_ (u"࠭ࠧ䗜"),l11lll_l1_ (u"ࠧࠨ䗝"),l11lll_l1_ (u"ࠨࠩ䗞"),l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䗟"))
	html = response.content
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ䗠"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭䗡"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䗢"),l111ll_l1_+title,link,452,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ䗣"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䗤"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠣࠤ䗥"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠩࠪ䗦"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗧"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ䗨")+title,link,454)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ䗩"),l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ䗪"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䗫"),l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ䗬"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䗭"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ䗮"),l11lll_l1_ (u"ࠫࠬ䗯"),l11lll_l1_ (u"ࠬ࠭䗰"),l11lll_l1_ (u"࠭ࠧ䗱"),l11lll_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䗲"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ䗳"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡖ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡵ࡬ࡨࡪࡄࠧ䗴"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ䗵"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䗶")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䗷")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡳࡦ࡮ࡤࡶࡾࠨࠧ䗸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭䗹"),block,re.DOTALL)
		for link,name in items:
			name = unescapeHTML(name)
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䗺"),name,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧ䗻")+l11l111l_l1_[0]
				name = l11lll_l1_ (u"ࠪࠫ䗼")
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠫࠬ䗽")
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䗾")+name+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䗿")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䘀"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䘁"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ䘂"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ䘃"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭䘄"),l11lll_l1_ (u"ࠬ࠱ࠧ䘅"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ䘆")+search
	l1111l_l1_(url)
	return
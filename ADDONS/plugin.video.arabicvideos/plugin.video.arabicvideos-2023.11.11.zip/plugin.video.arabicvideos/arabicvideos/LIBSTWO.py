# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll11l_l1_ import *
import traceback,bidi.algorithm
#import l1l1l1l111l1_l1_
script_name = l11lll_l1_ (u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ㥟")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1lll11l1111_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ㥠"))
	l1l1l11111_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ㥡"))
	l11l1111l11_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ㥢"))
	l1l1l111ll1l_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㥣"),l11lll_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㥤"),l11lll_l1_ (u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ㥥"))
	l111l11lll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㥦"),l11lll_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㥧"),l11lll_l1_ (u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ㥨"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㥩"),l11lll_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㥪"),l11lll_l1_ (u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭㥫"))
	half_triangular_colon = l11lll_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ㥬")
	from urllib.parse import quote as _1ll1l111111_l1_
	#from io import BytesIO as _1ll11111lll_l1_
else:
	l1lll11l1111_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ㥭"))
	l1l1l11111_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ㥮"))
	l11l1111l11_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ㥯"))
	l1l1l111ll1l_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㥰"),l11lll_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㥱"),l11lll_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ㥲"))
	l111l11lll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㥳"),l11lll_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㥴"),l11lll_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ㥵"))
	l1ll111lll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㥶"),l11lll_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㥷"),l11lll_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ㥸"))
	half_triangular_colon = l11lll_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ㥹").encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㥺"))
	from urllib import quote as _1ll1l111111_l1_
	#from StringIO import StringIO as _1ll11111lll_l1_
#l1lll1l1ll11_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11l1ll1ll1_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡊࡴࡲࡤࡦࡴࡓࡥࡹ࡮ࠧ㥻"))
l1ll1l1111ll_l1_ = os.path.join(l11l1111l11_l1_,l11lll_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫ㥼"))
l1ll1ll1llll_l1_ = os.path.join(l11l1111l11_l1_,l11lll_l1_ (u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩ㥽"))
iptv1_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㥾"))
iptv2_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ㥿"))
m3u_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㦀"))
#l1ll1lll11l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧࡹࡶࡵࡩࡦࡳࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ㦁"))
#l1ll1ll11lll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠨ࡮ࡤࡷࡹࡳࡥ࡯ࡷ࠱ࡨࡦࡺࠧ㦂"))
favoritesfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠩࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠴ࡤࡢࡶࠪ㦃"))
#dummyiptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪࡨࡺࡳ࡭ࡺ࡫ࡳࡸࡻ࠴ࡤࡢࡶࠪ㦄"))
fulliptvfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫ࡮ࡶࡴࡷࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㦅"))
fullm3ufile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠬࡳ࠳ࡶࡨ࡬ࡰࡪࡥ࡟ࡠ࠰ࡧࡥࡹ࠭㦆"))
l1l1111l11l1_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡦࡤࡸࠬ㦇"))
l1l111l1l1ll_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭࡟࠱࠲࠳࠴ࡤ࠴ࡰ࡯ࡩࠪ㦈"))
l11lll1ll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠨࡲࡤࡸ࡭࠭㦉"))
defaulticon = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ㦊"))
defaultthumb = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣ࠰ࡳࡲ࡬࠭㦋"))
defaultfanart = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲ࡵࡴࡧࠨ㦌"))
defaultbanner = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶ࠳ࡶ࡮ࡨࠩ㦍"))
defaultlandscape = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦ࠰ࡳࡲ࡬࠭㦎"))
defaultposter = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸ࠮ࡱࡰࡪࠫ㦏"))
defaultclearlogo = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲ࠲ࡵࡴࡧࠨ㦐"))
defaultclearart = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷ࠲ࡵࡴࡧࠨ㦑"))
l1l1ll1l11ll_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪ㦒"))
l1ll11llll_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ㦓"))
l1l1ll111ll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㦔"),l11lll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ㦕"),addon_id,l11lll_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭㦖"))
l1lll1l1111l_l1_ = os.path.join(l1lll11l1111_l1_,l11lll_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧ㦗"),l11lll_l1_ (u"ࠩࡉࡳࡳࡺࡳࠨ㦘"),l11lll_l1_ (u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭㦙"))
FOLDERS_COUNT = 5
text_numbers = [l11lll_l1_ (u"ฺࠫ็ัࠨ㦚"),l11lll_l1_ (u"ࠬษ่ๅࠩ㦛"),l11lll_l1_ (u"࠭หศ่ํࠫ㦜"),l11lll_l1_ (u"ࠧฬษ็ฯࠬ㦝"),l11lll_l1_ (u"ࠨำสฬ฾࠭㦞"),l11lll_l1_ (u"ࠩัหู๊ࠧ㦟"),l11lll_l1_ (u"ࠪืฬีำࠨ㦠"),l11lll_l1_ (u"ุࠫอศฺࠩ㦡"),l11lll_l1_ (u"ࠬัวๆ่ࠪ㦢"),l11lll_l1_ (u"࠭สศี฼ࠫ㦣"),l11lll_l1_ (u"ฺࠧษืีࠬ㦤")]
l1ll1ll1ll1l_l1_ = l11lll_l1_ (u"ࠨ⸽ࠣ⼡ࠥ⸰ࠠ⸼ࠩ㦥")
NO_CACHE = 0
l1l1lllll111_l1_ = 30*l1l1111111l_l1_
l1lll1111_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
VERYLONG_CACHE = 30*l11l1lll111_l1_
l11l1llllll_l1_ = 1*HOUR
l1ll1ll1l1l1_l1_ = [l11lll_l1_ (u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ㦦")]
l1lll111llll_l1_ = [l11lll_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ㦧"),l11lll_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㦨"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ㦩"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㦪"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ㦫"),l11lll_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ㦬"),l11lll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ㦭"),l11lll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ㦮")]
l1lll111llll_l1_ += [l11lll_l1_ (u"ࠫࡍࡋࡌࡂࡎࠪ㦯"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ㦰"),l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ㦱"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ㦲"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㦳"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ㦴"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ㦵"),l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㦶")]
l1l1111l1ll1_l1_ = [l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ㦷"),l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ㦸"),l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ㦹"),l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭㦺")]
l1l1111l1ll1_l1_ += [l11lll_l1_ (u"ࠩࡐ࠷࡚࠭㦻"),l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ㦼"),l11lll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㦽"),l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ㦾")]
l1l1111l1ll1_l1_ += [l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㦿"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭㧀"),l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ㧁")]
l1l1111l1ll1_l1_ += [l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㧂"),l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ㧃"),l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㧄"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㧅"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㧆"),l11lll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭㧇"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㧈")]
l1l1111l1ll1_l1_ += [l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㧉"),l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㧊"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭㧋"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ㧌"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ㧍"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㧎")]
#l1l1111l1ll1_l1_ += [l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㧏"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㧐"),l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩ㧑"),l11lll_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㧒")]
#l1l1111l1ll1_l1_ += [l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㧓"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࠩ㧔"),l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࠫ㧕"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࠫ㧖")]
l1l1l11l1ll_l1_ = [l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㧗"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ㧘"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ㧙"),l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ㧚")]
l1l1l11l1ll_l1_ += [l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ㧛"),l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㧜"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㧝"),l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㧞"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㧟")]
l1l1l1l1l11_l1_ = [l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㧠"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㧡"),l11lll_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ㧢"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㧣"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ㧤"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ㧥")]		# ,l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㧦")
l1l1l1l1l11_l1_ += [l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㧧"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ㧨"),l11lll_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ㧩"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ㧪"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ㧫")]
#l1l1l1l1l11_l1_ += [l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㧬"),l11lll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ㧭")]
l1l1ll1ll1l_l1_ = [l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㧮"),l11lll_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㧯"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㧰"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㧱"),l11lll_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㧲"),l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㧳"),l11lll_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㧴"),l11lll_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㧵")]
l1l1ll1ll1l_l1_ += [l11lll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㧶"),l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㧷"),l11lll_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㧸"),l11lll_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㧹"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㧺"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㧻")]
#l1l1ll1ll1l_l1_ += [l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭㧼"),l11lll_l1_ (u"ࠬࡎࡅࡍࡃࡏࠫ㧽"),l11lll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ㧾"),l11lll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ㧿"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪ㨀"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㨁"),l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㨂")]
l1l1ll1ll11l_l1_  = [l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㨃"),l11lll_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㨄"),l11lll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㨅"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㨆"),l11lll_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㨇"),l11lll_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㨈"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㨉"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㨊")]
l1l1ll1ll11l_l1_ += [l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㨋"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㨌"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㨍"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㨎"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㨏"),l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㨐"),l11lll_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㨑"),l11lll_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㨒"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㨓")]
l1l1ll1ll11l_l1_ += [l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㨔"),l11lll_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㨕"),l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㨖"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㨗"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㨘"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㨙"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㨚")]
l1l1ll1ll11l_l1_ += [l11lll_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㨛"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㨜"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㨝"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㨞"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㨟"),l11lll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㨠"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㨡")]
l1l1ll1ll11l_l1_ += [l11lll_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㨢"),l11lll_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㨣"),l11lll_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㨤"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㨥"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㨦"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㨧"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ㨨")]
l1l11ll1l111_l1_  = [l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㨩"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㨪"),l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㨫"),l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㨬")]
l1l11ll1l111_l1_ += [l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㨭"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㨮")]
l1l11ll1l111_l1_ += [l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㨯"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㨰"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㨱")]
l1l11ll1l111_l1_ += [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㨲"),l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㨳"),l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㨴")]
l1l11ll1l111_l1_ += [l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ㨵"),l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㨶"),l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㨷")]
#l1l11ll1l111_l1_ += [l11lll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㨸"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ㨹")]
#l1l11ll1l111_l1_ += [l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧ㨺"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ㨻"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࠨ㨼")]
l1l1l111l1ll_l1_ = [l11lll_l1_ (u"࠭ࡍ࠴ࡗࠪ㨽"),l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㨾"),l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭㨿"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ㩀"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㩁")]		# l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㩂"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ㩃")
l1l1l1lllll_l1_ = l1l1ll1ll11l_l1_+l1l11ll1l111_l1_
l1l1l1lll1ll_l1_ = l1l1ll1ll11l_l1_+l1l1l111l1ll_l1_
l11l1l11ll1_l1_ = l1l1ll1ll11l_l1_+l1l1l111l1ll_l1_
l1l1l1llll1_l1_ = l1l1111l1ll1_l1_+l1l1l1l1l11_l1_+l1l1ll1ll1l_l1_+l1l1l11l1ll_l1_
# l1ll1lll1111_l1_ will not show l1llll1l1l1l_l1_ errors and will not exit from the l11l11ll11l_l1_
l1llllll1ll1_l1_ = [
						l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㩄")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ㩅")
						,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ㩆")
						,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㩇")
						,l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ㩈")
						,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㩉")
						,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㩊")
						,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ㩋")
						,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㩌")
						,l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ㩍")
						,l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ㩎")
						,l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ㩏")
						]
l1111lll111_l1_ = l1llllll1ll1_l1_+[
				 l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㩐")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㩑")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㩒")
				,l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ㩓")
				,l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ㩔")
				,l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ㩕")
				,l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ㩖")
				,l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭㩗")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ㩘")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㩙")
				,l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㩚")
				,l11lll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫ㩛")
				,l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬ㩜")
				,l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ㩝")
				,l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㩞")
				,l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㩟")
				,l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㩠")
				#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㩡")
				#,l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࡠࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㩢")
				#,l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ㩣")
				#,l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㩤")
				#,l11lll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭㩥")
				#,l11lll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡈࡇࡗࡣࡑࡇࡔࡆࡕࡗࡣ࡛ࡋࡒࡔࡋࡒࡒࡤࡔࡕࡎࡄࡈࡖࡘ࠳࠱ࡴࡶࠪ㩦")
				#,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㩧")
				#,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭㩨")
				#,l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㩩")
				]
l1lll1l11111_l1_ = [l11lll_l1_ (u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ㩪"),l11lll_l1_ (u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫ㩫"),l11lll_l1_ (u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ㩬"),l11lll_l1_ (u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭㩭"),l11lll_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ㩮"),l11lll_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ㩯")]
l1ll11l_l1_ = {
			#,l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ㩰")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭㩱")]
			#,l11lll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭㩲")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡰࡰࡧࡷࡵࡪࡤࡶࡹࡼ࠮ࡪࡴࠪ㩳")]
			#,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧ㩴")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡱࡩࡹ࠭㩵")]
			#,l11lll_l1_ (u"ࠧࡆࡉ࡜࠸ࡇࡋࡓࡕࠩ㩶")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ㩷")]
			#,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠭㩸")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ㩹")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ㩺")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡩ࡬ࡿ࡮ࡰࡹ࠱ࡰ࡮ࡼࡥࠨ㩻")]
			#,l11lll_l1_ (u"࠭ࡈࡆࡎࡄࡐࠬ㩼")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࠶࡫ࡩࡱࡧ࡬࠯࡯ࡨࠫ㩽")]
			#,l11lll_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇࠫ㩾")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭㩿"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦࠩ㪀")]
			#,l11lll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㪁")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡴࡼࡳ࠵ࡷ࠱ࡻࡸ࠭㪂")]
			#,l11lll_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭㪃")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡲࠫ㪄")]
			#,l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㪅"):[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠭㪆")]
			#,l11lll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭㪇")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠯ࡥࡲࡱࠬ㪈")]
			#,l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ㪉")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࠰ࡶ࡬ࡴࡵࡦࡱࡴࡲ࠲ࡴࡴ࡬ࡪࡰࡨࠫ㪊")]    #	 https://l1l1l111111l_l1_.com
			#,l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㪋")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭ࡤ࡮ࡸࡦ࠳࡯࡯ࠨ㪌")]
			#,l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࡣࡔࡘࡇࠨ㪍"):[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡩ࠮ࡤ࡫ࡰࡥࡨࡲࡵࡣ࠰ࡺࡳࡷࡱࠧ㪎")]
			#,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ㪏")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㪐")]
			#,l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㪑")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮ࡤࡶࡴࢀࡡ࠯ࡱࡱࡩࠬ㪒")]
			 l11lll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ㪓")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡱࡩࡹ࠭㪔")]
			,l11lll_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㪕")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡫ࡻࡦࡱࡴࡷ࠰ࡱࡩࡹ࠭㪖")]
			,l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ㪗")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡭ࡺࡥࡲ࠴࡮ࡦࡶࠪ㪘")]
			,l11lll_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㪙")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪ㪚")]
			,l11lll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ㪛")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶࠨ㪜")]
			,l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭㪝")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫ࠫ㪞")]
			,l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㪟")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡸࡡࡣ࡫ࡦ࠱ࡹࡵ࡯࡯ࡵ࠱ࡧࡴࡳࠧ㪠")]
			,l11lll_l1_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ㪡")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ㪢")]
			,l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ㪣")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ㪤")]
			,l11lll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ㪥")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ㪦")]
			,l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ㪧")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ㪨")]
			,l11lll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ㪩")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ㪪")]
			,l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㪫")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ㪬")]
			,l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ㪭")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥ࠲ࡻ࡯ࡰࠨ㪮")]
			,l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㪯")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭㪰")]
			,l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭㪱")	:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠷࠰ࡰࡽ࠲ࡩࡩ࡮ࡣ࠱ࡲࡪࡺࠧ㪲")]
			,l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㪳")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠲ࡴ࡯ࡸ࠰ࡦࡳࡲ࠭㪴")]
			,l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ㪵")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㪶"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪ㪷")]
			,l11lll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ㪸")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡣ࠯ࡦࡵࡥࡲࡧࡳ࠸࠰ࡦࡳࡲ࠭㪹")]
			,l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ㪺")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯࠯ࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ㪻")]
			,l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ㪼")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࡫ࡶࠨ㪽")]
			,l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㪾")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪ㪿")]
			,l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭㫀")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ㫁")]
			,l11lll_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ㫂")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧ㫃")]
			,l11lll_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪ㫄")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩ㫅")]
			,l11lll_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ㫆")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩ㫇")]
			,l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ㫈")	:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫ㫉")]
			,l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ㫊")		:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡷ࡫ࡳࠫ㫋")]
			,l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㫌")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩ㫍")]
			,l11lll_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㫎")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩ㫏")]
			,l11lll_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㫐")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡹࡸ࠭㫑")]
			,l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㫒")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㫓"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫ㫔"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㫕"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ㫖"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭㫗")]
			,l11lll_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㫘")	:[l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩ㫙")]
			,l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ㫚")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡤࡸࡰࡵࡵࡵࡧ࠱ࡧࡴࡳࠧ㫛")]
			,l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭㫜")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡰࡸ࠱࡯࡮ࡺ࡫ࡰࡶ࠱ࡸࡻ࠭㫝")]
			,l11lll_l1_ (u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ㫞")	:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫ㫟"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࠲࡫ࡽࡳ࠯ࡵࡷࡳࡷ࡫ࠧ㫠")]
			,l11lll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㫡")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡩࡡ࡮ࠩ㫢")]
			,l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ㫣")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧ㫤")]
			,l11lll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㫥")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠴࠲ࡻ࡯ࡰࠨ㫦")]
			,l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ㫧")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࠳ࡹࡨ࠵ࡷ࠱ࡲࡪࡽࡳࠨ㫨")]
			,l11lll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ㫩")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪ㫪")]
			,l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ㫫")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭㫬"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡧࡴࡳࠧ㫭"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ㫮")]
			,l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ㫯")		:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨ㫰")]
			,l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ㫱")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡴࡶࡤࡨࠫ㫲")]
			,l11lll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ㫳")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡻ࠱ࡽࡦࡷ࡯ࡵ࠰ࡷࡺࠬ㫴")]
			,l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㫵")		:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱࠬ㫶")]
			#,l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㫷")		:[l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㫸"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㫹"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㫺"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㫻"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㫼"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㫽"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㫾")]
			#,l11lll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㫿")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㬀"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㬁"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㬂"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㬃"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㬄"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㬅"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㬆")]
			#,l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬇")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ㬈"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭㬉"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ㬊"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ㬋"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ㬌"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ㬍"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ㬎")]
			#,l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㬏")		:[l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ㬐"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ㬑"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭㬒"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ㬓"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ㬔"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ㬕"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ㬖"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩ㬗"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ㬘")]
			#,l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭㬙")	:[l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭㬚"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ㬛"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ㬜"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ㬝"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ㬞"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ㬟"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ㬠"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ㬡"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭㬢")]
			,l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬣")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㬤"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㬥"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㬦"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㬧"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㬨"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㬩"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㬪"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㬫"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ㬬")]
			,l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㬭")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ㬮"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ㬯"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ㬰"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ㬱"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ㬲"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ㬳"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ㬴"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ㬵"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ㬶")]
			,l11lll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ㬷")		:[l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ㬸"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪ㬹"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫ㬺")]
			,l11lll_l1_ (u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫ㬻")	:[l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㬼"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ㬽"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭㬾")]
			,l11lll_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭㬿")		:[l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭㭀"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡷࡺࡸࡧࡦ࠰ࡶ࡬ࠬ㭁"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒࠫ㭂")]
			}
class l1ll111l1ll1_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l11l1ll1_l1_ = -1
	def onClick(self,l1lll1l11l11_l1_):
		if l1lll1l11l11_l1_>=9010: self.l11l11l1ll1_l1_ = l1lll1l11l11_l1_-9010
		self.delete()
	def l1111111l11_l1_(self,*args):
		#self.getControl(9001).l1l11l111ll_l1_(header)
		#self.getControl(9009).l1ll1ll11l1l_l1_(text)
		#self.getControl(9010).l1l11l111ll_l1_(l1llll11llll_l1_)
		#self.getControl(9011).l1l11l111ll_l1_(l1l11lllllll_l1_)
		#self.getControl(9012).l1l11l111ll_l1_(l1llll1l1l11_l1_)
		self.l1llll11llll_l1_,self.l1l11lllllll_l1_,self.l1llll1l1l11_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l1lll1l1l1_l1_ = args[5],args[6]
		self.l1l1lll1llll_l1_,self.l1l11111ll1l_l1_,self.l1l11l11llll_l1_ = args[7],args[8],args[9]
		if self.l1l11111ll1l_l1_>0 or self.l1l11l11llll_l1_>0: self.l1l1ll11ll11_l1_ = True
		else: self.l1l1ll11ll11_l1_ = False
		self.l1ll1lll1l11_l1_,self.l1111111ll1_l1_ = l1l11l1l1ll1_l1_(self.l1llll11llll_l1_,self.l1l11lllllll_l1_,self.l1llll1l1l11_l1_,self.header,self.text,self.profile,self.l1l1lll1l1l1_l1_,self.l1l1lll1llll_l1_,self.l1l1ll11ll11_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1ll1lll1l11_l1_)
		self.getControl(9050).setHeight(self.l1111111ll1_l1_)
		if not self.l1l11lllllll_l1_ and self.l1llll11llll_l1_ and self.l1llll1l1l11_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1ll1lll1l11_l1_,self.l1111111ll1_l1_
	def l11l11l111l_l1_(self):
		if self.l1l11111ll1l_l1_:
			import threading
			self.l11l1lll1ll_l1_ = threading.Thread(target=self.l1ll11111l11_l1_,args=())
			self.l11l1lll1ll_l1_.start()
			#self.l11l1lll1ll_l1_.join()
		else: self.enableButtons()
	def l1ll11111l11_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11l1lllll_l1_ in range(1,self.l1l11111ll1l_l1_+1):
			time.sleep(1)
			l1l1111l1l11_l1_ = int(100*l11l1lllll_l1_/self.l1l11111ll1l_l1_)
			self.l1l111ll11ll_l1_(l1l1111l1l11_l1_)
			if self.l11l11l1ll1_l1_>0: break
		self.enableButtons()
	def l111llll11l_l1_(self):
		if self.l1l11l11llll_l1_:
			import threading
			self.l1l1l1lll1l1_l1_ = threading.Thread(target=self.l1ll1llll1l1_l1_,args=())
			self.l1l1l1lll1l1_l1_.start()
			#self.l1l1l1lll1l1_l1_.join()
		else: self.enableButtons()
	def l1ll1llll1l1_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l11111ll1l_l1_)
		for l11l1lllll_l1_ in range(self.l1l11l11llll_l1_-1,-1,-1):
			time.sleep(1)
			l1l1111l1l11_l1_ = int(100*l11l1lllll_l1_/self.l1l11l11llll_l1_)
			self.l1l111ll11ll_l1_(l1l1111l1l11_l1_)
			if self.l11l11l1ll1_l1_>0: break
		if self.l1l11l11llll_l1_>0: self.l11l11l1ll1_l1_ = 10
		self.delete()
	def l1l111ll11ll_l1_(self,l1l1111l1l11_l1_):
		self.l1ll1ll1lll1_l1_ = l1l1111l1l11_l1_
		self.getControl(9020).setPercent(self.l1ll1ll1lll1_l1_)
	def enableButtons(self):
		if self.l1llll11llll_l1_!=l11lll_l1_ (u"ࠩࠪ㭃"): self.getControl(9010).setEnabled(True)
		if self.l1l11lllllll_l1_!=l11lll_l1_ (u"ࠪࠫ㭄"): self.getControl(9011).setEnabled(True)
		if self.l1llll1l1l11_l1_!=l11lll_l1_ (u"ࠫࠬ㭅"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1ll1lll1l11_l1_)
		except: pass
		#del self
	l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࡨࡪ࡬ࠠࡶࡲࡧࡥࡹ࡫ࠨࡴࡧ࡯ࡪ࠱ࡶࡥࡳࡥࡨࡲࡹ࠲ࠪࡢࡴࡪࡷ࠮ࡀࠍࠋࠋࠌࡸࡪࡾࡴࠡ࠿ࠣࡥࡷ࡭ࡳ࡜࠲ࡠࠑࠏࠏࠉࡪࡨࠣࡰࡪࡴࠨࡢࡴࡪࡷ࠮ࡄ࠱࠻ࠢࡷࡩࡽࡺࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࡣࡵ࡫ࡸࡡ࠱࡞ࠏࠍࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡧࡲࡨࡵࠬࡂ࠷ࡀࠠࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࡡࡳࡩࡶ࡟࠷ࡣࠍࠋࠋࠌࡷࡪࡲࡦ࠯ࡲࡨࡶࡨ࡫࡮ࡵ࠮ࡶࡩࡱ࡬࠮ࡵࡧࡻࡸࠥࡃࠠࡱࡧࡵࡧࡪࡴࡴ࠭ࡶࡨࡼࡹࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡪ࡯ࡤ࡫ࡪࡥࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡮ࡥࡪࡩ࡫ࡸࠥࡃࠠࡴࡧ࡯ࡪ࠳ࡩࡲࡦࡣࡷࡩࡘ࡮࡯ࡸࡋࡰࡥ࡬࡫ࠨࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲ࠵࠲ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠵࠱ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠵࠰ࡸ࡫࡬ࡧ࠰࡫ࡩࡦࡪࡥࡳ࠮ࡶࡩࡱ࡬࠮ࡵࡧࡻࡸ࠱ࡹࡥ࡭ࡨ࠱ࡴࡷࡵࡦࡪ࡮ࡨ࠰ࡸ࡫࡬ࡧ࠰ࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲ࠱ࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡࡺ࡭ࡩࡺࡨ࠭ࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳࡹࡴࡪ࡯ࡨࡳࡺࡺࠬࡴࡧ࡯ࡪ࠳ࡩ࡬ࡰࡵࡨࡸ࡮ࡳࡥࡰࡷࡷ࠭ࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡵࡱࡦࡤࡸࡪࡖࡲࡰࡩࡵࡩࡸࡹࡂࡢࡴࠫࡴࡪࡸࡣࡦࡰࡷ࠭ࠒࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠬࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡭࡫ࡩࡨࡪࡷࠑࠏࠏࠢࠣࠤ㭆")
class l11111lllll_l1_():
	def __init__(self,l1ll_l1_=False,l1l1ll11llll_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1l1ll11llll_l1_ = l1l1ll11llll_l1_
		self.l1111ll11l1_l1_,self.l11l1l11l1l_l1_ = [],[]
		self.l1lll1l11l1l_l1_,self.l1ll1l1l11ll_l1_ = {},{}
		self.l1lllll1llll_l1_ = []
		self.l1lll11llll1_l1_,self.l1l11l1111l1_l1_,self.l11l111l1l1_l1_ = {},{},{}
	def l11111l11ll_l1_(self,id,func,*args):
		id = str(id)
		self.l1lll1l11l1l_l1_[id] = l11lll_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㭇")
		if self.l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧࠨ㭈"),id)
		# l1llllll1111_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1llllll1111_l1_ 2 & 3
		import threading
		l11l11ll111_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1lllll1llll_l1_.append(l11l11ll111_l1_)
		#l11l11ll111_l1_.start()
		return l11l11ll111_l1_
	def start_new_thread(self,id,func,*args):
		l11l11ll111_l1_ = self.l11111l11ll_l1_(id,func,*args)
		l11l11ll111_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1lll11llll1_l1_[id] = time.time()
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㭉"),l11lll_l1_ (u"ࠩࡷ࡬ࡷ࡫ࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣ࡭ࡩࡀࠠࠨ㭊")+id)
		try:
			#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㭋"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅ࠼࠽ࠤࠬ㭌")+str(func))
			self.l1ll1l1l11ll_l1_[id] = func(*args)
			if l11lll_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭㭍") in str(func) and not self.l1ll1l1l11ll_l1_[id].succeeded:
				l1lll1111lll_l1_(l11lll_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬ㭎"))
			self.l1111ll11l1_l1_.append(id)
			self.l1lll1l11l1l_l1_[id] = l11lll_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ㭏")
			#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㭐"),l11lll_l1_ (u"ࠩࡷ࡬ࡷ࡫ࡡࡥࠢࡩ࡭ࡳ࡯ࡳࡩࡧࡧࠤ࡮ࡪ࠺ࠡࠩ㭑")+id)
		except Exception as err:
			#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㭒"),l11lll_l1_ (u"ࠫࡹ࡮ࡲࡦࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤ࡮ࡪ࠺ࠡࠩ㭓")+id)
			if self.l1l1ll11llll_l1_:
				l1lll1lll1ll_l1_ = traceback.format_exc()
				sys.stderr.write(l1lll1lll1ll_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l1l11l1l_l1_.append(id)
			self.l1lll1l11l1l_l1_[id] = l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㭔")
		self.l1l11l1111l1_l1_[id] = time.time()
		self.l11l111l1l1_l1_[id] = self.l1l11l1111l1_l1_[id] - self.l1lll11llll1_l1_[id]
	def l1l1ll11lll1_l1_(self):
		for proc in self.l1lllll1llll_l1_:
			proc.start()
	def l1l1111ll11l_l1_(self):
		while l11lll_l1_ (u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧ㭕") in list(self.l1lll1l11l1l_l1_.values()): time.sleep(1.000)
def l1l1lll111l1_l1_():
	l1l1l1l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㭖"))
	l1llll11l1ll_l1_ = True
	if l1l1l1l1ll11_l1_==l11ll111111_l1_:
		status = l11lll_l1_ (u"ࠨࡐࡒࡣ࡚ࡖࡄࡂࡖࡈࠫ㭗")
		l1llll11l1ll_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㭘")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11lll_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ㭙")
	else:
		status = l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡘࡔࡉࡇࡔࡆࠩ㭚")
		l111l11l1ll_l1_ = [l11lll_l1_ (u"ࠬ࠾࠮࠶࠰࠳ࠫ㭛"),l11lll_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠶࠮࠲࠻ࠪ㭜"),l11lll_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠱࠯࠴࠷ࡥࠬ㭝"),l11lll_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠳࠰࠶࠴ࠬ㭞"),l11lll_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠱࠴࠱࠴࠷࠭㭟"),l11lll_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠳࠳࠲࠷࠸ࠧ㭠"),l11lll_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠷࠳࠶࠶ࠨ㭡"),l11lll_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠺࠴࠱࠷ࠩ㭢"),l11lll_l1_ (u"࠭࠲࠱࠴࠶࠲࠵࠼࠮࠱࠸ࠪ㭣"),l11lll_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠷࠰࠯࠴࠻ࠫ㭤")]
		l1ll1l111ll1_l1_ = l111l11l1ll_l1_[-1]
		l1llll1ll111_l1_ = l1l1111l1111_l1_(l1ll1l111ll1_l1_)
		l1ll11l1l111_l1_ = l1l1111l1111_l1_(l11ll111111_l1_)
		if l1ll11l1l111_l1_>l1llll1ll111_l1_:
			status = l11lll_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ㭥")
			l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉࠊࠋࡩ࡭ࡱ࡫ࡳࠡ࠿ࠣࡳࡸ࠴࡬ࡪࡵࡷࡨ࡮ࡸࠨࡢࡦࡧࡳࡳࡩࡡࡤࡪࡨࡪࡴࡲࡤࡦࡴࠬࠑࠏࠏࠉࠊࡨ࡬ࡰࡪࡹࠠ࠾ࠢࡶࡳࡷࡺࡥࡥࠪࡩ࡭ࡱ࡫ࡳ࠭ࡴࡨࡺࡪࡸࡳࡦ࠿ࡗࡶࡺ࡫ࠩࠎࠌࠌࠍࠎ࡬࡯ࡳࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡧ࡫࡯ࡩࡸࡀࠍࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡧࡥࡹࡧ࡟ࠨࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠠࡢࡰࡧࠤࠬ࠴ࡤࡣࠩࠣ࡭ࡳࠦࡦࡪ࡮ࡨࡲࡦࡳࡥ࠻ࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤࡣ࠭࠴ࠪࡀࠫ࡟࠲ࡩࡨࠧ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱ࡟࠵ࡣࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩࠥࡃࠠࡗࡇࡕࡗࡎࡕࡎࡠࡅࡒࡑࡕࡇࡒࡆࡡࡓࡅࡗ࡙ࡅࡓࠪࡲࡰࡩࡥࡶࡦࡴࡶ࡭ࡴࡴࠩࠎࠌࠌࠍࠎࠏࠉࡪࡨࠣࠫࡲࡧࡩ࡯ࡦࡤࡸࡦࡥࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡳࡱࡪ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࡠࡥࡲࡱࡵࡧࡲࡦࡀࡀࡰࡦࡹࡴࡧࡷ࡯ࡰࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠺ࠎࠌࠌࠍࠎࠏࠉࠊࠋࡲࡰࡩࡥࡤࡣࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡢࡦࡧࡳࡳࡩࡡࡤࡪࡨࡪࡴࡲࡤࡦࡴ࠯ࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡵࡴࡼ࠾ࠒࠐࠉࠊࠋࠌࠍࠎࠏࠉࡪࡨࠣࡳࡱࡪ࡟ࡥࡤࡩ࡭ࡱ࡫ࠡ࠾࡯ࡤ࡭ࡳࡥࡤࡣࡨ࡬ࡰࡪࡀࠠࡰࡵ࠱ࡶࡪࡴࡡ࡮ࡧࠫࡳࡱࡪ࡟ࡥࡤࡩ࡭ࡱ࡫ࠬ࡮ࡣ࡬ࡲࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠓࠊࠊࠋࠌࠍࠎࠏࠉࠊࡵࡷࡥࡹࡻࡳࠡ࠿ࠣࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫࠒࠐࠉࠊࠋࠌࠍࠎࠏࠉࡣࡴࡨࡥࡰࠓࠊࠊࠋࠌࠍࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠋࠌࠦࠧࠨ㭦")
	return status,l1llll11l1ll_l1_
def l1lll1111l1l_l1_(l1l1l1ll111_l1_,l1ll111llll1_l1_):
	succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_ = True,False,False
	type,name,l11lll1l11l_l1_,mode,l11llll11l1_l1_,l11l1l1ll1l_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
	l1l11ll1lll1_l1_ = type,name,l11lll1l11l_l1_,mode,l11llll11l1_l1_,l11l1l1ll1l_l1_,text,l11lll_l1_ (u"ࠪࠫ㭧"),l1ll111l111_l1_
	l1l1ll111111_l1_ = int(mode)
	l111111l111_l1_ = int(l1l1ll111111_l1_%10)
	l1l1ll11111l_l1_ = int(l1l1ll111111_l1_/10)
	l1l1111ll111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ㭨"))
	l1llll111111_l1_,l1llll11l1ll_l1_ = l1l1lll111l1_l1_()
	if l1llll11l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㭩"),l11lll_l1_ (u"࠭ࠧ㭪"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㭫"),l11lll_l1_ (u"ࠨฬ่ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ็๊ࠡฮ๊หื้࡜࡯ว็ํࠥอไฦืาหึࠦัใ็࠽ࡠࡳࡢ࡮ࠨ㭬")+l11ll111111_l1_)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㭭"),l11lll_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㭮"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㭯"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㭰"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㭱"),l11lll_l1_ (u"ࠧࡂࡗࡗࡌࠬ㭲"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫ㭳"),l11lll_l1_ (u"ࠩࠪ㭴"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡵࡳࡵࡣࠪ㭵"),l11lll_l1_ (u"ࠫࠬ㭶"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡢࡤࡵࡥࡰࡧࠧ㭷"),l11lll_l1_ (u"࠭ࠧ㭸"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ㭹"),l11lll_l1_ (u"ࠨࠩ㭺"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㭻"),l11lll_l1_ (u"ࠪࠫ㭼"))
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㭽"),l11lll_l1_ (u"ࠬ࠭㭾"))
		#settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㭿"),l11lll_l1_ (u"ࠧࠨ㮀"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㮁"),l11lll_l1_ (u"ࠩࠪ㮂"))
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ㮃"),l11lll_l1_ (u"ࠫࠬ㮄"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㮅"),l11lll_l1_ (u"࠭ࠧ㮆"))
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪࡶ࡯ࡴ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯ࠬ㮇"),l11lll_l1_ (u"ࠨࠩ㮈"))
		#if not l1l1111ll111_l1_: settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㮉"),l11lll_l1_ (u"ࠪࠫ㮊"))
		#l1l1l1l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㮋"))
		#if l1l1l1l1ll11_l1_:
		#	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ㮌"),l11lll_l1_ (u"࠭ࠧ㮍"))
		#	xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㮎"))
		#	return
		#l111l11ll11_l1_([main_dbfile])
		import l11ll1lll11_l1_
		if l1llll111111_l1_==l11lll_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ㮏"):
			LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㮐"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ㮑")+addon_path+l11lll_l1_ (u"ࠫࠥࡣࠧ㮒"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭㮓"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛࠭㮔"))
			DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚࠭㮕"))
		else:
			LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㮖"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡋ࡛ࡌࡍࠢࡘࡔࡉࡇࡔࡆࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭㮗")+addon_path+l11lll_l1_ (u"ࠪࠤࡢ࠭㮘"))
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㮙"),l11lll_l1_ (u"ࠬ࠭㮚"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㮛"),l11lll_l1_ (u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ㮜"))
			l111l11ll11_l1_()
			FIX_ALL_DATABASES(False)
			user = l11llll11ll_l1_(32)
			l11ll1lll11_l1_.l1l11llll111_l1_()
			l11ll1lll11_l1_.l111ll1l1l1_l1_(l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㮝"),False)
			l11ll1lll11_l1_.l111ll1l1l1_l1_(l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ㮞"),False)
			l11ll1lll11_l1_.l1ll1lll11ll_l1_(False)
			l11ll1lll11_l1_.l1l11ll1ll11_l1_(False)
			l11ll1lll11_l1_.l1l11lll1ll1_l1_(l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㮟"),l11lll_l1_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࠫ㮠"),False)
			l11lll_l1_ (u"ࠧࠨࠢࠎࠌࠌࠍࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࠉࠊࡵࡨࡸࡹ࡯࡮ࡨࡵࡩ࡭ࡱ࡫࠲ࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡸࡷࡪࡸࡦࡰ࡮ࡧࡩࡷ࠲ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ࠯ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ࠮ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ࠰ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠸ࠠ࠾ࠢࡻࡦࡲࡩࡡࡥࡦࡲࡲ࠳ࡇࡤࡥࡱࡱࠬ࡮ࡪ࠽ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨࠫࠐࠎࠎࠏࠉࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠵࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩ࡮ࡳࡩ࡯࡯࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡳࡸࡥࡱ࡯ࡴࡺ࠰ࡤࡷࡰ࠭ࠬࠨࡶࡵࡹࡪ࠭ࠩࠎࠌࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠉࠊࠤࠥࠦ㮡")
			try:
				l1l111ll11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㮢"),l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ㮣"),l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ㮤"),l11lll_l1_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ㮥"))
				l1l111ll1l11_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ㮦"))
				l1l111ll1l11_l1_.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪ㮧"),l11lll_l1_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ㮨"))
			except: pass
			try:
				l1l111ll11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㮩"),l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ㮪"),l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ㮫"),l11lll_l1_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ㮬"))
				l1l111ll1l11_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ㮭"))
				l1l111ll1l11_l1_.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧ㮮"),l11lll_l1_ (u"ࠬ࠹ࠧ㮯"))
			except: pass
			try:
				l1l111ll11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ㮰"),l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ㮱"),l11lll_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㮲"),l11lll_l1_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ㮳"))
				l1l111ll1l11_l1_ = xbmcaddon.Addon(id=l11lll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㮴"))
				l1l111ll1l11_l1_.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩ㮵"),l11lll_l1_ (u"ࠬ࠸ࠧ㮶"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㮷"),l11lll_l1_ (u"ࠧࠨ㮸"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㮹"),l11lll_l1_ (u"ࠩศิฬࠦใ็ฬࠣฮุะฮะ็ࠣาิ๋ษࠡโࡌࡔ࡙࡜ࠠศๆ่์ั๎ฯสࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠤๆู่โࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠหๆๅหห๐วࠡสฯ่อࠦๅๅใสฮࠥๆࡉࡑࡖ࡙ࠤัี๊ะหࠪ㮺"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(dummym3ufile):
			#	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㮻"),l11lll_l1_ (u"ࠫࠬ㮼"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㮽"),l11lll_l1_ (u"࠭ลัษࠣ็๋ะࠠหีอาิ๋ࠠฯั่อࠥๆࡍ࠴ࡗࠣห้๋่อ๊าอࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠠโี๋ๅࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥอไร่ࠣฮ้่วว์สࠤอาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ㮾"))
			#	import M3U
			#	M3U.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11lll1111l_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1111l11l1_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㮿"),l11ll111111_l1_)
		l11ll1lll11_l1_.l111lll11ll_l1_(False)
		#return
	#text = text.replace(l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㯀"),l11lll_l1_ (u"ࠩࠪ㯁"))
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㯂"))
	l11l1lll11_l1_ = RESTORE_PATH_NAME(l1ll111llll1_l1_)
	l11ll1l1l11_l1_ = RESTORE_PATH_NAME(name)
	l1lll111l11l_l1_ = [0,15,17,19,26,34,50,53]
	l1l1lll1ll1l_l1_ = [0,15,17,19,26,34,50,53]
	l11l111llll_l1_ = l1l1ll11111l_l1_ not in l1l1lll1ll1l_l1_
	l1l1111ll1ll_l1_ = l1l1ll11111l_l1_ in [23,28,71,72]
	l1ll111l1lll_l1_ = l1l1ll111111_l1_ in [265,270]
	l1ll1l1ll1l1_l1_ = (l11l111llll_l1_ or l1l1111ll1ll_l1_) and not l1ll111l1lll_l1_
	l111l111ll1_l1_ = l1l11llll1_l1_!=l11lll_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㯃") and (l1l11llll1_l1_!=l11lll_l1_ (u"ࠬ࠭㯄") or context==l11lll_l1_ (u"࠭ࠧ㯅"))
	l1l1ll11l111_l1_ = l11lll_l1_ (u"ࠧࡵࡻࡳࡩࡂ࠭㯆") in l1l11llll1_l1_
	l1l11lll111l_l1_ = l1l1ll111111_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	SEARCH = l111111l111_l1_==9 or l1l1ll111111_l1_ in [145,516,523,45]
	l111llllll1_l1_ = not l1l11lll111l_l1_
	l1111l1llll_l1_ = not SEARCH
	l1l1l1l11lll_l1_ = l11l1lll11_l1_ in [l11lll_l1_ (u"ࠨࠩ㯇"),l11lll_l1_ (u"ࠩ࠱࠲ࠬ㯈")]
	l1llll1l11ll_l1_ = l1l1l1l11lll_l1_ or l111llllll1_l1_
	l1lll111lll1_l1_ = l1l1l1l11lll_l1_ or l1111l1llll_l1_ or l1l1ll11l111_l1_
	l1l11l111ll1_l1_ = l1l1ll111111_l1_ not in [260,265,270,330,540]
	if l1l1111ll111_l1_: l1llll1l1111_l1_ = SEARCH or l1l11lll111l_l1_
	else: l1llll1l1111_l1_ = True
	l1l1l1llll_l1_ = l1l1ll11111l_l1_ in [74,75]
	l111lll1l1l_l1_ = l1l1ll111111_l1_ in [280,720]
	l1lllll1111l_l1_ = not l1l1l1llll_l1_ and not l111lll1l1l_l1_
	l1ll11l1l1ll_l1_ = l1llll1l11ll_l1_ and l1lll111lll1_l1_ and l1l11l111ll1_l1_ and l1llll1l1111_l1_ and l1lllll1111l_l1_
	l1111l1l11l_l1_ = l1l11l111ll1_l1_ and l1llll1l1111_l1_ and l1lllll1111l_l1_
	l111l1l11ll_l1_ = l1111l1l11l_l1_
	l11l1l1l111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡲࡵࡳࡻ࡯ࡤࡦࡴࠪ㯉"))
	trans_code = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧ㯊"))
	if 1 and l111l111ll1_l1_ and l1ll11l1l1ll_l1_:
		l1ll1l1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ㯋"),l11lll_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㯌")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠧࡠࠩ㯍")+trans_code,l1l11ll1lll1_l1_)
		if l1ll1l1l1111_l1_:
			#xbmcgui.Dialog().l1l11ll111ll_l1_(l11lll_l1_ (u"ࠨࠩ㯎"),l11lll_l1_ (u"ࠩࡵࡩࡦࡪࡩ࡯ࡩࠣࡧࡦࡩࡨࡦࠩ㯏"),l11lll_l1_ (u"ࠪࠫ㯐"),100,False)
			LOG_THIS(l11lll_l1_ (u"ࠫࠬ㯑"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㯒")+l11l1l1l111_l1_+l11lll_l1_ (u"࠭࡟ࠨ㯓")+trans_code+l11lll_l1_ (u"ࠧࠡࠢࠣࡐࡴࡧࡤࡪࡰࡪࠤࡲ࡫࡮ࡶࠢࡩࡶࡴࡳࠠࡤࡣࡦ࡬ࡪ࠭㯔"))
			if 1 and l1l1ll11l111_l1_:
				#xbmcgui.Dialog().l1l11ll111ll_l1_(l11lll_l1_ (u"ࠨࠩ㯕"),l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡺ࡫ࡱ࡫ࠥ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ㯖"),l11lll_l1_ (u"ࠪࠫ㯗"),100,False)
				l111lll1lll_l1_ = []
				import l1l11l1ll111_l1_,FAVORITES
				l1ll11l11111_l1_ = l1l11l1ll111_l1_.l1ll1l11l1ll_l1_
				l111lll1111_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l1lll1l1l111_l1_ = l1l11llll1_l1_
				l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll111ll111_l1_,l1l1l1lll111_l1_,l1l11l1l1lll_l1_,l1lll111111l_l1_,l1111ll1l11_l1_,l1l1llll1l11_l1_,l1ll1lllll11_l1_ = EXTRACT_KODI_PATH(l1lll1l1l111_l1_)
				l1ll11l111ll_l1_ = l1111l11ll1_l1_,l1111ll11ll_l1_,l1ll111ll111_l1_,l1l1l1lll111_l1_,l1l11l1l1lll_l1_,l1lll111111l_l1_,l1111ll1l11_l1_,l11lll_l1_ (u"ࠫࠬ㯘"),l1ll1lllll11_l1_
				#LOG_THIS(l11lll_l1_ (u"ࠬ࠭㯙"),str(l1ll11l111ll_l1_))
				for l1l1ll1ll1ll_l1_ in l1ll1l1l1111_l1_:
					l1l1l11l11l1_l1_ = l1l1ll1ll1ll_l1_[l11lll_l1_ (u"࠭࡭ࡦࡰࡸࡍࡹ࡫࡭ࠨ㯚")]
					#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㯛"),str(l1l1l11l11l1_l1_))
					if l1l1l11l11l1_l1_==l1ll11l111ll_l1_ or l1l1ll1ll1ll_l1_[l11lll_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭㯜")] in [265,270]:
						l1l1ll1ll1ll_l1_ = GET_LIST_ITEM(l1l1l11l11l1_l1_,l1ll11l11111_l1_,l111lll1111_l1_)
						if l1l1ll1ll1ll_l1_[l11lll_l1_ (u"ࠩࡩࡥࡻࡵࡲࡪࡶࡨࡷࠬ㯝")]:
							#xbmcgui.Dialog().l1l11ll111ll_l1_(l11lll_l1_ (u"ࠪࠫ㯞"),l11lll_l1_ (u"ࠫࡺࡶࡤࡢࡶ࡬ࡲ࡬ࠦࡣࡰࡰࡷࡩࡽࡺࠧ㯟"),l11lll_l1_ (u"ࠬ࠭㯠"),100,False)
							l1l1l1l1ll1l_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111lll1111_l1_,l1l1l11l11l1_l1_,l1l1ll1ll1ll_l1_[l11lll_l1_ (u"࠭࡮ࡦࡹࡳࡥࡹ࡮ࠧ㯡")])
							#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㯢"),str(l1l1l1l1ll1l_l1_))
							#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㯣"),str(l1l1ll1ll1ll_l1_[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ㯤")]))
							l1l1ll1ll1ll_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ㯥")] = l1l1l1l1ll1l_l1_+l1l1ll1ll1ll_l1_[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ㯦")]
					l111lll1lll_l1_.append(l1l1ll1ll1ll_l1_)
				settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㯧"),l11lll_l1_ (u"࠭ࠧ㯨"))
				if type==l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯩"): WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ㯪")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠩࡢࠫ㯫")+trans_code,l1l11ll1lll1_l1_,l111lll1lll_l1_,REGULAR_CACHE)
			else: l111lll1lll_l1_ = l1ll1l1l1111_l1_
			if type==l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㯬") and l11l1lll11_l1_!=l11lll_l1_ (u"ࠫ࠳࠴ࠧ㯭") and l1ll1l1ll1l1_l1_: l11llll111l_l1_()
			l1111llll11_l1_ = CREATE_KODI_MENU(l1l11ll1lll1_l1_,l111lll1lll_l1_,succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_)
			#xbmcgui.Dialog().l1l11ll111ll_l1_(l11lll_l1_ (u"ࠬ࠭㯮"),l11lll_l1_ (u"࠭ࡣࡳࡧࡤࡸ࡮ࡴࡧࠡ࡯ࡨࡲࡺ࠭㯯"),l11lll_l1_ (u"ࠧࠨ㯰"),100,False)
			return
	elif type==l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯱") and l1l11llll1_l1_==l11lll_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㯲") and l1111l1l11l_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ㯳"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㯴")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠬࡥࠧ㯵")+trans_code+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡩࡱ࡫ࡴࡪࡰࡪࠤࡴࡲࡤࠡࡥࡤࡧ࡭࡫ࡤࠡ࡯ࡨࡲࡺ࠭㯶"))
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭㯷")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠨࡡࠪ㯸")+trans_code,l1l11ll1lll1_l1_)
	#context = l11lll_l1_ (u"ࠩࠪ㯹")
	if l11lll_l1_ (u"ࠪࡣࠬ㯺") in context: l1l1llll1111_l1_,l1l11l11l1l1_l1_ = context.split(l11lll_l1_ (u"ࠫࡤ࠭㯻"),1)
	else: l1l1llll1111_l1_,l1l11l11l1l1_l1_ = context,l11lll_l1_ (u"ࠬ࠭㯼")
	if l1l1llll1111_l1_ in [l11lll_l1_ (u"࠭࠱ࠨ㯽"),l11lll_l1_ (u"ࠧ࠳ࠩ㯾"),l11lll_l1_ (u"ࠨ࠵ࠪ㯿"),l11lll_l1_ (u"ࠩ࠷ࠫ㰀"),l11lll_l1_ (u"ࠪ࠹ࠬ㰁")] and l1l11l11l1l1_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㰂") l11l11ll11_l1_ l1l11ll1ll1l_l1_ l1l111lll11l_l1_ is no addon_handle l1l1l111l_l1_ to l111l111l1l_l1_ for l1ll1l1lll1l_l1_ directory
		#l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠨ㰃") l11l11ll11_l1_ to open a menu list using l1l11lll11ll_l1_ addon_path
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ㰄")+sys.argv[0]+addon_path.split(l11lll_l1_ (u"ࠧࠧࡥࡲࡲࡹ࡫ࡸࡵ࠿ࠪ㰅"))[0]+l11lll_l1_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀ࠴ࠬ㰆")+l11lll_l1_ (u"ࠤࠬࠦ㰇"))
		#xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ㰈")+addon_id+l11lll_l1_ (u"ࠫ࠴ࡅࡴࡦࡺࡷࡁࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠯ࠧ㰉"))
		# l1111l11l1_l1_ not remove addon_path .. it is needed to update l1l1l1l1lll1_l1_ status
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㰊"),addon_path)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㰋"))
		return
	elif l1l1llll1111_l1_==l11lll_l1_ (u"ࠧ࠷ࠩ㰌"):
		if l1l11l11l1l1_l1_==l11lll_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㰍"): DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ㰎"),l11lll_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ㰏"))
		elif l1l11l11l1l1_l1_==l11lll_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ㰐"): l1l1ll111111_l1_ = 334
		results = l1l1l11l1l1l_l1_(type,l11ll1l1l11_l1_,l11lll1l11l_l1_,l1l1ll111111_l1_,l11llll11l1_l1_,l11l1l1ll1l_l1_,text,context,l1ll111l111_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㰑"))
		return
	elif context==l11lll_l1_ (u"࠭࠷ࠨ㰒"):
		import l1ll1l1111l_l1_
		l1ll1l1111l_l1_.l1l1l1l1l1l_l1_()
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㰓"))
		return
	elif context==l11lll_l1_ (u"ࠨ࠺ࠪ㰔"):
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㰕")+addon_id+l11lll_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ㰖")+str(mode)+l11lll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ㰗"))
		return
	elif context==l11lll_l1_ (u"ࠬ࠿ࠧ㰘"):
		# l1l1ll1ll1l1_l1_ update the l1l111l11l11_l1_ menu
		#results = l1l1l11l1l1l_l1_(type,l11ll1l1l11_l1_,l11lll1l11l_l1_,mode,l11llll11l1_l1_,l11l1l1ll1l_l1_,text,context,l1ll111l111_l1_)
		# l1l1ll1ll1l1_l1_ update the l1ll1l1l1l11_l1_ menu
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㰙"),l11lll_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ㰚"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㰛"))
		return
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㰜")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㰝"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ㰞"),l11lll_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㰟")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ㰠"),l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ㰡"))
	if not settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ㰢")): settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ㰣"),l1lll1l11111_l1_[0])
	l1l111l1l111_l1_ = False if l11l1llll1l_l1_(l11lll_l1_ (u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ㰤")) else True
	l11l11l1l11_l1_ = l1lll1111_l1_ if l1l111l1l111_l1_ else REGULAR_CACHE
	l11l1111111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ㰥"))
	l1l11l111lll_l1_ = l1lll1111l11_l1_(settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㰦")))
	l1l11l111lll_l1_ = 0 if not l1l11l111lll_l1_ else int(l1l11l111lll_l1_)
	if l11l1111111_l1_ in [l11lll_l1_ (u"࠭ࠧ㰧"),l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㰨")] or not l11l11l1l11_l1_ or not l1l11l111lll_l1_ or now-l1l11l111lll_l1_<0 or now-l1l11l111lll_l1_>l11l11l1l11_l1_:
		l11l1111111_l1_ = l11111l1ll1_l1_(True,False)
	l11l111l1ll_l1_ = l1lll1111l11_l1_(settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ㰩")))
	l11l111l1ll_l1_ = 0 if not l11l111l1ll_l1_ else int(l11l111l1ll_l1_)
	l1111ll1111_l1_ = l1lll1111l11_l1_(settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮ࠫ㰪")))
	l1111ll1111_l1_ = 0 if not l1111ll1111_l1_ else int(l1111ll1111_l1_)
	if not l11l111l1ll_l1_ or not l1111ll1111_l1_ or now-l1111ll1111_l1_<0 or now-l1111ll1111_l1_>l11l111l1ll_l1_:
		auth = 1
		if l1l111l1l111_l1_:
			# https://www.l1lll11ll1l1_l1_.com/l1l11llll11l_l1_/l1llllllllll_l1_
			# unescapeHTML(l11lll_l1_ (u"ࠪࠤࠫࠩࡸ࠳࠸࠶ࡆࡀࠦࠦࠤࡺ࠵࠻࠶ࡊ࠻ࠡࠨࠦࡼ࠷࠼࠲ࡂ࠽ࠣࠪࠨࡾ࠲࠷࠵ࡅ࠿ࠬ㰫"))
			#l1ll11l11l1l_l1_ = l11lll_l1_ (u"ࠫ⹀ࠦ⼝ࠡࠢ⾍ࠤࠥ⸰ࠠ⸼ࠩ㰬")
			#l1ll1llll111_l1_ = l11lll_l1_ (u"ࠬ⹁ࠠ⼞ࠢࠣ⾏ࠥࠦ⸪ࠡ⸽ࠪ㰭")
			l1l1l11l1l11_l1_ = l11l1111lll_l1_(True)
			if len(l1l1l11l1l11_l1_)>1:
				LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㰮"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㰯")+addon_path+l11lll_l1_ (u"ࠨࠢࡠࠫ㰰"))
				id,l1l11111lll1_l1_,l1l111lll111_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11l1l11_l1_[0]
				#if l11lll_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㰱") in reason: l1l1lll11l1l_l1_,l1l1lll11ll1_l1_,l1l1lll11lll_l1_ = reason.split(l11lll_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ㰲"),2)
				#else: l1l1lll11l1l_l1_,l1l1lll11ll1_l1_,l1l1lll11lll_l1_ = reason,reason,reason
				l1lll1l11ll1_l1_,l1lll1l11lll_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ㰳"))
				del l1l1l11l1l11_l1_[0]
				l1l1ll1111l1_l1_ = random.sample(l1l1l11l1l11_l1_,1)
				id,l1l11111lll1_l1_,l1l111lll111_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1ll1111l1_l1_[0]
				l1l111lll111_l1_ = l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ࠺ࠡࠩ㰴")+id+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㰵")+l1l111lll111_l1_
				l11111l1l11_l1_ = l11lll_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ㰶")
				l1ll1ll1ll1l_l1_ = l11lll_l1_ (u"ࠨษ็ฮอืูศฬࠪ㰷")
				l1llll11llll_l1_,l1l11lllllll_l1_ = l11111lll11_l1_,l11111l1l11_l1_
				l11l1l11_l1_ = [l1llll11llll_l1_,l1l11lllllll_l1_,l1ll1ll1ll1l_l1_]
				l11111111ll_l1_ = 5 if l11l1llll1l_l1_(l11lll_l1_ (u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪ㰸")) else 15
				choice = -9
				while choice<0:
					l1111ll1lll_l1_ = random.sample(l11l1l11_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ㰹"),l1111ll1lll_l1_[0],l1111ll1lll_l1_[1],l1111ll1lll_l1_[2],l1lll1l11ll1_l1_,l1l111lll111_l1_,l11lll_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭㰺"),l11111111ll_l1_,60)
					if choice==10: break
					import l11ll1lll11_l1_
					if choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[1]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭㰻"),l11lll_l1_ (u"࠭ࠧ㰼"),l11lll_l1_ (u"ฺ๊ࠧาอࠬ㰽"),l11lll_l1_ (u"ࠨࠩ㰾"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㰿"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไอ๊สฬࠥิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࠬ㱀")+reason,l11lll_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭㱁"),20)
						l11ll1lll11_l1_.l1l1ll1l1l1l_l1_()
						if choice>=0: choice = -9
					elif choice>=0 and l1111ll1lll_l1_[choice]==l11l1l11_l1_[2]:
						#choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭㱂"),l11lll_l1_ (u"࠭ࠧ㱃"),l1ll1ll1ll1l_l1_,l11lll_l1_ (u"ࠧࠨ㱄"),l1lll1l11ll1_l1_,l1l111lll111_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㱅")+l11l1l11_l1_[0]+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㱆"),l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㱇"),30)
						l11ll1lll11_l1_.l11lll1l1ll_l1_(False)
					if choice==-1: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㱈"),l11lll_l1_ (u"ࠬ࠭㱉"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㱊"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ัีําࠠฯูฦ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠠๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩ㱋"))
				auth = 1
			else: auth = 0
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㱌"),l1l1ll1ll111_l1_(now))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㱍"),l11lll_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ㱎"),auth,PERMANENT_CACHE)
	# l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㱏")	l111l111l1l_l1_ file to read/write the l1l1l111llll_l1_ menu list
	# l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㱐")		no l11l1l1111l_l1_ l1l11ll1l1ll_l1_ to the l1l1l111llll_l1_ menu list
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡘࡏࡔࡆࡕࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡏࡔࡆࡕࡢࡑࡔࡊࡅࡔࠢࡤࡲࡩࠦ࡭ࡰࡦࡨ࠵ࡂࡃ࠹ࠎࠌࠌࡓ࡙ࡎࡅࡓࡡࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡱࡴࡪࡥ࠱ࠢ࡬ࡲࠥࡡ࠱࠵࠷࠯࠹࠶࠼ࠬ࠶࠴࠶ࡡࠒࠐࠉࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࠽ࠡࡕࡌࡘࡊ࡙࡟ࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࠦ࡯ࡳࠢࡒࡘࡍࡋࡒࡠࡕࡈࡅࡗࡉࡈࡠࡏࡒࡈࡊ࡙ࠍࠋࠋࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡱࡴࡪࡥ࠳࠿ࡀ࠵࠻ࠦࡡ࡯ࡦࠣࡱࡴࡪࡥ࠱ࠣࡀ࠵࠻࠶ࠍࠋࠋ࡜ࡓ࡚࡚ࡕࡃࡇࡢࡑࡊࡔࡕࡔࠢࡀࠤࡲࡵࡤࡦ࠲ࠣ࡭ࡳ࡛ࠦ࠲࠶࠷ࡡࠒࠐࠉࠤࡰࡤࡱࡪࡥࠠ࠾ࠢࡆࡐࡊࡇࡎࡠࡏࡈࡒ࡚ࡥࡌࡂࡄࡈࡐ࠭ࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉ࡯ࡣࡰࡩࡤࠦ࠽ࠡࡔࡈࡗ࡙ࡕࡒࡆࡡࡓࡅ࡙ࡎ࡟ࡏࡃࡐࡉ࠭ࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉࡓࡇࡐࡉࡒࡈࡅࡓࡡࡕࡉࡘ࡛ࡌࡕࡕࡢࡑࡔࡊࡅࡔࠢࡀࠤࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡳࡷࠦࡒࡂࡐࡇࡓࡒࡥࡍࡐࡆࡈࡗࠥࡵࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࡡࡐࡉࡓ࡛ࡓࠎࠌࠌ࡭࡫ࠦࡒࡆࡏࡈࡑࡇࡋࡒࡠࡔࡈࡗ࡚ࡒࡔࡔࡡࡐࡓࡉࡋࡓ࠻ࠏࠍࠍࠎࠩࡩࡧࠢࡕࡅࡓࡊࡏࡎࡡࡐࡓࡉࡋࡓ࠻ࠢࡦࡳࡳࡪ࠱ࠡ࠿ࠣࠬࡲ࡫࡮ࡶࡡ࡯ࡥࡧ࡫࡬ࠡ࡫ࡱࠤࡠ࠭࠮࠯ࠩ࠯ࠫࡒࡧࡩ࡯ࠢࡐࡩࡳࡻࠧ࡞ࠫࠐࠎࠎࠏࠣࡦ࡮࡬ࡪ࡙ࠥࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖ࠾ࠥࡩ࡯࡯ࡦ࠴ࠤࡂࠦࠨ࡮ࡧࡱࡹࡤࡲࡡࡣࡧ࡯ࠥࡂࡴࡡ࡮ࡧࡢ࠭ࠒࠐࠉࠊ࡫ࡩࠤࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠣ࡭ࡳࠦࡴࡦࡺࡷࠤࡦࡴࡤࠡ࡯ࡨࡲࡺࡥ࡬ࡢࡤࡨࡰࠦࡃ࡮ࡢ࡯ࡨࡣࠥࡧ࡮ࡥࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡰࡦࡹࡴ࡮ࡧࡱࡹ࡫࡯࡬ࡦࠫ࠽ࠑࠏࠏࠉࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠮ࠡࠢࡕࡩࡦࡪࡩ࡯ࡩࠣࡰࡦࡹࡴࠡ࡯ࡨࡲࡺࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ࠯ࡦࡪࡤࡰࡰࡢࡴࡦࡺࡨࠬࠩࠣࡡࠬ࠯ࠍࠋࠋࠌࠍࡴࡲࡤࡇࡋࡏࡉࠥࡃࠠࡰࡲࡨࡲ࠭ࡲࡡࡴࡶࡰࡩࡳࡻࡦࡪ࡮ࡨ࠰ࠬࡸࡢࠨࠫ࠱ࡶࡪࡧࡤࠩࠫࠐࠎࠎࠏࠉࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢࡲࡰࡩࡌࡉࡍࡇࠣࡁࠥࡵ࡬ࡥࡈࡌࡐࡊ࠴ࡤࡦࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠍࠋࠋࠌࠍࡲ࡫࡮ࡶࡋࡷࡩࡲࡹࡌࡊࡕࡗ࡟࠿ࡣࠠ࠾ࠢࡈ࡚ࡆࡒࠨࠨ࡮࡬ࡷࡹ࠭ࠬࡰ࡮ࡧࡊࡎࡒࡅࠪࠏࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠑࠏࠏࠉࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠮࡚ࠡࠢࡶ࡮ࡺࡩ࡯ࡩࠣࡰࡦࡹࡴࠡ࡯ࡨࡲࡺࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ࠯ࡦࡪࡤࡰࡰࡢࡴࡦࡺࡨࠬࠩࠣࡡࠬ࠯ࠍࠋࠋࠌࠍࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡃࠠࡎࡃࡌࡒࡤࡊࡉࡔࡒࡄࡘࡈࡎࡅࡓࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩࡤ࠲ࡵࡳ࡮ࡢ࠰ࡲࡵࡤࡦ࠮࡬ࡱࡦ࡭ࡥࡠ࠮ࡳࡥ࡬࡫࡟࠭ࡶࡨࡼࡹ࠲ࡣࡰࡰࡷࡩࡽࡺࠬࡪࡰࡩࡳࡩ࡯ࡣࡵࠫࠐࠎࠎࠏࠉ࡯ࡧࡺࡊࡎࡒࡅࠡ࠿ࠣࡷࡹࡸࠨ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠ࡯ࡧࡺࡊࡎࡒࡅࠡ࠿ࠣࡲࡪࡽࡆࡊࡎࡈ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠒࠐࠉࠊࠋࡲࡴࡪࡴࠨ࡭ࡣࡶࡸࡲ࡫࡮ࡶࡨ࡬ࡰࡪ࠲ࠧࡸࡤࠪ࠭࠳ࡽࡲࡪࡶࡨࠬࡳ࡫ࡷࡇࡋࡏࡉ࠮ࠓࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡶࡹࡱࡺࡳࠡ࠿ࠣࡑࡆࡏࡎࡠࡆࡌࡗࡕࡇࡔࡄࡊࡈࡖ࠭ࡺࡹࡱࡧ࠯ࡲࡦࡳࡥࡠ࠮ࡸࡶࡱࡥࠬ࡮ࡱࡧࡩ࠱࡯࡭ࡢࡩࡨࡣ࠱ࡶࡡࡨࡧࡢ࠰ࡹ࡫ࡸࡵ࠮ࡦࡳࡳࡺࡥࡹࡶ࠯࡭ࡳ࡬࡯ࡥ࡫ࡦࡸ࠮ࠓࠊࠊࠤࠥࠦ㱑")
	results = l1l1l11l1l1l_l1_(type,l11ll1l1l11_l1_,l11lll1l11l_l1_,mode,l11llll11l1_l1_,l11l1l1ll1l_l1_,text,context,l1ll111l111_l1_)
	# l1111ll111l_l1_ l1llll11l11l_l1_: succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_ = True,False,True
	# l1lll1lll111_l1_ = True => l1ll1l11ll1l_l1_ this list is l1l1l1ll11l1_l1_ and will exit to main menu
	# l1lll1lll111_l1_ = False => l1ll1l11ll1l_l1_ this list is l1llllll11ll_l1_ and will exit to l1l1l111llll_l1_ menu
	# l111ll1l1ll_l1_ = True => will cause the l1l1111l1lll_l1_ status to l1l1111llll1_l1_ l1l1ll1111ll_l1_
	# l111ll1l1ll_l1_ = False => will l1l1l1llll11_l1_ the l1l1111l1lll_l1_ status to l111l111l11_l1_ l1llll1l1ll1_l1_
	#succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_ = True,False,True
	#if not l1lllll11111_l1_: l111ll1l1ll_l1_ = False
	if l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㱒") in text: l1lll1lll111_l1_ = True
	if type==l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱓"):
		if l11l1lll11_l1_!=l11lll_l1_ (u"ࠩ࠱࠲ࠬ㱔") and l1ll1l1ll1l1_l1_: l11llll111l_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪ࡭ࡳࡺࠧ㱕"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ㱖"),l11lll_l1_ (u"ࠬࡇࡕࡕࡊࠪ㱗")) or l1l1ll111111_l1_ not in l1lll111l11l_l1_) and not l11l1llll1l_l1_(l11lll_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ㱘")):
				import l1l11l1ll111_l1_
				l1ll1l1l1111_l1_ = GET_ALL_LIST_ITEMS(l1l11l1ll111_l1_.l1ll1l11l1ll_l1_)
				l1111llll11_l1_ = CREATE_KODI_MENU(l1l11ll1lll1_l1_,l1ll1l1l1111_l1_,succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_)
				if 1 and l1ll1l1l1111_l1_ and l111l1l11ll_l1_:
					#xbmcgui.Dialog().l1l11ll111ll_l1_(l11lll_l1_ (u"ࠧࠨ㱙"),l11lll_l1_ (u"ࠨࡹࡵ࡭ࡹ࡯࡮ࡨࠢࡦࡥࡨ࡮ࡥࠨ㱚"),l11lll_l1_ (u"ࠩࠪ㱛"),100,False)
					WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㱜")+l11l1l1l111_l1_+l11lll_l1_ (u"ࠫࡤ࠭㱝")+trans_code,l1l11ll1lll1_l1_,l1ll1l1l1111_l1_,REGULAR_CACHE)
				#elif 1 and not l1ll1l1l1111_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㱞")+l11l1l1l111_l1_+l11lll_l1_ (u"࠭࡟ࠨ㱟")+trans_code,l1l11ll1lll1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ㱠")+addon_id+l11lll_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ㱡"),xbmcgui.ListItem(l11lll_l1_ (u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦๅ็ࠢฯ๋ฬุใࠨ㱢")))
				xbmcplugin.addDirectoryItem(addon_handle,l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭㱣")+addon_id+l11lll_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ㱤"),xbmcgui.ListItem(l11lll_l1_ (u"ࠬษแหฯ่ࠣฯ่ัฤࠢส่ฯ็วึ์็ࠫ㱥")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_)
	return
def l1l1l11l1l1l_l1_(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_):
	l1l1ll111111_l1_ = int(mode)
	l1l1ll11111l_l1_ = int(l1l1ll111111_l1_//10)
	if   l1l1ll11111l_l1_==0:  import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==1:  import l111l1l1_l1_ 		; results = l111l1l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==2:  import l1l1l11l111_l1_ 		; results = l1l1l11l111_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==3:  import l1111l111ll_l1_ 		; results = l1111l111ll_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==4:  import l1l1l1ll1_l1_ 	; results = l1l1l1ll1_l1_.MAIN(l1l1ll111111_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll11111l_l1_==5:  import l11l111l11l_l1_ 	; results = l11l111l11l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==6:  import l1ll11ll1_l1_ 	; results = l1ll11ll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==7:  import l1l111l_l1_ 		; results = l1l111l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==8:  import l1l1l11l11l_l1_ 	; results = l1l1l11l11l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==9:  import l1ll1ll1ll_l1_		; results = l1ll1ll1ll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==10: import l1ll111lll11_l1_ 		; results = l1ll111lll11_l1_.MAIN(l1l1ll111111_l1_,url)
	elif l1l1ll11111l_l1_==11: import l1l1l1111lll_l1_ 	; results = l1l1l1111lll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==12: import l11111l1l1_l1_ 		; results = l11111l1l1_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==13: import l1l1ll111_l1_	; results = l1l1ll111_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==14: import l111llll1l1_l1_ 		; results = l111llll1l1_l1_.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_,name,l11l_l1_)
	elif l1l1ll11111l_l1_==15: import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==16: import l1l11lll111l_l1_	 	; results = l1l11lll111l_l1_.MAIN(l1l1ll111111_l1_,url,text,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==17: import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==18: import l1l111l111l1_l1_	; results = l1l111l111l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==19: import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==20: import l11l11l1l_l1_		; results = l11l11l1l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==21: import l11111111l1_l1_ ; results = l11111111l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==22: import l1ll1lll1l1_l1_ 	; results = l1ll1lll1l1_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==23: import IPTV 		; results = IPTV.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==24: import l111111_l1_ 		; results = l111111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==25: import l11ll1111_l1_ 	; results = l11ll1111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==26: import l1l11l1ll111_l1_ 		; results = l1l11l1ll111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1l1ll111111_l1_,context)
	elif l1l1ll11111l_l1_==28: import IPTV 		; results = IPTV.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==29: import l111l1llll1_l1_	; results = l111l1llll1_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==30: import l1ll1l1l1l_l1_		; results = l1ll1l1l1l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==31: import l1111l1l1l1_l1_	; results = l1111l1l1l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==32: import l1l11l1lll1_l1_	; results = l1l11l1lll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==33: import l11l111l11_l1_		; results = l11l111l11_l1_.MAIN(l1l1ll111111_l1_,url)
	elif l1l1ll11111l_l1_==34: import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==35: import l1l1l111_l1_		; results = l1l1l111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==36: import l1ll11111111_l1_		; results = l1ll11111111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==37: import l111l11l1_l1_		; results = l111l11l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==38: import l1l1l1lll11l_l1_ 		; results = l1l1l1lll11l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==39: import l1l1llllll1_l1_	; results = l1l1llllll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==40: import l11lll1l11_l1_	; results = l11lll1l11_l1_.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11111l_l1_==41: import l11lll1l11_l1_	; results = l11lll1l11_l1_.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_)
	elif l1l1ll11111l_l1_==42: import l1111l11l_l1_		; results = l1111l11l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==43: import l1ll1ll111l_l1_		; results = l1ll1ll111l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==44: import l1ll1ll11l1_l1_		; results = l1ll1ll11l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==45: import l11l11ll1l1_l1_		; results = l11l11ll1l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==46: import l1lll111ll1l_l1_		; results = l1lll111ll1l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==47: import l1ll1l1lll_l1_	; results = l1ll1l1lll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==48: import l1l11ll11111_l1_		; results = l1l11ll11111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==49: import l1lll111ll_l1_		; results = l1lll111ll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==50: import l11ll1lll11_l1_ 	; results = l11ll1lll11_l1_.MAIN(l1l1ll111111_l1_,text)
	elif l1l1ll11111l_l1_==51: import l1ll1l11111_l1_ 	; results = l1ll1l11111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==52: import l1ll1l11111_l1_ 	; results = l1ll1l11111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==53: import l1l11l1ll111_l1_ 		; results = l1l11l1ll111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==54: import l1ll1l1111l_l1_	; results = l1ll1l1111l_l1_.MAIN(l1l1ll111111_l1_,url,text,l1l11l1_l1_)
	elif l1l1ll11111l_l1_==55: import l1llll1111_l1_ 	; results = l1llll1111_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==56: import l1l1l111lll1_l1_		; results = l1l1l111lll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==57: import l1l1lllll11_l1_		; results = l1l1lllll11_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==58: import l111ll1lll1_l1_	; results = l111ll1lll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==59: import l1l1lll1ll1_l1_		; results = l1l1lll1ll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==60: import l1l1lll11l1_l1_		; results = l1l1lll11l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==61: import l1ll1ll_l1_		; results = l1ll1ll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==62: import l1ll111111l_l1_		; results = l1ll111111l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==63: import l1lll1l11l_l1_		; results = l1lll1l11l_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==64: import l1lll1ll1lll_l1_		; results = l1lll1ll1lll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==65: import l1111l1ll_l1_		; results = l1111l1ll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==66: import l111lllllll_l1_		; results = l111lllllll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==67: import l1l11l11ll1_l1_		; results = l1l11l11ll1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==68: import l111ll1lll_l1_		; results = l111ll1lll_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==69: import l1111l1l1_l1_		; results = l1111l1l1_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==70: import l1l111l1l1l_l1_		; results = l1l111l1l1l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==71: import M3U			; results = M3U.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==72: import M3U			; results = M3U.MAIN(l1l1ll111111_l1_,url,text,type,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==73: import l1l1l1l11_l1_	; results = l1l1l1l11_l1_.MAIN(l1l1ll111111_l1_,url,text)
	elif l1l1ll11111l_l1_==74: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1l1ll111111_l1_)
	elif l1l1ll11111l_l1_==75: import l1l1l1llll_l1_		; results = l1l1l1llll_l1_.MAIN(l1l1ll111111_l1_)
	elif l1l1ll11111l_l1_==76: import l1l11lll111l_l1_	 	; results = l1l11lll111l_l1_.MAIN(l1l1ll111111_l1_,url,text,l1l11l1_l1_,l1ll111l111_l1_)
	elif l1l1ll11111l_l1_==77: import l1lllll111l_l1_ 	; results = l1lllll111l_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==78: import l1lll1ll1ll_l1_ 	; results = l1lll1ll1ll_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==79: import l1lll1l111l_l1_ 	; results = l1lll1l111l_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==80: import l1lll11llll_l1_ 	; results = l1lll11llll_l1_.MAIN(l1l1ll111111_l1_,url,l1l11l1_l1_,text)
	elif l1l1ll11111l_l1_==81: import l1l11l1ll1l_l1_ 	; results = l1l11l1ll1l_l1_.MAIN(l1l1ll111111_l1_,url,text)
	else: results = None
	return results
def l11l1l1l1l_l1_(name=l11lll_l1_ (u"࠭ࠧ㱦")):
	if not name: name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ㱧"))
	name = name.replace(l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㱨"),l11lll_l1_ (u"ࠩࠪ㱩"))
	name = name.replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ㱪"),l11lll_l1_ (u"ࠫࠥ࠭㱫")).replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㱬"),l11lll_l1_ (u"࠭ࠠࠨ㱭")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ㱮"),l11lll_l1_ (u"ࠨࠢࠪ㱯")).strip(l11lll_l1_ (u"ࠩࠣࠫ㱰"))
	name = name.replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㱱"),l11lll_l1_ (u"ࠫࠬ㱲")).replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㱳"),l11lll_l1_ (u"࠭ࠧ㱴"))
	tmp = re.findall(l11lll_l1_ (u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࠫ㱵"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11lll_l1_ (u"ࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫ㱶")
	return name
def l1ll1l11ll11_l1_(code,reason,source,l1ll_l1_):
	l1ll1llll1ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㱷"))
	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㱸"),l11lll_l1_ (u"ࠫࠬ㱹"))
	if l11lll_l1_ (u"ࠬ࠳ࠧ㱺") in source: l1l1l1ll1ll_l1_ = source.split(l11lll_l1_ (u"࠭࠭ࠨ㱻"),1)[0]
	else: l1l1l1ll1ll_l1_ = source
	l1111llll1l_l1_ = code in [7,11001,11002,10054]
	l1l1111lll1l_l1_ = reason.lower()
	l1ll11lll1ll_l1_ = code in [0,104,10061,111]
	l1ll11lll1l1_l1_ = l11lll_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ㱼") in l1l1111lll1l_l1_
	l1ll11lll11l_l1_ = l11lll_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨ㱽") in l1l1111lll1l_l1_
	l1ll11lll111_l1_ = l11lll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㱾") in l1l1111lll1l_l1_
	l1ll11ll1lll_l1_ = l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬ㱿") in l1l1111lll1l_l1_
	l1l11lll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㲀"))
	l1l11l1l1l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㲁"))
	l1lll11l1ll1_l1_ = l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ㲂")
	l1l1ll11l1ll_l1_ = l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠧ㲃")+str(code)+l11lll_l1_ (u"ࠨ࠼ࠣࠫ㲄")+reason
	l1l1ll11l1ll_l1_ = l111l_l1_(l1l1ll11l1ll_l1_)
	if l1ll11lll1ll_l1_ or l1ll11lll1l1_l1_ or l1ll11lll11l_l1_ or l1ll11lll111_l1_ or l1ll11ll1lll_l1_:
		l1lll11l1ll1_l1_ += l11lll_l1_ (u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯ࠩ㲅")
	if l1111llll1l_l1_: l1lll11l1ll1_l1_ += l11lll_l1_ (u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ㲆")
	l1l1ll11l1ll_l1_ = l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㲇")+l1l1ll11l1ll_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㲈")
	if l1l11lll1lll_l1_==l11lll_l1_ (u"࠭ࡁࡔࡍࠪ㲉") or l1l11l1l1l1l_l1_==l11lll_l1_ (u"ࠧࡂࡕࡎࠫ㲊"):
		l1lll11l1ll1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํไࠡฬิ๎ิࠦร็ࠢํัฬ๎ไࠡษ็ฬึ์วๆฮࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠣร࡛ࠦࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㲋")
	l11l1111l1l_l1_ = False
	if l1ll_l1_ and source not in l1llllll1ll1_l1_:
		if l1l11lll1lll_l1_==l11lll_l1_ (u"ࠩࡄࡗࡐ࠭㲌") or l1l11l1l1l1l_l1_==l11lll_l1_ (u"ࠪࡅࡘࡑࠧ㲍"):
			#if kodi_version<19: l1l1ll11l1ll_l1_ = l1l1ll11l1ll_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㲎"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㲏"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ㲐"),l11lll_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠥษ่ࠡะฺวࠬ㲑"),l11lll_l1_ (u"ࠨวุ่ฬำࠠศๆุ่่๊ษࠨ㲒"),l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㲓")+TRANSLATE(l1l1l1ll1ll_l1_),l1lll11l1ll1_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㲔")+l1l1ll11l1ll_l1_)
			if choice==1:
				import l11ll1lll11_l1_
				l11ll1lll11_l1_.l1l1ll1l1l1l_l1_()
			elif choice==2: l11l1111l1l_l1_ = True
		else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㲕"),l11lll_l1_ (u"ࠬ࠭㲖"),l1l1l1ll1ll_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㲗")+TRANSLATE(l1l1l1ll1ll_l1_),l1lll11l1ll1_l1_,l1l1ll11l1ll_l1_)
	#if reason.endswith(l11lll_l1_ (u"ࠧࠡࠫࠪ㲘")): reason = reason.rsplit(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㲙"))[0]
	#if l11l1111l1l_l1_: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㲚"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ㲛")+str(code)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭㲜")+reason+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ㲝")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡆࡘࡁࡃࡋࡆ࠾ࠥࡡࠠࠨ㲞")+l1lll11l1ll1_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࡠࠤࠥࠦࡅࡏࡉࡏࡍࡘࡎ࠺ࠡ࡝ࠣࠫ㲟")+l1l1ll11l1ll_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ㲠"))
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㲡"),l1ll1llll1ll_l1_)
	return l11l1111l1l_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡩࡴࡳࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠶ࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠵ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠴࠼ࠐࠎࠎࠏࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠ࠾๊ࠢࠪํ฿ࠠๆ่ࠣห้ำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่࠴ࠧࠎࠌࠌࠍ࡮࡬ࠠࡴࡪࡲࡻࡉ࡯ࡡ࡭ࡱࡪࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠠࠬ࠿ࠣࠫࠥํไࠡฬิ๎ิࠦสโษุ๎้ࠦวไอิࠤฤ࠭ࠍࠋࠋࠌ࡭࡫ࠦࡤ࡯ࡵ࠽ࠑࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿้ࠣࠫี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤ࠰ࡃࠠࠨ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡨࡰࡸ࡫࠺ࠡ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃࠡ࠿ࠣࠫ์ึวࠡษ็้ํู่ࠡใํ๋ࠥ࠭ࠫࡣ࡮ࡲࡧࡰࡥ࡭ࡦࡧࡶࡷࡦ࡭ࡥࠎࠌࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ࠲ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧࠬࡵࡲࡹࡷࡩࡥࠬࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ࠮ࡷࡹࡸࠨࡤࡱࡧࡩ࠮࠱ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩ࠮ࡶࡪࡧࡳࡰࡰ࠮ࠫࠥࡣࠠࠡࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠼ࠣ࡟ࠥ࠭ࠫ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠫࠨࠢࡠࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠻ࠢ࡞ࠤࠬ࠱࡭ࡦࡵࡶࡥ࡬࡫ࡅࡏࡉࡏࡍࡘࡎࠫࠨࠢࡠࠫ࠮ࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠑࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸࠧ࠭ࡵ࡬ࡸࡪ࠱ࠧࠡࠢࠣࠫ࠰࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅࠩࡵ࡬ࡸࡪ࠯ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠳࠽ࠤ࡮ࡳࡰࡰࡴࡷࠤࡘࡋࡒࡗࡋࡆࡉࡘࠦ࠻ࠡࡕࡈࡖ࡛ࡏࡃࡆࡕ࠱ࡑࡆࡏࡎࠩ࠳࠼࠹࠮ࠓࠊࠊࡧ࡯࡭࡫ࠦࡳࡩࡱࡺࡈ࡮ࡧ࡬ࡰࡩࡶ࠾ࠒࠐࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳ࠢࡀࠤࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆ࠯ࠬࠦ࠮้ࠡ็ࠤฯื๊ะ่ࠢ฽ึ็ษࠡษ็วุฮวษ๋ࠢห้ำไ้ๆࠣรࠬࠓࠊࠊࠋࡼࡩࡸࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠ࡛ࡈࡗࡓࡕࠨࠨࡥࡨࡲࡹ࡫ࡲࠨ࠮ࡶ࡭ࡹ࡫ࠫࠨࠢࠣࠤࠬ࠱ࡔࡓࡃࡑࡗࡑࡇࡔࡆࠪࡶ࡭ࡹ࡫ࠩ࠭࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠳࠮ࡰࡩࡸࡹࡡࡨࡧࡈࡒࡌࡒࡉࡔࡊ࠯ࠫࠬ࠲ࠧไๆสࠫ࠱࠭ๆฺ็ࠪ࠭ࠒࠐࠉࠊ࡫ࡩࠤࡾ࡫ࡳ࠾࠿࠴࠾ࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣࡁࠥ࠭โะࠢํ็ํ์่่ࠠส็ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฾์ฯไࠩࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦวๅว้ฮึ์สࠡ฻้ำ่ࠦๅโื๋่ฮ࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้ืศุࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥเ๊า่ࠢฮํ็ัࠡษ็ฦ๋࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ื่ࠠา๊ࠤฬ๊ีโฯฬࠤํอไๆสิ้ัࠦไศࠢํ฽้๋ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳࡢ࡮ࠨ࠭ࠪะึฮࠠๆีะࠤฬ๊ใศึ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊าࠩࠨࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥาัษฺࠢี็ࠦัโ฻ࠣห้ำฬษ้ࠢࠫะ๊วࠡࡘࡓࡒࠥ࠲ࠠࡑࡴࡲࡼࡾࠦࠬࠡࡆࡑࡗ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠๆหࠤ์ึวࠡษ็้ํู่ࠡๆสั็อࠧࠎࠌࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤ࡚ࡅ࡙ࡖ࡙ࡍࡊ࡝ࡅࡓࠪࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ࠲࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠩࠎࠌࠌࠦࠧࠨ㲢")
def l111l11ll11_l1_(l1l11l1l1l11_l1_=False):
	l1lll11lll11_l1_ = [l11lll1111l_l1_,favoritesfile,l1l1111l11l1_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l11l1l1l11_l1_ and (filename.startswith(l11lll_l1_ (u"ࠫ࡮ࡶࡴࡷࠩ㲣")) or filename.startswith(l11lll_l1_ (u"ࠬࡳ࠳ࡶࠩ㲤"))): continue
		if filename.startswith(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬ㲥")): continue
		l1ll1l1l11l1_l1_ = os.path.join(addoncachefolder,filename)
		if l1ll1l1l11l1_l1_ in l1lll11lll11_l1_: continue
		try: os.remove(l1ll1l1l11l1_l1_)
		except: pass
	time.sleep(1)
	return
def l1ll1111lll1_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l111_l1_=True,l1l1lll11111_l1_=True):
	l1l1l111l11l_l1_,l1ll111l1111_l1_ = proxy.split(l11lll_l1_ (u"ࠧ࠻ࠩ㲦"))
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨ็ื็้ฯࠠฦ่อี๋๐สࠡ࠰ࠣืศำว้ๆࠣษฺ๊วฮ้สࠫ㲧"),l11lll_l1_ (u"ࠩึวัืศࠡࠩ㲨")+name,time=2000)
	#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㲩"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭ࠠࠨ㲪")+name+l11lll_l1_ (u"ࠬࠦࡳࡦࡴࡹࡩࡷࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㲫")+proxy+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㲬")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㲭"))
	url = url+l11lll_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㲮")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l111_l1_,l1l1lll11111_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㲯"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࠧ㲰")+name+l11lll_l1_ (u"ࠫࠥࡹࡥࡳࡸࡨࡶࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ㲱")+proxy+l11lll_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㲲")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㲳"))
		l1lll1111lll_l1_(l11lll_l1_ (u"ࠧࡉࡖࡗࡔࠥࡘࡥࡲࡷࡨࡷࡹࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧ㲴"))
	#else: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㲵"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㲶")+proxy+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㲷")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㲸"))
	return response
def l1l11l1ll11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㲹"),url,l11lll_l1_ (u"࠭ࠧ㲺"),l11lll_l1_ (u"ࠧࠨ㲻"),True,l11lll_l1_ (u"ࠨࠩ㲼"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㲽"),True,False)
	l1llll1l111l_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l111111_l1_
		l1l1ll1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠤ࠭࠴ࠪࡀࠫࠣࡠࡩࢁ࠱࠭࠵ࢀࡱࡸ࠭㲾"),html)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ㲿"),str(l1l1ll1l1ll1_l1_))
		if l1l1ll1l1ll1_l1_: html = l11lll_l1_ (u"ࠬࡢ࡮ࠨ㳀").join(l1l1ll1l1ll1_l1_)
		proxies = html.replace(l11lll_l1_ (u"࠭࡜ࡳࠩ㳁"),l11lll_l1_ (u"ࠧࠨ㳂")).strip(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㳃")).split(l11lll_l1_ (u"ࠩ࡟ࡲࠬ㳄"))
		l1llll1l111l_l1_ = []
		for proxy in proxies:
			if proxy.count(l11lll_l1_ (u"ࠪ࠲ࠬ㳅"))==3: l1llll1l111l_l1_.append(proxy)
	return l1llll1l111l_l1_
def l111ll1l11l_l1_(*args):
	#l1l1lll1l11l_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠹࠻࠮࠴࠵࠱࠵࠼࠴࠱࠳࠹࠲ࡥࡵ࡯࠯ࡱࡴࡲࡼࡾࡅࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡶࡴࡪ࡫ࡤ࠾࠳࠳ࠪࡱࡧࡳࡵࡡࡦ࡬ࡪࡩ࡫࠾࠳࠳ࠪ࡭ࡺࡴࡱࡵࡀࡸࡷࡻࡥࠧࡲࡲࡷࡹࡃࡴࡳࡷࡨࠪ࡫ࡵࡲ࡮ࡣࡷࡁࡹࡾࡴࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ㳆")
	l11l111ll11_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡴࡷࡵࡸࡺࡵࡦࡶࡦࡶࡥ࠯ࡥࡲࡱ࠴ࡼ࠲࠰ࡁࡵࡩࡶࡻࡥࡴࡶࡀࡨ࡮ࡹࡰ࡭ࡣࡼࡴࡷࡵࡸࡪࡧࡶࠪࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱࠲࠳࠴ࠫࡹࡳ࡭࠿ࡼࡩࡸࠬ࡬ࡪ࡯࡬ࡸࡂ࠷࠰ࠧࡥࡲࡹࡳࡺࡲࡺ࠿ࡑࡐ࠱ࡈࡅ࠭ࡆࡈ࠰ࡋࡘࠬࡈࡄ࠯ࡘࡗ࠭㳇")
	l1ll1l11111l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸ࡯ࡰࡵࡷࡩࡷࡱࡩࡥ࠱ࡲࡴࡪࡴࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡰࡥ࡮ࡴ࠯ࡉࡖࡗࡔࡘ࠴ࡴࡹࡶࠪ㳈")
	#l1llll1l11l1_l1_ = l1l11l1ll11l_l1_(l1l1lll1l11l_l1_)
	l1llll1l11l1_l1_ = l1l11l1ll11l_l1_(l1ll1l11111l_l1_)
	l1llll1l111l_l1_ = l1l11l1ll11l_l1_(l11l111ll11_l1_)
	l11l11ll1ll_l1_ = l1llll1l11l1_l1_+l1llll1l111l_l1_
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㳉"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧ㳊")+str(len(l1llll1l11l1_l1_))+l11lll_l1_ (u"ࠩ࠮ࠫ㳋")+str(len(l1llll1l111l_l1_))+l11lll_l1_ (u"ࠪࠤࡢ࠭㳌"))
	proxy = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㳍"))
	response = l1l1111l1ll_l1_()
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ㳎"),l11lll_l1_ (u"࠭ࠧ㳏"))
	if proxy or l11l11ll1ll_l1_:
		id,l1111111l1l_l1_ = 0,10
		l1l11lll1111_l1_ = len(l11l11ll1ll_l1_)
		l1lllllllll1_l1_ = l1111111l1l_l1_
		if l1l11lll1111_l1_>l1lllllllll1_l1_: counts = l1lllllllll1_l1_
		else: counts = l1l11lll1111_l1_
		l1111ll1ll1_l1_ = random.sample(l11l11ll1ll_l1_,counts)
		if proxy: l1111ll1ll1_l1_ = [proxy]+l1111ll1ll1_l1_
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㳐"),str(l1111ll1ll1_l1_))
		threads = l11111lllll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1111111l1l_l1_ and not threads.l1111ll11l1_l1_:
			if id<counts:
				proxy = l1111ll1ll1_l1_[id]
				threads.start_new_thread(id,l1ll1111lll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㳑"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㳒")+proxy+l11lll_l1_ (u"ࠪࠤࡢ࠭㳓"))
		l1111ll11l1_l1_ = threads.l1111ll11l1_l1_
		if l1111ll11l1_l1_:
			l1ll1l1l11ll_l1_ = threads.l1ll1l1l11ll_l1_
			l1lll1111111_l1_ = l1111ll11l1_l1_[0]
			response = l1ll1l1l11ll_l1_[l1lll1111111_l1_]
			proxy = l1111ll1ll1_l1_[int(l1lll1111111_l1_)]
			settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ㳔"),proxy)
			if l1lll1111111_l1_!=0: LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ㳕"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡐࡳࡱࡻࡽ࠿࡛ࠦࠡࠩ㳖")+proxy+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㳗"))
			else: LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㳘"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ㳙")+proxy+l11lll_l1_ (u"ࠪࠤࡢ࠭㳚"))
		#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㳛"),l11lll_l1_ (u"ࠬࡶࡲࡰࡺ࡬ࡩࡸࡒࡉࡔࡖ࠵ࠤ࠿ࡀࠠࠨ㳜")+str(l1111ll1ll1_l1_))
		#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㳝"),l11lll_l1_ (u"ࠧࡱࡴࡲࡼ࡮࡫ࡳࡍࡋࡖࡘࠥࡀ࠺ࠡࠩ㳞")+str(l11l11ll1ll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㳟"),l11lll_l1_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㳠")+str(threads.l1111ll11l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㳡"),l11lll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ㳢")+str(threads.l11l1l11l1l_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㳣"),l11lll_l1_ (u"࠭ࡲࡦࡵࡸࡰࡹࡹࡄࡊࡅࡗࠤ࠿ࡀࠠࠨ㳤")+str(threads.l1ll1l1l11ll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㳥"),l11lll_l1_ (u"ࠨࡧ࡯ࡴࡦࡹࡥࡥࡶ࡬ࡱࡪࡊࡉࡄࡖࠣ࠾࠿ࠦࠧ㳦")+str(threads.l11l111l1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㳧"),l11lll_l1_ (u"ࠪࡷࡴࡸࡴࡦࡦࡏࡍࡘ࡚ࠠ࠻࠼ࠣࠫ㳨")+str(l1lll11l11ll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㳩"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ㳪")+l1l11ll11lll_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ㳫")+str(l1lll11l11ll_l1_))
	return response
def l1l111lllll1_l1_(connection,l1l111l11lll_l1_):
	l11111l1lll_l1_ = connection.create_connection
	def l1l1l11ll11l_l1_(address,*args,**kwargs):
		host,port = address
		l1l1ll11l1l1_l1_ = DNS_RESOLVER(host,l1l111l11lll_l1_)
		if l1l1ll11l1l1_l1_: host = l1l1ll11l1l1_l1_[0]
		else:
			if l1l111l11lll_l1_ in l1lll1l11111_l1_: l1lll1l11111_l1_.remove(l1l111l11lll_l1_)
			if l1lll1l11111_l1_:
				l1llllll11l1_l1_ = l1lll1l11111_l1_[0]
				#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㳬"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࡛ࠡࠢࠣ࡮ࡲ࡬ࠡࡶࡵࡽࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡆࡑࡗ࠿ࡡࠠࠨ㳭")+l1llllll11l1_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡱࡶࡸ࠿ࡡࠠࠨ㳮")+str(host)+l11lll_l1_ (u"ࠪࠤࡢ࠭㳯"))
				l1l1ll11l1l1_l1_ = DNS_RESOLVER(host,l1llllll11l1_l1_)
				if l1l1ll11l1l1_l1_: host = l1l1ll11l1l1_l1_[0]
		address = (host,port)
		return l11111l1lll_l1_(address,*args,**kwargs)
	connection.create_connection = l1l1l11ll11l_l1_
	return l11111l1lll_l1_
def l1ll1l11l1_l1_(l11lll1lll1_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡸࡺࡲࠨ㳰"),l11lll_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭㳱"),(method,url,data,headers))
	if html:
		l11llll1111_l1_(l11lll_l1_ (u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫ㳲"),url,data,headers,source,method)
		return html
	html = l1lllll111_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ㳳"),(method,url,data,headers),html,l11lll1lll1_l1_)
	return html
def l1l111l11111_l1_(url):
	l111l111lll_l1_,l111l1l1ll1_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ㳴"))[2],80
	if l11lll_l1_ (u"ࠩ࠽ࠫ㳵") in l111l111lll_l1_: l111l111lll_l1_,l111l1l1ll1_l1_ = l111l111lll_l1_.split(l11lll_l1_ (u"ࠪ࠾ࠬ㳶"))
	l111111ll1l_l1_ = l11lll_l1_ (u"ࠫ࠴࠭㳷")+l11lll_l1_ (u"ࠬ࠵ࠧ㳸").join(url.split(l11lll_l1_ (u"࠭࠯ࠨ㳹"))[3:])
	request = l11lll_l1_ (u"ࠧࡈࡇࡗࠤࠬ㳺")+l111111ll1l_l1_+l11lll_l1_ (u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨ㳻")
	#request += l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡀࠠ࡝ࡴ࡟ࡲࠬ㳼")
	request += l11lll_l1_ (u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ㳽")+l111l111lll_l1_+l11lll_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ㳾")
	request += l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ㳿")
	import socket
	try:
		client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		client.connect((l111l111lll_l1_,l111l1l1ll1_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11lll_l1_ (u"࠭ࠧ㴀")
	return html
def SERVER(link,type):
	# url:	http://www.l1llll1ll1l1_l1_.com
	# host:	www.l1llll1ll1l1_l1_.com
	# name:	l1llll1ll1l1_l1_
	#server = l11lll_l1_ (u"ࠧ࠰ࠩ㴁").join(link.split(l11lll_l1_ (u"ࠨ࠱ࠪ㴂"))[:3])
	if l11lll_l1_ (u"ࠩ࠱ࠫ㴃") not in link: return link
	link = link+l11lll_l1_ (u"ࠪ࠳ࠬ㴄")
	l1l1l1l11ll1_l1_,l1l1l1l11l1l_l1_ = link.split(l11lll_l1_ (u"ࠫ࠳࠭㴅"),1)
	l1l1l1l11l11_l1_,l1l1l1l111ll_l1_ = l1l1l1l11l1l_l1_.split(l11lll_l1_ (u"ࠬ࠵ࠧ㴆"),1)
	server = l1l1l1l11ll1_l1_+l11lll_l1_ (u"࠭࠮ࠨ㴇")+l1l1l1l11l11_l1_
	if type in [l11lll_l1_ (u"ࠧࡩࡱࡶࡸࠬ㴈"),l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㴉")] and l11lll_l1_ (u"ࠩ࠲ࠫ㴊") in server: server = server.rsplit(l11lll_l1_ (u"ࠪ࠳ࠬ㴋"),1)[1]
	if type==l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㴌") and l11lll_l1_ (u"ࠬ࠴ࠧ㴍") in server:
		l1l1lll1l1ll_l1_ = server.split(l11lll_l1_ (u"࠭࠮ࠨ㴎"))
		length = len(l1l1lll1l1ll_l1_)
		if length<=2 or l11lll_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ㴏") in server: l1l1lll1l1ll_l1_ = l1l1lll1l1ll_l1_[0]
		elif length>=3: l1l1lll1l1ll_l1_ = l1l1lll1l1ll_l1_[1]
		if len(l1l1lll1l1ll_l1_)>1: server = l1l1lll1l1ll_l1_
	return server
	l11lll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࠧ࠰ࠩ࠮ࡹࡷࡲ࠲ࠬࠩ࠲ࠫࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡰࡨࡸ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡵ࡫࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡺࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡷࡺ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡹࡶ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡵࡱ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡭ࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡷࡻ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡦࡳ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡸࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤ࡮ࡸࡦ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡮࡬ࡪࡪ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡰࡼ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡫ࡱ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯ࡸࡹࡺ࠲ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠯࡮࠰ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡫࡭ࡣࡧࡧ࠲ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࠢࠣࠤ㴐")
def l1l11lll11l1_l1_(l1111l1111l_l1_):
	l1111l111l1_l1_ = repr(l1111l1111l_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㴑"))).replace(l11lll_l1_ (u"ࠥࠫࠧ㴒"),l11lll_l1_ (u"ࠫࠬ㴓"))
	return l1111l111l1_l1_
def l1l111lll1l_l1_(string):
	#if l11lll_l1_ (u"ࠬࡢࡵࠨ㴔") in string:
	#	string = string.decode(l11lll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㴕"))
	#	l1ll1ll111l1_l1_=re.findall(l11lll_l1_ (u"ࡲࠨ࡞ࡸ࡟࠵࠳࠹ࡂ࠯ࡉࡡࠬ㴖"),string)
	#	for unicode in l1ll1ll111l1_l1_
	#		char = l1l11111l1l1_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㴗"))
	l1l11l111111_l1_ = l11lll_l1_ (u"ࠩࠪ㴘")
	if kodi_version<19: string = string.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㴙"))
	import unicodedata
	for l1l111ll1ll_l1_ in string:
		if   l1l111ll1ll_l1_==l11lll_l1_ (u"ࡹࠬศࠧ㴚"): l111111l11l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭㴛")
		elif l1l111ll1ll_l1_==l11lll_l1_ (u"ࡻࠧฤࠩ㴜"): l111111l11l_l1_ = l11lll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨ㴝")
		elif l1l111ll1ll_l1_==l11lll_l1_ (u"ࡶࠩวࠫ㴞"): l111111l11l_l1_ = l11lll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪ㴟")
		elif l1l111ll1ll_l1_==l11lll_l1_ (u"ࡸࠫส࠭㴠"): l111111l11l_l1_ = l11lll_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬ㴡")
		elif l1l111ll1ll_l1_==l11lll_l1_ (u"ࡺ࠭ฦࠨ㴢"): l111111l11l_l1_ = l11lll_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧ㴣")
		else:
			l1l111111ll1_l1_ = unicodedata.decomposition(l1l111ll1ll_l1_)
			if l11lll_l1_ (u"ࠧࠡࠩ㴤") in l1l111111ll1_l1_: l111111l11l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹࠬ㴥")+l1l111111ll1_l1_.split(l11lll_l1_ (u"ࠩࠣࠫ㴦"),1)[1]
			else:
				l111111l11l_l1_ = l11lll_l1_ (u"ࠪ࠴࠵࠶࠰ࠨ㴧")+hex(ord(l1l111ll1ll_l1_)).replace(l11lll_l1_ (u"ࠫ࠵ࡾࠧ㴨"),l11lll_l1_ (u"ࠬ࠭㴩"))
				l111111l11l_l1_ = l11lll_l1_ (u"࠭࡜࡝ࡷࠪ㴪")+l111111l11l_l1_[-4:]
			#if ord(l1l111ll1ll_l1_)<256: l111111l11l_l1_ = l11lll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠵࠭㴫")+l1l1l1l1l1ll_l1_
			#elif ord(l1l111ll1ll_l1_)<4096: l111111l11l_l1_ = l11lll_l1_ (u"ࠨ࡞࡟ࡹ࠵࠭㴬")+l1l1l1l1l1ll_l1_
			#elif l11lll_l1_ (u"ࠩࠣࠫ㴭") in l1l111111ll1_l1_: l111111l11l_l1_ = l11lll_l1_ (u"ࠪࡠࡡࡻࠧ㴮")+l1l111111ll1_l1_.split(l11lll_l1_ (u"ࠫࠥ࠭㴯"),1)[1]
			#else: l111111l11l_l1_ = l11lll_l1_ (u"ࠬࡢ࡜ࡶࠩ㴰")+l1l1l1l1l1ll_l1_
		l1l11l111111_l1_ += l111111l11l_l1_
	l1l11l111111_l1_ = l1l11l111111_l1_.replace(l11lll_l1_ (u"࠭࡜࡝ࡷ࠳࠺ࡈࡉࠧ㴱"),l11lll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠺࠹ࠨ㴲"))
	if kodi_version<19: l1l11l111111_l1_ = l1l11l111111_l1_.decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㴳")).encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㴴"))
	else: l1l11l111111_l1_ = l1l11l111111_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㴵")).decode(l11lll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㴶"))
	return l1l11l111111_l1_
def OPEN_KEYBOARD(header=l11lll_l1_ (u"๊่ࠬฮหࠣห้๋แศฬํัࠬ㴷"),default=l11lll_l1_ (u"࠭ࠧ㴸"),l1llllllll11_l1_=False,source=l11lll_l1_ (u"ࠧࠨ㴹")):
	text = l111l1ll111_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11lll_l1_ (u"ࠨࠢࠣࠫ㴺"),l11lll_l1_ (u"ࠩࠣࠫ㴻")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭㴼"),l11lll_l1_ (u"ࠫࠥ࠭㴽")).replace(l11lll_l1_ (u"ࠬࠦࠠࠨ㴾"),l11lll_l1_ (u"࠭ࠠࠨ㴿"))
	if not text and not l1llllllll11_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㵀"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ㵁")+text+l11lll_l1_ (u"ࠩࠥࠫ㵂"))
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㵃"),l11lll_l1_ (u"ࠫࠬ㵄"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㵅"),l11lll_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩ㵆"))
		return l11lll_l1_ (u"ࠧࠨ㵇")
	if text not in [l11lll_l1_ (u"ࠨࠩ㵈"),l11lll_l1_ (u"ࠩࠣࠫ㵉")]:
		text = text.strip(l11lll_l1_ (u"ࠪࠤࠬ㵊"))
		text = l1l111lll1l_l1_(text)
	if source!=l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭㵋") and l11ll11_l1_(l11lll_l1_ (u"ࠬࡑࡅ࡚ࡄࡒࡅࡗࡊࠧ㵌"),l11lll_l1_ (u"࠭ࠧ㵍"),[text],False):
		LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㵎"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ㵏")+text+l11lll_l1_ (u"ࠩࠥࠫ㵐"))
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㵑"),l11lll_l1_ (u"ࠫࠬ㵒"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㵓"),l11lll_l1_ (u"࠭ว็ฬࠣ็ฯฮสࠡๅ็้ฮࠦร้ࠢิๆ๊ࠦไ่ࠢ฼่ฬ่ษࠡสฦๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠥ࠴࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏ูๅฮࠢหหุะฮะษ่ࠤ์้ะศࠢๆ่๊อสࠨ㵔"))
		return l11lll_l1_ (u"ࠧࠨ㵕")
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㵖"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ㵗")+text+l11lll_l1_ (u"ࠪࠦࠬ㵘"))
	return text
def l11ll11l11_l1_(l11l11l_l1_,headers={}):
	#if headers[l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㵙")]==l11lll_l1_ (u"ࠬ࠭㵚"): headers[l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㵛")] = l11lll_l1_ (u"ࠧࠡࠩ㵜")
	#l1ll1ll1l111_l1_ = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㵝") : l11lll_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠷࠶࠰࠳࠲࠸࠽࠷࠱࠰࠴࠸࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭㵞") }
	#url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡪ࠸࠵࠰ࡰࡽࡨࡪ࡮࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠱ࡱ࠸ࡻ࠸ࠨ㵟")
	#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝ࡶࡨࡷࡹ࠸࠮࡮࠵ࡸ࠼ࠬ㵠"), l11lll_l1_ (u"ࠬࡸࠧ㵡")).read()
	url,params = l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㵢")
	if l11lll_l1_ (u"ࠧࡽࠩ㵣") in l11l11l_l1_:
		url,params = l11l11l_l1_.split(l11lll_l1_ (u"ࠨࡾࠪ㵤"),1)
		if l11lll_l1_ (u"ࠩࡀࠫ㵥") not in params: url,params = l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㵦")
	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㵧"),url,l11lll_l1_ (u"ࠬ࠭㵨"),headers,l11lll_l1_ (u"࠭ࠧ㵩"),l11lll_l1_ (u"ࠧࠨ㵪"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ㵫"),False,False)
	html = response.content
	if l11lll_l1_ (u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭㵬") not in html: return [l11lll_l1_ (u"ࠪ࠱࠶࠭㵭")],[l11l11l_l1_]
	#	if l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㵮") in list(headers.keys()): del headers[l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㵯")]
	#	else: headers[l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㵰")] = l11lll_l1_ (u"ࠧࠨ㵱")
	#	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㵲"),url,l11lll_l1_ (u"ࠩࠪ㵳"),headers,l11lll_l1_ (u"ࠪࠫ㵴"),l11lll_l1_ (u"ࠫࠬ㵵"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠸࡮ࡥࠩ㵶"),False,False)
	#	html = response.content
	if l11lll_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ㵷") in html: return [l11lll_l1_ (u"ࠧ࠮࠳ࠪ㵸")],[l11l11l_l1_]
	if l11lll_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ㵹") in html: return [l11lll_l1_ (u"ࠩ࠰࠵ࠬ㵺")],[l11l11l_l1_]
	#if l11lll_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖࠫ㵻") in html: return [l11lll_l1_ (u"ࠫ࠲࠷ࠧ㵼")],[l11l11l_l1_]
	l1lll1ll_l1_,l1111_l1_,l1llll1llll1_l1_,l1l1lll1l111_l1_ = [],[],[],[]
	lines = re.findall(l11lll_l1_ (u"ࠬࡢࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ㵽"),html+l11lll_l1_ (u"࠭࡜࡯ࠩ㵾"),re.DOTALL)
	if not lines: return [l11lll_l1_ (u"ࠧ࠮࠳ࠪ㵿")],[l11l11l_l1_]
	for line,link in lines:
		l1l111ll1l1l_l1_,l111ll11111_l1_,l11l111l_l1_ = {},-1,-1
		title = l11lll_l1_ (u"ࠨࠩ㶀")
		#hostname = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㶁"))
		#title = title+l11lll_l1_ (u"ࠪࠤࠥ࠭㶂")+hostname+l11lll_l1_ (u"ࠫࠥࠦࠧ㶃")
		#line = line.lower()
		items = line.split(l11lll_l1_ (u"ࠬ࠲ࠧ㶄"))
		for item in items:
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㶅"),l11lll_l1_ (u"ࠧࠨ㶆"),item,l11lll_l1_ (u"ࠨࠩ㶇"))
			#if l11lll_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ㶈") in item: l1l111ll1l1l_l1_[key] = value
			if l11lll_l1_ (u"ࠪࡁࠬ㶉") in item:
				key,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭㶊"),1)
				l1l111ll1l1l_l1_[key.lower()] = value
		if l11lll_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㶋") in line.lower():
			l111ll11111_l1_ = int(l1l111ll1l1l_l1_[l11lll_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㶌")])//1024
			#title += l11lll_l1_ (u"ࠧࡂࡸࡪࡆ࡜ࡀࠠࠨ㶍")+str(l111ll11111_l1_)+l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ㶎")
			title += str(l111ll11111_l1_)+l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ㶏")
		elif l11lll_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭㶐") in line.lower():
			l111ll11111_l1_ = int(l1l111ll1l1l_l1_[l11lll_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ㶑")])//1024
			#title += l11lll_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ㶒")+str(l111ll11111_l1_)+l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭㶓")
			title += str(l111ll11111_l1_)+l11lll_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㶔")
		if l11lll_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ㶕") in line.lower():
			l11l111l_l1_ = int(l1l111ll1l1l_l1_[l11lll_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭㶖")].split(l11lll_l1_ (u"ࠪࡼࠬ㶗"))[1])
			#title += l11lll_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ㶘")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠨ㶙")
			title += str(l11l111l_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠩ㶚")
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠢࠪ㶛"))
		if not title: title = l11lll_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ㶜")
		if not link.startswith(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㶝")):
			if link.startswith(l11lll_l1_ (u"ࠪ࠳࠴࠭㶞")): link = url.split(l11lll_l1_ (u"ࠫ࠿࠭㶟"),1)[0]+l11lll_l1_ (u"ࠬࡀࠧ㶠")+link
			elif link.startswith(l11lll_l1_ (u"࠭࠯ࠨ㶡")): link = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ㶢"))+link
			else: link = url.rsplit(l11lll_l1_ (u"ࠨ࠱ࠪ㶣"),1)[0]+l11lll_l1_ (u"ࠩ࠲ࠫ㶤")+link
		if params!=l11lll_l1_ (u"ࠪࠫ㶥"): link = link+l11lll_l1_ (u"ࠫࢁ࠭㶦")+params
		if l11lll_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ㶧") in list(l1l111ll1l1l_l1_.keys()):
			l1lllllll1_l1_ = l1l111ll1l1l_l1_[l11lll_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ㶨")]
			l1lllllll1_l1_ = l1lllllll1_l1_.replace(l11lll_l1_ (u"ࠧࠣࠩ㶩"),l11lll_l1_ (u"ࠨࠩ㶪")).replace(l11lll_l1_ (u"ࠤࠪࠦ㶫"),l11lll_l1_ (u"ࠪࠫ㶬")).split(l11lll_l1_ (u"ࠫࠨ࠭㶭"),1)[0]
			l111lll11l_l1_ = l11l1ll1ll_l1_(l1lllllll1_l1_)
			if l111lll11l_l1_: l1lll1lll_l1_ = title+l11lll_l1_ (u"ࠬࠦࠠࠨ㶮")+l111lll11l_l1_
			else: l1lll1lll_l1_ = title
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭㶯")
			l1lll1lll_l1_ = l1lll1lll_l1_+l11lll_l1_ (u"ࠧࠡࠢࠪ㶰")+SERVER(l1lllllll1_l1_,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㶱"))
			l1lll1ll_l1_.append(l1lll1lll_l1_)
			l1111_l1_.append(l1lllllll1_l1_)
			l1llll1llll1_l1_.append(l11l111l_l1_)
			l1l1lll1l111_l1_.append(l111ll11111_l1_)
		link = link.split(l11lll_l1_ (u"ࠩࠦࠫ㶲"),1)[0]
		l111lll11l_l1_ = l11l1ll1ll_l1_(link)
		if l111lll11l_l1_: title = title+l11lll_l1_ (u"ࠪࠤࠥ࠭㶳")+l111lll11l_l1_
		title = title+l11lll_l1_ (u"ࠫࠥࠦࠧ㶴")+SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㶵"))
		l1lll1ll_l1_.append(title)
		l1111_l1_.append(link)
		l1llll1llll1_l1_.append(l11l111l_l1_)
		l1l1lll1l111_l1_.append(l111ll11111_l1_)
	zz = list(zip(l1lll1ll_l1_,l1111_l1_,l1llll1llll1_l1_,l1l1lll1l111_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1lll1ll_l1_,l1111_l1_,l1llll1llll1_l1_,l1l1lll1l111_l1_ = list(zip(*zz))
	l1lll1ll_l1_,l1111_l1_ = list(l1lll1ll_l1_),list(l1111_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭ࠧ㶶"), l1lll1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧࠨ㶷"), l1111_l1_)
	return l1lll1ll_l1_,l1111_l1_
def DNS_RESOLVER(host,l1l111l11lll_l1_=l11lll_l1_ (u"ࠨࠩ㶸")):
	if not l1l111l11lll_l1_: l1l111l11lll_l1_ = l1lll1l11111_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㶹"),l11lll_l1_ (u"ࠪࠫ㶺"),str(l1l111l11lll_l1_),str(host))
	if host.replace(l11lll_l1_ (u"ࠫ࠳࠭㶻"),l11lll_l1_ (u"ࠬ࠭㶼")).isdigit(): return [host]
	import struct,socket
	try:
		l1111l11lll_l1_ = struct.pack(l11lll_l1_ (u"ࠨ࠾ࡉࠤ㶽"), 12049)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠢ࠿ࡊࠥ㶾"), 256)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠣࡀࡋࠦ㶿"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠤࡁࡌࠧ㷀"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡂࡍࠨ㷁"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠦࡃࡎࠢ㷂"), 0)
		if kodi_version>18.99: l1ll1l11l1l1_l1_ = host.split(l11lll_l1_ (u"ࠬ࠴ࠧ㷃"))
		else: l1ll1l11l1l1_l1_ = host.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㷄")).split(l11lll_l1_ (u"ࠧ࠯ࠩ㷅"))
		for part in l1ll1l11l1l1_l1_:
			parts = part.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㷆"))
			l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠤࡅࠦ㷇"), len(part))
			for l1llll1111l1_l1_ in part:
				l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠥࡧࠧ㷈"), l1llll1111l1_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㷉")))
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠧࡈࠢ㷊"), 0)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠨ࠾ࡉࠤ㷋"), 1)
		l1111l11lll_l1_ += struct.pack(l11lll_l1_ (u"ࠢ࠿ࡊࠥ㷌"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l1111l11lll_l1_), (l1l111l11lll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l1111lll1ll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ㷍"), data, 0)
		l1lllll1ll11_l1_ = l1111lll1ll_l1_[3]
		offset = len(host)+18
		l11111lll11_l1_ = []
		for _ in range(l1lllll1ll11_l1_):
			l1llll1lll11_l1_ = offset
			l1ll111ll11l_l1_ = 1
			l1lll11l1l1l_l1_ = False
			while True:
				l1llll1111l1_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠤࡁࡆࠧ㷎"), data, l1llll1lll11_l1_)[0]
				if l1llll1111l1_l1_ == 0:
					l1llll1lll11_l1_ += 1
					break
				# l1l1l11lllll_l1_ the field l1l1l1111l11_l1_ the first l111l1111l1_l1_ bits l1l1ll111lll_l1_ to 1, l1lllllll11l_l1_ a pointer
				if l1llll1111l1_l1_ >= 192:
					l1lll1lll11l_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠥࡂࡇࠨ㷏"), data, l1llll1lll11_l1_ + 1)[0]
					# l1l111l1ll11_l1_ the pointer
					l1llll1lll11_l1_ = ((l1llll1111l1_l1_ << 8) + l1lll1lll11l_l1_ - 0xc000) - 1
					l1lll11l1l1l_l1_ = True
				l1llll1lll11_l1_ += 1
				if l1lll11l1l1l_l1_ == False: l1ll111ll11l_l1_ += 1
			if l1lll11l1l1l_l1_ == True: l1ll111ll11l_l1_ += 1
			offset = offset + l1ll111ll11l_l1_
			l11l11l1lll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠦࡃࡎࡈࡊࡊࠥ㷐"), data, offset)
			offset = offset + 10
			l111l1111ll_l1_ = l11l11l1lll_l1_[0]
			l1lll11l1lll_l1_ = l11l11l1lll_l1_[3]
			if l111l1111ll_l1_ == 1: # l11111ll11l_l1_ type
				l1llll1111ll_l1_ = struct.unpack_from(l11lll_l1_ (u"ࠧࡄࠢ㷑")+l11lll_l1_ (u"ࠨࡂࠣ㷒")*l1lll11l1lll_l1_, data, offset)
				l1l1ll11l1l1_l1_ = l11lll_l1_ (u"ࠧࠨ㷓")
				for l1llll1111l1_l1_ in l1llll1111ll_l1_: l1l1ll11l1l1_l1_ += str(l1llll1111l1_l1_) + l11lll_l1_ (u"ࠨ࠰ࠪ㷔")
				l1l1ll11l1l1_l1_ = l1l1ll11l1l1_l1_[0:-1]
				l11111lll11_l1_.append(l1l1ll11l1l1_l1_)
			if l111l1111ll_l1_ in [1,2,5,6,15,28]: offset = offset + l1lll11l1lll_l1_
	except: l11111lll11_l1_ = []
	if not l11111lll11_l1_: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㷕"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ㷖")+host+l11lll_l1_ (u"ࠫࠥࡣࠧ㷗"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㷘"),l11lll_l1_ (u"࠭ࠧ㷙"),str(host),str(l11111lll11_l1_))
	return l11111lll11_l1_
def l11ll11_l1_(script_name,url,l11ll1l_l1_,l1ll_l1_=True):
	if l11ll1l_l1_:
		l1111lll11l_l1_ = [l11lll_l1_ (u"ࠧไสสีࠬ㷚"),l11lll_l1_ (u"ࠨสส่฿࠭㷛"),l11lll_l1_ (u"ࠩࡤࡨࡺࡲࡴࠨ㷜"),l11lll_l1_ (u"ࠪࡼࡽ࠭㷝"),l11lll_l1_ (u"ࠫࡸ࡫ࡸࠨ㷞")]
		if script_name!=l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ㷟"):
			l1111lll11l_l1_ += [l11lll_l1_ (u"࠭ࡲ࠻ࠩ㷠"),l11lll_l1_ (u"ࠧࡳ࠯ࠪ㷡"),l11lll_l1_ (u"ࠨ࠯ࡰࡥࠬ㷢")]
			l1111lll11l_l1_ += [l11lll_l1_ (u"ࠩ࠽ࡶࠬ㷣"),l11lll_l1_ (u"ࠪ࠱ࡷ࠭㷤"),l11lll_l1_ (u"ࠫࡲࡧ࠭ࠨ㷥")]
		for l1ll1ll111_l1_ in l11ll1l_l1_:
			if l11lll_l1_ (u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ㷦") in l1ll1ll111_l1_: continue
			if l11lll_l1_ (u"࠭อๅไฬࠫ㷧") in l1ll1ll111_l1_: continue
			l1ll1ll111_l1_ = l1ll1ll111_l1_.lower()
			if kodi_version<19: l1ll1ll111_l1_ = l1ll1ll111_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㷨")).encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㷩"))
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㷪"),l11lll_l1_ (u"ࠪࠫ㷫"),l11lll_l1_ (u"ࠫࠬ㷬"),str(l1ll1ll111_l1_))
			#l1lllll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ㷭"),l1ll1ll111_l1_,re.DOTALL)
			#l1lllll1l111_l1_ = re.findall(l11lll_l1_ (u"࠭࡞࡝࠭ࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ㷮"),l1ll1ll111_l1_,re.DOTALL)
			#l1lllll11lll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫ࡟࠯ࠩ࠭㷯"),l1ll1ll111_l1_,re.DOTALL)
			#l11111l1l1l_l1_ = any(l1lllll11ll1_l1_,l1lllll1l111_l1_,l1lllll11lll_l1_,l1lllll11l11_l1_)
			l1ll1ll111_l1_ = l1ll1ll111_l1_.replace(l11lll_l1_ (u"ࠨ࠼ࠪ㷰"),l11lll_l1_ (u"ࠩࠪ㷱"))
			l11111l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ㷲"),l1ll1ll111_l1_,re.DOTALL)
			l1l1lll1ll11_l1_ = False
			for digits in l11111l1l1l_l1_:
				if len(digits)==2:
					l1l1lll1ll11_l1_ = True
					break
			if l11lll_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ㷳") in l1ll1ll111_l1_: continue
			elif l11lll_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭㷴") in l1ll1ll111_l1_: continue
			elif l11lll_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ㷵") in l1ll1ll111_l1_: continue
			elif l11l1llll1l_l1_(l11lll_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ㷶")): continue
			elif l1ll1ll111_l1_ in [l11lll_l1_ (u"ࠨࡴࠪ㷷")] or l1l1lll1ll11_l1_ or any(value in l1ll1ll111_l1_ for value in l1111lll11l_l1_):
				LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㷸"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㷹")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㷺"))
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㷻"),l11lll_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ㷼"))
				return True
	return False
def l1l11l11111l_l1_(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠧࠨ㷽"),l11l1l1ll11_l1_=l11lll_l1_ (u"ࠨࠩ㷾")):
	global l1l111l11ll_l1_
	import threading
	l11l1lll1ll_l1_ = threading.Thread(target=l1lllll111ll_l1_,args=(l11l1l1_l1_,l1l1ll11_l1_,l11l1l1ll11_l1_))
	l11l1lll1ll_l1_.start()
	l11l1lll1ll_l1_.join()
	return l1l111l11ll_l1_
def PLAY_VIDEO(l11l1l1_l1_,l1l1ll11_l1_=l11lll_l1_ (u"ࠩࠪ㷿"),l11l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ㸀")):
	global l1l111l11ll_l1_
	if not l11l1l1ll11_l1_: l11l1l1ll11_l1_ = l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㸁")
	l1l111l11ll_l1_,l111l11111l_l1_,httpd = l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࠰ࠨ㸂"),l11lll_l1_ (u"࠭ࠧ㸃"),l11lll_l1_ (u"ࠧࠨ㸄")
	if len(l11l1l1_l1_)==3:
		url,l1ll1111111l_l1_,httpd = l11l1l1_l1_
		if l1ll1111111l_l1_: l111l11111l_l1_ = l11lll_l1_ (u"ࠨࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀࠠ࡜ࠢࠪ㸅")+l1ll1111111l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠬ㸆")
	else: url,l1ll1111111l_l1_,httpd = l11l1l1_l1_,l11lll_l1_ (u"ࠪࠫ㸇"),l11lll_l1_ (u"ࠫࠬ㸈")
	#url = l111l_l1_(url)		# cause l1l11111ll11_l1_ for l1ll1llll_l1_ l1llll1l1_l1_ l1111llllll_l1_ l1ll11111l1l_l1_
	url = url.replace(l11lll_l1_ (u"ࠬࠫ࠲࠱ࠩ㸉"),l11lll_l1_ (u"࠭ࠠࠨ㸊"))	# needed for l1l111l1lll1_l1_
	l111lll11l_l1_ = l11l1ll1ll_l1_(url,l1l1ll11_l1_)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ㸋"),l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠭㸌")]:
		if l1l1ll11_l1_!=l11lll_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ㸍"): url = url.replace(l11lll_l1_ (u"ࠪࠤࠬ㸎"),l11lll_l1_ (u"ࠫࠪ࠸࠰ࠨ㸏"))
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㸐"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㸑")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㸒")+l111l11111l_l1_)
		if l111lll11l_l1_==l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㸓") and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㸔"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㸕")]:
			headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㸖"):l11lll_l1_ (u"ࠬ࠭㸗")}
			l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(url,headers)
			count = len(l1111_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ㸘")+str(count)+l11lll_l1_ (u"ࠧࠡ็็ๅ࠮࠭㸙"), l1lll1ll_l1_)
				if l1l_l1_ == -1:
					DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะิ฻์็ࠫ㸚"),l11lll_l1_ (u"ࠩࠪ㸛"))
					return l1l111l11ll_l1_
			else: l1l_l1_ = 0
			url = l1111_l1_[l1l_l1_]
			if l1lll1ll_l1_[0]!=l11lll_l1_ (u"ࠪ࠱࠶࠭㸜"):
				LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㸝"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ㸞")+l1lll1ll_l1_[l1l_l1_]+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㸟")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㸠"))
		#url = url+l11lll_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠶࠾࠶࠱࠲࠳࠴ࠬ㸡")
		#url = url+l11lll_l1_ (u"ࠩࡿࡈࡓ࡚࠽࠲ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࡁࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠹ࠫࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠦࡂࡥࡦࡩࡵࡺ࠽ࠫ࠱࡚࠭ࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡍ࡫ࡱࡹࡽࡁࠠࡂࡰࡧࡶࡴ࡯ࡤࠡ࠹࠱࠴ࡀࠦࡓࡎ࠯ࡊ࠼࠾࠸ࡁࠡࡄࡸ࡭ࡱࡪ࠯ࡏࡔࡇ࠽࠵ࡓ࠻ࠡࡹࡹ࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯࡙ࠪࠢࡩࡷࡹࡩࡰࡰ࠲࠸࠳࠶ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠹࠱࠴࠳࠹࠳࠺࠸࠱࠼࠼ࠦࡍࡰࡤ࡬ࡰࡪࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭㸢")
		if l11lll_l1_ (u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ㸣") in url: url = url+l11lll_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㸤")
		elif l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㸥") in url.lower() and l11lll_l1_ (u"࠭࠯ࡥࡣࡶ࡬࠴࠭㸦") not in url and l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ㸧") not in url:
			if l11lll_l1_ (u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭㸨") not in url and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ㸩") in url.lower():
				if l11lll_l1_ (u"ࠪࢀࠬ㸪") not in url: url = url+l11lll_l1_ (u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨ㸫")
				else: url = url+l11lll_l1_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ㸬")
			if l11lll_l1_ (u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ㸭") not in url.lower() and l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㸮"),l11lll_l1_ (u"ࠨࡏ࠶࡙ࠬ㸯")]:
				if l11lll_l1_ (u"ࠩࡿࠫ㸰") not in url: url = url+l11lll_l1_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ㸱")
				else: url = url+l11lll_l1_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ㸲")
		#url = url.replace(l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ㸳"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ㸴"))
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㸵"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㸶")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㸷"))
	l11l1ll111l_l1_ = xbmcgui.ListItem()
	#l11l1ll111l_l1_ = xbmcgui.ListItem(l11lll_l1_ (u"ࠪࡸࡪࡹࡴࠨ㸸"))
	l11l1l1ll11_l1_,l11ll1l1l11_l1_,l11lll1l11l_l1_,l11l1ll1l11_l1_,l11llll11l1_l1_,l11l1l1ll1l_l1_,l11ll1l11ll_l1_,l11ll1l111l_l1_,l11lll111l1_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l1ll11_l1_ not in [l11lll_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㸹"),l11lll_l1_ (u"ࠬࡏࡐࡕࡘࠪ㸺")]:
		if kodi_version<19: l1l11l1l11ll_l1_ = l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࡥࡩࡪ࡯࡯ࠩ㸻")
		else: l1l11l1l11ll_l1_ = l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࠬ㸼")
		#l11l1ll111l_l1_ = xbmcgui.ListItem(path=url)
		l11l1ll111l_l1_.setProperty(l1l11l1l11ll_l1_, l11lll_l1_ (u"ࠨࠩ㸽"))
		l11l1ll111l_l1_.setMimeType(l11lll_l1_ (u"ࠩࡰ࡭ࡲ࡫࠯ࡹ࠯ࡷࡽࡵ࡫ࠧ㸾"))
		if kodi_version<20: l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㸿"),{l11lll_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧ㹀"):l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ㹁")})
		else:
			l1l11l11ll11_l1_ = l11l1ll111l_l1_.getVideoInfoTag()
			l1l11l11ll11_l1_.setMediaType(l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㹂"))
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰࡬ࡧࡴࡴࠧ㹃"))
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㹄"),l11lll_l1_ (u"ࠩࡈࡑࡆࡊ࠺࠻࠼࠽࠾ࠥ࠭㹅")+l11l_l1_)
		#l11l1ll111l_l1_.setArt({l11lll_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ㹆"):l11l_l1_,l11lll_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ㹇"):l11l_l1_,l11lll_l1_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ㹈"):l11l_l1_})
		l11l1ll111l_l1_.setArt({l11lll_l1_ (u"࠭ࡴࡩࡷࡰࡦࠬ㹉"):l11llll11l1_l1_,l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧ㹊"):l11llll11l1_l1_,l11lll_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨ㹋"):l11llll11l1_l1_,l11lll_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ㹌"):l11llll11l1_l1_,l11lll_l1_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬ㹍"):l11llll11l1_l1_,l11lll_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ㹎"):l11llll11l1_l1_,l11lll_l1_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ㹏"):l11llll11l1_l1_,l11lll_l1_ (u"࠭ࡩࡤࡱࡱࠫ㹐"):l11llll11l1_l1_})
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㹑"),{l11lll_l1_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧ㹒"):name})
		#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ㹓"))
		#name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ㹔"))
		# when set to l11lll_l1_ (u"ࠦࡋࡧ࡬ࡴࡧࠥ㹕") it l111l1l1l1l_l1_ l1l1l1llllll_l1_ l1ll11l111l1_l1_ and l1l1l1llll11_l1_ l111111lll1_l1_ l1l111ll1111_l1_ l1l1lll1ll_l1_
		if l111lll11l_l1_ in [l11lll_l1_ (u"ࠬ࠴࡭ࡱࡦࠪ㹖"),l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㹗")]: l11l1ll111l_l1_.setContentLookup(True)
		else: l11l1ll111l_l1_.setContentLookup(False)
		#if l111lll11l_l1_ in [l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㹘")]: l11l1ll111l_l1_.setContentLookup(False)
		if l11lll_l1_ (u"ࠨࡴࡷࡱࡵ࠭㹙") in url:
			import l11ll1lll11_l1_
			l11ll1lll11_l1_.l111ll1l1l1_l1_(l11lll_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ㹚"),False)
		elif l111lll11l_l1_==l11lll_l1_ (u"ࠪ࠲ࡲࡶࡤࠨ㹛") or l11lll_l1_ (u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ㹜") in url:
			import l11ll1lll11_l1_
			l11ll1lll11_l1_.l111ll1l1l1_l1_(l11lll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ㹝"),False)
			l11l1ll111l_l1_.setProperty(l1l11l1l11ll_l1_,l11lll_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭㹞"))
			l11l1ll111l_l1_.setProperty(l11lll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫࠮࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡷࡽࡵ࡫ࠧ㹟"),l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ㹠"))
			#l11l1ll111l_l1_.setMimeType(l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡥࡣࡶ࡬࠰ࡾ࡭࡭ࠩ㹡"))
			#l11l1ll111l_l1_.setContentLookup(False)
		if l1ll1111111l_l1_:
			l11l1ll111l_l1_.setSubtitles([l1ll1111111l_l1_])
			#xbmc.log(LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࡄࡨࡩ࡫ࡤࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࠣࡸࡴࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡷࡥࡸ࡮ࡺ࡬ࡦ࠼࡞ࠫ㹢")+l1ll1111111l_l1_+l11lll_l1_ (u"ࠫࡢ࠭㹣"), level=xbmc.LOGNOTICE)
	if l11l1l1ll11_l1_==l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㹤") and l1l1ll11_l1_==l11lll_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㹥"):
		l1l111l11ll_l1_ = l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㹦")
		l1l1ll11_l1_ = l11lll_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ㹧")
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㹨") and l11ll1l111l_l1_.startswith(l11lll_l1_ (u"ࠪ࠺ࠬ㹩")):
		l1l111l11ll_l1_ = l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㹪")
		l1l1ll11_l1_ = l1l1ll11_l1_+l11lll_l1_ (u"ࠬࡥࡄࡍࠩ㹫")
	# l11l1ll1l1l_l1_ l1l1111l1l1_l1_
	#	l11ll1l1lll_l1_ = l11lll1ll11_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l11ll11_l1_ with xbmc.sleep(step*1000)
	if l1l111l11ll_l1_!=l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㹬"): l11llll111l_l1_()
	l11ll1l1lll_l1_ = l11lll1ll11_l1_()
	l11ll1l1lll_l1_.l11lll11l11_l1_(l1l1ll11_l1_)
	if l11ll1l1lll_l1_.status:
		l1l111l11ll_l1_ == l11lll_l1_ (u"ࠧࠨ㹭")
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㹮"),l11lll_l1_ (u"ࠩࠪ㹯"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㹰"),l11lll_l1_ (u"้่ࠫฯࠡไส้ࠥอไๆสิ้ัࠦศฦ์ๅหๆࠦสี฼ํ่ࠥ๎สฮ็ํ่ࠥอไโ์า๎ํํวหࠢไ๎ࠥํะศࠢส่ัํวำࠩ㹱"))
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㹲") and not l11ll1l111l_l1_.startswith(l11lll_l1_ (u"࠭࠶ࠨ㹳")):
		#title = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠨ㹴"))
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㹵"),{l11lll_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ㹶"): 3600})
		#xbmcplugin.setContent(addon_handle,l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ㹷"))
		#l11l1ll111l_l1_.setInfo(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㹸"),{l11lll_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ㹹"):l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㹺")})
		#l11l1ll111l_l1_.setProperty(l11lll_l1_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫ㹻"),l11lll_l1_ (u"ࠨࡶࡵࡹࡪ࠭㹼"))
		#l11l1ll111l_l1_.setInfo(type=l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㹽"),l1l11l111l11_l1_={l11lll_l1_ (u"ࠥࡘ࡮ࡺ࡬ࡦࠤ㹾"):l11lll_l1_ (u"ࠫ࡭࡫࡬࡭ࡱࠣࡻࡴࡸ࡬ࡥࠩ㹿")})
		l11l1ll111l_l1_.setPath(url)
		LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㺀"),LOGGING(script_name)+l11lll_l1_ (u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾࠦࡵࡴ࡫ࡱ࡫ࠥࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㺁")+url+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㺂"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll111l_l1_)
	elif l11l1l1ll11_l1_==l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㺃"):
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㺄"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡙ࠩࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㺅")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ㺆"))
		l11ll1l1lll_l1_.play(url,l11l1ll111l_l1_)
		#xbmc.Player().play(url,l11l1ll111l_l1_)
	succeeded = False
	if l1l111l11ll_l1_==l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㺇"):
		import l11l111l11_l1_
		succeeded = l11l111l11_l1_.l11l11l1l1_l1_(url,l111lll11l_l1_,l1l1ll11_l1_)
		if succeeded: l11llll111l_l1_()
	else:
		l1111111l1l_l1_,l1l111l11ll_l1_ = 10,l11lll_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ㺈")
		for l11l1lllll_l1_ in range(l1111111l1l_l1_):
			# l11l1ll1l1l_l1_ l1l1111l1l1_l1_
			#	if using time.sleep() l11l1lll1l1_l1_ of xbmc.sleep() l1l11111ll1_l1_ the l11ll1111ll_l1_ status
			#	l11lll_l1_ (u"ࠢ࡮ࡻࡳࡰࡦࡿࡥࡳ࠰ࡶࡸࡦࡺࡵࡴࠤ㺉") will stop l11ll1ll111_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l11ll_l1_ = l11ll1l1lll_l1_.status
			if l1l111l11ll_l1_==l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㺊"):
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣ๎฾๋ไࠨ㺋"),l11lll_l1_ (u"ࠪࠫ㺌"),time=500)
				LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㺍"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࡺ࡮ࡪࡥࡰࠢ࡬ࡷࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㺎")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ㺏")+l111l11111l_l1_)
				break
			elif l1l111l11ll_l1_==l11lll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ㺐"):
				LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㺑"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㺒")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭㺓")+l111l11111l_l1_)
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭㺔"),l11lll_l1_ (u"ࠬ࠭㺕"),time=500)
				break
			if l1l111l11ll_l1_:
				LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㺖"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡈࡪࡼࡩࡤࡧࠣ࡭ࡸࠦࡢ࡭ࡱࡦ࡯ࡪࡪࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㺗")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㺘"))
				break
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩฯหึ๐ࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧ㺙"),l11lll_l1_ (u"ࠪฬฬ่๊ࠡࠩ㺚")+str(l1111111l1l_l1_-l11l1lllll_l1_)+l11lll_l1_ (u"ࠫࠥัว็์ฬࠫ㺛"))
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠧ㺜"),l11lll_l1_ (u"࠭ࠧ㺝"),time=500)
			LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㺞"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸࠥࡻ࡮࡬ࡰࡲࡻࡳࠦࡰࡳࡱࡥࡰࡪࡳࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㺟")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㺠")+l111l11111l_l1_)
			l1l111l11ll_l1_ = l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㺡")
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋ࡬ࡪࠥ࡮ࡴࡵࡲࡧ࠾ࠒࠐࠉࠊࠥࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡣ࡭࡫ࡦ࡯ࠥࡵ࡫ࠡࡶࡲࠤࡸ࡮ࡵࡵࡦࡲࡻࡳࠦࡴࡩࡧࠣ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠨࠫࠐࠎࠎࠏࠣࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡐࡒࡣࡈࡇࡃࡉࡇ࠯ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ࠩࠎࠌࠌࠍࡹ࡯࡭ࡦ࠰ࡶࡰࡪ࡫ࡰࠩ࠳ࠬࠑࠏࠏࠉࡩࡶࡷࡴࡩ࠴ࡳࡩࡷࡷࡨࡴࡽ࡮ࠩࠫࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠩ࠯ࠫࠬ࠯ࠍࠋࠋࠥࠦࠧ㺢")
	if l1l111l11ll_l1_ in [l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㺣"),l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㺤")] or succeeded: response = l1l1111lll1_l1_(l1l1ll11_l1_)
	else: l11ll1l1lll_l1_.stop()
	#if l1l111l11ll_l1_ in [l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㺥"),l11lll_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㺦"),l11lll_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㺧"),l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㺨"),l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㺩")]: l111l11l11l_l1_(l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡍࡃ࡜ࡣ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧ㺪"),False)
	#l111l11l11l_l1_(l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒ࠱࠸ࡸࡤࠨ㺫"))
	#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ㺬") in url and l1l111l11ll_l1_ in [l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㺭"),l11lll_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ㺮")]:
	#	l11ll1ll111_l1_ = HTTPS(False)
	#	if not l11ll1ll111_l1_:
	#		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㺯"),l11lll_l1_ (u"ࠫࠬ㺰"),l11lll_l1_ (u"ࠬอไศฬุห้ࠦๅีใิࠫ㺱"),l11lll_l1_ (u"࠭ๅีๅ็อࠥ࠴࠮࠯๊ࠢิฬࠦวๅใํำ๏๎๋ࠠฯอหัࠦวๅ๋ࠣหฯ฻วๅุ่ࠢๆืࠠࠩำห฻๋ࠥิโำࠬࠤํ๊ใ็ࠢ็่ศูแࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽้๏ࠠอ้สึ่࠭㺲"))
	#		return l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭㺳")
	#sys.exit()
	if 0 and l1l111l11ll_l1_==l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ㺴"):
		LOG_THIS(l11lll_l1_ (u"ࠩࠪ㺵"),l11lll_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡕࡗࡅ࡙࡛ࡓ࠻࠼ࠣࠤࠥ࠭㺶")+l11lll_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㺷"))
		while True:
			l1l111l11ll_l1_ = l11ll1l1lll_l1_.status
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭㺸"),l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ㺹")+l1l111l11ll_l1_)
			if l1l111l11ll_l1_!=l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㺺"): break
			xbmc.sleep(1000)
		LOG_THIS(l11lll_l1_ (u"ࠨࠩ㺻"),l11lll_l1_ (u"ࠩࡓࡐࡆ࡟࡟ࡔࡖࡄࡘ࡚࡙࠺࠻ࠢࠣࠤࠬ㺼")+l11lll_l1_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ㺽"))
	return l1l111l11ll_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l1lll1l1l1_l1_ = args[0]
		l11l1ll1_l1_ = args[1]
		if not l1l1lll1l1l1_l1_: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㺾")
		if not l11l1ll1_l1_: l11l1ll1_l1_ = l11lll_l1_ (u"ࠬอำห็ิหึ࠭㺿")
		header = args[2]
		text = l11lll_l1_ (u"࠭࡜࡯ࠩ㻀").join(args[3:])
	else: l1l1lll1l1l1_l1_,l11l1ll1_l1_,header,text = l11lll_l1_ (u"ࠧࠨ㻁"),l11lll_l1_ (u"ࠨࡑࡎࠫ㻂"),l11lll_l1_ (u"ࠩࠪ㻃"),l11lll_l1_ (u"ࠪࠫ㻄")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l1lll1l1l1_l1_,l11lll_l1_ (u"ࠫࠬ㻅"),l11l1ll1_l1_,l11lll_l1_ (u"ࠬ࠭㻆"),header,text,**kwargs)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l1lll1l1l1_l1_ = args[0]
	l1ll11l1llll_l1_ = args[1]
	l1ll111l1l1l_l1_ = args[2]
	if l1ll111l1l1l_l1_ or l1ll11l1llll_l1_: l1ll11l1l11l_l1_ = True
	else: l1ll11l1l11l_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l1lll1l1l1_l1_: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㻇")
	if not l1ll11l1llll_l1_: l1ll11l1llll_l1_ = l11lll_l1_ (u"ࠧไๆสࠫ㻈")
	if not l1ll111l1l1l_l1_: l1ll111l1l1l_l1_ = l11lll_l1_ (u"ࠨ่฼้ࠬ㻉")
	if len(args)>=6: text += l11lll_l1_ (u"ࠩ࡟ࡲࠬ㻊")+args[5]
	if len(args)>=7: text += l11lll_l1_ (u"ࠪࡠࡳ࠭㻋")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1lll1l1l1_l1_,l1ll11l1llll_l1_,l11lll_l1_ (u"ࠫࠬ㻌"),l1ll111l1l1l_l1_,header,text,**kwargs)
	if choice==-1 and l1ll11l1l11l_l1_: choice = -1
	elif choice==-1 and not l1ll11l1l11l_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l1lll111l1l1_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11lll_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㻍") in list(kwargs.keys()): l11l1l111ll_l1_ = kwargs[l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㻎")]
	else: l11l1l111ll_l1_ = 1000
	if len(args)>2 and l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࠬ㻏") not in args[2]: profile = args[2]
	else: profile = l11lll_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧ㻐")
	l1l11l11l1ll_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࡉ࡮ࡣࡪࡩ࠳ࡾ࡭࡭ࠩ㻑"),l11lll1ll1l_l1_,l11lll_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ㻒"),l11lll_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ㻓"))
	l1ll1lll1l11_l1_,l1111111ll1_l1_ = l1l11l1l1ll1_l1_(l11lll_l1_ (u"ࠬ࠭㻔"),l11lll_l1_ (u"࠭ࠧ㻕"),l11lll_l1_ (u"ࠧࠨ㻖"),header,text,profile,l11lll_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭㻗"),720,False)
	#time.sleep(0.200)
	l1l11l11l1ll_l1_.show()
	if profile==l11lll_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡶࡺࡳ࡭ࡧ࡬ࡧࡵࠪ㻘"):
		l1l11l11l1ll_l1_.getControl(9040).setHeight(215)
		l1l11l11l1ll_l1_.getControl(9040).setPosition(55,-80)
		l1l11l11l1ll_l1_.getControl(9050).setPosition(120,-60)
		l1l11l11l1ll_l1_.getControl(400).setPosition(90,-35)
	l1l11l11l1ll_l1_.getControl(401).setVisible(False)
	l1l11l11l1ll_l1_.getControl(402).setVisible(False)
	l1l11l11l1ll_l1_.getControl(9050).setImage(l1ll1lll1l11_l1_)
	l1l11l11l1ll_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	import threading
	l11l11ll111_l1_ = threading.Thread(target=l1l11111l111_l1_,args=(l1l11l11l1ll_l1_,l1ll1lll1l11_l1_,l11l1l111ll_l1_))
	l11l11ll111_l1_.start()
	#l11l11ll111_l1_.join()
	return
	#return xbmcgui.Dialog().l1l11ll111ll_l1_(l1l1ll1lll1l_l1_=False,*args,**kwargs)
def l1l11111l111_l1_(l1l11l11l1ll_l1_,l1ll1lll1l11_l1_,l11l1l111ll_l1_):
	time.sleep(l11l1l111ll_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1ll1lll1l11_l1_):
		try: os.remove(l1ll1lll1l11_l1_)
		except: pass
	#del l1l11l11l1ll_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠪࠫ㻙"),l11lll_l1_ (u"ࠫࠬ㻚"),l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㻛"),l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ㻜")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l1lll1l1l1_l1_ = args[3]
	return l11ll11lll_l1_(l1l1lll1l1l1_l1_,header,text,profile)
	#return xbmcgui.Dialog().l1ll11llll1l_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1l1l1l1l1l1_l1_(*args,**kwargs)
def l11l11llll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111l1ll111_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text,profile,l1l1lll1l1l1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l11l11l1ll_l1_ = l1ll111l1ll1_l1_(l11lll_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㻝"),l11lll1ll1l_l1_,l11lll_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㻞"),l11lll_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㻟"))
	#l1l11l11l1ll_l1_.l1111111l11_l1_(l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text,profile,l1l1lll1l1l1_l1_,855)
	#return l1l11l11l1ll_l1_
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊ࡫ࡩࠤࡹࡺࡩ࡮ࡧࡲࡹࡹࡄ࠰࠻ࠢࡧ࡭ࡦࡲ࡯ࡨ࠰ࡶࡸࡦࡸࡴࡃࡷࡷࡸࡴࡴࡳࡕ࡫ࡰࡩࡴࡻࡴࠩࡶࡷ࡭ࡲ࡫࡯ࡶࡶࠬࠑࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡪࡩࡢ࡮ࡲ࡫࠳࡫࡮ࡢࡤ࡯ࡩࡇࡻࡴࡵࡱࡱࡷ࠭࠯ࠍࠋࠋࠦࡨ࡮ࡧ࡬ࡰࡩ࠱ࡹࡵࡪࡡࡵࡧࡓࡶࡴ࡭ࡲࡦࡵࡶࡆࡦࡸࠨ࠸࠲ࠬࠍࠨࠦ࠷࠱ࠧࠐࠎࠎࡪࡩࡢ࡮ࡲ࡫࠳ࡪ࡯ࡎࡱࡧࡥࡱ࠮ࠩࠎࠌࠌࡧ࡭ࡵࡩࡤࡧࠣࡁࠥࡪࡩࡢ࡮ࡲ࡫࠳ࡩࡨࡰ࡫ࡦࡩࡎࡊࠍࠋࠋࡷࡶࡾࡀࠠࡰࡵ࠱ࡶࡪࡳ࡯ࡷࡧࠫࡨ࡮ࡧ࡬ࡰࡩ࠱࡭ࡲࡧࡧࡦࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠒࠐࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠥࡧࡩࡱࠦࡤࡪࡣ࡯ࡳ࡬ࠓࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡥ࡫ࡳ࡮ࡩࡥࠎࠌࠌࠦࠧࠨ㻠")
def l1ll11l11_l1_(l1ll1111llll_l1_):
	if kodi_version>17.99: l1l11l11l1ll_l1_ = l11lll_l1_ (u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧ࡯ࡱࡦࡥࡳࡩࡥ࡭ࠩ㻡")
	else: l1l11l11l1ll_l1_ = l11lll_l1_ (u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠩ㻢")
	l1ll1111llll_l1_ = l1ll1111llll_l1_.lower()
	if l1ll1111llll_l1_==l11lll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㻣"): xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩ㻤")+l1l11l11l1ll_l1_+l11lll_l1_ (u"ࠨࠫࠪ㻥"))
	elif l1ll1111llll_l1_==l11lll_l1_ (u"ࠩࡶࡸࡴࡶࠧ㻦"): xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࠪ㻧")+l1l11l11l1ll_l1_+l11lll_l1_ (u"ࠫ࠮࠭㻨"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l1lll1l1l1_l1_,l1llll11llll_l1_=l11lll_l1_ (u"ࠬ࠭㻩"),l1l11lllllll_l1_=l11lll_l1_ (u"࠭ࠧ㻪"),l1llll1l1l11_l1_=l11lll_l1_ (u"ࠧࠨ㻫"),header=l11lll_l1_ (u"ࠨࠩ㻬"),text=l11lll_l1_ (u"ࠩࠪ㻭"),profile=l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㻮"),l1ll11l11ll1_l1_=0,l1l1l1llll1l_l1_=0):
	if not l1l1lll1l1l1_l1_: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㻯")
	l1l11l11l1ll_l1_ = l1ll111l1ll1_l1_(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ㻰"),l11lll1ll1l_l1_,l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㻱"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㻲"))
	l1l11l11l1ll_l1_.l1111111l11_l1_(l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text,profile,l1l1lll1l1l1_l1_,900,l1ll11l11ll1_l1_,l1l1l1llll1l_l1_)
	if l1ll11l11ll1_l1_>0: l1l11l11l1ll_l1_.l11l11l111l_l1_()
	if l1l1l1llll1l_l1_>0: l1l11l11l1ll_l1_.l111llll11l_l1_()
	if l1ll11l11ll1_l1_==0 and l1l1l1llll1l_l1_==0: l1l11l11l1ll_l1_.enableButtons()
	l1l11l11l1ll_l1_.doModal()
	choice = l1l11l11l1ll_l1_.l11l11l1ll1_l1_
	return choice
def l11ll11lll_l1_(l1l1lll1l1l1_l1_,header,text,profile=l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㻳")):
	if not l1l1lll1l1l1_l1_: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ㻴")
	#text = l11lll_l1_ (u"ࠪࡠࡳ࠭㻵").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11lll_l1_ (u"ࠫࠬ㻶")
	l1l11l11l1ll_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨ㻷"),l11lll1ll1l_l1_,l11lll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㻸"),l11lll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㻹"))
	l1ll1lll1l11_l1_,l1111111ll1_l1_ = l1l11l1l1ll1_l1_(l11lll_l1_ (u"ࠨࠩ㻺"),l11lll_l1_ (u"ࠩࠪ㻻"),l11lll_l1_ (u"ࠪࠫ㻼"),header,text,profile,l1l1lll1l1l1_l1_,1270,False)
	l1l11l11l1ll_l1_.show()
	#time.sleep(1)
	#l1l11l11l1ll_l1_.getControl(9050).l1l111llll1l_l1_(1270-60)
	l1l11l11l1ll_l1_.getControl(9050).setHeight(l1111111ll1_l1_)
	l1l11l11l1ll_l1_.getControl(9050).setImage(l1ll1lll1l11_l1_)
	result = l1l11l11l1ll_l1_.doModal()
	#del l1l11l11l1ll_l1_
	try: os.remove(l1ll1lll1l11_l1_)
	except: pass
	return result
def l1l11l11l_l1_(l1l1l1ll1111_l1_=True):
	if l1l1l1ll1111_l1_:
		l111lll1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡸࡺࡲࠨ㻽"),l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㻾"),l11lll_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㻿"))
		if l111lll1l1_l1_: return l111lll1l1_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㼀"),l11lll_l1_ (u"ࠨࡇࡐࡅࡉࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࡷࡶࡩࡷࡧࡧࡦࡰࡷ࠾ࠥ࠭㼁")+results)
	# l11l11l1l1l_l1_ and l11111l11l_l1_ common user l1l1llll1ll1_l1_ (l111l111l11_l1_ l11l11l11l1_l1_)
	text = l11lll_l1_ (u"ࠩࠪ㼂")
	url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡫ࡣࡩࡤ࡯ࡳ࡬࠴ࡷࡪ࡮࡯ࡷ࡭ࡵࡵࡴࡧ࠱ࡧࡴࡳ࠯࠳࠲࠴࠶࠴࠶࠱࠰࠲࠶࠳ࡲࡵࡳࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹࡹ࠯ࠨ㼃")
	headers = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㼄"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㼅"),url,l11lll_l1_ (u"࠭ࠧ㼆"),headers,l11lll_l1_ (u"ࠧࠨ㼇"),l11lll_l1_ (u"ࠨࠩ㼈"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ㼉"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11lll_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫ㼊"))
		if count>80:
			text = re.findall(l11lll_l1_ (u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㼋"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㼌"),l11lll_l1_ (u"࠭ࠧ㼍"),l11lll_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ㼎"),l11lll_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦࡕࡔࡇࡕ࠱ࡆࡍࡅࡏࡖࡖࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬ࠨ㼏"))
	if not text:
		l1ll1l11l11l_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㼐"),l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡹ࠮ࡵࡺࡷࠫ㼑"))
		text = open(l1ll1l11l11l_l1_,l11lll_l1_ (u"ࠫࡷࡨࠧ㼒")).read()
		if kodi_version>18.99: text = text.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㼓"))
		text = text.replace(l11lll_l1_ (u"࠭࡜ࡳࠩ㼔"),l11lll_l1_ (u"ࠧࠨ㼕"))
	l1ll1ll111ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ㼖"),text,re.DOTALL)
	l111ll11ll1_l1_ = []
	for line in l1ll1ll111ll_l1_:
		l1ll1111ll11_l1_ = line.lower()
		if l11lll_l1_ (u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ㼗") in l1ll1111ll11_l1_: continue
		if l11lll_l1_ (u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ㼘") in l1ll1111ll11_l1_: continue
		if l11lll_l1_ (u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ㼙") in l1ll1111ll11_l1_: continue
		if l11lll_l1_ (u"ࠬࡩࡲࡰࡵࠪ㼚") in l1ll1111ll11_l1_: continue
		#if l11lll_l1_ (u"࠭ࡨࡵ࡯࡯ࠫ㼛") in l1ll1111ll11_l1_: continue
		l111ll11ll1_l1_.append(line)
	l111lll1l1_l1_ = random.sample(l111ll11ll1_l1_,1)
	l111lll1l1_l1_ = l111lll1l1_l1_[0]
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㼜"),l11lll_l1_ (u"ࠨࠩ㼝"),str(len(l1ll1ll111ll_l1_)),l111lll1l1_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㼞"),l11lll_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭㼟"),l111lll1l1_l1_,REGULAR_CACHE)
	return l111lll1l1_l1_
def l11l11l11ll_l1_(l1lll1lll1ll_l1_):
	#if l11lll_l1_ (u"ࠫ࡫ࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠩ㼠") in str(error).lower(): return
	#l1lll1lll1ll_l1_ = traceback.format_exc()
	sys.stderr.write(l1lll1lll1ll_l1_)
	lines = l1lll1lll1ll_l1_.splitlines()
	error = lines[-1]
	l1llll1lll1l_l1_ = open(l1ll1l1111ll_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ㼡")).read()
	if kodi_version>18.99: l1llll1lll1l_l1_ = l1llll1lll1l_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㼢"))
	l1llll1lll1l_l1_ = l1llll1lll1l_l1_[-8000:]
	sep = l11lll_l1_ (u"ࠧ࠾ࠩ㼣")*100
	if sep in l1llll1lll1l_l1_: l1llll1lll1l_l1_ = l1llll1lll1l_l1_.rsplit(sep,1)[1]
	if error in l1llll1lll1l_l1_: l1llll1lll1l_l1_ = l1llll1lll1l_l1_.rsplit(error,1)[0]
	#l11ll11lll_l1_(l11lll_l1_ (u"ࠨࠩ㼤"),error,l1llll1lll1l_l1_)
	#l11lllll1l1_l1_ = l1llll1lll1l_l1_.splitlines()
	#for line in reversed(l11lllll1l1_l1_):
	#	if l11lll_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬ㼥") in line or l11lll_l1_ (u"ࠪࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯ࠪ㼦") in line: continue
	#	if l11lll_l1_ (u"ࠫࡒࡵࡤࡦ࠼ࠣ࡟ࠬ㼧") not in line: continue
	l1l1l11l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫ㼨"),l1llll1lll1l_l1_,re.DOTALL)
	for typ,source in reversed(l1l1l11l1ll1_l1_):
		#if l11lll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࠨ㼩") in source: continue
		#if l11lll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࠪ㼪") in source: continue
		if source: break
	else: source = l11lll_l1_ (u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨ㼫")
	#l11ll11lll_l1_(l11lll_l1_ (u"ࠩࠪ㼬"),source,str(l1l1l11l1ll1_l1_))
	file,line,func = l11lll_l1_ (u"ࠪࠫ㼭"),l11lll_l1_ (u"ࠫࠬ㼮"),l11lll_l1_ (u"ࠬ࠭㼯")
	l111l1lll11_l1_ = l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅะฺว࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㼰")+error
	l1lll11ll11l_l1_ = l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆู่ิื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㼱")+source
	for l1ll11l1ll1l_l1_ in reversed(lines):
		if l11lll_l1_ (u"ࠨࡈ࡬ࡰࡪࠦࠢࠨ㼲") in l1ll11l1ll1l_l1_ and l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㼳") in l1ll11l1ll1l_l1_: break
	l1ll11l1ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠫ࠲࠯ࡅࠩࠣ࡞࠯ࠤࡱ࡯࡮ࡦࠢࠫ࠲࠯ࡅࠩ࡝࠮ࠣ࡭ࡳࠦࠨ࠯ࠬࡂ࠭ࠩ࠭㼴"),l1ll11l1ll1l_l1_,re.DOTALL)
	if l1ll11l1ll1l_l1_:
		file,line,func = l1ll11l1ll1l_l1_[0]
		if l11lll_l1_ (u"ࠫ࠴࠭㼵") in file: file = file.rsplit(l11lll_l1_ (u"ࠬ࠵ࠧ㼶"),1)[1]
		else: file = file.rsplit(l11lll_l1_ (u"࠭࡜࡝ࠩ㼷"),1)[1]
		l1l11l111l1l_l1_ = l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆ่่ๆࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㼸")+file
		line2 = l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ื฼ื࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㼹")+line
		l1111l1l111_l1_ = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊้ว็࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㼺")+func
		l1ll11l1l1l1_l1_ = l1l11l111l1l_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㼻")+line2+l11lll_l1_ (u"ࠫࡡࡴࠧ㼼")+l1111l1l111_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㼽")+l1lll11ll11l_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㼾")+l111l1lll11_l1_
		l1l1lllll1l1_l1_ = line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㼿")+l1lll11ll11l_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࠫ㽀")+l111l1lll11_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ㽁")+l1l11l111l1l_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭㽂")+l1111l1l111_l1_
		l111lll1l11_l1_ = line2+l11lll_l1_ (u"ࠫࡡࡴࠧ㽃")+l111l1lll11_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ㽄")+l1l11l111l1l_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ㽅")+l1111l1l111_l1_
	else:
		l1l11l111l1l_l1_,line2,l1111l1l111_l1_ = l11lll_l1_ (u"ࠧࠨ㽆"),l11lll_l1_ (u"ࠨࠩ㽇"),l11lll_l1_ (u"ࠩࠪ㽈")
		l1ll11l1l1l1_l1_ = l1lll11ll11l_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㽉")+l111l1lll11_l1_
		l1l1lllll1l1_l1_ = l1lll11ll11l_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㽊")+l111l1lll11_l1_
		l111lll1l11_l1_ = l111l1lll11_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l11lll_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭㽋"),time=2000)
	l1111l11l11_l1_ = l11lll_l1_ (u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัࠪ㽌")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ㽍")
	addons = l1lllllll1ll_l1_()
	l1ll11llllll_l1_ = []
	results = addons[l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㽎")]
	l1ll11l1l111_l1_ = l1l1111l1111_l1_(l11ll111111_l1_)
	if l11lll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㽏") in list(addons.keys()):
		for l1l1l1l1ll11_l1_,l1lll1l1lll1_l1_,l111l1lll1l_l1_ in results: l1ll11llllll_l1_ = max(l1ll11llllll_l1_,l1lll1l1lll1_l1_)
		if l1ll11l1l111_l1_<l1ll11llllll_l1_:
			header = l11lll_l1_ (u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ั࠭㽐")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㽑"),l11lll_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㽒"),l11lll_l1_ (u"࠭สฮัํฯࠬ㽓"),l11lll_l1_ (u"ࠧฯำ๋ะࠬ㽔"),l1111l11l11_l1_+header,l1ll11l1l1l1_l1_)
			if choice==0:
				l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㽕"),l11lll_l1_ (u"ࠩัีําࠧ㽖"),l11lll_l1_ (u"ࠪฮาี๊ฬࠩ㽗"),l11lll_l1_ (u"ࠫࠬ㽘"),header)
				if l1ll111ll1_l1_==1: choice = 1
			if choice==1:
				import l11ll1lll11_l1_
				l11ll1lll11_l1_.l1ll111l1l11_l1_()
			return
	l1l111111lll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ㽙"),l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ㽚"),l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡘࡋࡎࡕࡡࡈࡖࡗࡕࡒࡔࠩ㽛"))
	if not l1l111111lll_l1_: l1l111111lll_l1_ = []
	l1l1lllll1l1_l1_ = l1l1lllll1l1_l1_.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㽜"),l11lll_l1_ (u"ࠩ࡟ࡠࡳ࠭㽝")).replace(l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ㽞"),l11lll_l1_ (u"ࠫࠬ㽟")).replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㽠"),l11lll_l1_ (u"࠭ࠧ㽡")).replace(l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㽢"),l11lll_l1_ (u"ࠨࠩ㽣"))
	l111lll1l11_l1_ = l111lll1l11_l1_.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ㽤"),l11lll_l1_ (u"ࠪࡠࡡࡴࠧ㽥")).replace(l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ㽦"),l11lll_l1_ (u"ࠬ࠭㽧")).replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ㽨"),l11lll_l1_ (u"ࠧࠨ㽩")).replace(l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㽪"),l11lll_l1_ (u"ࠩࠪ㽫"))
	l1l1111lll11_l1_ = l11ll111111_l1_+l11lll_l1_ (u"ࠪ࠾࠿࠭㽬")+l111lll1l11_l1_
	if l1l1111lll11_l1_ in l1l111111lll_l1_:
		header = l11lll_l1_ (u"้่ࠫฯࠡไ่ฮࠥอๆหࠢึหอ่วࠡสศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ㽭")
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ㽮"),l11lll_l1_ (u"࠭ฮา๊ฯࠫ㽯"),l11lll_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ㽰"),l1111l11l11_l1_+header,l1ll11l1l1l1_l1_)
		#if l1ll111ll1_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㽱"),l11lll_l1_ (u"ࠩัีําࠧ㽲"),l11lll_l1_ (u"ࠪࠫ㽳"),header)
		DIALOG_OK(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㽴"),l11lll_l1_ (u"ࠬ࠭㽵"),l1111l11l11_l1_+header,l1ll11l1l1l1_l1_)
		return
	l1l111l11ll1_l1_ = str(kodi_version).split(l11lll_l1_ (u"࠭࠮ࠨ㽶"))[0]
	#l111llll111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㽷"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㽸"),l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡋࡏࡑ࡚ࡒࡤࡋࡒࡓࡑࡕࡗࠬ㽹"))
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ㽺")][6]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ㽻"),url,l11lll_l1_ (u"ࠬ࠭㽼"),l11lll_l1_ (u"࠭ࠧ㽽"),l11lll_l1_ (u"ࠧࠨ㽾"),l11lll_l1_ (u"ࠨࠩ㽿"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓ࠮࠳ࡶࡸࠬ㾀"),False,False)
	html = response.content
	l111llll111_l1_ = re.findall(l11lll_l1_ (u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬ࠼࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࡇࡑࡈ࠿ࡀࡅࡏࡆࠪ㾁"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㾂"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡎࡒࡔ࡝ࡎࡠࡇࡕࡖࡔࡘࡓࠨ㾃"),l111llll111_l1_,REGULAR_CACHE)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㾄"),line+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ㾅")+error+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㾆")+l11ll111111_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㾇")+l1l111l11ll1_l1_)
	for l1111l11111_l1_,l111l1ll1ll_l1_,l1ll1llllll1_l1_,l1l1lllll11l_l1_ in l111llll111_l1_:
		l1111l11111_l1_ = l1111l11111_l1_.split(l11lll_l1_ (u"ࠪ࠯ࠬ㾈"))
		l1ll1llllll1_l1_ = l1ll1llllll1_l1_.split(l11lll_l1_ (u"ࠫ࠰࠭㾉"))
		l1l1lllll11l_l1_ = l1l1lllll11l_l1_.split(l11lll_l1_ (u"ࠬ࠱ࠧ㾊"))
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㾋"),str(l1111l11111_l1_)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ㾌")+l111l1ll1ll_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ㾍")+str(l1ll1llllll1_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㾎")+str(l1l1lllll11l_l1_))
		if line in l1111l11111_l1_ and error==l111l1ll1ll_l1_ and l11ll111111_l1_ in l1ll1llllll1_l1_ and l1l111l11ll1_l1_ in l1l1lllll11l_l1_:
			header = l11lll_l1_ (u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨ㾏")
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㾐"),l11lll_l1_ (u"ࠬิั้ฮࠪ㾑"),l11lll_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ㾒"),l1111l11l11_l1_+header,l1ll11l1l1l1_l1_)
			if l1ll111ll1_l1_==1: DIALOG_OK(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㾓"),l11lll_l1_ (u"ࠨࠩ㾔"),l11lll_l1_ (u"ࠩࠪ㾕"),header)
			return
	header = l11lll_l1_ (u"ࠪห้ืฬศรࠣษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ㾖")
	DIALOG_OK(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ㾗"),l11lll_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ㾘"),l1111l11l11_l1_+header,l1ll11l1l1l1_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㾙"),l11lll_l1_ (u"ࠧไๆสࠫ㾚"),l11lll_l1_ (u"ࠨ่฼้ࠬ㾛"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㾜"),l11lll_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤสืำศๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ่่ࠣ๐๋ࠠ฻ิๅࠥอไๆสิ้ัࠦร๋่ࠣ์๊ะ้๊ࠡๆ๎ๆ่ࠦๅ็สิฬࠦอึๆอࠤ์ึ็ࠡษ็ู้้ไสࠢ็ว๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮ้ࠠๆสࠤ๏ูสุ์฼ࠤฬ฻ไศฯู้้ࠣไส๋๋ࠢํࠦไศࠢํ฽ึ็ࠠไ์ไࠤ฽ํัห๋่๊ࠢอะศࠢ฻๋ึะ้ࠠ็อํࠥ฾็าฬ๋ࠣีํࠠศๆุ่่๊ษࠡ࠰๋้ࠣࠦสา์าࠤศืำศๆࠣหู้ฬๅࠢยࠫ㾝"))
	if l1ll111ll1_l1_==1: l1l1111lllll_l1_ = l11lll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㾞")
	else:
		DIALOG_OK(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㾟"),l11lll_l1_ (u"࠭ࠧ㾠"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㾡"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฮ๊ࠦลๅ฼สลࠥหัิษ็ࠤฬ๊ฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ๊ร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠฦื็หาࠦวๅะฺวࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อมࠡษ็ิ๏ࠦๅไฬ๋ฬࠥ็๊่ࠢฯ้๏฿ࠠหใสู๏๊่ࠠาสࠤฬ๊ฮุลࠣ์฿๐ั่่๊ࠢࠥอไฤะฺหฦ࠭㾢"))
		return
	message = l1l1lllll1l1_l1_
	import l11ll1lll11_l1_
	succeeded = l11ll1lll11_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࡴࠩ㾣"),message,True,l11lll_l1_ (u"ࠪࠫ㾤"),l11lll_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㾥"),l1l1111lllll_l1_)
	if succeeded and l1l1111lllll_l1_:
		l1l111111lll_l1_.append(l1l1111lll11_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㾦"),l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ㾧"),l1l111111lll_l1_,PERMANENT_CACHE)
	return
def WRITE_THIS(data):
	if kodi_version>18.99: data = data.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㾨"))
	filename = l11lll_l1_ (u"ࠨࡵ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࡟ࠨ㾩")+str(time.time())+l11lll_l1_ (u"ࠩ࠱ࡨࡦࡺࠧ㾪")
	open(filename,l11lll_l1_ (u"ࠪࡻࡧ࠭㾫")).write(data)
	return
def l11l1111lll_l1_(l11llllllll_l1_):
	if l11llllllll_l1_:
		l1l1l11l1l11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㾬"),l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㾭"),l11lll_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ㾮"))
		if l1l1l11l1l11_l1_: return l1l1l11l1l11_l1_
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㾯")][5]
	user = l11llll11ll_l1_(32)
	l1lll1ll111l_l1_ = l11l1ll1111_l1_()
	l1ll1111l11l_l1_ = l1lll1ll111l_l1_.split(l11lll_l1_ (u"ࠨ࠮ࠪ㾰"))[2]
	l1l1ll1llll1_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㾱"))
	l1ll1l1lllll_l1_ = l1l111llll11_l1_()
	payload = {l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㾲"):user,l11lll_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ㾳"):l11ll111111_l1_,l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㾴"):l1ll1111l11l_l1_,l11lll_l1_ (u"࠭ࡩࡥࡵࠪ㾵"):l1l1ll1ll111_l1_(l1ll1l1lllll_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㾶"),url,payload,l11lll_l1_ (u"ࠨࠩ㾷"),l11lll_l1_ (u"ࠩࠪ㾸"),l11lll_l1_ (u"ࠪࠫ㾹"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩ㾺"))
	if not response.succeeded: return []
	html = response.content
	l1l1l11l1l11_l1_ = html.replace(l11lll_l1_ (u"ࠬࡢ࡜ࡳࠩ㾻"),l11lll_l1_ (u"࠭࡜࡯ࠩ㾼")).replace(l11lll_l1_ (u"ࠧ࡝࡞ࡱࠫ㾽"),l11lll_l1_ (u"ࠨ࡞ࡱࠫ㾾")).replace(l11lll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㾿"),l11lll_l1_ (u"ࠪࡠࡳ࠭㿀")).replace(l11lll_l1_ (u"ࠫࡡࡸࠧ㿁"),l11lll_l1_ (u"ࠬࡢ࡮ࠨ㿂"))
	l1l1l11l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ㿃"),l1l1l11l1l11_l1_,re.DOTALL)
	if not l1l1l11l1l11_l1_: return []
	l1l1l11l1l11_l1_ = sorted(l1l1l11l1l11_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l11111lll1_l1_,l1l111lll111_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11l1l11_l1_[0]
	#if l11lll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ㿄") in reason: l1l1lll11l1l_l1_,l1l1lll11ll1_l1_,l1l1lll11lll_l1_ = reason.split(l11lll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭㿅"),2)
	#else: l1l1lll11l1l_l1_,l1l1lll11ll1_l1_,l1l1lll11lll_l1_ = reason,reason,reason
	l1l1llllll1l_l1_ = reason if l11l1llll1l_l1_(l11lll_l1_ (u"ࠩࡐࡘ࠵࠻ࡈ࡙࠲࡯ࡘ࡙ࡋࡆࡏࡕࡘࡒ࡫࡛ࡅࡗࡕࡖ࡙࠾ࡋࡘࠨ㿆")) else l1l111lll111_l1_
	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ㿇"),l1l1llllll1l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㿈"),l11lll_l1_ (u"ࠬࡗࡕࡆࡕࡗࡍࡔࡔࡓࠨ㿉"),l1l1l11l1l11_l1_,REGULAR_CACHE)
	return l1l1l11l1l11_l1_
def SPLIT_BIGLIST(items,l1l1111ll1l1_l1_=0,l1ll1l1l111l_l1_=0):
	if l1l1111ll1l1_l1_ and not l1ll1l1l111l_l1_: l1ll1l1l111l_l1_ = len(items)//l1l1111ll1l1_l1_
	l1ll11l11lll_l1_,l11l1lllll_l1_,l1ll1111ll1l_l1_ = [],-1,0
	for item in items:
		if l1ll1111ll1l_l1_%l1ll1l1l111l_l1_==0:
			l11l1lllll_l1_ += 1
			l1ll11l11lll_l1_.append([])
		l1ll11l11lll_l1_[l11l1lllll_l1_].append(item)
		l1ll1111ll1l_l1_ += 1
	return l1ll11l11lll_l1_
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡱ࡫࡮ࡨࡶ࡫ࠤࡂࠦ࡬ࡦࡰࠫࡦ࡮࡭࡬ࡪࡵࡷ࠭ࠒࠐࠉࡴࡲ࡯࡭ࡹࡺࡥࡥࠢࡀࠤࡠࡣࠍࠋࠋࡩࡳࡷࠦࡩࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬ࠶࠲ࡳࡱ࡮࡬ࡸࡸࡥࡣࡰࡷࡱࡸ࠰࠷ࠩ࠻ࠏࠍࠍࠎ࡯ࡦࠡ࡫࡬ࠥࡂࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠾ࠒࠐࠉࠊࠋ࡯࡭ࡳ࡫ࡳ࠱ࠢࡀࠤࡧ࡯ࡧ࡭࡫ࡶࡸࡠ࠶࠺ࡪࡰࡷࠬࡱ࡫࡮ࡨࡶ࡫࠳ࡸࡶ࡬ࡪࡶࡶࡣࡨࡵࡵ࡯ࡶࠬࡡࠒࠐࠉࠊࠋࡧࡩࡱࠦࡢࡪࡩ࡯࡭ࡸࡺ࡛࠱࠼࡬ࡲࡹ࠮࡬ࡦࡰࡪࡸ࡭࠵ࡳࡱ࡮࡬ࡸࡸࡥࡣࡰࡷࡱࡸ࠮ࡣࠉࠎࠌࠌࠍࡪࡲࡳࡦ࠼ࠐࠎࠎࠏࠉ࡭࡫ࡱࡩࡸ࠶ࠠ࠾ࠢࡥ࡭࡬ࡲࡩࡴࡶࠐࠎࠎࠏࠉࡥࡧ࡯ࠤࡧ࡯ࡧ࡭࡫ࡶࡸࠒࠐࠉࠊࡵࡳࡰ࡮ࡺࡴࡦࡦ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴࡥࡴ࠲ࠬࠑࠏࠏࠉࡥࡧ࡯ࠤࡱ࡯࡮ࡦࡵ࠳ࠑࠏࠏࡲࡦࡶࡸࡶࡳࠦࡳࡱ࡮࡬ࡸࡹ࡫ࠍࠋࠋࠥࠦࠧ㿊")
def l1llllll1l11_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11lll_l1_ (u"ࠧࡥࡷࡰࡱࡾࡴࡡ࡮ࡧࠪ㿋"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11lll_l1_ (u"ࠨࡋࡓࡘ࡛ࡥࠧ㿌") not in filename or l11lll_l1_ (u"ࠩࡐ࠷࡚ࡥࠧ㿍") not in filename: text = str(data)
	else:
		l1ll11l11lll_l1_ = SPLIT_BIGLIST(data,8)
		text = l11lll_l1_ (u"ࠪࠫ㿎")
		for split in l1ll11l11lll_l1_:
			text += str(split)+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㿏")
		text = text.strip(l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㿐"))
	l11lll1l1l1_l1_ = zlib.compress(text)
	open(filepath,l11lll_l1_ (u"࠭ࡷࡣࠩ㿑")).write(l11lll1l1l1_l1_)
	return
def l111ll11l11_l1_(l11lll1llll_l1_,filename):
	if l11lll1llll_l1_==l11lll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㿒"): data = {}
	elif l11lll1llll_l1_==l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㿓"): data = []
	elif l11lll1llll_l1_==l11lll_l1_ (u"ࠩࡶࡸࡷ࠭㿔"): data = l11lll_l1_ (u"ࠪࠫ㿕")
	elif l11lll1llll_l1_==l11lll_l1_ (u"ࠫ࡮ࡴࡴࠨ㿖"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l11lll1l1l1_l1_ = open(filepath,l11lll_l1_ (u"ࠬࡸࡢࠨ㿗")).read()
	text = zlib.decompress(l11lll1l1l1_l1_)
	#open(l11lll_l1_ (u"࠭ࡳ࠻࡞࡟ࡍࡕ࡚ࡖ࠲࠰ࡷࡼࡹ࠭㿘"),l11lll_l1_ (u"ࠧࡸࡤࠪ㿙")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11lll_l1_ (u"ࠨࡦࡸࡱࡲࡿ࡮ࡢ࡯ࡨࠫ㿚"))
	#if l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ㿛") not in text: data = EVAL(l11lll_l1_ (u"ࠪࡷࡹࡸࠧ㿜"),text)
	if l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ㿝") not in text: data = eval(text)
	else:
		l1ll11l11lll_l1_ = text.split(l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㿞"))
		del text
		data = []
		l1111ll1l1l_l1_ = l11111lllll_l1_()
		id = 0
		for split in l1ll11l11lll_l1_:
			#data += EVAL(l11lll_l1_ (u"࠭ࡳࡵࡴࠪ㿟"),split)
			l1111ll1l1l_l1_.l11111l11ll_l1_(str(id),eval,split)
			id += 1
		del l1ll11l11lll_l1_
		l1111ll1l1l_l1_.l1l1ll11lll1_l1_()
		l1111ll1l1l_l1_.l1l1111ll11l_l1_()
		l1l111ll1lll_l1_ = list(l1111ll1l1l_l1_.l1ll1l1l11ll_l1_.keys())
		l1l11ll1l1l1_l1_ = sorted(l1l111ll1lll_l1_,reverse=False,key=lambda key: int(key))
		for id in l1l11ll1l1l1_l1_:
			data += l1111ll1l1l_l1_.l1ll1l1l11ll_l1_[id]
	return data
def l1ll111l11ll_l1_(addon_id):
	l111l1l11l1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㿠"),addon_id,l11lll_l1_ (u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ㿡"))
	try: l1ll1ll1111l_l1_ = open(l111l1l11l1_l1_,l11lll_l1_ (u"ࠩࡵࡦࠬ㿢")).read()
	except:
		l1ll1111l1l1_l1_ = os.path.join(l1lll11l1111_l1_,l11lll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ㿣"),addon_id,l11lll_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ㿤"))
		try: l1ll1ll1111l_l1_ = open(l1ll1111l1l1_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ㿥")).read()
		except: return l11lll_l1_ (u"࠭ࠧ㿦"),[]
	if kodi_version>18.99: l1ll1ll1111l_l1_ = l1ll1ll1111l_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㿧"))
	version = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾࡝࡟ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠣ࡞ࠪࡡࠬ㿨"),l1ll1ll1111l_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11lll_l1_ (u"ࠩࠪ㿩"),[]
	l11l11lll1l_l1_,l11111l1111_l1_ = version[0],l1l1111l1111_l1_(version[0])
	return l11l11lll1l_l1_,l11111l1111_l1_
def l1lllllll1ll_l1_():
	l1llll11ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㿪"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ㿫"),l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭㿬"))
	if l1llll11ll11_l1_: return l1llll11ll11_l1_
	addons,l1llll11ll11_l1_ = {},{}
	l1l1l11l1ll1_l1_ = [l1ll11l_l1_[l11lll_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ㿭")][0]]
	if kodi_version>17.99: l1l1l11l1ll1_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㿮")][1])
	if kodi_version>18.99: l1l1l11l1ll1_l1_.append(l1ll11l_l1_[l11lll_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㿯")][2])
	for l1l11llll1ll_l1_ in l1l1l11l1ll1_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㿰"),l1l11llll1ll_l1_,l11lll_l1_ (u"ࠪࠫ㿱"),l11lll_l1_ (u"ࠫࠬ㿲"),l11lll_l1_ (u"ࠬ࠭㿳"),l11lll_l1_ (u"࠭ࠧ㿴"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㿵"))
		if response.succeeded:
			html = response.content
			l1l111l111ll_l1_ = l1l11llll1ll_l1_.rsplit(l11lll_l1_ (u"ࠨ࠱ࠪ㿶"),1)[0]
			l1llll11lll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㿷"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1llllll111l_l1_ in l1llll11lll1_l1_:
				l1lll1ll1111_l1_ = l1l111l111ll_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ㿸")+addon_id+l11lll_l1_ (u"ࠫ࠴࠭㿹")+addon_id+l11lll_l1_ (u"ࠬ࠳ࠧ㿺")+l1llllll111l_l1_+l11lll_l1_ (u"࠭࠮ࡻ࡫ࡳࠫ㿻")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1llll11ll11_l1_[addon_id] = []
				l1lll11111l1_l1_ = l1l1111l1111_l1_(l1llllll111l_l1_)
				addons[addon_id].append((l1llllll111l_l1_,l1lll11111l1_l1_,l1lll1ll1111_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11lll_l1_ (u"ࠧࠨ㿼"),str(addon_id)+l11lll_l1_ (u"ࠨࠢࠣ࠲ࠥࠦࠧ㿽")+str(addons[addon_id]))
		l1llll11ll11_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㿾"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㿿"),l1llll11ll11_l1_,REGULAR_CACHE)
	return l1llll11ll11_l1_
	l11lll_l1_ (u"ࠦࠧࠨࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬ࠯ࠍࠋࠋࡶࡳࡺࡸࡣࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠫࠐࠎࠎࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࡟ࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡨࡵࡤࡦࡤࡨࡶ࡬࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡳࡩ࡫ࡢࡦࡴࡪ࠲ࡴࡸࡧ࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵ࡢࡳࡣࡱࡧ࡭࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸࡪࡧ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡥࡶࡦࡴࡣࡩ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࡟ࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠯ࡌࡑࡇࡍ࠴ࡸࡡࡸ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠱ࡤࡨࡩࡵ࡮ࡴ࠰ࡻࡱࡱ࠭࡝ࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡦࡧ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠳࠱ࡵࡥࡼ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࠤࠥࠦ䀀")
def l1l1111l1111_l1_(l1llllll111l_l1_):
	l1lll11111l1_l1_ = []
	l1l1llll111_l1_ = l1llllll111l_l1_.split(l11lll_l1_ (u"ࠬ࠴ࠧ䀁"))
	for l1l1111l1l_l1_ in l1l1llll111_l1_:
		parts = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪ䀂"),l1l1111l1l_l1_,re.DOTALL)
		l1l111lll1l1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l111lll1l1_l1_.append(part)
		l1lll11111l1_l1_.append(l1l111lll1l1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ䀃"),str(l1llllll111l_l1_)+l11lll_l1_ (u"ࠨࠢࠣ࠲ࠥࠦࠧ䀄")+str(l1lll11111l1_l1_))
	return l1lll11111l1_l1_
def l1l1llll11l1_l1_(l1lll11111l1_l1_):
	l1llllll111l_l1_ = l11lll_l1_ (u"ࠩࠪ䀅")
	for l1l1111l1l_l1_ in l1lll11111l1_l1_:
		for part in l1l1111l1l_l1_: l1llllll111l_l1_ += str(part)
		l1llllll111l_l1_ += l11lll_l1_ (u"ࠪ࠲ࠬ䀆")
	l1llllll111l_l1_ = l1llllll111l_l1_.strip(l11lll_l1_ (u"ࠫ࠳࠭䀇"))
	return l1llllll111l_l1_
def l1ll1ll1l1ll_l1_(l111ll1111l_l1_):
	# l1l1l111ll11_l1_ not l111l111l1l_l1_ l1l1ll11l11l_l1_ l1l11ll1ll1l_l1_ addons status l1llllll1l1_l1_ l11l1111ll_l1_ l111l1ll11_l1_ l1111111lll_l1_
	#l1l111l11l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ䀈"),l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ䀉"),l11lll_l1_ (u"ࠧࡆࡏࡄࡈࡤࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭䀊"))
	#if l1l111l11l1l_l1_: return l1l111l11l1l_l1_
	l1l111l11l1l_l1_ = {}
	addons = l1lllllll1ll_l1_()
	l111lllll1l_l1_ = l1l1ll11ll1l_l1_(l111ll1111l_l1_)
	for addon_id in l111ll1111l_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1llll11ll11_l1_ = addons[addon_id]
		l1ll11lllll1_l1_,l111lll11l1_l1_,l1l1111111ll_l1_ = l1llll11ll11_l1_[0]
		#l1lll1llll1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠨ䀋")+addon_id+l11lll_l1_ (u"ࠩࠬࠫ䀌"))
		l1lll1llll1l_l1_,l111111ll11_l1_ = l1ll111l11ll_l1_(addon_id)
		l111l11ll1l_l1_,l1ll1l11lll1_l1_ = l111lllll1l_l1_[addon_id]
		l11l111l111_l1_ = l111lll11l1_l1_>l111111ll11_l1_ and l111l11ll1l_l1_
		l1l111111l1l_l1_ = True
		if not l111l11ll1l_l1_: l11l1l11111_l1_ = l11lll_l1_ (u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ䀍")
		elif not l1ll1l11lll1_l1_: l11l1l11111_l1_ = l11lll_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭䀎")
		elif l11l111l111_l1_: l11l1l11111_l1_ = l11lll_l1_ (u"ࠬࡵ࡬ࡥࠩ䀏")
		else:
			l11l1l11111_l1_ = l11lll_l1_ (u"࠭ࡧࡰࡱࡧࠫ䀐")
			l1l111111l1l_l1_ = False
		l1l111l11l1l_l1_[addon_id] = (l1l111111l1l_l1_,l1lll1llll1l_l1_,l111111ll11_l1_,l1ll11lllll1_l1_,l111lll11l1_l1_,l11l1l11111_l1_,l1l1111111ll_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ䀑"),l11lll_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ䀒"),l1l111l11l1l_l1_,REGULAR_CACHE)
	return l1l111l11l1l_l1_
	l11lll_l1_ (u"ࠤࠥࠦࠒࠐࠉࠤ࡫ࡩࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡹࡩࡷ࠲ࡩࡴࡡࡨࡼ࡮ࡹࡴ࠭࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠ࠾ࠢࡹࡩࡷࡹࡩࡰࡰ࠯ࡘࡷࡻࡥ࠭ࡖࡵࡹࡪࠓࠊࠊࠥࡨࡰࡸ࡫࠺ࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲ࠭࡫ࡶࡣࡪࡾࡩࡴࡶ࠯࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡀࠤࠬ࠭ࠬࡇࡣ࡯ࡷࡪ࠲ࡆࡢ࡮ࡶࡩࠒࠐࠉࠤ࡫ࡶࡣࡪࡾࡩࡴࡶࠣࡁࠥ࠮ࡸࡣ࡯ࡦ࠲࡬࡫ࡴࡄࡱࡱࡨ࡛࡯ࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠩࠩࡖࡽࡸࡺࡥ࡮࠰ࡋࡥࡸࡇࡤࡥࡱࡱࠬࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠬࠫ࠮ࡃ࠽࠲ࠫࠐࠎࠎࠩࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࠾ࠨࠩࠐࠎࠎࠩࡩࡧࠢ࡮ࡳࡩ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮࠿࠳࠻࠲࠾࠿࠺ࠡ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨࠥࡃࠠࠩࡺࡥࡱࡨ࠴ࡧࡦࡶࡆࡳࡳࡪࡖࡪࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠫࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰࡌࡷࡊࡴࡡࡣ࡮ࡨࡨ࠭࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪ࠭ࠬ࠯࠽࠾࠳ࠬࠑࠏࠏࠣࡦ࡮ࡶࡩ࠿ࠦࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥࡴ࡯ࡵࠢࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡤࡲࡩࠦ࡮ࡰࡶࠣ࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡬࡮࡭ࡨࡦࡵࡷࡣࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫࡟ࡷࡧࡵࡣࡨࡵ࡭ࡱࡣࡵࡩࠎࠏࠧࠬࡵࡷࡶ࠭࡮ࡩࡨࡪࡨࡷࡹࡥࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡡࡹࡩࡷࡥࡣࡰ࡯ࡳࡥࡷ࡫ࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵࡣࡨࡵ࡭ࡱࡣࡵࡩ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠏࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥ࡯࡭ࡦࠌࠫ࠰ࡹࡴࡳࠪ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡱ࡯ࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡰࡨࡩࡩࡥࡵࡱࡦࡤࡸࡪࠏࠉࠨ࠭ࡶࡸࡷ࠮࡮ࡦࡧࡧࡣࡺࡶࡤࡢࡶࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡷࡹࡧࡴࡶࡵࠌࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡳࡵࡣࡷࡹࡸ࠯ࠩࠎࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪࡺࡪࡸࡳࡪࡱࡱࡷ࠿ࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵ࠭࠰࠭ࠠࠡࠩ࠮ࡷࡹࡸࠨࡪࡵࡢࡩࡽ࡯ࡳࡵࠫ࠮ࠫࠥࠦࠧࠬࡵࡷࡶ࠭࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠫࠬࠑࠏࠏࠢࠣࠤ䀓")
def PROGRESS_UPDATE(l11l1l1ll1_l1_,l1lll1l111ll_l1_,l11111llll1_l1_=l11lll_l1_ (u"ࠪࠫ䀔"),line2=l11lll_l1_ (u"ࠫࠬ䀕"),l1111l11111_l1_=l11lll_l1_ (u"ࠬ࠭䀖")):
	if kodi_version<19: l11l1l1ll1_l1_.update(l1lll1l111ll_l1_,l11111llll1_l1_,line2,l1111l11111_l1_)
	else: l11l1l1ll1_l1_.update(l1lll1l111ll_l1_,l11111llll1_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ䀗")+line2+l11lll_l1_ (u"ࠧ࡝ࡰࠪ䀘")+l1111l11111_l1_)
	return
def l1l1ll1l111l_l1_(l1ll11l11l11_l1_):
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,d)
	# l111l111l1l_l1_ it for this:  function(p,a,c,k,e,r)
	# l1ll1lll1lll_l1_ l1l1l1l11111_l1_:  https://l1ll11l1ll11_l1_.io
	def l1ll1l1llll1_l1_(num,b,l1l1l1ll11ll_l1_=l11lll_l1_ (u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠣ䀙")):
		return ((num == 0) and l1l1l1ll11ll_l1_[0]) or (l1ll1l1llll1_l1_(num // b, b, l1l1l1ll11ll_l1_).lstrip(l1l1l1ll11ll_l1_[0]) + l1l1l1ll11ll_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11lll_l1_ (u"ࠤ࡟ࡠࡧࠨ䀚") + l1ll1l1llll1_l1_(c, a) + l11lll_l1_ (u"ࠥࡠࡡࡨࠢ䀛"),  k[c], p)
		return p
	l1ll11l11l11_l1_ = l1ll11l11l11_l1_.split(l11lll_l1_ (u"ࠫࢂ࠮ࠧ䀜"))[1][:-1]
	l1l1l1l1l111_l1_ = eval(l11lll_l1_ (u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭䀝")+l1ll11l11l11_l1_,{l11lll_l1_ (u"࠭ࡢࡢࡵࡨࡒࠬ䀞"):l1ll1l1llll1_l1_,l11lll_l1_ (u"ࠧࡶࡰࡳࡥࡨࡱࠧ䀟"):unpack})   #,locals())
	return l1l1l1l1l111_l1_
def l1ll1l1l11_l1_(url,l1ll111lll1l_l1_=l11lll_l1_ (u"ࠨࠩ䀠")):
	if l1ll111lll1l_l1_==l11lll_l1_ (u"ࠩ࡯ࡳࡼ࡫ࡲࠨ䀡"): url = re.sub(l11lll_l1_ (u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪ䀢"),lambda l11l11l1111_l1_: l11l11l1111_l1_.group(0).lower(),url)
	elif l1ll111lll1l_l1_==l11lll_l1_ (u"ࠫࡺࡶࡰࡦࡴࠪ䀣"): url = re.sub(l11lll_l1_ (u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬ䀤"),lambda l11l11l1111_l1_: l11l11l1111_l1_.group(0).upper(),url)
	return url
def l1l1ll11ll1l_l1_(l111ll1111l_l1_):
	installed,l1lll11l111l_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1l111ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll1111l_l1_)==1: l1lllllll1l1_l1_ = l11lll_l1_ (u"࠭ࠨࠣࠩ䀥")+l111ll1111l_l1_[0]+l11lll_l1_ (u"ࠧࠣࠫࠪ䀦")
	else: l1lllllll1l1_l1_ = str(tuple(l111ll1111l_l1_))
	cc.execute(l11lll_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨ䀧")+l1lllllll1l1_l1_+l11lll_l1_ (u"ࠩࠣ࠿ࠬ䀨"))
	l11ll1ll1l1_l1_ = cc.fetchall()
	l111lllll1l_l1_ = {}
	for addon_id in l111ll1111l_l1_: l111lllll1l_l1_[addon_id] = (False,False)
	for addon_id,l1lll11l111l_l1_ in l11ll1ll1l1_l1_:
		installed = True
		l1lll11l111l_l1_ = l1lll11l111l_l1_==1
		l111lllll1l_l1_[addon_id] = (installed,l1lll11l111l_l1_)
	conn.close()
	return l111lllll1l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	results = l11lll_l1_ (u"ࠪࠫ䀩")
	if file==l1l1111l11l1_l1_: status = l11111l1ll1_l1_(True,False)
	if os.path.exists(file):
		l11ll11llll_l1_ = open(file,l11lll_l1_ (u"ࠫࡷࡨࠧ䀪")).read()
		if kodi_version>18.99: l11ll11llll_l1_ = l11ll11llll_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䀫"))
		if file==l1l1111l11l1_l1_: results = l11ll11llll_l1_
		else:
			l1llll11111l_l1_ = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ䀬"),l11ll11llll_l1_)
			if l1llll11111l_l1_:
				results = {}
				for key in l1llll11111l_l1_.keys():
					results[key] = []
					for l1ll1ll1ll11_l1_ in l1llll11111l_l1_[key]:
						type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l11lll_l1_ (u"ࠧࠨ䀭"),l11lll_l1_ (u"ࠨࠩ䀮"),l11lll_l1_ (u"ࠩࠪ䀯"),l11lll_l1_ (u"ࠪࠫ䀰"),l11lll_l1_ (u"ࠫࠬ䀱"),l11lll_l1_ (u"ࠬ࠭䀲"),l11lll_l1_ (u"࠭ࠧ䀳"),l11lll_l1_ (u"ࠧࠨ䀴"),l11lll_l1_ (u"ࠨࠩ䀵")
						type = l1ll1ll1ll11_l1_[0]
						name = l1ll1ll1ll11_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1ll1ll1ll11_l1_[2]
						mode = l1ll1ll1ll11_l1_[3]
						l11l_l1_ = l1ll1ll1ll11_l1_[4]
						l1l11l1_l1_ = l1ll1ll1ll11_l1_[5]
						if len(l1ll1ll1ll11_l1_)>6: text = l1ll1ll1ll11_l1_[6]
						if len(l1ll1ll1ll11_l1_)>7: context = l1ll1ll1ll11_l1_[7]
						if len(l1ll1ll1ll11_l1_)>8: l1ll111l111_l1_ = l1ll1ll1ll11_l1_[8]
						if file==favoritesfile: l1l111l1llll_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,l11lll_l1_ (u"ࠩࠪ䀶"),l1ll111l111_l1_
						else: l1l111l1llll_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_
						results[key].append(l1l111l1llll_l1_)
			l11ll11111l_l1_ = str(results)
			if kodi_version>18.99: l11ll11111l_l1_ = l11ll11111l_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䀷"))
			open(file,l11lll_l1_ (u"ࠫࡼࡨࠧ䀸")).write(l11ll11111l_l1_)
	return results
def l1l1l11lll1_l1_(l1l1l1ll1ll_l1_):
	l1l1l1l11ll_l1_ = l1l1l1ll1ll_l1_.split(l11lll_l1_ (u"ࠬ࠳ࠧ䀹"),1)[0]
	l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l11lll_l1_ (u"࠭ࠧ䀺"),l11lll_l1_ (u"ࠧࠨ䀻"),l11lll_l1_ (u"ࠨࠩ䀼")
	if   l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䀽")		:	from l1l111l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ䀾")	:	from l1l1l111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ䀿")		:	from l111111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ䁀")	:	from l111l1l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ䁁")	:	from l1ll11ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ䁂")	: 	from l1l1ll111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ䁃")	:	from l1l1l1ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ䁄")	:	from l11ll1111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡆࡔࡑࡒࡂࠩ䁅")		:	from l111l11l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ䁆")	:	from l1111l11l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧ䁇")	:	from l1lll111ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ䁈")	:	from l1ll1ll1ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ䁉")	:	from l1ll1l1lll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗࠬ䁊"):	from l111ll1lll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ䁋")		:	from l1l1lll11l1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ䁌")		:	from l1ll1ll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ䁍")	:	from l1ll111111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ䁎")	:	from l1lll1l11l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭䁏")	:	from l1lll1ll1lll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ䁐")	:	from l1111l1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ䁑")	:	from l1l111l1l1l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ䁒")	:	from l1111l1ll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ䁓")		:	from l111lllllll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭䁔")	:	from l1l11l11ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ䁕")	:	from l1l11l1ll1l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ䁖"):	from l1l1l1l11_l1_	import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ䁗")	:	from l111ll1lll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ䁘")	:	from l1ll1l1l1l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ䁙"):	from l11lll1l11_l1_	import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ䁚")	:	from l11111l1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭䁛")	:	from l1lllll111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ䁜")	:	from l1lll1ll1ll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ䁝")	:	from l1lll1l111l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ䁞")	:	from l1lll11llll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ䁟")	:	from l1ll1ll11l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ䁠")	:	from l1ll1ll111l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭䁡")	:	from l1l1llllll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭䁢")	:	from l1l1l11l11l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ䁣")	:	from l1llll1111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ䁤")		:	from l1l1l11l111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ䁥")	:	from l1l11l1lll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ䁦")	:	from l11l11ll1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖࠩ䁧")	:	from l1l1l1lll11l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ䁨")	:	from l1ll11111111_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ䁩")	:	from l1l1l111lll1_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ䁪")	:	from l1l1lllll11_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ䁫")	:	from l1l1lll1ll1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭䁬")		:	from l1111l111ll_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ䁭")	:	from l1l1l1111lll_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ䁮")	:	from l1111l1l1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ䁯")	:	from l11l111l11l_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭䁰")	:	from l1l11ll11111_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ䁱")		:	from l1lll111ll1l_l1_			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䁲")	:	from l111llll1l1_l1_		import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,l111ll_l1_ as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭䁳"):	from l111l1llll1_l1_	import MENU as l1l1l1l11l1_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠨࡋࡓࡘ࡛࠭䁴")		:	from IPTV			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,menu_namee as l1l1lll1111_l1_
	elif l1l1l1l11ll_l1_==l11lll_l1_ (u"ࠩࡐ࠷࡚࠭䁵")		:	from M3U			import MENU as l1l1l1l11l1_l1_,SEARCH as l1l1l1ll1l1_l1_,menu_namee as l1l1lll1111_l1_
	return l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1l111111l11_l1_,headers,l1ll_l1_):
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ䁶"),l11lll_l1_ (u"ࠫࠬ䁷"),l11lll_l1_ (u"ࠬ࠭䁸"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䁹"),l11lll_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฽ไ้ส้๋ࠣࠦวๅว้ฮึ์ส๊ࠡๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠢࠩ䁺"))
	#if l1ll111ll1_l1_!=1: return l11lll_l1_ (u"ࠨࠩ䁻")
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䁼"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨ䁽")+l1l111111l11_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ䁾")+str(headers)+l11lll_l1_ (u"ࠬࠦ࡝ࠨ䁿"))
	l11l1l1ll1_l1_ = DIALOG_PROGRESS()
	l11l1l1ll1_l1_.create(l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䂀"),l11lll_l1_ (u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ䂁"))
	l11ll111ll_l1_ = 1024*1024
	l111l1ll11l_l1_ = bytes()
	chunk_size = 1*l11ll111ll_l1_
	import requests
	response = requests.get(l1l111111l11_l1_,stream=True,headers=headers)
	l1l11l1lllll_l1_ = response.headers
	response.close()
	if not l1l11l1lllll_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䂂"),l11lll_l1_ (u"ࠩࠪ䂃"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䂄"),l11lll_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧ䂅"))
		l11l1l1ll1_l1_.close()
	else:
		if l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭䂆") not in list(l1l11l1lllll_l1_.keys()): filesize = 0
		else: filesize = int(l1l11l1lllll_l1_[l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ䂇")])
		l11l1lll1l_l1_ = str(int(1000*filesize/l11ll111ll_l1_)/1000.0)
		l11l11l111_l1_ = int(filesize/chunk_size)+1
		if l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧ䂈") in list(l1l11l1lllll_l1_.keys()) and filesize>l11ll111ll_l1_:
			l1l11lllll1l_l1_ = True
			ranges = []
			l1l1l111l1l1_l1_ = 10
			ranges.append(str(0*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠨ࠯ࠪ䂉")+str(1*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(1*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠩ࠰ࠫ䂊")+str(2*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(2*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ䂋")+str(3*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(3*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠫ࠲࠭䂌")+str(4*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(4*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠬ࠳ࠧ䂍")+str(5*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(5*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"࠭࠭ࠨ䂎")+str(6*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(6*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠧ࠮ࠩ䂏")+str(7*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(7*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠨ࠯ࠪ䂐")+str(8*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(8*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠩ࠰ࠫ䂑")+str(9*filesize//l1l1l111l1l1_l1_-1))
			ranges.append(str(9*filesize//l1l1l111l1l1_l1_)+l11lll_l1_ (u"ࠪ࠱ࠬ䂒"))
			l111ll1ll11_l1_ = float(l11l11l111_l1_)/l1l1l111l1l1_l1_
			l1ll1lllllll_l1_ = l111ll1ll11_l1_/int(1+l111ll1ll11_l1_)
		else:
			l1l11lllll1l_l1_ = False
			l1l1l111l1l1_l1_ = 1
			l1ll1lllllll_l1_ = 1
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䂓"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭䂔")+str(l1l11lllll1l_l1_)+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ䂕")+str(filesize)+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䂖"))
		l11l1lllll_l1_ = 0
		#t1 = time.time()-30
		for l1ll1111ll1l_l1_ in range(l1l1l111l1l1_l1_):
			l1l1ll1ll_l1_ = headers.copy()
			if l1l11lllll1l_l1_: l1l1ll1ll_l1_[l11lll_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ䂗")] = l11lll_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩ䂘")+ranges[l1ll1111ll1l_l1_]
			response = requests.get(l1l111111l11_l1_,stream=True,headers=l1l1ll1ll_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunk_size):
				if l11l1l1ll1_l1_.iscanceled():
					LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䂙"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫ䂚"))
					break
				l11l1lllll_l1_ += l1ll1lllllll_l1_
				PROGRESS_UPDATE(l11l1l1ll1_l1_,100*l11l1lllll_l1_//l11l11l111_l1_,l11lll_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭䂛"),str(int(100*l11l1lllll_l1_*chunk_size//l11ll111ll_l1_)/100.0)+l11lll_l1_ (u"࠭ࠠ࠰ࠢࠪ䂜")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠧࠡࡏࡅࠫ䂝"))
				l111l1ll11l_l1_ += chunk
				#PROGRESS_UPDATE(l11l1l1ll1_l1_,0+int(35*l11l1lllll_l1_/l11l11l111_l1_),l11lll_l1_ (u"ࠨฮ็ฬࠥอไๆๆไࠤฬ๊ัว์ึ๎࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ䂞")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ䂟")+str(l11l1lllll_l1_*chunksize/l11ll111ll_l1_)+l11lll_l1_ (u"ࠪࠤ࠴ࠦࠧ䂠")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ䂡")+time.strftime(l11lll_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ䂢")+l11lll_l1_ (u"࠭࡜࡯ࠩ䂣")+time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠧࠡโࠪ䂤"))
				#l111llllll_l1_ = time.time()
				#l111lll1ll_l1_ = l111llllll_l1_-t1
				#l111lllll1_l1_ = l111lll1ll_l1_/l11l1lllll_l1_
				#l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
				#l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			response.close()
		l11l1l1ll1_l1_.close()
		if len(l111l1ll11l_l1_)<filesize and filesize>0:
			LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䂥"),l11lll_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡰࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡧࡴ࠻ࠢ࡞ࠤࠬ䂦")+str(len(l111l1ll11l_l1_)//l11ll111ll_l1_)+l11lll_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨ䂧")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ䂨"))
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠬ࠭䂩"),l11lll_l1_ (u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫ䂪"),l11lll_l1_ (u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧ䂫"),l11lll_l1_ (u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪ䂬"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䂭"),l11lll_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧ䂮")+str(len(l111l1ll11l_l1_)//l11ll111ll_l1_)+l11lll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪ䂯")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧ䂰"))
			if choice==2: l111l1ll11l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l111111l11_l1_,headers,l1ll_l1_)
			elif choice==1: LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䂱"),l11lll_l1_ (u"ࠧ࠯ࠢࠣࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭䂲"))
			else: return l11lll_l1_ (u"ࠨࠩ䂳")
			if not l111l1ll11l_l1_: return l11lll_l1_ (u"ࠩࠪ䂴")
		else: LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䂵"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠳ࠦࠠࠡࡈ࡬ࡰࡪࠦࡓࡪࡼࡨ࠾ࠥࡡࠠࠨ䂶")+l11l1lll1l_l1_+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࡠࠫ䂷"))
	return l111l1ll11l_l1_
def l1lll11111ll_l1_(script_name):
	# old l1lll11l11l1_l1_ l1ll11l1111l_l1_ l1l1l1l1llll_l1_
	# hit method:    https://l11ll11l111_l1_.google.com/l11llll1ll1_l1_/l1ll1l11llll_l1_/collection/protocol/l1l1l1l1llll_l1_/l1ll1l1l1lll_l1_
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡣࡰ࡯࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠱ࠧࡶ࡬ࡨࡂ࡛ࡁ࠮࠳࠵࠻࠵࠺࠵࠲࠲࠷࠱࠺ࠬࡣࡪࡦࡀࠫ䂸")+l11llll11ll_l1_(32)+l11lll_l1_ (u"ࠧࠧࡶࡀࡩࡻ࡫࡮ࡵࠨࡶࡧࡂ࡫࡮ࡥࠨࡨࡧࡂ࠭䂹")+l11ll111111_l1_+l11lll_l1_ (u"ࠨࠨࡤࡺࡂ࠭䂺")+l11ll111111_l1_+l11lll_l1_ (u"ࠩࠩࡥࡳࡃࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࡥࡎࡆ࡙ࡆࡐࡎࡋࡎࡕࡋࡇࠪࡪࡧ࠽ࠨ䂻")+script_name+l11lll_l1_ (u"ࠪࠪࡪࡲ࠽ࠨ䂼")+str(kodi_version)+l11lll_l1_ (u"ࠫࠫࢀ࠽ࠨ䂽")+l11ll11l1l1_l1_
	#response = l11lll11ll1_l1_(l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䂾"),url,l11lll_l1_ (u"࠭ࠧ䂿"),l11lll_l1_ (u"ࠧࠨ䃀"),l11lll_l1_ (u"ࠨࠩ䃁"),l11lll_l1_ (u"ࠩࠪ䃂"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ䃃"))
	# new l1ll1ll11ll1_l1_ l1ll11l1111l_l1_ 4
	# l1l1l1ll1l11_l1_ test:    https://l111lllll11_l1_-l1llll11ll1_l1_-l111l11l1l1_l1_.google/l1l1lllllll1_l1_/l1llll1l1lll_l1_-l1l1l1l1l11l_l1_
	# l1l1l1ll1l11_l1_ json method:    https://l11ll11l111_l1_.google.com/l11llll1ll1_l1_/l1ll1l11llll_l1_/collection/protocol/l1l1lllllll1_l1_/l1ll11ll111l_l1_/l1l1l1ll1l11_l1_
	# l1l1l1ll1l11_l1_ json method:    https://l11ll11l111_l1_.google.com/l11llll1ll1_l1_/l1ll1l11llll_l1_/collection/protocol/l1l1lllllll1_l1_/l1ll11ll111l_l1_?l1l11ll1111l_l1_=l1l111lll1ll_l1_
	# l1l1l1ll1l11_l1_ hit method:   https://www.l1lll1l1l1ll_l1_.com/l1l1lllllll1_l1_-l1llll1ll11l_l1_-protocol-l1ll1llll11l_l1_
	# l1l1l1ll1l11_l1_ hit method:   https://www.l1lll1l1l1ll_l1_.com/l111l1l1111_l1_-l111ll111ll_l1_-google-l11llll1ll1_l1_-l1llll1ll11l_l1_-protocol-version-2
	# l1l1l1ll1l11_l1_ params:  https://data.l1l11l11ll1l_l1_.com
	# l1l1l1ll111l_l1_ json method
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳ࡩ࡯࡮࠱ࡰࡴ࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡡࡱ࡫ࡢࡷࡪࡩࡲࡦࡶࡀ࠴࠲ࡼ࠱࠶ࡃࡧࡧࡗࡍࡡࡑࡩࡴࡶࡴ࡭࡬࠶࠻ࡎࡅࠫࡳࡥࡢࡵࡸࡶࡪࡳࡥ࡯ࡶࡢ࡭ࡩࡃࡇ࠮ࡔࡓ࠻ࡖ࡟ࡅࡋ࠻ࡊ࠽ࠬ䃄")
	#headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䃅"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩ䃆")}
	#params = {l11lll_l1_ (u"ࠧࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ䃇"):l11ll111111_l1_,l11lll_l1_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡢࡺࡪࡸࡳࡪࡱࡱࠫ䃈"):kodi_version}
	#data = {l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡡ࡬ࡨࠬ䃉"):l11llll11ll_l1_(32),l11lll_l1_ (u"ࠪࡩࡻ࡫࡮ࡵࡵࠪ䃊"):[{l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䃋"):script_name,l11lll_l1_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ䃌"):params}]}
	#response = l11lll11ll1_l1_(l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ䃍"),url,str(data),headers,l11lll_l1_ (u"ࠧࠨ䃎"),l11lll_l1_ (u"ࠨࠩ䃏"),l11lll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ䃐"))
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࡧࡹࡩࡳࡺࡎࡢ࡯ࡨࠑࠏࠏࡡࡱࡲ࡙ࡩࡷࡹࡩࡰࡰࠐࠎࠎࡵࡰࡦࡴࡤࡸ࡮ࡴࡧࡔࡻࡶࡸࡪࡳࡖࡦࡴࡶ࡭ࡴࡴࠍࠋࠋࡸࡥࡵࡼࠍࠋࠋࡸࡷࡪࡸ࡟ࡪࡦࠐࠎࠎࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠐࠎࠎࡶ࡬ࡢࡶࡩࡳࡷࡳ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠎࠌࠌࡩࡻ࡫࡮ࡵࡡࡱࡥࡲ࡫ࠍࠋࠋࠥࠦࠧ䃑")
	# l1l1l1ll111l_l1_ hit method (l11l11ll11_l1_ l11l1l1l11l_l1_ l1l11l1llll1_l1_)
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳ࡩ࡯࡮࠱ࡪ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠳ࠨࡷ࡭ࡩࡃࡇ࠮ࡔࡓ࠻ࡖ࡟ࡅࡋ࠻ࡊ࠽ࠫࡩࡩࡥ࠿ࠪ䃒")+l11llll11ll_l1_(32)+l11lll_l1_ (u"ࠬࠬ࡟ࡴ࠿࠴ࠪࡪࡴ࠽ࠨ䃓")+script_name+l11lll_l1_ (u"࠭ࠦࡶࡲ࠱ࡥࡻࡥࡶࡦࡴࡀࠫ䃔")+l11ll111111_l1_+l11lll_l1_ (u"ࠧࠧࡷࡳ࠲ࡰࡵࡤࡪࡡࡹࡩࡷࡃࠧ䃕")+str(kodi_version)
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡪ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠳ࠨࡷ࡭ࡩࡃࡇ࠮ࡔࡓ࠻ࡖ࡟ࡅࡋ࠻ࡊ࠽ࠫࡥࡤࡣࡩࡀ࠵ࠫࡩࡩࡥ࠿࠴࠼࠺࠼࠰࠵࠺࠷࠽࠼࠴࠱࠷࠻࠳࠵࠹࠻࠴࠶࠹ࠪ䃖")
	#l11ll11l1l1_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲࡫࠴ࡩ࡯࡭࡮ࡨࡧࡹࡅࡶ࠾࠴ࠩࡸ࡮ࡪ࠽ࡈ࠯ࡕࡔ࠼ࡗ࡙ࡆࡌ࠼ࡋ࠾ࠬ࡟ࡥࡤࡪࡁ࠶ࠬࡣࡪࡦࡀࠫ䃗")+str(l11ll11l1l1_l1_)+l11lll_l1_ (u"ࠪ࠲ࠬ䃘")+str(int(time.time()))
	#url += l11lll_l1_ (u"ࠫࠫࡻࡡࡱࡸࡀ࠵࠾࠴࠱ࠧࡦࡷࡁࡐࡕࡄࡊࠧ࠵࠴ࡊࡓࡁࡅࠨࡨࡲࡂࡶࡡࡨࡧࡢࡺ࡮࡫ࡷࠧࡡࡨࡩࡂ࠷ࠦࡶ࡫ࡧࡁ࠷࠸࠲࠳࠯࠵࠶࠷࠸࠭࠴࠵࠶࠷ࠫࡥࡳࡴ࠿࠴ࠫ䃙")
	#response = l11lll11ll1_l1_(l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䃚"),url,l11lll_l1_ (u"࠭ࠧ䃛"),l11lll_l1_ (u"ࠧࠨ䃜"),l11lll_l1_ (u"ࠨࠩ䃝"),l11lll_l1_ (u"ࠩࠪ䃞"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ䃟"))
	# l1l1l1ll111l_l1_ modified (not good l1lll1lll1l1_l1_)
	#l11ll11l1l1_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷ࠳ࡩ࡯࡮࠱ࡪ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠳ࠨࡷ࡭ࡩࡃࡇ࠮ࡔࡓ࠻ࡖ࡟ࡅࡋ࠻ࡊ࠽ࠫࡩࡩࡥ࠿ࠪ䃠")+l11llll11ll_l1_(32)+l11lll_l1_ (u"ࠬࠬ࡟ࡴ࠿࠴ࠪࡪࡴ࠽ࠨ䃡")+script_name+l11lll_l1_ (u"࠭ࠦࡶࡲ࠱ࡥࡻࡥࡶࡦࡴࡀࠫ䃢")+l11ll111111_l1_+l11lll_l1_ (u"ࠧࠧࡷࡤࡴࡻࡃࠧ䃣")+str(kodi_version)+l11lll_l1_ (u"ࠨࠨࡢࡴࡂ࠭䃤")+l11ll11l1l1_l1_
	#l11ll1lllll_l1_ = l11l1ll1111_l1_()
	#l1l1ll11l1l1_l1_ = l11ll1lllll_l1_.split(l11lll_l1_ (u"ࠩ࠯ࠫ䃥"),1)[0]
	return response
def l11l1ll1111_l1_(l1l1ll11l1l1_l1_=l11lll_l1_ (u"ࠪࠫ䃦")):
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡯ࡰ࡭ࡱࡦࡥࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭䃧")
	# l1l1l1l1llll_l1_   url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡱࡹ࡫ࡳ࡮ࡹ࠮ࡢࡲࡳ࠳࡯ࡹ࡯࡯࠱ࠪ䃨")+l1l1ll11l1l1_l1_
	# l11l1ll11l1_l1_   url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡹ࡫ࡳ࠳࡯ࡳ࠰ࡁࡲࡹࡹࡶࡵࡵ࠿࡭ࡷࡴࡴࠦࡧ࡫ࡨࡰࡩࡹ࠽ࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶ࠯ࡧࡴࡻ࡮ࡵࡴࡼ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ䃩")
	l1l1l1111ll1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡴࡶࡵࠫ䃪"),l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ䃫"),l11lll_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭䃬"))
	if l1l1l1111ll1_l1_: return l1l1l1111ll1_l1_
	l1l1ll11l1l1_l1_,l1l1l11l1111_l1_,l1ll1111l11l_l1_,l11l1l111l1_l1_,l1ll1111l111_l1_,l1llll11l111_l1_,timezone = l11lll_l1_ (u"ࠪࠫ䃭"),l11lll_l1_ (u"ࠫࠬ䃮"),l11lll_l1_ (u"ࠬ࠭䃯"),l11lll_l1_ (u"࠭ࠧ䃰"),l11lll_l1_ (u"ࠧࠨ䃱"),l11lll_l1_ (u"ࠨࠩ䃲"),l11lll_l1_ (u"ࠩࠪ䃳")
	url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭䃴")+l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀ࡭ࡵ࠲ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵ࠮ࡦࡳࡺࡴࡴࡳࡻ࠯ࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠮ࡵࡩ࡬࡯࡯࡯࠮ࡦ࡭ࡹࡿࠬࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ䃵")
	headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䃶"):l11lll_l1_ (u"࠭ࠧ䃷")}
	response = l11lll11ll1_l1_(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䃸"),url,l11lll_l1_ (u"ࠨࠩ䃹"),headers,l11lll_l1_ (u"ࠩࠪ䃺"),l11lll_l1_ (u"ࠪࠫ䃻"),l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ䃼"))
	if not response.succeeded: l1lll1ll111l_l1_ = l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ䃽")+l1l1l11l1111_l1_+l11lll_l1_ (u"࠭ࠬࠨ䃾")+l1ll1111l11l_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ䃿")+l1ll1111l111_l1_+l11lll_l1_ (u"ࠨ࠮ࠪ䄀")+l1llll11l111_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ䄁")+timezone
	else:
		html = response.content
		html = re.findall(l11lll_l1_ (u"ࠪࡠࢀ࠴ࠪࡀ࡞ࢀࡠࢂ࠭䄂"),html,re.DOTALL)
		if html:
			html = html[0]
			l11111ll111_l1_ = EVAL(l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䄃"),html)
			if l11lll_l1_ (u"ࠬ࡯ࡰࠨ䄄") in list(l11111ll111_l1_.keys()): l1l1ll11l1l1_l1_ = l11111ll111_l1_[l11lll_l1_ (u"࠭ࡩࡱࠩ䄅")]
			if l11lll_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ䄆") in list(l11111ll111_l1_.keys()): l1l1l11l1111_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫ䄇")]
			if l11lll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ䄈") in list(l11111ll111_l1_.keys()): l1ll1111l11l_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ䄉")]
			if l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ䄊") in list(l11111ll111_l1_.keys()): l11l1l111l1_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ䄋")]
			if l11lll_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭䄌") in list(l11111ll111_l1_.keys()): l1ll1111l111_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ䄍")]
			if l11lll_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭䄎") in list(l11111ll111_l1_.keys()): l1llll11l111_l1_ = l11111ll111_l1_[l11lll_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ䄏")]
			if l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ䄐") in list(l11111ll111_l1_.keys()):
				timezone = l11111ll111_l1_[l11lll_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭䄑")][l11lll_l1_ (u"ࠬࡻࡴࡤࠩ䄒")]
				if timezone[0] not in [l11lll_l1_ (u"࠭࠭ࠨ䄓"),l11lll_l1_ (u"ࠧࠬࠩ䄔")]: timezone = l11lll_l1_ (u"ࠨ࠭ࠪ䄕")+timezone
			l1lll1ll111l_l1_ = l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ䄖")+l1l1l11l1111_l1_+l11lll_l1_ (u"ࠪ࠰ࠬ䄗")+l1ll1111l11l_l1_+l11lll_l1_ (u"ࠫ࠱࠭䄘")+l1ll1111l111_l1_+l11lll_l1_ (u"ࠬ࠲ࠧ䄙")+l1llll11l111_l1_+l11lll_l1_ (u"࠭ࠬࠨ䄚")+timezone
			if kodi_version>18.99: l1lll1ll111l_l1_ = l1lll1ll111l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䄛")).decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ䄜"))
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ䄝"),l11lll_l1_ (u"ࠪࡍࡕࡒࡏࡄࡃࡗࡍࡔࡔࠧ䄞"),l1lll1ll111l_l1_,l1lll1111_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ䄟"),l1lll1ll111l_l1_)
	return l1lll1ll111l_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11lll_l1_ (u"ࠬ࠭䄠"),True
	if search.count(l11lll_l1_ (u"࠭࡟ࠨ䄡"))>=2:
		search,options = search.split(l11lll_l1_ (u"ࠧࡠࠩ䄢"),1)
		options = l11lll_l1_ (u"ࠨࡡࠪ䄣")+options
		if l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ䄤") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䄥"),l11lll_l1_ (u"ࠫࠬ䄦"),search,options)
	return search,options,l1ll_l1_
def l1l111llll11_l1_():
	l1l1ll1llll1_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ䄧"))
	l1ll1l1lllll_l1_ = 0
	if os.path.exists(l1l1ll1llll1_l1_):
		for filename in os.listdir(l1l1ll1llll1_l1_):
			if l11lll_l1_ (u"࠭࠮ࡱࡻࡲࠫ䄨") in filename: continue
			if l11lll_l1_ (u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬ䄩") in filename: continue
			l1l11l11ll_l1_ = os.path.join(l1l1ll1llll1_l1_,filename)
			size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
			l1ll1l1lllll_l1_ += size
	return l1ll1l1lllll_l1_
def l11111l1ll1_l1_(l11llllllll_l1_,l1ll_l1_):
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ䄪")][3]
	user = l11llll11ll_l1_(32)
	l1lll1ll111l_l1_ = l11l1ll1111_l1_()
	l1ll1111l11l_l1_ = l1lll1ll111l_l1_.split(l11lll_l1_ (u"ࠩ࠯ࠫ䄫"))[2]
	l1ll1l1lllll_l1_ = l1l111llll11_l1_()
	payload = {l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䄬"):user,l11lll_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ䄭"):l11ll111111_l1_,l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭䄮"):l1ll1111l11l_l1_,l11lll_l1_ (u"࠭ࡩࡥࡵࠪ䄯"):l1l1ll1ll111_l1_(l1ll1l1lllll_l1_)}
	if not l11llllllll_l1_: DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ䄰"),(l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䄱"),url,payload,l11lll_l1_ (u"ࠩࠪ䄲"),l11lll_l1_ (u"ࠪࠫ䄳"),l11lll_l1_ (u"ࠫࠬ䄴")))
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ䄵"),l11lll_l1_ (u"࠭ࠧ䄶"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䄷"),url,payload,l11lll_l1_ (u"ࠨࠩ䄸"),l11lll_l1_ (u"ࠩࠪ䄹"),l11lll_l1_ (u"ࠪࠫ䄺"),l11lll_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ䄻"),True,True)
	l11l1111ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ䄼"))
	if not l11l1111ll1_l1_: l11l1111ll1_l1_ = l11lll_l1_ (u"࠭ࡎࡆ࡙ࠪ䄽")
	l1l1llll1l1l_l1_ = l11l1111ll1_l1_
	if not response.succeeded: l1l1llll1l1l_l1_ = l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭䄾")
	else:
		l11ll11ll1l_l1_,l1lll1llll11_l1_,l1llll111lll_l1_,l1lll1lllll1_l1_ = l11lll_l1_ (u"ࠨࠩ䄿"),l11lll_l1_ (u"ࠩࠪ䅀"),l11lll_l1_ (u"ࠪࠫ䅁"),[]
		newfile = response.content
		if newfile:
			l1lll1lllll1_l1_ = EVAL(l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䅂"),newfile)
			for l1ll1l111l1l_l1_,l1l1l11l1lll_l1_,message in l1lll1lllll1_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ䅃")).decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䅄"))
				if l1ll1l111l1l_l1_==l11lll_l1_ (u"ࠧ࠱ࠩ䅅"): l11ll11ll1l_l1_ += message+l11lll_l1_ (u"ࠨ࠼࠽ࠫ䅆")
				else: l1lll1llll11_l1_ += message+l11lll_l1_ (u"ࠩ࡟ࡲࠬ䅇")
			l1lll1llll11_l1_ = l1lll1llll11_l1_.strip(l11lll_l1_ (u"ࠪࡠࡳ࠭䅈"))
			l11ll11ll1l_l1_ = l11ll11ll1l_l1_.strip(l11lll_l1_ (u"ࠫ࠿ࡀࠧ䅉"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ䅊"),l11ll11ll1l_l1_)
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ䅋"),l1l1ll1ll111_l1_(now))
		if os.path.exists(l1l1111l11l1_l1_): l1llll111lll_l1_ = open(l1l1111l11l1_l1_,l11lll_l1_ (u"ࠧࡳࡤࠪ䅌")).read()
		if kodi_version>18.99: l1lll1llll11_l1_ = l1lll1llll11_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䅍"))
		if l1lll1llll11_l1_!=l1llll111lll_l1_:
			l1l1llll1l1l_l1_ = l11lll_l1_ (u"ࠩࡑࡉ࡜࠭䅎")
			try: open(l1l1111l11l1_l1_,l11lll_l1_ (u"ࠪࡻࡧ࠭䅏")).write(l1lll1llll11_l1_)
			except: pass
		if l1ll_l1_:
			l1lll1lllll1_l1_ = sorted(l1lll1lllll1_l1_,reverse=True,key=lambda key: int(key[0]))
			l1llll111ll1_l1_ = l11lll_l1_ (u"ࠫࠬ䅐")
			for l1ll1l111l1l_l1_,l1l1l11l1lll_l1_,message in l1lll1lllll1_l1_:
				if kodi_version>18.99: message = message.encode(l11lll_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ䅑")).decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䅒"))
				if l1llll111ll1_l1_: l1llll111ll1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ䅓")
				if l1ll1l111l1l_l1_==l11lll_l1_ (u"ࠨ࠲ࠪ䅔"): continue
				date = message.split(l11lll_l1_ (u"ࠩ࡟ࡲࠬ䅕"))[0]
				l1lll1ll1_l1_ = l11lll_l1_ (u"ࠪࠫ䅖")
				if l1l1l11l1lll_l1_:
					l1lll1ll1_l1_ = l11lll_l1_ (u"ࠫึูวๅหࠣาฬ฻ษࠡๆๆࠤๆ่ืࠨ䅗")
					if kodi_version>18.99: l1lll1ll1_l1_ = l1lll1ll1_l1_.encode(l11lll_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ䅘")).decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䅙"))
				l1llll111ll1_l1_ += message.replace(date,l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ䅚")+date+l1lll1ll1_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䅛"))+l11lll_l1_ (u"ࠩ࡟ࡲࠬ䅜")
			l1llll111ll1_l1_ = escapeUNICODE(l1llll111ll1_l1_)
			l11ll11lll_l1_(l11lll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ䅝"),l11lll_l1_ (u"ࠫึูววๆ้๋ࠣࠦวๅ็หี๊าࠠฦๆ์ࠤู๊สฯั่๎ࠥอไษำ้ห๊าࠧ䅞"),l1llll111ll1_l1_,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭䅟"))
			l1l1llll1l1l_l1_ = l11lll_l1_ (u"࠭ࡏࡍࡆࠪ䅠")
	if l1l1llll1l1l_l1_!=l11l1111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ䅡"),l1l1llll1l1l_l1_)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ䅢"))
	return l1l1llll1l1l_l1_
def l11l1ll1ll_l1_(url,l1l1ll11_l1_=l11lll_l1_ (u"ࠩࠪ䅣")):
	l111lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡺࡳࡽ࡞࠱ࡥࡦࡩࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࡽ࡞࠱ࡻࡪࡨ࡭ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠦࠪ䅤"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111lll11l_l1_: l111lll11l_l1_ = l111lll11l_l1_[0][0]
	else: l111lll11l_l1_ = l11lll_l1_ (u"ࠫࠬ䅥")
	return l111lll11l_l1_
	#elif not l111lll11l_l1_ and l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭䅦") in l1l1ll11_l1_: l111lll11l_l1_ = l11lll_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䅧")
	#elif not l111lll11l_l1_ and l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ䅨") in l1l1ll11_l1_: l111lll11l_l1_ = l11lll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭䅩")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l1l11lll1l1l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1l11lll1l1l_l1_ = False
	l111llllll_l1_ = time.time()
	if l1l11lll1l1l_l1_: resp = l111llllll_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪ䅪"),l11lll_l1_ (u"ࠪࠫ䅫"),l11lll_l1_ (u"ࠫࠬ䅬"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䅭"),l11lll_l1_ (u"࠭ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤ฾๋ไ๋หࠣห้ะๆู์ไࠤฬ๊ย็ࠢยࠥࠬ䅮"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11lll_l1_ (u"ࠧ࠯ࡦࡥࠫ䅯")) and l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠭䅰") in filename:
				l1l1ll111l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,cc = l1l1111l111_l1_(l1l1ll111l_l1_)
				except: return
				cc.execute(l11lll_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬ䅱"))
				cc.execute(l11lll_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭䅲"))
				cc.execute(l11lll_l1_ (u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬ䅳"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䅴"),l11lll_l1_ (u"࠭ࠧ䅵"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䅶"),l11lll_l1_ (u"ࠨฬ่ฮࠥฮๆอษะࠤ฾๋ไ๋หࠣษฺ๊วฮ๋ࠢฮ๋฾๊โࠢฯ้๏฿ࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠡษ็ุ้ะฮะ็ฬࠤๆ๐ࠠศๆหี๋อๅอࠩ䅷"))
	return
def l1ll1lllll1l_l1_(script_name,l1lll11l1l11_l1_):
	l1lll1ll1l11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ䅸")][8]
	l1lll1ll1ll1_l1_ = l11llll11ll_l1_(32)
	l1llll1lllll_l1_ = {l11lll_l1_ (u"ࠪ࡭ࡩࡹࠧ䅹"):l1lll11l1l11_l1_,l11lll_l1_ (u"ࠫࡺࡹࡲࠨ䅺"):l1lll1ll1ll1_l1_,l11lll_l1_ (u"ࠬࡼࡥࡳࠩ䅻"):l11ll111111_l1_,l11lll_l1_ (u"࠭ࡳࡤࡴࠪ䅼"):script_name}
	l1l11ll1llll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䅽"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䅾")}
	l1111lllll1_l1_ = l1lllll111_l1_(l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䅿"),l1lll1ll1l11_l1_,l1llll1lllll_l1_,l1l11ll1llll_l1_)
	if l1111lllll1_l1_ and kodi_version>18.99: l1111lllll1_l1_ = l1111lllll1_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䆀"))
	try: l1l1llll11ll_l1_ = EVAL(l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䆁"),l1111lllll1_l1_)
	except: l1l1llll11ll_l1_ = {l11lll_l1_ (u"ࠬ࡯ࡤࡴࠩ䆂"):l11lll_l1_ (u"࠭ࠧ䆃"),l11lll_l1_ (u"ࠧ࡮ࡵࡪࠫ䆄"):l11lll_l1_ (u"ࠨࠩ䆅"),l11lll_l1_ (u"ࠩࡰࡥࡽ࠭䆆"):l11lll_l1_ (u"ࠪࠫ䆇"),l11lll_l1_ (u"ࠫࡨࡴࡴࠨ䆈"):l11lll_l1_ (u"ࠬ࠭䆉")}
	l111l1l1l11_l1_ = l1l1llll11ll_l1_[l11lll_l1_ (u"࠭ࡩࡥࡵࠪ䆊")]
	l1111111111_l1_ = l1l1llll11ll_l1_[l11lll_l1_ (u"ࠧࡤࡰࡷࠫ䆋")]
	l1ll111l11l1_l1_ = l1l1llll11ll_l1_[l11lll_l1_ (u"ࠨ࡯ࡤࡼࠬ䆌")]
	l1l111l1l1l1_l1_ = l1l1llll11ll_l1_[l11lll_l1_ (u"ࠩࡰࡷ࡬࠭䆍")]
	settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡴࡦࡵࡷ࡭ࡳ࡭࠮࡮ࡣࡻ࡭ࡲࡻ࡭ࠨ䆎"),l1ll111l11l1_l1_)
	settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡵࡧࡶࡸ࡮ࡴࡧ࠯ࡥࡲࡹࡳࡺࠧ䆏"),l1111111111_l1_)
	return l111l1l1l11_l1_,int(l1111111111_l1_),int(l1ll111l11l1_l1_),l1l111l1l1l1_l1_
def l11ll1ll11l_l1_(script_name):
	if not l11l1llll1l_l1_(l11lll_l1_ (u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪ䆐")): return False
	l1111111111_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡷࡩࡸࡺࡩ࡯ࡩ࠱ࡧࡴࡻ࡮ࡵࠩ䆑"))
	l1ll111l11l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡸࡪࡹࡴࡪࡰࡪ࠲ࡲࡧࡸࡪ࡯ࡸࡱࠬ䆒"))
	l1111111111_l1_ = 0 if not l1111111111_l1_ else int(l1111111111_l1_)
	l1ll111l11l1_l1_ = 0 if not l1ll111l11l1_l1_ else int(l1ll111l11l1_l1_)
	if not l1ll111l11l1_l1_ or not l1111111111_l1_ or l1111111111_l1_>l1ll111l11l1_l1_:
		l111l1l1l11_l1_,l1111111111_l1_,l1ll111l11l1_l1_,l1l111l1l1l1_l1_ = l1ll1lllll1l_l1_(script_name,l11lll_l1_ (u"ࠨࠩ䆓"))
		if l1111111111_l1_>l1ll111l11l1_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䆔"),l11lll_l1_ (u"ࠪࠫ䆕"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䆖"),l1l111l1l1l1_l1_)
			return False
	l1l1ll111l1l_l1_ = False
	l11111l111l_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭䆗"),l11lll_l1_ (u"࠭ࠧ䆘"),l11lll_l1_ (u"ࠧࠨ䆙"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䆚"),l11lll_l1_ (u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึ้าࠦไไࠢหฮูเ๊ๅࠢࠪ䆛")+str(l1ll111l11l1_l1_)+l11lll_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢๆฺ่ࠥ็าࠢหำํ์ࠠหสิ฽ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไ้ࠡำหࠥอไโ์า๎ํࠦฟࠢࠢ࡟ࡲࡡࡴ่ࠠาสࠤ์๎ࠠศๆไ๎ิ๐่ࠡำๅ้࠿ࠦࠠࠨ䆜")+str(l1111111111_l1_))
	if l11111l111l_l1_:
		l1l1111l11ll_l1_ = l1l1ll1ll111_l1_(now,l11lll_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ䆝"))
		l111l1l1l11_l1_,l1111111111_l1_,l1ll111l11l1_l1_,l1l111l1l1l1_l1_ = l1ll1lllll1l_l1_(script_name,l1l1111l11ll_l1_)
		if not l111l1l1l11_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䆞"),l11lll_l1_ (u"࠭ࠧ䆟"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䆠"),l1l111l1l1l1_l1_)
			return False
		l1l1111l111l_l1_ = l1lll1111l11_l1_(int(l111l1l1l11_l1_),l11lll_l1_ (u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ䆡"))
		l1l1111l111l_l1_ = int(l1l1111l111l_l1_)
		l1111111111_l1_ = l1l1111l111l_l1_//now
		l1l11l11lll1_l1_ = l1l1111l111l_l1_/l1111111111_l1_-now
		if 0<l1l11l11lll1_l1_<10:
			l1l1ll111l1l_l1_ = True
			settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡺࡥࡴࡶ࡬ࡲ࡬࠴ࡣࡰࡷࡱࡸࠬ䆢"),str(l1111111111_l1_+1))
		else: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䆣"),l11lll_l1_ (u"ࠫࠬ䆤"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䆥"),l1l111l1l1l1_l1_)
	return l1l1ll111l1l_l1_
def l1l1ll1lll11_l1_(word):
	if l11lll_l1_ (u"࡛࠭ࠨ䆦") in word and l11lll_l1_ (u"ࠧ࡞ࠩ䆧") in word:
		l111ll11lll_l1_ = [l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䆨"),l11lll_l1_ (u"ࠩ࡞࠳ࡗ࡚ࡌ࡞ࠩ䆩"),l11lll_l1_ (u"ࠪ࡟࠴ࡒࡅࡇࡖࡠࠫ䆪"),l11lll_l1_ (u"ࠫࡠ࠵ࡒࡊࡉࡋࡘࡢ࠭䆫"),l11lll_l1_ (u"ࠬࡡ࠯ࡄࡇࡑࡘࡊࡘ࡝ࠨ䆬"),l11lll_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ䆭"),l11lll_l1_ (u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠧ䆮"),l11lll_l1_ (u"ࠨ࡝ࡕࡍࡌࡎࡔ࡞ࠩ䆯"),l11lll_l1_ (u"ࠩ࡞ࡇࡊࡔࡔࡆࡔࡠࠫ䆰")]
		l1l1l11111l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕࠤ࠳࠰࠿࡝࡟ࠪ䆱"),word,re.DOTALL)
		l111l1l111l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡡࡡࡃࡐࡎࡒࡖࠨࠩࠣ࠯ࠬࡂࡠࡢ࠭䆲"),word,re.DOTALL)
		l1l1l11l11ll_l1_ = l111ll11lll_l1_+l1l1l11111l1_l1_+l111l1l111l_l1_
		for tag in l1l1l11l11ll_l1_: word = word.replace(tag,l11lll_l1_ (u"ࠬ࠭䆳"))
	return word
def l1ll1l11l111_l1_(l11l1l11lll_l1_,l1lll11ll1ll_l1_,l1ll111ll1ll_l1_,l1l1l1ll1l1l_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll111l1_l1_,l1111l1ll11_l1_,l1l11l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࠧ䆴"),0,15000
	l11l1l11lll_l1_ = l11l1l11lll_l1_.replace(l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࠨ䆵"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠤࠥࠦࠫ䆶"))
	l1l111l1ll1l_l1_ = PIL.ImageFont.truetype(l1lll1l1111l_l1_,size=l1lll11ll1ll_l1_)
	l1ll111ll1ll_l1_ -= l1lll11ll1ll_l1_*2
	txt = PIL.Image.new(l11lll_l1_ (u"ࠩࡕࡋࡇࡇࠧ䆷"),(l1ll111ll1ll_l1_,99),(255,255,255,0))
	l1llllll1l1l_l1_ = PIL.ImageDraw.Draw(txt)
	for l1l11llll1l1_l1_ in l11l1l11lll_l1_.splitlines():
		l1111l1ll11_l1_ += l1l1l1ll1l1l_l1_
		l1lll11lllll_l1_,newline = 0,l11lll_l1_ (u"ࠪࠫ䆸")
		for word in l1l11llll1l1_l1_.split(l11lll_l1_ (u"ࠫࠥ࠭䆹")):
			l1lllll111l1_l1_ = l1l1ll1lll11_l1_(l11lll_l1_ (u"ࠬࠦࠧ䆺")+word)
			l1l1l11ll111_l1_,l1lllll1l11l_l1_ = l1llllll1l1l_l1_.textsize(l1lllll111l1_l1_,font=l1l111l1ll1l_l1_)
			if l1lll11lllll_l1_+l1l1l11ll111_l1_<l1ll111ll1ll_l1_:
				if not newline: newline += word
				else: newline += l11lll_l1_ (u"࠭ࠠࠨ䆻")+word
				l1lll11lllll_l1_ += l1l1l11ll111_l1_
			else:
				if l1l1l11ll111_l1_<l1ll111ll1ll_l1_:
					newline += l11lll_l1_ (u"ࠧ࡝ࡰࠣࠫ䆼")+word
					l1111l1ll11_l1_ += l1l1l1ll1l1l_l1_
					l1lll11lllll_l1_ = l1l1l11ll111_l1_
				else:
					while l1l1l11ll111_l1_>l1ll111ll1ll_l1_:
						for l11l1lllll_l1_ in range(1,len(l11lll_l1_ (u"ࠨࠢࠪ䆽")+word),1):
							l1lllllll111_l1_ = l11lll_l1_ (u"ࠩࠣࠫ䆾")+word[:l11l1lllll_l1_]
							l11111l1ll_l1_ = word[l11l1lllll_l1_:]
							l1l11l11l11l_l1_ = l1l1ll1lll11_l1_(l1lllllll111_l1_)
							l111l1ll1l1_l1_,l1llll11ll1l_l1_ = l1llllll1l1l_l1_.textsize(l1l11l11l11l_l1_,font=l1l111l1ll1l_l1_)
							if l1lll11lllll_l1_+l111l1ll1l1_l1_>l1ll111ll1ll_l1_:
								l1ll11111ll1_l1_ = l1l1l11ll111_l1_-l111l1ll1l1_l1_
								newline += l1lllllll111_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭䆿")
								l1111l1ll11_l1_ += l1l1l1ll1l1l_l1_
								l1l1l11ll111_l1_ = l1ll11111ll1_l1_
								if l1ll11111ll1_l1_>l1ll111ll1ll_l1_:
									l1lll11lllll_l1_ = 0
									word = l11111l1ll_l1_
								else:
									l1lll11lllll_l1_ = l1ll11111ll1_l1_
									newline += l11111l1ll_l1_
								break
				if l1111l1ll11_l1_>l1l11l1ll1ll_l1_: break
		l111ll111l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ䇀")+newline
		if l1111l1ll11_l1_>l1l11l1ll1ll_l1_: break
	l111ll111l1_l1_ = l111ll111l1_l1_[1:]
	l111ll111l1_l1_ = l111ll111l1_l1_.replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠨࠩࠣࠨ䇁"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࠧ䇂"))
	return l111ll111l1_l1_
def l1111lll1l1_l1_(text):
	text = text.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ䇃"),l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ䇄"))
	text = text.replace(l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ䇅"),l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫ࡲࡵ࡮ࡢࠫ䇆"))
	text = text.replace(l11lll_l1_ (u"ࠫࡠࡒࡅࡇࡖࡠࠫ䇇"),l11lll_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦ࡮ࡨࡪࡹࡥࠧ䇈"))
	text = text.replace(l11lll_l1_ (u"࡛࠭ࡓࡋࡊࡌ࡙ࡣࠧ䇉"),l11lll_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡶ࡮࡭ࡨࡵࡡࠪ䇊"))
	text = text.replace(l11lll_l1_ (u"ࠨ࡝ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ䇋"),l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭䇌"))
	text = text.replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䇍"),l11lll_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡩࡳࡪࡣࡰ࡮ࡲࡶࡤ࠭䇎"))
	l1ll1l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦࠨ࠯ࠬࡂ࠭ࡡࡣࠧ䇏"),text,re.DOTALL)
	for l1l1llllllll_l1_ in l1ll1l1lll11_l1_: text = text.replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࠧ䇐")+l1l1llllllll_l1_+l11lll_l1_ (u"ࠧ࡞ࠩ䇑"),l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡧࡴࡲ࡯ࡳࠩ䇒")+l1l1llllllll_l1_+l11lll_l1_ (u"ࠩࡢࠫ䇓"))
	return text
def l1l11l1l1ll1_l1_(l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text,profile,l111l1lllll_l1_,l1l1lll1llll_l1_,l1l1ll11ll11_l1_):
	l1ll1llll1ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ䇔"))
	if l1ll1llll1ll_l1_:
		results = LANGUAGE_TRANSLATE([l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text])
		if results: l1llll11llll_l1_,l1l11lllllll_l1_,l1llll1l1l11_l1_,header,text = results
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䇕"))
		header = header.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䇖"))
		l1llll11llll_l1_ = l1llll11llll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䇗"))
		l1l11lllllll_l1_ = l1l11lllllll_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䇘"))
		l1llll1l1l11_l1_ = l1llll1l1l11_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䇙"))
	l1lllll1ll1l_l1_ = 5
	l1l111l1l11l_l1_ = 20
	l1ll11llll11_l1_ = 20
	l1ll1111l1ll_l1_ = 0
	l11l1l1l1l1_l1_ = l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䇚")
	l1l11l1l1111_l1_ = 0
	l1l11ll11ll1_l1_ = 19
	l1111l1l1ll_l1_ = 30
	l1ll11ll1l1l_l1_ = 8
	l1ll111111ll_l1_ = True
	l1l1l1111111_l1_ = 375
	l1l111ll1ll1_l1_ = 410
	l1lll111l1ll_l1_ = 50
	l1l1l1ll1lll_l1_ = 280
	l1llll111l11_l1_ = 28
	l1l11l11l111_l1_ = 5
	l1lll111ll11_l1_ = 0
	l1ll111ll1l1_l1_ = 31
	l111111l1ll_l1_ = [36,32,28]
	if profile in [l11lll_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ䇛"),l11lll_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ䇜")]:
		if profile==l11lll_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡹࡽ࡯ࡩࡣ࡯ࡪࡸ࠭䇝"):
			l11l1l11l11_l1_ = l11lll_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ䇞")
			l11l1l1l1l1_l1_ = l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭䇟")
			l1ll111111ll_l1_ = True
			l1ll1111l1ll_l1_ = 10
		else:
			l11l1l11l11_l1_ = 97+20
			l11l1l1l1l1_l1_ = l11lll_l1_ (u"ࠨ࡮ࡨࡪࡹ࠭䇠")
			l1ll111111ll_l1_ = False
		l111111l1ll_l1_ = [33,33,33]
		l1ll11llll11_l1_ = 20
		l1l111l1l11l_l1_ = 0
		l1111l1l1ll_l1_ = 20
		l1l11ll11ll1_l1_ = 25+10
	elif profile==l11lll_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭䇡"): l111111l1ll_l1_ = [28,24,20] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ䇢"): l111111l1ll_l1_ = [32,28,24] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭䇣"): l111111l1ll_l1_ = [36,32,28] ; l11l1l11l11_l1_ = 500
	elif profile==l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ䇤"): l11l1l11l11_l1_ = 740
	elif profile==l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ䇥"): l11l1l11l11_l1_ = l11lll_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭䇦")
	elif profile==l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭䇧"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = 740
	elif profile==l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ䇨"): l111111l1ll_l1_ = [28,23,18] ; l11l1l11l11_l1_ = l11lll_l1_ (u"࡙ࠪࡕࡖࡅࡓࠩ䇩")
	l1lll11ll111_l1_ = l111111l1ll_l1_[0]
	l11111ll1ll_l1_ = l111111l1ll_l1_[1]
	l11l11llll1_l1_ = l111111l1ll_l1_[2]
	l1lll1l111l1_l1_ = PIL.ImageFont.truetype(l1lll1l1111l_l1_,size=l1lll11ll111_l1_)
	l1ll1l1111l1_l1_ = PIL.ImageFont.truetype(l1lll1l1111l_l1_,size=l11111ll1ll_l1_)
	l1ll1l1ll1ll_l1_ = PIL.ImageFont.truetype(l1lll1l1111l_l1_,size=l11l11llll1_l1_)
	txt = PIL.Image.new(l11lll_l1_ (u"ࠫࡗࡍࡂࡂࠩ䇪"),(100,100),(255,255,255,0))
	l1llllll1l1l_l1_ = PIL.ImageDraw.Draw(txt)
	l1lllll11l1l_l1_,l1l1ll1lllll_l1_ = l1llllll1l1l_l1_.textsize(l11lll_l1_ (u"ࠬࡎࡈࡉࠢࡅࡆࡇࠦ࠸࠹࠺ࠣ࠴࠵࠶ࠧ䇫"),font=l1ll1l1111l1_l1_)
	l1l11lllll11_l1_,l1llll11l1l1_l1_ = l1llllll1l1l_l1_.textsize(l11lll_l1_ (u"࠭ࡈࡉࡊࠣࡆࡇࡈࠠ࠹࠺࠻ࠤ࠵࠶࠰ࠨ䇬"),font=l1lll1l111l1_l1_)
	l1l11l1l11l1_l1_ = header.count(l11lll_l1_ (u"ࠧ࡝ࡰࠪ䇭"))+1
	l1l1ll1l1111_l1_ = l1l111l1l11l_l1_+l1l11l1l11l1_l1_*(l1llll11l1l1_l1_+l1ll1111l1ll_l1_)-l1ll1111l1ll_l1_
	l1l11l1lll11_l1_ = {l11lll_l1_ (u"ࠨࡦࡨࡰࡪࡺࡥࡠࡪࡤࡶࡦࡱࡡࡵࠩ䇮"):False,l11lll_l1_ (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡢࡰ࡮࡭ࡡࡵࡷࡵࡩࡸ࠭䇯"):True,l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࠣࡐࡎࡍࡁࡕࡗࡕࡉࠥࡇࡌࡍࡃࡋࠫ䇰"):False}
	l111l1l1lll_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1l11l1lll11_l1_)
	if text:
		l11l11lll11_l1_ = l1l1lll1llll_l1_-l1111l1l1ll_l1_*2
		l1l11ll11l11_l1_ = l1l1ll1lllll_l1_+l1ll11ll1l1l_l1_
		l1l1llll1lll_l1_ = l111l1l1lll_l1_.reshape(text)
		if l1ll111111ll_l1_:
			l1l11111l11l_l1_ = l1ll1l11l111_l1_(l1l1llll1lll_l1_,l11111ll1ll_l1_,l11l11lll11_l1_,l1l11ll11l11_l1_)
			l1ll1lll1l1l_l1_ = l1l1ll1lll11_l1_(l1l11111l11l_l1_)
			l1l1llll111l_l1_ = l1ll1lll1l1l_l1_.count(l11lll_l1_ (u"ࠫࡡࡴࠧ䇱"))+1
			if l1l1llll111l_l1_<6:
				#l1l1l11111ll_l1_ = int(0.8*l11l11lll11_l1_) if l1l1llll111l_l1_<4 else int(0.9*l11l11lll11_l1_)
				l1l1l11111ll_l1_ = l11l11lll11_l1_
				l1l11111l11l_l1_ = l1ll1l11l111_l1_(l1l1llll1lll_l1_,l11111ll1ll_l1_,l1l1l11111ll_l1_,l1l11ll11l11_l1_)
				l1ll1lll1l1l_l1_ = l1l1ll1lll11_l1_(l1l11111l11l_l1_)
				l1l1llll111l_l1_ = l1ll1lll1l1l_l1_.count(l11lll_l1_ (u"ࠬࡢ࡮ࠨ䇲"))+1
			l111lll1ll1_l1_ = l1l11ll11ll1_l1_+l1l1llll111l_l1_*l1l11ll11l11_l1_-l1ll11ll1l1l_l1_
		else:
			l111lll1ll1_l1_ = l1l11ll11ll1_l1_+l1l1ll1lllll_l1_
			l1ll1lll1l1l_l1_ = l1l1llll1lll_l1_.split(l11lll_l1_ (u"࠭࡜࡯ࠩ䇳"))[0]
			l1l11111l11l_l1_ = l1l1llll1lll_l1_.split(l11lll_l1_ (u"ࠧ࡝ࡰࠪ䇴"))[0]
	else: l111lll1ll1_l1_ = l1l11ll11ll1_l1_
	l1ll111l111l_l1_ = l1lll111ll11_l1_+l1ll111ll1l1_l1_
	if l1l1ll11ll11_l1_:
		l1l1l1l1111l_l1_ = l1l111ll1ll1_l1_-l1l1l1111111_l1_
		l1ll111l111l_l1_ += l1l1l1l1111l_l1_
	else: l1l1l1l1111l_l1_ = 0
	if l1llll11llll_l1_ or l1l11lllllll_l1_ or l1llll1l1l11_l1_: l1ll111l111l_l1_ += l1lll111l1ll_l1_
	if l11l1l11l11_l1_!=l11lll_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ䇵"): l1111111ll1_l1_ = l11l1l11l11_l1_
	else: l1111111ll1_l1_ = l1l1ll1l1111_l1_+l111lll1ll1_l1_+l1ll111l111l_l1_
	l1ll1ll1l11l_l1_ = l1111111ll1_l1_-l1l1ll1l1111_l1_-l1ll111l111l_l1_-l1l11ll11ll1_l1_
	txt = PIL.Image.new(l11lll_l1_ (u"ࠩࡕࡋࡇࡇࠧ䇶"),(l1l1lll1llll_l1_,l1111111ll1_l1_),(255,255,255,0))
	l1llllll1l1l_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1l11lllllll_l1_ and l1llll11llll_l1_ and l1llll1l1l11_l1_:
		l1llll111l11_l1_ += 105
		l1l11l11l111_l1_ -= 110
	if header:
		l1lllll1lll1_l1_ = l1l111l1l11l_l1_
		header = bidi.algorithm.get_display(l111l1l1lll_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1l1lllll1ll_l1_ = l1llllll1l1l_l1_.textsize(line,font=l1lll1l111l1_l1_)
				if l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ䇷"): l1l1l111l111_l1_ = l1lllll1ll1l_l1_+(l1l1lll1llll_l1_-width)/2
				elif l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ䇸"): l1l1l111l111_l1_ = l1lllll1ll1l_l1_+l1l1lll1llll_l1_-width-l1ll11llll11_l1_
				elif l11l1l1l1l1_l1_==l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ䇹"): l1l1l111l111_l1_ = l1lllll1ll1l_l1_+l1ll11llll11_l1_
				l1llllll1l1l_l1_.text((l1l1l111l111_l1_,l1lllll1lll1_l1_),line,font=l1lll1l111l1_l1_,fill=l11lll_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭䇺"))
			l1lllll1lll1_l1_ += l1lll11ll111_l1_+l1ll1111l1ll_l1_
	if l1llll11llll_l1_ or l1l11lllllll_l1_ or l1llll1l1l11_l1_:
		l1llll111l1l_l1_ = l1l1ll1l1111_l1_+l1ll1ll1l11l_l1_+l1l11ll11ll1_l1_+l1l1l1l1111l_l1_+l1lll111ll11_l1_
		if l1llll11llll_l1_:
			l1llll11llll_l1_ = bidi.algorithm.get_display(l111l1l1lll_l1_.reshape(l1llll11llll_l1_))
			l1l1lll11l11_l1_,l111111111l_l1_ = l1llllll1l1l_l1_.textsize(l1llll11llll_l1_,font=l1ll1l1ll1ll_l1_)
			l111111l1l1_l1_ = l1llll111l11_l1_+0*(l1l11l11l111_l1_+l1l1l1ll1lll_l1_)+(l1l1l1ll1lll_l1_-l1l1lll11l11_l1_)/2
			l1llllll1l1l_l1_.text((l111111l1l1_l1_,l1llll111l1l_l1_),l1llll11llll_l1_,font=l1ll1l1ll1ll_l1_,fill=l11lll_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ䇻"))
		if l1l11lllllll_l1_:
			l1l11lllllll_l1_ = bidi.algorithm.get_display(l111l1l1lll_l1_.reshape(l1l11lllllll_l1_))
			l1ll11ll1ll1_l1_,l1ll111lllll_l1_ = l1llllll1l1l_l1_.textsize(l1l11lllllll_l1_,font=l1ll1l1ll1ll_l1_)
			l11111ll1l1_l1_ = l1llll111l11_l1_+1*(l1l11l11l111_l1_+l1l1l1ll1lll_l1_)+(l1l1l1ll1lll_l1_-l1ll11ll1ll1_l1_)/2
			l1llllll1l1l_l1_.text((l11111ll1l1_l1_,l1llll111l1l_l1_),l1l11lllllll_l1_,font=l1ll1l1ll1ll_l1_,fill=l11lll_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ䇼"))
		if l1llll1l1l11_l1_:
			l1llll1l1l11_l1_ = bidi.algorithm.get_display(l111l1l1lll_l1_.reshape(l1llll1l1l11_l1_))
			l111l11l111_l1_,l11l11lllll_l1_ = l1llllll1l1l_l1_.textsize(l1llll1l1l11_l1_,font=l1ll1l1ll1ll_l1_)
			l1lll111l111_l1_ = l1llll111l11_l1_+2*(l1l11l11l111_l1_+l1l1l1ll1lll_l1_)+(l1l1l1ll1lll_l1_-l111l11l111_l1_)/2
			l1llllll1l1l_l1_.text((l1lll111l111_l1_,l1llll111l1l_l1_),l1llll1l1l11_l1_,font=l1ll1l1ll1ll_l1_,fill=l11lll_l1_ (u"ࠩࡼࡩࡱࡲ࡯ࡸࠩ䇽"))
	if text:
		l1l111l1111l_l1_,l111l11llll_l1_ = [],[]
		l1l11111l11l_l1_ = l1111lll1l1_l1_(l1l11111l11l_l1_)
		l1l11ll11l1l_l1_ = l1l11111l11l_l1_.split(l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ䇾"))
		for l1l111llllll_l1_ in l1l11ll11l1l_l1_:
			l111llll1ll_l1_ = l111l1lllll_l1_
			if   l11lll_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭䇿") in l1l111llllll_l1_: l111llll1ll_l1_ = l11lll_l1_ (u"ࠬࡲࡥࡧࡶࠪ䈀")
			elif l11lll_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ䈁") in l1l111llllll_l1_: l111llll1ll_l1_ = l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭䈂")
			elif l11lll_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ䈃") in l1l111llllll_l1_: l111llll1ll_l1_ = l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ䈄")
			l11l11111ll_l1_ = l1l111llllll_l1_
			l111ll11lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࠱࠮ࡄࡥࠧ䈅"),l1l111llllll_l1_,re.DOTALL)
			for tag in l111ll11lll_l1_: l11l11111ll_l1_ = l11l11111ll_l1_.replace(tag,l11lll_l1_ (u"ࠫࠬ䈆"))
			if l11l11111ll_l1_==l11lll_l1_ (u"ࠬ࠭䈇"): width,l1l1lllll1ll_l1_ = 0,l1l11ll11l11_l1_
			else: width,l1l1lllll1ll_l1_ = l1llllll1l1l_l1_.textsize(l11l11111ll_l1_,font=l1ll1l1111l1_l1_)
			if   l111llll1ll_l1_==l11lll_l1_ (u"࠭࡬ࡦࡨࡷࠫ䈈"): l1lll1ll11ll_l1_ = l1l11l1l1111_l1_+l1111l1l1ll_l1_
			elif l111llll1ll_l1_==l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭䈉"): l1lll1ll11ll_l1_ = l1l11l1l1111_l1_+l1111l1l1ll_l1_+l11l11lll11_l1_-width
			elif l111llll1ll_l1_==l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ䈊"): l1lll1ll11ll_l1_ = l1l11l1l1111_l1_+l1111l1l1ll_l1_+(l11l11lll11_l1_-width)/2
			if l1lll1ll11ll_l1_<l1111l1l1ll_l1_: l1lll1ll11ll_l1_ = l1l11l1l1111_l1_+l1111l1l1ll_l1_
			l1l111l1111l_l1_.append(l1lll1ll11ll_l1_)
			l111l11llll_l1_.append(width)
		l1lll1ll11ll_l1_ = l1l111l1111l_l1_[0]
		l1l1l1111l1l_l1_ = l1l11111l11l_l1_.split(l11lll_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࠨ䈋"))
		l11l111lll1_l1_ = (255,255,255,255)
		l1ll1l111lll_l1_ = l11l111lll1_l1_
		l1l11ll111l1_l1_,l1ll11l1lll1_l1_ = 0,0
		l1lll1111ll1_l1_ = False
		l1llll1ll1ll_l1_ = 0
		l1l11l1l111l_l1_ = l1l1ll1l1111_l1_+l1l11ll11ll1_l1_/2
		if l111lll1ll1_l1_<(l1ll1ll1l11l_l1_+l1l11ll11ll1_l1_):
			l1lllll1l1l1_l1_ = (l1ll1ll1l11l_l1_+l1l11ll11ll1_l1_-l111lll1ll1_l1_)/2
			l1l11l1l111l_l1_ = l1l1ll1l1111_l1_+l1l11ll11ll1_l1_+l1lllll1l1l1_l1_-l1l1ll1lllll_l1_/2
		for line in l1l1l1111l1l_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1l1l11lll11_l1_ = line.split(l11lll_l1_ (u"ࠪࡣࡳ࡫ࡷ࡭࡫ࡱࡩࡤ࠭䈌"),1)
			l1l1l11lll1l_l1_ = line.split(l11lll_l1_ (u"ࠫࡤࡴࡥࡸࡥࡲࡰࡴࡸࠧ䈍"),1)
			l1l1l11llll1_l1_ = line.split(l11lll_l1_ (u"ࠬࡥࡥ࡯ࡦࡦࡳࡱࡵࡲࡠࠩ䈎"),1)
			l1ll1l1l1l1l_l1_ = line.split(l11lll_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷࡺ࡬ࡠࠩ䈏"),1)
			l1ll1l1ll111_l1_ = line.split(l11lll_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ䈐"),1)
			l1ll1l1ll11l_l1_ = line.split(l11lll_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫ࡲࡪࡩ࡫ࡸࡤ࠭䈑"),1)
			l1l1l11ll1ll_l1_ = line.split(l11lll_l1_ (u"ࠩࡢࡰ࡮ࡴࡥࡤࡧࡱࡸࡪࡸ࡟ࠨ䈒"),1)
			if len(l1l1l11lll11_l1_)>1:
				l1llll1ll1ll_l1_ += 1
				line = l1l1l11lll11_l1_[1]
				l1l11ll111l1_l1_ = 0
				l1lll1ll11ll_l1_ = l1l111l1111l_l1_[l1llll1ll1ll_l1_]
				l1ll11l1lll1_l1_ += l1l11ll11l11_l1_
				l1lll1111ll1_l1_ = False
			elif len(l1l1l11lll1l_l1_)>1:
				line = l1l1l11lll1l_l1_[1]
				l1ll1l111lll_l1_ = line[0:8]
				l1ll1l111lll_l1_ = l11lll_l1_ (u"ࠪࠧࠬ䈓")+l1ll1l111lll_l1_[2:]
				line = line[9:]
			elif len(l1l1l11llll1_l1_)>1:
				line = l1l1l11llll1_l1_[1]
				l1ll1l111lll_l1_ = l11l111lll1_l1_
			elif len(l1ll1l1l1l1l_l1_)>1:
				line = l1ll1l1l1l1l_l1_[1]
				l1lll1111ll1_l1_ = True
				l1l11ll111l1_l1_ = l111l11llll_l1_[l1llll1ll1ll_l1_]
			elif len(l1ll1l1ll111_l1_)>1:
				line = l1ll1l1ll111_l1_[1]
			elif len(l1ll1l1ll11l_l1_)>1:
				line = l1ll1l1ll11l_l1_[1]
			elif len(l1l1l11ll1ll_l1_)>1:
				line = l1l1l11ll1ll_l1_[1]
			if line:
				l1l1l1ll1ll1_l1_ = l1l11l1l111l_l1_+l1ll11l1lll1_l1_
				line = bidi.algorithm.get_display(line)
				width,l1l1lllll1ll_l1_ = l1llllll1l1l_l1_.textsize(line,font=l1ll1l1111l1_l1_)
				if l1lll1111ll1_l1_: l1l11ll111l1_l1_ -= width
				l1lll1ll11l1_l1_ = l1lll1ll11ll_l1_+l1l11ll111l1_l1_
				l1llllll1l1l_l1_.text((l1lll1ll11l1_l1_,l1l1l1ll1ll1_l1_),line,font=l1ll1l1111l1_l1_,fill=l1ll1l111lll_l1_)
				if not l1lll1111ll1_l1_: l1l11ll111l1_l1_ += width
				if l1l1l1ll1ll1_l1_>l1ll1ll1l11l_l1_+l1l11ll11l11_l1_: break
	l1ll1lll1l11_l1_ = l1l111l1l1ll_l1_.replace(l11lll_l1_ (u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ䈔"),l11lll_l1_ (u"ࠬࡥࠧ䈕")+str(time.time())+l11lll_l1_ (u"࠭࡟ࠨ䈖"))
	l1ll1lll1l11_l1_ = l1ll1lll1l11_l1_.replace(l11lll_l1_ (u"ࠧ࡝࡞ࠪ䈗"),l11lll_l1_ (u"ࠨ࡞࡟ࡠࡡ࠭䈘")).replace(l11lll_l1_ (u"ࠩ࠲࠳ࠬ䈙"),l11lll_l1_ (u"ࠪ࠳࠴࠵࠯ࠨ䈚"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l1ll1lll1l11_l1_)
	return l1ll1lll1l11_l1_,l1111111ll1_l1_
def l11lll11ll1_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l111_l1_=True,l1l1lll11111_l1_=True):
	# should l1l11111l1ll_l1_ ==l11lll_l1_ (u"ࠫࠬ䈛") l1111l11l1_l1_ not l11l1111ll_l1_ it to l11lll_l1_ (u"ࠬࡴ࡯ࡵࠩ䈜")
	if allow_redirects==l11lll_l1_ (u"࠭ࠧ䈝"): allow_redirects = True
	if l1ll_l1_==l11lll_l1_ (u"ࠧࠨ䈞"): l1ll_l1_ = True
	if l111ll1l111_l1_==l11lll_l1_ (u"ࠨࠩ䈟"): l111ll1l111_l1_ = True
	if l1l1lll11111_l1_==l11lll_l1_ (u"ࠩࠪ䈠"): l1l1lll11111_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1ll111111l1_l1_ = list(headers.keys())
	if l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䈡") not in l1ll111111l1_l1_: headers[l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䈢")] = l11lll_l1_ (u"ࠬࡆࡀࡁࡕࡎࡍࡕࡥࡈࡆࡃࡇࡉࡗࡆࡀࡁࠩ䈣")
	#if l11lll_l1_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ䈤") not in l1ll111111l1_l1_: headers[l11lll_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ䈥")] = l11lll_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠧ䈦")
	l11l11l_l1_,l1l11ll1l11l_l1_,l1l1lll111ll_l1_,l1l1ll111l11_l1_ = l1l11llllll1_l1_(url)
	l1l111l11lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ䈧"))
	l1l11l1l1l1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ䈨"))
	l1l11lll1lll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭䈩"))
	l1l111ll111l_l1_ = (l1l11ll1l11l_l1_==None and l1l1lll111ll_l1_==None and l1l1ll111l11_l1_==None)
	l1lllll1l1ll_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ䈪")]
	l1l11l1ll1l1_l1_ = l11l11l_l1_ in l1lllll1l1ll_l1_
	l1llllll1lll_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ䈫")]
	l111ll1ll1l_l1_ = l11l11l_l1_ in l1llllll1lll_l1_
	l1llllllll1l_l1_ = l1l11l1ll1l1_l1_ or l111ll1ll1l_l1_
	if l1l111ll111l_l1_ and l1llllllll1l_l1_:
		if l1l11l1ll1l1_l1_:
			l1ll1ll11l11_l1_ = l1lllll1l1ll_l1_.index(l11l11l_l1_)
			l1lll1ll1l1l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓࠫ䈬")][l1ll1ll11l11_l1_]
			l1lll1llllll_l1_ = [l11lll_l1_ (u"ࠨࡎࡌࡗ࡙ࡖࡌࡂ࡛ࠪ䈭"),l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡒࡕࡕࠪ䈮"),l11lll_l1_ (u"ࠪࡉࡒࡇࡉࡍࡕࠪ䈯"),l11lll_l1_ (u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭䈰"),l11lll_l1_ (u"ࠬࡏࡓࡍࡃࡐࡍࡈ࡙ࠧ䈱"),l11lll_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ䈲"),l11lll_l1_ (u"ࠧࡌࡐࡒ࡛ࡓࡋࡒࡓࡑࡕࡗࠬ䈳"),l11lll_l1_ (u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩ䈴")]
			l1llll1l1lll_l1_ = l1lll1llllll_l1_[l1ll1ll11l11_l1_]
		elif l111ll1ll1l_l1_:
			l1ll1ll11l11_l1_ = l1llllll1lll_l1_.index(l11l11l_l1_)
			l1lll1ll1l1l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ䈵")][l1ll1ll11l11_l1_]
			l1111l11l1l_l1_ = [l11lll_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕࠪ䈶"),l11lll_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠽࠭䈷"),l11lll_l1_ (u"ࠬࡇࡄࡅࡑࡑࡗ࠶࠿ࠧ䈸")]
			l1llll1l1lll_l1_ = l1111l11l1l_l1_[l1ll1ll11l11_l1_]
	if l1l1lll111ll_l1_==l11lll_l1_ (u"࠭ࠧ䈹"): l1l1lll111ll_l1_ = l1l111l11lll_l1_
	elif l1l1lll111ll_l1_==None and l1l11l1l1l1l_l1_ in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ䈺"),l11lll_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ䈻")] and l111ll1l111_l1_: l1l1lll111ll_l1_ = l1l111l11lll_l1_
	l1l1lll1111l_l1_ = l11l11l_l1_==l1ll11l_l1_[l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ䈼")][7]
	if source==l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠳ࡳࡦࠪ䈽"): l1111111l1l_l1_ = 120
	elif source==l11lll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭䈾"): l1111111l1l_l1_ = 20
	elif source==l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭䈿"): l1111111l1l_l1_ = 20
	elif source in l1llllll1ll1_l1_: l1111111l1l_l1_ = 10
	elif l1l11l1ll1l1_l1_ or l111ll1ll1l_l1_: l1111111l1l_l1_ = 15
	elif l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍࠨ䉀") in source: l1111111l1l_l1_ = 70
	elif l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ䉁") in source: l1111111l1l_l1_ = 75
	elif l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ䉂") in source: l1111111l1l_l1_ = 25
	elif l11lll_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ䉃") in source: l1111111l1l_l1_ = 20
	elif l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭䉄") in source: l1111111l1l_l1_ = 20
	elif l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭䉅") in source: l1111111l1l_l1_ = 20
	elif l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䉆") in source: l1111111l1l_l1_ = 25
	elif l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䉇") in source: l1111111l1l_l1_ = 30
	else: l1111111l1l_l1_ = 15
	if l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ䉈") in source and not data and l11lll_l1_ (u"ࠨࠨࠪ䉉") not in l11l11l_l1_ and l11lll_l1_ (u"ࠩࡂࠫ䉊") not in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬ䉋"))+l11lll_l1_ (u"ࠫ࠴࠭䉌")
	l111lll111l_l1_ = (l1l11ll1l11l_l1_!=None)
	l1l1ll1l1lll_l1_ = (l1l1lll111ll_l1_!=None and l1l11l1l1l1l_l1_!=l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ䉍"))
	if l111lll111l_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩ䉎"),l1l11ll1l11l_l1_)
	elif l1l1ll1l1lll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧ䉏"),l1l1lll111ll_l1_)
	if l111lll111l_l1_:
		proxies = {l11lll_l1_ (u"ࠣࡪࡷࡸࡵࠨ䉐"):l1l11ll1l11l_l1_,l11lll_l1_ (u"ࠤ࡫ࡸࡹࡶࡳࠣ䉑"):l1l11ll1l11l_l1_}
		l1ll1lll111l_l1_ = l1l11ll1l11l_l1_
	else: proxies,l1ll1lll111l_l1_ = {},l11lll_l1_ (u"ࠪࠫ䉒")
	if l1l1ll1l1lll_l1_:
		import urllib3.util.connection as connection
		l11111l1lll_l1_ = l1l111lllll1_l1_(connection,l1l111l11lll_l1_)
	verify = True
	l1lll1l1llll_l1_,l1lll11ll11l_l1_,l11lll1ll_l1_,l11l11111l1_l1_,l111ll1llll_l1_ = allow_redirects,source,method,False,False
	if l1l1lll1111l_l1_: l111ll1llll_l1_ = True
	#if l1llllllll1l_l1_ or (method==l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䉓") and allow_redirects): l1lll1l1llll_l1_ = False
	if l1llllllll1l_l1_ or allow_redirects: l1lll1l1llll_l1_ = False
	if l1l11l1ll1l1_l1_: l11lll1ll_l1_ = l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䉔")
	import requests
	code,reason = -1,l11lll_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡆࡴࡵࡳࡷ࠭䉕")
	for l11l1lllll_l1_ in range(9):
		l1ll1l111l11_l1_ = True
		succeeded = False
		try:
			if l11l1lllll_l1_: l1lll11ll11l_l1_ = l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖ࠱࠶ࡹࡴࠨ䉖")
			if not l111lll111l_l1_: l11llll1111_l1_(l11lll_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡔࡖࡅࡏࡡࡘࡖࡑ࠭䉗"),l11l11l_l1_,data,headers,l1lll11ll11l_l1_,l11lll1ll_l1_)
			try: response.close()
			except: pass
			l11l1l1_l1_ = l11l11l_l1_
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ䉘"),str(l11lll1ll_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ䉙")+str(l11l11l_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ䉚")+str(data)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ䉛")+str(headers)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ䉜")+str(verify)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ䉝")+str(l1lll1l1llll_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ䉞")+str(l1111111l1l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭䉟")+str(proxies))
			response = requests.request(l11lll1ll_l1_,l11l11l_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll1l1llll_l1_,timeout=l1111111l1l_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11l11111l1_l1_:
					l1ll1lll1ll1_l1_ = list(response.headers.keys())
					if l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䉠") in l1ll1lll1ll1_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䉡")]
					elif l11lll_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䉢") in l1ll1lll1ll1_l1_: l11l11l_l1_ = response.headers[l11lll_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䉣")]
					else: l11l11111l1_l1_ = True
					if not l11l11111l1_l1_: l11l11l_l1_ = l11l11l_l1_.encode(l11lll_l1_ (u"ࠧ࡭ࡣࡷ࡭ࡳ࠳࠱ࠨ䉤"),l11lll_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ䉥")).decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䉦"),l11lll_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ䉧"))
					if l1llllllll1l_l1_ and response.status_code==307:
						l1lll1l1llll_l1_ = allow_redirects
						l11lll1ll_l1_ = method
						l11l11111l1_l1_ = True
						l1l1llllll11_l1_
				if not l11l11111l1_l1_ or allow_redirects:
					if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䉨") not in l11l11l_l1_:
						server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ䉩"))
						l11l11l_l1_ = server+l11lll_l1_ (u"࠭࠯ࠨ䉪")+l11l11l_l1_
				if not l11l11111l1_l1_ and allow_redirects:
					l111lll11l_l1_ = l11l1ll1ll_l1_(l11l11l_l1_)
					if l111lll11l_l1_ not in [l11lll_l1_ (u"ࠧ࠯ࡣࡹ࡭ࠬ䉫"),l11lll_l1_ (u"ࠨ࠰ࡷࡷࠬ䉬"),l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ䉭"),l11lll_l1_ (u"ࠪ࠲ࡦࡧࡣࠨ䉮"),l11lll_l1_ (u"ࠫ࠳ࡳ࡫ࡷࠩ䉯"),l11lll_l1_ (u"ࠬ࠴࡭ࡱ࠵ࠪ䉰"),l11lll_l1_ (u"࠭࠮ࡸࡧࡥࡱࠬ䉱")]: l1l1llllll11_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111ll1llll_l1_ = True
			l11l1l1_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status l1ll1l1l1ll1_l1_ a log line: l11lll_l1_ (u"ࠢࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥࠣ䉲")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l11lll_l1_ (u"ࠨ࠼ࠣࠫ䉳"))[1]
			else: reason = str(err).split(l11lll_l1_ (u"ࠩ࠽ࠤࠬ䉴"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l11lll_l1_ (u"ࠪࡉࡷࡸ࡮ࡰࠩ䉵") in error: code,reason = re.findall(l11lll_l1_ (u"ࠦࡡࡡࡅࡳࡴࡱࡳࠥ࠮࡜ࡥ࠭ࠬࡠࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨ䉶"),error)[0]
				elif l11lll_l1_ (u"ࠬ࠲ࠠࡦࡴࡵࡳࡷ࠮ࠧ䉷") in error: code,reason = re.findall(l11lll_l1_ (u"ࠨࠬࠡࡧࡵࡶࡴࡸ࡜ࠩࠪ࡟ࡨ࠰࠯ࠬࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ䉸"),error)[0]
				elif error.count(l11lll_l1_ (u"ࠧ࠻ࠩ䉹"))>=2: reason,code = re.findall(l11lll_l1_ (u"ࠨ࠼ࠣࠬ࠳࠰࠿ࠪ࠼࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠫ䉺"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1ll1l111l11_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䉻"),l11lll_l1_ (u"ࠪ࠲ࠥࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡖࡊ࡙ࡐࡐࡐࡖࡉࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ䉼")+str(code)+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭䉽")+reason+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ䉾")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䉿")+l11l11l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ䊀"))
		if l1ll1l111l11_l1_ and l1llllllll1l_l1_ and not l111ll1llll_l1_ and code!=200:
			l11l11l_l1_ = l1lll1ll1l1l_l1_
			l111ll1llll_l1_ = True
			continue
		if l1ll1l111l11_l1_: break
	if l1l1lll111ll_l1_!=None and l1l11l1l1l1l_l1_!=l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭䊁"): connection.create_connection = l11111l1lll_l1_
	if l1l11l1l1l1l_l1_==l11lll_l1_ (u"ࠩࡄࡐ࡜ࡇ࡙ࡔࠩ䊂") and l111ll1l111_l1_: l1l1lll111ll_l1_ = None
	if not succeeded and l1l11ll1l11l_l1_==None and source not in l1llllll1ll1_l1_:
		l1lll1lll1ll_l1_ = traceback.format_exc()
		sys.stderr.write(l1lll1lll1ll_l1_)
	l1ll111ll_l1_ = l1l1111l1ll_l1_()
	l11lll_l1_ (u"ࠥࠦࠧࠓࠊࠊࡶࡵࡽ࠿ࠓࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠳ࡸࡡࡸࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡲࡢࡹࠐࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥ࠳࠰ࡷࡩࡽࡺࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡹ࡫ࡸࡵࠏࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫࠲࠯࡬ࡶࡳࡳࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱࡮ࡸࡵ࡮ࠩࠫࠐࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥ࠳࠰࡫࡭ࡸࡺ࡯ࡳࡻࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡩ࡫ࡶࡸࡴࡸࡹࠎࠌࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠸࠮ࡦ࡮ࡤࡴࡸ࡫ࡤࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࡫࡬ࡢࡲࡶࡩࡩࠓࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠳࡫࡮ࡤࡱࡧ࡭ࡳ࡭ࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡪࡴࡣࡰࡦ࡬ࡲ࡬ࠓࠊࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡳࡥࡸࡹࠍࠋࠋࠥࠦࠧ䊃")
	l1ll111ll_l1_.url = l11l1l1_l1_
	try: content = response.content
	except: content = l11lll_l1_ (u"ࠫࠬ䊄")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䊅"))
		except: pass
	code = int(code)
	l1ll111ll_l1_.code = code
	l1ll111ll_l1_.reason = reason
	l1ll111ll_l1_.content = content
	l1ll111ll_l1_.headers = headers
	l1ll111ll_l1_.cookies = cookies
	l1ll111ll_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1ll111ll_l1_.content,str): l1l11l1lll1l_l1_ = l1ll111ll_l1_.content.lower()
	else: l1l11l1lll1l_l1_ = l11lll_l1_ (u"࠭ࠧ䊆")
	l1ll11ll11l1_l1_ = (l11lll_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ䊇") in l1l11l1lll1l_l1_ or l11lll_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ䊈") in l1l11l1lll1l_l1_) and l1l11l1lll1l_l1_.count(l11lll_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ䊉"))>2 and l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ䊊") not in source and l11lll_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠭䊋") not in l1l11l1lll1l_l1_
	if code==200 and l1ll11ll11l1_l1_: l1ll111ll_l1_.succeeded = False
	if l1ll111ll_l1_.succeeded and l1l111ll111l_l1_ and l1llllllll1l_l1_:
		if l1l1lll1111l_l1_: l1llll1l1lll_l1_ = l11lll_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭䊌")+data[l11lll_l1_ (u"࠭ࡪࡰࡤࠪ䊍")].upper()
		l1ll111l1_l1_ = l1l1111lll1_l1_(l1llll1l1lll_l1_)
	if not l1ll111ll_l1_.succeeded and l1l111ll111l_l1_:
		l1ll11ll1111_l1_ = (l11lll_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ䊎") in l1l11l1lll1l_l1_ and l11lll_l1_ (u"ࠨࡴࡤࡽࠥ࡯ࡤ࠻ࠢࠪ䊏") in l1l11l1lll1l_l1_)
		l1lll1l1l11l_l1_ = (l11lll_l1_ (u"ࠩ࠸ࠤࡸ࡫ࡣࠨ䊐") in l1l11l1lll1l_l1_ and l11lll_l1_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ䊑") in l1l11l1lll1l_l1_)
		l1ll11ll11ll_l1_ = (code in [403] and l11lll_l1_ (u"ࠫࡪࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢ࠴࠴࠷࠶ࠧ䊒") in l1l11l1lll1l_l1_)
		l1ll11ll1l11_l1_ = (l11lll_l1_ (u"ࠬࡥࡣࡧࡡࡦ࡬ࡱࡥࠧ䊓") in l1l11l1lll1l_l1_ and l11lll_l1_ (u"࠭ࡣࡩࡣ࡯ࡰࡪࡴࡧࡦ࠯ࠪ䊔") in l1l11l1lll1l_l1_)
		if   l1ll11ll11l1_l1_: reason = l11lll_l1_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ䊕")
		elif l1ll11ll1111_l1_: reason = l11lll_l1_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ䊖")
		elif l1lll1l1l11l_l1_: reason = l11lll_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ䊗")
		elif l1ll11ll11ll_l1_: reason = l11lll_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡦࡩࡣࡦࡵࡶࠤࡩ࡫࡮ࡪࡧࡧࠫ䊘")
		elif l1ll11ll1l11_l1_: reason = l11lll_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭䊙")
		else: reason = str(reason)
		if source in l1llllll1ll1_l1_:
			LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ䊚"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ䊛")+str(code)+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ䊜")+reason+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ䊝")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䊞")+l11l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭䊟"))
		else: LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䊠"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ䊡")+str(code)+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ䊢")+reason+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ䊣")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䊤")+l11l11l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠬ䊥"))
		l1lll11lll1l_l1_ = l111l_l1_(l11l11l_l1_)
		if kodi_version<19 and isinstance(l1lll11lll1l_l1_,unicode): l1lll11lll1l_l1_ = l1lll11lll1l_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䊦"))
		if l1llllllll1l_l1_: l1lll11lll1l_l1_ = l1lll11lll1l_l1_.split(l11lll_l1_ (u"ࠫ࠴࠭䊧"))[-1]
		reason = str(reason)+l11lll_l1_ (u"ࠬࡢ࡮ࠩࠢࠪ䊨")+l1lll11lll1l_l1_+l11lll_l1_ (u"࠭ࠠࠪࠩ䊩")
		if l1ll11ll11l1_l1_ or l1ll11ll1111_l1_ or l1lll1l1l11l_l1_ or l1ll11ll11ll_l1_ or l1ll11ll1l11_l1_:
			code = -2
			l1ll111ll_l1_.code = code
			l1ll111ll_l1_.reason = reason
		l1ll111ll1_l1_ = True
		if (l1l11l1l1l1l_l1_==l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䊪") or l1l11lll1lll_l1_==l11lll_l1_ (u"ࠨࡃࡖࡏࠬ䊫")) and (l111ll1l111_l1_ or l1l1lll11111_l1_):
			l1ll111ll1_l1_ = l1ll1l11ll11_l1_(code,reason,source,l1ll_l1_)
			if l1ll111ll1_l1_ and l1l11l1l1l1l_l1_==l11lll_l1_ (u"ࠩࡄࡗࡐ࠭䊬"): l1l11l1l1l1l_l1_ = l11lll_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ䊭")
			else: l1l11l1l1l1l_l1_ = l11lll_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭䊮")
			if l1ll111ll1_l1_ and l1l11lll1lll_l1_==l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䊯"): l1l11lll1lll_l1_ = l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䊰")
			else: l1l11lll1lll_l1_ = l11lll_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ䊱")
			settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ䊲"),l1l11l1l1l1l_l1_)
			settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ䊳"),l1l11lll1lll_l1_)
		if l1ll111ll1_l1_:
			l1lll1l1ll1l_l1_ = True
			if code==8 and l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ䊴") in l11l11l_l1_ and l1lll1l1ll1l_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ็ู๋ๆࠣๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืࠠࡔࡕࡏࠫ䊵"),l11lll_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ䊶"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"࠭ࡼࡽࡏࡼࡗࡘࡒࡕࡳ࡮ࡀࠫ䊷")
				l1ll111l1_l1_ = l11lll11ll1_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭䊸"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ䊹")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ䊺")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭䊻"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"๋ࠫาวฮࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ䊼"),l11lll_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ䊽"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䊾"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭䊿")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䋀")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䋁"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪๅู๊ࠠษษึฮำีวๆࠢࡖࡗࡑ࠭䋂"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䋃"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l11lll1lll_l1_ in [l11lll_l1_ (u"ࠬࡇࡕࡕࡑࠪ䋄"),l11lll_l1_ (u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨ䋅")] and l1l1lll11111_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠧหใ฼๎้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ䋆"),l11lll_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ䋇"),time=2000)
				l1ll111l1_l1_ = l111ll1l11l_l1_(method,l11l11l_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ䋈"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡐࡳࡱࡻ࡭ࡪࡹࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ䋉")+source+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ䋊")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ䋋"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"࠭ๆอษะࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ䋌"),l11lll_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ䋍"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䋎"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭䋏")+source+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ䋐")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ䋑"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪ䋒"),l11lll_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ䋓"),time=2000)
			if not l1ll111ll_l1_.succeeded and l1l11l1l1l1l_l1_ in [l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ䋔"),l11lll_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ䋕")] and l111ll1l111_l1_:
				if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืࠠࡅࡐࡖࠫ䋖"),l11lll_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ䋗"),time=2000)
				l11l1l1_l1_ = l11l11l_l1_+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩ䋘")
				l1ll111l1_l1_ = l11lll11ll1_l1_(method,l11l1l1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
				if l1ll111l1_l1_.succeeded:
					l1ll111ll_l1_ = l1ll111l1_l1_
					LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ䋙"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤࠥࡊࡎࡔ࠼ࠣ࡟ࠥ࠭䋚")+l1l111l11lll_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ䋛")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䋜")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䋝"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"๊ࠪัออࠡีํีๆืࠠࡅࡐࡖࠫ䋞"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䋟"),time=2000)
				else:
					LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ䋠"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡇࡒࡘࠦࡦࡢ࡫࡯ࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪ䋡")+l1l111l11lll_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ䋢")+source+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䋣")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ䋤"))
					if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠪๅู๊ࠠิ์ิๅึࠦࡄࡏࡕࠪ䋥"),l11lll_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭䋦"),time=2000)
		if l1l11lll1lll_l1_==l11lll_l1_ (u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧ䋧") or l1l11l1l1l1l_l1_==l11lll_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ䋨"): l1ll_l1_ = False
		if not l1ll111ll_l1_.succeeded:
			if l1ll_l1_: l11l1111l1l_l1_ = l1ll1l11ll11_l1_(code,reason,source,l1ll_l1_)
			if code!=200 and source not in l1111lll111_l1_ and l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࠫ䋩") not in source:
				l1lll1111lll_l1_(l11lll_l1_ (u"ࠨࡈࡲࡶࡨ࡫ࡤࠡࡧࡻ࡭ࡹࠦࡤࡶࡧࠣࡸࡴࠦ࡮ࡦࡶࡺࡳࡷࡱࠠࡪࡵࡶࡹࡪࡹࠠࡸ࡫ࡷ࡬࠿ࠦࠧ䋪")+source)
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ䋫")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䋬"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䋭"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䋮")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䋯"),l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䋰"))
	if settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ䋱")) not in [l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ䋲"),l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ䋳"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䋴")]: settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ䋵"),l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䋶"))
	return l1ll111ll_l1_
def OPENURL_REQUESTS_CACHED(l11lll1lll1_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l111_l1_=True,l1l1lll11111_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	if l11lll1lll1_l1_:
		response = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ䋷"),l11lll_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫ䋸"),item)
		if response.succeeded:
			l11llll1111_l1_(l11lll_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩ䋹"),url,data,headers,source,method)
			return response
	response = l11lll11ll1_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1l111_l1_,l1l1lll11111_l1_)
	if response.succeeded:
		if l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ䋺") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l11lll1lll1_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧ䋻"),item,response,l11lll1lll1_l1_)
	return response
def OPENURL_CACHED(l11lll1lll1_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䋼")
	else:
		method = l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ䋽")
		data = l111l_l1_(data)
		dummy,data = l1llll11ll_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l11lll1lll1_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ䋾"))
	html = str(html)
	return html
def l1l11llllll1_l1_(url):
	l1l11lll1l11_l1_ = url.split(l11lll_l1_ (u"ࠨࡾࡿࠫ䋿"))
	l11l11l_l1_,l1l11ll1l11l_l1_,l1l1lll111ll_l1_,l1l1ll111l11_l1_ = l1l11lll1l11_l1_[0],None,None,None
	for item in l1l11lll1l11_l1_:
		if l11lll_l1_ (u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ䌀") in item: l1l11ll1l11l_l1_ = item.split(l11lll_l1_ (u"ࠪࡁࠬ䌁"))[1]
		elif l11lll_l1_ (u"ࠫࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧ䌂") in item: l1l1lll111ll_l1_ = item.split(l11lll_l1_ (u"ࠬࡃࠧ䌃"))[1]
		elif l11lll_l1_ (u"࠭ࡍࡺࡕࡖࡐ࡚ࡸ࡬࠾ࠩ䌄") in item: l1l1ll111l11_l1_ = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ䌅"))[1]
	return l11l11l_l1_,l1l11ll1l11l_l1_,l1l1lll111ll_l1_,l1l1ll111l11_l1_
def RESTORE_PATH_NAME(name):
	start,l1l1l1ll1ll_l1_,modified = l11lll_l1_ (u"ࠨࠩ䌆"),l11lll_l1_ (u"ࠩࠪ䌇"),l11lll_l1_ (u"ࠪࠫ䌈")
	name = name.replace(ltr,l11lll_l1_ (u"ࠫࠬ䌉")).replace(rtl,l11lll_l1_ (u"ࠬ࠭䌊"))
	tmp = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭䌋"),name,re.DOTALL)
	if tmp: start,l1l1l1ll1ll_l1_,name = tmp[0]
	if start not in [l11lll_l1_ (u"ࠧࠡࠩ䌌"),l11lll_l1_ (u"ࠨ࠮ࠪ䌍"),l11lll_l1_ (u"ࠩࠪ䌎")]: modified = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䌏")
	if l1l1l1ll1ll_l1_: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࡤ࠭䌐")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠬࡥࠧ䌑")
	#datetime = re.findall(l11lll_l1_ (u"࠭ࠨࡠ࡞ࡧࡠࡩࡢ࠮࡝ࡦ࡟ࡨࡤࡢࡤ࡝ࡦ࡟࠾ࡡࡪ࡜ࡥࡡࠬࠫ䌒"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11lll_l1_ (u"ࠧࠨ䌓"))
	name = l1l1l1ll1ll_l1_+modified+name
	return name
def l1ll11111l1_l1_(url,l1l1l1lllll1_l1_,l1l1ll1l11l1_l1_,l1ll1ll11111_l1_,headers={}):
	l1l1111l1l1l_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ䌔"))
	l1111l1ll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫ䌕")+l1l1l1lllll1_l1_)
	if l1111l1ll1l_l1_: l11l1l1_l1_ = url.replace(l1l1111l1l1l_l1_,l1111l1ll1l_l1_)
	else:
		l11l1l1_l1_ = url
		l1111l1ll1l_l1_ = l1l1111l1l1l_l1_
	l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䌖"),l11l1l1_l1_,l11lll_l1_ (u"ࠫࠬ䌗"),headers,l11lll_l1_ (u"ࠬ࠭䌘"),l11lll_l1_ (u"࠭ࠧ䌙"),l11lll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫ䌚"))
	html = l1ll111l1_l1_.content
	try: html = html.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䌛"),l11lll_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ䌜"))
	except: pass
	if not l1ll111l1_l1_.succeeded or l1ll1ll11111_l1_ not in html:
		l11l11l_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨ䌝")+l1l1ll1l11l1_l1_
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䌞"):l11lll_l1_ (u"ࠬ࠭䌟")}
		l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䌠"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ䌡"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ䌢"),l11lll_l1_ (u"ࠩࠪ䌣"),l11lll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠶ࡳࡪࠧ䌤"))
		if l1ll111ll_l1_.succeeded:
			html = l1ll111ll_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䌥"),l11lll_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ䌦"))
				except: pass
			links = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡸࡶࡱࡢ࠿ࡲ࠿ࠫ࠲࠯ࡅࠩࠣࠩ䌧"),html,re.DOTALL)
			l1lll1l1l1l1_l1_ = [l1111l1ll1l_l1_]
			for link in links:
				l1111l1ll1l_l1_ = SERVER(link,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ䌨"))
				if l11lll_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱࠬ䌩") in link: continue
				if l1111l1ll1l_l1_ in l1lll1l1l1l1_l1_: continue
				if len(l1lll1l1l1l1_l1_)==9:
					LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䌪"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䌫")+l1l1l1lllll1_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ䌬")+l1l1111l1l1l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ䌭"))
					settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ䌮")+l1l1l1lllll1_l1_,l11lll_l1_ (u"ࠧࠨ䌯"))
					break
				l1lll1l1l1l1_l1_.append(l1111l1ll1l_l1_)
				l11l1l1_l1_ = url.replace(l1l1111l1l1l_l1_,l1111l1ll1l_l1_)
				l1ll111l1_l1_ = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䌰"),l11l1l1_l1_,l11lll_l1_ (u"ࠩࠪ䌱"),headers,l11lll_l1_ (u"ࠪࠫ䌲"),l11lll_l1_ (u"ࠫࠬ䌳"),l11lll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ䌴"))
				html = l1ll111l1_l1_.content
				if l1ll111l1_l1_.succeeded and l1ll1ll11111_l1_ in html:
					LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䌵"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡋࡴࡵࡧ࡭ࡧࠣࡪࡴࡻ࡮ࡥࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ䌶")+l1l1l1lllll1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡎࡦࡹ࠽ࠤࡠࠦࠧ䌷")+l1111l1ll1l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧ䌸")+l1l1111l1l1l_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭䌹"))
					settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭䌺")+l1l1l1lllll1_l1_,l1111l1ll1l_l1_)
					break
	return l1111l1ll1l_l1_,l11l1l1_l1_,l1ll111l1_l1_
def TRANSLATE(text):
	dict = {
	 l11lll_l1_ (u"ࠬࡵ࡬ࡥࠩ䌻")			:l11lll_l1_ (u"࠭โะ์่ࠫ䌼")
	,l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ䌽")		:l11lll_l1_ (u"ࠨ็อ์็็ࠧ䌾")
	,l11lll_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ䌿")		:l11lll_l1_ (u"้ࠪๆ่่ะࠩ䍀")
	,l11lll_l1_ (u"ࠫ࡬ࡵ࡯ࡥࠩ䍁")			:l11lll_l1_ (u"ࠬา๊ะࠩ䍂")
	,l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䍃")		:l11lll_l1_ (u"ࠧโึ็ࠫ䍄")
	,l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍅")		:l11lll_l1_ (u"่ࠩะ้ีࠧ䍆")
	,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䍇")		:l11lll_l1_ (u"ࠫๆ๐ฯ๋๊ࠪ䍈")
	,l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䍉")			:l11lll_l1_ (u"࠭โ็ษฬࠫ䍊")
	,l11lll_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠭䍋")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ䍌")
	,l11lll_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ䍍")		:l11lll_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧ䍎")
	,l11lll_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡦࡥࡲ࠭䍏")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢๆห๊࠭䍐")
	,l11lll_l1_ (u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭䍑")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧ䍒")
	,l11lll_l1_ (u"ࠨࡣ࡯ࡪࡦࡺࡩ࡮࡫ࠪ䍓")		:l11lll_l1_ (u"่ࠩ์็฿ࠠศๆ่๊อืࠠศๆไห฼๋๊ࠨ䍔")
	,l11lll_l1_ (u"ࠪࡥࡱࡱࡡࡸࡶ࡫ࡥࡷ࠭䍕")	:l11lll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆๆ์ะืࠧ䍖")
	,l11lll_l1_ (u"ࠬࡧ࡬࡮ࡣࡤࡶࡪ࡬ࠧ䍗")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ䍘")
	,l11lll_l1_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ䍙")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ䍚")
	,l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭䍛")	:l11lll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨ䍜")
	,l11lll_l1_ (u"ࠫࡪࡲࡣࡪࡰࡨࡱࡦ࠭䍝")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣหู้๊็็สࠫ䍞")
	,l11lll_l1_ (u"࠭ࡨࡦ࡮ࡤࡰࠬ䍟")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ䍠")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦ࡬ࡡ࡯ࡵࠪ䍡")		:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ䍢")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ䍣")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭䍤")
	,l11lll_l1_ (u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧ䍥")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭䍦")
	,l11lll_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䍧")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ䍨")
	,l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䍩")		:l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ䍪")
	,l11lll_l1_ (u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧ䍫")	:l11lll_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨ䍬")
	,l11lll_l1_ (u"࠭ࡹࡵࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䍭")	:l11lll_l1_ (u"ࠧๆ๊สๆ฾๊้ࠦฬํ์อ࠭䍮")
	,l11lll_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䍯")		:l11lll_l1_ (u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩ䍰")
	,l11lll_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ䍱")		:l11lll_l1_ (u"๊ࠫ๎โฺ๋ࠢ๎ู๊ࠥๆษࠪ䍲")
	,l11lll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ䍳")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ䍴")
	,l11lll_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩ䍵")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫ䍶")
	,l11lll_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ䍷")		:l11lll_l1_ (u"้ࠪํู่ࠡสๆีฬ࠭䍸")
	,l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭䍹")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭䍺")
	,l11lll_l1_ (u"࠭࡬ࡪࡸࡨࡸࡻ࠭䍻")		:l11lll_l1_ (u"ࠧๆๆไࠫ䍼")
	,l11lll_l1_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺࠩ䍽")		:l11lll_l1_ (u"่่ࠩๆ࠭䍾")
	,l11lll_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ䍿")		:l11lll_l1_ (u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭䎀")
	,l11lll_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨ䎁")	:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫ䎂")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ䎃")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ䎄")
	,l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫ䎅")		:l11lll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭䎆")
	,l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭䎇")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨ䎈")
	,l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ䎉")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪ䎊")
	,l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪ䎋")		:l11lll_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬ䎌")
	,l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ䎍")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭䎎")
	,l11lll_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ䎏")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭䎐")
	,l11lll_l1_ (u"ࠧࡦࡩࡼࡨࡪࡧࡤࠨ䎑")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤิ๐ฯࠨ䎒")
	,l11lll_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ䎓")		:l11lll_l1_ (u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪ䎔")
	,l11lll_l1_ (u"ࠫࡱࡵࡤࡺࡰࡨࡸࠬ䎕")		:l11lll_l1_ (u"๋่ࠬใ฻่ࠣํี๊่ࠡอࠫ䎖")
	,l11lll_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ䎗")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ䎘")
	,l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡲࡩࡨࡪࡷࠫ䎙")	:l11lll_l1_ (u"่ࠩ์็฿ࠠิ์่ห๊ࠥว๋ฬࠪ䎚")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧ䎛")	:l11lll_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬ䎜")
	,l11lll_l1_ (u"ࠬ࡬࡯ࡴࡶࡤࠫ䎝")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ䎞")
	,l11lll_l1_ (u"ࠧࡢࡪࡺࡥࡰ࠭䎟")		:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦร่๊ส็ࠥะ๊โ์ࠪ䎠")
	,l11lll_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ䎡")		:l11lll_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ䎢")
	,l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭䎣")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭䎤")
	,l11lll_l1_ (u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭䎥")		:l11lll_l1_ (u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩ䎦")
	,l11lll_l1_ (u"ࠨࡤࡵࡷࡹ࡫ࡪࠨ䎧")		:l11lll_l1_ (u"่ࠩ์็฿ࠠษำึฮ๏าࠧ䎨")
	,l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫ䎩")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫ䎪")
	,l11lll_l1_ (u"ࠬࡲࡡࡳࡱࡽࡥࠬ䎫")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫ䎬")
	,l11lll_l1_ (u"ࠧࡺࡣࡴࡳࡹ࠭䎭")		:l11lll_l1_ (u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬ䎮")
	,l11lll_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ䎯")		:l11lll_l1_ (u"้ࠪํู่ࠡๅอ็ํะࠧ䎰")
	,l11lll_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭䎱")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧ䎲")
	,l11lll_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡺ࡯ࡰࡰࡶࠫ䎳")	:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩ䎴")
	,l11lll_l1_ (u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩ䎵")		:l11lll_l1_ (u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩ䎶")
	,l11lll_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䎷")		:l11lll_l1_ (u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪ䎸")
	#,l11lll_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ䎹")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧ䎺")
	,l11lll_l1_ (u"ࠧࡪࡨ࡬ࡰࡲ࠭䎻")				:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ䎼")
	,l11lll_l1_ (u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡣࡵࡥࡧ࡯ࡣࠨ䎽")			:l11lll_l1_ (u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎ฺ้๋ࠠำห๎ࠬ䎾")
	,l11lll_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯࠰ࡩࡳ࡭࡬ࡪࡵ࡫ࠫ䎿")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪ䏀")
	,l11lll_l1_ (u"࠭ࡰࡢࡰࡨࡸࠬ䏁")				:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥฮว็์อࠫ䏂")
	,l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ䏃")			:l11lll_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬ䏄")
	,l11lll_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡶࡩࡷ࡯ࡥࡴࠩ䏅")			:l11lll_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠡ็ึุ่๊วหࠩ䏆")
	,l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭䏇")				:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ䏈")
	,l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠨ䏉")		:l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦแ๋ัํ์์อสࠨ䏊")
	,l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭䏋")	:l11lll_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧ䏌")
	,l11lll_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡩࡨࡢࡰࡱࡩࡱࡹࠧ䏍")		:l11lll_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๆ๋๎วหࠩ䏎")
	,l11lll_l1_ (u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦࠩ䏏")			:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩ䏐")
	,l11lll_l1_ (u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬ䏑")	:l11lll_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩ䏒")
	,l11lll_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡ࡭ࡤࡸࡱࡸ࠭䏓")		:l11lll_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦวๅส๋้ࠬ䏔")
	,l11lll_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡣࡸࡨ࡮ࡵࡳࠨ䏕")		:l11lll_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡื๋ฮ๏อสࠨ䏖")
	,l11lll_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䏗")			:l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ䏘")
	,l11lll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡷ࡫ࡧࡩࡴࡹࠧ䏙")	:l11lll_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤๆ๐ฯ๋๊๊หฯ࠭䏚")
	,l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䏛"):l11lll_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬ䏜")
	,l11lll_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䏝")	:l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧ䏞")
	,l11lll_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡴࡰࡲ࡬ࡧࡸ࠭䏟")	:l11lll_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่้ࠣํอึ๋฻ࠪ䏠")
	,l11lll_l1_ (u"ࠪ࡭ࡵࡺࡶࠨ䏡")					:l11lll_l1_ (u"ࠫࡎࡖࡔࡗࠩ䏢")
	,l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨ䏣")			:l11lll_l1_ (u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪ䏤")
	,l11lll_l1_ (u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䏥")			:l11lll_l1_ (u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬ䏦")
	,l11lll_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧ䏧")			:l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩ䏨")
	,l11lll_l1_ (u"ࠫࡲ࠹ࡵࠨ䏩")					:l11lll_l1_ (u"ࠬࡓ࠳ࡖࠩ䏪")
	,l11lll_l1_ (u"࠭࡭࠴ࡷ࠰ࡰ࡮ࡼࡥࠨ䏫")				:l11lll_l1_ (u"ࠧࡎ࠵ࡘࠤ็์่ศฬࠪ䏬")
	,l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ䏭")			:l11lll_l1_ (u"ࠩࡐ࠷࡚ࠦรโๆส้ࠬ䏮")
	,l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠭ࡴࡧࡵ࡭ࡪࡹࠧ䏯")			:l11lll_l1_ (u"ࠫࡒ࠹ࡕࠡ็ึุ่๊วหࠩ䏰")
	}
	try: result = dict[text.lower()]
	except: result = l11lll_l1_ (u"ࠬ࠭䏱")
	return result
def l1lll1111lll_l1_(message=l11lll_l1_ (u"࠭ࠧ䏲")):
	l1l1ll1l1l11_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l11lll_l1_ (u"ࠧ࠻࠱ࠪ䏳")):
	return _1ll1l111111_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l111111llll_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠨࠩ䏴"),l11lll_l1_ (u"ࠩ࠳ࠫ䏵"),0]: return l11lll_l1_ (u"ࠪࠫ䏶")
	l1l1l111l_l1_ = int(l1l1l111l_l1_)
	first = l1l1l111l_l1_^l11111l_l1_
	second = l1l1l111l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l1l111l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1l11l1111ll_l1_(l1l1l111l_l1_):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠫࠬ䏷"),l11lll_l1_ (u"ࠬ࠶ࠧ䏸"),0]: return l11lll_l1_ (u"࠭ࠧ䏹")
	l1l1l111l_l1_ = str(l1l1l111l_l1_)
	result = l11lll_l1_ (u"ࠧࠨ䏺")
	if len(l1l1l111l_l1_)==15:
		first,second,l1lll111l_l1_ = l1l1l111l_l1_[0:4],l1l1l111l_l1_[4:9],l1l1l111l_l1_[9:]
		first = int(first)^l1lll1111_l1_
		second = int(second)^REGULAR_CACHE
		l1lll111l_l1_ = int(l1lll111l_l1_)^l11111l_l1_
		if first==second==l1lll111l_l1_: result = str(first*60)
	return result
def l1l1ll1ll111_l1_(l1l1l111l_l1_,l1l1lll1lll1_l1_=l11lll_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ䏻")):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"ࠩࠪ䏼"),l11lll_l1_ (u"ࠪ࠴ࠬ䏽"),0]: return l11lll_l1_ (u"ࠫࠬ䏾")
	l1l1l111l_l1_ = int(l1l1l111l_l1_)+int(l1l1lll1lll1_l1_)
	first = l1l1l111l_l1_^l11111l_l1_
	second = l1l1l111l_l1_^REGULAR_CACHE
	l1lll111l_l1_ = l1l1l111l_l1_^l1lll1111_l1_
	result = str(first)+str(second)+str(l1lll111l_l1_)
	return result
def l1lll1111l11_l1_(l1l1l111l_l1_,l1l1lll1lll1_l1_=l11lll_l1_ (u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ䏿")):
	if l1l1l111l_l1_ in [l11lll_l1_ (u"࠭ࠧ䐀"),l11lll_l1_ (u"ࠧ࠱ࠩ䐁"),0]: return l11lll_l1_ (u"ࠨࠩ䐂")
	l1l1l111l_l1_ = str(l1l1l111l_l1_)
	length = int(len(l1l1l111l_l1_)/3)
	first = int(l1l1l111l_l1_[0:length])^l11111l_l1_
	second = int(l1l1l111l_l1_[length:2*length])^REGULAR_CACHE
	l1lll111l_l1_ = int(l1l1l111l_l1_[2*length:3*length])^l1lll1111_l1_
	result = l11lll_l1_ (u"ࠩࠪ䐃")
	if first==second==l1lll111l_l1_: result = str(int(first)-int(l1l1lll1lll1_l1_))
	return result
def l1l1l11ll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1ll11l1ll_l1_(l1l1l11ll1l1_l1_,l1l1l11l111l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ䐄"),l11lll_l1_ (u"ࠫࠬ䐅"),l11lll_l1_ (u"ࠬ࠭䐆"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䐇"),l1l1l11ll1l1_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ䐈")+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อ้ࠡำหࠥอไๆฮ็ำࠥลࠡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䐉"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1l11ll1l1_l1_):
		#os.chmod(l1l1l11ll1l1_l1_,0o777)
		for root,dirs,files in os.walk(l1l1l11ll1l1_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				try: os.remove(filepath)
				except Exception as err:
					if l1ll_l1_ and not error: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䐊"),l11lll_l1_ (u"ࠪࠫ䐋"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䐌"),str(err))
					error = True
			if l1l1l11l111l_l1_:
				for dir in dirs:
					l1l11111llll_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l11111llll_l1_)
					except: pass
		if l1l1l11l111l_l1_:
			try: os.rmdir(root)
			except: pass
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䐍"),l11lll_l1_ (u"࠭ࠧ䐎"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䐏"),l11lll_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩ䐐"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭䐑"),l11lll_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭䐒"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ䐓"))
	return
def l1l1ll1l1l11_l1_(l1lll1lll1ll_l1_=l11lll_l1_ (u"ࠬ࠭䐔")):
	#if l1lll1lll1ll_l1_:
	#	if l11lll_l1_ (u"࠭࡟ࡠࡈࡒࡖࡈࡋࡄࡠࡇ࡛ࡍ࡙ࡥ࡟ࠨ䐕") in l1lll1lll1ll_l1_:
	#		message  = l1lll1lll1ll_l1_.split(l11lll_l1_ (u"ࠧࡠࡡࡉࡓࡗࡉࡅࡅࡡࡈ࡜ࡎ࡚࡟ࡠࠩ䐖"))[1]
	#		LOG_THIS(l11lll_l1_ (u"ࠨࠩ䐗"),l11lll_l1_ (u"ࠩࡉࡓࡗࡉࡅࡅࠢࡈ࡜ࡎ࡚ࠠࠡࠢࠣ࠲ࠥࠦࠠࠨ䐘")+message)
	#		#sys.stderr.write(l11lll_l1_ (u"ࠪࡊࡔࡘࡃࡆࡆࠣࡉ࡝ࡏࡔ࠻࡞ࡱࠫ䐙")+message+l11lll_l1_ (u"ࠫࡡࡴ࡟ࠨ䐚"))
	#	else: l11l11l11ll_l1_(l1lll1lll1ll_l1_)
	if l1lll1lll1ll_l1_:
		l1ll1llll1ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭䐛"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ䐜"),l11lll_l1_ (u"ࠧࠨ䐝"))
		l11l11l11ll_l1_(l1lll1lll1ll_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ䐞"),l1ll1llll1ll_l1_)
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭䐟"))
	if l1l11llll1_l1_==l11lll_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭䐠"): settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ䐡"),l11lll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ䐢"))
	elif l1l11llll1_l1_==l11lll_l1_ (u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩ䐣"): settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ䐤"),l11lll_l1_ (u"ࠨࠩ䐥"))
	if settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ䐦")) not in [l11lll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ䐧"),l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ䐨"),l11lll_l1_ (u"ࠬࡇࡓࡌࠩ䐩")]: settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭䐪"),l11lll_l1_ (u"ࠧࡂࡕࡎࠫ䐫"))
	if settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ䐬")) not in [l11lll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ䐭"),l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ䐮"),l11lll_l1_ (u"ࠫࡆ࡙ࡋࠨ䐯")]: settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ䐰"),l11lll_l1_ (u"࠭ࡁࡔࡍࠪ䐱"))
	l11l111ll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪ䐲"))
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫ䐳"))
	if l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ䐴") in str(l11111lll1l_l1_) and l11l111ll1l_l1_ in [l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭䐵"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ䐶")]:
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬ࠭䐷"),l11l111ll1l_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡖࡩࡹ࡜ࡩࡦࡹࡐࡳࡩ࡫ࠨ࠱ࠫࠪ䐸"))
	#l111ll11l1l_l1_ = sys.version_info[0]
	#l11111l11l1_l1_ = sys.version_info[1]
	#if l111ll11l1l_l1_==2: python_version = l11lll_l1_ (u"ࠧ࠳࠹ࠪ䐹")
	#else: python_version = str(l111ll11l1l_l1_)+str(l11111l11l1_l1_)
	#l11l111111l_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ䐺")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䐻"),l11lll_l1_ (u"ࠪࠫ䐼"),l11lll_l1_ (u"ࠫࠬ䐽"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1lll1lll111_l1_,l111ll1l1ll_l1_)
	return
from EXCLUDES import *
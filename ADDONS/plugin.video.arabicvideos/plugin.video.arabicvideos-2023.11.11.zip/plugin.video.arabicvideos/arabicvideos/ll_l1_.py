# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ劶")
#l111lll11ll1_l1_ = [ l11lll_l1_ (u"ࠧ࡮ࡻࡶࡸࡷ࡫ࡡ࡮ࠩ劷"),l11lll_l1_ (u"ࠨࡸ࡬ࡱࡵࡲࡥࠨ劸"),l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯࡮ࠩ効"),l11lll_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ劺") ]
l111lll11ll1_l1_ = []
headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ劻"):l11lll_l1_ (u"ࠬ࠭劼")}
def l11_l1_(l1lllll1_l1_,source,type,url):
	#DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ัศสฺࠤฬ๊ๅ็ษึฬࠬ劽"),l1lllll1_l1_)
	if not l1lllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ劾"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࡵࠣࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ势")+source+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪ勀")+type+l11lll_l1_ (u"ࠪࠤࡢ࠭勁"))
		l11l11l1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ勂"),l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ勃"),l11lll_l1_ (u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ勄"))
		datetime = time.strftime(l11lll_l1_ (u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍࠨ勅"),time.gmtime(now))
		line = datetime,url
		key = source+l11lll_l1_ (u"ࠨࠢࠣࠤࠥ࠭勆")+l11ll111111_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠧ勇")+str(kodi_version)
		message = l11lll_l1_ (u"ࠪࠫ勈")
		if key not in list(l11l11l1l1ll_l1_.keys()): l11l11l1l1ll_l1_[key] = [line]
		else:
			if url not in str(l11l11l1l1ll_l1_[key]): l11l11l1l1ll_l1_[key].append(line)
			else: message = l11lll_l1_ (u"ࠫࡡࡴ่ࠠาสࠤฬ๊แ๋ัํ์๋่ࠥอ๊าࠤๆ๐ࠠใษษ้ฮࠦวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤฯ฿ๅๅࠩ勉")
		total = 0
		for key in list(l11l11l1l1ll_l1_.keys()):
			l11l11l1l1ll_l1_[key] = list(set(l11l11l1l1ll_l1_[key]))
			total += len(l11l11l1l1ll_l1_[key])
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭勊"),l11lll_l1_ (u"࠭ࠧ勋"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ勌"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ勍")+message+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠠๅๆ฼่๊ࠦวๅสิ๊ฬ๋ฬࠡ์ๅ์๊ࠦศอ็฼ࠤ็อฦๆหࠣฬฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢํะิࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่๊ࠡึ์ๆฺ๊ࠦำูࠤ฾๊๊ไࠢส่อืๆศ็ฯࠤศ์ࠠหำึ่ࠥํะ่ࠢส่็อฦๆหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻้ำ๊อ๋ࠠืหัࠥ฿ฯะ้สࠤ࠺ࠦแ๋ัํ์์อสࠨ勎")+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ勏")+l11lll_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡษ็ๆฬฬๅสࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠧ勐")+str(total))
		if total>=5:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭勑"),l11lll_l1_ (u"࠭ࠧ勒"),l11lll_l1_ (u"ࠧࠨ勓"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ勔"),l11lll_l1_ (u"ࠩส่อืๆศ็ฯࠤัู๋ࠡไสส๊ฯࠠโ์๊หࠥ࠻ࠠโ์า๎ํํวหࠢ็้ࠥ๐ฬะࠢส่อืๆศ็ฯࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ๋ำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦลาีส่ࠥํะ่ࠢส่็อฦๆหࠣๆอ๊ࠠๆีะ๋ฬࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅ็หี๊าࠠษใะูࠥํะ่ࠢส่ๆ๐ฯ๋๊๊หฯࠦฟࠢࠣࠪ動"))
			if l1ll111ll1_l1_==1:
				l11l11l1ll1l_l1_ = l11lll_l1_ (u"ࠪࠫ勖")
				for key in list(l11l11l1l1ll_l1_.keys()):
					l11l11l1ll1l_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ勗")+key
					l1111l11l1l1_l1_ = sorted(l11l11l1l1ll_l1_[key],reverse=False,key=lambda l111ll1111ll_l1_: l111ll1111ll_l1_[0])
					for datetime,url in l1111l11l1l1_l1_:
						l11l11l1ll1l_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ勘")+datetime+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ務")+l111l_l1_(url)
					l11l11l1ll1l_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ勚")
				import l11ll1lll11_l1_
				succeeded = l11ll1lll11_l1_.l1111l1lll1_l1_(l11lll_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࡳࠨ勛"),l11lll_l1_ (u"ࠩࠪ勜"),False,l11lll_l1_ (u"ࠪࠫ勝"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡎࡄ࡝ࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ勞"),l11lll_l1_ (u"ࠬ࠭募"),l11l11l1ll1l_l1_)
				if succeeded: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ勠"),l11lll_l1_ (u"ࠧࠨ勡"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ勢"),l11lll_l1_ (u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬ勣"))
				else: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ勤"),l11lll_l1_ (u"ࠫࠬ勥"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ勦"),l11lll_l1_ (u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫ勧"))
			if l1ll111ll1_l1_!=-1:
				l11l11l1l1ll_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ勨"),l11lll_l1_ (u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ勩"))
		if l11l11l1l1ll_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ勪"),l11lll_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ勫"),l11l11l1l1ll_l1_,PERMANENT_CACHE)
		return
	l1lllll1_l1_ = list(set(l1lllll1_l1_))
	l1lll1ll_l1_,l1111_l1_ = l1111ll1111l_l1_(l1lllll1_l1_,source)
	l1111l11l111_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ勬"))
	l1111ll11ll1_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ勭"))
	l1111l11ll11_l1_ = len(l1111_l1_)-l1111l11l111_l1_-l1111ll11ll1_l1_
	l1111ll1llll_l1_ = l11lll_l1_ (u"࠭ๅีษ๊ำฮࡀࠧ勮")+str(l1111l11l111_l1_)+l11lll_l1_ (u"ࠧࠡࠢࠣࠤฯำๅ๋ๆ࠽ࠫ勯")+str(l1111ll11ll1_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠤࠥษฮา๋࠽ࠫ勰")+str(l1111l11ll11_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ勱"),l11lll_l1_ (u"ࠪࠫ勲"),str(l1111l11l111_l1_),str(l1111ll11ll1_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1111ll1llll_l1_, l1111_l1_)
	if not l1111_l1_: result,l11l1lll11l1_l1_ = l11lll_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ勳"),l11lll_l1_ (u"ࠬ࠭勴")
	else:
		while True:
			l11l1lll11l1_l1_ = l11lll_l1_ (u"࠭ࠧ勵")
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1111ll1llll_l1_,l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠴ࡷࡹࡥ࡭ࡦࡰࡸࠫ勶")
			else:
				title = l1lll1ll_l1_[l1l_l1_]
				link = l1111_l1_[l1l_l1_]
				#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ勷"),l11lll_l1_ (u"ࠩࠪ勸"),title,link)
				if l11lll_l1_ (u"ࠪื๏ืแาࠩ勹") in title and l11lll_l1_ (u"ࠫ࠷๋ฬ่๊็࠶ࠬ勺") in title:
					LOG_THIS(l11lll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ勻"),LOGGING(script_name)+l11lll_l1_ (u"࠭ࠠࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡗࡪࡲࡥࡤࡶࡨࡨ࡙ࠥࡥࡳࡸࡨࡶࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ勼")+title+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ勽")+link+l11lll_l1_ (u"ࠨࠢࡠࠫ勾"))
					import l11ll1lll11_l1_
					l11ll1lll11_l1_.MAIN(156)
					result = l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭勿")
				else:
					LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ匀"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡕࡨࡰࡪࡩࡴࡦࡦࠣࡗࡪࡸࡶࡦࡴࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩ匁")+title+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬ匂")+link+l11lll_l1_ (u"࠭ࠠ࡞ࠩ匃"))
					result,l11l1lll11l1_l1_,l11lll1lll11_l1_ = l1111llll1ll_l1_(link,source,type)
					#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ匄"),l11lll_l1_ (u"ࠨࠩ包"),result,l11l1lll11l1_l1_)
			if l11lll_l1_ (u"ࠩ࡟ࡲࠬ匆") not in l11l1lll11l1_l1_: l11l1l1ll1ll_l1_,l111l1lll11_l1_ = l11l1lll11l1_l1_,l11lll_l1_ (u"ࠪࠫ匇")
			else: l11l1l1ll1ll_l1_,l111l1lll11_l1_ = l11l1lll11l1_l1_.split(l11lll_l1_ (u"ࠫࡡࡴࠧ匈"),1)
			if result in [l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ匉"),l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ匊"),l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ匋"),l11lll_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ匌")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ匍"),l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ匎"),l11lll_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ匏")]: break
			elif result not in [l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ匐"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷࠬ匑")]: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ匒"),l11lll_l1_ (u"ࠨࠩ匓"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ匔"),l11lll_l1_ (u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์࠭匕")+l11lll_l1_ (u"ࠫࡡࡴࠧ化")+l11l1l1ll1ll_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ北")+l111l1lll11_l1_)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ匘"),l11lll_l1_ (u"ࠧࠨ匙"),l11lll_l1_ (u"ࠨࠩ匚"),str(l11lll1lll11_l1_))
	if result==l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭匛") and len(l1lll1ll_l1_)>0: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ匜"),l11lll_l1_ (u"ࠫࠬ匝"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ匞"),l11lll_l1_ (u"࠭ำ๋ำไีࠥํะศࠢส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠤัืศࠡใํำ๏๎ࠠ฻์ิ๋ࠬ匟")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ匠")+l11l1lll11l1_l1_)
	elif result in [l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ匡"),l11lll_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ匢")] and l11l1lll11l1_l1_!=l11lll_l1_ (u"ࠪࠫ匣"): DIALOG_OK(l11lll_l1_ (u"ࠫࠬ匤"),l11lll_l1_ (u"ࠬ࠭匥"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ匦"),l11l1lll11l1_l1_)
	#elif l11l1lll11l1_l1_==l11lll_l1_ (u"ࠧࡓࡇࡗ࡙ࡗࡔ࡟ࡕࡑࡢ࡝ࡔ࡛ࡔࡖࡄࡈࠫ匧"): result = l11lll1lll11_l1_
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡪࡨࠣࡶࡪࡹࡵ࡭ࡶࠣ࡭ࡳ࡛ࠦࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ࠲ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫࡢࡀࠊࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࡍࡑࡊࡋࡎࡔࡇࠩࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠯ࠫࠨࠢࠣࠤ࡙࡫ࡳࡵ࠼ࠣࠤࠥ࠭ࠫࡴࡻࡶ࠲ࡦࡸࡧࡷ࡝࠳ࡡ࠰ࡹࡹࡴ࠰ࡤࡶ࡬ࡼ࡛࠳࡟ࠬࠎࠎࠏࡸࡣ࡯ࡦࡴࡱࡻࡧࡪࡰ࠱ࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬࡦࡪࡤࡰࡰࡢ࡬ࡦࡴࡤ࡭ࡧ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠤࡽࡨ࡭ࡤࡩࡸ࡭࠳ࡒࡩࡴࡶࡌࡸࡪࡳࠨࠪࠫࠍࠍࠎࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲ࡑ࡯ࡳࡵࡋࡷࡩࡲ࠮ࡰࡢࡶ࡫ࡁࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡅ࡭ࡰࡦࡨࡁ࠶࠺࠳ࠧࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮ࠥ࠴ࡈࡹࠩ࠸ࡊࡧࡸࡤ࠴ࡴࡽ࡜ࡴࡸ࠻ࡔࠫ࠮ࠐࠉࠊࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡲ࡯ࡥࡾ࠮ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨ࡯ࡺ࠶࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯࠲࡭ࡵ࡮࡯࡯ࡧ࠲࠵࠷࠹࠴࠵࠹࠱ࡱࡵ࠺ࠧ࠭ࡲ࡯ࡥࡾࡥࡩࡵࡧࡰ࠭ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆส่฿อมࠨ࠮ࠪࠫ࠮ࠐࠉࠣࠤࠥ匨")
	return result
	#if source==l11lll_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ匩"): l111ll_l1_ = l11lll_l1_ (u"ࠪࡌࡑࡇࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ匪")
	#elif source==l11lll_l1_ (u"ࠫ࠹ࡎࡅࡍࡃࡏࠫ匫"): l111ll_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡉࡇࡏࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭匬")
	#elif source==l11lll_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ匭"): l111ll_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡄࡏࡒ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ匮")
	#elif source==l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ匯"): l111ll_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡘࡎ࠴ࠡࠩ匰")
	#size = len(l1ll1ll1l1_l1_)
	#for i in range(0,size):
	#	title = l11l1lll1111_l1_[i]
	#	link = l1ll1ll1l1_l1_[i]
	#	addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ匱"),l111ll_l1_+title,link,160,l11lll_l1_ (u"ࠫࠬ匲"),l11lll_l1_ (u"ࠬ࠭匳"),source)
def l1111llll1ll_l1_(url,source,type=l11lll_l1_ (u"࠭ࠧ匴")):
	url = url.strip(l11lll_l1_ (u"ࠧࠡࠩ匵")).strip(l11lll_l1_ (u"ࠨࠨࠪ匶")).strip(l11lll_l1_ (u"ࠩࡂࠫ匷")).strip(l11lll_l1_ (u"ࠪ࠳ࠬ匸"))
	l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll111_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ匹"),l11lll_l1_ (u"ࠬ࠭区"),url,l11l1lll11l1_l1_)
	if l11l1lll11l1_l1_==l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ医"): return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_:
		while True:
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭匼"), l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ匽")
			else:
				l111l1lll11l_l1_ = l1111_l1_[l1l_l1_]
				title = l1lll1ll_l1_[l1l_l1_]
				LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ匾"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡴࡧ࡯ࡩࡨࡺࡥࡥࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩ匿")+title+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ區")+str(l111l1lll11l_l1_)+l11lll_l1_ (u"ࠬࠦ࡝ࠨ十"))
				if l11lll_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࠩ卂") in l111l1lll11l_l1_ and l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ千") in l111l1lll11l_l1_:
					l111ll1ll11l_l1_,l11lll1l1l11_l1_,l11lll1lll11_l1_ = l11l11lll1ll_l1_(l111l1lll11l_l1_)
					if l11lll1lll11_l1_: l111l1lll11l_l1_ = l11lll1lll11_l1_[0]
					else: l111l1lll11l_l1_ = l11lll_l1_ (u"ࠨࠩ卄")
				if not l111l1lll11l_l1_: result = l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭卅")
				else: result = PLAY_VIDEO(l111l1lll11l_l1_,source,type)
			if result in [l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ卆"),l11lll_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ升")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ午"),l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ卉"),l11lll_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭半")]: break
			else: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ卋"),l11lll_l1_ (u"ࠩࠪ卌"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭卍"),l11lll_l1_ (u"ࠫฬ๊ๅๅใฺ่๊๊ࠣࠦ็็ࠤัืศࠡ็็ๅࠥเ๊า้ࠪ华"))
	else:
		result = l11lll_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ协")
		l111lll11l_l1_ = l11l1ll1ll_l1_(url)
		if l111lll11l_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11l1lll11l1_l1_,l1111_l1_
	#title = xbmc.getInfoLabel( l11lll_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠢ卐") )
	#if l11lll_l1_ (u"ࠧิ์ิๅึูࠦศ็้ࠣัํ่ๅࠩ卑") in title:
	#	import l11ll1lll11_l1_
	#	l11ll1lll11_l1_.MAIN(156)
	#	return l11lll_l1_ (u"ࠨࠩ卒")
def l11111l11111_l1_(url,source):
	# url = url+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ卓")+name+l11lll_l1_ (u"ࠪࡣࡤ࠭協")+type+l11lll_l1_ (u"ࠫࡤࡥࠧ单")+l1l1111_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࠨ卖")+l11l111l_l1_
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡬ࡹࡤࡱ࠳ࡴࡥࡵࡁࡱࡥࡲ࡫ࡤ࠾ࡣ࡮ࡻࡦࡳ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯ࡳ࠸ࡤࡥ࠷࠳࠲ࠪ南")
	l11l11l_l1_,l11l1l111lll_l1_,server,l111ll111l11_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = url,l11lll_l1_ (u"ࠧࠨ単"),l11lll_l1_ (u"ࠨࠩ卙"),l11lll_l1_ (u"ࠩࠪ博"),l11lll_l1_ (u"ࠪࠫ卛"),l11lll_l1_ (u"ࠫࠬ卜"),l11lll_l1_ (u"ࠬ࠭卝"),l11lll_l1_ (u"࠭ࠧ卞")
	#source = source.lower()
	if l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ卟") in url:
		l11l11l_l1_,l11l1l111lll_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ占"),1)
		l11l1l111lll_l1_ = l11l1l111lll_l1_+l11lll_l1_ (u"ࠩࡢࡣࠬ卡")+l11lll_l1_ (u"ࠪࡣࡤ࠭卢")+l11lll_l1_ (u"ࠫࡤࡥࠧ卣")+l11lll_l1_ (u"ࠬࡥ࡟ࠨ卤")
		l11l1l111lll_l1_ = l11l1l111lll_l1_.lower()
		name,type,l1l1111_l1_,l11l111l_l1_,l1lll11ll11l_l1_ = l11l1l111lll_l1_.split(l11lll_l1_ (u"࠭࡟ࡠࠩ卥"))[:5]
	if l11l111l_l1_==l11lll_l1_ (u"ࠧࠨ卦"): l11l111l_l1_ = l11lll_l1_ (u"ࠨ࠲ࠪ卧")
	else: l11l111l_l1_ = l11l111l_l1_.replace(l11lll_l1_ (u"ࠩࡳࠫ卨"),l11lll_l1_ (u"ࠪࠫ卩")).replace(l11lll_l1_ (u"ࠫࠥ࠭卪"),l11lll_l1_ (u"ࠬ࠭卫"))
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"࠭࠿ࠨ卬")).strip(l11lll_l1_ (u"ࠧ࠰ࠩ卭")).strip(l11lll_l1_ (u"ࠨࠨࠪ卮"))
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩ࡫ࡳࡸࡺࠧ卯"))
	if name: l111ll111l11_l1_ = name
	#elif source: l111ll111l11_l1_ = source
	else: l111ll111l11_l1_ = server
	l111ll111l11_l1_ = SERVER(l111ll111l11_l1_,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ印"))
	name = name.replace(l11lll_l1_ (u"๊ࠫฮวีำࠪ危"),l11lll_l1_ (u"ࠬ࠭卲")).replace(l11lll_l1_ (u"࠭ำ๋ำไีࠬ即"),l11lll_l1_ (u"ࠧࠨ却")).replace(l11lll_l1_ (u"ࠨษ็ࠤࠬ卵"),l11lll_l1_ (u"ࠩࠣࠫ卶")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭卷"),l11lll_l1_ (u"ࠫࠥ࠭卸"))
	l11l1l111lll_l1_ = l11l1l111lll_l1_.replace(l11lll_l1_ (u"๋ࠬศศึิࠫ卹"),l11lll_l1_ (u"࠭ࠧ卺")).replace(l11lll_l1_ (u"ࠧิ์ิๅึ࠭卻"),l11lll_l1_ (u"ࠨࠩ卼")).replace(l11lll_l1_ (u"ࠩส่ࠥ࠭卽"),l11lll_l1_ (u"ࠪࠤࠬ卾")).replace(l11lll_l1_ (u"ࠫࠥࠦࠧ卿"),l11lll_l1_ (u"ࠬࠦࠧ厀"))
	l111ll111l11_l1_ = l111ll111l11_l1_.replace(l11lll_l1_ (u"࠭ๅษษืีࠬ厁"),l11lll_l1_ (u"ࠧࠨ厂")).replace(l11lll_l1_ (u"ࠨีํีๆืࠧ厃"),l11lll_l1_ (u"ࠩࠪ厄")).replace(l11lll_l1_ (u"ࠪห้ࠦࠧ厅"),l11lll_l1_ (u"ࠫࠥ࠭历")).replace(l11lll_l1_ (u"ࠬࠦࠠࠨ厇"),l11lll_l1_ (u"࠭ࠠࠨ厈"))
	return l11l11l_l1_,l11l1l111lll_l1_,server,l111ll111l11_l1_,name,type,l1l1111_l1_,l11l111l_l1_
def l11l1ll1l1l1_l1_(url,source):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ厉"),l11lll_l1_ (u"ࠨࠩ厊"),url,l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡃࡅࡐࡊ࠭压"))
	# l1lll1ll1_l1_	: سيرفر خاص
	# l11l1l1l1l11_l1_		: سيرفر محدد
	# l11l1l111l1l_l1_		: سيرفر عام معروف
	# l1ll1ll11_l1_	: سيرفر عام خارجي
	# l1111l1l1111_l1_	: سيرفر عام خارجي
	l111l1ll111l_l1_,name,l1lll1ll1_l1_,l11l1l111l1l_l1_,l1ll1ll11_l1_,l11l1l1l1l11_l1_,l1111l1l1111_l1_ = l11lll_l1_ (u"ࠪࠫ厌"),l11lll_l1_ (u"ࠫࠬ厍"),None,None,None,None,None
	l11l11l_l1_,l11l1l111lll_l1_,server,l111ll111l11_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111l11111_l1_(url,source)
	if l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭厎") in url:
		if   type==l11lll_l1_ (u"࠭ࡥ࡮ࡤࡨࡨࠬ厏"): type = l11lll_l1_ (u"ࠧࠡࠩ厐")+l11lll_l1_ (u"ࠨ็ไฺ้࠭厑")
		elif type==l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ厒"): type = l11lll_l1_ (u"ࠪࠤࠬ厓")+l11lll_l1_ (u"๋ࠫࠪิศ้าอࠬ厔")
		elif type==l11lll_l1_ (u"ࠬࡨ࡯ࡵࡪࠪ厕"): type = l11lll_l1_ (u"࠭ࠠࠨ厖")+l11lll_l1_ (u"ุ่ࠧࠦࠧฬํฯส๋ࠢฮา๋๊ๅࠩ厗")
		elif type==l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ厘"): type = l11lll_l1_ (u"ࠩࠣࠫ厙")+l11lll_l1_ (u"ࠪࠩࠪࠫสฮ็ํ่ࠬ厚")
		elif type==l11lll_l1_ (u"ࠫࠬ厛"): type = l11lll_l1_ (u"ࠬࠦࠧ厜")+l11lll_l1_ (u"࠭ࠥࠦࠧࠨࠫ厝")
		if l1l1111_l1_!=l11lll_l1_ (u"ࠧࠨ厞"):
			if l11lll_l1_ (u"ࠨ࡯ࡳ࠸ࠬ原") not in l1l1111_l1_: l1l1111_l1_ = l11lll_l1_ (u"ࠩࠨࠫ厠")+l1l1111_l1_
			l1l1111_l1_ = l11lll_l1_ (u"ࠪࠤࠬ厡")+l1l1111_l1_
		if l11l111l_l1_!=l11lll_l1_ (u"ࠫࠬ厢"):
			l11l111l_l1_ = l11lll_l1_ (u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨ厣")+l11l111l_l1_
			l11l111l_l1_ = l11lll_l1_ (u"࠭ࠠࠨ厤")+l11l111l_l1_[-9:]
	#if any(value in server for value in l111lll11ll1_l1_): return l11lll_l1_ (u"ࠧࠨ厥")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ厦"),l11lll_l1_ (u"ࠩࠪ厧"),name,l111ll111l11_l1_)
	if   l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ厨")		in source: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ厩")		in source: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ厪")
	elif l11lll_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ厫")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ厬")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ厭")	in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ厮")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ厯")
	#elif l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡷࡹࡧࡴࡪࡱࡱࠫ厰") in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ厱")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭厲")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	#elif l11lll_l1_ (u"ࠧࡱࡥࡵࡩࡻ࡯ࡥࡸࠩ厳")	in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩ厴")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩࡷ࠻ࡲ࡫ࡥ࡭ࠩ厵")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠪࡱࡴࡼࡳ࠵ࡷࠪ厶")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭厷")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠬ࡬ࡡ࡫ࡧࡵࠫ厸")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣࠩ厹")	in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡨࡲࡵࡱࠩ厺")
	elif l11lll_l1_ (u"ࠨใฯีࠬ去")			in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ厼")
	elif l11lll_l1_ (u"ࠪๅู้ื๋่ࠪ厽")		in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧ厾")
	elif l11lll_l1_ (u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬ县")		in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪ࠭叀")
	elif l11lll_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ叁")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨࡹࡨࡧ࡮ࡳࡡࠨ参")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ參")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫ叄")		in name:   l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ叅")	in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ叆")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ叇")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭又")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ叉")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ及")		in server: l1lll1ll1_l1_	= l111ll111l11_l1_
	#elif l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺ࠲ࡳ࡫ࡴࠨ友")	in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࠥ࠭双")
	elif l11lll_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ反")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨ収")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧ叏")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ叐")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ发")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ叒")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ叓")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭叔")
	elif l11lll_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭叕")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ取")
	elif l11lll_l1_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭受")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭变")
	elif l11lll_l1_ (u"ࠪࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ叙")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠶࠭叚")
	elif l11lll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭叛")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨ叜")
	#elif l11lll_l1_ (u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ叝")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ叞")
	elif l11lll_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ叟")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ叠")
	elif l11lll_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ叡")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ叢")
	elif l11lll_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ口")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳࠧ古")
	elif l11lll_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ句")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ另")
	elif l11lll_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭叧")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ叨")
	elif l11lll_l1_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭叩")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ只")
	elif l11lll_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ叫")	 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠨࡥࡤࡸࡨ࡮ࠧ召")
	elif l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ叭")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ叮")
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ可")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ台")
	elif l11lll_l1_ (u"࠭ࡶࡪࡦ࡫ࡨࠬ叱")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠧ࡮ࡻࡹ࡭ࡩ࠭史")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠨ࡯ࡼࡺ࡮࡯ࡤࠨ右")		in server: l11l1l1l1l11_l1_	= l111ll111l11_l1_
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ叴")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ叵")
	elif l11lll_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ叶")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ号")
	elif l11lll_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ司") 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ叹")
	elif l11lll_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ叺")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ叻")
	elif l11lll_l1_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨ叼")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ叽")
	elif l11lll_l1_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ叾") 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ叿")
	elif l11lll_l1_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ吀")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ吁")
	elif l11lll_l1_ (u"ࠩࡸࡴࡵ࠭吂") 			in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠪࡹࡵࡨ࡯࡮ࠩ吃")
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࠨ各") 			in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠬࡻࡰࡣࡱࡰࠫ吅")
	elif l11lll_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭吆") 		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ吇")
	elif l11lll_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ合") 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ吉")
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ吊")		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ吋")
	elif l11lll_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ同") 		in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭名")
	elif l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ后") 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ吏")
	elif l11lll_l1_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭吐")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ向")
	elif l11lll_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ吒")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ吓")
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ吔") 	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠧࡶࡲࡷࡳࡧࡵࡸࠨ吕")
	#elif l11lll_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ吖")	in server: l11l1l111l1l_l1_	= l11lll_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭吗")
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࡵࡳ࡮࠮ࠫࡂࡃ࠽ࠨ࠭ࡸࡶࡱ࠸ࠩࠋࠋࠌࡸࡷࡿ࠺ࠋࠋࠌࠍ࡮ࡳࡰࡰࡴࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠋࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰ࠳ࡎ࡯ࡴࡶࡨࡨࡒ࡫ࡤࡪࡣࡉ࡭ࡱ࡫ࠨࡶࡴ࡯࠶࠮࠴ࡶࡢ࡮࡬ࡨࡤࡻࡲ࡭ࠪࠬࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࡳ࠼ࠍࠍࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࠬ࠷࠱࠲࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩࠬࠎࠎࠏࠉࡳࡧࡶࡳࡱࡼࡥࡳࠢࡀࠤࡋࡧ࡬ࡴࡧࠍࠍࠎࠏࠣࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡳࡺࡺࡵࡣࡧ࠰ࡨࡱ࠴࡯ࡳࡩࠍࠍࠎࠏ࡬ࡪࡵࡷࡣࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡿࡴࡥ࡮࠰ࡳࡷ࡭࠮ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡪࡱ࠲ࡽࡴࡻࡴࡶࡤࡨ࠱ࡩࡲ࠯ࡴࡷࡳࡴࡴࡸࡴࡦࡦࡶ࡭ࡹ࡫ࡳ࠯ࡪࡷࡱࡱ࠭ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭࡮࡬ࡷࡹࡥࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡉࡘࡕࡌࡗࡃࡅࡐࡊ࠳࠱ࡴࡶࠪ࠭ࠏࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࠼ࡶ࡮ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡩࡧࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࡞࠴ࡢ࠴࡬ࡰࡹࡨࡶ࠭࠯ࠊࠊࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁࡲࡩ࠿ࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿ࡦࡃ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡰ࡮ࡄࠧ࠭ࠩࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽࠱ࡥࡂࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱࠭࠲࠳࠴࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ࠭ࠏࠏࠉࠊࠋࡳࡥࡷࡺࡳࠡ࠿ࠣࡷࡪࡸࡶࡦࡴ࠱ࡷࡵࡲࡩࡵࠪࠪ࠲ࠬ࠯ࠊࠊࠋࠌࠍ࡫ࡵࡲࠡࡲࡤࡶࡹࠦࡩ࡯ࠢࡳࡥࡷࡺࡳ࠻ࠌࠌࠍࠎࠏࠉࡪࡨࠣࡰࡪࡴࠨࡱࡣࡵࡸ࠮ࡂ࠴࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࠉࠊࠋࡨࡰ࡮࡬ࠠࡱࡣࡵࡸࠥ࡯࡮ࠡࡪࡷࡱࡱࡀࠊࠊࠋࠌࠍࠎࠏࡲࡦࡵࡲࡰࡻ࡫ࡲࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠌࠍࠎࠏࠉࡣࡴࡨࡥࡰࠐࠉࠣࠤࠥ吘")
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ吙"),l11lll_l1_ (u"ࠬ࠭吚"),url,l11l11l_l1_)
	if   l1lll1ll1_l1_:	l111l1ll111l_l1_,name = l11lll_l1_ (u"࠭ฮศืࠪ君"),l1lll1ll1_l1_
	elif l11l1l1l1l11_l1_:		l111l1ll111l_l1_,name = l11lll_l1_ (u"ࠧࠦ็ะำิ࠭吜"),l11l1l1l1l11_l1_
	elif l11l1l111l1l_l1_:		l111l1ll111l_l1_,name = l11lll_l1_ (u"ࠨࠧࠨ฽ฬ๋ࠠๆ฻ิ์ๆ࠭吝"),l11l1l111l1l_l1_
	elif l1ll1ll11_l1_:	l111l1ll111l_l1_,name = l11lll_l1_ (u"ࠩࠨࠩࠪ฿วๆࠢัหึา๊ࠨ吞"),l1ll1ll11_l1_
	elif l1111l1l1111_l1_:	l111l1ll111l_l1_,name = l11lll_l1_ (u"ฺࠪࠩࠪࠫࠥษ่ࠤำอัอ์ࠪ吟"),l111ll111l11_l1_
	else:			l111l1ll111l_l1_,name = l11lll_l1_ (u"ࠫࠪࠫࠥࠦࠧ฼ห๊ࠦๅอ้๋่ࠬ吠"),l111ll111l11_l1_
	return l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࠨࡲ࡯ࡥࡾࡸ࠮࠵ࡪࡨࡰࡦࡲࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏࡰࡳ࡫ࡹࡥࡹ࡫ࠠ࠾ࠢࠪ࡬ࡪࡲࡡ࡭ࠩࠍࠍࡪࡲࡩࡧࠢࠪࡩࡸࡺࡲࡦࡣࡰࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡪࡰࡷࡳࡺࡶ࡬ࡰࡣࡧࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡩ࡯ࡶࡲࡹࡵࡲ࡯ࡢࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡹ࡮ࡥࡷ࡫ࡧࡩࡴ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠶࠿ࠏ࡫࡯ࡱࡺࡲࠥࡃࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡫ࡶ࠯࡫ࡲࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷࡧࡹࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡤࡲࡱࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷ࡫ࡧࡦࡴࡳࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨ࡭ࡪࠧࠡࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪࡺ࡮ࡪࡨࡥࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡳࡩࡣࡵࡩࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷ࡫ࡧࡷ࡭ࡧࡲࡦࠩࠍࠍࠧࠨࠢ吡")
def l111l111l11l_l1_(url,source):
	l11l11l_l1_,l11l1l111lll_l1_,server,l111ll111l11_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111l11111_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ吢"),l11lll_l1_ (u"ࠧࠨ吣"),l11l1l1l1l11_l1_,server)
	#if l11lll_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭吤")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ吥"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ否"))
	#if any(value in server for value in l111lll11ll1_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗࡋࡓࡐࡎ࡙ࡉࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡦࡴࡹࡩࡷ࠭吧")],[]
	if   l11lll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ吨")		in source: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l111l_l1_(l11l11l_l1_,name)
	elif l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ吩")		in source: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111111_l1_(l11l11l_l1_,type,l11l111l_l1_)
	elif l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ吪")		in source: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lllll11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ含")		in source: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ听")		in source: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ吭")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11l11ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ吮")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ启")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1ll1111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ吰")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l1111lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ吱")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l1111lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ吲")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ吳")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll111ll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡸࡻࡱࡳࡢࠩ吴")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll111ll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡹࡼ࠭ࡧ࠰ࡦࡳࡲ࠭吵")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll111ll1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ吶")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ吷")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ吸")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11ll11111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ吹")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ吺")			in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l1lll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ吻")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1llllll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ吼")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭吽")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ吾")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ吿")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ呀")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll11111111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ呁")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111lll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ呂")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ呃")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ呄")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭呅")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡴࡦࡥ࡫ࠫ呆")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡩࡸࡰ࡫ࡺࡥࡤࡪࠪ呇")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡴࡤࡸࡪ࠭呈")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡴࡨࡸࡥࡷ࡫ࡨࡻࠬ呉")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ告")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ呋")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ呌")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࠨ呍"),[l11lll_l1_ (u"ࠨࠩ呎")],[l11l11l_l1_]
	#elif l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ呏")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1l1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ呐")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ呑")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ呒")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111111l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ呓") 		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࠨ呔"),[l11lll_l1_ (u"ࠨࠩ呕")],[l11l11l_l1_]
	else: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ呖"),[l11lll_l1_ (u"ࠪࠫ呗")],[l11l11l_l1_]
	return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
def l11l1l1111ll_l1_(url,source):
	server = SERVER(url,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ员"))
	#if l11lll_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ呙")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭呚"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭呛"))
	#if any(value in server for value in l111lll11ll1_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ呜")],[]
	l111l111l111_l1_ = False
	if   l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࠨ呝")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ呞")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴࠨ呟") in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll11l111_l1_(url)
	elif l11lll_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫ呠")	in url: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll1l111_l1_(url)
	elif l11lll_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ呡")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(url)
	elif l11lll_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡲࡢࡶࡨࠫ呢")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(url)
	elif l11lll_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭呣")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1l11_l1_(url)
	elif l11lll_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ呤")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11lll1ll_l1_(url)
	elif l11lll_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ呥")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lllll11_l1_(url)
	elif l11lll_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ呦")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11lll1l_l1_(url)
	elif l11lll_l1_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭呧")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111111lll_l1_(url)
	elif l11lll_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ周")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1ll1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡦ࠷ࡷࡷࡦࡸࠧ呩")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l111lllll_l1_(url)
	elif l11lll_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ呪")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11l11l11_l1_(url)
	elif l11lll_l1_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬ呫")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11l11l11_l1_(url)
	elif l11lll_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ呬")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ呭")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ呮")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"࠭ࡶࡪࡦ࡫ࡨࠬ呯")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ呰")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"ࠨ࡮࡬࡭࡮ࡼࡩࡥࡧࡲࠫ呱")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡵࡢࡢࠩ呲")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111111lll1l_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡳࡱࡧࡨࡨࠬ味")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111111lll1l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡺࡶࡢࡢ࡯ࠪ呴") 		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬ࠭呵"),[l11lll_l1_ (u"࠭ࠧ呶")],[url]
	#elif l11lll_l1_ (u"ࠧࡨࡱࡹ࡭ࡩ࠭呷")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111111ll1_l1_(url)
	elif l11lll_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ呸") 	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111lll111ll_l1_(url)
	elif l11lll_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ呹")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11111l11_l1_(url)
	elif l11lll_l1_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࡩࡱࠪ呺")in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1lllll1_l1_(url)
	elif l11lll_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ呻") 	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11ll111l_l1_(url)
	elif l11lll_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭呼")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11l11l1_l1_(url)
	elif l11lll_l1_ (u"࠭ࡵࡱࡤࠪ命") 			in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllllllll11_l1_(url)
	elif l11lll_l1_ (u"ࠧࡶࡲࡳࠫ呾") 			in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllllllll11_l1_(url)
	#elif l11lll_l1_ (u"ࠨࡷࡳࡸࡴࡨ࡯ࡹࠩ呿") 	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1l111_l1_(url)
	#elif l11lll_l1_ (u"ࠩࡸࡴࡹࡵࡳࡵࡴࡨࡥࡲ࠭咀")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1l111_l1_(url)
	elif l11lll_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ咁") 		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1111ll11111_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭咂") 	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll1lll11_l1_(url)
	elif l11lll_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ咃")		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11111ll_l1_(url)
	elif l11lll_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭咄") 		in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1111lll1l11_l1_(url)
	elif l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ咅") 	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111lllll1ll_l1_(url)
	elif l11lll_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ咆")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l1111ll11l11_l1_(url)
	elif l11lll_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭咇")	in server: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l1ll11_l1_(url)
	else: l111l111l111_l1_ = True
	if l111l111l111_l1_ or l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠬ咈") in l11l1lll11l1_l1_:
		l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠳ࠣࡊࡦ࡯࡬ࡦࡦࠪ咉"),[],[]
	return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࠨࡧࡶࡸࡷ࡫ࡡ࡮ࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡙ࡔࡓࡇࡄࡑ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡉࡒ࡙ࡓࡒࡉࡎࡋࡗࡉࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡌࡒ࡙ࡕࡕࡑࡎࡒࡅࡉ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡹ࡮ࡥࡷ࡫ࡧࡩࡴ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡕࡊࡈ࡚ࡎࡊࡅࡐࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷࡧࡹ࠲࡮ࡵࠧࠊࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡉ࡛ࡏࡏࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡰ࡭ࡣࡼࡶ࠳࠺ࡨࡦ࡮ࡤࡰࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡎࡅࡍࡃࡏࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡨ࡯࡮ࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿࡚ࠣࡎࡊࡂࡐࡏࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨ࡭ࡪࠧࠡࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡍࡉࡎࡄࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡶ࡬ࡦࡸࡥࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾࡙ࠢࡍࡉ࡙ࡈࡂࡔࡈࠬࡺࡸ࡬ࠪࠌࠌࠦࠧࠨ咊")
def l111ll1l1l1l_l1_(l11llll11l11_l1_):
	if l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ咋") in str(type(l11llll11l11_l1_)):
		links = []
		for link in l11llll11l11_l1_:
			if l11lll_l1_ (u"ࠧࡴࡶࡵࠫ和") in str(type(link)):
				link = link.replace(l11lll_l1_ (u"ࠨ࡞ࡵࠫ咍"),l11lll_l1_ (u"ࠩࠪ咎")).replace(l11lll_l1_ (u"ࠪࡠࡳ࠭咏"),l11lll_l1_ (u"ࠫࠬ咐")).strip(l11lll_l1_ (u"ࠬࠦࠧ咑"))
			links.append(link)
	else: links = l11llll11l11_l1_.replace(l11lll_l1_ (u"࠭࡜ࡳࠩ咒"),l11lll_l1_ (u"ࠧࠨ咓")).replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ咔"),l11lll_l1_ (u"ࠩࠪ咕")).strip(l11lll_l1_ (u"ࠪࠤࠬ咖"))
	return links
def l11111lll111_l1_(url,source):
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ咗"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭咘")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠩ咙"))
	l1111l1l1111_l1_,link,l111ll1l1ll1_l1_ = l11lll_l1_ (u"ࠧࡊࡐࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࠫ咚"),l11lll_l1_ (u"ࠨࠩ咛"),l11lll_l1_ (u"ࠩࠪ咜")
	l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l111l111l11l_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ咝"),l11lll_l1_ (u"ࠫࠬ咞"),l11lll_l1_ (u"ࠬ࠭咟"),l11l1lll11l1_l1_)
	l1111_l1_ = l111ll1l1l1l_l1_(l1111_l1_)
	if l11l1lll11l1_l1_==l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ咠"): return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_: link = l1111_l1_[0]
	if l11l1lll11l1_l1_==l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ咡"):
		#l11l1lll11l1_l1_ = l11l1lll11l1_l1_.replace(l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ咢"),l11lll_l1_ (u"ࠩࠪ咣"))
		l1111l1l1111_l1_ = l11lll_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ咤")
		l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1111ll_l1_(link,source)
		l1111_l1_ = l111ll1l1l1l_l1_(l1111_l1_)
		if l11l1lll11l1_l1_==l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ咥"): return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
		elif l11lll_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠴ࠫ咦") in l11l1lll11l1_l1_:
			l111ll1l1ll1_l1_ += l11lll_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵࠿ࠦࠧ咧")+l11l1lll11l1_l1_
			l1111l1l1111_l1_ = l11lll_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭咨")
			l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1111l1_l1_(link,source)
			l1111_l1_ = l111ll1l1l1l_l1_(l1111_l1_)
			if l11l1lll11l1_l1_==l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭咩"): return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
			elif l11lll_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨ咪") in l11l1lll11l1_l1_:
				l111ll1l1ll1_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠫ咫")+l11l1lll11l1_l1_
				l1111l1l1111_l1_ = l11lll_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ咬")
				l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l11111l_l1_(link,source)
				l1111_l1_ = l111ll1l1l1l_l1_(l1111_l1_)
				if l11l1lll11l1_l1_==l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ咭"): return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
				elif l11lll_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬ咮") in l11l1lll11l1_l1_:
					l111ll1l1ll1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࡀࠠࠨ咯")+l11l1lll11l1_l1_
	elif l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ咰") in l11l1lll11l1_l1_: l111ll1l1ll1_l1_ = l11lll_l1_ (u"ࠩࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠵ࡀࠠࠨ咱")+l11l1lll11l1_l1_
	if l1111_l1_: LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ咲"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡔࡨࡷࡴࡲࡶࡦࡴ࠽ࠤࡠࠦࠧ咳")+l1111l1l1111_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ咴")+url+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭咵")+link+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡷ࡯ࡸࡸࡀࠠ࡜ࠢࠪ咶")+str(l1111_l1_)+l11lll_l1_ (u"ࠨࠢࡠࠫ咷"))
	else: LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ咸"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ咹")+url+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ咺")+link+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡉࡷࡸ࡯ࡳࡵ࠽ࠤࡠࠦࠧ咻")+l111ll1l1ll1_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ咼"))
	l111ll1l1ll1_l1_ = l111l_l1_(l111ll1l1ll1_l1_)
	return l111ll1l1ll1_l1_,l1lll1ll_l1_,l1111_l1_
def l1111ll1111l_l1_(l11lll1lll11_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ咽"),l11lll1lll11_l1_)
	l11lll1lll1_l1_ = l11111l_l1_
	data = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭咾"),l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪ咿"),l11lll1lll11_l1_)
	if data:
		l1lll1ll_l1_,l1111_l1_ = list(zip(*data))
		return l1lll1ll_l1_,l1111_l1_
	l1lll1ll_l1_,l1111_l1_,l11l1lll1111_l1_ = [],[],[]
	for link in l11lll1lll11_l1_:
		if l11lll_l1_ (u"ࠪ࠳࠴࠭哀") not in link: continue
		l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11l1ll1l1l1_l1_(link,source)
		l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡡࡪࠫࠨ品"),l11l111l_l1_,re.DOTALL)
		if l11l111l_l1_: l11l111l_l1_ = int(l11l111l_l1_[0])
		else: l11l111l_l1_ = 0
		#if l11l111l_l1_:
		#	l11l11lll111_l1_ = sorted(l11l111l_l1_,reverse=True,key=lambda key: int(key))
		#	l11l111l_l1_ = int(l11l11lll111_l1_[0])
		#else: l11l111l_l1_ = 0
		server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ哂"))
		l11l1lll1111_l1_.append([l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server])
	if l11l1lll1111_l1_:
		#l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link = zip(*l11l1lll1111_l1_)
		#name = reversed(name)
		#l11l1lll1111_l1_ = zip(l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link)
		l1lll11l11ll_l1_ = sorted(l11l1lll1111_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111ll11llll_l1_ = []
		for line in l1lll11l11ll_l1_:
			if line not in l111ll11llll_l1_:
				l111ll11llll_l1_.append(line)
				#LOG_THIS(l11lll_l1_ (u"࠭ࠧ哃"),str(line))
		for l111l1ll111l_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server in l111ll11llll_l1_:
			if l11l111l_l1_: l11l111l_l1_ = str(l11l111l_l1_)
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠧࠨ哄")
			#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ哅"),l11lll_l1_ (u"ࠩࠪ哆"),name,link)
			title = l11lll_l1_ (u"ࠪื๏ืแาࠩ哇")+l11lll_l1_ (u"ࠫࠥ࠭哈")+type+l11lll_l1_ (u"ࠬࠦࠧ哉")+l111l1ll111l_l1_+l11lll_l1_ (u"࠭ࠠࠨ哊")+l11l111l_l1_+l11lll_l1_ (u"ࠧࠡࠩ哋")+l1l1111_l1_+l11lll_l1_ (u"ࠨࠢࠪ哌")+name
			if server not in title: title = title+l11lll_l1_ (u"ࠩࠣࠫ响")+server
			title = title.replace(l11lll_l1_ (u"ࠪࠩࠬ哎"),l11lll_l1_ (u"ࠫࠬ哏")).strip(l11lll_l1_ (u"ࠬࠦࠧ哐")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ哑"),l11lll_l1_ (u"ࠧࠡࠩ哒")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ哓"),l11lll_l1_ (u"ࠩࠣࠫ哔")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭哕"),l11lll_l1_ (u"ࠫࠥ࠭哖"))
			if link not in l1111_l1_:
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		if l1111_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ哗"),l1111_l1_)
			data = list(zip(l1lll1ll_l1_,l1111_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ哘"),l11lll1lll11_l1_,data,l11lll1lll1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ哙"),l11lll_l1_ (u"ࠨࡦࡤࡸࡦࡀ࠲࠻ࠢࠣࠤࠬ哚")+str(data))
	return l1lll1ll_l1_,l1111_l1_
def l11l1l1111l1_l1_(url,source):
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࡈࡡࡘࡡ࡭ࡩࡳࡵࡺࡌࡥࠪ哛")
	l1lll1lll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ哜")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l1l1l1l1l_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1lll1lll1ll_l1_ = str(error)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ哝"),l11lll_l1_ (u"ࠬ࠭哞"),l11lll_l1_ (u"࠭ࠧ哟"),str(results))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ哠"),l11lll_l1_ (u"ࠨࠩ員"),l11lll_l1_ (u"ࠩࠪ哢"),str(l1lll1lll1ll_l1_))
	# resolveurl l1111l1l11_l1_ l1ll1l11l1l_l1_ l1111l11l1ll_l1_ with l111111l1l11_l1_ error or l111ll1ll1ll_l1_ value False
	if not results:
		if l1lll1lll1ll_l1_==l11lll_l1_ (u"ࠪࠫ哣"):
			l1lll1lll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lll1ll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ哤"),l11lll_l1_ (u"ࠬ࠭哥"),l11lll_l1_ (u"࠭ࠧ哦"),str(l1lll1lll1ll_l1_))
		l11l1lll11l1_l1_ = l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷ࠦࡆࡢ࡫࡯ࡩࡩ࠭哧")
		l11l1lll11l1_l1_ += l11lll_l1_ (u"ࠨࠢࠪ哨")+l1lll1lll1ll_l1_.splitlines()[-1]
		return l11l1lll11l1_l1_,[],[]
	return l11lll_l1_ (u"ࠩࠪ哩"),[l11lll_l1_ (u"ࠪࠫ哪")],[results]
def l11l1l11111l_l1_(url,source):
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡃࡣ࡚ࡣ࡯࡫࡮ࡰࡼࡎࡧࠬ哫")
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱ࠴ࡼࡩࡥࡧࡲ࠳ࡽ࠽ࡹࡺ࠶࠴ࡷࠬ哬")
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ哭"),l11lll_l1_ (u"ࠧࠨ哮"),url,l11lll_l1_ (u"ࠨࠩ哯"))
	#return l11lll_l1_ (u"ࠩࠪ哰"),[],[]
	l1lll1lll1ll_l1_ = l11lll_l1_ (u"ࠪࠫ哱")
	results = False
	try:
		import youtube_dl
		l11l1ll111ll_l1_ = youtube_dl.YoutubeDL({l11lll_l1_ (u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭哲"): True})
		results = l11l1ll111ll_l1_.extract_info(url,download=False)
	except Exception as error: l1lll1lll1ll_l1_ = str(error)
	# youtube_dl l1111l1l11_l1_ l1ll1l11l1l_l1_ l1111l11l1ll_l1_ with l111111l1l11_l1_ error or l111ll1ll1ll_l1_ value False
	if not results or l11lll_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭哳") not in list(results.keys()):
		if l1lll1lll1ll_l1_==l11lll_l1_ (u"࠭ࠧ哴"):
			l1lll1lll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lll1ll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ哵"),l11lll_l1_ (u"ࠨࠩ哶"),l11lll_l1_ (u"ࠩࠪ哷"),l1lll1lll1ll_l1_)
		l11l1lll11l1_l1_ = l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠢࡉࡥ࡮ࡲࡥࡥࠩ哸")
		l11l1lll11l1_l1_ += l11lll_l1_ (u"ࠫࠥ࠭哹")+l1lll1lll1ll_l1_.splitlines()[-1]
		return l11l1lll11l1_l1_,[],[]
	else:
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link in results[l11lll_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭哺")]:
			l1lll1ll_l1_.append(link[l11lll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹ࠭哻")])
			l1111_l1_.append(link[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ哼")])
		return l11lll_l1_ (u"ࠨࠩ哽"),l1lll1ll_l1_,l1111_l1_
def l11l1ll1111l_l1_(url):
	if l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ哾") in url:
		l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(url)
		if l1111_l1_: return l11lll_l1_ (u"ࠪࠫ哿"),l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡍࡃࡕࡅࡇ࠭唀"),[],[]
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ唁"),[l11lll_l1_ (u"࠭ࠧ唂")],[url]
def l1l11l11ll1_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ唃"),l11lll_l1_ (u"ࠨࠩ唄"),l11lll_l1_ (u"ࠩࠪ唅"),url)
	l1lllll1_l1_,l1lllll11l1_l1_ = [],[]
	if l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶ࠲ࡲࡶ࠴ࡀࡸ࡬ࡨࡂ࠭唆") in url:
		# l11l1111111l_l1_:
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1111l1l11l1_l1_.html
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1111lll_l1_?l1l11l1l1l1_l1_=49e3a27b4
		# l111l1l1111l_l1_: https://l111ll1lllll_l1_.l1ll1ll1l11_l1_.l1111111ll1l_l1_.l1ll1lll111_l1_/15/items/40animeHD/l111ll1l1lll_l1_.l1111lll_l1_
		# l11l1111111l_l1_:
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1111lll1l1l_l1_-l111lll1llll_l1_.html
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1111lll_l1_?l1l11l1l1l1_l1_=l11111l1l1l1_l1_
		# l111l1l1111l_l1_: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l11ll11l1l_l1_/l111ll11l1l1_l1_%20.l1111lll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ唇"),url,l11lll_l1_ (u"ࠬ࠭唈"),l11lll_l1_ (u"࠭ࠧ唉"),False,l11lll_l1_ (u"ࠧࠨ唊"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠱ࡴࡶࠪ唋"))
		if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ唌") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ唍")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ唎"))
			l1lllll11l1_l1_.append(server)
	elif l11lll_l1_ (u"ࠬࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰࠫ唏") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l11l1111111l_l1_:
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l1l1ll1l1_l1_.html
		# link: https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l11l1ll11ll1_l1_/?link=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1l11l1l1_l1_&l11111l111ll_l1_=
		# l11l1111111l_l1_:
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# link: https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?url=l111111l1lll_l1_==&sub=https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l11l11111lll_l1_/l111111l1l1l_l1_.l11111ll1111_l1_&l11111l111ll_l1_=https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l1111l1ll1ll_l1_/l11111111111_l1_-1.l1111lll111l_l1_
		# l11l1111111l_l1_:
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll111ll1_l1_.html
		# link: https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l111l1l1lll1_l1_/?url=https://photos.l111l1l1111_l1_.l111llllll1l_l1_.l11ll1111ll1_l1_/l111ll1llll1_l1_&sub=&l11111l111ll_l1_=http://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l1111l1ll1ll_l1_/4723b8ebe-1.l1111lll111l_l1_
		# l11l1111111l_l1_:
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l1l1lllll_l1_.html
		# https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l11l1ll11ll1_l1_/?link=https://l1l11111l11_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1l11l1l1_l1_&sub=&l11111l111ll_l1_=https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l1111l1ll1ll_l1_/2e8bc4c34-1.l1111lll111l_l1_
		# l11l1111111l_l1_:
		# https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_111l1111l1l_l1_.html
		# https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l11l1ll11ll1_l1_/?link=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1l11ll11_l1_=l11l1l11l11l_l1_&l11111l111ll_l1_=https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l1111l1ll1ll_l1_/l11l11111111_l1_-1.l1111lll111l_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ唐"),url,l11lll_l1_ (u"ࠧࠨ唑"),l11lll_l1_ (u"ࠨࠩ唒"),l11lll_l1_ (u"ࠩࠪ唓"),l11lll_l1_ (u"ࠪࠫ唔"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯࠵ࡲࡩ࠭唕"))
		html = response.content
		l1ll11l11l11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩࡢࠩ࠯ࠬࡂࡠ࠮ࡢࠩࠪ࠰࠿࠳ࡸࡩࡲࡪࡲࡷࡂࠬ唖"),html,re.DOTALL)
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ唗"),str(l1ll11l11l11_l1_))
		if l1ll11l11l11_l1_:
			l1ll11l11l11_l1_ = l1ll11l11l11_l1_[0]
			l1l1l1l1l111_l1_ = l1l1ll1l111l_l1_(l1ll11l11l11_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠧࠨ唘"),str(l1l1l1l1l111_l1_))
			l1l1l11l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭࠱࠭唙"),l1l1l1l1l111_l1_,re.DOTALL)
			if l1l1l11l1ll1_l1_:
				l1l1l11l1ll1_l1_ = l1l1l11l1ll1_l1_[0]
				l1l1l11l1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ唚"),l1l1l11l1ll1_l1_)
				for dict in l1l1l11l1ll1_l1_:
					link = dict[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࠨ唛")]
					l11l111l_l1_ = dict[l11lll_l1_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ唜")]
					#link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࠨ唝")+l11l111l_l1_
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ唞"))
					l1lllll11l1_l1_.append(l11l111l_l1_+l11lll_l1_ (u"ࠧࠡࠩ唟")+server)
		elif l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ唠") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ唡")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ唢"))
			l1lllll11l1_l1_.append(server)
		# l11l1111111l_l1_: 5
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll111ll1_l1_.html
		# link: https://www.l1l11l1l111_l1_.com/l11111l1l11l_l1_/l111l1l1lll1_l1_/?url=https://photos.l111l1l1111_l1_.l111llllll1l_l1_.l11ll1111ll1_l1_/l111ll1llll1_l1_&sub=&l11111l111ll_l1_=http://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11111lll1l1_l1_/l1111l1ll1ll_l1_/4723b8ebe-1.l1111lll111l_l1_
		if l11lll_l1_ (u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫ唣") in url:
			link = url.split(l11lll_l1_ (u"ࠬࡅࡵࡳ࡮ࡀࠫ唤"))[1]
			link = link.split(l11lll_l1_ (u"࠭ࠦࠨ唥"))[0]
			if link:
				l1lllll1_l1_.append(link)
				l1lllll11l1_l1_.append(l11lll_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧ唦"))
	else:
		# l11l1111111l_l1_:
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_11111l1111l_l1_.html
		# link: http://ok.l111lllllll1_l1_/l11l111ll1ll_l1_/1676019108395
		# l11l1111111l_l1_:
		# url: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_11111l1l111_l1_.html
		# link: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1l11l1l1_l1_
		l1lllll1_l1_.append(url)
		server = SERVER(url,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭唧"))
		l1lllll11l1_l1_.append(server)
	if not l1lllll1_l1_: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭唨"),[],[]
	elif len(l1lllll1_l1_)==1: link = l1lllll1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ唩"),l1lllll11l1_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ唪"),[],[]
		link = l1lllll1_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ唫"),[l11lll_l1_ (u"࠭ࠧ唬")],[link]
def l111ll11l111_l1_(url):
	# test from: https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11l1l11lll1_l1_-l111ll11l1ll_l1_-l111l1l111l1_l1_-l1111ll1l11l_l1_-l1111lll1111_l1_-l11ll11l1l_l1_-1-date.html
	# url = https://l11l11l1lll1_l1_.l1111111111l_l1_.com/l111l11lll11_l1_=l111lll1ll11_l1_
	headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ唭"):l11lll_l1_ (u"ࠨࡍࡲࡨ࡮࠵ࠧ售")+str(kodi_version)}
	for l11l1lllll_l1_ in range(50):
		time.sleep(0.100)
		response = l11lll11ll1_l1_(l11lll_l1_ (u"ࠩࡊࡉ࡙࠭唯"),url,l11lll_l1_ (u"ࠪࠫ唰"),headers,False,l11lll_l1_ (u"ࠫࠬ唱"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘ࠲࠷ࡳࡵࠩ唲"))
		if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ唳") in list(response.headers.keys()):
			link = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ唴")]
			link = link+l11lll_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ唵")+headers[l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭唶")]
			return l11lll_l1_ (u"ࠪࠫ唷"),[l11lll_l1_ (u"ࠫࠬ唸")],[link]
		if response.code!=429: break
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫ唹"),[],[]
def l111lll1l111_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ唺"),l11lll_l1_ (u"ࠧࠨ唻"),l11lll_l1_ (u"ࠨࠩ唼"),url)
	# https://photos.l111l1l1111_l1_.l111llllll1l_l1_.l11ll1111ll1_l1_/l111ll1llll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭唽"),url,l11lll_l1_ (u"ࠪࠫ唾"),l11lll_l1_ (u"ࠫࠬ唿"),l11lll_l1_ (u"ࠬ࠭啀"),l11lll_l1_ (u"࠭ࠧ啁"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆ࠯࠴ࡷࡹ࠭啂"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠨࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࠪࡀࠫࠥ࠰࠳࠰࠿࠭࠰࠭ࡃ࠱࠮࠮ࠫࡁࠬ࠰ࠬ啃"),html,re.DOTALL)
	if link:
		link,l11l111l_l1_ = link[0]
		return l11lll_l1_ (u"ࠩࠪ啄"),[l11l111l_l1_],[link]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈࠫ啅"),[],[]
def l1l1lllll11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ商"),l11lll_l1_ (u"ࠬ࠭啇"),l11lll_l1_ (u"࠭ࠧ啈"),url)
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠴࡯࡯ࡧ࠲ࡺ࡮ࡪࡥࡰࡡࡳࡰࡦࡿࡥࡳࡁࡸ࡭ࡩࡃ࠰ࠧࡸ࡬ࡨࡂ࡬ࡦࡣ࠹࠳࠼ࡨ࠷࠹࠳ࡥ࠵࠼ࡩ࠷࠱࠳࠲࠵ࡥࡩ࠷࠸ࡥࡦ࠴࠶ࡨ࠼࠸࠱࠸ࠪ啉")
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥࡸ࡫࡬ࡩࡦ࠰ࡩࡲࡨࡥࡥ࠰ࡶࡧࡩࡴ࠮ࡵࡱ࠲ࡺ࡮ࡪࡥࡰࡡࡳࡰࡦࡿࡥࡳࡁࡸ࡭ࡩࡃ࠰ࠧࡸ࡬ࡨࡂࡨ࠰࠲࠷࠼࠴࠹ࡧ࠸ࡢࡥࡩ࠻࠾࠻࠶ࡥ࠳ࡨ࠻࠻࠹࠰ࡣࡧ࠴࠻࠻࠻࠸࠸࠵ࠪ啊")
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭啋"),url,l11lll_l1_ (u"ࠪࠫ啌"),l11lll_l1_ (u"ࠫࠬ啍"),l11lll_l1_ (u"ࠬ࠭啎"),l11lll_l1_ (u"࠭ࠧ問"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࠷ࡳࡵࠩ啐"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ啑"),html)
	link = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ啒"),html,re.DOTALL)
	if link: return l11lll_l1_ (u"ࠪࠫ啓"),[l11lll_l1_ (u"ࠫࠬ啔")],[link[0]]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ啕"),[],[]
def l1111l11l_l1_(url):
	if l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ啖") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ啗"),url,l11lll_l1_ (u"ࠨࠩ啘"),l11lll_l1_ (u"ࠩࠪ啙"),l11lll_l1_ (u"ࠪࠫ啚"),l11lll_l1_ (u"ࠫࠬ啛"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆ࠺ࡕ࠮࠳ࡶࡸࠬ啜"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ啝"),html,re.DOTALL)
		link = link[0]
		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ啞") in link: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ啟"),[l11lll_l1_ (u"ࠩࠪ啠")],[link]
		return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙ࠬ啡"),[],[]
	else: return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ啢"),[l11lll_l1_ (u"ࠬ࠭啣")],[url]
def l1ll1ll111l_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ啤"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ啥"),l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ啦"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ啧")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ啨"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ啩"),l11lll_l1_ (u"ࠬ࠭啪"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡔࡏࡘ࠯࠴ࡷࡹ࠭啫"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ啬"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡎࡐ࡙ࠪ啭"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ啮"),[l11lll_l1_ (u"ࠪࠫ啯")],[link]
def l1l11ll11111_l1_(url):
	headers = {l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ啰"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭啱")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ啲"),url,l11lll_l1_ (u"ࠧࠨ啳"),headers,l11lll_l1_ (u"ࠨࠩ啴"),l11lll_l1_ (u"ࠩࠪ啵"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸࠬ啶"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ啷"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐࠩ啸"),[],[]
	link = link[0]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ啹"),[l11lll_l1_ (u"ࠧࠨ啺")],[link]
def l1l1l11l11l_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ啻"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ啼")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ啽"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ啾"),l11lll_l1_ (u"ࠬ࠭啿"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡋࡅࡑࡇࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ喀"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭喁"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡌࡆࡒࡁࡄࡋࡐࡅࠬ喂"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ喃") not in link: link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ善")+link
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ喅"),l11lll_l1_ (u"ࠬ࠭喆"),l11lll_l1_ (u"࠭ࠧ喇"),link)
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ喈"),[l11lll_l1_ (u"ࠨࠩ喉")],[link]
def l1llll1111_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ喊"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ喋")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ喌"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭喍"),l11lll_l1_ (u"࠭ࠧ喎"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡂࡄࡇࡓ࠲࠷ࡳࡵࠩ喏"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ喐"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂࡃࡅࡈࡔ࠭喑"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭喒"),[l11lll_l1_ (u"ࠫࠬ喓")],[link]
def l1lll111ll1l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭喔"),l11lll_l1_ (u"࠭ࠧ喕"),l11lll_l1_ (u"ࠧࠨ喖"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ喗"),url,l11lll_l1_ (u"ࠩࠪ喘"),l11lll_l1_ (u"ࠪࠫ喙"),l11lll_l1_ (u"ࠫࠬ喚"),l11lll_l1_ (u"ࠬ࠭喛"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡗ࡚ࡋ࡛ࡎ࠮࠳ࡶࡸࠬ喜"))
	html = response.content
	l11111l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠢࡷࡣࡵࠤ࡫ࡹࡥࡳࡸࠣࡁ࠳࠰࠿ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ喝"),html,re.DOTALL|re.IGNORECASE)
	if l11111l111l1_l1_:
		l11111l111l1_l1_ = l11111l111l1_l1_[0][2:]
		#l11111l111l1_l1_ = l11111l111l1_l1_.decode(l11lll_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ喞"))
		l11111l111l1_l1_ = base64.b64decode(l11111l111l1_l1_)
		if kodi_version>18.99: l11111l111l1_l1_ = l11111l111l1_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ喟"))
		link = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ喠"),l11111l111l1_l1_,re.DOTALL)
	else: link = l11lll_l1_ (u"ࠫࠬ喡")
	if not link: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭喢"),[],[]
	link = link[0]
	if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ喣") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭喤")+link
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ喥"),[l11lll_l1_ (u"ࠩࠪ喦")],[link]
def l1111l11111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ喧"),url,l11lll_l1_ (u"ࠫࠬ喨"),l11lll_l1_ (u"ࠬ࠭喩"),l11lll_l1_ (u"࠭ࠧ喪"),l11lll_l1_ (u"ࠧࠨ喫"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪ喬"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ喭"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧ單"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ喯"),[l11lll_l1_ (u"ࠬ࠭喰")],[link]
def l11lll1l11_l1_(url):
	id = url.split(l11lll_l1_ (u"࠭࠯ࠨ喱"))[-1]
	if l11lll_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ喲") in url: url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ喳"),l11lll_l1_ (u"ࠩࠪ喴"))
	url = url.replace(l11lll_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࠩ喵"),l11lll_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬ営"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ喷"),url,l11lll_l1_ (u"࠭ࠧ喸"),l11lll_l1_ (u"ࠧࠨ喹"),l11lll_l1_ (u"ࠨࠩ喺"),l11lll_l1_ (u"ࠩࠪ喻"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ喼"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ喽"),url)
	l11l1lll11l1_l1_ = l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ喾")
	error = re.findall(l11lll_l1_ (u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭喿"),html,re.DOTALL)
	if error: l11l1lll11l1_l1_ = error[0]
	url = re.findall(l11lll_l1_ (u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嗀"),html,re.DOTALL)
	if not url and l11l1lll11l1_l1_:
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嗁"),l11lll_l1_ (u"ࠩࠪ嗂"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠬ嗃"),l11l1lll11l1_l1_)
		return l11l1lll11l1_l1_,[],[]
	link = url[0].replace(l11lll_l1_ (u"ࠫࡡࡢࠧ嗄"),l11lll_l1_ (u"ࠬ࠭嗅"))
	l11lll1l1l11_l1_,l11lll1lll11_l1_ = l11ll11l11_l1_(link)
	owner = re.findall(l11lll_l1_ (u"࠭ࠢࡰࡹࡱࡩࡷࠨ࠺ࡼࠤ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嗆"),html,re.DOTALL)
	if owner: l111l11ll1l1_l1_,l11l1ll111l1_l1_,l11l111l11ll_l1_ = owner[0]
	else: l111l11ll1l1_l1_,l11l1ll111l1_l1_,l11l111l11ll_l1_ = l11lll_l1_ (u"ࠧࠨ嗇"),l11lll_l1_ (u"ࠨࠩ嗈"),l11lll_l1_ (u"ࠩࠪ嗉")
	l11l111l11ll_l1_ = l11l111l11ll_l1_.replace(l11lll_l1_ (u"ࠪࡠ࠴࠭嗊"),l11lll_l1_ (u"ࠫ࠴࠭嗋"))
	l11l1ll111l1_l1_ = escapeUNICODE(l11l1ll111l1_l1_)
	l1lll1ll_l1_ = [l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ嗌")+l11l1ll111l1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ嗍")]+l11lll1l1l11_l1_
	l1111_l1_ = [l11l111l11ll_l1_]+l11lll1lll11_l1_
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨ嗎")+str(len(l1111_l1_)-1)+l11lll_l1_ (u"ࠨ่่ࠢๆ࠯ࠧ嗏"),l1lll1ll_l1_)
	if l1l_l1_==-1: return l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ嗐"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11lll_l1_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩ嗑")+l11l111l11ll_l1_+l11lll_l1_ (u"ࠫࠫࡺࡥࡹࡶࡀࠫ嗒")+l11l1ll111l1_l1_
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ嗓")+new_path+l11lll_l1_ (u"ࠨࠩࠣ嗔"))
		return l11lll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ嗕"),[],[]
	link =  l1111_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠨࠩ嗖"),[l11lll_l1_ (u"ࠩࠪ嗗")],[link]
def l111l11l1_l1_(link):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嗘"),link,l11lll_l1_ (u"ࠫࠬ嗙"),l11lll_l1_ (u"ࠬ࠭嗚"),l11lll_l1_ (u"࠭ࠧ嗛"),l11lll_l1_ (u"ࠧࠨ嗜"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇࡕࡋࡓࡃ࠰࠵ࡸࡺࠧ嗝"))
	html = response.content
	if l11lll_l1_ (u"ࠩ࠱࡮ࡸࡵ࡮ࠨ嗞") in link: url = re.findall(l11lll_l1_ (u"ࠪࠦࡸࡸࡣࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ嗟"),html,re.DOTALL)
	else: url = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗠"),html,re.DOTALL)
	if not url: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡃࡑࡎࡖࡆ࠭嗡"),[],[]
	url = url[0]
	if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ嗢") not in url: url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭嗣")+url
	return l11lll_l1_ (u"ࠨࠩ嗤"),[l11lll_l1_ (u"ࠩࠪ嗥")],[url]
def l11l11lll1ll_l1_(url):
	# http://l111l111l1ll_l1_.l1ll1lll1lll_l1_/l11l1ll1l11l_l1_.html?l11l1l1l1l11_l1_=l111ll11ll1l_l1_
	# http://l111l111l1ll_l1_.l1ll1lll1lll_l1_/l11l11lll1l1_l1_?op=l111111l1111_l1_&id=l11l1ll1l11l_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ嗦") : l11lll_l1_ (u"ࠫࠬ嗧") }
	if l11lll_l1_ (u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨ嗨") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ嗩"),headers,l11lll_l1_ (u"ࠧࠨ嗪"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠱ࡴࡶࠪ嗫"))
		#xbmc.log(html)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嗬"),l11lll_l1_ (u"ࠪࠫ嗭"),url,html)
		items = re.findall(l11lll_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嗮"),html,re.DOTALL)
		if items: return l11lll_l1_ (u"ࠬ࠭嗯"),[l11lll_l1_ (u"࠭ࠧ嗰")],[items[0]]
		else:
			message = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嗱"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嗲"),l11lll_l1_ (u"ࠩࠪ嗳"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไศื็๎ࠬ嗴"),message[0])
				return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࠬ嗵")+message[0],[],[]
	else:
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭嗶"),l11lll_l1_ (u"࠭ࠧ嗷"),link,l11lll_l1_ (u"ࠧࠨ嗸"))
		#url,l1ll111lll1_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ嗹"))
		#l1ll111lll1_l1_ = l1ll111lll1_l1_.lower()
		l1ll111lll1_l1_ = l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬ嗺")
		# l11ll1l1l_l1_ links
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ嗻"),headers,l11lll_l1_ (u"ࠫࠬ嗼"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧ嗽"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ嗾"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ嗿"),[],[]
		l1lllllll1_l1_ = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		if l11lll_l1_ (u"ࠨ࠰ࡵࡥࡷ࠭嘀") in block or l11lll_l1_ (u"ࠩ࠱ࡾ࡮ࡶࠧ嘁") in block: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨ嘂"),[],[]
		items = re.findall(l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嘃"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l1ll_l1_(payload)
		html = OPENURL_CACHED(l1lll1111_l1_,l1lllllll1_l1_,data,headers,l11lll_l1_ (u"ࠬ࠭嘄"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠸ࡸࡤࠨ嘅"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥ࡙ࠢ࡭ࡩ࡫࡯࠯ࠬࡂ࡫ࡪࡺ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡯࡭ࡢࡩࡨ࠾ࠬ嘆"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ嘇"),[],[]
		download = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		items = re.findall(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤ࠱࠮ࡄࠨࡼࠪࠩ嘈"),block,re.DOTALL)
		l11l11l111l1_l1_,l1lll1ll_l1_,l11l1l11l111_l1_,l1111_l1_,l1111llll111_l1_ = [],[],[],[],[]
		for link,title in items:
			if l11lll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ嘉") in link:
				l11l11l111l1_l1_,l11l1l11l111_l1_ = l11ll11l11_l1_(link)
				l1111_l1_ = l1111_l1_ + l11l1l11l111_l1_
				if l11l11l111l1_l1_[0]==l11lll_l1_ (u"ࠫ࠲࠷ࠧ嘊"): l1lll1ll_l1_.append(l11lll_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ嘋")+l11lll_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ嘌")+l1ll111lll1_l1_)
				else:
					for title in l11l11l111l1_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ嘍")+l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ嘎")+l1ll111lll1_l1_+l11lll_l1_ (u"ࠩࠣࠫ嘏")+title)
			else:
				title = title.replace(l11lll_l1_ (u"ࠪ࠰ࡱࡧࡢࡦ࡮࠽ࠦࠬ嘐"),l11lll_l1_ (u"ࠫࠬ嘑"))
				title = title.strip(l11lll_l1_ (u"ࠬࠨࠧ嘒"))
				#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嘓"),l11lll_l1_ (u"ࠧࠨ嘔"),title,str(l1111llll111_l1_))
				title = l11lll_l1_ (u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧ嘕")+l11lll_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ嘖")+l1ll111lll1_l1_+l11lll_l1_ (u"ࠪࠤࠬ嘗")+title
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		# download links
		link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭嘘") + download
		html = OPENURL_CACHED(l1lll1111_l1_,link,l11lll_l1_ (u"ࠬ࠭嘙"),headers,l11lll_l1_ (u"࠭ࠧ嘚"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠻ࡴࡩࠩ嘛"))
		items = re.findall(l11lll_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰ࠧ嘜"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11lll_l1_ (u"ࠩࠣื๏ืแาࠢอั๊๐ไࠡะสูࠥ࠭嘝")+l11lll_l1_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ嘞")+l1ll111lll1_l1_+l11lll_l1_ (u"ࠫࠥ࠭嘟")+resolution.split(l11lll_l1_ (u"ࠬࡾࠧ嘠"))[1]
			link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࡦ࡯ࡃࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠦࡪࡦࡀࠫ嘡")+id+l11lll_l1_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ嘢")+mode+l11lll_l1_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ嘣")+hash
			l1111llll111_l1_.append(resolution)
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		l1111llll111_l1_ = set(l1111llll111_l1_)
		l111l111llll_l1_,l11l111l1lll_l1_ = [],[]
		for title in l1lll1ll_l1_:
			#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ嘤"),l11lll_l1_ (u"ࠪࠫ嘥"),title,l11lll_l1_ (u"ࠫࠬ嘦"))
			res = re.findall(l11lll_l1_ (u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧ嘧"),title+l11lll_l1_ (u"࠭ࠦࠧࠩ嘨"),re.DOTALL)
			for resolution in l1111llll111_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11lll_l1_ (u"ࠧࡹࠩ嘩"))[1])
			l111l111llll_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1111_l1_)):
			items = re.findall(l11lll_l1_ (u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤ嘪"),l11lll_l1_ (u"ࠩࠩࠪࠬ嘫")+l111l111llll_l1_[i]+l11lll_l1_ (u"ࠪࠪࠫ࠭嘬"),re.DOTALL)
			l11l111l1lll_l1_.append( [l111l111llll_l1_[i],l1111_l1_[i],items[0][0],items[0][1]] )
		l11l111l1lll_l1_ = sorted(l11l111l1lll_l1_, key=lambda x: x[3], reverse=True)
		l11l111l1lll_l1_ = sorted(l11l111l1lll_l1_, key=lambda x: x[2], reverse=False)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for i in range(len(l11l111l1lll_l1_)):
			l1lll1ll_l1_.append(l11l111l1lll_l1_[i][0])
			l1111_l1_.append(l11l111l1lll_l1_[i][1])
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ嘭"),[],[]
	return l11lll_l1_ (u"ࠬ࠭嘮"),l1lll1ll_l1_,l1111_l1_
def l11l111lllll_l1_(url):
	# http://l1111111llll_l1_.com/717254
	parts = url.split(l11lll_l1_ (u"࠭࠿ࠨ嘯"))
	l11l11l_l1_ = parts[0]
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ嘰") : l11lll_l1_ (u"ࠨࠩ嘱") }
	html = OPENURL_CACHED(l1lll1111_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ嘲"),headers,l11lll_l1_ (u"ࠪࠫ嘳"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫ嘴"))
	items = re.findall(l11lll_l1_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭嘵"),html,re.DOTALL)
	url = items[0]
	#l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lllll1_l1_(url)
	#return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嘶"),[l11lll_l1_ (u"ࠧࠨ嘷")],[url]
def l111l1l1ll1l_l1_(url):
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嘸") : l11lll_l1_ (u"ࠩࠪ嘹") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠪࠫ嘺"),headers,l11lll_l1_ (u"ࠫࠬ嘻"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ嘼"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘽"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠧࠨ嘾"),[l11lll_l1_ (u"ࠨࠩ嘿")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇ࡛࡚࡛ࡘࡕࡐࠬ噀"),[],[]
def l11l11l11l11_l1_(url):
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ噁") : l11lll_l1_ (u"ࠫࠬ噂") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠬ࠭噃"),headers,l11lll_l1_ (u"࠭ࠧ噄"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭噅"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫ噆"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠩࠪ噇"),[l11lll_l1_ (u"ࠪࠫ噈")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬ噉"),[],[]
def l1l1llllll1_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭噊"),l11lll_l1_ (u"࠭ࠧ噋"),l11lll_l1_ (u"ࠧࠨ噌"),url)
	# l11ll1l1l_l1_    https://show.l111l11llll1_l1_.com/l111l11l1l11_l1_-l111l11l1111_l1_/l111l11l1111_l1_-l111llll111l_l1_.l1ll1lll1l_l1_?action=l1111llll11l_l1_&post=32513&l1l1lllllll_l1_=1&type=l1lll111ll1_l1_
	# download https://show.l111l11llll1_l1_.com/links/l11111lll1ll_l1_
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠨࠩ噍")
	# l11ll1l1l_l1_
	if l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴࠭噎") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ噏"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ噐")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ噑"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ噒"),l11lll_l1_ (u"ࠧࠨ噓"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧࠫ噔"))
		l11lll1l_l1_ = response.content
		if l11lll1l_l1_.startswith(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ噕")): l11l11l_l1_ = l11lll1l_l1_
		else:
			l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫ噖"),l11lll1l_l1_,re.DOTALL)
			if l11l1l1_l1_:
				l11l11l_l1_ = l11l1l1_l1_[0]
				l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫࠧࠫ噗"),l11l11l_l1_,re.DOTALL)
				if l11l1l1_l1_:
					l11l11l_l1_ = l111l_l1_(l11l1l1_l1_[0])
					return l11lll_l1_ (u"ࠬ࠭噘"),[l11lll_l1_ (u"࠭ࠧ噙")],[l11l11l_l1_]
	# download
	elif l11lll_l1_ (u"ࠧ࠰࡮࡬ࡲࡰࡹ࠯ࠨ噚") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ噛"),url,l11lll_l1_ (u"ࠩࠪ噜"),l11lll_l1_ (u"ࠪࠫ噝"),True,l11lll_l1_ (u"ࠫࠬ噞"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠶ࡹࡴࠨ噟"))
		l11lll1l_l1_ = response.content
		if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ噠") in list(response.headers.keys()): l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ噡")]
		else: l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ噢"),l11lll1l_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ噣"),l11lll_l1_ (u"ࠪࠫ噤"),l11l11l_l1_,str(2222))
	if l11lll_l1_ (u"ࠫ࠴ࡼ࠯ࠨ噥") in l11l11l_l1_ or l11lll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ噦") in l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭࠯ࡧ࠱ࠪ噧"),l11lll_l1_ (u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭器"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡹ࠳ࠬ噩"),l11lll_l1_ (u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ噪"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ噫"),l11lll_l1_ (u"ࠫࠬ噬"),l11l11l_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ噭"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ噮"),l11lll_l1_ (u"ࠧࠨ噯"),l11lll_l1_ (u"ࠨࠩ噰"),l11lll_l1_ (u"ࠩࠪ噱"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭噲"))
		l11lll1l_l1_ = response.content
		items = re.findall(l11lll_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ噳"),l11lll1l_l1_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ噴"),l11lll_l1_ (u"࠭ࠧ噵"))
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ噶"),l11lll1l_l1_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l11lll_l1_ (u"ࠨ࡞࡟ࠫ噷"),l11lll_l1_ (u"ࠩࠪ噸"))
				l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࠫ噹"))
				l1111_l1_.append(link)
	else: return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ噺"),[l11lll_l1_ (u"ࠬ࠭噻")],[l11l11l_l1_]
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ噼"),l11lll_l1_ (u"ࠧࠨ噽"),str(l11llll11_l1_),l11l11l_l1_)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭噾"),[],[]
	return l11lll_l1_ (u"ࠩࠪ噿"),l1lll1ll_l1_,l1111_l1_
def l1l1l1lll11l_l1_(url):
	# l11ll1l1l_l1_ l1111lll_l1_  https://l111ll1111l1_l1_.l11l1l111ll1_l1_.l1ll1lll111_l1_/l11ll1111ll_l1_/l1lllllllll1l_l1_.l1ll1lll1l_l1_?s=07&id=l11l1lll1l1l_l1_,&l1llll_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1111lll111l_l1_&l11l1111ll1l_l1_=l111111lllll_l1_&l111l1l11lll_l1_=l1111111l111_l1_
	# l11ll1l1l_l1_ l1llll1l1_l1_ https://l11l1l11l1ll_l1_.l11l1l111ll1_l1_.l1ll1lll111_l1_/l11ll1111ll_l1_/l11111l1ll1l_l1_.l1ll1lll1l_l1_?l11l11l1ll11_l1_=l111l111ll11_l1_&l111ll1ll111_l1_=8a26a6cc61a884e89076504130c71626&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111lll111l_l1_&l11l1111ll1l_l1_=l111111lllll_l1_&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1111lll111l_l1_&l11l1111ll1l_l1_=l111111lllll_l1_&l111l1l11lll_l1_=l111l111ll1l_l1_
	# download https://www.l11l11lll11l_l1_.l111l11l1l1l_l1_/l11l111l1l11_l1_?server=l11111l1l1ll_l1_&id=l111lll1l1l1_l1_,,
	# l1l11llll_l1_ https://l11l11lll11l_l1_.l1lll1111l_l1_/l1l11llll_l1_/l11l11111ll1_l1_
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嚀"),url,l11lll_l1_ (u"ࠫࠬ嚁"),l11lll_l1_ (u"ࠬ࠭嚂"),l11lll_l1_ (u"࠭ࠧ嚃"),l11lll_l1_ (u"ࠧࠨ嚄"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨ嚅"))
	html = response.content
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠩࠪ嚆")
	if l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭嚇") in url or l11lll_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ嚈") in url:
		if l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ嚉") in url:
			l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚊"),html,re.DOTALL)
			l11l11l_l1_ = l11l11l_l1_[0]
		else: l11l11l_l1_ = url
		if l11lll_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ嚋") not in l11l11l_l1_: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嚌"),[l11lll_l1_ (u"ࠩࠪ嚍")],[l11l11l_l1_]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嚎"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ嚏"),l11lll_l1_ (u"ࠬ࠭嚐"),l11lll_l1_ (u"࠭ࠧ嚑"),l11lll_l1_ (u"ࠧࠨ嚒"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ嚓"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ嚔"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚕"),block,re.DOTALL)
		if items:
			for link,l1ll111llll1_l1_ in items:
				l1lll1ll_l1_.append(l1ll111llll1_l1_)
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭嚖") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ嚗"),html,re.DOTALL)
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ嚘"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ嚙"),l11lll_l1_ (u"ࠨࠩ嚚"),l11lll_l1_ (u"ࠩࠪ嚛"),l11lll_l1_ (u"ࠪࠫ嚜"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ嚝"))
		html = response.content
		l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚞"),html,re.DOTALL)
		l11l1l1_l1_ = l11l1l1_l1_[0]
		l1lll1ll_l1_.append(l11lll_l1_ (u"࠭ࠧ嚟"))
		l1111_l1_.append(l11l1l1_l1_)
	elif l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧ嚠") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚡"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嚢"),[l11lll_l1_ (u"ࠪࠫ嚣")],[l11l11l_l1_]
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭嚤"),[],[]
	return l11lll_l1_ (u"ࠬ࠭嚥"),l1lll1ll_l1_,l1111_l1_
def l1lll1l11l_l1_(url):
	l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ嚦")][0]
	headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ嚧"):l1l1ll11_l1_}
	if l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࠬ嚨") in url:
		l1l1ll1ll_l1_ = headers.copy()
		l1l1ll1ll_l1_[l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ嚩")] = l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ嚪")
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ嚫"),url,l11lll_l1_ (u"ࠬ࠭嚬"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ嚭"),l11lll_l1_ (u"ࠧࠨ嚮"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳࠱ࡴࡶࠪ嚯"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠩ࠭嚰"),html,re.DOTALL)
		if link: url = link[0]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嚱"),url,l11lll_l1_ (u"ࠫࠬ嚲"),headers,l11lll_l1_ (u"ࠬ࠭嚳"),l11lll_l1_ (u"࠭ࠧ嚴"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡆ࠲࠸࡮ࡥࠩ嚵"))
	html = response.content
	server = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ嚶"))
	link = re.findall(l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嚷"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠥࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ嚸"),html,re.DOTALL)
	if link:
		url = link[0]+l11lll_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ嚹")+l1l1ll11_l1_
		return l11lll_l1_ (u"ࠬ࠭嚺"),[l11lll_l1_ (u"࠭ࠧ嚻")],[url]
	link = re.findall(l11lll_l1_ (u"ࠢࡧ࡫࡯ࡩ࠿࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ嚼"),html,re.DOTALL)
	if link: url = server+link[0]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嚽"),[l11lll_l1_ (u"ࠩࠪ嚾")],[url]
	#return l11lll_l1_ (u"ࠪࠫ嚿"),l1lllll11l1_l1_,l1lllll1_l1_
	#return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ囀"),[],[]
	#return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ囁"),[l11lll_l1_ (u"࠭ࠧ囂")],[url]
	#return l11lll_l1_ (u"ࠧࠨ囃"),[l11lll_l1_ (u"ࠨࠩ囄")],[url]
def l1lllll111l_l1_(url):
	l1lllll11l1_l1_,l1lllll1_l1_ = [],[]
	if l11lll_l1_ (u"ࠩ࠲࠵࠴࠭囅") in url:
		link = url.replace(l11lll_l1_ (u"ࠪ࠳࠶࠵ࠧ囆"),l11lll_l1_ (u"ࠫ࠴࠺࠯ࠨ囇"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ囈"),link,l11lll_l1_ (u"࠭ࠧ囉"),l11lll_l1_ (u"ࠧࠨ囊"),False,l11lll_l1_ (u"ࠨࠩ囋"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠲ࡵࡷࠫ囌"))
		l11lll1l_l1_ = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡩ࡫࡯࠿ࠩ囍"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ囎"),block,re.DOTALL)
			for link,l11l111l_l1_ in items:
				if link not in l1lllll1_l1_:
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ囏"))
					l1lllll11l1_l1_.append(server+l11lll_l1_ (u"࠭ࠠࠡࠩ囐")+l11l111l_l1_)
			return l11lll_l1_ (u"ࠧࠨ囑"),l1lllll11l1_l1_,l1lllll1_l1_
	elif l11lll_l1_ (u"ࠨ࠱ࡧ࠳ࠬ囒") in url:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭囓"),url,l11lll_l1_ (u"ࠪࠫ囔"),l11lll_l1_ (u"ࠫࠬ囕"),l11lll_l1_ (u"ࠬ࠭囖"),l11lll_l1_ (u"࠭ࠧ囗"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠸࡮ࡥࠩ囘"))
		l11lll1l_l1_ = response.content
		link = re.findall(l11lll_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ囙"),l11lll1l_l1_,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"ࠩ࠲࠵࠴࠭囚"),l11lll_l1_ (u"ࠪ࠳࠹࠵ࠧ四"))
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ囜"),link,l11lll_l1_ (u"ࠬ࠭囝"),l11lll_l1_ (u"࠭ࠧ回"),False,l11lll_l1_ (u"ࠧࠨ囟"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠳ࡳࡦࠪ因"))
			l11lll1l_l1_ = response.content
			link = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ囡"),l11lll1l_l1_,re.DOTALL)
			if link: return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭团"),[l11lll_l1_ (u"ࠫࠬ団")],[link[0]]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ囤"),[],[]
def l1lll1l111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ囥"),l11lll_l1_ (u"ࠧࠨ囦"),l11lll_l1_ (u"ࠨࠩ囧"),url)
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭囨"),url,l11lll_l1_ (u"ࠪࠫ囩"),l11lll_l1_ (u"ࠫࠬ囪"),l11lll_l1_ (u"ࠬ࠭囫"),l11lll_l1_ (u"࠭ࠧ囬"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠷ࡳࡵࠩ园"))
	html = response.content
	data = re.findall(l11lll_l1_ (u"ࠨࠤࡤࡧࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ囮"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l11lll_l1_ (u"ࠩࡲࡴࡂ࠭囯")+op+l11lll_l1_ (u"ࠪࠪ࡮ࡪ࠽ࠨ困")+id+l11lll_l1_ (u"ࠫࠫ࡬࡮ࡢ࡯ࡨࡁࠬ囱")+fname
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ囲"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ図")}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ围"),url,data,headers,l11lll_l1_ (u"ࠨࠩ囵"),l11lll_l1_ (u"ࠩࠪ囶"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠴ࡱࡨࠬ囷"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠫࠧࡸࡥࡧࡧࡵࡩࡷࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ囸"),html,re.DOTALL)
		if link: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ囹"),[l11lll_l1_ (u"࠭ࠧ固")],[link[0]]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ囻"),[],[]
def l11111l1l1_l1_(url):
	# https://l1lllll1l11_l1_.l1lllll1111_l1_/l11ll1lll1l_l1_?call=l11l1111l11l_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1l1l1l11_l1_=l111ll11l11l_l1_
	# https://l1lllll1l11_l1_.l1lllll1111_l1_/l11ll1lll1l_l1_?call=l11l1111l11l_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1l1l1l11_l1_=l111l11l11ll_l1_
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ囼"),1)[0].strip(l11lll_l1_ (u"ࠩࡂࠫ国")).strip(l11lll_l1_ (u"ࠪ࠳ࠬ图")).strip(l11lll_l1_ (u"ࠫࠫ࠭囿"))
	l1lll1ll_l1_,l1111_l1_,items,l11l1l1_l1_ = [],[],[],l11lll_l1_ (u"ࠬ࠭圀")
	headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ圁"):l11lll_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠧ圂") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ圃"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ圄"),headers,True,l11lll_l1_ (u"ࠪࠫ圅"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠳ࡶࡸࠬ圆"))
	if l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ圇") in list(response.headers.keys()): l11l1l1_l1_ = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ圈")]
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ圉"),l11l1l1_l1_,l11lll_l1_ (u"ࠨࠩ圊"),headers,False,l11lll_l1_ (u"ࠩࠪ國"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠳ࡰࡧࠫ圌"))
	#if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭圍") in response.headers: l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ圎")]
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ圏"),l11lll_l1_ (u"ࠧࠨ圐"),l11l1l1_l1_,response.content)
	if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭圑") in l11l1l1_l1_:
		# https://l1111l1111_l1_.top/f/l111llll1ll1_l1_/?l111l1llll_l1_=l11ll111111l_l1_
		# https://l1111l1111_l1_.top/v/l111llll1ll1_l1_/?l111l1llll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ園") in url: l11l1l1_l1_ = l11l1l1_l1_.replace(l11lll_l1_ (u"ࠪ࠳࡫࠵ࠧ圓"),l11lll_l1_ (u"ࠫ࠴ࡼ࠯ࠨ圔"))
		l11l1l1ll11l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧ圕"))[1]
		headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ圖"):headers[l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ圗")] , l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ團"):l11lll_l1_ (u"ࠩࡓࡌࡕ࡙ࡉࡅ࠿ࠪ圙")+l11l1l1ll11l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ圚"),l11l1l1_l1_,l11lll_l1_ (u"ࠫࠬ圛"),headers,False,l11lll_l1_ (u"ࠬ࠭圜"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ圝"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1lll1111_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠧࠨ圞"),headers,l11lll_l1_ (u"ࠨࠩ土"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠳ࡳࡦࠪ圠"))
		if l11lll_l1_ (u"ࠪ࠳࡫࠵ࠧ圡") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圢"),html,re.DOTALL)
		elif l11lll_l1_ (u"ࠬ࠵ࡶ࠰ࠩ圣") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圤"),html,re.DOTALL)
		if items: return [],[l11lll_l1_ (u"ࠧࠨ圥")],[ items[0] ]
		elif l11lll_l1_ (u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧ圦") in html:
			return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬ圧"),[],[]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭在"),[],[]
	#xbmc.log(html)
def l11111111l1_l1_(link):
	# https://l11ll1111l11_l1_.net/?l11llll1_l1_=147043&l1l11111_l1_=5
	parts = re.findall(l11lll_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭圩"),link+l11lll_l1_ (u"ࠬࠬࠦࠨ圪"),re.DOTALL|re.IGNORECASE)
	l11llll1_l1_,l1l11111_l1_ = parts[0]
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ圫")+l11llll1_l1_+l11lll_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ圬")+l1l11111_l1_
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ圭"):l11lll_l1_ (u"ࠩࠪ圮") , l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭圯"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ地") }
	l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭圱"),headers,l11lll_l1_ (u"࠭ࠧ圲"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭圳"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ圴"),l11lll_l1_ (u"ࠩࠪ圵"),url,l11l11l_l1_)
	#l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lllll1_l1_(l11l11l_l1_)
	#return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭圶"),[l11lll_l1_ (u"ࠫࠬ圷")],[l11l11l_l1_]
def l1ll11111111_l1_(url):
	# https://l1111111ll11_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111llll1l1l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l111lll1l_l1_=1608181746
	server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ圸"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ圹"):server,l11lll_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ场"):l11lll_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨ圻")}
	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭圼"),url,l11lll_l1_ (u"ࠪࠫ圽"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ圾"),l11lll_l1_ (u"ࠬ࠭圿"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭址"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨ坁"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠨࠩ坂")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坃"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ坄"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠫࠬ坅"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ坆"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨ均"),[],[]
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ坈"),[l11lll_l1_ (u"ࠨࠩ坉")],[l11l11l_l1_]
def l1l1l111lll1_l1_(url):
	# https://l11ll1111l1l_l1_.l1111l111111_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l111llll1l1l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l111lll1l_l1_=1608181746
	# https://l11ll1111l1l_l1_.l1lllll1111_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l111llll1l1l_l1_=l11l1ll1ll11_l1_&l11l111lll1l_l1_=1684182121
	server = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭坊"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ坋"):server,l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭坌"):l11lll_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ坍")}
	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ坎"),url,l11lll_l1_ (u"ࠧࠨ坏"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ坐"),l11lll_l1_ (u"ࠩࠪ坑"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ坒"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ坓"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠬ࠭坔")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ坕"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ坖"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࠩ块"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	if not l11l11l_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ坘"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡅࡄࡋࡐࡅࠬ坙"),[],[]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ坚"),[l11lll_l1_ (u"ࠬ࠭坛")],[l11l11l_l1_]
def l1l1l111_l1_(link):
	# https://w.l111l1111l11_l1_.l1llll111l1_l1_/l111l11l1l11_l1_-content/l11l1lll1l11_l1_/l1111lllllll_l1_/l11l11llll1l_l1_/l1111llllll1_l1_/l111ll11111l_l1_/l111l11l1lll_l1_.l1ll1lll1l_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ坜"),l11lll_l1_ (u"ࠧࠨ坝"),link,html)
	parts = re.findall(l11lll_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ坞"),link+l11lll_l1_ (u"ࠩࠩࠪࠬ坟"),re.DOTALL)
	url,l11llll1_l1_,l1l11111_l1_ = parts[0]
	data = {l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫ坠"):l11llll1_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ坡"):l1l11111_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ坢"),url,data,l11lll_l1_ (u"࠭ࠧ坣"),l11lll_l1_ (u"ࠧࠨ坤"),l11lll_l1_ (u"ࠨࠩ坥"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐࡇࡆࡓ࠭࠲ࡵࡷࠫ坦"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坧"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ坨"),[l11lll_l1_ (u"ࠬ࠭坩")],[l11l11l_l1_]
def l1ll1l1lll_l1_(url):
	# https://l11l111ll11l_l1_.l1lll11111_l1_-l11l11l11l1l_l1_.com/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1l1l1_l1_=l111l1l1l11l_l1_
	# https://l.l111l11ll111_l1_.l111l11l1l1l_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1l1l1_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ坪"),url,l11lll_l1_ (u"ࠧࠨ坫"),l11lll_l1_ (u"ࠨࠩ坬"),l11lll_l1_ (u"ࠩࠪ坭"),l11lll_l1_ (u"ࠪࠫ坮"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ坯"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭坰"),html,re.DOTALL)
	if link:
		link = link[0]
		if link: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ坱"),[l11lll_l1_ (u"ࠧࠨ坲")],[link]
	return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭坳"),[],[]
def l1lll111ll_l1_(url):
	# https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/l111l11l1l11_l1_-content/l11l1lll1l11_l1_/old/l1llll1_l1_/server.l1ll1lll1l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭坴"),url,l11lll_l1_ (u"ࠪࠫ坵"),l11lll_l1_ (u"ࠫࠬ坶"),l11lll_l1_ (u"ࠬ࠭坷"),l11lll_l1_ (u"࠭ࠧ坸"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩ坹"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ坺"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ坻"),[l11lll_l1_ (u"ࠪࠫ坼")],[link]
def l1ll1l1l1l_l1_(url):
	# https://l11lllll111_l1_.l1l111l1lll1_l1_.cc/l111l11l1l11_l1_-content/l11l1lll1l11_l1_/l1111l1l1l11_l1_%20Now%20New/l11111lll11l_l1_.l1ll1lll1l_l1_?action=l11l11l11111_l1_&index=00&id=58504
	# https://l111llll1l11_l1_.l1l111l1lll1_l1_.net/l11111lll1l1_l1_/2021/04/05/_111l1l1l1ll_l1_-l11l1lllllll_l1_.l1lllllllllll_l1_ 200.l11111ll111l_l1_.2020.l1111l111l11_l1_/[l1111l1l1l11_l1_-l11l1lllllll_l1_.l1111ll111ll_l1_] 200.l11111ll111l_l1_.2020.l1111l111l11_l1_-360p.l1111lll_l1_
	l1llllll1l_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ坽"))
	if l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ坾") in url:
		headers = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ坿"):l1llllll1l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ垀"),url,l11lll_l1_ (u"ࠨࠩ垁"),headers,l11lll_l1_ (u"ࠩࠪ垂"),l11lll_l1_ (u"ࠪࠫ垃"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ垄"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ垅"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			if l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ垆") in l11l11l_l1_:
				l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ垇"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ垈"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭垉"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ垊"),headers,l11lll_l1_ (u"ࠫࠬ型"),l11lll_l1_ (u"ࠬ࠭垌"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ垍"))
				l11lll1l_l1_ = response.content
				items = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垎"),l11lll1l_l1_,re.DOTALL)
				l1lll1ll_l1_,l1111_l1_ = [],[]
				l1llllll11_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ垏"))
				for link,l11l111l_l1_ in reversed(items):
					link = l1llllll11_l1_+link+l11lll_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ垐")+l1llllll11_l1_
					l1lll1ll_l1_.append(l11l111l_l1_)
					l1111_l1_.append(link)
				return l11lll_l1_ (u"ࠪࠫ垑"),l1lll1ll_l1_,l1111_l1_
			else: return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ垒"),[l11lll_l1_ (u"ࠬ࠭垓")],[l11l11l_l1_]
	l11l11l_l1_ = url+l11lll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ垔")+l1llllll1l_l1_
	return l11lll_l1_ (u"ࠧࠨ垕"),[l11lll_l1_ (u"ࠨࠩ垖")],[l11l11l_l1_]
def l111ll1l1l11_l1_(link):
	# https://l1l111l1lll1_l1_.l1llll111l1_l1_/l111l11l1l11_l1_-content/l11l1lll1l11_l1_/l11l111llll1_l1_/l11111llll11_l1_/server.l1ll1lll1l_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	# https://l11l1l11ll1l_l1_.l1l111l1lll1_l1_.net/l11111lll1l1_l1_/2020/08/14/_111l1l1l1ll_l1_-l11l1lllllll_l1_.l1lllllllllll_l1_ l1111l1l111l_l1_.l111ll11ll11_l1_.2020.l111l1ll1l11_l1_-l111ll1l111l_l1_/[l1111l1l1l11_l1_-l11l1lllllll_l1_.l1111ll111ll_l1_] l1111l1l111l_l1_.l111ll11ll11_l1_.2020.l111l1ll1l11_l1_-l111ll1l111l_l1_-1080p.l1111lll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ垗"),l11lll_l1_ (u"ࠪࠫ垘"),url,html)
	l1llllll1l_l1_ = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ垙"))
	if l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ垚") in link:
		parts = re.findall(l11lll_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ垛"),link+l11lll_l1_ (u"ࠧࠧࠨࠪ垜"),re.DOTALL)
		url,l11llll1_l1_,l1l11111_l1_ = parts[0]
		data = {l11lll_l1_ (u"ࠨ࡫ࡧࠫ垝"):l11llll1_l1_,l11lll_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ垞"):l1l11111_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ垟"),url,data,l11lll_l1_ (u"ࠫࠬ垠"),l11lll_l1_ (u"ࠬ࠭垡"),l11lll_l1_ (u"࠭ࠧ垢"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ垣"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭垤"),html,re.DOTALL)[0]
		if l11lll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ垥") in l11l11l_l1_:
			headers = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ垦"):l1llllll1l_l1_,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ垧"):l11lll_l1_ (u"ࠬ࠭垨")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ垩"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ垪"),headers,l11lll_l1_ (u"ࠨࠩ垫"),l11lll_l1_ (u"ࠩࠪ垬"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ垭"))
			l11lll1l_l1_ = response.content
			items = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ垮"),l11lll1l_l1_,re.DOTALL)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			l1llllll11_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ垯"))
			for link,l11l111l_l1_ in reversed(items):
				link = l1llllll11_l1_+link+l11lll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ垰")+l1llllll11_l1_
				l1lll1ll_l1_.append(l11l111l_l1_)
				l1111_l1_.append(link)
			return l11lll_l1_ (u"ࠧࠨ垱"),l1lll1ll_l1_,l1111_l1_
		else: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ垲"),[l11lll_l1_ (u"ࠩࠪ垳")],[l11l11l_l1_]
	else:
		link = link+l11lll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭垴")+l1llllll1l_l1_
		return l11lll_l1_ (u"ࠫࠬ垵"),[l11lll_l1_ (u"ࠬ࠭垶")],[link]
def l11l11l1l_l1_(link):
	# http://l11l1ll1l111_l1_.tv/?l11llll1_l1_=159485&l1l11111_l1_=0
	if l11lll_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭垷") in link:
		parts = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ垸"),link+l11lll_l1_ (u"ࠨࠨࠩࠫ垹"),re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		host = SERVER(link,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭垺"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ垻"),l11lll_l1_ (u"ࠫࠬ垼"),link,host)
		url = host+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ垽")+l11llll1_l1_+l11lll_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ垾")+l1l11111_l1_
		headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ垿"):l11lll_l1_ (u"ࠨࠩ埀") , l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ埁"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ埂") }
		l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ埃"),headers,l11lll_l1_ (u"ࠬ࠭埄"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠶ࡹࡴࠨ埅"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ埆"),l11lll_l1_ (u"ࠨࠩ埇")).replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ埈"),l11lll_l1_ (u"ࠪࠫ埉"))
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ埊"),l11lll_l1_ (u"ࠬ࠭埋"),url,l11l11l_l1_)
		#l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lllll1_l1_(l11l11l_l1_)
		#return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ埌"),[l11lll_l1_ (u"ࠧࠨ埍")],[l11l11l_l1_]
	elif l11lll_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ城") in link:
		counts = 0
		while l11lll_l1_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭埏") in link and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ埐"),link,l11lll_l1_ (u"ࠫࠬ埑"),l11lll_l1_ (u"ࠬ࠭埒"),l11lll_l1_ (u"࠭ࠧ埓"),l11lll_l1_ (u"ࠧࠨ埔"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪ埕"))
			if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ埖") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ埗")]
			counts += 1
		return l11lll_l1_ (u"ࠫࠬ埘"),[l11lll_l1_ (u"ࠬ࠭埙")],[link]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ埚"),[],[]
def l11ll1111_l1_(url):
	# https://l111l1l11111_l1_.l1111l1lllll_l1_.me/l/l11l1ll1llll_l1_=
	# https://l11l1111l1ll_l1_.l1111l111ll1_l1_.net/l1l11llll_l1_-l1l11llll_l1_-l1111l11ll1l_l1_.html
	# https://m.l1111l111ll1_l1_.net/l1111l11ll1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ埛"),l11lll_l1_ (u"ࠨࠩ埜"),l11lll_l1_ (u"ࠩࠪ埝"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ埞"))
	if l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡶࡦࡺࡥࠨ域") in url and l11lll_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ埠") not in url: url = server+l11lll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ埡")+url.split(l11lll_l1_ (u"ࠧ࠰ࠩ埢"))[-1]+l11lll_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ埣")
	headers = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ埤"):server,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ埥"):l1l11l11l_l1_()}
	if l11lll_l1_ (u"ࠫ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ埦") in url:
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ埧"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ埨")}
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ埩"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠨࠩ埪"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠲ࡵࡷࠫ埫"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠪࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埬"),html,re.DOTALL|re.IGNORECASE)
		if link: return l11lll_l1_ (u"ࠫࠬ埭"),[l11lll_l1_ (u"ࠬ࠭埮")],[link[0]]
	elif l11lll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ埯") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ埰"),headers,l11lll_l1_ (u"ࠨࠩ埱"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫ埲"))
		link = re.findall(l11lll_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ埳"),html,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ埴"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ埵"))
			return l11lll_l1_ (u"࠭ࠧ埶"),[l11lll_l1_ (u"ࠧࠨ執")],[link]
	else:
		l111l1l111ll_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ埸"),url,l11lll_l1_ (u"ࠩࠪ培"),headers,l11lll_l1_ (u"ࠪࠫ基"),l11lll_l1_ (u"ࠫࠬ埻"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠷ࡷࡪࠧ埼"))
		html = l111l1l111ll_l1_.content
		link = re.findall(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ埽"),html,re.DOTALL)
		if link:
			link = l111l_l1_(link[0])+l11lll_l1_ (u"ࠧࠧࡦࡀ࠵ࠬ埾")
			l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ埿"),link,l11lll_l1_ (u"ࠩࠪ堀"),headers,l11lll_l1_ (u"ࠪࠫ堁"),l11lll_l1_ (u"ࠫࠬ堂"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠸ࡹ࡮ࠧ堃"))
			html = l1ll111ll_l1_.content
			link = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡦࡹࡴࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ堄"),html,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠧࠨ堅"),[l11lll_l1_ (u"ࠨࠩ堆")],[link]
		if l11lll_l1_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭堇") in list(l111l1l111ll_l1_.headers.keys()):
			cookies = l111l1l111ll_l1_.headers[l11lll_l1_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧ堈")]
			link = re.findall(l11lll_l1_ (u"ࠫࡤࡲ࡮࡬ࡡ࠱࠮ࡄࡃࠨ࠯ࠬࡂ࠭ࡀ࠭堉"),cookies,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ堊"),[l11lll_l1_ (u"࠭ࠧ堋")],[link]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫ堌"),[],[]
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠣࠡࡰࡲࡸࠥࡽ࡯ࡳ࡭࡬ࡲ࡬ࠐࠉࠊࠥࠣ࡭ࡹࠦ࡮ࡦࡧࡧࡷࠥࡩ࡯ࡰ࡭࡬ࡩࠥ࡬ࡲࡰ࡯ࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠊࠊࠋࠦࠤࡈࡵ࡯࡬࡫ࡨ࠾ࠥࡩࡦࡠࡥ࡯ࡩࡦࡸࡡ࡯ࡥࡨࡁࡈࡓࡥ࠯ࡊࡎࡋࡖࡱ࡭ࡸࡰࡖ࡚ࡺࡴࡺࡗࡋࡳࡵࡴࡽࡱࡔࡃ࡝ࡧࡵࡴࡆ࠸࡬ࡅࡔ࡚ࡕࡑࡣ࡛ࡅࡊ࠵࠳࠱࠷࠸࠶࠵࠶࠸࠰࠱࠸࠰࠴࠲࠸࠵࠱ࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࠤࡂࠦࡓࡆࡔ࡙ࡉࡗ࠮ࡵࡳ࡮࠯ࠫࡺࡸ࡬ࠨࠫࠍࠍࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽ࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࠻ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗࠬ࠮࠲ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࠼ࡶࡩࡷࡼࡥࡳࡿࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡒࡏࡏࡉࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫ࠮ࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑࢂࡲࡦ࠰ࡌࡋࡓࡕࡒࡆࡅࡄࡗࡊ࠯ࠊࠊࠋ࡬ࡪࠥࡲࡩ࡯࡭ࡶ࠾ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰࡹ࡛࠱࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡩࡲࡨࡥࡥ࠯ࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡶࡪࡺࡵࡳࡰࠣࠫࠬ࠲࡛ࠨࠩࡠ࠰ࡠࡲࡩ࡯࡭ࡠࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡵࡳ࡮ࠣࡁࠥࡲࡩ࡯࡭ࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠱࡮ࡴ࡮࡮ࠬࠎࠎࠏࠣ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯ࡠ࠶࡝ࠋࠋࠌࠧ࡮࡬ࠠࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠍࠍࠎࠩࠉࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠨࠏࡲࡦࡶࡸࡶࡳࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠐࠉࠊࠥࡨࡰࡸ࡫࠺ࠡࡷࡵࡰࠥࡃࠠ࡭࡫ࡱ࡯ࠏࠏࠢࠣࠤ堍")
	#if l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺࠮ࡩࡶࡰࡰࠬ堎") in url:
	#	l1ll11l11lll_l1_ = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ堏"))
	#	url = l11lll_l1_ (u"ࠫ࠴࠭堐").join(l1ll11l11lll_l1_[:4])
	#	tmp = re.findall(l11lll_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅ࠯࠰࠰࠭ࡃ࠴࠯ࠨ࠯ࠬࡂ࠭ࠩ࠭堑"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11lll_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭堒")+tmp[0][1]+l11lll_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭堓")
	#	#return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ堔"),[l11lll_l1_ (u"ࠩࠪ堕")],[url]
	#	#l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l11l1l_l1_(url)
	#	#return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
	# l1l11llll_l1_ link
	#return l11lll_l1_ (u"ࠪࠫ堖"),[l11lll_l1_ (u"ࠫࠬ堗")],[link]
def l1l1l1111lll_l1_(link):
	# https://l111l1lll1ll_l1_.l111ll1l11ll_l1_/l1llllllll1l1_l1_?_1111ll11lll_l1_=l111111l1ll1_l1_&_1111lllll11_l1_=86046&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠬࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠩ堘") in link:
		headers = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ堙"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ堚")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ堛"),link,l11lll_l1_ (u"ࠩࠪ堜"),headers,l11lll_l1_ (u"ࠪࠫ堝"),l11lll_l1_ (u"ࠫࠬ堞"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ堟"))
		url = response.content
		if url: return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ堠"),[l11lll_l1_ (u"ࠧࠨ堡")],[url]
	else:
		# https://l1111l111lll_l1_.net/?l11llll1_l1_=142302&l1l11111_l1_=4
		parts = re.findall(l11lll_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ堢"),link,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11lll_l1_ (u"ࠩࡢࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ堣"),link,re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		server = SERVER(link,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ堤"))
		#url = server+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡖ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ堥")
		url = server+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡸ࡭࡫࡭ࡦ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭堦")
		#url = server+l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ堧")+l11llll1_l1_+l11lll_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ堨")+l1l11111_l1_
		#data = {l11lll_l1_ (u"ࠨ࡫ࡧࠫ堩"):l11llll1_l1_,l11lll_l1_ (u"ࠩ࡬ࠫ堪"):l1l11111_l1_,l11lll_l1_ (u"ࠪࡱࡪࡺࡡࠨ堫"):l11lll_l1_ (u"ࠫࡴࡲࡤࡠࡵࡨࡶࡻ࡫ࡲࡴࠩ堬"),l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ堭"):l11lll_l1_ (u"࠭࡯࡭ࡦࠪ堮")}
		data = {l11lll_l1_ (u"ࠧࡪࡦࠪ堯"):l11llll1_l1_,l11lll_l1_ (u"ࠨ࡫ࠪ堰"):l1l11111_l1_}
		headers = {l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ報"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ堲"),l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ堳"):link}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ場"),url,data,headers,l11lll_l1_ (u"࠭ࠧ堵"),l11lll_l1_ (u"ࠧࠨ堶"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠲࡯ࡦࠪ堷"))
		l11lll1l_l1_ = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堸"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭堹"),[l11lll_l1_ (u"ࠫࠬ堺")],[l11l11l_l1_]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ堻"),[],[]
def l111lll1111l_l1_(l11111l1llll_l1_):
	l11ll11l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡳࡵࡴࠪ堼"),l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ堽"),l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࡟ࡗࡇࡕࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠭堾"))
	headers = {l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ堿"):l11ll11l1_l1_} if l11ll11l1_l1_ else l11lll_l1_ (u"ࠪࠫ塀")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ塁"),l11111l1llll_l1_,l11lll_l1_ (u"ࠬ࠭塂"),headers,l11lll_l1_ (u"࠭ࠧ塃"),l11lll_l1_ (u"ࠧࠨ塄"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠶ࡹࡴࠨ塅"))
	l11111ll1l11_l1_ = response.content
	l1111l11llll_l1_ = str(response.headers)
	l1111ll11l1l_l1_ = l1111l11llll_l1_+l11111ll1l11_l1_
	if l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ塆") in l1111ll11l1l_l1_: l1ll1ll1l_l1_ = True
	else:
		l111111ll11l_l1_,token,l11l11l111ll_l1_,l1111lll1lll_l1_,l1ll1ll1l_l1_ = l11lll_l1_ (u"ࠪࠫ塇"),l11lll_l1_ (u"ࠫࠬ塈"),l11lll_l1_ (u"ࠬ࠭塉"),l11lll_l1_ (u"࠭ࠧ塊"),False
		l11l11ll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ塋"),l11111ll1l11_l1_,re.DOTALL)
		if l11l11ll1lll_l1_: l11l11l111ll_l1_,l1111lll1lll_l1_ = l11l11ll1lll_l1_[0]
		l111l1ll11ll_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ塌")][7]
		user = l11llll11ll_l1_(32)
		if 0:
			data = {l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ塍"):user,l11lll_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ塎"):l11ll111111_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ塏"):l11111l1llll_l1_,l11lll_l1_ (u"ࠬࡱࡥࡺࠩ塐"):l1111lll1lll_l1_,l11lll_l1_ (u"࠭ࡩࡥࠩ塑"):l11lll_l1_ (u"ࠧࠨ塒"),l11lll_l1_ (u"ࠨ࡬ࡲࡦࠬ塓"):l11lll_l1_ (u"ࠩࡪࡩࡹࡻࡲ࡭ࡵࠪ塔")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ塕"),l111l1ll11ll_l1_,data,l11lll_l1_ (u"ࠫࠬ塖"),l11lll_l1_ (u"ࠬ࠭塗"),l11lll_l1_ (u"࠭ࠧ塘"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧ塙"))
			html = response.content
		html = l11lll_l1_ (u"ࠨࠩ塚")
		if html.startswith(l11lll_l1_ (u"ࠩࡘࡖࡑ࡙࠽ࠨ塛")):
			l11llll11l11_l1_ = EVAL(l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ塜"),html.split(l11lll_l1_ (u"࡚ࠫࡘࡌࡔ࠿ࠪ塝"),1)[1])
			for request in l11llll11l11_l1_:
				url = request[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ塞")]
				method = request[l11lll_l1_ (u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭塟")]
				data = request[l11lll_l1_ (u"ࠧࡥࡣࡷࡥࠬ塠")]
				headers = request[l11lll_l1_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ塡")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠩࠪ塢"),l11lll_l1_ (u"ࠪࠫ塣"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫ塤"))
				l11111ll1l11_l1_ = response.content
				if l11lll_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ塥") in l11111ll1l11_l1_:
					l1ll1ll1l_l1_ = True
					break
				l1111l11llll_l1_ = str(response.headers)
				l1111ll11l1l_l1_ = l1111l11llll_l1_+l11111ll1l11_l1_
				l111111ll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡠࡼ࠱ࠩ࠯ࠬࡂࠦ࠭࡫ࡹࡋ࠰࠭ࡃ࠮ࠨࠧ塦"),l1111ll11l1l_l1_,re.DOTALL)
				token = re.findall(l11lll_l1_ (u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯࠰࠭ࡃࠧ࠮࠰࠴ࡃ࠱࠮ࡄ࠯ࠢࠨ塧"),l1111ll11l1l_l1_,re.DOTALL)
				if token: token = token[0]
				if l111111ll11l_l1_ or token: break
		if not l1ll1ll1l_l1_:
			if not l111111ll11l_l1_:
				if not token and l11l11ll1lll_l1_:
					if 1 and not html.startswith(l11lll_l1_ (u"ࠨࡋࡇࡁࠬ塨")):
						data = {l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ塩"):user,l11lll_l1_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ塪"):l11ll111111_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ填"):l11111l1llll_l1_,l11lll_l1_ (u"ࠬࡱࡥࡺࠩ塬"):l1111lll1lll_l1_,l11lll_l1_ (u"࠭ࡩࡥࠩ塭"):l11lll_l1_ (u"ࠧࠨ塮"),l11lll_l1_ (u"ࠨ࡬ࡲࡦࠬ塯"):l11lll_l1_ (u"ࠩࡪࡩࡹ࡯ࡤࠨ塰")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ塱"),l111l1ll11ll_l1_,data,l11lll_l1_ (u"ࠫࠬ塲"),l11lll_l1_ (u"ࠬ࠭塳"),l11lll_l1_ (u"࠭ࠧ塴"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠸ࡹ࡮ࠧ塵"))
						html = response.content
					else: html = l11lll_l1_ (u"ࠨࡋࡇࡁ࠶࠸࠳࠵࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃ࠴࠶ࠩ塶")
					if html.startswith(l11lll_l1_ (u"ࠩࡌࡈࡂ࠭塷")):
						l1111ll1l111_l1_ = re.findall(l11lll_l1_ (u"ࠪࡍࡉࡃࠨ࠯ࠬࡂ࠭࠿ࡀ࠺࠻ࡖࡌࡑࡊࡕࡕࡕ࠿ࠫ࠲࠯ࡅࠩࠥࠩ塸"),html,re.DOTALL)
						l1111llll1l1_l1_,timeout = l1111ll1l111_l1_[0]
						message = l11lll_l1_ (u"ࠫ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬ๊ࠡๅฮ๋ࠥๆࠡ࠳࠳ࠤส๊้ࠡࠩ塹")+timeout+l11lll_l1_ (u"ࠬࠦหศ่ํอࠬ塺")
						l11l1l1ll1_l1_ = DIALOG_PROGRESS()
						l11l1l1ll1_l1_.create(l11lll_l1_ (u"࠭ๅฮษ๋่ฮࠦสอษ๋ึࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ๎ไิฬࠣฬึ์วๆฮࠣ็ํ๋ศ๋๊อีࠬ塻"),message)
						t1 = time.time()
						l11l1l11llll_l1_,l11l11l1llll_l1_ = 0,0
						while l11l1l11llll_l1_<int(timeout):
							PROGRESS_UPDATE(l11l1l1ll1_l1_,int(l11l1l11llll_l1_/int(timeout)*100),message,l11lll_l1_ (u"ࠧࠨ塼"),timeout+l11lll_l1_ (u"ࠨࠢ࠲ࠤࠬ塽")+str(int(l11l1l11llll_l1_))+l11lll_l1_ (u"ࠩࠣࠤะอๆ๋หࠪ塾"))
							#if l11l1l1ll1_l1_.iscanceled(): break
							if l11l1l11llll_l1_>l11l11l1llll_l1_+10:
								data = {l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ塿"):user,l11lll_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ墀"):l11ll111111_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ墁"):l11111l1llll_l1_,l11lll_l1_ (u"࠭࡫ࡦࡻࠪ墂"):l1111lll1lll_l1_,l11lll_l1_ (u"ࠧࡪࡦࠪ境"):l1111llll1l1_l1_,l11lll_l1_ (u"ࠨ࡬ࡲࡦࠬ墄"):l11lll_l1_ (u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫ墅")}
								response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ墆"),l111l1ll11ll_l1_,data,l11lll_l1_ (u"ࠫࠬ墇"),l11lll_l1_ (u"ࠬ࠭墈"),l11lll_l1_ (u"࠭ࠧ墉"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠹ࡹ࡮ࠧ墊"))
								html = response.content
								if html.startswith(l11lll_l1_ (u"ࠨࡖࡒࡏࡊࡔ࠽ࠨ墋")):
									token = html.split(l11lll_l1_ (u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ墌"),1)[1]
									break
								l11l11l1llll_l1_ = l11l1l11llll_l1_
							else: time.sleep(1)
							l11l1l11llll_l1_ = time.time()-t1
						l11l1l1ll1_l1_.close()
				if token:
					l11l11l11ll1_l1_ = response.cookies
					l1l11111111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࡀࠬ࠳࠰࠿ࠪ࠽ࠪ墍"),l1111ll11l1l_l1_,re.DOTALL)
					if l11lll_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࠫ墎") in list(l11l11l11ll1_l1_.keys()): l1l11111111l_l1_ = l11l11l11ll1_l1_[l11lll_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ墏")]
					elif l1l11111111l_l1_: l1l11111111l_l1_ = l1l11111111l_l1_[0]
					l11l11ll1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡢࡩࡨ࠱ࡷ࡫ࡤࡪࡴࡨࡧࡹ࠴ࠪࡀࡣࡦࡸ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶ࡭ࡹ࡫࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ墐"),l11111ll1l11_l1_,re.DOTALL)
					if l11l11ll1lll_l1_: l11l11l111ll_l1_,l1111lll1lll_l1_ = l11l11ll1lll_l1_[0]
					if l1l11111111l_l1_ and l11l11ll1lll_l1_:
						headers = {l11lll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ墑"):l11lll_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠩ墒")+l1l11111111l_l1_,l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ墓"):l11111l1llll_l1_,l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ墔"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ墕")}
						data = l11lll_l1_ (u"ࠬ࡭࠭ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡶࡪࡹࡰࡰࡰࡶࡩࡂ࠭墖")+token
						response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ増"),l11l11l111ll_l1_,data,headers,False,l11lll_l1_ (u"ࠧࠨ墘"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠻ࡺࡨࠨ墙"))
						l11111ll1l11_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l111111ll11l_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࠯ࠬࡂ࠭ࠬࡀࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ墚"),str(cookies),re.DOTALL)
			if l111111ll11l_l1_:
				name,l111111ll11l_l1_ = l111111ll11l_l1_[0]
				l11ll11l1_l1_ = name+l11lll_l1_ (u"ࠪࡁࠬ墛")+l111111ll11l_l1_
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ墜"),l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࡣ࡛ࡋࡒࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠪ墝"),l11ll11l1_l1_,PERMANENT_CACHE)
				DIALOG_OK(l11lll_l1_ (u"࠭ࠧ增"),l11lll_l1_ (u"ࠧࠨ墟"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ墠"),l11lll_l1_ (u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭墡"))
				if l11lll_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ墢") not in l11111ll1l11_l1_:
					headers = {l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ墣"):l11ll11l1_l1_}
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ墤"),l11111l1llll_l1_,l11lll_l1_ (u"࠭ࠧ墥"),headers,l11lll_l1_ (u"ࠧࠨ墦"),l11lll_l1_ (u"ࠨࠩ墧"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠽ࡴࡩࠩ墨"))
					l11111ll1l11_l1_ = response.content
	if not l1ll1ll1l_l1_ and not l11ll11l1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ墩"),l11lll_l1_ (u"ࠫࠬ墪"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ墫"),l11lll_l1_ (u"ู࠭ๆๆํอࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ็ิๅฬࠣ࠲࠳ࠦอศ๊็ࠤส฿วะหࠣห้฿ๅๅ์ฬࠤ๊ืษࠡลัี๎ࠦศศีอาิอๅ่ࠡไืࠥอไโ์า๎ํࠦร้ࠢไ๎ิ๐่ࠡ฼ํี์ࠦๅ็้ࠢๅุࠦวๅ็๋ๆ฾࠭墬"))
	return l11111ll1l11_l1_
def l111111_l1_(url,type,l11l111l_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ墭"),l11lll_l1_ (u"ࠨࠩ墮"),url,type)
	# http://l111l11lllll_l1_.l11l1l1ll111_l1_.io/link/136530
	l1lllll1_l1_,l1lllll11l1_l1_ = [],[]
	#l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ墯"),l11lll_l1_ (u"ࠪࠫ墰"),True,l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠱ࡴࡶࠪ墱"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ墲"),url,l11lll_l1_ (u"࠭ࠧ墳"),l11lll_l1_ (u"ࠧࠨ墴"),l11lll_l1_ (u"ࠨࠩ墵"),l11lll_l1_ (u"ࠩࠪ墶"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠷ࡳࡵࠩ墷"))
	l11lll1l_l1_ = response.content
	l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁ࠿࠳ࡦࡄࠧ墸"),l11lll1l_l1_,re.DOTALL)
	for block in l111l11_l1_:
		links = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ墹"),block,re.DOTALL)
		for link,title in links:
			if link in l1lllll1_l1_: continue
			if l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ墺") not in link and l11lll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ墻") not in link: continue
			title = title.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩ墼"),l11lll_l1_ (u"ࠩࠪ墽")).replace(l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ墾"),l11lll_l1_ (u"ࠫࠬ墿")).strip(l11lll_l1_ (u"ࠬࠦࠧ壀")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩ壁"),l11lll_l1_ (u"ࠧࠡࠩ壂"))
			l1lllll1_l1_.append(link)
			l1lllll11l1_l1_.append(title)
	if len(l1lllll1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨส฼ฺ์อ๋ࠠฯอหัࠦ࠶࠱ࠢฮห๋๐ษࠨ壃"),l1lllll11l1_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ壄"),[],[]
	elif len(l1lllll1_l1_)==1: l1l_l1_ = 0
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫ壅"),[],[]
	l11111l1llll_l1_ = l1lllll1_l1_[l1l_l1_]
	l11111ll1l11_l1_ = l111lll1111l_l1_(l11111l1llll_l1_)
	l1111_l1_,l1lll1ll_l1_ = [],[]
	if type==l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭壆"):
		l111l11ll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡨࡴ࡯࠯࡯ࡳࡦࡪࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ壇"),l11111ll1l11_l1_,re.DOTALL)
		if l111l11ll1ll_l1_:
			link = l111l_l1_(l111l11ll1ll_l1_[0])
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(l11l111l_l1_)
	elif type==l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ壈"):
		links = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ壉"),l11111ll1l11_l1_,re.DOTALL)
		for link,size in links:
			if not link: continue
			if l11l111l_l1_ in size:
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
				break
		if not l1111_l1_:
			for link,size in links:
				if not link: continue
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨࡖࡈࡗ࡙࠭壊"),l1111_l1_)
	if not l1111_l1_: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡑࡗࡂࡏࠪ壋"),[],[]
	return l11lll_l1_ (u"ࠪࠫ壌"),l1lll1ll_l1_,l1111_l1_
def l1l111l_l1_(url,name):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ壍"),l11lll_l1_ (u"ࠬ࠭壎"),url,l11l1l1l1l11_l1_)
	# http://l11l1l1111l_l1_.l111l1111l11_l1_.net/5cf68c23e6e79			?l11l1l1l1l11_l1_=			__11l1lllll11_l1_
	# http://w.l11ll1l1_l1_.l1ll1lll111_l1_/5e14fd0a2806e			?l11l1l1l1l11_l1_=			ok.l111l1l11ll1_l1_
	#l11l1l1l1l11_l1_ = l11l1l1l1l11_l1_.replace(l11lll_l1_ (u"࠭ࡡ࡬ࡱࡤࡱࡤࡥࠧ壏"),l11lll_l1_ (u"ࠧࠨ壐")).split(l11lll_l1_ (u"ࠨࡡࡢࠫ壑"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭壒"),url,l11lll_l1_ (u"ࠪࠫ壓"),l11lll_l1_ (u"ࠫࠬ壔"),True,l11lll_l1_ (u"ࠬ࠭壕"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ壖"))
	html = response.content
	cookies = response.cookies
	if l11lll_l1_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ壗") in list(cookies.keys()):
		l11ll11l1_l1_ = cookies[l11lll_l1_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ壘")]
		l11ll11l1_l1_ = l111l_l1_(escapeUNICODE(l11ll11l1_l1_))
		items = re.findall(l11lll_l1_ (u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ壙"),l11ll11l1_l1_,re.DOTALL)
		l11l11l_l1_ = items[0].replace(l11lll_l1_ (u"ࠪࡠ࠴࠭壚"),l11lll_l1_ (u"ࠫ࠴࠭壛"))
		l11l11l_l1_ = escapeUNICODE(l11l11l_l1_)
	else: l11l11l_l1_ = url
	if l11lll_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ壜") in l11l11l_l1_:
		id = l11l11l_l1_.split(l11lll_l1_ (u"࠭ࠥ࠳ࡈࠪ壝"))[-1]
		l11l11l_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ壞")+id
		return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ壟"),[l11lll_l1_ (u"ࠩࠪ壠")],[l11l11l_l1_]
	else:
		l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ壡")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ壢"),l1l1ll11_l1_,l11lll_l1_ (u"ࠬ࠭壣"),l11lll_l1_ (u"࠭ࠧ壤"),True,l11lll_l1_ (u"ࠧࠨ壥"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ壦"))
		l11l1l1l11l1_l1_ = response.url
		#l11l1l1l11l1_l1_ = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ壧")]
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ壨"),l11lll_l1_ (u"ࠫࠬ壩"),response.url,l1l1ll11_l1_)
		l111l1ll1l1l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠬ࠵ࠧ壪"))[2]#.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ士"))
		l11ll1111lll_l1_ = l11l1l1l11l1_l1_.split(l11lll_l1_ (u"ࠧ࠰ࠩ壬"))[2]#.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭壭"))
		l11l1l1_l1_ = l11l11l_l1_.replace(l111l1ll1l1l_l1_,l11ll1111lll_l1_)
		headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭壮"):l11lll_l1_ (u"ࠪࠫ壯") , l11lll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ声"):l11lll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭壱") , l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ売"):l11l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ壳"), l11l1l1_l1_, l11lll_l1_ (u"ࠨࠩ壴"), headers, False,l11lll_l1_ (u"ࠩࠪ壵"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠹ࡲࡥࠩ壶"))
		html = response.content
		#xbmc.log(str(l11l1l1_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11lll_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ壷"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭壸"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11lll_l1_ (u"࠭࠼ࡦ࡯ࡥࡩࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭壹"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ壺"),l11lll_l1_ (u"ࠨࠩ壻"),str(items),html)
		if items:
			link = items[0].replace(l11lll_l1_ (u"ࠩ࡟࠳ࠬ壼"),l11lll_l1_ (u"ࠪ࠳ࠬ壽"))
			link = link.rstrip(l11lll_l1_ (u"ࠫ࠴࠭壾"))
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ壿") not in link: link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ夀") + link
			link = link.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ夁"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ夂"))
			if name==l11lll_l1_ (u"ࠩࠪ夃"): l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠪࠫ处"),[l11lll_l1_ (u"ࠫࠬ夅")],[link]
			else: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ夆"),[l11lll_l1_ (u"࠭ࠧ备")],[link]
		else: l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏࡔࡇࡍࠨ夈"),[],[]
		return l11l1lll11l1_l1_,l1lll1ll_l1_,l1111_l1_
def l11l11ll111l_l1_(url):
	# https://www.l11l1l111111_l1_.com/e/l1111l11lll1_l1_
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ変") : l11lll_l1_ (u"ࠩࠪ夊") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ夋"),headers,l11lll_l1_ (u"ࠫࠬ夌"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ复"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ夎"),l11lll_l1_ (u"ࠧࠨ夏"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ夐"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠩࠪ夑")
	if items:
		for link,l1ll111llll1_l1_ in items:
			l1lll1ll_l1_.append(l1ll111llll1_l1_)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩ夒"),[],[]
	return l11lll_l1_ (u"ࠫࠬ夓"),l1lll1ll_l1_,l1111_l1_
def l1111ll11111_l1_(url):
	# https://l111l111lll1_l1_.io/l1l11llll_l1_-l1111ll111l1_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ夔"),l11lll_l1_ (u"࠭ࠧ夕"))
	headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ外"):l11lll_l1_ (u"ࠨࠩ夗")}
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ夘"),headers,l11lll_l1_ (u"ࠪࠫ夙"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ多"))
	items = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ夛"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ夜"),l11lll_l1_ (u"ࠧࠨ夝"),url,items[0])
	if items:
		url = items[0]+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ夞")+url
		return l11lll_l1_ (u"ࠩࠪ够"),[l11lll_l1_ (u"ࠪࠫ夠")],[url]
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭夡"),[],[]
def l111ll1lll11_l1_(url):
	# https://l1llllllll1ll_l1_.to/l1l11llll_l1_/5c83f14297d62
	url = url.strip(l11lll_l1_ (u"ࠬ࠵ࠧ夢"))
	if l11lll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ夣") in url: id = url.split(l11lll_l1_ (u"ࠧ࠰ࠩ夤"))[4]
	else: id = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ夥"))[-1]
	url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭夦") + id
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ大") : l11lll_l1_ (u"ࠫࠬ夨") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭天"),headers,l11lll_l1_ (u"࠭ࠧ太"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ夫"))
	html = html.replace(l11lll_l1_ (u"ࠨ࡞࡟ࠫ夬"),l11lll_l1_ (u"ࠩࠪ夭"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ央"),l11lll_l1_ (u"ࠫࠬ夯"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ夰"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"࠭ࠧ失"),[l11lll_l1_ (u"ࠧࠨ夲")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡈ࡙ࡔࡓࡇࡄࡑࠬ夳"),[],[]
def l1111lll1l11_l1_(url):
	# https://l11l1ll11l1l_l1_.net/l1l11llll_l1_-l11l111lll11_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ头"),l11lll_l1_ (u"ࠪࠫ夵"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ夶"),l11lll_l1_ (u"ࠬ࠭夷"),l11lll_l1_ (u"࠭ࠧ夸"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡏ࡛ࡃ࠰࠵ࡸࡺࠧ夹"))
	items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠣࡶࡪࡹ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ夺"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for link,l1ll111llll1_l1_,res in items:
		l1lll1ll_l1_.append(l1ll111llll1_l1_+l11lll_l1_ (u"ࠩࠣࠫ夻")+res)
		l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡉࡅࡑ࡝ࡅࠬ夼"),[],[]
	return l11lll_l1_ (u"ࠫࠬ夽"),l1lll1ll_l1_,l1111_l1_
def l111lllll1ll_l1_(url):
	# https://l11l1lll11ll_l1_.l1ll1ll1l11_l1_/l1l11llll_l1_-l111l11111l1_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ夾"),l11lll_l1_ (u"࠭ࠧ夿"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ奀"),l11lll_l1_ (u"ࠨࠩ奁"),l11lll_l1_ (u"ࠩࠪ奂"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ奃"))
	items = re.findall(l11lll_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࡠࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡀ࠴ࡺࡤ࠿ࠤ奄"),html,re.DOTALL)
	items = set(items)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for id,mode,hash,l1ll111llll1_l1_,res in items:
		url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱ࠱ࡹࡸ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩ奅")+id+l11lll_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭奆")+mode+l11lll_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ奇")+hash
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ奈"),l11lll_l1_ (u"ࠩࠪ奉"),l11lll_l1_ (u"ࠪࠫ奊"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ奋"))
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ奌"),html,re.DOTALL)
		for link in items:
			l1lll1ll_l1_.append(l1ll111llll1_l1_+l11lll_l1_ (u"࠭ࠠࠨ奍")+res)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠭奎"),[],[]
	return l11lll_l1_ (u"ࠨࠩ奏"),l1lll1ll_l1_,l1111_l1_
def l1lllllllll11_l1_(url):
	# https://l111111ll111_l1_.com:2053/l111111lll11_l1_/l1111lllll1l_l1_.l11l1111l111_l1_.l11ll11111l1_l1_.1080p.l11l1llll1l1_l1_.l11l1l1l11ll_l1_.l1111111l1ll_l1_.l1111lll_l1_.html?l111llll1l1l_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l111lll1l_l1_=1624070560
	# http://l11111ll1ll1_l1_.l1111llllll_l1_/l11l111111l1_l1_/l11l1111ll11_l1_.l111ll111l1l_l1_.l11l111ll111_l1_.2018.1080p.l111l1ll1l11_l1_-l111ll1l111l_l1_.l11111ll11ll_l1_.l1111lll_l1_.html
	link = l11lll_l1_ (u"ࠩࠪ奐")
	if 1 or l11lll_l1_ (u"ࠪࡏࡪࡿ࠽ࠨ契") not in url:
		l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠫࡺࡶࡢࡰ࡯࠱ࡰ࡮ࡼࡥࠨ奒"),l11lll_l1_ (u"ࠬࡻࡰࡱࡱࡰ࠲ࡱ࡯ࡶࡦࠩ奓"))
		l11l11l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"࠭࠯ࠨ奔"))
		id = l11l11l_l1_[3]
		l11l11l_l1_ = l11lll_l1_ (u"ࠧ࠰ࠩ奕").join(l11l11l_l1_[0:4])
		#headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ奖"):l1l11l11l_l1_(),l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ套"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ奘")}
		payload = {l11lll_l1_ (u"ࠫ࡮ࡪࠧ奙"):id,l11lll_l1_ (u"ࠬࡵࡰࠨ奚"):l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ奛"),l11lll_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ奜"):l11lll_l1_ (u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ奝")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ奞"),l11l11l_l1_,payload,l11lll_l1_ (u"ࠪࠫ奟"),l11lll_l1_ (u"ࠫࠬ奠"),l11lll_l1_ (u"ࠬ࠭奡"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬ奢"))
		if l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ奣") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ奤")]
		if not link and response.succeeded:
			html = response.content
			link = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭奥"),html,re.DOTALL)
			if link: link = link[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ奦"),url,l11lll_l1_ (u"ࠫࠬ奧"),l11lll_l1_ (u"ࠬ࠭奨"),l11lll_l1_ (u"࠭ࠧ奩"),l11lll_l1_ (u"ࠧࠨ奪"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠶ࡳࡪࠧ奫"))
		if l11lll_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ奬") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ奭")]
	if link: return l11lll_l1_ (u"ࠫࠬ奮"),[l11lll_l1_ (u"ࠬ࠭奯")],[link]
	return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧ奰"),[],[]
def l111lll111ll_l1_(url):
	# https://www.l111l1llll1l_l1_.com/012ocyw9li6g.html
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ奱") : l11lll_l1_ (u"ࠨࠩ奲") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ女"),headers,l11lll_l1_ (u"ࠪࠫ奴"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡋࡌ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭奵"))
	items = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦ࠭࠴ࠪࡀࠫࠥࠫ奶"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	if items:
		l1lll1ll_l1_.append(l11lll_l1_ (u"࠭࡭ࡱ࠶ࠪ奷"))
		l1111_l1_.append(items[0][1])
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠬ奸"))
		l1111_l1_.append(items[0][0])
		return l11lll_l1_ (u"ࠨࠩ她"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡏࡉࡗࡋࡇࡉࡔ࠭奺"),[],[]
def l111llll1l1_l1_(url):
	# l11l11111lll_l1_ l11l11lllll1_l1_			url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽࡚࠹࡚࠸࠶࡜ࡍࡹࡻࡔࡉࠬ奻")
	# l11111l11ll1_l1_ .l11l1lllll1l_l1_ l11l11lllll1_l1_		url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡚ࡹࡱࡘࡔࡁࡺࡧࡼࡊࡎ࠭奼")
	# l11l111111ll_l1_ l11l1l1l11_l1_ .l1llll1l1_l1_ l11l11lllll1_l1_		url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡊࡪ࠷࠳ࡎࡔࡶࡖࡷࡓࡽࠧ好")
	# l111lll1l11l_l1_ l11l11lllll1_l1_			url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ奾")
	# l111l11l11_l1_ files have l111ll1lll1l_l1_ l1l1111lllll_l1_		url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࠶ࡽࡄࡓࡗ࡙ࡧࡘࡿ࡟ࡒࠩ奿")
	# url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࡪࡊ࡬࡛࠷ࡹࡅࡓࡗࡕࡨࠩ妀")
	# url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼ࠶ࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ妁")
	# url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ如")
	# url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭妃")
	# url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡳࡊࡊࡲ࡫ࡪࡡࡍ࠵࡞ࡱࠦࡢࡤࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡁࡌࡵ࡬ࡥࡧࡱࡐ࡮ࡴࡥࡧࡱࡵࡘ࡛ࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡣࡱࡨࡉ࡯ࡳࡵࡴ࡬ࡦࡺࡺࡩࡰࡰࡂࡷࡾࡴࡤࡪࡥࡤࡸ࡮ࡵ࡮࠾࠴࠺࠻࠺࠽࠵ࠨ妄")
	# l1ll1llll_l1_ l1111l1lll11_l1_ details   https://l111l111111l_l1_.me/l111111l11ll_l1_/l11111111l11_l1_-l111111l11l1_l1_-l1111l1ll11l_l1_
	id = url.split(l11lll_l1_ (u"࠭࠯ࠨ妅"))[-1]
	id = id.split(l11lll_l1_ (u"ࠧࠧࠩ妆"))[0]
	id = id.replace(l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ妇"),l11lll_l1_ (u"ࠩࠪ妈"))
	#id = l11lll_l1_ (u"ࠪࡩࡤ࡙࠹ࡗࡸࡍࡑ࠶ࡖࡉࠨ妉")
	#url = l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ妊")+id
	#return l11lll_l1_ (u"ࠬ࠭妋"),[l11lll_l1_ (u"࠭ࠧ妌")],[url]
	l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ妍")][0]+l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ妎")+id
	l1llllllllll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡼࡳࡺࡺࡵ࠯ࡤࡨ࠳ࠬ妏")+id
	l111ll111lll_l1_,l111111ll1ll_l1_,l11ll11111ll_l1_,l11111l1ll11_l1_ = l11lll_l1_ (u"ࠪࠫ妐"),l11lll_l1_ (u"ࠫࠬ妑"),l11lll_l1_ (u"ࠬ࠭妒"),l11lll_l1_ (u"࠭ࠧ妓")
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡝ࠩ࠯ࠫࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠫ࠲࠯ࡅࠩࡥࡧࡩࡥࡺࡲࡴࡂࡷࡧ࡭ࡴ࡚ࡲࡢࡥ࡮ࡍࡳࡪࡥࡹࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠩࠫ࠮ࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡼࠤ࡯ࡥࡳ࡭ࡵࡢࡩࡨࡇࡴࡪࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ࡟࠯࡟ࠬ࠭࡝ࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮ࡤࡲ࡬࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭ࡣࡱ࡫࠮ࠐࠉࠊࠋࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ࠰ࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠌࠌࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡳࡵࡴࠡ࡫ࡱࠤࡠ࠶ࠬ࠮࠳ࡠ࠾ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡣࡣࡶࡩ࡚ࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࠍࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍࠢࡀࠤࡸࡻࡢࡵ࡫ࡷࡰࡪ࡛ࡒࡍ࡝࠳ࡡ࠰࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬ࠱࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠼ࠣࡨࡦࡹࡨࡖࡔࡏࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࡨࡰࡸ࡫࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡵ࠲ࠫ࠱࠭࠯ࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࠲ࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋ࡫ࡰࡸ࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠤࡪࡷࡱࡱ࠸ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡪ࡯ࡷ࡚ࡘࡌ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ࠯ࠊࠊࠋࠦ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬࡛ࠩࠩ࠱ࡒࡋࡄࡊࡃ࠽࡙ࡗࡏ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࡖ࡜ࡔࡊࡃࡓࡖࡄࡗࡍ࡙ࡒࡅࡔ࠮ࡊࡖࡔ࡛ࡐ࠮ࡋࡇࡁࠧࡼࡴࡵࠩ࠯࡬ࡹࡳ࡬࠳࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࡕࡓࡎࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠣࠬࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠪࡹࡿࡰࡦ࠿ࡷࡶࡦࡩ࡫ࠧࡶ࡯ࡥࡳ࡭࠽ࠨࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠯ࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࢀࢃࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡵࡳ࡮ࡢࡩࡳࡩ࡯ࡥࡧࡧࡣ࡫ࡳࡴࡠࡵࡷࡶࡪࡧ࡭ࡠ࡯ࡤࡴࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡡࡩࡱࡹࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡮࡬ࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨࡰࡸࡤࡲࡩࡴࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡦࡴࡤࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠧ࠽࡜ࠩࠪࡡ࠿ࠐࠉࠊࠋࡩࡱࡹࡥ࡬ࡪࡵࡷࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌࡪࡲࡺ࡟ࡪࡶࡤ࡫ࡸࠦ࠽ࠡࡨࡰࡸࡤࡲࡩࡴࡶ࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡨࡰࡸࡤ࡯ࡴࡢࡩࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡸࡦ࡭ࠬࡴ࡫ࡽࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪࠌࠌࠍࠎࠏࡦ࡮ࡶࡢࡷ࡮ࢀࡥࡠࡦ࡬ࡧࡹࡡࡩࡵࡣࡪࡡࠥࡃࠠࡴ࡫ࡽࡩࠏࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊ࡫ࡩࠤࡳࡵࡴࠡࡤ࡯ࡳࡨࡱ࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࡲࡩ࡯ࡧࡶࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠲ࠧࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡪࠦࡩ࡯ࠢ࡯࡭ࡳ࡫ࡳ࠻ࠌࠌࠍࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠱ࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࠊࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭ࡲࡩ࡯ࡧ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉ࡭࡫ࡱࡩࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩ࡮࡬ࡲࡪ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴࠡ࠿ࠣࡿࢂࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡰ࡮ࡴࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨࠨࠩࠫ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍࡰ࡫ࡹ࠭ࡸࡤࡰࡺ࡫ࠠ࠾ࠢ࡬ࡸࡪࡳ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠾ࠩ࠯࠵࠮ࠐࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜࡭ࡨࡽࡢࠦ࠽ࠡࡸࡤࡰࡺ࡫ࠊࠊࠋࠌ࡭࡫ࠦࠧࡴ࡫ࡽࡩࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࠬࡹࡩࡻࡧࠪࡡࠥࡃࠠࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺ࡛ࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢࡣࠊࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠳࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴࠪࠌࠌࡦࡱࡵࡣ࡬ࡵ࠯ࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦ࡫ࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠡࡤ࡯ࡳࡨࡱࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠫࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠨࠩࠫ࠱࠭ࠦࠨࠫࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠾ࠤࠪ࠰ࠬࡃࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࠧࠨࠧ࠭ࠩࠥࠫ࠮ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢࡥࡰࡴࡩ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠾ࡹࡸࡵࡦࠩ࠯ࠫ࠿࡚ࡲࡶࡧࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠻ࡨࡤࡰࡸ࡫ࠧ࠭ࠩ࠽ࡊࡦࡲࡳࡦࠩࠬࠎࠎࠏࡩࡧࠢࠪ࡟ࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡢ࡭ࡱࡦ࡯ࠥࡃࠠࠨ࡝ࠪ࠯ࡧࡲ࡯ࡤ࡭࠮ࠫࡢ࠭ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡉ࡛ࡇࡌࠩࠩ࡯࡭ࡸࡺࠧ࠭ࡤ࡯ࡳࡨࡱࠩࠋࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱ࠺ࠋࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠣࡁࠥࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠪࠌࠌࠍࠎࡪࡩࡤࡶ࡞ࠫࡹࡿࡰࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂ࠭ࠬࠨ࠿ࠥࠫ࠮࠱ࠧࠣࠩࠍࠍࠎࠏࡩࡧࠢࠪࡪࡵࡹࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡨࡳࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡬ࡰࡴࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡹ࡬ࡨࡹ࡮ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡵ࡬ࡾࡪ࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡷࡪࡦࡷ࡬ࠬࡣࠩࠬࠩࡻࠫ࠰ࡹࡴࡳࠪࡧ࡭ࡨࡺ࡛ࠨࡪࡨ࡭࡬࡮ࡴࠨ࡟ࠬࠎࠎࠏࠉࡪࡨࠣࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱ࡭ࡹ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡪࡴࡤࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ࡞࡝ࠪࡷࡹࡧࡲࡵࠩࡠ࠯ࠬ࠳ࠧࠬࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡦࡰࡧࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࡠࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡤ࡬ࡸࡷࡧࡴࡦࠩࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬࡩ࡯ࡣࡵ࠰࡮ࡩࡾࡹࠨࠪࠫࠣࡥࡳࡪࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࡀ࠴࠵࠶࠸࠲࠳࠵࠶࠷࠿ࠦࡤࡦ࡮ࠣࡨ࡮ࡩࡴ࡜ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠌࠌࠍࠎࠏࡣࡪࡲ࡫ࡩࡷࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩࡠ࠲ࡸࡶ࡬ࡪࡶࠫࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡬࡯ࡳࠢ࡬ࡸࡪࡳࠠࡪࡰࠣࡧ࡮ࡶࡨࡦࡴ࠽ࠎࠎࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࠋࡧ࡭ࡨࡺ࡛࡬ࡧࡼࡡࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡸࡤࡰࡺ࡫ࠩࠋࠋࠌࠍࠨ࡯ࡦࠡࠩࡸࡶࡱ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡦ࡬ࡧࡹࡡࠧࡶࡴ࡯ࠫࡢࠦ࠽ࠡࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࡛ࠨࡷࡵࡰࠬࡣࠩࠋࠋࠌࠍࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠲ࡦࡶࡰࡦࡰࡧࠬࡩ࡯ࡣࡵࠫࠍࠍࡺࡸ࡬ࡠ࡮࡬ࡷࡹ࠲ࡳࡵࡴࡨࡥࡲࡹ࠰࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠳࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠶ࠥࡃࠠ࡜࡟࠯࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲ࠢࡤࡲࡩࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࡀࠊࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷ࠵ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠻ࠌࠌࠍࠎࡻࡲ࡭࠳ࠣࡁࠥࡪࡩࡤࡶ࠴࡟ࠬࡻࡲ࡭ࠩࡠ࡟࠿࠹࠰࠱࡟ࠍࠍࠎࠏࠣࡶࡴ࡯࠵ࠥࡃࠠࡖࡐࡔ࡙ࡔ࡚ࡅࠩࡗࡑࡕ࡚ࡕࡔࡆࠪࡧ࡭ࡨࡺ࠱࡜ࠩࡸࡶࡱ࠭࡝ࠪࠫ࡞࠾࠸࠶࠰࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢࡧ࡭ࡨࡺ࠲ࠡ࡫ࡱࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡧ࡭ࡨࡺ࠲࡜ࠩࡸࡶࡱ࠭࡝࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍࠨࡻࡲ࡭࠴ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡶࡴ࡯࠵ࡂࡃࡵࡳ࡮࠵ࠤࡦࡴࡤࠡࡷࡵࡰ࠶ࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡵࡳ࡮ࡢࡰ࡮ࡹࡴ࠻ࠌࠌࠍࠎࠏࠉࡶࡴ࡯ࡣࡱ࡯ࡳࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠷ࠩࠋࠋࠌࠍࠎࠏࡤࡪࡥࡷ࠵࠳ࡻࡰࡥࡣࡷࡩ࠭ࡪࡩࡤࡶ࠵࠭ࠏࠏࠉࠊࠋࠌࡷࡹࡸࡥࡢ࡯ࡶ࠴࠳ࡧࡰࡱࡧࡱࡨ࠭ࡪࡩࡤࡶ࠴࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠥࡹࡴࡳࡧࡤࡱࡸ࠶ࠠ࠾ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠲࠭ࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳ࠌࠌࠦࠧࠨ妔")
	# l11111ll11l1_l1_ json data
	# l1l11llll_l1_ url l11l11lllll1_l1_:    https://www.l1ll1llll_l1_.com/l1l11llll_l1_/l11l111l1ll1_l1_
	# list of l11l11llllll_l1_ & l1l111l11l1l_l1_
	# https://github.com/l1111l1ll111_l1_-l111l1lll111_l1_/l1111l1ll111_l1_-l111l1lll111_l1_/blob/master/l11l11ll11l1_l1_/l111l1llllll_l1_/l1ll1llll_l1_.py
	# all the below l1111lll11l1_l1_ were l111lll111l1_l1_ using:	https://www.l1ll1llll_l1_.com/l11l1l1lll11_l1_/l1l1l1l1llll_l1_/l11ll1111ll_l1_?l111111111ll_l1_=l111111lllll_l1_	&	l11l11l1l111_l1_ = l11l111l1ll1_l1_
	# 3 l1ll11111l1l_l1_:	13KB:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ妕"): l11lll_l1_ (u"ࠩࡌࡓࡘࡥࡃࡓࡇࡄࡘࡔࡘࠧ妖"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ妗"): l11lll_l1_ (u"ࠫ࠷࠸࠮࠴࠵࠱࠵࠵࠷ࠧ妘")
	# 7 l1ll11111l1l_l1_		44KB:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ妙"): l11lll_l1_ (u"࠭ࡉࡐࡕࡢࡑࡊ࡙ࡓࡂࡉࡈࡗࡤࡋࡘࡕࡇࡑࡗࡎࡕࡎࠨ妚"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ妛"): l11lll_l1_ (u"ࠨ࠳࠺࠲࠸࠹࠮࠳ࠩ妜")
	# 7 l1ll11111l1l_l1_		58KB:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭妝"): l11lll_l1_ (u"ࠪࡍࡔ࡙ࠧ妞"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ妟"): l11lll_l1_ (u"ࠬ࠷࠷࠯࠵࠶࠲࠷࠭妠")
	# 9 l1ll11111l1l_l1_		24KB:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ妡"): l11lll_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ妢"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ妣"): l11lll_l1_ (u"ࠩ࠵࠶࠳࠹࠰࠯࠳࠳࠴ࠬ妤")
	# no json file:		21 l1ll11111l1l_l1_	95KB:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ妥"): l11lll_l1_ (u"ࠫ࡜ࡋࡂࡠࡅࡕࡉࡆ࡚ࡏࡓࠩ妦"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ妧"): l11lll_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠸࠱࠴࠵࠴࠰࠱ࠩ妨")
	# no json file:		21 l1ll11111l1l_l1_	121KB:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ妩"): l11lll_l1_ (u"ࠨ࡙ࡈࡆࠬ妪"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ妫"): l11lll_l1_ (u"ࠪ࠶࠳࠸࠰࠳࠴࠳࠼࠵࠷࠮࠱࠲࠱࠴࠵࠭妬")
	# no json file: 	26 l1ll11111l1l_l1_	115KB:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ妭"): l11lll_l1_ (u"ࠬࡓࡗࡆࡄࠪ妮"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭妯"): l11lll_l1_ (u"ࠧ࠳࠰࠵࠴࠷࠸࠰࠹࠲࠴࠲࠵࠶࠮࠱࠲ࠪ妰")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ妱"): l11lll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࠪ妲"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ妳"): l11lll_l1_ (u"ࠫ࠶࠽࠮࠴࠳࠱࠷࠺࠭妴")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ妵"): l11lll_l1_ (u"࠭ࡗࡆࡄࡢࡖࡊࡓࡉ࡙ࠩ妶"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ妷"): l11lll_l1_ (u"ࠨ࠳࠱࠶࠵࠸࠲࠱࠹࠵࠻࠳࠶࠱࠯࠲࠳ࠫ妸")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭妹"): l11lll_l1_ (u"࡛ࠪࡊࡈ࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ妺"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ妻"): l11lll_l1_ (u"ࠬ࠷࠮࠳࠲࠵࠶࠵࠽࠳࠲࠰࠳࠴࠳࠶࠰ࠨ妼")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ妽"): l11lll_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࡠࡇࡐࡆࡊࡊࡄࡆࡆࡢࡔࡑࡇ࡙ࡆࡔࠪ妾"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ妿"): l11lll_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ姀")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ姁"): l11lll_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡓࡕࡔࡋࡆࠫ姂"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ姃"): l11lll_l1_ (u"࠭࠵࠯࠳࠹࠲࠺࠷ࠧ姄")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ姅"): l11lll_l1_ (u"ࠨࡖ࡙ࡌ࡙ࡓࡌ࠶ࡡࡖࡍࡒࡖࡌ࡚ࡡࡈࡑࡇࡋࡄࡅࡇࡇࡣࡕࡒࡁ࡚ࡇࡕࠫ姆"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ姇"): l11lll_l1_ (u"ࠪ࠶࠳࠶ࠧ姈")
	# l11ll1ll11ll_l1_:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ姉"): l11lll_l1_ (u"ࠬࡏࡏࡔࡡࡐ࡙ࡘࡏࡃࠨ姊"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭始"): l11lll_l1_ (u"ࠧ࠶࠰࠵࠵ࠬ姌")
	# l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ姍")][0]+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡲࡵࡩࡹࡺࡹࡑࡴ࡬ࡲࡹࡃࡴࡳࡷࡨࠫ姎")  # l111111lllll_l1_ l1ll1l11ll1l_l1_ l111111llll1_l1_ and l1111l1llll1_l1_ l1ll11l111l1_l1_ l1l1l1ll1l_l1_ l1111l111l1l_l1_ file size
	#l11llll11_l1_ = l11lll_l1_ (u"ࠪࡿࠬ姏")l111111111l1_l1_ (u"ࠫ࠿࡯ࡤ࠭ࠩ姐")l111l1ll1ll1_l1_ (u"ࠬࡀࡻࠣࡥ࡯࡭ࡪࡴࡴࠣ࠼ࡾࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠥࡅࡓࡊࡒࡐࡋࡇࠦ࠱ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠣ࠳࠺࠲࠸࠷࠮࠴࠷ࠥࢁࢂࢃࠧ姑")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ姒"),l11l11l_l1_,l11llll11_l1_,l11lll_l1_ (u"ࠧࠨ姓"),l11lll_l1_ (u"ࠨࠩ委"),l11lll_l1_ (u"ࠩࠪ姕"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠲ࡵࡷࠫ姖"))
	#html = response.content
	for l11l1lllll_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฬ๊ๅฮษ๋่ฮࠦัใ็࠽ࠤࠥ࠭姗")+str(l11l1lllll_l1_+1),l11lll_l1_ (u"ࠬ࠭姘"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ姙"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ姚"),l11lll_l1_ (u"ࠨࠩ姛"),l11lll_l1_ (u"ࠩࠪ姜"),l11lll_l1_ (u"ࠪࠫ姝"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠳ࡶࡸࠬ姞"))
		html = response.content
		if l11lll_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ姟") in html: break
		time.sleep(2)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧ姠"),html)
	l11lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ姡"),html,re.DOTALL)
	if l11lll111l_l1_: l11lll111l_l1_ = l11lll111l_l1_[0]
	else: l11lll111l_l1_ = html
	l11lll111l_l1_ = l11lll111l_l1_.replace(l11lll_l1_ (u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ姢"),l11lll_l1_ (u"ࠩࠩࠫ姣"))
	l1111l1l1l1l_l1_ = EVAL(l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ姤"),l11lll111l_l1_)
	#WRITE_THIS(l11lll_l1_ (u"ࠫࠬ姥"),str(l1111l1l1l1l_l1_))
	# l11111ll11l1_l1_ l11l111ll1l1_l1_ & l11l1llll111_l1_
	# l1ll1llll_l1_ l11l11111lll_l1_ link l1l111l1l_l1_ l11lll_l1_ (u"ࠬࠬࡦ࡮ࡶࡀࡺࡹࡺࠧ姦") to l111l11lll_l1_ on l1111ll111l_l1_
	l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ姧")],[l11lll_l1_ (u"ࠧࠨ姨")]
	try:
		l11l111ll1l1_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪ姩")][l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭姪")][l11lll_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪ姫")]
		for l111lll1l1ll_l1_ in l11l111ll1l1_l1_:
			link = l111lll1l1ll_l1_[l11lll_l1_ (u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ姬")]
			try: title = l111lll1l1ll_l1_[l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ姭")][l11lll_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪ姮")]
			except: title = l111lll1l1ll_l1_[l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ姯")][l11lll_l1_ (u"ࠨࡴࡸࡲࡸ࠭姰")][0][l11lll_l1_ (u"ࠩࡷࡩࡽࡺࠧ姱")]
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(title)
	except: pass
	if len(l1lll1ll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ姲"), l1lll1ll_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ姳"),[],[]
		elif l1l_l1_!=0:
			link = l1111_l1_[l1l_l1_]+l11lll_l1_ (u"ࠬࠬࠧ姴")
			l111l111l1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ姵"),link)
			if l111l111l1l1_l1_: link = link.replace(l111l111l1l1_l1_[0],l11lll_l1_ (u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ姶"))
			else: link = link+l11lll_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ姷")
			l111ll111lll_l1_ = link.strip(l11lll_l1_ (u"ࠩࠩࠫ姸"))
	formats,l11l1lll1ll1_l1_,l11l11ll1l11_l1_,l11l11ll1l1l_l1_,l11l11ll11ll_l1_ = [],[],[],[],[]
	# l11111ll11l1_l1_ l111ll11lll1_l1_ l1ll11111l1l_l1_
	try: l111111ll1ll_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ姹")][l11lll_l1_ (u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭姺")]
	except: pass
	# l11111ll11l1_l1_ l11l111111ll_l1_ stream
	try: l11ll11111ll_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ姻")][l11lll_l1_ (u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ姼")]
	except: pass
	# l11111ll11l1_l1_ l1ll1l11ll_l1_ l1111lll_l1_ l1ll11111l1l_l1_
	try: formats = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ姽")][l11lll_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ姾")]
	except: pass
	# l11111ll11l1_l1_ l1ll1l11ll_l1_ l11l1lllll1l_l1_ l1ll11111l1l_l1_
	try: l11l1lll1ll1_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ姿")][l11lll_l1_ (u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ娀")]
	except: pass
	l111llllllll_l1_ = formats+l11l1lll1ll1_l1_
	for dict in l111llllllll_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ威"),str(dict))
		if l11lll_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ娂") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡩࡵࡣࡪࠫ娃")] = str(dict[l11lll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ娄")])
		if l11lll_l1_ (u"ࠨࡨࡳࡷࠬ娅") in list(dict.keys()): dict[l11lll_l1_ (u"ࠩࡩࡴࡸ࠭娆")] = str(dict[l11lll_l1_ (u"ࠪࡪࡵࡹࠧ娇")])
		if l11lll_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭娈") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ娉")] = dict[l11lll_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ娊")]		#.replace(l11lll_l1_ (u"ࠧ࠾ࠩ娋"),l11lll_l1_ (u"ࠨ࠿ࠪ娌"))+l11lll_l1_ (u"ࠩࠥࠫ娍")
		if l11lll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ娎") in list(dict.keys()): dict[l11lll_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ娏")] = str(dict[l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ娐")])
		if l11lll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭娑") in list(dict.keys()): dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ娒")] = str(dict[l11lll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ娓")])
		if l11lll_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ娔") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ娕")] = str(dict[l11lll_l1_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ娖")])+l11lll_l1_ (u"ࠬࡾࠧ娗")+str(dict[l11lll_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭娘")])
		if l11lll_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ娙") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭娚")] = dict[l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ娛")][l11lll_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ娜")]+l11lll_l1_ (u"ࠫ࠲࠭娝")+dict[l11lll_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ娞")][l11lll_l1_ (u"࠭ࡥ࡯ࡦࠪ娟")]
		if l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ娠") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ娡")] = dict[l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭娢")][l11lll_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ娣")]+l11lll_l1_ (u"ࠫ࠲࠭娤")+dict[l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ娥")][l11lll_l1_ (u"࠭ࡥ࡯ࡦࠪ娦")]
		if l11lll_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ娧") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ娨")] = dict[l11lll_l1_ (u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ娩")]
		if l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ娪") in list(dict.keys()) and int(dict[l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ娫")])>111222333: del dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭娬")]
		if l11lll_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ娭") in list(dict.keys()):
			cipher = dict[l11lll_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩ娮")].split(l11lll_l1_ (u"ࠨࠨࠪ娯"))
			for item in cipher:
				key,value = item.split(l11lll_l1_ (u"ࠩࡀࠫ娰"),1)
				dict[key] = l111l_l1_(value)
		if l11lll_l1_ (u"ࠪࡹࡷࡲࠧ娱") in list(dict.keys()): dict[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ娲")] = l111l_l1_(dict[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ娳")])
		#if l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸࡃࠧ娴") in dict[l11lll_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ娵")]: dict[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ娶")] = dict[l11lll_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ娷")].split(l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࡀࡠࠧ࠭娸"))[1].strip(l11lll_l1_ (u"ࠫࡡࠨࠧ娹"))
		#LOG_THIS(l11lll_l1_ (u"ࠬ࠭娺"),dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ娻")]+l11lll_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠࠨ娼")+dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭娽")])
		l11l11ll1l11_l1_.append(dict)
	l11ll1ll1_l1_ = l11lll_l1_ (u"ࠩࠪ娾")
	if l11lll_l1_ (u"ࠪࡷࡵࡃࡳࡪࡩࠪ娿") in l11lll111l_l1_:
		#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡾࡺࡳ࠰࡬ࡶࡦ࡮ࡴ࠯ࡱ࡮ࡤࡽࡪࡸ࡟࠯ࠬࡂ࠭ࠧ࠭婀"),html,re.DOTALL)
		# l11l11lllll1_l1_:	/s/l11ll1111ll_l1_/6dde7fb4/l1111l1111ll_l1_.l111l1ll1111_l1_/l111ll1l11l1_l1_/base.l11111llllll_l1_
		#l1111l11l11l_l1_ = [l11lll_l1_ (u"ࠬ࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰ࡦ࠻࠻ࡩ࠻࠸࠲ࡨ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࡙ࡘ࠵ࡢࡢࡵࡨ࠲࡯ࡹࠧ婁")]
		l1111l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ婂"),html,re.DOTALL)
		if l1111l11l11l_l1_:
			l1111l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ婃")][0]+l1111l11l11l_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ婄"),l1111l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ婅"),l11lll_l1_ (u"ࠪࠫ婆"),l11lll_l1_ (u"ࠫࠬ婇"),l11lll_l1_ (u"ࠬ࠭婈"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ婉"))
			l11ll1ll1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11111ll1lll_l1_ = cipher._load_javascript(l11ll1ll1_l1_)
			l111111ll1l1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ婊"),str(l11111ll1lll_l1_))
			l1111ll1ll1l_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l111111ll1l1_l1_)
	for dict in l11l11ll1l11_l1_:
		url = dict[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ婋")]
		if l11lll_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭婌") in url or url.count(l11lll_l1_ (u"ࠪࡷ࡮࡭࠽ࠨ婍"))>1:
			l11l11ll1l1l_l1_.append(dict)
		elif l11ll1ll1_l1_ and l11lll_l1_ (u"ࠫࡸ࠭婎") in list(dict.keys()) and l11lll_l1_ (u"ࠬࡹࡰࠨ婏") in list(dict.keys()):
			l111lll1l11l_l1_ = l1111ll1ll1l_l1_.execute(dict[l11lll_l1_ (u"࠭ࡳࠨ婐")])
			if l111lll1l11l_l1_!=dict[l11lll_l1_ (u"ࠧࡴࠩ婑")]:
				dict[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ婒")] = url+l11lll_l1_ (u"ࠩࠩࠫ婓")+dict[l11lll_l1_ (u"ࠪࡷࡵ࠭婔")]+l11lll_l1_ (u"ࠫࡂ࠭婕")+l111lll1l11l_l1_
				l11l11ll1l1l_l1_.append(dict)
	for dict in l11l11ll1l1l_l1_:
		l1l1111_l1_,l1111l1l1ll1_l1_,l1111l1ll1l1_l1_,l11lllll1_l1_,codecs,l111ll11111_l1_ = l11lll_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭婖"),l11lll_l1_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ婗"),l11lll_l1_ (u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ婘"),l11lll_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ婙"),l11lll_l1_ (u"ࠩࠪ婚"),l11lll_l1_ (u"ࠪ࠴ࠬ婛")
		try:
			l11l11ll1ll1_l1_ = dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦࠩ婜")]
			l11l11ll1ll1_l1_ = l11l11ll1ll1_l1_.replace(l11lll_l1_ (u"ࠬ࠱ࠧ婝"),l11lll_l1_ (u"࠭ࠧ婞"))
			items = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࡀ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ婟"),l11l11ll1ll1_l1_,re.DOTALL)
			l11lllll1_l1_,l1l1111_l1_,codecs = items[0]
			l11l1ll1ll1l_l1_ = codecs.split(l11lll_l1_ (u"ࠨ࠮ࠪ婠"))
			l1111l1l1ll1_l1_ = l11lll_l1_ (u"ࠩࠪ婡")
			for item in l11l1ll1ll1l_l1_: l1111l1l1ll1_l1_ += item.split(l11lll_l1_ (u"ࠪ࠲ࠬ婢"))[0]+l11lll_l1_ (u"ࠫ࠱࠭婣")
			l1111l1l1ll1_l1_ = l1111l1l1ll1_l1_.strip(l11lll_l1_ (u"ࠬ࠲ࠧ婤"))
			if l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ婥") in list(dict.keys()): l111ll11111_l1_ = str(float(dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ婦")]*10)//1024/10)+l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ婧")
			else: l111ll11111_l1_ = l11lll_l1_ (u"ࠩࠪ婨")
			if l11lllll1_l1_==l11lll_l1_ (u"ࠪࡸࡪࡾࡴࠨ婩"): continue
			elif l11lll_l1_ (u"ࠫ࠱࠭婪") in l11l11ll1ll1_l1_:
				l11lllll1_l1_ = l11lll_l1_ (u"ࠬࡇࠫࡗࠩ婫")
				l1111l1ll1l1_l1_ = l1l1111_l1_+l11lll_l1_ (u"࠭ࠠࠡࠩ婬")+l111ll11111_l1_+dict[l11lll_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ婭")].split(l11lll_l1_ (u"ࠨࡺࠪ婮"))[1]
			elif l11lllll1_l1_==l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ婯"):
				l11lllll1_l1_ = l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ婰")
				l1111l1ll1l1_l1_ = l111ll11111_l1_+dict[l11lll_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ婱")].split(l11lll_l1_ (u"ࠬࡾࠧ婲"))[1]+l11lll_l1_ (u"࠭ࠠࠡࠩ婳")+dict[l11lll_l1_ (u"ࠧࡧࡲࡶࠫ婴")]+l11lll_l1_ (u"ࠨࡨࡳࡷࠬ婵")+l11lll_l1_ (u"ࠩࠣࠤࠬ婶")+l1l1111_l1_
			elif l11lllll1_l1_==l11lll_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ婷"):
				l11lllll1_l1_ = l11lll_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ婸")
				l1111l1ll1l1_l1_ = l111ll11111_l1_+str(int(dict[l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩ婹")])/1000)+l11lll_l1_ (u"࠭࡫ࡩࡼࠣࠤࠬ婺")+dict[l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ婻")]+l11lll_l1_ (u"ࠨࡥ࡫ࠫ婼")+l11lll_l1_ (u"ࠩࠣࠤࠬ婽")+l1l1111_l1_
		except:
			l1lll1lll1ll_l1_ = traceback.format_exc()
			sys.stderr.write(l1lll1lll1ll_l1_)
		if l11lll_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ婾") in dict[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ婿")]: l1l111l1ll_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ媀")].split(l11lll_l1_ (u"࠭ࡤࡶࡴࡀࠫ媁"),1)[1].split(l11lll_l1_ (u"ࠧࠧࠩ媂"),1)[0]))
		elif l11lll_l1_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ媃") in list(dict.keys()): l1l111l1ll_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ媄")])/1000)
		else: l1l111l1ll_l1_ = l11lll_l1_ (u"ࠪ࠴ࠬ媅")
		if l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ媆") not in list(dict.keys()): l111ll11111_l1_ = dict[l11lll_l1_ (u"ࠬࡹࡩࡻࡧࠪ媇")].split(l11lll_l1_ (u"࠭ࡸࠨ媈"))[1]
		else: l111ll11111_l1_ = dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ媉")]
		if l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭媊") not in list(dict.keys()): dict[l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ媋")] = l11lll_l1_ (u"ࠪ࠴࠲࠶ࠧ媌")
		dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ媍")] = l11lllll1_l1_+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ媎")+l1111l1ll1l1_l1_+l11lll_l1_ (u"࠭ࠠࠡࠪࠪ媏")+l1111l1l1ll1_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ媐")+dict[l11lll_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭媑")]+l11lll_l1_ (u"ࠩࠬࠫ媒")
		dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ媓")] = l1111l1ll1l1_l1_.split(l11lll_l1_ (u"ࠫࠥࠦࠧ媔"))[0].split(l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠪ媕"))[0]
		dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ媖")] = l11lllll1_l1_
		dict[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ媗")] = l1l1111_l1_
		dict[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ媘")] = codecs
		dict[l11lll_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ媙")] = l1l111l1ll_l1_
		dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ媚")] = l111ll11111_l1_
		l11l11ll11ll_l1_.append(dict)
	l111llllll11_l1_,l11l1l1l1111_l1_,l11l1llllll1_l1_,l111l1ll1lll_l1_,l11l11l1111l_l1_ = [],[],[],[],[]
	l111l1l11l1l_l1_,l11l11llll11_l1_,l111l11l111l_l1_,l11l1ll1l1ll_l1_,l11l1llll11l_l1_ = [],[],[],[],[]
	if l111111ll1ll_l1_:
		dict = {}
		dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ媛")] = l11lll_l1_ (u"ࠬࡇࠫࡗࠩ媜")
		dict[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ媝")] = l11lll_l1_ (u"ࠧ࡮ࡲࡧࠫ媞")
		dict[l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ媟")] = dict[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ媠")]+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ媡")+dict[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭媢")]+l11lll_l1_ (u"ࠬࠦࠠࠨ媣")+l11lll_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ媤")
		dict[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ媥")] = l111111ll1ll_l1_
		dict[l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ媦")] = l11lll_l1_ (u"ࠩ࠳ࠫ媧") # for l11l1l111l_l1_ l111111ll1ll_l1_ any l1l1l111l_l1_ will l11l11l11lll_l1_ l1llll111ll_l1_ sort l1l11l1llll_l1_
		dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ媨")] = l11lll_l1_ (u"ࠫ࠾࠾࠷࠷࠷࠷࠷࠷࠷࠰ࠨ媩") # 20
		l11l11ll11ll_l1_.append(dict)
	if l11ll11111ll_l1_:
		l11l11l111l1_l1_,l11l1l11l111_l1_ = l11ll11l11_l1_(l11ll11111ll_l1_)
		l11l1l1lll1l_l1_ = list(zip(l11l11l111l1_l1_,l11l1l11l111_l1_))
		for title,link in l11l1l1lll1l_l1_:
			dict = {}
			dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ媪")] = l11lll_l1_ (u"࠭ࡁࠬࡘࠪ媫")
			dict[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ媬")] = l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭媭")
			dict[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭媮")] = link
			#if l11lll_l1_ (u"ࠪࡆ࡜ࡀࠠࠨ媯") in title: dict[l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ媰")] = title.split(l11lll_l1_ (u"ࠬࠦࠠࠨ媱"))[1].split(l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠫ媲"))[0]
			#if l11lll_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭媳") in title: dict[l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ媴")] = title.split(l11lll_l1_ (u"ࠩࡕࡩࡸࡀࠠࠨ媵"))[1]
			# title = l11lll_l1_ (u"ࠥ࠸࠷࠼࠷࡬ࡤࡳࡷࠥࠦ࠷࠳࠲ࠣࠤ࠳ࡳ࠳ࡶ࠺ࠥ媶")
			if l11lll_l1_ (u"ࠫࡰࡨࡰࡴࠩ媷") in title: dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭媸")] = title.split(l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠫ媹"))[0].rsplit(l11lll_l1_ (u"ࠧࠡࠢࠪ媺"))[-1]
			else: dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ媻")] = l11lll_l1_ (u"ࠩ࠴࠴ࠬ媼")
			if title.count(l11lll_l1_ (u"ࠪࠤࠥ࠭媽"))>1:
				l11l111l_l1_ = title.rsplit(l11lll_l1_ (u"ࠫࠥࠦࠧ媾"))[-3]
				if l11l111l_l1_.isdigit(): dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭媿")] = l11l111l_l1_
				else: dict[l11lll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ嫀")] = l11lll_l1_ (u"ࠧ࠱࠲࠳࠴ࠬ嫁")
			#dict[l11lll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ嫂")] = title
			if title==l11lll_l1_ (u"ࠩ࠰࠵ࠬ嫃"): dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ嫄")] = dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ嫅")]+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ嫆")+dict[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ嫇")]+l11lll_l1_ (u"ࠧࠡࠢࠪ嫈")+l11lll_l1_ (u"ࠨฮ๋ำฮࠦะไ์ฬࠫ嫉")
			else: dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ嫊")] = dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ嫋")]+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ嫌")+dict[l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ嫍")]+l11lll_l1_ (u"࠭ࠠࠡࠩ嫎")+dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ嫏")]+l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ嫐")+dict[l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ嫑")]
			l11l11ll11ll_l1_.append(dict)
	l11l11ll11ll_l1_ = sorted(l11l11ll11ll_l1_,reverse=True,key=lambda key: float(key[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ嫒")]))
	if not l11l11ll11ll_l1_:
		l1l1ll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡳࡴࡣࡪࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嫓"),html,re.DOTALL)
		l1l1ll11lll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀ࡜ࡼࠤࡵࡹࡳࡹࠢ࠻࡞࡞ࡠࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嫔"),html,re.DOTALL)
		l111llll1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嫕"),html,re.DOTALL)
		l111lllll111_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡸࡻࡢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ嫖"),html,re.DOTALL)
		try: l111lllll11l_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ嫗")][l11lll_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ嫘")][l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ嫙")][l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ嫚")][l11lll_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ嫛")][0][l11lll_l1_ (u"࠭ࡴࡦࡺࡷࠫ嫜")]
		except: l111lllll11l_l1_ = l11lll_l1_ (u"ࠧࠨ嫝")
		try: l111lllll1l1_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ嫞")][l11lll_l1_ (u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧ嫟")][l11lll_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫ嫠")][l11lll_l1_ (u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬ嫡")][0][l11lll_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ嫢")][0][l11lll_l1_ (u"࠭ࡴࡦࡺࡷࠫ嫣")]
		except: l111lllll1l1_l1_ = l11lll_l1_ (u"ࠧࠨ嫤")
		try: l1111ll1ll11_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬ嫥")][l11lll_l1_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩ嫦")]
		except: l1111ll1ll11_l1_ = l11lll_l1_ (u"ࠪࠫ嫧")
		if l1l1ll11ll1_l1_ or l1l1ll11lll_l1_ or l111llll1lll_l1_ or l111lllll111_l1_ or l111lllll11l_l1_ or l111lllll1l1_l1_ or l1111ll1ll11_l1_:
			if   l1l1ll11ll1_l1_: message = l1l1ll11ll1_l1_[0]
			elif l1l1ll11lll_l1_: message = l1l1ll11lll_l1_[0]
			elif l111llll1lll_l1_: message = l111llll1lll_l1_[0]
			elif l111lllll111_l1_: message = l111lllll111_l1_[0]
			elif l111lllll11l_l1_: message = l111lllll11l_l1_
			elif l111lllll1l1_l1_: message = l111lllll1l1_l1_
			elif l1111ll1ll11_l1_: message = l1111ll1ll11_l1_
			l111l1111ll1_l1_ = message.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ嫨"),l11lll_l1_ (u"ࠬ࠭嫩")).strip(l11lll_l1_ (u"࠭ࠠࠨ嫪"))
			l11l111l1l1l_l1_ = l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊ิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ嫫")
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ嫬"),l11lll_l1_ (u"ࠩࠪ嫭"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧ嫮"),l11l111l1l1l_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ嫯")+l111l1111ll1_l1_)
			return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧ嫰")+l111l1111ll1_l1_,[],[]
		else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭嫱"),[],[]
	l1111ll1lll1_l1_,l1111111l11l_l1_,l111lll11l1l_l1_ = [],[],[]
	for dict in l11l11ll11ll_l1_:
		if dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭嫲")]==l11lll_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ嫳"):
			l111llllll11_l1_.append(dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ嫴")])
			l111l1l11l1l_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ嫵")]==l11lll_l1_ (u"ࠫࡆࡻࡤࡪࡱࠪ嫶"):
			l11l1l1l1111_l1_.append(dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ嫷")])
			l11l11llll11_l1_.append(dict)
		elif dict[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ嫸")]==l11lll_l1_ (u"ࠧ࡮ࡲࡧࠫ嫹"):
			title = dict[l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ嫺")].replace(l11lll_l1_ (u"ࠩࡄ࠯࡛ࡀࠠࠡࠩ嫻"),l11lll_l1_ (u"ࠪࠫ嫼"))
			if l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ嫽") not in list(dict.keys()): l111ll11111_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ嫾")
			else: l111ll11111_l1_ = dict[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ嫿")]
			l1111ll1lll1_l1_.append([dict,{},title,l111ll11111_l1_])
		else:
			title = dict[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭嬀")].replace(l11lll_l1_ (u"ࠨࡃ࠮࡚࠿ࠦࠠࠨ嬁"),l11lll_l1_ (u"ࠩࠪ嬂"))
			if l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ嬃") not in list(dict.keys()): l111ll11111_l1_ = l11lll_l1_ (u"ࠫ࠵࠭嬄")
			else: l111ll11111_l1_ = dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭嬅")]
			l1111ll1lll1_l1_.append([dict,{},title,l111ll11111_l1_])
			l11l1llllll1_l1_.append(title)
			l111l11l111l_l1_.append(dict)
		l11l1ll11111_l1_ = True
		if l11lll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭嬆") in list(dict.keys()):
			if l11lll_l1_ (u"ࠧࡢࡸ࠳ࠫ嬇") in dict[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ嬈")]: l11l1ll11111_l1_ = False
			elif kodi_version<18:
				if l11lll_l1_ (u"ࠩࡤࡺࡨ࠭嬉") not in dict[l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ嬊")] and l11lll_l1_ (u"ࠫࡲࡶ࠴ࡢࠩ嬋") not in dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ嬌")]: l11l1ll11111_l1_ = False
		if dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ嬍")]==l11lll_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭嬎") and dict[l11lll_l1_ (u"ࠨ࡫ࡱ࡭ࡹ࠭嬏")]!=l11lll_l1_ (u"ࠩ࠳࠱࠵࠭嬐") and l11l1ll11111_l1_==True:
			l11l11l1111l_l1_.append(dict[l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ嬑")])
			l11l1llll11l_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ嬒")]==l11lll_l1_ (u"ࠬࡇࡵࡥ࡫ࡲࠫ嬓") and dict[l11lll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ嬔")]!=l11lll_l1_ (u"ࠧ࠱࠯࠳ࠫ嬕") and l11l1ll11111_l1_==True:
			l111l1ll1lll_l1_.append(dict[l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ嬖")])
			l11l1ll1l1ll_l1_.append(dict)
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ嬗"),l11lll_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ嬘")+dict[l11lll_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ嬙")])
	for l11l1l1l1lll_l1_ in l11l1ll1l1ll_l1_:
		l111l1lll1l1_l1_ = l11l1l1l1lll_l1_[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭嬚")]
		for l111llll11l1_l1_ in l11l1llll11l_l1_:
			l1111l1lll1l_l1_ = l111llll11l1_l1_[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ嬛")]
			l111ll11111_l1_ = l1111l1lll1l_l1_+l111l1lll1l1_l1_
			title = l111llll11l1_l1_[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭嬜")].replace(l11lll_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ嬝"),l11lll_l1_ (u"ࠩࡰࡴࡩࠦࠠࠨ嬞"))
			title = title.replace(l111llll11l1_l1_[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ嬟")]+l11lll_l1_ (u"ࠫࠥࠦࠧ嬠"),l11lll_l1_ (u"ࠬ࠭嬡"))
			title = title.replace(str((float(l1111l1lll1l_l1_*10)//1024/10))+l11lll_l1_ (u"࠭࡫ࡣࡲࡶࠫ嬢"),str((float(l111ll11111_l1_*10)//1024/10))+l11lll_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ嬣"))
			title = title+l11lll_l1_ (u"ࠨࠪࠪ嬤")+l11l1l1l1lll_l1_[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ嬥")].split(l11lll_l1_ (u"ࠪࠬࠬ嬦"),1)[1]
			l1111ll1lll1_l1_.append([l111llll11l1_l1_,l11l1l1l1lll_l1_,title,l111ll11111_l1_])
	l1111ll1lll1_l1_ = sorted(l1111ll1lll1_l1_, reverse=True, key=lambda key: float(key[3]))
	for l111llll11l1_l1_,l11l1l1l1lll_l1_,title,l111ll11111_l1_ in l1111ll1lll1_l1_:
		l11l11ll1111_l1_ = l111llll11l1_l1_[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭嬧")]
		if l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ嬨") in list(l11l1l1l1lll_l1_.keys()):
			l11l11ll1111_l1_ = l11lll_l1_ (u"࠭࡭ࡱࡦࠪ嬩")
			#l11l11ll1111_l1_ = l11l11ll1111_l1_+l11l1l1l1lll_l1_[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ嬪")]
		if l11l11ll1111_l1_ not in l111lll11l1l_l1_:
			l111lll11l1l_l1_.append(l11l11ll1111_l1_)
			l1111111l11l_l1_.append([l111llll11l1_l1_,l11l1l1l1lll_l1_,title,l111ll11111_l1_])
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ嬫"),str(l111ll11111_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭嬬")+title)
	#l1111111l11l_l1_ = sorted(l1111111l11l_l1_, reverse=True, key=lambda key: int(key[3]))
	l1111ll1l1ll_l1_,l111l1l1llll_l1_,shift = [],[],0
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡰࡹࡱࡩࡷࠨ࠺࠯ࠬࡂࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶ࠿ࠐࠉࠊࡵ࡫࡭࡫ࡺࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ࠫࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠳ࡡ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠱࡞ࠌࠌࠍࡸ࡫࡬ࡦࡥࡷࡑࡪࡴࡵ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡧ࡭ࡵࡩࡤࡧࡐࡩࡳࡻ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ嬭")
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊࡱࡺࡲࡪࡸ࡟ࡤࡪࡤࡲࡳ࡫࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲ࡟࡫ࡵࡲࡲ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡸࡸ࡭ࡵࡲࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮ࡢ࡮ࡸࡵ࡮࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡲࡻࡳ࡫ࡲࡠࡰࡤࡱࡪࡀࠊࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡡ࡭࡮ࡲࡻࡗࡧࡴࡪࡰࡪࡷࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࠍ࡮ࡳࡡࡨࡧࡶࡣࡺࡸ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡭ࡲࡧࡧࡦࡵࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡩࡧࠢ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࡀࠠࡪ࡯ࡤ࡫ࡪࠦ࠽ࠡ࡫ࡰࡥ࡬࡫ࡳࡠࡷࡵࡰࡠ࠳࠱࡞ࠌࠌࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡵࡷ࡯ࡧࡵࡣࡳࡧ࡭ࡦ࡝࠳ࡡࠏࠏࠉࡴࡪ࡬ࡪࡹࠦࠫ࠾ࠢ࠴ࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ࠱࡯ࡸࡰࡨࡶ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡜ࡋࡂࡔࡋࡗࡉࡘࡡ࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ࡟࡞࠴ࡢ࠱ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ࠯ࡴࡽ࡮ࡦࡴࡢࡧ࡭ࡧ࡮࡯ࡧ࡯࡟࠵ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ嬮")
	l11l1ll111l1_l1_,l11l11l1l11l_l1_ = l11lll_l1_ (u"ࠬ࠭嬯"),l11lll_l1_ (u"࠭ࠧ嬰")
	try: l11l1ll111l1_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭嬱")][l11lll_l1_ (u"ࠨࡣࡸࡸ࡭ࡵࡲࠨ嬲")]
	except: l11l1ll111l1_l1_ = l11lll_l1_ (u"ࠩࠪ嬳")
	try: l111l1111lll_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ嬴")][l11lll_l1_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡎࡪࠧ嬵")]
	except: l111l1111lll_l1_ = l11lll_l1_ (u"ࠬ࠭嬶")
	if l11l1ll111l1_l1_ and l111l1111lll_l1_:
		shift += 1
		title = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ嬷")+l11l1ll111l1_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ嬸")
		link = l1ll11l_l1_[l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ嬹")][0]+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ嬺")+l111l1111lll_l1_
		l1111ll1l1ll_l1_.append(title)
		l111l1l1llll_l1_.append(link)
		try: l11l11l1l11l_l1_ = l1111l1l1l1l_l1_[l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩ嬻")][l11lll_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ嬼")][l11lll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩ嬽")][-1][l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ嬾")]
		except: pass
	#if l111111ll1ll_l1_:
	#	shift += 1
	#	l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ࠧ࡮ࡲࡧࠤั๎ฯสࠢำ็๏ฯࠧ嬿")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠨࡦࡤࡷ࡭࠭孀"))
	for l111llll11l1_l1_,l11l1l1l1lll_l1_,title,l111ll11111_l1_ in l1111111l11l_l1_:
		l1111ll1l1ll_l1_.append(title) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ孁"))
	if l11l1llllll1_l1_: l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ孂")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ孃"))
	if l1111ll1lll1_l1_: l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ孄")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪ孅"))
	if l11l11l1111l_l1_: l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ孆")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ孇"))
	if l111llllll11_l1_: l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ孈")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ孉"))
	if l11l1l1l1111_l1_: l1111ll1l1ll_l1_.append(l11lll_l1_ (u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ孊")) ; l111l1l1llll_l1_.append(l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ孋"))
	l11ll1111111_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1llllllllll1_l1_, l1111ll1l1ll_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ孌"),[],[]
		elif l1l_l1_==0 and l11l1ll111l1_l1_:
			link = l111l1l1llll_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11lll_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ孍")+QUOTE(l11l1ll111l1_l1_)+l11lll_l1_ (u"ࠨࠨࡸࡶࡱࡃࠧ孎")+link
			if l11l11l1l11l_l1_: new_path = new_path+l11lll_l1_ (u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ孏")+QUOTE(l11l11l1l11l_l1_)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ子")+new_path+l11lll_l1_ (u"ࠦ࠮ࠨ孑"))
			return l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ孒"),[],[]
		choice = l111l1l1llll_l1_[l1l_l1_]
		l1111l1111l1_l1_ = l1111ll1l1ll_l1_[l1l_l1_]
		if choice==l11lll_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ孓"):
			l11111l1ll11_l1_ = l111111ll1ll_l1_
			break
		elif choice in [l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭孔"),l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ孕"),l11lll_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ孖")]:
			if choice==l11lll_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ字"): l1lll1ll_l1_,l111l11l1ll1_l1_ = l11l1llllll1_l1_,l111l11l111l_l1_
			elif choice==l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ存"): l1lll1ll_l1_,l111l11l1ll1_l1_ = l111llllll11_l1_,l111l1l11l1l_l1_
			elif choice==l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ孙"): l1lll1ll_l1_,l111l11l1ll1_l1_ = l11l1l1l1111_l1_,l11l11llll11_l1_
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ孚"), l1lll1ll_l1_)
			if l1l_l1_!=-1:
				l11111l1ll11_l1_ = l111l11l1ll1_l1_[l1l_l1_][l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ孛")]
				l1111l1111l1_l1_ = l1lll1ll_l1_[l1l_l1_]
				break
		elif choice==l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ孜"):
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอ࠿࠭孝"), l11l11l1111l_l1_)
			if l1l_l1_!=-1:
				l1111l1111l1_l1_ = l11l11l1111l_l1_[l1l_l1_]
				l11l11l1l1l1_l1_ = l11l1llll11l_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ฮ࠿࠭孞"), l111l1ll1lll_l1_)
				if l1l_l1_!=-1:
					l1111l1111l1_l1_ += l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ孟")+l111l1ll1lll_l1_[l1l_l1_]
					l111llll1111_l1_ = l11l1ll1l1ll_l1_[l1l_l1_]
					l11ll1111111_l1_ = True
					break
		elif choice==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ孠"):
			l11l1l111l11_l1_,l111ll111111_l1_,l1111111lll1_l1_,l11l111l111l_l1_ = list(zip(*l1111ll1lll1_l1_))
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ孡"), l1111111lll1_l1_)
			if l1l_l1_!=-1:
				l1111l1111l1_l1_ = l1111111lll1_l1_[l1l_l1_]
				l11l11l1l1l1_l1_ = l11l1l111l11_l1_[l1l_l1_]
				if l11lll_l1_ (u"ࠧ࡮ࡲࡧࠫ孢") in l1111111lll1_l1_[l1l_l1_] and l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ季")]!=l111111ll1ll_l1_:
					l111llll1111_l1_ = l111ll111111_l1_[l1l_l1_]
					l11ll1111111_l1_ = True
				else: l11111l1ll11_l1_ = l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭孤")]
				break
		elif choice==l11lll_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ孥"):
			#shift += 1
			l11l1l111l11_l1_,l111ll111111_l1_,l1111111lll1_l1_,l11l111l111l_l1_ = list(zip(*l1111111l11l_l1_))
			l11l11l1l1l1_l1_ = l11l1l111l11_l1_[l1l_l1_-shift]
			if l11lll_l1_ (u"ࠫࡲࡶࡤࠨ学") in l1111111lll1_l1_[l1l_l1_-shift] and l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ孧")]!=l111111ll1ll_l1_:
				l111llll1111_l1_ = l111ll111111_l1_[l1l_l1_-shift]
				l11ll1111111_l1_ = True
			else: l11111l1ll11_l1_ = l11l11l1l1l1_l1_[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ孨")]
			l1111l1111l1_l1_ = l1111111lll1_l1_[l1l_l1_-shift]
			break
	if not l11ll1111111_l1_: l11111l11lll_l1_ = l11111l1ll11_l1_
	else: l11111l11lll_l1_ = l11lll_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠨ孩")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ孪")]+l11lll_l1_ (u"ࠩࠣ࠯ࠥࡇࡵࡥ࡫ࡲ࠾ࠥ࠭孫")+l111llll1111_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ孬")]
	if l11ll1111111_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ孭"),l11lll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ孮")+str(l11l11l1l1l1_l1_))
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ孯"),l11lll_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ孰")+str(l111llll1111_l1_))
		#if l11l1lll1lll_l1_>l111lll11111_l1_: l1l111l1ll_l1_ = str(l11l1lll1lll_l1_)
		#else: l1l111l1ll_l1_ = str(l111lll11111_l1_)
		#l1l111l1ll_l1_ = str(l11l1lll1lll_l1_) if l11l1lll1lll_l1_>l111lll11111_l1_ else str(l111lll11111_l1_)
		l11l1lll1lll_l1_ = int(l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ孱")])
		l111lll11111_l1_ = int(l111llll1111_l1_[l11lll_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ孲")])
		l1l111l1ll_l1_ = str(max(l11l1lll1lll_l1_,l111lll11111_l1_))
		l111ll1l1111_l1_ = l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ孳")].replace(l11lll_l1_ (u"ࠫࠫ࠭孴"),l11lll_l1_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫ孵"))		# +l11lll_l1_ (u"࠭ࠦࡳࡣࡱ࡫ࡪࡃ࠰࠮࠳࠳࠴࠵࠶࠰࠱࠲ࠪ孶")
		l11l1l1l111l_l1_ = l111llll1111_l1_[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ孷")].replace(l11lll_l1_ (u"ࠨࠨࠪ學"),l11lll_l1_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ孹"))		# +l11lll_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠰࠱࠲࠳࠴࠵࠶ࠧ孺")
		l11l1lllll1l_l1_ = l11lll_l1_ (u"ࠫࡁࡅࡸ࡮࡮ࠣࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠷࠮࠱ࠤࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࡂࠨࡕࡕࡈ࠰࠼ࠧࡅ࠾࡝ࡰࠪ孻")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠬࡂࡍࡑࡆࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡷ࡮ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠷࠶࠰࠲࠱࡛ࡑࡑ࡙ࡣࡩࡧࡰࡥ࠲࡯࡮ࡴࡶࡤࡲࡨ࡫ࠢࠡࡺࡰࡰࡳࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠥࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡱ࡯࡮࡬࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠲࠻࠼࠽࠴ࡾ࡬ࡪࡰ࡮ࠦࠥࡾࡳࡪ࠼ࡶࡧ࡭࡫࡭ࡢࡎࡲࡧࡦࡺࡩࡰࡰࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠦࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡱࡨࡦࡸࡤࡴ࠰࡬ࡷࡴ࠴࡯ࡳࡩ࠲࡭ࡹࡺࡦ࠰ࡒࡸࡦࡱ࡯ࡣ࡭ࡻࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡘࡺࡡ࡯ࡦࡤࡶࡩࡹ࠯ࡎࡒࡈࡋ࠲ࡊࡁࡔࡊࡢࡷࡨ࡮ࡥ࡮ࡣࡢࡪ࡮ࡲࡥࡴ࠱ࡇࡅࡘࡎ࠭ࡎࡒࡇ࠲ࡽࡹࡤࠣࠢࡰ࡭ࡳࡈࡵࡧࡨࡨࡶ࡙࡯࡭ࡦ࠿ࠥࡔ࡙࠷࠮࠶ࡕࠥࠤࡲ࡫ࡤࡪࡣࡓࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࡅࡷࡵࡥࡹ࡯࡯࡯࠿ࠥࡔ࡙࠭孼")+l1l111l1ll_l1_+l11lll_l1_ (u"࠭ࡓࠣࠢࡷࡽࡵ࡫࠽ࠣࡵࡷࡥࡹ࡯ࡣࠣࠢࡳࡶࡴ࡬ࡩ࡭ࡧࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡶࡲࡰࡨ࡬ࡰࡪࡀࡩࡴࡱࡩࡪ࠲ࡳࡡࡪࡰ࠽࠶࠵࠷࠱ࠣࡀ࡟ࡲࠬ孽")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫ孾")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠰ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬ孿")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ宀")]+l11lll_l1_ (u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁࠧࡺࡲࡶࡧࠥࡂࡡࡴࠧ宁")		# l111lll11lll_l1_=l11lll_l1_ (u"ࠦ࠶ࠨ宂") l11l1llll1ll_l1_=l11lll_l1_ (u"ࠧࡺࡲࡶࡧࠥ它") default=l11lll_l1_ (u"ࠨࡴࡳࡷࡨࠦ宄")>\n
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬ宅")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨ宆")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ宇")]+l11lll_l1_ (u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧ守")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ安")]+l11lll_l1_ (u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨ宊")+str(l11l11l1l1l1_l1_[l11lll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ宋")])+l11lll_l1_ (u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪ完")+str(l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ宍")])+l11lll_l1_ (u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭宎")+str(l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ宏")])+l11lll_l1_ (u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫ宐")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠬ࡬ࡰࡴࠩ宑")]+l11lll_l1_ (u"࠭ࠢ࠿࡞ࡱࠫ宒")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ宓")+l111ll1l1111_l1_+l11lll_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ宔")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ宕")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ宖")]+l11lll_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ宗")	# l1111111l1l1_l1_=l11lll_l1_ (u"ࠧࡺࡲࡶࡧࠥ官")>\n
		l11l1lllll1l_l1_ += l11lll_l1_ (u"࠭࠼ࡊࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡤࡸ࡮ࡵ࡮ࠡࡴࡤࡲ࡬࡫࠽ࠣࠩ宙")+l11l11l1l1l1_l1_[l11lll_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ定")]+l11lll_l1_ (u"ࠨࠤࠣ࠳ࡃࡢ࡮ࠨ宛")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠩ࠿࠳ࡘ࡫ࡧ࡮ࡧࡱࡸࡇࡧࡳࡦࡀ࡟ࡲࠬ宜")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠪࡀ࠴ࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡄ࡜࡯ࠩ宝")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࡄ࡜࡯ࠩ实")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠵ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡤࡹࡩ࡯࡯࠰ࠩ実")+l111llll1111_l1_[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ宠")]+l11lll_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ审")		# l111lll11lll_l1_=l11lll_l1_ (u"ࠣ࠳ࠥ客") l11l1llll1ll_l1_=l11lll_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ宣") default=l11lll_l1_ (u"ࠥࡸࡷࡻࡥࠣ室")>\n
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ宥")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ宦")+l111llll1111_l1_[l11lll_l1_ (u"࠭ࡩࡵࡣࡪࠫ宧")]+l11lll_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ宨")+l111llll1111_l1_[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ宩")]+l11lll_l1_ (u"ࠩࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣ࠳࠶࠴࠹࠽࠵ࠣࡀ࡟ࡲࠬ宪")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠪࡀࡆࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻࠴࠶࠴࠵࠹࠺࠴࠼ࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠩ宫")+l111llll1111_l1_[l11lll_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ宬")]+l11lll_l1_ (u"ࠬࠨ࠯࠿࡞ࡱࠫ宭")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩ宮")+l11l1l1l111l_l1_+l11lll_l1_ (u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭宯")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭宰")+l111llll1111_l1_[l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ宱")]+l11lll_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ宲")	# l1111111l1l1_l1_=l11lll_l1_ (u"ࠦࡹࡸࡵࡦࠤ害")>\n
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ宴")+l111llll1111_l1_[l11lll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ宵")]+l11lll_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ家")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ宷")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ宸")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ容")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ宺")
		l11l1lllll1l_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴࠧ宻")
		#open(l11lll_l1_ (u"࠭ࡳ࠻࡞࡟ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ宼"),l11lll_l1_ (u"ࠧࡸࡤࠪ宽")).write(l11l1lllll1l_l1_)
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ宾"),l11l1lllll1l_l1_)
		#l11l1lllll1l_l1_ = OPENURL_CACHED(NO_CACHE,l111111ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ宿"),l11lll_l1_ (u"ࠪࠫ寀"),l11lll_l1_ (u"ࠫࠬ寁"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠼ࡸ࡭࠭寂"))
		if kodi_version>18.99:
			import http.server as l11l11111l1l_l1_
			import http.client as l1111ll1l1l1_l1_
		else:
			import BaseHTTPServer as l11l11111l1l_l1_
			import httplib as l1111ll1l1l1_l1_
		class l11111llll1l_l1_(l11l11111l1l_l1_.HTTPServer):
			#l11l1lllll1l_l1_ = l11lll_l1_ (u"࠭࠼࠿ࠩ寃")
			def __init__(self,l1l1ll11l1l1_l1_=l11lll_l1_ (u"ࠧ࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶࠪ寄"),port=55055,l11l1lllll1l_l1_=l11lll_l1_ (u"ࠨ࠾ࡁࠫ寅")):
				self.l1l1ll11l1l1_l1_ = l1l1ll11l1l1_l1_
				self.port = port
				self.l11l1lllll1l_l1_ = l11l1lllll1l_l1_
				l11l11111l1l_l1_.HTTPServer.__init__(self,(self.l1l1ll11l1l1_l1_,self.port),l111l1ll11l1_l1_)
				self.l11111ll1l1l_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪ密")+l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠪ࠾ࠬ寇")+str(port)+l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ寈")
				#print(l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡷࡳࠤࡳࡵࡷࠡ࡮࡬ࡷࡹ࡫࡮ࡪࡰࡪࠤࡴࡴࠠࡱࡱࡵࡸ࠿ࠦࠧ寉")+str(port))
			def start(self):
				self.threads = l11111lllll_l1_(False)
				self.threads.start_new_thread(1,self.l111ll1ll1l1_l1_)
			def l111ll1ll1l1_l1_(self):
				#print(l11lll_l1_ (u"࠭ࡳࡦࡴࡹ࡭ࡳ࡭ࠠࡳࡧࡴࡹࡪࡹࡴࡴࠢࡶࡸࡦࡸࡴࡦࡦࠪ寊"))
				self.l11111111l1l_l1_ = True
				#l1l11ll111l_l1_ = 0
				while self.l11111111l1l_l1_:
					#l1l11ll111l_l1_ += 1
					#print(l11lll_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠡࡣࠣࡷ࡮ࡴࡧ࡭ࡧࠣ࡬ࡦࡴࡤ࡭ࡧࡢࡶࡪࡷࡵࡦࡵࡷࠬ࠮ࠦ࡮ࡰࡹ࠽ࠤࠬ寋")+str(l1l11ll111l_l1_)+l11lll_l1_ (u"ࠨࠩ富"))
					#settimeout l1111ll1l1_l1_ not l111l11lll_l1_ l111l1111111_l1_ to error message if it l1111l1l11ll_l1_ l111111l1l11_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111ll1ll1l1_l1_ l111lll11l11_l1_ request l11111l1lll1_l1_ 60 seconds)
					self.handle_request()
				#print(l11lll_l1_ (u"ࠩࡶࡩࡷࡼࡩ࡯ࡩࠣࡶࡪࡷࡵࡦࡵࡷࡷࠥࡹࡴࡰࡲࡳࡩࡩࡢ࡮ࠨ寍"))
			def stop(self):
				self.l11111111l1l_l1_ = False
				self.l111llll11ll_l1_()	# needed to l11l1ll1lll1_l1_ self.handle_request() to l111ll1ll1l1_l1_ l1lllllll11l_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11lll_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡤࡰࡹࡱࠤࡳࡵࡷ࡝ࡰࠪ寎"))
			def load(self,l11l1lllll1l_l1_):
				self.l11l1lllll1l_l1_ = l11l1lllll1l_l1_
			def l111llll11ll_l1_(self):
				conn = l1111ll1l1l1_l1_.HTTPConnection(self.l1l1ll11l1l1_l1_+l11lll_l1_ (u"ࠫ࠿࠭寏")+str(self.port))
				conn.request(l11lll_l1_ (u"ࠧࡎࡅࡂࡆࠥ寐"), l11lll_l1_ (u"ࠨ࠯ࠣ寑"))
		class l111l1ll11l1_l1_(l11l11111l1l_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11lll_l1_ (u"ࠧࡥࡱ࡬ࡲ࡬ࠦࡇࡆࡖࠣࠤࠬ寒")+self.path)
				self.send_response(200)
				self.send_header(l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ寓"),l11lll_l1_ (u"ࠩࡷࡩࡽࡺ࠯ࡱ࡮ࡤ࡭ࡳ࠭寔"))
				self.end_headers()
				#self.wfile.write(self.path+l11lll_l1_ (u"ࠪࡠࡳ࠭寕"))
				self.wfile.write(self.server.l11l1lllll1l_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ寖")))
				time.sleep(1)
				if self.path==l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ寗"): self.server.shutdown()
				if self.path==l11lll_l1_ (u"࠭࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ寘"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11lll_l1_ (u"ࠧࡥࡱ࡬ࡲ࡬ࠦࡈࡆࡃࡇࠤࠥ࠭寙")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l11111llll1l_l1_(l11lll_l1_ (u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫ寚"),55055,l11l1lllll1l_l1_)
		#httpd.load(l11l1lllll1l_l1_)
		l11111l1ll11_l1_ = httpd.l11111ll1l1l_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l11111l1ll11_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡰ࡮ࡼࡥࡴ࡫ࡰ࠲ࡩࡧࡳࡩ࡫ࡩ࠲ࡴࡸࡧ࠰࡮࡬ࡺࡪࡹࡩ࡮࠱ࡦ࡬ࡺࡴ࡫ࡥࡷࡵࡣ࠶࠵ࡡࡵࡱࡢ࠻࠴ࡺࡥࡴࡶࡳ࡭ࡨ࠺࡟࠹ࡵ࠲ࡑࡦࡴࡩࡧࡧࡶࡸ࠳ࡳࡰࡥࠩ寛")
		#l11111l1ll11_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡧࡳࡩ࠰ࡤ࡯ࡦࡳࡡࡪࡼࡨࡨ࠳ࡴࡥࡵ࠱ࡧࡥࡸ࡮࠲࠷࠶࠲ࡘࡪࡹࡴࡄࡣࡶࡩࡸ࠵࠲ࡤ࠱ࡴࡹࡦࡲࡣࡰ࡯ࡰ࠳࠶࠵ࡍࡶ࡮ࡷ࡭ࡗ࡫ࡳࡎࡒࡈࡋ࠷࠴࡭ࡱࡦࠪ寜")
		#l11111l1ll11_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡴ࡫࠱ࡸࡪࡲࡥࡤࡱࡰ࠱ࡵࡧࡲࡪࡵࡷࡩࡨ࡮࠮ࡧࡴ࠲࡫ࡵࡧࡣ࠰ࡆࡄࡗࡍࡥࡃࡐࡐࡉࡓࡗࡓࡁࡏࡅࡈ࠳࡙࡫࡬ࡦࡥࡲࡱࡕࡧࡲࡪࡵࡗࡩࡨ࡮࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠱ࡰࡴ࠹࠳࡬ࡪࡸࡨ࠱ࡲࡶࡤ࠮ࡃ࡙࠱ࡇ࡙࠮࡮ࡲࡧࠫ寝")
		#l11111l1ll11_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡸࡤ࡮ࡧࡧ࡭ࡦ࠴ࡢࡣࡥ࠱ࡧࡴ࠴ࡵ࡬࠱ࡧࡥࡸ࡮࠯ࡰࡰࡧࡩࡲࡧ࡮ࡥ࠱ࡷࡩࡸࡺࡣࡢࡴࡧ࠳࠶࠵ࡣ࡭࡫ࡨࡲࡹࡥ࡭ࡢࡰ࡬ࡪࡪࡹࡴ࠮ࡧࡹࡩࡳࡺࡳ࠮࡯ࡸࡰࡹ࡯࡬ࡢࡰࡪ࠲ࡲࡶࡤࠨ寞")
		#l11111l1ll11_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵ࠼࠸࠹࠵࠻࠵࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭察")
	else: httpd = l11lll_l1_ (u"ࠧࠨ寠")
	if not l11111l1ll11_l1_: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ寡"),[],[]
	return l11lll_l1_ (u"ࠩࠪ寢"),[l11lll_l1_ (u"ࠪࠫ寣")],[[l11111l1ll11_l1_,l111ll111lll_l1_,httpd]]
def l111l11111ll_l1_(url):
	# https://l11l1ll11lll_l1_.com/l111l1l11l11_l1_
	headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ寤") : l11lll_l1_ (u"ࠬ࠭寥") }
	#url = url.replace(l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ實"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ寧"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ寨"),headers,l11lll_l1_ (u"ࠩࠪ審"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡅࡓࡇ࠳࠱ࡴࡶࠪ寪"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࢀ࠮ࡢࡽࠨ寫"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11l11l111l1_l1_,l1lll1ll_l1_,l11l1l11l111_l1_,l1111_l1_ = [],[],[],[]
	if items:
		for link,dummy,l1ll111llll1_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ寬"),l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ寭"))
			if l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭寮") in link:
				l11l11l111l1_l1_,l11l1l11l111_l1_ = l11ll11l11_l1_(link)
				#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ寯"),l11lll_l1_ (u"ࠩࠪ寰"),str(l1111_l1_),str(l11l1l11l111_l1_))
				l1111_l1_ = l1111_l1_ + l11l1l11l111_l1_
				if l11l11l111l1_l1_[0]==l11lll_l1_ (u"ࠪ࠱࠶࠭寱"): l1lll1ll_l1_.append(l11lll_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ寲")+l11lll_l1_ (u"ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭寳"))
				else:
					for title in l11l11l111l1_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ寴")+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ寵")+title)
			else:
				title = l11lll_l1_ (u"ࠨีํีๆืࠠฯษุࠫ寶")+l11lll_l1_ (u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬ寷")+l1ll111llll1_l1_
				l1111_l1_.append(link)
				l1lll1ll_l1_.append(title)
		return l11lll_l1_ (u"ࠪࠫ寸"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡅࡓࡇ࠭对"),[],[]
def l111111lll1l_l1_(url):
	# https://l11l1lll111l_l1_.cc/l1l11llll_l1_-1qrpoobdg7bu.html
	# https://l111lll1lll1_l1_.cc//l1l11llll_l1_-l11l111l11l1_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ寺"),url,l11lll_l1_ (u"࠭ࠧ寻"),l11lll_l1_ (u"ࠧࠨ导"),l11lll_l1_ (u"ࠨࠩ寽"),l11lll_l1_ (u"ࠩࠪ対"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡗࡋࡇࡉࡔ࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ寿"))
	html = response.content
	links = re.findall(l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ尀"),html,re.DOTALL)
	if links:
		link = links[0]
		return l11lll_l1_ (u"ࠬ࠭封"),[l11lll_l1_ (u"࠭ࠧ専")],[link]
	return l11lll_l1_ (u"ࠧࠨ尃"),[],[]
def l11111l11l1l_l1_(url):
	# https://l11111l11l11_l1_.in/l1111l1l1lll_l1_
	# https://l11111l11l11_l1_.in/l1l11llll_l1_-l1111l1l1lll_l1_.html
	# https://l11l1111l1l1_l1_.l1111lll11ll_l1_/l11l1l1llll1_l1_
	# https://l11l1111l1l1_l1_.l1111lll11ll_l1_/l1l11llll_l1_-l11l1l1llll1_l1_.html
	# https://www.l11l1ll11l11_l1_.com/l1l11llll_l1_-l111l1llll11_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ射"),l11lll_l1_ (u"ࠩࠪ尅")).replace(l11lll_l1_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩ将"),l11lll_l1_ (u"ࠫࠬ將"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ專"),url,l11lll_l1_ (u"࠭ࠧ尉"),l11lll_l1_ (u"ࠧࠨ尊"),l11lll_l1_ (u"ࠨࠩ尋"),l11lll_l1_ (u"ࠩࠪ尌"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ對"))
	html = response.content
	l1ll11l11l11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࡨࡡ࠯࠮ࠫࡁ࡟࠭ࡡ࠯࡜ࠪࠫࠪ導"),html,re.DOTALL)
	if l1ll11l11l11_l1_:
		l1ll11l11l11_l1_ = l1ll11l11l11_l1_[0]
		l1l1l1l1l111_l1_ = l1l1ll1l111l_l1_(l1ll11l11l11_l1_)
		links = re.findall(l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ小"),l1l1l1l1l111_l1_,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠯ࡽࠨ尐"),l1l1l1l1l111_l1_,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link,title in links:
			if not title: title = link.rsplit(l11lll_l1_ (u"ࠧ࠯ࠩ少"),1)[1]
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		return l11lll_l1_ (u"ࠨࠩ尒"),l1lll1ll_l1_,l1111_l1_
	id = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ尓"))[3]
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ尔"):l11lll_l1_ (u"ࠫࠬ尕") , l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ尖"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ尗") }
	payload = { l11lll_l1_ (u"ࠧࡪࡦࠪ尘"):id , l11lll_l1_ (u"ࠨࡱࡳࠫ尙"):l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬ尚") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ尛"),url,payload,headers,l11lll_l1_ (u"ࠫࠬ尜"),l11lll_l1_ (u"ࠬ࠭尝"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬ尞"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭尟"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠨࠩ尠"),[l11lll_l1_ (u"ࠩࠪ尡")],[ items[0] ]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡞ࡆࡊࡎࡈࡗࡍࡇࡒࡊࡐࡊࠫ尢"),[],[]
l11lll_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡌࡕࡖࡊࡆࠫࡹࡷࡲࠩ࠻ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡰࡸ࡬ࡨ࠳ࡩ࡯࠰ࡸ࡬ࡨࡪࡵ࠯ࡱ࡮ࡤࡽ࠴ࡇࡁࡗࡇࡑࡨࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࠣ࠾ࠥ࠭ࠧࠡࡿࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡘࡌࡈ࠲࠷ࡳࡵࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵ࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡ࠱ࡡ࡝ࠋࠋ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍ࡮࡬ࠠࠨ࠰ࡰ࠷ࡺ࠾ࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵ࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹ࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖࡷࡩࡲࡶ࡛࠱࡟ࡀࡁࠬ࠳࠱ࠨ࠼ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡ࡯࠶ࡹ࠽࠭ࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕࡶࡨࡱࡵࡀࠊࠊࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࠫ࠰ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ุࠣࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥࡳࡰ࠵ࠩࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࠩࠪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡍࡏࡗࡋࡇࠫ࠱ࡡ࡝࠭࡝ࡠࠎࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠴ࡱ࠳࡭࡯ࡷ࡫ࡧ࠲ࡨࡵ࠯ࡴࡶࡵࡩࡦࡳ࠯࠳࠴࠼࠲ࡲ࠹ࡵ࠹ࠌࠥࠦࠧ尣")
#####################################################
#    l11l1l1l1ll1_l1_ l111l1l1l1l1_l1_ l1111lll1ll1_l1_
#    16-06-2019
#####################################################
def l111l11lll1l_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭尤"),l11lll_l1_ (u"࠭ࠧ尥"),l11lll_l1_ (u"ࠧࠨ尦"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡎࡒࡅࡉ࡙࠭࠲ࡵࡷࠫ尧"))
	items = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ尨"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠪࠫ尩"),[l11lll_l1_ (u"ࠫࠬ尪")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪ尫"),[],[]
def l111l11l11l1_l1_(url):
	return l11lll_l1_ (u"࠭ࠧ尬"),[l11lll_l1_ (u"ࠧࠨ尭")],[ url ]
def l111l1l1ll11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ尮"),l11lll_l1_ (u"ࠩࠪ尯"),url,l11lll_l1_ (u"ࠪࠫ尰"))
	server = url.split(l11lll_l1_ (u"ࠫ࠴࠭就"))
	basename = l11lll_l1_ (u"ࠬ࠵ࠧ尲").join(server[0:3])
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ尳"),l11lll_l1_ (u"ࠧࠨ尴"),l11lll_l1_ (u"ࠨࠩ尵"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆ࠯࠴ࡷࡹ࠭尶"))
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡱࡨࡵࡵࡶࡲࡲࡡ࠭࡜ࠪ࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠣࡠ࠰ࠦ࡜ࠩࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪࠢ࡟࠯ࠥ࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࡢࠩࠡ࡞࠮ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ尷"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ尸"),l11lll_l1_ (u"ࠬ࠭尹"),url,str(var))
	if items:
		l11lll1l1ll1_l1_,l11llll111l1_l1_,l11llll111ll_l1_,l11l1111llll_l1_,l11l111l1111_l1_,l11l1111lll1_l1_ = items[0]
		var = int(l11llll111l1_l1_) % int(l11llll111ll_l1_) + int(l11l1111llll_l1_) % int(l11l111l1111_l1_)
		url = basename + l11lll1l1ll1_l1_ + str(var) + l11l1111lll1_l1_
		return l11lll_l1_ (u"࠭ࠧ尺"),[l11lll_l1_ (u"ࠧࠨ尻")],[url]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋࠧ尼"),[],[]
def l11l11111l11_l1_(url):
	url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ尽"),l11lll_l1_ (u"ࠪࠫ尾"))
	url = url.replace(l11lll_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ尿"),l11lll_l1_ (u"ࠬ࠭局"))
	id = url.split(l11lll_l1_ (u"࠭࠯ࠨ屁"))[-1]
	headers = { l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭层") : l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ屃") }
	payload = { l11lll_l1_ (u"ࠤ࡬ࡨࠧ屄"):id , l11lll_l1_ (u"ࠥࡳࡵࠨ居"):l11lll_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠢ屆") }
	request = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ屇"), url, payload, headers, l11lll_l1_ (u"࠭ࠧ屈"),l11lll_l1_ (u"ࠧࠨ屉"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡖ࠴ࡖࡒࡏࡓࡆࡊ࠭࠲ࡵࡷࠫ届"))
	if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ屋") in list(request.headers.keys()): link = request.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ屌")]
	else: link = url
	if link: return l11lll_l1_ (u"ࠫࠬ屍"),[l11lll_l1_ (u"ࠬ࠭屎")],[link]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡓ࠸࡚ࡖࡌࡐࡃࡇࠫ屏"),[],[]
def l1111ll11l11_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ屐"),l11lll_l1_ (u"ࠨࠩ屑"),l11lll_l1_ (u"ࠩࠪ屒"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡊࡐࡗ࡚ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭屓"))
	items = re.findall(l11lll_l1_ (u"ࠫࡲࡶ࠴࠻ࠢ࡟࡟ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ屔"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠬ࠭展"),[l11lll_l1_ (u"࠭ࠧ屖")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡍࡓ࡚ࡖࡍࡋ࡙ࡉࠬ屗"),[],[]
def l11111111lll_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ屘"),l11lll_l1_ (u"ࠩࠪ屙"),l11lll_l1_ (u"ࠪࠫ屚"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬ屛"))
	items = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ屜"),html,re.DOTALL)
	#l111lll1ll1l_l1_.l111111l111l_l1_(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬ屝") + items[0])
	if items:
		url = url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡧ࡭࡯ࡶࡦ࠰ࡲࡶ࡬࠭属") + items[0]
		return l11lll_l1_ (u"ࠨࠩ屟"),[l11lll_l1_ (u"ࠩࠪ屠")],[ url ]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡄࡊࡌ࡚ࡊ࠭屡"),[],[]
def l111l1lllll1_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ屢"),l11lll_l1_ (u"ࠬ࠭屣"),l11lll_l1_ (u"࠭ࠧ層"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔ࡚ࡈࡌࡊࡅ࡙ࡍࡉࡋࡏࡉࡑࡖࡘ࠲࠷ࡳࡵࠩ履"))
	items = re.findall(l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ屦"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ屧"),l11lll_l1_ (u"ࠪࠫ屨"),str(items),html)
	if items: return l11lll_l1_ (u"ࠫࠬ屩"),[l11lll_l1_ (u"ࠬ࠭屪")],[ items[0] ]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖࠪ屫"),[],[]
def l111l11ll11l_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ屬"),l11lll_l1_ (u"ࠨࠩ屭"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ屮"),l11lll_l1_ (u"ࠪࠫ屯"),l11lll_l1_ (u"ࠫࠬ屰"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭山"))
	items = re.findall(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭屲"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ屳"),l11lll_l1_ (u"ࠨࠩ屴"),items[0],items[0])
	if items: return l11lll_l1_ (u"ࠩࠪ屵"),[l11lll_l1_ (u"ࠪࠫ屶")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡔࡖࡕࡉࡆࡓࠧ屷"),[],[]
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ我")
headers = l11lll_l1_ (u"ࠫࠬ戒") #{ l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ戓") : l11lll_l1_ (u"࠭ࠧ戔") }
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭戕")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭或"),l11lll_l1_ (u"ࠩส่่๊ࠧ戗"),l11lll_l1_ (u"ࠪหๆ๊วๆࠩ战"),l11lll_l1_ (u"ࠫ࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠨ戙"),l11lll_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ戚")]
# l1l1ll11_l1_	https://l1lll1l1111ll_l1_.l1llll111l1_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l1111l111lll_l1_.net
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1lll1l1111l1_l1_
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1111l_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llllll_l1_(url,True)
	elif mode==114: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ戛")+text)
	elif mode==115: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ戜")+text)
	elif mode==116: results = l1llllll_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ戝"),l11lll_l1_ (u"ࠩืห์ีࠠโ๊ิ๎ํࠦ࠭ࠡࡕ࡫ࡥ࡭࡯ࡤࠡ࠶ࡸࠫ戞"),l11lll_l1_ (u"ࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪ戟"),headers)
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ戠"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ戡"),l11lll_l1_ (u"࠭ࠧ戢"),119,l11lll_l1_ (u"ࠧࠨ戣"),l11lll_l1_ (u"ࠨࠩ戤"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭戥"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ戦"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ戧"),l1ll1l1_l1_,115)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ戨"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ戩"),l1ll1l1_l1_,114)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ截"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ戫"),l11lll_l1_ (u"ࠩࠪ戬"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ戭"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ戮"),l1ll1l1_l1_,111,l11lll_l1_ (u"ࠬ࠭戯"),l11lll_l1_ (u"࠭ࠧ戰"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ戱"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵ࡬ࡱࡵࡲࡥ࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠩ戲"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ戳"),l11lll_l1_ (u"ࠪࠫ戴"),l11lll_l1_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭戵"),l11lll_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ุะื๋฻ࠣษ๏าวะࠢ฼๊ํอๆࠡษ็้ํู่ࠡล๋ࠤฯ฻ๅ๋็ࠣห้๋่ใ฻ࠣฮ฿๐ัࠨ戶"))
		return
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ户"),block,re.DOTALL)
		for filter,l1llll_l1_,title in items:
			url = l1ll1l1_l1_+filter
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ戸"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ戹")+l111ll_l1_+title,url,111,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ戺"),filter)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ戻"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ戼"),l11lll_l1_ (u"ࠬ࠭戽"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮ࠣࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ戾"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ房"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ所"),l11lll_l1_ (u"ࠩࠪ扁")).replace(l11lll_l1_ (u"ࠪࡠࡷ࠭扂"),l11lll_l1_ (u"ࠫࠬ扃")).strip(l11lll_l1_ (u"ࠬࠦࠧ扄"))
			if title in l1l1l1_l1_: continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ扅") not in link: link = l1ll1l1_l1_+link
			if l11lll_l1_ (u"ࠧ࡯ࡧࡷࡪࡱ࡯ࡸࠨ扆") in link: title = l11lll_l1_ (u"ࠨ่ํฮๆ๊ใิࠩ扇")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ扈"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ扉")+l111ll_l1_+title,link,111)
	return html
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠫࠬ扊"),response=l11lll_l1_ (u"ࠬ࠭手")):
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ扌"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ才")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ扎"),url,l11lll_l1_ (u"ࠩࠪ扏"),headers,l11lll_l1_ (u"ࠪࠫ扐"),l11lll_l1_ (u"ࠫࠬ扑"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ扒"))
	html = response.content
	l1l1ll1_l1_,items,l1l1_l1_ = [],[],[]
	if l1111l111_l1_==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ打"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡨ࡮࡬ࡨࡪࡥ࡟ࡴ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ扔"),html,re.DOTALL)
	#elif l1111l111_l1_==l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ払"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡐࡩࡩ࡯ࡡࡈࡴ࡬ࡨ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭扖"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷ࡭ࡵࡷࡴ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭扗"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#if l1111l111_l1_==l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ托"): items = re.findall(l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ扙"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭扚"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ扛"),l11lll_l1_ (u"ࠨใํ่๊࠭扜"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ扝"),l11lll_l1_ (u"ࠪ็้๐ศࠨ扞"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ扟"),l11lll_l1_ (u"ࠬํฯศใࠪ扠"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭扡"),l11lll_l1_ (u"ฺࠧำูࠫ扢"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ扣"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ扤")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ扥") in link: continue
		#if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭扦") in link: continue
		#link = link.replace(l11lll_l1_ (u"ࠬࠬࠣ࠱࠵࠻࠿ࠬ执"),l11lll_l1_ (u"࠭ࠦࠨ扨"))
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩ扩"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ扪"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ扫"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ扬") in link or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ扭"),l111ll_l1_+title,link,112,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ扮") in title and l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ扯") not in url:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭扰") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ扱"),l111ll_l1_+title,link,113,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ扲") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ扳"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭扴") in link and l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ扵") not in url:
			link = link+l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ扶")
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ扷"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ扸") in url and l11lll_l1_ (u"ࠩะ่็ฯࠧ批") in title:
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ扺"),l111ll_l1_+title,link,112,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ扻"),l111ll_l1_+title,link,113,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ扼"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1111l111_l1_!=l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭扽"): items = re.findall(l11lll_l1_ (u"ࠧࠩࡷࡳࡨࡦࡺࡥࡒࡷࡨࡶࡾ࠯࠮ࠫࡁࡁࠬ࠳࠱࠿ࠪ࠾ࠪ找"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠨ࠾࡯࡭ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ承"),block,re.DOTALL)
		for link,title in items:
			if l1111l111_l1_!=l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ技"):
				title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭抁"),l11lll_l1_ (u"ࠫࠬ抂")).replace(l11lll_l1_ (u"ࠬࡢࡲࠨ抃"),l11lll_l1_ (u"࠭ࠧ抄"))
				if l11lll_l1_ (u"ࠧࡀࠩ抅") in url: link = url+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ抆")+title
				else: link = url+l11lll_l1_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩ抇")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ抈"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ抉")+title,link,111,l11lll_l1_ (u"ࠬ࠭把"),l11lll_l1_ (u"࠭ࠧ抋"),l1111l111_l1_)
	return
def l1llllll_l1_(url,l1lll1l11111l_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ抌"),url,l11lll_l1_ (u"ࠨࠩ抍"),headers,l11lll_l1_ (u"ࠩࠪ抎"),l11lll_l1_ (u"ࠪࠫ抏"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ抐"))
	html = response.content
	# l1lllll_l1_ & l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠤࡩ࠳ࡦ࡭ࡧࡻࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ抑"),html,re.DOTALL)
	if len(l1l1ll1_l1_)>1:
		if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ抒") in l1l1ll1_l1_[0]: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[1]
		else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[1],l1l1ll1_l1_[0]
	else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[0]
	for l11l1lllll_l1_ in range(2):
		if l1lll1l11111l_l1_: mode,type,block = 116,l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ抓"),l1lllll_l1_
		else: mode,type,block = 112,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ抔"),l1l1l_l1_
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ投"),block,re.DOTALL)
		if l1lll1l11111l_l1_ and len(items)<2:
			l1lll1l11111l_l1_ = False
			continue
		for link,l11ll1l11_l1_,l1lll1lll_l1_ in items:
			title = l11ll1l11_l1_+l11lll_l1_ (u"ࠪࠤࠬ抖")+l1lll1lll_l1_
			addMenuItem(type,l111ll_l1_+title,link,mode)
		break
	# l1l1l_l1_ l11l1ll1_l1_
	if not items and l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹࠧ抗") in html:
		l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡲࡦࡣࡧࡧࡷࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ折"),html,re.DOTALL)
		if l1llll1l1l_l1_:
			block = l1llll1l1l_l1_[0]
			links = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ抙"),block,re.DOTALL)
			if len(links)>2:
				link = links[2]+l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ抚")
				l1111l_l1_(link)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ抛"),url,l11lll_l1_ (u"ࠩࠪ抜"),headers,l11lll_l1_ (u"ࠪࠫ抝"),l11lll_l1_ (u"ࠫࠬ択"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ抟"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡡࡤࡶ࡬ࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ抠"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭抡"),block,re.DOTALL)
	l11ll1l1l_l1_ = l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ抢") in block
	download = l11lll_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭抣") in block
	if   l11ll1l1l_l1_ and not download: l1lll1l111l11_l1_,l11l111l1l11_l1_ = links[0],l11lll_l1_ (u"ࠪࠫ护")
	elif not l11ll1l1l_l1_ and download: l1lll1l111l11_l1_,l11l111l1l11_l1_ = l11lll_l1_ (u"ࠫࠬ报"),links[0]
	elif l11ll1l1l_l1_ and download: l1lll1l111l11_l1_,l11l111l1l11_l1_ = links[0],links[1]
	else: l1lll1l111l11_l1_,l11l111l1l11_l1_ = l11lll_l1_ (u"ࠬ࠭抦"),l11lll_l1_ (u"࠭ࠧ抧")
	# l11ll1l1l_l1_
	if l11ll1l1l_l1_:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ抨"),l1lll1l111l11_l1_,l11lll_l1_ (u"ࠨࠩ抩"),headers,l11lll_l1_ (u"ࠩࠪ抪"),l11lll_l1_ (u"ࠪࠫ披"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ抬"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡲࡥࡵࠢࡶࡩࡷࡼࡥࡳࡵࠫ࠲࠯ࡅࠩࡱ࡮ࡤࡽࡪࡸࠧ抭"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ抮"),l11l1_l1_,re.DOTALL)
			for title,link in l1l1lll_l1_:
				link = link.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ抯"),l11lll_l1_ (u"ࠨ࠱ࠪ抰"))
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ抱")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ抲")
				l1111_l1_.append(link)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ抳"),l11l111l1l11_l1_,l11lll_l1_ (u"ࠬ࠭抴"),headers,l11lll_l1_ (u"࠭ࠧ抵"),l11lll_l1_ (u"ࠧࠨ抶"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ抷"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࡬ࡲ࡫ࡵ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠪ抸"),l11lll1l_l1_,re.DOTALL)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂ࠯ࡪࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ抹"),l11l1_l1_,re.DOTALL)
			for link,title,l11l111l_l1_ in l1l1lll_l1_:
				link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ抺")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ抻")+l11lll_l1_ (u"࠭࡟ࡠࡡࡢࠫ押")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ抽"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ抾"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ抿"),l11lll_l1_ (u"ࠪ࠯ࠬ拀"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ拁")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ拂"),l11lll_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ拃"),l11lll_l1_ (u"ࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧ拄"),headers)
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ担"),l1ll111ll_l1_)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭拆"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ拇"),url,l11lll_l1_ (u"ࠫࠬ拈"),headers,l11lll_l1_ (u"ࠬ࠭拉"),l11lll_l1_ (u"࠭ࠧ拊"),l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ拋"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡣࡧࡺ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡶ࡬ࡴࡽࡳ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠫ拌"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡸࡴࡩࡧࡴࡦࡓࡸࡩࡷࡿ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺࠧ拍"),block,re.DOTALL)
		l1lll1l111_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄ࡜ࡴࠬࠫ࠲࠯ࡅࠩ࡝ࡵ࠭ࡀࠬ拎"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ拏"),l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ拐"))
	if l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ拑") not in url: url = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ拒")
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ拓"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭拔"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	#url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ拕"),l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ拖"))
	url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ拗"),l11lll_l1_ (u"࠭࠯ࡀࠩ拘"))
	return url
l1lll11lll_l1_ = [l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ拙"),l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭拚"),l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ招"),l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ拜")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭拝"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ拞"),l11lll_l1_ (u"࠭ࡹࡦࡣࡵࠫ拟")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ拠"),l11lll_l1_ (u"ࠨࠩ拡"))
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭拢"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ拣"),1)
	if filter==l11lll_l1_ (u"ࠫࠬ拤"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠬ࠭拥"),l11lll_l1_ (u"࠭ࠧ拦")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ拧"))
	if type==l11lll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ拨"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"ࠩࡀࠫ择") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"ࠪࡁࠬ拪") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭拫")+category+l11lll_l1_ (u"ࠬࡃ࠰ࠨ括")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ拭")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ拮")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪ拯"))+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭拰")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ拱"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ拲"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ拳")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ拴"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ拵"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠨࠩ拶"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ拷"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠪࠫ拸"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ拹")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ拺"),l111ll_l1_+l11lll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ拻"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ拼"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ拽")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ拾"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ拿"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ挀"),l11lll_l1_ (u"ࠬ࠭持"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"࠭ใๅࠢࠪ挂"),l11lll_l1_ (u"ࠧࠨ挃"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠨ࠿ࠪ挄") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ挅"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ挆")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ指"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭挈"),l11l1l1_l1_,111)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭按"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ挊"),l11l11l_l1_,115,l11lll_l1_ (u"ࠨࠩ挋"),l11lll_l1_ (u"ࠩࠪ挌"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ挍"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭挎")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ挏")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ挐")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ挑")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ挒")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ挓"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬ挔")+name,l11l11l_l1_,114,l11lll_l1_ (u"ࠫࠬ挕"),l11lll_l1_ (u"ࠬ࠭挖"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ挗"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧ挘"): option = l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ挙")
			elif value==l11lll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ挚"): option = l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ挛")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ挜") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭挝"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ挞")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ挟")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ挠")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫ挡")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ挢")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧ挣")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧ挤")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩ挥")+name
			if type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ挦"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ挧"),l111ll_l1_+title,url,114,l11lll_l1_ (u"ࠩࠪ挨"),l11lll_l1_ (u"ࠪࠫ挩"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭挪"))
			elif type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭挫") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨ挬") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ挭"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ挮")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ振"),l111ll_l1_+title,l11l1l1_l1_,111)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ挰"),l111ll_l1_+title,url,115,l11lll_l1_ (u"ࠫࠬ挱"),l11lll_l1_ (u"ࠬ࠭挲"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ挳")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ挴")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ挵")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠩࡀࠪࠬ挶"),l11lll_l1_ (u"ࠪࡁ࠵ࠬࠧ挷"))
	filters = filters.strip(l11lll_l1_ (u"ࠫࠫ࠭挸"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠬࡃࠧ挹") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠨ挺"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ挻"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠨࠩ挼")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠩ࠳ࠫ挽")
		if l11lll_l1_ (u"ࠪࠩࠬ挾") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭挿") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ捀"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠠࠬࠢࠪ捁")+value
		elif mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ捂") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ捃"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ捄")+key+l11lll_l1_ (u"ࠪࡁࠬ捅")+value
		elif mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ捆"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ捇")+key+l11lll_l1_ (u"࠭࠽ࠨ捈")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ捉"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪ捊"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠩࡀ࠴ࠬ捋"),l11lll_l1_ (u"ࠪࡁࠬ捌"))
	return l1ll1l1l_l1_
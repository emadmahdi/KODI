# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬᳲ")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡃࡍࡐࡢࠫᳳ")
l1l1lll111_l1_ = os.path.join(l1ll11llll_l1_,l11lll_l1_ (u"࠭ࡴࡦ࡯ࡳࠫ᳴"))
l1l11l1ll1_l1_ = os.path.join(l1ll11llll_l1_,l11lll_l1_ (u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩᳵ"))
l1l1ll1ll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪᳶ"),l11lll_l1_ (u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭᳷"))
l1l1l1111l_l1_ = l1ll111lll_l1_
l1l11l1lll_l1_ = l11lll_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭᳸")
l1l11ll111_l1_ = l11lll_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫ᳹")
l1l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨᳺ")
l1l1lll11l_l1_ = l11lll_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬ᳻")
l1l11ll1ll_l1_ = l11lll_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪ᳼")
l1l11lll11_l1_ = l11lll_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫ᳽")
def MAIN(mode):
	if   mode==740: results = l1ll11lll1_l1_()
	elif mode==741: results = l1ll11l1ll_l1_(l1l1lll111_l1_,True,True)
	elif mode==742: results = l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,True)
	elif mode==743: results = l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,True)
	elif mode==744: results = l1l11lllll_l1_(l1l1l1111l_l1_,True)
	elif mode==745: results = l1l11l1l11_l1_(True)
	elif mode==750: results = l1l1l1lll1_l1_()
	elif mode==751: results = l1ll11l1ll_l1_(l1l11l1lll_l1_,False,True)
	elif mode==752: results = l1ll11l1ll_l1_(l1l11ll111_l1_,False,True)
	elif mode==753: results = l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,True)
	elif mode==754: results = l1ll11l1ll_l1_(l1l1lll11l_l1_,False,True)
	elif mode==755: results = l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,True)
	elif mode==756: results = l1ll11l1ll_l1_(l1l11lll11_l1_,False,True)
	elif mode==757: results = l1l1ll1111_l1_(True)
	elif mode==758: results = l1l1l1l1l1_l1_()
	else: results = False
	return results
def l1ll11lll1_l1_():
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l1lll111_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11l1ll1_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1ll1_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l1l11ll1_l1_(l1l1l1111l_l1_)
	l1ll11111l_l1_ -= 36864
	l1l1l111l1_l1_ -= 1
	l1l11ll1l1_l1_ = l11lll_l1_ (u"ࠩࠣࠬࠬ᳾")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ᳿")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᴀ")
	l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠬࠦࠨࠨᴁ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪᴂ")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᴃ")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"ࠨࠢࠫࠫᴄ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭ᴅ")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᴆ")
	l1ll11ll1l_l1_ = l11lll_l1_ (u"ࠫࠥ࠮ࠧᴇ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11lll_l1_ (u"ࠬ࠯ࠧᴈ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_
	text = l11lll_l1_ (u"࠭ࠠࠩࠩᴉ")+l1ll11ll11_l1_(size)+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫᴊ")+str(count)+l11lll_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᴋ")
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᴌ"),l111ll_l1_+l11lll_l1_ (u"ุ้ࠪำࠠศๆฯ้๏฿ࠧᴍ")+text,l11lll_l1_ (u"ࠫࠬᴎ"),745)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᴏ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᴐ"),l11lll_l1_ (u"ࠧࠨᴑ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᴒ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨᴓ")+l1l11ll1l1_l1_,l11lll_l1_ (u"ࠪࠫᴔ"),741)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᴕ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬᴖ")+l1l1l1ll11_l1_,l11lll_l1_ (u"࠭ࠧᴗ"),742)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᴘ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬᴙ")+l1l1l1l1ll_l1_,l11lll_l1_ (u"ࠩࠪᴚ"),743)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᴛ"),l111ll_l1_+l11lll_l1_ (u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ᴜ")+l1ll11ll1l_l1_,l11lll_l1_ (u"ࠬ࠭ᴝ"),744)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᴞ"),l11lll_l1_ (u"ࠧࠨᴟ"))
	return
def l1l1l1lll1_l1_():
	l1ll11l11l_l1_ = True if l11lll_l1_ (u"ࠨ࠱ࠪᴠ") in l1l1l11111_l1_ else False
	if not l1ll11l11l_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪᴡ"),l11lll_l1_ (u"ࠪࠫᴢ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᴣ"),l11lll_l1_ (u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬᴤ"))
		return
	l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᴥ"))
	if not l1l11llll1_l1_: l1l1l1l1l1_l1_()
	l1l1lllll1_l1_,l1ll11l1l1_l1_ = l1l11ll11l_l1_(l1l11l1lll_l1_)
	l1l1llll1l_l1_,l1l1l11l11_l1_ = l1l11ll11l_l1_(l1l11ll111_l1_)
	l1l1llll11_l1_,l1l1l11l1l_l1_ = l1l11ll11l_l1_(l1l1ll1l1l_l1_)
	l1ll11111l_l1_,l1l1l111l1_l1_ = l1l11ll11l_l1_(l1l1lll11l_l1_)
	l1ll111111_l1_,l1l1l111ll_l1_ = l1l11ll11l_l1_(l1l11ll1ll_l1_)
	l1l1llllll_l1_,l1l1lll1l1_l1_ = l1l11ll11l_l1_(l1l11lll11_l1_)
	l1l11ll1l1_l1_ = l11lll_l1_ (u"ࠧࠡࠪࠪᴦ")+l1ll11ll11_l1_(l1l1lllll1_l1_)+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬᴧ")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᴨ")
	l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠪࠤ࠭࠭ᴩ")+l1ll11ll11_l1_(l1l1llll1l_l1_)+l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨᴪ")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᴫ")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"࠭ࠠࠩࠩᴬ")+l1ll11ll11_l1_(l1l1llll11_l1_)+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫᴭ")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᴮ")
	l1ll11ll1l_l1_ = l11lll_l1_ (u"ࠩࠣࠬࠬᴯ")+l1ll11ll11_l1_(l1ll11111l_l1_)+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧᴰ")+str(l1l1l111l1_l1_)+l11lll_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᴱ")
	l1l1l11lll_l1_ = l11lll_l1_ (u"ࠬࠦࠨࠨᴲ")+l1ll11ll11_l1_(l1ll111111_l1_)+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪᴳ")+str(l1l1l111ll_l1_)+l11lll_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᴴ")
	l1l1l1l11l_l1_ = l11lll_l1_ (u"ࠨࠢࠫࠫᴵ")+l1ll11ll11_l1_(l1l1llllll_l1_)+l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭ᴶ")+str(l1l1lll1l1_l1_)+l11lll_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᴷ")
	size = l1l1lllll1_l1_+l1l1llll1l_l1_+l1l1llll11_l1_+l1ll11111l_l1_+l1ll111111_l1_+l1l1llllll_l1_
	count = l1ll11l1l1_l1_+l1l1l11l11_l1_+l1l1l11l1l_l1_+l1l1l111l1_l1_+l1l1l111ll_l1_+l1l1lll1l1_l1_
	text = l11lll_l1_ (u"ࠫࠥ࠮ࠧᴸ")+l1ll11ll11_l1_(size)+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩᴹ")+str(count)+l11lll_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᴺ")
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᴻ"),l111ll_l1_+l11lll_l1_ (u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫᴼ"),l11lll_l1_ (u"ࠩࠪᴽ"),758)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᴾ"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫอࠡษ็ะ๊๐ูࠨᴿ")+text,l11lll_l1_ (u"ࠬ࠭ᵀ"),757)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᵁ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᵂ"),l11lll_l1_ (u"ࠨࠩᵃ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᵄ"),l111ll_l1_+l11lll_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪᵅ")+l1l11ll1l1_l1_,l11lll_l1_ (u"ࠫࠬᵆ"),751)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᵇ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪᵈ")+l1l1l1ll11_l1_,l11lll_l1_ (u"ࠧࠨᵉ"),752)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᵊ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩᵋ")+l1l1l1l1ll_l1_,l11lll_l1_ (u"ࠪࠫᵌ"),753)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᵍ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨᵎ")+l1ll11ll1l_l1_,l11lll_l1_ (u"࠭ࠧᵏ"),754)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᵐ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨᵑ")+l1l1l11lll_l1_,l11lll_l1_ (u"ࠩࠪᵒ"),755)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᵓ"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫᵔ")+l1l1l1l11l_l1_,l11lll_l1_ (u"ࠬ࠭ᵕ"),756)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᵖ"),l11lll_l1_ (u"ࠧࠨᵗ"))
	return
def l1l1l1l1l1_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩᵘ"),l11lll_l1_ (u"ࠩࠪᵙ"),l11lll_l1_ (u"ࠪࠫᵚ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᵛ"),l11lll_l1_ (u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬᵜ"))
	if l1ll111ll1_l1_==-1: return
	if l1ll111ll1_l1_:
		l1ll11l111_l1_ = True
		import subprocess
		try: subprocess.Popen(l11lll_l1_ (u"࠭ࡳࡶࠩᵝ"))
		except: l1ll11l111_l1_ = False
		if l1ll11l111_l1_:
			l1l1ll11l1_l1_ = l1l11l1lll_l1_+l11lll_l1_ (u"ࠧࠡࠩᵞ")+l1l11ll111_l1_+l11lll_l1_ (u"ࠨࠢࠪᵟ")+l1l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠣࠫᵠ")+l1l1lll11l_l1_+l11lll_l1_ (u"ࠪࠤࠬᵡ")+l1l11ll1ll_l1_+l11lll_l1_ (u"ࠫࠥ࠭ᵢ")+l1l11lll11_l1_
			proc = subprocess.Popen(l11lll_l1_ (u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ᵣ")+l1l1ll11l1_l1_+l11lll_l1_ (u"࠭ࠢࠨᵤ"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨᵥ"),l11lll_l1_ (u"ࠨࠩᵦ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᵧ"),l11lll_l1_ (u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ᵨ"))
			settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᵩ"),l11lll_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᵪ"))
			xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᵫ"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠧࠨᵬ"),l11lll_l1_ (u"ࠨࠩᵭ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᵮ"),l11lll_l1_ (u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪᵯ"))
	return
def l1ll11ll11_l1_(size):
	for x in [l11lll_l1_ (u"ࠫࡇ࠭ᵰ"),l11lll_l1_ (u"ࠬࡑࡂࠨᵱ"),l11lll_l1_ (u"࠭ࡍࡃࠩᵲ"),l11lll_l1_ (u"ࠧࡈࡄࠪᵳ"),l11lll_l1_ (u"ࠨࡖࡅࠫᵴ")]:
		if size<1024: break
		else: size /= 1024.0
	text = l11lll_l1_ (u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦᵵ")%(size,x)
	return text
def l1l11ll11l_l1_(l1ll111l1l_l1_=l11lll_l1_ (u"ࠪ࠲ࠬᵶ")):
	global l1l1ll1l11_l1_,l1ll1111ll_l1_
	l1l1ll1l11_l1_,l1ll1111ll_l1_ = 0,0
	def l1l1ll1lll_l1_(l1ll111l1l_l1_):
		global l1l1ll1l11_l1_,l1ll1111ll_l1_
		if os.path.exists(l1ll111l1l_l1_):
			if 0 and l11lll_l1_ (u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬᵷ") in dir(os):
				# using l1l1lll1ll_l1_ l11lll_l1_ (u"ࠬࡵࡳ࠯ࡵࡦࡥࡳࡪࡩࡳࠩᵸ") method (new in version 3.5)
				for l1l11l1l1l_l1_ in os.scandir(l1ll111l1l_l1_):
					if l1l11l1l1l_l1_.l1ll111l11_l1_(follow_symlinks=False):
						l1l1ll1lll_l1_(l1l11l1l1l_l1_.path)
					elif l1l11l1l1l_l1_.l1l1l1l111_l1_(follow_symlinks=False):
						l1l1ll1l11_l1_ += l1l11l1l1l_l1_.stat().st_size
						l1ll1111ll_l1_ += 1
			else:
				# using l1l111l11_l1_, l1l1l1ll1l_l1_ l1l11lll1l_l1_ l11lll_l1_ (u"࠭࡯ࡴ࠰࡯࡭ࡸࡺࡤࡪࡴࠪᵹ") method
				for l1l11l1l1l_l1_ in os.listdir(l1ll111l1l_l1_):
					l1l11l11ll_l1_ = os.path.abspath(os.path.join(l1ll111l1l_l1_,l1l11l1l1l_l1_))
					if os.path.isdir(l1l11l11ll_l1_):
						l1l1ll1lll_l1_(l1l11l11ll_l1_)
					elif os.path.isfile(l1l11l11ll_l1_):
						size,count = l1l1l11ll1_l1_(l1l11l11ll_l1_)
						l1l1ll1l11_l1_ += size
						l1ll1111ll_l1_ += count
		return
	try: l1l1ll1lll_l1_(l1ll111l1l_l1_)
	except: pass
	return l1l1ll1l11_l1_,l1ll1111ll_l1_
def l1ll1111l1_l1_(l1l1ll11ll_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࠨᵺ"),l11lll_l1_ (u"ࠨࠩᵻ"),l11lll_l1_ (u"ࠩࠪᵼ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᵽ"),l1l1ll11ll_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩᵾ")+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊๊แࠡมࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᵿ"))
		if l1ll111ll1_l1_!=1: return
	error = False
	if os.path.exists(l1l1ll11ll_l1_):
		try: os.remove(l1l1ll11ll_l1_)
		except Exception as err:
			if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧᶀ"),l11lll_l1_ (u"ࠧࠨᶁ"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᶂ"),str(err))
			error = True
	if l1ll_l1_ and not error:
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪᶃ"),l11lll_l1_ (u"ࠪࠫᶄ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶅ"),l11lll_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ᶆ"))
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᶇ"),l11lll_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᶈ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᶉ"))
	return
def l1l11l1l11_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪᶊ"),l11lll_l1_ (u"ࠪࠫᶋ"),l11lll_l1_ (u"ࠫࠬᶌ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᶍ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้็ࠤฯื๊ะ่ࠢืา࠭ᶎ")+l11lll_l1_ (u"ࠧ࡝ࡰࠪᶏ")+l11lll_l1_ (u"ࠨ็ฯ่ิࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้๋ไโษอࠤฬ๊ๅื฼๋฻ฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็ูํืࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤํะแา์฽ࠤ๊๊แࠡื๋ีࠥอไฦุสๅฬะࠧᶐ")+l11lll_l1_ (u"ࠩ࡟ࡲࠬᶑ")+l11lll_l1_ (u"ࠪรࠦࠧࠧᶒ")+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᶓ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l1lll111_l1_,True,False)
	l1ll11l1ll_l1_(l1l11l1ll1_l1_,True,False)
	l1ll11l1ll_l1_(l1l1ll1ll1_l1_,False,False)
	l1l11lllll_l1_(l1l1l1111l_l1_,False)
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᶔ"),l11lll_l1_ (u"࠭ࠧᶕ"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶖ"),l11lll_l1_ (u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩᶗ"))
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭ᶘ"),l11lll_l1_ (u"ࠪࡗࡔࡓࡅࡕࡊࡌࡒࡌ࠭ᶙ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨᶚ"))
	return
def l1l1ll1111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬ࠭ᶛ"),l11lll_l1_ (u"࠭ࠧᶜ"),l11lll_l1_ (u"ࠧࠨᶝ"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᶞ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠨᶟ")+l11lll_l1_ (u"ࠪࡠࡳ࠭ᶠ")+l11lll_l1_ (u"ࠫࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠡ࠰࠱ࠤࡩࡸ࡯ࡱࡤࡲࡼࠥ࠴࠮ࠡࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠥ࠴࠮ࠡ࡮ࡲ࡫࡬࡫ࡲࠡ࠰࠱ࠤࡱࡵࡧࠡ࠰࠱ࠤࡦࡴࡲࠨᶡ")+l11lll_l1_ (u"ࠬࡢ࡮ࠨᶢ")+l11lll_l1_ (u"࠭࠿ࠢࠣࠪᶣ")+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᶤ"))
		if l1ll111ll1_l1_!=1: return
	l1ll11l1ll_l1_(l1l11l1lll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll111_l1_,False,False)
	l1ll11l1ll_l1_(l1l1ll1l1l_l1_,False,False)
	l1ll11l1ll_l1_(l1l1lll11l_l1_,False,False)
	l1ll11l1ll_l1_(l1l11ll1ll_l1_,False,False)
	l1ll11l1ll_l1_(l1l11lll11_l1_,False,False)
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩᶥ"),l11lll_l1_ (u"ࠩࠪᶦ"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᶧ"),l11lll_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᶨ"))
		settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᶩ"),l11lll_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᶪ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᶫ"))
	return
def l1l11lllll_l1_(l1l1ll111l_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩᶬ"),l11lll_l1_ (u"ࠩࠪᶭ"),l11lll_l1_ (u"ࠪࠫᶮ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᶯ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึั๋ࠥอห๊ํหฯࠦๅๅใูࠣํืࠠศๆฯ่ิࠦฟࠢࠣࠪᶰ")+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᶱ"))
		if l1ll111ll1_l1_!=1: return
	conn = sqlite3.connect(l1l1ll111l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l11lll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡶࡡࡵࡪ࠾ࠫᶲ"))
	cc.execute(l11lll_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡳࡪࡼࡨࡷࡀ࠭ᶳ"))
	cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡵࡧࡻࡸࡺࡸࡥ࠼ࠩᶴ"))
	conn.commit()
	cc.execute(l11lll_l1_ (u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫᶵ"))
	conn.close()
	if l1ll_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬᶶ"),l11lll_l1_ (u"ࠬ࠭ᶷ"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᶸ"),l11lll_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᶹ"))
		settings.setSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᶺ"),l11lll_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᶻ"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᶼ"))
	return
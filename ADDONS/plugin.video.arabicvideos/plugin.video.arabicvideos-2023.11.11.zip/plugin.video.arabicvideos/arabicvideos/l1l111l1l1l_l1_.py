# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ㜽")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡐࡗࡠ࡟ࠨ㜾")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ㜿"),l11lll_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ㝀"),l11lll_l1_ (u"ࠬอไศไึห๊࠭㝁"),l11lll_l1_ (u"ู࠭าุࠣห้๋า๋ัࠪ㝂")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l1111l_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l11111_l1_(url,text)
	elif mode==704: results = l1l11l_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡼ࡬࡯ࡦ࠴࠹ࠨ㝃")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㝄"),l1ll1l1_l1_,l11lll_l1_ (u"ࠩࠪ㝅"),l11lll_l1_ (u"ࠪࠫ㝆"),l11lll_l1_ (u"ࠫࠬ㝇"),l11lll_l1_ (u"ࠬ࠭㝈"),l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㝉"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㝊"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㝋"),l11lll_l1_ (u"ࠩࠪ㝌"),709,l11lll_l1_ (u"ࠪࠫ㝍"),l11lll_l1_ (u"ࠫࠬ㝎"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㝏"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㝐"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㝑"),l11lll_l1_ (u"ࠨࠩ㝒"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㝓"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㝔")+l111ll_l1_+l11lll_l1_ (u"๊๋๊ࠫำࠩ㝕"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠬ࠭㝖"),l11lll_l1_ (u"࠭ࠧ㝗"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㝘"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㝙"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㝚")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ㝛"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠫࠬ㝜"),l11lll_l1_ (u"ࠬ࠭㝝"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㝞"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㝟"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㝠")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ㝡"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠪࠫ㝢"),l11lll_l1_ (u"ࠫࠬ㝣"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㝤"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㝥"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㝦")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ㝧"),l1ll1l1_l1_,701,l11lll_l1_ (u"ࠩࠪ㝨"),l11lll_l1_ (u"ࠪࠫ㝩"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㝪"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㝫"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㝬"),l11lll_l1_ (u"ࠧࠨ㝭"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡰ࠱ࡹࡵࡰ࠮ࡰࡤࡺࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠪ㝮"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ㝯"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠪࡀࡧࡄࠧ㝰"),l11lll_l1_ (u"ࠫࠬ㝱")).strip(l11lll_l1_ (u"ࠬࠦࠧ㝲"))
		if title in l1l1l1_l1_: continue
		if link.endswith(l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠬ㝳")): continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㝴"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㝵")+l111ll_l1_+title,link,704)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㝶"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㝷"),l11lll_l1_ (u"ࠫࠬ㝸"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ㝹"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ㝺"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠧࠨ㝻"))
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㝼"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	title = title.replace(l11lll_l1_ (u"ࠩ࠿ࡦࡃ࠭㝽"),l11lll_l1_ (u"ࠪࠫ㝾")).strip(l11lll_l1_ (u"ࠫࠥ࠭㝿"))
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㞀"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㞁")+l111ll_l1_+title,link,704)
	return
def l1l11l_l1_(url):
	l1ll1ll1l_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㞂"),url,l11lll_l1_ (u"ࠨࠩ㞃"),l11lll_l1_ (u"ࠩࠪ㞄"),l11lll_l1_ (u"ࠪࠫ㞅"),l11lll_l1_ (u"ࠫࠬ㞆"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㞇"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡲࡰ࡮ࡨࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㞈"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ㞉"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ㞊"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㞋"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫ㞌"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㞍"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㞎"),l11lll_l1_ (u"࠭ࠧ㞏"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㞐"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫ㞑")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㞒"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㞓"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㞔"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㞕"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㞖"),l11lll_l1_ (u"ࠧࠨ㞗"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㞘"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡹ࡬࡯ࡰࡶࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ㞙"),html,re.DOTALL)
	if l1llll1l1l_l1_:
		block = l1llll1l1l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㞚"),block,re.DOTALL)
		if 1:
			if l1ll1ll1l_l1_: addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㞛"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㞜"),l11lll_l1_ (u"࠭ࠧ㞝"),9999)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ㞞"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㞟"),l111ll_l1_+title,link,701)
				l1ll1ll1l_l1_ = True
	if not l1ll1ll1l_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪ㞠")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㞡"),l11lll_l1_ (u"ࠫࠬ㞢"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ㞣"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨ㞤"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭㞥")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㞦"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ㞧")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㞨"),url,data,headers,l11lll_l1_ (u"ࠫࠬ㞩"),l11lll_l1_ (u"ࠬ࠭㞪"),l11lll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ㞫"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㞬"),url,l11lll_l1_ (u"ࠨࠩ㞭"),l11lll_l1_ (u"ࠩࠪ㞮"),l11lll_l1_ (u"ࠪࠫ㞯"),l11lll_l1_ (u"ࠫࠬ㞰"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ㞱"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧ㞲"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ㞳"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭㞴"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㞵"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ㞶"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㞷"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㞸"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㞹"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㞺"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ㞻"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㞼"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㞽"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡨࡡࠡ࡯ࡪࡦࠥࡺࡡࡣ࡮ࡨࠤ࡫ࡻ࡬࡭ࠤࠫ࠲࠯ࡅࠩࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫ㞾"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㞿"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧ㟀"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㟁"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㟂"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ㟃"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ㟄"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ㟅"),l11lll_l1_ (u"้ࠬไ๋สࠪ㟆"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ㟇"),l11lll_l1_ (u"่ࠧัสๅࠬ㟈"),l11lll_l1_ (u"ࠨ็หหึอษࠨ㟉"),l11lll_l1_ (u"ࠩ฼ี฻࠭㟊"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ㟋"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ㟌"),l11lll_l1_ (u"๋ࠬำาฯํอࠬ㟍")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨ㟎"))
		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ㟏") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㟐")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㟑"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㟒") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭㟓")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧ㟔"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㟕"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ㟖"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㟗"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㟘"):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㟙"),l111ll_l1_+title,link,702,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㟚") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㟛"),l111ll_l1_+title,link,703,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ㟜") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㟝"),l111ll_l1_+title,link,701,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㟞"),l111ll_l1_+title,link,703,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㟟"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㟠")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㟡"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㟢"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ㟣"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㟤")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ㟥"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㟦"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ㟧")+title,link,701)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㟨"),l11lll_l1_ (u"ࠬ࠭㟩"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㟪"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㟫"),url,l11lll_l1_ (u"ࠨࠩ㟬"),l11lll_l1_ (u"ࠩࠪ㟭"),l11lll_l1_ (u"ࠪࠫ㟮"),l11lll_l1_ (u"ࠫࠬ㟯"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㟰"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ㟱"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㟲"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩ㟳")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ㟴"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭㟵"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠫࠨ࠭㟶"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㟷"),l111ll_l1_+title,url,703,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ㟸"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭㟹"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ㟺"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ㟻")+l1ll1_l1_+l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㟼"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ㟽")+l1ll1_l1_+l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㟾"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪ㟿")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㠀"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢ㠁"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㠂"),l11lll_l1_ (u"ࠪࠫ㠃"),l11lll_l1_ (u"ࠫࠬ㠄"),l11lll_l1_ (u"ࠬ࠸࠲࠳࠴࠵ࠫ㠅"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㠆"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㠇"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"ࠨ࠰࠲ࠫ㠈"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㠉")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㠊"))
			title = title.replace(l11lll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ㠋"),l11lll_l1_ (u"ࠬࠦࠧ㠌"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㠍"),l111ll_l1_+title,link,702,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ㠎"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㠏") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㠐")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ㠑"))
		#		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㠒"),l111ll_l1_+title,link,702,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㠓"),l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ㠔"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㠕"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㠖"),l11lll_l1_ (u"ࠩࠪ㠗"),l11lll_l1_ (u"ࠪࠫ㠘"),l11lll_l1_ (u"ࠫࠬ㠙"),l11lll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㠚"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ㠛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ link
		link = re.findall(l11lll_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㠜"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ㠝"))
			l1111_l1_.append(link)
		# l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪ㠞"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ㠟"))
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㠠")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㠡"))
				l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡕࡨࡶࡻ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㠢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ㠣"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				title = title.strip(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㠤"))
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㠥")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㠦"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ㠧"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㠨"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ㠩"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ㠪"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ㠫"),l11lll_l1_ (u"ࠩ࠮ࠫ㠬"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ㠭")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ㠮"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ㠯")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ㠰"))
	return
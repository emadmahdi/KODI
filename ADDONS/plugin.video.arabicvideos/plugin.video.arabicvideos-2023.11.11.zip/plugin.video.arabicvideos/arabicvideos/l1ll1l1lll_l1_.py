# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪᭃ")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡆࡑࡑࡥ᭄ࠧ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩๅ๊ํอสࠡใูหห๐ษࠨᭅ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l1111l_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l1llllll_l1_(url,text)
	elif mode==474: results = l1l11l_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᭆ"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬᭇ"),l11lll_l1_ (u"ࠬ࠭ᭈ"),l11lll_l1_ (u"࠭ࠧᭉ"),l11lll_l1_ (u"ࠧࠨᭊ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᭋ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᭌ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠪ࠳ࠬ᭍"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ᭎"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭏"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭᭐"),l11lll_l1_ (u"ࠧࠨ᭑"),479,l11lll_l1_ (u"ࠨࠩ᭒"),l11lll_l1_ (u"ࠩࠪ᭓"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᭔"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᭕"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᭖"),l11lll_l1_ (u"࠭ࠧ᭗"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᭘"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᭙")+l111ll_l1_+l11lll_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧ᭚"),l1ll1l1_l1_,471,l11lll_l1_ (u"ࠪࠫ᭛"),l11lll_l1_ (u"ࠫࠬ᭜"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ᭝"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᭞"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᭟")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ᭠"),l1ll1l1_l1_,471,l11lll_l1_ (u"ࠩࠪ᭡"),l11lll_l1_ (u"ࠪࠫ᭢"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭᭣"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᭤"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᭥"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l11lll_l1_ (u"ࠧࠡࠢࠪ᭦"),l11lll_l1_ (u"ࠨࠩ᭧")).strip(l11lll_l1_ (u"ࠩࠣࠫ᭨"))
		#if title in l1l1l1_l1_: continue
		link = link.replace(l11lll_l1_ (u"ࠪࡧࡦࡺ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹ࠱ࠨ᭩"),l11lll_l1_ (u"ࠫࡨࡧࡴ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳࠨ᭪"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭫"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᭬")+l111ll_l1_+title,link,474)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᭭"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᭮"),l11lll_l1_ (u"ࠩࠪ᭯"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ᭰"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ᭱"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_:
	#	block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠬ࠭᭲"))
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᭳"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠧๆี็ื้ࠦࠧ᭴") in title: continue
		if l11lll_l1_ (u"ࠨสิ๊ฬ๋ฬࠡࠩ᭵") in title: continue
		if l11lll_l1_ (u"ࠩ็่่ฮวาࠩ᭶") in title: continue
		#link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧ᭷")+category+l11lll_l1_ (u"ࠫࡂ࠭᭸")+value
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭹"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᭺")+l111ll_l1_+title,link,474)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ᭻"),url,l11lll_l1_ (u"ࠨࠩ᭼"),l11lll_l1_ (u"ࠩࠪ᭽"),l11lll_l1_ (u"ࠪࠫ᭾"),l11lll_l1_ (u"ࠫࠬ᭿"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᮀ"))
	html = response.content
	if l11lll_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵ࠭ᮁ") in url: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡱ࠲࡭ࡲࡪࡦࠥࠫᮂ"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᮃ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᮄ"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪᮅ") in link:
				if l11lll_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃࡥ࡯ࡩ࡯࡭ࡸ࡮࠭࡮ࡱࡹ࡭ࡪࡹࠧᮆ") in link: continue
				if l11lll_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹ࠱ࠨᮇ") in link: continue
				if l11lll_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾࡯࡬ࡷࡨ࠭ᮈ") in link: continue
				if l11lll_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡷࡺ࠲ࡩࡨࡢࡰࡱࡩࡱ࠭ᮉ") in link: continue
				if l11lll_l1_ (u"ࠨ็้ิࠥอไษัส๎ฮ࠭ᮊ") in title and l11lll_l1_ (u"ࠩࡧࡳࡂࡸࡡࡵ࡫ࡱ࡫ࠬᮋ") not in link: continue
			else: title = l11lll_l1_ (u"ࠪฮึะ๊ษࠢหหุะฮะษ่࠾ࠥࠦࠧᮌ")+title
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᮍ"),l111ll_l1_+title,link,471)
	else: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠬ࠭ᮎ")):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪᮏ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᮐ"),url,l11lll_l1_ (u"ࠨࠩᮑ"),l11lll_l1_ (u"ࠩࠪᮒ"),l11lll_l1_ (u"ࠪࠫᮓ"),l11lll_l1_ (u"ࠫࠬᮔ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᮕ"))
	html = response.content
	items = []
	if request==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠ࡯ࡲࡺ࡮࡫ࡳࠨᮖ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡫ࡲࡵࡪࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᮗ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࠬᮘ"),block,re.DOTALL)
		links,l1l111_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,links,l1l111_l1_)
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᮙ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬᮚ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠩᮛ"),block,re.DOTALL)
		links,l1l111_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,links,l1l111_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᮜ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭ᮝ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᮞ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᮟ"),html,re.DOTALL)
		if not l1l1ll1_l1_: return
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᮠ"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᮡ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫᮢ"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪᮣ"),l11lll_l1_ (u"࠭ว฻่ํอࠬᮤ"),l11lll_l1_ (u"ࠧไๆํฬࠬᮥ"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧᮦ"),l11lll_l1_ (u"๊ࠩำฬ็ࠧᮧ"),l11lll_l1_ (u"้ࠪออัศหࠪᮨ"),l11lll_l1_ (u"ࠫ฾ืึࠨᮩ"),l11lll_l1_ (u"๋ࠬ็าฮส᮪๊ࠬ"),l11lll_l1_ (u"࠭วๅส᮫๋้ࠬ"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧᮬ")]
	for l1llll_l1_,link,title in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠨ࠱ࠪᮭ"))
		title = title.replace(l11lll_l1_ (u"่ࠩห๏ࠦำ๋็สࠫᮮ"),l11lll_l1_ (u"ࠪࠫᮯ")).replace(l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫ᮰"),l11lll_l1_ (u"ࠬ࠭᮱")).strip(l11lll_l1_ (u"࠭ࠠࠨ᮲")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ᮳"),l11lll_l1_ (u"ࠨࠢࠪ᮴"))
		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ᮵") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ᮶")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭᮷"))
		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ᮸") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ᮹")+l1llll_l1_.strip(l11lll_l1_ (u"ࠧ࠰ࠩᮺ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠨࠢࠪᮻ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᮼ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᮽ")+title
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᮾ"),l111ll_l1_+title,link,472,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠬอไฮๆๅอࠬᮿ") in title:
			title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᯀ")+l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯁ"),l111ll_l1_+title,link,473,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ᯂ") in link:
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᯃ"),l111ll_l1_+title,link,471,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᯄ"),l111ll_l1_+title,link,473,l1llll_l1_)
	if request not in [l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᯅ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧᯆ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᯇ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᯈ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠨࠥࠪᯉ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫᯊ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᯋ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯌ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫᯍ")+title,link,471)
		l11111l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᯎ"),html,re.DOTALL)
		if l11111l11_l1_:
			link = l11111l11_l1_[0]
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯏ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨᯐ"),link,471)
	return
def l1llllll_l1_(url,l1ll1_l1_):
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪᯑ"),l11lll_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪᯒ")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᯓ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᯔ"),url,l11lll_l1_ (u"࠭ࠧᯕ"),l11lll_l1_ (u"ࠧࠨᯖ"),l11lll_l1_ (u"ࠨࠩᯗ"),l11lll_l1_ (u"ࠩࠪᯘ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᯙ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᯚ"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪᯛ")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᯜ"),html,re.DOTALL)
	items = []
	# l1lllll_l1_
	if l1l1l11_l1_ and not l1ll1_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᯝ"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࡟࠰ࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬᯞ"),block,re.DOTALL)
		for l1ll1_l1_,title in items: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᯟ"),l111ll_l1_+title,url,473,l1llll_l1_,l11lll_l1_ (u"ࠪࠫᯠ"),l1ll1_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬᯡ"))
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᯢ"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡴࡪࡶ࡯ࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠦࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࠧᯣ"),block,re.DOTALL)
		if items:
			for title,link in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩᯤ")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪᯥ"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᯦"),l111ll_l1_+title,link,472,l1llll_l1_)
		else:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᯧ"),block,re.DOTALL)
			for link,title,l1llll_l1_ in items:
				if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᯨ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧᯩ")+link.strip(l11lll_l1_ (u"࠭࠯ࠨᯪ"))
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᯫ"),l111ll_l1_+title,link,472,l1llll_l1_)
	if l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤࠪᯬ") in html:
		if items: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᯭ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᯮ"),l11lll_l1_ (u"ࠫࠬᯯ"),9999)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯰ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅ้ษู๎฾ࠦะศฬู้ࠣฯࠧᯱ"),url,471)
	#else: l1111l_l1_(url)
	return
def PLAY(url):
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯᯲ࠫ"))
	l1111_l1_ = []
	# l1ll1ll111_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘ᯳ࠬ"),url,l11lll_l1_ (u"ࠩࠪ᯴"),l11lll_l1_ (u"ࠪࠫ᯵"),l11lll_l1_ (u"ࠫࠬ᯶"),l11lll_l1_ (u"ࠬ࠭᯷"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ᯸"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡦ࡬ࡺࠥ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠾ࠩ࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠫ᯹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ᯺"),block,re.DOTALL)
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,True): return
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭᯻"),l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࠰ࡳ࡬ࡵ࠭᯼"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ᯽"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭᯾"),l11lll_l1_ (u"࠭ࠧ᯿"),l11lll_l1_ (u"ࠧࠨᰀ"),l11lll_l1_ (u"ࠨࠩᰁ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧᰂ"))
	html = response.content
	l1ll1l1ll1_l1_ = []
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡖࡑࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᰃ"),html,re.DOTALL)
	if link:
		link = link[0]
		if link and link not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(link)
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬᰄ")
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᰅ") not in link: link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᰆ")+link
			l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠢ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠥᰇ"),html,re.DOTALL)
	for link,title in items:
		if link not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(link)
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᰈ")+title+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᰉ")
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᰊ") not in link: link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᰋ")+link
			l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᰌ"),l11lll_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱ࡴ࡭ࡶࠧᰍ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᰎ"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩᰏ"),l11lll_l1_ (u"ࠩࠪᰐ"),l11lll_l1_ (u"ࠪࠫᰑ"),l11lll_l1_ (u"ࠫࠬᰒ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪᰓ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᰔ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪᰕ"),block,re.DOTALL)
		for link,title in items:
			if link not in l1ll1l1ll1_l1_:
				l1ll1l1ll1_l1_.append(link)
				link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᰖ")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᰗ")
				if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᰘ") not in link: link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪᰙ")+link
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᰚ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᰛ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨᰜ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩᰝ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫᰞ"),l11lll_l1_ (u"ࠪ࠯ࠬᰟ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬᰠ")+search
	l1111l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ㗚")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡑࡔࡌࡡࠪ㗛")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ㗜"),l11lll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ㗝"),l11lll_l1_ (u"ࠧศๆฦๆุอๅࠨ㗞")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l1111l_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l11111_l1_(url,text)
	elif mode==674: results = l1l11l_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㗟"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㗠"),l11lll_l1_ (u"ࠪࠫ㗡"),l11lll_l1_ (u"ࠫࠬ㗢"),l11lll_l1_ (u"ࠬ࠭㗣"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㗤"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗥"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㗦"),l11lll_l1_ (u"ࠩࠪ㗧"),679,l11lll_l1_ (u"ࠪࠫ㗨"),l11lll_l1_ (u"ࠫࠬ㗩"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㗪"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㗫"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㗬"),l11lll_l1_ (u"ࠨࠩ㗭"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㗮"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㗯")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ㗰"),l11ll1_l1_,671,l11lll_l1_ (u"ࠬ࠭㗱"),l11lll_l1_ (u"࠭ࠧ㗲"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㗳"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㗴"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㗵")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ㗶"),l11ll1_l1_,671,l11lll_l1_ (u"ࠫࠬ㗷"),l11lll_l1_ (u"ࠬ࠭㗸"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㗹"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㗺"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㗻")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ㗼"),l11ll1_l1_,671,l11lll_l1_ (u"ࠪࠫ㗽"),l11lll_l1_ (u"ࠫࠬ㗾"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㗿"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘀"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㘁")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ㘂"),l11ll1_l1_,671,l11lll_l1_ (u"ࠩࠪ㘃"),l11lll_l1_ (u"ࠪࠫ㘄"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㘅"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㘆"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㘇"),l11lll_l1_ (u"ࠧࠨ㘈"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㘉"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㘊"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			if title==l11lll_l1_ (u"ࠪห้ษโิษ่ࠫ㘋"): mode = 675
			else: mode = 674
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㘌"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㘍")+l111ll_l1_+title,link,mode)
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㘎"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㘏"),l11lll_l1_ (u"ࠨࠩ㘐"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭㘑"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ㘒"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠫࠬ㘓"))
	#items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㘔"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㘕"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㘖")+l111ll_l1_+title,link,674)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㘗"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㘘"),l11lll_l1_ (u"ࠪࠫ㘙"),9999)
	items = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡧࡸ࡯ࡸࡵࡨ࠲࡭ࡺ࡭࡭ࠩ㘚"))
	for link,l1llll_l1_,title in items:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㘛"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㘜")+l111ll_l1_+title,link,674,l1llll_l1_)
	return
def CATEGORIES(url):
	l1ll1l1111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㘝"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ㘞"),l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭㘟"))
	if l1ll1l1111_l1_: return l1ll1l1111_l1_
	#DIALOG_OK()
	l1ll1l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㘠"),url,l11lll_l1_ (u"ࠫࠬ㘡"),l11lll_l1_ (u"ࠬ࠭㘢"),l11lll_l1_ (u"࠭ࠧ㘣"),l11lll_l1_ (u"ࠧࠨ㘤"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫ㘥"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡺࡥࡨࡱࡵࡽ࠲࡮ࡥࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬ㘦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1ll1l1111_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㘧"),block,re.DOTALL)
		if l1ll1l1111_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭㘨"),l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ㘩"),l1ll1l1111_l1_,l11111l_l1_)
	return l1ll1l1111_l1_
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㘪"),url,l11lll_l1_ (u"ࠧࠨ㘫"),l11lll_l1_ (u"ࠨࠩ㘬"),l11lll_l1_ (u"ࠩࠪ㘭"),l11lll_l1_ (u"ࠪࠫ㘮"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㘯"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㘰"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ㘱"),l11lll_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭㘲"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㘳"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠩࠪ㘴"),block)]
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㘵"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㘶"),l11lll_l1_ (u"ࠬ࠭㘷"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㘸"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠪ㘹")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘺"),l111ll_l1_+title,link,671)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㘻"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㘼"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㘽"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㘾"),l11lll_l1_ (u"࠭ࠧ㘿"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙀"),l111ll_l1_+title,link,671)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠨࠩ㙁")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㙂"),l11lll_l1_ (u"ࠪࠫ㙃"),request,url)
	if request==l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㙄"):
		url,search = url.split(l11lll_l1_ (u"ࠬࡅࠧ㙅"),1)
		data = l11lll_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ㙆")+search
		headers = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㙇"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ㙈")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㙉"),url,data,headers,l11lll_l1_ (u"ࠪࠫ㙊"),l11lll_l1_ (u"ࠫࠬ㙋"),l11lll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ㙌"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㙍"),url,l11lll_l1_ (u"ࠧࠨ㙎"),l11lll_l1_ (u"ࠨࠩ㙏"),l11lll_l1_ (u"ࠩࠪ㙐"),l11lll_l1_ (u"ࠪࠫ㙑"),l11lll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㙒"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠬ࠭㙓"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㙔"))
	if request==l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ㙕"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㙖"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠩࠪ㙗"),link,title))
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㙘"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㙙"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㙚"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㙛"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ㙜"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㙝"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㙞"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ㙟"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㙠"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠬ࠭㙡"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㙢"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㙣"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨ㙤"),l11lll_l1_ (u"ࠩไ๎้๋ࠧ㙥"),l11lll_l1_ (u"ࠪห฿์๊สࠩ㙦"),l11lll_l1_ (u"่๊๊ࠫษࠩ㙧"),l11lll_l1_ (u"ࠬอูๅษ้ࠫ㙨"),l11lll_l1_ (u"࠭็ะษไࠫ㙩"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧ㙪"),l11lll_l1_ (u"ࠨ฻ิฺࠬ㙫"),l11lll_l1_ (u"่๋ࠩึาว็ࠩ㙬"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩ㙭"),l11lll_l1_ (u"ู๊ࠫัฮ์ฬࠫ㙮"),l11lll_l1_ (u"ࠬ็ไๆࠩ㙯")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨ㙰"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ㙱") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㙲")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㙳"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㙴") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭㙵")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧ㙶"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㙷"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ㙸"),title,re.DOTALL)
		#addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㙹"),l111ll_l1_+title,link,672,l1llll_l1_)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㙺"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㙻"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㙼"),l111ll_l1_+title,link,672,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㙽") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙾"),l111ll_l1_+title,link,673,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㙿") in link:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㚀"),l111ll_l1_+title,link,671,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㚁"),l111ll_l1_+title,link,673,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㚂"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㚃"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠬࠩࠧ㚄"): continue
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㚅") not in link:
				l11l11l_l1_ = url.rsplit(l11lll_l1_ (u"ࠧ࠰ࠩ㚆"),1)[0]
				link = l11l11l_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ㚇")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ㚈"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㚉"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ㚊")+title,link,671,l11lll_l1_ (u"ࠬ࠭㚋"),l11lll_l1_ (u"࠭ࠧ㚌"),request)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㚍"),l11lll_l1_ (u"ࠨࠩ㚎"),l1ll1_l1_,url)
	addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㚏"),l111ll_l1_+l11lll_l1_ (u"ࠪฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ㚐"),url,672)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㚑"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㚒"),l11lll_l1_ (u"࠭ࠧ㚓"),9999)
	l1ll1l1111_l1_ = CATEGORIES(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡣࡴࡲࡻࡸ࡫࠮ࡩࡶࡰࡰࠬ㚔"))
	l1l11l11l1l_l1_,l1l11l11l11_l1_,l1l11l1l1ll_l1_ = zip(*l1ll1l1111_l1_)
	l1l11l11lll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㚕"),url,l11lll_l1_ (u"ࠩࠪ㚖"),l11lll_l1_ (u"ࠪࠫ㚗"),l11lll_l1_ (u"ࠫࠬ㚘"),l11lll_l1_ (u"ࠬ࠭㚙"),l11lll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ㚚"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠫ㚛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡼࡆࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㚜"),block,re.DOTALL)
		for link,title in links:
			if link not in l1l11l11l1l_l1_:
				item = (link,title)
				l1l11l11lll_l1_.append(item)
		if len(l1l11l11lll_l1_)==1:
			link,title = l1l11l11lll_l1_[0]
			l1111l_l1_(link,l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㚝"))
			return
		else:
			for link,title in l1l11l11lll_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㚞"),l111ll_l1_+title,link,671,l11lll_l1_ (u"ࠫࠬ㚟"),l11lll_l1_ (u"ࠬ࠭㚠"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㚡"))
	if not l1l11l11lll_l1_: l1111l_l1_(url,l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭㚢"))
	return
#https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1ll1lll1l_l1_?l1l11l1l1l1_l1_=l1l11l1l11l_l1_
#https://www.l1l11l1l111_l1_.com/l11ll1l1l_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1l1l1_l1_=l1l11l1l11l_l1_
def PLAY(url):
	l1lllll1_l1_ = []
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪ࠲ๅ๏๊ๅ࠮ๅิฮํ์࠭ษษิฬ๏࠳แ๋࠯่฾ฬ๋ัส࠯่ฮ้ษไวห࠰้ิฮ࡟ࡥ࠻࠺࠹ࡨࡨ࠷࠶࠵࠱࡬ࡹࡳ࡬ࠨ㚣")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㚤"),url,l11lll_l1_ (u"ࠪࠫ㚥"),l11lll_l1_ (u"ࠫࠬ㚦"),l11lll_l1_ (u"ࠬ࠭㚧"),l11lll_l1_ (u"࠭ࠧ㚨"),l11lll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㚩"))
	html = response.content
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡧ࡮ࡤࡷ࡭ࡶ࡬ࡢࡻࡨࡶࠬ㚪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ㚫"),block,re.DOTALL)
		for link,l11l111l_l1_ in links:
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࡣࡤ࠭㚬")+l11l111l_l1_
			l1lllll1_l1_.append(link)
	# l1l11llll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡨࡪࡪ࠭ࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㚭"),html,re.DOTALL)
	if not links: links = re.findall(l11lll_l1_ (u"ࠧ࡬ࡩ࡭ࡧ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ㚮"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ㚯") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭㚰")+link
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ㚱"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㚲"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㚳"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ㚴"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭㚵"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ㚶"),l11lll_l1_ (u"ࠧࠬࠩ㚷"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ㚸")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ㚹"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ㚺")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㚻"))
	return
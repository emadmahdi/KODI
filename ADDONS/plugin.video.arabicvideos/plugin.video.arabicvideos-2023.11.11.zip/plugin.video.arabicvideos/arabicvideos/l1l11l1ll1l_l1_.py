# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㖋")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡏ࡙࡜࡟ࠨ㖌")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬ㖍")]
def MAIN(mode,url,text):
	if   mode==810: results = MENU()
	elif mode==811: results = l1111l_l1_(url,text)
	elif mode==812: results = PLAY(url)
	elif mode==813: results = l1l11l1ll11_l1_(url)
	elif mode==819: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㖎"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㖏"),l11lll_l1_ (u"࠭ࠧ㖐"),l11lll_l1_ (u"ࠧࠨ㖑"),l11lll_l1_ (u"ࠨࠩ㖒"),l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㖓"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㖔"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㖕"),l11lll_l1_ (u"ࠬ࠭㖖"),819,l11lll_l1_ (u"࠭ࠧ㖗"),l11lll_l1_ (u"ࠧࠨ㖘"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㖙"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㖚"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㖛"),l11lll_l1_ (u"ࠫࠬ㖜"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡳ࡫ࡰࡥࡷࡿ࠭࡭࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡳ࡯ࡴࡶ࠰ࡺ࡮࡫ࡷࡦࡦࠥࠫ㖝"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㖞"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖟"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㖠")+l111ll_l1_+title,link,811)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠩࠪ㖡")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㖢"),l11lll_l1_ (u"ࠫࠬ㖣"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㖤"),url,l11lll_l1_ (u"࠭ࠧ㖥"),l11lll_l1_ (u"ࠧࠨ㖦"),l11lll_l1_ (u"ࠨࠩ㖧"),l11lll_l1_ (u"ࠩࠪ㖨"),l11lll_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㖩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࠥࡪࡴࡵࡴࡦࡴࠥࠫ㖪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㖫"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1llll_l1_,link,title in items:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ㖬"),title,re.DOTALL)
			if l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ㖭") not in type and l1lll11_l1_:
				title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㖮") + l1lll11_l1_[0][0]
				title = title.replace(l11lll_l1_ (u"ࠩส์๋ࠦไศ์้ࠫ㖯"),l11lll_l1_ (u"ࠪࠫ㖰"))
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㖱"),l111ll_l1_+title,link,813,l1llll_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㖲"),l111ll_l1_+title,link,812,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ࠭࠴ࠪࡀࠫࡩࡳࡴࡺࡥࡳࠤ㖳"),html,re.DOTALL)
	if l1l1ll1_l1_:
		type = l11lll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࡡࡳࡥ࡬࡫ࡳࠨ㖴") if l11lll_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ㖵") in type else l11lll_l1_ (u"ࠩࡳࡥ࡬࡫ࡳࠨ㖶")
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㖷"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㖸"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ㖹")+title,link,811,l11lll_l1_ (u"࠭ࠧ㖺"),l11lll_l1_ (u"ࠧࠨ㖻"),type)
	return
def l1l11l1ll11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㖼"),l11lll_l1_ (u"ࠩࠪ㖽"),l1ll1_l1_,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㖾"),url,l11lll_l1_ (u"ࠫࠬ㖿"),l11lll_l1_ (u"ࠬ࠭㗀"),l11lll_l1_ (u"࠭ࠧ㗁"),l11lll_l1_ (u"ࠧࠨ㗂"),l11lll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡗࡊࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ㗃"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡺࡥࡨࡱࡵࡽࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㗄"),html,re.DOTALL)
	if link: l1111l_l1_(link[0],l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㗅"))
	return
def PLAY(url):
	l1lllll1_l1_ = []
	# l11ll1l1l_l1_ links
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㗆"),url,l11lll_l1_ (u"ࠬ࠭㗇"),l11lll_l1_ (u"࠭ࠧ㗈"),l11lll_l1_ (u"ࠧࠨ㗉"),l11lll_l1_ (u"ࠨࠩ㗊"),l11lll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㗋"))
	html = response.content
	post = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ㗌"),html,re.DOTALL)
	post = base64.b64decode(post[0])
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㗍"))
	post = EVAL(l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ㗎"),post)
	links = post[l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡹࠧ㗏")]
	l1l111_l1_ = list(links.keys())
	links = list(links.values())
	l111l1_l1_ = zip(l1l111_l1_,links)
	for title,link in l111l1_l1_:
		link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㗐")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㗑")
		l1lllll1_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㗒"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㗓"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ㗔"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭㗕"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ㗖"),l11lll_l1_ (u"ࠧࠬࠩ㗗"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭㗘")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ㗙"))
	return
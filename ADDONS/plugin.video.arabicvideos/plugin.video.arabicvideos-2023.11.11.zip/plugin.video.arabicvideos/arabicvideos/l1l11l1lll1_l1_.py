# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㕂")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡌࡔࡅࡣࠬ㕃")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㕄"):l11lll_l1_ (u"ࠨࠩ㕅")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l1111l_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㕆"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ㕇"),l11lll_l1_ (u"ࠫࠬ㕈"),329,l11lll_l1_ (u"ࠬ࠭㕉"),l11lll_l1_ (u"࠭ࠧ㕊"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㕋"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㕌"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㕍"),l11lll_l1_ (u"ࠪࠫ㕎"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㕏"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㕐"),l11lll_l1_ (u"࠭ࠧ㕑"),headers,l11lll_l1_ (u"ࠧࠨ㕒"),l11lll_l1_ (u"ࠨࠩ㕓"),l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㕔"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮ࡰ࠯ࡳࡰࡺࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㕕"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㕖"),block,re.DOTALL)
	for link,title in items:
		if title==l11lll_l1_ (u"ࠬอไๆๅอฬฮࠦวๅ็ิส๏ฯࠧ㕗"): continue
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕘"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㕙")+l111ll_l1_+title,link,321)
	return html
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㕚"),l11lll_l1_ (u"ࠩࠪ㕛"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ㕜"),url,l11lll_l1_ (u"ࠫࠬ㕝"),headers,l11lll_l1_ (u"ࠬ࠭㕞"),l11lll_l1_ (u"࠭ࠧ㕟"),l11lll_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ㕠"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ㕡"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡵࡪ࠵ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࡮࠳࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㕢"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㕣"),block,re.DOTALL)
	for link,l1llll_l1_,count,title in items:
		count = count.replace(l11lll_l1_ (u"ࠫ฾ีฯࠡࠩ㕤"),l11lll_l1_ (u"ࠬ࠭㕥")).replace(l11lll_l1_ (u"࠭ࠠࠨ㕦"),l11lll_l1_ (u"ࠧࠨ㕧"))
		link = link.replace(l11lll_l1_ (u"ࠨ࠱ࠪ㕨"),l11lll_l1_ (u"ࠩࠪ㕩"))
		l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠥࠫࠧ㕪"),l11lll_l1_ (u"ࠫࠬ㕫"))
		if l11lll_l1_ (u"ࠬ࠴ࡰࡩࡲࠪ㕬") not in link: link = l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㕭")+link
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ㕮")+link
		l1llll_l1_ = l11ll1_l1_+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ㕯"))
		title = title+l11lll_l1_ (u"ࠩࠣࠬࠬ㕰")+count+l11lll_l1_ (u"ࠪ࠭ࠬ㕱")
		if l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㕲") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕳"),l111ll_l1_+title,link,321,l1llll_l1_)
		elif l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩ㕴") in link: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㕵"),l111ll_l1_+title,link,322,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡴࡺࡥࡳࠩ㕶"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㕷"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ㕸")+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕹"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ㕺")+title,link,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㕻"),url,l11lll_l1_ (u"ࠧࠨ㕼"),headers,l11lll_l1_ (u"ࠨࠩ㕽"),l11lll_l1_ (u"ࠩࠪ㕾"),l11lll_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㕿"))
	html = response.content
	#link = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㖀"),html,re.DOTALL)
	#if not link:
	link = re.findall(l11lll_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㖁"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]#+l11lll_l1_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ㖂")+l1l11l11l_l1_()+l11lll_l1_ (u"ࠧࠧࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂࡺࡲࡶࡧࠪ㖃")
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㖄"))
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"่ࠩาฯอัࠨ㖅")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ㖆"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ㖇"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ㖈"),l11lll_l1_ (u"࠭ࠫࠨ㖉"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ㖊")+search
	l1111l_l1_(url)
	return
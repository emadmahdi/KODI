# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ暐")
#headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ暑"):l11lll_l1_ (u"ࠨࠩ暒")}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨ暓")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺ้ࠪอัฺหࠪ暔"),l11lll_l1_ (u"ࠫอัࠠๆสสุึ࠭暕")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l1111l_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l1llllll_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ暖"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ暗"),l11lll_l1_ (u"ࠧࠨ暘"),l11lll_l1_ (u"ࠨࠩ暙"),l11lll_l1_ (u"ࠩࠪ暚"),l11lll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ暛"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ暜"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠬ࠵ࠧ暝"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ暞"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ暟"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ暠"),l1ll1l1_l1_,489,l11lll_l1_ (u"ࠩࠪ暡"),l11lll_l1_ (u"ࠪࠫ暢"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ暣"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ暤"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭暥"),l11lll_l1_ (u"ࠧࠨ暦"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ暧"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ暨")+l111ll_l1_+l11lll_l1_ (u"ࠪวาีหࠡษ็้ํอึ๋฻ࠪ暩"),l1ll1l1_l1_,481)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩࠣ࡯ࡼࡅࡨࡩ࡯ࡶࡰࡷࠦࠬ暪"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭暫"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"࠭ࠣࠨ暬"): continue
		if title in l1l1l1_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ暭"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ暮")+l111ll_l1_+title,link,481)
	return html
def l1111l_l1_(url,l1lll11l1l1ll_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭暯"),url,l11lll_l1_ (u"ࠪࠫ暰"),l11lll_l1_ (u"ࠫࠬ暱"),l11lll_l1_ (u"ࠬ࠭暲"),l11lll_l1_ (u"࠭ࠧ暳"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭暴"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡳࡸࡺࠨ࠯ࠬࡂ࠭ࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭暵"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ暶"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ暷"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ暸"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ暹"),l11lll_l1_ (u"࠭ร฻่ํอࠬ暺"),l11lll_l1_ (u"ࠧไๆํฬࠬ暻"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ暼"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ暽"),l11lll_l1_ (u"้ࠪออัศหࠪ暾"),l11lll_l1_ (u"ࠫ฾ืึࠨ暿"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ曀"),l11lll_l1_ (u"࠭วๅส๋้ࠬ曁"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧ曂")]
	l1lll11l1ll11_l1_ = l11lll_l1_ (u"ࠨ࠱ࠪ曃").join(l1lll11l1l1ll_l1_.strip(l11lll_l1_ (u"ࠩ࠲ࠫ曄")).split(l11lll_l1_ (u"ࠪ࠳ࠬ曅"))[4:]).split(l11lll_l1_ (u"ࠫ࠲࠭曆"))
	for link,title,l1llll_l1_ in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤา๊โสࠢ࡟ࡨ࠰࠭曇"),title,re.DOTALL)
		if l1lll11l1l1ll_l1_:
			l1lllllll1_l1_ = l11lll_l1_ (u"࠭࠯ࠨ曈").join(link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ曉")).split(l11lll_l1_ (u"ࠨ࠱ࠪ曊"))[4:]).split(l11lll_l1_ (u"ࠩ࠰ࠫ曋"))
			l1lll11l1ll1l_l1_ = len([x for x in l1lll11l1ll11_l1_ if x in l1lllllll1_l1_])
			if l1lll11l1ll1l_l1_>2 and l11lll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ曌") in link:
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ曍"),l111ll_l1_+title,link,482,l1llll_l1_)
		else:
			if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ曎"),title,re.DOTALL)
			#if any(value in title for value in l1lll1_l1_):
			if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"࠭ๅิๆึ่ࠬ曏") not in title:
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭曐"),l111ll_l1_+title,link,482,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠨฯ็ๆฮ࠭曑") in title:
				title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ曒") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ曓"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"ࠫࠬ曔"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曕"),l111ll_l1_+title,link,483,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ曖"),url)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠢࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠥ曗"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࠨ曘"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠩสฺ่็อสࠢࠪ曙"),l11lll_l1_ (u"ࠪࠫ曚"))
			if title!=l11lll_l1_ (u"ࠫࠬ曛"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曜"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ曝")+title,link,481,l11lll_l1_ (u"ࠧࠨ曞"),l11lll_l1_ (u"ࠨࠩ曟"),l1lll11l1l1ll_l1_)
	return
def l1llllll_l1_(url,l11l11l_l1_):
	headers = {l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ曠"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ曡")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ曢"),url,l11lll_l1_ (u"ࠬ࠭曣"),headers,l11lll_l1_ (u"࠭ࠧ曤"),l11lll_l1_ (u"ࠧࠨ曥"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ曦"))
	html = response.content
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭曧"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡮ࡳࡧ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ曨"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ曩"))
	l1lll11l1l1l1_l1_ = True
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡬ࡪࡵࡷࡗࡪࡧࡳࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ曪"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠭曫") not in url:
		block = l1l1l11_l1_[0]
		count = block.count(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠫ曬"))
		if count==0: count = block.count(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠧ曭"))
		if count>1:
			l1lll11l1l1l1_l1_ = False
			if l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂࠨࠧ曮") in block:
				items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵ࡯ࡹ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ曯"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠸࠮ࡱࡪࡳࡃࡸࡲࡵࡨ࠿ࠪ曰")+id
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曱"),l111ll_l1_+title,link,483,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ曲"),block,re.DOTALL)
				for id,title in items:
					link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡼ࡯࠳࠲࠵࠵࠴ࡺࡥ࡮ࡲ࠲ࡥ࡯ࡧࡸ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠰ࡳ࡬ࡵࡅࡳࡦࡴ࡬ࡩࡸࡏࡄ࠾ࠩ曳")+id
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ更"),l111ll_l1_+title,link,483,l1llll_l1_)
	# l1l1l_l1_
	if l1lll11l1l1l1_l1_:
		block = l11lll_l1_ (u"ࠩࠪ曵")
		if l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ曶") in url: block = html
		else:
			l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡫ࡰ࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ曷"),html,re.DOTALL)
			if l1l11ll_l1_: block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ書"),block,re.DOTALL)
		if items:
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ曹"))
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭曺"),l111ll_l1_+title,link,482,l1llll_l1_)
	if not menuItemsLIST: l1111l_l1_(l11l11l_l1_,url)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠨ࠱ࠪ曻"))+l11lll_l1_ (u"ࠩ࠲ࡃࡩࡵ࠽ࡸࡣࡷࡧ࡭࠭曼")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ曽"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ曾"),l11lll_l1_ (u"ࠬ࠭替"),l11lll_l1_ (u"࠭ࠧ最"),l11lll_l1_ (u"ࠧࠨ朁"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ朂"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭會"))
	l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡺࡴࡥࡰࡰࡵࡷࡍࡉࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ朄"),html,re.DOTALL)
	if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡡ࠮ࡴࡩ࡫ࡶࡠ࠳࡯ࡤ࡝࠮࠳ࡠ࠱࠮࠮ࠫࡁࠬࡠ࠮࠭朅"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ朆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ朇"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ月"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱࡬ࡪࡷࡧ࡭ࡦ࠴࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫ有")+l1ll1llll1_l1_+l11lll_l1_ (u"ࠩࠩࡺ࡮ࡪࡥࡰ࠿ࠪ朊")+l1lll111l1_l1_[2:]+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ朋")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ朌")
			l1111_l1_.append(link)
	# l1l11llll_l1_ l11ll1l1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠬࠨࡧࡦࡶࡈࡱࡧ࡫ࡤࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ服"),html,re.DOTALL)
	if link:
		title = SERVER(link[0],l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ朎"))
		link = link[0]+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ朏")+title+l11lll_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩ朐")
		l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠩ࠲ࠫ朑"))+l11lll_l1_ (u"ࠪ࠳ࡄࡪ࡯࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ朒")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ朓"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭朔"),l11lll_l1_ (u"࠭ࠧ朕"),l11lll_l1_ (u"ࠧࠨ朖"),l11lll_l1_ (u"ࠨࠩ朗"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭朘"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡹࡧࡢ࡭ࡧ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ朙"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭朚"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ望"))
			if l11lll_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ朜") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠧࡠࡡัหฺ࠭朝")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠨࠩ朞")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ期")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ朠")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ朡"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ朢"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"࠭ࠧ朣")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ朤"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ朥"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ朦"),l11lll_l1_ (u"ࠪ࠯ࠬ朧"))
	if l1ll1l1_l1_==l11lll_l1_ (u"ࠫࠬ木"): l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ朩")+search+l11lll_l1_ (u"࠭࠯ࠨ未")
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࠨ末"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡤ࠯࠶࡫ࡩࡱࡧ࡬࠯ࡶࡹࠫ᪻")
#l11ll1_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠴ࡩࡧ࡯ࡥࡱ࠴ࡴࡷࠩ᪼")
#l11ll1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࠹࡮ࡥ࡭ࡣ࡯࠲ࡹࡼ᪽ࠧ")
script_name = l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ᪾")
headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸᪿࠬ") : l11lll_l1_ (u"ᫀࠩࠪ") }
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡈࡓࡆࡠࠩ᫁")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1lllll1l_l1_()
	elif mode==95: results = l1llllll_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᫂"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽᫃ࠬ"),l11lll_l1_ (u"᫄࠭ࠧ"),99,l11lll_l1_ (u"ࠧࠨ᫅"),l11lll_l1_ (u"ࠨࠩ᫆"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᫇"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᫈"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᫉"),l11lll_l1_ (u"᫊ࠬ࠭"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫋"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᫌ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧᫍ"),l11lll_l1_ (u"ࠩࠪᫎ"),94)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᫏"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᫐")+l111ll_l1_+l11lll_l1_ (u"ࠬอไฤฯาฯࠬ᫑"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡢࡶࡨࡷࡹ࠭᫒"),91)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᫓"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᫔")+l111ll_l1_+l11lll_l1_ (u"ࠩส่ศ฿ไ๊ࠢอๆ๏๋ว์ࠩ᫕"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀ࡭ࡲࡪࡢࠨ᫖"),91)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᫗"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᫘")+l111ll_l1_+l11lll_l1_ (u"࠭วๅลๆฯึࠦๅีษ๊ำฮ࠭᫙"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡷ࡫ࡨࡻࠬ᫚"),91)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᫛"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᫜")+l111ll_l1_+l11lll_l1_ (u"ࠪห้๋หษฬࠪ᫝"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡵ࡯࡮ࠨ᫞"),91)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᫟"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᫠")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭᫡"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡰࡨࡻࡒࡵࡶࡪࡧࡶࠫ᫢"),91)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫣"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᫤")+l111ll_l1_+l11lll_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ᫥"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡴࡥࡸࡇࡳ࡭ࡸࡵࡤࡦࡵࠪ᫦"),91)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᫧"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᫨"),l11lll_l1_ (u"ࠨࠩ᫩"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫪"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᫫")+l111ll_l1_+l11lll_l1_ (u"ࠫัี๊ะࠢส่๊๎โฺࠩ᫬"),l11ll1_l1_,91)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭᫭"),headers,l11lll_l1_ (u"࠭ࠧ᫮"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᫯"))
	#upper menu
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡤ࡭ࡳࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࡯ࡣࡹࠫ᫰"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᫱"),block,re.DOTALL)
	l1l1l1_l1_ = [l11lll_l1_ (u"ࠪหๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭᫲")]
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭᫳"))
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᫴"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᫵")+l111ll_l1_+title,link,91)
	return html
def ITEMS(url):
	if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࠬ᫶") in url:
		url,search = url.split(l11lll_l1_ (u"ࠨࡁࡷࡁࠬ᫷"))
		headers = { l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᫸") : l11lll_l1_ (u"ࠪࠫ᫹") , l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ᫺") : l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ᫻") }
		data = { l11lll_l1_ (u"࠭ࡴࠨ᫼") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ᫽"),url,data,headers,l11lll_l1_ (u"ࠨࠩ᫾"),l11lll_l1_ (u"ࠩࠪ᫿"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨᬀ"))
		html = response.content
	else:
		headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᬁ") : l11lll_l1_ (u"ࠬ࠭ᬂ") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧᬃ"),headers,l11lll_l1_ (u"ࠧࠨᬄ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡍ࡙ࡋࡍࡔ࠯࠵ࡲࡩ࠭ᬅ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠳ࡩࡵࡧࡰࡷ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺࡦࡰࡱࡷࠦࠬᬆ"),html,re.DOTALL)
	if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	else: block = l11lll_l1_ (u"ࠪࠫᬇ")
	items = re.findall(l11lll_l1_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡰࡳࡻ࡯ࡥ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᬈ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠬอไฮๆๅอࠬᬉ") in title and l11lll_l1_ (u"࠭࠯ࡤ࠱ࠪᬊ") not in url and l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸ࠴࠭ᬋ") not in url:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡜࠲࠰࠽ࡢ࠱ࠧᬌ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᬍ")+l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᬎ"),l111ll_l1_+title,link,95,l1llll_l1_)
					l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬᬏ") in link: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᬐ"),l111ll_l1_+title,link,92,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬑ"),l111ll_l1_+title,link,91,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᬒ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᬓ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠩสฺ่็อสࠢࠪᬔ"),l11lll_l1_ (u"ࠪࠫᬕ"))
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬖ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫᬗ")+title,link,91)
	return
def l1llllll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧᬘ"),headers,l11lll_l1_ (u"ࠧࠨᬙ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᬚ"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᬛ"),html,re.DOTALL)
	l1llll_l1_ = l1llll_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡦࡲ࡬ࡷࡴࡪࡥࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᬜ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		name = re.findall(l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᬝ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ᬞ"))
			if l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᬟ") in name: name = name.split(l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᬠ"),1)[1]
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᬡ"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᬢ"),l111ll_l1_+name+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧᬣ")+title,link,92,l1llll_l1_)
	else:
		tmp = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࡷ࡭ࡹࡲࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᬤ"),html,re.DOTALL)
		if tmp: link,title = tmp[0]
		else: link,title = url,name
		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᬥ"),l111ll_l1_+title,link,92,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1ll1ll1l1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧᬦ"),headers,l11lll_l1_ (u"ࠧࠨᬧ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᬨ"))
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡷࡩࡽࡺ࠭ࡴࡪࡤࡨࡴࡽ࠺ࠡࡰࡲࡲࡪࡁࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᬩ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࡸ࠳ࡰࡢࡰࡨࡰ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᬪ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᬫ"),block,re.DOTALL)
		for link in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᬬ")
			l1111_l1_.append(link)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡮ࡢࡸ࠰ࡸࡦࡨࡳࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࠲ࡶࡡ࡯ࡧ࡯࠱ࡲࡵࡲࡦࠩᬭ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l11ll1l1l_l1_ links
		items = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡥ࡮ࡤࡨࡨࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᬮ"),block,re.DOTALL)
		for id,link in items:
			title = l11lll_l1_ (u"ࠨีํีๆืࠠࠨᬯ")+id
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᬰ")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᬱ")
			l1111_l1_.append(link)
		# other links
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᬲ"),block,re.DOTALL)
		for link in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᬳ") not in link: link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾᬴ࠬ")+link
			link = l111l_l1_(link)
			l1111_l1_.append(link)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᬵ"),url)
	return
def l1lllll1l_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᬶ"),headers,l11lll_l1_ (u"ࠩࠪᬷ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩᬸ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡫ࡱࡨࡪࡾ࠭࡭ࡣࡶࡸ࠲ࡳ࡯ࡷ࡫ࡨࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡯࡮ࡥࡧࡻ࠱ࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࠪᬹ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᬺ"),block,re.DOTALL)
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࠧᬻ") in link: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᬼ"),l111ll_l1_+title,link,92,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬽ"),l111ll_l1_+title,link,91,l1llll_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪᬾ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫᬿ"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭ᭀ"),l11lll_l1_ (u"ࠬ࠱ࠧᭁ"))
	url = l11ll1_l1_ + l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡹࡃࠧᭂ")+search
	ITEMS(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ♵")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡋࡂ࠵ࡡࠪ♶")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1lllll1l11_l1_-l1lllll1111_l1_.net
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l111l11l1l_l1_.l1lll1l1111_l1_
# l1lll1ll111_l1_	https://t.me/l1lll11lll1_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอ๊อ์ࠣฬุะࠧ♷"),l11lll_l1_ (u"࠭วหื็ࠤอ์วࠨ♸"),l11lll_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่ฬ฻ไ๋ࠩ♹"),l11lll_l1_ (u"ࠨษํะ๏ࠦศิฬࠣห้าฯ๋ัࠪ♺"),l11lll_l1_ (u"ࠩส๎ั๐ࠠษีอࠤฬ๊ศะ์็ࠫ♻"),l11lll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ♼"),l11lll_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษีอࠫ♽")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==800: results = MENU()
	elif mode==801: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==802: results = l1l11l_l1_(url)
	elif mode==803: results = PLAY(url)
	elif mode==804: results = l1lll1l11ll_l1_(url)
	elif mode==806: results = l1lll1l1l1_l1_(url,l1l11l1_l1_)
	elif mode==809: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♾"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭♿"),l11lll_l1_ (u"ࠧࠨ⚀"),809,l11lll_l1_ (u"ࠨࠩ⚁"),l11lll_l1_ (u"ࠩࠪ⚂"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⚃"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚄"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠪ⚅"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ⚆"),804,l11lll_l1_ (u"ࠧࠨ⚇"),l11lll_l1_ (u"ࠨࠩ⚈"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⚉"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⚊"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⚋"),l11lll_l1_ (u"ࠬ࠭⚌"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⚍"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ⚎"),l11lll_l1_ (u"ࠨࠩ⚏"),l11lll_l1_ (u"ࠩࠪ⚐"),l11lll_l1_ (u"ࠪࠫ⚑"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⚒"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡴࡡࡷ࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⚓"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⚔"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ⚕"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⚖") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚗"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⚘")+l111ll_l1_+title,link,801)
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⚙"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⚚"),l11lll_l1_ (u"࠭ࠧ⚛"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫ࠿ࡪࡴࡵࡴࡦࡴࡁࠫ⚜"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⚝"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⚞"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⚟") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⚠"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⚡")+l111ll_l1_+title,link,801,l11lll_l1_ (u"࠭ࠧ⚢"),l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠩ⚣"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⚤"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⚥"),l11lll_l1_ (u"ࠪࠫ⚦"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⚧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⚨"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ⚩"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⚪") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⚫"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⚬")+l111ll_l1_+title,link,801)
	return html
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠪࠫ⚭")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⚮"),l11lll_l1_ (u"ࠬ࠭⚯"),type,url)
	#if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⚰") in url: type = l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⚱")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⚲"),url,l11lll_l1_ (u"ࠩࠪ⚳"),l11lll_l1_ (u"ࠪࠫ⚴"),l11lll_l1_ (u"ࠫࠬ⚵"),l11lll_l1_ (u"ࠬ࠭⚶"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⚷"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࡙࡯ࡴ࡭ࡧ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࠨ⚸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠨࠩ⚹"),l11lll_l1_ (u"ࠩࠪ⚺"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠪั้่วหࠩ⚻") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"๊ࠫ๎วิ็ࠪ⚼") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⚽"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⚾"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⚿"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⛀"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⛁"),l111ll_l1_+title,link,803,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⛂"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⛃"),l111ll_l1_+title,link,803)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠬ࠭⛄")):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ⛅"),l11lll_l1_ (u"ࠧࠨ⛆"),l11lll_l1_ (u"ࠨࡖࡌࡘࡑࡋࡓࠨ⛇"),url)
	limit,start,l11lllll1_l1_,select,l1lll1l1ll1_l1_ = 0,0,l11lll_l1_ (u"ࠩࠪ⛈"),l11lll_l1_ (u"ࠪࠫ⛉"),l11lll_l1_ (u"ࠫࠬ⛊")
	if l11lll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ⛋") in type:
		# next l1l11l1_l1_
		l1lll1ll1l1_l1_,l11llll11_l1_ = url.split(l11lll_l1_ (u"࠭࠿࡯ࡧࡻࡸࡂࡶࡡࡨࡧࠩࠫ⛌"))
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⛍"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ⛎")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⛏"),l1lll1ll1l1_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ⛐"),l11lll_l1_ (u"ࠫࠬ⛑"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⛒"))
		html = response.content
		l11lll1l_l1_ = l11lll_l1_ (u"࠭ࡳࡦࡥࡆࡳࡳࡺࡥ࡯ࡶࠪ⛓")+html+l11lll_l1_ (u"ࠧ࠽ࡨࡲࡳࡹ࡫ࡲ࠿ࠩ⛔")
	else:
		# l11ll11l1l_l1_ html
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⛕"),url,l11lll_l1_ (u"ࠩࠪ⛖"),l11lll_l1_ (u"ࠪࠫ⛗"),l11lll_l1_ (u"ࠫࠬ⛘"),l11lll_l1_ (u"ࠬ࠭⛙"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ⛚"))
		html = response.content
		l11lll1l_l1_ = html
	items,l1lllll1l1l_l1_,filters = [],False,False
	if not type and l11lll_l1_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲࡸ࠭⛛") not in url:
		# l1lllll1l1l_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⛜"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⛝"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⛞"))
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛟"),l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠬ࠭⛠"),l11lll_l1_ (u"࠭ࡳࡶࡤࡰࡩࡳࡻࠧ⛡"))
				l1lllll1l1l_l1_ = True
	if not l1lllll1l1l_l1_:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡧࡦࡇࡴࡴࡴࡦࡰࡷࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳࡉ࡯࡯ࡶࡨࡲࡹ࠭⛢"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱ࡬ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⛣"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				link = l111l_l1_(link)
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠩ࡟ࡲࠬ⛤"))
				title = unescapeHTML(title)
				if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⛥") in link and type==l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ⛦"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛧"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭⛨"))
				elif l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⛩") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⛪"),l111ll_l1_+title,link,806,l1llll_l1_)
				elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ⛫") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⛬"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ⛭"))
				elif l11lll_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠫ⛮") in url: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛯"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"ࠧࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷࠬ⛰"))
				else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⛱"),l111ll_l1_+title,link,803,l1llll_l1_)
		# l1lll1lll1_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡯ࡳࡦࡪࡍࡰࡴࡨࡔࡦࡸࡡ࡮ࡵࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿ࠬ⛲"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			params = EVAL(l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⛳"),block)
			l1lll1l1ll1_l1_ = params[l11lll_l1_ (u"ࠫࡦࡰࡡࡹࡷࡵࡰࠬ⛴")]
			l1lll11ll1l_l1_ = int(params[l11lll_l1_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡰࡢࡩࡨࠫ⛵")])+1
			l1lll11ll11_l1_ = int(params[l11lll_l1_ (u"࠭࡭ࡢࡺࡢࡴࡦ࡭ࡥࠨ⛶")])
			query = params[l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡸ࠭⛷")].replace(l11lll_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ⛸"),l11lll_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ⛹")).replace(l11lll_l1_ (u"ࠪࡘࡷࡻࡥࠨ⛺"),l11lll_l1_ (u"ࠫࡹࡸࡵࡦࠩ⛻")).replace(l11lll_l1_ (u"ࠬࡔ࡯࡯ࡧࠪ⛼"),l11lll_l1_ (u"࠭࡮ࡶ࡮࡯ࠫ⛽"))
			if l1lll11ll1l_l1_<l1lll11ll11_l1_:
				l11llll11_l1_ = l11lll_l1_ (u"ࠧࡢࡥࡷ࡭ࡴࡴ࠽࡭ࡱࡤࡨࡲࡵࡲࡦࠨࡴࡹࡪࡸࡹ࠾ࠩ⛾")+QUOTE(query,l11lll_l1_ (u"ࠨࠩ⛿"))+l11lll_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ✀")+str(l1lll11ll1l_l1_)
				l11l11l_l1_ = l1lll1l1ll1_l1_+l11lll_l1_ (u"ࠪࡃࡳ࡫ࡸࡵ࠿ࡳࡥ࡬࡫ࠦࠨ✁")+l11llll11_l1_
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ✂"),l111ll_l1_+l11lll_l1_ (u"ࠬาไษࠢสุ่๊๊ะࠩ✃"),l11l11l_l1_,801,l11lll_l1_ (u"࠭ࠧ✄"),l11lll_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࡣࠬ✅")+type)
		elif l11lll_l1_ (u"ࠨࡁࡱࡩࡽࡺ࠽ࡱࡣࡪࡩࠫ࠭✆") in url:
			l11llll11_l1_,l1ll11l1l_l1_ = l11llll11_l1_.rsplit(l11lll_l1_ (u"ࠩࡀࠫ✇"),1)
			l1ll11l1l_l1_ = int(l1ll11l1l_l1_)+1
			l11l11l_l1_ = l1lll1ll1l1_l1_+l11lll_l1_ (u"ࠪࡃࡳ࡫ࡸࡵ࠿ࡳࡥ࡬࡫ࠦࠨ✈")+l11llll11_l1_+l11lll_l1_ (u"ࠫࡂ࠭✉")+str(l1ll11l1l_l1_)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✊"),l111ll_l1_+l11lll_l1_ (u"࠭ฬๅสࠣห้๋า๋ัࠪ✋"),l11l11l_l1_,801,l11lll_l1_ (u"ࠧࠨ✌"),l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࡤ࠭✍")+type)
	return
def l1lll1l11ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭✎"),url,l11lll_l1_ (u"ࠪࠫ✏"),l11lll_l1_ (u"ࠫࠬ✐"),l11lll_l1_ (u"ࠬ࠭✑"),l11lll_l1_ (u"࠭ࠧ✒"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ✓"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡸࡦࡤࡴࡡࡷࠪ࠱࠮ࡄ࠯ࡳࡦࡥࡆࡳࡳࡺࡥ࡯ࡶࠣࠫ✔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & options block
		l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡺࡸࡲࡦࡰࡷࡣࡴࡶࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭✕"),block,re.DOTALL)
		for name,block in l111l11_l1_:
			if l11lll_l1_ (u"ࠪห้ะี็์ไࠫ✖") in name: continue
			name = name.strip(l11lll_l1_ (u"ࠫࠥ࠭✗"))
			# link & value
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ✘"),block,re.DOTALL)
			for link,value in items:
				title = name+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ✙")+value
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✚"),l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠨࠩ✛"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩ✜"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ✝"),url,l11lll_l1_ (u"ࠫࠬ✞"),l11lll_l1_ (u"ࠬ࠭✟"),l11lll_l1_ (u"࠭ࠧ✠"),l11lll_l1_ (u"ࠧࠨ✡"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ✢"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡸࡩࡄวๅฬุ๊๏็࠼࠰ࡶࡧࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ✣"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l11ll1l1l_l1_ links
	l1lll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡆ࡯ࡥࡩࡩ࠴ࠪࡀࡲࡲࡷࡹࡃࠨ࠯ࠬࡂ࠭ࠧ࠭✤"),html,re.DOTALL)
	if l1lll1llll1_l1_:
		links = base64.b64decode(l1lll1llll1_l1_[0])
		if kodi_version>18.99: links = links.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ✥"))
		links = EVAL(l11lll_l1_ (u"ࠬࡪࡩࡤࡶࠪ✦"),links)
		links = list(links.values())
		for link in links:
			if link not in l1lll11ll1_l1_:
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ✧"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ✨")+server+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ✩"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࡄࡰࡹࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ✪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡀࡹࡸ࠾࠯ࠬࡂࡀࡹࡪ࠾࡜ࠢࡤ࠱ࡿࡇ࡛࠭࡟࠭ࠬࡡࡪࡻ࠴࠮࠷ࢁ࠮ࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ✫"),block,re.DOTALL)
		for l11l111l_l1_,link in items:
			if link not in l1lll11ll1_l1_:
				if l11lll_l1_ (u"ࠫ࠴ࡅࡵࡳ࡮ࡀࠫ✬") in link: link = link.split(l11lll_l1_ (u"ࠬ࠵࠿ࡶࡴ࡯ࡁࠬ✭"))[1]
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ✮"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ✯")+server+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ✰")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ✱"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ✲"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠫࠥ࠭✳"),l11lll_l1_ (u"ࠬ࠱ࠧ✴"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡀࡵࡀࠫ✵")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ✶"))
	return
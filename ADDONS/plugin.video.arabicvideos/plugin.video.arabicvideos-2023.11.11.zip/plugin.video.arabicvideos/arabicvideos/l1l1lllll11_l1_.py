# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩⷾ")
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬⷿ"):l11lll_l1_ (u"ࠩࠪ⸀")}
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡋࡎ࠱ࡠࠩ⸁")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://www.faselhd.l1ll1ll1l1l_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/faselhd.l1lll1111l_l1_
# l1llll1ll11_l1_	https://www.l1llll1ll11_l1_.com/faselhd
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1l1llll11l_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫั๎ววิࠣห้ษ่ิๅสีࠬ⸂"),l11lll_l1_ (u"ࠬอไๆำสะ฾อสࠨ⸃"),l11lll_l1_ (u"࠭ࡷࡸࡧࠪ⸄")]
def MAIN(mode,url,text):
	if   mode==570: results = MENU()
	elif mode==571: results = l1111l_l1_(url,text)
	elif mode==572: results = PLAY(url)
	elif mode==573: results = l1lll1l1l1_l1_(url,text)
	#elif mode==574: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ⸅")+text)
	#elif mode==575: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ⸆")+text)
	elif mode==579: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ⸇"):l1ll1l1_l1_,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⸈"):l1l11l11l_l1_(False)}
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭⸉"),l11lll_l1_ (u"ࠬ็วึๆࠣษ฾๊ว็์ࠪ⸊"),l11lll_l1_ (u"࠭ࡤࡶࡤࡥࡩࡩ࠳࡭ࡰࡸ࡬ࡩࡸ࠭⸋"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸌"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⸍"),l1ll1l1_l1_,579,l11lll_l1_ (u"ࠩࠪ⸎"),l11lll_l1_ (u"ࠪࠫ⸏"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⸐"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸑"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⸒"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ⸓"),574)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸔"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⸕"),l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ⸖"),575)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⸗"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⸘"),l11lll_l1_ (u"࠭ࠧ⸙"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸚"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩ⸛"),l1ll1l1_l1_,571,l11lll_l1_ (u"ࠩࠪ⸜"),l11lll_l1_ (u"ࠪࠫ⸝"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⸞"))
	items = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠳ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⸟"),html,re.DOTALL)
	if not items:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ⸠"),l11lll_l1_ (u"ࠧࠨ⸡"),l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬาࠠะ์ࠣ์ฬำฯࠨ⸢"),l11lll_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬ⸣"))
		return
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸤"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⸥")+l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠬ࠭⸦"),l11lll_l1_ (u"࠭ࠧ⸧"),l11lll_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠲ࠩ⸨"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡱࡴ࡬ࡱࡦࡸࡹࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⸩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1llll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡰ࡮ࠦࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ⸪"),block,re.DOTALL)
		l1l1llll111_l1_ = [l11lll_l1_ (u"ࠪࠫ⸫"),l11lll_l1_ (u"ࠫศ็ไศ็࠽ࠤࠬ⸬"),l11lll_l1_ (u"๋ࠬำๅี็หฯࡀࠠࠨ⸭"),l11lll_l1_ (u"࠭ศาษ่ะ࠿ࠦࠧ⸮"),l11lll_l1_ (u"ࠧรีํ์๏ࡀࠠࠨⸯ"),l11lll_l1_ (u"ࠨล้้๏ࡀࠠࠨ⸰")]
		l11l1lllll_l1_ = 0
		for menu in l1llll11l1_l1_:
			if l11l1lllll_l1_>0: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⸱"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⸲"),l11lll_l1_ (u"ࠫࠬ⸳"),9999)
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⸴"),menu,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ⸵"): continue
				if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⸶") not in link: link = l1ll1l1_l1_+link
				if title==l11lll_l1_ (u"ࠨࠩ⸷"): continue
				if any(value in title.lower() for value in l1l1l1_l1_): continue
				title = l1l1llll111_l1_[l11l1lllll_l1_]+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸸"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⸹")+l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠫࠬ⸺"),l11lll_l1_ (u"ࠬ࠭⸻"),l11lll_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨ⸼"))
			l11l1lllll_l1_ += 1
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠧࠨ⸽")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⸾"),l11lll_l1_ (u"ࠩࠪ⸿"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ⹀"):url,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⹁"):l1l11l11l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⹂"),url,l11lll_l1_ (u"࠭ࠧ⹃"),l11lll_l1_ (u"ࠧࠨ⹄"),l11lll_l1_ (u"ࠨࠩ⹅"),l11lll_l1_ (u"ࠩࠪ⹆"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⹇"))
	html = response.content
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࠺ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⹈"),html,re.DOTALL)
	if not l1l11ll_l1_: return
	if type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⹉"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"࠭࡜࡝࠱ࠪ⹊"),l11lll_l1_ (u"ࠧ࠰ࠩ⹋")).replace(l11lll_l1_ (u"ࠨ࡞࡟ࠦࠬ⹌"),l11lll_l1_ (u"ࠩࠥࠫ⹍"))]
	elif type==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⹎"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧࡖࡰ࡮ࡪࡥࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⹏"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⹐"),block,re.DOTALL)
		l1l1l1lll_l1_,links,l1l111_l1_ = zip(*items)
		items = zip(links,l1l1l1lll_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠳ࠩ⹑"):
		title,block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠢࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⹒"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨࡦࡨࡸࡦ࡯࡬ࡴ࠴ࠪ⹓") and len(l1l11ll_l1_)>1:
		title = l1l11ll_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹔"),l111ll_l1_+title,url,571,l11lll_l1_ (u"ࠪࠫ⹕"),l11lll_l1_ (u"ࠫࠬ⹖"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࠲ࠨ⹗"))
		title = l1l11ll_l1_[1][0]
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹘"),l111ll_l1_+title,url,571,l11lll_l1_ (u"ࠧࠨ⹙"),l11lll_l1_ (u"ࠨࠩ⹚"),l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠶ࠫ⹛"))
		return
	else:
		title,block = l1l11ll_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦ࡭࠷ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⹜"),block,re.DOTALL)
	#l1lll1_l1_ = [l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫ⹝"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ⹞"),l11lll_l1_ (u"࠭ว฻่ํอࠬ⹟"),l11lll_l1_ (u"ࠧไๆํฬࠬ⹠"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ⹡"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ⹢"),l11lll_l1_ (u"้ࠪออัศหࠪ⹣"),l11lll_l1_ (u"ࠫ฾ืึࠨ⹤"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ⹥"),l11lll_l1_ (u"࠭วๅส๋้ࠬ⹦"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧ⹧")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		l1llll_l1_ = escapeUNICODE(l1llll_l1_)
		l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠨࡁࡵࡩࡸ࡯ࡺࡦ࠿ࠪ⹨"))[0]
		title = unescapeHTML(title)
		#title = escapeUNICODE(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⹩"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮ࡴ࠱ࠪ⹪") in link:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹫"),l111ll_l1_+title,link,571,l1llll_l1_)
		#elif any(value in title for value in l1lll1_l1_):
		#	addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⹬"),l111ll_l1_+title,link,572,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"࠭ࠧ⹭"):
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⹮")+l1lll11_l1_[0][0]
			title = title.strip(l11lll_l1_ (u"ࠨࠢ⠖ࠫ⹯"))
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹰"),l111ll_l1_+title,link,573,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭⹱") in link or l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶ࠳ࠬ⹲") in link or l11lll_l1_ (u"ࠬ࡮ࡩ࡯ࡦ࡬࠳ࠬ⹳") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⹴"),l111ll_l1_+title,link,572,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹵"),l111ll_l1_+title,link,573,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⹶"):
		l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ⹷"),block,re.DOTALL)
		if l1lll11ll1l_l1_:
			count = l1lll11ll1l_l1_[0]
			link = url+l11lll_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ⹸")+count
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹹"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ⹺"),link,571,l11lll_l1_ (u"࠭ࠧ⹻"),l11lll_l1_ (u"ࠧࠨ⹼"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⹽"))
	elif l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵࠪ⹾") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠦ⹿"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨ⺀"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ⺁")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺂"),l111ll_l1_+title,link,571,l11lll_l1_ (u"ࠧࠨ⺃"),l11lll_l1_ (u"ࠨࠩ⺄"),l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠷ࠫ⺅"))
	return
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠪࠫ⺆")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⺇"),url,l11lll_l1_ (u"ࠬ࠭⺈"),l11lll_l1_ (u"࠭ࠧ⺉"),l11lll_l1_ (u"ࠧࠨ⺊"),l11lll_l1_ (u"ࠨࠩ⺋"),l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴࠱ࡘࡋࡁࡔࡑࡑࡗࡤࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⺌"))
	html = response.content
	#link = l11lll_l1_ (u"ࠪࠫ⺍")
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡹࡥࡢࡵࡲࡲࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ⺎"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࠣࡁࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࠤࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⺏"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⺐"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,name,title in items:
					name = unescapeHTML(name)
					if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⺑") not in link: link = l1ll1l1_l1_+link
					title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ⺒")+title
					addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⺓"),l111ll_l1_+title,link,573,l1llll_l1_,l11lll_l1_ (u"ࠪࠫ⺔"),l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⺕"))
	if type==l11lll_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ⺖") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡱࡶࡸࡪࡸࡉ࡮ࡩࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺗"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"ࠧࠨ⺘")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡨࡴࡆࡲ࡬ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⺙"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⺚"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⺛"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⺜"),l111ll_l1_+title,link,572,l1llll_l1_)
	#if not link: l1111l_l1_(url)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1llll1ll_l1_,l1l1lllll1l_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⺝"),url,l11lll_l1_ (u"࠭ࠧ⺞"),l11lll_l1_ (u"ࠧࠨ⺟"),l11lll_l1_ (u"ࠨࠩ⺠"),l11lll_l1_ (u"ࠩࠪ⺡"),l11lll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⺢"))
	html = response.content
	l1l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ู๊ࠫส้๋ࠣห้๋ิศ้าอ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ⺣"),html,re.DOTALL)
	if l1l1lll1lll_l1_:
		l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡢࡩࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⺤"),html,re.DOTALL)
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡘ࡯ࡸࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⺥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⺦"),block,re.DOTALL)
		for link in items:
			link = link.split(l11lll_l1_ (u"ࠨࠨ࡬ࡱ࡬ࡃࠧ⺧"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ⺨"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡹࡸࡥࡢ࡯ࡋࡩࡦࡪࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⺩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠦ࡭ࡸࡥࡧࠢࡀࠤࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ⺪"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"ࠬࠬࡩ࡮ࡩࡀࠫ⺫"))[0]
			name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ⺬"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⺭")+name+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⺮"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡐ࡮ࡴ࡫ࡴࠪ࠱࠮ࡄ࠯ࡢ࡭ࡣࡦ࡯ࡼ࡯࡮ࡥࡱࡺࠫ⺯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⺰"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l11lll_l1_ (u"ࠫࠫ࡯࡭ࡨ࠿ࠪ⺱"))[0]
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⺲")+name+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⺳"))
	for l1l1llll1l1_l1_ in l1lllll1_l1_:
		link,name = l1l1llll1l1_l1_.split(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪࠧ⺴"))
		if link not in l1l1llll1ll_l1_:
			l1l1llll1ll_l1_.append(link)
			l1l1lllll1l_l1_.append(l1l1llll1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅ็้หุฮࠧ⺵"), l1l1lllll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1lllll1l_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⺶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ⺷"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ⺸"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ⺹"),l11lll_l1_ (u"࠭ࠫࠨ⺺"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⺻")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠨࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ⺼"),l11lll_l1_ (u"ࠩไหฺ๊ࠠฦ฻็ห๋๐ࠧ⺽"),l11lll_l1_ (u"ࠪࡨࡺࡨࡢࡦࡦ࠰ࡱࡴࡼࡩࡦࡵࠪ⺾"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠺࠭⺿"))
	return
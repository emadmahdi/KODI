# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ⻀")
headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⻁"):l11lll_l1_ (u"ࠧࠨ⻂")}
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡉࡌ࠷ࡥࠧ⻃")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1l1lll11ll_l1_.faselhd.l1l1lll1l1l_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/faselhd.l1lll1111l_l1_
# l1llll1ll11_l1_	https://www.l1llll1ll11_l1_.com/faselhd
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1l1llll11l_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩࡺࡻࡪ࠭⻄")]
def MAIN(mode,url,text):
	if   mode==590: results = MENU()
	elif mode==591: results = l1111l_l1_(url,text)
	elif mode==592: results = PLAY(url)
	elif mode==593: results = l1lll1l1l1_l1_(url,text)
	#elif mode==594: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ⻅")+text)
	#elif mode==595: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ⻆")+text)
	elif mode==599: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭⻇"):l1ll1l1_l1_,l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⻈"):l1l11l11l_l1_(False)}
	l1ll1l1_l1_ = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⻉"),l1ll1l1_l1_,l11lll_l1_ (u"ࠨࠩ⻊"),l11lll_l1_ (u"ࠩࠪ⻋"),l11lll_l1_ (u"ࠪࠫ⻌"),l11lll_l1_ (u"ࠫࠬ⻍"),l11lll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⻎"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻏"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⻐"),l1ll1l1_l1_,599,l11lll_l1_ (u"ࠨࠩ⻑"),l11lll_l1_ (u"ࠩࠪ⻒"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⻓"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻔"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ⻕"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭⻖"),594)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻗"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ⻘"),l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ⻙"),595)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⻚"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⻛"),l11lll_l1_ (u"ࠬ࠭⻜"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻝"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ⻞"),l1ll1l1_l1_,591,l11lll_l1_ (u"ࠨࠩ⻟"),l11lll_l1_ (u"ࠩࠪ⻠"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠶࠭⻡"))
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⻢"),html,re.DOTALL)
	for title,link in items:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻣"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⻤")+l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠧࠨ⻥"),l11lll_l1_ (u"ࠨࠩ⻦"),l11lll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠴ࠫ⻧"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⻨"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⻩"),l11lll_l1_ (u"ࠬ࠭⻪"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡩࡧࡤࡨࡪࡸ࠭ࡴࡱࡦ࡭ࡦࡲࠧ⻫"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1llll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽࡮࡬ࠤ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ⻬"),block,re.DOTALL)
		for menu in l1llll11l1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⻭"),menu,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⻮") not in link: link = l1ll1l1_l1_+link
				#if any(value in title.lower() for value in l1l1l1_l1_): continue
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⻯"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⻰")+l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠬ࠭⻱"),l11lll_l1_ (u"࠭ࠧ⻲"),l11lll_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠳ࠩ⻳"))
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠨࠩ⻴")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⻵"),l11lll_l1_ (u"ࠪࠫ⻶"),type,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ⻷"):url,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⻸"):l1l11l11l_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⻹"),url,l11lll_l1_ (u"ࠧࠨ⻺"),l11lll_l1_ (u"ࠨࠩ⻻"),l11lll_l1_ (u"ࠩࠪ⻼"),l11lll_l1_ (u"ࠪࠫ⻽"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⻾"))
	html = response.content
	l1l1lll1l11_l1_ = 0
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡴ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࡮࠴࠿ࠩ⻿"),html,re.DOTALL)
	if l1l11ll_l1_: l11l1_l1_ = l1l11ll_l1_[0]
	else: l11l1_l1_ = l11lll_l1_ (u"࠭ࠧ⼀")
	if type==l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ࠳ࠪ⼁"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠾ࠨ⼂"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡸࡲࡩࡥࡧࡵ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⼃"),block,re.DOTALL)
		l1l1l1lll_l1_,l1l111_l1_,links = zip(*items)
		items = zip(links,l1l1l1lll_l1_,l1l111_l1_)
	elif type==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠷࠭⼄"):
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩ⼅"),l11l1_l1_,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⼆"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"࠭࡜࡝࠱ࠪ⼇"),l11lll_l1_ (u"ࠧ࠰ࠩ⼈")).replace(l11lll_l1_ (u"ࠨ࡞࡟ࠦࠬ⼉"),l11lll_l1_ (u"ࠩࠥࠫ⼊"))]
	elif type==l11lll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠶ࠬ⼋") and l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⼌") in l11l1_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠿ࠩ⼍"),html,re.DOTALL)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼎"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ็ํึฮ࠭⼏"),url,591,l11lll_l1_ (u"ࠨࠩ⼐"),l11lll_l1_ (u"ࠩࠪ⼑"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨ࠷࠭⼒"))
		title = l1l1ll1_l1_[0][0]
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼓"),l111ll_l1_+title,url,591,l11lll_l1_ (u"ࠬ࠭⼔"),l11lll_l1_ (u"࠭ࠧ⼕"),l11lll_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠴ࠩ⼖"))
		return
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾࡫࠸ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡂࠬ⼗"),html,re.DOTALL)
		title,block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ⼘"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ⼙"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ⼚"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ⼛"),l11lll_l1_ (u"࠭ใๅ์หࠫ⼜"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭⼝"),l11lll_l1_ (u"ࠨ้าหๆ࠭⼞"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ⼟"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ⼠"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ⼡"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ⼢"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭⼣"),l11lll_l1_ (u"ࠧฮๆๅอࠬ⼤")]
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if any(value in title.lower() for value in l1l1l1_l1_): continue
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⼥"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ⼦"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⼧") in link:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼨"),l111ll_l1_+title,link,591,l1llll_l1_)
		elif l1lll11_l1_ and type==l11lll_l1_ (u"ࠬ࠭⼩"):
			title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ⼪")+l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼫"),l111ll_l1_+title,link,593,l1llll_l1_)
				l1l1_l1_.append(title)
		elif any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⼬"),l111ll_l1_+title,link,592,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼭"),l111ll_l1_+title,link,593,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⼮"):
		l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ⼯"),block,re.DOTALL)
		if l1lll11ll1l_l1_:
			count = l1lll11ll1l_l1_[0]
			link = url+l11lll_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ⼰")+count
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼱"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ⼲"),link,591,l11lll_l1_ (u"ࠨࠩ⼳"),l11lll_l1_ (u"ࠩࠪ⼴"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ⼵"))
	elif l11lll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷࠬ⼶") in type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⼷"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⼸"),block,re.DOTALL)
			for link,title in items:
				title = l11lll_l1_ (u"ࠧึใะอࠥ࠭⼹")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼺"),l111ll_l1_+title,link,591,l11lll_l1_ (u"ࠩࠪ⼻"),l11lll_l1_ (u"ࠪࠫ⼼"),l11lll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠹࠭⼽"))
	return
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠬ࠭⼾")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⼿"),url,l11lll_l1_ (u"ࠧࠨ⽀"),l11lll_l1_ (u"ࠨࠩ⽁"),l11lll_l1_ (u"ࠩࠪ⽂"),l11lll_l1_ (u"ࠪࠫ⽃"),l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⽄"))
	html = response.content
	l1lllll_l1_ = False
	if not type:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡦࡣࡶࡳࡳࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡣࡶࡳࡳࡹ࠾ࠨ⽅"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⽆"),block,re.DOTALL)
			if len(items)>1:
				l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ⽇"))
				l1lllll_l1_ = True
				for link,l1llll_l1_,title in items:
					title = unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⽈"),l111ll_l1_+title,link,593,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ⽉"),l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⽊"))
	if type==l11lll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭⽋") or not l1lllll_l1_:
		l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡢ࡬ิ࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠤࡁࡀ࠴ࡨ࡫࠿ࠩ⽌"),html,re.DOTALL)
		if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
		else: l1llll_l1_ = l11lll_l1_ (u"࠭ࠧ⽍")
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡣ࡯ࡰ࠲࡫ࡰࡪࡵࡲࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࡭࡮࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࡃ࠭⽎"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⽏"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ⽐"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⽑"),l111ll_l1_+title,link,592,l1llll_l1_)
	return
def PLAY(url):
	l1lllll1_l1_,l1l1llll1ll_l1_,l1l1lllll1l_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⽒"),url,l11lll_l1_ (u"ࠬ࠭⽓"),l11lll_l1_ (u"࠭ࠧ⽔"),l11lll_l1_ (u"ࠧࠨ⽕"),l11lll_l1_ (u"ࠨࠩ⽖"),l11lll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⽗"))
	html = response.content
	l1l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪห้฿ๅาࠢ࠽࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩ⽘"),html,re.DOTALL)
	if l1l1lll1lll_l1_ and l11ll11_l1_(script_name,url,l1l1lll1lll_l1_): return
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⽙"),html,re.DOTALL)
	if link:
		link = link[0]
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⽚"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴ࡮࡬ࡧࡪ࠳ࡴࡪࡶ࡯ࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⽛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭⽜"),block,re.DOTALL)
		for link,name in items:
			name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ⽝"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⽞")+name+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⽟"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥࡱࡺࡲࡱࡵࡡࡥࡵࡁࠫ⽠"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⽡"),block,re.DOTALL)
		for link,name in items:
			l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⽢")+name+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⽣"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅ็้หุฮࠧ⽤"), l1lllll1_l1_)
	for l1l1llll1l1_l1_ in l1lllll1_l1_:
		link,name = l1l1llll1l1_l1_.split(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥࠩ⽥"))
		if link not in l1l1llll1ll_l1_:
			l1l1llll1ll_l1_.append(link)
			l1l1lllll1l_l1_.append(l1l1llll1l1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็้๋อำษࠩ⽦"), l1l1lllll1l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1l1lllll1l_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⽧"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭⽨"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ⽩"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ⽪"),l11lll_l1_ (u"ࠨ࠭ࠪ⽫"))
	#l1ll1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠸࠮ࡩࡱࡶࡸࠬ⽬"))
	#if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	l1ll1l1_l1_ = l11ll1_l1_
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⽭")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠺࠭⽮"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧፁ")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨፂ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧፃ"):l11lll_l1_ (u"ࠫࠬፄ")}
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫፅ"),l11lll_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧፆ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l1111l_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l111l111l_l1_(url)
	elif mode==375: results = l1111ll1l_l1_(url)
	elif mode==376: results = l1111lll1_l1_(0,url)
	elif mode==377: results = l1111lll1_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫፇ"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩፈ"),l11lll_l1_ (u"ࠩࠪፉ"),l11lll_l1_ (u"ࠪࠫፊ"),l11lll_l1_ (u"ࠫࠬፋ"),l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ፌ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ፍ"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧፎ"),l11lll_l1_ (u"ࠨࠩፏ"),379,l11lll_l1_ (u"ࠩࠪፐ"),l11lll_l1_ (u"ࠪࠫፑ"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨፒ"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪፓ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ፔ"),l11lll_l1_ (u"ࠧࠨፕ"),9999)
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨፖ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨፗ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪፘ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ፙ")+l111ll_l1_+title,link,371)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬፚ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ፛")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ፜"),l11ll1_l1_,375)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፝"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፞")+l111ll_l1_+l11lll_l1_ (u"ࠪห้ษอะอࠪ፟"),l11ll1_l1_,376)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፠"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፡")+l111ll_l1_+l11lll_l1_ (u"๊࠭ีษ๊ำࠥอไร่ࠪ።"),l11ll1_l1_,377)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፣"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፤")+l111ll_l1_+l11lll_l1_ (u"ࠩๅหห๋ษࠡษ็้๊ัไ๋่ࠪ፥"),l11ll1_l1_,374)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ፦"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ፧"),l11lll_l1_ (u"ࠬ࠭፨"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡵࡱࡳ࠱ࡲ࡫࡮ࡶࠩ፩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭፪"),block,re.DOTALL)
		for link,title in items[7:]:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ፫"))
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፬"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፭")+l111ll_l1_+title,link,371)
		for link,title in items[0:7]:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭፮"))
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፯"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ፰")+l111ll_l1_+title,link,371)
	return
def l111l111l_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠧࠨ፱")):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ፲"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ፳"),l11lll_l1_ (u"ࠪࠫ፴"),l11lll_l1_ (u"ࠫࠬ፵"),l11lll_l1_ (u"ࠬ࠭፶"),l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡇࡃࡕࡑࡕࡗࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭፷"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡖࡤ࡫ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ፸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ፹"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ፺") in link: continue
			else: link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ፻"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭፼")+l111ll_l1_+title,link,371)
	return
def l1111ll1l_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭፽")):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ፾"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ፿"),l11lll_l1_ (u"ࠨࠩᎀ"),l11lll_l1_ (u"ࠩࠪᎁ"),l11lll_l1_ (u"ࠪࠫᎂ"),l11lll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡊࡊࡇࡔࡖࡔࡈࡈ࠲࠷ࡳࡵࠩᎃ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠧᎄ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫᎅ"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠧ࠻࠱࠲ࠫᎆ"),l11lll_l1_ (u"ࠨ࠼࠲࠳࠴࠭ᎇ")).replace(l11lll_l1_ (u"ࠩ࠲࠳ࠬᎈ"),l11lll_l1_ (u"ࠪ࠳ࠬᎉ")).replace(l11lll_l1_ (u"ࠫࠥ࠭ᎊ"),l11lll_l1_ (u"ࠬࠫ࠲࠱ࠩᎋ"))
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᎌ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᎍ")+l111ll_l1_+title,link,372,l1llll_l1_)
	return
def l1111lll1_l1_(id,l1l1ll11_l1_=l11lll_l1_ (u"ࠨࠩᎎ")):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᎏ"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ᎐"),l11lll_l1_ (u"ࠫࠬ᎑"),l11lll_l1_ (u"ࠬ࠭᎒"),l11lll_l1_ (u"࠭ࠧ᎓"),l11lll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡗࡂࡖࡆࡌࡎࡔࡇࡏࡑ࡚࠱࠶ࡹࡴࠨ᎔"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠷࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠧ᎕"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[id]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬ᎖"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			link = l11ll1_l1_+link
			if not any(value in title for value in l1l1l1_l1_):
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠪ࠾࠴࠵ࠧ᎗"),l11lll_l1_ (u"ࠫ࠿࠵࠯࠰ࠩ᎘")).replace(l11lll_l1_ (u"ࠬ࠵࠯ࠨ᎙"),l11lll_l1_ (u"࠭࠯ࠨ᎚")).replace(l11lll_l1_ (u"ࠧࠡࠩ᎛"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ᎜"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᎝"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᎞")+l111ll_l1_+title,link,372,l1llll_l1_)
	return
def l1111l_l1_(url,l1l1111l1_l1_=l11lll_l1_ (u"ࠫࠬ᎟")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭Ꭰ"),l11lll_l1_ (u"࠭ࠧᎡ"),l1l1111l1_l1_,url)
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᎢ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᎣ"),url,l11lll_l1_ (u"ࠩࠪᎤ"),l11lll_l1_ (u"ࠪࠫᎥ"),l11lll_l1_ (u"ࠫࠬᎦ"),l11lll_l1_ (u"ࠬ࠭Ꭷ"),l11lll_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᎨ"))
	html = response.content
	if l11lll_l1_ (u"ࠧࡷ࡫ࡧࡴࡦ࡭ࡥࡠࠩᎩ") in url:
		link = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡄࡰࡧࡻ࡭࠮࠰࠭ࡃ࠮ࠨࠧᎪ"),html,re.DOTALL)
		if link:
			link = l11ll1_l1_+link[0]
			l1111l_l1_(link)
			return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠣࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠫᎫ"),html,re.DOTALL)
	if l1l1111l1_l1_==l11lll_l1_ (u"ࠪࠫᎬ") and l1l1ll1_l1_ and l1l1ll1_l1_[0].count(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧࠩᎭ"))>1:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᎮ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾࠭Ꭿ"),url,371,l11lll_l1_ (u"ࠧࠨᎰ"),l11lll_l1_ (u"ࠨࠩᎱ"),l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࡴࠩᎲ"))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᎳ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭Ꮄ")+link
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᎵ"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮆ"),l111ll_l1_+title,link,371)
	else:
		l1l1_l1_ = []
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡲࡪ࠭࠴ࠪ࠱࠮ࡄ࠯ࡣࡰ࡮࠰ࡼࡸ࠳࠱࠳ࠩᎷ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠺ࠥࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫᎸ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠺࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠶ࡁࠫᎹ"),block,re.DOTALL)
			l11lll_l1_ (u"ࠥࠦࠧࠐࠉࠊࠋ࡬ࡸࡪࡳࡳ࠳ࠢࡀࠤࡠࡣࠊࠊࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱࡯࡭ࡨ࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊࡶࡵࡽ࠿ࠦࡣࡰࡷࡱࡸࠥࡃࠠࡪࡰࡷࠬࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩส่า๊โสࠢ࠮ࠬࡡࡪࠫࠪࠩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࡡ࠰࡞ࠫࠍࠍࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࠰࠵ࠏࠏࠉࠊࠋ࡬ࡸࡪࡳࡳ࠳࠰ࡤࡴࡵ࡫࡮ࡥࠪࠫࡰ࡮ࡴ࡫࠭࡫ࡰ࡫࠱ࡺࡩࡵ࡮ࡨ࠰ࡨࡵࡵ࡯ࡶࠬ࠭ࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡶࡳࡷࡺࡥࡥࠪ࡬ࡸࡪࡳࡳ࠳࠮ࠣࡶࡪࡼࡥࡳࡵࡨࡁࡋࡧ࡬ࡴࡧ࠯ࠤࡰ࡫ࡹ࠾࡮ࡤࡱࡧࡪࡡࠡ࡭ࡨࡽ࠿ࠦ࡫ࡦࡻ࡞࠷ࡢ࠯ࠊࠊࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱࡯࡭ࡨ࠮ࡷ࡭ࡹࡲࡥ࠭ࡥࡲࡹࡳࡺࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠢࠣࠤᎺ")
			for link,l1llll_l1_,title in items:
				#LOG_THIS(l11lll_l1_ (u"ࠫࠬᎻ"),l1llll_l1_)
				link = l11ll1_l1_+link
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᎼ"))
				l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"࠭࠺࠰࠱ࠪᎽ"),l11lll_l1_ (u"ࠧ࠻࠱࠲࠳ࠬᎾ")).replace(l11lll_l1_ (u"ࠨ࠱࠲ࠫᎿ"),l11lll_l1_ (u"ࠩ࠲ࠫᏀ")).replace(l11lll_l1_ (u"ࠪࠤࠬᏁ"),l11lll_l1_ (u"ࠫࠪ࠸࠰ࠨᏂ"))
				if l11lll_l1_ (u"ࠬ࠵ࡡ࡭ࡡࠪᏃ") in link:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮔ"),l111ll_l1_+title,link,371,l1llll_l1_)
				elif l11lll_l1_ (u"ࠧศๆะ่็ฯࠧᏅ") in title and (l11lll_l1_ (u"ࠨ࠱ࡆࡥࡹ࠳ࠧᏆ") in url or l11lll_l1_ (u"ࠩ࠲ࡗࡪࡧࡲࡤࡪ࠲ࠫᏇ") in url):
					l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠰ࠤ࠰อไฮๆๅอࠥ࠱࡜ࡥ࠭ࠪᏈ"),title,re.DOTALL)
					if l1lll11_l1_: title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩᏉ")+l1lll11_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏊ"),l111ll_l1_+title,link,371,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᏋ"),l111ll_l1_+title,link,372,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᏌ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏍ"),block,re.DOTALL)
			for link,title in items:
				link = l11ll1_l1_+link
				title = l11lll_l1_ (u"ุࠩๅาฯࠠࠨᏎ")+unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏏ"),l111ll_l1_+title,link,371,l11lll_l1_ (u"ࠫࠬᏐ"),l11lll_l1_ (u"ࠬ࠭Ꮡ"),l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡸ࠭Ꮢ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᏓ"),url,l11lll_l1_ (u"ࠨࠩᏔ"),l11lll_l1_ (u"ࠩࠪᏕ"),l11lll_l1_ (u"ࠪࠫᏖ"),l11lll_l1_ (u"ࠫࠬᏗ"),l11lll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ꮨ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭࡬ࡢࡤࡨࡰ࠲ࡹࡵࡤࡥࡨࡷࡸࠦ࡭ࡳࡩ࠰ࡦࡹࡳ࠭࠶ࠢࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏙ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l11l1l1_l1_ = l11lll_l1_ (u"ࠧࠨᏚ")
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡸࡤࡶࠥࡻࡲ࡭ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᏛ"),html,re.DOTALL)
	if l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_[0]
	else: l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡰࡢࡩࡨࡣࠬᏜ"),l11lll_l1_ (u"ࠪ࠳ࡕࡲࡡࡺ࠱ࠪᏝ"))
	if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᏞ") not in l11l11l_l1_: l11l11l_l1_ = l11ll1_l1_+l11l11l_l1_
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠬ࠳ࠧᏟ"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᏠ"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨᏡ"),l11lll_l1_ (u"ࠨࠩᏢ"),l11lll_l1_ (u"ࠩࠪᏣ"),l11lll_l1_ (u"ࠪࠫᏤ"),l11lll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᏥ"))
	l11lll1l_l1_ = response.content
	l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᏦ"),l11lll1l_l1_,re.DOTALL)
	if l11l1l1_l1_:
		l11l1l1_l1_ = l11l1l1_l1_[-1]
		if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫᏧ") not in l11l1l1_l1_: l11l1l1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭Ꮸ")+l11l1l1_l1_
		if l11lll_l1_ (u"ࠨ࠱ࡓࡐࡆ࡟࠯ࠨᏩ") not in l11l11l_l1_:
			if l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠯࡯࡬ࡲ࠳ࡰࡳࠨᏪ") in l11l1l1_l1_:
				l1111llll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡲࡸࡦࡱ࡯ࡳࡩࡧࡵ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᏫ"),l11lll1l_l1_,re.DOTALL)
				if l1111llll_l1_:
					l1111ll11_l1_, l111l1111_l1_ = l1111llll_l1_[0]
					l11l1l1_l1_ = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᏬ"))+l11lll_l1_ (u"ࠬ࠵ࡶ࠳࠱ࠪᏭ")+l1111ll11_l1_+l11lll_l1_ (u"࠭࠯ࡤࡱࡱࡪ࡮࡭࠯ࠨᏮ")+l111l1111_l1_+l11lll_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭Ꮿ")
		import ll_l1_
		ll_l1_.l11_l1_([l11l1l1_l1_],script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᏰ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪᏱ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫᏲ"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭Ᏻ"),l11lll_l1_ (u"ࠬ࠱ࠧᏴ"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡔࡧࡤࡶࡨ࡮࠯ࠨᏵ")+search
	l1111l_l1_(url)
	return
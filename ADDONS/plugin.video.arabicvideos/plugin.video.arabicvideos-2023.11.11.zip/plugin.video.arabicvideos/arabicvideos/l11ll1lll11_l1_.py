# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫ崤")
def MAIN(mode,text=l11lll_l1_ (u"ࠪࠫ崥")):
	if   mode==  0: l1llll11l1lll_l1_(text)
	elif mode==  2: l1l1ll1l1l1l_l1_(text)
	elif mode==  3: l1lllll11l1ll_l1_()
	elif mode==  4: l1ll1lll11ll_l1_(text)
	elif mode==  5: l1llll11l11ll_l1_()
	elif mode==  6: l1lllll1l1111_l1_()
	elif mode==  7: l1ll111l1l11_l1_()
	elif mode==  8: l1llll111ll11_l1_()
	elif mode==  9: l1llll111lll1_l1_()
	elif mode==150: l1llll111111l_l1_()
	elif mode==151: l1lll1l11l11l_l1_()
	elif mode==152: l1llll1l1l1ll_l1_()
	elif mode==153: l1lllllll1111_l1_()
	elif mode==154: l1lllll1ll1l1_l1_()
	elif mode==155: l1llll11ll1ll_l1_()
	elif mode==156: l1lll1l111ll1_l1_()
	elif mode==157: l1lllll1l111l_l1_()
	elif mode==158: l1llll1l1ll11_l1_()
	elif mode==159: l1lll1llll11l_l1_(True)
	elif mode==170: l1lll1llll1ll_l1_()
	elif mode==171: l1llll1lll1l1_l1_()
	elif mode==172: l1lll1ll1l1l1_l1_(text,True,True)
	elif mode==173: l111ll1l1l1_l1_(l11lll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ崦"),True)
	elif mode==174: l111ll1l1l1_l1_(l11lll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ崧"),True)
	elif mode==175: l1llll1l111l1_l1_()
	elif mode==176: l1lll1ll1l1ll_l1_()
	elif mode==177: l1lllll1l1lll_l1_(l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ崨"))
	elif mode==178: l1lllll1l1lll_l1_(l11lll_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ崩"))
	elif mode==179: l1lllll1l1lll_l1_(l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ崪"))
	elif mode==190: l1llll11l1ll1_l1_()
	elif mode==191: l1lll1l1lllll_l1_()
	elif mode==192: l1lll1ll1ll11_l1_()
	elif mode==193: l1llll1llll11_l1_()
	elif mode==194: l1lll1ll11lll_l1_()
	elif mode==195: l1llll1111111_l1_()
	elif mode==196: l1llll11l11l1_l1_()
	elif mode==197: l1llll1111lll_l1_()
	elif mode==198: l1llll1lll111_l1_()
	elif mode==199: l1llll1111l1l_l1_()
	elif mode==340: l1lll1l1ll11l_l1_(text)
	elif mode==341: l1l11llll111_l1_()
	elif mode==342: l1llll11llll1_l1_()
	elif mode==343: l1llll111l111_l1_()
	elif mode==344: l1lll1ll11111_l1_(True)
	elif mode==345: l1llll1ll111l_l1_()
	elif mode==346: l11lll1l1ll_l1_(False)
	elif mode==347: l1l11ll1ll11_l1_(True)
	elif mode==348: l1llll1lll1ll_l1_()
	elif mode==349: l1lllll11l11l_l1_(l1l1111l11l1_l1_)
	elif mode==500: l1lll1ll1111l_l1_()
	elif mode==501: l1lll1l1l11l1_l1_()
	elif mode==502: l1llll1ll1lll_l1_(l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ崫"),True)
	elif mode==503: l1lllll11l11l_l1_(l11lll1111l_l1_)
	elif mode==504: l1lllll11l11l_l1_(favoritesfile)
	elif mode==505: l1llll1l11111_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l11lll1ll1_l1_(text,l11lll_l1_ (u"ࠪࠫ崬"),True)
	elif mode==508: l1llll1lll11l_l1_()
	elif mode==509: l1llllll1ll1l_l1_()
	return
def l1llllll1ll1l_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ崭"),l11lll_l1_ (u"ࠬ࠭崮"),l11lll_l1_ (u"࠭ࠧ崯"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ崰"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊ࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥ࠴࠮๊่ࠡืาࠦฬๆ์฼ࠤ๊๊แศฬࠣห้ฮั็ษ่ะࠥอไใัํ้ฮࠦ࠮࠯ࠢ็็๏ฺ๊๊ࠦาࠤฬ๊ศา่ส้ัࠦลๅ๋ࠣัฬ๊ษࠡษ็ูๆืࠠ࠯࠰ࠣ๎฾์๊ࠡฬฯำ๏ีࠠศๆหี๋อๅอ๋ࠢฮฺ็๊า้ࠣ์ํ฼ู่ࠢหัฬ๊ษࠡษ็ฺ้์ูࠡษ็ฮ๏่ࠦื฻๊หࠥอไๆสิ้ัࠦฟࠢࠣࠪ崱"))
	if l1ll111ll1_l1_:
		l1lll1ll11111_l1_(False)
		l1ll11l1ll_l1_(addoncachefolder,True,False)
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ崲"),l11lll_l1_ (u"ࠪࠫ崳"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ崴"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻ࠣห้๋ไโษอࠤฬ๊โะ์่อ๊ࠥไษำ้ห๊าࠠ࠯࠰ࠣ์฾อฯࠡษ็ฬึ์วๆฮࠣษ้๏ุ้ࠠ฼๎ฮࠦวๅืไีࠥ࠴࠮ู๊ࠡ฽๏ฯࠠศๆู่๋฿ࠧ崵"))
	return
def l1l11lll1ll1_l1_(addon_id,function,l1ll_l1_):
	# function: l11lll_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭崶"),l11lll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࠨ崷"),l11lll_l1_ (u"ࠨࠩ崸")
	conn = sqlite3.connect(l1l1l111ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1lll1ll1llll_l1_ = l11lll_l1_ (u"ࠩࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠬ崹")
	else: l1lll1ll1llll_l1_ = l11lll_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡢࡶࡺࡲࡥࡴࠩ崺")
	cc.execute(l11lll_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤ࠯ࠦࡆࡓࡑࡐࠤࠬ崻")+l1lll1ll1llll_l1_+l11lll_l1_ (u"ࠬࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ崼")+addon_id+l11lll_l1_ (u"࠭ࠢࠡ࠽ࠪ崽"))
	l11ll1ll1l1_l1_ = cc.fetchall()
	if l11ll1ll1l1_l1_ and function in [l11lll_l1_ (u"ࠧࠨ崾"),l11lll_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ崿")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪ嵀"),l11lll_l1_ (u"ࠪࠫ嵁"),l11lll_l1_ (u"ࠫࠬ嵂"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嵃"),l11lll_l1_ (u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪ嵄")+addon_id+l11lll_l1_ (u"ࠧࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ嵅"))
		if l1ll111ll1_l1_!=1: return
		cc.execute(l11lll_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧ嵆")+l1lll1ll1llll_l1_+l11lll_l1_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧ嵇")+addon_id+l11lll_l1_ (u"ࠪࠦࠥࡁࠧ嵈"))
	elif function in [l11lll_l1_ (u"ࠫࠬ嵉"),l11lll_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪ࠭嵊")]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ嵋"),l11lll_l1_ (u"ࠧࠨ嵌"),l11lll_l1_ (u"ࠨࠩ嵍"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嵎"),l11lll_l1_ (u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧ嵏")+addon_id+l11lll_l1_ (u"ࠫࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡡࡴ࡜࡯ࠢอืฯ฽ฺ๊ࠢอๅ฾๐ไ่ࠢหื์๎ไสࠢ฼๊ิࠦวๅ฻๋ำฮࠦลๅ๋๋ࠣีํࠠศๆืหูฯࠠศๆ่์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ嵐"))
		if l1ll111ll1_l1_!=1: return
		if kodi_version<19: cc.execute(l11lll_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࡦࡱࡧࡣ࡬࡮࡬ࡷࡹࠦࠨࡢࡦࡧࡳࡳࡏࡄ࡙ࠪࠢࡅࡑ࡛ࡅࡔࠢࠫࠦࠬ嵑")+addon_id+l11lll_l1_ (u"࠭ࠢࠪࠢ࠾ࠫ嵒"))
		else: cc.execute(l11lll_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡻࡰࡥࡣࡷࡩࡤࡸࡵ࡭ࡧࡶࠤ࠭ࡧࡤࡥࡱࡱࡍࡉ࠲ࡵࡱࡦࡤࡸࡪࡘࡵ࡭ࡧࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧ嵓")+addon_id+l11lll_l1_ (u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨ嵔"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭嵕"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嵖"),l11lll_l1_ (u"ࠫࠬ嵗"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嵘"),l11lll_l1_ (u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ嵙"))
	if function in [l11lll_l1_ (u"ࠧࠨ嵚"),l11lll_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࠨ嵛")]: l1lll1llll11l_l1_(l1ll_l1_)
	return
def l1llll1l11111_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ嵜"),l11lll_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭嵝"))
	l1l1l11l1l11_l1_ = l11l1111lll_l1_(False)
	l1llll111ll1_l1_ = l11lll_l1_ (u"ࠫࡡࡴࠧ嵞")
	l1lllllll11l1_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠯࠰࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嵟")
	l1lllllll111l_l1_ = l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ嵠")
	for id,l1l11111lll1_l1_,l1l111lll111_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason in reversed(l1l1l11l1l11_l1_):
		if id==l11lll_l1_ (u"ࠧ࠱ࠩ嵡"):
			l1lll1l11ll1_l1_,l1lll1l11lll_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭嵢"))
			continue
		if l1llll111ll1_l1_!=l11lll_l1_ (u"ࠩ࡟ࡲࠬ嵣"): l1llll111ll1_l1_ += l1lllllll111l_l1_
		l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ嵤")+id+l11lll_l1_ (u"ࠫࠥࡀࠠࠨ嵥")+l11lll_l1_ (u"ࠬอไิฦส่ࠥࡀࠠࠨ嵦")+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ嵧")+l1l111lll111_l1_
		l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ั๎วษࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嵨")+l11111lll11_l1_
		l111llll1lll_l1_ = l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嵩")+l11111l1l11_l1_
		l111lllll111_l1_ = l11lll_l1_ (u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ำษสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嵪")+reason
		l1llll111ll1_l1_ += l1l1ll11ll1_l1_+l1l1ll11lll_l1_+l11lll_l1_ (u"ࠪࡠࡳ࠭嵫")+l1lllllll11l1_l1_+l11lll_l1_ (u"ࠫࡡࡴࠧ嵬")+l111llll1lll_l1_+l111lllll111_l1_+l11lll_l1_ (u"ࠬࡢ࡮ࠨ嵭")
	l11ll11lll_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ嵮"),l1lll1l11lll_l1_,l1llll111ll1_l1_,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ嵯"))
	return
def l1lllll11l11l_l1_(file):
	if file==favoritesfile: l1llll1l11l1l_l1_ = l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨ嵰")
	elif file==l1l1111l11l1_l1_: l1llll1l11l1l_l1_ = l11lll_l1_ (u"ࠩส่ึูววๆࠪ嵱")
	elif file==l11lll1111l_l1_: l1llll1l11l1l_l1_ = l11lll_l1_ (u"ࠪๆํอฦๆࠢลาึࠦวๅใํำ๏๎็ศฬࠪ嵲")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ嵳"),l11lll_l1_ (u"๋ࠬำฮࠩ嵴"),l11lll_l1_ (u"࠭ลึๆสัࠬ嵵"),l11lll_l1_ (u"ࠧฯำ๋ะࠬ嵶"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ嵷"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษฺ๊วฮ่่ࠢๆࠦࠧ嵸")+l1llll1l11l1l_l1_+l11lll_l1_ (u"ࠪࠤศ๋ࠠหำํำ๋ࠥำฮࠢส่๊๊แࠡมࠪ嵹"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ嵺"),l11lll_l1_ (u"ࠬ࠭嵻"),l11lll_l1_ (u"࠭ࠧ嵼"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嵽"),l11lll_l1_ (u"ࠨࠩ嵾"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ嵿"),l11lll_l1_ (u"ࠪฮ๊ࠦๅิฯ้้ࠣ็ࠠࠨ嶀")+l1llll1l11l1l_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ嶁"),l11lll_l1_ (u"ࠬ࠭嶂"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嶃"),l11lll_l1_ (u"ࠧห็ࠣษฺ๊วฮ่่ࠢๆࠦࠧ嶄")+l1llll1l11l1l_l1_)
	return
def l1lll1l1l11l1_l1_():
	if kodi_version<18:
		message = l11lll_l1_ (u"ࠨๆ็วุ็ࠠฤ่อࠤฯูสฯั่ࠤส฻ฯศำࠣ็ํี๊ࠡไา๎๊ࠦัใ็ࠣࠫ嶅")+str(kodi_version)+l11lll_l1_ (u"ࠩࠣ์้ํะศࠢส่็๎วว็ࠣห้๋ี้ำฬࠤ้อࠠห฻่่ࠥ฿ๆะๅࠣ࠲ࠥํะ่ࠢส่๊๐าสࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲๊ࠥลึๆสัࠥอไๆึๆ่ฮࠦโๆࠢหฮาี๊ฬࠢหี๋อๅอࠢๆ์ิ๐ࠠฦๆ์ࠤส๐ࠠฦืาหึࠦัใ็๊ࠤศ฿ไ๊่๊ࠢࠥ࠷࠸࠯࠲ࠪ嶆")
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嶇"),l11lll_l1_ (u"ࠫࠬ嶈"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嶉"),message)
		return
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ嶊"))
	l1l111l11l1l_l1_ = l1ll1ll1l1ll_l1_([l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭嶋")])
	l1l111111l1l_l1_,l1lllll111ll1_l1_,l1lllll11l111_l1_,l1lllll111lll_l1_,l1lllll111l11_l1_,l1lll1l1ll111_l1_,l1lllll111l1l_l1_ = l1l111l11l1l_l1_[l11lll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ嶌")]
	if l1l111111l1l_l1_ or l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ嶍") not in str(l11111lll1l_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嶎"),l11lll_l1_ (u"ࠫࠬ嶏"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ嶐"),l11lll_l1_ (u"࠭วๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫ嶑"))
		succeeded = l1llll1ll1lll_l1_(l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭嶒"),True)
		if not succeeded: return
	l111lll11ll_l1_(True)
	return
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩࠬࠎࠎ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠶࠷ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้้สศสฬࠫࠏࠏࡥ࡭࡫ࡩࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄ࠾࠿ࠪ࠹࠺࠻ࠧ࠻ࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠤࡂࠦࠧใ๊สส๊ࠦวๅื๋ีࠬࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็้ࠣัํ่ๅหࠪࠎࠎ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠳࠾ࠎࠏࠣࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࠊࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨࠩࠍࠍࠎࠩࡩ࡮ࡲࡲࡶࡹࠦࡳࡲ࡮࡬ࡸࡪ࠹ࠊࠊࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡻ࡯ࡥࡸࡵࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠵࠾࠽࠱࠲࠹ࠣ࠿ࠬ࠯ࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠸࠹࠴࠽࠶ࠠ࠼ࠩࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠲࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠹࠺ࠧࠊࠥࠣࠦࡑ࡯ࡳࡵࠢࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠶࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭࠵࠶࠷ࠪࠍࠨࠦࠢࡈࡣ࡯ࡰࡪࡸࡹࡠࡇࡰࡥࡩࠨࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠨ࠮ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠯ࠊࠊࠤࠥࠦ嶓")
def l111lll11ll_l1_(l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ嶔"))
	if l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ嶕") not in str(l11111lll1l_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ嶖"),l11lll_l1_ (u"ࠬ࠭嶗"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ嶘"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ嶙"))
		return
	l1lllll11lll1_l1_ = os.path.join(l1l1l11111_l1_,l11lll_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ嶚"),l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ嶛"),l11lll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ嶜"),l11lll_l1_ (u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ嶝"))
	if not os.path.exists(l1lllll11lll1_l1_): return
	l11ll11llll_l1_ = open(l1lllll11lll1_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ嶞")).read()
	if kodi_version>18.99: l11ll11llll_l1_ = l11ll11llll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ嶟"))
	l1lll1l11llll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ嶠"),l11ll11llll_l1_,re.DOTALL)
	l1lll1l1ll1ll_l1_,l1llllll1llll_l1_ = l1lll1l11llll_l1_[0]
	l1lllll1lll1l_l1_ = l11lll_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ嶡")+l1lll1l1ll1ll_l1_+l11lll_l1_ (u"ࠩ࠯ࠫ嶢")+l1llllll1llll_l1_+l11lll_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ嶣")
	if l1ll_l1_:
		l1lllll1lllll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩ嶤"))
		if l1lllll1lllll_l1_==l11lll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ嶥"): l11l111ll1l_l1_ = l11lll_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭嶦")
		elif l1lllll1lllll_l1_==l11lll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭嶧"): l11l111ll1l_l1_ = l11lll_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭嶨")
		else: l11l111ll1l_l1_ = l11lll_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭嶩")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ嶪"),l11lll_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ嶫"),l11lll_l1_ (u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ嶬"),l11lll_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ嶭"),l11lll_l1_ (u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫ嶮")+l11l111ll1l_l1_,l11lll_l1_ (u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ嶯"))
		if choice==1: l1llll1l111ll_l1_ = l11lll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ嶰")
		elif choice==2: l1llll1l111ll_l1_ = l11lll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ嶱")
		else: l1llll1l111ll_l1_ = l11lll_l1_ (u"ࠫࠬ嶲")
	else:
		l1lllll1lllll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ嶳"))
		if   l1lllll1lllll_l1_==l11lll_l1_ (u"࠭ࠧ嶴"): choice = 0
		elif l1lllll1lllll_l1_==l11lll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ嶵"): choice = 1
		elif l1lllll1lllll_l1_==l11lll_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ嶶"): choice = 2
		l1llll1l111ll_l1_ = l1lllll1lllll_l1_
	if   choice==0: l1llll11l1l1l_l1_ = l11lll_l1_ (u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭嶷")
	elif choice==1: l1llll11l1l1l_l1_ = l11lll_l1_ (u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ嶸")
	elif choice==2: l1llll11l1l1l_l1_ = l11lll_l1_ (u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ嶹")
	else: return
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ嶺"),l1llll1l111ll_l1_)
	l1lll1ll111ll_l1_ = l11lll_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ嶻")+l1llll11l1l1l_l1_+l11lll_l1_ (u"ࠧ࠭ࠩ嶼")+l1llllll1llll_l1_+l11lll_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ嶽")
	l11ll11111l_l1_ = l11ll11llll_l1_.replace(l1lllll1lll1l_l1_,l1lll1ll111ll_l1_)
	if kodi_version>18.99: l11ll11111l_l1_ = l11ll11111l_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ嶾"))
	open(l1lllll11lll1_l1_,l11lll_l1_ (u"ࠪࡻࡧ࠭嶿")).write(l11ll11111l_l1_)
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ巀"),l11lll_l1_ (u"ࠬ࠴ࠠࠡࡕ࡮࡭ࡳࠦࡄࡦࡨࡤࡹࡱࡺࠠࡗ࡫ࡨࡻࡸࡀࠠ࡜ࠢࠪ巁")+l1llll11l1l1l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ巂"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11lll_l1_ (u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭巃"))
	return
def l1lll1ll1111l_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ巄"),l11lll_l1_ (u"ࠩๆ่ฬ࠭巅"),l11lll_l1_ (u"๊ࠪ฾๋ࠧ巆"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ巇"),l11lll_l1_ (u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪ巈"))
	if l1ll111ll1_l1_==1: l1ll111l1l11_l1_()
	return
def l1llll111ll11_l1_():
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ巉"),l11lll_l1_ (u"ࠧࠨ巊"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ巋"),l11lll_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬ巌"))
	return
def l1llll1lll1ll_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ巍")
	l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ巎")
	l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ巏")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞สิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ巐")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ巑")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭巒")
	message = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ巓")+l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ巔")+l1l1ll11lll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ巕"),l11lll_l1_ (u"ࠬ࠭巖"),message)
	return
def l11lll1l1ll_l1_(l11llllllll_l1_):
	try: status = l11111l1ll1_l1_(l11llllllll_l1_,False)
	except: pass
	l1l1l11l1l11_l1_ = l11l1111lll_l1_(l11llllllll_l1_)
	id,l1l11111lll1_l1_,l1l111lll111_l1_,l11111lll11_l1_,l11111l1l11_l1_,reason = l1l1l11l1l11_l1_[0]
	l1lll1l11ll1_l1_,l1lll1l11lll_l1_ = l11111lll11_l1_.split(l11lll_l1_ (u"࠭࡜࡯࠽࠾ࠫ巗"))
	l1l1ll11lll_l1_,l111llll1lll_l1_,l111lllll111_l1_ = l11111l1l11_l1_.split(l11lll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ巘"))
	l1l11111l1ll_l1_ = True
	while l1l11111l1ll_l1_:
		l1llll11l1111_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ巙"),l11lll_l1_ (u"ࠩัีําࠧ巚"),l11lll_l1_ (u"ࠪษึูวๅࠢิืฬ๊ษࠡล๋ࠤำ฽รࠨ巛"),l11lll_l1_ (u"ࠫ็อฦๆหࠣห้ะศา฻สฮࠬ巜"),l11lll_l1_ (u"๊ࠬล๋ไสๅࠥอไฦ฻็ห๋อสࠡ࠼ࠣࠤฯฮัฺࠢฦ์ࠥอๅิฯࠣห้ฮั็ษ่ะࠬ川"),l1l1ll11lll_l1_)
		if l1llll11l1111_l1_==2: l1llll111llll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࠧ州"),l11lll_l1_ (u"ࠧࠨ巟"),l11lll_l1_ (u"ࠨ฻๋ำฮ࠭巠"),l11lll_l1_ (u"ࠩࠪ巡"),l11lll_l1_ (u"้ࠪอีรࠡษ็ฮอืูࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪ巢"),l111llll1lll_l1_,l11lll_l1_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡹ࡭ࡢ࡮࡯ࡪࡴࡴࡴࠨ巣"))
		elif l1llll11l1111_l1_==1: l1l1ll1l1l1l_l1_()
		else: l1l11111l1ll_l1_ = False
	settings.setSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ巤"),l1l1ll1ll111_l1_(now))
	xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ工"))
	return
def l1lll1ll11111_l1_(l1ll_l1_):
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ左"),l11lll_l1_ (u"ࠨࠩ巧"),l11lll_l1_ (u"ࠩࠪ巨"),l11lll_l1_ (u"ࠪืษอไࠨ巩"),l11lll_l1_ (u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬ巪"))
	else: l1ll111ll1_l1_ = True
	if l1ll111ll1_l1_:
		succeeded = True
		if os.path.exists(l1l1ll111ll1_l1_):
			try: os.remove(l1l1ll111ll1_l1_)
			except: succeeded = False
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭巫"),l11lll_l1_ (u"࠭ࠧ巬"),l11lll_l1_ (u"ࠧࠨ巭"),l11lll_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ差"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ巯"),l11lll_l1_ (u"ࠪࠫ巰"),l11lll_l1_ (u"ࠫࠬ己"),l11lll_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ已"))
	return
def l1llll1ll111l_l1_():
	l1llll11l1ll1_l1_()
	l1llllll11l11_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ巳"))
	message = {}
	message[l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ巴")] = l11lll_l1_ (u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ巵")
	message[l11lll_l1_ (u"ࠩࡖࡘࡔࡖࠧ巶")] = l11lll_l1_ (u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ巷")
	message[l11lll_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ巸")] = l11lll_l1_ (u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭巹")+str(l11l1llllll_l1_/60)+l11lll_l1_ (u"࠭ࠠะไํๆฮࠦแใูࠪ巺")
	l1lll1llll111_l1_ = message[l1llllll11l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ巻"),l11lll_l1_ (u"ࠨๅสุࠥ࠭巼")+str(l11l1llllll_l1_/60)+l11lll_l1_ (u"ࠩࠣำ็๐โสࠩ巽"),l11lll_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ巾"),l11lll_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ巿"),l1lll1llll111_l1_,l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ帀"))
	if choice==0: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ币")
	elif choice==1: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ市")
	elif choice==2: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭布")
	else: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠩࠪ帄")
	if l1lll1lll1l1l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ帅"),l1lll1lll1l1l_l1_)
		l1lll1ll1l11l_l1_ = message[l1lll1lll1l1l_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ帆"),l11lll_l1_ (u"ࠬ࠭帇"),l11lll_l1_ (u"࠭ࠧ师"),l1lll1ll1l11l_l1_)
	return
def l1llll111l111_l1_():
	message = {}
	message[l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ帉")] = l11lll_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭帊")
	message[l11lll_l1_ (u"ࠩࡄࡗࡐ࠭帋")] = l11lll_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ希")
	message[l11lll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ帍")] = l11lll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ帎")
	l1lllll1l11ll_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭帏"))
	l1llllll11l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ帐"))
	l1lll1llll111_l1_ = message[l1llllll11l11_l1_]+l1lllll1l11ll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ帑"),l11lll_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ帒"),l11lll_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ帓"),l11lll_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ帔"),l1lll1llll111_l1_,l11lll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩ帕"))
	if choice==0: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"࠭ࡁࡔࡍࠪ帖")
	elif choice==1: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠧࡂࡗࡗࡓࠬ帗")
	elif choice==2: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠨࡕࡗࡓࡕ࠭帘")
	if choice in [0,1]:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ帙"),l11lll_l1_ (u"ࠪื๏ืแา࠼ࠣࠫ帚")+l1lll1l11111_l1_[1],l11lll_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ帛")+l1lll1l11111_l1_[0],l11lll_l1_ (u"ࠬ࠭帜"),l11lll_l1_ (u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ帝"))
		if l1ll111ll1_l1_==1: l1111l1ll1l_l1_ = l1lll1l11111_l1_[0]
		else: l1111l1ll1l_l1_ = l1lll1l11111_l1_[1]
	elif choice==2: l1111l1ll1l_l1_ = l11lll_l1_ (u"ࠧࠨ帞")
	else: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠨࠩ帟")
	if l1lll1lll1l1l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ帠"),l1lll1lll1l1l_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ帡"),l1111l1ll1l_l1_)
		l1lll1ll1l11l_l1_ = message[l1lll1lll1l1l_l1_]+l1111l1ll1l_l1_
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ帢"),l11lll_l1_ (u"ࠬ࠭帣"),l11lll_l1_ (u"࠭ࠧ帤"),l1lll1ll1l11l_l1_)
	return
def l1llll11llll1_l1_():
	l1llllll11l11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ帥"))
	message = {}
	message[l11lll_l1_ (u"ࠨࡃࡘࡘࡔ࠭带")] = l11lll_l1_ (u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪ帧")
	message[l11lll_l1_ (u"ࠪࡅࡘࡑࠧ帨")] = l11lll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ帩")
	message[l11lll_l1_ (u"࡙ࠬࡔࡐࡒࠪ帪")] = l11lll_l1_ (u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ師")
	l1lll1llll111_l1_ = message[l1llllll11l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ帬"),l11lll_l1_ (u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭席"),l11lll_l1_ (u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ帮"),l11lll_l1_ (u"ࠪษ๏่วโࠢๆห๊๊ࠧ帯"),l1lll1llll111_l1_,l11lll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧ帰"))
	if choice==0: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠬࡇࡓࡌࠩ帱")
	elif choice==1: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"࠭ࡁࡖࡖࡒࠫ帲")
	elif choice==2: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ帳")
	else: l1lll1lll1l1l_l1_ = l11lll_l1_ (u"ࠨࠩ帴")
	if l1lll1lll1l1l_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ帵"),l1lll1lll1l1l_l1_)
		l1lll1ll1l11l_l1_ = message[l1lll1lll1l1l_l1_]
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ帶"),l11lll_l1_ (u"ࠫࠬ帷"),l11lll_l1_ (u"ࠬ࠭常"),l1lll1ll1l11l_l1_)
	return
def l1llll1lll11l_l1_():
	l1l1111ll111_l1_ = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ帹"))
	if l1l1111ll111_l1_==l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ帺"): header = l11lll_l1_ (u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧ帻")
	else: header = l11lll_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧ帼")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ帽"),l11lll_l1_ (u"ࠫส๐โศใࠪ帾"),l11lll_l1_ (u"ࠬะแฺ์็ࠫ帿"),header,l11lll_l1_ (u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱ๋้ࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ幀"))
	if l1ll111ll1_l1_==-1: return
	elif l1ll111ll1_l1_:
		settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ幁"),l11lll_l1_ (u"ࠨࠩ幂"))
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ幃"),l11lll_l1_ (u"ࠪࠫ幄"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ幅"),l11lll_l1_ (u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ幆"))
	else:
		settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ幇"),l11lll_l1_ (u"ࠧࡔࡖࡒࡔࠬ幈"))
		DIALOG_OK(l11lll_l1_ (u"ࠨࠩ幉"),l11lll_l1_ (u"ࠩࠪ幊"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭幋"),l11lll_l1_ (u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭幌"))
	return
def l1llll11l1lll_l1_(text):
	if text!=l11lll_l1_ (u"ࠬ࠭幍"):
		text = l1l111lll1l_l1_(text)
		text = text.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ幎")).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ幏"))
		l1l11l11111_l1_ = 10103
		l1l111llll1_l1_ = xbmcgui.l1l111l1ll1_l1_(l1l11l11111_l1_)
		l1l111llll1_l1_.getControl(311).l1l11l111ll_l1_(text)
		#l1l11l11l1ll_l1_ = xbmcgui.WindowXMLDialog(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡌࡧࡼࡦࡴࡧࡲࡥ࠴࠵࠲ࡽࡳ࡬ࠨ幐"), xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ幑")).decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ幒")),l11lll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ幓"),l11lll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ幔"))
		#l1l11l11l1ll_l1_.show()
		#l1l11l11l1ll_l1_.getControl(99991).setPosition(0,0)
		#l1l11l11l1ll_l1_.getControl(311).l1l11l111ll_l1_(text)
		#l1l11l11l1ll_l1_.getControl(5).l1ll1ll11l1l_l1_(l1lllll11llll_l1_)
		#width = xbmcgui.l1lll1lll111l_l1_()
		#l1l1lllll1ll_l1_ = xbmcgui.l1llll1l1l1l1_l1_()
		#resolution = (0.0+width)/l1l1lllll1ll_l1_
		#l1l11l11l1ll_l1_.getControl(5).l1l111llll1l_l1_(width-180)
		#l1l11l11l1ll_l1_.getControl(5).setHeight(l1l1lllll1ll_l1_-180)
		#l1l11l11l1ll_l1_.doModal()
		#del l1l11l11l1ll_l1_
	return
l1lll1l1lll1l_l1_ = [
			 l11lll_l1_ (u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࠪࠫࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦ幕")
			,l11lll_l1_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪ幖")
			,l11lll_l1_ (u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪ幗")
			,l11lll_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼࠫ幘")
			,l11lll_l1_ (u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫ幙")
			,l11lll_l1_ (u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭幚")
			,l11lll_l1_ (u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠧࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪ幛")
			,l11lll_l1_ (u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ幜")
			,l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫࠽࠱ࠨࡷࡩࡽࡺ࠽ࠨ幝")
			,l11lll_l1_ (u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ幞")
			,l11lll_l1_ (u"ࠩࡡࡢࡣࡤ࡞ࠨ幟")
			,l11lll_l1_ (u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ幠")
			]
def l1llll111l1ll_l1_(line):
	if l11lll_l1_ (u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ幡") in line and l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ幢") in line: return True
	for text in l1lll1l1lll1l_l1_:
		if text in line: return True
	return False
def l1lll1l11ll11_l1_(data):
	data = data.replace(l11lll_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ幣")+51*l11lll_l1_ (u"ࠧࠡࠩ幤")+l11lll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭幥"),l11lll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ幦"))
	data = data.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭幧")+51*l11lll_l1_ (u"ࠫࠥ࠭幨")+l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ幩"),l11lll_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ幪"))
	data = data.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ幫")+51*l11lll_l1_ (u"ࠨࠢࠪ幬")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ幭"),l11lll_l1_ (u"ࠪࡠࡳ࠭幮"))
	data = data.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ幯")+51*l11lll_l1_ (u"ࠬࠦࠧ幰"),l11lll_l1_ (u"࠭࡜࡯ࠩ幱")+31*l11lll_l1_ (u"ࠧࠡࠩ干"))
	#data = data.replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳࠳ࡆࡴࡤࡳࡱ࡬ࡨ࠴ࡪࡡࡵࡣ࠲ࡳࡷ࡭࠮ࡹࡤࡰࡧ࠳ࡱ࡯ࡥ࡫࠲ࡪ࡮ࡲࡥࡴ࠱࠱࡯ࡴࡪࡩ࠰ࡣࡧࡨࡴࡴࡳ࠰ࠩ平"),l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠠࡇ࡫࡯ࡩࠥࠨࠧ年"))
	data = data.replace(l11lll_l1_ (u"ࠪࠤࡁ࡭ࡥ࡯ࡧࡵࡥࡱࡄ࠺ࠡࠩ幵"),l11lll_l1_ (u"ࠫ࠿ࠦࠧ并"))
	l11llll11_l1_ = l11lll_l1_ (u"ࠬ࠭幷")
	for line in data.splitlines():
		delete = re.findall(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠬ࠳࠰࠿ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠯ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ幸"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11lll_l1_ (u"ࠧࠨ幹"))
		l11llll11_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ幺")+line
	#WRITE_THIS(l11lll_l1_ (u"ࠩࠪ幻"),l11llll11_l1_)
	return l11llll11_l1_
def l1lll1l1ll11l_l1_(l1llll1l11l11_l1_):
	if l11lll_l1_ (u"ࠪࡓࡑࡊࠧ幼") in l1llll1l11l11_l1_:
		l1lllll1l1l11_l1_ = l1ll1ll1llll_l1_
		header = l11lll_l1_ (u"ࠫ็ืวยหࠣหู้ฬๅࠢส่็ี๊ๆࠢยࠫ幽")
	else:
		l1lllll1l1l11_l1_ = l1ll1l1111ll_l1_
		header = l11lll_l1_ (u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้ำวๅ์ࠣรࠬ幾")
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࠧ广"),l11lll_l1_ (u"ࠧࠨ庀"),l11lll_l1_ (u"ࠨࠩ庁"),header,l11lll_l1_ (u"ࠩึะ้ࠦวๅลั฻ฬว๋ࠠฯอ์๏ࠦรุ๋สࠤ฾๊้ࠡีฯ่ࠥอไศีอาิอๅࠡ࠰ࠣ์ฬ๊วฬ่ํ๊ࠥ฼ั้ำํอ๊ࠥๅฺำไอ้๊ࠥโࠢะำะะࠠศๆุ่่๊ษ๊่ࠡหࠥํ่ࠡษ็้่อๆࠡษ็ิ๏ࠦำษสࠣัิ๎หࠡษ็ู้้ไสࠢ࠱ࠤ่๎ฯ๋ࠢํัฯ็ุࠡสึะ้๐ๆࠡ࠰ࠣห้ษ่ๅ๊ࠢ์ࠥอไิฮ็ࠤฬ๊อศๆํࠤํ็๊่่ࠢ฽้๎ๅศฬࠣฮอีรࠡ็้ิࠥฮฯศ์ฬࠤฬ๊สี฼ํ่ࠥอไฮษ็๎๊ࠥศา่ส้ัࠦใ้ัํࠤํอไ๊ࠢส่ว์ࠠ࠯ࠢฦ้ฬࠦวๅีฯ่ࠥอไใัํ้ࠥ็็้ࠢสุ่าไࠡษ็ืฬฮโࠡษ็ิ๏ࠦสๆࠢฯ้฾ํࠠๆ่ࠣฬึ์วๆฮࠣ็ํี๊ࠡไห่ࠥศฮาࠢศ฻ๆอมࠡๆ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ庂"))
	if l1ll111ll1_l1_!=1: return
	l1lll1l1l1111_l1_,counts = [],0
	size,count = l1l1l11ll1_l1_(l1lllll1l1l11_l1_)
	#size = os.path.getsize(l1lllll1l1l11_l1_)
	file = open(l1lllll1l1l11_l1_,l11lll_l1_ (u"ࠪࡶࡧ࠭広"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ庄"))
	data = l1lll1l11ll11_l1_(data)
	lines = data.split(l11lll_l1_ (u"ࠬࡢ࡮ࠨ庅"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ庆"))
		#if line.strip(l11lll_l1_ (u"ࠧࠡࠩ庇"))==l11lll_l1_ (u"ࠨࠩ庈"): continue
		ignore = l1llll111l1ll_l1_(line)
		if ignore: continue
		line = line.replace(l11lll_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠࡠࠩ庉"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ床"))
		line = line.replace(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔ࠽ࠫ庋"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈ࠳࠴࠵࠶࡝ࡆࡔࡕࡓࡗࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ庌"))
		l1llll1l11ll1_l1_ = l11lll_l1_ (u"࠭ࠧ庍")
		l1lll1l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ庎"),line,re.DOTALL)
		if l1lll1l1lll11_l1_:
			line = line.replace(l1lll1l1lll11_l1_[0][0],l1lll1l1lll11_l1_[0][1]).replace(l1lll1l1lll11_l1_[0][2],l11lll_l1_ (u"ࠨࠩ序"))
			l1llll1l11ll1_l1_ = l1lll1l1lll11_l1_[0][1]
		else:
			l1lll1l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࡡࠬࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ庐"),line,re.DOTALL)
			if l1lll1l1lll11_l1_:
				line = line.replace(l1lll1l1lll11_l1_[0][1],l11lll_l1_ (u"ࠪࠫ庑"))
				l1llll1l11ll1_l1_ = l1lll1l1lll11_l1_[0][0]
		if l1llll1l11ll1_l1_: line = line.replace(l1llll1l11ll1_l1_,l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ庒")+l1llll1l11ll1_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ库"))
		l1lll1l1l1111_l1_.append(line)
		if len(str(l1lll1l1l1111_l1_))>50100: break
	l1lll1l1l1111_l1_ = reversed(l1lll1l1l1111_l1_)
	l1lllll11llll_l1_ = l11lll_l1_ (u"࠭࡜࡯ࠩ应").join(l1lll1l1l1111_l1_)
	l11ll11lll_l1_(l11lll_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ底"),l11lll_l1_ (u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬ庖"),l1lllll11llll_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ店"))
	return
def l1llll1111l1l_l1_():
	l1lllll1l1l1l_l1_ = open(l1l1ll1l11ll_l1_,l11lll_l1_ (u"ࠪࡶࡧ࠭庘")).read()
	if kodi_version>18.99: l1lllll1l1l1l_l1_ = l1lllll1l1l1l_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ庙"))
	l1lllll1l1l1l_l1_ = l1lllll1l1l1l_l1_.replace(l11lll_l1_ (u"ࠬࡢࡴࠨ庚"),l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠨ庛"))
	l1l111l11l1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡸ࡟ࡨ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨ府"),l1lllll1l1l1l_l1_,re.DOTALL)
	for line in l1l111l11l1l_l1_:
		l1lllll1l1l1l_l1_ = l1lllll1l1l1l_l1_.replace(line,l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ庝")+line+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ庞"))
	DIALOG_TEXTVIEWER(l11lll_l1_ (u"ࠪห้ะฺ๋์ิหฯࠦวๅลั๎ึฯࠠโ์ࠣห้ฮัศ็ฯࠫ废"),l1lllll1l1l1l_l1_)
	return
def l1llll1lll111_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠫอ฿ึࠡษ็วืืวาࠢ฼่๎ࠦวๅำํ้ํะࠠไ๊้ฮึ๎ไࠡฬ๋ๅึࠦลๆๅส๊๏ฯࠠหไา๎๊่ࠦหลั๎ึࠦวๅใํำ๏๎้้ࠠำ๋ࠥอไฤิิหึࠦ็๋ࠢส่ศู็ๆ๋ࠢห้ษัใษ่ࠤ๊฿ࠠษ฻ูࠤํ้วๅฬส่๏࠭庠")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"๊ࠬสใัํ้ࠥอไโ์า๎ํࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋็ํ๊ࠥ๎ไหลั๎ึํࠠศีอาิ๋ࠠศๆึ๋๊ࠦวๅ์ึหึࠦ࠮ࠡล่หࠥ฿ฯสࠢสื์๋ࠠๆฬอห้๐ษࠡใ๊ิ์ࠦสใ๊่ࠤอะอา์ๆࠤฬ๊แ๋ัํ์ࠥฮ่ใฬࠣห่ฮัࠡ็้ࠤํ่สࠡษ็ื์๋ࠠศๆ๋หาีࠠ࠯ࠢฦ้ฬࠦวๅี๊้ࠥอไฤ฻็ํࠥ๎วๅลึๅ้ࠦแ่๊ࠣ๎าืใࠡษ็ๅ๏ี๊้ࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦ่ࠦๅๅ้ࠤอ่แำหࠣ็อ๐ัสࠩ庡")
	l111llll1lll_l1_ = l11lll_l1_ (u"࠭รๆษࠣห้ษัใษ่ࠤๆํ๊ࠡฬึฮำีๅࠡๆ็ฮ็ี๊ๆ๋ࠢห้ะรฯ์ิࠤํ๊ใ็ࠢห้็ีวาࠢ฼ำิࠦวๅอ๋ห๋๐้ࠠษ็ำ็อฦใࠢ࠱ࠤ๊ัไศࠢิๆ๊ࠦ࠵࠵࠶ࠣฮ฾์๊ࠡ࠷ࠣำ็อฦใ๋ࠢࠤ࠹࠺ࠠฬษ้๎ฮࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣฬาูศࠡษึฮำีวๆๅู่้ࠣ็ๆࠢส่๏๋๊็ࠢฦ์ูࠥ็ๆࠢส่๏ูวาࠩ庢")
	message = l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠧ࠻ࠢࠪ庣")+l1l1ll11lll_l1_+l11lll_l1_ (u"ࠨࠢ࠱ࠤࠬ庤")+l111llll1lll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ庥"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭度"),message,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ座"))
	return
def l1111l1lll1_l1_(type,message,l1ll_l1_=True,url=l11lll_l1_ (u"ࠬ࠭庨"),source=l11lll_l1_ (u"࠭ࠧ庩"),text=l11lll_l1_ (u"ࠧࠨ庪"),l11l11l1ll1l_l1_=l11lll_l1_ (u"ࠨࠩ庫")):
	l1lll1l111lll_l1_ = True
	if not l11l1llll1l_l1_(l11lll_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ庬")):
		if l1ll_l1_:
			#if message.count(l11lll_l1_ (u"ࠪࡠࡡࡴࠧ庭"))>1: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ庮")
			#else: l1l1lll1l1l1_l1_ = l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ庯")
			l1lll1ll11l11_l1_ = (l11lll_l1_ (u"࠭วๅีฺี࠿࠭庰") in message and l11lll_l1_ (u"ࠧศๆ่็ฬ์࠺ࠨ庱") in message and l11lll_l1_ (u"ࠨษ็้้็࠺ࠨ庲") in message and l11lll_l1_ (u"ࠩส่ำ฽รࠨ庳") in message and l11lll_l1_ (u"ࠪห้๋ีะำ࠽ࠫ庴") in message)
			if not l1lll1ll11l11_l1_: l1lll1l111lll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ庵"),l11lll_l1_ (u"ࠬ࠭庶"),l11lll_l1_ (u"࠭ࠧ康"),l11lll_l1_ (u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫ庸"),message.replace(l11lll_l1_ (u"ࠨ࡞࡟ࡲࠬ庹"),l11lll_l1_ (u"ࠩ࡟ࡲࠬ庺")))
	elif l1ll_l1_:
		message = l11lll_l1_ (u"ࠪࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅหࠪ庻")
		l1llllll11lll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ庼"),l11lll_l1_ (u"ࠬ࠭庽"),l11lll_l1_ (u"࠭ࠧ庾"),l11lll_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ庿")+l11lll_l1_ (u"ࠨࠢࠣ࠵࠴࠻ࠧ廀"),l11lll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ廁"))
		l1llllll11ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ廂"),l11lll_l1_ (u"ࠫࠬ廃"),l11lll_l1_ (u"ࠬ࠭廄"),l11lll_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭廅")+l11lll_l1_ (u"ࠧࠡࠢ࠵࠳࠺࠭廆"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭廇"))
		l1llllll11l1l_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ廈"),l11lll_l1_ (u"ࠪࠫ廉"),l11lll_l1_ (u"ࠫࠬ廊"),l11lll_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ廋")+l11lll_l1_ (u"࠭ࠠࠡ࠵࠲࠹ࠬ廌"),l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ廍"))
		l1llllll1l1l1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ廎"),l11lll_l1_ (u"ࠩࠪ廏"),l11lll_l1_ (u"ࠪࠫ廐"),l11lll_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ廑")+l11lll_l1_ (u"ࠬࠦࠠ࠵࠱࠸ࠫ廒"),l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ廓"))
		l1lll1l111lll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ廔"),l11lll_l1_ (u"ࠨࠩ廕"),l11lll_l1_ (u"ࠩࠪ廖"),l11lll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ廗")+l11lll_l1_ (u"ࠫࠥࠦ࠵࠰࠷ࠪ廘"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ廙"))
	user = l11llll11ll_l1_(32,False)
	l1lllll1111ll_l1_ = l11lll_l1_ (u"࠭ࡁࡗ࠼ࠣࠫ廚")+user+l11lll_l1_ (u"ࠧ࠮ࠩ廛")+type
	l1l1111lllll_l1_ = True if l11lll_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࠫ廜") in text else False
	if not l1lll1l111lll_l1_:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ廝"),l11lll_l1_ (u"ࠪࠫ廞"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ廟"),l11lll_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨ廠"))
		return False
	l1llllll1l1ll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ廡"))
	message += l11lll_l1_ (u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭廢")+l11ll111111_l1_+l11lll_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࠧ廣")
	message += l11lll_l1_ (u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪ廤")+user+l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ廥")+l11lll11l1l_l1_+l11lll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ廦")
	message += l11lll_l1_ (u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪ廧")+l1llllll1l1ll_l1_
	#l11ll1lllll_l1_ = l11l1ll1111_l1_(l11lll_l1_ (u"࠭࠷࠷࠰࠹࠹࠳࠷࠳࠹࠰࠵࠷࠵࠭廨"))
	l1lll1ll111l_l1_ = l11l1ll1111_l1_()
	l1lll1ll111l_l1_ = QUOTE(l1lll1ll111l_l1_)
	if l1lll1ll111l_l1_: message += l11lll_l1_ (u"ࠧࠡ࠼࡟ࡠࡳࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠺ࠡࠩ廩")+l1lll1ll111l_l1_
	if url: message += l11lll_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࡕࡓࡎ࠽ࠤࠬ廪")+url
	if source: message += l11lll_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡔࡱࡸࡶࡨ࡫࠺ࠡࠩ廫")+source
	message += l11lll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࠩ廬")
	if l1ll_l1_: DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫัอั๋ࠢส่สืำศๆࠪ廭"),l11lll_l1_ (u"ࠬอไาฮสลࠥอไศ่อ฼ฬืࠧ廮"))
	if l11l11l1ll1l_l1_:
		l1lllll11llll_l1_ = l11l11l1ll1l_l1_
		if kodi_version>18.99: l1lllll11llll_l1_ = l1lllll11llll_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ廯"))
		l1lllll11llll_l1_ = base64.b64encode(l1lllll11llll_l1_)
	elif l1l1111lllll_l1_:
		if l11lll_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧ廰") in text: l1llllll111ll_l1_ = l1ll1ll1llll_l1_
		else: l1llllll111ll_l1_ = l1ll1l1111ll_l1_
		if not os.path.exists(l1llllll111ll_l1_):
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ廱"),l11lll_l1_ (u"ࠩࠪ廲"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭廳"),l11lll_l1_ (u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩ廴"))
			return False
		l1lll1l1l1111_l1_,counts = [],0
		size,count = l1l1l11ll1_l1_(l1llllll111ll_l1_)
		#size = os.path.getsize(l1llllll111ll_l1_)
		file = open(l1llllll111ll_l1_,l11lll_l1_ (u"ࠬࡸࡢࠨ廵"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ延"))
		data = l1lll1l11ll11_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ廷"))
			ignore = l1llll111l1ll_l1_(line)
			if ignore: continue
			l1lll1l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ廸"),line,re.DOTALL)
			if l1lll1l1lll11_l1_:
				line = line.replace(l1lll1l1lll11_l1_[0][0],l1lll1l1lll11_l1_[0][1]).replace(l1lll1l1lll11_l1_[0][2],l11lll_l1_ (u"ࠩࠪ廹"))
			else:
				l1lll1l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ建"),line,re.DOTALL)
				if l1lll1l1lll11_l1_: line = line.replace(l1lll1l1lll11_l1_[0][1],l11lll_l1_ (u"ࠫࠬ廻"))
			l1lll1l1l1111_l1_.append(line)
			if len(str(l1lll1l1l1111_l1_))>121000: break
		l1lll1l1l1111_l1_ = reversed(l1lll1l1l1111_l1_)
		l1lllll11llll_l1_ = l11lll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ廼").join(l1lll1l1l1111_l1_)
		l1lllll11llll_l1_ = l1lllll11llll_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ廽"))
		l1lllll11llll_l1_ = base64.b64encode(l1lllll11llll_l1_)
	else: l1lllll11llll_l1_ = l11lll_l1_ (u"ࠧࠨ廾")
	url = l1ll11l_l1_[l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ廿")][2]
	payload = {l11lll_l1_ (u"ࠩࡶࡹࡧࡰࡥࡤࡶࠪ开"):l1lllll1111ll_l1_,l11lll_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ弁"):message,l11lll_l1_ (u"ࠫࡱࡵࡧࡧ࡫࡯ࡩࠬ异"):l1lllll11llll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ弃"),url,payload,l11lll_l1_ (u"࠭ࠧ弄"),l11lll_l1_ (u"ࠧࠨ弅"),l11lll_l1_ (u"ࠨࠩ弆"),l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌ࠮࠳ࡶࡸࠬ弇"))
	#succeeded = response.succeeded
	html = response.content
	if l11lll_l1_ (u"ࠪࠦࡸࡻࡣࡤࡧࡨࡨࡪࡪࠢ࠻ࠢ࠴࠰ࠬ弈") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠨ弉"),l11lll_l1_ (u"ࠬฮๆอษะࠫ弊"))
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ弋"),l11lll_l1_ (u"ࠧࠨ弌"),l11lll_l1_ (u"ࠨࡏࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠧ弍"),l11lll_l1_ (u"ࠩอ้ࠥหัิษ็ࠤฬ๊ัิษ็อࠥฮๆอษะࠫ弎"))
		else:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"่้ࠪษำโࠩ式"),l11lll_l1_ (u"ࠫๆฺไࠡใํࠤฬ๊ลาีส่ࠬ弐"))
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭弑"),l11lll_l1_ (u"࠭ࠧ弒"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ弓"),l11lll_l1_ (u"ࠨะฺวࠥ๎แีๆࠣๅ๏ࠦลาีส่ࠥอไาีส่ฮ࠭弔"))
	return succeeded
def l1lll1l11l11l_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠩ࠴࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡹ࡫ࡸࡵࠢࡷ࡬ࡪࡴࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ引")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠪ࠵࠳ࠦࠠࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥอไฤฯิๅࠥอไฺำห๎ฮࠦแศา๊ฬࠥอไ๊ࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฬ็ࠣ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬ弖")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ弗"),l11lll_l1_ (u"ࠬ࠭弘"),l11lll_l1_ (u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡐࡳࡱࡥࡰࡪࡳࠧ弙"),l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ弚")+l1l1ll11lll_l1_)
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠨ࠴࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡣࡢࡰ࡟ࠫࡹࠦࡦࡪࡰࡧࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࡬࡯࡯ࡶࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡹ࡫ࡪࡰࠣࡥࡳࡪࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠧ弛")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠩ࠵࠲ࠥࠦࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ็๋ࠠษฬ฽๎๏ืࠠศๆฯ่ิࠦหๆࠢๅ้ࠥฮส฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤฬ๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ弜")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ弝"),l11lll_l1_ (u"ࠫࠬ弞"),l11lll_l1_ (u"ࠬࡌ࡯࡯ࡶࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ弟"),l1l1ll11ll1_l1_+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ张")+l1l1ll11lll_l1_)
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ弡"),l11lll_l1_ (u"ࠨࠩ弢"),l11lll_l1_ (u"ࠩࠪ弣"),l11lll_l1_ (u"ࠪࡊࡴࡴࡴࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠪ弤"),l11lll_l1_ (u"ࠫࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡱࡳࡼࠦ࠿ࠨ弥")+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ弦")+l11lll_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆำ๋ฬฮࠠฦๆ์ࠤ้๎อสࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฤๆล๊ฤ࠭弧"))
	if l1ll111ll1_l1_==1: l1lllll1l1111_l1_()
	return
def l1lllllll1111_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ弨"),l11lll_l1_ (u"ࠨࠩ弩"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ弪"),l11lll_l1_ (u"ࠪ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอ๋่้ࠢะรไัࠣๆ๊ࠦศหึ฽๎้ࠦวๅำสฬ฼ࠦวๅาํࠤ้อ๋ࠠ฻่่ࠥัๅࠡไ่ࠤอหัิษ็ࠤฺ๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤฬ๊โศศ่อࠥอไาศํื๏ฯࠠๅๆหี๋อๅอࠩ弫"))
	return
def l1lllll1ll1l1_l1_():
	message = l11lll_l1_ (u"ࠫ์ึวࠡษ็ฬึ์วๆฮ้ࠣำ฻ีࠡใๅ฻๊ࠥไ฻หࠣห้฿ัษ์ฬࠤํ๊ใ็๊ࠢิฬࠦไศࠢํ้๋฿้ࠠฮ๋ำ๋่ࠥศไ฼ࠤๆ๐็ศࠢฦๅ้อๅ๊่ࠡืู้ไศฬ้ࠣฯืฬๆหࠣวํࠦๅะส็ะฮࠦลๅ๋ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ์ฬ๊้ࠡๆ฽หฯࠦวฯำ์ࠤํ๊วࠡ์๋ะิࠦำษส่้ࠣะใาษิࠫ弬")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭弭"),l11lll_l1_ (u"࠭ࠧ弮"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ弯"),message)
	return
def l1llll11ll1ll_l1_():
	message = l11lll_l1_ (u"ࠨษ็ีํอศุࠢส่อ฽๊วห่ࠣฬูࠦๅษๅอ๊ࠥ็ศࠢหห้ฮั็ษ่ะࠥ๎ฺศๆหหࠥอไิสหࠤ์๎ࠠๆ่ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣหฺ้๋ั์่้ࠣฮั็ษ่ะࠬ弰")
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ弱"),l11lll_l1_ (u"ࠪࠫ弲"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ弳"),message)
	return
def l1lll1l111ll1_l1_():
	message = l11lll_l1_ (u"ࠬํ๊ࠡีํีๆืวหࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠศีอาิอๅ่ษࠣฬุฮศࠡๅ๋๊์อࠠๆฯ่๎ฮࠦๅ็ࠢส่๊฻ฯาࠢฦ์ࠥฮอศฮฬࠤส๊้ࠡษืฮึอใࠡำึ้๏ࠦร้ࠢฯำ๏ีษࠡล๋ࠤ้อ๋ࠠ฻ิๅ์อࠠศๆหี๋อๅอࠩ弴")
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ張"),l11lll_l1_ (u"ࠧࠨ弶"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ強"),l11lll_l1_ (u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫ弸"),message)
	return
def l1lllll1l111l_l1_():
	message = l11lll_l1_ (u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨ弹")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ强"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ弻"),message,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ弼"))
	return
def l1llll1l1ll11_l1_():
	l1l1ll11ll1_l1_ = l11lll_l1_ (u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ำ็ฯࠠศๆ฼ห้๐ษࠨ弽")
	l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢฦ่ࠥࡳ࠳ࡶ࠺ࠪ弾")
	l111llll1lll_l1_ = l11lll_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ะอๆ์็ࠤํอไะษ๋๊้๎ฯࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ弿")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ彀"),l11lll_l1_ (u"ࠫࠬ彁"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ彂"),l1l1ll11ll1_l1_,l1l1ll11lll_l1_,l111llll1lll_l1_)
	return
def l1llll11l1ll1_l1_():
	l1l1ll11lll_l1_ = l11lll_l1_ (u"࠭วๅๅสุࠥํ่ࠡ็ัึ๋ࠦๅลไอࠤ้๊ๅฺๆ๋้ฬะ๋ࠠีอาิ๋็ࠡษ็ฬึ์วๆฮ่ࠣำุๆࠡืไัฬะࠠศๆศ๊ฯืๆ๋ฬࠣ์ึ๎วษูࠣห้็๊ะ์๋๋ฬะࠠๅๆู๋ํ๊ࠠฦๆํ๋ฬࠦศิำ฼อࠥ๎ศะ๊้ࠤส์สา่ํฮࠥ๎วๅสิ๊ฬ๋ฬࠡ์่ืาํวࠡฬ็ๆฬฬ๊ศࠢห฽ิࠦว็ฬ๊หฦูࠦๆำ๊หࠥ๎รุ๋สࠤ฾์ฯࠡฬะำ๏ัࠠศๆหี๋อๅอࠢ࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤุฮูสࠢฦ๊ํอูࠡๆ฼้ึࠦวๅๅสุࠥࡀࠧ彃")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ彄") + l11lll_l1_ (u"ࠨ࠳࠱ࠤะอศหࠢ็ฺ่็อศฬࠣห้ะ๊ࠡ็฼ีํ็ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ืࠠ็้สส๏อ้ࠠ็าฮ์ࠦࠧ彅") + str(PERMANENT_CACHE/60/60/24/30) + l11lll_l1_ (u"ุࠩࠣ์ืࠧ彆")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭彇") + l11lll_l1_ (u"ࠫ࠷࠴ࠠอัสࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่๊็ัุ้ࠣว๋ํวࠡๆสࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪ彈") + str(VERYLONG_CACHE/60/60/24) + l11lll_l1_ (u"๊้ࠬࠦ็ࠪ彉")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"࠭࡜࡯ࠩ彊") + l11lll_l1_ (u"ࠧ࠴࠰ࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็ฮ๏ࠦๆศัิหࠥะส฻์ิࠤํ๋ฯห้ࠣࠫ彋") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠨࠢํ์๊࠭彌")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ彍") + l11lll_l1_ (u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ彎") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"ูࠫࠥวฺหࠪ彏")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࠨ彐") + l11lll_l1_ (u"࠭࠵࠯ࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤิอฦๆษࠣ์๊ีส่ࠢࠪ彑") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ࠧࠡีส฽ฮ࠭归")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ当") + l11lll_l1_ (u"ࠩ࠹࠲ࠥาฯศࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤ่ั๊าษࠣ์๊ีส่ࠢࠪ彔") + str(l1l1lllll111_l1_/60) + l11lll_l1_ (u"ࠪࠤิ่๊ใหࠪ录")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ彖") + l11lll_l1_ (u"ࠬ࠽࠮ࠡสา์๋ࠦใศึ่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡสึี฾ฯ้ࠠ็าฮ์ࠦࠧ彗") + str(NO_CACHE) + l11lll_l1_ (u"࠭ࠠะไํๆฮ࠭彘")
	l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ彙") + l11lll_l1_ (u"ࠨ็ฮ่ฬࡀࠠึใะหฯࠦโ้ษษ้ࠥอไฤใ็ห๊่ࠦศๆ่ืู้ไศฬࠣ์ฬ๊อๅไสฮࠥ฿ๅา้สࠤࠬ彚") + str(REGULAR_CACHE/60/60) + l11lll_l1_ (u"ࠩࠣืฬ฿ษࠡ࠰ࠣว๊อࠠใ๊สส๊ࠦร็๊ส฽ࠥอไโ์า๎ํํวหࠢไ฽๊ื็ศࠢࠪ彛") + str(l11111l_l1_/60/60/24) + l11lll_l1_ (u"ࠪࠤศ๐วๆࠢ࠱ࠤศ๋วࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡใ฼้ึํวࠡࠩ彜") + str(l1lll1111_l1_/60/60) + l11lll_l1_ (u"ูࠫࠥวฺหࠣๅ็฽ࠠ࠯ࠢฦ้ฬࠦแฮืࠣี็๋ࠠศๆศูิอัࠡใ฼้ึํࠠࠨ彝") + str(l1l1lllll111_l1_/60) + l11lll_l1_ (u"ࠬࠦฯใ์ๅอࠥ࠴ࠠฤ็สࠤๆำีࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠโ฻่ี์ࠦࠧ彞") + str(NO_CACHE) + l11lll_l1_ (u"࠭ࠠะไํๆฮ࠭彟")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭彠"),l11lll_l1_ (u"ࠨ็สࠤ์๎ࠠศๆๆหูࠦวๅ็ึฮำีๅࠡใํࠤฬ๊ศา่ส้ั࠭彡"),l1l1ll11lll_l1_,l11lll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ形"))
	return
def l1lll1l1lllll_l1_():
	message = l11lll_l1_ (u"ࠪห้็วึๆฬࠤฯ฿ๆ๋่ࠢะ้ีࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠣ์ฬ๊ๆใูฬࠤฯ฿ๆ๋ࠢฦ๊ࠥอไศี่ࠤฬ๊รึๆํࠤฯ๋ࠠห฻า๎้ํ้ࠠใสู้ฯ้่ࠠๅ฻ฮࠦสฺ่์ࠤ๊าไะ๋ࠢฮ๊ࠦสฺัํ่ࠥอำๆ้ࠣ์อี่็ࠢ฼่ฬ๋ษࠡฬ฼๊๏ࠦๅๅใࠣฬ๋็ำࠡษึ้์ࠦวๅลุ่๏࠭彣")
	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ彤"),l11lll_l1_ (u"ࠬ࠭彥"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ彦"),message)
	return
def l1lll1ll1ll11_l1_():
	message = l11lll_l1_ (u"ࠧฦาสࠤํอฬ่ฬๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅึห็ฮ่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥษ่ࠡษ้็ࠥะุ็ࠢฦ๊ࠥอไๆ๊ๅ฽ࠥอไฤื็๎้ࠥว็ࠢไ๎์ࠦๅีๅ็อ๋ࠥฤใฬ๊ࠤํะๅࠡฯ็๋ฬࠦ࠮࠯࠰ࠣๅสึๆࠡฮิฬ๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้ฮั็ษ่ะࠥฮืๅสࠣห้฻แฮหࠣห้฻อ๋ฯฬࠤํะฮำ์้๋ฬࠦศะๆสࠤ๊์ࠠศๆุๅาฯࠠศๆๅำ๏๋ษࠨ彧")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ彨"),l11lll_l1_ (u"ࠩࠪ彩"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭彪"),message)
	return
def l1llll1llll11_l1_():
	message = l11lll_l1_ (u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨ彫")
	DIALOG_OK(l11lll_l1_ (u"ࠬ࠭彬"),l11lll_l1_ (u"࠭ࠧ彭"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ彮"),message)
	return
def l1lll1ll11lll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ彯"),l11lll_l1_ (u"ࠩࠪ彰"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭影"),l11lll_l1_ (u"้้๊ࠫࠡ์฼้้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไโ์า๎ํํวหࠢ࡟ࡲࠥ๐ฬษࠢอๅ฾๐ไࠡวูหๆฯࠠศี่๋ฬࠦ࡜࡯ࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ彲"))
	l111ll1l1l1_l1_(l11lll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ彳"),True)
	return
def l1llll1111111_l1_():
	message  = l11lll_l1_ (u"࠭ๅละิห่ࠥวๆฬࠣฬ฾฼ࠠีำๆหฯࠦวๅว้ฮึ์สࠡษ็ำํ๊๊ࠡสฺ๋฾ูࠦศศๅࠤ฻ีࠠศๆหีฬ๋ฬࠡ็ฮ่้่ࠥะ์่ࠣฯูๅฮࠢไๆ฼ࠦไษ฻ูࠤู๊สฯั่๎ࠥอไๆฬุๅาࠦศศๆาาํ๊ࠠๅ็๋ห็฿ࠠศๆไ๎ิ๐่ࠨ彴")
	#message += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡํํะศࠢส่฾อฦใ๊ࠢ์ࠥࡸࡥࡄࡃࡓࡘࡈࡎࡁࠡษ็าฬ฻ࠠษึิ็ฮࠦฬ้ฮ็࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧ彵")
	#message += l11lll_l1_ (u"ࠨ๊ส่ี๐ࠠึ่฼ฮ์ࠦิาๅฬࠤั๎ฬๅࠢัู๏฻วࠡๆ่๊฾ࠦศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๆ่ࠣฮฺ็อࠡษ็ษ๋ะั็ฬࠪ彶")
	message += l11lll_l1_ (u"ࠩࠣ์๋ะ๊อห่ࠣ์ึวࠡษ็฽ฬฬโࠡใส๊์ࠦสใำํฬฬࠦฬๆ์฼ࠤู๊สฯั่๎ࠥฮั็ษ่ะ้่ࠥะ์่ࠣฬ๊ࠦิฬฺ๎฾๎ๆࠡษ็ำำ๎ไࠡๆฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡฯอํู๋ࠥࠡษึฮำีวๆࠩ彷")
	message += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝แ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴࠧ彸")
	message += l11lll_l1_ (u"ࠫࡡࡴไศ่๋ࠣีอࠠๅ่ࠣ๎า๊ࠠศๆุ่่๊ษ๊ࠡศ๊๊อࠠโไฺࠤุ๐โ้็ࠣฬส฻ไศฯࠣฬ฾฼ࠠศๆ่์ฬู่๊ࠡศ฽ฬ่ษࠡ็๋ห็฿ࠠศะิํ้ࠥว็ฬࠣฮ฾๋ไࠡีสฬ็อࠠษั๋๊๋ࠥิศๅ็ࠫ役")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ彺"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ彻"),message,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ彼"))
	message = l11lll_l1_ (u"ࠨษ็้ํอโฺࠢส่ฯ๐ࠠหลฮีฯࠦศศๆ฼หหฺ่่ࠠาࠤอ฿ึࠡษ็๊ฬู่ࠠ์࠽ࠫ彽")
	message += l11lll_l1_ (u"ࠩ࡟ࡲࠬ彾")+l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ彿")
	message += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ往")+l11lll_l1_ (u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭征")
	message += l11lll_l1_ (u"࠭࡜࡯ࠩ徂")+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ู่ึࠦࠠศๆๆ์๏ะࠠࠡล่๎ึ้วࠡࠢๆ๊ิอࠠࠡใิุ๊อࠠࠡษ็๎ํ์ว็ࠢࠣฬึ๐ืศ่ํหࠥอไฦ็สีฬะࠠฤๆ่ห๋๐วࠡำ๋ื๏อࠠศๆํหออๆࠡษ็ื฾๎ฯ๋หࠣีํ๋ว็์สࠤ์๎ไ็ัส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ徃")
	message += l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭径")+l11lll_l1_ (u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪ待")
	message += l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอัิๆࠣีุอไส่ࠢศิฮษࠡว็ํࠥอไๆสิ้ั่ࠦศๅอฬࠥ็๊่ษࠣหุ๋ࠠษๆา็ࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠหีอ฻๏฿ࠠะะ๋่์อ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ徆")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ徇"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ很"),message,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ徉"))
	#l1l1ll1l1l1l_l1_(l11lll_l1_ (u"ࠧࡊࡵࡓࡶࡴࡨ࡬ࡦ࡯ࡀࡊࡦࡲࡳࡦࠩ徊"))
	#message = l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭律")+l11lll_l1_ (u"๋่ࠩ็ีࠠๅษะ฼๋อࠠศ์ูหࠥษๆࠡษ็้ํอโฺࠢส่๊฿วใหࠣฮำะไโࠢหหำะไศใࠣห้ฮไะ๋ࠢฮำะไโࠢหหำะไศใุࠣึ้ษࠡษ็ห๋ะั็์อࠤๆ๐ࠠัๆๆࠤฬ๊ศๅัࠣ์์ึวࠡ็฼๊ฬํࠠศ่๊ࠤาะ้ࠡๆ๋ࠤฯ๋ࠠศีอาิอๅࠡࡘࡓࡒࠥษ่ࠡࡒࡵࡳࡽࡿࠠฤ๊ࠣว๏่ࠦิ์็อࠥอฮา๋ࠣๅฬ์ࠠศๆ่์ฬู่ࠡษ็้฾อโสࠢึ์ๆࠦสฯฬ็ๅࠥ๎ไไ่๊ห๊ࠥๆࠡฬ฼้้ࠦฬๆ์฼๋ฬ࠭後")
	#message += l11lll_l1_ (u"่ࠪา๊ࠠศๆุ่่๊ษࠡไ่ࠤอ฿ๅๅ์้࠾ࠥࠦࠠࠡษ็วํ๊࠺ࠡลิื้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠤํอใหส้ࠣ฾ํࠠศี่ࠤอ๊ฯไ๋ࠢหุ๋ࠠีำๆอࠥอไฦ่อี๋๐ส๊ࠡฦื๊อมࠡษ็้ํอโฺࠢส่ฯ๐ࠠๅษࠣฮ฾๋ไࠡ฻้ำ่࠭徍")
	#message += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ徎")+l11lll_l1_ (u"ࠬ๎วๅอส๊๏ࡀࠠอำหࠤฬูสฯัส้ࠥ࡜ࡐࡏ๋ࠢ฽๋ีࠠศๆห฽฻ࠦโะࠢอัฯอฬࠡใๅ฻ࠥะฺ๋์ิࠤࡉࡔࡓ๊ࠡส่ศำำ็ࠢฦ๊ࠥ๐ใ้่ࠣๅ๏ࠦศๅัࠣหำืฺࠠๆ่หࠥอๆࠡษึฮำีวๆࠢࡓࡶࡴࡾࡹࠡไาࠤ๏ำไࠡ็ื็้ฯࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ไไ่่ࠣ๏ูࠠโ์ࠣะ๊๐ูࠡษ็ำํ๊ࠧ徏")
	#DIALOG_TEXTVIEWER(l11lll_l1_ (u"࠭ๅีๅ็อࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠬ徐"),message)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ徑"),l11lll_l1_ (u"ࠨใะูࠥาๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠫ徒"),l11lll_l1_ (u"๊ࠩิฬࠦวๅใะูࠥํ่ࠡๆ่฽ึ็ษ้ࠡ็ࠤฬ๊ๅีๅ็อ๋ࠥๆࠡ฻้ำ่ࠦวๆ่๊ࠢࠥอไษำ้ห๊า࠮ࠡีํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษใะู๋่ࠥศไ฼๋๋ࠥัห์้ࠤฬ๊ร้ๆ์ࠤอ๎ึฺๅࠣห้฽ศ๋฻ํࠤํอไฬษ้๎ฮࠦศศีอาิอๅࠡสิ์ู่๊ࠡ็ฯห๋๐ࠠศ่อࠤฯิสศำ๊ࠤ๊์ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦำหฺ๊ี๊ࠥวฮไส࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวามࠪ従"),l11lll_l1_ (u"ࠪࠫ徔"),l11lll_l1_ (u"ࠫࠬ徕"),l11lll_l1_ (u"้ࠬไศࠩ徖"),l11lll_l1_ (u"࠭ๆฺ็ࠪ得"))
	#if l1ll111ll1_l1_==1:
	#l1llll1l111l1_l1_()
	return
def l1llll11l11l1_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ徘"),l11lll_l1_ (u"ࠨࠩ徙"),l11lll_l1_ (u"ࠩฮ่ฬัุࠠำๅࠤ้๊ส้ษุู่๋ࠥࠡษ็้อืๅอࠩ徚"),l11lll_l1_ (u"ࠪวึูไࠡำึห้ฯࠠฤู๊้้ࠣไส่๊่ࠢࠥวว็ฬࠤำีๅศฬ๋ࠣีอࠠศๆหี๋อๅอ࡞ࡱࡠࡳษ่ࠡสสืฯิฯศ็ࠣห้็๊ิส๋็ࠥษฯ็ษ๊ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡩࡶࡷࡴ࠿࠵࠯ࡧࡣࡦࡩࡧࡵ࡯࡬࠰ࡦࡳࡲ࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ徛"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ徜"),l11lll_l1_ (u"ࠬ࠭徝"),l11lll_l1_ (u"࠭ࡂࡃࡄࡅࡆࡇࡈࡂࡃࡄࠣࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭從"),l11lll_l1_ (u"ࠧ࠱࠲࠳࠴࠵ࠦ࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵ࠤ࠸࠹࠳࠴࠵࡟ࡲࡡࡴ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࡢ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆ࠷࡟ࡃࡄࡅࡆࡇ࠷࡟ࡄࡅࡆࡇࡈ࠷࡟ࡅࡆࡇࡈࡉ࠷࡟ࡆࡇࡈࡉࡊ࠷࡟ࡇࡈࡉࡊࡋ࠷࡟ࡈࡉࡊࡋࡌ࠷࡟ࡉࡊࡋࡌࡍ࠷࡟ࡊࡋࡌࡍࡎ࠷࡟ࡋࡌࡍࡎࡏ࠷࡟ࡌࡍࡎࡏࡐ࠷࡟ࡍࡎࡏࡐࡑ࠷࡟ࡎࡏࡐࡑࡒ࠷ࠠ࠱࠲࠳࠴࠵ࠦ࠱࠲࠳࠴࠵ࠥ࠸࠲࠳࠴࠵ࠤ࠸࠹࠳࠴࠵ࠣ࠸࠹࠺࠴࠵ࠢࡄࡅࡆࡇࡁ࠳ࡡࡅࡆࡇࡈࡂ࠳ࡡࡆࡇࡈࡉࡃ࠳ࡡࡇࡈࡉࡊࡄ࠳ࡡࡈࡉࡊࡋࡅ࠳ࡡࡉࡊࡋࡌࡆ࠳ࡡࡊࡋࡌࡍࡇ࠳ࡡࡋࡌࡍࡎࡈ࠳ࡡࡌࡍࡎࡏࡉ࠳ࡡࡍࡎࡏࡐࡊ࠳ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤ࠺࠻࠵࠶࠷ࠣ࠺࠻࠼࠶࠷ࠢ࠺࠻࠼࠽࠷ࠡ࠺࠻࠼࠽࠾ࠠ࠺࠻࠼࠽࠾ࠦࡁࡂࡃࡄࡅࠥࡈࡂࡃࡄࡅࠫ徟"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ徠"),l11lll_l1_ (u"ࠩࠪ御"),l11lll_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ徢"),l11lll_l1_ (u"ࠫ࠵ࠦ࠰ࠡ࠲ࠣ࠴ࠥ࠶ࠠ࠲ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠶ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠳ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠷ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠻ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠸ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠼ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠹ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠽ࠥ࠿ࠠ࠺ࠢ࠼ࠤ࠾ࠦࡁࡂࡃࡄࡅ࠶ࡥࡂࡃࡄࡅࡆ࠶ࡥࡃࡄࡅࡆࡇ࠶ࡥࡄࡅࡆࡇࡈ࠶ࡥࡅࡆࡇࡈࡉ࠶ࡥࡆࡇࡈࡉࡊ࠶ࡥࡇࡈࡉࡊࡋ࠶ࡥࡈࡉࡊࡋࡌ࠶ࡥࡉࡊࡋࡌࡍ࠶ࡥࡊࡋࡌࡍࡎ࠶ࡥࡋࡌࡍࡎࡏ࠶ࡥࡌࡍࡎࡏࡐ࠶ࡥࡍࡎࡏࡐࡑ࠶ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡࡃࡄࡅࡆࡇ࠲ࡠࡄࡅࡆࡇࡈ࠲ࡠࡅࡆࡇࡈࡉ࠲ࡠࡆࡇࡈࡉࡊ࠲ࡠࡇࡈࡉࡊࡋ࠲ࡠࡈࡉࡊࡋࡌ࠲ࡠࡉࡊࡋࡌࡍ࠲ࡠࡊࡋࡌࡍࡎ࠲ࡠࡋࡌࡍࡎࡏ࠲ࡠࡌࡍࡎࡏࡐ࠲ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣ࠹࠺࠻࠵࠶ࠢ࠹࠺࠻࠼࠶ࠡ࠹࠺࠻࠼࠽ࠠ࠹࠺࠻࠼࠽ࠦ࠹࠺࠻࠼࠽ࠥࡇࡁࡂࡃࡄࠤࡇࡈࡂࡃࡄࠪ徣"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭徤"),l11lll_l1_ (u"࠭ࠧ徥"),l11lll_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ徦"),l11lll_l1_ (u"ࠨ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠧ徧"))
	#text = l11lll_l1_ (u"ࠩࠫࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࠤ࠮ࠦ࠰ࠡ࠳ࠣ࠶ࠥ࠹ࠠ࠵ࠢ࠸ࠤ࠻ࠦ࠷ࠡ࠺ࠣ࠽ࠥࡧࠠࡣࠢࡦࠤࡩࠦࡥࠡࡨࠣ࡫ࠥ࡮ࠠࡪࠢ࡭ࠤࡰࠦ࡬ࠡ࡯ࠣࡲࠥࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠥࡼࠠࡸࠢࡻࠤࡾࠦࡺࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࡵࠠࡱࠢࡴࠤࡷࠦࡳࠡࡶࠣࡹࠬ徨")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࠫ復"),l11lll_l1_ (u"ࠫ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹࠱࠳࠵࠷࠹࠭循"),l11lll_l1_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺࠲࠴࠶࠸࠺ࠧ徫"),l11lll_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ徬"),l11lll_l1_ (u"ࠧ࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴࠵࠶࠷࠸࠲ࠨ徭"),text,l11lll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ微"),1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠩࠪ徯"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ徰"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ徱"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ徲"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ徳"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ徴"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠨࠩ徵"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ徶"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ德"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ徸"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ徹"),l11lll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭徺"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠧࠨ徻"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ徼"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ徽"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ徾"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ徿"),l11lll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ忀"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"࠭ࠧ忁"),l11lll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ忂"),l11lll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ心"),l11lll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ忄"),l11lll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡢ࡮ࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ必"),l11lll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ忆"))
	return
def l1llll111lll1_l1_():
	l1llll11l1ll1_l1_()
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ忇"),l11lll_l1_ (u"࠭ࠧ忈"),l11lll_l1_ (u"ࠧࠨ忉"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦฬๆ์฼ࠤฬ๊ใศึࠣรࠬ忊"),l11lll_l1_ (u"ࠩส่่อิࠡ์ึี฾ูࠦๆๆࠣห้ฮั็ษ่ะࠥ๎ๅิฯ๊ࠤ๏฿๊ะࠢึัอࠦวๅืไัฬะࠠๆ่ࠣห้หๆหำ้ฮࠥ฿ๆะࠢส่าอฬสࠢศ่๏ํว๊ࠡสู่๊อࠡ์อ้ࠥะไใษษ๎ฬูࠦ็ัࠣห๋ะ็ศรࠣ฽๊ืࠠศๆุๅาอส๊ࠡสู่๊อࠡๆสࠤ๏฼ั๊่้่ࠡ์๋ࠠฯ็ࠤอ฿ึࠡษ็ู้อใๅࠩ忋"))
	if l1ll111ll1_l1_==1:
		l111l11ll11_l1_(True)
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫ忌"),l11lll_l1_ (u"ࠫࠬ忍"),l11lll_l1_ (u"ࠬะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤออไไษ่่ࠬ忎"),l11lll_l1_ (u"࠭ลัษࠣ็ฬ์สࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษะำࠥอไๆ๊สๆ฾ࠦแอำหࠤฬ๊ๅ้ไ฼ࠤฬ๊ย็ࠢ࠱࠲࠳่ࠦฤาสࠤฬ๊ๅีๅ็อ๋ࠥำห็ิอࠥ็ลั่ࠣหึูไࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠧ忏"))
	return l1ll111ll1_l1_
def l1ll1lll11ll_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ忐"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡼࡦࡳࡰ࡭ࡧ࠱ࡧࡴࡳࠧ忑"),l11lll_l1_ (u"ࠩࠪ忒"),l11lll_l1_ (u"ࠪࠫ忓"),False,l11lll_l1_ (u"ࠫࠬ忔"),l11lll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ忕"))
	#html = response.content
	if not response.succeeded:
		l1lll1lllll1l_l1_ = False
		l11l1lll11_l1_ = l11l1l1l1l_l1_()
		LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ忖"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡌ࡙࡚ࡐࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡑࡧࡢࡦ࡮࠽࡟ࠬ志")+l11l1lll11_l1_+l11lll_l1_ (u"ࠨ࡟ࠪ忘"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ忙"),l11lll_l1_ (u"ࠪࠫ忚"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ忛"),l11lll_l1_ (u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ応"))
	else:
		l1lll1lllll1l_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ忝"),l11lll_l1_ (u"ࠧࠨ忞"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ忟"),l11lll_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢํ฽ฺ๊๊่ࠠา็ࠥ๎วๅสิ๊ฬ๋ฬࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭忠"))
	if not l1lll1lllll1l_l1_ and l1ll_l1_: l1llll1l1l1ll_l1_()
	return l1lll1lllll1l_l1_
def l1llll1l1l1ll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ忡"),l11lll_l1_ (u"ࠫࠬ忢"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ忣"),l11lll_l1_ (u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬ忤"))
	#l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠧี้สำฮࠦวๅฬืๅ๏ื่ࠠ์้้ࠣ็๋ࠠฯอ์๏ูࠦๅุ๋ࠣๆืษࠡะสูฮࠦร้ࠢอ์ฬฺ่๊ࠢัหฺฯࠠๅึิ็ฬะࠠๆ฻ิ์ๆฯ้ࠠๆ๊ࠤฯอั๋ะู้ࠣออ๋หࠣ์๋็วั๋ࠢห้เัื่๊ࠢ์ࠦ็้ࠢอฬฬีไࠡษ็้฾๊่ๆษอࠤอ฽ั๋ไฬࠤฺ๊แาหࠣ๎ฺ฿ศࠡษัฮึอโ่ษࠣ์ๆํๅ่ษࠪ忥")
	l1llll1llll1l_l1_()
	return
def l1l1ll1l1l1l_l1_(text=l11lll_l1_ (u"ࠨࠩ忦")):
	l1l1111lllll_l1_ = True
	if l11lll_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ忧") not in text:
		l1l1111lllll_l1_ = False
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ忨"),l11lll_l1_ (u"ࠫำื่อࠩ忩"),l11lll_l1_ (u"ࠬหัิษ็ࠤฺ๊ใๅหࠪ忪"),l11lll_l1_ (u"࠭ลาีส่ࠥืำศๆฬࠫ快"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ忬"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢศ่๎ࠦวๅ็หี๊าࠠ࠯࠰ࠣว๊ࠦสา์าࠤศ์ࠠหำึ่๋ࠥิไๆฬࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆหี๋อๅอࠢยࠫ忭"))
		if choice in [-1,0]: return
		elif choice==1:
			l1l1111lllll_l1_ = True
			text = l11lll_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ忮")
	if l1l1111lllll_l1_:
		#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ忯"),l11lll_l1_ (u"ࠫࠬ忰"),l11lll_l1_ (u"ࠬ࠭忱"),l11lll_l1_ (u"࠭ลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ忲"),l11lll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏ูสุ์฼ࠤฬ๊ๅษำ่ะู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ลึๆสั์อࠧ忳"))
		#if not l1ll111ll1_l1_:
		#	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ忴"),l11lll_l1_ (u"ࠩࠪ念"),l11lll_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭忶"),l11lll_l1_ (u"้๊ࠫริใࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ忷"))
		#	return
		l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡭ࡱࡪࡷࡂࡿࡥࡴࠩࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲่ࠧๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ࠬࠨไห่ࠥอัิษ็ࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾๊๊ไࠢส๊ࠥะโ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๎ࠠศๆิหอ฽ࠠศๆำ๎ࠥ๐ูุ์ๆࠤฬ๊ๅีๅ็อ๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅษั฻ฬว้ࠠษ็หุะฮะษ่࠲ࠥํไࠡฬิ๎ิࠦวๅษิืฬ๊ࠠศๆส๊ࠥลࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨๅ็หࠬ࠲ࠧ็฻่ࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡿࡥࡴ࠿ࡀ࠴࠿ࠐࠉࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไ฻ษฤࠤฬ๊วาีส่ࠬ࠯ࠊࠊࠋࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠊࠊࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠬࠨษำห้ࠥว็ฬ่ࠣิ๐ใࠡ็ื็้ฯࠠโษ็ีัอมࠡไิหฦฯࠠใี่ࠤฬ๊ๅีษๆ่ࠥ๎วๅษึส้ฯ้ࠠษำห๊ࠥๅࠡฬฯำࠥอไฮๆ๋๋ࠣอใࠡใะหํ๊ࠠไฬสฬฮࠦฬๆ์฼ࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࠭ࠏࠏࠉࠣࠤࠥ忸")
		if l11lll_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭忹") not in text:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ忺"),l11lll_l1_ (u"ࠨࠩ忻"),l11lll_l1_ (u"ࠩࠪ忼"),l11lll_l1_ (u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪ忽"),l11lll_l1_ (u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫ忾"))
			if l1ll111ll1_l1_!=1:
				DIALOG_OK(l11lll_l1_ (u"ࠬ࠭忿"),l11lll_l1_ (u"࠭ࠧ怀"),l11lll_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ态"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ怂"))
				return
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ怃"),l11lll_l1_ (u"ࠪࠫ怄"),l11lll_l1_ (u"่ࠫะวษหࠣ์ูือࠡษ็้ํ฼ฺ่ࠢ็่๊ฮัๆฮࠪ怅"),l11lll_l1_ (u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้อ๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ怆"))
	search = OPEN_KEYBOARD(header=l11lll_l1_ (u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ怇"),source=script_name)
	if not search: return
	message = search
	if l1l1111lllll_l1_: type = l11lll_l1_ (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨ怈")
	else: type = l11lll_l1_ (u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩ怉")
	succeeded = l1111l1lll1_l1_(type,message,True,l11lll_l1_ (u"ࠩࠪ怊"),l11lll_l1_ (u"ࠪࡉࡒࡇࡉࡍ࠯ࡉࡖࡔࡓ࠭ࡖࡕࡈࡖࡘ࠭怋"),text)
	#	url = l11lll_l1_ (u"ࠫࡲࡿࠠࡂࡒࡌࠤࡦࡴࡤ࠰ࡱࡵࠤࡘࡓࡔࡑࠢࡶࡩࡷࡼࡥࡳࠩ怌")
	#	payload = l11lll_l1_ (u"ࠬࢁࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣ࠼ࠥࡑ࡞ࠦࡁࡑࡋࠣࡏࡊ࡟ࠢ࠭ࠤࡷࡳࠧࡀ࡛ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࡞࠮ࠥࡷࡪࡴࡤࡦࡴࠥ࠾ࠧࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠦ࠱ࠨࡳࡶࡤ࡭ࡩࡨࡺࠢ࠻ࠤࡉࡶࡴࡳࠠࡂࡴࡤࡦ࡮ࡩࠠࡗ࡫ࡧࡩࡴࡹࠢ࠭ࠤࡷࡩࡽࡺ࡟ࡣࡱࡧࡽࠧࡀࠢࠨ怍")+message+l11lll_l1_ (u"࠭ࠢࡾࠩ怎")
	#	#auth=(l11lll_l1_ (u"ࠢࡢࡲ࡬ࠦ怏"), l11lll_l1_ (u"ࠣ࡯ࡼࠤࡵ࡫ࡲࡴࡱࡱࡥࡱࠦࡡࡱ࡫ࠣ࡯ࡪࡿࠢ怐")),
	#	import requests
	#	response = requests.request(l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ怑"),url, data=payload, headers=l11lll_l1_ (u"ࠪࠫ怒"), auth=l11lll_l1_ (u"ࠫࠬ怓"))
	#	response = requests.post(url, data=payload, headers=l11lll_l1_ (u"ࠬ࠭怔"), auth=l11lll_l1_ (u"࠭ࠧ怕"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ怖"),l11lll_l1_ (u"ࠨࠩ怗"),l11lll_l1_ (u"ࠩࠪ怘"),l11lll_l1_ (u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭怙"))
	#	else:
	#		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ怚"),l11lll_l1_ (u"ࠬ࠭怛"),l11lll_l1_ (u"࠭ฮุลࠣๅ๏ࠦวๅวิืฬ๊ࠧ怜"),l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡻࡾ࠼ࠣࡿࠦࡸࡽࠨ思").format(response.status_code, response.content))
	#	l1lll1lll1ll1_l1_ = l11lll_l1_ (u"ࠨ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠧ怞")
	#	l1llll11l111l_l1_ = l11lll_l1_ (u"ࠩࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨ怟")
	#	header = l11lll_l1_ (u"ࠪࠫ怠")
	#	#header += l11lll_l1_ (u"ࠫࡋࡸ࡯࡮࠼ࠣࠫ怡") + l1lll1lll1ll1_l1_
	#	#header += l11lll_l1_ (u"ࠬࡢ࡮ࡕࡱ࠽ࠤࠬ怢") + l1lll1l111l1l_l1_
	#	#header += l11lll_l1_ (u"࠭࡜࡯ࡅࡦ࠾ࠥ࠭怣") + l1lll1l111l1l_l1_
	#	header += l11lll_l1_ (u"ࠧ࡝ࡰࡖࡹࡧࡰࡥࡤࡶ࠽ࠤ๊์ࠠไ๊า๎ࠥอไโ์า๎ํࠦวๅ฻ิฬ๏࠭怤")
	#	server = l1llllll11111_l1_.l1llll11111l1_l1_(l11lll_l1_ (u"ࠨࡵࡰࡸࡵ࠳ࡳࡦࡴࡹࡩࡷ࠭急"),25)
	#	#server.l1llll11lll1l_l1_()
	#	server.l1llll1l1111l_l1_(l11lll_l1_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫ怦"),l11lll_l1_ (u"ࠪࡴࡦࡹࡳࡸࡱࡵࡨࠬ性"))
	#	response = server.l1llll1ll11ll_l1_(l1lll1lll1ll1_l1_,l1llll11l111l_l1_, header + l11lll_l1_ (u"ࠫࡡࡴࠧ怨") + message)
	#	server.quit()
	return
def l1lllll11l1ll_l1_():
	text = l11lll_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩ怩")
	l11ll11lll_l1_(l11lll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ怪"),l11lll_l1_ (u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧ怫"),text,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ怬"))
	text = l11lll_l1_ (u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬ怭")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ怮"),l11lll_l1_ (u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩ怯"),text,l11lll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ怰"))
	return
def l1llll11lllll_l1_(addon_id):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ怱"),l11lll_l1_ (u"ࠧࠨ怲"),l11lll_l1_ (u"ࠨࠩ怳"),addon_id)
	result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ怴")+addon_id+l11lll_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩ怵"))
	l1l11llll1_l1_ = True
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡰࡴࡴࡸࡴࠡࡵ࡫ࡹࡹ࡯࡬ࠋࠋࡻࡦࡲࡩࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡾࡢ࡮ࡥࡩࡳࡱࡪࡥࡳ࠮ࠪࡥࡩࡪ࡯࡯ࡵࠪ࠰ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠯ࠊࠊ࡫ࡩࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠩ࠻ࠌࠌࠍࡸ࡮ࡵࡵ࡫࡯࠲ࡷࡳࡴࡳࡧࡨࠬࡽࡨ࡭ࡤࡨ࡬ࡰࡪ࠯ࠊࠊࠋࡵࡩ࡫ࡸࡥࡴࡪࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࡺࡹࡥࡳࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡧࡤࡥࡱࡱࡷࠬ࠲ࡡࡥࡦࡲࡲࡤ࡯ࡤࠪࠌࠌ࡭࡫ࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮ࡦࡺ࡬ࡷࡹࡹࠨࡶࡵࡨࡶ࡫࡯࡬ࡦࠫ࠽ࠎࠎࠏࡳࡩࡷࡷ࡭ࡱ࠴ࡲ࡮ࡶࡵࡩࡪ࠮ࡵࡴࡧࡵࡪ࡮ࡲࡥࠪࠌࠌࠍࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡃࠠࡕࡴࡸࡩࠏࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡦࡪࡤࡰࡰࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡧࡤࡥࡱࡱࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࠣࡤࡥ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡶࡪࡶ࡯ࡴ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࡧࡴࡴ࡮࠯ࡥࡲࡱࡲ࡯ࡴࠩࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠧࠨࠢ怶")
	if l1l11llll1_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ怷"))
		time.sleep(1)
	return
def l1llll1lll1l1_l1_():
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ怸"),l11lll_l1_ (u"ࠧࠨ怹"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ怺"),l11lll_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠใะฺูࠥ็ศัฬࠤฬ๊สีใํีࠥ฿ๆะࠢส่ฬะีศๆࠣฬฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ่ࠦๅ้ำหࠥ็๊ࠡฯส่ࠥ๎ฬ้ัุࠣ์อฯสࠢ฽๎ึࠦีฮ์ะอࠥษ่ࠡ็้ฮ์๐ษࠡษ็ู้ออ๋หࠣวํࠦๅำ์ไอࠥ็ว็๊ࠢิฬࠦไ็ࠢํ์็็ࠠศๆิฬ฼ࠦวๅ็ืๅึ่ࠦๅ่ࠣ๎ํ่แࠡ฻่่ࠥอไษำ้ห๊าࠧ总"))
	l1llll1llll11_l1_()
	return
def l1llll1llll1l_l1_():
	#	https://l1111ll111l_l1_.tv/download/849
	#   https://play.google.com/l1llll111l1l1_l1_/l1llll11lll11_l1_/details?id=l1ll1lll111_l1_.xbmc.l1111ll111l_l1_
	#	http://mirror.l1llll1ll1ll1_l1_.l1lll1lll1lll_l1_.l1llllll1lll1_l1_/l1llll1l1llll_l1_/xbmc/l1llll1111ll1_l1_/l1lll1l11l1ll_l1_/l1llll1ll11l1_l1_
	#	http://l1lll1ll1l111_l1_.l1lll1l1l1ll1_l1_.l1llllll1lll1_l1_/l1111ll111l_l1_/l1llll1111ll1_l1_/l1lll1l11l1ll_l1_/l1llll1ll11l1_l1_
	url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱ࡮ࡸࡲࡰࡴࡶ࠲ࡰࡵࡤࡪ࠰ࡷࡺ࠴ࡸࡥ࡭ࡧࡤࡷࡪࡹ࠯ࡸ࡫ࡱࡨࡴࡽࡳ࠰ࡹ࡬ࡲ࠻࠺࠯ࠨ怼")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ怽"),url,l11lll_l1_ (u"ࠬ࠭怾"),l11lll_l1_ (u"࠭ࠧ怿"),l11lll_l1_ (u"ࠧࠨ恀"),l11lll_l1_ (u"ࠨࠩ恁"),l11lll_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡎࡏࡘࡡࡏࡅ࡙ࡋࡓࡕࡡࡎࡓࡉࡏ࡟ࡗࡇࡕࡗࡎࡕࡎ࠮࠳ࡶࡸࠬ恂"))
	html = response.content
	l1lll1l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥ࡯ࡴࡪࡩ࠮ࠪ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠱ࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠩ࠮ࠩ恃"),html,re.DOTALL)
	l1lll1l1l11ll_l1_ = l1lll1l1l11ll_l1_[0].split(l11lll_l1_ (u"ࠫ࠲࠭恄"))[0]
	l1llllll1l11l_l1_ = str(kodi_version)
	#l111lllll111_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ恅")+l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡๆสࠤ๏฿ๅๅ่ࠢ฽้่ࠥะ์ࠣษฺีวาࠢ࠴࠽ࠥ๎ๅศࠢห฽ิํࠧ恆")+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ恇")
	l111lllll111_l1_ = l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪ恈")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ恉")+l1lll1l1l11ll_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ恊")
	l111lllll111_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ恋")+l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫ恌")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ恍")+l1llllll1l11l_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ恎")
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ恏"),l11lll_l1_ (u"ࠩࠪ恐"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭恑"),l111lllll111_l1_)
	return
def l1lll1ll1l1ll_l1_():
	# https://l111lllll11_l1_-l1llll11ll1_l1_-l111l11l1l1_l1_.l1lllllll1l11_l1_.com/request-l1llll11ll111_l1_
	# https://l111lllll11_l1_-l1llll11ll1_l1_-l111l11l1l1_l1_.l1lllllll1l11_l1_.com/query-l1lll1l1l1l11_l1_
	l1l1ll11ll1_l1_,l1l1ll11lll_l1_,l111llll1lll_l1_,l111lllll111_l1_,l1llll1llllll_l1_,l1lll1l11l1l1_l1_,l1llll11111ll_l1_ = l11lll_l1_ (u"ࠫࠬ恒"),l11lll_l1_ (u"ࠬ࠭恓"),l11lll_l1_ (u"࠭ࠧ恔"),l11lll_l1_ (u"ࠧࠨ恕"),l11lll_l1_ (u"ࠨࠩ恖"),l11lll_l1_ (u"ࠩࠪ恗"),l11lll_l1_ (u"ࠪࠫ恘")
	payload,l1lll1l1l1l1l_l1_,l1llll1l1lll1_l1_,l1lll1l11ll1l_l1_ = {l11lll_l1_ (u"ࠫࡦ࠭恙"):l11lll_l1_ (u"ࠬࡧࠧ恚")},{},[],{}
	url = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭恛")][1]
	response = OPENURL_REQUESTS_CACHED(l1l1lllll111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ恜"),url,payload,l11lll_l1_ (u"ࠨࠩ恝"),l11lll_l1_ (u"ࠩࠪ恞"),l11lll_l1_ (u"ࠪࠫ恟"),l11lll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩ恠"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ恡"),l11lll_l1_ (u"࠭ࡕࡔࡃࠪ恢"))
	html = html.replace(l11lll_l1_ (u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨ恣"),l11lll_l1_ (u"ࠨࡗࡎࠫ恤"))
	html = html.replace(l11lll_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩ恥"),l11lll_l1_ (u"࡙ࠪࡆࡋࠧ恦"))
	html = html.replace(l11lll_l1_ (u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪ恧"),l11lll_l1_ (u"ࠬࡑࡓࡂࠩ恨"))
	html = html.replace(l11lll_l1_ (u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ恩"),l11lll_l1_ (u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ恪"))
	html = html.replace(l11lll_l1_ (u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩ恫"),l11lll_l1_ (u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫ恬"))
	html = html.replace(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ恭"),l11lll_l1_ (u"ࠫࠥࠦࠧ恮"))
	try: l1llll1l1ll1l_l1_ = EVAL(l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ息"),html)
	except:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ恰"),l11lll_l1_ (u"ࠧࠨ恱"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ恲"),l11lll_l1_ (u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ恳"))
		return
	l1lllll1ll111_l1_,l1llllll1ll11_l1_,l1llll11l1l11_l1_ = l1llll1l1ll1l_l1_
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ恴"),str(l1lllll1ll111_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ恵"),str(l1llllll1ll11_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭恶"),str(l1llll11l1l11_l1_))
	l1lll1l11ll1l_l1_ = {}
	l1111l11l1l_l1_ = [l11lll_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘ࠭恷"),l11lll_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩ恸"),l11lll_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪ恹")]
	l1lll1llllll_l1_ = [l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫ恺"),l11lll_l1_ (u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫ恻"),l11lll_l1_ (u"ࠫࡊࡓࡁࡊࡎࡖࠫ恼"),l11lll_l1_ (u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ恽"),l11lll_l1_ (u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ恾"),l11lll_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ恿"),l11lll_l1_ (u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭悀"),l11lll_l1_ (u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࡊࡉ࡙ࡏࡄࠨ悁"),l11lll_l1_ (u"ࠪࡇࡆࡖࡔࡄࡊࡄࡋࡊ࡚ࡔࡐࡍࡈࡒࠬ悂")]
	l1lllllll1l1l_l1_ = [l11lll_l1_ (u"ࠫࡆࡒࡌࠨ悃"),l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ悄"),l11lll_l1_ (u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ悅"),l11lll_l1_ (u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ悆"),l11lll_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ悇")]+l1lll1llllll_l1_+l1111l11l1l_l1_
	for l1l1l1ll1ll_l1_,l1llllll1111l_l1_,l1lllll1l1ll1_l1_ in l1llllll1ll11_l1_:
		l1lllll1l1ll1_l1_ = escapeUNICODE(l1lllll1l1ll1_l1_)
		l1lllll1l1ll1_l1_ = l1lllll1l1ll1_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ悈")).strip(l11lll_l1_ (u"ࠪࠤ࠳࠭悉"))
		l111lllll111_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ悊")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ悋")+l1lllll1l1ll1_l1_+l11lll_l1_ (u"࠭࡜࡯ࠩ悌")
		if l1llllll1111l_l1_.isdigit():
			l1lll1l11ll1l_l1_[l1l1l1ll1ll_l1_] = int(l1llllll1111l_l1_)
			if int(l1llllll1111l_l1_)>100: l1llllll1111l_l1_ = l11lll_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ悍")
			else: l1llllll1111l_l1_ = l11lll_l1_ (u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪ悎")
		if l1l1l1ll1ll_l1_ not in l1lllllll1l1l_l1_:
			if   l1llllll1111l_l1_==l11lll_l1_ (u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬ悏"): l1l1ll11ll1_l1_ += l11lll_l1_ (u"ࠪࠤࠥ࠭悐")+l1l1l1ll1ll_l1_
			elif l1llllll1111l_l1_==l11lll_l1_ (u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭悑"): l1l1ll11lll_l1_ += l11lll_l1_ (u"ࠬࠦࠠࠨ悒")+l1l1l1ll1ll_l1_
	l1lllllll11ll_l1_,l1lll1llllll1_l1_,l1llll1111l11_l1_ = list(zip(*l1llllll1ll11_l1_))
	for l1l1l1ll1ll_l1_ in sorted(l1l1l1lll1ll_l1_):
		if l1l1l1ll1ll_l1_ not in l1lllllll11ll_l1_:
			l111lllll111_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ悓")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ悔")+l11lll_l1_ (u"ࠨๆสࠤ๏๎ฬะࠩ悕")+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ悖")
			if l1l1l1ll1ll_l1_ not in l1lllllll1l1l_l1_: l111llll1lll_l1_ += l11lll_l1_ (u"ࠪࠤࠥ࠭悗")+l1l1l1ll1ll_l1_
	for l1lllll1l1ll1_l1_,counts in l1lllll1ll111_l1_:
		l1lllll1l1ll1_l1_ = escapeUNICODE(l1lllll1l1ll1_l1_)
		l1llll1llllll_l1_ += l1lllll1l1ll1_l1_+l11lll_l1_ (u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ悘")+str(counts)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠࠡࠢࠪ悙")
	l1l1ll11ll1_l1_ = l1l1ll11ll1_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ悚"))
	l1l1ll11lll_l1_ = l1l1ll11lll_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩ悛"))
	l111llll1lll_l1_ = l111llll1lll_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ悜"))
	l111lllll1l1_l1_ = l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠩࠣࠤࠬ悝")+l1l1ll11lll_l1_
	#l1111ll1ll11_l1_  = l11lll_l1_ (u"ࠪࡠࡳࡎࡩࡨࡪࡘࡷࡦ࡭ࡥ࠻ࠢ࡞ࠤࠬ悞")+l1l1ll11ll1_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ悟")
	#l1111ll1ll11_l1_ += l11lll_l1_ (u"ࠬࡢ࡮ࡍࡱࡺ࡙ࡸࡧࡧࡦࠢ࠽ࠤࡠࠦࠧ悠")+l1l1ll11lll_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ悡")
	#l1111ll1ll11_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࡑࡳ࡚ࡹࡡࡨࡧࠣࠤ࠿࡛ࠦࠡࠩ悢")+l111llll1lll_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ患")
	l111lllll11l_l1_  = l11lll_l1_ (u"่ࠩ์ฬู่่ࠡฯัࠥอไษำ้ห๊าࠠษฬื฾๏๊ࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭悤")+l11lll_l1_ (u"ࠪࡠࡳ࠭悥")+l11lll_l1_ (u"ࠫํํะศ่ࠢ฽๋อ็ࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๋๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠩ悦")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ悧")
	l111lllll11l_l1_ += l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ您")+l111lllll1l1_l1_+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳ࠭悩")
	l111lllll11l_l1_ += l11lll_l1_ (u"ࠨ็๋ห็฿ࠠๅ็ࠣ๎ูเไࠡษ็ฬึ์วๆฮ้๋ࠣํวࠡใํำ๏๎็ศฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠧ悪")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ悫")+l11lll_l1_ (u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊ࠠไสํีࠥ๎ฬ้ัู้้ࠣไสࠢไ๎ࠥอไษำ้ห๊าࠧ悬")+l11lll_l1_ (u"ࠫࡡࡴࠧ悭")
	l111lllll11l_l1_ += l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ悮")+l111llll1lll_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ悯")
	l1llllll1111_l1_,l1lll1ll1ll1l_l1_,l1llll1ll1l1l_l1_,l1lll1ll11ll1_l1_ = 0,0,0,0
	all = l1lll1l11ll1l_l1_[l11lll_l1_ (u"ࠧࡂࡎࡏࠫ悰")]
	if l11lll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ悱") in list(l1lll1l11ll1l_l1_.keys()): l1llllll1111_l1_ = l1lll1l11ll1l_l1_[l11lll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ悲")]
	if l11lll_l1_ (u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ悳") in list(l1lll1l11ll1l_l1_.keys()): l1lll1ll1ll1l_l1_ = l1lll1l11ll1l_l1_[l11lll_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ悴")]
	if l11lll_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ悵") in list(l1lll1l11ll1l_l1_.keys()): l1llll1ll1l1l_l1_ = l1lll1l11ll1l_l1_[l11lll_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ悶")]
	if l11lll_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭悷") in list(l1lll1l11ll1l_l1_.keys()): l1lll1ll11ll1_l1_ = l1lll1l11ll1l_l1_[l11lll_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ悸")]
	l1lll1lll11l1_l1_ = all-l1llllll1111_l1_-l1lll1ll1ll1l_l1_-l1llll1ll1l1l_l1_-l1lll1ll11ll1_l1_
	dummy,l1llll1l1l11l_l1_ = l1llll11l1l11_l1_[0]
	dummy,l1lll1l1llll1_l1_ = l1llll11l1l11_l1_[1]
	l1lll1lll11ll_l1_ = l1llll1l1l11l_l1_-l1lll1l1llll1_l1_
	l1llll11111ll_l1_ += l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ悹")+str(l1lll1l1llll1_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ悺")+l11lll_l1_ (u"ࠫฬู๊ะัࠣห้ำโ๋ไํࠤ้๊รอ้ีอࠥࡀࠠࠨ悻")
	l1llll11111ll_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ悼")+str(l1lll1lll11ll_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ悽")+l11lll_l1_ (u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫ悾")
	l1llll11111ll_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭悿")+str(l1llll1l1l11l_l1_)+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ惀")+l11lll_l1_ (u"ࠪห้฿ฯะࠢส่่๊๊ࠡๆฯ้๏฿ࠠศๆฦะ์ุษࠡ࠼ࠣࠫ惁")
	l1llll11111ll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ惂")+str(len(l1llll11l1l11_l1_[2:]))+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ惃")+l11lll_l1_ (u"ู࠭ะัࠣห้ี่ๅࠢส่ฯ๐ࠠโ์๊หࠥษฬ่ิฬࠤ࠿ࠦ࡜࡯࡞ࡱࠫ惄")
	for l1ll1111l11l_l1_,l1l11111lll1_l1_ in l1llll11l1l11_l1_[2:]:
		l1ll1111l11l_l1_ = escapeUNICODE(l1ll1111l11l_l1_)
		l1ll1111l11l_l1_ = l1ll1111l11l_l1_.strip(l11lll_l1_ (u"ࠧࠡࠩ情")).strip(l11lll_l1_ (u"ࠨࠢ࠱ࠫ惆"))
		l1llll11111ll_l1_ += l1ll1111l11l_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ惇")+str(l1l11111lll1_l1_)+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨ惈")
	#l1llll11111ll_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࠮ࠨ惉")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ惊")+str(l1lll1lll11l1_l1_)+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ惋")+l11lll_l1_ (u"ࠧโ์า๎ํํวหࠢสุฯเไหࠢ࠽ࠤࠬ惌")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭惍")+str(l1llllll1111_l1_)+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ惎")+l11lll_l1_ (u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡสส๎ะ๎ๆࠡ࠼ࠣࠫ惏")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ惐")+str(l1lll1ll11ll1_l1_)+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ惑")+l11lll_l1_ (u"࠭ืๅสสฮู๊ࠥาใิࠤฬ๊ๅิฬ๋ำ฾ࠦ࠺ࠡࠩ惒")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ惓")+str(l1lll1ll1ll1l_l1_)+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ惔")+l11lll_l1_ (u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭惕")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ惖")+str(l1llll1ll1l1l_l1_)+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭惗")+l11lll_l1_ (u"ࠬะหษ์อࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠼ࠣࠫ惘")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ惙")+str(len(l1lllll1ll111_l1_))+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ惚")+l11lll_l1_ (u"ࠨัฺฺ๋่ࠥๅฬࠣๅ๏ี๊้้สฮࠥࡀࠠࠨ惛")
	#l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ惜")+l11lll_l1_ (u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣห้฿วๅ็ࠣ๎ํ๋ࠠฤ็ึࠤ࠭อไษษิัฮ࠯ࠧ惝")+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭惞")
	l1lll1l11l1l1_l1_ += l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ惟")+l1llll1llllll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭惠"),l11lll_l1_ (u"ฺࠧัาࠤฬ๊รอ้ีอࠥอไห์ࠣหุะฮะ็อࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ惡"),l1llll11111ll_l1_,l11lll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ惢"))
	#l11ll11lll_l1_(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ惣"),l11lll_l1_ (u"ࠪะ๊๐ู้ࠡำ๋ࠥอไฤำๅห๊ࠦสฯืࠣวุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣࠤๆ่ืࠡ์๋้ࠥษๅิࠢࠫห้ฮวาฯฬ࠭ࠬ惤"),l1lll1l11l1l1_l1_,l11lll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ惥"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ惦"),l11lll_l1_ (u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ惧"),l1lll1l11l1l1_l1_,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ惨"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ惩"),l11lll_l1_ (u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ惪"),l111lllll11l_l1_,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭惫"))
	l11ll11lll_l1_(l11lll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ惬"),l11lll_l1_ (u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐ࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤฬูสฯั่ฮࠥอไษำ้ห๊าࠧ惭"),l111lllll111_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ惮"))
	return
def l1llll1111lll_l1_():
	message = l11lll_l1_ (u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣวํࠦสฮ็ํ่์ࠦๅ็࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࡠࡳࠦ็ั้ࠣห้ืำศๆฬࠤํเ๊า้สࠤ่ั๊า่ࠢ์ั๎ฯสࠢไ๎่ࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠥ๎วๅ็ี๎ิࠦรุ๋สࠤ๊๎ฬ้ัࠣๅ๏ࠦโศศ่อࠥษฬ้สฬࠤฬ๊ศา่ส้ั࠭惯")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ惰"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ惱"),message,l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭惲"))
	return
def l1l11llll111_l1_():
	message = l11lll_l1_ (u"ࠫฬ๊ัศสฺ๎๋ࠦระ่ส๋ࠥ็๊่็สࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิ่่๊ࠦࠣ฽ออัสࠢ฼๊ࠥะหษ์อࠤ่อๅๅࠢส์ฯ๎ๅศฬํ็๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎ๅฺ้ࠣห฻อแสࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ๎ๅฺ้ࠣห฻อแสࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิ่ࠦๆ฻๊ࠤฬ฼วโหุ้ࠣะ่ะ฻ࠣ฽๊อฯ๊ࠡไ๎์ࠦรุ๋สࠤัฺ๋๊ࠢส฽ิอฯหࠢๆ์ิ๐ࠠศๆ่฻้๎ศสࠢ็฽๊๊ࠠษำ้ห๊าฺࠠ็สำࠥ๎ใๅ้สࠤฯะๅࠡษ๋ฮํ๋วห์ๆ๎ฬ่ࠦๅษࠣฮาะวอࠢฦ๎ࠥ์ฺ่่๊ࠢࠥอไฯสิอࠥ็๊ࠡๅ๋ำ๏ࠦร้ࠢส่ำฮัสࠢไ๎ࠥะหษ์อࠤศ฼วโษอࠤ่๎ฯ๋ࠩ想")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ惴")+l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ惵")+l1ll11l_l1_[l11lll_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭惶")][0]+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥࠦࠠࠡล๋ࠤࠥࠦࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ惷")+l1ll11l_l1_[l11lll_l1_ (u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ惸")][1]+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ惹")
	message += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯࡞ࡱห้ืวษูࠣวิ์ว่๊ࠢ์ࠥอไิ๊ิืࠥอไั์ࠣ๎าะวอ้้ࠣิ๐ัࠡ็็ๅฬะࠠไ๊า๎๊ࠥสฬสํฮࠥฮั็ษ่ะࠥ฿ๅศัࠣฬฬ๊ืา์ๅอࠥอไหไ็๎ิ๐ษࠡษ็ๆิ๐ๅส࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭惺")+l1ll11l_l1_[l11lll_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭惻")][1]+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ惼")
	message += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪ惽")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ惾")+l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ惿")+l1ll11l_l1_[l11lll_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ愀")][2]+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭愁")
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ愂"),l11lll_l1_ (u"࠭วๅ็๋ห็฿ࠠศๆิื๊๐ษࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ愃"),message,l11lll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ愄"))
	return
def l1lllll1l1lll_l1_(l1lllll1ll11l_l1_):
	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠧ愅")+l1lllll1ll11l_l1_+l11lll_l1_ (u"ࠩࠬࠫ愆"), True)
	return
def l1lllll1l1111_l1_():
	l1ll11l11_l1_(l11lll_l1_ (u"ࠪࡷࡹࡵࡰࠨ愇"))
	xbmc.executebuiltin(l11lll_l1_ (u"ࠦࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࡔࡧࡷࡸ࡮ࡴࡧࡴࠫࠥ愈"))
	return
def l1llll11l11ll_l1_():
	xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠬࠫ愉"), True)
	return
def l1lll1llll11l_l1_(l1ll_l1_):
	if not l1ll_l1_: l1ll111ll1_l1_ = True
	else: l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭愊"),l11lll_l1_ (u"ࠧࠨ愋"),l11lll_l1_ (u"ࠨࠩ愌"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ愍"),l11lll_l1_ (u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣห้ศๆࠡมࠪ愎"))
	if l1ll111ll1_l1_==1:
		xbmc.executebuiltin(l11lll_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧ意"))
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭愐"),l11lll_l1_ (u"࠭ࠧ愑"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ愒"),l11lll_l1_ (u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨ愓"))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭愔"))
	return
def l1lll1llll1ll_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ愕"),l11lll_l1_ (u"ࠫࠬ愖"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ愗"),l11lll_l1_ (u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭愘"))
	return
def l1llll111111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ愙"),l11lll_l1_ (u"ࠨࠩ愚"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ愛"),l11lll_l1_ (u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠห่ๅีࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭愜"))
	return
#l1lllll1ll1ll_l1_ 	  required	and l1lllll1ll1ll_l1_     installed	and		not l1l111111l1l_l1_		ignore
#l1lllll1ll1ll_l1_ not required	and	l1lllll1ll1ll_l1_ not installed 	and 	    l1l111111l1l_l1_		ignore
#l1lllll1ll1ll_l1_ not required	and	l1lllll1ll1ll_l1_ not installed 	and 	not l1l111111l1l_l1_		ignore
#l1lllll1ll1ll_l1_ not required	and	l1lllll1ll1ll_l1_     installed 	and 	not l1l111111l1l_l1_		ignore
#l1lllll1ll1ll_l1_     required	and	l1lllll1ll1ll_l1_ not installed 	and 	    l1l111111l1l_l1_		l111111ll1_l1_ l1lll1ll1ll1l_l1_	l1lllll111111_l1_
#l1lllll1ll1ll_l1_     required	and	l1lllll1ll1ll_l1_ not installed 	and 	not l1l111111l1l_l1_		l111111ll1_l1_ l1lll1ll1ll1l_l1_	l1lllll111111_l1_
#l1lllll1ll1ll_l1_     required 	and l1lllll1ll1ll_l1_     installed 	and 	    l1l111111l1l_l1_		l111111ll1_l1_ l1llllll1l111_l1_	l1lllll111111_l1_
#l1lllll1ll1ll_l1_ not required	and	l1lllll1ll1ll_l1_     installed 	and 	    l1l111111l1l_l1_		l111111ll1_l1_ l1llllll1l111_l1_	l1lllll111111_l1_
#l1ll11ll11l1_l1_: required and not installed: l111111ll1_l1_ l1lll1ll1ll1l_l1_
#l1ll11ll1111_l1_: installed and l111111ll1_l1_ update: l111111ll1_l1_ l1llllll1l111_l1_
def l1l11ll1ll11_l1_(l1ll_l1_=True):
	l1llll1l11lll_l1_ = [l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴࡯ࡵࡪࡨࡶࡸ࠭愝"),l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡪ࠭愞"),l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦࠩ感"),l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡮ࡵࡣࠩ愠"),l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡢࠩ愡"),l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡨࡵࡤࡦࡤࡨࡶ࡬࠭愢")]
	l1llll1ll1111_l1_ = l1llll1l11lll_l1_+[l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ愣"),l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ愤"),l11lll_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫ愥"),l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡵ࡮ࡥ࡯ࡱࡰࡩࡳࡧ࡬ࡆࡏࡄࡈࠬ愦"),l11lll_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ愧"),l11lll_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ愨")]		# ,l11lll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡪࡰࡶࡸࡦࡲ࡬ࡆࡏࡄࡈࠬ愩")
	l1l111l11l1l_l1_ = l1ll1ll1l1ll_l1_([l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ愪")])
	l1llll1ll1l11_l1_ = []
	for addon_id in [l11lll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭愫")]:
		if addon_id not in list(l1l111l11l1l_l1_.keys()): continue
		l1l111111l1l_l1_,l1lll1llll1l_l1_,l1lllll11l111_l1_,l1lllll111lll_l1_,l1lllll111l11_l1_,l1lll1l1ll111_l1_,l1lllll111l1l_l1_ = l1l111l11l1l_l1_[addon_id]
		if not l1lll1llll1l_l1_ or (l1lll1llll1l_l1_ and l1l111111l1l_l1_): l1llll1ll1l11_l1_.append(addon_id)
	l1lll1l11l111_l1_ = len(l1llll1ll1l11_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1l111ll1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1lllll11ll1l_l1_ = []
	for addon_id in l1llll1l11lll_l1_:
		cc.execute(l11lll_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡦࡰࡤࡦࡱ࡫ࡤࠡ࠿ࠣࠦ࠶ࠨࠠࡢࡰࡧࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ愬")+addon_id+l11lll_l1_ (u"࠭ࠢࠡ࠽ࠪ愭"))
		l11ll1ll1l1_l1_ = cc.fetchall()
		if l11ll1ll1l1_l1_: l1lllll11ll1l_l1_.append(addon_id)
	l1llll111ll1l_l1_ = len(l1lllll11ll1l_l1_)>0
	for addon_id in l1llll1ll1111_l1_:
		cc.execute(l11lll_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ愮")+addon_id+l11lll_l1_ (u"ࠨࠤࠣ࠿ࠬ愯"))
		l1lllllll1ll1_l1_ = cc.fetchall()
		if l1lllllll1ll1_l1_ and l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ愰") not in str(l1lllllll1ll1_l1_): l1llll1ll1l11_l1_.append(addon_id)
	l1lll1lll1111_l1_ = len(l1llll1ll1l11_l1_)>0
	l1llll1ll1l11_l1_ = list(set(l1llll1ll1l11_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ愱"),l11lll_l1_ (u"ࠫࡳ࡫ࡥࡥࡡࡩ࡭ࡽ࡯࡮ࡨࡡࡵࡩࡵࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯࠼ࠣࠤࠬ愲")+str(l1lll1l11l111_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭愳"),l11lll_l1_ (u"࠭࡮ࡦࡧࡧࡣࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࡥ࡯࡭ࡦࡢࡥࡩࡪ࡯࡯ࡵ࠽ࠤࠥ࠭愴")+str(l1llll111ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ愵"),l11lll_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥ࡯ࡳ࡫ࡪ࡭ࡳࡀࠠࠡࠩ愶")+str(l1lll1lll1111_l1_))
	l1l111111l1l_l1_ = False
	if l1llll111ll1l_l1_ or l1lll1lll1111_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ愷"),l11lll_l1_ (u"ࠪࠫ愸"),l11lll_l1_ (u"ࠫࠬ愹"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ愺"),l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬ๊ࠡฯำ๋ࠥิไๆฬࠤๆ๐ࠠๆีอ์ิ฿ฺࠠ็สำࠥษ่ࠡ็ื็้ฯࠠโ์ࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฬ๊ย็ࠢย࡟࠴ࡉࡏࡍࡑࡕࡡࠬ愻"))
		if l1ll111ll1_l1_==1:
			l1llllll111l1_l1_ = True
			if l1lll1l11l111_l1_:
				l1llllll111l1_l1_ = l1lll1ll1l1l1_l1_(l11lll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ愼"),False,False)
			l1lll1ll111l1_l1_ = True
			if l1llll111ll1l_l1_:
				for addon_id in l1lllll11ll1l_l1_: l1llll11lllll_l1_(addon_id)
				l1lll1ll111l1_l1_ = True
			l1lll1ll11l1l_l1_ = True
			if l1lll1lll1111_l1_:
				conn = sqlite3.connect(l1l1l111ll1l_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1llll1ll1l11_l1_:
					if l11lll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫ愽") in addon_id: l1lllllll1ll1_l1_ = addon_id
					else: l1lllllll1ll1_l1_ = l11lll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ愾")
					try: cc.execute(l11lll_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧ愿")+l1lllllll1ll1_l1_+l11lll_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ慀")+addon_id+l11lll_l1_ (u"ࠬࠨࠠ࠼ࠩ慁"))
					except: l1lll1ll11l1l_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ慂"))
			time.sleep(1)
			if l1llllll111l1_l1_ or l1lll1ll111l1_l1_ or l1lll1ll11l1l_l1_:
				l1l111111l1l_l1_ = False
				DIALOG_OK(l11lll_l1_ (u"ࠧࠨ慃"),l11lll_l1_ (u"ࠨࠩ慄"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ慅"),l11lll_l1_ (u"ࠪะ๏ีࠠ࠯࠰ࠣฮ๊ࠦศ็ฮสัࠥะแฺ์็ࠤํหีๅษะࠤฬ๊ๅิฬ๋ำ฾่ࠦศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣัฺ๋๊ࠢศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ慆"))
			else:
				l1l111111l1l_l1_ = True
				DIALOG_OK(l11lll_l1_ (u"ࠫࠬ慇"),l11lll_l1_ (u"ࠬ࠭慈"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ慉"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦลึๆสั๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ส฻ไศฯࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไฦุสๅฬะࠠษำ้ห๊าฺࠠ็สำࠬ慊"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ態"),l11lll_l1_ (u"ࠩࠪ慌"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭慍"),l11lll_l1_ (u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอัู้้ࠣไสࠢไ๎๋ࠥำห๊า฽ࠥ฿ๅศัࠣวํࠦแ๋ࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ慎"))
	return l1l111111l1l_l1_
def l1lll1ll1lll1_l1_():
	l1lll1l11lll1_l1_,l1lllll1llll1_l1_,l1lllll11111l_l1_ = False,l11lll_l1_ (u"ࠬ࠭慏"),l11lll_l1_ (u"࠭ࠧ慐")
	l1lllll1lll11_l1_,l1llll11ll1l1_l1_,l1llll1l1l111_l1_ = False,l11lll_l1_ (u"ࠧࠨ慑"),l11lll_l1_ (u"ࠨࠩ慒")
	l1l111l11l1l_l1_ = l1ll1ll1l1ll_l1_([l11lll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ慓"),l11lll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ慔"),l11lll_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ慕")])
	for addon_id in [l11lll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ慖"),l11lll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ慗"),l11lll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭慘")]:
		if addon_id not in list(l1l111l11l1l_l1_.keys()): continue
		l1l111111l1l_l1_,l1lll1llll1l_l1_,l111111ll11_l1_,l1ll11lllll1_l1_,l111lll11l1_l1_,l11l1l11111_l1_,l1l1111111ll_l1_ = l1l111l11l1l_l1_[addon_id]
		if addon_id==l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭慙"):
			l1lllll1lll11_l1_ = l1l111111l1l_l1_
			l1llll11ll1l1_l1_ = l11lll_l1_ (u"ࠩࠫࠫ慚")+l1lll1llll1l_l1_+l11lll_l1_ (u"ࠪࠤࠬ慛")+TRANSLATE(l11l1l11111_l1_)+l11lll_l1_ (u"ࠫ࠮࠭慜")
			l1llll1l1l111_l1_ = l1ll11lllll1_l1_
		elif addon_id==l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ慝"):
			l1lll1l11lll1_l1_ = l1lll1l11lll1_l1_ or l1l111111l1l_l1_
			l1lllll1llll1_l1_ += l11lll_l1_ (u"࠭ࠠࠡ࠮ࠣࠤ࠭࠭慞")+l1lll1llll1l_l1_+l11lll_l1_ (u"ࠧࠡࠩ慟")+TRANSLATE(l11l1l11111_l1_)+l11lll_l1_ (u"ࠨࠫࠪ慠")
			l1lllll11111l_l1_ += l11lll_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ慡")+l1ll11lllll1_l1_
		elif addon_id==l11lll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ慢"):
			l1llll111l11l_l1_ = l1l111111l1l_l1_
			l1lll1lllllll_l1_ = l11lll_l1_ (u"ࠫ࠭࠭慣")+l1lll1llll1l_l1_+l11lll_l1_ (u"ࠬࠦࠧ慤")+TRANSLATE(l11l1l11111_l1_)+l11lll_l1_ (u"࠭ࠩࠨ慥")
			l1llll1lllll1_l1_ = l1ll11lllll1_l1_
	l1lllll1llll1_l1_ = l1lllll1llll1_l1_.strip(l11lll_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭慦"))
	l1lllll11111l_l1_ = l1lllll11111l_l1_.strip(l11lll_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ慧"))
	l1l11ll1l1_l1_  = l11lll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ慨")+l1llll1l1l111_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ慩")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴࠧ慪")+l11lll_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ慫")+l1llll11ll1l1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ慬")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ慭")+l11lll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ึฮํีูࠡ฻่หิࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ慮")+l1lllll11111l_l1_+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ慯")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠪࡠࡳ࠭慰")+l11lll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆีอ์ิ฿ฺࠠ็สำࠥํ่ࠡ࠼ࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ慱")+l1lllll1llll1_l1_+l11lll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ慲")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠫ慳")+l11lll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭慴")+l1llll1lllll1_l1_+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ慵")
	l1l11ll1l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ慶")+l11lll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭慷")+l1lll1lllllll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭慸")
	l1l111111l1l_l1_ = (l1lllll1lll11_l1_ or l1lll1l11lll1_l1_)
	if l1l111111l1l_l1_:
		header = l11lll_l1_ (u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧ慹")
		l1l1l1ll11_l1_ = l11lll_l1_ (u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧ慺")
	else:
		header = l11lll_l1_ (u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨ慻")
		l1l1l1ll11_l1_ = l11lll_l1_ (u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪ慼")
	l1l1l1l1ll_l1_ = l11lll_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ慽")
	l1ll11ll1l_l1_ = l1l11ll1l1_l1_+l11lll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ慾")+l1l1l1ll11_l1_+l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ慿")+l1l1l1l1ll_l1_
	l11ll11lll_l1_(l11lll_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ憀"),header,l1ll11ll1l_l1_,l11lll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ憁"))
	return
def l1ll111l1l11_l1_(l1ll_l1_=True,l1lll1lll1l11_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ憂"),l11lll_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ憃"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ憄"),l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ憅"))
	if l1ll_l1_:
		l1lll1ll1lll1_l1_()
		l1llll1llll1l_l1_()
	if l1lll1lll1l11_l1_:
		l1l11ll1ll11_l1_(False)
		l1l11lll1l1l_l1_ = []
		l1lllll11l1l1_l1_ = [l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ憆"),l11lll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ憇"),l11lll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ憈"),l11lll_l1_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦ࡯ࠫ憉")]
		for l1lll1llll1l1_l1_ in l1lllll11l1l1_l1_:
			succeeded,l1lllll1111l1_l1_,l1lll1llll1l_l1_ = l1lll1ll1l1l1_l1_(l1lll1llll1l1_l1_,True,False)
			l1l11lll1l1l_l1_.append(succeeded)
		l1lll1llll11l_l1_(l1ll_l1_)
		l11llllll111_l1_ = l11lll_l1_ (u"ࠨࠩ憊") if all(l1l11lll1l1l_l1_) else l11lll_l1_ (u"ࠩ࠴ࠫ憋")
		settings.setSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡲࡲࡷ࠳ࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠪ憌"),l11llllll111_l1_)
		settings.setSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡳࡳࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ憍"),str(now))
		xbmc.executebuiltin(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ憎"))
	return
def l1llll1ll1lll_l1_(l1lllll1l11l1_l1_=l11lll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ憏"),l1ll_l1_=True):
	l11111lll1l_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ憐"))
	import json
	data = json.loads(l11111lll1l_l1_)
	l1lll1l1l1lll_l1_ = data[l11lll_l1_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ憑")][l11lll_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ憒")]
	if kodi_version<19: l1lll1l1l1lll_l1_ = l1lll1l1l1lll_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ憓"))
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠫࠬ憔"),l11lll_l1_ (u"ࠬ࠭憕"),l11lll_l1_ (u"࠭ࠧ憖"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ憗"),l11lll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭憘")+l1lll1l1l1lll_l1_+l11lll_l1_ (u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫ憙")+l1lllll1l11l1_l1_+l11lll_l1_ (u"ࠪࠤฤࠧࠧ憚"))
		if l1ll111ll1_l1_!=1: return False
	succeeded,l1lllll1111l1_l1_,l1lll1l1ll1l1_l1_ = l1lll1ll1l1l1_l1_(l1lllll1l11l1_l1_,False,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ憛"),l11lll_l1_ (u"ࠬ࠭憜"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ憝"),l11lll_l1_ (u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩ憞"))
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬ憟")+l1lllll1l11l1_l1_+l11lll_l1_ (u"ࠩࠥࢁࢂ࠭憠"))
		if l11lll_l1_ (u"ࠪࡓࡐ࠭憡") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ憢"))
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭憣"),l11lll_l1_ (u"࠭ࠧ憤"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ憥"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪ憦"))
	return succeeded
def l111ll1l1l1_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11lll_l1_ (u"ࠩࠪ憧"): l1ll_l1_ = True
	#l1ll1l11lll1_l1_ = xbmc.getCondVisibility(l11lll_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭࠭憨")+addon_id+l11lll_l1_ (u"ࠫ࠮࠭憩"))
	l111lllll1l_l1_ = l1l1ll11ll1l_l1_([addon_id])
	l111l11ll1l_l1_,l1ll1l11lll1_l1_ = l111lllll1l_l1_[addon_id]
	if l1ll1l11lll1_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭憪"),l11lll_l1_ (u"࠭ࠧ憫"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ憬"),l11lll_l1_ (u"ࠨใะูࠥอไฦุสๅฮࠦ࡜࡯ࠢࠪ憭")+addon_id+l11lll_l1_ (u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬ憮"))
	else:
		succeeded = False
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ憯"),l11lll_l1_ (u"ࠫࠬ憰"),l11lll_l1_ (u"ࠬ࠭憱"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ憲"),l11lll_l1_ (u"ࠧࠨ憳")+addon_id+l11lll_l1_ (u"ࠨࠢ࡟ࡲࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ฼ํี๋ࠥแฺๆฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠤ࠳๊ࠦอสࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦไไ์ࠣ๎฾๋ไࠡษ็ฬึ์วๆฮࠣ฽๋ีใࠡสุ์ึฯࠠึฯํัฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢอฯอ๐ส๊ࠡอๅ฾๐ไ้ࠡำ๋ࠥอไฦุสๅฮࠦวๅฤ้ࠤฤ࠭憴"))
		if l1ll111ll1_l1_==1:
			xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡌࡲࡸࡺࡡ࡭࡮ࡄࡨࡩࡵ࡮ࠩࠩ憵")+addon_id+l11lll_l1_ (u"ࠪ࠭ࠬ憶"))
			time.sleep(1)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ憷"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11lll_l1_ (u"ࠬ࡝ࡩ࡯ࡦࡲࡻ࠳ࡏࡳࡂࡥࡷ࡭ࡻ࡫ࠨࡱࡴࡲ࡫ࡷ࡫ࡳࡴࡦ࡬ࡥࡱࡵࡧࠪࠩ憸")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11lll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ憹")+addon_id+l11lll_l1_ (u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ憺"))
			if l11lll_l1_ (u"ࠨࡑࡎࠫ憻") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ憼"),l11lll_l1_ (u"ࠪࠫ憽"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ憾"),l11lll_l1_ (u"ࠬะๅࠡใะูࠥษ่ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯ้้ࠠํࠤฬ๊ย็ࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫ憿"))
			elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ懀"),l11lll_l1_ (u"ࠧࠨ懁"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ懂"),l11lll_l1_ (u"ࠩไุ้ࠦแ๋ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠡ࠰ࠣ์ฬ๊อๅ๊ࠢ์ࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡ็้ࠤำอัอࠢส่อืๆศ็ฯࠫ懃"))
	return succeeded
def l1lll1lllll11_l1_(addon_id,l1l1111111ll_l1_,l1ll_l1_):
	succeeded = False
	if l1ll_l1_:
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࠫ懄"),l11lll_l1_ (u"ࠫࠬ懅"),l11lll_l1_ (u"ࠬ࠭懆"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ懇"),l11lll_l1_ (u"ࠧิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦฬๅสࠣห้๋ไโࠢส่๊฼ฺู้่้ࠣหึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦไไ์ࠣ๎ฯ๋ࠠหอห๎ฯํฺࠠๆ์ࠤ่๎ฯ๋ࠢ࠱ࠤฬ๊ๅๅใࠣๆิ๊ࠦไ๊้ࠤ่ฮ๊า๋ࠢๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡ࠰๋้ࠣࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢส่ว์ࠠภࠣࠪ懈"))
		if l1ll111ll1_l1_!=1: return False
	l1lll1l1l111l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l1111111ll_l1_,{},l1ll_l1_)
	if l1lll1l1l111l_l1_:
		l1l11111llll_l1_ = os.path.join(l1ll11llll_l1_,addon_id)
		l1ll11l1ll_l1_(l1l11111llll_l1_,True,False)
		import zipfile,io
		l1llll11ll11l_l1_ = io.BytesIO(l1lll1l1l111l_l1_)
		zf = zipfile.ZipFile(l1llll11ll11l_l1_)
		zf.extractall(l1ll11llll_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ應"))
		time.sleep(2)
		result = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ懊")+addon_id+l11lll_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ懋"))
		if l11lll_l1_ (u"ࠫࡔࡑࠧ懌") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ懍"),l11lll_l1_ (u"࠭ࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ懎"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ懏"),l11lll_l1_ (u"ࠨࠩ懐"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ懑"),l11lll_l1_ (u"ࠪฮ๊ࠦศ็ฮสัࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ懒"))
		else: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ懓"),l11lll_l1_ (u"ࠬ࠭懔"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ懕"),l11lll_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬ懖"))
	return succeeded
def l1lll1ll1l1l1_l1_(addon_id,l1ll_l1_,l1lllll11ll11_l1_):
	l1ll111ll1_l1_,succeeded,l1lllll1111l1_l1_,l1lll1llll1l_l1_ = True,False,l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ懗"),l11lll_l1_ (u"ࠩࠪ懘")
	l1l111l11l1l_l1_ = l1ll1ll1l1ll_l1_([addon_id])
	if addon_id in list(l1l111l11l1l_l1_.keys()):
		l1l111111l1l_l1_,l1lll1llll1l_l1_,l111111ll11_l1_,l1ll11lllll1_l1_,l111lll11l1_l1_,l11l1l11111_l1_,l1l1111111ll_l1_ = l1l111l11l1l_l1_[addon_id]
		if l11l1l11111_l1_==l11lll_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ懙"):
			succeeded,l1lllll1111l1_l1_ = True,l11lll_l1_ (u"ࠫࡳࡵࡴࡩ࡫ࡱ࡫ࠬ懚")
			if l1lllll11ll11_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭懛"),l11lll_l1_ (u"࠭ࠧ懜"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ懝"),l11lll_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲้่ࠥะ์ࠣ๎ุะฮะ็ࠣวำืࠠฦืาหึࠦๅห๊ไีࠥ็๊ࠡ็๋ห็฿ࠠๆีอ์ิ฿ฺࠠ็สำ๊ࠥ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ懞")+addon_id)
		else:
			if l1ll_l1_:
				if l11l1l11111_l1_==l11lll_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ懟"): message = l11lll_l1_ (u"้ࠪฯ๎โโหࠪ懠")
				elif l11l1l11111_l1_==l11lll_l1_ (u"ࠫࡴࡲࡤࠨ懡"): message = l11lll_l1_ (u"่ࠬฯ๋็ฬࠫ懢")
				elif l11l1l11111_l1_==l11lll_l1_ (u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ懣"): message = l11lll_l1_ (u"ࠧ฻์ิࠤ๊ัศหหࠪ懤")
				l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩ懥"),l11lll_l1_ (u"ࠩࠪ懦"),l11lll_l1_ (u"ࠪࠫ懧"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ懨"),l11lll_l1_ (u"ࠬํะ่ࠢส่ส฼วโหࠣࠫ懩")+message+l11lll_l1_ (u"࠭ࠠ࠯࠰๋้ࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡมࠤࡠࡳࡢ࡮ࠨ懪")+addon_id)
			if not l1ll111ll1_l1_: l1lllll1111l1_l1_ = l11lll_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩ懫")
			else:
				if l11l1l11111_l1_==l11lll_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ懬"):
					results = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ懭")+addon_id+l11lll_l1_ (u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ懮"))
					if l11lll_l1_ (u"ࠫࡔࡑࠧ懯") in results:
						succeeded,l1lllll1111l1_l1_ = True,l11lll_l1_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭懰")
						if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ懱"),l11lll_l1_ (u"ࠧࠨ懲"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ懳"),l11lll_l1_ (u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧ懴")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ懵"),l11lll_l1_ (u"ࠫࠬ懶"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ懷"),l11lll_l1_ (u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ษ฻อแส่ࠢฮํ่แสࠢ࠱࠲ࠥ๎ไๆࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฯฺฺ๋ๆ๊หࡡࡴ࡜࡯ࠩ懸")+addon_id)
				elif l11l1l11111_l1_ in [l11lll_l1_ (u"ࠧࡰ࡮ࡧࠫ懹"),l11lll_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ懺")]:
					succeeded = l1lll1lllll11_l1_(addon_id,l1l1111111ll_l1_,False)
					if succeeded:
						if l11l1l11111_l1_==l11lll_l1_ (u"ࠩࡲࡰࡩ࠭懻"): l1lllll1111l1_l1_ = l11lll_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫ懼")
						elif l11l1l11111_l1_==l11lll_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ懽"): l1lllll1111l1_l1_ = l11lll_l1_ (u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨ懾")
						l1lll1llll1l_l1_ = l1ll11lllll1_l1_
						if l1ll_l1_:
							if l1lllll1111l1_l1_==l11lll_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧ懿"): DIALOG_OK(l11lll_l1_ (u"ࠧࠨ戀"),l11lll_l1_ (u"ࠨࠩ戁"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ戂"),l11lll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦโะ์่อࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอัิ๐ห่ษ࡟ࡲࡡࡴࠧ戃")+addon_id)
							elif l1lllll1111l1_l1_==l11lll_l1_ (u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧ戄"): DIALOG_OK(l11lll_l1_ (u"ࠬ࠭戅"),l11lll_l1_ (u"࠭ࠧ戆"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ戇"),l11lll_l1_ (u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไฦุสๅฮࠦไๆࠢอ็๋ࠦๅ้ฮ๋ำฮࠦแ๋ࠢๆ์ิ๐ࠠ࠯࠰ࠣ์ฬ๊ศา่ส้ัࠦโศ็ࠣฬฯัศ๋ฬ๊หࡡࡴ࡜࡯ࠩ戈")+addon_id)
					elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ戉"),l11lll_l1_ (u"ࠪࠫ戊"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ戋"),l11lll_l1_ (u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥะอะ์ฮࠤศ๎ࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ戌")+addon_id)
	elif l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"࠭ࠧ戍"),l11lll_l1_ (u"ࠧࠨ戎"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ戏"),l11lll_l1_ (u"ࠩ็่ศูแࠡ࠰࠱ࠤ์ึ็ࠡษ็ษ฻อแสࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭成")+addon_id)
	return succeeded,l1lllll1111l1_l1_,l1lll1llll1l_l1_
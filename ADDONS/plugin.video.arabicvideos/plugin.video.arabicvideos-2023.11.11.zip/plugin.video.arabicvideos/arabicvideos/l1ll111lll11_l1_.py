# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚ࠬ䐾")
l11ll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭䐿")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11lll_l1_ (u"ࠧ࠱ࠩ䑀"),True)
	elif mode==102: results = ITEMS(l11lll_l1_ (u"ࠨ࠳ࠪ䑁"),True)
	elif mode==103: results = ITEMS(l11lll_l1_ (u"ࠩ࠵ࠫ䑂"),True)
	elif mode==104: results = ITEMS(l11lll_l1_ (u"ࠪ࠷ࠬ䑃"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11lll_l1_ (u"ࠫ࠹࠭䑄"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑅"),l11lll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䑆")+l11lll_l1_ (u"ࠧใ๊สส๊ࠦแ๋ัํ์์อสࠡࡏ࠶࡙ࠬ䑇"),l11lll_l1_ (u"ࠨࠩ䑈"),762)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䑉"),l11lll_l1_ (u"ࠪࡣࡎࡖࡔࡠࠩ䑊")+l11lll_l1_ (u"ࠫ็๎วว็ࠣๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠪ䑋"),l11lll_l1_ (u"ࠬ࠭䑌"),761)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑍"),l11lll_l1_ (u"ࠧࡠࡖ࡙࠴ࡤ࠭䑎")+l11lll_l1_ (u"ࠨไ้์ฬะࠠๆ่้ࠣํอโฺ้สࠤฬ๊รึๆํอࠬ䑏"),l11lll_l1_ (u"ࠩࠪ䑐"),101)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑑"),l11lll_l1_ (u"ࠫࡤ࡚ࡖ࠵ࡡࠪ䑒")+l11lll_l1_ (u"่ࠬๆ้ษอࠤ๊ิสศำฬࠤ๊์๋๊ࠠอ๎ํฮࠧ䑓"),l11lll_l1_ (u"࠭ࠧ䑔"),106)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑕"),l11lll_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ䑖")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ䑗"),l11lll_l1_ (u"ࠪࠫ䑘"),147)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑙"),l11lll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ䑚")+l11lll_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䑛"),l11lll_l1_ (u"ࠧࠨ䑜"),148)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑝"),l11lll_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ䑞")+l11lll_l1_ (u"ࠪࠤ่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠠࠡࠩ䑟"),l11lll_l1_ (u"ࠫࠬ䑠"),28)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䑡"),l11lll_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬ䑢")+l11lll_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ䑣"),l11lll_l1_ (u"ࠨࠩ䑤"),41)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䑥"),l11lll_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩ䑦")+l11lll_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ䑧"),l11lll_l1_ (u"ࠬ࠭䑨"),135)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䑩"),l11lll_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭䑪")+l11lll_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ䑫"),l11lll_l1_ (u"ࠩࠪ䑬"),38)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䑭"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䑮"),l11lll_l1_ (u"ࠬ࠭䑯"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑰"),l11lll_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭䑱")+l11lll_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨ䑲"),l11lll_l1_ (u"ࠩࠪ䑳"),102)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑴"),l11lll_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪ䑵")+l11lll_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬ䑶"),l11lll_l1_ (u"࠭ࠧ䑷"),103)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑸"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ䑹")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪ䑺"),l11lll_l1_ (u"ࠪࠫ䑻"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡚ࡖࠨ䑼")+menu+l11lll_l1_ (u"ࠬࡥࠧ䑽")
	user = l11llll11ll_l1_(32)
	payload = {l11lll_l1_ (u"࠭ࡩࡥࠩ䑾"):l11lll_l1_ (u"ࠧࠨ䑿"),l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䒀"):user,l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䒁"):l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䒂"),l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䒃"):menu}
	#data = l1ll1l1ll_l1_(payload)
	#LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䒄"),str(payload))
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䒅"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䒆"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠨࠩ䒇"), True,l11lll_l1_ (u"ࠩࠪ䒈"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䒉"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䒊"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠬ࠭䒋"),l11lll_l1_ (u"࠭ࠧ䒌"),l11lll_l1_ (u"ࠧࠨ䒍"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ䒎"))
	html = response.content
	#html = html.replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ䒏"),l11lll_l1_ (u"ࠪࠫ䒐"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䒑"),l11lll_l1_ (u"ࠬ࠭䒒"),html,html)
	#file = open(l11lll_l1_ (u"࠭ࡳ࠻࠱ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬ䒓"), l11lll_l1_ (u"ࠧࡸࠩ䒔"))
	#file.write(html)
	#file.close()
	items = re.findall(l11lll_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩ䒕"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11lll_l1_ (u"ࠩࡤࡰࠬ䒖"),l11lll_l1_ (u"ࠪࡅࡱ࠭䒗"))
			start = start.replace(l11lll_l1_ (u"ࠫࡊࡲࠧ䒘"),l11lll_l1_ (u"ࠬࡇ࡬ࠨ䒙"))
			start = start.replace(l11lll_l1_ (u"࠭ࡁࡍࠩ䒚"),l11lll_l1_ (u"ࠧࡂ࡮ࠪ䒛"))
			start = start.replace(l11lll_l1_ (u"ࠨࡇࡏࠫ䒜"),l11lll_l1_ (u"ࠩࡄࡰࠬ䒝"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11lll_l1_ (u"ࠪࡅࡱ࠳ࠧ䒞"),l11lll_l1_ (u"ࠫࡆࡲࠧ䒟"))
			start = start.replace(l11lll_l1_ (u"ࠬࡇ࡬ࠡࠩ䒠"),l11lll_l1_ (u"࠭ࡁ࡭ࠩ䒡"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll11ll_l1_,name,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠧࠤࠩ䒢") in source: continue
			#if source in [l11lll_l1_ (u"ࠨࡐࡗࠫ䒣"),l11lll_l1_ (u"ࠩ࡜࡙ࠬ䒤"),l11lll_l1_ (u"࡛ࠪࡘ࠶ࠧ䒥"),l11lll_l1_ (u"ࠫࡗࡒ࠱ࠨ䒦"),l11lll_l1_ (u"ࠬࡘࡌ࠳ࠩ䒧")]: continue
			if source!=l11lll_l1_ (u"࠭ࡕࡓࡎࠪ䒨"): name = name+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤࠥ࠭䒩")+source+l11lll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䒪")
			url = source+l11lll_l1_ (u"ࠩ࠾࠿ࠬ䒫")+server+l11lll_l1_ (u"ࠪ࠿ࡀ࠭䒬")+l11lll11ll_l1_+l11lll_l1_ (u"ࠫࡀࡁࠧ䒭")+menu
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ䒮"),l111ll_l1_+l11lll_l1_ (u"࠭ࠧ䒯")+name,url,105,l1llll_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䒰"),l111ll_l1_+l11lll_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ䒱"),l11lll_l1_ (u"ࠩࠪ䒲"),9999)
		#if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䒳"),l11lll_l1_ (u"ࠫࠬ䒴"),l11lll_l1_ (u"ࠬ࠭䒵"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䒶"))
		#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䒷"),l111ll_l1_+l11lll_l1_ (u"ࠨๆ็วุ็ࠠๅษࠣฮําฯࠡไ้์ฬะࠠหๆไึํ์๊สࠢ็็ࠬ䒸"),l11lll_l1_ (u"ࠩࠪ䒹"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䒺"),l111ll_l1_+l11lll_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆสๆึฮวย๋ࠢห้อีะไสลࠥ็โุࠩ䒻"),l11lll_l1_ (u"ࠬ࠭䒼"),9999)
		#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䒽"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䒾"),l11lll_l1_ (u"ࠨࠩ䒿"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䓀"),l111ll_l1_+l11lll_l1_ (u"࡙ࠪࡳ࡬࡯ࡳࡶࡸࡲࡦࡺࡥ࡭ࡻ࠯ࠤࡳࡵࠠࡕࡘࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠥ࡬࡯ࡳࠢࡼࡳࡺ࠭䓁"),l11lll_l1_ (u"ࠫࠬ䓂"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䓃"),l111ll_l1_+l11lll_l1_ (u"࠭ࡉࡵࠢ࡬ࡷࠥ࡬࡯ࡳࠢࡵࡩࡱࡧࡴࡪࡸࡨࡷࠥࠬࠠࡧࡴ࡬ࡩࡳࡪࡳࠡࡱࡱࡰࡾ࠭䓄"),l11lll_l1_ (u"ࠧࠨ䓅"),9999)
	return
def PLAY(id):
	source,server,l11lll11ll_l1_,menu = id.split(l11lll_l1_ (u"ࠨ࠽࠾ࠫ䓆"))
	url = l11lll_l1_ (u"ࠩࠪ䓇")
	user = l11llll11ll_l1_(32)
	if source==l11lll_l1_ (u"࡙ࠪࡗࡒࠧ䓈"): url = l11lll11ll_l1_
	elif source==l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ䓉"):
		url = l1ll11l_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䓊")][0]+l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䓋")+l11lll11ll_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䓌"),url)
		return
	elif source==l11lll_l1_ (u"ࠨࡉࡄࠫ䓍"):
		payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ䓎") : l11lll_l1_ (u"ࠪࠫ䓏"), l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ䓐") : user , l11lll_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ䓑") : l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠷ࠧ䓒") , l11lll_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ䓓") : l11lll_l1_ (u"ࠨࠩ䓔") }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䓕"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠪࠫ䓖"),False,l11lll_l1_ (u"ࠫࠬ䓗"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䓘"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䓙"),l11lll_l1_ (u"ࠧࠨ䓚"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䓛"),l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䓜"))
			return
		html = response.content
		cookies = response.cookies
		l1l11111111l_l1_ = cookies[l11lll_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪࠧ䓝")]
		url = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䓞")]
		payload = { l11lll_l1_ (u"ࠬ࡯ࡤࠨ䓟") : l11lll11ll_l1_ , l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ䓠") : user , l11lll_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ䓡") : l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾࡍࡁ࠳ࠩ䓢") , l11lll_l1_ (u"ࠩࡰࡩࡳࡻࠧ䓣") : l11lll_l1_ (u"ࠪࠫ䓤") }
		headers = { l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ䓥") : l11lll_l1_ (u"ࠬࡇࡓࡑ࠰ࡑࡉ࡙ࡥࡓࡦࡵࡶ࡭ࡴࡴࡉࡥ࠿ࠪ䓦")+l1l11111111l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䓧"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠧࠨ䓨"),l11lll_l1_ (u"ࠨࠩ䓩"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䓪"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䓫"),l11lll_l1_ (u"ࠫࠬ䓬"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䓭"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䓮"))
			return
		html = response.content
		url = re.findall(l11lll_l1_ (u"ࠧࡳࡧࡶࡴࠧࡀࠢࠩࡪࡷࡸࡵ࠴ࠪࡀ࡯࠶ࡹ࠽࠯ࠨ࠯ࠬࡂ࠭ࠧ࠭䓯"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ䓰"),l11lll_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬࠢࠪ䓱")+link)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ䓲"),l11lll_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠬ䓳")+params)
		l1l111111111_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠸࠯ࠩ䓴")+server+l11lll_l1_ (u"࠭࠷࠸࠹࠲ࠫ䓵")+l11lll11ll_l1_+l11lll_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ䓶")+params
		l11lllllllll_l1_ = l1l111111111_l1_.replace(l11lll_l1_ (u"ࠨ࠵࠹࠾࠼࠭䓷"),l11lll_l1_ (u"ࠩ࠷࠴࠿࠽ࠧ䓸")).replace(l11lll_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ䓹"),l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䓺"))
		l1l1111111l1_l1_ = l1l111111111_l1_.replace(l11lll_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ䓻"),l11lll_l1_ (u"࠭࠴࠳࠼࠺ࠫ䓼")).replace(l11lll_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ䓽"),l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䓾"))
		l1lll1ll_l1_ = [l11lll_l1_ (u"ࠩࡋࡈࠬ䓿"),l11lll_l1_ (u"ࠪࡗࡉ࠷ࠧ䔀"),l11lll_l1_ (u"ࠫࡘࡊ࠲ࠨ䔁")]
		l1111_l1_ = [l1l111111111_l1_,l11lllllllll_l1_,l1l1111111l1_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ䔂"), l1lll1ll_l1_)
		if l1l_l1_ == -1: return
		else: url = l1111_l1_[l1l_l1_]
	elif source==l11lll_l1_ (u"࠭ࡎࡕࠩ䔃"):
		headers = { l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䔄") : l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䔅") }
		payload = { l11lll_l1_ (u"ࠩ࡬ࡨࠬ䔆") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䔇") : user , l11lll_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭䔈") : l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡑࡘࠬ䔉") , l11lll_l1_ (u"࠭࡭ࡦࡰࡸࠫ䔊") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䔋"), l11ll1_l1_, payload, headers, False,l11lll_l1_ (u"ࠨࠩ䔌"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䔍"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䔎"),l11lll_l1_ (u"ࠫࠬ䔏"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䔐"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䔑"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䔒")]
		url = url.replace(l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ䔓"),l11lll_l1_ (u"ࠩࠣࠫ䔔"))
		url = url.replace(l11lll_l1_ (u"ࠪࠩ࠸ࡊࠧ䔕"),l11lll_l1_ (u"ࠫࡂ࠭䔖"))
		if l11lll_l1_ (u"ࠬࡒࡥࡢࡴࡱࠫ䔗") in l11lll11ll_l1_:
			url = url.replace(l11lll_l1_ (u"࠭ࡎࡕࡐࡑ࡭ࡱ࡫ࠧ䔘"),l11lll_l1_ (u"ࠧࠨ䔙"))
			url = url.replace(l11lll_l1_ (u"ࠨ࡮ࡨࡥࡷࡴࡩ࡯ࡩ࠴ࠫ䔚"),l11lll_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࡪࡰࡪࠫ䔛"))
	elif source==l11lll_l1_ (u"ࠪࡔࡑ࠭䔜"):
		#headers = { l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䔝") : l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䔞") }
		payload = { l11lll_l1_ (u"࠭ࡩࡥࠩ䔟") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ䔠") : user , l11lll_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ䔡") : l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡐࡍࠩ䔢") , l11lll_l1_ (u"ࠪࡱࡪࡴࡵࠨ䔣") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䔤"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠬ࠭䔥"),False,l11lll_l1_ (u"࠭ࠧ䔦"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ䔧"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ䔨"),l11lll_l1_ (u"ࠩࠪ䔩"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䔪"),l11lll_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ䔫"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䔬")]
		headers = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䔭"):response.headers[l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䔮")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䔯"),url, l11lll_l1_ (u"ࠩࠪ䔰"),headers , l11lll_l1_ (u"ࠪࠫ䔱"),l11lll_l1_ (u"ࠫࠬ䔲"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧ䔳"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"࠭ࠧ䔴"),l11lll_l1_ (u"ࠧࠨ䔵"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䔶"),l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䔷"))
			return
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䔸"),html,re.DOTALL)
		url = items[0]
	elif source in [l11lll_l1_ (u"࡙ࠫࡇࠧ䔹"),l11lll_l1_ (u"ࠬࡌࡍࠨ䔺"),l11lll_l1_ (u"࡙࠭ࡖࠩ䔻"),l11lll_l1_ (u"ࠧࡘࡕ࠴ࠫ䔼"),l11lll_l1_ (u"ࠨ࡙ࡖ࠶ࠬ䔽"),l11lll_l1_ (u"ࠩࡕࡐ࠶࠭䔾"),l11lll_l1_ (u"ࠪࡖࡑ࠸ࠧ䔿")]:
		if source==l11lll_l1_ (u"࡙ࠫࡇࠧ䕀"): l11lll11ll_l1_ = id
		headers = { l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䕁") : l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䕂") }
		payload = { l11lll_l1_ (u"ࠧࡪࡦࠪ䕃") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䕄") : user , l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䕅") : l11lll_l1_ (u"ࠪࡴࡱࡧࡹࠨ䕆")+source , l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䕇") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䕈"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"࠭ࠧ䕉"),l11lll_l1_ (u"ࠧࠨ䕊"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪ䕋"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䕌"),l11lll_l1_ (u"ࠪࠫ䕍"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䕎"),l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭䕏"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䕐")]
		if source==l11lll_l1_ (u"ࠧࡇࡏࠪ䕑"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䕒"), url, l11lll_l1_ (u"ࠩࠪ䕓"), l11lll_l1_ (u"ࠪࠫ䕔"), False,l11lll_l1_ (u"ࠫࠬ䕕"),l11lll_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠻ࡹ࡮ࠧ䕖"))
			url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䕗")]
			url = url.replace(l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭䕘"),l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭䕙"))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䕚"))
	return
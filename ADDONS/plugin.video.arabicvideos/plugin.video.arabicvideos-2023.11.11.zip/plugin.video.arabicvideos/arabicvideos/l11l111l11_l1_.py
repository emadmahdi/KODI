# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨῡ")
def MAIN(mode,url):
	if   mode==330: results = l11ll111l1_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l11ll1l_l1_()
	elif mode==333: results = l111llll11_l1_()
	elif mode==334: results = l1ll1111l1_l1_(url)
	else: results = False
	return results
def l1ll1111l1_l1_(l11l1l11l1_l1_):
	try: os.remove(l11l1l11l1_l1_.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬῢ")))
	except: os.remove(l11l1l11l1_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧΰ"))
	return
def l111llll11_l1_():
	message = l11lll_l1_ (u"ࠩฦิ์ฮࠠฦๆ์ࠤึอศุࠢส่ๆ๐ฯ๋๊ࠣวํࠦวๅื๋ฮࠥ็๊ࠡษ็้ํู่ࠡษ็้฼๊่ษࠢฮ้ࠥษึ฻ูࠣ฽้๏ࠠำำࠣห้่วว็ฬࠤฬ๊๊ๆ์้ࠤะ๋ࠠฤะอหึࠦࠢหฯ่๎้ࠦๅๅใสฮࠥ็๊ะ์๋ࠦࠥัๅࠡษัฮฬืࠠะไฬࠤฬ๊ี้ำฬࠤํอฮหษิࠤ๋๎ูࠡ็็ๅࠥอไึ๊ิอࠥ๎ศฺั๊หู่ࠥโࠢํฬิษࠠศๆอั๊๐ไࠨῤ")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫῥ"),l11lll_l1_ (u"ࠫࠬῦ"),l11lll_l1_ (u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆࠣห้๋ไโษอࠫῧ"),message)
	return
def l11ll111l1_l1_():
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫῨ"),l11lll_l1_ (u"ุࠧำํๆฮࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬῩ"),l11lll_l1_ (u"ࠨࠩῪ"),333)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧΎ"),l11lll_l1_ (u"ࠪฮ฿๐๊า่ࠢ็ฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠪῬ"),l11lll_l1_ (u"ࠫࠬ῭"),332)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ΅"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭`"),l11lll_l1_ (u"ࠧࠨ῰"),9999)
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	mtime = os.stat(l11l1ll111_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l1l1lll_l1_ = os.listdir(l11l1ll111_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭῱")))
	else: l11l1l1lll_l1_ = os.listdir(l11l1ll111_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧῲ")))
	for filename in l11l1l1lll_l1_:
		if kodi_version>18.99: filename = filename.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨῳ"))
		if not filename.startswith(l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪῴ")): continue
		filepath = os.path.join(l11l1ll111_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11l1llll1_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ῵"))
			except: pass
			filename = filename.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫῶ"))
		filepath = os.path.join(l11l1ll111_l1_,filename)
		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ῷ"),filename,filepath,331)
	return
def l11l11l1ll_l1_():
	l11l1ll111_l1_ = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫῸ"))
	if l11l1ll111_l1_: return l11l1ll111_l1_
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬΌ"),addoncachefolder)
	return addoncachefolder
def l11l11ll1l_l1_():
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	l11l1111ll_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪῺ"),l11lll_l1_ (u"ࠫࠬΏ"),l11lll_l1_ (u"ࠬ࠭ῼ"),l11l1ll111_l1_,l11lll_l1_ (u"࠭็ัษ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢอ฾๏๐ัࠡษ็้่อๆࠡมࠪ´"))
	if l11l1111ll_l1_==1:
		newpath = l11l11llll_l1_(3,l11lll_l1_ (u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫ῾"),l11lll_l1_ (u"ࠨ࡮ࡲࡧࡦࡲࠧ῿"),l11lll_l1_ (u"ࠩࠪ "),False,True,l11l1ll111_l1_)
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ "),l11lll_l1_ (u"ࠫࠬ "),l11lll_l1_ (u"ࠬ࠭ "),newpath,l11lll_l1_ (u"࠭็ัษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅฮา๎ิࠦไหะี๎๋ࠦๅๅใสฮࠥอไโ์า๎ํࠦวๅฬํࠤฯำๅๅ้สࠤฬ์สࠡสสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥอำหะาห๊ํࠠษั็ห๋ࠥๆࠡษ็้่อๆࠡษ็ๆิ๐ๅࠡมࠪ "))
		if l1ll111ll1_l1_==1:
			settings.setSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪ "),newpath)
			DIALOG_OK(l11lll_l1_ (u"ࠨࠩ "),l11lll_l1_ (u"ࠩࠪ "),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ "),l11lll_l1_ (u"ࠫฯ๋ࠠห฼ํ๎ึࠦๅไษ้ࠤฯิา๋่ࠣห้๋ไโษอࠤฬ๊ๅฮ็็อࠬ "))
	#if not l11l1111ll_l1_ or not l1ll111ll1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ "),l11lll_l1_ (u"࠭ࠧ​"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ‌"),l11lll_l1_ (u"ࠨฬ่ࠤฬฺ๊ศรࠣห้฿ๅๅ์ฬࠫ‍"))
	return
def l11l11lll1_l1_(filename):
	l11ll1111l_l1_ = l11lll_l1_ (u"ࠩࠪ‎").join(l11l1lllll_l1_ for l11l1lllll_l1_ in filename if l11l1lllll_l1_ not in l11lll_l1_ (u"ࠪࡠ࠴ࠨ࠺ࠫࡁ࠿ࡂࢁ࠭‏")+half_triangular_colon)
	return l11ll1111l_l1_
def l11l11l1l1_l1_(url,l111lll11l_l1_=l11lll_l1_ (u"ࠫࠬ‐"),l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭‑")):
	#DIALOG_NOTIFICATION(l11lll_l1_ (u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭‒"),l11lll_l1_ (u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ–"))
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ—"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ―")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭‖"))
	if not l111lll11l_l1_: l111lll11l_l1_ = l11l1ll1ll_l1_(url,l1l1ll11_l1_)
	#if not l111lll11l_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠫࠬ‗"),l11lll_l1_ (u"ࠬ࠭‘"),l11lll_l1_ (u"࠭ส็ิํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ’"),l11lll_l1_ (u"ࠧศๆ่่ๆࠦๅ็้ࠢ์฾ࠦࠧ‚")+l111lll11l_l1_+l11lll_l1_ (u"ࠨ๋ࠢห้ฮั็ษ่ะࠥำวๅ์สࠤ฿๐ัࠡฮส๋ืࠦไหฯ่๎้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไๆๆไหฯ࠭‛"))
	#	LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ“"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡺࡹࡱࡧ࠲ࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࠦࡩࡴࠢࡱࡳࡹࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ”")+url+l11lll_l1_ (u"ࠫࠥࡣࠧ„"))
	#	return False
	l11l1ll111_l1_ = l11l11l1ll_l1_()
	l11l1lll11_l1_ = l11l1l1l1l_l1_()
	filename = l11l1lll11_l1_.replace(l11lll_l1_ (u"ࠬࠦࠧ‟"),l11lll_l1_ (u"࠭࡟ࠨ†"))
	filename = l11l11lll1_l1_(filename)
	#l111lll11l_l1_ = l111lll11l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ‡"))
	filename = l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ•")+str(int(now))[-4:]+l11lll_l1_ (u"ࠩࡢࠫ‣")+filename+l111lll11l_l1_
	l111llll1l_l1_ = os.path.join(l11l1ll111_l1_,filename)
	headers = {}
	headers[l11lll_l1_ (u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࠬ․")] = l11lll_l1_ (u"ࠫࠬ‥")
	headers[l11lll_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸࠬ…")] = l11lll_l1_ (u"࠭ࠪ࠰ࠬࠪ‧")
	url = url.replace(l11lll_l1_ (u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ "),l11lll_l1_ (u"ࠨࠩ "))
	if l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ‪") in url:
		l11l11l_l1_,l111lll1l1_l1_ = url.rsplit(l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ‫"),1)
		l111lll1l1_l1_ = l111lll1l1_l1_.replace(l11lll_l1_ (u"ࠫࢁ࠭‬"),l11lll_l1_ (u"ࠬ࠭‭")).replace(l11lll_l1_ (u"࠭ࠦࠨ‮"),l11lll_l1_ (u"ࠧࠨ "))
	else: l11l11l_l1_,l111lll1l1_l1_ = url,None
	if not l111lll1l1_l1_: l111lll1l1_l1_ = l1l11l11l_l1_()
	if l111lll1l1_l1_: headers[l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ‰")] = l111lll1l1_l1_
	if l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ‱") in l11l11l_l1_: l11l11l_l1_,l11l111ll1_l1_ = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ′"),1)
	else: l11l11l_l1_,l11l111ll1_l1_ = l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ″")
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠬࢂࠧ‴")).strip(l11lll_l1_ (u"࠭ࠦࠨ‵")).strip(l11lll_l1_ (u"ࠧࡽࠩ‶")).strip(l11lll_l1_ (u"ࠨࠨࠪ‷"))
	l11l111ll1_l1_ = l11l111ll1_l1_.replace(l11lll_l1_ (u"ࠩࡿࠫ‸"),l11lll_l1_ (u"ࠪࠫ‹")).replace(l11lll_l1_ (u"ࠫࠫ࠭›"),l11lll_l1_ (u"ࠬ࠭※"))
	if l11l111ll1_l1_:	headers[l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ‼")] = l11l111ll1_l1_
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ‽"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ‾")+l11l11l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ‿")+str(headers)+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ⁀")+l111llll1l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ⁁"))
	l11ll111ll_l1_ = 1024*1024
	l11l1ll1l1_l1_ = 0
	try:
		l11l1ll11l_l1_ =	xbmc.getInfoLabel(l11lll_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡦࡧࡖࡴࡦࡩࡥࠨ⁂"))
		l11l1ll11l_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࠭ࠪ⁃"),l11l1ll11l_l1_)
		l11l1ll1l1_l1_ = int(l11l1ll11l_l1_[0])
	except: pass
	if not l11l1ll1l1_l1_:
		try:
			l11l1l11ll_l1_ = os.l111lll111_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l1l11ll_l1_.f_frsize*l11l1l11ll_l1_.f_bavail//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		try:
			l11l1l11ll_l1_ = os.l11ll11111_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l1l11ll_l1_.f_frsize*l11l1l11ll_l1_.f_bavail//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		try:
			import shutil
			total,l11l11ll11_l1_,l11l11l11l_l1_ = shutil.l11ll11ll1_l1_(l11l1ll111_l1_)
			l11l1ll1l1_l1_ = l11l11l11l_l1_//l11ll111ll_l1_
		except: pass
	if not l11l1ll1l1_l1_:
		l11ll11lll_l1_(l11lll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭⁄"),l11lll_l1_ (u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨ⁅"),l11lll_l1_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭⁆"),l11lll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭⁇"))
		LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⁈"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡩ࡫ࡴࡦࡴࡰ࡭ࡳ࡫ࠠࡵࡪࡨࠤࡩ࡯ࡳ࡬ࠢࡩࡶࡪ࡫ࠠࡴࡲࡤࡧࡪ࠭⁉"))
		return False
	import requests
	if l111lll11l_l1_==l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ⁊"):
		l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(l11l11l_l1_,headers)
		#DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ⁋"), l1lll1ll_l1_)
		#DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭⁌"), l1111_l1_)
		if len(l1lll1ll_l1_)==0:
			DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠩไุ้ࠦแ๋ࠢศ๎ัอฯࠡ็็ๅࠥอไหฯ่๎้࠭⁍"),l11lll_l1_ (u"ࠪࠫ⁎"))
			return False
		elif len(l1lll1ll_l1_)==1: l1l_l1_ = 0
		elif len(l1lll1ll_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษࠩ⁏"), l1lll1ll_l1_)
			if l1l_l1_ == -1 :
				DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอั๊๐ไࠨ⁐"),l11lll_l1_ (u"࠭ࠧ⁑"))
				return False
		l11l11l_l1_ = l1111_l1_[l1l_l1_]
	filesize = 0
	if l111lll11l_l1_==l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭⁒"):
		l111llll1l_l1_ = l111llll1l_l1_.rsplit(l11lll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ⁓"))[0]+l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ⁔")
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⁕"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ⁖"),headers,l11lll_l1_ (u"ࠬ࠭⁗"),l11lll_l1_ (u"࠭ࠧ⁘"),l11lll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅ࠯ࡇࡓ࡜ࡔࡌࡐࡃࡇࡣ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ⁙"))
		l1llll1l1_l1_ = response.content
		links = re.findall(l11lll_l1_ (u"ࠨ࡞ࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ⁚"),l1llll1l1_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࡡࡸࠧ⁛"),re.DOTALL)
		if not links:
			LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ⁜"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⁝")+l11l11l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ⁞"))
			return False
		link = links[0]
		if not link.startswith(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ ")):
			if link.startswith(l11lll_l1_ (u"ࠧ࠰࠱ࠪ⁠")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠨ࠼ࠪ⁡"),1)[0]+l11lll_l1_ (u"ࠩ࠽ࠫ⁢")+link
			elif link.startswith(l11lll_l1_ (u"ࠪ࠳ࠬ⁣")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ⁤"))+link
			else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠬ࠵ࠧ⁥"),1)[0]+l11lll_l1_ (u"࠭࠯ࠨ⁦")+link
		response = requests.request(l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⁧"),link,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l11l111_l1_ = len(links)
		filesize = chunksize*l11l11l111_l1_
	else:
		chunksize = 1*l11ll111ll_l1_
		response = requests.request(l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⁨"),l11l11l_l1_,headers=headers,verify=False,stream=True)
		if l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪ⁩") in response.headers: filesize = int(response.headers[l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ⁪")])
		l11l11l111_l1_ = int(filesize//chunksize)
	#l11l1lll1l_l1_ = l11l11l111_l1_+1
	l11l1lll1l_l1_ = int(filesize//l11ll111ll_l1_)+1
	if filesize<21000:
		LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⁫"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡶࡲࡳࠥࡹ࡭ࡢ࡮࡯ࠤࡴࡸࠠࡪࡶࠣ࡭ࡸࠦ࡭࠴ࡷ࠻ࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⁬")+l11l11l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪ⁭")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭⁮")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ⁯")+l111llll1l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠬ⁰"))
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫⁱ"),l11lll_l1_ (u"ࠫࠬ⁲"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ⁳"),l11lll_l1_ (u"࠭แีๆࠣๅ๏ࠦๅฺำไอࠥำฬๆ่่ࠢๆࠦวๅใํำ๏๎ࠠฤ๊ࠣห้๋ไโุࠢ฾๏ืࠠอัสࠤํ๊็ัษ่ࠣฬ๊ࠦๆๅ้ࠤ้๊ศา่ส้ัࠦสฮ็ํ่ࠥํะศࠢส่๊๊แࠨ⁴"))
		return False
	l11l111l1l_l1_ = 400
	l11l111111_l1_ = l11l1ll1l1_l1_-l11l1lll1l_l1_
	if l11l111111_l1_<l11l111l1l_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ⁵"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡓࡵࡴࠡࡧࡱࡳࡺ࡭ࡨࠡࡦ࡬ࡷࡰࠦࡳࡱࡣࡦࡩࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⁶")+l11l11l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭⁷")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ⁸")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠫࠥࡓࡂࠡ࠯ࠣࠫ⁹")+str(l11l111l1l_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨ⁺")+l111llll1l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩ⁻"))
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⁼"),l11lll_l1_ (u"ࠨࠩ⁽"),l11lll_l1_ (u"ࠩ็หࠥ๐่อัุ้ࠣออสࠢๆหๆ๐ษࠡๆ็ฮา๋๊ๅࠩ⁾"),l11lll_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣัั๋็ࠡࠩⁿ")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢࠪ₀")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡ็่๊ำวโฺฬࠤ฾๊้ࠡ฻่่ࠥา็ศิๆࠤอี่็ุ่ࠢฬ้ไࠡ์ฯฬࠥหศใษฤࠤࠬ₁")+str(l11l111l1l_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊หࠢไหึเษࠡัสส๊อ้้ࠠำหู๋ࠥ็ษ๊ࠤศ์ࠠอ้สึ่ࠦไศࠢอ์ัีࠠโ์๊ࠤู๊วฮหࠣ็ฬ็๊สࠢ็ฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศࠨ₂"))
		return False
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ₃"),l11lll_l1_ (u"ࠨࠩ₄"),l11lll_l1_ (u"ࠩࠪ₅"),l11lll_l1_ (u"๋้ࠪࠦสา์าࠤฯำๅ๋ๆࠣห้๋ไโࠢยࠫ₆"),l11lll_l1_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤาาๅ่ࠢอๆึ๐ศศࠢࠪ₇")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣฮ็ื๊ษษࠣࠫ₈")+str(l11l1ll1l1_l1_)+l11lll_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋๋ࠢีอࠠศๆ่่ๆࠦโะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ้๊สฮ็ํ่๋ࠥๆࠡษ็ษ๋ะั็ฬࠣษ้๏ࠠอ้สึ่ࠦ࠮้ࠡ็ࠤฬ์สࠡ็อว่ี้ࠠฬิ๎ิࠦวๅษึฮ๊ืวาࠢหฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠠภࠩ₉"))
	if l1ll111ll1_l1_!=1:
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨ₊"),l11lll_l1_ (u"ࠨࠩ₋"),l11lll_l1_ (u"ࠩࠪ₌"),l11lll_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ₍"))
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ₎"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡲࡦࡨࡸࡷࡪࡪࠠࡵࡱࠣࡷࡹࡧࡲࡵࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡱࡩࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ₏")+l11l11l_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ₐ")+l111llll1l_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪₑ"))
		return False
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨₒ"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠧₓ"))
	l11l1l1ll1_l1_ = DIALOG_PROGRESS()
	l11l1l1ll1_l1_.create(l111llll1l_l1_,l11lll_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫₔ"))
	l11l111lll_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111llll1l_l1_,l11lll_l1_ (u"ࠫࡼࡨࠧₕ"))
	else: file = open(l111llll1l_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪₖ")),l11lll_l1_ (u"࠭ࡷࡣࠩₗ"))
	if l111lll11l_l1_==l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ₘ"): # l11l11ll11_l1_ for l1llll1l1_l1_ and l11l11111l_l1_ chunks video files such as .l11l1l1l11_l1_
		for l11l1lllll_l1_ in range(1,l11l11l111_l1_+1):
			link = links[l11l1lllll_l1_-1]
			if not link.startswith(l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ₙ")):
				if link.startswith(l11lll_l1_ (u"ࠩ࠲࠳ࠬₚ")): link = l11l11l_l1_.split(l11lll_l1_ (u"ࠪ࠾ࠬₛ"),1)[0]+l11lll_l1_ (u"ࠫ࠿࠭ₜ")+link
				elif link.startswith(l11lll_l1_ (u"ࠬ࠵ࠧ₝")): link = SERVER(l11l11l_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ₞"))+link
				else: link = l11l11l_l1_.rsplit(l11lll_l1_ (u"ࠧ࠰ࠩ₟"),1)[0]+l11lll_l1_ (u"ࠨ࠱ࠪ₠")+link
			response = requests.request(l11lll_l1_ (u"ࠩࡊࡉ࡙࠭₡"),link,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l111llllll_l1_ = time.time()
			l111lll1ll_l1_ = l111llllll_l1_-t1
			l111lllll1_l1_ = l111lll1ll_l1_//l11l1lllll_l1_
			l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
			l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			PROGRESS_UPDATE(l11l1l1ll1_l1_,int(100*l11l1lllll_l1_//(l11l11l111_l1_+1)),l11lll_l1_ (u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ₢"),l11lll_l1_ (u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ₣"),str(l11l1lllll_l1_*chunksize//l11ll111ll_l1_)+l11lll_l1_ (u"ࠬ࠵ࠧ₤")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫ₥")+time.strftime(l11lll_l1_ (u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ₦"),time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠨࠢใࠫ₧"))
			if l11l1l1ll1_l1_.iscanceled():
				l11l111lll_l1_ = False
				break
	else: # l1111lll_l1_ and other l11l1l111l_l1_ file l11ll11l1l_l1_
		l11l1lllll_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11l1lllll_l1_ = l11l1lllll_l1_+1
			l111llllll_l1_ = time.time()
			l111lll1ll_l1_ = l111llllll_l1_-t1
			l111lllll1_l1_ = l111lll1ll_l1_/l11l1lllll_l1_
			l11l1l1111_l1_ = l111lllll1_l1_*(l11l11l111_l1_+1)
			l11l1111l1_l1_ = l11l1l1111_l1_-l111lll1ll_l1_
			PROGRESS_UPDATE(l11l1l1ll1_l1_,int(100*l11l1lllll_l1_/(l11l11l111_l1_+1)),l11lll_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ₨"),l11lll_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ₩"),str(l11l1lllll_l1_*chunksize//l11ll111ll_l1_)+l11lll_l1_ (u"ࠫ࠴࠭₪")+str(l11l1lll1l_l1_)+l11lll_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪ₫")+time.strftime(l11lll_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣ€"),time.gmtime(l11l1111l1_l1_))+l11lll_l1_ (u"ࠧࠡโࠪ₭"))
			if l11l1l1ll1_l1_.iscanceled():
				l11l111lll_l1_ = False
				break
		response.close()
	file.close()
	l11l1l1ll1_l1_.close()
	if not l11l111lll_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ₮"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤ࡛ࠥࡳࡦࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠴࡯࡮ࡵࡧࡵࡶࡺࡶࡴࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡶࡴࡩࡥࡴࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭₯")+l11l11l_l1_+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪ₰")+l111llll1l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠧ₱"))
		DIALOG_OK(l11lll_l1_ (u"ࠬ࠭₲"),l11lll_l1_ (u"࠭ࠧ₳"),l11lll_l1_ (u"ࠧࠨ₴"),l11lll_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣ฽๊๊๊สࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํ࠭₵"))
		return True
	LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ₶"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ₷")+l11l11l_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ₸")+l111llll1l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ₹"))
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧ₺"),l11lll_l1_ (u"ࠧࠨ₻"),l11lll_l1_ (u"ࠨࠩ₼"),l11lll_l1_ (u"ࠩอ้ࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢห๊ัออࠨ₽"))
	return True
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ⡧")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡅࡈࡐࡢࠫ⡨")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫ⡩"),l11lll_l1_ (u"ࠧศๆๆ่ࠬ⡪"),l11lll_l1_ (u"ࠨࡰ࠲ࡅࠬ⡫"),l11lll_l1_ (u"ࠩสุ่๊๊ะࠩ⡬"),l11lll_l1_ (u"ࠪๆฺฯฺࠠึๅࠫ⡭")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l1111l_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1llllll_l1_(url)
	elif mode==434: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⡮")+text)
	elif mode==435: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⡯")+text)
	elif mode==436: results = l1l11l_l1_(url)
	elif mode==437: results = l111111l1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⡰"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧ⡱"),l11lll_l1_ (u"ࠨࠩ⡲"),l11lll_l1_ (u"ࠩࠪ⡳"),l11lll_l1_ (u"ࠪࠫ⡴"),l11lll_l1_ (u"ࠫࠬ⡵"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⡶"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡣࡱࡳࡳ࡯ࡣࡢ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⡷"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩ⡸"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⡹"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡺"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⡻"),l11lll_l1_ (u"ࠫࠬ⡼"),439,l11lll_l1_ (u"ࠬ࠭⡽"),l11lll_l1_ (u"࠭ࠧ⡾"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⡿"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢀"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ⢁"),l1ll1l1_l1_,435)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⢂"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ⢃"),l1ll1l1_l1_,434)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⢄"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⢅"),l11lll_l1_ (u"ࠧࠨ⢆"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢇"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⢈")+l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ⢉"),l1ll1l1_l1_,431)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢊"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⢋")+l111ll_l1_+l11lll_l1_ (u"࠭วโๆส้ࠥอ่็ࠢ็ห๏์ࠧ⢌"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹ࠱ࠨ⢍"),436)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢎"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⢏")+l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤฬ๎ๆࠡๆส๎๋࠭⢐"),l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲ࡧ࡬࡭࠳ࠪ⢑"),436)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢒"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⢓")+l111ll_l1_+l11lll_l1_ (u"ࠧใษษ้ฮࠦสโืํ่๏ฯࠧ⢔"),l1ll1l1_l1_,437)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⢕"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⢖"),l11lll_l1_ (u"ࠪࠫ⢗"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢘"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⢙")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็่๎ืฯࠧ⢚"),l1ll1l1_l1_,431,l11lll_l1_ (u"ࠧࠨ⢛"),l11lll_l1_ (u"ࠨࠩ⢜"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ⢝"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⢞"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⢟")+l111ll_l1_+l11lll_l1_ (u"ࠬษแๅษ่ࠫ⢠"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠵ࠧ⢡"),436)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢢"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⢣")+l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠪ⢤"),l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱࠶࠵ࠧ⢥"),436)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠫࠧࡩࡵࡧࡑࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬ࠧ࠭⢦"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢧"),block,re.DOTALL)
	for link,title in items:
		#if title==l11lll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ⢨"): title = l11lll_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭⢩")
		if title in l1l1l1_l1_: continue
		if title==l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ⢪"): continue
		if l11lll_l1_ (u"ࠩส์๋ࠦไศ์้ࠫ⢫") in title: continue
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⢬"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⢭")+l111ll_l1_+title,link,431)
	return
def l111111l1_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭⢮")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⢯"),l1l1ll11_l1_+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹࠧ⢰"),l11lll_l1_ (u"ࠨࠩ⢱"),l11lll_l1_ (u"ࠩࠪ⢲"),l11lll_l1_ (u"ࠪࠫ⢳"),l11lll_l1_ (u"ࠫࠬ⢴"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⢵"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡣࡱࡳࡳ࡯ࡣࡢ࡮ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⢶"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠧ࠰ࠩ⢷"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⢸"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡐ࡮ࡹࡴࡅࡴࡲࡴࡪࡪࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡵࡧ࡭࡯࡮ࡨࡏࡤࡷࡹ࡫ࡲࠣࠩ⢹"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⢺"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l1l1_l1_: continue
		link = l1l1ll11_l1_+l11lll_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨ⢻")+category+l11lll_l1_ (u"ࠬࡃࠧ⢼")+value
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢽"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⢾")+l111ll_l1_+title,link,431)
	return
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⢿"),l11lll_l1_ (u"ࠩࠪ⣀"),l11lll_l1_ (u"ࠪࡗ࡚ࡈࡍࡆࡐࡘࠫ⣁"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ⣂"),link)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⣃"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⣄"),url,l11lll_l1_ (u"ࠧࠨ⣅"),l11lll_l1_ (u"ࠨࠩ⣆"),l11lll_l1_ (u"ࠩࠪ⣇"),l11lll_l1_ (u"ࠪࠫ⣈"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⣉"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣊"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾࠭⣋"),url,431)
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ⣌"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧ⣍"),block,re.DOTALL)
	for l1111l111_l1_,title in items:
		if title in l1l1l1_l1_: continue
		l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࡃࡰ࡫ࡹ࠾ࠩ⣎")+l1111l111_l1_
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣏"),l111ll_l1_+title,l11l11l_l1_,431)
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⣐"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⣑"),l11lll_l1_ (u"࠭ࠧ⣒"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡋࡱࡲࡪࡸࡐࡢࡩࡨࡊ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠧ⣓"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡴࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ⣔"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l1l1_l1_: continue
	#	if l11lll_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴ࠱ࠪ⣕") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡑࡴࡼࡩࡦࡵ࠲ࡘࡪࡸ࡭ࡴ࠰ࡳ࡬ࡵࡅࠧ⣖")+category+l11lll_l1_ (u"ࠫࡂ࠭⣗")+value
	#	elif l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠳ࠧ⣘") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡦࡴ࡬ࡩࡸ࠵ࡇࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨ⣙")+category+l11lll_l1_ (u"ࠧ࠾ࠩ⣚")+value
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣛"),l111ll_l1_+title,l11l11l_l1_,431)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪ⣜")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⣝"),l11lll_l1_ (u"ࠫࠬ⣞"),request,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⣟"))
	items = []
	if l11lll_l1_ (u"࠭࠯ࡕࡧࡵࡱࡸ࠴ࡰࡩࡲࠪ⣠") in url or l11lll_l1_ (u"ࠧ࠰ࡉࡨࡸ࠳ࡶࡨࡱࠩ⣡") in url or l11lll_l1_ (u"ࠨ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࠫ⣢") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ⣣"):l11lll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ⣤"),l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ⣥"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ⣦")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ⣧"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠧࠨ⣨"),l11lll_l1_ (u"ࠨࠩ⣩"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭⣪"))
		html = response.content
		block = html
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⣫"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⣬"),url,l11lll_l1_ (u"ࠬ࠭⣭"),l11lll_l1_ (u"࠭ࠧ⣮"),l11lll_l1_ (u"ࠧࠨ⣯"),l11lll_l1_ (u"ࠨࠩ⣰"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⣱"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡎࡣࡷࡧ࡭࡫ࡳࡕࡣࡥࡰࡪࠨࠧ⣲"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ⣳"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⣴"),url,l11lll_l1_ (u"࠭ࠧ⣵"),l11lll_l1_ (u"ࠧࠨ⣶"),l11lll_l1_ (u"ࠨࠩ⣷"),l11lll_l1_ (u"ࠩࠪ⣸"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⣹"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠫ⣺"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬ⣻"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⣼"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ⣽"),l11lll_l1_ (u"ࠨใํ่๊࠭⣾"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ⣿"),l11lll_l1_ (u"ࠪ็้๐ศࠨ⤀"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ⤁"),l11lll_l1_ (u"ࠬํฯศใࠪ⤂"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭⤃"),l11lll_l1_ (u"ฺࠧำูࠫ⤄"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ⤅"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ⤆")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ⤇"))
		#link = unescapeHTML(link)
		title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭⤈"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ⤉"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⤊"),l111ll_l1_+title,link,432,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠧศๆะ่็ฯࠧ⤋") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ⤌") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⤍"),l111ll_l1_+title,link,433,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ⤎") in link:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⤏"),l111ll_l1_+title,link,431,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤐"),l111ll_l1_+title,link,433,l1llll_l1_)
	if request!=l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⤑"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⤒"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⤓"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⤔") not in link: link = l1ll1l1_l1_+link
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠪࠫ⤕"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⤖"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ⤗")+title,link,431)
		l11111l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⤘"),html,re.DOTALL)
		if l11111l11_l1_:
			link = l11111l11_l1_[0]
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤙"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ⤚"),link,431)
	return
def l1llllll_l1_(url):
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ⤛"),l11lll_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪ⤜")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ⤝"))
	l1l1l11_l1_,l1l11ll_l1_ = [],[]
	if l11lll_l1_ (u"ࠬࡋࡰࡪࡵࡲࡨࡪࡹ࠮ࡱࡪࡳࠫ⤞") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ⤟"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ⤠"),l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⤡"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ⤢")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⤣"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ⤤"),l11lll_l1_ (u"ࠬ࠭⤥"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ⤦"))
		html = response.content
		l1l11ll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⤧"),url,l11lll_l1_ (u"ࠨࠩ⤨"),l11lll_l1_ (u"ࠩࠪ⤩"),l11lll_l1_ (u"ࠪࠫ⤪"),l11lll_l1_ (u"ࠫࠬ⤫"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ⤬"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⤭"),html,re.DOTALL)
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡇࡳ࡭ࡸࡵࡤࡦࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⤮"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡲ࡫࠿࡯࡭ࡢࡩࡨࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⤯"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡫ࡡࡴࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⤰"),block,re.DOTALL)
		for post,l1ll1l1llll_l1_,title in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡉࡵ࡯ࡳࡰࡦࡨࡷ࠳ࡶࡨࡱࡁࠪ⤱")+l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡁࠬ⤲")+l1ll1l1llll_l1_+l11lll_l1_ (u"ࠬࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ⤳")+post
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤴"),l111ll_l1_+title,link,433,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨ⤵"))
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ⤶"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠩࠣࠫ⤷")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⤸"),l111ll_l1_+title,link,432,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ⤹")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⤺"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ⤻"),l11lll_l1_ (u"ࠧࠨ⤼"),l11lll_l1_ (u"ࠨࠩ⤽"),l11lll_l1_ (u"ࠩࠪ⤾"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⤿"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ⥀"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠯ࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⥁"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⥂"),block,re.DOTALL)
		if l1ll1llll1_l1_:
			l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⥃"),l11lll_l1_ (u"ࠨࠩ⥄"),l11lll_l1_ (u"ࠩࠪ⥅"),l1ll1llll1_l1_)
			items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⥆"),block,re.DOTALL)
			for server,title in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩ⥇")+server+l11lll_l1_ (u"ࠬࠬࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ⥈")+l1ll1llll1_l1_+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⥉")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⥊")
				l1111_l1_.append(link)
	# l1l11llll_l1_ link
	l1l11llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡯ࡦࡳࡣࡰࡩࠧࡄ࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⥋"),html,re.DOTALL)
	if l1l11llll_l1_:
		l1l11llll_l1_ = l1l11llll_l1_[0].replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ⥌"),l11lll_l1_ (u"ࠪࠫ⥍"))
		title = SERVER(l1l11llll_l1_,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ⥎"))
		link = l1l11llll_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⥏")+title+l11lll_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪࠧ⥐")
		l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⥑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬ⥒"),block,re.DOTALL)
		for link,title,l11l111l_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ⥓"),l11lll_l1_ (u"ࠪࠫ⥔"))
			if l11l111l_l1_!=l11lll_l1_ (u"ࠫࠬ⥕"): l11l111l_l1_ = l11lll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ⥖")+l11l111l_l1_
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⥗")+title+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⥘")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⥙"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⥚"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ⥛"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ⥜"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ⥝"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ⥞"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⥟")+search
	l1111l_l1_(url)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⥠"))[0]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭⥡"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⥢"),l1ll1l1_l1_,l11lll_l1_ (u"ࠫࠬ⥣"),l11lll_l1_ (u"ࠬ࠭⥤"),l11lll_l1_ (u"࠭ࠧ⥥"),l11lll_l1_ (u"ࠧࠨ⥦"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ⥧"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫࡭ࡳ࡭ࡍࡢࡵࡷࡩࡷࠨࠧ⥨"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭ࠬ⥩"),block,re.DOTALL)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࡟ࡨ࠰࠯ࠢࠡࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⥪"),block,re.DOTALL)
	return items
def l111111ll_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠬࡩࡡࡵ࠿ࠪ⥫"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ⥬"))
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⥭"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⥮"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⥯"),l11lll_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧ⥰"))
	return url
def l1ll1ll1111_l1_(l1l1llll_l1_,url):
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⥱")) # l1llllll1l1_l1_ be l1llllllll1_l1_
	l11l1l1_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⥲")+l1l1111l_l1_
	l11l1l1_l1_ = l111111ll_l1_(l11l1l1_l1_)
	return l11l1l1_l1_
l1l11lll_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⥳"),l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ⥴"),l11lll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ⥵"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ⥶")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ⥷"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ⥸"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ⥹"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⥺"),l11lll_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ⥻"),l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ⥼")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⥽"),l11lll_l1_ (u"ࠪࠫ⥾"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⥿"),l11lll_l1_ (u"ࠬ࠭⦀"),filter,url)
	if l11lll_l1_ (u"࠭࠿ࠨ⦁") in url: url = url.split(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⦂"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬ⦃"),1)
	if filter==l11lll_l1_ (u"ࠩࠪ⦄"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠪࠫ⦅"),l11lll_l1_ (u"ࠫࠬ⦆")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⦇"))
	if type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⦈"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠧ࠾ࠩ⦉") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠨ࠿ࠪ⦊") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⦋")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭⦌")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭⦍")+category+l11lll_l1_ (u"ࠬࡃ࠰ࠨ⦎")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨ⦏"))+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⦐")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪ⦑"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⦒")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⦓")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧ⦔"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⦕")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"࠭ࠧ⦖"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⦗")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		if l1l11l11_l1_==l11lll_l1_ (u"ࠨࠩ⦘"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⦙")+l1l11l11_l1_
		l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦚"),l111ll_l1_+l11lll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ⦛"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦜"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭⦝")+l11lll11_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭⦞"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⦟"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⦠"),l11lll_l1_ (u"ࠪࠫ⦡"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠫ࠲࠳ࠧ⦢"),l11lll_l1_ (u"ࠬ࠭⦣"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"࠭࠽ࠨ⦤") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⦥"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l111111ll_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⦦")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⦧"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ⦨"),l11l11l_l1_,431)
				else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦩"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭⦪"),l11l11l_l1_,435,l11lll_l1_ (u"࠭ࠧ⦫"),l11lll_l1_ (u"ࠧࠨ⦬"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ⦭"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⦮")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁ࠵࠭⦯")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭⦰")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠰ࠨ⦱")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⦲")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦳"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪ⦴")+name,l11l11l_l1_,434,l11lll_l1_ (u"ࠩࠪ⦵"),l11lll_l1_ (u"ࠪࠫ⦶"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭⦷"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬ⦸"): option = l11lll_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭⦹")
			elif value==l11lll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧ⦺"): option = l11lll_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪ⦻")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ⦼") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫ⦽"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭⦾")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃࠧ⦿")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨ⧀")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ⧁")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ⧂")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠩࠣ࠾ࠬ⧃")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠪ࠴ࠬ⧄")]
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧ⧅")+name
			if type==l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⧆"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧇"),l111ll_l1_+title,url,434,l11lll_l1_ (u"ࠧࠨ⧈"),l11lll_l1_ (u"ࠨࠩ⧉"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⧊"))
			elif type==l11lll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⧋") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠫࡂ࠭⧌") in l1l11l1l_l1_:
				l11l1l1_l1_ = l1ll1ll1111_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⧍"),l111ll_l1_+title,l11l1l1_l1_,431)
			else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧎"),l111ll_l1_+title,url,435,l11lll_l1_ (u"ࠧࠨ⧏"),l11lll_l1_ (u"ࠨࠩ⧐"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⧑"),l11lll_l1_ (u"ࠪࠫ⧒"),filters,l11lll_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬ⧓"))
	# mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⧔")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⧕")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠧࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⧖")			all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠨ࠿ࠩࠫ⧗"),l11lll_l1_ (u"ࠩࡀ࠴ࠫ࠭⧘"))
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠬ⧙"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠫࡂ࠭⧚") in filters:
		items = filters.split(l11lll_l1_ (u"ࠬࠬࠧ⧛"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"࠭࠽ࠨ⧜"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠧࠨ⧝")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪ⧞")
		if l11lll_l1_ (u"ࠩࠨࠫ⧟") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ⧠") and value!=l11lll_l1_ (u"ࠫ࠵࠭⧡"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩ⧢")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⧣") and value!=l11lll_l1_ (u"ࠧ࠱ࠩ⧤"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⧥")+key+l11lll_l1_ (u"ࠩࡀࠫ⧦")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⧧"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭⧨")+key+l11lll_l1_ (u"ࠬࡃࠧ⧩")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪ⧪"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⧫"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠨ࠿࠳ࠫ⧬"),l11lll_l1_ (u"ࠩࡀࠫ⧭"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⧮"),l11lll_l1_ (u"ࠫࠬ⧯"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭⧰"))
	return l1ll1l1l_l1_
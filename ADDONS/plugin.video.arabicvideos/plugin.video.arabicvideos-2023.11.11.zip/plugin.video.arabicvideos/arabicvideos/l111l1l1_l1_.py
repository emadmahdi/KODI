# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠵ࡶࡪࡧࡺ࠱࠶࠵วโๆส้࠲฿ัษ์ฬࠫ౧")
#l11ll1_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬ౨")
#l11ll1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷ࠳࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ౩")
#l11ll1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࠫ౪")
script_name = l11lll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ౫")
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭౬"):l11lll_l1_ (u"ࠪࠫ౭")}
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡑࡌࡂࡡࠪ౮")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==10: results = MENU()
	elif mode==11: results = l1111l_l1_(url)
	elif mode==12: results = PLAY(url)
	elif mode==13: results = l1llllll_l1_(url)
	elif mode==14: results = l1lllll1l_l1_()
	elif mode==15: results = l111111l_l1_()
	elif mode==16: results = l111l111_l1_()
	elif mode==19: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ౯"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭౰"),l11lll_l1_ (u"ࠧࠨ౱"),19,l11lll_l1_ (u"ࠨࠩ౲"),l11lll_l1_ (u"ࠩࠪ౳"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ౴"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ౵"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ౶"),l11lll_l1_ (u"࠭ࠧ౷"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౸"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ౹")+l111ll_l1_+l11lll_l1_ (u"ࠩลาึࠦวๅวูหๆอสࠨ౺"),l11lll_l1_ (u"ࠪࠫ౻"),14)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ౼"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ౽")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋࠭౾"),l11lll_l1_ (u"ࠧࠨ౿"),15)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠨࠩಀ"),headers,l11lll_l1_ (u"ࠩࠪಁ"),l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬಂ"))
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡰࡤࡺ࠲ࡹ࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪಃ"),html,re.DOTALL)
	l111lll1_l1_ = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ಄"),l111lll1_l1_,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨಅ"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಆ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪಇ")+l111ll_l1_+title,link,11)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧಈ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪಉ"),l11lll_l1_ (u"ࠫࠬಊ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡱࡥࡻࡨࡡࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧಋ"),html,re.DOTALL)
	l11l1_l1_ = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨಌ"),l11l1_l1_,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ಍"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪಎ")+l111ll_l1_+title,link,11)
	return html
def l111111l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಏ"),l111ll_l1_+l11lll_l1_ (u"ࠪะ๊๐ูࠡษ็ุ้๊ำๅษอࠤฬู๊าสํอࠬಐ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡼࡩࡦࡹ࠰࠼࠴๋ำๅี็หฯ࠳ูาสํอࠬ಑"),11)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಒ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠศๆึ๊ฮࠦวๅลั๎ึฯࠧಓ"),l11lll_l1_ (u"ࠧࠨಔ"),16)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಕ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢส่ศิ๊าหࠣ࠵ࠬಖ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡥࡸ࠯࠻࠳ู๊ไิๆสฮ࠲ืๅืษ้࠱࠷࠶࠲࠳ࠩಗ"),11)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫಘ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥอไฤะํีฮࠦ࠲ࠨಙ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠲࠾࠯ๆี็ื้อส࠮ำฺ่ฬ์࠭࠳࠲࠵࠷ࠬಚ"),11)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಛ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠶࠸࠭ಜ"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠸࠳࠰็ุี๏ฯࠧಝ"),11)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಞ"),l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠲࠳ࠩಟ"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠴࠵࠳๊฻ั๋หࠪಠ"),11)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಡ"),l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠵࠵ࠬಢ"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠷࠷࠯ๆืิ๎ฮ࠭ಣ"),11)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩತ"),l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠰ࠨಥ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠳࠲࠲ฺ้ื๊สࠩದ"),11)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಧ"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠳࠼ࠫನ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠵࠾࠵ๅึำํอࠬ಩"),11)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಪ"),l111ll_l1_+l11lll_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠶࠾ࠧಫ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠱࠹࠱ู่ึ๐ษࠨಬ"),11)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫಭ"),l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠲࠹ࠪಮ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠴࠻࠴๋ีา์ฬࠫಯ"),11)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧರ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠻࠭ಱ"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠶࠰็ุี๏ฯࠧಲ"),11)
	return
def l1lllll1l_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11ll1_l1_,l11lll_l1_ (u"ࠪࠫಳ"),headers,True,l11lll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ಴"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ವ"),l11lll_l1_ (u"࠭ࠧಶ"),l11lll_l1_ (u"ࠧࠨಷ"),html)
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨࡪࡨࡥࡩ࡯࡮ࡨ࠯ࡷࡳࡵ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠧಸ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]+l1l1ll1_l1_[1]
	items=re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫಹ"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		url = l11ll1_l1_ + link
		if l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ಺") in url: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ಻"),l111ll_l1_+title,url,11,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲ಼ࠫ"),l111ll_l1_+title,url,12,l1llll_l1_)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧಽ"),l11lll_l1_ (u"ࠧࠨಾ"),l11lll_l1_ (u"ࠨࡖࡌࡘࡑࡋࡓࠨಿ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ೀ"),url,l11lll_l1_ (u"ࠪࠫು"),headers,True,True,l11lll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨೂ"))
	html = response.content
	#open(l11lll_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴ࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧೃ"),l11lll_l1_ (u"࠭ࡷࠨೄ")).write(str(html))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹࠩ࠰࠭ࡃ࠮ࡸࡩࡨࡪࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠬ೅"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1ll1ll1l_l1_ = False
	#items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࡜࠷࠵ࡡ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ೆ"),block,re.DOTALL)
	items = re.findall(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡤࡲࡼ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨೇ"),block,re.DOTALL)
	l1l1_l1_,l111l11l_l1_ = [],[]
	for link,l1llll_l1_,title in items:
		if title==l11lll_l1_ (u"ࠪࠫೈ"): title = link.split(l11lll_l1_ (u"ࠫ࠴࠭೉"))[-1].replace(l11lll_l1_ (u"ࠬ࠳ࠧೊ"),l11lll_l1_ (u"࠭ࠠࠨೋ"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࡞ࡧ࠯࠮࠭ೌ"),title,re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = int(l111ll1l_l1_[0])
		else: l111ll1l_l1_ = 0
		l111l11l_l1_.append([l1llll_l1_,link,title,l111ll1l_l1_])
	l111l11l_l1_ = sorted(l111l11l_l1_, reverse=True, key=lambda key: key[3])
	#DIALOG_OK(l11lll_l1_ (u"ࠨ್ࠩ"),l11lll_l1_ (u"ࠩࠪ೎"),l11lll_l1_ (u"ࠪ࠶࠷࠸ࠧ೏"),url)
	for l1llll_l1_,link,title,l111ll1l_l1_ in l111l11l_l1_:
		link = l11ll1_l1_ + link
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ೐"),l11lll_l1_ (u"ࠬ࠭೑"),url,title)
		title = title.replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦๅิๆึ่ࠬ೒"),l11lll_l1_ (u"ࠧๆี็ื้࠭೓"))
		title = title.replace(l11lll_l1_ (u"ࠨ็ืห์ีษࠡษ็ุ้๊ำๅࠩ೔"),l11lll_l1_ (u"ࠩสู่๊ไิๆࠪೕ"))
		title = title.replace(l11lll_l1_ (u"ู้ࠪอ็ะหࠣๅ๏๊ๅࠨೖ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ೗"))
		title = title.replace(l11lll_l1_ (u"๋ࠬิศ้าอࠥอไโ์็้ࠬ೘"),l11lll_l1_ (u"࠭วๅใํ่๊࠭೙"))
		title = title.replace(l11lll_l1_ (u"ࠧๆสสุึฯࠠไ๊ส่๏ะ๊ࠨ೚"),l11lll_l1_ (u"ࠨࠩ೛"))
		title = title.replace(l11lll_l1_ (u"ࠩ฼ห้๐ษࠡ฻็ํࠥอไฺำหࠫ೜"),l11lll_l1_ (u"ࠪࠫೝ"))
		title = title.replace(l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠤ๊ฮวีำฬࠫೞ"),l11lll_l1_ (u"ࠬ࠭೟"))
		title = title.replace(l11lll_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠨೠ"),l11lll_l1_ (u"ࠧࠨೡ"))
		title = title.replace(l11lll_l1_ (u"ࠨษ๋๊้อ๊็ࠩೢ"),l11lll_l1_ (u"ࠩࠪೣ"))
		title = title.replace(l11lll_l1_ (u"ࠪฬั๎ฯสࠢ฼ห้๐ษࠨ೤"),l11lll_l1_ (u"ࠫࠬ೥"))
		title = title.replace(l11lll_l1_ (u"ࠬา่ะหࠣ฽ฬ๊๊สࠩ೦"),l11lll_l1_ (u"࠭ࠧ೧"))
		title = title.replace(l11lll_l1_ (u"ࠧษั๋๊ࠥะอๆ์็ࠫ೨"),l11lll_l1_ (u"ࠨࠩ೩"))
		title = title.replace(l11lll_l1_ (u"ࠩ฼่๎ࠦวๅ฻ิฬࠬ೪"),l11lll_l1_ (u"ࠪࠫ೫"))
		title = title.replace(l11lll_l1_ (u"๊ࠫฮวีำฬࠫ೬"),l11lll_l1_ (u"ࠬ࠭೭"))
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ೮")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ೯"),l11lll_l1_ (u"ࠨࠢࠪ೰")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬೱ"),l11lll_l1_ (u"ࠪࠤࠬೲ"))
		title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪೳ")+title
		l1lll1lll_l1_ = title
		if l11lll_l1_ (u"ࠬ࠵ࡱ࠰ࠩ೴") in url and (l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭೵") in title or l11lll_l1_ (u"ࠧศๆะ่็ํࠧ೶") in title):
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ೷"),title,re.DOTALL)
			if l1lll11_l1_: l1lll1lll_l1_ = l1lll11_l1_[0]
			#if l11lll_l1_ (u"่ࠩืู้ไࠨ೸") not in l1lll1lll_l1_: l1lll1lll_l1_ = l11lll_l1_ (u"ุ้๊ࠪำๅࠢࠪ೹")+l1lll1lll_l1_
		if l1lll1lll_l1_ not in l1l1_l1_:
			l1l1_l1_.append(l1lll1lll_l1_)
			#xbmc.log(l1lll1lll_l1_, level=xbmc.LOGNOTICE)
			if l11lll_l1_ (u"ࠫ࠴ࡷ࠯ࠨ೺") in url and (l11lll_l1_ (u"ࠬอไฮๆๅอࠬ೻") in title or l11lll_l1_ (u"࠭วๅฯ็ๆ์࠭೼") in title):
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ೽"),l111ll_l1_+l1lll1lll_l1_,link,13,l1llll_l1_)
				l1ll1ll1l_l1_ = True
			elif l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ೾") in link:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೿"),l111ll_l1_+title,link,11,l1llll_l1_)
				l1ll1ll1l_l1_ = True
			else:
				#if l11lll_l1_ (u"ุ้๊ࠪำๅࠩഀ") not in title and l11lll_l1_ (u"ࠫฬ๊อๅไฬࠫഁ") in title: title = l11lll_l1_ (u"๋ࠬำๅี็ࠤࠬം")+title
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬഃ"),l111ll_l1_+title,link,12,l1llll_l1_)
				l1ll1ll1l_l1_ = True
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨഄ"),l11lll_l1_ (u"ࠨࠩഅ"),l11lll_l1_ (u"ࠩ࠶࠷࠸࠭ആ"),url)
	if l1ll1ll1l_l1_:
		items = re.findall(l11lll_l1_ (u"ࠪࡸࡸࡩ࡟࠴ࡦࡢࡦࡺࡺࡴࡰࡰࠣࡶࡪࡪ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨഇ"),block,re.DOTALL)
		for link,l1l11l1_l1_ in items:
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഈ"),l111ll_l1_+l1l11l1_l1_,url,11)
	return
def l1llllll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭ഉ"),headers,True,l11lll_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬഊ"))
	l111ll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠰ࡵࡨࡶ࡮࡫ࡳ࠯ࠬࡂ࠭ࠧ࠭ഋ"),html,re.DOTALL)
	l11l11l_l1_ = l11ll1_l1_+l111ll11_l1_[0]
	results = l1111l_l1_(l11l11l_l1_)
	return
l11lll_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡇࡓࡍࡘࡕࡄࡆࡕࡢࡓࡑࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡅࡗࡇࡂ࠮ࡇࡓࡍࡘࡕࡄࡆࡕࡢࡓࡑࡊ࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡨࡡ࡯ࡰࡨࡶ࠲ࡸࡩࡨࡪࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹࡩࡤ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡷࡲࠬࠨࡵࡷࡩࡵࠦ࠲ࠨࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠹ࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠯ࠤࡷ࡫ࡶࡦࡴࡶࡩࡂ࡚ࡲࡶࡧ࠯ࠤࡰ࡫ࡹ࠾࡮ࡤࡱࡧࡪࡡࠡ࡭ࡨࡽ࠿ࠦ࡫ࡦࡻ࡞࠵ࡢ࠯ࠊࠊࠥࡱࡥࡲ࡫ࠠ࠾ࠢࡻࡦࡲࡩ࠮ࡨࡧࡷࡍࡳ࡬࡯ࡍࡣࡥࡩࡱ࠮ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡹࡴࡦࡲࠣ࠸ࠬ࠯ࠊࠊࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶࠤࡂ࡛ࠦ࡞ࠌࠌࡪࡴࡸࠠࡪ࡯ࡪ࠰ࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࠡࡰࡲࡸࠥ࡯࡮ࠡࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠾ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯࡚ࡔࡑࡖࡑࡗࡉ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡶࡪࡦࡨࡳࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦุ้๊࠭ࠪำๅࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠳࠵࠰࡮ࡳࡧࠪࠌࠌࠍࠎࡧ࡬࡭ࡖ࡬ࡸࡱ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡷࡹ࡫ࡰࠡ࠷ࠪ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤഌ")
def PLAY(url):
	l1111_l1_ = []
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ഍"),headers,True,l11lll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬഎ"))
	# l1llll1l1_l1_ l1lll1ll1_l1_ server
	# https://l111llll_l1_.l1llll111_l1_.com/l1lll1l11_l1_-_حلقة_1ll1lll1_l1_حكايتي_11111l1_l1_رمضان_1111l1l_l1_
	# https://l111l1ll_l1_.l1llll111_l1_.com/numeric/110272.l1111lll_l1_/l1111l11_l1_.l1llll1l1_l1_
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫ࡳࡱ࠯࡬ࡪࡷࡧ࡭ࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨഏ"),html,re.DOTALL)
	if l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠬࡤࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠨࠬഐ"),l11l11l_l1_,re.DOTALL)
		if links:
			first = links[0][0]
			second,l1lll111l_l1_ = links[0][1].rsplit(l11lll_l1_ (u"࠭࠯ࠨ഑"),1)
			l11l1l1_l1_ = second+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨഒ")
			l1111_l1_.append(l11l1l1_l1_)
			l1111111_l1_ = first+l1lll111l_l1_
		else:
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩഓ"),headers,False,l11lll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫഔ"))
			l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸࡸࡣࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫക"),l11lll1l_l1_,re.DOTALL)
			if l11l11l_l1_:
				l11l11l_l1_ = l11l11l_l1_[0]+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭࠴ࡷ࠻ࠫഖ")
				l1111_l1_.append(l11l11l_l1_)
	# l1ll1ll11_l1_ server - l11111ll_l1_ - https://l111llll_l1_.l1llll111_l1_.com/l1lll1l1l_l1_-_الذئب_حلقة_1lll11ll_l1_
	# l1ll1ll11_l1_ server - l1ll1llll_l1_ - https://l111llll_l1_.l1llll111_l1_.com/l1111ll1_l1_-_1lll11l1_l1_فيلم_اكشن_1llllll1_l1_
	# l1ll1ll11_l1_ server - l1lllll11_l1_ - https://l111llll_l1_.l1llll111_l1_.com/l1llll1ll_l1_-_لحلقة_1lllllll_l1_السجين_مترجمة_1llll11l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡇࡵࡸࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭ഗ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬഘ"),block,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨങ")
			l1111_l1_.append(l11l11l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠧച"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨഛ"),url)
	return
def l111l111_l1_():
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠪࠫജ"),headers,True,l11lll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡗࡇࡍࡂࡆࡄࡒ࠲࠷ࡳࡵࠩഝ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࡢࡷࡪࡩࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤ࡯ࡩ࡫ࡺ࡟ࡤࡱࡱࡸࡪࡴࡴࠣࠩഞ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨട"),block,re.DOTALL)
	year = re.findall(l11lll_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯ࠪ࡞࠴࠲࠿࡝ࠬࠫ࠲ࠫഠ"),str(items),re.DOTALL)
	year = year[0]
	for link,title in items:
		url = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"ࠨࠢࠪഡ"))+l11lll_l1_ (u"ࠩࠣࠫഢ")+year
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪണ"),l111ll_l1_+title,url,11)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬത"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭ഥ"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"࠭ࠠࠨദ"),l11lll_l1_ (u"ࠧࠬࠩധ"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠣ࠱ࡴ࠳ࠧന") + l111l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪഩ"),l11lll_l1_ (u"ࠪࠫപ"),l11lll_l1_ (u"ࠫ࠸࠹࠳ࠨഫ"),url)
	results = l1111l_l1_(url)
	return
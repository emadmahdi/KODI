# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ樢")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ樣")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠬ࠭樤")
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ樥"):l11lll_l1_ (u"ࠧࠨ樦")}
l1ll1lllll1l1_l1_ = 0
def MAIN(mode,url,text,type,l1l11l1_l1_,name,l11l_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1ll1lllll111_l1_(url,name,l11l_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1111l_l1_(url,l1l11l1_l1_,text)
	elif mode==145: results = l1lll11l1111l_l1_(url,l1l11l1_l1_)
	elif mode==147: results = l1lll1111ll1l_l1_()
	elif mode==148: results = l1lll1111llll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樧"),l111ll_l1_+l11lll_l1_ (u"ࠩๅหห๋ษࠨ樨"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࡕࡒࡁ࡫࠷ࡊࡷ࠽ࡌࡈ࠹࡜ࡱ࡙ࡧࡌ࠰ࡓࡘ࠰࠻ࡌ࠹ࡂࡰࡳࡌࡽ࡟ࡇ࠴ࡶࡕࡄࠫ権"),144)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ横"),l111ll_l1_+l11lll_l1_ (u"ฺࠬฮึࠩ樫"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࡚ࡃࡏࡱࡩࡪ࡮ࡩࡩࡢ࡮ࠪ樬"),144)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ樭"),l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ๆ฾࠭樮"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳࡚ࡉࡱ࠶࠻ࡤࡋࡓࡹࡱ࠺ࡤࡥ࡬ࡼ࡜ࡔࡲ࠳ࡘࡸࡻ࡭ࡷࠨ樯"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樰"),l111ll_l1_+l11lll_l1_ (u"ࠫาูวษࠩ樱"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡀࡕࡪࡨࡗࡴࡩࡩࡢ࡮ࡆࡘ࡛࠭樲"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭樳"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆ฼หอ࠭樴"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ樵"),144)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ樶"),l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠩ樷"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ樸"),144)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ樹"),l111ll_l1_+l11lll_l1_ (u"࠭ๅฯฬสีฬะࠧ樺"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭樻"),144)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ樼"),l111ll_l1_+l11lll_l1_ (u"ࠩๅู๏ืษࠨ樽"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ樾"),144,l11lll_l1_ (u"ࠫࠬ樿"),l11lll_l1_ (u"ࠬ࠭橀"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ橁"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ橂"),l111ll_l1_+l11lll_l1_ (u"ࠨฬุๅา࠭橃"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ橄"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ橅"),l111ll_l1_+l11lll_l1_ (u"ࠫึฬ๊ิ์ฬࠫ橆"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠭橇"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭橈"),l111ll_l1_+l11lll_l1_ (u"ࠧาษษะࠬ橉"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࡁࡥࡴࡂ࠭橊"),144)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ橋"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ橌"),l11lll_l1_ (u"ࠫࠬ橍"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ橎"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭橏"),l11lll_l1_ (u"ࠧࠨ橐"),149,l11lll_l1_ (u"ࠨࠩ橑"),l11lll_l1_ (u"ࠩࠪ橒"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ橓"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ橔"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ橕"),l11lll_l1_ (u"࠭ࠧ橖"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ橗"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ีห๐ำ๋หࠪ橘"),l11ll1_l1_+l11lll_l1_ (u"ࠩࠪ橙"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ橚"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ัศศฯอࠬ橛"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭橜"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭橝"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆอูๆำࠧ橞"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ機"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ橠"),l111ll_l1_+l11lll_l1_ (u"ࠪห้่ี๋ำฬࠫ橡"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ橢"),144,l11lll_l1_ (u"ࠬ࠭橣"),l11lll_l1_ (u"࠭ࠧ橤"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ橥"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ橦"),l111ll_l1_+l11lll_l1_ (u"่ࠩาฯอัศฬࠣ๎ํะ๊้สࠪ橧"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ橨"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ橩"),l111ll_l1_+l11lll_l1_ (u"๋ࠬฮหษิหฯࠦวๅสิ๊ฬ๋ฬࠨ橪"),l11lll_l1_ (u"࠭ࠧ橫"),290)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ橬"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ橭"),l11lll_l1_ (u"ࠩࠪ橮"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ橯"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ橰"),l11lll_l1_ (u"ࠬ࠭橱"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭橲"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ橳"),l11lll_l1_ (u"ࠨࠩ橴"),148)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ橵"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬฺ๋ࠠำห๎ฮ࠭橶"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ็๊ๅ็ࠪ橷"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ橸"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤฬ็ไศ็ࠣหั์ศ๋หࠪ橹"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾࡯ࡲࡺ࡮࡫ࠧ橺"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ橻"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠๆีิั๏อสࠡ฻ิฬ๏ฯࠧ橼"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ัฮ์ฬࠫ橽"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ橾"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ橿"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ檀"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ檁"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏ฯࠧ檂"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡷࡪࡸࡩࡦࡵࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ檃"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ檄"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ檅"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ檆"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檇"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ檈"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ檉"),144)
	return
def l1ll1lllll111_l1_(url,name,l11l_l1_):
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ檊"),l111ll_l1_+l11lll_l1_ (u"ࠪࡇࡍࡔࡌ࠻ࠢࠣࠫ檋")+name,url,144,l11l_l1_)
	return
def l1lll1111ll1l_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮ฬะࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ檌"))
	return
def l1lll1111llll_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࡴࡷࠨࡶࡴࡂࡋࡧࡋࡃࡄࡕࡂࡃࠧ檍"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ檎"),l11lll_l1_ (u"ࠧࠨ檏"),l11lll_l1_ (u"ࠨࠩ檐"),url)
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ檑")
	#items = re.findall(l11lll_l1_ (u"ࠪࡺࡂ࠮࠮ࠫࡁࠬࠨࠬ檒"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ檓")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ檔"))
	#return
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩࠍࠍࡪࡸࡲࡰࡴࡶ࠰ࡹ࡯ࡴ࡭ࡧࡶ࠰ࡱ࡯࡮࡬ࡵࠣࡁࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠯ࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠨࡶࡴ࡯࠭ࠏࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪ࡯࡭ࡳࡱࡳ࡜࠲ࡠ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠮ࡷࡽࡵ࡫ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠌࠦࠧࠨ檕")
	url = url.split(l11lll_l1_ (u"ࠧࠧࠩ檖"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1lll11111l1l_l1_(cc,url,index):
	level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ檗"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ檘"),l11lll_l1_ (u"ࠪࠫ檙"),index,l11lll_l1_ (u"ࠫࡋࡏࡒࡔࡖࠪ檚")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ檛")+url)
	l1ll1llll1l1l_l1_,l1ll1llll1lll_l1_ = [],[]
	# l11ll1lll1l_l1_ l11l1l11lll1_l1_    should be the first item in the l1ll1llll1l1l_l1_ list
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ檜") in url: l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡃࡦࡸ࡮ࡵ࡮ࡴࠩࡠࠦ檝"))
	# l11ll1lll1l_l1_ search l1lll11l11l11_l1_      should be the first item in the l1ll1llll1l1l_l1_ list
	if l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ檞") in url: l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡇࡴࡳ࡭ࡢࡰࡧࡷࠬࡣࠢ檟"))
	# main l1l11l1_l1_
	if level==l11lll_l1_ (u"ࠪ࠵ࠬ檠"): l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ檡"))
	# search results
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ檢"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣࠢ檣"))
	# l1lll111l111l_l1_ l1lll1111ll11_l1_ & main l1l11l1_l1_ l1lll1111ll11_l1_ l1lll11l11l11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬࡣࠢ檤"))
	# l1lll11111ll1_l1_ menu
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࡡ࠳࡞࡝ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ檥"))
	l1lll111l11ll_l1_,dd,l1ll1lll1llll_l1_ = l1ll1llll11ll_l1_(cc,l11lll_l1_ (u"ࠩࠪ檦"),l1ll1llll1l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ檧"),str(dd))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ檨"),l11lll_l1_ (u"ࠬ࠭檩"),l11lll_l1_ (u"࠭ࠧ檪"),str(len(dd)))
	if level==l11lll_l1_ (u"ࠧ࠲ࠩ檫") and l1lll111l11ll_l1_:
		if len(dd)>1 and l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ檬") not in url:
			for zz in range(len(dd)):
				l1ll1lllllll1_l1_ = str(zz)
				l1ll1llll1l1l_l1_ = []
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠࠨ檭")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡦ࡮ࡲࡥࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ檮"))
				# l1lll111l111l_l1_ l1lll1111ll11_l1_
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛ࠣ檯")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠧࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࠩࡠࠦ檰"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ檱")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠢ࡞ࠤ檲"))
				succeeded,item,l111ll1l_l1_ = l1ll1llll11ll_l1_(dd,l11lll_l1_ (u"ࠨࠩ檳"),l1ll1llll1l1l_l1_)
				if succeeded: l1ll1llll1lll_l1_.append([item,url,l11lll_l1_ (u"ࠩ࠵࠾࠿࠭檴")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠪ࠾࠿࠶࠺࠻࠲ࠪ檵")])
				#l1l11lll1l1l_l1_ = l1lll111lll11_l1_(item,url,l11lll_l1_ (u"ࠫ࠷ࡀ࠺ࠨ檶")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ檷"))
				#if l1l11lll1l1l_l1_: l1ll11l1l1_l1_ += 1
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token = l1lll11l11l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭檸"),l111ll_l1_+title,link,144,l11lll_l1_ (u"ࠧࠨ檹"),l11lll_l1_ (u"ࠨ࠴࠽࠾ࠬ檺")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ檻"))
				#l1ll11l1l1_l1_ += 1
			# main l1l11l1_l1_ l1lll1111ll11_l1_ l1lll11l11l11_l1_
			l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ檼"))
			succeeded,item,l111ll1l_l1_ = l1ll1llll11ll_l1_(cc,l11lll_l1_ (u"ࠫࠬ檽"),l1ll1llll1l1l_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭檾"),str(cc))
			if succeeded and l1ll1llll1lll_l1_ and l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ檿") in list(item.keys()):
				link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ櫀")
				l1ll1llll1lll_l1_.append([item,link,l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ櫁")])
	return dd,l1lll111l11ll_l1_,l1ll1llll1lll_l1_,l1ll1lll1llll_l1_
def l1ll1llll1111_l1_(cc,dd,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ櫂"),l11lll_l1_ (u"ࠪࠫ櫃"),index,l11lll_l1_ (u"ࠫࡘࡋࡃࡐࡐࡇࠫ櫄")+l11lll_l1_ (u"ࠬࡢ࡮ࠨ櫅")+url)
	level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = index.split(l11lll_l1_ (u"࠭࠺࠻ࠩ櫆"))
	l1ll1llll1l1l_l1_,l1lll11111lll_l1_ = [],[]
	# search results
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ櫇"))
	# main l1l11l1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ櫈")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ櫉"))
	# l11lll11l11l_l1_ l1lll1111ll11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ櫊"))
	# l11ll1lll1l_l1_ search & l11l1l11lll1_l1_ & l1lll11l11l11_l1_
	if l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ櫋") in url: l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜࠲ࡠ࡟ࠬࡧࡰࡱࡧࡱࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡂࡥࡷ࡭ࡴࡴࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ櫌"))
	elif l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ櫍") in url: l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ櫎"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ櫏")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ櫐"))
	# l11lll11l11l_l1_ l11ll11l1l_l1_ & l1lll1111ll11_l1_ filters
	if l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ櫑") in url or (l11lll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ櫒") in url and l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ櫓") not in url):
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ櫔")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ櫕"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ櫖")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ櫗"))
	# l1lll111l111l_l1_ search
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡࠢ櫘")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ櫙"))
	# main l1l11l1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ櫚")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ櫛"))
	# l11ll1lll1l_l1_ l11l1l11lll1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞ࠦ櫜")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ櫝"))
	l1lll111l1111_l1_,ee,l1lll111111ll_l1_ = l1ll1llll11ll_l1_(dd,l11lll_l1_ (u"ࠩࠪ櫞"),l1ll1llll1l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ櫟"),str(ee))
	#DIALOG_OK()
	if level==l11lll_l1_ (u"ࠫ࠷࠭櫠") and l1lll111l1111_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1ll1llll1l1l_l1_ = []
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ櫡")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ櫢"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ櫣")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ櫤"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ櫥")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ櫦"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ櫧")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ櫨"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ櫩")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ櫪"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ櫫")+index2+l11lll_l1_ (u"ࠤࡠࠦ櫬"))
				succeeded,item,l111ll1l_l1_ = l1ll1llll11ll_l1_(ee,l11lll_l1_ (u"ࠪࠫ櫭"),l1ll1llll1l1l_l1_)
				if succeeded: l1lll11111lll_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠸ࡀ࠺ࠨ櫮")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ櫯")+index2+l11lll_l1_ (u"࠭࠺࠻࠲ࠪ櫰")])
				#l1l11lll1l1l_l1_ = l1lll111lll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽ࠫ櫱")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ櫲")+index2+l11lll_l1_ (u"ࠩ࠽࠾࠵࠭櫳"))
				#if l1l11lll1l1l_l1_: l1l1l11l11_l1_ += 1
				#LOG_THIS(l11lll_l1_ (u"ࠪࠫ櫴"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ櫵")+str(item))
				#l1l1l11l11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token = l1lll11l11l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ櫶"),l111ll_l1_+title,link,144,l1llll_l1_,l11lll_l1_ (u"࠭࠳࠻࠼ࠪ櫷")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ櫸")+index2+l11lll_l1_ (u"ࠨ࠼࠽࠴ࠬ櫹"))
			# search l1lll11l11l11_l1_
			l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠱࡞ࠤ櫺"))
			# search l1lll11l11l11_l1_
			l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡ࠱࡞ࠤ櫻"))
			succeeded,item,l111ll1l_l1_ = l1ll1llll11ll_l1_(dd,l11lll_l1_ (u"ࠫࠬ櫼"),l1ll1llll1l1l_l1_)
			if succeeded and l1lll11111lll_l1_ and l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ櫽") in list(item.keys()):
				l1lll11111lll_l1_.append([item,url,l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ櫾")])
			#l1l11lll1l1l_l1_ = l1lll111lll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ櫿"))
			#if l1l11lll1l1l_l1_: l1l1l11l11_l1_ += 1
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ欀"),str(item))
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ欁"),link+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ欂")+token)
	return ee,l1lll111l1111_l1_,l1lll11111lll_l1_,l1lll111111ll_l1_
def l1ll1lllll11l_l1_(cc,ee,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ欃"),l11lll_l1_ (u"ࠬ࠭欄"),index,l11lll_l1_ (u"࠭ࡔࡉࡋࡕࡈࠬ欅")+l11lll_l1_ (u"ࠧ࡝ࡰࠪ欆")+url)
	level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = index.split(l11lll_l1_ (u"ࠨ࠼࠽ࠫ欇"))
	l1ll1llll1l1l_l1_,l1ll1llllll11_l1_ = [],[]
	# search results
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ欈")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡶࡦࡴࡷ࡭ࡨࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ欉"))
	# l11ll1lll1l_l1_ l11l1l11lll1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ權")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ欋"))
	# l1lll111ll1ll_l1_ menu l1lll1111ll11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ欌")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ欍"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ欎")+index2+l11lll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ欏"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡࠢ欐")+index2+l11lll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ欑"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ欒")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ欓"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ欔")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ欕"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ欖")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ欗"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ欘"))
	# l1lll111l111l_l1_ l1lll11l11ll1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ欙"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ欚"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ欛")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫ࡥ࡭ࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ欜"))
	# main l1l11l1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ欝")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ欞"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫ࠢ欟"))
	l1lll111l1l1l_l1_,ff,l1lll11l111ll_l1_ = l1ll1llll11ll_l1_(ee,l11lll_l1_ (u"ࠬ࠭欠"),l1ll1llll1l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ次"),str(ff))
	if level==l11lll_l1_ (u"ࠧ࠴ࠩ欢") and l1lll111l1l1l_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1lll1111l1ll_l1_ = str(zz)
				#DIALOG_OK()
				l1ll1llll1l1l_l1_ = []
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠧ欣")+l1lll1111l1ll_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ欤"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠢ欥")+l1lll1111l1ll_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ欦"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠤ欧")+l1lll1111l1ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ欨"))
				l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠦ欩")+l1lll1111l1ll_l1_+l11lll_l1_ (u"ࠣ࡟ࠥ欪"))
				succeeded,item,l111ll1l_l1_ = l1ll1llll11ll_l1_(ff,l11lll_l1_ (u"ࠩࠪ欫"),l1ll1llll1l1l_l1_)
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token = l1lll11l11l1l_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ欬"),l111ll_l1_+link,link,143,l1llll_l1_)
				if succeeded: l1ll1llllll11_l1_.append([item,url,l11lll_l1_ (u"ࠫ࠹ࡀ࠺ࠨ欭")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ欮")+index2+l11lll_l1_ (u"࠭࠺࠻ࠩ欯")+l1lll1111l1ll_l1_])
				#l1l11lll1l1l_l1_ = l1lll111lll11_l1_(item,url,l11lll_l1_ (u"ࠧ࠵࠼࠽ࠫ欰")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ欱")+index2+l11lll_l1_ (u"ࠩ࠽࠾ࠬ欲")+l1lll1111l1ll_l1_)
				#if l1l11lll1l1l_l1_: l1l1l11l1l_l1_ += 1
	return ff,l1lll111l1l1l_l1_,l1ll1llllll11_l1_,l1lll11l111ll_l1_
def l1ll1llll11ll_l1_(l11lll1l1ll1_l1_,l11llll111l1_l1_,l1ll1llllll1l_l1_):
	cc,l11llll111l1_l1_ = l11lll1l1ll1_l1_,l11llll111l1_l1_
	dd,l11llll111l1_l1_ = l11lll1l1ll1_l1_,l11llll111l1_l1_
	ee,l11llll111l1_l1_ = l11lll1l1ll1_l1_,l11llll111l1_l1_
	ff,l11llll111l1_l1_ = l11lll1l1ll1_l1_,l11llll111l1_l1_
	item,render = l11lll1l1ll1_l1_,l11llll111l1_l1_
	count = len(l1ll1llllll1l_l1_)
	for l11l1lllll_l1_ in range(count):
		try:
			out = eval(l1ll1llllll1l_l1_[l11l1lllll_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"ࠪࠫ欳")
			return True,out,l11l1lllll_l1_+1
		except: pass
	return False,l11lll_l1_ (u"ࠫࠬ欴"),0
def l1111l_l1_(url,index=l11lll_l1_ (u"ࠬ࠭欵"),data=l11lll_l1_ (u"࠭ࠧ欶")):
	l1ll1llll1lll_l1_,l1lll11111lll_l1_,l1ll1llllll11_l1_ = [],[],[]
	if l11lll_l1_ (u"ࠧ࠻࠼ࠪ欷") not in index: index = l11lll_l1_ (u"ࠨ࠳࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ欸")
	level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = index.split(l11lll_l1_ (u"ࠩ࠽࠾ࠬ欹"))
	if level==l11lll_l1_ (u"ࠪ࠸ࠬ欺"): level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭欻"),l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭欼"),l11lll_l1_ (u"࠭ࠧ欽"),index,url)
	data = data.replace(l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ款"),l11lll_l1_ (u"ࠨࠩ欿"))
	html,cc,l11llll11_l1_ = l1lll1111l111_l1_(url,data)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡰࡴࠣࠫ࠴ࡻࡳࡦࡴ࠲ࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊࠥࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡲࡻࡳ࡫ࡲࡏࡣࡰࡩࠧ࠴ࠪࡀࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨ࡯ࡦࠡࡰࡲࡸࠥࡵࡷ࡯ࡧࡵ࠾ࠥࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡯ࡦࠡࡱࡺࡲࡪࡸ࠺ࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠵ࡣࠩࠋࠋࠌࠍࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠠ࠾ࠢࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭ࠫࡰࡹࡱࡩࡷࡔࡁࡎࡇ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡳࡼࡴࡥࡳ࡝࠳ࡡࡠ࠷࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱࠬ࠲࠶࠷࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠧࠨࠢ歀")
	index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭歁")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ歂")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ歃")+l1lll1111l1ll_l1_
	if level in [l11lll_l1_ (u"࠭࠱ࠨ歄"),l11lll_l1_ (u"ࠧ࠳ࠩ歅"),l11lll_l1_ (u"ࠨ࠵ࠪ歆")]:
		dd,l1lll111l11ll_l1_,l1ll1llll1lll_l1_,l1ll1lll1llll_l1_ = l1lll11111l1l_l1_(cc,url,index)
		if not l1lll111l11ll_l1_: return
		l1ll11l1l1_l1_ = len(l1ll1llll1lll_l1_)
		if l1ll11l1l1_l1_<2:
			if level==l11lll_l1_ (u"ࠩ࠴ࠫ歇"): level = l11lll_l1_ (u"ࠪ࠶ࠬ歈")
			l1ll1llll1lll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ歉"),l11lll_l1_ (u"ࠬ࠭歊"),index,l11lll_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠱࡝ࡰࠪ歋")+l11lll_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ歌")+str(l1ll1lll1llll_l1_)+l11lll_l1_ (u"ࠨ࡞ࡱࠫ歍")+l11lll_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ歎")+str(len(dd))+l11lll_l1_ (u"ࠪࡠࡳ࠭歏")+l11lll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ歐")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠬࡢ࡮ࠨ歑")+url)
	index = level+l11lll_l1_ (u"࠭࠺࠻ࠩ歒")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ歓")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ歔")+l1lll1111l1ll_l1_
	if level in [l11lll_l1_ (u"ࠩ࠵ࠫ歕"),l11lll_l1_ (u"ࠪ࠷ࠬ歖")]:
		ee,l1lll111l1111_l1_,l1lll11111lll_l1_,l1lll111111ll_l1_ = l1ll1llll1111_l1_(cc,dd,url,index)
		if not l1lll111l1111_l1_: return
		l1l1l11l11_l1_ = len(l1lll11111lll_l1_)
		if l1l1l11l11_l1_<2:
			if level==l11lll_l1_ (u"ࠫ࠷࠭歗"): level = l11lll_l1_ (u"ࠬ࠹ࠧ歘")
			l1lll11111lll_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ歙"),l11lll_l1_ (u"ࠧࠨ歚"),index,l11lll_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠴࡟ࡲࠬ歛")+l11lll_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭歜")+str(l1lll111111ll_l1_)+l11lll_l1_ (u"ࠪࡠࡳ࠭歝")+l11lll_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭歞")+str(len(ee))+l11lll_l1_ (u"ࠬࡢ࡮ࠨ歟")+l11lll_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ歠")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"ࠧ࡝ࡰࠪ歡")+url)
	index = level+l11lll_l1_ (u"ࠨ࠼࠽ࠫ止")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ正")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭此")+l1lll1111l1ll_l1_
	if level in [l11lll_l1_ (u"ࠫ࠸࠭步")]:
		ff,l1lll111l1l1l_l1_,l1ll1llllll11_l1_,l1lll11l111ll_l1_ = l1ll1lllll11l_l1_(cc,ee,url,index)
		if not l1lll111l1l1l_l1_: return
		l1l1l11l1l_l1_ = len(l1ll1llllll11_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭武"),l11lll_l1_ (u"࠭ࠧ歧"),index,l11lll_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠴࡞ࡱࠫ歨")+l11lll_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ歩")+str(l1lll11l111ll_l1_)+l11lll_l1_ (u"ࠩ࡟ࡲࠬ歪")+l11lll_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ歫")+str(len(ff))+l11lll_l1_ (u"ࠫࡡࡴࠧ歬")+l11lll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭歭")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"࠭࡜࡯ࠩ歮")+url)
	for item,url,index in l1ll1llll1lll_l1_+l1lll11111lll_l1_+l1ll1llllll11_l1_:
		l1l11lll1l1l_l1_ = l1lll111lll11_l1_(item,url,index)
	return
def l1lll111lll11_l1_(item,url=l11lll_l1_ (u"ࠧࠨ歯"),index=l11lll_l1_ (u"ࠨࠩ歰")):
	if l11lll_l1_ (u"ࠩ࠽࠾ࠬ歱") in index: level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = index.split(l11lll_l1_ (u"ࠪ࠾࠿࠭歲"))
	else: level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = l11lll_l1_ (u"ࠫ࠶࠭歳"),l11lll_l1_ (u"ࠬ࠶ࠧ歴"),l11lll_l1_ (u"࠭࠰ࠨ歵"),l11lll_l1_ (u"ࠧ࠱ࠩ歶")
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,l1lll111lllll_l1_ = l1lll11l11l1l_l1_(item)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ歷"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ歸"),link)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ歹"),link+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ歺")+title)
	# needed for l1lll111l111l_l1_ l1lll11l11ll1_l1_ next l1l11l1_l1_
	# and needed for l1lll111l111l_l1_ l1lll11l11ll1_l1_ sub-menu
	#if (l11lll_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠹࠵࠭死") in link or l11lll_l1_ (u"࠭ࡶࡪࡧࡺࡁ࠹࠿ࠧ歼") in link) and (l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࡃࠬ歽") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࡃࠬ歾") in link): link = url
	l1ll11ll11l1_l1_ = l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࡂࠫ歿") in link or l11lll_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰࡷࡄ࠭殀") in link or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ殁") in link
	l1ll11ll1111_l1_ = l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ殂") in link or l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠿ࠨ殃") in link
	if l1ll11ll11l1_l1_ or l1ll11ll1111_l1_: link = url
	l1ll11ll11l1_l1_ = l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ殄") not in link and l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ殅") not in link
	l1ll11ll1111_l1_ = l11lll_l1_ (u"ࠩ࠲࡫ࡦࡳࡩ࡯ࡩࠪ殆") not in link  and l11lll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭殇") not in link
	if index[0:5]==l11lll_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽ࠫ殈") and l1ll11ll11l1_l1_ and l1ll11ll1111_l1_: link = url
	if l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ殉") in url or l11lll_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ殊") in link:
		level,l1ll1lllllll1_l1_,index2,l1lll1111l1ll_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ残"),l11lll_l1_ (u"ࠨ࠲ࠪ殌"),l11lll_l1_ (u"ࠩ࠳ࠫ殍"),l11lll_l1_ (u"ࠪ࠴ࠬ殎")
		index = l11lll_l1_ (u"ࠫࠬ殏")
	l11llll11_l1_ = l11lll_l1_ (u"ࠬ࠭殐")
	if l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ殑") in link or l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭殒") in link or l11lll_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭殓") in url:
		data = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ殔"))
		if data.count(l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ殕"))==4:
			l1lll111l1l11_l1_,key,l1lll1111lll1_l1_,l1lll11111111_l1_,token = data.split(l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ殖"))
			l11llll11_l1_ = l1lll111l1l11_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ殗")+key+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ殘")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ殙")+l1lll11111111_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ殚")+l1lll111lllll_l1_
			if l11lll_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ殛") in url and not link: link = url
			else: link = link+l11lll_l1_ (u"ࠪࡃࡰ࡫ࡹ࠾ࠩ殜")+key
	if not title:
		global l1ll1lllll1l1_l1_
		l1ll1lllll1l1_l1_ += 1
		title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࠧ殝")+str(l1ll1lllll1l1_l1_)
		index = l11lll_l1_ (u"ࠬ࠹ࠧ殞")+l11lll_l1_ (u"࠭࠺࠻ࠩ殟")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠪ殠")+index2+l11lll_l1_ (u"ࠨ࠼࠽ࠫ殡")+l1lll1111l1ll_l1_
	#if l11lll_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ殢") in url: link = url
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ殣"),l11lll_l1_ (u"ࠫࠬ殤"),title,index+l11lll_l1_ (u"ࠬࡢ࡮ࠨ殥")+link)
	#if not link: link = url
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ殦"),l11lll_l1_ (u"ࠧࠨ殧"),str(succeeded),title+l11lll_l1_ (u"ࠨࠢ࠽࠾࠿ࠦࠧ殨")+link)
	#if l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ殩") in url and index==l11lll_l1_ (u"ࠪ࠴ࠬ殪"):
	#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ殫"),l111ll_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ殬") in str(item): return False			# l1lll111ll1l1_l1_ not items
	elif l11lll_l1_ (u"࠭࠯ࡢࡤࡲࡹࡹ࠭殭") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡥࡲࡱࡲࡻ࡮ࡪࡶࡼࠫ殮") in link: return False
	elif l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ殯") in list(item.keys()) or l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ殰") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭殱")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ殲")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ殳")+l1lll1111l1ll_l1_
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭殴"),l111ll_l1_+l11lll_l1_ (u"ࠧ࠻࠼ࠣࠫ段")+l11lll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ殶"),link,144,l1llll_l1_,index,l11llll11_l1_)
	elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ殷") in link:
		title = l11lll_l1_ (u"ࠪ࠾࠿ࠦࠧ殸")+title
		index = l11lll_l1_ (u"ࠫ࠸࠭殹")+l11lll_l1_ (u"ࠬࡀ࠺ࠨ殺")+l1ll1lllllll1_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ殻")+index2+l11lll_l1_ (u"ࠧ࠻࠼ࠪ殼")+l1lll1111l1ll_l1_
		url = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ殽"),l11lll_l1_ (u"ࠩࠪ殾"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ殿"),l111ll_l1_+title,url,145,l11lll_l1_ (u"ࠫࠬ毀"),index,l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ毁"))
	elif l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ毂") in url and not link:
		index = l11lll_l1_ (u"ࠧ࠴ࠩ毃")+l11lll_l1_ (u"ࠨ࠼࠽ࠫ毄")+l1ll1lllllll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ毅")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭毆")+l1lll1111l1ll_l1_
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ毇")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毈"),l111ll_l1_+title,url,144,l1llll_l1_,index,l11llll11_l1_)
	#elif l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ毉") in link: return False
	elif l11lll_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࠨ毊") in link and url==l11ll1_l1_:
		title = l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬ毋")+title
		index = l11lll_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭毌")
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ母"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11llll11_l1_)
	elif not link and l11lll_l1_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡎࡱࡹ࡭ࡪࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ毎") in str(item):
		title = l11lll_l1_ (u"ࠬࡀ࠺ࠡࠩ每")+title
		index = l11lll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ毐")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ毑"),l111ll_l1_+title,url,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ毒") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ毓"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ比"),9999)
	#elif l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ毕") in link and l11lll_l1_ (u"ࠬࡨࡰ࠾ࠩ毖") not in link:
	#	title = l11lll_l1_ (u"࠭࠺࠻ࠢࠪ毗")+title
	#	index = l11lll_l1_ (u"ࠧ࠳࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ毘")
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毙"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif l1111llllll_l1_:
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ毚"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	elif l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ毛") in link:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毜"),l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ毝")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ毞")+title,link,144,l1llll_l1_,index)
	#elif l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭毟") in link and l11lll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ毠") not in link and l11lll_l1_ (u"ࠩࡷࡁ࠵࠭毡") not in link:
	#	l1lll1111l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ毢"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭毣")+l1lll1111l1l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ毤"),l111ll_l1_+l11lll_l1_ (u"࠭ࡌࡊࡕࡗࠫ毥")+count+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ毦")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴ࠱ࠪ毧") in link:
		link = link.split(l11lll_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ毨"),1)[0]
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ毩"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	elif l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ毪") in link:
		if l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ毫") in link and count:
			l1lll1111l1l1_l1_ = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭毬"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ毭")+l1lll1111l1l1_l1_
			index = l11lll_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ毮")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ毯"),l111ll_l1_+l11lll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ毰")+count+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ毱")+title,link,144,l1llll_l1_,index)
		else:
			link = link.split(l11lll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ毲"),1)[0]
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ毳"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	elif l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ毴") in link or l11lll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ毵") in link or (l11lll_l1_ (u"ࠩ࠲ࡄࠬ毶") in link and link.count(l11lll_l1_ (u"ࠪ࠳ࠬ毷"))==3):
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ毸"),l111ll_l1_+l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ毹")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ毺")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ毻") in link:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ毼"),l111ll_l1_+l11lll_l1_ (u"ࠩࡘࡗࡊࡘࠧ毽")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ毾")+title,link,144,l1llll_l1_,index)
	else:
		if not link: link = url
		title = l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ毿")+title
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ氀"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11llll11_l1_)
	return True
def l1lll11l11l1l_l1_(item):
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token = False,l11lll_l1_ (u"࠭ࠧ氁"),l11lll_l1_ (u"ࠧࠨ氂"),l11lll_l1_ (u"ࠨࠩ氃"),l11lll_l1_ (u"ࠩࠪ氄"),l11lll_l1_ (u"ࠪࠫ氅"),l11lll_l1_ (u"ࠫࠬ氆"),l11lll_l1_ (u"ࠬ࠭氇"),l11lll_l1_ (u"࠭ࠧ氈")
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ氉"),str(item))
	if not isinstance(item,dict): return succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token
	for l1lll111ll111_l1_ in list(item.keys()):
		render = item[l1lll111ll111_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ氊"),str(render))
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ氋"),str(render))
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ氌"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡒࡩࡴࡶࡋࡩࡦࡪࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ氍"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡰ࡮ࡴࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ氎"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ氏"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ氐"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ民"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ氒"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ氓"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ气"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ氕"))
	# required for l11lll11l11l_l1_ l1lll11111l11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ氖"))
	# l1lll111l111l_l1_ l1lll1111ll11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡶࡪࡦࡨࡳࡎࡪࠧ࡞ࠤ気"))
	succeeded,title,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ氘"),l11lll_l1_ (u"ࠩࠪ氙"),l11lll_l1_ (u"ࠪࠫ氚"),str(l111ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ氛"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠩ氜")+str(title))
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ氝"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ氞"))
	# l1lll11l11l11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡦࡶࡩࡖࡴ࡯ࠫࡢࠨ氟"))
	# header feed
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ氠"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ氡"))
	# required for l11lll11l11l_l1_ l1lllll1l1l_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ氢"))
	# l1lll111l111l_l1_ l1lll1111ll11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ氣"))
	succeeded,link,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ氤"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ氥"))
	# l1lll111l111l_l1_ l1lll1111ll11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡳࡧࡨࡰ࡜ࡧࡴࡤࡪࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ氦"))
	succeeded,l1llll_l1_,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ氧"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠪࠤࠥࠦࠧ氨")+l1llll_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࠩࡠࠦ氩"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࡗࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ氪"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡈ࡯ࡵࡶࡲࡱࡕࡧ࡮ࡦ࡮ࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ氫"))
	succeeded,count,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ氬"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ氭"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ氮"))
	# l1lll111l1lll_l1_ l1lll111l111l_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࠨ࡟࡞ࠫ࡮ࡩ࡯࡯ࡖࡼࡴࡪ࠭࡝ࠣ氯"))
	# l1lll111l1lll_l1_ l1lll111l111l_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡺࡹ࡭ࡧࠪࡡࠧ氰"))
	succeeded,l1l111l1ll_l1_,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	#l1ll1llll1l1l_l1_ = []
	# l1lll11l11l11_l1_
	#l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡰ࡮ࡩ࡫ࡕࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ氱"))
	# l11ll1lll1l_l1_ l11l1l11lll1_l1_
	#l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡶࡵࡥࡨࡱࡩ࡯ࡩࡓࡥࡷࡧ࡭ࡴࠩࡠࠦ氲"))
	#succeeded,l1ll1lllll1ll_l1_,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	# l11ll1lll1l_l1_ l11l1l11lll1_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ氳"))
	# l1lll11l11l11_l1_
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡵࡱ࡮ࡩࡳ࠭࡝ࠣ水"))
	succeeded,token,l111ll1l_l1_ = l1ll1llll11ll_l1_(item,render,l1ll1llll1l1l_l1_)
	if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ氵") in l1l111l1ll_l1_: l1l111l1ll_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠪࠫ氶"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ氷")
	if l11lll_l1_ (u"๋ࠬศศึิࠫ永") in l1l111l1ll_l1_: l1l111l1ll_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ氹"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ氺")
	if l11lll_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ氻") in list(render.keys()):
		l1lll111lll1l_l1_ = str(render[l11lll_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ氼")])
		if l11lll_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ氽") in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠫࠩࡀࠠࠡࠩ氾")
		if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ氿") in l1lll111lll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ汀")
		if l11lll_l1_ (u"ࠧࡃࡷࡼࠫ汁") in l1lll111lll1l_l1_ or l11lll_l1_ (u"ࠨࡔࡨࡲࡹ࠭求") in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ汃")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡸ๊ࠫฮวีำࠪ汄")) in l1lll111lll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ汅")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡺ࠭ิาษฤࠫ汆")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ汇")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡵࠨษึฮหาวาࠩ汈")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ汉")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ汊")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ汋")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ汌") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠬࡅࠧ汍"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ汎") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ汏")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll1111l11l_l1_: title = l1lll1111l11l_l1_+title
	#title = unescapeHTML(title)
	l1l111l1ll_l1_ = l1l111l1ll_l1_.replace(l11lll_l1_ (u"ࠨ࠮ࠪ汐"),l11lll_l1_ (u"ࠩࠪ汑"))
	count = count.replace(l11lll_l1_ (u"ࠪ࠰ࠬ汒"),l11lll_l1_ (u"ࠫࠬ汓"))
	count = re.findall(l11lll_l1_ (u"ࠬࡢࡤࠬࠩ汔"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"࠭ࠧ汕")
	return True,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_,token
def l1lll1111l111_l1_(url,data=l11lll_l1_ (u"ࠧࠨ汖"),request=l11lll_l1_ (u"ࠨࠩ汗")):
	if request==l11lll_l1_ (u"ࠩࠪ汘"): request = l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ汙")
	#if l11lll_l1_ (u"ࠫࡤࡥࠧ汚") in l1lll111l11l1_l1_: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠬ࠭汛")
	#if l11lll_l1_ (u"࠭ࡳࡴ࠿ࠪ汜") in url: url = url.split(l11lll_l1_ (u"ࠧࡴࡵࡀࠫ汝"))[0]
	l111lll1l1_l1_ = l1l11l11l_l1_()
	#l111lll1l1_l1_ = l11lll_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠰࠺࠰࠳࠲࠵࠴࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠡࡇࡧ࡫࠴࠷࠰࠺࠰࠳࠲࠶࠻࠱࠹࠰࠺࠴ࠬ汞")
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭江"):l111lll1l1_l1_,l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ池"):l11lll_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ污")}
	#l1l1ll1ll_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ汢"))
	if data.count(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ汣"))==4: l1lll111l1l11_l1_,key,l1lll1111lll1_l1_,l1lll11111111_l1_,token = data.split(l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ汤"))
	else: l1lll111l1l11_l1_,key,l1lll1111lll1_l1_,l1lll11111111_l1_,token = l11lll_l1_ (u"ࠨࠩ汥"),l11lll_l1_ (u"ࠩࠪ汦"),l11lll_l1_ (u"ࠪࠫ汧"),l11lll_l1_ (u"ࠫࠬ汨"),l11lll_l1_ (u"ࠬ࠭汩")
	l11llll11_l1_ = {l11lll_l1_ (u"ࠨࡣࡰࡰࡷࡩࡽࡺࠢ汪"):{l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ汫"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ汬"):l11lll_l1_ (u"ࠤࡤࡶࠧ汭"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ汮"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ汯"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ汰"):l1lll1111lll1_l1_}}}
	if url==l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ汱") or l11lll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ汲") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡳࡧࡨࡰ࠴ࡸࡥࡦ࡮ࡢࡻࡦࡺࡣࡩࡡࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ汳")+l11lll_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ汴")+key
		l11llll11_l1_[l11lll_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩࡕࡧࡲࡢ࡯ࡶࠫ汵")] = l1lll111l1l11_l1_
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ汶"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠱ࡴࡶࠪ汷"))
	elif l11lll_l1_ (u"࠭࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ汸") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ汹")+key
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭決"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ汻"))
	elif l11lll_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ汼") in url and l1lll111l1l11_l1_:
		l11llll11_l1_[l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ汽")] = token
		l11llll11_l1_[l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭汾")][l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࠭汿")][l11lll_l1_ (u"ࠧࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ沀")] = l1lll111l1l11_l1_
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭沁"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠸ࡹ࡮ࠧ沂"))
	elif l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ沃") in url and l1lll11111111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ沄"):l11lll_l1_ (u"ࠬ࠷ࠧ沅"),l11lll_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ沆"):l1lll1111lll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ沇"):l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ沈")+l1lll11111111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭沉"),url,l11lll_l1_ (u"ࠪࠫ沊"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ沋"),l11lll_l1_ (u"ࠬ࠭沌"),l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠶ࡶ࡫ࠫ沍"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ沎"),url,l11lll_l1_ (u"ࠨࠩ沏"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ沐"),l11lll_l1_ (u"ࠪࠫ沑"),l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠼ࡴࡩࠩ沒"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ沓"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ沔"),html,re.DOTALL|re.I)
	if tmp: l1lll1111lll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ沕"),html,re.DOTALL|re.I)
	if tmp: l1lll111l1l11_l1_ = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ沖"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭沗"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠥ࠾ࢀࠨࡴࡰ࡭ࡨࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ沘"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ沙"),l11lll_l1_ (u"ࠬ࠭沚"),l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ沛"),str(len(tmp)))
	#if tmp: l1lll11l11l11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ沜") in list(cookies.keys()): l1lll11111111_l1_ = cookies[l11lll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊ࠭沝")]
	l11llll1l_l1_ = l1lll111l1l11_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭沞")+key+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ沟")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ沠")+l1lll11111111_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ没")+token
	if request==l11lll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭沢") and l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ沣") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ沤"),html,re.DOTALL)
		if not l111ll1ll1_l1_: l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ沥"),html,re.DOTALL)
		l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠪࡷࡹࡸࠧ沦"),l111ll1ll1_l1_[0])
	elif request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ沧") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ沨") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ沩"),html,re.DOTALL)
		l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ沪"),l111ll1ll1_l1_[0])
	elif l11lll_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ沫") not in html: l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠩࡶࡸࡷ࠭沬"),html)
	else: l1ll1llll1ll1_l1_ = l11lll_l1_ (u"ࠪࠫ沭")
	if 0:
		cc = str(l1ll1llll1ll1_l1_)
		if kodi_version>18.99: cc = cc.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ沮"))
		open(l11lll_l1_ (u"࡙ࠬ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ沯"),l11lll_l1_ (u"࠭ࡷࡣࠩ沰")).write(cc)
		#open(l11lll_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫ沱"),l11lll_l1_ (u"ࠨࡹࠪ沲")).write(html)
	settings.setSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ河"),l11llll1l_l1_)
	return html,l1ll1llll1ll1_l1_,l11llll1l_l1_
def l1lll11l1111l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ沴"),l11lll_l1_ (u"ࠫ࠰࠭沵"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭沶")+search
	l1111l_l1_(l11l11l_l1_,index)
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ沷")+l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࠬ沸")+l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ油")+l11lll_l1_ (u"ࠩࡢࠫ沺")+search
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ治"),l11lll_l1_ (u"ࠫࠬ沼"),l11lll_l1_ (u"ࠬ࠭沽"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ沾"),l11lll_l1_ (u"ࠧࠨ沿"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ泀"),l11lll_l1_ (u"ࠩ࠮ࠫ況"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࠬ泂")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"ࠫࡤ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘࡥࠧ泃") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡒࠧ࠵࠹࠸ࡊࠥ࠳࠷࠶ࡈࠬ泄")
		elif l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬ泅") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ泆")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࡤ࠭泇") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅ࡬ࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ泈")
		else: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠪࠫ泉")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111111l1_l1_
	else:
		l1lll1111111l_l1_,l1ll1llll11l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠫࠬ泊")
		l1ll1llll1l11_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ泋"),l11lll_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ泌"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ泍"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ泎"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭泏")]
		l1lll111ll11l_l1_ = [l11lll_l1_ (u"ࠪࠫ泐"),l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ泑"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ泒"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ泓"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭泔")]
		l1lll111llll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ法"),l1ll1llll1l11_l1_)
		if l1lll111llll1_l1_ == -1: return
		l1ll1llllllll_l1_ = l1lll111ll11l_l1_[l1lll111llll1_l1_]
		html,c,data = l1lll1111l111_l1_(l11l11l_l1_+l1ll1llllllll_l1_)
		if c:
			try:
				d = c[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ泖")][l11lll_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭泗")][l11lll_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭泘")][l11lll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ泙")][l11lll_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ泚")][l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ泛")][l11lll_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ泜")]
				for l1ll1llll111l_l1_ in range(len(d)):
					group = d[l1ll1llll111l_l1_][l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ泝")][l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ泞")]
					for l1lll11l111l1_l1_ in range(len(group)):
						render = group[l1lll11l111l1_l1_][l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ泟")]
						if l11lll_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ泠") in list(render.keys()):
							link = render[l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ泡")][l11lll_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ波")][l11lll_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭泣")][l11lll_l1_ (u"ࠩࡸࡶࡱ࠭泤")]
							link = link.replace(l11lll_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ泥"),l11lll_l1_ (u"ࠫࠫ࠭泦"))
							title = render[l11lll_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭泧")]
							title = title.replace(l11lll_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ注"),l11lll_l1_ (u"ࠧࠨ泩"))
							if l11lll_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ泪") in title: continue
							if l11lll_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ泫") in title:
								title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ泬")+title
								l1lll1lll_l1_ = title
								l1lllllll1_l1_ = link
							if l11lll_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ泭") in title: continue
							title = title.replace(l11lll_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ泮"),l11lll_l1_ (u"࠭ࠧ泯"))
							if l11lll_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ泰") in title: continue
							if l11lll_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ泱") in title:
								title = l11lll_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ泲")+title
								l1lll1lll_l1_ = title
								l1lllllll1_l1_ = link
							if l11lll_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ泳") in title: continue
							l1lll1111111l_l1_.append(escapeUNICODE(title))
							l1ll1llll11l1_l1_.append(link)
			except: pass
		if not l1lll1lll_l1_: l1lll111l1ll1_l1_ = l11lll_l1_ (u"ࠫࠬ泴")
		else:
			l1lll1111111l_l1_ = [l11lll_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ泵"),l1lll1lll_l1_]+l1lll1111111l_l1_
			l1ll1llll11l1_l1_ = [l11lll_l1_ (u"࠭ࠧ泶"),l1lllllll1_l1_]+l1ll1llll11l1_l1_
			l1lll11l11111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ泷"),l1lll1111111l_l1_)
			if l1lll11l11111_l1_ == -1: return
			l1lll111l1ll1_l1_ = l1ll1llll11l1_l1_[l1lll11l11111_l1_]
		if l1lll111l1ll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll111l1ll1_l1_
		elif l1ll1llllllll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1ll1llllllll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ泸")
	#DIALOG_OK()
	l1111l_l1_(l11l1l1_l1_)
	return
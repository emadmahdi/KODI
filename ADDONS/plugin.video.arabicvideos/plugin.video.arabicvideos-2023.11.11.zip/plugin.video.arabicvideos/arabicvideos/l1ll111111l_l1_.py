# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬⱐ")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡆࡃࡍࡢࠫⱑ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨⱒ"),l11lll_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨⱓ")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l1111l_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l11111_l1_(url,text)
	elif mode==624: results = l1l11l_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩⱔ"),l11lll_l1_ (u"ࠩไฬึ้ษࠡࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨⱕ"),l11lll_l1_ (u"ࠪࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠪⱖ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱗ"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬⱘ"),l11lll_l1_ (u"࠭ࠧⱙ"),629,l11lll_l1_ (u"ࠧࠨⱚ"),l11lll_l1_ (u"ࠨࠩⱛ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ⱜ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱝ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⱞ"),l11lll_l1_ (u"ࠬ࠭ⱟ"),9999)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱡ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⱡ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩⱢ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠩࠪⱣ"),l11lll_l1_ (u"ࠪࠫⱤ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ⱥ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱦ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⱧ")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ⱨ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠨࠩⱩ"),l11lll_l1_ (u"ࠩࠪⱪ"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩⱫ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱬ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⱭ")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬⱮ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠧࠨⱯ"),l11lll_l1_ (u"ࠨࠩⱰ"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ⱱ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱲ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ⱳ")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠩⱴ"),l1ll1l1_l1_,621,l11lll_l1_ (u"࠭ࠧⱵ"),l11lll_l1_ (u"ࠧࠨⱶ"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪⱷ"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⱸ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⱹ"),l11lll_l1_ (u"ࠫࠬⱺ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡹࡵࡥࡵࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪⱻ"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧⱼ"),l11lll_l1_ (u"ࠧࠨⱽ"),l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦแษำๆอࠬⱾ"),l11lll_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬⱿ"))
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫⲀ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲁ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⲂ")+l111ll_l1_+title,link,624)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⲃ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⲄ"),l11lll_l1_ (u"ࠨࠩⲅ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭Ⲇ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣⲇ"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠫࠬⲈ"))
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪⲉ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲋ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⲋ")+l111ll_l1_+title,link,624)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⲌ"),url,l11lll_l1_ (u"ࠩࠪⲍ"),l11lll_l1_ (u"ࠪࠫⲎ"),l11lll_l1_ (u"ࠫࠬⲏ"),l11lll_l1_ (u"ࠬ࠭Ⲑ"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬⲑ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫⲒ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩⲓ"),l11lll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨⲔ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧⲕ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠫࠬⲖ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⲗ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⲘ"),l11lll_l1_ (u"ࠧࠨⲙ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭Ⲛ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬⲛ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲜ"),l111ll_l1_+title,link,621)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨⲝ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧⲞ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⲟ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⲠ"),l11lll_l1_ (u"ࠨࠩⲡ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲢ"),l111ll_l1_+title,link,621)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠪࠫⲣ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬⲤ"),l11lll_l1_ (u"ࠬ࠭ⲥ"),request,url)
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫⲦ"):
		url,search = url.split(l11lll_l1_ (u"ࠧࡀࠩⲧ"),1)
		data = l11lll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧⲨ")+search
		headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨⲩ"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪⲪ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩⲫ"),url,data,headers,l11lll_l1_ (u"ࠬ࠭Ⲭ"),l11lll_l1_ (u"࠭ࠧⲭ"),l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬⲮ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⲯ"),url,l11lll_l1_ (u"ࠩࠪⲰ"),l11lll_l1_ (u"ࠪࠫⲱ"),l11lll_l1_ (u"ࠫࠬⲲ"),l11lll_l1_ (u"ࠬ࠭ⲳ"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫⲴ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠧࠨⲵ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬⲶ"))
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧⲷ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬⲸ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬⲹ"),link,title))
	elif request==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧⲺ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧⲻ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭Ⲽ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨⲽ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭Ⲿ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪⲿ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭Ⳁ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧⳁ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨⳂ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨⳃ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩⳄ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪⳅ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪⳆ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩⳇ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫⳈ"),l11lll_l1_ (u"࠭ใๅ์หࠫⳉ"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭Ⳋ"),l11lll_l1_ (u"ࠨ้าหๆ࠭ⳋ"),l11lll_l1_ (u"่ࠩฬฬืวสࠩⳌ"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧⳍ"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫⳎ"),l11lll_l1_ (u"ࠬอไษ๊่ࠫⳏ"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭Ⳑ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩⳑ"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭Ⳓ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫⳓ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬⳔ"))
		#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩⳕ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧⳖ")+l1llll_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨⳗ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠧࠡࠩⳘ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫⳙ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⳚ"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩⳛ"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪⳜ"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫⳝ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳟ"),l111ll_l1_+title,link,623,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬⳟ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳠ"),l111ll_l1_+title,link,621,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳡ"),l111ll_l1_+title,link,623,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩⳢ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ⳣ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ⳤ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⳥"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠧࠤࠩ⳦"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ⳧")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ⳨"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳩"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ⳪")+title,link,621)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭Ⳬ"),l11lll_l1_ (u"࠭ࠧⳬ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫⳭ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⳮ"),url,l11lll_l1_ (u"ࠩࠪ⳯"),l11lll_l1_ (u"ࠪࠫ⳰"),l11lll_l1_ (u"ࠫࠬ⳱"),l11lll_l1_ (u"ࠬ࠭Ⳳ"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ⳳ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ⳴"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⳵"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠩࠪ⳶")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࠫࠬࡵ࡮ࡤ࡮࡬ࡧࡰࡃࠢࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ⳷"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠫࠨ࠭⳸"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⳹"),l111ll_l1_+title,url,623,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ⳺"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࠬ⳻")+l1ll1_l1_+l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⳼"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠪࠫ࡭ࡸࡥࡧ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࡀ࠿ࡰ࡮ࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩࠪࠫ⳽"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⳾"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭⳿")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧⴀ"))
			title = title.replace(l11lll_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫⴁ"),l11lll_l1_ (u"ࠧࠡࠩⴂ"))
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⴃ"),l111ll_l1_+title,link,622,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪⴄ"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨⴅ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ⴆ")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧⴇ"))
		#		addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬⴈ"),l111ll_l1_+title,link,622,l1llll_l1_)
	return
def PLAY(url):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫⴉ"))
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬⴊ"),url,l11lll_l1_ (u"ࠩࠪⴋ"),l11lll_l1_ (u"ࠪࠫⴌ"),l11lll_l1_ (u"ࠫࠬⴍ"),l11lll_l1_ (u"ࠬ࠭ⴎ"),l11lll_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩⴏ"))
	html = response.content
	# l1llll1_l1_ l1l11l1_l1_
	link = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⴐ"),html,re.DOTALL)
	link = link[0]
	post = link.split(l11lll_l1_ (u"ࠨࡲࡲࡷࡹࡃࠧⴑ"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧⴒ"))
	post = EVAL(l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨⴓ"),post)
	links = post[l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡷࠬⴔ")]
	l1l111_l1_ = list(links.keys())
	links = list(links.values())
	l111l1_l1_ = zip(l1l111_l1_,links)
	for title,link in l111l1_l1_:
		link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ⴕ")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧⴖ")
		l1111_l1_.append(link)
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠨ࡯ࡦࠡ࡮࡬ࡲࡰࠦࡡ࡯ࡦࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࠪ࡬ࡹࡺࡰ࠻ࠩ࠮ࡰ࡮ࡴ࡫ࠋࠋ࡫ࡥࡸ࡮ࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡩࡣࡶ࡬ࡂ࠭ࠩ࡜࠳ࡠࠎࠎࡶࡡࡳࡶࡶࠤࡂࠦࡨࡢࡵ࡫࠲ࡸࡶ࡬ࡪࡶࠫࠫࡤࡥࠧࠪࠌࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸࠦ࠽ࠡ࡝ࡠࠎࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࡺࡲࡺ࠼ࠍࠍࠎࠏࡰࡢࡴࡷࠤࡂࠦࡢࡢࡵࡨ࠺࠹࠴ࡢ࠷࠶ࡧࡩࡨࡵࡤࡦࠪࡳࡥࡷࡺࠫࠨ࠿ࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡴࡦࡸࡴࠡ࠿ࠣࡴࡦࡸࡴ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠌࠌࠍࠎࡴࡥࡸࡡࡳࡥࡷࡺࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡲࡤࡶࡹ࠯ࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠋࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࠫࡃ࠭࠮࡫ࡱ࡬ࡲ࠭ࡴࡥࡸࡡࡳࡥࡷࡺࡳࠪࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡱ࡯࡮࡬ࡵ࠱ࡷࡵࡲࡩࡵ࡮࡬ࡲࡪࡹࠨࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠷ࠦࡩ࡯ࠢࡽࡾࡿࡀࠊࠊࠋࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠸࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠡ࠿ࡁࠤࠬ࠯ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫࠏࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧⴗ")
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ⴘ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⴙ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫⴚ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬⴛ"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧⴜ"),l11lll_l1_ (u"࠭ࠫࠨⴝ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨⴞ")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩⴟ"),l11lll_l1_ (u"ࠩไฬึ้ษࠡࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨⴠ"),l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴ࠭ⴡ"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫⴢ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩⴣ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫⴤ"))
	return
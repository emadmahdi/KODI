# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ撤")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡓࡉࡖࡢࠫ撥")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨ撦"),l11lll_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨ撧"),l11lll_l1_ (u"ࠨลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠫ撨")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1111l_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11111_l1_(url,text)
	elif mode==644: results = l1l11l_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭撩"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ撪"),l11lll_l1_ (u"ࠫࠬ撫"),l11lll_l1_ (u"ࠬ࠭撬"),l11lll_l1_ (u"࠭ࠧ播"),l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ撮"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ撯"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ撰"),l11lll_l1_ (u"ࠪࠫ撱"),649,l11lll_l1_ (u"ࠫࠬ撲"),l11lll_l1_ (u"ࠬ࠭撳"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ撴"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ撵"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ撶"),l11lll_l1_ (u"ࠩࠪ撷"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ撸"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭撹")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭撺"),l11ll1_l1_,641,l11lll_l1_ (u"࠭ࠧ撻"),l11lll_l1_ (u"ࠧࠨ撼"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ撽"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ撾"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ撿")+l111ll_l1_+l11lll_l1_ (u"ࠫัี๊ะࠢส่๊๎โฺࠩ擀"),l11ll1_l1_,641,l11lll_l1_ (u"ࠬ࠭擁"),l11lll_l1_ (u"࠭ࠧ擂"),l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭擃"))
	#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭擄"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ擅"),l11lll_l1_ (u"ࠪࠫ擆"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擇"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ擈")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬ擉"),l11ll1_l1_,641,l11lll_l1_ (u"ࠧࠨ擊"),l11lll_l1_ (u"ࠨࠩ擋"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭擌"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ操"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭擎")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠩ擏"),l11ll1_l1_,641,l11lll_l1_ (u"࠭ࠧ擐"),l11lll_l1_ (u"ࠧࠨ擑"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ擒"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ擓"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ擔"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ擕"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ擖")+l111ll_l1_+title,link,644)
	#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ擗"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ擘"),l11lll_l1_ (u"ࠨࠩ擙"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭據"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ擛"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠫࠬ擜"))
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ擝"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭擞"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ擟")+l111ll_l1_+title,link,644)
	return
def l1l11l_l1_(url):
	l111l1ll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ擠"),url,l11lll_l1_ (u"ࠩࠪ擡"),l11lll_l1_ (u"ࠪࠫ擢"),l11lll_l1_ (u"ࠫࠬ擣"),l11lll_l1_ (u"ࠬ࠭擤"),l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ擥"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ擦"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ擧"),l11lll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ擨"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ擩"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠫࠬ擪"),block)]
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ擫"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ擬"),l11lll_l1_ (u"ࠧࠨ擭"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			l111l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭擮"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬ擯")
			for link,title in l111l1ll1_l1_:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ擰"),l111ll_l1_+title,link,641)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ擱"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ擲"),block,re.DOTALL)
		if len(l1l1lll_l1_)<30:
			if l111l1ll1_l1_: addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ擳"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ擴"),l11lll_l1_ (u"ࠨࠩ擵"),9999)
			for link,title in l1l1lll_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ擶"),l111ll_l1_+title,link,641)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠪࠫ擷")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ擸"),l11lll_l1_ (u"ࠬ࠭擹"),request,url)
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ擺"):
		url,search = url.split(l11lll_l1_ (u"ࠧࡀࠩ擻"),1)
		data = l11lll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ擼")+search
		headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ擽"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ擾")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ擿"),url,data,headers,l11lll_l1_ (u"ࠬ࠭攀"),l11lll_l1_ (u"࠭ࠧ攁"),l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ攂"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ攃"),url,l11lll_l1_ (u"ࠩࠪ攄"),l11lll_l1_ (u"ࠪࠫ攅"),l11lll_l1_ (u"ࠫࠬ攆"),l11lll_l1_ (u"ࠬ࠭攇"),l11lll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ攈"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠧࠨ攉"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ攊"))
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ攋"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ攌"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬ攍"),link,title))
	elif request==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ攎"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ攏"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭攐"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ攑"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭攒"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ攓"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭攔"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ攕"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ攖"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨ攗"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ攘"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ攙"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ攚"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ攛"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ攜"),l11lll_l1_ (u"࠭ใๅ์หࠫ攝"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭攞"),l11lll_l1_ (u"ࠨ้าหๆ࠭攟"),l11lll_l1_ (u"่ࠩฬฬืวสࠩ攠"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧ攡"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫ攢"),l11lll_l1_ (u"ࠬอไษ๊่ࠫ攣"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭攤")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩ攥"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭攦") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ攧")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ攨"))
		#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ攩") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ攪")+l1llll_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨ攫"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ攬"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ攭"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ攮"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ支"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ攰"),l111ll_l1_+title,link,642,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ攱") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭攲"),l111ll_l1_+title,link,643,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ攳") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ攴"),l111ll_l1_+title,link,641,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ攵"),l111ll_l1_+title,link,643,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ收"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭攷")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭攸"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ改"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠧࠤࠩ攺"): continue
				if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭攻") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ攼")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬ攽"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ放"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ政")+title,link,641)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ敀"),l11lll_l1_ (u"ࠧࠨ敁"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ敂"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭敃"),url,l11lll_l1_ (u"ࠪࠫ敄"),l11lll_l1_ (u"ࠫࠬ故"),l11lll_l1_ (u"ࠬ࠭敆"),l11lll_l1_ (u"࠭ࠧ敇"),l11lll_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭效"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ敉"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ敊"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠪࠫ敋")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭敌"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠬࠩࠧ敍"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭敎"),l111ll_l1_+title,url,643,l1llll_l1_,l11lll_l1_ (u"ࠧࠨ敏"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ敐")+l1ll1_l1_+l11lll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ救"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ敒"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		#if not items: items = re.findall(l11lll_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ敓"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ敔") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ敕")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ敖"))
			title = title.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿࠾ࡨࡱࡃ࠭敗"),l11lll_l1_ (u"ࠩࠣࠫ敘"))
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ教"),l111ll_l1_+title,link,642,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ敚"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ敛") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨ敜")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩ敝"))
		#		addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ敞"),l111ll_l1_+title,link,642,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭敟"),l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡥࡸ࠰ࡳ࡬ࡵ࠭敠"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ敡"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭敢"),l11lll_l1_ (u"࠭ࠧ散"),l11lll_l1_ (u"ࠧࠨ敤"),l11lll_l1_ (u"ࠨࠩ敥"),l11lll_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ敦"))
	html = response.content
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ敧"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ敨"),block,re.DOTALL)
		if links:
			link = links[0]
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭敩"))
				l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ敪"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1111llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧ敫"),block,re.DOTALL)
		block = block.replace(l11lll_l1_ (u"ࠨ࡞࡟ࠦࠬ敬"),l11lll_l1_ (u"ࠩࠥࠫ敭")).replace(l11lll_l1_ (u"ࠪࡠ࠴࠭敮"),l11lll_l1_ (u"ࠫ࠴࠭敯"))
		links = re.findall(l11lll_l1_ (u"ࠬࠨ࠼ࡪࡨࡵࡥࡲ࡫࠮ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ数"),block,re.DOTALL)
		if len(l1111llll_l1_)==len(links):
			for id,title in l1111llll_l1_:
				link = links[int(id)]
				if link not in l1111_l1_:
					l1l1l11ll_l1_.append(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ敱")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ敲"))
					l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ敳"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ整"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ敵")+title+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ敶"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ敷"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ數"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ敹"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ敺"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ敻"),l11lll_l1_ (u"ࠪ࠯ࠬ敼"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ敽")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ敾"))
	#url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ敿")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ斀"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
import bs4
script_name = l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ⧱")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡇࡏࡇࡤ࠭⧲")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1ll1111lll_l1_(url)
	elif mode==512: results = l1ll1l1ll1l_l1_(url)
	elif mode==513: results = l1ll1l1ll11_l1_(url)
	elif mode==514: results = l1ll111l11l_l1_(url,l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⧳")+text)
	elif mode==515: results = l1ll111l11l_l1_(url,l11lll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⧴")+text)
	elif mode==516: results = l1ll11ll1l1_l1_(text)
	elif mode==517: results = l1ll1l111ll_l1_(url)
	elif mode==518: results = l1ll1l11l11_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1ll11lll1l_l1_(url)
	elif mode==521: results = l1ll1111ll1_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1ll111ll11_l1_(text)
	elif mode==524: results = l1ll111llll_l1_()
	elif mode==525: results = l1ll1l1l1ll_l1_()
	elif mode==526: results = l1ll11lll11_l1_()
	elif mode==527: results = l1ll11l1111_l1_()
	else: results = False
	return results
def MENU(l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ⧵")):
	if not l1l1ll11_l1_:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⧶"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⧷"),l11lll_l1_ (u"࠭ࠧ⧸"),519)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⧹"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⧺"),l11lll_l1_ (u"ࠩࠪ⧻"),9999)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⧼"),l111ll_l1_+l11lll_l1_ (u"๊ࠫ๎ำ้฻ฬࠤฬ๊รฺ็ส่ࠬ⧽"),l11lll_l1_ (u"ࠬ࠭⧾"),525)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧿"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆฦุำอีࠨ⨀"),l11lll_l1_ (u"ࠨࠩ⨁"),526)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨂"),l111ll_l1_+l11lll_l1_ (u"้ࠪํฺู่หࠣห้๋ี็ใสฮࠬ⨃"),l11lll_l1_ (u"ࠫࠬ⨄"),527)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨅"),l111ll_l1_+l11lll_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅ็้์฾อสࠨ⨆"),l11lll_l1_ (u"ࠧࠨ⨇"),524)
	return
def l1ll111llll_l1_():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨈"),l111ll_l1_+l11lll_l1_ (u"ࠩࠣๅ๏ี๊้้สฮࠥ࠳ࠠฯษุอࠬ⨉"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࠪ⨊"),520)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨋"),l111ll_l1_+l11lll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠ࠮ࠢฦัิัࠧ⨌"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵࡬ࡢࡶࡨࡷࡹ࠭⨍"),521)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨎"),l111ll_l1_+l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษโะ็ࠪ⨏"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࡲࡰࡩ࡫ࡳࡵࠩ⨐"),521)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨑"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡลๆฯึࠦๅีษ๊ำฮ࠭⨒"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡼࡩࡦࡹࡶࠫ⨓"),521)
	return
def l1ll1l1l1ll_l1_():
	l11lll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡹࡿࡰࡦࠢࡀࠤ࠶ࠦࠣࠡࡣࡦࡸࡴࡸࡳࠎࠌࠌࡸࡾࡶࡥࠡ࠿ࠣ࠶ࠥࠩࠠࡷ࡫ࡧࡩࡴࡹࠍࠋࠋࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦ࠱ࠡࠥࠣࡱࡴࡼࡩࡦࡵࠐࠎࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢ࠶ࠤࠨࠦࡳࡦࡴ࡬ࡩࡸࠓࠊࠊࡨࡲࡶࡪ࡯ࡧ࡯ࠢࡀࠤ࡫ࡧ࡬ࡴࡧࠣࠧࠥࡧࡲࡢࡤ࡬ࡧࠒࠐࠉࡧࡱࡵࡩ࡮࡭࡮ࠡ࠿ࠣࡸࡷࡻࡥࠡࠥࠣࡩࡳ࡭࡬ࡪࡵ࡫ࠑࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮๊๋ࠫหๅ์้ࠤศ็ไศ็ࠣ฽ึฮ๊ࠨ࠮࡯࡭ࡳࡱ࠲࠭࠷࠴࠵࠮ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦๅิๆึ่ฬะฺࠠำห๎ࠬ࠲࡬ࡪࡰ࡮࠷࠱࠻࠱࠲ࠫࠐࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ้๊࠭ࠪัไ๋่ࠣวๆ๊วๆࠢสะ๋ฮ๊ࠨ࠮࡯࡭ࡳࡱ࠴࠭࠷࠴࠵࠮ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦๅิๆึ่ฬะࠠศฮ้ฬ๏࠭ࠬ࡭࡫ࡱ࡯࠺࠲࠵࠲࠳ࠬࠑࠏࠏ࡬ࡪࡰ࡮࠵ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠷ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠸ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠸ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫࠒࠐࠉ࡭࡫ࡱ࡯࠹ࠦ࠽ࠡ࡮࡬ࡲࡰ࠶ࠫࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡵࡴࡸࡩࠫࡺࡡࡨ࠿ࠪࠑࠏࠏ࡬ࡪࡰ࡮࠹ࠥࡃࠠ࡭࡫ࡱ࡯࠵࠱ࠧࠧࡶࡼࡴࡪࡃ࠱ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩࠐࠎࠎࠨࠢࠣ⨔")
	l1ll111l1l1_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩ⨕")
	l1ll11l1ll1_l1_ = l1ll111l1l1_l1_+l11lll_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠳ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁ࠶ࠬࡦࡰࡴࡨ࡭࡬ࡴ࠽ࡧࡣ࡯ࡷࡪࠬࡴࡢࡩࡀࠫ⨖")
	l1ll1l1l1l1_l1_ = l1ll111l1l1_l1_+l11lll_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾࠴ࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠹ࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࡨࡤࡰࡸ࡫ࠦࡵࡣࡪࡁࠬ⨗")
	l1ll11l111l_l1_ = l1ll111l1l1_l1_+l11lll_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿࠵ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠱ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬ⨘")
	l1ll11l11l1_l1_ = l1ll111l1l1_l1_+l11lll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭⨙")
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨚"),l111ll_l1_+l11lll_l1_ (u"࠭ๅึ่ไหฯࠦรโๆส้ࠥ฿ัษ์ࠪ⨛"),l1ll11l1ll1_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨜"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ุ๊ๆอสࠡ็ึุ่๊วหࠢ฼ีอ๐ࠧ⨝"),l1ll1l1l1l1_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨞"),l111ll_l1_+l11lll_l1_ (u"ฺ้ࠪ์แศฬࠣวๆ๊วๆࠢสะ๋ฮ๊ࠨ⨟"),l1ll11l111l_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨠"),l111ll_l1_+l11lll_l1_ (u"๋ࠬี็ใสฮ๋ࠥำๅี็หฯࠦวอ่ห๎ࠬ⨡"),l1ll11l11l1_l1_,511)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⨢"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⨣"),l11lll_l1_ (u"ࠨࠩ⨤"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨥"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ์ืำࠡล฼้ฬ๊ࠠฤสฯำ๏࠭⨦"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡼࡵࡲ࡬࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫ⨧"),517)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⨨"),l111ll_l1_+l11lll_l1_ (u"࠭แ่ำึࠤࠥฮไะࠢส่ส์สศฮࠪ⨩"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡩ࡯ࡶࡰࡷࡶࡾ࠭⨪"),517)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⨫"),l111ll_l1_+l11lll_l1_ (u"ࠩไ๋ึูࠠศๆ็฾ฮ࠭⨬"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ⨭"),517)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⨮"),l111ll_l1_+l11lll_l1_ (u"ࠬ็็าีฺ้ࠣ์แศฬࠣห้฿ๅๅࠩ⨯"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳࡬࡫࡮ࡳࡧࠪ⨰"),517)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨱"),l111ll_l1_+l11lll_l1_ (u"ࠨใ๊ีุࠦำ็หࠣห้หีะษิࠫ⨲"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡳࡧ࡯ࡩࡦࡹࡥࡠࡻࡨࡥࡷ࠭⨳"),517)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⨴"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠲ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠶ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⨵"),l11lll_l1_ (u"ࠬ࠭⨶"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⨷"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊สื๊ࠦ࠭ࠡใ็ฮึࠦๅฮัาࠫ⨸"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡣ࡯ࡷࠬ⨹"),515)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⨺"),l111ll_l1_+l11lll_l1_ (u"้ࠪํอำๆࠢ࠰ࠤๆ๊สาࠢๆห๊๊ࠧ⨻"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ⨼"),514)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⨽"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠵ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠹࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⨾"),l11lll_l1_ (u"ࠧࠨ⨿"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩀"),l111ll_l1_+l11lll_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ⩁"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ⩂"),515)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩃"),l111ll_l1_+l11lll_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ⩄"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ⩅"),514)
	return
def l1ll11l1111_l1_():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⩆"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ⩇"),l11lll_l1_ (u"ࠩࠪ⩈"),l11lll_l1_ (u"ࠪࠫ⩉"),l11lll_l1_ (u"ࠫࠬ⩊"),l11lll_l1_ (u"ࠬ࠭⩋"),l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⩌"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⩍"),multi_valued_attributes=None)
	block = l1ll1111l1l_l1_.find(l11lll_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴࠨ⩎"),attrs={l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ⩏"):l11lll_l1_ (u"ࠪࡸࡦ࡭ࠧ⩐")})	# <select name=l11lll_l1_ (u"ࠫࡹࡧࡧࠨ⩑")>
	options = block.find_all(l11lll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠬ⩒"))
	for option in options:
		value = option.get(l11lll_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ⩓"))		# or option[l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭⩔")] l1l1l1ll1l_l1_ it will l1ll1l11l1l_l1_ if not l1ll1l11lll_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⩕"))
			value = value.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⩖"))
		link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠫࡺࡹࡱࡧࡀࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧ⩗")+value
		title = title.replace(l11lll_l1_ (u"ࠫ็อฦๆหࠣࠫ⩘"),l11lll_l1_ (u"ࠬ࠭⩙"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⩚"),l111ll_l1_+title,link,511)
	return
def l1ll11lll11_l1_():
	l1ll111l1l1_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡮࡬ࡲࡪࡻࡰࡀࡷࡷࡪ࠽ࡃࠥࡆ࠴ࠨ࠽ࡈࠫ࠹࠴ࠩ⩛")
	l1ll11l1l1l_l1_ = l1ll111l1l1_l1_+l11lll_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽࠲ࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࠦࡵࡣࡪࡁࠬ⩜")
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩝"),l111ll_l1_+l11lll_l1_ (u"ฺ้ࠪ์แศฬࠣวูิวึࠩ⩞"),l1ll11l1l1l_l1_,511)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⩟"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠶ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⩠"),l11lll_l1_ (u"࠭ࠧ⩡"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⩢"),l111ll_l1_+l11lll_l1_ (u"ࠨใ๊ีุࠦรีะสูࠥษศอัํࠫ⩣"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡤࡰࡵ࡮ࡡࡣࡧࡷࠫ⩤"),517)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⩥"),l111ll_l1_+l11lll_l1_ (u"ࠫๆํัิ่ࠢ์฼์ࠧ⩦"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡴࡡࡵ࡫ࡲࡲࡦࡲࡩࡵࡻࠪ⩧"),517)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⩨"),l111ll_l1_+l11lll_l1_ (u"ࠧโ้ิืࠥࠦสศำําࠥอไๆ์็หิ࠭⩩"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡤ࡬ࡶࡹ࡮࡟ࡺࡧࡤࡶࠬ⩪"),517)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⩫"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ์ืำࠡࠢอหึ๐ฮࠡษ็์ๆอษࠨ⩬"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡩ࡫ࡡࡵࡪࡢࡽࡪࡧࡲࠨ⩭"),517)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⩮"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠸࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⩯"),l11lll_l1_ (u"ࠧࠨ⩰"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⩱"),l111ll_l1_+l11lll_l1_ (u"ู่๋ࠩ็วหࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ⩲"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ⩳"),515)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⩴"),l111ll_l1_+l11lll_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ⩵"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ⩶"),514)
	return
def l1ll1111lll_l1_(url):
	if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ⩷") in url: index = 0
	elif l11lll_l1_ (u"ࠨ࠱࡯࡭ࡳ࡫ࡵࡱࠩ⩸") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⩹"),url,l11lll_l1_ (u"ࠪࠫ⩺"),l11lll_l1_ (u"ࠫࠬ⩻"),l11lll_l1_ (u"ࠬ࠭⩼"),l11lll_l1_ (u"࠭ࠧ⩽"),l11lll_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡏࡍࡘ࡚ࡓ࠮࠳ࡶࡸࠬ⩾"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭⩿"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111l1l_l1_.find_all(class_=l11lll_l1_ (u"ࠩ࡭ࡹࡲࡨ࡯࠮ࡶ࡫ࡩࡦࡺࡥࡳࠢࡦࡰࡪࡧࡲࡧ࡫ࡻࠫ⪀"))
	for block in l111l11_l1_:
		title = block.find_all(l11lll_l1_ (u"ࠪࡥࠬ⪁"))[index].text
		link = l11ll1_l1_+block.find_all(l11lll_l1_ (u"ࠫࡦ࠭⪂"))[index].get(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࠪ⪃"))
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⪄"))
			link = link.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⪅"))
		if not l111l11_l1_:
			l1ll1l1ll1l_l1_(link)
			return
		else:
			title = title.replace(l11lll_l1_ (u"ࠨไสส๊ฯࠠࠨ⪆"),l11lll_l1_ (u"ࠩࠪ⪇"))
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪈"),l111ll_l1_+title,link,512)
	PAGINATION(l1ll1111l1l_l1_,511)
	return
def PAGINATION(l1ll1111l1l_l1_,mode):
	block = l1ll1111l1l_l1_.find(class_=l11lll_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ⪉"))
	if block:
		l1l1ll11l_l1_ = block.find_all(l11lll_l1_ (u"ࠬࡧࠧ⪊"))
		l1ll1111l11_l1_ = block.find_all(l11lll_l1_ (u"࠭࡬ࡪࠩ⪋"))
		l1ll11ll1ll_l1_ = list(zip(l1l1ll11l_l1_,l1ll1111l11_l1_))
		l11l1lllll_l1_ = -1
		length = len(l1ll11ll1ll_l1_)
		for l1ll11l1l_l1_,l1ll111l1ll_l1_ in l1ll11ll1ll_l1_:
			l11l1lllll_l1_ += 1
			l1ll111l1ll_l1_ = l1ll111l1ll_l1_[l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭⪌")]
			if l11lll_l1_ (u"ࠨࡷࡱࡥࡻࡧࡩ࡭ࡣࡥࡰࡪ࠭⪍") in l1ll111l1ll_l1_ or l11lll_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࠪ⪎") in l1ll111l1ll_l1_: continue
			l1ll111lll1_l1_ = l1ll11l1l_l1_.text
			l1lllllll1_l1_ = l11ll1_l1_+l1ll11l1l_l1_.get(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ⪏"))
			if kodi_version<19:
				l1ll111lll1_l1_ = l1ll111lll1_l1_.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⪐"))
				l1lllllll1_l1_ = l1lllllll1_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⪑"))
			if   l11l1lllll_l1_==0: l1ll111lll1_l1_ = l11lll_l1_ (u"࠭ร้ๆ์ࠫ⪒")
			elif l11l1lllll_l1_==1: l1ll111lll1_l1_ = l11lll_l1_ (u"ࠧิษหๆฮ࠭⪓")
			elif l11l1lllll_l1_==length-2: l1ll111lll1_l1_ = l11lll_l1_ (u"ࠨๆสั็ฯࠧ⪔")
			elif l11l1lllll_l1_==length-1: l1ll111lll1_l1_ = l11lll_l1_ (u"ࠩฦา๏ืษࠨ⪕")
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⪖"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ⪗")+l1ll111lll1_l1_,l1lllllll1_l1_,mode)
	return
def l1ll1l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⪘"),url,l11lll_l1_ (u"࠭ࠧ⪙"),l11lll_l1_ (u"ࠧࠨ⪚"),l11lll_l1_ (u"ࠨࠩ⪛"),l11lll_l1_ (u"ࠩࠪ⪜"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠶࠳࠱ࡴࡶࠪ⪝"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⪞"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111l1l_l1_.find_all(class_=l11lll_l1_ (u"ࠬࡸ࡯ࡸࠩ⪟"))
	items,first = [],True
	for block in l111l11_l1_:
		if not block.find(class_=l11lll_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯ࡺࡶࡦࡶࡰࡦࡴࠪ⪠")): continue
		if first: first = False ; continue
		l1ll1l111l1_l1_ = []
		l1ll11111ll_l1_ = block.find_all(class_=[l11lll_l1_ (u"ࠧࡤࡧࡱࡷࡴࡸࡳࡩ࡫ࡳࠤࡷ࡫ࡤࠨ⪡"),l11lll_l1_ (u"ࠨࡥࡨࡲࡸࡵࡲࡴࡪ࡬ࡴࠥࡶࡵࡳࡲ࡯ࡩࠬ⪢")])
		for l1ll111ll1l_l1_ in l1ll11111ll_l1_:
			l1ll1ll111_l1_ = l1ll111ll1l_l1_.find_all(l11lll_l1_ (u"ࠩ࡯࡭ࠬ⪣"))[1].text
			if kodi_version<19:
				l1ll1ll111_l1_ = l1ll1ll111_l1_.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⪤"))
			l1ll1l111l1_l1_.append(l1ll1ll111_l1_)
		if not l11ll11_l1_(script_name,l11lll_l1_ (u"ࠫࠬ⪥"),l1ll1l111l1_l1_,False):
			l11l_l1_ = block.find(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠩ⪦")).get(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ⪧"))
			title = block.find(l11lll_l1_ (u"ࠧࡩ࠵ࠪ⪨"))
			name = title.find(l11lll_l1_ (u"ࠨࡣࠪ⪩")).text
			link = l11ll1_l1_+title.find(l11lll_l1_ (u"ࠩࡤࠫ⪪")).get(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ⪫"))
			l1ll11l11ll_l1_ = block.find(class_=l11lll_l1_ (u"ࠫࡳࡵ࠭࡮ࡣࡵ࡫࡮ࡴࠧ⪬"))
			l1ll11l1l11_l1_ = block.find(class_=l11lll_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬ⪭"))
			if l1ll11l11ll_l1_: l1ll11l11ll_l1_ = l1ll11l11ll_l1_.text
			if l1ll11l1l11_l1_: l1ll11l1l11_l1_ = l1ll11l1l11_l1_.text
			if kodi_version<19:
				l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⪮"))
				name = name.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⪯"))
				link = link.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⪰"))
				if l1ll11l11ll_l1_: l1ll11l11ll_l1_ = l1ll11l11ll_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⪱"))
			l1ll111l111_l1_ = {}
			if l1ll11l1l11_l1_: l1ll111l111_l1_[l11lll_l1_ (u"ࠪࡷࡹࡧࡲࡴࠩ⪲")] = l1ll11l1l11_l1_
			if l1ll11l11ll_l1_:
				l1ll11l11ll_l1_ = l1ll11l11ll_l1_.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ⪳"),l11lll_l1_ (u"ࠬࠦ࠮࠯ࠢࠪ⪴"))
				l1ll111l111_l1_[l11lll_l1_ (u"࠭ࡰ࡭ࡱࡷࠫ⪵")] = l1ll11l11ll_l1_.replace(l11lll_l1_ (u"ࠧ࠯࠰࠱ห็ืรࠡษ็้ื๐ฯࠨ⪶"),l11lll_l1_ (u"ࠨࠩ⪷"))
			if l11lll_l1_ (u"ࠩ࠲ࡻࡴࡸ࡫࠰ࠩ⪸") in link:
				#name = l11lll_l1_ (u"ࠪฬาัฺ่ࠠࠣࠫ⪹")+name
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⪺"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"ࠬ࠭⪻"),name,l11lll_l1_ (u"࠭ࠧ⪼"),l1ll111l111_l1_)
			elif l11lll_l1_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ⪽") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⪾"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"ࠩࠪ⪿"),name,l11lll_l1_ (u"ࠪࠫ⫀"),l1ll111l111_l1_)
	PAGINATION(l1ll1111l1l_l1_,512)
	return
def l1ll1l1ll11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⫁"),url,l11lll_l1_ (u"ࠬ࠭⫂"),l11lll_l1_ (u"࠭ࠧ⫃"),l11lll_l1_ (u"ࠧࠨ⫄"),l11lll_l1_ (u"ࠨࠩ⫅"),l11lll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠶࠲࠷ࡳࡵࠩ⫆"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⫇"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111l1l_l1_.find_all(l11lll_l1_ (u"ࠫࡱ࡯ࠧ⫈"))
	names,items = [],[]
	for block in l111l11_l1_:
		if not block.find(class_=l11lll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬࠮ࡹࡵࡥࡵࡶࡥࡳࠩ⫉")): continue
		if not block.find(class_=[l11lll_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠨ⫊"),l11lll_l1_ (u"ࠧࡶࡰࡶࡸࡾࡲࡥࡥࠢࡷࡩࡽࡺ࠭ࡤࡧࡱࡸࡪࡸࠧ⫋")]): continue
		if block.find(class_=l11lll_l1_ (u"ࠨࡪ࡬ࡨࡪ࠭⫌")): continue
		title = block.find(class_=[l11lll_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠫ⫍"),l11lll_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠥࡺࡥࡹࡶ࠰ࡧࡪࡴࡴࡦࡴࠪ⫎")])
		name = title.find(l11lll_l1_ (u"ࠫࡦ࠭⫏")).text
		if name in names: continue
		names.append(name)
		link = l11ll1_l1_+title.find(l11lll_l1_ (u"ࠬࡧࠧ⫐")).get(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࠫ⫑"))
		if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ⫒") in url: l11l_l1_ = block.find(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⫓")).get(l11lll_l1_ (u"ࠩࡶࡶࡨ࠭⫔"))
		elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⫕") in url: l11l_l1_ = block.find(l11lll_l1_ (u"ࠫ࡮ࡳࡧࠨ⫖")).get(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ⫗"))
		elif l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ⫘") in url: l11l_l1_ = block.find(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠫ⫙")).get(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ⫚"))
		else: l11l_l1_ = block.find(l11lll_l1_ (u"ࠩ࡬ࡱ࡬࠭⫛")).get(l11lll_l1_ (u"ࠪࡷࡷࡩࠧ⫝̸"))
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⫝"))
			link = link.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⫞"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⫟"))
		name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ⫠"))
		items.append((name,link,l11l_l1_))
	if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⫡") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,link,l11l_l1_ in items:
		if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ⫢") in url: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⫣"),l111ll_l1_+name,link,522,l11l_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭⫤") in url: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⫥"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"࠭ࠧ⫦"),name)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⫧"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"ࠨࠩ⫨"),name)
	return
def l1ll11ll1l1_l1_(text):
	text = text.replace(l11lll_l1_ (u"ࠩส่ส฿ไศ่ࠪ⫩"),l11lll_l1_ (u"ࠪࠫ⫪")).replace(l11lll_l1_ (u"้ࠫ็๊ๅ็ࠪ⫫"),l11lll_l1_ (u"ࠬ࠭⫬")).replace(l11lll_l1_ (u"࠭วๅำึ้๏࠭⫭"),l11lll_l1_ (u"ࠧࠨ⫮"))
	text = text.replace(l11lll_l1_ (u"ࠨว฼่ฬ์ࠧ⫯"),l11lll_l1_ (u"ࠩࠪ⫰")).replace(l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ⫱"),l11lll_l1_ (u"ࠫࠬ⫲")).replace(l11lll_l1_ (u"ࠬอไษำ๋้ํ࠭⫳"),l11lll_l1_ (u"࠭ࠧ⫴"))
	text = text.replace(l11lll_l1_ (u"ࠧศๆอุํ๐โ๋ࠩ⫵"),l11lll_l1_ (u"ࠨࠩ⫶")).replace(l11lll_l1_ (u"ࠩ็ุ้๊ำๅࠩ⫷"),l11lll_l1_ (u"ࠪࠫ⫸")).replace(l11lll_l1_ (u"ู๊ࠫไิๆࠪ⫹"),l11lll_l1_ (u"ࠬ࠭⫺"))
	text = text.replace(l11lll_l1_ (u"࠭࠺ࠨ⫻"),l11lll_l1_ (u"ࠧࠨ⫼")).replace(l11lll_l1_ (u"ࠨࠫࠪ⫽"),l11lll_l1_ (u"ࠩࠪ⫾")).replace(l11lll_l1_ (u"ࠪࠬࠬ⫿"),l11lll_l1_ (u"ࠫࠬ⬀")).replace(l11lll_l1_ (u"ࠬ࠲ࠧ⬁"),l11lll_l1_ (u"࠭ࠧ⬂"))
	text = text.replace(l11lll_l1_ (u"ࠧࡠࠩ⬃"),l11lll_l1_ (u"ࠨࠩ⬄")).replace(l11lll_l1_ (u"ࠩ࠾ࠫ⬅"),l11lll_l1_ (u"ࠪࠫ⬆")).replace(l11lll_l1_ (u"ࠫ࠲࠭⬇"),l11lll_l1_ (u"ࠬ࠭⬈")).replace(l11lll_l1_ (u"࠭࠮ࠨ⬉"),l11lll_l1_ (u"ࠧࠨ⬊"))
	text = text.replace(l11lll_l1_ (u"ࠨ࡞ࠪࠫ⬋"),l11lll_l1_ (u"ࠩࠪ⬌")).replace(l11lll_l1_ (u"ࠪࡠࠧ࠭⬍"),l11lll_l1_ (u"ࠫࠬ⬎"))
	text = text.replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ⬏"),l11lll_l1_ (u"࠭ࠠࠨ⬐")).replace(l11lll_l1_ (u"ࠧࠡࠢࠣࠫ⬑"),l11lll_l1_ (u"ࠨࠢࠪ⬒")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ⬓"),l11lll_l1_ (u"ࠪࠤࠬ⬔"))
	text = text.strip(l11lll_l1_ (u"ࠫࠥ࠭⬕"))
	l1ll1l1l11l_l1_ = text.count(l11lll_l1_ (u"ࠬࠦࠧ⬖"))+1
	if l1ll1l1l11l_l1_==1:
		l1ll111ll11_l1_(text)
		return
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⬗"),l111ll_l1_+l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃࠠไๆ่หฯࠦไๅสะฯࠥࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⬘"),l11lll_l1_ (u"ࠨࠩ⬙"),9999)
	l1ll11ll111_l1_ = text.split(l11lll_l1_ (u"ࠩࠣࠫ⬚"))
	l1ll1l1l111_l1_ = pow(2,l1ll1l1l11l_l1_)
	l1ll11lllll_l1_ = []
	def l1ll11l1lll_l1_(a,b):
		if a==l11lll_l1_ (u"ࠪ࠵ࠬ⬛"): return b
		return l11lll_l1_ (u"ࠫࠬ⬜")
	for l11l1lllll_l1_ in range(l1ll1l1l111_l1_,0,-1):
		l1ll11llll1_l1_ = list(l1ll1l1l11l_l1_*l11lll_l1_ (u"ࠬ࠶ࠧ⬝")+bin(l11l1lllll_l1_)[2:])[-l1ll1l1l11l_l1_:]
		l1ll11llll1_l1_ = reversed(l1ll11llll1_l1_)
		result = map(l1ll11l1lll_l1_,l1ll11llll1_l1_,l1ll11ll111_l1_)
		title = l11lll_l1_ (u"࠭ࠠࠨ⬞").join(filter(None,result))
		if kodi_version<19: l1lll1lll_l1_ = title.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⬟"))
		else: l1lll1lll_l1_ = title
		if len(l1lll1lll_l1_)>2 and title not in l1ll11lllll_l1_:
			l1ll11lllll_l1_.append(title)
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⬠"),l111ll_l1_+title,l11lll_l1_ (u"ࠩࠪ⬡"),523,l11lll_l1_ (u"ࠪࠫ⬢"),l11lll_l1_ (u"ࠫࠬ⬣"),title)
	return
def l1ll111ll11_l1_(l1ll1l11ll1_l1_):
	if kodi_version<19:
		l1ll1l11ll1_l1_ = l1ll1l11ll1_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⬤"))
		import arabic_reshaper
		l1ll1l11ll1_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1ll1l11ll1_l1_)
		l1ll1l11ll1_l1_ = bidi.algorithm.get_display(l1ll1l11ll1_l1_)
	import l1ll1l1111l_l1_
	l1ll1l11ll1_l1_ = OPEN_KEYBOARD(default=l1ll1l11ll1_l1_)
	l1ll1l1111l_l1_.SEARCH(l1ll1l11ll1_l1_)
	return
def l1ll1l111ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⬥"),url,l11lll_l1_ (u"ࠧࠨ⬦"),l11lll_l1_ (u"ࠨࠩ⬧"),l11lll_l1_ (u"ࠩࠪ⬨"),l11lll_l1_ (u"ࠪࠫ⬩"),l11lll_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡍࡋࡖࡘࡘ࠳࠱ࡴࡶࠪ⬪"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⬫"),multi_valued_attributes=None)
	block = l1ll1111l1l_l1_.find(class_=l11lll_l1_ (u"࠭࡬ࡪࡵࡷ࠱ࡸ࡫ࡰࡢࡴࡤࡸࡴࡸࠠ࡭࡫ࡶࡸ࠲ࡺࡩࡵ࡮ࡨࠫ⬬"))
	l1l111_l1_ = block.find_all(l11lll_l1_ (u"ࠧࡢࠩ⬭"))
	items = []
	for title in l1l111_l1_:
		name = title.text
		link = l11ll1_l1_+title.get(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫࠭⬮"))
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⬯"))
			link = link.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⬰"))
		if l11lll_l1_ (u"ࠫࠨ࠭⬱") not in link: items.append((name,link))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,link = item
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⬲"),l111ll_l1_+name,link,518)
	return
def l1ll1l11l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⬳"),url,l11lll_l1_ (u"ࠧࠨ⬴"),l11lll_l1_ (u"ࠨࠩ⬵"),l11lll_l1_ (u"ࠩࠪ⬶"),l11lll_l1_ (u"ࠪࠫ⬷"),l11lll_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡉࡏࡆࡈ࡜ࡊ࡙࡟ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⬸"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ⬹"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111l1l_l1_.find(class_=l11lll_l1_ (u"࠭ࡥࡹࡲࡤࡲࡩ࠭⬺")).find_all(l11lll_l1_ (u"ࠧࡵࡴࠪ⬻"))
	for block in l111l11_l1_:
		l1ll11ll11l_l1_ = block.find_all(l11lll_l1_ (u"ࠨࡣࠪ⬼"))
		if not l1ll11ll11l_l1_: continue
		l11l_l1_ = block.find(l11lll_l1_ (u"ࠩ࡬ࡱ࡬࠭⬽")).get(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡵࡧࠬ⬾"))
		name = l1ll11ll11l_l1_[1].text
		link = l11ll1_l1_+l1ll11ll11l_l1_[1].get(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ⬿"))
		l1ll11l1l11_l1_ = block.find(class_=l11lll_l1_ (u"ࠬࡲࡥࡨࡧࡱࡨࠬ⭀"))
		if l1ll11l1l11_l1_: l1ll11l1l11_l1_ = l1ll11l1l11_l1_.text
		if kodi_version<19:
			name = name.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⭁"))
			link = link.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⭂"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⭃"))
		l1ll111l111_l1_ = {}
		if l1ll11l1l11_l1_: l1ll111l111_l1_[l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡳࠨ⭄")] = l1ll11l1l11_l1_
		if l11lll_l1_ (u"ࠪ࠳ࡼࡵࡲ࡬࠱ࠪ⭅") in link:
			#name = l11lll_l1_ (u"ࠫอำหࠡ฻้ࠤࠬ⭆")+name
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭇"),l111ll_l1_+name,link,516,l11l_l1_,l11lll_l1_ (u"࠭ࠧ⭈"),name,l11lll_l1_ (u"ࠧࠨ⭉"),l1ll111l111_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࠪ⭊") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭋"),l111ll_l1_+name,link,513,l11l_l1_,l11lll_l1_ (u"ࠪࠫ⭌"),name,l11lll_l1_ (u"ࠫࠬ⭍"),l1ll111l111_l1_)
	PAGINATION(l1ll1111l1l_l1_,518)
	return
def l1ll11lll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⭎"),url,l11lll_l1_ (u"࠭ࠧ⭏"),l11lll_l1_ (u"ࠧࠨ⭐"),l11lll_l1_ (u"ࠨࠩ⭑"),l11lll_l1_ (u"ࠩࠪ⭒"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡜ࡉࡅࡇࡒࡗࡤࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨ⭓"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⭔"),multi_valued_attributes=None)
	l1l111_l1_ = l1ll1111l1l_l1_.find_all(class_=l11lll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡴࡪࡶ࡯ࡩࠥ࡯࡮࡭࡫ࡱࡩࠬ⭕"))
	links = l1ll1111l1l_l1_.find_all(class_=l11lll_l1_ (u"࠭ࡢࡶࡶࡷࡳࡳࠦࡧࡳࡧࡨࡲࠥࡹ࡭ࡢ࡮࡯ࠤࡷ࡯ࡧࡩࡶࠪ⭖"))
	items = zip(l1l111_l1_,links)
	for title,link in items:
		title = title.text
		link = l11ll1_l1_+link.get(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࠬ⭗"))
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⭘"))
			link = link.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⭙"))
		title = title.replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ⭚"),l11lll_l1_ (u"ࠫࠥ࠭⭛")).replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠩ⭜"),l11lll_l1_ (u"࠭ࠠࠨ⭝")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ⭞"),l11lll_l1_ (u"ࠨࠢࠪ⭟"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭠"),l111ll_l1_+title,link,521)
	return
def l1ll1111ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⭡"),url,l11lll_l1_ (u"ࠫࠬ⭢"),l11lll_l1_ (u"ࠬ࠭⭣"),l11lll_l1_ (u"࠭ࠧ⭤"),l11lll_l1_ (u"ࠧࠨ⭥"),l11lll_l1_ (u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃ࠰࡚ࡎࡊࡅࡐࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⭦"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠩ࡫ࡸࡲࡲ࠮ࡱࡣࡵࡷࡪࡸࠧ⭧"),multi_valued_attributes=None)
	l1ll1l1lll1_l1_ = l1ll1111l1l_l1_.find(class_=l11lll_l1_ (u"ࠪࡰࡦࡸࡧࡦ࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠴ࠡ࡯ࡨࡨ࡮ࡻ࡭࠮ࡤ࡯ࡳࡨࡱ࠭ࡨࡴ࡬ࡨ࠲࠺ࠠࡴ࡯ࡤࡰࡱ࠳ࡢ࡭ࡱࡦ࡯࠲࡭ࡲࡪࡦ࠰࠶ࠬ⭨"))
	l111l11_l1_ = l1ll1l1lll1_l1_.find_all(l11lll_l1_ (u"ࠫࡱ࡯ࠧ⭩"))
	for block in l111l11_l1_:
		title = block.find(class_=l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ⭪")).text
		link = l11ll1_l1_+block.find(l11lll_l1_ (u"࠭ࡡࠨ⭫")).get(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࠬ⭬"))
		l11l_l1_ = block.find(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ⭭")).get(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ⭮"))
		l1l111l1ll_l1_ = block.find(class_=l11lll_l1_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ⭯")).text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⭰"))
			link = link.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⭱"))
			l11l_l1_ = l11l_l1_.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ⭲"))
			l1l111l1ll_l1_ = l1l111l1ll_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⭳"))
		l1l111l1ll_l1_ = l1l111l1ll_l1_.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ⭴"),l11lll_l1_ (u"ࠩࠪ⭵")).strip(l11lll_l1_ (u"ࠪࠤࠬ⭶"))
		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⭷"),l111ll_l1_+title,link,522,l11l_l1_,l1l111l1ll_l1_)
	PAGINATION(l1ll1111l1l_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⭸"),url,l11lll_l1_ (u"࠭ࠧ⭹"),l11lll_l1_ (u"ࠧࠨ⭺"),l11lll_l1_ (u"ࠨࠩ⭻"),l11lll_l1_ (u"ࠩࠪ⭼"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⭽"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ⭾"),multi_valued_attributes=None)
	link = l1ll1111l1l_l1_.find(class_=l11lll_l1_ (u"ࠬ࡬࡬ࡦࡺ࠰ࡺ࡮ࡪࡥࡰࠩ⭿")).find(l11lll_l1_ (u"࠭ࡩࡧࡴࡤࡱࡪ࠭⮀")).get(l11lll_l1_ (u"ࠧࡴࡴࡦࠫ⮁"))
	if kodi_version<19: link = link.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭⮂"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⮃"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ⮄"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ⮅"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ⮆"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ⮇"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡁࡴࡁࠬ⮈")+search
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⮉"),url,l11lll_l1_ (u"ࠩࠪ⮊"),l11lll_l1_ (u"ࠪࠫ⮋"),l11lll_l1_ (u"ࠫࠬ⮌"),l11lll_l1_ (u"ࠬ࠭⮍"),l11lll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ⮎"))
	html = response.content
	l1ll1111l1l_l1_ = bs4.BeautifulSoup(html,l11lll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⮏"),multi_valued_attributes=None)
	l111l11_l1_ = l1ll1111l1l_l1_.find_all(class_=l11lll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡮ࡨࡪࡹ࠭⮐"))
	for block in l111l11_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⮑"))
		title = title.split(l11lll_l1_ (u"ࠪࠬࠬ⮒"),1)[0].strip(l11lll_l1_ (u"ࠫࠥ࠭⮓"))
		if   l11lll_l1_ (u"ࠬษูๆษ็ࠫ⮔") in title: link = url.replace(l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ⮕"),l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡹࡲࡶࡰ࠵ࠧ⮖"))
		elif l11lll_l1_ (u"ࠨลืาฬ฻ࠧ⮗") in title: link = url.replace(l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⮘"),l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ⮙"))
		#elif l11lll_l1_ (u"ࠫศำฯศอࠪ⮚") in title: link = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⮛"),l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡦࡸࡨࡲࡹ࠵ࠧ⮜"))
		#elif l11lll_l1_ (u"ࠧๆ้ิะฬ์วหࠩ⮝") in title: link = url.replace(l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⮞"),l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡪࡪࡹࡴࡪࡸࡤࡰ࠴࠭⮟"))
		elif l11lll_l1_ (u"ࠪๅ๏ี๊้้สฮࠬ⮠") in title: link = url.replace(l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⮡"),l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭⮢"))
		#elif l11lll_l1_ (u"࠭รฯสสีࠬ⮣") in title: link = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⮤"),l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡷࡳࡵ࡯ࡣ࠰ࠩ⮥"))
		else: continue
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮦"),l111ll_l1_+title,link,513)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l1ll111l11l_l1_(url,text):
	global l1l11lll_l1_,l1ll11ll_l1_
	if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ⮧") in url:
		l1l11lll_l1_ = [l11lll_l1_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡥࡱ࠭⮨"),l11lll_l1_ (u"ࠬࡿࡥࡢࡴࠪ⮩"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ⮪")]
		l1ll11ll_l1_ = [l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ⮫"),l11lll_l1_ (u"ࠨࡻࡨࡥࡷ࠭⮬"),l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⮭")]
	elif l11lll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࠫ⮮") in url:
		l1l11lll_l1_ = [l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⮯"),l11lll_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭⮰"),l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ⮱")]
		l1ll11ll_l1_ = [l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⮲"),l11lll_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⮳"),l11lll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⮴")]
	l1lll1l1_l1_(url,text)
	return
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⮵"))[0]
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ⮶"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⮷"),url,l11lll_l1_ (u"࠭ࠧ⮸"),l11lll_l1_ (u"ࠧࠨ⮹"),l11lll_l1_ (u"ࠨࠩ⮺"),l11lll_l1_ (u"ࠩࠪ⮻"),l11lll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧ⮼"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࠢࡤࡧࡹ࡯࡯࡯࠿ࠥ࠳࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ⮽"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + category + options block
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹࠦ࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⮾"),block,re.DOTALL)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# value + name
	items = re.findall(l11lll_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⮿"),block,re.DOTALL)
	return items
def l111111ll_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠧࡤࡣࡷࡁࠬ⯀"),l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ⯁"))
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⯂"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ⯃"))
	#url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⯄"),l11lll_l1_ (u"ࠬ࠵࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࠩ⯅"))
	return url
def l11111ll11_l1_(l1l1llll_l1_,url):
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⯆")) # l1llllll1l1_l1_ be l1llllllll1_l1_
	l11l1l1_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⯇")+l1l1111l_l1_
	l11l1l1_l1_ = l111111ll_l1_(l11l1l1_l1_)
	return l11l1l1_l1_
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⯈"),l11lll_l1_ (u"ࠩࠪ⯉"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⯊"),l11lll_l1_ (u"ࠫࠬ⯋"),filter,url)
	if l11lll_l1_ (u"ࠬࡅࠧ⯌") in url: url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⯍"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⯎"),1)
	if filter==l11lll_l1_ (u"ࠨࠩ⯏"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠩࠪ⯐"),l11lll_l1_ (u"ࠪࠫ⯑")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⯒"))
	if type==l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⯓"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"࠭࠽ࠨ⯔") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠧ࠾ࠩ⯕") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⯖")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⯗")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⯘")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⯙")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⯚"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⯛")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⯜"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⯝")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⯞")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⯟"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⯠")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠬ࠭⯡"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⯢")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		if l1l11l11_l1_==l11lll_l1_ (u"ࠧࠨ⯣"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⯤")+l1l11l11_l1_
		l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯥"),l111ll_l1_+l11lll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭⯦"),l11l11l_l1_,511)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⯧"),l111ll_l1_+l11lll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ⯨")+l11lll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ⯩"),l11l11l_l1_,511)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⯪"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⯫"),l11lll_l1_ (u"ࠩࠪ⯬"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠪ࠱࠲࠭⯭"),l11lll_l1_ (u"ࠫࠬ⯮"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧ⯯") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ⯰"):
			if l1ll1lll_l1_ not in l1l11lll_l1_: continue
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l111111ll_l1_(url)
					l1ll1l1ll1l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⯱")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⯲"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩ⯳"),l11l11l_l1_,511)
				else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯴"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ⯵"),l11l11l_l1_,515,l11lll_l1_ (u"ࠬ࠭⯶"),l11lll_l1_ (u"࠭ࠧ⯷"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ⯸"):
			if l1ll1lll_l1_ not in l1ll11ll_l1_: continue
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ⯹")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⯺")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ⯻")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⯼")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⯽")+l1l1llll_l1_
			if   name==l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ⯾"): name = l11lll_l1_ (u"ࠧศๆ้์฾࠭⯿")
			elif name==l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪⰀ"): name = l11lll_l1_ (u"ࠩส่฾๋ไࠨⰁ")
			elif name==l11lll_l1_ (u"ࠪࡪࡴࡸࡥࡪࡩࡱࠫⰂ"): name = l11lll_l1_ (u"ࠫฬ๊ไ฻หࠪⰃ")
			elif name==l11lll_l1_ (u"ࠬࡿࡥࡢࡴࠪⰄ"): name = l11lll_l1_ (u"࠭วๅี้อࠬⰅ")
			elif name==l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩⰆ"): name = l11lll_l1_ (u"ࠨษ็้ํูๅࠨⰇ")
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⰈ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻࠽ࠤࠬⰉ")+name,l11l11l_l1_,514,l11lll_l1_ (u"ࠫࠬⰊ"),l11lll_l1_ (u"ࠬ࠭Ⰻ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨⰌ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠧๆื้ๅฬะࠠฤะิํࠬⰍ") in option: continue
			if l11lll_l1_ (u"ࠨษ็็้࠭Ⰾ") in option: continue
			if l11lll_l1_ (u"ࠩส่้เษࠨⰏ") in option: continue
			option = option.replace(l11lll_l1_ (u"ࠪๆฬฬๅสࠢࠪⰐ"),l11lll_l1_ (u"ࠫࠬⰑ"))
			if   name==l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪⰒ"): name = l11lll_l1_ (u"࠭วๅ่๋฽ࠬⰓ")
			elif name==l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩⰔ"): name = l11lll_l1_ (u"ࠨษ็฽๊๊ࠧⰕ")
			elif name==l11lll_l1_ (u"ࠩࡩࡳࡷ࡫ࡩࡨࡰࠪⰖ"): name = l11lll_l1_ (u"ࠪหฺ้๊สࠩⰗ")
			elif name==l11lll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩⰘ"): name = l11lll_l1_ (u"ࠬอไิ่ฬࠫⰙ")
			elif name==l11lll_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳࡧ࡬ࠨⰚ"): name = l11lll_l1_ (u"ࠧศๆ่์ุ๋ࠧⰛ")
			#if l11lll_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧⰜ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪⰝ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬⰞ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭Ⱏ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧⰠ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨⰡ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫⰢ")+l1l1llll_l1_
			if name: title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫⰣ")+name
			else: title = option   #+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠩ࠳ࠫⰤ")]
			if type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭Ⱕ"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰦ"),l111ll_l1_+title,url,514,l11lll_l1_ (u"ࠬ࠭Ⱗ"),l11lll_l1_ (u"࠭ࠧⰨ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩⰩ"))
			elif type==l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫⰪ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠩࡀࠫⰫ") in l1l11l1l_l1_:
				l11l1l1_l1_ = l11111ll11_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰬ"),l111ll_l1_+title,l11l1l1_l1_,511)
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰭ"),l111ll_l1_+title,url,515,l11lll_l1_ (u"ࠬ࠭Ⱞ"),l11lll_l1_ (u"࠭ࠧⰯ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨⰰ"),l11lll_l1_ (u"ࠨࠩⰱ"),filters,l11lll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪⰲ"))
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬⰳ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧⰴ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪⰵ")			all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩⰶ"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫⰷ"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪⰸ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫⰹ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬⰺ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭ⰻ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭ⰼ")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨⰽ")
		if l11lll_l1_ (u"ࠧࠦࠩⰾ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪⰿ") and value!=l11lll_l1_ (u"ࠩ࠳ࠫⱀ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧⱁ")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧⱂ") and value!=l11lll_l1_ (u"ࠬ࠶ࠧⱃ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨⱄ")+key+l11lll_l1_ (u"ࠧ࠾ࠩⱅ")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ⱆ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫⱇ")+key+l11lll_l1_ (u"ࠪࡁࠬⱈ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨⱉ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧⱊ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩⱋ"),l11lll_l1_ (u"ࠧ࠾ࠩⱌ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩⱍ"),l11lll_l1_ (u"ࠩࠪⱎ"),filters,l11lll_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫⱏ"))
	return l1ll1l1l_l1_
l1l11lll_l1_ = []
l1ll11ll_l1_ = []
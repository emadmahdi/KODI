# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3
#import l11ll11l11l_l1_ as pickle
script_name = l11lll_l1_ (u"ࠧࡍࡋࡅࡗࡔࡔࡅࠨ㠱")
l11lll1ll1l_l1_ = xbmcaddon.Addon().getAddonInfo(l11lll_l1_ (u"ࠨࡲࡤࡸ࡭࠭㠲"))
l11l1ll11ll_l1_ = os.path.join(l11lll1ll1l_l1_,l11lll_l1_ (u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫ㠳"))
sys.path.append(l11l1ll11ll_l1_)
l11lll11l1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤ㠴"))
kodi_version = re.findall(l11lll_l1_ (u"ࠫ࠭ࡢࡤ࡝ࡦ࡟࠲ࡡࡪࠩࠨ㠵"),l11lll11l1l_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11l1l1llll_l1_ = xbmc.LOGINFO
	ltr,rtl = l11lll_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭㠶"),l11lll_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ㠷")
	l11ll1ll1ll_l1_ = xbmcvfs.translatePath(l11lll_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ㠸"))
	from urllib.parse import unquote as _11lll111ll_l1_
else:
	l11l1l1llll_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l11lll_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩ㠹").encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㠺")),l11lll_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫ㠻").encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㠼"))
	l11ll1ll1ll_l1_ = xbmc.translatePath(l11lll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭㠽"))
	from urllib import unquote as _11lll111ll_l1_
l1l1111111l_l1_ = 60
HOUR = 60*l1l1111111l_l1_
l11l1lll111_l1_ = 24*HOUR
l11lllll1ll_l1_ = 30*l11l1lll111_l1_
l11111l_l1_ = 3*l11l1lll111_l1_
PERMANENT_CACHE = 12*l11lllll1ll_l1_
addon_id = sys.argv[0].split(l11lll_l1_ (u"࠭࠯ࠨ㠾"))[2]	# plugin.video.l11l1ll1ll1_l1_
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
l1l11111l1l_l1_ = addon_id.split(l11lll_l1_ (u"ࠧ࠯ࠩ㠿"))[2]		# l11l1ll1ll1_l1_
l11ll111111_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠨ㡀")+addon_id+l11lll_l1_ (u"ࠩࠬࠫ㡁"))
addoncachefolder = os.path.join(l11ll1ll1ll_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠪࡱࡦ࡯࡮ࡥࡣࡷࡥ࠳ࡪࡢࠨ㡂"))
l11lll1111l_l1_ = os.path.join(addoncachefolder,l11lll_l1_ (u"ࠫࡱࡧࡳࡵࡸ࡬ࡨࡪࡵࡳ࠯ࡦࡤࡸࠬ㡃"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1llll11ll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㡄"),l11lll_l1_ (u"࠭ࠧ㡅"),url,l11lll_l1_ (u"ࠧࡖࡔࡏࡈࡊࡉࡏࡅࡇࠪ㡆"))
	if l11lll_l1_ (u"ࠨ࠿ࠪ㡇") in url:
		if l11lll_l1_ (u"ࠩࡂࠫ㡈") in url: l11l11l_l1_,filters = url.split(l11lll_l1_ (u"ࠪࡃࠬ㡉"),1)
		else: l11l11l_l1_,filters = l11lll_l1_ (u"ࠫࠬ㡊"),url
		filters = filters.split(l11lll_l1_ (u"ࠬࠬࠧ㡋"))
		l11llll11_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㡌"),l11lll_l1_ (u"ࠧࠨ㡍"),filter,str(filters))
			key,value = filter.split(l11lll_l1_ (u"ࠨ࠿ࠪ㡎"),1)
			l11llll11_l1_[key] = value
	else: l11l11l_l1_,l11llll11_l1_ = url,{}
	return l11l11l_l1_,l11llll11_l1_
def l111l_l1_(urll):
	return _11lll111ll_l1_(urll)
	#return urllib2.unquote(urll)
def EXTRACT_KODI_PATH(l11l1ll1lll_l1_):
	l1l111l111l_l1_ = {l11lll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㡏"):l11lll_l1_ (u"ࠪࠫ㡐"),l11lll_l1_ (u"ࠫࡲࡵࡤࡦࠩ㡑"):l11lll_l1_ (u"ࠬ࠭㡒"),l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㡓"):l11lll_l1_ (u"ࠧࠨ㡔"),l11lll_l1_ (u"ࠨࡶࡨࡼࡹ࠭㡕"):l11lll_l1_ (u"ࠩࠪ㡖"),l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥࠨ㡗"):l11lll_l1_ (u"ࠫࠬ㡘"),l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㡙"):l11lll_l1_ (u"࠭ࠧ㡚"),l11lll_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭㡛"):l11lll_l1_ (u"ࠨࠩ㡜"),l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ㡝"):l11lll_l1_ (u"ࠪࠫ㡞"),l11lll_l1_ (u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭㡟"):l11lll_l1_ (u"ࠬ࠭㡠")}
	if l11lll_l1_ (u"࠭࠿ࠨ㡡") in l11l1ll1lll_l1_: l11l1ll1lll_l1_ = l11l1ll1lll_l1_.split(l11lll_l1_ (u"ࠧࡀࠩ㡢"),1)[1]
	l11l11l_l1_,l1l111l1111_l1_ = l1llll11ll_l1_(l11l1ll1lll_l1_)
	args = dict(list(l1l111l111l_l1_.items())+list(l1l111l1111_l1_.items()))
	l11l1ll1l11_l1_ = args[l11lll_l1_ (u"ࠨ࡯ࡲࡨࡪ࠭㡣")]
	l11lll1l11l_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭㡤")])
	l11ll1l11ll_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠪࡸࡪࡾࡴࠨ㡥")])
	l11l1l1ll1l_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠫࡵࡧࡧࡦࠩ㡦")])
	l11l1l1ll11_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ㡧")])
	l11ll1l1l11_l1_ = l111l_l1_(args[l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㡨")])
	l11llll11l1_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭㡩")])
	l11ll1l111l_l1_ = args[l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ㡪")]
	l11lll111l1_l1_ = l111l_l1_(args[l11lll_l1_ (u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ㡫")])
	if l11lll111l1_l1_: l11lll111l1_l1_ = eval(l11lll111l1_l1_)
	else: l11lll111l1_l1_ = {}
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ㡬"))
	#l11l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫ㡭"))
	if not l11l1ll1l11_l1_: l11l1l1ll11_l1_ = l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㡮") ; l11l1ll1l11_l1_ = l11lll_l1_ (u"࠭࠲࠷࠲ࠪ㡯")
	return l11l1l1ll11_l1_,l11ll1l1l11_l1_,l11lll1l11l_l1_,l11l1ll1l11_l1_,l11llll11l1_l1_,l11l1l1ll1l_l1_,l11ll1l11ll_l1_,l11ll1l111l_l1_,l11lll111l1_l1_
def LOGGING(script_name):
	l11ll1l11l1_l1_ = sys._getframe(1).f_code.co_name
	if not script_name or not l11ll1l11l1_l1_ or l11ll1l11l1_l1_==l11lll_l1_ (u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩ㡰"):
		return l11lll_l1_ (u"ࠨ࡝ࠣࠫ㡱")+l1l11111l1l_l1_.upper()+l11lll_l1_ (u"ࠩ࠰ࠫ㡲")+l11ll111111_l1_+l11lll_l1_ (u"ࠪ࠱ࠬ㡳")+str(kodi_version)+l11lll_l1_ (u"ࠫࠥࡣࠧ㡴")
	return l11lll_l1_ (u"ࠬ࠴ࠠࠡࠩ㡵")+l11ll1l11l1_l1_
def LOG_THIS(level,message):
	if kodi_version<19: message = message.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㡶")).encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㡷"))
	l11ll1111l1_l1_ = l11l1l1llll_l1_
	lines = [l11lll_l1_ (u"ࠨࠩ㡸"),l11lll_l1_ (u"ࠩࠪ㡹")]
	if level: message = message.replace(l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㡺"),l11lll_l1_ (u"ࠫࠬ㡻")).replace(l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㡼"),l11lll_l1_ (u"࠭ࠧ㡽")).replace(l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㡾"),l11lll_l1_ (u"ࠨࠩ㡿"))
	else: level = l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㢀")
	l111l1l1ll_l1_,sep,shift = l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ㢁"),l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㢂"),l11lll_l1_ (u"ࠬ࠭㢃")
	if l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㢄") in level: l11ll1111l1_l1_ = xbmc.LOGERROR
	if level==l11lll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㢅"):
		message = message+sep
		lines = message.split(sep)
		shift = l111l1l1ll_l1_
	elif level==l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㢆"):
		message = message.replace(l11lll_l1_ (u"ࠩ࠱ࠫ㢇")+sep,l11lll_l1_ (u"ࠪ࠲ࠥࠦࠧ㢈"))
		lines = message.split(sep)
		lines[0] = l11lll_l1_ (u"ࠫ࠳࠭㢉")+lines[0][1:]
		shift = l111l1l1ll_l1_+sep
	elif level in [l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㢊"),l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ㢋")]: lines = message.split(l111l1l1ll_l1_)
	shift += 6*l111l1l1ll_l1_
	l11ll111ll1_l1_ = 3*l111l1l1ll_l1_
	if kodi_version>17.99: shift += 11*l11lll_l1_ (u"ࠧࠡࠩ㢌")
	l11lllll1l1_l1_ = lines[0]
	for line in lines[1:]:
		if l11lll_l1_ (u"ࠨ࡞ࡱࠫ㢍") in line: line = line.replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬ㢎"),l11lll_l1_ (u"ࠪࡠࡳ࠭㢏")+l111l1l1ll_l1_+l111l1l1ll_l1_)
		l11ll111ll1_l1_ += l111l1l1ll_l1_
		l11lllll1l1_l1_ += l11lll_l1_ (u"ࠫࡡࡸࠧ㢐")+shift+l11ll111ll1_l1_+line
	l11lllll1l1_l1_ += l11lll_l1_ (u"ࠬࠦ࡟ࠨ㢑")
	if l11lll_l1_ (u"࠭ࠥࠨ㢒") in l11lllll1l1_l1_: l11lllll1l1_l1_ = l111l_l1_(l11lllll1l1_l1_)
	xbmc.log(l11lllll1l1_l1_,level=l11ll1111l1_l1_)
	return
def l1l1111l111_l1_(l1l1ll111l_l1_):
	conn = sqlite3.connect(l1l1ll111l_l1_)
	cc = conn.cursor()
	cc.execute(l11lll_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡢࡷࡷࡳࡲࡧࡴࡪࡥࡢ࡭ࡳࡪࡥࡹ࠿ࡱࡳࡀ࠭㢓"))
	cc.execute(l11lll_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫ㢔"))
	cc.execute(l11lll_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬࡫ࡳࡵࡲࡦࡡࡦ࡬ࡪࡩ࡫ࡠࡥࡲࡲࡸࡺࡲࡢ࡫ࡱࡸࡸࡃࡹࡦࡵ࠾ࠫ㢕"))
	cc.execute(l11lll_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡮ࡴࡻࡲ࡯ࡣ࡯ࡣࡲࡵࡤࡦ࠿ࡒࡊࡋࡁࠧ㢖"))
	cc.execute(l11lll_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤࡹ࡫࡭ࡱࡡࡶࡸࡴࡸࡥ࠾ࡏࡈࡑࡔࡘ࡙࠼ࠩ㢗"))
	cc.execute(l11lll_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴ࡯ࡶࡵࡀࡓࡋࡌ࠻ࠨ㢘"))
	conn.text_factory = str
	return conn,cc
def DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l11lll1l111_l1_=None):
	try: conn,cc = l1l1111l111_l1_(l1l1ll111l_l1_)
	except: return
	if l11lll1l111_l1_==None: cc.execute(l11lll_l1_ (u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ㢙")+table+l11lll_l1_ (u"ࠧࠣࠢ࠾ࠫ㢚"))
	else:
		tt = (str(l11lll1l111_l1_),)
		try:
			if l11lll_l1_ (u"ࠨࠧࠪ㢛") in l11lll1l111_l1_: cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㢜")+table+l11lll_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡱ࡯࡫ࡦࠢࡂࠤࡀ࠭㢝"),tt)
			else: cc.execute(l11lll_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ㢞")+table+l11lll_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ㢟"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l11llllll11_l1_(): pass
class l1l1111l1ll_l1_(l11llllll11_l1_):
	def __init__(self):
		self.url = l11lll_l1_ (u"࠭ࠧ㢠")
		self.code = -99
		self.reason = l11lll_l1_ (u"ࠧࠨ㢡")
		self.content = l11lll_l1_ (u"ࠨࠩ㢢")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l11lll11lll_l1_(type):
	if type==l11lll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㢣"): data = {}
	elif type==l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㢤"): data = []
	elif type==l11lll_l1_ (u"ࠫࡸࡺࡲࠨ㢥"): data = l11lll_l1_ (u"ࠬ࠭㢦")
	elif type==l11lll_l1_ (u"࠭ࡩ࡯ࡶࠪ㢧"): data = 0
	elif type==l11lll_l1_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ㢨"): data = l1l1111l1ll_l1_()
	elif not type: data = None
	else: data = None
	return data
def READ_FROM_SQL3(l1l1ll111l_l1_,l11lll1llll_l1_,table,l11lll1l111_l1_=None):
	data = l11lll11lll_l1_(l11lll1llll_l1_)
	cache = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ㢩"))
	if table!=l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㢪") and l1l1ll111l_l1_==main_dbfile:
		if cache==l11lll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ㢫"): return data
		l1l11llll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ㢬"))
		if l1l11llll1_l1_==l11lll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ㢭"):
			DELETE_FROM_SQL3(l1l1ll111l_l1_,table,l11lll1l111_l1_)
			return data
	l1l111l1l11_l1_ = 0
	if cache==l11lll_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ㢮"): l1l111l1l11_l1_ = l11l1llllll_l1_
	try: conn,cc = l1l1111l111_l1_(l1l1ll111l_l1_)
	except: return data
	l11lll11111_l1_ = True
	try: cc.execute(l11lll_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩ㢯")+table+l11lll_l1_ (u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭㢰"))
	except: l11lll11111_l1_ = False
	if l11lll11111_l1_:
		if l1l111l1l11_l1_: cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㢱")+table+l11lll_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬ㢲")+str(now+l1l111l1l11_l1_)+l11lll_l1_ (u"ࠫࠥࡁࠧ㢳"))
		conn.commit()
		cc.execute(l11lll_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㢴")+table+l11lll_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨ㢵")+str(now)+l11lll_l1_ (u"ࠧࠡ࠽ࠪ㢶"))
		conn.commit()
		if l11lll1l111_l1_:
			tt = (str(l11lll1l111_l1_),)
			cc.execute(l11lll_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭㢷")+table+l11lll_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ㢸"),tt)
			l11ll1ll1l1_l1_ = cc.fetchall()
			if l11ll1ll1l1_l1_:
				try:
					text = zlib.decompress(l11ll1ll1l1_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11lll_l1_ (u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ㢹")+table+l11lll_l1_ (u"ࠫࠧࠦ࠻ࠨ㢺"))
			l11ll1ll1l1_l1_ = cc.fetchall()
			if l11ll1ll1l1_l1_:
				data,l1l11111lll_l1_ = {},[]
				for l11lllll11l_l1_,l11llll11_l1_ in l11ll1ll1l1_l1_:
					l1l1l1ll11_l1_ = zlib.decompress(l11llll11_l1_)
					l11llll11_l1_ = pickle.loads(l1l1l1ll11_l1_)
					data[l11lllll11l_l1_] = l11llll11_l1_
					l1l11111lll_l1_.append(l11lllll11l_l1_)
				if l1l11111lll_l1_:
					data[l11lll_l1_ (u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭㢻")] = l1l11111lll_l1_
					if l11lll1llll_l1_==l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ㢼"): data = l1l11111lll_l1_
	conn.close()
	return data
def l11ll1llll1_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l11llll11ll_l1_(length,l11llllllll_l1_=True):
	l11l1l1lll1_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡏࡧࡷࡻࡴࡸ࡫࠯ࡋࡓࡅࡩࡪࡲࡦࡵࡶࠫ㢽"))
	l11llll1l1l_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧ㢾"))
	if l11llllllll_l1_:
		try: l11llll111_l1_,l1l111111ll_l1_,l11ll111l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㢿"),l11lll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㣀"),l11lll_l1_ (u"ࠫࡎࡊࡓࠨ㣁"))
		except: l11llll111_l1_,l1l111111ll_l1_,l11ll111l1l_l1_ = l11lll_l1_ (u"ࠬ࠭㣂"),l11lll_l1_ (u"࠭ࠧ㣃"),l11lll_l1_ (u"ࠧࠨ㣄")
		if l11llll111_l1_ and l11l1l1lll1_l1_==l1l111111ll_l1_ and l11llll1l1l_l1_==l11ll111l1l_l1_: return l11llll111_l1_
	#import uuid
	#node = str(uuid.getnode())
	#l11llll1lll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡐࡨࡸࡼࡵࡲ࡬࠰ࡐࡥࡨࡇࡤࡥࡴࡨࡷࡸ࠭㣅"))
	#if l11llll1lll_l1_.count(l11lll_l1_ (u"ࠩ࠽ࠫ㣆"))==5 and l11llll1lll_l1_.count(l11lll_l1_ (u"ࠪ࠴ࠬ㣇"))<9: l11ll111lll_l1_ = l11llll1lll_l1_
	global mac
	length = length//2
	import threading
	l11l1lll1ll_l1_ = threading.Thread(target=l11ll1llll1_l1_,args=())
	l11l1lll1ll_l1_.start()
	mac = l11lll_l1_ (u"ࠫࠬ㣈")
	for l11l1lllll_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11lll_l1_ (u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ㣉")
	else:
		mac = mac.replace(l11lll_l1_ (u"࠭࠺ࠨ㣊"),l11lll_l1_ (u"ࠧࠨ㣋"))
		node = str(int(mac,16))
	node = re.findall(l11lll_l1_ (u"ࠨ࡝࠳࠱࠾ࡣࠫࠨ㣌"),node,re.DOTALL)
	node = length*l11lll_l1_ (u"ࠩ࠳ࠫ㣍")+node[0]
	node = node[-length:]
	mm,ss = l11lll_l1_ (u"ࠪࠫ㣎"),l11lll_l1_ (u"ࠫࠬ㣏")
	l11ll1l1ll1_l1_ = str(int(l11lll_l1_ (u"ࠬ࠿ࠧ㣐")*(length+1))-int(node))[-length:]
	for l11l1lllll_l1_ in list(range(0,length,4)):
		l11l1lllll1_l1_ = l11ll1l1ll1_l1_[l11l1lllll_l1_:l11l1lllll_l1_+4]
		mm += l11l1lllll1_l1_+l11lll_l1_ (u"࠭࠭ࠨ㣑")
		ss += str(sum(map(int,node[l11l1lllll_l1_:l11l1lllll_l1_+4]))%10)
	l1l1111ll11_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㣒"),l11lll_l1_ (u"ࠨࡋࡇࡗࠬ㣓"),[l1l1111ll11_l1_,l11l1l1lll1_l1_,l11llll1l1l_l1_],l11111l_l1_)
	return l1l1111ll11_l1_
def l11l1llll1l_l1_(l1l1111llll_l1_):
	l11ll11ll1l_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡻࡳࡦࡴ࠱ࡴࡷ࡯ࡶࡴࠩ㣔"))
	#l1l1111llll_l1_ = l1l1111llll_l1_.encode(l11lll_l1_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ㣕")).replace(l11lll_l1_ (u"ࠫࡡࡴࠧ㣖"),l11lll_l1_ (u"ࠬ࠭㣗"))
	user = l11llll11ll_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11lll_l1_ (u"࠭ࡘ࠲࠻ࠪ㣘")+l1l1111llll_l1_+l11lll_l1_ (u"ࠧ࠲࠺ࡀࠫ㣙")+user).encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㣚"))).hexdigest()[:32]
	if md5 in l11ll11ll1l_l1_: return True
	return False
class l11lll1ll11_l1_(xbmc.Player):
	def __init__(self): self.status = l11lll_l1_ (u"ࠩࠪ㣛")
	def l11lll11l11_l1_(self,script_name):
		if l11l1llll1l_l1_(l11lll_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㣜")) or not l11l1llll1l_l1_(l11lll_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㣝")):
			import LIBSTWO
			if not LIBSTWO.l11ll1ll11l_l1_(script_name):
				self.status = l11lll_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㣞")
				import l11ll1lll11_l1_
				l11ll1lll11_l1_.l11lll1l1ll_l1_(False)
	def onPlayBackStopped(self):
		self.status=l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㣟")
	def onPlayBackStarted(self):
		self.status = l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㣠")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㣡")
	def onPlayBackEnded(self):
		self.status = l11lll_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㣢")
def l11llll1111_l1_(type,url,data,headers,source,method):
	l1l1ll1ll_l1_ = str(headers)[0:250].replace(l11lll_l1_ (u"ࠪࡠࡳ࠭㣣"),l11lll_l1_ (u"ࠫࡡࡢ࡮ࠨ㣤")).replace(l11lll_l1_ (u"ࠬࡢࡲࠨ㣥"),l11lll_l1_ (u"࠭࡜࡝ࡴࠪ㣦")).replace(l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠬ㣧"),l11lll_l1_ (u"ࠨࠢࠪ㣨")).replace(l11lll_l1_ (u"ࠩࠣࠤࠥ࠭㣩"),l11lll_l1_ (u"ࠪࠤࠬ㣪"))
	if len(str(headers))>250: l1l1ll1ll_l1_ = l1l1ll1ll_l1_+l11lll_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ㣫")
	l11llll11_l1_ = str(data)[0:250].replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ㣬"),l11lll_l1_ (u"࠭࡜࡝ࡰࠪ㣭")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ㣮"),l11lll_l1_ (u"ࠨ࡞࡟ࡶࠬ㣯")).replace(l11lll_l1_ (u"ࠩࠣࠤࠥࠦࠧ㣰"),l11lll_l1_ (u"ࠪࠤࠬ㣱")).replace(l11lll_l1_ (u"ࠫࠥࠦࠠࠨ㣲"),l11lll_l1_ (u"ࠬࠦࠧ㣳"))
	if len(str(data))>250: l11llll11_l1_ = l11llll11_l1_+l11lll_l1_ (u"࠭ࠠ࠯࠰࠱ࠫ㣴")
	LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㣵"),l11lll_l1_ (u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤ࠭㣶")+type+l11lll_l1_ (u"ࠩࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㣷")+url+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㣸")+source+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭㣹")+method+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ㣺")+str(l1l1ll1ll_l1_)+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭㣻")+l11llll11_l1_+l11lll_l1_ (u"ࠧࠡ࡟ࠪ㣼"))
	return
def l1lllll111_l1_(method,url,data=l11lll_l1_ (u"ࠨࠩ㣽"),headers=l11lll_l1_ (u"ࠩࠪ㣾"),source=l11lll_l1_ (u"ࠪࠫ㣿")):
	l11llll1111_l1_(l11lll_l1_ (u"࡚ࠫࡘࡌࡍࡋࡅࠤࠥࡕࡐࡆࡐࡢ࡙ࡗࡒࠧ㤀"),url,data,headers,source,method)
	if kodi_version>18.99: import urllib.request as l11lllllll1_l1_
	else: import urllib2 as l11lllllll1_l1_
	if not headers: headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㤁"):l11lll_l1_ (u"࠭ࠧ㤂")}
	if not data: data = {}
	if method==l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㤃"):
		url = url+l11lll_l1_ (u"ࠨࡁࠪ㤄")+l1ll1l1ll_l1_(data)
		data = None
	elif method==l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㤅") and l11lll_l1_ (u"ࠪ࡮ࡸࡵ࡮ࠨ㤆") in str(headers):
		import json
		data = json.dumps(data)
		data = str(data).encode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㤇"))
	elif method==l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ㤈"):
		data = l1ll1l1ll_l1_(data)
		data = data.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㤉"))
	try:
		req = l11lllllll1_l1_.Request(url,headers=headers,data=data)
		response = l11lllllll1_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l11lll_l1_ (u"ࠧࡐࡍࠪ㤊")
	except:
		html = l11lll_l1_ (u"ࠨࠩ㤋")
		code,reason = -1,l11lll_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩ㤌")
	LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㤍"),l11lll_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ㤎")+str(code)+l11lll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㤏")+reason+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㤐")+source+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㤑")+url+l11lll_l1_ (u"ࠨࠢࡠࠫ㤒"))
	#try:
	#	req = l11lllllll1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	response = l11lllllll1_l1_.urlopen(req)
	#	html = response.read()
	#except: html = l11lll_l1_ (u"ࠩࠪ㤓")
	return html
def l1l1111lll1_l1_(script_name):
	# https://www.l1l11111l11_l1_.l11ll11l111_l1_.l11ll11l1ll_l1_.com/l11llll1ll1_l1_/l11ll1l1111_l1_/http-l11l1ll11l1_l1_-l11ll1lll1l_l1_
	# https://help.l11ll11l1ll_l1_.com/l11ll11lll1_l1_/l11lllll111_l1_-l1ll1ll1l11_l1_/l1l11111111_l1_/215562387-l11ll1l1l1l_l1_-property-l11l1l1l1ll_l1_
	# https://www.l1l11111l11_l1_.l11ll11l111_l1_.l11ll11l1ll_l1_.com/l11llll1ll1_l1_/l11ll1l1111_l1_/l11ll11ll11_l1_-rest-l11ll1lll1l_l1_
	l11ll11l1l1_l1_ = str(random.randrange(111111111111,999999999999))
	#l11ll1lllll_l1_ = l11l1ll1111_l1_()
	#l1l1111ll1l_l1_ = l11ll1lllll_l1_.split(l11lll_l1_ (u"ࠪ࠰ࠬ㤔"),1)[0]
	headers = {l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㤕"):l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ㤖")}
	data = {l11lll_l1_ (u"ࠨࡡࡱ࡫ࡢ࡯ࡪࡿࠢ㤗"):l11lll_l1_ (u"ࠧ࠳࠷࠷ࡨࡩ࠹ࡡ࠵࠲࠼ࡨ࠽ࡨ࠶࠹࠳ࡧ࠸ࡪ࠷࠱࠸ࡧࡨ࠻࠽ࡩࡥࡣࡨ࠵࠽ࠬ㤘"),
			l11lll_l1_ (u"ࠣ࡫ࡱࡷࡪࡸࡴࡠ࡫ࡧࠦ㤙"):l11ll11l1l1_l1_,
			l11lll_l1_ (u"ࠤࡨࡺࡪࡴࡴࡴࠤ㤚"): [{
				l11lll_l1_ (u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ㤛"):l11llll11ll_l1_(32),
				l11lll_l1_ (u"ࠦࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣ㤜"):str(kodi_version),
				l11lll_l1_ (u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥ㤝"):l11ll111111_l1_,
				#l11lll_l1_ (u"ࠨࡣࡢࡴࡵ࡭ࡪࡸࠢ㤞"):l11ll111111_l1_,
				l11lll_l1_ (u"ࠢࡥࡧࡹ࡭ࡨ࡫࡟ࡧࡣࡰ࡭ࡱࡿࠢ㤟"):l11ll111111_l1_,
				l11lll_l1_ (u"ࠣࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠧ㤠"):script_name,
				l11lll_l1_ (u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧ㤡"):{l11lll_l1_ (u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ㤢"):script_name},
				l11lll_l1_ (u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ㤣"): {l11lll_l1_ (u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ㤤"):script_name},
				l11lll_l1_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣ㤥"): l11lll_l1_ (u"ࠢࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙ࠢ㤦"),
				l11lll_l1_ (u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢ㤧"):False,
				l11lll_l1_ (u"ࠤ࡬ࡴࠧ㤨"): l11lll_l1_ (u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ㤩")
			}]
		}
	url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭㤪")
	#response = l11lll11ll1_l1_(l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ㤫"),url,data,headers,l11lll_l1_ (u"࠭ࠧ㤬"),l11lll_l1_ (u"ࠧࠨ㤭"),l11lll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㤮"),False,False)
	html = l1lllll111_l1_(l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㤯"),url,data,headers,script_name)
	return html
def l11llll1l11_l1_(url,script_name,type):
	l11l1ll111l_l1_ = xbmcgui.ListItem()
	l11ll1l1lll_l1_ = l11lll1ll11_l1_()
	l11ll1l1lll_l1_.l11lll11l11_l1_(script_name)
	if l11ll1l1lll_l1_.status: LOG_THIS(l11lll_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㤰"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㤱")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㤲"))
	else:
		if type==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㤳"):
			l11l1ll111l_l1_.setPath(url)
			LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㤴"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡻ࡯ࡤࡦࡱࠣࡴࡱࡧࡹࠡࡷࡶ࡭ࡳ࡭ࠠࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࠫࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㤵")+url+l11lll_l1_ (u"ࠩࠣࡡࠬ㤶"))
			xbmcplugin.setResolvedUrl(addon_handle,True,l11l1ll111l_l1_)
		else:
			LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㤷"),LOGGING(script_name)+l11lll_l1_ (u"ࠫࠥࠦࠠࡔ࡫ࡰࡴࡱ࡫ࠠ࡭࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㤸")+url+l11lll_l1_ (u"ࠬࠦ࡝ࠨ㤹"))
			l11ll1l1lll_l1_.play(url,l11l1ll111l_l1_)
		l11llll111l_l1_()
		timeout = 5
		for l11l1lllll_l1_ in range(timeout):
			# l11l1ll1l1l_l1_ l1l1111l1l1_l1_
			#	if using time.sleep() l11l1lll1l1_l1_ of xbmc.sleep() l1l11111ll1_l1_ the l11ll1111ll_l1_ status
			#	l11lll_l1_ (u"ࠨ࡭ࡺࡲ࡯ࡥࡾ࡫ࡲ࠯ࡵࡷࡥࡹࡻࡳࠣ㤺") will stop l11ll1ll111_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l1l111l11ll_l1_ = l11ll1l1lll_l1_.status
			if l1l111l11ll_l1_ in [l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㤻"),l11lll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㤼")]: break
		if l1l111l11ll_l1_==l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ㤽"): response = l1l1111lll1_l1_(script_name)
	return
def EVAL(l11lll1llll_l1_,text):
	#text = text.replace(l11lll_l1_ (u"ࠥࡹࠬࠨ㤾"),l11lll_l1_ (u"ࠦࠬࠨ㤿"))
	text = text.replace(l11lll_l1_ (u"ࠬࡴࡵ࡭࡮ࠪ㥀"),l11lll_l1_ (u"࠭ࡎࡰࡰࡨࠫ㥁"))
	text = text.replace(l11lll_l1_ (u"ࠧࡵࡴࡸࡩࠬ㥂"),l11lll_l1_ (u"ࠨࡖࡵࡹࡪ࠭㥃"))
	text = text.replace(l11lll_l1_ (u"ࠩࡩࡥࡱࡹࡥࠨ㥄"),l11lll_l1_ (u"ࠪࡊࡦࡲࡳࡦࠩ㥅"))
	text = text.replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ㥆"),l11lll_l1_ (u"ࠬ࠵ࠧ㥇"))
	try: l1l1l1ll11_l1_ = eval(text)
	except: l1l1l1ll11_l1_ = l11lll11lll_l1_(l11lll1llll_l1_)
	return l1l1l1ll11_l1_
def l11llll111l_l1_():
	type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭㥈"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11lll_l1_ (u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧ㥉"),time.localtime(now))
	name = name+datetime
	l1l1l1ll111_l1_ = type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_
	if os.path.exists(l11lll1111l_l1_):
		l11ll11llll_l1_ = open(l11lll1111l_l1_,l11lll_l1_ (u"ࠨࡴࡥࠫ㥊")).read()
		if kodi_version>18.99: l11ll11llll_l1_ = l11ll11llll_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㥋"))
		l11ll11llll_l1_ = EVAL(l11lll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㥌"),l11ll11llll_l1_)
	else: l11ll11llll_l1_ = {}
	l11ll11111l_l1_ = {}
	for l1l111111l1_l1_ in list(l11ll11llll_l1_.keys()):
		if l1l111111l1_l1_!=type: l11ll11111l_l1_[l1l111111l1_l1_] = l11ll11llll_l1_[l1l111111l1_l1_]
		else:
			if name and name!=l11lll_l1_ (u"ࠫ࠳࠴ࠧ㥍"):
				l11l1llll11_l1_ = l11ll11llll_l1_[l1l111111l1_l1_]
				if l1l1l1ll111_l1_ in l11l1llll11_l1_:
					index = l11l1llll11_l1_.index(l1l1l1ll111_l1_)
					del l11l1llll11_l1_[index]
				l1ll1lll1ll_l1_ = [l1l1l1ll111_l1_]+l11l1llll11_l1_
				l1ll1lll1ll_l1_ = l1ll1lll1ll_l1_[:50]
				l11ll11111l_l1_[l1l111111l1_l1_] = l1ll1lll1ll_l1_
			else: l11ll11111l_l1_[l1l111111l1_l1_] = l11ll11llll_l1_[l1l111111l1_l1_]
	if type not in list(l11ll11111l_l1_.keys()): l11ll11111l_l1_[type] = [l1l1l1ll111_l1_]
	l11ll11111l_l1_ = str(l11ll11111l_l1_)
	if kodi_version>18.99: l11ll11111l_l1_ = l11ll11111l_l1_.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㥎"))
	open(l11lll1111l_l1_,l11lll_l1_ (u"࠭ࡷࡣࠩ㥏")).write(l11ll11111l_l1_)
	return
def WRITE_TO_SQL3(l1l1ll111l_l1_,table,l11lll1l111_l1_,data,l11lll1lll1_l1_,l11llllll1l_l1_=False):
	cache = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㥐"))
	if cache==l11lll_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㥑") and l11lll1lll1_l1_>l11l1llllll_l1_: l11lll1lll1_l1_ = l11l1llllll_l1_
	if l11llllll1l_l1_:
		l11ll1lll_l1_,l11lll111_l1_ = [],[]
		for l11l1lllll_l1_ in range(len(l11lll1l111_l1_)):
			text = pickle.dumps(data[l11l1lllll_l1_])
			l11ll111l11_l1_ = zlib.compress(text)
			l11ll1lll_l1_.append((l11lll1l111_l1_[l11l1lllll_l1_],))
			l11lll111_l1_.append((l11lll1lll1_l1_+now,str(l11lll1l111_l1_[l11l1lllll_l1_]),l11ll111l11_l1_))
	else:
		text = pickle.dumps(data)
		l11lll1l1l1_l1_ = zlib.compress(text)
	try: conn,cc = l1l1111l111_l1_(l1l1ll111l_l1_)
	except: return
	while True:
		try:
			cc.execute(l11lll_l1_ (u"ࠩࡅࡉࡌࡏࡎࠡࡋࡐࡑࡊࡊࡉࡂࡖࡈࠤ࡙ࡘࡁࡏࡕࡄࡇ࡙ࡏࡏࡏࠢ࠾ࠫ㥒"))
			break
		except: time.sleep(0.5)
	cc.execute(l11lll_l1_ (u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ㥓")+table+l11lll_l1_ (u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ㥔"))
	if l11llllll1l_l1_:
		cc.executemany(l11lll_l1_ (u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ㥕")+table+l11lll_l1_ (u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㥖"),l11ll1lll_l1_)
		cc.executemany(l11lll_l1_ (u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ㥗")+table+l11lll_l1_ (u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭㥘"),l11lll111_l1_)
	else:
		if l11lll1lll1_l1_:
			tt = (str(l11lll1l111_l1_),)
			cc.execute(l11lll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㥙")+table+l11lll_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㥚"),tt)
			tt = (l11lll1lll1_l1_+now,str(l11lll1l111_l1_),l11lll1l1l1_l1_)
			cc.execute(l11lll_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ㥛")+table+l11lll_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ㥜"),tt)
		else:
			tt = (l11lll1l1l1_l1_,str(l11lll1l111_l1_))
			cc.execute(l11lll_l1_ (u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨ㥝")+table+l11lll_l1_ (u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭㥞"),tt)
	conn.commit()
	conn.close()
	return
def l1ll1l1ll_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l1111l11l_l1_
	else: import urllib as l1l1111l11l_l1_
	l1l111l11l1_l1_ = l1l1111l11l_l1_.urlencode(data)
	return l1l111l11l1_l1_
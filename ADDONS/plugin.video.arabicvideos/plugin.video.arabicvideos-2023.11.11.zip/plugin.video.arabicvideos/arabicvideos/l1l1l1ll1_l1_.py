﻿# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨຮ")
headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫຯ") : l11lll_l1_ (u"ࠨࠩະ") }
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨັ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ะ่ศื็ࠤฬ๊วอฬ่ห฾๐ࠧາ"),l11lll_l1_ (u"ฺࠫ๎ัࠡษ็ฮํอีๅࠢส่ฬาสๆษ฼๎ࠬຳ"),l11lll_l1_ (u"ࠬษัี์ไࠤัฺ๋๊ࠢส่อืวๆฮࠪິ")]
def MAIN(mode,url,text,l1l11l1_l1_):
	if   mode==40: results = MENU()
	elif mode==41: results = l1l1lll1l_l1_()
	elif mode==42: results = l1llllll_l1_(url)
	elif mode==43: results = PLAY(url)
	elif mode==44: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==45: results = l1111l_l1_(url,l11lll_l1_ (u"࠭࡬ࡪ࡯࡬ࡸࡪࡪ࡟ࡴࡧࡤࡶࡨ࡮ࠧີ"))		# needed for search
	elif mode==46: results = l1l1l1l1l_l1_(url)
	elif mode==49: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬຶ"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣหู้๋ศำไࠫື"),l11lll_l1_ (u"ຸࠩࠪ"),41)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴູࠪ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼຺ࠫ"),l11lll_l1_ (u"ࠬ࠭ົ"),49)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫຼ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧຽ"),l11lll_l1_ (u"ࠨࠩ຾"),9999)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ຿"),headers,l11lll_l1_ (u"ࠪࠫເ"),l11lll_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨແ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠮࠶࠴࠺࠸࠹ࠨ࠯ࠬࡂ࠭ࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠭࠵࠳࠷࠶࠸࠭ໂ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡮ࡧࡱࡹ࠲ࡺࡥࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫໃ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧໄ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ໅")+l111ll_l1_+title,link,44)
	return
def l1111l_l1_(url,type):
	if type==l11lll_l1_ (u"ࠩ࡯࡭ࡲ࡯ࡴࡦࡦࡢࡷࡪࡧࡲࡤࡪࠪໆ"):
		search = OPEN_KEYBOARD()
		if not search: return
		url = url.replace(l11lll_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࡡࡖࡉࡆࡘࡃࡉࡡ࡚ࡓࡗࡊࠧ໇"),search)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ່"),url,l11lll_l1_ (u"້ࠬ࠭"),l11lll_l1_ (u"໊࠭ࠧ"),l11lll_l1_ (u"ࠧࠨ໋"),l11lll_l1_ (u"ࠨࠩ໌"),l11lll_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨໍ"))
	html = response.content
	if not type:
		data = re.findall(l11lll_l1_ (u"ࠪ࡮ࡪࡺ࠭ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࡤࡥࡦࡰࡴࡰ࠲࠯ࡅࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ໎"),html,re.DOTALL)
		if data:
			data = l111l_l1_(unescapeHTML(data[0]))
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ໏")+l11lll_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࡣࡘࡋࡁࡓࡅࡋࡣ࡜ࡕࡒࡅࠩ໐")+l11lll_l1_ (u"࠭ࠦ࡫ࡧࡷࡣࡦࡰࡡࡹࡡࡶࡩࡦࡸࡣࡩࡡࡶࡩࡹࡺࡩ࡯ࡩࡶࡁࠬ໑")+data+l11lll_l1_ (u"ࠧࠧࡲࡲࡷࡹࡥࡴࡺࡲࡨࡁࡻ࡯ࡤࡦࡱࡶࠫ໒")
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໓"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋๊ࠢิฬࠦวๅไึ้ࠬ໔"),link,45,l11lll_l1_ (u"ࠪࠫ໕"),l11lll_l1_ (u"ࠫࡱ࡯࡭ࡪࡶࡨࡨࡤࡹࡥࡢࡴࡦ࡬ࠬ໖"))
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ໗"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭໘"),l11lll_l1_ (u"ࠧࠨ໙"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡨࡰࡪࡳࡥ࡯ࡶࡲࡶ࠲ࡶ࡯ࡴࡶࡢࡣࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࡟ࡠ࡮࡬ࡲࡰࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨ໚"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡦࡨࡷࡰࡺ࡯ࡱࡡࡳࡳࡸࡺࡳࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭໛"),html,re.DOTALL)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡲࡥ࡮ࡧࡱࡸࡴࡸ࠭ࡪࡥࡲࡲ࠲ࡲࡩࡴࡶ࠰ࡸࡪࡾࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡴ࡫ࡷࡩ࠲࡬࡯ࡰࡶࡨࡶࠧ࠭ໜ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		items = []
		block = l1l1ll1_l1_[0]
		if l11lll_l1_ (u"ࠫࡸࡵࡣࡪࡣ࡯ࠫໝ") in url:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫໞ"),block,re.DOTALL)
			links,l1l111_l1_,l1l1l1lll_l1_ = zip(*items)
			items = zip(l1l1l1lll_l1_,links,l1l111_l1_)
		if not items: items = re.findall(l11lll_l1_ (u"࠭࠼࡯ࡱࡶࡧࡷ࡯ࡰࡵࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧໟ"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ໠"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ໡"),l111ll_l1_+title,link,43,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡨ࠱ࡱࡵࡡࡥ࠯ࡰࡳࡷ࡫࠭ࡢࡰࡦ࡬ࡴࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨ໢"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ໣"),block,re.DOTALL)
		l1ll1ll1l_l1_ = False
		for link,title in items:
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ໤") not in link: continue
			l1ll1ll1l_l1_ = True
			title = unescapeHTML(title)
			link = unescapeHTML(link)
			if l11lll_l1_ (u"ࠬࡄࠧ໥") in title: title = title.rsplit(l11lll_l1_ (u"࠭࠾ࠨ໦"),1)[1]
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ໧"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ໨")+title,link,44,l11lll_l1_ (u"ࠩࠪ໩"),l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ໪"))
		if not l1ll1ll1l_l1_:
			link = re.findall(l11lll_l1_ (u"ࠫࡳ࡫ࡸࡵ࠯ࡳࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ໫"),block,re.DOTALL)
			if link:
				link = link[0]
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ໬"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ໭")+l11lll_l1_ (u"ࠧศๆ่ึ๏ีࠧ໮"),link,44,l11lll_l1_ (u"ࠨࠩ໯"),l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭໰"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ໱"),url,l11lll_l1_ (u"ࠫࠬ໲"),l11lll_l1_ (u"ࠬ࠭໳"),l11lll_l1_ (u"࠭ࠧ໴"),l11lll_l1_ (u"ࠧࠨ໵"),l11lll_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ໶"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩ࠿ࡺ࡮ࡪࡥࡰࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ໷"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࡣࡺࡸ࡬࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠬࠧ໸"),html,re.DOTALL)
	l1lllll1_l1_ = []
	if link:
		link = link[0].replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ໹"),l11lll_l1_ (u"ࠬ࠵ࠧ໺"))
		l1lllll1_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ໻"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭໼"),url)
	return
def l1l1lll1l_l1_():
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱หฯ࠲๋ศศึิࠫ໽"),l11lll_l1_ (u"ࠩࠪ໾"),l11lll_l1_ (u"ࠪࠫ໿"),l11lll_l1_ (u"ࠫࠬༀ"),l11lll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ༁"))
	items = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༂"),html,re.DOTALL)
	url = l111l_l1_(items[0])
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ༃"),l11lll_l1_ (u"ࠨࠩ༄"),url,str(html))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ༅"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ༆"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ༇"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ༈"),l11lll_l1_ (u"࠭ࠫࠨ༉"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ༊") +l111l1l_l1_
	l1l1l1l1l_l1_(url)
	return
def l1l1l1l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ་"),url,l11lll_l1_ (u"ࠩࠪ༌"),l11lll_l1_ (u"ࠪࠫ།"),l11lll_l1_ (u"ࠫࠬ༎"),l11lll_l1_ (u"ࠬ࠭༏"),l11lll_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ༐"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵ࡬ࡸࡪ࠳࡭ࡢ࡫ࡱࠦ࠭࠴ࠪࡀࠫࠥࡷ࡮ࡺࡥ࠮ࡨࡲࡳࡹ࡫ࡲࠣࠩ༑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡦࡴࡵ࡫࡮ࡣࡵ࡯ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭༒"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ༓"),l111ll_l1_+title,link,43,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯ࠢࡴ࡫ࡷࡩ࠲࡬࡯ࡰࡶࡨࡶࠧ࠭༔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ༕"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ༖"))
			if not title: continue
			if l11lll_l1_ (u"࠭ีโฯฬࠫ༗") not in title: title = l11lll_l1_ (u"ࠧึใะอ༘ࠥ࠭")+title
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ༙"),l111ll_l1_+title,link,46)
	return
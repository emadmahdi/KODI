# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ᏶")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧ᏷")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᏸ"),l11lll_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫᏹ"),l11lll_l1_ (u"ࠫฬ๊วใีส้ࠬᏺ"),l11lll_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩᏻ")]
def MAIN(mode,url,text):
	if   mode==650: results = MENU()
	elif mode==651: results = l1111l_l1_(url,text)
	elif mode==652: results = PLAY(url)
	elif mode==653: results = l11111_l1_(url,text)
	elif mode==654: results = l1l11l_l1_(url)
	elif mode==659: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᏼ"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨᏽ"),l11lll_l1_ (u"ࠨࠩ᏾"),l11lll_l1_ (u"ࠩࠪ᏿"),l11lll_l1_ (u"ࠪࠫ᐀"),l11lll_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᐁ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐂ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᐃ"),l11lll_l1_ (u"ࠧࠨᐄ"),659,l11lll_l1_ (u"ࠨࠩᐅ"),l11lll_l1_ (u"ࠩࠪᐆ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᐇ"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᐈ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᐉ"),l11lll_l1_ (u"࠭ࠧᐊ"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐋ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᐌ")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪᐍ"),l11ll1_l1_,651,l11lll_l1_ (u"ࠪࠫᐎ"),l11lll_l1_ (u"ࠫࠬᐏ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᐐ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐑ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐒ")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᐓ"),l11ll1_l1_,651,l11lll_l1_ (u"ࠩࠪᐔ"),l11lll_l1_ (u"ࠪࠫᐕ"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᐖ"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐗ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᐘ")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᐙ"),l11ll1_l1_,651,l11lll_l1_ (u"ࠨࠩᐚ"),l11lll_l1_ (u"ࠩࠪᐛ"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᐜ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐝ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᐞ")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᐟ"),l11ll1_l1_,651,l11lll_l1_ (u"ࠧࠨᐠ"),l11lll_l1_ (u"ࠨࠩᐡ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᐢ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐣ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐤ"),l11lll_l1_ (u"ࠬ࠭ᐥ"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐦ"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᐧ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐨ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᐩ")+l111ll_l1_+title,link,654)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐪ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐫ"),l11lll_l1_ (u"ࠬ࠭ᐬ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᐭ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᐮ"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠨࠩᐯ"))
	#block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᐰ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		title = title.replace(l11lll_l1_ (u"ࠪࡀࡧࡄࠧᐱ"),l11lll_l1_ (u"ࠫࠬᐲ")).strip(l11lll_l1_ (u"ࠬࠦࠧᐳ"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐴ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐵ")+l111ll_l1_+title,link,654)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᐶ"),url,l11lll_l1_ (u"ࠩࠪᐷ"),l11lll_l1_ (u"ࠪࠫᐸ"),l11lll_l1_ (u"ࠫࠬᐹ"),l11lll_l1_ (u"ࠬ࠭ᐺ"),l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᐻ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐼ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᐽ"),l11lll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᐾ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᐿ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠫࠬᑀ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᑁ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᑂ"),l11lll_l1_ (u"ࠧࠨᑃ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᑄ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬᑅ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᑆ"),l111ll_l1_+title,link,651)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑇ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᑈ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᑉ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑊ"),l11lll_l1_ (u"ࠨࠩᑋ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑌ"),l111ll_l1_+title,link,651)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠪࠫᑍ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᑎ"),l11lll_l1_ (u"ࠬ࠭ᑏ"),request,url)
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᑐ"):
		url,search = url.split(l11lll_l1_ (u"ࠧࡀࠩᑑ"),1)
		data = l11lll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᑒ")+search
		headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᑓ"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᑔ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩᑕ"),url,data,headers,l11lll_l1_ (u"ࠬ࠭ᑖ"),l11lll_l1_ (u"࠭ࠧᑗ"),l11lll_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᑘ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᑙ"),url,l11lll_l1_ (u"ࠩࠪᑚ"),l11lll_l1_ (u"ࠪࠫᑛ"),l11lll_l1_ (u"ࠫࠬᑜ"),l11lll_l1_ (u"ࠬ࠭ᑝ"),l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᑞ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠧࠨᑟ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᑠ"))
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᑡ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᑢ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬᑣ"),link,title))
	elif request==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᑤ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑥ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᑦ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑧ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᑨ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᑩ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᑪ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᑫ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᑬ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨᑭ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᑮ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᑯ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪᑰ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩᑱ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫᑲ"),l11lll_l1_ (u"࠭ใๅ์หࠫᑳ"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭ᑴ"),l11lll_l1_ (u"ࠨ้าหๆ࠭ᑵ"),l11lll_l1_ (u"่ࠩฬฬืวสࠩᑶ"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧᑷ"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫᑸ"),l11lll_l1_ (u"ࠬอไษ๊่ࠫᑹ"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭ᑺ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩᑻ"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᑼ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫᑽ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᑾ"))
		#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᑿ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧᒀ")+l1llll_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨᒁ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠧࠡࠩᒂ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᒃ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᒄ"),l111ll_l1_+title,link,652,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᒅ"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᒆ"),l111ll_l1_+title,link,652,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᒇ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒈ"),l111ll_l1_+title,link,653,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᒉ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒊ"),l111ll_l1_+title,link,651,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒋ"),l111ll_l1_+title,link,653,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᒌ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᒍ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒎ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᒏ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠧࠤࠩᒐ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪᒑ")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫᒒ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒓ"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪᒔ")+title,link,651)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᒕ"),l11lll_l1_ (u"࠭ࠧᒖ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᒗ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᒘ"),url,l11lll_l1_ (u"ࠩࠪᒙ"),l11lll_l1_ (u"ࠪࠫᒚ"),l11lll_l1_ (u"ࠫࠬᒛ"),l11lll_l1_ (u"ࠬ࠭ᒜ"),l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᒝ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᒞ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᒟ"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠩࠪᒠ")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪᒡ"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ᒢ"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠬࠩࠧᒣ"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒤ"),l111ll_l1_+title,url,653,l1llll_l1_,l11lll_l1_ (u"ࠧࠨᒥ"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᒦ"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪᒧ"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᒨ")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᒩ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᒪ")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᒫ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᒬ")+l1ll1_l1_+l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒭ"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᒮ"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᒯ"),l11lll_l1_ (u"ࠫࠬᒰ"),l11lll_l1_ (u"ࠬ࠭ᒱ"),l11lll_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᒲ"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᒳ"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒴ"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"ࠩ࠱࠳ࠬᒵ"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᒶ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᒷ"))
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᒸ"),l11lll_l1_ (u"࠭ࠠࠨᒹ"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᒺ"),l111ll_l1_+title,link,652,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᒻ"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᒼ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᒽ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᒾ"))
		#		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᒿ"),l111ll_l1_+title,link,652,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᓀ"),l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪᓁ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᓂ"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪᓃ"),l11lll_l1_ (u"ࠪࠫᓄ"),l11lll_l1_ (u"ࠫࠬᓅ"),l11lll_l1_ (u"ࠬ࠭ᓆ"),l11lll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᓇ"))
	html = response.content
	# l1l11llll_l1_ link
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᓈ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		link = re.findall(l11lll_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᓉ"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᓊ"))
			l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᓋ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫࠬ࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦ࠰ࡹࡷࡲ࠽࡜ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࠫࠧࡣ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬᓌ"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᓍ"))
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᓎ")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᓏ"))
				l1111_l1_.append(link)
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ࠲ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨࠫࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲ࠲࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡃࡔࡖࡘࡊࡐ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡵࡳ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍࠎࠏ࡮ࡢ࡯ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧᓐ")
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᓑ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᓒ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬᓓ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭ᓔ"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨᓕ"),l11lll_l1_ (u"ࠧࠬࠩᓖ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩᓗ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᓘ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧᓙ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᓚ"))
	return
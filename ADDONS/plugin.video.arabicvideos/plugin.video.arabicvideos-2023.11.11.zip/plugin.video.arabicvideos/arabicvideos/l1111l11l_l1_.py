# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᗄ")
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᗅ"):l11lll_l1_ (u"ࠩࠪᗆ")}
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡈ࠺ࡕࡠࠩᗇ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨᗈ"),l11lll_l1_ (u"ࠬอฮา์ࠪᗉ"),l11lll_l1_ (u"࠭วฯำ์ࠫᗊ"),l11lll_l1_ (u"ࠧศๆิส๏ู๊สࠩᗋ"),l11lll_l1_ (u"ࠨสา์๋ࠦลฯฬํหึ࠭ᗌ"),l11lll_l1_ (u"ࠩสๅ้อๅࠨᗍ"),l11lll_l1_ (u"ุ้๊ࠪำๅษอࠫᗎ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l1111l_l1_(url,text)
	elif mode==422: results = l1llll1l11_l1_(url)
	elif mode==423: results = l1llllll_l1_(url)
	elif mode==424: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗏ")+text)
	elif mode==425: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᗐ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l111111l1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1lllll111_l1_(l11lll_l1_ (u"࠭ࡇࡆࡖࠪᗑ"),l11ll1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨᗒ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᗓ"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪᗔ"),l11lll_l1_ (u"ࠪࠫᗕ"),l11lll_l1_ (u"ࠫࠬᗖ"),l11lll_l1_ (u"ࠬ࠭ᗗ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᗘ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗙ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠨ࠱ࠪᗚ"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ᗛ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗜ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᗝ"),l11lll_l1_ (u"ࠬ࠭ᗞ"),429,l11lll_l1_ (u"࠭ࠧᗟ"),l11lll_l1_ (u"ࠧࠨᗠ"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᗡ"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᗣ"),l1ll1l1_l1_,425)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗤ"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᗥ"),l1ll1l1_l1_,424)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᗦ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗧ"),l11lll_l1_ (u"ࠨࠩᗨ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗩ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗪ")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᗫ"),l1ll1l1_l1_,421)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗬ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗭ")+l111ll_l1_+l11lll_l1_ (u"ࠧฤใ็ห๊ࠦวๅ่ฯ์๊࠭ᗮ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴ࠱ࠪᗯ"),421)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗰ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗱ")+l111ll_l1_+l11lll_l1_ (u"๋ࠫ๐สโๆๆืࠬᗲ"),l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾ࠯ࠨᗳ"),421)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᗴ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗵ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴࠩᗶ") in link: title = l11lll_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨᗷ")
		elif l11lll_l1_ (u"ࠪ࠳ࡳ࡫ࡴࡧ࡮࡬ࡼࠬᗸ") in link: title = l11lll_l1_ (u"ࠫศ็ไศ็ࠣ์ู๊ไิๆสฮࠥ์๊หใ็็ุ࠭ᗹ")
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗺ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗻ")+l111ll_l1_+title,link,421)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗼ"),l111ll_l1_+l11lll_l1_ (u"ࠨไสส๊ฯࠠหใุ๎้๐ษࠨᗽ"),l1ll1l1_l1_,427)
	return
def l111111l1_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠩࠪᗾ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᗿ"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬᘀ"),l11lll_l1_ (u"ࠬ࠭ᘁ"),l11lll_l1_ (u"࠭ࠧᘂ"),l11lll_l1_ (u"ࠧࠨᘃ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᘄ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪᘅ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪࠡࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠪ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘆ"),block,re.DOTALL)
	for category,id,link,title in items:
		if title in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᘇ") in link: title = l11lll_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬᘈ")
		elif l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠳࡮ࡦࡶࡩࡰ࡮ࡾࠧᘉ") in link: title = l11lll_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩᘊ")
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘋ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᘌ")+l111ll_l1_+title,link,421,l11lll_l1_ (u"ࠪࠫᘍ"),l11lll_l1_ (u"ࠫࠬᘎ"),category+l11lll_l1_ (u"ࠬࢂࠧᘏ")+id)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"࠭ࠧᘐ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᘑ"),l11lll_l1_ (u"ࠨࠩᘒ"),l1111l111_l1_,url)
	if l11lll_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᘓ") in url: url = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬᘔ"))+l11lll_l1_ (u"ࠫ࠴ࡳࡰࡢࡣ࠲ࡪࡦࡳࡩ࡭ࡻ࠲ࠫᘕ")
	items = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩᘖ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᘗ"),url,l11lll_l1_ (u"ࠧࠨᘘ"),headers,l11lll_l1_ (u"ࠨࠩᘙ"),l11lll_l1_ (u"ࠩࠪᘚ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᘛ"))
	html = response.content
	if not l1111l111_l1_ or l11lll_l1_ (u"ࠫࢁ࠭ᘜ") in l1111l111_l1_:
		#if l11lll_l1_ (u"ࠬࡓࡵ࡭ࡶ࡬ࡊ࡮ࡲࡴࡦࡴࠪᘝ") in html:
		#	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘞ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪᘟ"),url,425)
		#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘠ"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬᘡ"),url,424)
		#	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘢ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘣ"),l11lll_l1_ (u"ࠬ࠭ᘤ"),9999)
		if l11lll_l1_ (u"࠭ࡼࠨᘥ") not in l1111l111_l1_: l1111111l_l1_ = l11lll_l1_ (u"ࠧࠨᘦ")
		else: l1111111l_l1_ = l11lll_l1_ (u"ࠨ࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠲ࠫᘧ")+l1111l111_l1_
		separator = False
		if l11lll_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶࠬᘨ") in html:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘩ"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᘪ"),url,421,l11lll_l1_ (u"ࠬ࠭ᘫ"),l11lll_l1_ (u"࠭ࠧᘬ"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᘭ"))
			separator = True
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠭ᘮ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l1_l1_ = l1l1ll1_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡥࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᘯ"),l11l1_l1_,re.DOTALL)
			for l1llllllll_l1_,l1lll1lll_l1_ in l1l1lll_l1_:
				l1lllllll1_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡥࡨࡲࡹ࡫ࡲ࠰ࡣࡦࡸ࡮ࡵ࡮࠰ࡊࡲࡱࡪࡶࡡࡨࡧࡏࡳࡦࡪࡥࡳ࠱ࡷࡥࡧ࠵ࠧᘰ")+l1llllllll_l1_+l1111111l_l1_+l11lll_l1_ (u"ࠫ࠴࠭ᘱ")
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘲ"),l111ll_l1_+l1lll1lll_l1_,l1lllllll1_l1_,421)
				separator = True
		if separator: addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᘳ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᘴ"),l11lll_l1_ (u"ࠨࠩᘵ"),9999)
	if l1111l111_l1_==l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᘶ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡲࡴࡪࡈ࡬ࡰࡹ࡫ࡲࠨᘷ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡕ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᘸ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"ࠬ࠭ᘹ")
	elif l11lll_l1_ (u"࠭࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᘺ") in url or l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡤࡧࡱࡸࡪࡸ࠯ࠨᘻ") in url:
		block = html
	elif l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪᘼ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡓࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠯ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠭ࠫᘽ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫᘾ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠪࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠯࠭ᘿ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡆࡩࡴࡰࡴࡑࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙀ"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡃࡪ࡯ࡤ࠸ࡺࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭ᙁ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: block = l11lll_l1_ (u"ࠧࠨᙂ")
	if not items: items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨࠪ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠯ࠬࡂࡆࡴࡾࡔࡪࡶ࡯ࡩࡎࡴࡦࡰ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩᙃ"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᙄ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if not title: continue
		if l11lll_l1_ (u"ࠪࡃࡳ࡫ࡷࡴ࠿ࠪᙅ") in link: continue
		title = title.replace(l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬᙆ"),l11lll_l1_ (u"ࠬ࠭ᙇ"))
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧᙈ"),title,re.DOTALL)
		if l1lll11_l1_ and l11lll_l1_ (u"ࠧฮๆๅอࠬᙉ") in title:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᙊ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙋ"),l111ll_l1_+title,link,422,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴ࠲ࠫᙌ") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙍ"),l111ll_l1_+title,link,421,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙎ"),l111ll_l1_+title,link,422,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙏ"),html,re.DOTALL)
	if l1l1ll1_l1_ and l1111l111_l1_!=l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᙐ"):
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛࡝ࠩ࡟ࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭࡜ࠣ࡟ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙑ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠩสฺ่็อสࠢࠪᙒ"),l11lll_l1_ (u"ࠪࠫᙓ"))
			if title!=l11lll_l1_ (u"ࠫࠬᙔ"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙕ"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬᙖ")+title,link,421)
	l11111l11_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽࠱࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙗ"),html,re.DOTALL)
	if l11111l11_l1_:
		link,title = l11111l11_l1_[0]
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙘ"),l111ll_l1_+title,link,421)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᙙ"),url,l11lll_l1_ (u"ࠪࠫᙚ"),l11lll_l1_ (u"ࠫࠬᙛ"),l11lll_l1_ (u"ࠬ࠭ᙜ"),l11lll_l1_ (u"࠭ࠧᙝ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠳ࡶࡸࠬᙞ"))
	html = response.content
	# l11ll1l1l_l1_/download main l11l1ll1_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡎࡰࡹࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᙟ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		url = l1l1ll1_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᙠ"),url,l11lll_l1_ (u"ࠪࠫᙡ"),l11lll_l1_ (u"ࠫࠬᙢ"),l11lll_l1_ (u"ࠬ࠭ᙣ"),l11lll_l1_ (u"࠭ࠧᙤ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠴ࡱࡨࠬᙥ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᙦ"),l11lll_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᙧ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡗࡪࡧࡳࡰࡰࡶࡗࡪࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᙨ"),html,re.DOTALL)
	# l1llll1ll1_l1_ l11111111_l1_
	if l11lll_l1_ (u"ࠫ࠴ࡺࡡࡨ࠱ࠪᙩ") in url or l11lll_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࠬᙪ") in url:
		l1111l_l1_(url)
	# l1lllll_l1_
	elif l1l1ll1_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᙫ"))
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨᙬ"),block,re.DOTALL)
		l1lllll11l_l1_ = [l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ᙭"),l11lll_l1_ (u"่ࠩ์ุ๋ࠧ᙮"),l11lll_l1_ (u"ࠪฬึ์วๆฮࠪᙯ"),l11lll_l1_ (u"ࠫา๊โสࠩᙰ")]
		for link,title in items:
			if any(value in title for value in l1lllll11l_l1_):
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙱ"),l111ll_l1_+title,link,423,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᙲ"),l111ll_l1_+title,link,426,l1llll_l1_)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᙳ"),url,l11lll_l1_ (u"ࠨࠩᙴ"),l11lll_l1_ (u"ࠩࠪᙵ"),l11lll_l1_ (u"ࠪࠫᙶ"),l11lll_l1_ (u"ࠫࠬᙷ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᙸ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᙹ"),l11lll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᙺ"))
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᙻ"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠩࠪᙼ")
	# l1l1l_l1_
	l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࡷࡘ࡫ࡣࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᙽ"),html,re.DOTALL)
	if l1llll1l1l_l1_:
		block = l1llll1l1l_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙾ"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠬࠦࠧᙿ")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ "),l111ll_l1_+title,link,426,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᚁ"),l111ll_l1_+l11lll_l1_ (u"ࠨำสฬ฼ࠦวๅฬื฾๏๊ࠧᚂ"),url,426,l1llll_l1_)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᚃ"),url,l11lll_l1_ (u"ࠪࠫᚄ"),headers,l11lll_l1_ (u"ࠫࠬᚅ"),l11lll_l1_ (u"ࠬ࠭ᚆ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᚇ"))
	html = response.content
	#newurl = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡷࡽࡱ࡫ࡳࡩࡧࡨࡸࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚈ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᚉ"))
	l1ll1l1_l1_ = SERVER(newurl,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ᚊ"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	#if kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᚋ"),l11lll_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᚌ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡝ࡡࡵࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᚍ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᚎ"),block,re.DOTALL)
		for l1l11111_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩᚏ"))
			if l11lll_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧᚐ") in title.lower(): title = l11lll_l1_ (u"ࠩัหฺࠦࠧᚑ")+title
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸࡺࡲࡶࡥࡷࡹࡷ࡫࠯ࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨᚒ")+l1l11111_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᚓ")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᚔ")
			#link = link.replace(l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡦ࠺ࡵ࠯࡫ࡦࡹࠬᚕ"),l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻ࠮࡮ࡺࠪᚖ"))
			link = link.replace(l11lll_l1_ (u"ࠨ࡞ࡵࠫᚗ"),l11lll_l1_ (u"ࠩࠪᚘ"))
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡘ࡫ࡲࡷࡧࡵࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨᚙ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠦ࠯࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᚚ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ᚛"))
			if l11lll_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬ᚜") in title.lower(): l1lll1lll_l1_ = l11lll_l1_ (u"ࠧࡠࡡัหฺ࠭᚝")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ࠨࠩ᚞")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᚟")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᚠ")+l1lll1lll_l1_
			link = link.replace(l11lll_l1_ (u"ࠫࡡࡸࠧᚡ"),l11lll_l1_ (u"ࠬ࠭ᚢ"))
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᚣ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᚤ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩᚥ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪᚦ"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬᚧ"),l11lll_l1_ (u"ࠫ࠰࠭ᚨ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡓࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩᚩ")+search
	l1111l_l1_(url,l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᚪ"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	if l11lll_l1_ (u"ࠧࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࠩᚫ") not in url: url = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᚬ"))
	else: url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᚭ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᚮ"),url,l11lll_l1_ (u"ࠫࠬᚯ"),l11lll_l1_ (u"ࠬ࠭ᚰ"),l11lll_l1_ (u"࠭ࠧᚱ"),l11lll_l1_ (u"ࠧࠨᚲ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪᚳ"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡐࡹࡱࡺࡩࡇ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᚴ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡌࡴࡼࡥࡳࡣࡥࡰࡪ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࠤࡤࡰࡱࠨ࠮ࠫࡁࠫࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᚵ"),block,re.DOTALL)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id + title
	items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᚶ"),block,re.DOTALL)
	return items
def l111111ll_l1_(url):
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᚷ"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪᚸ"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᚹ"),l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡣࡦࡰࡷࡩࡷ࠵ࡡࡤࡶ࡬ࡳࡳ࠵ࡈࡰ࡯ࡨࡴࡦ࡭ࡥࡍࡱࡤࡨࡪࡸ࠯ࠨᚺ"))
	url = url.replace(l11lll_l1_ (u"ࠩࡀࠫᚻ"),l11lll_l1_ (u"ࠪ࠳ࠬᚼ")).replace(l11lll_l1_ (u"ࠫࠫ࠭ᚽ"),l11lll_l1_ (u"ࠬ࠵ࠧᚾ"))
	url = url+l11lll_l1_ (u"࠭࠯ࠨᚿ")
	return url
l1l11lll_l1_ = [l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᛀ"),l11lll_l1_ (u"ࠨࡶࡼࡴࡪࡹࠧᛁ"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᛂ")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠫᛃ"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪᛄ"),l11lll_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᛅ"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᛆ")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᛇ"),l11lll_l1_ (u"ࠨࠩᛈ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᛉ"),l11lll_l1_ (u"ࠪࠫᛊ"),filter,url)
	if l11lll_l1_ (u"ࠫࡄ࠭ᛋ") in url: url = url.split(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᛌ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪᛍ"),1)
	if filter==l11lll_l1_ (u"ࠧࠨᛎ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠨࠩᛏ"),l11lll_l1_ (u"ࠩࠪᛐ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧᛑ"))
	if type==l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᛒ"):
		if l11lll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᛓ") in url:
			global l1l11lll_l1_
			l1l11lll_l1_ = l1l11lll_l1_[1:]
		if l1l11lll_l1_[0]+l11lll_l1_ (u"࠭࠽ࠨᛔ") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠧ࠾ࠩᛕ") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪᛖ")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬᛗ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬᛘ")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧᛙ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧᛚ"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪᛛ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩᛜ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᛝ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᛞ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ᛟ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᛠ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠬ࠭ᛡ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᛢ"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠧࠨᛣ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᛤ")+l1l11l11_l1_
		l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᛥ"),l111ll_l1_+l11lll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ᛦ"),l11l11l_l1_,421,l11lll_l1_ (u"ࠫࠬᛧ"),l11lll_l1_ (u"ࠬ࠭ᛨ"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᛩ"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛪ"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ᛫")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ᛬"),l11l11l_l1_,421,l11lll_l1_ (u"ࠪࠫ᛭"),l11lll_l1_ (u"ࠫࠬᛮ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᛯ"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᛰ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᛱ"),l11lll_l1_ (u"ࠨࠩᛲ"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		if l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᛳ") in url and l1ll1lll_l1_==l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᛴ"): continue
		name = name.replace(l11lll_l1_ (u"ࠫ࠲࠳ࠧᛵ"),l11lll_l1_ (u"ࠬ࠭ᛶ"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"࠭࠽ࠨᛷ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᛸ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l111111ll_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ᛹")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᛺"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠪ᛻"),l11l11l_l1_,421,l11lll_l1_ (u"ࠫࠬ᛼"),l11lll_l1_ (u"ࠬ࠭᛽"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭᛾"))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᛿"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠨᜀ"),l11l11l_l1_,425,l11lll_l1_ (u"ࠩࠪᜁ"),l11lll_l1_ (u"ࠪࠫᜂ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧᜃ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧᜄ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩᜅ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩᜆ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿࠳ࠫᜇ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ᜈ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜉ"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᜊ")+name,l11l11l_l1_,424,l11lll_l1_ (u"ࠬ࠭ᜋ"),l11lll_l1_ (u"࠭ࠧᜌ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᜍ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨᜎ"): option = l11lll_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩᜏ")
			elif value==l11lll_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪᜐ"): option = l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭ᜑ")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᜒ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧᜓ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"᜔ࠧࠧࠩ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿᜕ࠪ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ᜖")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ᜗")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ᜘")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ᜙")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"࠭࠰ࠨ᜚")]
			title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ᜛")+name
			if type==l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ᜜"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᜝"),l111ll_l1_+title,url,424,l11lll_l1_ (u"ࠪࠫ᜞"),l11lll_l1_ (u"ࠫࠬᜟ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᜠ"))
			elif type==l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩᜡ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠧ࠾ࠩᜢ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᜣ"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᜤ")+l1l1111l_l1_
				l11l1l1_l1_ = l111111ll_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᜥ"),l111ll_l1_+title,l11l1l1_l1_,421,l11lll_l1_ (u"ࠫࠬᜦ"),l11lll_l1_ (u"ࠬ࠭ᜧ"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᜨ"))
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜩ"),l111ll_l1_+title,url,425,l11lll_l1_ (u"ࠨࠩᜪ"),l11lll_l1_ (u"ࠩࠪᜫ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᜬ"),l11lll_l1_ (u"ࠫࠬᜭ"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭ᜮ"))
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᜯ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᜰ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬᜱ")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠩࡀࠪࠬᜲ"),l11lll_l1_ (u"ࠪࡁ࠵ࠬࠧᜳ"))
	filters = filters.strip(l11lll_l1_ (u"᜴ࠫࠫ࠭"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠬࡃࠧ᜵") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠨ᜶"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ᜷"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠨࠩ᜸")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠩ࠳ࠫ᜹")
		if l11lll_l1_ (u"ࠪࠩࠬ᜺") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭᜻") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ᜼"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠠࠬࠢࠪ᜽")+value
		elif mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ᜾") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ᜿"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫᝀ")+key+l11lll_l1_ (u"ࠪࡁࠬᝁ")+value
		elif mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨᝂ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧᝃ")+key+l11lll_l1_ (u"࠭࠽ࠨᝄ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫᝅ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪᝆ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠩࡀ࠴ࠬᝇ"),l11lll_l1_ (u"ࠪࡁࠬᝈ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᝉ"),l11lll_l1_ (u"ࠬ࠭ᝊ"),filters,l11lll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᝋ"))
	return l1ll1l1l_l1_
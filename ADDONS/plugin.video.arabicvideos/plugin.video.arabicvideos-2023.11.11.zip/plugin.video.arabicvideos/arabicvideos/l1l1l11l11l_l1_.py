# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㌜")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡌࡑࡉ࡟ࠨ㌝")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺ้ࠪอัฺหࠪ㌞"),l11lll_l1_ (u"ࠫฬำฯฬࠢส่อืวๆฮࠪ㌟"),l11lll_l1_ (u"ࠬออะอࠣห้อไฺษหࠫ㌠"),l11lll_l1_ (u"࠭วฮัฮࠤฬ๊ว฻ษ้ํࠬ㌡")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l1111l_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l1llllll_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ㌢"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㌣"),l11lll_l1_ (u"ࠩࠪ㌤"),l11lll_l1_ (u"ࠪࠫ㌥"),l11lll_l1_ (u"ࠫࠬ㌦"),l11lll_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㌧"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ㌨"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㌩"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㌪"),l11lll_l1_ (u"ࠩࠪ㌫"),89,l11lll_l1_ (u"ࠪࠫ㌬"),l11lll_l1_ (u"ࠫࠬ㌭"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㌮"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㌯"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㌰"),l11lll_l1_ (u"ࠨࠩ㌱"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㌲"),l111ll_l1_+l11lll_l1_ (u"ࠪหำะั็ษ่่ࠣ࠭㌳"),l1ll1l1_l1_,81,l11lll_l1_ (u"ࠫࠬ㌴"),l11lll_l1_ (u"ࠬ࠭㌵"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㌶"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㌷"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㌸"),block,re.DOTALL)
	for l1111l111_l1_,title in items:
		link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࡁ࡬ࡸࡪࡳ࠽ࠨ㌹")+l1111l111_l1_+l11lll_l1_ (u"ࠪࠪࡆࡰࡡࡹ࠿࠴ࠫ㌺")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌻"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㌼")+l111ll_l1_+title,link,81)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㌽"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㌾"),l11lll_l1_ (u"ࠨࠩ㌿"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡲࡦࡼ࠭࡮ࡣ࡬ࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡴࡡࡷࡀࠪ㍀"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㍁"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠫࠨ࠭㍂"): continue
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㍃"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㍄")+l111ll_l1_+title,link,81)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠧࠨ㍅")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㍆"),l11lll_l1_ (u"ࠩࠪ㍇"),url)
	items = []
	# l1llll111l_l1_ l1llll11l1_l1_
	if l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪ㍈") in url or l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬ㍉") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㍊"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭㍋")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ㍌"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ㍍"),l11lll_l1_ (u"ࠩࠪ㍎"),l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㍏"))
		html = response.content
		l1l1ll1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ㍐"),url,l11lll_l1_ (u"ࠬ࠭㍑"),l11lll_l1_ (u"࠭ࠧ㍒"),l11lll_l1_ (u"ࠧࠨ㍓"),l11lll_l1_ (u"ࠨࠩ㍔"),l11lll_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㍕"))
		html = response.content
		# l1111l111_l1_ items
		if l1111l111_l1_==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㍖"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ㍗"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㍘"),block,re.DOTALL)
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㍙"),l11lll_l1_ (u"ࠧࠨ㍚"),l11lll_l1_ (u"ࠨࠩ㍛"))
		# l1llll1ll1_l1_ l111ll11_l1_
		elif l11lll_l1_ (u"ࠩࠥࡷࡪࡩࡴࡪࡱࡱ࠱ࡵࡵࡳࡵࠢࡰࡦ࠲࠷࠰ࠣࠩ㍜") in html:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡶ࡯ࡴࡶࠣࡱࡧ࠳࠱࠱ࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ㍝"),html,re.DOTALL)
		else:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ㍞"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	if not items:
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡴࡸࡩࡨ࡫ࡱࡥࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㍟"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㍠"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧ㍡"),l11lll_l1_ (u"ࠨใํ่๊࠭㍢"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨ㍣"),l11lll_l1_ (u"ࠪ็้๐ศࠨ㍤"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪ㍥"),l11lll_l1_ (u"ࠬํฯศใࠪ㍦"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭㍧"),l11lll_l1_ (u"ฺࠧำูࠫ㍨"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ㍩"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ㍪")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ㍫"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ㍬"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ㍭") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍮"),l111ll_l1_+title,link,83,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧิๆสื้࠭㍯") not in url and any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㍰"),l111ll_l1_+title,link,82,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠩส่า๊โสࠩ㍱") in title:
			title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㍲") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㍳"),l111ll_l1_+title,link,83,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ㍴") in link:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍵"),l111ll_l1_+title,link,81,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㍶"),l111ll_l1_+title,link,83,l1llll_l1_)
	if l1111l111_l1_==l11lll_l1_ (u"ࠨࠩ㍷"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷ࠭㍸"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㍹"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠦࠧ㍺"): continue
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠬ࠭㍻"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㍼"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭㍽")+title,link,81)
	if l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ㍾") in url or l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ㍿") in url:
		if l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪ㎀") in url:
			url = url.replace(l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫ㎁"),l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭㎂"))+l11lll_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽࠳࠲ࠪ㎃")
		elif l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ㎄") in url:
			url,offset = url.split(l11lll_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿ࠪ㎅"))
			offset = int(offset)+20
			url = url+l11lll_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀࠫ㎆")+str(offset)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㎇"),l111ll_l1_+l11lll_l1_ (u"ࠫ์์วไࠢสุ่๊๊ะࠩ㎈"),url,81)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㎉"),url,l11lll_l1_ (u"࠭ࠧ㎊"),l11lll_l1_ (u"ࠧࠨ㎋"),l11lll_l1_ (u"ࠨࠩ㎌"),l11lll_l1_ (u"ࠩࠪ㎍"),l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㎎"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡭ࡥࡵࡕࡨࡥࡸࡵ࡮ࡴࡄࡼࡗࡪࡸࡩࡦࡵࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬ㎏"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡬ࡪࡵࡷ࠱ࡪࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ㎐"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ㎑") not in url:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㎒"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㎓"),l111ll_l1_+title,link,83,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥ࡭ࡲࡧࡧࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㎔"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㎕"),block,re.DOTALL)
		for link,title in items:
			#title = title.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ㎖"),l11lll_l1_ (u"ࠬ࠭㎗")).strip(l11lll_l1_ (u"࠭ࠠࠨ㎘"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㎙"),l111ll_l1_+title,link,82,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㎚"),l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㎛"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㎜"),l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㎝"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㎞"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㎟"),l11lll_l1_ (u"ࠧࠨ㎠"),l11lll_l1_ (u"ࠨࠩ㎡"),l11lll_l1_ (u"ࠩࠪ㎢"),l11lll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㎣"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ㎤"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㎥"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11llll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡍࡉࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ㎦"),html,re.DOTALL)
		l11llll1_l1_ = l11llll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠢࡨࡧࡷࡔࡱࡧࡹࡦࡴ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠢ㎧"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ㎨"),l11lll_l1_ (u"ࠩࠪ㎩")).strip(l11lll_l1_ (u"ࠪࠤࠬ㎪"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡅࡳࡦࡴࡹࡩࡷࡃࠧ㎫")+server+l11lll_l1_ (u"ࠬࠬࡰࡰࡵࡷࡍࡉࡃࠧ㎬")+l11llll1_l1_+l11lll_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧ㎭")
			link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㎮")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㎯")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡴࡽ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㎰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㎱"),block,re.DOTALL)
		for link,name in items:
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㎲")+name+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㎳")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㎴"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㎵"),url)
	return
l11lll_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡒࡏࡅ࡞ࡥࡏࡍࡆࠫࡹࡷࡲࠩ࠻ࠌࠌࡨࡦࡺࡡࠡ࠿ࠣࡿࠬ࡜ࡩࡦࡹࠪ࠾࠶ࢃࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡀࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ࡽࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࠪࡔࡔ࡙ࡔࠨ࠮ࡸࡶࡱ࠲ࡤࡢࡶࡤ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞ࠌࠌࠧࠥࡽࡡࡵࡥ࡫ࠤࡱ࡯࡮࡬ࡵࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡻࡦࡺࡣࡩࡃࡵࡩࡦࡓࡡࡴࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡺࡥࡹࡩࡨࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠤࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡱ࡯࡮࡬ࡵࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡨࡴࡴࡷ࡭ࡱࡤࡨ࠲ࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡳࡦࡴ࠰ࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠬࡲࡷࡤࡰ࡮ࡺࡹ࠭࡮࡬ࡲࡰࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧࠬࠩࡢࡣࡤࡥࠧࠬࡳࡸࡥࡱ࡯ࡴࡺࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪࠌࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࡃ࠽࠱࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࠯ࠫฬ๊ัศสฺࠤ้๐ำࠡใํ๋ࠥ็๊ะ์๋ࠫ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖࠎࠎࠏࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡺࡸ࡬ࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨ㎶")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ㎷"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ㎸"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭㎹"),l11lll_l1_ (u"ࠬ࠳ࠧ㎺"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ㎻")+search+l11lll_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭㎼")
	l1111l_l1_(url)
	return
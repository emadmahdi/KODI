# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ㎽")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ㎾")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
l1l11lll1ll_l1_ = l1ll11l_l1_[script_name][2]
l1l11llll1l_l1_ = l1ll11l_l1_[script_name][3]
#l1l1l1111ll_l1_  = l1ll11l_l1_[script_name][4]
#l1l1l1111ll_l1_  = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==20: results = l1l11lllll1_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==23: results = l1llllll_l1_(url,l1l11l1_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l11ll11l1_l1_(url)
	elif mode==27: results = l1l1lll1l_l1_(url)
	elif mode==28: results = l1l1l11111l_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l11lllll1_l1_():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㎿"),l111ll_l1_+l11lll_l1_ (u"ࠫ฾ืศ๋ࠩ㏀"),l11ll1_l1_,21,l11lll_l1_ (u"ࠬ࠭㏁"),l11lll_l1_ (u"࠭࠱࠱࠳ࠪ㏂"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㏃"),l111ll_l1_+l11lll_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ㏄"),l11lllll11_l1_,21,l11lll_l1_ (u"ࠩࠪ㏅"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㏆"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏇"),l111ll_l1_+l11lll_l1_ (u"ࠬ็วาี์ࠫ㏈"),l1l11lll1ll_l1_,21,l11lll_l1_ (u"࠭ࠧ㏉"),l11lll_l1_ (u"ࠧ࠲࠲࠴ࠫ㏊"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㏋"),l111ll_l1_+l11lll_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ㏌"),l1l11llll1l_l1_,21,l11lll_l1_ (u"ࠪࠫ㏍"),l11lll_l1_ (u"ࠫ࠶࠶࠱ࠨ㏎"))
	return
def l1l1l11111l_l1_():
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪ㏏"),l111ll_l1_+l11lll_l1_ (u"ู࠭าสํࠫ㏐"),l11ll1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㏑"),l111ll_l1_+l11lll_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ㏒"),l11lllll11_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㏓"),l111ll_l1_+l11lll_l1_ (u"ࠪๅฬืำ๊ࠩ㏔"),l1l11lll1ll_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㏕"),l111ll_l1_+l11lll_l1_ (u"ࠬ็วาี์ࠤ࠷࠭㏖"),l1l11llll1l_l1_,27)
	return
def MENU(l1l1l1111l1_l1_):
	script_name = l1l1l1111l1_l1_
	if l1l1l1111l1_l1_==l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ㏗"): l1l1l1111l1_l1_ = l11ll1_l1_
	elif l1l1l1111l1_l1_==l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ㏘"): l1l1l1111l1_l1_ = l11lllll11_l1_
	else: script_name = l11lll_l1_ (u"ࠨࠩ㏙")
	l1ll1111111_l1_ = l1l1l111l11_l1_(l1l1l1111l1_l1_)
	if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡤࡶࠬ㏚") or script_name==l11lll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ㏛"):
		l1l11ll1l11_l1_ = l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㏜")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡฯส่๏ฯࠧ㏝")
		l1ll111lll1_l1_ = l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢฦัิัࠧ㏞")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣวอาฯ๋ࠩ㏟")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"ࠨสฮࠤา๐ࠠร์ࠣๅ๏๊ๅࠨ㏠")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠩฦๅ้อๅࠨ㏡")
		l1l11lll11l_l1_ = l11lll_l1_ (u"้ࠪํู๊ใ๋ࠪ㏢")
		l1l11lll111_l1_ = l11lll_l1_ (u"ࠫอืวๆฮࠪ㏣")
	elif l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㏤") or script_name==l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭㏥"):
		l1l11ll1l11_l1_ = l11lll_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡪࡰࠣࡷ࡮ࡺࡥࠨ㏦")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡇࡺࡸࡲࡦࡰࡷࠫ㏧")
		l1ll111lll1_l1_ = l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡑࡧࡴࡦࡵࡷࠫ㏨")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡇ࡬ࡱࡪࡤࡦࡪࡺࠧ㏩")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"ࠫࡑ࡯ࡶࡦࠢ࡬ࡊ࡮ࡲ࡭ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠩ㏪")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࡷࠬ㏫")
		l1l11lll11l_l1_ = l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ㏬")
		l1l11lll111_l1_ = l11lll_l1_ (u"ࠧࡔࡪࡲࡻࡸ࠭㏭")
	elif l1ll1111111_l1_ in [l11lll_l1_ (u"ࠨࡨࡤࠫ㏮"),l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㏯")]:
		l1l11ll1l11_l1_ = l11lll_l1_ (u"ࠪะุะฬ้ࠢาีูࠥวໍฬࠪ㏰")
		l1l11ll11ll_l1_ = l11lll_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥาวา໎ࠪ㏱")
		l1ll111lll1_l1_ = l11lll_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦยฯำ໏๊ࠬ㏲")
		l1l11ll1l1l_l1_ = l11lll_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠศๆไฬฬ࠭㏳")
		l1l11ll1lll_l1_ = l11lll_l1_ (u"ࠧ๿ะืࠤื์ฯ่ࠢส๎ࠥ็๊ๅ็ࠪ㏴")
		l1l11ll1ll1_l1_ = l11lll_l1_ (u"ࠨใํ่๊࠭㏵")
		l1l11lll11l_l1_ = l11lll_l1_ (u"่ࠩ์ุ๐โ๊ࠩ㏶")
		l1l11lll111_l1_ = l11lll_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬ࠭㏷")
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㏸"),l111ll_l1_+l1l11ll1l11_l1_,l1l1l1111l1_l1_,29,l11lll_l1_ (u"ࠬ࠭㏹"),l11lll_l1_ (u"࠭ࠧ㏺"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㏻"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㏼"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㏽")+l111ll_l1_+l1l11ll1lll_l1_,l1l1l1111l1_l1_,27)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㏾"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㏿"),l11lll_l1_ (u"ࠬ࠭㐀"),9999)
	menu = [l11lll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭㐁"),l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㐂"),l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㐃")]
	html = OPENURL_CACHED(l11111l_l1_,l1l1l1111l1_l1_+l11lll_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ㐄"),l11lll_l1_ (u"ࠪࠫ㐅"),l11lll_l1_ (u"ࠫࠬ㐆"),l11lll_l1_ (u"ࠬ࠭㐇"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㐈"))
	l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠲ࡇࡴࡴࡴࡢࡥࡷࠫ㐉"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㐊"),block,re.DOTALL)
		for link,title in items:
			if any(value in link for value in menu):
				url = l1l1l1111l1_l1_+link
				if l11lll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ㐋") in link:
					addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㐌"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㐍")+l111ll_l1_+l1l11ll11ll_l1_,url,22,l11lll_l1_ (u"ࠬ࠭㐎"),l11lll_l1_ (u"࠭࠱࠱࠲ࠪ㐏"))
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐐"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㐑")+l111ll_l1_+l1ll111lll1_l1_,url,22,l11lll_l1_ (u"ࠩࠪ㐒"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㐓"))
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㐔"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㐕")+l111ll_l1_+l1l11ll1l1l_l1_,url,22,l11lll_l1_ (u"࠭ࠧ㐖"),l11lll_l1_ (u"ࠧ࠳࠲࠴ࠫ㐗"))
				elif l11lll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭㐘") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㐙"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㐚")+l111ll_l1_+l1l11ll1ll1_l1_,url,22,l11lll_l1_ (u"ࠫࠬ㐛"),l11lll_l1_ (u"ࠬ࠷࠰࠱ࠩ㐜"))
				elif l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ㐝") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐞"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㐟")+l111ll_l1_+l1l11lll11l_l1_,url,25,l11lll_l1_ (u"ࠩࠪ㐠"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㐡"))
				elif l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㐢") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐣"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㐤")+l111ll_l1_+l1l11lll111_l1_,url,22,l11lll_l1_ (u"ࠧࠨ㐥"),l11lll_l1_ (u"ࠨ࠳࠳࠵ࠬ㐦"))
	return html
def l1l11ll11l1_l1_(url):
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ㐧"),l11lll_l1_ (u"ࠪࠫ㐨"),l11lll_l1_ (u"ࠫࠬ㐩"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡒ࡛ࡓࡊࡅࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ㐪"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧ࠲ࡺ࡯ࡰ࡮ࡶ࠱࡭࡫ࡡࡥࡧࡵࠬ࠳࠰࠿ࠪࡏࡸࡷ࡮ࡩ࠭ࡣࡱࡧࡽࠬ㐫"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭㐬"),block,re.DOTALL)[0]
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㐭"),l111ll_l1_+title,url,22,l11lll_l1_ (u"ࠩࠪ㐮"),l11lll_l1_ (u"ࠪ࠵࠵࠷ࠧ㐯"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㐰"),block,re.DOTALL)
	for link,title in items:
		link = l1l1l1111l1_l1_ + link
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐱"),l111ll_l1_+title,link,23,l11lll_l1_ (u"࠭ࠧ㐲"),l11lll_l1_ (u"ࠧ࠲࠲࠴ࠫ㐳"))
	return
def l1111l_l1_(url,l1l11l1_l1_):
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	type = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ㐴"))[-1]
	l1l11l1llll_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㐵"),l11lll_l1_ (u"ࠪࠫ㐶"),url, type)
	if type==l11lll_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ㐷") and l1l11l1_l1_==l11lll_l1_ (u"ࠬ࠶ࠧ㐸"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㐹"),l11lll_l1_ (u"ࠧࠨ㐺"),l11lll_l1_ (u"ࠨࠩ㐻"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ㐼"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡸ࡯ࡸࠩ㐽"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠫ࠲࠯ࡅࠩ࠿࠰࠭ࡃ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㐾"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			link = l1l1l1111l1_l1_ + link
			l1llll_l1_ = l1l1l1111l1_l1_ + QUOTE(l1llll_l1_)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐿"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"࠭࠰࠲ࠩ㑀"))
	l1l11ll1111_l1_=0
	if type==l11lll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ㑁"): category=l11lll_l1_ (u"ࠨ࠵ࠪ㑂")
	if type==l11lll_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ㑃"): category=l11lll_l1_ (u"ࠪ࠹ࠬ㑄")
	if type==l11lll_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ㑅"): category=l11lll_l1_ (u"ࠬ࠽ࠧ㑆")
	if type in [l11lll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭㑇"),l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㑈"),l11lll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭㑉")] and l1l11l1_l1_!=l11lll_l1_ (u"ࠩ࠳ࠫ㑊"):
		l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡌࡸࡪࡳ࠿ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ㑋")+category+l11lll_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ㑌")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾ࠩ㑍")+l1l11l1llll_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㑎"),l11lll_l1_ (u"ࠧࠨ㑏"),l11lll_l1_ (u"ࠨࠩ㑐"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ㑑"))
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㑒"),l11lll_l1_ (u"ࠫࠬ㑓"),l11l11l_l1_, html)
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠯ࡄࠨࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㑔"),html,re.DOTALL)
		for id,title,l1llll_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"࠭࡜࡝ࠩ㑕"),l11lll_l1_ (u"ࠧࠨ㑖"))
			title = title.replace(l11lll_l1_ (u"ࠨࠤࠪ㑗"),l11lll_l1_ (u"ࠩࠪ㑘"))
			l1l11ll1111_l1_ += 1
			link = l1l1l1111l1_l1_ + l11lll_l1_ (u"ࠪ࠳ࠬ㑙") + type + l11lll_l1_ (u"ࠫ࠴ࡉ࡯࡯ࡶࡨࡲࡹ࠵ࠧ㑚") + id
			l1llll_l1_ = l1l1l1111l1_l1_ + QUOTE(l1llll_l1_)
			if type==l11lll_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ㑛"): addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㑜"),l111ll_l1_+title,link,24,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"ࠧ࠱࠳ࠪ㑝"))
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㑞"),l111ll_l1_+title,link,23,l1llll_l1_,l1l11l1llll_l1_+l11lll_l1_ (u"ࠩ࠳࠵ࠬ㑟"))
	if type==l11lll_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ㑠"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1111l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡎࡴࡤࡦࡺࡂࡴࡦ࡭ࡥ࠾ࠩ㑡")+l1l11l1_l1_,l11lll_l1_ (u"ࠬ࠭㑢"),l11lll_l1_ (u"࠭ࠧ㑣"),l11lll_l1_ (u"ࠧࠨ㑤"),l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠴ࡴࡧࠫ㑥"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠳ࡤࡦ࡯ࡲࠬ࠳࠰࠿ࠪࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠲ࡪࡥ࡮ࡱࠪ㑦"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ㑧"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			l1l11ll1111_l1_ += 1
			l1llll_l1_ = l1l1l1111l1_l1_ + l1llll_l1_
			link = l1l1l1111l1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑨"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠬ࠷࠰࠲ࠩ㑩"))
	if l1l11ll1111_l1_>20:
		title=l11lll_l1_ (u"࠭ีโฯฬࠤࠬ㑪")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡦࡰࠪ㑫"): title = l11lll_l1_ (u"ࠨࡒࡤ࡫ࡪࠦࠧ㑬")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥࠬ㑭"): title = l11lll_l1_ (u"ูࠪๆำ็ࠡࠩ㑮")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ㑯"): title = l11lll_l1_ (u"ࠬ฻แฮ้ࠣࠫ㑰")
		for l1l11llll11_l1_ in range(1,11) :
			if not l1l11l1_l1_==str(l1l11llll11_l1_):
				l1l11ll111l_l1_ = l11lll_l1_ (u"࠭࠰ࠨ㑱")+str(l1l11llll11_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㑲"),l111ll_l1_+title+str(l1l11llll11_l1_),url,22,l11lll_l1_ (u"ࠨࠩ㑳"),l1l11l1llll_l1_+l1l11ll111l_l1_[-2:])
	return
def l1llllll_l1_(url,l1l11l1_l1_):
	if not l1l11l1_l1_: l1l11l1_l1_ = 0
	l1l1l1111l1_l1_ = l1l11lll1l1_l1_(url)
	l1l1l1111ll_l1_ = l1l11lll1l1_l1_(url)
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	parts = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ㑴"))
	id,type = parts[-1],parts[3]
	l1l11l1llll_l1_ = str(int(l1l11l1_l1_)//100)
	l1l11l1_l1_ = str(int(l1l11l1_l1_)%100)
	l1l11ll1111_l1_ = 0
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㑵"),l11lll_l1_ (u"ࠫࠬ㑶"),url, type)
	if type==l11lll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ㑷"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㑸"),l11lll_l1_ (u"ࠧࠨ㑹"),l11lll_l1_ (u"ࠨࠩ㑺"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㑻"))
		items = re.findall(l11lll_l1_ (u"ࠪࡇࡴࡳ࡭ࡦࡰࡷࡣࡵࡧ࡮ࡦ࡮ࡢࡍࡹ࡫࡭࠯ࠬࡂࡴࡃ࠮࠮ࠫࡁࠬࡀ࡮࠴ࠫࡀࡸࡤࡶࠥ࡯࡮ࡵࡧࡵࡣࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ㑼"),html,re.DOTALL)
		title = l11lll_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ㑽")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㑾"): title = l11lll_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ㑿")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡧࡣࠪ㒀"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ㒁")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㒂"): title = l11lll_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ㒃")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࠧ㒄"): l1l11llllll_l1_ = l11lll_l1_ (u"ࠬ࠭㒅")
		else: l1l11llllll_l1_ = l1ll1111111_l1_
		l1l1l111ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱࡀࠦ࠭࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪࡣ࠮࠮࠮ࠫࡁࠬࠦࡃ࠭㒆"),html,re.DOTALL)
		for name,count,l1llll_l1_,link in items:
			for l1lll11_l1_ in range(int(count),0,-1):
				l1l1l111l1l_l1_ = l1llll_l1_ + l1l11llllll_l1_ + id + l11lll_l1_ (u"ࠧ࠰ࠩ㒇") + str(l1lll11_l1_) + l11lll_l1_ (u"ࠨ࠰ࡳࡲ࡬࠭㒈")
				#l1ll11l1l1l_l1_ = l1l1l111ll1_l1_[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"ࠩ࠲࠰ࠬ㒉")+str(l1lll11_l1_)+l11lll_l1_ (u"ࠪ࠰ࠬ㒊")+str(l1lll11_l1_)+l11lll_l1_ (u"ࠫࡤ࠭㒋")+l1l1l111ll1_l1_[0][2]
				l1l11ll11ll_l1_ = name + title + str(l1lll11_l1_)
				l1l11ll11ll_l1_ = unescapeHTML(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㒌"),l111ll_l1_+l1l11ll11ll_l1_,url,24,l1l1l111l1l_l1_,l11lll_l1_ (u"࠭ࠧ㒍"),str(l1lll11_l1_))
	elif type==l11lll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ㒎"):
		l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡂࡶࡷࡥࡨ࡮࡭ࡦࡰࡷࡍࡹ࡫࡭ࡀ࡫ࡧࡁࠬ㒏")+str(id)+l11lll_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ㒐")+l1l11l1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃ࠱ࠨ㒑")
		html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ㒒"),l11lll_l1_ (u"ࠬ࠭㒓"),l11lll_l1_ (u"࠭ࠧ㒔"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ㒕"))
		items = re.findall(l11lll_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮࠱࠮ࡄࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡄࡪࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㒖"),html,re.DOTALL)
		title = l11lll_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭㒗")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠪࡩࡳ࠭㒘"): title = l11lll_l1_ (u"ࠫࠥ࠳ࠠࡆࡲ࡬ࡷࡴࡪࡥࠡࠩ㒙")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡬ࡡࠨ㒚"): title = l11lll_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ㒛")
		if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡧࡣ࠵ࠫ㒜"): title = l11lll_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ㒝")
		for l1lll11_l1_,l1llll_l1_,link,desc,name in items:
			l1l11ll1111_l1_ += 1
			l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
			#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
			name = escapeUNICODE(name)
			l1l11ll11ll_l1_ = name + title + str(l1lll11_l1_)
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㒞"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠪࠫ㒟"),str(l1l11ll1111_l1_))
	elif type==l11lll_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ㒠"):
		if l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠭㒡") in url and l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ㒢") not in url:
			l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾ࠩ㒣")+str(id)+l11lll_l1_ (u"ࠨࠨࡳࡥ࡬࡫࠽ࠨ㒤")+l1l11l1_l1_+l11lll_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠳ࠫ㒥")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㒦"),l11lll_l1_ (u"ࠫࠬ㒧"),l11lll_l1_ (u"ࠬ࠭㒨"),l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠴ࡴࡧࠫ㒩"))
			items = re.findall(l11lll_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㒪"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = name + l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ㒫") + title
				l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ㒬"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㒭"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠫࠬ㒮"),str(l1l11ll1111_l1_))
		elif l11lll_l1_ (u"ࠬࡉ࡬ࡪࡲࡶࠫ㒯") in url:
			l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ㒰")+l1l11l1_l1_+l11lll_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠲࠷ࠪ㒱")
			html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ㒲"),l11lll_l1_ (u"ࠩࠪ㒳"),l11lll_l1_ (u"ࠪࠫ㒴"),l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠺ࡴࡩࠩ㒵"))
			items = re.findall(l11lll_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㒶"),html,re.DOTALL)
			for l1llll_l1_,title,link in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = title.strip(l11lll_l1_ (u"࠭ࠠࠨ㒷"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㒸"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠨࠩ㒹"),str(l1l11ll1111_l1_))
		elif l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ㒺") in url:
			if l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠼ࠧ㒻") in url:
				l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭㒼")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠼ࠧ㒽")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㒾"),l11lll_l1_ (u"ࠧࠨ㒿"),l11lll_l1_ (u"ࠨࠩ㓀"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠹ࡹ࡮ࠧ㓁"))
			elif l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠺ࠧ㓂") in url:
				l11l11l_l1_ = l1l1l1111l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭㓃")+l1l11l1_l1_+l11lll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠺ࠧ㓄")
				html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ㓅"),l11lll_l1_ (u"ࠧࠨ㓆"),l11lll_l1_ (u"ࠨࠩ㓇"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠺ࡹ࡮ࠧ㓈"))
			items = re.findall(l11lll_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㓉"),html,re.DOTALL)
			for l1llll_l1_,link,name,title in items:
				l1l11ll1111_l1_ += 1
				l1l1l111l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(l1llll_l1_)
				#l1ll11l1l1l_l1_ = l1l1l1111ll_l1_ + QUOTE(link)
				l1l11ll11ll_l1_ = name + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ㓊") + title
				l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠬࠦࠧ㓋"))
				l1l11ll11ll_l1_ = escapeUNICODE(l1l11ll11ll_l1_)
				addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㓌"),l111ll_l1_+l1l11ll11ll_l1_,l11l11l_l1_,24,l1l1l111l1l_l1_,l11lll_l1_ (u"ࠧࠨ㓍"),str(l1l11ll1111_l1_))
	if type==l11lll_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ㓎") or type==l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㓏"):
		if l1l11ll1111_l1_>25:
			title=l11lll_l1_ (u"ูࠪๆำษࠡࠩ㓐")
			if l1ll1111111_l1_==l11lll_l1_ (u"ࠫࡪࡴࠧ㓑"): title = l11lll_l1_ (u"ࠬࠦࡐࡢࡩࡨࠤࠬ㓒")
			if l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡦࡢࠩ㓓"): title = l11lll_l1_ (u"ࠧࠡืไั์ࠦࠧ㓔")
			if l1ll1111111_l1_==l11lll_l1_ (u"ࠨࡨࡤ࠶ࠬ㓕"): title = l11lll_l1_ (u"ูࠩࠣๆำ็ࠡࠩ㓖")
			for l1l11llll11_l1_ in range(1,11):
				if not l1l11l1_l1_==str(l1l11llll11_l1_):
					l1l11ll111l_l1_ = l11lll_l1_ (u"ࠪ࠴ࠬ㓗")+str(l1l11llll11_l1_)
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓘"),l111ll_l1_+title+str(l1l11llll11_l1_),url,23,l11lll_l1_ (u"ࠬ࠭㓙"),l1l11l1llll_l1_+l1l11ll111l_l1_[-2:])
	return
def PLAY(url,l1lll11_l1_):
	l1l1l1111ll_l1_ = l1l11lll1l1_l1_(url)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ㓚"),l11lll_l1_ (u"ࠧࠨ㓛"),l11lll_l1_ (u"ࠨࠩ㓜"),l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㓝"))
	# l1l1l_l1_ l1llll1l1_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠨ࡝ࠩ࠱࠮ࡄࡢࠧࡠࠫࠫ࠲࠯ࡅࠩࠣࡀࠪ㓞"),html,re.DOTALL)
	if items:
		l1ll1111111_l1_ = l1l1l111l11_l1_(url)
		parts = url.split(l11lll_l1_ (u"ࠫ࠴࠭㓟"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"ࠬ࠵ࠬࠨ㓠")+l1lll11_l1_+l11lll_l1_ (u"࠭ࠬࠨ㓡")+l1lll11_l1_+l11lll_l1_ (u"ࠧࡠࠩ㓢")+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨ࡯࠶ࡹ࠽࠭㓣"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ url
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩ࡞ࠪ࠲࠯ࡅ࡜ࠨࠫࠫࡠ࠳࠴ࠪࡀࠫࠥࠫ㓤"),html,re.DOTALL)
	if items:
		l1ll1111111_l1_ = l1l1l111l11_l1_(url)
		parts = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ㓥"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+l1ll1111111_l1_+id+l11lll_l1_ (u"ࠫ࠴࠭㓦")+l1lll11_l1_+items[0][2]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠬࡳࡰ࠵ࠢࡸࡶࡱ࠭㓧"))
		l1111_l1_.append(link)
	# l1l1l_l1_ l1111lll_l1_ src
	items = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㓨"),html,re.DOTALL)
	for link in items:
		link = link.replace(l11lll_l1_ (u"ࠧ࠰࠱ࠪ㓩"),l11lll_l1_ (u"ࠨ࠱ࠪ㓪"))
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠩࡰࡴ࠹ࠦࡳࡳࡥࠪ㓫"))
		l1111_l1_.append(link)
	# l1l1l111111_l1_ l1111lll_l1_ links
	items = re.findall(l11lll_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㓬"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l1l1111ll_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࡲࡶ࠴ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ㓭"))
		l1111_l1_.append(link)
	# l1l1l111111_l1_ l1l1l111lll_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠬ࡜࡯ࡪࡥࡨࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㓮"),html,re.DOTALL)
	if items:
		link = items[int(l1lll11_l1_)-1]
		link = l1l1l1111ll_l1_+QUOTE(link)
		l1lll1ll_l1_.append(l11lll_l1_ (u"࠭࡭ࡱ࠵ࠣࡥࡩࡪࡲࡦࡵࡶࠫ㓯"))
		l1111_l1_.append(link)
	# l1l_l1_
	if len(l1111_l1_)==1: link = l1111_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨ㓰"), l1lll1ll_l1_)
		if l1l_l1_ == -1 : return
		link = l1111_l1_[l1l_l1_]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㓱"))
	return
def l1l11lll1l1_l1_(url):
	if l11ll1_l1_ in url: l1l1l1ll1ll_l1_ = l11ll1_l1_
	elif l11lllll11_l1_ in url: l1l1l1ll1ll_l1_ = l11lllll11_l1_
	elif l1l11lll1ll_l1_ in url: l1l1l1ll1ll_l1_ = l1l11lll1ll_l1_
	elif l1l11llll1l_l1_ in url: l1l1l1ll1ll_l1_ = l1l11llll1l_l1_
	else: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࠪ㓲")
	return l1l1l1ll1ll_l1_
def l1l1l111l11_l1_(url):
	if   l11ll1_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠪࡥࡷ࠭㓳")
	elif l11lllll11_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠫࡪࡴࠧ㓴")
	elif l1l11lll1ll_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"ࠬ࡬ࡡࠨ㓵")
	elif l1l11llll1l_l1_ in url: l1ll1111111_l1_ = l11lll_l1_ (u"࠭ࡦࡢ࠴ࠪ㓶")
	else: l1ll1111111_l1_ = l11lll_l1_ (u"ࠧࠨ㓷")
	return l1ll1111111_l1_
def l1l1lll1l_l1_(url):
	l1ll1111111_l1_ = l1l1l111l11_l1_(url)
	l11l11l_l1_ = url + l11lll_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡍ࡫ࡹࡩࠬ㓸")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭㓹"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ㓺"),l11lll_l1_ (u"ࠫࠬ㓻"),l11lll_l1_ (u"ࠬ࠭㓼"),l11lll_l1_ (u"࠭ࠧ㓽"),l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨ㓾"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㓿"),html,re.DOTALL)
	l11l1l1_l1_ = items[0]
	PLAY_VIDEO(l11l1l1_l1_,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㔀"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠪࠤࠬ㔁"),l11lll_l1_ (u"ࠫ࠰࠭㔂"))
	if l1ll_l1_:
		l1ll1ll1l1_l1_ = [ l11ll1_l1_ , l11lllll11_l1_ , l1l11lll1ll_l1_ , l1l11llll1l_l1_ ]
		l1l1l11ll_l1_ = [ l11lll_l1_ (u"ࠬ฿ัษ์ࠪ㔃") , l11lll_l1_ (u"࠭ࡅ࡯ࡩ࡯࡭ࡸ࡮ࠧ㔄") , l11lll_l1_ (u"ࠧโษิื๎࠭㔅") , l11lll_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ㔆") ]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩสาฯืࠠศๆ็฾ฮࠦวๅ็้หุฮษ࠻ࠩ㔇"), l1l1l11ll_l1_)
		if l1l_l1_ == -1 : return
		l1l1ll11_l1_ = l1ll1ll1l1_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠪࡣࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࡢࠫ㔈") in options: l1l1ll11_l1_ = l11ll1_l1_
		elif l11lll_l1_ (u"ࠫࡤࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࡤ࠭㔉") in options: l1l1ll11_l1_ = l11lllll11_l1_
		else: l1l1ll11_l1_ = l11lll_l1_ (u"ࠬ࠭㔊")
	if not l1l1ll11_l1_: return
	l1ll1111111_l1_ = l1l1l111l11_l1_(l1l1ll11_l1_)
	l11l11l_l1_ = l1l1ll11_l1_ + l11lll_l1_ (u"ࠨ࠯ࡉࡱࡰࡩ࠴࡙ࡥࡢࡴࡦ࡬ࡄࡹࡥࡢࡴࡦ࡬ࡸࡺࡲࡪࡰࡪࡁࠧ㔋") + l111l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㔌"),l11lll_l1_ (u"ࠨࠩ㔍"),l1ll1111111_l1_,l11l11l_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ㔎"),l11lll_l1_ (u"ࠪࠫ㔏"),l11lll_l1_ (u"ࠫࠬ㔐"),l11lll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ㔑"))
	items = re.findall(l11lll_l1_ (u"࠭ࠢࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡎࡪࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠪ㔒"),html,re.DOTALL)
	if items:
		for l1llll_l1_,category,id,title in items:
			#if category in [l11lll_l1_ (u"ࠧ࠴ࠩ㔓"),l11lll_l1_ (u"ࠨ࠷ࠪ㔔"),l11lll_l1_ (u"ࠩ࠺ࠫ㔕")]:
			if category in [l11lll_l1_ (u"ࠪ࠷ࠬ㔖"),l11lll_l1_ (u"ࠫ࠼࠭㔗")]:
				title = title.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ㔘"),l11lll_l1_ (u"࠭ࠧ㔙"))
				title = title.replace(l11lll_l1_ (u"ࠧࠣࠩ㔚"),l11lll_l1_ (u"ࠨࠩ㔛"))
				if category==l11lll_l1_ (u"ࠩ࠶ࠫ㔜"):
					type = l11lll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ㔝")
					if l1ll1111111_l1_==l11lll_l1_ (u"ࠫࡦࡸࠧ㔞"): name = l11lll_l1_ (u"๋ࠬำๅี็ࠤ࠿ࠦࠧ㔟")
					elif l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡥ࡯ࠩ㔠"): name = l11lll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠻ࠢࠪ㔡")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠨࡨࡤࠫ㔢"): name = l11lll_l1_ (u"ࠩึี๏อไ้ࠡสࠤ࠿ࠦࠧ㔣")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠪࡪࡦ࠸ࠧ㔤"): name = l11lll_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ㔥")
				elif category==l11lll_l1_ (u"ࠬ࠻ࠧ㔦"):
					type = l11lll_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ㔧")
					if l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡢࡴࠪ㔨"): name = l11lll_l1_ (u"ࠨใํ่๊ࠦ࠺ࠡࠩ㔩")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡨࡲࠬ㔪"): name = l11lll_l1_ (u"ࠪࡑࡴࡼࡩࡦࠢ࠽ࠤࠬ㔫")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠫ࡫ࡧࠧ㔬"): name = l11lll_l1_ (u"ࠬ็๊ๅ็ࠣ࠾ࠥ࠭㔭")
					elif l1ll1111111_l1_==l11lll_l1_ (u"࠭ࡦࡢ࠴ࠪ㔮"): name = l11lll_l1_ (u"ࠧโๆ่ࠤ์อࠠ࠻ࠢࠪ㔯")
				elif category==l11lll_l1_ (u"ࠨ࠹ࠪ㔰"):
					type = l11lll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ㔱")
					if l1ll1111111_l1_==l11lll_l1_ (u"ࠪࡥࡷ࠭㔲"): name = l11lll_l1_ (u"ࠫอืๆศ็ฯࠤ࠿ࠦࠧ㔳")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠬ࡫࡮ࠨ㔴"): name = l11lll_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠠ࠻ࠢࠪ㔵")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠧࡧࡣࠪ㔶"): name = l11lll_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠤ࠿ࠦࠧ㔷")
					elif l1ll1111111_l1_==l11lll_l1_ (u"ࠩࡩࡥ࠷࠭㔸"): name = l11lll_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ㔹")
				title = name + title
				link = l1l1ll11_l1_ + l11lll_l1_ (u"ࠫ࠴࠭㔺") + type + l11lll_l1_ (u"ࠬ࠵ࡃࡰࡰࡷࡩࡳࡺ࠯ࠨ㔻") + id
				l1llll_l1_ = QUOTE(l1llll_l1_)
				l1llll_l1_ = l1l1ll11_l1_+l1llll_l1_
				#LOG_THIS(l11lll_l1_ (u"࠭ࠧ㔼"),l1llll_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㔽"),l111ll_l1_+title,link,23,l1llll_l1_,l11lll_l1_ (u"ࠨ࠳࠳࠵ࠬ㔾"))
	#else: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㔿"),l11lll_l1_ (u"ࠪࠫ㕀"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㕁"),,لا توجد نتائج للبحث')
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᰡ")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡄࡏࡑࡣࠬᰢ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧใษษ้ฯ๐ࠧᰣ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l11l_l1_(url)
	elif mode==302: results = l1111l_l1_(url)
	elif mode==303: results = l1llll1l11_l1_(url)
	elif mode==304: results = l1llllll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll1l111l_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰤ"),l111ll_l1_+l11lll_l1_ (u"ࠩ็้ฬึวࠡษ็้ํู่ࠡสฺ๎ฦ࠭ᰥ"),l11lll_l1_ (u"ࠪࠫᰦ"),306)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰧ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᰨ"),l11lll_l1_ (u"࠭ࠧᰩ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᰪ"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᰫ"),l11lll_l1_ (u"ࠩࠪᰬ"),309,l11lll_l1_ (u"ࠪࠫᰭ"),l11lll_l1_ (u"ࠫࠬᰮ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᰯ"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰰ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᰱ"),l11lll_l1_ (u"ࠨࠩᰲ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᰳ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᰴ"),l11lll_l1_ (u"ࠫࠬᰵ"),l11lll_l1_ (u"ࠬ࠭ᰶ"),l11lll_l1_ (u"᰷࠭ࠧ"),l11lll_l1_ (u"ࠧࠨ᰸"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᰹"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"ࠩࠪ᰺"),html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࡫ࡡࡥࡧࡵࡂࠬ᰻"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᰼"),block,re.DOTALL)
	for link,title in items:
		#link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ᰽"))
		#if title==l11lll_l1_ (u"࠭ัๆุส๊ࠬ᰾"): link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ี๊฼ว็࠱ࠪ᰿")
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᱀"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᱁")+l111ll_l1_+title,link,301)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᱂"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᱃"),l11lll_l1_ (u"ࠬ࠭᱄"),9999)
	l1l11l_l1_(l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬ᱅"),html)
	return html
def l1ll1l111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠧࠨ᱆"),l11lll_l1_ (u"ࠨࠩ᱇"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᱈"),l11lll_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠣฬ฼๐มࠡ็้ࠤฬ๊ๅึัิࠤ࠳࠴ࠠษีหฬ่๊ࠥศ็ࠣวฺำวษࠢส่๊๎โฺࠢหฮู็๊า่ࠢัฯ๎๊ศฬࠣะ๊๐ูࠡืไัฬะࠠศๆ่์็฿ࠠ࠯࠰ࠣ์ฬ๊่ใฬࠣห้฼วว฻ࠣ๎ีํศࠡใํࠤ๊฿วๅฮฬࠤฯฺแ๋ำࠣห้฻แฮษอࠤฬ๊ๅีใิอ่ࠥศๅࠢ฼ี฻ࠦๅฮฬ๋๎ฬะ็ศࠢไ๎่่ࠥศศ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪ᱉"))
	return
def l1l11l_l1_(url,html=l11lll_l1_ (u"ࠫࠬ᱊")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᱋"),url,l11lll_l1_ (u"࠭ࠧ᱌"),l11lll_l1_ (u"ࠧࠨᱍ"),l11lll_l1_ (u"ࠨࠩᱎ"),l11lll_l1_ (u"ࠩࠪᱏ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ᱐"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯ࠬࡂࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠩࠨ᱑"),html,re.DOTALL)
	if l1l1ll1_l1_:
		for block in l1l1ll1_l1_:
			seq += 1
			items = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᱒"),block,re.DOTALL)
			for title,test,link in items:
				title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ᱓"))
				if title==l11lll_l1_ (u"ࠧࠨ᱔"): title = l11lll_l1_ (u"ࠨส๋์ํ๎่ࠨ᱕")
				if l11lll_l1_ (u"ࠩࡨࡱࡃࡂࡡࠨ᱖") not in test:
					if block.count(l11lll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧ᱗"))>0:
						l1ll1l1111_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᱘"),block,re.DOTALL)
						for link in l1ll1l1111_l1_:
							title = link.split(l11lll_l1_ (u"ࠬ࠵ࠧ᱙"))[-2]
							addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᱚ"),l111ll_l1_+title,link,301)
						continue
					else: link = url+l11lll_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫᱛ")+str(seq)
				#l111ll1l1_l1_ = [l11lll_l1_ (u"ࠨ็ึุ่๊วหࠢࠪᱜ"),l11lll_l1_ (u"ࠩสๅ้อๅࠡࠩᱝ"),l11lll_l1_ (u"ࠪฬึอๅอࠩᱞ"),l11lll_l1_ (u"ࠫ฾ื่ืࠩᱟ"),l11lll_l1_ (u"้ࠬไ๋สสฮࠬᱠ"),l11lll_l1_ (u"࠭ว฻ษ้ํࠬᱡ")]
				#if any(value in title for value in l111ll1l1_l1_):
				if not any(value in title for value in l1l1l1_l1_):
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱢ"),l111ll_l1_+title,link,302)
	else: l1111l_l1_(url,html)
	return
def l1111l_l1_(url,html=l11lll_l1_ (u"ࠨࠩᱣ")):
	if html==l11lll_l1_ (u"ࠩࠪᱤ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᱥ"),url,l11lll_l1_ (u"ࠫࠬᱦ"),l11lll_l1_ (u"ࠬ࠭ᱧ"),l11lll_l1_ (u"࠭ࠧᱨ"),l11lll_l1_ (u"ࠧࠨᱩ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᱪ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11lll_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ᱫ") in url:
		url,seq = url.split(l11lll_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᱬ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯ࠬࡂࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠩࠨᱭ"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(seq)-1]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡨ࡯ࡥࡻࡁࠫᱮ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭࠼ࡢ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᱯ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,data,l1llll_l1_ in items:
		title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁ࠲࠯ࡅ࠼࠰ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࡩࡲࡄࠧᱰ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫᱱ"),l11lll_l1_ (u"ࠩࠪᱲ")).strip(l11lll_l1_ (u"ࠪࠤࠬᱳ"))
		if not title or title==l11lll_l1_ (u"ࠫࠬᱴ"):
			title = re.findall(l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦࡃ࠴ࠪࡀ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᱵ"),data,re.DOTALL)
			if title: title = title[0].replace(l11lll_l1_ (u"࠭࡜࡯ࠩᱶ"),l11lll_l1_ (u"ࠧࠨᱷ")).strip(l11lll_l1_ (u"ࠨࠢࠪᱸ"))
			if not title or title==l11lll_l1_ (u"ࠩࠪᱹ"):
				title = re.findall(l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᱺ"),data,re.DOTALL)
				title = title[0].replace(l11lll_l1_ (u"ࠫࡡࡴࠧᱻ"),l11lll_l1_ (u"ࠬ࠭ᱼ")).strip(l11lll_l1_ (u"࠭ࠠࠨᱽ"))
		title = unescapeHTML(title)
		#if title==l11lll_l1_ (u"ࠧࠨ᱾"): continue
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l11l1_l1_ = link+data+l1llll_l1_
			if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪ᱿") in l11l1_l1_ or l11lll_l1_ (u"่ࠩืู้ไࠨᲀ") in l11l1_l1_ or l11lll_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࠧ࠭ᲁ") in l11l1_l1_:
				if l11lll_l1_ (u"ࠫอืวๆฮࠪᲂ") in data: title = l11lll_l1_ (u"ࠬฮั็ษ่ะࠥ࠭ᲃ")+title
				elif l11lll_l1_ (u"࠭ๅิๆึ่ࠬᲄ") in data or l11lll_l1_ (u"ࠧๆ๊ึ้ࠬᲅ") in data: title = l11lll_l1_ (u"ࠨ็ึุ่๊ࠠࠨᲆ")+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᲇ"),l111ll_l1_+title,link,303,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᲈ"),l111ll_l1_+title,link,305,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᲉ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᲊ"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᲋"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭᲌")+title,link,302)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᲍"),url,l11lll_l1_ (u"ࠩࠪ᲎"),l11lll_l1_ (u"ࠪࠫ᲏"),l11lll_l1_ (u"ࠫࠬᲐ"),l11lll_l1_ (u"ࠬ࠭Ბ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠳ࡶࡸࠬᲒ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵ࡫ࡷࡰࡪࡄࠧᲓ"),html,re.DOTALL)
	name = name[0].replace(l11lll_l1_ (u"ࠨࡾࠣื๏๋ว่ࠡส์ࠬᲔ"),l11lll_l1_ (u"ࠩࠪᲕ")).replace(l11lll_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬᲖ"),l11lll_l1_ (u"ࠫࠬᲗ")).strip(l11lll_l1_ (u"ࠬࠦࠧᲘ")).replace(l11lll_l1_ (u"࠭ࠠࠡࠩᲙ"),l11lll_l1_ (u"ࠧࠡࠩᲚ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬᲛ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᲜ"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠪࠤࠬᲝ")+title.replace(l11lll_l1_ (u"ࠫࡡࡴࠧᲞ"),l11lll_l1_ (u"ࠬ࠭Ჟ")).strip(l11lll_l1_ (u"࠭ࠠࠨᲠ"))
				title = title.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪᲡ"),l11lll_l1_ (u"ࠨࠩᲢ")).strip(l11lll_l1_ (u"ࠩࠣࠫᲣ"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᲤ"),l111ll_l1_+title,link,304)
		else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	if l11lll_l1_ (u"ࠫ࠴ࡹࡥ࡭ࡣࡵࡽ࠴࠭Ქ") not in url: url = url.strip(l11lll_l1_ (u"ࠬ࠵ࠧᲦ"))+l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࡯࡮ࡨࠩᲧ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᲨ"),url,l11lll_l1_ (u"ࠨࠩᲩ"),l11lll_l1_ (u"ࠩࠪᲪ"),l11lll_l1_ (u"ࠪࠫᲫ"),l11lll_l1_ (u"ࠫࠬᲬ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᲭ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"࠭ࠧᲮ"),html)
	if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩᲯ") not in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᲰ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᲱ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭Ჲ"),l11lll_l1_ (u"ࠫࠬᲳ")).strip(l11lll_l1_ (u"ࠬࠦࠧᲴ"))
			title = l11lll_l1_ (u"࠭วๅฯ็ๆฮࠦࠧᲵ")+title
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ჶ"),l111ll_l1_+title,link,305)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡧࡩࡹࡧࡩ࡭ࡵࠥࠬ࠳࠰࠿ࠪࠤࡵࡩࡱࡧࡴࡦࡦࠥࠫᲷ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲸ"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭Ჹ"),l11lll_l1_ (u"ࠫࠬᲺ")).strip(l11lll_l1_ (u"ࠬࠦࠧ᲻"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᲼"),l111ll_l1_+title,link,305,l1llll_l1_)
	return
def PLAY(url):
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠤࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡨࡵ࡯࡯࠭ࠏࠏࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡩ࡫ࡱࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࡟࠵ࡣࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧࠪࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࡵࡩࡩ࡯ࡲࡦࡥࡷࡣ࡭ࡺ࡭࡭ࠢࡀࠤࡉࡋࡃࡐࡆࡈࡣࡆࡊࡉࡍࡄࡒࡣࡍ࡚ࡍࡍࠪࡵࡩࡩ࡯ࡲࡦࡥࡷࡣ࡭ࡺ࡭࡭ࠫࠍࠍࡨࡵ࡯࡬࡫ࡨࡷࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡴࡱࡩࡦࡵࠍࠍࡕࡎࡐࡔࡇࡖࡗࡎࡊࠠ࠾ࠢࡦࡳࡴࡱࡩࡦࡵ࡞ࠫࡕࡎࡐࡔࡇࡖࡗࡎࡊࠧ࡞ࠌࠌࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠣࡪࡵࡩ࡫ࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ࠯ࡶࡪࡪࡩࡳࡧࡦࡸࡤ࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠯ࠫࡈࡵ࡯࡬࡫ࡨࠫ࠿࠭ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅ࠿ࠪ࠯ࡕࡎࡐࡔࡇࡖࡗࡎࡊࡽࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡶࡦࡴ࡬ࡪࡾࡥ࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ࠮ࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭ࠢࡀࠤࡉࡋࡃࡐࡆࡈࡣࡆࡊࡉࡍࡄࡒࡣࡍ࡚ࡍࡍࠪࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠩࠋࠋࠦࡥࡩࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣࡣࡧࠦࠥࡺࡡࡳࡩࡨࡸࡂࠨ࡟ࡣ࡮ࡤࡲࡰࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟ࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡢࡦࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎࠩࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡥࡩࡥ࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭ࠩࠋࠋࠦࡥࡩࡥࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡅࡇࡆࡓࡉࡋ࡟ࡂࡆࡌࡐࡇࡕ࡟ࡉࡖࡐࡐ࠭ࡧࡤࡠࡪࡷࡱࡱ࠯ࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡤࡷࡲࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡤࡪࡵࡳࡰࡦࡿ࠺ࠡࡰࡲࡲࡪࡁࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࡝࠳ࡡ࠰࠭࠯ࠨࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡣ࠰ࡦ࡭ࡲࡧࡶࡪࡦࡶ࠲ࡱ࡯ࡶࡦ࠱ࠪࢁࠏࠏࠢࠣࠤᲽ")
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡩ࡯ࡩ࠲ࠫᲾ")
	#server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭Ჿ"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᳀"):None,l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ᳁"):server}
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᳂"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᳃"),l11lll_l1_ (u"ࠧࠨ᳄"),l11lll_l1_ (u"ࠨࠩ᳅"),l11lll_l1_ (u"ࠩࠪ᳆"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭᳇"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l11l11l_l1_ = l1ll1l1l11_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡱࡵࡷࡦࡴࠪ᳈"))
	#html = l1ll1l11l1_l1_(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᳉"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᳊"),l11lll_l1_ (u"ࠧࠨ᳋"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ᳌"))
	#if html and kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ᳍"))
	#html = DECODE_ADILBO_HTML(html)
	l1111_l1_ = []
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᳎"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᳏"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ᳐"),l11lll_l1_ (u"࠭ࠧ᳑")).strip(l11lll_l1_ (u"ࠧࠡࠩ᳒"))
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ᳓"),title,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠩࡢࡣࡤࡥ᳔ࠧ")+l11l111l_l1_[0]
				#title = l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺ᳕ࠫ")
				title = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦ᳖ࠩ"))
			else: l11l111l_l1_ = l11lll_l1_ (u"᳗ࠬ࠭")
			l1lllllll1_l1_ = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ᳘ࠧ")+title+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧ᳙ࠫ")+l11l111l_l1_
			l1111_l1_.append(l1lllllll1_l1_)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡺࡥࡹࡩࡨࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᳚"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠩࠫ࠳࠴࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ᳛"),block,re.DOTALL)
		for link in links:
			link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻᳜ࠩ")+link
			title = SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦ᳝ࠩ"))
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ᳞࠭")+title+l11lll_l1_ (u"࠭࡟ࡠࡧࡰࡦࡪࡪ᳟ࠧ")
			l1111_l1_.append(link)
		# l1ll1l11ll_l1_ l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼࡡ࠮ࡻࡶࡴ࡯࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᳠"),html,re.DOTALL)
		if links:
			items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࡯ࡦࡨࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ᳡"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11lll_l1_ (u"ࠩ࡟ࡲ᳢ࠬ"),l11lll_l1_ (u"᳣ࠪࠫ")).strip(l11lll_l1_ (u"᳤ࠫࠥ࠭"))
				title = title.replace(l11lll_l1_ (u"ࠬࡉࡩ࡮ࡣࠣࡒࡴࡽ᳥ࠧ"),l11lll_l1_ (u"࠭ࡃࡪ࡯ࡤࡒࡴࡽ᳦ࠧ"))
				link = links[0]+l11lll_l1_ (u"ࠧࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡺ࡭ࡹࡩࡨࠧ࡫ࡱࡨࡪࡾ࠽ࠨ᳧")+index+l11lll_l1_ (u"ࠨࠨ࡬ࡨࡂ᳨࠭")+id+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᳩ")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᳪ")
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᳫ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᳬ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"᳭࠭ࠧ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨᳮ"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪᳯ"),l11lll_l1_ (u"ࠩ࠮ࠫᳰ"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨᳱ")+search
	l1111l_l1_(url)
	return
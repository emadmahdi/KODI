# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ泹")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ泺")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠫࠬ泻")
#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ泼"):l11lll_l1_ (u"࠭ࠧ泽")}
def MAIN(mode,url,text,type,l1l11l1_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11111l1_l1_(url)
	#elif mode==142: results = l1ll1lll11lll_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l1l11l1_l1_)
	elif mode==145: results = l1lll11l1111l_l1_(url)
	elif mode==146: results = l1ll1lll111l1_l1_(url)
	elif mode==147: results = l1lll1111ll1l_l1_()
	elif mode==148: results = l1lll1111llll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡊ࠳࡙ࡥ࡛ࡏࡇ࡛ࡳࡻ࡮ࡅࡸࡒ࡙ࡷࡇࡨ࡝࡞࡛࡚ࡌࡑࡍࡽࡾࡵࡸࡸࡐࡕࠪ泾")
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ泿"),l111ll_l1_+l11lll_l1_ (u"ࠩࡗࡉࡘ࡚࡚ࠠࡑࡘࡘ࡚ࡈࡅࠨ洀"),url,144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ洁"),l111ll_l1_+l11lll_l1_ (u"ࠫࡴࡲࡤࡦࡴࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࠥࡴ࡯ࡵࠢ࡯࡭ࡸࡺࡩ࡯ࡩࠣࡲࡪࡽࡥࡳࠢࡳࡰࡾࡧ࡬ࡪࡵࡷࠫ洂"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡊࡵࡷࡥ࡚ࡼ࡛࡞࡫ࡱࠦ࡭࡫ࡶࡸࡂࡘࡄࡒࡏ࠹࠷ࡻࡎࡪࡑ࠲࡫ࡩ࡙ࡹࠧ洃"),144)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洄"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วา฼ࠪ洅"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡺࡏࡷࡱࡱ࡮࠹ࡍࡹࡰࡲࡐࡘࡒࡈࡡ࠳࠵ࡴ࡙ࡨࡽࠧ洆"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洇"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ洈"),l11lll_l1_ (u"ࠫࠬ洉"),149,l11lll_l1_ (u"ࠬ࠭洊"),l11lll_l1_ (u"࠭ࠧ洋"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ洌"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ洍"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ洎")+l11lll_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ洏")+l11lll_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ洐"),l11lll_l1_ (u"ࠬ࠭洑"),290)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洒"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ洓")+l111ll_l1_+l11lll_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ洔"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ洕"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ洖"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭洗")+l111ll_l1_+l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ洘"),l11ll1_l1_,144,l11lll_l1_ (u"࠭ࠧ洙"),l11lll_l1_ (u"ࠧࠨ洚"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ洛"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洜"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ洝")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ洞"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭洟"),146)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ洠"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ洡"),l11lll_l1_ (u"ࠨࠩ洢"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洣"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ洤")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ津"),l11lll_l1_ (u"ࠬ࠭洦"),147)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭洧"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ洨")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ洩"),l11lll_l1_ (u"ࠩࠪ洪"),148)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ洫"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭洬")+l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ洭"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ洮"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ洯"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ洰")+l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭洱"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ洲"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ洳"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ洴")+l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ洵"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ洶"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ洷"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ洸")+l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ洹"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ洺"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ活"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ洼")+l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭洽"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ派"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ洿"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ浀")+l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ流"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ浂"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭浃"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ浄")+l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭浅"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭浆"),144)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ浇"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭浈")+l111ll_l1_+l11lll_l1_ (u"ࠬอไฺำสๆࠥิืษหࠣห้๋ัอ฻ํอࠬ浉"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࡑࡎ࠷࡮࡚ࡷ࠶ࡱࡰࡊ࠷࠻ࡗࡪࡶ࡚ࡇ࡬ࡓࡴࡉ࡭ࡴ࡬ࡹࡿࡸ࡯ࡕࡈࡷࡱ࡫ࡸࠧ浊"),144)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ测"),l111ll_l1_+l11lll_l1_ (u"ࠨษ฼ำฬีวหࠢสฺฬ็ษࠡ์๋ฮ๏๎ศࠨ浌"),l11lll_l1_ (u"ࠩࠪ浍"),144)
	#l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ济"),l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ浏"),l11lll_l1_ (u"ࠬํะศࠢส่ฬิส๋ษิࠤุ๎แࠡ์ัีั้ࠠๆ่ࠣห้ฮั็ษ่ะࠬ浐"),l11lll_l1_ (u"࠭ไฤ่๊ࠤุ๎แࠡ์ๅ์๊ࠦศหึ฽๎้ࠦศา่ส้ั๊้ࠦฬํ์อ࠭浑"))
	#if l1ll111ll1_l1_==1:
	#	url = l11lll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ浒")
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬ浓"))
	#	xbmc.executebuiltin(l11lll_l1_ (u"ࠩࡕࡩࡵࡲࡡࡤࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡹ࡭ࡩ࡫࡯ࡴ࠮ࠪ浔")+url+l11lll_l1_ (u"ࠪ࠭ࠬ浕"))
	#	#xbmc.executebuiltin(l11lll_l1_ (u"ࠫࡗࡻ࡮ࡂࡦࡧࡳࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ浖"))
	return
l11lll_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡓࡁࡊࡐࡓࡅࡌࡋࠨࡶࡴ࡯࠭࠿ࠐࠉࡩࡶࡰࡰ࠱ࡩࡣ࠭ࡦࡤࡸࡦࠦ࠽ࠡࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁࠩࡷࡵࡰ࠮ࠐࠉࡪࡨࠣࠫࡗ࡫ࡦࡢࡣࡷࠤࡆࡲ࠭ࡈࡣࡰࡱࡦࡲࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡽࡪࡹࠧࠪࠌࠌࡨࡩࠦ࠽ࠡࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠎࠎ࡬࡯ࡳࠢ࡬ࠤ࡮ࡴࠠࡳࡰࡤ࡫ࡪ࠮࡬ࡦࡰࠫࡨࡩ࠯ࠩ࠻ࠌࠌࠍ࡮ࡺࡥ࡮ࠢࡀࠤࡩࡪ࡛ࡪ࡟ࠍࠍࠎࡏࡎࡔࡇࡕࡘࡤࡏࡔࡆࡏࡢࡘࡔࡥࡍࡆࡐࡘࠬ࡮ࡺࡥ࡮ࠫࠍࠍࡎ࡚ࡅࡎࡕࠫࡹࡷࡲࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠥࠦࠧ浗")
def l1lll1111ll1l_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭浘"))
	return
def l1lll1111llll_l1_():
	ITEMS(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ浙"))
	return
def PLAY(url,type):
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ浚")
	#items = re.findall(l11lll_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ浛"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ浜")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ浝"))
	#return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠥ࠭ࠫࡴࡶࡵࠬࡱ࡯࡮࡬ࡵࠬ࠭ࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠪࡸࡶࡱ࠯ࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ浞")
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1ll1lll111l1_l1_(url):
	html,cc,data = l1lll1111l111_l1_(url)
	dd = cc[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ浟")][l11lll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ浠")][l11lll_l1_ (u"ࠨࡶࡤࡦࡸ࠭浡")]
	for l11l1lllll_l1_ in range(len(dd)):
		item = dd[l11l1lllll_l1_]
		l1lll111lll11_l1_(item,url,str(l11l1lllll_l1_))
	ee = dd[0][l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ浢")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ浣")][l11lll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ浤")][l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ浥")]
	s = 0
	for l11l1lllll_l1_ in range(len(ee)):
		item = ee[l11l1lllll_l1_][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ浦")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ浧")][0]
		if list(item[l11lll_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ浨")][l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ浩")].keys())[0]==l11lll_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ浪"): continue
		succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_ = l1lll11l11l1l_l1_(item)
		if not title:
			s += 1
			title = l11lll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦัศศฯอࠥ࠭浫")+str(s)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ浬"),l111ll_l1_+title,url,144,l11lll_l1_ (u"࠭ࠧ浭"),str(l11l1lllll_l1_))
	key = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ浮"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭浯")+key[0]
	html,cc,l11llll11_l1_ = l1lll1111l111_l1_(l11l11l_l1_)
	for l1ll1111ll1l_l1_ in range(3,4):
		dd = cc[l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ浰")][l1ll1111ll1l_l1_][l11lll_l1_ (u"ࠪ࡫ࡺ࡯ࡤࡦࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ浱")][l11lll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ浲")]
		for l11l1lllll_l1_ in range(len(dd)):
			item = dd[l11l1lllll_l1_]
			if l11lll_l1_ (u"ࠬ࡟࡯ࡶࡖࡸࡦࡪࠦࡐࡳࡧࡰ࡭ࡺࡳࠧ浳") in str(item): continue
			l1lll111lll11_l1_(item)
	return
def ITEMS(url,data=l11lll_l1_ (u"࠭ࠧ浴"),index=0):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ浵"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ浶"),l11lll_l1_ (u"ࠩࠪ海"))
	html,cc,l11llll11_l1_ = l1lll1111l111_l1_(url,data)
	l11lllllll_l1_,ff = l11lll_l1_ (u"ࠪࠫ浸"),l11lll_l1_ (u"ࠫࠬ浹")
	#if l11lll_l1_ (u"ࠬࡵࡷ࡯ࡧࡵࠫ浺") in html.lower(): DIALOG_OK(l11lll_l1_ (u"࠭ࠧ浻"),l11lll_l1_ (u"ࠧࠨ浼"),l11lll_l1_ (u"ࠨࡱࡺࡲࡪࡸࠠࡦࡺ࡬ࡷࡹ࠭浽"),l11lll_l1_ (u"ࠩ࡬ࡲࠥ࡮ࡴ࡮࡮ࠪ浾"))
	owner = re.findall(l11lll_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ浿"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠫࠧࡼࡩࡥࡧࡲࡓࡼࡴࡥࡳࠤ࠱࠮ࡄࠨࡴࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ涀"),html,re.DOTALL)
	if not owner: owner = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡩࡣࡱࡲࡪࡲࡍࡦࡶࡤࡨࡦࡺࡡࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡳࡼࡴࡥࡳࡗࡵࡰࡸࠨ࠺࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪ涁"),html,re.DOTALL)
	if owner:
		l11lllllll_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ涂")+owner[0][0]+l11lll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ涃")
		link = owner[0][1]
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭涄") not in link: link = l11ll1_l1_+link
		#if l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭涅") in url and l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭涆") not in url and l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ涇") not in url and l11lll_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ消") not in url:
		if l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ涉") in url: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ涊"),l111ll_l1_+l11lllllll_l1_,link,144)
	#if cc==l11lll_l1_ (u"ࠨࠩ涋"): l1ll1lll11ll1_l1_(url,html) ; return
	l1ll1lll11l11_l1_ = [l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ涌"),l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ涍"),l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ涎"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ涏"),l11lll_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ涐"),l11lll_l1_ (u"ࠧࡴࡵࡀࠫ涑"),l11lll_l1_ (u"ࠨࡥࡷࡳࡰ࡫࡮࠾ࠩ涒"),l11lll_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ涓"),l11lll_l1_ (u"ࠪࡦࡵࡃࠧ涔"),l11lll_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩࡃࠧ涕")]
	l1ll1lll11111_l1_ = not any(value in url for value in l1ll1lll11l11_l1_)
	if l1ll1lll11111_l1_ and l11lllllll_l1_:
		l11ll1l11_l1_ = l11lll_l1_ (u"ࠬอไษฯฮࠫ涖")
		l1lll1lll_l1_ = l11lll_l1_ (u"࠭โ้ษษ้ࠥอไหึ฽๎้࠭涗")
		l11ll11ll_l1_ = l11lll_l1_ (u"ࠧศๆไ๎ิ๐่่ษอࠫ涘")
		l1ll1lll1111l_l1_ = l11lll_l1_ (u"ࠨษ็ๆ๋๎วหࠩ涙")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ涚"),l111ll_l1_+l11lllllll_l1_,url,9999)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧฮอฬࠤࠪ涛") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ涜"),l111ll_l1_+l11ll1l11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭涝"),l11lll_l1_ (u"࠭ࠧ涞"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ涟"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥๆํอฦๆࠢส่ฯฺฺ๋ๆࠥࠫ涠") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ涡"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ涢"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅใํำ๏๎็ศฬࠥࠫ涣") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ涤"),l111ll_l1_+l11ll11ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ涥"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ润") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ涧"),l111ll_l1_+l1ll1lll1111l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ涨"),144)
		if l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾࡙ࠧࡥࡢࡴࡦ࡬ࠧ࠭涩") in html: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ涪"),l111ll_l1_+l11ll1l11_l1_,url,145,l11lll_l1_ (u"ࠬ࠭涫"),l11lll_l1_ (u"࠭ࠧ涬"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ涭"))
		if l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠨࠧ涮") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ涯"),l111ll_l1_+l1lll1lll_l1_,url+l11lll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ涰"),144)
		if l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ涱") in html: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ液"),l111ll_l1_+l11ll11ll_l1_,url+l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ涳"),144)
		if l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ涴") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ涵"),l111ll_l1_+l1ll1lll1111l_l1_,url+l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ涶"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ涷"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ涸"),l11lll_l1_ (u"ࠬ࠭涹"),9999)
	if l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ涺") in url:
		dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ涻")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ涼")][l11lll_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ涽")][l11lll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ涾")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭涿")]
		l1ll1ll1lllll_l1_ = 0
		for i in range(len(dd)):
			if l11lll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ淀") in list(dd[i].keys()):
				l1ll1ll1llll1_l1_ = dd[i][l11lll_l1_ (u"࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ淁")]
				length = len(str(l1ll1ll1llll1_l1_))
				if length>l1ll1ll1lllll_l1_:
					l1ll1ll1lllll_l1_ = length
					ff = l1ll1ll1llll1_l1_
		if l1ll1ll1lllll_l1_==0: return
	elif l11lll_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ淂") in url or l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁ࡮ࡩࡾࡃࠧ淃") in url or l11lll_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ淄") in url or l11lll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ淅") in url or l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ淆") in url or url==l11ll1_l1_:
		l1ll1llll1l1l_l1_ = []
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ淇"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ淈"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ淉"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ淊"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬࡣࠢ淋"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠲࠷࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ淌"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡡࡣࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ淍"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰ࡚ࡥࡹࡩࡨࡏࡧࡻࡸࡗ࡫ࡳࡶ࡮ࡷࡷࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨ࡟ࠥ淎"))
		l1ll1lll111ll_l1_,ff = l1ll1lll1l1l1_l1_(cc,l11lll_l1_ (u"࠭ࠧ淏"),l1ll1llll1l1l_l1_)
	if not ff:
		try:
			dd = cc[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ淐")][l11lll_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ淑")][l11lll_l1_ (u"ࠩࡷࡥࡧࡹࠧ淒")]
			l1ll11ll11l1_l1_ = l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ淓") in url or l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ淔") in url or l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ淕") in url
			l1ll1lll1lll1_l1_ = l11lll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭淖") in html or l11lll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ淗") in html or l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้่ๆ้ษอࠦࠬ淘") in html
			l1ll1lll1ll1l_l1_ = l11lll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽࡛ࠦ࡯ࡤࡦࡱࡶࠦࠬ淙") in html or l11lll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ淚") in html or l11lll_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ淛") in html
			if l1ll11ll11l1_l1_ and (l1ll1lll1lll1_l1_ or l1ll1lll1ll1l_l1_):
				for l11l1lllll_l1_ in range(len(dd)):
					if l11lll_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ淜") not in list(dd[l11l1lllll_l1_].keys()): continue
					ee = dd[l11l1lllll_l1_][l11lll_l1_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ淝")]
					try: gg = ee[l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ淞")][l11lll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ淟")][l11lll_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ淠")][l11lll_l1_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ淡")][l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡙ࡿࡰࡦࡕࡸࡦࡒ࡫࡮ࡶࡋࡷࡩࡲࡹࠧ淢")][l11l1lllll_l1_]
					except: gg = ee
					try: link = gg[l11lll_l1_ (u"ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ淣")][l11lll_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ淤")][l11lll_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ淥")][l11lll_l1_ (u"ࠨࡷࡵࡰࠬ淦")]
					except: continue
					if   l11lll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ淧")		in link	and l11lll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ淨")		in url: ee = dd[l11l1lllll_l1_] ; break
					elif l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ淩")	in link	and l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ淪")	in url: ee = dd[l11l1lllll_l1_] ; break
					elif l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ淫")	in link	and l11lll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ淬")		in url: ee = dd[l11l1lllll_l1_] ; break
					else: ee = dd[0]
			elif l11lll_l1_ (u"ࠨࡤࡳࡁࠬ淭") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11lll_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ淮")][l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ淯")]
		except: pass
	if not ff: return
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ淰"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ深"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ淲"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ淳"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ淴"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡥࡷࡪࡳࠨ࡟ࠥ淵"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ淶"))
	if l11lll_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿ࠪ混") not in url: l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡸࡻࡢࡎࡧࡱࡹࠬࡣ࡛ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩࡠࠦ淸"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ淹"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ淺"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ添"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ淼"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ淽"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞ࠤ淾"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ淿"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ渀"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡧࡨࠥ渁"))
	l1111l1111l_l1_ = l1l11lll11l1_l1_(l11lll_l1_ (u"ࡶࠩๆ่่่ࠥศศ่ࠤฬ๊สี฼ํ่ࠬ渂"))
	l1111l111l1_l1_ = l1l11lll11l1_l1_(l11lll_l1_ (u"ࡷࠪ็้ࠦวๅใํำ๏๎็ศฬࠪ渃"))
	l1ll1lll1l111_l1_ = l1l11lll11l1_l1_(l11lll_l1_ (u"ࡸ่๊ࠫࠠศๆๅ๊ํอสࠨ渄"))
	l11ll1l11ll1_l1_ = [l1111l1111l_l1_,l1111l111l1_l1_,l1ll1lll1l111_l1_,l11lll_l1_ (u"ࠫࡆࡲ࡬ࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ清"),l11lll_l1_ (u"ࠬࡇ࡬࡭ࠢࡹ࡭ࡩ࡫࡯ࡴࠩ渆"),l11lll_l1_ (u"࠭ࡁ࡭࡮ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ渇")]
	l1ll1lll11l1l_l1_,gg = l1ll1lll1l1l1_l1_(ff,index,l1ll1llll1l1l_l1_)
	if l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ済") in str(type(gg)) and any(value in str(gg[0]) for value in l11ll1l11ll1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l1ll1llll1l1l_l1_ = []
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ渉"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ渊"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ渋"))
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ渌"))		#4
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ渍"))		#7
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ渎"))		#6
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ渏"))		#5
		l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ渐"))
		l1ll1lll111ll_l1_,item = l1ll1lll1l1l1_l1_(gg,index2,l1ll1llll1l1l_l1_)
		#if l1ll1lll111ll_l1_ not in [l11lll_l1_ (u"ࠩ࠵ࠫ渑"),l11lll_l1_ (u"ࠪ࠸ࠬ渒"),l11lll_l1_ (u"ࠫ࠺࠭渓")]: l1lll111lll11_l1_(item)		# 2,4,7
		#else: l1lll111lll11_l1_(item,url,str(index2))
		l1lll111lll11_l1_(item,url,str(index2))
		if l1ll1lll111ll_l1_==l11lll_l1_ (u"ࠬ࠺ࠧ渔"):
			try:
				hh = item[l11lll_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭渕")][l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ渖")][l11lll_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ渗")][l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ渘")]
				for l1lll1111l1ll_l1_ in range(len(hh)):
					l11ll1lll11l_l1_ = hh[l1lll1111l1ll_l1_]
					l1lll111lll11_l1_(l11ll1lll11l_l1_)
			except: pass
	l1lllll1l1l_l1_ = False
	if l11lll_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ渙") not in url and l1ll1lll11l1l_l1_==l11lll_l1_ (u"ࠫ࠽࠭渚"): l1lllll1l1l_l1_ = True
	if l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ減") in l11llll11_l1_: l1lll111l1l11_l1_,key,l1lll11l11l11_l1_,l1lll1111lll1_l1_,token,l1lll11111111_l1_ = l11llll11_l1_.split(l11lll_l1_ (u"࠭࠺࠻࠼ࠪ渜"))
	else: l1lll111l1l11_l1_,key,l1lll11l11l11_l1_,l1lll1111lll1_l1_,token,l1lll11111111_l1_ = l11lll_l1_ (u"ࠧࠨ渝"),l11lll_l1_ (u"ࠨࠩ渞"),l11lll_l1_ (u"ࠩࠪ渟"),l11lll_l1_ (u"ࠪࠫ渠"),l11lll_l1_ (u"ࠫࠬ渡"),l11lll_l1_ (u"ࠬ࠭渢")
	l11l11l_l1_,l1lll11ll1l_l1_ = l11lll_l1_ (u"࠭ࠧ渣"),l11lll_l1_ (u"ࠧࠨ渤")
	if menuItemsLIST:
		l1ll1lll1ll11_l1_ = str(menuItemsLIST[-1][1])
		if   l111ll_l1_+l11lll_l1_ (u"ࠨࡅࡋࡒࡑ࠭渥") in l1ll1lll1ll11_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ渦")
		elif l111ll_l1_+l11lll_l1_ (u"࡙ࠪࡘࡋࡒࠨ渧") in l1ll1lll1ll11_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭渨")
		elif l111ll_l1_+l11lll_l1_ (u"ࠬࡒࡉࡔࡖࠪ温") in l1ll1lll1ll11_l1_: l1lll11ll1l_l1_ = l11lll_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ渪")
	if l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ渫") in html and l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ測") not in url and not l1lllll1l1l_l1_ and l11lll_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ渭") not in url:	# and (index!=l11lll_l1_ (u"ࠪࠫ渮") or l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ港") in url or l11lll_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ渰") in url or l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭渱") in url or l11lll_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭渲") in url):
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ渳")+l1lll11l11l11_l1_
	elif l11lll_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ渴") in html and l11lll_l1_ (u"ࠪࡦࡵࡃࠧ渵") not in url and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ渶") in url or l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ渷") in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ游")+key
	elif l11lll_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢࠨ渹") in html and l11lll_l1_ (u"ࠨࡤࡳࡁࠬ渺") not in url:
		l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭渻")+key
	if l11l11l_l1_: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ渼"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ渽"),l11l11l_l1_,144,l1lll11ll1l_l1_,l11lll_l1_ (u"ࠬ࠭渾"),l11llll11_l1_)
	return
def l1ll1lll1l1l1_l1_(l11lll1l1ll1_l1_,l11llll111l1_l1_,l1ll1llllll1l_l1_):
	cc = l11lll1l1ll1_l1_
	ff,index = l11lll1l1ll1_l1_,l11llll111l1_l1_
	gg,index2 = l11lll1l1ll1_l1_,l11llll111l1_l1_
	item,render = l11lll1l1ll1_l1_,l11llll111l1_l1_
	count = len(l1ll1llllll1l_l1_)
	for l11l1lllll_l1_ in range(count):
		try:
			out = eval(l1ll1llllll1l_l1_[l11l1lllll_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"࠭ࠧ渿")
			return str(l11l1lllll_l1_+1),out
		except: pass
	return l11lll_l1_ (u"ࠧࠨ湀"),l11lll_l1_ (u"ࠨࠩ湁")
def l1lll11l11l1l_l1_(item):
	try: l1lll111ll111_l1_ = list(item.keys())[0]
	except: return False,l11lll_l1_ (u"ࠩࠪ湂"),l11lll_l1_ (u"ࠪࠫ湃"),l11lll_l1_ (u"ࠫࠬ湄"),l11lll_l1_ (u"ࠬ࠭湅"),l11lll_l1_ (u"࠭ࠧ湆"),l11lll_l1_ (u"ࠧࠨ湇"),l11lll_l1_ (u"ࠨࠩ湈")
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_ = False,l11lll_l1_ (u"ࠩࠪ湉"),l11lll_l1_ (u"ࠪࠫ湊"),l11lll_l1_ (u"ࠫࠬ湋"),l11lll_l1_ (u"ࠬ࠭湌"),l11lll_l1_ (u"࠭ࠧ湍"),l11lll_l1_ (u"ࠧࠨ湎"),l11lll_l1_ (u"ࠨࠩ湏")
	#WRITE_THIS(l11lll_l1_ (u"ࠩࠪ湐"),str(item))
	render = item[l1lll111ll111_l1_]
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ湑"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ湒"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ湓"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ湔"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ湕"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ湖"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ湗"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ湘"))
	l1ll1lll111ll_l1_,title = l1ll1lll1l1l1_l1_(item,render,l1ll1llll1l1l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ湙"),l11lll_l1_ (u"ࠬ࠭湚"),l11lll_l1_ (u"࠭ࠧ湛"),title)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ湜"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ湝"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ湞"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ湟")) # required for l11lll11l11l_l1_ l1lllll1l1l_l1_
	l1ll1lll111ll_l1_,link = l1ll1lll1l1l1_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ湠"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ湡"))
	l1ll1lll111ll_l1_,l1llll_l1_ = l1ll1lll1l1l1_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ湢"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ湣"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ湤"))
	l1ll1lll111ll_l1_,count = l1ll1lll1l1l1_l1_(item,render,l1ll1llll1l1l_l1_)
	l1ll1llll1l1l_l1_ = []
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡰࡪࡴࡧࡵࡪࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ湥"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ湦"))
	l1ll1llll1l1l_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ湧"))
	l1ll1lll111ll_l1_,l1l111l1ll_l1_ = l1ll1lll1l1l1_l1_(item,render,l1ll1llll1l1l_l1_)
	if l11lll_l1_ (u"ࠬࡒࡉࡗࡇࠪ湨") in l1l111l1ll_l1_: l1l111l1ll_l1_,l1111llllll_l1_ = l11lll_l1_ (u"࠭ࠧ湩"),l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ湪")
	if l11lll_l1_ (u"ࠨ็หหูืࠧ湫") in l1l111l1ll_l1_: l1l111l1ll_l1_,l1111llllll_l1_ = l11lll_l1_ (u"ࠩࠪ湬"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ湭")
	if l11lll_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ湮") in list(render.keys()):
		l1lll111lll1l_l1_ = str(render[l11lll_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ湯")])
		if l11lll_l1_ (u"࠭ࡆࡳࡧࡨࠤࡼ࡯ࡴࡩࠢࡄࡨࡸ࠭湰") in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠧࠥ࠼ࠪ湱")
		if l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࠦࡎࡐ࡙ࠪ湲") in l1lll111lll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ湳")
		if l11lll_l1_ (u"ࠪࡆࡺࡿࠧ湴") in l1lll111lll1l_l1_ or l11lll_l1_ (u"ࠫࡗ࡫࡮ࡵࠩ湵") in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠬࠪࠤ࠻ࠩ湶")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡻࠧๆสสุึ࠭湷")) in l1lll111lll1l_l1_: l1111llllll_l1_ = l11lll_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ湸")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡶࠩืีฬวࠧ湹")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠩࠧࠨ࠿࠭湺")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡸࠫฬูสวฮสีࠬ湻")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"ࠫࠩࠪ࠺ࠨ湼")
		if l1l11lll11l1_l1_(l11lll_l1_ (u"ࡺ࠭ลฺๆส๊ฬะࠧ湽")) in l1lll111lll1l_l1_: l1lll1111l11l_l1_ = l11lll_l1_ (u"࠭ࠤ࠻ࠩ湾")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ湿") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠨࡁࠪ満"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ溁") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ溂")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll1111l11l_l1_: title = l1lll1111l11l_l1_+l11lll_l1_ (u"ࠫࠥࠦࠧ溃")+title
	#title = unescapeHTML(title)
	l1l111l1ll_l1_ = l1l111l1ll_l1_.replace(l11lll_l1_ (u"ࠬ࠲ࠧ溄"),l11lll_l1_ (u"࠭ࠧ溅"))
	count = count.replace(l11lll_l1_ (u"ࠧ࠭ࠩ溆"),l11lll_l1_ (u"ࠨࠩ溇"))
	count = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭溈"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"ࠪࠫ溉")
	return True,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_
def l1lll111lll11_l1_(item,url=l11lll_l1_ (u"ࠫࠬ溊"),index=l11lll_l1_ (u"ࠬ࠭溋")):
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l1111llllll_l1_,l1lll1111l11l_l1_ = l1lll11l11l1l_l1_(item)
	#if l11lll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ溌") in url and index==l11lll_l1_ (u"ࠧ࠱ࠩ溍"):
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ溎"),l111ll_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭溏") in str(item): return	# l1lll11l11l11_l1_ not items
	elif l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ源") in str(item): return			# l1lll111ll1l1_l1_ not items
	elif not link and l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ溑") in url: return			# separator l1ll1ll1lll1l_l1_ list not items
	elif title and not link and (l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ溒") in url or l11lll_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭溓") in str(item) or url==l11ll1_l1_):
		title = l11lll_l1_ (u"ࠧ࠾࠿ࡀࠤࠬ溔")+title+l11lll_l1_ (u"ࠨࠢࡀࡁࡂ࠭溕")
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ準"),l111ll_l1_+title,l11lll_l1_ (u"ࠪࠫ溗"),9999)
	elif title and l11lll_l1_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭溘") in str(item):
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ溙"),l111ll_l1_+title,l11lll_l1_ (u"࠭ࠧ溚"),9999)
	elif l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ溛") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ溜"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif not title: return
	elif l1111llllll_l1_: addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ溝"),l111ll_l1_+l1111llllll_l1_+title,link,143,l1llll_l1_)
	#elif l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ溞") in link and l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡀࠫ溟") not in link and l11lll_l1_ (u"ࠬࡺ࠽࠱ࠩ溠") not in link:
	#	l1lll1111l1l1_l1_ = re.findall(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡁ࠭࠴ࠪࡀࠫࠧࠫ溡"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ溢")+l1lll1111l1l1_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ溣"),l111ll_l1_+l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ溤")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ溥")+title,link,144,l1llll_l1_)
	elif l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭溦") in link or l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ溧") in link:
		if l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭溨") in link and l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ溩") not in link:
			l1lll1111l1l1_l1_ = link.split(l11lll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ溪"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ溫")+l1lll1111l1l1_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ溬"),l111ll_l1_+l11lll_l1_ (u"ࠫࡑࡏࡓࡕࠩ溭")+count+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ溮")+title,link,144,l1llll_l1_)
		else:
			link = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭溯"),1)[0]
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭溰"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	else:
		type = l11lll_l1_ (u"ࠨࠩ溱")
		if not link: link = url
		#if l11lll_l1_ (u"ࠩࡶࡷࡂ࠭溲") in link: link = url
		#elif l11lll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭溳") in link: link = url		# not needed it will stop l1ll1lll1l11l_l1_ l11lll11l11l_l1_ l1lllll1l1l_l1_
		elif not any(value in link for value in [l11lll_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ溴"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ溵"),l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ溶"),l11lll_l1_ (u"ࠧ࠰ࡨࡨࡥࡹࡻࡲࡦࡦࠪ溷"),l11lll_l1_ (u"ࠨࡵࡶࡁࠬ溸"),l11lll_l1_ (u"ࠩࡥࡴࡂ࠭溹")]):
			if l11lll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭溺")	in link or l11lll_l1_ (u"ࠫ࠴ࡩ࠯ࠨ溻") in link: type = l11lll_l1_ (u"ࠬࡉࡈࡏࡎࠪ溼")+count+l11lll_l1_ (u"࠭࠺ࠡࠢࠪ溽")
			if l11lll_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ溾") in link: type = l11lll_l1_ (u"ࠨࡗࡖࡉࡗ࠭溿")+count+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭滀")
			index,l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠪࠫ滁"),l11lll_l1_ (u"ࠫࠬ滂")
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ滃"),l111ll_l1_+type+title,link,144,l1llll_l1_,index)
	return
def l1lll1111l111_l1_(url,data=l11lll_l1_ (u"࠭ࠧ滄"),request=l11lll_l1_ (u"ࠧࠨ滅")):
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ滆"))
	#if l11lll_l1_ (u"ࠩࡢࡣࠬ滇") in l1lll111l11l1_l1_: l1lll111l11l1_l1_ = l11lll_l1_ (u"ࠪࠫ滈")
	#if l11lll_l1_ (u"ࠫࡸࡹ࠽ࠨ滉") in url: url = url.split(l11lll_l1_ (u"ࠬࡹࡳ࠾ࠩ滊"))[0]
	if request==l11lll_l1_ (u"࠭ࠧ滋"): request = l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ滌")
	l111lll1l1_l1_ = l1l11l11l_l1_()
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ滍"):l111lll1l1_l1_,l11lll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ滎"):l11lll_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ滏")}
	#l1l1ll1ll_l1_ = headers.copy()
	if l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ滐") in data: l1lll111l1l11_l1_,key,l1lll11l11l11_l1_,l1lll1111lll1_l1_,token,l1lll11111111_l1_ = data.split(l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ滑"))
	else: l1lll111l1l11_l1_,key,l1lll11l11l11_l1_,l1lll1111lll1_l1_,token,l1lll11111111_l1_ = l11lll_l1_ (u"࠭ࠧ滒"),l11lll_l1_ (u"ࠧࠨ滓"),l11lll_l1_ (u"ࠨࠩ滔"),l11lll_l1_ (u"ࠩࠪ滕"),l11lll_l1_ (u"ࠪࠫ滖"),l11lll_l1_ (u"ࠫࠬ滗")
	if l11lll_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ滘") in url:
		l11llll11_l1_ = {}
		l11llll11_l1_[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ滙")] = {l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࠢ滚"):{l11lll_l1_ (u"ࠣࡪ࡯ࠦ滛"):l11lll_l1_ (u"ࠤࡤࡶࠧ滜"),l11lll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠢ滝"):l11lll_l1_ (u"ࠦ࡜ࡋࡂࠣ滞"),l11lll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠧ滟"):l1lll1111lll1_l1_}}
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ滠"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ满"))
	elif l11lll_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭滢") in url and l1lll111l1l11_l1_:
		l11llll11_l1_ = {l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ滣"):token}
		l11llll11_l1_[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ滤")] = {l11lll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ滥"):{l11lll_l1_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ滦"):l1lll111l1l11_l1_,l11lll_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ滧"):l11lll_l1_ (u"ࠢࡘࡇࡅࠦ滨"),l11lll_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ滩"):l1lll1111lll1_l1_}}
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ滪"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠷ࡴࡤࠨ滫"))
	elif l11lll_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ滬") in url and l1lll11111111_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡐࡤࡱࡪ࠭滭"):l11lll_l1_ (u"࠭࠱ࠨ滮"),l11lll_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰࡚ࡪࡸࡳࡪࡱࡱࠫ滯"):l1lll1111lll1_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ滰"):l11lll_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋ࠽ࠨ滱")+l1lll11111111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ滲"),url,l11lll_l1_ (u"ࠫࠬ滳"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭滴"),l11lll_l1_ (u"࠭ࠧ滵"),l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ滶"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ滷"),url,l11lll_l1_ (u"ࠩࠪ滸"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ滹"),l11lll_l1_ (u"ࠫࠬ滺"),l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠴ࡵࡪࠪ滻"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭滼"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭滽"),html,re.DOTALL|re.I)
	if tmp: l1lll1111lll1_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ滾"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ滿"),html,re.DOTALL|re.I)
	if tmp: l1lll111l1l11_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ漀"),html,re.DOTALL|re.I)
	if tmp: l1lll11l11l11_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ漁") in list(cookies.keys()): l1lll11111111_l1_ = cookies[l11lll_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ漂")]
	data = l1lll111l1l11_l1_+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ漃")+key+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ漄")+l1lll11l11l11_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ漅")+l1lll1111lll1_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭漆")+token+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ漇")+l1lll11111111_l1_
	if request==l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ漈") and l11lll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ漉") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ漊"),html,re.DOTALL)
		if not l111ll1ll1_l1_: l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ漋"),html,re.DOTALL)
		l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠨࡵࡷࡶࠬ漌"),l111ll1ll1_l1_[0])
	elif request==l11lll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ漍") and l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ漎") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ漏"),html,re.DOTALL)
		l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠬࡹࡴࡳࠩ漐"),l111ll1ll1_l1_[0])
	elif l11lll_l1_ (u"࠭࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ漑") not in html: l1ll1llll1ll1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ漒"),html)
	else: l1ll1llll1ll1_l1_ = l11lll_l1_ (u"ࠨࠩ漓")
	#open(l11lll_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭演"),l11lll_l1_ (u"ࠪࡻࠬ漕")).write(str(l1ll1llll1ll1_l1_))
	#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ漖"),l11lll_l1_ (u"ࠬࡽࠧ漗")).write(html)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ漘"),data)
	return html,l1ll1llll1ll1_l1_,data
def l1lll11l1111l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ漙"),l11lll_l1_ (u"ࠨ࠭ࠪ漚"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ漛")+search
	ITEMS(l11l11l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬ漜"),l11lll_l1_ (u"ࠫ࠰࠭漝"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ漞")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ漟") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ漠")
		elif l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ漡") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ漢")
		elif l11lll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ漣") in options: l1lll111111l1_l1_ = l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ漤")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111111l1_l1_
	else:
		l1lll1111111l_l1_,l1ll1llll11l1_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠬ࠭漥")
		l1ll1llll1l11_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤฯืส๋สࠪ漦"),l11lll_l1_ (u"ࠧหำอ๎อࠦอิส้ࠣิ๏ࠠศๆุ่ฮ࠭漧"),l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฯอั๋ะࠣห้ะอๆ์็ࠫ漨"),l11lll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥ฿ฯะࠢสฺ่๊ว่ัสฮࠬ漩"),l11lll_l1_ (u"ࠪฮึะ๊ษࠢะือࠦวๅฬๅ๎๏๋ࠧ漪")]
		l1lll111ll11l_l1_ = [l11lll_l1_ (u"ࠫࠬ漫"),l11lll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡆࠫ࠲࠶࠵ࡇࠫ漬"),l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡏࠥ࠳࠷࠶ࡈࠬ漭"),l11lll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡍࠦ࠴࠸࠷ࡉ࠭漮"),l11lll_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡆࠧ࠵࠹࠸ࡊࠧ漯")]
		l1lll111llll1_l1_ = DIALOG_SELECT(l11lll_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆอีฯ๐ศࠨ漰"),l1ll1llll1l11_l1_)
		if l1lll111llll1_l1_ == -1: return
		l1ll1llllllll_l1_ = l1lll111ll11l_l1_[l1lll111llll1_l1_]
		html,c,data = l1lll1111l111_l1_(l11l11l_l1_+l1ll1llllllll_l1_)
		if c:
			d = c[l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ漱")][l11lll_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ漲")][l11lll_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ漳")][l11lll_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ漴")][l11lll_l1_ (u"ࠧࡴࡷࡥࡑࡪࡴࡵࠨ漵")][l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ漶")][l11lll_l1_ (u"ࠩࡪࡶࡴࡻࡰࡴࠩ漷")]
			for l1ll1llll111l_l1_ in range(len(d)):
				group = d[l1ll1llll111l_l1_][l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡉࡵࡳࡺࡶࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ漸")][l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ漹")]
				for l1lll11l111l1_l1_ in range(len(group)):
					render = group[l1lll11l111l1_l1_][l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬ漺")]
					if l11lll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ漻") in list(render.keys()):
						link = render[l11lll_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ漼")][l11lll_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ漽")][l11lll_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ漾")][l11lll_l1_ (u"ࠪࡹࡷࡲࠧ漿")]
						link = link.replace(l11lll_l1_ (u"ࠫࡡࡻ࠰࠱࠴࠹ࠫ潀"),l11lll_l1_ (u"ࠬࠬࠧ潁"))
						title = render[l11lll_l1_ (u"࠭ࡴࡰࡱ࡯ࡸ࡮ࡶࠧ潂")]
						title = title.replace(l11lll_l1_ (u"ࠧศๆหัะูࠦ็ࠢࠪ潃"),l11lll_l1_ (u"ࠨࠩ潄"))
						if l11lll_l1_ (u"ࠩศึฬ๊ษࠡษ็ๅ้ะัࠨ潅") in title: continue
						if l11lll_l1_ (u"ࠪๆฬฬๅสࠢอุ฿๐ไࠨ潆") in title:
							title = l11lll_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ潇")+title
							l1lll1lll_l1_ = title
							l1lllllll1_l1_ = link
						if l11lll_l1_ (u"ࠬะัห์หࠤาูศࠨ潈") in title: continue
						title = title.replace(l11lll_l1_ (u"࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠣࠫ潉"),l11lll_l1_ (u"ࠧࠨ潊"))
						if l11lll_l1_ (u"ࠨࡔࡨࡱࡴࡼࡥࠨ潋") in title: continue
						if l11lll_l1_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫ潌") in title:
							title = l11lll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ潍")+title
							l1lll1lll_l1_ = title
							l1lllllll1_l1_ = link
						if l11lll_l1_ (u"ࠫࡘࡵࡲࡵࠢࡥࡽࠬ潎") in title: continue
						l1lll1111111l_l1_.append(escapeUNICODE(title))
						l1ll1llll11l1_l1_.append(link)
		if not l1lll1lll_l1_: l1lll111l1ll1_l1_ = l11lll_l1_ (u"ࠬ࠭潏")
		else:
			l1lll1111111l_l1_ = [l11lll_l1_ (u"࠭ศะ๊้ࠤๆ๊สาࠩ潐"),l1lll1lll_l1_]+l1lll1111111l_l1_
			l1ll1llll11l1_l1_ = [l11lll_l1_ (u"ࠧࠨ潑"),l1lllllll1_l1_]+l1ll1llll11l1_l1_
			l1lll11l11111_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅใ็ฮึ࠭潒"),l1lll1111111l_l1_)
			if l1lll11l11111_l1_ == -1: return
			l1lll111l1ll1_l1_ = l1ll1llll11l1_l1_[l1lll11l11111_l1_]
		if l1lll111l1ll1_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll111l1ll1_l1_
		elif l1ll1llllllll_l1_: l11l1l1_l1_ = l11l11l_l1_+l1ll1llllllll_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠤࠥࠦࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡓࡧࡰࡳࡻ࡫ࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠩ࠯ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ࡙ࠬࠬ࡯ࡳࡶࠣࡦࡾ࠭ࠬࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ࠭ࠩࠩࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯ࠩࠋࠋࠌࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡲࡶࡹࠦࡢࡺ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠦࠧࠨ潓")
	ITEMS(l11l1l1_l1_)
	return
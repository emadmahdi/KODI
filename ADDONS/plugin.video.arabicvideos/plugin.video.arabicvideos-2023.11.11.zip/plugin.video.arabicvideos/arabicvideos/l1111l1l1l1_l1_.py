# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ揶")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬ揷")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ揸"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1111l_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1lll11lll11l_l1_(url)
	elif mode==314: results = l1lllll1l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ揹"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ揺"),l11lll_l1_ (u"ࠪࠫ揻"),319,l11lll_l1_ (u"ࠫࠬ揼"),l11lll_l1_ (u"ࠬ࠭揽"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ揾"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ揿"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึ࠭搀"),l11lll_l1_ (u"ࠩࠪ搁"),114,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ搂"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ搃"),l11lll_l1_ (u"ࠬ࠭搄"),l11lll_l1_ (u"࠭ࠧ搅"),l11lll_l1_ (u"ࠧࠨ搆"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭搇"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡦࡰࡸࡰ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭搈"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ搉"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ搊"),l11lll_l1_ (u"ࠬ࠭搋"),9999)
	items = re.findall(l11lll_l1_ (u"࠭࠼ࡩ࠷ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠺ࡄࠧ搌"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11lll_l1_ (u"ࠧࠡࠩ損"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ搎"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ搏")+l111ll_l1_+title,l11ll1_l1_,314,l11lll_l1_ (u"ࠪࠫ搐"),l11lll_l1_ (u"ࠫࠬ搑"),str(seq+1))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ搒"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ搓")+l111ll_l1_+l11lll_l1_ (u"ࠧๆไส฻฾ࠦิ่ำࠪ搔"),l11ll1_l1_,314,l11lll_l1_ (u"ࠨࠩ搕"),l11lll_l1_ (u"ࠩࠪ搖"),l11lll_l1_ (u"ࠪ࠴ࠬ搗"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ搘"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ搙"),l11lll_l1_ (u"࠭ࠧ搚"),9999)
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡅࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡇࡄࠧ搛"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ搜")+link
		#title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ搝"))
		#url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡅ࡬ࡱࡦࡔ࡯ࡸ࠱ࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࠴࡬ࡩ࡭ࡶࡨࡶ࠳ࡶࡨࡱࠩ搞")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ搟"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ搠")+l111ll_l1_+title,link,311)
	return html
def l1lllll1l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ搡"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ搢"),l11lll_l1_ (u"ࠨࠩ搣"),l11lll_l1_ (u"ࠩࠪ搤"),l11lll_l1_ (u"ࠪࠫ搥"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡍࡃࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ搦"))
	html = response.content
	if seq==l11lll_l1_ (u"ࠬ࠶ࠧ搧"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡢࡤ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ搨"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ搩"),block,re.DOTALL)
		for link,name,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ搪")+link
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ搫"))
			name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ搬"))
			title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ搭")+name+l11lll_l1_ (u"ࠬ࠯ࠧ搮")
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ搯"),l111ll_l1_+title,link,312)
	elif seq in [l11lll_l1_ (u"ࠧ࠲ࠩ搰"),l11lll_l1_ (u"ࠨ࠴ࠪ搱"),l11lll_l1_ (u"ࠩ࠶ࠫ搲")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡁ࡮࠵࠿࠰࠭ࡃ࠮ࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡭ࡩࠪ搳"),html,re.DOTALL)
		l1lll11lll1l1_l1_ = int(seq)-1
		block = l1l1ll1_l1_[l1lll11lll1l1_l1_]
		if seq==l11lll_l1_ (u"ࠫ࠶࠭搴"): items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭搵"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ搶"),block,re.DOTALL)
		for link,l1llll_l1_,title,name in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ搷")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ搸")+link
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ搹"))
			name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ携"))
			title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ搻")+name+l11lll_l1_ (u"ࠬ࠯ࠧ搼")
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭搽"),l111ll_l1_+title,link,311,l1llll_l1_)
	elif seq in [l11lll_l1_ (u"ࠧ࠵ࠩ搾"),l11lll_l1_ (u"ࠨ࠷ࠪ搿"),l11lll_l1_ (u"ࠩ࠹ࠫ摀")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡁ࡮࠵࠿࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ摁"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1ll1_l1_[seq]
		items = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿࠮ࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ摂"),block,re.DOTALL)
		for l1llll_l1_,link,l1l11ll11ll_l1_,title,l1ll111lll1_l1_ in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ摃")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ摄")+link
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ摅"))
			l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ摆"))
			l1ll111lll1_l1_ = l1ll111lll1_l1_.strip(l11lll_l1_ (u"ࠩࠣࠫ摇"))
			if l1l11ll11ll_l1_: name = l1l11ll11ll_l1_
			else: name = l1ll111lll1_l1_
			title = title+l11lll_l1_ (u"ࠪࠤ࠭࠭摈")+name+l11lll_l1_ (u"ࠫ࠮࠭摉")
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ摊"),l111ll_l1_+title,link,312,l1llll_l1_)
	return
def l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ摋"),url,l11lll_l1_ (u"ࠧࠨ摌"),l11lll_l1_ (u"ࠨࠩ摍"),l11lll_l1_ (u"ࠩࠪ摎"),l11lll_l1_ (u"ࠪࠫ摏"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ摐"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡢࡰࡺ࠰࡬ࡪࡧࡤࡪࡰࡪࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡩࡰࡴࡧࡴ࠮ࡴ࡬࡫࡭ࡺࠧ摑"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	if l11lll_l1_ (u"࠭ࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪ࠭摒") in block:
		items = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄࡩࡡࡵࡵࡸࡱ࠲ࡳ࡯ࡣ࡫࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭摓"),block,re.DOTALL)
		if items:
			for l1llll_l1_,link,title,count in items:
				l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ摔")+l1llll_l1_
				link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ摕")+link
				count = count.replace(l11lll_l1_ (u"ࠪࠤฬ๊ี้ฬํอ࠿ࠦࠧ摖"),l11lll_l1_ (u"ࠫ࠿࠭摗"))
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ摘"))
				title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ摙")+count+l11lll_l1_ (u"ࠧࠪࠩ摚")
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ摛"),l111ll_l1_+title,link,311,l1llll_l1_)
	else:
		items = re.findall(l11lll_l1_ (u"ࠩࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ摜"),block,re.DOTALL)
		for link,title,l1lll11lll1ll_l1_,l1l111l1ll_l1_ in items:
			if title==l11lll_l1_ (u"ࠪࠫ摝") or l1lll11lll1ll_l1_==l11lll_l1_ (u"ࠫࠬ摞"): continue
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ摟")+link
			title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ摠")+l1l111l1ll_l1_+l11lll_l1_ (u"ࠧࠪࠩ摡")
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ摢"),l111ll_l1_+title,link,312)
	if not items: l1llllll_l1_(html)
	return
def l1llllll_l1_(html):
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ摣"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ摤"),block,re.DOTALL)
	for link,title,name,count,l1l111l1ll_l1_ in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭摥")+link
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ摦"))
		name = name.strip(l11lll_l1_ (u"࠭ࠠࠨ摧"))
		title = title+l11lll_l1_ (u"ࠧࠡࠪࠪ摨")+name+l11lll_l1_ (u"ࠨࠫࠪ摩")
		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ摪"),l111ll_l1_+title,link,312,l11lll_l1_ (u"ࠪࠫ摫"),l1l111l1ll_l1_)
	return
def l1lll11lll11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ摬"),url,l11lll_l1_ (u"ࠬ࠭摭"),l11lll_l1_ (u"࠭ࠧ摮"),l11lll_l1_ (u"ࠧࠨ摯"),l11lll_l1_ (u"ࠨࠩ摰"),l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲࡙ࡅࡂࡔࡆࡌࡤࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ摱"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠢࡳ࠱࠶ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ摲"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		l1111l_l1_(url)
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭摳"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ摴")+link
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ摵"))
		if l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠳ࠧ摶") in link: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ摷"),l111ll_l1_+title,link,312)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ摸"),l111ll_l1_+title,link,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ摹"),url,l11lll_l1_ (u"ࠫࠬ摺"),l11lll_l1_ (u"ࠬ࠭摻"),l11lll_l1_ (u"࠭ࠧ摼"),l11lll_l1_ (u"ࠧࠨ摽"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭摾"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩ࠿ࡥࡺࡪࡩࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ摿"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠪࡀࡻ࡯ࡤࡦࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ撀"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ撁"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭撂"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ撃"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ撄"),l11lll_l1_ (u"ࠨ࠭ࠪ撅"))
	l1lll11llll11_l1_ = [l11lll_l1_ (u"ࠩࠩࡸࡂࡧࠧ撆"),l11lll_l1_ (u"ࠪࠪࡹࡃࡣࠨ撇"),l11lll_l1_ (u"ࠫࠫࡺ࠽ࡴࠩ撈")]
	if l1ll_l1_:
		l1lll11lll111_l1_ = [l11lll_l1_ (u"่ࠬวาศࠪ撉"),l11lll_l1_ (u"࠭ลึัสีࠥ࠵ࠠๆฮ็ำࠬ撊"),l11lll_l1_ (u"ࠧๆไฺ฽ࠥอไึ๊อ๎ࠬ撋")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣ࠱ࠥษฮหำࠣห้ฮอฬࠩ撌"), l1lll11lll111_l1_)
		if l1l_l1_ == -1: return
	elif l11lll_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙࡟ࠨ撍") in options: l1l_l1_ = 0
	elif l11lll_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙࡟ࠨ撎") in options: l1l_l1_ = 1
	elif l11lll_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࡠࠩ撏") in options: l1l_l1_ = 2
	else: return
	type = l1lll11llll11_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭撐")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ撑"),url,l11lll_l1_ (u"ࠧࠨ撒"),l11lll_l1_ (u"ࠨࠩ撓"),l11lll_l1_ (u"ࠩࠪ撔"),l11lll_l1_ (u"ࠪࠫ撕"),l11lll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ撖"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ撗"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ撘"),block,re.DOTALL)
			for link,l1llll_l1_,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ撙"))
				name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ撚"))
				title = title+l11lll_l1_ (u"ࠩࠣࠬࠬ撛")+name+l11lll_l1_ (u"ࠪ࠭ࠬ撜")
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ撝"),l111ll_l1_+title,link,313,l1llll_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡹࡪ࠾࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿ࠫ撞"),block,re.DOTALL)
			for link,title,name in items:
				title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ撟"))
				name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ撠"))
				title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ撡")+name+l11lll_l1_ (u"ࠩࠬࠫ撢")
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ撣"),l111ll_l1_+title,link,312)
	return
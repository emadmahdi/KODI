# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ⠇")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭⠈")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨ็ุหึ฿ษࠨ⠉"),l11lll_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨ⠊"),l11lll_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩ⠋"),l11lll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭⠌"),l11lll_l1_ (u"ࠬออะอࠣห้อฺศ่์ࠫ⠍")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l1111l_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l1llllll_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⠎"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ⠏"),l11lll_l1_ (u"ࠨࠩ⠐"),l11lll_l1_ (u"ࠩࠪ⠑"),l11lll_l1_ (u"ࠪࠫ⠒"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⠓"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⠔"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⠕"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⠖"),l11lll_l1_ (u"ࠨࠩ⠗"),449,l11lll_l1_ (u"ࠩࠪ⠘"),l11lll_l1_ (u"ࠪࠫ⠙"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⠚"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⠛"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⠜")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆิส๏ู๊สࠩ⠝"),l11ll1_l1_,441)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⠞"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⠟"),l11lll_l1_ (u"ࠪࠫ⠠"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡢࡱࡪࡴࡵࡠࡴ࡬࡫࡭ࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⠡"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⠢"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if link==l11lll_l1_ (u"࠭ࠣࠨ⠣"): continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⠤"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⠥")+l111ll_l1_+title,link,441)
	return
def l1111l_l1_(url,l111ll1l_l1_=l11lll_l1_ (u"ࠩࠪ⠦")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ⠧"),url,l11lll_l1_ (u"ࠫࠬ⠨"),l11lll_l1_ (u"ࠬ࠭⠩"),l11lll_l1_ (u"࠭ࠧ⠪"),l11lll_l1_ (u"ࠧࠨ⠫"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⠬"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡳࡧ࡯ࡥࡹ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ⠭"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡀࡱ࡯࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠴ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⠮"),block,re.DOTALL)
	for link,title,l1llll_l1_ in items:
		if l11lll_l1_ (u"ࠫ࠴ࡻࡲ࡭࠱ࠪ⠯") in link: continue
		elif l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ⠰") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⠱"),l111ll_l1_+title,link,443,l1llll_l1_)
		elif l11lll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪ⠲") in link: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⠳"),l111ll_l1_+title,link,443,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⠴"),l111ll_l1_+title,link,442,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⠵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⠶"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⠷"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ⠸")+title,link,441)
	return
l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡶࡪࡦࡨࡳࡑࡏࡓࡕࠢࡀࠤࡠ࠭ๅีษ๊ำฮ࠭ࠬࠨใํ่๊࠭ࠬࠨษ฽๊๏ฯࠧ࠭ࠩๆ่๏ฮࠧ࠭ࠩส฽้อๆࠨ࠮๋ࠪิอแࠨ࠮้ࠪออัศหࠪ࠰ࠬ฿ัืࠩ࠯๊ࠫํัอษ้ࠫ࠱࠭วๅส๋้ࠬࡣࠊࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦ࠮࡬ࡱ࡬ࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡻ࡮ࡦࡵࡦࡥࡵ࡫ࡈࡕࡏࡏࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱ࡯࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡦࡴࡹࠩࡸࡤࡰࡺ࡫ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦࠢࡩࡳࡷࠦࡶࡢ࡮ࡸࡩࠥ࡯࡮ࠡࡸ࡬ࡨࡪࡵࡌࡊࡕࡗ࠭࠿ࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡸ࡬ࡨࡪࡵࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠶࠷࠶࠱࡯࡭ࡨࠫࠍࠍࠎ࡫࡬ࡪࡨࠣࡩࡵ࡯ࡳࡰࡦࡨࠤࡦࡴࡤࠡࠩส่า๊โสࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫࡤࡓࡏࡅࡡࠪࠤ࠰ࠦࡥࡱ࡫ࡶࡳࡩ࡫࡛࠱࡟ࠍࠍࠎࠏࡩࡧࠢࡷ࡭ࡹࡲࡥࠡࡰࡲࡸࠥ࡯࡮ࠡࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠾ࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠸࠲ࡩ࡮ࡩࠬࠎࠎࠏࠉࠊࡣ࡯ࡰ࡙࡯ࡴ࡭ࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡡࡴࡵࡨࡱࡧࡲࡹ࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠸࠶࠲ࡩ࡮ࡩࠬࠎࠎࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠵࠶࠶࠰࡮ࡳࡧࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࡩࡧࠢࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࡂ࠭ࠧ࠻ࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨ⠹")
def l1llllll_l1_(url):
	data = {l11lll_l1_ (u"ࠨࡘ࡬ࡩࡼ࠭⠺"):1}
	headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⠻"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ⠼")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ⠽"),url,data,headers,l11lll_l1_ (u"ࠬ࠭⠾"),l11lll_l1_ (u"࠭ࠧ⠿"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⡀"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠴࠼࠰ࡦ࡬ࡺࡃ࠭⡁"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨ⡂"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⡃"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡄"),l111ll_l1_+title,link,443,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡯ࡨ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⡅"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⡆"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ⡇"),l11lll_l1_ (u"ࠨࠩ⡈")).strip(l11lll_l1_ (u"ࠩࠣࠫ⡉"))
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⡊"),l111ll_l1_+title,link,442,l1llll_l1_)
	return
def PLAY(url):
	data = {l11lll_l1_ (u"࡛ࠫ࡯ࡥࡸࠩ⡋"):1}
	headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⡌"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ⡍")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ⡎"),url,data,headers,l11lll_l1_ (u"ࠨࠩ⡏"),l11lll_l1_ (u"ࠩࠪ⡐"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⡑"))
	html = response.content
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⡒"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡰ࡮ࡴ࡫࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪ⡓"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ⡔"),l11lll_l1_ (u"ࠧࠨ⡕")).strip(l11lll_l1_ (u"ࠨࠢࠪ⡖"))
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⡗")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⡘")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⡙"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࠨࡳࡦࡴ࠰ࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⡚"),block,re.DOTALL)
		for title,l11l111l_l1_,link in items:
			link = link.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ⡛"),l11lll_l1_ (u"ࠧࠨ⡜"))
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⡝")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⡞")+l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ⡟")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⡠"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⡡"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ⡢"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ⡣"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ⡤"),l11lll_l1_ (u"ࠩ࠮ࠫ⡥"))
	#search = unescapeHTML(search)
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⡦")+search
	l1111l_l1_(url)
	return
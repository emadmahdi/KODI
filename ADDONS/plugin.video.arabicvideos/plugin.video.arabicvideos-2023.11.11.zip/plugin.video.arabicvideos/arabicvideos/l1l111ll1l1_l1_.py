﻿# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#import unicodedata,simplejson
def MAIN(mode,l1l11l1111l_l1_):
	if l1l11l1111l_l1_==l11lll_l1_ (u"ࠬ࠭㚼"): return
	if mode==1:
		l1l11l11111_l1_ = xbmcgui.l1l111lllll_l1_()
		l1l111llll1_l1_ = xbmcgui.l1l111l1ll1_l1_(l1l11l11111_l1_)
		l1l11l1111l_l1_ = l1l111lll1l_l1_(l1l11l1111l_l1_)
		l1l111llll1_l1_.getControl(311).l1l11l111ll_l1_(l1l11l1111l_l1_)
	if mode==0:
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㚽"))
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ㚾"))
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㚿"))
		l1l111ll111_l1_=l11lll_l1_ (u"࡛ࠩࠫ㛀")
		if kodi_version>18.99: check = isinstance(l1l11l1111l_l1_,str)
		else: check = isinstance(l1l11l1111l_l1_,unicode)
		if check==True: l1l111ll111_l1_=l11lll_l1_ (u"࡙ࠪࠬ㛁")
		l1l111l1lll_l1_=str(type(l1l11l1111l_l1_))+l11lll_l1_ (u"ࠫࠥ࠭㛂")+l1l11l1111l_l1_+l11lll_l1_ (u"ࠬࠦࠧ㛃")+l1l111ll111_l1_+l11lll_l1_ (u"࠭ࠠࠨ㛄")
		for i in range(0,len(l1l11l1111l_l1_),1):
			l1l111l1lll_l1_ += hex(ord(l1l11l1111l_l1_[i])).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㛅"),l11lll_l1_ (u"ࠨࠩ㛆"))+l11lll_l1_ (u"ࠩࠣࠫ㛇")
		l1l11l1111l_l1_ = l1l111lll1l_l1_(l1l11l1111l_l1_)
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛈"))
		l1l111ll111_l1_=l11lll_l1_ (u"ࠫ࡝࠭㛉")
		if kodi_version>18.99: check = isinstance(l1l11l1111l_l1_, str)
		else: check = isinstance(l1l11l1111l_l1_, unicode)
		if check==True: l1l111ll111_l1_=l11lll_l1_ (u"࡛ࠬࠧ㛊")
		l1l111ll11l_l1_=str(type(l1l11l1111l_l1_))+l11lll_l1_ (u"࠭ࠠࠨ㛋")+l1l11l1111l_l1_+l11lll_l1_ (u"ࠧࠡࠩ㛌")+l1l111ll111_l1_+l11lll_l1_ (u"ࠨࠢࠪ㛍")
		for i in range(0,len(l1l11l1111l_l1_),1):
			l1l111ll11l_l1_ += hex(ord(l1l11l1111l_l1_[i])).replace(l11lll_l1_ (u"ࠩ࠳ࡼࠬ㛎"),l11lll_l1_ (u"ࠪࠫ㛏"))+l11lll_l1_ (u"ࠫࠥ࠭㛐")
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㛑"),l11lll_l1_ (u"࠭ࠧ㛒"),l1l111l1lll_l1_,l1l111ll11l_l1_)
	return
	#for i in range(0,len(l1l11l1111l_l1_)-2,3):
	#	string=hex(ord(l1l11l1111l_l1_[i+0]))+l11lll_l1_ (u"ࠧࠡࠢࠪ㛓")+hex(ord(l1l11l1111l_l1_[i+1]))+l11lll_l1_ (u"ࠨࠢࠣࠫ㛔")+hex(ord(l1l11l1111l_l1_[i+2]))
	#	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㛕"),l11lll_l1_ (u"ࠪࠫ㛖"),l11lll_l1_ (u"ࠫࠬ㛗"),string)
	#return
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㛘"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㛙"),l11lll_l1_ (u"ࠧࠨ㛚"),l11lll_l1_ (u"ࠨࠩ㛛"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l111lll1l_l1_(l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛜"))
	#l1l11l1111l_l1_ = unicodedata.normalize(l11lll_l1_ (u"ࠪࡒࡋࡑࡄࠨ㛝"),l1l11l1111l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㛞"),l11lll_l1_ (u"ࠬ࠭㛟"),l11lll_l1_ (u"࠭ࠧ㛠"),   hex(  unicodedata.combining(l1l11l1111l_l1_[0])  )   )
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㛡"),l11lll_l1_ (u"ࠨࠩ㛢"),l1l11l1111l_l1_,   hex(ord(  l1l11l1111l_l1_[0]  ))   )
	#new = l11lll_l1_ (u"ࠩࠪ㛣")
	#for l1l111ll1ll_l1_ in l1l11l1111l_l1_:
	#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㛤"),l11lll_l1_ (u"ࠫࠬ㛥"),l11lll_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㛦"),unicodedata.decomposition(l1l111ll1ll_l1_) )
	#	new += l11lll_l1_ (u"࠭࡜ࡶ࠲ࠪ㛧") + hex(ord(l1l111ll1ll_l1_)).replace(l11lll_l1_ (u"ࠧ࠱ࡺࠪ㛨"),l11lll_l1_ (u"ࠨࠩ㛩"))
	#l1l11l1111l_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㛪"),l11lll_l1_ (u"ࠪࠫ㛫"),l11lll_l1_ (u"ࠫࠬ㛬"),l1l11l1111l_l1_)
	#new = l11lll_l1_ (u"ࠬ࠭㛭")
	#for i in range(len(l1l11l1111l_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㛮"),l11lll_l1_ (u"ࠧࠨ㛯"),l11lll_l1_ (u"ࠨࠩ㛰"),str(i))
	#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1] + l1l11l1111l_l1_[i+2] + l1l11l1111l_l1_[i+3] + l1l11l1111l_l1_[i+4] + l1l11l1111l_l1_[i+5]
	#l1l11l1111l_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㛱"),l11lll_l1_ (u"ࠪࠫ㛲"),l11lll_l1_ (u"ࠫࠬ㛳"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㛴"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㛵"),l11lll_l1_ (u"ࠧࠨ㛶"),l11lll_l1_ (u"ࠨࠩ㛷"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛸"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㛹"),l11lll_l1_ (u"ࠫࠬ㛺"),l11lll_l1_ (u"ࠬ࠭㛻"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l11lll_l1_ (u"࠭ࡥ࡮ࡣࡧࠫ㛼")
	#l1l111lll11_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡉ࡯ࡲࡸࡸ࠳࡙ࡥ࡯ࡦࡗࡩࡽࡺࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠭㛽")+l1l11l1111l_l1_+l11lll_l1_ (u"ࠨࠤ࠯ࠦࡩࡵ࡮ࡦࠤ࠽ࡪࡦࡲࡳࡦࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫ㛾"))
	#simplejson.loads(l1l111lll11_l1_)
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.encode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㛿"))
	#new = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㜀"))
	#l1l11l1111l_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㜁"),l11lll_l1_ (u"ࠬ࠭㜂"),l11lll_l1_ (u"࠭ࠧ㜃"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l111lll1l_l1_(l1l11l1111l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ㜄"),l11lll_l1_ (u"ࠨࠩ㜅"),l11lll_l1_ (u"ࠩࠪ㜆"),l1l11l1111l_l1_)
	#new = l11lll_l1_ (u"ࠪࠫ㜇")
	#for i in range(len(l1l11l1111l_l1_)-2,-1,-2):
	#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1]
	#l1l11l1111l_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ㜈"),l11lll_l1_ (u"ࠬ࠭㜉"),l11lll_l1_ (u"࠭ࠧ㜊"),l1l11l1111l_l1_)
	#l1l11l1111l_l1_ = l1l11l1111l_l1_.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㜋"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㜌"),l11lll_l1_ (u"ࠩࠪ㜍"),l11lll_l1_ (u"ࠪࠫ㜎"),l1l11l1111l_l1_)
	#new = l11lll_l1_ (u"ࠫࠬ㜏")
	#for i in range(len(l1l11l1111l_l1_)-2,-1,-2):
	#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1]
	#l1l11l1111l_l1_ = new
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㜐"),l11lll_l1_ (u"࠭ࠧ㜑"),l11lll_l1_ (u"ࠧࠨ㜒"),l1l11l1111l_l1_)
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.replace(l11lll_l1_ (u"ࠨࠢࠪ㜓"),l11lll_l1_ (u"ࠩࠪ㜔"))
		#new = l11lll_l1_ (u"ࠪࠫ㜕")
		#for i in range(len(l1l11l1111l_l1_)-3,-2,-3):
		#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1] + l1l11l1111l_l1_[i+2]
		#l1l11l1111l_l1_ = new
		#new = l11lll_l1_ (u"ࠫࠬ㜖")
		#for i in range(len(l1l11l1111l_l1_)-2,-1,-2):
		#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1]
		#l1l11l1111l_l1_ = new
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㜗"),l11lll_l1_ (u"࠭ࠧ㜘"),l11lll_l1_ (u"ࠧࠨ㜙"),l1l11l1111l_l1_)
		#l1l11l1111l_l1_ = l1l11l1111l_l1_.l1l11l111l1_l1_(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㜚"))
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㜛"),l11lll_l1_ (u"ࠪࠫ㜜"),str(ord(l1l11l1111l_l1_[0]))+l11lll_l1_ (u"ࠫࠥ࠭㜝")+str(ord(l1l11l1111l_l1_[1]))+l11lll_l1_ (u"ࠬࠦࠧ㜞")+str(ord(l1l11l1111l_l1_[2])),str(len(l1l11l1111l_l1_)))
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ㜟"),l11lll_l1_ (u"ࠧࠨ㜠"),l11lll_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠡࡎࡨࡸࡹ࡫ࡲࡴࠩ㜡"),l1l11l1111l_l1_)
		#new = l11lll_l1_ (u"ࠩࠪ㜢")
		#for i in range(len(l1l11l1111l_l1_)-2,-1,-2):
		#	new += l1l11l1111l_l1_[i] + l1l11l1111l_l1_[i+1]
		#l1l11l1111l_l1_ = new
		#new = l1l11l1111l_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㜣"))
		#new = new.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㜤"))
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭㜥"),l11lll_l1_ (u"࠭ࠧ㜦"),l11lll_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ㜧"),new )
		#l1l111l1lll_l1_ = l11lll_l1_ (u"ࠨࠩ㜨")
		#for l1l111ll1ll_l1_ in new:
		#	DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㜩"),l11lll_l1_ (u"ࠪࠫ㜪"),l11lll_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㜫"),unicodedata.decomposition(l1l111ll1ll_l1_) )
		#	l1l111l1lll_l1_ += l11lll_l1_ (u"ࠬࡢࡵࠨ㜬") + hex(ord(l1l111ll1ll_l1_)).replace(l11lll_l1_ (u"࠭ࡸࠨ㜭"),l11lll_l1_ (u"ࠧࠨ㜮"))
		#l1l111l1lll_l1_ = l1l111l1lll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㜯"))
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ㜰"),l11lll_l1_ (u"ࠪࠫ㜱"),l11lll_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㜲"),l1l111l1lll_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l111lll1l_l1_(new)
		#l1l11l1111l_l1_ = new.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㜳"))
		#new = new.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㜴")) #.decode(l11lll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㜵"))
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ㜶"),l11lll_l1_ (u"ࠩࠪ㜷"),l11lll_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㜸"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㜹")))   )
		#l1l11l1111l_l1_ = l1l111lll1l_l1_(new)
		#l1l11l1111l_l1_ = l1l111lll1l_l1_(l1l11l1111l_l1_)
		#method=l11lll_l1_ (u"ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨ㜺")
		#params=l11lll_l1_ (u"࠭ࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠧࡶࠦ࠱ࠦࠢࡥࡱࡱࡩࠧࡀࡦࡢ࡮ࡶࡩࢂ࠭㜻") % l1l11l1111l_l1_
		#l1l111lll11_l1_ = xbmc.executeJSONRPC(l11lll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠥࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠡࠤࠨࡷࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࠣࠩࡸ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ㜼") % (method, params))
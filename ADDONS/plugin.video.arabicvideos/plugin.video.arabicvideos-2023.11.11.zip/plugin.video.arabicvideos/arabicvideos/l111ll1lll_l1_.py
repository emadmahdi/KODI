# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ₾")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡊࡒ࠸ࡡࠪ₿")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ⃀"),l11lll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ⃁"),l11lll_l1_ (u"ࠧหีฯ๎้࠭⃂")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l1111l_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l11111_l1_(url,text)
	elif mode==684: results = l1l11l_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⃃"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ⃄"),l11lll_l1_ (u"ࠪࠫ⃅"),l11lll_l1_ (u"ࠫࠬ⃆"),l11lll_l1_ (u"ࠬ࠭⃇"),l11lll_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⃈"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⃉"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⃊"),l11lll_l1_ (u"ࠩࠪ⃋"),689,l11lll_l1_ (u"ࠪࠫ⃌"),l11lll_l1_ (u"ࠫࠬ⃍"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⃎"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⃏"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⃐"),l11lll_l1_ (u"ࠨࠩ⃑"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ⃒ࠩ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ⃓ࠬ")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ⃔"),l11ll1_l1_,681,l11lll_l1_ (u"ࠬ࠭⃕"),l11lll_l1_ (u"࠭ࠧ⃖"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⃗"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃘"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ⃙ࠫ")+l111ll_l1_+l11lll_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆ⃚ࠩ"),l11ll1_l1_,681,l11lll_l1_ (u"ࠫࠬ⃛"),l11lll_l1_ (u"ࠬ࠭⃜"),l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ⃝"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⃞"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⃟")+l111ll_l1_+l11lll_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨ⃠"),l11ll1_l1_,681,l11lll_l1_ (u"ࠪࠫ⃡"),l11lll_l1_ (u"ࠫࠬ⃢"),l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⃣"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⃤"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠ⃥ࠩ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอ⃦ࠬ"),l11ll1_l1_,681,l11lll_l1_ (u"ࠩࠪ⃧"),l11lll_l1_ (u"⃨ࠪࠫ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⃩"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭⃪ࠪ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ⃫࠭"),l11lll_l1_ (u"ࠧࠨ⃬"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ⃭࠭"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ⃮ࠪ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ⃯ࠪ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⃰")+l111ll_l1_+title,link,684)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⃱"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⃲"),l11lll_l1_ (u"ࠧࠨ⃳"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ⃴"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ⃵"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠪࠫ⃶"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ⃷"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⃸"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⃹")+l111ll_l1_+title,link,684)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⃺"),url,l11lll_l1_ (u"ࠨࠩ⃻"),l11lll_l1_ (u"ࠩࠪ⃼"),l11lll_l1_ (u"ࠪࠫ⃽"),l11lll_l1_ (u"ࠫࠬ⃾"),l11lll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⃿"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ℀"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ℁"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧℂ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭℃"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫ℄"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ℅"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ℆"),l11lll_l1_ (u"࠭ࠧℇ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ℈"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫ℉")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩℊ"),l111ll_l1_+title,link,681)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧℋ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ℌ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪℍ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ℎ"),l11lll_l1_ (u"ࠧࠨℏ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨℐ"),l111ll_l1_+title,link,681)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪℑ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫℒ"),l11lll_l1_ (u"ࠫࠬℓ"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ℔"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨℕ"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭№")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ℗"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ℘")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨℙ"),url,data,headers,l11lll_l1_ (u"ࠫࠬℚ"),l11lll_l1_ (u"ࠬ࠭ℛ"),l11lll_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫℜ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫℝ"),url,l11lll_l1_ (u"ࠨࠩ℞"),l11lll_l1_ (u"ࠩࠪ℟"),l11lll_l1_ (u"ࠪࠫ℠"),l11lll_l1_ (u"ࠫࠬ℡"),l11lll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ™"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧ℣"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫℤ"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭℥"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫΩ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫ℧"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ℨ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭℩"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬK"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧÅ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬℬ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩℭ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ℮"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ℯ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧℰ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧℱ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨℲ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩℳ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩℴ"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨℵ"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪℶ"),l11lll_l1_ (u"้ࠬไ๋สࠪℷ"),l11lll_l1_ (u"࠭วฺๆส๊ࠬℸ"),l11lll_l1_ (u"่ࠧัสๅࠬℹ"),l11lll_l1_ (u"ࠨ็หหึอษࠨ℺"),l11lll_l1_ (u"ࠩ฼ี฻࠭℻"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪℼ"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪℽ"),l11lll_l1_ (u"๋ࠬำาฯํอࠬℾ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨℿ"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⅀") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ⅁")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ⅂"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⅃") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭⅄")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧⅅ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨⅆ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪⅇ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⅈ"),l111ll_l1_+title,link,682,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨⅉ"):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⅊"),l111ll_l1_+title,link,682,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ⅋") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⅌"),l111ll_l1_+title,link,683,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ⅍") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⅎ"),l111ll_l1_+title,link,681,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⅏"),l111ll_l1_+title,link,683,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⅐"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ⅑")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⅒"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⅓"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨ⅔"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ⅕")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ⅖"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⅗"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ⅘")+title,link,681)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⅙"),l11lll_l1_ (u"ࠬ࠭⅚"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⅛"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⅜"),url,l11lll_l1_ (u"ࠨࠩ⅝"),l11lll_l1_ (u"ࠩࠪ⅞"),l11lll_l1_ (u"ࠪࠫ⅟"),l11lll_l1_ (u"ࠫࠬⅠ"),l11lll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬⅡ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩⅢ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩⅣ"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩⅤ")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩⅥ"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠪࠧࠬⅦ"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅧ"),l111ll_l1_+title,url,683,l1llll_l1_,l11lll_l1_ (u"ࠬ࠭Ⅸ"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࠫⅩ")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬⅪ"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢⅫ"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⅬ"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬⅭ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭Ⅾ"))
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪⅯ"),l11lll_l1_ (u"࠭ࠠࠨⅰ"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ⅱ"),l111ll_l1_+title,link,682,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩⅲ"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧⅳ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬⅴ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ⅵ"))
		#		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⅶ"),l111ll_l1_+title,link,682,l1llll_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = []
	# l11ll1l1l_l1_ links
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪⅷ"),url,l11lll_l1_ (u"ࠧࠨⅸ"),l11lll_l1_ (u"ࠨࠩⅹ"),l11lll_l1_ (u"ࠩࠪⅺ"),l11lll_l1_ (u"ࠪࠫⅻ"),l11lll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧⅼ"))
	html = response.content
	post = re.findall(l11lll_l1_ (u"ࠬࠨࡩࡴࡈࡲࡶࡲ࡙ࡥࡳࡸࡶࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⅽ"),html,re.DOTALL)
	if not post: post = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡮ࡤࡽ࠲ࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡱࡱࡶࡸࡂ࠮࠮ࠫࡁࠬࠦࠬⅾ"),html,re.DOTALL)
	post = base64.b64decode(post[0])
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬⅿ"))
	post = EVAL(l11lll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭ↀ"),post)
	links = post[l11lll_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵࠪↁ")]
	l1l111_l1_ = list(links.keys())
	links = list(links.values())
	l111l1_l1_ = zip(l1l111_l1_,links)
	for title,link in l111l1_l1_:
		link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫↂ")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬↃ")
		l1lllll1_l1_.append(link)
	# download links
	if l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࡲ࡫ࡴࠬↄ") in html:
		url = url.replace(l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩↅ"),l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱ࡴ࡭ࡶࠧↆ"))
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬↇ"),url,l11lll_l1_ (u"ࠩࠪↈ"),l11lll_l1_ (u"ࠪࠫ↉"),l11lll_l1_ (u"ࠫࠬ↊"),l11lll_l1_ (u"ࠬ࠭↋"),l11lll_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ↌"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡦࡲࡻࡳࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ↍"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			links = re.findall(l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ↎"),block,re.DOTALL)
			for link,title in links:
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ↏")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ←")
				l1lllll1_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ↑"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ→"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ↓"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ↔"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ↕"),l11lll_l1_ (u"ࠩ࠮ࠫ↖"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ↗")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ↘"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ↙")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ↚"))
	return
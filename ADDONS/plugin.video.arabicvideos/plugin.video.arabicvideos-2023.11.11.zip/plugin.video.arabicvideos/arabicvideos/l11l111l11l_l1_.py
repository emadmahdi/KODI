# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ斁")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ斂")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l11lllll11_l1_ = l1ll11l_l1_[script_name][1]
l1l11lll1ll_l1_ = l1ll11l_l1_[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1111l_l1_(url)
	elif mode==52: results = l1llllll_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1lll11ll1lll_l1_()
	elif mode==56: results = l1lll11ll1l11_l1_()
	elif mode==57: results = l1lll1l11ll_l1_(url,1)
	elif mode==58: results = l1lll1l11ll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ斃"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ斄"),l11lll_l1_ (u"ࠬ࠭斅"),59,l11lll_l1_ (u"࠭ࠧ斆"),l11lll_l1_ (u"ࠧࠨ文"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ斈"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ斉"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ斊"),l11lll_l1_ (u"ࠫࠬ斋"),9999)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ斌"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ斍")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ斎"),l11lll_l1_ (u"ࠨࠩ斏"),56)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斐"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ斑")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊วโๆส้ࠬ斒"),l11lll_l1_ (u"ࠬ࠭斓"),55)
	return l11lll_l1_ (u"࠭ࠧ斔")
def l1lll11ll1lll_l1_():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斕"),l111ll_l1_+l11lll_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ斖"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ斗"),51)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ斘"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ料"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ斚"),51)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭斛"),l111ll_l1_+l11lll_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ斜"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ斝"),51)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斞"),l111ll_l1_+l11lll_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ斟"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ斠"),51)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ斡"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭斢"),l11lll_l1_ (u"ࠧࠨ斣"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ斤"),l111ll_l1_+l11lll_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭斥"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ斦"),57)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ斧"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ斨"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ斩"),57)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斪"),l111ll_l1_+l11lll_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ斫"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ斬"),57)
	return
def l1lll11ll1l11_l1_():
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ断"),l111ll_l1_+l11lll_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ斮"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ斯"),51)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭新"),l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ斱"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ斲"),51)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ斳"),l111ll_l1_+l11lll_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ斴"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ斵"),51)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ斶"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ斷"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ斸"),51)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭方"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ斺"),l11lll_l1_ (u"ࠪࠫ斻"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ於"),l111ll_l1_+l11lll_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ施"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭斾"),57)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ斿"),l111ll_l1_+l11lll_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ旀"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ旁"),57)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ旂"),l111ll_l1_+l11lll_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ旃"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ旄"),57)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ旅"),l11lll_l1_ (u"ࠧࠨ旆"),url,url)
	if l11lll_l1_ (u"ࠨࡁࠪ旇") in url:
		parts = url.split(l11lll_l1_ (u"ࠩࡂࠫ旈"))
		url = parts[0]
		filter = l11lll_l1_ (u"ࠪࡃࠬ旉") + QUOTE(parts[1],l11lll_l1_ (u"ࠫࡂࠬ࠺࠰ࠧࠪ旊"))
	else: filter = l11lll_l1_ (u"ࠬ࠭旋")
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ旌"),l11lll_l1_ (u"ࠧࠨ旍"),filter,l11lll_l1_ (u"ࠨࠩ旎"))
	parts = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ族"))
	sort,l1l11l1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11lll_l1_ (u"ࠪࡽࡴࡶࠧ旐"),l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ旑"),l11lll_l1_ (u"ࠬࡼࡩࡦࡹࡶࠫ旒")]:
		if type==l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ旓"): l1l1111l1_l1_=l11lll_l1_ (u"ࠧโ์็้ࠬ旔")
		elif type==l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ旕"): l1l1111l1_l1_=l11lll_l1_ (u"่ࠩืู้ไࠨ旖")
		#url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ旗") + QUOTE(l1l1111l1_l1_) + l11lll_l1_ (u"ࠫ࠴࠭旘") + l1l11l1_l1_ + l11lll_l1_ (u"ࠬ࠵ࠧ旙") + sort + filter
		url = l11ll1_l1_ + l11lll_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ旚") + QUOTE(l1l1111l1_l1_) + l11lll_l1_ (u"ࠧ࠰ࠩ旛") + l1l11l1_l1_ + l11lll_l1_ (u"ࠨ࠱ࠪ旜") + sort + filter
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ旝"),l11lll_l1_ (u"ࠪࠫ旞"),l11lll_l1_ (u"ࠫࠬ旟"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠬ࠭无"),l11lll_l1_ (u"࠭ࠧ旡"),l11lll_l1_ (u"ࠧࠨ既"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ旣"))
		#items = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿ࠣࡰࡸࡱࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡴࡨࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ旤"),html,re.DOTALL)
		items = re.findall(l11lll_l1_ (u"ࠪࠦࡵ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡶࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡴࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡱࡴࡨࡷࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ日"),html,re.DOTALL)
		l1l11ll1111_l1_=0
		for id,title,l1lll11ll1111_l1_,l1llll_l1_ in items:
			l1l11ll1111_l1_ += 1
			#l1llll_l1_ = l11lllll11_l1_ + l11lll_l1_ (u"ࠫ࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ旦") + l1llll_l1_ + l11lll_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ旧")
			l1llll_l1_ = l1l11lll1ll_l1_ + l11lll_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ旨") + l1llll_l1_ + l11lll_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ早")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ旪") + id
			if type==l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ旫"): addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ旬"),l111ll_l1_+title,link,53,l1llll_l1_)
			if type==l11lll_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ旭"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ旮"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ࠥ࠭旯")+title,link+l11lll_l1_ (u"ࠧࡀࡧࡳࡁࠬ旰")+l1lll11ll1111_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ旱")+title+l11lll_l1_ (u"ࠩࡀࠫ旲")+l1llll_l1_,52,l1llll_l1_)
	else:
		if type==l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ旳"): l1l1111l1_l1_=l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ旴")
		elif type==l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ旵"): l1l1111l1_l1_=l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭时")
		url = l11lllll11_l1_ + l11lll_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ旷") + sort + l11lll_l1_ (u"ࠨ࠯ࠪ旸") + l1l1111l1_l1_ + l11lll_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ旹")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫ旺"),l11lll_l1_ (u"ࠫࠬ旻"),l11lll_l1_ (u"ࠬ࠭旼"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ旽"))
		items = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ旾"),html,re.DOTALL)
		l1l11ll1111_l1_=0
		for id,l1lll11ll1111_l1_,l1llll_l1_,title in items:
			l1l11ll1111_l1_ += 1
			l1llll_l1_ = l11lllll11_l1_ + l11lll_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ旿") + l1llll_l1_ + l11lll_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ昀")
			link = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭昁") + id
			if type==l11lll_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ昂"): addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ昃"),l111ll_l1_+title,link,53,l1llll_l1_)
			elif type==l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭昄"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ昅"),l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊ࠠࠨ昆")+title,link+l11lll_l1_ (u"ࠩࡂࡩࡵࡃࠧ昇")+l1lll11ll1111_l1_+l11lll_l1_ (u"ࠪࡁࠬ昈")+title+l11lll_l1_ (u"ࠫࡂ࠭昉")+l1llll_l1_,52,l1llll_l1_)
	title=l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ昊")
	if l1l11ll1111_l1_==16:
		for l1l11llll11_l1_ in range(1,13) :
			if not l1l11l1_l1_==str(l1l11llll11_l1_):
				#url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠭ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪ昋")+type+l11lll_l1_ (u"ࠧ࠰ࠩ昌")+str(l1l11llll11_l1_)+l11lll_l1_ (u"ࠨ࠱ࠪ昍")+sort + filter
				url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ明")+type+l11lll_l1_ (u"ࠪ࠳ࠬ昏")+str(l1l11llll11_l1_)+l11lll_l1_ (u"ࠫ࠴࠭昐")+sort + filter
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ昑"),l111ll_l1_+title+str(l1l11llll11_l1_),url,51)
	return
def l1llllll_l1_(url):
	parts = url.split(l11lll_l1_ (u"࠭࠽ࠨ昒"))
	l1lll11ll1111_l1_ = int(parts[1])
	name = l111l_l1_(parts[2])
	name = name.replace(l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ易"),l11lll_l1_ (u"ࠨࠩ昔"))
	l1llll_l1_ = parts[3]
	url = url.split(l11lll_l1_ (u"ࠩࡂࠫ昕"))[0]
	if l1lll11ll1111_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠪࠫ昖"),l11lll_l1_ (u"ࠫࠬ昗"),l11lll_l1_ (u"ࠬ࠭昘"),l11lll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ昙"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨ昚"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ昛"),block,re.DOTALL)
		l1lll11ll1111_l1_ = int(items[-1])
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ昜"),l11lll_l1_ (u"ࠪࠫ昝"),l1lll11ll1111_l1_,l11lll_l1_ (u"ࠫࠬ昞"))
	#name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕ࡫ࡷࡰࡪࠨ星") )
	#l1llll_l1_ = xbmc.getInfoLabel( l11lll_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠢ映") )
	for l1lll11_l1_ in range(l1lll11ll1111_l1_,0,-1):
		link = url + l11lll_l1_ (u"ࠧࡀࡧࡳࡁࠬ昡") + str(l1lll11_l1_)
		title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭昢")+name+l11lll_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭昣")+str(l1lll11_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ昤"),l111ll_l1_+title,link,53,l1llll_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ春"),l11lll_l1_ (u"ࠬ࠭昦"),l11lll_l1_ (u"࠭ࠧ昧"),l11lll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ昨"))
	l1lll11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ昩"),html,re.DOTALL)
	if l1lll11ll11ll_l1_:
		time = l1lll11ll11ll_l1_[1].replace(l11lll_l1_ (u"ࠩࡗࠫ昪"),l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ昫"))
		DIALOG_OK(l11lll_l1_ (u"ࠫࠬ昬"),l11lll_l1_ (u"ࠬ࠭昭"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ昮"),l11lll_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ是")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ昰")+time)
		return
	#if l11lll_l1_ (u"้ࠩ฽ฯึัࠡ฻็ํࠥ๎โ้฻ࠣา฼ษࠧ昱") in html:
	#	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ昲"),l11lll_l1_ (u"ࠫࠬ昳"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ昴"),l11lll_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ昵"))
	#	return
	l1lll11l1lll1_l1_,l1lll11ll1l1l_l1_ = [],[]
	l1lll11ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡷࡣࡵࠤࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ昶"),html,re.DOTALL)[0]
	l1lll11ll11l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡸࡤࡶࠥࡨࡡࡤ࡭ࡸࡴࡤࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭昷"),html,re.DOTALL)[0]
	# l1llll1l1_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡰࡸࡀࠠࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭昸"),html,re.DOTALL)
	for server,link in links:
		if l11lll_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ昹") in server:
			server = l11lll_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ昺")
			url = l1lll11ll11l1_l1_ + link
		else:
			server = l11lll_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ昻")
			url = l1lll11ll1ll1_l1_ + link
		if l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ昼") in url:
			l1lll11l1lll1_l1_.append(url)
			l1lll11ll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥࠦࠧ昽")+server)
		l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡ࠰࡞࠿ࡀࠫ࠲࠷ࠧ࠻ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠯ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡰ࠷ࡺ࠾ࠠࠡࠩ࠮ࡷࡪࡸࡶࡦࡴࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡱ࡫࡮ࠩࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭࠮ࡀࠊࠊࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡺࡸ࡬࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞࡭ࡢ࠯ࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࠪ࠭ࡠ࠶࡝ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࡭ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࡧ࡫࡯ࡩࡹࡿࡰࡦ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠠࠡࠩ࠯ࠫࠥࠦࠧࠪࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥ࡮ࡢ࡯ࡨ࠲ࡦࡶࡰࡦࡰࡧࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠱ࠧࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠯ࠬࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠧࠨࠢ显")
	# l1111lll_l1_ links
	links = re.findall(l11lll_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ昿"),html,re.DOTALL)
	links += re.findall(l11lll_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ晀"),html,re.DOTALL)
	for server,link in links:
		filename = link.split(l11lll_l1_ (u"ࠫ࠴࠭晁"))[-1]
		filename = filename.replace(l11lll_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ時"),l11lll_l1_ (u"࠭ࠧ晃"))
		filename = filename.replace(l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ晄"),l11lll_l1_ (u"ࠨࠩ晅"))
		filename = filename.replace(l11lll_l1_ (u"ࠩ࠰ࠫ晆"),l11lll_l1_ (u"ࠪࠫ晇"))
		if l11lll_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ晈") in server:
			server = l11lll_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ晉")
			url = l1lll11ll11l1_l1_ + link
		else:
			server = l11lll_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ晊")
			url = l1lll11ll1ll1_l1_ + link
		l1lll11l1lll1_l1_.append(url)
		l1lll11ll1l1l_l1_.append(l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭晋")+server+l11lll_l1_ (u"ࠨࠢࠣࠫ晌")+filename)
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ晍"), l1lll11ll1l1l_l1_)
	if l1l_l1_ == -1 : return
	url = l1lll11l1lll1_l1_[l1l_l1_]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ晎"))
	return
def l1lll1l11ll_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ晏"),l11lll_l1_ (u"ࠬ࠭晐"),url,url)
	if l11lll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭晑") in url: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ๆี็ื้࠭晒")
	else: l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ใํ่๊࠭晓")
	l11l11l_l1_ = QUOTE(l11l11l_l1_)
	html = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ晔"),l11lll_l1_ (u"ࠪࠫ晕"),l11lll_l1_ (u"ࠫࠬ晖"),l11lll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡇࡋࡏࡘࡊࡘࡓ࠮࠳ࡶࡸࠬ晗"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ晘"),l11lll_l1_ (u"ࠧࠨ晙"),url,html)
	if type==1: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ晚"),html,re.DOTALL)
	elif type==2: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ晛"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ晜"),block,re.DOTALL)
	if type==1:
		for l1lll11l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ晝"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ晞")+l1lll11l1llll_l1_,58)
	elif type==2:
		url,l1lll11l1llll_l1_ = url.split(l11lll_l1_ (u"࠭࠿ࠨ晟"))
		for l1ll1111l11l_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ晠"),l111ll_l1_+title,url+l11lll_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ晡")+l1ll1111l11l_l1_+l11lll_l1_ (u"ࠩࠩࠫ晢")+l1lll11l1llll_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ晣"),l11lll_l1_ (u"ࠫࠬ晤"),search,search)
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ晥"),l11lll_l1_ (u"࠭ࠥ࠳࠲ࠪ晦"))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ晧"), l11ll1_l1_, l11lll_l1_ (u"ࠨࠩ晨"), l11lll_l1_ (u"ࠩࠪ晩"), True,l11lll_l1_ (u"ࠪࠫ晪"),l11lll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ晫"))
	#html = response.content
	#cookies = response.cookies
	#l11ll11l1_l1_ = cookies[l11lll_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳ࠭晬")]
	#l1lll11ll111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡣࡴࡴࡩࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭晭"),html,re.DOTALL)
	#l1lll11ll111l_l1_ = l1lll11ll111l_l1_[0]
	#payload = l11lll_l1_ (u"ࠧࡠࡥࡶࡶ࡫ࡃࠧ普") + l1lll11ll111l_l1_ + l11lll_l1_ (u"ࠨࠨࡴࡁࠬ景") + QUOTE(l111l1l_l1_)
	#headers = { l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ晰"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ晱") , l11lll_l1_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ晲"):l11lll_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ晳")+l11ll11l1_l1_ }
	#url = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠯ࡴࡧࡤࡶࡨ࡮ࠢ晴")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ晵"), url, payload, headers, True,l11lll_l1_ (u"ࠨࠩ晶"),l11lll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ晷"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ晸")+l111l1l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ晹"),url,l11lll_l1_ (u"ࠬ࠭智"),l11lll_l1_ (u"࠭ࠧ晻"),True,l11lll_l1_ (u"ࠧࠨ晼"),l11lll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧ晽"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡪࡩࡳ࡫ࡲࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡹࡥࡢࡴࡦ࡬࠲ࡨ࡯ࡵࡶࡲࡱ࠲ࡶࡡࡥࡦ࡬ࡲ࡬࠭晾"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ晿"),block,re.DOTALL)
	if items:
		for link,l1llll_l1_,title in items:
			#title = title.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ暀")).encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ暁"))
			url = l11ll1_l1_ + link
			if l11lll_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ暂") in url:
				if l11lll_l1_ (u"ࠧࡀࡧࡳࡁࠬ暃") in url:
					title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭暄")+title
					url = url.replace(l11lll_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ暅"),l11lll_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ暆"))
					url = url+l11lll_l1_ (u"ࠫࡂ࠭暇")+QUOTE(title)+l11lll_l1_ (u"ࠬࡃࠧ暈")+l1llll_l1_
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭暉"),l111ll_l1_+title,url,52,l1llll_l1_)
				else:
					title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ暊")+title
					addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ暋"),l111ll_l1_+title,url,53,l1llll_l1_)
	#else: DIALOG_OK(l11lll_l1_ (u"ࠩࠪ暌"),l11lll_l1_ (u"ࠪࠫ暍"),l11lll_l1_ (u"ࠫࡳࡵࠠࡳࡧࡶࡹࡱࡺࡳࠨ暎"),l11lll_l1_ (u"๊ࠬวࠡฬ๋ะิࠦๆหษษะ๊ࠥไษฯฮࠫ暏"))
	return
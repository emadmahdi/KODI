# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ朷")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ朸")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧษอ้ࠣออิาࠩ朹")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l1111l_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llllll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ机"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ朻"),l11lll_l1_ (u"ࠪࠫ朼"),l11lll_l1_ (u"ࠫࠬ朽"),l11lll_l1_ (u"ࠬ࠭朾"),l11lll_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ朿"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杀"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ杁"),l11lll_l1_ (u"ࠩࠪ杂"),469,l11lll_l1_ (u"ࠪࠫ权"),l11lll_l1_ (u"ࠫࠬ杄"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ杅"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭杆"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ杇")+l111ll_l1_+l11lll_l1_ (u"ࠨลัีࠥอไฮๆๅหฯ࠭杈"),l11ll1_l1_,461,l11lll_l1_ (u"ࠩࠪ杉"),l11lll_l1_ (u"ࠪࠫ杊"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ杋"))
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ杌"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭杍"),l11lll_l1_ (u"ࠧࠨ李"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡣࡶࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ杏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ材"),block,re.DOTALL)
		for link,title in items:
			#if link==l11lll_l1_ (u"ࠪࠧࠬ村"): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ杒") not in link: link = l11ll1_l1_+link
			if title==l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ杓"): title = l11lll_l1_ (u"࠭ฬะ์าࠤา๊โศฬࠣฮ๏็๊ࠡใส๊ࠬ杔")
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杕"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ杖")+l111ll_l1_+title,link,461)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡊࡴࡵࡴࡦࡴࡆࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ杗"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ杘"),block,re.DOTALL)
	#	for link,title in items:
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ杙"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ杚")+l111ll_l1_+title,link,461)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"࠭ࠧ杛")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ杜"),l11lll_l1_ (u"ࠨࠩ杝"),l1111l111_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭杞"),url,l11lll_l1_ (u"ࠪࠫ束"),l11lll_l1_ (u"ࠫࠬ杠"),l11lll_l1_ (u"ࠬ࠭条"),l11lll_l1_ (u"࠭ࠧ杢"),l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ杣"))
	html = response.content
	#if l1111l111_l1_==l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ杤"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩฦาึࠦวๅฯ็ๆฬะࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠣࠩ来"),html,re.DOTALL)
	#else:
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ杦"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ杧"),block,re.DOTALL)
		l1l1_l1_ = []
		l1lll1_l1_ = [l11lll_l1_ (u"๋ࠬิศ้าอࠬ杨"),l11lll_l1_ (u"࠭แ๋ๆ่ࠫ杩"),l11lll_l1_ (u"ࠧศ฼้๎ฮ࠭杪"),l11lll_l1_ (u"ࠨๅ็๎อ࠭杫"),l11lll_l1_ (u"ࠩส฽้อๆࠨ杬"),l11lll_l1_ (u"๋ࠪิอแࠨ杭"),l11lll_l1_ (u"๊ࠫฮวาษฬࠫ杮"),l11lll_l1_ (u"ࠬ฿ัืࠩ杯"),l11lll_l1_ (u"࠭ๅ่ำฯห๋࠭杰"),l11lll_l1_ (u"ࠧศๆห์๊࠭東")]
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭杲") not in link: link = l11ll1_l1_+link
			link = l111l_l1_(link)	#.strip(l11lll_l1_ (u"ࠩ࠲ࠫ杳"))
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭杴"),title,re.DOTALL)
			if any(value in title for value in l1lll1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ杵"),l111ll_l1_+title,link,462,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠬอไฮๆๅอࠬ杶") in title:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ杷") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ杸"),l111ll_l1_+title,link,463,l1llll_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ杹"),l111ll_l1_+title,link,463,l1llll_l1_)
	if l1111l111_l1_!=l11lll_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ杺"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ杻"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ杼"),block,re.DOTALL)
			for link,title in items:
				link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ杽"))
				if link==l11lll_l1_ (u"ࠨࠢ松"): continue
				if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ板") not in link: link = l11ll1_l1_+link
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠨࠩ枀"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ极"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ枂")+title,link,461)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ枃"),l11lll_l1_ (u"ࠬ࠭构"),l11lll_l1_ (u"࠭ࡅࡑࡋࡖࡓࡉࡋࡓࠨ枅"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ枆"),url,l11lll_l1_ (u"ࠨࠩ枇"),l11lll_l1_ (u"ࠩࠪ枈"),l11lll_l1_ (u"ࠪࠫ枉"),l11lll_l1_ (u"ࠫࠬ枊"),l11lll_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ枋"))
	html = response.content
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧ࠱ࡹ࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭枌"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ枍"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭枎") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ枏"),l111ll_l1_+title,link,462,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ析"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭枑"),block,re.DOTALL)
		for link,title in items:
			link = link.strip(l11lll_l1_ (u"ࠬࠦࠧ枒"))
			if link==l11lll_l1_ (u"ࠨࠢ枓"): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ枔") not in link: link = l11ll1_l1_+link
			#title = unescapeHTML(title)
			if title!=l11lll_l1_ (u"ࠨࠩ枕"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ枖"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ林")+title,link,463)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ枘"),url,l11lll_l1_ (u"ࠬ࠭枙"),l11lll_l1_ (u"࠭ࠧ枚"),l11lll_l1_ (u"ࠧࠨ枛"),l11lll_l1_ (u"ࠨࠩ果"),l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ枝"))
	html = response.content
	# l1l11llll_l1_ link
	l1111l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡘࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ枞"),html,re.DOTALL)
	if l1111l111l_l1_:
		l1111l111l_l1_ = l1111l111l_l1_[0]
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ枟") not in l1111l111l_l1_:
			if l11lll_l1_ (u"ࠬ࠵࠯ࠨ枠") in l1111l111l_l1_: l1111l111l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ枡")+l1111l111l_l1_
			else: l1111l111l_l1_ = l11ll1_l1_+l1111l111l_l1_
		l1111l111l_l1_ = l1111l111l_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ枢")
		l1111_l1_.append(l1111l111l_l1_)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡤ࠴࠹࠿ࡨࡥࡧࡱࡵࡩ࠭࠴ࠪࡀࠫࡶࡱࡦࡲ࡬࠯ࠬࡂ࡛ࠦ࡯ࡤࡦࡱࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪࠤࡓࡰࡦࡿࠢࠨ枣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lll11l1l111_l1_,l1lll11l1l11l_l1_ = l1l1ll1_l1_[0]
		names = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ枤"),l1lll11l1l111_l1_,re.DOTALL)
		links = re.findall(l11lll_l1_ (u"ࠥࡷࡪࡺࡖࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤ枥"),l1lll11l1l11l_l1_,re.DOTALL)
		l1lll11l11lll_l1_ = zip(names,links)
		for name,l11111l111l1_l1_ in l1lll11l11lll_l1_:
			l11111l111l1_l1_ = l11111l111l1_l1_[2:]
			if kodi_version<19: l11111l111l1_l1_ = l11111l111l1_l1_.decode(l11lll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ枦"))
			l11111l111l1_l1_ = base64.b64decode(l11111l111l1_l1_)
			if kodi_version>18.99: l11111l111l1_l1_ = l11111l111l1_l1_.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ枧"))
			link = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ枨"),l11111l111l1_l1_,re.DOTALL)
			link = link[0]
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ枩") not in link:
				if l11lll_l1_ (u"ࠨ࠱࠲ࠫ枪") in link: link = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ枫")+link
				else: link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ枬")+name+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ枭")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ枮"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ枯"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11lll_l1_ (u"ࠧࠡࠩ枰") in search:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠨࠩ枱"),l11lll_l1_ (u"ࠩࠪ枲"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ่ࠢ์็฿ࠠห์ไ๎ࠥ็ว็ࠩ枳"),l11lll_l1_ (u"้๊ࠫริใࠣห้ฮอฬࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ็หࠥ๐ูๆๆࠣ฽๋ีุࠠๆหࠤศ้หา่๊้ࠢࠥไๆหࠣ์ฬำฯสࠢ࠱࠲࠳๊ࠦาฮ์ࠤฬ๊ศฮอࠣ฽๋ࠦใๅ็ฬࠤํออะหࠣๅ็฽ࠧ枴"))
		return
	#search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ枵"),l11lll_l1_ (u"࠭࠭ࠨ架"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ枷")+search
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡴ࠳ࠬ枸")+search+l11lll_l1_ (u"ࠩ࠲ࠫ枹")
	l1111l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨ▴")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡇࡅ࠷ࡤ࠭▵")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1llll11l1l_l1_.l1lll1l1lll_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l1lll1ll11l_l1_
# l1lll1ll111_l1_	https://t.me/l1lll1l1l11_l1_
# l1lll1l11l1_l1_	https://l1llll1l111_l1_.com/l1lll1l1l11_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ฺ้อัฺหࠣห้ำัสࠩ▶"),l11lll_l1_ (u"ࠩส๎ั๐ࠠษีอࠫ▷"),l11lll_l1_ (u"ࠪห้ะีๆ์่ࠤฬ๊ฬะ์าࠫ▸"),l11lll_l1_ (u"ࠫ฾ื่ืࠢส่๊฻วา฻ฬࠫ▹"),l11lll_l1_ (u"๋ࠬใหสอ๎ࠬ►"),l11lll_l1_ (u"࠭ว๋ฮํࠤอูสࠡษ็ะิ๐ฯࠨ▻"),l11lll_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠢส่อี๊ๅࠩ▼"),l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ▽"),l11lll_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮำหࠩ▾"),l11lll_l1_ (u"้ࠪํู่่ࠡอๅ้๐ใิࠩ▿")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==790: results = MENU()
	elif mode==791: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==792: results = l1l11l_l1_(url)
	elif mode==793: results = PLAY(url)
	elif mode==796: results = l1lll1l1l1_l1_(url,l1l11l1_l1_)
	elif mode==799: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◀"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ◁"),l11lll_l1_ (u"࠭ࠧ◂"),799,l11lll_l1_ (u"ࠧࠨ◃"),l11lll_l1_ (u"ࠨࠩ◄"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭◅"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ◆"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ◇"),l11lll_l1_ (u"ࠬ࠭◈"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ◉"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ◊"),l11lll_l1_ (u"ࠨࠩ○"),l11lll_l1_ (u"ࠩࠪ◌"),l11lll_l1_ (u"ࠪࠫ◍"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ◎"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡲࡩࡴࡶ࠰ࡴࡦ࡭ࡥࡴࠪ࠱࠮ࡄ࠯ࡦࡢ࠯ࡩࡳࡱࡪࡥࡳࠩ●"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ◐"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ◑"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭◒") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ◓"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ◔")+l111ll_l1_+title,link,791)
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ◕"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ◖"),l11lll_l1_ (u"࠭ࠧ◗"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡧࡲࡵ࡫ࡦࡰࡪ࠮࠮ࠫࡁࠬࡷࡴࡩࡩࡢ࡮࠰ࡦࡴࡾࠧ◘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ◙"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ◚"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ◛") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◜"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ◝")+l111ll_l1_+title,link,791,l11lll_l1_ (u"࠭ࠧ◞"),l11lll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠩ◟"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭◠"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ◡"),l11lll_l1_ (u"ࠪࠫ◢"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ◣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ◤"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ◥"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ◦") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◧"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ◨")+l111ll_l1_+title,link,791)
	return html
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠪࠫ◩")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ◪"),l11lll_l1_ (u"ࠬ࠭◫"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ◬"),url,l11lll_l1_ (u"ࠧࠨ◭"),l11lll_l1_ (u"ࠨࠩ◮"),l11lll_l1_ (u"ࠩࠪ◯"),l11lll_l1_ (u"ࠪࠫ◰"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭◱"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯ࡡࡳࡶ࡬ࡧࡱ࡫ࠧ◲"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"࠭ࠧ◳"),l11lll_l1_ (u"ࠧࠨ◴"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠨฯ็ๆฬะࠧ◵") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"่ࠩ์ฬูๅࠨ◶") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ◷"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◸"),l111ll_l1_+title,link,796,l1llll_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ◹"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ◺"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭◻"),l111ll_l1_+title,link,793,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ◼"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ◽"),l111ll_l1_+title,link,793)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠪࠫ◾")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ◿"),l11lll_l1_ (u"ࠬ࠭☀"),l11lll_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘ࠭☁"),url)
	limit,start,l11lllll1_l1_,select,l1lll1l1ll1_l1_ = 0,0,l11lll_l1_ (u"ࠧࠨ☂"),l11lll_l1_ (u"ࠨࠩ☃"),l11lll_l1_ (u"ࠩࠪ☄")
	if l11lll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ★") in type:
		# next l1l11l1_l1_
		l1lll1ll1l1_l1_,data = l1llll11ll_l1_(url)
		limit = int(data[l11lll_l1_ (u"ࠫࡱ࡯࡭ࡪࡶࠪ☆")])
		start = int(data[l11lll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ☇")])
		l11lllll1_l1_ = data[l11lll_l1_ (u"࠭ࡴࡺࡲࡨࠫ☈")]
		select = data[l11lll_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺࠧ☉")]
		l11llll11_l1_ = l11lll_l1_ (u"ࠨ࡮࡬ࡱ࡮ࡺ࠽ࠨ☊")+str(limit)+l11lll_l1_ (u"ࠩࠩࡷࡹࡧࡲࡵ࠿ࠪ☋")+str(start)+l11lll_l1_ (u"ࠪࠪࡹࡿࡰࡦ࠿ࠪ☌")+l11lllll1_l1_+l11lll_l1_ (u"ࠫࠫࡹࡥ࡭ࡧࡦࡸࡂ࠭☍")+select
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ☎"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ☏")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ☐"),l1lll1ll1l1_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ☑"),l11lll_l1_ (u"ࠩࠪ☒"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ☓"))
		html = response.content
		l11lll1l_l1_ = l11lll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡶࠫ☔")+html+l11lll_l1_ (u"ࠬࡧࡲࡵ࡫ࡦࡰࡪ࠭☕")
	else:
		# l11ll11l1l_l1_ html
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ☖"),url,l11lll_l1_ (u"ࠧࠨ☗"),l11lll_l1_ (u"ࠨࠩ☘"),l11lll_l1_ (u"ࠩࠪ☙"),l11lll_l1_ (u"ࠪࠫ☚"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ☛"))
		html = response.content
		l11lll1l_l1_ = html
		code = re.findall(l11lll_l1_ (u"ࠧࡂࡳࡤࡴ࡬ࡴࡹࡄࠨࡷࡣࡵ࠲࠯ࡅ࠽࠯ࠬࡂ࠿ࡻࡧࡲ࠯ࠬࡂࡁ࠳࠰࠿࠼ࡸࡤࡶ࠳࠰࠿࠾࠰࠭ࡃࡀࡼࡡࡳ࠰࠭ࡃࡂ࠴ࠪࡀ࠽ࡹࡥࡷ࠴ࠪࡀ࠿࠱࠮ࡄ࠯࠻࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠥ☜"),html,re.DOTALL)
		if code:
			code = code[0].replace(l11lll_l1_ (u"࠭ࡶࡢࡴࠪ☝"),l11lll_l1_ (u"ࠧࠨ☞")).replace(l11lll_l1_ (u"ࠨࠢࠪ☟"),l11lll_l1_ (u"ࠩࠪ☠")).replace(l11lll_l1_ (u"ࠥࠫࠧ☡"),l11lll_l1_ (u"ࠫࠬ☢")).replace(l11lll_l1_ (u"ࠬࡁࠧ☣"),l11lll_l1_ (u"࠭ࠦࠨ☤"))
			dummy,data = l1llll11ll_l1_(l11lll_l1_ (u"ࠧࡀࠩ☥")+code)
			limit = int(data[l11lll_l1_ (u"ࠨ࡮࡬ࡱ࡮ࡺࠧ☦")])
			start = int(data[l11lll_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ☧")])
			l11lllll1_l1_ = data[l11lll_l1_ (u"ࠪࡸࡾࡶࡥࠨ☨")]
			select = data[l11lll_l1_ (u"ࠫࡸ࡫࡬ࡦࡥࡷࠫ☩")]
			l1lll1l1ll1_l1_ = data[l11lll_l1_ (u"ࠬࡧࡪࡢࡺࡸࡶࡱ࠭☪")]
			l11llll11_l1_ = l11lll_l1_ (u"࠭࡬ࡪ࡯࡬ࡸࡂ࠭☫")+str(limit)+l11lll_l1_ (u"ࠧࠧࡵࡷࡥࡷࡺ࠽ࠨ☬")+str(start)+l11lll_l1_ (u"ࠨࠨࡷࡽࡵ࡫࠽ࠨ☭")+l11lllll1_l1_+l11lll_l1_ (u"ࠩࠩࡷࡪࡲࡥࡤࡶࡀࠫ☮")+select
			l1lll1ll1l1_l1_ = l11ll1_l1_+l1lll1l1ll1_l1_
			l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ☯"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ☰")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ☱"),l1lll1ll1l1_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ☲"),l11lll_l1_ (u"ࠧࠨ☳"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧ☴"))
			l11lll1l_l1_ = response.content
			l11lll1l_l1_ = l11lll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡴࠩ☵")+l11lll1l_l1_+l11lll_l1_ (u"ࠪࡥࡷࡺࡩࡤ࡮ࡨࠫ☶")
	items,l1lllll1l1l_l1_,filters = [],False,False
	if not type:
		# l1lllll1l1l_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ☷"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭☸"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ☹"))
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ☺"),l111ll_l1_+title,link,791,l11lll_l1_ (u"ࠨࠩ☻"),l11lll_l1_ (u"ࠩࡶࡹࡧࡳࡥ࡯ࡷࠪ☼"))
				l1lllll1l1l_l1_ = True
	if not type:
		# filter
		filters = l1lll1l11ll_l1_(html)
	if not l1lllll1l1l_l1_ and not filters:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ☽"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ☾"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠬࡢ࡮ࠨ☿"))
				link = l111l_l1_(link)
				if l11lll_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ♀") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ♁"),l111ll_l1_+title,link,791,l1llll_l1_)
				elif l11lll_l1_ (u"ࠨ็ึุ่๊ࠧ♂") in link and l11lll_l1_ (u"ࠩะ่็ฯࠧ♃") not in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ♄"),l111ll_l1_+title,link,796,l1llll_l1_)
				elif l11lll_l1_ (u"๊ࠫ๎ำๆࠩ♅") in link and l11lll_l1_ (u"ࠬำไใหࠪ♆") not in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♇"),l111ll_l1_+title,link,796,l1llll_l1_)
				else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭♈"),l111ll_l1_+title,link,793,l1llll_l1_)
		# l1lll1lll1_l1_
		length = 12
		data = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠪ࡯ࡳࡦࡪ࠭࡮ࡱࡵࡩ࠳࠰࠿ࠪ࠾ࠪ♉"),html,re.DOTALL)
		if len(items)==length and (data or l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭♊") in type):
			l11llll11_l1_ = l11lll_l1_ (u"ࠪࡰ࡮ࡳࡩࡵ࠿ࠪ♋")+str(length)+l11lll_l1_ (u"ࠫࠫࡹࡴࡢࡴࡷࡁࠬ♌")+str(start+length)+l11lll_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁࠬ♍")+l11lllll1_l1_+l11lll_l1_ (u"࠭ࠦࡴࡧ࡯ࡩࡨࡺ࠽ࠨ♎")+select
			l11l11l_l1_ = l1lll1ll1l1_l1_+l11lll_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ♏")+l11llll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♐"),l111ll_l1_+l11lll_l1_ (u"ࠩสุ่๊๊ะࠩ♑"),l11l11l_l1_,791,l11lll_l1_ (u"ࠪࠫ♒"),l11lll_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡠࠩ♓")+type)
	return
def l1lll1l11ll_l1_(html):
	filters = False
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࡣࡵࡸ࡮ࡩ࡬ࡦࠩ♔"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l111l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭♕"),block,re.DOTALL)
		if l111l11_l1_: addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ♖"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ♗"),l11lll_l1_ (u"ࠩࠪ♘"),9999)
		for category,name,block in l111l11_l1_:
			name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ♙"))
			# link & value
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ♚"),block,re.DOTALL)
			for link,value in items:
				title = name+l11lll_l1_ (u"ࠬࡀࠠࠡࠩ♛")+value
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♜"),l111ll_l1_+title,link,791,l11lll_l1_ (u"ࠧࠨ♝"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ♞"))
				filters = True
	return filters
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭♟"),url,l11lll_l1_ (u"ࠪࠫ♠"),l11lll_l1_ (u"ࠫࠬ♡"),l11lll_l1_ (u"ࠬ࠭♢"),l11lll_l1_ (u"࠭ࠧ♣"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ♤"))
	html = response.content
	#l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾࡯ࡥࡧ࡫࡬࠿ษ็ฮฺ์๊โ࠾࠲ࡰࡦࡨࡥ࡭ࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ♥"),html,re.DOTALL)
	#if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l11ll1l1l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠯࡬ࡸࡪࡳ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭♦"),html,re.DOTALL)
	for l1lll1llll1_l1_ in items:
		l1llll1111l_l1_ = base64.b64decode(l1lll1llll1_l1_)
		if kodi_version>18.99: l1llll1111l_l1_ = l1llll1111l_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♧"))
		link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ♨"),l1llll1111l_l1_,re.DOTALL)
		if link:
			link = link[0]
			if link not in l1lll11ll1_l1_:
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ♩"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ♪")+server+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ♫"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬ♬"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠥࡸࡷࠦࡦ࡭ࡧࡻ࠱ࡸࡺࡡࡳࡶࠥ࠲࠯ࡅ࠼ࡥ࡫ࡹࡂࡠࠦࡡ࠮ࡼࡄ࠱࡟ࡣࠪࠩ࡞ࡧࡿ࠸࠲࠴ࡾࠫ࡞ࠤࡦ࠳ࡺࡂ࠯࡝ࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭♭"),block,re.DOTALL)
		for l11l111l_l1_,link in items:
			if link not in l1lll11ll1_l1_:
				if l11lll_l1_ (u"ࠪ࠳ࡄࡻࡲ࡭࠿ࠪ♮") in link: link = link.split(l11lll_l1_ (u"ࠫ࠴ࡅࡵࡳ࡮ࡀࠫ♯"))[1]
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ♰"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ♱")+server+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ♲")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ♳"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ♴"),url)
	return
def SEARCH():
	# needed for l1lll1l1l1l_l1_
	return
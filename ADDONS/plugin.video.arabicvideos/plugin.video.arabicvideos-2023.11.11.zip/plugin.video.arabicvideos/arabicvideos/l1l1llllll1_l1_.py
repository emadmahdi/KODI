# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪⴥ")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡉࡎࡘࡥࠧ⴦")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩส่ฯ฻ๆ๋ใสฮࠬⴧ"),l11lll_l1_ (u"ࠪหฺ๋วยࠢะืฬฮࠧ⴨"),l11lll_l1_ (u"ࠫ฼๊ศศฬࠣหุ้่๒ษิࠫ⴩")]
#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⴪"):l11lll_l1_ (u"࠭ࠧ⴫")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l1111l_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1llllll_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⴬"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨⴭ"),l11lll_l1_ (u"ࠩࠪ⴮"),399,l11lll_l1_ (u"ࠪࠫ⴯"),l11lll_l1_ (u"ࠫࠬⴰ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩⴱ"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴲ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⴳ"),l11lll_l1_ (u"ࠨࠩⴴ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ⴵ"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫⴶ"),l11lll_l1_ (u"ࠫࠬⴷ"),l11lll_l1_ (u"ࠬ࠭ⴸ"),l11lll_l1_ (u"࠭ࠧⴹ"),l11lll_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬⴺ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩⴻ"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴼ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬⴽ")+l111ll_l1_+title,l11ll1_l1_,391,l11lll_l1_ (u"ࠫࠬⴾ"),l11lll_l1_ (u"ࠬ࠭ⴿ"),l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭ⵀ")+str(seq))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵁ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⵂ")+l111ll_l1_+l11lll_l1_ (u"่ࠩาฯอัศฬࠣ฽ู๎วว์ฬࠫⵃ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠪࠫⵄ"),l11lll_l1_ (u"ࠫࠬⵅ"),l11lll_l1_ (u"ࠬࡸࡡ࡯ࡦࡲࡱࡸ࠭ⵆ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵇ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⵈ")+l111ll_l1_+l11lll_l1_ (u"ࠨล฼่๎ࠦวๅลไ่ฬ๋ࠠหไํ๎๊อ๋ࠨⵉ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠩࠪⵊ"),l11lll_l1_ (u"ࠪࠫⵋ"),l11lll_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ⵌ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵍ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⵎ")+l111ll_l1_+l11lll_l1_ (u"ࠧฤ฻็ํࠥอไๆี็ื้อสࠡฬๅ๎๏๋ว์ࠩⵏ"),l11ll1_l1_,391,l11lll_l1_ (u"ࠨࠩⵐ"),l11lll_l1_ (u"ࠩࠪⵑ"),l11lll_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡹࡥࡳ࡫ࡨࡷࠬⵒ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵓ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⵔ")+l111ll_l1_+l11lll_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫⵕ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨⵖ"),391,l11lll_l1_ (u"ࠨࠩⵗ"),l11lll_l1_ (u"ࠩࠪⵘ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬⵙ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵚ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⵛ")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ⵜ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩⵝ"),391,l11lll_l1_ (u"ࠨࠩⵞ"),l11lll_l1_ (u"ࠩࠪⵟ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡺࡶࡴࡪࡲࡻࡸ࠭ⵠ"))
	block = l11lll_l1_ (u"ࠫࠬⵡ")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩ࡯࡯ࡶࡨࡲࡪࡪ࡯ࡳࠤࠪⵢ"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪⵣ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨⵤ"),l11lll_l1_ (u"ࠨࠩⵥ"),l11lll_l1_ (u"ࠩࠪⵦ"),l11lll_l1_ (u"ࠪࠫⵧ"),l11lll_l1_ (u"ࠫࠬ⵨"),l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ⵩"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡮ࡨࡥࡸ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࡡࡴ࡫ࡧࡩࠬ⵪"),html,re.DOTALL)
	if l1l1ll1_l1_: block += l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⵫"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⵬"),l11lll_l1_ (u"ࠩࠪ⵭"),9999)
	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⵮"),block,re.DOTALL)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l11lll_l1_ (u"ࠫฬ๊รฺๆ์ࠤฺ๊ว่ัฬࠫⵯ"):
			if first:
				title = l11lll_l1_ (u"ࠬอไศใ็ห๊ࠦࠧ⵰")+title
				first = False
			else: title = l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢࠪ⵱")+title
		if title not in l1l1l1_l1_:
			if title==l11lll_l1_ (u"ࠧฤใ็ห๊࠭⵲"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵳"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⵴")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ⵵"),391,l11lll_l1_ (u"ࠫࠬ⵶"),l11lll_l1_ (u"ࠬ࠭⵷"),l11lll_l1_ (u"࠭ࡡ࡭࡮ࡢࡱࡴࡼࡩࡦࡵࡢࡸࡻࡹࡨࡰࡹࡶࠫ⵸"))
			elif title==l11lll_l1_ (u"ࠧๆี็ื้อสࠨ⵹"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵺"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⵻")+l111ll_l1_+title,l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷࠬ⵼"),391,l11lll_l1_ (u"ࠫࠬ⵽"),l11lll_l1_ (u"ࠬ࠭⵾"),l11lll_l1_ (u"࠭ࡡ࡭࡮ࡢࡱࡴࡼࡩࡦࡵࡢࡸࡻࡹࡨࡰࡹࡶ⵿ࠫ"))
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶀ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⶁ")+l111ll_l1_+title,link,391)
	return html
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪⶂ"),l11lll_l1_ (u"ࠪࠫⶃ"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨⶄ"),url,l11lll_l1_ (u"ࠬ࠭ⶅ"),l11lll_l1_ (u"࠭ࠧⶆ"),l11lll_l1_ (u"ࠧࠨⶇ"),l11lll_l1_ (u"ࠨࠩⶈ"),l11lll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩⶉ"))
	html = response.content
	if type in [l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬⶊ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡴࡷࡵ࡫ࡳࡼࡹࠧⶋ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡣࡵࡧ࡭࡯ࡶࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫⶌ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧⶍ"),l11lll_l1_ (u"ࠧࠨⶎ"),url,block)
	elif type==l11lll_l1_ (u"ࠨࡣ࡯ࡰࡤࡳ࡯ࡷ࡫ࡨࡷࡤࡺࡶࡴࡪࡲࡻࡸ࠭ⶏ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫⶐ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif type==l11lll_l1_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬⶑ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࡨࡲࡡࡴࡵࡀࠫࡹࡵࡰ࠮࡫ࡰࡨࡧ࠳࡬ࡪࡵࡷࠤࡹࡲࡥࡧࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠧࡵࡱࡳ࠱࡮ࡳࡤࡣ࠯࡯࡭ࡸࡺࠠࡵࡴ࡬࡫࡭ࡺࠢⶒ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ⶓ"),l11lll_l1_ (u"࠭ࠧⶔ"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠢࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥⶕ"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡷࡪࡸࡩࡦࡵࠪⶖ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡷࡳࡵ࠳ࡩ࡮ࡦࡥ࠱ࡱ࡯ࡳࡵࠢࡷࡶ࡮࡭ࡨࡵࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷࠨ⶗"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⶘"),l11lll_l1_ (u"ࠫࠬ⶙"),str(len(block)),type)
			items = re.findall(l11lll_l1_ (u"ࠧ࡯࡭ࡨࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ⶚"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭⶛"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡤࡶࡨ࡮࠭ࡱࡣࡪࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ⶜"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⶝"),block,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ⶞"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠧ⶟"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⶠ"),block,re.DOTALL)
		l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_ = zip(*l111l1_l1_)
		items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	elif type==l11lll_l1_ (u"ࠬࡸࡡ࡯ࡦࡲࡱࡸ࠭ⶡ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࡵ࠰ࡸࡻࡹࡨࡰࡹࡶࠦ࠭࠴ࠪࡀࠫ࠿࡬ࡪࡧࡤࡦࡴࡁࠫⶢ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⶣ"),block,re.DOTALL)
	elif l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨⶤ") in type:
		seq = int(type[-1:])
		html = html.replace(l11lll_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠫⶥ"),l11lll_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡶࡸࡦࡸࡴ࠿ࠩⶦ"))
		html = html.replace(l11lll_l1_ (u"ࠫࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ⶧"),l11lll_l1_ (u"ࠬࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿ࡩࡳࡪ࠾ࠨⶨ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡶࡤࡶࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡮ࡥࡀࠪⶩ"),html,re.DOTALL)
		block = l1l1ll1_l1_[seq]
		if seq==6:
			l111l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨⶪ"),block,re.DOTALL)
			l1l11ll11_l1_,l1lll1ll_l1_,l1111_l1_ = zip(*l111l1_l1_)
			items = zip(l1l11ll11_l1_,l1111_l1_,l1lll1ll_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠩࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࢁࡹࡩࡥࡧࡥࡥࡷ࠯ࠧⶫ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0][0]
			if l11lll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨⶬ") in url:
				items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⶭ"),block,re.DOTALL)
			elif l11lll_l1_ (u"ࠫ࠴ࡷࡵࡢ࡮࡬ࡸࡾ࠵ࠧⶮ") in url:
				items = re.findall(l11lll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⶯"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11lll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨⶰ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠬⶱ") in title: continue
		if l11lll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࠧⶲ") in title:
			title = re.findall(l11lll_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡥࡳ࡫ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⶳ"),title,re.DOTALL)
			title = title[0][1]#+l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧⶴ")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪⶵ")+title
		l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠭ⶶ"),title,re.DOTALL)
		if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
		title = unescapeHTML(title)
		if l11lll_l1_ (u"࠭࠯ࡵࡸࡶ࡬ࡴࡽࡳ࠰ࠩ⶷") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶸ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬⶹ") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶺ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭ⶻ") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶼ"),l111ll_l1_+title,link,393,l1llll_l1_)
		elif l11lll_l1_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫⶽ") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶾ"),l111ll_l1_+title,link,391,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⶿"),l111ll_l1_+title,link,392,l1llll_l1_)
	if type not in [l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪⷀ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹࡼࡳࡩࡱࡺࡷࠬⷁ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ⷂ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⷃ"),block,re.DOTALL)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷄ"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬⷅ")+title,link,391,l11lll_l1_ (u"ࠧࠨⷆ"),l11lll_l1_ (u"ࠨࠩ⷇"),type)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪⷈ"),l11lll_l1_ (u"ࠪࠫⷉ"),l11lll_l1_ (u"ࠫࠬⷊ"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩⷋ"))
	url = url.replace(server,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪⷌ"),url,l11lll_l1_ (u"ࠧࠨⷍ"),l11lll_l1_ (u"ࠨࠩⷎ"),l11lll_l1_ (u"ࠩࠪ⷏"),l11lll_l1_ (u"ࠪࠫⷐ"),l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ⷑ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪⷒ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨⷓ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩⷔ"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⷕ"),l111ll_l1_+title,link,392,l1llll_l1_)
	return
def PLAY(url):
	html = l1ll1l11l1_l1_(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ⷖ"),url,l11lll_l1_ (u"ࠪࠫ⷗"),l11lll_l1_ (u"ࠫࠬⷘ"),l11lll_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪⷙ"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪⷚ"),url,l11lll_l1_ (u"ࠧࠨⷛ"),l11lll_l1_ (u"ࠨࠩⷜ"),l11lll_l1_ (u"ࠩࠪⷝ"),l11lll_l1_ (u"ࠪࠫⷞ"),l11lll_l1_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⷟"))
	#html = response.content
	if kodi_version>18.99:
		try: html = html.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪⷠ"),l11lll_l1_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ⷡ"))
		except: pass
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬⷢ"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶ࠲ࡵࡰࡵ࡫ࡲࡲ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࡠࠨࡼ࡝ࠩࡠࠬࡸ࡮ࡥࡢࡦࡨࡶࢁࡶࡡࡨࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠭ࡠࠨࡼ࡝ࠩࡠࠫⷣ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0][0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡵࡵࡳࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡰࡸࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡹ࡭ࡩࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ⷤ"),block,re.DOTALL)
		for type,post,l1l1lllllll_l1_,title in items:
			#link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡸ࠰ࡤࡰ࡫ࡧࡪࡦࡴࡷࡺ࠳ࡩ࡯࡮࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࡦࡪ࡭ࡪࡰ࠰ࡥ࡯ࡧࡸ࠯ࡲ࡫ࡴࠬⷥ")
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡦࡲࡳࡤࡶ࡬ࡢࡻࡨࡶࡤࡧࡪࡢࡺࠩࡴࡴࡹࡴ࠾ࠩⷦ")+post+l11lll_l1_ (u"ࠬࠬ࡮ࡶ࡯ࡨࡁࠬⷧ")+l1l1lllllll_l1_+l11lll_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠭ⷨ")+type
			link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨⷩ")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩⷪ")
			l1111_l1_.append(link)
	# download links
	#WRITE_THIS(html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠪࠫ࡮ࡪ࠽࡜ࠤࠪࡡࡩࡵࡷ࡯࡮ࡲࡥࡩࡡࠢࠨ࡟ࠣࡧࡱࡧࡳࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࡡࠢࠨ࡟ࡶࡦࡴࡾ࡛ࠣࠩࡠࠫࠬ࠭ⷫ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࠫࠬ࡯࡭ࡨࠢࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠴ࠪࡀ࡝ࠥࠫࡢࡷࡵࡢ࡮࡬ࡸࡾࡡࠢࠨ࡟ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫⷬ"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬⷭ"),l11lll_l1_ (u"ࠬ࠭ⷮ"),str(items),str(block))
		for l1llll_l1_,link,l11l111l_l1_,l1ll1111111_l1_ in items:
			if l11lll_l1_ (u"࠭࠽ࠨⷯ") in l1llll_l1_:
				host = l1llll_l1_.split(l11lll_l1_ (u"ࠧ࠾ࠩⷰ"))[1]
				title = SERVER(host,l11lll_l1_ (u"ࠨࡪࡲࡷࡹ࠭ⷱ"))
			else: title = l11lll_l1_ (u"ࠩࠪⷲ")
			title = l1ll1111111_l1_+l11lll_l1_ (u"ࠪࠤࠬⷳ")+title
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬⷴ")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡣࡤ࠭ⷵ")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫⷶ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ⷷ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩⷸ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪⷹ"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬⷺ"),l11lll_l1_ (u"ࠫ࠰࠭ⷻ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪⷼ")+search
	l1111l_l1_(url,l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ⷽ"))
	return
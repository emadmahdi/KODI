# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ᠀")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡄࡏࡆࡣࠬ᠁")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺࠧำฺ๋ࠥอไๆืสี฾ํࠧ᠂"),l11lll_l1_ (u"ࠨๆ็็ออัࠡใๅ฻ࠥ࠱࠱࠹ࠩ᠃"),l11lll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ᠄"),l11lll_l1_ (u"ࠪหๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭᠅")]
headers = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ᠆"):l11ll1_l1_}
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l1lll1l1l1_l1_(url)
	elif mode==634: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭᠇")+text)
	elif mode==635: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ᠈")+text)
	elif mode==639: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ᠉"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ᠊"),headers,l11lll_l1_ (u"ࠩࠪ᠋"),l11lll_l1_ (u"ࠪࠫ᠌"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ᠍"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᠎"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭᠏"),l11ll1_l1_,639,l11lll_l1_ (u"ࠧࠨ᠐"),l11lll_l1_ (u"ࠨࠩ᠑"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᠒"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠓"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ᠔"),l11ll1_l1_,635,l11lll_l1_ (u"ࠬ࠭᠕"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭᠖"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠗"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ᠘"),l11ll1_l1_,634,l11lll_l1_ (u"ࠩࠪ᠙"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ᠚"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᠛"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᠜"),l11lll_l1_ (u"࠭ࠧ᠝"),9999)
	link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡳ࡭ࡳࡶ࡯ࡴࡶࡶࠪࡤࡩ࡯ࡶࡰࡷࡁ࠶࠶ࠧ᠞")
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠟"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᠠ")+l111ll_l1_+l11lll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᠡ"),link,631,l11lll_l1_ (u"ࠫࠬᠢ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᠣ"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᠤ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡖࡤࡦࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᠥ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᠦ"),block,re.DOTALL)
	for data,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡺࡹࡱࡧࡀࡳࡳ࡫ࠦࡥࡣࡷࡥࡂ࠭ᠧ")+data
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠨ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᠩ")+l111ll_l1_+title,link,631)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᠪ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᠫ"),l11lll_l1_ (u"ࠧࠨᠬ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᠭ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᠮ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠯ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᠰ")+l111ll_l1_+title,link,631)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠬ࠭ᠱ")):
	if type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᠲ"):
		l1l1ll1ll_l1_ = headers.copy()
		l1l1ll1ll_l1_[l11lll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪᠳ")] = l11lll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩᠴ")
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᠵ"),url,l11lll_l1_ (u"ࠪࠫᠶ"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬᠷ"),l11lll_l1_ (u"ࠬ࠭ᠸ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᠹ"))
		html = response.content
		block = html
	else:
		block = l11lll_l1_ (u"ࠧࠨᠺ")
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᠻ"),url,l11lll_l1_ (u"ࠩࠪᠼ"),headers,l11lll_l1_ (u"ࠪࠫᠽ"),l11lll_l1_ (u"ࠫࠬᠾ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᠿ"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡭ࡦࡦ࡬ࡥ࠲ࡨ࡬ࡰࡥ࡮ࠬ࠳࠰࠿ࠪࡨࡲࡳࡹ࡫ࡲ࠮࡯ࡨࡲࡺ࠭ᡀ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᡁ"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		l1llll_l1_ = l1llll_l1_+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᡂ")+l11ll1_l1_
		if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᡃ") in link: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᡄ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᡅ")+l111ll_l1_+title,link,633,l1llll_l1_)
		elif l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᡆ") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡇ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᡈ")+l111ll_l1_+title,link,633,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᡉ") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᡊ"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᡋ")+l111ll_l1_+title,link,631,l1llll_l1_)
		elif l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠭ᡌ") in link: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡍ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᡎ")+l111ll_l1_+title,link,631,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᡏ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᡐ")+l111ll_l1_+title,link,632,l1llll_l1_)
	# l1lll1lll1_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᡑ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᡒ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᡓ"),l11lll_l1_ (u"ࠬ࠭ᡔ"))
			if title!=l11lll_l1_ (u"࠭ࠧᡕ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡖ"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧᡗ")+title,link,631)
	return
def l1lll1l1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᡘ"),url,l11lll_l1_ (u"ࠪࠫᡙ"),headers,l11lll_l1_ (u"ࠫࠬᡚ"),l11lll_l1_ (u"ࠬ࠭ᡛ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡕࡈࡅࡘࡕࡎࡔࡡࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᡜ"))
	html = response.content
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡪࡸ࠭ࡪ࡯ࡤ࡫ࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᡝ"),html,re.DOTALL)
	l1llll_l1_ = l1llll_l1_[0] if l1llll_l1_ else l11lll_l1_ (u"ࠨࠩᡞ")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡳࡱࡪࡥࡳ࠯ࡥࡰࡴࡩ࡫࠯ࠬࡂࡀ࡭࠸ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᡟ"),html,re.DOTALL)
	for name,block in l1l1ll1_l1_:
		# l1lllll_l1_
		if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᡠ") in url and l11lll_l1_ (u"๊ࠫ๎วิ็ࠪᡡ") in name:
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧᡢ"),block,re.DOTALL)
			for link,title in items:
				title = title.replace(l11lll_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠭ᡣ"),l11lll_l1_ (u"ࠧࠡࠩᡤ")).replace(l11lll_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩᡥ"),l11lll_l1_ (u"ࠩࠪᡦ"))
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᡧ"),l111ll_l1_+title,link,633,l1llll_l1_)
		# l1l1l_l1_
		if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᡨ") in url and l11lll_l1_ (u"ࠬำไใษอࠫᡩ") in name:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨᡪ"),block,re.DOTALL)
			for link,title in items:
				title = title.replace(l11lll_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠧᡫ"),l11lll_l1_ (u"ࠨࠢࠪᡬ")).replace(l11lll_l1_ (u"ࠩ࠿࠳ࡸࡶࡡ࡯ࡀࠪᡭ"),l11lll_l1_ (u"ࠪࠫᡮ"))
				addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᡯ"),l111ll_l1_+title,link,632,l1llll_l1_)
	return
def PLAY(url):
	url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨᡰ"),l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧᡱ")).replace(l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲ࠵ࠧᡲ"),l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩᡳ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᡴ"),url,l11lll_l1_ (u"ࠪࠫᡵ"),headers,l11lll_l1_ (u"ࠫࠬᡶ"),l11lll_l1_ (u"ࠬ࠭ᡷ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᡸ"))
	html = response.content
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠭ࡸࡴࡤࡴࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᡹"),html,re.DOTALL)
	if link:
		link = link[0]
		l1lll11ll1_l1_.append(link)
		server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭᡺"))
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᡻")+server+l11lll_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ᡼"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡺࡡࡣࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᡽"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11llll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭᡾"),html,re.DOTALL)
		l11llll1_l1_ = l11llll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᡿"),block,re.DOTALL)
		for l1l11111_l1_,title in items:
			title = title.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪᢀ"),l11lll_l1_ (u"ࠨࠩᢁ"))
			if not title: title = l11lll_l1_ (u"ࠩสุ่๐ัโำࠣห้๋ๅ๋ิࠪᢂ")
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨᢃ")+l11llll1_l1_+l11lll_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨᢄ")+l1l11111_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᢅ")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᢆ")
			l1lllll1_l1_.append(link)
	# download links
	items = re.findall(l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡰࡴࡩ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬᢇ"),html,re.DOTALL)
	for link,title in items:
		if link not in l1lll11ll1_l1_:
			l1lll11ll1_l1_.append(link)
			title = title.replace(l11lll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠨᢈ"),l11lll_l1_ (u"ࠩࠣࠫᢉ")).replace(l11lll_l1_ (u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫᢊ"),l11lll_l1_ (u"ࠫࠬᢋ")).replace(l11lll_l1_ (u"ࠬࡂࡩ࠿ࠩᢌ"),l11lll_l1_ (u"࠭ࠧᢍ")).replace(l11lll_l1_ (u"ࠧ࠽࠱࡬ࡂࠬᢎ"),l11lll_l1_ (u"ࠨࠢࠪᢏ"))
			l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᢐ")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᢑ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᢒ"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᢓ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨᢔ"),l11lll_l1_ (u"ࠧࠬࠩᢕ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᢖ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᢗ"))
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_ l1lllll1l_l1_ 2023-10-30
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᢘ"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᢙ"),url,l11lll_l1_ (u"ࠬ࠭ᢚ"),headers,l11lll_l1_ (u"࠭ࠧᢛ"),l11lll_l1_ (u"ࠧࠨᢜ"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬᢝ"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩᢞ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡴࡵࠣࡀ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᢟ"),block,re.DOTALL)
		names,l1lll1l111_l1_,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠫࡨࡧࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᢠ"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	if l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᢡ") in url:
		url,filters = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᢢ"))
		# filter final url
		link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫᢣ")+filters
	else: link = l11ll1_l1_
	return link
l1lll11lll_l1_ = [l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪᢤ"),l11lll_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨᢥ"),l11lll_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᢦ"),l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬᢧ")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᢨ"),l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶᢩࠬ"),l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᢪ")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᢫"),l11lll_l1_ (u"ࠩࠪ᢬"))
	url = url.split(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ᢭"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ᢮"),1)
	if filter==l11lll_l1_ (u"ࠬ࠭᢯"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"࠭ࠧᢰ"),l11lll_l1_ (u"ࠧࠨᢱ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬᢲ"))
	if type==l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪᢳ"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"ࠪࡁࠬᢴ") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"ࠫࡂ࠭ᢵ") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧᢶ")+category+l11lll_l1_ (u"࠭࠽࠱ࠩᢷ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩᢸ")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫᢹ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫᢺ"))+l11lll_l1_ (u"ࠪࡣࡤࡥࠧᢻ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭ᢼ"))
		# l1lll1l1ll_l1_ url type
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᢽ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᢾ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬᢿ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᣀ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		# l1lll1ll1l_l1_ url type
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᣁ"))
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᣂ")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᣃ"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨᣄ"),l11l1l1_l1_,631,l11lll_l1_ (u"࠭ࠧᣅ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᣆ"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣇ"),l111ll_l1_+l11lll_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩᣈ")+l11lll11_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩᣉ"),l11l1l1_l1_,631,l11lll_l1_ (u"ࠫࠬᣊ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࠬᣋ"))
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᣌ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᣍ"),l11lll_l1_ (u"ࠨࠩᣎ"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠩๆ่ࠥ࠭ᣏ"),l11lll_l1_ (u"ࠪࠫᣐ"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠫࡂ࠭ᣑ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᣒ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_,l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᣓ"))
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᣔ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣕ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪᣖ"),l11l1l1_l1_,631,l11lll_l1_ (u"ࠪࠫᣗ"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᣘ"))
				else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣙ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧᣚ"),l11l11l_l1_,635,l11lll_l1_ (u"ࠧࠨᣛ"),l11lll_l1_ (u"ࠨࠩᣜ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧᣝ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬᣞ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧᣟ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧᣠ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩᣡ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫᣢ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣣ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫᣤ")+name,l11l11l_l1_,634,l11lll_l1_ (u"ࠪࠫᣥ"),l11lll_l1_ (u"ࠫࠬᣦ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧᣧ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l1l1l1_l1_: continue
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨᣨ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾ࠩᣩ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪᣪ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀࠫᣫ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧᣬ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠫࠥࡀࠧᣭ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠬ࠶ࠧᣮ")]
			title = option+l11lll_l1_ (u"࠭ࠠ࠻ࠩᣯ")+name
			if type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬᣰ"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣱ"),l111ll_l1_+title,url,634,l11lll_l1_ (u"ࠩࠪᣲ"),l11lll_l1_ (u"ࠪࠫᣳ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᣴ"))
			elif type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᣵ") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"࠭࠽ࠨ᣶") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ᣷"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ᣸")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᣹"),l111ll_l1_+title,l11l1l1_l1_,631,l11lll_l1_ (u"ࠪࠫ᣺"),l11lll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ᣻"))
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᣼"),l111ll_l1_+title,url,635,l11lll_l1_ (u"࠭ࠧ᣽"),l11lll_l1_ (u"ࠧࠨ᣾"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ᣿")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᤀ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᤁ")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠫࡂࠬࠧᤂ"),l11lll_l1_ (u"ࠬࡃ࠰ࠧࠩᤃ"))
	filters = filters.strip(l11lll_l1_ (u"࠭ࠦࠨᤄ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠧ࠾ࠩᤅ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠪᤆ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࠫᤇ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠪࠫᤈ")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠫ࠵࠭ᤉ")
		if l11lll_l1_ (u"ࠬࠫࠧᤊ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨᤋ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᤌ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬᤍ")+value
		elif mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᤎ") and value!=l11lll_l1_ (u"ࠪ࠴ࠬᤏ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ᤐ")+key+l11lll_l1_ (u"ࠬࡃࠧᤑ")+value
		elif mode==l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪᤒ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩᤓ")+key+l11lll_l1_ (u"ࠨ࠿ࠪᤔ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭ᤕ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬᤖ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠫࡂ࠶ࠧᤗ"),l11lll_l1_ (u"ࠬࡃࠧᤘ"))
	return l1ll1l1l_l1_
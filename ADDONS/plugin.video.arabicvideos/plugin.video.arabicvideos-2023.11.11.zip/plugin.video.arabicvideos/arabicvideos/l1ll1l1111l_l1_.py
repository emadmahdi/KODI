# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩう")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡍࡌࡔࡡࠪぇ")
def MAIN(mode,url,text,l1l11l1_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1l1ll11l1l_l1_(text)
	elif mode==542: results = l1l1l1ll11l_l1_(text,url,l1l11l1_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬえ"),l11lll_l1_ (u"࠭ศฮอࠣะิ๐ฯࠨぉ"),l11lll_l1_ (u"ࠧࠨお"),549)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭か"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾ࠢๆ่๊อสࠡ็ัึ๋ฯࠠ࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭が"),l11lll_l1_ (u"ࠪࠫき"),9999)
	l1l1ll11111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩぎ"),l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪく"))
	if l1l1ll11111_l1_:
		l1l1ll11111_l1_ = l1l1ll11111_l1_[l11lll_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧぐ")]
		for search in reversed(l1l1ll11111_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧけ"),search,l11lll_l1_ (u"ࠨࠩげ"),549,l11lll_l1_ (u"ࠩࠪこ"),l11lll_l1_ (u"ࠪࠫご"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1ll1_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1ll1l11ll1_l1_ = search.replace(l111ll_l1_,l11lll_l1_ (u"ࠫࠬさ"))
	l1l1l1l111l_l1_(l1ll1l11ll1_l1_)
	#l1l1l11ll11_l1_ = search+options+l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩざ")
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫし"),l11lll_l1_ (u"ฺࠧ็็ࠤอำหࠡฮ่ห฾๐ࠠ࠮ࠢࠪじ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧす"),542,l11lll_l1_ (u"ࠩࠪず"),l11lll_l1_ (u"ࠪࠫせ"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩぜ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪそ"),l11lll_l1_ (u"࠭ࠧぞ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧた"),l11lll_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅโื็อࠥ࠳ࠠࠨだ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࡲࡴࡪࡴࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨち"),542,l11lll_l1_ (u"ࠪࠫぢ"),l11lll_l1_ (u"ࠫࠬっ"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬつ"),l11lll_l1_ (u"࠭ๆหษษะࠥอไษฯฮࠤ๊่ำๆหࠣ࠱ࠥ࠭づ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭て"),542,l11lll_l1_ (u"ࠨࠩで"),l11lll_l1_ (u"ࠩࠪと"),l1ll1l11ll1_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪど"),l11lll_l1_ (u"ࠫอำหࠡ็้ๅึีࠠ࠮ࠢࠪな")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭に"),541,l11lll_l1_ (u"࠭ࠧぬ"),l11lll_l1_ (u"ࠧࠨね"),l1ll1l11ll1_l1_)
	return
def l1l1l1l111l_l1_(l1l1ll1l1l1_l1_):
	l1l1ll1ll11_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭の"),l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧは"),l1l1ll1l1l1_l1_)
	l1l1ll1l1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨば"),l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩぱ"),l111ll_l1_+l1l1ll1l1l1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪひ"),l1l1ll1l1l1_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫび"),l111ll_l1_+l1l1ll1l1l1_l1_)
	old_value = l1l1ll1ll11_l1_+l1l1ll1l1ll_l1_
	if old_value: l1l1ll1l1l1_l1_ = l111ll_l1_+l1l1ll1l1l1_l1_
	WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬぴ"),l1l1ll1l1l1_l1_,old_value,VERYLONG_CACHE)
	return
def l1l1l1l1l1l_l1_():
	l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠨࠩふ"),l11lll_l1_ (u"ࠩࠪぶ"),l11lll_l1_ (u"ࠪࠫぷ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧへ"),l11lll_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠢࠩべ"))
	if l1ll111ll1_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫぺ"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭ほ"))
	DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧぼ"))
	DIALOG_OK(l11lll_l1_ (u"ࠩࠪぽ"),l11lll_l1_ (u"ࠪࠫま"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧみ"),l11lll_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ั࠭む"))
	return
def l1l1l1ll11l_l1_(l1l1l1l1ll1_l1_,action,l1l1l1ll1ll_l1_=l11lll_l1_ (u"࠭ࠧめ")):
	l1l1l1lll11_l1_,l1l1l1lll1l_l1_,l1l1ll111l1_l1_,l1l1l11l1l1_l1_,l1l1l11ll1l_l1_,l1l1ll1111l_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭も"):
		if action==l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧゃ"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧや"),l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨゅ"),l111ll_l1_+l1l1l1l1ll1_l1_)
		elif action==l11lll_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪゆ"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪょ"),l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬよ"),l1l1l1l1ll1_l1_)
		elif action==l11lll_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ら"): l1l1ll111l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭り"),l11lll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨる"),(l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_))
	if not l1l1ll111l1_l1_:
		l1l1ll11ll1_l1_ = l11lll_l1_ (u"๋ࠪีอࠠศๆหัะฺ๋ࠦำ้ࠣํา่ะࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤࡡࡴ࡜࡯࡞ࡱࠫれ")
		l1l1ll11lll_l1_ = l11lll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไร่ࠣห้ฮอฬࠢไ๎ࠥาๅ๋฻ࠣห้๋่ศไ฼ࠤ฾์ࠠ࡝ࡰࠣࠦࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠࠨろ")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠣࠢ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้ฮอฬࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠧゎ")
		if action==l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬわ"): message = l1l1ll11lll_l1_
		else: message = l1l1ll11ll1_l1_+l1l1ll11lll_l1_
		l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠧࠨゐ"),l11lll_l1_ (u"ࠨࠩゑ"),l11lll_l1_ (u"ࠩࠪを"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ん"),message)
		if l1ll111ll1_l1_!=1: return
		LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫゔ"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩゕ")+l1l1l1l1ll1_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠩゖ"))
		#global menuItemsLIST
		import threading
		#l1l1l1lllll_l1_ = [l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭゗"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ゘"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ゙࡙ࠪ")]
		l1l1lll111l_l1_ = 1
		for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
			l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_] = []
			options = l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ゚")
			if l11lll_l1_ (u"ࠫ࠲࠭゛") in l1l1l1ll1ll_l1_: options = options+l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࠪ゜")+l1l1l1ll1ll_l1_+l11lll_l1_ (u"࠭࡟ࠨゝ")
			l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
			if l1l1lll111l_l1_:
				time.sleep(0.5)
				threads[l1l1l1ll1ll_l1_] = threading.Thread(target=l1l1l1ll1l1_l1_,args=(l1l1l1l1ll1_l1_+options,))
				threads[l1l1l1ll1ll_l1_].start()
			else: l1l1l1ll1l1_l1_(l1l1l1l1ll1_l1_+options)
			DIALOG_NOTIFICATION(TRANSLATE(l1l1l1ll1ll_l1_),l11lll_l1_ (u"ࠧࠨゞ"),time=1000)
		if l1l1lll111l_l1_:
			time.sleep(2)
			for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
				threads[l1l1l1ll1ll_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩゟ"),l11lll_l1_ (u"ࠩࠪ゠"),l11lll_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠢࡩࡳࡺࡴࡤࡦࡦ࠽ࠫァ"),str(len(menuItemsLIST)))
		for l1l1l1ll1ll_l1_ in l1l1l1lllll_l1_:
			l1l1l1l11l1_l1_,l1l1l1ll1l1_l1_,l1l1lll1111_l1_ = l1l1l11lll1_l1_(l1l1l1ll1ll_l1_)
			for l1l1l1ll111_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
				if l1l1lll1111_l1_ in name:
					if l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࠪア") in l1l1l1ll1ll_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨィ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫイ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬゥ")]: continue
						if l11lll_l1_ (u"ࠨืไัฮ࠭ウ") not in name:
							if   type==l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧェ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭エ")
							elif type==l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪォ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪオ")
							elif type==l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭カ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬガ")
						else:
							if   l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭キ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬギ")
							elif l11lll_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪク") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩグ")
							elif l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬケ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫゲ")
					elif l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࠬコ") in l1l1l1ll1ll_l1_ and 729>=mode>=710:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪゴ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭サ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧザ")]: continue
						if l11lll_l1_ (u"ฺࠫ็อสࠩシ") not in name:
							if   type==l11lll_l1_ (u"ࠬࡲࡩࡷࡧࠪジ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨス")
							elif type==l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ズ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬセ")
							elif type==l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩゼ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧソ")
						else:
							if   l11lll_l1_ (u"ࠫࡑࡏࡖࡆࠩゾ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧタ")
							elif l11lll_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭ダ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫチ")
							elif l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨヂ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ッ")
					elif l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࠬツ") in l1l1l1ll1ll_l1_ and 149>=mode>=140:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧヅ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩテ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧデ")]: continue
						if l11lll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪト") in name or l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬド") in name:
							continue
							#if   l11l_l1_==l11lll_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫナ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ニ")
							#elif l11l_l1_==l11lll_l1_ (u"ࠫࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧヌ"): l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩネ")
							#else: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧノ")
						else:
							if   mode==144 and l11lll_l1_ (u"ࠧࡖࡕࡈࡖࠬハ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫバ")
							elif mode==144 and l11lll_l1_ (u"ࠩࡆࡌࡓࡒࠧパ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ヒ")
							elif mode==144 and l11lll_l1_ (u"ࠫࡑࡏࡓࡕࠩビ") in name: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩピ")
							elif mode==143: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧフ")
							else: continue
					elif l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠭ブ") in l1l1l1ll1ll_l1_ and 419>=mode>=400:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩプ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩヘ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨベ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩペ")]: continue
						if   mode in [401,405]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ホ")
						elif mode in [402,406]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ボ")
						elif mode in [403,404]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬポ")
						elif mode in [412,413]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭マ")
					elif l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࠩミ") in l1l1l1ll1ll_l1_ and 39>=mode>=30:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩム")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪメ")]: continue
						if   mode in [32,39]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫモ")
						elif mode in [33,39]: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬャ")
					elif l11lll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࠧヤ") in l1l1l1ll1ll_l1_ and 29>=mode>=20:
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧュ")]: continue
						if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l11lll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩユ")]: continue
						if   l11lll_l1_ (u"ࠪ࠳ࡦࡸ࠮ࠨョ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪヨ")
						elif l11lll_l1_ (u"ࠬ࠵ࡥ࡯࠰ࠪラ") in url: l1l1l1ll1ll_l1_ = l11lll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭リ")
					#elif l11lll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࠫル") in l1l1l1ll1ll_l1_ and 319>=mode>=310:
					#	if l1l1l1ll111_l1_ in l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_]: continue
					#	if mode==312: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠨ࠯ࡄ࡙ࡉࡏࡏࡔࠩレ")
					#	elif l11lll_l1_ (u"ࠩ࠲ࡧࡦࡺ࠭ࠨロ") in url: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠪ࠱ࡆࡒࡂࡖࡏࡖࠫヮ")
					#	else: l1l1l1ll1ll_l1_ = l1l1l1l11ll_l1_+l11lll_l1_ (u"ࠫ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭ワ")
					l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
		menuItemsLIST[:] = []
		for l1l1l1ll1ll_l1_ in list(l1l1l11l1l1_l1_.keys()):
			l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_] = []
			l1l1ll1111l_l1_[l1l1l1ll1ll_l1_] = []
			for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1l1l11l1l1_l1_[l1l1l1ll1ll_l1_]:
				l1l1l1ll111_l1_ = (type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
				if l11lll_l1_ (u"ࠬ฻แฮหࠪヰ") in name and type==l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ヱ"): l1l1ll1111l_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
				else: l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_].append(l1l1l1ll111_l1_)
		l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬヲ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫン"),l11lll_l1_ (u"ࠩࠪヴ"),157,l11lll_l1_ (u"ࠪࠫヵ"),l11lll_l1_ (u"ࠫࠬヶ"),l11lll_l1_ (u"ࠬ࠭ヷ"),l11lll_l1_ (u"࠭ࠧヸ"),l11lll_l1_ (u"ࠧࠨヹ"))]
		for l1l1l1ll1ll_l1_ in l1l1l1llll1_l1_:
			if l1l1l1ll1ll_l1_==l1l1l1l1l11_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ヺ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ・"),l11lll_l1_ (u"ࠪࠫー"),157,l11lll_l1_ (u"ࠫࠬヽ"),l11lll_l1_ (u"ࠬ࠭ヾ"),l11lll_l1_ (u"࠭ࠧヿ"),l11lll_l1_ (u"ࠧࠨ㄀"),l11lll_l1_ (u"ࠨࠩ㄁"))]
			elif l1l1l1ll1ll_l1_==l1l1ll1ll1l_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㄂"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㄃"),l11lll_l1_ (u"ࠫࠬ㄄"),157,l11lll_l1_ (u"ࠬ࠭ㄅ"),l11lll_l1_ (u"࠭ࠧㄆ"),l11lll_l1_ (u"ࠧࠨㄇ"),l11lll_l1_ (u"ࠨࠩㄈ"),l11lll_l1_ (u"ࠩࠪㄉ"))]
			elif l1l1l1ll1ll_l1_==l1l1l11l1ll_l1_[0]: l1l1ll11l11_l1_ = [(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨㄊ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㄋ"),l11lll_l1_ (u"ࠬ࠭ㄌ"),157,l11lll_l1_ (u"࠭ࠧㄍ"),l11lll_l1_ (u"ࠧࠨㄎ"),l11lll_l1_ (u"ࠨࠩㄏ"),l11lll_l1_ (u"ࠩࠪㄐ"),l11lll_l1_ (u"ࠪࠫㄑ"))]
			if l1l1l1ll1ll_l1_ not in l1l1l11ll1l_l1_.keys(): continue
			if l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_]:
				l1l1l1l1111_l1_ = TRANSLATE(l1l1l1ll1ll_l1_)
				l1l1l1l1lll_l1_ = [(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㄒ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࠦࠧㄓ")+l1l1l1l1111_l1_+l11lll_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㄔ"),l11lll_l1_ (u"ࠧࠨㄕ"),9999,l11lll_l1_ (u"ࠨࠩㄖ"),l11lll_l1_ (u"ࠩࠪㄗ"),l11lll_l1_ (u"ࠪࠫㄘ"),l11lll_l1_ (u"ࠫࠬㄙ"),l11lll_l1_ (u"ࠬ࠭ㄚ"))]
				if 0:
					l1l1ll1lll1_l1_ = l1l1l1l1ll1_l1_+l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪㄛ")+l11lll_l1_ (u"ࠧษฯฮࠫㄜ")+l11lll_l1_ (u"ࠨࠢࠪㄝ")+l1l1l1l1111_l1_
				else:
					l1l1ll1lll1_l1_ = l11lll_l1_ (u"ࠩหัะ࠭ㄞ")+l11lll_l1_ (u"ࠪࠤࠬㄟ")+l1l1l1l1111_l1_+l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨㄠ")+l1l1l1l1ll1_l1_
				if len(l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_])<8: l1l1ll111ll_l1_ = []
				else:
					l1l1ll1llll_l1_ = l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨㄡ")+l1l1ll1lll1_l1_+l11lll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨㄢ")
					l1l1ll111ll_l1_ = [(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄣ"),l111ll_l1_+l1l1ll1llll_l1_,l11lll_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧㄤ"),542,l11lll_l1_ (u"ࠩࠪㄥ"),l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠪࠫㄦ"),l11lll_l1_ (u"ࠫࠬㄧ"))]
				l1l1ll1l111_l1_ = l1l1l11ll1l_l1_[l1l1l1ll1ll_l1_]+l1l1ll1111l_l1_[l1l1l1ll1ll_l1_]
				l1l1l1lll1l_l1_ += l1l1ll11l11_l1_+l1l1l1l1lll_l1_+l1l1ll1l111_l1_[:7]+l1l1ll111ll_l1_
				l1l1l11llll_l1_ = [(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㄨ"),l111ll_l1_+l1l1ll1lll1_l1_,l11lll_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬㄩ"),542,l11lll_l1_ (u"ࠧࠨㄪ"),l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_,l11lll_l1_ (u"ࠨࠩㄫ"),l11lll_l1_ (u"ࠩࠪㄬ"))]
				l1l1l1lll11_l1_ += l1l1ll11l11_l1_+l1l1l11llll_l1_
				l1l1ll11l11_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩㄭ"),(l1l1l1ll1ll_l1_,l1l1l1l1ll1_l1_),l1l1ll1l111_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪㄮ"),l1l1l1l1ll1_l1_,l1l1l1lll1l_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪㄯ"),l1l1l1l1ll1_l1_)
		WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ㄰"),l111ll_l1_+l1l1l1l1ll1_l1_,l1l1l1lll11_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨㄱ"),l11lll_l1_ (u"ࠨࠩㄲ"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬㄳ"),l11lll_l1_ (u"ࠪห้ฮอฬࠢส่ั๋วฺ์ࠣห๋ะ็๊ࠢห๊ัออࠡ࡞ࡱࡠࡳࠦสๆࠢอาื๐ๆࠡษ็๊ฯอฦอࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤ้๋ฯสࠢฮ่ฬั๊็ࠢํ์๊ࠦไไ์ࠣฮุะื๋฻ࠣห้฿่ะหࠣษ้๐็ศࠢหำํ์ฺࠠ็็ࠤอำหࠡฮา๎ิ࠭ㄴ"))
		if action==l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪㄵ") and l1l1l1lll11_l1_: l1l1ll111l1_l1_ = l1l1l1lll11_l1_
		else: l1l1ll111l1_l1_ = l1l1l1lll1l_l1_
	if action!=l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫㄶ"):
		for type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ in l1l1ll111l1_l1_:
			if action in [l11lll_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬㄷ"),l11lll_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ㄸ")] and l11lll_l1_ (u"ࠨืไัฮ࠭ㄹ") in name and type==l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄺ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_)
	return
def l1l1ll11l1l_l1_(l1l1l1l1ll1_l1_=l11lll_l1_ (u"ࠪࠫㄻ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1l1l1ll1_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11lll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫㄼ"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩㄽ")+search+l11lll_l1_ (u"࠭ࠠ࡞ࠩㄾ"))
	l111l1l_l1_ = search+options
	if 0:
		l1l1ll1l11l_l1_,l1ll1l11ll1_l1_ = search+l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫㄿ"),l11lll_l1_ (u"ࠨࠩㅀ")
	else:
		l1l1ll1l11l_l1_,l1ll1l11ll1_l1_ = l11lll_l1_ (u"ࠩࠪㅁ"),l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧㅂ")+search
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㅃ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨㅄ"),l11lll_l1_ (u"࠭ࠧㅅ"),157)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㅆ"),l11lll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧㅇ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦࡍ࠴ࡗࠪㅈ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫㅉ"),719,l11lll_l1_ (u"ࠫࠬㅊ"),l11lll_l1_ (u"ࠬ࠭ㅋ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅌ"),l11lll_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭ㅍ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯࠥࡏࡐࡕࡘࠪㅎ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪㅏ"),239,l11lll_l1_ (u"ࠪࠫㅐ"),l11lll_l1_ (u"ࠫࠬㅑ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅒ"),l11lll_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬㅓ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢห็ึอࠧㅔ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩㅕ"),379,l11lll_l1_ (u"ࠩࠪㅖ"),l11lll_l1_ (u"ࠪࠫㅗ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅘ"),l11lll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫㅙ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠧㅚ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨㅛ"),39,l11lll_l1_ (u"ࠨࠩㅜ"),l11lll_l1_ (u"ࠩࠪㅝ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅞ"),l11lll_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪㅟ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬㅠ"),l11lll_l1_ (u"࠭ࠧㅡ"),39,l11lll_l1_ (u"ࠧࠨㅢ"),l11lll_l1_ (u"ࠨࠩㅣ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧㅤ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅥ"),l11lll_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪㅦ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧㅧ"),l11lll_l1_ (u"࠭ࠧㅨ"),39,l11lll_l1_ (u"ࠧࠨㅩ"),l11lll_l1_ (u"ࠨࠩㅪ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧㅫ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅬ"),l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪㅭ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩㅮ"),l11lll_l1_ (u"࠭ࠧㅯ"),149,l11lll_l1_ (u"ࠧࠨㅰ"),l11lll_l1_ (u"ࠨࠩㅱ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩㅲ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅳ"),l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪㅴ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ㅵ"),l11lll_l1_ (u"࠭ࠧㅶ"),149,l11lll_l1_ (u"ࠧࠨㅷ"),l11lll_l1_ (u"ࠨࠩㅸ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬㅹ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅺ"),l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪㅻ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭ㅼ"),l11lll_l1_ (u"࠭ࠧㅽ"),149,l11lll_l1_ (u"ࠧࠨㅾ"),l11lll_l1_ (u"ࠨࠩㅿ"),l111l1l_l1_+l11lll_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫㆀ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆁ"),l11lll_l1_ (u"ࠫࡤࡑࡌࡂࡡࠪㆂ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠไๆࠣห้฿ัษࠩㆃ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧㆄ"),19,l11lll_l1_ (u"ࠧࠨㆅ"),l11lll_l1_ (u"ࠨࠩㆆ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆇ"),l11lll_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩㆈ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪㆉ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭ㆊ"),739,l11lll_l1_ (u"࠭ࠧㆋ"),l11lll_l1_ (u"ࠧࠨㆌ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㆍ"),l11lll_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨㆎ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪ㆏")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㆐"),329,l11lll_l1_ (u"ࠬ࠭㆑"),l11lll_l1_ (u"࠭ࠧ㆒"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㆓"),l11lll_l1_ (u"ࠨࡡࡉࡌ࠶ࡥࠧ㆔")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨ㆕")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㆖"),579,l11lll_l1_ (u"ࠫࠬ㆗"),l11lll_l1_ (u"ࠬ࠭㆘"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㆙"),l11lll_l1_ (u"ࠧࡠࡍࡗ࡚ࡤ࠭㆚")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧ㆛")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㆜"),819,l11lll_l1_ (u"ࠪࠫ㆝"),l11lll_l1_ (u"ࠫࠬ㆞"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㆟"),l11lll_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬㆠ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส๎ั๐ࠠษ์ึฮࠬㆡ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩㆢ"),129,l11lll_l1_ (u"ࠩࠪㆣ"),l11lll_l1_ (u"ࠪࠫㆤ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆥ"),l11lll_l1_ (u"ࠬࡥࡅࡃ࠳ࡢࠫㆦ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭ㆧ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨㆨ"),779,l11lll_l1_ (u"ࠨࠩㆩ"),l11lll_l1_ (u"ࠩࠪㆪ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㆫ"),l11lll_l1_ (u"ࠫࡤࡋࡂ࠳ࡡࠪㆬ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠶ࠬㆭ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧㆮ"),789,l11lll_l1_ (u"ࠧࠨㆯ"),l11lll_l1_ (u"ࠨࠩㆰ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆱ"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩㆲ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫㆳ"),l11lll_l1_ (u"ࠬ࠭ㆴ"),409,l11lll_l1_ (u"࠭ࠧㆵ"),l11lll_l1_ (u"ࠧࠨㆶ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࡣࠬㆷ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆸ"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩㆹ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ์ฬฬๅࠨㆺ"),l11lll_l1_ (u"ࠬ࠭ㆻ"),409,l11lll_l1_ (u"࠭ࠧㆼ"),l11lll_l1_ (u"ࠧࠨㆽ"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙࡟ࠨㆾ"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆿ"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ㇀")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ๊ํอสࠨ㇁"),l11lll_l1_ (u"ࠬ࠭㇂"),409,l11lll_l1_ (u"࠭ࠧ㇃"),l11lll_l1_ (u"ࠧࠨ㇄"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ㇅"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇆"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ㇇")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫࠥࠦศฮอ้ࠣํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠧ㇈")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬࠦࠠࠨ㇉"),l11lll_l1_ (u"࠭ࠧ㇊"),29,l11lll_l1_ (u"ࠧࠨ㇋"),l11lll_l1_ (u"ࠨࠩ㇌"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇍"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ㇎")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪ㇏"),l11lll_l1_ (u"ࠬ࠭㇐"),29,l11lll_l1_ (u"࠭ࠧ㇑"),l11lll_l1_ (u"ࠧࠨ㇒"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭㇓"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇔"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ㇕")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭㇖"),l11lll_l1_ (u"ࠬ࠭㇗"),29,l11lll_l1_ (u"࠭ࠧ㇘"),l11lll_l1_ (u"ࠧࠨ㇙"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍࡥࠧ㇚"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㇛"),l11lll_l1_ (u"ࠪࡣࡆࡑࡏࡠࠩ㇜")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦรไ๊ส้ࠥอไใัํ้ࠬ㇝")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㇞"),79,l11lll_l1_ (u"࠭ࠧ㇟"),l11lll_l1_ (u"ࠧࠨ㇠"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇡"),l11lll_l1_ (u"ࠩࡢࡅࡐ࡝࡟ࠨ㇢")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫ㇣")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㇤"),249,l11lll_l1_ (u"ࠬ࠭㇥"),l11lll_l1_ (u"࠭ࠧ㇦"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇧"),l11lll_l1_ (u"ࠨࡡࡐࡖࡋࡥࠧ㇨")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢส่๊฿วาใࠪ㇩"),l11lll_l1_ (u"ࠪࠫ㇪"),49,l11lll_l1_ (u"ࠫࠬ㇫"),l11lll_l1_ (u"ࠬ࠭㇬"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㇭"),l11lll_l1_ (u"ࠧࡠࡕࡋࡑࡤ࠭㇮")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็ࠠๆษๆืࠬ㇯")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪㇰ"),59,l11lll_l1_ (u"ࠪࠫㇱ"),l11lll_l1_ (u"ࠫࠬㇲ"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㇳ"),l11lll_l1_ (u"࠭࡟ࡇࡖࡐࡣࠬㇴ")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส่๊์ศาࠢส่ๆอืๆ์ࠪㇵ")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩㇶ"),69,l11lll_l1_ (u"ࠩࠪㇷ"),l11lll_l1_ (u"ࠪࠫㇸ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㇹ"),l11lll_l1_ (u"ࠬࡥࡋࡘࡖࡢࠫㇺ")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭ㇻ"),l11lll_l1_ (u"ࠧࠨㇼ"),139,l11lll_l1_ (u"ࠨࠩㇽ"),l11lll_l1_ (u"ࠩࠪㇾ"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㇿ"),l11lll_l1_ (u"ࠫࡤ࡙ࡈࡗࡡࠪ㈀")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠫ㈁"),l11lll_l1_ (u"࠭ࠧ㈂"),319,l11lll_l1_ (u"ࠧࠨ㈃"),l11lll_l1_ (u"ࠨࠩ㈄"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈅"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ㈆")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣๆฬืฦࠨ㈇"),l11lll_l1_ (u"ࠬ࠭㈈"),319,l11lll_l1_ (u"࠭ࠧ㈉"),l11lll_l1_ (u"ࠧࠨ㈊"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࡢࠫ㈋"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈌"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ㈍")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊ห้ࠣั๊ฯࠨ㈎"),l11lll_l1_ (u"ࠬ࠭㈏"),319,l11lll_l1_ (u"࠭ࠧ㈐"),l11lll_l1_ (u"ࠧࠨ㈑"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ㈒"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈓"),l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ㈔")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หูࠣํะ๊ศฬࠪ㈕"),l11lll_l1_ (u"ࠬ࠭㈖"),319,l11lll_l1_ (u"࠭ࠧ㈗"),l11lll_l1_ (u"ࠧࠨ㈘"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ㈙"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㈚"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㈛"),l11lll_l1_ (u"ࠫࠬ㈜"),157)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㈝"),l11lll_l1_ (u"࠭࡟ࡌࡖࡎࡣࠬ㈞")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๆฮ่๎สࠨ㈟")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㈠"),679,l11lll_l1_ (u"ࠩࠪ㈡"),l11lll_l1_ (u"ࠪࠫ㈢"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㈣"),l11lll_l1_ (u"ࠬࡥࡆࡋࡕࡢࠫ㈤")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ࠠษฯฮࠤ๊๎โฺࠢไะึࠦิ้ࠩ㈥")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠧࠡࠩ㈦"),l11lll_l1_ (u"ࠨࠩ㈧"),399,l11lll_l1_ (u"ࠩࠪ㈨"),l11lll_l1_ (u"ࠪࠫ㈩"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㈪"),l11lll_l1_ (u"ࠬࡥࡔࡗࡈࡢࠫ㈫")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡฬํๅ๏ࠦแศ่ࠪ㈬")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㈭"),469,l11lll_l1_ (u"ࠨࠩ㈮"),l11lll_l1_ (u"ࠩࠪ㈯"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㈰"),l11lll_l1_ (u"ࠫࡤࡒࡄࡏࡡࠪ㈱")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๅ๊า๎ࠥ์สࠨ㈲")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㈳"),459,l11lll_l1_ (u"ࠧࠨ㈴"),l11lll_l1_ (u"ࠨࠩ㈵"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈶"),l11lll_l1_ (u"ࠪࡣࡈࡓࡎࡠࠩ㈷")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ㈸")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㈹"),309,l11lll_l1_ (u"࠭ࠧ㈺"),l11lll_l1_ (u"ࠧࠨ㈻"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈼"),l11lll_l1_ (u"ࠩࡢ࡛ࡈࡓ࡟ࠨ㈽")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭㈾")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㈿"),569,l11lll_l1_ (u"ࠬ࠭㉀"),l11lll_l1_ (u"࠭ࠧ㉁"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉂"),l11lll_l1_ (u"ࠨࡡࡖࡌࡓࡥࠧ㉃")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤูอ็ะ้ࠢ๎ํุࠧ㉄")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㉅"),589,l11lll_l1_ (u"ࠫࠬ㉆"),l11lll_l1_ (u"ࠬ࠭㉇"),l111l1l_l1_+l11lll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ㉈"))
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉉"),l11lll_l1_ (u"ࠨࡡࡐࡇࡒࡥࠧ㉊")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭㉋")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㉌"),369,l11lll_l1_ (u"ࠫࠬ㉍"),l11lll_l1_ (u"ࠬ࠭㉎"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㉏"),l11lll_l1_ (u"ࠧࡠࡕࡋࡔࡤ࠭㉐")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣํ็ࠠษำ๋ࠫ㉑")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㉒"),489,l11lll_l1_ (u"ࠪࠫ㉓"),l11lll_l1_ (u"ࠫࠬ㉔"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㉕"),l11lll_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬ㉖")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ฼ีอࠦำ๋์าࠫ㉗")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㉘"),259,l11lll_l1_ (u"ࠩࠪ㉙"),l11lll_l1_ (u"ࠪࠫ㉚"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㉛"),l11lll_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫ㉜")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫ㉝"),l11lll_l1_ (u"ࠧࠨ㉞"),639,l11lll_l1_ (u"ࠨࠩ㉟"),l11lll_l1_ (u"ࠩࠪ㉠"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㉡"),l11lll_l1_ (u"ࠫࡤࡉ࠴ࡖࡡࠪ㉢")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็่า์๋ࠫ㉣")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㉤"),429,l11lll_l1_ (u"ࠧࠨ㉥"),l11lll_l1_ (u"ࠨࠩ㉦"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉧"),l11lll_l1_ (u"ࠪࡣࡘࡎ࠴ࡠࠩ㉨")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ㉩")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㉪"),119,l11lll_l1_ (u"࠭ࠧ㉫"),l11lll_l1_ (u"ࠧࠨ㉬"),l111l1l_l1_+l11lll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㉭"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉮"),l11lll_l1_ (u"ࠪࡣࡊࡈ࠳ࡠࠩ㉯")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠶ࠫ㉰")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㉱"),799,l11lll_l1_ (u"࠭ࠧ㉲"),l11lll_l1_ (u"ࠧࠨ㉳"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㉴"),l11lll_l1_ (u"ࠩࡢࡑ࠹࡛࡟ࠨ㉵")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩ㉶"),l11lll_l1_ (u"ࠫࠬ㉷"),389,l11lll_l1_ (u"ࠬ࠭㉸"),l11lll_l1_ (u"࠭ࠧ㉹"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉺"),l11lll_l1_ (u"ࠨࡡࡈࡋ࡛ࡥࠧ㉻")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤส๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫ㉼"),l11lll_l1_ (u"ࠪࠫ㉽"),229,l11lll_l1_ (u"ࠫࠬ㉾"),l11lll_l1_ (u"ࠬ࠭㉿"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㊀"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㊁"),l11lll_l1_ (u"ࠨࠩ㊂"),157)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㊃"),l11lll_l1_ (u"ࠪࡣࡑࡘ࡚ࡠࠩ㊄")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦไศำ๋ึฬ࠭㊅")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㊆"),709,l11lll_l1_ (u"࠭ࠧ㊇"),l11lll_l1_ (u"ࠧࠨ㊈"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊉"),l11lll_l1_ (u"ࠩࡢࡊࡘ࡚࡟ࠨ㊊")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็่ิฬสࠫ㊋")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㊌"),609,l11lll_l1_ (u"ࠬ࠭㊍"),l11lll_l1_ (u"࠭ࠧ㊎"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊏"),l11lll_l1_ (u"ࠨࡡࡉࡆࡐࡥࠧ㊐")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆฮัไหࠪ㊑")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㊒"),629,l11lll_l1_ (u"ࠫࠬ㊓"),l11lll_l1_ (u"ࠬ࠭㊔"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊕"),l11lll_l1_ (u"ࠧࡠ࡛ࡔࡘࡤ࠭㊖")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣ๎ฬ่่หࠩ㊗")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㊘"),669,l11lll_l1_ (u"ࠪࠫ㊙"),l11lll_l1_ (u"ࠫࠬ㊚"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㊛"),l11lll_l1_ (u"࠭࡟ࡃࡔࡖࡣࠬ㊜")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหีุะ๊อࠩ㊝")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㊞"),659,l11lll_l1_ (u"ࠩࠪ㊟"),l11lll_l1_ (u"ࠪࠫ㊠"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊡"),l11lll_l1_ (u"ࠬࡥࡈࡍࡅࡢࠫ㊢")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่้ࠡ็หู๊ࠥๆษࠪ㊣")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㊤"),89,l11lll_l1_ (u"ࠨࠩ㊥"),l11lll_l1_ (u"ࠩࠪ㊦"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㊧"),l11lll_l1_ (u"ࠫࡤࡊࡒ࠸ࡡࠪ㊨")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะำส้ฬࠦีฮࠩ㊩")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㊪"),689,l11lll_l1_ (u"ࠧࠨ㊫"),l11lll_l1_ (u"ࠨࠩ㊬"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㊭"),l11lll_l1_ (u"ࠪࡣࡈࡓࡆࡠࠩ㊮")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ㊯")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㊰"),99,l11lll_l1_ (u"࠭ࠧ㊱"),l11lll_l1_ (u"ࠧࠨ㊲"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊳"),l11lll_l1_ (u"ࠩࡢࡇࡒࡒ࡟ࠨ㊴")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨ㊵")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㊶"),479,l11lll_l1_ (u"ࠬ࠭㊷"),l11lll_l1_ (u"࠭ࠧ㊸"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊹"),l11lll_l1_ (u"ࠨࡡࡄࡆࡉࡥࠧ㊺")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ฼ฬิ๎ࠧ㊻")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㊼"),559,l11lll_l1_ (u"ࠫࠬ㊽"),l11lll_l1_ (u"ࠬ࠭㊾"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊿"),l11lll_l1_ (u"ࠧࡠࡅ࠷ࡌࡤ࠭㋀")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡ࠶࠳࠴ࠬ㋁")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ㋂"),699,l11lll_l1_ (u"ࠪࠫ㋃"),l11lll_l1_ (u"ࠫࠬ㋄"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋅"),l11lll_l1_ (u"࠭࡟ࡂࡊࡎࡣࠬ㋆")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭㋇")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ㋈"),619,l11lll_l1_ (u"ࠩࠪ㋉"),l11lll_l1_ (u"ࠪࠫ㋊"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋋"),l11lll_l1_ (u"ࠬࡥࡃࡄࡄࡢࠫ㋌")+l1l1ll1l11l_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫ㋍")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠧࠨ㋎"),639,l11lll_l1_ (u"ࠨࠩ㋏"),l11lll_l1_ (u"ࠩࠪ㋐"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋑"),l11lll_l1_ (u"ࠫࡤ࡙ࡈࡕࡡࠪ㋒")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไ๋ฬࠦส๋ใํࠫ㋓")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㋔"),649,l11lll_l1_ (u"ࠧࠨ㋕"),l11lll_l1_ (u"ࠨࠩ㋖"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋗"),l11lll_l1_ (u"ࠪࡣࡊࡍࡎࡠࠩ㋘")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨ㋙")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㋚"),439,l11lll_l1_ (u"࠭ࠧ㋛"),l11lll_l1_ (u"ࠧࠨ㋜"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋝"),l11lll_l1_ (u"ࠩࡢࡊࡍ࠸࡟ࠨ㋞")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪ㋟")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ㋠"),599,l11lll_l1_ (u"ࠬ࠭㋡"),l11lll_l1_ (u"࠭ࠧ㋢"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋣"),l11lll_l1_ (u"ࠨࡡࡈࡆ࠹ࡥࠧ㋤")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠵ࠩ㋥")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ㋦"),809,l11lll_l1_ (u"ࠫࠬ㋧"),l11lll_l1_ (u"ࠬ࠭㋨"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋩"),l11lll_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭㋪")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡัํำࠬ㋫"),l11lll_l1_ (u"ࠩࠪ㋬"),449,l11lll_l1_ (u"ࠪࠫ㋭"),l11lll_l1_ (u"ࠫࠬ㋮"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋯"),l11lll_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬ㋰")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส็ํอๅࠡๅส้ࠬ㋱"),l11lll_l1_ (u"ࠨࠩ㋲"),359,l11lll_l1_ (u"ࠩࠪ㋳"),l11lll_l1_ (u"ࠪࠫ㋴"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋵"),l11lll_l1_ (u"ࠬࡥࡁࡓࡎࡢࠫ㋶")+l1ll1l11ll1_l1_+l11lll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ฻ิฬ๊๊้่ࠥีࠫ㋷"),l11lll_l1_ (u"ࠧࠨ㋸"),209,l11lll_l1_ (u"ࠨࠩ㋹"),l11lll_l1_ (u"ࠩࠪ㋺"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋻"),l11lll_l1_ (u"ࠫࡤࡎࡅࡍࡡࠪ㋼")+l1ll1l11ll1_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ㋽"),l11lll_l1_ (u"࠭ࠧ㋾"),99,l11lll_l1_ (u"ࠧࠨ㋿"),l11lll_l1_ (u"ࠨࠩ㌀"),l111l1l_l1_)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㌁"),l11lll_l1_ (u"ࠪࡣࡘࡌࡗࡠࠩ㌂")+search+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋ำํืࠥ็่า๋ࠢฮู࠭㌃"),l11lll_l1_ (u"ࠬ࠭㌄"),218,l11lll_l1_ (u"࠭ࠧ㌅"),l11lll_l1_ (u"ࠧࠨ㌆"),search) # 219
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㌇"),l11lll_l1_ (u"ࠩࡢࡑ࡛ࡠ࡟ࠨ㌈")+search+l11lll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๋่ࠥโ์ีࠤ้อๆะࠩ㌉"),l11lll_l1_ (u"ࠫࠬ㌊"),188,l11lll_l1_ (u"ࠬ࠭㌋"),l11lll_l1_ (u"࠭ࠧ㌌"),search)# 189
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㌍"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㌎"),l11lll_l1_ (u"ࠩࠪ㌏"),157)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㌐"),l11lll_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㌑")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠧ㌒")+l1ll1l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ㌓"),149,l11lll_l1_ (u"ࠧࠨ㌔"),l11lll_l1_ (u"ࠨࠩ㌕"),l111l1l_l1_)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㌖"),l11lll_l1_ (u"ࠪࡣࡉࡒࡍࡠࠩ㌗")+l1l1ll1l11l_l1_+l11lll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠩ㌘")+l1ll1l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭㌙"),409,l11lll_l1_ (u"࠭ࠧ㌚"),l11lll_l1_ (u"ࠧࠨ㌛"),l111l1l_l1_)
	return
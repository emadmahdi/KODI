# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᓛ")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬᓜ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᓝ"),l11lll_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩᓞ"),l11lll_l1_ (u"ࠩส่ฬ่ำศ็ࠪᓟ"),l11lll_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧᓠ"),l11lll_l1_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨᓡ"),l11lll_l1_ (u"ࠬ࠭ᓢ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l1111l_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l11111_l1_(url,text)
	elif mode==694: results = l1l11l_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᓣ"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨᓤ"),l11lll_l1_ (u"ࠨࠩᓥ"),l11lll_l1_ (u"ࠩࠪᓦ"),l11lll_l1_ (u"ࠪࠫᓧ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᓨ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓩ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᓪ"),l11lll_l1_ (u"ࠧࠨᓫ"),699,l11lll_l1_ (u"ࠨࠩᓬ"),l11lll_l1_ (u"ࠩࠪᓭ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᓮ"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᓯ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓰ"),l11lll_l1_ (u"࠭ࠧᓱ"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓲ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᓳ")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪᓴ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠪࠫᓵ"),l11lll_l1_ (u"ࠫࠬᓶ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᓷ"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓸ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᓹ")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᓺ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠩࠪᓻ"),l11lll_l1_ (u"ࠪࠫᓼ"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᓽ"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓾ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᓿ")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᔀ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠨࠩᔁ"),l11lll_l1_ (u"ࠩࠪᔂ"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᔃ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔄ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᔅ")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᔆ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠧࠨᔇ"),l11lll_l1_ (u"ࠨࠩᔈ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᔉ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔊ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔋ"),l11lll_l1_ (u"ࠬ࠭ᔌ"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔍ"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᔎ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔏ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔐ")+l111ll_l1_+title,link,694)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔑ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔒ"),l11lll_l1_ (u"ࠬ࠭ᔓ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᔔ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᔕ"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠨࠩᔖ"))
	#block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᔗ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		title = title.replace(l11lll_l1_ (u"ࠪࡀࡧࡄࠧᔘ"),l11lll_l1_ (u"ࠫࠬᔙ")).strip(l11lll_l1_ (u"ࠬࠦࠧᔚ"))
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔛ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔜ")+l111ll_l1_+title,link,694)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᔝ"),url,l11lll_l1_ (u"ࠩࠪᔞ"),l11lll_l1_ (u"ࠪࠫᔟ"),l11lll_l1_ (u"ࠫࠬᔠ"),l11lll_l1_ (u"ࠬ࠭ᔡ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᔢ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔣ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᔤ"),l11lll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᔥ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔦ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠫࠬᔧ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᔨ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔩ"),l11lll_l1_ (u"ࠧࠨᔪ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔫ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠬᔬ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔭ"),l111ll_l1_+title,link,691)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔮ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔯ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᔰ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᔱ"),l11lll_l1_ (u"ࠨࠩᔲ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔳ"),l111ll_l1_+title,link,691)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠪࠫᔴ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᔵ"),l11lll_l1_ (u"ࠬ࠭ᔶ"),request,url)
	if request==l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᔷ"):
		url,search = url.split(l11lll_l1_ (u"ࠧࡀࠩᔸ"),1)
		data = l11lll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᔹ")+search
		headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᔺ"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᔻ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩᔼ"),url,data,headers,l11lll_l1_ (u"ࠬ࠭ᔽ"),l11lll_l1_ (u"࠭ࠧᔾ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᔿ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᕀ"),url,l11lll_l1_ (u"ࠩࠪᕁ"),l11lll_l1_ (u"ࠪࠫᕂ"),l11lll_l1_ (u"ࠫࠬᕃ"),l11lll_l1_ (u"ࠬ࠭ᕄ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᕅ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠧࠨᕆ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᕇ"))
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᕈ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᕉ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠫࠬᕊ"),link,title))
	elif request==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᕋ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕌ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᕍ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕎ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᕏ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᕐ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕑ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᕒ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕓ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠧࠨᕔ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕕ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᕖ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪᕗ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩᕘ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫᕙ"),l11lll_l1_ (u"࠭ใๅ์หࠫᕚ"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭ᕛ"),l11lll_l1_ (u"ࠨ้าหๆ࠭ᕜ"),l11lll_l1_ (u"่ࠩฬฬืวสࠩᕝ"),l11lll_l1_ (u"ࠪ฽ึ฼ࠧᕞ"),l11lll_l1_ (u"๊ࠫํัอษ้ࠫᕟ"),l11lll_l1_ (u"ࠬอไษ๊่ࠫᕠ"),l11lll_l1_ (u"࠭ๅิำะ๎ฮ࠭ᕡ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠧ࠰ࠩᕢ"))
		#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᕣ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫᕤ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᕥ"))
		#if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᕦ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧᕧ")+l1llll_l1_.strip(l11lll_l1_ (u"࠭࠯ࠨᕨ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠧࠡࠩᕩ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᕪ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᕫ"),l111ll_l1_+title,link,692,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕬ"):
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᕭ"),l111ll_l1_+title,link,692,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᕮ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕯ"),l111ll_l1_+title,link,693,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᕰ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕱ"),l111ll_l1_+title,link,691,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕲ"),l111ll_l1_+title,link,693,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕳ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕴ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕵ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᕶ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠧࠤࠩᕷ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪᕸ")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫᕹ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕺ"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪᕻ")+title,link,691)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᕼ"),l11lll_l1_ (u"࠭ࠧᕽ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᕾ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᕿ"),url,l11lll_l1_ (u"ࠩࠪᖀ"),l11lll_l1_ (u"ࠪࠫᖁ"),l11lll_l1_ (u"ࠫࠬᖂ"),l11lll_l1_ (u"ࠬ࠭ᖃ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᖄ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᖅ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᖆ"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠩࠪᖇ")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫᖈ"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᖉ"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠬࠩࠧᖊ"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖋ"),l111ll_l1_+title,url,693,l1llll_l1_,l11lll_l1_ (u"ࠧࠨᖌ"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᖍ"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪᖎ"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᖏ")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᖐ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᖑ")+l1ll1_l1_+l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᖒ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᖓ")+l1ll1_l1_+l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᖔ"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᖕ"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᖖ"),l11lll_l1_ (u"ࠫࠬᖗ"),l11lll_l1_ (u"ࠬ࠭ᖘ"),l11lll_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᖙ"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᖚ"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖛ"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"ࠩ࠱࠳ࠬᖜ"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᖝ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᖞ"))
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᖟ"),l11lll_l1_ (u"࠭ࠠࠨᖠ"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᖡ"),l111ll_l1_+title,link,692,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᖢ"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᖣ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᖤ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᖥ"))
		#		addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖦ"),l111ll_l1_+title,link,692,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᖧ"),l11lll_l1_ (u"ࠧ࠰ࡵࡨࡩ࠳ࡶࡨࡱࠩᖨ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᖩ"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪᖪ"),l11lll_l1_ (u"ࠪࠫᖫ"),l11lll_l1_ (u"ࠫࠬᖬ"),l11lll_l1_ (u"ࠬ࠭ᖭ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᖮ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᖯ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ link
		link = re.findall(l11lll_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖰ"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᖱ"))
			l1111_l1_.append(link)
		# l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡰࡰࡦࡰ࡮ࡩ࡫࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᖲ"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭ᖳ"))
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᖴ")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᖵ"))
				l1111_l1_.append(link)
		# download links
		links = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᖶ"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				title = title.strip(l11lll_l1_ (u"ࠨ࡞ࡱࠫᖷ"))
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖸ")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᖹ"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᖺ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖻ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧᖼ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨᖽ"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪᖾ"),l11lll_l1_ (u"ࠩ࠮ࠫᖿ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᗀ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᗁ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩᗂ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᗃ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃࠪ枺")
headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ枻"):l11lll_l1_ (u"ࠬ࠭枼")}
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬ枽")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧๆืสี฾ฯࠠฮำฬࠫ枾"),l11lll_l1_ (u"ࠨࡹࡺࡩࠬ枿")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1111l_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1llllll_l1_(url,text)
	elif mode==564: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ柀")+text)
	elif mode==565: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ柁")+text)
	elif mode==566: results = l1l11l_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ柂"),l11ll1_l1_,l11lll_l1_ (u"ࠬ࠭柃"),l11lll_l1_ (u"࠭ࠧ柄"),False,l11lll_l1_ (u"ࠧࠨ柅"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ柆"))
	#hostname = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ柇")]
	#hostname = hostname.strip(l11lll_l1_ (u"ࠪ࠳ࠬ柈"))
	#l1ll1l1_l1_ = l11ll1_l1_
	#url = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ柉")
	#url = l1ll1l1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ柊"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ柋"),l11lll_l1_ (u"ࠧࠨ柌"),l11lll_l1_ (u"ࠨࠩ柍"),l11lll_l1_ (u"ࠩࠪ柎"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ柏"))
	#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ某"),l111ll_l1_+l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ柑"),l11lll_l1_ (u"࠭ࠧ柒"),8)
	#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ染"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ柔"),l11lll_l1_ (u"ࠩࠪ柕"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ柖"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ柗"),l11ll1_l1_,569,l11lll_l1_ (u"ࠬ࠭柘"),l11lll_l1_ (u"࠭ࠧ柙"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ柚"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ柛"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ柜"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ柝"),564)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ柞"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ柟"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭柠"),565)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ柡"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ柢"),l11lll_l1_ (u"ࠩࠪ柣"),9999)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ柤"):hostname,l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ查"):l11lll_l1_ (u"ࠬ࠭柦")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ柧"),l11lll_l1_ (u"ࠧ࠰ࠩ柨"))
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࡢࡢࡴࠫ࠲࠯ࡅࠩࡧ࡫࡯ࡸࡪࡸࠧ柩"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ柪"),block,re.DOTALL)
	#	for link,title in items:
	#		if l11lll_l1_ (u"ࠪࠩࡩ࠿ࠥ࠹࠷ࠨࡨ࠽ࠫࡢ࠶ࠧࡧ࠼ࠪࡧ࠷ࠦࡦ࠻ࠩࡧ࠷ࠥࡥ࠺ࠨࡦ࠾ࠫࡤ࠹ࠧࡤ࠽࠲ࠫࡤ࠹ࠧࡤࡨࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡢ࠻ࠪ柫") in link: continue
	#		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ柬"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ柭")+l111ll_l1_+title,link,566)
	#	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ柮"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ柯"),l11lll_l1_ (u"ࠨࠩ柰"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭柱"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ柲"),l11lll_l1_ (u"ࠫࠬ柳"),l11lll_l1_ (u"ࠬ࠭柴"),l11lll_l1_ (u"࠭ࠧ柵"),l11lll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ柶"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡷࡑ࡯ࡳࡵࡄࡸࡸࡹࡵ࡮ࠣࠩ柷"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭柸"),block,re.DOTALL)
		for link,title in items:
			#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ柹") not in link:
			#	server = SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ柺"))
			#	link = link.replace(server,l1ll1l1_l1_)
			if title==l11lll_l1_ (u"ࠬ࠭査"): continue
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭柼"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ柽")+l111ll_l1_+title,link,566)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭柾"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ柿"),l11lll_l1_ (u"ࠪࠫ栀"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠫ࠲࠯ࡅࠩࡩࡱࡹࡩࡷࡧࡢ࡭ࡧࠣࡥࡨࡺࡩࡷࡣࡥࡰࡪ࠭栁"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ栂"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭栃"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ栄")+l111ll_l1_+title,link,566,l1llll_l1_)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ栅"),l11lll_l1_ (u"ࠩࠪ栆"),url,l11lll_l1_ (u"ࠪࠫ标"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ栈"):url,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ栉"):l11lll_l1_ (u"࠭ࠧ栊")}
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ栋"),url,l11lll_l1_ (u"ࠨࠩ栌"),l11lll_l1_ (u"ࠩࠪ栍"),l11lll_l1_ (u"ࠪࠫ栎"),l11lll_l1_ (u"ࠫࠬ栏"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ栐"))
	html = response.content
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭树"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ栒"),url,564)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ栓"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ栔"),url,565)
	if l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ栕") in html:
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ栖"),l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭栗"),url,561,l11lll_l1_ (u"࠭ࠧ栘"),l11lll_l1_ (u"ࠧࠨ栙"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ栚"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ栛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭栜"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ栝"),l111ll_l1_+title,link,561)
	return
def l1111l_l1_(l1ll111ll111_l1_,type=l11lll_l1_ (u"ࠬ࠭栞")):
	if l11lll_l1_ (u"࠭࠺࠻ࠩ栟") in l1ll111ll111_l1_:
		l11l1l1_l1_,url = l1ll111ll111_l1_.split(l11lll_l1_ (u"ࠧ࠻࠼ࠪ栠"))
		server = SERVER(l11l1l1_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ校"))
		url = server+url
	else: url,l11l1l1_l1_ = l1ll111ll111_l1_,l1ll111ll111_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ栢"):l11l1l1_l1_,l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ栣"):l11lll_l1_ (u"ࠫࠬ栤")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ栥"),url,l11lll_l1_ (u"࠭ࠧ栦"),l11lll_l1_ (u"ࠧࠨ栧"),l11lll_l1_ (u"ࠨࠩ栨"),l11lll_l1_ (u"ࠩࠪ栩"),l11lll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ株"))
	html = response.content
	if type==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭栫"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠩ栬"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ栭"):
		l1l1ll1_l1_ = [html.replace(l11lll_l1_ (u"ࠧ࡝࡞࠲ࠫ栮"),l11lll_l1_ (u"ࠨ࠱ࠪ栯")).replace(l11lll_l1_ (u"ࠩ࡟ࡠࠧ࠭栰"),l11lll_l1_ (u"ࠪࠦࠬ栱"))]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡌࡸࡩࡥ࠯࠰࡛ࡪࡩࡩ࡮ࡣࡓࡳࡸࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ栲"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡍࡲࡪࡦࡌࡸࡪࡳࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ栳"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if any(value in title.lower() for value in l1l1l1_l1_): continue
			l1llll_l1_ = escapeUNICODE(l1llll_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ栴"),l11lll_l1_ (u"ࠧࠨ栵"))
			if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ栶") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ样"),l111ll_l1_+title,link,563,l1llll_l1_)
			elif l11lll_l1_ (u"ࠪั้่ษࠨ核") in title:
				l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠯า๊โสࠢ࠮ࡠࡩ࠱ࠧ根"),title,re.DOTALL)
				if l1lll11_l1_: title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ栺") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭栻"),l111ll_l1_+title,link,563,l1llll_l1_)
			else:
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭格"),l111ll_l1_+title,link,562,l1llll_l1_)
		if type==l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ栽"):
			l1lll11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡱࡴࡸࡥࡠࡤࡸࡸࡹࡵ࡮ࡠࡲࡤ࡫ࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠧ栾"),block,re.DOTALL)
			if l1lll11ll1l_l1_:
				count = l1lll11ll1l_l1_[0]
				link = url+l11lll_l1_ (u"ࠪ࠳ࡴ࡬ࡦࡴࡧࡷ࠳ࠬ栿")+count
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ桀"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ桁"),link,561,l11lll_l1_ (u"࠭ࠧ桂"),l11lll_l1_ (u"ࠧࠨ桃"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ桄"))
		elif type==l11lll_l1_ (u"ࠩࠪ桅"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ框"),html,re.DOTALL)
			if l1l1ll1_l1_:
				block = l1l1ll1_l1_[0]
				items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ桇"),block,re.DOTALL)
				for link,title in items:
					title = l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ案")+unescapeHTML(title)
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桉"),l111ll_l1_+title,link,561)
	return
def l1llllll_l1_(url,type=l11lll_l1_ (u"ࠧࠨ桊")):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ桋"),l11lll_l1_ (u"ࠩࠪ桌"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ桍"),url,l11lll_l1_ (u"ࠫࠬ桎"),l11lll_l1_ (u"ࠬ࠭桏"),l11lll_l1_ (u"࠭ࠧ桐"),l11lll_l1_ (u"ࠧࠨ桑"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ桒"))
	html = response.content
	html = l111l_l1_(html)
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠡࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࡡ࠭࠲࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠳ࠧ࠭ࠩࠣࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭࠯ࠨࠫࠍࠍ࡮࡬ࠠࠨ็๋ื๊࠭ࠠࡪࡰࠣࡲࡦࡳࡥࠡࡣࡱࡨࠥࡴ࡯ࡵࠢࡷࡽࡵ࡫࠺ࠋࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࠯ࡵࡳࡰ࡮ࡺࠨࠨ็๋ื๊࠭ࠩ࡜࠲ࡠࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ๅีษ๊ำฮ࠭ࠬࠨࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࡨࡰ࡮࡬ࠠࠨฯ็ๆฮ࠭ࠠࡪࡰࠣࡲࡦࡳࡥ࠻ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩะ่็ฯࠧࠪ࡝࠳ࡡࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧๆึส๋ิฯࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠦࠧࠨ桓")
	# l1lllll_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ桔"),html,re.DOTALL)
	if not type and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭桕"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠬࠦ࠭ࠡࠩ桖")+title
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭桗"),l111ll_l1_+title,link,563,l11lll_l1_ (u"ࠧࠨ桘"),l11lll_l1_ (u"ࠨࠩ桙"),l11lll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ桚"))
			return
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࡵࡁࠫ桛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ桜"),block)
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡔࡪࡶ࡯ࡩࡃ࠭桝"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ桞"),str(items))
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ桟"))
			#title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤࠬ桠")+title
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ桡"),l111ll_l1_+title,link,562)
	if not menuItemsLIST:
		title = re.findall(l11lll_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠪ桢"),html,re.DOTALL)
		if title: title = title[0].replace(l11lll_l1_ (u"ࠫࠥ࠳ࠠๆษํࠤุ๐ๅศࠩ档"),l11lll_l1_ (u"ࠬ࠭桤")).replace(l11lll_l1_ (u"࠭ๅีษ๊ำฮࠦࠧ桥"),l11lll_l1_ (u"ࠧࠨ桦"))
		else: title = l11lll_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭桧")
		addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ桨"),l111ll_l1_+title,url,562)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ桩"),url,l11lll_l1_ (u"ࠫࠬ桪"),l11lll_l1_ (u"ࠬ࠭桫"),l11lll_l1_ (u"࠭ࠧ桬"),l11lll_l1_ (u"ࠧࠨ桭"),l11lll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ桮"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ษ็ฮฺ์๊โ࠾࠱࠮ࡄࡂࡡ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ桯"),html,re.DOTALL)
	if l11ll1l_l1_:
		l11ll1l_l1_ = [l11ll1l_l1_[0][0],l11ll1l_l1_[0][1]]
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࡈࡱࡧ࡫ࡤࠣࠩ桰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ桱"),block,re.DOTALL)
		for link,name in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ桲") not in link: link = l11ll1_l1_+link
			if name==l11lll_l1_ (u"࠭ำ๋ำไีࠥ๎๊ࠡีํ้ฬ࠭桳"): name = l11lll_l1_ (u"ࠧࡸࡧࡦ࡭ࡲࡧࠧ桴")
			link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ桵")+name+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ桶")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡹࡴ࠮࠯ࡇࡳࡼࡴ࡬ࡰࡣࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ桷"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ桸"),block,re.DOTALL)
		for link,l11l111l_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ桹") not in link: link = l11ll1_l1_+link
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ桺"),l11l111l_l1_,re.DOTALL)
			if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬ桻")+l11l111l_l1_[0]
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠨࠩ桼")
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡺࡩࡨ࡯࡭ࡢࠩ桽")+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ桾")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ桿"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ梀"),url)
	return
def SEARCH(search,hostname=l11lll_l1_ (u"࠭ࠧ梁")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ梂"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ梃"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ梄"),l11lll_l1_ (u"ࠪ࠯ࠬ梅"))
	l1111_l1_ = [l11lll_l1_ (u"ࠫ࠴࠭梆"),l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ梇"),l11lll_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ梈"),l11lll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ梉"),l11lll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ梊")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"ࠩฦๅ้อๅࠨ梋"),l11lll_l1_ (u"ุ้๊ࠪำๅษอࠫ梌"),l11lll_l1_ (u"ࠫศ์๊ๆ์ࠣ์่ืส้่ࠪ梍"),l11lll_l1_ (u"ࠬฮัศ็ฯࠤฯ๊๊โิํ์๋࠭梎"),l11lll_l1_ (u"࠭ๅิๆึ่ฬะ้ࠠล้๎๊๐ࠧ梏")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไ็๊฼ࠤฬ๊ๅุๆ๋ฬ࠿࠭梐"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11ll1_l1_
		#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ梑"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ梒"),l11lll_l1_ (u"ࠪࠫ梓"),False,l11lll_l1_ (u"ࠫࠬ梔"),l11lll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ梕"))
		#hostname = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ梖")]
		#hostname = response.url
		#hostname = hostname.strip(l11lll_l1_ (u"ࠧ࠰ࠩ梗"))
	l11l11l_l1_ = hostname+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ梘")+search+l1111_l1_[l1l_l1_]
	l1111l_l1_(l11l11l_l1_)
	return
def l1lll1l1_l1_(l1ll111ll111_l1_,filter):
	if l11lll_l1_ (u"ࠩࡂࡃࠬ梙") in l1ll111ll111_l1_: url = l1ll111ll111_l1_.split(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ梚"))[0]
	else: url = l1ll111ll111_l1_
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ梛"):l1ll111ll111_l1_,l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ梜"):l11lll_l1_ (u"࠭ࠧ條")}
	filter = filter.replace(l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ梞"),l11lll_l1_ (u"ࠨࠩ梟"))
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭梠"),1)
	if filter==l11lll_l1_ (u"ࠪࠫ梡"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬ梢"),l11lll_l1_ (u"ࠬ࠭梣")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ梤"))
	if type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ梥"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࡀࠫ梦") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"ࠩࡀࡁࠬ梧") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭梨")+category+l11lll_l1_ (u"ࠫࡂࡃ࠰ࠨ梩")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ梪")+category+l11lll_l1_ (u"࠭࠽࠾࠲ࠪ梫")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪ梬"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ梭")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ梮"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭梯"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ械")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭梱"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ梲"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨ梳"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ梴"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪ梵"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ梶")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll111ll111_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ梷"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ梸"),l1111111_l1_,561,l11lll_l1_ (u"࠭ࠧ梹"),l11lll_l1_ (u"ࠧࠨ梺"),l11lll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ梻"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ梼"),l111ll_l1_+l11lll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ梽")+l11lll11_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ梾"),l1111111_l1_,561,l11lll_l1_ (u"ࠬ࠭梿"),l11lll_l1_ (u"࠭ࠧ检"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ棁"))
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭棂"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ棃"),l11lll_l1_ (u"ࠪࠫ棄"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ棅"),url,l11lll_l1_ (u"ࠬ࠭棆"),l11lll_l1_ (u"࠭ࠧ棇"),l11lll_l1_ (u"ࠧࠨ棈"),l11lll_l1_ (u"ࠨࠩ棉"),l11lll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ棊"))
	html = response.content
	html = html.replace(l11lll_l1_ (u"ࠪࡠࡡࠨࠧ棋"),l11lll_l1_ (u"ࠫࠧ࠭棌")).replace(l11lll_l1_ (u"ࠬࡢ࡜࠰ࠩ棍"),l11lll_l1_ (u"࠭࠯ࠨ棎"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡹࡨࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ棏"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭棐"),block+l11lll_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭棑"),re.DOTALL)
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		name = escapeUNICODE(name)
		if l11lll_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ棒") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭棓"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠬࡃ࠽ࠨ棔") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ棕"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ棖")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_,l1ll111ll111_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]:
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ棗"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠩ棘"),l1111111_l1_,561,l11lll_l1_ (u"ࠪࠫ棙"),l11lll_l1_ (u"ࠫࠬ棚"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭棛"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭棜"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ棝"),l11l11l_l1_,564,l11lll_l1_ (u"ࠨࠩ棞"),l11lll_l1_ (u"ࠩࠪ棟"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ棠"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ棡")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ棢")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ棣")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫ棤")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ棥")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ棦"),l111ll_l1_+name+l11lll_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ棧"),l11l11l_l1_,565,l11lll_l1_ (u"ࠫࠬ棨"),l11lll_l1_ (u"ࠬ࠭棩"),l1l1l11l_l1_+l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ棪"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11lll_l1_ (u"ࠧࡳࠩ棫") or value==l11lll_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ棬"): continue
			if any(value in option.lower() for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ棭") in option: continue
			if l11lll_l1_ (u"ࠪห้้ไࠨ森") in option: continue
			if l11lll_l1_ (u"ࠫࡳ࠳ࡡࠨ棯") in value: continue
			#if value in [l11lll_l1_ (u"ࠬࡸࠧ棰"),l11lll_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ棱"),l11lll_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭棲")]: continue
			#if l1ll1lll_l1_==l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ棳"): option = value
			if option==l11lll_l1_ (u"ࠩࠪ棴"): option = value
			l11ll1l11_l1_ = option
			l1l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ棵"),option,re.DOTALL)
			if l1l11ll11ll_l1_: l11ll1l11_l1_ = l1l11ll11ll_l1_[0]
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠫ࠿ࠦࠧ棶")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠦࠨ棷")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠾ࠩ棸")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠨࠪ棹")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫ棺")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭棻")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ棼"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ棽"),l111ll_l1_+l1lll1lll_l1_,url,565,l11lll_l1_ (u"ࠬ࠭棾"),l11lll_l1_ (u"࠭ࠧ棿"),l1ll1ll1_l1_+l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ椀"))
			elif type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ椁") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"ࠩࡀࡁࠬ椂") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭椃"))
				#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ椄"),l11lll_l1_ (u"ࠬ࠭椅"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ椆")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_,l1ll111ll111_l1_)
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ椇"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,561,l11lll_l1_ (u"ࠨࠩ椈"),l11lll_l1_ (u"ࠩࠪ椉"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ椊"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ椋"),l111ll_l1_+l1lll1lll_l1_,url,564,l11lll_l1_ (u"ࠬ࠭椌"),l11lll_l1_ (u"࠭ࠧ植"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭椎"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ椏"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ椐")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠪࡱࡵࡧࡡࠨ椑"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ椒"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ椓"),l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ椔"),l11lll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ椕"),l11lll_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ椖"),l11lll_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ椗"),l11lll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ椘")]
def l11llllll_l1_(l11l11l_l1_,l11l1l1_l1_):
	if l11lll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ椙") in l11l11l_l1_: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ椚"),l11lll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ椛"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭検"),l11lll_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ椝"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠩࡀࡁࠬ椞"),l11lll_l1_ (u"ࠪ࠳ࠬ椟"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫࠫࠬࠧ椠"),l11lll_l1_ (u"ࠬ࠵ࠧ椡"))
	return l11l11l_l1_
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ椢"),l11lll_l1_ (u"ࠧࠨ椣"),filters,l11lll_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ椤")+mode)
	# mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ椥")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭椦")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࠨ椧")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠬࠬࠦࠨ椨"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"࠭ࠧ椩")
	if l11lll_l1_ (u"ࠧ࠾࠿ࠪ椪") in filters:
		items = filters.split(l11lll_l1_ (u"ࠨࠨࠩࠫ椫"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠩࡀࡁࠬ椬"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠪ࠴ࠬ椭")
		if l11lll_l1_ (u"ࠫࠪ࠭椮") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ椯") and value!=l11lll_l1_ (u"࠭࠰ࠨ椰"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ椱")+value
		elif mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ椲") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ椳"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠫ࠭椴")+key+l11lll_l1_ (u"ࠫࡂࡃࠧ椵")+value
		elif mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ椶"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩ椷")+key+l11lll_l1_ (u"ࠧ࠾࠿ࠪ椸")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ椹"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠩࠪࠬ椺"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ椻"),l11lll_l1_ (u"ࠫࠬ椼"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠬࡕࡕࡕࠩ椽"))
	return l1ll1l1l_l1_
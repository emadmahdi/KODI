# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ༚")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩ༛")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==730: results = MENU()
	elif mode==731: results = l1111l_l1_(url)
	elif mode==732: results = PLAY(url)
	elif mode==733: results = l1llllll_l1_(url)
	elif mode==734: results = l1l1l11l1_l1_(url)
	elif mode==735: results = l1l1l1111_l1_(url)
	elif mode==739: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ༜"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ༝"),l11lll_l1_ (u"࠭ࠧ༞"),739,l11lll_l1_ (u"ࠧࠨ༟"),l11lll_l1_ (u"ࠨࠩ༠"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭༡"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ༢"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ༣"),l11lll_l1_ (u"ࠬ࠭༤"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༥"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ༦")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ༧"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡸࡴࡶ࠮ࡱࡪࡳࠫ༨"),735)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༩"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭༪")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯ࠭༫"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡣࡵࡸࡴࡵ࡮࠯ࡲ࡫ࡴࠬ༬"),734)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ༭"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ༮")+l111ll_l1_+l11lll_l1_ (u"ࠩสๅ้อๅࠨ༯"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠲ࡵ࡮ࡰࠨ༰"),731)
	return
def l1l1l11l1_l1_(url):
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ༱"),l111ll_l1_+l11lll_l1_ (u"ࠬอไไๆࠪ༲"),url,731)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ༳"),url,l11lll_l1_ (u"ࠧࠨ༴"),l11lll_l1_ (u"ࠨ༵ࠩ"),l11lll_l1_ (u"ࠩࠪ༶"),l11lll_l1_ (u"༷ࠪࠫ"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔ࠯ࡖࡉࡗࡏࡅࡔࡡࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ༸"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡲࡡࡣࡧ࡯ࡁࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ༹࠭"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ༺"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ༻")+link
			title = l11lll_l1_ (u"ࠨฯิๅࠥ࠭༼")+title
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ༽"),l111ll_l1_+title,link,731)
	return
def l1l1l1111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ༾"),url,l11lll_l1_ (u"ࠫࠬ༿"),l11lll_l1_ (u"ࠬ࠭ཀ"),l11lll_l1_ (u"࠭ࠧཁ"),l11lll_l1_ (u"ࠧࠨག"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠳ࡓࡆࡔࡌࡉࡘࡥࡆࡆࡃࡗ࡙ࡗࡋࡄ࠮࠴ࡱࡨࠬགྷ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ང"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩཅ"),block,re.DOTALL)
		for title,link,l1llll_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ཆ")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧཇ")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ཈"))
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧཉ"),l111ll_l1_+title,link,733,l1llll_l1_)
	return
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩཊ"),l11lll_l1_ (u"ࠩࠪཋ"),request,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧཌ"),url,l11lll_l1_ (u"ࠫࠬཌྷ"),l11lll_l1_ (u"ࠬ࠭ཎ"),l11lll_l1_ (u"࠭ࠧཏ"),l11lll_l1_ (u"ࠧࠨཐ"),l11lll_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪད"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࡦࡰࡦࡹࡳ࠾ࠩࡰࡳࡻ࡯ࡥࡴࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤདྷ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡴࡼࡩࡦࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡂࠬན"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭པ")+link
		l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧཕ")+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨབ"))
		if l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹ࠮ࡱࡪࡳࠫབྷ") in url: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧམ"),l111ll_l1_+title,link,732,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩཙ"),l111ll_l1_+title,link,733,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫཚ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[-1]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩཛ"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧཛྷ")+link
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨཝ"))
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧཞ"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧཟ")+title,link,731)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪའ"),l11lll_l1_ (u"ࠪࠫཡ"),l11lll_l1_ (u"ࠫࠬར"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩལ"),url,l11lll_l1_ (u"࠭ࠧཤ"),l11lll_l1_ (u"ࠧࠨཥ"),l11lll_l1_ (u"ࠨࠩས"),l11lll_l1_ (u"ࠩࠪཧ"),l11lll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧཨ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࡨࡲࡡࡴࡵࡀࠫࡲࡵࡶࡪࡧࡶࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡴࡥࡵ࡭ࡵࡺࠢཀྵ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳ࡯ࡷ࡫ࡨࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢ࠿ࠩཪ"),block,re.DOTALL)
		for title,link,l1llll_l1_,l1l1l111l_l1_ in items:
			link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨཫ")+link
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩཬ")+l1llll_l1_
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ཭"))
			title = title+l11lll_l1_ (u"ࠩࠣࠫ཮")+l1l1l111l_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬ཯"))
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ཰"),l111ll_l1_+title,link,732,l1llll_l1_)
	return
def PLAY(url):
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱ࠴ࡴࡡࡶࡵ࡬ࡧࡦࡧ࠭࠴࠵࠳࠷࠺࠳࡭ࡰࡸ࡬ࡩࡸ࠳ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨ࠰࡫ࡸࡲࡲཱࠧ")
	l1lllll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖིࠪ"),url,l11lll_l1_ (u"ࠧࠨཱི"),l11lll_l1_ (u"ࠨུࠩ"),l11lll_l1_ (u"ཱུࠩࠪ"),l11lll_l1_ (u"ࠪࠫྲྀ"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫཷ"))
	html = response.content
	# l1l11llll_l1_ link
	links = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪླྀ"),html,re.DOTALL)
	if links:
		link = links[0]
		if l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨཹ") not in link: link = link+l11lll_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ེࠪ")
		l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥཻࠩ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮོࠧ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰཽࠩ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬཾ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭ཿ"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨྀ"),l11lll_l1_ (u"ࠧࠦ࠴࠳ཱྀࠫ"))
	l1111_l1_ = [l11lll_l1_ (u"ࠨࠩྂ"),l11lll_l1_ (u"ࠩࡰࠫྃ")]
	l1l1l11ll_l1_ = [l11lll_l1_ (u"ุ้๊ࠪำๅษอ྄ࠫ"),l11lll_l1_ (u"ࠫฬ็ไศ็ࠪ྅")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ྆"), l1l1l11ll_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	type = l1111_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭࡫ࡹࡩࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ྇")+type+l11lll_l1_ (u"ࠧࠧࡳࡀࠫྈ")+search
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬྉ"),url,l11lll_l1_ (u"ࠩࠪྊ"),l11lll_l1_ (u"ࠪࠫྋ"),l11lll_l1_ (u"ࠫࠬྌ"),l11lll_l1_ (u"ࠬ࠭ྍ"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨྎ"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ྏ"),html,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪྐ")+link
		title = title.strip(l11lll_l1_ (u"ࠩࠣࠫྑ"))
		if type==l11lll_l1_ (u"ࠪࡱࠬྒ"): addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪྒྷ"),l111ll_l1_+title,link,732)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬྔ"),l111ll_l1_+title,link,733)
	return
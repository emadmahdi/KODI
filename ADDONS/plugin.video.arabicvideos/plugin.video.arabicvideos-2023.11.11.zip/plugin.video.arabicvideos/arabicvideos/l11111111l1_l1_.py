# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ屸")
headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ屹") : l11lll_l1_ (u"ࠧࠨ屺") }
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧ屻")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1111l_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1llllll_l1_(url)
	elif mode==214: results = l1lllllll1lll_l1_(url)
	elif mode==215: results = l1llllllll111_l1_(url)
	elif mode==218: results = l11llll1111l_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11llll1111l_l1_():
	message = l11lll_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠥ࠴࠮࠯๋ࠢฬาอฬสࠢส่๎ࠦวฺษาอࠥฮัๆฮฬࠤ๊์ࠠศๆุๅึࠦ࠮࠯࠰ࠣ์ฬ๊ๅษำ่ะࠥำวๅ์สࠤฺฺ๊้ๆࠣ์๏฿ว็์ฺ้๋่ࠣࠦๅฬࠤฺำ๊สࠢ࠱࠲࠳่ࠦๅ้ำหู่ࠥโࠢํฬ็๏ࠠศๆ่์็฿ࠠๆ฼็ๆࠥอไ๊่ࠢหฺࠥวยࠢส่้ํࠧ屼")
	DIALOG_OK(l11lll_l1_ (u"ࠪࠫ屽"),l11lll_l1_ (u"ࠫࠬ屾"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ屿"),l11lll_l1_ (u"࠭วๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠬ岀"),message)
	return
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岁"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ岂"),l11lll_l1_ (u"ࠩࠪ岃"),219,l11lll_l1_ (u"ࠪࠫ岄"),l11lll_l1_ (u"ࠫࠬ岅"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ岆"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岇"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอีࠬ岈"),l11lll_l1_ (u"ࠨࠩ岉"),114,l11ll1_l1_)
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡕ࡯࡮ࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࡲ࡬ࡲࠫࡲࡩ࡮࡫ࡷࡁ࠷࠻ࠧ岊")
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭岌")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭岍"),url,211)
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ岎"),headers,l11lll_l1_ (u"ࠧࠨ岏"),l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ岐"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳࡵࡅࡹࡹࡺ࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ岑"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ岒"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡵࡻࡳࡩࡂࡵ࡮ࡦࠨࡧࡥࡹࡧ࠽ࠨ岓")+link
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岔"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ岕")+l111ll_l1_+title,url,211)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭岖"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ岗"),block,re.DOTALL)
	l1l1l1_l1_ = [l11lll_l1_ (u"่ࠩืู้ไศฬࠣห๋๋๊ࠨ岘"),l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬ岙")]
	#l111ll1l1_l1_ = [l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ࠭岚"),l11lll_l1_ (u"ࠬอแๅษ่ࠤࠬ岛"),l11lll_l1_ (u"࠭ศาษ่ะࠬ岜"),l11lll_l1_ (u"ฺࠧำฺ๋ࠬ岝"),l11lll_l1_ (u"ࠨๅ็๎ออสࠨ岞"),l11lll_l1_ (u"ࠩส฾ฬ์้ࠨ岟")]
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ岠"))
		if not any(value in title for value in l1l1l1_l1_):
		#	if any(value in title for value in l111ll1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岡"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ岢")+l111ll_l1_+title,link,211)
	return html
def l1111l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"࠭ࠧ岣"),headers,l11lll_l1_ (u"ࠧࠨ岤"),l11lll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ岥"))
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ岦"),l11lll_l1_ (u"ࠪࠫ岧"),url,html)
	if l11lll_l1_ (u"ࠫ࡬࡫ࡴࡱࡱࡶࡸࡸ࠭岨") in url or l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩ岩") in url: block = html
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡍࡦࡦ࡬ࡥࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ岪"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		else: return
	items = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ岫"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l11ll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨ岬"),l11lll_l1_ (u"ࠩไ๎้๋ࠧ岭"),l11lll_l1_ (u"ࠪห฿์๊สࠩ岮"),l11lll_l1_ (u"่๊๊ࠫษࠩ岯"),l11lll_l1_ (u"ࠬอูๅษ้ࠫ岰"),l11lll_l1_ (u"࠭็ะษไࠫ岱"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧ岲"),l11lll_l1_ (u"ࠨ฻ิฺࠬ岳"),l11lll_l1_ (u"่๋ࠩึาว็ࠩ岴"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩ岵")]
	for l1llll_l1_,link,title in items:
		if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭岶") in link: continue
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠬ࠵ࠧ岷"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ岸"))
		if l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲ࠵ࠧ岹") in link or any(value in title for value in l11l11ll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ岺"),l111ll_l1_+title,link,212,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ岻") in link and l11lll_l1_ (u"ࠪห้ำไใหࠪ岼") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ岽"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ岾") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岿"),l111ll_l1_+title,link,213,l1llll_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ峀"),l111ll_l1_+title,link,213,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ峁"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ峂"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠪห้฻แฮหࠣࠫ峃"),l11lll_l1_ (u"ࠫࠬ峄"))
			if title!=l11lll_l1_ (u"ࠬ࠭峅"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峆"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭峇")+title,link,211)
	return
def l1llllll_l1_(url):
	l11l1l11l_l1_,items,l111l11l_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠨࠩ峈"),headers,l11lll_l1_ (u"ࠩࠪ峉"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ峊"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ峋"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11_l1_ = l11lll_l1_ (u"ࠬ࠭峌").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ峍"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ峎"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ峏"))
		title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ峐") + link.split(l11lll_l1_ (u"ࠪ࠳ࠬ峑"))[-1].replace(l11lll_l1_ (u"ࠫ࠲࠭峒"),l11lll_l1_ (u"ࠬࠦࠧ峓"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬ峔"),link.split(l11lll_l1_ (u"ࠧ࠰ࠩ峕"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠨ࠲ࠪ峖")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11lll_l1_ = str(items).count(l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ峗"))
	l11l1l11l_l1_ = str(items).count(l11lll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭峘"))
	if l11l11lll_l1_>1 and l11l1l11l_l1_>0 and l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭峙") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ峚") in link: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭峛"),l111ll_l1_+title,link,213)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ峜") not in link: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ峝"),l111ll_l1_+title,link,212)
	return
def PLAY(url):
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠩ࠲ࠫ峞"))
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠪࠫ峟"),headers,l11lll_l1_ (u"ࠫࠬ峠"),l11lll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭峡"))
	# l11ll1l1l_l1_ links
	if l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ峢") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠭峣"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ峤"),headers,l11lll_l1_ (u"ࠩࠪ峥"),l11lll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ峦"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡫ࡲࡷࡧࡵࡷ࠲ࡲࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ峧"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡦࡴࡹࡩࡷࡥࡩ࡮ࡣࡪࡩࠧࡄ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ峨"),block,re.DOTALL)
			if items:
				id = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ峩"),l11lll1l_l1_,re.DOTALL)
				if id:
					l11lll11ll_l1_ = id[0]
					for link,title in items:
						link = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡳࡳࡸࡺࡩࡥ࠿ࠪ峪")+l11lll11ll_l1_+l11lll_l1_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ峫")+link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ峬")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ峭")
						l1111_l1_.append(link)
			else:
				# https://l1llllllll11l_l1_.tv/l11ll1l1l_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠪࠥࢀࠫࡷࡵࡰࡶ࠾࠭ࠬ峮"),block,re.DOTALL)
				for link,dummy in items:
					l1111_l1_.append(link)
	# download links
	if l11lll_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ峯") in html:
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ峰"))
		l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ峱"),headers,l11lll_l1_ (u"ࠨࠩ峲"),l11lll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ峳"))
		id = re.findall(l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡊࡦ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ峴"),l11lll1l_l1_,re.DOTALL)
		if id:
			l11lll11ll_l1_ = id[0]
			l1l1ll1ll_l1_ = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ峵"):l11lll_l1_ (u"ࠬ࠭島") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ峷"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ峸") }
			l11l11l_l1_ = l11ll1_l1_ + l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ峹")+l11lll11ll_l1_
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ峺"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ峻"),l11lll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ峼"))
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃ࠭ࡢࡤࠬࠫࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ峽"),l11lll1l_l1_,re.DOTALL)
			if l1l1ll1_l1_:
				for resolution,block in l1l1ll1_l1_:
					items = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ峾"),block,re.DOTALL)
					for name,link in items:
						l1111_l1_.append(link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ峿")+name+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ崀")+l11lll_l1_ (u"ࠩࡢࡣࡤࡥࠧ崁")+resolution)
			else:
				l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࡭࠼ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭崂"),l11lll1l_l1_,re.DOTALL)
				if not l1l1ll1_l1_: l1l1ll1_l1_ = [l11lll1l_l1_]
				for block in l1l1ll1_l1_:
					l11lll_l1_ (u"ࠦࠧࠨࠊࠊࠋࠌࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡷࡪࡸࡶࡦࡴࡶࡘ࡮ࡺ࡬ࡦ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࠏࠉࡪࡨࠣࡲࡦࡳࡥ࠻ࠌࠌࠍࠎࠏࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪࡡ࠭࠲࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬอไะไฬࠤࠬ࠲ࠧࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡰࡤࡱࡪࠧ࠽ࠨࠩ࠽ࠤࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦࠢ࠮ࠤࠬࠦเࠡࠩࠍࠍࠎࠏࠉࠊࡧ࡯ࡷࡪࡀࠠ࡯ࡣࡰࡩࠥࡃࠠࠨࠩࠍࠍࠎࠏࠉࠊࠤࠥࠦ崃")
					name = l11lll_l1_ (u"ࠬ࠭崄")
					items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ崅"),block,re.DOTALL)
					for link in items:
						server = l11lll_l1_ (u"ࠧࠧࠨࠪ崆") + link.split(l11lll_l1_ (u"ࠨ࠱ࠪ崇"))[2].lower() + l11lll_l1_ (u"ࠩࠩࠪࠬ崈")
						server = server.replace(l11lll_l1_ (u"ࠪ࠲ࡨࡵ࡭ࠧࠨࠪ崉"),l11lll_l1_ (u"ࠫࠬ崊")).replace(l11lll_l1_ (u"ࠬ࠴ࡣࡰࠨࠩࠫ崋"),l11lll_l1_ (u"࠭ࠧ崌"))
						server = server.replace(l11lll_l1_ (u"ࠧ࠯ࡰࡨࡸࠫࠬࠧ崍"),l11lll_l1_ (u"ࠨࠩ崎")).replace(l11lll_l1_ (u"ࠩ࠱ࡳࡷ࡭ࠦࠧࠩ崏"),l11lll_l1_ (u"ࠪࠫ崐"))
						server = server.replace(l11lll_l1_ (u"ࠫ࠳ࡲࡩࡷࡧࠩࠪࠬ崑"),l11lll_l1_ (u"ࠬ࠭崒")).replace(l11lll_l1_ (u"࠭࠮ࡰࡰ࡯࡭ࡳ࡫ࠦࠧࠩ崓"),l11lll_l1_ (u"ࠧࠨ崔"))
						server = server.replace(l11lll_l1_ (u"ࠨࠨࠩ࡬ࡩ࠴ࠧ崕"),l11lll_l1_ (u"ࠩࠪ崖")).replace(l11lll_l1_ (u"ࠪࠪࠫࡽࡷࡸ࠰ࠪ崗"),l11lll_l1_ (u"ࠫࠬ崘"))
						server = server.replace(l11lll_l1_ (u"ࠬࠬࠦࠨ崙"),l11lll_l1_ (u"࠭ࠧ崚"))
						link = link + l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ崛") + name + server + l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ崜")
						l1111_l1_.append(link)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ崝"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ崞"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ崟"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ崠"),l11lll_l1_ (u"࠭ࠫࠨ崡"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ崢")+search
	l1111l_l1_(url)
	return
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡶࡩࡦࡸࡣࡩࠢࡶࡩࡨࡵ࡮ࡥࡣࡵࡽ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤ࠱ࡨࡧࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨ࡮ࡥࡤ࡭ࡰࡥࡷࡱ࠭ࡣࡱ࡯ࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࡨࡧࡴࡦࡩࡲࡶࡾࡒࡉࡔࡖ࠯ࡪ࡮ࡲࡴࡦࡴࡏࡍࡘ࡚ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝ࠋࠋࠌࡪࡴࡸࠠࡤࡣࡷࡩ࡬ࡵࡲࡺ࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡣࡢࡶࡨ࡫ࡴࡸࡹࠪࠌࠌࠍࠎ࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪหำะัࠡษ็ๅ้ะัࠡษ็้๋อำษ࠼ࠪ࠰ࠥ࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࡃࠠ࠮࠳ࠣ࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࠉࡤࡣࡷࡩ࡬ࡵࡲࡺࠢࡀࠤࡨࡧࡴࡦࡩࡲࡶࡾࡒࡉࡔࡖ࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠋࡸࡶࡱࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤ࠰ࠦࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫ࠰ࡹࡥࡢࡴࡦ࡬࠰࠭ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ࠯ࡨࡧࡴࡦࡩࡲࡶࡾࠐࠉࠊࡖࡌࡘࡑࡋࡓࠩࡷࡵࡰ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠊࠤࠥࠦ崣")
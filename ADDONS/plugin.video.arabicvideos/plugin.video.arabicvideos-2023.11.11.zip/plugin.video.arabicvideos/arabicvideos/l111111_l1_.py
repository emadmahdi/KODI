# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨଗ") : l11lll_l1_ (u"ࠬ࠭ଘ") }
script_name = l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬଙ")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡃࡎ࡛ࡤ࠭ଚ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#l11llll_l1_ = [l11lll_l1_ (u"ࠨใํ่๊࠭ଛ"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧଜ"),l11lll_l1_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫଝ"),l11lll_l1_ (u"ู๊ࠫัฮ์ฬࠫଞ"),l11lll_l1_ (u"๋ࠬำาฯํ๋ࠬଟ"),l11lll_l1_ (u"࠭ว฻่ํอࠬଠ"),l11lll_l1_ (u"ࠧศ฻็ห๋࠭ଡ"),l11lll_l1_ (u"ࠨๆๅหฦ࠭ଢ")]
#proxy = l11lll_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱࠴࠹࠾࠴࠲࠱࠵࠱࠼࠼࠴࠱࠴࠲࠽࠷࠶࠸࠸ࠨଣ")
#proxy = l11lll_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪତ")+l11ll11l_l1_[6][1]
proxy = l11lll_l1_ (u"ࠫࠬଥ")
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬษไฺษหࠫଦ"),l11lll_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧଧ"),l11lll_l1_ (u"ࠧศๆๅีฬ์ࠠศๆๆี๏๋ࠧନ"),l11lll_l1_ (u"ࠨษ็็ฯฮ้ࠠࠢส่ฬฮอศอࠪ଩"),l11lll_l1_ (u"ࠩสฺ่๎ั๊ࠡࠣห้ิไโ์สฮࠬପ"),l11lll_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅษำห฾๐ษࠨଫ")]
def MAIN(mode,url,text):
	if   mode==240: results = MENU()
	elif mode==241: results = l1111l_l1_(url,text)
	elif mode==242: results = l1llllll_l1_(url)
	elif mode==243: results = PLAY(url)
	elif mode==244: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨବ")+text)
	elif mode==245: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬଭ")+text)
	elif mode==246: results = l1ll111l_l1_(url)
	elif mode==247: results = l11ll111_l1_(url)
	elif mode==248: results = l11l11ll_l1_()
	elif mode==249: results = SEARCH(text)
	else: results = False
	return results
def l11l11ll_l1_():
	DIALOG_OK(l11lll_l1_ (u"࠭ࠧମ"),l11lll_l1_ (u"ࠧࠨଯ"),l11lll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫର"),l11lll_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦࠢฤๅ๋ห๊ࠦวๅฮา๎ิࠨࠠโ์ࠣฬ฾฼ࠠศๆฦั๏อๆࠡใํ๋ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฻ีࠠศๆหีฬ๋ฬࠡ࠰ࠣ์์ึวࠡ์ึฬอࠦๅีๅ็อࠥ็๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่่ษอࠤ࠳ࠦ็ั้ࠣห้๋ิไๆฬࠤุฮศ่ษ้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏่่ࠦ์ࠣฮ฽ํั๊ࠡอาฯ็๊ࠡสุ์ึฯฺࠠึ๋หห๐ษࠨ଱"))
	return
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧଲ"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬଳ"),headers,l11lll_l1_ (u"ࠬ࠭଴"),l11lll_l1_ (u"࠭ࠧଵ"),l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨଶ"))
	html = response.content
	l11l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡲࡱࡪ࠳ࡳࡪࡶࡨ࠱ࡧࡺ࡮࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬଷ"),html,re.DOTALL)
	if l11l1l1l_l1_: l11l1l1l_l1_ = l11l1l1l_l1_[0]
	else: l11l1l1l_l1_ = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ସ"),l11l1l1l_l1_,l11lll_l1_ (u"ࠪࠫହ"),headers,l11lll_l1_ (u"ࠫࠬ଺"),l11lll_l1_ (u"ࠬ࠭଻"),l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪ଼ࠧ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧଽ"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨା"),l11lll_l1_ (u"ࠩࠪି"),249,l11lll_l1_ (u"ࠪࠫୀ"),l11lll_l1_ (u"ࠫࠬୁ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩୂ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ୃ"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪୄ"),l11ll1_l1_,246)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୅"),l111ll_l1_+l11lll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ୆"),l11ll1_l1_,247)
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨେ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫୈ"),l11lll_l1_ (u"ࠬ࠭୉"),9999)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୊"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩୋ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩୌ"),l11l1l1l_l1_,241,l11lll_l1_ (u"୍ࠩࠪ"),l11lll_l1_ (u"ࠪࠫ୎"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭୏"))
	l11l1111_l1_ = re.findall(l11lll_l1_ (u"ࠬࡸࡥࡤࡧࡱࡸࡱࡿ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୐"),html,re.DOTALL)
	link = l11l1111_l1_[0]
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୑"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ୒")+l111ll_l1_+l11lll_l1_ (u"ࠨลู๎ๆࠦอะ์ฮหࠬ୓"),link,241)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ୔"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ୕"),l11lll_l1_ (u"ࠫࠬୖ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡢ࠮࠶ࠣࡨ࠲࡬࡬ࡦࡺࠣࡥࡱ࡯ࡧ࡯࠯࡬ࡸࡪࡳࡳ࠮ࡥࡨࡲࡹ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥࡧࡵ࠱ࡱ࡯࡮࡬ࠢࡷࡩࡽࡺ࠭ࡸࡪ࡬ࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬୗ"),html,re.DOTALL)
	for link,name,block in l1l1ll1_l1_:
		if name in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭୘"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ୙")+l111ll_l1_+name,link,241)
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ୚"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			title = name+l11lll_l1_ (u"ࠩࠣࠫ୛")+title
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪଡ଼"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ଢ଼")+l111ll_l1_+title,link,241)
	return
def l1ll111l_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠬ࠭୞")):
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"࠭ࠧୟ"),headers,l11lll_l1_ (u"ࠧࠨୠ"),l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩୡ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩୢ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪୣ"),block,re.DOTALL)
		for link,title in items:
			if title not in l1l1l1_l1_:
				title = title+l11lll_l1_ (u"๋ࠫࠥี็ใฬࠫ୤")
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୥"),l111ll_l1_+title,link,245)
		if l1l1ll11_l1_==l11lll_l1_ (u"࠭ࠧ୦"): addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ୧"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ୨"),l11lll_l1_ (u"ࠩࠪ୩"),9999)
	return html
def l11ll111_l1_(l1l1ll11_l1_=l11lll_l1_ (u"ࠪࠫ୪")):
	html = OPENURL_CACHED(l11111l_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ୫"),headers,l11lll_l1_ (u"ࠬ࠭୬"),l11lll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ୭"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧ୮"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ୯"),block,re.DOTALL)
		for link,title in items:
			if title not in l1l1l1_l1_:
				title = title+l11lll_l1_ (u"้ࠩࠣๆ๊สาหࠪ୰")
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪୱ"),l111ll_l1_+title,link,244)
		if l1l1ll11_l1_==l11lll_l1_ (u"ࠫࠬ୲"): addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ୳"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୴"),l11lll_l1_ (u"ࠧࠨ୵"),9999)
	return html
def l1111l_l1_(url,type=l11lll_l1_ (u"ࠨࠩ୶")):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ୷"),l11lll_l1_ (u"ࠪࠫ୸"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠫࠬ୹"),headers,True,l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ୺"))
	if type==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ୻"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡹ࡬ࡴࡪࡸ࠭ࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠫ࠲࠯ࡅࠩࡴࡹ࡬ࡴࡪࡸ࠭ࡣࡷࡷࡸࡴࡴ࠭ࡱࡴࡨࡺࠬ୼"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱࡫ࡵ࡯ࡵࡧࡵࠫ୽"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶࡨࡼࡹ࠳ࡷࡩ࡫ࡷࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭୾"),block,re.DOTALL)
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ୿"),block,re.DOTALL)
		for l1llll_l1_,link,title in items:
			#if l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭஀") in l1llll_l1_: l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠩ஁"))[1]
			if l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨஂ") in link or l11lll_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡼࡹ࠯ࠨஃ") in link:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஄"),l111ll_l1_+title,link,242,l1llll_l1_)
			elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲ࠫஅ") in link:
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩஆ"),l111ll_l1_+title,link,243,l1llll_l1_)
			elif l11lll_l1_ (u"ࠫ࠴࡭ࡡ࡮ࡧࡶ࠳ࠬஇ") not in link:
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫஈ"),l111ll_l1_+title,link,243,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧஉ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩஊ"),block,re.DOTALL)
		for link,title in items:
			if title==l11lll_l1_ (u"ࠨࠨ࡯ࡷࡦࡷࡵࡰ࠽ࠪ஋"): title = l11lll_l1_ (u"ࠩึหอ่ษࠨ஌")
			if title==l11lll_l1_ (u"ࠪࠪࡷࡹࡡࡲࡷࡲ࠿ࠬ஍"): title = l11lll_l1_ (u"้ࠫออใหࠪஎ")
			link = unescapeHTML(link)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬஏ"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬஐ")+title,link,241)
	return
def SEARCH(search):
	# https://l11ll1l1_l1_.net/search?q=%l11ll1ll_l1_%l1l1lll1_l1_%l11ll1ll_l1_%l1ll1l11_l1_%l11ll1ll_l1_%l1l1l1l1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ஑"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩஒ"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠩࠣࠫஓ"),l11lll_l1_ (u"ࠪࠩ࠷࠶ࠧஔ"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨக")+l111l1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭஖"),l11lll_l1_ (u"࠭ࠧ஗"),url,l11lll_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎ࡟ࡂࡍࡒࡅࡒ࠭஘"))
	results = l1111l_l1_(url)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩங"),l11lll_l1_ (u"ࠩࠪச"),url,l11lll_l1_ (u"ࠪࡉࡕࡏࡓࡐࡆࡈࡗࡤࡇࡋࡘࡃࡐࠫ஛"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠫࠬஜ"),headers,True,l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ஝"))
	if l11lll_l1_ (u"࠭࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࡁࠫஞ") not in html:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧட"))
		addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ஠"),l111ll_l1_+l11lll_l1_ (u"ࠩิหอ฽ࠠศๆอุ฿๐ไࠨ஡"),url,243,l1llll_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࠱ࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶ࠰࠸ࠬ஢"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪண"),block,re.DOTALL)
		for link,title,l1llll_l1_ in l1l1l_l1_:
			#if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧத") in link: continue
			if l11lll_l1_ (u"࠭วๅฯ็ๆฬะࠧ஥") in title or l11lll_l1_ (u"ࠧๆ๊สื๊ࠦวฯำ์ࠫ஦") in title: continue
			if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ஧") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩந"),l111ll_l1_+title,link,242,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩன"),l111ll_l1_+title,link,243,l1llll_l1_)
	return
def PLAY(url):
	#l11l11ll_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝ࡧࡰࡥࡩ࠴ࡨࡵ࡯࡯ࠫப"), l11lll_l1_ (u"ࠬࡽࠧ஫")).write(html)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧ஬"),headers,True,l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ஭"))
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡤࡤࡨ࡬࡫࠭ࡥࡣࡱ࡫ࡪࡸ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪம"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l11l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫய"),html,re.DOTALL)
	#l11l1l11_l1_ = ([l11lll_l1_ (u"ࠪࠫர"),l11lll_l1_ (u"ࠫࠬற")],[l11lll_l1_ (u"ࠬ࠭ல"),l11lll_l1_ (u"࠭ࠧள")])
	l1111_l1_,l1lll1ll_l1_,l111l11_l1_,l11l1lll_l1_ = [],[],[],[]
	if l11l1l11_l1_:
		l1l1111_l1_ = l11lll_l1_ (u"ࠧ࡮ࡲ࠷ࠫழ")
		for l11l1ll1_l1_,l11l111l_l1_ in l11l1l11_l1_:
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠦࡱࡶࡣ࡯࡭ࡹࡿࠢࠡ࡫ࡧࡁࠧ࠭வ")+l11l1ll1_l1_+l11lll_l1_ (u"ࠩࠥ࠲࠯ࡅ࠼࠰ࡦ࡬ࡺࡃ࠴࡜ࡴࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩஶ"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			l111l11_l1_.append(block)
			l11l1lll_l1_.append(l11l111l_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡵࡺࡧ࡬ࡪࡶ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪஷ"),html,re.DOTALL)
		if not l1l1ll1_l1_:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬஸ"),l11lll_l1_ (u"ࠬ࠭ஹ"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ஺"),l11lll_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็็ๅࠥ็๊ะ์๋ࠤๆ๐่ࠠาสࠤฬ๊ัศสฺࠫ஻"))
			return
		else:
			block,filename = l1l1ll1_l1_[0]
			l11l111_l1_ = [l11lll_l1_ (u"ࠨࡼ࡬ࡴࠬ஼"),l11lll_l1_ (u"ࠩࡵࡥࡷ࠭஽"),l11lll_l1_ (u"ࠪࡸࡽࡺࠧா"),l11lll_l1_ (u"ࠫࡵࡪࡦࠨி"),l11lll_l1_ (u"ࠬ࡮ࡴ࡮ࠩீ"),l11lll_l1_ (u"࠭ࡴࡢࡴࠪு"),l11lll_l1_ (u"ࠧࡪࡵࡲࠫூ"),l11lll_l1_ (u"ࠨࡪࡷࡱࡱ࠭௃")]
			l1l1111_l1_ = filename.rsplit(l11lll_l1_ (u"ࠩ࠱ࠫ௄"),1)[1].strip(l11lll_l1_ (u"ࠪࠤࠬ௅"))
			if l1l1111_l1_ in l11l111_l1_:
				DIALOG_OK(l11lll_l1_ (u"ࠫࠬெ"),l11lll_l1_ (u"ࠬ࠭ே"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩை"),l11lll_l1_ (u"ࠧศๆ่่ๆࠦไ๋ีࠣๅ๏ี๊้๋่ࠢฬࠦี้ฬࠪ௉"))
				return
		l111l11_l1_.append(block)
		l11l1lll_l1_.append(l11lll_l1_ (u"ࠨࠩொ"))
	for i in range(len(l111l11_l1_)):
		links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡨࡵ࡮࠮ࠪ࠱࠮ࡄ࠯ࠢࠨோ"),l111l11_l1_[i],re.DOTALL)
		for link,l11l11l1_l1_ in links:
			if l11lll_l1_ (u"ࠪࡸࡴࡸࡲࡦࡰࡷࠫௌ") in l11l11l1_l1_: continue
			#elif l11lll_l1_ (u"ࠫࡵࡲࡡࡺ்ࠩ") in l11l11l1_l1_: continue
			elif l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௎") in l11l11l1_l1_: type = l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏")
			elif l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࠬௐ") in l11l11l1_l1_: type = l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧ௑")
			else: type = l11lll_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ௒")
			#title = l11l1lll_l1_[i]+l11lll_l1_ (u"ࠪࠤ๊๊แࠡࠩ௓")+type
			#l1lll1ll_l1_.append(title)
			link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࠧ௔")+type+l11lll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ௕")+l11l1lll_l1_[i]+l11lll_l1_ (u"࠭࡟ࡠࡣ࡮ࡻࡦࡳࠧ௖")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧࡕࡇࡖࡘࠬௗ"),l1lll1ll_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨࡖࡈࡗ࡙࠭௘"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ௙"),url)
	return
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ௚"),l11lll_l1_ (u"ࠫࠬ௛"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭௜"),l11lll_l1_ (u"࠭ࠧ௝"),filter,url)
	l1l11lll_l1_ = [l11lll_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࠨ௞"),l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ௟"),l11lll_l1_ (u"ࠩࡼࡩࡦࡸࠧ௠"),l11lll_l1_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ௡")]
	if l11lll_l1_ (u"ࠫࡄ࠭௢") in url: url = url.split(l11lll_l1_ (u"ࠬࡅࠧ௣"))[0]
	type,filter = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ௤"),1)
	if filter==l11lll_l1_ (u"ࠧࠨ௥"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠨࠩ௦"),l11lll_l1_ (u"ࠩࠪ௧")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧ௨"))
	if type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ௩"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠬࡃࠧ௪") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"࠭࠽ࠨ௫") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩ௬")+category+l11lll_l1_ (u"ࠨ࠿࠳ࠫ௭")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫ௮")+category+l11lll_l1_ (u"ࠪࡁ࠵࠭௯")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠫࠫ࠭௰"))+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ௱")+l1l1llll_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨ௲"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧࡢ࡮࡯ࠫ௳"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠨࡁࠪ௴")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ௵"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ௶"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠫࠬ௷"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ௸"))
		if l1l11l11_l1_==l11lll_l1_ (u"࠭ࠧ௹"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠧࡀࠩ௺")+l1l11l11_l1_
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௻"),l111ll_l1_+l11lll_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠫ௼"),l11l11l_l1_,241,l11lll_l1_ (u"ࠪࠫ௽"),l11lll_l1_ (u"ࠫ࠶࠭௾"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ௿"),l111ll_l1_+l11lll_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ఀ")+l11lll11_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ఁ"),l11l11l_l1_,241,l11lll_l1_ (u"ࠨࠩం"),l11lll_l1_ (u"ࠩ࠴ࠫః"))
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨఄ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫఅ"),l11lll_l1_ (u"ࠬ࠭ఆ"),9999)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧఇ"),headers,True,l11lll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩఈ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡩࡳࡷࡳࠠࡪࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡩࡳࡷࡳ࠾ࠨఉ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶ࠱࠮ࡄࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨఊ"),block,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫఋ"),l11lll_l1_ (u"ࠫࠬఌ"),l11lll_l1_ (u"ࠬ࠭఍"),str(l1lll11l_l1_))
	dict = {}
	for l1ll1lll_l1_,name,block in l1lll11l_l1_:
		#name = name.replace(l11lll_l1_ (u"࠭࠭࠮ࠩఎ"),l11lll_l1_ (u"ࠧࠨఏ"))
		items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡲࡴࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧఐ"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠩࡀࠫ఑") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧఒ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫఓ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬఔ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾࠭క"),l11l11l_l1_,241,l11lll_l1_ (u"ࠧࠨఖ"),l11lll_l1_ (u"ࠨ࠳ࠪగ"))
				else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩఘ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠪఙ"),l11l11l_l1_,245,l11lll_l1_ (u"ࠫࠬచ"),l11lll_l1_ (u"ࠬ࠭ఛ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧజ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩఝ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿࠳ࠫఞ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫట")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁ࠵࠭ఠ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨడ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬఢ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠡࠩణ")+name,l11l11l_l1_,244,l11lll_l1_ (u"ࠧࠨత"),l11lll_l1_ (u"ࠨࠩథ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫద"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩధ") not in value: value = option
			else: value = re.findall(l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬన"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ఩")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨప")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩఫ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪబ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭భ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠪࠤ࠿ࠦࠧమ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠫ࠵࠭య")]
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠡࠩర")+name
			if type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧఱ"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧల"),l111ll_l1_+title,url,244,l11lll_l1_ (u"ࠨࠩళ"),l11lll_l1_ (u"ࠩࠪఴ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬవ"))
			elif type==l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨశ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠬࡃࠧష") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"࠭ࡡ࡭࡮ࠪస"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠧࡀࠩహ")+l1l1111l_l1_
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ఺"),l111ll_l1_+title,l11l1l1_l1_,241,l11lll_l1_ (u"ࠩࠪ఻"),l11lll_l1_ (u"ࠪ࠵఼ࠬ"))
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఽ"),l111ll_l1_+title,url,245,l11lll_l1_ (u"ࠬ࠭ా"),l11lll_l1_ (u"࠭ࠧి"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨీ"),l11lll_l1_ (u"ࠨࠩు"),filters,l11lll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪూ"))
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬృ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧౄ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ౅")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	#filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩె"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫే"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪై"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫ౉") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬొ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭ో"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭ౌ")
	l1ll11ll_l1_ = [l11lll_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ్ࠧ"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ౎"),l11lll_l1_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ౏"),l11lll_l1_ (u"ࠩࡼࡩࡦࡸࠧ౐"),l11lll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ౑"),l11lll_l1_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ౒"),l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭౓")]
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ౔")
		#if l11lll_l1_ (u"ౕࠧࠦࠩ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵౖࠪ") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ౗"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧౘ")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧౙ") and value!=l11lll_l1_ (u"ࠬ࠶ࠧౚ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ౛")+key+l11lll_l1_ (u"ࠧ࠾ࠩ౜")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬౝ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ౞")+key+l11lll_l1_ (u"ࠪࡁࠬ౟")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨౠ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧౡ"))
	#l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩౢ"),l11lll_l1_ (u"ࠧ࠾ࠩౣ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ౤"),l11lll_l1_ (u"ࠩࠪ౥"),filters,l11lll_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫ౦"))
	return l1ll1l1l_l1_
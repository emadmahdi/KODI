# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧᅔ")
headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᅕ") : l11lll_l1_ (u"ࠧࠨᅖ") }
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡄࡖࡑࡥࠧᅗ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩᅘ"),l11lll_l1_ (u"ࠪห้้ไࠨᅙ"),l11lll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᅚ"),l11lll_l1_ (u"ࠬอไฺษหࠫᅛ"),l11lll_l1_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࠭ᅜ"),l11lll_l1_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧᅝ"),l11lll_l1_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩᅞ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l1111l_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l1llllll_l1_(url)
	elif mode==204: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ᅟ")+text)
	elif mode==205: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪᅠ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅡ"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᅢ"),l11lll_l1_ (u"࠭ࠧᅣ"),209,l11lll_l1_ (u"ࠧࠨᅤ"),l11lll_l1_ (u"ࠨࠩᅥ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᅦ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅧ"),l111ll_l1_+l11lll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧᅨ"),l11ll1_l1_,205)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅩ"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩᅪ"),l11ll1_l1_,204)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᅫ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᅬ"),l11lll_l1_ (u"ࠩࠪᅭ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅮ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᅯ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬๅ๋ิฬࠫᅰ"),l11ll1_l1_+l11lll_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࠪᅱ"),201)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅲ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᅳ")+l111ll_l1_+l11lll_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧᅴ"),l11ll1_l1_+l11lll_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᅵ"),201)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅶ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᅷ")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᅸ"),l11ll1_l1_+l11lll_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫᅹ"),201)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅺ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᅻ")+l111ll_l1_+l11lll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᅼ"),l11ll1_l1_+l11lll_l1_ (u"ࠫࡄࡅ࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨᅽ"),201)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᅾ"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧᅿ"),headers,True,l11lll_l1_ (u"ࠧࠨᆀ"),l11lll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᆁ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡴࡢࡤࡶࠬ࠳࠰࠿ࠪࡏࡤ࡭ࡳࡘ࡯ࡸࠩᆂ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆃ"),block,re.DOTALL)
		for filter,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡬ࡴࡳࡥ࠰࡯ࡲࡶࡪࡅࡦࡪ࡮ࡷࡩࡷࡃࠧᆄ")+filter
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆅ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆆ")+l111ll_l1_+title,link,201)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᆇ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᆈ"),l11lll_l1_ (u"ࠩࠪᆉ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᆊ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᆋ"),block,re.DOTALL)
	#l111ll1l1_l1_ = [l11lll_l1_ (u"๋ࠬำๅี็หฯࠦࠧᆌ"),l11lll_l1_ (u"࠭วโๆส้ࠥ࠭ᆍ"),l11lll_l1_ (u"ࠧษำส้ั࠭ᆎ"),l11lll_l1_ (u"ࠨ฻ิ์฻࠭ᆏ"),l11lll_l1_ (u"ࠩๆ่๏ฮวหࠩᆐ"),l11lll_l1_ (u"ࠪห฿อๆ๊ࠩᆑ")]
	for link,title in items:
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᆒ") not in link: link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᆓ"))
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆔ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆕ")+l111ll_l1_+title,link,201)
	return html
def l1111l_l1_(url):
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡧࡱࡵࠤࡕࡕࡓࡕࠢࡩ࡭ࡱࡺࡥࡳ࠼ࠍࠍ࡮࡬ࠠࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬࠦࡩ࡯ࠢࡸࡶࡱࡀࠊࠊࠋࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨࡁࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࠰ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠳࠮ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠭ࠏࠏࠉࡥࡣࡷࡥ࠷ࠦ࠽ࠡࡽࠪࡪࡴࡸ࡭ࠨ࠼ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠰ࠬࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥ࠿ࠪ࠾ࠬ࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳ࠯ࡥࡲࡴࡾ࠮ࠩࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡣࠠ࠾ࠢࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬࡣࠠ࠾ࠢࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩࡠࠤࡂࠦࠧࡈ࡜࠷ࡓࡩ࠶࡮࡫ࡖࡆࡥࡌࡽࡣࡈࡳ࠷ࡍࡿࡍࡱࡉࡇࡵ࡝࠵ࡻ࡚ࡰࡣࡘ࡜࡟ࡉ࠶ࡉࡧ࡛ࡼࡽ࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡻࡦࡸࡢ࡭࡫ࡲࡲࡿࡺࡶࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࡨࡽࡏࡶࡤࡪࡋ࠹ࡍࡲࡘ࠰ࡎ࡚ࡑࡎ࡞ࡲࡒࡍࡓ࡭ࡨࡦࡔࡄ࡬ࡺ࡙ࡲࡩࡍ࡚࠲ࡄ࠵࡝ࡱࡋ࠹ࡑࡕࡌࡷࡎࡴ࡚ࡩࡤࡋ࡚ࡱࡏࡪࡰ࡫ࡔࡘࡗࡘࡖ࡙ࡏ࠴࡙࡯ࡲࡇࡣࡈࡉࡶࡦ࡛ࡆ࡬ࡑࡈࡼࡊࡕࡕࡗࡓ࡜࡙࠹࠷ࡤ࠲ࡐ࡚ࡩࡍࡩࡷࡦࡰࡐࡽ࡛࡝ࡒࡇࡓࡰࡰ࠷࡛ࡘࡊ࠲ࡧ࡯ࡽࡲ࡚࠲ࡄࡱࡥ࠸ࡶࡘࡔ࠳ࡅ࡛ࡧ࡚ࡁ࠴ࡕࡰࡒ࡯ࡪࡆࡥ࠵࡚ࡇࡎࡹࡉ࡮࠳࡫࡝ࡾࡏ࠶ࡊ࡬ࡘࡼ࡟࡚ࡧࡺࡐࡰࡑࡾࡕࡇࡆࡻࡐ࡮ࡎ࠶ࡎࡅࡐ࡯࡞࡯࡮࡬ࡏ࠴ࡑ࡯࡟࡚ࡂ࡮ࡐ࡭ࡨࡲ࡟ࡺࡂ࠲ࡑ࡮ࡆࡽࡍࡕࡌ࡮ࡑࡿࡠࡪࡐࡆࡌࡾࡓ࡚࡙ࡺࡏࡽ࡯࠵ࡔࡄࡤ࠷ࡐࡘࡇࡰࡎࡘࡋࡼࡓ࡙ࡲࡪࡏ࡬ࡪ࡭࡫ࡗ࠽࠾ࠩࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠴࠯ࡨࡦࡺࡡ࠳࠮࡫ࡩࡦࡪࡥࡳࡵ࠵࠰࡙ࡸࡵࡦ࠮ࠪࠫ࠱࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠨ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠤࠥࠦᆖ")
	if l11lll_l1_ (u"ࠩࡂࡃࠬᆗ") in url: url,type = url.split(l11lll_l1_ (u"ࠪࡃࡄ࠭ᆘ"))
	else: type = l11lll_l1_ (u"ࠫࠬᆙ")
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᆚ"),l11lll_l1_ (u"࠭ࠧᆛ"),url,type)
	#if url==l11ll1_l1_: url = url+l11lll_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᆜ")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᆝ"),l11lll_l1_ (u"ࠩࠪᆞ"),url,l11lll_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪᆟ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᆠ"),url,l11lll_l1_ (u"ࠬ࠭ᆡ"),headers,True,l11lll_l1_ (u"࠭ࠧᆢ"),l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᆣ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᆤ"))
	#WRITE_THIS(html)
	if l11lll_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫᆥ") in url: l1l1ll1_l1_ = [html]
	elif type==l11lll_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬᆦ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ᆧ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᆨ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᆩ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩᆪ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᆫ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᆬ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩᆭ"),html,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬᆮ"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᆯ"),l11lll_l1_ (u"࠭ࠧᆰ"),l11lll_l1_ (u"ࠧࠨᆱ"),str(l1l1ll1_l1_))
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆲ"),block,re.DOTALL)
	l11l11ll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩᆳ"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨᆴ"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪᆵ"),l11lll_l1_ (u"้ࠬไ๋สࠪᆶ"),l11lll_l1_ (u"࠭วฺๆส๊ࠬᆷ"),l11lll_l1_ (u"่ࠧัสๅࠬᆸ"),l11lll_l1_ (u"ࠨ็หหึอษࠨᆹ"),l11lll_l1_ (u"ࠩ฼ี฻࠭ᆺ"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪᆻ"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪᆼ")]
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᆽ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᆾ"),l11lll_l1_ (u"ࠧࠨᆿ"),9999)
	items = re.findall(l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᇀ"),block,re.DOTALL)
	if not items:
		items = re.findall(l11lll_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᇁ"),block,re.DOTALL)
		links,l1l1l1lll_l1_,l1l111_l1_ = zip(*items)
		items = zip(l1l1l1lll_l1_,links,l1l111_l1_)
	l1l1_l1_ = []
	for l1llll_l1_,link,title in items:
		#link = escapeUNICODE(link)
		#link = QUOTE(link)
		if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᇂ") in link: continue
		link = link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᇃ"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᇄ"))
		if l11lll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭ᇅ") in link or any(value in title for value in l11l11ll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᇆ"),l111ll_l1_+title,link,202,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᇇ") in link and l11lll_l1_ (u"ࠩส่า๊โสࠩᇈ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᇉ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᇊ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇋ"),l111ll_l1_+title,link,203,l1llll_l1_)
					l1l1_l1_.append(title)
		elif l11lll_l1_ (u"࠭࠯ࡱࡣࡦ࡯࠴࠭ᇌ") in link:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇍ"),l111ll_l1_+title,link+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᇎ"),201,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇏ"),l111ll_l1_+title,link,203,l1llll_l1_)
	if type in [l11lll_l1_ (u"ࠪࠫᇐ"),l11lll_l1_ (u"ࠫࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᇑ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᇒ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇓ"),block,re.DOTALL)
			for link,title in items:
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				title = title.replace(l11lll_l1_ (u"ࠧศๆุๅาฯࠠࠨᇔ"),l11lll_l1_ (u"ࠨࠩᇕ"))
				if l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᇖ") in url:
					l111ll111_l1_ = link.split(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇗ"))[1]
					l11l1111l_l1_ = url.split(l11lll_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᇘ"))[1]
					link = url.replace(l11lll_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᇙ")+l11l1111l_l1_,l11lll_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬᇚ")+l111ll111_l1_)
				if title!=l11lll_l1_ (u"ࠧࠨᇛ"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇜ"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨᇝ")+title,link,201)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᇞ"),l11lll_l1_ (u"ࠫࠬᇟ"),url,l11lll_l1_ (u"ࠬ࠭ᇠ"))
	l11l1l11l_l1_,items,l111l11l_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᇡ"),url,l11lll_l1_ (u"ࠧࠨᇢ"),headers,True,l11lll_l1_ (u"ࠨࠩᇣ"),l11lll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᇤ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᇥ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᇦ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l111l11l_l1_ = []
		l111l11_l1_ = l11lll_l1_ (u"ࠬ࠭ᇧ").join(l1l1ll1_l1_)
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᇨ"),l111l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨᇩ"))
	for link in items:
		link = link.strip(l11lll_l1_ (u"ࠨ࠱ࠪᇪ"))
		title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᇫ") + link.split(l11lll_l1_ (u"ࠪ࠳ࠬᇬ"))[-1].replace(l11lll_l1_ (u"ࠫ࠲࠭ᇭ"),l11lll_l1_ (u"ࠬࠦࠧᇮ"))
		l111ll1l_l1_ = re.findall(l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬᇯ"),link.split(l11lll_l1_ (u"ࠧ࠰ࠩᇰ"))[-1],re.DOTALL)
		if l111ll1l_l1_: l111ll1l_l1_ = l111ll1l_l1_[0]
		else: l111ll1l_l1_ = l11lll_l1_ (u"ࠨ࠲ࠪᇱ")
		l111l11l_l1_.append([link,title,l111ll1l_l1_])
	items = sorted(l111l11l_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l11lll_l1_ = str(items).count(l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᇲ"))
	l11l1l11l_l1_ = str(items).count(l11lll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᇳ"))
	if l11l11lll_l1_>1 and l11l1l11l_l1_>0 and l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᇴ") not in url:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᇵ") in link:
				#link = QUOTE(link)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇶ"),l111ll_l1_+title,link,203)
	else:
		for link,title,l111ll1l_l1_ in items:
			if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩᇷ") not in link:
				#if l11lll_l1_ (u"ࠨࠧࠪᇸ") not in link: link = QUOTE(link)
				#else: link = QUOTE(l111l_l1_(link))
				#link = l111l_l1_(link)
				title = l111l_l1_(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᇹ"),l111ll_l1_+title,link,202)
	return
def PLAY(url):
	#LOG_THIS(l11lll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᇺ"),l11lll_l1_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭ᇻ"))
	l1111_l1_ = []
	parts = url.split(l11lll_l1_ (u"ࠬ࠵ࠧᇼ"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧᇽ"),l11lll_l1_ (u"ࠧࠨᇾ"),url,l11lll_l1_ (u"ࠨࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᇿ"))
	#url = l111l_l1_(QUOTE(url))
	hostname = l11ll1_l1_
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ሀ"),url,l11lll_l1_ (u"ࠪࠫሁ"),headers,True,True,l11lll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨሂ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪሃ"))
	id = re.findall(l11lll_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧሄ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨህ"),html,re.DOTALL)
	if not id: id = re.findall(l11lll_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪሆ"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l11lll_l1_ (u"ࠩࠪሇ"),l11lll_l1_ (u"ࠪࠫለ"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሉ"),l11lll_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩሊ"))
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ላ"),l11lll_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠶࠷࠱ࠨሌ"))
	if l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩል") in html:
		#parts = url.split(l11lll_l1_ (u"ࠩ࠲ࠫሎ"))
		l11l11l_l1_ = url.replace(parts[3],l11lll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩሏ"))
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨሐ"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭ሑ"),headers,True,True,l11lll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪሒ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬሓ"))
		l111l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሔ"),l11lll1l_l1_,re.DOTALL)
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪሕ"),l11lll1l_l1_,re.DOTALL)
		l111l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧሖ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬሗ"),l11lll1l_l1_)
		l111l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭መ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		l11l11111_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨሙ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		items = l111l1ll1_l1_+l1l1lll_l1_+l111l1lll_l1_+l111l1l11_l1_+l111l11ll_l1_+l11l11111_l1_
		#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧሚ"),l11lll_l1_ (u"ࠨࡇࡐࡅࡉࠦࡓࡕࡃࡕࡘ࡚ࠥࡉࡎࡋࡑࡋࠥ࠺࠴࠵ࠩማ"))
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሜ"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l11lll_l1_ (u"ࠪ࠲ࡵࡴࡧࠨም") in server: continue
			if l11lll_l1_ (u"ࠫ࠳ࡰࡰࡨࠩሞ") in server: continue
			if l11lll_l1_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬሟ") in server: continue
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧሠ"),title,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11l111l_l1_[0]
				if l11l111l_l1_ in title: title = title.replace(l11l111l_l1_+l11lll_l1_ (u"ࠧࡱࠩሡ"),l11lll_l1_ (u"ࠨࠩሢ")).replace(l11l111l_l1_,l11lll_l1_ (u"ࠩࠪሣ")).strip(l11lll_l1_ (u"ࠪࠤࠬሤ"))
				l11l111l_l1_ = l11lll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩሥ")+l11l111l_l1_
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭ሦ")
			#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሧ"),l11lll_l1_ (u"ࠧ࡜ࠩረ")+str(id)+l11lll_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ሩ")+str(hostname)+l11lll_l1_ (u"ࠩࡠࠤࠥࡡࠧሪ")+str(title)+l11lll_l1_ (u"ࠪࡡ࡛ࠥࠦࠨራ")+str(l11l111l_l1_)+l11lll_l1_ (u"ࠫࡢ࠭ሬ"))
			if server.isdigit():
				link = hostname+l11lll_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨር")+id+l11lll_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪሮ")+server+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨሯ")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩሰ")+l11l111l_l1_
			else:
				if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧሱ") not in server: server = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩሲ")+server
				l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬሳ"),title,re.DOTALL)
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪሴ")+l11l111l_l1_[0]
				else: l11l111l_l1_ = l11lll_l1_ (u"࠭ࠧስ")
				link = server+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨሶ")+l11l111l_l1_
			l1111_l1_.append(link)
	#LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨሷ"),l11lll_l1_ (u"ࠩ࡞ࠫሸ")+l11l111l_l1_+l11lll_l1_ (u"ࠪࡡࠥࠦࠠࠡ࡝ࠪሹ")+title+l11lll_l1_ (u"ࠫࡢ࠭ሺ"))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪሻ"), l1111_l1_)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧሼ"),l11lll_l1_ (u"ࠧࠨሽ"),l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠠ࠲ࠩሾ"),	str(len(items)))
	if l11lll_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧሿ") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩቀ"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫቁ") }
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨቂ")
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪቃ"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨቄ"),l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠨࠩቅ"),l11lll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ቆ"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨቇ"))
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬቈ"),l11lll_l1_ (u"ࠬ࠭቉"),l11l11l_l1_,l11lll1l_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧቊ"),l11lll1l_l1_,re.DOTALL)
		for block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩቋ"),block,re.DOTALL)
			for link,name,l11l111l_l1_ in items:
				link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩቌ")+name+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ቍ")+l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ቎")+l11l111l_l1_
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ቏") in html:
		l1l1ll1ll_l1_ = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩቐ"):l11lll_l1_ (u"࠭ࠧቑ") , l11lll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪቒ"):l11lll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩቓ") }
		l11l11l_l1_ = hostname + l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬቔ")+id
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧቕ"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬቖ"),l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ቗"))
		l11lll1l_l1_ = response.content#.encode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫቘ"))
		if l11lll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧ቙") in l11lll1l_l1_:
			l111l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧቚ"),l11lll1l_l1_,re.DOTALL)
			for l11l1l1_l1_ in l111l1lll_l1_:
				if l11lll_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩቛ") not in l11l1l1_l1_ and l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨቜ") in l11l1l1_l1_:
					l11l1l1_l1_ = l11l1l1_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨቝ")
					l1111_l1_.append(l11l1l1_l1_)
				elif l11lll_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ቞") in l11l1l1_l1_:
					l11l111l_l1_ = l11lll_l1_ (u"࠭ࠧ቟")
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫበ"),l11l1l1_l1_,l11lll_l1_ (u"ࠨࠩቡ"),headers,True,True,l11lll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ቢ"))
					l111ll1ll_l1_ = response.content#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨባ"))
					l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭ࡂࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࠬ࠱࠲࠳࠭࠮ࠩቤ"),l111ll1ll_l1_,re.DOTALL)
					for l11l1l111_l1_ in l111l11_l1_:
						l111lll1l_l1_ = l11lll_l1_ (u"ࠬ࠭ብ")
						l111l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨቦ"),l11l1l111_l1_,re.DOTALL)
						for l11l111l1_l1_ in l111l1l11_l1_:
							item = re.findall(l11lll_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨቧ"),l11l111l1_l1_,re.DOTALL)
							if item:
								l11l111l_l1_ = l11lll_l1_ (u"ࠨࡡࡢࡣࡤ࠭ቨ")+item[0]
								break
						for l11l111l1_l1_ in reversed(l111l1l11_l1_):
							item = re.findall(l11lll_l1_ (u"ࠩ࡟ࡻࡡࡽࠫࠨቩ"),l11l111l1_l1_,re.DOTALL)
							if item:
								l111lll1l_l1_ = item[0]
								break
						l111l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩቪ"),l11l1l111_l1_,re.DOTALL)
						for l111lllll_l1_ in l111l11ll_l1_:
							l111lllll_l1_ = l111lllll_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬቫ")+l111lll1l_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩቬ")+l11l111l_l1_
							l1111_l1_.append(l111lllll_l1_)
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧቭ"),l11lll_l1_ (u"ࠧࠨቮ"),l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬቯ"),	str(len(l1111_l1_))	)
		elif l11lll_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧተ") in l11lll1l_l1_:
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"ࠪࡀ࡭࠼ࠠࠨቱ"),l11lll_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨቲ"))+l11lll_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ታ")
			l11lll1l_l1_ = l11lll1l_l1_.replace(l11lll_l1_ (u"࠭࠼ࡩ࠵ࠣࠫቴ"),l11lll_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫት"))+l11lll_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩቶ")
			#LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩቷ"),l11lll1l_l1_)
			#open(l11lll_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪቸ"),l11lll_l1_ (u"ࠫࡼ࠭ቹ")).write(l11lll1l_l1_)
			l111l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ቺ"),l11lll1l_l1_,re.DOTALL)
			if l111l1l1l_l1_:
				for l11l1l111_l1_ in l111l1l1l_l1_:
					if l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬቻ") not in l11l1l111_l1_: continue
					#DIALOG_OK(l11lll_l1_ (u"ࠧࠨቼ"),l11lll_l1_ (u"ࠨࠩች"),l11lll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࠶࠷࠱ࠨቾ"),	l11l1l111_l1_	)
					l11l111ll_l1_ = l11lll_l1_ (u"ࠪࠫቿ")
					l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኀ"),l11l1l111_l1_,re.DOTALL)
					for l11l111l1_l1_ in l111l1l11_l1_:
						item = re.findall(l11lll_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ኁ"),l11l111l1_l1_,re.DOTALL)
						if item:
							l11l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡠࡡࡢࠫኂ")+item[0]
							break
					l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ኃ"),l11l1l111_l1_,re.DOTALL)
					if l111l1l11_l1_:
						for l111lll1l_l1_,l111llll1_l1_ in l111l1l11_l1_:
							l111llll1_l1_ = l111llll1_l1_+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩኄ")+l111lll1l_l1_+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ኅ")+l11l111ll_l1_
							l1111_l1_.append(l111llll1_l1_)
					else:
						l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኆ"),l11l1l111_l1_,re.DOTALL)
						for l111llll1_l1_,l111lll1l_l1_ in l111l1l11_l1_:
							l111llll1_l1_ = l111llll1_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠭ኇ"))+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ኈ")+l111lll1l_l1_+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ኉")+l11l111ll_l1_
							l1111_l1_.append(l111llll1_l1_)
			else:
				l111l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫࡠࡼ࠱ࠩ࠽ࠩኊ"),l11lll1l_l1_,re.DOTALL)
				for l111llll1_l1_,l111lll1l_l1_ in l111l1l11_l1_:
					l111llll1_l1_ = l111llll1_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪኋ"))+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪኌ")+l111lll1l_l1_+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧኍ")
					l1111_l1_.append(l111llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ኎"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ኏"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧነ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨኑ"): return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪኒ"),l11lll_l1_ (u"ࠩ࠮ࠫና"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧኔ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩን"),l11lll_l1_ (u"ࠬ࠭ኖ"),headers,True,l11lll_l1_ (u"࠭ࠧኗ"),l11lll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ኘ"))
	html = response.content#.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ኙ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧኚ"),html,re.DOTALL)
	if l1ll_l1_ and l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ኛ"),block,re.DOTALL)
		l11l11l11_l1_,l111lll11_l1_ = [],[]
		for category,title in items:
			#if title in [l11lll_l1_ (u"ࠫึ๐วืหࠣ์๋ࠥีศำ฼๋ࠬኜ")]: continue
			l11l11l11_l1_.append(category)
			l111lll11_l1_.append(title)
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬኝ"), l111lll11_l1_)
		if l1l_l1_ == -1 : return
		category = l11l11l11_l1_[l1l_l1_]
	else: category = l11lll_l1_ (u"࠭ࠧኞ")
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫኟ")+search+l11lll_l1_ (u"ࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬአ")+category+l11lll_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾࠳ࠪኡ")
	l1111l_l1_(url)
	return
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬኢ"),l11lll_l1_ (u"ࠫࠬኣ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ኤ"),l11lll_l1_ (u"࠭ࠧእ"),filter,url)
	# for l111ll11l_l1_ filter:		l1l11lll_l1_ = [l11lll_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪኦ"),l11lll_l1_ (u"ࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧኧ"),l11lll_l1_ (u"ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩከ"),l11lll_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬኩ")]
	l1l11lll_l1_ = [l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ኪ"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫካ"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬኬ"),l11lll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨክ")]
	if l11lll_l1_ (u"ࠨࡁࠪኮ") in url: url = url.split(l11lll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ኯ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠪࡣࡤࡥࠧኰ"),1)
	if filter==l11lll_l1_ (u"ࠫࠬ኱"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠬ࠭ኲ"),l11lll_l1_ (u"࠭ࠧኳ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫኴ"))
	if type==l11lll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬኵ"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠩࡀࠫ኶") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠪࡁࠬ኷") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫ࠭ኸ")+category+l11lll_l1_ (u"ࠬࡃ࠰ࠨኹ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠨኺ")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪኻ")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪኼ"))+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ኽ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬኾ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ኿"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩዀ")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ዁"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩዂ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠨࠩዃ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬዄ"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠪࠫዅ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ዆")+l1l11l11_l1_
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ዇"),l111ll_l1_+l11lll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩወ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዉ"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨዊ")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨዋ"),l11l11l_l1_,201)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨዌ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫው"),l11lll_l1_ (u"ࠬ࠭ዎ"),9999)
	html = OPENURL_CACHED(l11111l_l1_,url+l11lll_l1_ (u"࠭࠯ࡢ࡮ࡽࠫዏ"),l11lll_l1_ (u"ࠧࠨዐ"),headers,l11lll_l1_ (u"ࠨࠩዑ"),l11lll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧዒ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨዓ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# for l111ll11l_l1_ filter:		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪዔ"),block,re.DOTALL)
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡩࡳࡷ࡚ࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫዕ"),block,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧዖ"),l11lll_l1_ (u"ࠧࠨ዗"),l11lll_l1_ (u"ࠨࠩዘ"),str(l1lll11l_l1_))
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#name = name.replace(l11lll_l1_ (u"ࠩ࠰࠱ࠬዙ"),l11lll_l1_ (u"ࠪࠫዚ"))
		name = name.replace(l11lll_l1_ (u"ࠫฬิส๋ษิࠤࠬዛ"),l11lll_l1_ (u"ࠬ࠭ዜ"))
		name = name.replace(l11lll_l1_ (u"࠭ำ็หࠣห้หๆหษฯࠫዝ"),l11lll_l1_ (u"ࠧศๆึ๊ฮ࠭ዞ"))
		items = re.findall(l11lll_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩዟ"),block,re.DOTALL)
		if l11lll_l1_ (u"ࠩࡀࠫዠ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧዡ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫዢ")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዣ"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧዤ"),l11l11l_l1_,201)
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዥ"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩዦ"),l11l11l_l1_,205,l11lll_l1_ (u"ࠩࠪዧ"),l11lll_l1_ (u"ࠪࠫየ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬዩ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧዪ")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩያ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩዬ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿࠳ࠫይ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭ዮ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዯ"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ደ")+name,l11l11l_l1_,204,l11lll_l1_ (u"ࠬ࠭ዱ"),l11lll_l1_ (u"࠭ࠧዲ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩዳ"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			option = option.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫዴ"),l11lll_l1_ (u"ࠩࠪድ"))
			if option in l1l1l1_l1_: continue
			#if option==l11lll_l1_ (u"ࠪห้้ไࠨዶ"): continue
			#option = l11lll_l1_ (u"ࠫࡠ࠭ዷ")+option+l11lll_l1_ (u"ࠬࡣࠧዸ")
			#if l11lll_l1_ (u"࠭วๅๅ็ࠫዹ") in option: DIALOG_OK(l11lll_l1_ (u"ࠧࠨዺ"),l11lll_l1_ (u"ࠨࠩዻ"),l11lll_l1_ (u"ࠩࠪዼ"),l11lll_l1_ (u"ࠪ࡟ࠬዽ")+str(option)+l11lll_l1_ (u"ࠫࡢ࠭ዾ"))
			#if l11lll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫዿ") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧጀ"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩጁ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪጂ")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠩࠩࠫጃ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬጄ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨጅ")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨጆ")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"࠭࠰ࠨጇ")]
			title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪገ")+name
			if type==l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩጉ"): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩጊ"),l111ll_l1_+title,url,204,l11lll_l1_ (u"ࠪࠫጋ"),l11lll_l1_ (u"ࠫࠬጌ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧግ"))
			elif type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪጎ") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠧ࠾ࠩጏ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫጐ"))
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭጑")+l1l1111l_l1_
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጒ"),l111ll_l1_+title,l11l1l1_l1_,201)
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጓ"),l111ll_l1_+title,url,205,l11lll_l1_ (u"ࠬ࠭ጔ"),l11lll_l1_ (u"࠭ࠧጕ"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ጖"),l11lll_l1_ (u"ࠨࠩ጗"),filters,l11lll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪጘ"))
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬጙ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧጚ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩጛ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩጜ"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫጝ"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪጞ"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫጟ") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬጠ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭ጡ"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭ጢ")
	# for l111ll11l_l1_ filter:		l1ll11ll_l1_ = [l11lll_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩጣ"),l11lll_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ጤ"),l11lll_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጥ"),l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫጦ")]
	l1ll11ll_l1_ = [l11lll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬጧ"),l11lll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪጨ"),l11lll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫጩ"),l11lll_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧጪ")]
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠧ࠱ࠩጫ")
		if l11lll_l1_ (u"ࠨࠧࠪጬ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫጭ") and value!=l11lll_l1_ (u"ࠪ࠴ࠬጮ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨጯ")+value
		elif mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨጰ") and value!=l11lll_l1_ (u"࠭࠰ࠨጱ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠧࠩጲ")+key+l11lll_l1_ (u"ࠨ࠿ࠪጳ")+value
		elif mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭ጴ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬጵ")+key+l11lll_l1_ (u"ࠫࡂ࠭ጶ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠦࠫࠡࠩጷ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠦࠨጸ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠧ࠾࠲ࠪጹ"),l11lll_l1_ (u"ࠨ࠿ࠪጺ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪጻ"),l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫጼ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬጽ"),l11lll_l1_ (u"ࠬ࠭ጾ"),filters,l11lll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧጿ"))
	return l1ll1l1l_l1_
l11lll_l1_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨፀ")
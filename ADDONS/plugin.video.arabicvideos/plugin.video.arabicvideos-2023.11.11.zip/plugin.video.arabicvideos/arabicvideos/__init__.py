# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from l11l1lll11l_l1_ import *
script_name = l11lll_l1_ (u"ࠫࡎࡔࡉࡕࠩ牺")
LOG_THIS(l11lll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ牻"),l11lll_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠫ牼"))
l1l1l1ll111_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1l11l1_l1_,text,context,l1ll111l111_l1_ = l1l1l1ll111_l1_
l1l1ll111111_l1_ = int(mode)
l1ll111llll1_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ牽"))
l1ll111llll1_l1_ = l1ll111llll1_l1_.replace(ltr,l11lll_l1_ (u"ࠨࠩ牾")).replace(rtl,l11lll_l1_ (u"ࠩࠪ牿"))
if l1l1ll111111_l1_==260: message = l11lll_l1_ (u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ犀")+l11ll111111_l1_+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫ犁")+l11lll11l1l_l1_+l11lll_l1_ (u"ࠬࠦ࡝ࠨ犂")
else:
	l1ll1ll1ll1l1_l1_ = l111l_l1_(addon_path).replace(l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ犃"),l11lll_l1_ (u"ࠧࠨ犄")).replace(l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ犅"),l11lll_l1_ (u"ࠩࠪ犆"))
	l1ll1ll1ll1l1_l1_ = l1ll1ll1ll1l1_l1_.replace(l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ犇"),l11lll_l1_ (u"ࠫࠬ犈")).strip(l11lll_l1_ (u"ࠬࠦࠧ犉"))
	l1ll1ll1ll1l1_l1_ = l1ll1ll1ll1l1_l1_.replace(l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ犊"),l11lll_l1_ (u"ࠧࠡࠩ犋")).replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠬ犌"),l11lll_l1_ (u"ࠩࠣࠫ犍")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭犎"),l11lll_l1_ (u"ࠫࠥ࠭犏"))
	message = l11lll_l1_ (u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ犐")+l1ll111llll1_l1_+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭犑")+mode+l11lll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ犒")+l1ll1ll1ll1l1_l1_+l11lll_l1_ (u"ࠨࠢࡠࠫ犓")
LOG_THIS(l11lll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ犔"),LOGGING(script_name)+message)
l1l1l1l1ll11_l1_ = settings.getSetting(l11lll_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ犕"))
l1llll11l1ll_l1_ = False if l1l1l1l1ll11_l1_==l11ll111111_l1_ else True
if not l1llll11l1ll_l1_ and l1l1ll111111_l1_ in [235,715]:
	l11ll1l1llll_l1_ = str(l1ll111l111_l1_[l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ犖")])
	script_name = l11lll_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ犗") if l1l1ll111111_l1_==235 else l11lll_l1_ (u"࠭࡭࠴ࡷࠪ犘")
	l111lll1l1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠧࡢࡸ࠱ࠫ犙")+script_name+l11lll_l1_ (u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭犚")+l11ll1l1llll_l1_)
	l11l111ll1_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭犛")+script_name+l11lll_l1_ (u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭犜")+l11ll1l1llll_l1_)
	if l111lll1l1_l1_ or l11l111ll1_l1_:
		url += l11lll_l1_ (u"ࠫࢁ࠭犝")
		if l111lll1l1_l1_: url += l11lll_l1_ (u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ犞")+l111lll1l1_l1_
		if l11l111ll1_l1_: url += l11lll_l1_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ犟")+l11l111ll1_l1_
		url = url.replace(l11lll_l1_ (u"ࠧࡽࠨࠪ犠"),l11lll_l1_ (u"ࠨࡾࠪ犡"))
	l1111l11ll_l1_ = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳࠭犢")+script_name+l11lll_l1_ (u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ犣")+l11ll1l1llll_l1_)
	if l1111l11ll_l1_:
		l1ll1ll1ll1ll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ犤"),url,re.DOTALL)
		url = url.replace(l1ll1ll1ll1ll_l1_[0],l1111l11ll_l1_)
	script_name = script_name.upper()
	l11llll1l11_l1_(url,script_name,type)
else:
	from LIBSTWO import *
	l1lll1lll1ll_l1_ = l11lll_l1_ (u"ࠬ࠭犥")
	l1ll11l11_l1_(l11lll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ犦"))
	try: l1lll1111l1l_l1_(l1l1l1ll111_l1_,l1ll111llll1_l1_)
	except Exception as error: l1lll1lll1ll_l1_ = traceback.format_exc()
	l1ll11l11_l1_(l11lll_l1_ (u"ࠧࡴࡶࡲࡴࠬ犧"))
	l1l1ll1l1l11_l1_(l1lll1lll1ll_l1_)
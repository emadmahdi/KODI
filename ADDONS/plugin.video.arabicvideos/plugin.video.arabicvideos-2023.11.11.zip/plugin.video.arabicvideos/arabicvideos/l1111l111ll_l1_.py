# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ伊")
headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ伋"):l11lll_l1_ (u"࠭ࠧ伌")}
script_name = l11lll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭伍")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ伎")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11lll_l1_ (u"ࠩ࠶ࠫ伏"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11lll_l1_ (u"ࠪ࠵ࠬ伐"))
	elif mode==36: results = CATEGORIES(url,l11lll_l1_ (u"ࠫ࠷࠭休"))
	elif mode==37: results = CATEGORIES(url,l11lll_l1_ (u"ࠬ࠺ࠧ伒"))
	elif mode==38: results = l1l1lll1l_l1_()
	elif mode==39: results = SEARCH(text,l1l11l1_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭伓"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ伔"),l11lll_l1_ (u"ࠨࠩ伕"),39,l11lll_l1_ (u"ࠩࠪ伖"),l11lll_l1_ (u"ࠪࠫ众"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ优"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ伙"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭会"),l11lll_l1_ (u"ࠧࠨ伛"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭伜"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ伝")+l111ll_l1_+l11lll_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ伞"),l11lll_l1_ (u"ࠫࠬ伟"),38)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ传"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ伡")+l111ll_l1_+l11lll_l1_ (u"ࠧๆี็ื้อส๊ࠡหีฬ๋ฬࠨ伢"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭伣"),31)
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ伤"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ伥")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆส็ะืࠠๆึส๋ิฯࠧ伦"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ伧"),37)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭伨"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ伩")+l111ll_l1_+l11lll_l1_ (u"ࠨษไ่ฬ๋ࠠฮีหࠤฬ๊ๆ้฻ࠪ伪"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ伫"),35)
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ伬"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭伭")+l111ll_l1_+l11lll_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็้๊ัไࠨ伮"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ伯"),36)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ估"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ伱")+l111ll_l1_+l11lll_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ伲"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ伳"),32)
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ伴"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ伵")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิำะ๎ฬะࠧ伶"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯࠵࠱࠴ࠫ伷"),32)
	return l11lll_l1_ (u"ࠨࠩ伸")
def CATEGORIES(url,select=l11lll_l1_ (u"ࠩࠪ伹")):
	type = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ伺"))[3]
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ伻"),l11lll_l1_ (u"ࠬ࠭似"),type, url)
	if type==l11lll_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ伽"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠧࠨ伾"),headers,l11lll_l1_ (u"ࠨࠩ伿"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ佀"))
		if select==l11lll_l1_ (u"ࠪ࠷ࠬ佁"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭佂"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ佃"),block,re.DOTALL)
			for link,name in items:
				if l11lll_l1_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬ佄") in name: continue
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ佅"))
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ但"),l111ll_l1_+name,url,32)
		if select==l11lll_l1_ (u"ࠩ࠷ࠫ佇"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬ佈"),html,re.DOTALL)
			block= l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭佉"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				url = l11ll1_l1_ + link
				title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ佊"))
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭佋"),l111ll_l1_+title,url,32,l1llll_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ佌"),l11lll_l1_ (u"ࠨࠩ位"),url,l11lll_l1_ (u"ࠩࠪ低"))
	if type==l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ住"):
		html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠫࠬ佐"),headers,l11lll_l1_ (u"ࠬ࠭佑"),l11lll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠵ࡲࡩ࠭佒"))
		if select==l11lll_l1_ (u"ࠧ࠲ࠩ体"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡈࡧࡱࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ佔"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ何"),block,re.DOTALL)
			for value,name in items:
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳࡬࡫࡮ࡳࡧ࠲ࠫ佖") + value
				name = name.strip(l11lll_l1_ (u"ࠫࠥ࠭佗"))
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ佘"),l111ll_l1_+name,url,32)
		elif select==l11lll_l1_ (u"࠭࠲ࠨ余"):
			l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡁࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ佚"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items=re.findall(l11lll_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ佛"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11lll_l1_ (u"ࠩࠣࠫ作"))
				url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࡦࡩࡴࡰࡴ࠲ࠫ佝") + value
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ佞"),l111ll_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭佟"),l11lll_l1_ (u"࠭ࠧ你"),url,l11lll_l1_ (u"ࠧࠨ佡"))
	type = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ佢"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11lll_l1_ (u"ࠩࠪ佣"),headers,l11lll_l1_ (u"ࠪࠫ佤"),l11lll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭佥"))
	if l11lll_l1_ (u"ࠬ࡮࡯࡮ࡧࠪ佦") in url: type=l11lll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ佧")
	if type==l11lll_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ佨"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠬ࠳࠰࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ佩"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ佪"),block,re.DOTALL)
			for link,l1llll_l1_,name in items:
				url = l11ll1_l1_ + link
				name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ佫"))
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ佬"),l111ll_l1_+name,url,32,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ佭"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ佮"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠫࡀࠫࠥࠫ佯"),block,re.DOTALL)
		for link,l1llll_l1_,name in items:
			name = name.strip(l11lll_l1_ (u"ࠨࠢࠪ佰"))
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ佱"),l111ll_l1_+name,url,33,l1llll_l1_)
	if type==l11lll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ佲"):
		l1l11l1_l1_ = url.split(l11lll_l1_ (u"ࠫ࠴࠭佳"))[-1]
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭佴"),l11lll_l1_ (u"࠭ࠧ併"),url,l11lll_l1_ (u"ࠧࠨ佶"))
		if l1l11l1_l1_==l11lll_l1_ (u"ࠨ࠳ࠪ佷"):
			l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠧ佸"),html,re.DOTALL)
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࠫ佹"),block,re.DOTALL)
			count = 0
			for link,l1llll_l1_,l1lll11_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ佺") + l1lll11_l1_
				url = l11ll1_l1_ + link
				addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ佻"),l111ll_l1_+name,url,33,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵ࠱࠮ࡄࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ佼"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲ࠨ佽"),block,re.DOTALL)
		for link,l1llll_l1_,title,l1lll11_l1_ in items:
			l1lll11_l1_ = l1lll11_l1_.strip(l11lll_l1_ (u"ࠨࠢࠪ佾"))
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ使"))
			name = title + l11lll_l1_ (u"ࠪࠤ࠲ࠦࠧ侀") + l1lll11_l1_
			url = l11ll1_l1_ + link
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ侁"),l111ll_l1_+name,url,33,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡵ࡭࡬࡮ࡴࠩ࠰࠮ࡃ࠮ࡪࡡࡵࡣ࠰ࡶࡪࡼࡩࡷࡧ࠰ࡾࡴࡴࡥࡪࡦࡀࠦ࠹ࠨࠧ侂"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ侃"),block,re.DOTALL)
	for link,l1l11l1_l1_ in items:
		url = l11ll1_l1_ + link
		name = l11lll_l1_ (u"ࠧึใะอࠥ࠭侄") + l1l11l1_l1_
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ侅"),l111ll_l1_+name,url,32)
	return
def PLAY(url):
	if l11lll_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭來") in url:
		url = l11ll1_l1_ + l11lll_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࡸ࠴࠳ࡸ࡫ࡲࡪࡧࡶࡐ࡮ࡴ࡫࠰ࠩ侇") + url.split(l11lll_l1_ (u"ࠫ࠴࠭侈"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ侉"),url,l11lll_l1_ (u"࠭ࠧ侊"),headers,l11lll_l1_ (u"ࠧࠨ例"),l11lll_l1_ (u"ࠨࠩ侌"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ侍"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠪࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ侎"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ侏"),l11lll_l1_ (u"ࠬ࠵ࠧ侐"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ侑"),url,l11lll_l1_ (u"ࠧࠨ侒"),headers,l11lll_l1_ (u"ࠨࠩ侓"),l11lll_l1_ (u"ࠩࠪ侔"),l11lll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ侕"))
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ侖"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ侗"))
	return
def SEARCH(search,l1l11l1_l1_=l11lll_l1_ (u"࠭ࠧ侘")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠧࠡࠩ侙"),l11lll_l1_ (u"ࠨࠧ࠵࠴ࠬ侚"))
	l1ll1111l_l1_ = [l11lll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ供"),l11lll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ侜")]
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠫ࠶࠭依")
	else: l1l11l1_l1_,type = l1l11l1_l1_.split(l11lll_l1_ (u"ࠬ࠵ࠧ侞"))
	if l1ll_l1_:
		l1l1l11ll_l1_ = [ l11lll_l1_ (u"࠭ศฮอࠣ฽๋ࠦวโๆส้ࠬ侟") , l11lll_l1_ (u"ࠧษฯฮࠤ฾์ࠠๆี็ื้อสࠨ侠")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥ࠳ࠠศะอีࠥอไษฯฮࠫ価"), l1l1l11ll_l1_)
		if l1l_l1_ == -1 : return
		type = l1ll1111l_l1_[l1l_l1_]
	else:
		if l11lll_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࡡࠪ侢") in options: type = l11lll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ侣")
		elif l11lll_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࡣࠬ侤") in options: type = l11lll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ侥")
		else: return
	headers[l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ侦")] = l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ侧")
	data = {l11lll_l1_ (u"ࠨࡳࡸࡩࡷࡿࠧ侨"):l111l1l_l1_ , l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡆࡲࡱࡦ࡯࡮ࠨ侩"):type}
	if l1l11l1_l1_!=l11lll_l1_ (u"ࠪ࠵ࠬ侪"): data[l11lll_l1_ (u"ࠫ࡫ࡸ࡯࡮ࠩ侫")] = l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ侬"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ侭"),data,headers,l11lll_l1_ (u"ࠧࠨ侮"),l11lll_l1_ (u"ࠨࠩ侯"),l11lll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ侰"))
	html = response.content
	items=re.findall(l11lll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭侱"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l11ll1_l1_ + link.replace(l11lll_l1_ (u"ࠫࡡ࠵ࠧ侲"),l11lll_l1_ (u"ࠬ࠵ࠧ侳"))
			if l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ侴") in url: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭侵"),l111ll_l1_+l11lll_l1_ (u"ࠨใํ่๊ࠦࠧ侶")+title,url,33)
			elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ侷") in url:
				url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ侸"),l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࠪ侹"))
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ侺"),l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ࠥ࠭侻")+title,url+l11lll_l1_ (u"ࠧ࠰࠳ࠪ侼"),32)
	count=re.findall(l11lll_l1_ (u"ࠨࠤࡷࡳࡹࡧ࡬ࠣ࠼ࠫ࠲࠯ࡅࠩࡾࠩ侽"),html,re.DOTALL)
	if count:
		l1l1ll11l_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll11l1l_l1_ in range(1,l1l1ll11l_l1_):
			l1ll11l1l_l1_ = str(l1ll11l1l_l1_)
			if l1ll11l1l_l1_!=l1l11l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ侾"),l11lll_l1_ (u"ูࠪๆำษࠡࠩ便")+l1ll11l1l_l1_,l11lll_l1_ (u"ࠫࠬ俀"),39,l11lll_l1_ (u"ࠬ࠭俁"),l1ll11l1l_l1_+l11lll_l1_ (u"࠭࠯ࠨ係")+type,search)
	return
def l1l1lll1l_l1_():
	link = l11lll_l1_ (u"ࠧࡢࡊࡕ࠴ࡨࡊ࡯ࡷࡎ࠵ࡨࡿࡪࡈࡋ࡮࡜࡛࠵࠶ࡌ࡯ࡄ࡫ࡦࡲ࡜࠰ࡍ࡯ࡑࡺࡑࡳ࡬ࡴࡎ࠵࡚ࡰࡠ࠲ࡗࡨ࡜࡛ࡏࡿࡌ࠳ࡪ࡫ࡦࡌࡌࡕࡗ࡫࠼ࡻࡧࡍࡆ࠶ࡤࡊࡰࡿࡪࡃ࠶ࡶࡐ࠷࡚࠺ࠧ促")
	link = base64.b64decode(link)
	link = link.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭俄"))
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ俅"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠭㋍")
l1l1l1_l1_ = WEBSITES[l1l1ll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ㋎")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l1l1ll_l1_ (u"ࠨ࠲ࠪ㋏"),True)
	elif mode==102: results = ITEMS(l1l1ll_l1_ (u"ࠩ࠴ࠫ㋐"),True)
	elif mode==103: results = ITEMS(l1l1ll_l1_ (u"ࠪ࠶ࠬ㋑"),True)
	elif mode==104: results = ITEMS(l1l1ll_l1_ (u"ࠫ࠸࠭㋒"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l1l1ll_l1_ (u"ࠬ࠺ࠧ㋓"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋔"),l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㋕")+l1l1ll_l1_ (u"ࠨๆ็ู้ะัไ์้ࠤอิฯๆหࠣࡑ࠸࡛ࠧ㋖"),l1l1ll_l1_ (u"ࠩࠪ㋗"),710)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋘"),l1l1ll_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪ㋙")+l1l1ll_l1_ (u"๊ࠬไๆึอี่๐ๆࠡสัำ๊ฯࠠࡊࡒࡗ࡚ࠬ㋚"),l1l1ll_l1_ (u"࠭ࠧ㋛"),230)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋜"),l1l1ll_l1_ (u"ࠨࡡࡗ࡚࠵ࡥࠧ㋝")+l1l1ll_l1_ (u"ࠩๅ๊ํอสࠡ็้ࠤ๊๎วใ฻๊หࠥอไฤื็๎ฮ࠭㋞"),l1l1ll_l1_ (u"ࠪࠫ㋟"),101)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋠"),l1l1ll_l1_ (u"ࠬࡥࡔࡗ࠶ࡢࠫ㋡")+l1l1ll_l1_ (u"࠭โ็๊สฮ๋ࠥฮหษิอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㋢"),l1l1ll_l1_ (u"ࠧࠨ㋣"),106)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㋤"),l1l1ll_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ㋥")+l1l1ll_l1_ (u"ࠪๆ๋๎วหࠢ฼ีอ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㋦"),l1l1ll_l1_ (u"ࠫࠬ㋧"),147)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋨"),l1l1ll_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ㋩")+l1l1ll_l1_ (u"ࠧใ่๋หฯࠦรอ่ห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㋪"),l1l1ll_l1_ (u"ࠨࠩ㋫"),148)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋬"),l1l1ll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ㋭")+l1l1ll_l1_ (u"ࠫࠥࠦโ็ษฬࠤว๐ࠠโ์็้๋ࠥๆࠡ็๋ๆ฾ํๅࠡࠢࠪ㋮"),l1l1ll_l1_ (u"ࠬ࠭㋯"),28)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡸࡨࠫ㋰"),l1l1ll_l1_ (u"ࠧࡠࡏࡕࡊࡤ࠭㋱")+l1l1ll_l1_ (u"ࠨไ้หฮࠦวๅ็฼หึ็ࠠๆ่้ࠣํู่่็ࠪ㋲"),l1l1ll_l1_ (u"ࠩࠪ㋳"),41)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㋴"),l1l1ll_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ㋵")+l1l1ll_l1_ (u"่ࠬๆศหࠣห้้่ฬำ้๋ࠣࠦๅ้ไ฼๋๊࠭㋶"),l1l1ll_l1_ (u"࠭ࠧ㋷"),135)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㋸"),l1l1ll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ㋹")+l1l1ll_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ㋺"),l1l1ll_l1_ (u"ࠪࠫ㋻"),38)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㋼"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㋽"),l1l1ll_l1_ (u"࠭ࠧ㋾"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋿"),l1l1ll_l1_ (u"ࠨࡡࡗ࡚࠶ࡥࠧ㌀")+l1l1ll_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ฾อๅสࠩ㌁"),l1l1ll_l1_ (u"ࠪࠫ㌂"),102)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌃"),l1l1ll_l1_ (u"ࠬࡥࡔࡗ࠴ࡢࠫ㌄")+l1l1ll_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡะสูฮ࠭㌅"),l1l1ll_l1_ (u"ࠧࠨ㌆"),103)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㌇"),l1l1ll_l1_ (u"ࠩࡢࡘ࡛࠹࡟ࠨ㌈")+l1l1ll_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอ๊ࠥไโฯุࠫ㌉"),l1l1ll_l1_ (u"ࠫࠬ㌊"),104)
	return
def ITEMS(l1lll1l11l_l1_,showDialogs=True):
	menu_name = l1l1ll_l1_ (u"ࠬࡥࡔࡗࠩ㌋")+l1lll1l11l_l1_+l1l1ll_l1_ (u"࠭࡟ࠨ㌌")
	client = l1l1l1l1l1l_l1_(32)
	payload = {l1l1ll_l1_ (u"ࠧࡪࡦࠪ㌍"):l1l1ll_l1_ (u"ࠨࠩ㌎"),l1l1ll_l1_ (u"ࠩࡸࡷࡪࡸࠧ㌏"):client,l1l1ll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㌐"):l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㌑"),l1l1ll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㌒"):l1lll1l11l_l1_}
	#data = l1lll1l11_l1_(payload)
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌓"),str(payload))
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㌔"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㌕"), l1l1l1_l1_, payload, l1l1ll_l1_ (u"ࠩࠪ㌖"), True,l1l1ll_l1_ (u"ࠪࠫ㌗"),l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㌘"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ㌙"),l1l1l1_l1_,payload,l1l1ll_l1_ (u"࠭ࠧ㌚"),l1l1ll_l1_ (u"ࠧࠨ㌛"),l1l1ll_l1_ (u"ࠨࠩ㌜"),l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㌝"))
	html = response.content
	#html = html.replace(l1l1ll_l1_ (u"ࠪࡠࡷ࠭㌞"),l1l1ll_l1_ (u"ࠫࠬ㌟"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㌠"),l1l1ll_l1_ (u"࠭ࠧ㌡"),html,html)
	#file = open(l1l1ll_l1_ (u"ࠧࡴ࠼࠲ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭㌢"), l1l1ll_l1_ (u"ࠨࡹࠪ㌣"))
	#file.write(html)
	#file.close()
	items = re.findall(l1l1ll_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ㌤"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l1ll_l1_ (u"ࠪࡥࡱ࠭㌥"),l1l1ll_l1_ (u"ࠫࡆࡲࠧ㌦"))
			start = start.replace(l1l1ll_l1_ (u"ࠬࡋ࡬ࠨ㌧"),l1l1ll_l1_ (u"࠭ࡁ࡭ࠩ㌨"))
			start = start.replace(l1l1ll_l1_ (u"ࠧࡂࡎࠪ㌩"),l1l1ll_l1_ (u"ࠨࡃ࡯ࠫ㌪"))
			start = start.replace(l1l1ll_l1_ (u"ࠩࡈࡐࠬ㌫"),l1l1ll_l1_ (u"ࠪࡅࡱ࠭㌬"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l1ll_l1_ (u"ࠫࡆࡲ࠭ࠨ㌭"),l1l1ll_l1_ (u"ࠬࡇ࡬ࠨ㌮"))
			start = start.replace(l1l1ll_l1_ (u"࠭ࡁ࡭ࠢࠪ㌯"),l1l1ll_l1_ (u"ࠧࡂ࡮ࠪ㌰"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,id2,name,img in items:
			if l1l1ll_l1_ (u"ࠨࠥࠪ㌱") in source: continue
			#if source in [l1l1ll_l1_ (u"ࠩࡑࡘࠬ㌲"),l1l1ll_l1_ (u"ࠪ࡝࡚࠭㌳"),l1l1ll_l1_ (u"ࠫ࡜࡙࠰ࠨ㌴"),l1l1ll_l1_ (u"ࠬࡘࡌ࠲ࠩ㌵"),l1l1ll_l1_ (u"࠭ࡒࡍ࠴ࠪ㌶")]: continue
			if source!=l1l1ll_l1_ (u"ࠧࡖࡔࡏࠫ㌷"): name = name+l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࠥࠦࠧ㌸")+source+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㌹")
			url = source+l1l1ll_l1_ (u"ࠪ࠿ࡀ࠭㌺")+server+l1l1ll_l1_ (u"ࠫࡀࡁࠧ㌻")+id2+l1l1ll_l1_ (u"ࠬࡁ࠻ࠨ㌼")+l1lll1l11l_l1_
			addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡸࡨࠫ㌽"),menu_name+l1l1ll_l1_ (u"ࠧࠨ㌾")+name,url,105,img)
	else:
		if showDialogs: addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㌿"),menu_name+l1l1ll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㍀"),l1l1ll_l1_ (u"ࠪࠫ㍁"),9999)
		#if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㍂"),l1l1ll_l1_ (u"ࠬ࠭㍃"),l1l1ll_l1_ (u"࠭ࠧ㍄"),l1l1ll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㍅"))
		#addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㍆"),menu_name+l1l1ll_l1_ (u"ࠩ็่ศูแࠡๆสࠤฯ๎ฬะࠢๅ๊ํอสࠡฬ็ๅื๎ๆ๋ห่่ࠣ࠭㍇"),l1l1ll_l1_ (u"ࠪࠫ㍈"),9999)
		#addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㍉"),menu_name+l1l1ll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็ห็ืศศรࠣ์ฬ๊วึัๅหฦࠦแใูࠪ㍊"),l1l1ll_l1_ (u"࠭ࠧ㍋"),9999)
		#addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㍌"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㍍"),l1l1ll_l1_ (u"ࠩࠪ㍎"),9999)
		#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㍏"),menu_name+l1l1ll_l1_ (u"࡚ࠫࡴࡦࡰࡴࡷࡹࡳࡧࡴࡦ࡮ࡼ࠰ࠥࡴ࡯ࠡࡖ࡙ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠦࡦࡰࡴࠣࡽࡴࡻࠧ㍐"),l1l1ll_l1_ (u"ࠬ࠭㍑"),9999)
		#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㍒"),menu_name+l1l1ll_l1_ (u"ࠧࡊࡶࠣ࡭ࡸࠦࡦࡰࡴࠣࡶࡪࡲࡡࡵ࡫ࡹࡩࡸࠦࠦࠡࡨࡵ࡭ࡪࡴࡤࡴࠢࡲࡲࡱࡿࠧ㍓"),l1l1ll_l1_ (u"ࠨࠩ㍔"),9999)
	return
def PLAY(id):
	source,server,id2,l1lll1l11l_l1_ = id.split(l1l1ll_l1_ (u"ࠩ࠾࠿ࠬ㍕"))
	url = l1l1ll_l1_ (u"ࠪࠫ㍖")
	if source==l1l1ll_l1_ (u"࡚ࠫࡘࡌࠨ㍗"): url = id2
	elif source==l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㍘"):
		url = WEBSITES[l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㍙")][0]+l1l1ll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ㍚")+id2
		import ll_l1_
		ll_l1_.l1l_l1_([url],script_name,l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㍛"),url)
		return
	elif source==l1l1ll_l1_ (u"ࠩࡊࡅࠬ㍜"):
		payload = { l1l1ll_l1_ (u"ࠪ࡭ࡩ࠭㍝") : l1l1ll_l1_ (u"ࠫࠬ㍞"), l1l1ll_l1_ (u"ࠬࡻࡳࡦࡴࠪ㍟") : l1l1l1l1l1l_l1_(32) , l1l1ll_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㍠") : l1l1ll_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠱ࠨ㍡") , l1l1ll_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㍢") : l1l1ll_l1_ (u"ࠩࠪ㍣") }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ㍤"),l1l1l1_l1_,payload,l1l1ll_l1_ (u"ࠫࠬ㍥"),False,l1l1ll_l1_ (u"ࠬ࠭㍦"),l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㍧"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㍨"),l1l1ll_l1_ (u"ࠨࠩ㍩"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㍪"),l1l1ll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㍫"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l1l1l11ll_l1_ = cookies[l1l1ll_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤࠨ㍬")]
		url = response.headers[l1l1ll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㍭")]
		payload = { l1l1ll_l1_ (u"࠭ࡩࡥࠩ㍮") : id2 , l1l1ll_l1_ (u"ࠧࡶࡵࡨࡶࠬ㍯") : l1l1l1l1l1l_l1_(32) , l1l1ll_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㍰") : l1l1ll_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠴ࠪ㍱") , l1l1ll_l1_ (u"ࠪࡱࡪࡴࡵࠨ㍲") : l1l1ll_l1_ (u"ࠫࠬ㍳") }
		headers = { l1l1ll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ㍴") : l1l1ll_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࡀࠫ㍵")+l1l1l1l11ll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㍶"),l1l1l1_l1_,payload,headers,l1l1ll_l1_ (u"ࠨࠩ㍷"),l1l1ll_l1_ (u"ࠩࠪ㍸"),l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㍹"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㍺"),l1l1ll_l1_ (u"ࠬ࠭㍻"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㍼"),l1l1ll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㍽"))
			return
		html = response.content
		url = re.findall(l1l1ll_l1_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ㍾"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ㍿"),l1l1ll_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠫ㎀")+link)
		#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ㎁"),l1l1ll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭㎂")+params)
		l1l1l1l11l1_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠹࠰ࠪ㎃")+server+l1l1ll_l1_ (u"ࠧ࠸࠹࠺࠳ࠬ㎄")+id2+l1l1ll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㎅")+params
		l1l1l1l1lll_l1_ = l1l1l1l11l1_l1_.replace(l1l1ll_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㎆"),l1l1ll_l1_ (u"ࠪ࠸࠵ࡀ࠷ࠨ㎇")).replace(l1l1ll_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㎈"),l1l1ll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㎉"))
		l1l1l1l1ll1_l1_ = l1l1l1l11l1_l1_.replace(l1l1ll_l1_ (u"࠭࠳࠷࠼࠺ࠫ㎊"),l1l1ll_l1_ (u"ࠧ࠵࠴࠽࠻ࠬ㎋")).replace(l1l1ll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㎌"),l1l1ll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㎍"))
		l111l1l_l1_ = [l1l1ll_l1_ (u"ࠪࡌࡉ࠭㎎"),l1l1ll_l1_ (u"ࠫࡘࡊ࠱ࠨ㎏"),l1l1ll_l1_ (u"࡙ࠬࡄ࠳ࠩ㎐")]
		l11l1_l1_ = [l1l1l1l11l1_l1_,l1l1l1l1lll_l1_,l1l1l1l1ll1_l1_]
		selection = 0
		#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ㎑"), l111l1l_l1_)
		if selection == -1: return
		else: url = l11l1_l1_[selection]
	elif source==l1l1ll_l1_ (u"ࠧࡏࡖࠪ㎒"):
		headers = { l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㎓") : l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ㎔") }
		payload = { l1l1ll_l1_ (u"ࠪ࡭ࡩ࠭㎕") : id2 , l1l1ll_l1_ (u"ࠫࡺࡹࡥࡳࠩ㎖") : l1l1l1l1l1l_l1_(32) , l1l1ll_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㎗") : l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࡒ࡙࠭㎘") , l1l1ll_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㎙") : l1lll1l11l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭㎚"), l1l1l1_l1_, payload, headers, False,l1l1ll_l1_ (u"ࠩࠪ㎛"),l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㎜"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㎝"),l1l1ll_l1_ (u"ࠬ࠭㎞"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㎟"),l1l1ll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㎠"))
			return
		html = response.content
		url = response.headers[l1l1ll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㎡")]
		url = url.replace(l1l1ll_l1_ (u"ࠩࠨ࠶࠵࠭㎢"),l1l1ll_l1_ (u"ࠪࠤࠬ㎣"))
		url = url.replace(l1l1ll_l1_ (u"ࠫࠪ࠹ࡄࠨ㎤"),l1l1ll_l1_ (u"ࠬࡃࠧ㎥"))
		if l1l1ll_l1_ (u"࠭ࡌࡦࡣࡵࡲࠬ㎦") in id2:
			url = url.replace(l1l1ll_l1_ (u"ࠧࡏࡖࡑࡒ࡮ࡲࡥࠨ㎧"),l1l1ll_l1_ (u"ࠨࠩ㎨"))
			url = url.replace(l1l1ll_l1_ (u"ࠩ࡯ࡩࡦࡸ࡮ࡪࡰࡪ࠵ࠬ㎩"),l1l1ll_l1_ (u"ࠪࡐࡪࡧࡲ࡯࡫ࡱ࡫ࠬ㎪"))
	elif source==l1l1ll_l1_ (u"ࠫࡕࡒࠧ㎫"):
		#headers = { l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㎬") : l1l1ll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ㎭") }
		payload = { l1l1ll_l1_ (u"ࠧࡪࡦࠪ㎮") : id2 , l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷ࠭㎯") : l1l1l1l1l1l_l1_(32) , l1l1ll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㎰") : l1l1ll_l1_ (u"ࠪࡴࡱࡧࡹࡑࡎࠪ㎱") , l1l1ll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㎲") : l1lll1l11l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ㎳"), l1l1l1_l1_, payload, l1l1ll_l1_ (u"࠭ࠧ㎴"),False,l1l1ll_l1_ (u"ࠧࠨ㎵"),l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ㎶"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㎷"),l1l1ll_l1_ (u"ࠪࠫ㎸"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㎹"),l1l1ll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㎺"))
			return
		html = response.content
		url = response.headers[l1l1ll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㎻")]
		headers = {l1l1ll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㎼"):response.headers[l1l1ll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㎽")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㎾"),url, l1l1ll_l1_ (u"ࠪࠫ㎿"),headers , l1l1ll_l1_ (u"ࠫࠬ㏀"),l1l1ll_l1_ (u"ࠬ࠭㏁"),l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ㏂"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㏃"),l1l1ll_l1_ (u"ࠨࠩ㏄"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㏅"),l1l1ll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㏆"))
			return
		html = response.content
		items = re.findall(l1l1ll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㏇"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l1ll_l1_ (u"࡚ࠬࡁࠨ㏈"),l1l1ll_l1_ (u"࠭ࡆࡎࠩ㏉"),l1l1ll_l1_ (u"࡚ࠧࡗࠪ㏊"),l1l1ll_l1_ (u"ࠨ࡙ࡖ࠵ࠬ㏋"),l1l1ll_l1_ (u"࡚ࠩࡗ࠷࠭㏌"),l1l1ll_l1_ (u"ࠪࡖࡑ࠷ࠧ㏍"),l1l1ll_l1_ (u"ࠫࡗࡒ࠲ࠨ㏎")]:
		if source==l1l1ll_l1_ (u"࡚ࠬࡁࠨ㏏"): id2 = id
		headers = { l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㏐") : l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㏑") }
		payload = { l1l1ll_l1_ (u"ࠨ࡫ࡧࠫ㏒") : id2 , l1l1ll_l1_ (u"ࠩࡸࡷࡪࡸࠧ㏓") : l1l1l1l1l1l_l1_(32) , l1l1ll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㏔") : l1l1ll_l1_ (u"ࠫࡵࡲࡡࡺࠩ㏕")+source , l1l1ll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㏖") : l1lll1l11l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡐࡐࡕࡗࠫ㏗"),l1l1l1_l1_,payload,headers,l1l1ll_l1_ (u"ࠧࠨ㏘"),l1l1ll_l1_ (u"ࠨࠩ㏙"),l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ㏚"))
		if not response.succeeded:
			DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㏛"),l1l1ll_l1_ (u"ࠫࠬ㏜"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㏝"),l1l1ll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㏞"))
			return
		html = response.content
		url = response.headers[l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㏟")]
		if source==l1l1ll_l1_ (u"ࠨࡈࡐࠫ㏠"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭㏡"), url, l1l1ll_l1_ (u"ࠪࠫ㏢"), l1l1ll_l1_ (u"ࠫࠬ㏣"), False,l1l1ll_l1_ (u"ࠬ࠭㏤"),l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠼ࡺࡨࠨ㏥"))
			url = response.headers[l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㏦")]
			url = url.replace(l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ㏧"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㏨"))
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ㏩"))
	return
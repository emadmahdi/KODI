# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
l1l1ll_l1_ (u"ࠦࠧࠨࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠸ࡧ࡫ࡳࡵ࠰ࡦࡳࡲ࠭ࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠵࠳ࡨࡥࡴࡶࠪࠎࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠶࠴ࡣࡰ࡯ࠪࠎࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼ࠴ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨࠌࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰࡳࡻ࡯ࡥࡴ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡷ࡮ࡺࡥࠨࠌࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡸࡻ࠭ࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡣࡦ࡯࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡣࡰࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡣ࡮ࡲ࡫ࠬࠐࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡦࡣࡵ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡳࡥࠨࠌࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡳࡴࡲ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯࡮ࡷࡨࠬࠐࠢࠣࠤ⁫")
script_name = l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭⁬")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡆࡉࡅࡣࠬ⁭")
l1l1l1_l1_ = WEBSITES[script_name][0]
headers = {l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⁮"):l1l1ll_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵࠭⁯")}
def MAIN(mode,url,page,text):
	if   mode==120: results = MENU()
	elif mode==121: results = l11l1l_l1_(url,page)
	elif mode==122: results = l1ll1l_l1_(url)
	elif mode==123: results = PLAY(url)
	elif mode==124: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⁰")+text)
	elif mode==125: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩⁱ")+text)
	elif mode==129: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⁲"),menu_name+l1l1ll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ⁳"),l1l1ll_l1_ (u"࠭ࠧ⁴"),129,l1l1ll_l1_ (u"ࠧࠨ⁵"),l1l1ll_l1_ (u"ࠨࠩ⁶"),l1l1ll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⁷"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⁸"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⁹"),l1l1ll_l1_ (u"ࠬ࠭⁺"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ⁻"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ⁼"),headers,l1l1ll_l1_ (u"ࠨࠩ⁽"),l1l1ll_l1_ (u"ࠩࠪ⁾"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ⁿ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࠦࡩ࠮ࡪࡲࡱࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࠦࡩ࠮ࡨࡲࡰࡩ࡫ࡲࠣࠩ₀"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ₁"),block,re.DOTALL)
		for link,title in items:
			if l1l1ll_l1_ (u"࠭วๅ็ุหึ฿ษࠨ₂") in title: continue
			title = title.rsplit(l1l1ll_l1_ (u"ࠧ࠿ࠩ₃"),1)[1]
			title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ₄"))
			link = link.rstrip(l1l1ll_l1_ (u"ࠩ࠲ࠫ₅"))
			link = l1l1l1_l1_+link
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ₆"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭₇")+menu_name+title,link,122)
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ₈"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭₉"),l1l1ll_l1_ (u"ࠧࠨ₊"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧࡳࡡࡪࡰࡏࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡼࡥࡳࡶ࡬ࡧࡦࡲࡄࡺࡰࡤࡱ࡮ࡩࠢࠨ₋"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࡳࡨࡦࠦࡢࡥࡤࠥࡂࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭₌"),html,re.DOTALL)
		for title,link in items:
			title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬ₍"))
			link = link.rstrip(l1l1ll_l1_ (u"ࠫ࠴࠭₎"))
			link = l1l1l1_l1_+link
			if l1l1ll_l1_ (u"ࠬอไๆืสี฾ฯࠧ₏") in title: continue
			if l1l1ll_l1_ (u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨₐ") in link: continue
			if not title and l1l1ll_l1_ (u"ࠧ࠰ࡶࡹ࠳ࡦࡸࡡࡣ࡫ࡦࠫₑ") in link: title = l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢ฼ีอ๐ษࠨₒ")
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩₓ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬₔ")+menu_name+title,link,121)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩₕ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬₖ"),l1l1ll_l1_ (u"࠭ࠧₗ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡣࠫ࠲࠯ࡅࠩ࠿ࡇࡪࡽࡇ࡫ࡳࡵ࠾࠲ࡥࡃ࠭ₘ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪₙ"),block,re.DOTALL)
		for link,title in items:
			link = l1l1l1_l1_+link
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫₚ"))
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪₛ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ₜ")+menu_name+title,link,121)
	return html
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ₝"),url,l1l1ll_l1_ (u"࠭ࠧ₞"),headers,l1l1ll_l1_ (u"ࠧࠨ₟"),l1l1ll_l1_ (u"ࠨࠩ₠"),l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ₡"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡸࡥࡳࡤࡴࡲࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ₢"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ₣"),block,re.DOTALL)
	if l1l1ll_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ₤") not in url:
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭₥"),menu_name+l1l1ll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ₦"),url,125)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ₧"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ₨"),url,124)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ₩"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ₪"),l1l1ll_l1_ (u"ࠬ࠭₫"),9999)
	for link,title in items:
		link = l1l1l1_l1_+link
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭€"),menu_name+title,link,121)
	return
def l11l1l_l1_(url,page=l1l1ll_l1_ (u"ࠧ࠲ࠩ₭")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ₮"),l1l1ll_l1_ (u"ࠩࠪ₯"),l1l1ll_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪ₰"),url)
	if not page: page = l1l1ll_l1_ (u"ࠫ࠶࠭₱")
	#if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ₲") not in url: url = l1l1l1_l1_+url
	if l1l1ll_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࠩ₳") in url or l1l1ll_l1_ (u"ࠧࡀࠩ₴") in url: url2 = url + l1l1ll_l1_ (u"ࠨࠨࠪ₵")
	else: url2 = url + l1l1ll_l1_ (u"ࠩࡂࠫ₶")
	url2 = url2 + l1l1ll_l1_ (u"ࠪࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠧࡱࡸࡸࡵࡻࡴࡠ࡯ࡲࡨࡪࡃ࡭ࡰࡸ࡬ࡩࡸࡥ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠪ₷")+page
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ₸"),url2,l1l1ll_l1_ (u"ࠬ࠭₹"),headers,l1l1ll_l1_ (u"࠭ࠧ₺"),l1l1ll_l1_ (u"ࠧࠨ₻"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭₼"))
	html = response.content
	name,items = l1l1ll_l1_ (u"ࠩࠪ₽"),[]
	if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ₾") in url:
		name = re.findall(l1l1ll_l1_ (u"ࠫࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ₿"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l1ll_l1_ (u"ࠬࠦࠧ⃀")) + l1l1ll_l1_ (u"࠭ࠠ࠮ࠢࠪ⃁")
		else: name = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠣ⃂") ) + l1l1ll_l1_ (u"ࠨࠢ࠰ࠤࠬ⃃")
	if l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪ⃄") not in url: items = re.findall(l1l1ll_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡡࡢ࡜࡝ࠤࠫࡠࡡࡢ࡜࡝࠱ࡶࡩࡦࡹ࡯࡯࠰࠭ࡃ࠮ࡢ࡜࡝࡞ࠥ࠲࠯ࡅࡳࡳࡥࡀࡠࡡࡢ࡜ࠣࠪ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫࡜࡝࡞࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⃅"),html,re.DOTALL)
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࡶࡶࡨࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࡞࡟ࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⃆"),html,re.DOTALL)
	for link,img,title in items:
		if l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⃇") in url and l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࡜࠰ࠩ⃈") not in link: continue
		if l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ⃉") in url and l1l1ll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࡟࠳ࠬ⃊") not in link: continue
		title = name+escapeUNICODE(title).strip(l1l1ll_l1_ (u"ࠩࠣࠫ⃋"))
		link = link.replace(l1l1ll_l1_ (u"ࠪࡠ࠴࠭⃌"),l1l1ll_l1_ (u"ࠫ࠴࠭⃍"))
		img = img.replace(l1l1ll_l1_ (u"ࠬࡢ࠯ࠨ⃎"),l1l1ll_l1_ (u"࠭࠯ࠨ⃏"))
		if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ⃐") not in img: img = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ⃑")+img
		url2 = l1l1l1_l1_+link
		if l1l1ll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱⃒ࠪ") in url2 or l1l1ll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴⃓࠭") in url2 or l1l1ll_l1_ (u"ࠫ࠴ࡳࡡࡴࡴࡤ࡬࡮ࡿࡡࡵ࠱ࠪ⃔") in url:
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⃕"),menu_name+title,url2.rstrip(l1l1ll_l1_ (u"࠭࠯ࠨ⃖")),123,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⃗"),menu_name+title,url2,121,img)
	if len(items)>=12:
		l111l1lll1_l1_ = [l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱⃘ࠪ"),l1l1ll_l1_ (u"ࠩ࠲ࡸࡻ࠵⃙ࠧ"),l1l1ll_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴⃚࠭"),l1l1ll_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠯ࠨ⃛"),l1l1ll_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫ⃜")]
		page = int(page)
		if any(value in url for value in l111l1lll1_l1_):
			for n in range(0,1100,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⃝"),menu_name+l1l1ll_l1_ (u"ࠧึใะอࠥ࠭⃞")+str(j),url,121,l1l1ll_l1_ (u"ࠨࠩ⃟"),str(j))
						elif i!=0: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⃠"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ⃡")+str(i),url,121,l1l1ll_l1_ (u"ࠫࠬ⃢"),str(i))
						else: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⃣"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ⃤")+str(1),url,121,l1l1ll_l1_ (u"ࠧࠨ⃥"),str(1))
				elif n!=0: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⃦"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ⃧")+str(n),url,121,l1l1ll_l1_ (u"⃨ࠪࠫ"),str(n))
				else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⃩"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮห⃪ࠣࠫ")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ⃫ࠪ"):l1l1ll_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴⃬ࠬ")}
	#url = url.replace(l1l1ll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡱࡩࡹ⃭࠭"),l1l1ll_l1_ (u"ࠩࡺ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴࡥࡵ⃮ࠩ"))
	# cache l111ll111l_l1_ not l11l111111_l1_ after 3 minutes
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚⃯ࠧ"),url,l1l1ll_l1_ (u"ࠫࠬ⃰"),headers,l1l1ll_l1_ (u"ࠬ࠭⃱"),l1l1ll_l1_ (u"࠭ࠧ⃲"),l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⃳"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⃴"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	new_server = re.findall(l1l1ll_l1_ (u"ࠩࠥࡳ࡬ࡀࡵࡳ࡮ࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⃵"),html,re.DOTALL)
	if new_server: server = SERVER(new_server[0],l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ⃶"))
	else: server = SERVER(url,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ⃷"))
	l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡵࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡸࡧࡵࡤࡺࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢࡱࡳࡹࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡏࡑࡗࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠮ࠧฯูฦࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐่่ࠧ࠭ࠩๆࠦวๅใํำ๏๎ࠠ฻์ิࠤ๊ะ่โำࠪ࠭ࠏࠏࠉࡳࡧࡷࡹࡷࡴࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠧࠨࠢ⃸")
	# l111l11l1l_l1_ l1lll11l_l1_://l111lllll1_l1_.l1ll1ll1_l1_/l11lllll1_l1_/?v=l1111ll1ll_l1_&h=5de8bb072d336de05092297ec8b61643
	# l11l11ll11_l1_ l1lll11l_l1_://l111l11l11_l1_.top/l1l1l1l11_l1_/l11l11l11l_l1_/?l11l111lll_l1_=44711370a2655b3f2d23487cb74c05e5347648e8bb9571dfa7c5d5e4zlllsCGMDslElsMaYXobviuROhYfamfMOhlsEslsWQUlslElsMOcSbzMykqapaqlsEslsxMcGlslElsOGsabiZusOxySMgOpEaucSxiSVGEBOlOouQzsEslsxWdlslElsmmmlRPMMslnfpaqlsEslsCMcGlslElsOEOEEZlEMOuzslh
	l111l1l_l1_,l11l1_l1_ = [],[]
	# l11lllll1_l1_ & download l1ll_l1_
	#l111l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⃹"),html,re.DOTALL)
	l111l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡢࡷࡷࡳ࠲ࡹࡩࡻࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⃺"),html,re.DOTALL)
	if l111l11l1l_l1_:
		l111l11l1l_l1_ = server+l111l11l1l_l1_[0]		#+l1l1ll_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࡩࡶࡷࡴ࠿࠵࠯࠸࠻࠱࠵࠻࠻࠮࠳࠶࠵࠲࠽࠺࠺࠵࠳࠷࠹ࠬ⃻")
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ⃼"),l1l1ll_l1_ (u"ࠪࠫ⃽"),l1l1ll_l1_ (u"ࠫࠬ⃾"),l111l11l1l_l1_)
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ⃿"),l111l11l1l_l1_,l1l1ll_l1_ (u"࠭ࠧ℀"),headers,l1l1ll_l1_ (u"ࠧࠨ℁"),l1l1ll_l1_ (u"ࠨࠩℂ"),l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ℃"))
		l1l11ll1_l1_ = response.content
		#WRITE_THIS(l1l11ll1_l1_)
		if l1l1ll_l1_ (u"ࠪࡨࡴࡹࡴࡳࡧࡤࡱࠬ℄") not in l1l11ll1_l1_:
			l111ll11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁࡹࡣࡳ࡫ࡳࡸ࠳࠰࠿࠿ࡨࡸࡲࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ℅"),l1l11ll1_l1_,re.DOTALL)
			l111ll11ll_l1_ = l111ll11ll_l1_[0]
			result = l1111l1lll_l1_(l111ll11ll_l1_)
			try: l11111111l_l1_,l111111ll1_l1_,l11l11l1ll_l1_ = result
			except:
				DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭℆"),l1l1ll_l1_ (u"࠭ࠧℇ"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ℈"),l1l1ll_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢ࠱ࠤ็ี๋ࠠๅ๋๊ࠥอไๆ๊ๅ฽ࠥอไฤื็๎่ࠥวๆࠢหฮาี๊ฬุࠢๅาอส่๋ࠢห้ฮั็ษ่ะࠥเ๊าࠢๅหิืฺࠠๆ์ࠤ็ืวยหࠣห้฻แฮษอࠤฬ๊ฬะ์าอࠬ℉"))
				return
			l111111ll1_l1_ = server+l111111ll1_l1_
			l11111111l_l1_ = server+l11111111l_l1_
			cookies = response.cookies.get_dict()
			if l1l1ll_l1_ (u"ࠩࡓࡗࡘࡏࡄࠨℊ") in cookies.keys():
				l11111l11l_l1_ = cookies[l1l1ll_l1_ (u"ࠪࡔࡘ࡙ࡉࡅࠩℋ")]
				#headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨℌ"):l1l11lll1_l1_(),l1l1ll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬℍ"):l1l1ll_l1_ (u"࠭ࡐࡔࡕࡌࡈࡂ࠭ℎ")+l11111l11l_l1_}
				headers[l1l1ll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧℏ")] = l1l1ll_l1_ (u"ࠨࡒࡖࡗࡎࡊ࠽ࠨℐ")+l11111l11l_l1_
				l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࠉࠊࠋࡤࡹࡹ࡮ࡵࡳ࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࠏࡩࡧࠢࡤࡹࡹ࡮ࡵࡳ࡮࠽ࠎࠎࠏࠉࠊࠋࡤࡹࡹ࡮ࡵࡳ࡮ࠣࡁࠥࡹࡥࡳࡸࡨࡶ࠰ࡧࡵࡵࡪࡸࡶࡱࡡ࠰࡞ࠌࠌࠍࠎࠏࠉࠤࡣࡸࡸ࡭ࡻࡲ࡭ࠢࡀࠤࡦࡻࡴࡩࡷࡵࡰ࠰࠭ࠦࡷ࠿࠴ࠫࠏࠏࠉࠊࠋࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࡀࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕࠪࠬࢁࠏࠏࠉࠊࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡒࡔࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡻࡴࡩࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ࠯ࠊࠊࠋࠌࠍࠎ࡮ࡴ࡮࡮࠶ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠍࠎࠏࠉࡤࡱࡲ࡯࡮࡫ࡳࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸ࠴ࡧࡦࡶࡢࡨ࡮ࡩࡴࠩࠫࠍࠍࠎࠏࠉࠊ࡫ࡩࠤࠬࡖࡓࡔࡋࡇࠫࠥ࡯࡮ࠡࡥࡲࡳࡰ࡯ࡥࡴ࠰࡮ࡩࡾࡹࠨࠪ࠼ࠣࠎࠎࠏࠉࠊࠋࠌࡔࡘ࡙ࡉࡅࠢࡀࠤࡨࡵ࡯࡬࡫ࡨࡷࡠ࠭ࡐࡔࡕࡌࡈࠬࡣࠊࠊࠋࠌࠍࠎࠏࡨࡦࡣࡧࡩࡷࡹ࡛ࠨࡅࡲࡳࡰ࡯ࡥࠨ࡟ࠣࡁࠥ࠭ࡐࡔࡕࡌࡈࡂ࠭ࠫࡑࡕࡖࡍࡉࠐࠉࠊࠋࠌࠍࠨ࡝ࡒࡊࡖࡈࡣ࡙ࡎࡉࡔࠪ࡫ࡸࡲࡲ࠳ࠪࠌࠌࠍࠎࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࡨࡵ࡯࡯࠷࠮ࠐࠉࠊࠋࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࡶࡸࡷ࠮ࡨࡵ࡯࡯࠷࠮࠯ࠊࠊࠋࠌࠍࠧࠨࠢℑ")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧℒ"),l11111111l_l1_,l1l1ll_l1_ (u"ࠫࠬℓ"),headers,l1l1ll_l1_ (u"ࠬ࠭℔"),l1l1ll_l1_ (u"࠭ࠧℕ"),l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ№"))
				#headers = l1l1ll_l1_ (u"ࠨࠩ℗")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ℘"),l111111ll1_l1_,l11l11l1ll_l1_,headers,l1l1ll_l1_ (u"ࠪࠫℙ"),l1l1ll_l1_ (u"ࠫࠬℚ"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨℛ"))
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪℜ"),l111l11l1l_l1_,l1l1ll_l1_ (u"ࠧࠨℝ"),headers,l1l1ll_l1_ (u"ࠨࠩ℞"),l1l1ll_l1_ (u"ࠩࠪ℟"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭℠"))
				l1l11ll1_l1_ = response.content
		l11111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ℡"),l1l11ll1_l1_,re.DOTALL)
		if l11111ll_l1_:
			l11111ll_l1_ = server+l11111ll_l1_[0]
			l111l1l_l1_,l11l1_l1_ = l11lll1lll_l1_(l11111ll_l1_,headers)
			#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭™"),str(l111l1l_l1_))
			zz = zip(l111l1l_l1_,l11l1_l1_)
			l111l1l_l1_,l11l1_l1_ = [],[]
			for title,link in zz:
				l11ll1l1_l1_ = title.split(l1l1ll_l1_ (u"࠭ࠠࠡࠩ℣"))[1]
				# l11lllll1_l1_ l1ll_l1_
				l11l1_l1_.append(link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲ࠹ࡵ࠹ࡡࡢࠫℤ")+l11ll1l1_l1_)
				# download l1ll_l1_
				l11l11l1l1_l1_ = link.replace(l1l1ll_l1_ (u"ࠨ࠱ࡶࡸࡷ࡫ࡡ࡮࠱ࠪ℥"),l1l1ll_l1_ (u"ࠩ࠲ࡨࡱ࠵ࠧΩ")).replace(l1l1ll_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰ࠲ࡲ࠹ࡵ࠹ࠩ℧"),l1l1ll_l1_ (u"ࠫࠬℨ"))
				l11l1_l1_.append(l11l11l1l1_l1_+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡼࡩࡥࡵࡷࡶࡪࡧ࡭ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫ℩")+l11ll1l1_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧK"),str(l11l1_l1_))
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧศะอีࠥอไโ์า๎ํࠦวๅ็้หุฮ࠺ࠨÅ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧℬ"),url)
	return
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࠣࠡࡰࡨࡩࡩࠦࡡࡤࡥࡲࡹࡳࡺࠠࡶࡵࡨࡶ࠴ࡶࡡࡴࡵࠍࠍࠨࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡹࡲࡶࡰࠦࡩ࡯ࠢࡤࡰࡱࠦࡣࡰࡷࡱࡸࡷ࡯ࡥࡴࠌࠌࠧࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠫࡸࡣࡷࡧ࡭ࠦ࡬ࡪࡰ࡮ࡷࠏࠏࠣࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡲࡪࡺ࠯ࡢࡲ࡬ࡃࡨࡧ࡬࡭࠿ࡓࡉࡊࡋࡪࡤࡋࡴࡉ࡯ࡋࡶࡆ࡬ࡰࡘࡵࡰࡅ࡚ࡖࡈࡺࡗ࡟ࡅࡆ࡛ࡗࡉࡲࡋࡅ࡫ࡸ࡭ࡉ࡯ࡋࡇ࡮ࡇ࡭ࡉࡻࡋࡪࡩࡍࡤࡴࡊ࡮ࡁࡤࡥ࡭ࡧ࡚ࡉࡷ࡚ࡇࡱࡨࡪࡰࡶ࡫ࡇ࡭ࡼࡎࡧࡪࡆࡸࡈ࡮࡫ࡏࡡࡊࡺࡌࡩࡒ࡮ࡶ࡚ࡇ࡭ࡺ࡯ࡋࡪࡸࡨࡶࡦࡨࡏࡰࡸࡧ࡭ࡉࡻࡳࡔࡣ࡯ࡗࡉࡲࡼࡶࡏࡤࡰࡦࡲࡨ࡭ࡉ࡬ࡈ࡮ࡹࡧࡅ࡫ࡇࡹࡉ࡯ࡳࡔࡱࡤࡺࡪࡓࡨ࡭ࡕࡣ࡭ࡺ࡯ࡋࡪࡱࡍࡓࡉ࡯ࡋࡶࡆ࡬ࡦࡱࡎࡴࡤࡦࡥ࡜ࡴࡐ࡮ࡸࡅࡇ࡭ࡺ࡯ࡋࡪࡤࡋࡻࡉ࡯ࡋࡶࡆ࡬ࡰ࡝࡞࡚ࡔࡕࡣ࡭ࡉࡧࠬࡡࡶࡶ࡫ࡁ࠵࠿ࡢ࠶ࡥ࠵࠻࠷࠻࠷࠷࠳ࡨ࠵࠹࠿ࡦ࠷࠹࠴࠼࠷࠽ࡣ࠶࠺ࡦ࠸࠷࠻࠶ࡣࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾࠲ࡸ࡭࡫ࡡࡥࡀࠣࡀࡹࡨ࡯ࡥࡻࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠢ࠿࠳ࡸࡶࡡ࡯ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࠿࠳ࡹࡪ࠾ࠡ࠾ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡࡳࡸࡥࡱ࡯ࡴࡺ࠮࡯࡭ࡳࡱ࠱࠭࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡷࡵࡢ࡮࡬ࡸࡾࠦ࠽ࠡࡳࡸࡥࡱ࡯ࡴࡺ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠠࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࡸࡶࡱ࠷ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰ࡲࡩ࡯࡭࠴ࠤࠨࠦࠫࠡࠩࠩࡺࡂ࠷ࠧࠋࠋࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱࡬ࡪࡰ࡮࠶ࠥࠩࠠࠬࠢࠪࠪࡻࡃ࠱ࠨࠌࠌࠍࠨࡻࡲ࡭ࠢࡀࠤࡺࡸ࡬ࠬࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ࠰ࡖࡈࡑࡕࡌࡈࠏࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠷ࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡸ࡬ࡨࡸࡺࡲࡦࡣࡰࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠ࡯ࡳ࠸ࡤࡥࠧࠬࡳࡸࡥࡱ࡯ࡴࡺࠫࠍࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠶࠰࠭࠿࡯ࡣࡰࡩࡩࡃࡶࡪࡦࡶࡸࡷ࡫ࡡ࡮ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱࡵ࠺࡟ࡠࠩ࠮ࡵࡺࡧ࡬ࡪࡶࡼ࠭ࠏࠏࠢࠣࠤℭ")
	l1l1ll_l1_ (u"ࠥࠦࠧࠐࠉࠤࡥࡲࡳࡰ࡯ࡥࡴࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡱ࡮࡭ࡪࡹ࠮ࡨࡧࡷࡣࡩ࡯ࡣࡵࠪࠬࠎࠎࠩࡐࡉࡒࡖࡍࡉࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡔࡍࡖࡓࡊࡆࠪࡡࠏࠏࡨࡦࡣࡧࡩࡷࡹ࠲ࠡ࠿ࠣ࡬ࡪࡧࡤࡦࡴࡶࠎࠎࠩࡨࡦࡣࡧࡩࡷࡹ࠲࡜ࠩࡆࡳࡴࡱࡩࡦࠩࡠࠤࡂࠦࠧࡑࡊࡓࡗࡎࡊ࠽ࠨ࠭ࡓࡌࡕ࡙ࡉࡅࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠶࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠴࠯ࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮࠵ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠸ࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡹࡷࡲ࠳ࠡ࠿ࠣࡷࡪࡸࡶࡦࡴ࠮࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠏࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮ࡵࡳ࡮࠶࠭ࠏࠏࠉࡻࠢࡀࠤࡿ࡯ࡰࠩࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯ࠊࠊࠋࡩࡳࡷࠦࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭ࠣ࡭ࡳࠦࡺ࠻ࠌࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡸࡀࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡷࡵࡢ࡮࡬ࡸࡾࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡓࡧࡶ࠾ࠥ࠭ࠩ࡜࠳ࡠࠎࠎࠏࠉࡦ࡮࡬ࡪࠥ࠭ࡂࡘ࠼ࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡳࡸࡥࡱ࡯ࡴࡺࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡵࡲࡩࡵࠪࠪࡆ࡜ࡀࠠࠨࠫ࡞࠵ࡢ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࡫ࡣࡲࡶࠫ࠮ࡡ࠰࡞ࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡶࡻࡡ࡭࡫ࡷࡽࠥࡃࠠࠨࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲ࠹ࡵ࠹ࡡࡢࠫ࠰ࡷࡵࡢ࡮࡬ࡸࡾ࠯ࠊࠊࠥࡨࡰࡸ࡫࠺ࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲ࠲ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࡹ࡭ࡩࡹࡴࡳࡧࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭࠴ࡷ࠻ࠫ࠮ࠐࠉࠤ࡫ࡩࠤࡳࡵࡴࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࠽ࠎࠎࠩࠉࡳࡧࡷࡹࡷࡴࠊࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡢࡲ࡬ࡃࡨࡧ࡬࡭࠿ࠪࠤ࠰ࠦࡷࡢࡶࡦ࡬࡮ࡺࡥ࡮࡝࠳ࡡࠏࠏࡅࡈࡗࡇࡍ࠱ࠦࡅࡈࡗࡖࡍࡉ࠲ࠠࡆࡉࡘࡗࡘࠦ࠽ࠡࡉࡈࡘࡤࡖࡌࡂ࡛ࡢࡘࡔࡑࡅࡏࡕࠫ࠭ࠏࠏࡩࡧࠢࡈࡋ࡚ࡊࡉ࠾࠿ࠪࠫ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࠬࡍ࡯ࡰࡩ࡯ࡩࡧࡵࡴ࠰࠴࠱࠵ࠥ࠮ࠫࡩࡶࡷࡴ࠮࠭ࠬࠡࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠡࠩࡆࡳࡴࡱࡩࡦࠩ࠽ࠫࡊࡍࡕࡅࡋࡀࠫ࠰ࡋࡇࡖࡆࡌ࠯ࠬࡁࠠࡆࡉࡘࡗࡎࡊ࠽ࠨ࠭ࡈࡋ࡚࡙ࡉࡅ࠭ࠪ࠿ࠥࡋࡇࡖࡕࡖࡁࠬ࠱ࡅࡈࡗࡖࡗࠥࢃࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࠦࡵࡳ࡮࠯ࠤࠬ࠭ࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠯ࠬࡂࡖࡊ࡙ࡏࡍࡗࡗࡍࡔࡔ࠽ࠩ࠰࠭ࡃ࠮࠲࠮ࠫࡁ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡧࡱࡵࠤࡶࡻࡡ࡭ࡶ࡬ࡽ࠱ࡻࡲ࡭ࠢ࡬ࡲࠥࡸࡥࡷࡧࡵࡷࡪࡪࠨࡪࡶࡨࡱࡸ࠯࠺ࠋࠋࠌࠍࡶࡻࡡ࡭࡫ࡷࡽࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠢࠫࠫࡲ࠹ࡵ࠹ࠢࠣࠤࠬ࠱ࡱࡶࡣ࡯ࡸ࡮ࡿࠩࠋࠋࠌࠍࡩࡧࡴࡢࡥࡤࡰࡱࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠣࠬࡺࡸ࡬ࠪࠌࠌࠧࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡࡖࡉࡑࡋࡃࡕࠪࠪหำะัࠡษ็ๅ๏ี๊้ࠢส่๊์วิส࠽ࠫ࠱ࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪࠌࠌࠧ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲ࠢ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࠩࡵࡳ࡮ࠣࡁࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡠࠎࠎ࡯ࡦࠡࠩ࡫ࡸࡹࡶࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠋࡸࡶࡱࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤࠤ࠰ࠦࠧ࠰ࡣࡳ࡭ࡄࡩࡡ࡭࡮ࡀࠫࠥ࠱ࠠ࡭࡫ࡱ࡯ࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࠬࡍ࡯ࡰࡩ࡯ࡩࡧࡵࡴ࠰࠴࠱࠵ࠥ࠮ࠫࡩࡶࡷࡴ࠮࠭ࠬࠡࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠡࠩࡆࡳࡴࡱࡩࡦࠩ࠽ࠫࡊࡍࡕࡅࡋࡀࠫ࠰ࡋࡇࡖࡆࡌ࠯ࠬࡁࠠࡆࡉࡘࡗࡎࡊ࠽ࠨ࠭ࡈࡋ࡚࡙ࡉࡅ࠭ࠪ࠿ࠥࡋࡇࡖࡕࡖࡁࠬ࠱ࡅࡈࡗࡖࡗࠥࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࠠࡶࡴ࡯࠰ࠥ࠭ࠧ࠭ࠢ࡫ࡩࡦࡪࡥࡳࡵ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ࠭ࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦࡰ࡮ࡴ࡫ࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠏࠏࠉࠤࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡢࡲ࡬ࡃࡨࡧ࡬࡭࠿ࠪࠤ࠰ࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠣࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠥ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࠬࡍ࡯ࡰࡩ࡯ࡩࡧࡵࡴ࠰࠴࠱࠵ࠥ࠮ࠫࡩࡶࡷࡴ࠮࠭ࠬࠡࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠡࠩࡆࡳࡴࡱࡩࡦࠩ࠽ࠫࡊࡍࡕࡅࡋࡀࠫ࠰ࡋࡇࡖࡆࡌ࠯ࠬࡁࠠࡆࡉࡘࡗࡎࡊ࠽ࠨ࠭ࡈࡋ࡚࡙ࡉࡅ࠭ࠪ࠿ࠥࡋࡇࡖࡕࡖࡁࠬ࠱ࡅࡈࡗࡖࡗࠥࢃࠊࠊࠋࠦࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࠡࡷࡵࡰ࠱ࠦࠧࠨ࠮ࠣ࡬ࡪࡧࡤࡦࡴࡶ࠰ࠥࡌࡡ࡭ࡵࡨ࠰ࠬ࠭ࠬࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ࠮ࠐࠉࠊࠥ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫ࡬ࡹࡳ࡬ࠪ࠮ࠣࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠣࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠏࠏࠉࠤ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡵࡳ࡮ࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠊࠊࡷࡵࡰࠥࡃࠠࡶࡴ࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࠰ࠩ࠯ࠫ࠴࠭ࠩࠋࠋࠦࡶࡪࡹࡵ࡭ࡶࠣࡁࠥࡖࡌࡂ࡛ࡢ࡚ࡎࡊࡅࡐࠪࡸࡶࡱ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࠬࡼࡩࡥࡧࡲࠫ࠮ࠐࠉࠣࠤࠥ℮")
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬℯ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭ℰ"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨℱ"),l1l1ll_l1_ (u"ࠧࠬࠩℲ"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࡃࡶࡃࠧℳ") + l11lll1_l1_
	l11l1l_l1_(url)
	return
# ===========================================
#     l1111l1ll_l1_ l1lllllll1_l1_ l1lllll1ll_l1_
# ===========================================
l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠩส่๋๎ูࠨℴ"),l1l1ll_l1_ (u"ࠪหู้ๆสࠩℵ"),l1l1ll_l1_ (u"ࠫฬ๊ศๅัࠪℶ")]
l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠬอไิ่ฬࠫℷ"),l1l1ll_l1_ (u"࠭วๅๆ฽อࠬℸ"),l1l1ll_l1_ (u"ࠧศๆห่ิ࠭ℹ"),l1l1ll_l1_ (u"ࠨษ็ำ็ฯࠧ℺"),l1l1ll_l1_ (u"ࠩส่ั๎ฯสࠩ℻"),l1l1ll_l1_ (u"ࠪห้ะัอ็ฬࠫℼ"),l1l1ll_l1_ (u"ࠫฬ๊ๆ้฻ࠪℽ"),l1l1ll_l1_ (u"ࠬอไหื้๎ๆ࠭ℾ")]
l1ll11_l1_ = []
def l1111l1l1_l1_(url):		# should be l11111ll1l_l1_ to match website l11l111l1l_l1_
	url = url.split(l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪℿ"))[0]
	#server = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ⅀"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⅁"),url,l1l1ll_l1_ (u"ࠩࠪ⅂"),headers,l1l1ll_l1_ (u"ࠪࠫ⅃"),l1l1ll_l1_ (u"ࠫࠬ⅄"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨⅅ"))
	html = response.content
	# all l1l1l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮ࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵࠥࠫⅆ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	# name + options block + category
	zz = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡷࡵࡶࡪࡴࡴࡠࡱࡳࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩⅇ"),block,re.DOTALL)
	l11l11111l_l1_,l111lll11l_l1_ = zip(*zz)
	l1111ll_l1_ = zip(l11l11111l_l1_,l111lll11l_l1_,l11l11111l_l1_)
	return l1111ll_l1_
def l1llllllll_l1_(block):		# should be l11111ll1l_l1_ to match website l11l111l1l_l1_
	# value + name
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⅈ"),block,re.DOTALL)
	l1111111l1_l1_ = []
	for link,name in items:
		name = name.strip(l1l1ll_l1_ (u"ࠩࠣࠫⅉ"))
		value = link.rsplit(l1l1ll_l1_ (u"ࠪ࠳ࠬ⅊"),1)[1]
		if name in l1ll11_l1_: continue
		if l1l1ll_l1_ (u"้๊ࠫใษษิࠫ⅋") in name: continue
		if l1l1ll_l1_ (u"࡚ࠬࡖ࠮ࡏࡄࠫ⅌") in name: continue
		if l1l1ll_l1_ (u"࠭ࡔࡗ࠯࠴࠸ࠬ⅍") in name: continue
		#if value==l1l1ll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠹ࠧⅎ"): name = l1l1ll_l1_ (u"ࠨลไ่ฬ๋ࠠ็์อๅ้้ำࠨ⅏")
		#elif value==l1l1ll_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠲ࠩ⅐"): name = l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤ๋๐สโๆๆืࠬ⅑")
		#if l1l1ll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ⅒") not in value: value = name
		#else: value = re.findall(l1l1ll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⅓"),value,re.DOTALL)[0]
		l1111111l1_l1_.append((value,name))
	return l1111111l1_l1_
def l111l11111_l1_(l1lll111_l1_,url):		# should be l11111ll1l_l1_ to match website l11l111l1l_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⅔"),l1l1ll_l1_ (u"ࠧࠨ⅕"),l1l1ll_l1_ (u"ࠨࡉࡈࡘࡤࡌࡉࡏࡃࡏࡣ࡚ࡘࡌࡠࡡࡢࡍࡓ࠭⅖"),l1lll111_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ⅗")+url)
	url = url.split(l1l1ll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⅘"),1)[0]
	url = url.strip(l1l1ll_l1_ (u"ࠫ࠴࠭⅙"))
	l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⅚"))		# l11111l111_l1_ be l11111ll1l_l1_
	l1l1l1l1_l1_ = l1l1l1l1_l1_.replace(l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪ⅛"),l1l1ll_l1_ (u"ࠧ࠮ࠩ⅜"))
	url = url+l1l1ll_l1_ (u"ࠨ࠱ࠪ⅝")+l1l1l1l1_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ⅞"),l1l1ll_l1_ (u"ࠪࠫ⅟"),l1l1ll_l1_ (u"ࠫࡌࡋࡔࡠࡈࡌࡒࡆࡒ࡟ࡖࡔࡏࡣࡤࡥࡏࡖࡖࠪⅠ"),url)
	return url
def l111l11_l1_(url,filter):		# l111l1l1l1_l1_ l1111ll11l_l1_ l111llll1l_l1_ minor l1111111ll_l1_ l1l1llllll_l1_ it is l111ll1l11_l1_ not to l11ll1l111_l1_ l11l111l11_l1_ all
	#filter = filter.replace(l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧⅡ"),l1l1ll_l1_ (u"࠭ࠧⅢ"))
	if l1l1ll_l1_ (u"ࠧࡀࠩⅣ") in url: url = url.split(l1l1ll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬⅤ"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭Ⅵ"),1)
	if filter==l1l1ll_l1_ (u"ࠪࠫⅦ"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠫࠬⅧ"),l1l1ll_l1_ (u"ࠬ࠭Ⅸ")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪⅩ"))
	if type==l1l1ll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪⅪ"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠨ࠿ࠪⅫ") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠩࡀࠫⅬ") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠪࠪࠬⅭ")+category+l1l1ll_l1_ (u"ࠫࡂ࠶ࠧⅮ")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠬࠬࠧⅯ")+category+l1l1ll_l1_ (u"࠭࠽࠱ࠩⅰ")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠩⅱ"))+l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬⅲ")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠩࠩࠫⅳ"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ⅴ")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		url2 = url+l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨⅵ")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨⅶ"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨⅷ")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_: l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪⅸ")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		if not l1l1ll1l_l1_: url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬⅹ")+l1l1ll1l_l1_
		url3 = l111l11111_l1_(l1l1ll1l_l1_,url2)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⅺ"),menu_name+l1l1ll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭ⅻ"),url3,121)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⅼ"),menu_name+l1l1ll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬⅽ")+l1l11l1l_l1_+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬⅾ"),url3,121)
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⅿ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨↀ"),l1l1ll_l1_ (u"ࠩࠪↁ"),9999)
	l1111ll_l1_ = l1111l1l1_l1_(url)
	dict = {}
	for name,block,l11111l_l1_ in l1111ll_l1_:
		l11111l_l1_ = l11111l_l1_.strip(l1l1ll_l1_ (u"ࠪࠤࠬↂ"))
		name = name.strip(l1l1ll_l1_ (u"ࠫࠥ࠭Ↄ"))
		name = name.replace(l1l1ll_l1_ (u"ࠬ࠳࠭ࠨↄ"),l1l1ll_l1_ (u"࠭ࠧↅ"))
		items = l1llllllll_l1_(block)
		if l1l1ll_l1_ (u"ࠧ࠾ࠩↆ") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫↇ"):
			if category!=l11111l_l1_: continue
			elif len(items)<2:
				if l11111l_l1_==l1ll1111_l1_[-1]:
					url3 = l111l11111_l1_(l1l1ll1l_l1_,url)
					l11l1l_l1_(url3)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨↈ")+l1ll11l1_l1_)
				return
			else:
				url3 = l111l11111_l1_(l1l1ll1l_l1_,url2)
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ↉"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ↊"),url3,121)
				else: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ↋"),menu_name+l1l1ll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ↌"),url2,125,l1l1ll_l1_ (u"ࠧࠨ↍"),l1l1ll_l1_ (u"ࠨࠩ↎"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ↏"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠪࠪࠬ←")+l11111l_l1_+l1l1ll_l1_ (u"ࠫࡂ࠶ࠧ↑")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ→")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽࠱ࠩ↓")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ↔")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↕"),menu_name+l1l1ll_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ↖")+name,url2,124,l1l1ll_l1_ (u"ࠪࠫ↗"),l1l1ll_l1_ (u"ࠫࠬ↘"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ↙"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ↚")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾ࠩ↛")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠨࠨࠪ↜")+l11111l_l1_+l1l1ll_l1_ (u"ࠩࡀࠫ↝")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ↞")+l1lll111_l1_
			#title = option+l1l1ll_l1_ (u"ࠫࠥࡀࠧ↟")#+dict[l11111l_l1_][l1l1ll_l1_ (u"ࠬ࠶ࠧ↠")]
			title = option+l1l1ll_l1_ (u"࠭ࠠ࠻ࠩ↡")+name
			if type==l1l1ll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ↢"): addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↣"),menu_name+title,url,124,l1l1ll_l1_ (u"ࠩࠪ↤"),l1l1ll_l1_ (u"ࠪࠫ↥"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭↦"))
			elif type==l1l1ll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ↧") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"࠭࠽ࠨ↨") in l1l1lll1_l1_:
				url3 = l111l11111_l1_(l1lll111_l1_,url)
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ↩"),menu_name+title,url3,121)
			else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ↪"),menu_name+title,url,125,l1l1ll_l1_ (u"ࠩࠪ↫"),l1l1ll_l1_ (u"ࠪࠫ↬"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):		# l111l11ll1_l1_ not l11ll1l111_l1_ l1111l111l_l1_ here
	# mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭↭")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ↮")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ↯")			all l1ll1l1l_l1_ & l1111l11l_l1_ filters
	filters = filters.replace(l1l1ll_l1_ (u"ࠧ࠾ࠨࠪ↰"),l1l1ll_l1_ (u"ࠨ࠿࠳ࠪࠬ↱"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠩࠩࠫ↲"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠪࡁࠬ↳") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠫࠫ࠭↴"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠬࡃࠧ↵"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"࠭ࠧ↶")
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠧ࠱ࠩ↷")
		if l1l1ll_l1_ (u"ࠨࠧࠪ↸") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ↹") and value!=l1l1ll_l1_ (u"ࠪ࠴ࠬ↺"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠥ࠱ࠠࠨ↻")+value
		elif mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ↼") and value!=l1l1ll_l1_ (u"࠭࠰ࠨ↽"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠧࠧࠩ↾")+key+l1l1ll_l1_ (u"ࠨ࠿ࠪ↿")+value
		elif mode==l1l1ll_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⇀"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠪࠪࠬ⇁")+key+l1l1ll_l1_ (u"ࠫࡂ࠭⇂")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩ⇃"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠦࠨ⇄"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠧ࠾࠲ࠪ⇅"),l1l1ll_l1_ (u"ࠨ࠿ࠪ⇆"))
	return l1llllll_l1_
l1l1ll_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡊࡉ࡙ࡥࡕࡔࡇࡕࡒࡆࡓࡅࡠࡒࡄࡗࡘ࡝ࡏࡓࡆࠫ࠭࠿ࠐࠉࡵࡧࡻࡸࠥࡃࠠࠨ้ำหࠥอไๆ๊ๅ฽ࠥ๐อหษฯࠤฬูๅࠡัั์้่ࠦไๆ่อࠥอไิำ่่ࠣ๐ࠠหีอ฻๏฿ࠠหึ฽๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠴ࠠๅๆะูํฺ๊ࠠๆํ๋๊ࠦโๆࠢหๅฯำࠠฮีสฬ๋ࠥฬศ่ํࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧࠋࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬอไๆ๊ๅ฽ࠥอไศื็๎ࠥࠦࠧࠬࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࡹ࡫ࡸࡵࠫࠍࠍࡴࡲࡤࡶࡵࡨࡶࡳࡧ࡭ࡦࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡷࡶࡩࡷ࠭ࠩࠋࠋࡲࡰࡩࡶࡡࡴࡵࡺࡳࡷࡪࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡰࡢࡵࡶࠫ࠮ࠐࠉࡹࡤࡰࡧ࠳࡫ࡸࡦࡥࡸࡸࡪࡨࡵࡪ࡮ࡷ࡭ࡳ࠮ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭ࠫࡳࠪࠩࠣࠩࡦࡪࡤࡰࡰࡢ࡭ࡩ࠲ࠠࡕࡴࡸࡩ࠮ࠐࠉ࡯ࡧࡺࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠥࡃࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡪࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡺࡹࡥࡳࠩࠬࠎࠎࡴࡥࡸࡲࡤࡷࡸࡽ࡯ࡳࡦࠣࡁࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡨࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡳࡥࡸࡹࠧࠪࠌࠌ࡭࡫ࠦ࡯࡭ࡦࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠥࡂࡴࡥࡸࡷࡶࡩࡷࡴࡡ࡮ࡧࠣࡳࡷࠦ࡯࡭ࡦࡳࡥࡸࡹࡷࡰࡴࡧࠥࡂࡴࡥࡸࡲࡤࡷࡸࡽ࡯ࡳࡦ࠽ࠎࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡄࡊࠩ࠯ࠫࠬ࠯ࠊࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡖࡍࡉ࠭ࠬࠨࠩࠬࠎࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡓࡔࠩ࠯ࠫࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠌࡧࡩ࡫ࠦࡇࡆࡖࡢࡔࡑࡇ࡙ࡠࡖࡒࡏࡊࡔࡓࠩࠫ࠽ࠎࠎࡋࡇࡖࡆࡌࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡄࡊࠩࠬࠎࠎࡋࡇࡖࡕࡌࡈࠥࡃࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡪࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡔࡋࡇࠫ࠮ࠐࠉࡆࡉࡘࡗࡘࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡋࡇࡖࡕࡖࠫ࠮ࠐࠉࡶࡵࡨࡶࡳࡧ࡭ࡦࠢࡀࠤࡒࡏࡘࡠࡃࡕࡅࡇࡏࡃࠩࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡻࡳࡦࡴࠪ࠭࠮ࠐࠉࡱࡣࡶࡷࡼࡵࡲࡥࠢࡀࠤࡒࡏࡘࡠࡃࡕࡅࡇࡏࡃࠩࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡶࡡࡴࡵࠪ࠭࠮ࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡹࡸ࡫ࡲ࡯ࡣࡰࡩ࠱ࡶࡡࡴࡵࡺࡳࡷࡪࠩࠋࠋ࡬ࡪࠥࡻࡳࡦࡴࡱࡥࡲ࡫࠽࠾ࠩࠪࠤࡴࡸࠠࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࡀࠫࠬࡀࠊࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡇࡍࠬ࠲ࠧࠨࠫࠍࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚࡙ࡉࡅࠩ࠯ࠫࠬ࠯ࠊࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡖࡗࠬ࠲ࠧࠨࠫࠍࠍࠎࡍࡅࡕࡡࡘࡗࡊࡘࡎࡂࡏࡈࡣࡕࡇࡓࡔ࡙ࡒࡖࡉ࠮ࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣ࡟ࠬ࠭ࠬࠨࠩ࠯ࠫࠬࡣࠊࠊ࡫ࡩࠤࡊࡍࡕࡅࡋࠤࡁࠬ࠭࠺ࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠡࠩࡆࡳࡴࡱࡩࡦࠩ࠽ࠫࡊࡍࡕࡅࡋࡀࠫ࠰ࡋࡇࡖࡆࡌ࠯ࠬࡁࠠࡆࡉࡘࡗࡎࡊ࠽ࠨ࠭ࡈࡋ࡚࡙ࡉࡅ࠭ࠪ࠿ࠥࡋࡇࡖࡕࡖࡁࠬ࠱ࡅࡈࡗࡖࡗࠥࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠤࠬ࠭ࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡈࡇࡗࡣࡕࡒࡁ࡚ࡡࡗࡓࡐࡋࡎࡔ࠯࠴ࡷࡹ࠭ࠩࠋࠋࠌࡶࡪ࡭ࡩࡴࡶࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡳ࡭࠰ࡨ࡫ࡪࡾࡡ࠯ࡥࡲࡱࡡ࠵ࡲࡦࡩ࡬ࡷࡹ࡫ࡲࠨ࠮ࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡳࡧࡪ࡭ࡸࡺࡥࡳ࠼ࠍࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡄࡊࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡎࡊࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡋࡇࡖࡕࡖࠫ࠱࠭ࠧࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪࡲࡴࠦ࡮ࡦࡹࠣࡰࡴ࡭ࡩ࡯ࠢࡱࡩࡪࡪࡥࡥ࠮ࠣࡽࡴࡻࠠࡸࡧࡵࡩࠥࡧ࡬ࡳࡧࡤࡨࡾࠦ࡬ࡰࡩࡪࡩࡩࠦࡩ࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡶࡪࡺࡵࡳࡰࠣ࡟ࠥࡋࡇࡖࡆࡌ࠰ࠥࡋࡇࡖࡕࡌࡈ࠱ࠦࡅࡈࡗࡖࡗࠥࡣࠊࠊࡥ࡫ࡥࡷࡥࡳࡦࡶࠣࡁࠥࡹࡴࡳ࡫ࡱ࡫࠳ࡧࡳࡤ࡫࡬ࡣࡺࡶࡰࡦࡴࡦࡥࡸ࡫ࠠࠬࠢࡶࡸࡷ࡯࡮ࡨ࠰ࡧ࡭࡬࡯ࡴࡴࠢ࠮ࠤࡸࡺࡲࡪࡰࡪ࠲ࡦࡹࡣࡪ࡫ࡢࡰࡴࡽࡥࡳࡥࡤࡷࡪࠐࠉࡳࡣࡱࡨࡴࡳࡓࡵࡴ࡬ࡲ࡬ࠦ࠽ࠡࠩࠪ࠲࡯ࡵࡩ࡯ࠪࡵࡥࡳࡪ࡯࡮࠰ࡶࡥࡲࡶ࡬ࡦࠪࡦ࡬ࡦࡸ࡟ࡴࡧࡷ࠮࠶࠻ࠬࠡ࠳࠸࠭࠮ࠐࠉࡶࡴ࡯ࠤࡂࠦࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡶࡰ࠳࡫ࡧࡦࡺࡤ࠲ࡨࡵ࡭࠰࡮ࡲ࡫࡮ࡴ࠯ࠣࠌࠌࠧࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠠ࠾ࠢࠪ࠴࠸ࡇࡏࡍࡖࡅࡐࡖࡊࡴ࡮ࡧࡌࡧ࡙࠾ࡌ࠶࠻ࡇࡴࡿࡴࡇ࠱ࡲ࠴࡛ࡈࡱࡨࡩࡷࡰ࡬ࡪࡱࡡ࡮࡚ࡒࡨࡆ࠷࡫࠺ࡍ࠹ࡧࡘࡻ࡟ࡆ࡛ࡤࡸࡻࡰࡈ࠮ࡔࡳ࡯ࡍࡴࡑࡩ࠶ࡗࡏ࡭ࡐ࡬࠹ࡔ࡙ࡺࡸࡥࡩࡱࡺ࡭ࡧ࠻ࡰࡉࡦࡃ࡜ࡖࡩࡨࡧࡦࡡࡊࡶࡖࡪࡶࡕ࠶ࡺࡌ࡜ࡳ࡟ࡍࡸ࠹ࡐ࠷࠹࡚ࡆࡩࡉࡓࡱࡾࡨࡢࡸ࡙࡬ࡼ࡮ࡱ࠳ࡑࡨࡈࡌࡑ࠭ࡣࡱࡱࡗࡘ࡙ࡉࡖ࠶ࡴ࡭ࡍࡕࡴࡓࡨࡥࡻ࡜࠾ࡊࡧࡊࡑ࠱ࡎࢀࡸࡣ࠯ࡗࡼࡒ࠼ࡏࡘ࡜ࡏ࠶࡯ࡻࡈࡺࡩ࡯࡮ࡲࡌࡃ࡫ࡈ࡛࠹ࡊࡥࡴࡧ࡛࠵࡜ࡏࡼࡍࡲࡉࡖ࡮࡭ࡌࡡ࠶ࡺ࡜ࡻࡦࡺࡘ࠮ࡥࡰࡴ࡝࠽ࡘ࠱ࡏࡼ࠽ࡖ࠽࡭࡬ࡲࡸ࠼࠻ࡇ࠭ࡋ࡯࡛ࡸࡨࡵࡴࡤ࡚ࡲࡒ࠻࡝ࡁ࡮ࡘࡺ࡙࡞ࡵ࡭ࡍࡒࡓ࡝ࡽࡶࡦࡢࡲࡍࡲ࡫࡝ࡘ࠴ࡄࡺ࠼࠸࠹࡙ࡌࡆࡢࡆࡉ࡝ࡷࡷࡖ࡛࡮࡫࡝࡟ࡑࡧࡑ࡙ࡩࡐࡈ࠸ࡈࡺࡐ࠾ࡺ࡮࠶ࡡࡪ࡬ࡉࡷࡖࡦࡡ࡯ࡕࡰ࡮ࡰ࠷ࡱࡲ࡜ࡲ࡜ࡴ࡫ࡏࡄࡲ࠾ࡥࡍ࠵ࠩࠍࠍࠨࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠡ࠿ࠣࠫࠬࠐࠉࡱࡣࡼࡰࡴࡧࡤࠡ࠿ࠣࠦࠧࠐࠉࡱࡣࡼࡰࡴࡧࡤࠡ࠭ࡀࠤࠧ࠳࠭࠮࠯࠰࠱࡜࡫ࡢࡌ࡫ࡷࡊࡴࡸ࡭ࡃࡱࡸࡲࡩࡧࡲࡺࠤ࠮ࡶࡦࡴࡤࡰ࡯ࡖࡸࡷ࡯࡮ࡨ࠭ࠥࡠࡳࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡄࡪࡵࡳࡳࡸ࡯ࡴࡪࡱࡱ࠾ࠥ࡬࡯ࡳ࡯࠰ࡨࡦࡺࡡ࠼ࠢࡱࡥࡲ࡫࠽࡝ࠤࡤ࡮ࡦࡾ࡜ࠣ࡞ࡱࡠࡳ࠷࡜࡯ࠤࠍࠍࡵࡧࡹ࡭ࡱࡤࡨࠥ࠱࠽ࠡࠤ࠰࠱࠲࠳࠭࠮࡙ࡨࡦࡐ࡯ࡴࡇࡱࡵࡱࡇࡵࡵ࡯ࡦࡤࡶࡾࠨࠫࡳࡣࡱࡨࡴࡳࡓࡵࡴ࡬ࡲ࡬࠱ࠢ࡝ࡰࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡈ࡮ࡹࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠻ࠢࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦ࡮ࡢ࡯ࡨࡁࡡࠨࡤࡰ࡞ࠥࡠࡳࡢ࡮࡭ࡱࡪ࡭ࡳࡢ࡮ࠣࠌࠌࡴࡦࡿ࡬ࡰࡣࡧࠤ࠰ࡃࠠࠣ࠯࠰࠱࠲࠳࠭ࡘࡧࡥࡏ࡮ࡺࡆࡰࡴࡰࡆࡴࡻ࡮ࡥࡣࡵࡽࠧ࠱ࡲࡢࡰࡧࡳࡲ࡙ࡴࡳ࡫ࡱ࡫࠰ࠨ࡜࡯ࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡇ࡭ࡸࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴ࠺ࠡࡨࡲࡶࡲ࠳ࡤࡢࡶࡤ࠿ࠥࡴࡡ࡮ࡧࡀࡠࠧ࡫࡭ࡢ࡫࡯ࡠࠧࡢ࡮࡝ࡰࠥ࠯ࡺࡹࡥࡳࡰࡤࡱࡪ࠱ࠢ࡝ࡰࠥࠎࠎࡶࡡࡺ࡮ࡲࡥࡩࠦࠫ࠾ࠢࠥ࠱࠲࠳࠭࠮࠯࡚ࡩࡧࡑࡩࡵࡈࡲࡶࡲࡈ࡯ࡶࡰࡧࡥࡷࡿࠢࠬࡴࡤࡲࡩࡵ࡭ࡔࡶࡵ࡭ࡳ࡭ࠫࠣ࡞ࡱࡇࡴࡴࡴࡦࡰࡷ࠱ࡉ࡯ࡳࡱࡱࡶ࡭ࡹ࡯࡯࡯࠼ࠣࡪࡴࡸ࡭࠮ࡦࡤࡸࡦࡁࠠ࡯ࡣࡰࡩࡂࡢࠢࡱࡣࡶࡷࡼࡵࡲࡥ࡞ࠥࡠࡳࡢ࡮ࠣ࠭ࡳࡥࡸࡹࡷࡰࡴࡧ࠯ࠧࡢ࡮ࠣࠌࠌࠧࡵࡧࡹ࡭ࡱࡤࡨࠥ࠱࠽ࠡࠤ࠰࠱࠲࠳࠭࠮࡙ࡨࡦࡐ࡯ࡴࡇࡱࡵࡱࡇࡵࡵ࡯ࡦࡤࡶࡾࠨࠫࡳࡣࡱࡨࡴࡳࡓࡵࡴ࡬ࡲ࡬࠱ࠢ࡝ࡰࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡈ࡮ࡹࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠻ࠢࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦ࡮ࡢ࡯ࡨࡁࡡࠨࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡢࠢ࡝ࡰ࡟ࡲࠧ࠱ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠭ࠥࡠࡳࠨࠊࠊࡲࡤࡽࡱࡵࡡࡥࠢ࠮ࡁࠥࠨ࠭࠮࠯࠰࠱࠲࡝ࡥࡣࡍ࡬ࡸࡋࡵࡲ࡮ࡄࡲࡹࡳࡪࡡࡳࡻࠥ࠯ࡷࡧ࡮ࡥࡱࡰࡗࡹࡸࡩ࡯ࡩ࠮ࠦࡡࡴࡃࡰࡰࡷࡩࡳࡺ࠭ࡅ࡫ࡶࡴࡴࡹࡩࡵ࡫ࡲࡲ࠿ࠦࡦࡰࡴࡰ࠱ࡩࡧࡴࡢ࠽ࠣࡲࡦࡳࡥ࠾࡞ࠥࡺࡦࡲࡆࡰࡴࡰࡠࠧࡢ࡮࡝ࡰ࡟ࡲࠧࠐࠉࡱࡣࡼࡰࡴࡧࡤࠡ࠭ࡀࠤࠧ࠳࠭࠮࠯࠰࠱࡜࡫ࡢࡌ࡫ࡷࡊࡴࡸ࡭ࡃࡱࡸࡲࡩࡧࡲࡺࠤ࠮ࡶࡦࡴࡤࡰ࡯ࡖࡸࡷ࡯࡮ࡨ࠭ࠥ࠱࠲ࠨࠊࠊࠥࡻࡦࡲࡩ࠮࡭ࡱࡪࠬࡵࡧࡹ࡭ࡱࡤࡨ࠱ࠦ࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀࠐࠉࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࠻ࠢࠥࡱࡺࡲࡴࡪࡲࡤࡶࡹ࠵ࡦࡰࡴࡰ࠱ࡩࡧࡴࡢ࠽ࠣࡦࡴࡻ࡮ࡥࡣࡵࡽࡂ࠳࠭࠮࠯࡚ࡩࡧࡑࡩࡵࡈࡲࡶࡲࡈ࡯ࡶࡰࡧࡥࡷࡿࠢࠬࡴࡤࡲࡩࡵ࡭ࡔࡶࡵ࡭ࡳ࡭ࠬࠋࠋࠦࠫࡈࡵ࡯࡬࡫ࡨࠫ࠿ࠦࠢࡑࡕࡖࡍࡉࡃࠢࠬࡒࡖࡗࡎࡊࠫࠣ࠽ࠣࡎࡘࡥࡔࡊࡏࡈ࡞ࡔࡔࡅࡠࡑࡉࡊࡘࡋࡔ࠾࠳࠻࠴࠵࠶ࠢ࠭ࠌࠌࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡷࡱ࠴ࡥࡨࡧࡻࡥ࠳ࡩ࡯࡮࠱࡯ࡳ࡬࡯࡮࠰ࡁࡧࡳࡲࡧࡩ࡯࠿ࠪ࠯ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰࠱ࠪ࠭ࡠ࠷࡝ࠬࠩࠩࡹࡷࡲ࠽ࡳࡧࡩࠫࠏࠏࡽࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡒࡒࡗ࡙࠭ࠬࠡࡷࡵࡰ࠱ࠦࡰࡢࡻ࡯ࡳࡦࡪࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡈࡇࡗࡣࡕࡒࡁ࡚ࡡࡗࡓࡐࡋࡎࡔ࠯࠵ࡲࡩ࠭ࠩࠋࠋࡦࡳࡴࡱࡩࡦࡵࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡲ࡯࡮࡫ࡳ࠯ࡩࡨࡸࡤࡪࡩࡤࡶࠫ࠭ࠏࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸ࠱ࠦ࡬ࡦࡸࡨࡰࡂࡾࡢ࡮ࡥ࠱ࡐࡔࡍࡎࡐࡖࡌࡇࡊ࠯ࠊࠊ࡫ࡩࠤࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠣࡥࡤࡴࡹࡩࡨࡢࠤࠪࠤ࡮ࡴࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶ࠽ࠎࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱ุ่่๊࠭ࠧ࠭ࠩษࠡฮาห๋ࠥาฺฮฬࠤฯิีࠡฮ๊หื้ࠠโไฺࠫ࠱࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะ๋ࠠำไฺࠥีฮ้ๆๆࠤฬ๊๊่็ࠣฬสูสฯัส้้่ࠥะ์ࠣ࠲࠳࠴ࠠฮษ๋่ࠥ็ีๅࠢส่ฬ์สา่ํฮࠥ๎วฺษาอࠥืศุ้สࠤ้ะอึๆࠣ฽้๏ฺ่๋ࠠห๋ࠦࡉࡑࠢฯำ๏ีࠠ࠯࠰࠱ࠤฬ๎ࠠศ฻าࠤฬ๊ๅฮษ๋่ฮࠦศฺัࠣ฽ิฯࠠศ์ส้ࠥอ่ࠡ฻าอࠥอำศสํ฽ࠬ࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢ࡞ࠫࠬ࠲ࠧࠨ࠮ࠪࠫࡢࠐࠉࡪࡨࠣࡰࡪࡴࠨࡤࡱࡲ࡯࡮࡫ࡳࠪ࠾࠶࠾ࠏࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ู้้ࠪไสࠢไ๎ࠥะำอ์็ࠤฬ๊ฯฯ๊็ࠤ้๊ๅ้ไ฼ࠫ࠱࠭อศ๊็ࠤฬ฻ไศฯࠣหุ๋ࠠศๆาาํ๊้ࠠๅ็้ฮࠦวๅีิࠤ้้๊ࠡฬอ้่์ࠠๆ่ࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠣฬฺ๎ัสุࠢั๏ำษࠨࠫࠍࠍࠎࡍࡅࡕࡡࡘࡗࡊࡘࡎࡂࡏࡈࡣࡕࡇࡓࡔ࡙ࡒࡖࡉ࠮ࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠣ࡟ࠬ࠭ࠬࠨࠩ࠯ࠫࠬࡣࠊࠊࡇࡊ࡙ࡉࡏࠠ࠾ࠢࡦࡳࡴࡱࡩࡦࡵ࡞ࠫࡊࡍࡕࡅࡋࠪࡡࠏࠏࡅࡈࡗࡖࡍࡉࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡉࡌ࡛ࡓࡊࡆࠪࡡࠏࠏࡅࡈࡗࡖࡗࠥࡃࠠࡤࡱࡲ࡯࡮࡫ࡳ࡜ࠩࡈࡋ࡚࡙ࡓࠨ࡟ࠍࠍࡹ࡯࡭ࡦ࠰ࡶࡰࡪ࡫ࡰࠩ࠳ࠬࠎࠎࡻࡲ࡭ࠢࡀࠤࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡴ࡮࠱ࡩ࡬࡫ࡸࡢ࠰ࡦࡳࡲ࠵ࡦࡪࡰ࡬ࡷ࡭࠵ࠢࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠠࠨࡅࡲࡳࡰ࡯ࡥࠨ࠼ࠪࡉࡌ࡛ࡄࡊ࠿ࠪ࠯ࡊࡍࡕࡅࡋ࠮ࠫࡀࠦࡅࡈࡗࡖࡍࡉࡃࠧࠬࡇࡊ࡙ࡘࡏࡄࠬࠩ࠾ࠤࡊࡍࡕࡔࡕࡀࠫ࠰ࡋࡇࡖࡕࡖࠤࢂࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࠥࡻࡲ࡭࠮ࠣࠫࠬ࠲ࠠࡩࡧࡤࡨࡪࡸࡳ࠭ࠢࡗࡶࡺ࡫ࠬࠨࠩ࠯ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡍࡅࡕࡡࡓࡐࡆ࡟࡟ࡕࡑࡎࡉࡓ࡙࠭࠴ࡴࡧࠫ࠮ࠐࠉࡤࡱࡲ࡯࡮࡫ࡳࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸ࠴ࡧࡦࡶࡢࡨ࡮ࡩࡴࠩࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡴࡶࡵࠬࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠩ࠭ࡵࡷࡶ࠭ࡩ࡯ࡰ࡭࡬ࡩࡸ࠯ࠩࠋࠋࡈࡋ࡚ࡊࡉࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡋࡇࡖࡆࡌࠫࡢࠐࠉࡆࡉࡘࡗࡎࡊࠠ࠾ࠢࡦࡳࡴࡱࡩࡦࡵ࡞ࠫࡊࡍࡕࡔࡋࡇࠫࡢࠐࠉࡆࡉࡘࡗࡘࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡉࡌ࡛ࡓࡔࠩࡠࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚ࡊࡉࠨ࠮ࡈࡋ࡚ࡊࡉࠪࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡎࡊࠧ࠭ࡇࡊ࡙ࡘࡏࡄࠪࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡘ࠭ࠬࡆࡉࡘࡗࡘ࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬࡹࡵࡤࡥࡨࡷࡸ࠲ࠠࡺࡱࡸࠤ࡯ࡻࡳࡵࠢ࡯ࡳ࡬࡭ࡥࡥࠢ࡬ࡲࠥࡴ࡯ࡸࠩ࠯ࠫࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡ࡝ࠣࡉࡌ࡛ࡄࡊ࠮ࠣࡉࡌ࡛ࡓࡊࡆ࠯ࠤࡊࡍࡕࡔࡕࠣࡡࠏࠨࠢࠣ⇇")
#===================================================================================================
# l1111lll1l_l1_ of the l1111l1l1l_l1_ code l11111lll1_l1_ added from:
# l1lll11l_l1_://l1111l11l1_l1_.l1lll1ll1_l1_/l111111lll_l1_/l1111lll11_l1_-l1111l1ll1_l1_/l111l11lll_l1_/l111ll1111_l1_/l1111l1111_l1_.l11lll11l1_l1_.l111lll1ll_l1_/l111l1l111_l1_/l111ll1lll_l1_/l111lllll1_l1_.py
# l1lll11l_l1_://l111llll11_l1_.l1lll1ll1_l1_/l11111l1l1_l1_/l1111lllll_l1_-host-l11111llll_l1_/-/l111l11lll_l1_/l111ll1111_l1_/l111111l1l_l1_/l11111l1ll_l1_/l1111ll111_l1_/l111l1l1ll_l1_.py
#===================================================================================================
def l11l1111l1_l1_(l111l1l11l_l1_):
	m = re.search(l1l1ll_l1_ (u"ࡵࠫࡣ࠮࡜ࡥ࠭ࠬ࡟࠳࠲࡝ࡀ࡞ࡧ࠮ࡄ࠭⇈"), str(l111l1l11l_l1_))
	return int(m.groups()[-1]) if m and not callable(l111l1l11l_l1_) else 0
def l11l111ll1_l1_(l111l1111l_l1_):
	try:
		l111ll1ll1_l1_ = base64.b64decode(l111l1111l_l1_)
	except:
		try:
			l111ll1ll1_l1_ = base64.b64decode(l111l1111l_l1_+l1l1ll_l1_ (u"ࠫࡂ࠭⇉"))
		except:
			try:
				l111ll1ll1_l1_ = base64.b64decode(l111l1111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠽ࠨ⇊"))
			except:
				l111ll1ll1_l1_ = l1l1ll_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡧࡧࡳࡦ࠸࠷ࠤࡩ࡫ࡣࡰࡦࡨࠤࡪࡸࡲࡰࡴࠪ⇋")
	if kodi_version>18.99: l111ll1ll1_l1_ = l111ll1ll1_l1_.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⇌"))
	return l111ll1ll1_l1_
def l1111l1l11_l1_(l111ll1l1l_l1_,l111l1llll_l1_,a):
	a = a - l111l1llll_l1_
	if a<0:
		c = l1l1ll_l1_ (u"ࠨࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠫ⇍")
	else:
		c = l111ll1l1l_l1_[a]
	return c
def x(l111ll1l1l_l1_,l111l1llll_l1_,a):
	return(l1111l1l11_l1_(l111ll1l1l_l1_,l111l1llll_l1_,a))
def l111ll11l1_l1_(tab,step,l111l1llll_l1_,l111l111l1_l1_):
	l111l111l1_l1_ = l111l111l1_l1_.replace(l1l1ll_l1_ (u"ࠩࡹࡥࡷࠦࠧ⇎"),l1l1ll_l1_ (u"ࠪ࡫ࡱࡵࡢࡢ࡮ࠣࡨࡀࠦࠧ⇏"))
	l111l111l1_l1_ = l111l111l1_l1_.replace(l1l1ll_l1_ (u"ࠫࡽ࠮ࠧ⇐"),l1l1ll_l1_ (u"ࠬࡾࠨࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠫ⇑"))
	#exec(l111l111l1_l1_)
	l111l111l1_l1_ = l111l111l1_l1_.replace(l1l1ll_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡤ࠼ࠢࡧࡁࠬ⇒"),l1l1ll_l1_ (u"ࠧࠨ⇓"))
	d = eval(l111l111l1_l1_,{l1l1ll_l1_ (u"ࠨࡲࡤࡶࡸ࡫ࡉ࡯ࡶࠪ⇔"):l11l1111l1_l1_,l1l1ll_l1_ (u"ࠩࡻࠫ⇕"):x,l1l1ll_l1_ (u"ࠪࡸࡦࡨࠧ⇖"):tab,l1l1ll_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪ⇗"):l111l1llll_l1_})
	l11l11lll1_l1_=0
	while True:
		l11l11lll1_l1_=l11l11lll1_l1_+1
		tab.append(tab[0])
		del tab[0]
		#_print([i for i in tab[0:10]])
		#_print(str(l11l11lll1_l1_)+l1l1ll_l1_ (u"ࠬࡀࠧ⇘")+str(c))
		#exec(l111l111l1_l1_)
		d = eval(l111l111l1_l1_,{l1l1ll_l1_ (u"࠭ࡰࡢࡴࡶࡩࡎࡴࡴࠨ⇙"):l11l1111l1_l1_,l1l1ll_l1_ (u"ࠧࡹࠩ⇚"):x,l1l1ll_l1_ (u"ࠨࡶࡤࡦࠬ⇛"):tab,l1l1ll_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨ⇜"):l111l1llll_l1_})
		if ((d == step) or (l11l11lll1_l1_>10000)): break
	return
def l1111l1lll_l1_(l111ll11ll_l1_):
	tmp = re.findall(l1l1ll_l1_ (u"ࠪࡺࡦࡸ࠮ࠫࡁࡀࠬ࠳ࢁ࠲࠭࠶ࢀ࠭ࡡ࠮࡜ࠪࠩ⇝"), l111ll11ll_l1_, re.S)
	if not tmp: return l1l1ll_l1_ (u"ࠫࡊࡘࡒ࠻ࡘࡤࡶࡨࡵ࡮ࡴࡶࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭⇞")
	l11111ll11_l1_ = tmp[0].strip()
	_print(l1l1ll_l1_ (u"ࠬ࡜ࡡࡳࡥࡲࡲࡸࡺࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩ⇟") % l11111ll11_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"࠭ࡽ࡝ࠪࠪ⇠")+l11111ll11_l1_+l1l1ll_l1_ (u"ࠧࡀ࠮ࠫ࠴ࡽࡡ࠰࠮࠻ࡤ࠱࡫ࡣࡻ࠲࠮࠴࠴ࢂ࠯࡜ࠪ࡞ࠬ࠿ࠬ⇡"), l111ll11ll_l1_)
	if not tmp: return l1l1ll_l1_ (u"ࠨࡇࡕࡖ࠿ࠦࡓࡵࡧࡳ࠵ࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ⇢")
	step = eval(tmp[0])
	_print(l1l1ll_l1_ (u"ࠩࡖࡸࡪࡶ࠱ࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣ࠴ࡽࠫࡳࠨ⇣") % l1l1ll_l1_ (u"ࠪࡿ࠿࠶࠲࡙ࡿࠪ⇤").format(step).lower())
	tmp = re.findall(l1l1ll_l1_ (u"ࠫࡩࡃࡤ࠮ࠪ࠳ࡼࡠ࠶࠭࠺ࡣ࠰ࡪࡢࢁ࠱࠭࠳࠳ࢁ࠮ࡁࠧ⇥"), l111ll11ll_l1_)
	if not tmp: return l1l1ll_l1_ (u"ࠬࡋࡒࡓ࠼ࡖࡸࡪࡶ࠲ࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ⇦")
	l111l1llll_l1_ = eval(tmp[0])
	_print(l1l1ll_l1_ (u"࠭ࡓࡵࡧࡳ࠶ࠥࠦࠠࠡࠢࠣࠤࠥࡃࠠ࠱ࡺࠨࡷࠬ⇧") % l1l1ll_l1_ (u"ࠧࡼ࠼࠳࠶࡝ࢃࠧ⇨").format(l111l1llll_l1_).lower())
	tmp = re.findall(l1l1ll_l1_ (u"ࠣࡶࡵࡽࢀ࠮ࡶࡢࡴ࠱࠮ࡄ࠯࠻ࠣ⇩"), l111ll11ll_l1_)
	if not tmp: return l1l1ll_l1_ (u"ࠩࡈࡖࡗࡀࡤࡦࡥࡤࡰࡤ࡬࡮ࡤࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬ⇪")
	l111l111l1_l1_ = tmp[0]
	_print(l1l1ll_l1_ (u"ࠪࡈࡪࡩࡡ࡭ࠢࡩࡹࡳࡩࠠࠡࠢࡀࠤࠧࠦࠥࡴ࠰࠱࠲ࠧ࠭⇫") % l111l111l1_l1_[0:135])
	tmp = re.findall(l1l1ll_l1_ (u"ࠦࠬࡪࡡࡵࡣࠪ࠾ࢀ࠭ࠨࡠ࡝࠳࠱࠾ࡧ࠭ࡻࡃ࠰࡞ࡢࢁ࠱࠱࠮࠵࠴ࢂ࠯ࠧ࠻ࠩࡲ࡯ࠬࠨ⇬"), l111ll11ll_l1_)
	if not tmp: return l1l1ll_l1_ (u"ࠬࡋࡒࡓ࠼ࡓࡳࡸࡺࡋࡦࡻࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭⇭")
	l111llllll_l1_ = tmp[0]
	_print(l1l1ll_l1_ (u"࠭ࡐࡰࡵࡷࡏࡪࡿࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪ⇮") % l111llllll_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"ࠢࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࠥ⇯")+l11111ll11_l1_+l1l1ll_l1_ (u"ࠣ࠰࠭ࡃࡻࡧࡲ࠯ࠬࡂࡁ࠭ࡢ࡛࠯ࠬࡂࡡ࠮ࠨ⇰"), l111ll11ll_l1_)
	if not tmp: return l1l1ll_l1_ (u"ࠩࡈࡖࡗࡀࡔࡢࡤࡏ࡭ࡸࡺࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪ⇱")
	l111l1ll11_l1_ = tmp[0]
	l111l1ll11_l1_ = l11111ll11_l1_ + l1l1ll_l1_ (u"ࠥࡁࠧ⇲") + l111l1ll11_l1_
	exec(l111l1ll11_l1_) in globals(), locals()
	l111ll1l1l_l1_ = locals()[l11111ll11_l1_]
	_print(l11111ll11_l1_+l1l1ll_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫ⇳")%str(l111ll1l1l_l1_))
	l111ll11l1_l1_(l111ll1l1l_l1_,step,l111l1llll_l1_,l111l111l1_l1_)
	_print(l11111ll11_l1_+l1l1ll_l1_ (u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣࠩ࠳࠿࠰ࡴ࠰࠱࠲ࠬ⇴")%str(l111ll1l1l_l1_))
	tmp = re.findall(l1l1ll_l1_ (u"ࠨ࡜ࠩ࡞ࠬ࠿࠭ࡼࡡࡳࠢ࠱࠮ࡄ࠯࡜ࠥ࡞ࠫࠫࡡ࠰ࠧ࡝ࠫࠥ⇵"), l111ll11ll_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l1ll_l1_ (u"ࠢࡢ࠲ࡤࡠ࠭ࡢࠩ࠼ࠪ࠱࠮ࡄ࠯࡜ࠥ࡞ࠫࠫࡡ࠰ࠧ࡝ࠫࠥ⇶"), l111ll11ll_l1_, re.S)
		if not tmp:
			return l1l1ll_l1_ (u"ࠨࡇࡕࡖ࠿ࡒࡩࡴࡶࡢ࡚ࡦࡸࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪ⇷")
	l11l11ll1l_l1_ = tmp[0]
	l11l11ll1l_l1_ = re.sub(l1l1ll_l1_ (u"ࠤࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࠥ࠴ࠪࡀࡿ࠱࠮ࡄࢃࠩࠣ⇸"), l1l1ll_l1_ (u"ࠥࠦ⇹"), l11l11ll1l_l1_)
	_print(l1l1ll_l1_ (u"ࠫࡑ࡯ࡳࡵࡡ࡙ࡥࡷࠦࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧ⇺") % l11l11ll1l_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"ࠧ࠮࡟࡜ࡣ࠰ࡾࡆ࠳ࡺ࠱࠯࠼ࡡࢀ࠺ࠬ࠹ࡿࠬࡁࡡࡡ࡜࡞ࠤ⇻") , l11l11ll1l_l1_)
	if not tmp: return l1l1ll_l1_ (u"࠭ࡅࡓࡔ࠽࠷࡛ࡧࡲࡴࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬ⇼")
	_111l1ll1l_l1_ = tmp
	_print(l1l1ll_l1_ (u"ࠧ࠴ࡘࡤࡶࡸࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ⇽")%str(_111l1ll1l_l1_))
	l111lll1l1_l1_ = _111l1ll1l_l1_[1]
	_print(l1l1ll_l1_ (u"ࠨࡤ࡬࡫ࡤࡹࡴࡳࡡࡹࡥࡷࠦࠠ࠾ࠢࠨࡷࠬ⇾")%l111lll1l1_l1_)
	l11l11ll1l_l1_ = l11l11ll1l_l1_.replace(l1l1ll_l1_ (u"ࠩ࠯ࠫ⇿"),l1l1ll_l1_ (u"ࠪ࠿ࠬ∀")).split(l1l1ll_l1_ (u"ࠫࡀ࠭∁"))
	for l111l1111l_l1_ in l11l11ll1l_l1_:
		l111l1111l_l1_ = l111l1111l_l1_.strip()
		if l1l1ll_l1_ (u"ࠬ࡯ࡳ࡮ࡱࡥࠫ∂") in l111l1111l_l1_: l111l1111l_l1_=l1l1ll_l1_ (u"࠭ࠧ∃")
		if l1l1ll_l1_ (u"ࠧ࠾࡝ࡠࠫ∄")   in l111l1111l_l1_: l111l1111l_l1_ = l111l1111l_l1_.replace(l1l1ll_l1_ (u"ࠨ࠿࡞ࡡࠬ∅"),l1l1ll_l1_ (u"ࠩࡀࡿࢂ࠭∆"))
		l111l1111l_l1_ = re.sub(l1l1ll_l1_ (u"ࠥࠬࡦ࠶࠮࡝ࠪࠬࠦ∇"), l1l1ll_l1_ (u"ࠦࡦ࠶ࡤࠩ࡯ࡤ࡭ࡳࡥࡴࡢࡤ࠯ࡷࡹ࡫ࡰ࠳࠮ࠥ∈"), l111l1111l_l1_)
		#if l1l1ll_l1_ (u"ࠬࡧ࠰ࡈࠪࠪ∉")  in l111l1111l_l1_: l111l1111l_l1_ = l111l1111l_l1_.replace(l1l1ll_l1_ (u"࠭ࡡ࠱ࡉࠫࠫ∊"),l1l1ll_l1_ (u"ࠧࡢ࠲ࡊࠬࡲࡧࡩ࡯ࡡࡷࡥࡧ࠲ࡳࡵࡧࡳ࠶࠱࠭∋"))
		if l111l1111l_l1_!=l1l1ll_l1_ (u"ࠨࠩ∌"):
			#_print(l1l1ll_l1_ (u"ࠩࡨࡰࡲࠦ࠽ࠡࠧࡶࠫ∍") % l111l1111l_l1_)
			l111l1111l_l1_ = l111l1111l_l1_.replace(l1l1ll_l1_ (u"ࠪࠥࠦࡡ࡝ࠨ∎"),l1l1ll_l1_ (u"࡙ࠫࡸࡵࡦࠩ∏"));
			l111l1111l_l1_ = l111l1111l_l1_.replace(l1l1ll_l1_ (u"࡛ࠬࠧ࡞ࠩ∐"),l1l1ll_l1_ (u"࠭ࡆࡢ࡮ࡶࡩࠬ∑"));
			l111l1111l_l1_ = l111l1111l_l1_.replace(l1l1ll_l1_ (u"ࠧࡷࡣࡵࠤࠬ−"),l1l1ll_l1_ (u"ࠨࠩ∓"));
			#_print(l1l1ll_l1_ (u"ࠩࡨࡰࡲࠦ࠽ࠡࠧࡶࠫ∔") % l111l1111l_l1_)
			try:
				exec(l111l1111l_l1_,{l1l1ll_l1_ (u"ࠪࡴࡦࡸࡳࡦࡋࡱࡸࠬ∕"):l11l1111l1_l1_,l1l1ll_l1_ (u"ࠫࡦࡺ࡯ࡣࠩ∖"):l11l111ll1_l1_,l1l1ll_l1_ (u"ࠬࡧ࠰ࡥࠩ∗"):l1111l1l11_l1_,l1l1ll_l1_ (u"࠭ࡸࠨ∘"):x,l1l1ll_l1_ (u"ࠧ࡮ࡣ࡬ࡲࡤࡺࡡࡣࠩ∙"):l111ll1l1l_l1_,l1l1ll_l1_ (u"ࠨࡵࡷࡩࡵ࠸ࠧ√"):l111l1llll_l1_},locals())
			except:
				#_print(l1l1ll_l1_ (u"ࠩࡨࡰࡲࠦ࠽ࠡࠧࡶࠫ∛") % l111l1111l_l1_)
				#_print(l1l1ll_l1_ (u"ࠪࡺࠥࡃࠠࠣࠧࡶࠦࠥ࡫ࡸࡦࡥࠣࡴࡷࡵࡢ࡭ࡧࡰࠥࠬ∜") % l111l1111l_l1_, sys.exc_info()[0])
				pass
	l11l11l111_l1_ = l1l1ll_l1_ (u"ࠫࠬ∝")
	for i in range(0,len(locals()[_111l1ll1l_l1_[2]])):
		if locals()[_111l1ll1l_l1_[2]][i] in locals()[_111l1ll1l_l1_[1]]:
			l11l11l111_l1_ = l11l11l111_l1_ + locals()[_111l1ll1l_l1_[1]][locals()[_111l1ll1l_l1_[2]][i]]
	_print(l1l1ll_l1_ (u"ࠬࡨࡩࡨࡕࡷࡶ࡮ࡴࡧࠡࠢࠣࠤࡂࠦࠥ࠯࠻࠳ࡷ࠳࠴࠮ࠨ∞")%l11l11l111_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"࠭ࡶࡢࡴࠣࡦࡂࡢࠧ࠰࡞ࠪࡠ࠰࠮࠮ࠫࡁࠬࠬࡄࡀࠬࡽ࠽ࠬࠫ∟"), l111ll11ll_l1_, re.S)
	if not tmp: return l1l1ll_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡍࡥࡵࡗࡵࡰࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ∠")
	l111l111ll_l1_ = str(tmp[0])
	_print(l1l1ll_l1_ (u"ࠨࡉࡨࡸ࡚ࡸ࡬ࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ∡") % l111l111ll_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"ࠩࠫࡣ࠳࠰࠿ࠪ࡞࡞ࠫ∢"), l111l111ll_l1_, re.S)
	if not tmp: return l1l1ll_l1_ (u"ࠪࡉࡗࡘ࠺ࠡࡉࡨࡸ࡛ࡧࡲࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ∣")
	l11l1111ll_l1_ = tmp[0]
	_print(l1l1ll_l1_ (u"ࠫࡌ࡫ࡴࡗࡣࡵࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨ∤") % l11l1111ll_l1_)
	l111lll111_l1_ = locals()[l11l1111ll_l1_][0]
	l111lll111_l1_ = l11l111ll1_l1_(l111lll111_l1_)
	_print(l1l1ll_l1_ (u"ࠬࡍࡥࡵࡘࡤࡰࠥࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩ∥") % l111lll111_l1_)
	tmp = re.findall(l1l1ll_l1_ (u"࠭ࡽࡷࡣࡵࠤ࠭࡬࠽࠯ࠬࡂ࠭ࡀ࠭∦"), l111ll11ll_l1_, re.S)
	if not tmp: return l1l1ll_l1_ (u"ࠧࡆࡔࡕ࠾ࠥࡖ࡯ࡴࡶࡘࡶࡱࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ∧")
	l1111ll1l1_l1_ = str(tmp[0])
	_print(l1l1ll_l1_ (u"ࠨࡒࡲࡷࡹ࡛ࡲ࡭ࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ∨") % l1111ll1l1_l1_)
	l1111ll1l1_l1_ = re.sub(l1l1ll_l1_ (u"ࠤࠫࡻ࡮ࡴࡤࡰࡹ࡟࡟࠳࠰࠿࡝࡟ࠬࠦ∩"), l1l1ll_l1_ (u"ࠥࡥࡹࡵࡢࠣ∪"), l1111ll1l1_l1_)
	l1111ll1l1_l1_ = re.sub(l1l1ll_l1_ (u"ࠦ࠭ࡡࡁ࠮࡜ࡠࡿ࠶࠲࠲ࡾ࡞ࠫ࠭ࠧ∫"), l1l1ll_l1_ (u"ࠧࡧ࠰ࡥࠪࡰࡥ࡮ࡴ࡟ࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠦ∬"), l1111ll1l1_l1_)
	l1111ll1l1_l1_ = l1l1ll_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡦ࠼ࠢࠪ∭")+l1111ll1l1_l1_
	verify = re.findall(l1l1ll_l1_ (u"ࠧ࡝࠭ࠫࡣ࠳࠰࠿ࠪࠦࠪ∮"),l1111ll1l1_l1_,re.DOTALL)[0]
	l1111l11ll_l1_ = eval(verify)
	#exec(l1111ll1l1_l1_)
	l1111ll1l1_l1_ = l1111ll1l1_l1_.replace(l1l1ll_l1_ (u"ࠨࡩ࡯ࡳࡧࡧ࡬ࠡࡨ࠾ࠤ࡫ࡃࠧ∯"),l1l1ll_l1_ (u"ࠩࠪ∰"))
	f = eval(l1111ll1l1_l1_,{l1l1ll_l1_ (u"ࠪࡥࡹࡵࡢࠨ∱"):l11l111ll1_l1_,l1l1ll_l1_ (u"ࠫࡦ࠶ࡤࠨ∲"):l1111l1l11_l1_,l1l1ll_l1_ (u"ࠬࡳࡡࡪࡰࡢࡸࡦࡨࠧ∳"):l111ll1l1l_l1_,l1l1ll_l1_ (u"࠭ࡳࡵࡧࡳ࠶ࠬ∴"):l111l1llll_l1_,verify:l1111l11ll_l1_})
	_print(l1l1ll_l1_ (u"ࠧ࠰ࠩ∵")+l111lll111_l1_+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠥ࠭∶")+f+l11l11l111_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠥࠦࠧ∷")+l111llllll_l1_)
	return([l1l1ll_l1_ (u"ࠪ࠳ࠬ∸")+l111lll111_l1_,f+l11l11l111_l1_,{ l111llllll_l1_ : l1l1ll_l1_ (u"ࠫࡴࡱࠧ∹")}])
def _print(text):
	#text = text.replace(l1l1ll_l1_ (u"ࠬࠦࠠࠡࠢࠪ∺"),l1l1ll_l1_ (u"࠭ࠠࠡࠩ∻")).replace(l1l1ll_l1_ (u"ࠧࠡࠢࠣࠤࠬ∼"),l1l1ll_l1_ (u"ࠨࠢࠣࠫ∽")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠥࠦࠧ∾"),l1l1ll_l1_ (u"ࠪࠤࠥ࠭∿"))
	#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ≀"),str(text))
	return
l1l1ll_l1_ (u"ࠧࠨࠢࠋࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡳࡴࡲ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯࡮ࡷࡨ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࡱࡧࡵࡨࡪ࠰࡯࡮ࡲ࡬ࡦࡴ࠰ࡰࡦࡻࡧࡩ࠯࠵࠴࠶࠻ࠧࠋࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡳࡴࡲ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯࡮ࡷࡨ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࡦࡲ࡬࠮ࡪࡤࡰࡱࡵࡷࡴ࠯ࡨࡺࡪ࠳࠲࠮࠴࠳࠵࠺࠵࠿ࡳࡧࡩࡁࡸ࡯࡭ࡪ࡮ࡤࡶࠬࠐࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵࡱࡲࡰ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴࡬ࡵࡦ࠲ࡱࡴࡼࡩࡦ࠱ࡤࡨࡻ࡫ࡲࡴࡧ࠰࠶࠵࠸࠰࠰ࡁࡵࡩ࡫ࡃ࡭ࡰࡸ࡬ࡩࡸ࠳ࡰ࠲ࠩࠍࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡒࡔࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡕࡇࡖࡘ࠶࠭ࠩࠋࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡰࡦࡹࡳ࠾ࠤࡤࡹࡹࡵ࠭ࡴ࡫ࡽࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊ࡭࡫ࡱ࡯ࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡳࡴࡲ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯࡮ࡷࡨࠬ࠱࡬ࡪࡰ࡮࡟࠵ࡣࠊࠤ࡮࡬ࡲࡰࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠵ࡷࡢࡶࡦ࡬࠴ࡅࡶ࠾࡛࡫࡬࡭࡫ࡇ࡛࡫࡝ࡋࡩ࡞ࡖࡳࡧ࡫ࡕ࡭࡮ࡨࡦࡉ࡯ࡉ࡭࡫ࡨࡒࡪࡨࡪࡘࡑࡋࡘࡺࡐࡨࡩ࡫ࡤ࡬࡫࡝ࡪ࡭ࡑࡢࡧࡍ࡫ࡩࡖ࡫ࡨࡦࡅࡎࡨࡺ࡫ࡨࡒࡪࡨࡈࡱࡕࡤࡱࡋࡧࡩࡐ࡬ࡄ࡙ࡔࡇࡵ࡙࡜࡚ࡧࡪ࡫ࡩ࡭࡟ࡑࡦࡪࡨࡨࡘࡑࡨࡦࡪࡔ࡬ࡪࡪࡋ࡚ࡆࡖࡲࡊ࡜ࡤࡩࡦ࡝࡛ࡌ࡮ࡥࡒࡧ࡫ࡩ࡟ࡼ࡯࡚ࡦࡖࡰ࡟࡝ࡥࡩࡓࡇࡲ࡞ࡊ࡮ࡩࡆࡔࡈࡲࡉࡤࡅࡨࡔࡕࡪ࡮ࡥࡌࡕࡑࡩ࡭ࡗࡨࡦࡵࡧࡗࡐࡍࡦ࡭ࡲࡑࡳ࡭ࡪࡰࡰࡦ࡝ࡴࡐ࡮ࡥࡒࡧ࡫ࡩࡩ࡙ࡣࡩࡧ࡫ࡕ࡭࡫ࡄ࡯࡮ࡨ࡬࡫ࡴࡨࡒࡴࡩ࡬࡭࡬࡮ࡩࡆ࡫࡬ࡪ࡮࡙ࠧࡪࡀ࠹ࡩ࡫࠸ࡣࡤ࠳࠻࠷ࡪ࠳࠴࠸ࡧࡩ࠵࠻࠰࠺࠴࠵࠽࠼࡫ࡣ࠹ࡤ࠹࠵࠻࠺࠳ࠨࠌࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡑࡓࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡰ࡮ࡴ࡫࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡕࡇࡖࡘ࠷࠭ࠩࠋࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࡹࡸࡹ࠻ࠌࠌࡶࡪࡹࡵ࡭ࡶࠣࡁࠥ࡜ࡩࡥࡕࡷࡶࡪࡧ࡭ࠩࡪࡷࡱࡱ࠯ࠊࠊ࡮ࡱ࠵࠱ࡲ࡮࠳࠮ࡳࡶࡲࠦ࠽ࠡࡴࡨࡷࡺࡲࡴࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡇࡐࡅࡉࠦࡅࡎࡃࡇ࠾ࠥࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬࡯࠳ࠬ࠭ࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬࡋࡍࡂࡆࠣࡉࡒࡇࡄ࠻ࠢࠣࠤࠬ࠱ࡳࡵࡴࠫࡰࡳ࠸ࠩࠪࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡈࡑࡆࡊࠠࡆࡏࡄࡈ࠿ࠦࠠࠡࠩ࠮ࡷࡹࡸࠨࡱࡴࡰ࠭࠮ࠐࡥࡹࡥࡨࡴࡹࡀࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡆࡏࡄࡈࠥࡋࡍࡂࡆ࠽ࠤࠥࠦࠧࠬࡵࡷࡶ࠭ࡸࡥࡴࡷ࡯ࡸ࠮࠯ࠊࠣࠤࠥ≁")
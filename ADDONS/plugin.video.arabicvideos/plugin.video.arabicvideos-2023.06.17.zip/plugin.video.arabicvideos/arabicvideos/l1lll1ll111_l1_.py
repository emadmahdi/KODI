# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࠫ⭜")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡈࡎࡖࡣࠬ⭝")
def MAIN(mode,url,text,page):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll1l111ll_l1_(text)
	elif mode==542: results = l1ll11l1lll_l1_(text,url,page)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⭞"),l1l1ll_l1_ (u"ࠨสะฯࠥาฯ๋ัࠪ⭟"),l1l1ll_l1_ (u"ࠩࠪ⭠"),549)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⭡"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࠤ่๊ๅศฬ้ࠣำุๆสࠢࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⭢"),l1l1ll_l1_ (u"ࠬ࠭⭣"),9999)
	l1ll11llll1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡤࡪࡥࡷࠫ⭤"),l1l1ll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⭥"))
	if l1ll11llll1_l1_:
		l1ll11llll1_l1_ = l1ll11llll1_l1_[l1l1ll_l1_ (u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ⭦")]
		for search in reversed(l1ll11llll1_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭧"),search,l1l1ll_l1_ (u"ࠪࠫ⭨"),549,l1l1ll_l1_ (u"ࠫࠬ⭩"),l1l1ll_l1_ (u"ࠬ࠭⭪"),search)
	return
def SEARCH(search):
	#search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll1lll1l_l1_ = search.replace(menu_name,l1l1ll_l1_ (u"࠭ࠧ⭫"))
	l1ll11l111l_l1_(l1lll1lll1l_l1_)
	#l1ll111ll11_l1_ = search+options+l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⭬")
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⭭"),l1l1ll_l1_ (u"ࠩ฼้้ࠦศฮอࠣะ๊อู๋ࠢ࠰ࠤࠬ⭮")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡷ࡮ࡺࡥࡴࠩ⭯"),542,l1l1ll_l1_ (u"ࠫࠬ⭰"),l1l1ll_l1_ (u"ࠬ࠭⭱"),l1lll1lll1l_l1_)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⭲"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⭳"),l1l1ll_l1_ (u"ࠨࠩ⭴"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⭵"),l1l1ll_l1_ (u"๊ࠪฯอฦอࠢส่อำหࠡ็ไู้ฯࠠ࠮ࠢࠪ⭶")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⭷"),542,l1l1ll_l1_ (u"ࠬ࠭⭸"),l1l1ll_l1_ (u"࠭ࠧ⭹"),l1lll1lll1l_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⭺"),l1l1ll_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅใี่อࠥ࠳ࠠࠨ⭻")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⭼"),542,l1l1ll_l1_ (u"ࠪࠫ⭽"),l1l1ll_l1_ (u"ࠫࠬ⭾"),l1lll1lll1l_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭿"),l1l1ll_l1_ (u"࠭ศฮอ้๋ࠣ็ัะࠢ࠰ࠤࠬ⮀")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨ⮁"),541,l1l1ll_l1_ (u"ࠨࠩ⮂"),l1l1ll_l1_ (u"ࠩࠪ⮃"),l1lll1lll1l_l1_)
	return
def l1ll11l111l_l1_(l1ll1l1l111_l1_):
	l1ll1l1l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮄"),l1l1ll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮅"),l1ll1l1l111_l1_)
	l1ll1l1l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࠪ⮆"),l1l1ll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮇"),menu_name+l1ll1l1l111_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮈"),l1ll1l1l111_l1_)
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮉"),menu_name+l1ll1l1l111_l1_)
	old_value = l1ll1l1l1l1_l1_+l1ll1l1l11l_l1_
	if old_value: l1ll1l1l111_l1_ = menu_name+l1ll1l1l111_l1_
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮊"),l1ll1l1l111_l1_,old_value,l1ll11ll11l_l1_)
	return
def l1ll11l1l1l_l1_():
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࠫ⮋"),l1l1ll_l1_ (u"ࠫࠬ⮌"),l1l1ll_l1_ (u"ࠬ࠭⮍"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⮎"),l1l1ll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥาๅ๋฻ࠣ็้๋วหࠢส่อำหࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠤࠫ⮏"))
	if yes!=1: return
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮐"))
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡑࡓࡉࡓࡋࡄࠨ⮑"))
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⮒"))
	DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ⮓"),l1l1ll_l1_ (u"ࠬ࠭⮔"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⮕"),l1l1ll_l1_ (u"ࠧห็ࠣฬ๋าวฮ่ࠢืาࠦฬๆ์฼ࠤ่๊ๅศฬࠣห้ฮอฬࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ⮖"))
	return
def l1ll11l1lll_l1_(search_org,action,site=l1l1ll_l1_ (u"ࠨࠩ⮗")):
	l1ll11ll1l1_l1_,l1ll11ll1ll_l1_,l1ll1l11111_l1_,l1ll111l1l1_l1_,l1ll111ll1l_l1_,l1ll11lllll_l1_,threads = [],[],[],{},{},{},{}
	if action==l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮘"): l1ll1l11111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮙"),l1l1ll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮚"),menu_name+search_org)
	elif action==l1l1ll_l1_ (u"ࠬࡵࡰࡦࡰࡨࡨࡤࡹࡩࡵࡧࡶࠫ⮛"): l1ll1l11111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ⮜"),l1l1ll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⮝"),search_org)
	elif action==l1l1ll_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⮞"): l1ll1l11111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮟"),l1l1ll_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩ⮠"),[site,search_org])
	if not l1ll1l11111_l1_:
		l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠫ์ึวࠡษ็ฬาัࠠ฻์ิࠤ๊๎ฬ้ัࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะࠥࡢ࡮࡝ࡰ࡟ࡲࠬ⮡")
		l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวๅฤ้ࠤฬ๊ศฮอࠣๅ๏ࠦฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥ฿ๆࠡ࡞ࡱࠤࠧࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡࠩ⮢")+search_org+l1l1ll_l1_ (u"࠭ࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࠣࡠࡳูࠦๅ็สࠤศ์่ࠠาสࠤฬ๊ศฮอࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠨ⮣")
		if action==l1l1ll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⮤"): message = l1ll1l11l1l_l1_
		else: message = l1ll1l11l11_l1_+l1ll1l11l1l_l1_
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࠩ⮥"),l1l1ll_l1_ (u"ࠩࠪ⮦"),l1l1ll_l1_ (u"ࠪࠫ⮧"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⮨"),message)
		if yes!=1: return
		LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⮩"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪ⮪")+search_org+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ⮫"))
		#global menuItemsLIST
		import threading
		#l1ll11lll1l_l1_ = [l1l1ll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ⮬"),l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ⮭"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ⮮")]
		l1ll1l1llll_l1_ = 1
		for site in l1ll11lll1l_l1_:
			l1ll111l1l1_l1_[site] = []
			options = l1l1ll_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ⮯")
			if l1l1ll_l1_ (u"ࠬ࠳ࠧ⮰") in site: options = options+l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࠫ⮱")+site+l1l1ll_l1_ (u"ࠧࡠࠩ⮲")
			l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_ = l1ll111lll1_l1_(site)
			if l1ll1l1llll_l1_:
				threads[site] = threading.Thread(target=l1ll11ll111_l1_,args=(search_org+options,))
				threads[site].start()
			else: l1ll11ll111_l1_(search_org+options)
			DIALOG_NOTIFICATION(TRANSLATE(site),l1l1ll_l1_ (u"ࠨࠩ⮳"),time=1000)
		if l1ll1l1llll_l1_:
			for site in l1ll11lll1l_l1_:
				threads[site].join(10)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ⮴"),l1l1ll_l1_ (u"ࠪࠫ⮵"),l1l1ll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠣࡪࡴࡻ࡮ࡥࡧࡧ࠾ࠬ⮶"),str(len(menuItemsLIST)))
		for site in l1ll11lll1l_l1_:
			l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_ = l1ll111lll1_l1_(site)
			for menuItem in menuItemsLIST:
				type,name,url,mode,image,page,text,context,infodict = menuItem
				if l1ll1l1lll1_l1_ in name:
					if l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࠫ⮷") in site and (239>=mode>=230 or 289>=mode>=280):
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ⮸")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ⮹")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⮺")]: continue
						if l1l1ll_l1_ (u"ุࠩๅาฯࠧ⮻") not in name:
							if   type==l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⮼"): site = l1l1ll_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡏࡍ࡛ࡋࠧ⮽")
							elif type==l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⮾"): site = l1l1ll_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⮿")
							elif type==l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⯀"): site = l1l1ll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭⯁")
						else:
							if   l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ⯂") in url: site = l1l1ll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭⯃")
							elif l1l1ll_l1_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫ⯄") in url: site = l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⯅")
							elif l1l1ll_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭⯆") in url: site = l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯇")
					elif l1l1ll_l1_ (u"ࠨࡏ࠶࡙࠲࠭⯈") in site and 729>=mode>=710:
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫ⯉")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ⯊")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⯋")]: continue
						if l1l1ll_l1_ (u"ࠬ฻แฮหࠪ⯌") not in name:
							if   type==l1l1ll_l1_ (u"࠭࡬ࡪࡸࡨࠫ⯍"): site = l1l1ll_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ⯎")
							elif type==l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⯏"): site = l1l1ll_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⯐")
							elif type==l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⯑"): site = l1l1ll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ⯒")
						else:
							if   l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࠪ⯓") in url: site = l1l1ll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ⯔")
							elif l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡍࡊ࡙ࠧ⯕") in url: site = l1l1ll_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⯖")
							elif l1l1ll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ⯗") in url: site = l1l1ll_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯘")
					elif l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࠭⯙") in site and 149>=mode>=140:
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯚")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯛")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯜")]: continue
						if l1l1ll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⯝") in name or l1l1ll_l1_ (u"ࠩ࠽࠾ࠥ࠭⯞") in name:
							continue
							#if   image==l1l1ll_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯟"): site = l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯠")
							#elif image==l1l1ll_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯡"): site = l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯢")
							#else: site = l1l1ll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯣")
						else:
							if   mode==144 and l1l1ll_l1_ (u"ࠨࡗࡖࡉࡗ࠭⯤") in name: site = l1l1ll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ⯥")
							elif mode==144 and l1l1ll_l1_ (u"ࠪࡇࡍࡔࡌࠨ⯦") in name: site = l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯧")
							elif mode==144 and l1l1ll_l1_ (u"ࠬࡒࡉࡔࡖࠪ⯨") in name: site = l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯩")
							elif mode==143: site = l1l1ll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ⯪")
							else: continue
					elif l1l1ll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࠧ⯫") in site and 419>=mode>=400:
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪ⯬")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ⯭")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ⯮")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡘࡔࡖࡉࡄࡕࠪ⯯")]: continue
						if   mode in [401,405]: site = l1l1ll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ⯰")
						elif mode in [402,406]: site = l1l1ll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯱")
						elif mode in [403,404]: site = l1l1ll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭⯲")
						elif mode in [412,413]: site = l1l1ll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ⯳")
					elif l1l1ll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࠪ⯴") in site and 39>=mode>=30:
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ⯵")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࠫ⯶")]: continue
						if   mode in [32,39]: site = l1l1ll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࠬ⯷")
						elif mode in [33,39]: site = l1l1ll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘ࠭⯸")
					elif l1l1ll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࠨ⯹") in site and 29>=mode>=20:
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⯺")]: continue
						if menuItem in l1ll111l1l1_l1_[l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⯻")]: continue
						if   l1l1ll_l1_ (u"ࠫ࠴ࡧࡲ࠯ࠩ⯼") in url: site = l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⯽")
						elif l1l1ll_l1_ (u"࠭࠯ࡦࡰ࠱ࠫ⯾") in url: site = l1l1ll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⯿")
					#elif l1l1ll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࠬⰀ") in site and 319>=mode>=310:
					#	if menuItem in l1ll111l1l1_l1_[site]: continue
					#	if mode==312: site = l1ll11l11ll_l1_+l1l1ll_l1_ (u"ࠩ࠰ࡅ࡚ࡊࡉࡐࡕࠪⰁ")
					#	elif l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴ࠮ࠩⰂ") in url: site = l1ll11l11ll_l1_+l1l1ll_l1_ (u"ࠫ࠲ࡇࡌࡃࡗࡐࡗࠬⰃ")
					#	else: site = l1ll11l11ll_l1_+l1l1ll_l1_ (u"ࠬ࠳ࡐࡆࡔࡖࡓࡓ࡙ࠧⰄ")
					l1ll111l1l1_l1_[site].append(menuItem)
		menuItemsLIST[:] = []
		for site in list(l1ll111l1l1_l1_.keys()):
			l1ll111ll1l_l1_[site] = []
			l1ll11lllll_l1_[site] = []
			for type,name,url,mode,image,page,text,context,infodict in l1ll111l1l1_l1_[site]:
				menuItem = (type,name,url,mode,image,page,text,context,infodict)
				if l1l1ll_l1_ (u"࠭ีโฯฬࠫⰅ") in name and type==l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⰆ"): l1ll11lllll_l1_[site].append(menuItem)
				else: l1ll111ll1l_l1_[site].append(menuItem)
		l1ll1l111l1_l1_ = [(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⰷ"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰈ"),l1l1ll_l1_ (u"ࠪࠫⰉ"),157,l1l1ll_l1_ (u"ࠫࠬⰊ"),l1l1ll_l1_ (u"ࠬ࠭Ⰻ"),l1l1ll_l1_ (u"࠭ࠧⰌ"),l1l1ll_l1_ (u"ࠧࠨⰍ"),l1l1ll_l1_ (u"ࠨࠩⰎ"))]
		for site in l1ll11lll11_l1_:
			if site==l1ll11l1l11_l1_[0]: l1ll1l111l1_l1_ = [(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰏ"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥิวึหࠣ์฾อๅสࠢ࠰ࠤ่ั๊าหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰐ"),l1l1ll_l1_ (u"ࠫࠬⰑ"),157,l1l1ll_l1_ (u"ࠬ࠭Ⱂ"),l1l1ll_l1_ (u"࠭ࠧⰓ"),l1l1ll_l1_ (u"ࠧࠨⰔ"),l1l1ll_l1_ (u"ࠨࠩⰕ"),l1l1ll_l1_ (u"ࠩࠪⰖ"))]
			elif site==l1ll1l1l1ll_l1_[0]: l1ll1l111l1_l1_ = [(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰗ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯูࠦศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰘ"),l1l1ll_l1_ (u"ࠬ࠭Ⱉ"),157,l1l1ll_l1_ (u"࠭ࠧⰚ"),l1l1ll_l1_ (u"ࠧࠨⰛ"),l1l1ll_l1_ (u"ࠨࠩⰜ"),l1l1ll_l1_ (u"ࠩࠪⰝ"),l1l1ll_l1_ (u"ࠪࠫⰞ"))]
			elif site==l1ll111l1ll_l1_[0]: l1ll1l111l1_l1_ = [(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰟ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰠ"),l1l1ll_l1_ (u"࠭ࠧⰡ"),157,l1l1ll_l1_ (u"ࠧࠨⰢ"),l1l1ll_l1_ (u"ࠨࠩⰣ"),l1l1ll_l1_ (u"ࠩࠪⰤ"),l1l1ll_l1_ (u"ࠪࠫⰥ"),l1l1ll_l1_ (u"ࠫࠬⰦ"))]
			if site not in l1ll111ll1l_l1_.keys(): continue
			if l1ll111ll1l_l1_[site]:
				l1ll11l1111_l1_ = TRANSLATE(site)
				l1ll11l1ll1_l1_ = [(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⰧ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃࠠࠨⰨ")+l1ll11l1111_l1_+l1l1ll_l1_ (u"ࠧࠡ࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰩ"),l1l1ll_l1_ (u"ࠨࠩⰪ"),9999,l1l1ll_l1_ (u"ࠩࠪⰫ"),l1l1ll_l1_ (u"ࠪࠫⰬ"),l1l1ll_l1_ (u"ࠫࠬⰭ"),l1l1ll_l1_ (u"ࠬ࠭Ⱞ"),l1l1ll_l1_ (u"࠭ࠧⰯ"))]
				if 0:
					l1ll1l1ll11_l1_ = search_org+l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫⰰ")+l1l1ll_l1_ (u"ࠨสะฯࠬⰱ")+l1l1ll_l1_ (u"ࠩࠣࠫⰲ")+l1ll11l1111_l1_
				else:
					l1ll1l1ll11_l1_ = l1l1ll_l1_ (u"ࠪฬาัࠧⰳ")+l1l1ll_l1_ (u"ࠫࠥ࠭ⰴ")+l1ll11l1111_l1_+l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩⰵ")+search_org
				if len(l1ll111ll1l_l1_[site])<8: l1ll1l1111l_l1_ = []
				else:
					l1ll1l1ll1l_l1_ = l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩⰶ")+l1ll1l1ll11_l1_+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⰷ")
					l1ll1l1111l_l1_ = [(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⰸ"),menu_name+l1ll1l1ll1l_l1_,l1l1ll_l1_ (u"ࠩࡦࡰࡴࡹࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨⰹ"),542,l1l1ll_l1_ (u"ࠪࠫⰺ"),site,search_org,l1l1ll_l1_ (u"ࠫࠬⰻ"),l1l1ll_l1_ (u"ࠬ࠭ⰼ"))]
				l1ll1l11ll1_l1_ = l1ll111ll1l_l1_[site]+l1ll11lllll_l1_[site]
				l1ll11ll1ll_l1_ += l1ll1l111l1_l1_+l1ll11l1ll1_l1_+l1ll1l11ll1_l1_[:7]+l1ll1l1111l_l1_
				l1ll111llll_l1_ = [(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⰽ"),menu_name+l1ll1l1ll11_l1_,l1l1ll_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⰾ"),542,l1l1ll_l1_ (u"ࠨࠩⰿ"),site,search_org,l1l1ll_l1_ (u"ࠩࠪⱀ"),l1l1ll_l1_ (u"ࠪࠫⱁ"))]
				l1ll11ll1l1_l1_ += l1ll1l111l1_l1_+l1ll111llll_l1_
				l1ll1l111l1_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡇࡑࡕࡓࡆࡆࠪⱂ"),(site,search_org),l1ll1l11ll1_l1_,l1ll11ll11l_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫⱃ"),search_org,l1ll11ll1ll_l1_,l1ll11ll11l_l1_)
		DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱄ"),search_org)
		WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬⱅ"),menu_name+search_org,l1ll11ll1l1_l1_,l1ll11ll11l_l1_)
		DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩⱆ"),l1l1ll_l1_ (u"ࠩࠪⱇ"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ⱈ"),l1l1ll_l1_ (u"ࠫฬ๊ศฮอࠣห้าๅศ฻ํࠤฬ์ส่๋ࠣฬ๋าวฮࠢ࡟ࡲࡡࡴࠠห็ࠣฮำุ๊็ࠢส่๋ะววฮࠣๅ๏ࠦใศึࠣห้ฮั็ษ่ะ๊ࠥๅะหࠣฯ้อห๋่ࠣ๎ํ๋ࠠๅๅํࠤฯูสุ์฼ࠤฬู๊้ัฬࠤส๊๊่ษࠣฬิ๎ๆࠡ฻่่ࠥฮอฬࠢฯำ๏ีࠧⱉ"))
		if action==l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࡨࡨࡤࡹࡩࡵࡧࡶࠫⱊ") and l1ll11ll1l1_l1_: l1ll1l11111_l1_ = l1ll11ll1l1_l1_
		else: l1ll1l11111_l1_ = l1ll11ll1ll_l1_
	if action!=l1l1ll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬⱋ"):
		for type,name,url,mode,image,page,text,context,infodict in l1ll1l11111_l1_:
			if action in [l1l1ll_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱌ"),l1l1ll_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱍ")] and l1l1ll_l1_ (u"ุࠩๅาฯࠧⱎ") in name and type==l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱏ"): continue
			addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return
def l1ll1l111ll_l1_(search_org=l1l1ll_l1_ (u"ࠫࠬⱐ")):
	search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬⱑ"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡖࡩࡦࡸࡣࡩࠢࡉࡳࡷࡀࠠ࡜ࠢࠪⱒ")+search+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪⱓ"))
	l11lll1_l1_ = search+options
	if 0:
		l1ll1l11lll_l1_,l1lll1lll1l_l1_ = search+l1l1ll_l1_ (u"ࠨࠢ࠰ࠤࠬⱔ"),l1l1ll_l1_ (u"ࠩࠪⱕ")
	else:
		l1ll1l11lll_l1_,l1lll1lll1l_l1_ = l1l1ll_l1_ (u"ࠪࠫⱖ"),l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨⱗ")+search
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⱘ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⱙ"),l1l1ll_l1_ (u"ࠧࠨⱚ"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱛ"),l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨⱜ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠࡎ࠵ࡘࠫⱝ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬⱞ"),719,l1l1ll_l1_ (u"ࠬ࠭ⱟ"),l1l1ll_l1_ (u"࠭ࠧⱠ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱡ"),l1l1ll_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧⱢ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦࡉࡑࡖ࡙ࠫⱣ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⱤ"),239,l1l1ll_l1_ (u"ࠫࠬⱥ"),l1l1ll_l1_ (u"ࠬ࠭ⱦ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱨ"),l1l1ll_l1_ (u"ࠧࡠࡄࡎࡖࡤ࠭ⱨ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬ่ืวࠨⱩ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩࠪⱪ"),379,l1l1ll_l1_ (u"ࠪࠫⱫ"),l1l1ll_l1_ (u"ࠫࠬⱬ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱭ"),l1l1ll_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬⱮ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢหห๋๐สࠨⱯ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠨࠩⱰ"),39,l1l1ll_l1_ (u"ࠩࠪⱱ"),l1l1ll_l1_ (u"ࠪࠫⱲ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱳ"),l1l1ll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫⱴ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠศใ็ห๊࠭Ⱶ"),l1l1ll_l1_ (u"ࠧࠨⱶ"),39,l1l1ll_l1_ (u"ࠨࠩⱷ"),l1l1ll_l1_ (u"ࠩࠪⱸ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙࡟ࠨⱹ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱺ"),l1l1ll_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫⱻ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨⱼ"),l1l1ll_l1_ (u"ࠧࠨⱽ"),39,l1l1ll_l1_ (u"ࠨࠩⱾ"),l1l1ll_l1_ (u"ࠩࠪⱿ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠࡒࡄࡒࡊ࡚࠭ࡔࡇࡕࡍࡊ࡙࡟ࠨⲀ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲁ"),l1l1ll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲂ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪⲃ"),l1l1ll_l1_ (u"ࠧࠨⲄ"),149,l1l1ll_l1_ (u"ࠨࠩⲅ"),l1l1ll_l1_ (u"ࠩࠪⲆ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࡡࠪⲇ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲈ"),l1l1ll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲉ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ๋หห๋ࠧⲊ"),l1l1ll_l1_ (u"ࠧࠨⲋ"),149,l1l1ll_l1_ (u"ࠨࠩⲌ"),l1l1ll_l1_ (u"ࠩࠪⲍ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭Ⲏ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲏ"),l1l1ll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⲐ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧⲑ"),l1l1ll_l1_ (u"ࠧࠨⲒ"),149,l1l1ll_l1_ (u"ࠨࠩⲓ"),l1l1ll_l1_ (u"ࠩࠪⲔ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬⲕ"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲖ"),l1l1ll_l1_ (u"ࠬࡥࡋࡍࡃࡢࠫⲗ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅ็ࠤฬู๊าสࠪⲘ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨⲙ"),19,l1l1ll_l1_ (u"ࠨࠩⲚ"),l1l1ll_l1_ (u"ࠩࠪⲛ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲜ"),l1l1ll_l1_ (u"ࠫࡤࡇࡒࡕࡡࠪⲝ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠห๊้ึࠥ฿ัษ์ฬࠫⲞ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"࠭ࠧⲟ"),739,l1l1ll_l1_ (u"ࠧࠨⲠ"),l1l1ll_l1_ (u"ࠨࠩⲡ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲢ"),l1l1ll_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩⲣ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦโ็ษฬࠤ่ืศๅษฤࠫⲤ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭ⲥ"),329,l1l1ll_l1_ (u"࠭ࠧⲦ"),l1l1ll_l1_ (u"ࠧࠨⲧ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲨ"),l1l1ll_l1_ (u"ࠩࡢࡊࡍ࠷࡟ࠨⲩ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็วึๆࠣห้ษ่ๅࠩⲪ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬⲫ"),579,l1l1ll_l1_ (u"ࠬ࠭Ⲭ"),l1l1ll_l1_ (u"࠭ࠧⲭ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲮ"),l1l1ll_l1_ (u"ࠨࡡࡈࡋࡇࡥࠧⲯ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧⲰ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⲱ"),129,l1l1ll_l1_ (u"ࠫࠬⲲ"),l1l1ll_l1_ (u"ࠬ࠭ⲳ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⲵ"),l1l1ll_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭ⲵ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦแ๋ัํ์์อสࠨⲶ"),l1l1ll_l1_ (u"ࠩࠪⲷ"),409,l1l1ll_l1_ (u"ࠪࠫⲸ"),l1l1ll_l1_ (u"ࠫࠬⲹ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࡠࠩⲺ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲻ"),l1l1ll_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭Ⲽ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ้ษษ้ࠬⲽ"),l1l1ll_l1_ (u"ࠩࠪⲾ"),409,l1l1ll_l1_ (u"ࠪࠫⲿ"),l1l1ll_l1_ (u"ࠫࠬⳀ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬⳁ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳃ"),l1l1ll_l1_ (u"ࠧࡠࡆࡏࡑࡤ࠭ⳃ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬⳄ"),l1l1ll_l1_ (u"ࠩࠪⳅ"),409,l1l1ll_l1_ (u"ࠪࠫⳆ"),l1l1ll_l1_ (u"ࠫࠬⳇ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫⳈ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳉ"),l1l1ll_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭Ⳋ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨࠢࠣฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫⳋ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠬⳌ"),l1l1ll_l1_ (u"ࠪࠫⳍ"),29,l1l1ll_l1_ (u"ࠫࠬⳎ"),l1l1ll_l1_ (u"ࠬ࠭ⳏ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳑ"),l1l1ll_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭ⳑ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢ฼ีอ๐ࠧⳒ"),l1l1ll_l1_ (u"ࠩࠪⳓ"),29,l1l1ll_l1_ (u"ࠪࠫⳔ"),l1l1ll_l1_ (u"ࠫࠬⳕ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࡡࠪⳖ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳗ"),l1l1ll_l1_ (u"ࠧࡠࡋࡉࡐࡤ࠭Ⳙ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠢส๊ั๊๊ำ์ࠪⳙ"),l1l1ll_l1_ (u"ࠩࠪⳚ"),29,l1l1ll_l1_ (u"ࠪࠫⳛ"),l1l1ll_l1_ (u"ࠫࠬⳜ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࡢࠫⳝ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳟ"),l1l1ll_l1_ (u"ࠧࡠࡃࡎࡓࡤ࠭ⳟ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩⳠ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩࠪⳡ"),79,l1l1ll_l1_ (u"ࠪࠫⳢ"),l1l1ll_l1_ (u"ࠫࠬⳣ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳤ"),l1l1ll_l1_ (u"࠭࡟ࡂࡍ࡚ࡣࠬ⳥")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨ⳦")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠨࠩ⳧"),249,l1l1ll_l1_ (u"ࠩࠪ⳨"),l1l1ll_l1_ (u"ࠪࠫ⳩"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳪"),l1l1ll_l1_ (u"ࠬࡥࡍࡓࡈࠪⳫ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧⳬ"),l1l1ll_l1_ (u"ࠧࠨⳭ"),49,l1l1ll_l1_ (u"ࠨࠩⳮ"),l1l1ll_l1_ (u"ࠩࠪ⳯"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳰"),l1l1ll_l1_ (u"ࠫࡤ࡙ࡈࡎࡡࠪ⳱")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไࠤ๊อใิࠩⳲ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"࠭ࠧⳳ"),59,l1l1ll_l1_ (u"ࠧࠨ⳴"),l1l1ll_l1_ (u"ࠨࠩ⳵"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳶"),l1l1ll_l1_ (u"ࠪࡣࡋ࡚ࡍࡠࠩ⳷")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧ⳸")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭⳹"),69,l1l1ll_l1_ (u"࠭ࠧ⳺"),l1l1ll_l1_ (u"ࠧࠨ⳻"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⳼"),l1l1ll_l1_ (u"ࠩࡢࡏ࡜࡚࡟ࠨ⳽")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪ⳾"),l1l1ll_l1_ (u"ࠫࠬ⳿"),139,l1l1ll_l1_ (u"ࠬ࠭ⴀ"),l1l1ll_l1_ (u"࠭ࠧⴁ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴂ"),l1l1ll_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧⴃ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨⴄ"),l1l1ll_l1_ (u"ࠪࠫⴅ"),319,l1l1ll_l1_ (u"ࠫࠬⴆ"),l1l1ll_l1_ (u"ࠬ࠭ⴇ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴈ"),l1l1ll_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴉ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬⴊ"),l1l1ll_l1_ (u"ࠩࠪⴋ"),319,l1l1ll_l1_ (u"ࠪࠫⴌ"),l1l1ll_l1_ (u"ࠫࠬⴍ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡆࡔࡖࡓࡓ࡙࡟ࠨⴎ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l1l1ll_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴐ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠๆฮ็ำࠬⴑ"),l1l1ll_l1_ (u"ࠩࠪⴒ"),319,l1l1ll_l1_ (u"ࠪࠫⴓ"),l1l1ll_l1_ (u"ࠫࠬⴔ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘࡥࠧⴕ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴖ"),l1l1ll_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴗ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠠึ๊อ๎ฬะࠧⴘ"),l1l1ll_l1_ (u"ࠩࠪⴙ"),319,l1l1ll_l1_ (u"ࠪࠫⴚ"),l1l1ll_l1_ (u"ࠫࠬⴛ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘࡥࠧⴜ"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴝ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯ้ࠠ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩⴞ"),l1l1ll_l1_ (u"ࠨࠩⴟ"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴠ"),l1l1ll_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩⴡ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦใหๅ๋ฮࠬⴢ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭ⴣ"),679,l1l1ll_l1_ (u"࠭ࠧⴤ"),l1l1ll_l1_ (u"ࠧࠨⴥ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⴦"),l1l1ll_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨⴧ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪࠤอำหࠡ็๋ๆ฾ࠦแอำุࠣํ࠭⴨")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠫࠥ࠭⴩"),l1l1ll_l1_ (u"ࠬ࠭⴪"),399,l1l1ll_l1_ (u"࠭ࠧ⴫"),l1l1ll_l1_ (u"ࠧࠨ⴬"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴭ"),l1l1ll_l1_ (u"ࠩࡢࡘ࡛ࡌ࡟ࠨ⴮")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ⴯")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬⴰ"),469,l1l1ll_l1_ (u"ࠬ࠭ⴱ"),l1l1ll_l1_ (u"࠭ࠧⴲ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴳ"),l1l1ll_l1_ (u"ࠨࡡࡏࡈࡓࡥࠧⴴ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬⴵ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⴶ"),459,l1l1ll_l1_ (u"ࠫࠬⴷ"),l1l1ll_l1_ (u"ࠬ࠭ⴸ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴹ"),l1l1ll_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭ⴺ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋ว่ࠡส์ࠬⴻ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩࠪⴼ"),309,l1l1ll_l1_ (u"ࠪࠫⴽ"),l1l1ll_l1_ (u"ࠫࠬⴾ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴿ"),l1l1ll_l1_ (u"࠭࡟ࡘࡅࡐࡣࠬⵀ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๋ࠢ๎ู๊ࠥๆษࠪⵁ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠨࠩⵂ"),569,l1l1ll_l1_ (u"ࠩࠪⵃ"),l1l1ll_l1_ (u"ࠪࠫⵄ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵅ"),l1l1ll_l1_ (u"ࠬࡥࡓࡉࡐࡢࠫⵆ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡึส๋ิࠦๆ๋๊ีࠫⵇ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨⵈ"),589,l1l1ll_l1_ (u"ࠨࠩⵉ"),l1l1ll_l1_ (u"ࠩࠪⵊ"),l11lll1_l1_+l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨⵋ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵌ"),l1l1ll_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫⵍ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ็ส๎ู๊ࠥๆษࠪⵎ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨⵏ"),369,l1l1ll_l1_ (u"ࠨࠩⵐ"),l1l1ll_l1_ (u"ࠩࠪⵑ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵒ"),l1l1ll_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪⵓ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠี๊ไࠤอื่ࠨⵔ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"࠭ࠧⵕ"),489,l1l1ll_l1_ (u"ࠧࠨⵖ"),l1l1ll_l1_ (u"ࠨࠩⵗ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵘ"),l1l1ll_l1_ (u"ࠪࡣࡆࡘࡓࡠࠩⵙ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨⵚ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭ⵛ"),259,l1l1ll_l1_ (u"࠭ࠧⵜ"),l1l1ll_l1_ (u"ࠧࠨⵝ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵞ"),l1l1ll_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨⵟ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩⵠ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬⵡ"),429,l1l1ll_l1_ (u"ࠬ࠭ⵢ"),l1l1ll_l1_ (u"࠭ࠧⵣ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⵤ"),l1l1ll_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧⵥ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨⵦ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⵧ"),119,l1l1ll_l1_ (u"ࠫࠬ⵨"),l1l1ll_l1_ (u"ࠬ࠭⵩"),l11lll1_l1_+l1l1ll_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ⵪"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⵫"),l1l1ll_l1_ (u"ࠨࡡࡐ࠸࡚ࡥࠧ⵬")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨ⵭"),l1l1ll_l1_ (u"ࠪࠫ⵮"),389,l1l1ll_l1_ (u"ࠫࠬⵯ"),l1l1ll_l1_ (u"ࠬ࠭⵰"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵱"),l1l1ll_l1_ (u"ࠧࡠࡇࡊ࡚ࡤ࠭⵲")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡสํืฯࠦࡶࡪࡲࠪ⵳"),l1l1ll_l1_ (u"ࠩࠪ⵴"),229,l1l1ll_l1_ (u"ࠪࠫ⵵"),l1l1ll_l1_ (u"ࠫࠬ⵶"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⵷"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡ฻ส้ฮࠦ࠭ࠡๅฮ๎ึฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⵸"),l1l1ll_l1_ (u"ࠧࠨ⵹"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵺"),l1l1ll_l1_ (u"ࠩࡢࡐࡗࡠ࡟ࠨ⵻")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽๊ࠥวา๊ีหࠬ⵼")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬ⵽"),709,l1l1ll_l1_ (u"ࠬ࠭⵾"),l1l1ll_l1_ (u"⵿࠭ࠧ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶀ"),l1l1ll_l1_ (u"ࠨࡡࡉࡗ࡙ࡥࠧⶁ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆ๎ำหษࠪⶂ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⶃ"),609,l1l1ll_l1_ (u"ࠫࠬⶄ"),l1l1ll_l1_ (u"ࠬ࠭ⶅ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶆ"),l1l1ll_l1_ (u"ࠧࡠࡈࡅࡏࡤ࠭ⶇ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅอืใสࠩⶈ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩࠪⶉ"),629,l1l1ll_l1_ (u"ࠪࠫⶊ"),l1l1ll_l1_ (u"ࠫࠬⶋ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶌ"),l1l1ll_l1_ (u"࠭࡟࡚ࡓࡗࡣࠬⶍ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢํห็๎สࠨⶎ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠨࠩⶏ"),669,l1l1ll_l1_ (u"ࠩࠪⶐ"),l1l1ll_l1_ (u"ࠪࠫⶑ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶒ"),l1l1ll_l1_ (u"ࠬࡥࡂࡓࡕࡢࠫⶓ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสิืฯ๐ฬࠨⶔ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨⶕ"),659,l1l1ll_l1_ (u"ࠨࠩⶖ"),l1l1ll_l1_ (u"ࠩࠪ⶗"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶘"),l1l1ll_l1_ (u"ࠫࡤࡎࡌࡄࡡࠪ⶙")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿่ࠠๆสࠤุ๐ๅศࠩ⶚")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"࠭ࠧ⶛"),89,l1l1ll_l1_ (u"ࠧࠨ⶜"),l1l1ll_l1_ (u"ࠨࠩ⶝"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⶞"),l1l1ll_l1_ (u"ࠪࡣࡉࡘ࠷ࡠࠩ⶟")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨⶠ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭ⶡ"),689,l1l1ll_l1_ (u"࠭ࠧⶢ"),l1l1ll_l1_ (u"ࠧࠨⶣ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶤ"),l1l1ll_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨⶥ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨⶦ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬ⶧"),99,l1l1ll_l1_ (u"ࠬ࠭ⶨ"),l1l1ll_l1_ (u"࠭ࠧⶩ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶪ"),l1l1ll_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧⶫ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧⶬ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫⶭ"),479,l1l1ll_l1_ (u"ࠫࠬⶮ"),l1l1ll_l1_ (u"ࠬ࠭⶯"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶰ"),l1l1ll_l1_ (u"ࠧࡠࡃࡅࡈࡤ࠭ⶱ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡ฻หำํ࠭ⶲ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠩࠪⶳ"),559,l1l1ll_l1_ (u"ࠪࠫⶴ"),l1l1ll_l1_ (u"ࠫࠬⶵ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶶ"),l1l1ll_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬ⶷")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫⶸ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠨࠩⶹ"),699,l1l1ll_l1_ (u"ࠩࠪⶺ"),l1l1ll_l1_ (u"ࠪࠫⶻ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶼ"),l1l1ll_l1_ (u"ࠬࡥࡁࡉࡍࡢࠫⶽ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬⶾ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠧࠨ⶿"),619,l1l1ll_l1_ (u"ࠨࠩⷀ"),l1l1ll_l1_ (u"ࠩࠪⷁ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷂ"),l1l1ll_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪⷃ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪⷄ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"࠭ࠧⷅ"),639,l1l1ll_l1_ (u"ࠧࠨⷆ"),l1l1ll_l1_ (u"ࠨࠩ⷇"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷈ"),l1l1ll_l1_ (u"ࠪࡣࡘࡎࡔࡠࠩⷉ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪⷊ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭ⷋ"),649,l1l1ll_l1_ (u"࠭ࠧⷌ"),l1l1ll_l1_ (u"ࠧࠨⷍ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷎ"),l1l1ll_l1_ (u"ࠩࡢࡉࡌࡔ࡟ࠨ⷏")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥห๊อ์๊ࠣฬ๎ࠧⷐ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬⷑ"),439,l1l1ll_l1_ (u"ࠬ࠭ⷒ"),l1l1ll_l1_ (u"࠭ࠧⷓ"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷔ"),l1l1ll_l1_ (u"ࠨࡡࡉࡌ࠷ࡥࠧⷕ")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩⷖ")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠪࠫ⷗"),599,l1l1ll_l1_ (u"ࠫࠬⷘ"),l1l1ll_l1_ (u"ࠬ࠭ⷙ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷚ"),l1l1ll_l1_ (u"ࠧࡠࡇࡊࡈࡤ࠭ⷛ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣษ๏า๊ࠡัํำࠬⷜ"),l1l1ll_l1_ (u"ࠩࠪⷝ"),449,l1l1ll_l1_ (u"ࠪࠫⷞ"),l1l1ll_l1_ (u"ࠫࠬ⷟"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷠ"),l1l1ll_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬⷡ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢส็ํอๅࠡๅส้ࠬⷢ"),l1l1ll_l1_ (u"ࠨࠩⷣ"),359,l1l1ll_l1_ (u"ࠩࠪⷤ"),l1l1ll_l1_ (u"ࠪࠫⷥ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷦ"),l1l1ll_l1_ (u"ࠬࡥࡃࡎࡅࡢࠫⷧ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦใๅ๊หࠫⷨ"),l1l1ll_l1_ (u"ࠧࠨⷩ"),499,l1l1ll_l1_ (u"ࠨࠩⷪ"),l1l1ll_l1_ (u"ࠩࠪⷫ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷬ"),l1l1ll_l1_ (u"ࠫࡤࡇࡒࡍࡡࠪⷭ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠬฮอฬ่ࠢ์็฿ฺࠠำหࠤ้๐่็ิࠪⷮ"),l1l1ll_l1_ (u"࠭ࠧⷯ"),209,l1l1ll_l1_ (u"ࠧࠨⷰ"),l1l1ll_l1_ (u"ࠨࠩⷱ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷲ"),l1l1ll_l1_ (u"ࠪࡣࡍࡋࡌࡠࠩⷳ")+l1lll1lll1l_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫⷴ"),l1l1ll_l1_ (u"ࠬ࠭ⷵ"),99,l1l1ll_l1_ (u"࠭ࠧⷶ"),l1l1ll_l1_ (u"ࠧࠨⷷ"),l11lll1_l1_)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷸ"),l1l1ll_l1_ (u"ࠩࡢࡗࡋ࡝࡟ࠨⷹ")+search+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥา์ึࠤๆ๎ั๊ࠡอุࠬⷺ"),l1l1ll_l1_ (u"ࠫࠬⷻ"),218,l1l1ll_l1_ (u"ࠬ࠭ⷼ"),l1l1ll_l1_ (u"࠭ࠧⷽ"),search) # 219
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷾ"),l1l1ll_l1_ (u"ࠨࡡࡐ࡚࡟ࡥࠧⷿ")+search+l1l1ll_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ⸀"),l1l1ll_l1_ (u"ࠪࠫ⸁"),188,l1l1ll_l1_ (u"ࠫࠬ⸂"),l1l1ll_l1_ (u"ࠬ࠭⸃"),search)# 189
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⸄"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢัหฺฯࠠ࠮ࠢๅ่๏๊ษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⸅"),l1l1ll_l1_ (u"ࠨࠩ⸆"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⸇"),l1l1ll_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ⸈")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠫอำหࠡ็๋ๆ฾๊้ࠦฬํ์อ࠭⸉")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠬ࠭⸊"),149,l1l1ll_l1_ (u"࠭ࠧ⸋"),l1l1ll_l1_ (u"ࠧࠨ⸌"),l11lll1_l1_)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸍"),l1l1ll_l1_ (u"ࠩࡢࡈࡑࡓ࡟ࠨ⸎")+l1ll1l11lll_l1_+l1l1ll_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠨ⸏")+l1lll1lll1l_l1_,l1l1ll_l1_ (u"ࠫࠬ⸐"),409,l1l1ll_l1_ (u"ࠬ࠭⸑"),l1l1ll_l1_ (u"࠭ࠧ⸒"),l11lll1_l1_)
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭み")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡋࡕࡍࡢࠫむ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨめ"),l1l1ll_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨも"),l1l1ll_l1_ (u"ࠨษ็ว็ูวๆࠩゃ")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l11l1l_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l11_l1_(url,text)
	elif mode==674: results = l1ll1l_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭や"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫゅ"),l1l1ll_l1_ (u"ࠫࠬゆ"),l1l1ll_l1_ (u"ࠬ࠭ょ"),l1l1ll_l1_ (u"࠭ࠧよ"),l1l1ll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫら"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨり"),menu_name+l1l1ll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩる"),l1l1ll_l1_ (u"ࠪࠫれ"),679,l1l1ll_l1_ (u"ࠫࠬろ"),l1l1ll_l1_ (u"ࠬ࠭ゎ"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪわ"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬゐ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨゑ"),l1l1ll_l1_ (u"ࠩࠪを"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪん"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ゔ")+menu_name+l1l1ll_l1_ (u"ࠬอไๆ็ํึฮ࠭ゕ"),l1l1l1_l1_,671,l1l1ll_l1_ (u"࠭ࠧゖ"),l1l1ll_l1_ (u"ࠧࠨ゗"),l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ゘"))
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳ゙ࠩ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ゚ࠬ")+menu_name+l1l1ll_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ゛"),l1l1l1_l1_,671,l1l1ll_l1_ (u"ࠬ࠭゜"),l1l1ll_l1_ (u"࠭ࠧゝ"),l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ゞ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨゟ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ゠")+menu_name+l1l1ll_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩァ"),l1l1l1_l1_,671,l1l1ll_l1_ (u"ࠫࠬア"),l1l1ll_l1_ (u"ࠬ࠭ィ"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪイ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧゥ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪウ")+menu_name+l1l1ll_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭ェ"),l1l1l1_l1_,671,l1l1ll_l1_ (u"ࠪࠫエ"),l1l1ll_l1_ (u"ࠫࠬォ"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧオ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫカ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧガ"),l1l1ll_l1_ (u"ࠨࠩキ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪギ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬク"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		if title==l1l1ll_l1_ (u"ࠫฬ๊รใีส้ࠬグ"): mode = 675
		else: mode = 674
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬケ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨゲ")+menu_name+title,link,mode)
	#addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬコ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨゴ"),l1l1ll_l1_ (u"ࠩࠪサ"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧザ"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤシ"),html,re.DOTALL)
	#for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠬ࠭ジ"))
	#items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫス"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧズ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪセ")+menu_name+title,link,674)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧゼ"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪソ"),l1l1ll_l1_ (u"ࠫࠬゾ"),9999)
	items = CATEGORIES(l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡨࡲࡰࡹࡶࡩ࠳࡮ࡴ࡮࡮ࠪタ"))
	for link,img,title in items:
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ダ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩチ")+menu_name+title,link,674,img)
	return
def CATEGORIES(url):
	l1ll1lllll_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭ヂ"),l1l1ll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫッ"),l1l1ll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧツ"))
	if l1ll1lllll_l1_: return l1ll1lllll_l1_
	#DIALOG_OK()
	l1ll1lllll_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨヅ"),url,l1l1ll_l1_ (u"ࠬ࠭テ"),l1l1ll_l1_ (u"࠭ࠧデ"),l1l1ll_l1_ (u"ࠧࠨト"),l1l1ll_l1_ (u"ࠨࠩド"),l1l1ll_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸࠬナ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡨࡦࡣࡧࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࡬࡯ࡰࡶࡨࡶࡃ࠭ニ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll1lllll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨヌ"),block,re.DOTALL)
		if l1ll1lllll_l1_: WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧネ"),l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪノ"),l1ll1lllll_l1_,l11l1ll_l1_)
	return l1ll1lllll_l1_
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫハ"),url,l1l1ll_l1_ (u"ࠨࠩバ"),l1l1ll_l1_ (u"ࠩࠪパ"),l1l1ll_l1_ (u"ࠪࠫヒ"),l1l1ll_l1_ (u"ࠫࠬビ"),l1l1ll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬピ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪフ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨブ"),l1l1ll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧプ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヘ"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠪࠫベ"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩペ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪホ"),l1l1ll_l1_ (u"࠭ࠧボ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬポ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠨ࠼ࠣࠫマ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩミ"),menu_name+title,link,671)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧム"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭メ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪモ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ャ"),l1l1ll_l1_ (u"ࠧࠨヤ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨュ"),menu_name+title,link,671)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠩࠪユ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫョ"),l1l1ll_l1_ (u"ࠫࠬヨ"),request,url)
	if request==l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪラ"):
		url,search = url.split(l1l1ll_l1_ (u"࠭࠿ࠨリ"),1)
		data = l1l1ll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ル")+search
		headers = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧレ"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩロ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨヮ"),url,data,headers,l1l1ll_l1_ (u"ࠫࠬワ"),l1l1ll_l1_ (u"ࠬ࠭ヰ"),l1l1ll_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬヱ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫヲ"),url,l1l1ll_l1_ (u"ࠨࠩン"),l1l1ll_l1_ (u"ࠩࠪヴ"),l1l1ll_l1_ (u"ࠪࠫヵ"),l1l1ll_l1_ (u"ࠫࠬヶ"),l1l1ll_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫヷ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"࠭ࠧヸ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫヹ"))
	if request==l1l1ll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ヺ"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ・"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠪࠫー"),link,title))
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ヽ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ヾ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬヿ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㄀"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ㄁"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㄂"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㄃"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭㄄"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧㄅ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"࠭ࠧㄆ"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨㄇ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩㄈ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩㄉ"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨㄊ"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪㄋ"),l1l1ll_l1_ (u"้ࠬไ๋สࠪㄌ"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬㄍ"),l1l1ll_l1_ (u"่ࠧัสๅࠬㄎ"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨㄏ"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭ㄐ"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪㄑ"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪㄒ"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬㄓ"),l1l1ll_l1_ (u"࠭แๅ็ࠪㄔ")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩㄕ"))
		#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ㄖ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫㄗ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬㄘ"))
		#if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩㄙ") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧㄚ")+img.strip(l1l1ll_l1_ (u"࠭࠯ࠨㄛ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩㄜ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫㄝ"),title,re.DOTALL)
		#addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㄞ"),menu_name+title,link,672,img)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄟ"),menu_name+title,link,672,img)
		elif request==l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪㄠ"):
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫㄡ"),menu_name+title,link,672,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬㄢ") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㄣ"),menu_name+title,link,673,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ㄤ") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄥ"),menu_name+title,link,671,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄦ"),menu_name+title,link,673,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄧ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㄨ"),block,re.DOTALL)
		for link,title in items:
			if link==l1l1ll_l1_ (u"࠭ࠣࠨㄩ"): continue
			if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬㄪ") not in link:
				url2 = url.rsplit(l1l1ll_l1_ (u"ࠨ࠱ࠪㄫ"),1)[0]
				link = url2+l1l1ll_l1_ (u"ࠩ࠲ࠫㄬ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬㄭ"))
			title = unescapeHTML(title)
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㄮ"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫㄯ")+title,link,671,l1l1ll_l1_ (u"࠭ࠧ㄰"),l1l1ll_l1_ (u"ࠧࠨㄱ"),request)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩㄲ"),l1l1ll_l1_ (u"ࠩࠪㄳ"),l1lll_l1_,url)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㄴ"),menu_name+l1l1ll_l1_ (u"ࠫฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫㄵ"),url,672)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪㄶ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ㄷ"),l1l1ll_l1_ (u"ࠧࠨㄸ"),9999)
	l1ll1lllll_l1_ = CATEGORIES(l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡤࡵࡳࡼࡹࡥ࠯ࡪࡷࡱࡱ࠭ㄹ"))
	l1l1ll11lll_l1_,l1l1ll1l111_l1_,l1l1ll1lll1_l1_ = zip(*l1ll1lllll_l1_)
	l1l1ll1l1l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ㄺ"),url,l1l1ll_l1_ (u"ࠪࠫㄻ"),l1l1ll_l1_ (u"ࠫࠬㄼ"),l1l1ll_l1_ (u"ࠬ࠭ㄽ"),l1l1ll_l1_ (u"࠭ࠧㄾ"),l1l1ll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨㄿ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡪࡨࡥࡩ࡯࡮ࡨࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦࠬㅀ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡽࡇࡻࡴࡵࡱࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡥࡂ࠭࠴ࠪࡀࠫ࠿ࠫㅁ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l1l1ll11lll_l1_:
				item = (link,title)
				l1l1ll1l1l1_l1_.append(item)
		if len(l1l1ll1l1l1_l1_)==1:
			link,title = l1l1ll1l1l1_l1_[0]
			l11l1l_l1_(link,l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㅂ"))
			return
		else:
			for link,title in l1l1ll1l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅃ"),menu_name+title,link,671,l1l1ll_l1_ (u"ࠬ࠭ㅄ"),l1l1ll_l1_ (u"࠭ࠧㅅ"),l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ㅆ"))
	if not l1l1ll1l1l1_l1_: l11l1l_l1_(url,l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧㅇ"))
	return
#l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l11llll111_l1_.l1lll1ll11_l1_?l1l1ll1ll1l_l1_=l1l1ll1ll11_l1_
#l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1l1l1l11_l1_.l1lll1ll11_l1_?l1l1ll1ll1l_l1_=l1l1ll1ll11_l1_
def PLAY(url):
	l111ll1_l1_ = []
	#url = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫࠳ๆ๐ไๆ࠯ๆีฯ๎ๆ࠮สสีอ๐࠭โ์࠰้฿อๅาห࠰้ฯ๊รๅศฬ࠱๊ีศࡠࡦ࠼࠻࠺ࡩࡢ࠸࠷࠶࠲࡭ࡺ࡭࡭ࠩㅈ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧㅉ"),url,l1l1ll_l1_ (u"ࠫࠬㅊ"),l1l1ll_l1_ (u"ࠬ࠭ㅋ"),l1l1ll_l1_ (u"࠭ࠧㅌ"),l1l1ll_l1_ (u"ࠧࠨㅍ"),l1l1ll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬㅎ"))
	html = response.content
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪࡨ࡯ࡥࡸ࡮ࡰ࡭ࡣࡼࡩࡷ࠭ㅏ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ㅐ"),block,re.DOTALL)
		for link,l11ll1l1_l1_ in l1ll_l1_:
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡷࡢࡶࡦ࡬ࡤࡥࠧㅑ")+l11ll1l1_l1_
			l111ll1_l1_.append(link)
	# l1l1l1l11_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡩ࡫ࡤ࠮ࡸ࡬ࡨࡪࡵࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨㅒ"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡦࡪ࡮ࡨ࠾ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨㅓ"),html,re.DOTALL)
	if l1ll_l1_:
		link = l1ll_l1_[0]
		if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬㅔ") not in link: link = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧㅕ")+link
		l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪㅖ"))
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨㅗ"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪㅘ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠬ࠭ㅙ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"࠭ࠧㅚ"): return
	search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩㅛ"),l1l1ll_l1_ (u"ࠨ࠭ࠪㅜ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩㅝ")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪㅞ"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨㅟ")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪㅠ"))
	return
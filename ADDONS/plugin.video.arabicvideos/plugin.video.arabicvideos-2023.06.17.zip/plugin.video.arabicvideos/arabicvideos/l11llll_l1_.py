# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪଙ") : l1l1ll_l1_ (u"ࠧࠨଚ") }
script_name = l1l1ll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧଛ")
menu_name = l1l1ll_l1_ (u"ࠩࡢࡅࡐ࡝࡟ࠨଜ")
l1l1l1_l1_ = WEBSITES[script_name][0]
#l11l1l1_l1_ = [l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨଝ"),l1l1ll_l1_ (u"่๊๊ࠫษࠩଞ"),l1l1ll_l1_ (u"ࠬอไฺำูࠤฬ๊วิส๋฽๏࠭ଟ"),l1l1ll_l1_ (u"࠭ๅิำะ๎ฮ࠭ଠ"),l1l1ll_l1_ (u"ࠧๆีิั๏ํࠧଡ"),l1l1ll_l1_ (u"ࠨษ฽๊๏ฯࠧଢ"),l1l1ll_l1_ (u"ࠩส฽้อๆࠨଣ"),l1l1ll_l1_ (u"่ࠪ็อมࠨତ")]
#proxy = l1l1ll_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶࠻࠹࠯࠴࠳࠷࠳࠾࠷࠯࠳࠶࠴࠿࠹࠱࠳࠺ࠪଥ")
#proxy = l1l1ll_l1_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬଦ")+l1l111l1_l1_[6][1]
proxy = l1l1ll_l1_ (u"࠭ࠧଧ")
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧฤๆ฼หอ࠭ନ"),l1l1ll_l1_ (u"ࠨษ็ฺ้อัฺหࠣห้ำัสࠩ଩"),l1l1ll_l1_ (u"ࠩส่็ืว็ࠢส่่ื๊ๆࠩପ"),l1l1ll_l1_ (u"ࠪห้้สษ๋ࠢࠤฬ๊วษฯสฯࠬଫ"),l1l1ll_l1_ (u"ࠫฬ๊ี้ำࠣ์ࠥอไฯๆไ๎ฬะࠧବ"),l1l1ll_l1_ (u"ࠬอไๆี็ื้อสࠡษ็หีอู๋หࠪଭ")]
def MAIN(mode,url,text):
	if   mode==240: results = MENU()
	elif mode==241: results = l11l1l_l1_(url,text)
	elif mode==242: results = l11ll1l_l1_(url)
	elif mode==243: results = PLAY(url)
	elif mode==244: results = l111l11_l1_(url,l1l1ll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪମ")+text)
	elif mode==245: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧଯ")+text)
	elif mode==246: results = l1lll1ll_l1_(url)
	elif mode==247: results = l1l1111l_l1_(url)
	elif mode==248: results = l11lll11_l1_()
	elif mode==249: results = SEARCH(text)
	else: results = False
	return results
def l11lll11_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩର"),l1l1ll_l1_ (u"ࠩࠪ଱"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଲ"),l1l1ll_l1_ (u"ࠫ์ึวࠡษ็้ํู่ࠡࠤฦ็ํอๅࠡษ็ะิ๐ฯࠣࠢไ๎ࠥฮูืࠢส่ศำ๊ศ่ࠣๅ๏ํࠠ็๊฼ࠤ๊์ࠠศๆะะอࠦึะࠢส่อืวๆฮࠣ࠲ࠥ๎็ัษࠣ๎ุฮศࠡ็ื็้ฯࠠโ์ࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦ࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦำษส๊ห๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊๊๊ࠡ๎ࠥะุ่ำࠣ์ฯิสโ์ࠣฬฺ๎ัสࠢ฼ุํอฦ๋หࠪଳ"))
	return
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ଴"),l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧଵ"),headers,l1l1ll_l1_ (u"ࠧࠨଶ"),l1l1ll_l1_ (u"ࠨࠩଷ"),l1l1ll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪସ"))
	html = response.content
	l11llll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡴࡳࡥ࠮ࡵ࡬ࡸࡪ࠳ࡢࡵࡰ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧହ"),html,re.DOTALL)
	if l11llll1_l1_: l11llll1_l1_ = l11llll1_l1_[0]
	else: l11llll1_l1_ = l1l1l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ଺"),l11llll1_l1_,l1l1ll_l1_ (u"ࠬ࠭଻"),headers,l1l1ll_l1_ (u"଼࠭ࠧ"),l1l1ll_l1_ (u"ࠧࠨଽ"),l1l1ll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩା"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩି"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪୀ"),l1l1ll_l1_ (u"ࠫࠬୁ"),249,l1l1ll_l1_ (u"ࠬ࠭ୂ"),l1l1ll_l1_ (u"࠭ࠧୃ"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫୄ"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୅"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ୆"),l1l1l1_l1_,246)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪେ"),menu_name+l1l1ll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧୈ"),l1l1l1_l1_,247)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ୉"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭୊"),l1l1ll_l1_ (u"ࠧࠨୋ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨୌ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢ୍ࠫ")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ୎"),l11llll1_l1_,241,l1l1ll_l1_ (u"ࠫࠬ୏"),l1l1ll_l1_ (u"ࠬ࠭୐"),l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ୑"))
	l11ll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭୒"),html,re.DOTALL)
	link = l11ll11l_l1_[0]
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୓"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ୔")+menu_name+l1l1ll_l1_ (u"ࠪว฻๐แࠡฯา๎ะอࠧ୕"),link,241)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩୖ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬୗ"),l1l1ll_l1_ (u"࠭ࠧ୘"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡮ࡤ࠰࠸ࠥࡪ࠭ࡧ࡮ࡨࡼࠥࡧ࡬ࡪࡩࡱ࠱࡮ࡺࡥ࡮ࡵ࠰ࡧࡪࡴࡴࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡨࡦࡣࡧࡩࡷ࠳࡬ࡪࡰ࡮ࠤࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ୙"),html,re.DOTALL)
	for link,name,block in l1lll11_l1_:
		if name in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ୚"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ୛")+menu_name+name,link,241)
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩଡ଼"),block,re.DOTALL)
		for link,title in items:
			if title in l1ll11_l1_: continue
			title = name+l1l1ll_l1_ (u"ࠫࠥ࠭ଢ଼")+title
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୞"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨୟ")+menu_name+title,link,241)
	return
def l1lll1ll_l1_(website=l1l1ll_l1_ (u"ࠧࠨୠ")):
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩୡ"),headers,l1l1ll_l1_ (u"ࠩࠪୢ"),l1l1ll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫୣ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࡯ࡣࡹࠫ୤"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ୥"),block,re.DOTALL)
		for link,title in items:
			if title not in l1ll11_l1_:
				title = title+l1l1ll_l1_ (u"࠭ࠠๆื้ๅฮ࠭୦")
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ୧"),menu_name+title,link,245)
		if website==l1l1ll_l1_ (u"ࠨࠩ୨"): addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ୩"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ୪"),l1l1ll_l1_ (u"ࠫࠬ୫"),9999)
	return html
def l1l1111l_l1_(website=l1l1ll_l1_ (u"ࠬ࠭୬")):
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧ୭"),headers,l1l1ll_l1_ (u"ࠧࠨ୮"),l1l1ll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ୯"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩ୰"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪୱ"),block,re.DOTALL)
		for link,title in items:
			if title not in l1ll11_l1_:
				title = title+l1l1ll_l1_ (u"๋ࠫࠥแๅฬิอࠬ୲")
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୳"),menu_name+title,link,244)
		if website==l1l1ll_l1_ (u"࠭ࠧ୴"): addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ୵"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ୶"),l1l1ll_l1_ (u"ࠩࠪ୷"),9999)
	return html
def l11l1l_l1_(url,type=l1l1ll_l1_ (u"ࠪࠫ୸")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ୹"),l1l1ll_l1_ (u"ࠬ࠭୺"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"࠭ࠧ୻"),headers,True,l1l1ll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ୼"))
	if type==l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ୽"): l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧ୾"),html,re.DOTALL)
	else: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳ࠳ࡦࡰࡱࡷࡩࡷ࠭୿"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ஀"),block,re.DOTALL)
		if not items:
			items = re.findall(l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡦࡺࡷ࠱ࡼ࡮ࡩࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஁"),block,re.DOTALL)
		for img,link,title in items:
			#if l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨஂ") in img: img = img.split(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠫஃ"))[1]
			if l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ஄") in link or l1l1ll_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡷࡴ࠱ࠪஅ") in link:
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪஆ"),menu_name+title,link,242,img)
			elif l1l1ll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭இ") in link:
				addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫஈ"),menu_name+title,link,243,img)
			elif l1l1ll_l1_ (u"࠭࠯ࡨࡣࡰࡩࡸ࠵ࠧஉ") not in link:
				addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ஊ"),menu_name+title,link,243,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ஋"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ஌"),block,re.DOTALL)
		for link,title in items:
			if title==l1l1ll_l1_ (u"ࠪࠪࡱࡹࡡࡲࡷࡲ࠿ࠬ஍"): title = l1l1ll_l1_ (u"ุࠫอศใหࠪஎ")
			if title==l1l1ll_l1_ (u"ࠬࠬࡲࡴࡣࡴࡹࡴࡁࠧஏ"): title = l1l1ll_l1_ (u"࠭ไศฯๅอࠬஐ")
			link = unescapeHTML(link)
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஑"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦࠧஒ")+title,link,241)
	return
def SEARCH(search):
	# l1lll11l_l1_://l1l111ll_l1_.l1ll1ll1_l1_/search?q=%l1l11l11_l1_%l1ll1lll_l1_%l1l11l11_l1_%l1lllll1_l1_%l1l11l11_l1_%l1ll11ll_l1_
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠩࠪஓ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠪࠫஔ"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠫࠥ࠭க"),l1l1ll_l1_ (u"ࠬࠫ࠲࠱ࠩ஖"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ஗")+l11lll1_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ஘"),l1l1ll_l1_ (u"ࠨࠩங"),url,l1l1ll_l1_ (u"ࠩࡖࡉࡆࡘࡃࡉࡡࡄࡏࡔࡇࡍࠨச"))
	results = l11l1l_l1_(url)
	return
def l11ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ஛"),l1l1ll_l1_ (u"ࠫࠬஜ"),url,l1l1ll_l1_ (u"ࠬࡋࡐࡊࡕࡒࡈࡊ࡙࡟ࡂࡍ࡚ࡅࡒ࠭஝"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"࠭ࠧஞ"),headers,True,l1l1ll_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬட"))
	if l1l1ll_l1_ (u"ࠨ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦࡃ࠭஠") not in html:
		img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ஡"))
		addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ஢"),menu_name+l1l1ll_l1_ (u"ࠫึอศุࠢส่ฯฺฺ๋ๆࠪண"),url,243,img)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸ࠲࠺ࠧத"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		l1ll1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ஥"),block,re.DOTALL)
		for link,title,img in l1ll1_l1_:
			#if l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ஦") in link: continue
			if l1l1ll_l1_ (u"ࠨษ็ั้่วหࠩ஧") in title or l1l1ll_l1_ (u"่ࠩ์ฬูๅࠡษัี๎࠭ந") in title: continue
			if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬன") in link: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫப"),menu_name+title,link,242,img)
			else: addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ஫"),menu_name+title,link,243,img)
	return
def PLAY(url):
	#l11lll11_l1_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#open(l1l1ll_l1_ (u"࠭ࡓ࠻࡞࡟ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭஬"), l1l1ll_l1_ (u"ࠧࡸࠩ஭")).write(html)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩம"),headers,True,l1l1ll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪய"))
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡦࡦࡪࡧࡦ࠯ࡧࡥࡳ࡭ࡥࡳ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬர"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	l11lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ற"),html,re.DOTALL)
	#l11lll1l_l1_ = ([l1l1ll_l1_ (u"ࠬ࠭ல"),l1l1ll_l1_ (u"࠭ࠧள")],[l1l1ll_l1_ (u"ࠧࠨழ"),l1l1ll_l1_ (u"ࠨࠩவ")])
	l11l1_l1_,l111l1l_l1_,l1l1l11_l1_,l1l11111_l1_ = [],[],[],[]
	if l11lll1l_l1_:
		l1l111l_l1_ = l1l1ll_l1_ (u"ࠩࡰࡴ࠹࠭ஶ")
		for l11lllll_l1_,l11ll1l1_l1_ in l11lll1l_l1_:
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡸࡦࡨ࠭ࡤࡱࡱࡸࡪࡴࡴࠡࡳࡸࡥࡱ࡯ࡴࡺࠤࠣ࡭ࡩࡃࠢࠨஷ")+l11lllll_l1_+l1l1ll_l1_ (u"ࠫࠧ࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾࠯࡞ࡶ࠮ࡁ࠵ࡤࡪࡸࡁࠫஸ"),html,re.DOTALL)
			block = l1lll11_l1_[0]
			l1l1l11_l1_.append(block)
			l1l11111_l1_.append(l11ll1l1_l1_)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡷࡵࡢ࡮࡬ࡸ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬஹ"),html,re.DOTALL)
		if not l1lll11_l1_:
			DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ஺"),l1l1ll_l1_ (u"ࠧࠨ஻"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ஼"),l1l1ll_l1_ (u"ࠩ็หࠥ๐่อั้้ࠣ็ࠠโ์า๎ํࠦแ๋๊ࠢิฬࠦวๅำสฬ฼࠭஽"))
			return
		else:
			block,filename = l1lll11_l1_[0]
			l11l11l_l1_ = [l1l1ll_l1_ (u"ࠪࡾ࡮ࡶࠧா"),l1l1ll_l1_ (u"ࠫࡷࡧࡲࠨி"),l1l1ll_l1_ (u"ࠬࡺࡸࡵࠩீ"),l1l1ll_l1_ (u"࠭ࡰࡥࡨࠪு"),l1l1ll_l1_ (u"ࠧࡩࡶࡰࠫூ"),l1l1ll_l1_ (u"ࠨࡶࡤࡶࠬ௃"),l1l1ll_l1_ (u"ࠩ࡬ࡷࡴ࠭௄"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡳ࡬ࠨ௅")]
			l1l111l_l1_ = filename.rsplit(l1l1ll_l1_ (u"ࠫ࠳࠭ெ"),1)[1].strip(l1l1ll_l1_ (u"ࠬࠦࠧே"))
			if l1l111l_l1_ in l11l11l_l1_:
				DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧை"),l1l1ll_l1_ (u"ࠧࠨ௉"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫொ"),l1l1ll_l1_ (u"ࠩส่๊๊แࠡๆํืࠥ็๊ะ์๋ࠤํ๊วࠡื๋ฮࠬோ"))
				return
		l1l1l11_l1_.append(block)
		l1l11111_l1_.append(l1l1ll_l1_ (u"ࠪࠫௌ"))
	for i in range(len(l1l1l11_l1_)):
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯ࡣࡰࡰ࠰ࠬ࠳࠰࠿ࠪࠤ்ࠪ"),l1l1l11_l1_[i],re.DOTALL)
		for link,l11ll1ll_l1_ in l1ll_l1_:
			if l1l1ll_l1_ (u"ࠬࡺ࡯ࡳࡴࡨࡲࡹ࠭௎") in l11ll1ll_l1_: continue
			#elif l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࠫ௏") in l11ll1ll_l1_: continue
			elif l1l1ll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩௐ") in l11ll1ll_l1_: type = l1l1ll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ௑")
			elif l1l1ll_l1_ (u"ࠩࡳࡰࡦࡿࠧ௒") in l11ll1ll_l1_: type = l1l1ll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ௓")
			else: type = l1l1ll_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ௔")
			#title = l1l11111_l1_[i]+l1l1ll_l1_ (u"ࠬࠦๅๅใࠣࠫ௕")+type
			#l111l1l_l1_.append(title)
			link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࠩ௖")+type+l1l1ll_l1_ (u"ࠧࡠࡡࡢࡣࠬௗ")+l1l11111_l1_[i]+l1l1ll_l1_ (u"ࠨࡡࡢࡥࡰࡽࡡ࡮ࠩ௘")
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ௙"),l111l1l_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ௚"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ௛"),url)
	return
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ௜"),l1l1ll_l1_ (u"࠭ࠧ௝"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ௞"),l1l1ll_l1_ (u"ࠨࠩ௟"),filter,url)
	l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࠪ௠"),l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ௡"),l1l1ll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ௢"),l1l1ll_l1_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ௣")]
	if l1l1ll_l1_ (u"࠭࠿ࠨ௤") in url: url = url.split(l1l1ll_l1_ (u"ࠧࡀࠩ௥"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ௦"),1)
	if filter==l1l1ll_l1_ (u"ࠩࠪ௧"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠪࠫ௨"),l1l1ll_l1_ (u"ࠫࠬ௩")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠬࡥ࡟ࡠࠩ௪"))
	if type==l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ௫"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠧ࠾ࠩ௬") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠨ࠿ࠪ௭") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠩࠩࠫ௮")+category+l1l1ll_l1_ (u"ࠪࡁ࠵࠭௯")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭௰")+category+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨ௱")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"࠭ࠦࠨ௲"))+l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ௳")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠨࠨࠪ௴"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠩࡤࡰࡱ࠭௵"))
		url2 = url+l1l1ll_l1_ (u"ࠪࡃࠬ௶")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ௷"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ௸"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"࠭ࠧ௹"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠧࡢ࡮࡯ࠫ௺"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠨࠩ௻"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠩࡂࠫ௼")+l1l1ll1l_l1_
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ௽"),menu_name+l1l1ll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬ࠭௾"),url2,241,l1l1ll_l1_ (u"ࠬ࠭௿"),l1l1ll_l1_ (u"࠭࠱ࠨఀ"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧఁ"),menu_name+l1l1ll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨం")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨః"),url2,241,l1l1ll_l1_ (u"ࠪࠫఄ"),l1l1ll_l1_ (u"ࠫ࠶࠭అ"))
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪఆ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ఇ"),l1l1ll_l1_ (u"ࠧࠨఈ"),9999)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩఉ"),headers,True,l1l1ll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫఊ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢ࡬ࡨ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪఋ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠳࠰࠿࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪఌ"),block,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭఍"),l1l1ll_l1_ (u"࠭ࠧఎ"),l1l1ll_l1_ (u"ࠧࠨఏ"),str(l1111ll_l1_))
	dict = {}
	for l11111l_l1_,name,block in l1111ll_l1_:
		#name = name.replace(l1l1ll_l1_ (u"ࠨ࠯࠰ࠫఐ"),l1l1ll_l1_ (u"ࠩࠪ఑"))
		items = re.findall(l1l1ll_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡀࠫ࠲࠯ࡅࠩ࠽ࠩఒ"),block,re.DOTALL)
		if l1l1ll_l1_ (u"ࠫࡂ࠭ఓ") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩఔ"):
			if category!=l11111l_l1_: continue
			elif len(items)<=1:
				if l11111l_l1_==l1ll1111_l1_[-1]: l11l1l_l1_(url2)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭క")+l1ll11l1_l1_)
				return
			else:
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧఖ"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠨగ"),url2,241,l1l1ll_l1_ (u"ࠩࠪఘ"),l1l1ll_l1_ (u"ࠪ࠵ࠬఙ"))
				else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫచ"),menu_name+l1l1ll_l1_ (u"ࠬอไอ็ํ฽ࠬఛ"),url2,245,l1l1ll_l1_ (u"࠭ࠧజ"),l1l1ll_l1_ (u"ࠧࠨఝ"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩఞ"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠩࠩࠫట")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁ࠵࠭ఠ")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭డ")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨఢ")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪణ")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧత"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠣࠫథ")+name,url2,244,l1l1ll_l1_ (u"ࠩࠪద"),l1l1ll_l1_ (u"ࠪࠫధ"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭న"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if option in l1ll11_l1_: continue
			if l1l1ll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ఩") not in value: value = option
			else: value = re.findall(l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧప"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠧࠧࠩఫ")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࠪబ")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠩࠩࠫభ")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࠬమ")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨయ")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠬࠦ࠺ࠡࠩర")#+dict[l11111l_l1_][l1l1ll_l1_ (u"࠭࠰ࠨఱ")]
			title = option+l1l1ll_l1_ (u"ࠧࠡ࠼ࠣࠫల")+name
			if type==l1l1ll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩళ"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩఴ"),menu_name+title,url,244,l1l1ll_l1_ (u"ࠪࠫవ"),l1l1ll_l1_ (u"ࠫࠬశ"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧష"))
			elif type==l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪస") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠧ࠾ࠩహ") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠨࡣ࡯ࡰࠬ఺"))
				url3 = url+l1l1ll_l1_ (u"ࠩࡂࠫ఻")+l1l1l1l1_l1_
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴ఼ࠪ"),menu_name+title,url3,241,l1l1ll_l1_ (u"ࠫࠬఽ"),l1l1ll_l1_ (u"ࠬ࠷ࠧా"))
			else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ి"),menu_name+title,url,245,l1l1ll_l1_ (u"ࠧࠨీ"),l1l1ll_l1_ (u"ࠨࠩు"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪూ"),l1l1ll_l1_ (u"ࠪࠫృ"),filters,l1l1ll_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬౄ"))
	# mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ౅")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩె")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠧࡢ࡮࡯ࠫే")					all filters (l1l1l111_l1_ l1ll1l1l_l1_ filter)
	#filters = filters.replace(l1l1ll_l1_ (u"ࠨ࠿ࠩࠫై"),l1l1ll_l1_ (u"ࠩࡀ࠴ࠫ࠭౉"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠪࠪࠬొ"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠫࡂ࠭ో") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠬࠬࠧౌ"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"࠭࠽ࠨ్"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠧࠨ౎")
	l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࠩ౏"),l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ౐"),l1l1ll_l1_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ౑"),l1l1ll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ౒"),l1l1ll_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ౓"),l1l1ll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ౔"),l1l1ll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨౕ")]
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠨ࠲ౖࠪ")
		#if l1l1ll_l1_ (u"ࠩࠨࠫ౗") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬౘ") and value!=l1l1ll_l1_ (u"ࠫ࠵࠭ౙ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩౚ")+value
		elif mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ౛") and value!=l1l1ll_l1_ (u"ࠧ࠱ࠩ౜"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠨࠪౝ")+key+l1l1ll_l1_ (u"ࠩࡀࠫ౞")+value
		elif mode==l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧ౟"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭ౠ")+key+l1l1ll_l1_ (u"ࠬࡃࠧౡ")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪౢ"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠩౣ"))
	#l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠨ࠿࠳ࠫ౤"),l1l1ll_l1_ (u"ࠩࡀࠫ౥"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ౦"),l1l1ll_l1_ (u"ࠫࠬ౧"),filters,l1l1ll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭౨"))
	return l1llllll_l1_
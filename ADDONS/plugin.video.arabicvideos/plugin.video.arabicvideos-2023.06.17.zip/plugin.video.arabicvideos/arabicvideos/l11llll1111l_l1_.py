# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ幐")
menu_name = l1l1ll_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ幑")
l1l1l1_l1_ = WEBSITES[script_name][0]
#headers = l1l1ll_l1_ (u"ࠪࠫ幒")
#headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ幓"):l1l1ll_l1_ (u"ࠬ࠭幔")}
def MAIN(mode,url,text,type,page):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l1l11l1l11_l1_(url)
	#elif mode==142: results = l11lll1lll1l_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,page)
	elif mode==145: results = l1l1111ll11l_l1_(url)
	elif mode==146: results = l11lll1l1ll1_l1_(url)
	elif mode==147: results = l1l111111l1l_l1_()
	elif mode==148: results = l1l111111lll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡉ࠹ࡘࡤ࡚ࡎࡆ࡚ࡹࡺ࡭ࡄࡷࡑࡘࡽࡆࡧ࡜࡝࡚࡙ࡒࡐࡌࡼࡽࡴࡷࡾࡏࡔࠩ幕")
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ幖"),menu_name+l1l1ll_l1_ (u"ࠨࡖࡈࡗ࡙࡙ࠦࡐࡗࡗ࡙ࡇࡋࠧ幗"),url,144)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ幘"),menu_name+l1l1ll_l1_ (u"ࠪࡳࡱࡪࡥࡳࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࠤࡳࡵࡴࠡ࡮࡬ࡷࡹ࡯࡮ࡨࠢࡱࡩࡼ࡫ࡲࠡࡲ࡯ࡽࡦࡲࡩࡴࡶࠪ幙"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡚ࡉࡴࡶ࡫࡙ࡻ࡚࡝ࡪࡰࠬ࡬ࡪࡵࡷࡁࡗࡊࡑࡎ࠸࠶ࡺࡍࡰࡐ࠱ࡪࡨࡘࡸ࠭幚"),144)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ幛"),menu_name+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤๆอั฻ࠩ幜"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡹࡕࡶࡰࡰ࡭࠸ࡌࡿ࡯ࡱࡏࡗࡑࡇࡧ࠲࠴ࡳࡘࡧࡼ࠭幝"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ幞"),menu_name+l1l1ll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ幟"),l1l1ll_l1_ (u"ࠪࠫ幠"),149,l1l1ll_l1_ (u"ࠫࠬ幡"),l1l1ll_l1_ (u"ࠬ࠭幢"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ幣"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ幤"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ幥")+l1l1ll_l1_ (u"ࠩࡢ࡝࡙ࡉ࡟ࠨ幦")+l1l1ll_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣห้๋ศา็ฯࠫ幧"),l1l1ll_l1_ (u"ࠫࠬ幨"),290)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ幩"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ幪")+menu_name+l1l1ll_l1_ (u"ࠧๆ๊สๆ฾ࠦวฯฬสี์อ๋๊ࠠอ๎ํฮࠧ幫"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ幬"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ幭"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ幮")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭幯"),l1l1l1_l1_,144,l1l1ll_l1_ (u"ࠬ࠭幰"),l1l1ll_l1_ (u"࠭ࠧ幱"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ干"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ平"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ年")+menu_name+l1l1ll_l1_ (u"ࠪห้๋อห๊์ࠤฬ๊ัศศฯࠫ幵"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ并"),146)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ幷"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭幸"),l1l1ll_l1_ (u"ࠧࠨ幹"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ幺"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ幻")+menu_name+l1l1ll_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะฺࠠำห๎ฮ࠭幼"),l1l1ll_l1_ (u"ࠫࠬ幽"),147)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ幾"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ广")+menu_name+l1l1ll_l1_ (u"ࠧษฯฮ࠾่ࠥๆ้ษอࠤศาๆษ์ฬࠫ庀"),l1l1ll_l1_ (u"ࠨࠩ庁"),148)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庂"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ広")+menu_name+l1l1ll_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡ฻ิฬ๏ฯࠧ庄"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃแ๋ๆ่ࠫ庅"),144)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭庆"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ庇")+menu_name+l1l1ll_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ庈"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ庉"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ床"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭庋")+menu_name+l1l1ll_l1_ (u"ࠬฮอฬ࠼ุ้ࠣือ๋ษอࠤ฾ืศ๋หࠪ庌"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆีิั๏ฯࠧ庍"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ庎"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ序")+menu_name+l1l1ll_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ庐"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ庑"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ庒"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ库")+menu_name+l1l1ll_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ应"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭底"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ庖"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ店")+menu_name+l1l1ll_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢๆหึะ่็ࠩ庘"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ้วาฬ๋๊ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ庙"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庚"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ庛")+menu_name+l1l1ll_l1_ (u"ࠧษฯฮ࠾ࠥิืษหࠣห้๋ัอ฻ํอࠬ府"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫไำห่ฬวࠫศๆไฺฬฬ๊ส࠭ั฻อฯࠫศๆฯ้฾ฯࠦࡴࡲࡀࡇࡆࡏࡓࡂࡪࡄࡆࠬ庝"),144)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庞"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ废")+menu_name+l1l1ll_l1_ (u"ࠫฬู๊าษๅࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ庠"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࡐࡍ࠶࡭࡙ࡶ࠼ࡰ࡯ࡉ࠶࠺ࡖࡰࡵ࡙ࡆ࡫ࡒࡳࡏ࡬ࡳ࡫ࡸࡾࡷࡵࡔࡇࡶࡰࡪࡷ࠭庡"),144)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭庢"),menu_name+l1l1ll_l1_ (u"ࠧศ฻าหิอสࠡษูหๆฯ๋๊ࠠอ๎ํฮࠧ庣"),l1l1ll_l1_ (u"ࠨࠩ庤"),144)
	#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ庥"),l1l1ll_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ度"),l1l1ll_l1_ (u"ࠫ์ึวࠡษ็หำะ๊ศำࠣืํ็๋ࠠะิะ่ࠦๅ็ࠢส่อืๆศ็ฯࠫ座"),l1l1ll_l1_ (u"๊ࠬร็้ࠣืํ็๋ࠠไ๋้ࠥฮสี฼ํ่ࠥฮั็ษ่ะࠥ๐่ห์๋ฬࠬ庨"))
	#if yes==1:
	#	url = l1l1ll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ庩")
	#	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠬࠫ庪"))
	#	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠨࡔࡨࡴࡱࡧࡣࡦ࡙࡬ࡲࡩࡵࡷࠩࡸ࡬ࡨࡪࡵࡳ࠭ࠩ庫")+url+l1l1ll_l1_ (u"ࠩࠬࠫ庬"))
	#	#xbmc.executebuiltin(l1l1ll_l1_ (u"ࠪࡖࡺࡴࡁࡥࡦࡲࡲ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠮࠭庭"))
	return
l1l1ll_l1_ (u"ࠦࠧࠨࠊࡥࡧࡩࠤࡒࡇࡉࡏࡒࡄࡋࡊ࠮ࡵࡳ࡮ࠬ࠾ࠏࠏࡨࡵ࡯࡯࠰ࡨࡩࠬࡥࡣࡷࡥࠥࡃࠠࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇࠨࡶࡴ࡯࠭ࠏࠏࡩࡧࠢࠪࡖࡪ࡬ࡡࡢࡶࠣࡅࡱ࠳ࡇࡢ࡯ࡰࡥࡱ࠭ࠠࡪࡰࠣ࡬ࡹࡳ࡬࠻ࠢࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠭ࠩࡼࡩࡸ࠭ࠩࠋࠋࡧࡨࠥࡃࠠࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲ࡯ࡣࡪࡩ࠭ࡲࡥ࡯ࠪࡧࡨ࠮࠯࠺ࠋࠋࠌ࡭ࡹ࡫࡭ࠡ࠿ࠣࡨࡩࡡࡩ࡞ࠌࠌࠍࡎࡔࡓࡆࡔࡗࡣࡎ࡚ࡅࡎࡡࡗࡓࡤࡓࡅࡏࡗࠫ࡭ࡹ࡫࡭ࠪࠌࠌࡍ࡙ࡋࡍࡔࠪࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦ庮")
def l1l111111l1l_l1_():
	ITEMS(l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯อัࠦࡴࡲࡀࡉ࡬ࡐࡁࡂࡓࡀࡁࠬ庯"))
	return
def l1l111111lll_l1_():
	ITEMS(l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡵࡸࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ庰"))
	return
def PLAY(url,type):
	#url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡬࡮ࡋ࠸ࡅ࡯࠷ࡹ࠺࠸ࡨࠩ庱")
	#items = re.findall(l1l1ll_l1_ (u"ࠨࡸࡀࠬ࠳࠰࠿ࠪࠦࠪ庲"),url,re.DOTALL)
	#id = items[0]
	#link = l1l1ll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭庳")+id
	#PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ庴"))
	#return
	l1l1ll_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡰࡴࡴࡸࡴࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖࠎࠎࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡪ࡬ࡐ࠽ࡃ࡭࠵ࡷ࠸࠽࡭ࠧࠋࠋࡨࡶࡷࡵࡲࡴ࠮ࡷ࡭ࡹࡲࡥࡴ࠮࡯࡭ࡳࡱࡳࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠴ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶࠭ࡻࡲ࡭ࠫࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠩࡷࡵࡰ࠮ࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠭ࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱ࡺࡹࡱࡧࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤ庵")
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l11lll1l1ll1_l1_(url):
	html,cc,data = l1l111111111_l1_(url)
	dd = cc[l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ庶")][l1l1ll_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ康")][l1l1ll_l1_ (u"ࠧࡵࡣࡥࡷࠬ庸")]
	for ii in range(len(dd)):
		item = dd[ii]
		l1l1111l1l11_l1_(item,url,str(ii))
	ee = dd[0][l1l1ll_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭庹")][l1l1ll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ庺")][l1l1ll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ庻")][l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭庼")]
	s = 0
	for ii in range(len(ee)):
		item = ee[ii][l1l1ll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ庽")][l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ庾")][0]
		if list(item[l1l1ll_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ庿")][l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ廀")].keys())[0]==l1l1ll_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ廁"): continue
		succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_ = l1l1111lll1l_l1_(item)
		if not title:
			s += 1
			title = l1l1ll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥืววฮฬࠤࠬ廂")+str(s)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廃"),menu_name+title,url,144,l1l1ll_l1_ (u"ࠬ࠭廄"),str(ii))
	key = re.findall(l1l1ll_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ廅"),html,re.DOTALL)
	url2 = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ廆")+key[0]
	html,cc,data2 = l1l111111111_l1_(url2)
	for jj in range(3,4):
		dd = cc[l1l1ll_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ廇")][jj][l1l1ll_l1_ (u"ࠩࡪࡹ࡮ࡪࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ廈")][l1l1ll_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ廉")]
		for ii in range(len(dd)):
			item = dd[ii]
			if l1l1ll_l1_ (u"ࠫ࡞ࡵࡵࡕࡷࡥࡩࠥࡖࡲࡦ࡯࡬ࡹࡲ࠭廊") in str(item): continue
			l1l1111l1l11_l1_(item)
	return
def ITEMS(url,data=l1l1ll_l1_ (u"ࠬ࠭廋"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ廌"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ廍"),l1l1ll_l1_ (u"ࠨࠩ廎"))
	html,cc,data2 = l1l111111111_l1_(url,data)
	l1l11l111l_l1_,ff = l1l1ll_l1_ (u"ࠩࠪ廏"),l1l1ll_l1_ (u"ࠪࠫ廐")
	#if l1l1ll_l1_ (u"ࠫࡴࡽ࡮ࡦࡴࠪ廑") in html.lower(): DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭廒"),l1l1ll_l1_ (u"࠭ࠧ廓"),l1l1ll_l1_ (u"ࠧࡰࡹࡱࡩࡷࠦࡥࡹ࡫ࡶࡸࠬ廔"),l1l1ll_l1_ (u"ࠨ࡫ࡱࠤ࡭ࡺ࡭࡭ࠩ廕"))
	owner = re.findall(l1l1ll_l1_ (u"ࠩࠥࡳࡼࡴࡥࡳࡐࡤࡱࡪࠨ࠮ࠫࡁࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ廖"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l1ll_l1_ (u"ࠪࠦࡻ࡯ࡤࡦࡱࡒࡻࡳ࡫ࡲࠣ࠰࠭ࡃࠧࡺࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ廗"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l1ll_l1_ (u"ࠫࠧࡩࡨࡢࡰࡱࡩࡱࡓࡥࡵࡣࡧࡥࡹࡧࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡲࡻࡳ࡫ࡲࡖࡴ࡯ࡷࠧࡀ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ廘"),html,re.DOTALL)
	if owner:
		l1l11l111l_l1_ = l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ廙")+owner[0][0]+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ廚")
		link = owner[0][1]
		if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ廛") not in link: link = l1l1l1_l1_+link
		#if l1l1ll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ廜") in url and l1l1ll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ廝") not in url and l1l1ll_l1_ (u"ࠪ࠳ࡨ࠵ࠧ廞") not in url and l1l1ll_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ廟") not in url:
		if l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ廠") in url: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廡"),menu_name+l1l11l111l_l1_,link,144)
	#if cc==l1l1ll_l1_ (u"ࠧࠨ廢"): l11lll1ll1ll_l1_(url,html) ; return
	l11lll1ll11l_l1_ = [l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ廣"),l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ廤"),l1l1ll_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭廥"),l1l1ll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ廦"),l1l1ll_l1_ (u"ࠬ࠵ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ廧"),l1l1ll_l1_ (u"࠭ࡳࡴ࠿ࠪ廨"),l1l1ll_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ廩"),l1l1ll_l1_ (u"ࠨ࡭ࡨࡽࡂ࠭廪"),l1l1ll_l1_ (u"ࠩࡥࡴࡂ࠭廫"),l1l1ll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭廬")]
	l11lll1l1l11_l1_ = not any(value in url for value in l11lll1ll11l_l1_)
	if l11lll1l1l11_l1_ and l1l11l111l_l1_:
		l11llll11_l1_ = l1l1ll_l1_ (u"ࠫฬ๊ศฮอࠪ廭")
		title2 = l1l1ll_l1_ (u"่่ࠬศศ่ࠤฬ๊สี฼ํ่ࠬ廮")
		l11lll1ll_l1_ = l1l1ll_l1_ (u"࠭วๅใํำ๏๎็ศฬࠪ廯")
		l11lll1l1l1l_l1_ = l1l1ll_l1_ (u"ࠧศๆๅ๊ํอสࠨ廰")
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭廱"),menu_name+l1l11l111l_l1_,url,9999)
		if l1l1ll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦอำหࠣࠩ廲") in html: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ廳"),menu_name+l11llll11_l1_,url,145,l1l1ll_l1_ (u"ࠫࠬ廴"),l1l1ll_l1_ (u"ࠬ࠭廵"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ延"))
		if l1l1ll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠤࠪ廷") in html: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ廸"),menu_name+title2,url+l1l1ll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭廹"),144)
		if l1l1ll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ建") in html: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廻"),menu_name+l11lll1ll_l1_,url+l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭廼"),144)
		if l1l1ll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๆ๋๎วหࠤࠪ廽") in html: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廾"),menu_name+l11lll1l1l1l_l1_,url+l1l1ll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ廿"),144)
		if l1l1ll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬ开") in html: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弁"),menu_name+l11llll11_l1_,url,145,l1l1ll_l1_ (u"ࠫࠬ异"),l1l1ll_l1_ (u"ࠬ࠭弃"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ弄"))
		if l1l1ll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭弅") in html: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弆"),menu_name+title2,url+l1l1ll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭弇"),144)
		if l1l1ll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࡜ࡩࡥࡧࡲࡷࠧ࠭弈") in html: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弉"),menu_name+l11lll1ll_l1_,url+l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭弊"),144)
		if l1l1ll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ弋") in html: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弌"),menu_name+l11lll1l1l1l_l1_,url+l1l1ll_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ弍"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ弎"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ式"),l1l1ll_l1_ (u"ࠫࠬ弐"),9999)
	if l1l1ll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ弑") in url:
		dd = cc[l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ弒")][l1l1ll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弓")][l1l1ll_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ弔")][l1l1ll_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ引")][l1l1ll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ弖")]
		l11lll1l11l1_l1_ = 0
		for i in range(len(dd)):
			if l1l1ll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弗") in list(dd[i].keys()):
				l11lll1l111l_l1_ = dd[i][l1l1ll_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ弘")]
				length = len(str(l11lll1l111l_l1_))
				if length>l11lll1l11l1_l1_:
					l11lll1l11l1_l1_ = length
					ff = l11lll1l111l_l1_
		if l11lll1l11l1_l1_==0: return
	elif l1l1ll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭弙") in url or l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀ࡭ࡨࡽࡂ࠭弚") in url or l1l1ll_l1_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡁ࡮ࡩࡾࡃࠧ弛") in url or l1l1ll_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ弜") in url or l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ弝") in url or url==l1l1l1_l1_:
		l11llll1l1ll_l1_ = []
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡉ࡯࡮࡯ࡤࡲࡩࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ弞"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡁࡤࡶ࡬ࡳࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ弟"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡣࡤ࡝࠴ࡡࡠ࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠧ张"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡤࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ弡"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡥࡦ࡟࠶ࡣ࡛ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠨ弢"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟࡞࠱࠶ࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡢࡤ࡯ࡩ࡙ࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟ࠥ弣"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ弤"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯࡙ࡤࡸࡨ࡮ࡎࡦࡺࡷࡖࡪࡹࡵ࡭ࡶࡶࠫࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠧ࡞ࠤ弥"))
		l11lll1ll111_l1_,ff = l11llll11111_l1_(cc,l1l1ll_l1_ (u"ࠬ࠭弦"),l11llll1l1ll_l1_)
	if not ff:
		try:
			dd = cc[l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ弧")][l1l1ll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弨")][l1l1ll_l1_ (u"ࠨࡶࡤࡦࡸ࠭弩")]
			cond1 = l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ弪") in url or l1l1ll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ弫") in url or l1l1ll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ弬") in url
			l11llll11l11_l1_ = l1l1ll_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆไ๎ิ๐่่ษอࠦࠬ弭") in html or l1l1ll_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ弮") in html or l1l1ll_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ弯") in html
			l11llll111ll_l1_ = l1l1ll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼࡚ࠥ࡮ࡪࡥࡰࡵࠥࠫ弰") in html or l1l1ll_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡕࡲࡡࡺ࡮࡬ࡷࡹࡹࠢࠨ弱") in html or l1l1ll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡉࡨࡢࡰࡱࡩࡱࡹࠢࠨ弲") in html
			if cond1 and (l11llll11l11_l1_ or l11llll111ll_l1_):
				for ii in range(len(dd)):
					if l1l1ll_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ弳") not in list(dd[ii].keys()): continue
					ee = dd[ii][l1l1ll_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ弴")]
					try: gg = ee[l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ張")][l1l1ll_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭弶")][l1l1ll_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ強")][l1l1ll_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ弸")][l1l1ll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭弹")][ii]
					except: gg = ee
					try: link = gg[l1l1ll_l1_ (u"ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭强")][l1l1ll_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ弻")][l1l1ll_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ弼")][l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ弽")]
					except: continue
					if   l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ弾")		in link	and l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ弿")		in url: ee = dd[ii] ; break
					elif l1l1ll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ彀")	in link	and l1l1ll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ彁")	in url: ee = dd[ii] ; break
					elif l1l1ll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ彂")	in link	and l1l1ll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ彃")		in url: ee = dd[ii] ; break
					else: ee = dd[0]
			elif l1l1ll_l1_ (u"ࠧࡣࡲࡀࠫ彄") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l1l1ll_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彅")][l1l1ll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ彆")]
		except: pass
	if not ff: return
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ彇"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡓ࡯ࡷ࡫ࡨࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ彈"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ彉"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ彊"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ彋"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ彌"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ彍"))
	if l1l1ll_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ彎") not in url: l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡷࡺࡨࡍࡦࡰࡸࠫࡢࡡࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡚ࡹࡱࡧࡖࡹࡧࡓࡥ࡯ࡷࡌࡸࡪࡳࡳࠨ࡟ࠥ彏"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ彐"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ彑"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡛࡯ࡤࡦࡱࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ归"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ当"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ彔"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ录"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡫࡬࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ彖"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ彗"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡦࡧࠤ彘"))
	l11lll1lll11_l1_ = l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡵࠨๅ็ࠤ็๎วว็ࠣห้ะิ฻์็ࠫ彙"))
	l11lll1l11ll_l1_ = l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡶࠩๆ่ࠥอไโ์า๎ํํวหࠩ彚"))
	l11lll1l1lll_l1_ = l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡷࠪ็้ࠦวๅไ้์ฬะࠧ彛"))
	l11lll11ll1_l1_ = [l11lll1lll11_l1_,l11lll1l11ll_l1_,l11lll1l1lll_l1_,l1l1ll_l1_ (u"ࠪࡅࡱࡲࠠࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ彜"),l1l1ll_l1_ (u"ࠫࡆࡲ࡬ࠡࡸ࡬ࡨࡪࡵࡳࠨ彝"),l1l1ll_l1_ (u"ࠬࡇ࡬࡭ࠢࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ彞")]
	l11lll1ll1l1_l1_,gg = l11llll11111_l1_(ff,index,l11llll1l1ll_l1_)
	if l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ彟") in str(type(gg)) and any(value in str(gg[0]) for value in l11lll11ll1_l1_): del gg[0]
	for index2 in range(len(gg)):
		l11llll1l1ll_l1_ = []
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ彠"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ彡"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡇࡦࡸࡤࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ形"))
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ彣"))		#4
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ彤"))		#7
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ彥"))		#6
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ彦"))		#5
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠࠦ彧"))
		l11lll1ll111_l1_,item = l11llll11111_l1_(gg,index2,l11llll1l1ll_l1_)
		#if l11lll1ll111_l1_ not in [l1l1ll_l1_ (u"ࠨ࠴ࠪ彨"),l1l1ll_l1_ (u"ࠩ࠷ࠫ彩"),l1l1ll_l1_ (u"ࠪ࠹ࠬ彪")]: l1l1111l1l11_l1_(item)		# 2,4,7
		#else: l1l1111l1l11_l1_(item,url,str(index2))
		l1l1111l1l11_l1_(item,url,str(index2))
		if l11lll1ll111_l1_==l1l1ll_l1_ (u"ࠫ࠹࠭彫"):
			try:
				hh = item[l1l1ll_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ彬")][l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ彭")][l1l1ll_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彮")][l1l1ll_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ彯")]
				for l1l1111111ll_l1_ in range(len(hh)):
					l11lll1llll1_l1_ = hh[l1l1111111ll_l1_]
					l1l1111l1l11_l1_(l11lll1llll1_l1_)
			except: pass
	l11lllll1l11_l1_ = False
	if l1l1ll_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ彰") not in url and l11lll1ll1l1_l1_==l1l1ll_l1_ (u"ࠪ࠼ࠬ影"): l11lllll1l11_l1_ = True
	if l1l1ll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ彲") in data2: l1l11111ll11_l1_,key,l1l11111l1l1_l1_,l1l111111ll1_l1_,token,l11llllll111_l1_ = data2.split(l1l1ll_l1_ (u"ࠬࡀ࠺࠻ࠩ彳"))
	else: l1l11111ll11_l1_,key,l1l11111l1l1_l1_,l1l111111ll1_l1_,token,l11llllll111_l1_ = l1l1ll_l1_ (u"࠭ࠧ彴"),l1l1ll_l1_ (u"ࠧࠨ彵"),l1l1ll_l1_ (u"ࠨࠩ彶"),l1l1ll_l1_ (u"ࠩࠪ彷"),l1l1ll_l1_ (u"ࠪࠫ彸"),l1l1ll_l1_ (u"ࠫࠬ役")
	url2,l1ll1ll11ll_l1_ = l1l1ll_l1_ (u"ࠬ࠭彺"),l1l1ll_l1_ (u"࠭ࠧ彻")
	if menuItemsLIST:
		l11llll111l1_l1_ = str(menuItemsLIST[-1][1])
		if   menu_name+l1l1ll_l1_ (u"ࠧࡄࡊࡑࡐࠬ彼") in l11llll111l1_l1_: l1ll1ll11ll_l1_ = l1l1ll_l1_ (u"ࠨࡅࡋࡅࡓࡔࡅࡍࡕࠪ彽")
		elif menu_name+l1l1ll_l1_ (u"ࠩࡘࡗࡊࡘࠧ彾") in l11llll111l1_l1_: l1ll1ll11ll_l1_ = l1l1ll_l1_ (u"ࠪࡇࡍࡇࡎࡏࡇࡏࡗࠬ彿")
		elif menu_name+l1l1ll_l1_ (u"ࠫࡑࡏࡓࡕࠩ往") in l11llll111l1_l1_: l1ll1ll11ll_l1_ = l1l1ll_l1_ (u"ࠬࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ征")
	if l1l1ll_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡹࠢࠨ徂") in html and l1l1ll_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ徃") not in url and not l11lllll1l11_l1_ and l1l1ll_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࠪ径") not in url:	# and (index!=l1l1ll_l1_ (u"ࠩࠪ待") or l1l1ll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ徆") in url or l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ徇") in url or l1l1ll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ很") in url or l1l1ll_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ徉") in url):
		url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥࡠࡣ࡭ࡥࡽࡅࡣࡵࡱ࡮ࡩࡳࡃࠧ徊")+l1l11111l1l1_l1_
	elif l1l1ll_l1_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣࠩ律") in html and l1l1ll_l1_ (u"ࠩࡥࡴࡂ࠭後") not in url and l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ徍") in url or l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ徎") in url:
		url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ徏")+key
	elif l1l1ll_l1_ (u"࠭ࠢࡵࡱ࡮ࡩࡳࠨࠧ徐") in html and l1l1ll_l1_ (u"ࠧࡣࡲࡀࠫ徑") not in url:
		url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ徒")+key
	if url2: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ従"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡลัี๎࠭徔"),url2,144,l1ll1ll11ll_l1_,l1l1ll_l1_ (u"ࠫࠬ徕"),data2)
	return
def l11llll11111_l1_(l1l111l1l11_l1_,l1l11l1111l_l1_,l11lllll1l1l_l1_):
	cc = l1l111l1l11_l1_
	ff,index = l1l111l1l11_l1_,l1l11l1111l_l1_
	gg,index2 = l1l111l1l11_l1_,l1l11l1111l_l1_
	item,render = l1l111l1l11_l1_,l1l11l1111l_l1_
	count = len(l11lllll1l1l_l1_)
	for ii in range(count):
		try:
			out = eval(l11lllll1l1l_l1_[ii])
			#if isinstance(out,dict): out = l1l1ll_l1_ (u"ࠬ࠭徖")
			return str(ii+1),out
		except: pass
	return l1l1ll_l1_ (u"࠭ࠧ得"),l1l1ll_l1_ (u"ࠧࠨ徘")
def l1l1111lll1l_l1_(item):
	try: l1l1111l1111_l1_ = list(item.keys())[0]
	except: return False,l1l1ll_l1_ (u"ࠨࠩ徙"),l1l1ll_l1_ (u"ࠩࠪ徚"),l1l1ll_l1_ (u"ࠪࠫ徛"),l1l1ll_l1_ (u"ࠫࠬ徜"),l1l1ll_l1_ (u"ࠬ࠭徝"),l1l1ll_l1_ (u"࠭ࠧ從"),l1l1ll_l1_ (u"ࠧࠨ徟")
	succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_ = False,l1l1ll_l1_ (u"ࠨࠩ徠"),l1l1ll_l1_ (u"ࠩࠪ御"),l1l1ll_l1_ (u"ࠪࠫ徢"),l1l1ll_l1_ (u"ࠫࠬ徣"),l1l1ll_l1_ (u"ࠬ࠭徤"),l1l1ll_l1_ (u"࠭ࠧ徥"),l1l1ll_l1_ (u"ࠧࠨ徦")
	#WRITE_THIS(l1l1ll_l1_ (u"ࠨࠩ徧"),str(item))
	render = item[l1l1111l1111_l1_]
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ徨"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ復"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ循"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ徫"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ徬"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ徭"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ微"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ徯"))
	l11lll1ll111_l1_,title = l11llll11111_l1_(item,render,l11llll1l1ll_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ徰"),l1l1ll_l1_ (u"ࠫࠬ徱"),l1l1ll_l1_ (u"ࠬ࠭徲"),title)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ徳"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ徴"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ徵"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ徶")) # required for l1l11111l11_l1_ l11lllll1l11_l1_
	l11lll1ll111_l1_,link = l11llll11111_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ德"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ徸"))
	l11lll1ll111_l1_,img = l11llll11111_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡶࡪࡦࡨࡳࡈࡵࡵ࡯ࡶࠪࡡࠧ徹"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࡘࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ徺"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡂࡰࡶࡷࡳࡲࡖࡡ࡯ࡧ࡯ࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ徻"))
	l11lll1ll111_l1_,count = l11llll11111_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡯ࡩࡳ࡭ࡴࡩࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ徼"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ徽"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ徾"))
	l11lll1ll111_l1_,duration = l11llll11111_l1_(item,render,l11llll1l1ll_l1_)
	if l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࠩ徿") in duration: duration,l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭忀"),l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ忁")
	if l1l1ll_l1_ (u"ࠧๆสสุึ࠭忂") in duration: duration,l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠨࠩ心"),l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ忄")
	if l1l1ll_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ必") in list(render.keys()):
		l1l1111l1l1l_l1_ = str(render[l1l1ll_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ忆")])
		if l1l1ll_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ忇") in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"࠭ࠤ࠻ࠩ忈")
		if l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࠥࡔࡏࡘࠩ忉") in l1l1111l1l1l_l1_: l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ忊")
		if l1l1ll_l1_ (u"ࠩࡅࡹࡾ࠭忋") in l1l1111l1l1l_l1_ or l1l1ll_l1_ (u"ࠪࡖࡪࡴࡴࠨ忌") in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠫࠩࠪ࠺ࠨ忍")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡺ࠭ๅษษืีࠬ忎")) in l1l1111l1l1l_l1_: l11l1111l1l_l1_ = l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ忏")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡵࠨึิหฦ࠭忐")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠨࠦࠧ࠾ࠬ忑")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡷࠪหุะฦอษิࠫ忒")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠪࠨࠩࡀࠧ忓")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡹࠬหูๅษ้หฯ࠭忔")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠬࠪ࠺ࠨ忕")
	link = escapeUNICODE(link)
	if link and l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ忖") not in link: link = l1l1l1_l1_+link
	img = img.split(l1l1ll_l1_ (u"ࠧࡀࠩ志"))[0]
	if  img and l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭忘") not in img: img = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ忙")+img
	title = escapeUNICODE(title)
	if l1l11111111l_l1_: title = l1l11111111l_l1_+l1l1ll_l1_ (u"ࠪࠤࠥ࠭忚")+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l1ll_l1_ (u"ࠫ࠱࠭忛"),l1l1ll_l1_ (u"ࠬ࠭応"))
	count = count.replace(l1l1ll_l1_ (u"࠭ࠬࠨ忝"),l1l1ll_l1_ (u"ࠧࠨ忞"))
	count = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࡧ࠯ࠬ忟"),count)
	if count: count = count[0]
	else: count = l1l1ll_l1_ (u"ࠩࠪ忠")
	return True,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_
def l1l1111l1l11_l1_(item,url=l1l1ll_l1_ (u"ࠪࠫ忡"),index=l1l1ll_l1_ (u"ࠫࠬ忢")):
	succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_ = l1l1111lll1l_l1_(item)
	#if l1l1ll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ忣") in url and index==l1l1ll_l1_ (u"࠭࠰ࠨ忤"):
	#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ忥"),menu_name+title,url,144)
	#	return
	if not succeeded: return
	elif l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ忦") in str(item): return	# l1l11111l1l1_l1_ not items
	elif l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忧") in str(item): return			# l1l1111l11l1_l1_ not items
	elif not link and l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ忨") in url: return			# l1lllll11l_l1_ l11lll1l1111_l1_ list not items
	elif title and not link and (l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ忩") in url or l1l1ll_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ忪") in str(item) or url==l1l1l1_l1_):
		title = l1l1ll_l1_ (u"࠭࠽࠾࠿ࠣࠫ快")+title+l1l1ll_l1_ (u"ࠧࠡ࠿ࡀࡁࠬ忬")
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭忭"),menu_name+title,l1l1ll_l1_ (u"ࠩࠪ忮"),9999)
	elif title and l1l1ll_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ忯") in str(item):
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ忰"),menu_name+title,l1l1ll_l1_ (u"ࠬ࠭忱"),9999)
	elif l1l1ll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ忲") in link: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ忳"),menu_name+title,link,144,img,index)
	elif not title: return
	elif l11l1111l1l_l1_: addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭忴"),menu_name+l11l1111l1l_l1_+title,link,143,img)
	#elif l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ念") in link and l1l1ll_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ忶") not in link and l1l1ll_l1_ (u"ࠫࡹࡃ࠰ࠨ忷") not in link:
	#	l1l1111111l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࡀࠬ࠳࠰࠿ࠪࠦࠪ忸"),link,re.DOTALL)
	#	link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ忹")+l1l1111111l1_l1_[0]
	#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ忺"),menu_name+l1l1ll_l1_ (u"ࠨࡎࡌࡗ࡙࠭忻")+count+l1l1ll_l1_ (u"ࠩ࠽ࠤࠥ࠭忼")+title,link,144,img)
	elif l1l1ll_l1_ (u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬ忽") in link or l1l1ll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭忾") in link:
		if l1l1ll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ忿") in link and l1l1ll_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭怀") not in link:
			l1l1111111l1_l1_ = link.split(l1l1ll_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ态"),1)[1]
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ怂")+l1l1111111l1_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ怃"),menu_name+l1l1ll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ怄")+count+l1l1ll_l1_ (u"ࠫ࠿ࠦࠠࠨ怅")+title,link,144,img)
		else:
			link = link.split(l1l1ll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ怆"),1)[0]
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ怇"),menu_name+title,link,143,img,duration)
	else:
		type = l1l1ll_l1_ (u"ࠧࠨ怈")
		if not link: link = url
		#if l1l1ll_l1_ (u"ࠨࡵࡶࡁࠬ怉") in link: link = url
		#elif l1l1ll_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࡁࠬ怊") in link: link = url		# not needed it will stop l11lll1lllll_l1_ l1l11111l11_l1_ l11lllll1l11_l1_
		elif not any(value in link for value in [l1l1ll_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ怋"),l1l1ll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ怌"),l1l1ll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ怍"),l1l1ll_l1_ (u"࠭࠯ࡧࡧࡤࡸࡺࡸࡥࡥࠩ怎"),l1l1ll_l1_ (u"ࠧࡴࡵࡀࠫ怏"),l1l1ll_l1_ (u"ࠨࡤࡳࡁࠬ怐")]):
			if l1l1ll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ怑")	in link or l1l1ll_l1_ (u"ࠪ࠳ࡨ࠵ࠧ怒") in link: type = l1l1ll_l1_ (u"ࠫࡈࡎࡎࡍࠩ怓")+count+l1l1ll_l1_ (u"ࠬࡀࠠࠡࠩ怔")
			if l1l1ll_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭怕") in link: type = l1l1ll_l1_ (u"ࠧࡖࡕࡈࡖࠬ怖")+count+l1l1ll_l1_ (u"ࠨ࠼ࠣࠤࠬ怗")
			index,l1l1111lll11_l1_ = l1l1ll_l1_ (u"ࠩࠪ怘"),l1l1ll_l1_ (u"ࠪࠫ怙")
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ怚"),menu_name+type+title,link,144,img,index)
	return
def l1l111111111_l1_(url,data=l1l1ll_l1_ (u"ࠬ࠭怛"),request=l1l1ll_l1_ (u"࠭ࠧ怜")):
	global settings
	if not data: data = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ思"))
	#if l1l1ll_l1_ (u"ࠨࡡࡢࠫ怞") in l1l1111lll11_l1_: l1l1111lll11_l1_ = l1l1ll_l1_ (u"ࠩࠪ怟")
	#if l1l1ll_l1_ (u"ࠪࡷࡸࡃࠧ怠") in url: url = url.split(l1l1ll_l1_ (u"ࠫࡸࡹ࠽ࠨ怡"))[0]
	if request==l1l1ll_l1_ (u"ࠬ࠭怢"): request = l1l1ll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭怣")
	useragent = l1l11lll1_l1_()
	headers2 = {l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ怤"):useragent,l1l1ll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ急"):l1l1ll_l1_ (u"ࠩࡓࡖࡊࡌ࠽ࡩ࡮ࡀࡥࡷ࠭怦")}
	#headers2 = headers.copy()
	if l1l1ll_l1_ (u"ࠪ࠾࠿ࡀࠧ性") in data: l1l11111ll11_l1_,key,l1l11111l1l1_l1_,l1l111111ll1_l1_,token,l11llllll111_l1_ = data.split(l1l1ll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ怨"))
	else: l1l11111ll11_l1_,key,l1l11111l1l1_l1_,l1l111111ll1_l1_,token,l11llllll111_l1_ = l1l1ll_l1_ (u"ࠬ࠭怩"),l1l1ll_l1_ (u"࠭ࠧ怪"),l1l1ll_l1_ (u"ࠧࠨ怫"),l1l1ll_l1_ (u"ࠨࠩ怬"),l1l1ll_l1_ (u"ࠩࠪ怭"),l1l1ll_l1_ (u"ࠪࠫ怮")
	if l1l1ll_l1_ (u"ࠫ࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ怯") in url:
		data2 = {}
		data2[l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭怰")] = {l1l1ll_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ怱"):{l1l1ll_l1_ (u"ࠢࡩ࡮ࠥ怲"):l1l1ll_l1_ (u"ࠣࡣࡵࠦ怳"),l1l1ll_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ怴"):l1l1ll_l1_ (u"࡛ࠥࡊࡈࠢ怵"),l1l1ll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ怶"):l1l111111ll1_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ怷"),url,data2,headers2,True,True,l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠲ࡵࡷࠫ怸"))
	elif l1l1ll_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ怹") in url and l1l11111ll11_l1_:
		data2 = {l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ怺"):token}
		data2[l1l1ll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ总")] = {l1l1ll_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ怼"):{l1l1ll_l1_ (u"ࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ怽"):l1l11111ll11_l1_,l1l1ll_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ怾"):l1l1ll_l1_ (u"ࠨࡗࡆࡄࠥ怿"),l1l1ll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ恀"):l1l111111ll1_l1_}}
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭恁"),url,data2,headers2,True,True,l1l1ll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠶ࡳࡪࠧ恂"))
	elif l1l1ll_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ恃") in url and l11llllll111_l1_:
		headers2.update({l1l1ll_l1_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡏࡣࡰࡩࠬ恄"):l1l1ll_l1_ (u"ࠬ࠷ࠧ恅"),l1l1ll_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯࡙ࡩࡷࡹࡩࡰࡰࠪ恆"):l1l111111ll1_l1_})
		headers2.update({l1l1ll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ恇"):l1l1ll_l1_ (u"ࠨࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࡃࠧ恈")+l11llllll111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭恉"),url,l1l1ll_l1_ (u"ࠪࠫ恊"),headers2,l1l1ll_l1_ (u"ࠫࠬ恋"),l1l1ll_l1_ (u"ࠬ࠭恌"),l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ恍"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ恎"),url,l1l1ll_l1_ (u"ࠨࠩ恏"),headers2,l1l1ll_l1_ (u"ࠩࠪ恐"),l1l1ll_l1_ (u"ࠪࠫ恑"),l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ恒"))
	html = response.content
	tmp = re.findall(l1l1ll_l1_ (u"ࠬࠨࡩ࡯ࡰࡨࡶࡹࡻࡢࡦࡃࡳ࡭ࡐ࡫ࡹࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恓"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"࠭ࠢࡤࡸࡨࡶࠧ࠴ࠪࡀࠤࡹࡥࡱࡻࡥࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ恔"),html,re.DOTALL|re.I)
	if tmp: l1l111111ll1_l1_ = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ恕"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"ࠨࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ恖"),html,re.DOTALL|re.I)
	if tmp: l1l11111ll11_l1_ = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恗"),html,re.DOTALL|re.I)
	if tmp: l1l11111l1l1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l1ll_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ恘") in list(cookies.keys()): l11llllll111_l1_ = cookies[l1l1ll_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ恙")]
	data = l1l11111ll11_l1_+l1l1ll_l1_ (u"ࠬࡀ࠺࠻ࠩ恚")+key+l1l1ll_l1_ (u"࠭࠺࠻࠼ࠪ恛")+l1l11111l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠻࠼࠽ࠫ恜")+l1l111111ll1_l1_+l1l1ll_l1_ (u"ࠨ࠼࠽࠾ࠬ恝")+token+l1l1ll_l1_ (u"ࠩ࠽࠾࠿࠭恞")+l11llllll111_l1_
	if request==l1l1ll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ恟") and l1l1ll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ恠") in html:
		l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ恡"),html,re.DOTALL)
		if not l11l11lll1_l1_: l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ恢"),html,re.DOTALL)
		l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"ࠧࡴࡶࡵࠫ恣"),l11l11lll1_l1_[0])
	elif request==l1l1ll_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭恤") and l1l1ll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ恥") in html:
		l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ恦"),html,re.DOTALL)
		l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"ࠫࡸࡺࡲࠨ恧"),l11l11lll1_l1_[0])
	elif l1l1ll_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ恨") not in html: l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"࠭ࡳࡵࡴࠪ恩"),html)
	else: l11llll1ll11_l1_ = l1l1ll_l1_ (u"ࠧࠨ恪")
	#open(l1l1ll_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮࡫ࡵࡲࡲࠬ恫"),l1l1ll_l1_ (u"ࠩࡺࠫ恬")).write(str(l11llll1ll11_l1_))
	#open(l1l1ll_l1_ (u"ࠪࡗ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ恭"),l1l1ll_l1_ (u"ࠫࡼ࠭恮")).write(html)
	settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡥࡹࡧࠧ息"),data)
	return html,l11llll1ll11_l1_,data
def l1l1111ll11l_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ恰"),l1l1ll_l1_ (u"ࠧࠬࠩ恱"))
	url2 = url+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡹࡪࡸࡹ࠾ࠩ恲")+search
	ITEMS(url2)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1ll_l1_ (u"ࠩࠣࠫ恳"),l1l1ll_l1_ (u"ࠪ࠯ࠬ恴"))
	url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ࠭恵")+search
	if not showDialogs:
		if l1l1ll_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨ恶") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡓࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭恷")
		elif l1l1ll_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࡤ࠭恸") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ恹")
		elif l1l1ll_l1_ (u"ࠩࡢ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࠧ恺") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"ࠪࠪࡸࡶ࠽ࡆࡩࡌࡕࡆ࡭ࠥ࠳࠷࠶ࡈࠪ࠸࠵࠴ࡆࠪ恻")
		url3 = url2+l11llllll1l1_l1_
	else:
		l11llllll11l_l1_,l11llll1l111_l1_,title2 = [],[],l1l1ll_l1_ (u"ࠫࠬ恼")
		l11llll1l1l1_l1_ = [l1l1ll_l1_ (u"ࠬฮฯ้่ࠣฮึะ๊ษࠩ恽"),l1l1ll_l1_ (u"࠭สาฬํฬࠥำำษ่ࠢำ๎ࠦวๅื็อࠬ恾"),l1l1ll_l1_ (u"ࠧหำอ๎อࠦอิสࠣฮฬื๊ฯࠢส่ฯำๅ๋ๆࠪ恿"),l1l1ll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ฾ีฯࠡษ็ู้อ็ะษอࠫ悀"),l1l1ll_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥอไหไํ๎๊࠭悁")]
		l1l1111l111l_l1_ = [l1l1ll_l1_ (u"ࠪࠫ悂"),l1l1ll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡅࠪ࠸࠵࠴ࡆࠪ悃"),l1l1ll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡎࠫ࠲࠶࠵ࡇࠫ悄"),l1l1ll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡓࠥ࠳࠷࠶ࡈࠬ悅"),l1l1ll_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡅࠦ࠴࠸࠷ࡉ࠭悆")]
		l1l1111l1ll1_l1_ = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦ࠭ࠡษัฮึࠦวๅฬิฮ๏ฮࠧ悇"),l11llll1l1l1_l1_)
		if l1l1111l1ll1_l1_ == -1: return
		l11lllll1lll_l1_ = l1l1111l111l_l1_[l1l1111l1ll1_l1_]
		html,c,data = l1l111111111_l1_(url2+l11lllll1lll_l1_)
		if c:
			d = c[l1l1ll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ悈")][l1l1ll_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭悉")][l1l1ll_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭悊")][l1l1ll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ悋")][l1l1ll_l1_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ悌")][l1l1ll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悍")][l1l1ll_l1_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ悎")]
			for l11llll11lll_l1_ in range(len(d)):
				group = d[l11llll11lll_l1_][l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ悏")][l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ悐")]
				for l1l1111ll1l1_l1_ in range(len(group)):
					render = group[l1l1111ll1l1_l1_][l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ悑")]
					if l1l1ll_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ悒") in list(render.keys()):
						link = render[l1l1ll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ悓")][l1l1ll_l1_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ悔")][l1l1ll_l1_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭悕")][l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭悖")]
						link = link.replace(l1l1ll_l1_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ悗"),l1l1ll_l1_ (u"ࠫࠫ࠭悘"))
						title = render[l1l1ll_l1_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭悙")]
						title = title.replace(l1l1ll_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ悚"),l1l1ll_l1_ (u"ࠧࠨ悛"))
						if l1l1ll_l1_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ悜") in title: continue
						if l1l1ll_l1_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ悝") in title:
							title = l1l1ll_l1_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ悞")+title
							title2 = title
							l111111l1_l1_ = link
						if l1l1ll_l1_ (u"ࠫฯืส๋สࠣัุฮࠧ悟") in title: continue
						title = title.replace(l1l1ll_l1_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ悠"),l1l1ll_l1_ (u"࠭ࠧ悡"))
						if l1l1ll_l1_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ悢") in title: continue
						if l1l1ll_l1_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ患") in title:
							title = l1l1ll_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ悤")+title
							title2 = title
							l111111l1_l1_ = link
						if l1l1ll_l1_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ悥") in title: continue
						l11llllll11l_l1_.append(escapeUNICODE(title))
						l11llll1l111_l1_.append(link)
		if not title2: l1l11111lll1_l1_ = l1l1ll_l1_ (u"ࠫࠬ悦")
		else:
			l11llllll11l_l1_ = [l1l1ll_l1_ (u"ࠬฮฯ้่ࠣๅ้ะัࠨ悧"),title2]+l11llllll11l_l1_
			l11llll1l111_l1_ = [l1l1ll_l1_ (u"࠭ࠧ您"),l111111l1_l1_]+l11llll1l111_l1_
			l1l1111ll111_l1_ = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไโๆอีࠬ悩"),l11llllll11l_l1_)
			if l1l1111ll111_l1_ == -1: return
			l1l11111lll1_l1_ = l11llll1l111_l1_[l1l1111ll111_l1_]
		if l1l11111lll1_l1_: url3 = l1l1l1_l1_+l1l11111lll1_l1_
		elif l11lllll1lll_l1_: url3 = url2+l11lllll1lll_l1_
		else: url3 = url2
		l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦࡪ࡮ࡷࡩࡷ࠳ࡤࡳࡱࡳࡨࡴࡽ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯࠰ࡷࡪࡩࡴࡪࡱࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠨ࠮ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡘࡵࡲࡵࠢࡥࡽࠬ࠲ࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫ࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡴࡪࡶ࡯ࡩࠥࡃࠠࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡧࡤࡶࡨ࡮࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡔࡱࡵࡸࠥࡨࡹ࠻ࠢࠣࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠋࠋࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠋࠥࠦࠧ悪")
	ITEMS(url3)
	return
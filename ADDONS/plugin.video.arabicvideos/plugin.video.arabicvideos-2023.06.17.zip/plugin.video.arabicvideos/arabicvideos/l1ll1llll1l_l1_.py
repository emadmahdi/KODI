# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁࠨ❙")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡉࡆࡐࡥࠧ❚")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ❛"),l1l1ll_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫ❜")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l11l1l_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l11_l1_(url,text)
	elif mode==624: results = l1ll1l_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ❝"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭❞"),l1l1ll_l1_ (u"࠭ࠧ❟"),l1l1ll_l1_ (u"ࠧࠨ❠"),l1l1ll_l1_ (u"ࠨࠩ❡"),l1l1ll_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ❢"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❣"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ❤"),l1l1ll_l1_ (u"ࠬ࠭❥"),629,l1l1ll_l1_ (u"࠭ࠧ❦"),l1l1ll_l1_ (u"ࠧࠨ❧"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ❨"))
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ❩"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ❪"),l1l1ll_l1_ (u"ࠫࠬ❫"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❬"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ❭")+menu_name+l1l1ll_l1_ (u"ࠧศๆ่้๏ุษࠨ❮"),l1l1l1_l1_,621,l1l1ll_l1_ (u"ࠨࠩ❯"),l1l1ll_l1_ (u"ࠩࠪ❰"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ❱"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❲"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ❳")+menu_name+l1l1ll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬ❴"),l1l1l1_l1_,621,l1l1ll_l1_ (u"ࠧࠨ❵"),l1l1ll_l1_ (u"ࠨࠩ❶"),l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ❷"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❸"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭❹")+menu_name+l1l1ll_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ❺"),l1l1l1_l1_,621,l1l1ll_l1_ (u"࠭ࠧ❻"),l1l1ll_l1_ (u"ࠧࠨ❼"),l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ❽"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❾"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❿")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ➀"),l1l1l1_l1_,621,l1l1ll_l1_ (u"ࠬ࠭➁"),l1l1ll_l1_ (u"࠭ࠧ➂"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ➃"))
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭➄"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ➅"),l1l1ll_l1_ (u"ࠪࠫ➆"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ➇"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭➈"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➉"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ➊")+menu_name+title,link,624)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭➋"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ➌"),l1l1ll_l1_ (u"ࠪࠫ➍"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ➎"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ➏"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"࠭ࠧ➐"))
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ➑"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➒"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ➓")+menu_name+title,link,624)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ➔"),url,l1l1ll_l1_ (u"ࠫࠬ➕"),l1l1ll_l1_ (u"ࠬ࠭➖"),l1l1ll_l1_ (u"࠭ࠧ➗"),l1l1ll_l1_ (u"ࠧࠨ➘"),l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ➙"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭➚"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ➛"),l1l1ll_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ➜"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ➝"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"࠭ࠧ➞"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ➟"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭➠"),l1l1ll_l1_ (u"ࠩࠪ➡"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ➢"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠫ࠿ࠦࠧ➣")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➤"),menu_name+title,link,621)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ➥"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ➦"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭➧"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ➨"),l1l1ll_l1_ (u"ࠪࠫ➩"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➪"),menu_name+title,link,621)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠬ࠭➫")):
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ➬"),l1l1ll_l1_ (u"ࠧࠨ➭"),request,url)
	if request==l1l1ll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭➮"):
		url,search = url.split(l1l1ll_l1_ (u"ࠩࡂࠫ➯"),1)
		data = l1l1ll_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ➰")+search
		headers = {l1l1ll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ➱"):l1l1ll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ➲")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡐࡐࡕࡗࠫ➳"),url,data,headers,l1l1ll_l1_ (u"ࠧࠨ➴"),l1l1ll_l1_ (u"ࠨࠩ➵"),l1l1ll_l1_ (u"ࠩࡉࡅࡇࡘࡁࡌࡃ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ➶"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ➷"),url,l1l1ll_l1_ (u"ࠫࠬ➸"),l1l1ll_l1_ (u"ࠬ࠭➹"),l1l1ll_l1_ (u"࠭ࠧ➺"),l1l1ll_l1_ (u"ࠧࠨ➻"),l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭➼"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠩࠪ➽"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ➾"))
	if request==l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ➿"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⟀"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"࠭ࠧ⟁"),link,title))
	elif request==l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⟂"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⟃"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ⟄"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⟅"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ⟆"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⟇"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ⟈"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ⟉"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⟊"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠩࠪ⟋"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⟌"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⟍"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"๋ࠬิศ้าอࠬ⟎"),l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫ⟏"),l1l1ll_l1_ (u"ࠧศ฼้๎ฮ࠭⟐"),l1l1ll_l1_ (u"ࠨๅ็๎อ࠭⟑"),l1l1ll_l1_ (u"ࠩส฽้อๆࠨ⟒"),l1l1ll_l1_ (u"๋ࠪิอแࠨ⟓"),l1l1ll_l1_ (u"๊ࠫฮวาษฬࠫ⟔"),l1l1ll_l1_ (u"ࠬ฿ัืࠩ⟕"),l1l1ll_l1_ (u"࠭ๅ่ำฯห๋࠭⟖"),l1l1ll_l1_ (u"ࠧศๆห์๊࠭⟗"),l1l1ll_l1_ (u"ࠨ็ึีา๐ษࠨ⟘")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ⟙"))
		#if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⟚") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭⟛")+link.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ⟜"))
		#if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ⟝") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ⟞")+img.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ⟟"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ⟠"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭⟡"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⟢"),menu_name+title,link,622,img)
		elif request==l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⟣"):
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⟤"),menu_name+title,link,622,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⟥") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⟦"),menu_name+title,link,623,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ⟧") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⟨"),menu_name+title,link,621,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⟩"),menu_name+title,link,623,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⟪"),l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ⟫")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⟬"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⟭"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠩࠦࠫ⟮"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ⟯")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭⟰"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⟱"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ⟲")+title,link,621)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ⟳"),l1l1ll_l1_ (u"ࠨࠩ⟴"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭⟵"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ⟶"),url,l1l1ll_l1_ (u"ࠫࠬ⟷"),l1l1ll_l1_ (u"ࠬ࠭⟸"),l1l1ll_l1_ (u"࠭ࠧ⟹"),l1l1ll_l1_ (u"ࠧࠨ⟺"),l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ⟻"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ⟼"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⟽"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠫࠬ⟾")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࠭ࠧࡰࡰࡦࡰ࡮ࡩ࡫࠾ࠤࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬ⟿"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"࠭ࠣࠨ⠀"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⠁"),menu_name+title,url,623,img,l1l1ll_l1_ (u"ࠨࠩ⠂"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ⠃")+l1lll_l1_+l1l1ll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⠄"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠥ⠅"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⠆"),block,re.DOTALL)
		for link,title,img in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨ⠇")+link.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ⠈"))
			title = title.replace(l1l1ll_l1_ (u"ࠨ࠾࠲ࡩࡲࡄ࠼ࡴࡲࡤࡲࡃ࠭⠉"),l1l1ll_l1_ (u"ࠩࠣࠫ⠊"))
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⠋"),menu_name+title,link,622,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ⠌"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ⠍") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨ⠎")+link.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ⠏"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⠐"),menu_name+title,link,622,img)
	return
def PLAY(url):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭⠑"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ⠒"),url,l1l1ll_l1_ (u"ࠫࠬ⠓"),l1l1ll_l1_ (u"ࠬ࠭⠔"),l1l1ll_l1_ (u"࠭ࠧ⠕"),l1l1ll_l1_ (u"ࠧࠨ⠖"),l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⠗"))
	html = response.content
	# l111l1_l1_ page
	link = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⠘"),html,re.DOTALL)
	link = link[0]
	l111ll_l1_ = link.split(l1l1ll_l1_ (u"ࠪࡴࡴࡹࡴ࠾ࠩ⠙"))[1]
	l111ll_l1_ = base64.b64decode(l111ll_l1_)
	if kodi_version>18.99: l111ll_l1_ = l111ll_l1_.decode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⠚"))
	l111ll_l1_ = l111ll_l1_.replace(l1l1ll_l1_ (u"ࠬࡢ࠯ࠨ⠛"),l1l1ll_l1_ (u"࠭࠯ࠨ⠜"))
	l111ll_l1_ = EVAL(l1l1ll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ⠝"),l111ll_l1_)
	l1ll_l1_ = l111ll_l1_[l1l1ll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࡴࠩ⠞")]
	titles = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	zzz = zip(titles,l1ll_l1_)
	for title,link in zzz:
		link = link+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⠟")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⠠")
		l11l1_l1_.append(link)
	l1l1ll_l1_ (u"ࠦࠧࠨࠊࠊࠥ࡬ࡪࠥࡲࡩ࡯࡭ࠣࡥࡳࡪࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦ࡬ࡪࡰ࡮ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠭ࠫ࡭࡫ࡱ࡯ࠏࠏࡨࡢࡵ࡫ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡸࡶ࡬ࡪࡶࠫࠫ࡭ࡧࡳࡩ࠿ࠪ࠭ࡠ࠷࡝ࠋࠋࡳࡥࡷࡺࡳࠡ࠿ࠣ࡬ࡦࡹࡨ࠯ࡵࡳࡰ࡮ࡺࠨࠨࡡࡢࠫ࠮ࠐࠉ࡯ࡧࡺࡣࡵࡧࡲࡵࡵࠣࡁࠥࡡ࡝ࠋࠋࡩࡳࡷࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡱࡣࡵࡸࡸࡀࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌࡴࡦࡸࡴࠡ࠿ࠣࡦࡦࡹࡥ࠷࠶࠱ࡦ࠻࠺ࡤࡦࡥࡲࡨࡪ࠮ࡰࡢࡴࡷ࠯ࠬࡃࠧࠪࠌࠌࠍࠎ࡯ࡦࠡ࡭ࡲࡨ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴ࠾࠲࠺࠱࠽࠾ࡀࠠࡱࡣࡵࡸࠥࡃࠠࡱࡣࡵࡸ࠳ࡪࡥࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊࠋࡱࡩࡼࡥࡰࡢࡴࡷࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡶࡡࡳࡶࠬࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠠࡱࡣࡶࡷࠏࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠࠨࡀࠪ࠲࡯ࡵࡩ࡯ࠪࡱࡩࡼࡥࡰࡢࡴࡷࡷ࠮ࠐࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡ࡮࡬ࡲࡰࡹ࠮ࡴࡲ࡯࡭ࡹࡲࡩ࡯ࡧࡶࠬ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠴ࠣ࡭ࡳࠦࡺࡻࡼ࠽ࠎࠎࠏࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠵࠲ࡸࡶ࡬ࡪࡶࠫࠫࠥࡃ࠾ࠡࠩࠬࠎࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠯ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࠫࡵ࡫ࡷࡰࡪ࠱ࠧࡠࡡࡺࡥࡹࡩࡨࠨࠌࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠢࠣࠤ⠡")
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⠢"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⠣"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠧࠨ⠤"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠨࠩ⠥"): return
	search = search.replace(l1l1ll_l1_ (u"ࠩࠣࠫ⠦"),l1l1ll_l1_ (u"ࠪ࠯ࠬ⠧"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ⠨")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⠩"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ⠪")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ⠫"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧභ")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡋࡘࡖࡢࠫම")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==130: results = MENU()
	elif mode==131: results = l11l1l_l1_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l11ll1l_l1_(url,page)
	elif mode==134: results = PLAY(url)
	elif mode==135: results = l1ll1l11l_l1_()
	elif mode==139: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡸࡨࠫඹ"),menu_name+l1l1ll_l1_ (u"ࠧศๆหฯࠥอไฮ์่ࠣ็์วสࠢส่่๎หาࠩය"),l1l1ll_l1_ (u"ࠨࠩර"),135)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ඼"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪල"),l1l1ll_l1_ (u"ࠫࠬ඾"),139,l1l1ll_l1_ (u"ࠬ࠭඿"),l1l1ll_l1_ (u"࠭ࠧව"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫශ"))
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ෂ"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩස"),l1l1ll_l1_ (u"ࠪࠫහ"),9999)
	html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬළ"),l1l1ll_l1_ (u"ࠬ࠭ෆ"),True,l1l1ll_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ෇"))
	l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡴࡰࡩࡪࡰࡪ࠭෈"),html,re.DOTALL)
	block = l1lll11_l1_[1]
	items=re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ෉"),block,re.DOTALL)
	for link,title in items:
		if l1l1ll_l1_ (u"ࠩ࠲ࡧࡴࡴࡤࡶࡥࡷࡳࡷ්࠭") in link: continue
		title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬ෋"))
		#l1ll1ll11_l1_ = [l1l1ll_l1_ (u"ࠫ࠴ࡸࡥ࡭࡫ࡪ࡭ࡴࡻࡳࠨ෌"),l1l1ll_l1_ (u"ࠬ࠵ࡳࡰࡥ࡬ࡥࡱ࠭෍"),l1l1ll_l1_ (u"࠭࠯ࡱࡱ࡯࡭ࡹ࡯ࡣࡢ࡮ࠪ෎")]
		#if any(value in link for value in l1ll1ll11_l1_):
		#	title = l1l1ll_l1_ (u"ࠧศๆหีฬ๋ฬࠡࠩා")+title
		url = l1l1l1_l1_+link
		if l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬැ") in url: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩෑ"),menu_name+title,url,132)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪි"),menu_name+title,url,131)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩී"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬු"),l1l1ll_l1_ (u"࠭ࠧ෕"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧූ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ෗")+menu_name+l1l1ll_l1_ (u"ࠩสู่๊ไิๆสฮࠬෘ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠵࠵ࠪෙ"),132,l1l1ll_l1_ (u"ࠫࠬේ"),l1l1ll_l1_ (u"ࠬ࠷ࠧෛ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ො"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩෝ")+menu_name+l1l1ll_l1_ (u"ࠨษ็วๆ๊วๆࠩෞ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠼࠲࠹ࠩෟ"),132,l1l1ll_l1_ (u"ࠪࠫ෠"),l1l1ll_l1_ (u"ࠫ࠶࠭෡"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෢"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ෣")+menu_name+l1l1ll_l1_ (u"ࠧษำส้ัࠦวๅื฽หึ่ࠦศๆืฬฬฮࠧ෤"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠷࠷ࠨ෥"),132,l1l1ll_l1_ (u"ࠩࠪ෦"),l1l1ll_l1_ (u"ࠪ࠵ࠬ෧"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෨"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ෩")+menu_name+l1l1ll_l1_ (u"࠭วษำีࠤฬ๊ศาษ่ะࠬ෪"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠵࠼࠼࠳ࠨ෫"),132,l1l1ll_l1_ (u"ࠨࠩ෬"),l1l1ll_l1_ (u"ࠩ࠴ࠫ෭"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෮"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭෯")+menu_name+l1l1ll_l1_ (u"ࠬอไๆฯสฺึอสࠨ෰"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠼࠸࠸࠭෱"),132,l1l1ll_l1_ (u"ࠧࠨෲ"),l1l1ll_l1_ (u"ࠨ࠳ࠪෳ"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ෴"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ෵")+menu_name+l1l1ll_l1_ (u"ࠫ฾อิ้ำสลࠬ෶"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠳࠶࠹࠸࠭෷"),132,l1l1ll_l1_ (u"࠭ࠧ෸"),l1l1ll_l1_ (u"ࠧ࠲ࠩ෹"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ෺"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ෻")+menu_name+l1l1ll_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊วอฬ่ห฾๐ษࠨ෼"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠲࠴ࠫ෽"),132,l1l1ll_l1_ (u"ࠬ࠭෾"),l1l1ll_l1_ (u"࠭࠱ࠨ෿"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ฀"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪก")+menu_name+l1l1ll_l1_ (u"ࠩส่อืวๆฮࠣห้ี๊็์ฬࠫข"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠱࠻ࠪฃ"),132,l1l1ll_l1_ (u"ࠫࠬค"),l1l1ll_l1_ (u"ࠬ࠷ࠧฅ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ฆ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩง")+menu_name+l1l1ll_l1_ (u"ࠨษ็ฬึอๅอࠢส่ํัววไํอࠬจ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠵࠴ࠩฉ"),132,l1l1ll_l1_ (u"ࠪࠫช"),l1l1ll_l1_ (u"ࠫ࠶࠭ซ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฌ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨญ")+menu_name+l1l1ll_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็ื๏อำ๋หࠪฎ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠺࠵ࠨฏ"),132,l1l1ll_l1_ (u"ࠩࠪฐ"),l1l1ll_l1_ (u"ࠪ࠵ࠬฑ"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫฒ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧณ")+menu_name+l1l1ll_l1_ (u"࠭ใหสࠪด"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠶࠾࠷ࠧต"),132,l1l1ll_l1_ (u"ࠨࠩถ"),l1l1ll_l1_ (u"ࠩ࠴ࠫท"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪธ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭น")+menu_name+l1l1ll_l1_ (u"ࠬะูๅ็ࠣห้็วาีํอࠬบ"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠻࠼ࠬป"),132,l1l1ll_l1_ (u"ࠧࠨผ"),l1l1ll_l1_ (u"ࠨ࠳ࠪฝ"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩพ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬฟ")+menu_name+l1l1ll_l1_ (u"ࠫศืิ๋ใࠣห้ฮัศ็ฯࠫภ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠳࠵࠻࠾࠭ม"),132,l1l1ll_l1_ (u"࠭ࠧย"),l1l1ll_l1_ (u"ࠧ࠲ࠩร"))
	return
def l11l1l_l1_(url):
	l1ll1ll11_l1_ = [l1l1ll_l1_ (u"ࠨ࠱ࡵࡩࡱ࡯ࡧࡪࡱࡸࡷࠬฤ"),l1l1ll_l1_ (u"ࠩ࠲ࡷࡴࡩࡩࡢ࡮ࠪล"),l1l1ll_l1_ (u"ࠪ࠳ࡵࡵ࡬ࡪࡶ࡬ࡧࡦࡲࠧฦ"),l1l1ll_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫว"),l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠭ศ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"࠭ࠧษ"),l1l1ll_l1_ (u"ࠧࠨส"),True,l1l1ll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨห"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡶ࡬ࡸࡱ࡫ࡢࡢࡴࠪฬ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	if any(value in url for value in l1ll1ll11_l1_):
		items = re.findall(l1l1ll_l1_ (u"ࠥࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧอ"),block,re.DOTALL)
		for img,link,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭ฮ"))
			link = l1l1l1_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฯ"),menu_name+title,link,133,img,l1l1ll_l1_ (u"࠭࠱ࠨะ"))
	elif l1l1ll_l1_ (u"ࠧ࠰ࡦࡲࡧࡸ࠭ั") in url:
		items = re.findall(l1l1ll_l1_ (u"ࠣࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠥา"),block,re.DOTALL)
		for img,title,link in items:
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫำ"))
			link = l1l1l1_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪิ"),menu_name+title,link,133,img,l1l1ll_l1_ (u"ࠫ࠶࠭ี"))
	return
def CATEGORIES(url):
	category = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧึ"))[-1]
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"࠭ࠧื"),l1l1ll_l1_ (u"ࠧࠨุ"),True,l1l1ll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸูࠬ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡳࡥࡷ࡫࡮ࡵࡥࡤࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ฺࠩ"),html,re.DOTALL)
	if not l1lll11_l1_:
		l11ll1l_l1_(url,l1l1ll_l1_ (u"ࠪ࠵ࠬ฻"))
		return
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨ฼"),block,re.DOTALL)
	for link,title in items:
		#l1ll1l1ll_l1_ = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ฽"))[-1]
		#if category==l1ll1l1ll_l1_: continue
		title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ฾"))
		link = l1l1l1_l1_ + link
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ฿"),menu_name+title,link,132,l1l1ll_l1_ (u"ࠨࠩเ"),l1l1ll_l1_ (u"ࠩ࠴ࠫแ"))
	return
def l11ll1l_l1_(url,page):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠪࠫโ"),l1l1ll_l1_ (u"ࠫࠬใ"),True,l1l1ll_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧไ"))
	items = re.findall(l1l1ll_l1_ (u"࠭ࡴࡰࡶࡤࡰࡵࡧࡧࡦࡥࡲࡹࡳࡺ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩๅ"),html,re.DOTALL)
	if not items:
		url = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡺࡷ࠲ࡪࡥࡵࡣ࡬ࡰ࠲ࡨ࡯ࡥࡻࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬๆ"),html,re.DOTALL)
		url = url[0]
		title = l1l1ll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ็") + l1l1ll_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊่ࠧ")
		if url: addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ้ࠩ"),menu_name+title,url,134)
		else: DIALOG_OK(l1l1ll_l1_ (u"๊ࠫࠬ"),l1l1ll_l1_ (u"๋ࠬ࠭"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ์"),l1l1ll_l1_ (u"ࠧๅษࠣ๎ําฯࠡฯส่๏อࠠๆๆไหฯࠦแ๋ัํ์ࠥ็๊้ࠡำหࠥอไโำ฼ࠫํ"))
		return
	l1ll11lll_l1_ = int(items[0])
	name = re.findall(l1l1ll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠽࠱ࡤࡂࠥࡄࠨ࠯ࠬࡂ࠭ࡁ࠭๎"),html,re.DOTALL)
	if name: name = name[0].strip(l1l1ll_l1_ (u"ࠩࠣࠫ๏"))
	else: name = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ๐"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ๑"),l1l1ll_l1_ (u"ࠬ࠭๒"),name, str(l1l1ll_l1_ (u"࠭ࠧ๓")))
	if l1l1ll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫ๔") in url or l1l1ll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ๕") in url:
		category = url.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ๖"))[-1]
		if page==l1l1ll_l1_ (u"ࠪࠫ๗"): url2 = url
		else: url2 = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ๘") + category + l1l1ll_l1_ (u"ࠬ࠵ࠧ๙") + page
		l1l11ll1_l1_ = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"࠭ࠧ๚"),l1l1ll_l1_ (u"ࠧࠨ๛"),True,l1l1ll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ๜"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡳࡥ࡬࡫࡮ࡶ࡯ࡥࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ๝"),l1l11ll1_l1_,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡪࡺࡲ࡬ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ๞"),block,re.DOTALL)
		for img,type,link,title in items:
			if l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๟") not in type: continue
			if l1l1ll_l1_ (u"๋ࠬำๅี็ࠫ๠") in title and l1l1ll_l1_ (u"࠭อๅไฬࠫ๡") not in title: continue
			title = title.replace(l1l1ll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ๢"),l1l1ll_l1_ (u"ࠨࠩ๣"))
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ๤"))
			if l1l1ll_l1_ (u"ุ้๊ࠪำๅࠩ๥") in name and l1l1ll_l1_ (u"ࠫา๊โสࠩ๦") in title and l1l1ll_l1_ (u"๋ࠬำๅี็ࠫ๧") not in title:
				title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ๨") + name + l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫ๩") + title
			link = l1l1l1_l1_ + link
			if category==l1l1ll_l1_ (u"ࠨ࠸࠵࠼ࠬ๪"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๫"),menu_name+title,link,133,img,l1l1ll_l1_ (u"ࠪ࠵ࠬ๬"))
			else: addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๭"),menu_name+title,link,134,img)
	elif l1l1ll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ๮") in url:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡰࡨ࠲࠷࠲ࠨ๯"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠢࡷ࡫ࡧࡩࡴ࠳ࡴࡳࡣࡦ࡯࠲ࡺࡥࡹࡶ࠱࠮ࡄࡲ࡯ࡢࡦ࡙࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ๰"),block,re.DOTALL)
			for link,img,title in items:
				title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ๱"))
				addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๲"),menu_name+title,link,134,img)
		elif l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠶࠳࠺ࠪ๳") in html:
				title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ๴") + l1l1ll_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ๵")
				addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ๶"),menu_name+title,url,134)
		else:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ๷"),html,re.DOTALL)
			category = items[0].split(l1l1ll_l1_ (u"ࠨ࠱ࠪ๸"))[-1]
			url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭๹") + category
			CATEGORIES(url)
			return
		l1l1ll_l1_ (u"ࠥࠦࠧࠐࠉࠊࡶࡲࡸࡦࡲࡰࡢࡩࡨࡷࠥࡃࠠ࠱ࠌࠌࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࡏࡄࠡ࠿ࠣࡹࡷࡲ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢࡄࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪ࡝࠰࠵ࡢࠐࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡤ࡮ࡦࡾ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪࠤ࠰ࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠭ࠣࠫ࠴࠭ࠠࠬࠢࡳࡥ࡬࡫ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩࠬࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࠦ࠼ࡩ࠷ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩ࡮ࡩ࠯ࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠏࠉࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࡃ࠽ࡦࡲ࡬ࡷࡴࡪࡥࡊࡆ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠵࠸࠺ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠣࠤࠥ๺")
	l1l1ll_l1_ (u"ࠦࠧࠨࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࠴࠰࠶࠱ࡴࡰࡶࡤࡰࡵࡧࡧࡦࡵࠬ࠾ࠏࠏࠉࡪࡨࠣࡴࡦ࡭ࡥࠢ࠿ࡶࡸࡷ࠮ࡩࠪ࠼ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦู࠭ࠪๆำษࠡࠩ࠮ࡷࡹࡸࠨࡪࠫ࠯ࡹࡷࡲࠬ࠲࠵࠶࠰ࠬ࠭ࠬࡴࡶࡵࠬ࡮࠯ࠩࠋࠋࠥࠦࠧ๻")
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭๼"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		pages = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ๽"),block,re.DOTALL)
		for link,title in pages:
			link = l1l1l1_l1_+link
			link = link.replace(l1l1ll_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭๾"),l1l1ll_l1_ (u"ࠨࠨࠪ๿"))
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ຀"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩກ")+title,link,133)
	return
def PLAY(url):
	if l1l1ll_l1_ (u"ࠫ࠴ࡴࡥࡸࡵ࠲ࠫຂ") in url or l1l1ll_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ຃") in url:
		html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"࠭ࠧຄ"),l1l1ll_l1_ (u"ࠧࠨ຅"),True,l1l1ll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ຆ"))
		items = re.findall(l1l1ll_l1_ (u"ࠤࡰࡳࡧ࡯࡬ࡦࡸ࡬ࡨࡪࡵࡰࡢࡶ࡫࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨງ"),html,re.DOTALL)
		if items: url = items[0]
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩຈ"))
	return
def l1ll1l11l_l1_():
	#l1ll1ll1l_l1_(l1l1ll_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪຉ"))
	#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠬาวา์ࠣฮูเ๊ๅࠢส่็์วสࠩຊ"),l1l1ll_l1_ (u"࠭ࠧ຋"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰࡮࡬ࡺࡪ࠭ຌ")
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩຍ"),l1l1ll_l1_ (u"ࠩࠪຎ"),True,l1l1ll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨຏ"))
	url2 = re.findall(l1l1ll_l1_ (u"ࠫࡱ࡯ࡶࡦ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬຐ"),html,re.DOTALL)
	url2 = url2[0]
	headers2 = {l1l1ll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ຑ"):l1l1l1_l1_}
	response2 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪຒ"),url2,l1l1ll_l1_ (u"ࠧࠨຓ"),headers2,l1l1ll_l1_ (u"ࠨࠩດ"),True,l1l1ll_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡒࡉࡗࡇ࠰࠶ࡳࡪࠧຕ"))
	l1l11ll1_l1_ = response2.content
	token = re.findall(l1l1ll_l1_ (u"ࠪࡧࡸࡸࡦ࠮ࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪຖ"),l1l11ll1_l1_,re.DOTALL)
	token = token[0]
	l1ll1l1l1_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨທ"))
	url3 = re.findall(l1l1ll_l1_ (u"ࠧࡶ࡬ࡢࡻࡘࡶࡱࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤຘ"),l1l11ll1_l1_,re.DOTALL)
	url3 = l1ll1l1l1_l1_+url3[0]
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧນ"),url3)
	l1ll11ll1_l1_ = {l1l1ll_l1_ (u"࡙ࠧ࠯ࡆࡗࡗࡌ࠭ࡕࡑࡎࡉࡓ࠭ບ"):token}
	response3 = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭ປ"),url3,l1l1ll_l1_ (u"ࠩࠪຜ"),l1ll11ll1_l1_,False,True,l1l1ll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠸ࡸࡤࠨຝ"))
	l1ll1l111_l1_ = response3.content
	l111l11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬພ"),l1ll1l111_l1_,re.DOTALL)
	l111l11l_l1_ = l111l11l_l1_[0].replace(l1l1ll_l1_ (u"ࠬࡢ࠯ࠨຟ"),l1l1ll_l1_ (u"࠭࠯ࠨຠ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨມ"),l1l1ll_l1_ (u"ࠨࠩຢ"),url,html)
	#l1ll1ll1l_l1_(l1l1ll_l1_ (u"ࠩࡶࡸࡴࡶࠧຣ"))
	PLAY_VIDEO(l111l11l_l1_,script_name,l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ຤"))
	return
def SEARCH(search,url=l1l1ll_l1_ (u"ࠫࠬລ")):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if url==l1l1ll_l1_ (u"ࠬ࠭຦"):
		if search==l1l1ll_l1_ (u"࠭ࠧວ"): search = OPEN_KEYBOARD()
		if search==l1l1ll_l1_ (u"ࠧࠨຨ"): return
		#search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪຩ"),l1l1ll_l1_ (u"ࠩ࠮ࠫສ"))
		#search = l1l1ll_l1_ (u"ࠪ࠱ࡹࡧࡧࠡࡦࡲࡧࡸࠦࡏࡓࠢࡩ࡭ࡱࡳࡳࠡࡑࡕࠤࡸ࡫ࡲࡪࡧࡶࠤࡔࡘࠠࡦࡲ࡬ࡷࡴࡪࡥࠡࡑࡕࠤࡪࡶࡩࡴࡱࡧࡩࡸࠦࡏࡓࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡔࡘࠠ࡯ࡧࡺࡷࠥࡳࡰ࠵ࠢࠪຫ")+search
		#search = l1l1ll_l1_ (u"ࠫࠧࡳࡰ࠵ࠤࠣࠫຬ")+search
		search = QUOTE(search)
		url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩອ")+search
		l11ll1l_l1_(url,l1l1ll_l1_ (u"࠭ࠧຮ"))
		return
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࡕࡴࡸࡩ࠱࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ࠩࠋࠋࠌࡧࡽࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭ࠨࡶࡢࡴࠣࡧࡽࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࡠ࠶࡝ࠋࠋࠌࡹࡷࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡨࡥࡶࡩ࠳ࡹࡲࡤࠢࡀࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠࠎࠎࠏࡵࡳ࡮ࠣࡁࠥࡻࡲ࡭࠭ࡦࡼࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨࠫࠍࠍࠎࡩࡳࡦࡡࡷࡳࡰ࡫࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡶࡩࡤࡺ࡯࡬ࡧࡱࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࡞࠴ࡢࠐࠉࠊࡥࡶࡩࡱ࡯ࡢࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡶࡩࡱ࡯ࡢࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯࡛࠱࡟ࠍࠍࠎࡸࡡ࡯ࡦࡲࡱࡆࡖࡉࠡ࠿ࠣࡷࡹࡸࠨࡳࡣࡱࡨࡴࡳ࠮ࡳࡣࡱࡨ࡮ࡴࡴࠩ࠳࠴࠵࠶࠲࠹࠺࠻࠼࠭࠮ࠐࠉࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡷࡪ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡧࡸ࡫࠯ࡦ࡮ࡨࡱࡪࡴࡴ࠰ࡸ࠴ࡃࡷࡹࡺ࠾ࡨ࡬ࡰࡹ࡫ࡲࡦࡦࡢࡧࡸ࡫ࠦ࡯ࡷࡰࡁ࠶࠶ࠦࡩ࡮ࡀࡥࡷࠬࡳࡰࡷࡵࡧࡪࡃࡧࡤࡵࡦࠪ࡬ࡹࡳ࠾࠰ࡦࡳࡲࠬࡣࡴࡧ࡯࡭ࡧࡼ࠽ࠨ࠭ࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯࠭ࠪࠪࡨࡾ࠽ࠨ࠭ࡦࡼ࠰࠭ࠦࡲ࠿ࠪ࠯ࡸ࡫ࡡࡳࡥ࡫࠯ࠬࠬࡳࡢࡨࡨࡁࡴ࡬ࡦࠧࡥࡶࡩࡤࡺ࡯࡬࠿ࠪ࠯ࡨࡹࡥࡠࡶࡲ࡯ࡪࡴࠫࠨࠨࡶࡳࡷࡺ࠽ࠧࡧࡻࡴࡂࡩࡳࡲࡴ࠯ࡧࡨࠬࡣࡢ࡮࡯ࡦࡦࡩ࡫࠾ࡩࡲࡳ࡬ࡲࡥ࠯ࡵࡨࡥࡷࡩࡨ࠯ࡥࡶࡩ࠳ࡧࡰࡪࠩ࠮ࡶࡦࡴࡤࡰ࡯ࡄࡔࡎ࠱ࠧࠧࡵࡷࡥࡷࡺ࠽࠱ࠩࠍࠍࡺࡹࡥࡳࡣࡪࡩࡳࡺࠠ࠾ࠢࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠭࠯ࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࡺࡹࡥࡳࡣࡪࡩࡳࡺࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡘࡋࡁࡓࡅࡋ࠱࠸ࡸࡤࠨࠫࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡦࡩࡨࡦࡗࡵࡰࠧࡀ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡲ࡫ࡴࡢࡶࡤ࡫ࡸࠨ࠺ࠡࡽࠫ࠲࠯ࡅࠩࡾࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬࡵࡣࡪࡷࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌ࡭࡫ࠦࠧࡷ࡫ࡧࡩࡴ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡵࡣࡪࡷ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡺࡴࡥࡴࡥࡤࡴࡪࡎࡔࡎࡎࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠸ࡩࠧ࠭ࠩ࠿ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠹ࡥࠨ࠮ࠪࡂࠬ࠯ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁࡨ࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠩ࠯ࠫࠥ࠭ࠩࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠉࠤࠢࡲࡶࠥ࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠊࡸࡤࡶࡸࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣࡺࡦࡸࡳ࡜࠶ࡠࠎࠎࠏࠉࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩࠣ࠯ࠥࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡺࡦࡸࡳࠪࡀ࠸࠾ࠏࠏࠉࠊࠋࡳࡥ࡬࡫࠱ࠡ࠿ࠣࡺࡦࡸࡳ࡜࠷ࡠࠎࠎࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠲࠵࠶࠰ࠬ࠭ࠬࡱࡣࡪࡩ࠶࠯ࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠳࠶࠶࠮ࠐࠉࠊࡧ࡯࡭࡫ࠦࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠱࠴࠵࠯ࠫࠬ࠲ࠧ࠲ࠩࠬࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠴ࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠤ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡴࡶࡤࡶࡹࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧࡺࡸࡲࡦࡰࡷࡔࡦ࡭ࡥࡊࡰࡧࡩࡽࠨ࠺ࠡࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡶࡴࡵࡩࡳࡺࡐࡢࡩࡨࠤࡂࠦࡳࡵࡴࠫ࡭ࡳࡺࠨࡤࡷࡵࡶࡪࡴࡴࡑࡣࡪࡩࡠ࠶࡝ࠪ࠭࠴࠭ࠏࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡷࡹࡧࡲࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡀࡁࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡷࡵࡰࠥࡃࠠࡶࡴ࡯࠲ࡸࡶ࡬ࡪࡶࠫࠫࡸࡺࡡࡳࡶࡀࠫ࠮ࡡ࠰࡞࠭ࠪࡷࡹࡧࡲࡵ࠿ࠪ࠯ࡸࡺࡡࡳࡶࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦู࠭ࠪๆำษࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠮ࡸࡶࡱ࠲࠱࠴࠻ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤຯ")
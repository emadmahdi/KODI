# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ⌐")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡊࡍࡄࡠࠩ⌑")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"๊ࠫ฻วา฻ฬࠫ⌒"),l1l1ll_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫ⌓"),l1l1ll_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬ⌔"),l1l1ll_l1_ (u"ࠧศๆิส๏ู๊สࠩ⌕"),l1l1ll_l1_ (u"ࠨษะำะࠦวๅษ฽ห๋๏ࠧ⌖")]
def MAIN(mode,url,text):
	if   mode==440: results = MENU()
	elif mode==441: results = l11l1l_l1_(url,text)
	elif mode==442: results = PLAY(url)
	elif mode==443: results = l11ll1l_l1_(url)
	elif mode==449: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭⌗"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ⌘"),l1l1ll_l1_ (u"ࠫࠬ⌙"),l1l1ll_l1_ (u"ࠬ࠭⌚"),l1l1ll_l1_ (u"࠭ࠧ⌛"),l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⌜"))
	html = response.content
	l11ll1_l1_ = SERVER(l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ⌝"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌞"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ⌟"),l1l1ll_l1_ (u"ࠫࠬ⌠"),449,l1l1ll_l1_ (u"ࠬ࠭⌡"),l1l1ll_l1_ (u"࠭ࠧ⌢"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⌣"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⌤"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⌥")+menu_name+l1l1ll_l1_ (u"ࠪห้ืฦ๋ีํอࠬ⌦"),l1l1l1_l1_,441)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⌧"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⌨"),l1l1ll_l1_ (u"࠭ࠧ〈"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪࡥ࡭ࡦࡰࡸࡣࡷ࡯ࡧࡩࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ〉"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⌫"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		if link==l1l1ll_l1_ (u"ࠩࠦࠫ⌬"): continue
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌭"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⌮")+menu_name+title,link,441)
	return
def l11l1l_l1_(url,l11l1ll1_l1_=l1l1ll_l1_ (u"ࠬ࠭⌯")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ⌰"),url,l1l1ll_l1_ (u"ࠧࠨ⌱"),l1l1ll_l1_ (u"ࠨࠩ⌲"),l1l1ll_l1_ (u"ࠩࠪ⌳"),l1l1ll_l1_ (u"ࠪࠫ⌴"),l1l1ll_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⌵"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰ࡶࡪࡲࡡࡵࡧࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧ⌶"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"࠭࠼࡭࡫ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⌷"),block,re.DOTALL)
	for link,title,img in items:
		if l1l1ll_l1_ (u"ࠧ࠰ࡷࡵࡰ࠴࠭⌸") in link: continue
		elif l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ⌹") in link: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⌺"),menu_name+title,link,443,img)
		elif l1l1ll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭⌻") in link: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌼"),menu_name+title,link,443,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⌽"),menu_name+title,link,442,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ⌾"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⌿"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⍀"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ⍁")+title,link,441)
	return
l1l1ll_l1_ (u"ࠥࠦࠧࠐࠉࡢ࡮࡯ࡘ࡮ࡺ࡬ࡦࡵࠣࡁࠥࡡ࡝ࠋࠋࡹ࡭ࡩ࡫࡯ࡍࡋࡖࡘࠥࡃࠠ࡜ุ่ࠩฬํฯสࠩ࠯ࠫๆ๐ไๆࠩ࠯ࠫฬเๆ๋หࠪ࠰้ࠬไ๋สࠪ࠰ࠬอูๅษ้ࠫ࠱࠭็ะษไࠫ࠱࠭ๅษษิหฮ࠭ࠬࠨ฻ิฺࠬ࠲ࠧๆ้ิะฬ์ࠧ࠭ࠩส่อ๎ๅࠨ࡟ࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩ࠱࡯࡭ࡨࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡷࡱࡩࡸࡩࡡࡱࡧࡋࡘࡒࡒࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡰ࡮ࡴ࡫ࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩ࠲ࠫ࠮ࠐࠉࠊࡧࡳ࡭ࡸࡵࡤࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ࠲ࡴࡪࡶ࡯ࡩ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡢࡰࡼࠬࡻࡧ࡬ࡶࡧࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩࠥ࡬࡯ࡳࠢࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡻ࡯ࡤࡦࡱࡏࡍࡘ࡚ࠩ࠻ࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠹࠺࠲࠭࡫ࡰ࡫࠮ࠐࠉࠊࡧ࡯࡭࡫ࠦࡥࡱ࡫ࡶࡳࡩ࡫ࠠࡢࡰࡧࠤࠬอไฮๆๅอࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧࡠࡏࡒࡈࡤ࠭ࠠࠬࠢࡨࡴ࡮ࡹ࡯ࡥࡧ࡞࠴ࡢࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤࡳࡵࡴࠡ࡫ࡱࠤࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹ࠺ࠋࠋࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠺࠴࠴࠮࡬ࡱ࡬࠯ࠊࠊࠋࠌࠍࡦࡲ࡬ࡕ࡫ࡷࡰࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࠨ࠱ࡤࡷࡸ࡫࡭ࡣ࡮ࡼ࠳ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡶ࡬ࡸࡱ࡫ࠬ࡭࡫ࡱ࡯࠱࠺࠴࠲࠮࡬ࡱ࡬࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠸࠹࠹ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠴࠵࠵࠯࡭ࡲ࡭ࠩࠋࠋ࡬ࡪࠥࡹࡥࡲࡷࡨࡲࡨ࡫࠽࠾ࠩࠪ࠾ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠢࠣࠤ⍂")
def l11ll1l_l1_(url):
	data = {l1l1ll_l1_ (u"࡛ࠫ࡯ࡥࡸࠩ⍃"):1}
	headers = {l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⍄"):l1l1ll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ⍅")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ⍆"),url,data,headers,l1l1ll_l1_ (u"ࠨࠩ⍇"),l1l1ll_l1_ (u"ࠩࠪ⍈"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⍉"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡹࡥࡢࡵࡲࡲࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ⍊"),html,re.DOTALL)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ⍋"),html,re.DOTALL)
	# l11l11_l1_
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⍌"),block,re.DOTALL)
		for link,title,img in items:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⍍"),menu_name+title,link,443,img)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		img = re.findall(l1l1ll_l1_ (u"ࠨࠤࡲ࡫࠿࡯࡭ࡢࡩࡨࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⍎"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⍏"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠪࡠࡳ࠭⍐"),l1l1ll_l1_ (u"ࠫࠬ⍑")).strip(l1l1ll_l1_ (u"ࠬࠦࠧ⍒"))
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⍓"),menu_name+title,link,442,img)
	return
def PLAY(url):
	data = {l1l1ll_l1_ (u"ࠧࡗ࡫ࡨࡻࠬ⍔"):1}
	headers = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⍕"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ⍖")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⍗"),url,data,headers,l1l1ll_l1_ (u"ࠫࠬ⍘"),l1l1ll_l1_ (u"ࠬ࠭⍙"),l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡇࡉࡆࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⍚"))
	html = response.content
	l11l1_l1_ = []
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡹࡤࡸࡨ࡮ࡁࡳࡧࡤࡑࡦࡹࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⍛"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭⍜"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ⍝"),l1l1ll_l1_ (u"ࠪࠫ⍞")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭⍟"))
			link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⍠")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⍡")
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡦࡲࡲࡼࡲ࡯ࡢࡦ࠰ࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⍢"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷ࠳࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⍣"),block,re.DOTALL)
		for title,l11ll1l1_l1_,link in items:
			link = link.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ⍤"),l1l1ll_l1_ (u"ࠪࠫ⍥"))
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⍦")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ⍧")+l1l1ll_l1_ (u"࠭࡟ࡠࡡࡢࠫ⍨")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⍩"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⍪"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠩࠪ⍫"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠪࠫ⍬"): return
	search = search.replace(l1l1ll_l1_ (u"ࠫࠥ࠭⍭"),l1l1ll_l1_ (u"ࠬ࠱ࠧ⍮"))
	#search = unescapeHTML(search)
	url = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡀࡵࡀࠫ⍯")+search
	l11l1l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜ࠫ揑")
contentsDICT = {}
menuItemsLIST = []
l1l1l1lll111_l1_ = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠦࡘࡿࡳࡵࡧࡰ࠲ࡇࡻࡩ࡭ࡦ࡙ࡩࡷࡹࡩࡰࡰࠥ插"))
kodi_version = re.findall(l1l1ll_l1_ (u"ࠬ࠮࡜ࡥ࡞ࡧࡠ࠳ࡢࡤࠪࠩ揓"),l1l1l1lll111_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
if kodi_version>18.99:
	l11l11l1llll_l1_ = xbmcvfs.translatePath(l1l1ll_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ揔"))
	l1l1ll11l1_l1_ = xbmcvfs.translatePath(l1l1ll_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ揕"))
	l11ll1lll111_l1_ = xbmcvfs.translatePath(l1l1ll_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬ揖"))
	l111ll1l1lll_l1_ = xbmcvfs.translatePath(l1l1ll_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪ揗"))
	loglevel = xbmc.LOGINFO
	l1l1lll111l1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ揘"),l1l1ll_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭揙"),l1l1ll_l1_ (u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪ揚"))
	ltr,rtl = l1l1ll_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ換"),l1l1ll_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ揜")
	half_triangular_colon = l1l1ll_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ揝")
else:
	l11l11l1llll_l1_ = xbmc.translatePath(l1l1ll_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ揞"))
	l1l1ll11l1_l1_ = xbmc.translatePath(l1l1ll_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ揟"))
	l11ll1lll111_l1_ = xbmc.translatePath(l1l1ll_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ揠"))
	l111ll1l1lll_l1_ = xbmc.translatePath(l1l1ll_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭握"))
	loglevel = xbmc.LOGNOTICE
	l1l1lll111l1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ揢"),l1l1ll_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ揣"),l1l1ll_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭揤"))
	ltr,rtl = l1l1ll_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪ揥").encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ揦")),l1l1ll_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬ揧").encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ揨"))
	half_triangular_colon = l1l1ll_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ揩").encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ揪"))
addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split(l1l1ll_l1_ (u"ࠨ࠱ࠪ揫"))[2]	# l1111l1111_l1_.l11lll11l1_l1_.l11l11l11111_l1_
addon_name = addon_id.split(l1l1ll_l1_ (u"ࠩ࠱ࠫ揬"))[2]		# l11l11l11111_l1_
addon_path = sys.argv[2]				# ?mode=12&url=http://test.l1lll1ll1_l1_
#l11ll1ll11l1_l1_ = sys.argv[0]+addon_path		# l1111l1111_l1_://l1111l1111_l1_.l11lll11l1_l1_.l11l11l11111_l1_/?mode=12&url=http://test.l1lll1ll1_l1_
#addon_path = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡌ࡯࡭ࡦࡨࡶࡕࡧࡴࡩࠩ揭"))
addon_version = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫ揮")+addon_id+l1l1ll_l1_ (u"ࠬ࠯ࠧ揯"))
l1l1lllll111_l1_ = os.path.join(l11ll1lll111_l1_,l1l1ll_l1_ (u"࠭࡫ࡰࡦ࡬࠲ࡱࡵࡧࠨ揰"))
l1l11l1ll11l_l1_ = os.path.join(l11ll1lll111_l1_,l1l1ll_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡵ࡬ࡥ࠰࡯ࡳ࡬࠭揱"))
l1ll11l1111l_l1_ = [l1l1ll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ揲"),l1l1ll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪ揳"),l1l1ll_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭援"),l1l1ll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶ࡫ࡹࡧ࠭揵"),l1l1ll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷࡩࡦ࠭揶"),l1l1ll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡥࡲࡨࡪࡨࡥࡳࡩࠪ揷")]
l1l1lll1111l_l1_ = l1ll11l1111l_l1_+[l1l1ll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ揸"),l1l1ll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭揹"),l1l1ll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ揺"),l1l1ll_l1_ (u"ࠪࡷࡰ࡯࡮࠯ࡲ࡫ࡩࡳࡵ࡭ࡦࡰࡤࡰࡊࡓࡁࡅࠩ揻")]		# ,l1l1ll_l1_ (u"ࠫࡸࡱࡩ࡯࠰࡬ࡲࡸࡺࡡ࡭࡮ࡈࡑࡆࡊࠧ揼")
addoncachefolder = os.path.join(l111ll1l1lll_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠬࡳࡡࡪࡰࡧࡥࡹࡧ࠮ࡥࡤࠪ揽"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ揾"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ揿"))
l1l1l111ll1_l1_ = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨ搀"))
l1l11l11ll1_l1_ = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪ搁"))
#l11l111l1lll_l1_ = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠪࡰࡦࡹࡴ࡮ࡧࡱࡹ࠳ࡪࡡࡵࠩ搂"))
favoritesfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠫ࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳ࠯ࡦࡤࡸࠬ搃"))
#dummyiptvfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠬࡪࡵ࡮࡯ࡼ࡭ࡵࡺࡶ࠯ࡦࡤࡸࠬ搄"))
fulliptvfile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"࠭ࡩࡱࡶࡹࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ搅"))
l1l1l11l111_l1_ = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠧ࡮࠵ࡸࡪ࡮ࡲࡥࡠࡡࡢ࠲ࡩࡧࡴࠨ搆"))
l1ll1111lll1_l1_ = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡨࡦࡺࠧ搇"))
dialogimagefile = os.path.join(addoncachefolder,l1l1ll_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬ搈"))
addonfolder = xbmcaddon.Addon().getAddonInfo(l1l1ll_l1_ (u"ࠪࡴࡦࡺࡨࠨ搉"))
defaulticon = os.path.join(addonfolder,l1l1ll_l1_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭搊"))
defaultthumb = os.path.join(addonfolder,l1l1ll_l1_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ搋"))
defaultfanart = os.path.join(addonfolder,l1l1ll_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡪࡱࡩࠪ搌"))
l1l1l1lll1ll_l1_ = os.path.join(addonfolder,l1l1ll_l1_ (u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺࠧ損"))
l11l1111l11l_l1_ = os.path.join(addonfolder,l1l1ll_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ搎"),l1l1ll_l1_ (u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶࠪ搏"))
l1ll1llll1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ搐"))
l1l11ll1lll1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭搑"),l1l1ll_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ搒"),addon_id,l1l1ll_l1_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ搓"))
l11ll1l111l1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ搔"),l1l1ll_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ搕"),l1l1ll_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ搖"))
fontfile = os.path.join(l11l11l1llll_l1_,l1l1ll_l1_ (u"ࠪࡱࡪࡪࡩࡢࠩ搗"),l1l1ll_l1_ (u"ࠫࡋࡵ࡮ࡵࡵࠪ搘"),l1l1ll_l1_ (u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨ搙"))
FOLDERS_COUNT = 5
text_numbers = [l1l1ll_l1_ (u"࠭ร้ๆࠪ搚"),l1l1ll_l1_ (u"ࠧฬษ้๎ࠬ搛"),l1l1ll_l1_ (u"ࠨอส่ะ࠭搜"),l1l1ll_l1_ (u"ࠩิหอ฿ࠧ搝"),l1l1ll_l1_ (u"ࠪาฬ๋ำࠨ搞"),l1l1ll_l1_ (u"ุࠫอฯิࠩ搟"),l1l1ll_l1_ (u"ูࠬวษ฻ࠪ搠"),l1l1ll_l1_ (u"࠭หศ็้ࠫ搡"),l1l1ll_l1_ (u"ࠧหษึ฽ࠬ搢"),l1l1ll_l1_ (u"ࠨ฻สุึ࠭搣")]
l1l11l1l1l11_l1_ = l1l1ll_l1_ (u"ࠩ⸾ࠤ⼢ࠦ⸪ࠡ⸽ࠪ搤")
settings = xbmcaddon.Addon(id=addon_id)
now = int(time.time())
l11ll1lll1l1_l1_ = 60
HOUR = 60*l11ll1lll1l1_l1_
l1111ll111l1_l1_ = 24*HOUR
l11l1ll11111_l1_ = 30*l1111ll111l1_l1_
NO_CACHE = 0
l11ll1l1l1l_l1_ = 30*l11ll1lll1l1_l1_
l1llll1l1_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l11l1ll_l1_ = 3*l1111ll111l1_l1_
l1ll11ll11l_l1_ = 30*l1111ll111l1_l1_
PERMANENT_CACHE = 12*l11l1ll11111_l1_
LIMITED_CACHE = 1*HOUR
l111l11ll111_l1_ = [l1l1ll_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ搥"),l1l1ll_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ搦")]
l11l111ll1l1_l1_ = [l1l1ll_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ搧")]
l111lll1llll_l1_ = [l1l1ll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ搨"),l1l1ll_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ搩"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ搪"),l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ搫"),l1l1ll_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭搬"),l1l1ll_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ搭"),l1l1ll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ搮")]
l111lll1llll_l1_ += [l1l1ll_l1_ (u"࠭ࡈࡆࡎࡄࡐࠬ搯"),l1l1ll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭搰"),l1l1ll_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ搱"),l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ搲"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ搳"),l1l1ll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ搴"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ搵")]
l1111ll1l111_l1_ = [l1l1ll_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ搶"),l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ搷"),l1l1ll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭搸"),l1l1ll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ搹")]
l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠪࡑ࠸࡛ࠧ携"),l1l1ll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭搻"),l1l1ll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ搼"),l1l1ll_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ搽")]
l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭搾"),l1l1ll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ搿"),l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ摀")]
l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ摁"),l1l1ll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ摂"),l1l1ll_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ摃"),l1l1ll_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ摄")]		# l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ摅")
l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ摆"),l1l1ll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ摇"),l1l1ll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ摈"),l1l1ll_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ摉"),l1l1ll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ摊"),l1l1ll_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ摋")]
#l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭摌"),l1l1ll_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ摍"),l1l1ll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ摎"),l1l1ll_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭摏")]
#l1111ll1l111_l1_ += [l1l1ll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ摐"),l1l1ll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࠨ摑"),l1l1ll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࠪ摒"),l1l1ll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࠪ摓")]
l1ll111l1ll_l1_ = [l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ摔"),l1l1ll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ摕"),l1l1ll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ摖"),l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ摗")]
l1ll111l1ll_l1_ += [l1l1ll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ摘"),l1l1ll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ摙"),l1l1ll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ摚"),l1l1ll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ摛"),l1l1ll_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ摜")]
l1ll11l1l11_l1_ = [l1l1ll_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭摝"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ摞"),l1l1ll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭摟"),l1l1ll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ摠"),l1l1ll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ摡"),l1l1ll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ摢")]
l1ll11l1l11_l1_ += [l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ摣"),l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ摤"),l1l1ll_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ摥"),l1l1ll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ摦")]
#l1ll11l1l11_l1_ += [l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ摧"),l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ摨")]
l1ll1l1l1ll_l1_ = [l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ摩"),l1l1ll_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ摪"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ摫"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ摬"),l1l1ll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ摭"),l1l1ll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ摮"),l1l1ll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭摯"),l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ摰")]	# ,l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ摱")
l1ll1l1l1ll_l1_ += [l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ摲"),l1l1ll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ摳"),l1l1ll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ摴"),l1l1ll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ摵"),l1l1ll_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ摶"),l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ摷"),l1l1ll_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ摸")]
#l1ll1l1l1ll_l1_ += [l1l1ll_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ摹"),l1l1ll_l1_ (u"ࠫࡍࡋࡌࡂࡎࠪ摺"),l1l1ll_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ摻"),l1l1ll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ摼"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ摽"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ摾"),l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ摿")]
l111ll11l111_l1_  = [l1l1ll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ撀"),l1l1ll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ撁"),l1l1ll_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ撂"),l1l1ll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ撃"),l1l1ll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭撄"),l1l1ll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ撅"),l1l1ll_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ撆"),l1l1ll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ撇")]
l111ll11l111_l1_ += [l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ撈"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ撉"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ撊"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ撋"),l1l1ll_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ撌"),l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭撍"),l1l1ll_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ撎"),l1l1ll_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ撏"),l1l1ll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭撐")]
l111ll11l111_l1_ += [l1l1ll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ撑"),l1l1ll_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ撒"),l1l1ll_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ撓")]		# l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ撔"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ撕"),l1l1ll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭撖")
l111ll11l111_l1_ += [l1l1ll_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭撗"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ撘"),l1l1ll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ撙"),l1l1ll_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ撚"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ撛"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ撜"),l1l1ll_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ撝")]
l111ll11l111_l1_ += [l1l1ll_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ撞"),l1l1ll_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ撟"),l1l1ll_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ撠"),l1l1ll_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ撡"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ撢"),l1l1ll_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ撣"),l1l1ll_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ撤")]
l111l111lll1_l1_  = [l1l1ll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ撥"),l1l1ll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ撦"),l1l1ll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ撧"),l1l1ll_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭撨")]
l111l111lll1_l1_ += [l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ撩"),l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ撪")]
l111l111lll1_l1_ += [l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬ撫"),l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ撬"),l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ播")]
l111l111lll1_l1_ += [l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ撮"),l1l1ll_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭撯"),l1l1ll_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ撰")]
l111l111lll1_l1_ += [l1l1ll_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ撱"),l1l1ll_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ撲"),l1l1ll_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ撳")]
#l111l111lll1_l1_ += [l1l1ll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ撴"),l1l1ll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭撵")]
#l111l111lll1_l1_ += [l1l1ll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࠬ撶"),l1l1ll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࠬ撷"),l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘ࠭撸")]
l111l1l1111l_l1_ = [l1l1ll_l1_ (u"ࠫࡒ࠹ࡕࠨ撹"),l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘࠪ撺"),l1l1ll_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ撻"),l1l1ll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭撼"),l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ撽")]		# l1l1ll_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ撾"),l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭撿")
l1ll11lll1l_l1_ = l111ll11l111_l1_+l111l111lll1_l1_
l11ll1llll1_l1_ = l111ll11l111_l1_+l111l1l1111l_l1_
l1l11111l1l_l1_ = l111ll11l111_l1_+l111l1l1111l_l1_+l111l11ll111_l1_
l1ll11lll11_l1_ = l1111ll1l111_l1_+l1ll11l1l11_l1_+l1ll1l1l1ll_l1_+l1ll111l1ll_l1_
NO_EXIT_LIST = [ l1l1ll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭擀")
				,l1l1ll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ擁")
				,l1l1ll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ擂")
				,l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ擃")
				,l1l1ll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ擄")
				,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ擅")
				,l1l1ll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ擆")
				,l1l1ll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭擇")
				,l1l1ll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ擈")
				,l1l1ll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ擉")
				,l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ擊")
				,l1l1ll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭擋")
				,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ擌")
				,l1l1ll_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ操")
				,l1l1ll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ擎")
				,l1l1ll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ擏")
				,l1l1ll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ擐")
				,l1l1ll_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ擑")
				,l1l1ll_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ擒")
				,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ擓")
				,l1l1ll_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ擔")
				,l1l1ll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ擕")
				,l1l1ll_l1_ (u"ࠬࡌࡏࡔࡖࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭擖")
				#,l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ擗")
				#,l1l1ll_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ擘")
				#,l1l1ll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ擙")
				#,l1l1ll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ據")
				#,l1l1ll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ擛")
				#,l1l1ll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡇࡆࡖࡢࡐࡆ࡚ࡅࡔࡖࡢ࡚ࡊࡘࡓࡊࡑࡑࡣࡓ࡛ࡍࡃࡇࡕࡗ࠲࠷ࡳࡵࠩ擜")
				#,l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ擝")
				#,l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ擞")
				#,l1l1ll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ擟")
				]
# l11l111lllll_l1_ will not show l11l1l1l11ll_l1_ errors
UNIMPORTANT_REQUESTS = [
						l1l1ll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭擠")
						,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭擡")
						]
l1l11l111l11_l1_ = [l1l1ll_l1_ (u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ擢"),l1l1ll_l1_ (u"ࠫ࠶࠴࠱࠯࠳࠱࠵ࠬ擣"),l1l1ll_l1_ (u"ࠬ࠷࠮࠱࠰࠳࠲࠶࠭擤"),l1l1ll_l1_ (u"࠭࠸࠯࠺࠱࠸࠳࠺ࠧ擥"),l1l1ll_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠵࠲࠷࠸࠲ࠨ擦"),l1l1ll_l1_ (u"ࠨ࠴࠳࠼࠳࠼࠷࠯࠴࠵࠴࠳࠸࠲࠱ࠩ擧")]
WEBSITES = {
			#,l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ擨")	:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ擩")]
			#,l1l1ll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭擪")	:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡰࡨࡸࠬ擫")]
			#,l1l1ll_l1_ (u"࠭ࡅࡈ࡛࠷ࡆࡊ࡙ࡔࠨ擬")	:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭擭")]
			#,l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ擮")	:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ擯")]
			#,l1l1ll_l1_ (u"ࠪࡌࡊࡒࡁࡍࠩ擰")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠺ࡨࡦ࡮ࡤࡰ࠳ࡳࡥࠨ擱")]
			#,l1l1ll_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ擲")	:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧࠪ擳"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠭擴")]
			#,l1l1ll_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ擵")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡱࡹࡷ࠹ࡻ࠮ࡸࡵࠪ擶")]
			#,l1l1ll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ擷"):[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴࠨ擸")]
			#,l1l1ll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ擹")	:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠱ࡧࡴࡳࠧ擺")]
			 l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭擻")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ擼")]
			,l1l1ll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ擽")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺࠧ擾")]
			,l1l1ll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ擿")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ攀")]
			,l1l1ll_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ攁")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮ࡩࡥࡹ࡯࡭ࡪ࠰ࡷࡺࠬ攂")]
			#,l1l1ll_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ攃")	:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࡷࡺ࠳࡯ࡲࠨ攄")]
			,l1l1ll_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ攅")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪ攆")]
			,l1l1ll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ攇")		:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡤࡦࡸ࡫ࡥࡥ࠰ࡱࡩࡹ࠭攈")]
			,l1l1ll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭攉")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫ࡳࡴ࡬ࡶࡰࡦ࠱ࡧࡴࡳࠧ攊")]
			,l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ攋")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࠶ࡩࡩ࡮ࡣ࠷ࡹ࠳ࡩ࡯࡮ࠩ攌")]
			,l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭攍")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡥࡧࡪ࡯࠯ࡥࡲࡱࠬ攎")]
			,l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ攏")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥ࠲࡮ࡵࠧ攐")]
			,l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ攑")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭攒")]
			,l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭攓")	:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴ࠯ࡥࡲࡱࠬ攔")]
			,l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ攕")	:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬ攖")]
			,l1l1ll_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭攗")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡳࡸࡺࡡ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ攘")]
			,l1l1ll_l1_ (u"ࠩࡄࡌ࡜ࡇࡋࠨ攙")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࠮ࡢࡪࡺࡥࡰࡺࡶ࠯ࡰࡨࡸࠬ攚")]
			,l1l1ll_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ攛")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦ࠸ࡣࡥ࠲ࡦࢀࡵࡳࡧࡨࡨ࡬࡫࠮࡯ࡧࡷࠫ攜")]
			,l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ攝")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡦ࠲ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡷࡰࡴ࡮ࠫ攞")]
			,l1l1ll_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ攟")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨ攠")]
			,l1l1ll_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ攡")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩ攢")]
			,l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭攣")		:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬ攤")]
			,l1l1ll_l1_ (u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ攥")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡥࡷࡵࡺࡢ࠰ࡲࡲࡪ࠭攦")]
			,l1l1ll_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ攧")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ攨")]
			,l1l1ll_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭攩")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ攪")]
			,l1l1ll_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ攫")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡦ࠲ࡩࡸࡡ࡮ࡣࡶ࠻࠳ࡩ࡯࡮ࠩ攬")]
			,l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ攭")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡ࠮ࡰࡲࡻ࠳ࡩ࡯࡮ࠩ攮")]
			,l1l1ll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ支")	:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡥࡧ࡯ࡣ࠮ࡶࡲࡳࡳࡹ࠮ࡤࡱࡰࠫ攰")]
			,l1l1ll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ攱")	:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭攲"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ攳")]
			#,l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ攴")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡲࡪࡺࠧ攵")]
			,l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫ收")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡦࡨࡥࡩ࠴࡬ࡪࡸࡨࠫ攷")]
			#,l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ攸")		:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡪ࡭ࡹ࡯ࡱࡺ࠲ࡱ࡯ࡶࡦࠩ改")]
			,l1l1ll_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ攺")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡰࡨ࡯࡮ࡦ࡯ࡤ࠲ࡨࡵ࡭ࠨ攻")]
			,l1l1ll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ攼")	:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡪࡦࡴ࠱ࡷ࡭ࡵࡷࠨ攽")]
			,l1l1ll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭放")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡻ࡯ࡰࠨ政")]
			,l1l1ll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ敀")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪ敁")]
			,l1l1ll_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ敂")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡬ࡦࡲࡡࡤ࡫ࡰࡥ࠳ࡻࡳࠨ敃")]
			,l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ敄")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ故"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡯࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭敆"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ敇"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠶࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ效"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨ敉")]
			#,l1l1ll_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ敊")			:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳࡵࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮ࠩ敋")]
			,l1l1ll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ敌")	:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭敍")]
			,l1l1ll_l1_ (u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ敎")	:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫ敏"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥ࡭ࡹ࠴࡬ࡺ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫ敐")]
			,l1l1ll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ救")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡩࡡ࡮ࠩ敒")]
			#,l1l1ll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ敓")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡺࡥ࡬ࡱࡦ࠴ࡣࡰࠩ敔")]
			,l1l1ll_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠭敕")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡶࡸࡦࡪ࠭敖")]
			,l1l1ll_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ敗")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ敘")]
			#,l1l1ll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ教")		:[l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ敚"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ敛"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ敜"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭敝"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭敞"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ敟"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ敠")]
			#,l1l1ll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ敡")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ敢"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ散"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭敤"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ敥"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ敦"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ敧"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ敨")]
			#,l1l1ll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ敩")		:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ敪"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭敫"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ敬"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ敭"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ敮"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ敯"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ数")]
			#,l1l1ll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭敱")		:[l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ敲"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ敳"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭整"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ敵"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩ敶"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ敷"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ數")]
			#,l1l1ll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ敹")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ敺"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ敻"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ敼"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ敽"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ敾"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭敿"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ斀")]
			,l1l1ll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ斁")		:[l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ斂"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ斃"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ斄"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ斅"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ斆"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ文"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ斈")]
			#,l1l1ll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ斉")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳ࠫ斊"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ斋"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ斌"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡌࡑࡇࡍࡗࡋࡐࡐ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ斍")]
			,l1l1ll_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭斎")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰࠩ斏"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ斐"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ斑"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭斒")]
			,l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ斓")		:[l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬ࡪࡪ࠭࠵ࡷ࠱ࡧࡴࡳࠧ斔")]
			,l1l1ll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ斕")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡵࡦ࡮ࡣࡻ࠲ࡨࡵ࡭ࠨ斖"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ斗"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭斘")]
			#,l1l1ll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭料")	:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣ࠯ࡵ࡫ࡳࡴ࡬ࡰࡳࡱ࠱ࡳࡳࡲࡩ࡯ࡧࠪ斚")]    #	l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡶࡲࡰ࠰ࡦࡳࡲ࠭斛")
			,l1l1ll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭斜")		:[l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ斝")]
			,l1l1ll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ斞")		:[l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠭斟")]
			,l1l1ll_l1_ (u"ࠫࡘࡕࡕࡓࡅࡈࡗࠬ斠")		:[l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡬ࡱࡧ࡭ࠬ斡"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡶࡹࡷ࡭ࡥ࠯ࡵ࡫࠳ࡰࡵࡤࡪࠩ斢")]
			}
class l11l1111111l_l1_(): pass
class empty_response(l11l1111111l_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l1l1ll_l1_ (u"ࠧࠨ斣")
		self.content = l1l1ll_l1_ (u"ࠨࠩ斤")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l1l1ll_l1_ (u"ࠩࠪ斥")
class l111l1l111ll_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11lll1111ll_l1_ = -1
	def onClick(self,l11l11lll1ll_l1_):
		if l11l11lll1ll_l1_>=9010: self.l11lll1111ll_l1_ = l11l11lll1ll_l1_-9010
		self.delete()
	def l11ll1111ll1_l1_(self,*args):
		#self.getControl(9001).l1l1ll11ll1_l1_(header)
		#self.getControl(9009).l1l11l11l1ll_l1_(text)
		#self.getControl(9010).l1l1ll11ll1_l1_(button0)
		#self.getControl(9011).l1l1ll11ll1_l1_(button1)
		#self.getControl(9012).l1l1ll11ll1_l1_(button2)
		self.button0,self.button1,self.button2 = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1l11lll11l1_l1_ = args[5],args[6]
		self.image_width,self.l1111ll1111l_l1_,self.l111l1111l11_l1_ = args[7],args[8],args[9]
		if self.l1111ll1111l_l1_>0 or self.l111l1111l11_l1_>0: self.enable_progressbar = True
		else: self.enable_progressbar = False
		self.image_filename,self.image_height = CREATE_IMAGE(self.button0,self.button1,self.button2,self.header,self.text,self.profile,self.l1l11lll11l1_l1_,self.image_width,self.enable_progressbar)
		self.show()
		self.getControl(9050).setImage(self.image_filename)
		self.getControl(9050).setHeight(self.image_height)
		if not self.button1 and self.button0 and self.button2: self.getControl(9012).setPosition(-220,0)
		return self.image_filename,self.image_height
	def l11ll1llllll_l1_(self):
		if self.l1111ll1111l_l1_:
			import threading
			self.l111l1lll11l_l1_ = threading.Thread(target=self.l111lll11111_l1_,args=())
			self.l111l1lll11l_l1_.start()
			#self.l111l1lll11l_l1_.join()
		else: self.enableButtons()
	def l111lll11111_l1_(self):
		self.getControl(9020).setEnabled(True)
		for ii in range(1,self.l1111ll1111l_l1_+1):
			time.sleep(1)
			l1111ll11l1l_l1_ = int(100*ii/self.l1111ll1111l_l1_)
			self.l11l11111ll1_l1_(l1111ll11l1l_l1_)
			if self.l11lll1111ll_l1_>0: break
		self.enableButtons()
	def l11ll1ll111l_l1_(self):
		if self.l111l1111l11_l1_:
			import threading
			self.l111l1lll1l1_l1_ = threading.Thread(target=self.l11l11l111ll_l1_,args=())
			self.l111l1lll1l1_l1_.start()
			#self.l111l1lll1l1_l1_.join()
		else: self.enableButtons()
	def l11l11l111ll_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1111ll1111l_l1_)
		for ii in range(self.l111l1111l11_l1_-1,-1,-1):
			time.sleep(1)
			l1111ll11l1l_l1_ = int(100*ii/self.l111l1111l11_l1_)
			self.l11l11111ll1_l1_(l1111ll11l1l_l1_)
			if self.l11lll1111ll_l1_>0: break
		if self.l111l1111l11_l1_>0: self.l11lll1111ll_l1_ = 10
		self.delete()
	def l11l11111ll1_l1_(self,l1111ll11l1l_l1_):
		self.l11l111lll1l_l1_ = l1111ll11l1l_l1_
		self.getControl(9020).setPercent(self.l11l111lll1l_l1_)
	def enableButtons(self):
		if self.button0!=l1l1ll_l1_ (u"ࠪࠫ斦"): self.getControl(9010).setEnabled(True)
		if self.button1!=l1l1ll_l1_ (u"ࠫࠬ斧"): self.getControl(9011).setEnabled(True)
		if self.button2!=l1l1ll_l1_ (u"ࠬ࠭斨"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.image_filename)
		except: pass
		#del self
	l1l1ll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡩ࡫ࡦࠡࡷࡳࡨࡦࡺࡥࠩࡵࡨࡰ࡫࠲ࡰࡦࡴࡦࡩࡳࡺࠬࠫࡣࡵ࡫ࡸ࠯࠺ࠎࠌࠌࠍࡹ࡫ࡸࡵࠢࡀࠤࡦࡸࡧࡴ࡝࠳ࡡࠒࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩࡣࡵ࡫ࡸ࠯࠾࠲࠼ࠣࡸࡪࡾࡴࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࡤࡶ࡬ࡹ࡛࠲࡟ࠐࠎࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡡࡳࡩࡶ࠭ࡃ࠸࠺ࠡࡶࡨࡼࡹࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࡢࡴࡪࡷࡠ࠸࡝ࠎࠌࠌࠍࡸ࡫࡬ࡧ࠰ࡳࡩࡷࡩࡥ࡯ࡶ࠯ࡷࡪࡲࡦ࠯ࡶࡨࡼࡹࠦ࠽ࠡࡲࡨࡶࡨ࡫࡮ࡵ࠮ࡷࡩࡽࡺࠍࠋࠋࠌࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡧ࡫࡯ࡩࡳࡧ࡭ࡦ࠮ࡶࡩࡱ࡬࠮ࡪ࡯ࡤ࡫ࡪࡥࡨࡦ࡫ࡪ࡬ࡹࠦ࠽ࠡࡵࡨࡰ࡫࠴ࡣࡳࡧࡤࡸࡪ࡙ࡨࡰࡹࡌࡱࡦ࡭ࡥࠩࡵࡨࡰ࡫࠴ࡢࡶࡶࡷࡳࡳ࠶ࠬࡴࡧ࡯ࡪ࠳ࡨࡵࡵࡶࡲࡲ࠶࠲ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱ࠶࠱ࡹࡥ࡭ࡨ࠱࡬ࡪࡧࡤࡦࡴ࠯ࡷࡪࡲࡦ࠯ࡶࡨࡼࡹ࠲ࡳࡦ࡮ࡩ࠲ࡵࡸ࡯ࡧ࡫࡯ࡩ࠱ࡹࡥ࡭ࡨ࠱ࡨ࡮ࡸࡥࡤࡶ࡬ࡳࡳ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢࡻ࡮ࡪࡴࡩ࠮ࡶࡩࡱ࡬࠮ࡣࡷࡷࡸࡴࡴࡳࡵ࡫ࡰࡩࡴࡻࡴ࠭ࡵࡨࡰ࡫࠴ࡣ࡭ࡱࡶࡩࡹ࡯࡭ࡦࡱࡸࡸ࠮ࠓࠊࠊࠋࡶࡩࡱ࡬࠮ࡶࡲࡧࡥࡹ࡫ࡐࡳࡱࡪࡶࡪࡹࡳࡃࡣࡵࠬࡵ࡫ࡲࡤࡧࡱࡸ࠮ࠓࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࡶࡩࡱ࡬࠮ࡪ࡯ࡤ࡫ࡪࡥࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡵࡨࡰ࡫࠴ࡩ࡮ࡣࡪࡩࡤ࡮ࡥࡪࡩ࡫ࡸࠒࠐࠉࠣࠤࠥ斩")
class l111lll1111l_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l1l1ll_l1_ (u"ࠧࠨ斪")
	def onPlayBackStopped(self):
		self.status=l1l1ll_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ斫")
	def onPlayBackStarted(self):
		if l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ斬")):
			self.stop()
			self.status = l1l1ll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ断")
		else: self.status = l1l1ll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ斮")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l1l1ll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ斯")
	def onPlayBackEnded(self):
		self.status = l1l1ll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭新")
class l111ll11lll_l1_():
	def __init__(self,showDialogs=False,l111ll111l1l_l1_=True):
		self.showDialogs = showDialogs
		self.l111ll111l1l_l1_ = l111ll111l1l_l1_
		self.l11ll111ll1l_l1_,self.l11lll11ll1l_l1_ = [],[]
		self.l11l11llll11_l1_,self.l11l11ll1l1l_l1_ = {},{}
		self.l11l1ll11lll_l1_ = []
		self.l1111lll1lll_l1_,self.l11l111ll11l_l1_,self.l11ll1lll1ll_l1_ = {},{},{}
	def l11l1lllll11_l1_(self,id,func,*args):
		id = str(id)
		self.l11l11llll11_l1_[id] = l1l1ll_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ斱")
		if self.showDialogs: DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠨࠩ斲"),id)
		# l1ll1111111l_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1ll1111111l_l1_ 2 & 3
		import threading
		l11lll111ll1_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l11l1ll11lll_l1_.append(l11lll111ll1_l1_)
		#l11lll111ll1_l1_.start()
		return l11lll111ll1_l1_
	def start_new_thread(self,id,func,*args):
		l11lll111ll1_l1_ = self.l11l1lllll11_l1_(id,func,*args)
		l11lll111ll1_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1111lll1lll_l1_[id] = time.time()
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ斳"),l1l1ll_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡷࡹࡧࡲࡵࡧࡧࠤ࡮ࡪ࠺ࠡࠩ斴")+id)
		try:
			#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ斵"),l1l1ll_l1_ (u"ࠬࡋࡍࡂࡆ࠽࠾ࠥ࠭斶")+str(func))
			self.l11l11ll1l1l_l1_[id] = func(*args)
			if l1l1ll_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧ斷") in str(func) and not self.l11l11ll1l1l_l1_[id].succeeded:
				FORCED_EXIT(l1l1ll_l1_ (u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡺࡨࡳࡧࡤࡨࡪࡪࠠࡐࡒࡈࡒ࡚ࡘࡌࠡࡨࡤ࡭ࡱ࠭斸"))
			self.l11ll111ll1l_l1_.append(id)
			self.l11l11llll11_l1_[id] = l1l1ll_l1_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪ方")
			#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ斺"),l1l1ll_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪ࡮ࡴࡩࡴࡪࡨࡨࠥ࡯ࡤ࠻ࠢࠪ斻")+id)
		except Exception as err:
			#LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ於"),l1l1ll_l1_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨࠥ࡯ࡤ࠻ࠢࠪ施")+id)
			if self.l111ll111l1l_l1_:
				errortrace = traceback.format_exc()
				sys.stderr.write(errortrace)
				#traceback.print_exc(file=sys.stderr)
			self.l11lll11ll1l_l1_.append(id)
			self.l11l11llll11_l1_[id] = l1l1ll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭斾")
		self.l11l111ll11l_l1_[id] = time.time()
		self.l11ll1lll1ll_l1_[id] = self.l11l111ll11l_l1_[id] - self.l1111lll1lll_l1_[id]
	def l111ll111l11_l1_(self):
		for proc in self.l11l1ll11lll_l1_:
			proc.start()
	def l1111ll1l1l1_l1_(self):
		while l1l1ll_l1_ (u"ࠧࡳࡷࡱࡲ࡮ࡴࡧࠨ斿") in list(self.l11l11llll11_l1_.values()): time.sleep(1.000)
def l111ll11l1ll_l1_():
	l111l1l1llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬ旀"))
	if l111l1l1llll_l1_==addon_version:
		status = l1l1ll_l1_ (u"ࠩࡑࡓࡤ࡛ࡐࡅࡃࡗࡉࠬ旁")
	elif not os.path.exists(addoncachefolder):
		status = l1l1ll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ旂")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l1l1ll_l1_ (u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ旃")
	else:
		status = l1l1ll_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ旄")
		l11ll1l11111_l1_ = [l1l1ll_l1_ (u"࠭࠸࠯࠷࠱࠴ࠬ旅"),l1l1ll_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫ旆"),l1l1ll_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭旇"),l1l1ll_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭旈"),l1l1ll_l1_ (u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧ旉"),l1l1ll_l1_ (u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨ旊"),l1l1ll_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩ旋"),l1l1ll_l1_ (u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪ旌"),l1l1ll_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫ旍")]
		l11l1111l111_l1_ = l11ll1l11111_l1_[-1]
		l11l1l1l1ll1_l1_ = l1111ll11l11_l1_(l11l1111l111_l1_)
		l111llll1l11_l1_ = l1111ll11l11_l1_(addon_version)
		if l111llll1l11_l1_>l11l1l1l1ll1_l1_:
			status = l1l1ll_l1_ (u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨ旎")
			l1l1ll_l1_ (u"ࠤࠥࠦࠒࠐࠉࠊࠋࡩ࡭ࡱ࡫ࡳࠡ࠿ࠣࡳࡸ࠴࡬ࡪࡵࡷࡨ࡮ࡸࠨࡢࡦࡧࡳࡳࡩࡡࡤࡪࡨࡪࡴࡲࡤࡦࡴࠬࠑࠏࠏࠉࠊࡨ࡬ࡰࡪࡹࠠ࠾ࠢࡶࡳࡷࡺࡥࡥࠪࡩ࡭ࡱ࡫ࡳ࠭ࡴࡨࡺࡪࡸࡳࡦ࠿ࡗࡶࡺ࡫ࠩࠎࠌࠌࠍࠎ࡬࡯ࡳࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡧ࡫࡯ࡩࡸࡀࠍࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡧࡥࡹࡧ࡟ࠨࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠠࡢࡰࡧࠤࠬ࠴ࡤࡣࠩࠣ࡭ࡳࠦࡦࡪ࡮ࡨࡲࡦࡳࡥ࠻ࠏࠍࠍࠎࠏࠉࠊࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤࡣ࠭࠴ࠪࡀࠫ࡟࠲ࡩࡨࠧ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱ࡟࠵ࡣࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩࠥࡃࠠࡗࡇࡕࡗࡎࡕࡎࡠࡅࡒࡑࡕࡇࡒࡆࡡࡓࡅࡗ࡙ࡅࡓࠪࡲࡰࡩࡥࡶࡦࡴࡶ࡭ࡴࡴࠩࠎࠌࠌࠍࠎࠏࠉࡪࡨࠣࠫࡲࡧࡩ࡯ࡦࡤࡸࡦࡥࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏࠉࡪࡨࠣࡳࡱࡪ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࡠࡥࡲࡱࡵࡧࡲࡦࡀࡀࡰࡦࡹࡴࡧࡷ࡯ࡰࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠺ࠎࠌࠌࠍࠎࠏࠉࠊࠋࡲࡰࡩࡥࡤࡣࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡢࡦࡧࡳࡳࡩࡡࡤࡪࡨࡪࡴࡲࡤࡦࡴ࠯ࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡵࡴࡼ࠾ࠒࠐࠉࠊࠋࠌࠍࠎࠏࠉࡪࡨࠣࡳࡱࡪ࡟ࡥࡤࡩ࡭ࡱ࡫ࠡ࠾࡯ࡤ࡭ࡳࡥࡤࡣࡨ࡬ࡰࡪࡀࠠࡰࡵ࠱ࡶࡪࡴࡡ࡮ࡧࠫࡳࡱࡪ࡟ࡥࡤࡩ࡭ࡱ࡫ࠬ࡮ࡣ࡬ࡲࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠓࠊࠊࠋࠌࠍࠎࠏࠉࠊࡵࡷࡥࡹࡻࡳࠡ࠿ࠣࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫࠒࠐࠉࠊࠋࠌࠍࠎࠏࠉࡣࡴࡨࡥࡰࠓࠊࠊࠋࠌࠍࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠋࠌࠦࠧࠨ族")
	return status
def l11l11l1l1l1_l1_():
	script_name = l1l1ll_l1_ (u"ࠪࡑࡆࡏࡎࡎࡇࡑ࡙ࠬ旐")
	succeeded,updateListing,cacheToDisc = True,False,False
	menuItem = EXTRACT_KODI_PATH(addon_path)
	type,l11ll11l1ll1_l1_,l111lll11l11_l1_,mode,l111l111l1l1_l1_,l11l111l1l11_l1_,text,context,infodict = menuItem
	l1111lllllll_l1_ = type,l11ll11l1ll1_l1_,l111lll11l11_l1_,mode,l111l111l1l1_l1_,l11l111l1l11_l1_,text,l1l1ll_l1_ (u"ࠫࠬ旑"),infodict
	l111l1lllll1_l1_ = int(mode)
	l11l1lll1ll1_l1_ = int(l111l1lllll1_l1_%10)
	l11lllll111_l1_ = int(l111l1lllll1_l1_/10)
	#l11lll1111_l1_ = l11ll1l1ll_l1_()
	l1llll11l1ll_l1_ = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭旒"))
	l1llll11l1ll_l1_ = l1llll11l1ll_l1_.replace(ltr,l1l1ll_l1_ (u"࠭ࠧ旓")).replace(rtl,l1l1ll_l1_ (u"ࠧࠨ旔"))
	if l111l1lllll1_l1_==260: message = l1l1ll_l1_ (u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩ旕")+addon_version+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩ旖")+l1l1l1lll111_l1_+l1l1ll_l1_ (u"ࠪࠤࡢ࠭旗")
	else:
		l11ll1ll1lll_l1_ = UNQUOTE(addon_path).replace(l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ旘"),l1l1ll_l1_ (u"ࠬ࠭旙")).replace(l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ旚"),l1l1ll_l1_ (u"ࠧࠨ旛"))
		l11ll1ll1lll_l1_ = l11ll1ll1lll_l1_.replace(l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ旜"),l1l1ll_l1_ (u"ࠩࠪ旝")).strip(l1l1ll_l1_ (u"ࠪࠤࠬ旞"))
		l11ll1ll1lll_l1_ = l11ll1ll1lll_l1_.replace(l1l1ll_l1_ (u"ࠫࠥࠦࠠࠡࠩ旟"),l1l1ll_l1_ (u"ࠬࠦࠧ无")).replace(l1l1ll_l1_ (u"࠭ࠠࠡࠢࠪ旡"),l1l1ll_l1_ (u"ࠧࠡࠩ既")).replace(l1l1ll_l1_ (u"ࠨࠢࠣࠫ旣"),l1l1ll_l1_ (u"ࠩࠣࠫ旤"))
		message = l1l1ll_l1_ (u"ࠪࠤࠥࠦࡌࡢࡤࡨࡰ࠿࡛ࠦࠡࠩ日")+l1llll11l1ll_l1_+l1l1ll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡐࡳࡩ࡫࠺ࠡ࡝ࠣࠫ旦")+mode+l1l1ll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ旧")+l11ll1ll1lll_l1_+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ旨")
	LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ早"),LOGGING(script_name)+message)
	#text = text.replace(l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ旪"),l1l1ll_l1_ (u"ࠩࠪ旫"))
	refresh = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ旬"))
	l1l11ll1ll1l_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ旭"))
	l11lll1111_l1_ = RESTORE_PATH_NAME(l1llll11l1ll_l1_)
	l11ll11l1ll1_l1_ = RESTORE_PATH_NAME(l11ll11l1ll1_l1_)
	l11l11lll11l_l1_ = [0,15,17,19,26,34,50,53]
	l111ll1l111l_l1_ = [0,15,17,19,26,34,50,53]
	l11ll1llll1l_l1_ = l11lllll111_l1_ not in l111ll1l111l_l1_
	l11ll1l1lll1_l1_ = l11lllll111_l1_ in [23,28,71,72]
	l111lll1l1ll_l1_ = l111l1lllll1_l1_ in [265,270]
	l11l1111llll_l1_ = (l11ll1llll1l_l1_ or l11ll1l1lll1_l1_) and not l111lll1l1ll_l1_
	l11lll111lll_l1_ = refresh!=l1l1ll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ旮") and (refresh!=l1l1ll_l1_ (u"࠭ࠧ旯") or context==l1l1ll_l1_ (u"ࠧࠨ旰"))
	l11l1ll1l11l_l1_ = l1l1ll_l1_ (u"ࠨࡶࡼࡴࡪࡃࠧ旱") in refresh
	l11ll1l111l_l1_ = l111l1lllll1_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l11l1lll1ll1_l1_==9 or l111l1lllll1_l1_ in [145,516,523]
	l11ll1ll11ll_l1_ = not l11ll1l111l_l1_
	l11ll111l1l1_l1_ = not SEARCH
	l111llll111l_l1_ = l11lll1111_l1_ in [l1l1ll_l1_ (u"ࠩࠪ旲"),l1l1ll_l1_ (u"ࠪ࠲࠳࠭旳")]
	l11l1l1l11l1_l1_ = l111llll111l_l1_ or l11ll1ll11ll_l1_
	l11l11l1ll1l_l1_ = l111llll111l_l1_ or l11ll111l1l1_l1_ or l11l1ll1l11l_l1_
	l111l11111l1_l1_ = l111l1lllll1_l1_ not in [260,265,270,330,540]
	if l1l11ll1ll1l_l1_: l11l1l11llll_l1_ = SEARCH or l11ll1l111l_l1_
	else: l11l1l11llll_l1_ = True
	l1ll11111l_l1_ = l11lllll111_l1_ in [74,75]
	l11l1l1lllll_l1_ = not l11ll1l1lll1_l1_ and not l1ll11111l_l1_
	l11l111l1ll1_l1_ = l111l11111l1_l1_ and l11l1l1l11l1_l1_ and l11l11l1ll1l_l1_ and l11l1l11llll_l1_ and l11l1l1lllll_l1_
	l111ll1l11l1_l1_ = l111l11111l1_l1_ and l11l1l11llll_l1_ and l11l1l1lllll_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ旴"),l1l1ll_l1_ (u"ࠬ࠭旵"),l1l1ll_l1_ (u"࠭ࠧ时"),type+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠫ旷")+refresh+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠬ旸")+str(l111ll1l11l1_l1_))
	if 1 and l11lll111lll_l1_ and l11l111l1ll1_l1_:
		DirectoryItems_List = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ旹"),l1l1ll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ旺"),l1111lllllll_l1_)
		if DirectoryItems_List:
			#xbmcgui.Dialog().l111l111ll11_l1_(l1l1ll_l1_ (u"ࠫࠬ旻"),l1l1ll_l1_ (u"ࠬࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࠬ旼"),l1l1ll_l1_ (u"࠭ࠧ旽"),100,False)
			#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ旾"),l1l1ll_l1_ (u"ࠨ࠰ࠣࠤࠥࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦࡣࡢࡥ࡫ࡩࡩࠦ࡭ࡦࡰࡸࠫ旿"))
			if 1 and l11l1ll1l11l_l1_:
				#xbmcgui.Dialog().l111l111ll11_l1_(l1l1ll_l1_ (u"ࠩࠪ昀"),l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧࡻ࡬ࡲ࡬ࠦࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ昁"),l1l1ll_l1_ (u"ࠫࠬ昂"),100,False)
				l11ll1l1llll_l1_ = []
				import l1l11ll11l1_l1_,FAVORITES
				MENUS__LAST_VIDEOS_MENU = l1l11ll11l1_l1_.l1l11ll11ll_l1_
				FAVORITES_FILE_DICT = FAVORITES.GET_ALL_FAVORITES()
				l11l11llll1l_l1_ = refresh
				l11ll111l111_l1_,l11ll111lll1_l1_,l1l1111llll_l1_,l111l1lll111_l1_,l11ll1l11l1l_l1_,l11l11l1l111_l1_,l11ll111llll_l1_,l111ll1l1ll1_l1_,l11l11l11l11_l1_ = EXTRACT_KODI_PATH(l11l11llll1l_l1_)
				l111llll1111_l1_ = l11ll111l111_l1_,l11ll111lll1_l1_,l1l1111llll_l1_,l111l1lll111_l1_,l11ll1l11l1l_l1_,l11l11l1l111_l1_,l11ll111llll_l1_,l1l1ll_l1_ (u"ࠬ࠭昃"),l11l11l11l11_l1_
				#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ昄"),str(l111llll1111_l1_))
				for list_item in DirectoryItems_List:
					l111l1l11l1l_l1_ = list_item[l1l1ll_l1_ (u"ࠧ࡮ࡧࡱࡹࡎࡺࡥ࡮ࠩ昅")]
					#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ昆"),str(l111l1l11l1l_l1_))
					if l111l1l11l1l_l1_==l111llll1111_l1_ or list_item[l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡫ࠧ昇")] in [265,270]:
						list_item = GET_LIST_ITEM(l111l1l11l1l_l1_,MENUS__LAST_VIDEOS_MENU,FAVORITES_FILE_DICT)
						if list_item[l1l1ll_l1_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸ࠭昈")]:
							#xbmcgui.Dialog().l111l111ll11_l1_(l1l1ll_l1_ (u"ࠫࠬ昉"),l1l1ll_l1_ (u"ࠬࡻࡰࡥࡣࡷ࡭ࡳ࡭ࠠࡤࡱࡱࡸࡪࡾࡴࠨ昊"),l1l1ll_l1_ (u"࠭ࠧ昋"),100,False)
							l111l1ll1111_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(FAVORITES_FILE_DICT,l111l1l11l1l_l1_,list_item[l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡴࡦࡺࡨࠨ昌")])
							#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ昍"),str(l111l1ll1111_l1_))
							#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ明"),str(list_item[l1l1ll_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ昏")]))
							list_item[l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪ昐")] = l111l1ll1111_l1_+list_item[l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹࡥ࡭ࡦࡰࡸࠫ昑")]
					l11ll1l1llll_l1_.append(list_item)
				settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ昒"),l1l1ll_l1_ (u"ࠧࠨ易"))
				if type==l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ昔"): WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠧ昕"),l1111lllllll_l1_,l11ll1l1llll_l1_,REGULAR_CACHE)
			else: l11ll1l1llll_l1_ = DirectoryItems_List
			if type==l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ昖") and l11lll1111_l1_!=l1l1ll_l1_ (u"ࠫ࠳࠴ࠧ昗") and l11l1111llll_l1_: l11l1l11ll11_l1_()
			addItems_succeeded = CREATE_KODI_MENU(l11ll1l1llll_l1_,succeeded,updateListing,cacheToDisc)
			#xbmcgui.Dialog().l111l111ll11_l1_(l1l1ll_l1_ (u"ࠬ࠭昘"),l1l1ll_l1_ (u"࠭ࡣࡳࡧࡤࡸ࡮ࡴࡧࠡ࡯ࡨࡲࡺ࠭昙"),l1l1ll_l1_ (u"ࠧࠨ昚"),100,False)
			return
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ昛"),addon_path)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ昜"),refresh)
	elif type==l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ昝") and refresh==l1l1ll_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ昞") and l111ll1l11l1_l1_:
		#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭星"),l1l1ll_l1_ (u"࠭࠮ࠡࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠡࠢࠣࡈࡪࡲࡥࡵ࡫ࡱ࡫ࠥࡵ࡬ࡥࠢࡦࡥࡨ࡮ࡥࡥࠢࡰࡩࡳࡻࠧ映"))
		DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ昡"),l1111lllllll_l1_)
	#context = l1l1ll_l1_ (u"ࠨࠩ昢")
	if l1l1ll_l1_ (u"ࠩࡢࠫ昣") in context: l111l11111ll_l1_,context2 = context.split(l1l1ll_l1_ (u"ࠪࡣࠬ昤"),1)
	else: l111l11111ll_l1_,context2 = context,l1l1ll_l1_ (u"ࠫࠬ春")
	if l111l11111ll_l1_ in [l1l1ll_l1_ (u"ࠬ࠷ࠧ昦"),l1l1ll_l1_ (u"࠭࠲ࠨ昧"),l1l1ll_l1_ (u"ࠧ࠴ࠩ昨"),l1l1ll_l1_ (u"ࠨ࠶ࠪ昩"),l1l1ll_l1_ (u"ࠩ࠸ࠫ昪")] and context2:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ昫") l11ll111l1_l1_ l111l11l11l1_l1_ l1111llll1l1_l1_ is no addon_handle l1l1l1ll1_l1_ to l11ll11lll1l_l1_ for l11l111l1111_l1_ directory
		#l1l1ll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠧ昬") l11ll111l1_l1_ to open a l1lll1l11l_l1_ list l1l1lll11l_l1_ l111l11l1lll_l1_ addon_path
		#xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤ昭")+sys.argv[0]+addon_path.split(l1l1ll_l1_ (u"࠭ࠦࡤࡱࡱࡸࡪࡾࡴ࠾ࠩ昮"))[0]+l1l1ll_l1_ (u"ࠧࠧࡥࡲࡲࡹ࡫ࡸࡵ࠿࠳ࠫ是")+l1l1ll_l1_ (u"ࠣࠫࠥ昰"))
		#xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ昱")+addon_id+l1l1ll_l1_ (u"ࠪ࠳ࡄࡺࡥࡹࡶࡀࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣ࠮࠭昲"))
		settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ昳"),l1l1ll_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ昴"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ昵"))
		return
	elif l111l11111ll_l1_==l1l1ll_l1_ (u"ࠧ࠷ࠩ昶"):
		if context2==l1l1ll_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ昷"): DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩ昸"),l1l1ll_l1_ (u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪ昹"))
		elif context2==l1l1ll_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠫ昺"): mode = 334
		results = l11lll111ll_l1_(type,l11ll11l1ll1_l1_,l111lll11l11_l1_,mode,l111l111l1l1_l1_,l11l111l1l11_l1_,text,context,infodict)
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ昻"))
		return
	elif context==l1l1ll_l1_ (u"࠭࠷ࠨ昼"):
		import l1lll1ll111_l1_
		l1lll1ll111_l1_.l1ll11l1l1l_l1_()
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ昽"))
		return
	elif context==l1l1ll_l1_ (u"ࠨ࠺ࠪ显"):
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ昿")+addon_id+l1l1ll_l1_ (u"ࠪࡃࡲࡵࡤࡦ࠿ࠪ晀")+str(mode)+l1l1ll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫ晁"))
		return
	elif context==l1l1ll_l1_ (u"ࠬ࠿ࠧ時"):
		# l111ll11l11l_l1_ update the l1111lll111l_l1_ l1lll1l11l_l1_
		#results = l11lll111ll_l1_(type,l11ll11l1ll1_l1_,l111lll11l11_l1_,mode,l111l111l1l1_l1_,l11l111l1l11_l1_,text,context,infodict)
		# l111ll11l11l_l1_ update the l111lll1ll1l_l1_ l1lll1l11l_l1_
		settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ晃"),l1l1ll_l1_ (u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡆࡆࠪ晄"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ晅"))
		return
	if settings.getSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ晆")) not in [l1l1ll_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ晇"),l1l1ll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ晈"),l1l1ll_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭晉")]: settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ晊"),l1l1ll_l1_ (u"ࠧࡂࡗࡗࡓࠬ晋"))
	if not settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡨࡶࡻ࡫ࡲࠨ晌")): settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡩࡷࡼࡥࡳࠩ晍"),l1l11l111l11_l1_[0])
	l11l1lllll1l_l1_ = l111ll11l1ll_l1_()
	l11l1l11ll1l_l1_ = l11l1lllll1l_l1_!=l1l1ll_l1_ (u"ࠪࡒࡔࡥࡕࡑࡆࡄࡘࡊ࠭晎")
	if l11l1l11ll1l_l1_:
		if not l1l11ll1ll1l_l1_: settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ晏"),l1l1ll_l1_ (u"ࠬ࠭晐"))
		#l111l1l1llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ晑"))
		#if l111l1l1llll_l1_:
		#	settings.setSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ晒"),l1l1ll_l1_ (u"ࠨࠩ晓"))
		#	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭晔"))
		#	return
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ晕"),l1l1ll_l1_ (u"ࠫࠬ晖"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ晗"),l1l1ll_l1_ (u"࠭สๆࠢอัิ๐หࠡสิ๊ฬ๋ฬࠡ฻่หิࠦวๅาํࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧ晘")+addon_version)
		#l1l1l1l111ll_l1_([main_dbfile])
		if l11l1lllll1l_l1_==l1l1ll_l1_ (u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧ晙"):
			LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ晚"),l1l1ll_l1_ (u"ࠩ࠱ࠤࠥࠦࡁࡳࡣࡥ࡭ࡨ࡜ࡩࡥࡧࡲࡷ࡛ࠥࡰࡥࡣࡷࡩ࡚ࠥࡹࡱࡧ࠽ࠤ࡙ࠥࡉࡎࡒࡏࡉ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ晛")+addon_path+l1l1ll_l1_ (u"ࠪࠤࡢ࠭晜"))
			DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ晝"),l1l1ll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡔࡋࡗࡉࡘ࠭晞"))
			for folder in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ晟"),l1l1ll_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ晠")+str(folder))
				DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ晡"),l1l1ll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ晢")+str(folder))
		else:
			LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ晣"),l1l1ll_l1_ (u"ࠫ࠳ࠦࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡇࡗࡏࡐ࡛ࠥࡐࡅࡃࡗࡉࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ晤")+addon_path+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ晥"))
			DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ晦"),l1l1ll_l1_ (u"ࠧࠨ晧"),l1l1ll_l1_ (u"ࠨสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ晨"),l1l1ll_l1_ (u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣื๏่่ๆࠢส่ว์ࠠศๆหี๋อๅอࠢหฬ฾฼ࠠศๆไัํ฻วหࠢ็ฺ๊อๆࠡ฻่่ࠥอไษำ้ห๊าࠠษื๋ีฮࠦีฮ์ะอࠥ๎ๅหๅส้้ฯࠧ晩"))
			l1l1l1l111ll_l1_()
			FIX_ALL_DATABASES(False)
			l11ll11111l1_l1_ = l1l1l1l1l1l_l1_(32)
			import l1ll1l1lll11_l1_
			l1ll1l1lll11_l1_.l1l1l1lll1l1_l1_()
			l1ll1l1lll11_l1_.l1l1llll1lll_l1_()
			l1ll1l1lll11_l1_.l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ晪"),False)
			l1ll1l1lll11_l1_.l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ晫"),False)
			l1ll1l1lll11_l1_.l1l1llll11l1_l1_(False)
			l1ll1l1lll11_l1_.l1l1lll11ll1_l1_(False)
			l1ll1l1lll11_l1_.l1l1llll1l11_l1_(l1l1ll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ晬"),l1l1ll_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭晭"),False)
			l1l1ll_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡵࡴࡼ࠾ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࡫࡯࡬ࡦ࠴ࠣࡁࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡪࡰ࡫ࡱࠬࡺࡹࡥࡳࡨࡲࡰࡩ࡫ࡲ࠭ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ࠱࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ࠰ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩࠬ࠲ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳ࠢࡀࠤࡽࡨ࡭ࡤࡣࡧࡨࡴࡴ࠮ࡂࡦࡧࡳࡳ࠮ࡩࡥ࠿ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪ࠭ࠒࠐࠉࠊࠋࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠷࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡰࡵࡤࡪࡱࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡵࡺࡧ࡬ࡪࡶࡼ࠲ࡦࡹ࡫ࠨ࠮ࠪࡸࡷࡻࡥࠨࠫࠐࠎࠎࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠓࠊࠊࠋࠌࠦࠧࠨ普")
			try:
				l11ll11ll111_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ景"),l1l1ll_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭晰"),l1l1ll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧ晱"),l1l1ll_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ晲"))
				l11l11lll111_l1_ = xbmcaddon.Addon(id=l1l1ll_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ晳"))
				l11l11lll111_l1_.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡤࡹࡹࡵ࡟ࡱ࡫ࡦ࡯ࠬ晴"),l1l1ll_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭晵"))
			except: pass
			try:
				l11ll11ll111_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ晶"),l1l1ll_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭晷"),l1l1ll_l1_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ晸"),l1l1ll_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ晹"))
				l11l11lll111_l1_ = xbmcaddon.Addon(id=l1l1ll_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ智"))
				l11l11lll111_l1_.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡹ࡭ࡩ࡫࡯ࡠࡳࡸࡥࡱ࡯ࡴࡺࠩ晻"),l1l1ll_l1_ (u"ࠧ࠴ࠩ晼"))
			except: pass
			try:
				l11ll11ll111_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ晽"),l1l1ll_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭晾"),l1l1ll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ晿"),l1l1ll_l1_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ暀"))
				l11l11lll111_l1_ = xbmcaddon.Addon(id=l1l1ll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ暁"))
				l11l11lll111_l1_.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡖࡘࡗࡋࡁࡎࡕࡈࡐࡊࡉࡔࡊࡑࡑࠫ暂"),l1l1ll_l1_ (u"ࠧ࠳ࠩ暃"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ暄"),l1l1ll_l1_ (u"ࠩࠪ暅"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭暆"),l1l1ll_l1_ (u"ࠫสึวࠡๅ้ฮࠥะำหะา้ࠥิฯๆหࠣไࡎࡖࡔࡗࠢส่๊๎ฬ้ัฬࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦแิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢอ่็อฦ๋ษࠣฬั๊ศࠡ็็ๅฬะࠠแࡋࡓࡘ࡛ࠦฬะ์าอࠬ暇"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1l1l11ll11_l1_):
			#	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭暈"),l1l1ll_l1_ (u"࠭ࠧ暉"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ暊"),l1l1ll_l1_ (u"ࠨวำห้ࠥๆหࠢอืฯิฯๆࠢัำ๊ฯࠠแࡏ࠶࡙ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ暋"))
			#	import l1l1l11l1l1_l1_
			#	l1l1l11l1l1_l1_.CREATE_STREAMS()
		settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ暌"),l1l1ll_l1_ (u"ࠪࠫ暍"))
		settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬࡯ࡴࡶࡤࠫ暎"),l1l1ll_l1_ (u"ࠬ࠭暏"))
		data = FIX_AND_GET_FILE_CONTENTS(l1l11l11ll1_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1ll1111lll1_l1_)
		settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ暐"),addon_version)
		return
	l11l111ll1ll_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ暑"))
	if not l11l111ll1ll_l1_ or now-int(l11l111ll1ll_l1_)>REGULAR_CACHE:
		#l1l1l1l111ll_l1_([main_dbfile,iptv1_dbfile,iptv2_dbfile])
		#settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭暒"),l1l1ll_l1_ (u"ࠩࠪ暓"))
		l1l11l1l11l_l1_ = l1l11l1l111_l1_(False)
	l111ll1ll1ll_l1_ = 0
	l11l1llll11l_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ暔"))
	if len(l11l1llll11l_l1_)==15:
		first,second,l1llll1ll_l1_ = l11l1llll11l_l1_[0:4],l11l1llll11l_l1_[4:9],l11l1llll11l_l1_[9:]
		first = int(first)^l1llll1l1_l1_
		second = int(second)^REGULAR_CACHE
		l1llll1ll_l1_ = int(l1llll1ll_l1_)^l11l1ll_l1_
		if first==second==l1llll1ll_l1_:
			l111ll1ll1ll_l1_ = first*60
			if l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪ暕")): l111ll1ll1ll_l1_ = l111ll1ll1ll_l1_*2
	l11ll111l1ll_l1_ = l1l1ll_l1_ (u"ࠬ࠷࠶ࠨ暖")+settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ暗"))
	if l11ll111l1ll_l1_: l11ll111l1ll_l1_ = int(l11ll111l1ll_l1_)^l1ll11ll11l_l1_
	if (not l11ll111l1ll_l1_ or not l111ll1ll1ll_l1_ or now-int(l11ll111l1ll_l1_)<=0 or now-int(l11ll111l1ll_l1_)>l111ll1ll1ll_l1_):
		if not l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨ暘")):
			# l1lll11l_l1_://l1l1ll1llll_l1_.l111lllll11l_l1_.l1lll1ll1_l1_/l111l11ll1l1_l1_/l11l1lll11ll_l1_
			# unescapeHTML(l1l1ll_l1_ (u"ࠨࠢࠩࠧࡽ࠸࠶࠴ࡄ࠾ࠤࠫࠩࡸ࠳࠹࠴ࡈࡀࠦࠦࠤࡺ࠵࠺࠷ࡇ࠻ࠡࠨࠦࡼ࠷࠼࠳ࡃ࠽ࠪ暙"))
			#l111llll11l1_l1_ = l1l1ll_l1_ (u"ࠩ⸾ࠤ⼢ࠦࠠ⾋ࠢࠣ⸮ࠥ⹁ࠧ暚")
			#l11l11l1111l_l1_ = l1l1ll_l1_ (u"ࠪ⸿ࠥ⼣ࠠࠡ⾍ࠣࠤⸯࠦ⸻ࠨ暛")
			l1l1lll1l111_l1_ = l1l1llll1ll1_l1_()
			if len(l1l1lll1l111_l1_)>1:
				LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ暜"),l1l1ll_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡬ࡴࡽࡩ࡯ࡩࠣࡕࡺ࡫ࡳࡵ࡫ࡲࡲࠥࠦࠠࡑࡣࡷ࡬࠿࡛ࠦࠡࠩ暝")+addon_path+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ暞"))
				id,l1l1ll111111_l1_,l1l1l1l1l1ll_l1_,answer,l1l11l1l11ll_l1_,reason = l1l1lll1l111_l1_[0]
				l1l1l11l1l1l_l1_,l1ll11111l1l_l1_ = answer.split(l1l1ll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ暟"))
				del l1l1lll1l111_l1_[0]
				l111l1llllll_l1_ = random.sample(l1l1lll1l111_l1_,1)
				id,l1l1ll111111_l1_,l1l1l1l1l1ll_l1_,answer,l1l11l1l11ll_l1_,reason = l111l1llllll_l1_[0]
				l1l1l1l1l1ll_l1_ = l1l1ll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠽ࠤࠬ暠")+id+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ暡")+l1l1l1l1l1ll_l1_
				button0,button1,l11l1l1ll111_l1_ = answer,l1l11l1l11ll_l1_,reason
				l11lll1l_l1_ = [button0,button1,l1l11l1l1l11_l1_]
				choice = -9
				while choice<0:
					l11ll11l11l1_l1_ = random.sample(l11lll1l_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࠫ暢"),l11ll11l11l1_l1_[0],l11ll11l11l1_l1_[1],l11ll11l11l1_l1_[2],l1l1l11l1l1l_l1_,l1l1l1l1l1ll_l1_,5,60)
					if choice==10: break
					if choice>=0 and l11ll11l11l1_l1_[choice]==l11lll1l_l1_[1]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠫࠬ暣"),l1l1ll_l1_ (u"ࠬ࠭暤"),l1l1ll_l1_ (u"ู้࠭ัฬࠫ暥"),l1l1ll_l1_ (u"ࠧࠨ暦"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ暧"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ฬ้ษหࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ暨")+l11l1l1ll111_l1_,10)
						if choice>=0: choice = -9
					elif choice>=0 and l11ll11l11l1_l1_[choice]==l11lll1l_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࠫ暩"),l1l1ll_l1_ (u"ࠫࠬ暪"),l1l11l1l1l11_l1_,l1l1ll_l1_ (u"ࠬ࠭暫"),l1l1l11l1l1l_l1_,l1l1l1l1l1ll_l1_+l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭暬")+l11lll1l_l1_[0]+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ暭"),30)
					if choice==-1: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ暮"),l1l1ll_l1_ (u"ࠩࠪ暯"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭暰"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣฮา๊ฯࠤำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่้ิั้ฮࠣห้฻อ๋ฯࠣวำะั๊ࠡสัิࠦๅ็ࠢส่ศา่ษหࠣห้๋ส้ใิอࠬ暱"))
				settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ暲"),str(now^l1ll11ll11l_l1_)[2:])
				WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ暳"),l1l1ll_l1_ (u"ࠧࡂࡗࡗࡌࠬ暴"),1,PERMANENT_CACHE)
			else: WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ暵"),l1l1ll_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ暶"),0,PERMANENT_CACHE)
		else:
			settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ暷"),str(now^l1ll11ll11l_l1_)[2:])
			WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ暸"),l1l1ll_l1_ (u"ࠬࡇࡕࡕࡊࠪ暹"),1,PERMANENT_CACHE)
	if l11l1l11ll1l_l1_: l1ll1l1lll11_l1_.l1l1ll1ll1l1_l1_(False)
	# l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ暺")	l11ll11lll1l_l1_ file to read/write the l11lll1ll1l_l1_ l1lll1l11l_l1_ list
	# l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ暻")		no l11ll111ll1_l1_ l111l11l1111_l1_ to the l11lll1ll1l_l1_ l1lll1l11l_l1_ list
	l1l1ll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡓࡊࡖࡈࡗࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡊࡖࡈࡗࡤࡓࡏࡅࡇࡖࠤࡦࡴࡤࠡ࡯ࡲࡨࡪ࠷࠽࠾࠻ࠐࠎࠎࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠳ࠤ࡮ࡴࠠ࡜࠳࠷࠹࠱࠻࠱࠷࠮࠸࠶࠸ࡣࠍࠋࠋࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡗࡎ࡚ࡅࡔࡡࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤࡔ࡚ࡈࡆࡔࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠏࠍࠍࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠵ࡁࡂ࠷࠶ࠡࡣࡱࡨࠥࡳ࡯ࡥࡧ࠳ࠥࡂ࠷࠶࠱ࠏࠍࠍ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠹ࡣࠍࠋࠋࠦࡲࡦࡳࡥࡠࠢࡀࠤࡈࡒࡅࡂࡐࡢࡑࡊࡔࡕࡠࡎࡄࡆࡊࡒࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡱࡥࡲ࡫࡟ࠡ࠿ࠣࡖࡊ࡙ࡔࡐࡔࡈࡣࡕࡇࡔࡉࡡࡑࡅࡒࡋࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡵࡲࠡࡔࡄࡒࡉࡕࡍࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࡣࡒࡋࡎࡖࡕࠐࠎࠎ࡯ࡦࠡࡔࡈࡑࡊࡓࡂࡆࡔࡢࡖࡊ࡙ࡕࡍࡖࡖࡣࡒࡕࡄࡆࡕ࠽ࠑࠏࠏࠉࠤ࡫ࡩࠤࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕ࠽ࠤࡨࡵ࡮ࡥ࠳ࠣࡁࠥ࠮࡭ࡦࡰࡸࡣࡱࡧࡢࡦ࡮ࠣ࡭ࡳ࡛ࠦࠨ࠰࠱ࠫ࠱࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩࡠ࠭ࠒࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࡀࠠࡤࡱࡱࡨ࠶ࠦ࠽ࠡࠪࡰࡩࡳࡻ࡟࡭ࡣࡥࡩࡱࠧ࠽࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࠌ࡭࡫ࠦࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫࠥ࡯࡮ࠡࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠠࡢࡰࡧࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡲࡡࡴࡶࡰࡩࡳࡻࡦࡪ࡮ࡨ࠭࠿ࠓࠊࠊࠋࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠰ࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡵ࡫࡮ࠩ࡮ࡤࡷࡹࡳࡥ࡯ࡷࡩ࡭ࡱ࡫ࠬࠨࡴࡥࠫ࠮࠴ࡲࡦࡣࡧࠬ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱ࡯ࡨࡋࡏࡌࡆ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚࡛࠻࡟ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡳࡱࡪࡆࡊࡎࡈ࠭ࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࠦࡗࡳ࡫ࡷ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡴࡨࡷࡺࡲࡴࡴࠢࡀࠤࡒࡇࡉࡏࡡࡇࡍࡘࡖࡁࡕࡅࡋࡉࡗ࠮ࡴࡺࡲࡨ࠰ࡳࡧ࡭ࡦࡡ࠯ࡹࡷࡲ࡟࠭࡯ࡲࡨࡪ࠲ࡩ࡮ࡣࡪࡩࡤ࠲ࡰࡢࡩࡨࡣ࠱ࡺࡥࡹࡶ࠯ࡧࡴࡴࡴࡦࡺࡷ࠰࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠯ࠍࠋࠋࠌࠍࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠࡴࡶࡵࠬࡲ࡫࡮ࡶࡋࡷࡩࡲࡹࡌࡊࡕࡗ࠭ࠒࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠ࡯ࡧࡺࡊࡎࡒࡅ࠯ࡧࡱࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠏࠍࠍࠎࠏ࡯ࡱࡧࡱࠬࡱࡧࡳࡵ࡯ࡨࡲࡺ࡬ࡩ࡭ࡧ࠯ࠫࡼࡨࠧࠪ࠰ࡺࡶ࡮ࡺࡥࠩࡰࡨࡻࡋࡏࡌࡆࠫࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡃࠠࡎࡃࡌࡒࡤࡊࡉࡔࡒࡄࡘࡈࡎࡅࡓࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩࡤ࠲ࡵࡳ࡮ࡢ࠰ࡲࡵࡤࡦ࠮࡬ࡱࡦ࡭ࡥࡠ࠮ࡳࡥ࡬࡫࡟࠭ࡶࡨࡼࡹ࠲ࡣࡰࡰࡷࡩࡽࡺࠬࡪࡰࡩࡳࡩ࡯ࡣࡵࠫࠐࠎࠎࠨࠢࠣ暼")
	results = l11lll111ll_l1_(type,l11ll11l1ll1_l1_,l111lll11l11_l1_,mode,l111l111l1l1_l1_,l11l111l1l11_l1_,text,context,infodict)
	# l111llll11l_l1_ l11ll1ll1l1l_l1_: succeeded,updateListing,cacheToDisc = True,False,True
	# updateListing = True => l1lllll11l11_l1_ this list is l111l1ll1l1l_l1_ and will exit to main l1lll1l11l_l1_
	# updateListing = False => l1lllll11l11_l1_ this list is l11l1ll1l1ll_l1_ and will exit to l11lll1ll1l_l1_ l1lll1l11l_l1_
	# cacheToDisc = True => will cause the l1111ll1l11l_l1_ status to l1111ll1ll1l_l1_ l111ll111111_l1_
	# cacheToDisc = False => will l111l1lll1ll_l1_ the l1111ll1l11l_l1_ status to l11l1ll111ll_l1_ l11l1l1l1l11_l1_
	#succeeded,updateListing,cacheToDisc = True,False,True
	#if not l11ll1lll11l_l1_: cacheToDisc = False
	if l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ暽") in text: updateListing = True
	if type==l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ暾"):
		if l11lll1111_l1_!=l1l1ll_l1_ (u"ࠫ࠳࠴ࠧ暿") and l11l1111llll_l1_: l11l1l11ll11_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬ࡯࡮ࡵࠩ曀"),l1l1ll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ曁"),l1l1ll_l1_ (u"ࠧࡂࡗࡗࡌࠬ曂")) or l111l1lllll1_l1_ not in l11l11lll11l_l1_) and not l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ曃")):
				import l1l11ll11l1_l1_
				DirectoryItems_List = GET_ALL_LIST_ITEMS(l1l11ll11l1_l1_.l1l11ll11ll_l1_)
				addItems_succeeded = CREATE_KODI_MENU(DirectoryItems_List,succeeded,updateListing,cacheToDisc)
				if 1 and l111ll1l11l1_l1_ and DirectoryItems_List:
					WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠧ曄"),l1111lllllll_l1_,DirectoryItems_List,REGULAR_CACHE)
				#elif 1 and not DirectoryItems_List:
				#	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ曅"),l1111lllllll_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l1ll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ曆")+addon_id+l1l1ll_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ曇"),xbmcgui.ListItem(l1l1ll_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ曈")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l1ll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ曉")+addon_id+l1l1ll_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ曊"),xbmcgui.ListItem(l1l1ll_l1_ (u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ曋")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
	return
def l11lll111ll_l1_(type,name,url,mode,image,page,text,context,infodict):
	l111l1lllll1_l1_ = int(mode)
	l11lllll111_l1_ = int(l111l1lllll1_l1_//10)
	if   l11lllll111_l1_==0:  import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==1:  import l11l11ll_l1_ 		; results = l11l11ll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==2:  import l1ll111l111_l1_ 		; results = l1ll111l111_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==3:  import l1l1111ll1l_l1_ 		; results = l1l1111ll1l_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==4:  import l1ll11l11_l1_ 	; results = l1ll11l11_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==5:  import l1l111l1l11l_l1_ 	; results = l1l111l1l11l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==6:  import l1ll1llll_l1_ 	; results = l1ll1llll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==7:  import l1l1l1l_l1_ 		; results = l1l1l1l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==8:  import l1ll111l11l_l1_ 	; results = l1ll111l11l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==9:  import l1lll1l1l1_l1_		; results = l1lll1l1l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==10: import l1l1l1l1l11_l1_ 		; results = l1l1l1l1l11_l1_.MAIN(l111l1lllll1_l1_,url)
	elif l11lllll111_l1_==11: import l1lll11111l1_l1_ 	; results = l1lll11111l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==12: import l1111llll1_l1_ 		; results = l1111llll1_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==13: import l1ll11l1l_l1_	; results = l1ll11l1l_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==14: import l11l1l1l11l_l1_ 		; results = l11l1l1l11l_l1_.MAIN(l111l1lllll1_l1_,url,text,type,page,name,image)
	elif l11lllll111_l1_==15: import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==16: import l11ll1l111l_l1_	 	; results = l11ll1l111l_l1_.MAIN(l111l1lllll1_l1_,url,text,page,infodict)
	elif l11lllll111_l1_==17: import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==18: import l1l111lll11_l1_	; results = l1l111lll11_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==19: import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==20: import l11l1l1l1_l1_		; results = l11l1l1l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==21: import l111l1l1lll_l1_ ; results = l111l1l1lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==22: import l1lllll1111_l1_ 	; results = l1lllll1111_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==23: import IPTV 		; results = IPTV.MAIN(l111l1lllll1_l1_,url,text,type,page,infodict)
	elif l11lllll111_l1_==24: import l11llll_l1_ 		; results = l11llll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==25: import l11lll111_l1_ 	; results = l11lll111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==26: import l1l11ll11l1_l1_ 		; results = l1l11ll11l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l111l1lllll1_l1_,context)
	elif l11lllll111_l1_==28: import IPTV 		; results = IPTV.MAIN(l111l1lllll1_l1_,url,text,type,page,infodict)
	elif l11lllll111_l1_==29: import l11lll11lll1_l1_	; results = l11lll11lll1_l1_.MAIN(l111l1lllll1_l1_,url,page,text)
	elif l11lllll111_l1_==30: import l1lll11l11_l1_		; results = l1lll11l11_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==31: import l1l111ll1lll_l1_	; results = l1l111ll1lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==32: import l1l1lll1111_l1_	; results = l1l1lll1111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==33: import l11l1ll1l1_l1_		; results = l11l1ll1l1_l1_.MAIN(l111l1lllll1_l1_,url)
	elif l11lllll111_l1_==34: import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==35: import l1ll111l_l1_		; results = l1ll111l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==36: import l1l1111lll1_l1_		; results = l1l1111lll1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==37: import l111l1ll1_l1_		; results = l111l1ll1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==38: import l1l111l1111_l1_ 		; results = l1l111l1111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==39: import l1ll1lll1ll_l1_	; results = l1ll1lll1ll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==40: import l1l1111ll1_l1_	; results = l1l1111ll1_l1_.MAIN(l111l1lllll1_l1_,url,text,type,page)
	elif l11lllll111_l1_==41: import l1l1111ll1_l1_	; results = l1l1111ll1_l1_.MAIN(l111l1lllll1_l1_,url,text,type,page)
	elif l11lllll111_l1_==42: import l1111ll1l_l1_		; results = l1111ll1l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==43: import l1llll11ll1_l1_		; results = l1llll11ll1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==44: import l1llll11lll_l1_		; results = l1llll11lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==45: import l1l1l1l111l_l1_		; results = l1l1l1l111l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==46: import l111111l111_l1_		; results = l111111l111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==47: import l1lll11l1l_l1_	; results = l1lll11l1l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==48: import l1ll1ll11lll_l1_		; results = l1ll1ll11lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==49: import l1llll11l1_l1_		; results = l1llll11l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==50: import l1ll1l1lll11_l1_ 	; results = l1ll1l1lll11_l1_.MAIN(l111l1lllll1_l1_,text)
	elif l11lllll111_l1_==51: import l1lll1l1lll_l1_ 	; results = l1lll1l1lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==52: import l1lll1l1lll_l1_ 	; results = l1lll1l1lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==53: import l1l11ll11l1_l1_ 		; results = l1l11ll11l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==54: import l1lll1ll111_l1_	; results = l1lll1ll111_l1_.MAIN(l111l1lllll1_l1_,url,text,page)
	elif l11lllll111_l1_==55: import l1llll1lll_l1_ 	; results = l1llll1lll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==56: import l1lll111l111_l1_		; results = l1lll111l111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==57: import l1ll1lll11l_l1_		; results = l1ll1lll11l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==58: import l1l111llll11_l1_	; results = l1l111llll11_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==59: import l1ll1ll11l1_l1_		; results = l1ll1ll11l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==60: import l1ll1ll1111_l1_		; results = l1ll1ll1111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==61: import l1lllll_l1_		; results = l1lllll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==62: import l1ll1llll1l_l1_		; results = l1ll1llll1l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==63: import l1llll11ll_l1_		; results = l1llll11ll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==64: import l1l111ll1l11_l1_		; results = l1l111ll1l11_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==65: import l1111llll_l1_		; results = l1111llll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==66: import l1l1111lllll_l1_		; results = l1l1111lllll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==67: import l1l1ll1l11l_l1_		; results = l1l1ll1l11l_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==68: import l11l11llll_l1_		; results = l11l11llll_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==69: import l1111lll1_l1_		; results = l1111lll1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==70: import l1l1l1ll111_l1_		; results = l1l1l1ll111_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==71: import l1l1l11l1l1_l1_			; results = l1l1l11l1l1_l1_.MAIN(l111l1lllll1_l1_,url,text,type,page,infodict)
	elif l11lllll111_l1_==72: import l1l1l11l1l1_l1_			; results = l1l1l11l1l1_l1_.MAIN(l111l1lllll1_l1_,url,text,type,page,infodict)
	elif l11lllll111_l1_==73: import l1l1ll1l1_l1_	; results = l1l1ll1l1_l1_.MAIN(l111l1lllll1_l1_,url,text)
	elif l11lllll111_l1_==74: import l1ll11111l_l1_		; results = l1ll11111l_l1_.MAIN(l111l1lllll1_l1_)
	elif l11lllll111_l1_==75: import l1ll11111l_l1_		; results = l1ll11111l_l1_.MAIN(l111l1lllll1_l1_)
	else: results = None
	return results
def l11ll1l1ll_l1_(name=l1l1ll_l1_ (u"ࠪࠫ曌")):
	if not name: name = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ曍"))
	name = name.replace(l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ曎"),l1l1ll_l1_ (u"࠭ࠧ曏"))
	name = name.replace(l1l1ll_l1_ (u"ࠧࠡࠢࠣࠤࠬ曐"),l1l1ll_l1_ (u"ࠨࠢࠪ曑")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠥ࠭曒"),l1l1ll_l1_ (u"ࠪࠤࠬ曓")).replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧ曔"),l1l1ll_l1_ (u"ࠬࠦࠧ曕")).strip(l1l1ll_l1_ (u"࠭ࠠࠨ曖"))
	name = name.replace(l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ曗"),l1l1ll_l1_ (u"ࠨࠩ曘")).replace(l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ曙"),l1l1ll_l1_ (u"ࠪࠫ曚"))
	tmp = re.findall(l1l1ll_l1_ (u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠࠨ曛"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l1ll_l1_ (u"ࠬࡓࡡࡪࡰࠣࡑࡪࡴࡵࠨ曜")
	return name
def SHOW_NETWORK_ERRORS(code,reason,source,showDialogs):
	if l1l1ll_l1_ (u"࠭࠭ࠨ曝") in source: site = source.split(l1l1ll_l1_ (u"ࠧ࠮ࠩ曞"),1)[0]
	else: site = source
	l11ll11l1lll_l1_ = code in [7,11001,11002,10054]
	l1111ll1ll11_l1_ = reason.lower()
	l11l11111111_l1_ = code in [0,104,10061,111]
	l111llllllll_l1_ = l1l1ll_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ曟") in l1111ll1ll11_l1_
	l111lllllll1_l1_ = l1l1ll_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ曠") in l1111ll1ll11_l1_
	l111llllll1l_l1_ = l1l1ll_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ曡") in l1111ll1ll11_l1_
	l111llllll11_l1_ = l1l1ll_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭曢") in l1111ll1ll11_l1_
	proxy_status = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ曣"))
	dns_status = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭曤"))
	l11l11ll11ll_l1_ = l1l1ll_l1_ (u"ࠧโึ็ࠤอูอษࠢสฺ่็อส่๊ࠢࠥอไฦ่อี๋ะࠧ曥")
	l111lll1l1l1_l1_ = l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠨ曦")+str(code)+l1l1ll_l1_ (u"ࠩ࠽ࠤࠬ曧")+reason
	if l11l11111111_l1_ or l111llllllll_l1_ or l111lllllll1_l1_ or l111llllll1l_l1_ or l111llllll11_l1_:
		l11l11ll11ll_l1_ += l1l1ll_l1_ (u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ曨")
	if l11ll11l1lll_l1_: l11l11ll11ll_l1_ += l1l1ll_l1_ (u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ曩")
	l111lll1l1l1_l1_ = l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ曪")+l111lll1l1l1_l1_+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ曫")
	if proxy_status==l1l1ll_l1_ (u"ࠧࡂࡕࡎࠫ曬") or dns_status==l1l1ll_l1_ (u"ࠨࡃࡖࡏࠬ曭"):
		l11l11ll11ll_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤศีๆศ้ࠣรࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭曮")
	trytofix = False
	if showDialogs:
		if proxy_status==l1l1ll_l1_ (u"ࠪࡅࡘࡑࠧ曯") or dns_status==l1l1ll_l1_ (u"ࠫࡆ࡙ࡋࠨ曰"):
			#if kodi_version<19: l111lll1l1l1_l1_ = l111lll1l1l1_l1_.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ曱"))
			trytofix = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭曲"),l1l1ll_l1_ (u"ࠧࠨ曳"),l1l1ll_l1_ (u"ࠨࠩ更"),site+l1l1ll_l1_ (u"ࠩࠣࠤࠥ࠭曵")+TRANSLATE(site),l11l11ll11ll_l1_,l111lll1l1l1_l1_)
		else: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ曶"),l1l1ll_l1_ (u"ࠫࠬ曷"),site+l1l1ll_l1_ (u"ࠬࠦࠠࠡࠩ書")+TRANSLATE(site),l11l11ll11ll_l1_,l111lll1l1l1_l1_)
	if reason.endswith(l1l1ll_l1_ (u"࠭ࠠࠪࠩ曹")): reason = reason.rsplit(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ曺"))[0]
	#if trytofix: LOG_THIS(l1l1ll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭曻"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ曼")+str(code)+l1l1ll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ曽")+reason+l1l1ll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭曾")+source+l1l1ll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡅࡗࡇࡂࡊࡅ࠽ࠤࡠࠦࠧ替")+l11l11ll11ll_l1_+l1l1ll_l1_ (u"࠭ࠠ࡞࡟ࠣࠤࠥࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ最")+l111lll1l1l1_l1_+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ朁"))
	return trytofix
	l1l1ll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡧࡲࡸࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠴ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠳ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠹࠺ࠎࠌࠌࠍࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨ่๋฽๋ࠥๆࠡษ็ััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆ࠲ࠬࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥ࠱࠽๋้ࠡࠩࠣࠦสา์าࠤฯ็วึ์็ࠤฬ้หาࠢยࠫࠒࠐࠉࠊ࡫ࡩࠤࡩࡴࡳ࠻ࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽ࠡࠩ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄࠢ࠮ࡁ้ࠥ࠭ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽๊ࠡࠩิฬࠦวๅ็๋ๆ฾ࠦแ๋้ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡰࡷࡵࡧࡪ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠰࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠏࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲ࡳࡪࡶࡨ࠯ࠬࠦࠠࠡࠩ࠮ࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠮ࡳࡪࡶࡨ࠭࠱ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠱࠻ࠢ࡬ࡱࡵࡵࡲࡵࠢࡖࡉࡗ࡜ࡉࡄࡇࡖࠤࡀࠦࡓࡆࡔ࡙ࡍࡈࡋࡓ࠯ࡏࡄࡍࡓ࠮࠱࠺࠷ࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠐࠎࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠠ࠾ࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤ࠳ࠦ็ๅࠢอี๏ีࠠๆ฻ิๅฮࠦวๅลึฬฬฮ้ࠠษ็ั้๎ไࠡมࠪࠑࠏࠏࠉࡺࡧࡶࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥ࡙ࡆࡕࡑࡓ࠭࠭ࡣࡦࡰࡷࡩࡷ࠭ࠬࡴ࡫ࡷࡩ࠰࠭ࠠࠡࠢࠪ࠯࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋࠨࡴ࡫ࡷࡩ࠮࠲࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠲࠼ࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠿ࠣࠫ็ี๋ࠠๅ๋๊ࠥํๆศๅ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢ฼๊ิ้ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤ๊็ี้ๆฬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠๅษࠣ๎฾๋ไࠡ฻้ำ่࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํีࠥํะ่ࠢสฺ่็อส๋ࠢห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࡠࡳ࠭ࠫࠨฮิฬ๋ࠥำฮࠢส่่อิ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠำๅࠤึ็ูࠡษ็ััฮࠠࠩ็ฮ่ฬࠦࡖࡑࡐࠣ࠰ࠥࡖࡲࡰࡺࡼࠤ࠱ࠦࡄࡏࡕࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ไษ๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศฯๅหࠬࠓࠊࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡘࡊ࡞ࡔࡗࡋࡈ࡛ࡊࡘࠨࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗ࠮ࠓࠊࠊࠤࠥࠦ朂")
def l1l1l1l111ll_l1_(l111l1111ll1_l1_=False):
	l11l11ll1lll_l1_ = [l1l11l11ll1_l1_,favoritesfile,l1ll1111lll1_l1_]
	for filename in os.listdir(addoncachefolder):
		if l111l1111ll1_l1_ and (filename.startswith(l1l1ll_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ會")) or filename.startswith(l1l1ll_l1_ (u"ࠪࡱ࠸ࡻࠧ朄"))): continue
		if filename.startswith(l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪ朅")): continue
		l1l1l111lll_l1_ = os.path.join(addoncachefolder,filename)
		if l1l1l111lll_l1_ in l11l11ll1lll_l1_: continue
		try: os.remove(l1l1l111lll_l1_)
		except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(kodipath=addon_path):
	l11l1ll1lll1_l1_ = {l1l1ll_l1_ (u"ࠬࡺࡹࡱࡧࠪ朆"):l1l1ll_l1_ (u"࠭ࠧ朇"),l1l1ll_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ月"):l1l1ll_l1_ (u"ࠨࠩ有"),l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭朊"):l1l1ll_l1_ (u"ࠪࠫ朋"),l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ朌"):l1l1ll_l1_ (u"ࠬ࠭服"),l1l1ll_l1_ (u"࠭ࡰࡢࡩࡨࠫ朎"):l1l1ll_l1_ (u"ࠧࠨ朏"),l1l1ll_l1_ (u"ࠨࡰࡤࡱࡪ࠭朐"):l1l1ll_l1_ (u"ࠩࠪ朑"),l1l1ll_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ朒"):l1l1ll_l1_ (u"ࠫࠬ朓"),l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭朔"):l1l1ll_l1_ (u"࠭ࠧ朕"),l1l1ll_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ朖"):l1l1ll_l1_ (u"ࠨࠩ朗")}
	if l1l1ll_l1_ (u"ࠩࡂࠫ朘") in kodipath: kodipath = kodipath.split(l1l1ll_l1_ (u"ࠪࡃࠬ朙"),1)[1]
	url2,l11l1ll1ll1l_l1_ = URLDECODE(kodipath)
	args = dict(list(l11l1ll1lll1_l1_.items())+list(l11l1ll1ll1l_l1_.items()))
	l111l1ll1l11_l1_ = args[l1l1ll_l1_ (u"ࠫࡲࡵࡤࡦࠩ朚")]
	l111lll11l11_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ望")])
	l11ll11l1l1l_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"࠭ࡴࡦࡺࡷࠫ朜")])
	l11l111l1l11_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠧࡱࡣࡪࡩࠬ朝")])
	type_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠨࡶࡼࡴࡪ࠭朞")])
	l11ll11l1ll1_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ期")])
	l111l111l1l1_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ朠")])
	l111ll11llll_l1_ = args[l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ朡")]
	l111ll1lllll_l1_ = UNQUOTE(args[l1l1ll_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ朢")])
	if l111ll1lllll_l1_: l111ll1lllll_l1_ = eval(l111ll1lllll_l1_)
	else: l111ll1lllll_l1_ = {}
	#name = xbmc.getInfoLabel(l1l1ll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ朣"))
	#image = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ朤"))
	if not l111l1ll1l11_l1_: type_ = l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ朥") ; l111l1ll1l11_l1_ = l1l1ll_l1_ (u"ࠩ࠵࠺࠵࠭朦")
	return type_,l11ll11l1ll1_l1_,l111lll11l11_l1_,l111l1ll1l11_l1_,l111l111l1l1_l1_,l11l111l1l11_l1_,l11ll11l1l1l_l1_,l111ll11llll_l1_,l111ll1lllll_l1_
def l111lll11ll1_l1_(proxy,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix=True,allow_proxy_fix=True):
	l111l11lllll_l1_,l111lll1l111_l1_ = proxy.split(l1l1ll_l1_ (u"ࠪ࠾ࠬ朧"))
	#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ木"),l1l1ll_l1_ (u"ูࠬรอำหࠤࠬ朩")+name,time=2000)
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭未"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ末")+name+l1l1ll_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ本")+proxy+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ札")+url+l1l1ll_l1_ (u"ࠪࠤࡢ࠭朮"))
	url = url+l1l1ll_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ术")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,showDialogs,source,allow_dns_fix,allow_proxy_fix)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ朰"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ朱")+name+l1l1ll_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭朲")+proxy+l1l1ll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ朳")+url+l1l1ll_l1_ (u"ࠩࠣࡡࠬ朴"))
		FORCED_EXIT(l1l1ll_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ朵"))
	#else: LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ朶"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ朷")+proxy+l1l1ll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ朸")+url+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ朹"))
	return response
def l111l111l111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ机"),url,l1l1ll_l1_ (u"ࠩࠪ朻"),l1l1ll_l1_ (u"ࠪࠫ朼"),True,False,l1l1ll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬ朽"),True,False)
	l11lll11ll11_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l1111l1l_l1_
		l111ll111lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠦࠨ࠯ࠬࡂ࠭ࠥࡢࡤࡼ࠳࠯࠷ࢂࡳࡳࠨ朾"),html)
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ朿"),str(l111ll111lll_l1_))
		if l111ll111lll_l1_: html = l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ杀").join(l111ll111lll_l1_)
		proxies = html.replace(l1l1ll_l1_ (u"ࠨ࡞ࡵࠫ杁"),l1l1ll_l1_ (u"ࠩࠪ杂")).strip(l1l1ll_l1_ (u"ࠪࡠࡳ࠭权")).split(l1l1ll_l1_ (u"ࠫࡡࡴࠧ杄"))
		l11lll11ll11_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l1ll_l1_ (u"ࠬ࠴ࠧ杅"))==3: l11lll11ll11_l1_.append(proxy)
	return l11lll11ll11_l1_
def OPENURL_REQUESTS_PROXIES(*args):
	#l111ll1l1111_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠴࠶࠰࠶࠷࠳࠷࠷࠯࠳࠵࠻࠴ࡧࡰࡪ࠱ࡳࡶࡴࡾࡹࡀࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡸࡶࡥࡦࡦࡀ࠵࠵ࠬ࡬ࡢࡵࡷࡣࡨ࡮ࡥࡤ࡭ࡀ࠵࠵ࠬࡨࡵࡶࡳࡷࡂࡺࡲࡶࡧࠩࡴࡴࡹࡴ࠾ࡶࡵࡹࡪࠬࡦࡰࡴࡰࡥࡹࡃࡴࡹࡶࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ杆")
	l11ll1llll11_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ杇")
	l11l11111l11_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬ杈")
	#l11l1l1l111l_l1_ = l111l111l111_l1_(l111ll1l1111_l1_)
	l11l1l1l111l_l1_ = l111l111l111_l1_(l11l11111l11_l1_)
	l11lll11ll11_l1_ = l111l111l111_l1_(l11ll1llll11_l1_)
	l11lll11l111_l1_ = l11l1l1l111l_l1_+l11lll11ll11_l1_
	LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ杉"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩ杊")+str(len(l11l1l1l111l_l1_))+l1l1ll_l1_ (u"ࠫ࠰࠭杋")+str(len(l11lll11ll11_l1_))+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ杌"))
	proxy = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭杍"))
	response = empty_response()
	settings.setSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ李"),l1l1ll_l1_ (u"ࠨࠩ杏"))
	if proxy or l11lll11l111_l1_:
		id,timeout = 0,10
		l111l11l1l1l_l1_ = len(l11lll11l111_l1_)
		l11l1lll111l_l1_ = timeout
		if l111l11l1l1l_l1_>l11l1lll111l_l1_: counts = l11l1lll111l_l1_
		else: counts = l111l11l1l1l_l1_
		l11ll11l111l_l1_ = random.sample(l11lll11l111_l1_,counts)
		if proxy: l11ll11l111l_l1_ = [proxy]+l11ll11l111l_l1_
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ材"),str(l11ll11l111l_l1_))
		threads = l111ll11lll_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l11ll111ll1l_l1_:
			if id<counts:
				proxy = l11ll11l111l_l1_[id]
				threads.start_new_thread(id,l111lll11ll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ村"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭杒")+proxy+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ杓"))
		l11ll111ll1l_l1_ = threads.l11ll111ll1l_l1_
		if l11ll111ll1l_l1_:
			l11l11ll1l1l_l1_ = threads.l11l11ll1l1l_l1_
			l11l11l11lll_l1_ = l11ll111ll1l_l1_[0]
			response = l11l11ll1l1l_l1_[l11l11l11lll_l1_]
			proxy = l11ll11l111l_l1_[int(l11l11l11lll_l1_)]
			settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭杔"),proxy)
			if l11l11l11lll_l1_!=0: LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭杕"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡘࡻࡣࡤࡧࡶࡷ࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ杖")+proxy+l1l1ll_l1_ (u"ࠩࠣࡡࠬ杗"))
			else: LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ杘"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭杙")+proxy+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ杚"))
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭杛"),l1l1ll_l1_ (u"ࠧࡱࡴࡲࡼ࡮࡫ࡳࡍࡋࡖࡘ࠷ࠦ࠺࠻ࠢࠪ杜")+str(l11ll11l111l_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ杝"),l1l1ll_l1_ (u"ࠩࡳࡶࡴࡾࡩࡦࡵࡏࡍࡘ࡚ࠠ࠻࠼ࠣࠫ杞")+str(l11lll11l111_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ束"),l1l1ll_l1_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ杠")+str(threads.l11ll111ll1l_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ条"),l1l1ll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ杢")+str(threads.l11lll11ll1l_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ杣"),l1l1ll_l1_ (u"ࠨࡴࡨࡷࡺࡲࡴࡴࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ杤")+str(threads.l11l11ll1l1l_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ来"),l1l1ll_l1_ (u"ࠪࡩࡱࡶࡡࡴࡧࡧࡸ࡮ࡳࡥࡅࡋࡆࡘࠥࡀ࠺ࠡࠩ杦")+str(threads.l11ll1lll1ll_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ杧"),l1l1ll_l1_ (u"ࠬࡹ࡯ࡳࡶࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭杨")+str(l111111ll1l_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭杩"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠫ杪")+l111l111ll1l_l1_+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠬ杫")+str(l111111ll1l_l1_))
	return response
def USE_DNS_SERVER(connection,dns_server):
	original_create_connection = connection.create_connection
	def l111l1l11lll_l1_(address,*args,**kwargs):
		host,port = address
		l1lll1l1111l_l1_ = DNS_RESOLVER(host,dns_server)
		if l1lll1l1111l_l1_: host = l1lll1l1111l_l1_[0]
		else:
			if dns_server in l1l11l111l11_l1_: l1l11l111l11_l1_.remove(dns_server)
			if l1l11l111l11_l1_:
				l111ll1111l1_l1_ = l1l11l111l11_l1_[0]
				#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ杬"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥ࡝ࡩ࡭࡮ࠣࡸࡷࡿࠠࡵࡪࡨࠤࡴࡺࡨࡦࡴࠣࡈࡓ࡙࠺࡜ࠢࠪ杭")+l111ll1111l1_l1_+l1l1ll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡳࡸࡺ࠺࡜ࠢࠪ杮")+str(host)+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ杯"))
				l1lll1l1111l_l1_ = DNS_RESOLVER(host,l111ll1111l1_l1_)
				if l1lll1l1111l_l1_: host = l1lll1l1111l_l1_[0]
		address = (host,port)
		return original_create_connection(address,*args,**kwargs)
	connection.create_connection = l111l1l11lll_l1_
	return original_create_connection
def l1lll11111_l1_(expiry,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡳࡵࡴࠪ杰"),l1l1ll_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ東"),(method,url,data,headers,source))
	if html:
		LOG_OPENURL(True,url,data,headers,source,l1l1ll_l1_ (u"ࠨࠩ杲"))
		return html
	html = l1llllll11_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪ杳"),(method,url,data,headers,source),html,expiry)
	return html
def l1llllll11_l1_(method,url,data=l1l1ll_l1_ (u"ࠪࠫ杴"),headers=l1l1ll_l1_ (u"ࠫࠬ杵"),source=l1l1ll_l1_ (u"ࠬ࠭杶")):
	LOG_OPENURL(False,url,data,headers,source,l1l1ll_l1_ (u"࠭ࠧ杷"))
	if kodi_version>18.99: import urllib.request as l111l11l1ll1_l1_
	else: import urllib2 as l111l11l1ll1_l1_
	if not headers: headers = {l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ杸"):l1l1ll_l1_ (u"ࠨࠩ杹")}
	if not data: data = {}
	if method==l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭杺"):
		url = url+l1l1ll_l1_ (u"ࠪࡃࠬ杻")+l1lll1l11_l1_(data)
		data = None
	try:
		req = l111l11l1ll1_l1_.Request(url,headers=headers,data=data)
		http_response = l111l11l1ll1_l1_.urlopen(req)
		html = http_response.read()
	except: html = l1l1ll_l1_ (u"ࠫࠬ杼")
	#try:
	#	req = l111l11l1ll1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l111l11l1ll1_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l1l1ll_l1_ (u"ࠬ࠭杽")
	return html
def l1111ll1llll_l1_(url):
	l11ll11llll1_l1_,l11l1l11l11l_l1_ = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ松"))[2],80
	if l1l1ll_l1_ (u"ࠧ࠻ࠩ板") in l11ll11llll1_l1_: l11ll11llll1_l1_,l11l1l11l11l_l1_ = l11ll11llll1_l1_.split(l1l1ll_l1_ (u"ࠨ࠼ࠪ枀"))
	l111l11l11ll_l1_ = l1l1ll_l1_ (u"ࠩ࠲ࠫ极")+l1l1ll_l1_ (u"ࠪ࠳ࠬ枂").join(url.split(l1l1ll_l1_ (u"ࠫ࠴࠭枃"))[3:])
	request = l1l1ll_l1_ (u"ࠬࡍࡅࡕࠢࠪ构")+l111l11l11ll_l1_+l1l1ll_l1_ (u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭枅")
	#request += l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷ࠾ࠥࡢࡲ࡝ࡰࠪ枆")
	request += l1l1ll_l1_ (u"ࠨࡊࡲࡷࡹࡀࠠࠨ枇")+l11ll11llll1_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ枈")
	request += l1l1ll_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ枉")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l11ll11llll1_l1_,l11l1l11l11l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l1ll_l1_ (u"ࠫࠬ枊")
	return html
def SERVER(link,type):
	# url:	http://l1l1ll1llll_l1_.l11l1l1ll11l_l1_.l1lll1ll1_l1_
	# host:	l1l1ll1llll_l1_.l11l1l1ll11l_l1_.l1lll1ll1_l1_
	# name:	l11l1l1ll11l_l1_
	#server = l1l1ll_l1_ (u"ࠬ࠵ࠧ枋").join(link.split(l1l1ll_l1_ (u"࠭࠯ࠨ枌"))[:3])
	if l1l1ll_l1_ (u"ࠧ࠯ࠩ枍") not in link: return link
	link = link+l1l1ll_l1_ (u"ࠨ࠱ࠪ枎")
	part1,part2 = link.split(l1l1ll_l1_ (u"ࠩ࠱ࠫ枏"),1)
	l111l1l1l1ll_l1_,l111l1l1l1l1_l1_ = part2.split(l1l1ll_l1_ (u"ࠪ࠳ࠬ析"),1)
	server = part1+l1l1ll_l1_ (u"ࠫ࠳࠭枑")+l111l1l1l1ll_l1_
	if type in [l1l1ll_l1_ (u"ࠬ࡮࡯ࡴࡶࠪ枒"),l1l1ll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ枓")] and l1l1ll_l1_ (u"ࠧ࠰ࠩ枔") in server: server = server.rsplit(l1l1ll_l1_ (u"ࠨ࠱ࠪ枕"),1)[1]
	if type==l1l1ll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ枖") and l1l1ll_l1_ (u"ࠪ࠲ࠬ林") in server:
		l111l11llll1_l1_ = server.split(l1l1ll_l1_ (u"ࠫ࠳࠭枘"))
		length = len(l111l11llll1_l1_)
		if length<=2 or l1l1ll_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ枙") in server: l111l11llll1_l1_ = l111l11llll1_l1_[0]
		elif length>=3: l111l11llll1_l1_ = l111l11llll1_l1_[1]
		if len(l111l11llll1_l1_)>1: server = l111l11llll1_l1_
	return server
	l1l1ll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࠬ࠵ࠧࠬࡷࡵࡰ࠷࠱ࠧ࠰ࠩࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡮ࡦࡶ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣࡰ࡯࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡯ࡳࡩ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡸࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡵࡸ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡷࡴ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡲ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡵࡹ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡤࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩࠎࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡶࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡩ࡬ࡶࡤ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴࡬ࡪࡨࡨ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡮ࡺ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡩ࡯࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡽࡷࡸ࠰ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡳ࠮ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡩࡲࡨࡥࡥ࠰ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࠧࠨࠢ枚")
def l11ll1ll11l_l1_(l11lll1lll11_l1_):
	l11lll1l11ll_l1_ = repr(l11lll1lll11_l1_.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ枛"))).replace(l1l1ll_l1_ (u"ࠣࠩࠥ果"),l1l1ll_l1_ (u"ࠩࠪ枝"))
	return l11lll1l11ll_l1_
def l1l1ll11111_l1_(string):
	#if l1l1ll_l1_ (u"ࠪࡠࡺ࠭枞") in string:
	#	string = string.decode(l1l1ll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ枟"))
	#	l11l111l11ll_l1_=re.findall(l1l1ll_l1_ (u"ࡷ࠭࡜ࡶ࡝࠳࠱࠾ࡇ࠭ࡇ࡟ࠪ枠"),string)
	#	for unicode in l11l111l11ll_l1_
	#		char = l1111l1llll1_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ枡"))
	l1111lllll1l_l1_ = l1l1ll_l1_ (u"ࠧࠨ枢")
	if kodi_version<19: string = string.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭枣"))
	import unicodedata
	for l1l1l1llll1_l1_ in string:
		if   l1l1l1llll1_l1_==l1l1ll_l1_ (u"ࡷࠪฦࠬ枤"): l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫ枥")
		elif l1l1l1llll1_l1_==l1l1ll_l1_ (u"ࡹࠬษࠧ枦"): l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭枧")
		elif l1l1l1llll1_l1_==l1l1ll_l1_ (u"ࡻࠧลࠩ枨"): l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨ枩")
		elif l1l1l1llll1_l1_==l1l1ll_l1_ (u"ࡶࠩศࠫ枪"): l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪ枫")
		elif l1l1l1llll1_l1_==l1l1ll_l1_ (u"ࡸࠫห࠭枬"): l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬ枭")
		else:
			l1111l1ll1l1_l1_ = unicodedata.decomposition(l1l1l1llll1_l1_)
			if l1l1ll_l1_ (u"ࠬࠦࠧ枮") in l1111l1ll1l1_l1_: l11l1lll1lll_l1_ = l1l1ll_l1_ (u"࠭࡜࡝ࡷࠪ枯")+l1111l1ll1l1_l1_.split(l1l1ll_l1_ (u"ࠧࠡࠩ枰"),1)[1]
			else:
				l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠨ࠲࠳࠴࠵࠭枱")+hex(ord(l1l1l1llll1_l1_)).replace(l1l1ll_l1_ (u"ࠩ࠳ࡼࠬ枲"),l1l1ll_l1_ (u"ࠪࠫ枳"))
				l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠫࡡࡢࡵࠨ枴")+l11l1lll1lll_l1_[-4:]
			#if ord(l1l1l1llll1_l1_)<256: l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳ࠫ枵")+l111l11lll11_l1_
			#elif ord(l1l1l1llll1_l1_)<4096: l11l1lll1lll_l1_ = l1l1ll_l1_ (u"࠭࡜࡝ࡷ࠳ࠫ架")+l111l11lll11_l1_
			#elif l1l1ll_l1_ (u"ࠧࠡࠩ枷") in l1111l1ll1l1_l1_: l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠨ࡞࡟ࡹࠬ枸")+l1111l1ll1l1_l1_.split(l1l1ll_l1_ (u"ࠩࠣࠫ枹"),1)[1]
			#else: l11l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠪࡠࡡࡻࠧ枺")+l111l11lll11_l1_
		l1111lllll1l_l1_ += l11l1lll1lll_l1_
	l1111lllll1l_l1_ = l1111lllll1l_l1_.replace(l1l1ll_l1_ (u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬ枻"),l1l1ll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭枼"))
	if kodi_version<19: l1111lllll1l_l1_ = l1111lllll1l_l1_.decode(l1l1ll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ枽")).encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ枾"))
	else: l1111lllll1l_l1_ = l1111lllll1l_l1_.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭枿")).decode(l1l1ll_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ柀"))
	return l1111lllll1l_l1_
def OPEN_KEYBOARD(header=l1l1ll_l1_ (u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪ柁"),default=l1l1ll_l1_ (u"ࠫࠬ柂"),l11l1ll1llll_l1_=False):
	text = l111ll111ll1_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ柃"),l1l1ll_l1_ (u"࠭ࠠࠨ柄")).replace(l1l1ll_l1_ (u"ࠧࠡࠢࠪ柅"),l1l1ll_l1_ (u"ࠨࠢࠪ柆")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠬ柇"),l1l1ll_l1_ (u"ࠪࠤࠬ柈"))
	if not text and not l11l1ll1llll_l1_:
		LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ柉"),l1l1ll_l1_ (u"ࠬ࠴ࠠࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪ柊")+text+l1l1ll_l1_ (u"࠭ࠢࠨ柋"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ柌"),l1l1ll_l1_ (u"ࠨࠩ柍"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ柎"),l1l1ll_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦััห้࠭柏"))
		return l1l1ll_l1_ (u"ࠫࠬ某")
	if text not in [l1l1ll_l1_ (u"ࠬ࠭柑"),l1l1ll_l1_ (u"࠭ࠠࠨ柒")]:
		text = text.strip(l1l1ll_l1_ (u"ࠧࠡࠩ染"))
		text = l1l1ll11111_l1_(text)
	if l1l1111_l1_(l1l1ll_l1_ (u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪ柔"),l1l1ll_l1_ (u"ࠩࠪ柕"),[text],False):
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ柖"),l1l1ll_l1_ (u"ࠫ࠳ࠦࠠࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨ柗")+text+l1l1ll_l1_ (u"ࠬࠨࠧ柘"))
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ柙"),l1l1ll_l1_ (u"ࠧࠨ柚"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ柛"),l1l1ll_l1_ (u"ࠩหัะฺ๋ࠦำุ้๋่ࠣฮࠢห๋ࠥ็๊้ࠡำหࠥอไษำ้ห๊าࠧ柜"))
		return l1l1ll_l1_ (u"ࠪࠫ柝")
	LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ柞"),l1l1ll_l1_ (u"ࠬ࠴ࠠࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩ柟")+text+l1l1ll_l1_ (u"࠭ࠢࠨ柠"))
	return text
def l11l1l11ll11_l1_():
	type,name,url,mode,image,page,text,context,infodict = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l1ll_l1_ (u"ࠧ࡝ࡦ࡟ࡨ࠿ࡢࡤ࡝ࡦࠣࡠࡠ࠵ࡃࡐࡎࡒࡖࡡࡣࠧ柡"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l1ll_l1_ (u"ࠨࡡࠨࡱ࠳ࠫࡤࡠࠧࡋ࠾ࠪࡓ࡟ࠨ柢"),time.localtime(now))
	name = name+datetime
	menuItem = type,name,url,mode,image,page,text,context,infodict
	if os.path.exists(l1l11l11ll1_l1_):
		oldFILE = open(l1l11l11ll1_l1_,l1l1ll_l1_ (u"ࠩࡵࡦࠬ柣")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ柤"))
		oldFILE = EVAL(l1l1ll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ查"),oldFILE)
	else: oldFILE = {}
	newFILE = {}
	for l111l11ll11l_l1_ in list(oldFILE.keys()):
		if l111l11ll11l_l1_!=type: newFILE[l111l11ll11l_l1_] = oldFILE[l111l11ll11l_l1_]
		else:
			if name and name!=l1l1ll_l1_ (u"ࠬ࠴࠮ࠨ柦"):
				oldLIST = oldFILE[l111l11ll11l_l1_]
				if menuItem in oldLIST:
					index = oldLIST.index(menuItem)
					del oldLIST[index]
				newLIST = [menuItem]+oldLIST
				newLIST = newLIST[:50]
				newFILE[l111l11ll11l_l1_] = newLIST
			else: newFILE[l111l11ll11l_l1_] = oldFILE[l111l11ll11l_l1_]
	if type not in list(newFILE.keys()): newFILE[type] = [menuItem]
	newFILE = str(newFILE)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ柧"))
	open(l1l11l11ll1_l1_,l1l1ll_l1_ (u"ࠧࡸࡤࠪ柨")).write(newFILE)
	return
def l11lll1lll_l1_(url2,headers={}):
	#if headers[l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ柩")]==l1l1ll_l1_ (u"ࠩࠪ柪"): headers[l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ柫")] = l1l1ll_l1_ (u"ࠫࠥ࠭柬")
	#l11l111ll111_l1_ = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ柭") : l1l1ll_l1_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠻࠺࠴࠰࠯࠵࠺࠻࠵࠴࠱࠵࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ柮") }
	#url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡧ࠼࠹࠴࡭ࡺࡥࡧࡲ࠳ࡳࡥ࠰ࡸ࡬ࡨࡪࡵ࠮࡮࠵ࡸ࠼ࠬ柯")
	#open(l1l1ll_l1_ (u"ࠨࡕ࠽ࡠࡡࡺࡥࡴࡶ࠵࠲ࡲ࠹ࡵ࠹ࠩ柰"), l1l1ll_l1_ (u"ࠩࡵࠫ柱")).read()
	url,params = url2,l1l1ll_l1_ (u"ࠪࠫ柲")
	if l1l1ll_l1_ (u"ࠫࢁ࠭柳") in url2:
		url,params = url2.split(l1l1ll_l1_ (u"ࠬࢂࠧ柴"),1)
		if l1l1ll_l1_ (u"࠭࠽ࠨ柵") not in params: url,params = url2,l1l1ll_l1_ (u"ࠧࠨ柶")
	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ柷"),url,l1l1ll_l1_ (u"ࠩࠪ柸"),headers,l1l1ll_l1_ (u"ࠪࠫ柹"),True,l1l1ll_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨ柺"),False,False)
	html = response.content
	if l1l1ll_l1_ (u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩ査") not in html: return [l1l1ll_l1_ (u"࠭࠭࠲ࠩ柼")],[url2]
	#	if l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ柽") in list(headers.keys()): del headers[l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ柾")]
	#	else: headers[l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭柿")] = l1l1ll_l1_ (u"ࠪࠫ栀")
	#	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ栁"),url,l1l1ll_l1_ (u"ࠬ࠭栂"),headers,l1l1ll_l1_ (u"࠭ࠧ栃"),False,l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠳ࡰࡧࠫ栄"),False,False)
	#	html = response.content
	if l1l1ll_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ栅") in html: return [l1l1ll_l1_ (u"ࠩ࠰࠵ࠬ栆")],[url2]
	if l1l1ll_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ标") in html: return [l1l1ll_l1_ (u"ࠫ࠲࠷ࠧ栈")],[url2]
	#if l1l1ll_l1_ (u"࡚࡙ࠬࡑࡇࡀࡗ࡚ࡈࡔࡊࡖࡏࡉࡘ࠭栉") in html: return [l1l1ll_l1_ (u"࠭࠭࠲ࠩ栊")],[url2]
	l111l1l_l1_,l11l1_l1_,l11l1l1lll11_l1_,l11lll11l11l_l1_ = [],[],[],[]
	lines = re.findall(l1l1ll_l1_ (u"ࠧ࡝ࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ栋"),html+l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡷ࠭栌"),re.DOTALL)
	if not lines: return [l1l1ll_l1_ (u"ࠩ࠰࠵ࠬ栍")],[url2]
	for line,link in lines:
		l1111llll111_l1_,l11l11ll1l1_l1_,l11ll1l1_l1_ = {},-1,-1
		title = l1l1ll_l1_ (u"ࠪࠫ栎")
		#hostname = SERVER(link,l1l1ll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ栏"))
		#title = title+l1l1ll_l1_ (u"ࠬࠦࠠࠨ栐")+hostname+l1l1ll_l1_ (u"࠭ࠠࠡࠩ树")
		#line = line.lower()
		items = line.split(l1l1ll_l1_ (u"ࠧ࠭ࠩ栒"))
		for item in items:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ栓"),l1l1ll_l1_ (u"ࠩࠪ栔"),item,l1l1ll_l1_ (u"ࠪࠫ栕"))
			#if l1l1ll_l1_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭栖") in item: l1111llll111_l1_[key] = value
			if l1l1ll_l1_ (u"ࠬࡃࠧ栗") in item:
				key,value = item.split(l1l1ll_l1_ (u"࠭࠽ࠨ栘"),1)
				l1111llll111_l1_[key.lower()] = value
		if l1l1ll_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ栙") in line.lower():
			l11l11ll1l1_l1_ = int(l1111llll111_l1_[l1l1ll_l1_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ栚")])//1024
			#title += l1l1ll_l1_ (u"ࠩࡄࡺ࡬ࡈࡗ࠻ࠢࠪ栛")+str(l11l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ栜")
			title += str(l11l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ栝")
		elif l1l1ll_l1_ (u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ栞") in line.lower():
			l11l11ll1l1_l1_ = int(l1111llll111_l1_[l1l1ll_l1_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ栟")])//1024
			#title += l1l1ll_l1_ (u"ࠧࡃ࡙࠽ࠤࠬ栠")+str(l11l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ校")
			title += str(l11l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ栢")
		if l1l1ll_l1_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ栣") in line.lower():
			l11ll1l1_l1_ = int(l1111llll111_l1_[l1l1ll_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ栤")].split(l1l1ll_l1_ (u"ࠬࡾࠧ栥"))[1])
			#title += l1l1ll_l1_ (u"࠭ࡒࡦࡵ࠽ࠤࠬ栦")+str(l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠧࠡࠢࠪ栧")
			title += str(l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠨࠢࠣࠫ栨")
		title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠤࠬ栩"))
		if not title: title = l1l1ll_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ株")
		if not link.startswith(l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ栫")):
			if link.startswith(l1l1ll_l1_ (u"ࠬ࠵࠯ࠨ栬")): link = url.split(l1l1ll_l1_ (u"࠭࠺ࠨ栭"),1)[0]+l1l1ll_l1_ (u"ࠧ࠻ࠩ栮")+link
			elif link.startswith(l1l1ll_l1_ (u"ࠨ࠱ࠪ栯")): link = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭栰"))+link
			else: link = url.rsplit(l1l1ll_l1_ (u"ࠪ࠳ࠬ栱"),1)[0]+l1l1ll_l1_ (u"ࠫ࠴࠭栲")+link
		if params!=l1l1ll_l1_ (u"ࠬ࠭栳"): link = link+l1l1ll_l1_ (u"࠭ࡼࠨ栴")+params
		if l1l1ll_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ栵") in list(l1111llll111_l1_.keys()):
			l111111l1_l1_ = l1111llll111_l1_[l1l1ll_l1_ (u"ࠨࡲࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠳ࡵࡳ࡫ࠪ栶")]
			l111111l1_l1_ = l111111l1_l1_.replace(l1l1ll_l1_ (u"ࠩࠥࠫ样"),l1l1ll_l1_ (u"ࠪࠫ核")).replace(l1l1ll_l1_ (u"ࠦࠬࠨ根"),l1l1ll_l1_ (u"ࠬ࠭栺")).split(l1l1ll_l1_ (u"࠭ࠣࠨ栻"),1)[0]
			videofiletype = GET_VIDEOFILETYPE(l111111l1_l1_)
			if videofiletype: title2 = title+l1l1ll_l1_ (u"ࠧࠡࠢࠪ格")+videofiletype
			else: title2 = title
			title2 = title2+l1l1ll_l1_ (u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ栽")
			title2 = title2+l1l1ll_l1_ (u"ࠩࠣࠤࠬ栾")+SERVER(l111111l1_l1_,l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥࠨ栿"))
			l111l1l_l1_.append(title2)
			l11l1_l1_.append(l111111l1_l1_)
			l11l1l1lll11_l1_.append(l11ll1l1_l1_)
			l11lll11l11l_l1_.append(l11l11ll1l1_l1_)
		link = link.split(l1l1ll_l1_ (u"ࠫࠨ࠭桀"),1)[0]
		videofiletype = GET_VIDEOFILETYPE(link)
		if videofiletype: title = title+l1l1ll_l1_ (u"ࠬࠦࠠࠨ桁")+videofiletype
		title = title+l1l1ll_l1_ (u"࠭ࠠࠡࠩ桂")+SERVER(link,l1l1ll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ桃"))
		l111l1l_l1_.append(title)
		l11l1_l1_.append(link)
		l11l1l1lll11_l1_.append(l11ll1l1_l1_)
		l11lll11l11l_l1_.append(l11l11ll1l1_l1_)
	zz = list(zip(l111l1l_l1_,l11l1_l1_,l11l1l1lll11_l1_,l11lll11l11l_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l111l1l_l1_,l11l1_l1_,l11l1l1lll11_l1_,l11lll11l11l_l1_ = list(zip(*zz))
	l111l1l_l1_,l11l1_l1_ = list(l111l1l_l1_),list(l11l1_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨࠩ桄"), l111l1l_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩࠪ桅"), l11l1_l1_)
	return l111l1l_l1_,l11l1_l1_
mac = l1l1ll_l1_ (u"ࠪࠫ框")
def l11l1l11111l_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l1l1l1l1l_l1_(length=32):
	l1l111l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡸࡺࡲࠨ桇"),l1l1ll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ案"),l1l1ll_l1_ (u"࠭ࡃࡍࡋࡈࡒ࡙ࡏࡄࠨ桉"))
	if l1l111l1l1_l1_: return l1l111l1l1_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l111l1lll11l_l1_ = threading.Thread(target=l11l1l11111l_l1_,args=())
	l111l1lll11l_l1_.start()
	for ii in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l1l1ll_l1_ (u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪ桊")
	else:
		mac = mac.replace(l1l1ll_l1_ (u"ࠨ࠼ࠪ桋"),l1l1ll_l1_ (u"ࠩࠪ桌"))
		node = str(int(mac,16))
	node = re.findall(l1l1ll_l1_ (u"ࠪ࡟࠵࠳࠹࡞࠭ࠪ桍"),node,re.DOTALL)
	node = length*l1l1ll_l1_ (u"ࠫ࠵࠭桎")+node[0]
	node = node[-length:]
	mm,ss = l1l1ll_l1_ (u"ࠬ࠭桏"),l1l1ll_l1_ (u"࠭ࠧ桐")
	l111ll1l11ll_l1_ = str(int(l1l1ll_l1_ (u"ࠧ࠺ࠩ桑")*(length+1))-int(node))[-length:]
	for ii in list(range(0,length,4)):
		l1111ll11lll_l1_ = l111ll1l11ll_l1_[ii:ii+4]
		mm += l1111ll11lll_l1_+l1l1ll_l1_ (u"ࠨ࠯ࠪ桒")
		ss += str(sum(map(int,node[ii:ii+4]))%10)
	l1l111l1l1_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ桓"),l1l1ll_l1_ (u"ࠪࡇࡑࡏࡅࡏࡖࡌࡈࠬ桔"),l1l111l1l1_l1_,PERMANENT_CACHE)
	return l1l111l1l1_l1_
def DNS_RESOLVER(host,dns_server=l1l11l111l11_l1_[0]):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ桕"),l1l1ll_l1_ (u"ࠬ࠭桖"),str(dns_server),str(host))
	if host.replace(l1l1ll_l1_ (u"࠭࠮ࠨ桗"),l1l1ll_l1_ (u"ࠧࠨ桘")).isdigit(): return [host]
	import struct,socket
	try:
		l11l11ll1ll1_l1_ = struct.pack(l1l1ll_l1_ (u"ࠣࡀࡋࠦ桙"), 12049)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠤࡁࡌࠧ桚"), 256)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠥࡂࡍࠨ桛"), 1)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠦࡃࡎࠢ桜"), 0)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠧࡄࡈࠣ桝"), 0)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠨ࠾ࡉࠤ桞"), 0)
		if kodi_version>18.99: l11l1111l1l1_l1_ = host.split(l1l1ll_l1_ (u"ࠧ࠯ࠩ桟"))
		else: l11l1111l1l1_l1_ = host.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭桠")).split(l1l1ll_l1_ (u"ࠩ࠱ࠫ桡"))
		for part in l11l1111l1l1_l1_:
			parts = part.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ桢"))
			l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠦࡇࠨ档"), len(part))
			for l11l1l111lll_l1_ in part:
				l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠧࡩࠢ桤"), l11l1l111lll_l1_.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ桥")))
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠢࡃࠤ桦"), 0)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠣࡀࡋࠦ桧"), 1)
		l11l11ll1ll1_l1_ += struct.pack(l1l1ll_l1_ (u"ࠤࡁࡌࠧ桨"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l11l11ll1ll1_l1_), (dns_server, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11ll11l1l11_l1_ = struct.unpack_from(l1l1ll_l1_ (u"ࠥࡂࡍࡎࡈࡉࡊࡋࠦ桩"), data, 0)
		l11l1ll11l1l_l1_ = l11ll11l1l11_l1_[3]
		offset = len(host)+18
		answer = []
		for _ in range(l11l1ll11l1l_l1_):
			l11l1l1ll1l1_l1_ = offset
			l111lll1ll11_l1_ = 1
			l11l11ll11l1_l1_ = False
			while True:
				l11l1l111lll_l1_ = struct.unpack_from(l1l1ll_l1_ (u"ࠦࡃࡈࠢ桪"), data, l11l1l1ll1l1_l1_)[0]
				if l11l1l111lll_l1_ == 0:
					l11l1l1ll1l1_l1_ += 1
					break
				# l111l1l1l111_l1_ the field l111l11lll1l_l1_ the first l11ll11ll1l1_l1_ bits l111ll11111l_l1_ to 1, l111l1l11l1_l1_ a pointer
				if l11l1l111lll_l1_ >= 192:
					l11l1l1111l1_l1_ = struct.unpack_from(l1l1ll_l1_ (u"ࠧࡄࡂࠣ桫"), data, l11l1l1ll1l1_l1_ + 1)[0]
					# l1111lll1l11_l1_ the pointer
					l11l1l1ll1l1_l1_ = ((l11l1l111lll_l1_ << 8) + l11l1l1111l1_l1_ - 0xc000) - 1
					l11l11ll11l1_l1_ = True
				l11l1l1ll1l1_l1_ += 1
				if l11l11ll11l1_l1_ == False: l111lll1ll11_l1_ += 1
			if l11l11ll11l1_l1_ == True: l111lll1ll11_l1_ += 1
			offset = offset + l111lll1ll11_l1_
			l11lll111l11_l1_ = struct.unpack_from(l1l1ll_l1_ (u"ࠨ࠾ࡉࡊࡌࡌࠧ桬"), data, offset)
			offset = offset + 10
			l11ll11ll1ll_l1_ = l11lll111l11_l1_[0]
			l11l11ll1l11_l1_ = l11lll111l11_l1_[3]
			if l11ll11ll1ll_l1_ == 1: # l11ll111111l_l1_ type
				l11l1l11l111_l1_ = struct.unpack_from(l1l1ll_l1_ (u"ࠢ࠿ࠤ桭")+l1l1ll_l1_ (u"ࠣࡄࠥ桮")*l11l11ll1l11_l1_, data, offset)
				l1lll1l1111l_l1_ = l1l1ll_l1_ (u"ࠩࠪ桯")
				for l11l1l111lll_l1_ in l11l1l11l111_l1_: l1lll1l1111l_l1_ += str(l11l1l111lll_l1_) + l1l1ll_l1_ (u"ࠪ࠲ࠬ桰")
				l1lll1l1111l_l1_ = l1lll1l1111l_l1_[0:-1]
				answer.append(l1lll1l1111l_l1_)
			if l11ll11ll1ll_l1_ in [1,2,5,6,15,28]: offset = offset + l11l11ll1l11_l1_
	except: answer = []
	if not answer: LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ桱"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ桲")+host+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ桳"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ桴"),l1l1ll_l1_ (u"ࠨࠩ桵"),str(host),str(answer))
	return answer
def l1l1111_l1_(script_name,url,l1ll111_l1_,showDialogs=True):
	if l1ll111_l1_:
		l11ll11l11ll_l1_ = [l1l1ll_l1_ (u"ࠩๆฬฬืࠧ桶"),l1l1ll_l1_ (u"ࠪฬฬฺ๊ࠨ桷"),l1l1ll_l1_ (u"ࠫࡦࡪࡵ࡭ࡶࠪ桸"),l1l1ll_l1_ (u"ࠬࡾࡸࠨ桹"),l1l1ll_l1_ (u"࠭ࡳࡦࡺࠪ桺")]
		if script_name!=l1l1ll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭桻"):
			l11ll11l11ll_l1_ += [l1l1ll_l1_ (u"ࠨࡴ࠽ࠫ桼"),l1l1ll_l1_ (u"ࠩࡵ࠱ࠬ桽"),l1l1ll_l1_ (u"ࠪ࠱ࡲࡧࠧ桾")]
			l11ll11l11ll_l1_ += [l1l1ll_l1_ (u"ࠫ࠿ࡸࠧ桿"),l1l1ll_l1_ (u"ࠬ࠳ࡲࠨ梀"),l1l1ll_l1_ (u"࠭࡭ࡢ࠯ࠪ梁")]
		for l1lll11ll1_l1_ in l1ll111_l1_:
			if l1l1ll_l1_ (u"ࠧࡨࡧࡷ࠲ࡵ࡮ࡰࡀࠩ梂") in l1lll11ll1_l1_: continue
			if l1l1ll_l1_ (u"ࠨฯ็ๆฮ࠭梃") in l1lll11ll1_l1_: continue
			l1lll11ll1_l1_ = l1lll11ll1_l1_.lower()
			if kodi_version<19: l1lll11ll1_l1_ = l1lll11ll1_l1_.decode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ梄")).encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ梅"))
			#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ梆"),l1l1ll_l1_ (u"ࠬ࠭梇"),l1l1ll_l1_ (u"࠭ࠧ梈"),str(l1lll11ll1_l1_))
			#l11l1ll111l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫࠧࠫ梉"),l1lll11ll1_l1_,re.DOTALL)
			#l11l1ll11l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡠ࡟࠯࠭࠷࡛࠷࠯࠼ࡡࢁ࠸࡛࠱࠯࠼ࡡ࠮ࠪࠧ梊"),l1lll11ll1_l1_,re.DOTALL)
			#l1111lll11l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡡࠬ࠶ࡡ࠶࠮࠻ࡠࢀ࠷ࡡ࠰࠮࠻ࡠ࠭ࡡ࠱ࠤࠨ梋"),l1lll11ll1_l1_,re.DOTALL)
			#l11l1l111l1l_l1_ = any(l11l1ll111l1_l1_,l11l1ll11l11_l1_,l1111lll11l1_l1_,l11l1ll1111l_l1_)
			l1lll11ll1_l1_ = l1lll11ll1_l1_.replace(l1l1ll_l1_ (u"ࠪ࠾ࠬ梌"),l1l1ll_l1_ (u"ࠫࠬ梍"))
			l11l1l111l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠱࡜࠷࠰࠽ࡢ࠱ࡼ࠳࡝࠳࠱࠸ࡣࠫࠪࠩ梎"),l1lll11ll1_l1_,re.DOTALL)
			l11l11l1l1ll_l1_ = False
			for digits in l11l1l111l1l_l1_:
				if len(digits)==2:
					l11l11l1l1ll_l1_ = True
					break
			if l1l1ll_l1_ (u"࠭࡮ࡰࡶࠣࡶࡦࡺࡥࡥࠩ梏") in l1lll11ll1_l1_: continue
			elif l1l1ll_l1_ (u"ࠧࡶࡰࡵࡥࡹ࡫ࡤࠨ梐") in l1lll11ll1_l1_: continue
			elif l1l1ll_l1_ (u"ࠨ฼ํี๋ࠥี็ใࠪ梑") in l1lll11ll1_l1_: continue
			elif l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼ࡗࡗ࡜ࡎࡖࡗ࡯࡚ࡉ࡜ࡅࡗࡇ࡛ࠫ梒")): continue
			elif l1lll11ll1_l1_ in [l1l1ll_l1_ (u"ࠪࡶࠬ梓")] or l11l11l1l1ll_l1_ or any(value in l1lll11ll1_l1_ for value in l11ll11l11ll_l1_):
				LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ梔"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡄ࡯ࡳࡨࡱࡥࡥࠢࡤࡨࡺࡲࡴࡴࠢࡹ࡭ࡩ࡫࡯࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ梕")+url+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ梖"))
				if showDialogs: DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ梗"),l1l1ll_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ梘"))
				return True
	return False
def l1lll1l11_l1_(data):
	if kodi_version>18.99: import urllib.parse as l11lll111l1l_l1_
	else: import urllib as l11lll111l1l_l1_
	l11l1lll11l1_l1_ = l11lll111l1l_l1_.urlencode(data)
	return l11l1lll11l1_l1_
def URLDECODE(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ梙"),l1l1ll_l1_ (u"ࠪࠫ梚"),url,l1l1ll_l1_ (u"࡚ࠫࡘࡌࡅࡇࡆࡓࡉࡋࠧ梛"))
	if l1l1ll_l1_ (u"ࠬࡃࠧ梜") in url:
		if l1l1ll_l1_ (u"࠭࠿ࠨ條") in url: url2,filters = url.split(l1l1ll_l1_ (u"ࠧࡀࠩ梞"))
		else: url2,filters = l1l1ll_l1_ (u"ࠨࠩ梟"),url
		filters = filters.split(l1l1ll_l1_ (u"ࠩࠩࠫ梠"))
		data2 = {}
		for filter in filters:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ梡"),l1l1ll_l1_ (u"ࠫࠬ梢"),filter,str(filters))
			key,value = filter.split(l1l1ll_l1_ (u"ࠬࡃࠧ梣"))
			data2[key] = value
	else: url2,data2 = url,{}
	return url2,data2
def PLAY_VIDEO(url3,website=l1l1ll_l1_ (u"࠭ࠧ梤"),type_=l1l1ll_l1_ (u"ࠧࠨ梥")):
	if not type_: type_ = l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ梦")
	result,l11ll11ll11l_l1_,httpd = l1l1ll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ梧"),l1l1ll_l1_ (u"ࠪࠫ梨"),l1l1ll_l1_ (u"ࠫࠬ梩")
	if len(url3)==3:
		url,l111ll1llll1_l1_,httpd = url3
		if l111ll1llll1_l1_!=l1l1ll_l1_ (u"ࠬ࠭梪"): l11ll11ll11l_l1_ = l1l1ll_l1_ (u"࠭ࠠࠡࠢࡖࡹࡧࡺࡩࡵ࡮ࡨ࠾ࠥࡡࠠࠨ梫")+l111ll1llll1_l1_+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ梬")
	else: url,l111ll1llll1_l1_,httpd = url3,l1l1ll_l1_ (u"ࠨࠩ梭"),l1l1ll_l1_ (u"ࠩࠪ梮")
	#url = UNQUOTE(url)		# cause l1111ll11111_l1_ for l1llll11l_l1_ l11111ll_l1_ l11l1111l1l_l1_ streams
	url = url.replace(l1l1ll_l1_ (u"ࠪࠩ࠷࠶ࠧ梯"),l1l1ll_l1_ (u"ࠫࠥ࠭械"))	# needed for l1ll1l1l1l11_l1_
	videofiletype = GET_VIDEOFILETYPE(url,website)
	if website not in [l1l1ll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ梱"),l1l1ll_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ梲")]:
		if website!=l1l1ll_l1_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ梳"): url = url.replace(l1l1ll_l1_ (u"ࠨࠢࠪ梴"),l1l1ll_l1_ (u"ࠩࠨ࠶࠵࠭梵"))
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ梶"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡰ࡭ࡣࡼ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ梷")+url+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ梸")+l11ll11ll11l_l1_)
		if videofiletype==l1l1ll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ梹") and website not in [l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ梺"),l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ梻")]:
			headers = {l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭梼"):l1l1ll_l1_ (u"ࠪࠫ梽")}
			l111l1l_l1_,l11l1_l1_ = l11lll1lll_l1_(url,headers)
			count = len(l11l1_l1_)
			if count>1:
				selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬ梾")+str(count)+l1l1ll_l1_ (u"ࠬࠦๅๅใࠬࠫ梿"), l111l1l_l1_)
				if selection == -1:
					DIALOG_NOTIFICATION(l1l1ll_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ฮูเ๊ๅࠩ检"),l1l1ll_l1_ (u"ࠧࠨ棁"))
					return result
			else: selection = 0
			url = l11l1_l1_[selection]
			if l111l1l_l1_[0]!=l1l1ll_l1_ (u"ࠨ࠯࠴ࠫ棂"):
				LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ棃"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠿࡛ࠦࠡࠩ棄")+l111l1l_l1_[selection]+l1l1ll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ棅")+url+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ棆"))
		#url = url+l1l1ll_l1_ (u"࠭ࠦࡳࡣࡱ࡫ࡪࡃ࠰࠮࠳࠴࠼࠻࠶࠰࠱࠲ࠪ棇")
		#url = url+l1l1ll_l1_ (u"ࠧࡽࡆࡑࡘࡂ࠷ࠦࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦ࠿ࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠷ࠩࡅࡨࡩࡥࡱࡶ࠰ࡉࡳࡩ࡯ࡥ࡫ࡱ࡫ࡂ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠫࡇࡣࡤࡧࡳࡸࡂ࠰࠯ࠫࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭ࡒࡩ࡯ࡷࡻ࠿ࠥࡇ࡮ࡥࡴࡲ࡭ࡩࠦ࠷࠯࠲࠾ࠤࡘࡓ࠭ࡈ࠺࠼࠶ࡆࠦࡂࡶ࡫࡯ࡨ࠴ࡔࡒࡅ࠻࠳ࡑࡀࠦࡷࡷࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡗࡧࡵࡷ࡮ࡵ࡮࠰࠶࠱࠴ࠥࡉࡨࡳࡱࡰࡩ࠴࠼࠷࠯࠲࠱࠷࠸࠿࠶࠯࠺࠺ࠤࡒࡵࡢࡪ࡮ࡨࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ棈")
		if l1l1ll_l1_ (u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩ棉") in url: url = url+l1l1ll_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ棊")
		elif l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ棋") in url.lower() and l1l1ll_l1_ (u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ棌") not in url and l1l1ll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ棍") not in url:
			if l1l1ll_l1_ (u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࠫ棎") not in url and l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ棏") in url.lower():
				if l1l1ll_l1_ (u"ࠨࡾࠪ棐") not in url: url = url+l1l1ll_l1_ (u"ࠩࡿࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭棑")
				else: url = url+l1l1ll_l1_ (u"ࠪࠪࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠧ棒")
			if l1l1ll_l1_ (u"ࠫࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴࠨ棓") not in url.lower() and website not in [l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘࠪ棔"),l1l1ll_l1_ (u"࠭ࡍ࠴ࡗࠪ棕")]:
				if l1l1ll_l1_ (u"ࠧࡽࠩ棖") not in url: url = url+l1l1ll_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ棗")
				else: url = url+l1l1ll_l1_ (u"࡙ࠩࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ棘")
		#url = url.replace(l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ棙"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ棚"))
	LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ棛"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ棜")+url+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ棝"))
	l1111llllll1_l1_ = xbmcgui.ListItem()
	#l1111llllll1_l1_ = xbmcgui.ListItem(l1l1ll_l1_ (u"ࠨࡶࡨࡷࡹ࠭棞"))
	type_,l11ll11l1ll1_l1_,l111lll11l11_l1_,l111l1ll1l11_l1_,l111l111l1l1_l1_,l11l111l1l11_l1_,l11ll11l1l1l_l1_,l111ll11llll_l1_,l111ll1lllll_l1_ = EXTRACT_KODI_PATH(addon_path)
	if website not in [l1l1ll_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ棟"),l1l1ll_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ棠")]:
		if kodi_version<19: l1111l1lllll_l1_ = l1l1ll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧ棡")
		else: l1111l1lllll_l1_ = l1l1ll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࠪ棢")
		#l1111llllll1_l1_ = xbmcgui.ListItem(path=url)
		l1111llllll1_l1_.setProperty(l1111l1lllll_l1_, l1l1ll_l1_ (u"࠭ࠧ棣"))
		l1111llllll1_l1_.setMimeType(l1l1ll_l1_ (u"ࠧ࡮࡫ࡰࡩ࠴ࡾ࠭ࡵࡻࡳࡩࠬ棤"))
		if kodi_version<20: l1111llllll1_l1_.setInfo(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ棥"),{l1l1ll_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ棦"):l1l1ll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ棧")})
		else:
			videoinfo = l1111llllll1_l1_.getVideoInfoTag()
			videoinfo.setMediaType(l1l1ll_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ棨"))
		#img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡪࡥࡲࡲࠬ棩"))
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ棪"),l1l1ll_l1_ (u"ࠧࡆࡏࡄࡈ࠿ࡀ࠺࠻࠼ࠣࠫ棫")+image)
		#l1111llllll1_l1_.setArt({l1l1ll_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭棬"):image,l1l1ll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢࠨ棭"):image,l1l1ll_l1_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪ森"):image})
		l1111llllll1_l1_.setArt({l1l1ll_l1_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ棯"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ棰"):l111l111l1l1_l1_,l1l1ll_l1_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭棱"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ棲"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪ棳"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬ棴"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭棵"):l111l111l1l1_l1_,l1l1ll_l1_ (u"ࠫ࡮ࡩ࡯࡯ࠩ棶"):l111l111l1l1_l1_})
		#l1111llllll1_l1_.setInfo(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ棷"),{l1l1ll_l1_ (u"࠭ࡔࡪࡶ࡯ࡩࠬ棸"):name})
		#name = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ棹"))
		#name = name.strip(l1l1ll_l1_ (u"ࠨࠢࠪ棺"))
		# when set to l1l1ll_l1_ (u"ࠤࡉࡥࡱࡹࡥࠣ棻") it l11ll1l11l11_l1_ l111l1llll1l_l1_ l1llll11llll_l1_ and l111l1lll1ll_l1_ l11l1llll111_l1_ l1111lll1ll1_l1_ l1ll11l1ll_l1_
		if videofiletype in [l1l1ll_l1_ (u"ࠪ࠲ࡲࡶࡤࠨ棼"),l1l1ll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ棽")]: l1111llllll1_l1_.setContentLookup(True)
		else: l1111llllll1_l1_.setContentLookup(False)
		#if videofiletype in [l1l1ll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ棾")]: l1111llllll1_l1_.setContentLookup(False)
		if l1l1ll_l1_ (u"࠭ࡲࡵ࡯ࡳࠫ棿") in url:
			import l1ll1l1lll11_l1_
			l1ll1l1lll11_l1_.l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ椀"),False)
		elif videofiletype==l1l1ll_l1_ (u"ࠨ࠰ࡰࡴࡩ࠭椁") or l1l1ll_l1_ (u"ࠩ࠲ࡨࡦࡹࡨ࠰ࠩ椂") in url:
			import l1ll1l1lll11_l1_
			l1ll1l1lll11_l1_.l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ椃"),False)
			l1111llllll1_l1_.setProperty(l1111l1lllll_l1_,l1l1ll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ椄"))
			l1111llllll1_l1_.setProperty(l1l1ll_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠳ࡳࡡ࡯࡫ࡩࡩࡸࡺ࡟ࡵࡻࡳࡩࠬ椅"),l1l1ll_l1_ (u"࠭࡭ࡱࡦࠪ椆"))
			#l1111llllll1_l1_.setMimeType(l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡪࡡࡴࡪ࠮ࡼࡲࡲࠧ椇"))
			#l1111llllll1_l1_.setContentLookup(False)
		if l111ll1llll1_l1_:
			l1111llllll1_l1_.setSubtitles([l111ll1llll1_l1_])
			#xbmc.log(LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࡂࡦࡧࡩࡩࠦࡳࡶࡤࡷ࡭ࡹࡲࡥࠡࡶࡲࠤࡻ࡯ࡤࡦࡱࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺࡜ࠩ椈")+l111ll1llll1_l1_+l1l1ll_l1_ (u"ࠩࡠࠫ椉"), level=xbmc.LOGNOTICE)
	if type_==l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ椊") and website==l1l1ll_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭椋"):
		result = l1l1ll_l1_ (u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ椌")
		website = l1l1ll_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡉࡒ࡟ࡇࡋࡏࡉࡘ࠭植")
	elif type_==l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭椎") and l111ll11llll_l1_.startswith(l1l1ll_l1_ (u"ࠨ࠸ࠪ椏")):
		result = l1l1ll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ椐")
		website = website+l1l1ll_l1_ (u"ࠪࡣࡉࡒࠧ椑")
	# l11l111llll1_l1_ l11l1111ll1l_l1_
	#	l111ll1l1l11_l1_ = l111lll1111l_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11ll111l1_l1_ with xbmc.sleep(step*1000)
	if result!=l1l1ll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭椒"): l11l1l11ll11_l1_()
	l111ll1l1l11_l1_ = l111lll1111l_l1_()
	if type_==l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ椓") and not l111ll11llll_l1_.startswith(l1l1ll_l1_ (u"࠭࠶ࠨ椔")):
		#title = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡭ࡹࡲࡥࠨ椕"))
		#l1111llllll1_l1_.setInfo(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ椖"),{l1l1ll_l1_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ椗"): 3600})
		#xbmcplugin.setContent(addon_handle,l1l1ll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ椘"))
		#l1111llllll1_l1_.setInfo(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ椙"),{l1l1ll_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ椚"):l1l1ll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ椛")})
		#l1111llllll1_l1_.setProperty(l1l1ll_l1_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫ検"),l1l1ll_l1_ (u"ࠨࡶࡵࡹࡪ࠭椝"))
		#l1111llllll1_l1_.setInfo(type=l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ椞"),l111l1111111_l1_={l1l1ll_l1_ (u"ࠥࡘ࡮ࡺ࡬ࡦࠤ椟"):l1l1ll_l1_ (u"ࠫ࡭࡫࡬࡭ࡱࠣࡻࡴࡸ࡬ࡥࠩ椠")})
		l1111llllll1_l1_.setPath(url)
		LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ椡"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ椢")+url+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ椣"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1111llllll1_l1_)
	elif type_==l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭椤"):
		LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ椥"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡺࡹࡩ࡯ࡩࠣࡴࡱࡧࡹࠩࠫࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭椦")+url+l1l1ll_l1_ (u"ࠫࠥࡣࠧ椧"))
		l111ll1l1l11_l1_.play(url,l1111llllll1_l1_)
		#xbmc.Player().play(url,l1111llllll1_l1_)
	if result!=l1l1ll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ椨"):
		timeout,result = 10,l1l1ll_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ椩")
		for ii in range(timeout):
			# l11l111llll1_l1_ l11l1111ll1l_l1_
			#	if l1l1lll11l_l1_ time.sleep() l11lll1lll1_l1_ of xbmc.sleep() l11l1ll1l1l1_l1_ the l1lll11llll1_l1_ status
			#	l1l1ll_l1_ (u"ࠢ࡮ࡻࡳࡰࡦࡿࡥࡳ࠰ࡶࡸࡦࡺࡵࡴࠤ椪") will stop l11ll11lll11_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			result = l111ll1l1l11_l1_.status
			if result==l1l1ll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ椫"):
				DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣ๎฾๋ไࠨ椬"),l1l1ll_l1_ (u"ࠪࠫ椭"),time=500)
				LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ椮"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࡺ࡮ࡪࡥࡰࠢ࡬ࡷࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ椯")+url+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ椰")+l11ll11ll11l_l1_)
				break
			elif result==l1l1ll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ椱"):
				LOG_THIS(l1l1ll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭椲"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ椳")+url+l1l1ll_l1_ (u"ࠪࠤࡢ࠭椴")+l11ll11ll11l_l1_)
				DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠫฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้࠭椵"),l1l1ll_l1_ (u"ࠬ࠭椶"),time=500)
				break
			DIALOG_NOTIFICATION(l1l1ll_l1_ (u"࠭ฬศำํࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫ椷"),l1l1ll_l1_ (u"ࠧษษๅ๎ࠥ࠭椸")+str(timeout-ii)+l1l1ll_l1_ (u"ࠨࠢฮห๋๐ษࠨ椹"))
		else:
			result = l1l1ll_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ椺")
			l111ll1l1l11_l1_.stop()
			DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠪห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠬ椻"),l1l1ll_l1_ (u"ࠫࠬ椼"),time=500)
			LOG_THIS(l1l1ll_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ椽"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡗ࡭ࡲ࡫࡯ࡶࡶࠣࡹࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ椾")+url+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ椿")+l11ll11ll11l_l1_)
	l1l1ll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢ࡫ࡸࡹࡶࡤ࠻ࠏࠍࠍࠎࠩࠠࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠯ࠍࠋࠋࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ࠲ࠧࠨ࠮ࠪࠫ࠱ࡌࡡ࡭ࡵࡨ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠸ࡸ࡭࠭ࠩࠎࠌࠌࠍࡹ࡯࡭ࡦ࠰ࡶࡰࡪ࡫ࡰࠩ࠳ࠬࠑࠏࠏࠉࡩࡶࡷࡴࡩ࠴ࡳࡩࡷࡷࡨࡴࡽ࡮ࠩࠫࠐࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࠪ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠩ࠯ࠫࠬ࠯ࠍࠋࠋࠥࠦࠧ楀")
	if result==l1l1ll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ楁") and not l1l1l111lll1_l1_(l1l1ll_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ楂")):
		import l11l1ll1l1_l1_
		succeeded = l11l1ll1l1_l1_.l11ll11111_l1_(url,videofiletype,website)
		if succeeded: l11l1l11ll11_l1_()
	else: succeeded = False
	if result in [l1l1ll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ楃"),l1l1ll_l1_ (u"ࠬࡶ࡬ࡢࡻࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ楄")] or succeeded:
		#addon_version = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠨࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭ࠨ楅")+addon_id+l1l1ll_l1_ (u"ࠢࠪࠤ楆") )
		response = SEND_ANALYTICS_EVENT(website)
		#html = response.content
	#if result in [l1l1ll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ楇"),l1l1ll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ楈"),l1l1ll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ楉"),l1l1ll_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ楊"),l1l1ll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭楋")]: l11ll11lllll_l1_(l1l1ll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ楌"),False)
	#l11ll11lllll_l1_(l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠲࠹ࡲࡥࠩ楍"))
	#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ楎") in url and result in [l1l1ll_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ楏"),l1l1ll_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ楐")]:
	#	l11ll11lll11_l1_ = HTTPS(False)
	#	if not l11ll11lll11_l1_:
	#		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ楑"),l1l1ll_l1_ (u"ࠬ࠭楒"),l1l1ll_l1_ (u"࠭วๅษอูฬ๊ࠠๆึไีࠬ楓"),l1l1ll_l1_ (u"ࠧๆึๆ่ฮࠦ࠮࠯࠰๋ࠣีอࠠศๆไ๎ิ๐่ࠡ์ะฮฬาࠠศๆ์ࠤฬะีศๆู้ࠣ็ัࠡࠪิฬ฼ࠦๅีใิ࠭ࠥ๎ไไ่่้ࠣษำโࠢส่ฬะีศๆࠣห้๋ิโำ่ࠣฬฺ๊ࠦ็็ࠤ฾๊้ࠡฮ๊หื้ࠧ楔"))
	#		return l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ楕")
	#sys.exit()
	return result
def DIALOG_OK(*args,**kwargs):
	if args:
		l1l11lll11l1_l1_ = args[0]
		l11lllll_l1_ = args[1]
		if not l1l11lll11l1_l1_: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ楖")
		if not l11lllll_l1_: l11lllll_l1_ = l1l1ll_l1_ (u"ࠪหุะๅาษิࠫ楗")
		header = args[2]
		text = l1l1ll_l1_ (u"ࠫࡡࡴࠧ楘").join(args[3:])
	else: l1l11lll11l1_l1_,l11lllll_l1_,header,text = l1l1ll_l1_ (u"ࠬ࠭楙"),l1l1ll_l1_ (u"࠭ࡏࡌࠩ楚"),l1l1ll_l1_ (u"ࠧࠨ楛"),l1l1ll_l1_ (u"ࠨࠩ楜")
	DIALOG_THREEBUTTONS_TIMEOUT(l1l11lll11l1_l1_,l1l1ll_l1_ (u"ࠩࠪ楝"),l11lllll_l1_,l1l1ll_l1_ (u"ࠪࠫ楞"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l1l11lll11l1_l1_ = args[0]
	l111lllll1l1_l1_ = args[1]
	l111lll1l11l_l1_ = args[2]
	if l111lll1l11l_l1_ or l111lllll1l1_l1_: l111llll1l1l_l1_ = True
	else: l111llll1l1l_l1_ = False
	header = args[3]
	text = args[4]
	if not l1l11lll11l1_l1_: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ楟")
	if not l111lllll1l1_l1_: l111lllll1l1_l1_ = l1l1ll_l1_ (u"้ࠬไศࠩ楠")
	if not l111lll1l11l_l1_: l111lll1l11l_l1_ = l1l1ll_l1_ (u"࠭ๆฺ็ࠪ楡")
	if len(args)>=6: text += l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ楢")+args[5]
	if len(args)>=7: text += l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ楣")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l11lll11l1_l1_,l111lllll1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ楤"),l111lll1l11l_l1_,header,text)
	if choice==-1 and l111llll1l1l_l1_: choice = -1
	elif choice==-1 and not l111llll1l1l_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l11l11l1ll11_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def DIALOG_NOTIFICATION(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l1ll_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ楥") in list(kwargs.keys()): l11l1l1l1111_l1_ = kwargs[l1l1ll_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ楦")]
	else: l11l1l1l1111_l1_ = 1000
	if len(args)>2 and l1l1ll_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ楧") not in args[2]: profile = args[2]
	else: profile = l1l1ll_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࠬ楨")
	l1l1l1ll1l11_l1_ = xbmcgui.WindowXMLDialog(l1l1ll_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧ楩"),addonfolder,l1l1ll_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ楪"),l1l1ll_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ楫"))
	image_filename,image_height = CREATE_IMAGE(l1l1ll_l1_ (u"ࠪࠫ楬"),l1l1ll_l1_ (u"ࠫࠬ業"),l1l1ll_l1_ (u"ࠬ࠭楮"),header,text,profile,l1l1ll_l1_ (u"࠭࡬ࡦࡨࡷࠫ楯"),720,False)
	#time.sleep(0.200)
	l1l1l1ll1l11_l1_.show()
	if profile==l1l1ll_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ楰"):
		l1l1l1ll1l11_l1_.getControl(9040).setHeight(215)
		l1l1l1ll1l11_l1_.getControl(9040).setPosition(55,-80)
		l1l1l1ll1l11_l1_.getControl(9050).setPosition(120,-60)
		l1l1l1ll1l11_l1_.getControl(400).setPosition(90,-35)
	l1l1l1ll1l11_l1_.getControl(401).setVisible(False)
	l1l1l1ll1l11_l1_.getControl(402).setVisible(False)
	l1l1l1ll1l11_l1_.getControl(9050).setImage(image_filename)
	l1l1l1ll1l11_l1_.getControl(9050).setHeight(image_height)
	import threading
	l11lll111ll1_l1_ = threading.Thread(target=l1111l1lll11_l1_,args=(l1l1l1ll1l11_l1_,image_filename,l11l1l1l1111_l1_))
	l11lll111ll1_l1_.start()
	#l11lll111ll1_l1_.join()
	return
	#return xbmcgui.Dialog().l111l111ll11_l1_(l111ll11l1l1_l1_=False,*args,**kwargs)
def l1111l1lll11_l1_(l1l1l1ll1l11_l1_,image_filename,l11l1l1l1111_l1_):
	time.sleep(l11l1l1l1111_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(image_filename):
		try: os.remove(image_filename)
		except: pass
	#del l1l1l1ll1l11_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,profile,l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠨࠩ楱"),l1l1ll_l1_ (u"ࠩࠪ楲"),l1l1ll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ楳"),l1l1ll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ楴")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1l11lll11l1_l1_ = args[3]
	return l11llll1l1_l1_(l1l11lll11l1_l1_,header,text,profile)
	#return xbmcgui.Dialog().l11l111111l1_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l111l1l1ll1l_l1_(*args,**kwargs)
def l11ll11l1l_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111ll111ll1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#button0,button1,button2,header,text,profile,l1l11lll11l1_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l1l1ll1l11_l1_ = l111l1l111ll_l1_(l1l1ll_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧ極"),addonfolder,l1l1ll_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ楶"),l1l1ll_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ楷"))
	#l1l1l1ll1l11_l1_.l11ll1111ll1_l1_(button0,button1,button2,header,text,profile,l1l11lll11l1_l1_,855)
	#return l1l1l1ll1l11_l1_
	l1l1ll_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡁ࠴࠿ࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡳࡵࡣࡵࡸࡇࡻࡴࡵࡱࡱࡷ࡙࡯࡭ࡦࡱࡸࡸ࠭ࡺࡩ࡮ࡧࡲࡹࡹ࠯ࠍࠋࠋࡨࡰࡸ࡫࠺ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡧࡱࡥࡧࡲࡥࡃࡷࡷࡸࡴࡴࡳࠩࠫࠐࠎࠎࠩࡤࡪࡣ࡯ࡳ࡬࠴ࡵࡱࡦࡤࡸࡪࡖࡲࡰࡩࡵࡩࡸࡹࡂࡢࡴࠫ࠻࠵࠯ࠉࠤࠢ࠺࠴ࠪࠓࠊࠊࡦ࡬ࡥࡱࡵࡧ࠯ࡦࡲࡑࡴࡪࡡ࡭ࠪࠬࠑࠏࠏࡣࡩࡱ࡬ࡧࡪࠦ࠽ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡥ࡫ࡳ࡮ࡩࡥࡊࡆࠐࠎࠎࡺࡲࡺ࠼ࠣࡳࡸ࠴ࡲࡦ࡯ࡲࡺࡪ࠮ࡤࡪࡣ࡯ࡳ࡬࠴ࡩ࡮ࡣࡪࡩࡤ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠩࠎࠌࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠨࡪࡥ࡭ࠢࡧ࡭ࡦࡲ࡯ࡨࠏࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡨ࡮࡯ࡪࡥࡨࠑࠏࠏࠢࠣࠤ楸")
def l1ll1ll1l_l1_(l111lll11lll_l1_):
	if kodi_version>17.99: l1l1l1ll1l11_l1_ = l1l1ll_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧ楹")
	else: l1l1l1ll1l11_l1_ = l1l1ll_l1_ (u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧ楺")
	l111lll11lll_l1_ = l111lll11lll_l1_.lower()
	if l111lll11lll_l1_==l1l1ll_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ楻"): xbmc.executebuiltin(l1l1ll_l1_ (u"ࠬࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࠧ楼")+l1l1l1ll1l11_l1_+l1l1ll_l1_ (u"࠭ࠩࠨ楽"))
	elif l111lll11lll_l1_==l1l1ll_l1_ (u"ࠧࡴࡶࡲࡴࠬ楾"): xbmc.executebuiltin(l1l1ll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࠨ楿")+l1l1l1ll1l11_l1_+l1l1ll_l1_ (u"ࠩࠬࠫ榀"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l1l11lll11l1_l1_,button0=l1l1ll_l1_ (u"ࠪࠫ榁"),button1=l1l1ll_l1_ (u"ࠫࠬ概"),button2=l1l1ll_l1_ (u"ࠬ࠭榃"),header=l1l1ll_l1_ (u"࠭ࠧ榄"),text=l1l1ll_l1_ (u"ࠧࠨ榅"),l111llll11ll_l1_=0,l111l1llll11_l1_=0,profile=l1l1ll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ榆")):
	if not l1l11lll11l1_l1_: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ榇")
	l1l1l1ll1l11_l1_ = l111l1l111ll_l1_(l1l1ll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ榈"),addonfolder,l1l1ll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ榉"),l1l1ll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ榊"))
	l1l1l1ll1l11_l1_.l11ll1111ll1_l1_(button0,button1,button2,header,text,profile,l1l11lll11l1_l1_,900,l111llll11ll_l1_,l111l1llll11_l1_)
	if l111llll11ll_l1_>0: l1l1l1ll1l11_l1_.l11ll1llllll_l1_()
	if l111l1llll11_l1_>0: l1l1l1ll1l11_l1_.l11ll1ll111l_l1_()
	if l111llll11ll_l1_==0 and l111l1llll11_l1_==0: l1l1l1ll1l11_l1_.enableButtons()
	l1l1l1ll1l11_l1_.doModal()
	choice = l1l1l1ll1l11_l1_.l11lll1111ll_l1_
	return choice
def l11llll1l1_l1_(l1l11lll11l1_l1_,header,text,profile=l1l1ll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ榋")):
	if not l1l11lll11l1_l1_: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ榌")
	#text = l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ榍").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l1l1ll_l1_ (u"ࠩࠪ榎")
	l1l1l1ll1l11_l1_ = xbmcgui.WindowXMLDialog(l1l1ll_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡗࡩࡽࡺࡖࡪࡧࡺࡩࡷࡌࡵ࡭࡮ࡖࡧࡷ࡫ࡥ࡯࠰ࡻࡱࡱ࠭榏"),addonfolder,l1l1ll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ榐"),l1l1ll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ榑"))
	image_filename,image_height = CREATE_IMAGE(l1l1ll_l1_ (u"࠭ࠧ榒"),l1l1ll_l1_ (u"ࠧࠨ榓"),l1l1ll_l1_ (u"ࠨࠩ榔"),header,text,profile,l1l11lll11l1_l1_,1270,False)
	l1l1l1ll1l11_l1_.show()
	#time.sleep(1)
	#l1l1l1ll1l11_l1_.getControl(9050).l1l1ll1l1ll1_l1_(1270-60)
	l1l1l1ll1l11_l1_.getControl(9050).setHeight(image_height)
	l1l1l1ll1l11_l1_.getControl(9050).setImage(image_filename)
	result = l1l1l1ll1l11_l1_.doModal()
	#del l1l1l1ll1l11_l1_
	try: os.remove(image_filename)
	except: pass
	return result
def l1l11lll1_l1_(l111l1ll11l1_l1_=True):
	if l111l1ll11l1_l1_:
		useragent = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭榕"),l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭榖"),l1l1ll_l1_ (u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧ榗"))
		if useragent: return useragent
	#LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ榘"),l1l1ll_l1_ (u"࠭ࡅࡎࡃࡇࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࡵࡴࡧࡵࡥ࡬࡫࡮ࡵ࠼ࠣࠫ榙")+results)
	# l11lll1111l1_l1_ and l1111lll1l_l1_ common user l111ll1ll111_l1_ (l11l1ll111ll_l1_ l11lll111111_l1_)
	text = l1l1ll_l1_ (u"ࠧࠨ榚")
	url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡩࡨ࡮ࡢ࡭ࡱࡪ࠲ࡼ࡯࡬࡭ࡵ࡫ࡳࡺࡹࡥ࠯ࡥࡲࡱ࠴࠸࠰࠲࠴࠲࠴࠶࠵࠰࠴࠱ࡰࡳࡸࡺ࠭ࡤࡱࡰࡱࡴࡴ࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࡷ࠴࠭榛")
	headers = {l1l1ll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ榜"):url}
	response = OPENURL_REQUESTS_CACHED(l1ll11ll11l_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ榝"),url,l1l1ll_l1_ (u"ࠫࠬ榞"),headers,l1l1ll_l1_ (u"ࠬ࠭榟"),False,l1l1ll_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧ榠"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l1ll_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ榡"))
		if count>80:
			text = re.findall(l1l1ll_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ榢"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ榣"),l1l1ll_l1_ (u"ࠪࠫ榤"),l1l1ll_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠧ榥"),l1l1ll_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࡙ࠣࡘࡋࡒ࠮ࡃࡊࡉࡓ࡚ࡓࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠬ榦"))
	if not text:
		text = open(l11l1111l11l_l1_,l1l1ll_l1_ (u"࠭ࡲࡣࠩ榧")).read()
		if kodi_version>18.99: text = text.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ榨"))
		text = text.replace(l1l1ll_l1_ (u"ࠨ࡞ࡵࠫ榩"),l1l1ll_l1_ (u"ࠩࠪ榪"))
	l11l111l1l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫ榫"),text,re.DOTALL)
	l11ll1l1l1ll_l1_ = []
	for line in l11l111l1l1l_l1_:
		l111lll11l1l_l1_ = line.lower()
		if l1l1ll_l1_ (u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬ榬") in l111lll11l1l_l1_: continue
		if l1l1ll_l1_ (u"ࠬࡻࡢࡶࡰࡷࡹࠬ榭") in l111lll11l1l_l1_: continue
		#if l1l1ll_l1_ (u"࠭ࡨࡵ࡯࡯ࠫ榮") in l111lll11l1l_l1_: continue
		l11ll1l1l1ll_l1_.append(line)
	useragent = random.sample(l11ll1l1l1ll_l1_,1)
	useragent = useragent[0]
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ榯"),l1l1ll_l1_ (u"ࠨࠩ榰"),str(len(l11l111l1l1l_l1_)),useragent)
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ榱"),l1l1ll_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭榲"),useragent,l1llll1l1_l1_)
	return useragent
def l11lll11111l_l1_(errortrace):
	#if l1l1ll_l1_ (u"ࠫ࡫ࡵࡲࡤࡧࡧࠤࡪࡾࡩࡵࠩ榳") in str(error).lower(): return
	#errortrace = traceback.format_exc()
	sys.stderr.write(errortrace)
	lines = errortrace.splitlines()
	error = lines[-1]
	l11l1l1ll1ll_l1_ = open(l1l1lllll111_l1_,l1l1ll_l1_ (u"ࠬࡸࡢࠨ榴")).read()
	if kodi_version>18.99: l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ榵"))
	l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_[-8000:]
	sep = l1l1ll_l1_ (u"ࠧ࠾ࠩ榶")*100
	if sep in l11l1l1ll1ll_l1_: l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_.rsplit(sep,1)[1]
	if error in l11l1l1ll1ll_l1_: l11l1l1ll1ll_l1_ = l11l1l1ll1ll_l1_.rsplit(error,1)[0]
	#l11llll1l1_l1_(l1l1ll_l1_ (u"ࠨࠩ榷"),error,l11l1l1ll1ll_l1_)
	#loglines = l11l1l1ll1ll_l1_.splitlines()
	#for line in reversed(loglines):
	#	if l1l1ll_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬ榸") in line: continue
	#	if l1l1ll_l1_ (u"ࠪࡑࡴࡪࡥ࠻ࠢ࡞ࠫ榹") not in line: continue
	l1lll111l1l1_l1_ = re.findall(l1l1ll_l1_ (u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪ榺"),l11l1l1ll1ll_l1_,re.DOTALL)
	for typ,source in reversed(l1lll111l1l1_l1_):
		#if l1l1ll_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࠧ榻") in source: continue
		#if l1l1ll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࠩ榼") in source: continue
		if source: break
	else: source = l1l1ll_l1_ (u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧ榽")
	#l11llll1l1_l1_(l1l1ll_l1_ (u"ࠨࠩ榾"),source,str(l1lll111l1l1_l1_))
	file,line,func = l1l1ll_l1_ (u"ࠩࠪ榿"),l1l1ll_l1_ (u"ࠪࠫ槀"),l1l1ll_l1_ (u"ࠫࠬ槁")
	l11l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไฯูฦ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ槂")+error
	source2 = l1l1ll_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ุำึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ槃")+source
	for l111llll1lll_l1_ in reversed(lines):
		if l1l1ll_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠧ槄") in l111llll1lll_l1_ and l1l1ll_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ槅") in l111llll1lll_l1_: break
	l111llll1lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬ槆"),l111llll1lll_l1_,re.DOTALL)
	if l111llll1lll_l1_:
		file,line,func = l111llll1lll_l1_[0]
		if l1l1ll_l1_ (u"ࠪ࠳ࠬ槇") in file: file = file.rsplit(l1l1ll_l1_ (u"ࠫ࠴࠭槈"),1)[1]
		else: file = file.rsplit(l1l1ll_l1_ (u"ࠬࡢ࡜ࠨ槉"),1)[1]
		l111l111111l_l1_ = l1l1ll_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็็ๅ࠿ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ槊")+file
		line2 = l1l1ll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆึ฻ึࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ構")+line
		l11ll111l11l_l1_ = l1l1ll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็้่อๆ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ槌")+func
		l11l1l1lll1l_l1_ = l111l111111l_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ槍")+line2+l1l1ll_l1_ (u"ࠪࡠࡳ࠭槎")+l11ll111l11l_l1_+l1l1ll_l1_ (u"ࠫࡡࡴࠧ槏")+source2+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ槐")+l11l11l1ll1_l1_
		l111ll1ll1l1_l1_ = line2+l1l1ll_l1_ (u"࠭࡜࡯ࠩ槑")+source2+l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ槒")+l11l11l1ll1_l1_+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ槓")+l111l111111l_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ槔")+l11ll111l11l_l1_
		l11ll1l1ll1l_l1_ = line2+l1l1ll_l1_ (u"ࠪࡠࡳ࠭槕")+l11l11l1ll1_l1_+l1l1ll_l1_ (u"ࠫࡡࡴࠧ槖")+l111l111111l_l1_+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ槗")+l11ll111l11l_l1_
	else:
		l111l111111l_l1_,line2,l11ll111l11l_l1_ = l1l1ll_l1_ (u"࠭ࠧ様"),l1l1ll_l1_ (u"ࠧࠨ槙"),l1l1ll_l1_ (u"ࠨࠩ槚")
		l11l1l1lll1l_l1_ = source2+l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ槛")+l11l11l1ll1_l1_
		l111ll1ll1l1_l1_ = source2+l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ槜")+l11l11l1ll1_l1_
		l11ll1l1ll1l_l1_ = l11l11l1ll1_l1_
	#DIALOG_NOTIFICATION(file+line+func,error,l1l1ll_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ槝"),time=2000)
	l11ll1111lll_l1_ = l1l1ll_l1_ (u"ࠬำฯฬࠢั฻ศฺ๋ࠦำ้ࠣ็฻่ะࠩ槞")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ槟")
	l1111l1ll1_l1_ = l1l11lllll1_l1_()
	l11l111111ll_l1_ = []
	results = l1111l1ll1_l1_[l1l1ll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ槠")]
	l111llll1l11_l1_ = l1111ll11l11_l1_(addon_version)
	if l1l1ll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭槡") in list(l1111l1ll1_l1_.keys()):
		for l111l1l1llll_l1_,l11l1l111111_l1_,l11ll1l11lll_l1_ in results: l11l111111ll_l1_ = max(l11l111111ll_l1_,l11l1l111111_l1_)
		if l111llll1l11_l1_<l11l111111ll_l1_:
			header = l1l1ll_l1_ (u"ࠩๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨ槢")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ槣"),l1l1ll_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ槤"),l1l1ll_l1_ (u"ࠬะอะ์ฮࠫ槥"),l1l1ll_l1_ (u"࠭ฮา๊ฯࠫ槦"),l11ll1111lll_l1_+header,l11l1l1lll1l_l1_)
			if choice==0:
				yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ槧"),l1l1ll_l1_ (u"ࠨะิ์ั࠭槨"),l1l1ll_l1_ (u"ࠩอัิ๐หࠨ槩"),l1l1ll_l1_ (u"ࠪࠫ槪"),header)
				if yes==1: choice = 1
			if choice==1:
				import l1ll1l1lll11_l1_
				l1ll1l1lll11_l1_.l1l1ll111l1l_l1_()
			return
	l1111l1ll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ槫"),l1l1ll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ槬"),l1l1ll_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ槭"))
	if not l1111l1ll1ll_l1_: l1111l1ll1ll_l1_ = []
	l111ll1ll1l1_l1_ = l111ll1ll1l1_l1_.replace(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ槮"),l1l1ll_l1_ (u"ࠨ࡞࡟ࡲࠬ槯")).replace(l1l1ll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ槰"),l1l1ll_l1_ (u"ࠪࠫ槱")).replace(l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ槲"),l1l1ll_l1_ (u"ࠬ࠭槳")).replace(l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ槴"),l1l1ll_l1_ (u"ࠧࠨ槵"))
	l11ll1l1ll1l_l1_ = l11ll1l1ll1l_l1_.replace(l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ槶"),l1l1ll_l1_ (u"ࠩ࡟ࡠࡳ࠭槷")).replace(l1l1ll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ槸"),l1l1ll_l1_ (u"ࠫࠬ槹")).replace(l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ槺"),l1l1ll_l1_ (u"࠭ࠧ槻")).replace(l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ槼"),l1l1ll_l1_ (u"ࠨࠩ槽"))
	l1111ll1l1ll_l1_ = addon_version+l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ槾")+l11ll1l1ll1l_l1_
	if l1111ll1l1ll_l1_ in l1111l1ll1ll_l1_:
		header = l1l1ll_l1_ (u"่ࠪ็ีࠠใ็อࠤฬ์สࠡีสฬ็อࠠษวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ槿")
		#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ樀"),l1l1ll_l1_ (u"ࠬิั้ฮࠪ樁"),l1l1ll_l1_ (u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ樂"),l11ll1111lll_l1_+header,l11l1l1lll1l_l1_)
		#if yes==1: DIALOG_OK(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ樃"),l1l1ll_l1_ (u"ࠨะิ์ั࠭樄"),l1l1ll_l1_ (u"ࠩࠪ樅"),header)
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ樆"),l1l1ll_l1_ (u"ࠫࠬ樇"),l11ll1111lll_l1_+header,l11l1l1lll1l_l1_)
		return
	l1111lll11ll_l1_ = str(kodi_version).split(l1l1ll_l1_ (u"ࠬ࠴ࠧ樈"))[0]
	#l11ll1ll1111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ樉"),l1l1ll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ樊"),l1l1ll_l1_ (u"ࠨࡃࡏࡐࡤࡑࡎࡐ࡙ࡑࡣࡊࡘࡒࡐࡔࡖࠫ樋"))
	url = WEBSITES[l1l1ll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ樌")][6]
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ樍"),url,l1l1ll_l1_ (u"ࠫࠬ樎"),l1l1ll_l1_ (u"ࠬ࠭樏"),l1l1ll_l1_ (u"࠭ࠧ樐"),l1l1ll_l1_ (u"ࠧࠨ樑"),l1l1ll_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ樒"),False,False)
	html = response.content
	l11ll1ll1111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ樓"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭樔"),l1l1ll_l1_ (u"ࠫࡆࡒࡌࡠࡍࡑࡓ࡜ࡔ࡟ࡆࡔࡕࡓࡗ࡙ࠧ樕"),l11ll1ll1111_l1_,REGULAR_CACHE)
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭樖"),line+l1l1ll_l1_ (u"࠭ࠠࠡࠢࠪ樗")+error+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠫ樘")+addon_version+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠬ標")+l1111lll11ll_l1_)
	for l11ll1111l11_l1_,l11ll1l11ll1_l1_,l11l11l11l1l_l1_,l111ll1ll11l_l1_ in l11ll1ll1111_l1_:
		l11ll1111l11_l1_ = l11ll1111l11_l1_.split(l1l1ll_l1_ (u"ࠩ࠮ࠫ樚"))
		l11l11l11l1l_l1_ = l11l11l11l1l_l1_.split(l1l1ll_l1_ (u"ࠪ࠯ࠬ樛"))
		l111ll1ll11l_l1_ = l111ll1ll11l_l1_.split(l1l1ll_l1_ (u"ࠫ࠰࠭樜"))
		#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭樝"),str(l11ll1111l11_l1_)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࠪ樞")+l11ll1l11ll1_l1_+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠫ樟")+str(l11l11l11l1l_l1_)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࠬ樠")+str(l111ll1ll11l_l1_))
		if line in l11ll1111l11_l1_ and error==l11ll1l11ll1_l1_ and addon_version in l11l11l11l1l_l1_ and l1111lll11ll_l1_ in l111ll1ll11l_l1_:
			header = l1l1ll_l1_ (u"๊ࠩิฬࠦวๅะฺวู๋ࠥา๊ไࠤํฺู๊ษ็ะࠥฮวๅวุำฬืࠠศๆๅหิ๋ࠧ模")
			yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ樢"),l1l1ll_l1_ (u"ࠫำื่อࠩ樣"),l1l1ll_l1_ (u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩ樤"),l11ll1111lll_l1_+header,l11l1l1lll1l_l1_)
			if yes==1: DIALOG_OK(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭樥"),l1l1ll_l1_ (u"ࠧࠨ樦"),l1l1ll_l1_ (u"ࠨࠩ樧"),header)
			return
	header = l1l1ll_l1_ (u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩ樨")
	DIALOG_OK(l1l1ll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ権"),l1l1ll_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ横"),l11ll1111lll_l1_+header,l11l1l1lll1l_l1_)
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ樫"),l1l1ll_l1_ (u"࠭ใๅษࠪ樬"),l1l1ll_l1_ (u"ࠧ็฻่ࠫ樭"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ樮"),l1l1ll_l1_ (u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ樯"))
	if yes==1: l1ll1l111l11_l1_ = l1l1ll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭樰")
	else:
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ樱"),l1l1ll_l1_ (u"ࠬ࠭樲"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ樳"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟อ้ࠥหไ฻ษฤࠤสืำศๆࠣห้ิืฤ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬ樴"))
		return
	message = l111ll1ll1l1_l1_
	l1llll1l1111_l1_ = l1l1ll_l1_ (u"ࠨࡃ࡙࠾ࠥ࠭樵")+l1l1l1l1l1l_l1_(32)+l1l1ll_l1_ (u"ࠩ࠰ࡉࡷࡸ࡯ࡳࡵࠪ樶")
	import l1ll1l1lll11_l1_
	succeeded = l1ll1l1lll11_l1_.l111lll1ll1_l1_(l1llll1l1111_l1_,message,True,l1l1ll_l1_ (u"ࠪࠫ樷"),l1l1ll_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡇ࡛ࡍ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭樸"),l1ll1l111l11_l1_)
	if succeeded and l1ll1l111l11_l1_:
		l1111l1ll1ll_l1_.append(l1111ll1l1ll_l1_)
		WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ樹"),l1l1ll_l1_ (u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ樺"),l1111l1ll1ll_l1_,PERMANENT_CACHE)
	return
def l1l1l111lll1_l1_(l11l1111lll1_l1_):
	l11ll111ll11_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡹࡸ࡫ࡲ࠯ࡲࡵ࡭ࡻࡹࠧ樻"))
	#l11l1111lll1_l1_ = l11l1111lll1_l1_.encode(l1l1ll_l1_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ樼")).replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ樽"),l1l1ll_l1_ (u"ࠪࠫ樾"))
	user = l1l1l1l1l1l_l1_(32)
	import hashlib
	md5 = hashlib.md5((l1l1ll_l1_ (u"ࠫ࡝࠷࠹ࠨ樿")+l11l1111lll1_l1_+l1l1ll_l1_ (u"ࠬ࠷࠸࠾ࠩ橀")+user).encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ橁"))).hexdigest()[0:32]
	if md5 in l11ll111ll11_l1_: return True
	return False
def WRITE_THIS(l11l1l1lll_l1_,data):
	if kodi_version>18.99: data = data.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ橂"))
	if l11l1l1lll_l1_==l1l1ll_l1_ (u"ࠨࠩ橃"): filename = l1l1ll_l1_ (u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ橄")
	else: filename = l1l1ll_l1_ (u"ࠪࡷ࠿ࡢ࡜࠱࠲࠳࠴ࡪࡳࡡࡥࡡࠪ橅")+str(now)+l1l1ll_l1_ (u"ࠫ࠳ࡪࡡࡵࠩ橆")
	open(filename,l1l1ll_l1_ (u"ࠬࡽࡢࠨ橇")).write(data)
	return
def l1l1llll1ll1_l1_():
	l11l1llll11l_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ橈"))
	if l11l1llll11l_l1_:
		l1l1lll1l111_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ橉"),l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ橊"),l1l1ll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ橋"))
		if l1l1lll1l111_l1_: return l1l1lll1l111_l1_
	l111l111l11l_l1_ = l1l1l1l1l1l_l1_(32)
	payload = {l1l1ll_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ橌"):l111l111l11l_l1_}
	url = WEBSITES[l1l1ll_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ橍")][5]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ橎"),url,payload,l1l1ll_l1_ (u"࠭ࠧ橏"),l1l1ll_l1_ (u"ࠧࠨ橐"),l1l1ll_l1_ (u"ࠨࠩ橑"),l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ橒"))
	if not response.succeeded: return []
	l11lll11l1l1_l1_ = response.content
	l11lll11l1l1_l1_ = l11lll11l1l1_l1_.replace(l1l1ll_l1_ (u"ࠪࡠࡡࡸࠧ橓"),l1l1ll_l1_ (u"ࠫࡡࡴࠧ橔")).replace(l1l1ll_l1_ (u"ࠬࡢ࡜࡯ࠩ橕"),l1l1ll_l1_ (u"࠭࡜࡯ࠩ橖")).replace(l1l1ll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ橗"),l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ橘")).replace(l1l1ll_l1_ (u"ࠩ࡟ࡶࠬ橙"),l1l1ll_l1_ (u"ࠪࡠࡳ࠭橚")).replace(l1l1ll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ橛"),l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ橜"))
	l11lll11l1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩ橝"),l11lll11l1l1_l1_,re.DOTALL)
	if not l11lll11l1l1_l1_: return []
	l11lll11l1l1_l1_ = sorted(l11lll11l1l1_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1ll111111_l1_,l1l1l1l1l1ll_l1_,answer,l1l11l1l11ll_l1_,reason = l11lll11l1l1_l1_[0]
	if l1l1ll_l1_ (u"ࠧ࡝ࡰ࠾࠿ࠬ橞") not in reason: l111ll11ll11_l1_,l111ll11ll1l_l1_,l111ll11lll1_l1_ = reason,reason,reason
	else: l111ll11ll11_l1_,l111ll11ll1l_l1_,l111ll11lll1_l1_ = reason.split(l1l1ll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭機"),2)
	settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ橠"),l1l1l1l1l1ll_l1_)
	#settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨ࠳ࡲ࡯࡯ࡩࠪ橡"),l111ll11ll11_l1_)
	settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠴࡬ࡰࡰࡪࠫ橢"),l1l1ll_l1_ (u"ࠬ࠭橣"))
	settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ橤"),l1l1ll_l1_ (u"ࠧࠨ橥"))
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ橦"),l1l1ll_l1_ (u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬ橧"),l11lll11l1l1_l1_,REGULAR_CACHE)
	return l11lll11l1l1_l1_
def SPLIT_BIGLIST(l11ll1l1111l_l1_,splits_count):
	length = len(l11ll1l1111l_l1_)
	l11ll1ll1l11_l1_ = []
	for ii in range(1,splits_count+1):
		if ii!=splits_count:
			l11l1lllllll_l1_ = l11ll1l1111l_l1_[0:int(length/splits_count)]
			del l11ll1l1111l_l1_[0:int(length/splits_count)]
		else:
			l11l1lllllll_l1_ = l11ll1l1111l_l1_
			del l11ll1l1111l_l1_
		l11ll1ll1l11_l1_.append(l11l1lllllll_l1_)
		del l11l1lllllll_l1_
	return l11ll1ll1l11_l1_
def l11l1ll1ll11_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l1l1ll_l1_ (u"ࠪࡨࡺࡳ࡭ࡺࡰࡤࡱࡪ࠭橨"),data)
	#text = pickle.dumps(dummy)
	if 1 or l1l1ll_l1_ (u"ࠫࡎࡖࡔࡗࡡࠪ橩") not in filename or l1l1ll_l1_ (u"ࠬࡓ࠳ࡖࡡࠪ橪") not in filename: text = str(data)
	else:
		l1lll1l11ll1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l1ll_l1_ (u"࠭ࠧ橫")
		for split in l1lll1l11ll1_l1_:
			text += str(split)+l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭橬")
		text = text.strip(l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ橭"))
	compressed = zlib.compress(text)
	open(filepath,l1l1ll_l1_ (u"ࠩࡺࡦࠬ橮")).write(compressed)
	return
def l11ll1l1l11l_l1_(results_type,filename):
	if results_type==l1l1ll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ橯"): data = {}
	elif results_type==l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ橰"): data = []
	elif results_type==l1l1ll_l1_ (u"ࠬࡹࡴࡳࠩ橱"): data = l1l1ll_l1_ (u"࠭ࠧ橲")
	elif results_type==l1l1ll_l1_ (u"ࠧࡪࡰࡷࠫ橳"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	compressed = open(filepath,l1l1ll_l1_ (u"ࠨࡴࡥࠫ橴")).read()
	text = zlib.decompress(compressed)
	#open(l1l1ll_l1_ (u"ࠩࡶ࠾ࡡࡢࡉࡑࡖ࡙࠵࠳ࡺࡸࡵࠩ橵"),l1l1ll_l1_ (u"ࠪࡻࡧ࠭橶")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l1l1ll_l1_ (u"ࠫࡩࡻ࡭࡮ࡻࡱࡥࡲ࡫ࠧ橷"))
	#if l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ橸") not in text: data = EVAL(l1l1ll_l1_ (u"࠭ࡳࡵࡴࠪ橹"),text)
	if l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭橺") not in text: data = eval(text)
	else:
		l1lll1l11ll1_l1_ = text.split(l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ橻"))
		del text
		data = []
		l11ll11l1111_l1_ = l111ll11lll_l1_()
		id = 0
		for split in l1lll1l11ll1_l1_:
			#data += EVAL(l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭橼"),split)
			l11ll11l1111_l1_.l11l1lllll11_l1_(str(id),eval,split)
			id += 1
		del l1lll1l11ll1_l1_
		l11ll11l1111_l1_.l111ll111l11_l1_()
		l11ll11l1111_l1_.l1111ll1l1l1_l1_()
		l1111llll11l_l1_ = list(l11ll11l1111_l1_.l11l11ll1l1l_l1_.keys())
		l111l111llll_l1_ = sorted(l1111llll11l_l1_,reverse=False,key=lambda key: int(key))
		for id in l111l111llll_l1_:
			data += l11ll11l1111_l1_.l11l11ll1l1l_l1_[id]
	return data
def l1l11lll1ll_l1_(addon_id):
	l111l1l11111_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ橽"),addon_id,l1l1ll_l1_ (u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ橾"))
	try: l11l111l11l1_l1_ = open(l111l1l11111_l1_,l1l1ll_l1_ (u"ࠬࡸࡢࠨ橿")).read()
	except:
		l111lll111ll_l1_ = os.path.join(l11l11l1llll_l1_,l1l1ll_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭檀"),addon_id,l1l1ll_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ檁"))
		try: l11l111l11l1_l1_ = open(l111lll111ll_l1_,l1l1ll_l1_ (u"ࠨࡴࡥࠫ檂")).read()
		except: return l1l1ll_l1_ (u"ࠩࠪ檃"),[]
	if kodi_version>18.99: l11l111l11l1_l1_ = l11l111l11l1_l1_.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ檄"))
	version = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࡠࡢࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠦࡡ࠭࡝ࠨ檅"),l11l111l11l1_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l1ll_l1_ (u"ࠬ࠭檆"),[]
	l11lll11l1ll_l1_,l11l11lllll1_l1_ = version[0],l1111ll11l11_l1_(version[0])
	return l11lll11l1ll_l1_,l11l11lllll1_l1_
def l1l11lllll1_l1_():
	l1l11ll1l11_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡤࡪࡥࡷࠫ檇"),l1l1ll_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ檈"),l1l1ll_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ檉"))
	if l1l11ll1l11_l1_: return l1l11ll1l11_l1_
	l1111l1ll1_l1_,l1l11ll1l11_l1_ = {},{}
	l1lll111l1l1_l1_ = [WEBSITES[l1l1ll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ檊")][1]]
	if kodi_version>17.99: l1lll111l1l1_l1_.append(WEBSITES[l1l1ll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ檋")][2])
	if kodi_version>18.99: l1lll111l1l1_l1_.append(WEBSITES[l1l1ll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ檌")][3])
	for l111l11ll1ll_l1_ in l1lll111l1l1_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ檍"),l111l11ll1ll_l1_,l1l1ll_l1_ (u"࠭ࠧ檎"),l1l1ll_l1_ (u"ࠧࠨ檏"),l1l1ll_l1_ (u"ࠨࠩ檐"),False,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭檑"))
		if response.succeeded:
			html = response.content
			l1111lll1111_l1_ = l111l11ll1ll_l1_.rsplit(l1l1ll_l1_ (u"ࠪ࠳ࠬ檒"),1)[0]
			l11l1l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ檓"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l11l1ll1l111_l1_ in l11l1l11lll1_l1_:
				l11l1llll1l1_l1_ = l1111lll1111_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧ檔")+addon_id+l1l1ll_l1_ (u"࠭࠯ࠨ檕")+addon_id+l1l1ll_l1_ (u"ࠧ࠮ࠩ檖")+l11l1ll1l111_l1_+l1l1ll_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠭檗")
				if addon_id not in list(l1111l1ll1_l1_.keys()):
					l1111l1ll1_l1_[addon_id] = []
					l1l11ll1l11_l1_[addon_id] = []
				l11l11l1l11l_l1_ = l1111ll11l11_l1_(l11l1ll1l111_l1_)
				l1111l1ll1_l1_[addon_id].append((l11l1ll1l111_l1_,l11l11l1l11l_l1_,l11l1llll1l1_l1_))
	for addon_id in list(l1111l1ll1_l1_.keys()):
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ檘"),str(addon_id)+l1l1ll_l1_ (u"ࠪࠤࠥ࠴ࠠࠡࠩ檙")+str(l1111l1ll1_l1_[addon_id]))
		l1l11ll1l11_l1_[addon_id] = sorted(l1111l1ll1_l1_[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ檚"),l1l1ll_l1_ (u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭檛"),l1l11ll1l11_l1_,REGULAR_CACHE)
	return l1l11ll1l11_l1_
	l1l1ll_l1_ (u"ࠨࠢࠣࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧࠪࠏࠍࠍࡸࡵࡵࡳࡥࡨࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ࠭ࠒࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦࠩ࠯ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸ࡭ࡻࡢࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬࡯ࡴࡩࡷࡥ࠲ࡨࡵ࡭࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠳ࡐࡕࡄࡊ࠱ࡵࡥࡼ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡵࡤࡦࡤࡨࡶ࡬࠴࡯ࡳࡩ࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡤࡵࡥࡳࡩࡨ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡥࡢ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡧࡸࡡ࡯ࡥ࡫࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࡟ࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵࡭ࡢࡵࡷࡩࡷ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪࡡ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴࡯ࡵࡪࡨࡶࡸ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡲࡧࡳࡵࡧࡵ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࡟ࠬࠑࠏࠏࡳࡰࡷࡵࡧࡪࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡧࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶࡨࡩ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠵࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࠦࠧࠨ檜")
def l1111ll11l11_l1_(l11l1ll1l111_l1_):
	l11l11l1l11l_l1_ = []
	l1ll1ll1l1l_l1_ = l11l1ll1l111_l1_.split(l1l1ll_l1_ (u"ࠧ࠯ࠩ檝"))
	for l1l11l1lll_l1_ in l1ll1ll1l1l_l1_:
		parts = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࡧ࠯ࢁࡡ࡜ࠬ࡞࠰ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࠬ檞"),l1l11l1lll_l1_,re.DOTALL)
		l1l111llll1l_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l111llll1l_l1_.append(part)
		l11l11l1l11l_l1_.append(l1l111llll1l_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ檟"),str(l11l1ll1l111_l1_)+l1l1ll_l1_ (u"ࠪࠤࠥ࠴ࠠࠡࠩ檠")+str(l11l11l1l11l_l1_))
	return l11l11l1l11l_l1_
def l111ll1l1l1l_l1_(l11l11l1l11l_l1_):
	l11l1ll1l111_l1_ = l1l1ll_l1_ (u"ࠫࠬ檡")
	for l1l11l1lll_l1_ in l11l11l1l11l_l1_:
		for part in l1l11l1lll_l1_: l11l1ll1l111_l1_ += str(part)
		l11l1ll1l111_l1_ += l1l1ll_l1_ (u"ࠬ࠴ࠧ檢")
	l11l1ll1l111_l1_ = l11l1ll1l111_l1_.strip(l1l1ll_l1_ (u"࠭࠮ࠨ檣"))
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ檤"),str(l11l11l1l11l_l1_)+l1l1ll_l1_ (u"ࠨࠢࠣ࠲ࠥࠦࠧ檥")+str(l11l1ll1l111_l1_))
	return l11l1ll1l111_l1_
def l1l1l1l1llll_l1_(l1l11ll1111_l1_=l1l1lll1111l_l1_):
	# l111l1l111l1_l1_ not l11ll11lll1l_l1_ l111ll1111ll_l1_ l111l11l11l1_l1_ l1111l1ll1_l1_ status l11111l111_l1_ l11ll1l111_l1_ l11l111l11_l1_ l11l1lll1l1l_l1_
	#l1ll1l11l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ檦"),l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭檧"),l1l1ll_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ檨"))
	#if l1ll1l11l1l1_l1_: return l1ll1l11l1l1_l1_
	l1ll1l11l1l1_l1_ = {}
	l1111l1ll1_l1_ = l1l11lllll1_l1_()
	l1l1lll1l11l_l1_ = l1l11lll1lll_l1_(l1l11ll1111_l1_)
	for addon_id in l1l11ll1111_l1_:
		if addon_id not in list(l1111l1ll1_l1_.keys()): continue
		#if not l1111l1ll1_l1_[addon_id]: continue
		l1l11ll1l11_l1_ = l1111l1ll1_l1_[addon_id]
		l1l11llll11_l1_,l1l11lll1l1_l1_,l1l11l11lll_l1_ = l1l11ll1l11_l1_[0]
		#l1l11l11l1l_l1_ = xbmc.getInfoLabel(l1l1ll_l1_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬ檩")+addon_id+l1l1ll_l1_ (u"࠭ࠩࠨ檪"))
		l1l11l11l1l_l1_,l1l11l1ll1l_l1_ = l1l11lll1ll_l1_(addon_id)
		l1l1lll11l1l_l1_,l1ll11111l11_l1_ = l1l1lll1l11l_l1_[addon_id]
		l1l11l1llll_l1_ = l1l11lll1l1_l1_>l1l11l1ll1l_l1_ and l1l1lll11l1l_l1_
		l1l11l1l1ll_l1_ = True
		if not l1l1lll11l1l_l1_: l1ll111ll111_l1_ = l1l1ll_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ檫")
		elif not l1ll11111l11_l1_: l1ll111ll111_l1_ = l1l1ll_l1_ (u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ檬")
		elif l1l11l1llll_l1_: l1ll111ll111_l1_ = l1l1ll_l1_ (u"ࠩࡲࡰࡩ࠭檭")
		else:
			l1ll111ll111_l1_ = l1l1ll_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ檮")
			l1l11l1l1ll_l1_ = False
		l1ll1l11l1l1_l1_[addon_id] = (l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1ll1l_l1_,l1l11llll11_l1_,l1l11lll1l1_l1_,l1ll111ll111_l1_,l1l11l11lll_l1_)
	#WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ檯"),l1l1ll_l1_ (u"ࠬࡋࡍࡂࡆࡢࡅࡉࡊࡏࡏࡕࡢࡈࡊ࡚ࡁࡊࡎࡖࠫ檰"),l1ll1l11l1l1_l1_,REGULAR_CACHE)
	return l1ll1l11l1l1_l1_
	l1l1ll_l1_ (u"ࠨࠢࠣࠏࠍࠍࠨ࡯ࡦࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࡥࡶࡦࡴ࠯࡭ࡸࡥࡥࡹ࡫ࡶࡸ࠱࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡂࠦࡶࡦࡴࡶ࡭ࡴࡴࠬࡕࡴࡸࡩ࠱࡚ࡲࡶࡧࠐࠎࠎࠩࡥ࡭ࡵࡨ࠾ࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠱࡯ࡳࡠࡧࡻ࡭ࡸࡺࠬࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡࠩࠪ࠰ࡋࡧ࡬ࡴࡧ࠯ࡊࡦࡲࡳࡦࠏࠍࠍࠨ࡯ࡳࡠࡧࡻ࡭ࡸࡺࠠ࠾ࠢࠫࡼࡧࡳࡣ࠯ࡩࡨࡸࡈࡵ࡮ࡥࡘ࡬ࡷ࡮ࡨࡩ࡭࡫ࡷࡽ࠭࠭ࡓࡺࡵࡷࡩࡲ࠴ࡈࡢࡵࡄࡨࡩࡵ࡮ࠩࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠩࠨࠫࡀࡁ࠶࠯ࠍࠋࠋࠦ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡀࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵࡂࠬ࠭ࠍࠋࠋࠦ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥ࡯ࡳࡠࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤ࠭ࡾࡢ࡮ࡥ࠱࡫ࡪࡺࡃࡰࡰࡧ࡚࡮ࡹࡩࡣ࡫࡯࡭ࡹࡿࠨࠨࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡉࡴࡇࡱࡥࡧࡲࡥࡥࠪࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠪࠩࠬࡁࡂ࠷ࠩࠎࠌࠌࠧࡪࡲࡳࡦ࠼ࠣ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠠ࠾ࠢࡱࡳࡹࠦࠨࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡪࡵࡢࡩࡽ࡯ࡳࡵࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࡠࡣࡹࡥ࡮ࡲࡡࡣ࡮ࡨࡣࡻ࡫ࡲࡠࡥࡲࡱࡵࡧࡲࡦࠋࠌࠫ࠰ࡹࡴࡳࠪ࡫࡭࡬࡮ࡥࡴࡶࡢࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࡥࡶࡦࡴࡢࡧࡴࡳࡰࡢࡴࡨ࠭࠮ࠓࠊࠊࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲࡠࡥࡲࡱࡵࡧࡲࡦࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࡯ࡳࡠ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠬ࠭ࠒࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠌࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡰࡤࡦࡱ࡫ࡤࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡳࡱࡪࠉࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡵ࡬ࡥࠫࠬࠑࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬࡴࡥࡦࡦࡢࡹࡵࡪࡡࡵࡧࠌࠍࠬ࠱ࡳࡵࡴࠫࡲࡪ࡫ࡤࡠࡷࡳࡨࡦࡺࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡴࡶࡤࡸࡺࡹࠉࠊࠩ࠮ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡷࡹࡧࡴࡶࡵࠬ࠭ࠒࠐࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࡴ࠼ࠣࠤࠬ࠱ࡳࡵࡴࠫࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲࠪ࠭ࠪࠤࠥ࠭ࠫࡴࡶࡵࠬ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠯ࠫࠨࠢࠣࠫ࠰ࡹࡴࡳࠪ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩ࠯ࠩࠎࠌࠌࠦࠧࠨ檱")
def PROGRESS_UPDATE(pDialog,l11l11lll1l1_l1_,l11ll11111ll_l1_=l1l1ll_l1_ (u"ࠧࠨ檲"),line2=l1l1ll_l1_ (u"ࠨࠩ檳"),l11ll1111l11_l1_=l1l1ll_l1_ (u"ࠩࠪ檴")):
	if kodi_version<19: pDialog.update(l11l11lll1l1_l1_,l11ll11111ll_l1_,line2,l11ll1111l11_l1_)
	else: pDialog.update(l11l11lll1l1_l1_,l11ll11111ll_l1_+l1l1ll_l1_ (u"ࠪࡠࡳ࠭檵")+line2+l1l1ll_l1_ (u"ࠫࡡࡴࠧ檶")+l11ll1111l11_l1_)
	return
def l1lll1l111l1_l1_(l1llll1l111l_l1_):
	# l11ll11lll1l_l1_ it for this:  function(p,a,c,k,e,d)
	# l1ll1lllll1l_l1_ l111l1l1l11l_l1_:  l1lll11l_l1_://l111llll1ll1_l1_.io
	def l11l111l111l_l1_(num,b,l111l1ll1ll1_l1_=l1l1ll_l1_ (u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠧ檷")):
		return ((num == 0) and l111l1ll1ll1_l1_[0]) or (l11l111l111l_l1_(num // b, b, l111l1ll1ll1_l1_).lstrip(l111l1ll1ll1_l1_[0]) + l111l1ll1ll1_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l1ll_l1_ (u"ࠨ࡜࡝ࡤࠥ檸") + l11l111l111l_l1_(c, a) + l1l1ll_l1_ (u"ࠢ࡝࡞ࡥࠦ檹"),  k[c], p)
		return p
	l1llll1l111l_l1_ = l1llll1l111l_l1_.split(l1l1ll_l1_ (u"ࠨࡿࠫࠫ檺"))[1][:-1]
	l1lll11l1l11_l1_ = eval(l1l1ll_l1_ (u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ檻")+l1llll1l111l_l1_,{l1l1ll_l1_ (u"ࠪࡦࡦࡹࡥࡏࠩ檼"):l11l111l111l_l1_,l1l1ll_l1_ (u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ檽"):unpack})   #,locals())
	return l1lll11l1l11_l1_
def l1lll111ll_l1_(url,l111lll1lll1_l1_=l1l1ll_l1_ (u"ࠬ࠭檾")):
	if l111lll1lll1_l1_==l1l1ll_l1_ (u"࠭࡬ࡰࡹࡨࡶࠬ檿"): url = re.sub(l1l1ll_l1_ (u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧ櫀"),lambda l11ll1lllll1_l1_: l11ll1lllll1_l1_.group(0).lower(),url)
	elif l111lll1lll1_l1_==l1l1ll_l1_ (u"ࠨࡷࡳࡴࡪࡸࠧ櫁"): url = re.sub(l1l1ll_l1_ (u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩ櫂"),lambda l11ll1lllll1_l1_: l11ll1lllll1_l1_.group(0).upper(),url)
	return url
def l1l11lll1lll_l1_(l1l11ll1111_l1_):
	installed,l11l11ll1111_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l1lll111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l1l11ll1111_l1_)==1: l11l11111l1l_l1_ = l1l1ll_l1_ (u"ࠪࠬࠧ࠭櫃")+l1l11ll1111_l1_[0]+l1l1ll_l1_ (u"ࠫࠧ࠯ࠧ櫄")
	else: l11l11111l1l_l1_ = str(tuple(l1l11ll1111_l1_))
	cc.execute(l1l1ll_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬ櫅")+l11l11111l1l_l1_+l1l1ll_l1_ (u"࠭ࠠ࠼ࠩ櫆"))
	rows = cc.fetchall()
	l1l1lll1l11l_l1_ = {}
	for addon_id in l1l11ll1111_l1_: l1l1lll1l11l_l1_[addon_id] = (False,False)
	for addon_id,l11l11ll1111_l1_ in rows:
		installed = True
		l11l11ll1111_l1_ = l11l11ll1111_l1_==1
		l1l1lll1l11l_l1_[addon_id] = (installed,l11l11ll1111_l1_)
	conn.close()
	return l1l1lll1l11l_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	if file==l1ll1111lll1_l1_: results = []
	else: results = {}
	if os.path.exists(file):
		oldFILE = open(file,l1l1ll_l1_ (u"ࠧࡳࡤࠪ櫇")).read()
		if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭櫈"))
		if file==l1ll1111lll1_l1_: results = EVAL(l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ櫉"),oldFILE)
		else:
			l11l1l111ll1_l1_ = EVAL(l1l1ll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ櫊"),oldFILE)
			if l11l1l111ll1_l1_:
				for key in l11l1l111ll1_l1_.keys():
					results[key] = []
					for l11l111lll11_l1_ in l11l1l111ll1_l1_[key]:
						type,name,url,mode,image,page,text,context,infodict = l1l1ll_l1_ (u"ࠫࠬ櫋"),l1l1ll_l1_ (u"ࠬ࠭櫌"),l1l1ll_l1_ (u"࠭ࠧ櫍"),l1l1ll_l1_ (u"ࠧࠨ櫎"),l1l1ll_l1_ (u"ࠨࠩ櫏"),l1l1ll_l1_ (u"ࠩࠪ櫐"),l1l1ll_l1_ (u"ࠪࠫ櫑"),l1l1ll_l1_ (u"ࠫࠬ櫒"),l1l1ll_l1_ (u"ࠬ࠭櫓")
						type = l11l111lll11_l1_[0]
						name = l11l111lll11_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l11l111lll11_l1_[2]
						mode = l11l111lll11_l1_[3]
						image = l11l111lll11_l1_[4]
						page = l11l111lll11_l1_[5]
						if len(l11l111lll11_l1_)>6: text = l11l111lll11_l1_[6]
						if len(l11l111lll11_l1_)>7: context = l11l111lll11_l1_[7]
						if len(l11l111lll11_l1_)>8: infodict = l11l111lll11_l1_[8]
						if file==favoritesfile: l1111lll1l1l_l1_ = type,name,url,mode,image,page,text,l1l1ll_l1_ (u"࠭ࠧ櫔"),infodict
						else: l1111lll1l1l_l1_ = type,name,url,mode,image,page,text,context,infodict
						results[key].append(l1111lll1l1l_l1_)
		newFILE = str(results)
		if kodi_version>18.99: newFILE = newFILE.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ櫕"))
		open(file,l1l1ll_l1_ (u"ࠨࡹࡥࠫ櫖")).write(newFILE)
	return results
def l1ll111lll1_l1_(site):
	l1ll11l11ll_l1_ = site.split(l1l1ll_l1_ (u"ࠩ࠰ࠫ櫗"),1)[0]
	l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_ = l1l1ll_l1_ (u"ࠪࠫ櫘"),l1l1ll_l1_ (u"ࠫࠬ櫙"),l1l1ll_l1_ (u"ࠬ࠭櫚")
	if   l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ櫛")		:	from l1l1l1l_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ櫜")	:	from l1ll111l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ櫝")		:	from l11llll_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ櫞")	:	from l11l11ll_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ櫟")	:	from l1ll1llll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ櫠")	: 	from l1ll11l1l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ櫡")	:	from l1ll11l11_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ櫢")	:	from l11lll111_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭櫣")		:	from l111l1ll1_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕࠨ櫤")	:	from l1111ll1l_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ櫥")	:	from l1llll11l1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ櫦")	:	from l1lll1l1l1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ櫧")	:	from l1lll11l1l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ櫨"):	from l1l111llll11_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ櫩")		:	from l1ll1ll1111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭櫪")		:	from l1lllll_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ櫫")	:	from l1ll1llll1l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ櫬")	:	from l1llll11ll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ櫭")	:	from l1l111ll1l11_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ櫮")	:	from l1111lll1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅࠬ櫯")	:	from l1l1l1ll111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭櫰")	:	from l1111llll_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭櫱")		:	from l1l1111lllll_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ櫲")	:	from l1l1ll1l11l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ櫳"):	from l1l1ll1l1_l1_	import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫ櫴")	:	from l11l11llll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ櫵")	:	from l1lll11l11_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ櫶"):	from l1l1111ll1_l1_	import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ櫷")	:	from l1111llll1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨ櫸")	:	from l1llll11lll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗࠨ櫹")	:	from l1llll11ll1_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ櫺")	:	from l1ll1lll1ll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ櫻")	:	from l1ll111l11l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭櫼")	:	from l1llll1lll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ櫽")		:	from l1ll111l111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ櫾")		:	from IPTV			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡎ࠵ࡘࠫ櫿")		:	from l1l1l11l1l1_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ欀")	:	from l1l1lll1111_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ欁")	:	from l1l1l1l111l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ欂")	:	from l1l111l1111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ欃")	:	from l1l1111lll1_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ欄")	:	from l1lll111l111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ欅")	:	from l1ll1lll11l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ欆")	:	from l1ll1ll11l1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ欇")		:	from l1l1111ll1l_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ欈")	:	from l1lll11111l1_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭欉")	:	from l1l111ll1lll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭權")	:	from l1l111l1l11l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ欋")	:	from l1ll1ll11lll_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࠭ࡔࡗࡈࡘࡒࠬ欌")		:	from l111111l111_l1_			import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ欍")	:	from l11l1l1l11l_l1_		import MENU as l1ll11l11l1_l1_,SEARCH as l1ll11ll111_l1_,menu_name as l1ll1l1lll1_l1_
	elif l1ll11l11ll_l1_==l1l1ll_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ欎"):	from l11lll11lll1_l1_	import MENU as l1ll11l11l1_l1_
	return l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1111l1ll11l_l1_,headers={},showDialogs=True):
	#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࠪ欏"),l1l1ll_l1_ (u"ࠪࠫ欐"),l1l1ll_l1_ (u"ࠫࠬ欑"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ欒"),l1l1ll_l1_ (u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฼๊่ษ่๊ࠢࠥอไฦ่อี๋ะ้ࠠไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠡࠨ欓"))
	#if yes!=1: return
	LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ欔"),l1l1ll_l1_ (u"ࠨ࠰ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧ欕")+l1111l1ll11l_l1_+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬ欖")+str(headers)+l1l1ll_l1_ (u"ࠪࠤࡢ࠭欗"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ欘"),l1l1ll_l1_ (u"ࠬ๐ฬา์ࠣห้ศๆࠡใะูࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥ๎ศฺั๊หู่ࠥโࠢอฬิษฺࠠ็็๎ฮࠦฬๅสࠣห้๋ไโ่๊ࠢࠥอไฦ่อี๋ะࠧ欙"))
	MegaByte = 1024*1024
	l111l1111lll_l1_ = bytes()
	chunk_size = 1*MegaByte
	import requests
	headers2 = headers
	headers2[l1l1ll_l1_ (u"࠭ࡒࡢࡰࡪࡩࠬ欚")] = l1l1ll_l1_ (u"ࠧࡣࡻࡷࡩࡸࡃ࠰࠮ࠩ欛")
	response = requests.get(l1111l1ll11l_l1_,stream=True,headers=headers2,timeout=120)
	if l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩ欜") not in list(response.headers.keys()):
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ欝"),l1l1ll_l1_ (u"ࠪࠫ欞"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ欟"),l1l1ll_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ฯ๋ใ็่๊ࠢࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤํอไิสหࠤ็ี๋ࠠๅ๋๊ࠥ฿ๆะๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢ࠱ࠤัืศࠡฬะ้๏๊ࠠศๆ่่ๆࠦๅาหࠣวำื้ࠨ欠"))
		return
	filesize = int(response.headers[l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ次")])
	l11lll111l_l1_ = str(int(1000*filesize/MegaByte)/1000.0)
	l11l1llll1_l1_ = int(filesize/chunk_size)+1
	if l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧ欢") in list(response.headers.keys()) and filesize>MegaByte:
		l111l1l1lll1_l1_ = True
		ranges = []
		l11ll1l111ll_l1_ = 10
		ranges.append(str(0*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠨ࠯ࠪ欣")+str(1*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(1*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠩ࠰ࠫ欤")+str(2*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(2*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠪ࠱ࠬ欥")+str(3*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(3*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠫ࠲࠭欦")+str(4*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(4*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠬ࠳ࠧ欧")+str(5*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(5*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"࠭࠭ࠨ欨")+str(6*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(6*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠧ࠮ࠩ欩")+str(7*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(7*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠨ࠯ࠪ欪")+str(8*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(8*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠩ࠰ࠫ欫")+str(9*filesize//l11ll1l111ll_l1_-1))
		ranges.append(str(9*filesize//l11ll1l111ll_l1_)+l1l1ll_l1_ (u"ࠪ࠱ࠬ欬"))
		l11ll1l1ll11_l1_ = float(l11l1llll1_l1_)/l11ll1l111ll_l1_
		l11l11l11ll1_l1_ = l11ll1l1ll11_l1_/int(1+l11ll1l1ll11_l1_)
	else:
		l111l1l1lll1_l1_ = False
		l11ll1l111ll_l1_ = 1
		l11l11l11ll1_l1_ = 1
	response.close()
	LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ欭"),l1l1ll_l1_ (u"ࠬ࠴ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧ欮")+str(l111l1l1lll1_l1_)+l1l1ll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ欯")+str(filesize)+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ欰"))
	ii = 0
	#t1 = time.time()-30
	for jj in range(l11ll1l111ll_l1_):
		headers2 = headers
		if l111l1l1lll1_l1_: headers2[l1l1ll_l1_ (u"ࠨࡔࡤࡲ࡬࡫ࠧ欱")] = l1l1ll_l1_ (u"ࠩࡥࡽࡹ࡫ࡳ࠾ࠩ欲")+ranges[jj]
		response = requests.get(l1111l1ll11l_l1_,stream=True,headers=headers2,timeout=120)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if pDialog.iscanceled():
				response.close()
				LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ欳"),l1l1ll_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬ欴"))
				break
			ii += l11l11l11ll1_l1_
			PROGRESS_UPDATE(pDialog,0+int(100*ii/l11l1llll1_l1_),l1l1ll_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭欵"),str(int(ii*chunk_size//MegaByte))+l1l1ll_l1_ (u"࠭ࠠ࠰ࠢࠪ欶")+l11lll111l_l1_+l1l1ll_l1_ (u"ࠧࠡࡏࡅࠫ欷"))
			l111l1111lll_l1_ += chunk
			#PROGRESS_UPDATE(pDialog,0+int(35*ii/l11l1llll1_l1_),l1l1ll_l1_ (u"ࠨฮ็ฬࠥอไๆๆไࠤฬ๊ัว์ึ๎࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ欸")+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ欹")+str(ii*chunksize/MegaByte)+l1l1ll_l1_ (u"ࠪࠤ࠴ࠦࠧ欺")+l11lll111l_l1_+l1l1ll_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩ欻")+time.strftime(l1l1ll_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ欼")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ欽")+time.gmtime(l11l1ll111_l1_))+l1l1ll_l1_ (u"ࠧࠡโࠪ款"))
			#l11l1l1l1l_l1_ = time.time()
			#l11l1l111l_l1_ = l11l1l1l1l_l1_-t1
			#l11l1l1l11_l1_ = l11l1l111l_l1_/ii
			#l11ll11ll1_l1_ = l11l1l1l11_l1_*(l11l1llll1_l1_+1)
			#l11l1ll111_l1_ = l11ll11ll1_l1_-l11l1l111l_l1_
		response.close()
	pDialog.close()
	if len(l111l1111lll_l1_)<filesize:
		LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ欿"),l1l1ll_l1_ (u"ࠩ࠱ࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭歀")+str(len(l111l1111lll_l1_)//MegaByte)+l1l1ll_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋࡸ࡯࡮ࠢࡷࡳࡹࡧ࡬ࠡࡱࡩ࠾ࠥࡡࠠࠨ歁")+l11lll111l_l1_+l1l1ll_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ歂"))
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠬ࠭歃"),l1l1ll_l1_ (u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫ歄"),l1l1ll_l1_ (u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧ歅"),l1l1ll_l1_ (u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪ歆"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ歇"),l1l1ll_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧ歈")+str(len(l111l1111lll_l1_)//MegaByte)+l1l1ll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪ歉")+l11lll111l_l1_+l1l1ll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧ歊"))
		if choice==2: l111l1111lll_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1111l1ll11l_l1_,headers)
		elif choice==1: LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭歋"),l1l1ll_l1_ (u"ࠧ࠯ࠢࠣࠤࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧ歌"))
		else: return
		if not l111l1111lll_l1_: return
	else: LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ歍"),l1l1ll_l1_ (u"ࠩ࠱ࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧ歎")+l11lll111l_l1_+l1l1ll_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠩ歏"))
	return l111l1111lll_l1_
def SEND_ANALYTICS_EVENT(script_name,allow_dns_fix=True,allow_proxy_fix=True):
	# old l11l11ll111l_l1_ l11l11l1lll1_l1_ l1lll11l1lll_l1_
	#l1111ll1lll1_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠶ࠬࡴࡪࡦࡀ࡙ࡆ࠳࠱࠳࠹࠳࠸࠺࠷࠰࠵࠯࠸ࠪࡨ࡯ࡤ࠾ࠩ歐")+l1l1l1l1l1l_l1_(32)+l1l1ll_l1_ (u"ࠬࠬࡴ࠾ࡧࡹࡩࡳࡺࠦࡴࡥࡀࡩࡳࡪࠦࡦࡥࡀࠫ歑")+addon_version+l1l1ll_l1_ (u"࠭ࠦࡢࡸࡀࠫ歒")+addon_version+l1l1ll_l1_ (u"ࠧࠧࡣࡱࡁࡆࡘࡁࡃࡋࡆࡣ࡛ࡏࡄࡆࡑࡖࡣࡓࡋࡗࡄࡎࡌࡉࡓ࡚ࡉࡅࠨࡨࡥࡂ࠭歓")+script_name+l1l1ll_l1_ (u"ࠨࠨࡨࡰࡂ࠭歔")+str(kodi_version)+l1l1ll_l1_ (u"ࠩࠩࡾࡂ࠭歕")+l1111ll1lll1_l1_
	#response = OPENURL_REQUESTS(l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ歖"),url,l1l1ll_l1_ (u"ࠫࠬ歗"),l1l1ll_l1_ (u"ࠬ࠭歘"),l1l1ll_l1_ (u"࠭ࠧ歙"),False,l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ歚"))
	# l111l1ll1lll_l1_ test:    l1lll11l_l1_://l1ll111ll1ll_l1_-l1l11lllllll_l1_-l1l1l1l1111l_l1_.l1ll1lll1ll1_l1_/l111ll1lll11_l1_/l11l1l1l1l1l_l1_-l111l1l1ll11_l1_
	# l111l1ll1lll_l1_ json method:    l1lll11l_l1_://l1111ll111ll_l1_.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/l111lllll111_l1_/l11l1111ll11_l1_/l11l1llllll1_l1_/protocol/l111ll1lll11_l1_/l111lllll1ll_l1_/l111l1ll1lll_l1_
	# l111l1ll1lll_l1_ json method:    l1lll11l_l1_://l1111ll111ll_l1_.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/l111lllll111_l1_/l11l1111ll11_l1_/l11l1llllll1_l1_/protocol/l111ll1lll11_l1_/l111lllll1ll_l1_?l111l111l1ll_l1_=l1111lllll11_l1_
	# l111l1ll1lll_l1_ hit method:   l1lll11l_l1_://l1l1ll1llll_l1_.l11l1l11l1ll_l1_.l1lll1ll1_l1_/l111ll1lll11_l1_-l11l1l1l1lll_l1_-protocol-l11l11l111l1_l1_
	# l111l1ll1lll_l1_ hit method:   l1lll11l_l1_://l1l1ll1llll_l1_.l11l1l11l1ll_l1_.l1lll1ll1_l1_/l11l111ll11_l1_-l11ll1l1l111_l1_-l1ll1lll1ll1_l1_-l111lllll111_l1_-l11l1l1l1lll_l1_-protocol-version-2
	# l111l1ll11ll_l1_ json method
	#url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵࡭ࡱ࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡥࡵ࡯࡟ࡴࡧࡦࡶࡪࡺ࠽࠱࠯ࡹ࠵࠺ࡇࡤࡤࡔࡊࡥࡕ࡭ࡱࡳࡱࡪࡰ࠺࠿ࡋࡂࠨࡰࡩࡦࡹࡵࡳࡧࡰࡩࡳࡺ࡟ࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠩ歛")
	#headers = {l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ歜"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭歝")}
	#params = {l1l1ll_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠩ歞"):script_name,l1l1ll_l1_ (u"ࠬࡧࡶࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ歟"):addon_version,l1l1ll_l1_ (u"࠭࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ歠"):kodi_version}
	#data = {l1l1ll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺ࡟ࡪࡦࠪ歡"):l1l1l1l1l1l_l1_(32),l1l1ll_l1_ (u"ࠨࡧࡹࡩࡳࡺࡳࠨ止"):[{l1l1ll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ正"):l1l1ll_l1_ (u"ࠪࡅࡗࡇࡂࡊࡅࡢ࡚ࡎࡊࡅࡐࡕࡢࡋࡆ࠺ࠧ此"),l1l1ll_l1_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ步"):params}]}
	#response = OPENURL_REQUESTS(l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ武"),url,str(data),headers,l1l1ll_l1_ (u"࠭ࠧ歧"),False,l1l1ll_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ歨"))
	# l111l1ll11ll_l1_ hit method
	url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡧ࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠷ࠬࡴࡪࡦࡀࡋ࠲ࡘࡐ࠸ࡓ࡜ࡉࡏ࠿ࡇ࠺ࠨࡦ࡭ࡩࡃࠧ歩")+l1l1l1l1l1l_l1_(32)+l1l1ll_l1_ (u"ࠩࠩࡣࡸࡃ࠱ࠧࡧࡱࡁࠬ歪")+script_name+l1l1ll_l1_ (u"ࠪࠪࡺࡶ࠮ࡢࡸࡢࡺࡪࡸ࠽ࠨ歫")+addon_version+l1l1ll_l1_ (u"ࠫࠫࡻࡰ࠯࡭ࡲࡨ࡮ࡥࡶࡦࡴࡀࠫ歬")+str(kodi_version)
	response = OPENURL_REQUESTS(l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ歭"),url,l1l1ll_l1_ (u"࠭ࠧ歮"),l1l1ll_l1_ (u"ࠧࠨ歯"),l1l1ll_l1_ (u"ࠨࠩ歰"),False,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ歱"))
	return response
def l1l11lll1111_l1_(l1lll1l1111l_l1_=l1l1ll_l1_ (u"ࠪࠫ歲")):
	l1ll1111l11l_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡸࡺࡲࠨ歳"),l1l1ll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ歴"),l1l1ll_l1_ (u"࠭ࡉࡑࡎࡒࡇࡆ࡚ࡉࡐࡐࠪ歵"))
	if l1ll1111l11l_l1_: return l1ll1111l11l_l1_
	# url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡰࡴࡩࡡࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ歶")
	# l1lll11l1lll_l1_   url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡴࡼ࡮࡯ࡪࡵ࠱ࡥࡵࡶ࠯࡫ࡵࡲࡲ࠴࠭歷")+l1lll1l1111l_l1_
	# l111l1ll111l_l1_   url = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ歸")
	url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡽࡨࡰ࠰࡬ࡷ࠴࠭歹")+l1lll1l1111l_l1_+l1l1ll_l1_ (u"ࠫࡄࡵࡵࡵࡲࡸࡸࡂࡰࡳࡰࡰࠩࡪ࡮࡫࡬ࡥࡵࡀࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ歺")
	response = OPENURL_REQUESTS(l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ死"),url,l1l1ll_l1_ (u"࠭ࠧ歼"),l1l1ll_l1_ (u"ࠧࠨ歽"),l1l1ll_l1_ (u"ࠨࠩ歾"),False,l1l1ll_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡊࡒࡏࡓࡈࡇࡔࡊࡑࡑ࠱࠶ࡹࡴࠨ歿"))
	html = response.content
	l11ll1111111_l1_ = EVAL(l1l1ll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ殀"),html)
	l111l1l11l11_l1_,country,l111lll111l1_l1_,l11l11llllll_l1_,timezone = l1l1ll_l1_ (u"ࠫࠬ殁"),l1l1ll_l1_ (u"ࠬ࠭殂"),l1l1ll_l1_ (u"࠭ࠧ殃"),l1l1ll_l1_ (u"ࠧࠨ殄"),l1l1ll_l1_ (u"ࠨࠩ殅")
	if l1l1ll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡧࡱࡸࠬ殆") in list(l11ll1111111_l1_.keys()): l111l1l11l11_l1_ = l11ll1111111_l1_[l1l1ll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭殇")]
	if l1l1ll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ殈") in list(l11ll1111111_l1_.keys()): country = l11ll1111111_l1_[l1l1ll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭殉")]
	if l1l1ll_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭殊") in list(l11ll1111111_l1_.keys()): l111lll111l1_l1_ = l11ll1111111_l1_[l1l1ll_l1_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ残")]
	if l1l1ll_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭殌") in list(l11ll1111111_l1_.keys()): l11l11llllll_l1_ = l11ll1111111_l1_[l1l1ll_l1_ (u"ࠩࡦ࡭ࡹࡿࠧ殍")]
	if l1l1ll_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ殎") in list(l11ll1111111_l1_.keys()):
		timezone = l11ll1111111_l1_[l1l1ll_l1_ (u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭殏")][l1l1ll_l1_ (u"ࠬࡻࡴࡤࠩ殐")]
		if timezone[0] not in [l1l1ll_l1_ (u"࠭࠭ࠨ殑"),l1l1ll_l1_ (u"ࠧࠬࠩ殒")]: timezone = l1l1ll_l1_ (u"ࠨ࠭ࠪ殓")+timezone
	l1ll1111l11l_l1_ = l111l1l11l11_l1_+l1l1ll_l1_ (u"ࠩ࠯ࠫ殔")+country+l1l1ll_l1_ (u"ࠪ࠰ࠬ殕")+l111lll111l1_l1_+l1l1ll_l1_ (u"ࠫ࠱࠭殖")+l11l11llllll_l1_+l1l1ll_l1_ (u"ࠬ࠲ࠧ殗")+timezone
	if kodi_version>18.99: l1ll1111l11l_l1_ = l1ll1111l11l_l1_.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ殘")).decode(l1l1ll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ殙"))
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ殚"),l1l1ll_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭殛"),l1ll1111l11l_l1_,l1llll1l1_l1_)
	return l1ll1111l11l_l1_
#=================================================================================
# the l1111l1l1l_l1_ function l111111l11l_l1_ added from:
# l1lll11l_l1_://l111llll11_l1_.l1lll1ll1_l1_/l11111l1l1_l1_/l1111lllll_l1_-host-l11111llll_l1_/-/l111l11lll_l1_/l111ll1111_l1_/l111111l1l_l1_/l11111l1ll_l1_/l1111l1lll1l_l1_.py
# l1lll11l_l1_://l1111l11l1_l1_.l1lll1ll1_l1_/l111111lll_l1_/l1111lll11_l1_-l1111l1ll1_l1_/l111l11lll_l1_/l111ll1111_l1_/l1111l1111_l1_.l11lll11l1_l1_.l111lll1ll_l1_/l111l1l111_l1_/l1111llll1ll_l1_/l1llll1ll1l_l1_.py
# l11l1l1llll1_l1_ to the l111ll1lll1l_l1_ l1l1ll_l1_ (u"ࠥࡖ࡬ࡿࡳࡰࡨࡷࠦ殜")
#=================================================================================
def l1lll111l1_l1_(data):
	page = data
	if l1l1ll_l1_ (u"ࠫࡦࡪࡩ࡭ࡤࡲࡣࡍ࡚ࡍࡍࡡࡨࡲࡨࡵࡤࡦࡴࠪ殝") in data:
		l11ll1111l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂࡳࡤࡴ࡬ࡴࡹ࠴ࠪࡀ࠽࠱࠮ࡄࡢࠧࠩ࠰࠭ࡃ࠮ࡁࠧ殞"), data, re.S)
		l11l1ll11ll1_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠯ࡨ࠰࠱࠲࠳࠴ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ殟"), data, re.S)
		if l11ll1111l1l_l1_ and l11l1ll11ll1_l1_:
			l111ll11ll_l1_ = l11ll1111l1l_l1_[0].replace(l1l1ll_l1_ (u"ࠢࠨࠤ殠"),l1l1ll_l1_ (u"ࠨࠩ殡"))
			l111ll11ll_l1_ = l111ll11ll_l1_.replace(l1l1ll_l1_ (u"ࠤ࠮ࠦ殢"),l1l1ll_l1_ (u"ࠪࠫ殣"))
			l111ll11ll_l1_ = l111ll11ll_l1_.replace(l1l1ll_l1_ (u"ࠦࡡࡴࠢ殤"),l1l1ll_l1_ (u"ࠬ࠭殥"))
			l11l1lll1l11_l1_ = l111ll11ll_l1_.split(l1l1ll_l1_ (u"࠭࠮ࠨ殦"))
			page = l1l1ll_l1_ (u"ࠧࠨ殧")
			for l111l1111l_l1_ in l11l1lll1l11_l1_:
				l11l1111l1ll_l1_ = base64.b64decode(l111l1111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࡀࠫ殨")).decode(l1l1ll_l1_ (u"ࠤࡸࡸ࡫࠳࠸ࠣ殩"))
				l11l1lll1111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡠࡩ࠱ࠧ殪"), l11l1111l1ll_l1_, re.S)
				if l11l1lll1111_l1_:
					l1111ll11ll1_l1_ = int(l11l1lll1111_l1_[0])+int(l11l1ll11ll1_l1_[0])
					page = page + chr(l1111ll11ll1_l1_)
			if kodi_version>18.99: page = page.encode(l1l1ll_l1_ (u"ࠫ࡮ࡹ࡯࠮࠺࠻࠹࠾࠳࠱ࠨ殫")).decode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ殬"))
	return page
def SEARCH_OPTIONS(search):
	options,showDialogs = l1l1ll_l1_ (u"࠭ࠧ殭"),True
	if search.count(l1l1ll_l1_ (u"ࠧࡠࠩ殮"))>=2:
		search,options = search.split(l1l1ll_l1_ (u"ࠨࡡࠪ殯"),1)
		options = l1l1ll_l1_ (u"ࠩࡢࠫ殰")+options
		if l1l1ll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ殱") in options: showDialogs = False
		else: showDialogs = True
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ殲"),l1l1ll_l1_ (u"ࠬ࠭殳"),search,options)
	return search,options,showDialogs
def l1l11l1l111_l1_(showDialogs):
	url = WEBSITES[l1l1ll_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭殴")][3]
	l111l111l11l_l1_ = l1l1l1l1l1l_l1_(32)
	payload = {l1l1ll_l1_ (u"ࠧࡶࡵࡨࡶࠬ段"):l111l111l11l_l1_,l1l1ll_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ殶"):addon_version}
	if showDialogs: DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ殷"),(l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ殸"),url,payload,l1l1ll_l1_ (u"ࠫࠬ殹"),l1l1ll_l1_ (u"ࠬ࠭殺"),l1l1ll_l1_ (u"࠭ࠧ殻"),l1l1ll_l1_ (u"ࠧࡎࡇࡑ࡙ࡘ࠳ࡓࡉࡑ࡚ࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪ殼")))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭殽"),url,payload,l1l1ll_l1_ (u"ࠩࠪ殾"),l1l1ll_l1_ (u"ࠪࠫ殿"),l1l1ll_l1_ (u"ࠫࠬ毀"),l1l1ll_l1_ (u"ࠬࡓࡅࡏࡗࡖ࠱ࡘࡎࡏࡘࡡࡐࡉࡘ࡙ࡁࡈࡇࡖ࠱࠶ࡹࡴࠨ毁"),True,True)
	if not response.succeeded: l1l11l1l11l_l1_ = l1l1ll_l1_ (u"࠭ࡅࡓࡔࡒࡖࠬ毂")
	else:
		l11ll111ll11_l1_,l11l1l1111ll_l1_,l11l1l11l1l1_l1_,l11l1l111l11_l1_ = l1l1ll_l1_ (u"ࠧࠨ毃"),l1l1ll_l1_ (u"ࠨࠩ毄"),l1l1ll_l1_ (u"ࠩࠪ毅"),[]
		newfile = response.content
		if newfile:
			l11l1l111l11_l1_ = EVAL(l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ毆"),newfile)
			for l11l11111lll_l1_,l111l1l11ll1_l1_,message in l11l1l111l11_l1_:
				if kodi_version>18.99: message = message.encode(l1l1ll_l1_ (u"ࠫࡷࡧࡷࡠࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ毇")).decode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ毈"))
				if l11l11111lll_l1_==l1l1ll_l1_ (u"࠭࠰ࠨ毉"): l11ll111ll11_l1_ += message+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ毊")
				else: l11l1l1111ll_l1_ += message+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ毋")
			l11l1l1111ll_l1_ = l11l1l1111ll_l1_.strip(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ毌"))
			l11ll111ll11_l1_ = l11ll111ll11_l1_.strip(l1l1ll_l1_ (u"ࠪ࠾࠿࠭母"))
		settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡶࡵࡨࡶ࠳ࡶࡲࡪࡸࡶࠫ毎"),l11ll111ll11_l1_)
		settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭每"),str(now))
		if os.path.exists(l1ll1111lll1_l1_): l11l1l11l1l1_l1_ = open(l1ll1111lll1_l1_,l1l1ll_l1_ (u"࠭ࡲࡣࠩ毐")).read()
		if kodi_version>18.99: l11l1l1111ll_l1_ = l11l1l1111ll_l1_.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ毑"))
		if l11l1l1111ll_l1_==l11l1l11l1l1_l1_: l1l11l1l11l_l1_ = l1l1ll_l1_ (u"ࠨࡑࡏࡈࠬ毒")
		else:
			l1l11l1l11l_l1_ = l1l1ll_l1_ (u"ࠩࡑࡉ࡜࠭毓")
			open(l1ll1111lll1_l1_,l1l1ll_l1_ (u"ࠪࡻࡧ࠭比")).write(l11l1l1111ll_l1_)
		if showDialogs:
			l1l11l1l11l_l1_ = l1l1ll_l1_ (u"ࠫࡔࡒࡄࠨ毕")
			l11l1l111l11_l1_ = sorted(l11l1l111l11_l1_,reverse=True,key=lambda key: int(key[0]))
			l1l1ll11l1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭毖")
			for l11l11111lll_l1_,l111l1l11ll1_l1_,message in l11l1l111l11_l1_:
				if kodi_version>18.99: message = message.encode(l1l1ll_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ毗")).decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ毘"))
				if l1l1ll11l1l1_l1_: l1l1ll11l1l1_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯ࠩ毙")
				if l11l11111lll_l1_==l1l1ll_l1_ (u"ࠩ࠳ࠫ毚"): continue
				date = message.split(l1l1ll_l1_ (u"ࠪࡠࡳ࠭毛"))[0]
				l1111111_l1_ = l1l1ll_l1_ (u"ࠫࠬ毜")
				if l111l1l11ll1_l1_:
					l1111111_l1_ = l1l1ll_l1_ (u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩ毝")
					if kodi_version>18.99: l1111111_l1_ = l1111111_l1_.encode(l1l1ll_l1_ (u"࠭ࡲࡢࡹࡢࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ毞")).decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ毟"))
				l1l1ll11l1l1_l1_ += message.replace(date,l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ毠")+date+l1111111_l1_+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ毡"))+l1l1ll_l1_ (u"ࠪࡠࡳ࠭毢")
			l1l1ll11l1l1_l1_ = escapeUNICODE(l1l1ll11l1l1_l1_)
			l11llll1l1_l1_(l1l1ll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ毣"),l1l1ll_l1_ (u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨ毤"),l1l1ll11l1l1_l1_,l1l1ll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ毥"))
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ毦"))
	settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭毧"),l1l11l1l11l_l1_)
	return l1l11l1l11l_l1_
def GET_EMPTY_VALUE(type):
	if type==l1l1ll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ毨"): data = {}
	elif type==l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ毩"): data = []
	elif type==l1l1ll_l1_ (u"ࠫࡸࡺࡲࠨ毪"): data = l1l1ll_l1_ (u"ࠬ࠭毫")
	elif type==l1l1ll_l1_ (u"࠭ࡩ࡯ࡶࠪ毬"): data = 0
	elif type==l1l1ll_l1_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ毭"): data = empty_response()
	elif not type: data = None
	else: data = None
	return data
def GET_VIDEOFILETYPE(url,website=l1l1ll_l1_ (u"ࠨࠩ毮")):
	videofiletype = re.findall(l1l1ll_l1_ (u"ࠩࠫࡠ࠳ࡧࡶࡪࡾ࡟࠲ࡹࡹࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࡽ࡞࠱ࡻࡪࡨ࡭ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠦࠪ毯"),url.lower(),re.DOTALL|re.IGNORECASE)
	if videofiletype: videofiletype = videofiletype[0][0]
	else: videofiletype = l1l1ll_l1_ (u"ࠪࠫ毰")
	return videofiletype
	#elif not videofiletype and l1l1ll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘࠬ毱") in website: videofiletype = l1l1ll_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ毲")
	#elif not videofiletype and l1l1ll_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ毳") in website: videofiletype = l1l1ll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ毴")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l11llll1llll_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l11llll1llll_l1_ = False
	l11l1l1l1l_l1_ = time.time()
	if l11llll1llll_l1_: resp = l11l1l1l1l_l1_-t1
	return resp
def FIX_ALL_DATABASES(showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࠩ毵"),l1l1ll_l1_ (u"ࠩࠪ毶"),l1l1ll_l1_ (u"ࠪࠫ毷"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ毸"),l1l1ll_l1_ (u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥฮั็ษ่ะࠥ฿ๅศัࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหึ฽๎้ࠦ็ั้ࠣห้฿ๅๅ์ฬࠤฬ๊ย็ࠢยࠥࠦ࠭毹"))
	else: yes = True
	if yes==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l1ll_l1_ (u"࠭࠮ࡥࡤࠪ毺")) and l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥࡤ࠭毻") in filename:
				dbfile = os.path.join(addoncachefolder,filename)
				conn = sqlite3.connect(dbfile)
				cc = conn.cursor()
				SET_SQL3_CONNECTION(cc)
				cc.execute(l1l1ll_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡱࡸࡪ࡭ࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭࠾ࠫ毼"))
				cc.execute(l1l1ll_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡲࡴࡹ࡯࡭ࡪࡼࡨ࠿ࠬ毽"))
				cc.execute(l1l1ll_l1_ (u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫ毾"))
				conn.commit()
				conn.close()
				if showDialogs:
					DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ毿"),l1l1ll_l1_ (u"ࠬ࠭氀"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ氁"),l1l1ll_l1_ (u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣฬึ์วๆฮࠣ฽๊อฯࠨ氂"))
	return
def EVAL(results_type,text):
	#text = text.replace(l1l1ll_l1_ (u"ࠣࡷࠪࠦ氃"),l1l1ll_l1_ (u"ࠤࠪࠦ氄"))
	text = text.replace(l1l1ll_l1_ (u"ࠪࡲࡺࡲ࡬ࠨ氅"),l1l1ll_l1_ (u"ࠫࡓࡵ࡮ࡦࠩ氆"))
	text = text.replace(l1l1ll_l1_ (u"ࠬࡺࡲࡶࡧࠪ氇"),l1l1ll_l1_ (u"࠭ࡔࡳࡷࡨࠫ氈"))
	text = text.replace(l1l1ll_l1_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭氉"),l1l1ll_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧ氊"))
	try: text2 = eval(text)
	except: text2 = GET_EMPTY_VALUE(results_type)
	return text2
def FORCED_EXIT(message):
	eval(l1l1ll_l1_ (u"ࠩࡢࡣࡋࡕࡒࡄࡇࡇࡣࡊ࡞ࡉࡕࡡࡢࠫ氋")+message)
	return
if __name__==l1l1ll_l1_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬ氌"):
	# l111l11l1l11_l1_ l1lll1l1_l1_ when l1111l1ll111_l1_
	LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ氍"),l1l1ll_l1_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠪ氎"))
	if 0:
		url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡵ࡮ࡦ࠱ࡹ࡭ࡩ࡫࡯ࡠࡲ࡯ࡥࡾ࡫ࡲࡀࡷ࡬ࡨࡂ࠶ࠦࡷ࡫ࡧࡁ࡫࡬ࡢ࠸࠲࠻ࡧ࠶࠿࠲ࡤ࠴࠻ࡨ࠶࠷࠲࠱࠴ࡤࡨ࠶࠾ࡤࡥ࠳࠵ࡧ࠻࠾࠰࠷ࠩ氏")
		import ll_l1_
		a,b,c = ll_l1_.l1ll1lll11l_l1_(url)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ氐"),l1l1ll_l1_ (u"ࠨࠩ民"),l1l1ll_l1_ (u"ࠩࠪ氒"),str(c))
		l1l1ll1ll1l_l1_ = c[0][0]
		#LOG_THIS(l1l1ll_l1_ (u"ࠪࠫ氓"),l1l1ll1ll1l_l1_)
		l1l1ll1ll1l_l1_ = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸ࠲࠴࠯࠰ࡦࡰࡿࡣࡧࡥ࡯࡮࠳ࡩ࠮ࡴࡥࡧࡲ࠳ࡺ࡯࠰ࡵࡷࡶࡪࡧ࡭࠰ࡸ࠴࠳࡭ࡲࡳ࠰࠵ࡧ࡙࡙ࡌ࠷࡚࠹ࡈࡆࡌࡲࡕࡳࡘࡍࡎࡹ࠸ࡋࡘࡩ࠲࠵࠻࠾࠳࠷࠻࠼࠶࠾࠺࠯ࡢ࡮࡯࠳ࡦࡲ࡬࠰࠳࠳࠻࠳࠷࠵࠺࠰࠴࠸࠳࠺࠳࠰ࡻࡨࡷ࠴ࡉࡁ࠰࠲࠲࠴࠻࠳࠰࠳࠱࠵࠳࡫࡬ࡢ࠸࠲࠻ࡧ࠶࠿࠲ࡤ࠴࠻ࡨ࠶࠷࠲࠱࠴ࡤࡨ࠶࠾ࡤࡥ࠳࠵ࡧ࠻࠾࠰࠷࠱࠴࠹࠺ࡥࡨࡥ࠹࠵࠴ࡧࡥࡰ࡭ࡣࡼࡰ࡮ࡹࡴ࠯࡯࠶ࡹ࠽࠭气")
		#PLAY_VIDEO(l1l1ll1ll1l_l1_)
		l1111llllll1_l1_ = xbmcgui.ListItem()
		#l1111llllll1_l1_.setPath(l1l1ll1ll1l_l1_)
		#xbmcplugin.setResolvedUrl(addon_handle,True,l1111llllll1_l1_)
		xbmc.Player().play(l1l1ll1ll1l_l1_,l1111llllll1_l1_)
	else:
		errortrace = l1l1ll_l1_ (u"ࠬ࠭氕")
		l1ll1ll1l_l1_(l1l1ll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ氖"))
		try: l11l11l1l1l1_l1_()
		except Exception as error: errortrace = traceback.format_exc()
		l1ll1ll1l_l1_(l1l1ll_l1_ (u"ࠧࡴࡶࡲࡴࠬ気"))
		if errortrace:
			#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ氘"),l1l1ll_l1_ (u"ࠩࡈࡉࡒࡓࡁࡂࡆࡇ࠾ࠥࠦࠧ氙")+errortrace)
			if l1l1ll_l1_ (u"ࠪࡣࡤࡌࡏࡓࡅࡈࡈࡤࡋࡘࡊࡖࡢࡣࠬ氚") not in errortrace: l11lll11111l_l1_(errortrace)
			else:
				l111l11l111l_l1_ = errortrace.splitlines()
				for line in reversed(l111l11l111l_l1_):
					if l1l1ll_l1_ (u"ࠫࡤࡥࡆࡐࡔࡆࡉࡉࡥࡅ࡙ࡋࡗࡣࡤ࠭氛") in line:
						line = line.split(l1l1ll_l1_ (u"ࠬࡥ࡟ࡇࡑࡕࡇࡊࡊ࡟ࡆ࡚ࡌࡘࡤࡥࠧ氜"))[1]
						sys.stderr.write(l1l1ll_l1_ (u"࠭࡜࡯ࡈࡒࡖࡈࡋࡄࠡࡇ࡛ࡍ࡙ࡀ࡜࡯ࠩ氝")+line)
						sys.stderr.write(l1l1ll_l1_ (u"ࠧ࡝ࡰࡢࠫ氞"))
						break
		refresh = settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ氟"))
		if refresh==l1l1ll_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ氠"): settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ氡"),l1l1ll_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ氢"))
		elif refresh==l1l1ll_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ氣"): settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ氤"),l1l1ll_l1_ (u"ࠧࠨ氥"))
		if settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ氦")) not in [l1l1ll_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ氧"),l1l1ll_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ氨"),l1l1ll_l1_ (u"ࠫࡆ࡙ࡋࠨ氩")]: settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ氪"),l1l1ll_l1_ (u"࠭ࡁࡔࡍࠪ氫"))
		if settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ氬")) not in [l1l1ll_l1_ (u"ࠨࡃࡘࡘࡔ࠭氭"),l1l1ll_l1_ (u"ࠩࡖࡘࡔࡖࠧ氮"),l1l1ll_l1_ (u"ࠪࡅࡘࡑࠧ氯")]: settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭氰"),l1l1ll_l1_ (u"ࠬࡇࡓࡌࠩ氱"))
		l1l1llllll11_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ氲"))
		l1l11l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ氳"))
		if l1l1ll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ水") in str(l1l11l1lllll_l1_) and l1l1llllll11_l1_ in [l1l1ll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ氵"),l1l1ll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ氶")]:
			#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠫࠬ氷"),l1l1llllll11_l1_)
			time.sleep(0.100)
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩ永"))
		#l11ll1l1l1l1_l1_ = sys.version_info[0]
		#l11l1llll1ll_l1_ = sys.version_info[1]
		#if l11ll1l1l1l1_l1_==2: python_version = l1l1ll_l1_ (u"࠭࠲࠸ࠩ氹")
		#else: python_version = str(l11ll1l1l1l1_l1_)+str(l11l1llll1ll_l1_)
		#l11ll1ll1ll1_l1_ = os.path.join(addonfolder,l1l1ll_l1_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ氺")+python_version)
		if 0 and addon_handle>-1:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ氻"),l1l1ll_l1_ (u"ࠩࠪ氼"),l1l1ll_l1_ (u"ࠪࠫ氽"),str(addon_handle))
			xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
			succeeded,updateListing,cacheToDisc = False,False,False
			xbmcplugin.endOfDirectory(addon_handle,succeeded,updateListing,cacheToDisc)
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
headers = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࣓ࠩ") : l1l1ll_l1_ (u"࠭ࠧࣔ") }
script_name = l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭ࣕ")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡄࡏࡔࡥࠧࣖ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l11l1l1_l1_ = [l1l1ll_l1_ (u"ࠩไ๎้๋ࠧࣗ"),l1l1ll_l1_ (u"ࠪ็้๐ศࠨࣘ"),l1l1ll_l1_ (u"ࠫฬู๊าุࠣห้อำษ๊฼๎ࠬࣙ"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬࣚ"),l1l1ll_l1_ (u"࠭ๅิำะ๎์࠭ࣛ"),l1l1ll_l1_ (u"ࠧศ฼้๎ฮ࠭ࣜ"),l1l1ll_l1_ (u"ࠨษ฼่ฬ์ࠧࣝ"),l1l1ll_l1_ (u"ࠩ็ๆฬวࠧࣞ")]
def MAIN(mode,url,text):
	if   mode==70: results = MENU()
	elif mode==71: results = CATEGORIES(url)
	elif mode==72: results = l11l1l_l1_(url,text)
	elif mode==73: results = l111lll_l1_(url)
	elif mode==74: results = PLAY(url)
	elif mode==79: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࣟ"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࣠"),l1l1ll_l1_ (u"ࠬ࠭࣡"),79,l1l1ll_l1_ (u"࠭ࠧ࣢"),l1l1ll_l1_ (u"ࠧࠨࣣ"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࣤ"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣥ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࣦࠬ")+menu_name+l1l1ll_l1_ (u"ุ๊ࠫำๅหࠣหๆ๊วๆࠩࣧ"),l1l1ll_l1_ (u"ࠬ࠭ࣨ"),79,l1l1ll_l1_ (u"ࣩ࠭ࠧ"),l1l1ll_l1_ (u"ࠧࠨ࣪"),l1l1ll_l1_ (u"ࠨี็ื้ฯࠠศใ็ห๊࠭࣫"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࣬"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ࣭ࠬ")+menu_name+l1l1ll_l1_ (u"ุ๊ࠫวิๆ้๋ࠣ๎ูส࣮ࠩ"),l1l1ll_l1_ (u"࣯ࠬ࠭"),79,l1l1ll_l1_ (u"ࣰ࠭ࠧ"),l1l1ll_l1_ (u"ࠧࠨࣱ"),l1l1ll_l1_ (u"ࠨี็ื้ฯࣲࠧ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣳ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬࣴ")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬࣵ"),l1l1l1_l1_,72,l1l1ll_l1_ (u"ࣶࠬ࠭"),l1l1ll_l1_ (u"࠭ࠧࣷ"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩࣸ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣹ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࣺࠫ")+menu_name+l1l1ll_l1_ (u"ࠪห้๋า๋ัࠪࣻ"),l1l1l1_l1_,72,l1l1ll_l1_ (u"ࠫࠬࣼ"),l1l1ll_l1_ (u"ࠬ࠭ࣽ"),l1l1ll_l1_ (u"࠭࡭ࡰࡴࡨࠫࣾ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࣿ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪऀ")+menu_name+l1l1ll_l1_ (u"ࠩส่ศิศศำࠪँ"),l1l1l1_l1_,72,l1l1ll_l1_ (u"ࠪࠫं"),l1l1ll_l1_ (u"ࠫࠬः"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡵࠪऄ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭अ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩआ")+menu_name+l1l1ll_l1_ (u"ࠨษ็วำฮวาࠩइ"),l1l1l1_l1_,72,l1l1ll_l1_ (u"ࠩࠪई"),l1l1ll_l1_ (u"ࠪࠫउ"),l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡴࠩऊ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪऋ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ऌ"),l1l1ll_l1_ (u"ࠧࠨऍ"),9999)
	l1ll11_l1_ = [l1l1ll_l1_ (u"ࠨษ็็ฯฮ้ࠠࠢส่ฬฮอศอࠪऎ"),l1l1ll_l1_ (u"ࠩส่่๎ัิษอࠤฬ๊สฺๆํ้๏ฯࠧए"),l1l1ll_l1_ (u"ࠪห้ษไฺษหࠫऐ"),l1l1ll_l1_ (u"ࠫฬ๊ศาษ่ะࠬऑ"),l1l1ll_l1_ (u"ࠬอไศฮ๊ึฮࠦวๅๆ๋ั๏ฯࠧऒ"),l1l1ll_l1_ (u"࠭วๅื๋ีࠥ๎ࠠศๆั่ๆ๐วหࠩओ"),l1l1ll_l1_ (u"ࠧศๆู่ฬืูสࠢส่าืษࠨऔ")]
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩक"),headers,l1l1ll_l1_ (u"ࠩࠪख"),l1l1ll_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫग"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡲࡵ࡫ࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪघ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫङ"),block,re.DOTALL)
		for link,title in items:
			if title not in l1ll11_l1_:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭च"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩछ")+menu_name+title,link,71)
	return html
def CATEGORIES(url):
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩज"),headers,l1l1ll_l1_ (u"ࠩࠪझ"),l1l1ll_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪञ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸ࡫ࡣࡵࡡࡳࡥࡷࡺࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬट"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧठ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨड"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧढ"),menu_name+title,link,72)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨण"),menu_name+l1l1ll_l1_ (u"ࠩฯ้๏฿ࠠศๆไีํ฿ࠧत"),url,72)
	else: l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࠫथ"))
	return
def l11l1l_l1_(url,type):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬद"),l1l1ll_l1_ (u"ࠬ࠭ध"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"࠭ࠧन"),headers,True,l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪऩ"))
	items = []
	if type==l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪप"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡢࡸ࡮ࡺ࡬ࡦࠢࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹ࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡴࡷࡥ࡮ࡪࡩࡴࡴ࠯ࡦࡶࡴࡻࡳࡦ࡮ࠪफ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥ࡮ࡪࡩࡴࡠࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫब"),block,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫभ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࡣࡷ࡫ࡳࡶ࡮ࡷࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࠩम"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠭य"),block,re.DOTALL)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨर"),l1l1ll_l1_ (u"ࠨࠩऱ"),str(len(items)),block)
	elif type==l1l1ll_l1_ (u"ࠩࡰࡳࡷ࡫ࠧल"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡣࡹ࡯ࡴ࡭ࡧࠣࡱࡴࡸࡥࡠࡶ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵࡣࡧࡵࡴࡵࡱࡰࡣࡸ࡫ࡲࡷ࡫ࡦࡩࡸ࠭ळ"),html,re.DOTALL)
	#elif type==l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡴࠩऴ"):
	#	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡥࡴࡪࡶ࡯ࡩࠥࡴࡥࡸࡵࡢࡸ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯࡮ࡦࡹࡶࡣࡲࡵࡲࡦࡡࡦ࡬ࡴ࡯ࡣࡦࡵࠪव"),html,re.DOTALL)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨश"),html,re.DOTALL)
	if not items and l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸࡻࡢ࡫ࡧࡦࡸࡤࡨ࡯ࡹ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩष"),block,re.DOTALL)
	for link,img,title in items:
		if l1l1ll_l1_ (u"ࠨฬฺ๋๏ำ่ࠠษ่ࠫस") in title: continue
		title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬह"),l1l1ll_l1_ (u"ࠪࠫऺ")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭ऻ"))
		title = unescapeHTML(title)
		if any(value in title for value in l11l1l1_l1_): addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲ़ࠫ"),menu_name+title,link,73,img)
		else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ऽ"),menu_name+title,link,73,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨा"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠣ࠾࠲ࡰ࡮ࡄ࠼࡭࡫ࠣࡂ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨि"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩी"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩु")+title,link,72,l1l1ll_l1_ (u"ࠫࠬू"),l1l1ll_l1_ (u"ࠬ࠭ृ"),type)
	return
def l1l1lll_l1_(url):
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"࠭ࠧॄ"),headers,True,l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠳ࡓࡆࡅࡗࡍࡔࡔࡓ࠮࠴ࡱࡨࠬॅ"))
	url2 = re.findall(l1l1ll_l1_ (u"ࠨࠤ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩॆ"),html,re.DOTALL)
	url2 = url2[1]
	return url2
def l111lll_l1_(url):
	#l11l11l_l1_ = [l1l1ll_l1_ (u"ࠩࡽ࡭ࡵ࠭े"),l1l1ll_l1_ (u"ࠪࡶࡦࡸࠧै"),l1l1ll_l1_ (u"ࠫࡹࡾࡴࠨॉ"),l1l1ll_l1_ (u"ࠬࡶࡤࡧࠩॊ"),l1l1ll_l1_ (u"࠭ࡨࡵ࡯ࠪो"),l1l1ll_l1_ (u"ࠧࡵࡣࡵࠫौ"),l1l1ll_l1_ (u"ࠨ࡫ࡶࡳ्ࠬ"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡲࡲࠧॎ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠪࠫॏ"),headers,True,l1l1ll_l1_ (u"ࠫࡆࡑࡏࡂࡏ࠰ࡗࡊࡉࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩॐ"))
	l1ll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸ࠰࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸ࠴ࡢࡷࠬ࠰࠭ࡃ࠮ࠨࠧ॑"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹࠪ࠻࠱࠲ࡹࡳࡪࡥࡳࡷࡵࡰ࠳ࡩ࡯࡮࠱࡟ࡻ࠰࠴ࠪࡀ॒ࠫࠥࠫ"),html,re.DOTALL)
	if l1ll11l_l1_ or l1l11ll_l1_:
		if l1ll11l_l1_: url3 = l1ll11l_l1_[0]
		elif l1l11ll_l1_: url3 = l1l1lll_l1_(l1l11ll_l1_[0])
		url3 = UNQUOTE(url3)
		import l11llll_l1_
		if l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ॓") in url3 or l1l1ll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡽࡳ࠰ࠩ॔") in url3: l11llll_l1_.l11ll1l_l1_(url3)
		else: l11llll_l1_.PLAY(url3)
		return
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"่ࠩัฯ๎้ࠡษ็ๅ๏๊ๅ࠯ࠬࡂࡂ࠳࠰࠿ࠩ࡞ࡺ࠮ࡄ࠯࡜ࡘࠬࡂࡀࠬॕ"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	items = re.findall(l1l1ll_l1_ (u"ࠪࡀࡧࡸࠠ࠰ࡀ࡟ࡲࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪॖ"),html,re.DOTALL)
	for link,title in items:
		title = unescapeHTML(title)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫॗ"),menu_name+title,link,73)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣࡡࡷ࡭ࡹࡲࡥࠣ࠰࠭ࡃࡁ࡮࠱࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡱࡦ࡯࡮ࡠ࡫ࡰ࡫ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠭࠴ࠪࡀࠫࡤ࡯ࡴ࠳ࡦࡦࡧࡧࡦࡦࡩ࡫ࠨक़"),html,re.DOTALL)
	if not l1lll11_l1_:
		DIALOG_NOTIFICATION(l1l1ll_l1_ (u"࠭ฮุลࠣาฬืฬ๋ࠩख़"),l1l1ll_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็็ๅࠥ็๊ะ์๋ࠫग़"))
		return
	name,img,block = l1lll11_l1_[0]
	name = name.strip(l1l1ll_l1_ (u"ࠨࠢࠪज़"))
	if l1l1ll_l1_ (u"ࠩࡶࡹࡧࡥࡥࡱࡵ࡬ࡳࡩ࡫࡟ࡵ࡫ࡷࡰࡪ࠭ड़") in block:
		items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡺࡨ࡟ࡦࡲࡶ࡭ࡴࡪࡥࡠࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂ࠳࠰࠿ࡴࡷࡥࡣ࡫࡯࡬ࡦࡡࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫढ़"),block,re.DOTALL)
	else:
		filenames = re.findall(l1l1ll_l1_ (u"ࠫࡸࡻࡢࡠࡨ࡬ࡰࡪࡥࡴࡪࡶ࡯ࡩࡡ࠭࠾ࠩ࠰࠭ࡃ࠮ࠦ࠭ࠡ࠾࡬ࡂࠬफ़"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l1l1ll_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫय़"),filename) )
	if not items: items = [ (l1l1ll_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬॠ"),l1l1ll_l1_ (u"ࠧࠨॡ")) ]
	count = 0
	l111l1l_l1_,l1l11l1_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l1l111l_l1_ = l1l1ll_l1_ (u"ࠨࠩॢ")
		if l1l1ll_l1_ (u"ࠩࠣ࠱ࠥ࠭ॣ") in filename: filename = filename.split(l1l1ll_l1_ (u"ࠪࠤ࠲ࠦࠧ।"))[0]
		else: filename = l1l1ll_l1_ (u"ࠫࡩࡻ࡭࡮ࡻ࠱ࡾ࡮ࡶࠧ॥")
		if l1l1ll_l1_ (u"ࠬ࠴ࠧ०") in filename: l1l111l_l1_ = filename.split(l1l1ll_l1_ (u"࠭࠮ࠨ१"))[-1]
		#if any(value in l1l111l_l1_ for value in l11l11l_l1_):
		#	if l1l1ll_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭२") not in title: title = title + l1l1ll_l1_ (u"ࠨ࠼ࠪ३")
		title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ४"),l1l1ll_l1_ (u"ࠪࠫ५")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭६"))
		l111l1l_l1_.append(title)
		l1l11l1_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l11l1l1_l1_):
			if size==1:
				selection = 0
			else:
				#DIALOG_SELECT(l1l1ll_l1_ (u"ࠬ࠭७"),l111l1l_l1_)
				selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ८"), l111l1l_l1_)
				if selection == -1: return
			PLAY(url+l1l1ll_l1_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪ९")+str(1+l1l11l1_l1_[size-selection-1]))
		else:
			for i in reversed(range(size)):
				#if l1l1ll_l1_ (u"ࠨ࠼ࠪ॰") in l111l1l_l1_[i]: title = l111l1l_l1_[i].strip(l1l1ll_l1_ (u"ࠩ࠽ࠫॱ")) + l1l1ll_l1_ (u"ࠪࠤ࠲ࠦๅๅใࠣห้็๊ะ์๋ࠤ฿๐ัࠡ็๋ะํีࠧॲ")
				#else: title = name + l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨॳ") + l111l1l_l1_[i]
				title = name + l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩॴ") + l111l1l_l1_[i]
				title = title.replace(l1l1ll_l1_ (u"࠭࡜࡯ࠩॵ"),l1l1ll_l1_ (u"ࠧࠨॶ")).strip(l1l1ll_l1_ (u"ࠨࠢࠪॷ"))
				link = url + l1l1ll_l1_ (u"ࠩࡂࡷࡪࡩࡴࡪࡱࡱࡁࠬॸ")+str(size-i)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩॹ"),menu_name+title,link,74,img)
	else:
		addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪॺ"),menu_name+l1l1ll_l1_ (u"ࠬอไาษห฻๊๊ࠥิࠢไ๎ิ๐่ࠨॻ"),l1l1ll_l1_ (u"࠭ࠧॼ"),9999,img)
		#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠧฯูฦࠤำอัอ์ࠪॽ"),l1l1ll_l1_ (u"ࠨษ็ีฬฮืࠡๆํืࠥ็๊ะ์๋ࠫॾ"))
	return
def PLAY(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪॿ"),l1l1ll_l1_ (u"ࠪࠫঀ"),url,l1l1ll_l1_ (u"ࠫࠬঁ"))
	url2,l11111_l1_ = url.split(l1l1ll_l1_ (u"ࠬࡅࡳࡦࡥࡷ࡭ࡴࡴ࠽ࠨং"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪঃ"),url2,l1l1ll_l1_ (u"ࠧࠨ঄"),headers,True,l1l1ll_l1_ (u"ࠨࠩঅ"),l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡒࡏࡅ࡞ࡥࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩআ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡥࡩ࠳࠳࠱࠲࠰࠶࠺࠶࠮ࠫࡁࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠮࠮ࠫࡁࠬࡥࡰࡵ࠭ࡧࡧࡨࡨࡧࡧࡣ࡬ࠩই"),html,re.DOTALL)
	l11ll11_l1_ = l1lll11_l1_[0].replace(l1l1ll_l1_ (u"ࠦࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠢঈ"),l1l1ll_l1_ (u"ࠬࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠡࡧࡳࡷࡴ࡯ࡤࡦࡡࡥࡳࡽ࠭উ"))
	l11ll11_l1_ = l11ll11_l1_ + l1l1ll_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠨঊ")
	l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼ࠭࠴ࠪࡀࠫࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࡟ࡣࡱࡻࠫঋ"),l11ll11_l1_,re.DOTALL)
	l11111_l1_ = len(l1l1l11_l1_)-int(l11111_l1_)
	block = l1l1l11_l1_[l11111_l1_]
	l111ll1_l1_ = []
	l1l1ll1_l1_ = {l1l1ll_l1_ (u"ࠨ࠳࠷࠶࠸࠶࠷࠶࠺࠹࠶ࠬঌ"):l1l1ll_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ঍"),l1l1ll_l1_ (u"ࠪ࠵࠹࠽࠷࠵࠺࠺࠺࠵࠷ࠧ঎"):l1l1ll_l1_ (u"ࠫࡪࡹࡴࡳࡧࡤࡱࠬএ"),l1l1ll_l1_ (u"ࠬ࠷࠵࠱࠷࠶࠶࠽࠺࠰࠵ࠩঐ"):l1l1ll_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲࡧ࡮ࡨࡱࠪ঑"),
		l1l1ll_l1_ (u"ࠧ࠲࠶࠵࠷࠵࠾࠰࠱࠳࠸ࠫ঒"):l1l1ll_l1_ (u"ࠨࡨ࡯ࡥࡸ࡮ࡸࠨও"),l1l1ll_l1_ (u"ࠩ࠴࠸࠺࠾࠱࠲࠹࠵࠽࠺࠭ঔ"):l1l1ll_l1_ (u"ࠪࡳࡵ࡫࡮࡭ࡱࡤࡨࠬক"),l1l1ll_l1_ (u"ࠫ࠶࠺࠲࠴࠲࠺࠽࠸࠶࠶ࠨখ"):l1l1ll_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬগ"),l1l1ll_l1_ (u"࠭࠱࠵࠵࠳࠴࠺࠸࠳࠸࠳ࠪঘ"):l1l1ll_l1_ (u"ࠧࡰ࡭࠱ࡶࡺ࠭ঙ"),
		l1l1ll_l1_ (u"ࠨ࠳࠷࠻࠼࠺࠸࠹࠴࠴࠷ࠬচ"):l1l1ll_l1_ (u"ࠩࡷ࡬ࡪࡼࡩࡥࠩছ"),l1l1ll_l1_ (u"ࠪ࠵࠺࠻࠸࠳࠹࠻࠴࠵࠼ࠧজ"):l1l1ll_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫঝ"),l1l1ll_l1_ (u"ࠬ࠷࠴࠸࠹࠷࠼࠼࠿࠹࠱ࠩঞ"):l1l1ll_l1_ (u"࠭ࡶࡪࡦࡷࡳࡩࡵࠧট")}
	items = re.findall(l1l1ll_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡥࡸࡳ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢঠ"),block,re.DOTALL)
	for link in items:
		l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨড"))
	items = re.findall(l1l1ll_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨঢ"),block,re.DOTALL)
	for l11l111_l1_,link in items:
		l11l111_l1_ = l11l111_l1_.split(l1l1ll_l1_ (u"ࠪ࠳ࠬণ"))[-1]
		l11l111_l1_ = l11l111_l1_.split(l1l1ll_l1_ (u"ࠫ࠳࠭ত"))[0]
		if l11l111_l1_ in l1l1ll1_l1_:
			l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭থ")+l1l1ll1_l1_[l11l111_l1_]+l1l1ll_l1_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭দ"))
		else: l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨধ")+l11l111_l1_+l1l1ll_l1_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨন"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ঩"),l1l1ll_l1_ (u"ࠪࠫপ"),url,str(l111ll1_l1_))
	if not l111ll1_l1_:
		message = re.findall(l1l1ll_l1_ (u"ࠫࡸࡻࡢ࠮ࡰࡲ࠱࡫࡯࡬ࡦ࠰࠭ࡃࡡࡴࠨ࠯ࠬࡂ࠭ࡡࡴࠧফ"),block,re.DOTALL)
		if message: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ব"),l1l1ll_l1_ (u"࠭ࠧভ"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩম"),message[0])
	else:
		import ll_l1_
		ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧয"),url)
	return
def SEARCH(search):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪর"),l1l1ll_l1_ (u"ࠪࠫ঱"),search,l1l1ll_l1_ (u"ࠫࠬল"))
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠬ࠭঳"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"࠭ࠧ঴"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ঵"),l1l1ll_l1_ (u"ࠨࠧ࠵࠴ࠬশ"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫষ")+l11lll1_l1_
	results = l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪস"))
	return
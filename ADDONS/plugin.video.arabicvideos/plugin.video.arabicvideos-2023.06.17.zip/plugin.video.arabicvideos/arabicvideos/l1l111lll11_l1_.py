# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈࠬ㹅")
headers = { l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㹆") : l1l1ll_l1_ (u"ࠫࠬ㹇") }
menu_name = l1l1ll_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫ㹈")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1l111lll1_l1_ = WEBSITES[script_name][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l11l1l_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l11ll1l_l1_(url)
	elif mode==188: results = l1l11l11111_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l1l11l11111_l1_():
	message = l1l1ll_l1_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ㹉")
	DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㹊"),l1l1ll_l1_ (u"ࠨࠩ㹋"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㹌"),message)
	return
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㹍"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ㹎"),l1l1ll_l1_ (u"ࠬ࠭㹏"),189,l1l1ll_l1_ (u"࠭ࠧ㹐"),l1l1ll_l1_ (u"ࠧࠨ㹑"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㹒"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㹓"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㹔")+menu_name+l1l1ll_l1_ (u"ࠫอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࠬ㹕"),l1l1l1_l1_,181,l1l1ll_l1_ (u"ࠬ࠭㹖"),l1l1ll_l1_ (u"࠭ࠧ㹗"),l1l1ll_l1_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫ㹘"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㹙"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㹚")+menu_name+l1l1ll_l1_ (u"ࠪวาีหࠡษ็หๆ๊วๆࠩ㹛"),l1l1l1_l1_,181,l1l1ll_l1_ (u"ࠫࠬ㹜"),l1l1ll_l1_ (u"ࠬ࠭㹝"),l1l1ll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭㹞"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㹟"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㹠")+menu_name+l1l1ll_l1_ (u"ࠩอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨ㹡"),l1l1l1_l1_,181,l1l1ll_l1_ (u"ࠪࠫ㹢"),l1l1ll_l1_ (u"ࠫࠬ㹣"),l1l1ll_l1_ (u"ࠬࡺࡶࠨ㹤"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㹥"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㹦")+menu_name+l1l1ll_l1_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨ㹧"),l1l1l1_l1_,181,l1l1ll_l1_ (u"ࠩࠪ㹨"),l1l1ll_l1_ (u"ࠪࠫ㹩"),l1l1ll_l1_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧ㹪"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㹫"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㹬")+menu_name+l1l1ll_l1_ (u"ࠧฤไ๋ํࠥอไศใ็ห๊ࠦวๅฯส่๏ฯࠧ㹭"),l1l1l1_l1_,181,l1l1ll_l1_ (u"ࠨࠩ㹮"),l1l1ll_l1_ (u"ࠩࠪ㹯"),l1l1ll_l1_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㹰"))
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬ㹱"),headers,l1l1ll_l1_ (u"ࠬ࠭㹲"),l1l1ll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㹳"))
	items = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㹴"),html,re.DOTALL)
	for link,title in items:
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㹵"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㹶")+menu_name+title,link,181)
	return html
def l11l1l_l1_(url,type=l1l1ll_l1_ (u"ࠪࠫ㹷")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠫࠬ㹸"),headers,l1l1ll_l1_ (u"ࠬ࠭㹹"),l1l1ll_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ㹺"))
	if type==l1l1ll_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ㹻"): block = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ละำะࠦวๅลไ่ฬ๋࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭㹼"),html,re.DOTALL)[0]
	elif type==l1l1ll_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭㹽"): block = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ㹾"),html,re.DOTALL)[0]
	elif type==l1l1ll_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㹿"): block = re.findall(l1l1ll_l1_ (u"ࠬࡨࡴ࡯࠯࠵࠱ࡴࡼࡥࡳ࡮ࡤࡽ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ㺀"),html,re.DOTALL)[0]
	elif type==l1l1ll_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ㺁"): block = re.findall(l1l1ll_l1_ (u"ࠧࡣࡶࡱ࠱࠶ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠫ࠲࠯ࡅࠩࡣࡶࡱ࠱࠷ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠪ㺂"),html,re.DOTALL)[0]
	elif type==l1l1ll_l1_ (u"ࠨࡶࡹࠫ㺃"): block = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡩࠥࠫ㺄"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l1ll_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭㺅"),l1l1ll_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㺆")]:
		items = re.findall(l1l1ll_l1_ (u"ࠬࡹࡴࡺ࡮ࡨࡁࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㺇"),block,re.DOTALL)
	else: items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠴࡝࠳࠱࠾ࡣࠫࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㺈"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l1l1ll_l1_ = [l1l1ll_l1_ (u"ࠧโ์็้ࠬ㺉"),l1l1ll_l1_ (u"ࠨษ็ั้่ษࠨ㺊"),l1l1ll_l1_ (u"ࠩส่า๊โ่ࠩ㺋"),l1l1ll_l1_ (u"ࠪ฽ึ฼ࠧ㺌"),l1l1ll_l1_ (u"ࠫࡗࡧࡷࠨ㺍"),l1l1ll_l1_ (u"࡙ࠬ࡭ࡢࡥ࡮ࡈࡴࡽ࡮ࠨ㺎"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬ㺏"),l1l1ll_l1_ (u"ࠧศฮีหฦ࠭㺐")]
	for img,l1l111l1l11_l1_,l1l11l1111l_l1_,l1l11l111l1_l1_ in items:
		if type in [l1l1ll_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ㺑"),l1l1ll_l1_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭㺒")]:
			img,link,l111111l1_l1_,title = img,l1l111l1l11_l1_,l1l11l1111l_l1_,l1l11l111l1_l1_
		else: img,title,link,l111111l1_l1_ = img,l1l111l1l11_l1_,l1l11l1111l_l1_,l1l11l111l1_l1_
		link = UNQUOTE(link)
		link = link.replace(l1l1ll_l1_ (u"ࠪࡃࡻ࡯ࡥࡸ࠿ࡷࡶࡺ࡫ࠧ㺓"),l1l1ll_l1_ (u"ࠫࠬ㺔"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㺕"),l1l1ll_l1_ (u"࠭ࠧ㺖"),link,l111111l1_l1_)
		title = unescapeHTML(title)
		#title2 = re.findall(l1l1ll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮࠮ศอ๊าอࢁฮฬ้ั๊࠭ࠬ㺗"),title,re.DOTALL)
		#if title2: title = title2[0][0]
		if l1l1ll_l1_ (u"ࠨสฯ์ิฯࠠࠨ㺘") in title or l1l1ll_l1_ (u"ࠩหะํี็ࠡࠩ㺙") in title:
			title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㺚") + title.replace(l1l1ll_l1_ (u"ࠫอา่ะหࠣࠫ㺛"),l1l1ll_l1_ (u"ࠬ࠭㺜")).replace(l1l1ll_l1_ (u"࠭ศอ๊า๋ࠥ࠭㺝"),l1l1ll_l1_ (u"ࠧࠨ㺞"))
		title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ㺟"))
		if l1l1ll_l1_ (u"ࠩส่า๊โสࠩ㺠") in title or l1l1ll_l1_ (u"ࠪห้ำไใ้ࠪ㺡") in title:
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡢࡤࠬࠩ㺢"),title,re.DOTALL)
			if l11111_l1_:
				title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㺣") + l11111_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺤"),menu_name+title,link,183,img)
					l1l1_l1_.append(title)
		elif any(value in title for value in l11l1l1ll_l1_):
			link = link + l1l1ll_l1_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ㺥") + l111111l1_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㺦"),menu_name+title,link,182,img)
		else:
			link = link + l1l1ll_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ㺧") + l111111l1_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㺨"),menu_name+title,link,183,img)
	if type==l1l1ll_l1_ (u"ࠫࠬ㺩"):
		items = re.findall(l1l1ll_l1_ (u"ࠬࡢ࡮࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㺪"),html,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"࠭วๅืไัฮࠦࠧ㺫"),l1l1ll_l1_ (u"ࠧࠨ㺬"))
			if title!=l1l1ll_l1_ (u"ࠨࠩ㺭"):
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㺮"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ㺯")+title,link,181)
	return
def l11ll1l_l1_(url):
	url2 = url.split(l1l1ll_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ㺰"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠬ࠭㺱"),headers,l1l1ll_l1_ (u"࠭ࠧ㺲"),l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㺳"))
	block = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾࠯ࠬࡂ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠭ࡡ࠰࠮࠻ࡠ࠯࠮ࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㺴"),html,re.DOTALL)
	title,dummy,img = block[0]
	name = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣ࡟࠵࠳࠹࡞࠭ࠪ㺵"),title,re.DOTALL)
	if name: name = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㺶") + name[0][0]
	else: name = title
	items = []
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸࡔࡵ࡮ࡤࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㺷"),html,re.DOTALL)
	if l1lll11_l1_:
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㺸"),l1l1ll_l1_ (u"࠭ࠧ㺹"),url2,str(l1lll11_l1_))
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㺺"),block,re.DOTALL)
		for link in items:
			link = UNQUOTE(link)
			title = re.findall(l1l1ll_l1_ (u"ࠨࠪส่า๊โสࡾส่า๊โ่ࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ㺻"),link.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ㺼"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ㺽"),link.split(l1l1ll_l1_ (u"ࠫ࠴࠭㺾"))[-2],re.DOTALL)
			if title: title = l1l1ll_l1_ (u"ࠬࠦࠧ㺿") + title[0][1]
			else: title = l1l1ll_l1_ (u"࠭ࠧ㻀")
			title = name + l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫ㻁") + l1l1ll_l1_ (u"ࠨษ็ั้่ษࠨ㻂") + title
			title = unescapeHTML(title)
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㻃"),menu_name+title,link,182,img)
	if not items:
		title = unescapeHTML(title)
		if l1l1ll_l1_ (u"ࠪฬั๎ฯสࠢࠪ㻄") in title or l1l1ll_l1_ (u"ࠫอา่ะ้ࠣࠫ㻅") in title:
			title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㻆") + title.replace(l1l1ll_l1_ (u"࠭ศอ๊าอࠥ࠭㻇"),l1l1ll_l1_ (u"ࠧࠨ㻈")).replace(l1l1ll_l1_ (u"ࠨสฯ์ิํࠠࠨ㻉"),l1l1ll_l1_ (u"ࠩࠪ㻊"))
		addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㻋"),menu_name+title,url,182,img)
	return
def PLAY(url):
	l1l11l111ll_l1_ = url.split(l1l1ll_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ㻌"))
	url2 = l1l11l111ll_l1_[0]
	del l1l11l111ll_l1_[0]
	html = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"ࠬ࠭㻍"),headers,l1l1ll_l1_ (u"࠭ࠧ㻎"),l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㻏"))
	link = re.findall(l1l1ll_l1_ (u"ࠨࡨࡲࡲࡹ࠳ࡳࡪࡼࡨ࠾ࠥ࠸࠵ࡱࡺ࠾ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㻐"),html,re.DOTALL)[0]
	if link not in l1l11l111ll_l1_: l1l11l111ll_l1_.append(link)
	l11l1_l1_ = []
	# l1l111lll1l_l1_
	for link in l1l11l111ll_l1_:
		if l1l1ll_l1_ (u"ࠩ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ㻑") in link:
			l1l111lll1l_l1_ = link
			l11l1_l1_.append(l1l111lll1l_l1_+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡦ࡯࡮ࠨ㻒"))
	# l1l111ll1ll_l1_
	for link in l1l11l111ll_l1_:
		if l1l1ll_l1_ (u"ࠫ࠿࠵࠯ࡷࡤ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠧ㻓") in link:
			html = OPENURL_CACHED(l11l1ll_l1_,link,l1l1ll_l1_ (u"ࠬ࠭㻔"),headers,l1l1ll_l1_ (u"࠭ࠧ㻕"),l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ㻖"))
			html = html.decode(l1l1ll_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴ࠯࠴࠶࠺࠼ࠧ㻗")).encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㻘"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l1l111l11ll_l1_><l1l111l1lll_l1_ /><l1l111l11ll_l1_ l1l111lllll_l1_=l1l1ll_l1_ (u"ࠥࡧࡪࡴࡴࡦࡴࠥ㻙")>(\*\*\*\*\*\*\*\*|13721411411.l1l111l111l_l1_|)
			html = html.replace(l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡥࡲࡱ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㻚"),l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㻛"))
			html = html.replace(l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ㻜"),l1l1ll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㻝"))
			html = html.replace(l1l1ll_l1_ (u"ࠨ࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࡁࡨࡲࠡ࠱ࡁࡀࡩ࡯ࡶࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࡀࠪ㻞"),l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ㻟"))
			html = html.replace(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡧࡵࡲࡥࡧࡵࠦࠥࡧ࡬ࡪࡩࡱࡁࠧࡩࡥ࡯ࡶࡨࡶࠧ࠭㻠"),l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ㻡"))
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ㻢"),html,re.DOTALL)
			if l1lll11_l1_:
				#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ㻣"),l1l1ll_l1_ (u"ࠧࠨ㻤"),url,str(len(l1lll11_l1_)))
				l1l111l11l1_l1_,l1l111ll1l1_l1_ = [],[]
				if len(l1lll11_l1_)==1:
					title = l1l1ll_l1_ (u"ࠨࠩ㻥")
					block = html
				else:
					for block in l1lll11_l1_:
						l11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠮ࠫࡁ࡟࠮ࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࠮ࠬ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ㻦"),block,re.DOTALL)
						if l11ll_l1_: block = l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ㻧") + l11ll_l1_[0][1]
						l11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࠿࡬ࡷࠦࡳࡪࡼࡨࡁࠧ࠷ࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࠤ࠵࠶࠷ࡀࠦࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰ࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹ࠢࠡ࠱ࡁࠬ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ㻨"),block,re.DOTALL)
						if l11ll_l1_: block = l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ㻩") + l11ll_l1_[0]
						l11ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱࠨ࠮ࠫࡁࠬࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ㻪"),block,re.DOTALL)
						if l11ll_l1_: block = l11ll_l1_[0] + l1l1ll_l1_ (u"ࠧࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㻫")
						l1l111llll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࠫ࠲࠯ࡅࠩࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࠨࡰࡰ࡯࡭ࡳ࡫ࡼࡤࡱࡰ࠭࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵ࠧ㻬"),block,re.DOTALL)
						title = re.findall(l1l1ll_l1_ (u"ࠩࡁࠤ࠯࠮࡛࡟࠾ࡁࡡ࠰࠯ࠠࠫ࠾ࠪ㻭"),l1l111llll1_l1_[0][0],re.DOTALL)
						title = l1l1ll_l1_ (u"ࠪࠤࠬ㻮").join(title)
						title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭㻯"))
						title = title.replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ㻰"),l1l1ll_l1_ (u"࠭ࠠࠨ㻱")).replace(l1l1ll_l1_ (u"ࠧࠡࠢࠪ㻲"),l1l1ll_l1_ (u"ࠨࠢࠪ㻳")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠬ㻴"),l1l1ll_l1_ (u"ࠪࠤࠬ㻵")).replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧ㻶"),l1l1ll_l1_ (u"ࠬࠦࠧ㻷")).replace(l1l1ll_l1_ (u"࠭ࠠࠡࠩ㻸"),l1l1ll_l1_ (u"ࠧࠡࠩ㻹"))
						l1l111l11l1_l1_.append(title)
					selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅใํำ๏๎ࠠศๆ่฻้๎ศ࠻ࠩ㻺"), l1l111l11l1_l1_)
					if selection == -1 : return
					title = l1l111l11l1_l1_[selection]
					block = l1lll11_l1_[selection]
				link = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯࠭ࠧ࠭㻻"),block,re.DOTALL)
				l1l111ll111_l1_ = link[0]
				l11l1_l1_.append(l1l111ll111_l1_+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡊࡴࡸࡵ࡮ࠩ㻼"))
				block = block.replace(l1l1ll_l1_ (u"ࠫๅ࠭㻽"),l1l1ll_l1_ (u"ࠬ࠭㻾"))
				block = block.replace(l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ㻿"),l1l1ll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡨ࡯ࡵࡪࠥࠤࠥࡢ࡮ࠡࠢࠪ㼀"))
				block = block.replace(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡩ࡯࡮࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠺࠷࠷࠵࠳࠵࠵࠼࠻࠲࠺࠸࠱ࡴࡳ࡭ࠢࠨ㼁"),l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ㼂"))
				block = block.replace(l1l1ll_l1_ (u"ࠪื๏ืแาษอࠤฬ๊สฮ็ํ่ࠬ㼃"),l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦࠥࠦ࡜࡯ࠢࠣࠫ㼄"))
				block = block.replace(l1l1ll_l1_ (u"ࠬื่ศสฺࠤฬ๊สฮ็ํ่ࠬ㼅"),l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭㼆"))
				block = block.replace(l1l1ll_l1_ (u"ࠧิ์ิๅึอสࠡษ็ู้อ็ะࠩ㼇"),l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡷࡢࡶࡦ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ㼈"))
				block = block.replace(l1l1ll_l1_ (u"ࠩิ์ฬฮืࠡษ็ู้อ็ะࠩ㼉"),l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ㼊"))
				l1l111l1l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵࡜ࡥ࠭ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ㼋"),block,re.DOTALL)
				for l1l111ll11l_l1_ in l1l111l1l1l_l1_:
					#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㼌"),l1l1ll_l1_ (u"࠭ࠧ㼍"),l1l1ll_l1_ (u"ࠧࠨ㼎"),str(l1l111ll11l_l1_))
					type = re.findall(l1l1ll_l1_ (u"ࠨࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭㼏"),l1l111ll11l_l1_)
					if type:
						if type[0]!=l1l1ll_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ㼐"): type = l1l1ll_l1_ (u"ࠪࡣࡤ࠭㼑")+type[0]
						else: type = l1l1ll_l1_ (u"ࠫࠬ㼒")
					items = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠿࠽ࠣ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࠹ࡹࡹࡡࡳ࠰ࡦࡳࡲ࠵ࠩࠩ࡞ࡺ࠯ࡠࠦ࡜ࡸ࡟࠭ࡀ࠴࡬࡯࡯ࡶࡁ࠲࠯ࡅࡼ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿ࡦࡷࠦ࠯࠿࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡫࠵ࡵࡵࡤࡶ࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢࠨ㼓"),l1l111ll11l_l1_,re.DOTALL)
					for l1l111l1ll1_l1_,link in items:
						title = re.findall(l1l1ll_l1_ (u"࠭ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬࠬࡀࠬ㼔"),l1l111l1ll1_l1_)
						title = title[-1]
						link = link + l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㼕") + title + type
						l11l1_l1_.append(link)
	# l1l11l11l11_l1_
	url3 = url2.replace(l1l1l1_l1_,l1l111lll1_l1_)
	html = OPENURL_CACHED(l11l1ll_l1_,url3,l1l1ll_l1_ (u"ࠨࠩ㼖"),headers,l1l1ll_l1_ (u"ࠩࠪ㼗"),l1l1ll_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ㼘"))
	items = re.findall(l1l1ll_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㼙"),html,re.DOTALL)
	#id2 = re.findall(l1l1ll_l1_ (u"ࠬࠨࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯ࡦ࡯ࡥࡩࡩࡓ࠭ࠩ࡞ࡺ࠯࠮࠳࠮ࠫࡁ࠱࡬ࡹࡳ࡬ࠪࠩ㼚"),html,re.DOTALL)
	#if id2:
	if items:
		#l1l11l11l11_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥ࠰ࠩ㼛") + id2[-1] + l1l1ll_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭㼜")
		l1l11l11l11_l1_ = items[-1]
		l11l1_l1_.append(l1l11l11l11_l1_+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡏࡲࡦ࡮ࡲࡥࠨ㼝"))
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㼞"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠪࠫ㼟"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠫࠬ㼠"): return
	search = search.replace(l1l1ll_l1_ (u"ࠬࠦࠧ㼡"),l1l1ll_l1_ (u"࠭ࠫࠨ㼢"))
	html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ㼣"),headers,l1l1ll_l1_ (u"ࠨࠩ㼤"),l1l1ll_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ㼥"))
	items = re.findall(l1l1ll_l1_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࡂࠬ㼦"),html,re.DOTALL)
	l11l1l11l_l1_ = [ l1l1ll_l1_ (u"ࠫࠬ㼧") ]
	l11l1111l_l1_ = [ l1l1ll_l1_ (u"ࠬอไไๆࠣ์อี่็ࠢไ่ฯืࠧ㼨") ]
	for category,title in items:
		l11l1l11l_l1_.append(category)
		l11l1111l_l1_.append(title)
	if category:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭㼩"), l11l1111l_l1_)
		if selection == -1 : return
		category = l11l1l11l_l1_[selection]
	else: category = l1l1ll_l1_ (u"ࠧࠨ㼪")
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭㼫")+search+l1l1ll_l1_ (u"ࠩࠩࡱࡨࡧࡴ࠾ࠩ㼬")+category
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㼭"),l1l1ll_l1_ (u"ࠫࠬ㼮"),url,url)
	l11l1l_l1_(url)
	return
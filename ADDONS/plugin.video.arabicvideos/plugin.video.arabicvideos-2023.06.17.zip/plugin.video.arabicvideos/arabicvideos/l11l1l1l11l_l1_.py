# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭孼")
menu_name = l1l1ll_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ孽")
l1l1l1_l1_ = WEBSITES[script_name][0]
#headers = l1l1ll_l1_ (u"ࠧࠨ孾")
#headers = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ孿"):l1l1ll_l1_ (u"ࠩࠪ宀")}
l11lllll111l_l1_ = 0
def MAIN(mode,url,text,type,page,name,image):
	if	 mode==140: results = MENU()
	elif mode==141: results = l11llll1lll1_l1_(url,name,image)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l11l1l_l1_(url,page,text)
	elif mode==145: results = l1l1111ll11l_l1_(url,page)
	elif mode==147: results = l1l111111l1l_l1_()
	elif mode==148: results = l1l111111lll_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宁"),menu_name+l1l1ll_l1_ (u"ࠫ็อฦๆหࠪ宂"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࡐࡍࡃ࡭࠹ࡌࡹ࠸ࡇࡊ࠻࡞ࡳ࡛ࡢࡇ࠲ࡕ࡚࠲࠽ࡇ࠴ࡄࡲࡵࡎࡿ࡚ࡂ࠶ࡸࡗࡆ࠭它"),144)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宄"),menu_name+l1l1ll_l1_ (u"ࠧีะุࠫ宅"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡸࡷࡪࡸ࠯ࡕࡅࡑࡳ࡫࡬ࡩࡤ࡫ࡤࡰࠬ宆"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宇"),menu_name+l1l1ll_l1_ (u"้ࠪํู่ࠨ守"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࡕࡄࡳ࠸࠽ࡦࡍࡎࡴࡳ࠼ࡦࡧ࡮ࡷࡗࡖࡴ࠵࡚ࡺࡶࡨࡹࠪ安"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ宊"),menu_name+l1l1ll_l1_ (u"࠭อิษหࠫ宋"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡂࡗ࡬ࡪ࡙࡯ࡤ࡫ࡤࡰࡈ࡚ࡖࠨ完"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宍"),menu_name+l1l1ll_l1_ (u"ࠩส่฾อศࠨ宎"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ宏"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宐"),menu_name+l1l1ll_l1_ (u"ࠬอแๅษ่ࠫ宑"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡹࡴࡰࡴࡨࡪࡷࡵ࡮ࡵࠩ宒"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ宓"),menu_name+l1l1ll_l1_ (u"ࠨ็ัฮฬืวหࠩ宔"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ宕"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宖"),menu_name+l1l1ll_l1_ (u"ࠫ็฻๊าหࠪ宗"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭官"),144,l1l1ll_l1_ (u"࠭ࠧ宙"),l1l1ll_l1_ (u"ࠧࠨ定"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ宛"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宜"),menu_name+l1l1ll_l1_ (u"ࠪฮฺ็อࠨ宝"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ实"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ実"),menu_name+l1l1ll_l1_ (u"࠭ัว์ึ๎ฮ࠭宠"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧࠨ审"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ客"),menu_name+l1l1ll_l1_ (u"ࠩิหหาࠧ宣"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࡃࡧࡶ࠽ࠨ室"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ宥"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ宦"),l1l1ll_l1_ (u"࠭ࠧ宧"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ宨"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ宩"),l1l1ll_l1_ (u"ࠩࠪ宪"),149,l1l1ll_l1_ (u"ࠪࠫ宫"),l1l1ll_l1_ (u"ࠫࠬ宬"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ宭"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宮"),menu_name+l1l1ll_l1_ (u"ࠧศๆิส๏ู๊สࠩ宯"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨࠩ宰"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宱"),menu_name+l1l1ll_l1_ (u"ࠪห้ืววฮฬࠫ宲"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ害"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ宴"),menu_name+l1l1ll_l1_ (u"࠭วๅฬุๅา࠭宵"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ家"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ宷"),menu_name+l1l1ll_l1_ (u"ࠩส่็฻๊าหࠪ宸"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ容"),144,l1l1ll_l1_ (u"ࠫࠬ宺"),l1l1ll_l1_ (u"ࠬ࠭宻"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ宼"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ宽"),menu_name+l1l1ll_l1_ (u"ࠨ็ัฮฬืวหࠢํ์ฯ๐่ษࠩ宾"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ宿"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寀"),menu_name+l1l1ll_l1_ (u"๊ࠫิสศำสฮࠥอไษำ้ห๊าࠧ寁"),l1l1ll_l1_ (u"ࠬ࠭寂"),290)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ寃"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ寄"),l1l1ll_l1_ (u"ࠨࠩ寅"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ密"),menu_name+l1l1ll_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะฺࠠำห๎ฮ࠭寇"),l1l1ll_l1_ (u"ࠫࠬ寈"),147)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寉"),menu_name+l1l1ll_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣวั์ศ๋หࠪ寊"),l1l1ll_l1_ (u"ࠧࠨ寋"),148)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ富"),menu_name+l1l1ll_l1_ (u"ࠩหัะࡀࠠศใ็หู๊ࠦาสํอࠬ寍"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁๆ๐ไๆࠩ寎"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寏"),menu_name+l1l1ll_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢสะ๋ฮ๊สࠩ寐"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽࡮ࡱࡹ࡭ࡪ࠭寑"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ寒"),menu_name+l1l1ll_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭寓"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ寔"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ寕"),menu_name+l1l1ll_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ฽ึฮ๊สࠩ寖"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิๆึ่ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ寗"),144)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭寘"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭寙"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ寚"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寛"),menu_name+l1l1ll_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢๆหึะ่็ࠩ寜"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ้วาฬ๋๊ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ寝"),144)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寞"),menu_name+l1l1ll_l1_ (u"࠭ศฮอ࠽ࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ察"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ใาส็หฦ࠱วๅใูหห๐ษࠬะฺฬฮ࠱วๅฮ่฽ฮࠬࡳࡱ࠿ࡆࡅࡎ࡙ࡁࡩࡃࡅࠫ寠"),144)
	return
def l11llll1lll1_l1_(url,name,image):
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ寡"),menu_name+l1l1ll_l1_ (u"ࠩࡆࡌࡓࡒ࠺ࠡࠢࠪ寢")+name,url,144,image)
	return
def l1l111111l1l_l1_():
	l11l1l_l1_(l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ寣"))
	return
def l1l111111lll_l1_():
	l11l1l_l1_(l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭寤"))
	return
def PLAY(url,type):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭寥"),l1l1ll_l1_ (u"࠭ࠧ實"),l1l1ll_l1_ (u"ࠧࠨ寧"),url)
	#url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ寨")
	#items = re.findall(l1l1ll_l1_ (u"ࠩࡹࡁ࠭࠴ࠪࡀࠫࠧࠫ審"),url,re.DOTALL)
	#id = items[0]
	#link = l1l1ll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡾࡵࡵࡵࡷࡥࡩ࠴ࡶ࡬ࡢࡻ࠲ࡃࡻ࡯ࡤࡦࡱࡢ࡭ࡩࡃࠧ寪")+id
	#PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ寫"))
	#return
	l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠮ࡵࡳ࡮ࠬࠎࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࠱ࠫࠬ࠭࠮࠯ࠥࠦࠧࠬࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠮ࠐࠉࡦࡴࡵࡳࡷࡹࠬࡵ࡫ࡷࡰࡪࡹࠬ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠫࡹࡷࡲࠩࠋࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࡶࡼࡴࡪ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ寬")
	url = url.split(l1l1ll_l1_ (u"࠭ࠦࠨ寭"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],script_name,type,url)
	return
def l11lllllll1l_l1_(cc,url,index):
	level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = index.split(l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ寮"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ寯"),l1l1ll_l1_ (u"ࠩࠪ寰"),index,l1l1ll_l1_ (u"ࠪࡊࡎࡘࡓࡕࠩ寱")+l1l1ll_l1_ (u"ࠫࡡࡴࠧ寲")+url)
	l11llll1l1ll_l1_,l11llll1ll1l_l1_ = [],[]
	# l11l111l11l_l1_ l11l1111lll_l1_    should be the first item in the l11llll1l1ll_l1_ list
	if l1l1ll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ寳") in url: l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡂࡥࡷ࡭ࡴࡴࡳࠨ࡟ࠥ寴"))
	# l11l111l11l_l1_ search l1l11111l1l1_l1_      should be the first item in the l11llll1l1ll_l1_ list
	if l1l1ll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭࠭寵") in url: l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡆࡳࡲࡳࡡ࡯ࡦࡶࠫࡢࠨ寶"))
	# main page
	if level==l1l1ll_l1_ (u"ࠩ࠴ࠫ寷"): l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ寸"))
	# search results
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡨࡩ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ对"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࠨ寺"))
	# l1l11111l11l_l1_ l1l111111l11_l1_ & main page l1l111111l11_l1_ l1l11111l1l1_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡣࡤ࡝ࠪࡩࡳࡺࡲࡪࡧࡶࠫࡢࠨ寻"))
	# l11llllllll1_l1_ l1lll1l11l_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡤࡥ࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࡠ࠹࡝࡜ࠩࡪࡹ࡮ࡪࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ导"))
	l1l11111l1ll_l1_,dd,l11llll11l1l_l1_ = l11llll1l11l_l1_(cc,l1l1ll_l1_ (u"ࠨࠩ寽"),l11llll1l1ll_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ対"),str(dd))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ寿"),l1l1ll_l1_ (u"ࠫࠬ尀"),l1l1ll_l1_ (u"ࠬ࠭封"),str(len(dd)))
	if level==l1l1ll_l1_ (u"࠭࠱ࠨ専") and l1l11111l1ll_l1_:
		if len(dd)>1 and l1l1ll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭尃") not in url:
			for zz in range(len(dd)):
				l11lllll1ll1_l1_ = str(zz)
				l11llll1l1ll_l1_ = []
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡦࡧ࡟ࠧ射")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ尅"))
				# l1l11111l11l_l1_ l1l111111l11_l1_
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡨࡩࡡࠢ将")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠦࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࠨ࡟ࠥ將"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡪࡤ࡜ࠤ專")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠨ࡝ࠣ尉"))
				succeeded,item,l11l1ll1_l1_ = l11llll1l11l_l1_(dd,l1l1ll_l1_ (u"ࠧࠨ尊"),l11llll1l1ll_l1_)
				if succeeded: l11llll1ll1l_l1_.append([item,url,l1l1ll_l1_ (u"ࠨ࠴࠽࠾ࠬ尋")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ尌")])
				#l11llll1llll_l1_ = l1l1111l1l11_l1_(item,url,l1l1ll_l1_ (u"ࠪ࠶࠿ࡀࠧ對")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠫ࠿ࡀ࠰࠻࠼࠳ࠫ導"))
				#if l11llll1llll_l1_: l1l1lll1l1_l1_ += 1
				#succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token = l1l1111lll1l_l1_(item)
				#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ小"),menu_name+title,link,144,l1l1ll_l1_ (u"࠭ࠧ尐"),l1l1ll_l1_ (u"ࠧ࠳࠼࠽ࠫ少")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠨ࠼࠽࠴࠿ࡀ࠰ࠨ尒"))
				#l1l1lll1l1_l1_ += 1
			# main page l1l111111l11_l1_ l1l11111l1l1_l1_
			l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝ࠣ尓"))
			succeeded,item,l11l1ll1_l1_ = l11llll1l11l_l1_(cc,l1l1ll_l1_ (u"ࠪࠫ尔"),l11llll1l1ll_l1_)
			#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ尕"),str(cc))
			if succeeded and l11llll1ll1l_l1_ and l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡳ࡭ࡢࡰࡧࠫ尖") in list(item.keys()):
				link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ尗")
				l11llll1ll1l_l1_.append([item,link,l1l1ll_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ尘")])
	return dd,l1l11111l1ll_l1_,l11llll1ll1l_l1_,l11llll11l1l_l1_
def l11llll11ll1_l1_(cc,dd,url,index):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ尙"),l1l1ll_l1_ (u"ࠩࠪ尚"),index,l1l1ll_l1_ (u"ࠪࡗࡊࡉࡏࡏࡆࠪ尛")+l1l1ll_l1_ (u"ࠫࡡࡴࠧ尜")+url)
	level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = index.split(l1l1ll_l1_ (u"ࠬࡀ࠺ࠨ尝"))
	l11llll1l1ll_l1_,l11lllllllll_l1_ = [],[]
	# search results
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡤࡥ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ尞"))
	# main page
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡥࡦ࡞ࠦ尟")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠣ࡟࡞ࠫࡷ࡫࡬ࡰࡣࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࠧ࡞ࠤ尠"))
	# l1l11111l11_l1_ l1l111111l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡧࡨࡠ࠷࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ尡"))
	# l11l111l11l_l1_ search & l11l1111lll_l1_ & l1l11111l1l1_l1_
	if l1l1ll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ尢") in url: l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ尣"))
	elif l1l1ll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ尤") in url: l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ尥"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡥࡦ࡞ࠦ尦")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ尧"))
	# l1l11111l11_l1_ l11llll111_l1_ & l1l111111l11_l1_ filters
	if l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ尨") in url or (l1l1ll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ尩") in url and l1l1ll_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷ࠴࠭尪") not in url):
		l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡪࡤ࡜ࠤ尫")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡩࡩࡪࡪࡆࡪ࡮ࡷࡩࡷࡉࡨࡪࡲࡅࡥࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ尬"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡥࡦ࡞ࠦ尭")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠣ࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ尮"))
	# l1l11111l11l_l1_ search
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡧࡨࡠࠨ尯")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠥࡡࡠ࠭ࡥࡹࡲࡤࡲࡩࡧࡢ࡭ࡧࡗࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ尰"))
	# main page
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡩࡪ࡛ࠣ就")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ尲"))
	# l11l111l11l_l1_ l11l1111lll_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡤࡥ࡝ࠥ尳")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠢ࡞ࠤ尴"))
	l1l11111l111_l1_,ee,l11llllll1ll_l1_ = l11llll1l11l_l1_(dd,l1l1ll_l1_ (u"ࠨࠩ尵"),l11llll1l1ll_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ尶"),str(ee))
	#DIALOG_OK()
	if level==l1l1ll_l1_ (u"ࠪ࠶ࠬ尷") and l1l11111l111_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l11llll1l1ll_l1_ = []
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡪ࡫࡛ࠣ尸")+index2+l1l1ll_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ尹"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡥࡦ࡝ࠥ尺")+index2+l1l1ll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ尻"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡧࡨ࡟ࠧ尼")+index2+l1l1ll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ尽"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡩࡪࡡࠢ尾")+index2+l1l1ll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ尿"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ局")+index2+l1l1ll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ屁"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡦࡧ࡞ࠦ层")+index2+l1l1ll_l1_ (u"ࠣ࡟ࠥ屃"))
				succeeded,item,l11l1ll1_l1_ = l11llll1l11l_l1_(ee,l1l1ll_l1_ (u"ࠩࠪ屄"),l11llll1l1ll_l1_)
				if succeeded: l11lllllllll_l1_.append([item,url,l1l1ll_l1_ (u"ࠪ࠷࠿ࡀࠧ居")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ屆")+index2+l1l1ll_l1_ (u"ࠬࡀ࠺࠱ࠩ屇")])
				#l11llll1llll_l1_ = l1l1111l1l11_l1_(item,url,l1l1ll_l1_ (u"࠭࠳࠻࠼ࠪ屈")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ屉")+index2+l1l1ll_l1_ (u"ࠨ࠼࠽࠴ࠬ届"))
				#if l11llll1llll_l1_: l1l1ll1lll_l1_ += 1
				#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ屋"),str(l11l1ll1_l1_)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࠧ屌")+str(item))
				#l1l1ll1lll_l1_ += 1
				#item = ee[zz]
				#succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token = l1l1111lll1l_l1_(item)
				#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屍"),menu_name+title,link,144,img,l1l1ll_l1_ (u"ࠬ࠹࠺࠻ࠩ屎")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"࠭࠺࠻ࠩ屏")+index2+l1l1ll_l1_ (u"ࠧ࠻࠼࠳ࠫ屐"))
			# search l1l11111l1l1_l1_
			l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࡠ࠷࡝ࠣ屑"))
			# search l1l11111l1l1_l1_
			l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡧࡨࡠ࠷࡝ࠣ屒"))
			succeeded,item,l11l1ll1_l1_ = l11llll1l11l_l1_(dd,l1l1ll_l1_ (u"ࠪࠫ屓"),l11llll1l1ll_l1_)
			if succeeded and l11lllllllll_l1_ and l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ屔") in list(item.keys()):
				l11lllllllll_l1_.append([item,url,l1l1ll_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ展")])
			#l11llll1llll_l1_ = l1l1111l1l11_l1_(item,url,l1l1ll_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ屖"))
			#if l11llll1llll_l1_: l1l1ll1lll_l1_ += 1
			#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ屗"),str(item))
			#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ屘"),link+l1l1ll_l1_ (u"ࠩࠣࠤࠥ࠭屙")+token)
	return ee,l1l11111l111_l1_,l11lllllllll_l1_,l11llllll1ll_l1_
def l11lllll1111_l1_(cc,ee,url,index):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ屚"),l1l1ll_l1_ (u"ࠫࠬ屛"),index,l1l1ll_l1_ (u"࡚ࠬࡈࡊࡔࡇࠫ屜")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ屝")+url)
	level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = index.split(l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ属"))
	l11llll1l1ll_l1_,l11lllll11ll_l1_ = [],[]
	# search results
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡧࡨ࡟ࠧ屟")+index2+l1l1ll_l1_ (u"ࠤࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡼࡥࡳࡶ࡬ࡧࡦࡲࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ屠"))
	# l11l111l11l_l1_ l11l1111lll_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡩࡪࡡࠢ屡")+index2+l1l1ll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ屢"))
	# l1l1111l11ll_l1_ l1lll1l11l_l1_ l1l111111l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ屣")+index2+l1l1ll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡸࡥࡦ࡮ࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ層"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡦࡧ࡞ࠦ履")+index2+l1l1ll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ屦"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡨࡩࡠࠨ屧")+index2+l1l1ll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ屨"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡪ࡫࡛ࠣ屩")+index2+l1l1ll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ屪"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡥࡦ࡝ࠥ屫")+index2+l1l1ll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ屬"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡧࡨ࡟ࠧ屭")+index2+l1l1ll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ屮"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ屯"))
	# l1l11111l11l_l1_ l1l1111llll1_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ屰"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡫ࡥ࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ山"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡥࡦ࡝ࠥ屲")+index2+l1l1ll_l1_ (u"ࠢ࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ屳"))
	# main page
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡧࡨ࡟ࠧ屴")+index2+l1l1ll_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡕ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ屵"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡩࡪࠨ屶"))
	l1l11111ll1l_l1_,ff,l1l1111ll1ll_l1_ = l11llll1l11l_l1_(ee,l1l1ll_l1_ (u"ࠫࠬ屷"),l11llll1l1ll_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭屸"),str(ff))
	if level==l1l1ll_l1_ (u"࠭࠳ࠨ屹") and l1l11111ll1l_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1l1111111ll_l1_ = str(zz)
				#DIALOG_OK()
				l11llll1l1ll_l1_ = []
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡧࡨ࡞ࠦ屺")+l1l1111111ll_l1_+l1l1ll_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ屻"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡩࡪࡠࠨ屼")+l1l1111111ll_l1_+l1l1ll_l1_ (u"ࠥࡡࡠ࠭ࡧࡢ࡯ࡨࡇࡦࡸࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡭ࡡ࡮ࡧࠪࡡࠧ屽"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡫࡬࡛ࠣ屾")+l1l1111111ll_l1_+l1l1ll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟ࠥ屿"))
				l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡦࡧ࡝ࠥ岀")+l1l1111111ll_l1_+l1l1ll_l1_ (u"ࠢ࡞ࠤ岁"))
				succeeded,item,l11l1ll1_l1_ = l11llll1l11l_l1_(ff,l1l1ll_l1_ (u"ࠨࠩ岂"),l11llll1l1ll_l1_)
				#succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token = l1l1111lll1l_l1_(item)
				#addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ岃"),menu_name+link,link,143,img)
				if succeeded: l11lllll11ll_l1_.append([item,url,l1l1ll_l1_ (u"ࠪ࠸࠿ࡀࠧ岄")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ岅")+index2+l1l1ll_l1_ (u"ࠬࡀ࠺ࠨ岆")+l1l1111111ll_l1_])
				#l11llll1llll_l1_ = l1l1111l1l11_l1_(item,url,l1l1ll_l1_ (u"࠭࠴࠻࠼ࠪ岇")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ岈")+index2+l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ岉")+l1l1111111ll_l1_)
				#if l11llll1llll_l1_: l1l1lll111_l1_ += 1
	return ff,l1l11111ll1l_l1_,l11lllll11ll_l1_,l1l1111ll1ll_l1_
def l11llll1l11l_l1_(l1l111l1l11_l1_,l1l11l1111l_l1_,l11lllll1l1l_l1_):
	cc,l1l11l1111l_l1_ = l1l111l1l11_l1_,l1l11l1111l_l1_
	dd,l1l11l1111l_l1_ = l1l111l1l11_l1_,l1l11l1111l_l1_
	ee,l1l11l1111l_l1_ = l1l111l1l11_l1_,l1l11l1111l_l1_
	ff,l1l11l1111l_l1_ = l1l111l1l11_l1_,l1l11l1111l_l1_
	item,render = l1l111l1l11_l1_,l1l11l1111l_l1_
	count = len(l11lllll1l1l_l1_)
	for ii in range(count):
		try:
			out = eval(l11lllll1l1l_l1_[ii])
			#if isinstance(out,dict): out = l1l1ll_l1_ (u"ࠩࠪ岊")
			return True,out,ii+1
		except: pass
	return False,l1l1ll_l1_ (u"ࠪࠫ岋"),0
def l11l1l_l1_(url,index=l1l1ll_l1_ (u"ࠫࠬ岌"),data=l1l1ll_l1_ (u"ࠬ࠭岍")):
	l11llll1ll1l_l1_,l11lllllllll_l1_,l11lllll11ll_l1_ = [],[],[]
	if l1l1ll_l1_ (u"࠭࠺࠻ࠩ岎") not in index: index = l1l1ll_l1_ (u"ࠧ࠲࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ岏")
	level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = index.split(l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ岐"))
	if level==l1l1ll_l1_ (u"ࠩ࠷ࠫ岑"): level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = l1l1ll_l1_ (u"ࠪ࠵ࠬ岒"),l11lllll1ll1_l1_,index2,l1l1111111ll_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ岓"),l1l1ll_l1_ (u"ࠬ࠭岔"),index,url)
	data = data.replace(l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ岕"),l1l1ll_l1_ (u"ࠧࠨ岖"))
	html,cc,data2 = l1l111111111_l1_(url,data)
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎ࡯ࡦࠡࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬࠦࡩ࡯ࠢࡸࡶࡱࠦ࡯ࡳࠢࠪ࠳ࡺࡹࡥࡳ࠱ࠪࠤ࡮ࡴࠠࡶࡴ࡯࠾ࠏࠏࠉࠤࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡱࡺࡲࡪࡸࡎࡢ࡯ࡨࠦ࠳࠰࠿ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠧ࡮࡬ࠠ࡯ࡱࡷࠤࡴࡽ࡮ࡦࡴ࠽ࠤࠏࠏࠉࡰࡹࡱࡩࡷࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡎࡧࡷࡥࡩࡧࡴࡢࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡴࡽ࡮ࡦࡴࡘࡶࡱࡹࠢ࠻࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠦ࡭࡫ࠦ࡮ࡰࡶࠣࡳࡼࡴࡥࡳ࠼ࠣࡳࡼࡴࡥࡳࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡺ࡮ࡪࡥࡰࡑࡺࡲࡪࡸࠢ࠯ࠬࡂࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡀࠊࠊࠋࠌࡳࡼࡴࡥࡳࡐࡄࡑࡊࠦ࠽ࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠴ࡢ࠯ࠊࠊࠋࠌࡳࡼࡴࡥࡳࡐࡄࡑࡊࠦ࠽ࠡࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ࠱࡯ࡸࡰࡨࡶࡓࡇࡍࡆ࠭ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠶ࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡩࡶࡷࡴࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡲࡩ࡯࡭ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬ࡮࡬ࡲࡰࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡵࡷ࡯ࡧࡵࡒࡆࡓࡅ࠭࡮࡬ࡲࡰ࠲࠱࠵࠶ࠬࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭࡬ࡪࡰ࡮ࠫ࠱࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬࠨࠩ࠯࠽࠾࠿࠹ࠪࠌࠌࠦࠧࠨ岗")
	index = level+l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ岘")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠪ࠾࠿࠭岙")+index2+l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ岚")+l1l1111111ll_l1_
	if level in [l1l1ll_l1_ (u"ࠬ࠷ࠧ岛"),l1l1ll_l1_ (u"࠭࠲ࠨ岜"),l1l1ll_l1_ (u"ࠧ࠴ࠩ岝")]:
		dd,l1l11111l1ll_l1_,l11llll1ll1l_l1_,l11llll11l1l_l1_ = l11lllllll1l_l1_(cc,url,index)
		if not l1l11111l1ll_l1_: return
		l1l1lll1l1_l1_ = len(l11llll1ll1l_l1_)
		if l1l1lll1l1_l1_<2:
			if level==l1l1ll_l1_ (u"ࠨ࠳ࠪ岞"): level = l1l1ll_l1_ (u"ࠩ࠵ࠫ岟")
			l11llll1ll1l_l1_ = []
		#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ岠"),l1l1ll_l1_ (u"ࠫࠬ岡"),index,l1l1ll_l1_ (u"ࠬࡲࡥࡷࡧ࡯࠾ࠥ࠷࡜࡯ࠩ岢")+l1l1ll_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥ࠻ࠢࠪ岣")+str(l11llll11l1l_l1_)+l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ岤")+l1l1ll_l1_ (u"ࠨ࡮ࡨࡲ࡬ࡺࡨ࠻ࠢࠪ岥")+str(len(dd))+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ岦")+l1l1ll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵ࠼ࠣࠫ岧")+str(l1l1lll1l1_l1_)+l1l1ll_l1_ (u"ࠫࡡࡴࠧ岨")+url)
	index = level+l1l1ll_l1_ (u"ࠬࡀ࠺ࠨ岩")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"࠭࠺࠻ࠩ岪")+index2+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ岫")+l1l1111111ll_l1_
	if level in [l1l1ll_l1_ (u"ࠨ࠴ࠪ岬"),l1l1ll_l1_ (u"ࠩ࠶ࠫ岭")]:
		ee,l1l11111l111_l1_,l11lllllllll_l1_,l11llllll1ll_l1_ = l11llll11ll1_l1_(cc,dd,url,index)
		if not l1l11111l111_l1_: return
		l1l1ll1lll_l1_ = len(l11lllllllll_l1_)
		if l1l1ll1lll_l1_<2:
			if level==l1l1ll_l1_ (u"ࠪ࠶ࠬ岮"): level = l1l1ll_l1_ (u"ࠫ࠸࠭岯")
			l11lllllllll_l1_ = []
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭岰"),l1l1ll_l1_ (u"࠭ࠧ岱"),index,l1l1ll_l1_ (u"ࠧ࡭ࡧࡹࡩࡱࡀࠠ࠳࡞ࡱࠫ岲")+l1l1ll_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ岳")+str(l11llllll1ll_l1_)+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ岴")+l1l1ll_l1_ (u"ࠪࡰࡪࡴࡧࡵࡪ࠽ࠤࠬ岵")+str(len(ee))+l1l1ll_l1_ (u"ࠫࡡࡴࠧ岶")+l1l1ll_l1_ (u"ࠬࡩ࡯ࡶࡰࡷ࠾ࠥ࠭岷")+str(l1l1ll1lll_l1_)+l1l1ll_l1_ (u"࠭࡜࡯ࠩ岸")+url)
	index = level+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ岹")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ岺")+index2+l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ岻")+l1l1111111ll_l1_
	if level in [l1l1ll_l1_ (u"ࠪ࠷ࠬ岼")]:
		ff,l1l11111ll1l_l1_,l11lllll11ll_l1_,l1l1111ll1ll_l1_ = l11lllll1111_l1_(cc,ee,url,index)
		if not l1l11111ll1l_l1_: return
		l1l1lll111_l1_ = len(l11lllll11ll_l1_)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ岽"),l1l1ll_l1_ (u"ࠬ࠭岾"),index,l1l1ll_l1_ (u"࠭࡬ࡦࡸࡨࡰ࠿ࠦ࠳࡝ࡰࠪ岿")+l1l1ll_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦ࠼ࠣࠫ峀")+str(l1l1111ll1ll_l1_)+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ峁")+l1l1ll_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩ࠼ࠣࠫ峂")+str(len(ff))+l1l1ll_l1_ (u"ࠪࡠࡳ࠭峃")+l1l1ll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶ࠽ࠤࠬ峄")+str(l1l1lll111_l1_)+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ峅")+url)
	for item,url,index in l11llll1ll1l_l1_+l11lllllllll_l1_+l11lllll11ll_l1_:
		l11llll1llll_l1_ = l1l1111l1l11_l1_(item,url,index)
	return
def l1l1111l1l11_l1_(item,url=l1l1ll_l1_ (u"࠭ࠧ峆"),index=l1l1ll_l1_ (u"ࠧࠨ峇")):
	if l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ峈") in index: level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = index.split(l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ峉"))
	else: level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = l1l1ll_l1_ (u"ࠪ࠵ࠬ峊"),l1l1ll_l1_ (u"ࠫ࠵࠭峋"),l1l1ll_l1_ (u"ࠬ࠶ࠧ峌"),l1l1ll_l1_ (u"࠭࠰ࠨ峍")
	succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,l1l1111l1lll_l1_ = l1l1111lll1l_l1_(item)
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ峎"),url)
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ峏"),link)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ峐"),link+l1l1ll_l1_ (u"ࠪࠤࠥࠦࠧ峑")+title)
	# needed for l1l11111l11l_l1_ l1l1111llll1_l1_ next page
	# and needed for l1l11111l11l_l1_ l1l1111llll1_l1_ sub-l1lll1l11l_l1_
	#if (l1l1ll_l1_ (u"ࠫࡻ࡯ࡥࡸ࠿࠸࠴ࠬ峒") in link or l1l1ll_l1_ (u"ࠬࡼࡩࡦࡹࡀ࠸࠾࠭峓") in link) and (l1l1ll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࡂࠫ峔") in link or l1l1ll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡂࠫ峕") in link): link = url
	cond1 = l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࡁࠪ峖") in link or l1l1ll_l1_ (u"ࠩ࠲ࡷࡹࡸࡥࡢ࡯ࡶࡃࠬ峗") in link or l1l1ll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠿ࠨ峘") in link
	cond2 = l1l1ll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠿ࠨ峙") in link or l1l1ll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸࡅࠧ峚") in link
	if cond1 or cond2: link = url
	cond1 = l1l1ll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ峛") not in link and l1l1ll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ峜") not in link
	cond2 = l1l1ll_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ峝") not in link  and l1l1ll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ峞") not in link
	if index[0:5]==l1l1ll_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼ࠪ峟") and cond1 and cond2: link = url
	if l1l1ll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ峠") in url or l1l1ll_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭峡") in link:
		level,l11lllll1ll1_l1_,index2,l1l1111111ll_l1_ = l1l1ll_l1_ (u"࠭࠱ࠨ峢"),l1l1ll_l1_ (u"ࠧ࠱ࠩ峣"),l1l1ll_l1_ (u"ࠨ࠲ࠪ峤"),l1l1ll_l1_ (u"ࠩ࠳ࠫ峥")
		index = l1l1ll_l1_ (u"ࠪࠫ峦")
	data2 = l1l1ll_l1_ (u"ࠫࠬ峧")
	if l1l1ll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡧࡸ࡯ࡸࡵࡨࠫ峨") in link or l1l1ll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ峩") in link or l1l1ll_l1_ (u"ࠧ࠰࡯ࡼࡣࡲࡧࡩ࡯ࡡࡳࡥ࡬࡫࡟ࡴࡪࡲࡶࡹࡹ࡟࡭࡫ࡱ࡯ࠬ峪") in url:
		data = settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ峫"))
		if data.count(l1l1ll_l1_ (u"ࠩ࠽࠾࠿࠭峬"))==4:
			l1l11111ll11_l1_,key,l1l111111ll1_l1_,l11llllll111_l1_,token = data.split(l1l1ll_l1_ (u"ࠪ࠾࠿ࡀࠧ峭"))
			data2 = l1l11111ll11_l1_+l1l1ll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ峮")+key+l1l1ll_l1_ (u"ࠬࡀ࠺࠻ࠩ峯")+l1l111111ll1_l1_+l1l1ll_l1_ (u"࠭࠺࠻࠼ࠪ峰")+l11llllll111_l1_+l1l1ll_l1_ (u"ࠧ࠻࠼࠽ࠫ峱")+l1l1111l1lll_l1_
			if l1l1ll_l1_ (u"ࠨ࠱ࡰࡽࡤࡳࡡࡪࡰࡢࡴࡦ࡭ࡥࡠࡵ࡫ࡳࡷࡺࡳࡠ࡮࡬ࡲࡰ࠭峲") in url and not link: link = url
			else: link = link+l1l1ll_l1_ (u"ࠩࡂ࡯ࡪࡿ࠽ࠨ峳")+key
	if not title:
		global l11lllll111l_l1_
		l11lllll111l_l1_ += 1
		title = l1l1ll_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ࠭峴")+str(l11lllll111l_l1_)
		index = l1l1ll_l1_ (u"ࠫ࠸࠭峵")+l1l1ll_l1_ (u"ࠬࡀ࠺ࠨ島")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"࠭࠺࠻ࠩ峷")+index2+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ峸")+l1l1111111ll_l1_
	#if l1l1ll_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧ峹") in url: link = url
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ峺"),l1l1ll_l1_ (u"ࠪࠫ峻"),title,index+l1l1ll_l1_ (u"ࠫࡡࡴࠧ峼")+link)
	#if not link: link = url
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭峽"),l1l1ll_l1_ (u"࠭ࠧ峾"),str(succeeded),title+l1l1ll_l1_ (u"ࠧࠡ࠼࠽࠾ࠥ࠭峿")+link)
	#if l1l1ll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ崀") in url and index==l1l1ll_l1_ (u"ࠩ࠳ࠫ崁"):
	#	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崂"),menu_name+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡔࡾࡼࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ崃") in str(item): return False			# l1l1111l11l1_l1_ not items
	elif l1l1ll_l1_ (u"ࠬ࠵ࡡࡣࡱࡸࡸࠬ崄") in link: return False
	elif l1l1ll_l1_ (u"࠭࠯ࡤࡱࡰࡱࡺࡴࡩࡵࡻࠪ崅") in link: return False
	elif l1l1ll_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ崆") in list(item.keys()) or l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ崇") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ崈")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠪ࠾࠿࠭崉")+index2+l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ崊")+l1l1111111ll_l1_
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ崋"),menu_name+l1l1ll_l1_ (u"࠭࠺࠻ࠢࠪ崌")+l1l1ll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ崍"),link,144,img,index,data2)
	elif l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ崎") in link:
		title = l1l1ll_l1_ (u"ࠩ࠽࠾ࠥ࠭崏")+title
		index = l1l1ll_l1_ (u"ࠪ࠷ࠬ崐")+l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ崑")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠬࡀ࠺ࠨ崒")+index2+l1l1ll_l1_ (u"࠭࠺࠻ࠩ崓")+l1l1111111ll_l1_
		url = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ崔"),l1l1ll_l1_ (u"ࠨࠩ崕"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崖"),menu_name+title,url,145,l1l1ll_l1_ (u"ࠪࠫ崗"),index,l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ崘"))
	elif l1l1ll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ崙") in url and not link:
		index = l1l1ll_l1_ (u"࠭࠳ࠨ崚")+l1l1ll_l1_ (u"ࠧ࠻࠼ࠪ崛")+l11lllll1ll1_l1_+l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ崜")+index2+l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ崝")+l1l1111111ll_l1_
		title = l1l1ll_l1_ (u"ࠪ࠾࠿ࠦࠧ崞")+title
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崟"),menu_name+title,url,144,img,index,data2)
	#elif l1l1ll_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ崠") in link: return False
	elif l1l1ll_l1_ (u"࠭࠯ࡣࡴࡲࡻࡸ࡫ࠧ崡") in link and url==l1l1l1_l1_:
		title = l1l1ll_l1_ (u"ࠧ࠻࠼ࠣࠫ崢")+title
		index = l1l1ll_l1_ (u"ࠨ࠴࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ崣")
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ崤"),menu_name+title,link,144,img,index,data2)
	elif not link and l1l1ll_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ崥") in str(item):
		title = l1l1ll_l1_ (u"ࠫ࠿ࡀࠠࠨ崦")+title
		index = l1l1ll_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ崧")
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭崨"),menu_name+title,url,144,img,index)
	elif l1l1ll_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ崩") in str(item):
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭崪"),menu_name+title,l1l1ll_l1_ (u"ࠩࠪ崫"),9999)
	#elif l1l1ll_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ崬") in link and l1l1ll_l1_ (u"ࠫࡧࡶ࠽ࠨ崭") not in link:
	#	title = l1l1ll_l1_ (u"ࠬࡀ࠺ࠡࠩ崮")+title
	#	index = l1l1ll_l1_ (u"࠭࠲࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ崯")
	#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崰"),menu_name+title,link,144,img,index)
	elif l11l1111l1l_l1_:
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭崱"),menu_name+l11l1111l1l_l1_+title,link,143,img)
	elif l1l1ll_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ崲") in link:
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ崳"),menu_name+l1l1ll_l1_ (u"ࠫࡑࡏࡓࡕࠩ崴")+count+l1l1ll_l1_ (u"ࠬࡀࠠࠡࠩ崵")+title,link,144,img,index)
	#elif l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࡁࠬ崶") in link and l1l1ll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ崷") not in link and l1l1ll_l1_ (u"ࠨࡶࡀ࠴ࠬ崸") not in link:
	#	l1l1111111l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ崹"),link,re.DOTALL)
	#	link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ崺")+l1l1111111l1_l1_[0]
	#	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ崻"),menu_name+l1l1ll_l1_ (u"ࠬࡒࡉࡔࡖࠪ崼")+count+l1l1ll_l1_ (u"࠭࠺ࠡࠢࠪ崽")+title,link,144,img,index)
	elif l1l1ll_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ崾") in link:
		link = link.split(l1l1ll_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ崿"),1)[0]
		addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嵀"),menu_name+title,link,143,img,duration)
	elif l1l1ll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭嵁") in link:
		if l1l1ll_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ嵂") in link and count:
			l1l1111111l1_l1_ = link.split(l1l1ll_l1_ (u"ࠬࠬ࡬ࡪࡵࡷࡁࠬ嵃"),1)[1]
			link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ嵄")+l1l1111111l1_l1_
			index = l1l1ll_l1_ (u"ࠧ࠴࠼࠽࠴࠿ࡀ࠰࠻࠼࠳ࠫ嵅")
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嵆"),menu_name+l1l1ll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ嵇")+count+l1l1ll_l1_ (u"ࠪ࠾ࠥࠦࠧ嵈")+title,link,144,img,index)
		else:
			link = link.split(l1l1ll_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ嵉"),1)[0]
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嵊"),menu_name+title,link,143,img,duration)
	elif l1l1ll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ嵋") in link or l1l1ll_l1_ (u"ࠧ࠰ࡥ࠲ࠫ嵌") in link or (l1l1ll_l1_ (u"ࠨ࠱ࡃࠫ嵍") in link and link.count(l1l1ll_l1_ (u"ࠩ࠲ࠫ嵎"))==3):
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嵏"),menu_name+l1l1ll_l1_ (u"ࠫࡈࡎࡎࡍࠩ嵐")+count+l1l1ll_l1_ (u"ࠬࡀࠠࠡࠩ嵑")+title,link,144,img,index)
	elif l1l1ll_l1_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭嵒") in link:
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嵓"),menu_name+l1l1ll_l1_ (u"ࠨࡗࡖࡉࡗ࠭嵔")+count+l1l1ll_l1_ (u"ࠩ࠽ࠤࠥ࠭嵕")+title,link,144,img,index)
	else:
		if not link: link = url
		title = l1l1ll_l1_ (u"ࠪ࠾࠿ࠦࠧ嵖")+title
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵗"),menu_name+title,link,144,img,index,data2)
	return True
def l1l1111lll1l_l1_(item):
	succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token = False,l1l1ll_l1_ (u"ࠬ࠭嵘"),l1l1ll_l1_ (u"࠭ࠧ嵙"),l1l1ll_l1_ (u"ࠧࠨ嵚"),l1l1ll_l1_ (u"ࠨࠩ嵛"),l1l1ll_l1_ (u"ࠩࠪ嵜"),l1l1ll_l1_ (u"ࠪࠫ嵝"),l1l1ll_l1_ (u"ࠫࠬ嵞"),l1l1ll_l1_ (u"ࠬ࠭嵟")
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ嵠"),str(item))
	if not isinstance(item,dict): return succeeded,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token
	for l1l1111l1111_l1_ in list(item.keys()):
		render = item[l1l1111l1111_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l1l1ll_l1_ (u"ࠧࠨ嵡"),str(render))
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ嵢"),str(render))
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡐ࡮ࡹࡴࡉࡧࡤࡨࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ嵣"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡑ࡯ࡳࡵࡊࡨࡥࡩ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ嵤"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡮ࡥࡢࡦ࡯࡭ࡳ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ嵥"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ嵦"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ嵧"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ嵨"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ嵩"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ嵪"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ嵫"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ嵬"))
	# required for l1l11111l11_l1_ l11lllllll11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ嵭"))
	# l1l11111l11l_l1_ l1l111111l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡸࡥࡦ࡮࡚ࡥࡹࡩࡨࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡼࡩࡥࡧࡲࡍࡩ࠭࡝ࠣ嵮"))
	succeeded,title,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ嵯"),l1l1ll_l1_ (u"ࠨࠩ嵰"),l1l1ll_l1_ (u"ࠩࠪ嵱"),str(l11l1ll1_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"ࠪࠫ嵲"),str(l11l1ll1_l1_)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࠨ嵳")+str(title))
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ嵴"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ嵵"))
	# l1l11111l1l1_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡥࡵ࡯ࡕࡳ࡮ࠪࡡࠧ嵶"))
	# header feed
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡤࡴ࡮࡛ࡲ࡭ࠩࡠࠦ嵷"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ嵸"))
	# required for l1l11111l11_l1_ l11lllll1l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ嵹"))
	# l1l11111l11l_l1_ l1l111111l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ嵺"))
	succeeded,link,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ嵻"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ嵼"))
	# l1l11111l11l_l1_ l1l111111l11_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡲࡦࡧ࡯࡛ࡦࡺࡣࡩࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ嵽"))
	succeeded,img,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ嵾"),str(l11l1ll1_l1_)+l1l1ll_l1_ (u"ࠩࠣࠤࠥ࠭嵿")+img)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࠨ࡟ࠥ嶀"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࡖࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ嶁"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡇࡵࡴࡵࡱࡰࡔࡦࡴࡥ࡭ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ嶂"))
	succeeded,count,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ嶃"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ嶄"))
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡯ࡩࡳ࡭ࡴࡩࡖࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ嶅"))
	# l1l11111llll_l1_ l1l11111l11l_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡧࡴࡴࠧ࡞࡝ࠪ࡭ࡨࡵ࡮ࡕࡻࡳࡩࠬࡣࠢ嶆"))
	# l1l11111llll_l1_ l1l11111l11l_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡷࡹࡿ࡬ࡦࠩࡠࠦ嶇"))
	succeeded,duration,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	#l11llll1l1ll_l1_ = []
	# l1l11111l1l1_l1_
	#l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥ࡯࡭ࡨࡱࡔࡳࡣࡦ࡯࡮ࡴࡧࡑࡣࡵࡥࡲࡹࠧ࡞ࠤ嶈"))
	# l11l111l11l_l1_ l11l1111lll_l1_
	#l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡵࡴࡤࡧࡰ࡯࡮ࡨࡒࡤࡶࡦࡳࡳࠨ࡟ࠥ嶉"))
	#succeeded,l11lllll11l1_l1_,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	l11llll1l1ll_l1_ = []
	# l11l111l11l_l1_ l11l1111lll_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ࡞࡝ࠪࡸࡴࡱࡥ࡯ࠩࡠࠦ嶊"))
	# l1l11111l1l1_l1_
	l11llll1l1ll_l1_.append(l1l1ll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ嶋"))
	succeeded,token,l11l1ll1_l1_ = l11llll1l11l_l1_(item,render,l11llll1l1ll_l1_)
	if l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭嶌") in duration: duration,l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠩࠪ嶍"),l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ嶎")
	if l1l1ll_l1_ (u"๊ࠫฮวีำࠪ嶏") in duration: duration,l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭嶐"),l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ嶑")
	if l1l1ll_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ嶒") in list(render.keys()):
		l1l1111l1l1l_l1_ = str(render[l1l1ll_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ嶓")])
		if l1l1ll_l1_ (u"ࠩࡉࡶࡪ࡫ࠠࡸ࡫ࡷ࡬ࠥࡇࡤࡴࠩ嶔") in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ嶕")
		if l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࠩ嶖") in l1l1111l1l1l_l1_: l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭嶗")
		if l1l1ll_l1_ (u"࠭ࡂࡶࡻࠪ嶘") in l1l1111l1l1l_l1_ or l1l1ll_l1_ (u"ࠧࡓࡧࡱࡸࠬ嶙") in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ嶚")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡷ้ࠪออิาࠩ嶛")) in l1l1111l1l1l_l1_: l11l1111l1l_l1_ = l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ嶜")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡹฺࠬัศรࠪ嶝")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ嶞")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡻࠧศีอสัอัࠨ嶟")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠧࠥࠦ࠽ࠤࠥ࠭嶠")
		if l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡶࠩศ฽้อๆศฬࠪ嶡")) in l1l1111l1l1l_l1_: l1l11111111l_l1_ = l1l1ll_l1_ (u"ࠩࠧ࠾ࠥࠦࠧ嶢")
	link = escapeUNICODE(link)
	if link and l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嶣") not in link: link = l1l1l1_l1_+link
	img = img.split(l1l1ll_l1_ (u"ࠫࡄ࠭嶤"))[0]
	if  img and l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ嶥") not in img: img = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭嶦")+img
	title = escapeUNICODE(title)
	if l1l11111111l_l1_: title = l1l11111111l_l1_+title
	#title = unescapeHTML(title)
	duration = duration.replace(l1l1ll_l1_ (u"ࠧ࠭ࠩ嶧"),l1l1ll_l1_ (u"ࠨࠩ嶨"))
	count = count.replace(l1l1ll_l1_ (u"ࠩ࠯ࠫ嶩"),l1l1ll_l1_ (u"ࠪࠫ嶪"))
	count = re.findall(l1l1ll_l1_ (u"ࠫࡡࡪࠫࠨ嶫"),count)
	if count: count = count[0]
	else: count = l1l1ll_l1_ (u"ࠬ࠭嶬")
	return True,title,link,img,count,duration,l11l1111l1l_l1_,l1l11111111l_l1_,token
def l1l111111111_l1_(url,data=l1l1ll_l1_ (u"࠭ࠧ嶭"),request=l1l1ll_l1_ (u"ࠧࠨ嶮")):
	if request==l1l1ll_l1_ (u"ࠨࠩ嶯"): request = l1l1ll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ嶰")
	#if l1l1ll_l1_ (u"ࠪࡣࡤ࠭嶱") in l1l1111lll11_l1_: l1l1111lll11_l1_ = l1l1ll_l1_ (u"ࠫࠬ嶲")
	#if l1l1ll_l1_ (u"ࠬࡹࡳ࠾ࠩ嶳") in url: url = url.split(l1l1ll_l1_ (u"࠭ࡳࡴ࠿ࠪ嶴"))[0]
	useragent = l1l11lll1_l1_()
	#useragent = l1l1ll_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠶࠶࠹࠯࠲࠱࠴࠳࠶ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠠࡆࡦࡪ࠳࠶࠶࠹࠯࠲࠱࠵࠺࠷࠸࠯࠹࠳ࠫ嶵")
	headers2 = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ嶶"):useragent,l1l1ll_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ嶷"):l1l1ll_l1_ (u"ࠪࡔࡗࡋࡆ࠾ࡪ࡯ࡁࡦࡸࠧ嶸")}
	#headers2 = headers.copy()
	global settings
	if not data: data = settings.getSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭嶹"))
	if data.count(l1l1ll_l1_ (u"ࠬࡀ࠺࠻ࠩ嶺"))==4: l1l11111ll11_l1_,key,l1l111111ll1_l1_,l11llllll111_l1_,token = data.split(l1l1ll_l1_ (u"࠭࠺࠻࠼ࠪ嶻"))
	else: l1l11111ll11_l1_,key,l1l111111ll1_l1_,l11llllll111_l1_,token = l1l1ll_l1_ (u"ࠧࠨ嶼"),l1l1ll_l1_ (u"ࠨࠩ嶽"),l1l1ll_l1_ (u"ࠩࠪ嶾"),l1l1ll_l1_ (u"ࠪࠫ嶿"),l1l1ll_l1_ (u"ࠫࠬ巀")
	data2 = {l1l1ll_l1_ (u"ࠧࡩ࡯࡯ࡶࡨࡼࡹࠨ巁"):{l1l1ll_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ巂"):{l1l1ll_l1_ (u"ࠢࡩ࡮ࠥ巃"):l1l1ll_l1_ (u"ࠣࡣࡵࠦ巄"),l1l1ll_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ巅"):l1l1ll_l1_ (u"࡛ࠥࡊࡈࠢ巆"),l1l1ll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ巇"):l1l111111ll1_l1_}}}
	if url==l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠭巈") or l1l1ll_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ巉") in url:
		url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡲࡦࡧ࡯࠳ࡷ࡫ࡥ࡭ࡡࡺࡥࡹࡩࡨࡠࡵࡨࡵࡺ࡫࡮ࡤࡧࠪ巊")+l1l1ll_l1_ (u"ࠨࡁ࡮ࡩࡾࡃࠧ巋")+key
		data2[l1l1ll_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨࡔࡦࡸࡡ࡮ࡵࠪ巌")] = l1l11111ll11_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ巍"),url,data2,headers2,True,True,l1l1ll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠷ࡳࡵࠩ巎"))
	elif l1l1ll_l1_ (u"ࠬ࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ巏") in url:
		url = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ巐")+key
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ巑"),url,data2,headers2,True,True,l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠶ࡶࡩ࠭巒"))
	elif l1l1ll_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ巓") in url and l1l11111ll11_l1_:
		data2[l1l1ll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩ巔")] = token
		data2[l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ巕")][l1l1ll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࠬ巖")][l1l1ll_l1_ (u"࠭ࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠫ巗")] = l1l11111ll11_l1_
		data2 = str(data2)
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ巘"),url,data2,headers2,True,True,l1l1ll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠷ࡸ࡭࠭巙"))
	elif l1l1ll_l1_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ巚") in url and l11llllll111_l1_:
		headers2.update({l1l1ll_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡎࡢ࡯ࡨࠫ巛"):l1l1ll_l1_ (u"ࠫ࠶࠭巜"),l1l1ll_l1_ (u"ࠬ࡞࡚࠭ࡱࡸࡘࡺࡨࡥ࠮ࡅ࡯࡭ࡪࡴࡴ࠮ࡘࡨࡶࡸ࡯࡯࡯ࠩ川"):l1l111111ll1_l1_})
		headers2.update({l1l1ll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭州"):l1l1ll_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࡂ࠭巟")+l11llllll111_l1_})
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ巠"),url,l1l1ll_l1_ (u"ࠩࠪ巡"),headers2,l1l1ll_l1_ (u"ࠪࠫ巢"),l1l1ll_l1_ (u"ࠫࠬ巣"),l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠵ࡵࡪࠪ巤"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ工"),url,l1l1ll_l1_ (u"ࠧࠨ左"),headers2,l1l1ll_l1_ (u"ࠨࠩ巧"),l1l1ll_l1_ (u"ࠩࠪ巨"),l1l1ll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠻ࡺࡨࠨ巩"))
	html = response.content
	tmp = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡯࡮࡯ࡧࡵࡸࡺࡨࡥࡂࡲ࡬ࡏࡪࡿࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ巪"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"ࠬࠨࡣࡷࡧࡵࠦ࠳࠰࠿ࠣࡸࡤࡰࡺ࡫ࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ巫"),html,re.DOTALL|re.I)
	if tmp: l1l111111ll1_l1_ = tmp[0]
	tmp = re.findall(l1l1ll_l1_ (u"࠭ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ巬"),html,re.DOTALL|re.I)
	if tmp: l1l11111ll11_l1_ = tmp[0]
	#tmp = re.findall(l1l1ll_l1_ (u"ࠧࠣࡶࡲ࡯ࡪࡴࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ巭"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l1l1ll_l1_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ差"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠤ࠽ࡿࠧࡺ࡯࡬ࡧࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭巯"),html,re.DOTALL|re.I)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ巰"),l1l1ll_l1_ (u"ࠫࠬ己"),l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ已"),str(len(tmp)))
	#if tmp: l1l11111l1l1_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l1l1ll_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ巳") in list(cookies.keys()): l11llllll111_l1_ = cookies[l1l1ll_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ巴")]
	l1l111l11_l1_ = l1l11111ll11_l1_+l1l1ll_l1_ (u"ࠨ࠼࠽࠾ࠬ巵")+key+l1l1ll_l1_ (u"ࠩ࠽࠾࠿࠭巶")+l1l111111ll1_l1_+l1l1ll_l1_ (u"ࠪ࠾࠿ࡀࠧ巷")+l11llllll111_l1_+l1l1ll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ巸")+token
	if request==l1l1ll_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ巹") and l1l1ll_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭巺") in html:
		l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡸ࡫ࡱࡨࡴࡽ࡜࡜ࠤࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠤ࡟ࡡࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ巻"),html,re.DOTALL)
		if not l11l11lll1_l1_: l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ巼"),html,re.DOTALL)
		l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭巽"),l11l11lll1_l1_[0])
	elif request==l1l1ll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ巾") and l1l1ll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ巿") in html:
		l11l11lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ帀"),html,re.DOTALL)
		l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"࠭ࡳࡵࡴࠪ币"),l11l11lll1_l1_[0])
	elif l1l1ll_l1_ (u"ࠧ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ市") not in html: l11llll1ll11_l1_ = EVAL(l1l1ll_l1_ (u"ࠨࡵࡷࡶࠬ布"),html)
	else: l11llll1ll11_l1_ = l1l1ll_l1_ (u"ࠩࠪ帄")
	if 0:
		cc = str(l11llll1ll11_l1_)
		if kodi_version>18.99: cc = cc.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ帅"))
		open(l1l1ll_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱ࡨࡦࡺࠧ帆"),l1l1ll_l1_ (u"ࠬࡽࡢࠨ帇")).write(cc)
		#open(l1l1ll_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ师"),l1l1ll_l1_ (u"ࠧࡸࠩ帉")).write(html)
	settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ帊"),l1l111l11_l1_)
	return html,l11llll1ll11_l1_,l1l111l11_l1_
def l1l1111ll11l_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l1l1ll_l1_ (u"ࠩࠣࠫ帋"),l1l1ll_l1_ (u"ࠪ࠯ࠬ希"))
	url2 = url+l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ帍")+search
	l11l1l_l1_(url2,index)
	return
def SEARCH(search):
	#search = l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ帎")+l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࠫ帏")+l1l1ll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ帐")+l1l1ll_l1_ (u"ࠨࡡࠪ帑")+search
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ帒"),l1l1ll_l1_ (u"ࠪࠫ帓"),l1l1ll_l1_ (u"ࠫࠬ帔"),search)
	search,options,showDialogs = SEARCH_OPTIONS(search)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭帕"),l1l1ll_l1_ (u"࠭ࠧ帖"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ帗"),l1l1ll_l1_ (u"ࠨ࠭ࠪ帘"))
	url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࠫ帙")+search
	if not showDialogs:
		if l1l1ll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭帚") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡑࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ帛")
		elif l1l1ll_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ帜") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭帝")
		elif l1l1ll_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬ帞") in options: l11llllll1l1_l1_ = l1l1ll_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄ࡫ࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ帟")
		else: l11llllll1l1_l1_ = l1l1ll_l1_ (u"ࠩࠪ帠")
		url3 = url2+l11llllll1l1_l1_
	else:
		l11llllll11l_l1_,l11llll1l111_l1_,title2 = [],[],l1l1ll_l1_ (u"ࠪࠫ帡")
		l11llll1l1l1_l1_ = [l1l1ll_l1_ (u"ࠫอี่็ࠢอีฯ๐ศࠨ帢"),l1l1ll_l1_ (u"ࠬะัห์หࠤาูศࠡ็าํࠥอไึๆฬࠫ帣"),l1l1ll_l1_ (u"࠭สาฬํฬࠥำำษࠢอหึ๐ฮࠡษ็ฮา๋๊ๅࠩ帤"),l1l1ll_l1_ (u"ࠧหำอ๎อࠦอิสࠣ฽ิีࠠศๆุ่ฬํฯศฬࠪ帥"),l1l1ll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฬ๊สใ์ํ้ࠬ带")]
		l1l1111l111l_l1_ = [l1l1ll_l1_ (u"ࠩࠪ帧"),l1l1ll_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡄࠩ࠷࠻࠳ࡅࠩ帨"),l1l1ll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡍࠪ࠸࠵࠴ࡆࠪ帩"),l1l1ll_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡒࠫ࠲࠶࠵ࡇࠫ帪"),l1l1ll_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡋࠥ࠳࠷࠶ࡈࠬ師")]
		l1l1111l1ll1_l1_ = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไหำอ๎อ࠭帬"),l11llll1l1l1_l1_)
		if l1l1111l1ll1_l1_ == -1: return
		l11lllll1lll_l1_ = l1l1111l111l_l1_[l1l1111l1ll1_l1_]
		html,c,data = l1l111111111_l1_(url2+l11lllll1lll_l1_)
		if c:
			try:
				d = c[l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ席")][l1l1ll_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ帮")][l1l1ll_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ帯")][l1l1ll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ帰")][l1l1ll_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭帱")][l1l1ll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ帲")][l1l1ll_l1_ (u"ࠧࡨࡴࡲࡹࡵࡹࠧ帳")]
				for l11llll11lll_l1_ in range(len(d)):
					group = d[l11llll11lll_l1_][l1l1ll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡇࡳࡱࡸࡴࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭帴")][l1l1ll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ帵")]
					for l1l1111ll1l1_l1_ in range(len(group)):
						render = group[l1l1111ll1l1_l1_][l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ帶")]
						if l1l1ll_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ帷") in list(render.keys()):
							link = render[l1l1ll_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ常")][l1l1ll_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ帹")][l1l1ll_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ帺")][l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ帻")]
							link = link.replace(l1l1ll_l1_ (u"ࠩ࡟ࡹ࠵࠶࠲࠷ࠩ帼"),l1l1ll_l1_ (u"ࠪࠪࠬ帽"))
							title = render[l1l1ll_l1_ (u"ࠫࡹࡵ࡯࡭ࡶ࡬ࡴࠬ帾")]
							title = title.replace(l1l1ll_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠࠨ帿"),l1l1ll_l1_ (u"࠭ࠧ幀"))
							if l1l1ll_l1_ (u"ࠧฦิส่ฮࠦวๅใ็ฮึ࠭幁") in title: continue
							if l1l1ll_l1_ (u"ࠨไสส๊ฯࠠหึ฽๎้࠭幂") in title:
								title = l1l1ll_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ幃")+title
								title2 = title
								l111111l1_l1_ = link
							if l1l1ll_l1_ (u"ࠪฮึะ๊ษࠢะือ࠭幄") in title: continue
							title = title.replace(l1l1ll_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠡࠩ幅"),l1l1ll_l1_ (u"ࠬ࠭幆"))
							if l1l1ll_l1_ (u"࠭ࡒࡦ࡯ࡲࡺࡪ࠭幇") in title: continue
							if l1l1ll_l1_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩ幈") in title:
								title = l1l1ll_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ幉")+title
								title2 = title
								l111111l1_l1_ = link
							if l1l1ll_l1_ (u"ࠩࡖࡳࡷࡺࠠࡣࡻࠪ幊") in title: continue
							l11llllll11l_l1_.append(escapeUNICODE(title))
							l11llll1l111_l1_.append(link)
			except: pass
		if not title2: l1l11111lll1_l1_ = l1l1ll_l1_ (u"ࠪࠫ幋")
		else:
			l11llllll11l_l1_ = [l1l1ll_l1_ (u"ࠫอี่็ࠢไ่ฯืࠧ幌"),title2]+l11llllll11l_l1_
			l11llll1l111_l1_ = [l1l1ll_l1_ (u"ࠬ࠭幍"),l111111l1_l1_]+l11llll1l111_l1_
			l1l1111ll111_l1_ = DIALOG_SELECT(l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊แๅฬิࠫ幎"),l11llllll11l_l1_)
			if l1l1111ll111_l1_ == -1: return
			l1l11111lll1_l1_ = l11llll1l111_l1_[l1l1111ll111_l1_]
		if l1l11111lll1_l1_: url3 = l1l1l1_l1_+l1l11111lll1_l1_
		elif l11lllll1lll_l1_: url3 = url2+l11lllll1lll_l1_
		else: url3 = url2
		l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡬ࡩ࡭ࡶࡨࡶ࠲ࡪࡲࡰࡲࡧࡳࡼࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡶࡩࡨࡺࡩࡰࡰࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡫ࡩࠤࠬࡘࡥ࡮ࡱࡹࡩࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠧ࠭ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠬࠎࠎࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡗࡴࡸࡴࠡࡤࡼࠫ࠱࠭ࡓࡰࡴࡷࠤࡧࡿ࠺ࠡࠢࠪ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡺࡩࡵ࡮ࡨࠤࡂࠦࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢࡵ࠱࠲࠵࠺ࠬ࠲ࠧࠧࠩࠬࠎࠎࠏࠉࠊ࡫ࡩࠤ࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࠉࡧ࡫࡯ࡩࡹ࡫ࡲࡍࡋࡖࡘࡤࡹࡥࡢࡴࡦ࡬࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡦࡣࡵࡧ࡭࠴ࡡࡱࡲࡨࡲࡩ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥ࠭ࡓࡰࡴࡷࠤࡧࡿ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡴࡸࡴ࠯ࡣࡳࡴࡪࡴࡤࠩࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩࠪࠌࠌࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࡡࡶࡳࡷࡺ࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠤࠥࠦ幏")
	#DIALOG_OK()
	l11l1l_l1_(url3)
	return
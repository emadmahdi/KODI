# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩമ")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧയ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1lll11l1_l1_ = [l1l1ll_l1_ (u"ࠩ࠴࠶࠸࠿ࠧര"),l1l1ll_l1_ (u"ࠪ࠵࠷࠻࠰ࠨറ"),l1l1ll_l1_ (u"ࠫ࠶࠸࠴࠶ࠩല"),l1l1ll_l1_ (u"ࠬ࠸࠰ࠨള"),l1l1ll_l1_ (u"࠭࠱࠳࠷࠼ࠫഴ"),l1l1ll_l1_ (u"ࠧ࠳࠳࠻ࠫവ"),l1l1ll_l1_ (u"ࠨ࠶࠻࠹ࠬശ"),l1l1ll_l1_ (u"ࠩ࠴࠶࠸࠾ࠧഷ"),l1l1ll_l1_ (u"ࠪ࠵࠷࠻࠸ࠨസ"),l1l1ll_l1_ (u"ࠫ࠷࠿࠲ࠨഹ")]
l1lll111l_l1_ = [l1l1ll_l1_ (u"ࠬ࠹࠰࠴࠲ࠪഺ"),l1l1ll_l1_ (u"࠭࠶࠳࠺഻ࠪ")]
def MAIN(mode,url,text):
	if   mode==60: results = MENU()
	elif mode==61: results = l11l1l_l1_(url,text)
	elif mode==62: results = l11ll1l_l1_(url)
	elif mode==63: results = PLAY(url)
	elif mode==64: results = l1lll11ll_l1_(text)
	elif mode==69: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ഼ࠧ"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨഽ"),l1l1ll_l1_ (u"ࠩࠪാ"),69,l1l1ll_l1_ (u"ࠪࠫി"),l1l1ll_l1_ (u"ࠫࠬീ"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩു"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ൂ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩൃ")+menu_name+l1l1ll_l1_ (u"ࠨ็สࠤ๏ะๅࠡ็ืห์ีส่ࠢส่ฬ์ࠧൄ"),l1l1l1_l1_,64,l1l1ll_l1_ (u"ࠩࠪ൅"),l1l1ll_l1_ (u"ࠪࠫെ"),l1l1ll_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡣࡻ࡯ࡥࡸࡧࡧࡣࡻ࡯ࡤࡴࠩേ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬൈ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ൉")+menu_name+l1l1ll_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧൊ"),l1l1l1_l1_,64,l1l1ll_l1_ (u"ࠨࠩോ"),l1l1ll_l1_ (u"ࠩࠪൌ"),l1l1ll_l1_ (u"ࠪࡱࡴࡹࡴࡠࡸ࡬ࡩࡼ࡫ࡤࡠࡸ࡬ࡨࡸ്࠭"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൎ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ൏")+menu_name+l1l1ll_l1_ (u"࠭วื์ไฮ๋ࠥฤฯำสࠫ൐"),l1l1l1_l1_,64,l1l1ll_l1_ (u"ࠧࠨ൑"),l1l1ll_l1_ (u"ࠨࠩ൒"),l1l1ll_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࡮ࡼࡣࡦࡪࡤࡦࡦࡢࡺ࡮ࡪࡳࠨ൓"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪൔ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ൕ")+menu_name+l1l1ll_l1_ (u"ࠬ็๊ะ์๋ࠤ฾ฺ่ศศํࠫൖ"),l1l1l1_l1_,64,l1l1ll_l1_ (u"࠭ࠧൗ"),l1l1ll_l1_ (u"ࠧࠨ൘"),l1l1ll_l1_ (u"ࠨࡴࡤࡲࡩࡵ࡭ࡠࡸ࡬ࡨࡸ࠭൙"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ൚"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ൛")+menu_name+l1l1ll_l1_ (u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬ൜"),l1l1l1_l1_,61,l1l1ll_l1_ (u"ࠬ࠭൝"),l1l1ll_l1_ (u"࠭ࠧ൞"),l1l1ll_l1_ (u"ࠧ࠮࠳ࠪൟ"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨൠ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫൡ")+menu_name+l1l1ll_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊ฯ๋่ํอࠬൢ"),l1l1l1_l1_,61,l1l1ll_l1_ (u"ࠫࠬൣ"),l1l1ll_l1_ (u"ࠬ࠭൤"),l1l1ll_l1_ (u"࠭࠭࠳ࠩ൥"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ൦"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ൧")+menu_name+l1l1ll_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪ࡚ࠣ࡮ࡪࡥࡰࡵࠪ൨"),l1l1l1_l1_,61,l1l1ll_l1_ (u"ࠪࠫ൩"),l1l1ll_l1_ (u"ࠫࠬ൪"),l1l1ll_l1_ (u"ࠬ࠳࠳ࠨ൫"))
	return l1l1ll_l1_ (u"࠭ࠧ൬")
def l11l1l_l1_(url,category):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ൭"),l1l1ll_l1_ (u"ࠨࠩ൮"),l1l1ll_l1_ (u"ࠩࠪ൯"), category)
	cat = l1l1ll_l1_ (u"ࠪࠫ൰")
	if category not in [l1l1ll_l1_ (u"ࠫ࠲࠷ࠧ൱"),l1l1ll_l1_ (u"ࠬ࠳࠲ࠨ൲"),l1l1ll_l1_ (u"࠭࠭࠴ࠩ൳")]: cat = l1l1ll_l1_ (u"ࠧࡀࡥࡤࡸࡂ࠭൴")+category
	url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡰࡩࡳࡻ࡟࡭ࡧࡹࡩࡱ࠴ࡰࡩࡲࠪ൵")+cat
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠩࠪ൶"),l1l1ll_l1_ (u"ࠪࠫ൷"),l1l1ll_l1_ (u"ࠫࠬ൸"),l1l1ll_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ൹"))
	items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬൺ"),html,re.DOTALL)
	l1lll1111_l1_,l1lll1lll_l1_ = False,False
	for link,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩൻ"))
		if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ർ") not in link: link = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨൽ")+link
		cat = re.findall(l1l1ll_l1_ (u"ࠪࡧࡦࡺ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧൾ"),link,re.DOTALL)[0]
		if category==cat: l1lll1111_l1_ = True
		elif l1lll1111_l1_ 	or (category==l1l1ll_l1_ (u"ࠫ࠲࠷ࠧൿ") and cat in l1lll11l1_l1_) \
						or (category==l1l1ll_l1_ (u"ࠬ࠳࠲ࠨ඀") and cat not in l1lll111l_l1_ and cat not in l1lll11l1_l1_) \
						or (category==l1l1ll_l1_ (u"࠭࠭࠴ࠩඁ") and cat in l1lll111l_l1_):
							if count==l1l1ll_l1_ (u"ࠧ࠲ࠩං"): addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧඃ"),menu_name+title,link,63)
							else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ඄"),menu_name+title,link,61,l1l1ll_l1_ (u"ࠪࠫඅ"),l1l1ll_l1_ (u"ࠫࠬආ"),cat)
							l1lll1lll_l1_ = True
	if not l1lll1lll_l1_: l11ll1l_l1_(url)
	return
def l11ll1l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠬ࠭ඇ"),l1l1ll_l1_ (u"࠭ࠧඈ"),True,l1l1ll_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨඉ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩඊ"),l1l1ll_l1_ (u"ࠩࠪඋ"),url , html)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠨඌ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡬ࡸࡩࡥࡡࡹ࡭ࡪࡽ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩඍ"),block,re.DOTALL)
	link = l1l1ll_l1_ (u"ࠬ࠭ඎ")
	for img,title,link in items:
		title = title.replace(l1l1ll_l1_ (u"࠭ࡁࡥࡦࠪඏ"),l1l1ll_l1_ (u"ࠧࠨඐ")).replace(l1l1ll_l1_ (u"ࠨࡶࡲࠤࡖࡻࡩࡤ࡭࡯࡭ࡸࡺࠧඑ"),l1l1ll_l1_ (u"ࠩࠪඒ")).strip(l1l1ll_l1_ (u"ࠪࠤࠬඓ"))
		if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩඔ") not in link: link = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫඕ")+link
		addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬඖ"),menu_name+title,link,63,img)
	l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ඗"),block,re.DOTALL)
	block=l1lll11_l1_[0]
	block=re.findall(l1l1ll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ඘"),html,re.DOTALL)[0]
	items=re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ඙"),block,re.DOTALL)
	url2 = url.split(l1l1ll_l1_ (u"ࠪࡃࠬක"))[0]
	for link,l1ll1lll1_l1_ in items:
		link = url2 + link
		title = unescapeHTML(l1ll1lll1_l1_)
		title = l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪඛ") + title
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬග"),menu_name+title,link,62)
	return link
def PLAY(url):
	if l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪඝ") in url: url = l11ll1l_l1_(url)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠧࠨඞ"),l1l1ll_l1_ (u"ࠨࠩඟ"),True,l1l1ll_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ච"))
	items = re.findall(l1l1ll_l1_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪඡ"),html,re.DOTALL)
	url = items[0]
	if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩජ") not in url: url = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫඣ")+url
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬඤ"))
	return
def l1lll11ll_l1_(category):
	payload = { l1l1ll_l1_ (u"ࠧ࡮ࡱࡧࡩࠬඥ") : category }
	url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠵ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࠨඦ")
	headers = { l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨට") : l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩඨ") }
	data = l1lll1l11_l1_(payload)
	html = OPENURL_CACHED(l1llll1l1_l1_,url,data,headers,True,l1l1ll_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡍࡐࡕࡗࡗ࠲࠷ࡳࡵࠩඩ"))
	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫࠭ඪ"),html,re.DOTALL)
	for link,title,img in items:
		title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨණ"))
		if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬඬ") not in link: link = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧත")+link
		addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨථ"),menu_name+title,link,63,img)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠪࠫද"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠫࠬධ"): return
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭න"),l1l1ll_l1_ (u"࠭ࠧ඲"),search, l1l1l1_l1_)
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩඳ"),l1l1ll_l1_ (u"ࠨ࠭ࠪප"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡶࡪࡹࡵ࡭ࡶ࠱ࡴ࡭ࡶ࠿ࡲࡷࡨࡶࡾࡃࠧඵ") + l11lll1_l1_ # + l1l1ll_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿࠴ࠫබ")
	l11ll1l_l1_(url)
	return
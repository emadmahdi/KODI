# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫ䈓")
menu_name = l1l1ll_l1_ (u"ࠫࡤࡒࡓࡕࡡࠪ䈔")
l11llllllll_l1_ = 5
l11llll111l_l1_ = 10
def MAIN(mode,url,text,page,infodict):
	try: folder = str(infodict[l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈕")])
	except: folder = l1l1ll_l1_ (u"࠭ࠧ䈖")
	if   mode==160: results = MENU()
	elif mode==161: results = l1l1111ll11_l1_(text)
	elif mode==162: results = l11lll11l11_l1_(text,162)
	elif mode==163: results = l11lll11l11_l1_(text,163)
	elif mode==164: results = l1l1111l1l1_l1_(text)
	elif mode==165: results = l11llllll11_l1_(folder,text,page)
	elif mode==166: results = l1l111111ll_l1_(url,text)
	elif mode==167: results = l11ll1ll111_l1_(url,text)
	elif mode==168: results = l11ll11ll11_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䈗"),l1l1ll_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆࠡ฻ื์ฬฬ๊สࠩ䈘"),l1l1ll_l1_ (u"ࠩࠪ䈙"),161,l1l1ll_l1_ (u"ࠪࠫ䈚"),l1l1ll_l1_ (u"ࠫࠬ䈛"),l1l1ll_l1_ (u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䈜"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈝"),l1l1ll_l1_ (u"ࠧใี่ࠤ฾ฺ่ศศํࠫ䈞"),l1l1ll_l1_ (u"ࠨࠩ䈟"),162,l1l1ll_l1_ (u"ࠩࠪ䈠"),l1l1ll_l1_ (u"ࠪࠫ䈡"),l1l1ll_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䈢"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈣"),l1l1ll_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊สࠩ䈤"),l1l1ll_l1_ (u"ࠧࠨ䈥"),163,l1l1ll_l1_ (u"ࠨࠩ䈦"),l1l1ll_l1_ (u"ࠩࠪ䈧"),l1l1ll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䈨"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䈩"),l1l1ll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠษฯฮࠤ฾ฺ่ศศํࠫ䈪"),l1l1ll_l1_ (u"࠭ࠧ䈫"),164,l1l1ll_l1_ (u"ࠧࠨ䈬"),l1l1ll_l1_ (u"ࠨࠩ䈭"),l1l1ll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䈮"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䈯"),l1l1ll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠠๆ่ࠣๆุ๋ࠧ䈰"),l1l1ll_l1_ (u"ࠬ࠭䈱"),165,l1l1ll_l1_ (u"࠭ࠧ䈲"),l1l1ll_l1_ (u"ࠧࠨ䈳"),l1l1ll_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ䈴"))
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䈵"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䈶"),l1l1ll_l1_ (u"ࠫࠬ䈷"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈸"),l1l1ll_l1_ (u"࠭โ็๊สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋หࠪ䈹"),l1l1ll_l1_ (u"ࠧࠨ䈺"),163,l1l1ll_l1_ (u"ࠨࠩ䈻"),l1l1ll_l1_ (u"ࠩࠪ䈼"),l1l1ll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䈽"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䈾"),l1l1ll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ䈿"),l1l1ll_l1_ (u"࠭ࠧ䉀"),163,l1l1ll_l1_ (u"ࠧࠨ䉁"),l1l1ll_l1_ (u"ࠨࠩ䉂"),l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䉃"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉄"),l1l1ll_l1_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํࠫ䉅"),l1l1ll_l1_ (u"ࠬ࠭䉆"),162,l1l1ll_l1_ (u"࠭ࠧ䉇"),l1l1ll_l1_ (u"ࠧࠨ䉈"),l1l1ll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䉉"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉊"),l1l1ll_l1_ (u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ䉋"),l1l1ll_l1_ (u"ࠫࠬ䉌"),162,l1l1ll_l1_ (u"ࠬ࠭䉍"),l1l1ll_l1_ (u"࠭ࠧ䉎"),l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䉏"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉐"),l1l1ll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡสะฯࠥ฿ิ้ษษ๎ࠬ䉑"),l1l1ll_l1_ (u"ࠪࠫ䉒"),164,l1l1ll_l1_ (u"ࠫࠬ䉓"),l1l1ll_l1_ (u"ࠬ࠭䉔"),l1l1ll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䉕"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䉖"),l1l1ll_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ䉗"),l1l1ll_l1_ (u"ࠩࠪ䉘"),165,l1l1ll_l1_ (u"ࠪࠫ䉙"),l1l1ll_l1_ (u"ࠫࠬ䉚"),l1l1ll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䉛"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䉜"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䉝"),l1l1ll_l1_ (u"ࠨࠩ䉞"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉟"),l1l1ll_l1_ (u"ࠪๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠨ䉠"),l1l1ll_l1_ (u"ࠫࠬ䉡"),163,l1l1ll_l1_ (u"ࠬ࠭䉢"),l1l1ll_l1_ (u"࠭ࠧ䉣"),l1l1ll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䉤"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉥"),l1l1ll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ䉦"),l1l1ll_l1_ (u"ࠪࠫ䉧"),163,l1l1ll_l1_ (u"ࠫࠬ䉨"),l1l1ll_l1_ (u"ࠬ࠭䉩"),l1l1ll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䉪"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䉫"),l1l1ll_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ࠩ䉬"),l1l1ll_l1_ (u"ࠩࠪ䉭"),162,l1l1ll_l1_ (u"ࠪࠫ䉮"),l1l1ll_l1_ (u"ࠫࠬ䉯"),l1l1ll_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡒࡉࡗࡇࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䉰"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䉱"),l1l1ll_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ࠨ䉲"),l1l1ll_l1_ (u"ࠨࠩ䉳"),162,l1l1ll_l1_ (u"ࠩࠪ䉴"),l1l1ll_l1_ (u"ࠪࠫ䉵"),l1l1ll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䉶"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉷"),l1l1ll_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘ࡛ࠦศฮอࠣ฽ู๎วว์ࠪ䉸"),l1l1ll_l1_ (u"ࠧࠨ䉹"),164,l1l1ll_l1_ (u"ࠨࠩ䉺"),l1l1ll_l1_ (u"ࠩࠪ䉻"),l1l1ll_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䉼"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉽"),l1l1ll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭䉾"),l1l1ll_l1_ (u"࠭ࠧ䉿"),165,l1l1ll_l1_ (u"ࠧࠨ䊀"),l1l1ll_l1_ (u"ࠨࠩ䊁"),l1l1ll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䊂"))
	return
def l1l1111ll11_l1_(options):
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䊃"),l1l1ll_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ䊄"),l1l1ll_l1_ (u"ࠬ࠭䊅"),161,l1l1ll_l1_ (u"࠭ࠧ䊆"),l1l1ll_l1_ (u"ࠧࠨ䊇"),l1l1ll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䊈"))
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䊉"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䊊"),l1l1ll_l1_ (u"ࠫࠬ䊋"),9999)
	l11lll1ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊌"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢ࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䊍")+l1l1ll_l1_ (u"ࠧใ่๋หฯูࠦาสํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䊎"),l1l1ll_l1_ (u"ࠨࠩ䊏"),147)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊐"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡙ࠦࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䊑")+l1l1ll_l1_ (u"ࠫ็์่ศฬࠣวั์ศ๋ห้๋๊้ࠣࠦฬํ์อ࠭䊒"),l1l1ll_l1_ (u"ࠬ࠭䊓"),148)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊔"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䊕")+l1l1ll_l1_ (u"ࠨไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠪ䊖"),l1l1ll_l1_ (u"ࠩࠪ䊗"),28)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䊘"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䊙")+l1l1ll_l1_ (u"่ࠬๆศหࠣหู้๋ศำไࠤ๊์ࠠๆ๊ๅ฽์๋ࠧ䊚"),l1l1ll_l1_ (u"࠭ࠧ䊛"),41)
	#addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䊜"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䊝")+l1l1ll_l1_ (u"ࠩๅ๊ฬฯࠠศๆๆ์ะืࠠๆ่้ࠣํู่่็ࠪ䊞"),l1l1ll_l1_ (u"ࠪࠫ䊟"),135)
	import l1l1l1l1l11_l1_
	l1l1l1l1l11_l1_.ITEMS(l1l1ll_l1_ (u"ࠫ࠵࠭䊠"),False)
	l1l1l1l1l11_l1_.ITEMS(l1l1ll_l1_ (u"ࠬ࠷ࠧ䊡"),False)
	l1l1l1l1l11_l1_.ITEMS(l1l1ll_l1_ (u"࠭࠲ࠨ䊢"),False)
	#l1l1l1l1l11_l1_.ITEMS(l1l1ll_l1_ (u"ࠧ࠴ࠩ䊣"),False)
	if l1l1ll_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䊤") in options:
		menuItemsLIST[:] = l11lll11lll_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l11llllllll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11llllllll_l1_)
	menuItemsLIST[:] = l11lll1ll1l_l1_+menuItemsLIST
	return
def l1l1111l1l1_l1_(options):
	options = options.replace(l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䊥"),l1l1ll_l1_ (u"ࠪࠫ䊦")).replace(l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䊧"),l1l1ll_l1_ (u"ࠬ࠭䊨"))
	headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䊩") : l1l1ll_l1_ (u"ࠧࠨ䊪") }
	url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ䊫")
	payload = { l1l1ll_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ䊬") : l1l1ll_l1_ (u"ࠪ࠹࠵࠭䊭") }
	data = l1lll1l11_l1_(payload)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䊮"),l1l1ll_l1_ (u"ࠬ࠭䊯"),l1l1ll_l1_ (u"࠭ࠧ䊰"),str(data))
	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䊱"),url,data,headers,l1l1ll_l1_ (u"ࠨࠩ䊲"),l1l1ll_l1_ (u"ࠩࠪ䊳"),l1l1ll_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖ࠱ࡗࡇࡎࡅࡑࡐࡣ࡛ࡏࡄࡆࡑࡖࡣࡋࡘࡏࡎࡡ࡚ࡓࡗࡊࡓ࠮࠳ࡶࡸࠬ䊴"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧ࠭䊵"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ䊶"),block,re.DOTALL)
	l11ll11l11l_l1_,l11ll1l1ll1_l1_ = list(zip(*items))
	l11lllll1ll_l1_ = []
	l1l1111l11l_l1_ = [l1l1ll_l1_ (u"࠭ࠠࠨ䊷"),l1l1ll_l1_ (u"ࠧࠣࠩ䊸"),l1l1ll_l1_ (u"ࠨࡢࠪ䊹"),l1l1ll_l1_ (u"ࠩ࠯ࠫ䊺"),l1l1ll_l1_ (u"ࠪ࠲ࠬ䊻"),l1l1ll_l1_ (u"ࠫ࠿࠭䊼"),l1l1ll_l1_ (u"ࠬࡁࠧ䊽"),l1l1ll_l1_ (u"ࠨࠧࠣ䊾"),l1l1ll_l1_ (u"ࠧ࠮ࠩ䊿")]
	l11ll1lllll_l1_ = l11ll1l1ll1_l1_+l11ll11l11l_l1_
	for word in l11ll1lllll_l1_:
		if word in l11ll1l1ll1_l1_: l11llll1l11_l1_ = 2
		if word in l11ll11l11l_l1_: l11llll1l11_l1_ = 4
		l1l11111ll1_l1_ = [i in word for i in l1l1111l11l_l1_]
		if any(l1l11111ll1_l1_):
			index = l1l11111ll1_l1_.index(True)
			splitter = l1l1111l11l_l1_[index]
			l1l1111111l_l1_ = l1l1ll_l1_ (u"ࠨࠩ䋀")
			if word.count(splitter)>1: l1l111111l1_l1_,l1l11111111_l1_,l1l1111111l_l1_ = word.split(splitter,2)
			else: l1l111111l1_l1_,l1l11111111_l1_ = word.split(splitter,1)
			if len(l1l111111l1_l1_)>l11llll1l11_l1_: l11lllll1ll_l1_.append(l1l111111l1_l1_.lower())
			if len(l1l11111111_l1_)>l11llll1l11_l1_: l11lllll1ll_l1_.append(l1l11111111_l1_.lower())
			if len(l1l1111111l_l1_)>l11llll1l11_l1_: l11lllll1ll_l1_.append(l1l1111111l_l1_.lower())
		elif len(word)>l11llll1l11_l1_: l11lllll1ll_l1_.append(word.lower())
	for i in range(9): random.shuffle(l11lllll1ll_l1_)
	#selection = DIALOG_SELECT(str(len(l11lllll1ll_l1_)),l11lllll1ll_l1_)
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ䋁")
	if l1l1ll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䋂") in options:
		l11lll1ll11_l1_ = l11ll1llll1_l1_
	elif l1l1ll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䋃") in options:
		l11lll1ll11_l1_ = [l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘࠪ䋄")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"࠭ࠧ䋅"),True): return
	elif l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䋆") in options:
		l11lll1ll11_l1_ = [l1l1ll_l1_ (u"ࠨࡏ࠶࡙ࠬ䋇")]
		import l1l1l11l1l1_l1_
		if not l1l1l11l1l1_l1_.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"ࠩࠪ䋈"),True): return
	count,l11ll11l1l1_l1_ = 0,0
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋉"),l1l1ll_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦ࠺ࠡ࡝ࠣࠤࡢ࠭䋊"),l1l1ll_l1_ (u"ࠬ࠭䋋"),164,l1l1ll_l1_ (u"࠭ࠧ䋌"),l1l1ll_l1_ (u"ࠧࠨ䋍"),l1l1ll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䋎")+options)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋏"),l1l1ll_l1_ (u"ࠪษ฾อฯสࠢส่อำหࠡษ็฽ู๎วว์ࠪ䋐"),l1l1ll_l1_ (u"ࠫࠬ䋑"),164,l1l1ll_l1_ (u"ࠬ࠭䋒"),l1l1ll_l1_ (u"࠭ࠧ䋓"),l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䋔")+options)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䋕"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䋖"),l1l1ll_l1_ (u"ࠪࠫ䋗"),9999)
	l11ll11l111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1111l111_l1_ = []
	for word in l11lllll1ll_l1_:
		l1l11111111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡠࠦ࡜࠭࡞࠾ࡠ࠿ࡢ࠭࡝࠭࡟ࡁࡡࠨ࡜ࠨ࡞࡞ࡠࡢࡢࠨ࡝ࠫ࡟ࡿࡡࢃ࡜ࠢ࡞ࡃࡠࠨࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩ䋘"),word,re.DOTALL)
		if l1l11111111_l1_: word = word.split(l1l11111111_l1_[0],1)[0]
		l11lllll1l1_l1_ = word.replace(l1l1ll_l1_ (u"ࠬ๗ࠧ䋙"),l1l1ll_l1_ (u"࠭ࠧ䋚")).replace(l1l1ll_l1_ (u"ࠧ๏ࠩ䋛"),l1l1ll_l1_ (u"ࠨࠩ䋜")).replace(l1l1ll_l1_ (u"ࠩ๎ࠫ䋝"),l1l1ll_l1_ (u"ࠪࠫ䋞")).replace(l1l1ll_l1_ (u"ࠫ๔࠭䋟"),l1l1ll_l1_ (u"ࠬ࠭䋠")).replace(l1l1ll_l1_ (u"࠭์ࠨ䋡"),l1l1ll_l1_ (u"ࠧࠨ䋢"))
		l11lllll1l1_l1_ = l11lllll1l1_l1_.replace(l1l1ll_l1_ (u"ࠨ๒ࠪ䋣"),l1l1ll_l1_ (u"ࠩࠪ䋤")).replace(l1l1ll_l1_ (u"ࠪ๑ࠬ䋥"),l1l1ll_l1_ (u"ࠫࠬ䋦")).replace(l1l1ll_l1_ (u"ࠬ๘ࠧ䋧"),l1l1ll_l1_ (u"࠭ࠧ䋨")).replace(l1l1ll_l1_ (u"ࠧญࠩ䋩"),l1l1ll_l1_ (u"ࠨࠩ䋪")).replace(l1l1ll_l1_ (u"ࠩใࠫ䋫"),l1l1ll_l1_ (u"ࠪࠫ䋬"))
		if l11lllll1l1_l1_: l1l1111l111_l1_.append(l11lllll1l1_l1_)
	#selection = DIALOG_SELECT(str(len(l1l1111l111_l1_)),l1l1111l111_l1_)
	l11llll1lll_l1_ = []
	for ii in range(0,20):
		search = random.sample(l1l1111l111_l1_,1)[0]
		if search in l11llll1lll_l1_: continue
		l11llll1lll_l1_.append(search)
		site = random.sample(l11lll1ll11_l1_,1)[0]
		LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䋭"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡘ࡬ࡨࡪࡵࠠࡔࡧࡤࡶࡨ࡮ࠠࠡࠢࡶ࡭ࡹ࡫࠺ࠨ䋮")+str(site)+l1l1ll_l1_ (u"࠭ࠠࠡࡵࡨࡥࡷࡩࡨ࠻ࠩ䋯")+search)
		#results = l11lll111ll_l1_(l1l1ll_l1_ (u"ࠧࠨ䋰"),l1l1ll_l1_ (u"ࠨࠩ䋱"),l1l1ll_l1_ (u"ࠩࠪ䋲"),site,l1l1ll_l1_ (u"ࠪࠫ䋳"),l1l1ll_l1_ (u"ࠫࠬ䋴"),search+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ䋵"),l1l1ll_l1_ (u"࠭ࠧ䋶"),l1l1ll_l1_ (u"ࠧࠨ䋷"))
		l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_ = l1ll111lll1_l1_(site)
		l1ll11ll111_l1_(search+l1l1ll_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭䋸"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䋹"),l1l1ll_l1_ (u"ࠪࠫ䋺"))
	l11ll11l111_l1_[0][1] = l1l1ll_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䋻")+search+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆหัะูࠦ็ࠢ࠽ࠤࡠࠦࠧ䋼")
	menuItemsLIST[:] = l11lll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l11llllllll_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l11llllllll_l1_)
	menuItemsLIST[:] = l11ll11l111_l1_+menuItemsLIST
	#import l1lll1ll111_l1_
	#l1lll1ll111_l1_.SEARCH(search)
	return
def l1l11111lll_l1_(site):
	l1ll11l11l1_l1_,l1ll11ll111_l1_,l1ll1l1lll1_l1_ = l1ll111lll1_l1_(site)
	try:
		if l1l1ll_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ䋽") in site: l1ll11l11l1_l1_(site)
		else: l1ll11l11l1_l1_()
		l11llll1ll1_l1_ = False
	except: l11llll1ll1_l1_ = True
	if l11llll1ll1_l1_: DIALOG_NOTIFICATION(site,l1l1ll_l1_ (u"ࠧโึ็ࠤอํะศࠢส่๊๎โฺࠩ䋾"),time=2000)
	else: DIALOG_NOTIFICATION(site,l1l1ll_l1_ (u"ࠨฬ่ࠤั๊ศࠡษ็ว็ูวๆࠩ䋿"),time=2000)
	return l11llll1ll1_l1_
def l11ll11llll_l1_(l11llll11l1_l1_=True):
	if not l11llll11l1_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䌀"),l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䌁"),l1l1ll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䌂"))
		if results:
			contentsDICT = results
			return
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䌃"),l1l1ll_l1_ (u"࠭ࠧ䌄"),l1l1ll_l1_ (u"ࠧࠨ䌅"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䌆"),l1l1ll_l1_ (u"ࠩ็็๏ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱ࠤฬ๊ศา่ส้ั๊ࠦฮฬสะࠥษๆࠡ์ไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠๅๅํࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱ࠤะ๋๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะี๊ࠥํะ่ࠢส่ศ่ำศ็ࠣัฯ๏ࠠๅษࠣฮาะวอࠢฦ๊ࠥะๅๅศ๊ห๋ࠥัสࠢฦาึ๏ࠠ࠯ࠢ฼้้๐ษࠡ็็สࠥาๅ๋฻ࠣห้ษโิษ่ࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࠱ࠤ์๊ࠠหำํำࠥษๆࠡฬฯ้฾ࠦโศศ่อࠥอไฤไึห๊ࠦวๅฤ้ࠤฤ࠭䌇"))
	if yes!=1: return
	l11ll1l11l1_l1_ = menuItemsLIST[:]
	l11lll1l1l1_l1_,l11lll1l111_l1_ = 0,l1l1ll_l1_ (u"ࠪࠫ䌈")
	for site in l1l11111l1l_l1_:
		l11llll1ll1_l1_ = l1l11111lll_l1_(site)
		if l11llll1ll1_l1_:
			l11lll1l1l1_l1_ += 1
			l11lll1l111_l1_ += l1l1ll_l1_ (u"ࠫࠥ࠭䌉")+site
			if l11lll1l1l1_l1_>=l11llll111l_l1_: break
	menuItemsLIST[:] = l11ll1l11l1_l1_
	if l11lll1l1l1_l1_>=l11llll111l_l1_: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䌊"),l1l1ll_l1_ (u"࠭ࠧ䌋"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䌌"),l1l1ll_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡࠩ䌍")+str(l11lll1l1l1_l1_)+l1l1ll_l1_ (u"้ࠩࠣํอโฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์ุฮศ่ษࠣๆิ๊ࠦไ๊้ࠤ฾ีๅ๊ࠡฯ์ิࠦล็ฬิ๊๏ะࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࡀࠧ䌎")+l11lll1l111_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䌏"),l1l1ll_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ䌐"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䌑"),l1l1ll_l1_ (u"࠭ࠧ䌒"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䌓"),l1l1ll_l1_ (u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧ䌔"))
	return
def l11lll1111l_l1_(folder,options):
	if l1l1ll_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䌕") not in options:
		results = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䌖"),l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䌗"),l1l1ll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭䌘")+folder)
		if results: menuItemsLIST[:] = results ; return
	message = l1l1ll_l1_ (u"࠭ไๅลึๅ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥํะศࠢส่๊๎โฺࠢ࠱ࠤํืำศๆฬࠤฬ๊ฮุลࠣ็ฬ์ࠠโ์๊หࠥะแศืํ่ࠥอไๆึๆ่ฮࠦ࠮ࠡลำหࠥอไๆึๆ่ฮࠦไ๋ีอࠤาาศࠡใฯีอࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ䌙")
	import IPTV
	if l1l1ll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䌚") in options and l1l1ll_l1_ (u"ࠨࡡࡏࡍ࡛ࡋ࡟ࠨ䌛") not in options:
		try: IPTV.GROUPS(folder,l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䌜"),l1l1ll_l1_ (u"ࠪࠫ䌝"),l1l1ll_l1_ (u"ࠫࠬ䌞"),options+l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌟"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䌠"),l1l1ll_l1_ (u"ࠧࠨ䌡"),l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䌢"),message)
		try: IPTV.GROUPS(folder,l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䌣"),l1l1ll_l1_ (u"ࠪࠫ䌤"),l1l1ll_l1_ (u"ࠫࠬ䌥"),options+l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌦"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䌧"),l1l1ll_l1_ (u"ࠧࠨ䌨"),l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䌩"),message)
		try: IPTV.GROUPS(folder,l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ䌪"),l1l1ll_l1_ (u"ࠪࠫ䌫"),l1l1ll_l1_ (u"ࠫࠬ䌬"),options+l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌭"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䌮"),l1l1ll_l1_ (u"ࠧࠨ䌯"),l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ䌰"),message)
	if l1l1ll_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䌱") in options and l1l1ll_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ䌲") not in options:
		try: IPTV.GROUPS(folder,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ䌳"),l1l1ll_l1_ (u"ࠬ࠭䌴"),l1l1ll_l1_ (u"࠭ࠧ䌵"),options+l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䌶"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䌷"),l1l1ll_l1_ (u"ࠩࠪ䌸"),l1l1ll_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ䌹"),message)
		try: IPTV.GROUPS(folder,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䌺"),l1l1ll_l1_ (u"ࠬ࠭䌻"),l1l1ll_l1_ (u"࠭ࠧ䌼"),options+l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䌽"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䌾"),l1l1ll_l1_ (u"ࠩࠪ䌿"),l1l1ll_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ䍀"),message)
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䍁"),l1l1ll_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭䍂")+folder,menuItemsLIST,PERMANENT_CACHE)
	return
def l11lll1llll_l1_(folder,options):
	if l1l1ll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䍃") not in options:
		results = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䍄"),l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䍅"),l1l1ll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ䍆")+folder)
		if results: menuItemsLIST[:] = results ; return
	message = l1l1ll_l1_ (u"่้ࠪษำโࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦ࠮๊ࠡิืฬ๊ษࠡษ็า฼ษࠠไษ้ࠤๆ๐็ศࠢอๅฬ฻๊ๅࠢสฺ่๊ใๅหࠣ࠲ࠥษะศࠢสฺ่๊ใๅห่ࠣ๏ูสࠡฯฯฬࠥ็ฬาสࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨ䍇")
	import l1l1l11l1l1_l1_
	if l1l1ll_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䍈") in options and l1l1ll_l1_ (u"ࠬࡥࡌࡊࡘࡈࡣࠬ䍉") not in options:
		try: l1l1l11l1l1_l1_.GROUPS(folder,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ䍊"),l1l1ll_l1_ (u"ࠧࠨ䍋"),l1l1ll_l1_ (u"ࠨࠩ䍌"),options+l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍍"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䍎"),l1l1ll_l1_ (u"ࠫࠬ䍏"),l1l1ll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䍐"),message)
		try: l1l1l11l1l1_l1_.GROUPS(folder,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䍑"),l1l1ll_l1_ (u"ࠧࠨ䍒"),l1l1ll_l1_ (u"ࠨࠩ䍓"),options+l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍔"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䍕"),l1l1ll_l1_ (u"ࠫࠬ䍖"),l1l1ll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䍗"),message)
		try: l1l1l11l1l1_l1_.GROUPS(folder,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ䍘"),l1l1ll_l1_ (u"ࠧࠨ䍙"),l1l1ll_l1_ (u"ࠨࠩ䍚"),options+l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍛"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䍜"),l1l1ll_l1_ (u"ࠫࠬ䍝"),l1l1ll_l1_ (u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬ䍞"),message)
	if l1l1ll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䍟") in options and l1l1ll_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䍠") not in options:
		try: l1l1l11l1l1_l1_.GROUPS(folder,l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ䍡"),l1l1ll_l1_ (u"ࠩࠪ䍢"),l1l1ll_l1_ (u"ࠪࠫ䍣"),options+l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䍤"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䍥"),l1l1ll_l1_ (u"࠭ࠧ䍦"),l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ䍧"),message)
		try: l1l1l11l1l1_l1_.GROUPS(folder,l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ䍨"),l1l1ll_l1_ (u"ࠩࠪ䍩"),l1l1ll_l1_ (u"ࠪࠫ䍪"),options+l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䍫"),False)
		except: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䍬"),l1l1ll_l1_ (u"࠭ࠧ䍭"),l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ䍮"),message)
	WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䍯"),l1l1ll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ䍰")+folder,menuItemsLIST,PERMANENT_CACHE)
	return
def l11llllll11_l1_(folder,options,l11ll1ll1l1_l1_):
	if l1l1ll_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ䍱") in options:
		if l1l1ll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䍲") in options and l11ll1ll1l1_l1_==l1l1ll_l1_ (u"ࠬ࠭䍳"): l11ll11llll_l1_(True)
		elif l11ll1ll1l1_l1_: l11ll11llll_l1_(False)
		#if contentsDICT=={}: return
	l11llll11ll_l1_ = options.replace(l1l1ll_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䍴"),l1l1ll_l1_ (u"ࠧࠨ䍵")).replace(l1l1ll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䍶"),l1l1ll_l1_ (u"ࠩࠪ䍷")).replace(l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍸"),l1l1ll_l1_ (u"ࠫࠬ䍹"))
	if not l11ll1ll1l1_l1_:
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䍺"),l1l1ll_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ䍻"),l1l1ll_l1_ (u"ࠧࠨ䍼"),165,l1l1ll_l1_ (u"ࠨࠩ䍽"),l1l1ll_l1_ (u"ࠩࠪ䍾"),l1l1ll_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䍿")+l11llll11ll_l1_,l1l1ll_l1_ (u"ࠫࠬ䎀"),{l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䎁"):folder})
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䎂"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䎃"),l1l1ll_l1_ (u"ࠨࠩ䎄"),9999)
	if l1l1ll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䎅") in options:
		l1ll1lllll_l1_ = [l1l1ll_l1_ (u"ࠪวๆ๊วๆࠩ䎆"),l1l1ll_l1_ (u"ู๊ࠫไิๆสฮࠬ䎇"),l1l1ll_l1_ (u"๋ࠬำาฯํหฯ࠭䎈"),l1l1ll_l1_ (u"࠭ศาษ่ะࠬ䎉"),l1l1ll_l1_ (u"ࠧฤูไห้่ࠦไำอ์๋࠭䎊"),l1l1ll_l1_ (u"ࠨำฺ่ฬ์ࠧ䎋"),l1l1ll_l1_ (u"ࠩฦัิั࠭ฤะิࠫ䎌"),l1l1ll_l1_ (u"ࠪื้อำๅࠩ䎍"),l1l1ll_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ䎎"),l1l1ll_l1_ (u"ࠬษิ่ำ࠰ว่ััࠨ䎏"),l1l1ll_l1_ (u"࠭วๅฤ้ࠫ䎐"),l1l1ll_l1_ (u"ࠧืฯๆࠫ䎑"),l1l1ll_l1_ (u"ࠨำํห฻ฯࠧ䎒"),l1l1ll_l1_ (u"้ࠩ๎ฯ็ไไีࠪ䎓"),l1l1ll_l1_ (u"้๊ࠪัไ๋่ࠪ䎔"),l1l1ll_l1_ (u"ࠫอัࠠฮ์ࠪ䎕"),l1l1ll_l1_ (u"ࠬี๊็์ฬࠫ䎖"),l1l1ll_l1_ (u"࠭ำ็๊สฮࠬ䎗"),l1l1ll_l1_ (u"ࠧฤะิํࠬ䎘")]
		l11ll1l11ll_l1_ = [l1l1ll_l1_ (u"ࠨษไ่ฬ๋ࠧ䎙"),l1l1ll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ䎚"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨ䎛"),l1l1ll_l1_ (u"ࠫๆ๊ๅࠨ䎜")]
		l11lllllll1_l1_ = [l1l1ll_l1_ (u"๋ࠬำๅี็ࠫ䎝"),l1l1ll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭䎞")]
		l1l1111l1ll_l1_ = [l1l1ll_l1_ (u"ࠧๆีสีา࠭䎟"),l1l1ll_l1_ (u"ࠨ็ึีา๐วหࠩ䎠")]
		l11ll1ll1ll_l1_ = [l1l1ll_l1_ (u"ࠩหีฬ๋ฬࠨ䎡"),l1l1ll_l1_ (u"ࠪࡷ࡭ࡵࡷࠨ䎢"),l1l1ll_l1_ (u"ࠫฯ๊แำ์๋๊ࠬ䎣"),l1l1ll_l1_ (u"ࠬะไ๋ใี๎ํ์ࠧ䎤")]
		l11lllll11l_l1_ = [l1l1ll_l1_ (u"࠭ว็็ํࠫ䎥"),l1l1ll_l1_ (u"ࠧไำอ์๋࠭䎦"),l1l1ll_l1_ (u"ࠨๅสีฯ๎ๆࠨ䎧"),l1l1ll_l1_ (u"ࠩ࡮࡭ࡩࡹࠧ䎨"),l1l1ll_l1_ (u"ࠪ฻ๆ๊ࠧ䎩"),l1l1ll_l1_ (u"ࠫฬ฽แศๆࠪ䎪")]
		l11l111l_l1_ = [l1l1ll_l1_ (u"ࠬืๅืษ้ࠫ䎫")]
		l1111ll1_l1_ = [l1l1ll_l1_ (u"࠭วฮัฮࠫ䎬"),l1l1ll_l1_ (u"ࠧศะิࠫ䎭"),l1l1ll_l1_ (u"ࠨ็๋าึ࠭䎮"),l1l1ll_l1_ (u"ࠩฯำ๏ีࠧ䎯"),l1l1ll_l1_ (u"้ࠪ฻อแࠨ䎰"),l1l1ll_l1_ (u"ࠫาี๊ฬࠩ䎱")]
		l11lll111l1_l1_ = [l1l1ll_l1_ (u"ูࠬไศี็ࠫ䎲"),l1l1ll_l1_ (u"࠭ำๅี็๋ࠬ䎳")]
		l11ll11l1ll_l1_ = [l1l1ll_l1_ (u"ࠧศ฼ส๊๏࠭䎴"),l1l1ll_l1_ (u"ࠨ็๋ื๏่้ࠨ䎵"),l1l1ll_l1_ (u"ࠩๆ่๏ฮࠧ䎶"),l1l1ll_l1_ (u"ࠪัๆ๊ࠧ䎷"),l1l1ll_l1_ (u"ࠫࡲࡻࡳࡪࡥࠪ䎸")]
		l111l111l_l1_ = [l1l1ll_l1_ (u"ࠬอใฬำࠪ䎹"),l1l1ll_l1_ (u"࠭วี้ิࠫ䎺"),l1l1ll_l1_ (u"ࠧๆ็ํึ์࠭䎻"),l1l1ll_l1_ (u"ࠨษ฼่๎࠭䎼"),l1l1ll_l1_ (u"่ࠩาฯอั่ࠩ䎽"),l1l1ll_l1_ (u"้ࠪำะวาษอࠫ䎾"),l1l1ll_l1_ (u"ࠫฬ่่๊ࠩ䎿")]
		l11ll1l1111_l1_ = [l1l1ll_l1_ (u"ࠬอไศ่ࠪ䏀"),l1l1ll_l1_ (u"࠭อศๆํࠫ䏁"),l1l1ll_l1_ (u"ࠧๆอหฮࠬ䏂"),l1l1ll_l1_ (u"ࠨำสสั࠭䏃")]
		l11ll11lll1_l1_ = [l1l1ll_l1_ (u"ูࠩั่࠭䏄"),l1l1ll_l1_ (u"ࠪ็ํ๋๊ะ์ࠪ䏅")]
		l11ll1l1l11_l1_ = [l1l1ll_l1_ (u"ࠫึ๐วื้ࠪ䏆"),l1l1ll_l1_ (u"้่ࠬา้ࠪ䏇"),l1l1ll_l1_ (u"࠭ๅึษิ฽์࠭䏈"),l1l1ll_l1_ (u"ࠧี๊อࠫ䏉"),l1l1ll_l1_ (u"ࠨำํห฻ฯࠧ䏊")]
		l11llll1l1l_l1_ = [l1l1ll_l1_ (u"้ࠩ๎ฯ็ไไีࠪ䏋"),l1l1ll_l1_ (u"ࠪࡲࡪࡺࡦ࡭࡫ࡻࠫ䏌"),l1l1ll_l1_ (u"๋ࠫ๐สโๆํ็ุ࠭䏍")]
		l11ll1lll11_l1_ = [l1l1ll_l1_ (u"๋ࠬๅฬๆํ๊ࠬ䏎"),l1l1ll_l1_ (u"࠭วีะสูࠬ䏏"),l1l1ll_l1_ (u"ࠧ็ฮ๋้ࠬ䏐")]
		l1ll1l11l_l1_ = [l1l1ll_l1_ (u"ࠨสฮࠤา๐ࠧ䏑"),l1l1ll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䏒"),l1l1ll_l1_ (u"ࠪๆ๋อ็ࠨ䏓"),l1l1ll_l1_ (u"ࠫ็์่ศฬࠪ䏔")]
		l11llll1111_l1_ = [l1l1ll_l1_ (u"ࠬี๊็ࠩ䏕"),l1l1ll_l1_ (u"࠭วะ฻ํ๋ࠬ䏖"),l1l1ll_l1_ (u"ࠧำ์สีฬะࠧ䏗"),l1l1ll_l1_ (u"ࠨๆฺ้๏อสࠨ䏘"),l1l1ll_l1_ (u"ࠩา฽ฬวࠧ䏙"),l1l1ll_l1_ (u"ࠪๆึอๆࠨ䏚"),l1l1ll_l1_ (u"ࠫ็฻ววัࠪ䏛"),l1l1ll_l1_ (u"ࠬืหศรࠪ䏜"),l1l1ll_l1_ (u"࠭ๅาฮ฼๎์࠭䏝"),l1l1ll_l1_ (u"ࠧศาส๊ࠬ䏞"),l1l1ll_l1_ (u"ࠨษึ่ฬ๋ࠧ䏟"),l1l1ll_l1_ (u"ࠩอ์ฬฺ๊ฮࠩ䏠"),l1l1ll_l1_ (u"ࠪา฼ฮࠧ䏡"),l1l1ll_l1_ (u"ࠫา๎า้์ࠪ䏢"),l1l1ll_l1_ (u"ࠬ฿สษษอࠫ䏣"),l1l1ll_l1_ (u"࠭ๅ้ษ็๎ิ࠭䏤"),l1l1ll_l1_ (u"ࠧ็๊ส฽๏࠭䏥"),l1l1ll_l1_ (u"ࠨ฻ๅหหีࠧ䏦"),l1l1ll_l1_ (u"ࠩส๊ฬฺ๊ะࠩ䏧")]
		l11llllll1l_l1_ = [l1l1ll_l1_ (u"ࠪ࠵࠾࠭䏨"),l1l1ll_l1_ (u"ࠫ࠷࠶ࠧ䏩"),l1l1ll_l1_ (u"ࠬ࠸࠱ࠨ䏪"),l1l1ll_l1_ (u"࠭࠲࠳ࠩ䏫"),l1l1ll_l1_ (u"ࠧ࠳࠵ࠪ䏬"),l1l1ll_l1_ (u"ࠨ࠴࠷ࠫ䏭"),l1l1ll_l1_ (u"ࠩ࠵࠹ࠬ䏮"),l1l1ll_l1_ (u"ࠪ࠶࠻࠭䏯")]
		if not l11ll1ll1l1_l1_:
			l11ll1ll1l1_l1_ = 0
			for l11lll1l1ll_l1_ in l1ll1lllll_l1_:
				l11ll1ll1l1_l1_ += 1
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䏰"),menu_name+l11lll1l1ll_l1_,l1l1ll_l1_ (u"ࠬ࠭䏱"),165,l1l1ll_l1_ (u"࠭ࠧ䏲"),str(l11ll1ll1l1_l1_),l11llll11ll_l1_,l1l1ll_l1_ (u"ࠧࠨ䏳"),{l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䏴"):folder})
		else:
			for name in sorted(list(contentsDICT.keys())):
				name2 = name.lower()
				category = []
				if any(value in name2 for value in l11ll1l11ll_l1_): category.append(1)
				if any(value in name2 for value in l11lllllll1_l1_): category.append(2)
				if any(value in name2 for value in l1l1111l1ll_l1_): category.append(3)
				if any(value in name2 for value in l11ll1ll1ll_l1_): category.append(4)
				if any(value in name2 for value in l11lllll11l_l1_): category.append(5)
				if any(value in name2 for value in l11l111l_l1_): category.append(6)
				if any(value in name2 for value in l1111ll1_l1_) and name2 not in [l1l1ll_l1_ (u"ࠩสาึ๏ࠧ䏵")]: category.append(7)
				if any(value in name2 for value in l11lll111l1_l1_): category.append(8)
				if any(value in name2 for value in l11ll11l1ll_l1_): category.append(9)
				if any(value in name2 for value in l111l111l_l1_): category.append(10)
				if any(value in name2 for value in l11ll1l1111_l1_): category.append(11)
				if any(value in name2 for value in l11ll11lll1_l1_): category.append(12)
				if any(value in name2 for value in l11ll1l1l11_l1_): category.append(13)
				if any(value in name2 for value in l11llll1l1l_l1_): category.append(14)
				if any(value in name2 for value in l11ll1lll11_l1_): category.append(15)
				if any(value in name2 for value in l1ll1l11l_l1_): category.append(16)
				if any(value in name2 for value in l11llll1111_l1_): category.append(17)
				if any(value in name2 for value in l11llllll1l_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l11ll1ll1l1_l1_:
						addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䏶"),menu_name+name,name,166,l1l1ll_l1_ (u"ࠫࠬ䏷"),l1l1ll_l1_ (u"ࠬ࠭䏸"),l11llll11ll_l1_+l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䏹"))
	elif l1l1ll_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䏺") in options:
		import IPTV
		#if l1l1ll_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䏻") in options:
		l11ll11ll1l_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if folder:
			if not IPTV.CHECK_TABLES_EXIST(folder,True): return
			l11lll1111l_l1_(folder,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"ࠩࠪ䏼"),True): return
			for folder in range(FOLDERS_COUNT):
				l11lll1111l_l1_(str(folder),options)
			#else: l11ll11ll1l_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11ll11ll1l_l1_+menuItemsLIST[:]
	elif l1l1ll_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䏽") in options:
		import l1l1l11l1l1_l1_
		#if l1l1ll_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䏾") in options:
		l11ll11ll1l_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if folder:
			if not l1l1l11l1l1_l1_.CHECK_TABLES_EXIST(folder,True): return
			l11lll1llll_l1_(folder,options)
		else:
			if not l1l1l11l1l1_l1_.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"ࠬ࠭䏿"),True): return
			for folder in range(FOLDERS_COUNT):
				l11lll1llll_l1_(str(folder),options)
			#else: l11ll11ll1l_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l11ll11ll1l_l1_+menuItemsLIST[:]
	return
def l1l111111ll_l1_(nameonly,options):
	nameonly = nameonly.replace(l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䐀"),l1l1ll_l1_ (u"ࠧࠨ䐁"))
	options = options.replace(l1l1ll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䐂"),l1l1ll_l1_ (u"ࠩࠪ䐃")).replace(l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䐄"),l1l1ll_l1_ (u"ࠫࠬ䐅"))
	l11ll11llll_l1_(False)
	if contentsDICT=={}: return
	if l1l1ll_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ䐆") in options:
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐇"),l1l1ll_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䐈")+nameonly+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ䐉"),nameonly,166,l1l1ll_l1_ (u"ࠩࠪ䐊"),l1l1ll_l1_ (u"ࠪࠫ䐋"),l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䐌")+options)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐍"),l1l1ll_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䐎"),nameonly,166,l1l1ll_l1_ (u"ࠧࠨ䐏"),l1l1ll_l1_ (u"ࠨࠩ䐐"),l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䐑")+options)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䐒"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐓"),l1l1ll_l1_ (u"ࠬ࠭䐔"),9999)
	for website in sorted(list(contentsDICT[nameonly].keys())):
		type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		if l1l1ll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䐕") in options or len(contentsDICT[nameonly])==1:
			l11lll111ll_l1_(type,l1l1ll_l1_ (u"ࠧࠨ䐖"),url,l11lllll111_l1_,l1l1ll_l1_ (u"ࠨࠩ䐗"),page,text,l1l1ll_l1_ (u"ࠩࠪ䐘"),l1l1ll_l1_ (u"ࠪࠫ䐙"))
			menuItemsLIST[:] = l11lll11lll_l1_(menuItemsLIST)
			l11ll11ll1l_l1_,newLIST = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(newLIST)
			if l1l1ll_l1_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭䐚") in options: menuItemsLIST[:] = l11ll11ll1l_l1_+newLIST[:l11llllllll_l1_]
			else: menuItemsLIST[:] = l11ll11ll1l_l1_+newLIST
		elif l1l1ll_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䐛") in options: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐜"),website,url,l11lllll111_l1_,image,page,text,favorite,infodict)
	return
def l11lll11l11_l1_(options,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䐝"),l1l1ll_l1_ (u"ࠨࠩ䐞"),str(mode),options)
	options = options.replace(l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䐟"),l1l1ll_l1_ (u"ࠪࠫ䐠")).replace(l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䐡"),l1l1ll_l1_ (u"ࠬ࠭䐢"))
	name,l11lll11111_l1_ = l1l1ll_l1_ (u"࠭ࠧ䐣"),[]
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐤"),l1l1ll_l1_ (u"ࠨ࡝ࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭䐥")+name+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤฬ๊โิ็ࠣ࠾ࠥࡡࠠࠨ䐦"),l1l1ll_l1_ (u"ࠪࠫ䐧"),mode,l1l1ll_l1_ (u"ࠫࠬ䐨"),l1l1ll_l1_ (u"ࠬ࠭䐩"),l1l1ll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䐪")+options)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐫"),l1l1ll_l1_ (u"ࠨว฼หิฯุࠠๆหࠤ็ูๅࠡ฻ื์ฬฬ๊ࠨ䐬"),l1l1ll_l1_ (u"ࠩࠪ䐭"),mode,l1l1ll_l1_ (u"ࠪࠫ䐮"),l1l1ll_l1_ (u"ࠫࠬ䐯"),l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䐰")+options)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䐱"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䐲"),l1l1ll_l1_ (u"ࠨࠩ䐳"),9999)
	l11ll11ll1l_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l1l1ll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䐴") in options:
		l11ll11llll_l1_(False)
		if contentsDICT=={}: return
		l11lll11ll1_l1_ = list(contentsDICT.keys())
		nameonly = random.sample(l11lll11ll1_l1_,1)[0]
		l11lllll1ll_l1_ = list(contentsDICT[nameonly].keys())
		website = random.sample(l11lllll1ll_l1_,1)[0]
		type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict = contentsDICT[nameonly][website]
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䐵"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠿ࠦࠧ䐶")+website+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡰࡤࡱࡪࡀࠠࠨ䐷")+name+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䐸")+url+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䐹")+str(l11lllll111_l1_))
	elif l1l1ll_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䐺") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"ࠩࠪ䐻"),True): return
		for folder in range(FOLDERS_COUNT):
			l11lll1111l_l1_(str(folder),options)
		if not menuItemsLIST: return
		type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䐼"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ䐽")+name+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ䐾")+url+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ䐿")+str(l11lllll111_l1_))
	elif l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䑀") in options:
		import l1l1l11l1l1_l1_
		if not l1l1l11l1l1_l1_.CHECK_TABLES_EXIST(l1l1ll_l1_ (u"ࠨࠩ䑁"),True): return
		for folder in range(FOLDERS_COUNT):
			l11lll1llll_l1_(str(folder),options)
		if not menuItemsLIST: return
		type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䑂"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡃࡢࡶࡨ࡫ࡴࡸࡹࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䑃")+name+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭䑄")+url+l1l1ll_l1_ (u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨ䑅")+str(l11lllll111_l1_))
	l11ll1lll1l_l1_ = name
	l11lll1l11l_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䑆"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ䑇")+name+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䑈")+url+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䑉")+str(l11lllll111_l1_))
		menuItemsLIST[:] = []
		if l11lllll111_l1_==234 and l1l1ll_l1_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䑊") in text: l11lllll111_l1_ = 233
		if l11lllll111_l1_==714 and l1l1ll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䑋") in text: l11lllll111_l1_ = 713
		if l11lllll111_l1_==144: l11lllll111_l1_ = 291
		html = l11lll111ll_l1_(type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict)
		#if l1l1ll_l1_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ䑌") in html: l11lll11l11_l1_(options,mode)
		if l1l1ll_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䑍") in options and l11lllll111_l1_==167: del menuItemsLIST[:3]
		if l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䑎") in options and l11lllll111_l1_==168: del menuItemsLIST[:3]
		l11lll11111_l1_[:] = l11lll11lll_l1_(menuItemsLIST)
		if l11lll1l11l_l1_ and l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡶࠩะ่็ฯࠧ䑏")) in str(l11lll11111_l1_) or l11ll1ll11l_l1_(l1l1ll_l1_ (u"ࡷࠪั้่็ࠨ䑐")) in str(l11lll11111_l1_):
			name = l11ll1lll1l_l1_
			l11lll11111_l1_[:] = l11lll1l11l_l1_
			break
		l11ll1lll1l_l1_ = name
		l11lll1l11l_l1_ = l11lll11111_l1_[:]
		if str(l11lll11111_l1_).count(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䑑"))>0: break
		if str(l11lll11111_l1_).count(l1l1ll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䑒"))>0: break
		if l11lllll111_l1_==233: break	# l1111lllll_l1_ l11l1l1l_l1_ names l11lll1lll1_l1_ of l1ll1_l1_ name
		if l11lllll111_l1_==713: break	# l11ll1l1lll_l1_ l11l1l1l_l1_ names l11lll1lll1_l1_ of l1ll1_l1_ name
		if l11lllll111_l1_==291: break	# l1llll11l_l1_ l1l11111l11_l1_ names l11lll1lll1_l1_ of l1llll11l_l1_ l1l11111l11_l1_ contents
		if l11lll11111_l1_: type,name,url,l11lllll111_l1_,image,page,text,favorite,infodict = random.sample(l11lll11111_l1_,1)[0]
	if not name: name = l1l1ll_l1_ (u"ࠬ࠴࠮࠯࠰ࠪ䑓")
	elif name.count(l1l1ll_l1_ (u"࠭࡟ࠨ䑔"))>1: name = name.split(l1l1ll_l1_ (u"ࠧࡠࠩ䑕"),2)[2]
	name = name.replace(l1l1ll_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫ䑖"),l1l1ll_l1_ (u"ࠩࠪ䑗"))#.replace(l1l1ll_l1_ (u"ࠪ࠰ࡒࡕࡖࡊࡇࡖ࠾ࠥ࠭䑘"),l1l1ll_l1_ (u"ࠫࠬ䑙")).replace(l1l1ll_l1_ (u"ࠬ࠲ࡓࡆࡔࡌࡉࡘࡀࠠࠨ䑚"),l1l1ll_l1_ (u"࠭ࠧ䑛")).replace(l1l1ll_l1_ (u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨ䑜"),l1l1ll_l1_ (u"ࠨࠩ䑝"))
	name = name.replace(l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䑞"),l1l1ll_l1_ (u"ࠪࠫ䑟"))
	l11ll11ll1l_l1_[0][1] = l1l1ll_l1_ (u"ࠫࡠ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ䑠")+name+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠศๆๅื๊ࠦ࠺ࠡ࡝ࠣࠫ䑡")
	for i in range(9): random.shuffle(l11lll11111_l1_)
	if l1l1ll_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䑢") in options: menuItemsLIST[:] = l11ll11ll1l_l1_+l11lll11111_l1_[:l11llllllll_l1_]
	else: menuItemsLIST[:] = l11ll11ll1l_l1_+l11lll11111_l1_
	return
def l11ll1ll111_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䑣"),l1l1ll_l1_ (u"ࠨࠩ䑤")).replace(l1l1ll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䑥"),l1l1ll_l1_ (u"ࠪࠫ䑦"))
	l11lll11l1l_l1_ = GROUP
	if l1l1ll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䑧") in GROUP:
		l11lll11l1l_l1_ = GROUP.split(l1l1ll_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䑨"))[0]
		type = l1l1ll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ䑩")
	elif l1l1ll_l1_ (u"ࠧࡗࡑࡇࠫ䑪") in TYPE: type = l1l1ll_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ䑫")
	elif l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䑬") in TYPE: type = l1l1ll_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ䑭")
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑮"),l1l1ll_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䑯")+type+l11lll11l1l_l1_+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ䑰"),TYPE,167,l1l1ll_l1_ (u"ࠧࠨ䑱"),l1l1ll_l1_ (u"ࠨࠩ䑲"),l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䑳")+GROUP)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑴"),l1l1ll_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䑵"),TYPE,167,l1l1ll_l1_ (u"ࠬ࠭䑶"),l1l1ll_l1_ (u"࠭ࠧ䑷"),l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䑸")+GROUP)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䑹"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䑺"),l1l1ll_l1_ (u"ࠪࠫ䑻"),9999)
	import IPTV
	for folder in range(FOLDERS_COUNT):
		if l1l1ll_l1_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡪࡸࡩࡦࡵࡢࡣࠬ䑼") in GROUP: IPTV.GROUPS(str(folder),TYPE,GROUP,l1l1ll_l1_ (u"ࠬ࠭䑽"),False)
		else: IPTV.ITEMS(str(folder),TYPE,GROUP,l1l1ll_l1_ (u"࠭ࠧ䑾"),False)
	menuItemsLIST[:] = l11lll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11llllllll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11llllllll_l1_)
	return
def l11ll11ll11_l1_(TYPE,GROUP):
	GROUP = GROUP.replace(l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䑿"),l1l1ll_l1_ (u"ࠨࠩ䒀")).replace(l1l1ll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䒁"),l1l1ll_l1_ (u"ࠪࠫ䒂"))
	l11lll11l1l_l1_ = GROUP
	if l1l1ll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䒃") in GROUP:
		l11lll11l1l_l1_ = GROUP.split(l1l1ll_l1_ (u"ࠬࡥ࡟ࡎ࠵ࡘࡗࡪࡸࡩࡦࡵࡢࡣࠬ䒄"))[0]
		type = l1l1ll_l1_ (u"࠭ࠬࡔࡇࡕࡍࡊ࡙࠺ࠡࠩ䒅")
	elif l1l1ll_l1_ (u"ࠧࡗࡑࡇࠫ䒆") in TYPE: type = l1l1ll_l1_ (u"ࠨ࠮࡙ࡍࡉࡋࡏࡔ࠼ࠣࠫ䒇")
	elif l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ䒈") in TYPE: type = l1l1ll_l1_ (u"ࠪ࠰ࡑࡏࡖࡆ࠼ࠣࠫ䒉")
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䒊"),l1l1ll_l1_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䒋")+type+l11lll11l1l_l1_+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ䒌"),TYPE,168,l1l1ll_l1_ (u"ࠧࠨ䒍"),l1l1ll_l1_ (u"ࠨࠩ䒎"),l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䒏")+GROUP)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䒐"),l1l1ll_l1_ (u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪ䒑"),TYPE,168,l1l1ll_l1_ (u"ࠬ࠭䒒"),l1l1ll_l1_ (u"࠭ࠧ䒓"),l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䒔")+GROUP)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䒕"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䒖"),l1l1ll_l1_ (u"ࠪࠫ䒗"),9999)
	import l1l1l11l1l1_l1_
	for folder in range(FOLDERS_COUNT):
		if l1l1ll_l1_ (u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫ䒘") in GROUP: l1l1l11l1l1_l1_.GROUPS(str(folder),TYPE,GROUP,l1l1ll_l1_ (u"ࠬ࠭䒙"),False)
		else: l1l1l11l1l1_l1_.ITEMS(str(folder),TYPE,GROUP,l1l1ll_l1_ (u"࠭ࠧ䒚"),False)
	menuItemsLIST[:] = l11lll11lll_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l11llllllll_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l11llllllll_l1_)
	return
def l11lll11lll_l1_(menuItemsLIST):
	l11lll11111_l1_ = []
	for type,name,url,mode,image,page,text,favorite,infodict in menuItemsLIST:
		if l1l1ll_l1_ (u"ࠧึใะอࠬ䒛") in name or l1l1ll_l1_ (u"ࠨืไั์࠭䒜") in name or l1l1ll_l1_ (u"ࠩࡳࡥ࡬࡫ࠧ䒝") in name.lower(): continue
		l11lll11111_l1_.append([type,name,url,mode,image,page,text,favorite,infodict])
	return l11lll11111_l1_
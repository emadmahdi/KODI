# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪᾗ")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡉࡘ࠷ࡠࠩᾘ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭ᾙ"),l1l1ll_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭ᾚ"),l1l1ll_l1_ (u"࠭สิฮํ่ࠬᾛ")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l11l1l_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l11_l1_(url,text)
	elif mode==684: results = l1ll1l_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᾜ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩᾝ"),l1l1ll_l1_ (u"ࠩࠪᾞ"),l1l1ll_l1_ (u"ࠪࠫᾟ"),l1l1ll_l1_ (u"ࠫࠬᾠ"),l1l1ll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᾡ"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾢ"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᾣ"),l1l1ll_l1_ (u"ࠨࠩᾤ"),689,l1l1ll_l1_ (u"ࠩࠪᾥ"),l1l1ll_l1_ (u"ࠪࠫᾦ"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᾧ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᾨ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᾩ"),l1l1ll_l1_ (u"ࠧࠨᾪ"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᾫ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᾬ")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫᾭ"),l1l1l1_l1_,681,l1l1ll_l1_ (u"ࠫࠬᾮ"),l1l1ll_l1_ (u"ࠬ࠭ᾯ"),l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨᾰ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᾱ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᾲ")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨᾳ"),l1l1l1_l1_,681,l1l1ll_l1_ (u"ࠪࠫᾴ"),l1l1ll_l1_ (u"ࠫࠬ᾵"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩᾶ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᾷ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᾸ")+menu_name+l1l1ll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᾹ"),l1l1l1_l1_,681,l1l1ll_l1_ (u"ࠩࠪᾺ"),l1l1ll_l1_ (u"ࠪࠫΆ"),l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᾼ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᾽"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨι")+menu_name+l1l1ll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠫ᾿"),l1l1l1_l1_,681,l1l1ll_l1_ (u"ࠨࠩ῀"),l1l1ll_l1_ (u"ࠩࠪ῁"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬῂ"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῃ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῄ"),l1l1ll_l1_ (u"࠭ࠧ῅"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡻࡷࡧࡰࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬῆ"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩῇ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩῈ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬΈ")+menu_name+title,link,684)
	#addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῊ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬΉ"),l1l1ll_l1_ (u"࠭ࠧῌ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ῍"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨ῎"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠩࠪ῏"))
	items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨῐ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫῑ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧῒ")+menu_name+title,link,684)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪΐ"),url,l1l1ll_l1_ (u"ࠧࠨ῔"),l1l1ll_l1_ (u"ࠨࠩ῕"),l1l1ll_l1_ (u"ࠩࠪῖ"),l1l1ll_l1_ (u"ࠪࠫῗ"),l1l1ll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪῘ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩῙ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧῚ"),l1l1ll_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭Ί"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ῜"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠩࠪ῝"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ῞"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ῟"),l1l1ll_l1_ (u"ࠬ࠭ῠ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫῡ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠧ࠻ࠢࠪῢ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨΰ"),menu_name+title,link,681)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ῤ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬῥ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩῦ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῧ"),l1l1ll_l1_ (u"࠭ࠧῨ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧῩ"),menu_name+title,link,681)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠨࠩῪ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪΎ"),l1l1ll_l1_ (u"ࠪࠫῬ"),request,url)
	if request==l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ῭"):
		url,search = url.split(l1l1ll_l1_ (u"ࠬࡅࠧ΅"),1)
		data = l1l1ll_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ`")+search
		headers = {l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭῰"):l1l1ll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ῱")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧῲ"),url,data,headers,l1l1ll_l1_ (u"ࠪࠫῳ"),l1l1ll_l1_ (u"ࠫࠬῴ"),l1l1ll_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ῵"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪῶ"),url,l1l1ll_l1_ (u"ࠧࠨῷ"),l1l1ll_l1_ (u"ࠨࠩῸ"),l1l1ll_l1_ (u"ࠩࠪΌ"),l1l1ll_l1_ (u"ࠪࠫῺ"),l1l1ll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩΏ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠬ࠭ῼ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ´"))
	if request==l1l1ll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ῾"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ῿"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠩࠪ "),link,title))
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ "):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ "),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ "):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ "),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ "):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ "),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ "):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬ "),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ "),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠬ࠭ "),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ​"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ‌"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ࠨ็ืห์ีษࠨ‍"),l1l1ll_l1_ (u"ࠩไ๎้๋ࠧ‎"),l1l1ll_l1_ (u"ࠪห฿์๊สࠩ‏"),l1l1ll_l1_ (u"่๊๊ࠫษࠩ‐"),l1l1ll_l1_ (u"ࠬอูๅษ้ࠫ‑"),l1l1ll_l1_ (u"࠭็ะษไࠫ‒"),l1l1ll_l1_ (u"ࠧๆสสีฬฯࠧ–"),l1l1ll_l1_ (u"ࠨ฻ิฺࠬ—"),l1l1ll_l1_ (u"่๋ࠩึาว็ࠩ―"),l1l1ll_l1_ (u"ࠪห้ฮ่ๆࠩ‖"),l1l1ll_l1_ (u"ู๊ࠫัฮ์ฬࠫ‗")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ‘"))
		#if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ’") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ‚")+link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ‛"))
		#if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ“") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ”")+img.strip(l1l1ll_l1_ (u"ࠫ࠴࠭„"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ‟"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ†"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭‡"),menu_name+title,link,682,img)
		elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ•"):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ‣"),menu_name+title,link,682,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ․") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ‥"),menu_name+title,link,683,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ…") in link:
		#	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭‧"),menu_name+title,link,681,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ "),menu_name+title,link,683,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ "),l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ‪")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ‫"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ‬"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠬࠩࠧ‭"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨ‮")+link.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ "))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ‰"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ‱")+title,link,681)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ′"),l1l1ll_l1_ (u"ࠫࠬ″"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ‴"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ‵"),url,l1l1ll_l1_ (u"ࠧࠨ‶"),l1l1ll_l1_ (u"ࠨࠩ‷"),l1l1ll_l1_ (u"ࠩࠪ‸"),l1l1ll_l1_ (u"ࠪࠫ‹"),l1l1ll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ›"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ※"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ‼"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠧࠨ‽")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࠩࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ‾"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠩࠦࠫ‿"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⁀"),menu_name+title,url,683,img,l1l1ll_l1_ (u"ࠫࠬ⁁"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ⁂")+l1lll_l1_+l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⁃"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨ⁄"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⁅"),block,re.DOTALL)
		for link,title,img in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ⁆")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ⁇"))
			title = title.replace(l1l1ll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ⁈"),l1l1ll_l1_ (u"ࠬࠦࠧ⁉"))
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⁊"),menu_name+title,link,682,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ⁋"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⁌") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ⁍")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ⁎"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⁏"),menu_name+title,link,682,img)
	return
def PLAY(url):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ⁐"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ⁑"),url,l1l1ll_l1_ (u"ࠧࠨ⁒"),l1l1ll_l1_ (u"ࠨࠩ⁓"),l1l1ll_l1_ (u"ࠩࠪ⁔"),l1l1ll_l1_ (u"ࠪࠫ⁕"),l1l1ll_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ⁖"))
	html = response.content
	# l111l1_l1_ page
	link = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⁗"),html,re.DOTALL)
	link = link[0]
	l111ll_l1_ = link.split(l1l1ll_l1_ (u"࠭ࡰࡰࡵࡷࡁࠬ⁘"))[1]
	l111ll_l1_ = base64.b64decode(l111ll_l1_)
	if kodi_version>18.99: l111ll_l1_ = l111ll_l1_.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ⁙"))
	l111ll_l1_ = l111ll_l1_.replace(l1l1ll_l1_ (u"ࠨ࡞࠲ࠫ⁚"),l1l1ll_l1_ (u"ࠩ࠲ࠫ⁛"))
	l111ll_l1_ = EVAL(l1l1ll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ⁜"),l111ll_l1_)
	l1ll_l1_ = l111ll_l1_[l1l1ll_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡷࠬ⁝")]
	titles = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	zzz = zip(titles,l1ll_l1_)
	for title,link in zzz:
		link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⁞")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ ")
		l11l1_l1_.append(link)
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍࠨ࡯ࡦࠡ࡮࡬ࡲࡰࠦࡡ࡯ࡦࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢ࡯࡭ࡳࡱࠠ࠾ࠢࠪ࡬ࡹࡺࡰ࠻ࠩ࠮ࡰ࡮ࡴ࡫ࠋࠋ࡫ࡥࡸ࡮ࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡩࡣࡶ࡬ࡂ࠭ࠩ࡜࠳ࡠࠎࠎࡶࡡࡳࡶࡶࠤࡂࠦࡨࡢࡵ࡫࠲ࡸࡶ࡬ࡪࡶࠫࠫࡤࡥࠧࠪࠌࠌࡲࡪࡽ࡟ࡱࡣࡵࡸࡸࠦ࠽ࠡ࡝ࡠࠎࠎ࡬࡯ࡳࠢࡳࡥࡷࡺࠠࡪࡰࠣࡴࡦࡸࡴࡴ࠼ࠍࠍࠎࡺࡲࡺ࠼ࠍࠍࠎࠏࡰࡢࡴࡷࠤࡂࠦࡢࡢࡵࡨ࠺࠹࠴ࡢ࠷࠶ࡧࡩࡨࡵࡤࡦࠪࡳࡥࡷࡺࠫࠨ࠿ࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠼ࠣࡴࡦࡸࡴࠡ࠿ࠣࡴࡦࡸࡴ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠌࠌࠍࠎࡴࡥࡸࡡࡳࡥࡷࡺࡳ࠯ࡣࡳࡴࡪࡴࡤࠩࡲࡤࡶࡹ࠯ࠊࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠋࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࠫࡃ࠭࠮࡫ࡱ࡬ࡲ࠭ࡴࡥࡸࡡࡳࡥࡷࡺࡳࠪࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡱ࡯࡮࡬ࡵ࠱ࡷࡵࡲࡩࡵ࡮࡬ࡲࡪࡹࠨࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠷ࠦࡩ࡯ࠢࡽࡾࡿࡀࠊࠊࠋࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠸࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࠡ࠿ࡁࠤࠬ࠯ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠭ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫࠏࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ⁠")
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⁡"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⁢"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠪࠫ⁣"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠫࠬ⁤"): return
	search = search.replace(l1l1ll_l1_ (u"ࠬࠦࠧ⁥"),l1l1ll_l1_ (u"࠭ࠫࠨ⁦"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ⁧")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⁨"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄ࠭⁩")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ⁪"))
	return
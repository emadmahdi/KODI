# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᖽ")
headers = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᖾ"):l1l1ll_l1_ (u"ࠩࠪᖿ")}
menu_name = l1l1ll_l1_ (u"ࠪࡣࡈ࠺ࡕࡠࠩᗀ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨᗁ"),l1l1ll_l1_ (u"ࠬอฮา์ࠪᗂ"),l1l1ll_l1_ (u"࠭วฯำ์ࠫᗃ"),l1l1ll_l1_ (u"ࠧศๆิส๏ู๊สࠩᗄ"),l1l1ll_l1_ (u"ࠨสา์๋ࠦลฯฬํหึ࠭ᗅ"),l1l1ll_l1_ (u"ࠩสๅ้อๅࠨᗆ"),l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠫᗇ")]
def MAIN(mode,url,text):
	if   mode==420: results = MENU()
	elif mode==421: results = l11l1l_l1_(url,text)
	elif mode==422: results = l1lllll111_l1_(url)
	elif mode==423: results = l11ll1l_l1_(url)
	elif mode==424: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪᗈ")+text)
	elif mode==425: results = l111l11_l1_(url,l1l1ll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᗉ")+text)
	elif mode==426: results = PLAY(url)
	elif mode==427: results = l11111ll1_l1_(url)
	elif mode==429: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#html = l1llllll11_l1_(l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᗊ"),l1l1l1_l1_)
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨᗋ"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᗌ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪᗍ"),l1l1ll_l1_ (u"ࠪࠫᗎ"),l1l1ll_l1_ (u"ࠫࠬᗏ"),l1l1ll_l1_ (u"ࠬ࠭ᗐ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᗑ"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗒ"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠨ࠱ࠪᗓ"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭ᗔ"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗕ"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᗖ"),l1l1ll_l1_ (u"ࠬ࠭ᗗ"),429,l1l1ll_l1_ (u"࠭ࠧᗘ"),l1l1ll_l1_ (u"ࠧࠨᗙ"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᗚ"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗛ"),menu_name+l1l1ll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ᗜ"),l11ll1_l1_,425)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗝ"),menu_name+l1l1ll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨᗞ"),l11ll1_l1_,424)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᗟ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗠ"),l1l1ll_l1_ (u"ࠨࠩᗡ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗢ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗣ")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᗤ"),l11ll1_l1_,421)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗥ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗦ")+menu_name+l1l1ll_l1_ (u"ࠧฤใ็ห๊ࠦวๅ่ฯ์๊࠭ᗧ"),l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴ࠱ࠪᗨ"),421)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᗩ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᗪ")+menu_name+l1l1ll_l1_ (u"๋ࠫ๐สโๆๆืࠬᗫ"),l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵࡮ࡦࡶࡩࡰ࡮ࡾ࠯ࠨᗬ"),421)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᗭ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗮ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		if l1l1ll_l1_ (u"ࠨ࠱ࡤࡧࡹࡵࡲࡴࠩᗯ") in link: title = l1l1ll_l1_ (u"ࠩฦๅ้อๅࠡษ็๊ั๎ๅࠨᗰ")
		elif l1l1ll_l1_ (u"ࠪ࠳ࡳ࡫ࡴࡧ࡮࡬ࡼࠬᗱ") in link: title = l1l1ll_l1_ (u"ࠫศ็ไศ็ࠣ์ู๊ไิๆสฮࠥ์๊หใ็็ุ࠭ᗲ")
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗳ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗴ")+menu_name+title,link,421)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗵ"),menu_name+l1l1ll_l1_ (u"ࠨไสส๊ฯࠠหใุ๎้๐ษࠨᗶ"),l11ll1_l1_,427)
	return
def l11111ll1_l1_(website=l1l1ll_l1_ (u"ࠩࠪᗷ")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧᗸ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬᗹ"),l1l1ll_l1_ (u"ࠬ࠭ᗺ"),l1l1ll_l1_ (u"࠭ࠧᗻ"),l1l1ll_l1_ (u"ࠧࠨᗼ"),l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᗽ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫࡙࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡑࡣࡪࡩ࡙࡯ࡴ࡭ࡧࠪᗾ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠪࠩ࠰࠭ࡃ࠮ࠨࠪࠡࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥ࠮࠭࠴ࠪࡀࠫ࡞ࠦࡃࡣࠪ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗿ"),block,re.DOTALL)
	for category,id,link,title in items:
		if title in l1ll11_l1_: continue
		if l1l1ll_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᘀ") in link: title = l1l1ll_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬᘁ")
		elif l1l1ll_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠳࡮ࡦࡶࡩࡰ࡮ࡾࠧᘂ") in link: title = l1l1ll_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩᘃ")
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘄ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᘅ")+menu_name+title,link,421,l1l1ll_l1_ (u"ࠪࠫᘆ"),l1l1ll_l1_ (u"ࠫࠬᘇ"),category+l1l1ll_l1_ (u"ࠬࢂࠧᘈ")+id)
	return
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"࠭ࠧᘉ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨᘊ"),l1l1ll_l1_ (u"ࠨࠩᘋ"),l1111ll11_l1_,url)
	if l1l1ll_l1_ (u"ࠩ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᘌ") in url: url = url.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬᘍ"))+l1l1ll_l1_ (u"ࠫ࠴ࡳࡰࡢࡣ࠲ࡪࡦࡳࡩ࡭ࡻ࠲ࠫᘎ")
	items = []
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩᘏ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᘐ"),url,l1l1ll_l1_ (u"ࠧࠨᘑ"),headers,l1l1ll_l1_ (u"ࠨࠩᘒ"),l1l1ll_l1_ (u"ࠩࠪᘓ"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᘔ"))
	html = response.content
	if not l1111ll11_l1_ or l1l1ll_l1_ (u"ࠫࢁ࠭ᘕ") in l1111ll11_l1_:
		#if l1l1ll_l1_ (u"ࠬࡓࡵ࡭ࡶ࡬ࡊ࡮ࡲࡴࡦࡴࠪᘖ") in html:
		#	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᘗ"),menu_name+l1l1ll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪᘘ"),url,425)
		#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᘙ"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬᘚ"),url,424)
		#	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᘛ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᘜ"),l1l1ll_l1_ (u"ࠬ࠭ᘝ"),9999)
		if l1l1ll_l1_ (u"࠭ࡼࠨᘞ") not in l1111ll11_l1_: l11111l1l_l1_ = l1l1ll_l1_ (u"ࠧࠨᘟ")
		else: l11111l1l_l1_ = l1l1ll_l1_ (u"ࠨ࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠲ࠫᘠ")+l1111ll11_l1_
		l1lllll11l_l1_ = False
		if l1l1ll_l1_ (u"ࠩࡓ࡭ࡳ࡙࡬ࡪࡦࡨࡶࠬᘡ") in html:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᘢ"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬᘣ"),url,421,l1l1ll_l1_ (u"ࠬ࠭ᘤ"),l1l1ll_l1_ (u"࠭ࠧᘥ"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᘦ"))
			l1lllll11l_l1_ = True
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪࡉ࡯࡯ࡶࡨࡲࡹ࠭ᘧ"),html,re.DOTALL)
		if l1lll11_l1_:
			l11ll_l1_ = l1lll11_l1_[0]
			l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡥࡁࠧ࠰ࠨ࠯ࠬࡂ࠭ࠧ࠰࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘨ"),l11ll_l1_,re.DOTALL)
			for l111111ll_l1_,title2 in l1lll1l_l1_:
				l111111l1_l1_ = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡥࡨࡲࡹ࡫ࡲ࠰ࡣࡦࡸ࡮ࡵ࡮࠰ࡊࡲࡱࡪࡶࡡࡨࡧࡏࡳࡦࡪࡥࡳ࠱ࡷࡥࡧ࠵ࠧᘩ")+l111111ll_l1_+l11111l1l_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭ᘪ")
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᘫ"),menu_name+title2,l111111l1_l1_,421)
				l1lllll11l_l1_ = True
		if l1lllll11l_l1_: addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᘬ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᘭ"),l1l1ll_l1_ (u"ࠨࠩᘮ"),9999)
	if l1111ll11_l1_==l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫᘯ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡔ࡮ࡴࡓ࡭࡫ࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡲࡴࡪࡈ࡬ࡰࡹ࡫ࡲࠨᘰ"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡕ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡕࡧࡧࡦࡖ࡬ࡸࡱ࡫ࠧᘱ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		else: block = l1l1ll_l1_ (u"ࠬ࠭ᘲ")
	elif l1l1ll_l1_ (u"࠭࠯ࡉࡱࡰࡩࡵࡧࡧࡦࡎࡲࡥࡩ࡫ࡲ࠰ࠩᘳ") in url or l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡤࡧࡱࡸࡪࡸ࠯ࠨᘴ") in url:
		block = html
	elif l1l1ll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪᘵ") in url:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡓࡥ࡬࡫ࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࠯ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠭ࠫᘶ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	elif l1l1ll_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴࡶࠫᘷ") in url:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡕࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠪࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠯࠭ᘸ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠯࠮࠮ࠫࡁࠬ࡟ࠧࡄ࡝ࠬ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡆࡩࡴࡰࡴࡑࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᘹ"),block,re.DOTALL)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡃࡪ࡯ࡤ࠸ࡺࡈ࡬ࡰࡥ࡮ࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾࠽࠱ࡸࡰࡃ࠭ᘺ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		else: block = l1l1ll_l1_ (u"ࠧࠨᘻ")
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠬࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨࠪ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠭ࠬ࠳࠰࠿ࠪ࡝ࠥࡂࡢ࠱࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠯ࠬࡂࡆࡴࡾࡔࡪࡶ࡯ࡩࡎࡴࡦࡰ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩᘼ"),block,re.DOTALL)
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡳࡻ࡯ࡥࡃ࡮ࡲࡧࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᘽ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,img,title in items:
		if not title: continue
		if l1l1ll_l1_ (u"ࠪࡃࡳ࡫ࡷࡴ࠿ࠪᘾ") in link: continue
		title = title.replace(l1l1ll_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬᘿ"),l1l1ll_l1_ (u"ࠬ࠭ᙀ"))
		title = unescapeHTML(title)
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥำไใหࠣࡠࡩ࠱ࠧᙁ"),title,re.DOTALL)
		if l11111_l1_ and l1l1ll_l1_ (u"ࠧฮๆๅอࠬᙂ") in title:
			title = l1l1ll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᙃ") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙄ"),menu_name+title,link,422,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠪ࠳ࡦࡩࡴࡰࡴ࠲ࠫᙅ") in link: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᙆ"),menu_name+title,link,421,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙇ"),menu_name+title,link,422,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᙈ"),html,re.DOTALL)
	if l1lll11_l1_ and l1111ll11_l1_!=l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᙉ"):
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃ࡛࡝ࠩ࡟ࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭࡜ࠣ࡟ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙊ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"ࠩสฺ่็อสࠢࠪᙋ"),l1l1ll_l1_ (u"ࠪࠫᙌ"))
			if title!=l1l1ll_l1_ (u"ࠫࠬᙍ"): addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙎ"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬᙏ")+title,link,421)
	l1111l111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࠽࠱࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᙐ"),html,re.DOTALL)
	if l1111l111_l1_:
		link,title = l1111l111_l1_[0]
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᙑ"),menu_name+title,link,421)
	return
def l1lllll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ᙒ"),url,l1l1ll_l1_ (u"ࠪࠫᙓ"),l1l1ll_l1_ (u"ࠫࠬᙔ"),l1l1ll_l1_ (u"ࠬ࠭ᙕ"),l1l1ll_l1_ (u"࠭ࠧᙖ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠳ࡶࡸࠬᙗ"))
	html = response.content
	# l11lllll1_l1_/download main l11lllll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡎࡰࡹࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᙘ"),html,re.DOTALL)
	if l1lll11_l1_:
		url = l1lll11_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ᙙ"),url,l1l1ll_l1_ (u"ࠪࠫᙚ"),l1l1ll_l1_ (u"ࠫࠬᙛ"),l1l1ll_l1_ (u"ࠬ࠭ᙜ"),l1l1ll_l1_ (u"࠭ࠧᙝ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠴ࡱࡨࠬᙞ"))
		html = response.content
		#if kodi_version>18.99: html = html.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᙟ"),l1l1ll_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᙠ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡗࡪࡧࡳࡰࡰࡶࡗࡪࡩࡴࡪࡱࡱࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᙡ"),html,re.DOTALL)
	# l1lllll1l1_l1_ l11111l11_l1_
	if l1l1ll_l1_ (u"ࠫ࠴ࡺࡡࡨ࠱ࠪᙢ") in url or l1l1ll_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶࠬᙣ") in url:
		l11l1l_l1_(url)
	# l11l11_l1_
	elif l1lll11_l1_:
		img = xbmc.getInfoLabel(l1l1ll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧᙤ"))
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨᙥ"),block,re.DOTALL)
		l1llllll1l_l1_ = [l1l1ll_l1_ (u"ࠨ็ึุ่๊ࠧᙦ"),l1l1ll_l1_ (u"่ࠩ์ุ๋ࠧᙧ"),l1l1ll_l1_ (u"ࠪฬึ์วๆฮࠪᙨ"),l1l1ll_l1_ (u"ࠫา๊โสࠩᙩ")]
		for link,title in items:
			if any(value in title for value in l1llllll1l_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᙪ"),menu_name+title,link,423,img)
			else: addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᙫ"),menu_name+title,link,426,img)
	else: l11ll1l_l1_(url)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᙬ"),url,l1l1ll_l1_ (u"ࠨࠩ᙭"),l1l1ll_l1_ (u"ࠩࠪ᙮"),l1l1ll_l1_ (u"ࠪࠫᙯ"),l1l1ll_l1_ (u"ࠫࠬᙰ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫᙱ"))
	html = response.content
	#if kodi_version>18.99: html = html.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫᙲ"),l1l1ll_l1_ (u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᙳ"))
	img = re.findall(l1l1ll_l1_ (u"ࠨࠤࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫᙴ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = l1l1ll_l1_ (u"ࠩࠪᙵ")
	# l1ll1_l1_
	l1l1llll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࡷࡘ࡫ࡣࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᙶ"),html,re.DOTALL)
	if l1l1llll1_l1_:
		block = l1l1llll1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᙷ"),block,re.DOTALL)
		for link,title,l11111_l1_ in items:
			title = title+l1l1ll_l1_ (u"ࠬࠦࠧᙸ")+l11111_l1_
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᙹ"),menu_name+title,link,426,img)
	else: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᙺ"),menu_name+l1l1ll_l1_ (u"ࠨำสฬ฼ࠦวๅฬื฾๏๊ࠧᙻ"),url,426,img)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ᙼ"),url,l1l1ll_l1_ (u"ࠪࠫᙽ"),headers,l1l1ll_l1_ (u"ࠫࠬᙾ"),l1l1ll_l1_ (u"ࠬ࠭ᙿ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ "))
	html = response.content
	#newurl = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡷࡽࡱ࡫ࡳࡩࡧࡨࡸࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᚁ"),html,re.DOTALL)
	newurl = response.url
	if kodi_version<19: newurl = newurl.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᚂ"))
	l11ll1_l1_ = SERVER(newurl,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭ᚃ"))
	l11l1_l1_ = []
	# l11lllll1_l1_ l1ll_l1_
	#if kodi_version>18.99: html = html.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᚄ"),l1l1ll_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᚅ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡝ࡡࡵࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧᚆ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡱ࡯࡮࡬࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠦࠥ࠵࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᚇ"),block,re.DOTALL)
		for l1l1l11l_l1_,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩᚈ"))
			if l1l1ll_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧᚉ") in title.lower(): title = l1l1ll_l1_ (u"ࠩัหฺࠦࠧᚊ")+title
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸࡺࡲࡶࡥࡷࡹࡷ࡫࠯ࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨᚋ")+l1l1l11l_l1_+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᚌ")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᚍ")
			#link = link.replace(l1l1ll_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡦ࠺ࡵ࠯࡫ࡦࡹࠬᚎ"),l1l1ll_l1_ (u"ࠧࡤ࡫ࡰࡥ࠹ࡻ࠮࡮ࡺࠪᚏ"))
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡆࡲࡻࡳࡲ࡯ࡢࡦࡖࡩࡷࡼࡥࡳࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭ᚐ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠤࠣ࠳ࡃ࠮࠮ࠫࡁࠬࡀࠬᚑ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬᚒ"))
			if l1l1ll_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪᚓ") in title.lower(): title2 = l1l1ll_l1_ (u"ࠬࡥ࡟ฯษุࠫᚔ")
			else: title2 = l1l1ll_l1_ (u"࠭ࠧᚕ")
			link = link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᚖ")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᚗ")+title2
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᚘ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᚙ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬᚚ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭᚛"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ᚜"),l1l1ll_l1_ (u"ࠧࠬࠩ᚝"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ᚞")+search+l1l1ll_l1_ (u"ࠩ࠲ࠫ᚟")
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪᚠ"))
	return
# ===========================================
#     l1111l1ll_l1_ l1lllllll1_l1_ l1lllll1ll_l1_
# ===========================================
def l1111l1l1_l1_(url):
	if l1l1ll_l1_ (u"ࠫࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷ࠭ᚡ") not in url: url = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩᚢ"))
	else: url = url.split(l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᚣ"))[0]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᚤ"),url,l1l1ll_l1_ (u"ࠨࠩᚥ"),l1l1ll_l1_ (u"ࠩࠪᚦ"),l1l1ll_l1_ (u"ࠪࠫᚧ"),l1l1ll_l1_ (u"ࠫࠬᚨ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙࠲ࡍࡅࡕࡡࡉࡍࡑ࡚ࡅࡓࡕࡢࡆࡑࡕࡃࡌࡕ࠰࠵ࡸࡺࠧᚩ"))
	html = response.content
	# all l1l1l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡍࡶ࡮ࡷ࡭ࡋ࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪࡒࡤ࡫ࡪ࡚ࡩࡵ࡮ࡨࠫᚪ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	# name + options block + category
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡉࡱࡹࡩࡷࡧࡢ࡭ࡧ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࠨࡡ࡭࡮ࠥ࠲࠯ࡅࠨࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᚫ"),block,re.DOTALL)
	return l1111ll_l1_
def l1llllllll_l1_(block):
	# id + title
	items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᚬ"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	l1111111l_l1_ = url.split(l1l1ll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᚭ"))[0]
	l11111111_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧᚮ"))
	url = url.replace(l1111111l_l1_,l11111111_l1_)
	url = url.replace(l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨᚯ"),l1l1ll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡧࡪࡴࡴࡦࡴ࠲ࡥࡨࡺࡩࡰࡰ࠲ࡌࡴࡳࡥࡱࡣࡪࡩࡑࡵࡡࡥࡧࡵ࠳ࠬᚰ"))
	url = url.replace(l1l1ll_l1_ (u"࠭࠽ࠨᚱ"),l1l1ll_l1_ (u"ࠧ࠰ࠩᚲ")).replace(l1l1ll_l1_ (u"ࠨࠨࠪᚳ"),l1l1ll_l1_ (u"ࠩ࠲ࠫᚴ"))
	url = url+l1l1ll_l1_ (u"ࠪ࠳ࠬᚵ")
	return url
l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ᚶ"),l1l1ll_l1_ (u"ࠬࡺࡹࡱࡧࡶࠫᚷ"),l1l1ll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᚸ")]
l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨᚹ"),l1l1ll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᚺ"),l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫ࡳࠨᚻ"),l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᚼ")]
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᚽ"),l1l1ll_l1_ (u"ࠬ࠭ᚾ"))
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧᚿ"),l1l1ll_l1_ (u"ࠧࠨᛀ"),filter,url)
	if l1l1ll_l1_ (u"ࠨࡁࠪᛁ") in url: url = url.split(l1l1ll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᛂ"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧᛃ"),1)
	if filter==l1l1ll_l1_ (u"ࠫࠬᛄ"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭ᛅ"),l1l1ll_l1_ (u"࠭ࠧᛆ")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫᛇ"))
	if type==l1l1ll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫᛈ"):
		if l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᛉ") in url:
			global l1ll1111_l1_
			l1ll1111_l1_ = l1ll1111_l1_[1:]
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠪࡁࠬᛊ") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠫࡂ࠭ᛋ") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠧᛌ")+category+l1l1ll_l1_ (u"࠭࠽࠱ࠩᛍ")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠩᛎ")+category+l1l1ll_l1_ (u"ࠨ࠿࠳ࠫᛏ")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠩࠩࠫᛐ"))+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧᛑ")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠫࠫ࠭ᛒ"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᛓ"))
		url2 = url+l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪᛔ")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪᛕ"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᛖ"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠩࠪᛗ"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᛘ"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠫࠬᛙ"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᛚ")+l1l1ll1l_l1_
		url2 = l11111lll_l1_(url2)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛛ"),menu_name+l1l1ll_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪᛜ"),url2,421,l1l1ll_l1_ (u"ࠨࠩᛝ"),l1l1ll_l1_ (u"ࠩࠪᛞ"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᛟ"))
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛠ"),menu_name+l1l1ll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬᛡ")+l1l11l1l_l1_+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬᛢ"),url2,421,l1l1ll_l1_ (u"ࠧࠨᛣ"),l1l1ll_l1_ (u"ࠨࠩᛤ"),l1l1ll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᛥ"))
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᛦ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᛧ"),l1l1ll_l1_ (u"ࠬ࠭ᛨ"),9999)
	l1111ll_l1_ = l1111l1l1_l1_(url)
	dict = {}
	for name,block,l11111l_l1_ in l1111ll_l1_:
		if l1l1ll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪᛩ") in url and l11111l_l1_==l1l1ll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᛪ"): continue
		name = name.replace(l1l1ll_l1_ (u"ࠨ࠯࠰ࠫ᛫"),l1l1ll_l1_ (u"ࠩࠪ᛬"))
		items = l1llllllll_l1_(block)
		if l1l1ll_l1_ (u"ࠪࡁࠬ᛭") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧᛮ"):
			if category!=l11111l_l1_: continue
			elif len(items)<2:
				if l11111l_l1_==l1ll1111_l1_[-1]:
					url = l11111lll_l1_(url)
					l11l1l_l1_(url)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᛯ")+l1ll11l1_l1_)
				return
			else:
				url2 = l11111lll_l1_(url2)
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᛰ"),menu_name+l1l1ll_l1_ (u"ࠧศๆฯ้๏฿ࠧᛱ"),url2,421,l1l1ll_l1_ (u"ࠨࠩᛲ"),l1l1ll_l1_ (u"ࠩࠪᛳ"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪᛴ"))
				else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛵ"),menu_name+l1l1ll_l1_ (u"ࠬอไอ็ํ฽ࠬᛶ"),url2,425,l1l1ll_l1_ (u"࠭ࠧᛷ"),l1l1ll_l1_ (u"ࠧࠨᛸ"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ᛹"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠩࠩࠫ᛺")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁ࠵࠭᛻")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭᛼")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨ᛽")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪ᛾")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᛿"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠪᜀ")+name,url2,424,l1l1ll_l1_ (u"ࠩࠪᜁ"),l1l1ll_l1_ (u"ࠪࠫᜂ"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᜃ"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if value==l1l1ll_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬᜄ"): option = l1l1ll_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭ᜅ")
			elif value==l1l1ll_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧᜆ"): option = l1l1ll_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪᜇ")
			if option in l1ll11_l1_: continue
			#if l1l1ll_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨᜈ") not in value: value = option
			#else: value = re.findall(l1l1ll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫᜉ"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭ᜊ")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃࠧᜋ")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨᜌ")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾ࠩᜍ")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬᜎ")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠩࠣ࠾ࠬᜏ")#+dict[l11111l_l1_][l1l1ll_l1_ (u"ࠪ࠴ࠬᜐ")]
			title = option+l1l1ll_l1_ (u"ࠫࠥࡀࠧᜑ")+name
			if type==l1l1ll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨᜒ"): addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᜓ"),menu_name+title,url,424,l1l1ll_l1_ (u"ࠧࠨ᜔"),l1l1ll_l1_ (u"ࠨ᜕ࠩ"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᜖"))
			elif type==l1l1ll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭᜗") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠫࡂ࠭᜘") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ᜙"))
				url3 = url+l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ᜚")+l1l1l1l1_l1_
				url3 = l11111lll_l1_(url3)
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᜛"),menu_name+title,url3,421,l1l1ll_l1_ (u"ࠨࠩ᜜"),l1l1ll_l1_ (u"ࠩࠪ᜝"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ᜞"))
			else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᜟ"),menu_name+title,url,425,l1l1ll_l1_ (u"ࠬ࠭ᜠ"),l1l1ll_l1_ (u"࠭ࠧᜡ"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨᜢ"),l1l1ll_l1_ (u"ࠨࠩᜣ"),filters,l1l1ll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪᜤ"))
	# mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᜥ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᜦ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠬࡧ࡬࡭ࠩᜧ")					all l1ll1l1l_l1_ & l1111l11l_l1_ filters
	filters = filters.replace(l1l1ll_l1_ (u"࠭࠽ࠧࠩᜨ"),l1l1ll_l1_ (u"ࠧ࠾࠲ࠩࠫᜩ"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠨࠨࠪᜪ"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠩࡀࠫᜫ") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠪࠪࠬᜬ"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠫࡂ࠭ᜭ"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠬ࠭ᜮ")
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"࠭࠰ࠨᜯ")
		if l1l1ll_l1_ (u"ࠧࠦࠩᜰ") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᜱ") and value!=l1l1ll_l1_ (u"ࠩ࠳ࠫᜲ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠪࠤ࠰ࠦࠧᜳ")+value
		elif mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹ᜴ࠧ") and value!=l1l1ll_l1_ (u"ࠬ࠶ࠧ᜵"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ᜶")+key+l1l1ll_l1_ (u"ࠧ࠾ࠩ᜷")+value
		elif mode==l1l1ll_l1_ (u"ࠨࡣ࡯ࡰࠬ᜸"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠩࠩࠫ᜹")+key+l1l1ll_l1_ (u"ࠪࡁࠬ᜺")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠫࠥ࠱ࠠࠨ᜻"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠬࠬࠧ᜼"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"࠭࠽࠱ࠩ᜽"),l1l1ll_l1_ (u"ࠧ࠾ࠩ᜾"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ᜿"),l1l1ll_l1_ (u"ࠩࠪᝀ"),filters,l1l1ll_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠴࠵ࠫᝁ"))
	return l1llllll_l1_
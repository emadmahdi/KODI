# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ埬")
#headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ埭"):l1l1ll_l1_ (u"ࠬ࠭埮")}
menu_name = l1l1ll_l1_ (u"࠭࡟ࡔࡊࡓࡣࠬ埯")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧๆืสี฾ฯࠧ埰"),l1l1ll_l1_ (u"ࠨสฮࠤ๊ฮวีำࠪ埱")]
def MAIN(mode,url,text):
	if   mode==480: results = MENU()
	elif mode==481: results = l11l1l_l1_(url,text)
	elif mode==482: results = PLAY(url)
	elif mode==483: results = l11ll1l_l1_(url,text)
	elif mode==489: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭埲"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ埳"),l1l1ll_l1_ (u"ࠫࠬ埴"),l1l1ll_l1_ (u"ࠬ࠭埵"),l1l1ll_l1_ (u"࠭ࠧ埶"),l1l1ll_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ執"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ埸"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ培"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ基"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ埻"),menu_name+l1l1ll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ埼"),l11ll1_l1_,489,l1l1ll_l1_ (u"࠭ࠧ埽"),l1l1ll_l1_ (u"ࠧࠨ埾"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ埿"))
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ堀"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ堁"),l1l1ll_l1_ (u"ࠫࠬ堂"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堃"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ堄")+menu_name+l1l1ll_l1_ (u"ࠧฤฯาฯࠥอไๆ๊สฺ๏฿ࠧ堅"),l11ll1_l1_,481)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࠧࡳࡹࡂࡥࡦࡳࡺࡴࡴࠣࠩ堆"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ堇"),block,re.DOTALL)
	for link,title in items:
		if link==l1l1ll_l1_ (u"ࠪࠧࠬ堈"): continue
		if title in l1ll11_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ堉"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ堊")+menu_name+title,link,481)
	return html
def l11l1l_l1_(url,l1l111l11l1l_l1_):
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ堋"),url,l1l1ll_l1_ (u"ࠧࠨ堌"),l1l1ll_l1_ (u"ࠨࠩ堍"),l1l1ll_l1_ (u"ࠩࠪ堎"),l1l1ll_l1_ (u"ࠪࠫ堏"),l1l1ll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ堐"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡰࡵࡷࠬ࠳࠰࠿ࠪࠤࡩࡳࡴࡺࡥࡳࠤࠪ堑"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ堒"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠧ堓"),l1l1ll_l1_ (u"ࠨใํ่๊࠭堔"),l1l1ll_l1_ (u"ࠩส฾๋๐ษࠨ堕"),l1l1ll_l1_ (u"ࠪว฿์๊สࠩ堖"),l1l1ll_l1_ (u"่๊๊ࠫษࠩ堗"),l1l1ll_l1_ (u"ࠬอูๅษ้ࠫ堘"),l1l1ll_l1_ (u"࠭็ะษไࠫ堙"),l1l1ll_l1_ (u"ࠧๆสสีฬฯࠧ堚"),l1l1ll_l1_ (u"ࠨ฻ิฺࠬ堛"),l1l1ll_l1_ (u"่๋ࠩึาว็ࠩ堜"),l1l1ll_l1_ (u"ࠪห้ฮ่ๆࠩ堝"),l1l1ll_l1_ (u"ู๊ࠫัฮ์ฬࠫ堞")]
	l1l111l11ll1_l1_ = l1l1ll_l1_ (u"ࠬ࠵ࠧ堟").join(l1l111l11l1l_l1_.strip(l1l1ll_l1_ (u"࠭࠯ࠨ堠")).split(l1l1ll_l1_ (u"ࠧ࠰ࠩ堡"))[4:]).split(l1l1ll_l1_ (u"ࠨ࠯ࠪ堢"))
	for link,title,img in items:
		title = unescapeHTML(title)
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡฯ็ๆฮࠦ࡜ࡥ࠭ࠪ堣"),title,re.DOTALL)
		if l1l111l11l1l_l1_:
			l111111l1_l1_ = l1l1ll_l1_ (u"ࠪ࠳ࠬ堤").join(link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭堥")).split(l1l1ll_l1_ (u"ࠬ࠵ࠧ堦"))[4:]).split(l1l1ll_l1_ (u"࠭࠭ࠨ堧"))
			l1l111l11lll_l1_ = len([x for x in l1l111l11ll1_l1_ if x in l111111l1_l1_])
			if l1l111l11lll_l1_>2 and l1l1ll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ堨") in link:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ堩"),menu_name+title,link,482,img)
		else:
			if not l11111_l1_: l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ堪"),title,re.DOTALL)
			#if any(value in title for value in l111l_l1_):
			if set(title.split()) & set(l111l_l1_) and l1l1ll_l1_ (u"ุ้๊ࠪำๅࠩ堫") not in title:
				addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ堬"),menu_name+title,link,482,img)
			elif l11111_l1_ and l1l1ll_l1_ (u"ࠬำไใหࠪ堭") in title:
				title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ堮") + l11111_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ堯"),menu_name+title,link,483,img,l1l1ll_l1_ (u"ࠨࠩ堰"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ報"),menu_name+title,link,483,img,l1l1ll_l1_ (u"ࠪࠫ堲"),url)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠦࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ堳"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ場"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"࠭วๅืไัฮࠦࠧ堵"),l1l1ll_l1_ (u"ࠧࠨ堶"))
			if title!=l1l1ll_l1_ (u"ࠨࠩ堷"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ堸"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ堹")+title,link,481,l1l1ll_l1_ (u"ࠫࠬ堺"),l1l1ll_l1_ (u"ࠬ࠭堻"),l1l111l11l1l_l1_)
	return
def l11ll1l_l1_(url,url2):
	headers = {l1l1ll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ堼"):l1l1ll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ堽")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ堾"),url,l1l1ll_l1_ (u"ࠩࠪ堿"),headers,l1l1ll_l1_ (u"ࠪࠫ塀"),l1l1ll_l1_ (u"ࠫࠬ塁"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭塂"))
	html = response.content
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ塃"))
	img = re.findall(l1l1ll_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塄"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ塅"))
	l1l111l11l11_l1_ = True
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡰ࡮ࡹࡴࡔࡧࡤࡷࡴࡴࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ塆"),html,re.DOTALL)
	# l11l11_l1_
	if l1ll1ll_l1_ and l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵࠪ塇") not in url:
		block = l1ll1ll_l1_[0]
		count = block.count(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠨ塈"))
		if count==0: count = block.count(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠫ塉"))
		if count>1:
			l1l111l11l11_l1_ = False
			if l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡲࡵࡨ࠿ࠥࠫ塊") in block:
				items = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹ࡬ࡶࡩࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ塋"),block,re.DOTALL)
				for id,title in items:
					link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡶࡰ࠴࠳࠶࠶࠵ࡴࡦ࡯ࡳ࠳ࡦࡰࡡࡹ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠵࠲ࡵ࡮ࡰࡀࡵ࡯ࡹ࡬ࡃࠧ塌")+id
					addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ塍"),menu_name+title,link,483,img)
			else:
				items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭塎"),block,re.DOTALL)
				for id,title in items:
					link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡹࡳ࠷࠶࠲࠲࠱ࡷࡩࡲࡶ࠯ࡢ࡬ࡤࡼ࠴ࡹࡥࡢࡵࡲࡲࡸ࠴ࡰࡩࡲࡂࡷࡪࡸࡩࡦࡵࡌࡈࡂ࠭塏")+id
					addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ塐"),menu_name+title,link,483,img)
	# l1ll1_l1_
	if l1l111l11l11_l1_:
		block = l1l1ll_l1_ (u"࠭ࠧ塑")
		if l1l1ll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡶࡳࡳࡹࠧ塒") in url: block = html
		else:
			l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡨࡴࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭塓"),html,re.DOTALL)
			if l1ll1l1_l1_: block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塔"),block,re.DOTALL)
		if items:
			for link,title in items:
				title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬ塕"))
				addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ塖"),menu_name+title,link,482,img)
	if not menuItemsLIST: l11l1l_l1_(url2,url)
	return
def PLAY(url):
	url2 = url.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ塗"))+l1l1ll_l1_ (u"࠭࠯ࡀࡦࡲࡁࡼࡧࡴࡤࡪࠪ塘")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ塙"),url2,l1l1ll_l1_ (u"ࠨࠩ塚"),l1l1ll_l1_ (u"ࠩࠪ塛"),l1l1ll_l1_ (u"ࠪࠫ塜"),l1l1ll_l1_ (u"ࠫࠬ塝"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ塞"))
	html = response.content
	l11l1_l1_ = []
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ塟"))
	l1lll1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡷࡱࡢࡴࡴࡹࡴࡊࡆࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塠"),html,re.DOTALL)
	if not l1lll1ll1l_l1_: l1lll1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ塡"),html,re.DOTALL)
	l1lll1ll1l_l1_ = l1lll1ll1l_l1_[0]
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ塢"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ塣"),block,re.DOTALL)
		for l1llll111l_l1_,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭塤"))
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡺࡴ࠸࠰࠳࠳࠲ࡸࡪࡳࡰ࠰ࡣ࡭ࡥࡽ࠵ࡩࡧࡴࡤࡱࡪ࠸࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ塥")+l1lll1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࡷ࡫ࡧࡩࡴࡃࠧ塦")+l1llll111l_l1_[2:]+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ塧")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ塨")
			l11l1_l1_.append(link)
	# l1l1l1l11_l1_ l11lllll1_l1_ link
	link = re.findall(l1l1ll_l1_ (u"ࠩࠥ࡫ࡪࡺࡅ࡮ࡤࡨࡨࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塩"),html,re.DOTALL)
	if link:
		title = SERVER(link[0],l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ塪"))
		link = link[0]+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ填")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭塬")
		l11l1_l1_.append(link)
	# download l1ll_l1_
	url2 = url.strip(l1l1ll_l1_ (u"࠭࠯ࠨ塭"))+l1l1ll_l1_ (u"ࠧ࠰ࡁࡧࡳࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ塮")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ塯"),url2,l1l1ll_l1_ (u"ࠩࠪ塰"),l1l1ll_l1_ (u"ࠪࠫ塱"),l1l1ll_l1_ (u"ࠫࠬ塲"),l1l1ll_l1_ (u"ࠬ࠭塳"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ塴"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡶࡤࡦࡱ࡫࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ塵"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ塶"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ塷"))
			if l1l1ll_l1_ (u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫ塸") in link: title2 = l1l1ll_l1_ (u"ࠫࡤࡥฮศืࠪ塹")
			else: title2 = l1l1ll_l1_ (u"ࠬ࠭塺")
			link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ塻")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ塼")+title2
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭塽"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ塾"),url)
	return
def SEARCH(search,l11ll1_l1_=l1l1ll_l1_ (u"ࠪࠫ塿")):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ墀"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭墁"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ墂"),l1l1ll_l1_ (u"ࠧࠬࠩ境"))
	if l11ll1_l1_==l1l1ll_l1_ (u"ࠨࠩ墄"): l11ll1_l1_ = l1l1l1_l1_
	url = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ墅")+search+l1l1ll_l1_ (u"ࠪ࠳ࠬ墆")
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࠬ墇"))
	return
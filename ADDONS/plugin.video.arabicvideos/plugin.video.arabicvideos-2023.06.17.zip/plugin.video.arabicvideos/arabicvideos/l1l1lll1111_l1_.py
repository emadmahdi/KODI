# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ〶")
menu_name = l1l1ll_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨ〷")
l1l1l1_l1_ = WEBSITES[script_name][0]
headers = {l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ〸"):l1l1ll_l1_ (u"ࠫࠬ〹")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l11l1l_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ〺"),menu_name+l1l1ll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭〻"),l1l1ll_l1_ (u"ࠧࠨ〼"),329,l1l1ll_l1_ (u"ࠨࠩ〽"),l1l1ll_l1_ (u"ࠩࠪ〾"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ〿"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ぀"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬぁ"),l1l1ll_l1_ (u"࠭ࠧあ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫぃ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬい"),l1l1ll_l1_ (u"ࠩࠪぅ"),headers,l1l1ll_l1_ (u"ࠪࠫう"),l1l1ll_l1_ (u"ࠫࠬぇ"),l1l1ll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪえ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡤࡱࡱࡳ࠲ࡶ࡬ࡶࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧぉ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭お"),block,re.DOTALL)
	for link,title in items:
		if title==l1l1ll_l1_ (u"ࠨษ็้่ะศสࠢส่๊ืฦ๋หࠪか"): continue
		link = l1l1l1_l1_+link
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩが"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬき")+menu_name+title,link,321)
	return html
def l11l1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬぎ"),l1l1ll_l1_ (u"ࠬ࠭く"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪぐ"),url,l1l1ll_l1_ (u"ࠧࠨけ"),headers,l1l1ll_l1_ (u"ࠨࠩげ"),l1l1ll_l1_ (u"ࠩࠪこ"),l1l1ll_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪご"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬさ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡱࡦ࠸ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨざ"),block,re.DOTALL)
	if not items: items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭し"),block,re.DOTALL)
	for link,img,count,title in items:
		count = count.replace(l1l1ll_l1_ (u"ฺࠧัาࠤࠬじ"),l1l1ll_l1_ (u"ࠨࠩす")).replace(l1l1ll_l1_ (u"ࠩࠣࠫず"),l1l1ll_l1_ (u"ࠪࠫせ"))
		link = link.replace(l1l1ll_l1_ (u"ࠫ࠴࠭ぜ"),l1l1ll_l1_ (u"ࠬ࠭そ"))
		img = img.replace(l1l1ll_l1_ (u"ࠨࠧࠣぞ"),l1l1ll_l1_ (u"ࠧࠨた"))
		if l1l1ll_l1_ (u"ࠨ࠰ࡳ࡬ࡵ࠭だ") not in link: link = l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬち")+link
		link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬぢ")+link
		img = l1l1l1_l1_+img
		title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭っ"))
		title = title+l1l1ll_l1_ (u"ࠬࠦࠨࠨつ")+count+l1l1ll_l1_ (u"࠭ࠩࠨづ")
		if l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪて") in link: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨで"),menu_name+title,link,321,img)
		elif l1l1ll_l1_ (u"ࠩࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬと") in link: addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩど"),menu_name+title,link,322,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡬࡯ࡰࡶࡨࡶࠬな"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫに"),block,re.DOTALL)
		for link,title in items:
			link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪぬ")+link
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧね"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦࠧの")+title,link,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭は"),url,l1l1ll_l1_ (u"ࠪࠫば"),headers,l1l1ll_l1_ (u"ࠫࠬぱ"),l1l1ll_l1_ (u"ࠬ࠭ひ"),l1l1ll_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫび"))
	html = response.content
	#link = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡣࡸࡨ࡮ࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧぴ"),html,re.DOTALL)
	#if not link:
	link = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡹ࡭ࡩ࡫࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨふ"),html,re.DOTALL)
	link = l1l1l1_l1_+link[0]#+l1l1ll_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨぶ")+l1l11lll1_l1_()+l1l1ll_l1_ (u"ࠪࠪࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡶࡵࡹࡪ࠭ぷ")
	PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪへ"))
	return
def SEARCH(search):
	#search = l1l1ll_l1_ (u"๋ࠬฮหษิࠫべ")
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧぺ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨほ"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪぼ"),l1l1ll_l1_ (u"ࠩ࠮ࠫぽ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡳࡀࠫま")+search
	l11l1l_l1_(url)
	return
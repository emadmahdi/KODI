# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᓔ")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬᓕ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᓖ"),l1l1ll_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩᓗ"),l1l1ll_l1_ (u"ࠩส่ฬ่ำศ็ࠪᓘ"),l1l1ll_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧᓙ"),l1l1ll_l1_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨᓚ"),l1l1ll_l1_ (u"ࠬ࠭ᓛ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l11l1l_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l11_l1_(url,text)
	elif mode==694: results = l1ll1l_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᓜ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨᓝ"),l1l1ll_l1_ (u"ࠨࠩᓞ"),l1l1ll_l1_ (u"ࠩࠪᓟ"),l1l1ll_l1_ (u"ࠪࠫᓠ"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᓡ"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓢ"),menu_name+l1l1ll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᓣ"),l1l1ll_l1_ (u"ࠧࠨᓤ"),699,l1l1ll_l1_ (u"ࠨࠩᓥ"),l1l1ll_l1_ (u"ࠩࠪᓦ"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᓧ"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᓨ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓩ"),l1l1ll_l1_ (u"࠭ࠧᓪ"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓫ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᓬ")+menu_name+l1l1ll_l1_ (u"ࠩส่๊๋๊ำหࠪᓭ"),l1l1l1_l1_,691,l1l1ll_l1_ (u"ࠪࠫᓮ"),l1l1ll_l1_ (u"ࠫࠬᓯ"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᓰ"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓱ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᓲ")+menu_name+l1l1ll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᓳ"),l1l1l1_l1_,691,l1l1ll_l1_ (u"ࠩࠪᓴ"),l1l1ll_l1_ (u"ࠪࠫᓵ"),l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᓶ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓷ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᓸ")+menu_name+l1l1ll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᓹ"),l1l1l1_l1_,691,l1l1ll_l1_ (u"ࠨࠩᓺ"),l1l1ll_l1_ (u"ࠩࠪᓻ"),l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᓼ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓽ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᓾ")+menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᓿ"),l1l1l1_l1_,691,l1l1ll_l1_ (u"ࠧࠨᔀ"),l1l1ll_l1_ (u"ࠨࠩᔁ"),l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᔂ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔃ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔄ"),l1l1ll_l1_ (u"ࠬ࠭ᔅ"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔆ"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᔇ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔈ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔉ")+menu_name+title,link,694)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔊ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔋ"),l1l1ll_l1_ (u"ࠬ࠭ᔌ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᔍ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᔎ"),html,re.DOTALL)
	#for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠨࠩᔏ"))
	#block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᔐ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		title = title.replace(l1l1ll_l1_ (u"ࠪࡀࡧࡄࠧᔑ"),l1l1ll_l1_ (u"ࠫࠬᔒ")).strip(l1l1ll_l1_ (u"ࠬࠦࠧᔓ"))
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔔ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔕ")+menu_name+title,link,694)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᔖ"),url,l1l1ll_l1_ (u"ࠩࠪᔗ"),l1l1ll_l1_ (u"ࠪࠫᔘ"),l1l1ll_l1_ (u"ࠫࠬᔙ"),l1l1ll_l1_ (u"ࠬ࠭ᔚ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᔛ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔜ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᔝ"),l1l1ll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᔞ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔟ"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠫࠬᔠ"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᔡ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔢ"),l1l1ll_l1_ (u"ࠧࠨᔣ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔤ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠩ࠽ࠤࠬᔥ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔦ"),menu_name+title,link,691)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔧ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔨ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᔩ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᔪ"),l1l1ll_l1_ (u"ࠨࠩᔫ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔬ"),menu_name+title,link,691)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠪࠫᔭ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬᔮ"),l1l1ll_l1_ (u"ࠬ࠭ᔯ"),request,url)
	if request==l1l1ll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᔰ"):
		url,search = url.split(l1l1ll_l1_ (u"ࠧࡀࠩᔱ"),1)
		data = l1l1ll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᔲ")+search
		headers = {l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᔳ"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᔴ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩᔵ"),url,data,headers,l1l1ll_l1_ (u"ࠬ࠭ᔶ"),l1l1ll_l1_ (u"࠭ࠧᔷ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᔸ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᔹ"),url,l1l1ll_l1_ (u"ࠩࠪᔺ"),l1l1ll_l1_ (u"ࠪࠫᔻ"),l1l1ll_l1_ (u"ࠫࠬᔼ"),l1l1ll_l1_ (u"ࠬ࠭ᔽ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᔾ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠧࠨᔿ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬᕀ"))
	if request==l1l1ll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᕁ"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᕂ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠫࠬᕃ"),link,title))
	elif request==l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᕄ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕅ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᕆ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕇ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᕈ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᕉ"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕊ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᕋ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕌ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠧࠨᕍ"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕎ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᕏ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ู้ࠪอ็ะหࠪᕐ"),l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩᕑ"),l1l1ll_l1_ (u"ࠬอฺ็์ฬࠫᕒ"),l1l1ll_l1_ (u"࠭ใๅ์หࠫᕓ"),l1l1ll_l1_ (u"ࠧศ฻็ห๋࠭ᕔ"),l1l1ll_l1_ (u"ࠨ้าหๆ࠭ᕕ"),l1l1ll_l1_ (u"่ࠩฬฬืวสࠩᕖ"),l1l1ll_l1_ (u"ࠪ฽ึ฼ࠧᕗ"),l1l1ll_l1_ (u"๊ࠫํัอษ้ࠫᕘ"),l1l1ll_l1_ (u"ࠬอไษ๊่ࠫᕙ"),l1l1ll_l1_ (u"࠭ๅิำะ๎ฮ࠭ᕚ")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩᕛ"))
		#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᕜ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫᕝ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬᕞ"))
		#if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᕟ") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧᕠ")+img.strip(l1l1ll_l1_ (u"࠭࠯ࠨᕡ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩᕢ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᕣ"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᕤ"),menu_name+title,link,692,img)
		elif request==l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕥ"):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᕦ"),menu_name+title,link,692,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᕧ") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕨ"),menu_name+title,link,693,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᕩ") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕪ"),menu_name+title,link,691,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕫ"),menu_name+title,link,693,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕬ"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕭ")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕮ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᕯ"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠧࠤࠩᕰ"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪᕱ")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫᕲ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕳ"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪᕴ")+title,link,691)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ᕵ"),l1l1ll_l1_ (u"࠭ࠧᕶ"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫᕷ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᕸ"),url,l1l1ll_l1_ (u"ࠩࠪᕹ"),l1l1ll_l1_ (u"ࠪࠫᕺ"),l1l1ll_l1_ (u"ࠫࠬᕻ"),l1l1ll_l1_ (u"ࠬ࠭ᕼ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᕽ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᕾ"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᕿ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠩࠪᖀ")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫᖁ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᖂ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠬࠩࠧᖃ"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖄ"),menu_name+title,url,693,img,l1l1ll_l1_ (u"ࠧࠨᖅ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᖆ"),html,re.DOTALL)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪᖇ"),str(l1lll11_l1_))
	block = l1lll11_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᖈ")+l1lll_l1_+l1l1ll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᖉ"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᖊ")+l1lll_l1_+l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᖋ"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᖌ")+l1lll_l1_+l1l1ll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᖍ"),block,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᖎ"),block,re.DOTALL)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫᖏ"),l1l1ll_l1_ (u"ࠫࠬᖐ"),l1l1ll_l1_ (u"ࠬ࠭ᖑ"),l1l1ll_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᖒ"))
		if not l1lll1l_l1_: l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᖓ"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖔ"),block,re.DOTALL)
		for link,title,img in items:
			link = link.strip(l1l1ll_l1_ (u"ࠩ࠱࠳ࠬᖕ"))
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬᖖ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᖗ"))
			title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᖘ"),l1l1ll_l1_ (u"࠭ࠠࠨᖙ"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᖚ"),menu_name+title,link,692,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᖛ"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᖜ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬᖝ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᖞ"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖟ"),menu_name+title,link,692,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᖠ"),l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡩ࠳ࡶࡨࡱࠩᖡ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᖢ"),url2,l1l1ll_l1_ (u"ࠩࠪᖣ"),l1l1ll_l1_ (u"ࠪࠫᖤ"),l1l1ll_l1_ (u"ࠫࠬᖥ"),l1l1ll_l1_ (u"ࠬ࠭ᖦ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᖧ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᖨ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		# l1l1l1l11_l1_ link
		link = re.findall(l1l1ll_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖩ"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᖪ"))
			l11l1_l1_.append(link)
		# l11lllll1_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡰࡰࡦࡰ࡮ࡩ࡫࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᖫ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭ᖬ"))
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᖭ")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᖮ"))
				l11l1_l1_.append(link)
		# download l1ll_l1_
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᖯ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l11l1_l1_:
				title = title.strip(l1l1ll_l1_ (u"ࠨ࡞ࡱࠫᖰ"))
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖱ")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᖲ"))
				l11l1_l1_.append(link)
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᖳ"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖴ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧᖵ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨᖶ"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪᖷ"),l1l1ll_l1_ (u"ࠩ࠮ࠫᖸ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᖹ")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᖺ"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩᖻ")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᖼ"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
DIALOG_NOTIFICATION(l1l1ll_l1_ (u"࡚ࠬࡅࡔࡖࠪ墈"),l1l1ll_l1_ (u"࠭ࡔࡆࡕࡗࠫ墉"))
#url = l1l1ll_l1_ (u"ࠧࡄ࠼࡟ࡠࡕࡵࡲࡵࡣࡥࡰࡪࠦࡐࡳࡱࡪࡶࡦࡳࡳ࡝࡞ࡎࡓࡉࡏ࡟ࡷ࠳࠻ࡣ࠻࠺ࡢࡪࡶ࡟ࡠࡐࡵࡤࡪ࡞࡟ࡴࡴࡸࡴࡢࡤ࡯ࡩࡤࡪࡡࡵࡣ࡟ࡠࡨࡧࡣࡩࡧ࡟ࡠࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࡞࡟ࡪ࡮ࡲࡥࡠ࠲࠻࠽࠻ࡥࡓࡉࡘࡢึ๏อัสࡡส่ึู่ๅࡡส่ศ฿ุๆࡡูࠫ࠮ࡥࠨฤสสิึࡥวๅฯ็์ฬา๊ࠪ࠰ࡰࡴ࠸࠭墊")
#url = l1l1ll_l1_ (u"ࠨࡥ࠽ࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ墋")
#url = l1l1ll_l1_ (u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡹࡤࡧ࠰ࡰࡴ࠸࠭墌")
#url = l1l1ll_l1_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡡࠡࡤࡥࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ墍")
url = l1l1ll_l1_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢแฮื࠱ࡱࡵ࠹ࠧ墎")
url = l1l1ll_l1_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜ࡧ࡫࡯ࡩࡤ࠺࠸࠴࠶ࡢࡗࡍ࡜࡟ำ์สีฮࡥวๅำึ์้ࡥวๅล฼฼๊ࡥࠨึࠫࡢࠬศฮวัำࡢห้ำไ้ษฯ๎࠮࠴࡭ࡱ࠵ࠪ墏")
#url = url.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ墐"))
xbmc.Player().play(url)
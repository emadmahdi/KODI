# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ囝")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬ回")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1l111lll1_l1_ = WEBSITES[script_name][1]
l1l1lllll11_l1_ = WEBSITES[script_name][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l11l1l_l1_(url)
	elif mode==52: results = l11ll1l_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l1l111ll11ll_l1_()
	elif mode==56: results = l1l111l1lll1_l1_()
	elif mode==57: results = l1l111l1llll_l1_(url,1)
	elif mode==58: results = l1l111l1llll_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囟"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ因"),l1l1ll_l1_ (u"ࠩࠪ囡"),59,l1l1ll_l1_ (u"ࠪࠫ团"),l1l1ll_l1_ (u"ࠫࠬ団"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ囤"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ囥"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ囦"),l1l1ll_l1_ (u"ࠨࠩ囧"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囨"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ囩")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠧ囪"),l1l1ll_l1_ (u"ࠬ࠭囫"),56)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囬"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ园")+menu_name+l1l1ll_l1_ (u"ࠨษ็หๆ๊วๆࠩ囮"),l1l1ll_l1_ (u"ࠩࠪ囯"),55)
	return l1l1ll_l1_ (u"ࠪࠫ困")
def l1l111ll11ll_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囱"),menu_name+l1l1ll_l1_ (u"ࠬออะอࠣห้อแๅษ่ࠫ囲"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ図"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ围"),menu_name+l1l1ll_l1_ (u"ࠨษไ่ฬ๋ࠠาษษะฮ࠭囵"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ囶"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囷"),menu_name+l1l1ll_l1_ (u"ࠫฬิัࠡษูหๆอสࠡษ็หๆ๊วๆࠩ囸"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ囹"),51)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭固"),menu_name+l1l1ll_l1_ (u"ࠧศใ็ห๊ࠦใๅษึ๎่๐ษࠨ囻"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ囼"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ国"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ图"),l1l1ll_l1_ (u"ࠫࠬ囿"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圀"),menu_name+l1l1ll_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤอูๆสࠢส่ฬ์สศฮࠪ圁"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡼࡳࡵ࠭圂"),57)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ圃"),menu_name+l1l1ll_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษษ็หๆ฼ไࠡฬๅ๎๏๋ࠧ圄"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ圅"),57)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圆"),menu_name+l1l1ll_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วไอิࠤฺ๊ว่ัฬࠫ圇"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ圈"),57)
	return
def l1l111l1lll1_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ圉"),menu_name+l1l1ll_l1_ (u"ࠨษะำะࠦวๅ็ึุ่๊วหࠩ圊"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡴࡥࡸࡧࡶࡸࠬ國"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ圌"),menu_name+l1l1ll_l1_ (u"ู๊ࠫไิๆสฮࠥืววฮฬࠫ圍"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡲࡲࡴࡺࡲࡡࡳࠩ圎"),51)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圏"),menu_name+l1l1ll_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊ๅิๆึ่ฬะࠧ圐"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡱࡧࡴࡦࡵࡷࠫ圑"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ園"),menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤ่๊วิ์ๆ๎ฮ࠭圓"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡤ࡮ࡤࡷࡸ࡯ࡣࠨ圔"),51)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ圕"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭圖"),l1l1ll_l1_ (u"ࠧࠨ圗"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ團"),menu_name+l1l1ll_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหื๋ฯࠠศๆส๊ฯอฬࠨ圙"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡹࡰࡲࠪ圚"),57)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圛"),menu_name+l1l1ll_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮวๅษไฺ้ࠦสใ์ํ้ࠬ圜"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡵࡩࡻ࡯ࡥࡸࠩ圝"),57)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ圞"),menu_name+l1l1ll_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ้หาุ่ࠢฬํฯสࠩ土"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡼࡩࡦࡹࡶࠫ圠"),57)
	return
def l11l1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ圡"),l1l1ll_l1_ (u"ࠫࠬ圢"),url,url)
	if l1l1ll_l1_ (u"ࠬࡅࠧ圣") in url:
		parts = url.split(l1l1ll_l1_ (u"࠭࠿ࠨ圤"))
		url = parts[0]
		filter = l1l1ll_l1_ (u"ࠧࡀࠩ圥") + QUOTE(parts[1],l1l1ll_l1_ (u"ࠨ࠿ࠩ࠾࠴ࠫࠧ圦"))
	else: filter = l1l1ll_l1_ (u"ࠩࠪ圧")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ在"),l1l1ll_l1_ (u"ࠫࠬ圩"),filter,l1l1ll_l1_ (u"ࠬ࠭圪"))
	parts = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ圫"))
	sort,page,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l1ll_l1_ (u"ࠧࡺࡱࡳࠫ圬"),l1l1ll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࠨ圭"),l1l1ll_l1_ (u"ࠩࡹ࡭ࡪࡽࡳࠨ圮")]:
		if type==l1l1ll_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ圯"): type1=l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩ地")
		elif type==l1l1ll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ圱"): type1=l1l1ll_l1_ (u"࠭ๅิๆึ่ࠬ圲")
		#url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ圳") + QUOTE(type1) + l1l1ll_l1_ (u"ࠨ࠱ࠪ圴") + page + l1l1ll_l1_ (u"ࠩ࠲ࠫ圵") + sort + filter
		url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ圶") + QUOTE(type1) + l1l1ll_l1_ (u"ࠫ࠴࠭圷") + page + l1l1ll_l1_ (u"ࠬ࠵ࠧ圸") + sort + filter
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ圹"),l1l1ll_l1_ (u"ࠧࠨ场"),l1l1ll_l1_ (u"ࠨࠩ圻"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠩࠪ圼"),l1l1ll_l1_ (u"ࠪࠫ圽"),l1l1ll_l1_ (u"ࠫࠬ圾"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ圿"))
		#items = re.findall(l1l1ll_l1_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡴࡵ࡮ࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡸࡥࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ址"),html,re.DOTALL)
		items = re.findall(l1l1ll_l1_ (u"ࠧࠣࡲ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࠤࡳࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠰ࡅࠢࡱࡧࡳ࡭ࡸࡵࡤࡦࡵࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡵࡸࡥࡴࡤࡤࡷࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ坁"),html,re.DOTALL)
		l1l1lll11l1_l1_=0
		for id,title,l1l111l1l1l1_l1_,img in items:
			l1l1lll11l1_l1_ += 1
			#img = l1l111lll1_l1_ + l1l1ll_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ坂") + img + l1l1ll_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ坃")
			img = l1l1lllll11_l1_ + l1l1ll_l1_ (u"ࠪ࠳ࡻ࠸࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴ࡳࡡࡪࡰ࠲ࠫ坄") + img + l1l1ll_l1_ (u"ࠫ࠲࠸࠮࡫ࡲࡪࠫ坅")
			link = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠬ࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ坆") + id
			if type==l1l1ll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ均"): addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭坈"),menu_name+title,link,53,img)
			if type==l1l1ll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ坉"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坊"),menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅࠢࠪ坋")+title,link+l1l1ll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ坌")+l1l111l1l1l1_l1_+l1l1ll_l1_ (u"ࠬࡃࠧ坍")+title+l1l1ll_l1_ (u"࠭࠽ࠨ坎")+img,52,img)
	else:
		if type==l1l1ll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭坏"): type1=l1l1ll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ坐")
		elif type==l1l1ll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ坑"): type1=l1l1ll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ坒")
		url = l1l111lll1_l1_ + l1l1ll_l1_ (u"ࠫ࠴ࡰࡳࡰࡰ࠲ࡷࡪࡲࡥࡤࡶࡨࡨ࠴࠭坓") + sort + l1l1ll_l1_ (u"ࠬ࠳ࠧ坔") + type1 + l1l1ll_l1_ (u"࠭࠭ࡘ࡙࠱࡮ࡸࡵ࡮ࠨ坕")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠧࠨ坖"),l1l1ll_l1_ (u"ࠨࠩ块"),l1l1ll_l1_ (u"ࠩࠪ坘"),l1l1ll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ坙"))
		items = re.findall(l1l1ll_l1_ (u"ࠫࠧࡸࡥࡧࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡩࡵࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡣࡣࡶࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ坚"),html,re.DOTALL)
		l1l1lll11l1_l1_=0
		for id,l1l111l1l1l1_l1_,img,title in items:
			l1l1lll11l1_l1_ += 1
			img = l1l111lll1_l1_ + l1l1ll_l1_ (u"ࠬ࠵ࡩ࡮ࡩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ坛") + img + l1l1ll_l1_ (u"࠭࠭࠳࠰࡭ࡴ࡬࠭坜")
			link = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ坝") + id
			if type==l1l1ll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ坞"): addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ坟"),menu_name+title,link,53,img)
			elif type==l1l1ll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ坠"): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坡"),menu_name+l1l1ll_l1_ (u"๋ࠬำๅี็ࠤࠬ坢")+title,link+l1l1ll_l1_ (u"࠭࠿ࡦࡲࡀࠫ坣")+l1l111l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠾ࠩ坤")+title+l1l1ll_l1_ (u"ࠨ࠿ࠪ坥")+img,52,img)
	title=l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ坦")
	if l1l1lll11l1_l1_==16:
		for l1l1lllll1l_l1_ in range(1,13) :
			if not page==str(l1l1lllll1l_l1_):
				#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ坧")+type+l1l1ll_l1_ (u"ࠫ࠴࠭坨")+str(l1l1lllll1l_l1_)+l1l1ll_l1_ (u"ࠬ࠵ࠧ坩")+sort + filter
				url = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ坪")+type+l1l1ll_l1_ (u"ࠧ࠰ࠩ坫")+str(l1l1lllll1l_l1_)+l1l1ll_l1_ (u"ࠨ࠱ࠪ坬")+sort + filter
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ坭"),menu_name+title+str(l1l1lllll1l_l1_),url,51)
	return
def l11ll1l_l1_(url):
	parts = url.split(l1l1ll_l1_ (u"ࠪࡁࠬ坮"))
	l1l111l1l1l1_l1_ = int(parts[1])
	name = UNQUOTE(parts[2])
	name = name.replace(l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ坯"),l1l1ll_l1_ (u"ࠬ࠭坰"))
	img = parts[3]
	url = url.split(l1l1ll_l1_ (u"࠭࠿ࠨ坱"))[0]
	if l1l111l1l1l1_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠧࠨ坲"),l1l1ll_l1_ (u"ࠨࠩ坳"),l1l1ll_l1_ (u"ࠩࠪ坴"),l1l1ll_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ坵"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁࡹࡥ࡭ࡧࡦࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬ坶"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ坷"),block,re.DOTALL)
		l1l111l1l1l1_l1_ = int(items[-1])
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ坸"),l1l1ll_l1_ (u"ࠧࠨ坹"),l1l111l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩ坺"))
	#name = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡯ࡴ࡭ࡧࠥ坻") )
	#img = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠦ坼") )
	for l11111_l1_ in range(l1l111l1l1l1_l1_,0,-1):
		link = url + l1l1ll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ坽") + str(l11111_l1_)
		title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ坾")+name+l1l1ll_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ坿")+str(l11111_l1_)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭垀"),menu_name+title,link,53,img)
	return
def PLAY(url):
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩ垁"),l1l1ll_l1_ (u"ࠩࠪ垂"),l1l1ll_l1_ (u"ࠪࠫ垃"),l1l1ll_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ垄"))
	l1l111l1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"๋ࠬส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี࠮ࠫࡁࡰࡳࡲ࡫࡮ࡵ࡞ࠫࠦ࠭࠴ࠪࡀࠫࠥࠫ垅"),html,re.DOTALL)
	if l1l111l1ll1l_l1_:
		time = l1l111l1ll1l_l1_[1].replace(l1l1ll_l1_ (u"࠭ࡔࠨ垆"),l1l1ll_l1_ (u"ࠧࠡࠢࠣࠤࠬ垇"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ垈"),l1l1ll_l1_ (u"ࠩࠪ垉"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠬ垊"),l1l1ll_l1_ (u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢึ๎่๎ๆࠡ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั๋ࠣีอࠠศๆ๋ๆฯ࠭型")+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ垌")+time)
		return
	#if l1l1ll_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ垍") in html:
	#	DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ垎"),l1l1ll_l1_ (u"ࠨࠩ垏"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠫ垐"),l1l1ll_l1_ (u"๊ࠪ฾ะะาࠢ฼่๎่ࠦใ๊฼ࠤำ฽รࠨ垑"))
	#	return
	l1l111l1l111_l1_,l1l111ll1111_l1_ = [],[]
	l1l111ll11l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡻࡧࡲࠡࡱࡵ࡭࡬࡯࡮ࡠ࡮࡬ࡲࡰࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ垒"),html,re.DOTALL)[0]
	l1l111l1ll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡼࡡࡳࠢࡥࡥࡨࡱࡵࡱࡡࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ垓"),html,re.DOTALL)[0]
	# l11111ll_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨ࡭ࡵ࠽ࠤ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ垔"),html,re.DOTALL)
	for server,link in l1ll_l1_:
		if l1l1ll_l1_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠧ垕") in server:
			server = l1l1ll_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠡࡵࡨࡶࡻ࡫ࡲࠨ垖")
			url = l1l111l1ll11_l1_ + link
		else:
			server = l1l1ll_l1_ (u"ࠩࡰࡥ࡮ࡴࠠࡴࡧࡵࡺࡪࡸࠧ垗")
			url = l1l111ll11l1_l1_ + link
		if l1l1ll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ垘") in url:
			l1l111l1l111_l1_.append(url)
			l1l111ll1111_l1_.append(l1l1ll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠣࠫ垙")+server)
		l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋࠌ࡭࡫ࠦࠧ࠯࡯࠶ࡹ࠽࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺ࠫࡹࡷࡲࠩࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࠴ࡢࡃ࠽ࠨ࠯࠴ࠫ࠿ࠐࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴࡡࡸࡶࡱ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࠊ࡫ࡷࡩࡲࡹ࡟࡯ࡣࡰࡩ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭࡭࠴ࡷ࠻ࠤࠥ࠭ࠫࡴࡧࡵࡺࡪࡸࠩࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡥࡳ࡭ࡥࠩ࡮ࡨࡲ࠭ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࠪࠫ࠽ࠎࠎࠏࠉࠊࠋ࡬ࡸࡪࡳࡳࡠࡷࡵࡰ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚࡛ࡪ࡟ࠬࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠤࡂࠦࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࡝࡬ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠦࠧࠪ࡝࠳ࡡࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࡛ࡪ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠣࠤࠥ࠭ࠬࠨࠢࠣࠫ࠮ࠐࠉࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࡨ࡬ࡰࡪࡺࡹࡱࡧ࠮ࠫࠥࠦࠧࠬࡵࡨࡶࡻ࡫ࡲࠬࠩࠣࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠤࠥࠦ垚")
	# l11l1111_l1_ l1ll_l1_
	l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ垛"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l1ll_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ垜"),html,re.DOTALL)
	for server,link in l1ll_l1_:
		filename = link.split(l1l1ll_l1_ (u"ࠨ࠱ࠪ垝"))[-1]
		filename = filename.replace(l1l1ll_l1_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ垞"),l1l1ll_l1_ (u"ࠪࠫ垟"))
		filename = filename.replace(l1l1ll_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ垠"),l1l1ll_l1_ (u"ࠬ࠭垡"))
		filename = filename.replace(l1l1ll_l1_ (u"࠭࠭ࠨ垢"),l1l1ll_l1_ (u"ࠧࠨ垣"))
		if l1l1ll_l1_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ垤") in server:
			server = l1l1ll_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ垥")
			url = l1l111l1ll11_l1_ + link
		else:
			server = l1l1ll_l1_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ垦")
			url = l1l111ll11l1_l1_ + link
		l1l111l1l111_l1_.append(url)
		l1l111ll1111_l1_.append(l1l1ll_l1_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ垧")+server+l1l1ll_l1_ (u"ࠬࠦࠠࠨ垨")+filename)
	selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ垩"), l1l111ll1111_l1_)
	if selection == -1 : return
	url = l1l111l1l111_l1_[selection]
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭垪"))
	return
def l1l111l1llll_l1_(url,type):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ垫"),l1l1ll_l1_ (u"ࠩࠪ垬"),url,url)
	if l1l1ll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ垭") in url: url2 = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳ู๊ไิๆࠪ垮")
	else: url2 = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠬ࠵ࡧࡦࡰࡵࡩ࠴็๊ๅ็ࠪ垯")
	url2 = QUOTE(url2)
	html = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"࠭ࠧ垰"),l1l1ll_l1_ (u"ࠧࠨ垱"),l1l1ll_l1_ (u"ࠨࠩ垲"),l1l1ll_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡋࡏࡌࡕࡇࡕࡗ࠲࠷ࡳࡵࠩ垳"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ垴"),l1l1ll_l1_ (u"ࠫࠬ垵"),url,html)
	if type==1: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡹࡵࡣࡩࡨࡲࡷ࡫ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ垶"),html,re.DOTALL)
	elif type==2: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ垷"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴࠧ垸"),block,re.DOTALL)
	if type==1:
		for l1l111ll111l_l1_,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垹"),menu_name+title,url+l1l1ll_l1_ (u"ࠩࡂࡷࡺࡨࡧࡦࡰࡵࡩࡂ࠭垺")+l1l111ll111l_l1_,58)
	elif type==2:
		url,l1l111ll111l_l1_ = url.split(l1l1ll_l1_ (u"ࠪࡃࠬ垻"))
		for country,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垼"),menu_name+title,url+l1l1ll_l1_ (u"ࠬࡅࡣࡰࡷࡱࡸࡷࡿ࠽ࠨ垽")+country+l1l1ll_l1_ (u"࠭ࠦࠨ垾")+l1l111ll111l_l1_,51)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ垿"),l1l1ll_l1_ (u"ࠨࠩ埀"),search,search)
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠩࠣࠫ埁"),l1l1ll_l1_ (u"ࠪࠩ࠷࠶ࠧ埂"))
	#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ埃"), l1l1l1_l1_, l1l1ll_l1_ (u"ࠬ࠭埄"), l1l1ll_l1_ (u"࠭ࠧ埅"), True,l1l1ll_l1_ (u"ࠧࠨ埆"),l1l1ll_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ埇"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11lll1l1_l1_ = cookies[l1l1ll_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࠪ埈")]
	#l1l111l1l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡧࡸࡸࡦࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪ埉"),html,re.DOTALL)
	#l1l111l1l1ll_l1_ = l1l111l1l1ll_l1_[0]
	#payload = l1l1ll_l1_ (u"ࠫࡤࡩࡳࡳࡨࡀࠫ埊") + l1l111l1l1ll_l1_ + l1l1ll_l1_ (u"ࠬࠬࡱ࠾ࠩ埋") + QUOTE(l11lll1_l1_)
	#headers = { l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ埌"):l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭埍") , l1l1ll_l1_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨ城"):l1l1ll_l1_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡀࠫ埏")+l11lll1l1_l1_ }
	#url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠥ࠳ࡸ࡫ࡡࡳࡥ࡫ࠦ埐")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ埑"), url, payload, headers, True,l1l1ll_l1_ (u"ࠬ࠭埒"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡕࡈࡅࡗࡉࡈ࠮࠴ࡱࡨࠬ埓"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ埔")+l11lll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ埕"),url,l1l1ll_l1_ (u"ࠩࠪ埖"),l1l1ll_l1_ (u"ࠪࠫ埗"),True,l1l1ll_l1_ (u"ࠫࠬ埘"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠳ࡰࡧࠫ埙"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡧࡦࡰࡨࡶࡦࡲ࠭ࡣࡱࡧࡽ࠭࠴ࠪࡀࠫࡶࡩࡦࡸࡣࡩ࠯ࡥࡳࡹࡺ࡯࡮࠯ࡳࡥࡩࡪࡩ࡯ࡩࠪ埚"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࠥࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ埛"),block,re.DOTALL)
	if items:
		for link,img,title in items:
			#title = title.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭埜")).encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ埝"))
			url = l1l1l1_l1_ + link
			if l1l1ll_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭埞") in url:
				if l1l1ll_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ域") in url:
					title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ埠")+title
					url = url.replace(l1l1ll_l1_ (u"࠭࠿ࡦࡲࡀ࠵ࠬ埡"),l1l1ll_l1_ (u"ࠧࡀࡧࡳࡁ࠵࠭埢"))
					url = url+l1l1ll_l1_ (u"ࠨ࠿ࠪ埣")+QUOTE(title)+l1l1ll_l1_ (u"ࠩࡀࠫ埤")+img
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埥"),menu_name+title,url,52,img)
				else:
					title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡไ๎้๋ࠠࠨ埦")+title
					addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ埧"),menu_name+title,url,53,img)
	#else: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ埨"),l1l1ll_l1_ (u"ࠧࠨ埩"),l1l1ll_l1_ (u"ࠨࡰࡲࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠬ埪"),l1l1ll_l1_ (u"ࠩ็หࠥะ่อั๊ࠣฯอฦอࠢ็่อำหࠨ埫"))
	return
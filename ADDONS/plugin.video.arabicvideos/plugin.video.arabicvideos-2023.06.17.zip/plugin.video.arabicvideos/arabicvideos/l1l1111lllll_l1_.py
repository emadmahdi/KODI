# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ媘")
menu_name = l1l1ll_l1_ (u"ࠩࡢ࡝ࡖ࡚࡟ࠨ媙")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬ媚"),l1l1ll_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬ媛"),l1l1ll_l1_ (u"ࠬะำอ์็ࠫ媜"),l1l1ll_l1_ (u"࠭สิฮํ่ࠥอไะะ๋่ࠬ媝"),l1l1ll_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫ媞")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l11l1l_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l11_l1_(url,text)
	elif mode==664: results = l1ll1l_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ媟"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ媠"),l1l1ll_l1_ (u"ࠪࠫ媡"),l1l1ll_l1_ (u"ࠫࠬ媢"),l1l1ll_l1_ (u"ࠬ࠭媣"),l1l1ll_l1_ (u"࡙࠭ࡂࡓࡒࡘ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ媤"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媥"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ媦"),l1l1ll_l1_ (u"ࠩࠪ媧"),669,l1l1ll_l1_ (u"ࠪࠫ媨"),l1l1ll_l1_ (u"ࠫࠬ媩"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ媪"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ媫"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ媬"),l1l1ll_l1_ (u"ࠨࠩ媭"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媮"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ媯")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ媰"),l1l1l1_l1_,661,l1l1ll_l1_ (u"ࠬ࠭媱"),l1l1ll_l1_ (u"࠭ࠧ媲"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ媳"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媴"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ媵")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ媶"),l1l1l1_l1_,661,l1l1ll_l1_ (u"ࠫࠬ媷"),l1l1ll_l1_ (u"ࠬ࠭媸"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ媹"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媺"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媻")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ媼"),l1l1l1_l1_,661,l1l1ll_l1_ (u"ࠪࠫ媽"),l1l1ll_l1_ (u"ࠫࠬ媾"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ媿"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫀"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嫁")+menu_name+l1l1ll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ嫂"),l1l1l1_l1_,661,l1l1ll_l1_ (u"ࠩࠪ嫃"),l1l1ll_l1_ (u"ࠪࠫ嫄"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭嫅"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嫆"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嫇"),l1l1ll_l1_ (u"ࠧࠨ嫈"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嫉"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ嫊"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫋"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嫌")+menu_name+title,link,664)
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嫍"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嫎"),l1l1ll_l1_ (u"ࠧࠨ嫏"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ嫐"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ嫑"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠪࠫ嫒"))
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ嫓"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l1l1ll_l1_ (u"ࠬࡂࡢ࠿ࠩ嫔"),l1l1ll_l1_ (u"࠭ࠧ嫕")).replace(l1l1ll_l1_ (u"ࠧ࠽࠱ࡥࡂࠬ嫖"),l1l1ll_l1_ (u"ࠨࠩ嫗")).replace(l1l1ll_l1_ (u"ࠩ࠿ࡦࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡧࡷࠦࡃ࠭嫘"),l1l1ll_l1_ (u"ࠪࠫ嫙")).replace(l1l1ll_l1_ (u"ࠫࡁࡨ࠾ࠨ嫚"),l1l1ll_l1_ (u"ࠬ࠭嫛")).strip(l1l1ll_l1_ (u"࠭ࠠࠨ嫜"))
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫝"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嫞")+menu_name+title,link,664)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭嫟"),url,l1l1ll_l1_ (u"ࠪࠫ嫠"),l1l1ll_l1_ (u"ࠫࠬ嫡"),l1l1ll_l1_ (u"ࠬ࠭嫢"),l1l1ll_l1_ (u"࠭ࠧ嫣"),l1l1ll_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ嫤"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ嫥"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪ嫦"),l1l1ll_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩ嫧"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嫨"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠬ࠭嫩"),block)]
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嫪"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ嫫"),l1l1ll_l1_ (u"ࠨࠩ嫬"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ嫭"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠪ࠾ࠥ࠭嫮")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫯"),menu_name+title,link,661)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嫰"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ嫱"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ嫲"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嫳"),l1l1ll_l1_ (u"ࠩࠪ嫴"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嫵"),menu_name+title,link,661)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠫࠬ嫶")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭嫷"),l1l1ll_l1_ (u"࠭ࠧ嫸"),request,url)
	if request==l1l1ll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ嫹"):
		url,search = url.split(l1l1ll_l1_ (u"ࠨࡁࠪ嫺"),1)
		data = l1l1ll_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ嫻")+search
		headers = {l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ嫼"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ嫽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ嫾"),url,data,headers,l1l1ll_l1_ (u"࠭ࠧ嫿"),l1l1ll_l1_ (u"ࠧࠨ嬀"),l1l1ll_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ嬁"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭嬂"),url,l1l1ll_l1_ (u"ࠪࠫ嬃"),l1l1ll_l1_ (u"ࠫࠬ嬄"),l1l1ll_l1_ (u"ࠬ࠭嬅"),l1l1ll_l1_ (u"࠭ࠧ嬆"),l1l1ll_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ嬇"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠨࠩ嬈"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭嬉"))
	if request==l1l1ll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ嬊"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭嬋"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠬ࠭嬌"),link,title))
	elif request==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ嬍"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嬎"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ嬏"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ嬐"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ嬑"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ嬒"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ嬓"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ嬔"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ嬕"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠨࠩ嬖"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ嬗"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嬘"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ฺ๊ࠫว่ัฬࠫ嬙"),l1l1ll_l1_ (u"ࠬ็๊ๅ็ࠪ嬚"),l1l1ll_l1_ (u"࠭ว฻่ํอࠬ嬛"),l1l1ll_l1_ (u"ࠧไๆํฬࠬ嬜"),l1l1ll_l1_ (u"ࠨษ฼่ฬ์ࠧ嬝"),l1l1ll_l1_ (u"๊ࠩำฬ็ࠧ嬞"),l1l1ll_l1_ (u"้ࠪออัศหࠪ嬟"),l1l1ll_l1_ (u"ࠫ฾ืึࠨ嬠"),l1l1ll_l1_ (u"๋ࠬ็าฮส๊ࠬ嬡"),l1l1ll_l1_ (u"࠭วๅส๋้ࠬ嬢"),l1l1ll_l1_ (u"ࠧๆีิั๏ฯࠧ嬣")]
	for img,link,title in items:
		title = title.replace(l1l1ll_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠣࠫ嬤"),l1l1ll_l1_ (u"ࠩࠪ嬥")).replace(l1l1ll_l1_ (u"ࠪหํ์ไศ์้ࠤࠬ嬦"),l1l1ll_l1_ (u"ࠫࠬ嬧")).replace(l1l1ll_l1_ (u"๋ࠬิศ้าอࠥ࠭嬨"),l1l1ll_l1_ (u"࠭ࠧ嬩"))
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ嬪"))
		#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭嬫") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ嬬")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ嬭"))
		#if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ嬮") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧ嬯")+img.strip(l1l1ll_l1_ (u"࠭࠯ࠨ嬰"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩ嬱"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ嬲"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嬳"),menu_name+title,link,662,img)
		elif request==l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ嬴"):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嬵"),menu_name+title,link,662,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ嬶") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嬷"),menu_name+title,link,663,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ嬸") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嬹"),menu_name+title,link,661,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬺"),menu_name+title,link,663,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ嬻"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭嬼")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嬽"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ嬾"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠧࠤࠩ嬿"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪ孀")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ孁"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孂"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪ孃")+title,link,661)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭孄"),l1l1ll_l1_ (u"࠭ࠧ孅"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ孆"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ孇"),url,l1l1ll_l1_ (u"ࠩࠪ孈"),l1l1ll_l1_ (u"ࠪࠫ孉"),l1l1ll_l1_ (u"ࠫࠬ孊"),l1l1ll_l1_ (u"ࠬ࠭孋"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ孌"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ孍"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ孎"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠩࠪ孏")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ子"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠫࠨ࠭孑"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孒"),menu_name+title,url,663,img,l1l1ll_l1_ (u"࠭ࠧ孓"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠨ孔")+l1lll_l1_+l1l1ll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ孕"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭孖"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		#if not items: items = re.findall(l1l1ll_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ字"),block,re.DOTALL)
		for link,title,img in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭存")+link.strip(l1l1ll_l1_ (u"ࠬ࠴࠯ࠨ孙"))
			title = title.replace(l1l1ll_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫ孚"),l1l1ll_l1_ (u"ࠧࠡࠩ孛"))
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ孜"),menu_name+title,link,662,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ孝"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ孞") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭孟")+link.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ孠"))
		#		addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ孡"),menu_name+title,link,662,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	url2 = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ孢"),l1l1ll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠮ࡱࡪࡳࠫ季"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭孤"),url2,l1l1ll_l1_ (u"ࠪࠫ孥"),l1l1ll_l1_ (u"ࠫࠬ学"),l1l1ll_l1_ (u"ࠬ࠭孧"),l1l1ll_l1_ (u"࠭ࠧ孨"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ孩"))
	html = response.content
	# l1l1l1l11_l1_ link
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ孪"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		link = re.findall(l1l1ll_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ孫"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ孬"))
			l11l1_l1_.append(link)
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭孭"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭孮"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ孯")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ孰"))
				l11l1_l1_.append(link)
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ࠲ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨࠫࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲ࠲࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡱ࡯࡮࡬ࡵ࠽ࠎࠎࠏࠉࡪࡨࠣࡰ࡮ࡴ࡫ࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡒࡉࡔࡖ࠽ࠎࠎࠏࠉࠊࡰࡤࡱࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠧࠨࠢ孱")
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ孲"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ孳"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ孴"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭孵"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ孶"),l1l1ll_l1_ (u"ࠧࠬࠩ孷"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ學")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ孹"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ孺")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ孻"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
#l1l1l1_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ≂")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠶࠴ࡢࡦࡵࡷࠫ≃")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠴࠲ࡨࡵ࡭ࠨ≄")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ≅")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠵ࡤࡨࡷࡹ࠴ࡣࡰ࡯ࠪ≆")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠳ࡶࡪࡲ࠱ࡷ࡭ࡵࡦࡥࡣ࠱ࡧࡴࡳࠧ≇")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡰ࡯ࡨ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴ࡬ࠨ≈")
#l1l1l1_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࠨ≉")
script_name = l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓࠫ≊")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡈࡋ࡛ࡥࠧ≋")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l11l1l_l1_(url,page)
	elif mode==222: results = l1ll1l_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l111l11_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ≌"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ≍"),l1l1ll_l1_ (u"ࠫࠬ≎"),229,l1l1ll_l1_ (u"ࠬ࠭≏"),l1l1ll_l1_ (u"࠭ࠧ≐"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ≑"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ≒"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ≓"),l1l1l1_l1_,226,l1l1ll_l1_ (u"ࠪࠫ≔"),l1l1ll_l1_ (u"ࠫࠬ≕"),l1l1ll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ≖"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭≗"),menu_name+l1l1ll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ≘"),l1l1l1_l1_,226,l1l1ll_l1_ (u"ࠨࠩ≙"),l1l1ll_l1_ (u"ࠩࠪ≚"),l1l1ll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࡣࡤࡥࠧ≛"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ≜"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ≝"),l1l1ll_l1_ (u"࠭ࠧ≞"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ≟"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩ≠"),l1l1ll_l1_ (u"ࠩࠪ≡"),l1l1ll_l1_ (u"ࠪࠫ≢"),l1l1ll_l1_ (u"ࠫࠬ≣"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ≤"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࠡ࡫࠰࡬ࡴࡳࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭≥"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ≦"),block,re.DOTALL)
	for link,title in items:
		if l1l1ll_l1_ (u"ࠨ࠾࠲࡭ࡃ࠭≧") in title: title = title.split(l1l1ll_l1_ (u"ࠩ࠿࠳࡮ࡄࠧ≨"))[1]
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≩"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭≪")+menu_name+title,link,222)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ≫"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≬"),l1l1ll_l1_ (u"ࠧࠨ≭"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡤࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࠩ≮"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩࡳࡨࡦࠦࡢࡥࡤࠥࡂࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭≯"),html,re.DOTALL)
	for title,link in items:
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ≰"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭≱")+menu_name+title,link,221)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ≲"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭≳"),l1l1ll_l1_ (u"ࠧࠨ≴"),9999)
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≵"),block,re.DOTALL)
	for link,title in items:
		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡲࡲࠧ≶") not in link: continue
		if not link.endswith(l1l1ll_l1_ (u"ࠪ࠳ࠬ≷")): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≸"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ≹")+menu_name+title,link,221)
	return html
	l1l1ll_l1_ (u"ࠨࠢࠣࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษู฾฼ࠦ็็ษ่ࠣฬ฼วโหࠣหุ๋ࠠะะ๋่ࠥ๎ใๅ็ฬࠤฬ๊ำาࠩ࠯ࠫࠬ࠲࠲࠳࠷ࠬࠎࠎࠩࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪฮาึ๊าࠩ࠯ࠫࠬ࠲࠲࠳࠸ࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠥ࡮ࡴ࡮࡮ࠬࠎࠎࠩࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴࡌࡰࡣࡧࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠥࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠩࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡡࡴࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡦࡰࡴࠣࡹࡷࡲࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠧࠎ࡯ࡦࠡࡷࡵࡰࠦࡃࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡻࡲ࡭࠮࠵࠶࠹࠯ࠊࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ࠲ࠧࠨ࠮࠵࠶࠾࠲ࠧࠨ࠮ࠪࠫ࠱࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอไฤๅฮี๋ࠥิศ้าอࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭ࠪ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭ࠬ࠳࠴࠴࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอไศใ็ห๊࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠮ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ࠲࠲࠳࠶ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ๊ๅิๆึ่ฬะࠧ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࠬ࠵ࡴࡷࠩ࠯࠶࠷࠺ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨ࡮࡬ࡲࡰ࠭ࠬࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠮ࠪࠫ࠱࠿࠹࠺࠻ࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡤ࡮ࡤࡷࡸࡃࠢࡣࡣࠣࡱ࡬ࡨࠨ࠯ࠬࡂ࠭ࡃࡋࡧࡺࡄࡨࡷࡹࡂ࠯ࡢࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠯ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠴࠵࠵࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡩࡶࡰࡰࠏࠏࠣࠡࡧࡪࡽࡧ࡫ࡳࡵ࠳࠱ࡧࡴࡳࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠨ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡜࠳࠲ࡡࡠ࡯ࠢ࡞ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࠬࡺ࡯ࡳࡴࡨࡲࡹ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡶࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌ࡭࡫ࠦࠧࡵࡱࡵࡶࡪࡴࡴࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫࠭࠴࠵࠵࠮ࠐࠉࠣࠤࠥ≺")
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ≻"),url,l1l1ll_l1_ (u"ࠨࠩ≼"),l1l1ll_l1_ (u"ࠩࠪ≽"),l1l1ll_l1_ (u"ࠪࠫ≾"),l1l1ll_l1_ (u"ࠫࠬ≿"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⊀"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡴࡡࡶࡧࡷࡵ࡬࡭ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⊁"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⊂"),block,re.DOTALL)
	for link,title in items:
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊃"),menu_name+title,link,224)
	return
def l111l11_l1_(url):
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⊄"),menu_name+l1l1ll_l1_ (u"ࠪห้าๅ๋฻ࠪ⊅"),url,221)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠫࠬ⊆"),l1l1ll_l1_ (u"ࠬ࠭⊇"),l1l1ll_l1_ (u"࠭ࠧ⊈"),l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⊉"))
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡡࡪࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎࠨࠢࠣ⊊")
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡹࡧࡥ࡮ࡢࡸࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡲࡵࡶࡪࡧࡶࠫ⊋"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ⊌"),block,re.DOTALL)
		for link,title in items:
			if link==l1l1ll_l1_ (u"ࠫࠨ࠭⊍"): name = title
			else:
				title = title + l1l1ll_l1_ (u"ࠬࠦࠠ࠻ࠢࠣࠫ⊎") + l1l1ll_l1_ (u"࠭แๅฬิࠤࠬ⊏") + name
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊐"),menu_name+title,link,221)
	else: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,page=l1l1ll_l1_ (u"ࠨ࠳ࠪ⊑")):
	if page==l1l1ll_l1_ (u"ࠩࠪ⊒"): page = l1l1ll_l1_ (u"ࠪ࠵ࠬ⊓")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ⊔"),l1l1ll_l1_ (u"ࠬ࠭⊕"),str(url), str(page))
	if l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ⊖") in url or l1l1ll_l1_ (u"ࠧࡀࠩ⊗") in url: url2 = url + l1l1ll_l1_ (u"ࠨࠨࠪ⊘")
	else: url2 = url + l1l1ll_l1_ (u"ࠩࡂࠫ⊙")
	#url2 = url2 + l1l1ll_l1_ (u"ࠪࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠧࡱࡸࡸࡵࡻࡴࡠ࡯ࡲࡨࡪࡃ࡭ࡰࡸ࡬ࡩࡸࡥ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠪ⊚")+page
	url2 = url2 + l1l1ll_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪ⊛") + page
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠬ࠭⊜"),l1l1ll_l1_ (u"࠭ࠧ⊝"),l1l1ll_l1_ (u"ࠧࠨ⊞"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⊟"))
	#name = l1l1ll_l1_ (u"ࠩࠪ⊠")
	#if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫ⊡") in url:
	#	name = re.findall(l1l1ll_l1_ (u"ࠫࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⊢"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l1l1ll_l1_ (u"ࠬࠦࠧ⊣")) + l1l1ll_l1_ (u"࠭ࠠ࠮ࠢࠪ⊤")
	#	else: name = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠣ⊥") ) + l1l1ll_l1_ (u"ࠨࠢ࠰ࠤࠬ⊦")
	if l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪ⊧") in url:
		l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡩࡧࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ⊨"),html,re.DOTALL)
		block = l1lll11_l1_[-1]
	# l1llll1l1ll_l1_ l11l11_l1_
	elif l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⊩") in url:
		l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡵࡷ࡭࠯ࡦࡥࡷࡵࡵࡴࡧ࡯ࠤࡴࡽ࡬࠮ࡥࡤࡶࡴࡻࡳࡦ࡮ࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ⊪"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	else:
		l1lll11_l1_=re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⊫"),html,re.DOTALL)
		block = l1lll11_l1_[-1]
	items = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⊬"),block,re.DOTALL)
	for link,img,title in items:
		l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠏࡩࡧࠢࠪ࠳ࡸ࡫ࡲࡪࡧࡶࠫࠥ࡯࡮ࠡࡷࡵࡰࠥࡧ࡮ࡥࠢࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊ࡫ࡩࠤࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭ࠠࡪࡰࠣࡹࡷࡲࠠࡢࡰࡧࠤࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡵ࡫ࡷࡰࡪ࠲ࠠࡴࡶࡵࠬࡱ࡯࡮࡬ࠫࠬࠎࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠ࡯ࡣࡰࡩࠥ࠱ࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡵ࡫ࡷࡰࡪ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠢࠣࠤ⊭")
		title = unescapeHTML(title)
		l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡱ࡬ࠦ࠽ࠡ࡫ࡰ࡫࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡪ࡯ࡪ࠾ࠥ࡯࡭ࡨࠢࡀࠤࠬ࡮ࡴࡵࡲ࠽ࠫࠥ࠱ࠠࡪ࡯ࡪࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡏࡑࡗࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠮ࡩ࡮ࡩ࠯ࠫࠬ࠯ࠊࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠ࡭࡫ࡱ࡯ࠏࠏࠉࠣࠤࠥ⊮")
		if l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲ࠫ⊯") in link or l1l1ll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠭⊰") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⊱"),menu_name+title,link.rstrip(l1l1ll_l1_ (u"࠭࠯ࠨ⊲")),223,img)
		else:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊳"),menu_name+title,link,221,img)
	if len(items)>=16:
		l111l1lll1_l1_ = [l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⊴"),l1l1ll_l1_ (u"ࠩ࠲ࡸࡻ࠭⊵"),l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ⊶"),l1l1ll_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ⊷")]
		page = int(page)
		if any(value in url for value in l111l1lll1_l1_):
			for n in range(0,1000,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⊸"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ⊹")+str(j),url,221,l1l1ll_l1_ (u"ࠧࠨ⊺"),str(j))
						elif i!=0: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊻"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ⊼")+str(i),url,221,l1l1ll_l1_ (u"ࠪࠫ⊽"),str(i))
						else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊾"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ⊿")+str(1),url,221,l1l1ll_l1_ (u"࠭ࠧ⋀"),str(1))
				elif n!=0: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋁"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦࠧ⋂")+str(n),url,221,l1l1ll_l1_ (u"ࠩࠪ⋃"),str(n))
				else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋄"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪ⋅")+str(1),url,221)
	return
def PLAY(url):
	#global l1l1ll_l1_ (u"ࠬ࠭⋆")
	l111l1l_l1_,l11l1_l1_ = [],[]
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⋇"),l1l1ll_l1_ (u"ࠧࠨ⋈"),url, url[-45:])
	# l1lll11l_l1_://l1lllll1ll1_l1_.l1lll1ll1_l1_/l1llllll1ll_l1_/فيلم-the-l1lllllllll_l1_-l1llll1ll11_l1_-2019-مترجم
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠨࠩ⋉"),l1l1ll_l1_ (u"ࠩࠪ⋊"),l1l1ll_l1_ (u"ࠪࠫ⋋"),l1l1ll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⋌"))
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂࡴࡥࡀส่ฯ฻ๆ๋ใ࠿࠳ࡹࡪ࠾࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⋍"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	# l1lll11l_l1_://l111lllll1_l1_.l1llll1l1l1_l1_/l1llllll1ll_l1_/فيلم-the-l1lllllllll_l1_-l1llll1ll11_l1_-2019-مترجم
	l11ll11ll_l1_,l1l111ll1_l1_ = l1l1ll_l1_ (u"࠭ࠧ⋎"),l1l1ll_l1_ (u"ࠧࠨ⋏")
	l111111111_l1_,l1lllll11ll_l1_ = html,html
	l1llllll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡵ࡫ࡳࡼࡥࡤ࡭ࠢࡤࡴ࡮ࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⋐"),html,re.DOTALL)
	if l1llllll111_l1_:
		for link in l1llllll111_l1_:
			if l1l1ll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ⋑") in link: l11ll11ll_l1_ = link
			elif l1l1ll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ⋒") in link: l1l111ll1_l1_ = link
		if l11ll11ll_l1_!=l1l1ll_l1_ (u"ࠫࠬ⋓"): l111111111_l1_ = OPENURL_CACHED(l11l1ll_l1_,l11ll11ll_l1_,l1l1ll_l1_ (u"ࠬ࠭⋔"),l1l1ll_l1_ (u"࠭ࠧ⋕"),l1l1ll_l1_ (u"ࠧࠨ⋖"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ⋗"))
		if l1l111ll1_l1_!=l1l1ll_l1_ (u"ࠩࠪ⋘"): l1lllll11ll_l1_ = OPENURL_CACHED(l11l1ll_l1_,l1l111ll1_l1_,l1l1ll_l1_ (u"ࠪࠫ⋙"),l1l1ll_l1_ (u"ࠫࠬ⋚"),l1l1ll_l1_ (u"ࠬ࠭⋛"),l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ⋜"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ⋝"),l1l1ll_l1_ (u"ࠨࠩ⋞"),l1l111ll1_l1_,l11ll11ll_l1_)
	# l1lll11l_l1_://l1lllll11l1_l1_.l111lllll1_l1_.download/?id=__1llllllll1_l1_
	l1llllll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⋟"),l111111111_l1_,re.DOTALL)
	if l1llllll11l_l1_:
		url2 = l1llllll11l_l1_[0]#+l1l1ll_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿࡫ࡸࡹࡶ࠺࠰࠱࠺࠽࠳࠷࠶࠶࠰࠵࠸࠷࠴࠸࠵࠼࠷࠵࠹࠻ࠧ⋠")
		if url2!=l1l1ll_l1_ (u"ࠫࠬ⋡") and l1l1ll_l1_ (u"ࠬࡻࡰ࡭ࡱࡤࡨࡪࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⋢") in url2 and l1l1ll_l1_ (u"࠭࠯ࡀ࡫ࡧࡁࡤ࠭⋣") not in url2:
			l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"ࠧࠨ⋤"),l1l1ll_l1_ (u"ࠨࠩ⋥"),l1l1ll_l1_ (u"ࠩࠪ⋦"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ⋧"))
			l1llll1l111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⋨"),l1l11ll1_l1_,re.DOTALL)
			if l1llll1l111_l1_:
				for link,l11ll1l1_l1_ in l1llll1l111_l1_:
					l11l1_l1_.append(link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࡫ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡳࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣࠬ⋩")+l11ll1l1_l1_)
			else:
				server = url2.split(l1l1ll_l1_ (u"࠭࠯ࠨ⋪"))[2]
				l11l1_l1_.append(url2+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⋫")+server+l1l1ll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⋬"))
		elif url2!=l1l1ll_l1_ (u"ࠩࠪ⋭"):
			#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ⋮"),l1l1ll_l1_ (u"ࠫࠬ⋯"),url2,str(l1llllll11l_l1_))
			server = url2.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ⋰"))[2]
			l11l1_l1_.append(url2+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋱")+server+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⋲"))
	# l1lll11l_l1_://l1llll1llll_l1_.cc/l1lllllll1l_l1_
	# l1lll11l_l1_://l1llllll1l1_l1_.l1llll1lll1_l1_/l1lllllll1l_l1_
	l1lllll111l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷࡥࡧࡲࡥࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡦ࡯ࡷࡤࡺࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ⋳"),l1lllll11ll_l1_,re.DOTALL)
	if l1lllll111l_l1_:
		l1lllll111l_l1_ = l1lllll111l_l1_[0]
		l1lllll1lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡸࡩࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⋴"),l1lllll111l_l1_,re.DOTALL)
		if l1lllll1lll_l1_:
			for l11ll1l1_l1_,link in l1lllll1lll_l1_:
				if l1l1ll_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ⋵") not in link: continue
				if link.count(l1l1ll_l1_ (u"ࠫ࠴࠭⋶"))>=2:
					server = link.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ⋷"))[2]
					l11l1_l1_.append(link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⋸")+server+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫ⋹")+l11ll1l1_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨษัฮึࠦวๅใํำ๏๎ࠠศๆ่๊ฬูศ࠻ࠩ⋺"), l11l1_l1_)
	#if selection == -1 : return
	newLIST = []
	for link in l11l1_l1_:
		# l1llll1ll1l_l1_	l1lll11l_l1_://l1lllll1l1_l1_.l111lllll1_l1_.l1llll1l1l1_l1_/l1llllll1ll_l1_/l11lllll1_l1_/فيلم-the-l1lllllll11_l1_-l1lllll1l1l_l1_-l1llll1l11l_l1_-2017-مترجم/l1lllll1l11_l1_
		#if l1l1ll_l1_ (u"ࠩࡩࡥࡸ࡫࡬ࡩࡦࠪ⋻") in link: continue
		#if l1l1ll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡻ࡯ࡰࡀࡰࡤࡱࡪ࠭⋼") in link: continue
		#if l1l1ll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ⋽") in link: continue
		#if l1l1ll_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ⋾") not in link: continue
		newLIST.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ⋿"), newLIST)
	import ll_l1_
	ll_l1_.l1l_l1_(newLIST,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⌀"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠨࠩ⌁"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠩࠪ⌂"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠪࠤࠬ⌃"),l1l1ll_l1_ (u"ࠫ࠰࠭⌄"))
	html = OPENURL_CACHED(l1llll1l1_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭⌅"),l1l1ll_l1_ (u"࠭ࠧ⌆"),l1l1ll_l1_ (u"ࠧࠨ⌇"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ⌈"))
	token = re.findall(l1l1ll_l1_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࡡࡷࡳࡰ࡫࡮ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⌉"),html,re.DOTALL)
	if token:
		url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡤࡺ࡯࡬ࡧࡱࡁࠬ⌊")+token[0]+l1l1ll_l1_ (u"ࠫࠫࡷ࠽ࠨ⌋")+l11lll1_l1_
		l11l1l_l1_(url)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭⌌"),l1l1ll_l1_ (u"࠭ࠧ⌍"),l1l1ll_l1_ (u"ࠧࠨ⌎"), l1l1ll_l1_ (u"ࠨࠩ⌏"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡇࡑࡋࡁࡏࡇࡕࠫ᮶")
menu_name = l1l1ll_l1_ (u"ࠫࡤࡉࡌࡏࡡࠪ᮷")
l1ll11l11l_l1_ = os.path.join(l1ll1llll1_l1_,l1l1ll_l1_ (u"ࠬࡺࡥ࡮ࡲࠪ᮸"))
l1l1l1l111_l1_ = os.path.join(l1ll1llll1_l1_,l1l1ll_l1_ (u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨ᮹"))
l1ll111lll_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩᮺ"),l1l1ll_l1_ (u"ࠨࡖ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬᮻ"))
l1ll11llll_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫᮼ"),l1l1ll_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬᮽ"),l1l1ll_l1_ (u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫᮾ"))
l1l1l1l11l_l1_ = l1l1ll_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡸࡿࡳࡵࡧࡰ࠳ࡺࡹࡡࡨࡧࡶࡸࡦࡺࡳࠨᮿ")
l1l1l1l1l1_l1_ = l1l1ll_l1_ (u"࠭࠯ࡥࡣࡷࡥ࠴ࡹࡹࡴࡶࡨࡱ࠴ࡪࡲࡰࡲࡥࡳࡽ࠭ᯀ")
l1ll111ll1_l1_ = l1l1ll_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠪᯁ")
l1l1l1ll11_l1_ = l1l1ll_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯࡭ࡱࡪ࡫ࡪࡸࠧᯂ")
l1l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰࡮ࡲ࡫ࠬᯃ")
l1l1l1lll1_l1_ = l1l1ll_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡤࡲࡷ࠭ᯄ")
def MAIN(mode):
	if   mode==740: results = l1ll1lll1l_l1_()
	elif mode==741: results = l1ll1ll11l_l1_(l1ll11l11l_l1_,True,True)
	elif mode==742: results = l1ll1ll11l_l1_(l1l1l1l111_l1_,True,True)
	elif mode==743: results = l1ll1ll11l_l1_(l1ll111lll_l1_,False,True)
	elif mode==744: results = l1l1ll111l_l1_(l1ll11llll_l1_,True)
	elif mode==745: results = l1l1l11ll1_l1_(True)
	elif mode==750: results = l1ll111111_l1_()
	elif mode==751: results = l1ll1ll11l_l1_(l1l1l1l11l_l1_,False,True)
	elif mode==752: results = l1ll1ll11l_l1_(l1l1l1l1l1_l1_,False,True)
	elif mode==753: results = l1ll1ll11l_l1_(l1ll111ll1_l1_,False,True)
	elif mode==754: results = l1ll1ll11l_l1_(l1l1l1ll11_l1_,False,True)
	elif mode==755: results = l1ll1ll11l_l1_(l1l1l1ll1l_l1_,False,True)
	elif mode==756: results = l1ll1ll11l_l1_(l1l1l1lll1_l1_,False,True)
	elif mode==757: results = l1ll1111l1_l1_(True)
	elif mode==758: results = l1l1lllll1_l1_()
	else: results = False
	return results
def l1ll1lll1l_l1_():
	l1l1ll1l11_l1_,l1l1lll1l1_l1_ = l1l1l1l1ll_l1_(l1ll11l11l_l1_)
	l1ll11lll1_l1_,l1l1ll1lll_l1_ = l1l1l1l1ll_l1_(l1l1l1l111_l1_)
	l1ll11ll1l_l1_,l1l1lll111_l1_ = l1l1l1l1ll_l1_(l1ll111lll_l1_)
	l1ll1l11ll_l1_,l1l1ll1l1l_l1_ = l1ll11l111_l1_(l1ll11llll_l1_)
	l1ll1l11ll_l1_ -= 36864
	l1l1ll1l1l_l1_ -= 1
	text1 = l1l1ll_l1_ (u"ࠫࠥ࠮ࠧᯅ")+l1ll1ll1l1_l1_(l1l1ll1l11_l1_)+l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩᯆ")+str(l1l1lll1l1_l1_)+l1l1ll_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᯇ")
	text2 = l1l1ll_l1_ (u"ࠧࠡࠪࠪᯈ")+l1ll1ll1l1_l1_(l1ll11lll1_l1_)+l1l1ll_l1_ (u"ࠨࠢ࠰ࠤࠬᯉ")+str(l1l1ll1lll_l1_)+l1l1ll_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᯊ")
	text3 = l1l1ll_l1_ (u"ࠪࠤ࠭࠭ᯋ")+l1ll1ll1l1_l1_(l1ll11ll1l_l1_)+l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨᯌ")+str(l1l1lll111_l1_)+l1l1ll_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᯍ")
	l1ll1l1111_l1_ = l1l1ll_l1_ (u"࠭ࠠࠩࠩᯎ")+l1ll1ll1l1_l1_(l1ll1l11ll_l1_)+l1l1ll_l1_ (u"ࠧࠪࠩᯏ")
	size = l1l1ll1l11_l1_+l1ll11lll1_l1_+l1ll11ll1l_l1_+l1ll1l11ll_l1_
	count = l1l1lll1l1_l1_+l1l1ll1lll_l1_+l1l1lll111_l1_+l1l1ll1l1l_l1_
	text = l1l1ll_l1_ (u"ࠨࠢࠫࠫᯐ")+l1ll1ll1l1_l1_(size)+l1l1ll_l1_ (u"ࠩࠣ࠱ࠥ࠭ᯑ")+str(count)+l1l1ll_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᯒ")
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᯓ"),menu_name+l1l1ll_l1_ (u"๋ࠬำฮࠢส่ัฺ๋๊ࠩᯔ")+text,l1l1ll_l1_ (u"࠭ࠧᯕ"),745)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᯖ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᯗ"),l1l1ll_l1_ (u"ࠩࠪᯘ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᯙ"),menu_name+l1l1ll_l1_ (u"ู๊ࠫอࠡษ็้้็วหࠢส่๊สโหหࠪᯚ")+text1,l1l1ll_l1_ (u"ࠬ࠭ᯛ"),741)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᯜ"),menu_name+l1l1ll_l1_ (u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆุ฽์฼ฯࠧᯝ")+text2,l1l1ll_l1_ (u"ࠨࠩᯞ"),742)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᯟ"),menu_name+l1l1ll_l1_ (u"ุ้ࠪำࠠศๆุ์ึࠦวๅไา๎๊ฯࠧᯠ")+text3,l1l1ll_l1_ (u"ࠫࠬᯡ"),743)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᯢ"),menu_name+l1l1ll_l1_ (u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨᯣ")+l1ll1l1111_l1_,l1l1ll_l1_ (u"ࠧࠨᯤ"),744)
	settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᯥ"),l1l1ll_l1_ (u"᯦ࠩࠪ"))
	return
def l1ll111111_l1_():
	l1ll1ll111_l1_ = True if l1l1ll_l1_ (u"ࠪ࠳ࠬᯧ") in l1l1ll11l1_l1_ else False
	if not l1ll1ll111_l1_:
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬᯨ"),l1l1ll_l1_ (u"ࠬ࠭ᯩ"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᯪ"),l1l1ll_l1_ (u"ฺࠧ็็๎ฮࠦส็ฺํๅࠥอไอ้สึ๋ࠥส้ใิอࠥ็โุࠢ็วัําสࠢํ์๋้ำࠡ࠰࠱ࠤํา็ศิๆࠤ้๐ำࠡ็้ࠤ๋๎ูࠡ์ู๋๊่ࠧᯫ"))
		return
	refresh = settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᯬ"))
	if not refresh: l1l1lllll1_l1_()
	l1l1ll1l11_l1_,l1l1lll1l1_l1_ = l1l1l1l1ll_l1_(l1l1l1l11l_l1_)
	l1ll11lll1_l1_,l1l1ll1lll_l1_ = l1l1l1l1ll_l1_(l1l1l1l1l1_l1_)
	l1ll11ll1l_l1_,l1l1lll111_l1_ = l1l1l1l1ll_l1_(l1ll111ll1_l1_)
	l1ll1l11ll_l1_,l1l1ll1l1l_l1_ = l1l1l1l1ll_l1_(l1l1l1ll11_l1_)
	l1ll1l11l1_l1_,l1l1ll1ll1_l1_ = l1l1l1l1ll_l1_(l1l1l1ll1l_l1_)
	l1ll1l111l_l1_,l1ll11l1l1_l1_ = l1l1l1l1ll_l1_(l1l1l1lll1_l1_)
	text1 = l1l1ll_l1_ (u"ࠩࠣࠬࠬᯭ")+l1ll1ll1l1_l1_(l1l1ll1l11_l1_)+l1l1ll_l1_ (u"ࠪࠤ࠲ࠦࠧᯮ")+str(l1l1lll1l1_l1_)+l1l1ll_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᯯ")
	text2 = l1l1ll_l1_ (u"ࠬࠦࠨࠨᯰ")+l1ll1ll1l1_l1_(l1ll11lll1_l1_)+l1l1ll_l1_ (u"࠭ࠠ࠮ࠢࠪᯱ")+str(l1l1ll1lll_l1_)+l1l1ll_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ᯲")
	text3 = l1l1ll_l1_ (u"ࠨ᯳ࠢࠫࠫ")+l1ll1ll1l1_l1_(l1ll11ll1l_l1_)+l1l1ll_l1_ (u"ࠩࠣ࠱ࠥ࠭᯴")+str(l1l1lll111_l1_)+l1l1ll_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ᯵")
	l1ll1l1111_l1_ = l1l1ll_l1_ (u"ࠫࠥ࠮ࠧ᯶")+l1ll1ll1l1_l1_(l1ll1l11ll_l1_)+l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩ᯷")+str(l1l1ll1l1l_l1_)+l1l1ll_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ᯸")
	l1l1lll1ll_l1_ = l1l1ll_l1_ (u"ࠧࠡࠪࠪ᯹")+l1ll1ll1l1_l1_(l1ll1l11l1_l1_)+l1l1ll_l1_ (u"ࠨࠢ࠰ࠤࠬ᯺")+str(l1l1ll1ll1_l1_)+l1l1ll_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ᯻")
	l1l1llll1l_l1_ = l1l1ll_l1_ (u"ࠪࠤ࠭࠭᯼")+l1ll1ll1l1_l1_(l1ll1l111l_l1_)+l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨ᯽")+str(l1ll11l1l1_l1_)+l1l1ll_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭᯾")
	size = l1l1ll1l11_l1_+l1ll11lll1_l1_+l1ll11ll1l_l1_+l1ll1l11ll_l1_+l1ll1l11l1_l1_+l1ll1l111l_l1_
	count = l1l1lll1l1_l1_+l1l1ll1lll_l1_+l1l1lll111_l1_+l1l1ll1l1l_l1_+l1l1ll1ll1_l1_+l1ll11l1l1_l1_
	text = l1l1ll_l1_ (u"࠭ࠠࠩࠩ᯿")+l1ll1ll1l1_l1_(size)+l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫᰀ")+str(count)+l1l1ll_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᰁ")
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰂ"),menu_name+l1l1ll_l1_ (u"ࠪษ฾฽วยࠢิาฺฯࠠใำสลฮ่ࠦไฬสฬฮ࠭ᰃ"),l1l1ll_l1_ (u"ࠫࠬᰄ"),758)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰅ"),menu_name+l1l1ll_l1_ (u"࠭ๅิฯࠣห้าๅ๋฻ࠪᰆ")+text,l1l1ll_l1_ (u"ࠧࠨᰇ"),757)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰈ"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᰉ"),l1l1ll_l1_ (u"ࠪࠫᰊ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᰋ"),menu_name+l1l1ll_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬᰌ")+text1,l1l1ll_l1_ (u"࠭ࠧᰍ"),751)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰎ"),menu_name+l1l1ll_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡩࡸ࡯ࡱࡤࡲࡼࠬᰏ")+text2,l1l1ll_l1_ (u"ࠩࠪᰐ"),752)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᰑ"),menu_name+l1l1ll_l1_ (u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠫᰒ")+text3,l1l1ll_l1_ (u"ࠬ࠭ᰓ"),753)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᰔ"),menu_name+l1l1ll_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡰࡴ࡭ࡧࡦࡴࠪᰕ")+l1ll1l1111_l1_,l1l1ll_l1_ (u"ࠨࠩᰖ"),754)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰗ"),menu_name+l1l1ll_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦ࡬ࡰࡩࠪᰘ")+l1l1lll1ll_l1_,l1l1ll_l1_ (u"ࠫࠬᰙ"),755)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰚ"),menu_name+l1l1ll_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡤࡲࡷ࠭ᰛ")+l1l1llll1l_l1_,l1l1ll_l1_ (u"ࠧࠨᰜ"),756)
	settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᰝ"),l1l1ll_l1_ (u"ࠩࠪᰞ"))
	return
def l1l1lllll1_l1_():
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࠫᰟ"),l1l1ll_l1_ (u"ࠫࠬᰠ"),l1l1ll_l1_ (u"ࠬ࠭ᰡ"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᰢ"),l1l1ll_l1_ (u"ࠧๅๅํࠤ๏฿ๅๅࠢส่ฯ์ุ๋ใࠣ฽๋ีใࠡ࠰࠱ࠤอืๆศ็ฯࠤ฾๋วะࠢหัฬาษࠡว็ํࠥหูุษฤࠤึิีสࠢส่็ืวยหࠣ์ฬ๊ใหษหอ๊ࠥไๆๆไหฯ่ࠦศๆ่ะ้ีวหࠢส่ฯ๐ࠠิ๊ไࠤ๏๋ำฮ้สࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ฾฽วย๊ࠢิ์ࠦวๅำัูฮࠦวๅฤ้ࠤฤࠧࠧᰣ"))
	if yes==-1: return
	if yes:
		l1l1ll1111_l1_ = True
		import subprocess
		try: subprocess.Popen(l1l1ll_l1_ (u"ࠨࡵࡸࠫᰤ"))
		except: l1l1ll1111_l1_ = False
		if l1l1ll1111_l1_:
			l1ll1111ll_l1_ = l1l1l1l11l_l1_+l1l1ll_l1_ (u"ࠩࠣࠫᰥ")+l1l1l1l1l1_l1_+l1l1ll_l1_ (u"ࠪࠤࠬᰦ")+l1ll111ll1_l1_+l1l1ll_l1_ (u"ࠫࠥ࠭ᰧ")+l1l1l1ll11_l1_+l1l1ll_l1_ (u"ࠬࠦࠧᰨ")+l1l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠠࠨᰩ")+l1l1l1lll1_l1_
			proc = subprocess.Popen(l1l1ll_l1_ (u"ࠧࡴࡷࠣ࠱ࡨࠦࠢࡤࡪࡰࡳࡩࠦ࠭ࡓࠢ࠳࠻࠼࠽ࠠࠨᰪ")+l1ll1111ll_l1_+l1l1ll_l1_ (u"ࠨࠤࠪᰫ"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			#error = proc.stderr.read().decode()
			#output = proc.stdout.read().decode()
			DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪᰬ"),l1l1ll_l1_ (u"ࠪࠫᰭ"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᰮ"),l1l1ll_l1_ (u"ࠬ์ฬฮฬࠣ฽๊๊๊สࠢศ฽฼อมࠡษ็ีำ฻ษࠨᰯ"))
			settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪᰰ"),l1l1ll_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪᰱ"))
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬᰲ"))
		else: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪᰳ"),l1l1ll_l1_ (u"ࠪࠫᰴ"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᰵ"),l1l1ll_l1_ (u"ࠬ฿ๅๅ์ฬࠤส฿ืศรࠣีำ฻ษࠡษ็ๆึอมส๋ࠢห้้สศสฬࠤฯำสศฮࠣฬึ์วๆฮࠣࠤࡷࡵ࡯ࡵࠢࠣวํࠦࠠࡴࡷࡳࡩࡷࡻࡳࡦࡴࠣࠤศ๎ࠠࠡࡵࡸࠤࠥ๎ฬ่ษี็๊ࠥวࠡ์๋ะิࠦแ๋้๋ࠣีอࠠศๆหี๋อๅอࠢ࠱࠲ࠥษ่ࠡๅ๋ำ๏ฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠬᰶ"))
	return
def l1ll1ll1l1_l1_(size):
	for x in [l1l1ll_l1_ (u"࠭ࡂࠨ᰷"),l1l1ll_l1_ (u"ࠧࡌࡄࠪ᰸"),l1l1ll_l1_ (u"ࠨࡏࡅࠫ᰹"),l1l1ll_l1_ (u"ࠩࡊࡆࠬ᰺"),l1l1ll_l1_ (u"ࠪࡘࡇ࠭᰻")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l1ll_l1_ (u"ࠦࠪ࠹࠮࠲ࡨࠣࠩࡸࠨ᰼")%(size,x)
	return text
def l1ll11l111_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1l1l1l1ll_l1_(l1ll1l1ll1_l1_=l1l1ll_l1_ (u"ࠬ࠴ࠧ᰽")):
	global l1ll111l1l_l1_,l1ll1l1l1l_l1_
	l1ll111l1l_l1_,l1ll1l1l1l_l1_ = 0,0
	def l1ll1lll11_l1_(l1ll1l1ll1_l1_):
		global l1ll111l1l_l1_,l1ll1l1l1l_l1_
		if os.path.exists(l1ll1l1ll1_l1_):
			if 0 and l1l1ll_l1_ (u"࠭ࡳࡤࡣࡱࡨ࡮ࡸࠧ᰾") in dir(os):
				# l1l1lll11l_l1_ l1ll11l1ll_l1_ l1l1ll_l1_ (u"ࠧࡰࡵ࠱ࡷࡨࡧ࡮ࡥ࡫ࡵࠫ᰿") method (new in version 3.5)
				for l1l1l11lll_l1_ in os.scandir(l1ll1l1ll1_l1_):
					if l1l1l11lll_l1_.l1ll1l1lll_l1_(follow_symlinks=False):
						l1ll1lll11_l1_(l1l1l11lll_l1_.path)
					elif l1l1l11lll_l1_.l1l1llll11_l1_(follow_symlinks=False):
						l1ll111l1l_l1_ += l1l1l11lll_l1_.stat().st_size
						l1ll1l1l1l_l1_ += 1
			else:
				# l1l1lll11l_l1_ l1l11l11l_l1_, l1l1llllll_l1_ l1l1l1llll_l1_ l1l1ll_l1_ (u"ࠨࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶࠬ᱀") method
				for l1l1l11lll_l1_ in os.listdir(l1ll1l1ll1_l1_):
					l1l1l11l1l_l1_ = os.path.abspath(os.path.join(l1ll1l1ll1_l1_,l1l1l11lll_l1_))
					if os.path.isdir(l1l1l11l1l_l1_):
						l1ll1lll11_l1_(l1l1l11l1l_l1_)
					elif os.path.isfile(l1l1l11l1l_l1_):
						size,count = l1ll11l111_l1_(l1l1l11l1l_l1_)
						l1ll111l1l_l1_ += size
						l1ll1l1l1l_l1_ += count
		return
	try: l1ll1lll11_l1_(l1ll1l1ll1_l1_)
	except: pass
	return l1ll111l1l_l1_,l1ll1l1l1l_l1_
def l1ll1ll11l_l1_(l1ll1ll1ll_l1_,l1ll11ll11_l1_,showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࠪ᱁"),l1l1ll_l1_ (u"ࠪࠫ᱂"),l1l1ll_l1_ (u"ࠫࠬ᱃"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᱄"),l1ll1ll1ll_l1_+l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ᱅")+l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤ࡛ࠧ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᱆"))
		if yes!=1: return
	error = False
	if os.path.exists(l1ll1ll1ll_l1_):
		#os.chmod(l1ll1ll1ll_l1_,0o777)
		for root,dirs,files in os.walk(l1ll1ll1ll_l1_,topdown=False):
			for file in files:
				filepath = os.path.join(root,file)
				#os.chmod(filepath,0o777)
				#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ᱇"),filepath)
				try: os.remove(filepath)
				except Exception as err:
					if showDialogs and not error: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ᱈"),l1l1ll_l1_ (u"ࠪࠫ᱉"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᱊"),str(err))
					error = True
			if l1ll11ll11_l1_:
				for dir in dirs:
					l1l1ll11ll_l1_ = os.path.join(root,dir)
					#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭᱋"),l1l1ll11ll_l1_)
					os.rmdir(l1l1ll11ll_l1_)
		if l1ll11ll11_l1_: os.rmdir(root)
	if showDialogs and not error:
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ᱌"),l1l1ll_l1_ (u"ࠧࠨᱍ"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᱎ"),l1l1ll_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᱏ"))
		settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᱐"),l1l1ll_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᱑"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ᱒"))
	return
def l1ll1l1l11_l1_(l1ll111l11_l1_,showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࠧ᱓"),l1l1ll_l1_ (u"ࠧࠨ᱔"),l1l1ll_l1_ (u"ࠨࠩ᱕"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᱖"),l1ll111l11_l1_+l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ᱗")+l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้้็ࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᱘"))
		if yes!=1: return
	error = False
	if os.path.exists(l1ll111l11_l1_):
		try: os.remove(l1ll111l11_l1_)
		except Exception as err:
			if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭᱙"),l1l1ll_l1_ (u"࠭ࠧᱚ"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱛ"),str(err))
			error = True
	if showDialogs and not error:
		DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩᱜ"),l1l1ll_l1_ (u"ࠩࠪᱝ"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᱞ"),l1l1ll_l1_ (u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬᱟ"))
		settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩᱠ"),l1l1ll_l1_ (u"࠭ࡓࡐࡏࡈࡘࡍࡏࡎࡈࠩᱡ"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫᱢ"))
	return
def l1l1l11ll1_l1_(showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࠩᱣ"),l1l1ll_l1_ (u"ࠩࠪᱤ"),l1l1ll_l1_ (u"ࠪࠫᱥ"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᱦ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠬᱧ")+l1l1ll_l1_ (u"࠭࡜࡯ࠩᱨ")+l1l1ll_l1_ (u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ᱩ")+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫᱪ")+l1l1ll_l1_ (u"ࠩยࠥࠦ࠭ᱫ")+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᱬ"))
		if yes!=1: return
	l1ll1ll11l_l1_(l1ll11l11l_l1_,True,False)
	l1ll1ll11l_l1_(l1l1l1l111_l1_,True,False)
	l1ll1ll11l_l1_(l1ll111lll_l1_,False,False)
	l1l1ll111l_l1_(l1ll11llll_l1_,False)
	if showDialogs:
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬᱭ"),l1l1ll_l1_ (u"ࠬ࠭ᱮ"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᱯ"),l1l1ll_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨᱰ"))
		settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᱱ"),l1l1ll_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᱲ"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᱳ"))
	return
def l1ll1111l1_l1_(showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࠬᱴ"),l1l1ll_l1_ (u"ࠬ࠭ᱵ"),l1l1ll_l1_ (u"࠭ࠧᱶ"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᱷ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อࠡ็็ๅฬะࠧᱸ")+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬᱹ")+l1l1ll_l1_ (u"ࠪࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠠ࠯࠰ࠣࡨࡷࡵࡰࡣࡱࡻࠤ࠳࠴ࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶࠤ࠳࠴ࠠ࡭ࡱࡪ࡫ࡪࡸࠠ࠯࠰ࠣࡰࡴ࡭ࠠ࠯࠰ࠣࡥࡳࡸࠧᱺ")+l1l1ll_l1_ (u"ࠫࡡࡴࠧᱻ")+l1l1ll_l1_ (u"ࠬࡅࠡࠢࠩᱼ")+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᱽ"))
		if yes!=1: return
	l1ll1ll11l_l1_(l1l1l1l11l_l1_,False,False)
	l1ll1ll11l_l1_(l1l1l1l1l1_l1_,False,False)
	l1ll1ll11l_l1_(l1ll111ll1_l1_,False,False)
	l1ll1ll11l_l1_(l1l1l1ll11_l1_,False,False)
	l1ll1ll11l_l1_(l1l1l1ll1l_l1_,False,False)
	l1ll1ll11l_l1_(l1l1l1lll1_l1_,False,False)
	if showDialogs:
		DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ᱾"),l1l1ll_l1_ (u"ࠨࠩ᱿"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᲀ"),l1l1ll_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫᲁ"))
		settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨᲂ"),l1l1ll_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨᲃ"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪᲄ"))
	return
def l1l1ll111l_l1_(dbfile,showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࠨᲅ"),l1l1ll_l1_ (u"ࠨࠩᲆ"),l1l1ll_l1_ (u"ࠩࠪᲇ"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᲈ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ๊ำส้์สฮ๋ࠥไโุࠢ์ึࠦวๅฮ็ำࠥลࠡࠢࠩᲉ")+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲊ"))
		if yes!=1: return
	conn = sqlite3.connect(dbfile)
	conn.text_factory = str
	cc = conn.cursor()
	cc.execute(l1l1ll_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡵࡧࡴࡩ࠽ࠪ᲋"))
	cc.execute(l1l1ll_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡹࡩࡻࡧࡶ࠿ࠬ᲌"))
	cc.execute(l1l1ll_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡴࡦࡺࡷࡹࡷ࡫࠻ࠨ᲍"))
	conn.commit()
	cc.execute(l1l1ll_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪ᲎"))
	conn.close()
	if showDialogs:
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ᲏"),l1l1ll_l1_ (u"ࠫࠬᲐ"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᲑ"),l1l1ll_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧᲒ"))
		settings.setSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫᲓ"),l1l1ll_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫᲔ"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭Ვ"))
	return
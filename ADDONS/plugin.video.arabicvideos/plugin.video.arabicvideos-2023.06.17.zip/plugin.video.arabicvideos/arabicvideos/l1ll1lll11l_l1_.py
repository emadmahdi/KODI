# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ⤇")
headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⤈"):l1l1ll_l1_ (u"ࠬ࠭⤉")}
menu_name = l1l1ll_l1_ (u"࠭࡟ࡇࡊ࠴ࡣࠬ⤊")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧอ๊สสืࠦวๅล๋ื่อัࠨ⤋"),l1l1ll_l1_ (u"ࠨษ็้ึอฬฺษอࠫ⤌"),l1l1ll_l1_ (u"ࠩࡺࡻࡪ࠭⤍")]
def MAIN(mode,url,text):
	if   mode==570: results = MENU()
	elif mode==571: results = l11l1l_l1_(url,text)
	elif mode==572: results = PLAY(url)
	elif mode==573: results = l1ll1lll111_l1_(url,text)
	#elif mode==574: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ⤎")+text)
	#elif mode==575: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ⤏")+text)
	elif mode==579: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#headers2 = {l1l1ll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭⤐"):l11ll1_l1_,l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⤑"):l1l11lll1_l1_(False)}
	l11ll1_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ⤒"))
	if not l11ll1_l1_: l11ll1_l1_ = l1l1l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⤓"),l11ll1_l1_,l1l1ll_l1_ (u"ࠩࠪ⤔"),l1l1ll_l1_ (u"ࠪࠫ⤕"),l1l1ll_l1_ (u"ࠫࠬ⤖"),False,l1l1ll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⤗"))
	if not response.succeeded:
		newserver = GET_HOSTNAME_FROM_GOOGLE(l1l1ll_l1_ (u"࠭แศื็࠯ส฿ไศ่ํࠫ⤘"))
		if newserver and newserver!=l11ll1_l1_:
			l11ll1_l1_ = newserver
			settings.setSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪ⤙"),newserver)
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⤚"),l11ll1_l1_,l1l1ll_l1_ (u"ࠩࠪ⤛"),l1l1ll_l1_ (u"ࠪࠫ⤜"),l1l1ll_l1_ (u"ࠫࠬ⤝"),l1l1ll_l1_ (u"ࠬ࠭⤞"),l1l1ll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ⤟"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤠"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⤡"),l11ll1_l1_,579,l1l1ll_l1_ (u"ࠩࠪ⤢"),l1l1ll_l1_ (u"ࠪࠫ⤣"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⤤"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤥"),menu_name+l1l1ll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ⤦"),l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ⤧"),574)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤨"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⤩"),l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ⤪"),575)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⤫"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⤬"),l1l1ll_l1_ (u"࠭ࠧ⤭"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤮"),menu_name+l1l1ll_l1_ (u"ࠨษ็้๊๐าสࠩ⤯"),l11ll1_l1_,571,l1l1ll_l1_ (u"ࠩࠪ⤰"),l1l1ll_l1_ (u"ࠪࠫ⤱"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⤲"))
	items = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠳ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⤳"),html,re.DOTALL)
	for title,link in items:
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤴"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⤵")+menu_name+title,link,571,l1l1ll_l1_ (u"ࠨࠩ⤶"),l1l1ll_l1_ (u"ࠩࠪ⤷"),l1l1ll_l1_ (u"ࠪࡨࡪࡺࡡࡪ࡮ࡶ࠵ࠬ⤸"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡳࡥ࡯ࡷ࠰ࡴࡷ࡯࡭ࡢࡴࡼࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⤹"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1llll1ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂ࡬ࡪࠢࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭⤺"),block,re.DOTALL)
		l1ll1ll1l1l_l1_ = [l1l1ll_l1_ (u"࠭ࠧ⤻"),l1l1ll_l1_ (u"ࠧฤใ็ห๊ࡀࠠࠨ⤼"),l1l1ll_l1_ (u"ࠨ็ึุ่๊วห࠼ࠣࠫ⤽"),l1l1ll_l1_ (u"ࠩหีฬ๋ฬ࠻ࠢࠪ⤾"),l1l1ll_l1_ (u"ࠪฦุ๐่๋࠼ࠣࠫ⤿"),l1l1ll_l1_ (u"ࠫศ์ๅ๋࠼ࠣࠫ⥀")]
		ii = 0
		for l1lll1l11l_l1_ in l1llll1ll1_l1_:
			if ii>0: addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⥁"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⥂"),l1l1ll_l1_ (u"ࠧࠨ⥃"),9999)
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⥄"),l1lll1l11l_l1_,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠩࠦࠫ⥅"): continue
				if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⥆") not in link: link = l11ll1_l1_+link
				if title==l1l1ll_l1_ (u"ࠫࠬ⥇"): continue
				if any(value in title.lower() for value in l1ll11_l1_): continue
				title = l1ll1ll1l1l_l1_[ii]+title
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥈"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⥉")+menu_name+title,link,571,l1l1ll_l1_ (u"ࠧࠨ⥊"),l1l1ll_l1_ (u"ࠨࠩ⥋"),l1l1ll_l1_ (u"ࠩࡧࡩࡹࡧࡩ࡭ࡵ࠵ࠫ⥌"))
			ii += 1
	return
def l11l1l_l1_(url,type=l1l1ll_l1_ (u"ࠪࠫ⥍")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ⥎"),l1l1ll_l1_ (u"ࠬ࠭⥏"),type,url)
	#headers2 = {l1l1ll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ⥐"):url,l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⥑"):l1l11lll1_l1_()}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⥒"),url,l1l1ll_l1_ (u"ࠩࠪ⥓"),l1l1ll_l1_ (u"ࠪࠫ⥔"),l1l1ll_l1_ (u"ࠫࠬ⥕"),l1l1ll_l1_ (u"ࠬ࠭⥖"),l1l1ll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⥗"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩ࠶ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⥘"),html,re.DOTALL)
	if type==l1l1ll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⥙"):
		l1lll11_l1_ = [html.replace(l1l1ll_l1_ (u"ࠩ࡟ࡠ࠴࠭⥚"),l1l1ll_l1_ (u"ࠪ࠳ࠬ⥛")).replace(l1l1ll_l1_ (u"ࠫࡡࡢࠢࠨ⥜"),l1l1ll_l1_ (u"ࠬࠨࠧ⥝"))]
	elif type==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠲ࠩ⥞"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡪࡲࡱࡪ࡙࡬ࡪࡦࡨࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⥟"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⥠"),block,re.DOTALL)
		l111llll1_l1_,l1ll_l1_,titles = zip(*items)
		items = zip(l1ll_l1_,l111llll1_l1_,titles)
	elif type==l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠶ࠬ⥡"):
		title,block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⥢"),block,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠷࠭⥣") and len(l1ll1l1_l1_)>1:
		title = l1ll1l1_l1_[0][0]
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⥤"),menu_name+title,url,571,l1l1ll_l1_ (u"࠭ࠧ⥥"),l1l1ll_l1_ (u"ࠧࠨ⥦"),l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦ࠵ࠫ⥧"))
		title = l1ll1l1_l1_[1][0]
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⥨"),menu_name+title,url,571,l1l1ll_l1_ (u"ࠪࠫ⥩"),l1l1ll_l1_ (u"ࠫࠬ⥪"),l1l1ll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠹ࠧ⥫"))
		return
	else:
		title,block = l1ll1l1_l1_[-1]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡩ࠳ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⥬"),block,re.DOTALL)
	#l111l_l1_ = [l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠧ⥭"),l1l1ll_l1_ (u"ࠨใํ่๊࠭⥮"),l1l1ll_l1_ (u"ࠩส฾๋๐ษࠨ⥯"),l1l1ll_l1_ (u"ࠪ็้๐ศࠨ⥰"),l1l1ll_l1_ (u"ࠫฬ฿ไศ่ࠪ⥱"),l1l1ll_l1_ (u"ࠬํฯศใࠪ⥲"),l1l1ll_l1_ (u"࠭ๅษษิหฮ࠭⥳"),l1l1ll_l1_ (u"ฺࠧำูࠫ⥴"),l1l1ll_l1_ (u"ࠨ็๊ีัอๆࠨ⥵"),l1l1ll_l1_ (u"ࠩส่อ๎ๅࠨ⥶"),l1l1ll_l1_ (u"ุ้ࠪือ๋หࠪ⥷")]
	l1l1_l1_ = []
	for link,img,title in items:
		if any(value in title.lower() for value in l1ll11_l1_): continue
		img = escapeUNICODE(img)
		img = img.split(l1l1ll_l1_ (u"ࠫࡄࡸࡥࡴ࡫ࡽࡩࡂ࠭⥸"))[0]
		title = unescapeHTML(title)
		#title = escapeUNICODE(title)
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨ⥹"),title,re.DOTALL)
		if l1l1ll_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷ࠴࠭⥺") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥻"),menu_name+title,link,571,img)
		#elif any(value in title for value in l111l_l1_):
		#	addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⥼"),menu_name+title,link,572,img)
		elif l11111_l1_ and type==l1l1ll_l1_ (u"ࠩࠪ⥽"):
			title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⥾")+l11111_l1_[0][0]
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ⠙ࠧ⥿"))
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦀"),menu_name+title,link,573,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⦁") in link or l1l1ll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ⦂") in link or l1l1ll_l1_ (u"ࠨࡪ࡬ࡲࡩ࡯࠯ࠨ⦃") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⦄"),menu_name+title,link,572,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦅"),menu_name+title,link,573,img)
	if type==l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⦆"):
		l1ll1ll11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ⦇"),block,re.DOTALL)
		if l1ll1ll11ll_l1_:
			count = l1ll1ll11ll_l1_[0]
			link = url+l1l1ll_l1_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ⦈")+count
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦉"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦรฯำ์ࠫ⦊"),link,571,l1l1ll_l1_ (u"ࠩࠪ⦋"),l1l1ll_l1_ (u"ࠪࠫ⦌"),l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⦍"))
	elif l1l1ll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠭⦎") in type:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡣ࡭ࡣࡶࡷࡂ࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠢ⦏"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⦐"),block,re.DOTALL)
			for link,title in items:
				title = l1l1ll_l1_ (u"ࠨืไัฮࠦࠧ⦑")+unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⦒"),menu_name+title,link,571,l1l1ll_l1_ (u"ࠪࠫ⦓"),l1l1ll_l1_ (u"ࠫࠬ⦔"),l1l1ll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠺ࠧ⦕"))
	return
def l1ll1lll111_l1_(url,type=l1l1ll_l1_ (u"࠭ࠧ⦖")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ⦗"),url,l1l1ll_l1_ (u"ࠨࠩ⦘"),l1l1ll_l1_ (u"ࠩࠪ⦙"),l1l1ll_l1_ (u"ࠪࠫ⦚"),l1l1ll_l1_ (u"ࠫࠬ⦛"),l1l1ll_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⦜"))
	html = response.content
	#link = l1l1ll_l1_ (u"࠭ࠧ⦝")
	l11l11_l1_ = False
	if not type:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨ⦞"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࠦ࠽ࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࠠࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⦟"),block,re.DOTALL)
			if len(items)>1:
				l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭⦠"))
				l11l11_l1_ = True
				for link,img,name,title in items:
					name = unescapeHTML(name)
					if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⦡") not in link: link = l11ll1_l1_+link
					title = name+l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨ⦢")+title
					addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦣"),menu_name+title,link,573,img,l1l1ll_l1_ (u"࠭ࠧ⦤"),l1l1ll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⦥"))
	if type==l1l1ll_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⦦") or not l11l11_l1_:
		image = re.findall(l1l1ll_l1_ (u"ࠩࠥࡴࡴࡹࡴࡦࡴࡌࡱ࡬ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⦧"),html,re.DOTALL)
		if image: img = image[0]
		else: img = l1l1ll_l1_ (u"ࠪࠫ⦨")
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡫ࡰࡂ࡮࡯ࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⦩"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⦪"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ⦫"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⦬"),menu_name+title,link,572,img)
	#if not link: l11l1l_l1_(url)
	return
def PLAY(url):
	l111ll1_l1_,l1ll1ll1lll_l1_,l1ll1lll1l1_l1_ = [],[],[]
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⦭"),url,l1l1ll_l1_ (u"ࠩࠪ⦮"),l1l1ll_l1_ (u"ࠪࠫ⦯"),l1l1ll_l1_ (u"ࠫࠬ⦰"),l1l1ll_l1_ (u"ࠬ࠭⦱"),l1l1ll_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⦲"))
	html = response.content
	l1ll1ll1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧๆีอ์๎ࠦวๅ็ืห์ีษ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ⦳"),html,re.DOTALL)
	if l1ll1ll1l11_l1_:
		l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷࡥ࡬ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⦴"),html,re.DOTALL)
		if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	# l1l1l1l11_l1_ link
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡺ࡮ࡪࡥࡰࡔࡲࡻࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⦵"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⦶"),block,re.DOTALL)
		for link in items:
			link = link.split(l1l1ll_l1_ (u"ࠫࠫ࡯࡭ࡨ࠿ࠪ⦷"))[0]
			l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⦸"))
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡵࡴࡨࡥࡲࡎࡥࡢࡦࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⦹"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠢࡩࡴࡨࡪࠥࡃࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ⦺"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l1l1ll_l1_ (u"ࠨࠨ࡬ࡱ࡬ࡃࠧ⦻"))[0]
			name = name.strip(l1l1ll_l1_ (u"ࠩࠣࠫ⦼"))
			l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⦽")+name+l1l1ll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⦾"))
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡌࡪࡰ࡮ࡷ࠭࠴ࠪࡀࠫࡥࡰࡦࡩ࡫ࡸ࡫ࡱࡨࡴࡽࠧ⦿"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ⧀"),block,re.DOTALL)
		for link,name in items:
			link = link.split(l1l1ll_l1_ (u"ࠧࠧ࡫ࡰ࡫ࡂ࠭⧁"))[0]
			l111ll1_l1_.append(link+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⧂")+name+l1l1ll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⧃"))
	for l1ll1ll1ll1_l1_ in l111ll1_l1_:
		link,name = l1ll1ll1ll1_l1_.split(l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࠪ⧄"))
		if link not in l1ll1ll1lll_l1_:
			l1ll1ll1lll_l1_.append(link)
			l1ll1lll1l1_l1_.append(l1ll1ll1ll1_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่๊์วิสࠪ⧅"), l1ll1lll1l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll1lll1l1_l1_,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⧆"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧ⧇"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨ⧈"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪ⧉"),l1l1ll_l1_ (u"ࠩ࠮ࠫ⧊"))
	l11ll1_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭⧋"))
	if not l11ll1_l1_: l11ll1_l1_ = l1l1l1_l1_
	url = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⧌")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠻ࠧ⧍"))
	return
l1l1ll_l1_ (u"ࠨࠢࠣࠏࠍࡨࡪ࡬ࠠࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠮ࡵࡳ࡮࠼࠰࡫࡯࡬ࡵࡧࡵ࠭࠿ࠓࠊࠊ࡫ࡩࠤࠬࡅ࠿ࠨࠢ࡬ࡲࠥࡻࡲ࡭࠻࠽ࠤࡺࡸ࡬ࠡ࠿ࠣࡹࡷࡲ࠹࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧࠪ࡝࠳ࡡࠒࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡵࡳ࡮ࠣࡁࠥࡻࡲ࡭࠻ࠐࠎࠎࠩࡨࡦࡣࡧࡩࡷࡹ࠲ࠡ࠿ࠣࡿࠬࡘࡥࡧࡧࡵࡩࡷ࠭࠺ࡶࡴ࡯࠽࠱࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࠬ࠭ࡽࠎࠌࠌࡪ࡮ࡲࡴࡦࡴࠣࡁࠥ࡬ࡩ࡭ࡶࡨࡶ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ࠯ࠫࠬ࠯ࠍࠋࠋࡷࡽࡵ࡫ࠬࡧ࡫࡯ࡸࡪࡸࠠ࠾ࠢࡩ࡭ࡱࡺࡥࡳ࠰ࡶࡴࡱ࡯ࡴࠩࠩࡢࡣࡤ࠭ࠬ࠲ࠫࠐࠎࠎ࡯ࡦࠡࡨ࡬ࡰࡹ࡫ࡲ࠾࠿ࠪࠫ࠿ࠦࡦࡪ࡮ࡷࡩࡷࡥ࡯ࡱࡶ࡬ࡳࡳࡹࠬࡧ࡫࡯ࡸࡪࡸ࡟ࡷࡣ࡯ࡹࡪࡹࠠ࠾ࠢࠪࠫ࠱࠭ࠧࠎࠌࠌࡩࡱࡹࡥ࠻ࠢࡩ࡭ࡱࡺࡥࡳࡡࡲࡴࡹ࡯࡯࡯ࡵ࠯ࡪ࡮ࡲࡴࡦࡴࡢࡺࡦࡲࡵࡦࡵࠣࡁࠥ࡬ࡩ࡭ࡶࡨࡶ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࡠࠩࠬࠑࠏࠏࡩࡧࠢࡷࡽࡵ࡫࠽࠾ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭࠺ࠎࠌࠌࠍ࡮࡬ࠠࡢ࡮࡯ࡣࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡠ࡮࡬ࡷࡹࡡ࠰࡞࠭ࠪࡁࡂ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡧ࡫࡯ࡸࡪࡸ࡟ࡰࡲࡷ࡭ࡴࡴࡳ࠻ࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡂࠦࡡ࡭࡮ࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࡟࡭࡫ࡶࡸࡠ࠶࡝ࠎࠌࠌࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࠪࡤࡰࡱࡥࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࡢࡰ࡮ࡹࡴ࡜࠲࠽࠱࠶ࡣࠩࠪ࠼ࠐࠎࠎࠏࠉࡪࡨࠣࡥࡱࡲ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࡣࡱ࡯ࡳࡵ࡝࡬ࡡ࠰࠭࠽࠾ࠩࠣ࡭ࡳࠦࡦࡪ࡮ࡷࡩࡷࡥ࡯ࡱࡶ࡬ࡳࡳࡹ࠺ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡧ࡬࡭ࡡࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸࡥ࡬ࡪࡵࡷ࡟࡮࠱࠱࡞ࠏࠍࠍࠎࡴࡥࡸࡡࡲࡴࡹ࡯࡯࡯ࡵࠣࡁࠥ࡬ࡩ࡭ࡶࡨࡶࡤࡵࡰࡵ࡫ࡲࡲࡸ࠱ࠧࠧࠨࠪ࠯ࡨࡧࡴࡦࡩࡲࡶࡾ࠱ࠧ࠾࠿࠳ࠫࠒࠐࠉࠊࡰࡨࡻࡤࡼࡡ࡭ࡷࡨࡷࠥࡃࠠࡧ࡫࡯ࡸࡪࡸ࡟ࡷࡣ࡯ࡹࡪࡹࠫࠨࠨࠩࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠫࠨ࠿ࡀ࠴ࠬࠓࠊࠊࠋࡱࡩࡼࡥࡦࡪ࡮ࡷࡩࡷࠦ࠽ࠡࡰࡨࡻࡤࡵࡰࡵ࡫ࡲࡲࡸ࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠦࠧࠩࠬ࠯ࠬࡥ࡟ࡠࠩ࠮ࡲࡪࡽ࡟ࡷࡣ࡯ࡹࡪࡹ࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠧࠨࠪ࠭ࠒࠐࠉࠊࡥ࡯ࡩࡦࡴ࡟ࡧ࡫࡯ࡸࡪࡸࠠ࠾ࠢࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠨࡧ࡫࡯ࡸࡪࡸ࡟ࡷࡣ࡯ࡹࡪࡹࠬࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ࠮ࠓࠊࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠱ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭ࠫࡤ࡮ࡨࡥࡳࡥࡦࡪ࡮ࡷࡩࡷࠓࠊࠊࡧ࡯࡭࡫ࠦࡴࡺࡲࡨࡁࡂ࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ࠻ࠏࠍࠍࠎ࡬ࡩ࡭ࡶࡨࡶࡤࡹࡨࡰࡹࠣࡁࠥࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠫࡪ࡮ࡲࡴࡦࡴࡢࡳࡵࡺࡩࡰࡰࡶ࠰ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧࠪࠏࠍࠍࠎ࡬ࡩ࡭ࡶࡨࡶࡤࡹࡨࡰࡹࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡦࡪ࡮ࡷࡩࡷࡥࡳࡩࡱࡺ࠭ࠒࠐࠉࠊ࡫ࡩࠤ࡫࡯࡬ࡵࡧࡵࡣࡻࡧ࡬ࡶࡧࡶࠥࡂ࠭ࠧ࠻ࠢࡩ࡭ࡱࡺࡥࡳࡡࡹࡥࡱࡻࡥࡴࠢࡀࠤࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠪࡩ࡭ࡱࡺࡥࡳࡡࡹࡥࡱࡻࡥࡴ࠮ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ࠩࠎࠌࠌࠍ࡮࡬ࠠࡧ࡫࡯ࡸࡪࡸ࡟ࡷࡣ࡯ࡹࡪࡹ࠽࠾ࠩࠪ࠾ࠥࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭ࠏࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬ࠬࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ࠭ࡩ࡭ࡱࡺࡥࡳࡡࡹࡥࡱࡻࡥࡴࠏࠍࠍࠎࡻࡲ࡭࠶ࠣࡁࠥࡖࡒࡆࡒࡄࡖࡊࡥࡆࡊࡎࡗࡉࡗࡥࡆࡊࡐࡄࡐࡤ࡛ࡒࡍࠪࡸࡶࡱ࠸ࠬࡶࡴ࡯࠽࠮ࠓࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ࠯ࡹࡷࡲ࠴࠭࠷࠺࠵࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ࠩࠎࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨࠢ࡞࡟ࠥࠦࠠࠨ࠭ࡩ࡭ࡱࡺࡥࡳࡡࡶ࡬ࡴࡽࠫࠨࠢࠣࠤࡢࡣࠧ࠭ࡷࡵࡰ࠹࠲࠵࠸࠳࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ࠮ࠓࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨ࡮࡬ࡲࡰ࠭ࠬࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠮ࠪࠫ࠱࠿࠹࠺࠻ࠬࠑࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡌࡁࡔࡇࡏࡌࡉ࠷࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ࠭ࠒࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠐࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡜ࠣࠩ࠯ࠫࠧ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࠼ࡇࡃࡖࡉࡑࡎࡄ࠲࠯࠰ࡪ࡮ࡲࡴࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠏࠍࠍ࡮࡬ࠠ࡯ࡱࡷࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡶࡪࡺࡵࡳࡰࠐࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠍࠋࠋࡶࡩࡱ࡫ࡣࡵࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡷࡥࡽࡵ࡮ࡰ࡯ࡼࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࡫࡯࡬ࡵࡧࡵࡦࡴࡾࠧ࠭ࡤ࡯ࡳࡨࡱࠫࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠐࠎࠎࡪࡩࡤࡶࠣࡁࠥࢁࡽࠎࠌࠌࡪࡴࡸࠠࡤࡣࡷࡩ࡬ࡵࡲࡺ࠴࠯ࡲࡦࡳࡥ࠭ࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡷࡪࡲࡥࡤࡶࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠑࠏࠏࠉ࡯ࡣࡰࡩࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨ࡯ࡣࡰࡩ࠮ࠓࠊࠊࠋ࡬ࡪࠥ࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨࠢ࡬ࡲࠥࡩࡡࡵࡧࡪࡳࡷࡿ࠲࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠑࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊ࡫ࡩࠤࠬࡃ࠽ࠨࠢࡱࡳࡹࠦࡩ࡯ࠢࡸࡶࡱ࠸࠺ࠡࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰࠒࠐࠉࠊ࡫ࡩࠤࡹࡿࡰࡦ࠿ࡀࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ࠼ࠐࠎࠎࠏࠉࡪࡨࠣࡧࡦࡺࡥࡨࡱࡵࡽࠦࡃࡣࡢࡶࡨ࡫ࡴࡸࡹ࠳࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠒࠐࠉࠊࠋࡨࡰ࡮࡬ࠠ࡭ࡧࡱࠬ࡮ࡺࡥ࡮ࡵࠬࡀࡂ࠷࠺ࠎࠌࠌࠍࠎࠏࡩࡧࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠶ࡂࡃࡡ࡭࡮ࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࡟࡭࡫ࡶࡸࡠ࠳࠱࡞࠼ࠣࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲ࠲ࠪࠏࠍࠍࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠭ࡻࡲ࡭࠴࠯ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ࠰ࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࠫࠐࠎࠎࠏࠉࠊࡴࡨࡸࡺࡸ࡮ࠎࠌࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠑࠏࠏࠉࠊࠋࡸࡶࡱ࠺ࠠ࠾ࠢࡓࡖࡊࡖࡁࡓࡇࡢࡊࡎࡒࡔࡆࡔࡢࡊࡎࡔࡁࡍࡡࡘࡖࡑ࠮ࡵࡳ࡮࠵࠰ࡺࡸ࡬࠺ࠫࠐࠎࠎࠏࠉࠊ࡫ࡩࠤࡨࡧࡴࡦࡩࡲࡶࡾ࠸࠽࠾ࡣ࡯ࡰࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࡡ࡯࡭ࡸࡺ࡛࠮࠳ࡠ࠾ࠒࠐࠉࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ะ๊๐ูࠨ࠮ࡸࡶࡱ࠺ࠬ࠶࠹࠴࠰ࠬ࠭ࠬࠨࠩ࠯ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ࠯ࠍࠋࠋࠌࠍࠎ࡫࡬ࡴࡧ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ะ๊๐ูࠨ࠮ࡸࡶࡱ࠸ࠬ࠶࠹࠷࠰ࠬ࠭ࠬࠨࠩ࠯ࡲࡪࡽ࡟ࡧ࡫࡯ࡸࡪࡸࠩࠎࠌࠌࠍࡪࡲࡩࡧࠢࡷࡽࡵ࡫࠽࠾ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ࠾ࠒࠐࠉࠊࠋࡱࡩࡼࡥ࡯ࡱࡶ࡬ࡳࡳࡹࠠ࠾ࠢࡩ࡭ࡱࡺࡥࡳࡡࡲࡴࡹ࡯࡯࡯ࡵ࠮ࠫࠫࠬࠧࠬࡥࡤࡸࡪ࡭࡯ࡳࡻ࠵࠯ࠬࡃ࠽࠱ࠩࠐࠎࠎࠏࠉ࡯ࡧࡺࡣࡻࡧ࡬ࡶࡧࡶࠤࡂࠦࡦࡪ࡮ࡷࡩࡷࡥࡶࡢ࡮ࡸࡩࡸ࠱ࠧࠧࠨࠪ࠯ࡨࡧࡴࡦࡩࡲࡶࡾ࠸ࠫࠨ࠿ࡀ࠴ࠬࠓࠊࠊࠋࠌࡲࡪࡽ࡟ࡧ࡫࡯ࡸࡪࡸࠠ࠾ࠢࡱࡩࡼࡥ࡯ࡱࡶ࡬ࡳࡳࡹࠫࠨࡡࡢࡣࠬ࠱࡮ࡦࡹࡢࡺࡦࡲࡵࡦࡵࠐࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡲࡦࡳࡥࠬࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ࠱ࡻࡲ࡭࠴࠯࠹࠼࠻ࠬࠨࠩ࠯ࠫࠬ࠲࡮ࡦࡹࡢࡪ࡮ࡲࡴࡦࡴ࠮ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠩࠎࠌࠌࠍࡩ࡯ࡣࡵ࡝ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠶ࡢࠦ࠽ࠡࡽࢀࠑࠏࠏࠉࡧࡱࡵࠤࡻࡧ࡬ࡶࡧ࠯ࡳࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠓࠊࠊࠋࠌࡲࡦࡳࡥࠡ࠿ࠣࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡲࡦࡳࡥࠪࠏࠍࠍࠎࠏ࡯ࡱࡶ࡬ࡳࡳࠦ࠽ࠡࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡱࡳࡸ࡮ࡵ࡮ࠪࠏࠍࠍࠎࠏࡩࡧࠢࡹࡥࡱࡻࡥ࠾࠿ࠪࡶࠬࠦ࡯ࡳࠢࡹࡥࡱࡻࡥ࠾࠿ࠪࡲࡨ࠳࠱࠸ࠩ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠓࠊࠊࠋࠌ࡭࡫ࠦࡡ࡯ࡻࠫࡺࡦࡲࡵࡦࠢ࡬ࡲࠥࡵࡰࡵ࡫ࡲࡲ࠳ࡲ࡯ࡸࡧࡵࠬ࠮ࠦࡦࡰࡴࠣࡺࡦࡲࡵࡦࠢ࡬ࡲࠥ࡯ࡧ࡯ࡱࡵࡩࡑࡏࡓࡕࠫ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠓࠊࠊࠋࠌ࡭࡫ࠦࠧࡩࡶࡷࡴࠬࠦࡩ࡯ࠢࡲࡴࡹ࡯࡯࡯࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠒࠐࠉࠊࠋ࡬ࡪࠥ࠭วๅๅ็ࠫࠥ࡯࡮ࠡࡱࡳࡸ࡮ࡵ࡮࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠑࠏࠏࠉࠊ࡫ࡩࠤࠬࡴ࠭ࡢࠩࠣ࡭ࡳࠦࡶࡢ࡮ࡸࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠎࠌࠌࠍࠎࠩࡩࡧࠢࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡠ࠭ࡲࠨ࠮ࠪࡲࡨ࠳࠱࠸ࠩ࠯ࠫࡹࡼ࠭࡮ࡣࠪࡡ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠎࠌࠌࠍࠎࠩࡩࡧࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠶ࡂࡃࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭࠺ࠡࡱࡳࡸ࡮ࡵ࡮ࠡ࠿ࠣࡺࡦࡲࡵࡦࠏࠍࠍࠎࠏࡩࡧࠢࡲࡴࡹ࡯࡯࡯࠿ࡀࠫࠬࡀࠠࡰࡲࡷ࡭ࡴࡴࠠ࠾ࠢࡹࡥࡱࡻࡥࠎࠌࠌࠍࠎࡺࡩࡵ࡮ࡨ࠵ࠥࡃࠠࡰࡲࡷ࡭ࡴࡴࠍࠋࠋࠌࠍࡳࡧ࡭ࡦ࠳ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ࠮ࡲࡴࡹ࡯࡯࡯࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠵࠿ࠦࡴࡪࡶ࡯ࡩ࠶ࠦ࠽ࠡࡰࡤࡱࡪ࠷࡛࠱࡟ࠐࠎࠎࠏࠉࡵ࡫ࡷࡰࡪ࠸ࠠ࠾ࠢࡱࡥࡲ࡫ࠫࠨ࠼ࠣࠫ࠰ࡺࡩࡵ࡮ࡨ࠵ࠒࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠴ࡠ࡟ࡻࡧ࡬ࡶࡧࡠࠤࡂࠦࡴࡪࡶ࡯ࡩ࠷ࠓࠊࠊࠋࠌࡲࡪࡽ࡟ࡰࡲࡷ࡭ࡴࡴࡳࠡ࠿ࠣࡪ࡮ࡲࡴࡦࡴࡢࡳࡵࡺࡩࡰࡰࡶ࠯ࠬࠬࠦࠨ࠭ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠶࠰࠭࠽࠾ࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠳ࠐࠎࠎࠏࠉ࡯ࡧࡺࡣࡻࡧ࡬ࡶࡧࡶࠤࡂࠦࡦࡪ࡮ࡷࡩࡷࡥࡶࡢ࡮ࡸࡩࡸ࠱ࠧࠧࠨࠪ࠯ࡨࡧࡴࡦࡩࡲࡶࡾ࠸ࠫࠨ࠿ࡀࠫ࠰ࡼࡡ࡭ࡷࡨࠑࠏࠏࠉࠊࡰࡨࡻࡤ࡬ࡩ࡭ࡶࡨࡶ࠷ࠦ࠽ࠡࡰࡨࡻࡤࡵࡰࡵ࡫ࡲࡲࡸ࠱ࠧࡠࡡࡢࠫ࠰ࡴࡥࡸࡡࡹࡥࡱࡻࡥࡴࠏࠍࠍࠎࠏࡩࡧࠢࡷࡽࡵ࡫࠽࠾ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ࠾ࠒࠐࠉࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠷࠲ࡵࡳ࡮࠯࠹࠼࠻ࠬࠨࠩ࠯ࠫࠬ࠲࡮ࡦࡹࡢࡪ࡮ࡲࡴࡦࡴ࠵࠯ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧࠪࠏࠍࠍࠎࠏࡥ࡭࡫ࡩࠤࡹࡿࡰࡦ࠿ࡀࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨࠢࡤࡲࡩࠦࡡ࡭࡮ࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࡟࡭࡫ࡶࡸࡠ࠳࠲࡞࠭ࠪࡁࡂ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡴࡦࡴࡢࡳࡵࡺࡩࡰࡰࡶ࠾ࠒࠐࠉࠊࠋࠌࡧࡱ࡫ࡡ࡯ࡡࡩ࡭ࡱࡺࡥࡳࠢࡀࠤࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠪࡱࡩࡼࡥࡶࡢ࡮ࡸࡩࡸ࠲ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ࠭ࠒࠐࠉࠊࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡣ࡭ࡧࡤࡲࡤ࡬ࡩ࡭ࡶࡨࡶ࠱ࡴࡥࡸࡡࡹࡥࡱࡻࡥࡴࠫࠐࠎࠎࠏࠉࠊࡷࡵࡰ࠸ࠦ࠽ࠡࡷࡵࡰ࠰࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ࠱ࡣ࡭ࡧࡤࡲࡤ࡬ࡩ࡭ࡶࡨࡶࠒࠐࠉࠊࠋࠌࡹࡷࡲ࠴ࠡ࠿ࠣࡔࡗࡋࡐࡂࡔࡈࡣࡋࡏࡌࡕࡇࡕࡣࡋࡏࡎࡂࡎࡢ࡙ࡗࡒࠨࡶࡴ࡯࠷࠱ࡻࡲ࡭࠻ࠬࠑࠏࠏࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠶࠱ࡻࡲ࡭࠶࠯࠹࠼࠷ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨࠫࠐࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠳࠮ࡸࡶࡱ࠲࠵࠸࠶࠯ࠫࠬ࠲ࠧࠨ࠮ࡱࡩࡼࡥࡦࡪ࡮ࡷࡩࡷ࠸ࠩࠎࠌࠌࡶࡪࡺࡵࡳࡰࠐࠎࠒࠐࡡ࡭࡮ࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࡟࡭࡫ࡶࡸࠥࡃࠠ࡜ࠩࡪࡩࡳࡸࡥࠨ࠮ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ࠯ࠫࡳࡧࡴࡪࡱࡱࠫࡢࠓࠊࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࡤࡲࡩࡴࡶࠣࡁࠥࡡࠧ࡮ࡲࡤࡥࠬ࠲ࠧࡨࡧࡱࡶࡪ࠭ࠬࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ࠭ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ࠱࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ࠭ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ࠱࠭࡮ࡢࡶ࡬ࡳࡳ࠭ࠬࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪࡡࠒࠐࠍࠋࡦࡨࡪࠥࡖࡒࡆࡒࡄࡖࡊࡥࡆࡊࡎࡗࡉࡗࡥࡆࡊࡐࡄࡐࡤ࡛ࡒࡍࠪࡸࡶࡱ࠸ࠬࡶࡴ࡯࠷࠮ࡀࠍࠋࠋ࡬ࡪࠥ࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭ࠠࡪࡰࠣࡹࡷࡲ࠲࠻ࠢࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ࠯ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ࠮ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂࡃࠧ࠭ࠩ࠲ࠫ࠮ࠓࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠨࠩࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡸࡥࡵࡷࡵࡲࠥࡻࡲ࡭࠴ࠐࠎࠒࠐࡤࡦࡨࠣࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠩࡨ࡬ࡰࡹ࡫ࡲࡴ࠮ࡰࡳࡩ࡫ࠩ࠻ࠏࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠭ࠩࡌࡒࠥࠦࠠࠡࠩ࠮ࡱࡴࡪࡥࠪࠏࠍࠍࠨࠦ࡭ࡰࡦࡨࡁࡂ࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨࠋࠌࡳࡳࡲࡹࠡࡰࡲࡲࠥ࡫࡭ࡱࡶࡼࠤࡻࡧ࡬ࡶࡧࡶࠑࠏࠏࠣࠡ࡯ࡲࡨࡪࡃ࠽ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫࠎࠏ࡯࡯࡮ࡼࠤࡳࡵ࡮ࠡࡧࡰࡴࡹࡿࠠࡧ࡫࡯ࡸࡪࡸࡳࠎࠌࠌࠧࠥࡳ࡯ࡥࡧࡀࡁࠬࡧ࡬࡭ࠩࠌࠍࠎࠏࠉࡢ࡮࡯ࠤ࡫࡯࡬ࡵࡧࡵࡷࠥ࠮ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡳࠡࡧࡰࡴࡹࡿࠠࡧ࡫࡯ࡸࡪࡸࠩࠎࠌࠌࡪ࡮ࡲࡴࡦࡴࡶࠤࡂࠦࡦࡪ࡮ࡷࡩࡷࡹ࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠧࠨࠪ࠭ࠒࠐࠉࡧ࡫࡯ࡸࡪࡸࡳࡅࡋࡆࡘ࠱ࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࡵࠣࡁࠥࢁࡽ࠭ࠩࠪࠑࠏࠏࡩࡧࠢࠪࡁࡂ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠒࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡩ࡭ࡱࡺࡥࡳࡵ࠱ࡷࡵࡲࡩࡵࠪࠪࠪࠫ࠭ࠩࠎࠌࠌࠍ࡫ࡵࡲࠡ࡫ࡷࡩࡲࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠏࠍࠍࠎࠏࡶࡢࡴ࠯ࡺࡦࡲࡵࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩࡀࡁࠬ࠯ࠍࠋࠋࠌࠍ࡫࡯࡬ࡵࡧࡵࡷࡉࡏࡃࡕ࡝ࡹࡥࡷࡣࠠ࠾ࠢࡹࡥࡱࡻࡥࠎࠌࠌࡪࡴࡸࠠ࡬ࡧࡼࠤ࡮ࡴࠠࡢ࡮࡯ࡣ࡫࡯࡬ࡵࡧࡵࡷࡤࡲࡩࡴࡶ࠽ࠑࠏࠏࠉࡪࡨࠣ࡯ࡪࡿࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡨ࡬ࡰࡹ࡫ࡲࡴࡆࡌࡇ࡙࠴࡫ࡦࡻࡶࠬ࠮࠯࠺ࠡࡸࡤࡰࡺ࡫ࠠ࠾ࠢࡩ࡭ࡱࡺࡥࡳࡵࡇࡍࡈ࡚࡛࡬ࡧࡼࡡࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠠࡷࡣ࡯ࡹࡪࠦ࠽ࠡࠩ࠳ࠫࠒࠐࠉࠊ࡫ࡩࠤࠬࠫࠧࠡࡰࡲࡸࠥ࡯࡮ࠡࡸࡤࡰࡺ࡫࠺ࠡࡸࡤࡰࡺ࡫ࠠ࠾ࠢࡔ࡙ࡔ࡚ࡅࠩࡸࡤࡰࡺ࡫ࠩࠎࠌࠌࠍ࡮࡬ࠠ࡮ࡱࡧࡩࡂࡃࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩࠣࡥࡳࡪࠠࡷࡣ࡯ࡹࡪࠧ࠽ࠨ࠲ࠪ࠾ࠥࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࡵࠣࡁࠥࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࡵ࠮ࠫࠥ࠱ࠠࠨ࠭ࡹࡥࡱࡻࡥࠎࠌࠌࠍࡪࡲࡩࡧࠢࡰࡳࡩ࡫࠽࠾ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬࠦࡡ࡯ࡦࠣࡺࡦࡲࡵࡦࠣࡀࠫ࠵࠭࠺ࠡࡰࡨࡻࡤ࡬ࡩ࡭ࡶࡨࡶࡸࠦ࠽ࠡࡰࡨࡻࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠱ࠧࠧࠨࠪ࠯ࡰ࡫ࡹࠬࠩࡀࡁࠬ࠱ࡶࡢ࡮ࡸࡩࠒࠐࠉࠊࡧ࡯࡭࡫ࠦ࡭ࡰࡦࡨࡁࡂ࠭ࡡ࡭࡮ࠪ࠾ࠥࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࡵࠣࡁࠥࡴࡥࡸࡡࡩ࡭ࡱࡺࡥࡳࡵ࠮ࠫࠫࠬࠧࠬ࡭ࡨࡽ࠰࠭࠽࠾ࠩ࠮ࡺࡦࡲࡵࡦࠏࠍࠍࡳ࡫ࡷࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠢࡀࠤࡳ࡫ࡷࡠࡨ࡬ࡰࡹ࡫ࡲࡴ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣ࠯ࠥ࠭ࠩࠎࠌࠌࡲࡪࡽ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠡ࠿ࠣࡲࡪࡽ࡟ࡧ࡫࡯ࡸࡪࡸࡳ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠨࠩࠫ࠮ࠓࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡳ࡫ࡷࡠࡨ࡬ࡰࡹ࡫ࡲࡴ࠮ࠪࡓ࡚࡚ࠧࠪࠏࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡳ࡫ࡷࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠏࠍࠦࠧࠨ⧎")
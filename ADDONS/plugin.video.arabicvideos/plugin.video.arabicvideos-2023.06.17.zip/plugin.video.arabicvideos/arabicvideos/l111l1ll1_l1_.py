# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧፈ")
menu_name = l1l1ll_l1_ (u"ࠩࡢࡆࡐࡘ࡟ࠨፉ")
l1l1l1_l1_ = WEBSITES[script_name][0]
headers = {l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧፊ"):l1l1ll_l1_ (u"ࠫࠬፋ")}
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠫፌ"),l1l1ll_l1_ (u"࠭ศไำสࠤ࡙࡜ࠧፍ")]
def MAIN(mode,url,text):
	if   mode==370: results = MENU()
	elif mode==371: results = l11l1l_l1_(url,text)
	elif mode==372: results = PLAY(url)
	elif mode==374: results = l111l1l1l_l1_(url)
	elif mode==375: results = l111l111l_l1_(url)
	elif mode==376: results = l111l11l1_l1_(0,url)
	elif mode==377: results = l111l11l1_l1_(1,url)
	elif mode==379: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫፎ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩፏ"),l1l1ll_l1_ (u"ࠩࠪፐ"),l1l1ll_l1_ (u"ࠪࠫፑ"),l1l1ll_l1_ (u"ࠫࠬፒ"),l1l1ll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ፓ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ፔ"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧፕ"),l1l1ll_l1_ (u"ࠨࠩፖ"),379,l1l1ll_l1_ (u"ࠩࠪፗ"),l1l1ll_l1_ (u"ࠪࠫፘ"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨፙ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪፚ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭፛"),l1l1ll_l1_ (u"ࠧࠨ፜"),9999)
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺ࠭ࡴ࡫ࡧࡩ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ፝"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ፞"),block,re.DOTALL)
		for link,title in items:
			link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ፟"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭፠")+menu_name+title,link,371)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፡"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ።")+menu_name+l1l1ll_l1_ (u"ࠧศๆ่้๏ุษࠨ፣"),l1l1l1_l1_,375)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ፤"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ፥")+menu_name+l1l1ll_l1_ (u"ࠪห้ษอะอࠪ፦"),l1l1l1_l1_,376)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ፧"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ፨")+menu_name+l1l1ll_l1_ (u"๊࠭ีษ๊ำࠥอไร่ࠪ፩"),l1l1l1_l1_,377)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ፪"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ፫")+menu_name+l1l1ll_l1_ (u"ࠩๅหห๋ษࠡษ็้๊ัไ๋่ࠪ፬"),l1l1l1_l1_,374)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ፭"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ፮"),l1l1ll_l1_ (u"ࠬ࠭፯"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡵࡱࡳ࠱ࡲ࡫࡮ࡶࠩ፰"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭፱"),block,re.DOTALL)
		for link,title in items[7:]:
			title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ፲"))
			link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ፳"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ፴")+menu_name+title,link,371)
		for link,title in items[0:7]:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭፵"))
			link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ፶"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ፷")+menu_name+title,link,371)
	return
def l111l1l1l_l1_(website=l1l1ll_l1_ (u"ࠧࠨ፸")):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ፹"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ፺"),l1l1ll_l1_ (u"ࠪࠫ፻"),l1l1ll_l1_ (u"ࠫࠬ፼"),l1l1ll_l1_ (u"ࠬ࠭፽"),l1l1ll_l1_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡇࡃࡕࡑࡕࡗࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭፾"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡖࡤ࡫ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ፿"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᎀ"),block,re.DOTALL)
		for link,title in items:
			if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᎁ") in link: continue
			else: link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᎂ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᎃ")+menu_name+title,link,371)
	return
def l111l111l_l1_(website=l1l1ll_l1_ (u"ࠬ࠭ᎄ")):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᎅ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨᎆ"),l1l1ll_l1_ (u"ࠨࠩᎇ"),l1l1ll_l1_ (u"ࠩࠪᎈ"),l1l1ll_l1_ (u"ࠪࠫᎉ"),l1l1ll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡊࡊࡇࡔࡖࡔࡈࡈ࠲࠷ࡳࡵࠩᎊ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡇࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠧᎋ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯ࡷ࡫ࡧࡴࡦ࡭ࡥࡠ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫᎌ"),block,re.DOTALL)
		for link,img,title in items:
			link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᎍ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᎎ")+menu_name+title,link,372,img)
	return
def l111l11l1_l1_(id,website=l1l1ll_l1_ (u"ࠩࠪᎏ")):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ᎐"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬ᎑"),l1l1ll_l1_ (u"ࠬ࠭᎒"),l1l1ll_l1_ (u"࠭ࠧ᎓"),l1l1ll_l1_ (u"ࠧࠨ᎔"),l1l1ll_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡘࡃࡗࡇࡍࡏࡎࡈࡐࡒ࡛࠲࠷ࡳࡵࠩ᎕"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡵ࡫ࡷࡰࡪ࠸ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨ᎖"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[id]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭᎗"),block,re.DOTALL)
		for link,img,title in items:
			link = l1l1l1_l1_+link
			if not any(value in title for value in l1ll11_l1_):
				addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᎘"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᎙")+menu_name+title,link,372,img)
	return
def l11l1l_l1_(url,type1=l1l1ll_l1_ (u"࠭ࠧ᎚")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ᎛"),l1l1ll_l1_ (u"ࠨࠩ᎜"),type1,url)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ᎝"),html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ᎞"),url,l1l1ll_l1_ (u"ࠫࠬ᎟"),l1l1ll_l1_ (u"ࠬ࠭Ꭰ"),l1l1ll_l1_ (u"࠭ࠧᎡ"),l1l1ll_l1_ (u"ࠧࠨᎢ"),l1l1ll_l1_ (u"ࠨࡄࡒࡏࡗࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᎣ"))
	html = response.content
	if l1l1ll_l1_ (u"ࠩࡹ࡭ࡩࡶࡡࡨࡧࡢࠫᎤ") in url:
		link = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡆࡲࡢࡶ࡯࠰࠲࠯ࡅࠩࠣࠩᎥ"),html,re.DOTALL)
		if link:
			link = l1l1l1_l1_+link[0]
			l11l1l_l1_(link)
			return
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࠥࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡯ࡧ࠱࠸࠭Ꭶ"),html,re.DOTALL)
	if type1==l1l1ll_l1_ (u"ࠬ࠭Ꭷ") and l1lll11_l1_ and l1lll11_l1_[0].count(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࠫᎨ"))>1:
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᎩ"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠨᎪ"),url,371,l1l1ll_l1_ (u"ࠩࠪᎫ"),l1l1ll_l1_ (u"ࠪࠫᎬ"),l1l1ll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡶࠫᎭ"))
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᎮ"),block,re.DOTALL)
		for link,title in items:
			link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨᎯ")+link
			title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩᎰ"))
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᎱ"),menu_name+title,link,371)
	else:
		l1l1_l1_ = []
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡭ࡥ࠯࠶ࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡾࡳ࠮࠳࠵ࠫᎲ"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠼ࠧ࠮࠮ࠫࡁࠬࡧࡴࡲ࠭ࡹࡵ࠰࠵࠷࠭Ꮃ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭Ꮄ"),block,re.DOTALL)
			l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵ࠤࡂ࡛ࠦ࡞ࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸࡷࡿ࠺ࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࡬ࡲࡹ࠮ࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫฬ๊อๅไฬࠤ࠰࠮࡜ࡥ࠭ࠬࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠ࠭ࠏࠏࠉࠊࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡧࡴࡻ࡮ࡵࠢࡀࠤ࠲࠷ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵ࠵࠲ࡦࡶࡰࡦࡰࡧࠬ࠭ࡲࡩ࡯࡭࠯࡭ࡲ࡭ࠬࡵ࡫ࡷࡰࡪ࠲ࡣࡰࡷࡱࡸ࠮࠯ࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠵࠰ࠥࡸࡥࡷࡧࡵࡷࡪࡃࡆࡢ࡮ࡶࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠹࡝ࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡪ࡯ࡪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡧࡴࡻ࡮ࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠤࠥࠦᎵ")
			for link,img,title in items:
				img = img[:10]+img[10:].replace(l1l1ll_l1_ (u"࠭࠯࠰ࠩᎶ"),l1l1ll_l1_ (u"ࠧ࠰ࠩᎷ")).replace(l1l1ll_l1_ (u"ࠨࠢࠪᎸ"),l1l1ll_l1_ (u"ࠩࠨ࠶࠵࠭Ꮉ"))
				#LOG_THIS(l1l1ll_l1_ (u"ࠪࠫᎺ"),img)
				link = l1l1l1_l1_+link
				title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭Ꮋ"))
				if l1l1ll_l1_ (u"ࠬ࠵ࡡ࡭ࡡࠪᎼ") in link:
					addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮍ"),menu_name+title,link,371,img)
				elif l1l1ll_l1_ (u"ࠧศๆะ่็ฯࠧᎾ") in title and (l1l1ll_l1_ (u"ࠨ࠱ࡆࡥࡹ࠳ࠧᎿ") in url or l1l1ll_l1_ (u"ࠩ࠲ࡗࡪࡧࡲࡤࡪ࠲ࠫᏀ") in url):
					l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠰ࠤ࠰อไฮๆๅอࠥ࠱࡜ࡥ࠭ࠪᏁ"),title,re.DOTALL)
					if l11111_l1_: title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩᏂ")+l11111_l1_[0]
					if title not in l1l1_l1_:
						l1l1_l1_.append(title)
						addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏃ"),menu_name+title,link,371,img)
				else: addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᏄ"),menu_name+title,link,372,img)
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᏅ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏆ"),block,re.DOTALL)
			for link,title in items:
				link = l1l1l1_l1_+link
				title = l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨᏇ")+unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᏈ"),menu_name+title,link,371,l1l1ll_l1_ (u"ࠫࠬᏉ"),l1l1ll_l1_ (u"ࠬ࠭Ꮚ"),l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡸ࠭Ꮛ"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᏌ"),url,l1l1ll_l1_ (u"ࠨࠩᏍ"),l1l1ll_l1_ (u"ࠩࠪᏎ"),l1l1ll_l1_ (u"ࠪࠫᏏ"),l1l1ll_l1_ (u"ࠫࠬᏐ"),l1l1ll_l1_ (u"ࠬࡈࡏࡌࡔࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭Ꮡ"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡬ࡢࡤࡨࡰ࠲ࡹࡵࡤࡥࡨࡷࡸࠦ࡭ࡳࡩ࠰ࡦࡹࡳ࠭࠶ࠢࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᏒ"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	url3 = l1l1ll_l1_ (u"ࠧࠨᏓ")
	url2 = re.findall(l1l1ll_l1_ (u"ࠨࡸࡤࡶࠥࡻࡲ࡭ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᏔ"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = url.replace(l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡰࡢࡩࡨࡣࠬᏕ"),l1l1ll_l1_ (u"ࠪ࠳ࡕࡲࡡࡺ࠱ࠪᏖ"))
	if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᏗ") not in url2: url2 = l1l1l1_l1_+url2
	url2 = url2.strip(l1l1ll_l1_ (u"ࠬ࠳ࠧᏘ"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᏙ"),url2,l1l1ll_l1_ (u"ࠧࠨᏚ"),l1l1ll_l1_ (u"ࠨࠩᏛ"),l1l1ll_l1_ (u"ࠩࠪᏜ"),l1l1ll_l1_ (u"ࠪࠫᏝ"),l1l1ll_l1_ (u"ࠫࡇࡕࡋࡓࡃ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬᏞ"))
	l1l11ll1_l1_ = response.content
	url3 = re.findall(l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᏟ"),l1l11ll1_l1_,re.DOTALL)
	if url3:
		url3 = url3[-1]
		if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫᏠ") not in url3: url3 = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭Ꮱ")+url3
		if l1l1ll_l1_ (u"ࠨ࠱ࡓࡐࡆ࡟࠯ࠨᏢ") not in url2:
			if l1l1ll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠯࡯࡬ࡲ࠳ࡰࡳࠨᏣ") in url3:
				l111l11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡲࡸࡦࡱ࡯ࡳࡩࡧࡵ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᏤ"),l1l11ll1_l1_,re.DOTALL)
				if l111l11ll_l1_:
					l111l1111_l1_, l111l1l11_l1_ = l111l11ll_l1_[0]
					url3 = SERVER(url3,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨᏥ"))+l1l1ll_l1_ (u"ࠬ࠵ࡶ࠳࠱ࠪᏦ")+l111l1111_l1_+l1l1ll_l1_ (u"࠭࠯ࡤࡱࡱࡪ࡮࡭࠯ࠨᏧ")+l111l1l11_l1_+l1l1ll_l1_ (u"ࠧ࠯࡬ࡶࡳࡳ࠭Ꮸ")
		import ll_l1_
		ll_l1_.l1l_l1_([url3],script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᏩ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠩࠪᏪ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠪࠫᏫ"): return
	search = search.replace(l1l1ll_l1_ (u"ࠫࠥ࠭Ꮼ"),l1l1ll_l1_ (u"ࠬ࠱ࠧᏭ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡔࡧࡤࡶࡨ࡮࠯ࠨᏮ")+search
	l11l1l_l1_(url)
	return
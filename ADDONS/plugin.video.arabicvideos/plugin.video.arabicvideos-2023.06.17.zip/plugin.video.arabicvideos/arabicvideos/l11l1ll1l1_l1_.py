# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧẺ")
def MAIN(mode,url):
	if   mode==330: results = l11lll1ll1_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11ll111ll_l1_()
	elif mode==333: results = l11l1l11l1_l1_()
	elif mode==334: results = l1ll1l1l11_l1_(url)
	else: results = False
	return results
def l1ll1l1l11_l1_(l11l1ll11l_l1_):
	try: os.remove(l11l1ll11l_l1_.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫẻ")))
	except: os.remove(l11l1ll11l_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ẽ"))
	return
def l11l1l11l1_l1_():
	message = l1l1ll_l1_ (u"ࠨลำ๋อࠦลๅ๋ࠣีฬฮืࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไึ๊อࠤๆ๐ࠠศๆ่์็฿ࠠศๆ่฻้๎ศࠡอ่ࠤศ฼ฺุࠢ฼่๎ࠦาาࠢส่็อฦๆหࠣห้๐ๅ๋่ࠣฯ๊ࠦรฯฬสีࠥࠨสฮ็ํ่๋ࠥไโษอࠤๆ๐ฯ๋๊ࠥࠤะ๋ࠠศะอหึࠦฯใหࠣห้฻่าหࠣ์ฬิสศำ๊ࠣํ฿ࠠๆๆไࠤฬ๊ี้ำฬࠤํฮูะ้สࠤุ๎แࠡ์หำศࠦวๅฬะ้๏๊ࠧẽ")
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪẾ"),l1l1ll_l1_ (u"ࠪࠫế"),l1l1ll_l1_ (u"ࠫ฼ื๊ใหࠣฮา๋๊ๅࠢส่๊๊แศฬࠪỀ"),message)
	return
def l11lll1ll1_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪề"),l1l1ll_l1_ (u"࠭ืา์ๅอࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫỂ"),l1l1ll_l1_ (u"ࠧࠨể"),333)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ễ"),l1l1ll_l1_ (u"ࠩอ฾๏๐ัࠡ็ๆห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩễ"),l1l1ll_l1_ (u"ࠪࠫỆ"),332)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩệ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬỈ"),l1l1ll_l1_ (u"࠭ࠧỉ"),9999)
	l11ll1ll1l_l1_ = l11ll1111l_l1_()
	mtime = os.stat(l11ll1ll1l_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11ll1ll11_l1_ = os.listdir(l11ll1ll1l_l1_.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬỊ")))
	else: l11ll1ll11_l1_ = os.listdir(l11ll1ll1l_l1_.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ị")))
	for filename in l11ll1ll11_l1_:
		if kodi_version>18.99: filename = filename.decode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧỌ"))
		if not filename.startswith(l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩọ")): continue
		filepath = os.path.join(l11ll1ll1l_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11lll11ll_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩỎ"))
			except: pass
			filename = filename.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪỏ"))
		filepath = os.path.join(l11ll1ll1l_l1_,filename)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬỐ"),filename,filepath,331)
	return
def l11ll1111l_l1_():
	l11ll1ll1l_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪố"))
	if l11ll1ll1l_l1_: return l11ll1ll1l_l1_
	settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫỒ"),addoncachefolder)
	return addoncachefolder
def l11ll111ll_l1_():
	l11ll1ll1l_l1_ = l11ll1111l_l1_()
	l11ll1l111_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩồ"),l1l1ll_l1_ (u"ࠪࠫỔ"),l1l1ll_l1_ (u"ࠫࠬổ"),l11ll1ll1l_l1_,l1l1ll_l1_ (u"ࠬํะศ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฽๎๏ืࠠศๆ่็ฬ์ࠠภࠩỖ"))
	if l11ll1l111_l1_==1:
		newpath = l11ll11l1l_l1_(3,l1l1ll_l1_ (u"࠭ๅไษ้ࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪỗ"),l1l1ll_l1_ (u"ࠧ࡭ࡱࡦࡥࡱ࠭Ộ"),l1l1ll_l1_ (u"ࠨࠩộ"),False,True,l11ll1ll1l_l1_)
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩỚ"),l1l1ll_l1_ (u"ࠪࠫớ"),l1l1ll_l1_ (u"ࠫࠬỜ"),newpath,l1l1ll_l1_ (u"ࠬํะศ๊ࠢ์ࠥอไๆๅส๊ࠥอไอัํำ๊ࠥสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฬูสฯัส้์ࠦศะๆสࠤ๊์ࠠศๆ่็ฬ์ࠠศๆๅำ๏๋ࠠภࠩờ"))
		if yes==1:
			settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩỞ"),newpath)
			DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨở"),l1l1ll_l1_ (u"ࠨࠩỠ"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬỡ"),l1l1ll_l1_ (u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫỢ"))
	#if not l11ll1l111_l1_ or not yes: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬợ"),l1l1ll_l1_ (u"ࠬ࠭Ụ"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩụ"),l1l1ll_l1_ (u"ࠧห็ࠣห้เวยࠢส่฾๋ไ๋หࠪỦ"))
	return
def l11ll11l11_l1_(filename):
	l11lll1l1l_l1_ = l1l1ll_l1_ (u"ࠨࠩủ").join(ii for ii in filename if ii not in l1l1ll_l1_ (u"ࠩ࡟࠳ࠧࡀࠪࡀ࠾ࡁࢀࠬỨ")+half_triangular_colon)
	return l11lll1l1l_l1_
def l11ll11111_l1_(url,videofiletype=l1l1ll_l1_ (u"ࠪࠫứ"),website=l1l1ll_l1_ (u"ࠫࠬỪ")):
	#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬừ"),l1l1ll_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭Ử"))
	LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧử"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨỮ")+url+l1l1ll_l1_ (u"ࠩࠣࡡࠬữ"))
	if not videofiletype: videofiletype = GET_VIDEOFILETYPE(url,website)
	#if not videofiletype:
	#	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫỰ"),l1l1ll_l1_ (u"ࠫࠬự"),l1l1ll_l1_ (u"ࠬะๆำ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩỲ"),l1l1ll_l1_ (u"࠭วๅ็็ๅ๋ࠥๆ่๋ࠡ฽ࠥ࠭ỳ")+videofiletype+l1l1ll_l1_ (u"๊ࠧࠡส่อืๆศ็ฯࠤาอไ๋ษࠣ฾๏ืࠠอษ๊ึ๊ࠥสฮ็ํ่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊ๅๅใสฮࠬỴ"))
	#	LOG_THIS(l1l1ll_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ỵ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡹࡿࡰࡦ࠱ࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫỶ")+url+l1l1ll_l1_ (u"ࠪࠤࡢ࠭ỷ"))
	#	return False
	l11ll1ll1l_l1_ = l11ll1111l_l1_()
	l11lll1111_l1_ = l11ll1l1ll_l1_()
	filename = l11lll1111_l1_.replace(l1l1ll_l1_ (u"ࠫࠥ࠭Ỹ"),l1l1ll_l1_ (u"ࠬࡥࠧỹ"))
	filename = l11ll11l11_l1_(filename)
	#videofiletype = videofiletype.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫỺ"))
	filename = l1l1ll_l1_ (u"ࠧࡧ࡫࡯ࡩࡤ࠭ỻ")+str(int(now))[-4:]+l1l1ll_l1_ (u"ࠨࡡࠪỼ")+filename+videofiletype
	l11l1l11ll_l1_ = os.path.join(l11ll1ll1l_l1_,filename)
	headers = {}
	headers[l1l1ll_l1_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫỽ")] = l1l1ll_l1_ (u"ࠪࠫỾ")
	headers[l1l1ll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷࠫỿ")] = l1l1ll_l1_ (u"ࠬ࠰࠯ࠫࠩἀ")
	url = url.replace(l1l1ll_l1_ (u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩἁ"),l1l1ll_l1_ (u"ࠧࠨἂ"))
	if l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ἃ") in url:
		url2,useragent = url.rsplit(l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧἄ"),1)
		useragent = useragent.replace(l1l1ll_l1_ (u"ࠪࢀࠬἅ"),l1l1ll_l1_ (u"ࠫࠬἆ")).replace(l1l1ll_l1_ (u"ࠬࠬࠧἇ"),l1l1ll_l1_ (u"࠭ࠧἈ"))
	else: url2,useragent = url,None
	if not useragent: useragent = l1l11lll1_l1_()
	if useragent: headers[l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫἉ")] = useragent
	if l1l1ll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪἊ") in url2: url2,l11l1lll11_l1_ = url2.rsplit(l1l1ll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀࠫἋ"),1)
	else: url2,l11l1lll11_l1_ = url2,l1l1ll_l1_ (u"ࠪࠫἌ")
	url2 = url2.strip(l1l1ll_l1_ (u"ࠫࢁ࠭Ἅ")).strip(l1l1ll_l1_ (u"ࠬࠬࠧἎ")).strip(l1l1ll_l1_ (u"࠭ࡼࠨἏ")).strip(l1l1ll_l1_ (u"ࠧࠧࠩἐ"))
	l11l1lll11_l1_ = l11l1lll11_l1_.replace(l1l1ll_l1_ (u"ࠨࡾࠪἑ"),l1l1ll_l1_ (u"ࠩࠪἒ")).replace(l1l1ll_l1_ (u"ࠪࠪࠬἓ"),l1l1ll_l1_ (u"ࠫࠬἔ"))
	if l11l1lll11_l1_:	headers[l1l1ll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ἕ")] = l11l1lll11_l1_
	LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭἖"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ἗")+url2+l1l1ll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫἘ")+str(headers)+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩἙ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"ࠪࠤࡢ࠭Ἒ"))
	MegaByte = 1024*1024
	l11ll1llll_l1_ = 0
	try:
		l11ll1lll1_l1_ =	xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡥࡦࡕࡳࡥࡨ࡫ࠧἛ"))
		l11ll1lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡢࡤࠬࠩἜ"),l11ll1lll1_l1_)
		l11ll1llll_l1_ = int(l11ll1lll1_l1_[0])
	except: pass
	if not l11ll1llll_l1_:
		try:
			l11ll1l11l_l1_ = os.l11l1l1111_l1_(l11ll1ll1l_l1_)
			l11ll1llll_l1_ = l11ll1l11l_l1_.f_frsize*l11ll1l11l_l1_.f_bavail//MegaByte
		except: pass
	if not l11ll1llll_l1_:
		try:
			l11ll1l11l_l1_ = os.l11lll1l11_l1_(l11ll1ll1l_l1_)
			l11ll1llll_l1_ = l11ll1l11l_l1_.f_frsize*l11ll1l11l_l1_.f_bavail//MegaByte
		except: pass
	if not l11ll1llll_l1_:
		try:
			import shutil
			total,l11ll111l1_l1_,l11l1lllll_l1_ = shutil.l11llll11l_l1_(l11ll1ll1l_l1_)
			l11ll1llll_l1_ = l11l1lllll_l1_//MegaByte
		except: pass
	if not l11ll1llll_l1_:
		l11llll1l1_l1_(l1l1ll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬἝ"),l1l1ll_l1_ (u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠๆฮ๊์้ฯࠧ἞"),l1l1ll_l1_ (u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ฽๎ึࠦโศัิࠤศ์๋ࠠฯาำ๋ࠥโะษิࠤู๊วฮหࠣห้ะฮำ์้ࠤฬ๊แศำ฽อࠥ็๊ࠡฮ๊หื้้ࠠ฻็๎์ࠦแศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦไ็ࠢํ฽ฺ๊๊่ࠠา็ࠥหไ๊ࠢฦ๊ࠥ๐โ้็้ࠣอืๅอ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡสะ่ࠥํะ่ࠢสฺ่๊ใๅห่ࠣฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠣๆิ๊ࠦิสหࠤฬ๋สๅษฤࠤัํวำๅࠣฬฬ๊ๅๅใสฮࠥ๎็ัษࠣๅ๏ํࠠฯู๋ีฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๊็ัษࠣหู้ศษࠢๅห๊ࠦวๅ็หี๊าࠠๆฦๅฮฬࠦศๆ่฼ࠤฬ๊ศา่ส้ัࠦๅ็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬ἟"),l1l1ll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬἠ"))
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨἡ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬἢ"))
		return False
	import requests
	if videofiletype==l1l1ll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫἣ"):
		l111l1l_l1_,l11l1_l1_ = l11lll1lll_l1_(url2,headers)
		#DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫἤ"), l111l1l_l1_)
		#DIALOG_SELECT(l1l1ll_l1_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬἥ"), l11l1_l1_)
		if len(l111l1l_l1_)==0:
			DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬἦ"),l1l1ll_l1_ (u"ࠩࠪἧ"))
			return False
		elif len(l111l1l_l1_)==1: selection = 0
		elif len(l111l1l_l1_)>1:
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨἨ"), l111l1l_l1_)
			if selection == -1 :
				DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅฬะ้๏๊ࠧἩ"),l1l1ll_l1_ (u"ࠬ࠭Ἢ"))
				return False
		url2 = l11l1_l1_[selection]
	filesize = 0
	if videofiletype==l1l1ll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬἫ"):
		l11l1l11ll_l1_ = l11l1l11ll_l1_.rsplit(l1l1ll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭Ἤ"))[0]+l1l1ll_l1_ (u"ࠨ࠰ࡰࡴ࠹࠭Ἥ")
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭Ἦ"),url2,l1l1ll_l1_ (u"ࠪࠫἯ"),headers,l1l1ll_l1_ (u"ࠫࠬἰ"),l1l1ll_l1_ (u"ࠬ࠭ἱ"),l1l1ll_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭ἲ"))
		l11111ll_l1_ = response.content
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡝ࠥࡈ࡜࡙ࡏࡎࡇ࠼࠱࠮ࡄࡡ࡜࡯࡞ࡵࡡ࠭࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩἳ"),l11111ll_l1_+l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡷ࠭ἴ"),re.DOTALL)
		if not l1ll_l1_:
			LOG_THIS(l1l1ll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧἵ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡔࡩࡧࠣࡱ࠸ࡻ࠸ࠡࡨ࡬ࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡩࡣࡹࡩࠥࡺࡨࡦࠢࡵࡩࡶࡻࡩࡳࡧࡧࠤࡱ࡯࡮࡬ࡵࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ἶ")+url2+l1l1ll_l1_ (u"ࠫࠥࡣࠧἷ"))
			return False
		link = l1ll_l1_[0]
		if not link.startswith(l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪἸ")):
			if link.startswith(l1l1ll_l1_ (u"࠭࠯࠰ࠩἹ")): link = url2.split(l1l1ll_l1_ (u"ࠧ࠻ࠩἺ"),1)[0]+l1l1ll_l1_ (u"ࠨ࠼ࠪἻ")+link
			elif link.startswith(l1l1ll_l1_ (u"ࠩ࠲ࠫἼ")): link = SERVER(url2,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧἽ"))+link
			else: link = url2.rsplit(l1l1ll_l1_ (u"ࠫ࠴࠭Ἶ"),1)[0]+l1l1ll_l1_ (u"ࠬ࠵ࠧἿ")+link
		response = requests.request(l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪὀ"),link,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l11l1llll1_l1_ = len(l1ll_l1_)
		filesize = chunksize*l11l1llll1_l1_
	else:
		chunksize = 1*MegaByte
		response = requests.request(l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫὁ"),url2,headers=headers,verify=False,stream=True)
		if l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩὂ") in response.headers: filesize = int(response.headers[l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪὃ")])
		l11l1llll1_l1_ = int(filesize//chunksize)
	#l11lll111l_l1_ = l11l1llll1_l1_+1
	l11lll111l_l1_ = int(filesize//MegaByte)+1
	if filesize<21000:
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨὄ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ὅ")+url2+l1l1ll_l1_ (u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩ὆")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ὇")+str(l11ll1llll_l1_)+l1l1ll_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪὈ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"ࠨࠢࡠࠫὉ"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪὊ"),l1l1ll_l1_ (u"ࠪࠫὋ"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧὌ"),l1l1ll_l1_ (u"ࠬ็ิๅࠢไ๎ู๋ࠥาใฬࠤาาๅࠡ็็ๅࠥอไโ์า๎ํࠦร้ࠢส่๊๊แࠡื฽๎ึࠦฬะษࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧὍ"))
		return False
	l11l1ll1ll_l1_ = 400
	l11l1l1ll1_l1_ = l11ll1llll_l1_-l11lll111l_l1_
	if l11l1l1ll1_l1_<l11l1ll1ll_l1_:
		LOG_THIS(l1l1ll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ὎"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡒࡴࡺࠠࡦࡰࡲࡹ࡬࡮ࠠࡥ࡫ࡶ࡯ࠥࡹࡰࡢࡥࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭὏")+url2+l1l1ll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬὐ")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨὑ")+str(l11ll1llll_l1_)+l1l1ll_l1_ (u"ࠪࠤࡒࡈࠠ࠮ࠢࠪὒ")+str(l11l1ll1ll_l1_)+l1l1ll_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧὓ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨὔ"))
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧὕ"),l1l1ll_l1_ (u"ࠧࠨὖ"),l1l1ll_l1_ (u"ࠨๆสࠤ๏๎ฬะ่ࠢืฬำษࠡๅสๅ๏ฯࠠๅๆอั๊๐ไࠨὗ"),l1l1ll_l1_ (u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่ࠢะะ๊ํࠠࠨ὘")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡࠩὙ")+str(l11ll1llll_l1_)+l1l1ll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠๆ็้าอแูหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬิ๎ๆࠡ็ืห่๊๋ࠠฮหࠤสฮโศรࠣࠫ὚")+str(l11l1ll1ll_l1_)+l1l1ll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐สࠡใสี฿ฯࠠะษษ้ฬ่่ࠦาสࠤ๊฿ๆศ้ࠣว๋ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧὛ"))
		return False
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭὜"),l1l1ll_l1_ (u"ࠧࠨὝ"),l1l1ll_l1_ (u"ࠨࠩ὞"),l1l1ll_l1_ (u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪὟ"),l1l1ll_l1_ (u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩὠ")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪὡ")+str(l11ll1llll_l1_)+l1l1ll_l1_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨὢ"))
	if yes!=1:
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧὣ"),l1l1ll_l1_ (u"ࠧࠨὤ"),l1l1ll_l1_ (u"ࠨࠩὥ"),l1l1ll_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧὦ"))
		LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪὧ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡸࡥࡧࡷࡶࡩࡩࠦࡴࡰࠢࡶࡸࡦࡸࡴࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧὨ")+url2+l1l1ll_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬὩ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩὪ"))
		return False
	LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧὫ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭Ὤ"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l11l1l11ll_l1_,l1l1ll_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪὭ"))
	l11l1lll1l_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l11l1l11ll_l1_,l1l1ll_l1_ (u"ࠪࡻࡧ࠭Ὦ"))
	else: file = open(l11l1l11ll_l1_.decode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩὯ")),l1l1ll_l1_ (u"ࠬࡽࡢࠨὰ"))
	if videofiletype==l1l1ll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬά"): # l11ll111l1_l1_ for l11111ll_l1_ and l11l1l1lll_l1_ chunks l11lll11l1_l1_ files such as .l11ll1l1l1_l1_
		for ii in range(1,l11l1llll1_l1_+1):
			link = l1ll_l1_[ii-1]
			if not link.startswith(l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬὲ")):
				if link.startswith(l1l1ll_l1_ (u"ࠨ࠱࠲ࠫέ")): link = url2.split(l1l1ll_l1_ (u"ࠩ࠽ࠫὴ"),1)[0]+l1l1ll_l1_ (u"ࠪ࠾ࠬή")+link
				elif link.startswith(l1l1ll_l1_ (u"ࠫ࠴࠭ὶ")): link = SERVER(url2,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩί"))+link
				else: link = url2.rsplit(l1l1ll_l1_ (u"࠭࠯ࠨὸ"),1)[0]+l1l1ll_l1_ (u"ࠧ࠰ࠩό")+link
			response = requests.request(l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬὺ"),link,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l11l1l1l1l_l1_ = time.time()
			l11l1l111l_l1_ = l11l1l1l1l_l1_-t1
			l11l1l1l11_l1_ = l11l1l111l_l1_//ii
			l11ll11ll1_l1_ = l11l1l1l11_l1_*(l11l1llll1_l1_+1)
			l11l1ll111_l1_ = l11ll11ll1_l1_-l11l1l111l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii//(l11l1llll1_l1_+1)),l1l1ll_l1_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪύ"),l1l1ll_l1_ (u"ࠪะ้ฮࠠๆๆไࠤฬ๊แ๋ัํ์࠿࠳ࠠศๆฯึฦࠦัใ็ࠪὼ"),str(ii*chunksize//MegaByte)+l1l1ll_l1_ (u"ࠫ࠴࠭ώ")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪ὾")+time.strftime(l1l1ll_l1_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣ὿"),time.gmtime(l11l1ll111_l1_))+l1l1ll_l1_ (u"ࠧࠡโࠪᾀ"))
			if pDialog.iscanceled():
				l11l1lll1l_l1_ = False
				break
	else: # l11l1111_l1_ and other l11ll11lll_l1_ file l11llll111_l1_
		ii = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			ii = ii+1
			l11l1l1l1l_l1_ = time.time()
			l11l1l111l_l1_ = l11l1l1l1l_l1_-t1
			l11l1l1l11_l1_ = l11l1l111l_l1_/ii
			l11ll11ll1_l1_ = l11l1l1l11_l1_*(l11l1llll1_l1_+1)
			l11l1ll111_l1_ = l11ll11ll1_l1_-l11l1l111l_l1_
			PROGRESS_UPDATE(pDialog,int(100*ii/(l11l1llll1_l1_+1)),l1l1ll_l1_ (u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᾁ"),l1l1ll_l1_ (u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩᾂ"),str(ii*chunksize//MegaByte)+l1l1ll_l1_ (u"ࠪ࠳ࠬᾃ")+str(l11lll111l_l1_)+l1l1ll_l1_ (u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩᾄ")+time.strftime(l1l1ll_l1_ (u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᾅ"),time.gmtime(l11l1ll111_l1_))+l1l1ll_l1_ (u"࠭ࠠแࠩᾆ"))
			if pDialog.iscanceled():
				l11l1lll1l_l1_ = False
				break
		response.close()
	file.close()
	pDialog.close()
	if not l11l1lll1l_l1_:
		LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᾇ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤ࡚ࡹࡥࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᾈ")+url2+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᾉ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"ࠪࠤࡢ࠭ᾊ"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬᾋ"),l1l1ll_l1_ (u"ࠬ࠭ᾌ"),l1l1ll_l1_ (u"࠭ࠧᾍ"),l1l1ll_l1_ (u"ࠧห็ࠣษ้เวยࠢ฼้้๐ษࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᾎ"))
		return True
	LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᾏ"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᾐ")+url2+l1l1ll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪᾑ")+l11l1l11ll_l1_+l1l1ll_l1_ (u"ࠫࠥࡣࠧᾒ"))
	DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ᾓ"),l1l1ll_l1_ (u"࠭ࠧᾔ"),l1l1ll_l1_ (u"ࠧࠨᾕ"),l1l1ll_l1_ (u"ࠨฬ่ࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡส้ะฬำࠧᾖ"))
	return True
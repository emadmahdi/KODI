# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ䵻")
headers = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䵼") : l1l1ll_l1_ (u"࠭ࠧ䵽") }
menu_name = l1l1ll_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭䵾")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l11l1l_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l11ll1l_l1_(url)
	elif mode==214: results = l1ll11l11l11_l1_(url)
	elif mode==215: results = l1ll11l11l1l_l1_(url)
	elif mode==218: results = l1l11l11111_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l1l11l11111_l1_():
	message = l1l1ll_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭䵿")
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䶀"),l1l1ll_l1_ (u"ࠪࠫ䶁"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䶂"),l1l1ll_l1_ (u"ࠬอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠫ䶃"),message)
	return
def MENU():
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䶄"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䶅"),l1l1ll_l1_ (u"ࠨࠩ䶆"),219,l1l1ll_l1_ (u"ࠩࠪ䶇"),l1l1ll_l1_ (u"ࠪࠫ䶈"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䶉"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䶊"),menu_name+l1l1ll_l1_ (u"࠭แๅฬิࠫ䶋"),l1l1ll_l1_ (u"ࠧࠨ䶌"),114,l1l1l1_l1_)
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡔ࡮ࡴ࠿ࡵࡻࡳࡩࡂࡵ࡮ࡦࠨࡧࡥࡹࡧ࠽ࡱ࡫ࡱࠪࡱ࡯࡭ࡪࡶࡀ࠶࠺࠭䶍")
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䶎"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䶏")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䶐"),url,211)
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭䶑"),headers,l1l1ll_l1_ (u"࠭ࠧ䶒"),l1l1ll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䶓"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡴࡄࡸࡸࡹࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䶔"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶕"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࠧ䶖")+link
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䶗"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䶘")+menu_name+title,url,211)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䶙"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䶚"),block,re.DOTALL)
	l1ll11_l1_ = [l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢส๊๊๐ࠧ䶛"),l1l1ll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ䶜")]
	#l111lllll_l1_ = [l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤࠬ䶝"),l1l1ll_l1_ (u"ࠫฬ็ไศ็ࠣࠫ䶞"),l1l1ll_l1_ (u"ࠬฮัศ็ฯࠫ䶟"),l1l1ll_l1_ (u"ู࠭าู๊ࠫ䶠"),l1l1ll_l1_ (u"ࠧไๆํฬฬะࠧ䶡"),l1l1ll_l1_ (u"ࠨษ฽ห๋๏ࠧ䶢")]
	for link,title in items:
		title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ䶣"))
		if not any(value in title for value in l1ll11_l1_):
		#	if any(value in title for value in l111lllll_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䶤"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䶥")+menu_name+title,link,211)
	return html
def l11l1l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠬ࠭䶦"),headers,l1l1ll_l1_ (u"࠭ࠧ䶧"),l1l1ll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ䶨"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䶩"),l1l1ll_l1_ (u"ࠩࠪ䶪"),url,html)
	if l1l1ll_l1_ (u"ࠪ࡫ࡪࡺࡰࡰࡵࡷࡷࠬ䶫") in url or l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ䶬") in url: block = html
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ䶭"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		else: return
	items = re.findall(l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䶮"),block,re.DOTALL)
	l1l1_l1_ = []
	l11l1l1ll_l1_ = [l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠧ䶯"),l1l1ll_l1_ (u"ࠨใํ่๊࠭䶰"),l1l1ll_l1_ (u"ࠩส฾๋๐ษࠨ䶱"),l1l1ll_l1_ (u"ࠪ็้๐ศࠨ䶲"),l1l1ll_l1_ (u"ࠫฬ฿ไศ่ࠪ䶳"),l1l1ll_l1_ (u"ࠬํฯศใࠪ䶴"),l1l1ll_l1_ (u"࠭ๅษษิหฮ࠭䶵"),l1l1ll_l1_ (u"ฺࠧำูࠫ䶶"),l1l1ll_l1_ (u"ࠨ็๊ีัอๆࠨ䶷"),l1l1ll_l1_ (u"ࠩส่อ๎ๅࠨ䶸")]
	for img,link,title in items:
		if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䶹") in link: continue
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠫ࠴࠭䶺"))
		title = unescapeHTML(title)
		title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ䶻"))
		if l1l1ll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭䶼") in link or any(value in title for value in l11l1l1ll_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䶽"),menu_name+title,link,212,img)
		elif l1l1ll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ䶾") in link and l1l1ll_l1_ (u"ࠩส่า๊โสࠩ䶿") in title:
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭䷀"),title,re.DOTALL)
			if l11111_l1_:
				title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䷁") + l11111_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷂"),menu_name+title,link,213,img)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䷃"),menu_name+title,link,213,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䷄"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䷅"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"ࠩสฺ่็อสࠢࠪ䷆"),l1l1ll_l1_ (u"ࠪࠫ䷇"))
			if title!=l1l1ll_l1_ (u"ࠫࠬ䷈"): addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷉"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ䷊")+title,link,211)
	return
def l11ll1l_l1_(url):
	l11l1lll1_l1_,items,l11l11l1_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠧࠨ䷋"),headers,l1l1ll_l1_ (u"ࠨࠩ䷌"),l1l1ll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䷍"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䷎"),html,re.DOTALL)
	if l1lll11_l1_:
		l1l1l11_l1_ = l1l1ll_l1_ (u"ࠫࠬ䷏").join(l1lll11_l1_)
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䷐"),l1l1l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l1ll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ䷑"))
	for link in items:
		link = link.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ䷒"))
		title = l1l1ll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䷓") + link.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ䷔"))[-1].replace(l1l1ll_l1_ (u"ࠪ࠱ࠬ䷕"),l1l1ll_l1_ (u"ࠫࠥ࠭䷖"))
		l11l1ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫ䷗"),link.split(l1l1ll_l1_ (u"࠭࠯ࠨ䷘"))[-1],re.DOTALL)
		if l11l1ll1_l1_: l11l1ll1_l1_ = l11l1ll1_l1_[0]
		else: l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠧ࠱ࠩ䷙")
		l11l11l1_l1_.append([link,title,l11l1ll1_l1_])
	items = sorted(l11l11l1_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l1ll11_l1_ = str(items).count(l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ䷚"))
	l11l1lll1_l1_ = str(items).count(l1l1ll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ䷛"))
	if l11l1ll11_l1_>1 and l11l1lll1_l1_>0 and l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ䷜") not in url:
		for link,title,l11l1ll1_l1_ in items:
			if l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭䷝") in link: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䷞"),menu_name+title,link,213)
	else:
		for link,title,l11l1ll1_l1_ in items:
			if l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ䷟") not in link: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䷠"),menu_name+title,link,212)
	return
def PLAY(url):
	l11l1_l1_ = []
	parts = url.split(l1l1ll_l1_ (u"ࠨ࠱ࠪ䷡"))
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䷢"),headers,l1l1ll_l1_ (u"ࠪࠫ䷣"),l1l1ll_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䷤"))
	# l11lllll1_l1_ l1ll_l1_
	if l1l1ll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭䷥") in html:
		url2 = url.replace(parts[3],l1l1ll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ䷦"))
		l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"ࠧࠨ䷧"),headers,l1l1ll_l1_ (u"ࠨࠩ䷨"),l1l1ll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ䷩"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䷪"),l1l11ll1_l1_,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ䷫"),block,re.DOTALL)
			if items:
				id = re.findall(l1l1ll_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭䷬"),l1l11ll1_l1_,re.DOTALL)
				if id:
					id2 = id[0]
					for link,title in items:
						link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩ䷭")+id2+l1l1ll_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ䷮")+link+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䷯")+title+l1l1ll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䷰")
						l11l1_l1_.append(link)
			else:
				# l1lll11l_l1_://l1ll11l11ll1_l1_.tv/l11lllll1_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ䷱"),block,re.DOTALL)
				for link,dummy in items:
					l11l1_l1_.append(link)
	# download l1ll_l1_
	if l1l1ll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䷲") in html:
		url2 = url.replace(parts[3],l1l1ll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䷳"))
		l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"࠭ࠧ䷴"),headers,l1l1ll_l1_ (u"ࠧࠨ䷵"),l1l1ll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ䷶"))
		id = re.findall(l1l1ll_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䷷"),l1l11ll1_l1_,re.DOTALL)
		if id:
			id2 = id[0]
			headers2 = { l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䷸"):l1l1ll_l1_ (u"ࠫࠬ䷹") , l1l1ll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䷺"):l1l1ll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䷻") }
			url2 = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪ䷼")+id2
			l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"ࠨࠩ䷽"),headers2,l1l1ll_l1_ (u"ࠩࠪ䷾"),l1l1ll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ䷿"))
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭一"),l1l11ll1_l1_,re.DOTALL)
			if l1lll11_l1_:
				for resolution,block in l1lll11_l1_:
					items = re.findall(l1l1ll_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ丁"),block,re.DOTALL)
					for name,link in items:
						l11l1_l1_.append(link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ丂")+name+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ七")+l1l1ll_l1_ (u"ࠨࡡࡢࡣࡤ࠭丄")+resolution)
			else:
				l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿࡬࠻࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ丅"),l1l11ll1_l1_,re.DOTALL)
				if not l1lll11_l1_: l1lll11_l1_ = [l1l11ll1_l1_]
				for block in l1lll11_l1_:
					l1l1ll_l1_ (u"ࠥࠦࠧࠐࠉࠊࠋࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡩࡷࡼࡥࡳࡵࡗ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠋࠋࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࡠ࠳࠱࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫฬ๊ฯใหࠣࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠌࠍ࡮࡬ࠠ࡯ࡣࡰࡩࠦࡃࠧࠨ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࠫࠥๆࠠࠨࠌࠌࠍࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦࠧࠨࠌࠌࠍࠎࠏࠉࠣࠤࠥ丆")
					name = l1l1ll_l1_ (u"ࠫࠬ万")
					items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ丈"),block,re.DOTALL)
					for link in items:
						server = l1l1ll_l1_ (u"࠭ࠦࠧࠩ三") + link.split(l1l1ll_l1_ (u"ࠧ࠰ࠩ上"))[2].lower() + l1l1ll_l1_ (u"ࠨࠨࠩࠫ下")
						server = server.replace(l1l1ll_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ丌"),l1l1ll_l1_ (u"ࠪࠫ不")).replace(l1l1ll_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ与"),l1l1ll_l1_ (u"ࠬ࠭丏"))
						server = server.replace(l1l1ll_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭丐"),l1l1ll_l1_ (u"ࠧࠨ丑")).replace(l1l1ll_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ丒"),l1l1ll_l1_ (u"ࠩࠪ专"))
						server = server.replace(l1l1ll_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ且"),l1l1ll_l1_ (u"ࠫࠬ丕")).replace(l1l1ll_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ世"),l1l1ll_l1_ (u"࠭ࠧ丗"))
						server = server.replace(l1l1ll_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭丘"),l1l1ll_l1_ (u"ࠨࠩ丙")).replace(l1l1ll_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ业"),l1l1ll_l1_ (u"ࠪࠫ丛"))
						server = server.replace(l1l1ll_l1_ (u"ࠫࠫࠬࠧ东"),l1l1ll_l1_ (u"ࠬ࠭丝"))
						link = link + l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ丞") + name + server + l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ丟")
						l11l1_l1_.append(link)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ丠"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠩࠪ両"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠪࠫ丢"): return
	search = search.replace(l1l1ll_l1_ (u"ࠫࠥ࠭丣"),l1l1ll_l1_ (u"ࠬ࠱ࠧ两"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ严")+search
	l11l1l_l1_(url)
	return
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠡࡵࡨࡧࡴࡴࡤࡢࡴࡼࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡧࡦࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧ࡭࡫ࡣ࡬࡯ࡤࡶࡰ࠳ࡢࡰ࡮ࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠮ࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࠋࡩࡳࡷࠦࡣࡢࡶࡨ࡫ࡴࡸࡹ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡩࡡࡵࡧࡪࡳࡷࡿࠩࠋࠋࠌࠍ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩ࠯ࠤ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠪࠌࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲ࠢ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ࠯ࡸ࡫ࡡࡳࡥ࡫࠯ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ࠮ࡧࡦࡺࡥࡨࡱࡵࡽࠏࠏࠉࡕࡋࡗࡐࡊ࡙ࠨࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ並")
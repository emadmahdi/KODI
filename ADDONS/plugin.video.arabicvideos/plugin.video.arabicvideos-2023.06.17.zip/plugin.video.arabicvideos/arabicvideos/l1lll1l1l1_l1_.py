# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
#l1l1l1_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡩࡦ࠱࠸࡭࡫࡬ࡢ࡮࠱ࡸࡻ࠭ᦗ")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࠶࡫ࡩࡱࡧ࡬࠯ࡶࡹࠫᦘ")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࠴ࡩࡧ࡯ࡥࡱ࠴ࡴࡷࠩᦙ")
script_name = l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫᦚ")
headers = { l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᦛ") : l1l1ll_l1_ (u"ࠫࠬᦜ") }
menu_name = l1l1ll_l1_ (u"ࠬࡥࡃࡎࡈࡢࠫᦝ")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1111ll1_l1_()
	elif mode==95: results = l11ll1l_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦞ"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧᦟ"),l1l1ll_l1_ (u"ࠨࠩᦠ"),99,l1l1ll_l1_ (u"ࠩࠪᦡ"),l1l1ll_l1_ (u"ࠪࠫᦢ"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᦣ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᦤ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᦥ"),l1l1ll_l1_ (u"ࠧࠨᦦ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᦧ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᦨ")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩᦩ"),l1l1ll_l1_ (u"ࠫࠬᦪ"),94)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦫ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᦬")+menu_name+l1l1ll_l1_ (u"ࠧศๆฦัิัࠧ᦭"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮ࡤࡸࡪࡹࡴࠨ᦮"),91)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᦯"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᦰ")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊รฺๆ์ࠤฯ่๊ๆษ๎ࠫᦱ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂ࡯࡭ࡥࡤࠪᦲ"),91)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦳ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᦴ")+menu_name+l1l1ll_l1_ (u"ࠨษ็ว่ััࠡ็ืห์ีษࠨᦵ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡹ࡭ࡪࡽࠧᦶ"),91)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦷ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᦸ")+menu_name+l1l1ll_l1_ (u"ࠬอไๆอหฮࠬᦹ"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡰࡪࡰࠪᦺ"),91)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᦻ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᦼ")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨᦽ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡲࡪࡽࡍࡰࡸ࡬ࡩࡸ࠭ᦾ"),91)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦿ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᧀ")+menu_name+l1l1ll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮࠬᧁ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡯ࡧࡺࡉࡵ࡯ࡳࡰࡦࡨࡷࠬᧂ"),91)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᧃ"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᧄ"),l1l1ll_l1_ (u"ࠪࠫᧅ"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᧆ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᧇ")+menu_name+l1l1ll_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫᧈ"),l1l1l1_l1_,91)
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨᧉ"),headers,l1l1ll_l1_ (u"ࠨࠩ᧊"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᧋"))
	#upper l1lll1l11l_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡦ࡯࡮࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫࡱࡥࡻ࠭᧌"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᧍"),block,re.DOTALL)
	l1ll11_l1_ = [l1l1ll_l1_ (u"ࠬอแๅษ่ࠤ้๊ใษษิࠤๆ่ืࠨ᧎")]
	for link,title in items:
		title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ᧏"))
		if not any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᧐"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᧑")+menu_name+title,link,91)
	return html
def ITEMS(url):
	if l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶࠧ᧒") in url:
		url,search = url.split(l1l1ll_l1_ (u"ࠪࡃࡹࡃࠧ᧓"))
		headers = { l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᧔") : l1l1ll_l1_ (u"ࠬ࠭᧕") , l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ᧖") : l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭᧗") }
		data = { l1l1ll_l1_ (u"ࠨࡶࠪ᧘") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ᧙"),url,data,headers,l1l1ll_l1_ (u"ࠪࠫ᧚"),l1l1ll_l1_ (u"ࠫࠬ᧛"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ᧜"))
		html = response.content
	else:
		headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᧝") : l1l1ll_l1_ (u"ࠧࠨ᧞") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠨࠩ᧟"),headers,l1l1ll_l1_ (u"ࠩࠪ᧠"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡏࡔࡆࡏࡖ࠱࠷ࡴࡤࠨ᧡"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳ࠮࡫ࡷࡩࡲࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵࡨࡲࡳࡹࠨࠧ᧢"),html,re.DOTALL)
	if l1lll11_l1_: block = l1lll11_l1_[0]
	else: block = l1l1ll_l1_ (u"ࠬ࠭᧣")
	items = re.findall(l1l1ll_l1_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡲࡵࡶࡪࡧ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᧤"),block,re.DOTALL)
	l1l1_l1_ = []
	for img,link,title in items:
		if l1l1ll_l1_ (u"ࠧศๆะ่็ฯࠧ᧥") in title and l1l1ll_l1_ (u"ࠨ࠱ࡦ࠳ࠬ᧦") not in url and l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺ࠯ࠨ᧧") not in url:
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡞࠴࠲࠿࡝ࠬࠩ᧨"),title,re.DOTALL)
			if l11111_l1_:
				title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ᧩")+l11111_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᧪"),menu_name+title,link,95,img)
					l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ᧫") in link: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᧬"),menu_name+title,link,92,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧭"),menu_name+title,link,91,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ᧮"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᧯"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ᧰"),l1l1ll_l1_ (u"ࠬ࠭᧱"))
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᧲"),menu_name+l1l1ll_l1_ (u"ࠧึใะอࠥ࠭᧳")+title,link,91)
	return
def l11ll1l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠨࠩ᧴"),headers,l1l1ll_l1_ (u"ࠩࠪ᧵"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ᧶"))
	img = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᧷"),html,re.DOTALL)
	img = img[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ᧸"),html,re.DOTALL)
	if l1lll11_l1_:
		name = re.findall(l1l1ll_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᧹"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ᧺"))
			if l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᧻") in name: name = name.split(l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᧼"),1)[1]
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᧽"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᧾"),menu_name+name+l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩ᧿")+title,link,92,img)
	else:
		tmp = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡰࡸ࡬ࡩࡹ࡯ࡴ࡭ࡧࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᨀ"),html,re.DOTALL)
		if tmp: link,title = tmp[0]
		else: link,title = url,name
		addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᨁ"),menu_name+title,link,92,img)
	return
def PLAY(url):
	l11l1_l1_,l1lll1l111_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠨࠩᨂ"),headers,l1l1ll_l1_ (u"ࠩࠪᨃ"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᨄ"))
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵ࠯ࡶ࡬ࡦࡪ࡯ࡸ࠼ࠣࡲࡴࡴࡥ࠼ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᨅ"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨᨆ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᨇ"),block,re.DOTALL)
		for link in items:
			link = link+l1l1ll_l1_ (u"ࠧࡀࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᨈ")
			l11l1_l1_.append(link)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡰࡤࡺ࠲ࡺࡡࡣࡵࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵ࠭ࡱࡣࡱࡩࡱ࠳࡭ࡰࡴࡨࠫᨉ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		# l11lllll1_l1_ l1ll_l1_
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡧࡰࡦࡪࡪࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᨊ"),block,re.DOTALL)
		for id,link in items:
			title = l1l1ll_l1_ (u"ࠪื๏ืแาࠢࠪᨋ")+id
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᨌ")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᨍ")
			l11l1_l1_.append(link)
		# other l1ll_l1_
		items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨎ"),block,re.DOTALL)
		for link in items:
			if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬᨏ") not in link: link = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᨐ")+link
			link = UNQUOTE(link)
			l11l1_l1_.append(link)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᨑ"),url)
	return
def l1111ll1_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫᨒ"),headers,l1l1ll_l1_ (u"ࠫࠬᨓ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡍࡃࡗࡉࡘ࡚࠭࠲ࡵࡷࠫᨔ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥ࡭ࡳࡪࡥࡹ࠯࡯ࡥࡸࡺ࠭࡮ࡱࡹ࡭ࡪ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡪࡰࡧࡩࡽ࠳ࡳ࡭࡫ࡧࡩࡷ࠳࡭ࡰࡸ࡬ࡩࠬᨕ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᨖ"),block,re.DOTALL)
	for img,link,title in items:
		if l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩᨗ") in link: addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᨘ"),menu_name+title,link,92,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨙ"),menu_name+title,link,91,img)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬᨚ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭ᨛ"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ᨜"),l1l1ll_l1_ (u"ࠧࠬࠩ᨝"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࡴ࠾ࠩ᨞")+search
	ITEMS(url)
	return
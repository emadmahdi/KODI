# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㏪")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ㏫")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ㏬"),l1l1ll_l1_ (u"ࠧศีอๅุอัหๅ่ࠤํࠦวๅู็ฬฬะࠧ㏭")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l11l1l_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lllll111_l1_(url)
	elif mode==454: results = l11ll1l_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ㏮"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ㏯"),l1l1ll_l1_ (u"ࠪࠫ㏰"),l1l1ll_l1_ (u"ࠫࠬ㏱"),l1l1ll_l1_ (u"ࠬ࠭㏲"),l1l1ll_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㏳"))
	html = response.content
	l11ll1_l1_ = SERVER(l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ㏴"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㏵"),menu_name+l1l1ll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ㏶"),l1l1ll_l1_ (u"ࠪࠫ㏷"),459,l1l1ll_l1_ (u"ࠫࠬ㏸"),l1l1ll_l1_ (u"ࠬ࠭㏹"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㏺"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㏻"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㏼")+menu_name+l1l1ll_l1_ (u"่ࠩฯอะวหࠢ็์ิ๐ࠠ็ฬࠪ㏽"),l11ll1_l1_,451,l1l1ll_l1_ (u"ࠪࠫ㏾"),l1l1ll_l1_ (u"ࠫࠬ㏿"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㐀"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐁"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㐂")+menu_name+l1l1ll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ㐃"),l11ll1_l1_,451,l1l1ll_l1_ (u"ࠩࠪ㐄"),l1l1ll_l1_ (u"ࠪࠫ㐅"),l1l1ll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ㐆"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐇"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㐈")+menu_name+l1l1ll_l1_ (u"ࠧๆ็ฮ่๏์ࠧ㐉"),l11ll1_l1_,451,l1l1ll_l1_ (u"ࠨࠩ㐊"),l1l1ll_l1_ (u"ࠩࠪ㐋"),l1l1ll_l1_ (u"ࠪࡥࡨࡺ࡯ࡳࡵࠪ㐌"))
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㐍"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㐎")+menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะ่่ࠠา๎ฮ࠭㐏"),l11ll1_l1_,451,l1l1ll_l1_ (u"ࠧࠨ㐐"),l1l1ll_l1_ (u"ࠨࠩ㐑"),l1l1ll_l1_ (u"ࠩ࠳ࠫ㐒"))
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㐓"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㐔")+menu_name+l1l1ll_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอ๋ࠥฯษๆฯอࠬ㐕"),l11ll1_l1_,451,l1l1ll_l1_ (u"࠭ࠧ㐖"),l1l1ll_l1_ (u"ࠧࠨ㐗"),l1l1ll_l1_ (u"ࠨ࠳ࠪ㐘"))
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㐙"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㐚")+menu_name+l1l1ll_l1_ (u"ࠫฬ็ไศ็๋๋ࠣี๊สࠩ㐛"),l11ll1_l1_,451,l1l1ll_l1_ (u"ࠬ࠭㐜"),l1l1ll_l1_ (u"࠭ࠧ㐝"),l1l1ll_l1_ (u"ࠧ࠳ࠩ㐞"))
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㐟"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㐠"),l1l1ll_l1_ (u"ࠪࠫ㐡"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡓࡡࡪࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠫ㐢"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㐣"),block,re.DOTALL)
		for link,title in items:
			if link==l1l1ll_l1_ (u"࠭ࠣࠨ㐤"): continue
			if title in l1ll11_l1_: continue
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐥"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㐦")+menu_name+title,link,451)
	return
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"ࠩࠪ㐧")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㐨"),l1l1ll_l1_ (u"ࠫࠬ㐩"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ㐪"),url,l1l1ll_l1_ (u"࠭ࠧ㐫"),l1l1ll_l1_ (u"ࠧࠨ㐬"),l1l1ll_l1_ (u"ࠨࠩ㐭"),l1l1ll_l1_ (u"ࠩࠪ㐮"),l1l1ll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㐯"))
	html = response.content
	if l1111ll11_l1_==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㐰"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡺࡥࡻ࡫ࡳࠣࠩ㐱"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	elif l1111ll11_l1_==l1l1ll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㐲"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡔࡨࡧࡪࡴࡴࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ㐳"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	elif l1l1ll_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠧ㐴") in html:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ㐵"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࠢࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㐶"),block,re.DOTALL)
	elif l1111ll11_l1_ in [l1l1ll_l1_ (u"ࠫ࠵࠭㐷"),l1l1ll_l1_ (u"ࠬ࠷ࠧ㐸"),l1l1ll_l1_ (u"࠭࠲ࠨ㐹")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫ㐺"),html,re.DOTALL)
		block = l1lll11_l1_[int(l1111ll11_l1_)]
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㐻"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㐼"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ู้ࠪอ็ะหࠪ㐽"),l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩ㐾"),l1l1ll_l1_ (u"ࠬอฺ็์ฬࠫ㐿"),l1l1ll_l1_ (u"࠭ร฻่ํอࠬ㑀"),l1l1ll_l1_ (u"ࠧไๆํฬࠬ㑁"),l1l1ll_l1_ (u"ࠨษ฼่ฬ์ࠧ㑂"),l1l1ll_l1_ (u"๊ࠩำฬ็ࠧ㑃"),l1l1ll_l1_ (u"้ࠪออัศหࠪ㑄"),l1l1ll_l1_ (u"ࠫ฾ืึࠨ㑅"),l1l1ll_l1_ (u"๋ࠬ็าฮส๊ࠬ㑆"),l1l1ll_l1_ (u"࠭วๅส๋้ࠬ㑇")]
	for link,img,title in items:
		if l1l1ll_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㑈") in html and l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂ࠭㑉") in img:
			img = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㑊"),img,re.DOTALL)
			img = img[0]
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ㑋"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ㑌"),title,re.DOTALL)
		if not l11111_l1_: l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ㑍"),title,re.DOTALL)
		#if any(value in title for value in l111l_l1_):
		if set(title.split()) & set(l111l_l1_) and l1l1ll_l1_ (u"࠭ๅิๆึ่ࠬ㑎") not in title:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㑏"),menu_name+title,link,452,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠨฯ็ๆฮ࠭㑐") in title:
			title = l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ㑑") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㑒"),menu_name+title,link,453,img)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑓"),menu_name+title,link,453,img)
	if l1111ll11_l1_ in [l1l1ll_l1_ (u"ࠬ࠭㑔"),l1l1ll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㑕")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㑖"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㑗"),block,re.DOTALL)
			for link,title in items:
				#if link==l1l1ll_l1_ (u"ࠤࠥ㑘"): continue
				title = unescapeHTML(title)
				#if title!=l1l1ll_l1_ (u"ࠪࠫ㑙"):
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑚"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ㑛")+title,link,451)
	return
def l1lllll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ㑜"),url,l1l1ll_l1_ (u"ࠧࠨ㑝"),l1l1ll_l1_ (u"ࠨࠩ㑞"),l1l1ll_l1_ (u"ࠩࠪ㑟"),l1l1ll_l1_ (u"ࠪࠫ㑠"),l1l1ll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㑡"))
	html = response.content
	# l11l11_l1_
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡔࡷࡥࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㑢"),html,re.DOTALL)
	if l1ll1ll_l1_ and l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬ㑣") in str(l1ll1ll_l1_):
		title = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮࠳ࠧ㑤"),html,re.DOTALL)
		title = title[0].strip(l1l1ll_l1_ (u"ࠨࠢࠪ㑥"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑦"),menu_name+title,url,454)
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㑧"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑨"),menu_name+title,link,454)
	else: l11ll1l_l1_(url)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ㑩"),url,l1l1ll_l1_ (u"࠭ࠧ㑪"),l1l1ll_l1_ (u"ࠧࠨ㑫"),l1l1ll_l1_ (u"ࠨࠩ㑬"),l1l1ll_l1_ (u"ࠩࠪ㑭"),l1l1ll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㑮"))
	html = response.content
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ㑯"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ㑰"),block,re.DOTALL)
		for link,img,title in items:
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㑱"),menu_name+title,link,452,img)
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㑲"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㑳"),block,re.DOTALL)
			for link,title in items:
				#if link==l1l1ll_l1_ (u"ࠤࠥ㑴"): continue
				title = unescapeHTML(title)
				#if title!=l1l1ll_l1_ (u"ࠪࠫ㑵"):
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㑶"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ㑷")+title,link,454)
	return
def PLAY(url):
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ㑸"),l1l1ll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ㑹"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ㑺"),l1l1ll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ㑻"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ㑼"),url2,l1l1ll_l1_ (u"ࠫࠬ㑽"),l1l1ll_l1_ (u"ࠬ࠭㑾"),l1l1ll_l1_ (u"࠭ࠧ㑿"),l1l1ll_l1_ (u"ࠧࠨ㒀"),l1l1ll_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㒁"))
	html = response.content
	l11ll1_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭㒂"))
	l11l1_l1_ = []
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡗ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡶ࡭ࡩ࡫࠾ࠨ㒃"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭㒄"),block,re.DOTALL)
		for link,title in items:
			link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㒅")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ㒆")
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡴࡧ࡯ࡥࡷࡿࠢࠨ㒇"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ㒈"),block,re.DOTALL)
		for link,name in items:
			name = unescapeHTML(name)
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ㒉"),name,re.DOTALL)
			if l11ll1l1_l1_:
				l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ㒊")+l11ll1l1_l1_[0]
				name = l1l1ll_l1_ (u"ࠫࠬ㒋")
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭㒌")
			link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㒍")+name+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㒎")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㒏"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㒐"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠪࠫ㒑"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠫࠬ㒒"): return
	search = search.replace(l1l1ll_l1_ (u"ࠬࠦࠧ㒓"),l1l1ll_l1_ (u"࠭ࠫࠨ㒔"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ㒕")+search
	l11l1l_l1_(url)
	return
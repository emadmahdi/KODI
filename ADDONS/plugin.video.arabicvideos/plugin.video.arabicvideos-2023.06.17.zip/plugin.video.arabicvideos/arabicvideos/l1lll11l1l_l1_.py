# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ᨟")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡈࡓࡌࡠࠩᨠ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠫ็์่ศฬࠣๅ฻อฦ๋หࠪᨡ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l11l1l_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l11ll1l_l1_(url,text)
	elif mode==474: results = l1ll1l_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩᨢ"),l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧᨣ"),l1l1ll_l1_ (u"ࠧࠨᨤ"),l1l1ll_l1_ (u"ࠨࠩᨥ"),l1l1ll_l1_ (u"ࠩࠪᨦ"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᨧ"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡻࡲ࡭ࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᨨ"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠬ࠵ࠧᨩ"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪᨪ"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᨫ"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᨬ"),l1l1ll_l1_ (u"ࠩࠪᨭ"),479,l1l1ll_l1_ (u"ࠪࠫᨮ"),l1l1ll_l1_ (u"ࠫࠬᨯ"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᨰ"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨱ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᨲ"),l1l1ll_l1_ (u"ࠨࠩᨳ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᨴ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᨵ")+menu_name+l1l1ll_l1_ (u"ࠫศ็ไศ็้๊ࠣ๐าสࠩᨶ"),l11ll1_l1_,471,l1l1ll_l1_ (u"ࠬ࠭ᨷ"),l1l1ll_l1_ (u"࠭ࠧᨸ"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩᨹ"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᨺ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᨻ")+menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤ๊๋๊ำหࠪᨼ"),l11ll1_l1_,471,l1l1ll_l1_ (u"ࠫࠬᨽ"),l1l1ll_l1_ (u"ࠬ࠭ᨾ"),l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᨿ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᩀ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᩁ"),block,re.DOTALL)
	for link,title in items:
		title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫᩂ"))
		#if title in l1ll11_l1_: continue
		link = link.replace(l1l1ll_l1_ (u"ࠪࡧࡦࡺ࠽ࡰࡰ࡯࡭ࡳ࡫࠭࡮ࡱࡹ࡭ࡪࡹ࠱ࠨᩃ"),l1l1ll_l1_ (u"ࠫࡨࡧࡴ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳࠨᩄ"))
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩅ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᩆ")+menu_name+title,link,474)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩇ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᩈ"),l1l1ll_l1_ (u"ࠩࠪᩉ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧᩊ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤᩋ"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_:
		block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠬ࠭ᩌ"))
	items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᩍ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		#link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࡂࠫᩎ")+category+l1l1ll_l1_ (u"ࠨ࠿ࠪᩏ")+value
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᩐ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᩑ")+menu_name+title,link,474)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᩒ"),url,l1l1ll_l1_ (u"ࠬ࠭ᩓ"),l1l1ll_l1_ (u"࠭ࠧᩔ"),l1l1ll_l1_ (u"ࠧࠨᩕ"),l1l1ll_l1_ (u"ࠨࠩᩖ"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᩗ"))
	html = response.content
	if l1l1ll_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪᩘ") in url: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡰ࡮࠯ࡪࡶ࡮ࡪࠢࠨᩙ"),html,re.DOTALL)
	else: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᩚ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᩛ"),block,re.DOTALL)
		for link,title in items:
			if l1l1ll_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶࠧᩜ") in link:
				if l1l1ll_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡩࡳ࡭࡬ࡪࡵ࡫࠱ࡲࡵࡶࡪࡧࡶࠫᩝ") in link: continue
				if l1l1ll_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶ࠵ࠬᩞ") in link: continue
				if l1l1ll_l1_ (u"ࠪࡸࡴࡶࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࡂࡧࡂࡳࡩࡴࡥࠪ᩟") in link: continue
				if l1l1ll_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࡃࡨࡃࡴࡷ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮᩠ࠪ") in link: continue
				if l1l1ll_l1_ (u"๋ࠬๆัࠢส่อีว๋หࠪᩡ") in title and l1l1ll_l1_ (u"࠭ࡤࡰ࠿ࡵࡥࡹ࡯࡮ࡨࠩᩢ") not in link: continue
			else: title = l1l1ll_l1_ (u"ࠧหำอ๎อࠦศศีอาิอๅ࠻ࠢࠣࠫᩣ")+title
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩤ"),menu_name+title,link,471)
	else: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠩࠪᩥ")):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧᩦ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᩧ"),url,l1l1ll_l1_ (u"ࠬ࠭ᩨ"),l1l1ll_l1_ (u"࠭ࠧᩩ"),l1l1ll_l1_ (u"ࠧࠨᩪ"),l1l1ll_l1_ (u"ࠨࠩᩫ"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᩬ"))
	html = response.content
	items = []
	if request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬᩭ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮ࡨ࡯ࡹ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᩮ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠩᩯ"),block,re.DOTALL)
		l1ll_l1_,titles,l1lll11lll_l1_ = zip(*items)
		items = zip(l1lll11lll_l1_,l1ll_l1_,titles)
	elif request==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᩰ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧศๆ่ืู้ไศฬࠣห้๋ๅ๋ิฬࠬ࠳࠰࠿ࠪ࠾ࡶࡸࡾࡲࡥ࠿ࠩᩱ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᩲ"),block,re.DOTALL)
		l1ll_l1_,titles,l1lll11lll_l1_ = zip(*items)
		items = zip(l1lll11lll_l1_,l1ll_l1_,titles)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᩳ"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪᩴ"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᩵"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᩶"),html,re.DOTALL)
		if not l1lll11_l1_: return
		block = l1lll11_l1_[0]
	if not items: items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᩷"),block,re.DOTALL)
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᩸"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ࠨ็ืห์ีษࠨ᩹"),l1l1ll_l1_ (u"ࠩไ๎้๋ࠧ᩺"),l1l1ll_l1_ (u"ࠪห฿์๊สࠩ᩻"),l1l1ll_l1_ (u"่๊๊ࠫษࠩ᩼"),l1l1ll_l1_ (u"ࠬอูๅษ้ࠫ᩽"),l1l1ll_l1_ (u"࠭็ะษไࠫ᩾"),l1l1ll_l1_ (u"ࠧๆสสีฬฯ᩿ࠧ"),l1l1ll_l1_ (u"ࠨ฻ิฺࠬ᪀"),l1l1ll_l1_ (u"่๋ࠩึาว็ࠩ᪁"),l1l1ll_l1_ (u"ࠪห้ฮ่ๆࠩ᪂"),l1l1ll_l1_ (u"ู๊ࠫัฮ์ฬࠫ᪃")]
	for img,link,title in items:
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ᪄"))
		if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ᪅") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ᪆")+link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ᪇"))
		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ᪈") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ᪉")+img.strip(l1l1ll_l1_ (u"ࠫ࠴࠭᪊"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ᪋"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ᪌"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᪍"),menu_name+title,link,472,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠨษ็ั้่ษࠨ᪎") in title:
			title = l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ᪏") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪐"),menu_name+title,link,473,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ᪑") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪒"),menu_name+title,link,471,img)
		else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪓"),menu_name+title,link,473,img)
	if request not in [l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ᪔"),l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ᪕")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᪖"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᪗"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠫࠨ࠭᪘"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧ᪙")+link.strip(l1l1ll_l1_ (u"࠭࠯ࠨ᪚"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪛"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦࠧ᪜")+title,link,471)
		l1111l111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᪝"),html,re.DOTALL)
		if l1111l111_l1_:
			link = l1111l111_l1_[0]
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪞"),menu_name+l1l1ll_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ᪟"),link,471)
	return
def l11ll1l_l1_(url,l1lll_l1_):
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭᪠"),l1l1ll_l1_ (u"࠭࠱࠲࠳࠴ࠤࠥ࠭᪡")+url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ᪢"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ᪣"),url,l1l1ll_l1_ (u"ࠩࠪ᪤"),l1l1ll_l1_ (u"ࠪࠫ᪥"),l1l1ll_l1_ (u"ࠫࠬ᪦"),l1l1ll_l1_ (u"ࠬ࠭ᪧ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ᪨"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ᪩"),html,re.DOTALL)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭᪪")+l1lll_l1_+l1l1ll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᪫"),html,re.DOTALL)
	items = []
	# l11l11_l1_
	if l1ll1ll_l1_ and not l1lll_l1_:
		img = re.findall(l1l1ll_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᪬"),html,re.DOTALL)
		img = img[0]
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹࡢࠬࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨ᪭"),block,re.DOTALL)
		for l1lll_l1_,title in items: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪮"),menu_name+title,url,473,img,l1l1ll_l1_ (u"࠭ࠧ᪯"),l1lll_l1_)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		#img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨ᪰"))
		img = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᪱"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠤࡷ࡭ࡹࡲࡥ࠾ࠩࠫ࠲࠯ࡅࠩࠨࠢ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧࠣ᪲"),block,re.DOTALL)
		if items:
			for title,link in items:
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ᪳")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭᪴"))
				addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲ᪵ࠫ"),menu_name+title,link,472,img)
		else:
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯᪶ࠧ"),block,re.DOTALL)
			for link,title,img in items:
				if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ᪷ࠬ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱᪸ࠪ")+link.strip(l1l1ll_l1_ (u"ࠩ࠲᪹ࠫ"))
				addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ᪺ࠩ"),menu_name+title,link,472,img)
	if l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠭᪻") in html:
		if items: addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᪼"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᪽࠭"),l1l1ll_l1_ (u"ࠧࠨ᪾"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᪿ"),menu_name+l1l1ll_l1_ (u"่ࠩ์ฬ฼ฺ๊ࠢำหฯࠦีๅหᫀࠪ"),url,471)
	#else: l11l1l_l1_(url)
	return
def PLAY(url):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ᫁"))
	l11l1_l1_ = []
	# l1lll11ll1_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ᫂"),url,l1l1ll_l1_ (u"᫃ࠬ࠭"),l1l1ll_l1_ (u"᫄࠭ࠧ"),l1l1ll_l1_ (u"ࠧࠨ᫅"),l1l1ll_l1_ (u"ࠨࠩ᫆"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ᫇"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩࡲ࠾ࠨ᫈"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᫉"),block,re.DOTALL)
		if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_,True): return
	# default l11lllll1_l1_ link
	link = re.findall(l1l1ll_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᫊ࠫࠥࠫ"),html,re.DOTALL)
	if link:
		link = link[0]+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧ᫋")
		if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬᫌ") not in link: link = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᫍ")+link
		l11l1_l1_.append(link)
	# l1l1l1l11_l1_ l11lllll1_l1_ link
	link = re.findall(l1l1ll_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡗࡕࡐࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᫎ"),html,re.DOTALL)
	if link:
		link = link[0]+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࡫࡭ࡣࡧࡧࠫ᫏")
		if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᫐") not in link: link = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᫑")+link
		l11l1_l1_.append(link)
	# l11lllll1_l1_ l1ll_l1_
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ᫒"),l1l1ll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪ᫓"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ᫔"),url2,l1l1ll_l1_ (u"ࠩࠪ᫕"),l1l1ll_l1_ (u"ࠪࠫ᫖"),l1l1ll_l1_ (u"ࠫࠬ᫗"),l1l1ll_l1_ (u"ࠬ࠭᫘"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ᫙"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᫚"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ᫛"),block,re.DOTALL)
		for link,title in items:
			link = link+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᫜")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ᫝")
			if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᫞") not in link: link = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᫟")+link
			l11l1_l1_.append(link)
	# download l1ll_l1_
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ᫠"),l1l1ll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴ࡭ࡶࠧ᫡"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ᫢"),url2,l1l1ll_l1_ (u"ࠩࠪ᫣"),l1l1ll_l1_ (u"ࠪࠫ᫤"),l1l1ll_l1_ (u"ࠫࠬ᫥"),l1l1ll_l1_ (u"ࠬ࠭᫦"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ᫧"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᫨"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪ᫩"),block,re.DOTALL)
		for link,title in items:
			link = link+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ᫪")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ᫫")
			if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᫬") not in link: link = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᫭")+link
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ᫮"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᫯"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠨࠩ᫰"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠩࠪ᫱"): return
	search = search.replace(l1l1ll_l1_ (u"ࠪࠤࠬ᫲"),l1l1ll_l1_ (u"ࠫ࠰࠭᫳"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭᫴")+search
	l11l1l_l1_(url)
	return
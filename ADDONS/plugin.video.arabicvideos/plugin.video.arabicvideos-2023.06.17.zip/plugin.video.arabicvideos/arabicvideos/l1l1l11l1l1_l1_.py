# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨࡏ࠶࡙ࠬ㒖")
menu_name = l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㒗")
UNIQUE_TYPES = [
		 l1l1ll_l1_ (u"ࠪࡍࡌࡔࡏࡓࡇࡇࠫ㒘")
		,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ㒙"),l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㒚")
		,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ㒛"),l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㒜")
		#,l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡁࡓࡅࡋࡍ࡛ࡋࡄࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㒝"),l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡆࡒࡊࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㒞"),l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㒟")
		,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㒠"),l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㒡")
		,l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ㒢"),l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࠩ㒣"),l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡓࡇࡍࡆࡡࡖࡓࡗ࡚ࡅࡅࠩ㒤")
		,l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ㒥"),l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㒦")
		,l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㒧"),l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㒨")
		,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㒩"),l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ㒪"),l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡒࡆࡓࡅࡠࡕࡒࡖ࡙ࡋࡄࠨ㒫")
		]
l1l1l11l11l_l1_ = 4
def MAIN(mode,url,text,type,page,infodict):
	try: folder = str(infodict[l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㒬")])
	except: folder = l1l1ll_l1_ (u"ࠪࠫ㒭")
	try: l11l1ll1_l1_ = str(infodict[l1l1ll_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭㒮")])
	except: l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠬ࠭㒯")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(folder,l11l1ll1_l1_)
	elif mode==712: results = l1l1l11l1ll_l1_(folder)
	elif mode==713: results = GROUPS(folder,url,text,page)
	elif mode==714: results = ITEMS(folder,url,text,page)
	elif mode==715: results = PLAY(folder,url,type)
	elif mode==716: results = CHECK_ACCOUNT(folder,True)
	elif mode==717: results = l1l1l1111ll_l1_(folder,True)
	elif mode==718: results = EPG_ITEMS(folder,url,text)
	elif mode==719: results = SEARCH(text,folder,url,page)
	elif mode==720: results = MENU(folder)
	elif mode==721: results = l1l1l11llll_l1_(folder)
	elif mode==722: results = USE_FASTER_SERVER(folder)
	elif mode==723: results = ADD_USERAGENT(folder)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==729: results = SEARCH_ONE_FOLDER(text,folder,url,page)
	else: results = False
	return results
def FOLDERS_MENU():
	for folder in range(FOLDERS_COUNT):
		folder2 = l1l1ll_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ㒰")+str(int(folder)+1)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒱"),menu_name+l1l1ll_l1_ (u"ࠨ็ฯ่ิࠦࠧ㒲")+text_numbers[folder]+folder2,l1l1ll_l1_ (u"ࠩࠪ㒳"),720,l1l1ll_l1_ (u"ࠪࠫ㒴"),l1l1ll_l1_ (u"ࠫࠬ㒵"),l1l1ll_l1_ (u"ࠬ࠭㒶"),l1l1ll_l1_ (u"࠭ࠧ㒷"),{l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㒸"):folder})
	return
def SECTIONS_MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㒹"),menu_name+l1l1ll_l1_ (u"ࠩฯ้๏฿ࠠฤไึห๊ࠦࡍ࠴ࡗࠪ㒺"),l1l1ll_l1_ (u"ࠪࠫ㒻"),165,l1l1ll_l1_ (u"ࠫࠬ㒼"),l1l1ll_l1_ (u"ࠬ࠭㒽"),l1l1ll_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ㒾"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㒿"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㓀"),l1l1ll_l1_ (u"ࠩࠪ㓁"),9999)
	for folder in range(FOLDERS_COUNT):
		folder2 = l1l1ll_l1_ (u"ࠪࠤࡒ࠹ࡕࠨ㓂")+str(int(folder)+1)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓃"),menu_name+l1l1ll_l1_ (u"ࠬษโิษ่ࠤ๊าไะࠢࠪ㓄")+text_numbers[folder]+folder2,l1l1ll_l1_ (u"࠭ࠧ㓅"),165,l1l1ll_l1_ (u"ࠧࠨ㓆"),l1l1ll_l1_ (u"ࠨࠩ㓇"),l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㓈"),l1l1ll_l1_ (u"ࠪࠫ㓉"),{l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓊"):folder})
	return
def MENU(folder=l1l1ll_l1_ (u"ࠬ࠭㓋")):
	if folder:
		folder1 = {l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓌"):folder}
		folder2 = l1l1ll_l1_ (u"ࠧࠡࡏ࠶࡙ࠬ㓍")+str(int(folder)+1)
	else:
		folder1 = l1l1ll_l1_ (u"ࠨࠩ㓎")
		folder2 = l1l1ll_l1_ (u"ࠩࠪ㓏")
	if CHECK_TABLES_EXIST(folder,True):
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓐"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤ๊๊แศฬࠪ㓑")+folder2,l1l1ll_l1_ (u"ࠬ࠭㓒"),729,l1l1ll_l1_ (u"࠭ࠧ㓓"),l1l1ll_l1_ (u"ࠧࠨ㓔"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㓕"),l1l1ll_l1_ (u"ࠩࠪ㓖"),folder1)
		#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓗"),menu_name+l1l1ll_l1_ (u"ࠫ็อฦๆหࠣว็ูวๆࠩ㓘")+folder2,l1l1ll_l1_ (u"ࠬ࠭㓙"),165,l1l1ll_l1_ (u"࠭ࠧ㓚"),l1l1ll_l1_ (u"ࠧࠨ㓛"),l1l1ll_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㓜"),l1l1ll_l1_ (u"ࠩࠪ㓝"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㓞"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㓟"),l1l1ll_l1_ (u"ࠬ࠭㓠"),9999)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓡"),menu_name+l1l1ll_l1_ (u"ࠧใ่๋หฯࠦๅึ่ไอࠬ㓢")+folder2,l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ㓣"),713,l1l1ll_l1_ (u"ࠩࠪ㓤"),l1l1ll_l1_ (u"ࠪࠫ㓥"),l1l1ll_l1_ (u"ࠫࠬ㓦"),l1l1ll_l1_ (u"ࠬ࠭㓧"),folder1)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓨"),menu_name+l1l1ll_l1_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠨ㓩")+folder2,l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㓪"),713,l1l1ll_l1_ (u"ࠩࠪ㓫"),l1l1ll_l1_ (u"ࠪࠫ㓬"),l1l1ll_l1_ (u"ࠫࠬ㓭"),l1l1ll_l1_ (u"ࠬ࠭㓮"),folder1)
		#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓯"),menu_name+l1l1ll_l1_ (u"ࠧฤใ็ห๊ࠦๅึ่ไอࠬ㓰")+folder2,l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㓱"),713,l1l1ll_l1_ (u"ࠩࠪ㓲"),l1l1ll_l1_ (u"ࠪࠫ㓳"),l1l1ll_l1_ (u"ࠫࠬ㓴"),l1l1ll_l1_ (u"ࠬ࠭㓵"),folder1)
		#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓶"),menu_name+l1l1ll_l1_ (u"ࠧๆี็ื้อสࠡ็ุ๊ๆฯࠧ㓷")+folder2,l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㓸"),713,l1l1ll_l1_ (u"ࠩࠪ㓹"),l1l1ll_l1_ (u"ࠪࠫ㓺"),l1l1ll_l1_ (u"ࠫࠬ㓻"),l1l1ll_l1_ (u"ࠬ࠭㓼"),folder1)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㓽"),menu_name+l1l1ll_l1_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩ㓾")+folder2,l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ㓿"),713,l1l1ll_l1_ (u"ࠩࠪ㔀"),l1l1ll_l1_ (u"ࠪࠫ㔁"),l1l1ll_l1_ (u"ࠫࠬ㔂"),l1l1ll_l1_ (u"ࠬ࠭㔃"),folder1)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㔄"),menu_name+l1l1ll_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ࠭㔅")+folder2,l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㔆"),713,l1l1ll_l1_ (u"ࠩࠪ㔇"),l1l1ll_l1_ (u"ࠪࠫ㔈"),l1l1ll_l1_ (u"ࠫࠬ㔉"),l1l1ll_l1_ (u"ࠬ࠭㔊"),folder1)
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㔋"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㔌"),l1l1ll_l1_ (u"ࠨࠩ㔍"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔎"),menu_name+l1l1ll_l1_ (u"ࠪๆ๋๎วหู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ㔏")+folder2,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㔐"),713,l1l1ll_l1_ (u"ࠬ࠭㔑"),l1l1ll_l1_ (u"࠭ࠧ㔒"),l1l1ll_l1_ (u"ࠧࠨ㔓"),l1l1ll_l1_ (u"ࠨࠩ㔔"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔕"),menu_name+l1l1ll_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥี็ใฬࠤํ๋ัหสฬࠫ㔖")+folder2,l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㔗"),713,l1l1ll_l1_ (u"ࠬ࠭㔘"),l1l1ll_l1_ (u"࠭ࠧ㔙"),l1l1ll_l1_ (u"ࠧࠨ㔚"),l1l1ll_l1_ (u"ࠨࠩ㔛"),folder1)
		#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔜"),menu_name+l1l1ll_l1_ (u"ࠪวๆ๊วๆู่๋ࠢ็ษ๊่ࠡีฯฮษࠨ㔝")+folder2,l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㔞"),713,l1l1ll_l1_ (u"ࠬ࠭㔟"),l1l1ll_l1_ (u"࠭ࠧ㔠"),l1l1ll_l1_ (u"ࠧࠨ㔡"),l1l1ll_l1_ (u"ࠨࠩ㔢"),folder1)
		#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔣"),menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤ๊฻ๆโหࠣ์๊ืสษหࠪ㔤")+folder2,l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㔥"),713,l1l1ll_l1_ (u"ࠬ࠭㔦"),l1l1ll_l1_ (u"࠭ࠧ㔧"),l1l1ll_l1_ (u"ࠧࠨ㔨"),l1l1ll_l1_ (u"ࠨࠩ㔩"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔪"),menu_name+l1l1ll_l1_ (u"ࠪๅ๏ี๊้้สฮ๋ࠥฬ่๊็อࠥ๎ๅาฬหอࠬ㔫")+folder2,l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㔬"),713,l1l1ll_l1_ (u"ࠬ࠭㔭"),l1l1ll_l1_ (u"࠭ࠧ㔮"),l1l1ll_l1_ (u"ࠧࠨ㔯"),l1l1ll_l1_ (u"ࠨࠩ㔰"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㔱"),menu_name+l1l1ll_l1_ (u"ࠪๆ๋๎วห่ࠢะ์๎ไส๋้ࠢึะศสࠩ㔲")+folder2,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㔳"),713,l1l1ll_l1_ (u"ࠬ࠭㔴"),l1l1ll_l1_ (u"࠭ࠧ㔵"),l1l1ll_l1_ (u"ࠧࠨ㔶"),l1l1ll_l1_ (u"ࠨࠩ㔷"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㔸"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㔹"),l1l1ll_l1_ (u"ࠫࠬ㔺"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔻"),menu_name+l1l1ll_l1_ (u"࠭วๅไ้์ฬะࠠศๆฦู้๐ษࠡสา์๋ࠦส฻์ํีࠬ㔼")+folder2,l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㔽"),713,l1l1ll_l1_ (u"ࠨࠩ㔾"),l1l1ll_l1_ (u"ࠩࠪ㔿"),l1l1ll_l1_ (u"ࠪࠫ㕀"),l1l1ll_l1_ (u"ࠫࠬ㕁"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㕂"),menu_name+l1l1ll_l1_ (u"࠭วๅใํำ๏๎็ศฬࠣห้ษีๅ์ฬࠤอี่็ࠢอ฾๏๐ัࠨ㕃")+folder2,l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ㕄"),713,l1l1ll_l1_ (u"ࠨࠩ㕅"),l1l1ll_l1_ (u"ࠩࠪ㕆"),l1l1ll_l1_ (u"ࠪࠫ㕇"),l1l1ll_l1_ (u"ࠫࠬ㕈"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㕉"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㕊"),l1l1ll_l1_ (u"ࠧࠨ㕋"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕌"),menu_name+l1l1ll_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠠๆ่ࠣวุ๋วว้สࠤํ๋ัหสฬࠫ㕍")+folder2,l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡈࡕࡓࡒࡥࡎࡂࡏࡈࡣࡘࡕࡒࡕࡇࡇࠫ㕎"),713,l1l1ll_l1_ (u"ࠫࠬ㕏"),l1l1ll_l1_ (u"ࠬ࠭㕐"),l1l1ll_l1_ (u"࠭ࠧ㕑"),l1l1ll_l1_ (u"ࠧࠨ㕒"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕓"),menu_name+l1l1ll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโห้๋ࠣࠦริ็สส์อ้ࠠ็ิฮอฯࠧ㕔")+folder2,l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ㕕"),713,l1l1ll_l1_ (u"ࠫࠬ㕖"),l1l1ll_l1_ (u"ࠬ࠭㕗"),l1l1ll_l1_ (u"࠭ࠧ㕘"),l1l1ll_l1_ (u"ࠧࠨ㕙"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㕚"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㕛"),l1l1ll_l1_ (u"ࠪࠫ㕜"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕝"),menu_name+l1l1ll_l1_ (u"่ࠬๆ้ษอࠤ๊฻ๆโห้๋ࠣࠦรใีส้์อ้ࠠ็ิฮอฯࠧ㕞")+folder2,l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ㕟"),713,l1l1ll_l1_ (u"ࠧࠨ㕠"),l1l1ll_l1_ (u"ࠨࠩ㕡"),l1l1ll_l1_ (u"ࠩࠪ㕢"),l1l1ll_l1_ (u"ࠪࠫ㕣"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕤"),menu_name+l1l1ll_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆื้ๅฮࠦๅ็ࠢฦๆุอๅ่ษࠣ์๊ืสษหࠪ㕥")+folder2,l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ㕦"),713,l1l1ll_l1_ (u"ࠧࠨ㕧"),l1l1ll_l1_ (u"ࠨࠩ㕨"),l1l1ll_l1_ (u"ࠩࠪ㕩"),l1l1ll_l1_ (u"ࠪࠫ㕪"),folder1)
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㕫"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㕬"),l1l1ll_l1_ (u"࠭ࠧ㕭"),9999)
	for seq in range(l1l1l11l11l_l1_):
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㕮"),menu_name+l1l1ll_l1_ (u"ࠨวูหๆฯ้ࠠฬ฽๎๏ืࠠาษห฻ࠬ㕯")+folder2+l1l1ll_l1_ (u"ࠩࠣࠫ㕰")+text_numbers[seq],l1l1ll_l1_ (u"ࠪࠫ㕱"),711,l1l1ll_l1_ (u"ࠫࠬ㕲"),l1l1ll_l1_ (u"ࠬ࠭㕳"),l1l1ll_l1_ (u"࠭ࠧ㕴"),l1l1ll_l1_ (u"ࠧࠨ㕵"),{l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕶"):folder,l1l1ll_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨࠫ㕷"):seq})
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕸"),menu_name+l1l1ll_l1_ (u"ࠫอืวๆฮࠣห้่ๆ้ษอࠤ࠭าฯ้ๆࠣๅ็฽ࠩࠨ㕹")+folder2,l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡉࡕࡍ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㕺"),713,l1l1ll_l1_ (u"࠭ࠧ㕻"),l1l1ll_l1_ (u"ࠧࠨ㕼"),l1l1ll_l1_ (u"ࠨࠩ㕽"),l1l1ll_l1_ (u"ࠩࠪ㕾"),folder1)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕿"),menu_name+l1l1ll_l1_ (u"ࠫศืิ๋ใࠣห้่ๆ้ษอࠤ้๊ร๋ษ่ࠤฬ๊ๅศุํอࠬ㖀")+folder2,l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㖁"),713,l1l1ll_l1_ (u"࠭ࠧ㖂"),l1l1ll_l1_ (u"ࠧࠨ㖃"),l1l1ll_l1_ (u"ࠨࠩ㖄"),l1l1ll_l1_ (u"ࠩࠪ㖅"),folder1)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㖆"),menu_name+l1l1ll_l1_ (u"ࠫศืิ๋ใࠣฬึอๅอࠢส่็์่ศฬ่้ࠣษ๊ศ็ࠣห้๋วื์ฬࠫ㖇")+folder2,l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡅࡗࡉࡈࡊࡘࡈࡈࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㖈"),713,l1l1ll_l1_ (u"࠭ࠧ㖉"),l1l1ll_l1_ (u"ࠧࠨ㖊"),l1l1ll_l1_ (u"ࠨࠩ㖋"),l1l1ll_l1_ (u"ࠩࠪ㖌"),folder1)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㖍"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㖎"),l1l1ll_l1_ (u"ࠬ࠭㖏"),9999)
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖐"),menu_name+l1l1ll_l1_ (u"ࠧฦุสๅฮࠦร้ࠢอ฾๏๐ัࠡษืฮึอใࠨ㖑")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖒"),711,l1l1ll_l1_ (u"ࠩࠪ㖓"),l1l1ll_l1_ (u"ࠪࠫ㖔"),l1l1ll_l1_ (u"ࠫࠬ㖕"),l1l1ll_l1_ (u"ࠬ࠭㖖"),folder1)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖗"),menu_name+l1l1ll_l1_ (u"ฺࠧัาࠤๆ๐ฯ๋๊๊หฯ࠭㖘")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖙"),721,l1l1ll_l1_ (u"ࠩࠪ㖚"),l1l1ll_l1_ (u"ࠪࠫ㖛"),l1l1ll_l1_ (u"ࠫࠬ㖜"),l1l1ll_l1_ (u"ࠬ࠭㖝"),folder1)
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖞"),menu_name+l1l1ll_l1_ (u"ࠧโฯุࠤฬฺสาษๆࠫ㖟")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖠"),716,l1l1ll_l1_ (u"ࠩࠪ㖡"),l1l1ll_l1_ (u"ࠪࠫ㖢"),l1l1ll_l1_ (u"ࠫࠬ㖣"),l1l1ll_l1_ (u"ࠬ࠭㖤"),folder1)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖥"),menu_name+l1l1ll_l1_ (u"ࠧอๆหࠤ๊๊แศฬࠪ㖦")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖧"),712,l1l1ll_l1_ (u"ࠩࠪ㖨"),l1l1ll_l1_ (u"ࠪࠫ㖩"),l1l1ll_l1_ (u"ࠫࠬ㖪"),l1l1ll_l1_ (u"ࠬ࠭㖫"),folder1)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖬"),menu_name+l1l1ll_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠪ㖭")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖮"),717,l1l1ll_l1_ (u"ࠩࠪ㖯"),l1l1ll_l1_ (u"ࠪࠫ㖰"),l1l1ll_l1_ (u"ࠫࠬ㖱"),l1l1ll_l1_ (u"ࠬ࠭㖲"),folder1)
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖳"),menu_name+l1l1ll_l1_ (u"ࠧศีอาิอๅࠡษ็ื๏ืแาࠢส่ศูัฺࠩ㖴")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖵"),722,l1l1ll_l1_ (u"ࠩࠪ㖶"),l1l1ll_l1_ (u"ࠪࠫ㖷"),l1l1ll_l1_ (u"ࠫࠬ㖸"),l1l1ll_l1_ (u"ࠬ࠭㖹"),folder1)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖺"),menu_name+l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤฯเ๊๋ำࠪ㖻")+folder2,l1l1ll_l1_ (u"ࠨࠩ㖼"),723,l1l1ll_l1_ (u"ࠩࠪ㖽"),l1l1ll_l1_ (u"ࠪࠫ㖾"),l1l1ll_l1_ (u"ࠫࠬ㖿"),l1l1ll_l1_ (u"ࠬ࠭㗀"),folder1)
	return
def CHECK_ACCOUNT(folder,showDialogs=True):
	ok,status = False,l1l1ll_l1_ (u"࠭ࠧ㗁")
	new_host,new_port = l1l1ll_l1_ (u"ࠧࠨ㗂"),l1l1ll_l1_ (u"ࠨࠩ㗃")
	URL_player,URL_get,server,username,password = GET_URL(folder)
	if username==l1l1ll_l1_ (u"ࠩࠪ㗄"): return
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ㗅")+folder)
	headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㗆"):useragent}
	if URL_player:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ㗇"),URL_player,l1l1ll_l1_ (u"࠭ࠧ㗈"),headers,False,False,l1l1ll_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ㗉"))
		html = response.content
		if response.succeeded:
			timestamp,timediff,time_now,created_at,exp_date = 0,0,l1l1ll_l1_ (u"ࠨࠩ㗊"),l1l1ll_l1_ (u"ࠩࠪ㗋"),l1l1ll_l1_ (u"ࠪࠫ㗌")
			try:
				dict = EVAL(l1l1ll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㗍"),html)
				status = dict[l1l1ll_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㗎")][l1l1ll_l1_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭㗏")]
				ok = True
				time_now = dict[l1l1ll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠬ㗐")][l1l1ll_l1_ (u"ࠨࡶ࡬ࡱࡪࡥ࡮ࡰࡹࠪ㗑")]
			except: pass
			if time_now:
				try:
					struct = time.strptime(time_now,l1l1ll_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭㗒"))
					timestamp = int(time.mktime(struct))
					timediff = int(now-timestamp)
					timediff = int((timediff+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l1l1ll_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭㗓")][l1l1ll_l1_ (u"ࠫࡨࡸࡥࡢࡶࡨࡨࡤࡧࡴࠨ㗔")]))
					created_at = time.strftime(l1l1ll_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ㗕"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l1l1ll_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ㗖")][l1l1ll_l1_ (u"ࠧࡦࡺࡳࡣࡩࡧࡴࡦࠩ㗗")]))
					exp_date = time.strftime(l1l1ll_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ㗘"),struct)
				except: pass
			settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ㗙")+folder,str(now))
			settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫ࡥࠧ㗚")+folder,str(timediff))
			server_info = l1l1ll_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡤ࡯࡮ࡧࡱࠥ࠾ࠬ㗛")+html.split(l1l1ll_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠦ࠿࠭㗜"))[1]
			server_info = server_info.replace(l1l1ll_l1_ (u"࠭࠺ࠨ㗝"),l1l1ll_l1_ (u"ࠧ࠻ࠢࠪ㗞")).replace(l1l1ll_l1_ (u"ࠨ࠮ࠪ㗟"),l1l1ll_l1_ (u"ࠩ࠯ࠤࠬ㗠")).replace(l1l1ll_l1_ (u"ࠪࢁࢂ࠭㗡"),l1l1ll_l1_ (u"ࠫࢂ࠭㗢"))
			new = re.findall(l1l1ll_l1_ (u"ࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࠣࡲࡲࡶࡹࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ㗣"),server_info,re.DOTALL)
			new_host,new_port = new[0]
			if ok and showDialogs:
				max = dict[l1l1ll_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ㗤")][l1l1ll_l1_ (u"ࠧ࡮ࡣࡻࡣࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࡴࠩ㗥")]
				active = dict[l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ㗦")][l1l1ll_l1_ (u"ࠩࡤࡧࡹ࡯ࡶࡦࡡࡦࡳࡳࡹࠧ㗧")]
				is_trial = dict[l1l1ll_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭㗨")][l1l1ll_l1_ (u"ࠫ࡮ࡹ࡟ࡵࡴ࡬ࡥࡱ࠭㗩")]
				parts = URL_player.split(l1l1ll_l1_ (u"ࠬࡅࠧ㗪"),1)
				message = l1l1ll_l1_ (u"࠭ࡕࡓࡎ࠽ࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㗫")+URL_player+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㗬")
				message += l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳ࡙ࡴࡢࡶࡸࡷ࠿ࠦࠠࠨ㗭")+l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㗮")+status+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㗯")
				message += l1l1ll_l1_ (u"ࠫࡡࡴࡔࡳ࡫ࡤࡰ࠿ࠦࠠࠡࠢࠪ㗰")+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㗱")+str(is_trial==l1l1ll_l1_ (u"࠭࠱ࠨ㗲"))+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㗳")
				message += l1l1ll_l1_ (u"ࠨ࡞ࡱࡇࡷ࡫ࡡࡵࡧࡧࠤࠥࡇࡴ࠻ࠢࠣࠫ㗴")+l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㗵")+created_at+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㗶")
				message += l1l1ll_l1_ (u"ࠫࡡࡴࡅࡹࡲ࡬ࡶࡾࠦࡄࡢࡶࡨ࠾ࠥࠦࠧ㗷")+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㗸")+exp_date+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㗹")
				message += l1l1ll_l1_ (u"ࠧ࡝ࡰࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࡹࠠࠡࠢࠫࠤࡆࡩࡴࡪࡸࡨࠤ࠴ࠦࡍࡢࡺ࡬ࡱࡺࡳࠠࠪࠢ࠽ࠤࠥ࠭㗺")+l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㗻")+active+l1l1ll_l1_ (u"ࠩࠣ࠳ࠥ࠭㗼")+max+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㗽")
				message += l1l1ll_l1_ (u"ࠫࡡࡴࡁ࡭࡮ࡲࡻࡪࡪࠠࡐࡷࡷࡴࡺࡺࡳ࠻ࠢࠣࠤࠬ㗾")+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㗿")+l1l1ll_l1_ (u"ࠨࠠ࠭ࠢࠥ㘀").join(dict[l1l1ll_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ㘁")][l1l1ll_l1_ (u"ࠨࡣ࡯ࡰࡴࡽࡥࡥࡡࡲࡹࡹࡶࡵࡵࡡࡩࡳࡷࡳࡡࡵࡵࠪ㘂")])+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㘃")
				message += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㘄")+server_info
				if status==l1l1ll_l1_ (u"ࠫࡆࡩࡴࡪࡸࡨࠫ㘅"): DIALOG_TEXTVIEWER(l1l1ll_l1_ (u"ࠬอไศึอีฬ้๋ࠠ฻่่ࠥฮฯู้่้ࠣอใๅࠩ㘆"),message)
				else: DIALOG_TEXTVIEWER(l1l1ll_l1_ (u"๊࠭ษั๋ࠤศ์่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠศๆสุฯืวไࠩ㘇"),message)
	if URL_player and ok and status==l1l1ll_l1_ (u"ࠧࡂࡥࡷ࡭ࡻ࡫ࠧ㘈"):
		LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㘉"),l1l1ll_l1_ (u"ࠩ࠱ࠤࠥࠦࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡋࡓࡘ࡛ࠦࡕࡓࡎࠣࠤࠥࡡࠠࡊࡒࡗ࡚ࠥࡧࡣࡤࡱࡸࡲࡹࠦࡩࡴࠢࡒࡏࠥࡣࠠࠡࠢ࡞ࠤࠬ㘊")+URL_player+l1l1ll_l1_ (u"ࠪࠤࡢ࠭㘋"))
		succeeded = True
	else:
		LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㘌"),l1l1ll_l1_ (u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡊࡒࡗ࡚࡛ࠥࡒࡍࠢࠣࠤࡠࠦࡄࡰࡧࡶࠤࡳࡵࡴࠡࡹࡲࡶࡰࠦ࡝ࠡࠢࠣ࡟ࠥ࠭㘍")+URL_player+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ㘎"))
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㘏"),l1l1ll_l1_ (u"ࠨࠩ㘐"),l1l1ll_l1_ (u"ࠩไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠬ㘑"),l1l1ll_l1_ (u"ࠪีฬฮืࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡋࡓࡘ่࡛ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡌࡔ࡙࡜ࠠอัํำࠥษ่ࠡไ่ࠤอหีๅษะࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠫ㘒"))
		succeeded = False
	return succeeded,new_host,new_port
def ITEMS(folder,TYPE,GROUP,PAGE,showDialogs=True):
	if not PAGE: PAGE = l1l1ll_l1_ (u"ࠫ࠶࠭㘓")
	#menu_name = l1l1ll_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ㘔")
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	streams = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ㘕"),TYPE,GROUP)
	end = int(PAGE)*100
	start = end-100
	for context,title,url,img in streams[start:end]:
		cond1 = (l1l1ll_l1_ (u"ࠧࡈࡔࡒ࡙ࡕࡋࡄࠨ㘖") in TYPE or TYPE==l1l1ll_l1_ (u"ࠨࡃࡏࡐࠬ㘗"))
		cond2 = (l1l1ll_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡆࡆࠪ㘘") not in TYPE and TYPE!=l1l1ll_l1_ (u"ࠪࡅࡑࡒࠧ㘙"))
		if cond1 or cond2:
			if   l1l1ll_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㘚")  in TYPE: menuItemsLIST.append([l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㘛"),menu_name+title,url,718,img,l1l1ll_l1_ (u"࠭ࠧ㘜"),l1l1ll_l1_ (u"ࠧࡂࡔࡆࡌࡎ࡜ࡅࡅࠩ㘝"),l1l1ll_l1_ (u"ࠨࠩ㘞"),{l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㘟"):folder}])
			elif l1l1ll_l1_ (u"ࠪࡉࡕࡍࠧ㘠") 		 in TYPE: menuItemsLIST.append([l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㘡"),menu_name+title,url,718,img,l1l1ll_l1_ (u"ࠬ࠭㘢"),l1l1ll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡊࡖࡇࠨ㘣"),l1l1ll_l1_ (u"ࠧࠨ㘤"),{l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘥"):folder}])
			elif l1l1ll_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ㘦") in TYPE: menuItemsLIST.append([l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘧"),menu_name+title,url,718,img,l1l1ll_l1_ (u"ࠫࠬ㘨"),l1l1ll_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ㘩"),l1l1ll_l1_ (u"࠭ࠧ㘪"),{l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㘫"):folder}])
			elif l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭㘬") 	 in TYPE: menuItemsLIST.append([l1l1ll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㘭"),menu_name+title,url,715,img,l1l1ll_l1_ (u"ࠪࠫ㘮"),l1l1ll_l1_ (u"ࠫࠬ㘯"),context,{l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㘰"):folder}])
			else: menuItemsLIST.append([l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㘱"),menu_name+title,url,715,img,l1l1ll_l1_ (u"ࠧࠨ㘲"),l1l1ll_l1_ (u"ࠨࠩ㘳"),l1l1ll_l1_ (u"ࠩࠪ㘴"),{l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘵"):folder}])
	total = len(streams)
	PAGINATION(folder,PAGE,TYPE,714,total,GROUP)
	return
def SHOW_EMPTY(menu_name2):
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㘶"),menu_name2+l1l1ll_l1_ (u"ࠬํะ่ࠢส่็อฦๆหࠣษ๊อࠠโษิ฾ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮ࠭㘷"),l1l1ll_l1_ (u"࠭ࠧ㘸"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㘹"),menu_name2+l1l1ll_l1_ (u"ࠨล๋ࠤฬ๊ฮะ็ฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤฬฺสาษๆ็ࠬ㘺"),l1l1ll_l1_ (u"ࠩࠪ㘻"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㘼"),menu_name2+l1l1ll_l1_ (u"ࠫศ๎ࠠาษห฻ࠥࡓ࠳ࡖโࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ฿๐ัࠡืะ๎า࠭㘽"),l1l1ll_l1_ (u"ࠬ࠭㘾"),9999)
	return
def GROUPS(folder,TYPE,GROUP,PAGE,website=l1l1ll_l1_ (u"࠭ࠧ㘿"),showDialogs=True):
	if not PAGE: PAGE = l1l1ll_l1_ (u"ࠧ࠲ࠩ㙀")
	menu_name2 = menu_name
	if not CHECK_TABLES_EXIST(folder,showDialogs): return False
	if l1l1ll_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㙁") in GROUP: MAINGROUP,SUBGROUP = GROUP.split(l1l1ll_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㙂"))
	else: MAINGROUP,SUBGROUP = GROUP,l1l1ll_l1_ (u"ࠪࠫ㙃")
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	uniquegroups = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㙄"),TYPE,l1l1ll_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ㙅"))
	if not uniquegroups: return False
	unique = []
	for group,img in uniquegroups:
		if website:
			if l1l1ll_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㙆") in group: menu_name2 = l1l1ll_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ㙇")
			elif l1l1ll_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪ㙈") in group: menu_name2 = l1l1ll_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐࠪ㙉")
			elif l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ㙊") in TYPE: menu_name2 = l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࠩ㙋")
			else: menu_name2 = l1l1ll_l1_ (u"ࠬ࡜ࡉࡅࡇࡒࡗࠬ㙌")
			menu_name2 = l1l1ll_l1_ (u"࠭ࠬ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㙍")+menu_name2+l1l1ll_l1_ (u"ࠧ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㙎")
		if l1l1ll_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㙏") in group: maingroup,subgroup = group.split(l1l1ll_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㙐"))
		else: maingroup,subgroup = group,l1l1ll_l1_ (u"ࠪࠫ㙑")
		if not GROUP:
			if maingroup in unique: continue
			unique.append(maingroup)
			if l1l1ll_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࠫ㙒") in website: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㙓"),menu_name2+maingroup,TYPE,168,l1l1ll_l1_ (u"࠭ࠧ㙔"),l1l1ll_l1_ (u"ࠧ࠲ࠩ㙕"),group,l1l1ll_l1_ (u"ࠨࠩ㙖"),{l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙗"):folder})
			elif l1l1ll_l1_ (u"ࠪࡣࡤ࡙ࡅࡓࡋࡈࡗࡤࡥࠧ㙘") in group: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㙙"),menu_name2+maingroup,TYPE,713,l1l1ll_l1_ (u"ࠬ࠭㙚"),l1l1ll_l1_ (u"࠭࠱ࠨ㙛"),group,l1l1ll_l1_ (u"ࠧࠨ㙜"),{l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㙝"):folder})
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙞"),menu_name2+maingroup,TYPE,714,l1l1ll_l1_ (u"ࠪࠫ㙟"),l1l1ll_l1_ (u"ࠫ࠶࠭㙠"),group,l1l1ll_l1_ (u"ࠬ࠭㙡"),{l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙢"):folder})
		elif l1l1ll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㙣") in group and maingroup==MAINGROUP:
			if subgroup in unique: continue
			unique.append(subgroup)
			if l1l1ll_l1_ (u"ࠨࡔࡄࡒࡉࡕࡍࠨ㙤") in website: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙥"),menu_name2+subgroup,TYPE,168,l1l1ll_l1_ (u"ࠪࠫ㙦"),l1l1ll_l1_ (u"ࠫ࠶࠭㙧"),group,l1l1ll_l1_ (u"ࠬ࠭㙨"),{l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙩"):folder})
			else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙪"),menu_name2+subgroup,TYPE,714,img,l1l1ll_l1_ (u"ࠨ࠳ࠪ㙫"),group,l1l1ll_l1_ (u"ࠩࠪ㙬"),{l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㙭"):folder})
	#if l1l1ll_l1_ (u"ࠫࡘࡕࡒࡕࡇࡇࠫ㙮") in TYPE:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not website:
		end = int(PAGE)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(folder,PAGE,TYPE,713,total,GROUP)
	return True
def EPG_ITEMS(folder,url,function):
	HOUR_ = 60*60
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㙯")+folder)
	headers = {l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㙰"):useragent}
	if not CHECK_TABLES_EXIST(folder,True): return
	timestamp = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࡣࠬ㙱")+folder)
	if timestamp==l1l1ll_l1_ (u"ࠨࠩ㙲") or now-int(timestamp)>24*HOUR_:
		ok,new_host,new_port = CHECK_ACCOUNT(folder,False)
		if not ok: return
	timediff = int(settings.getSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡥ࡫ࡩࡪࡤ࠭㙳")+folder))
	server = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬ㙴")+folder)
	username = settings.getSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡻࡳࡦࡴࡱࡥࡲ࡫࡟ࠨ㙵")+folder)
	password = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡫ࡳࡸࡻ࠴ࡰࡢࡵࡶࡻࡴࡸࡤࡠࠩ㙶")+folder)
	url_parts = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ㙷"))
	stream_id = url_parts[-1].replace(l1l1ll_l1_ (u"ࠧ࠯ࡶࡶࠫ㙸"),l1l1ll_l1_ (u"ࠨࠩ㙹")).replace(l1l1ll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㙺"),l1l1ll_l1_ (u"ࠪࠫ㙻"))
	if function==l1l1ll_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ㙼"): url_action = l1l1ll_l1_ (u"ࠬ࡭ࡥࡵࡡࡶ࡬ࡴࡸࡴࡠࡧࡳ࡫ࠬ㙽")
	else: url_action = l1l1ll_l1_ (u"࠭ࡧࡦࡶࡢࡷ࡮ࡳࡰ࡭ࡧࡢࡨࡦࡺࡡࡠࡶࡤࡦࡱ࡫ࠧ㙾")
	URL_player,URL_get,server,username,password = GET_URL(folder)
	if username==l1l1ll_l1_ (u"ࠧࠨ㙿"): return
	epg_url = URL_player+l1l1ll_l1_ (u"ࠨࠨࡤࡧࡹ࡯࡯࡯࠿ࠪ㚀")+url_action+l1l1ll_l1_ (u"ࠩࠩࡷࡹࡸࡥࡢ࡯ࡢ࡭ࡩࡃࠧ㚁")+stream_id
	html = OPENURL_CACHED(NO_CACHE,epg_url,l1l1ll_l1_ (u"ࠪࠫ㚂"),headers,l1l1ll_l1_ (u"ࠫࠬ㚃"),l1l1ll_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡉࡕࡍ࡟ࡊࡖࡈࡑࡘ࠳࠲࡯ࡦࠪ㚄"))
	archive_files = EVAL(l1l1ll_l1_ (u"࠭ࡤࡪࡥࡷࠫ㚅"),html)
	all_epg = archive_files[l1l1ll_l1_ (u"ࠧࡦࡲࡪࡣࡱ࡯ࡳࡵ࡫ࡱ࡫ࡸ࠭㚆")]
	epg_items = []
	if function in [l1l1ll_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ㚇"),l1l1ll_l1_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ㚈")]:
		for dict in all_epg:
			if dict[l1l1ll_l1_ (u"ࠪ࡬ࡦࡹ࡟ࡢࡴࡦ࡬࡮ࡼࡥࠨ㚉")]==1:
				epg_items.append(dict)
				if function in [l1l1ll_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㚊")]: break
		if not epg_items: return
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㚋"),menu_name+l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ษ็้้็วหࠢส่ศ๎ไ๋ࠢห๋ีํࠠศๆๅหห๋ษࠡไาࠤ้อࠠห฻่่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㚌"),l1l1ll_l1_ (u"ࠧࠨ㚍"),9999)
		if function in [l1l1ll_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㚎")]:
			length_hours = 2
			length_secs = length_hours*HOUR_
			epg_items = []
			initial_timestamp = int(int(dict[l1l1ll_l1_ (u"ࠩࡶࡸࡦࡸࡴࡠࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ㚏")])/length_secs)*length_secs
			finish_timestamp = now+length_secs
			videos_count = int((finish_timestamp-initial_timestamp)/HOUR_)
			for count in range(videos_count):
				if count>=6:
					if count%length_hours!=0: continue
					duration = length_secs
				else: duration = length_secs//2
				start_timestamp = initial_timestamp+count*HOUR_
				dict = {}
				dict[l1l1ll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㚐")] = l1l1ll_l1_ (u"ࠫࠬ㚑")
				struct = time.localtime(start_timestamp-timediff-HOUR_)
				dict[l1l1ll_l1_ (u"ࠬࡹࡴࡢࡴࡷࠫ㚒")] = time.strftime(l1l1ll_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ㚓"),struct)
				dict[l1l1ll_l1_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ㚔")] = str(start_timestamp)
				dict[l1l1ll_l1_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ㚕")] = str(start_timestamp+duration)
				epg_items.append(dict)
	elif function in [l1l1ll_l1_ (u"ࠩࡖࡌࡔࡘࡔࡠࡇࡓࡋࠬ㚖"),l1l1ll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ㚗")]: epg_items = all_epg
	if function==l1l1ll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭㚘") and len(epg_items)>0:
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㚙"),menu_name+l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞้ำ๋่ࠥวว็ฬࠤอืวๆฮࠣห้่ๆ้ษอࠤ࠭าฯ้ๆࠣๅ็฽ࠩแ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㚚"),l1l1ll_l1_ (u"ࠧࠨ㚛"),9999)
	epg_list = []
	img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡍࡨࡵ࡮ࠨ㚜"))
	for dict in epg_items:
		title = base64.b64decode(dict[l1l1ll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㚝")])
		if kodi_version>18.99: title = title.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㚞"))
		start_timestamp = int(dict[l1l1ll_l1_ (u"ࠫࡸࡺࡡࡳࡶࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭㚟")])
		stop_timestamp = int(dict[l1l1ll_l1_ (u"ࠬࡹࡴࡰࡲࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭㚠")])
		duration_minutes = str(int((stop_timestamp-start_timestamp+59)/60))
		start_string = dict[l1l1ll_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ㚡")].replace(l1l1ll_l1_ (u"ࠧࠡࠩ㚢"),l1l1ll_l1_ (u"ࠨ࠼ࠪ㚣"))
		struct = time.localtime(start_timestamp-HOUR_)
		time_string = time.strftime(l1l1ll_l1_ (u"ࠩࠨࡌ࠿ࠫࡍࠨ㚤"),struct)
		english_dayname = time.strftime(l1l1ll_l1_ (u"ࠪࠩࡦ࠭㚥"),struct)
		if function==l1l1ll_l1_ (u"ࠫࡘࡎࡏࡓࡖࡢࡉࡕࡍࠧ㚦"): title = l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㚧")+time_string+l1l1ll_l1_ (u"࠭ࠠแࠢࠪ㚨")+title+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㚩")
		elif function==l1l1ll_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㚪"): title = english_dayname+l1l1ll_l1_ (u"ࠩࠣࠫ㚫")+time_string+l1l1ll_l1_ (u"ࠪࠤ࠭࠭㚬")+duration_minutes+l1l1ll_l1_ (u"ࠫࡲ࡯࡮ࠪࠩ㚭")
		else: title = english_dayname+l1l1ll_l1_ (u"ࠬࠦࠧ㚮")+time_string+l1l1ll_l1_ (u"࠭ࠠࠩࠩ㚯")+duration_minutes+l1l1ll_l1_ (u"ࠧ࡮࡫ࡱ࠭ࠥࠦࠠࠨ㚰")+title+l1l1ll_l1_ (u"ࠨࠢใࠫ㚱")
		if function in [l1l1ll_l1_ (u"ࠩࡄࡖࡈࡎࡉࡗࡇࡇࠫ㚲"),l1l1ll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡇࡓࡋࠬ㚳"),l1l1ll_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㚴")]:
			timeshift_url = server+l1l1ll_l1_ (u"ࠬ࠵ࡴࡪ࡯ࡨࡷ࡭࡯ࡦࡵ࠱ࠪ㚵")+username+l1l1ll_l1_ (u"࠭࠯ࠨ㚶")+password+l1l1ll_l1_ (u"ࠧ࠰ࠩ㚷")+duration_minutes+l1l1ll_l1_ (u"ࠨ࠱ࠪ㚸")+start_string+l1l1ll_l1_ (u"ࠩ࠲ࠫ㚹")+stream_id+l1l1ll_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㚺")
			if function==l1l1ll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭㚻"): addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㚼"),menu_name+title,timeshift_url,9999,img,l1l1ll_l1_ (u"࠭ࠧ㚽"),l1l1ll_l1_ (u"ࠧࠨ㚾"),l1l1ll_l1_ (u"ࠨࠩ㚿"),{l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㛀"):folder})
			else: addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㛁"),menu_name+title,timeshift_url,235,img,l1l1ll_l1_ (u"ࠫࠬ㛂"),l1l1ll_l1_ (u"ࠬ࠭㛃"),l1l1ll_l1_ (u"࠭ࠧ㛄"),{l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㛅"):folder})
		epg_list.append(title)
	if function==l1l1ll_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ㛆") and epg_list: selection = DIALOG_CONTEXTMENU(epg_list)
	return epg_list
def USE_FASTER_SERVER(folder):
	if not CHECK_TABLES_EXIST(folder,True): return
	server,pingTime_newserver,pingTime_orgserver = l1l1ll_l1_ (u"ࠩࠪ㛇"),0,0
	succeeded,new_host,new_port = CHECK_ACCOUNT(folder,False)
	if succeeded:
		new_host_ip = DNS_RESOLVER(new_host)
		pingTime_newserver = PING(new_host_ip[0],int(new_port))
		dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㛈"))
		groups = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㛉"),l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫ㛊"))
		streams = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ㛋"),l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭㛌"),groups[1])
		url = streams[0][2]
		org_server = re.findall(l1l1ll_l1_ (u"ࠨ࠼࠲࠳࠭࠴ࠪࡀࠫ࠲ࠫ㛍"),url,re.DOTALL)
		org_server = org_server[0]
		if l1l1ll_l1_ (u"ࠩ࠽ࠫ㛎") in org_server: org_host,org_port = org_server.split(l1l1ll_l1_ (u"ࠪ࠾ࠬ㛏"))
		else: org_host,org_port = org_server,l1l1ll_l1_ (u"ࠫ࠽࠶ࠧ㛐")
		org_host_ip = DNS_RESOLVER(org_host)
		pingTime_orgserver = PING(org_host_ip[0],int(org_port))
	if pingTime_newserver and pingTime_orgserver:
		message = l1l1ll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆึ๎ึ็ัࠡษ็วฺ๊๊ࠡล่ࠤฬ๊ำ๋ำไีࠥอไฤีิ฽ࠥลࠡࠢࠩ㛑")
		message += l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ㛒")+l1l1ll_l1_ (u"้ࠧไอࠤ฻อฦฺࠢไ๎ࠥอไิ์ิๅึࠦวๅลุ่๏࠭㛓")+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ㛔")+str(int(pingTime_orgserver*1000))+l1l1ll_l1_ (u"้้ࠩࠣ๐ࠠฬษ้๎ฮ࠭㛕")
		message += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㛖")+l1l1ll_l1_ (u"ࠫํ่สุࠡสส฾ࠦแ๋ࠢสุ่๐ัโำࠣห้ฮฯ๋ๆࠪ㛗")+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ㛘")+str(int(pingTime_newserver*1000))+l1l1ll_l1_ (u"࠭ࠠๆๆํࠤะอๆ๋หࠪ㛙")
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㛚"),l1l1ll_l1_ (u"ࠨษ็ื๏ืแาࠢส่ศ฻ไ๋ࠩ㛛"),l1l1ll_l1_ (u"ࠩสุ่๐ัโำࠣห้ษำา฻ࠪ㛜"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㛝"),message)
		if yes==1 and pingTime_newserver<pingTime_orgserver: server = new_host+l1l1ll_l1_ (u"ࠫ࠿࠭㛞")+new_port
	else: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㛟"),l1l1ll_l1_ (u"࠭ࠧ㛠"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㛡"),l1l1ll_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦอัࠣหู้๊าใิࠤฬ๊ศะ์็ࠫ㛢"))
	settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡷࡪࡸࡶࡦࡴࡢࠫ㛣")+folder,server)
	return
def PLAY(folder,url,type):
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴࡭࠴ࡷ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ㛤")+folder)
	if useragent!=l1l1ll_l1_ (u"ࠫࠬ㛥"): url = url+l1l1ll_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ㛦")+useragent
	#new_server = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡳࡦࡴࡹࡩࡷࡥࠧ㛧")+folder)
	#if new_server:
	#	old_server = re.findall(l1l1ll_l1_ (u"ࠧ࠻࠱࠲ࠬ࠳࠰࠿ࠪ࠱ࠪ㛨"),url,re.DOTALL)
	#	url = url.replace(old_server[0],new_server)
	PLAY_VIDEO(url,script_name,type)
	return
def ADD_USERAGENT(folder):
	DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ㛩"),l1l1ll_l1_ (u"ࠩࠪ㛪"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㛫"),l1l1ll_l1_ (u"ࠫฯำะ๋ำ้ࠣ์๋้้ࠠส้ࠥาฯศࠢ࠱ࠤ๏ืฬ๊ࠢ฼ำ๊ࠦส฻์ํี์ࠦลัษࠣ็๋ะࠠๅษࠣฮ฾ืแࠡ็สࠤ์๎ࠠ࠯ࠢࠣ์฾ีๅࠡฬ฽๎๏ื็ࠡว็หࠥ฿ๆะࠢส่฻ื่าหࠣห้่ี้๋ࠣ࠲ࠥอไฮษฯอ๊ࠥ็ัษࠣห้ะฺ๋์ิࠤ์๐ࠠโไฺࠤสึวูࠡ็ฬฯࠦๅ็ๅุࠣึ้ษࠡโࡐ࠷࡚ࠦร็ࠢอ฽๊๊่ࠠาสࠤฬ๊ส฻์ํีࠥ࠴้ࠠใๅ฻ࠥ฿ๆะ็สࠤฯูสฯั่ࠤำีๅสࠢใࡑ࠸࡛ࠠหฯอหัࠦเࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤำอีࠨ㛬"))
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ㛭")+folder)
	answer = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㛮"),l1l1ll_l1_ (u"ࠧศีอาิอๅࠡษ็วฺ๊๊ࠨ㛯"),l1l1ll_l1_ (u"ࠨฬ฼ำ๏๊ࠠศๆๅำ๏๋ࠧ㛰"),useragent,l1l1ll_l1_ (u"๊ࠩิฬࠦ็้ࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠศๆ่ืฯิฯๆࠢะห้๐วࠡ็฼ࠤๅࡓ࠳ࡖࠢส่ี๐ࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะูะ์็๋ࠥษๅࠡฬิ๎ิࠦลฺษาฮ์ࠦลๅ๋ࠣ์฻฿๊สࠢส่ฯัศ๋ฬࠣห้ษีๅ์ࠣ์ฬ๊ส๋ࠢอๆึ๐ศศࠢอ๊ฬูศࠡฮ่๎฾ࠦิาๅสฮࠥๆࡍ࠴ࡗࠣรࠦ࠭㛱"))
	if answer==1: useragent = OPEN_KEYBOARD(l1l1ll_l1_ (u"ࠪว่ะศࠡโࡐ࠷࡚ࠦࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣะิ๐ฯࠨ㛲"),useragent,True)
	else: useragent = l1l1ll_l1_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ㛳")
	if useragent==l1l1ll_l1_ (u"ࠬࠦࠧ㛴"):
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ㛵"),l1l1ll_l1_ (u"ࠧࠨ㛶"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㛷"),l1l1ll_l1_ (u"ࠩ฽๎ึࠦๅิ็๋ัࠥษำหะาห๊ࠦแาษ฽ࠤ้๎อะ้ࠣวํูࠦะหࠣๅึอฺศฬ่ࠣํำฯ่ษࠣ࠲࠳࠴๋ࠠฮหࠤส๋วࠡฬิ็์ࠦแศำ฽ࠤฯ๋วๆษࠣวํࠦลืษไอࠥำัโࠢฦ์ࠥษ๊ࠡึํࠤวิัࠡ็฼๋ฬ࠭㛸"))
		return
	answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㛹"),l1l1ll_l1_ (u"ࠫࠬ㛺"),l1l1ll_l1_ (u"ࠬ࠭㛻"),useragent,l1l1ll_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅ้ࠡำหࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣฬิ๊วࠡ็้ࠤࠥอไใัํ้ࠥลࠧ㛼"))
	if answer!=1:
		DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㛽"),l1l1ll_l1_ (u"ࠨࠩ㛾"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㛿"),l1l1ll_l1_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧ㜀"))
		return
	settings.setSetting(l1l1ll_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ㜁")+folder,useragent)
	l1l1l11l1ll_l1_(folder)
	return
def GET_URL(folder,iptvURL=l1l1ll_l1_ (u"ࠬ࠭㜂")):
	if not iptvURL: iptvURL = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡶࡴ࡯ࡣࠬ㜃")+folder)
	server = SERVER(iptvURL,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ㜄"))
	username = re.findall(l1l1ll_l1_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠬ࠳࠰࠿ࠪࠨࠪ㜅"),iptvURL+l1l1ll_l1_ (u"ࠩࠩࠫ㜆"),re.DOTALL)
	password = re.findall(l1l1ll_l1_ (u"ࠪࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠮࠮ࠫࡁࠬࠪࠬ㜇"),iptvURL+l1l1ll_l1_ (u"ࠫࠫ࠭㜈"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㜉"),l1l1ll_l1_ (u"࠭ࠧ㜊"),l1l1ll_l1_ (u"ࠧโฯุࠤฬฺสาษๆࠤๅࡏࡐࡕࡘࠪ㜋"),l1l1ll_l1_ (u"ࠨำสฬ฼ࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥอไั์ࠣๆ๊ะࠠศ่อࠤอหึศใอ๋ࠥหไ๊ࠢส่อืๆศ็ฯࠤ้อ๋ࠠ฻่่ࠥษ่ࠡษ็ีฬฮืࠡ฼ํี๋่ࠥอ๊าࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱ࠤศึ็ษࠢศ่๎ࠦโศศ่อࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤํ่ๅࠡสศฺฬ็ษࠡำสฬ฼ࠦเࡊࡒࡗ࡚ࠥาฯ๋ัࠣวํࠦโๆࠢหษฺ๊วฮࠢส่ึอศุࠢส่็ี๊ๆࠩ㜌"))
		return l1l1ll_l1_ (u"ࠩࠪ㜍"),l1l1ll_l1_ (u"ࠪࠫ㜎"),l1l1ll_l1_ (u"ࠫࠬ㜏"),l1l1ll_l1_ (u"ࠬ࠭㜐"),l1l1ll_l1_ (u"࠭ࠧ㜑")
	username = username[0]
	password = password[0]
	URL_player = server+l1l1ll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࡫ࡲࡠࡣࡳ࡭࠳ࡶࡨࡱࡁࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡁࠬ㜒")+username+l1l1ll_l1_ (u"ࠨࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁࠬ㜓")+password
	URL_get = server+l1l1ll_l1_ (u"ࠩ࠲࡫ࡪࡺ࠮ࡱࡪࡳࡃࡺࡹࡥࡳࡰࡤࡱࡪࡃࠧ㜔")+username+l1l1ll_l1_ (u"ࠪࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠧ㜕")+password+l1l1ll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀࡱ࠸ࡻ࡟ࡱ࡮ࡸࡷࠬ㜖")
	return URL_player,URL_get,server,username,password
def GET_FILENAME(folder,URL=l1l1ll_l1_ (u"ࠬ࠭㜗")):
	fullfile = URL.replace(l1l1ll_l1_ (u"࠭࠯ࠨ㜘"),l1l1ll_l1_ (u"ࠧࡠࠩ㜙")).replace(l1l1ll_l1_ (u"ࠨ࠼ࠪ㜚"),l1l1ll_l1_ (u"ࠩࡢࠫ㜛")).replace(l1l1ll_l1_ (u"ࠪ࠲ࠬ㜜"),l1l1ll_l1_ (u"ࠫࡤ࠭㜝"))
	fullfile = fullfile.replace(l1l1ll_l1_ (u"ࠬࡅࠧ㜞"),l1l1ll_l1_ (u"࠭࡟ࠨ㜟")).replace(l1l1ll_l1_ (u"ࠧ࠾ࠩ㜠"),l1l1ll_l1_ (u"ࠨࡡࠪ㜡")).replace(l1l1ll_l1_ (u"ࠩࠩࠫ㜢"),l1l1ll_l1_ (u"ࠪࡣࠬ㜣"))
	fullfile = os.path.join(addoncachefolder,fullfile).strip(l1l1ll_l1_ (u"ࠫ࠳ࡳ࠳ࡶࠩ㜤"))+l1l1ll_l1_ (u"ࠬ࠴࡭࠴ࡷࠪ㜥")
	return fullfile
def ADD_ACCOUNT(folder,l11l1ll1_l1_):
	header_message = l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㜦")
	if l11l1ll1_l1_: header_message = l1l1ll_l1_ (u"ࠧฦุสๅฮ่ࠦห฼ํ๎ึࠦัศสฺࠤࠬ㜧")+text_numbers[int(l11l1ll1_l1_)]
	answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㜨"),l1l1ll_l1_ (u"ࠩࠪ㜩"),l1l1ll_l1_ (u"ࠪࠫ㜪"),header_message,l1l1ll_l1_ (u"ࠫ์ึวࠡษ็ะืวࠠๆ่ࠣห้ฮั็ษ่ะࠥ๐อหษฯࠤึอศุࠢไ๎ิ๐่่ษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢฦ์ࠥษิหำส็๋ࠥฯโ๊฼ࠤ๊์ࠠศๆืี่อสࠡษ็ฮ๏ࠦสษ์฼๋ࠥ๎วๅำสฬ฼ࠦๅ็้ࠢ์฾ࠦ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࡲ࠹ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡟ࡲࡡࡴ้้ࠠำห๋ࠥหศๆ่ࠣฯ๎ึ๋ฯุ่๊่ࠣࠠาสࠤฬ๊ัศสฺࠤࡡࡴࠠࡩࡶࡷࡴࡸࡀ࠯࠰࡫ࡳࡸࡻ࠳࡯ࡳࡩ࠱࡫࡮ࡺࡨࡶࡤ࠱࡭ࡴ࠵ࡩࡱࡶࡹ࠳ࡱࡧ࡮ࡨࡷࡤ࡫ࡪࡹ࠯ࡢࡴࡤ࠲ࡲ࠹ࡵࠡ࡞ࡱࠤ์๊ࠠหำํำࠥหึศใฬࠤศ๎ࠠห฼ํ๎ึࠦร้่ࠢืาࠦวๅำสฬ฼ࠦวๅฤ้ࠤฤ࠭㜫"))
	if answer!=1: return
	old_URL = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ㜬")+folder+l1l1ll_l1_ (u"࠭࡟ࠨ㜭")+l11l1ll1_l1_)
	getnew = True
	if old_URL:
		answer = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㜮"),l1l1ll_l1_ (u"ࠨๅอหอฯࠠอัํำࠬ㜯"),l1l1ll_l1_ (u"ࠩอ฽ิ๐ไࠡษ็ๆิ๐ๅࠨ㜰"),l1l1ll_l1_ (u"ุ้ࠪำࠠศๆๅำ๏๋ࠧ㜱"),l1l1ll_l1_ (u"ࠫฬ๊ัศสฺࠤฬ๊อศๆํࠤ์๎࠺ࠨ㜲"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㜳")+old_URL+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㜴")+l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠥํะศ๊ࠢ์ࠥืวษูࠣไࡒ࠹ࡕࠡษ็ุ้าไࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤฯ฿ฯ๋ๆ๊ࠤศ๋ࠠหำํำ้ࠥสศสฬࠤึอศุࠢฯำ๏ีࠠภࠣࠪ㜵"))
		if answer==-1: return
		elif answer==0: old_URL = l1l1ll_l1_ (u"ࠨࠩ㜶")
		elif answer==2:
			answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜷"),l1l1ll_l1_ (u"ࠪࠫ㜸"),l1l1ll_l1_ (u"ࠫࠬ㜹"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㜺"),l1l1ll_l1_ (u"࠭็ๅࠢอี๏ีࠠๆีะࠤฬ๊ัศสฺࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢยࠥࠬ㜻"))
			if answer in [-1,0]: return
			DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㜼"),l1l1ll_l1_ (u"ࠨࠩ㜽"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㜾"),l1l1ll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣห้ืวษูࠪ㜿"))
			getnew = False
			new_URL = l1l1ll_l1_ (u"ࠫࠬ㝀")
	if getnew:
		new_URL = OPEN_KEYBOARD(l1l1ll_l1_ (u"ࠬอใหสࠣีฬฮืࠡโࡐ࠷࡚ࠦใศ็็หࠬ㝁"),old_URL)
		new_URL = new_URL.strip(l1l1ll_l1_ (u"࠭ࠠࠨ㝂"))
		if not new_URL:
			answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㝃"),l1l1ll_l1_ (u"ࠨࠩ㝄"),l1l1ll_l1_ (u"ࠩࠪ㝅"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㝆"),l1l1ll_l1_ (u"้่ࠫฯࠡไ่ฮࠥฮละะส่ࠥืวษูࠣๅฬืฺࠡ࠰࠱ࠤ์๊ࠠหำํำ๋ࠥำฮࠢส่ึอศุࠢสู่๊ฬๅࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠪ㝇"))
			if answer in [-1,0]: return
			DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㝈"),l1l1ll_l1_ (u"࠭ࠧ㝉"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㝊"),l1l1ll_l1_ (u"ࠨฬ่ࠤู๊อࠡษ็ีฬฮืࠨ㝋"))
		else:
			#URL_player,URL_get,server,username,password = GET_URL(folder)
			#if not username: return
			message = l1l1ll_l1_ (u"๊ࠩิ์ࠦวๅ็฼่ํ๋วหࠢอ้ࠥษฮั้สࠤ๊์ࠠาษห฻ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡษ้ฮ้ࠥสษฬ๊ࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ษࠣรࠦࡢ࡮ࠨ㝌")
			#message += l1l1ll_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㝍")+server+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ฿ๆ้ษ้ࠤฬ๊ำ๋ำไี࠿ࠦࠧ㝎")
			#message += l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ㝏")+username+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ศี่ࠤฬ๊ๅิฬัำ๊ࡀࠠࠨ㝐")
			#message += l1l1ll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㝑")+password+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ๆ่๊ฯࠠศๆึี࠿ࠦࠧ㝒")
			answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࠪ㝓"),l1l1ll_l1_ (u"ࠪࠫ㝔"),l1l1ll_l1_ (u"ࠫࠬ㝕"),l1l1ll_l1_ (u"ࠬอไาษห฻ࠥอไอัํำࠥํ่࠻ࠩ㝖"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㝗")+new_URL+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㝘")+l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㝙")+message)
			if answer!=1:
				DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㝚"),l1l1ll_l1_ (u"ࠪࠫ㝛"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㝜"),l1l1ll_l1_ (u"ࠬะๅࠡษ็ษ้เวยࠩ㝝"))
				return
	settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡳ࡮ࡢࠫ㝞")+folder+l1l1ll_l1_ (u"ࠧࡠࠩ㝟")+l11l1ll1_l1_,new_URL)
	#settings.setSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࡤ࠭㝠")+folder,l1l1ll_l1_ (u"ࠩࠪ㝡"))
	#settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫ࡥࠧ㝢")+folder,l1l1ll_l1_ (u"ࠫࠬ㝣"))
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ㝤")+folder)
	if not useragent: settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰ࠷ࡺ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡡࠪ㝥")+folder,l1l1ll_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ㝦"))
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㝧"),l1l1ll_l1_ (u"ࠩࠪ㝨"),l1l1ll_l1_ (u"ࠪࠫ㝩"),l1l1ll_l1_ (u"ࠫࠬ㝪"),new_URL+l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰอ้ࠥะฺ๋ำࠣีฬฮืࠡษืฮึอใࠡโࡐ࠷࡚ࠦลๅ๋๋ࠣีอࠠศๆิหอ฽ࠠศๆฯำ๏ีࠠ࠯࠰࠱ࠤ์๊ࠠหำํำࠥ็อึ๊ࠢิฬࠦวๅำสฬ฼ࠦวๅฤ้ࠤฤ࠭㝫"))
	if yes==1: ok,new_host,new_port = CHECK_ACCOUNT(folder,True)
	l1l1l11l1ll_l1_(folder)
	return
def READ_ALL_LINES(lines,live_epg_channels,live_archived_channels,pDialog,length,jj,URL_get):
	streams,ignored_streams = [],[]
	vod_types = [l1l1ll_l1_ (u"࠭࠮ࡢࡸ࡬ࠫ㝬"),l1l1ll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ㝭"),l1l1ll_l1_ (u"ࠨ࠰ࡰ࡯ࡻ࠭㝮"),l1l1ll_l1_ (u"ࠩ࠱ࡪࡱࡼࠧ㝯"),l1l1ll_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ㝰"),l1l1ll_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ㝱")]
	for line in lines:
		if jj%473==0:
			PROGRESS_UPDATE(pDialog,40+int(10*jj/length),l1l1ll_l1_ (u"่ࠬัศรฬࠤฬ๊แ๋ัํ์์อสࠨ㝲"),l1l1ll_l1_ (u"࠭วๅใํำ๏๎ࠠาไ่࠾࠲࠭㝳"),str(jj)+l1l1ll_l1_ (u"ࠧࠡ࠱ࠣࠫ㝴")+str(length))
			if pDialog.iscanceled(): return None,None,None
		if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ㝵") in line:
			line,url = line.rsplit(l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㝶"),1)
			url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ㝷")+url
		elif l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ㝸") in line:
			line,url = line.rsplit(l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ㝹"),1)
			url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㝺")+url
		elif l1l1ll_l1_ (u"ࠧࡳࡶࡰࡴ࠿࠭㝻") in line:
			line,url = line.rsplit(l1l1ll_l1_ (u"ࠨࡴࡷࡱࡵࡀࠧ㝼"),1)
			url = l1l1ll_l1_ (u"ࠩࡵࡸࡲࡶ࠺ࠨ㝽")+url
		else:
			ignored_streams.append({l1l1ll_l1_ (u"ࠪࡰ࡮ࡴࡥࠨ㝾"):line})
			continue
		dict1,context,group,title,type,is_vod_url = {},l1l1ll_l1_ (u"ࠫࠬ㝿"),l1l1ll_l1_ (u"ࠬ࠭㞀"),l1l1ll_l1_ (u"࠭ࠧ㞁"),l1l1ll_l1_ (u"ࠧࠨ㞂"),False
		try:
			line,title = line.rsplit(l1l1ll_l1_ (u"ࠨࠤ࠯ࠫ㞃"),1)
			line = line+l1l1ll_l1_ (u"ࠩࠥࠫ㞄")
		except:
			try: line,title = line.rsplit(l1l1ll_l1_ (u"ࠪ࠵࠱࠭㞅"),1)
			except: title = l1l1ll_l1_ (u"ࠫࠬ㞆")
		dict1[l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ㞇")] = url
		params = re.findall(l1l1ll_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㞈"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l1l1ll_l1_ (u"ࠧࠣࠩ㞉"),l1l1ll_l1_ (u"ࠨࠩ㞊")).strip(l1l1ll_l1_ (u"ࠩࠣࠫ㞋"))
			dict1[key] = value.strip(l1l1ll_l1_ (u"ࠪࠤࠬ㞌"))
		keys = list(dict1.keys())
		if not title:
			if l1l1ll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㞍") in keys and dict1[l1l1ll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㞎")]: title = dict1[l1l1ll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㞏")]
		dict1[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㞐")] = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ㞑")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠬ㞒"),l1l1ll_l1_ (u"ࠪࠤࠬ㞓")).replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧ㞔"),l1l1ll_l1_ (u"ࠬࠦࠧ㞕"))
		if l1l1ll_l1_ (u"࠭࡬ࡰࡩࡲࠫ㞖") in keys:
			dict1[l1l1ll_l1_ (u"ࠧࡪ࡯ࡪࠫ㞗")] = dict1[l1l1ll_l1_ (u"ࠨ࡮ࡲ࡫ࡴ࠭㞘")]
			del dict1[l1l1ll_l1_ (u"ࠩ࡯ࡳ࡬ࡵࠧ㞙")]
		else: dict1[l1l1ll_l1_ (u"ࠪ࡭ࡲ࡭ࠧ㞚")] = l1l1ll_l1_ (u"ࠫࠬ㞛")
		if l1l1ll_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ㞜") in keys and dict1[l1l1ll_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ㞝")]: group = dict1[l1l1ll_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠭㞞")]
		if any(value in url.lower() for value in vod_types): is_vod_url = True
		if is_vod_url or l1l1ll_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㞟") in group or l1l1ll_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭㞠") in group:
			type = l1l1ll_l1_ (u"࡚ࠪࡔࡊࠧ㞡")
			if l1l1ll_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㞢") in group: type = type+l1l1ll_l1_ (u"ࠬࡥࡓࡆࡔࡌࡉࡘ࠭㞣")
			elif l1l1ll_l1_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ㞤") in group: type = type+l1l1ll_l1_ (u"ࠧࡠࡏࡒ࡚ࡎࡋࡓࠨ㞥")
			else: type = type+l1l1ll_l1_ (u"ࠨࡡࡘࡒࡐࡔࡏࡘࡐࠪ㞦")
			group = group.replace(l1l1ll_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㞧"),l1l1ll_l1_ (u"ࠪࠫ㞨")).replace(l1l1ll_l1_ (u"ࠫࡤࡥࡍࡐࡘࡌࡉࡘࡥ࡟ࠨ㞩"),l1l1ll_l1_ (u"ࠬ࠭㞪"))
		else:
			type = l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࠫ㞫")
			if title in live_epg_channels: context = context+l1l1ll_l1_ (u"ࠧࡠࡇࡓࡋࠬ㞬")
			if title in live_archived_channels: context = context+l1l1ll_l1_ (u"ࠨࡡࡄࡖࡈࡎࡉࡗࡇࡇࠫ㞭")
			if not group: type = type+l1l1ll_l1_ (u"ࠩࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ㞮")
			else: type = type+context
		group = group.strip(l1l1ll_l1_ (u"ࠪࠤࠬ㞯")).replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧ㞰"),l1l1ll_l1_ (u"ࠬࠦࠧ㞱")).replace(l1l1ll_l1_ (u"࠭ࠠࠡࠩ㞲"),l1l1ll_l1_ (u"ࠧࠡࠩ㞳"))
		if l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔࠧ㞴") in type: group = l1l1ll_l1_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡍࡋ࡙ࡉࡤࡥࠡࠢࠩ㞵")
		elif l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࠨ㞶") in type: group = l1l1ll_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡ࡙ࡓࡉࡥ࡟ࠢࠣࠪ㞷")
		elif l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࠩ㞸") in type:
			series_title = re.findall(l1l1ll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥࡡࡓࡴ࡟࡟ࡨ࠰ࠦࠫ࡜ࡇࡨࡡࡡࡪࠫࠨ㞹"),dict1[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㞺")],re.DOTALL)
			if series_title: series_title = series_title[0]
			else: series_title = l1l1ll_l1_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠢࠣࠪ㞻")
			group = group+l1l1ll_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㞼")+series_title
		id2 = l1l1ll_l1_ (u"ࠪࠫ㞽")
		if l1l1ll_l1_ (u"ࠫ࡮ࡪࠧ㞾") in keys:
			id2 = dict1[l1l1ll_l1_ (u"ࠬ࡯ࡤࠨ㞿")]
			del dict1[l1l1ll_l1_ (u"࠭ࡩࡥࠩ㟀")]
		if l1l1ll_l1_ (u"ࠧࡊࡆࠪ㟁") in keys:
			id2 = dict1[l1l1ll_l1_ (u"ࠨࡋࡇࠫ㟂")]
			del dict1[l1l1ll_l1_ (u"ࠩࡌࡈࠬ㟃")]
		if l1l1ll_l1_ (u"ࠪ࡭ࡵࡺࡶ࠮ࡱࡵ࡫ࠬ㟄") in URL_get and l1l1ll_l1_ (u"ࠫ࠳࠭㟅") in id2:
			id2 = id2.rsplit(l1l1ll_l1_ (u"ࠬ࠴ࠧ㟆"),1)[1]
			id2 = l1l1ll_l1_ (u"࠭ࡼࠨ㟇")+id2.upper()+l1l1ll_l1_ (u"ࠧࡽࠢࠪ㟈")
		if l1l1ll_l1_ (u"ࠨࡰࡤࡱࡪ࠭㟉") in keys: del dict1[l1l1ll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㟊")]
		title = id2+dict1[l1l1ll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㟋")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		country,title = SPLIT_NAME(title)
		dict1[l1l1ll_l1_ (u"ࠫࡹࡿࡰࡦࠩ㟌")] = type
		dict1[l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭㟍")] = context
		dict1[l1l1ll_l1_ (u"࠭ࡧࡳࡱࡸࡴࠬ㟎")] = group.upper()
		dict1[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㟏")] = title.upper()
		try: dict1[l1l1ll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㟐")] = COUNTRY_NAME[country.upper()]
		except: dict1[l1l1ll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㟑")] = country.upper()
		dict1[l1l1ll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ㟒")] = language.upper()
		streams.append(dict1)
		jj += 1
	return streams,jj,ignored_streams
def CLEAN_NAME(title):
	title = title.replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧ㟓"),l1l1ll_l1_ (u"ࠬࠦࠧ㟔")).replace(l1l1ll_l1_ (u"࠭ࠠࠡࠩ㟕"),l1l1ll_l1_ (u"ࠧࠡࠩ㟖")).replace(l1l1ll_l1_ (u"ࠨࠢࠣࠫ㟗"),l1l1ll_l1_ (u"ࠩࠣࠫ㟘"))
	title = title.replace(l1l1ll_l1_ (u"ࠪࢀࢁ࠭㟙"),l1l1ll_l1_ (u"ࠫࢁ࠭㟚")).replace(l1l1ll_l1_ (u"ࠬࡥ࡟ࡠࠩ㟛"),l1l1ll_l1_ (u"࠭࠺ࠨ㟜")).replace(l1l1ll_l1_ (u"ࠧ࠮࠯ࠪ㟝"),l1l1ll_l1_ (u"ࠨ࠯ࠪ㟞"))
	title = title.replace(l1l1ll_l1_ (u"ࠩ࡞࡟ࠬ㟟"),l1l1ll_l1_ (u"ࠪ࡟ࠬ㟠")).replace(l1l1ll_l1_ (u"ࠫࡢࡣࠧ㟡"),l1l1ll_l1_ (u"ࠬࡣࠧ㟢"))
	title = title.replace(l1l1ll_l1_ (u"࠭ࠨࠩࠩ㟣"),l1l1ll_l1_ (u"ࠧࠩࠩ㟤")).replace(l1l1ll_l1_ (u"ࠨࠫࠬࠫ㟥"),l1l1ll_l1_ (u"ࠩࠬࠫ㟦"))
	title = title.replace(l1l1ll_l1_ (u"ࠪࡀࡁ࠭㟧"),l1l1ll_l1_ (u"ࠫࡁ࠭㟨")).replace(l1l1ll_l1_ (u"ࠬࡄ࠾ࠨ㟩"),l1l1ll_l1_ (u"࠭࠾ࠨ㟪"))
	title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩ㟫"))
	return title
def CREATE_GROUPED_STREAMS(streams_not_sorted,pDialog,l11l1ll1_l1_):
	grouped_streams = {}
	for type1 in UNIQUE_TYPES: grouped_streams[type1+l1l1ll_l1_ (u"ࠨࡡࠪ㟬")+l11l1ll1_l1_] = []
	length = len(streams_not_sorted)
	text3 = str(length)
	jj = 0
	ignored_streams = []
	for dict1 in streams_not_sorted:
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,50+int(5*jj/length),l1l1ll_l1_ (u"ࠩอู๋๐แࠡษ็ๅ๏ี๊้้สฮࠥอไ฻์ิࠤ๊ืสษหࠪ㟭"),l1l1ll_l1_ (u"ࠪห้็๊ะ์๋ࠤึ่ๅ࠻࠯ࠪ㟮"),str(jj)+l1l1ll_l1_ (u"ࠫࠥ࠵ࠠࠨ㟯")+text3)
			if pDialog.iscanceled(): return None,None
		group,context,title,url,img = dict1[l1l1ll_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ㟰")],dict1[l1l1ll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ㟱")],dict1[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㟲")],dict1[l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ㟳")],dict1[l1l1ll_l1_ (u"ࠩ࡬ࡱ࡬࠭㟴")]
		country,language,type1 = dict1[l1l1ll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㟵")],dict1[l1l1ll_l1_ (u"ࠫࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭㟶")],dict1[l1l1ll_l1_ (u"ࠬࡺࡹࡱࡧࠪ㟷")]
		tuple2 = (group,context,title,url,img)
		fail = False
		if l1l1ll_l1_ (u"࠭ࡌࡊࡘࡈࠫ㟸") in type1:
			if l1l1ll_l1_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨ㟹") in type1: grouped_streams[l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࠩ㟺")+l11l1ll1_l1_].append(tuple2)
			elif l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㟻") in type1: grouped_streams[l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㟼")+l11l1ll1_l1_].append(tuple2)
			else: fail = True
			grouped_streams[l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭㟽")+l11l1ll1_l1_].append(tuple2)
		elif l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࠩ㟾") in type1:
			if l1l1ll_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧ㟿") in type1: grouped_streams[l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ㠀")+l11l1ll1_l1_].append(tuple2)
			elif l1l1ll_l1_ (u"ࠨࡏࡒ࡚ࡎࡋࡓࠨ㠁") in type1: grouped_streams[l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࠨ㠂")+l11l1ll1_l1_].append(tuple2)
			elif l1l1ll_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕࠪ㠃") in type1: grouped_streams[l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㠄")+l11l1ll1_l1_].append(tuple2)
			else: fail = True
			grouped_streams[l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭㠅")+l11l1ll1_l1_].append(tuple2)
		else: fail = True
		if fail: ignored_streams.append(dict1)
		jj += 1
	streams_sorted = sorted(streams_not_sorted,reverse=False,key=lambda key: key[l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㠆")].lower())
	del streams_not_sorted
	text3 = str(length)
	jj = 0
	for dict1 in streams_sorted:
		jj += 1
		if jj%873==0:
			PROGRESS_UPDATE(pDialog,55+int(5*jj/length),l1l1ll_l1_ (u"ࠧหื้๎ๆࠦวๅใํำ๏๎็ศฬࠣห้๋ัหสฬࠫ㠇"),l1l1ll_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢิๆ๊ࡀ࠭ࠨ㠈"),str(jj)+l1l1ll_l1_ (u"ࠩࠣ࠳ࠥ࠭㠉")+text3)
			if pDialog.iscanceled(): return None,None
		type1 = dict1[l1l1ll_l1_ (u"ࠪࡸࡾࡶࡥࠨ㠊")]
		group,context,title,url,img = dict1[l1l1ll_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪ㠋")],dict1[l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭㠌")],dict1[l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㠍")],dict1[l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ㠎")],dict1[l1l1ll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ㠏")]
		country,language = dict1[l1l1ll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㠐")],dict1[l1l1ll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ㠑")]
		tuple1 = (group,context+l1l1ll_l1_ (u"ࠫࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࠨ㠒"),title,url,img)
		tuple2 = (group,context,title,url,img)
		tuple3 = (country,context,title,url,img)
		tuple4 = (language,context,title,url,img)
		if l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࠪ㠓") in type1:
			if l1l1ll_l1_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧ㠔") in type1: grouped_streams[l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠕")+l11l1ll1_l1_].append(tuple2)
			else: grouped_streams[l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠖")+l11l1ll1_l1_].append(tuple2)
			if l1l1ll_l1_ (u"ࠩࡈࡔࡌ࠭㠗")		in type1: grouped_streams[l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡇࡓࡋࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ㠘")+l11l1ll1_l1_].append(tuple2)
			if l1l1ll_l1_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭㠙")	in type1: grouped_streams[l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡅࡗࡉࡈࡊࡘࡈࡈࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ㠚")+l11l1ll1_l1_].append(tuple2)
			if l1l1ll_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ㠛")	in type1: grouped_streams[l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡚ࡉࡎࡇࡖࡌࡎࡌࡔࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㠜")+l11l1ll1_l1_].append(tuple1)
			grouped_streams[l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡓࡇࡍࡆࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㠝")+l11l1ll1_l1_].append(tuple3)
			grouped_streams[l1l1ll_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࡣࠬ㠞")+l11l1ll1_l1_].append(tuple4)
		elif l1l1ll_l1_ (u"࡚ࠪࡔࡊࠧ㠟") in type1:
			if   l1l1ll_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ㠠")	in type1: grouped_streams[l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ㠡")+l11l1ll1_l1_].append(tuple2)
			elif l1l1ll_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭㠢")	in type1: grouped_streams[l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭㠣")+l11l1ll1_l1_].append(tuple2)
			elif l1l1ll_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ㠤")	in type1: grouped_streams[l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠥")+l11l1ll1_l1_].append(tuple2)
			grouped_streams[l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠦")+l11l1ll1_l1_].append(tuple3)
			grouped_streams[l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࡤ࠭㠧")+l11l1ll1_l1_].append(tuple4)
	return grouped_streams,ignored_streams
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	lang,sep = l1l1ll_l1_ (u"ࠬ࠭㠨"),l1l1ll_l1_ (u"࠭ࠧ㠩")
	title2 = title
	first = title[:1]
	rest = title[1:]
	if   first==l1l1ll_l1_ (u"ࠧࠩࠩ㠪"): sep = l1l1ll_l1_ (u"ࠨࠫࠪ㠫")
	elif first==l1l1ll_l1_ (u"ࠩ࡞ࠫ㠬"): sep = l1l1ll_l1_ (u"ࠪࡡࠬ㠭")
	elif first==l1l1ll_l1_ (u"ࠫࡁ࠭㠮"): sep = l1l1ll_l1_ (u"ࠬࡄࠧ㠯")
	elif first==l1l1ll_l1_ (u"࠭ࡼࠨ㠰"): sep = l1l1ll_l1_ (u"ࠧࡽࠩ㠱")
	if sep and (sep in rest):
		part1,part2 = rest.split(sep,1)
		lang = part1
		title2 = first+part1+sep+l1l1ll_l1_ (u"ࠨࠢࠪ㠲")+part2
	elif title.count(l1l1ll_l1_ (u"ࠩࡿࠫ㠳"))>=2:
		part1,part2 = title.split(l1l1ll_l1_ (u"ࠪࢀࠬ㠴"),1)
		lang = part1
		title2 = part1+l1l1ll_l1_ (u"ࠫࠥࢂࠧ㠵")+part2
	else:
		sep = re.findall(l1l1ll_l1_ (u"ࠬࡤ࡜ࡸࡽ࠵ࢁ࠭ࠦࡼ࡝࠼ࡿࡠ࠲ࢂ࡜ࡽࡾ࡟ࡡࢁࡢࠩࡽ࡞ࠦࢀࡡ࠴ࡼ࡝࠮ࡿࡠࠩࢂ࡜ࠨࡾ࡟ࠥࢁࡢࡀࡽ࡞ࠨࢀࡡࠬࡼ࡝ࠬࡿࡠࡣ࠯ࠧ㠶"),title,re.DOTALL)
		if not sep: sep = re.findall(l1l1ll_l1_ (u"࠭࡞࡝ࡹࡾ࠷ࢂ࠮ࠠࡽ࡞࠽ࢀࡡ࠳ࡼ࡝ࡾࡿࡠࡢࢂ࡜ࠪࡾ࡟ࠧࢁࡢ࠮ࡽ࡞࠯ࢀࡡࠪࡼ࡝ࠩࡿࡠࠦࢂ࡜ࡁࡾ࡟ࠩࢁࡢࠦࡽ࡞࠭ࢀࡡࡤࠩࠨ㠷"),title,re.DOTALL)
		if not sep: sep = re.findall(l1l1ll_l1_ (u"ࠧ࡟࡞ࡺࡿ࠹ࢃࠨࠡࡾ࡟࠾ࢁࡢ࠭ࡽ࡞ࡿࢀࡡࡣࡼ࡝ࠫࡿࡠࠨࢂ࡜࠯ࡾ࡟࠰ࢁࡢࠤࡽ࡞ࠪࢀࡡࠧࡼ࡝ࡂࡿࡠࠪࢂ࡜ࠧࡾ࡟࠮ࢁࡢ࡞ࠪࠩ㠸"),title,re.DOTALL)
		if sep:
			part1,part2 = title.split(sep[0],1)
			lang = part1
			title2 = part1+l1l1ll_l1_ (u"ࠨࠢࠪ㠹")+sep[0]+l1l1ll_l1_ (u"ࠩࠣࠫ㠺")+part2
	title2 = title2.replace(l1l1ll_l1_ (u"ࠪࠤࠥࠦࠧ㠻"),l1l1ll_l1_ (u"ࠫࠥ࠭㠼")).replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ㠽"),l1l1ll_l1_ (u"࠭ࠠࠨ㠾"))
	lang = lang.replace(l1l1ll_l1_ (u"ࠧࠡࠢࠪ㠿"),l1l1ll_l1_ (u"ࠨࠢࠪ㡀"))
	if not lang: lang = l1l1ll_l1_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡠࠣࠤࠫ㡁")
	lang = lang.strip(l1l1ll_l1_ (u"ࠪࠤࠬ㡂"))
	title2 = title2.strip(l1l1ll_l1_ (u"ࠫࠥ࠭㡃"))
	return lang,title2
def CREATE_STREAMS(folder,l11l1ll1_l1_):
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	URL_get = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ㡄")+folder+l1l1ll_l1_ (u"࠭࡟ࠨ㡅")+l11l1ll1_l1_)
	#URL_player,URL_get,server,username,password = GET_URL(folder)
	#if not username: return
	useragent = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㡆")+folder)
	headers = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㡇"):useragent}
	#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㡈"),l1l1ll_l1_ (u"ࠪࠫ㡉"),l1l1ll_l1_ (u"ࠫࠬ㡊"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㡋"),l1l1ll_l1_ (u"ู࠭ๆๆํอࠥาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอ่ࠥฯࠡฬะฮฬาฺࠠัฬࠤิ่ววไࠣ࠲ࠥํไࠡฬิ๎ิࠦร็ࠢอะ้ฮࠠศๆ่่ๆอสࠡษ็ฦ๋ࠦฟࠨ㡌"))
	#if yes!=1: return
	fullfile = l1l1l11l111_l1_.replace(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ㡍"),l1l1ll_l1_ (u"ࠨࡡࠪ㡎")+folder+l1l1ll_l1_ (u"ࠩࡢࠫ㡏")+l11l1ll1_l1_)
	if 1:
		ok,new_host,new_port = True,l1l1ll_l1_ (u"ࠪࠫ㡐"),l1l1ll_l1_ (u"ࠫࠬ㡑")
		if not ok:
			DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㡒"),l1l1ll_l1_ (u"࠭ࠧ㡓"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㡔"),l1l1ll_l1_ (u"ࠨใื่ࠥฮำฮส้้ࠣ็วหࠢใࡑ࠸࡛ࠠ࠯ࠢฦัฯ๋วๅࠢิหอ฽ࠠแࡏ࠶࡙ࠥเ๊าุࠢั๏ำࠠฤ๊ࠣห๋ะࠠๅ็ࠣฮุะฮะ็ࠣืฬฮโศࠢัำ๊ฯࠠแࡏ࠶࡙ࠥอไๆ๊ฯ์ิฯࠠษษ็ฬึ์วๆฮࠣ࠲࠳ูࠦๅ็สࠤศ์่ࠠา๊ࠤฬ๊ฮะ็ฬࠤฯำสศฮࠣหูะัศๅ้ࠣิ็ฺู่๋ࠢา๐อ๊ࠡํะอࠦร็ࠢอฺ๏็ࠠาษห฻ࠥอไศึอีฬ้ࠠษ่ไื่ࠦไๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣๆฬฬๅสࠢใࡑ࠸࡛ࠠศๆ่์ั๎ฯสࠢห๋ีอࠠศๆหี๋อๅอࠩ㡕"))
			if not URL_get: LOG_THIS(l1l1ll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㡖"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࡎࡰࠢࡐ࠷࡚ࠦࡕࡓࡎࠣࡪࡴࡻ࡮ࡥࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡎ࠵ࡘࠤ࡫࡯࡬ࡦࡵࠪ㡗"))
			else: LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㡘"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡍ࠴ࡗࠣࡪ࡮ࡲࡥࡴࠩ㡙"))
			return
		m3u_text = DOWNLOAD_USING_PROGRESSBAR(URL_get,headers,False)
		if not m3u_text: return
		open(fullfile,l1l1ll_l1_ (u"࠭ࡷࡣࠩ㡚")).write(m3u_text)
	else: m3u_text = open(fullfile,l1l1ll_l1_ (u"ࠧࡳࡤࠪ㡛")).read()
	if kodi_version>18.99: m3u_text = m3u_text.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㡜"))
	pDialog = DIALOG_PROGRESS()
	pDialog.create(l1l1ll_l1_ (u"ࠩฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠩ㡝"),l1l1ll_l1_ (u"ࠪࠫ㡞"))
	m3u_text = m3u_text.replace(l1l1ll_l1_ (u"ࠫࠧࡺࡶࡨ࠯ࠪ㡟"),l1l1ll_l1_ (u"ࠬࠨࠠࡵࡸࡪ࠱ࠬ㡠"))
	m3u_text = m3u_text.replace(l1l1ll_l1_ (u"࠭๎ࠨ㡡"),l1l1ll_l1_ (u"ࠧࠨ㡢")).replace(l1l1ll_l1_ (u"ࠨํࠪ㡣"),l1l1ll_l1_ (u"ࠩࠪ㡤")).replace(l1l1ll_l1_ (u"ࠪ๓ࠬ㡥"),l1l1ll_l1_ (u"ࠫࠬ㡦")).replace(l1l1ll_l1_ (u"ࠬ๒ࠧ㡧"),l1l1ll_l1_ (u"࠭ࠧ㡨"))
	m3u_text = m3u_text.replace(l1l1ll_l1_ (u"ࠧ๒ࠩ㡩"),l1l1ll_l1_ (u"ࠨࠩ㡪")).replace(l1l1ll_l1_ (u"ࠩ๓ࠫ㡫"),l1l1ll_l1_ (u"ࠪࠫ㡬")).replace(l1l1ll_l1_ (u"ࠫ๒࠭㡭"),l1l1ll_l1_ (u"ࠬ࠭㡮")).replace(l1l1ll_l1_ (u"࠭๒ࠨ㡯"),l1l1ll_l1_ (u"ࠧࠨ㡰"))
	m3u_text = m3u_text.replace(l1l1ll_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠧ㡱"),l1l1ll_l1_ (u"ࠩࡪࡶࡴࡻࡰ࠾ࠩ㡲"))
	m3u_text = m3u_text.replace(l1l1ll_l1_ (u"ࠪࡸࡻ࡭࠭ࠨ㡳"),l1l1ll_l1_ (u"ࠫࠬ㡴")).replace(l1l1ll_l1_ (u"ࠬࡢࡲࠨ㡵"),l1l1ll_l1_ (u"࠭ࠧ㡶")).replace(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ㡷"),l1l1ll_l1_ (u"ࠨࠩ㡸"))
	live_archived_channels,live_epg_channels = [],[]
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࡐࡓࡑࡊࡖࡊ࡙ࡓࡠࡗࡓࡈࡆ࡚ࡅࠩࡲࡇ࡭ࡦࡲ࡯ࡨ࠮࠵࠴࠱࠭ฬๅสࠣห้๋ไโษอࠤฬ๊หศ่๋๎ฮ࠭ࠬࠨษ็้้็ࠠาไ่࠾࠲࠭ࠬࠨ࠳ࠣ࠳ࠥ࠹ࠧࠪࠌࠌ࡭࡫ࠦࡰࡅ࡫ࡤࡰࡴ࡭࠮ࡪࡵࡦࡥࡳࡩࡥ࡭ࡧࡧࠬ࠮ࡀࠠࡳࡧࡷࡹࡷࡴࠊࠊࡷࡵࡰࠥࡃࠠࡖࡔࡏࡣࡵࡲࡡࡺࡧࡵ࠯ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡢࡷࡪࡸࡩࡦࡵࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡋࡓࡘ࡛࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡦࡵࡦࡥࡵ࡫ࡕࡏࡋࡆࡓࡉࡋࠨࡩࡶࡰࡰ࠮ࠐࠉࡴࡧࡵ࡭ࡪࡹ࡟ࡨࡴࡲࡹࡵࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࡡࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡤࡦ࡮ࠣ࡬ࡹࡳ࡬ࠋࠋࡩࡳࡷࠦࡧࡳࡱࡸࡴࠥ࡯࡮ࠡࡵࡨࡶ࡮࡫ࡳࡠࡩࡵࡳࡺࡶࡳ࠻ࠌࠌࠍ࡬ࡸ࡯ࡶࡲࠣࡁࠥ࡭ࡲࡰࡷࡳ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࠰ࠩ࠯ࠫ࠴࠭ࠩࠋࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡁ࠷࠹࠻ࠢࡪࡶࡴࡻࡰࠡ࠿ࠣ࡫ࡷࡵࡵࡱ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠎࠎࠏ࡭࠴ࡷࡢࡸࡪࡾࡴࠡ࠿ࠣࡱ࠸ࡻ࡟ࡵࡧࡻࡸ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡨࡴࡲࡹࡵࡃࠢࠨ࠭ࡪࡶࡴࡻࡰࠬࠩࠥࠫ࠱࠭ࡧࡳࡱࡸࡴࡂࠨ࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ࠯࡬ࡸ࡯ࡶࡲ࠮ࠫࠧ࠭ࠩࠋࠋࡧࡩࡱࠦࡳࡦࡴ࡬ࡩࡸࡥࡧࡳࡱࡸࡴࡸࠐࠉࡑࡔࡒࡋࡗࡋࡓࡔࡡࡘࡔࡉࡇࡔࡆࠪࡳࡈ࡮ࡧ࡬ࡰࡩ࠯࠶࠺࠲ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯࠧ࠭ࠩส่๊๊แࠡำๅ้࠿࠳ࠧ࠭ࠩ࠵ࠤ࠴ࠦ࠳ࠨࠫࠍࠍ࡮࡬ࠠࡱࡆ࡬ࡥࡱࡵࡧ࠯࡫ࡶࡧࡦࡴࡣࡦ࡮ࡨࡨ࠭࠯࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡸࡶࡱࠦ࠽ࠡࡗࡕࡐࡤࡶ࡬ࡢࡻࡨࡶ࠰࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡻࡵࡤࡠࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠬࠐࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࡉࡑࡖ࡙࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭࡮ࡴ࡮࡮ࠬࠎࠎࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡦࡨࡰࠥ࡮ࡴ࡮࡮ࠍࠍ࡫ࡵࡲࠡࡩࡵࡳࡺࡶࠠࡪࡰࠣࡺࡴࡪ࡟ࡨࡴࡲࡹࡵࡹ࠺ࠋࠋࠌ࡫ࡷࡵࡵࡱࠢࡀࠤ࡬ࡸ࡯ࡶࡲ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡀ࠶࠿࠺ࠡࡩࡵࡳࡺࡶࠠ࠾ࠢࡪࡶࡴࡻࡰ࠯ࡦࡨࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪ࠰ࡨࡲࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࡳ࠳ࡶࡡࡷࡩࡽࡺࠠ࠾ࠢࡰ࠷ࡺࡥࡴࡦࡺࡷ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡧࡳࡱࡸࡴࡂࠨࠧࠬࡩࡵࡳࡺࡶࠫࠨࠤࠪ࠰ࠬ࡭ࡲࡰࡷࡳࡁࠧࡥ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡠࠩ࠮࡫ࡷࡵࡵࡱ࠭ࠪࠦࠬ࠯ࠊࠊࡦࡨࡰࠥࡼ࡯ࡥࡡࡪࡶࡴࡻࡰࡴࠌࠌࡔࡗࡕࡇࡓࡇࡖࡗࡤ࡛ࡐࡅࡃࡗࡉ࠭ࡶࡄࡪࡣ࡯ࡳ࡬࠲࠳࠱࠮ࠪะ้ฮࠠศๆ่่ๆอสࠡษ็ฯฬ์่๋หࠪ࠰ࠬอไๆๆไࠤึ่ๅ࠻࠯ࠪ࠰ࠬ࠹ࠠ࠰ࠢ࠶ࠫ࠮ࠐࠉࡪࡨࠣࡴࡉ࡯ࡡ࡭ࡱࡪ࠲࡮ࡹࡣࡢࡰࡦࡩࡱ࡫ࡤࠩࠫ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤ࡚ࡘࡌࡠࡲ࡯ࡥࡾ࡫ࡲࠬࠩࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟࡭࡫ࡹࡩࡤࡹࡴࡳࡧࡤࡱࡸ࠭ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡊࡒࡗ࡚࠲ࡉࡒࡆࡃࡗࡉࡤ࡙ࡔࡓࡇࡄࡑࡘ࠳࠳ࡳࡦࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏ࡬ࡪࡸࡨࡣࡦࡸࡣࡩ࡫ࡹࡩࡩࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢ࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸࡻࡥࡡࡳࡥ࡫࡭ࡻ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢࡱࡥࡲ࡫ࠬࡢࡴࡦ࡬࡮ࡼࡥࡥࠢ࡬ࡲࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨ࠿ࠐࠉࠊ࡫ࡩࠤࡦࡸࡣࡩ࡫ࡹࡩࡩࡃ࠽ࠨ࠳ࠪ࠾ࠥࡲࡩࡷࡧࡢࡥࡷࡩࡨࡪࡸࡨࡨࡤࡩࡨࡢࡰࡱࡩࡱࡹ࠮ࡢࡲࡳࡩࡳࡪࠨ࡯ࡣࡰࡩ࠮ࠐࠉࡥࡧ࡯ࠤࡱ࡯ࡶࡦࡡࡤࡶࡨ࡮ࡩࡷࡧࡧࠎࠎࡲࡩࡷࡧࡢࡩࡵ࡭ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡪࡶࡧࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡ࡬ࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡨࡪࡲࠠࡩࡶࡰࡰࠏࠏࡦࡰࡴࠣࡲࡦࡳࡥ࠭ࡧࡳ࡫ࠥ࡯࡮ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩ࠽ࠎࠎࠏࡩࡧࠢࡨࡴ࡬ࠧ࠽ࠨࡰࡸࡰࡱ࠭࠺ࠡ࡮࡬ࡺࡪࡥࡥࡱࡩࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡡ࡮ࡧࠬࠎࠎࡪࡥ࡭ࠢ࡯࡭ࡻ࡫࡟ࡦࡲࡪࠎࠎࠨࠢࠣ㡹")
	lines = re.findall(l1l1ll_l1_ (u"ࠪࡒࡋࡀࠨ࠯࠭ࡂ࠭ࠨࡋࡘࡕࡋࠪ㡺"),m3u_text+l1l1ll_l1_ (u"ࠫࡡࡴࠣࡆ࡚ࡗࡍࡓࡌ࠺ࠨ㡻"),re.DOTALL)
	MegaByte = 1024*1024
	splits_count = 1+len(m3u_text)//MegaByte//10
	del m3u_text
	m3u_streams_count = len(lines)
	lines2 = SPLIT_BIGLIST(lines,splits_count)
	del lines
	for ii in range(splits_count):
		PROGRESS_UPDATE(pDialog,35+int(5*ii/splits_count),l1l1ll_l1_ (u"ࠬะโุ์฼ࠤฬ๊ๅๅใࠣห้ืฦ๋ีํࠫ㡼"),l1l1ll_l1_ (u"࠭วๅฮีลࠥืโๆ࠼࠰ࠫ㡽"),str(ii+1)+l1l1ll_l1_ (u"ࠧࠡ࠱ࠣࠫ㡾")+str(splits_count))
		if pDialog.iscanceled(): return
		lines_text = str(lines2[ii])
		if kodi_version>18.99: lines_text = lines_text.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭㡿"))
		open(fullfile+l1l1ll_l1_ (u"ࠩ࠱࠴࠵࠭㢀")+str(ii),l1l1ll_l1_ (u"ࠪࡻࡧ࠭㢁")).write(lines_text)
	del lines2,lines_text
	all_ignored_streams,streams_not_sorted,jj = [],[],0
	for ii in range(splits_count):
		if pDialog.iscanceled(): return
		lines_text = open(fullfile+l1l1ll_l1_ (u"ࠫ࠳࠶࠰ࠨ㢂")+str(ii),l1l1ll_l1_ (u"ࠬࡸࡢࠨ㢃")).read()
		try: os.remove(fullfile+l1l1ll_l1_ (u"࠭࠮࠱࠲ࠪ㢄")+str(ii))
		except: pass
		if kodi_version>18.99: lines_text = lines_text.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㢅"))
		lines = EVAL(l1l1ll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㢆"),lines_text)
		del lines_text
		streams,jj,ignored_streams = READ_ALL_LINES(lines,live_epg_channels,live_archived_channels,pDialog,m3u_streams_count,jj,URL_get)
		if pDialog.iscanceled(): return
		if not streams: return
		streams_not_sorted += streams
		all_ignored_streams += ignored_streams
	del lines,streams
	grouped_streams,ignored_streams = CREATE_GROUPED_STREAMS(streams_not_sorted,pDialog,l11l1ll1_l1_)
	if pDialog.iscanceled(): return
	all_ignored_streams += ignored_streams
	del streams_not_sorted,ignored_streams
	types_count = len(UNIQUE_TYPES)
	finalstreams,all_menus,menus_counts,total_menus_count,ii = {},{},{},0,0
	for TYPE in list(grouped_streams.keys()):
		all_groups,streamsbygroup,new_streams = [],{},[]
		grouped_streams_type = grouped_streams[TYPE]
		del grouped_streams[TYPE]
		streams_type_count = len(grouped_streams_type)
		streamsbygroup[l1l1ll_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㢇")] = streams_type_count
		if streams_type_count>0:
			grouplist,contextlist,titlelist,urllist,imglist = zip(*grouped_streams_type)
			new_streams = zip(grouplist,imglist)
			del grouplist,contextlist,titlelist,urllist,imglist
			new_streams = set(new_streams)
			new_streams = list(new_streams)
			new_streams_count = len(new_streams)
			for jj in range(new_streams_count):
				if jj%173==0:
					PROGRESS_UPDATE(pDialog,60+int(15*ii//types_count),l1l1ll_l1_ (u"ࠪฮฺ์ฺ๊ࠢส่๊๊แศฬ࠽࠱ࠥอไๆๆไࠤึ่ๅࠨ㢈"),str(ii)+l1l1ll_l1_ (u"ࠫࠥ࠵ࠠࠨ㢉")+str(types_count),str(jj+1)+l1l1ll_l1_ (u"ࠬࠦ࠯ࠡࠩ㢊")+str(new_streams_count))
					if pDialog.iscanceled(): return
				all_groups.append(new_streams[jj])
				group,img = new_streams[jj]
				streamsbygroup[group] = []
			del new_streams
			all_groups = sorted(all_groups)
		streamsbygroup[l1l1ll_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㢋")] = all_groups
		del all_groups
		for group,context,title,url,img in grouped_streams_type:
			streamsbygroup[group].append((context,title,url,img))
		del grouped_streams_type
		finalstreams[TYPE] = streamsbygroup
		del streamsbygroup
		all_menus[TYPE] = list(finalstreams[TYPE].keys())
		menus_counts[TYPE] = len(all_menus[TYPE])
		total_menus_count += menus_counts[TYPE]
		ii += 1
	total_saved = 0
	DELETE_FILES(folder,l11l1ll1_l1_,False)
	for TYPE in list(finalstreams.keys()):
		CREATE_MENUS(folder,TYPE)
		if pDialog.iscanceled(): return
	ignoredCount = len(all_ignored_streams)
	ii = 0
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠧࡊࡉࡑࡓࡗࡋࡄࠨ㢌"))
	for stream in all_ignored_streams:
		PROGRESS_UPDATE(pDialog,95+int(5*ii//ignoredCount),l1l1ll_l1_ (u"ࠨฬัึ๏์ࠠศๆ่๋๊๊ษࠨ㢍"),l1l1ll_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ㢎"),str(ii)+l1l1ll_l1_ (u"ࠪࠤ࠴ࠦࠧ㢏")+str(ignoredCount))
		if pDialog.iscanceled(): return
		WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"ࠫࡎࡍࡎࡐࡔࡈࡈࡤ࠭㢐")+l11l1ll1_l1_,str(stream),l1l1ll_l1_ (u"ࠬ࠭㢑"),PERMANENT_CACHE)
		ii += 1
	WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊ࡟ࠨ㢒")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㢓"),str(ignoredCount),PERMANENT_CACHE)
	#WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"ࠨࡆࡘࡑࡒ࡟࡟ࠨ㢔")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠩࡢࡣࡉ࡛ࡍࡎ࡛ࡢࡣࠬ㢕"),l1l1ll_l1_ (u"ࠪ࠵ࠬ㢖"),PERMANENT_CACHE)
	#open(l1l1l11ll11_l1_,l1l1ll_l1_ (u"ࠫࡼ࠭㢗")).write(l1l1ll_l1_ (u"ࠬ࠭㢘"))
	pDialog.close()
	time.sleep(1)
	#countsMessage = COUNTS(folder,l11l1ll1_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ㢙"),l1l1ll_l1_ (u"ࠧࠨ㢚"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㢛"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㢜")+l1l1ll_l1_ (u"ࠪฮ๊ࠦฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭㢝")+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㢞")+l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ㢟")+countsMessage)
	#xbmc.executebuiltin(l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ㢠"))
	return
def CREATE_MENUS(folder,TYPE):
	dbfile = GET_DBFILE_NAME(folder,TYPE)
	global pDialog,total_saved,finalstreams,menus_counts,all_menus,total_menus_count
	for jj in range(1+menus_counts[TYPE]//173):
		groups_chunk = all_menus[TYPE][0:173]
		del all_menus[TYPE][0:173]
		columns_list,data_list = [],[]
		for group in groups_chunk:
			columns_list.append(group)
			data_list.append(finalstreams[TYPE][group])
		total_saved += len(data_list)
		PROGRESS_UPDATE(pDialog,75+int(20*total_saved//total_menus_count),l1l1ll_l1_ (u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠧ㢡"),l1l1ll_l1_ (u"ࠨษ็ๆฬฬๅสࠢิๆ๊ࡀ࠭ࠨ㢢"),str(total_saved)+l1l1ll_l1_ (u"ࠩࠣ࠳ࠥ࠭㢣")+str(total_menus_count))
		if pDialog.iscanceled(): return
		WRITE_TO_SQL3(dbfile,TYPE,columns_list,data_list,PERMANENT_CACHE,True)
	del finalstreams[TYPE],all_menus[TYPE],menus_counts[TYPE]
	return
def COUNTS(folder,l11l1ll1_l1_,showDialogs=True):
	#if not CHECK_TABLES_EXIST(folder,showDialogs): return
	header_message = l1l1ll_l1_ (u"ࠪ฽ิีࠠโ์า๎ํํวหࠢฯ้๏฿ࠠศๆิ์ฬฮืࠨ㢤")
	dbfile1 = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㢥"))
	dbfile2 = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㢦"))
	if l11l1ll1_l1_:
		header_message = l1l1ll_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠥืวษูࠣࠫ㢧")+text_numbers[int(l11l1ll1_l1_)]
		l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠧࡠࠩ㢨")+l11l1ll1_l1_
	ignoredCount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"ࠨ࡫ࡱࡸࠬ㢩"),l1l1ll_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ㢪")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㢫"))
	originalLIVEcount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"ࠫ࡮ࡴࡴࠨ㢬"),l1l1ll_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㢭")+l11l1ll1_l1_,l1l1ll_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㢮"))
	originalVODcount = READ_FROM_SQL3(dbfile2,l1l1ll_l1_ (u"ࠧࡪࡰࡷࠫ㢯"),l1l1ll_l1_ (u"ࠨࡘࡒࡈࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㢰")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㢱"))
	knownLIVEcount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"ࠪ࡭ࡳࡺࠧ㢲"),l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㢳")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㢴"))
	unknownLIVEcount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"࠭ࡩ࡯ࡶࠪ㢵"),l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ㢶")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㢷"))
	moviesVODcount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"ࠩ࡬ࡲࡹ࠭㢸"),l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㢹")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㢺"))
	episodesVODcount = READ_FROM_SQL3(dbfile2,l1l1ll_l1_ (u"ࠬ࡯࡮ࡵࠩ㢻"),l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫ㢼")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㢽"))
	unknownVODcount = READ_FROM_SQL3(dbfile1,l1l1ll_l1_ (u"ࠨ࡫ࡱࡸࠬ㢾"),l1l1ll_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㢿")+l11l1ll1_l1_,l1l1ll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㣀"))
	groups = READ_FROM_SQL3(dbfile2,l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㣁"),l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㣂")+l11l1ll1_l1_,l1l1ll_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㣃"))
	seriesLIST = []
	for group,img in groups:
		seriesName = group.split(l1l1ll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㣄"))[1]
		seriesLIST.append(seriesName)
	seriesVODcount = len(seriesLIST)
	total = int(moviesVODcount)+int(episodesVODcount)+int(unknownVODcount)+int(unknownLIVEcount)+int(knownLIVEcount)
	countsMessage = l1l1ll_l1_ (u"ࠨࠩ㣅")
	countsMessage += l1l1ll_l1_ (u"ࠩๅ๊ํอส࠻ࠢࠪ㣆")+str(knownLIVEcount)
	countsMessage += l1l1ll_l1_ (u"ࠪࠤࠥࠦ࠮ࠡࠢࠣวๆ๊วๆ࠼ࠣࠫ㣇")+str(moviesVODcount)
	countsMessage += l1l1ll_l1_ (u"ࠫࡡࡴๅิๆึ่ฬะ࠺ࠡࠩ㣈")+str(seriesVODcount)
	countsMessage += l1l1ll_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥำไใษอ࠾ࠥ࠭㣉")+str(episodesVODcount)
	countsMessage += l1l1ll_l1_ (u"࠭࡜࡯ไ้์ฬะࠠๆฮ๊์้ฯ࠺ࠡࠩ㣊")+str(unknownLIVEcount)
	countsMessage += l1l1ll_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠโ์า์์อสࠡ็ฯ๋ํ๊ษ࠻ࠢࠪ㣋")+str(unknownVODcount)
	countsMessage += l1l1ll_l1_ (u"ࠨ࡞ࡱ้ัฺ๋่ࠢส่็์่ศฬ࠽ࠤࠬ㣌")+str(originalLIVEcount)
	countsMessage += l1l1ll_l1_ (u"ࠩࠣࠤࠥ࠴่ࠠࠡࠢะ๊๎ูࠡษ็ๅ๏ี๊้้สฮ࠿ࠦࠧ㣍")+str(originalVODcount)
	countsMessage += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ๆฮ่์฾ࠦวๅ็ูหๆฯ࠺ࠡࠩ㣎")+str(total)
	countsMessage += l1l1ll_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤ๊าๅ้฻ࠣห้๋็ๆๆฬ࠾ࠥ࠭㣏")+str(ignoredCount)
	if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㣐"),l1l1ll_l1_ (u"࠭ࠧ㣑"),header_message,countsMessage)
	logMssage = countsMessage.replace(l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㣒"),l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ㣓"))
	if not l11l1ll1_l1_: l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠩࡄࡰࡱ࠭㣔")
	else: l11l1ll1_l1_ = l11l1ll1_l1_[1]
	LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㣕"),l1l1ll_l1_ (u"ࠫ࠳ࠦࠠࠡࡅࡲࡹࡳࡺࡳࠡࡱࡩࠤࡒ࠹ࡕࠡࡸ࡬ࡨࡪࡵࡳࠡࠢࠣࡊࡴࡲࡤࡦࡴ࠽ࠤࠬ㣖")+folder+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡕࡨࡵࡺ࡫࡮ࡤࡧ࠽ࠤࠬ㣗")+l11l1ll1_l1_+l1l1ll_l1_ (u"࠭ࠠ࡝ࡰࠪ㣘")+logMssage)
	return countsMessage
def DELETE_FILES(folder,l11l1ll1_l1_,showDialogs=True):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㣙"),l1l1ll_l1_ (u"ࠨࠩ㣚"),l1l1ll_l1_ (u"ࠩࠪ㣛"),l1l1ll_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ㣜"),l1l1ll_l1_ (u"ࠫ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠤ࠳࠴ฺࠠๆ่หࠥอๆไࠢอืฯ฽ฺ๊ࠢไ๎ࠥษ๊๊ࠡๅฮࠥอไะะ๋่ࠥหไ๊ࠢๅหห๋ษࠡโࡐ࠷่࡚ࠦอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ㣝"))
		if yes!=1: return
		file = l1l1l11l111_l1_.replace(l1l1ll_l1_ (u"ࠬࡥ࡟ࡠࠩ㣞"),l1l1ll_l1_ (u"࠭࡟ࠨ㣟")+folder+l1l1ll_l1_ (u"ࠧࡠࠩ㣠")+l11l1ll1_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l1l1l1111l1_l1_)
	#except: pass
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠨࠩ㣡"))
	if l11l1ll1_l1_:
		l1l1l11ll1l_l1_ = []
		for l1l111l1l_l1_ in UNIQUE_TYPES:
			l1l1l11ll1l_l1_.append(l1l111l1l_l1_+l1l1ll_l1_ (u"ࠩࡢࠫ㣢")+l11l1ll1_l1_)
		DELETE_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ㣣")+l11l1ll1_l1_)
	else:
		l1l1l11ll1l_l1_ = UNIQUE_TYPES
		DELETE_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㣤"))
		DELETE_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠬࡍࡒࡐࡗࡓࡗࠬ㣥"))
		DELETE_FROM_SQL3(dbfile,l1l1ll_l1_ (u"࠭ࡉࡕࡇࡐࡗࠬ㣦"))
		DELETE_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠧࡔࡇࡄࡖࡈࡎࠧ㣧"))
		DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㣨"),l1l1ll_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ㣩")+folder)
	for TYPE in l1l1l11ll1l_l1_:
		DELETE_FROM_SQL3(dbfile,TYPE)
	FIX_ALL_DATABASES(False)
	if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㣪"),l1l1ll_l1_ (u"ࠫࠬ㣫"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㣬"),l1l1ll_l1_ (u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤ๊๊แศฬࠣไࡒ࠹ࡕࠨ㣭"))
	return
def CHECK_TABLES_EXIST(folder=l1l1ll_l1_ (u"ࠧࠨ㣮"),showDialogs=True):
	if folder:
		dbfile = GET_DBFILE_NAME(str(folder),l1l1ll_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ㣯"))
		dummy = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭㣰"),l1l1ll_l1_ (u"ࠪࡈ࡚ࡓࡍ࡚ࠩ㣱"),l1l1ll_l1_ (u"ࠫࡤࡥࡄࡖࡏࡐ࡝ࡤࡥࠧ㣲"))
		if dummy: return True
	else:
		for folder in range(FOLDERS_COUNT):
			dbfile = GET_DBFILE_NAME(str(folder),l1l1ll_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ㣳"))
			dummy = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"࠭ࡳࡵࡴࠪ㣴"),l1l1ll_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭㣵"),l1l1ll_l1_ (u"ࠨࡡࡢࡈ࡚ࡓࡍ࡚ࡡࡢࠫ㣶"))
			if dummy: return True
	if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㣷"),l1l1ll_l1_ (u"ࠪࠫ㣸"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㣹"),l1l1ll_l1_ (u"ࠬอๆหࠢหัฬาษࠡว็ํࠥอไั้สฬࠥหไ๊ࠢๅหห๋ษࠡโࡐ࠷࡚ࠦหๆࠢอฺ฿฽ฺࠠๆ์ࠤࠧหึศใฬࠤึอศุࠢฦ์ࠥอิหำส็ࠥๆࡍ࠴ࡗࠥࠤ࠳࠴่ࠠา๊ࠤฬ๊ั้ษห฻ࠥออห็ส่ࠥะฬะ้สࠤๆ๐ࠠศๆศ๊ฯืๆหࠢฦ์ࠥะิหำํ๋ฬࠦๅ็ࠢืี่ฯࠠโ์า๎ํํวหࠢ࡟ࡲࡡࡴࠠฤ็สࠤสึวࠡไ่ฮࠥ็ูๅษࠣฬส฼วโหࠣห้ืวษูࠣๅสึๆࠡล้ฮࠥฮอศฮฬࠤ้าไษ่่ࠢๆอสࠡโࡐ࠷่࡚ࠦัๆๆࠤออไั้สฬࠥหไ๊ࠢๅหห๋ษࠡโࡐ࠷࡚ࠦหๆࠢอฺ฿฽ฺࠠๆ์ࠤࠧาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠨ࠮ࠨ㣺"))
	#SHOW_EMPTY(menu_name)
	return False
def SEARCH(search_org,folder=l1l1ll_l1_ (u"࠭ࠧ㣻"),TYPE=l1l1ll_l1_ (u"ࠧࠨ㣼"),PAGE=l1l1ll_l1_ (u"ࠨࠩ㣽")):
	if not PAGE: PAGE = l1l1ll_l1_ (u"ࠩ࠴ࠫ㣾")
	search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	typeList = [l1l1ll_l1_ (u"ࠪࠫ㣿"),l1l1ll_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㤀"),l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㤁"),l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㤂"),l1l1ll_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㤃"),l1l1ll_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㤄")]
	if not TYPE:
		if not showDialogs:
			if   l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡍࡋ࡙ࡉࡤ࠭㤅") in options: TYPE = typeList[1]
			elif l1l1ll_l1_ (u"ࠪࡣࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㤆") in options: TYPE = typeList[2]
			elif l1l1ll_l1_ (u"ࠫࡤࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ㤇") in options: TYPE = typeList[3]
			else: TYPE = typeList[0]
		else:
			searchTitle = [l1l1ll_l1_ (u"ࠬอไไๆࠪ㤈"),l1l1ll_l1_ (u"࠭โ็๊สฮࠬ㤉"),l1l1ll_l1_ (u"ࠧฤใ็ห๊࠭㤊"),l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠩ㤋"),l1l1ll_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠫ㤌"),l1l1ll_l1_ (u"ࠪๆ๋๎วห่ࠢะ์๎ไสࠩ㤍")]
			choice = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ㤎"), searchTitle)
			if choice==-1: return
			TYPE = typeList[choice]
	search = search+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ㤏")
	if folder: SEARCH_ONE_FOLDER(search,folder,TYPE,PAGE)
	else:
		for folder in range(FOLDERS_COUNT):
			SEARCH_ONE_FOLDER(search,str(folder),TYPE,PAGE)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(search_org,folder,TYPE=l1l1ll_l1_ (u"࠭ࠧ㤐"),PAGE=l1l1ll_l1_ (u"ࠧࠨ㤑")):
	if not PAGE: PAGE = l1l1ll_l1_ (u"ࠨ࠳ࠪ㤒")
	search,options,showDialogs = SEARCH_OPTIONS(search_org)
	if not folder: return
	if not CHECK_TABLES_EXIST(folder,showDialogs): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	typeList = [l1l1ll_l1_ (u"ࠩࠪ㤓"),l1l1ll_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㤔"),l1l1ll_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㤕"),l1l1ll_l1_ (u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㤖"),l1l1ll_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㤗"),l1l1ll_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㤘")]
	if not TYPE:
		if not showDialogs:
			if   l1l1ll_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡌࡊࡘࡈࡣࠬ㤙") in options: TYPE = typeList[1]
			elif l1l1ll_l1_ (u"ࠩࡢࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ㤚") in options: TYPE = typeList[2]
			elif l1l1ll_l1_ (u"ࠪࡣࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨ㤛") in options: TYPE = typeList[3]
			else: TYPE = typeList[0]
		else:
			searchTitle = [l1l1ll_l1_ (u"ࠫฬ๊ใๅࠩ㤜"),l1l1ll_l1_ (u"่ࠬๆ้ษอࠫ㤝"),l1l1ll_l1_ (u"࠭รโๆส้ࠬ㤞"),l1l1ll_l1_ (u"ࠧๆี็ื้อสࠨ㤟"),l1l1ll_l1_ (u"ࠨใํำ๏๎็ศฬ้ࠣัํ่ๅหࠪ㤠"),l1l1ll_l1_ (u"ࠩๅ๊ํอสࠡ็ฯ๋ํ๊ษࠨ㤡")]
			choice = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ㤢"), searchTitle)
			if choice==-1: return
			TYPE = typeList[choice]
	searchLower = search.lower()
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ㤣"))
	results = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࠪ㤤"),l1l1ll_l1_ (u"࠭ࡓࡆࡃࡕࡇࡍ࠭㤥"),(TYPE,searchLower))
	if not results:
		allgroups,alltitles = [],[]
		if not TYPE: choices = [1,2,3,4,5]
		else: choices = [typeList.index(TYPE)]
		for ii in choices:
			#dbfile = GET_DBFILE_NAME(folder,typeList[ii])
			if ii!=3:
				streams = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㤦"),typeList[ii])
				del streams[l1l1ll_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㤧")]
				del streams[l1l1ll_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭㤨")]
				del streams[l1l1ll_l1_ (u"ࠪࡣࡤ࡙ࡅࡒࡗࡈࡒࡈࡋࡄࡠࡅࡒࡐ࡚ࡓࡎࡔࡡࡢࠫ㤩")]
				groups = list(streams.keys())
				for group in groups:
					for context,title,url,img in streams[group]:
						if searchLower in title.lower(): alltitles.append((title,url,img))
					del streams[group]
				del streams
			else: groups = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ㤪"),typeList[ii],l1l1ll_l1_ (u"ࠬࡥ࡟ࡈࡔࡒ࡙ࡕ࡙࡟ࡠࠩ㤫"))
			for group in groups:
				try: group,img = group
				except: img = l1l1ll_l1_ (u"࠭ࠧ㤬")
				if searchLower in group.lower():
					if ii!=3: group2 = group
					else:
						maingroup,subgroup = group.split(l1l1ll_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㤭"))
						if searchLower in maingroup.lower(): group2 = maingroup
						else: group2 = subgroup
					allgroups.append((group,group2,typeList[ii],img))
			del groups
		allgroups = set(allgroups)
		alltitles = set(alltitles)
		allgroups = sorted(allgroups,reverse=False,key=lambda key: key[1])
		alltitles = sorted(alltitles,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"ࠨࡕࡈࡅࡗࡉࡈࠨ㤮"),(TYPE,searchLower),(allgroups,alltitles),PERMANENT_CACHE)
	else: allgroups,alltitles = results
	groups = len(allgroups)
	titles = len(alltitles)
	page = int(PAGE)
	s1 = max(0,(page-1)*100)
	e1 = max(0,page*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,group2,TYPE2,img in allgroups[s1:e1]:
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㤯"),menu_name+group2,TYPE2,714,img,l1l1ll_l1_ (u"ࠪ࠵ࠬ㤰"),group,l1l1ll_l1_ (u"ࠫࠬ㤱"),{l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㤲"):folder})
	del allgroups
	for title,url,img in alltitles[s2:e2]:
		videofile = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ㤳"))[-1]
		if l1l1ll_l1_ (u"ࠧ࠯ࠩ㤴") in videofile and l1l1ll_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㤵") not in videofile: addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㤶"),menu_name+title,url,715,img,l1l1ll_l1_ (u"ࠪࠫ㤷"),l1l1ll_l1_ (u"ࠫࠬ㤸"),l1l1ll_l1_ (u"ࠬ࠭㤹"),{l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㤺"):folder})
		else: addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㤻"),menu_name+title,url,715,img,l1l1ll_l1_ (u"ࠨࠩ㤼"),l1l1ll_l1_ (u"ࠩࠪ㤽"),l1l1ll_l1_ (u"ࠪࠫ㤾"),{l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㤿"):folder})
	del alltitles
	PAGINATION(folder,PAGE,TYPE,719,groups+titles,search+l1l1ll_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ㥀"))
	return
def PAGINATION(folder,PAGE,TYPE,mode,total,text):
	if not PAGE: PAGE = l1l1ll_l1_ (u"࠭࠱ࠨ㥁")
	if PAGE!=l1l1ll_l1_ (u"ࠧ࠲ࠩ㥂"): addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㥃"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ㥄")+str(1),TYPE,mode,l1l1ll_l1_ (u"ࠪࠫ㥅"),str(1),text,l1l1ll_l1_ (u"ࠫࠬ㥆"),{l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㥇"):folder})
	if not total: total = 0
	pages = int(total/100)+1
	for page in range(2,pages):
		cond1 = (page%10==0 or int(PAGE)-4<page<int(PAGE)+4)
		cond2 = (cond1 and int(PAGE)-40<page<int(PAGE)+40)
		if str(page)!=PAGE and (page%100==0 or cond2):
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㥈"),menu_name+l1l1ll_l1_ (u"ࠧึใะอࠥ࠭㥉")+str(page),TYPE,mode,l1l1ll_l1_ (u"ࠨࠩ㥊"),str(page),text,l1l1ll_l1_ (u"ࠩࠪ㥋"),{l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㥌"):folder})
	if str(pages)!=PAGE: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㥍"),menu_name+l1l1ll_l1_ (u"ࠬษฮาุࠢๅาฯࠠࠨ㥎")+str(pages),TYPE,mode,l1l1ll_l1_ (u"࠭ࠧ㥏"),str(pages),text,l1l1ll_l1_ (u"ࠧࠨ㥐"),{l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㥑"):folder})
	return
def GET_DBFILE_NAME(folder,TYPE):
	#if l1l1ll_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ㥒") in TYPE or l1l1ll_l1_ (u"࡚ࠪࡔࡊ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࠩ㥓") in TYPE: dbfile = iptv2_dbfile
	#else: dbfile = iptv1_dbfile
	dbfile = l1l1l111ll1_l1_.replace(l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ㥔"),l1l1ll_l1_ (u"ࠬࡥࠧ㥕")+folder)
	return dbfile
def l1l1l11l1ll_l1_(folder):
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"࠭ࠧ㥖"))
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㥗"),l1l1ll_l1_ (u"ࠨࠩ㥘"),l1l1ll_l1_ (u"ࠩࠪ㥙"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㥚"),l1l1ll_l1_ (u"ࠫ฾๋ไ๋หࠣะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠣๆิࠦสฮฬสะࠥ฿ฯสࠢาๆฬฬโࠡ࠰๋้ࠣࠦสา์าࠤศ์ࠠหฮ็ฬࠥอไๆๆไหฯࠦวๅฤ้ࠤฤ࠭㥛"))
	if yes!=1: return
	l1l1l1111ll_l1_(folder,False)
	counts = []
	for seq in range(l1l1l11l11l_l1_):
		URL = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ㥜")+folder+l1l1ll_l1_ (u"࠭࡟ࠨ㥝")+str(seq))
		if URL: CREATE_STREAMS(folder,str(seq))
		counts.append(0)
	for TYPE in UNIQUE_TYPES:
		l1l1l11111l_l1_,l1l1l111l11_l1_,l1l1l111111_l1_,l1l1l11lll1_l1_,l1l1l1l1111_l1_ = 0,{},[],[],[]
		for seq in range(l1l1l11l11l_l1_):
			TYPE2 = TYPE+l1l1ll_l1_ (u"ࠧࡠࠩ㥞")+str(seq)
			grouped_streams = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㥟"),TYPE2)
			try:
				l1l1l111l1l_l1_ = grouped_streams[l1l1ll_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭㥠")]
				count = grouped_streams[l1l1ll_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㥡")]
			except:
				l1l1l111l1l_l1_ = []
				count = l1l1ll_l1_ (u"ࠫ࠵࠭㥢")
			for tuple in l1l1l111l1l_l1_:
				group,image = tuple
				streams = grouped_streams[group]
				if group not in l1l1l11lll1_l1_:
					l1l1l11lll1_l1_.append(group)
					l1l1l1l1111_l1_.append(tuple)
					l1l1l111l11_l1_[group] = []
				l1l1l111l11_l1_[group] += streams
			DELETE_FROM_SQL3(dbfile,TYPE2)
			WRITE_TO_SQL3(dbfile,TYPE2,l1l1ll_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㥣"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l1l1l11lll1_l1_:
			streams = list(set(l1l1l111l11_l1_[group]))
			l1l1l11111l_l1_ += len(streams)
			l1l1l111111_l1_.append(streams)
		WRITE_TO_SQL3(dbfile,TYPE,l1l1ll_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㥤"),str(l1l1l11111l_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(dbfile,TYPE,l1l1ll_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ㥥"),l1l1l1l1111_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(dbfile,TYPE,l1l1l11lll1_l1_,l1l1l111111_l1_,PERMANENT_CACHE,True)
	for seq in range(l1l1l11l11l_l1_):
		if int(counts[seq])>0:
			URL = settings.getSetting(l1l1ll_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㥦")+folder+l1l1ll_l1_ (u"ࠩࡢࠫ㥧")+str(seq))
			WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ㥨")+str(seq),l1l1ll_l1_ (u"ࠫࡤࡥࡌࡊࡐࡎࡣࡤ࠭㥩"),URL,PERMANENT_CACHE)
	WRITE_TO_SQL3(dbfile,l1l1ll_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ㥪"),l1l1ll_l1_ (u"࠭࡟ࡠࡆࡘࡑࡒ࡟࡟ࡠࠩ㥫"),l1l1ll_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭㥬"),PERMANENT_CACHE)
	DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ㥭"),l1l1ll_l1_ (u"ࠩࠪ㥮"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㥯"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ㥰")+l1l1ll_l1_ (u"ࠬะๅࠡฮ็ฬ๋ࠥไโษอࠤๅࡓ࠳ࡖࠢฯำ๏ีษࠨ㥱")+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㥲"))
	l1l1l11llll_l1_(folder)
	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ㥳"))
	return
def l1l1l11llll_l1_(folder):
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠨࠩ㥴"))
	if not CHECK_TABLES_EXIST(folder,True): return
	for seq in range(l1l1l11l11l_l1_):
		URL = READ_FROM_SQL3(dbfile,l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭㥵"),l1l1ll_l1_ (u"ࠪࡐࡎࡔࡋࡠࠩ㥶")+str(seq),l1l1ll_l1_ (u"ࠫࡤࡥࡌࡊࡐࡎࡣࡤ࠭㥷"))
		if URL: countsMessage = COUNTS(folder,str(seq))
	COUNTS(folder,l1l1ll_l1_ (u"ࠬ࠭㥸"))
	return
def l1l1l1111ll_l1_(folder,showDialogs):
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㥹"),l1l1ll_l1_ (u"ࠧࠨ㥺"),l1l1ll_l1_ (u"ࠨࠩ㥻"),l1l1ll_l1_ (u"่ࠩืาࠦๅๅใสฮࠥๆࡍ࠴ࡗࠪ㥼"),l1l1ll_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็่ࠢืาࠦวๅ็็ๅฬะࠠศๆๅำ๏๋ษࠡษ็้ำุๆสࠢไ๎ࠥอไษำ้ห๊าࠠภࠣࠣ࠲࠳ูࠦๅ็สࠤฬ์ใࠡฬึฮ฼๐ูࠡใํࠤศ๐้ࠠไอࠤฬ๊ฯฯ๊็ࠤส๊้ࠡไสส๊ฯࠠแࡏ࠶࡙ࠥ๎ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭㥽"))
		if yes!=1: return
	#for seq in range(l1l1l11l11l_l1_):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l1l1ll_l1_ (u"ࠫࠬ㥾"),False)
	dbfile = GET_DBFILE_NAME(folder,l1l1ll_l1_ (u"ࠬ࠭㥿"))
	try: os.remove(dbfile)
	except: pass
	for seq in range(l1l1l11l11l_l1_):
		filename = l1l1l11l111_l1_.replace(l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪ㦀"),l1l1ll_l1_ (u"ࠧࡠࠩ㦁")+folder+l1l1ll_l1_ (u"ࠨࡡࠪ㦂")+str(seq))
		l1l1l111lll_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1l1l111lll_l1_)
		except: pass
	if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㦃"),l1l1ll_l1_ (u"ࠪࠫ㦄"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㦅"),l1l1ll_l1_ (u"ࠬะๅࠡ็ึัࠥาๅ๋฻้้ࠣ็วหࠢใࡑ࠸࡛ࠧ㦆"))
	return
COUNTRY_NAME = {
 l1l1ll_l1_ (u"࠭ࡁࡇࠩ㦇"):l1l1ll_l1_ (u"ࠧࡂࡨࡪ࡬ࡦࡴࡩࡴࡶࡤࡲࠬ㦈")
,l1l1ll_l1_ (u"ࠨࡃࡏࠫ㦉"):l1l1ll_l1_ (u"ࠩࡄࡰࡧࡧ࡮ࡪࡣࠪ㦊")
,l1l1ll_l1_ (u"ࠪࡈ࡟࠭㦋"):l1l1ll_l1_ (u"ࠫࡆࡲࡧࡦࡴ࡬ࡥࠬ㦌")
,l1l1ll_l1_ (u"ࠬࡇࡓࠨ㦍"):l1l1ll_l1_ (u"࠭ࡁ࡮ࡧࡵ࡭ࡨࡧ࡮ࠡࡕࡤࡱࡴࡧࠧ㦎")
,l1l1ll_l1_ (u"ࠧࡂࡆࠪ㦏"):l1l1ll_l1_ (u"ࠨࡃࡱࡨࡴࡸࡲࡢࠩ㦐")
,l1l1ll_l1_ (u"ࠩࡄࡓࠬ㦑"):l1l1ll_l1_ (u"ࠪࡅࡳ࡭࡯࡭ࡣࠪ㦒")
,l1l1ll_l1_ (u"ࠫࡆࡏࠧ㦓"):l1l1ll_l1_ (u"ࠬࡇ࡮ࡨࡷ࡬ࡰࡱࡧࠧ㦔")
,l1l1ll_l1_ (u"࠭ࡁࡒࠩ㦕"):l1l1ll_l1_ (u"ࠧࡂࡰࡷࡥࡷࡩࡴࡪࡥࡤࠫ㦖")
,l1l1ll_l1_ (u"ࠨࡃࡊࠫ㦗"):l1l1ll_l1_ (u"ࠩࡄࡲࡹ࡯ࡧࡶࡣࠣࡥࡳࡪࠠࡃࡣࡵࡦࡺࡪࡡࠨ㦘")
,l1l1ll_l1_ (u"ࠪࡅࡗ࠭㦙"):l1l1ll_l1_ (u"ࠫࡆࡸࡧࡦࡰࡷ࡭ࡳࡧࠧ㦚")
,l1l1ll_l1_ (u"ࠬࡇࡍࠨ㦛"):l1l1ll_l1_ (u"࠭ࡁࡳ࡯ࡨࡲ࡮ࡧࠧ㦜")
,l1l1ll_l1_ (u"ࠧࡂ࡙ࠪ㦝"):l1l1ll_l1_ (u"ࠨࡃࡵࡹࡧࡧࠧ㦞")
,l1l1ll_l1_ (u"ࠩࡄ࡙ࠬ㦟"):l1l1ll_l1_ (u"ࠪࡅࡺࡹࡴࡳࡣ࡯࡭ࡦ࠭㦠")
,l1l1ll_l1_ (u"ࠫࡆ࡚ࠧ㦡"):l1l1ll_l1_ (u"ࠬࡇࡵࡴࡶࡵ࡭ࡦ࠭㦢")
,l1l1ll_l1_ (u"࠭ࡁ࡛ࠩ㦣"):l1l1ll_l1_ (u"ࠧࡂࡼࡨࡶࡧࡧࡩ࡫ࡣࡱࠫ㦤")
,l1l1ll_l1_ (u"ࠨࡄࡖࠫ㦥"):l1l1ll_l1_ (u"ࠩࡅࡥ࡭ࡧ࡭ࡢࡵࠪ㦦")
,l1l1ll_l1_ (u"ࠪࡆࡍ࠭㦧"):l1l1ll_l1_ (u"ࠫࡇࡧࡨࡳࡣ࡬ࡲࠬ㦨")
,l1l1ll_l1_ (u"ࠬࡈࡄࠨ㦩"):l1l1ll_l1_ (u"࠭ࡂࡢࡰࡪࡰࡦࡪࡥࡴࡪࠪ㦪")
,l1l1ll_l1_ (u"ࠧࡃࡄࠪ㦫"):l1l1ll_l1_ (u"ࠨࡄࡤࡶࡧࡧࡤࡰࡵࠪ㦬")
,l1l1ll_l1_ (u"ࠩࡅ࡝ࠬ㦭"):l1l1ll_l1_ (u"ࠪࡆࡪࡲࡡࡳࡷࡶࠫ㦮")
,l1l1ll_l1_ (u"ࠫࡇࡋࠧ㦯"):l1l1ll_l1_ (u"ࠬࡈࡥ࡭ࡩ࡬ࡹࡲ࠭㦰")
,l1l1ll_l1_ (u"࠭ࡂ࡛ࠩ㦱"):l1l1ll_l1_ (u"ࠧࡃࡧ࡯࡭ࡿ࡫ࠧ㦲")
,l1l1ll_l1_ (u"ࠨࡄࡍࠫ㦳"):l1l1ll_l1_ (u"ࠩࡅࡩࡳ࡯࡮ࠨ㦴")
,l1l1ll_l1_ (u"ࠪࡆࡒ࠭㦵"):l1l1ll_l1_ (u"ࠫࡇ࡫ࡲ࡮ࡷࡧࡥࠬ㦶")
,l1l1ll_l1_ (u"ࠬࡈࡔࠨ㦷"):l1l1ll_l1_ (u"࠭ࡂࡩࡷࡷࡥࡳ࠭㦸")
,l1l1ll_l1_ (u"ࠧࡃࡑࠪ㦹"):l1l1ll_l1_ (u"ࠨࡄࡲࡰ࡮ࡼࡩࡢࠩ㦺")
,l1l1ll_l1_ (u"ࠩࡅࡕࠬ㦻"):l1l1ll_l1_ (u"ࠪࡆࡴࡴࡡࡪࡴࡨࠫ㦼")
,l1l1ll_l1_ (u"ࠫࡇࡇࠧ㦽"):l1l1ll_l1_ (u"ࠬࡈ࡯ࡴࡰ࡬ࡥࠥࡧ࡮ࡥࠢࡋࡩࡷࢀࡥࡨࡱࡹ࡭ࡳࡧࠧ㦾")
,l1l1ll_l1_ (u"࠭ࡂࡘࠩ㦿"):l1l1ll_l1_ (u"ࠧࡃࡱࡷࡷࡼࡧ࡮ࡢࠩ㧀")
,l1l1ll_l1_ (u"ࠨࡄ࡙ࠫ㧁"):l1l1ll_l1_ (u"ࠩࡅࡳࡺࡼࡥࡵࠢࡌࡷࡱࡧ࡮ࡥࠩ㧂")
,l1l1ll_l1_ (u"ࠪࡆࡗ࠭㧃"):l1l1ll_l1_ (u"ࠫࡇࡸࡡࡻ࡫࡯ࠫ㧄")
,l1l1ll_l1_ (u"ࠬࡏࡏࠨ㧅"):l1l1ll_l1_ (u"࠭ࡂࡳ࡫ࡷ࡭ࡸ࡮ࠠࡊࡰࡧ࡭ࡦࡴࠠࡐࡥࡨࡥࡳࠦࡔࡦࡴࡵ࡭ࡹࡵࡲࡺࠩ㧆")
,l1l1ll_l1_ (u"ࠧࡗࡉࠪ㧇"):l1l1ll_l1_ (u"ࠨࡄࡵ࡭ࡹ࡯ࡳࡩ࡙ࠢ࡭ࡷ࡭ࡩ࡯ࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ㧈")
,l1l1ll_l1_ (u"ࠩࡅࡒࠬ㧉"):l1l1ll_l1_ (u"ࠪࡆࡷࡻ࡮ࡦ࡫ࠪ㧊")
,l1l1ll_l1_ (u"ࠫࡇࡍࠧ㧋"):l1l1ll_l1_ (u"ࠬࡈࡵ࡭ࡩࡤࡶ࡮ࡧࠧ㧌")
,l1l1ll_l1_ (u"࠭ࡂࡇࠩ㧍"):l1l1ll_l1_ (u"ࠧࡃࡷࡵ࡯࡮ࡴࡡࠡࡈࡤࡷࡴ࠭㧎")
,l1l1ll_l1_ (u"ࠨࡄࡌࠫ㧏"):l1l1ll_l1_ (u"ࠩࡅࡹࡷࡻ࡮ࡥ࡫ࠪ㧐")
,l1l1ll_l1_ (u"ࠪࡏࡍ࠭㧑"):l1l1ll_l1_ (u"ࠫࡈࡧ࡭ࡣࡱࡧ࡭ࡦ࠭㧒")
,l1l1ll_l1_ (u"ࠬࡉࡍࠨ㧓"):l1l1ll_l1_ (u"࠭ࡃࡢ࡯ࡨࡶࡴࡵ࡮ࠨ㧔")
,l1l1ll_l1_ (u"ࠧࡄࡃࠪ㧕"):l1l1ll_l1_ (u"ࠨࡅࡤࡲࡦࡪࡡࠨ㧖")
,l1l1ll_l1_ (u"ࠩࡆ࡚ࠬ㧗"):l1l1ll_l1_ (u"ࠪࡇࡦࡶࡥࠡࡘࡨࡶࡩ࡫ࠧ㧘")
,l1l1ll_l1_ (u"ࠫࡐ࡟ࠧ㧙"):l1l1ll_l1_ (u"ࠬࡉࡡࡺ࡯ࡤࡲࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧚")
,l1l1ll_l1_ (u"࠭ࡃࡇࠩ㧛"):l1l1ll_l1_ (u"ࠧࡄࡧࡱࡸࡷࡧ࡬ࠡࡃࡩࡶ࡮ࡩࡡ࡯ࠢࡕࡩࡵࡻࡢ࡭࡫ࡦࠫ㧜")
,l1l1ll_l1_ (u"ࠨࡖࡇࠫ㧝"):l1l1ll_l1_ (u"ࠩࡆ࡬ࡦࡪࠧ㧞")
,l1l1ll_l1_ (u"ࠪࡇࡑ࠭㧟"):l1l1ll_l1_ (u"ࠫࡈ࡮ࡩ࡭ࡧࠪ㧠")
,l1l1ll_l1_ (u"ࠬࡉࡎࠨ㧡"):l1l1ll_l1_ (u"࠭ࡃࡩ࡫ࡱࡥࠬ㧢")
,l1l1ll_l1_ (u"ࠧࡄ࡚ࠪ㧣"):l1l1ll_l1_ (u"ࠨࡅ࡫ࡶ࡮ࡹࡴ࡮ࡣࡶࠤࡎࡹ࡬ࡢࡰࡧࠫ㧤")
,l1l1ll_l1_ (u"ࠩࡆࡇࠬ㧥"):l1l1ll_l1_ (u"ࠪࡇࡴࡩ࡯ࡴࠢࠫࡏࡪ࡫࡬ࡪࡰࡪ࠭ࠥࡏࡳ࡭ࡣࡱࡨࡸ࠭㧦")
,l1l1ll_l1_ (u"ࠫࡈࡕࠧ㧧"):l1l1ll_l1_ (u"ࠬࡉ࡯࡭ࡱࡰࡦ࡮ࡧࠧ㧨")
,l1l1ll_l1_ (u"࠭ࡋࡎࠩ㧩"):l1l1ll_l1_ (u"ࠧࡄࡱࡰࡳࡷࡵࡳࠨ㧪")
,l1l1ll_l1_ (u"ࠨࡅࡎࠫ㧫"):l1l1ll_l1_ (u"ࠩࡆࡳࡴࡱࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㧬")
,l1l1ll_l1_ (u"ࠪࡇࡗ࠭㧭"):l1l1ll_l1_ (u"ࠫࡈࡵࡳࡵࡣࠣࡖ࡮ࡩࡡࠨ㧮")
,l1l1ll_l1_ (u"ࠬࡎࡒࠨ㧯"):l1l1ll_l1_ (u"࠭ࡃࡳࡱࡤࡸ࡮ࡧࠧ㧰")
,l1l1ll_l1_ (u"ࠧࡄࡗࠪ㧱"):l1l1ll_l1_ (u"ࠨࡅࡸࡦࡦ࠭㧲")
,l1l1ll_l1_ (u"ࠩࡆ࡛ࠬ㧳"):l1l1ll_l1_ (u"ࠪࡇࡺࡸࡡࡤࡣࡲࠫ㧴")
,l1l1ll_l1_ (u"ࠫࡈ࡟ࠧ㧵"):l1l1ll_l1_ (u"ࠬࡉࡹࡱࡴࡸࡷࠬ㧶")
,l1l1ll_l1_ (u"࠭ࡃ࡛ࠩ㧷"):l1l1ll_l1_ (u"ࠧࡄࡼࡨࡧ࡭ࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠨ㧸")
,l1l1ll_l1_ (u"ࠨࡅࡇࠫ㧹"):l1l1ll_l1_ (u"ࠩࡇࡩࡲࡵࡣࡳࡣࡷ࡭ࡨࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠡࡱࡩࠤࡹ࡮ࡥࠡࡅࡲࡲ࡬ࡵࠧ㧺")
,l1l1ll_l1_ (u"ࠪࡈࡐ࠭㧻"):l1l1ll_l1_ (u"ࠫࡉ࡫࡮࡮ࡣࡵ࡯ࠬ㧼")
,l1l1ll_l1_ (u"ࠬࡊࡊࠨ㧽"):l1l1ll_l1_ (u"࠭ࡄ࡫࡫ࡥࡳࡺࡺࡩࠨ㧾")
,l1l1ll_l1_ (u"ࠧࡅࡏࠪ㧿"):l1l1ll_l1_ (u"ࠨࡆࡲࡱ࡮ࡴࡩࡤࡣࠪ㨀")
,l1l1ll_l1_ (u"ࠩࡇࡓࠬ㨁"):l1l1ll_l1_ (u"ࠪࡈࡴࡳࡩ࡯࡫ࡦࡥࡳࠦࡒࡦࡲࡸࡦࡱ࡯ࡣࠨ㨂")
,l1l1ll_l1_ (u"࡙ࠫࡒࠧ㨃"):l1l1ll_l1_ (u"ࠬࡋࡡࡴࡶࠣࡘ࡮ࡳ࡯ࡳࠩ㨄")
,l1l1ll_l1_ (u"࠭ࡅࡄࠩ㨅"):l1l1ll_l1_ (u"ࠧࡆࡥࡸࡥࡩࡵࡲࠨ㨆")
,l1l1ll_l1_ (u"ࠨࡇࡊࠫ㨇"):l1l1ll_l1_ (u"ࠩࡈ࡫ࡾࡶࡴࠨ㨈")
,l1l1ll_l1_ (u"ࠪࡗ࡛࠭㨉"):l1l1ll_l1_ (u"ࠫࡊࡲࠠࡔࡣ࡯ࡺࡦࡪ࡯ࡳࠩ㨊")
,l1l1ll_l1_ (u"ࠬࡍࡑࠨ㨋"):l1l1ll_l1_ (u"࠭ࡅࡲࡷࡤࡸࡴࡸࡩࡢ࡮ࠣࡋࡺ࡯࡮ࡦࡣࠪ㨌")
,l1l1ll_l1_ (u"ࠧࡆࡔࠪ㨍"):l1l1ll_l1_ (u"ࠨࡇࡵ࡭ࡹࡸࡥࡢࠩ㨎")
,l1l1ll_l1_ (u"ࠩࡈࡉࠬ㨏"):l1l1ll_l1_ (u"ࠪࡉࡸࡺ࡯࡯࡫ࡤࠫ㨐")
,l1l1ll_l1_ (u"ࠫࡊ࡚ࠧ㨑"):l1l1ll_l1_ (u"ࠬࡋࡴࡩ࡫ࡲࡴ࡮ࡧࠧ㨒")
,l1l1ll_l1_ (u"࠭ࡆࡌࠩ㨓"):l1l1ll_l1_ (u"ࠧࡇࡣ࡯࡯ࡱࡧ࡮ࡥࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ㨔")
,l1l1ll_l1_ (u"ࠨࡈࡒࠫ㨕"):l1l1ll_l1_ (u"ࠩࡉࡥࡷࡵࡥࠡࡋࡶࡰࡦࡴࡤࡴࠩ㨖")
,l1l1ll_l1_ (u"ࠪࡊࡏ࠭㨗"):l1l1ll_l1_ (u"ࠫࡋ࡯ࡪࡪࠩ㨘")
,l1l1ll_l1_ (u"ࠬࡌࡉࠨ㨙"):l1l1ll_l1_ (u"࠭ࡆࡪࡰ࡯ࡥࡳࡪࠧ㨚")
,l1l1ll_l1_ (u"ࠧࡇࡔࠪ㨛"):l1l1ll_l1_ (u"ࠨࡈࡵࡥࡳࡩࡥࠨ㨜")
,l1l1ll_l1_ (u"ࠩࡊࡊࠬ㨝"):l1l1ll_l1_ (u"ࠪࡊࡷ࡫࡮ࡤࡪࠣࡋࡺ࡯ࡡ࡯ࡣࠪ㨞")
,l1l1ll_l1_ (u"ࠫࡕࡌࠧ㨟"):l1l1ll_l1_ (u"ࠬࡌࡲࡦࡰࡦ࡬ࠥࡖ࡯࡭ࡻࡱࡩࡸ࡯ࡡࠨ㨠")
,l1l1ll_l1_ (u"࠭ࡔࡇࠩ㨡"):l1l1ll_l1_ (u"ࠧࡇࡴࡨࡲࡨ࡮ࠠࡔࡱࡸࡸ࡭࡫ࡲ࡯ࠢࡗࡩࡷࡸࡩࡵࡱࡵ࡭ࡪࡹࠧ㨢")
,l1l1ll_l1_ (u"ࠨࡉࡄࠫ㨣"):l1l1ll_l1_ (u"ࠩࡊࡥࡧࡵ࡮ࠨ㨤")
,l1l1ll_l1_ (u"ࠪࡋࡒ࠭㨥"):l1l1ll_l1_ (u"ࠫࡌࡧ࡭ࡣ࡫ࡤࠫ㨦")
,l1l1ll_l1_ (u"ࠬࡍࡅࠨ㨧"):l1l1ll_l1_ (u"࠭ࡇࡦࡱࡵ࡫࡮ࡧࠧ㨨")
,l1l1ll_l1_ (u"ࠧࡅࡇࠪ㨩"):l1l1ll_l1_ (u"ࠨࡉࡨࡶࡲࡧ࡮ࡺࠩ㨪")
,l1l1ll_l1_ (u"ࠩࡊࡌࠬ㨫"):l1l1ll_l1_ (u"ࠪࡋ࡭ࡧ࡮ࡢࠩ㨬")
,l1l1ll_l1_ (u"ࠫࡌࡏࠧ㨭"):l1l1ll_l1_ (u"ࠬࡍࡩࡣࡴࡤࡰࡹࡧࡲࠨ㨮")
,l1l1ll_l1_ (u"࠭ࡇࡓࠩ㨯"):l1l1ll_l1_ (u"ࠧࡈࡴࡨࡩࡨ࡫ࠧ㨰")
,l1l1ll_l1_ (u"ࠨࡉࡏࠫ㨱"):l1l1ll_l1_ (u"ࠩࡊࡶࡪ࡫࡮࡭ࡣࡱࡨࠬ㨲")
,l1l1ll_l1_ (u"ࠪࡋࡉ࠭㨳"):l1l1ll_l1_ (u"ࠫࡌࡸࡥ࡯ࡣࡧࡥࠬ㨴")
,l1l1ll_l1_ (u"ࠬࡍࡐࠨ㨵"):l1l1ll_l1_ (u"࠭ࡇࡶࡣࡧࡩࡱࡵࡵࡱࡧࠪ㨶")
,l1l1ll_l1_ (u"ࠧࡈࡗࠪ㨷"):l1l1ll_l1_ (u"ࠨࡉࡸࡥࡲ࠭㨸")
,l1l1ll_l1_ (u"ࠩࡊࡘࠬ㨹"):l1l1ll_l1_ (u"ࠪࡋࡺࡧࡴࡦ࡯ࡤࡰࡦ࠭㨺")
,l1l1ll_l1_ (u"ࠫࡌࡍࠧ㨻"):l1l1ll_l1_ (u"ࠬࡍࡵࡦࡴࡱࡷࡪࡿࠧ㨼")
,l1l1ll_l1_ (u"࠭ࡇࡏࠩ㨽"):l1l1ll_l1_ (u"ࠧࡈࡷ࡬ࡲࡪࡧࠧ㨾")
,l1l1ll_l1_ (u"ࠨࡉ࡚ࠫ㨿"):l1l1ll_l1_ (u"ࠩࡊࡹ࡮ࡴࡥࡢ࠯ࡅ࡭ࡸࡹࡡࡶࠩ㩀")
,l1l1ll_l1_ (u"ࠪࡋ࡞࠭㩁"):l1l1ll_l1_ (u"ࠫࡌࡻࡹࡢࡰࡤࠫ㩂")
,l1l1ll_l1_ (u"ࠬࡎࡔࠨ㩃"):l1l1ll_l1_ (u"࠭ࡈࡢ࡫ࡷ࡭ࠬ㩄")
,l1l1ll_l1_ (u"ࠧࡉࡏࠪ㩅"):l1l1ll_l1_ (u"ࠨࡊࡨࡥࡷࡪࠠࡊࡵ࡯ࡥࡳࡪࠠࡢࡰࡧࠤࡒࡩࡄࡰࡰࡤࡰࡩࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㩆")
,l1l1ll_l1_ (u"ࠩࡋࡒࠬ㩇"):l1l1ll_l1_ (u"ࠪࡌࡴࡴࡤࡶࡴࡤࡷࠬ㩈")
,l1l1ll_l1_ (u"ࠫࡍࡑࠧ㩉"):l1l1ll_l1_ (u"ࠬࡎ࡯࡯ࡩࠣࡏࡴࡴࡧࠨ㩊")
,l1l1ll_l1_ (u"࠭ࡈࡖࠩ㩋"):l1l1ll_l1_ (u"ࠧࡉࡷࡱ࡫ࡦࡸࡹࠨ㩌")
,l1l1ll_l1_ (u"ࠨࡋࡖࠫ㩍"):l1l1ll_l1_ (u"ࠩࡌࡧࡪࡲࡡ࡯ࡦࠪ㩎")
,l1l1ll_l1_ (u"ࠪࡍࡓ࠭㩏"):l1l1ll_l1_ (u"ࠫࡎࡴࡤࡪࡣࠪ㩐")
,l1l1ll_l1_ (u"ࠬࡏࡄࠨ㩑"):l1l1ll_l1_ (u"࠭ࡉ࡯ࡦࡲࡲࡪࡹࡩࡢࠩ㩒")
,l1l1ll_l1_ (u"ࠧࡊࡔࠪ㩓"):l1l1ll_l1_ (u"ࠨࡋࡵࡥࡳ࠭㩔")
,l1l1ll_l1_ (u"ࠩࡌࡕࠬ㩕"):l1l1ll_l1_ (u"ࠪࡍࡷࡧࡱࠨ㩖")
,l1l1ll_l1_ (u"ࠫࡎࡋࠧ㩗"):l1l1ll_l1_ (u"ࠬࡏࡲࡦ࡮ࡤࡲࡩ࠭㩘")
,l1l1ll_l1_ (u"࠭ࡉࡎࠩ㩙"):l1l1ll_l1_ (u"ࠧࡊࡵ࡯ࡩࠥࡵࡦࠡࡏࡤࡲࠬ㩚")
,l1l1ll_l1_ (u"ࠨࡋࡏࠫ㩛"):l1l1ll_l1_ (u"ࠩࡌࡷࡷࡧࡥ࡭ࠩ㩜")
,l1l1ll_l1_ (u"ࠪࡍ࡙࠭㩝"):l1l1ll_l1_ (u"ࠫࡎࡺࡡ࡭ࡻࠪ㩞")
,l1l1ll_l1_ (u"ࠬࡉࡉࠨ㩟"):l1l1ll_l1_ (u"࠭ࡉࡷࡱࡵࡽࠥࡉ࡯ࡢࡵࡷࠫ㩠")
,l1l1ll_l1_ (u"ࠧࡋࡏࠪ㩡"):l1l1ll_l1_ (u"ࠨࡌࡤࡱࡦ࡯ࡣࡢࠩ㩢")
,l1l1ll_l1_ (u"ࠩࡍࡔࠬ㩣"):l1l1ll_l1_ (u"ࠪࡎࡦࡶࡡ࡯ࠩ㩤")
,l1l1ll_l1_ (u"ࠫࡏࡋࠧ㩥"):l1l1ll_l1_ (u"ࠬࡐࡥࡳࡵࡨࡽࠬ㩦")
,l1l1ll_l1_ (u"࠭ࡊࡐࠩ㩧"):l1l1ll_l1_ (u"ࠧࡋࡱࡵࡨࡦࡴࠧ㩨")
,l1l1ll_l1_ (u"ࠨࡍ࡝ࠫ㩩"):l1l1ll_l1_ (u"ࠩࡎࡥࡿࡧ࡫ࡩࡵࡷࡥࡳ࠭㩪")
,l1l1ll_l1_ (u"ࠪࡏࡊ࠭㩫"):l1l1ll_l1_ (u"ࠫࡐ࡫࡮ࡺࡣࠪ㩬")
,l1l1ll_l1_ (u"ࠬࡑࡉࠨ㩭"):l1l1ll_l1_ (u"࠭ࡋࡪࡴ࡬ࡦࡦࡺࡩࠨ㩮")
,l1l1ll_l1_ (u"࡙ࠧࡍࠪ㩯"):l1l1ll_l1_ (u"ࠨࡍࡲࡷࡴࡼ࡯ࠨ㩰")
,l1l1ll_l1_ (u"ࠩࡎ࡛ࠬ㩱"):l1l1ll_l1_ (u"ࠪࡏࡺࡽࡡࡪࡶࠪ㩲")
,l1l1ll_l1_ (u"ࠫࡐࡍࠧ㩳"):l1l1ll_l1_ (u"ࠬࡑࡹࡳࡩࡼࡾࡸࡺࡡ࡯ࠩ㩴")
,l1l1ll_l1_ (u"࠭ࡌࡂࠩ㩵"):l1l1ll_l1_ (u"ࠧࡍࡣࡲࡷࠬ㩶")
,l1l1ll_l1_ (u"ࠨࡎ࡙ࠫ㩷"):l1l1ll_l1_ (u"ࠩࡏࡥࡹࡼࡩࡢࠩ㩸")
,l1l1ll_l1_ (u"ࠪࡐࡇ࠭㩹"):l1l1ll_l1_ (u"ࠫࡑ࡫ࡢࡢࡰࡲࡲࠬ㩺")
,l1l1ll_l1_ (u"ࠬࡒࡓࠨ㩻"):l1l1ll_l1_ (u"࠭ࡌࡦࡵࡲࡸ࡭ࡵࠧ㩼")
,l1l1ll_l1_ (u"ࠧࡍࡔࠪ㩽"):l1l1ll_l1_ (u"ࠨࡎ࡬ࡦࡪࡸࡩࡢࠩ㩾")
,l1l1ll_l1_ (u"ࠩࡏ࡝ࠬ㩿"):l1l1ll_l1_ (u"ࠪࡐ࡮ࡨࡹࡢࠩ㪀")
,l1l1ll_l1_ (u"ࠫࡑࡏࠧ㪁"):l1l1ll_l1_ (u"ࠬࡒࡩࡦࡥ࡫ࡸࡪࡴࡳࡵࡧ࡬ࡲࠬ㪂")
,l1l1ll_l1_ (u"࠭ࡌࡕࠩ㪃"):l1l1ll_l1_ (u"ࠧࡍ࡫ࡷ࡬ࡺࡧ࡮ࡪࡣࠪ㪄")
,l1l1ll_l1_ (u"ࠨࡎࡘࠫ㪅"):l1l1ll_l1_ (u"ࠩࡏࡹࡽ࡫࡭ࡣࡱࡸࡶ࡬࠭㪆")
,l1l1ll_l1_ (u"ࠪࡑࡔ࠭㪇"):l1l1ll_l1_ (u"ࠫࡒࡧࡣࡢࡱࠪ㪈")
,l1l1ll_l1_ (u"ࠬࡓࡇࠨ㪉"):l1l1ll_l1_ (u"࠭ࡍࡢࡦࡤ࡫ࡦࡹࡣࡢࡴࠪ㪊")
,l1l1ll_l1_ (u"ࠧࡎ࡙ࠪ㪋"):l1l1ll_l1_ (u"ࠨࡏࡤࡰࡦࡽࡩࠨ㪌")
,l1l1ll_l1_ (u"ࠩࡐ࡝ࠬ㪍"):l1l1ll_l1_ (u"ࠪࡑࡦࡲࡡࡺࡵ࡬ࡥࠬ㪎")
,l1l1ll_l1_ (u"ࠫࡒ࡜ࠧ㪏"):l1l1ll_l1_ (u"ࠬࡓࡡ࡭ࡦ࡬ࡺࡪࡹࠧ㪐")
,l1l1ll_l1_ (u"࠭ࡍࡍࠩ㪑"):l1l1ll_l1_ (u"ࠧࡎࡣ࡯࡭ࠬ㪒")
,l1l1ll_l1_ (u"ࠨࡏࡗࠫ㪓"):l1l1ll_l1_ (u"ࠩࡐࡥࡱࡺࡡࠨ㪔")
,l1l1ll_l1_ (u"ࠪࡑࡍ࠭㪕"):l1l1ll_l1_ (u"ࠫࡒࡧࡲࡴࡪࡤࡰࡱࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㪖")
,l1l1ll_l1_ (u"ࠬࡓࡑࠨ㪗"):l1l1ll_l1_ (u"࠭ࡍࡢࡴࡷ࡭ࡳ࡯ࡱࡶࡧࠪ㪘")
,l1l1ll_l1_ (u"ࠧࡎࡔࠪ㪙"):l1l1ll_l1_ (u"ࠨࡏࡤࡹࡷ࡯ࡴࡢࡰ࡬ࡥࠬ㪚")
,l1l1ll_l1_ (u"ࠩࡐ࡙ࠬ㪛"):l1l1ll_l1_ (u"ࠪࡑࡦࡻࡲࡪࡶ࡬ࡹࡸ࠭㪜")
,l1l1ll_l1_ (u"ࠫ࡞࡚ࠧ㪝"):l1l1ll_l1_ (u"ࠬࡓࡡࡺࡱࡷࡸࡪ࠭㪞")
,l1l1ll_l1_ (u"࠭ࡍ࡙ࠩ㪟"):l1l1ll_l1_ (u"ࠧࡎࡧࡻ࡭ࡨࡵࠧ㪠")
,l1l1ll_l1_ (u"ࠨࡈࡐࠫ㪡"):l1l1ll_l1_ (u"ࠩࡐ࡭ࡨࡸ࡯࡯ࡧࡶ࡭ࡦ࠭㪢")
,l1l1ll_l1_ (u"ࠪࡑࡉ࠭㪣"):l1l1ll_l1_ (u"ࠫࡒࡵ࡬ࡥࡱࡹࡥࠬ㪤")
,l1l1ll_l1_ (u"ࠬࡓࡃࠨ㪥"):l1l1ll_l1_ (u"࠭ࡍࡰࡰࡤࡧࡴ࠭㪦")
,l1l1ll_l1_ (u"ࠧࡎࡐࠪ㪧"):l1l1ll_l1_ (u"ࠨࡏࡲࡲ࡬ࡵ࡬ࡪࡣࠪ㪨")
,l1l1ll_l1_ (u"ࠩࡐࡉࠬ㪩"):l1l1ll_l1_ (u"ࠪࡑࡴࡴࡴࡦࡰࡨ࡫ࡷࡵࠧ㪪")
,l1l1ll_l1_ (u"ࠫࡒ࡙ࠧ㪫"):l1l1ll_l1_ (u"ࠬࡓ࡯࡯ࡶࡶࡩࡷࡸࡡࡵࠩ㪬")
,l1l1ll_l1_ (u"࠭ࡍࡂࠩ㪭"):l1l1ll_l1_ (u"ࠧࡎࡱࡵࡳࡨࡩ࡯ࠨ㪮")
,l1l1ll_l1_ (u"ࠨࡏ࡝ࠫ㪯"):l1l1ll_l1_ (u"ࠩࡐࡳࡿࡧ࡭ࡣ࡫ࡴࡹࡪ࠭㪰")
,l1l1ll_l1_ (u"ࠪࡑࡒ࠭㪱"):l1l1ll_l1_ (u"ࠫࡒࡿࡡ࡯࡯ࡤࡶࠥ࠮ࡂࡶࡴࡰࡥ࠮࠭㪲")
,l1l1ll_l1_ (u"ࠬࡔࡁࠨ㪳"):l1l1ll_l1_ (u"࠭ࡎࡢ࡯࡬ࡦ࡮ࡧࠧ㪴")
,l1l1ll_l1_ (u"ࠧࡏࡔࠪ㪵"):l1l1ll_l1_ (u"ࠨࡐࡤࡹࡷࡻࠧ㪶")
,l1l1ll_l1_ (u"ࠩࡑࡔࠬ㪷"):l1l1ll_l1_ (u"ࠪࡒࡪࡶࡡ࡭ࠩ㪸")
,l1l1ll_l1_ (u"ࠫࡓࡒࠧ㪹"):l1l1ll_l1_ (u"ࠬࡔࡥࡵࡪࡨࡶࡱࡧ࡮ࡥࡵࠪ㪺")
,l1l1ll_l1_ (u"࠭ࡎࡄࠩ㪻"):l1l1ll_l1_ (u"ࠧࡏࡧࡺࠤࡈࡧ࡬ࡦࡦࡲࡲ࡮ࡧࠧ㪼")
,l1l1ll_l1_ (u"ࠨࡐ࡝ࠫ㪽"):l1l1ll_l1_ (u"ࠩࡑࡩࡼ࡚ࠦࡦࡣ࡯ࡥࡳࡪࠧ㪾")
,l1l1ll_l1_ (u"ࠪࡒࡎ࠭㪿"):l1l1ll_l1_ (u"ࠫࡓ࡯ࡣࡢࡴࡤ࡫ࡺࡧࠧ㫀")
,l1l1ll_l1_ (u"ࠬࡔࡅࠨ㫁"):l1l1ll_l1_ (u"࠭ࡎࡪࡩࡨࡶࠬ㫂")
,l1l1ll_l1_ (u"ࠧࡏࡉࠪ㫃"):l1l1ll_l1_ (u"ࠨࡐ࡬࡫ࡪࡸࡩࡢࠩ㫄")
,l1l1ll_l1_ (u"ࠩࡑ࡙ࠬ㫅"):l1l1ll_l1_ (u"ࠪࡒ࡮ࡻࡥࠨ㫆")
,l1l1ll_l1_ (u"ࠫࡓࡌࠧ㫇"):l1l1ll_l1_ (u"ࠬࡔ࡯ࡳࡨࡲࡰࡰࠦࡉࡴ࡮ࡤࡲࡩ࠭㫈")
,l1l1ll_l1_ (u"࠭ࡋࡑࠩ㫉"):l1l1ll_l1_ (u"ࠧࡏࡱࡵࡸ࡭ࠦࡋࡰࡴࡨࡥࠬ㫊")
,l1l1ll_l1_ (u"ࠨࡏࡎࠫ㫋"):l1l1ll_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ㫌")
,l1l1ll_l1_ (u"ࠪࡑࡕ࠭㫍"):l1l1ll_l1_ (u"ࠫࡓࡵࡲࡵࡪࡨࡶࡳࠦࡍࡢࡴ࡬ࡥࡳࡧࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㫎")
,l1l1ll_l1_ (u"ࠬࡔࡏࠨ㫏"):l1l1ll_l1_ (u"࠭ࡎࡰࡴࡺࡥࡾ࠭㫐")
,l1l1ll_l1_ (u"ࠧࡐࡏࠪ㫑"):l1l1ll_l1_ (u"ࠨࡑࡰࡥࡳ࠭㫒")
,l1l1ll_l1_ (u"ࠩࡓࡏࠬ㫓"):l1l1ll_l1_ (u"ࠪࡔࡦࡱࡩࡴࡶࡤࡲࠬ㫔")
,l1l1ll_l1_ (u"ࠫࡕ࡝ࠧ㫕"):l1l1ll_l1_ (u"ࠬࡖࡡ࡭ࡣࡸࠫ㫖")
,l1l1ll_l1_ (u"࠭ࡐࡔࠩ㫗"):l1l1ll_l1_ (u"ࠧࡑࡣ࡯ࡩࡸࡺࡩ࡯ࡧࠪ㫘")
,l1l1ll_l1_ (u"ࠨࡒࡄࠫ㫙"):l1l1ll_l1_ (u"ࠩࡓࡥࡳࡧ࡭ࡢࠩ㫚")
,l1l1ll_l1_ (u"ࠪࡔࡌ࠭㫛"):l1l1ll_l1_ (u"ࠫࡕࡧࡰࡶࡣࠣࡒࡪࡽࠠࡈࡷ࡬ࡲࡪࡧࠧ㫜")
,l1l1ll_l1_ (u"ࠬࡖ࡙ࠨ㫝"):l1l1ll_l1_ (u"࠭ࡐࡢࡴࡤ࡫ࡺࡧࡹࠨ㫞")
,l1l1ll_l1_ (u"ࠧࡑࡇࠪ㫟"):l1l1ll_l1_ (u"ࠨࡒࡨࡶࡺ࠭㫠")
,l1l1ll_l1_ (u"ࠩࡓࡌࠬ㫡"):l1l1ll_l1_ (u"ࠪࡔ࡭࡯࡬ࡪࡲࡳ࡭ࡳ࡫ࡳࠨ㫢")
,l1l1ll_l1_ (u"ࠫࡕࡔࠧ㫣"):l1l1ll_l1_ (u"ࠬࡖࡩࡵࡥࡤ࡭ࡷࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㫤")
,l1l1ll_l1_ (u"࠭ࡐࡍࠩ㫥"):l1l1ll_l1_ (u"ࠧࡑࡱ࡯ࡥࡳࡪࠧ㫦")
,l1l1ll_l1_ (u"ࠨࡒࡗࠫ㫧"):l1l1ll_l1_ (u"ࠩࡓࡳࡷࡺࡵࡨࡣ࡯ࠫ㫨")
,l1l1ll_l1_ (u"ࠪࡔࡗ࠭㫩"):l1l1ll_l1_ (u"ࠫࡕࡻࡥࡳࡶࡲࠤࡗ࡯ࡣࡰࠩ㫪")
,l1l1ll_l1_ (u"ࠬࡗࡁࠨ㫫"):l1l1ll_l1_ (u"࠭ࡑࡢࡶࡤࡶࠬ㫬")
,l1l1ll_l1_ (u"ࠧࡄࡉࠪ㫭"):l1l1ll_l1_ (u"ࠨࡔࡨࡴࡺࡨ࡬ࡪࡥࠣࡳ࡫ࠦࡴࡩࡧࠣࡇࡴࡴࡧࡰࠩ㫮")
,l1l1ll_l1_ (u"ࠩࡕࡓࠬ㫯"):l1l1ll_l1_ (u"ࠪࡖࡴࡳࡡ࡯࡫ࡤࠫ㫰")
,l1l1ll_l1_ (u"ࠫࡗ࡛ࠧ㫱"):l1l1ll_l1_ (u"ࠬࡘࡵࡴࡵ࡬ࡥࠬ㫲")
,l1l1ll_l1_ (u"࠭ࡒࡘࠩ㫳"):l1l1ll_l1_ (u"ࠧࡓࡹࡤࡲࡩࡧࠧ㫴")
,l1l1ll_l1_ (u"ࠨࡔࡈࠫ㫵"):l1l1ll_l1_ (u"ࠩࡕ࣭ࡺࡴࡩࡰࡰࠪ㫶")
,l1l1ll_l1_ (u"ࠪࡆࡑ࠭㫷"):l1l1ll_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡆࡦࡸࡴࡩ࣫࡯ࡩࡲࡿࠧ㫸")
,l1l1ll_l1_ (u"࡙ࠬࡈࠨ㫹"):l1l1ll_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡎࡥ࡭ࡧࡱࡥࠬ㫺")
,l1l1ll_l1_ (u"ࠧࡌࡐࠪ㫻"):l1l1ll_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡌ࡫ࡷࡸࡸࠦࡡ࡯ࡦࠣࡒࡪࡼࡩࡴࠩ㫼")
,l1l1ll_l1_ (u"ࠩࡏࡇࠬ㫽"):l1l1ll_l1_ (u"ࠪࡗࡦ࡯࡮ࡵࠢࡏࡹࡨ࡯ࡡࠨ㫾")
,l1l1ll_l1_ (u"ࠫࡒࡌࠧ㫿"):l1l1ll_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡒࡧࡲࡵ࡫ࡱࠫ㬀")
,l1l1ll_l1_ (u"࠭ࡐࡎࠩ㬁"):l1l1ll_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡐࡪࡧࡵࡶࡪࠦࡡ࡯ࡦࠣࡑ࡮ࡷࡵࡦ࡮ࡲࡲࠬ㬂")
,l1l1ll_l1_ (u"ࠨࡘࡆࠫ㬃"):l1l1ll_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡘ࡬ࡲࡨ࡫࡮ࡵࠢࡤࡲࡩࠦࡴࡩࡧࠣࡋࡷ࡫࡮ࡢࡦ࡬ࡲࡪࡹࠧ㬄")
,l1l1ll_l1_ (u"࡛ࠪࡘ࠭㬅"):l1l1ll_l1_ (u"ࠫࡘࡧ࡭ࡰࡣࠪ㬆")
,l1l1ll_l1_ (u"࡙ࠬࡍࠨ㬇"):l1l1ll_l1_ (u"࠭ࡓࡢࡰࠣࡑࡦࡸࡩ࡯ࡱࠪ㬈")
,l1l1ll_l1_ (u"ࠧࡔࡃࠪ㬉"):l1l1ll_l1_ (u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧ㬊")
,l1l1ll_l1_ (u"ࠩࡖࡒࠬ㬋"):l1l1ll_l1_ (u"ࠪࡗࡪࡴࡥࡨࡣ࡯ࠫ㬌")
,l1l1ll_l1_ (u"ࠫࡗ࡙ࠧ㬍"):l1l1ll_l1_ (u"࡙ࠬࡥࡳࡤ࡬ࡥࠬ㬎")
,l1l1ll_l1_ (u"࠭ࡓࡄࠩ㬏"):l1l1ll_l1_ (u"ࠧࡔࡧࡼࡧ࡭࡫࡬࡭ࡧࡶࠫ㬐")
,l1l1ll_l1_ (u"ࠨࡕࡏࠫ㬑"):l1l1ll_l1_ (u"ࠩࡖ࡭ࡪࡸࡲࡢࠢࡏࡩࡴࡴࡥࠨ㬒")
,l1l1ll_l1_ (u"ࠪࡗࡌ࠭㬓"):l1l1ll_l1_ (u"ࠫࡘ࡯࡮ࡨࡣࡳࡳࡷ࡫ࠧ㬔")
,l1l1ll_l1_ (u"࡙ࠬࡘࠨ㬕"):l1l1ll_l1_ (u"࠭ࡓࡪࡰࡷࠤࡒࡧࡡࡳࡶࡨࡲࠬ㬖")
,l1l1ll_l1_ (u"ࠧࡔࡍࠪ㬗"):l1l1ll_l1_ (u"ࠨࡕ࡯ࡳࡻࡧ࡫ࡪࡣࠪ㬘")
,l1l1ll_l1_ (u"ࠩࡖࡍࠬ㬙"):l1l1ll_l1_ (u"ࠪࡗࡱࡵࡶࡦࡰ࡬ࡥࠬ㬚")
,l1l1ll_l1_ (u"ࠫࡘࡈࠧ㬛"):l1l1ll_l1_ (u"࡙ࠬ࡯࡭ࡱࡰࡳࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㬜")
,l1l1ll_l1_ (u"࠭ࡓࡐࠩ㬝"):l1l1ll_l1_ (u"ࠧࡔࡱࡰࡥࡱ࡯ࡡࠨ㬞")
,l1l1ll_l1_ (u"ࠨ࡜ࡄࠫ㬟"):l1l1ll_l1_ (u"ࠩࡖࡳࡺࡺࡨࠡࡃࡩࡶ࡮ࡩࡡࠨ㬠")
,l1l1ll_l1_ (u"ࠪࡋࡘ࠭㬡"):l1l1ll_l1_ (u"ࠫࡘࡵࡵࡵࡪࠣࡋࡪࡵࡲࡨ࡫ࡤࠤࡦࡴࡤࠡࡶ࡫ࡩ࡙ࠥ࡯ࡶࡶ࡫ࠤࡘࡧ࡮ࡥࡹ࡬ࡧ࡭ࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㬢")
,l1l1ll_l1_ (u"ࠬࡑࡒࠨ㬣"):l1l1ll_l1_ (u"࠭ࡓࡰࡷࡷ࡬ࠥࡑ࡯ࡳࡧࡤࠫ㬤")
,l1l1ll_l1_ (u"ࠧࡔࡕࠪ㬥"):l1l1ll_l1_ (u"ࠨࡕࡲࡹࡹ࡮ࠠࡔࡷࡧࡥࡳ࠭㬦")
,l1l1ll_l1_ (u"ࠩࡈࡗࠬ㬧"):l1l1ll_l1_ (u"ࠪࡗࡵࡧࡩ࡯ࠩ㬨")
,l1l1ll_l1_ (u"ࠫࡑࡑࠧ㬩"):l1l1ll_l1_ (u"࡙ࠬࡲࡪࠢࡏࡥࡳࡱࡡࠨ㬪")
,l1l1ll_l1_ (u"࠭ࡓࡅࠩ㬫"):l1l1ll_l1_ (u"ࠧࡔࡷࡧࡥࡳ࠭㬬")
,l1l1ll_l1_ (u"ࠨࡕࡕࠫ㬭"):l1l1ll_l1_ (u"ࠩࡖࡹࡷ࡯࡮ࡢ࡯ࡨࠫ㬮")
,l1l1ll_l1_ (u"ࠪࡗࡏ࠭㬯"):l1l1ll_l1_ (u"ࠫࡘࡼࡡ࡭ࡤࡤࡶࡩࠦࡡ࡯ࡦࠣࡎࡦࡴࠠࡎࡣࡼࡩࡳ࠭㬰")
,l1l1ll_l1_ (u"࡙࡚ࠬࠨ㬱"):l1l1ll_l1_ (u"࠭ࡓࡸࡣࡽ࡭ࡱࡧ࡮ࡥࠩ㬲")
,l1l1ll_l1_ (u"ࠧࡔࡇࠪ㬳"):l1l1ll_l1_ (u"ࠨࡕࡺࡩࡩ࡫࡮ࠨ㬴")
,l1l1ll_l1_ (u"ࠩࡆࡌࠬ㬵"):l1l1ll_l1_ (u"ࠪࡗࡼ࡯ࡴࡻࡧࡵࡰࡦࡴࡤࠨ㬶")
,l1l1ll_l1_ (u"ࠫࡘ࡟ࠧ㬷"):l1l1ll_l1_ (u"࡙ࠬࡹࡳ࡫ࡤࠫ㬸")
,l1l1ll_l1_ (u"࠭ࡓࡕࠩ㬹"):l1l1ll_l1_ (u"ࠧࡔࣥࡲࠤ࡙ࡵ࡭࣪ࠢࡤࡲࡩࠦࡐࡳ࣯ࡱࡧ࡮ࡶࡥࠨ㬺")
,l1l1ll_l1_ (u"ࠨࡖ࡚ࠫ㬻"):l1l1ll_l1_ (u"ࠩࡗࡥ࡮ࡽࡡ࡯ࠩ㬼")
,l1l1ll_l1_ (u"ࠪࡘࡏ࠭㬽"):l1l1ll_l1_ (u"࡙ࠫࡧࡪࡪ࡭࡬ࡷࡹࡧ࡮ࠨ㬾")
,l1l1ll_l1_ (u"࡚࡚ࠬࠨ㬿"):l1l1ll_l1_ (u"࠭ࡔࡢࡰࡽࡥࡳ࡯ࡡࠨ㭀")
,l1l1ll_l1_ (u"ࠧࡕࡊࠪ㭁"):l1l1ll_l1_ (u"ࠨࡖ࡫ࡥ࡮ࡲࡡ࡯ࡦࠪ㭂")
,l1l1ll_l1_ (u"ࠩࡗࡋࠬ㭃"):l1l1ll_l1_ (u"ࠪࡘࡴ࡭࡯ࠨ㭄")
,l1l1ll_l1_ (u"࡙ࠫࡑࠧ㭅"):l1l1ll_l1_ (u"࡚ࠬ࡯࡬ࡧ࡯ࡥࡺ࠭㭆")
,l1l1ll_l1_ (u"࠭ࡔࡐࠩ㭇"):l1l1ll_l1_ (u"ࠧࡕࡱࡱ࡫ࡦ࠭㭈")
,l1l1ll_l1_ (u"ࠨࡖࡗࠫ㭉"):l1l1ll_l1_ (u"ࠩࡗࡶ࡮ࡴࡩࡥࡣࡧࠤࡦࡴࡤࠡࡖࡲࡦࡦ࡭࡯ࠨ㭊")
,l1l1ll_l1_ (u"ࠪࡘࡓ࠭㭋"):l1l1ll_l1_ (u"࡙ࠫࡻ࡮ࡪࡵ࡬ࡥࠬ㭌")
,l1l1ll_l1_ (u"࡚ࠬࡒࠨ㭍"):l1l1ll_l1_ (u"࠭ࡔࡶࡴ࡮ࡩࡾ࠭㭎")
,l1l1ll_l1_ (u"ࠧࡕࡏࠪ㭏"):l1l1ll_l1_ (u"ࠨࡖࡸࡶࡰࡳࡥ࡯࡫ࡶࡸࡦࡴࠧ㭐")
,l1l1ll_l1_ (u"ࠩࡗࡇࠬ㭑"):l1l1ll_l1_ (u"ࠪࡘࡺࡸ࡫ࡴࠢࡤࡲࡩࠦࡃࡢ࡫ࡦࡳࡸࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㭒")
,l1l1ll_l1_ (u"࡙ࠫ࡜ࠧ㭓"):l1l1ll_l1_ (u"࡚ࠬࡵࡷࡣ࡯ࡹࠬ㭔")
,l1l1ll_l1_ (u"࠭ࡕࡎࠩ㭕"):l1l1ll_l1_ (u"ࠧࡖ࠰ࡖ࠲ࠥࡓࡩ࡯ࡱࡵࠤࡔࡻࡴ࡭ࡻ࡬ࡲ࡬ࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㭖")
,l1l1ll_l1_ (u"ࠨࡘࡌࠫ㭗"):l1l1ll_l1_ (u"ࠩࡘ࠲ࡘ࠴ࠠࡗ࡫ࡵ࡫࡮ࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㭘")
,l1l1ll_l1_ (u"࡙ࠪࡌ࠭㭙"):l1l1ll_l1_ (u"࡚ࠫ࡭ࡡ࡯ࡦࡤࠫ㭚")
,l1l1ll_l1_ (u"࡛ࠬࡁࠨ㭛"):l1l1ll_l1_ (u"࠭ࡕ࡬ࡴࡤ࡭ࡳ࡫ࠧ㭜")
,l1l1ll_l1_ (u"ࠧࡂࡇࠪ㭝"):l1l1ll_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨ㭞")
,l1l1ll_l1_ (u"ࠩࡘࡏࠬ㭟"):l1l1ll_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ㭠")
,l1l1ll_l1_ (u"࡚࡙ࠫࠧ㭡"):l1l1ll_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬ㭢")
,l1l1ll_l1_ (u"࠭ࡕ࡚ࠩ㭣"):l1l1ll_l1_ (u"ࠧࡖࡴࡸ࡫ࡺࡧࡹࠨ㭤")
,l1l1ll_l1_ (u"ࠨࡗ࡝ࠫ㭥"):l1l1ll_l1_ (u"ࠩࡘࡾࡧ࡫࡫ࡪࡵࡷࡥࡳ࠭㭦")
,l1l1ll_l1_ (u"࡚࡚ࠪ࠭㭧"):l1l1ll_l1_ (u"࡛ࠫࡧ࡮ࡶࡣࡷࡹࠬ㭨")
,l1l1ll_l1_ (u"ࠬ࡜ࡁࠨ㭩"):l1l1ll_l1_ (u"࠭ࡖࡢࡶ࡬ࡧࡦࡴࠠࡄ࡫ࡷࡽࠬ㭪")
,l1l1ll_l1_ (u"ࠧࡗࡇࠪ㭫"):l1l1ll_l1_ (u"ࠨࡘࡨࡲࡪࢀࡵࡦ࡮ࡤࠫ㭬")
,l1l1ll_l1_ (u"࡙ࠩࡒࠬ㭭"):l1l1ll_l1_ (u"࡚ࠪ࡮࡫ࡴ࡯ࡣࡰࠫ㭮")
,l1l1ll_l1_ (u"ࠫ࡜ࡌࠧ㭯"):l1l1ll_l1_ (u"ࠬ࡝ࡡ࡭࡮࡬ࡷࠥࡧ࡮ࡥࠢࡉࡹࡹࡻ࡮ࡢࠩ㭰")
,l1l1ll_l1_ (u"࠭ࡅࡉࠩ㭱"):l1l1ll_l1_ (u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨ㭲")
,l1l1ll_l1_ (u"ࠨ࡛ࡈࠫ㭳"):l1l1ll_l1_ (u"ࠩ࡜ࡩࡲ࡫࡮ࠨ㭴")
,l1l1ll_l1_ (u"ࠪ࡞ࡒ࠭㭵"):l1l1ll_l1_ (u"ࠫ࡟ࡧ࡭ࡣ࡫ࡤࠫ㭶")
,l1l1ll_l1_ (u"ࠬࡠࡗࠨ㭷"):l1l1ll_l1_ (u"࡚࠭ࡪ࡯ࡥࡥࡧࡽࡥࠨ㭸")
,l1l1ll_l1_ (u"ࠧࡂ࡚ࠪ㭹"):l1l1ll_l1_ (u"ࠨࣇ࡯ࡥࡳࡪࠧ㭺")
}
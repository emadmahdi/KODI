# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭ᝂ")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡁࡃࡆࡢࠫᝃ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨᝄ")]
def MAIN(mode,url,text):
	if   mode==550: results = MENU()
	elif mode==551: results = l11l1l_l1_(url,text)
	elif mode==552: results = PLAY(url)
	elif mode==553: results = l11ll1l_l1_(url)
	elif mode==559: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᝅ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱࡫ࡳࡲ࡫ࠧᝆ"),l1l1ll_l1_ (u"ࠩࠪᝇ"),l1l1ll_l1_ (u"ࠪࠫᝈ"),l1l1ll_l1_ (u"ࠫࠬᝉ"),l1l1ll_l1_ (u"ࠬ࠭ᝊ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᝋ"))
	html = response.content
	l11ll1_l1_ = SERVER(l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫᝌ"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᝍ"),menu_name+l1l1ll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᝎ"),l1l1ll_l1_ (u"ࠪࠫᝏ"),559,l1l1ll_l1_ (u"ࠫࠬᝐ"),l1l1ll_l1_ (u"ࠬ࠭ᝑ"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᝒ"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᝓ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᝔"),l1l1ll_l1_ (u"ࠩࠪ᝕"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᝖"),menu_name+l1l1ll_l1_ (u"ࠫฬิสา่สࠤ้้ࠧ᝗"),l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫ᝘"),551,l1l1ll_l1_ (u"࠭ࠧ᝙"),l1l1ll_l1_ (u"ࠧࠨ᝚"),l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ᝛"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᝜"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᝝"),block,re.DOTALL)
	for l1111ll11_l1_,title in items:
		link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࡃ࡮ࡺࡥ࡮࠿ࠪ᝞")+l1111ll11_l1_+l1l1ll_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭᝟")
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝠ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᝡ")+menu_name+title,link,551)
	#addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᝢ"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᝣ"),l1l1ll_l1_ (u"ࠪࠫᝤ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡴࡡࡷ࠯ࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡹࡂࠬᝥ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᝦ"),block,re.DOTALL)
	for link,title in items:
		if link==l1l1ll_l1_ (u"࠭ࠣࠨᝧ"): continue
		if title in l1ll11_l1_: continue
		if l1l1ll_l1_ (u"ࠧๆี็ื้ࠦࠧᝨ") in title: continue
		if l1l1ll_l1_ (u"ࠨละำะ࠭ᝩ") in title: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᝪ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᝫ")+menu_name+title,link,551)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᝬ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᝭"),l1l1ll_l1_ (u"࠭ࠧᝮ"),9999)
	for link,title in items:
		if link==l1l1ll_l1_ (u"ࠧࠤࠩᝯ"): continue
		if title in l1ll11_l1_: continue
		if l1l1ll_l1_ (u"ࠨ็ึุ่๊ࠠࠨᝰ") in title: continue
		if l1l1ll_l1_ (u"ࠩฦัิัࠧ᝱") not in title: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᝲ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᝳ")+menu_name+title,link,551)
	return
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"ࠬ࠭᝴")):
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ᝵"),l1l1ll_l1_ (u"ࠧࠨ᝶"),url)
	items = []
	# l1llll1l1l_l1_ l1llll1ll1_l1_
	if l1l1ll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ᝷") in url or l1l1ll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ᝸") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ᝹"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ᝺")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ᝻"),url2,data2,headers2,l1l1ll_l1_ (u"࠭ࠧ᝼"),l1l1ll_l1_ (u"ࠧࠨ᝽"),l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ᝾"))
		html = response.content
		l1lll11_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭᝿"),url,l1l1ll_l1_ (u"ࠪࠫក"),l1l1ll_l1_ (u"ࠫࠬខ"),l1l1ll_l1_ (u"ࠬ࠭គ"),l1l1ll_l1_ (u"࠭ࠧឃ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ង"))
		html = response.content
		# l1111ll11_l1_ items
		if l1111ll11_l1_==l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪច"):
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩឆ"),html,re.DOTALL)
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩជ"),block,re.DOTALL)
			#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬឈ"),l1l1ll_l1_ (u"ࠬ࠭ញ"),l1l1ll_l1_ (u"࠭ࠧដ"))
		# l1lllll1l1_l1_ l11l1l1l_l1_
		elif l1l1ll_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠧឋ") in html:
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪឌ"),html,re.DOTALL)
		else:
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧឍ"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	if not items:
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬណ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪត"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"๋ࠬิศ้าอࠬថ"),l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫទ"),l1l1ll_l1_ (u"ࠧศ฼้๎ฮ࠭ធ"),l1l1ll_l1_ (u"ࠨๅ็๎อ࠭ន"),l1l1ll_l1_ (u"ࠩส฽้อๆࠨប"),l1l1ll_l1_ (u"๋ࠪิอแࠨផ"),l1l1ll_l1_ (u"๊ࠫฮวาษฬࠫព"),l1l1ll_l1_ (u"ࠬ฿ัืࠩភ"),l1l1ll_l1_ (u"࠭ๅ่ำฯห๋࠭ម"),l1l1ll_l1_ (u"ࠧศๆห์๊࠭យ")]
	for link,title,img in items:
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠨ࠱ࠪរ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬល"),title,re.DOTALL)
		if l1l1ll_l1_ (u"ࠪื้อำๅࠩវ") not in url and any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪឝ"),menu_name+title,link,552,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠬอไฮๆๅอࠬឞ") in title:
			title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬស") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧហ"),menu_name+title,link,553,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪឡ") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩអ"),menu_name+title,link,551,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឣ"),menu_name+title,link,553,img)
	if l1111ll11_l1_==l1l1ll_l1_ (u"ࠫࠬឤ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࠩឥ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨឦ"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠢࠣឧ"): continue
				#title = unescapeHTML(title)
				if title!=l1l1ll_l1_ (u"ࠨࠩឨ"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩឩ"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩឪ")+title,link,551)
	if l1l1ll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫឫ") in url or l1l1ll_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ឬ") in url:
		if l1l1ll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ឭ") in url:
			url = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡌࡸࡪࡳࠧឮ"),l1l1ll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯࡭ࡱࡤࡨࡒࡵࡲࡦࠩឯ"))+l1l1ll_l1_ (u"ࠩࠩࡳ࡫࡬ࡳࡦࡶࡀ࠶࠵࠭ឰ")
		elif l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫឱ") in url:
			url,offset = url.split(l1l1ll_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭ឲ"))
			offset = int(offset)+20
			url = url+l1l1ll_l1_ (u"ࠬࠬ࡯ࡧࡨࡶࡩࡹࡃࠧឳ")+str(offset)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭឴"),menu_name+l1l1ll_l1_ (u"่่ࠧส็ࠥอไๆิํำࠬ឵"),url,551)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬា"),url,l1l1ll_l1_ (u"ࠩࠪិ"),l1l1ll_l1_ (u"ࠪࠫី"),l1l1ll_l1_ (u"ࠫࠬឹ"),l1l1ll_l1_ (u"ࠬ࠭ឺ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧុ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡩࡨࡸࡘ࡫ࡡࡴࡱࡱࡷࡇࡿࡓࡦࡴ࡬ࡩࡸ࠮࠮ࠫࡁࠬࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠨូ"),html,re.DOTALL)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤ࡯࡭ࡸࡺ࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬួ"),html,re.DOTALL)
	# l11l11_l1_
	if l1ll1ll_l1_ and l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫើ") not in url:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩឿ"),block,re.DOTALL)
		for link,title,img in items:
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫៀ"),menu_name+title,link,553,img)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		img = re.findall(l1l1ll_l1_ (u"ࠬࠨࡩ࡮ࡣࡪࡩࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫេ"),html,re.DOTALL)
		img = img[0]
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬែ"),block,re.DOTALL)
		for link,title in items:
			#title = title.replace(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪៃ"),l1l1ll_l1_ (u"ࠨࠩោ")).strip(l1l1ll_l1_ (u"ࠩࠣࠫៅ"))
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩំ"),menu_name+title,link,552,img)
	return
def PLAY(url):
	url2 = url.replace(l1l1ll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ះ"),l1l1ll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡤࡳ࡯ࡷ࡫ࡨࡷ࠴࠭ៈ"))
	url2 = url2.replace(l1l1ll_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ៉"),l1l1ll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ៊"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ់"),url2,l1l1ll_l1_ (u"ࠩࠪ៌"),l1l1ll_l1_ (u"ࠪࠫ៍"),l1l1ll_l1_ (u"ࠫࠬ៎"),l1l1ll_l1_ (u"ࠬ࠭៏"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ័"))
	html = response.content
	l11ll1_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ៑"))
	l11l1_l1_ = []
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ្ࠧ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1l11lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡳࡳࡸࡺࡉࡅࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ៓"),html,re.DOTALL)
		l1l11lll_l1_ = l1l11lll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠥ࡫ࡪࡺࡐ࡭ࡣࡼࡩࡷࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠥ។"),block,re.DOTALL)
		if items:
			for server,title in items:
				title = title.replace(l1l1ll_l1_ (u"ࠫࡡࡴࠧ៕"),l1l1ll_l1_ (u"ࠬ࠭៖")).strip(l1l1ll_l1_ (u"࠭ࠠࠨៗ"))
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡓࡰࡦࡿࡥࡳࡁࡶࡩࡷࡼࡥࡳ࠿ࠪ៘")+server+l1l1ll_l1_ (u"ࠨࠨࡳࡳࡸࡺࡉࡅ࠿ࠪ៙")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠩࠩࡅ࡯ࡧࡸ࠾࠳ࠪ៚")
				link = link+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ៛")+title+l1l1ll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬៜ")
				l11l1_l1_.append(link)
		else:
			items = re.findall(l1l1ll_l1_ (u"ࠧ࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡃࡻࡑࡥࡲ࡫࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡢࠢࡴࡧࡵࡺࡪࡸ࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠧ៝"),block,re.DOTALL)
			for server,l1llll1l11_l1_,title in items:
				title = title.replace(l1l1ll_l1_ (u"࠭࡜࡯ࠩ៞"),l1l1ll_l1_ (u"ࠧࠨ៟")).strip(l1l1ll_l1_ (u"ࠨࠢࠪ០"))
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡕࡲࡡࡺࡧࡵࡆࡾࡔࡡ࡮ࡧࡂࡷࡪࡸࡶࡦࡴࡀࠫ១")+server+l1l1ll_l1_ (u"ࠪࠪࡲࡻ࡬ࡵ࡫ࡳࡰࡪ࡙ࡥࡳࡸࡨࡶࡸࡃࠧ២")+l1llll1l11_l1_+l1l1ll_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡌࡈࡂ࠭៣")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭៤")
				link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៥")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ៦")
				l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡧࡳࡼࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ៧"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៨"),block,re.DOTALL)
		for link,name in items:
			link = link+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ៩")+name+l1l1ll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ៪")
			if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ៫") not in link: link = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ៬")+link
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ៭"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ៮"),url)
	return
l1l1ll_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡓࡐࡆ࡟࡟ࡐࡎࡇࠬࡺࡸ࡬ࠪ࠼ࠍࠍࡩࡧࡴࡢࠢࡀࠤࢀ࠭ࡖࡪࡧࡺࠫ࠿࠷ࡽࠋࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࠺ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࡹࡷࡲࠬࡥࡣࡷࡥ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡅࡇࡊࡏ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜࡟ࠍࠍࠨࠦࡷࡢࡶࡦ࡬ࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡼࡧࡴࡤࡪࡄࡶࡪࡧࡍࡢࡵࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡲࡩ࡯࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࠧࠬࡶ࡬ࡸࡱ࡫ࠫࠨࡡࡢࡻࡦࡺࡣࡩࠩࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡲࡩ࡯࡭ࡶࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡩࡵ࡮ࡸ࡮ࡲࡥࡩ࠳ࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡴࡧࡵ࠱ࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥ࠭ࡳࡸࡥࡱ࡯ࡴࡺ࠮࡯࡭ࡳࡱࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࡯ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ࠭ࠪࡣࡤࡥ࡟ࠨ࠭ࡴࡹࡦࡲࡩࡵࡻࠍࠍࠎࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰ࠯ࠊࠊࠥࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟ࡔࡇࡏࡉࡈ࡚ࠨࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠍࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠯࠽࠾࠲࠽ࠤࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬอไาษห฻๊๊ࠥิࠢไ๎์ࠦแ๋ัํ์ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋ࡬ࡱࡵࡵࡲࡵࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗࠏࠏࠉࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡔࡑࡇ࡙ࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࠬࡼࡩࡥࡧࡲࠫ࠱ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ៯")
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠪࠫ៰"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠫࠬ៱"): return
	search = search.replace(l1l1ll_l1_ (u"ࠬࠦࠧ៲"),l1l1ll_l1_ (u"࠭࠭ࠨ៳"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ៴")+search+l1l1ll_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ៵")
	l11l1l_l1_(url)
	return
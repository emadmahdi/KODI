# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ咫")
menu_name = l1l1ll_l1_ (u"ࠫࡤ࡙ࡈࡏࡡࠪ咬")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"่ࠬๆ้ษอࠤๆ฼วว์ฬࠫ咭"),l1l1ll_l1_ (u"࠭แศำึ็ํ࠭咮"),l1l1ll_l1_ (u"ࠧࡔࡪࡲࡻࠥࡳ࡯ࡳࡧࠪ咯")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l11l1l_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l11ll1l_l1_(url,text)
	elif mode==584: results = l1ll1l_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ咰"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ咱"),l1l1ll_l1_ (u"ࠪࠫ咲"),l1l1ll_l1_ (u"ࠫࠬ咳"),l1l1ll_l1_ (u"ࠬ࠭咴"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ咵"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ咶"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ咷"),l1l1ll_l1_ (u"ࠩࠪ咸"),589,l1l1ll_l1_ (u"ࠪࠫ咹"),l1l1ll_l1_ (u"ࠫࠬ咺"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ咻"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ咼"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ咽"),l1l1ll_l1_ (u"ࠨࠩ咾"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭咿"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ哀"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠫࠬ品"))
	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ哂"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭哃"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ哄")+menu_name+title,link,584)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ哅"),url,l1l1ll_l1_ (u"ࠩࠪ哆"),l1l1ll_l1_ (u"ࠪࠫ哇"),l1l1ll_l1_ (u"ࠫࠬ哈"),l1l1ll_l1_ (u"ࠬ࠭哉"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ哊"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ哋"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ哌"),l1l1ll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ响"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ哎"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠫࠬ哏"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ哐"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ哑"),l1l1ll_l1_ (u"ࠧࠨ哒"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭哓"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠩ࠽ࠤࠬ哔")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ哕"),menu_name+title,link,581)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ哖"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ哗"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ哘"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ哙"),l1l1ll_l1_ (u"ࠨࠩ哚"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ哛"),menu_name+title,link,581)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠪࠫ哜")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ哝"),l1l1ll_l1_ (u"ࠬ࠭哞"),request,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ哟"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ哠"),url,l1l1ll_l1_ (u"ࠨࠩ員"),l1l1ll_l1_ (u"ࠩࠪ哢"),l1l1ll_l1_ (u"ࠪࠫ哣"),l1l1ll_l1_ (u"ࠫࠬ哤"),l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭哥"))
	html = response.content
	items = []
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ哦"),html,re.DOTALL)
	if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧ哧"),html,re.DOTALL)
	if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ哨"),html,re.DOTALL)
	if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ哩"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ哪"),block,re.DOTALL)
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭哫"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"๋ࠬิศ้าอࠬ哬"),l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫ哭"),l1l1ll_l1_ (u"ࠧศ฼้๎ฮ࠭哮"),l1l1ll_l1_ (u"ࠨๅ็๎อ࠭哯"),l1l1ll_l1_ (u"ࠩส฽้อๆࠨ哰"),l1l1ll_l1_ (u"๋ࠪิอแࠨ哱"),l1l1ll_l1_ (u"๊ࠫฮวาษฬࠫ哲"),l1l1ll_l1_ (u"ࠬ฿ัืࠩ哳"),l1l1ll_l1_ (u"࠭ๅ่ำฯห๋࠭哴"),l1l1ll_l1_ (u"ࠧศๆห์๊࠭哵"),l1l1ll_l1_ (u"ࠨ็ึีา๐ษࠨ哶")]
	for img,link,title in items:
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ哷"))
		if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ哸") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭哹")+link.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ哺"))
		if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ哻") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ哼")+img.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ哽"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ哾"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭哿"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ唀"),menu_name+title,link,582,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠬอไฮๆๅอࠬ唁") in title:
			title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ唂") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ唃"),menu_name+title,link,583,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭唄") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ唅"),menu_name+title,link,581,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唆"),menu_name+title,link,583,img)
	if request not in [l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭唇"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ唈")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ唉"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ唊"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠨࠥࠪ唋"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ唌")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ唍"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唎"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ唏")+title,link,581)
		l1111l111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ唐"),html,re.DOTALL)
		if l1111l111_l1_:
			link = l1111l111_l1_[0]
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ唑"),menu_name+l1l1ll_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ唒"),link,581)
	return
def l11ll1l_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ唓"),l1l1ll_l1_ (u"ࠪࠫ唔"),l1lll_l1_,url)
	#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ唕"),l1l1ll_l1_ (u"ࠬ࠷࠱࠲࠳ࠣࠤࠬ唖")+url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ唗"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ唘"),url,l1l1ll_l1_ (u"ࠨࠩ唙"),l1l1ll_l1_ (u"ࠩࠪ唚"),l1l1ll_l1_ (u"ࠪࠫ唛"),l1l1ll_l1_ (u"ࠫࠬ唜"),l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ唝"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡮ࡢࡸ࠰ࡷࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ唞"),html,re.DOTALL)
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ唟"),str(l1lll_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ唠"),str(l1ll1l1_l1_))
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ唡"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠪࠧࠬ唢"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唣"),menu_name+title,url,583,l1l1ll_l1_ (u"ࠬ࠭唤"),l1l1ll_l1_ (u"࠭ࠧ唥"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࠬ唦")+l1lll_l1_+l1l1ll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ唧"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ唨"),block,re.DOTALL)
		if items:
			for link,title in items:
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ唩")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭唪"))
				addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ唫"),menu_name+title,link,582)
		else:
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ唬"),block,re.DOTALL)
			for link,title,img in items:
				if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ唭") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪ售")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ唯"))
				addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ唰"),menu_name+title,link,582)
	return
def PLAY(url):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ唱"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ唲"),url,l1l1ll_l1_ (u"࠭ࠧ唳"),l1l1ll_l1_ (u"ࠧࠨ唴"),l1l1ll_l1_ (u"ࠨࠩ唵"),l1l1ll_l1_ (u"ࠩࠪ唶"),l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ唷"))
	html = response.content
	# l111l1_l1_ page
	link = re.findall(l1l1ll_l1_ (u"ࠫࠧࡖ࡬ࡢࡻࡨࡶ࡭ࡵ࡬ࡥࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭唸"),html,re.DOTALL)
	link = link[0]
	if link and l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ唹") not in link: link = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ唺")+link
	#//l1l1ll1llll_l1_.l1l111lll1l1_l1_.l1l111lll11l_l1_/l1l111lll1ll_l1_/?l1l111lllll1_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = link.split(l1l1ll_l1_ (u"ࠧࡩࡣࡶ࡬ࡂ࠭唻"))[1]
	parts = hash.split(l1l1ll_l1_ (u"ࠨࡡࡢࠫ唼"))
	l1l111llll1l_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l1ll_l1_ (u"ࠩࡀࠫ唽"))
			if kodi_version>18.99: part = part.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ唾"))
			l1l111llll1l_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l1ll_l1_ (u"ࠫࡃ࠭唿").join(l1l111llll1l_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭啀"),str(l1ll_l1_))
	if l1l1ll_l1_ (u"࠭ࡦࡢࡴࡶࡳࡱ࠭啁") not in str(l1ll_l1_):
		for link in l1ll_l1_:
			title,link = link.split(l1l1ll_l1_ (u"ࠧࠡ࠿ࡁࠤࠬ啂"))
			link = link+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ啃")+title+l1l1ll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ啄")
			l11l1_l1_.append(link)
		#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ啅"),l11l1_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ商"),url)
	else:
		title,link = l1ll_l1_[0].split(l1l1ll_l1_ (u"ࠬࠦ࠽࠿ࠢࠪ啇"))
		DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ啈"),l1l1ll_l1_ (u"ࠧࠨ啉"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ啊"),l1l1ll_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆࠨ啋")+l1l1ll_l1_ (u"ࠪࡠࡳ࠭啌")+l1l1ll_l1_ (u"ࠫ๏ืฬ๊ࠢส่๊ำว้ๆฬࠤ้ออใษࠪ啍")+l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ啎")+title)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧ問"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨ啐"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪ啑"),l1l1ll_l1_ (u"ࠩ࠮ࠫ啒"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ啓")+search
	l11l1l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧᏯ")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡅࡖࡘࡥࠧᏰ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫᏱ"),l1l1ll_l1_ (u"ࠪࡗ࡮࡭࡮ࠡ࡫ࡱࠫᏲ"),l1l1ll_l1_ (u"ࠫฬ๊วใีส้ࠬᏳ"),l1l1ll_l1_ (u"ࠬ฿ัืࠢสุ่๊๊ะࠩᏴ")]
def MAIN(mode,url,text):
	if   mode==650: results = MENU()
	elif mode==651: results = l11l1l_l1_(url,text)
	elif mode==652: results = PLAY(url)
	elif mode==653: results = l11_l1_(url,text)
	elif mode==654: results = l1ll1l_l1_(url)
	elif mode==659: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᏵ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ᏶"),l1l1ll_l1_ (u"ࠨࠩ᏷"),l1l1ll_l1_ (u"ࠩࠪᏸ"),l1l1ll_l1_ (u"ࠪࠫᏹ"),l1l1ll_l1_ (u"ࠫࡇࡘࡓࡕࡇࡍ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᏺ"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᏻ"),menu_name+l1l1ll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᏼ"),l1l1ll_l1_ (u"ࠧࠨᏽ"),659,l1l1ll_l1_ (u"ࠨࠩ᏾"),l1l1ll_l1_ (u"ࠩࠪ᏿"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᐀"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᐁ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᐂ"),l1l1ll_l1_ (u"࠭ࠧᐃ"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᐄ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᐅ")+menu_name+l1l1ll_l1_ (u"ࠩส่๊๋๊ำหࠪᐆ"),l1l1l1_l1_,651,l1l1ll_l1_ (u"ࠪࠫᐇ"),l1l1ll_l1_ (u"ࠫࠬᐈ"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᐉ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐊ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐋ")+menu_name+l1l1ll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᐌ"),l1l1l1_l1_,651,l1l1ll_l1_ (u"ࠩࠪᐍ"),l1l1ll_l1_ (u"ࠪࠫᐎ"),l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᐏ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᐐ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᐑ")+menu_name+l1l1ll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᐒ"),l1l1l1_l1_,651,l1l1ll_l1_ (u"ࠨࠩᐓ"),l1l1ll_l1_ (u"ࠩࠪᐔ"),l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᐕ"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᐖ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᐗ")+menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᐘ"),l1l1l1_l1_,651,l1l1ll_l1_ (u"ࠧࠨᐙ"),l1l1ll_l1_ (u"ࠨࠩᐚ"),l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᐛ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐜ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐝ"),l1l1ll_l1_ (u"ࠬ࠭ᐞ"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐟ"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᐠ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᐡ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᐢ")+menu_name+title,link,654)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᐣ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐤ"),l1l1ll_l1_ (u"ࠬ࠭ᐥ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᐦ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᐧ"),html,re.DOTALL)
	#for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠨࠩᐨ"))
	#block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᐩ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		title = title.replace(l1l1ll_l1_ (u"ࠪࡀࡧࡄࠧᐪ"),l1l1ll_l1_ (u"ࠫࠬᐫ")).strip(l1l1ll_l1_ (u"ࠬࠦࠧᐬ"))
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᐭ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᐮ")+menu_name+title,link,654)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᐯ"),url,l1l1ll_l1_ (u"ࠩࠪᐰ"),l1l1ll_l1_ (u"ࠪࠫᐱ"),l1l1ll_l1_ (u"ࠫࠬᐲ"),l1l1ll_l1_ (u"ࠬ࠭ᐳ"),l1l1ll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᐴ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᐵ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᐶ"),l1l1ll_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᐷ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᐸ"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠫࠬᐹ"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᐺ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᐻ"),l1l1ll_l1_ (u"ࠧࠨᐼ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᐽ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠩ࠽ࠤࠬᐾ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᐿ"),menu_name+title,link,651)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑀ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᑁ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᑂ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᑃ"),l1l1ll_l1_ (u"ࠨࠩᑄ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᑅ"),menu_name+title,link,651)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠪࠫᑆ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬᑇ"),l1l1ll_l1_ (u"ࠬ࠭ᑈ"),request,url)
	if request==l1l1ll_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᑉ"):
		url,search = url.split(l1l1ll_l1_ (u"ࠧࡀࠩᑊ"),1)
		data = l1l1ll_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᑋ")+search
		headers = {l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᑌ"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᑍ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩᑎ"),url,data,headers,l1l1ll_l1_ (u"ࠬ࠭ᑏ"),l1l1ll_l1_ (u"࠭ࠧᑐ"),l1l1ll_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᑑ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᑒ"),url,l1l1ll_l1_ (u"ࠩࠪᑓ"),l1l1ll_l1_ (u"ࠪࠫᑔ"),l1l1ll_l1_ (u"ࠫࠬᑕ"),l1l1ll_l1_ (u"ࠬ࠭ᑖ"),l1l1ll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᑗ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠧࠨᑘ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬᑙ"))
	if request==l1l1ll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᑚ"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᑛ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠫࠬᑜ"),link,title))
	elif request==l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᑝ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᑞ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᑟ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᑠ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᑡ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᑢ"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᑣ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᑤ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᑥ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠧࠨᑦ"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᑧ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᑨ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ู้ࠪอ็ะหࠪᑩ"),l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩᑪ"),l1l1ll_l1_ (u"ࠬอฺ็์ฬࠫᑫ"),l1l1ll_l1_ (u"࠭ใๅ์หࠫᑬ"),l1l1ll_l1_ (u"ࠧศ฻็ห๋࠭ᑭ"),l1l1ll_l1_ (u"ࠨ้าหๆ࠭ᑮ"),l1l1ll_l1_ (u"่ࠩฬฬืวสࠩᑯ"),l1l1ll_l1_ (u"ࠪ฽ึ฼ࠧᑰ"),l1l1ll_l1_ (u"๊ࠫํัอษ้ࠫᑱ"),l1l1ll_l1_ (u"ࠬอไษ๊่ࠫᑲ"),l1l1ll_l1_ (u"࠭ๅิำะ๎ฮ࠭ᑳ")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩᑴ"))
		#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᑵ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫᑶ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬᑷ"))
		#if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᑸ") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧᑹ")+img.strip(l1l1ll_l1_ (u"࠭࠯ࠨᑺ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩᑻ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᑼ"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᑽ"),menu_name+title,link,652,img)
		elif request==l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᑾ"):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᑿ"),menu_name+title,link,652,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᒀ") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒁ"),menu_name+title,link,653,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᒂ") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᒃ"),menu_name+title,link,651,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᒄ"),menu_name+title,link,653,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᒅ"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᒆ")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒇ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᒈ"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠧࠤࠩᒉ"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪᒊ")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫᒋ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᒌ"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪᒍ")+title,link,651)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ᒎ"),l1l1ll_l1_ (u"࠭ࠧᒏ"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫᒐ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᒑ"),url,l1l1ll_l1_ (u"ࠩࠪᒒ"),l1l1ll_l1_ (u"ࠪࠫᒓ"),l1l1ll_l1_ (u"ࠫࠬᒔ"),l1l1ll_l1_ (u"ࠬ࠭ᒕ"),l1l1ll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᒖ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᒗ"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᒘ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠩࠪᒙ")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫᒚ"),block,re.DOTALL)
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᒛ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠬࠩࠧᒜ"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᒝ"),menu_name+title,url,653,img,l1l1ll_l1_ (u"ࠧࠨᒞ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᒟ"),html,re.DOTALL)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪᒠ"),str(l1lll11_l1_))
	block = l1lll11_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᒡ")+l1lll_l1_+l1l1ll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᒢ"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᒣ")+l1lll_l1_+l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᒤ"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᒥ")+l1lll_l1_+l1l1ll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᒦ"),block,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᒧ"),block,re.DOTALL)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫᒨ"),l1l1ll_l1_ (u"ࠫࠬᒩ"),l1l1ll_l1_ (u"ࠬ࠭ᒪ"),l1l1ll_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᒫ"))
		if not l1lll1l_l1_: l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᒬ"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒭ"),block,re.DOTALL)
		for link,title,img in items:
			link = link.strip(l1l1ll_l1_ (u"ࠩ࠱࠳ࠬᒮ"))
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬᒯ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᒰ"))
			title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᒱ"),l1l1ll_l1_ (u"࠭ࠠࠨᒲ"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᒳ"),menu_name+title,link,652,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᒴ"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᒵ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬᒶ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᒷ"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᒸ"),menu_name+title,link,652,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᒹ"),l1l1ll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪᒺ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᒻ"),url2,l1l1ll_l1_ (u"ࠩࠪᒼ"),l1l1ll_l1_ (u"ࠪࠫᒽ"),l1l1ll_l1_ (u"ࠫࠬᒾ"),l1l1ll_l1_ (u"ࠬ࠭ᒿ"),l1l1ll_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᓀ"))
	html = response.content
	# l1l1l1l11_l1_ link
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡕࡲࡡࡺࡧࡵ࡬ࡴࡲࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᓁ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		link = re.findall(l1l1ll_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᓂ"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᓃ"))
			l11l1_l1_.append(link)
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᓄ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠮ࡷࡵࡰࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠤᓅ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧᓆ"))
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᓇ")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᓈ"))
				l11l1_l1_.append(link)
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡯࡭ࡳࡱࡳࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ࠲ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨࠫࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲ࠲࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡃࡔࡖࡘࡊࡐ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡵࡳ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠻ࠌࠌࠍࠎࠏ࡮ࡢ࡯ࡨࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨࠫࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧᓉ")
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᓊ"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᓋ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬᓌ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭ᓍ"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨᓎ"),l1l1ll_l1_ (u"ࠧࠬࠩᓏ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩᓐ")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᓑ"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧᓒ")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᓓ"))
	return
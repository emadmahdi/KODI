# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫ䅗")
headers = {l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䅘"):l1l1ll_l1_ (u"࠭ࠧ䅙")}
script_name = l1l1ll_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭䅚")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ䅛")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l1l1ll_l1_ (u"ࠩ࠶ࠫ䅜"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l1l1ll_l1_ (u"ࠪ࠵ࠬ䅝"))
	elif mode==36: results = CATEGORIES(url,l1l1ll_l1_ (u"ࠫ࠷࠭䅞"))
	elif mode==37: results = CATEGORIES(url,l1l1ll_l1_ (u"ࠬ࠺ࠧ䅟"))
	elif mode==38: results = l1ll1l11l_l1_()
	elif mode==39: results = SEARCH(text,page)
	else: results = False
	return results
def MENU():
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅠"),menu_name+l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䅡"),l1l1ll_l1_ (u"ࠨࠩ䅢"),39,l1l1ll_l1_ (u"ࠩࠪ䅣"),l1l1ll_l1_ (u"ࠪࠫ䅤"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䅥"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䅦"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䅧"),l1l1ll_l1_ (u"ࠧࠨ䅨"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䅩"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䅪")+menu_name+l1l1ll_l1_ (u"ࠪๆ๋อษ้ࠡ็ห๋ࠥๆࠡ็๋ๆ฾ࠦศศ่ํฮࠬ䅫"),l1l1ll_l1_ (u"ࠫࠬ䅬"),38)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䅭"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䅮")+menu_name+l1l1ll_l1_ (u"ࠧๆี็ื้อส๊ࠡหีฬ๋ฬࠨ䅯"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䅰"),31)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅱"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䅲")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆส็ะืࠠๆึส๋ิฯࠧ䅳"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䅴"),37)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅵"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䅶")+menu_name+l1l1ll_l1_ (u"ࠨษไ่ฬ๋ࠠฮีหࠤฬ๊ๆ้฻ࠪ䅷"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ䅸"),35)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䅹"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䅺")+menu_name+l1l1ll_l1_ (u"ࠬอแๅษ่ࠤาูศࠡษ็้๊ัไࠨ䅻"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ䅼"),36)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䅽"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䅾")+menu_name+l1l1ll_l1_ (u"ࠩสัิัࠠศๆสๅ้อๅࠨ䅿"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫ䆀"),32)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆁"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䆂")+menu_name+l1l1ll_l1_ (u"࠭ๅิำะ๎ฬะࠧ䆃"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࡩࡨࡲࡷ࡫࠯࠵࠱࠴ࠫ䆄"),32)
	return l1l1ll_l1_ (u"ࠨࠩ䆅")
def CATEGORIES(url,select=l1l1ll_l1_ (u"ࠩࠪ䆆")):
	type = url.split(l1l1ll_l1_ (u"ࠪ࠳ࠬ䆇"))[3]
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䆈"),l1l1ll_l1_ (u"ࠬ࠭䆉"),type, url)
	if type==l1l1ll_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䆊"):
		html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠧࠨ䆋"),headers,l1l1ll_l1_ (u"ࠨࠩ䆌"),l1l1ll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ䆍"))
		if select==l1l1ll_l1_ (u"ࠪ࠷ࠬ䆎"):
			l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭䆏"),html,re.DOTALL)
			block= l1lll11_l1_[0]
			items=re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䆐"),block,re.DOTALL)
			for link,name in items:
				if l1l1ll_l1_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬ䆑") in name: continue
				url = l1l1l1_l1_ + link
				name = name.strip(l1l1ll_l1_ (u"ࠧࠡࠩ䆒"))
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䆓"),menu_name+name,url,32)
		if select==l1l1ll_l1_ (u"ࠩ࠷ࠫ䆔"):
			l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䆕"),html,re.DOTALL)
			block= l1lll11_l1_[0]
			items=re.findall(l1l1ll_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䆖"),block,re.DOTALL)
			for link,img,title in items:
				url = l1l1l1_l1_ + link
				title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ䆗"))
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䆘"),menu_name+title,url,32,img)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䆙"),l1l1ll_l1_ (u"ࠨࠩ䆚"),url,l1l1ll_l1_ (u"ࠩࠪ䆛"))
	if type==l1l1ll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䆜"):
		html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠫࠬ䆝"),headers,l1l1ll_l1_ (u"ࠬ࠭䆞"),l1l1ll_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠵ࡲࡩ࠭䆟"))
		if select==l1l1ll_l1_ (u"ࠧ࠲ࠩ䆠"):
			l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡈࡧࡱࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ䆡"),html,re.DOTALL)
			block = l1lll11_l1_[0]
			items=re.findall(l1l1ll_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䆢"),block,re.DOTALL)
			for value,name in items:
				url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳࡬࡫࡮ࡳࡧ࠲ࠫ䆣") + value
				name = name.strip(l1l1ll_l1_ (u"ࠫࠥ࠭䆤"))
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䆥"),menu_name+name,url,32)
		elif select==l1l1ll_l1_ (u"࠭࠲ࠨ䆦"):
			l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡁࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ䆧"),html,re.DOTALL)
			block = l1lll11_l1_[0]
			items=re.findall(l1l1ll_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䆨"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l1ll_l1_ (u"ࠩࠣࠫ䆩"))
				url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࡦࡩࡴࡰࡴ࠲ࠫ䆪") + value
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆫"),menu_name+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䆬"),l1l1ll_l1_ (u"࠭ࠧ䆭"),url,l1l1ll_l1_ (u"ࠧࠨ䆮"))
	type = url.split(l1l1ll_l1_ (u"ࠨ࠱ࠪ䆯"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠩࠪ䆰"),headers,l1l1ll_l1_ (u"ࠪࠫ䆱"),l1l1ll_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䆲"))
	if l1l1ll_l1_ (u"ࠬ࡮࡯࡮ࡧࠪ䆳") in url: type=l1l1ll_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䆴")
	if type==l1l1ll_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䆵"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠬ࠳࠰࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䆶"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䆷"),block,re.DOTALL)
			for link,img,name in items:
				url = l1l1l1_l1_ + link
				name = name.strip(l1l1ll_l1_ (u"ࠪࠤࠬ䆸"))
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆹"),menu_name+name,url,32,img)
	if type==l1l1ll_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䆺"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ䆻"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠫࡀࠫࠥࠫ䆼"),block,re.DOTALL)
		for link,img,name in items:
			name = name.strip(l1l1ll_l1_ (u"ࠨࠢࠪ䆽"))
			url = l1l1l1_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䆾"),menu_name+name,url,33,img)
	if type==l1l1ll_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䆿"):
		page = url.split(l1l1ll_l1_ (u"ࠫ࠴࠭䇀"))[-1]
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䇁"),l1l1ll_l1_ (u"࠭ࠧ䇂"),url,l1l1ll_l1_ (u"ࠧࠨ䇃"))
		if page==l1l1ll_l1_ (u"ࠨ࠳ࠪ䇄"):
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠧ䇅"),html,re.DOTALL)
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮࡫ࡱࡪࡴࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࠫ䇆"),block,re.DOTALL)
			count = 0
			for link,img,l11111_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨ䇇") + l11111_l1_
				url = l1l1l1_l1_ + link
				addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䇈"),menu_name+name,url,33,img)
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵ࠱࠮ࡄࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠪ࠱࠯ࡄ࠯ࡰࡢࡰࡨࡸ࠲ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ䇉"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡳࡥࡳ࡫ࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲ࠨ䇊"),block,re.DOTALL)
		for link,img,title,l11111_l1_ in items:
			l11111_l1_ = l11111_l1_.strip(l1l1ll_l1_ (u"ࠨࠢࠪ䇋"))
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ䇌"))
			name = title + l1l1ll_l1_ (u"ࠪࠤ࠲ࠦࠧ䇍") + l11111_l1_
			url = l1l1l1_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䇎"),menu_name+name,url,33,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡵ࡭࡬࡮ࡴࠩ࠰࠮ࡃ࠮ࡪࡡࡵࡣ࠰ࡶࡪࡼࡩࡷࡧ࠰ࡾࡴࡴࡥࡪࡦࡀࠦ࠹ࠨࠧ䇏"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䇐"),block,re.DOTALL)
	for link,page in items:
		url = l1l1l1_l1_ + link
		name = l1l1ll_l1_ (u"ࠧึใะอࠥ࠭䇑") + page
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇒"),menu_name+name,url,32)
	return
def PLAY(url):
	if l1l1ll_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䇓") in url:
		url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴ࠰ࡸ࠴࠳ࡸ࡫ࡲࡪࡧࡶࡐ࡮ࡴ࡫࠰ࠩ䇔") + url.split(l1l1ll_l1_ (u"ࠫ࠴࠭䇕"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ䇖"),url,l1l1ll_l1_ (u"࠭ࠧ䇗"),headers,l1l1ll_l1_ (u"ࠧࠨ䇘"),l1l1ll_l1_ (u"ࠨࠩ䇙"),l1l1ll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䇚"))
		html = response.content
		items = re.findall(l1l1ll_l1_ (u"ࠪࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䇛"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l1ll_l1_ (u"ࠫࡡ࠵ࠧ䇜"),l1l1ll_l1_ (u"ࠬ࠵ࠧ䇝"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䇞"),url,l1l1ll_l1_ (u"ࠧࠨ䇟"),headers,l1l1ll_l1_ (u"ࠨࠩ䇠"),l1l1ll_l1_ (u"ࠩࠪ䇡"),l1l1ll_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ䇢"))
		html = response.content
		items = re.findall(l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࡚ࡘࡌࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䇣"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䇤"))
	return
def SEARCH(search,page=l1l1ll_l1_ (u"࠭ࠧ䇥")):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ䇦"),l1l1ll_l1_ (u"ࠨࠧ࠵࠴ࠬ䇧"))
	l1ll1ll11_l1_ = [l1l1ll_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䇨"),l1l1ll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ䇩")]
	if not page: page = l1l1ll_l1_ (u"ࠫ࠶࠭䇪")
	else: page,type = page.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ䇫"))
	if showDialogs:
		l1l1ll11l_l1_ = [ l1l1ll_l1_ (u"࠭ศฮอࠣ฽๋ࠦวโๆส้ࠬ䇬") , l1l1ll_l1_ (u"ࠧษฯฮࠤ฾์ࠠๆี็ื้อสࠨ䇭")]
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥ࠳ࠠศะอีࠥอไษฯฮࠫ䇮"), l1l1ll11l_l1_)
		if selection == -1 : return
		type = l1ll1ll11_l1_[selection]
	else:
		if l1l1ll_l1_ (u"ࠩࡢࡔࡆࡔࡅࡕ࠯ࡐࡓ࡛ࡏࡅࡔࡡࠪ䇯") in options: type = l1l1ll_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䇰")
		elif l1l1ll_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࡣࠬ䇱") in options: type = l1l1ll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䇲")
		else: return
	headers[l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䇳")] = l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䇴")
	data = {l1l1ll_l1_ (u"ࠨࡳࡸࡩࡷࡿࠧ䇵"):l11lll1_l1_ , l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡆࡲࡱࡦ࡯࡮ࠨ䇶"):type}
	if page!=l1l1ll_l1_ (u"ࠪ࠵ࠬ䇷"): data[l1l1ll_l1_ (u"ࠫ࡫ࡸ࡯࡮ࠩ䇸")] = page
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䇹"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ䇺"),data,headers,l1l1ll_l1_ (u"ࠧࠨ䇻"),l1l1ll_l1_ (u"ࠨࠩ䇼"),l1l1ll_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䇽"))
	html = response.content
	items=re.findall(l1l1ll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡪࡰ࡮ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䇾"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l1l1l1_l1_ + link.replace(l1l1ll_l1_ (u"ࠫࡡ࠵ࠧ䇿"),l1l1ll_l1_ (u"ࠬ࠵ࠧ䈀"))
			if l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䈁") in url: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䈂"),menu_name+l1l1ll_l1_ (u"ࠨใํ่๊ࠦࠧ䈃")+title,url,33)
			elif l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ䈄") in url:
				url = url.replace(l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䈅"),l1l1ll_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࠪ䈆"))
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䈇"),menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ࠥ࠭䈈")+title,url+l1l1ll_l1_ (u"ࠧ࠰࠳ࠪ䈉"),32)
	count=re.findall(l1l1ll_l1_ (u"ࠨࠤࡷࡳࡹࡧ࡬ࠣ࠼ࠫ࠲࠯ࡅࠩࡾࠩ䈊"),html,re.DOTALL)
	if count:
		pages = int(  (int(count[0])+9)   /10 )+1
		for l1ll1lll1_l1_ in range(1,pages):
			l1ll1lll1_l1_ = str(l1ll1lll1_l1_)
			if l1ll1lll1_l1_!=page:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䈋"),l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ䈌")+l1ll1lll1_l1_,l1l1ll_l1_ (u"ࠫࠬ䈍"),39,l1l1ll_l1_ (u"ࠬ࠭䈎"),l1ll1lll1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨ䈏")+type,search)
	return
def l1ll1l11l_l1_():
	link = l1l1ll_l1_ (u"ࠧࡢࡊࡕ࠴ࡨࡊ࡯ࡷࡎ࠵ࡨࡿࡪࡈࡋ࡮࡜࡛࠵࠶ࡌ࡯ࡄ࡫ࡦࡲ࡜࠰ࡍ࡯ࡑࡺࡑࡳ࡬ࡴࡎ࠵࡚ࡰࡠ࠲ࡗࡨ࡜࡛ࡏࡿࡌ࠳ࡪ࡫ࡦࡌࡌࡕࡗ࡫࠼ࡻࡧࡍࡆ࠶ࡤࡊࡰࡿࡪࡃ࠶ࡶࡐ࠷࡚࠺ࠧ䈐")
	link = base64.b64decode(link)
	link = link.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䈑"))
	PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䈒"))
	return
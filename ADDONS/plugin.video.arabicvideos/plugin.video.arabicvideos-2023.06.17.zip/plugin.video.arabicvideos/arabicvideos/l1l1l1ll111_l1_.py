# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ㇢")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡑࡘ࡚ࡠࠩ㇣")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭㇤"),l1l1ll_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭㇥"),l1l1ll_l1_ (u"࠭วๅษๅืฬ๋ࠧ㇦"),l1l1ll_l1_ (u"ฺࠧำูࠤฬ๊ๅำ์าࠫ㇧")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l11l1l_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l11_l1_(url,text)
	elif mode==704: results = l1ll1l_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ㇨"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ㇩"),l1l1ll_l1_ (u"ࠪࠫ㇪"),l1l1ll_l1_ (u"ࠫࠬ㇫"),l1l1ll_l1_ (u"ࠬ࠭㇬"),l1l1ll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㇭"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㇮"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㇯"),l1l1ll_l1_ (u"ࠩࠪㇰ"),709,l1l1ll_l1_ (u"ࠪࠫㇱ"),l1l1ll_l1_ (u"ࠫࠬㇲ"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩㇳ"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫㇴ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧㇵ"),l1l1ll_l1_ (u"ࠨࠩㇶ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㇷ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬㇸ")+menu_name+l1l1ll_l1_ (u"๊๋๊ࠫำࠩㇹ"),l1l1l1_l1_,701,l1l1ll_l1_ (u"ࠬ࠭ㇺ"),l1l1ll_l1_ (u"࠭ࠧㇻ"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩㇼ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㇽ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫㇾ")+menu_name+l1l1ll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩㇿ"),l1l1l1_l1_,701,l1l1ll_l1_ (u"ࠫࠬ㈀"),l1l1ll_l1_ (u"ࠬ࠭㈁"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㈂"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈃"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㈄")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ㈅"),l1l1l1_l1_,701,l1l1ll_l1_ (u"ࠪࠫ㈆"),l1l1ll_l1_ (u"ࠫࠬ㈇"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ㈈"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈉"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㈊")+menu_name+l1l1ll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ㈋"),l1l1l1_l1_,701,l1l1ll_l1_ (u"ࠩࠪ㈌"),l1l1ll_l1_ (u"ࠪࠫ㈍"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭㈎"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㈏"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈐"),l1l1ll_l1_ (u"ࠧࠨ㈑"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧ㈒"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ㈓"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l1l1ll_l1_ (u"ࠪࡀࡧࡄࠧ㈔"),l1l1ll_l1_ (u"ࠫࠬ㈕")).strip(l1l1ll_l1_ (u"ࠬࠦࠧ㈖"))
		if title in l1ll11_l1_: continue
		if link.endswith(l1l1ll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠬ㈗")): continue
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈘"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㈙")+menu_name+title,link,704)
	#addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㈚"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈛"),l1l1ll_l1_ (u"ࠫࠬ㈜"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ㈝"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ㈞"),html,re.DOTALL)
	#for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠧࠨ㈟"))
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫ㈠"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	title = title.replace(l1l1ll_l1_ (u"ࠩ࠿ࡦࡃ࠭㈡"),l1l1ll_l1_ (u"ࠪࠫ㈢")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭㈣"))
	#	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㈤"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㈥")+menu_name+title,link,704)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㈦"),url,l1l1ll_l1_ (u"ࠨࠩ㈧"),l1l1ll_l1_ (u"ࠩࠪ㈨"),l1l1ll_l1_ (u"ࠪࠫ㈩"),l1l1ll_l1_ (u"ࠫࠬ㈪"),l1l1ll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㈫"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡲࡰ࡮ࡨࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㈬"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ㈭"),l1l1ll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ㈮"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㈯"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠪࠫ㈰"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㈱"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈲"),l1l1ll_l1_ (u"࠭ࠧ㈳"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㈴"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠨ࠼ࠣࠫ㈵")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈶"),menu_name+title,link,701)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㈷"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭㈸"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㈹"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈺"),l1l1ll_l1_ (u"ࠧࠨ㈻"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈼"),menu_name+title,link,701)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠩࠪ㈽")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㈾"),l1l1ll_l1_ (u"ࠫࠬ㈿"),request,url)
	if request==l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ㉀"):
		url,search = url.split(l1l1ll_l1_ (u"࠭࠿ࠨ㉁"),1)
		data = l1l1ll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭㉂")+search
		headers = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ㉃"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ㉄")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㉅"),url,data,headers,l1l1ll_l1_ (u"ࠫࠬ㉆"),l1l1ll_l1_ (u"ࠬ࠭㉇"),l1l1ll_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ㉈"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㉉"),url,l1l1ll_l1_ (u"ࠨࠩ㉊"),l1l1ll_l1_ (u"ࠩࠪ㉋"),l1l1ll_l1_ (u"ࠪࠫ㉌"),l1l1ll_l1_ (u"ࠫࠬ㉍"),l1l1ll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ㉎"))
	html = response.content
	block,items = l1l1ll_l1_ (u"࠭ࠧ㉏"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ㉐"))
	if request==l1l1ll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭㉑"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㉒"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠪࠫ㉓"),link,title))
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㉔"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㉕"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ㉖"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㉗"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ㉘"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㉙"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㉚"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡨࡡࠡ࡯ࡪࡦࠥࡺࡡࡣ࡮ࡨࠤ࡫ࡻ࡬࡭ࠤࠫ࠲࠯ࡅࠩࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫ㉛"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㉜"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"࠭ࠧ㉝"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㉞"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㉟"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩ㉠"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨ㉡"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪ㉢"),l1l1ll_l1_ (u"้ࠬไ๋สࠪ㉣"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬ㉤"),l1l1ll_l1_ (u"่ࠧัสๅࠬ㉥"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨ㉦"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭㉧"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪ㉨"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪ㉩"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬ㉪")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"࠭࠯ࠨ㉫"))
		#if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ㉬") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪ㉭")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ㉮"))
		#if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㉯") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭㉰")+img.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ㉱"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ㉲"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ㉳"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㉴"),menu_name+title,link,702,img)
		elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㉵"):
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㉶"),menu_name+title,link,702,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㉷") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㉸"),menu_name+title,link,703,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ㉹") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉺"),menu_name+title,link,701,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㉻"),menu_name+title,link,703,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ㉼"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㉽")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㉾"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㉿"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"࠭ࠣࠨ㊀"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ㊁")+link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ㊂"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㊃"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ㊄")+title,link,701)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㊅"),l1l1ll_l1_ (u"ࠬ࠭㊆"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ㊇"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㊈"),url,l1l1ll_l1_ (u"ࠨࠩ㊉"),l1l1ll_l1_ (u"ࠩࠪ㊊"),l1l1ll_l1_ (u"ࠪࠫ㊋"),l1l1ll_l1_ (u"ࠫࠬ㊌"),l1l1ll_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㊍"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ㊎"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㊏"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠨࠩ㊐")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ㊑"),block,re.DOTALL)
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭㊒"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠫࠨ࠭㊓"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㊔"),menu_name+title,url,703,img,l1l1ll_l1_ (u"࠭ࠧ㊕"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ㊖"),html,re.DOTALL)
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ㊗"),str(l1lll11_l1_))
	block = l1lll11_l1_[0]
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ㊘")+l1lll_l1_+l1l1ll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㊙"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ㊚")+l1lll_l1_+l1l1ll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㊛"),block,re.DOTALL)
	if not l1ll1l1_l1_: l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪ㊜")+l1lll_l1_+l1l1ll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㊝"),block,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢ㊞"),block,re.DOTALL)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㊟"),l1l1ll_l1_ (u"ࠪࠫ㊠"),l1l1ll_l1_ (u"ࠫࠬ㊡"),l1l1ll_l1_ (u"ࠬ࠸࠲࠳࠴࠵ࠫ㊢"))
		if not l1lll1l_l1_: l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ㊣"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㊤"),block,re.DOTALL)
		for link,title,img in items:
			link = link.strip(l1l1ll_l1_ (u"ࠨ࠰࠲ࠫ㊥"))
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ㊦")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ㊧"))
			title = title.replace(l1l1ll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩ㊨"),l1l1ll_l1_ (u"ࠬࠦࠧ㊩"))
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㊪"),menu_name+title,link,702,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ㊫"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭㊬") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫ㊭")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ㊮"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㊯"),menu_name+title,link,702,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	url2 = url.replace(l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㊰"),l1l1ll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠳ࡶࡨࡱࠩ㊱"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㊲"),url2,l1l1ll_l1_ (u"ࠨࠩ㊳"),l1l1ll_l1_ (u"ࠩࠪ㊴"),l1l1ll_l1_ (u"ࠪࠫ㊵"),l1l1ll_l1_ (u"ࠫࠬ㊶"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㊷"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ㊸"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		# l1l1l1l11_l1_ link
		link = re.findall(l1l1ll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㊹"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩ㊺"))
			l11l1_l1_.append(link)
		# l11lllll1_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠤࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠥ㊻"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬ㊼"))
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㊽")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㊾"))
				l11l1_l1_.append(link)
		# download l1ll_l1_
		#l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㊿"),block,re.DOTALL)
		#for link,title in l1ll_l1_:
		#	if link not in l11l1_l1_:
		#		title = title.strip(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ㋀"))
		#		l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㋁")+title+l1l1ll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㋂"))
		#		l11l1_l1_.append(link)
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ㋃"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㋄"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠬ࠭㋅"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"࠭ࠧ㋆"): return
	search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ㋇"),l1l1ll_l1_ (u"ࠨ࠭ࠪ㋈"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪ㋉")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ㋊"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨ㋋")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ㋌"))
	return
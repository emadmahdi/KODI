# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪࠀ")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡁࡉࡍࡢࠫࠁ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨࠂ"),l1l1ll_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨࠃ")]
def MAIN(mode,url,text):
	if   mode==610: results = MENU()
	elif mode==611: results = l11l1l_l1_(url,text)
	elif mode==612: results = PLAY(url)
	elif mode==613: results = l11_l1_(url,text)
	elif mode==614: results = l1ll1l_l1_(url)
	elif mode==619: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬࠄ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪࠅ"),l1l1ll_l1_ (u"ࠪࠫࠆ"),l1l1ll_l1_ (u"ࠫࠬࠇ"),l1l1ll_l1_ (u"ࠬ࠭ࠈ"),l1l1ll_l1_ (u"࠭ࡁࡉ࡙ࡄࡏ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧࠉ"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠊ"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨࠋ"),l1l1ll_l1_ (u"ࠩࠪࠌ"),619,l1l1ll_l1_ (u"ࠪࠫࠍ"),l1l1ll_l1_ (u"ࠫࠬࠎ"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠏ"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫࠐ"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠑ"),l1l1ll_l1_ (u"ࠨࠩࠒ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠓ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬࠔ")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬࠕ"),l1l1l1_l1_,611,l1l1ll_l1_ (u"ࠬ࠭ࠖ"),l1l1ll_l1_ (u"࠭ࠧࠗ"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ࠘"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࠙"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫࠚ")+menu_name+l1l1ll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩࠛ"),l1l1l1_l1_,611,l1l1ll_l1_ (u"ࠫࠬࠜ"),l1l1ll_l1_ (u"ࠬ࠭ࠝ"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬࠞ"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠟ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪࠠ")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨࠡ"),l1l1l1_l1_,611,l1l1ll_l1_ (u"ࠪࠫࠢ"),l1l1ll_l1_ (u"ࠫࠬࠣ"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩࠤ"))
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠥ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩࠦ")+menu_name+l1l1ll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬࠧ"),l1l1l1_l1_,611,l1l1ll_l1_ (u"ࠩࠪࠨ"),l1l1ll_l1_ (u"ࠪࠫࠩ"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ࠪ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪࠫ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬ"),l1l1ll_l1_ (u"ࠧࠨ࠭"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭࠮"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ࠯"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࠰"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࠱")+menu_name+title,link,614)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ࠲"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠳"),l1l1ll_l1_ (u"ࠧࠨ࠴"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ࠵"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ࠶"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠪࠫ࠷"))
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ࠸"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࠹"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠺")+menu_name+title,link,614)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ࠻"),url,l1l1ll_l1_ (u"ࠨࠩ࠼"),l1l1ll_l1_ (u"ࠩࠪ࠽"),l1l1ll_l1_ (u"ࠪࠫ࠾"),l1l1ll_l1_ (u"ࠫࠬ࠿"),l1l1ll_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩࡀ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪࡁ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨࡂ"),l1l1ll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧࡃ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࡄ"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠪࠫࡅ"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩࡆ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡇ"),l1l1ll_l1_ (u"࠭ࠧࡈ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬࡉ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠨ࠼ࠣࠫࡊ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࡋ"),menu_name+title,link,611)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧࡌ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ࡍ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪࡎ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡏ"),l1l1ll_l1_ (u"ࠧࠨࡐ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࡑ"),menu_name+title,link,611)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠩࠪࡒ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫࡓ"),l1l1ll_l1_ (u"ࠫࠬࡔ"),request,url)
	if request==l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪࡕ"):
		url,search = url.split(l1l1ll_l1_ (u"࠭࠿ࠨࡖ"),1)
		data = l1l1ll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ࡗ")+search
		headers = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࡘ"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹࡙ࠩ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ࡚"),url,data,headers,l1l1ll_l1_ (u"࡛ࠫࠬ"),l1l1ll_l1_ (u"ࠬ࠭࡜"),l1l1ll_l1_ (u"࠭ࡁࡉ࡙ࡄࡏ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ࡝"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ࡞"),url,l1l1ll_l1_ (u"ࠨࠩ࡟"),l1l1ll_l1_ (u"ࠩࠪࡠ"),l1l1ll_l1_ (u"ࠪࠫࡡ"),l1l1ll_l1_ (u"ࠫࠬࡢ"),l1l1ll_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨࡣ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"࠭ࠧࡤ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫࡥ"))
	if request==l1l1ll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ࡦ"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫࡧ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠪࠫࡨ"),link,title))
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ࡩ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࡪ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࡫"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࡬"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ࡭"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࡮"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ࡯"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ࡰ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧࡱ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"࠭ࠧࡲ"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࡳ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩࡴ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩࡵ"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨࡶ"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪࡷ"),l1l1ll_l1_ (u"้ࠬไ๋สࠪࡸ"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬࡹ"),l1l1ll_l1_ (u"่ࠧัสๅࠬࡺ"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨࡻ"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭ࡼ"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪࡽ"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪࡾ"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬࡿ")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"࠭࠯ࠨࢀ"))
		#if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬࢁ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪࢂ")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫࢃ"))
		#if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨࢄ") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭ࢅ")+img.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧࢆ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨࢇ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ࢈"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧࢉ"),menu_name+title,link,612,img)
		elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࢊ"):
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩࢋ"),menu_name+title,link,612,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪࢌ") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࢍ"),menu_name+title,link,613,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫࢎ") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࢏"),menu_name+title,link,611,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࢐"),menu_name+title,link,613,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࢑"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ࢒")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࢓"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ࢔"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"࠭ࠣࠨ࢕"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ࢖")+link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪࢗ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࢘"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษ࢙ࠡࠩ")+title,link,611)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"࢚ࠫࠬ"),l1l1ll_l1_ (u"࢛ࠬ࠭"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ࢜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ࢝"),url,l1l1ll_l1_ (u"ࠨࠩ࢞"),l1l1ll_l1_ (u"ࠩࠪ࢟"),l1l1ll_l1_ (u"ࠪࠫࢠ"),l1l1ll_l1_ (u"ࠫࠬࢡ"),l1l1ll_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪࢢ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩࢣ"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢤ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠨࠩࢥ")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩࢦ"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠪࠧࠬࢧ"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࢨ"),menu_name+title,url,613,img,l1l1ll_l1_ (u"ࠬ࠭ࢩ"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࠫࢪ")+l1lll_l1_+l1l1ll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬࢫ"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢࢬ"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢭ"),block,re.DOTALL)
		for link,title,img in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬࢮ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ࢯ"))
			title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪࢰ"),l1l1ll_l1_ (u"࠭ࠠࠨࢱ"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ࢲ"),menu_name+title,link,612,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩࢳ"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧࢴ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬࢵ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ࢶ"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫࢷ"),menu_name+title,link,612,img)
	return
def PLAY(url):
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪࢸ"))
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫࢹ"),url,l1l1ll_l1_ (u"ࠨࠩࢺ"),l1l1ll_l1_ (u"ࠩࠪࢻ"),l1l1ll_l1_ (u"ࠪࠫࢼ"),l1l1ll_l1_ (u"ࠫࠬࢽ"),l1l1ll_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࢾ"))
	html = response.content
	# l111l1_l1_ page
	link = re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢿ"),html,re.DOTALL)
	link = link[0]
	l111ll_l1_ = link.split(l1l1ll_l1_ (u"ࠧࡱࡱࡶࡸࡂ࠭ࣀ"))[1]
	l111ll_l1_ = base64.b64decode(l111ll_l1_)
	if kodi_version>18.99: l111ll_l1_ = l111ll_l1_.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ࣁ"))
	l111ll_l1_ = l111ll_l1_.replace(l1l1ll_l1_ (u"ࠩ࡟࠳ࠬࣂ"),l1l1ll_l1_ (u"ࠪ࠳ࠬࣃ"))
	l111ll_l1_ = EVAL(l1l1ll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩࣄ"),l111ll_l1_)
	l1ll_l1_ = l111ll_l1_[l1l1ll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭ࣅ")]
	titles = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	zzz = zip(titles,l1ll_l1_)
	for title,link in zzz:
		link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧࣆ")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨࣇ")
		l11l1_l1_.append(link)
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠩࡩࡧࠢ࡯࡭ࡳࡱࠠࡢࡰࡧࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪ࠯ࡱ࡯࡮࡬ࠌࠌ࡬ࡦࡹࡨࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨࡪࡤࡷ࡭ࡃࠧࠪ࡝࠴ࡡࠏࠏࡰࡢࡴࡷࡷࠥࡃࠠࡩࡣࡶ࡬࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࠨࠫࠍࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡱࡣࡵࡸࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫࡴࡦࡸࡴࠬࠩࡀࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡵࡧࡲࡵࠢࡀࠤࡵࡧࡲࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡳࡥࡷࡺࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣࡾࡿࢀ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠲࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࡀࡂࠥ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨࣈ")
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧࣉ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ࣊"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ࣋"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭࣌"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ࣍"),l1l1ll_l1_ (u"ࠧࠬࠩ࣎"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾࣏ࠩ")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩ࣐ࠩ"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࣑ࠧ")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࣒ࠩ"))
	return
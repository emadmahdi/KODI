# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ⺱")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ⺲")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1l111lll1_l1_ = WEBSITES[script_name][1]
l1l1lllll11_l1_ = WEBSITES[script_name][2]
l1l1llllll1_l1_ = WEBSITES[script_name][3]
#l1ll1111l11_l1_  = WEBSITES[script_name][4]
#l1ll1111l11_l1_  = WEBSITES[script_name][0]
def MAIN(mode,url,page,text):
	if   mode==20: results = l1l1lllllll_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l11l1l_l1_(url,page)
	elif mode==23: results = l11ll1l_l1_(url,page)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l1lll1l11_l1_(url)
	elif mode==27: results = l1ll1l11l_l1_(url)
	elif mode==28: results = l1ll11111l1_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l1lllllll_l1_():
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⺳"),menu_name+l1l1ll_l1_ (u"ฺࠧำห๎ࠬ⺴"),l1l1l1_l1_,21,l1l1ll_l1_ (u"ࠨࠩ⺵"),l1l1ll_l1_ (u"ࠩ࠴࠴࠶࠭⺶"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺷"),menu_name+l1l1ll_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⺸"),l1l111lll1_l1_,21,l1l1ll_l1_ (u"ࠬ࠭⺹"),l1l1ll_l1_ (u"࠭࠱࠱࠳ࠪ⺺"))
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺻"),menu_name+l1l1ll_l1_ (u"ࠨใสีุ๏ࠧ⺼"),l1l1lllll11_l1_,21,l1l1ll_l1_ (u"ࠩࠪ⺽"),l1l1ll_l1_ (u"ࠪ࠵࠵࠷ࠧ⺾"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺿"),menu_name+l1l1ll_l1_ (u"ࠬ็วาี์ࠤ࠷࠭⻀"),l1l1llllll1_l1_,21,l1l1ll_l1_ (u"࠭ࠧ⻁"),l1l1ll_l1_ (u"ࠧ࠲࠲࠴ࠫ⻂"))
	return
def l1ll11111l1_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⻃"),menu_name+l1l1ll_l1_ (u"ࠩ฼ีอ๐ࠧ⻄"),l1l1l1_l1_,27)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⻅"),menu_name+l1l1ll_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⻆"),l1l111lll1_l1_,27)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩࡷࡧࠪ⻇"),menu_name+l1l1ll_l1_ (u"࠭แศำึํࠬ⻈"),l1l1lllll11_l1_,27)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⻉"),menu_name+l1l1ll_l1_ (u"ࠨใสีุ๏ࠠ࠳ࠩ⻊"),l1l1llllll1_l1_,27)
	return
def MENU(l1ll11111ll_l1_):
	script_name = l1ll11111ll_l1_
	if l1ll11111ll_l1_==l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ⻋"): l1ll11111ll_l1_ = l1l1l1_l1_
	elif l1ll11111ll_l1_==l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ⻌"): l1ll11111ll_l1_ = l1l111lll1_l1_
	else: script_name = l1l1ll_l1_ (u"ࠫࠬ⻍")
	lang = l1ll1111l1l_l1_(l1ll11111ll_l1_)
	if lang==l1l1ll_l1_ (u"ࠬࡧࡲࠨ⻎") or script_name==l1l1ll_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ⻏"):
		l1l1lll1l1l_l1_ = l1l1ll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⻐")
		name1 = l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤาอไ๋หࠪ⻑")
		name2 = l1l1ll_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษอะอࠪ⻒")
		l1l1lll1ll1_l1_ = l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤ࠲ࠦรษฮา๎ࠬ⻓")
		l1l1llll111_l1_ = l1l1ll_l1_ (u"ࠫอัࠠฮ์ࠣฦ๏ࠦแ๋ๆ่ࠫ⻔")
		l1l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠬษแๅษ่ࠫ⻕")
		l1l1llll1l1_l1_ = l1l1ll_l1_ (u"࠭ๅ้ีํๆ๎࠭⻖")
		l1l1llll11l_l1_ = l1l1ll_l1_ (u"ࠧษำส้ั࠭⻗")
	elif lang==l1l1ll_l1_ (u"ࠨࡧࡱࠫ⻘") or script_name==l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⻙"):
		l1l1lll1l1l_l1_ = l1l1ll_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣ࡭ࡳࠦࡳࡪࡶࡨࠫ⻚")
		name1 = l1l1ll_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡃࡶࡴࡵࡩࡳࡺࠧ⻛")
		name2 = l1l1ll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡍࡣࡷࡩࡸࡺࠧ⻜")
		l1l1lll1ll1_l1_ = l1l1ll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠭ࠡࡃ࡯ࡴ࡭ࡧࡢࡦࡶࠪ⻝")
		l1l1llll111_l1_ = l1l1ll_l1_ (u"ࠧࡍ࡫ࡹࡩࠥ࡯ࡆࡪ࡮ࡰࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠬ⻞")
		l1l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠨࡏࡲࡺ࡮࡫ࡳࠨ⻟")
		l1l1llll1l1_l1_ = l1l1ll_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⻠")
		l1l1llll11l_l1_ = l1l1ll_l1_ (u"ࠪࡗ࡭ࡵࡷࡴࠩ⻡")
	elif lang in [l1l1ll_l1_ (u"ࠫ࡫ࡧࠧ⻢"),l1l1ll_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⻣")]:
		l1l1lll1l1l_l1_ = l1l1ll_l1_ (u"࠭ฬิฬฯ์ࠥีัࠡีส໐ฯ࠭⻤")
		name1 = l1l1ll_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฮสี໑࠭⻥")
		name2 = l1l1ll_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢลาึ໒ๆࠨ⻦")
		l1l1lll1ll1_l1_ = l1l1ll_l1_ (u"ࠩึี๏อไࠡ࠯ࠣห้็ศศࠩ⻧")
		l1l1llll111_l1_ = l1l1ll_l1_ (u"ࠪຂำฺࠠำ่า๋ࠥอ๊ࠡใํ่๊࠭⻨")
		l1l1lll1lll_l1_ = l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩ⻩")
		l1l1llll1l1_l1_ = l1l1ll_l1_ (u"๋่ࠬิ์ๅํࠬ⻪")
		l1l1llll11l_l1_ = l1l1ll_l1_ (u"࠭ศา่ส้์ࠦ็ศࠩ⻫")
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻬"),menu_name+l1l1lll1l1l_l1_,l1ll11111ll_l1_,29,l1l1ll_l1_ (u"ࠨࠩ⻭"),l1l1ll_l1_ (u"ࠩࠪ⻮"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⻯"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⻰"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⻱")+menu_name+l1l1llll111_l1_,l1ll11111ll_l1_,27)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⻲"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠴ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠱࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⻳"),l1l1ll_l1_ (u"ࠨࠩ⻴"),9999)
	l1lll1l11l_l1_ = [l1l1ll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⻵"),l1l1ll_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⻶"),l1l1ll_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⻷")]
	html = OPENURL_CACHED(l11l1ll_l1_,l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡨࡰ࡯ࡨࠫ⻸"),l1l1ll_l1_ (u"࠭ࠧ⻹"),l1l1ll_l1_ (u"ࠧࠨ⻺"),l1l1ll_l1_ (u"ࠨࠩ⻻"),l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⻼"))
	l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠪࡦࡺࡺࡴࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮࠵ࡃࡰࡰࡷࡥࡨࡺࠧ⻽"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⻾"),block,re.DOTALL)
		for link,title in items:
			if any(value in link for value in l1lll1l11l_l1_):
				url = l1ll11111ll_l1_+link
				if l1l1ll_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⻿") in link:
					addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼀"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⼁")+menu_name+name1,url,22,l1l1ll_l1_ (u"ࠨࠩ⼂"),l1l1ll_l1_ (u"ࠩ࠴࠴࠵࠭⼃"))
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼄"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⼅")+menu_name+name2,url,22,l1l1ll_l1_ (u"ࠬ࠭⼆"),l1l1ll_l1_ (u"࠭࠱࠱࠳ࠪ⼇"))
					addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼈"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⼉")+menu_name+l1l1lll1ll1_l1_,url,22,l1l1ll_l1_ (u"ࠩࠪ⼊"),l1l1ll_l1_ (u"ࠪ࠶࠵࠷ࠧ⼋"))
				elif l1l1ll_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⼌") in link: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼍"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼎")+menu_name+l1l1lll1lll_l1_,url,22,l1l1ll_l1_ (u"ࠧࠨ⼏"),l1l1ll_l1_ (u"ࠨ࠳࠳࠴ࠬ⼐"))
				elif l1l1ll_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⼑") in link: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼒"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⼓")+menu_name+l1l1llll1l1_l1_,url,25,l1l1ll_l1_ (u"ࠬ࠭⼔"),l1l1ll_l1_ (u"࠭࠱࠱࠳ࠪ⼕"))
				elif l1l1ll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⼖") in link: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼗"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⼘")+menu_name+l1l1llll11l_l1_,url,22,l1l1ll_l1_ (u"ࠪࠫ⼙"),l1l1ll_l1_ (u"ࠫ࠶࠶࠱ࠨ⼚"))
	return html
def l1l1lll1l11_l1_(url):
	l1ll11111ll_l1_ = l1l1llll1ll_l1_(url)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠬ࠭⼛"),l1l1ll_l1_ (u"࠭ࠧ⼜"),l1l1ll_l1_ (u"ࠧࠨ⼝"),l1l1ll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡗࡖࡍࡈࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⼞"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡐࡹࡸ࡯ࡣ࠮ࡶࡲࡳࡱࡹ࠭ࡩࡧࡤࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡒࡻࡳࡪࡥ࠰ࡦࡴࡪࡹࠨ⼟"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	title = re.findall(l1l1ll_l1_ (u"ࠪࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩ⼠"),block,re.DOTALL)[0]
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼡"),menu_name+title,url,22,l1l1ll_l1_ (u"ࠬ࠭⼢"),l1l1ll_l1_ (u"࠭࠱࠱࠳ࠪ⼣"))
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⼤"),block,re.DOTALL)
	for link,title in items:
		link = l1ll11111ll_l1_ + link
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼥"),menu_name+title,link,23,l1l1ll_l1_ (u"ࠩࠪ⼦"),l1l1ll_l1_ (u"ࠪ࠵࠵࠷ࠧ⼧"))
	return
def l11l1l_l1_(url,page):
	l1ll11111ll_l1_ = l1l1llll1ll_l1_(url)
	lang = l1ll1111l1l_l1_(url)
	type = url.split(l1l1ll_l1_ (u"ࠫ࠴࠭⼨"))[-1]
	l1l1lll111l_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭⼩"),l1l1ll_l1_ (u"࠭ࠧ⼪"),url, type)
	if type==l1l1ll_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⼫") and page==l1l1ll_l1_ (u"ࠨ࠲ࠪ⼬"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠩࠪ⼭"),l1l1ll_l1_ (u"ࠪࠫ⼮"),l1l1ll_l1_ (u"ࠫࠬ⼯"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⼰"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠳ࡢࡰࡦࡼࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡲࡻࠬ⼱"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂ࠮࠮ࠫࡁࠬࡂ࠳࠰࠿ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⼲"),block,re.DOTALL)
		for link,img,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			link = l1ll11111ll_l1_ + link
			img = l1ll11111ll_l1_ + QUOTE(img)
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⼳"),menu_name+title,link,23,img,l1l1lll111l_l1_+l1l1ll_l1_ (u"ࠩ࠳࠵ࠬ⼴"))
	l1l1lll11l1_l1_=0
	if type==l1l1ll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⼵"): category=l1l1ll_l1_ (u"ࠫ࠸࠭⼶")
	if type==l1l1ll_l1_ (u"ࠬࡌࡩ࡭࡯ࠪ⼷"): category=l1l1ll_l1_ (u"࠭࠵ࠨ⼸")
	if type==l1l1ll_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⼹"): category=l1l1ll_l1_ (u"ࠨ࠹ࠪ⼺")
	if type in [l1l1ll_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⼻"),l1l1ll_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⼼"),l1l1ll_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⼽")] and page!=l1l1ll_l1_ (u"ࠬ࠶ࠧ⼾"):
		url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡖࡡࡨࡧ࡬ࡲ࡬ࡏࡴࡦ࡯ࡂࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭⼿")+category+l1l1ll_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ⽀")+page+l1l1ll_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡳࡷࡪࡥࡳࡤࡼࡁࠬ⽁")+l1l1lll111l_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠩࠪ⽂"),l1l1ll_l1_ (u"ࠪࠫ⽃"),l1l1ll_l1_ (u"ࠫࠬ⽄"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⽅"))
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⽆"),l1l1ll_l1_ (u"ࠧࠨ⽇"),url2, html)
		items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠫࡀࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⽈"),html,re.DOTALL)
		for id,title,img in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡠࠬ⽉"),l1l1ll_l1_ (u"ࠪࠫ⽊"))
			title = title.replace(l1l1ll_l1_ (u"ࠫࠧ࠭⽋"),l1l1ll_l1_ (u"ࠬ࠭⽌"))
			l1l1lll11l1_l1_ += 1
			link = l1ll11111ll_l1_ + l1l1ll_l1_ (u"࠭࠯ࠨ⽍") + type + l1l1ll_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ⽎") + id
			img = l1ll11111ll_l1_ + QUOTE(img)
			if type==l1l1ll_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⽏"): addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⽐"),menu_name+title,link,24,img,l1l1lll111l_l1_+l1l1ll_l1_ (u"ࠪ࠴࠶࠭⽑"))
			else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⽒"),menu_name+title,link,23,img,l1l1lll111l_l1_+l1l1ll_l1_ (u"ࠬ࠶࠱ࠨ⽓"))
	if type==l1l1ll_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⽔"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡊࡰࡧࡩࡽࡅࡰࡢࡩࡨࡁࠬ⽕")+page,l1l1ll_l1_ (u"ࠨࠩ⽖"),l1l1ll_l1_ (u"ࠩࠪ⽗"),l1l1ll_l1_ (u"ࠪࠫ⽘"),l1l1ll_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧ⽙"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯࠯ࡧࡩࡲࡵࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠭⽚"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⽛"),block,re.DOTALL)
		for link,img,title in items:
			l1l1lll11l1_l1_ += 1
			img = l1ll11111ll_l1_ + img
			link = l1ll11111ll_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⽜"),menu_name+title,link,23,img,l1l1ll_l1_ (u"ࠨ࠳࠳࠵ࠬ⽝"))
	if l1l1lll11l1_l1_>20:
		title=l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ⽞")
		if lang==l1l1ll_l1_ (u"ࠪࡩࡳ࠭⽟"): title = l1l1ll_l1_ (u"ࠫࡕࡧࡧࡦࠢࠪ⽠")
		if lang==l1l1ll_l1_ (u"ࠬ࡬ࡡࠨ⽡"): title = l1l1ll_l1_ (u"࠭ีโฯ๊ࠤࠬ⽢")
		if lang==l1l1ll_l1_ (u"ࠧࡧࡣ࠵ࠫ⽣"): title = l1l1ll_l1_ (u"ࠨืไั์ࠦࠧ⽤")
		for l1l1lllll1l_l1_ in range(1,11) :
			if not page==str(l1l1lllll1l_l1_):
				l1l1lll11ll_l1_ = l1l1ll_l1_ (u"ࠩ࠳ࠫ⽥")+str(l1l1lllll1l_l1_)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⽦"),menu_name+title+str(l1l1lllll1l_l1_),url,22,l1l1ll_l1_ (u"ࠫࠬ⽧"),l1l1lll111l_l1_+l1l1lll11ll_l1_[-2:])
	return
def l11ll1l_l1_(url,page):
	if not page: page = 0
	l1ll11111ll_l1_ = l1l1llll1ll_l1_(url)
	l1ll1111l11_l1_ = l1l1llll1ll_l1_(url)
	lang = l1ll1111l1l_l1_(url)
	parts = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ⽨"))
	id,type = parts[-1],parts[3]
	l1l1lll111l_l1_ = str(int(page)//100)
	page = str(int(page)%100)
	l1l1lll11l1_l1_ = 0
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⽩"),l1l1ll_l1_ (u"ࠧࠨ⽪"),url, type)
	if type==l1l1ll_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⽫"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠩࠪ⽬"),l1l1ll_l1_ (u"ࠪࠫ⽭"),l1l1ll_l1_ (u"ࠫࠬ⽮"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ⽯"))
		items = re.findall(l1l1ll_l1_ (u"࠭ࡃࡰ࡯ࡰࡩࡳࡺ࡟ࡱࡣࡱࡩࡱࡥࡉࡵࡧࡰ࠲࠯ࡅࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࡪ࠰࠮ࡃࡻࡧࡲࠡ࡫ࡱࡸࡪࡸ࡟ࠡ࠿ࠣࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩࠪ⽰"),html,re.DOTALL)
		title = l1l1ll_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ⽱")
		if lang==l1l1ll_l1_ (u"ࠨࡧࡱࠫ⽲"): title = l1l1ll_l1_ (u"ࠩࠣ࠱ࠥࡋࡰࡪࡵࡲࡨࡪࠦࠧ⽳")
		if lang==l1l1ll_l1_ (u"ࠪࡪࡦ࠭⽴"): title = l1l1ll_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⽵")
		if lang==l1l1ll_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⽶"): title = l1l1ll_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⽷")
		if lang==l1l1ll_l1_ (u"ࠧࡧࡣࠪ⽸"): l1ll1111111_l1_ = l1l1ll_l1_ (u"ࠨࠩ⽹")
		else: l1ll1111111_l1_ = lang
		l1ll1111ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡷ࡫ࡧࡩࡴࡃࠢࠩ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭࡟ࠪࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ⽺"),html,re.DOTALL)
		for name,count,img,link in items:
			for l11111_l1_ in range(int(count),0,-1):
				l1l1lll11_l1_ = img + l1ll1111111_l1_ + id + l1l1ll_l1_ (u"ࠪ࠳ࠬ⽻") + str(l11111_l1_) + l1l1ll_l1_ (u"ࠫ࠳ࡶ࡮ࡨࠩ⽼")
				#l1lll11ll11_l1_ = l1ll1111ll1_l1_[0][0]+lang+id+l1l1ll_l1_ (u"ࠬ࠵ࠬࠨ⽽")+str(l11111_l1_)+l1l1ll_l1_ (u"࠭ࠬࠨ⽾")+str(l11111_l1_)+l1l1ll_l1_ (u"ࠧࡠࠩ⽿")+l1ll1111ll1_l1_[0][2]
				name1 = name + title + str(l11111_l1_)
				name1 = unescapeHTML(name1)
				addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⾀"),menu_name+name1,url,24,l1l1lll11_l1_,l1l1ll_l1_ (u"ࠩࠪ⾁"),str(l11111_l1_))
	elif type==l1l1ll_l1_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ⾂"):
		url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧ࠲ࡔࡦ࡭ࡥࡪࡰࡪࡅࡹࡺࡡࡤࡪࡰࡩࡳࡺࡉࡵࡧࡰࡃ࡮ࡪ࠽ࠨ⾃")+str(id)+l1l1ll_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⾄")+page+l1l1ll_l1_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡱࡵࡨࡪࡸࡢࡺ࠿࠴ࠫ⾅")
		html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠧࠨ⾆"),l1l1ll_l1_ (u"ࠨࠩ⾇"),l1l1ll_l1_ (u"ࠩࠪ⾈"),l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ⾉"))
		items = re.findall(l1l1ll_l1_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡇ࡭ࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⾊"),html,re.DOTALL)
		title = l1l1ll_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ⾋")
		if lang==l1l1ll_l1_ (u"࠭ࡥ࡯ࠩ⾌"): title = l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࡉࡵ࡯ࡳࡰࡦࡨࠤࠬ⾍")
		if lang==l1l1ll_l1_ (u"ࠨࡨࡤࠫ⾎"): title = l1l1ll_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ⾏")
		if lang==l1l1ll_l1_ (u"ࠪࡪࡦ࠸ࠧ⾐"): title = l1l1ll_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⾑")
		for l11111_l1_,img,link,desc,name in items:
			l1l1lll11l1_l1_ += 1
			l1l1lll11_l1_ = l1ll1111l11_l1_ + QUOTE(img)
			#l1lll11ll11_l1_ = l1ll1111l11_l1_ + QUOTE(link)
			name = escapeUNICODE(name)
			name1 = name + title + str(l11111_l1_)
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⾒"),menu_name+name1,url2,24,l1l1lll11_l1_,l1l1ll_l1_ (u"࠭ࠧ⾓"),str(l1l1lll11l1_l1_))
	elif type==l1l1ll_l1_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭⾔"):
		if l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵࠩ⾕") in url and l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⾖") not in url:
			url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡒࡻࡳࡪࡥ࠲ࡋࡪࡺࡔࡳࡣࡦ࡯ࡸࡈࡹࡀ࡫ࡧࡁࠬ⾗")+str(id)+l1l1ll_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ⾘")+page+l1l1ll_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠶ࠧ⾙")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"࠭ࠧ⾚"),l1l1ll_l1_ (u"ࠧࠨ⾛"),l1l1ll_l1_ (u"ࠨࠩ⾜"),l1l1ll_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠷ࡷࡪࠧ⾝"))
			items = re.findall(l1l1ll_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⾞"),html,re.DOTALL)
			for img,link,name,title in items:
				l1l1lll11l1_l1_ += 1
				l1l1lll11_l1_ = l1ll1111l11_l1_ + QUOTE(img)
				#l1lll11ll11_l1_ = l1ll1111l11_l1_ + QUOTE(link)
				name1 = name + l1l1ll_l1_ (u"ࠫࠥ࠳ࠠࠨ⾟") + title
				name1 = name1.strip(l1l1ll_l1_ (u"ࠬࠦࠧ⾠"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⾡"),menu_name+name1,url2,24,l1l1lll11_l1_,l1l1ll_l1_ (u"ࠧࠨ⾢"),str(l1l1lll11l1_l1_))
		elif l1l1ll_l1_ (u"ࠨࡅ࡯࡭ࡵࡹࠧ⾣") in url:
			url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⾤")+page+l1l1ll_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠵࠺࠭⾥")
			html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠫࠬ⾦"),l1l1ll_l1_ (u"ࠬ࠭⾧"),l1l1ll_l1_ (u"࠭ࠧ⾨"),l1l1ll_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠶ࡷ࡬ࠬ⾩"))
			items = re.findall(l1l1ll_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛࡯ࡤࡦࡱࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⾪"),html,re.DOTALL)
			for img,title,link in items:
				l1l1lll11l1_l1_ += 1
				l1l1lll11_l1_ = l1ll1111l11_l1_ + QUOTE(img)
				#l1lll11ll11_l1_ = l1ll1111l11_l1_ + QUOTE(link)
				name1 = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ⾫"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⾬"),menu_name+name1,url2,24,l1l1lll11_l1_,l1l1ll_l1_ (u"ࠫࠬ⾭"),str(l1l1lll11l1_l1_))
		elif l1l1ll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⾮") in url:
			if l1l1ll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠸ࠪ⾯") in url:
				url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾࠲ࠩࡴࡦ࡭ࡥ࠾ࠩ⾰")+page+l1l1ll_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠸ࠪ⾱")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠩࠪ⾲"),l1l1ll_l1_ (u"ࠪࠫ⾳"),l1l1ll_l1_ (u"ࠫࠬ⾴"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠵ࡵࡪࠪ⾵"))
			elif l1l1ll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠶ࠪ⾶") in url:
				url2 = l1ll11111ll_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾࠲ࠩࡴࡦ࡭ࡥ࠾ࠩ⾷")+page+l1l1ll_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠶ࠪ⾸")
				html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠩࠪ⾹"),l1l1ll_l1_ (u"ࠪࠫ⾺"),l1l1ll_l1_ (u"ࠫࠬ⾻"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠶ࡵࡪࠪ⾼"))
			items = re.findall(l1l1ll_l1_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡛ࡵࡩࡤࡧࡄࡨࡩࡸࡥࡴࡵࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡄࡣࡳࡸ࡮ࡵ࡮ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⾽"),html,re.DOTALL)
			for img,link,name,title in items:
				l1l1lll11l1_l1_ += 1
				l1l1lll11_l1_ = l1ll1111l11_l1_ + QUOTE(img)
				#l1lll11ll11_l1_ = l1ll1111l11_l1_ + QUOTE(link)
				name1 = name + l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫ⾾") + title
				name1 = name1.strip(l1l1ll_l1_ (u"ࠨࠢࠪ⾿"))
				name1 = escapeUNICODE(name1)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⿀"),menu_name+name1,url2,24,l1l1lll11_l1_,l1l1ll_l1_ (u"ࠪࠫ⿁"),str(l1l1lll11l1_l1_))
	if type==l1l1ll_l1_ (u"ࠫࡒࡻࡳࡪࡥࠪ⿂") or type==l1l1ll_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⿃"):
		if l1l1lll11l1_l1_>25:
			title=l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ⿄")
			if lang==l1l1ll_l1_ (u"ࠧࡦࡰࠪ⿅"): title = l1l1ll_l1_ (u"ࠨࠢࡓࡥ࡬࡫ࠠࠨ⿆")
			if lang==l1l1ll_l1_ (u"ࠩࡩࡥࠬ⿇"): title = l1l1ll_l1_ (u"ࠪࠤฺ็อ่ࠢࠪ⿈")
			if lang==l1l1ll_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⿉"): title = l1l1ll_l1_ (u"ࠬࠦีโฯ๊ࠤࠬ⿊")
			for l1l1lllll1l_l1_ in range(1,11):
				if not page==str(l1l1lllll1l_l1_):
					l1l1lll11ll_l1_ = l1l1ll_l1_ (u"࠭࠰ࠨ⿋")+str(l1l1lllll1l_l1_)
					addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿌"),menu_name+title+str(l1l1lllll1l_l1_),url,23,l1l1ll_l1_ (u"ࠨࠩ⿍"),l1l1lll111l_l1_+l1l1lll11ll_l1_[-2:])
	return
def PLAY(url,l11111_l1_):
	l1ll1111l11_l1_ = l1l1llll1ll_l1_(url)
	l111l1l_l1_,l11l1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠩࠪ⿎"),l1l1ll_l1_ (u"ࠪࠫ⿏"),l1l1ll_l1_ (u"ࠫࠬ⿐"),l1l1ll_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⿑"))
	# l1ll1_l1_ l11111ll_l1_ l1ll_l1_
	items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱࡀࠦ࠭࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪࡣ࠮࠮࠮ࠫࡁࠬࠦࡃ࠭⿒"),html,re.DOTALL)
	if items:
		lang = l1ll1111l1l_l1_(url)
		parts = url.split(l1l1ll_l1_ (u"ࠧ࠰ࠩ⿓"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+lang+id+l1l1ll_l1_ (u"ࠨ࠱࠯ࠫ⿔")+l11111_l1_+l1l1ll_l1_ (u"ࠩ࠯ࠫ⿕")+l11111_l1_+l1l1ll_l1_ (u"ࠪࡣࠬ⿖")+items[0][2]
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ⿗"))
		l11l1_l1_.append(link)
	# l1ll1_l1_ l11l1111_l1_ url
	items = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬࡡ࠭࠮ࠫࡁ࡟ࠫ࠮࠮࡜࠯࠰࠭ࡃ࠮ࠨࠧ⿘"),html,re.DOTALL)
	if items:
		lang = l1ll1111l1l_l1_(url)
		parts = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ⿙"))
		id,type = parts[-1],parts[3]
		link = items[0][0]+lang+id+l1l1ll_l1_ (u"ࠧ࠰ࠩ⿚")+l11111_l1_+items[0][2]
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠨ࡯ࡳ࠸ࠥࡻࡲ࡭ࠩ⿛"))
		l11l1_l1_.append(link)
	# l1ll1_l1_ l11l1111_l1_ src
	items = re.findall(l1l1ll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿜"),html,re.DOTALL)
	for link in items:
		link = link.replace(l1l1ll_l1_ (u"ࠪ࠳࠴࠭⿝"),l1l1ll_l1_ (u"ࠫ࠴࠭⿞"))
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠬࡳࡰ࠵ࠢࡶࡶࡨ࠭⿟"))
		l11l1_l1_.append(link)
	# l1ll111111l_l1_ l11l1111_l1_ l1ll_l1_
	items = re.findall(l1l1ll_l1_ (u"࠭ࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿠"),html,re.DOTALL)
	if items:
		link = items[int(l11111_l1_)-1]
		link = l1ll1111l11_l1_+QUOTE(link)
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡦࡪࡤࡳࡧࡶࡷࠬ⿡"))
		l11l1_l1_.append(link)
	# l1ll111111l_l1_ l1ll1111lll_l1_ l1ll_l1_
	items = re.findall(l1l1ll_l1_ (u"ࠨࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⿢"),html,re.DOTALL)
	if items:
		link = items[int(l11111_l1_)-1]
		link = l1ll1111l11_l1_+QUOTE(link)
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠩࡰࡴ࠸ࠦࡡࡥࡦࡵࡩࡸࡹࠧ⿣"))
		l11l1_l1_.append(link)
	# selection
	if len(l11l1_l1_)==1: link = l11l1_l1_[0]
	else:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪหำะัࠡษ็ๅ๏ี๊้ࠢส่๊์วิส࠽ࠫ⿤"), l111l1l_l1_)
		if selection == -1 : return
		link = l11l1_l1_[selection]
	PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⿥"))
	return
def l1l1llll1ll_l1_(url):
	if l1l1l1_l1_ in url: site = l1l1l1_l1_
	elif l1l111lll1_l1_ in url: site = l1l111lll1_l1_
	elif l1l1lllll11_l1_ in url: site = l1l1lllll11_l1_
	elif l1l1llllll1_l1_ in url: site = l1l1llllll1_l1_
	else: site = l1l1ll_l1_ (u"ࠬ࠭⿦")
	return site
def l1ll1111l1l_l1_(url):
	if   l1l1l1_l1_ in url: lang = l1l1ll_l1_ (u"࠭ࡡࡳࠩ⿧")
	elif l1l111lll1_l1_ in url: lang = l1l1ll_l1_ (u"ࠧࡦࡰࠪ⿨")
	elif l1l1lllll11_l1_ in url: lang = l1l1ll_l1_ (u"ࠨࡨࡤࠫ⿩")
	elif l1l1llllll1_l1_ in url: lang = l1l1ll_l1_ (u"ࠩࡩࡥ࠷࠭⿪")
	else: lang = l1l1ll_l1_ (u"ࠪࠫ⿫")
	return lang
def l1ll1l11l_l1_(url):
	lang = l1ll1111l1l_l1_(url)
	url2 = url + l1l1ll_l1_ (u"ࠫ࠴ࡎ࡯࡮ࡧ࠲ࡐ࡮ࡼࡥࠨ⿬")
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ⿭"),url2,l1l1ll_l1_ (u"࠭ࠧ⿮"),l1l1ll_l1_ (u"ࠧࠨ⿯"),l1l1ll_l1_ (u"ࠨࠩ⿰"),l1l1ll_l1_ (u"ࠩࠪ⿱"),l1l1ll_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ⿲"))
	html = response.content
	items = re.findall(l1l1ll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⿳"),html,re.DOTALL)
	url3 = items[0]
	PLAY_VIDEO(url3,script_name,l1l1ll_l1_ (u"ࠬࡲࡩࡷࡧࠪ⿴"))
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ⿵"),l1l1ll_l1_ (u"ࠧࠬࠩ⿶"))
	if showDialogs:
		l1lll1l111_l1_ = [ l1l1l1_l1_ , l1l111lll1_l1_ , l1l1lllll11_l1_ , l1l1llllll1_l1_ ]
		l1l1ll11l_l1_ = [ l1l1ll_l1_ (u"ࠨ฻ิฬ๏࠭⿷") , l1l1ll_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠪ⿸") , l1l1ll_l1_ (u"ࠪๅฬืำ๊ࠩ⿹") , l1l1ll_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ⿺") ]
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬอฮหำࠣหฺ้๊สࠢส่๊์วิสฬ࠾ࠬ⿻"), l1l1ll11l_l1_)
		if selection == -1 : return
		website = l1lll1l111_l1_[selection]
	else:
		if l1l1ll_l1_ (u"࠭࡟ࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈࡥࠧ⿼") in options: website = l1l1l1_l1_
		elif l1l1ll_l1_ (u"ࠧࡠࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࡠࠩ⿽") in options: website = l1l111lll1_l1_
		else: website = l1l1ll_l1_ (u"ࠨࠩ⿾")
	if not website: return
	lang = l1ll1111l1l_l1_(website)
	url2 = website + l1l1ll_l1_ (u"ࠤ࠲ࡌࡴࡳࡥ࠰ࡕࡨࡥࡷࡩࡨࡀࡵࡨࡥࡷࡩࡨࡴࡶࡵ࡭ࡳ࡭࠽ࠣ⿿") + l11lll1_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ　"),l1l1ll_l1_ (u"ࠫࠬ、"),lang,url2)
	html = OPENURL_CACHED(REGULAR_CACHE,url2,l1l1ll_l1_ (u"ࠬ࠭。"),l1l1ll_l1_ (u"࠭ࠧ〃"),l1l1ll_l1_ (u"ࠧࠨ〄"),l1l1ll_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ々"))
	items = re.findall(l1l1ll_l1_ (u"ࠩࠥࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱࠭〆"),html,re.DOTALL)
	if items:
		for img,category,id,title in items:
			#if category in [l1l1ll_l1_ (u"ࠪ࠷ࠬ〇"),l1l1ll_l1_ (u"ࠫ࠺࠭〈"),l1l1ll_l1_ (u"ࠬ࠽ࠧ〉")]:
			if category in [l1l1ll_l1_ (u"࠭࠳ࠨ《"),l1l1ll_l1_ (u"ࠧ࠸ࠩ》")]:
				title = title.replace(l1l1ll_l1_ (u"ࠨ࡞࡟ࠫ「"),l1l1ll_l1_ (u"ࠩࠪ」"))
				title = title.replace(l1l1ll_l1_ (u"ࠪࠦࠬ『"),l1l1ll_l1_ (u"ࠫࠬ』"))
				if category==l1l1ll_l1_ (u"ࠬ࠹ࠧ【"):
					type = l1l1ll_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭】")
					if lang==l1l1ll_l1_ (u"ࠧࡢࡴࠪ〒"): name = l1l1ll_l1_ (u"ࠨ็ึุ่๊ࠠ࠻ࠢࠪ〓")
					elif lang==l1l1ll_l1_ (u"ࠩࡨࡲࠬ〔"): name = l1l1ll_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠾ࠥ࠭〕")
					elif lang==l1l1ll_l1_ (u"ࠫ࡫ࡧࠧ〖"): name = l1l1ll_l1_ (u"ูࠬั๋ษ็ࠤ์อࠠ࠻ࠢࠪ〗")
					elif lang==l1l1ll_l1_ (u"࠭ࡦࡢ࠴ࠪ〘"): name = l1l1ll_l1_ (u"ࠧิำํห้ࠦ็ศࠢ࠽ࠤࠬ〙")
				elif category==l1l1ll_l1_ (u"ࠨ࠷ࠪ〚"):
					type = l1l1ll_l1_ (u"ࠩࡉ࡭ࡱࡳࠧ〛")
					if lang==l1l1ll_l1_ (u"ࠪࡥࡷ࠭〜"): name = l1l1ll_l1_ (u"ࠫๆ๐ไๆࠢ࠽ࠤࠬ〝")
					elif lang==l1l1ll_l1_ (u"ࠬ࡫࡮ࠨ〞"): name = l1l1ll_l1_ (u"࠭ࡍࡰࡸ࡬ࡩࠥࡀࠠࠨ〟")
					elif lang==l1l1ll_l1_ (u"ࠧࡧࡣࠪ〠"): name = l1l1ll_l1_ (u"ࠨใํ่๊ࠦ࠺ࠡࠩ〡")
					elif lang==l1l1ll_l1_ (u"ࠩࡩࡥ࠷࠭〢"): name = l1l1ll_l1_ (u"ࠪๅ้๋่ࠠษࠣ࠾ࠥ࠭〣")
				elif category==l1l1ll_l1_ (u"ࠫ࠼࠭〤"):
					type = l1l1ll_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭〥")
					if lang==l1l1ll_l1_ (u"࠭ࡡࡳࠩ〦"): name = l1l1ll_l1_ (u"ࠧษำ้ห๊าࠠ࠻ࠢࠪ〧")
					elif lang==l1l1ll_l1_ (u"ࠨࡧࡱࠫ〨"): name = l1l1ll_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠣ࠾ࠥ࠭〩")
					elif lang==l1l1ll_l1_ (u"ࠪࡪࡦ〪࠭"): name = l1l1ll_l1_ (u"ࠫอืๆศ็๊ࠤ์อࠠ࠻〫ࠢࠪ")
					elif lang==l1l1ll_l1_ (u"ࠬ࡬ࡡ࠳ࠩ〬"): name = l1l1ll_l1_ (u"࠭ศา่ส้์ࠦ็ศࠢ࠽ࠤ〭ࠬ")
				title = name + title
				link = website + l1l1ll_l1_ (u"ࠧ࠰〮ࠩ") + type + l1l1ll_l1_ (u"ࠨ࠱ࡆࡳࡳࡺࡥ࡯ࡶ࠲〯ࠫ") + id
				img = QUOTE(img)
				img = website+img
				#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ〰"),img)
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ〱"),menu_name+title,link,23,img,l1l1ll_l1_ (u"ࠫ࠶࠶࠱ࠨ〲"))
	#else: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭〳"),l1l1ll_l1_ (u"࠭ࠧ〴"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ〵"),,لا توجد نتائج للبحث')
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䒞")
#l11111lll11_l1_ = [ l1l1ll_l1_ (u"ࠫࡲࡿࡳࡵࡴࡨࡥࡲ࠭䒟"),l1l1ll_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬ䒠"),l1l1ll_l1_ (u"࠭ࡶࡪࡦࡥࡳࡲ࠭䒡"),l1l1ll_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ䒢") ]
l11111lll11_l1_ = []
headers = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䒣"):l1l1ll_l1_ (u"ࠩࠪ䒤")}
def l1l_l1_(l111ll1_l1_,source,type,url):
	#DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ีฬฮืࠡษ็้๋อำษࠩ䒥"),l111ll1_l1_)
	if not l111ll1_l1_:
		LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䒦"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ䒧")+source+l1l1ll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ䒨")+type+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ䒩"))
		l111ll111ll_l1_ = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䒪"),l1l1ll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䒫"),l1l1ll_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䒬"))
		datetime = time.strftime(l1l1ll_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ䒭"),time.gmtime(now))
		line = datetime,url
		key = source+l1l1ll_l1_ (u"ࠬࠦࠠࠡࠢࠪ䒮")+addon_version+l1l1ll_l1_ (u"࠭ࠠࠡࠢࠣࠫ䒯")+str(kodi_version)
		if key not in list(l111ll111ll_l1_.keys()): l111ll111ll_l1_[key] = [line]
		else: l111ll111ll_l1_[key].append(line)
		total = 0
		for key in list(l111ll111ll_l1_.keys()):
			l111ll111ll_l1_[key] = list(set(l111ll111ll_l1_[key]))
			total += len(l111ll111ll_l1_[key])
		DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䒰"),l1l1ll_l1_ (u"ࠨࠩ䒱"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䒲"),l1l1ll_l1_ (u"่้ࠪษำโࠢส่อืๆศ็ฯࠤ้๋๋ࠠฮาࠤ๊๊แศฬࠣห้็๊ะ์๋ࠤࡡࡴ࡜࡯ࠢ็่฾๊ๅࠡษ็ฬึ์วๆฮࠣ๎็๎ๅࠡสฯ้฾ࠦโศศ่อࠥฮวๅใํำ๏๎็ศฬࠣห้ะ๊ࠡๆ่ࠤ๏าฯࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ์ุ๎แࠡ์฼ี฻ูࠦๅ์ๆࠤฬ๊ศา่ส้ัࠦร็ࠢอีุ๊่ࠠา๊ࠤฬ๊โศศ่อࠥหไ๊ࠢส่๊ฮัๆฮࠣ฽๋ีๅศࠢํูอำฺࠠัา๋ฬࠦ࠷ࠡใํำ๏๎็ศฬࠪ䒳")+l1l1ll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䒴")+l1l1ll_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨ䒵")+str(total))
		if total>=7:
			yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࠧ䒶"),l1l1ll_l1_ (u"ࠧࠨ䒷"),l1l1ll_l1_ (u"ࠨࠩ䒸"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䒹"),l1l1ll_l1_ (u"ࠪห้ฮั็ษ่ะࠥาๅฺࠢๅหห๋ษࠡใํ๋ฬࠦ࠷ࠡใํำ๏๎็ศฬ่๊๊ࠣࠦอัࠣห้ฮั็ษ่ะ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰ࠣืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮๅิฯ๋ࠣีํࠠศๆๅหห๋ษࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦำึห้ࠦ็ั้ࠣห้่วว็ฬࠤ็ฮไࠡ็ึั์อࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆ่ฬึ๋ฬࠡสไัฺࠦ็ั้ࠣห้็๊ะ์๋๋ฬะࠠภࠣࠤࠫ䒺"))
			if yes==1:
				l111ll11l1l_l1_ = l1l1ll_l1_ (u"ࠫࠬ䒻")
				for key in list(l111ll111ll_l1_.keys()):
					l111ll11l1l_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ䒼")+key
					l1ll1lll1lll_l1_ = sorted(l111ll111ll_l1_[key],reverse=False,key=lambda l1llllll1lll_l1_: l1llllll1lll_l1_[0])
					for datetime,url in l1ll1lll1lll_l1_:
						l111ll11l1l_l1_ += l1l1ll_l1_ (u"࠭࡜࡯ࠩ䒽")+datetime+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠤࠬ䒾")+UNQUOTE(url)
					l111ll11l1l_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䒿")
				import l1ll1l1lll11_l1_
				l1llll1l1111_l1_ = l1l1ll_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ䓀")+l1l1l1l1l1l_l1_(32)+l1l1ll_l1_ (u"ࠪ࠱࡛࡯ࡤࡦࡱࡶࠫ䓁")
				succeeded = l1ll1l1lll11_l1_.l111lll1ll1_l1_(l1llll1l1111_l1_,l1l1ll_l1_ (u"ࠫࠬ䓂"),False,l1l1ll_l1_ (u"ࠬ࠭䓃"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡐࡆ࡟࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䓄"),l1l1ll_l1_ (u"ࠧࠨ䓅"),l111ll11l1l_l1_)
				if succeeded: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䓆"),l1l1ll_l1_ (u"ࠩࠪ䓇"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䓈"),l1l1ll_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ䓉"))
				else: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䓊"),l1l1ll_l1_ (u"࠭ࠧ䓋"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䓌"),l1l1ll_l1_ (u"ࠨใื่ฯูࠦๆๆํอࠥอไฦำึห้࠭䓍"))
			if yes!=-1:
				l111ll111ll_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ䓎"),l1l1ll_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ䓏"))
		if l111ll111ll_l1_: WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䓐"),l1l1ll_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䓑"),l111ll111ll_l1_,PERMANENT_CACHE)
		return
	l111ll1_l1_ = list(set(l111ll1_l1_))
	l111l1l_l1_,l11l1_l1_ = l1lll11l1111_l1_(l111ll1_l1_,source)
	l1ll1lll1l1l_l1_ = str(l11l1_l1_).count(l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䓒"))
	l1lll11l11ll_l1_ = str(l11l1_l1_).count(l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䓓"))
	l1ll1llll11l_l1_ = len(l11l1_l1_)-l1ll1lll1l1l_l1_-l1lll11l11ll_l1_
	l1lll11lll1l_l1_ = l1l1ll_l1_ (u"ࠨ็ืห์ีษ࠻ࠩ䓔")+str(l1ll1lll1l1l_l1_)+l1l1ll_l1_ (u"ࠩࠣࠤࠥࠦสฮ็ํ่࠿࠭䓕")+str(l1lll11l11ll_l1_)+l1l1ll_l1_ (u"ࠪࠤࠥࠦࠠฤะิํ࠿࠭䓖")+str(l1ll1llll11l_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䓗"),l1l1ll_l1_ (u"ࠬ࠭䓘"),str(l1ll1lll1l1l_l1_),str(l1lll11l11ll_l1_))
	#selection = DIALOG_SELECT(l1lll11lll1l_l1_, l11l1_l1_)
	if not l11l1_l1_:
		result = l1l1ll_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䓙")
		l11l1ll111l_l1_ = l1l1ll_l1_ (u"ࠧࠨ䓚")
	else:
		while True:
			l11l1ll111l_l1_ = l1l1ll_l1_ (u"ࠨࠩ䓛")
			if len(l11l1_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1lll11lll1l_l1_,l111l1l_l1_)
			if selection==-1: result = l1l1ll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠶ࡹࡴࡠ࡯ࡨࡲࡺ࠭䓜")
			else:
				title = l111l1l_l1_[selection]
				link = l11l1_l1_[selection]
				#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䓝"),l1l1ll_l1_ (u"ࠫࠬ䓞"),title,link)
				if l1l1ll_l1_ (u"ู๊ࠬาใิࠫ䓟") in title and l1l1ll_l1_ (u"࠭࠲ๆฮ๊์้࠸ࠧ䓠") in title:
					LOG_THIS(l1l1ll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ䓡"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭䓢")+title+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䓣")+link+l1l1ll_l1_ (u"ࠪࠤࡢ࠭䓤"))
					import l1ll1l1lll11_l1_
					l1ll1l1lll11_l1_.MAIN(156)
					result = l1l1ll_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䓥")
				else:
					LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䓦"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡗࡪࡲࡥࡤࡶࡨࡨ࡙ࠥࡥࡳࡸࡨࡶࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䓧")+title+l1l1ll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ䓨")+link+l1l1ll_l1_ (u"ࠨࠢࡠࠫ䓩"))
					result,l11l1ll111l_l1_,l1l111ll1l1_l1_ = l1lll1l1l1ll_l1_(link,source,type)
					#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䓪"),l1l1ll_l1_ (u"ࠪࠫ䓫"),result,l11l1ll111l_l1_)
			if l1l1ll_l1_ (u"ࠫࡡࡴࠧ䓬") not in l11l1ll111l_l1_: l11l11l1lll_l1_,l11l11l1ll1_l1_ = l11l1ll111l_l1_,l1l1ll_l1_ (u"ࠬ࠭䓭")
			else: l11l11l1lll_l1_,l11l11l1ll1_l1_ = l11l1ll111l_l1_.split(l1l1ll_l1_ (u"࠭࡜࡯ࠩ䓮"),1)
			if result in [l1l1ll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䓯"),l1l1ll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䓰"),l1l1ll_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䓱"),l1l1ll_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠷ࡳࡵࡡࡰࡩࡳࡻࠧ䓲")] or len(l11l1_l1_)==1: break
			elif result in [l1l1ll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ䓳"),l1l1ll_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭䓴"),l1l1ll_l1_ (u"࠭ࡴࡳ࡫ࡨࡨࠬ䓵")]: break
			elif result not in [l1l1ll_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ䓶"),l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䓷")]: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䓸"),l1l1ll_l1_ (u"ࠪࠫ䓹"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䓺"),l1l1ll_l1_ (u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨ䓻")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ䓼")+l11l11l1lll_l1_+l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ䓽")+l11l11l1ll1_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䓾"),l1l1ll_l1_ (u"ࠩࠪ䓿"),l1l1ll_l1_ (u"ࠪࠫ䔀"),str(l1l111ll1l1_l1_))
	if result==l1l1ll_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䔁") and len(l111l1l_l1_)>0: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䔂"),l1l1ll_l1_ (u"࠭ࠧ䔃"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䔄"),l1l1ll_l1_ (u"ࠨีํีๆื่ࠠาสࠤฬ๊แ๋ัํ์๊ࠥๅࠡ์฼้้ࠦฬาสࠣๅ๏ี๊้ࠢ฽๎ึํࠧ䔅")+l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ䔆")+l11l1ll111l_l1_)
	elif result in [l1l1ll_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ䔇"),l1l1ll_l1_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ䔈")] and l11l1ll111l_l1_!=l1l1ll_l1_ (u"ࠬ࠭䔉"): DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䔊"),l1l1ll_l1_ (u"ࠧࠨ䔋"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䔌"),l11l1ll111l_l1_)
	#elif l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠩࡕࡉ࡙࡛ࡒࡏࡡࡗࡓࡤ࡟ࡏࡖࡖࡘࡆࡊ࠭䔍"): result = l1l111ll1l1_l1_
	l1l1ll_l1_ (u"ࠥࠦࠧࠐࠉࡦ࡮࡬ࡪࠥࡸࡥࡴࡷ࡯ࡸࠥ࡯࡮ࠡ࡝ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠷ࡳࡵࡡࡰࡩࡳࡻࠧ࠭ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭࡝࠻ࠌࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࡏࡓࡌࡍࡉࡏࡉࠫࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠪ࠭ࠪࠤࠥࠦࡔࡦࡵࡷ࠾ࠥࠦࠠࠨ࠭ࡶࡽࡸ࠴ࡡࡳࡩࡹ࡟࠵ࡣࠫࡴࡻࡶ࠲ࡦࡸࡧࡷ࡝࠵ࡡ࠮ࠐࠉࠊࡺࡥࡱࡨࡶ࡬ࡶࡩ࡬ࡲ࠳ࡹࡥࡵࡔࡨࡷࡴࡲࡶࡦࡦࡘࡶࡱ࠮ࡡࡥࡦࡲࡲࡤ࡮ࡡ࡯ࡦ࡯ࡩ࠱ࠦࡆࡢ࡮ࡶࡩ࠱ࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡍ࡫ࡶࡸࡎࡺࡥ࡮ࠪࠬ࠭ࠏࠏࠉࡱ࡮ࡤࡽࡤ࡯ࡴࡦ࡯ࠣࡁࠥࡾࡢ࡮ࡥࡪࡹ࡮࠴ࡌࡪࡵࡷࡍࡹ࡫࡭ࠩࡲࡤࡸ࡭ࡃࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠯ࡀ࡯ࡲࡨࡪࡃ࠱࠵࠵ࠩࡹࡷࡲ࠽ࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࠧ࠶ࡊࡻࠫ࠳ࡅࡩࡺࡦ࠶ࡶࡸࡗࡶࡺ࠽ࡖ࠭ࠩࠋࠋࠌࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡴࡱࡧࡹࠩࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡱࡼ࠱࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱ࠴࡯ࡰࡩࡱࡱࡩ࠴࠷࠲࠴࠶࠷࠻࠳ࡳࡰ࠵ࠩ࠯ࡴࡱࡧࡹࡠ࡫ࡷࡩࡲ࠯ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭สๆࠢส่ฬฺ๊ศรࠪ࠰ࠬ࠭ࠩࠋࠋࠥࠦࠧ䔎")
	return result
	#if source==l1l1ll_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭䔏"): menu_name = l1l1ll_l1_ (u"ࠬࡎࡌࡂࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䔐")
	#elif source==l1l1ll_l1_ (u"࠭࠴ࡉࡇࡏࡅࡑ࠭䔑"): menu_name = l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡋࡉࡑ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䔒")
	#elif source==l1l1ll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䔓"): menu_name = l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡆࡑࡍࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䔔")
	#elif source==l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ䔕"): menu_name = l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡓࡉ࠶ࠣࠫ䔖")
	#size = len(l1lll1l111_l1_)
	#for i in range(0,size):
	#	title = l11l1l1lll1_l1_[i]
	#	link = l1lll1l111_l1_[i]
	#	addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䔗"),menu_name+title,link,160,l1l1ll_l1_ (u"࠭ࠧ䔘"),l1l1ll_l1_ (u"ࠧࠨ䔙"),source)
def l1lll1l1l1ll_l1_(url,source,type=l1l1ll_l1_ (u"ࠨࠩ䔚")):
	url = url.strip(l1l1ll_l1_ (u"ࠩࠣࠫ䔛")).strip(l1l1ll_l1_ (u"ࠪࠪࠬ䔜")).strip(l1l1ll_l1_ (u"ࠫࡄ࠭䔝")).strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ䔞"))
	l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll11l1l_l1_(url,source)
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䔟"),l1l1ll_l1_ (u"ࠧࠨ䔠"),url,l11l1ll111l_l1_)
	if l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䔡"): return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	elif l11l1_l1_:
		while True:
			if len(l11l1_l1_)==1: selection = 0
			else: selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ䔢"), l111l1l_l1_)
			if selection==-1: result = l1l1ll_l1_ (u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ䔣")
			else:
				l1lllll1ll1l_l1_ = l11l1_l1_[selection]
				title = l111l1l_l1_[selection]
				LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䔤"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡒ࡯ࡥࡾ࡯࡮ࡨࠢࡶࡩࡱ࡫ࡣࡵࡧࡧࠤࡻ࡯ࡤࡦࡱࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫ䔥")+title+l1l1ll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ䔦")+str(l1lllll1ll1l_l1_)+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ䔧"))
				if l1l1ll_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࠫ䔨") in l1lllll1ll1l_l1_ and l1l1ll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩ䔩") in l1lllll1ll1l_l1_:
					l11111l1111_l1_,l1l111l11l1_l1_,l1l111ll1l1_l1_ = l111lll111l_l1_(l1lllll1ll1l_l1_)
					if l1l111ll1l1_l1_: l1lllll1ll1l_l1_ = l1l111ll1l1_l1_[0]
					else: l1lllll1ll1l_l1_ = l1l1ll_l1_ (u"ࠪࠫ䔪")
				if not l1lllll1ll1l_l1_: result = l1l1ll_l1_ (u"ࠫࡺࡴࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ䔫")
				else: result = PLAY_VIDEO(l1lllll1ll1l_l1_,source,type)
			if result in [l1l1ll_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭䔬"),l1l1ll_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ䔭")] or len(l11l1_l1_)==1: break
			elif result in [l1l1ll_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ䔮"),l1l1ll_l1_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ䔯"),l1l1ll_l1_ (u"ࠩࡷࡶ࡮࡫ࡤࠨ䔰")]: break
			else: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䔱"),l1l1ll_l1_ (u"ࠫࠬ䔲"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䔳"),l1l1ll_l1_ (u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ䔴"))
	else:
		result = l1l1ll_l1_ (u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ䔵")
		videofiletype = GET_VIDEOFILETYPE(url)
		if videofiletype: result = PLAY_VIDEO(url,source,type)
	return result,l11l1ll111l_l1_,l11l1_l1_
	#title = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠤ䔶") )
	#if l1l1ll_l1_ (u"ࠩึ๎ึ็ัࠡ฻ส้๋ࠥฬ่๊็ࠫ䔷") in title:
	#	import l1ll1l1lll11_l1_
	#	l1ll1l1lll11_l1_.MAIN(156)
	#	return l1l1ll_l1_ (u"ࠪࠫ䔸")
def l1ll1l11ll1l_l1_(url,source):
	# url = url+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䔹")+name+l1l1ll_l1_ (u"ࠬࡥ࡟ࠨ䔺")+type+l1l1ll_l1_ (u"࠭࡟ࡠࠩ䔻")+l1l111l_l1_+l1l1ll_l1_ (u"ࠧࡠࡡࠪ䔼")+l11ll1l1_l1_
	# url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡮ࡻࡦࡳ࠮࡯ࡧࡷࡃࡳࡧ࡭ࡦࡦࡀࡥࡰࡽࡡ࡮ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱࡵ࠺࡟ࡠ࠹࠵࠴ࠬ䔽")
	url2,l111lllllll_l1_,server,l1lllllll111_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_ = url,l1l1ll_l1_ (u"ࠩࠪ䔾"),l1l1ll_l1_ (u"ࠪࠫ䔿"),l1l1ll_l1_ (u"ࠫࠬ䕀"),l1l1ll_l1_ (u"ࠬ࠭䕁"),l1l1ll_l1_ (u"࠭ࠧ䕂"),l1l1ll_l1_ (u"ࠧࠨ䕃"),l1l1ll_l1_ (u"ࠨࠩ䕄")
	#source = source.lower()
	if l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䕅") in url:
		url2,l111lllllll_l1_ = url.split(l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䕆"),1)
		l111lllllll_l1_ = l111lllllll_l1_+l1l1ll_l1_ (u"ࠫࡤࡥࠧ䕇")+l1l1ll_l1_ (u"ࠬࡥ࡟ࠨ䕈")+l1l1ll_l1_ (u"࠭࡟ࡠࠩ䕉")+l1l1ll_l1_ (u"ࠧࡠࡡࠪ䕊")
		l111lllllll_l1_ = l111lllllll_l1_.lower()
		name,type,l1l111l_l1_,l11ll1l1_l1_,source2 = l111lllllll_l1_.split(l1l1ll_l1_ (u"ࠨࡡࡢࠫ䕋"))[:5]
	if l11ll1l1_l1_==l1l1ll_l1_ (u"ࠩࠪ䕌"): l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪ࠴ࠬ䕍")
	else: l11ll1l1_l1_ = l11ll1l1_l1_.replace(l1l1ll_l1_ (u"ࠫࡵ࠭䕎"),l1l1ll_l1_ (u"ࠬ࠭䕏")).replace(l1l1ll_l1_ (u"࠭ࠠࠨ䕐"),l1l1ll_l1_ (u"ࠧࠨ䕑"))
	url2 = url2.strip(l1l1ll_l1_ (u"ࠨࡁࠪ䕒")).strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ䕓")).strip(l1l1ll_l1_ (u"ࠪࠪࠬ䕔"))
	server = SERVER(url2,l1l1ll_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ䕕"))
	if name: l1lllllll111_l1_ = name
	#elif source: l1lllllll111_l1_ = source
	else: l1lllllll111_l1_ = server
	l1lllllll111_l1_ = SERVER(l1lllllll111_l1_,l1l1ll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䕖"))
	name = name.replace(l1l1ll_l1_ (u"࠭ๅษษืีࠬ䕗"),l1l1ll_l1_ (u"ࠧࠨ䕘")).replace(l1l1ll_l1_ (u"ࠨีํีๆืࠧ䕙"),l1l1ll_l1_ (u"ࠩࠪ䕚")).replace(l1l1ll_l1_ (u"ࠪห้ࠦࠧ䕛"),l1l1ll_l1_ (u"ࠫࠥ࠭䕜")).replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ䕝"),l1l1ll_l1_ (u"࠭ࠠࠨ䕞"))
	l111lllllll_l1_ = l111lllllll_l1_.replace(l1l1ll_l1_ (u"ࠧๆสสุึ࠭䕟"),l1l1ll_l1_ (u"ࠨࠩ䕠")).replace(l1l1ll_l1_ (u"ࠩึ๎ึ็ัࠨ䕡"),l1l1ll_l1_ (u"ࠪࠫ䕢")).replace(l1l1ll_l1_ (u"ࠫฬ๊ࠠࠨ䕣"),l1l1ll_l1_ (u"ࠬࠦࠧ䕤")).replace(l1l1ll_l1_ (u"࠭ࠠࠡࠩ䕥"),l1l1ll_l1_ (u"ࠧࠡࠩ䕦"))
	l1lllllll111_l1_ = l1lllllll111_l1_.replace(l1l1ll_l1_ (u"ࠨ็หหูืࠧ䕧"),l1l1ll_l1_ (u"ࠩࠪ䕨")).replace(l1l1ll_l1_ (u"ࠪื๏ืแาࠩ䕩"),l1l1ll_l1_ (u"ࠫࠬ䕪")).replace(l1l1ll_l1_ (u"ࠬอไࠡࠩ䕫"),l1l1ll_l1_ (u"࠭ࠠࠨ䕬")).replace(l1l1ll_l1_ (u"ࠧࠡࠢࠪ䕭"),l1l1ll_l1_ (u"ࠨࠢࠪ䕮"))
	return url2,l111lllllll_l1_,server,l1lllllll111_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_
def l11l1l11lll_l1_(url,source):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䕯"),l1l1ll_l1_ (u"ࠪࠫ䕰"),url,l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡅࡇࡒࡅࠨ䕱"))
	# l1111111_l1_	: سيرفر خاص
	# l11l111llll_l1_		: سيرفر محدد
	# l111lllll1l_l1_		: سيرفر عام معروف
	# l1lll1l1l_l1_	: سيرفر عام خارجي
	# l1ll1llll1ll_l1_	: سيرفر عام خارجي
	l1lllll111ll_l1_,name,l1111111_l1_,l111lllll1l_l1_,l1lll1l1l_l1_,l11l111llll_l1_,l1ll1llll1ll_l1_ = l1l1ll_l1_ (u"ࠬ࠭䕲"),l1l1ll_l1_ (u"࠭ࠧ䕳"),None,None,None,None,None
	url2,l111lllllll_l1_,server,l1lllllll111_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_ = l1ll1l11ll1l_l1_(url,source)
	if l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䕴") in url:
		if   type==l1l1ll_l1_ (u"ࠨࡧࡰࡦࡪࡪࠧ䕵"): type = l1l1ll_l1_ (u"ࠩࠣࠫ䕶")+l1l1ll_l1_ (u"้ࠪๆ฼ไࠨ䕷")
		elif type==l1l1ll_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ䕸"): type = l1l1ll_l1_ (u"ࠬࠦࠧ䕹")+l1l1ll_l1_ (u"࠭ࠥๆึส๋ิฯࠧ䕺")
		elif type==l1l1ll_l1_ (u"ࠧࡣࡱࡷ࡬ࠬ䕻"): type = l1l1ll_l1_ (u"ࠨࠢࠪ䕼")+l1l1ll_l1_ (u"ࠩࠨฺ๊ࠩว่ัฬࠤํะอๆ์็ࠫ䕽")
		elif type==l1l1ll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䕾"): type = l1l1ll_l1_ (u"ࠫࠥ࠭䕿")+l1l1ll_l1_ (u"ࠬࠫࠥࠦฬะ้๏๊ࠧ䖀")
		elif type==l1l1ll_l1_ (u"࠭ࠧ䖁"): type = l1l1ll_l1_ (u"ࠧࠡࠩ䖂")+l1l1ll_l1_ (u"ࠨࠧࠨࠩࠪ࠭䖃")
		if l1l111l_l1_!=l1l1ll_l1_ (u"ࠩࠪ䖄"):
			if l1l1ll_l1_ (u"ࠪࡱࡵ࠺ࠧ䖅") not in l1l111l_l1_: l1l111l_l1_ = l1l1ll_l1_ (u"ࠫࠪ࠭䖆")+l1l111l_l1_
			l1l111l_l1_ = l1l1ll_l1_ (u"ࠬࠦࠧ䖇")+l1l111l_l1_
		if l11ll1l1_l1_!=l1l1ll_l1_ (u"࠭ࠧ䖈"):
			l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠧࠦࠧࠨࠩࠪࠫࠥࠦࠧࠪ䖉")+l11ll1l1_l1_
			l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࠢࠪ䖊")+l11ll1l1_l1_[-9:]
	#if any(value in server for value in l11111lll11_l1_): return l1l1ll_l1_ (u"ࠩࠪ䖋")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䖌"),l1l1ll_l1_ (u"ࠫࠬ䖍"),name,l1lllllll111_l1_)
	if   l1l1ll_l1_ (u"ࠬࡇࡋࡐࡃࡐࠫ䖎")		in source: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࠬ䖏")		in source: l1111111_l1_	= l1l1ll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲ࠭䖐")
	elif l1l1ll_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ䖑")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ䖒")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ䖓")	in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠫࡸ࡫ࡥࡦࡧࡧࠫ䖔")		in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䖕")
	#elif l1l1ll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡹࡴࡢࡶ࡬ࡳࡳ࠭䖖") in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠧࡢ࡮ࡤࡶࡦࡨࠧ䖗")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ䖘")		in server: l1111111_l1_	= l1lllllll111_l1_
	#elif l1l1ll_l1_ (u"ࠩࡳࡧࡷ࡫ࡶࡪࡧࡺࠫ䖙")	in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ䖚")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫ䖛")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ䖜")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ䖝")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭䖞")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳ࡣ࡭ࡷࡥࠫ䖟")	in name:   l1111111_l1_	= l1l1ll_l1_ (u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡳࠫ䖠")
	elif l1l1ll_l1_ (u"ࠪๅัืࠧ䖡")			in name:   l1111111_l1_	= l1l1ll_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࠪ䖢")
	elif l1l1ll_l1_ (u"ࠬ็ไิูํ๊ࠬ䖣")		in name:   l1111111_l1_	= l1l1ll_l1_ (u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩ䖤")
	elif l1l1ll_l1_ (u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧ䖥")		in url2:   l1111111_l1_	= l1l1ll_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ䖦")
	elif l1l1ll_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䖧")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠪࡻࡪࡩࡩ࡮ࡣࠪ䖨")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䖩")		in name:   l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䖪")	in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"࠭ࡢࡰ࡭ࡵࡥࠬ䖫")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠧࡵࡸࡩࡹࡳ࠭䖬")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠨࡶࡹ࡯ࡸࡧࠧ䖭")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪ䖮")		in server: l1111111_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䖯")		in server: l1111111_l1_	= l1lllllll111_l1_
	#elif l1l1ll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻ࠳ࡴࡥࡵࠩ䖰")	in url2:   l1111111_l1_	= l1l1ll_l1_ (u"ࠬࠦࠧ䖱")
	elif l1l1ll_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ䖲")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ䖳")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨ䖴")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ䖵")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ䖶")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭䖷")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ䖸")	 	in server: l1111111_l1_	= l1l1ll_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ䖹")
	elif l1l1ll_l1_ (u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧ䖺")	 	in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ䖻")
	elif l1l1ll_l1_ (u"ࠩࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪࠧ䖼")	in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧ䖽")
	elif l1l1ll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ䖾")		in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭䖿")
	elif l1l1ll_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䗀")		in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ䗁")
	elif l1l1ll_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ䗂")	in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ䗃")
	elif l1l1ll_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭䗄")	in server: l1111111_l1_	= l1l1ll_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ䗅")
	elif l1l1ll_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭䗆")		in server: l1111111_l1_	= l1l1ll_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ䗇")
	elif l1l1ll_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ䗈")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䗉")
	elif l1l1ll_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䗊")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ䗋")
	elif l1l1ll_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭䗌")	 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠬࡩࡡࡵࡥ࡫ࠫ䗍")
	elif l1l1ll_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䗎")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ䗏")
	elif l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ䗐")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䗑")
	elif l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ䗒")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ䗓")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ䗔")		in server: l11l111llll_l1_	= l1lllllll111_l1_
	elif l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ䗕")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ䗖")
	elif l1l1ll_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ䗗")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䗘")
	elif l1l1ll_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ䗙") 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭䗚")
	elif l1l1ll_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ䗛")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䗜")
	elif l1l1ll_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ䗝")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭䗞")
	elif l1l1ll_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭䗟") 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ䗠")
	elif l1l1ll_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ䗡")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭䗢")
	elif l1l1ll_l1_ (u"࠭ࡵࡱࡲࠪ䗣") 			in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭䗤")
	elif l1l1ll_l1_ (u"ࠨࡷࡳࡦࠬ䗥") 			in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ䗦")
	elif l1l1ll_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ䗧") 		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ䗨")
	elif l1l1ll_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ䗩") 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䗪")
	elif l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䗫")		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ䗬")
	elif l1l1ll_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ䗭") 		in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䗮")
	elif l1l1ll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䗯") 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ䗰")
	elif l1l1ll_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ䗱")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䗲")
	elif l1l1ll_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䗳")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭䗴")
	#elif l1l1ll_l1_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ䗵") 	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ䗶")
	#elif l1l1ll_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ䗷")	in server: l111lllll1l_l1_	= l1l1ll_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ䗸")
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࡹࡷࡲࠫࠨ࠿ࡀࡁࠬ࠱ࡵࡳ࡮࠵࠭ࠏࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭࠰ࡋࡳࡸࡺࡥࡥࡏࡨࡨ࡮ࡧࡆࡪ࡮ࡨࠬࡺࡸ࡬࠳ࠫ࠱ࡺࡦࡲࡩࡥࡡࡸࡶࡱ࠮ࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠊࠊࠋࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠴࠵࠶࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠩࠋࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡈࡤࡰࡸ࡫ࠊࠊࠋࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥ࡮࠱ࡳࡷ࡭ࠊࠊࠋࠌࡰ࡮ࡹࡴࡠࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡸࡩࡲ࠭ࡰࡴࡪ࠲࡬࡯ࡴࡩࡷࡥ࠲࡮ࡵ࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠳ࡸࡻࡰࡱࡱࡵࡸࡪࡪࡳࡪࡶࡨࡷ࠳࡮ࡴ࡮࡮ࠪࠎࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡲࡩࡴࡶࡢࡹࡷࡲࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀࡺࡲ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࡛࠱࡟࠱ࡰࡴࡽࡥࡳࠪࠬࠎࠎࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࡯࡭ࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯࡭࡫ࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁ࠵ࡢ࠿ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠶࠷࠸࠲ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࠏࡰࡢࡴࡷࡷࠥࡃࠠࡴࡧࡵࡺࡪࡸ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠯ࠩࠬࠎࠎࠏࠉࠊࡨࡲࡶࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡰࡢࡴࡷࡷ࠿ࠐࠉࠊࠋࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡵࡧࡲࡵࠫ࠿࠸࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࠏࡥ࡭࡫ࡩࠤࡵࡧࡲࡵࠢ࡬ࡲࠥ࡮ࡴ࡮࡮࠽ࠎࠎࠏࠉࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡕࡴࡸࡩࠏࠏࠉࠊࠋࠌࠍࡧࡸࡥࡢ࡭ࠍࠍࠧࠨࠢ䗹")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䗺"),l1l1ll_l1_ (u"ࠩࠪ䗻"),url,url2)
	if   l1111111_l1_:	l1lllll111ll_l1_,name = l1l1ll_l1_ (u"ࠪาฬ฻ࠧ䗼"),l1111111_l1_
	elif l11l111llll_l1_:		l1lllll111ll_l1_,name = l1l1ll_l1_ (u"๋ࠫࠪอะัࠪ䗽"),l11l111llll_l1_
	elif l111lllll1l_l1_:		l1lllll111ll_l1_,name = l1l1ll_l1_ (u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪ䗾"),l111lllll1l_l1_
	elif l1lll1l1l_l1_:	l1lllll111ll_l1_,name = l1l1ll_l1_ (u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ䗿"),l1lll1l1l_l1_
	elif l1ll1llll1ll_l1_:	l1lllll111ll_l1_,name = l1l1ll_l1_ (u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧ䘀"),l1lllllll111_l1_
	else:			l1lllll111ll_l1_,name = l1l1ll_l1_ (u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩ䘁"),l1lllllll111_l1_
	return l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌࡴࡷ࡯ࡶࡢࡶࡨࠤࡂࠦࠧࡩࡧ࡯ࡥࡱ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸࡨࡺ࠳࡯࡯ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡫ࡶࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡨ࡯࡮ࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡷ࡭ࡧࡲࡦࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠊࠊࠤࠥࠦ䘂")
def l1lll1lll111_l1_(url,source):
	url2,l111lllllll_l1_,server,l1lllllll111_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_ = l1ll1l11ll1l_l1_(url,source)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䘃"),l1l1ll_l1_ (u"ࠫࠬ䘄"),l11l111llll_l1_,server)
	#if l1l1ll_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ䘅")	in server: url2 = url2.replace(l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭䘆"),l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䘇"))
	#if any(value in server for value in l11111lll11_l1_): l111l1l_l1_,l11l1_l1_ = [l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ䘈")],[]
	if   l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ䘉")		in source: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1l1l_l1_(url2,name)
	elif l1l1ll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ䘊")		in source: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11llll_l1_(url2,type,l11ll1l1_l1_)
	elif l1l1ll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭䘋")		in source: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1lll11l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ䘌")		in source: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1111ll1l_l1_(url2)
	elif l1l1ll_l1_ (u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ䘍")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll1l11l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠧࡢ࡭ࡲࡥࡲ࠴ࡣࡢ࡯ࠪ䘎")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll111l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠨࡣ࡯ࡥࡷࡧࡢࠨ䘏")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11l11llll1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ䘐")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11111l1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬ䘑")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11111l1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ䘒")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll11l1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ䘓")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll11ll1_l1_(url2)
	elif l1l1ll_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ䘔")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111111l111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭䘕")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111111l111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ䘖")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll111l11l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫ䘗")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll1lll_l1_(url2)
	elif l1l1ll_l1_ (u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬ䘘")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll11lll_l1_(url2)
	elif l1l1ll_l1_ (u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭䘙")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll1llll_l1_(url2)
	elif l1l1ll_l1_ (u"ࠬࡼࡳ࠵ࡷࠪ䘚")			in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l111l1111_l1_(url2)
	elif l1l1ll_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ䘛")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1lll1ll_l1_(url2)
	elif l1l1ll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䘜")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11l11_l1_(url2)
	elif l1l1ll_l1_ (u"ࠨࡥ࡬ࡱࡦ࠳࡬ࡪࡩ࡫ࡸࠬ䘝")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11l1l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬ䘞")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11l1l_l1_(url2)
	elif l1l1ll_l1_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ䘟")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1111lll1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠫࡼ࡫ࡣࡪ࡯ࡤࠫ䘠")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll111l111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠬࡨ࡯࡬ࡴࡤࠫ䘡")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111l1ll1_l1_(url2)
	elif l1l1ll_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ䘢")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1111ll1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䘣")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11lll111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠨࡵࡨࡩࡪ࡫ࡤࠨ䘤")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11lll111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡶࡨࡧ࡭࠭䘥")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11lll111_l1_(url2)
	elif l1l1ll_l1_ (u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬ䘦")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11l1l1l1_l1_(url2)
	elif l1l1ll_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ䘧")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭䘨"),[l1l1ll_l1_ (u"࠭ࠧ䘩")],[url2]
	elif l1l1ll_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ䘪")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1111llll1_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠧ䘫")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111l1l1lll_l1_(url2)
	elif l1l1ll_l1_ (u"ࠩࡸࡴࡧࡧ࡭ࠨ䘬") 		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠪࠫ䘭"),[l1l1ll_l1_ (u"ࠫࠬ䘮")],[url2]
	else: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䘯"),[l1l1ll_l1_ (u"࠭ࠧ䘰")],[url2]
	return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
def l111llll1ll_l1_(url,source):
	server = SERVER(url,l1l1ll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䘱"))
	#if l1l1ll_l1_ (u"ࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭䘲")	in server: url2 = url2.replace(l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ䘳"),l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䘴"))
	#if any(value in server for value in l11111lll11_l1_): l111l1l_l1_,l11l1_l1_ = [l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗࡋࡓࡐࡎ࡙ࡉࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡳࡧࡶࡳࡱࡼࡥࠡࡶ࡫࡭ࡸࠦࡳࡦࡴࡹࡩࡷ࠭䘵")],[]
	l1lll1ll1lll_l1_ = False
	if   l1l1ll_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࠫ䘶")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11l1l1l11l_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡹ࠳ࡷ࠱ࡦࡪ࠭䘷")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11l1l1l11l_l1_(url)
	elif l1l1ll_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷࠫ䘸") in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llllllll11_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ䘹")	in url: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11111llll1_l1_(url)
	elif l1l1ll_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䘺")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11lll111_l1_(url)
	elif l1l1ll_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䘻")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1111ll1_l1_(url)
	elif l1l1ll_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䘼")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111lll111l_l1_(url)
	elif l1l1ll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭䘽")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1lll11l_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ䘾")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll11ll1l_l1_(url)
	elif l1l1ll_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䘿")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll11ll11ll_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ䙀")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll1lllll_l1_(url)
	elif l1l1ll_l1_ (u"ࠩࡨ࠹ࡹࡹࡡࡳࠩ䙁")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111l1ll11l_l1_(url)
	elif l1l1ll_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䙂")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111l1lll11_l1_(url)
	elif l1l1ll_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ䙃")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111l1lll11_l1_(url)
	elif l1l1ll_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䙄")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䙅")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭䙆")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡸ࡬ࡨ࡭ࡪࠧ䙇")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ䙈")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠪࡰ࡮࡯ࡩࡷ࡫ࡧࡩࡴ࠭䙉")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡰࡤࡤࠫ䙊")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l11l11l_l1_(url)
	elif l1l1ll_l1_ (u"ࠬࡼࡩࡥࡵࡳࡩࡪࡪࠧ䙋")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l11l11l_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䙌") 		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠧࠨ䙍"),[l1l1ll_l1_ (u"ࠨࠩ䙎")],[url]
	#elif l1l1ll_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ䙏")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll11ll11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ䙐") 	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11111ll11l_l1_(url)
	elif l1l1ll_l1_ (u"ࠫࡲࡶ࠴ࡶࡲ࡯ࡳࡦࡪࠧ䙑")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1111lll1ll_l1_(url)
	elif l1l1ll_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱ࡫ࡳࠬ䙒")in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llllll11l1_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ䙓") 	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111ll1l11l_l1_(url)
	elif l1l1ll_l1_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ䙔")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll11111l_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡷࡳࡦࠬ䙕") 			in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll11l1l111_l1_(url)
	elif l1l1ll_l1_ (u"ࠩࡸࡴࡵ࠭䙖") 			in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll11l1l111_l1_(url)
	#elif l1l1ll_l1_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ䙗") 	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll1ll1l1_l1_(url)
	#elif l1l1ll_l1_ (u"ࠫࡺࡶࡴࡰࡵࡷࡶࡪࡧ࡭ࠨ䙘")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll1ll1l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䙙") 		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll111llll_l1_(url)
	elif l1l1ll_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ䙚") 	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11111l11ll_l1_(url)
	elif l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ䙛")		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll111111_l1_(url)
	elif l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ䙜") 		in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll1l11l11_l1_(url)
	elif l1l1ll_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䙝") 	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1111ll111l_l1_(url)
	elif l1l1ll_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䙞")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll11l11l1_l1_(url)
	elif l1l1ll_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ䙟")	in server: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1llll1llll1_l1_(url)
	else: l1lll1ll1lll_l1_ = True
	if l1lll1ll1lll_l1_ or l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ䙠") in l11l1ll111l_l1_:
		l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠵ࠥࡌࡡࡪ࡮ࡨࡨࠬ䙡"),[],[]
	return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࠪࡩࡸࡺࡲࡦࡣࡰࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡅࡔࡖࡕࡉࡆࡓࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡋࡔ࡛ࡎࡍࡋࡐࡍ࡙ࡋࡄࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡩ࡯ࡶࡲࡹࡵࡲ࡯ࡢࡦࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡎࡔࡔࡐࡗࡓࡐࡔࡇࡄࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡴࡩࡧࡹ࡭ࡩ࡫࡯ࠨࠋࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡗࡌࡊ࡜ࡉࡅࡇࡒࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹࡩࡻ࠴ࡩࡰࠩࠌࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡛ࡋࡖࡊࡑࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡲ࡯ࡥࡾࡸ࠮࠵ࡪࡨࡰࡦࡲࠧࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡉࡇࡏࡅࡑ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥ࡜ࡉࡅࡄࡒࡑ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡨࡥࠩࠣࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡛ࡏࡄࡉࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸ࡬ࡨࡸ࡮ࡡࡳࡧࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡛ࡏࡄࡔࡊࡄࡖࡊ࠮ࡵࡳ࡮ࠬࠎࠎࠨࠢࠣ䙢")
def	l111111l1ll_l1_(l1l11l111ll_l1_):
	if l1l1ll_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭䙣") in str(type(l1l11l111ll_l1_)):
		l1ll_l1_ = []
		for link in l1l11l111ll_l1_:
			if l1l1ll_l1_ (u"ࠩࡶࡸࡷ࠭䙤") in str(type(link)):
				link = link.replace(l1l1ll_l1_ (u"ࠪࡠࡷ࠭䙥"),l1l1ll_l1_ (u"ࠫࠬ䙦")).replace(l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ䙧"),l1l1ll_l1_ (u"࠭ࠧ䙨")).strip(l1l1ll_l1_ (u"ࠧࠡࠩ䙩"))
			l1ll_l1_.append(link)
	else: l1ll_l1_ = l1l11l111ll_l1_.replace(l1l1ll_l1_ (u"ࠨ࡞ࡵࠫ䙪"),l1l1ll_l1_ (u"ࠩࠪ䙫")).replace(l1l1ll_l1_ (u"ࠪࡠࡳ࠭䙬"),l1l1ll_l1_ (u"ࠫࠬ䙭")).strip(l1l1ll_l1_ (u"ࠬࠦࠧ䙮"))
	return l1ll_l1_
def l1ll1ll11l1l_l1_(url,source):
	LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䙯"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡳࡵࡣࡵࡸࡪࡪࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨ䙰")+url+l1l1ll_l1_ (u"ࠨࠢࡠࠫ䙱"))
	l1ll1llll1ll_l1_,link,l111111ll11_l1_ = l1l1ll_l1_ (u"ࠩࡌࡒ࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠭䙲"),l1l1ll_l1_ (u"ࠪࠫ䙳"),l1l1ll_l1_ (u"ࠫࠬ䙴")
	l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1lll1lll111_l1_(url,source)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䙵"),l1l1ll_l1_ (u"࠭ࠧ䙶"),l1l1ll_l1_ (u"ࠧࠨ䙷"),l11l1ll111l_l1_)
	l11l1_l1_ = l111111l1ll_l1_(l11l1_l1_)
	if l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䙸"): return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	elif l11l1_l1_: link = l11l1_l1_[0]
	if l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䙹"):
		#l11l1ll111l_l1_ = l11l1ll111l_l1_.replace(l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䙺"),l1l1ll_l1_ (u"ࠫࠬ䙻"))
		l1ll1llll1ll_l1_ = l1l1ll_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠴ࠫ䙼")
		l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111llll1ll_l1_(link,source)
		l11l1_l1_ = l111111l1ll_l1_(l11l1_l1_)
		if l11l1ll111l_l1_==l1l1ll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䙽"): return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
		elif l1l1ll_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶࠭䙾") in l11l1ll111l_l1_:
			l111111ll11_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠩ䙿")+l11l1ll111l_l1_
			l1ll1llll1ll_l1_ = l1l1ll_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨ䚀")
			l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l111llll1l1_l1_(link,source)
			l11l1_l1_ = l111111l1ll_l1_(l11l1_l1_)
			if l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䚁"): return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
			elif l1l1ll_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䚂") in l11l1ll111l_l1_:
				l111111ll11_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥ࠭䚃")+l11l1ll111l_l1_
				l1ll1llll1ll_l1_ = l1l1ll_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬ䚄")
				l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l11l1ll1111_l1_(link,source)
				l11l1_l1_ = l111111l1ll_l1_(l11l1_l1_)
				if l11l1ll111l_l1_==l1l1ll_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䚅"): return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
				elif l1l1ll_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ䚆") in l11l1ll111l_l1_:
					l111111ll11_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠳࠻ࠢࠪ䚇")+l11l1ll111l_l1_
	elif l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠬ䚈") in l11l1ll111l_l1_: l111111ll11_l1_ = l1l1ll_l1_ (u"ࠫࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠰࠻ࠢࠪ䚉")+l11l1ll111l_l1_
	if l11l1_l1_: LOG_THIS(l1l1ll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䚊"),LOGGING(script_name)+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩ䚋")+l1ll1llll1ll_l1_+l1l1ll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䚌")+url+l1l1ll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䚍")+link+l1l1ll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡓࡧࡶࡹࡱࡺࡳ࠻ࠢ࡞ࠤࠬ䚎")+str(l11l1_l1_)+l1l1ll_l1_ (u"ࠪࠤࡢ࠭䚏"))
	else: LOG_THIS(l1l1ll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ䚐"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ䚑")+url+l1l1ll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䚒")+link+l1l1ll_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡋࡲࡳࡱࡵࡷ࠿࡛ࠦࠡࠩ䚓")+l111111ll11_l1_+l1l1ll_l1_ (u"ࠨࠢࡠࠫ䚔"))
	l111111ll11_l1_ = UNQUOTE(l111111ll11_l1_)
	return l111111ll11_l1_,l111l1l_l1_,l11l1_l1_
def l1lll11l1111_l1_(l1l111ll1l1_l1_,source):
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䚕"),l1l111ll1l1_l1_)
	expiry = l11l1ll_l1_
	data = READ_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䚖"),l1l1ll_l1_ (u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬ䚗"),l1l111ll1l1_l1_)
	if data:
		l111l1l_l1_,l11l1_l1_ = list(zip(*data))
		return l111l1l_l1_,l11l1_l1_
	l111l1l_l1_,l11l1_l1_,l11l1l1lll1_l1_ = [],[],[]
	for link in l1l111ll1l1_l1_:
		if l1l1ll_l1_ (u"ࠬ࠵࠯ࠨ䚘") not in link: continue
		l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_ = l11l1l11lll_l1_(link,source)
		l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡜ࡥ࠭ࠪ䚙"),l11ll1l1_l1_,re.DOTALL)
		if l11ll1l1_l1_: l11ll1l1_l1_ = int(l11ll1l1_l1_[0])
		else: l11ll1l1_l1_ = 0
		#if l11ll1l1_l1_:
		#	l111ll1llll_l1_ = sorted(l11ll1l1_l1_,reverse=True,key=lambda key: int(key))
		#	l11ll1l1_l1_ = int(l111ll1llll_l1_[0])
		#else: l11ll1l1_l1_ = 0
		server = SERVER(link,l1l1ll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䚚"))
		l11l1l1lll1_l1_.append([l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_,link,server])
	if l11l1l1lll1_l1_:
		#l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_,link = zip(*l11l1l1lll1_l1_)
		#name = reversed(name)
		#l11l1l1lll1_l1_ = zip(l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_,link)
		l111111ll1l_l1_ = sorted(l11l1l1lll1_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1111111l11_l1_ = []
		for line in l111111ll1l_l1_:
			if line not in l1111111l11_l1_:
				l1111111l11_l1_.append(line)
				#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ䚛"),str(line))
		for l1lllll111ll_l1_,name,type,l1l111l_l1_,l11ll1l1_l1_,link,server in l1111111l11_l1_:
			if l11ll1l1_l1_: l11ll1l1_l1_ = str(l11ll1l1_l1_)
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠩࠪ䚜")
			#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䚝"),l1l1ll_l1_ (u"ࠫࠬ䚞"),name,link)
			title = l1l1ll_l1_ (u"ู๊ࠬาใิࠫ䚟")+l1l1ll_l1_ (u"࠭ࠠࠨ䚠")+type+l1l1ll_l1_ (u"ࠧࠡࠩ䚡")+l1lllll111ll_l1_+l1l1ll_l1_ (u"ࠨࠢࠪ䚢")+l11ll1l1_l1_+l1l1ll_l1_ (u"ࠩࠣࠫ䚣")+l1l111l_l1_+l1l1ll_l1_ (u"ࠪࠤࠬ䚤")+name
			if server not in title: title = title+l1l1ll_l1_ (u"ࠫࠥ࠭䚥")+server
			title = title.replace(l1l1ll_l1_ (u"ࠬࠫࠧ䚦"),l1l1ll_l1_ (u"࠭ࠧ䚧")).strip(l1l1ll_l1_ (u"ࠧࠡࠩ䚨")).replace(l1l1ll_l1_ (u"ࠨࠢࠣࠫ䚩"),l1l1ll_l1_ (u"ࠩࠣࠫ䚪")).replace(l1l1ll_l1_ (u"ࠪࠤࠥ࠭䚫"),l1l1ll_l1_ (u"ࠫࠥ࠭䚬")).replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ䚭"),l1l1ll_l1_ (u"࠭ࠠࠨ䚮"))
			if link not in l11l1_l1_:
				l111l1l_l1_.append(title)
				l11l1_l1_.append(link)
		if l11l1_l1_:
			#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ䚯"),l11l1_l1_)
			data = list(zip(l111l1l_l1_,l11l1_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䚰"),l1l111ll1l1_l1_,data,expiry)
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ䚱"),l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠻࠴࠽ࠤࠥࠦࠧ䚲")+str(data))
	return l111l1l_l1_,l11l1_l1_
def	l111llll1l1_l1_(url,source):
	#url = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡃࡣ࡚ࡣ࡯࡫࡮ࡰࡼࡎࡧࠬ䚳")
	errortrace = l1l1ll_l1_ (u"ࠬ࠭䚴")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l11l1111_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: errortrace = str(error)
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䚵"),l1l1ll_l1_ (u"ࠧࠨ䚶"),l1l1ll_l1_ (u"ࠨࠩ䚷"),str(results))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䚸"),l1l1ll_l1_ (u"ࠪࠫ䚹"),l1l1ll_l1_ (u"ࠫࠬ䚺"),str(errortrace))
	# resolveurl l111l1l1l1_l1_ fail l1lllll1ll11_l1_ with l1ll1l11111l_l1_ error or l11111l11l1_l1_ value False
	if not results:
		if errortrace==l1l1ll_l1_ (u"ࠬ࠭䚻"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䚼"),l1l1ll_l1_ (u"ࠧࠨ䚽"),l1l1ll_l1_ (u"ࠨࠩ䚾"),str(errortrace))
		l11l1ll111l_l1_ = l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠡࡈࡤ࡭ࡱ࡫ࡤࠨ䚿")
		l11l1ll111l_l1_ += l1l1ll_l1_ (u"ࠪࠤࠬ䛀")+errortrace.splitlines()[-1]
		return l11l1ll111l_l1_,[],[]
	return l1l1ll_l1_ (u"ࠫࠬ䛁"),[l1l1ll_l1_ (u"ࠬ࠭䛂")],[results]
def	l11l1ll1111_l1_(url,source):
	#url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ䛃")
	#url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳ࠯ࡷ࡫ࡧࡩࡴ࠵ࡸ࠸ࡻࡼ࠸࠶ࡹࠧ䛄")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䛅"),l1l1ll_l1_ (u"ࠩࠪ䛆"),url,l1l1ll_l1_ (u"ࠪࠫ䛇"))
	#return l1l1ll_l1_ (u"ࠫࠬ䛈"),[],[]
	errortrace = l1l1ll_l1_ (u"ࠬ࠭䛉")
	results = False
	try:
		import youtube_dl
		l11l1l11111_l1_ = youtube_dl.YoutubeDL({l1l1ll_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ䛊"): True})
		results = l11l1l11111_l1_.extract_info(url,download=False)
	except Exception as error: errortrace = str(error)
	# youtube_dl l111l1l1l1_l1_ fail l1lllll1ll11_l1_ with l1ll1l11111l_l1_ error or l11111l11l1_l1_ value False
	if not results or l1l1ll_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䛋") not in list(results.keys()):
		if errortrace==l1l1ll_l1_ (u"ࠨࠩ䛌"):
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䛍"),l1l1ll_l1_ (u"ࠪࠫ䛎"),l1l1ll_l1_ (u"ࠫࠬ䛏"),errortrace)
		l11l1ll111l_l1_ = l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠤࡋࡧࡩ࡭ࡧࡧࠫ䛐")
		l11l1ll111l_l1_ += l1l1ll_l1_ (u"࠭ࠠࠨ䛑")+errortrace.splitlines()[-1]
		return l11l1ll111l_l1_,[],[]
	else:
		l111l1l_l1_,l11l1_l1_ = [],[]
		for link in results[l1l1ll_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䛒")]:
			l111l1l_l1_.append(link[l1l1ll_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ䛓")])
			l11l1_l1_.append(link[l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭䛔")])
		return l1l1ll_l1_ (u"ࠪࠫ䛕"),l111l1l_l1_,l11l1_l1_
def l11l11llll1_l1_(url):
	if l1l1ll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䛖") in url:
		l111l1l_l1_,l11l1_l1_ = l11lll1lll_l1_(url)
		if l11l1_l1_: return l1l1ll_l1_ (u"ࠬ࠭䛗"),l111l1l_l1_,l11l1_l1_
		return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡅࡗࡇࡂࠨ䛘"),[],[]
	return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䛙"),[l1l1ll_l1_ (u"ࠨࠩ䛚")],[url]
def l1l1ll1l11l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䛛"),l1l1ll_l1_ (u"ࠪࠫ䛜"),l1l1ll_l1_ (u"ࠫࠬ䛝"),url)
	l111ll1_l1_,l1lllll1l1l1_l1_ = [],[]
	if l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠴࡭ࡱ࠶ࡂࡺ࡮ࡪ࠽ࠨ䛞") in url:
		# l1111ll1lll_l1_:
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1ll1llllll1_l1_.html
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l11llll111_l1_.l11l1111_l1_?l1l1ll1ll1l_l1_=49e3a27b4
		# l1llll1l11ll_l1_: l1lll11l_l1_://l11111l1ll1_l1_.l1llll1l11l_l1_.l1ll11lll1l1_l1_.l1llll1lll1_l1_/15/items/40animeHD/l111111lll1_l1_.l11l1111_l1_
		# l1111ll1lll_l1_:
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1lll1l11l1l_l1_-l1111l11l1l_l1_.html
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l11llll111_l1_.l11l1111_l1_?l1l1ll1ll1l_l1_=l1ll1l1ll111_l1_
		# l1llll1l11ll_l1_: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l11llll111_l1_/l1lllllllll1_l1_%20.l11l1111_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䛟"),url,l1l1ll_l1_ (u"ࠧࠨ䛠"),l1l1ll_l1_ (u"ࠨࠩ䛡"),False,l1l1ll_l1_ (u"ࠩࠪ䛢"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠳ࡶࡸࠬ䛣"))
		if l1l1ll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䛤") in response.headers:
			link = response.headers[l1l1ll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䛥")]
			l111ll1_l1_.append(link)
			server = SERVER(link,l1l1ll_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䛦"))
			l1lllll1l1l1_l1_.append(server)
	elif l1l1ll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦ࠰ࡦࡳࡲ࠭䛧") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l1111ll1lll_l1_:
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l11l1l1l_l1_.html
		# link: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l11l1l111ll_l1_/?link=l1lll11l_l1_://drive.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l11111l1_l1_&l1ll1l1l1111_l1_=
		# l1111ll1lll_l1_:
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# link: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l1l1l1l11_l1_.l1lll1ll11_l1_?url=l1ll1l1111ll_l1_==&sub=l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1111lllll1_l1_/l1ll1l1111l1_l1_.l1ll1l1llll1_l1_&l1ll1l1l1111_l1_=l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1lll111l11l_l1_/l1ll11l1ll11_l1_-1.l1lll11lllll_l1_
		# l1111ll1lll_l1_:
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1lllllll1l1_l1_.html
		# link: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l1lllll11111_l1_/?url=l1lll11l_l1_://l1lll1l1l11l_l1_.l11l111ll11_l1_.l1111ll11ll_l1_.l11ll111l1l_l1_/l11111l1l1l_l1_&sub=&l1ll1l1l1111_l1_=http://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1lll111l11l_l1_/4723b8ebe-1.l1lll11lllll_l1_
		# l1111ll1lll_l1_:
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l11lll11_l1_.html
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l11l1l111ll_l1_/?link=l1lll11l_l1_://l111l111l11_l1_.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l11111l1_l1_&sub=&l1ll1l1l1111_l1_=l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1lll111l11l_l1_/2e8bc4c34-1.l1lll11lllll_l1_
		# l1111ll1lll_l1_:
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1lll1ll1l11_l1_.html
		# l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l11l1l111ll_l1_/?link=l1lll11l_l1_://drive.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1111l11_l1_=l11l111111l_l1_&l1ll1l1l1111_l1_=l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1lll111l11l_l1_/l1111ll1ll1_l1_-1.l1lll11lllll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ䛨"),url,l1l1ll_l1_ (u"ࠩࠪ䛩"),l1l1ll_l1_ (u"ࠪࠫ䛪"),l1l1ll_l1_ (u"ࠫࠬ䛫"),l1l1ll_l1_ (u"ࠬ࠭䛬"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠷ࡴࡤࠨ䛭"))
		html = response.content
		l1llll1l111l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࡤ࡝ࠫ࠱࠮ࡄࡢࠩ࡝ࠫࠬ࠲ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ䛮"),html,re.DOTALL)
		#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ䛯"),str(l1llll1l111l_l1_))
		if l1llll1l111l_l1_:
			l1llll1l111l_l1_ = l1llll1l111l_l1_[0]
			l1lll11l1l11_l1_ = l1lll1l111l1_l1_(l1llll1l111l_l1_)
			#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ䛰"),str(l1lll11l1l11_l1_))
			l1lll111l1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨ䛱"),l1lll11l1l11_l1_,re.DOTALL)
			if l1lll111l1l1_l1_:
				l1lll111l1l1_l1_ = l1lll111l1l1_l1_[0]
				l1lll111l1l1_l1_ = EVAL(l1l1ll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䛲"),l1lll111l1l1_l1_)
				for dict in l1lll111l1l1_l1_:
					link = dict[l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࠪ䛳")]
					l11ll1l1_l1_ = dict[l1l1ll_l1_ (u"࠭࡬ࡢࡤࡨࡰࠬ䛴")]
					#link = link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࠪ䛵")+l11ll1l1_l1_
					l111ll1_l1_.append(link)
					server = SERVER(link,l1l1ll_l1_ (u"ࠨࡰࡤࡱࡪ࠭䛶"))
					l1lllll1l1l1_l1_.append(l11ll1l1_l1_+l1l1ll_l1_ (u"ࠩࠣࠫ䛷")+server)
		elif l1l1ll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䛸") in response.headers:
			link = response.headers[l1l1ll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䛹")]
			l111ll1_l1_.append(link)
			server = SERVER(link,l1l1ll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䛺"))
			l1lllll1l1l1_l1_.append(server)
		# l1111ll1lll_l1_: 5
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1lllllll1l1_l1_.html
		# link: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l1ll1l1l1lll_l1_/l1lllll11111_l1_/?url=l1lll11l_l1_://l1lll1l1l11l_l1_.l11l111ll11_l1_.l1111ll11ll_l1_.l11ll111l1l_l1_/l11111l1l1l_l1_&sub=&l1ll1l1l1111_l1_=http://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l1ll1ll1l111_l1_/l1lll111l11l_l1_/4723b8ebe-1.l1lll11lllll_l1_
		if l1l1ll_l1_ (u"࠭࠿ࡶࡴ࡯ࡁ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࡳࡴ࠭䛻") in url:
			link = url.split(l1l1ll_l1_ (u"ࠧࡀࡷࡵࡰࡂ࠭䛼"))[1]
			link = link.split(l1l1ll_l1_ (u"ࠨࠨࠪ䛽"))[0]
			if link:
				l111ll1_l1_.append(link)
				l1lllll1l1l1_l1_.append(l1l1ll_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴࠢࡪࡳࡴ࡭࡬ࡦࠩ䛾"))
	else:
		# l1111ll1lll_l1_:
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1ll1l11lll1_l1_.html
		# link: http://ok.l1111ll1l11_l1_/l111l1l1l11_l1_/1676019108395
		# l1111ll1lll_l1_:
		# url: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1ll1l1l1ll1_l1_.html
		# link: l1lll11l_l1_://drive.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l11111l1_l1_
		l111ll1_l1_.append(url)
		server = SERVER(url,l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥࠨ䛿"))
		l1lllll1l1l1_l1_.append(server)
	if not l111ll1_l1_: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ䜀"),[],[]
	elif len(l111ll1_l1_)==1: link = l111ll1_l1_[0]
	else:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ䜁"),l1lllll1l1l1_l1_)
		if selection==-1: return l1l1ll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䜂"),[],[]
		link = l111ll1_l1_[selection]
	return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䜃"),[l1l1ll_l1_ (u"ࠨࠩ䜄")],[link]
def l1llllllll11_l1_(url):
	# test from: l1lll11l_l1_://l1l1ll1llll_l1_.l1l1ll1l1ll_l1_.l1lll1ll1_l1_/l11lllll1_l1_/l11l1111lll_l1_-l1111111111_l1_-l1llll1l1l11_l1_-l1lll11l1l1l_l1_-arabic-l11llll111_l1_-1-date.html
	# url = l1lll11l_l1_://l111ll11ll1_l1_.l1ll11l1ll1l_l1_.l1lll1ll1_l1_/l1llll11ll11_l1_=l1111l111l1_l1_
	headers = {l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䜅"):l1l1ll_l1_ (u"ࠪࡏࡴࡪࡩ࠰ࠩ䜆")+str(kodi_version)}
	for ii in range(50):
		time.sleep(0.100)
		response = OPENURL_REQUESTS(l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䜇"),url,l1l1ll_l1_ (u"ࠬ࠭䜈"),headers,False,False,l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪ䜉"))
		if l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䜊") in list(response.headers.keys()):
			link = response.headers[l1l1ll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䜋")]
			link = link+l1l1ll_l1_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ䜌")+headers[l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䜍")]
			return l1l1ll_l1_ (u"ࠫࠬ䜎"),[l1l1ll_l1_ (u"ࠬ࠭䜏")],[link]
		if response.code!=429: break
	return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡉࡒࡓࡌࡒࡅࡖࡕࡈࡖࡈࡕࡎࡕࡇࡑࡘࠬ䜐"),[],[]
def l11111llll1_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䜑"),l1l1ll_l1_ (u"ࠨࠩ䜒"),l1l1ll_l1_ (u"ࠩࠪ䜓"),url)
	# l1lll11l_l1_://l1lll1l1l11l_l1_.l11l111ll11_l1_.l1111ll11ll_l1_.l11ll111l1l_l1_/l11111l1l1l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䜔"),url,l1l1ll_l1_ (u"ࠫࠬ䜕"),l1l1ll_l1_ (u"ࠬ࠭䜖"),l1l1ll_l1_ (u"࠭ࠧ䜗"),l1l1ll_l1_ (u"ࠧࠨ䜘"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡎࡏࡕࡑࡖࡋࡔࡕࡇࡍࡇ࠰࠵ࡸࡺࠧ䜙"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠩࠥࠬ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡥࡧࡲ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࠫࡁࠬࠦ࠱࠴ࠪࡀ࠮࠱࠮ࡄ࠲ࠨ࠯ࠬࡂ࠭࠱࠭䜚"),html,re.DOTALL)
	if link:
		link,l11ll1l1_l1_ = link[0]
		return l1l1ll_l1_ (u"ࠪࠫ䜛"),[l11ll1l1_l1_],[link]
	return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬ䜜"),[],[]
def l1ll1lll11l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䜝"),l1l1ll_l1_ (u"࠭ࠧ䜞"),l1l1ll_l1_ (u"ࠧࠨ䜟"),url)
	#url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡰࡰࡨ࠳ࡻ࡯ࡤࡦࡱࡢࡴࡱࡧࡹࡦࡴࡂࡹ࡮ࡪ࠽࠱ࠨࡹ࡭ࡩࡃࡦࡧࡤ࠺࠴࠽ࡩ࠱࠺࠴ࡦ࠶࠽ࡪ࠱࠲࠴࠳࠶ࡦࡪ࠱࠹ࡦࡧ࠵࠷ࡩ࠶࠹࠲࠹ࠫ䜠")
	#url = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡹࡥ࡭ࡪࡧ࠱ࡪࡳࡢࡦࡦ࠱ࡷࡨࡪ࡮࠯ࡶࡲ࠳ࡻ࡯ࡤࡦࡱࡢࡴࡱࡧࡹࡦࡴࡂࡹ࡮ࡪ࠽࠱ࠨࡹ࡭ࡩࡃࡢ࠱࠳࠸࠽࠵࠺ࡡ࠹ࡣࡦࡪ࠼࠿࠵࠷ࡦ࠴ࡩ࠼࠼࠳࠱ࡤࡨ࠵࠼࠼࠵࠹࠹࠶ࠫ䜡")
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䜢"),url,l1l1ll_l1_ (u"ࠫࠬ䜣"),l1l1ll_l1_ (u"ࠬ࠭䜤"),l1l1ll_l1_ (u"࠭ࠧ䜥"),l1l1ll_l1_ (u"ࠧࠨ䜦"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡓࡆࡎࡋࡈ࠶࠳࠱ࡴࡶࠪ䜧"))
	html = response.content
	html = l1lll111l1_l1_(html)
	#WRITE_THIS(l1l1ll_l1_ (u"ࠩࠪ䜨"),html)
	link = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䜩"),html,re.DOTALL)
	if link: return l1l1ll_l1_ (u"ࠫࠬ䜪"),[l1l1ll_l1_ (u"ࠬ࠭䜫")],[link[0]]
	return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䜬"),[],[]
def l1111ll1l_l1_(url):
	if l1l1ll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䜭") in url:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ䜮"),url,l1l1ll_l1_ (u"ࠩࠪ䜯"),l1l1ll_l1_ (u"ࠪࠫ䜰"),l1l1ll_l1_ (u"ࠫࠬ䜱"),l1l1ll_l1_ (u"ࠬ࠭䜲"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭䜳"))
		html = response.content
		link = re.findall(l1l1ll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䜴"),html,re.DOTALL)
		link = link[0]
		if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭䜵") in link: return l1l1ll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䜶"),[l1l1ll_l1_ (u"ࠪࠫ䜷")],[link]
		return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭䜸"),[],[]
	else: return l1l1ll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䜹"),[l1l1ll_l1_ (u"࠭ࠧ䜺")],[url]
def l1llll11ll1_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1ll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䜻"):l1l1ll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䜼"),l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䜽"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䜾")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䜿"),url2,data2,headers2,l1l1ll_l1_ (u"ࠬ࠭䝀"),l1l1ll_l1_ (u"࠭ࠧ䝁"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧ䝂"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䝃"),html,re.DOTALL)
	if not link: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫ䝄"),[],[]
	link = link[0]
	return l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䝅"),[l1l1ll_l1_ (u"ࠫࠬ䝆")],[link]
def l1ll1ll11lll_l1_(url):
	headers = {l1l1ll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䝇"):l1l1ll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䝈")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䝉"),url,l1l1ll_l1_ (u"ࠨࠩ䝊"),headers,l1l1ll_l1_ (u"ࠩࠪ䝋"),l1l1ll_l1_ (u"ࠪࠫ䝌"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭䝍"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䝎"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪ䝏"),[],[]
	link = link[0]
	return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䝐"),[l1l1ll_l1_ (u"ࠨࠩ䝑")],[link]
def l1ll111l11l_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䝒"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䝓")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䝔"),url2,data2,headers2,l1l1ll_l1_ (u"ࠬ࠭䝕"),l1l1ll_l1_ (u"࠭ࠧ䝖"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䝗"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ䝘"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭䝙"),[],[]
	link = link[0]
	if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䝚") not in link: link = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䝛")+link
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䝜"),l1l1ll_l1_ (u"࠭ࠧ䝝"),l1l1ll_l1_ (u"ࠧࠨ䝞"),link)
	return l1l1ll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䝟"),[l1l1ll_l1_ (u"ࠩࠪ䝠")],[link]
def l1llll1lll_l1_(url):
	url2,data2 = URLDECODE(url)
	headers2 = {l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䝡"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䝢")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䝣"),url2,data2,headers2,l1l1ll_l1_ (u"࠭ࠧ䝤"),l1l1ll_l1_ (u"ࠧࠨ䝥"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡃࡅࡈࡔ࠳࠱ࡴࡶࠪ䝦"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ䝧"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡄࡆࡉࡕࠧ䝨"),[],[]
	link = link[0]
	return l1l1ll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䝩"),[l1l1ll_l1_ (u"ࠬ࠭䝪")],[link]
def l111111l111_l1_(url):
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ䝫"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䝬"),url,l1l1ll_l1_ (u"ࠨࠩ䝭"),l1l1ll_l1_ (u"ࠩࠪ䝮"),l1l1ll_l1_ (u"ࠪࠫ䝯"),l1l1ll_l1_ (u"ࠫࠬ䝰"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡖ࡙ࡊ࡚ࡔ࠭࠲ࡵࡷࠫ䝱"))
	html = response.content
	l1ll1l11llll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡶࡢࡴࠣࡪࡸ࡫ࡲࡷࠢࡀ࠲࠯ࡅࠧࠩ࠰࠭ࡃ࠮࠭ࠢ䝲"),html,re.DOTALL|re.IGNORECASE)
	if l1ll1l11llll_l1_:
		l1ll1l11llll_l1_ = l1ll1l11llll_l1_[0][2:]
		#l1ll1l11llll_l1_ = l1ll1l11llll_l1_.decode(l1l1ll_l1_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ䝳"))
		l1ll1l11llll_l1_ = base64.b64decode(l1ll1l11llll_l1_)
		if kodi_version>18.99: l1ll1l11llll_l1_ = l1ll1l11llll_l1_.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭䝴"))
		link = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䝵"),l1ll1l11llll_l1_,re.DOTALL)
	else: link = l1l1ll_l1_ (u"ࠪࠫ䝶")
	if not link: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡔࡗࡈࡘࡒࠬ䝷"),[],[]
	link = link[0]
	if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䝸") not in link: link = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䝹")+link
	return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䝺"),[l1l1ll_l1_ (u"ࠨࠩ䝻")],[link]
def l1ll1ll1llll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䝼"),url,l1l1ll_l1_ (u"ࠪࠫ䝽"),l1l1ll_l1_ (u"ࠫࠬ䝾"),l1l1ll_l1_ (u"ࠬ࠭䝿"),l1l1ll_l1_ (u"࠭ࠧ䞀"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑ࡞ࡋࡇ࡚ࡘࡌࡔ࠲࠷ࡳࡵࠩ䞁"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠳࠵ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䞂"),html,re.DOTALL)
	if not link: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠭䞃"),[],[]
	link = link[0]
	return l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䞄"),[l1l1ll_l1_ (u"ࠫࠬ䞅")],[link]
def l1l1111ll1_l1_(url):
	id = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ䞆"))[-1]
	if l1l1ll_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭䞇") in url: url = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ䞈"),l1l1ll_l1_ (u"ࠨࠩ䞉"))
	url = url.replace(l1l1ll_l1_ (u"ࠩ࠱ࡧࡴࡳ࠯ࠨ䞊"),l1l1ll_l1_ (u"ࠪ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡯ࡨࡸࡦࡪࡡࡵࡣ࠲ࠫ䞋"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䞌"),url,l1l1ll_l1_ (u"ࠬ࠭䞍"),l1l1ll_l1_ (u"࠭ࠧ䞎"),l1l1ll_l1_ (u"ࠧࠨ䞏"),l1l1ll_l1_ (u"ࠨࠩ䞐"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ䞑"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l1l1ll_l1_ (u"ࠪࠫ䞒"),url)
	l11l1ll111l_l1_ = l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ䞓")
	error = re.findall(l1l1ll_l1_ (u"ࠬࠨࡥࡳࡴࡲࡶࠧ࠴ࠪࡀࠤࡰࡩࡸࡹࡡࡨࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䞔"),html,re.DOTALL)
	if error: l11l1ll111l_l1_ = error[0]
	url = re.findall(l1l1ll_l1_ (u"࠭ࡸ࠮࡯ࡳࡩ࡬࡛ࡒࡍࠤ࠯ࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䞕"),html,re.DOTALL)
	if not url and l11l1ll111l_l1_:
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䞖"),l1l1ll_l1_ (u"ࠨࠩ䞗"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠫ䞘"),l11l1ll111l_l1_)
		return l11l1ll111l_l1_,[],[]
	link = url[0].replace(l1l1ll_l1_ (u"ࠪࡠࡡ࠭䞙"),l1l1ll_l1_ (u"ࠫࠬ䞚"))
	l1l111l11l1_l1_,l1l111ll1l1_l1_ = l11lll1lll_l1_(link)
	owner = re.findall(l1l1ll_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䞛"),html,re.DOTALL)
	if owner: l1llll11l11l_l1_,l11l11lllll_l1_,l111l11l1ll_l1_ = owner[0]
	else: l1llll11l11l_l1_,l11l11lllll_l1_,l111l11l1ll_l1_ = l1l1ll_l1_ (u"࠭ࠧ䞜"),l1l1ll_l1_ (u"ࠧࠨ䞝"),l1l1ll_l1_ (u"ࠨࠩ䞞")
	l111l11l1ll_l1_ = l111l11l1ll_l1_.replace(l1l1ll_l1_ (u"ࠩ࡟࠳ࠬ䞟"),l1l1ll_l1_ (u"ࠪ࠳ࠬ䞠"))
	l11l11lllll_l1_ = escapeUNICODE(l11l11lllll_l1_)
	l111l1l_l1_ = [l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䞡")+l11l11lllll_l1_+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䞢")]+l1l111l11l1_l1_
	l11l1_l1_ = [l111l11l1ll_l1_]+l1l111ll1l1_l1_
	selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ䞣")+str(len(l11l1_l1_)-1)+l1l1ll_l1_ (u"ࠧࠡ็็ๅ࠮࠭䞤"),l111l1l_l1_)
	if selection==-1: return l1l1ll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䞥"),[],[]
	elif selection==0:
		new_path = sys.argv[0]+l1l1ll_l1_ (u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠴࠱࠴ࠩࡹࡷࡲ࠽ࠨ䞦")+l111l11l1ll_l1_+l1l1ll_l1_ (u"ࠪࠪࡹ࡫ࡸࡵ࠿ࠪ䞧")+l11l11lllll_l1_
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ䞨")+new_path+l1l1ll_l1_ (u"ࠧ࠯ࠢ䞩"))
		return l1l1ll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䞪"),[],[]
	link =  l11l1_l1_[selection]
	return l1l1ll_l1_ (u"ࠧࠨ䞫"),[l1l1ll_l1_ (u"ࠨࠩ䞬")],[link]
def l111l1ll1_l1_(link):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䞭"),link,l1l1ll_l1_ (u"ࠪࠫ䞮"),l1l1ll_l1_ (u"ࠫࠬ䞯"),l1l1ll_l1_ (u"ࠬ࠭䞰"),l1l1ll_l1_ (u"࠭ࠧ䞱"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆࡔࡑࡒࡂ࠯࠴ࡷࡹ࠭䞲"))
	html = response.content
	if l1l1ll_l1_ (u"ࠨ࠰࡭ࡷࡴࡴࠧ䞳") in link: url = re.findall(l1l1ll_l1_ (u"ࠩࠥࡷࡷࡩࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䞴"),html,re.DOTALL)
	else: url = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䞵"),html,re.DOTALL)
	if not url: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡐࡍࡕࡅࠬ䞶"),[],[]
	url = url[0]
	if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䞷") not in url: url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ䞸")+url
	return l1l1ll_l1_ (u"ࠧࠨ䞹"),[l1l1ll_l1_ (u"ࠨࠩ䞺")],[url]
def l111lll111l_l1_(url):
	# http://l1lll1lll1l1_l1_.l1ll1lllll1l_l1_/l11l1l11ll1_l1_.html?l11l111llll_l1_=l11111111l1_l1_
	# http://l1lll1lll1l1_l1_.l1ll1lllll1l_l1_/l1lllll11ll1_l1_?op=l1ll11llll1l_l1_&id=l11l1l11ll1_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䞻") : l1l1ll_l1_ (u"ࠪࠫ䞼") }
	if l1l1ll_l1_ (u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧ䞽") in url:
		html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠬ࠭䞾"),headers,l1l1ll_l1_ (u"࠭ࠧ䞿"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠷ࡳࡵࠩ䟀"))
		#xbmc.log(html)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䟁"),l1l1ll_l1_ (u"ࠩࠪ䟂"),url,html)
		items = re.findall(l1l1ll_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䟃"),html,re.DOTALL)
		if items: return l1l1ll_l1_ (u"ࠫࠬ䟄"),[l1l1ll_l1_ (u"ࠬ࠭䟅")],[items[0]]
		else:
			message = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䟆"),html,re.DOTALL)
			if message:
				DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䟇"),l1l1ll_l1_ (u"ࠨࠩ䟈"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊วึๆํࠫ䟉"),message[0])
				return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࠫ䟊")+message[0],[],[]
	else:
		#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䟋"),l1l1ll_l1_ (u"ࠬ࠭䟌"),link,l1l1ll_l1_ (u"࠭ࠧ䟍"))
		#url,name2 = url.split(l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䟎"))
		#name2 = name2.lower()
		name2 = l1l1ll_l1_ (u"ࠨ࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧࠫ䟏")
		# l11lllll1_l1_ l1ll_l1_
		html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䟐"),headers,l1l1ll_l1_ (u"ࠪࠫ䟑"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠵ࡲࡩ࠭䟒"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡌ࡯ࡳ࡯ࠣࡱࡪࡺࡨࡰࡦࡀࠦࡕࡕࡓࡕࠤࠣࡥࡨࡺࡩࡰࡰࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䟓"),html,re.DOTALL)
		if not l1lll11_l1_: return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䟔"),[],[]
		l111111l1_l1_ = l1lll11_l1_[0][0]
		block = l1lll11_l1_[0][1]
		if l1l1ll_l1_ (u"ࠧ࠯ࡴࡤࡶࠬ䟕") in block or l1l1ll_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠭䟖") in block: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡐࡓࡘࡎࡁࡉࡆࡄࠤࡓࡵࡴࠡࡣࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠧ䟗"),[],[]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䟘"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lll1l11_l1_(payload)
		html = OPENURL_CACHED(l1llll1l1_l1_,l111111l1_l1_,data,headers,l1l1ll_l1_ (u"ࠫࠬ䟙"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠷ࡷࡪࠧ䟚"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࠡࡘ࡬ࡨࡪࡵ࠮ࠫࡁࡪࡩࡹࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࠯ࠬࡂ࠭࡮ࡳࡡࡨࡧ࠽ࠫ䟛"),html,re.DOTALL)
		if not l1lll11_l1_: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫ䟜"),[],[]
		download = l1lll11_l1_[0][0]
		block = l1lll11_l1_[0][1]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣ࠰࠭ࡃࠧࢂࠩࠨ䟝"),block,re.DOTALL)
		l1ll1llll111_l1_,l111l1l_l1_,l11l1111111_l1_,l11l1_l1_,l1lll1l1l111_l1_ = [],[],[],[],[]
		for link,title in items:
			if l1l1ll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䟞") in link:
				l1ll1llll111_l1_,l11l1111111_l1_ = l11lll1lll_l1_(link)
				l11l1_l1_ = l11l1_l1_ + l11l1111111_l1_
				if l1ll1llll111_l1_[0]==l1l1ll_l1_ (u"ࠪ࠱࠶࠭䟟"): l111l1l_l1_.append(l1l1ll_l1_ (u"ู๊ࠫࠥาใิࠤำอีࠡࠩ䟠")+l1l1ll_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠫ䟡")+name2)
				else:
					for title in l1ll1llll111_l1_:
						l111l1l_l1_.append(l1l1ll_l1_ (u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫ䟢")+l1l1ll_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥ࠭䟣")+name2+l1l1ll_l1_ (u"ࠨࠢࠪ䟤")+title)
			else:
				title = title.replace(l1l1ll_l1_ (u"ࠩ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠫ䟥"),l1l1ll_l1_ (u"ࠪࠫ䟦"))
				title = title.strip(l1l1ll_l1_ (u"ࠫࠧ࠭䟧"))
				#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䟨"),l1l1ll_l1_ (u"࠭ࠧ䟩"),title,str(l1lll1l1l111_l1_))
				title = l1l1ll_l1_ (u"ࠧࠡีํีๆืࠠࠡะสูࠥ࠭䟪")+l1l1ll_l1_ (u"ࠨࠢࡰࡴ࠹ࠦࠧ䟫")+name2+l1l1ll_l1_ (u"ࠩࠣࠫ䟬")+title
				l111l1l_l1_.append(title)
				l11l1_l1_.append(link)
		# download l1ll_l1_
		link = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬ䟭") + download
		html = OPENURL_CACHED(l1llll1l1_l1_,link,l1l1ll_l1_ (u"ࠫࠬ䟮"),headers,l1l1ll_l1_ (u"ࠬ࠭䟯"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠺ࡺࡨࠨ䟰"))
		items = re.findall(l1l1ll_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯ࠦ䟱"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l1ll_l1_ (u"ࠨࠢึ๎ึ็ัࠡฬะ้๏๊ࠠฯษุࠤࠬ䟲")+l1l1ll_l1_ (u"ࠩࠣࡱࡵ࠺ࠠࠨ䟳")+name2+l1l1ll_l1_ (u"ࠪࠤࠬ䟴")+resolution.split(l1l1ll_l1_ (u"ࠫࡽ࠭䟵"))[1]
			link = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ䟶")+id+l1l1ll_l1_ (u"࠭ࠦ࡮ࡱࡧࡩࡂ࠭䟷")+mode+l1l1ll_l1_ (u"ࠧࠧࡪࡤࡷ࡭ࡃࠧ䟸")+hash
			l1lll1l1l111_l1_.append(resolution)
			l111l1l_l1_.append(title)
			l11l1_l1_.append(link)
		l1lll1l1l111_l1_ = set(l1lll1l1l111_l1_)
		l1lll1lllll1_l1_,l111l11llll_l1_ = [],[]
		for title in l111l1l_l1_:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䟹"),l1l1ll_l1_ (u"ࠩࠪ䟺"),title,l1l1ll_l1_ (u"ࠪࠫ䟻"))
			res = re.findall(l1l1ll_l1_ (u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦ䟼"),title+l1l1ll_l1_ (u"ࠬࠬࠦࠨ䟽"),re.DOTALL)
			for resolution in l1lll1l1l111_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l1ll_l1_ (u"࠭ࡸࠨ䟾"))[1])
			l1lll1lllll1_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l11l1_l1_)):
			items = re.findall(l1l1ll_l1_ (u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣ䟿"),l1l1ll_l1_ (u"ࠨࠨࠩࠫ䠀")+l1lll1lllll1_l1_[i]+l1l1ll_l1_ (u"ࠩࠩࠪࠬ䠁"),re.DOTALL)
			l111l11llll_l1_.append( [l1lll1lllll1_l1_[i],l11l1_l1_[i],items[0][0],items[0][1]] )
		l111l11llll_l1_ = sorted(l111l11llll_l1_, key=lambda x: x[3], reverse=True)
		l111l11llll_l1_ = sorted(l111l11llll_l1_, key=lambda x: x[2], reverse=False)
		l111l1l_l1_,l11l1_l1_ = [],[]
		for i in range(len(l111l11llll_l1_)):
			l111l1l_l1_.append(l111l11llll_l1_[i][0])
			l11l1_l1_.append(l111l11llll_l1_[i][1])
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䠂"),[],[]
	return l1l1ll_l1_ (u"ࠫࠬ䠃"),l111l1l_l1_,l11l1_l1_
def l111l1ll11l_l1_(url):
	# http://l1ll11llll11_l1_.l1lll1ll1_l1_/717254
	parts = url.split(l1l1ll_l1_ (u"ࠬࡅࠧ䠄"))
	url2 = parts[0]
	headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䠅") : l1l1ll_l1_ (u"ࠧࠨ䠆") }
	html = OPENURL_CACHED(l1llll1l1_l1_,url2,l1l1ll_l1_ (u"ࠨࠩ䠇"),headers,l1l1ll_l1_ (u"ࠩࠪ䠈"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࠶ࡖࡖࡅࡗ࠳࠱ࡴࡶࠪ䠉"))
	items = re.findall(l1l1ll_l1_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡼࡧࡩࡵ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ䠊"),html,re.DOTALL)
	url = items[0]
	#l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll1ll11_l1_(url)
	#return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	return l1l1ll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䠋"),[l1l1ll_l1_ (u"࠭ࠧ䠌")],[url]
def l1llll1lllll_l1_(url):
	# l1lll11l_l1_://l1llllll1l1_l1_.l1llll1lll1_l1_/l1lllllll1l_l1_
	# l1lll11l_l1_://l1llll1llll_l1_.cc/l1lllllll1l_l1_
	l111l1l_l1_,l11l1_l1_ = [],[]
	headers = { l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䠍") : l1l1ll_l1_ (u"ࠨࠩ䠎") }
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䠏"),headers,l1l1ll_l1_ (u"ࠪࠫ䠐"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ䠑"))
	url2 = re.findall(l1l1ll_l1_ (u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䠒"),html,re.DOTALL)
	if url2: return l1l1ll_l1_ (u"࠭ࠧ䠓"),[l1l1ll_l1_ (u"ࠧࠨ䠔")],[url2[0]]
	else: return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠫ䠕"),[],[]
def l111l1lll11_l1_(url):
	# l1lll11l_l1_://l1llllll1l1_l1_.l1llll1lll1_l1_/l1lllllll1l_l1_
	# l1lll11l_l1_://l1llll1llll_l1_.cc/l1lllllll1l_l1_
	l111l1l_l1_,l11l1_l1_ = [],[]
	headers = { l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䠖") : l1l1ll_l1_ (u"ࠪࠫ䠗") }
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠫࠬ䠘"),headers,l1l1ll_l1_ (u"ࠬ࠭䠙"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ䠚"))
	url2 = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪ䠛"),html,re.DOTALL)
	if url2: return l1l1ll_l1_ (u"ࠨࠩ䠜"),[l1l1ll_l1_ (u"ࠩࠪ䠝")],[url2[0]]
	else: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠫ䠞"),[],[]
def l1ll1lll1ll_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䠟"),l1l1ll_l1_ (u"ࠬ࠭䠠"),l1l1ll_l1_ (u"࠭ࠧ䠡"),url)
	# l11lllll1_l1_    l1lll11l_l1_://show.l1llll11lll1_l1_.l1lll1ll1_l1_/l1llll1111ll_l1_-l1lll1llllll_l1_/l1lll1llllll_l1_-l1111l11lll_l1_.l1lll1ll11_l1_?action=l1lll1l1l1l1_l1_&l111ll_l1_=32513&l1ll1llll11_l1_=1&type=l1llllll1ll_l1_
	# download l1lll11l_l1_://show.l1llll11lll1_l1_.l1lll1ll1_l1_/l1ll_l1_/l1ll1ll1l11l_l1_
	l111l1l_l1_,l11l1_l1_,errno = [],[],l1l1ll_l1_ (u"ࠧࠨ䠢")
	# l11lllll1_l1_
	if l1l1ll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡧࡤ࡮࡫ࡱ࠳ࠬ䠣") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1ll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䠤"):l1l1ll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䠥")}
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䠦"),url2,data2,headers2,l1l1ll_l1_ (u"ࠬ࠭䠧"),l1l1ll_l1_ (u"࠭ࠧ䠨"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠲࡯ࡦࠪ䠩"))
		l1l11ll1_l1_ = response.content
		if l1l11ll1_l1_.startswith(l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭䠪")): url2 = l1l11ll1_l1_
		else:
			url3 = re.findall(l1l1ll_l1_ (u"ࠩࠪࠫࡸࡸࡣ࠾࡝ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࠬࠨ࡝ࠨࠩࠪ䠫"),l1l11ll1_l1_,re.DOTALL)
			if url3:
				url2 = url3[0]
				url3 = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡀࠬ࠳࠰࠿ࠪࠦࠪ䠬"),url2,re.DOTALL)
				if url3:
					url2 = UNQUOTE(url3[0])
					return l1l1ll_l1_ (u"ࠫࠬ䠭"),[l1l1ll_l1_ (u"ࠬ࠭䠮")],[url2]
	# download
	elif l1l1ll_l1_ (u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧ䠯") in url:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䠰"),url,l1l1ll_l1_ (u"ࠨࠩ䠱"),l1l1ll_l1_ (u"ࠩࠪ䠲"),True,l1l1ll_l1_ (u"ࠪࠫ䠳"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧ䠴"))
		l1l11ll1_l1_ = response.content
		if l1l1ll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䠵") in list(response.headers.keys()): url2 = response.headers[l1l1ll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䠶")]
		else: url2 = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䠷"),l1l11ll1_l1_,re.DOTALL)[0]
		#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䠸"),l1l1ll_l1_ (u"ࠩࠪ䠹"),url2,str(2222))
	if l1l1ll_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䠺") in url2 or l1l1ll_l1_ (u"ࠫ࠴࡬࠯ࠨ䠻") in url2:
		url2 = url2.replace(l1l1ll_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䠼"),l1l1ll_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ䠽"))
		url2 = url2.replace(l1l1ll_l1_ (u"ࠧ࠰ࡸ࠲ࠫ䠾"),l1l1ll_l1_ (u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧ䠿"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䡀"),l1l1ll_l1_ (u"ࠪࠫ䡁"),url2,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䡂"),url2,l1l1ll_l1_ (u"ࠬ࠭䡃"),l1l1ll_l1_ (u"࠭ࠧ䡄"),l1l1ll_l1_ (u"ࠧࠨ䡅"),l1l1ll_l1_ (u"ࠨࠩ䡆"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠵ࡵࡨࠬ䡇"))
		l1l11ll1_l1_ = response.content
		items = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡲࡡࡣࡧ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䡈"),l1l11ll1_l1_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l1l1ll_l1_ (u"ࠫࡡࡢࠧ䡉"),l1l1ll_l1_ (u"ࠬ࠭䡊"))
				l111l1l_l1_.append(title)
				l11l1_l1_.append(link)
		else:
			items = re.findall(l1l1ll_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䡋"),l1l11ll1_l1_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l1l1ll_l1_ (u"ࠧ࡝࡞ࠪ䡌"),l1l1ll_l1_ (u"ࠨࠩ䡍"))
				l111l1l_l1_.append(l1l1ll_l1_ (u"ࠩࠪ䡎"))
				l11l1_l1_.append(link)
	else: return l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䡏"),[l1l1ll_l1_ (u"ࠫࠬ䡐")],[url2]
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䡑"),l1l1ll_l1_ (u"࠭ࠧ䡒"),str(data2),url2)
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ䡓"),[],[]
	return l1l1ll_l1_ (u"ࠨࠩ䡔"),l111l1l_l1_,l11l1_l1_
def l1l111l1111_l1_(url):
	# l11lllll1_l1_ l11l1111_l1_  l1lll11l_l1_://l1llllll1ll1_l1_.l111llllll1_l1_.l1llll1lll1_l1_/l1lll11llll1_l1_/l1ll11l1l11l_l1_.l1lll1ll11_l1_?s=07&id=l11l1ll1l11_l1_,&img=2wh9shmvcTypozADtS8EpvgrwWS.l1lll11lllll_l1_&l111l111l1l_l1_=l1ll1l11ll11_l1_&l1llll1ll11l_l1_=l1ll11ll1l1l_l1_
	# l11lllll1_l1_ l11111ll_l1_ l1lll11l_l1_://l11l11111ll_l1_.l111llllll1_l1_.l1llll1lll1_l1_/l1lll11llll1_l1_/l1ll1l1ll1ll_l1_.l1lll1ll11_l1_?l111ll11l11_l1_=l1lll1lll1ll_l1_&l111111llll_l1_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1lll11lllll_l1_&l111l111l1l_l1_=l1ll1l11ll11_l1_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1lll11lllll_l1_&l111l111l1l_l1_=l1ll1l11ll11_l1_&l1llll1ll11l_l1_=l1lll1111lll_l1_
	# download l1lll11l_l1_://l1l1ll1llll_l1_.l111lll1111_l1_.l1llll111l11_l1_/l111l11ll11_l1_?server=l1ll1l1ll11l_l1_&id=l111l1lllll_l1_,,
	# l1l1l1l11_l1_ l1lll11l_l1_://l111lll1111_l1_.l1llll1111_l1_/l1l1l1l11_l1_/l1111llll1l_l1_
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䡕"),url,l1l1ll_l1_ (u"ࠪࠫ䡖"),l1l1ll_l1_ (u"ࠫࠬ䡗"),l1l1ll_l1_ (u"ࠬ࠭䡘"),l1l1ll_l1_ (u"࠭ࠧ䡙"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠵ࡸࡺࠧ䡚"))
	html = response.content
	l111l1l_l1_,l11l1_l1_,errno = [],[],l1l1ll_l1_ (u"ࠨࠩ䡛")
	if l1l1ll_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ䡜") in url or l1l1ll_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ䡝") in url:
		if l1l1ll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡪࡳࡢࡦࡦ࠱ࡴ࡭ࡶࠧ䡞") in url:
			url2 = re.findall(l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䡟"),html,re.DOTALL)
			url2 = url2[0]
		else: url2 = url
		if l1l1ll_l1_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭䡠") not in url2: return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䡡"),[l1l1ll_l1_ (u"ࠨࠩ䡢")],[url2]
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䡣"),url2,l1l1ll_l1_ (u"ࠪࠫ䡤"),l1l1ll_l1_ (u"ࠫࠬ䡥"),l1l1ll_l1_ (u"ࠬ࠭䡦"),l1l1ll_l1_ (u"࠭ࠧ䡧"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠶ࡳࡪࠧ䡨"))
		html = response.content
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࡬ࡶࠫ䡩"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䡪"),block,re.DOTALL)
		if items:
			for link,l1llll11l1ll_l1_ in items:
				l111l1l_l1_.append(l1llll11l1ll_l1_)
				l11l1_l1_.append(link)
	elif l1l1ll_l1_ (u"ࠪࡱࡦ࡯࡮ࡠࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࠬ䡫") in url:
		url2 = re.findall(l1l1ll_l1_ (u"ࠫࡺࡸ࡬࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ䡬"),html,re.DOTALL)
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ䡭"),url2,l1l1ll_l1_ (u"࠭ࠧ䡮"),l1l1ll_l1_ (u"ࠧࠨ䡯"),l1l1ll_l1_ (u"ࠨࠩ䡰"),l1l1ll_l1_ (u"ࠩࠪ䡱"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠳ࡳࡦࠪ䡲"))
		html = response.content
		url3 = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䡳"),html,re.DOTALL)
		url3 = url3[0]
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠬ࠭䡴"))
		l11l1_l1_.append(url3)
	elif l1l1ll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠ࡮࡬ࡲࡰ࠭䡵") in url:
		url2 = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡥࡨࡲࡹ࡫ࡲ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䡶"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			return l1l1ll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䡷"),[l1l1ll_l1_ (u"ࠩࠪ䡸")],[url2]
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡗࡕ࠷࡙ࠬ䡹"),[],[]
	return l1l1ll_l1_ (u"ࠫࠬ䡺"),l111l1l_l1_,l11l1_l1_
def l1111llll1_l1_(url):
	# l1lll11l_l1_://l111l1llll1_l1_.l1llllllllll_l1_/l11l111l11l_l1_?call=l111l111111_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111llll_l1_=l1llllllll1l_l1_
	# l1lll11l_l1_://l111l1llll1_l1_.l1llllllllll_l1_/l11l111l11l_l1_?call=l111l111111_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l111llll_l1_=l1llll1111l1_l1_
	url2 = url.split(l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䡻"),1)[0].strip(l1l1ll_l1_ (u"࠭࠿ࠨ䡼")).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ䡽")).strip(l1l1ll_l1_ (u"ࠨࠨࠪ䡾"))
	l111l1l_l1_,l11l1_l1_,items,url3 = [],[],[],l1l1ll_l1_ (u"ࠩࠪ䡿")
	headers = { l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䢀"):l1l1ll_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ䢁") }
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ䢂"),url2,l1l1ll_l1_ (u"࠭ࠧ䢃"),headers,True,l1l1ll_l1_ (u"ࠧࠨ䢄"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩ䢅"))
	if l1l1ll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䢆") in list(response.headers.keys()): url3 = response.headers[l1l1ll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䢇")]
	#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䢈"),url3,l1l1ll_l1_ (u"ࠬ࠭䢉"),headers,False,l1l1ll_l1_ (u"࠭ࠧ䢊"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠷ࡴࡤࠨ䢋"))
	#if l1l1ll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䢌") in response.headers: url3 = response.headers[l1l1ll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䢍")]
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䢎"),l1l1ll_l1_ (u"ࠫࠬ䢏"),url3,response.content)
	if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䢐") in url3:
		# l1lll11l_l1_://l111l11l11_l1_.top/f/l1111l1ll11_l1_/?l11l111lll_l1_=l11ll111111_l1_
		# l1lll11l_l1_://l111l11l11_l1_.top/v/l1111l1ll11_l1_/?l11l111lll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䢑") in url: url3 = url3.replace(l1l1ll_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䢒"),l1l1ll_l1_ (u"ࠨ࠱ࡹ࠳ࠬ䢓"))
		l11l11l1l11_l1_ = url2.split(l1l1ll_l1_ (u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ䢔"))[1]
		headers = { l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䢕"):headers[l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䢖")] , l1l1ll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䢗"):l1l1ll_l1_ (u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ䢘")+l11l11l1l11_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䢙"),url3,l1l1ll_l1_ (u"ࠨࠩ䢚"),headers,False,l1l1ll_l1_ (u"ࠩࠪ䢛"),l1l1ll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭䢜"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1llll1l1_l1_,url3,l1l1ll_l1_ (u"ࠫࠬ䢝"),headers,l1l1ll_l1_ (u"ࠬ࠭䢞"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠷ࡷࡪࠧ䢟"))
		if l1l1ll_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䢠") in url3: items = re.findall(l1l1ll_l1_ (u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䢡"),html,re.DOTALL)
		elif l1l1ll_l1_ (u"ࠩ࠲ࡺ࠴࠭䢢") in url3: items = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䢣"),html,re.DOTALL)
		if items: return [],[l1l1ll_l1_ (u"ࠫࠬ䢤")],[ items[0] ]
		elif l1l1ll_l1_ (u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫ䢥") in html:
			return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩ䢦"),[],[]
	else: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪ䢧"),[],[]
	#xbmc.log(html)
def l111l1l1lll_l1_(link):
	# l1lll11l_l1_://l11ll1111ll_l1_.l1ll1ll1_l1_/?l1l11lll_l1_=147043&l1l1l11l_l1_=5
	parts = re.findall(l1l1ll_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ䢨"),link+l1l1ll_l1_ (u"ࠩࠩࠪࠬ䢩"),re.DOTALL|re.IGNORECASE)
	l1l11lll_l1_,l1l1l11l_l1_ = parts[0]
	url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ䢪")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䢫")+l1l1l11l_l1_
	headers = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䢬"):l1l1ll_l1_ (u"࠭ࠧ䢭") , l1l1ll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䢮"):l1l1ll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䢯") }
	url2 = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䢰"),headers,l1l1ll_l1_ (u"ࠪࠫ䢱"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪ䢲"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䢳"),l1l1ll_l1_ (u"࠭ࠧ䢴"),url,url2)
	#l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll1ll11_l1_(url2)
	#return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䢵"),[l1l1ll_l1_ (u"ࠨࠩ䢶")],[url2]
def l1l1111lll1_l1_(url):
	# l1lll11l_l1_://l1ll11lll11l_l1_.l11lll11l1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1111l1l1ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111l1l1ll1_l1_=1608181746
	server = SERVER(url,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭䢷"))
	headers2 = {l1l1ll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䢸"):server,l1l1ll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䢹"):l1l1ll_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䢺")}
	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䢻"),url,l1l1ll_l1_ (u"ࠧࠨ䢼"),headers2,l1l1ll_l1_ (u"ࠨࠩ䢽"),l1l1ll_l1_ (u"ࠩࠪ䢾"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䢿"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ䣀"),html,re.DOTALL)
	url2 = l1l1ll_l1_ (u"ࠬ࠭䣁")
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䣂"),block,re.DOTALL)
		l111l1l_l1_,l11l1_l1_ = [],[]
		for title,link in items:
			l111l1l_l1_.append(title)
			l11l1_l1_.append(link)
		if len(l11l1_l1_)==1: url2 = l11l1_l1_[0]
		elif len(l11l1_l1_)>1:
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ䣃"), l111l1l_l1_)
			if selection==-1: return l1l1ll_l1_ (u"ࠨࠩ䣄"),[],[]
			url2 = l11l1_l1_[selection]
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䣅"),html,re.DOTALL)
		if l1lll11_l1_: url2 = l1lll11_l1_[0]
	if not url2: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬ䣆"),[],[]
	return l1l1ll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䣇"),[l1l1ll_l1_ (u"ࠬ࠭䣈")],[url2]
def l1lll111l111_l1_(url):
	# l1lll11l_l1_://l11ll111l11_l1_.l1ll1ll1lll1_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1111l1l1ll_l1_=0GfHI4TukZPPkW7vi8eP8Q&l111l1l1ll1_l1_=1608181746
	# l1lll11l_l1_://l11ll111l11_l1_.l1llllllllll_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l1111l1l1ll_l1_=l11l1l1l1l1_l1_&l111l1l1ll1_l1_=1684182121
	server = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䣉"))
	headers2 = {l1l1ll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䣊"):server,l1l1ll_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ䣋"):l1l1ll_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ䣌")}
	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䣍"),url,l1l1ll_l1_ (u"ࠫࠬ䣎"),headers2,l1l1ll_l1_ (u"ࠬ࠭䣏"),l1l1ll_l1_ (u"࠭ࠧ䣐"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ䣑"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ䣒"),html,re.DOTALL)
	url2 = l1l1ll_l1_ (u"ࠩࠪ䣓")
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䣔"),block,re.DOTALL)
		l111l1l_l1_,l11l1_l1_ = [],[]
		for title,link in items:
			l111l1l_l1_.append(title)
			l11l1_l1_.append(link)
		if len(l11l1_l1_)==1: url2 = l11l1_l1_[0]
		elif len(l11l1_l1_)>1:
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ䣕"), l111l1l_l1_)
			if selection==-1: return l1l1ll_l1_ (u"ࠬ࠭䣖"),[],[]
			url2 = l11l1_l1_[selection]
	if not url2:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䣗"),html,re.DOTALL)
		if l1lll11_l1_: url2 = l1lll11_l1_[0]
	if not url2: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ䣘"),[],[]
	return l1l1ll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䣙"),[l1l1ll_l1_ (u"ࠩࠪ䣚")],[url2]
def l1ll111l_l1_(link):
	# l1lll11l_l1_://w.l1lll1ll11ll_l1_.l111lll1l1l_l1_/l1llll1111ll_l1_-content/l11l1ll11ll_l1_/l1lll1l1lll1_l1_/l111lll11ll_l1_/l1lll1l1ll1l_l1_/l1llllll1l1l_l1_/l1llll111ll1_l1_.l1lll1ll11_l1_?l1l11lll_l1_=42869&l1l1l11l_l1_=4
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䣛"),l1l1ll_l1_ (u"ࠫࠬ䣜"),link,html)
	parts = re.findall(l1l1ll_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ䣝"),link+l1l1ll_l1_ (u"࠭ࠦࠧࠩ䣞"),re.DOTALL)
	url,l1l11lll_l1_,l1l1l11l_l1_ = parts[0]
	data = {l1l1ll_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨ䣟"):l1l11lll_l1_,l1l1ll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ䣠"):l1l1l11l_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䣡"),url,data,l1l1ll_l1_ (u"ࠪࠫ䣢"),l1l1ll_l1_ (u"ࠫࠬ䣣"),l1l1ll_l1_ (u"ࠬ࠭䣤"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ䣥"))
	html = response.content
	url2 = re.findall(l1l1ll_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䣦"),html,re.DOTALL)[0]
	return l1l1ll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䣧"),[l1l1ll_l1_ (u"ࠩࠪ䣨")],[url2]
def l1lll11l1l_l1_(url):
	# l1lll11l_l1_://l111l1l111l_l1_.l1lll1llll_l1_-l111l1lll1l_l1_.l1lll1ll1_l1_/l1l1l1l11_l1_.l1lll1ll11_l1_?l1l1ll1ll1l_l1_=l1llll1ll1ll_l1_
	# l1lll11l_l1_://l.l1llll111lll_l1_.l1llll111l11_l1_/l1l1l1l11_l1_.l1lll1ll11_l1_?l1l1ll1ll1l_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䣩"),url,l1l1ll_l1_ (u"ࠫࠬ䣪"),l1l1ll_l1_ (u"ࠬ࠭䣫"),l1l1ll_l1_ (u"࠭ࠧ䣬"),l1l1ll_l1_ (u"ࠧࠨ䣭"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ䣮"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䣯"),html,re.DOTALL)
	if link:
		link = link[0]
		if link: return l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䣰"),[l1l1ll_l1_ (u"ࠫࠬ䣱")],[link]
	return l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ䣲"),[],[]
def l1llll11l1_l1_(url):
	# l1lll11l_l1_://l1lll1lll1_l1_.l1lll1llll_l1_-l1llll1111_l1_.l1llll1111_l1_/l1llll1111ll_l1_-content/l11l1ll11ll_l1_/old/l111l1_l1_/server.l1lll1ll11_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䣳"),url,l1l1ll_l1_ (u"ࠧࠨ䣴"),l1l1ll_l1_ (u"ࠨࠩ䣵"),l1l1ll_l1_ (u"ࠩࠪ䣶"),l1l1ll_l1_ (u"ࠪࠫ䣷"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡑ࠯࠴ࡷࡹ࠭䣸"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠬࡂࡉࡇࡔࡄࡑࡊࠦࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䣹"),html,re.DOTALL)[0]
	return l1l1ll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䣺"),[l1l1ll_l1_ (u"ࠧࠨ䣻")],[link]
def l1lll11l11_l1_(url):
	# l1lll11l_l1_://l1111lll1l1_l1_.l1ll1l1l1l11_l1_.cc/l1llll1111ll_l1_-content/l11l1ll11ll_l1_/l1lll1111111_l1_%20Now%20New/l1ll1ll11ll1_l1_.l1lll1ll11_l1_?action=l111l1ll1l1_l1_&index=00&id=58504
	# l1lll11l_l1_://l1111l1l1l1_l1_.l1ll1l1l1l11_l1_.l1ll1ll1_l1_/l1ll1ll1l111_l1_/2021/04/05/_1llll1lll1l_l1_-l11l1lllll1_l1_.l1ll11l1l1ll_l1_ 200.l1ll1l1lllll_l1_.2020.l1ll1lll11l1_l1_/[l1lll1111111_l1_-l11l1lllll1_l1_.l1lll11l111l_l1_] 200.l1ll1l1lllll_l1_.2020.l1ll1lll11l1_l1_-360p.l11l1111_l1_
	l1111111l_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䣼"))
	if l1l1ll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ䣽") in url:
		headers = {l1l1ll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䣾"):l1111111l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䣿"),url,l1l1ll_l1_ (u"ࠬ࠭䤀"),headers,l1l1ll_l1_ (u"࠭ࠧ䤁"),l1l1ll_l1_ (u"ࠧࠨ䤂"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ䤃"))
		html = response.content
		url2 = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䤄"),html,re.DOTALL)
		if url2:
			url2 = url2[0]
			if l1l1ll_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ䤅") in url2:
				url2 = url2.replace(l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭䤆"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䤇"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䤈"),url2,l1l1ll_l1_ (u"ࠧࠨ䤉"),headers,l1l1ll_l1_ (u"ࠨࠩ䤊"),l1l1ll_l1_ (u"ࠩࠪ䤋"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ䤌"))
				l1l11ll1_l1_ = response.content
				items = re.findall(l1l1ll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤍"),l1l11ll1_l1_,re.DOTALL)
				l111l1l_l1_,l11l1_l1_ = [],[]
				l11111111_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ䤎"))
				for link,l11ll1l1_l1_ in reversed(items):
					link = l11111111_l1_+link+l1l1ll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䤏")+l11111111_l1_
					l111l1l_l1_.append(l11ll1l1_l1_)
					l11l1_l1_.append(link)
				return l1l1ll_l1_ (u"ࠧࠨ䤐"),l111l1l_l1_,l11l1_l1_
			else: return l1l1ll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䤑"),[l1l1ll_l1_ (u"ࠩࠪ䤒")],[url2]
	url2 = url+l1l1ll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䤓")+l1111111l_l1_
	return l1l1ll_l1_ (u"ࠫࠬ䤔"),[l1l1ll_l1_ (u"ࠬ࠭䤕")],[url2]
def l111111l1l1_l1_(link):
	# l1lll11l_l1_://l1ll1l1l1l11_l1_.l111lll1l1l_l1_/l1llll1111ll_l1_-content/l11l1ll11ll_l1_/l111l1ll111_l1_/l1ll1ll1l1l1_l1_/server.l1lll1ll11_l1_?l1l11lll_l1_=42869&l1l1l11l_l1_=4
	# l1lll11l_l1_://l11l1111ll1_l1_.l1ll1l1l1l11_l1_.l1ll1ll1_l1_/l1ll1ll1l111_l1_/2020/08/14/_1llll1lll1l_l1_-l11l1lllll1_l1_.l1ll11l1l1ll_l1_ l1ll1lllll11_l1_.l111111111l_l1_.2020.l1lllll11lll_l1_-l1111111ll1_l1_/[l1lll1111111_l1_-l11l1lllll1_l1_.l1lll11l111l_l1_] l1ll1lllll11_l1_.l111111111l_l1_.2020.l1lllll11lll_l1_-l1111111ll1_l1_-1080p.l11l1111_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䤖"),l1l1ll_l1_ (u"ࠧࠨ䤗"),url,html)
	l1111111l_l1_ = SERVER(link,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䤘"))
	if l1l1ll_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ䤙") in link:
		parts = re.findall(l1l1ll_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䤚"),link+l1l1ll_l1_ (u"ࠫࠫࠬࠧ䤛"),re.DOTALL)
		url,l1l11lll_l1_,l1l1l11l_l1_ = parts[0]
		data = {l1l1ll_l1_ (u"ࠬ࡯ࡤࠨ䤜"):l1l11lll_l1_,l1l1ll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭䤝"):l1l1l11l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䤞"),url,data,l1l1ll_l1_ (u"ࠨࠩ䤟"),l1l1ll_l1_ (u"ࠩࠪ䤠"),l1l1ll_l1_ (u"ࠪࠫ䤡"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ䤢"))
		html = response.content
		url2 = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤣"),html,re.DOTALL)[0]
		if l1l1ll_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䤤") in url2:
			headers = {l1l1ll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䤥"):l1111111l_l1_,l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䤦"):l1l1ll_l1_ (u"ࠩࠪ䤧")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䤨"),url2,l1l1ll_l1_ (u"ࠫࠬ䤩"),headers,l1l1ll_l1_ (u"ࠬ࠭䤪"),l1l1ll_l1_ (u"࠭ࠧ䤫"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ䤬"))
			l1l11ll1_l1_ = response.content
			items = re.findall(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䤭"),l1l11ll1_l1_,re.DOTALL)
			l111l1l_l1_,l11l1_l1_ = [],[]
			l11111111_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭䤮"))
			for link,l11ll1l1_l1_ in reversed(items):
				link = l11111111_l1_+link+l1l1ll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䤯")+l11111111_l1_
				l111l1l_l1_.append(l11ll1l1_l1_)
				l11l1_l1_.append(link)
			return l1l1ll_l1_ (u"ࠫࠬ䤰"),l111l1l_l1_,l11l1_l1_
		else: return l1l1ll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䤱"),[l1l1ll_l1_ (u"࠭ࠧ䤲")],[url2]
	else:
		link = link+l1l1ll_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ䤳")+l1111111l_l1_
		return l1l1ll_l1_ (u"ࠨࠩ䤴"),[l1l1ll_l1_ (u"ࠩࠪ䤵")],[link]
def l11l1l1l1_l1_(link):
	# http://l11l1l11l1l_l1_.tv/?l1l11lll_l1_=159485&l1l1l11l_l1_=0
	if l1l1ll_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ䤶") in link:
		parts = re.findall(l1l1ll_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䤷"),link+l1l1ll_l1_ (u"ࠬࠬࠦࠨ䤸"),re.DOTALL|re.IGNORECASE)
		l1l11lll_l1_,l1l1l11l_l1_ = parts[0]
		host = SERVER(link,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䤹"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䤺"),l1l1ll_l1_ (u"ࠨࠩ䤻"),link,host)
		url = host+l1l1ll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ䤼")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ䤽")+l1l1l11l_l1_
		headers = { l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䤾"):l1l1ll_l1_ (u"ࠬ࠭䤿") , l1l1ll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䥀"):l1l1ll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䥁") }
		url2 = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠨࠩ䥂"),headers,l1l1ll_l1_ (u"ࠩࠪ䥃"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬ䥄"))
		url2 = url2.replace(l1l1ll_l1_ (u"ࠫࡡࡴࠧ䥅"),l1l1ll_l1_ (u"ࠬ࠭䥆")).replace(l1l1ll_l1_ (u"࠭࡜ࡳࠩ䥇"),l1l1ll_l1_ (u"ࠧࠨ䥈"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䥉"),l1l1ll_l1_ (u"ࠩࠪ䥊"),url,url2)
		#l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1ll1ll11_l1_(url2)
		#return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
		return l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䥋"),[l1l1ll_l1_ (u"ࠫࠬ䥌")],[url2]
	elif l1l1ll_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ䥍") in link:
		counts = 0
		while l1l1ll_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ䥎") in link and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䥏"),link,l1l1ll_l1_ (u"ࠨࠩ䥐"),l1l1ll_l1_ (u"ࠩࠪ䥑"),l1l1ll_l1_ (u"ࠪࠫ䥒"),l1l1ll_l1_ (u"ࠫࠬ䥓"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠶ࡳࡪࠧ䥔"))
			if l1l1ll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䥕") in list(response.headers.keys()): link = response.headers[l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䥖")]
			counts += 1
		return l1l1ll_l1_ (u"ࠨࠩ䥗"),[l1l1ll_l1_ (u"ࠩࠪ䥘")],[link]
	else: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧ䥙"),[],[]
def l11lll111_l1_(url):
	# l1lll11l_l1_://l1llll1l11l1_l1_.l1lll111lll1_l1_.me/l/l11l1l1ll1l_l1_=
	server = SERVER(url,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ䥚"))
	headers = {l1l1ll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䥛"):server,l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䥜"):l1l11lll1_l1_()}
	if l1l1ll_l1_ (u"ࠧ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䥝") in url:
		headers2 = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䥞"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ䥟")}
		url2,data2 = URLDECODE(url)
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䥠"),url2,data2,headers2,True,l1l1ll_l1_ (u"ࠫࠬ䥡"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠵ࡸࡺࠧ䥢"))
		html = response.content
		link = re.findall(l1l1ll_l1_ (u"࠭ࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䥣"),html,re.DOTALL|re.IGNORECASE)
		if link: return l1l1ll_l1_ (u"ࠧࠨ䥤"),[l1l1ll_l1_ (u"ࠨࠩ䥥")],[link[0]]
	elif l1l1ll_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ䥦") in url:
		html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠪࠫ䥧"),headers,l1l1ll_l1_ (u"ࠫࠬ䥨"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧ䥩"))
		link = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䥪"),html,re.DOTALL)
		if link: return l1l1ll_l1_ (u"ࠧࠨ䥫"),[l1l1ll_l1_ (u"ࠨࠩ䥬")],[link[0]]
	else:
		l1llll1l1l1l_l1_ = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䥭"),url,l1l1ll_l1_ (u"ࠪࠫ䥮"),headers,l1l1ll_l1_ (u"ࠫࠬ䥯"),l1l1ll_l1_ (u"ࠬ࠭䥰"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠸ࡸࡤࠨ䥱"))
		html = l1llll1l1l1l_l1_.content
		link = re.findall(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯࠳࡮ࡲࡦࡨࠣࡁࠥࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ䥲"),html,re.DOTALL)
		if link:
			link = UNQUOTE(link[0])+l1l1ll_l1_ (u"ࠨࠨࡧࡁ࠶࠭䥳")
			response2 = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䥴"),link,l1l1ll_l1_ (u"ࠪࠫ䥵"),headers,l1l1ll_l1_ (u"ࠫࠬ䥶"),l1l1ll_l1_ (u"ࠬ࠭䥷"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠹ࡺࡨࠨ䥸"))
			html = response2.content
			link = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡧࡺ࡮ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䥹"),html,re.DOTALL)
			if link:
				link = UNQUOTE(link[0])
				return l1l1ll_l1_ (u"ࠨࠩ䥺"),[l1l1ll_l1_ (u"ࠩࠪ䥻")],[link]
		if l1l1ll_l1_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧ䥼") in list(l1llll1l1l1l_l1_.headers.keys()):
			cookies = l1llll1l1l1l_l1_.headers[l1l1ll_l1_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ䥽")]
			link = re.findall(l1l1ll_l1_ (u"ࠬࡥ࡬࡯࡭ࡢ࠲࠯ࡅ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧ䥾"),cookies,re.DOTALL)
			if link:
				link = UNQUOTE(link[0])
				return l1l1ll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䥿"),[l1l1ll_l1_ (u"ࠧࠨ䦀")],[link]
	return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡇࡂࡔࡇࡈࡈࠬ䦁"),[],[]
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠤࠢࡱࡳࡹࠦࡷࡰࡴ࡮࡭ࡳ࡭ࠊࠊࠋࠦࠤ࡮ࡺࠠ࡯ࡧࡨࡨࡸࠦࡣࡰࡱ࡮࡭ࡪࠦࡦࡳࡱࡰࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠋࠋࠌࠧࠥࡉ࡯ࡰ࡭࡬ࡩ࠿ࠦࡣࡧࡡࡦࡰࡪࡧࡲࡢࡰࡦࡩࡂࡉࡍࡦ࠰ࡋࡏࡌࡗ࡫࡮ࡹࡱࡗ࡛ࡻ࡮ࡻࡘࡌࡴࡶࡵࡷࡲࡕࡄ࡞ࡨࡶ࡮ࡇ࠹࡭ࡆࡕ࡛ࡏࡒࡤ࡜ࡆࡋ࠶࠭࠲࠸࠹࠷࠶࠷࠲࠱࠲࠹࠱࠵࠳࠲࠶࠲ࠍࠍࠎࡹࡥࡳࡸࡨࡶࠥࡃࠠࡔࡇࡕ࡚ࡊࡘࠨࡶࡴ࡯࠰ࠬࡻࡲ࡭ࠩࠬࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾ࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࠼ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠭࠯ࠬࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡷࡪࡸࡶࡦࡴࢀࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠉ࡭࡫ࡱ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࡼࡳࡧ࠱ࡍࡌࡔࡏࡓࡇࡆࡅࡘࡋࠩࠋࠋࠌ࡭࡫ࠦ࡬ࡪࡰ࡮ࡷ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡪࡨࠣࠫࡪࡳࡢࡦࡦ࠰ࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠬ࡜ࠩࠪࡡ࠱ࡡ࡬ࡪࡰ࡮ࡡࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠠࡶࡴ࡯ࠤࡂࠦ࡬ࡪࡰ࡮ࠎࠎࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠲ࡨࡵ࡯࡯࠭ࠏࠏࠉࠤ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌࠍࠨ࡯ࡦࠡࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠎࠎࠏࠣࠊࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡖࡊ࡙ࡏࡍࡘࡈࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠩࠉࡳࡧࡷࡹࡷࡴࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࠋࠦࡩࡱࡹࡥ࠻ࠢࡸࡶࡱࠦ࠽ࠡ࡮࡬ࡲࡰࠐࠉࠣࠤࠥ䦂")
	#if l1l1ll_l1_ (u"ࠪ࠲ࡲࡶ࠴࠯ࡪࡷࡱࡱ࠭䦃") in url:
	#	l1lll1l11ll1_l1_ = url.split(l1l1ll_l1_ (u"ࠫ࠴࠭䦄"))
	#	url = l1l1ll_l1_ (u"ࠬ࠵ࠧ䦅").join(l1lll1l11ll1_l1_[:4])
	#	tmp = re.findall(l1l1ll_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿࠰࠱࠱࠮ࡄ࠵ࠩࠩ࠰࠭ࡃ࠮ࠪࠧ䦆"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l1l1ll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䦇")+tmp[0][1]+l1l1ll_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䦈")
	#	#return l1l1ll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䦉"),[l1l1ll_l1_ (u"ࠪࠫ䦊")],[url]
	#	#l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1ll1l1l11l1_l1_(url)
	#	#return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
	# l1l1l1l11_l1_ link
	#return l1l1ll_l1_ (u"ࠫࠬ䦋"),[l1l1ll_l1_ (u"ࠬ࠭䦌")],[link]
def l1lll11111l1_l1_(link):
	# l1lll11l_l1_://l1ll1lll1l11_l1_.l1ll1ll1_l1_/?l1l11lll_l1_=142302&l1l1l11l_l1_=4
	parts = re.findall(l1l1ll_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ䦍"),link,re.DOTALL|re.IGNORECASE)
	l1l11lll_l1_,l1l1l11l_l1_ = parts[0]
	server = SERVER(link,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ䦎"))
	#url = server+l1l1ll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䦏")
	url = server+l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䦐")
	#url = server+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ䦑")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䦒")+l1l1l11l_l1_
	#data = {l1l1ll_l1_ (u"ࠬ࡯ࡤࠨ䦓"):l1l11lll_l1_,l1l1ll_l1_ (u"࠭ࡩࠨ䦔"):l1l1l11l_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡧࡷࡥࠬ䦕"):l1l1ll_l1_ (u"ࠨࡱ࡯ࡨࡤࡹࡥࡳࡸࡨࡶࡸ࠭䦖"),l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ䦗"):l1l1ll_l1_ (u"ࠪࡳࡱࡪࠧ䦘")}
	data = {l1l1ll_l1_ (u"ࠫ࡮ࡪࠧ䦙"):l1l11lll_l1_,l1l1ll_l1_ (u"ࠬ࡯ࠧ䦚"):l1l1l11l_l1_}
	headers = {l1l1ll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䦛"):l1l1ll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䦜"),l1l1ll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䦝"):link}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䦞"),url,data,headers,l1l1ll_l1_ (u"ࠪࠫ䦟"),l1l1ll_l1_ (u"ࠫࠬ䦠"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ䦡"))
	l1l11ll1_l1_ = response.content
	url2 = re.findall(l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䦢"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
	if url2:
		url2 = url2[0]
		return l1l1ll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䦣"),[l1l1ll_l1_ (u"ࠨࠩ䦤")],[url2]
	return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭䦥"),[],[]
def l11llll_l1_(url,type,l11ll1l1_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䦦"),l1l1ll_l1_ (u"ࠫࠬ䦧"),url2,type)
	# http://l1lllll1llll_l1_.l11l11l11ll_l1_.io/link/136530
	l111ll1_l1_,l1lllll1l1l1_l1_ = [],[]
	l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠬ࠭䦨"),l1l1ll_l1_ (u"࠭ࠧ䦩"),True,l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭䦪"))
	l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ䦫"),l1l11ll1_l1_,re.DOTALL)
	for block in l1l1l11_l1_:
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ䦬"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l111ll1_l1_ and (l1l1ll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ䦭") in link or l1l1ll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䦮") in link):
				title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭䦯"),l1l1ll_l1_ (u"࠭ࠧ䦰")).replace(l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫ䦱"),l1l1ll_l1_ (u"ࠨࠩ䦲")).strip(l1l1ll_l1_ (u"ࠩࠣࠫ䦳")).replace(l1l1ll_l1_ (u"ࠪࠤࠥ࠭䦴"),l1l1ll_l1_ (u"ࠫࠥ࠭䦵"))
				l111ll1_l1_.append(link)
				l1lllll1l1l1_l1_.append(title)
	if not l111ll1_l1_: return l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭䦶"),[],[]
	if len(l111ll1_l1_)>1:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䦷"),l1lllll1l1l1_l1_)
		if selection==-1: selection = 0
	else: selection = 0
	url3 = l111ll1_l1_[selection]
	l11l1_l1_,l111l1l_l1_ = [],[]
	if type==l1l1ll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䦸"):
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ䦹"),url3,l1l1ll_l1_ (u"ࠩࠪ䦺"),l1l1ll_l1_ (u"ࠪࠫ䦻"),l1l1ll_l1_ (u"ࠫࠬ䦼"),True,l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠳ࡰࡧࠫ䦽"))
		l1ll1l111_l1_ = response.content
		l111l11l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡢࡵࡰ࠰ࡰࡴࡧࡤࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䦾"),l1ll1l111_l1_,re.DOTALL)
		if l111l11l_l1_:
			link = UNQUOTE(l111l11l_l1_[0])
			l11l1_l1_.append(link)
			l111l1l_l1_.append(l11ll1l1_l1_)
			#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䦿"),l1l1ll_l1_ (u"ࠨࠩ䧀"),l1l1ll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䧁"),link)
	elif type==l1l1ll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䧂"):
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䧃"),url3,l1l1ll_l1_ (u"ࠬ࠭䧄"),l1l1ll_l1_ (u"࠭ࠧ䧅"),l1l1ll_l1_ (u"ࠧࠨ䧆"),True,l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠷ࡷࡪࠧ䧇"))
		l1ll1l111_l1_ = response.content
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䧈"),l1ll1l111_l1_,re.DOTALL)
		for link,size in l1ll_l1_:
			if l11ll1l1_l1_ in size:
				l111l1l_l1_.append(size)
				l11l1_l1_.append(link)
				#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ䧉"),l1l1ll_l1_ (u"ࠫࠬ䧊"),l1l1ll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䧋"),link)
				break
		if not l11l1_l1_:
			for link,size in l1ll_l1_:
				l111l1l_l1_.append(size)
				l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭ࡔࡆࡕࡗࠫ䧌"),l11l1_l1_)
	if not l11l1_l1_: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䧍"),[],[]
	return l1l1ll_l1_ (u"ࠨࠩ䧎"),l111l1l_l1_,l11l1_l1_
def l1l1l1l_l1_(url,name):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䧏"),l1l1ll_l1_ (u"ࠪࠫ䧐"),url,l11l111llll_l1_)
	# http://l11ll111ll1_l1_.l1lll1ll11ll_l1_.l1ll1ll1_l1_/5cf68c23e6e79			?l11l111llll_l1_=			__11l1lll1ll_l1_
	# http://w.l1l111ll_l1_.l1llll1lll1_l1_/5e14fd0a2806e			?l11l111llll_l1_=			ok.l1llll1ll111_l1_
	#l11l111llll_l1_ = l11l111llll_l1_.replace(l1l1ll_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡢࡣࠬ䧑"),l1l1ll_l1_ (u"ࠬ࠭䧒")).split(l1l1ll_l1_ (u"࠭࡟ࡠࠩ䧓"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䧔"),url,l1l1ll_l1_ (u"ࠨࠩ䧕"),l1l1ll_l1_ (u"ࠩࠪ䧖"),True,l1l1ll_l1_ (u"ࠪࠫ䧗"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠱ࡴࡶࠪ䧘"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l1l1ll_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䧙") in list(cookies.keys()):
		l11lll1l1_l1_ = cookies[l1l1ll_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䧚")]
		l11lll1l1_l1_ = UNQUOTE(escapeUNICODE(l11lll1l1_l1_))
		items = re.findall(l1l1ll_l1_ (u"ࠧࡳࡱࡸࡸࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䧛"),l11lll1l1_l1_,re.DOTALL)
		url2 = items[0].replace(l1l1ll_l1_ (u"ࠨ࡞࠲ࠫ䧜"),l1l1ll_l1_ (u"ࠩ࠲ࠫ䧝"))
		url2 = escapeUNICODE(url2)
	else: url2 = url
	if l1l1ll_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ䧞") in url2:
		id = url2.split(l1l1ll_l1_ (u"ࠫࠪ࠸ࡆࠨ䧟"))[-1]
		url2 = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡡࡵࡥ࡫࠲࡮ࡹ࠯ࠨ䧠")+id
		return l1l1ll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䧡"),[l1l1ll_l1_ (u"ࠧࠨ䧢")],[url2]
	else:
		website = WEBSITES[l1l1ll_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䧣")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䧤"),website,l1l1ll_l1_ (u"ࠪࠫ䧥"),l1l1ll_l1_ (u"ࠫࠬ䧦"),True,l1l1ll_l1_ (u"ࠬ࠭䧧"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ䧨"))
		l11l111ll1l_l1_ = response.url
		#l11l111ll1l_l1_ = response.headers[l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䧩")]
		#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䧪"),l1l1ll_l1_ (u"ࠩࠪ䧫"),response.url,website)
		l1lllll1l111_l1_ = url2.split(l1l1ll_l1_ (u"ࠪ࠳ࠬ䧬"))[2]#.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䧭"))
		l11ll111lll_l1_ = l11l111ll1l_l1_.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ䧮"))[2]#.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䧯"))
		url3 = url2.replace(l1lllll1l111_l1_,l11ll111lll_l1_)
		headers = { l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䧰"):l1l1ll_l1_ (u"ࠨࠩ䧱") , l1l1ll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䧲"):l1l1ll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䧳") , l1l1ll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䧴"):url3 }
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䧵"), url3, l1l1ll_l1_ (u"࠭ࠧ䧶"), headers, False,l1l1ll_l1_ (u"ࠧࠨ䧷"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧ䧸"))
		html = response.content
		#xbmc.log(str(url3), level=xbmc.LOGERROR)
		items = re.findall(l1l1ll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䧹"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l1ll_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䧺"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l1ll_l1_ (u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䧻"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䧼"),l1l1ll_l1_ (u"࠭ࠧ䧽"),str(items),html)
		if items:
			link = items[0].replace(l1l1ll_l1_ (u"ࠧ࡝࠱ࠪ䧾"),l1l1ll_l1_ (u"ࠨ࠱ࠪ䧿"))
			link = link.rstrip(l1l1ll_l1_ (u"ࠩ࠲ࠫ䨀"))
			if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䨁") not in link: link = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䨂") + link
			link = link.replace(l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䨃"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䨄"))
			if name==l1l1ll_l1_ (u"ࠧࠨ䨅"): l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠨࠩ䨆"),[l1l1ll_l1_ (u"ࠩࠪ䨇")],[link]
			else: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䨈"),[l1l1ll_l1_ (u"ࠫࠬ䨉")],[link]
		else: l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_ = l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭䨊"),[],[]
		return l11l1ll111l_l1_,l111l1l_l1_,l11l1_l1_
def l111ll1l11l_l1_(url):
	# l1lll11l_l1_://l1l1ll1llll_l1_.l111llll111_l1_.l1lll1ll1_l1_/e/l1ll1llll1l1_l1_
	headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䨋") : l1l1ll_l1_ (u"ࠧࠨ䨌") }
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠨࠩ䨍"),headers,l1l1ll_l1_ (u"ࠩࠪ䨎"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ䨏"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䨐"),l1l1ll_l1_ (u"ࠬ࠭䨑"),url,html)
	items = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䨒"),html,re.DOTALL)
	l111l1l_l1_,l11l1_l1_,errno = [],[],l1l1ll_l1_ (u"ࠧࠨ䨓")
	if items:
		for link,l1llll11l1ll_l1_ in items:
			l111l1l_l1_.append(l1llll11l1ll_l1_)
			l11l1_l1_.append(link)
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧ䨔"),[],[]
	return l1l1ll_l1_ (u"ࠩࠪ䨕"),l111l1l_l1_,l11l1_l1_
def l1lll111llll_l1_(url):
	# l1lll11l_l1_://l1lll1llll1l_l1_.l1lll1ll1_l1_/l1l1l1l11_l1_-l111l1111l1_l1_.html
	url = url.replace(l1l1ll_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䨖"),l1l1ll_l1_ (u"ࠫࠬ䨗"))
	headers = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䨘") : l1l1ll_l1_ (u"࠭ࠧ䨙") }
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠧࠨ䨚"),headers,l1l1ll_l1_ (u"ࠨࠩ䨛"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ䨜"))
	items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䨝"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䨞"),l1l1ll_l1_ (u"ࠬ࠭䨟"),url,items[0])
	if items:
		url = items[0]+l1l1ll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䨠")+url
		return l1l1ll_l1_ (u"ࠧࠨ䨡"),[l1l1ll_l1_ (u"ࠨࠩ䨢")],[url]
	else: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡗࡌࡐࡃࡇࠫ䨣"),[],[]
def l11111l11ll_l1_(url):
	# l1lll11l_l1_://l1ll11l11lll_l1_.to/l1l1l1l11_l1_/5c83f14297d62
	url = url.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ䨤"))
	if l1l1ll_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ䨥") in url: id = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧ䨦"))[4]
	else: id = url.split(l1l1ll_l1_ (u"࠭࠯ࠨ䨧"))[-1]
	url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡦࡷࡹࡸࡥࡢ࡯࠱ࡸࡴ࠵ࡰ࡭ࡣࡼࡩࡷࡅࡦࡪࡦࡀࠫ䨨") + id
	headers = { l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䨩") : l1l1ll_l1_ (u"ࠩࠪ䨪") }
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠪࠫ䨫"),headers,l1l1ll_l1_ (u"ࠫࠬ䨬"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ䨭"))
	html = html.replace(l1l1ll_l1_ (u"࠭࡜࡝ࠩ䨮"),l1l1ll_l1_ (u"ࠧࠨ䨯"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䨰"),l1l1ll_l1_ (u"ࠩࠪ䨱"),url,html)
	items = re.findall(l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䨲"),html,re.DOTALL)
	if items: return l1l1ll_l1_ (u"ࠫࠬ䨳"),[l1l1ll_l1_ (u"ࠬ࠭䨴")],[ items[0] ]
	else: return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪ䨵"),[],[]
def l1lll1l11l11_l1_(url):
	# l1lll11l_l1_://l11l1l111l1_l1_.l1ll1ll1_l1_/l1l1l1l11_l1_-l111l1l1l1l_l1_.html
	url = url.replace(l1l1ll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䨶"),l1l1ll_l1_ (u"ࠨࠩ䨷"))
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䨸"),l1l1ll_l1_ (u"ࠪࠫ䨹"),l1l1ll_l1_ (u"ࠫࠬ䨺"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬ䨻"))
	items = re.findall(l1l1ll_l1_ (u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䨼"),html,re.DOTALL)
	l111l1l_l1_,l11l1_l1_ = [],[]
	for link,l1llll11l1ll_l1_,res in items:
		l111l1l_l1_.append(l1llll11l1ll_l1_+l1l1ll_l1_ (u"ࠧࠡࠩ䨽")+res)
		l11l1_l1_.append(link)
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡏ࡛ࡃࠪ䨾"),[],[]
	return l1l1ll_l1_ (u"ࠩࠪ䨿"),l111l1l_l1_,l11l1_l1_
def l1111ll111l_l1_(url):
	# l1lll11l_l1_://l11l1ll11l1_l1_.l1llll1l11l_l1_/l1l1l1l11_l1_-l1lll1ll111l_l1_.html
	url = url.replace(l1l1ll_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䩀"),l1l1ll_l1_ (u"ࠫࠬ䩁"))
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠬ࠭䩂"),l1l1ll_l1_ (u"࠭ࠧ䩃"),l1l1ll_l1_ (u"ࠧࠨ䩄"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ䩅"))
	items = re.findall(l1l1ll_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢ䩆"),html,re.DOTALL)
	items = set(items)
	l111l1l_l1_,l11l1_l1_ = [],[]
	for id,mode,hash,l1llll11l1ll_l1_,res in items:
		url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ䩇")+id+l1l1ll_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ䩈")+mode+l1l1ll_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ䩉")+hash
		html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"࠭ࠧ䩊"),l1l1ll_l1_ (u"ࠧࠨ䩋"),l1l1ll_l1_ (u"ࠨࠩ䩌"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭䩍"))
		items = re.findall(l1l1ll_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䩎"),html,re.DOTALL)
		for link in items:
			l111l1l_l1_.append(l1llll11l1ll_l1_+l1l1ll_l1_ (u"ࠫࠥ࠭䩏")+res)
			l11l1_l1_.append(link)
	if len(l11l1_l1_)==0: return l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ䩐"),[],[]
	return l1l1ll_l1_ (u"࠭ࠧ䩑"),l111l1l_l1_,l11l1_l1_
def l1ll11l1l111_l1_(url):
	# l1lll11l_l1_://l1ll1l111l1l_l1_.l1lll1ll1_l1_:2053/l1ll1l11l111_l1_/l1lll1l1ll11_l1_.l1111llllll_l1_.l11ll11111l_l1_.1080p.l11l1lll11l_l1_.l11l111lll1_l1_.l1ll11lll111_l1_.l11l1111_l1_.html?l1111l1l1ll_l1_=2jpqzvpT8BbNUifWZO4QLQ&l111l1l1ll1_l1_=1624070560
	# http://l1ll1ll111ll_l1_.l11l1111l1l_l1_/l1111lll111_l1_/l111l1111ll_l1_.l1lllllll11l_l1_.l111l1l1111_l1_.2018.1080p.l1lllll11lll_l1_-l1111111ll1_l1_.l1ll1ll1111l_l1_.l11l1111_l1_.html
	link = l1l1ll_l1_ (u"ࠧࠨ䩒")
	if 1 or l1l1ll_l1_ (u"ࠨࡍࡨࡽࡂ࠭䩓") not in url:
		url2 = url.replace(l1l1ll_l1_ (u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭䩔"),l1l1ll_l1_ (u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ䩕"))
		url2 = url2.split(l1l1ll_l1_ (u"ࠫ࠴࠭䩖"))
		id = url2[3]
		url2 = l1l1ll_l1_ (u"ࠬ࠵ࠧ䩗").join(url2[0:4])
		#headers = {l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䩘"):l1l11lll1_l1_(),l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䩙"):l1l1ll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䩚")}
		payload = {l1l1ll_l1_ (u"ࠩ࡬ࡨࠬ䩛"):id,l1l1ll_l1_ (u"ࠪࡳࡵ࠭䩜"):l1l1ll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ䩝"),l1l1ll_l1_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ䩞"):l1l1ll_l1_ (u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭䩟")}
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ䩠"),url2,payload,l1l1ll_l1_ (u"ࠨࠩ䩡"),l1l1ll_l1_ (u"ࠩࠪ䩢"),l1l1ll_l1_ (u"ࠪࠫ䩣"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ䩤"))
		if l1l1ll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䩥") in list(response.headers.keys()): link = response.headers[l1l1ll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䩦")]
		if not link and response.succeeded:
			html = response.content
			link = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䩧"),html,re.DOTALL)
			if link: link = link[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ䩨"),url,l1l1ll_l1_ (u"ࠩࠪ䩩"),l1l1ll_l1_ (u"ࠪࠫ䩪"),l1l1ll_l1_ (u"ࠫࠬ䩫"),l1l1ll_l1_ (u"ࠬ࠭䩬"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ䩭"))
		if l1l1ll_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ䩮") in list(response.headers.keys()): link = response.headers[l1l1ll_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ䩯")]
	if link: return l1l1ll_l1_ (u"ࠩࠪ䩰"),[l1l1ll_l1_ (u"ࠪࠫ䩱")],[link]
	return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ䩲"),[],[]
def l11111ll11l_l1_(url):
	# l1lll11l_l1_://l1l1ll1llll_l1_.l1llllll111l_l1_.l1lll1ll1_l1_/012ocyw9li6g.html
	headers = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䩳") : l1l1ll_l1_ (u"࠭ࠧ䩴") }
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠧࠨ䩵"),headers,l1l1ll_l1_ (u"ࠨࠩ䩶"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ䩷"))
	items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩ䩸"),html,re.DOTALL)
	l111l1l_l1_,l11l1_l1_ = [],[]
	if items:
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠫࡲࡶ࠴ࠨ䩹"))
		l11l1_l1_.append(items[0][1])
		l111l1l_l1_.append(l1l1ll_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ䩺"))
		l11l1_l1_.append(items[0][0])
		return l1l1ll_l1_ (u"࠭ࠧ䩻"),l111l1l_l1_,l11l1_l1_
	else: return l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫ䩼"),[],[]
def l11l1l1l11l_l1_(url):
	# l1111lllll1_l1_ l111lll1l11_l1_			url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡟࠷ࡘ࠶࠴࡚ࡒࡾࡹࡒࡇࠪ䩽")
	# l1ll1l1l11ll_l1_ .l11l1llll11_l1_ l111lll1l11_l1_		url = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡷ࡯ࡖࡒࡆࡿࡥࡺࡈࡌࠫ䩾")
	# l1111lll11l_l1_ l11ll1l1l1_l1_ .l11111ll_l1_ l111lll1l11_l1_		url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡈࡨ࠵࠱ࡓ࡙ࡴࡔࡵࡑࡻࠬ䩿")
	# l11111lllll_l1_ l111lll1l11_l1_			url = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭䪀")
	# l111llll1l_l1_ files have l11111l1l11_l1_ l1ll1l111l11_l1_		url = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࠴ࡻࡉࡘࡕࡗࡥࡖࡽࡤࡗࠧ䪁")
	# url = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ䪂")
	# url = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺ࠴ࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ䪃")
	# url = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ䪄")
	# url = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ䪅")
	# url = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡱࡈࡈࡰࡰ࡯࡟ࡋ࠳࡜࡯ࠫࡧࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭࠿ࡊࡳࡱࡪࡥ࡯ࡎ࡬ࡲࡪ࡬࡯ࡳࡖ࡙ࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡡ࡯ࡦࡇ࡭ࡸࡺࡲࡪࡤࡸࡸ࡮ࡵ࡮ࡀࡵࡼࡲࡩ࡯ࡣࡢࡶ࡬ࡳࡳࡃ࠲࠸࠹࠸࠻࠺࠭䪆")
	# l1llll11l_l1_ l1lll111l1ll_l1_ l1ll11ll1l11_l1_   l1lll11l_l1_://l1lll1ll1111_l1_.me/l1ll1l111111_l1_/l1ll11ll1111_l1_-l1ll11llllll_l1_-l1lll1111ll1_l1_
	id = url.split(l1l1ll_l1_ (u"ࠫ࠴࠭䪇"))[-1]
	id = id.split(l1l1ll_l1_ (u"ࠬࠬࠧ䪈"))[0]
	id = id.replace(l1l1ll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ䪉"),l1l1ll_l1_ (u"ࠧࠨ䪊"))
	#id = l1l1ll_l1_ (u"ࠨࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭䪋")
	#url = l1l1ll_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭䪌")+id
	#return l1l1ll_l1_ (u"ࠪࠫ䪍"),[l1l1ll_l1_ (u"ࠫࠬ䪎")],[url]
	url2 = WEBSITES[l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䪏")][0]+l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䪐")+id
	l1ll11l1l1l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ䪑")+id
	l1lllllll1ll_l1_,l1ll1l111lll_l1_,l11ll1111l1_l1_,l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࠩ䪒"),l1l1ll_l1_ (u"ࠩࠪ䪓"),l1l1ll_l1_ (u"ࠪࠫ䪔"),l1l1ll_l1_ (u"ࠫࠬ䪕")
	l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫࠬࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡢࠧ࠭ࠩࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠩ࠰࠭ࡃ࠮ࡪࡥࡧࡣࡸࡰࡹࡇࡵࡥ࡫ࡲࡘࡷࡧࡣ࡬ࡋࡱࡨࡪࡾࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࢁࠢ࡭ࡣࡱ࡫ࡺࡧࡧࡦࡅࡲࡨࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭࡝࠭࡝ࠪࠫࡢࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡢࡰࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡡ࡯ࡩࠬࠎࠎࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨ࠮ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠊࠊࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡱࡳࡹࠦࡩ࡯ࠢ࡞࠴࠱࠳࠱࡞࠼ࠍࠍࠎࠏࠉࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡨࡡࡴࡧࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒ࡛࠱࡟࠮ࠫࠫ࡬࡭ࡵ࠿ࡹࡸࡹࠬࡴࡺࡲࡨࡁࡹࡸࡡࡤ࡭ࠩࡸࡱࡧ࡮ࡨ࠿ࠪ࠯ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡤࡢࡵ࡫࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡳ࠰ࠩ࠯ࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡩ࡮ࡶ࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠩࡨࡵ࡯࡯࠶ࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡨ࡭ࡵࡘࡖࡑ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ࠭ࠏࠏࠉࠤ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮࡙ࠧ࠯ࡐࡉࡉࡏࡁ࠻ࡗࡕࡍࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠬࡈࡔࡒ࡙ࡕ࠳ࡉࡅ࠿ࠥࡺࡹࡺࠧ࠭ࡪࡷࡱࡱ࠸ࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠣࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠨ࠱ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠨࡷࡽࡵ࡫࠽ࡵࡴࡤࡧࡰࠬࡴ࡭ࡣࡱ࡫ࡂ࠭ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠭ࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮ࡾࢁࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡺࡸ࡬ࡠࡧࡱࡧࡴࡪࡥࡥࡡࡩࡱࡹࡥࡳࡵࡴࡨࡥࡲࡥ࡭ࡢࡲࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫࡟ࡧ࡯ࡷࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡬ࡪࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡤࡲࡩࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠥࡂࡡࠧࠨ࡟࠽ࠎࠎࠏࠉࡧ࡯ࡷࡣࡱ࡯ࡳࡵࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊࡨࡰࡸࡤ࡯ࡴࡢࡩࡶࠤࡂࠦࡦ࡮ࡶࡢࡰ࡮ࡹࡴ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠮ࠪ࠭ࠏࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡦ࡮ࡶࡢ࡭ࡹࡧࡧࡴ࠼ࠍࠍࠎࠏࠉࡪࡶࡤ࡫࠱ࡹࡩࡻࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪ࠳ࠬ࠯ࠊࠊࠋࠌࠍ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࡟࡮ࡺࡡࡨ࡟ࠣࡁࠥࡹࡩࡻࡧࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࡰ࡮ࡴࡥࡴࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰࡨࠤ࡮ࡴࠠ࡭࡫ࡱࡩࡸࡀࠊࠊࠋࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮ࠧ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࡰ࡮ࡴࡥ࠭࡮ࡨࡺࡪࡲ࠽ࡹࡤࡰࡧ࠳ࡒࡏࡈࡐࡒࡘࡎࡉࡅࠪࠌࠌࠍࠎࡲࡩ࡯ࡧࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰࡨ࠭ࠏࠏࠉࠊࡦ࡬ࡧࡹࠦ࠽ࠡࡽࢀࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡ࡮࡬ࡲࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠦࠧࠩࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࡦ࡬ࡧࡹࡡ࡫ࡦࡻࡠࠤࡂࠦࡶࡢ࡮ࡸࡩࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡻࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪࡷ࡮ࢀࡥࠨ࡟ࠣࡁࠥ࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࡠࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࡡࠏࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠯ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲ࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡩࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋࡩࡳࡷࠦࡢ࡭ࡱࡦ࡯ࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠦࠧࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡃࠢࠨ࠮ࠪࡁࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠥࠦࠬ࠲ࠧࠣࠩࠬࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠼ࡷࡶࡺ࡫ࠧ࠭ࠩ࠽ࡘࡷࡻࡥࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡀࡦࡢ࡮ࡶࡩࠬ࠲ࠧ࠻ࡈࡤࡰࡸ࡫ࠧࠪࠌࠌࠍ࡮࡬ࠠࠨ࡝ࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡧࡲ࡯ࡤ࡭ࠣࡁ࡛ࠥ࠭ࠨ࠭ࡥࡰࡴࡩ࡫ࠬࠩࡠࠫࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡇ࡙ࡅࡑ࠮ࠧ࡭࡫ࡶࡸࠬ࠲ࡢ࡭ࡱࡦ࡯࠮ࠐࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩࡷࡽࡵ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡀࠫ࠱࠭࠽ࠣࠩࠬ࠯ࠬࠨࠧࠋࠋࠌࠍ࡮࡬ࠠࠨࡨࡳࡷࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡦࡱࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡪࡵࡹࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡷࡪࡦࡷ࡬ࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡼࡨࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫࡼ࡯ࡤࡵࡪࠪࡡ࠮࠱ࠧࡹࠩ࠮ࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡳࡵࡣࡵࡸࠬࡣࠫࠨ࠯ࠪ࠯ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡨࡲࡩ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࡠ࡟ࠬ࡫࡮ࡥࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣ࠾࠲࠳࠴࠶࠷࠸࠳࠴࠵࠽ࠤࡩ࡫࡬ࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡨ࡯ࡰࡩࡧࡵࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࠩࠫ࠮ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡥ࡬ࡴ࡭࡫ࡲ࠻ࠌࠌࠍࠎࠏࠉ࡬ࡧࡼ࠰ࡻࡧ࡬ࡶࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪࡁࠬ࠲࠱ࠪࠌࠌࠍࠎࠏࠉࡥ࡫ࡦࡸࡠࡱࡥࡺ࡟ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡶࡢ࡮ࡸࡩ࠮ࠐࠉࠊࠋࠦ࡭࡫ࠦࠧࡶࡴ࡯ࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡻࡲ࡭ࠩࡠࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸࡠ࠭ࡵࡳ࡮ࠪࡡ࠮ࠐࠉࠊࠋࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺࠩࠋࠋࡸࡶࡱࡥ࡬ࡪࡵࡷ࠰ࡸࡺࡲࡦࡣࡰࡷ࠵࠲ࡳࡵࡴࡨࡥࡲࡹ࠱࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠠࡢࡰࡧࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵ࠳ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶ࡀࠊࠊࠋࠌࡹࡷࡲ࠱ࠡ࠿ࠣࡨ࡮ࡩࡴ࠲࡝ࠪࡹࡷࡲࠧ࡞࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠨࡻࡲ࡭࠳ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠶ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸ࠷ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠼ࠍࠍࠎࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋࠦࡹࡷࡲ࠲ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈ࡚ࠬࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࠵࡟ࠬࡻࡲ࡭ࠩࡠ࠭࠮ࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋ࡬ࡪࠥࡻࡲ࡭࠳ࡀࡁࡺࡸ࡬࠳ࠢࡤࡲࡩࠦࡵࡳ࡮࠴ࠤࡳࡵࡴࠡ࡫ࡱࠤࡺࡸ࡬ࡠ࡮࡬ࡷࡹࡀࠊࠊࠋࠌࠍࠎࡻࡲ࡭ࡡ࡯࡭ࡸࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠵࠮ࠐࠉࠊࠋࠌࠍࡩ࡯ࡣࡵ࠳࠱ࡹࡵࡪࡡࡵࡧࠫࡨ࡮ࡩࡴ࠳ࠫࠍࠍࠎࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴ࠲࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴ࠲ࠫࠍࠍࡪࡲࡳࡦ࠼ࠣࡷࡹࡸࡥࡢ࡯ࡶ࠴ࠥࡃࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠫࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸ࠊࠊࠤࠥࠦ䪖")
	# l1ll1ll11111_l1_ json data
	# l1l1l1l11_l1_ url l111lll1l11_l1_:    l1lll11l_l1_://l1l1ll1llll_l1_.l1llll11l_l1_.l1lll1ll1_l1_/l1l1l1l11_l1_/l111l11lll1_l1_
	# list of l111lll1lll_l1_ & l1ll1l11l1l1_l1_
	# l1lll11l_l1_://l1111l11l1_l1_.l1lll1ll1_l1_/l1lll1111l1l_l1_-l1llll11l1l1_l1_/l1lll1111l1l_l1_-l1llll11l1l1_l1_/l111l11lll_l1_/l111ll1111_l1_/l111ll1l1l1_l1_/l1llllll11ll_l1_/l1llll11l_l1_.py
	# all the l1111l1l1l_l1_ l1lll1l11111_l1_ l111111l11l_l1_ l11111ll111_l1_ l1l1lll11l_l1_:	l1lll11l_l1_://l1l1ll1llll_l1_.l1llll11l_l1_.l1lll1ll1_l1_/l11l11ll111_l1_/l1lll11l1lll_l1_/l1lll11llll1_l1_?l1ll11l1llll_l1_=l1ll1l11ll11_l1_	&	l111ll11111_l1_ = l111l11lll1_l1_
	# 3 streams:	13KB:	l1l1ll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䪗"): l1l1ll_l1_ (u"ࠧࡊࡑࡖࡣࡈࡘࡅࡂࡖࡒࡖࠬ䪘"),l1l1ll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䪙"): l1l1ll_l1_ (u"ࠩ࠵࠶࠳࠹࠳࠯࠳࠳࠵ࠬ䪚")
	# 7 streams		44KB:	l1l1ll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䪛"): l1l1ll_l1_ (u"ࠫࡎࡕࡓࡠࡏࡈࡗࡘࡇࡇࡆࡕࡢࡉ࡝࡚ࡅࡏࡕࡌࡓࡓ࠭䪜"),l1l1ll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䪝"): l1l1ll_l1_ (u"࠭࠱࠸࠰࠶࠷࠳࠸ࠧ䪞")
	# 7 streams		58KB:	l1l1ll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䪟"): l1l1ll_l1_ (u"ࠨࡋࡒࡗࠬ䪠"),l1l1ll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䪡"): l1l1ll_l1_ (u"ࠪ࠵࠼࠴࠳࠴࠰࠵ࠫ䪢")
	# 9 streams		24KB:	l1l1ll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䪣"): l1l1ll_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡃࡓࡇࡄࡘࡔࡘࠧ䪤"),l1l1ll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䪥"): l1l1ll_l1_ (u"ࠧ࠳࠴࠱࠷࠵࠴࠱࠱࠲ࠪ䪦")
	# no json file:		21 streams	95KB:	l1l1ll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䪧"): l1l1ll_l1_ (u"࡚ࠩࡉࡇࡥࡃࡓࡇࡄࡘࡔࡘࠧ䪨"),l1l1ll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䪩"): l1l1ll_l1_ (u"ࠫ࠶࠴࠲࠱࠴࠵࠴࠼࠸࠶࠯࠲࠳࠲࠵࠶ࠧ䪪")
	# no json file:		21 streams	121KB:	l1l1ll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䪫"): l1l1ll_l1_ (u"࠭ࡗࡆࡄࠪ䪬"),l1l1ll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䪭"): l1l1ll_l1_ (u"ࠨ࠴࠱࠶࠵࠸࠲࠱࠺࠳࠵࠳࠶࠰࠯࠲࠳ࠫ䪮")
	# no json file: 	26 streams	115KB:	l1l1ll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䪯"): l1l1ll_l1_ (u"ࠪࡑ࡜ࡋࡂࠨ䪰"),l1l1ll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䪱"): l1l1ll_l1_ (u"ࠬ࠸࠮࠳࠲࠵࠶࠵࠾࠰࠲࠰࠳࠴࠳࠶࠰ࠨ䪲")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䪳"): l1l1ll_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࠨ䪴"),l1l1ll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䪵"): l1l1ll_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ䪶")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䪷"): l1l1ll_l1_ (u"ࠫ࡜ࡋࡂࡠࡔࡈࡑࡎ࡞ࠧ䪸"),l1l1ll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䪹"): l1l1ll_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠹࠱࠴࠶࠴࠰࠱ࠩ䪺")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䪻"): l1l1ll_l1_ (u"ࠨ࡙ࡈࡆࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ䪼"),l1l1ll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䪽"): l1l1ll_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠸࠷࠮࠱࠲࠱࠴࠵࠭䪾")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䪿"): l1l1ll_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡅࡎࡄࡈࡈࡉࡋࡄࡠࡒࡏࡅ࡞ࡋࡒࠨ䫀"),l1l1ll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䫁"): l1l1ll_l1_ (u"ࠧ࠲࠹࠱࠷࠶࠴࠳࠶ࠩ䫂")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䫃"): l1l1ll_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡑ࡚࡙ࡉࡄࠩ䫄"),l1l1ll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䫅"): l1l1ll_l1_ (u"ࠫ࠺࠴࠱࠷࠰࠸࠵ࠬ䫆")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䫇"): l1l1ll_l1_ (u"࠭ࡔࡗࡊࡗࡑࡑ࠻࡟ࡔࡋࡐࡔࡑ࡟࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ䫈"),l1l1ll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䫉"): l1l1ll_l1_ (u"ࠨ࠴࠱࠴ࠬ䫊")
	# l11llll1ll1_l1_:	l1l1ll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䫋"): l1l1ll_l1_ (u"ࠪࡍࡔ࡙࡟ࡎࡗࡖࡍࡈ࠭䫌"),l1l1ll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䫍"): l1l1ll_l1_ (u"ࠬ࠻࠮࠳࠳ࠪ䫎")
	# url2 = WEBSITES[l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䫏")][0]+l1l1ll_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷࡅࡰࡳࡧࡷࡸࡾࡖࡲࡪࡰࡷࡁࡹࡸࡵࡦࠩ䫐")  # l1ll1l11ll11_l1_ l1lllll11l11_l1_ l1ll1l11l1ll_l1_ and l1lll111ll1l_l1_ l1llll11llll_l1_ l1l1llllll_l1_ l1ll1lll11ll_l1_ file size
	#data2 = l1l1ll_l1_ (u"ࠨࡽࠪ䫑")l1ll11l1lll1_l1_ (u"ࠩ࠽࡭ࡩ࠲ࠧ䫒")l1lllll1l11l_l1_ (u"ࠪ࠾ࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠣࡃࡑࡈࡗࡕࡉࡅࠤ࠯ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠨ࠱࠸࠰࠶࠵࠳࠹࠵ࠣࡿࢀࢁࠬ䫓")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ䫔"),url2,data2,l1l1ll_l1_ (u"ࠬ࠭䫕"),l1l1ll_l1_ (u"࠭ࠧ䫖"),l1l1ll_l1_ (u"ࠧࠨ䫗"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩ䫘"))
	#html = response.content
	for ii in range(5):
		#DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠩส่๊ำว้ๆฬࠤึ่ๅ࠻ࠢࠣࠫ䫙")+str(ii+1),l1l1ll_l1_ (u"ࠪࠫ䫚"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䫛"),url2,l1l1ll_l1_ (u"ࠬ࠭䫜"),l1l1ll_l1_ (u"࠭ࠧ䫝"),l1l1ll_l1_ (u"ࠧࠨ䫞"),l1l1ll_l1_ (u"ࠨࠩ䫟"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ䫠"))
		html = response.content
		if l1l1ll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ䫡") in html: break
		time.sleep(2)
	#WRITE_THIS(l1l1ll_l1_ (u"ࠫࠬ䫢"),html)
	l1l1111l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ䫣"),html,re.DOTALL)
	if l1l1111l11_l1_: l1l1111l11_l1_ = l1l1111l11_l1_[0]
	else: l1l1111l11_l1_ = html
	l1l1111l11_l1_ = l1l1111l11_l1_.replace(l1l1ll_l1_ (u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ䫤"),l1l1ll_l1_ (u"ࠧࠧࠩ䫥"))
	l1lll111111l_l1_ = EVAL(l1l1ll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䫦"),l1l1111l11_l1_)
	#WRITE_THIS(l1l1ll_l1_ (u"ࠩࠪ䫧"),str(l1lll111111l_l1_))
	# l1ll1ll11111_l1_ l111l1l11ll_l1_ & l11l1ll1lll_l1_
	# l1llll11l_l1_ l1111lllll1_l1_ link l1l11l1l1_l1_ l1l1ll_l1_ (u"ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠬ䫨") to l11l111111_l1_ on l111llll11l_l1_
	l111l1l_l1_,l11l1_l1_ = [l1l1ll_l1_ (u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ䫩")],[l1l1ll_l1_ (u"ࠬ࠭䫪")]
	try:
		l111l1l11ll_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ䫫")][l1l1ll_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䫬")][l1l1ll_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ䫭")]
		for l1111l1111l_l1_ in l111l1l11ll_l1_:
			link = l1111l1111l_l1_[l1l1ll_l1_ (u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ䫮")]
			try: title = l1111l1111l_l1_[l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥࠨ䫯")][l1l1ll_l1_ (u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ䫰")]
			except: title = l1111l1111l_l1_[l1l1ll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䫱")][l1l1ll_l1_ (u"࠭ࡲࡶࡰࡶࠫ䫲")][0][l1l1ll_l1_ (u"ࠧࡵࡧࡻࡸࠬ䫳")]
			l11l1_l1_.append(link)
			l111l1l_l1_.append(title)
	except: pass
	if len(l111l1l_l1_)>1:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ䫴"), l111l1l_l1_)
		if selection==-1: return l1l1ll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䫵"),[],[]
		elif selection!=0:
			link = l11l1_l1_[selection]+l1l1ll_l1_ (u"ࠪࠪࠬ䫶")
			l1lll1lll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠫ࠮ࡦ࡮ࡶࡀ࠲࠯ࡅࠩࠧࠩ䫷"),link)
			if l1lll1lll11l_l1_: link = link.replace(l1lll1lll11l_l1_[0],l1l1ll_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭䫸"))
			else: link = link+l1l1ll_l1_ (u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ䫹")
			l1lllllll1ll_l1_ = link.strip(l1l1ll_l1_ (u"ࠧࠧࠩ䫺"))
	formats,l11l1ll1l1l_l1_,l111ll1ll11_l1_,l111ll1ll1l_l1_,l111ll1l1ll_l1_ = [],[],[],[],[]
	# l1ll1ll11111_l1_ l11111111ll_l1_ streams
	try: l1ll1l111lll_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ䫻")][l1l1ll_l1_ (u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ䫼")]
	except: pass
	# l1ll1ll11111_l1_ l1111lll11l_l1_ stream
	try: l11ll1111l1_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ䫽")][l1l1ll_l1_ (u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ䫾")]
	except: pass
	# l1ll1ll11111_l1_ l1lll1111l_l1_ l11l1111_l1_ streams
	try: formats = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ䫿")][l1l1ll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䬀")]
	except: pass
	# l1ll1ll11111_l1_ l1lll1111l_l1_ l11l1llll11_l1_ streams
	try: l11l1ll1l1l_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ䬁")][l1l1ll_l1_ (u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪ䬂")]
	except: pass
	l1111ll1l1l_l1_ = formats+l11l1ll1l1l_l1_
	for dict in l1111ll1l1l_l1_:
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ䬃"),str(dict))
		if l1l1ll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ䬄") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䬅")] = str(dict[l1l1ll_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䬆")])
		if l1l1ll_l1_ (u"࠭ࡦࡱࡵࠪ䬇") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠧࡧࡲࡶࠫ䬈")] = str(dict[l1l1ll_l1_ (u"ࠨࡨࡳࡷࠬ䬉")])
		if l1l1ll_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ䬊") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠪࡸࡾࡶࡥࠨ䬋")] = dict[l1l1ll_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭䬌")]		#.replace(l1l1ll_l1_ (u"ࠬࡃࠧ䬍"),l1l1ll_l1_ (u"࠭࠽ࠨ䬎"))+l1l1ll_l1_ (u"ࠧࠣࠩ䬏")
		if l1l1ll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ䬐") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭䬑")] = str(dict[l1l1ll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ䬒")])
		if l1l1ll_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ䬓") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䬔")] = str(dict[l1l1ll_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䬕")])
		if l1l1ll_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭䬖") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭䬗")] = str(dict[l1l1ll_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ䬘")])+l1l1ll_l1_ (u"ࠪࡼࠬ䬙")+str(dict[l1l1ll_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ䬚")])
		if l1l1ll_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ䬛") in list(dict.keys()): dict[l1l1ll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䬜")] = dict[l1l1ll_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ䬝")][l1l1ll_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䬞")]+l1l1ll_l1_ (u"ࠩ࠰ࠫ䬟")+dict[l1l1ll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭䬠")][l1l1ll_l1_ (u"ࠫࡪࡴࡤࠨ䬡")]
		if l1l1ll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ䬢") in list(dict.keys()): dict[l1l1ll_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ䬣")] = dict[l1l1ll_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ䬤")][l1l1ll_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䬥")]+l1l1ll_l1_ (u"ࠩ࠰ࠫ䬦")+dict[l1l1ll_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ䬧")][l1l1ll_l1_ (u"ࠫࡪࡴࡤࠨ䬨")]
		if l1l1ll_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭䬩") in list(dict.keys()): dict[l1l1ll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䬪")] = dict[l1l1ll_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ䬫")]
		if l1l1ll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䬬") in list(dict.keys()) and int(dict[l1l1ll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䬭")])>111222333: del dict[l1l1ll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䬮")]
		if l1l1ll_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭䬯") in list(dict.keys()):
			cipher = dict[l1l1ll_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ䬰")].split(l1l1ll_l1_ (u"࠭ࠦࠨ䬱"))
			for item in cipher:
				key,value = item.split(l1l1ll_l1_ (u"ࠧ࠾ࠩ䬲"),1)
				dict[key] = UNQUOTE(value)
		if l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䬳") in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭䬴")] = UNQUOTE(dict[l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ䬵")])
		#if l1l1ll_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࡁࠬ䬶") in dict[l1l1ll_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ䬷")]: dict[l1l1ll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䬸")] = dict[l1l1ll_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ䬹")].split(l1l1ll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳ࠾࡞ࠥࠫ䬺"))[1].strip(l1l1ll_l1_ (u"ࠩ࡟ࠦࠬ䬻"))
		#LOG_THIS(l1l1ll_l1_ (u"ࠪࠫ䬼"),dict[l1l1ll_l1_ (u"ࠫࡹࡿࡰࡦࠩ䬽")]+l1l1ll_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥ࠭䬾")+dict[l1l1ll_l1_ (u"࠭ࡴࡺࡲࡨࠫ䬿")])
		l111ll1ll11_l1_.append(dict)
	l11llllll_l1_ = l1l1ll_l1_ (u"ࠧࠨ䭀")
	if l1l1ll_l1_ (u"ࠨࡵࡳࡁࡸ࡯ࡧࠨ䭁") in l1l1111l11_l1_:
		#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡼࡸࡸ࠵ࡪࡴࡤ࡬ࡲ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࠴ࠪࡀࠫࠥࠫ䭂"),html,re.DOTALL)
		# l111lll1l11_l1_:	/s/l1lll11llll1_l1_/6dde7fb4/l1ll1lll111l_l1_.l1lllll111l1_l1_/l1111111lll_l1_/base.l1ll1ll1ll1l_l1_
		#l11l111l111_l1_ = [l1l1ll_l1_ (u"ࠪ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵ࡤ࠹࠹ࡧ࠹࠽࠷ࡦ࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠࡗࡖ࠳ࡧࡧࡳࡦ࠰࡭ࡷࠬ䭃")]
		l11l111l111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ䭄"),html,re.DOTALL)
		if l11l111l111_l1_:
			l11l111l111_l1_ = WEBSITES[l1l1ll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䭅")][0]+l11l111l111_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䭆"),l11l111l111_l1_,l1l1ll_l1_ (u"ࠧࠨ䭇"),l1l1ll_l1_ (u"ࠨࠩ䭈"),l1l1ll_l1_ (u"ࠩࠪ䭉"),l1l1ll_l1_ (u"ࠪࠫ䭊"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ䭋"))
			l11llllll_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1ll1ll11l11_l1_ = cipher._load_javascript(l11llllll_l1_)
			l1ll1l111ll1_l1_ = EVAL(l1l1ll_l1_ (u"ࠬࡹࡴࡳࠩ䭌"),str(l1ll1ll11l11_l1_))
			l1lll11ll1l1_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1ll1l111ll1_l1_)
	for dict in l111ll1ll11_l1_:
		url = dict[l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䭍")]
		if l1l1ll_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡀࠫ䭎") in url or url.count(l1l1ll_l1_ (u"ࠨࡵ࡬࡫ࡂ࠭䭏"))>1:
			l111ll1ll1l_l1_.append(dict)
		elif l11llllll_l1_ and l1l1ll_l1_ (u"ࠩࡶࠫ䭐") in list(dict.keys()) and l1l1ll_l1_ (u"ࠪࡷࡵ࠭䭑") in list(dict.keys()):
			l11111lllll_l1_ = l1lll11ll1l1_l1_.execute(dict[l1l1ll_l1_ (u"ࠫࡸ࠭䭒")])
			if l11111lllll_l1_!=dict[l1l1ll_l1_ (u"ࠬࡹࠧ䭓")]:
				dict[l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䭔")] = url+l1l1ll_l1_ (u"ࠧࠧࠩ䭕")+dict[l1l1ll_l1_ (u"ࠨࡵࡳࠫ䭖")]+l1l1ll_l1_ (u"ࠩࡀࠫ䭗")+l11111lllll_l1_
				l111ll1ll1l_l1_.append(dict)
	for dict in l111ll1ll1l_l1_:
		l1l111l_l1_,l1lll11111ll_l1_,l1lll1llll11_l1_,l1l111l1l_l1_,codecs,l11l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ䭘"),l1l1ll_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ䭙"),l1l1ll_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭䭚"),l1l1ll_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ䭛"),l1l1ll_l1_ (u"ࠧࠨ䭜"),l1l1ll_l1_ (u"ࠨ࠲ࠪ䭝")
		try:
			l111ll1lll1_l1_ = dict[l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ䭞")]
			l111ll1lll1_l1_ = l111ll1lll1_l1_.replace(l1l1ll_l1_ (u"ࠪ࠯ࠬ䭟"),l1l1ll_l1_ (u"ࠫࠬ䭠"))
			items = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䭡"),l111ll1lll1_l1_,re.DOTALL)
			l1l111l1l_l1_,l1l111l_l1_,codecs = items[0]
			l11l1l1l1ll_l1_ = codecs.split(l1l1ll_l1_ (u"࠭ࠬࠨ䭢"))
			l1lll11111ll_l1_ = l1l1ll_l1_ (u"ࠧࠨ䭣")
			for item in l11l1l1l1ll_l1_: l1lll11111ll_l1_ += item.split(l1l1ll_l1_ (u"ࠨ࠰ࠪ䭤"))[0]+l1l1ll_l1_ (u"ࠩ࠯ࠫ䭥")
			l1lll11111ll_l1_ = l1lll11111ll_l1_.strip(l1l1ll_l1_ (u"ࠪ࠰ࠬ䭦"))
			if l1l1ll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䭧") in list(dict.keys()): l11l11ll1l1_l1_ = str(float(dict[l1l1ll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䭨")]*10)//1024/10)+l1l1ll_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭䭩")
			else: l11l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠧࠨ䭪")
			if l1l111l1l_l1_==l1l1ll_l1_ (u"ࠨࡶࡨࡼࡹ࠭䭫"): continue
			elif l1l1ll_l1_ (u"ࠩ࠯ࠫ䭬") in l111ll1lll1_l1_:
				l1l111l1l_l1_ = l1l1ll_l1_ (u"ࠪࡅ࠰࡜ࠧ䭭")
				l1lll1llll11_l1_ = l1l111l_l1_+l1l1ll_l1_ (u"ࠫࠥࠦࠧ䭮")+l11l11ll1l1_l1_+dict[l1l1ll_l1_ (u"ࠬࡹࡩࡻࡧࠪ䭯")].split(l1l1ll_l1_ (u"࠭ࡸࠨ䭰"))[1]
			elif l1l111l1l_l1_==l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䭱"):
				l1l111l1l_l1_ = l1l1ll_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ䭲")
				l1lll1llll11_l1_ = l11l11ll1l1_l1_+dict[l1l1ll_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ䭳")].split(l1l1ll_l1_ (u"ࠪࡼࠬ䭴"))[1]+l1l1ll_l1_ (u"ࠫࠥࠦࠧ䭵")+dict[l1l1ll_l1_ (u"ࠬ࡬ࡰࡴࠩ䭶")]+l1l1ll_l1_ (u"࠭ࡦࡱࡵࠪ䭷")+l1l1ll_l1_ (u"ࠧࠡࠢࠪ䭸")+l1l111l_l1_
			elif l1l111l1l_l1_==l1l1ll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ䭹"):
				l1l111l1l_l1_ = l1l1ll_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ䭺")
				l1lll1llll11_l1_ = l11l11ll1l1_l1_+str(int(dict[l1l1ll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ䭻")])/1000)+l1l1ll_l1_ (u"ࠫࡰ࡮ࡺࠡࠢࠪ䭼")+dict[l1l1ll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䭽")]+l1l1ll_l1_ (u"࠭ࡣࡩࠩ䭾")+l1l1ll_l1_ (u"ࠧࠡࠢࠪ䭿")+l1l111l_l1_
		except:
			errortrace = traceback.format_exc()
			sys.stderr.write(errortrace)
		if l1l1ll_l1_ (u"ࠨࡦࡸࡶࡂ࠭䮀") in dict[l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭䮁")]: duration = round(0.5+float(dict[l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ䮂")].split(l1l1ll_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ䮃"),1)[1].split(l1l1ll_l1_ (u"ࠬࠬࠧ䮄"),1)[0]))
		elif l1l1ll_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ䮅") in list(dict.keys()): duration = round(0.5+float(dict[l1l1ll_l1_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ䮆")])/1000)
		else: duration = l1l1ll_l1_ (u"ࠨ࠲ࠪ䮇")
		if l1l1ll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䮈") not in list(dict.keys()): l11l11ll1l1_l1_ = dict[l1l1ll_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ䮉")].split(l1l1ll_l1_ (u"ࠫࡽ࠭䮊"))[1]
		else: l11l11ll1l1_l1_ = dict[l1l1ll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䮋")]
		if l1l1ll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䮌") not in list(dict.keys()): dict[l1l1ll_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ䮍")] = l1l1ll_l1_ (u"ࠨ࠲࠰࠴ࠬ䮎")
		dict[l1l1ll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䮏")] = l1l111l1l_l1_+l1l1ll_l1_ (u"ࠪ࠾ࠥࠦࠧ䮐")+l1lll1llll11_l1_+l1l1ll_l1_ (u"ࠫࠥࠦࠨࠨ䮑")+l1lll11111ll_l1_+l1l1ll_l1_ (u"ࠬ࠲ࠧ䮒")+dict[l1l1ll_l1_ (u"࠭ࡩࡵࡣࡪࠫ䮓")]+l1l1ll_l1_ (u"ࠧࠪࠩ䮔")
		dict[l1l1ll_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䮕")] = l1lll1llll11_l1_.split(l1l1ll_l1_ (u"ࠩࠣࠤࠬ䮖"))[0].split(l1l1ll_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ䮗"))[0]
		dict[l1l1ll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䮘")] = l1l111l1l_l1_
		dict[l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䮙")] = l1l111l_l1_
		dict[l1l1ll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䮚")] = codecs
		dict[l1l1ll_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ䮛")] = duration
		dict[l1l1ll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䮜")] = l11l11ll1l1_l1_
		l111ll1l1ll_l1_.append(dict)
	l1111ll11l1_l1_,l11l111l1l1_l1_,l11l1llll1l_l1_,l1lllll1l1ll_l1_,l111l1ll1ll_l1_ = [],[],[],[],[]
	l1llll1l1lll_l1_,l111lll11l1_l1_,l1lll1ll11l1_l1_,l11l1l1l111_l1_,l11l1lll111_l1_ = [],[],[],[],[]
	if l1ll1l111lll_l1_:
		dict = {}
		dict[l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䮝")] = l1l1ll_l1_ (u"ࠪࡅ࠰࡜ࠧ䮞")
		dict[l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䮟")] = l1l1ll_l1_ (u"ࠬࡳࡰࡥࠩ䮠")
		dict[l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䮡")] = dict[l1l1ll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭䮢")]+l1l1ll_l1_ (u"ࠨ࠼ࠣࠤࠬ䮣")+dict[l1l1ll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䮤")]+l1l1ll_l1_ (u"ࠪࠤࠥ࠭䮥")+l1l1ll_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ䮦")
		dict[l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ䮧")] = l1ll1l111lll_l1_
		dict[l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䮨")] = l1l1ll_l1_ (u"ࠧ࠱ࠩ䮩") # for l11ll11lll_l1_ l1ll1l111lll_l1_ any l1l1l1ll1_l1_ will l1111l11111_l1_ l1lll11lll11_l1_ sort l1l1lll111l_l1_
		dict[l1l1ll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䮪")] = l1l1ll_l1_ (u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭䮫") # 20
		l111ll1l1ll_l1_.append(dict)
	if l11ll1111l1_l1_:
		l1ll1llll111_l1_,l11l1111111_l1_ = l11lll1lll_l1_(l11ll1111l1_l1_)
		l11l11ll11l_l1_ = list(zip(l1ll1llll111_l1_,l11l1111111_l1_))
		for title,link in l11l11ll11l_l1_:
			dict = {}
			dict[l1l1ll_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䮬")] = l1l1ll_l1_ (u"ࠫࡆ࠱ࡖࠨ䮭")
			dict[l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䮮")] = l1l1ll_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ䮯")
			dict[l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ䮰")] = link
			#if l1l1ll_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭䮱") in title: dict[l1l1ll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䮲")] = title.split(l1l1ll_l1_ (u"ࠪࠤࠥ࠭䮳"))[1].split(l1l1ll_l1_ (u"ࠫࡰࡨࡰࡴࠩ䮴"))[0]
			#if l1l1ll_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ䮵") in title: dict[l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䮶")] = title.split(l1l1ll_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭䮷"))[1]
			# title = l1l1ll_l1_ (u"ࠣ࠶࠵࠺࠼ࡱࡢࡱࡵࠣࠤ࠼࠸࠰ࠡࠢ࠱ࡱ࠸ࡻ࠸ࠣ䮸")
			if l1l1ll_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ䮹") in title: dict[l1l1ll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䮺")] = title.split(l1l1ll_l1_ (u"ࠫࡰࡨࡰࡴࠩ䮻"))[0].rsplit(l1l1ll_l1_ (u"ࠬࠦࠠࠨ䮼"))[-1]
			else: dict[l1l1ll_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䮽")] = l1l1ll_l1_ (u"ࠧ࠲࠲ࠪ䮾")
			if title.count(l1l1ll_l1_ (u"ࠨࠢࠣࠫ䮿"))>1:
				l11ll1l1_l1_ = title.rsplit(l1l1ll_l1_ (u"ࠩࠣࠤࠬ䯀"))[-3]
				if l11ll1l1_l1_.isdigit(): dict[l1l1ll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ䯁")] = l11ll1l1_l1_
				else: dict[l1l1ll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ䯂")] = l1l1ll_l1_ (u"ࠬ࠶࠰࠱࠲ࠪ䯃")
			#dict[l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䯄")] = title
			if title==l1l1ll_l1_ (u"ࠧ࠮࠳ࠪ䯅"): dict[l1l1ll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䯆")] = dict[l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䯇")]+l1l1ll_l1_ (u"ࠪ࠾ࠥࠦࠧ䯈")+dict[l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䯉")]+l1l1ll_l1_ (u"ࠬࠦࠠࠨ䯊")+l1l1ll_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ䯋")
			else: dict[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䯌")] = dict[l1l1ll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䯍")]+l1l1ll_l1_ (u"ࠩ࠽ࠤࠥ࠭䯎")+dict[l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䯏")]+l1l1ll_l1_ (u"ࠫࠥࠦࠧ䯐")+dict[l1l1ll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䯑")]+l1l1ll_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭䯒")+dict[l1l1ll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ䯓")]
			l111ll1l1ll_l1_.append(dict)
	l111ll1l1ll_l1_ = sorted(l111ll1l1ll_l1_,reverse=True,key=lambda key: float(key[l1l1ll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䯔")]))
	if not l111ll1l1ll_l1_:
		l1ll1l11l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䯕"),html,re.DOTALL)
		l1ll1l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䯖"),html,re.DOTALL)
		l1111l1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䯗"),html,re.DOTALL)
		l1111l1lll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯘"),html,re.DOTALL)
		try: l1111l1llll_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䯙")][l1l1ll_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ䯚")][l1l1ll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ䯛")][l1l1ll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䯜")][l1l1ll_l1_ (u"ࠪࡶࡺࡴࡳࠨ䯝")][0][l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ䯞")]
		except: l1111l1llll_l1_ = l1l1ll_l1_ (u"ࠬ࠭䯟")
		try: l1111ll1111_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䯠")][l1l1ll_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ䯡")][l1l1ll_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ䯢")][l1l1ll_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ䯣")][0][l1l1ll_l1_ (u"ࠪࡶࡺࡴࡳࠨ䯤")][0][l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ䯥")]
		except: l1111ll1111_l1_ = l1l1ll_l1_ (u"ࠬ࠭䯦")
		try: l1lll11ll11l_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䯧")][l1l1ll_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ䯨")]
		except: l1lll11ll11l_l1_ = l1l1ll_l1_ (u"ࠨࠩ䯩")
		if l1ll1l11l11_l1_ or l1ll1l11l1l_l1_ or l1111l1ll1l_l1_ or l1111l1lll1_l1_ or l1111l1llll_l1_ or l1111ll1111_l1_ or l1lll11ll11l_l1_:
			if   l1ll1l11l11_l1_: message = l1ll1l11l11_l1_[0]
			elif l1ll1l11l1l_l1_: message = l1ll1l11l1l_l1_[0]
			elif l1111l1ll1l_l1_: message = l1111l1ll1l_l1_[0]
			elif l1111l1lll1_l1_: message = l1111l1lll1_l1_[0]
			elif l1111l1llll_l1_: message = l1111l1llll_l1_
			elif l1111ll1111_l1_: message = l1111ll1111_l1_
			elif l1lll11ll11l_l1_: message = l1lll11ll11l_l1_
			l1lll1ll1l1l_l1_ = message.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ䯪"),l1l1ll_l1_ (u"ࠪࠫ䯫")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭䯬"))
			l111l11ll1l_l1_ = l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䯭")
			DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䯮"),l1l1ll_l1_ (u"ࠧࠨ䯯"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ䯰"),l111l11ll1l_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䯱")+l1lll1ll1l1l_l1_)
			return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ䯲")+l1lll1ll1l1l_l1_,[],[]
		else: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ䯳"),[],[]
	l1lll11ll1ll_l1_,l1ll11ll1ll1_l1_,l11111ll1ll_l1_ = [],[],[]
	for dict in l111ll1l1ll_l1_:
		if dict[l1l1ll_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䯴")]==l1l1ll_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ䯵"):
			l1111ll11l1_l1_.append(dict[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䯶")])
			l1llll1l1lll_l1_.append(dict)
		elif dict[l1l1ll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䯷")]==l1l1ll_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ䯸"):
			l11l111l1l1_l1_.append(dict[l1l1ll_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䯹")])
			l111lll11l1_l1_.append(dict)
		elif dict[l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䯺")]==l1l1ll_l1_ (u"ࠬࡳࡰࡥࠩ䯻"):
			title = dict[l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䯼")].replace(l1l1ll_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ䯽"),l1l1ll_l1_ (u"ࠨࠩ䯾"))
			if l1l1ll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䯿") not in list(dict.keys()): l11l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪ࠴ࠬ䰀")
			else: l11l11ll1l1_l1_ = dict[l1l1ll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䰁")]
			l1lll11ll1ll_l1_.append([dict,{},title,l11l11ll1l1_l1_])
		else:
			title = dict[l1l1ll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䰂")].replace(l1l1ll_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭䰃"),l1l1ll_l1_ (u"ࠧࠨ䰄"))
			if l1l1ll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䰅") not in list(dict.keys()): l11l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠩ࠳ࠫ䰆")
			else: l11l11ll1l1_l1_ = dict[l1l1ll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰇")]
			l1lll11ll1ll_l1_.append([dict,{},title,l11l11ll1l1_l1_])
			l11l1llll1l_l1_.append(title)
			l1lll1ll11l1_l1_.append(dict)
		l11l11lll1l_l1_ = True
		if l1l1ll_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䰈") in list(dict.keys()):
			if l1l1ll_l1_ (u"ࠬࡧࡶ࠱ࠩ䰉") in dict[l1l1ll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䰊")]: l11l11lll1l_l1_ = False
			elif kodi_version<18:
				if l1l1ll_l1_ (u"ࠧࡢࡸࡦࠫ䰋") not in dict[l1l1ll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䰌")] and l1l1ll_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ䰍") not in dict[l1l1ll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䰎")]: l11l11lll1l_l1_ = False
		if dict[l1l1ll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䰏")]==l1l1ll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ䰐") and dict[l1l1ll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䰑")]!=l1l1ll_l1_ (u"ࠧ࠱࠯࠳ࠫ䰒") and l11l11lll1l_l1_==True:
			l111l1ll1ll_l1_.append(dict[l1l1ll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䰓")])
			l11l1lll111_l1_.append(dict)
		elif dict[l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䰔")]==l1l1ll_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ䰕") and dict[l1l1ll_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䰖")]!=l1l1ll_l1_ (u"ࠬ࠶࠭࠱ࠩ䰗") and l11l11lll1l_l1_==True:
			l1lllll1l1ll_l1_.append(dict[l1l1ll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䰘")])
			l11l1l1l111_l1_.append(dict)
		#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ䰙"),l1l1ll_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ䰚")+dict[l1l1ll_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ䰛")])
	for l11l11l11l1_l1_ in l11l1l1l111_l1_:
		l1lllll1lll1_l1_ = l11l11l11l1_l1_[l1l1ll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰜")]
		for l1111l1l111_l1_ in l11l1lll111_l1_:
			l1lll111ll11_l1_ = l1111l1l111_l1_[l1l1ll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䰝")]
			l11l11ll1l1_l1_ = l1lll111ll11_l1_+l1lllll1lll1_l1_
			title = l1111l1l111_l1_[l1l1ll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䰞")].replace(l1l1ll_l1_ (u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ䰟"),l1l1ll_l1_ (u"ࠧ࡮ࡲࡧࠤࠥ࠭䰠"))
			title = title.replace(l1111l1l111_l1_[l1l1ll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ䰡")]+l1l1ll_l1_ (u"ࠩࠣࠤࠬ䰢"),l1l1ll_l1_ (u"ࠪࠫ䰣"))
			title = title.replace(str((float(l1lll111ll11_l1_*10)//1024/10))+l1l1ll_l1_ (u"ࠫࡰࡨࡰࡴࠩ䰤"),str((float(l11l11ll1l1_l1_*10)//1024/10))+l1l1ll_l1_ (u"ࠬࡱࡢࡱࡵࠪ䰥"))
			title = title+l1l1ll_l1_ (u"࠭ࠨࠨ䰦")+l11l11l11l1_l1_[l1l1ll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䰧")].split(l1l1ll_l1_ (u"ࠨࠪࠪ䰨"),1)[1]
			l1lll11ll1ll_l1_.append([l1111l1l111_l1_,l11l11l11l1_l1_,title,l11l11ll1l1_l1_])
	l1lll11ll1ll_l1_ = sorted(l1lll11ll1ll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1111l1l111_l1_,l11l11l11l1_l1_,title,l11l11ll1l1_l1_ in l1lll11ll1ll_l1_:
		l111ll1l111_l1_ = l1111l1l111_l1_[l1l1ll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䰩")]
		if l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䰪") in list(l11l11l11l1_l1_.keys()):
			l111ll1l111_l1_ = l1l1ll_l1_ (u"ࠫࡲࡶࡤࠨ䰫")
			#l111ll1l111_l1_ = l111ll1l111_l1_+l11l11l11l1_l1_[l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䰬")]
		if l111ll1l111_l1_ not in l11111ll1ll_l1_:
			l11111ll1ll_l1_.append(l111ll1l111_l1_)
			l1ll11ll1ll1_l1_.append([l1111l1l111_l1_,l11l11l11l1_l1_,title,l11l11ll1l1_l1_])
			#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ䰭"),str(l11l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠧࠡࠢࠣࠫ䰮")+title)
	#l1ll11ll1ll1_l1_ = sorted(l1ll11ll1ll1_l1_, reverse=True, key=lambda key: int(key[3]))
	l1lll11ll111_l1_,l1lllll1111l_l1_,shift = [],[],0
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࡳࡩ࡫ࡩࡸࠥ࠱࠽ࠡ࠳ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ࠰ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠶ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ䰯")
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏ࡯ࡸࡰࡨࡶࡤࡩࡨࡢࡰࡱࡩࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰࡤࡰࡳࡰࡰ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡱࡺࡲࡪࡸ࡟࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡡࡶࡶ࡫ࡳࡷࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬ࡠ࡬ࡶࡳࡳ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨ࠾ࠏࠏࠉࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠧ࠮࠮ࠫࡁࠬࠦࡦࡲ࡬ࡰࡹࡕࡥࡹ࡯࡮ࡨࡵࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥ࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭࡫ࡰࡥ࡬࡫ࡳࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡶࡴ࡯࠾ࠥ࡯࡭ࡢࡩࡨࠤࡂࠦࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮࡞࠱࠶ࡣࠊࠊࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫࡛࠱࡟ࠍࠍࠎࡹࡨࡪࡨࡷࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ࠯ࡴࡽ࡮ࡦࡴ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾࡚ࠢࡉࡇ࡙ࡉࡕࡇࡖ࡟ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭࡝࡜࠲ࡠ࠯ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ࠭ࡲࡻࡳ࡫ࡲࡠࡥ࡫ࡥࡳࡴࡥ࡭࡝࠳ࡡࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡣࡩࡱ࡬ࡧࡪࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ䰰")
	l11l11lllll_l1_,l111ll1111l_l1_ = l1l1ll_l1_ (u"ࠪࠫ䰱"),l1l1ll_l1_ (u"ࠫࠬ䰲")
	try: l11l11lllll_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ䰳")][l1l1ll_l1_ (u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭䰴")]
	except: l11l11lllll_l1_ = l1l1ll_l1_ (u"ࠧࠨ䰵")
	try: l1lll1ll1ll1_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ䰶")][l1l1ll_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ䰷")]
	except: l1lll1ll1ll1_l1_ = l1l1ll_l1_ (u"ࠪࠫ䰸")
	if l11l11lllll_l1_ and l1lll1ll1ll1_l1_:
		shift += 1
		title = l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䰹")+l11l11lllll_l1_+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䰺")
		link = WEBSITES[l1l1ll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䰻")][0]+l1l1ll_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ䰼")+l1lll1ll1ll1_l1_
		l1lll11ll111_l1_.append(title)
		l1lllll1111l_l1_.append(link)
		try: l111ll1111l_l1_ = l1lll111111l_l1_[l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ䰽")][l1l1ll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ䰾")][l1l1ll_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ䰿")][-1][l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ䱀")]
		except: pass
	#if l1ll1l111lll_l1_:
	#	shift += 1
	#	l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ࠬࡳࡰࡥࠢฯ์ิฯࠠัๅํอࠬ䱁")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ䱂"))
	for l1111l1l111_l1_,l11l11l11l1_l1_,title,l11l11ll1l1_l1_ in l1ll11ll1ll1_l1_:
		l1lll11ll111_l1_.append(title) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ䱃"))
	if l11l1llll1l_l1_: l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯะหࠪ䱄")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ䱅"))
	if l1lll11ll1ll_l1_: l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦวๅ็อ์ๆืࠧ䱆")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"ࠫࡦࡲ࡬ࠨ䱇"))
	if l111l1ll1ll_l1_: l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ࠬࡳࡰࡥࠢสาฯืࠠศๆุ์ึฯ้ࠠษ็ูํะࠧ䱈")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"࠭࡭ࡱࡦࠪ䱉"))
	if l1111ll11l1_l1_: l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ࠧึ๊ิอࠥฮฯู้่ࠣํะࠧ䱊")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䱋"))
	if l11l111l1l1_l1_: l1lll11ll111_l1_.append(l1l1ll_l1_ (u"ุࠩ์ฯࠦศะ๊้ࠤฺ๎ัสࠩ䱌")) ; l1lllll1111l_l1_.append(l1l1ll_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䱍"))
	l11l1llllll_l1_ = False
	while True:
		selection = DIALOG_SELECT(l1ll11l1l1l1_l1_, l1lll11ll111_l1_)
		if selection==-1: return l1l1ll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䱎"),[],[]
		elif selection==0 and l11l11lllll_l1_:
			link = l1lllll1111l_l1_[selection]
			new_path = sys.argv[0]+l1l1ll_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠶ࠬ࡮ࡢ࡯ࡨࡁࠬ䱏")+QUOTE(l11l11lllll_l1_)+l1l1ll_l1_ (u"࠭ࠦࡶࡴ࡯ࡁࠬ䱐")+link
			if l111ll1111l_l1_: new_path = new_path+l1l1ll_l1_ (u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ䱑")+QUOTE(l111ll1111l_l1_)
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ䱒")+new_path+l1l1ll_l1_ (u"ࠤࠬࠦ䱓"))
			return l1l1ll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䱔"),[],[]
		choice = l1lllll1111l_l1_[selection]
		l1ll1lll1111_l1_ = l1lll11ll111_l1_[selection]
		if choice==l1l1ll_l1_ (u"ࠫࡩࡧࡳࡩࠩ䱕"):
			l1ll1l1ll1l1_l1_ = l1ll1l111lll_l1_
			break
		elif choice in [l1l1ll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ䱖"),l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䱗"),l1l1ll_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭䱘")]:
			if choice==l1l1ll_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ䱙"): l111l1l_l1_,l1llll111l1l_l1_ = l11l1llll1l_l1_,l1lll1ll11l1_l1_
			elif choice==l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䱚"): l111l1l_l1_,l1llll111l1l_l1_ = l1111ll11l1_l1_,l1llll1l1lll_l1_
			elif choice==l1l1ll_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䱛"): l111l1l_l1_,l1llll111l1l_l1_ = l11l111l1l1_l1_,l111lll11l1_l1_
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䱜"), l111l1l_l1_)
			if selection!=-1:
				l1ll1l1ll1l1_l1_ = l1llll111l1l_l1_[selection][l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ䱝")]
				l1ll1lll1111_l1_ = l111l1l_l1_[selection]
				break
		elif choice==l1l1ll_l1_ (u"࠭࡭ࡱࡦࠪ䱞"):
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่าห࠽ࠫ䱟"), l111l1ll1ll_l1_)
			if selection!=-1:
				l1ll1lll1111_l1_ = l111l1ll1ll_l1_[selection]
				l111ll111l1_l1_ = l11l1lll111_l1_[selection]
				selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬ࠽ࠫ䱠"), l1lllll1l1ll_l1_)
				if selection!=-1:
					l1ll1lll1111_l1_ += l1l1ll_l1_ (u"ࠩࠣ࠯ࠥ࠭䱡")+l1lllll1l1ll_l1_[selection]
					l1111l11ll1_l1_ = l11l1l1l111_l1_[selection]
					l11l1llllll_l1_ = True
					break
		elif choice==l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧ䱢"):
			l111lllll11_l1_,l1llllll1l11_l1_,l1ll11lll1ll_l1_,l111l11l11l_l1_ = list(zip(*l1lll11ll1ll_l1_))
			selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䱣"), l1ll11lll1ll_l1_)
			if selection!=-1:
				l1ll1lll1111_l1_ = l1ll11lll1ll_l1_[selection]
				l111ll111l1_l1_ = l111lllll11_l1_[selection]
				if l1l1ll_l1_ (u"ࠬࡳࡰࡥࠩ䱤") in l1ll11lll1ll_l1_[selection] and l111ll111l1_l1_[l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䱥")]!=l1ll1l111lll_l1_:
					l1111l11ll1_l1_ = l1llllll1l11_l1_[selection]
					l11l1llllll_l1_ = True
				else: l1ll1l1ll1l1_l1_ = l111ll111l1_l1_[l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ䱦")]
				break
		elif choice==l1l1ll_l1_ (u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ䱧"):
			#shift += 1
			l111lllll11_l1_,l1llllll1l11_l1_,l1ll11lll1ll_l1_,l111l11l11l_l1_ = list(zip(*l1ll11ll1ll1_l1_))
			l111ll111l1_l1_ = l111lllll11_l1_[selection-shift]
			if l1l1ll_l1_ (u"ࠩࡰࡴࡩ࠭䱨") in l1ll11lll1ll_l1_[selection-shift] and l111ll111l1_l1_[l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ䱩")]!=l1ll1l111lll_l1_:
				l1111l11ll1_l1_ = l1llllll1l11_l1_[selection-shift]
				l11l1llllll_l1_ = True
			else: l1ll1l1ll1l1_l1_ = l111ll111l1_l1_[l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ䱪")]
			l1ll1lll1111_l1_ = l1ll11lll1ll_l1_[selection-shift]
			break
	if not l11l1llllll_l1_: l1ll1l1l1l1l_l1_ = l1ll1l1ll1l1_l1_
	else: l1ll1l1l1l1l_l1_ = l1l1ll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭䱫")+l111ll111l1_l1_[l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ䱬")]+l1l1ll_l1_ (u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫ䱭")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䱮")]
	if l11l1llllll_l1_:
		#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ䱯"),l1l1ll_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ䱰")+str(l111ll111l1_l1_))
		#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ䱱"),l1l1ll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ䱲")+str(l1111l11ll1_l1_))
		#if l11l1ll1ll1_l1_>l11111l1lll_l1_: duration = str(l11l1ll1ll1_l1_)
		#else: duration = str(l11111l1lll_l1_)
		#duration = str(l11l1ll1ll1_l1_) if l11l1ll1ll1_l1_>l11111l1lll_l1_ else str(l11111l1lll_l1_)
		l11l1ll1ll1_l1_ = int(l111ll111l1_l1_[l1l1ll_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ䱳")])
		l11111l1lll_l1_ = int(l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ䱴")])
		duration = str(max(l11l1ll1ll1_l1_,l11111l1lll_l1_))
		l1111111l1l_l1_ = l111ll111l1_l1_[l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䱵")].replace(l1l1ll_l1_ (u"ࠩࠩࠫ䱶"),l1l1ll_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ䱷"))		# +l1l1ll_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ䱸")
		l11l111l1ll_l1_ = l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ䱹")].replace(l1l1ll_l1_ (u"࠭ࠦࠨ䱺"),l1l1ll_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭䱻"))		# +l1l1ll_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ䱼")
		l11l1llll11_l1_ = l1l1ll_l1_ (u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨ䱽")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫ䱾")+duration+l1l1ll_l1_ (u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰࠪ䱿")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ䲀")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪ䲁")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䲂")]+l1l1ll_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ䲃")		# l11111lll1l_l1_=l1l1ll_l1_ (u"ࠤ࠴ࠦ䲄") l11l1lll1l1_l1_=l1l1ll_l1_ (u"ࠥࡸࡷࡻࡥࠣ䲅") default=l1l1ll_l1_ (u"ࠦࡹࡸࡵࡦࠤ䲆")>\n
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ䲇")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭䲈")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ䲉")]+l1l1ll_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ䲊")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ䲋")]+l1l1ll_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭䲌")+str(l111ll111l1_l1_[l1l1ll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䲍")])+l1l1ll_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ䲎")+str(l111ll111l1_l1_[l1l1ll_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ䲏")])+l1l1ll_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ䲐")+str(l111ll111l1_l1_[l1l1ll_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ䲑")])+l1l1ll_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ䲒")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠪࡪࡵࡹࠧ䲓")]+l1l1ll_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ䲔")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ䲕")+l1111111l1l_l1_+l1l1ll_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ䲖")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ䲗")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ䲘")]+l1l1ll_l1_ (u"ࠩࠥࡂࡡࡴࠧ䲙")	# l1ll11ll1lll_l1_=l1l1ll_l1_ (u"ࠥࡸࡷࡻࡥࠣ䲚")>\n
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ䲛")+l111ll111l1_l1_[l1l1ll_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ䲜")]+l1l1ll_l1_ (u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭䲝")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ䲞")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ䲟")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ䲠")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠳ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧ䲡")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䲢")]+l1l1ll_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ䲣")		# l11111lll1l_l1_=l1l1ll_l1_ (u"ࠨ࠱ࠣ䲤") l11l1lll1l1_l1_=l1l1ll_l1_ (u"ࠢࡵࡴࡸࡩࠧ䲥") default=l1l1ll_l1_ (u"ࠣࡶࡵࡹࡪࠨ䲦")>\n
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ䲧")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ䲨")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䲩")]+l1l1ll_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ䲪")+l1111l11ll1_l1_[l1l1ll_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䲫")]+l1l1ll_l1_ (u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ䲬")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧ䲭")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䲮")]+l1l1ll_l1_ (u"ࠪࠦ࠴ࡄ࡜࡯ࠩ䲯")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ䲰")+l11l111l1ll_l1_+l1l1ll_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ䲱")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ䲲")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭䲳")]+l1l1ll_l1_ (u"ࠨࠤࡁࡠࡳ࠭䲴")	# l1ll11ll1lll_l1_=l1l1ll_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ䲵")>\n
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭䲶")+l1111l11ll1_l1_[l1l1ll_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䲷")]+l1l1ll_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ䲸")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ䲹")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭䲺")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭䲻")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ䲼")
		l11l1llll11_l1_ += l1l1ll_l1_ (u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬ䲽")
		#open(l1l1ll_l1_ (u"ࠫࡸࡀ࡜࡝ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭䲾"),l1l1ll_l1_ (u"ࠬࡽࡢࠨ䲿")).write(l11l1llll11_l1_)
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ䳀"),l11l1llll11_l1_)
		#l11l1llll11_l1_ = OPENURL_CACHED(NO_CACHE,l1ll1l111lll_l1_,l1l1ll_l1_ (u"ࠧࠨ䳁"),l1l1ll_l1_ (u"ࠨࠩ䳂"),l1l1ll_l1_ (u"ࠩࠪ䳃"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠺ࡶ࡫ࠫ䳄"))
		if kodi_version>18.99:
			import http.server as l1111llll11_l1_
			import http.client as l1lll11l1ll1_l1_
		else:
			import BaseHTTPServer as l1111llll11_l1_
			import httplib as l1lll11l1ll1_l1_
		class l1ll1ll1l1ll_l1_(l1111llll11_l1_.HTTPServer):
			#l11l1llll11_l1_ = l1l1ll_l1_ (u"ࠫࡁࡄࠧ䳅")
			def __init__(self,l1lll1l1111l_l1_=l1l1ll_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ䳆"),port=55055,l11l1llll11_l1_=l1l1ll_l1_ (u"࠭࠼࠿ࠩ䳇")):
				self.l1lll1l1111l_l1_ = l1lll1l1111l_l1_
				self.port = port
				self.l11l1llll11_l1_ = l11l1llll11_l1_
				l1111llll11_l1_.HTTPServer.__init__(self,(self.l1lll1l1111l_l1_,self.port),l1lllll11l1l_l1_)
				self.l1ll1ll111l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䳈")+l1lll1l1111l_l1_+l1l1ll_l1_ (u"ࠨ࠼ࠪ䳉")+str(port)+l1l1ll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ䳊")
				#print(l1l1ll_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡵࡱࠢࡱࡳࡼࠦ࡬ࡪࡵࡷࡩࡳ࡯࡮ࡨࠢࡲࡲࠥࡶ࡯ࡳࡶ࠽ࠤࠬ䳋")+str(port))
			def start(self):
				self.threads = l111ll11lll_l1_(False)
				self.threads.start_new_thread(1,self.l11111l111l_l1_)
			def l11111l111l_l1_(self):
				#print(l1l1ll_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡤࡶࡹ࡫ࡤࠨ䳌"))
				self.l1ll11ll111l_l1_ = True
				#l1l1lll11ll_l1_ = 0
				while self.l1ll11ll111l_l1_:
					#l1l1lll11ll_l1_ += 1
					#print(l1l1ll_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡪࡤࡲࡩࡲࡥࡠࡴࡨࡵࡺ࡫ࡳࡵࠪࠬࠤࡳࡵࡷ࠻ࠢࠪ䳍")+str(l1l1lll11ll_l1_)+l1l1ll_l1_ (u"࠭ࠧ䳎"))
					#settimeout l111ll111l_l1_ not l11l111111_l1_ l1lll1l1llll_l1_ to error message if it l1ll1lllllll_l1_ l1ll1l11111l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l11111l111l_l1_ l11111ll1l1_l1_ request l1ll1l1lll1l_l1_ 60 seconds)
					self.handle_request()
				#print(l1l1ll_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡵࡰࡱࡧࡧࡠࡳ࠭䳏"))
			def stop(self):
				self.l1ll11ll111l_l1_ = False
				self.l1111l1l11l_l1_()	# needed to l11l1l1ll11_l1_ self.handle_request() to l11111l111l_l1_ l111l1l11l1_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l1l1ll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠢࡱࡳࡼࡢ࡮ࠨ䳐"))
			def load(self,l11l1llll11_l1_):
				self.l11l1llll11_l1_ = l11l1llll11_l1_
			def l1111l1l11l_l1_(self):
				conn = l1lll11l1ll1_l1_.HTTPConnection(self.l1lll1l1111l_l1_+l1l1ll_l1_ (u"ࠩ࠽ࠫ䳑")+str(self.port))
				conn.request(l1l1ll_l1_ (u"ࠥࡌࡊࡇࡄࠣ䳒"), l1l1ll_l1_ (u"ࠦ࠴ࠨ䳓"))
		class l1lllll11l1l_l1_(l1111llll11_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l1l1ll_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡌࡋࡔࠡࠢࠪ䳔")+self.path)
				self.send_response(200)
				self.send_header(l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ䳕"),l1l1ll_l1_ (u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ䳖"))
				self.end_headers()
				#self.wfile.write(self.path+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ䳗"))
				self.wfile.write(self.server.l11l1llll11_l1_.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䳘")))
				time.sleep(1)
				if self.path==l1l1ll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ䳙"): self.server.shutdown()
				if self.path==l1l1ll_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ䳚"): self.server.shutdown()
			def do_HEAD(self):
				#print(l1l1ll_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡍࡋࡁࡅࠢࠣࠫ䳛")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1ll1ll1l1ll_l1_(l1l1ll_l1_ (u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ䳜"),55055,l11l1llll11_l1_)
		#httpd.load(l11l1llll11_l1_)
		l1ll1l1ll1l1_l1_ = httpd.l1ll1ll111l1_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮࡬ࡺࡪࡹࡩ࡮࠰ࡧࡥࡸ࡮ࡩࡧ࠰ࡲࡶ࡬࠵࡬ࡪࡸࡨࡷ࡮ࡳ࠯ࡤࡪࡸࡲࡰࡪࡵࡳࡡ࠴࠳ࡦࡺ࡯ࡠ࠹࠲ࡸࡪࡹࡴࡱ࡫ࡦ࠸ࡤ࠾ࡳ࠰ࡏࡤࡲ࡮࡬ࡥࡴࡶ࠱ࡱࡵࡪࠧ䳝")
		#l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡥࡸ࡮࠮ࡢ࡭ࡤࡱࡦ࡯ࡺࡦࡦ࠱ࡲࡪࡺ࠯ࡥࡣࡶ࡬࠷࠼࠴࠰ࡖࡨࡷࡹࡉࡡࡴࡧࡶ࠳࠷ࡩ࠯ࡲࡷࡤࡰࡨࡵ࡭࡮࠱࠴࠳ࡒࡻ࡬ࡵ࡫ࡕࡩࡸࡓࡐࡆࡉ࠵࠲ࡲࡶࡤࠨ䳞")
		#l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹࡹࡩ࠯ࡶࡨࡰࡪࡩ࡯࡮࠯ࡳࡥࡷ࡯ࡳࡵࡧࡦ࡬࠳࡬ࡲ࠰ࡩࡳࡥࡨ࠵ࡄࡂࡕࡋࡣࡈࡕࡎࡇࡑࡕࡑࡆࡔࡃࡆ࠱ࡗࡩࡱ࡫ࡣࡰ࡯ࡓࡥࡷ࡯ࡳࡕࡧࡦ࡬࠴ࡳࡰ࠵࠯࡯࡭ࡻ࡫࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠯ࡰࡴࡩ࠳ࡁࡗ࠯ࡅࡗ࠳ࡳࡰࡥࠩ䳟")
		#l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡶࡩࡳࡥࡥ࡫ࡤ࠲ࡧࡨࡣ࠯ࡥࡲ࠲ࡺࡱ࠯ࡥࡣࡶ࡬࠴ࡵ࡮ࡥࡧࡰࡥࡳࡪ࠯ࡵࡧࡶࡸࡨࡧࡲࡥ࠱࠴࠳ࡨࡲࡩࡦࡰࡷࡣࡲࡧ࡮ࡪࡨࡨࡷࡹ࠳ࡥࡷࡧࡱࡸࡸ࠳࡭ࡶ࡮ࡷ࡭ࡱࡧ࡮ࡨ࠰ࡰࡴࡩ࠭䳠")
		#l1ll1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ䳡")
	else: httpd = l1l1ll_l1_ (u"ࠬ࠭䳢")
	if not l1ll1l1ll1l1_l1_: return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭䳣"),[],[]
	return l1l1ll_l1_ (u"ࠧࠨ䳤"),[l1l1ll_l1_ (u"ࠨࠩ䳥")],[[l1ll1l1ll1l1_l1_,l1lllllll1ll_l1_,httpd]]
def l1llll111111_l1_(url):
	# l1lll11l_l1_://l11l1l11l11_l1_.l1lll1ll1_l1_/l1llll1l1ll1_l1_
	headers = { l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䳦") : l1l1ll_l1_ (u"ࠪࠫ䳧") }
	#url = url.replace(l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䳨"),l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ䳩"))
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"࠭ࠧ䳪"),headers,l1l1ll_l1_ (u"ࠧࠨ䳫"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨ䳬"))
	items = re.findall(l1l1ll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭䳭"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1ll1llll111_l1_,l111l1l_l1_,l11l1111111_l1_,l11l1_l1_ = [],[],[],[]
	if items:
		for link,dummy,l1llll11l1ll_l1_ in items:
			link = link.replace(l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ䳮"),l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䳯"))
			if l1l1ll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䳰") in link:
				l1ll1llll111_l1_,l11l1111111_l1_ = l11lll1lll_l1_(link)
				#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䳱"),l1l1ll_l1_ (u"ࠧࠨ䳲"),str(l11l1_l1_),str(l11l1111111_l1_))
				l11l1_l1_ = l11l1_l1_ + l11l1111111_l1_
				if l1ll1llll111_l1_[0]==l1l1ll_l1_ (u"ࠨ࠯࠴ࠫ䳳"): l111l1l_l1_.append(l1l1ll_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ䳴")+l1l1ll_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ䳵"))
				else:
					for title in l1ll1llll111_l1_:
						l111l1l_l1_.append(l1l1ll_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ䳶")+l1l1ll_l1_ (u"ࠬࠦࠠࠡࠩ䳷")+title)
			else:
				title = l1l1ll_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ䳸")+l1l1ll_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ䳹")+l1llll11l1ll_l1_
				l11l1_l1_.append(link)
				l111l1l_l1_.append(title)
		return l1l1ll_l1_ (u"ࠨࠩ䳺"),l111l1l_l1_,l11l1_l1_
	else: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ䳻"),[],[]
def	l1ll1l11l11l_l1_(url):
	# l1lll11l_l1_://l11l1l1llll_l1_.cc/l1l1l1l11_l1_-1qrpoobdg7bu.html
	# l1lll11l_l1_://l1111l11l11_l1_.cc//l1l1l1l11_l1_-l111l11l1l1_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䳼"),url,l1l1ll_l1_ (u"ࠫࠬ䳽"),l1l1ll_l1_ (u"ࠬ࠭䳾"),l1l1ll_l1_ (u"࠭ࠧ䳿"),l1l1ll_l1_ (u"ࠧࠨ䴀"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡜ࡉࡅࡇࡒࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ䴁"))
	html = response.content
	l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴂"),html,re.DOTALL)
	if l1ll_l1_:
		link = l1ll_l1_[0]
		return l1l1ll_l1_ (u"ࠪࠫ䴃"),[l1l1ll_l1_ (u"ࠫࠬ䴄")],[link]
	return l1l1ll_l1_ (u"ࠬ࠭䴅"),[],[]
def	l1ll1l1l11l1_l1_(url):
	# l1lll11l_l1_://l1ll1l1l111l_l1_.in/l1lll1111l11_l1_
	# l1lll11l_l1_://l1ll1l1l111l_l1_.in/l1l1l1l11_l1_-l1lll1111l11_l1_.html
	# l1lll11l_l1_://l111l11111l_l1_.l1lll1l111ll_l1_/l11l11ll1ll_l1_
	# l1lll11l_l1_://l111l11111l_l1_.l1lll1l111ll_l1_/l1l1l1l11_l1_-l11l11ll1ll_l1_.html
	# l1lll11l_l1_://l1l1ll1llll_l1_.l11l1l1111l_l1_.l1lll1ll1_l1_/l1l1l1l11_l1_-l1llllll1111_l1_.html
	url = url.replace(l1l1ll_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭䴆"),l1l1ll_l1_ (u"ࠧࠨ䴇")).replace(l1l1ll_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䴈"),l1l1ll_l1_ (u"ࠩࠪ䴉"))
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ䴊"),url,l1l1ll_l1_ (u"ࠫࠬ䴋"),l1l1ll_l1_ (u"ࠬ࠭䴌"),l1l1ll_l1_ (u"࠭ࠧ䴍"),l1l1ll_l1_ (u"ࠧࠨ䴎"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ䴏"))
	html = response.content
	l1llll1l111l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠨ䴐"),html,re.DOTALL)
	if l1llll1l111l_l1_:
		l1llll1l111l_l1_ = l1llll1l111l_l1_[0]
		l1lll11l1l11_l1_ = l1lll1l111l1_l1_(l1llll1l111l_l1_)
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䴑"),l1lll11l1l11_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠭ࢂ࠭䴒"),l1lll11l1l11_l1_,re.DOTALL)
		l111l1l_l1_,l11l1_l1_ = [],[]
		for link,title in l1ll_l1_:
			if not title: title = link.rsplit(l1l1ll_l1_ (u"ࠬ࠴ࠧ䴓"),1)[1]
			l111l1l_l1_.append(title)
			l11l1_l1_.append(link)
		return l1l1ll_l1_ (u"࠭ࠧ䴔"),l111l1l_l1_,l11l1_l1_
	id = url.split(l1l1ll_l1_ (u"ࠧ࠰ࠩ䴕"))[3]
	headers = { l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䴖"):l1l1ll_l1_ (u"ࠩࠪ䴗") , l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䴘"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䴙") }
	payload = { l1l1ll_l1_ (u"ࠬ࡯ࡤࠨ䴚"):id , l1l1ll_l1_ (u"࠭࡯ࡱࠩ䴛"):l1l1ll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ䴜") }
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䴝"),url,payload,headers,l1l1ll_l1_ (u"ࠩࠪ䴞"),l1l1ll_l1_ (u"ࠪࠫ䴟"),l1l1ll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ䴠"))
	html = response.content
	items = re.findall(l1l1ll_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䴡"),html,re.DOTALL)
	if items: return l1l1ll_l1_ (u"࠭ࠧ䴢"),[l1l1ll_l1_ (u"ࠧࠨ䴣")],[ items[0] ]
	return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈࠩ䴤"),[],[]
l1l1ll_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡊࡓ࡛ࡏࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵࡶࡪࡦ࠱ࡧࡴ࠵ࡶࡪࡦࡨࡳ࠴ࡶ࡬ࡢࡻ࠲ࡅࡆ࡜ࡅࡏࡦࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࠡ࠼ࠣࠫࠬࠦࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡖࡊࡆ࠰࠵ࡸࡺࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡪࠥ࠭࠮࡮࠵ࡸ࠼ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࡵࡧࡰࡴࡠ࠶࡝࠾࠿ࠪ࠱࠶࠭࠺ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧู๊ࠬࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠾ࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱࡵ࠺ࠧࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔ࡜ࡉࡅࠩ࠯࡟ࡢ࠲࡛࡞ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠲࡯࠱࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡹࡴࡳࡧࡤࡱ࠴࠸࠲࠺࠰ࡰ࠷ࡺ࠾ࠊࠣࠤࠥ䴥")
#####################################################
#    l11l11l111l_l1_ l1llll1lll11_l1_ l1lll1l11lll_l1_
#    16-06-2019
#####################################################
def l1llll11ll1l_l1_(url):
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠪࠫ䴦"),l1l1ll_l1_ (u"ࠫࠬ䴧"),l1l1ll_l1_ (u"ࠬ࠭䴨"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩ䴩"))
	items = re.findall(l1l1ll_l1_ (u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䴪"),html,re.DOTALL)
	if items: return l1l1ll_l1_ (u"ࠨࠩ䴫"),[l1l1ll_l1_ (u"ࠩࠪ䴬")],[ items[0] ]
	else: return l1l1ll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨ䴭"),[],[]
def l1llll11111l_l1_(url):
	return l1l1ll_l1_ (u"ࠫࠬ䴮"),[l1l1ll_l1_ (u"ࠬ࠭䴯")],[ url ]
def l1llll1llll1_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ䴰"),l1l1ll_l1_ (u"ࠧࠨ䴱"),url,l1l1ll_l1_ (u"ࠨࠩ䴲"))
	server = url.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ䴳"))
	basename = l1l1ll_l1_ (u"ࠪ࠳ࠬ䴴").join(server[0:3])
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠫࠬ䴵"),l1l1ll_l1_ (u"ࠬ࠭䴶"),l1l1ll_l1_ (u"࠭ࠧ䴷"),l1l1ll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ䴸"))
	items = re.findall(l1l1ll_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䴹"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䴺"),l1l1ll_l1_ (u"ࠪࠫ䴻"),url,str(var))
	if items:
		l1l111l1l11_l1_,l1l11l1111l_l1_,l1l11l111l1_l1_,l111l111lll_l1_,l111l11l111_l1_,l111l111ll1_l1_ = items[0]
		var = int(l1l11l1111l_l1_) % int(l1l11l111l1_l1_) + int(l111l111lll_l1_) % int(l111l11l111_l1_)
		url = basename + l1l111l1l11_l1_ + str(var) + l111l111ll1_l1_
		return l1l1ll_l1_ (u"ࠫࠬ䴼"),[l1l1ll_l1_ (u"ࠬ࠭䴽")],[url]
	else: return l1l1ll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ䴾"),[],[]
def l1111lll1ll_l1_(url):
	url = url.replace(l1l1ll_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䴿"),l1l1ll_l1_ (u"ࠨࠩ䵀"))
	url = url.replace(l1l1ll_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ䵁"),l1l1ll_l1_ (u"ࠪࠫ䵂"))
	id = url.split(l1l1ll_l1_ (u"ࠫ࠴࠭䵃"))[-1]
	headers = { l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䵄") : l1l1ll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䵅") }
	payload = { l1l1ll_l1_ (u"ࠢࡪࡦࠥ䵆"):id , l1l1ll_l1_ (u"ࠣࡱࡳࠦ䵇"):l1l1ll_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ䵈") }
	request = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䵉"), url, payload, headers, l1l1ll_l1_ (u"ࠫࠬ䵊"),l1l1ll_l1_ (u"ࠬ࠭䵋"),l1l1ll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ䵌"))
	if l1l1ll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䵍") in list(request.headers.keys()): link = request.headers[l1l1ll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䵎")]
	else: link = url
	if link: return l1l1ll_l1_ (u"ࠩࠪ䵏"),[l1l1ll_l1_ (u"ࠪࠫ䵐")],[link]
	else: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ䵑"),[],[]
def l1lll11l11l1_l1_(url):
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠬ࠭䵒"),l1l1ll_l1_ (u"࠭ࠧ䵓"),l1l1ll_l1_ (u"ࠧࠨ䵔"),l1l1ll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ䵕"))
	items = re.findall(l1l1ll_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ䵖"),html,re.DOTALL)
	if items: return l1l1ll_l1_ (u"ࠪࠫ䵗"),[l1l1ll_l1_ (u"ࠫࠬ䵘")],[ items[0] ]
	else: return l1l1ll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ䵙"),[],[]
def l1ll11ll11ll_l1_(url):
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"࠭ࠧ䵚"),l1l1ll_l1_ (u"ࠧࠨ䵛"),l1l1ll_l1_ (u"ࠨࠩ䵜"),l1l1ll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ䵝"))
	items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䵞"),html,re.DOTALL)
	#l1111l111ll_l1_.l1ll11lllll1_l1_(l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ䵟") + items[0])
	if items:
		url = url = l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ䵠") + items[0]
		return l1l1ll_l1_ (u"࠭ࠧ䵡"),[l1l1ll_l1_ (u"ࠧࠨ䵢")],[ url ]
	else: return l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ䵣"),[],[]
def l1llllll11l1_l1_(url):
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠩࠪ䵤"),l1l1ll_l1_ (u"ࠪࠫ䵥"),l1l1ll_l1_ (u"ࠫࠬ䵦"),l1l1ll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖ࠰࠵ࡸࡺࠧ䵧"))
	items = re.findall(l1l1ll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䵨"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ䵩"),l1l1ll_l1_ (u"ࠨࠩ䵪"),str(items),html)
	if items: return l1l1ll_l1_ (u"ࠩࠪ䵫"),[l1l1ll_l1_ (u"ࠪࠫ䵬")],[ items[0] ]
	else: return l1l1ll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡖࡄࡏࡍࡈ࡜ࡉࡅࡇࡒࡌࡔ࡙ࡔࠨ䵭"),[],[]
def l1llll11l111_l1_(url):
	#url = url.replace(l1l1ll_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䵮"),l1l1ll_l1_ (u"࠭ࠧ䵯"))
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠧࠨ䵰"),l1l1ll_l1_ (u"ࠨࠩ䵱"),l1l1ll_l1_ (u"ࠩࠪ䵲"),l1l1ll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ䵳"))
	items = re.findall(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䵴"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䵵"),l1l1ll_l1_ (u"࠭ࠧ䵶"),items[0],items[0])
	if items: return l1l1ll_l1_ (u"ࠧࠨ䵷"),[l1l1ll_l1_ (u"ࠨࠩ䵸")],[ items[0] ]
	else: return l1l1ll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ䵹"),[],[]
l1l1ll_l1_ (u"ࠥࠦࠧࠐࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠎࠨࠦࠠࠡࠢࡑࡓ࡙ࠦࡗࡐࡔࡎࡍࡓࡍࠠࡂࡐ࡜ࡑࡔࡘࡅࠋࠥࠣࠤࠥࠦ࠰࠳࠯ࡉࡉࡇ࠳࠲࠱࠴࠴ࠎࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠌࠍࠎࠏࠐࠢࠣࠤ䵺")
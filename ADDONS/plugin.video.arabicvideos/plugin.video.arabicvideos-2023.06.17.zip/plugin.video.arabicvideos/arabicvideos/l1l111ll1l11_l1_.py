# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠪࡗࡍࡕࡆࡉࡃࠪ嘂")
menu_name = l1l1ll_l1_ (u"ࠫࡤ࡙ࡈࡕࡡࠪ嘃")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ嘄"),l1l1ll_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ嘅"),l1l1ll_l1_ (u"ࠧฤใ็ห๊ࠦไๅๅหหึࠦแใูࠪ嘆")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l11l1l_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l11_l1_(url,text)
	elif mode==644: results = l1ll1l_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ嘇"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ嘈"),l1l1ll_l1_ (u"ࠪࠫ嘉"),l1l1ll_l1_ (u"ࠫࠬ嘊"),l1l1ll_l1_ (u"ࠬ࠭嘋"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嘌"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘍"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ嘎"),l1l1ll_l1_ (u"ࠩࠪ嘏"),649,l1l1ll_l1_ (u"ࠪࠫ嘐"),l1l1ll_l1_ (u"ࠫࠬ嘑"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ嘒"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嘓"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嘔"),l1l1ll_l1_ (u"ࠨࠩ嘕"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘖"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ嘗")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ嘘"),l1l1l1_l1_,641,l1l1ll_l1_ (u"ࠬ࠭嘙"),l1l1ll_l1_ (u"࠭ࠧ嘚"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ嘛"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嘜"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ嘝")+menu_name+l1l1ll_l1_ (u"ࠪะิ๐ฯࠡษ็้ํู่ࠨ嘞"),l1l1l1_l1_,641,l1l1ll_l1_ (u"ࠫࠬ嘟"),l1l1ll_l1_ (u"ࠬ࠭嘠"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ嘡"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘢"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嘣")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ嘤"),l1l1l1_l1_,641,l1l1ll_l1_ (u"ࠪࠫ嘥"),l1l1ll_l1_ (u"ࠫࠬ嘦"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ嘧"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘨"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嘩")+menu_name+l1l1ll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ嘪"),l1l1l1_l1_,641,l1l1ll_l1_ (u"ࠩࠪ嘫"),l1l1ll_l1_ (u"ࠪࠫ嘬"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭嘭"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嘮"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嘯"),l1l1ll_l1_ (u"ࠧࠨ嘰"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭嘱"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ嘲"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1ll11_l1_: continue
	#	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘳"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嘴")+menu_name+title,link,644)
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嘵"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嘶"),l1l1ll_l1_ (u"ࠧࠨ嘷"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ嘸"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ嘹"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠪࠫ嘺"))
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ嘻"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嘼"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ嘽")+menu_name+title,link,644)
	return
def l1ll1l_l1_(url):
	l111ll1l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ嘾"),url,l1l1ll_l1_ (u"ࠨࠩ嘿"),l1l1ll_l1_ (u"ࠩࠪ噀"),l1l1ll_l1_ (u"ࠪࠫ噁"),l1l1ll_l1_ (u"ࠫࠬ噂"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ噃"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ噄"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ噅"),l1l1ll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ噆"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭噇"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠪࠫ噈"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ噉"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ噊"),l1l1ll_l1_ (u"࠭ࠧ噋"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			l111ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ噌"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"ࠨ࠼ࠣࠫ噍")
			for link,title in l111ll1l1_l1_:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ噎"),menu_name+title,link,641)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ噏"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭噐"),block,re.DOTALL)
		if len(l1lll1l_l1_)<30:
			if l111ll1l1_l1_: addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ噑"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭噒"),l1l1ll_l1_ (u"ࠧࠨ噓"),9999)
			for link,title in l1lll1l_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噔"),menu_name+title,link,641)
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠩࠪ噕")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ噖"),l1l1ll_l1_ (u"ࠫࠬ噗"),request,url)
	if request==l1l1ll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪ噘"):
		url,search = url.split(l1l1ll_l1_ (u"࠭࠿ࠨ噙"),1)
		data = l1l1ll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭噚")+search
		headers = {l1l1ll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ噛"):l1l1ll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ噜")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ噝"),url,data,headers,l1l1ll_l1_ (u"ࠫࠬ噞"),l1l1ll_l1_ (u"ࠬ࠭噟"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ噠"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ噡"),url,l1l1ll_l1_ (u"ࠨࠩ噢"),l1l1ll_l1_ (u"ࠩࠪ噣"),l1l1ll_l1_ (u"ࠪࠫ噤"),l1l1ll_l1_ (u"ࠫࠬ噥"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ噦"))
	html = response.content
	block,items = l1l1ll_l1_ (u"࠭ࠧ噧"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ器"))
	if request==l1l1ll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭噩"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ噪"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"ࠪࠫ噫"),link,title))
	elif request==l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭噬"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭噭"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ噮"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ噯"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ噰"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ噱"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ噲"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭噳"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ噴"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((l1l1ll_l1_ (u"࠭ࠧ噵"),link,title))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ噶"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噷"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩ噸"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨ噹"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪ噺"),l1l1ll_l1_ (u"้ࠬไ๋สࠪ噻"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬ噼"),l1l1ll_l1_ (u"่ࠧัสๅࠬ噽"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨ噾"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭噿"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪ嚀"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪ嚁"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬ嚂")]
	for img,link,title in items:
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"࠭࠯ࠨ嚃"))
		#if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ嚄") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪ嚅")+link.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ嚆"))
		#if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嚇") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭嚈")+img.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ嚉"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ嚊"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ嚋"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嚌"),menu_name+title,link,642,img)
		elif request==l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ嚍"):
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嚎"),menu_name+title,link,642,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ嚏") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嚐"),menu_name+title,link,643,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ嚑") in link:
		#	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嚒"),menu_name+title,link,641,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嚓"),menu_name+title,link,643,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ嚔"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ嚕")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ嚖"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ嚗"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"࠭ࠣࠨ嚘"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ嚙")+link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ嚚"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嚛"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩ嚜")+title,link,641)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ嚝"),l1l1ll_l1_ (u"ࠬ࠭嚞"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ嚟"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ嚠"),url,l1l1ll_l1_ (u"ࠨࠩ嚡"),l1l1ll_l1_ (u"ࠩࠪ嚢"),l1l1ll_l1_ (u"ࠪࠫ嚣"),l1l1ll_l1_ (u"ࠫࠬ嚤"),l1l1ll_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ嚥"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩ嚦"),html,re.DOTALL)
	image = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嚧"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ࠨࠩ嚨")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ嚩"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠪࠧࠬ嚪"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚫"),menu_name+title,url,643,img,l1l1ll_l1_ (u"ࠬ࠭嚬"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡦࡴ࡬ࡩࡂࠨࠧ嚭")+l1lll_l1_+l1l1ll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭嚮"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪ嚯"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		#if not items: items = re.findall(l1l1ll_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嚰"),block,re.DOTALL)
		for link,title,img in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ嚱")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭嚲"))
			title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃࡂࡥ࡮ࡀࠪ嚳"),l1l1ll_l1_ (u"࠭ࠠࠨ嚴"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嚵"),menu_name+title,link,642,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ嚶"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ嚷") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ嚸")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭嚹"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嚺"),menu_name+title,link,642,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ嚻"),l1l1ll_l1_ (u"ࠧ࠰ࡸ࡬ࡩࡼ࠴ࡰࡩࡲࠪ嚼"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ嚽"),url2,l1l1ll_l1_ (u"ࠩࠪ嚾"),l1l1ll_l1_ (u"ࠪࠫ嚿"),l1l1ll_l1_ (u"ࠫࠬ囀"),l1l1ll_l1_ (u"ࠬ࠭囁"),l1l1ll_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ囂"))
	html = response.content
	# l1l1l1l11_l1_ link
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡤࡦࡦ࠰ࡺ࡮ࡪࡥࡰࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ囃"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭囄"),block,re.DOTALL)
		if l1ll_l1_:
			link = l1ll_l1_[0]
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ囅"))
				l11l1_l1_.append(link)
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡖࡩࡷࡼࡥࡳࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ囆"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l111l11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫ囇"),block,re.DOTALL)
		block = block.replace(l1l1ll_l1_ (u"ࠬࡢ࡜ࠣࠩ囈"),l1l1ll_l1_ (u"࠭ࠢࠨ囉")).replace(l1l1ll_l1_ (u"ࠧ࡝࠱ࠪ囊"),l1l1ll_l1_ (u"ࠨ࠱ࠪ囋"))
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡀ࡮࡬ࡲࡢ࡯ࡨ࠲ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ囌"),block,re.DOTALL)
		if len(l111l11ll_l1_)==len(l1ll_l1_):
			for id,title in l111l11ll_l1_:
				link = l1ll_l1_[int(id)]
				if link not in l11l1_l1_:
					l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ囍")+title+l1l1ll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ囎"))
					l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡄࡰࡹࡱࡰࡴࡧࡤࡔࡧࡵࡺࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ囏"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ囐"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ囑")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ囒"))
				l11l1_l1_.append(link)
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ囓"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ囔"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ囕"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭囖"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ囗"),l1l1ll_l1_ (u"ࠧࠬࠩ囘"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ囙")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ囚"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ四")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ囜"))
	return
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
headers = { l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨহ") : l1l1ll_l1_ (u"ࠬ࠭঺") }
script_name = l1l1ll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ঻")
menu_name = l1l1ll_l1_ (u"ࠧࡠࡃࡎࡇࡤ়࠭")
l1l1l1_l1_ = WEBSITES[script_name][0]
#l11l1l1_l1_ = [l1l1ll_l1_ (u"ࠨใํ่๊࠭ঽ"),l1l1ll_l1_ (u"ࠩๆ่๏ฮࠧা"),l1l1ll_l1_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫি"),l1l1ll_l1_ (u"ู๊ࠫัฮ์ฬࠫী"),l1l1ll_l1_ (u"๋ࠬำาฯํ๋ࠬু"),l1l1ll_l1_ (u"࠭ว฻่ํอࠬূ"),l1l1ll_l1_ (u"ࠧศ฻็ห๋࠭ৃ"),l1l1ll_l1_ (u"ࠨๆๅหฦ࠭ৄ")]
#proxy = l1l1ll_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱࠴࠹࠾࠴࠲࠱࠵࠱࠼࠼࠴࠱࠴࠲࠽࠷࠶࠸࠸ࠨ৅")
#proxy = l1l1ll_l1_ (u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ৆")+l1l111l1_l1_[6][1]
#l1ll11_l1_ = [l1l1ll_l1_ (u"ࠫอืวๆฮࠪে"),l1l1ll_l1_ (u"ࠬษไฺษหࠫৈ"),l1l1ll_l1_ (u"࠭วๅ็ุหึ฿ษࠡษ็ัึฯࠧ৉"),l1l1ll_l1_ (u"ࠧศๆฦะ์ุษࠡษ็่ํำ๊สࠩ৊"),l1l1ll_l1_ (u"ࠨษ็็ํืำศฬࠣห้ะูๅ์่๎ฮ࠭ো"),l1l1ll_l1_ (u"ࠩหีฬ๋ฬࠡษ็ฮฺ๋๊ๆࠩৌ"),l1l1ll_l1_ (u"ࠪห้฿วษࠢๅฮฬ্๊ࠧ"),l1l1ll_l1_ (u"ࠫฬู๊ศสࠣห้้ๅษ์๋ฮึࠦࡐࡄࠩৎ"),l1l1ll_l1_ (u"ࠬอไษำส้ั࠭৏")]
l1ll11_l1_ = [l1l1ll_l1_ (u"࠭ๅึษิ฽ฮ࠭৐")]
def MAIN(mode,url,text):
	if   mode==350: results = MENU(url)
	elif mode==351: results = l11l1l_l1_(url,text)
	elif mode==352: results = l11ll1l_l1_(url)
	elif mode==353: results = PLAY(url)
	elif mode==354: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ৑")+text)
	elif mode==355: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ৒")+text)
	elif mode==356: results = l1lll1ll_l1_(url)
	elif mode==357: results = l1l1111l_l1_(url)
	elif mode==359: results = SEARCH(text)
	else: results = False
	return results
def MENU(website=l1l1ll_l1_ (u"ࠩࠪ৓")):
	if website==l1l1ll_l1_ (u"ࠪࠫ৔"):
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ৕"),menu_name+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่าสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ৖"),l1l1ll_l1_ (u"࠭ࠧৗ"),8)
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ৘"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ৙"),l1l1ll_l1_ (u"ࠩࠪ৚"),9999)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ৛"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫড়"),l1l1ll_l1_ (u"ࠬ࠭ঢ়"),359,l1l1ll_l1_ (u"࠭ࠧ৞"),l1l1ll_l1_ (u"ࠧࠨয়"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬৠ"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩৡ"),menu_name+l1l1ll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ৢ"),l1l1l1_l1_,356)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫৣ"),menu_name+l1l1ll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ৤"),l1l1l1_l1_,357)
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ৥"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ০"),l1l1ll_l1_ (u"ࠨࠩ১"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ২"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ৩")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅำ์าࠫ৪"),l1l1l1_l1_,352,l1l1ll_l1_ (u"ࠬ࠭৫"),l1l1ll_l1_ (u"࠭ࠧ৬"),l1l1ll_l1_ (u"ࠧ࡮ࡱࡵࡩࠬ৭"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ৮"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ৯")+menu_name+l1l1ll_l1_ (u"ࠪห้อฮษษิࠫৰ"),l1l1l1_l1_,352,l1l1ll_l1_ (u"ࠫࠬৱ"),l1l1ll_l1_ (u"ࠬ࠭৲"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡶࠫ৳"))
	html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ৴"),headers,l1l1ll_l1_ (u"ࠨࠩ৵"),l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭৶"))
	url2 = re.findall(l1l1ll_l1_ (u"ࠪࡶࡪࡩࡥ࡯ࡶ࡯ࡽ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৷"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = l1l1l1_l1_
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ৸"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ৹")+menu_name+l1l1ll_l1_ (u"࠭วื์ไࠤาี๊ฬษࠪ৺"),url2,351)
	url2 = re.findall(l1l1ll_l1_ (u"ࠧࡁ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৻"),html,re.DOTALL)
	if url2: url2 = url2[0]
	else: url2 = l1l1l1_l1_
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨৼ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ৽")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ৾"),url2,351,l1l1ll_l1_ (u"ࠫࠬ৿"),l1l1ll_l1_ (u"ࠬ࠭਀"),l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨਁ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡮ࡣ࡬ࡲ࠲ࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠫਂ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡳࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪਃ"),block,re.DOTALL)
		for link,title in items:
			if title not in l1ll11_l1_: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ਄"),menu_name+title,link,351)
		if website==l1l1ll_l1_ (u"ࠪࠫਅ"): addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩਆ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬਇ"),l1l1ll_l1_ (u"࠭ࠧਈ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡧࡵࡸࠩ࠰࠭ࡃ࠮ࡂࡦࡰࡱࡷࡩࡷ࠭ਉ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫਊ"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			if title not in l1ll11_l1_: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ਋"),menu_name+title,link,351)
	return html
def l1lll1ll_l1_(website=l1l1ll_l1_ (u"ࠪࠫ਌")):
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬ਍"),headers,l1l1ll_l1_ (u"ࠬ࠭਎"),l1l1ll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪਏ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧਐ"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ਑"),l1l1ll_l1_ (u"ࠩࠪ਒"),link,l1lll11_l1_][0])
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਓ"),block,re.DOTALL)
		for link,title in items:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬਔ"),l1l1ll_l1_ (u"ࠬ࠭ਕ"),link,title)
			if title not in l1ll11_l1_:
				title = title+l1l1ll_l1_ (u"࠭ࠠๆื้ๅฮ࠭ਖ")
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧਗ"),menu_name+title,link,355)
		if website==l1l1ll_l1_ (u"ࠨࠩਘ"): addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧਙ"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਚ"),l1l1ll_l1_ (u"ࠫࠬਛ"),9999)
	return html
def l1l1111l_l1_(website=l1l1ll_l1_ (u"ࠬ࠭ਜ")):
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧਝ"),headers,l1l1ll_l1_ (u"ࠧࠨਞ"),l1l1ll_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬਟ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩਠ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਡ"),block,re.DOTALL)
		for link,title in items:
			if title not in l1ll11_l1_:
				title = title+l1l1ll_l1_ (u"๋ࠫࠥแๅฬิอࠬਢ")
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਣ"),menu_name+title,link,354)
		if website==l1l1ll_l1_ (u"࠭ࠧਤ"): addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬਥ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨਦ"),l1l1ll_l1_ (u"ࠩࠪਧ"),9999)
	return html
def l11l1l_l1_(url,type=l1l1ll_l1_ (u"ࠪࠫਨ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ਩"),l1l1ll_l1_ (u"ࠬ࠭ਪ"),url,type)
	html = OPENURL_CACHED(NO_CACHE,url,l1l1ll_l1_ (u"࠭ࠧਫ"),headers,True,l1l1ll_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ਬ"))
	if type==l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪਭ"): l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡻ࡮ࡶࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠭࠴ࠪࡀࠫࡶࡻ࡮ࡶࡥࡳ࠯ࡥࡹࡹࡺ࡯࡯࠯ࡳࡶࡪࡼࠧਮ"),html,re.DOTALL)
	else: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩਯ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡽࡲࡩ࡯࡭࠽࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡥࡹࡶ࠰ࡻ࡭࡯ࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪਰ"),block,re.DOTALL)
		#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭਱"),l1l1ll_l1_ (u"࠭ࠧਲ"),str(len(block)),url)
		l1l1_l1_ = []
		for img,link,title in items:
			title = unescapeHTML(title)
			if l1l1ll_l1_ (u"ࠧศๆะ่็ฯࠧਲ਼") in title or l1l1ll_l1_ (u"ࠨษ็ั้่็ࠨ਴") in title:
				l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧਵ"),title,re.DOTALL)
				if l11111_l1_:
					title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩਸ਼") + l11111_l1_[0][0]
					if title not in l1l1_l1_:
						addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ਷"),menu_name+title,link,352,img)
						l1l1_l1_.append(title)
			elif l1l1ll_l1_ (u"๋ࠬำๅี็ࠫਸ") in title:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ਹ"),menu_name+title,link,352,img)
			else: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭਺"),menu_name+title,link,353,img)
			#if l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ਻") in link or l1l1ll_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡷࡴ࠱਼ࠪ") in link:
			#	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ਽"),menu_name+title,link,352,img)
			#elif l1l1ll_l1_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨਾ") not in link and l1l1ll_l1_ (u"ࠬ࠵ࡧࡢ࡯ࡨࡷ࠴࠭ਿ") not in link:
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧੀ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪੁ"),block,re.DOTALL)
		for link,title in items:
			#if l1l1ll_l1_ (u"ࠨࠨ࡯ࡷࡦࡷࡵࡰ࠽ࠪੂ") in title: title = l1l1ll_l1_ (u"ุࠩๅาฯࠠิษหๆฮ࠭੃")
			#if l1l1ll_l1_ (u"ࠪࠪࡷࡹࡡࡲࡷࡲ࠿ࠬ੄") in title: title = l1l1ll_l1_ (u"ฺࠫ็อสࠢ็หา่ษࠨ੅")
			#if l1l1ll_l1_ (u"ࠬࠬ࡬ࡢࡳࡸࡳࠬ੆") in title: title = l1l1ll_l1_ (u"࠭วๅืไัฮࠦวๅฬส่๏ฯࠧੇ")
			#if l1l1ll_l1_ (u"ࠧึใะอࠬੈ") not in title: title = l1l1ll_l1_ (u"ࠨืไัฮࠦࠧ੉")+title
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੊"),menu_name+l1l1ll_l1_ (u"ูࠪๆำษࠡࠩੋ")+title,link,351)
	return
def SEARCH(search):
	# l1lll11l_l1_://l1l111ll_l1_.l1ll1ll1_l1_/search?q=%l1l11l11_l1_%l1ll1lll_l1_%l1l11l11_l1_%l1lllll1_l1_%l1l11l11_l1_%l1ll11ll_l1_
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬੌ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"੍ࠬ࠭"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ੎"),l1l1ll_l1_ (u"ࠧࠬࠩ੏"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭੐")+l11lll1_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪੑ"),l1l1ll_l1_ (u"ࠪࠫ੒"),url,l1l1ll_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࡣࡆࡑࡏࡂࡏࠪ੓"))
	results = l11l1l_l1_(url)
	return
def l11ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭੔"),l1l1ll_l1_ (u"࠭ࠧ੕"),url,l1l1ll_l1_ (u"ࠧࡆࡒࡌࡗࡔࡊࡅࡔࡡࡄࡏ࡜ࡇࡍࠨ੖"))
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠨࠩ੗"),headers,True,l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ੘"))
	#if l1l1ll_l1_ (u"ࠪ࠱ࡪࡶࡩࡴࡱࡧࡩࡸ࠭ਖ਼") not in html:
	#	img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡉࡤࡱࡱࠫਗ਼"))
	#	addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫਜ਼"),menu_name+l1l1ll_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬੜ"),url,353,img)
	#else:
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃอไฮๆๅหฯ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࠫ੝"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਫ਼"),block,re.DOTALL)
		for link,img,title in l1ll1_l1_:
			if l1l1ll_l1_ (u"ࠩส่า๊โสࠩ੟") in title or l1l1ll_l1_ (u"ࠪห้ำไใ้ࠪ੠") in title: addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ੡"),menu_name+title,link,353,img)
			#else: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ੢"),menu_name+title,link,352,img)
	else:
		img = xbmc.getInfoLabel(l1l1ll_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡋࡦࡳࡳ࠭੣"))
		if html.count(l1l1ll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠨ੤"))>1: title = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ੥"),html,re.DOTALL)[1]
		else: title = l1l1ll_l1_ (u"ࠩิหอ฽ࠠศๆอุ฿๐ไࠨ੦")
		addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ੧"),menu_name+title,url,353,img)
	return
def PLAY(url):
	l11l1_l1_,l111l1l_l1_ = [],[]
	l1111l1_l1_ = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ੨"),url,l1l1ll_l1_ (u"ࠬ࠭੩"),l1l1ll_l1_ (u"࠭ࠧ੪"),l1l1ll_l1_ (u"ࠧࠨ੫"),l1l1ll_l1_ (u"ࠨࠩ੬"),l1l1ll_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭੭"))
	html = l1111l1_l1_.content
	l1l11lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫ੮"),html,re.DOTALL)
	if l1l11lll_l1_:
		l1l11lll_l1_ = l1l11lll_l1_[0]
		headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੯"):l1l1ll_l1_ (u"ࠬ࠭ੰ"),l1l1ll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬੱ"):l1l1ll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ੲ")}
		data = {l1l1ll_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩੳ"):l1l11lll_l1_}
		url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡢࡨ࡯ࡥࡲ࠾࡫࡬࡭࠲ࡍࡳࡩ࠯ࡂ࡬ࡤࡼ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡝ࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨੴ")
		l1l1ll11_l1_ = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨੵ"),url2,data,headers,l1l1ll_l1_ (u"ࠫࠬ੶"),l1l1ll_l1_ (u"ࠬ࠭੷"),l1l1ll_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ੸"))
		l1l11ll1_l1_ = l1l1ll11_l1_.content
		items = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ੹"),l1l11ll1_l1_,re.DOTALL)
		for l1l1l11l_l1_,name in items:
			#data = {l1l1ll_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥࠩ੺"):l1l11lll_l1_,l1l1ll_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ੻"):l1l1l11l_l1_}
			link = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࠴ࡡ࡬ࡱࡤࡱ࠳ࡩࡡ࡮࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ੼")
			link = link+l1l1ll_l1_ (u"ࠫࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠭੽")+l1l11lll_l1_+l1l1ll_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ੾")+l1l1l11l_l1_+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ੿")+name+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ઀")
			l11l1_l1_.append(link)
			l111l1l_l1_.append(name)
		url2 = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡡࡧ࡮ࡤࡱ࠽ࡱ࡫࡬࠱ࡌࡲࡨ࠵ࡁ࡫ࡣࡻ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡩࡲࠪઁ")
		l1l1ll11_l1_ = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧં"),url2,data,headers,l1l1ll_l1_ (u"ࠪࠫઃ"),l1l1ll_l1_ (u"ࠫࠬ઄"),l1l1ll_l1_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩઅ"))
		l1l11ll1_l1_ = l1l1ll11_l1_.content
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭આ"),l1l11ll1_l1_,re.DOTALL)
		for link,title in items:
			#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨઇ"),l1l1ll_l1_ (u"ࠨࠩઈ"),link,title)
			link = link.strip(l1l1ll_l1_ (u"ࠩࠣࠫઉ"))
			link = link+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫઊ")+title+l1l1ll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨઋ")
			l11l1_l1_.append(link)
			l111l1l_l1_.append(title)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫઌ"),url)
	return
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨઍ"),l1l1ll_l1_ (u"ࠧࠨ઎"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩએ"),l1l1ll_l1_ (u"ࠩࠪઐ"),filter,url)
	l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠪࡧࡦࡺࠧઑ"),l1l1ll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ઒"),l1l1ll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫઓ"),l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧઔ"),l1l1ll_l1_ (u"ࠧࡰࡴࡧࡩࡷࡨࡹࠨક")]
	if l1l1ll_l1_ (u"ࠨࡁࠪખ") in url: url = url.split(l1l1ll_l1_ (u"ࠩࡂࠫગ"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧઘ"),1)
	if filter==l1l1ll_l1_ (u"ࠫࠬઙ"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭ચ"),l1l1ll_l1_ (u"࠭ࠧછ")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫજ"))
	if type==l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬઝ"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠩࡀࠫઞ") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠪࡁࠬટ") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭ઠ")+category+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨડ")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨઢ")+category+l1l1ll_l1_ (u"ࠧ࠾࠲ࠪણ")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠨࠨࠪત"))+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭થ")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠪࠪࠬદ"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠫࡦࡲ࡬ࠨધ"))
		url2 = url+l1l1ll_l1_ (u"ࠬࡅࠧન")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ઩"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩપ"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠨࠩફ"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠩࡤࡰࡱ࠭બ"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠪࠫભ"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠫࡄ࠭મ")+l1l1ll1l_l1_
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬય"),menu_name+l1l1ll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠨર"),url2,351,l1l1ll_l1_ (u"ࠧࠨ઱"),l1l1ll_l1_ (u"ࠨ࠳ࠪલ"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩળ"),menu_name+l1l1ll_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ઴")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪવ"),url2,351,l1l1ll_l1_ (u"ࠬ࠭શ"),l1l1ll_l1_ (u"࠭࠱ࠨષ"))
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬસ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨહ"),l1l1ll_l1_ (u"ࠩࠪ઺"),9999)
	html = OPENURL_CACHED(l11l1ll_l1_,url,l1l1ll_l1_ (u"ࠪࠫ઻"),headers,True,l1l1ll_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠳ࡆࡊࡎࡗࡉࡗ࡙࡟ࡎࡇࡑ࡙࠲࠷ࡳࡵ઼ࠩ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂࡦࡰࡴࡰࠤ࡮ࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡦࡰࡴࡰࡂࠬઽ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺ࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬા"),block,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨિ"),l1l1ll_l1_ (u"ࠨࠩી"),l1l1ll_l1_ (u"ࠩࠪુ"),str(l1111ll_l1_))
	dict = {}
	for l11111l_l1_,name,block in l1111ll_l1_:
		#name = name.replace(l1l1ll_l1_ (u"ࠪ࠱࠲࠭ૂ"),l1l1ll_l1_ (u"ࠫࠬૃ"))
		items = re.findall(l1l1ll_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡂ࠭࠴ࠪࡀࠫ࠿ࠫૄ"),block,re.DOTALL)
		if l1l1ll_l1_ (u"࠭࠽ࠨૅ") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ૆"):
			if category!=l11111l_l1_: continue
			elif len(items)<=1:
				if l11111l_l1_==l1ll1111_l1_[-1]: l11l1l_l1_(url2)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨે")+l1ll11l1_l1_)
				return
			else:
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩૈ"),menu_name+l1l1ll_l1_ (u"ࠪห้าๅ๋฻ࠪૉ"),url2,351,l1l1ll_l1_ (u"ࠫࠬ૊"),l1l1ll_l1_ (u"ࠬ࠷ࠧો"))
				else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ૌ"),menu_name+l1l1ll_l1_ (u"ࠧศๆฯ้๏฿્ࠧ"),url2,355,l1l1ll_l1_ (u"ࠨࠩ૎"),l1l1ll_l1_ (u"ࠩࠪ૏"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫૐ"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭૑")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨ૒")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ૓")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾࠲ࠪ૔")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ૕")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ૖"),menu_name+l1l1ll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠥ࠭૗")+name,url2,354,l1l1ll_l1_ (u"ࠫࠬ૘"),l1l1ll_l1_ (u"ࠬ࠭૙"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ૚"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if option in l1ll11_l1_: continue
			if l1l1ll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭૛") not in value: value = option
			else: value = re.findall(l1l1ll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩࠣࠩ૜"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠩࠩࠫ૝")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࠬ૞")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭૟")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃࠧૠ")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪૡ")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠧࠡ࠼ࠣࠫૢ")#+dict[l11111l_l1_][l1l1ll_l1_ (u"ࠨ࠲ࠪૣ")]
			title = option+l1l1ll_l1_ (u"ࠩࠣ࠾ࠥ࠭૤")+name
			if type==l1l1ll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ૥"): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ૦"),menu_name+title,url,354,l1l1ll_l1_ (u"ࠬ࠭૧"),l1l1ll_l1_ (u"࠭ࠧ૨"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ૩"))
			elif type==l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ૪") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠩࡀࠫ૫") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧ૬"))
				url3 = url+l1l1ll_l1_ (u"ࠫࡄ࠭૭")+l1l1l1l1_l1_
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ૮"),menu_name+title,url3,351,l1l1ll_l1_ (u"࠭ࠧ૯"),l1l1ll_l1_ (u"ࠧ࠲ࠩ૰"))
			else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ૱"),menu_name+title,url,355,l1l1ll_l1_ (u"ࠩࠪ૲"),l1l1ll_l1_ (u"ࠪࠫ૳"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ૴"),l1l1ll_l1_ (u"ࠬ࠭૵"),filters,l1l1ll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠶࠷ࠧ૶"))
	# mode==l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ૷")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ૸")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠩࡤࡰࡱ࠭ૹ")					all filters (l1l1l111_l1_ l1ll1l1l_l1_ filter)
	#filters = filters.replace(l1l1ll_l1_ (u"ࠪࡁࠫ࠭ૺ"),l1l1ll_l1_ (u"ࠫࡂ࠶ࠦࠨૻ"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠬࠬࠧૼ"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"࠭࠽ࠨ૽") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠧࠧࠩ૾"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠨ࠿ࠪ૿"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠩࠪ଀")
	l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠪࡧࡦࡺࠧଁ"),l1l1ll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪଂ"),l1l1ll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫଃ"),l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ଄"),l1l1ll_l1_ (u"ࠧࡰࡴࡧࡩࡷࡨࡹࠨଅ")]
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠨ࠲ࠪଆ")
		#if l1l1ll_l1_ (u"ࠩࠨࠫଇ") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬଈ") and value!=l1l1ll_l1_ (u"ࠫ࠵࠭ଉ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩଊ")+value
		elif mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩଋ") and value!=l1l1ll_l1_ (u"ࠧ࠱ࠩଌ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠨࠪ଍")+key+l1l1ll_l1_ (u"ࠩࡀࠫ଎")+value
		elif mode==l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧଏ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭ଐ")+key+l1l1ll_l1_ (u"ࠬࡃࠧ଑")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪ଒"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠩଓ"))
	#l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠨ࠿࠳ࠫଔ"),l1l1ll_l1_ (u"ࠩࡀࠫକ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫଖ"),l1l1ll_l1_ (u"ࠫࠬଗ"),filters,l1l1ll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠶࠷࠭ଘ"))
	return l1llllll_l1_
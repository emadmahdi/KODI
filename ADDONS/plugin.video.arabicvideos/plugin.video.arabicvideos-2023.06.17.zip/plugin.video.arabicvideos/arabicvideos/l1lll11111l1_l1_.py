# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ勑")
headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ勒") : l1l1ll_l1_ (u"ࠧࠨ勓") }
menu_name = l1l1ll_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧ勔")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ動"),l1l1ll_l1_ (u"ࠪห้้ไࠨ勖"),l1l1ll_l1_ (u"ࠫฬ็ไศ็ࠪ勗"),l1l1ll_l1_ (u"ࠬࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠩ勘"),l1l1ll_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ務")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l11l1l_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l11ll1l_l1_(url)
	elif mode==114: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ勚")+text)
	elif mode==115: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ勛")+text)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭勜"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ勝"),headers,l1l1ll_l1_ (u"ࠫࠬ勞"),l1l1ll_l1_ (u"ࠬ࠭募"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ勠"))
	html = response.content
	l11llll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭勡"),html,re.DOTALL)
	if l11llll1_l1_: l11llll1_l1_ = l11llll1_l1_[0].strip(l1l1ll_l1_ (u"ࠨ࠱ࠪ勢"))
	else: l11llll1_l1_ = l1l1l1_l1_
	l11ll1_l1_ = SERVER(l11llll1_l1_,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭勣"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ勤"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ勥"),l1l1ll_l1_ (u"ࠬ࠭勦"),119,l1l1ll_l1_ (u"࠭ࠧ勧"),l1l1ll_l1_ (u"ࠧࠨ勨"),l1l1ll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ勩"))
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ勪"),menu_name+l1l1ll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭勫"),l11llll1_l1_,115)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ勬"),menu_name+l1l1ll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ勭"),l11llll1_l1_,114)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ勮"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ勯"),l1l1ll_l1_ (u"ࠨࠩ勰"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭勱"),l11llll1_l1_,l1l1ll_l1_ (u"ࠪࠫ勲"),headers,l1l1ll_l1_ (u"ࠫࠬ勳"),l1l1ll_l1_ (u"ࠬ࠭勴"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠲࡯ࡦࠪ勵"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡹࡧࡢࡴࠪ࠱࠮ࡄ࠯ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠨ勶"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ勷"),block,re.DOTALL)
		for filter,title in items:
			#url = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡔࡪࡤ࡬࡮ࡪ࠴ࡶ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡋࡳࡲ࡫࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡋࡳࡲ࡫࠮ࡱࡪࡳࠫ勸")
			url = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡉࡱࡰࡩ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡉࡱࡰࡩ࠳ࡶࡨࡱࠩ勹")
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ勺"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ勻")+menu_name+title,url,111,l1l1ll_l1_ (u"࠭ࠧ勼"),l1l1ll_l1_ (u"ࠧࠨ勽"),filter)
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭勾"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ勿"),l1l1ll_l1_ (u"ࠪࠫ匀"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ匁"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ匂"),block,re.DOTALL)
		for link,title in items:
			if title in l1ll11_l1_: continue
			if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ匃") not in link: link = l11ll1_l1_+link
			title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩ匄"))
			if l1l1ll_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ包") in link: title = l1l1ll_l1_ (u"้ࠩ๎ฯ็ไไีࠪ匆")
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ匇"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭匈")+menu_name+title,link,111)
	return html
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"ࠬ࠭匉")):
	if l1l1ll_l1_ (u"࠭࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡖ࡬ࡴࡽࡳ࠯ࡲ࡫ࡴࡄ࠭匊") in url:
		url,data = URLDECODE(url)
		headers2 = {l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭匋"):l1l1ll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ匌"),l1l1ll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ匍"):l1l1ll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ匎")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡕࡕࡓࡕࠩ匏"),url,data,headers2,l1l1ll_l1_ (u"ࠬ࠭匐"),l1l1ll_l1_ (u"࠭ࠧ匑"),l1l1ll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭匒"))
		html = response.content
		block = html
	elif l1l1ll_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ匓") in url:
		data = {l1l1ll_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ匔"):l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡧࡲ࡯ࡤ࡭ࠪ匕"),l1l1ll_l1_ (u"ࠫࡰ࡫ࡹࠨ化"):l1111ll11_l1_}
		headers2 = {l1l1ll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ北"):l1l1ll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ匘")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ匙"),url,data,headers2,l1l1ll_l1_ (u"ࠨࠩ匚"),l1l1ll_l1_ (u"ࠩࠪ匛"),l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ匜"))
		html = response.content
		block = html
	else:
		headers2 = {l1l1ll_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ匝"):l1l1ll_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭匞")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ匟"),url,l1l1ll_l1_ (u"ࠧࠨ匠"),headers2,l1l1ll_l1_ (u"ࠨࠩ匡"),l1l1ll_l1_ (u"ࠩࠪ匢"),l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ匣"))
		html = response.content
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡵࡣࡪࡷ࠲ࡩ࡬ࡰࡷࡧࠫ匤"),html,re.DOTALL)
		if not l1lll11_l1_: return
		block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ匥"),block,re.DOTALL)
	items = re.findall(l1l1ll_l1_ (u"࠭ࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ匦"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠧ匧"),l1l1ll_l1_ (u"ࠨใํ่๊࠭匨"),l1l1ll_l1_ (u"ࠩส฾๋๐ษࠨ匩"),l1l1ll_l1_ (u"ࠪ็้๐ศࠨ匪"),l1l1ll_l1_ (u"ࠫฬ฿ไศ่ࠪ匫"),l1l1ll_l1_ (u"ࠬํฯศใࠪ匬"),l1l1ll_l1_ (u"࠭ๅษษิหฮ࠭匭"),l1l1ll_l1_ (u"ฺࠧำูࠫ匮"),l1l1ll_l1_ (u"ࠨ็๊ีัอๆࠨ匯"),l1l1ll_l1_ (u"ࠩส่อ๎ๅࠨ匰")]
	for link,img,title in items:
		if l1l1ll_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ匱") in link: continue
		#if l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭匲") in link: continue
		#link = link.replace(l1l1ll_l1_ (u"ࠬࠬࠣ࠱࠵࠻࠿ࠬ匳"),l1l1ll_l1_ (u"࠭ࠦࠨ匴"))
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ匵"))
		title = unescapeHTML(title)
		title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ匶"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ匷"),title,re.DOTALL)
		if l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨ匸") in link or any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ匹"),menu_name+title,link,112,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠬอไฮๆๅอࠬ区") in title and l1l1ll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ医") not in url:
			title = l1l1ll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭匼") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ匽"),menu_name+title,link,113,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ匾") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ匿"),menu_name+title,link,111,img)
		elif l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭區") in link and l1l1ll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ十") not in url:
			link = link+l1l1ll_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ卂")
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ千"),menu_name+title,link,111,img)
		elif l1l1ll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ卄") in url and l1l1ll_l1_ (u"ࠩะ่็ฯࠧ卅") in title:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ卆"),menu_name+title,link,112,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ升"),menu_name+title,link,113,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ午"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ卉"),block,re.DOTALL)
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭半"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"ࠨษ็ูๆำษࠡࠩ卋"),l1l1ll_l1_ (u"ࠩࠪ卌"))
			if title!=l1l1ll_l1_ (u"ࠪࠫ卍"): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ华"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ协")+title,link,111)
	l1111l111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ卐"),html,re.DOTALL)
	if l1111l111_l1_:
		link = l1111l111_l1_[0]
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ卑"),menu_name+l1l1ll_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ卒"),link,111)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭卓"),url,l1l1ll_l1_ (u"ࠪࠫ協"),headers,l1l1ll_l1_ (u"ࠫࠬ单"),l1l1ll_l1_ (u"ࠬ࠭卖"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ南"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࠢ࡬ࡨࡂࠨࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡺࡡࡨࡵ࠰ࡧࡱࡵࡵࡥࠩ単"),html,re.DOTALL)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ卙"),html,re.DOTALL)
	items = []
	# l11l11_l1_
	if l1ll1ll_l1_ and l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ博") not in url:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡬ࡱࡦ࡭ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ卛"),block,re.DOTALL)
		for link,img,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭卜"))
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ卝"),menu_name+title,link,113,img)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡡࡡ࠮ࡼࡠ࠯ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ卞"),block,re.DOTALL)
		for link,img,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩ卟"))
			addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ占"),menu_name+title,link,112,img)
	# l1ll1_l1_ l11lllll_l1_
	if not items and l1l1ll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ卡") in html:
		l1l1llll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡷ࡫ࡡࡥࡥࡵࡹࡲࡨࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ卢"),html,re.DOTALL)
		if l1l1llll1_l1_:
			block = l1l1llll1_l1_[0]
			l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ卣"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				link = l1ll_l1_[2]+l1l1ll_l1_ (u"ࠬࡲࡩࡴࡶࠪ卤")
				l11l1l_l1_(link)
	return
def PLAY(url):
	l11l1_l1_ = []
	l111l11l_l1_ = url.strip(l1l1ll_l1_ (u"࠭࠯ࠨ卥"))
	hostname = SERVER(l111l11l_l1_,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ卦"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ卧"),l111l11l_l1_,l1l1ll_l1_ (u"ࠩࠪ卨"),headers,l1l1ll_l1_ (u"ࠪࠫ卩"),l1l1ll_l1_ (u"ࠫࠬ卪"),l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ卫"))
	html = response.content#.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ卬"))
	id = re.findall(l1l1ll_l1_ (u"ࠧࡱࡱࡶࡸࡎࡪ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ卭"),html,re.DOTALL)
	if not id: id = re.findall(l1l1ll_l1_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩ卮"),html,re.DOTALL)
	if not id: id = re.findall(l1l1ll_l1_ (u"ࠩࡳࡳࡸࡺ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ卯"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l1l1ll_l1_ (u"ࠪࠫ印")
	#else: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ危"),l1l1ll_l1_ (u"ࠬ࠭卲"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ即"),l1l1ll_l1_ (u"๋ࠧำฯํࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠࠡ็้ࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠫ却"))
	if l1l1ll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠤࠪ卵") in html:
		#parts = url.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ卶"))
		#url2 = url.replace(parts[3],l1l1ll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ卷"))
		url2 = l111l11l_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࠫ卸")
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ卹"),url2,l1l1ll_l1_ (u"࠭ࠧ卺"),headers,l1l1ll_l1_ (u"ࠧࠨ卻"),l1l1ll_l1_ (u"ࠨࠩ卼"),l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭卽"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ卾"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ卿"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lll11_l1_: l11ll_l1_ = l1lll11_l1_[0]
		else: l11ll_l1_ = l1l11ll1_l1_
		if not id:
			id = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡂࠨ࠰ࠣࠢࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ厀"),l11ll_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l1l1ll_l1_ (u"࠭ࠧ厁")
		l111ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭厂"),l1l11ll1_l1_,re.DOTALL)
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩ厃"),l1l11ll1_l1_,re.DOTALL)
		l111ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭厄"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࡟ࡲ࠯࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ厅"),l1l11ll1_l1_)
		l111l1lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ历"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ厇"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		l1l11l111111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ厈"),l11ll_l1_,re.DOTALL|re.IGNORECASE)
		l1l11l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ厉"),l11ll_l1_,re.DOTALL|re.IGNORECASE)
		items = l111ll1l1_l1_+l1lll1l_l1_+l111ll1ll_l1_+l111ll111_l1_+l111l1lll_l1_+l11l11l1l_l1_+l1l11l111111_l1_+l1l11l1111ll_l1_
		if not items:
			items = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭厊"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡸࠬ压"),l1l1ll_l1_ (u"ࠪࠫ厌")).replace(l1l1ll_l1_ (u"ࠫࡡࡴࠧ厍"),l1l1ll_l1_ (u"ࠬ࠭厎")).strip(l1l1ll_l1_ (u"࠭ࠠࠨ厏"))
			#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ厐"),title)
			if l1l1ll_l1_ (u"ࠨ࠰ࡳࡲ࡬࠭厑") in server: continue
			if l1l1ll_l1_ (u"ࠩ࠱࡮ࡵ࡭ࠧ厒") in server: continue
			if l1l1ll_l1_ (u"ࠪࠪࡶࡻ࡯ࡵ࠽ࠪ厓") in server: continue
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ厔"),title,re.DOTALL)
			if l11ll1l1_l1_:
				l11ll1l1_l1_ = l11ll1l1_l1_[0]
				if l11ll1l1_l1_ in title: title = title.replace(l11ll1l1_l1_+l1l1ll_l1_ (u"ࠬࡶࠧ厕"),l1l1ll_l1_ (u"࠭ࠧ厖")).replace(l11ll1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ厗")).strip(l1l1ll_l1_ (u"ࠨࠢࠪ厘"))
				l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠩࡢࡣࡤࡥࠧ厙")+l11ll1l1_l1_
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪࠫ厚")
			if server.isdigit(): link = hostname+l1l1ll_l1_ (u"ࠫ࠴ࡅࡰࡰࡵࡷ࡭ࡩࡃࠧ厛")+id+l1l1ll_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ厜")+server+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ厝")+title+l1l1ll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ厞")+l11ll1l1_l1_
			else:
				if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭原") not in server: server = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ厠")+server
				l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ厡"),title,re.DOTALL)
				if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ厢")+l11ll1l1_l1_[0]
				else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭厣")
				link = server+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧ厤")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ厥"),l11l1_l1_)
	#l11l1_l1_ = []
	if l1l1ll_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠧ࠭厦") in html:
		#parts = url.split(l1l1ll_l1_ (u"ࠩ࠲ࠫ厧"))
		#url2 = url.replace(parts[3],l1l1ll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ厨"))
		url2 = l111l11l_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ厩")
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ厪"),url2,l1l1ll_l1_ (u"࠭ࠧ厫"),headers,l1l1ll_l1_ (u"ࠧࠨ厬"),l1l1ll_l1_ (u"ࠨࠩ厭"),l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭厮"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ厯"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡲ࡫ࡤࡪࡣ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀ࠾࠲ࡨ࡮ࡼ࠾ࠪ࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ厰"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lll11_l1_: l11ll_l1_ = l1lll11_l1_[0]
		else: l11ll_l1_ = l1l11ll1_l1_
		l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂࡨ࠴࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ厱"),l11ll_l1_,re.DOTALL)
		for title,block in l1l1l11_l1_:
			title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ厲"))
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ厳"),block,re.DOTALL)
			for link,name,l11ll1l1_l1_ in items:
				l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࡧ࠯ࠬ厴"),l11ll1l1_l1_,re.DOTALL)
				if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠩࡢࡣࡤࡥࠧ厵")+l11ll1l1_l1_[0]
				else:
					l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡠࡩ࠱ࠧ厶"),title,re.DOTALL)
					if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ厷")+l11ll1l1_l1_[0]
					else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭厸")
				link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ厹")+name+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ厺")+l11ll1l1_l1_
				l11l1_l1_.append(link)
		if not l1l1l11_l1_:
			#url2 = hostname +l1l1ll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡆࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴ࡭ࡶࠧ去")
			url2 = hostname +l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡄࡰࡹࡱࡰࡴࡧࡤ࠯ࡲ࡫ࡴࠬ厼")
			headers2 = {l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ厽"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ厾")}
			data2 = {l1l1ll_l1_ (u"ࠬ࡯ࡤࠨ县"):id}
			response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡐࡐࡕࡗࠫ叀"),url2,data2,headers2,l1l1ll_l1_ (u"ࠧࠨ叁"),l1l1ll_l1_ (u"ࠨࠩ参"),l1l1ll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭參"))
			l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ叄"))
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ叅"),l1l11ll1_l1_,re.DOTALL)
			for link,name,l11ll1l1_l1_ in items:
				link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭叆")+name+l1l1ll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ叇")+l1l1ll_l1_ (u"ࠧࡠࡡࡢࡣࠬ又")+l11ll1l1_l1_
				l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭叉"),l11l1_l1_)
	elif l1l1ll_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧ及") in html:
		headers2 = { l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ友"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ双") }
		url2 = l111l11l_l1_.replace(parts[3],l1l1ll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ反"))
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ収"),url2,l1l1ll_l1_ (u"ࠧࠨ叏"),headers2,l1l1ll_l1_ (u"ࠨࠩ叐"),l1l1ll_l1_ (u"ࠩࠪ发"),l1l1ll_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ叒"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ叓"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭叔"),l1l11ll1_l1_,re.DOTALL)
		for block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ叕"),block,re.DOTALL)
			for link,name,l11ll1l1_l1_ in items:
				link = link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ取")+name+l1l1ll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ受")+l1l1ll_l1_ (u"ࠩࡢࡣࡤࡥࠧ变")+l11ll1l1_l1_
				l11l1_l1_.append(link)
	elif l1l1ll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ叙") in html:
		headers2 = { l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ叚"):l1l1ll_l1_ (u"ࠬ࠭叛") , l1l1ll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ叜"):l1l1ll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ叝") }
		url2 = hostname + l1l1ll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ叞")+id
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭叟"),url2,l1l1ll_l1_ (u"ࠪࠫ叠"),headers2,l1l1ll_l1_ (u"ࠫࠬ叡"),l1l1ll_l1_ (u"ࠬ࠭叢"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ口"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ古"))
		if l1l1ll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰ࡦࡹࡴࡳࠨ句") in l1l11ll1_l1_:
			l111ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ另"),l1l11ll1_l1_,re.DOTALL)
			for url3 in l111ll1ll_l1_:
				if l1l1ll_l1_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠪ叧") not in url3 and l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ叨") in url3:
					url3 = url3+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ叩")
					l11l1_l1_.append(url3)
				elif l1l1ll_l1_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭只") in url3:
					l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠧࠨ叫")
					response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ召"),url3,l1l1ll_l1_ (u"ࠩࠪ叭"),headers,l1l1ll_l1_ (u"ࠪࠫ叮"),l1l1ll_l1_ (u"ࠫࠬ可"),l1l1ll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠼ࡴࡩࠩ台"))
					l11l11111_l1_ = response.content#.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ叱"))
					l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠩ࠾ࡶࡸࡷࡵ࡮ࡨࡀ࠱࠮ࡄ࠯࠭࠮࠯࠰࠱ࠬ史"),l11l11111_l1_,re.DOTALL)
					for l11l1ll1l_l1_ in l1l1l11_l1_:
						l11l111l1_l1_ = l1l1ll_l1_ (u"ࠨࠩ右")
						l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ叴"),l11l1ll1l_l1_,re.DOTALL)
						for l11l11lll_l1_ in l111ll111_l1_:
							item = re.findall(l1l1ll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ叵"),l11l11lll_l1_,re.DOTALL)
							if item:
								l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ叶")+item[0]
								break
						for l11l11lll_l1_ in reversed(l111ll111_l1_):
							item = re.findall(l1l1ll_l1_ (u"ࠬࡢࡷ࡝ࡹ࠮ࠫ号"),l11l11lll_l1_,re.DOTALL)
							if item:
								l11l111l1_l1_ = item[0]
								break
						l111l1lll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ司"),l11l1ll1l_l1_,re.DOTALL)
						for l11l11l11_l1_ in l111l1lll_l1_:
							l11l11l11_l1_ = l11l11l11_l1_+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ叹")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ叺")+l11ll1l1_l1_
							l11l1_l1_.append(l11l11l11_l1_)
		elif l1l1ll_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧ叻") in l1l11ll1_l1_:
			l1l11ll1_l1_ = l1l11ll1_l1_.replace(l1l1ll_l1_ (u"ࠪࡀ࡭࠼ࠠࠨ叼"),l1l1ll_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨ叽"))+l1l1ll_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭叾")
			l1l11ll1_l1_ = l1l11ll1_l1_.replace(l1l1ll_l1_ (u"࠭࠼ࡩ࠵ࠣࠫ叿"),l1l1ll_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫ吀"))+l1l1ll_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩ吁")
			l111ll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡀࡁࡘ࡚ࡁࡓࡖࡀࡁ࠭࠴ࠪࡀࠫࡀࡁࡊࡔࡄ࠾࠿ࠪ吂"),l1l11ll1_l1_,re.DOTALL)
			if l111ll11l_l1_:
				for l11l1ll1l_l1_ in l111ll11l_l1_:
					if l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩ吃") not in l11l1ll1l_l1_: continue
					l11l1l111_l1_ = l1l1ll_l1_ (u"ࠫࠬ各")
					l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡹ࡬ࡰࡹ࠰ࡱࡴࡺࡩࡰࡰࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ吅"),l11l1ll1l_l1_,re.DOTALL)
					for l11l11lll_l1_ in l111ll111_l1_:
						item = re.findall(l1l1ll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ吆"),l11l11lll_l1_,re.DOTALL)
						if item:
							l11l1l111_l1_ = l1l1ll_l1_ (u"ࠧࡠࡡࡢࡣࠬ吇")+item[0]
							break
					l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧ合"),l11l1ll1l_l1_,re.DOTALL)
					if l111ll111_l1_:
						for l11l111l1_l1_,l11l111ll_l1_ in l111ll111_l1_:
							l11l111ll_l1_ = l11l111ll_l1_+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ吉")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ吊")+l11l1l111_l1_
							l11l1_l1_.append(l11l111ll_l1_)
					else:
						l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ吋"),l11l1ll1l_l1_,re.DOTALL)
						for l11l111ll_l1_,l11l111l1_l1_ in l111ll111_l1_:
							l11l111ll_l1_ = l11l111ll_l1_.strip(l1l1ll_l1_ (u"ࠬࠦࠧ同"))+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ名")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ后")+l11l1l111_l1_
							l11l1_l1_.append(l11l111ll_l1_)
			else:
				l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬࡡࡽࠫࠪ࠾ࠪ吏"),l1l11ll1_l1_,re.DOTALL)
				for l11l111ll_l1_,l11l111l1_l1_ in l111ll111_l1_:
					l11l111ll_l1_ = l11l111ll_l1_.strip(l1l1ll_l1_ (u"ࠩࠣࠫ吐"))+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ向")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ吒")
					l11l1_l1_.append(l11l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ吓"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ吔"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ吕"),l1l1ll_l1_ (u"ࠨ࠭ࠪ吖"))
	if showDialogs:
		l11l1111l_l1_ = [l1l1ll_l1_ (u"ࠩสๅ้อๅࠨ吗"),l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠫ吘"),l1l1ll_l1_ (u"๊๋ࠫหๅ์้ࠫ吙"),l1l1ll_l1_ (u"ࠬอไไๆࠪ吚")]
		l1ll1ll11_l1_ = [l1l1ll_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ君"),l1l1ll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ吜"),l1l1ll_l1_ (u"ࠨࡣࡦࡸࡴࡸࠧ吝"),l1l1ll_l1_ (u"ࠩࠪ吞")]
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠥ࠳ࠠศะอีࠥอไโๆอีࠥอไๆ่สือ࠭吟"), l11l1111l_l1_)
		if selection == -1 : return
		type = l1ll1ll11_l1_[selection]
	else: type = l1l1ll_l1_ (u"ࠫࠬ吠")
	l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲࡬ࡴࡳࡥࠨ࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡲࡦࡳࡥ࠾ࠤࡷࡽࡵ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡵࡷࡶ࠭ࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵࠬ࠰ࡸࡺࡲࠩ࡮ࡨࡲ࠭࡮ࡴ࡮࡮ࠬ࠭࠮ࠐࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳࠡࡣࡱࡨࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚ࠬࡧ࡫࡯ࡸࡪࡸࡌࡊࡕࡗࠤࡂ࡛ࠦ࡞࠮࡞ࡡࠏࠏࠉࡧࡱࡵࠤࡨࡧࡴࡦࡩࡲࡶࡾ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍ࡮࡬ࠠࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡞ࠫ฾ื่ืู่ࠢฬืูสࠩࡠ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡦࡥࡹ࡫ࡧࡰࡴࡼ࠭ࠏࠏࠉࠊࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊แๅฬิࠤฬ๊ๅ็ษึฬ࠿࠭ࠬࠡࡨ࡬ࡰࡹ࡫ࡲࡍࡋࡖࡘ࠮ࠐࠉࠊ࡫ࡩࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠ࠾࠿ࠣ࠱࠶ࠦ࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠࡤࡣࡷࡩ࡬ࡵࡲࡺࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍࡪࡲࡳࡦ࠼ࠣࡧࡦࡺࡥࡨࡱࡵࡽࠥࡃࠠࠨࠩࠍࠍࠨࡻࡲ࡭ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠠࠬࠢࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧࠬࡵࡨࡥࡷࡩࡨࠬࠩࠩࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠭ࠫࡤࡣࡷࡩ࡬ࡵࡲࡺࠌࠌࠦࠧࠨ吡")
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"࠭࠯ࡀࡵࡀࠫ吢")+search+l1l1ll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧ吣")+type
	l11l1l_l1_(url)
	return
# ===========================================
#     l1111l1ll_l1_ l1lllllll1_l1_ l1lllll1ll_l1_
# ===========================================
def l1111l1l1_l1_(url):
	url = url.split(l1l1ll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ吤"))[0]
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭吥"),url,l1l1ll_l1_ (u"ࠪࠫ否"),headers,l1l1ll_l1_ (u"ࠫࠬ吧"),l1l1ll_l1_ (u"ࠬ࠭吨"),l1l1ll_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ吩"))
	html = response.content
	# all l1l1l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡷࡪࡧࡲࡤࡪࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ吪"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		# name + category + options block
		l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡵࡨࡰࡪࡩࡴ࠮࡯ࡨࡲࡺ࠴ࠪࡀࡴࡲࡹࡳࡪࡥࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡯࡮ࡱࡷࡷࠤࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭含"),block,re.DOTALL)
		return l1111ll_l1_
	return []
def l1llllllll_l1_(block):
	# id + title
	items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡤࡣࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡤࡪࡨࡧࡰࡳࡡࡳ࡭࠰ࡦࡴࡲࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ听"),block,re.DOTALL)
	return items
def l1l11l11111l_l1_(url):
	url = url.replace(l1l1ll_l1_ (u"ࠪࡧࡦࡺ࠽ࠨ吭"),l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧ吮"))
	if l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ启") not in url: url = url+l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ吰")
	l1111111l_l1_ = url.split(l1l1ll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ吱"))[0]
	l11111111_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ吲"))
	url = url.replace(l1111111l_l1_,l11111111_l1_)
	#url = url.replace(l1l1ll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭吳"),l1l1ll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡕ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡗ࡭ࡵࡷࡴ࠰ࡳ࡬ࡵࡅࠧ吴"))
	url = url.replace(l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ吵"),l1l1ll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡸ࡭࡫࡭ࡦ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡋࡳࡲ࡫࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡖ࡬ࡴࡽࡳ࠯ࡲ࡫ࡴࡄ࠭吶"))
	return url
l1l111llllll_l1_ = [l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ吷"),l1l1ll_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭吸"),l1l1ll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ吹"),l1l1ll_l1_ (u"ࠩࡦࡥࡹ࠭吺")]
l1l11l1111l1_l1_ = [l1l1ll_l1_ (u"ࠪࡧࡦࡺࠧ吻"),l1l1ll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ吼"),l1l1ll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ吽")]
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ吾"),l1l1ll_l1_ (u"ࠧࠨ吿"))
	url = url.split(l1l1ll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ呀"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭呁"),1)
	if filter==l1l1ll_l1_ (u"ࠪࠫ呂"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠫࠬ呃"),l1l1ll_l1_ (u"ࠬ࠭呄")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪ呅"))
	if type==l1l1ll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ呆"):
		if l1l11l1111l1_l1_[0]+l1l1ll_l1_ (u"ࠨ࠿ࠪ呇") not in l1l1lll1_l1_: category = l1l11l1111l1_l1_[0]
		for i in range(len(l1l11l1111l1_l1_[0:-1])):
			if l1l11l1111l1_l1_[i]+l1l1ll_l1_ (u"ࠩࡀࠫ呈") in l1l1lll1_l1_: category = l1l11l1111l1_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠪࠪࠬ呉")+category+l1l1ll_l1_ (u"ࠫࡂ࠶ࠧ告")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ呋")+category+l1l1ll_l1_ (u"࠭࠽࠱ࠩ呌")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠩ呍"))+l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ呎")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠩࠩࠫ呏"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭呐"))
		url2 = url+l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ呑")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ呒"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ呓"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠧࠨ呔"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ呕"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠩࠪ呖"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ呗")+l1l1ll1l_l1_
		url3 = l1l11l11111l_l1_(url2)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ员"),menu_name+l1l1ll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ呙"),url3,111)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭呚"),menu_name+l1l1ll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ呛")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ呜"),url3,111)
		addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ呝"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ呞"),l1l1ll_l1_ (u"ࠫࠬ呟"),9999)
	l1111ll_l1_ = l1111l1l1_l1_(url)
	dict = {}
	for name,l11111l_l1_,block in l1111ll_l1_:
		name = name.replace(l1l1ll_l1_ (u"ࠬ࠳࠭ࠨ呠"),l1l1ll_l1_ (u"࠭ࠧ呡"))
		items = l1llllllll_l1_(block)
		if l1l1ll_l1_ (u"ࠧ࠾ࠩ呢") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ呣"):
			if category!=l11111l_l1_: continue
			elif len(items)<2:
				if l11111l_l1_==l1l11l1111l1_l1_[-1]:
					url3 = l1l11l11111l_l1_(url2)
					l11l1l_l1_(url3)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭呤")+l1ll11l1_l1_)
				return
			else:
				if l11111l_l1_==l1l11l1111l1_l1_[-1]:
					url3 = l1l11l11111l_l1_(url2)
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ呥"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ呦"),url3,111)
				else: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ呧"),menu_name+l1l1ll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ周"),url2,115,l1l1ll_l1_ (u"ࠧࠨ呩"),l1l1ll_l1_ (u"ࠨࠩ呪"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ呫"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠪࠪࠬ呬")+l11111l_l1_+l1l1ll_l1_ (u"ࠫࡂ࠶ࠧ呭")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ呮")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽࠱ࠩ呯")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ呰")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ呱"),menu_name+l1l1ll_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ呲")+name,url2,114,l1l1ll_l1_ (u"ࠪࠫ味"),l1l1ll_l1_ (u"ࠫࠬ呴"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ呵"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if value==l1l1ll_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭呶"): option = l1l1ll_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧ呷")
			elif value==l1l1ll_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨ呸"): option = l1l1ll_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫ呹")
			if option in l1ll11_l1_: continue
			#if l1l1ll_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ呺") not in value: value = option
			#else: value = re.findall(l1l1ll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬ呻"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ呼")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽ࠨ命")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠩ呾")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࠪ呿")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭咀")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠪࠤ࠿࠭咁")#+dict[l11111l_l1_][l1l1ll_l1_ (u"ࠫ࠵࠭咂")]
			title = option+l1l1ll_l1_ (u"ࠬࠦ࠺ࠨ咃")+name
			if type==l1l1ll_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ咄"): addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ咅"),menu_name+title,url,114,l1l1ll_l1_ (u"ࠨࠩ咆"),l1l1ll_l1_ (u"ࠩࠪ咇"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ咈"))
			elif type==l1l1ll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ咉") and l1l11l1111l1_l1_[-2]+l1l1ll_l1_ (u"ࠬࡃࠧ咊") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ咋"))
				url2 = url+l1l1ll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ和")+l1l1l1l1_l1_
				url3 = l1l11l11111l_l1_(url2)
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ咍"),menu_name+title,url3,111)
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ咎"),menu_name+title,url,115,l1l1ll_l1_ (u"ࠪࠫ咏"),l1l1ll_l1_ (u"ࠫࠬ咐"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	# mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ咑")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ咒")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠧࡢ࡮࡯ࠫ咓")					all l1ll1l1l_l1_ & l1111l11l_l1_ filters
	filters = filters.replace(l1l1ll_l1_ (u"ࠨ࠿ࠩࠫ咔"),l1l1ll_l1_ (u"ࠩࡀ࠴ࠫ࠭咕"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠪࠪࠬ咖"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠫࡂ࠭咗") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠬࠬࠧ咘"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"࠭࠽ࠨ咙"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠧࠨ咚")
	for key in l1l111llllll_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠨ࠲ࠪ咛")
		if l1l1ll_l1_ (u"ࠩࠨࠫ咜") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ咝") and value!=l1l1ll_l1_ (u"ࠫ࠵࠭咞"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩ咟")+value
		elif mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ咠") and value!=l1l1ll_l1_ (u"ࠧ࠱ࠩ咡"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠨࠪ咢")+key+l1l1ll_l1_ (u"ࠩࡀࠫ咣")+value
		elif mode==l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧ咤"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭咥")+key+l1l1ll_l1_ (u"ࠬࡃࠧ咦")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪ咧"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠩ咨"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠨ࠿࠳ࠫ咩"),l1l1ll_l1_ (u"ࠩࡀࠫ咪"))
	return l1llllll_l1_
# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
#l1l1l1_l1_ = l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭࠰ࡸ࡬ࡩࡼ࠳࠱࠰ษไ่ฬฺ๋࠭ำห๎ฮ࠭౩")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ౪")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠵࠳ࡧ࡬ࡢࡴࡤࡦ࠳ࡩ࡯࡮ࠩ౫")
#l1l1l1_l1_ = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡹࡳࡩ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵ࠭౬")
script_name = l1l1ll_l1_ (u"ࠪࡅࡑࡇࡒࡂࡄࠪ౭")
headers = {l1l1ll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ౮"):l1l1ll_l1_ (u"ࠬ࠭౯")}
menu_name = l1l1ll_l1_ (u"࠭࡟ࡌࡎࡄࡣࠬ౰")
l1l1l1_l1_ = WEBSITES[script_name][0]
def MAIN(mode,url,text):
	if   mode==10: results = MENU()
	elif mode==11: results = l11l1l_l1_(url)
	elif mode==12: results = PLAY(url)
	elif mode==13: results = l11ll1l_l1_(url)
	elif mode==14: results = l1111ll1_l1_()
	elif mode==15: results = l111l1l1_l1_()
	elif mode==16: results = l11l111l_l1_()
	elif mode==19: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౱"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ౲"),l1l1ll_l1_ (u"ࠩࠪ౳"),19,l1l1ll_l1_ (u"ࠪࠫ౴"),l1l1ll_l1_ (u"ࠫࠬ౵"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ౶"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ౷"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ౸"),l1l1ll_l1_ (u"ࠨࠩ౹"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౺"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ౻")+menu_name+l1l1ll_l1_ (u"ࠫวิัࠡษ็ษ฻อแศฬࠪ౼"),l1l1ll_l1_ (u"ࠬ࠭౽"),14)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭౾"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ౿")+menu_name+l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠨಀ"),l1l1ll_l1_ (u"ࠩࠪಁ"),15)
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫಂ"),headers,l1l1ll_l1_ (u"ࠫࠬಃ"),l1l1ll_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ಄"))
	l1lll11_l1_=re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࡲࡦࡼ࠭ࡴ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬಅ"),html,re.DOTALL)
	l11l1lll_l1_ = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩಆ"),l11l1lll_l1_,re.DOTALL)
	for link,title in items:
		link = l1l1l1_l1_+link
		title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪಇ"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಈ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬಉ")+menu_name+title,link,11)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩಊ"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬಋ"),l1l1ll_l1_ (u"࠭ࠧಌ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡳࡧࡶࡣࡣࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ಍"),html,re.DOTALL)
	l11ll_l1_ = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪಎ"),l11ll_l1_,re.DOTALL)
	for link,title in items:
		link = l1l1l1_l1_+link
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಏ"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬಐ")+menu_name+title,link,11)
	return html
def l111l1l1_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ಑"),menu_name+l1l1ll_l1_ (u"ࠬาๅ๋฻ࠣห้๋ำๅี็หฯࠦวๅ฻ิฬ๏ฯࠧಒ"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡷ࡫ࡨࡻ࠲࠾࠯ๆี็ื้อส࠮฻ิฬ๏ฯࠧಓ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧಔ"),menu_name+l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢสุ่์ษࠡษ็วำ๐ัสࠩಕ"),l1l1ll_l1_ (u"ࠩࠪಖ"),16)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಗ"),menu_name+l1l1ll_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤฬ๊รฯ์ิอࠥ࠷ࠧಘ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡧࡺ࠱࠽࠵ๅิๆึ่ฬะ࠭า็ูห๋࠳࠲࠱࠴࠵ࠫಙ"),11)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಚ"),menu_name+l1l1ll_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠศๆฦา๏ืษࠡ࠴ࠪಛ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡪࡽ࠭࠹࠱่ืู้ไศฬ࠰ี๊฼ว็࠯࠵࠴࠷࠹ࠧಜ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಝ"),menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠳ࠨಞ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠳࠵࠲ฺ้ื๊สࠩಟ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಠ"),menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠴࠵ࠫಡ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠶࠷࠵ๅึำํอࠬಢ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨಣ"),menu_name+l1l1ll_l1_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠷࠷ࠧತ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠲࠲࠱ู่ึ๐ษࠨಥ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫದ"),menu_name+l1l1ll_l1_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠳࠲ࠪಧ"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠵࠴࠴๋ีา์ฬࠫನ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ಩"),menu_name+l1l1ll_l1_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠾࠭ಪ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠹࠰็ุี๏ฯࠧಫ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪಬ"),menu_name+l1l1ll_l1_ (u"ู๊ࠫไิๆสฮࠥืๅืษ้ࠤ࠷࠶࠱࠹ࠩಭ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡲࡢ࡯ࡤࡨࡦࡴ࠲࠱࠳࠻࠳๊฻ั๋หࠪಮ"),11)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಯ"),menu_name+l1l1ll_l1_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠴࠻ࠬರ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰ࠵࠴࠶࠽࠯ๆืิ๎ฮ࠭ಱ"),11)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩಲ"),menu_name+l1l1ll_l1_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠷࠶ࠨಳ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡸࡡ࡮ࡣࡧࡥࡳ࠸࠰࠲࠸࠲ฺ้ื๊สࠩ಴"),11)
	return
def l1111ll1_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭ವ"),headers,True,l1l1ll_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪಶ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨಷ"),l1l1ll_l1_ (u"ࠨࠩಸ"),l1l1ll_l1_ (u"ࠩࠪಹ"),html)
	l1lll11_l1_=re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡪࡧࡤࡪࡰࡪ࠱ࡹࡵࡰࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠩ಺"),html,re.DOTALL)
	block = l1lll11_l1_[0]+l1lll11_l1_[1]
	items=re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭಻"),block,re.DOTALL)
	for link,img,title in items:
		url = l1l1l1_l1_ + link
		if l1l1ll_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ಼ࠬ") in url: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಽ"),menu_name+title,url,11,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ಾ"),menu_name+title,url,12,img)
	return
def l11l1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩಿ"),l1l1ll_l1_ (u"ࠩࠪೀ"),l1l1ll_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪು"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨೂ"),url,l1l1ll_l1_ (u"ࠬ࠭ೃ"),headers,True,True,l1l1ll_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪೄ"))
	html = response.content
	#open(l1l1ll_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ೅"),l1l1ll_l1_ (u"ࠨࡹࠪೆ")).write(str(html))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻࠫ࠲࠯ࡅࠩࡳ࡫ࡪ࡬ࡹࡥࡣࡰࡰࡷࡩࡳࡺࠧೇ"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	l1lll1lll_l1_ = False
	#items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࡞࠹࠷ࡣ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨೈ"),block,re.DOTALL)
	items = re.findall(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱ࠰ࡦࡴࡾ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ೉"),block,re.DOTALL)
	l1l1_l1_,l11l11l1_l1_ = [],[]
	for link,img,title in items:
		if title==l1l1ll_l1_ (u"ࠬ࠭ೊ"): title = link.split(l1l1ll_l1_ (u"࠭࠯ࠨೋ"))[-1].replace(l1l1ll_l1_ (u"ࠧ࠮ࠩೌ"),l1l1ll_l1_ (u"ࠨ್ࠢࠪ"))
		l11l1ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡠࡩ࠱ࠩࠨ೎"),title,re.DOTALL)
		if l11l1ll1_l1_: l11l1ll1_l1_ = int(l11l1ll1_l1_[0])
		else: l11l1ll1_l1_ = 0
		l11l11l1_l1_.append([img,link,title,l11l1ll1_l1_])
	l11l11l1_l1_ = sorted(l11l11l1_l1_, reverse=True, key=lambda key: key[3])
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ೏"),l1l1ll_l1_ (u"ࠫࠬ೐"),l1l1ll_l1_ (u"ࠬ࠸࠲࠳ࠩ೑"),url)
	for img,link,title,l11l1ll1_l1_ in l11l11l1_l1_:
		link = l1l1l1_l1_ + link
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ೒"),l1l1ll_l1_ (u"ࠧࠨ೓"),url,title)
		title = title.replace(l1l1ll_l1_ (u"ࠨ็ืห์ีษࠡ็ึุ่๊ࠧ೔"),l1l1ll_l1_ (u"่ࠩืู้ไࠨೕ"))
		title = title.replace(l1l1ll_l1_ (u"ู้ࠪอ็ะหࠣห้๋ำๅี็ࠫೖ"),l1l1ll_l1_ (u"ࠫฬ๊ๅิๆึ่ࠬ೗"))
		title = title.replace(l1l1ll_l1_ (u"๋ࠬิศ้าอࠥ็๊ๅ็ࠪ೘"),l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫ೙"))
		title = title.replace(l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠠศๆไ๎้๋ࠧ೚"),l1l1ll_l1_ (u"ࠨษ็ๅ๏๊ๅࠨ೛"))
		title = title.replace(l1l1ll_l1_ (u"่ࠩฬฬฺัสࠢๆ์ฬ๊๊ห์ࠪ೜"),l1l1ll_l1_ (u"ࠪࠫೝ"))
		title = title.replace(l1l1ll_l1_ (u"ࠫ฾อไ๋หࠣ฽้๏ࠠศๆ฼ีอ࠭ೞ"),l1l1ll_l1_ (u"ࠬ࠭೟"))
		title = title.replace(l1l1ll_l1_ (u"࠭ๅีษ๊ำฮࠦๅษษืีฮ࠭ೠ"),l1l1ll_l1_ (u"ࠧࠨೡ"))
		title = title.replace(l1l1ll_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠪೢ"),l1l1ll_l1_ (u"ࠩࠪೣ"))
		title = title.replace(l1l1ll_l1_ (u"ࠪหํ์ไศ์้ࠫ೤"),l1l1ll_l1_ (u"ࠫࠬ೥"))
		title = title.replace(l1l1ll_l1_ (u"ࠬฮฬ้ัฬࠤ฾อไ๋หࠪ೦"),l1l1ll_l1_ (u"࠭ࠧ೧"))
		title = title.replace(l1l1ll_l1_ (u"ࠧอ๊าอࠥ฿วๅ์ฬࠫ೨"),l1l1ll_l1_ (u"ࠨࠩ೩"))
		title = title.replace(l1l1ll_l1_ (u"ࠩหำํ์ࠠหฯ่๎้࠭೪"),l1l1ll_l1_ (u"ࠪࠫ೫"))
		title = title.replace(l1l1ll_l1_ (u"ࠫ฾๊้ࠡษ็฽ึฮࠧ೬"),l1l1ll_l1_ (u"ࠬ࠭೭"))
		title = title.replace(l1l1ll_l1_ (u"࠭ๅษษืีฮ࠭೮"),l1l1ll_l1_ (u"ࠧࠨ೯"))
		title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ೰")).replace(l1l1ll_l1_ (u"ࠩࠣࠤࠬೱ"),l1l1ll_l1_ (u"ࠪࠤࠬೲ")).replace(l1l1ll_l1_ (u"ࠫࠥࠦࠧೳ"),l1l1ll_l1_ (u"ࠬࠦࠧ೴"))
		title = l1l1ll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ೵")+title
		title2 = title
		if l1l1ll_l1_ (u"ࠧ࠰ࡳ࠲ࠫ೶") in url and (l1l1ll_l1_ (u"ࠨษ็ั้่ษࠨ೷") in title or l1l1ll_l1_ (u"ࠩส่า๊โ่ࠩ೸") in title):
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭೹"),title,re.DOTALL)
			if l11111_l1_: title2 = l11111_l1_[0]
			#if l1l1ll_l1_ (u"ู๊ࠫไิๆࠪ೺") not in title2: title2 = l1l1ll_l1_ (u"๋ࠬำๅี็ࠤࠬ೻")+title2
		if title2 not in l1l1_l1_:
			l1l1_l1_.append(title2)
			#xbmc.log(title2, level=xbmc.LOGNOTICE)
			if l1l1ll_l1_ (u"࠭࠯ࡲ࠱ࠪ೼") in url and (l1l1ll_l1_ (u"ࠧศๆะ่็ฯࠧ೽") in title or l1l1ll_l1_ (u"ࠨษ็ั้่็ࠨ೾") in title):
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೿"),menu_name+title2,link,13,img)
				l1lll1lll_l1_ = True
			elif l1l1ll_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪഀ") in link:
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഁ"),menu_name+title,link,11,img)
				l1lll1lll_l1_ = True
			else:
				#if l1l1ll_l1_ (u"๋ࠬำๅี็ࠫം") not in title and l1l1ll_l1_ (u"࠭วๅฯ็ๆฮ࠭ഃ") in title: title = l1l1ll_l1_ (u"ࠧๆี็ื้ࠦࠧഄ")+title
				addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧഅ"),menu_name+title,link,12,img)
				l1lll1lll_l1_ = True
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪആ"),l1l1ll_l1_ (u"ࠪࠫഇ"),l1l1ll_l1_ (u"ࠫ࠸࠹࠳ࠨഈ"),url)
	if l1lll1lll_l1_:
		items = re.findall(l1l1ll_l1_ (u"ࠬࡺࡳࡤࡡ࠶ࡨࡤࡨࡵࡵࡶࡲࡲࠥࡸࡥࡥ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪഉ"),block,re.DOTALL)
		for link,page in items:
			url = l1l1l1_l1_ + link
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ഊ"),menu_name+page,url,11)
	return
def l11ll1l_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l1l1ll_l1_ (u"ࠧࠨഋ"),headers,True,l1l1ll_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧഌ"))
	l11l1l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡷࡪࡸࡩࡦࡵ࠱࠮ࡄ࠯ࠢࠨ഍"),html,re.DOTALL)
	url2 = l1l1l1_l1_+l11l1l1l_l1_[0]
	results = l11l1l_l1_(url2)
	return
l1l1ll_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡉࡕࡏࡓࡐࡆࡈࡗࡤࡕࡌࡅࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰࡙ࡸࡵࡦ࠮ࠪࡅࡑࡇࡒࡂࡄ࠰ࡉࡕࡏࡓࡐࡆࡈࡗࡤࡕࡌࡅ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡣࡣࡱࡲࡪࡸ࠭ࡳ࡫ࡪ࡬ࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࡫ࡦ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡻࡲ࡭࠮ࠪࡷࡹ࡫ࡰࠡ࠴ࠪ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠭ࠩࡶࡸࡪࡶࠠ࠴ࠩࠬࠎࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡳࡰࡴࡷࡩࡩ࠮ࡩࡵࡧࡰࡷ࠱ࠦࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠱ࠦ࡫ࡦࡻࡀࡰࡦࡳࡢࡥࡣࠣ࡯ࡪࡿ࠺ࠡ࡭ࡨࡽࡠ࠷࡝ࠪࠌࠌࠧࡳࡧ࡭ࡦࠢࡀࠤࡽࡨ࡭ࡤ࠰ࡪࡩࡹࡏ࡮ࡧࡱࡏࡥࡧ࡫࡬ࠩࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ࠭ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠺ࠧࠪࠌࠌࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࠦ࠽ࠡ࡝ࡠࠎࠎ࡬࡯ࡳࠢ࡬ࡱ࡬࠲࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࠣࡲࡴࡺࠠࡪࡰࠣࡥࡱࡲࡔࡪࡶ࡯ࡩࡸࡀࠊࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡸ࡬ࡨࡪࡵࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯๋ࠬำๅี็ࠤࠬ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠵࠷࠲ࡩ࡮ࡩࠬࠎࠎࠏࠉࡢ࡮࡯ࡘ࡮ࡺ࡬ࡦࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡹࡴࡦࡲࠣ࠹ࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦഎ")
def PLAY(url):
	l11l1_l1_ = []
	html = OPENURL_CACHED(l1llll1l1_l1_,url,l1l1ll_l1_ (u"ࠫࠬഏ"),headers,True,l1l1ll_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧഐ"))
	# l11111ll_l1_ l1111111_l1_ server
	# l1lll11l_l1_://l11ll111_l1_.l111111l_l1_.l1lll1ll1_l1_/l1llllll1_l1_-_حلقة_1llll111_l1_حكايتي_111l1ll_l1_رمضان_111lll1_l1_
	# l1lll11l_l1_://l11l1l11_l1_.l111111l_l1_.l1lll1ll1_l1_/numeric/110272.l11l1111_l1_/l111ll1l_l1_.l11111ll_l1_
	url2 = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦࡵࡳ࠱࡮࡬ࡲࡢ࡯ࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ഑"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡟ࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠪࠧഒ"),url2,re.DOTALL)
		if l1ll_l1_:
			first = l1ll_l1_[0][0]
			second,l1llll1ll_l1_ = l1ll_l1_[0][1].rsplit(l1l1ll_l1_ (u"ࠨ࠱ࠪഓ"),1)
			url3 = second+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪഔ")
			l11l1_l1_.append(url3)
			l111l11l_l1_ = first+l1llll1ll_l1_
		else:
			l1l11ll1_l1_ = OPENURL_CACHED(l11l1ll_l1_,url2,l1l1ll_l1_ (u"ࠪࠫക"),headers,False,l1l1ll_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ഖ"))
			url2 = re.findall(l1l1ll_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ഗ"),l1l11ll1_l1_,re.DOTALL)
			if url2:
				url2 = url2[0]+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮࡟ࡠ࡯࠶ࡹ࠽࠭ഘ")
				l11l1_l1_.append(url2)
	# l1lll1l1l_l1_ server - l111ll11_l1_ - l1lll11l_l1_://l11ll111_l1_.l111111l_l1_.l1lll1ll1_l1_/l1lllllll_l1_-_الذئب_حلقة_1lllll1l_l1_
	# l1lll1l1l_l1_ server - l1llll11l_l1_ - l1lll11l_l1_://l11ll111_l1_.l111111l_l1_.l1lll1ll1_l1_/l111llll_l1_-_1lllll11_l1_فيلم_اكشن_1111lll_l1_
	# l1lll1l1l_l1_ server - l1111l1l_l1_ - l1lll11l_l1_://l11ll111_l1_.l111111l_l1_.l1lll1ll1_l1_/l1111l11_l1_-_لحلقة_111l111_l1_السجين_مترجمة_11111l1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡂࡰࡺࠫ࠲࠯ࡅࠩ࠽ࡵࡷࡽࡱ࡫࠾ࠨങ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		url2 = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧച"),block,re.DOTALL)
		if url2:
			url2 = url2[0]+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡼࡧࡴࡤࡪࠪഛ")
			l11l1_l1_.append(url2)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩജ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪഝ"),url)
	return
def l11l111l_l1_():
	html = OPENURL_CACHED(l11l1ll_l1_,l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭ഞ"),headers,True,l1l1ll_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡒࡂࡏࡄࡈࡆࡔ࠭࠲ࡵࡷࠫട"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࡤࡹࡥࡤࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡱ࡫ࡦࡵࡡࡦࡳࡳࡺࡥ࡯ࡶࠥࠫഠ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪഡ"),block,re.DOTALL)
	year = re.findall(l1l1ll_l1_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱࠬࡠ࠶࠭࠺࡟࠮࠭࠴࠭ഢ"),str(items),re.DOTALL)
	year = year[0]
	for link,title in items:
		url = l1l1l1_l1_+link
		title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬണ"))+l1l1ll_l1_ (u"ࠫࠥ࠭ത")+year
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬഥ"),menu_name+title,url,11)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧദ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨധ"): return
	l11lll1_l1_ = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪന"),l1l1ll_l1_ (u"ࠩ࠮ࠫഩ"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠥ࠳ࡶ࠵ࠢപ") + l11lll1_l1_
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬഫ"),l1l1ll_l1_ (u"ࠬ࠭ബ"),l1l1ll_l1_ (u"࠭࠳࠴࠵ࠪഭ"),url)
	results = l11l1l_l1_(url)
	return
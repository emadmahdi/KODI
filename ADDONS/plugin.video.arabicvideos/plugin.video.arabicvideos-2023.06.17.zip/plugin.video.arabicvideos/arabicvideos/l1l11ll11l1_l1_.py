# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࠨ㭻")
def MAIN(mode,url,text):
	if   mode==260: results = MENU()
	elif mode==261: results = l1l11l1ll11_l1_()
	elif mode==263: results = l1l11lll111_l1_()
	elif mode==264: results = l1l11llll1l_l1_()
	elif mode==265: results = l1l11ll11ll_l1_(text)
	elif mode==266: results = l1l11lll11l_l1_(text)
	elif mode==267: results = l1l11l1l111_l1_(True)
	elif mode==531: results = l1l11llllll_l1_()
	else: results = False
	return results
def MENU():
	if kodi_version<18: addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㭼"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣไฮๆࠣห้๋ิศๅ็ࠤะฮสࠡๅ๋ำ๏ࠦอะ์ฮ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㭽"),l1l1ll_l1_ (u"ࠬ࠭㭾"),341)
	l1l11ll1l1l_l1_,l1l11ll111l_l1_ = False,False
	l1l11l1l11l_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㭿"))
	if not l1l11l1l11l_l1_: l1l11l1l11l_l1_ = l1l11l1l111_l1_(False)
	if l1l11l1l11l_l1_==l1l1ll_l1_ (u"ࠧࡆࡔࡕࡓࡗ࠭㮀"): l1l11ll1l1l_l1_ = True
	elif l1l11l1l11l_l1_==l1l1ll_l1_ (u"ࠨࡐࡈ࡛ࠬ㮁"): l1l11ll111l_l1_ = True
	elif l1l11l1l11l_l1_==l1l1ll_l1_ (u"ࠩࡒࡐࡉ࠭㮂"): l1l11ll111l_l1_ = False
	else: return
	l1l11l1l1ll_l1_ = l1l11ll1ll1_l1_([l1l1ll_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ㮃"),l1l1ll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭㮄")])
	#l1l11ll1l1l_l1_ = True
	if l1l11ll1l1l_l1_:
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㮅"),l1l1ll_l1_ (u"࠭࠱࠯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡอืๆศ็ฯࠤ฾๋วะࠢไ๎์ࠦๅีๅ็อࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮆"),l1l1ll_l1_ (u"ࠧࠨ㮇"),531)
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㮈"),l1l1ll_l1_ (u"ࠩ࠵࠲ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ษำ้ห๊าฺࠠ็สำࠥ็ุ๊่่่๊ࠢษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㮉"),l1l1ll_l1_ (u"ࠪࠫ㮊"),531)
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㮋"),l1l1ll_l1_ (u"ࠬ࠹࠮ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠฬึ์วๆฮࠣ฽๊อฯࠡใํ๋๋ࠥิไๆฬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㮌"),l1l1ll_l1_ (u"࠭ࠧ㮍"),531)
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㮎"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠴ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠱࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㮏"),l1l1ll_l1_ (u"ࠩࠪ㮐"),9990)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㮑"),l1l1ll_l1_ (u"ࠫࠬ㮒"),str(l1l11ll1l1l_l1_),str(l1l11ll111l_l1_))
	if l1l11ll1l1l_l1_ or l1l11ll111l_l1_: addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㮓"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ๆา๎่ࠦัิษ็อ๋ࠥๆࠡษ็้อืๅอ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㮔"),l1l1ll_l1_ (u"ࠧࠨ㮕"),267)
	if l1l11ll1l1l_l1_ or l1l11l1l1ll_l1_: addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㮖"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ้ี๊ไࠢอัิ๐หࠡ็้ࠤฬ๊ๅษำ่ะࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮗"),l1l1ll_l1_ (u"ࠪࠫ㮘"),159)
	if l1l11ll1l1l_l1_ or l1l11l1l1ll_l1_ or l1l11ll111l_l1_:
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㮙"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠱ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠵ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㮚"),l1l1ll_l1_ (u"࠭ࠧ㮛"),9990)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㮜"),l1l1ll_l1_ (u"ࠨࡐࡲࠤࡆࡸࡡࡣ࡫ࡦࠫ㮝"),l1l1ll_l1_ (u"ࠩࠪ㮞"),151)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㮟"),l1l1ll_l1_ (u"ࠫ฾์ࠠศๆศ฽้อๆศฬࠪ㮠"),l1l1ll_l1_ (u"ࠬ࠭㮡"),346)
	if not l1l11ll1l1l_l1_:
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㮢"),l1l1ll_l1_ (u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ㮣"),l1l1ll_l1_ (u"ࠨࠩ㮤"),501)
		addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㮥"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㮦"),l1l1ll_l1_ (u"ࠫࠬ㮧"),9990)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮨"),l1l1ll_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧ㮩"),l1l1ll_l1_ (u"ࠧࠨ㮪"),510)
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㮫"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠷ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠴࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㮬"),l1l1ll_l1_ (u"ࠪࠫ㮭"),9990)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮮"),l1l1ll_l1_ (u"ࠬอไโ์า๎ํํวหࠩ㮯"),l1l1ll_l1_ (u"࠭ࠧ㮰"),165,l1l1ll_l1_ (u"ࠧࠨ㮱"),l1l1ll_l1_ (u"ࠨࠩ㮲"),l1l1ll_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ㮳"))
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮴"),l1l1ll_l1_ (u"๊ࠫ๎วใ฻ࠣห้็๊ะ์๋ࠫ㮵"),l1l1ll_l1_ (u"ࠬ࠭㮶"),261)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮷"),l1l1ll_l1_ (u"ࠧใ๊สส๊ࠦวๅไ้์ฬะࠧ㮸"),l1l1ll_l1_ (u"ࠨࠩ㮹"),100)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮺"),l1l1ll_l1_ (u"ࠪๆํอฦๆࠢส่฾ฺ่ศศํอࠬ㮻"),l1l1ll_l1_ (u"ࠫࠬ㮼"),160)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮽"),l1l1ll_l1_ (u"࠭ศฮอࠣฬ่๊ࠠศๆ่์ฬู่ࠨ㮾"),l1l1ll_l1_ (u"ࠧࠨ㮿"),540)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯀"),l1l1ll_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯࠦวๅ็ะ้้ฯࠧ㯁"),l1l1ll_l1_ (u"ࠪࠫ㯂"),330)
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㯃"),l1l1ll_l1_ (u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠤ๊์๋๊ࠠอ๎ํฮࠧ㯄"),l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ㯅"),144)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯆"),l1l1ll_l1_ (u"ࠨ็๋ห็฿๋๊ࠠอ๎ํฮࠠๆ่ࠣห้ฮั็ษ่ะࠬ㯇"),l1l1ll_l1_ (u"ࠩࠪ㯈"),290)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㯉"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠳ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠷ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㯊"),l1l1ll_l1_ (u"ࠬ࠭㯋"),9990)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㯌"),l1l1ll_l1_ (u"ࠧใ๊สส๊ࠦสี฼ํ่ࠥࡓ࠳ࡖࠩ㯍"),l1l1ll_l1_ (u"ࠨࠩ㯎"),710)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㯏"),l1l1ll_l1_ (u"ࠪๆํอฦๆࠢฦๆุอๅࠡࡏ࠶࡙ࠬ㯐"),l1l1ll_l1_ (u"ࠫࠬ㯑"),724,l1l1ll_l1_ (u"ࠬ࠭㯒"),l1l1ll_l1_ (u"࠭ࠧ㯓"),l1l1ll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㯔"))
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㯕"),l1l1ll_l1_ (u"ࠩหัะࠦฬๆ์฼ࠤࡒ࠹ࡕࠨ㯖"),l1l1ll_l1_ (u"ࠪࠫ㯗"),719,l1l1ll_l1_ (u"ࠫࠬ㯘"),l1l1ll_l1_ (u"ࠬ࠭㯙"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㯚"))
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㯛"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠸ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠵࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㯜"),l1l1ll_l1_ (u"ࠩࠪ㯝"),9990)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㯞"),l1l1ll_l1_ (u"ࠫ็๎วว็ࠣหูะัศๅࠣࡍࡕ࡚ࡖࠨ㯟"),l1l1ll_l1_ (u"ࠬ࠭㯠"),230)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㯡"),l1l1ll_l1_ (u"ࠧใ๊สส๊ࠦรใีส้ࠥࡏࡐࡕࡘࠪ㯢"),l1l1ll_l1_ (u"ࠨࠩ㯣"),284,l1l1ll_l1_ (u"ࠩࠪ㯤"),l1l1ll_l1_ (u"ࠪࠫ㯥"),l1l1ll_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ㯦"))
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㯧"),l1l1ll_l1_ (u"࠭ศฮอࠣะ๊๐ูࠡࡋࡓࡘ࡛࠭㯨"),l1l1ll_l1_ (u"ࠧࠨ㯩"),239,l1l1ll_l1_ (u"ࠨࠩ㯪"),l1l1ll_l1_ (u"ࠩࠪ㯫"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㯬"))
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㯭"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠶ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠺ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㯮"),l1l1ll_l1_ (u"࠭ࠧ㯯"),9990)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯰"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠳ࠪ㯱"),l1l1ll_l1_ (u"ࠩࠪ㯲"),270,l1l1ll_l1_ (u"ࠪࠫ㯳"),l1l1ll_l1_ (u"ࠫࠬ㯴"),l1l1ll_l1_ (u"ࠬ࠭㯵"),l1l1ll_l1_ (u"࠭࠱ࠨ㯶"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯷"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠴ࠪ㯸"),l1l1ll_l1_ (u"ࠩࠪ㯹"),270,l1l1ll_l1_ (u"ࠪࠫ㯺"),l1l1ll_l1_ (u"ࠫࠬ㯻"),l1l1ll_l1_ (u"ࠬ࠭㯼"),l1l1ll_l1_ (u"࠭࠲ࠨ㯽"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㯾"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠵ࠪ㯿"),l1l1ll_l1_ (u"ࠩࠪ㰀"),270,l1l1ll_l1_ (u"ࠪࠫ㰁"),l1l1ll_l1_ (u"ࠫࠬ㰂"),l1l1ll_l1_ (u"ࠬ࠭㰃"),l1l1ll_l1_ (u"࠭࠳ࠨ㰄"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㰅"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠶ࠪ㰆"),l1l1ll_l1_ (u"ࠩࠪ㰇"),270,l1l1ll_l1_ (u"ࠪࠫ㰈"),l1l1ll_l1_ (u"ࠫࠬ㰉"),l1l1ll_l1_ (u"ࠬ࠭㰊"),l1l1ll_l1_ (u"࠭࠴ࠨ㰋"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㰌"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠศๆ่ๅ฻๊ษࠡ࠷ࠪ㰍"),l1l1ll_l1_ (u"ࠩࠪ㰎"),270,l1l1ll_l1_ (u"ࠪࠫ㰏"),l1l1ll_l1_ (u"ࠫࠬ㰐"),l1l1ll_l1_ (u"ࠬ࠭㰑"),l1l1ll_l1_ (u"࠭࠵ࠨ㰒"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㰓"),l1l1ll_l1_ (u"ࠨไสส๊ฯࠠระิࠤ࠺࠶ࠠโ์า๎ํ࠭㰔"),l1l1ll_l1_ (u"ࠩࠪ㰕"),265,l1l1ll_l1_ (u"ࠪࠫ㰖"),l1l1ll_l1_ (u"ࠫࠬ㰗"),l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㰘"))
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㰙"),l1l1ll_l1_ (u"ࠧใษษ้ฮࠦยฯำࠣ࠹࠵ࠦโ็ษฬࠫ㰚"),l1l1ll_l1_ (u"ࠨࠩ㰛"),265,l1l1ll_l1_ (u"ࠩࠪ㰜"),l1l1ll_l1_ (u"ࠪࠫ㰝"),l1l1ll_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㰞"))
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㰟"),l1l1ll_l1_ (u"࠭โศศ่อࠥศฮาࠢ࠸࠴๋ࠥฬๅัࠪ㰠"),l1l1ll_l1_ (u"ࠧࠨ㰡"),265,l1l1ll_l1_ (u"ࠨࠩ㰢"),l1l1ll_l1_ (u"ࠩࠪ㰣"),l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰤"))
		#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㰥"),l1l1ll_l1_ (u"ࠬࡥࡅࡎࡆࡢࠫ㰦")+l1l1ll_l1_ (u"࠭โศศ่อࠥ็อึࠢࡌࡔ࡙࡜เࠨ㰧"),l1l1ll_l1_ (u"ࠧࠨ㰨"),9999,l1l1ll_l1_ (u"ࠨࠩ㰩"),l1l1ll_l1_ (u"ࠩࠪ㰪"),l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰫"))
		#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㰬"),l1l1ll_l1_ (u"ࠬࡥࡅࡎࡆࡢࠫ㰭")+l1l1ll_l1_ (u"࠭โศศ่อࠥ็อึࠩ㰮"),l1l1ll_l1_ (u"ࠧࠨ㰯"),9999,l1l1ll_l1_ (u"ࠨࠩ㰰"),l1l1ll_l1_ (u"ࠩࠪ㰱"),l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㰲"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㰳"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠷ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤ࠻ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㰴"),l1l1ll_l1_ (u"࠭ࠧ㰵"),9990)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㰶"),l1l1ll_l1_ (u"ࠨว฼่ฬ์วหࠢฮๆฬ็๊สࠢศื้อๅ๋หࠪ㰷"),l1l1ll_l1_ (u"ࠩࠪ㰸"),505)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㰹"),l1l1ll_l1_ (u"ࠫฯ่ั๋ำࠣหุะฮะษ่ࠤฬ๊ศา่ส้ั࠭㰺"),l1l1ll_l1_ (u"ࠬ࠭㰻"),176)
	if l1l11ll111l_l1_: addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㰼"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ิืฬฬไ๊ࠡฦาออัࠡ็้ࠤฬ๊ๅษำ่ะࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㰽"),l1l1ll_l1_ (u"ࠨࠩ㰾"),267)
	else: addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㰿"),l1l1ll_l1_ (u"ࠪีุอฦๅ๋ࠢวำฮวา่๊ࠢࠥอไๆสิ้ั࠭㱀"),l1l1ll_l1_ (u"ࠫࠬ㱁"),267)
	if l1l11l1l1ll_l1_: addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㱂"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ษฺีวาࠢิๆ๊ࠦࠨࠡࠩ㱃")+addon_version+l1l1ll_l1_ (u"ࠧࠡࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㱄"),l1l1ll_l1_ (u"ࠨࠩ㱅"),7)
	else: addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱆"),l1l1ll_l1_ (u"ࠪห้หีะษิࠤึ่ๅࠡࠪࠣࠫ㱇")+addon_version+l1l1ll_l1_ (u"ࠫࠥ࠯ࠧ㱈"),l1l1ll_l1_ (u"ࠬ࠭㱉"),7)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㱊"),l1l1ll_l1_ (u"ࠧหไิ๎ึูࠦ็ࠢลาึࠦวๅฬ฽๎๏ืวหࠩ㱋"),l1l1ll_l1_ (u"ࠨࠩ㱌"),199)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱍"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠽ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠺࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㱎"),l1l1ll_l1_ (u"ࠫࠬ㱏"),9990)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱐"),l1l1ll_l1_ (u"࠭โศศ่อࠥอไฤฮ๋ฬฮ࠭㱑"),l1l1ll_l1_ (u"ࠧࠨ㱒"),263)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱓"),l1l1ll_l1_ (u"ࠩๅหห๋ษࠡษ็าิ๋วหࠩ㱔"),l1l1ll_l1_ (u"ࠪࠫ㱕"),264)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㱖"),l1l1ll_l1_ (u"ࠬอไๆ๊ๅ฽ࠥอไาี่๎ࠬ㱗"),l1l1ll_l1_ (u"࠭ࠧ㱘"),341)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㱙"),l1l1ll_l1_ (u"ࠨษ็ษ๋าวำษอࠤฬ๊รฯำ์ࠫ㱚"),l1l1ll_l1_ (u"ࠩࠪ㱛"),348)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㱜"),l1l1ll_l1_ (u"ࠫฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧ㱝"),l1l1ll_l1_ (u"ࠬ࠭㱞"),196)
	return
def l1l11l1ll11_l1_():
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㱟"),l1l1ll_l1_ (u"ࠧࠡࠢ࠴࠲ࠥࠦ࡟ࡕࡘ࠳ࡣࠬ㱠")+l1l1ll_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠪ㱡"),l1l1ll_l1_ (u"ࠩࠪ㱢"),100)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㱣"),l1l1ll_l1_ (u"ࠫࠥࠦ࠲࠯ࠢࠣࡣࡎࡖࡔࡠࠩ㱤")+l1l1ll_l1_ (u"ࠬอิหำส็ࠥࡏࡐࡕࡘ้ࠣิ็ฺ่ࠩ㱥"),l1l1ll_l1_ (u"࠭ࠧ㱦"),230)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㱧"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ู้ࠣอใๅࠢๅ่๏๊ษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㱨"),l1l1ll_l1_ (u"ࠩࠪ㱩"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㱪"),l1l1ll_l1_ (u"ࠫࡤࡈࡋࡓࡡࠪ㱫")+l1l1ll_l1_ (u"๋่ࠬใ฻ࠣฬ่ืวࠨ㱬"),l1l1ll_l1_ (u"࠭ࠧ㱭"),370)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㱮"),l1l1ll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ㱯")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭㱰"),l1l1ll_l1_ (u"ࠪࠫ㱱"),30)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㱲"),l1l1ll_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ㱳")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠫ㱴"),l1l1ll_l1_ (u"ࠧࠨ㱵"),140)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱶"),l1l1ll_l1_ (u"ࠩࡢࡏࡑࡇ࡟ࠨ㱷")+l1l1ll_l1_ (u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪ㱸"),l1l1ll_l1_ (u"ࠫࠬ㱹"),10)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱺"),l1l1ll_l1_ (u"࠭࡟ࡂࡔࡗࡣࠬ㱻")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊ࠨ㱼"),l1l1ll_l1_ (u"ࠨࠩ㱽"),730)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㱾"),l1l1ll_l1_ (u"ࠪࡣࡐࡘࡂࡠࠩ㱿")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ㲀"),l1l1ll_l1_ (u"ࠬ࠭㲁"),320)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲂"),l1l1ll_l1_ (u"ࠧࡠࡈࡋ࠵ࡤ࠭㲃")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪ㲄"),l1l1ll_l1_ (u"ࠩࠪ㲅"),570)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲆"),l1l1ll_l1_ (u"ࠫࡤࡋࡇࡃࡡࠪ㲇")+l1l1ll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ࠭㲈"),l1l1ll_l1_ (u"࠭ࠧ㲉"),120) # 128
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲊"),l1l1ll_l1_ (u"ࠨࡡࡇࡐࡒࡥࠧ㲋")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠪ㲌"),l1l1ll_l1_ (u"ࠪࠫ㲍"),400)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲎"),l1l1ll_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㲏")+l1l1ll_l1_ (u"࠭ࠠࠡ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠬ㲐"),l1l1ll_l1_ (u"ࠧࠨ㲑"),20)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲒"),l1l1ll_l1_ (u"ࠩࡢࡅࡐࡕ࡟ࠨ㲓")+l1l1ll_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ㲔"),l1l1ll_l1_ (u"ࠫࠬ㲕"),70)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲖"),l1l1ll_l1_ (u"࠭࡟ࡂࡍ࡚ࡣࠬ㲗") +l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊ฬะ์าࠫ㲘"),l1l1ll_l1_ (u"ࠨࠩ㲙"),240)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲚"),l1l1ll_l1_ (u"ࠪࡣࡒࡘࡆࡠࠩ㲛")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨ㲜"),l1l1ll_l1_ (u"ࠬ࠭㲝"),40)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲞"),l1l1ll_l1_ (u"ࠧࡠࡕࡋࡑࡤ࠭㲟")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨ㲠"),l1l1ll_l1_ (u"ࠩࠪ㲡"),50)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲢"),l1l1ll_l1_ (u"ࠫࡤࡌࡔࡎࡡࠪ㲣")+l1l1ll_l1_ (u"๋่ࠬใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫ㲤"),l1l1ll_l1_ (u"࠭ࠧ㲥"),60)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㲦"),l1l1ll_l1_ (u"ࠨࡡࡎ࡛࡙ࡥࠧ㲧")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬ㲨"),l1l1ll_l1_ (u"ࠪࠫ㲩"),130)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲪"),l1l1ll_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ㲫")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨ㲬"),l1l1ll_l1_ (u"ࠧࠨ㲭"),310)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㲮"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ู้ࠣอใๅࠢๆฯ๏ืษ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㲯"),l1l1ll_l1_ (u"ࠪࠫ㲰"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㲱"),l1l1ll_l1_ (u"ࠬࡥࡋࡕࡍࡢࠫ㲲")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠪ㲳"),l1l1ll_l1_ (u"ࠧࠨ㲴"),670)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲵"),l1l1ll_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨ㲶")+l1l1ll_l1_ (u"ࠪࠤ๋่ࠥใ฻ࠣๅัืࠠี๊ࠪ㲷"),l1l1ll_l1_ (u"ࠫࠬ㲸"),390)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㲹"),l1l1ll_l1_ (u"࠭࡟ࡕࡘࡉࡣࠬ㲺")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ㲻"),l1l1ll_l1_ (u"ࠨࠩ㲼"),460)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲽"),l1l1ll_l1_ (u"ࠪࡣࡑࡊࡎࡠࠩ㲾")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪ㲿"),l1l1ll_l1_ (u"ࠬ࠭㳀"),450)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳁"),l1l1ll_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭㳂")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨ㳃"),l1l1ll_l1_ (u"ࠩࠪ㳄"),300)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㳅"),l1l1ll_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ㳆")+l1l1ll_l1_ (u"๋่ࠬใ฻ࠣ์๏ࠦำ๋็สࠫ㳇"),l1l1ll_l1_ (u"࠭ࠧ㳈"),560)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳉"),l1l1ll_l1_ (u"ࠨࡡࡖࡌࡓࡥࠧ㳊")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪ㳋"),l1l1ll_l1_ (u"ࠪࠫ㳌"),580)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㳍"),l1l1ll_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫ㳎")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭㳏"),l1l1ll_l1_ (u"ࠧࠨ㳐"),360)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㳑"),l1l1ll_l1_ (u"ࠩࡢࡗࡍࡖ࡟ࠨ㳒")+l1l1ll_l1_ (u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩ㳓"),l1l1ll_l1_ (u"ࠫࠬ㳔"),480)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳕"),l1l1ll_l1_ (u"࠭࡟ࡂࡔࡖࡣࠬ㳖")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ㳗"),l1l1ll_l1_ (u"ࠨࠩ㳘"),250)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳙"),l1l1ll_l1_ (u"ࠪࡣࡈ࠺ࡕࡠࠩ㳚")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโ๊ิ๎ํ࠭㳛"),l1l1ll_l1_ (u"ࠬ࠭㳜"),420)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㳝"),l1l1ll_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭㳞")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ㳟"),l1l1ll_l1_ (u"ࠩࠪ㳠"),110)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㳡"),l1l1ll_l1_ (u"ࠫࡤࡓ࠴ࡖࡡࠪ㳢")+l1l1ll_l1_ (u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧ㳣"),l1l1ll_l1_ (u"࠭ࠧ㳤"),380)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳥"),l1l1ll_l1_ (u"ࠨࡡࡈࡋ࡛ࡥࠧ㳦")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ㳧"),l1l1ll_l1_ (u"ࠪࠫ㳨"),220)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㳩"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠๆึส็้ࠦใฬ์ิอࠥาฯศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㳪"),l1l1ll_l1_ (u"࠭ࠧ㳫"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㳬"),l1l1ll_l1_ (u"ࠨࡡࡏࡖ࡟ࡥࠧ㳭")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠๅษิ์ือࠧ㳮"),l1l1ll_l1_ (u"ࠪࠫ㳯"),700)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㳰"),l1l1ll_l1_ (u"ࠬࡥࡆࡔࡖࡢࠫ㳱")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤๆ๎ำหษࠪ㳲"),l1l1ll_l1_ (u"ࠧࠨ㳳"),600)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㳴"),l1l1ll_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨ㳵")+l1l1ll_l1_ (u"้ࠪํู่ࠡใหี่ฯࠧ㳶"),l1l1ll_l1_ (u"ࠫࠬ㳷"),620)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㳸"),l1l1ll_l1_ (u"࠭࡟࡚ࡓࡗࡣࠬ㳹")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ㳺"),l1l1ll_l1_ (u"ࠨࠩ㳻"),660)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㳼"),l1l1ll_l1_ (u"ࠪࡣࡇࡘࡓࡠࠩ㳽")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢหีุะ๊อࠩ㳾"),l1l1ll_l1_ (u"ࠬ࠭㳿"),650)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㴀"),l1l1ll_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭㴁")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ㴂"),l1l1ll_l1_ (u"ࠩࠪ㴃"),80)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㴄"),l1l1ll_l1_ (u"ࠫࡤࡊࡒ࠸ࡡࠪ㴅")+l1l1ll_l1_ (u"๋่ࠬใ฻ࠣำึอๅศุࠢัࠬ㴆"),l1l1ll_l1_ (u"࠭ࠧ㴇"),680)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㴈"),l1l1ll_l1_ (u"ࠨࡡࡆࡑࡋࡥࠧ㴉")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ็ว็ิࠪ㴊"),l1l1ll_l1_ (u"ࠪࠫ㴋"),90)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㴌"),l1l1ll_l1_ (u"ࠬࡥࡃࡎࡎࡢࠫ㴍")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ็ห๏ะࠧ㴎"),l1l1ll_l1_ (u"ࠧࠨ㴏"),470)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㴐"),l1l1ll_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨ㴑")+l1l1ll_l1_ (u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫ㴒"),l1l1ll_l1_ (u"ࠫࠬ㴓"),550)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴔"),l1l1ll_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬ㴕")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ࠸࠵࠶ࠧ㴖"),l1l1ll_l1_ (u"ࠨࠩ㴗"),690)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㴘"),l1l1ll_l1_ (u"ࠪࡣࡆࡎࡋࡠࠩ㴙")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢฦ๋ํอใࠡฬํๅ๏࠭㴚"),l1l1ll_l1_ (u"ࠬ࠭㴛"),610)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㴜"),l1l1ll_l1_ (u"ࠧࡠࡅࡆࡆࡤ࠭㴝")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩ㴞"),l1l1ll_l1_ (u"ࠩࠪ㴟"),630)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㴠"),l1l1ll_l1_ (u"ࠫࡤ࡙ࡈࡕࡡࠪ㴡")+l1l1ll_l1_ (u"๋่ࠬใ฻ุࠣํ็็ศࠢอ๎ๆ๐ࠧ㴢"),l1l1ll_l1_ (u"࠭ࠧ㴣"),640)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㴤"),l1l1ll_l1_ (u"ࠨࡡࡈࡋࡓࡥࠧ㴥")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥ์ว้ࠩ㴦"),l1l1ll_l1_ (u"ࠪࠫ㴧"),430)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㴨"),l1l1ll_l1_ (u"ࠬࡥࡆࡉ࠴ࡢࠫ㴩")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩ㴪"),l1l1ll_l1_ (u"ࠧࠨ㴫"),590)
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㴬"),l1l1ll_l1_ (u"ࠩࡢࡉࡌࡊ࡟ࠨ㴭")+l1l1ll_l1_ (u"้ࠪํู่ࠡวํะ๏ࠦฯ๋ัࠪ㴮"),l1l1ll_l1_ (u"ࠫࠬ㴯"),440)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㴰"),l1l1ll_l1_ (u"࠭࡟ࡂࡍࡆࡣࠬ㴱")+l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨ㴲"),l1l1ll_l1_ (u"ࠨࠩ㴳"),350)
	#addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㴴"),l1l1ll_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩ㴵")+l1l1ll_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬ㴶"),l1l1ll_l1_ (u"ࠬ࠭㴷"),490)
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㴸"),l1l1ll_l1_ (u"ࠧࡠࡃࡕࡐࡤ࠭㴹")+l1l1ll_l1_ (u"ࠨ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩ㴺"),l1l1ll_l1_ (u"ࠩࠪ㴻"),200)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㴼"),l1l1ll_l1_ (u"ࠫࡤࡎࡅࡍࡡࠪ㴽")+l1l1ll_l1_ (u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨ㴾"),l1l1ll_l1_ (u"࠭ࠧ㴿"),90)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㵀"),l1l1ll_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧ㵁")+l1l1ll_l1_ (u"่ࠩ์็฿ࠠิ์ิ๎ุࠦแ้ำࠣ์ฯฺࠧ㵂"),l1l1ll_l1_ (u"ࠪࠫ㵃"),218)
	#addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㵄"),l1l1ll_l1_ (u"ࠬࡥࡍࡗ࡜ࡢࠫ㵅")+l1l1ll_l1_ (u"࠭ๅ้ไ฼ࠤ๊๎แ๋ิ็ห๋ีࠠศ๊้่ฬ๐ๆࠨ㵆"),l1l1ll_l1_ (u"ࠧࠨ㵇"),188) # 180
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㵈"),l1l1ll_l1_ (u"ࠩࡢࡉࡌࡈ࡟ࠨ㵉")+l1l1ll_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫ㵊"),l1l1ll_l1_ (u"ࠫࠬ㵋"),120) # 128
	return
def l1l11llll1l_l1_():
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㵌"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞โࠣࡔࡷࡵࡢ࡭ࡧࡰࡷࠥࠬࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࡵࠣࠤ็อฦๆหู้ࠣอใๅ๋ࠢวุฬไสࠢࠣ࠲࠶࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㵍"),l1l1ll_l1_ (u"ࠧࠨ㵎"),264)
	#addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㵏"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࠦ࠲࠯ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㵐")+l1l1ll_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭㵑"),l1l1ll_l1_ (u"ࠫࠬ㵒"),175)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㵓"),l1l1ll_l1_ (u"࠭ࡎࡰࠢࡄࡶࡦࡨࡩࡤࠢࡏࡩࡹࡺࡥࡳࡵࠣࠬࡴࡸࠠࡕࡧࡻࡸ࠮࠭㵔"),l1l1ll_l1_ (u"ࠧࠨ㵕"),151)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㵖"),l1l1ll_l1_ (u"ࠩศฬ้อฺࠡ฻้ࠤฺ๊ใๅหࠪ㵗"),l1l1ll_l1_ (u"ࠪࠫ㵘"),2,l1l1ll_l1_ (u"ࠫࠬ㵙"),l1l1ll_l1_ (u"ࠬ࠭㵚"),l1l1ll_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ㵛"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㵜"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㵝"),l1l1ll_l1_ (u"ࠩࠪ㵞"),2,l1l1ll_l1_ (u"ࠪࠫ㵟"),l1l1ll_l1_ (u"ࠫࠬ㵠"),l1l1ll_l1_ (u"ࠬ࠭㵡"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㵢"),l1l1ll_l1_ (u"ࠧฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤฬ๊อศๆํࠫ㵣"),l1l1ll_l1_ (u"ࠨࠩ㵤"),2,l1l1ll_l1_ (u"ࠩࠪ㵥"),l1l1ll_l1_ (u"ࠪࠫ㵦"),l1l1ll_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ㵧"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㵨"),l1l1ll_l1_ (u"࠭ลาีสู่ࠥฬๅࠢส่สิืศรࠣห้่ฯ๋็ࠪ㵩"),l1l1ll_l1_ (u"ࠧࠨ㵪"),2,l1l1ll_l1_ (u"ࠨࠩ㵫"),l1l1ll_l1_ (u"ࠩࠪ㵬"),l1l1ll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ㵭"))
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㵮"),l1l1ll_l1_ (u"่ࠬัศรฬࠤุาไࠡษ็วำ฽วยࠢส่าอไ๋ࠩ㵯"),l1l1ll_l1_ (u"࠭ࠧ㵰"),340,l1l1ll_l1_ (u"ࠧࠨ㵱"),l1l1ll_l1_ (u"ࠨࠩ㵲"),l1l1ll_l1_ (u"ࠩࡢࡐࡔࡍࡆࡊࡎࡈࡣࠬ㵳"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㵴"),l1l1ll_l1_ (u"ࠫ็ืวยหࠣืั๊ࠠศๆฦา฼อมࠡษ็ๆิ๐ๅࠨ㵵"),l1l1ll_l1_ (u"ࠬ࠭㵶"),340,l1l1ll_l1_ (u"࠭ࠧ㵷"),l1l1ll_l1_ (u"ࠧࠨ㵸"),l1l1ll_l1_ (u"ࠨࡡࡏࡓࡌࡌࡉࡍࡇࡢࡓࡑࡊ࡟ࠨ㵹"))
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㵺"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㵻"),l1l1ll_l1_ (u"ࠫࠬ㵼"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㵽"),l1l1ll_l1_ (u"࠭ล๋ไสๅࠥ๎สี฼ํ่ࠥอไไษืࠫ㵾"),l1l1ll_l1_ (u"ࠧࠨ㵿"),345)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㶀"),l1l1ll_l1_ (u"ࠩส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥไษำ้ห๊าࠧ㶁"),l1l1ll_l1_ (u"ࠪࠫ㶂"),507,l1l1ll_l1_ (u"ࠫࠬ㶃"),l1l1ll_l1_ (u"ࠬ࠭㶄"),l1l1ll_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ㶅"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㶆"),l1l1ll_l1_ (u"ࠨฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠪ㶇"),l1l1ll_l1_ (u"ࠩࠪ㶈"),159)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㶉"),l1l1ll_l1_ (u"ࠫส๐โศใࠣ์ฯฺฺ๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭㶊"),l1l1ll_l1_ (u"ࠬ࠭㶋"),343)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㶌"),l1l1ll_l1_ (u"ࠧฦ์ๅหๆ่ࠦหึ฽๎้ࠦสฯิํ๊ࠥอไใ๊สส๊࠭㶍"),l1l1ll_l1_ (u"ࠨࠩ㶎"),508)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㶏"),l1l1ll_l1_ (u"ࠪๅา฻้ࠠวุ่ฬำࠠระิࠤฬ๊สฮัํฯฬะࠧ㶐"),l1l1ll_l1_ (u"ࠫࠬ㶑"),7)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㶒"),l1l1ll_l1_ (u"࠭ส฻์ํี๋ࠥใศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭㶓"),l1l1ll_l1_ (u"ࠧࠨ㶔"),332)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㶕"),l1l1ll_l1_ (u"ࠩศ๎็อแ๊ࠡอุ฿๐ไࠡีํีๆืวหࠢส่อื่ไีํࠫ㶖"),l1l1ll_l1_ (u"ࠪࠫ㶗"),342)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㶘"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㶙"),l1l1ll_l1_ (u"࠭ࠧ㶚"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㶛"),l1l1ll_l1_ (u"ࠨวุ่ฬำࠠๆะี๊ࠥ฿ๅศัࠪ㶜"),l1l1ll_l1_ (u"ࠩࠪ㶝"),172)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㶞"),l1l1ll_l1_ (u"ࠫส฻ไศฯ้้ࠣ็ࠠศๆิืฬฬไࠨ㶟"),l1l1ll_l1_ (u"ࠬ࠭㶠"),349)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㶡"),l1l1ll_l1_ (u"ࠧฦื็หาࠦโ้ษษ้ࠥอไๆใู่ฮ࠭㶢"),l1l1ll_l1_ (u"ࠨࠩ㶣"),504)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㶤"),l1l1ll_l1_ (u"ࠪษฺ๊วฮࠢไ๎ิ๐่่ษอࠤࡲࡶࡤࠨ㶥"),l1l1ll_l1_ (u"ࠫࠬ㶦"),173)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㶧"),l1l1ll_l1_ (u"࠭ลึๆสัࠥ็๊ะ์๋๋ฬะࠠࡳࡶࡰࡴࠬ㶨"),l1l1ll_l1_ (u"ࠧࠨ㶩"),174)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㶪"),l1l1ll_l1_ (u"ࠩศู้ออࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠬ㶫"),l1l1ll_l1_ (u"ࠪࠫ㶬"),502)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㶭"),l1l1ll_l1_ (u"ࠬหีๅษะࠤ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ㶮"),l1l1ll_l1_ (u"࠭ࠧ㶯"),503)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㶰"),l1l1ll_l1_ (u"ࠨวุ่ฬำࠠใ๊ส฽ิࠦวๅสํห๋อส๊ࠡส่่อิࠨ㶱"),l1l1ll_l1_ (u"ࠩࠪ㶲"),506)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㶳"),l1l1ll_l1_ (u"ࠫๆำีࠡษอูฬ๊ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ㶴"),l1l1ll_l1_ (u"ࠬ࠭㶵"),4)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㶶"),l1l1ll_l1_ (u"ࠧฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็็ํี๊ࠨ㶷"),l1l1ll_l1_ (u"ࠨࠩ㶸"),347)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㶹"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㶺"),l1l1ll_l1_ (u"ࠫࠬ㶻"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㶼"),l1l1ll_l1_ (u"࠭ส็ฺํๅ้่ࠥะ์ࠪ㶽"),l1l1ll_l1_ (u"ࠧࠨ㶾"),740)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㶿"),l1l1ll_l1_ (u"ࠩอ๊฽๐แࠡษ็ะ์อาࠨ㷀"),l1l1ll_l1_ (u"ࠪࠫ㷁"),750)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㷂"),l1l1ll_l1_ (u"๋ࠬำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠨ㷃"),l1l1ll_l1_ (u"࠭ࠧ㷄"),9)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㷅"),l1l1ll_l1_ (u"ࠨ็ึัࠥหูะษาหฯࠦวๅสิ๊ฬ๋ฬࠨ㷆"),l1l1ll_l1_ (u"ࠩࠪ㷇"),344)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㷈"),l1l1ll_l1_ (u"ࠫส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠩ㷉"),l1l1ll_l1_ (u"ࠬ࠭㷊"),6)
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㷋"),l1l1ll_l1_ (u"ࠧฦ฻าหิอส࡛ࠡࡲࡹࡹࡻࡢࡦࠩ㷌"),l1l1ll_l1_ (u"ࠨࠩ㷍"),179)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㷎"),l1l1ll_l1_ (u"ࠪษ฾ีวะษอࠤ࡞ࡵࡵࡵࡷࡥࡩ࠲ࡊࡌࠨ㷏"),l1l1ll_l1_ (u"ࠫࠬ㷐"),178)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㷑"),l1l1ll_l1_ (u"࠭ลฺัสำฬะࠠࡓࡧࡶࡳࡱࡼࡥࡖࡔࡏࠫ㷒"),l1l1ll_l1_ (u"ࠧࠨ㷓"),177)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㷔"),l1l1ll_l1_ (u"ࠩศ฽ิอฯศฬࠣࡍࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࠡࡃࡧࡥࡵࡺࡩࡷࡧࠪ㷕"),l1l1ll_l1_ (u"ࠪࠫ㷖"),5)
	return
def l1l11lll111_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㷗"),l1l1ll_l1_ (u"ࠬࡔ࡯ࠡࡃࡵࡥࡧ࡯ࡣࠡࡎࡨࡸࡹ࡫ࡲࡴࠢࠫࡳࡷࠦࡔࡦࡺࡷ࠭ࠬ㷘"),l1l1ll_l1_ (u"࠭ࠧ㷙"),151)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㷚"),l1l1ll_l1_ (u"ࠨ็สࠤ์๎ࠠศใู่ࠥาไะࠢ็่อืๆศ็ฯࠫ㷛"),l1l1ll_l1_ (u"ࠩࠪ㷜"),197)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㷝"),l1l1ll_l1_ (u"๊ࠫอ่๊ࠠࠣห้๋่ใ฻ࠣห้ืำๆ์่้ࠣฮั็ษ่ะࠬ㷞"),l1l1ll_l1_ (u"ࠬ࠭㷟"),341)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㷠"),l1l1ll_l1_ (u"ࠧๆษ๋ࠣํࠦยฯำࠣษฺีวาࠢ็็ํี๊๊ࠡ็่อืๆศ็ฯࠫ㷡"),l1l1ll_l1_ (u"ࠨࠩ㷢"),7)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㷣"),l1l1ll_l1_ (u"ࠪ็๏็๊สࠢสืฯิฯศ็ࠣห้๋แืๆฬࠫ㷤"),l1l1ll_l1_ (u"ࠫࠬ㷥"),150)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㷦"),l1l1ll_l1_ (u"࠭ใ๋ใํอ๋ࠥำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠩ㷧"),l1l1ll_l1_ (u"ࠧࠨ㷨"),170)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㷩"),l1l1ll_l1_ (u"ࠩๆ๎ๆࠦสหื็ࠤํะส้ษุู่๋ࠥࠡษ็้อืๅอࠩ㷪"),l1l1ll_l1_ (u"ࠪࠫ㷫"),196)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㷬"),l1l1ll_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣ์ฺ่๋ࠠ็ิ๋ࠥฮวๅสิ๊ฬ๋ฬࠨ㷭"),l1l1ll_l1_ (u"࠭ࠧ㷮"),190)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㷯"),l1l1ll_l1_ (u"ࠨๆ่หีอࠠษ฻ูࠤฬ๊ั้ษห฻ࠥฮื๋ศฬࠫ㷰"),l1l1ll_l1_ (u"ࠩࠪ㷱"),155)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㷲"),l1l1ll_l1_ (u"้๋ࠫวัษࠣฬ฾฼ࠠศๆิ์ฬฮืࠡๆสࠤฯ฿ๅๅࠩ㷳"),l1l1ll_l1_ (u"ࠬ࠭㷴"),153)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㷵"),l1l1ll_l1_ (u"ࠧๅ็สิฬࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠡๆสࠤฯ฿ๅๅࠩ㷶"),l1l1ll_l1_ (u"ࠨࠩ㷷"),152)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㷸"),l1l1ll_l1_ (u"่๊ࠪอะศࠢห฽฻ࠦวๅ็๋ห็฿ࠠๅษࠣฮ฾๋ไࠨ㷹"),l1l1ll_l1_ (u"ࠫࠬ㷺"),195)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㷻"),l1l1ll_l1_ (u"࠭สฮาํีࠥ๐ฮึࠢื๋ฬีษࠡษ็ฮู็๊าࠩ㷼"),l1l1ll_l1_ (u"ࠧࠨ㷽"),171)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㷾"),l1l1ll_l1_ (u"ࠩ็้ฬึวࠡ์๋ะิࠦำ๋ำไีฬะࠠๆฮ๊์้ฯࠧ㷿"),l1l1ll_l1_ (u"ࠪࠫ㸀"),156)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㸁"),l1l1ll_l1_ (u"ࠬอไโ์า๎ํํวห้ࠢ์฾ࠦ࡭ࡱࡦ่ࠣฬࠦสฺ็็ࠫ㸂"),l1l1ll_l1_ (u"࠭ࠧ㸃"),194)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㸄"),l1l1ll_l1_ (u"ࠨๆ่หีอࠠๅษ๊ࠣๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠨ㸅"),l1l1ll_l1_ (u"ࠩࠪ㸆"),193)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㸇"),l1l1ll_l1_ (u"ࠫอ฿ึࠡษ็ๅ๏ี๊้้สฮࠥฮื๋ศฬࠤํะโุ฻ࠪ㸈"),l1l1ll_l1_ (u"ࠬ࠭㸉"),158)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㸊"),l1l1ll_l1_ (u"ࠧไ์ไࠤฯำไࠡส้ๅุ้ࠠๆึๆ่ฮࠦๅลไอ๋ࠬ㸋"),l1l1ll_l1_ (u"ࠨࠩ㸌"),192)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㸍"),l1l1ll_l1_ (u"ࠪ็๏็ࠠหีอาิ๋ࠠศๆิ๎๊๎สࠡ็฼ࠤ่๎ฯ๋ࠩ㸎"),l1l1ll_l1_ (u"ࠫࠬ㸏"),198)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㸐"),l1l1ll_l1_ (u"࠭ๅศ๊ࠢ๎ࠥอไิ์ิๅึอสࠡษ็฽ฬ๋ษ๊ࠡส่ำอีสࠩ㸑"),l1l1ll_l1_ (u"ࠧࠨ㸒"),157)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㸓"),l1l1ll_l1_ (u"่ࠩหู๋ࠥ็๋๋ࠣีํࠠศๆ฼่ฬ๋วหࠢหห้ฮั็ษ่ะࠥ࠲ࠧ㸔")+half_triangular_colon+l1l1ll_l1_ (u"ࠪ࠿ࠬ㸕"),l1l1ll_l1_ (u"ࠫࠬ㸖"),191)
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㸗"),l1l1ll_l1_ (u"࠭ใ๋ใࠣฮา๊ࠠๆึๆ่ฮࠦออสࠣฬ฾฼ࠠศๆ่์ฬู่ࠨ㸘"),l1l1ll_l1_ (u"ࠧࠨ㸙"),195)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㸚"),l1l1ll_l1_ (u"ࠩฦ๎๋ࠦๅ้ษๅ฽ࠥอไฤใ็ห๊่ࠦศๆ่ืู้ไศฬࠣห้ษฬ็สํอࠬ㸛"),l1l1ll_l1_ (u"ࠪࠫ㸜"),154)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㸝"),l1l1ll_l1_ (u"่ࠬว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠬ㸞"),l1l1ll_l1_ (u"࠭ࠧ㸟"),3)
	return
def l1l11ll11ll_l1_(type_,l1l11l1l1l1_l1_=False):
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㸠"),l1l1ll_l1_ (u"ࠨ็ึัࠥํะ่ࠢส่็อฦๆหࠪ㸡"),l1l1ll_l1_ (u"ࠩࠪ㸢"),266,l1l1ll_l1_ (u"ࠪࠫ㸣"),l1l1ll_l1_ (u"ࠫࠬ㸤"),type_)
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㸥"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㸦"),l1l1ll_l1_ (u"ࠧࠨ㸧"),9999)
	l111l_l1_ = []
	if os.path.exists(l1l11l11ll1_l1_):
		l1l11ll1lll_l1_ = open(l1l11l11ll1_l1_,l1l1ll_l1_ (u"ࠨࡴࡥࠫ㸨")).read()
		if kodi_version>18.99: l1l11ll1lll_l1_ = l1l11ll1lll_l1_.decode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㸩"))
		l1l11l1lll1_l1_ = EVAL(l1l1ll_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㸪"),l1l11ll1lll_l1_)
		if type_ in list(l1l11l1lll1_l1_.keys()):
			l111l_l1_ = l1l11l1lll1_l1_[type_]
			if not l1l11l1l1l1_l1_:
				try:
					for type,name,url,mode,image,page,text,context,infodict in l111l_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
				except:
					#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㸫"),l1l1ll_l1_ (u"ࠬ࠭㸬"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㸭"),l1l1ll_l1_ (u"่่ࠧส็๋ࠥิไๆฬࠤๆ๐ࠠๆๆไࠤวิัࠡษ็ๅ๏ี๊้้สฮࠬ㸮"),l1l1ll_l1_ (u"ࠨๆๆ๎ࠥะสฯๆุࠤ๊์ࠠศๆุ่่๊ษࠡษู฾฼ูࠦๅ๋ࠪ㸯"),l1l1ll_l1_ (u"ุ้ࠩࠥำ่ࠠา๊ࠤฬ๊โศศ่อࠧ࠭㸰"))
					l1l11l1lll1_l1_ = FIX_AND_GET_FILE_CONTENTS(l1l11l11ll1_l1_)
					l111l_l1_ = l1l11l1lll1_l1_[type_]
					for type,name,url,mode,image,page,text,context,infodict in l111l_l1_:
						addMenuItem(type,name,url,mode,image,page,text,context,infodict)
	return len(l111l_l1_)
def l1l11lll11l_l1_(type_):
	answer = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㸱"),l1l1ll_l1_ (u"ࠫࠬ㸲"),l1l1ll_l1_ (u"ࠬ࠭㸳"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㸴"),l1l1ll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡใ฼่ฬࠦๅิฯࠣะ๊๐ูࠡ็ะฮํ๐วหࠢๅหห๋ษࠡฤัีࠥ࠻࠰ࠡࠩ㸵")+TRANSLATE(type)+l1l1ll_l1_ (u"ࠨࠢยࠥࠬ㸶"))
	if answer==1:
		if os.path.exists(l1l11l11ll1_l1_):
			l1l11ll1lll_l1_ = open(l1l11l11ll1_l1_,l1l1ll_l1_ (u"ࠩࡵࡦࠬ㸷")).read()
			if kodi_version>18.99: l1l11ll1lll_l1_ = l1l11ll1lll_l1_.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㸸"))
			l1l11ll1lll_l1_ = EVAL(l1l1ll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㸹"),l1l11ll1lll_l1_)
			if type_ in list(l1l11ll1lll_l1_.keys()):
				del l1l11ll1lll_l1_[type_]
				l1l11ll1lll_l1_ = str(l1l11ll1lll_l1_)
				if kodi_version>18.99: l1l11ll1lll_l1_ = l1l11ll1lll_l1_.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㸺"))
				open(l1l11l11ll1_l1_,l1l1ll_l1_ (u"࠭ࡷࡣࠩ㸻")).write(l1l11ll1lll_l1_)
				DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㸼"),l1l1ll_l1_ (u"ࠨࠩ㸽"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㸾"),l1l1ll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡ็ะฮํ๐วหࠢๅหห๋ษࠡฤัีࠥ࠻࠰ࠡࠩ㸿")+TRANSLATE(type))
	l1l11ll11ll_l1_(type_)
	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㹀"))
	return
def l1l11ll1ll1_l1_(l1l11ll1111_l1_):
	l1111l1ll1_l1_ = l1l11lllll1_l1_()
	l1l11l1l1ll_l1_ = False
	for addon_id in l1l11ll1111_l1_:
		if l1l11l1l1ll_l1_: continue
		if addon_id not in list(l1111l1ll1_l1_.keys()): continue
		l1l11ll1l11_l1_ = l1111l1ll1_l1_[addon_id]
		l1l11llll11_l1_,l1l11lll1l1_l1_,l1l11l11lll_l1_ = l1l11ll1l11_l1_[0]
		l1l11l11l1l_l1_,l1l11l1ll1l_l1_ = l1l11lll1ll_l1_(addon_id)
		if not l1l11l11l1l_l1_: l1l11l1l1ll_l1_ = True
		else:
			l1l11l1llll_l1_ = l1l11lll1l1_l1_>l1l11l1ll1l_l1_
			if l1l11l1llll_l1_: l1l11l1l1ll_l1_ = True
	return l1l11l1l1ll_l1_
def l1l11llllll_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㹁"),l1l1ll_l1_ (u"࠭ࠧ㹂"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㹃"),l1l1ll_l1_ (u"ࠨสิ๊ฬ๋ฬࠡ฻่หิࠦแ๋้ࠣ฽๋ีใࠡ็ื็้ฯࠠไสํีฮࠦ࠮࠯ࠢฦฬิษࠠษใะูࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦอศ๊็ࠤฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡ࠰࠱ࠤฬ๊ๅีๅ็อࠥ฿ๆะๅࠣษ๊อࠠษีหฬࠥอไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦศิสหࠤศ์ࠠศๆหี๋อๅอࠢ฼๊ิ้ࠠใัํ้ࠥ࠴࠮ࠡล๋ࠤอูศษࠢฦ๊ࠥอไๆสิ้ัࠦโศ็ࠣฬส๐โศใࠣห้ฮั็ษ่ะࠥ฿ไ๊ࠢฯ๋ฬุใࠡ࠰࠱ࠤศ๎ࠠษีหฬࠥอๆไࠢ็หࠥะำหะา้ࠥฮั็ษ่ะࠥ฿ๅศัࠣห้ษีๅ์ࠣ࠲࠳ࠦไๆ฻ิๅฮࠦวๅ็ื็้ฯࠠษษ็ฺอ฽ࠠศ่อࠤอำวอหࠣษ้๏ࠠฦำึห้ࠦัใ็ࠣห้ิืฤࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏ูวฺัๆࠤๆ๐ࠠฮๆู้้ࠣไสࠢฯ๋ฬุใ้ࠡำหࠬ㹄"))
	return
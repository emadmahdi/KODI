# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
#
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪ丧")
def MAIN(mode,text=l1l1ll_l1_ (u"ࠩࠪ丨")):
	if   mode==  0: l1l1l1l11l11_l1_(text)
	elif mode==  2: l1l11llllll1_l1_(text)
	elif mode==  3: l1l1ll1lll11_l1_()
	elif mode==  4: l1l1llll11l1_l1_(text)
	elif mode==  5: l1l1l11llll1_l1_()
	elif mode==  6: l1l1lll1ll11_l1_()
	elif mode==  7: l1l1ll111l1l_l1_()
	elif mode==  8: l1l1l11l1ll1_l1_()
	elif mode==  9: l1l1l11ll111_l1_()
	elif mode==150: l1l1lll111ll_l1_()
	elif mode==151: l1l11l11l11l_l1_()
	elif mode==152: l1l1l1llllll_l1_()
	elif mode==153: l1ll111llll1_l1_()
	elif mode==154: l1l1lllll1ll_l1_()
	elif mode==155: l1l1l1l1l1l1_l1_()
	elif mode==156: l1l11l111ll1_l1_()
	elif mode==157: l1l1lll1ll1l_l1_()
	elif mode==158: l1l1ll11111l_l1_()
	elif mode==159: l1l1ll1l1lll_l1_(True)
	elif mode==170: l1l1l1111l1l_l1_()
	elif mode==171: l1l1ll1l111l_l1_()
	elif mode==172: l1ll111l1l1l_l1_()
	elif mode==173: l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ丩"),True)
	elif mode==174: l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ个"),True)
	elif mode==175: l1l1l1ll11ll_l1_()
	elif mode==176: l1l11llll111_l1_()
	elif mode==177: l1l1llll1l1l_l1_(l1l1ll_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ丫"))
	elif mode==178: l1l1llll1l1l_l1_(l1l1ll_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ丬"))
	elif mode==179: l1l1llll1l1l_l1_(l1l1ll_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ中"))
	elif mode==190: l1l1l1l111l1_l1_()
	elif mode==191: l1l11ll1l111_l1_()
	elif mode==192: l1l11llll11l_l1_()
	elif mode==193: l1l1ll1l11ll_l1_()
	elif mode==194: l1l11lll1l11_l1_()
	elif mode==195: l1l1l111l1l1_l1_()
	elif mode==196: l1l1l11lll1l_l1_()
	elif mode==197: l1l1l11l1111_l1_()
	elif mode==198: l1l1ll11llll_l1_()
	elif mode==199: l1l11ll11l11_l1_()
	elif mode==340: l1l11ll11111_l1_(text)
	elif mode==341: l1l1llll1lll_l1_()
	elif mode==342: l1l1l1l1lll1_l1_()
	elif mode==343: l1l1l11l111l_l1_()
	elif mode==344: l1l1lllll11l_l1_()
	elif mode==345: l1l1ll111ll1_l1_()
	elif mode==346: l1l1l1lll1l1_l1_()
	elif mode==347: l1l1lll11ll1_l1_(True)
	elif mode==348: l1l1ll1l11l1_l1_()
	elif mode==349: l1l1lll11l11_l1_(l1ll1111lll1_l1_)
	elif mode==500: l1l11ll1l1ll_l1_()
	elif mode==501: l1l11l1l1ll1_l1_()
	elif mode==502: l1l1ll11ll1l_l1_(l1l1ll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ丮"),True)
	elif mode==503: l1l1lll11l11_l1_(l1l11l11ll1_l1_)
	elif mode==504: l1l1lll11l11_l1_(favoritesfile)
	elif mode==505: l1l1l1ll111l_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l1llll1l11_l1_(text,l1l1ll_l1_ (u"ࠩࠪ丯"),True)
	elif mode==508: l1l1ll1l1111_l1_()
	return
def l1l1llll1l11_l1_(addon_id,function,showDialogs):
	conn = sqlite3.connect(l1l1lll111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l1l11lllll11_l1_ = l1l1ll_l1_ (u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭丰")
	else: l1l11lllll11_l1_ = l1l1ll_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪ丱")
	cc.execute(l1l1ll_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭串")+l1l11lllll11_l1_+l1l1ll_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ丳")+addon_id+l1l1ll_l1_ (u"ࠧࠣࠢ࠾ࠫ临"))
	rows = cc.fetchall()
	if rows and function in [l1l1ll_l1_ (u"ࠨࠩ丵"),l1l1ll_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ丶")]:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࠫ丷"),l1l1ll_l1_ (u"ࠫࠬ丸"),l1l1ll_l1_ (u"ࠬ࠭丹"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ为"),l1l1ll_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ主")+addon_id+l1l1ll_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ丼"))
		if yes!=1: return
		cc.execute(l1l1ll_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ丽")+l1l11lllll11_l1_+l1l1ll_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ举")+addon_id+l1l1ll_l1_ (u"ࠫࠧࠦ࠻ࠨ丿"))
	elif function in [l1l1ll_l1_ (u"ࠬ࠭乀"),l1l1ll_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࠧ乁")]:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࠨ乂"),l1l1ll_l1_ (u"ࠨࠩ乃"),l1l1ll_l1_ (u"ࠩࠪ乄"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭久"),l1l1ll_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ乆")+addon_id+l1l1ll_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ乇"))
		if yes!=1: return
		if kodi_version<19: cc.execute(l1l1ll_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭么")+addon_id+l1l1ll_l1_ (u"ࠧࠣࠫࠣ࠿ࠬ义"))
		else: cc.execute(l1l1ll_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ乊")+addon_id+l1l1ll_l1_ (u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩ之"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l1l1ll_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ乌"))
	time.sleep(1)
	if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ乍"),l1l1ll_l1_ (u"ࠬ࠭乎"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ乏"),l1l1ll_l1_ (u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ乐"))
	if function in [l1l1ll_l1_ (u"ࠨࠩ乑"),l1l1ll_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ乒")]: l1l1ll1l1lll_l1_(showDialogs)
	return
def l1l1l1ll111l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭乓"),l1l1ll_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ乔"))
	l1l1lll1l111_l1_ = l1l1llll1ll1_l1_()
	l1l1ll11l1l1_l1_ = l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ乕")
	l1ll11l11111_l1_ = l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ乖")
	l1ll111lllll_l1_ = l1l1ll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ乗")
	for id,l1l1ll111111_l1_,l1l1l1l1l1ll_l1_,answer,l1l11l1l11ll_l1_,reason in reversed(l1l1lll1l111_l1_):
		if id==l1l1ll_l1_ (u"ࠨ࠲ࠪ乘"):
			l1l1l11l1l1l_l1_,l1ll11111l1l_l1_ = answer.split(l1l1ll_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ乙"))
			continue
		if l1l1ll11l1l1_l1_!=l1l1ll_l1_ (u"ࠪࡠࡳ࠭乚"): l1l1ll11l1l1_l1_ += l1ll111lllll_l1_
		l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ乛")+id+l1l1ll_l1_ (u"ࠬࠦ࠺ࠡࠩ乜")+l1l1ll_l1_ (u"࠭วๅีวห้ࠦ࠺ࠡࠩ九")+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ乞")+l1l1l1l1l1ll_l1_
		l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ也")+answer
		l1111l1ll1l_l1_ = l1l1ll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽รࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ习")+l1l11l1l11ll_l1_
		l1111l1lll1_l1_ = l1l1ll_l1_ (u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิสหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ乡")+reason
		l1l1ll11l1l1_l1_ += l1ll1l11l11_l1_+l1ll1l11l1l_l1_+l1l1ll_l1_ (u"ࠫࡡࡴࠧ乢")+l1ll11l11111_l1_+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ乣")+l1111l1ll1l_l1_+l1111l1lll1_l1_+l1l1ll_l1_ (u"࠭࡜࡯ࠩ乤")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭乥"),l1ll11111l1l_l1_,l1l1ll11l1l1_l1_,l1l1ll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ书"))
	return
def l1l1lll11l11_l1_(file):
	if file==favoritesfile: l1l1l1ll1lll_l1_ = l1l1ll_l1_ (u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ乧")
	elif file==l1ll1111lll1_l1_: l1l1l1ll1lll_l1_ = l1l1ll_l1_ (u"ࠪห้ืำศศ็ࠫ乨")
	elif file==l1l11l11ll1_l1_: l1l1l1ll1lll_l1_ = l1l1ll_l1_ (u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ乩")
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠬ࠭乪"),l1l1ll_l1_ (u"࠭ࠧ乫"),l1l1ll_l1_ (u"ࠧࠨ乬"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ乭"),l1l1ll_l1_ (u"๊่ࠩࠥะั๋ัࠣห้ศๆࠡวุ่ฬำࠠࠨ乮")+l1l1l1ll1lll_l1_+l1l1ll_l1_ (u"ࠪࠤฤࠧࠧ乯"))
	if yes==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ买"),l1l1ll_l1_ (u"ࠬ࠭乱"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ乲"),l1l1ll_l1_ (u"ࠧห็ࠣษฺ๊วฮ่่ࠢๆࠦࠧ乳")+l1l1l1ll1lll_l1_)
	return
def l1l11l1l1ll1_l1_():
	if kodi_version<18:
		message = l1l1ll_l1_ (u"ࠨๆ็วุ็ࠠฤ่อࠤฯูสฯั่ࠤส฻ฯศำࠣ็ํี๊ࠡไา๎๊ࠦัใ็ࠣࠫ乴")+str(kodi_version)+l1l1ll_l1_ (u"ࠩࠣ์้ํะศࠢส่็๎วว็ࠣห้๋ี้ำฬࠤ้อࠠห฻่่ࠥ฿ๆะๅࠣ࠲ࠥํะ่ࠢส่๊๐าสࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠣ࠲๊ࠥลึๆสัࠥอไๆึๆ่ฮࠦโๆࠢหฮาี๊ฬࠢหี๋อๅอࠢๆ์ิ๐ࠠฦๆ์ࠤส๐ࠠฦืาหึࠦัใ็๊ࠤศ฿ไ๊่๊ࠢࠥ࠷࠸࠯࠲ࠪ乵")
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ乶"),l1l1ll_l1_ (u"ࠫࠬ乷"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ乸"),message)
		return
	l1l11l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ乹"))
	l1ll1l11l1l1_l1_ = l1l1l1l1llll_l1_([l1l1ll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭乺")])
	l1l11l1l1ll_l1_,l1l1ll1lllll_l1_,l1l11l1l111l_l1_,l1l1lll11111_l1_,l1l1ll1lll1l_l1_,l1l11l1llll1_l1_,l1l1ll1llll1_l1_ = l1ll1l11l1l1_l1_[l1l1ll_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ乻")]
	if l1l11l1l1ll_l1_ or l1l1ll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ乼") not in str(l1l11l1lllll_l1_):
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ乽"),l1l1ll_l1_ (u"ࠫࠬ乾"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ乿"),l1l1ll_l1_ (u"࠭วๅไ๋หห๋ࠠศๆู่ํืษࠡฬ฼้้ࠦแใู้ࠣ฾ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥํะ่ࠢส่็๎วว็ࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠫ亀"))
		succeeded = l1l1ll11ll1l_l1_(l1l1ll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭亁"),True)
		if not succeeded: return
	l1l1ll1ll1l1_l1_(True)
	return
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩࠬࠎࠎ࡯ࡦࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࡂࡃࠧ࠶࠶࠷ࠫ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็ࠣห้้สศสฬࠫࠏࠏࡥ࡭࡫ࡩࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄ࠾࠿ࠪ࠹࠺࠻ࠧ࠻ࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠤࡂࠦࠧใ๊สส๊ࠦวๅื๋ีࠬࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࠡ࠿ࠣࠫ็๎วว็้ࠣัํ่ๅหࠪࠎࠎ࡯ࡦࠡࡥ࡫ࡳ࡮ࡩࡥ࠾࠿࠳࠾ࠎࠏࠣࠡࡣࡱࡽࠥࡵࡴࡩࡧࡵࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࠐࠉࠊࡸ࡬ࡩࡼࡺࡹࡱࡧࡌࡈࠥࡃࠠࠨࠩࠍࠍࠎࠩࡩ࡮ࡲࡲࡶࡹࠦࡳࡲ࡮࡬ࡸࡪ࠹ࠊࠊࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡻ࡯ࡥࡸࡵࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠎࠎࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࠍࡨࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࡸ࡬ࡩࡼࠨࠠࡘࡊࡈࡖࡊࠦࡶࡪࡧࡺࡑࡴࡪࡥࠡ࠿ࠣ࠵࠾࠽࠱࠲࠹ࠣ࠿ࠬ࠯ࠊࠊࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࡶࡪࡧࡺࠦࠥ࡝ࡈࡆࡔࡈࠤࡻ࡯ࡥࡸࡏࡲࡨࡪࠦ࠽ࠡ࠸࠹࠴࠽࠶ࠠ࠼ࠩࠬࠎࠎࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࠊࡥࡲࡲࡳ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࡧ࡯࡭࡫ࠦࡣࡩࡱ࡬ࡧࡪࡃ࠽࠲࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠠ࠾ࠢࠪ࠹࠹࠺ࠧࠊࠥࠣࠦࡑ࡯ࡳࡵࠢࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠶࠿ࠦࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥ࠭࠵࠶࠷ࠪࠍࠨࠦࠢࡈࡣ࡯ࡰࡪࡸࡹࡠࡇࡰࡥࡩࠨࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠌࠌࡩࡱࡹࡥ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠌࠌࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠨ࠮ࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉ࠯ࠊࠊࠤࠥࠦ亂")
def l1l1ll1ll1l1_l1_(showDialogs=True):
	l1l11l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ亃"))
	if l1l1ll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ亄") not in str(l1l11l1lllll_l1_):
		if showDialogs:
			DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ亅"),l1l1ll_l1_ (u"ࠬ࠭了"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ亇"),l1l1ll_l1_ (u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ予"))
		return
	l1l1lll1l1l1_l1_ = os.path.join(l1l1ll11l1_l1_,l1l1ll_l1_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ争"),l1l1ll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ亊"),l1l1ll_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ事"),l1l1ll_l1_ (u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ二"))
	if not os.path.exists(l1l1lll1l1l1_l1_): return
	oldFILE = open(l1l1lll1l1l1_l1_,l1l1ll_l1_ (u"ࠬࡸࡢࠨ亍")).read()
	if kodi_version>18.99: oldFILE = oldFILE.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ于"))
	l1l11l1l1111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠩ࡞ࡧ࠯࠱ࡢࡤࠬ࠮࡟ࡨ࠰࠯ࠬࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡨࡻࡸࡄࠧ亏"),oldFILE,re.DOTALL)
	l1l11ll111l1_l1_,l1ll111lll11_l1_ = l1l11l1l1111_l1_[0]
	l1l1llllllll_l1_ = l1l1ll_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ亐")+l1l11ll111l1_l1_+l1l1ll_l1_ (u"ࠩ࠯ࠫ云")+l1ll111lll11_l1_+l1l1ll_l1_ (u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ互")
	if showDialogs:
		l1ll111111ll_l1_ = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡗ࡫ࡨࡻࡲࡵࡤࡦࠩ亓"))
		if l1ll111111ll_l1_==l1l1ll_l1_ (u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨ五"): l1l1llllll11_l1_ = l1l1ll_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭井")
		elif l1ll111111ll_l1_==l1l1ll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭亖"): l1l1llllll11_l1_ = l1l1ll_l1_ (u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭亗")
		else: l1l1llllll11_l1_ = l1l1ll_l1_ (u"ࠩๅ์ฬฬๅࠡลัี๎࠭亘")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ亙"),l1l1ll_l1_ (u"ࠫ็๎วว็ࠣวำื้ࠨ亚"),l1l1ll_l1_ (u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ些"),l1l1ll_l1_ (u"࠭โ้ษษ้ࠥอไึ๊ิࠫ亜"),l1l1ll_l1_ (u"ࠧศ่อࠤาอไ๋ษࠣฮุะฮะ็ࠣࠫ亝")+l1l1llllll11_l1_,l1l1ll_l1_ (u"ࠨษ้ฮࠥอไร่ࠣฮุะฮะ็ࠣห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤํํะศ่ࠢ฽๋อ็ࠡษ้็ࠥะำหูํ฽ࠥอำหะาห๊ࠦวๅไ๋หห๋ࠠศๆู่ํืษࠡสา่ฬࠦๅ็ࠢๅ์ฬฬๅࠡษ็็ฯอศสࠢ࠱ࠤํษ๊ืษࠣฮุะื๋฻ࠣษ๏่วโ้สࠤๆ๐ࠠฤ์ࠣ์็ะࠠหึสลࠥࡢ࡮࡝ࡰࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ亞"))
		if choice==1: l1l1l1ll1l1l_l1_ = l1l1ll_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ亟")
		elif choice==2: l1l1l1ll1l1l_l1_ = l1l1ll_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ亠")
		else: l1l1l1ll1l1l_l1_ = l1l1ll_l1_ (u"ࠫࠬ亡")
	else:
		l1ll111111ll_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ亢"))
		if   l1ll111111ll_l1_==l1l1ll_l1_ (u"࠭ࠧ亣"): choice = 0
		elif l1ll111111ll_l1_==l1l1ll_l1_ (u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪ交"): choice = 1
		elif l1ll111111ll_l1_==l1l1ll_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ亥"): choice = 2
		l1l1l1ll1l1l_l1_ = l1ll111111ll_l1_
	if   choice==0: l1l1l1l11111_l1_ = l1l1ll_l1_ (u"ࠩ࠸࠹࠱࠻࠴࠵࠮࠸࠹࠺࠭亦")
	elif choice==1: l1l1l1l11111_l1_ = l1l1ll_l1_ (u"ࠪ࠹࠹࠺ࠬ࠶࠷࠸࠰࠺࠻ࠧ产")
	elif choice==2: l1l1l1l11111_l1_ = l1l1ll_l1_ (u"ࠫ࠺࠻࠵࠭࠷࠸࠰࠺࠺࠴ࠨ亨")
	else: return
	settings.setSetting(l1l1ll_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ亩"),l1l1l1ll1l1l_l1_)
	l1l11lll111l_l1_ = l1l1ll_l1_ (u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠧ亪")+l1l1l1l11111_l1_+l1l1ll_l1_ (u"ࠧ࠭ࠩ享")+l1ll111lll11_l1_+l1l1ll_l1_ (u"ࠨ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪ京")
	newFILE = oldFILE.replace(l1l1llllllll_l1_,l1l11lll111l_l1_)
	if kodi_version>18.99: newFILE = newFILE.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ亭"))
	open(l1l1lll1l1l1_l1_,l1l1ll_l1_ (u"ࠪࡻࡧ࠭亮")).write(newFILE)
	LOG_THIS(l1l1ll_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ亯"),l1l1ll_l1_ (u"ࠬ࠴ࠠࠡࠢࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫ亰")+l1l1l1l11111_l1_+l1l1ll_l1_ (u"࠭ࠠ࡞ࠩ亱"))
	#time.sleep(2)
	if showDialogs: xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭亲"))
	return
def l1l11ll1l1ll_l1_():
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࠩ亳"),l1l1ll_l1_ (u"ࠩๆ่ฬ࠭亴"),l1l1ll_l1_ (u"๊ࠪ฾๋ࠧ亵"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ亶"),l1l1ll_l1_ (u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡมࠪ亷"))
	if yes==1: l1l1ll111l1l_l1_()
	return
def l1l1l11l1ll1_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ亸"),l1l1ll_l1_ (u"ࠧࠨ亹"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ人"),l1l1ll_l1_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤ๊์ࠠศๆู่ิื้ࠠ฼ํีู๋ࠥา๊ไࠤ๊ะ๊ࠡ์ิะ฾ࠦไๅ฻่่ࠬ亻"))
	return
def l1l1ll1l11l1_l1_():
	l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ亼")
	l1ll1l11l11_l1_ += l1l1ll_l1_ (u"ࠫฬ๊ๅ้ไ฼ࠤศีๆศ้ࠣๅ๏ํࠠฦฯุหห๐ษࠡๆ฼ำิࠦวๅึํ฽ฮࠦแ๋ࠢส่฾อไๆࠢอ้ࠥาๅฺ้สࠤ๊์ࠠอ็ํ฽ࠥอไๆืสำึࠦวๅ็อ์ๆืษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅไา๎๊ฯ้ࠠษ็ะิ๐ฯสࠢส่า้่ๆ์ฬࠤํอไ฻์ิࠤา้่ๆ์ฬࠤํ๋ๆࠡฮ่๎฾ࠦฯ้ๆࠣห้฿วๅ็ࠣฯ๊ࠦสๆࠢอ์า๐ฯ่ษࠣ์าูวษࠢส่๊฿ฯๅࠢะือࠦำไษ้ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡๆึ๊ฮࠦ࠲࠱࠴࠴ࠤํํ๊ࠡษ็ษา฻วว์ฬࠤฬ๊รฮัฮࠤํอไฤึ่่ࠥอไห์ࠣฮู๊ࠦๆๆ๊หࠥ็๊ࠡษ็ื๋๎วหࠢส่฾ฺัสࠢส่๊อึ๋หࠪ亽")
	l1ll1l11l11_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡸ࡮ࡩࡢࡥࡲࡹࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ亾")
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞สิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ亿")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"่๊ࠧࠣ฽ออัสࠢ฼๊ࠥฮั็ษ่ะࠥ๐่โำ้ࠣ฾๊่ๆษอࠤาูวษ์ฬࠤ่ั๊าหࠣฮ์๋ࠠอ็ํ฽ࠥอไๆี็้๏์ࠠๆอ็ࠤศ๎โศฬࠣห้฻ไศหࠣ์ศ๎โศฬࠣห้้ำ้ใࠣ์ฬ๊ฮิ๊ไࠤํฺใๅࠢส่็๋ั๊ࠡฦ์็อสࠡษ็ๆ๊ื้ࠠลํฺฬ๊้ࠦใิࠤึส๊สࠢส่์๊วๅࠢไ๎ࠥาๅ๋฻ࠣำํ๊ࠠศๆ฼ห้๋้ࠠลํฺฬࠦแ๋้ࠣฮ็๎๊ๆ่ࠢ๎้อฯ๋๋๋ࠢัื๊๊ࠡไ๎์ࠦรุ๋สࠤอำห๊ࠡๅีฬวษࠡษ็ๆึศๆ๊ࠡฦ๎฻อࠠโ์๊ࠤฬูสฯษิอࠥ๎สโษว่ࠥ๎แ๋้ࠣว็๎วๅุ่๊ࠢ๎ศสࠢ็่ศ๋วๆࠢ฼่๏่ࠦฤ็๋ีࠥษฮา๋ࠣฮ์๋ࠠไๆุ้๊ࠣๅࠡ࠰ࠣห้ฮั็ษ่ะ๋ࠥให๊หࠤอฺ๊สࠢฯหๆอࠠิๅิฬฯ่๋ࠦีอาิ๋ࠠ็ฺส้ࠥ๎๊็ั๋ึࠥะอหࠢห๎หฯ้ࠠ์้ำํุࠠไษฯ๎ฯ่ࠦๆะุูࠥ็โุࠢ็วัําสࠢส่ํ๐ๆะ๊ีࠤ࠳ࠦวๅ็๋ๆ฾ࠦวๅำึ้๏ࠦไๅสิ๊ฬ๋ฬ้๋ࠡࠫ什")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡮ࡷࡶࡰ࡮ࡳࡲࡶ࡮ࡨࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭仁")
	message = l1l1ll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ仂")+l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰ࡞ࡖ࡙ࡒ࡝ࠨ仃")+l1ll1l11l1l_l1_
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ仄"),l1l1ll_l1_ (u"ࠬ࠭仅"),message)
	return
def l1l1l1lll1l1_l1_():
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ仆"),l1l1ll_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ仇"))
	l1l1lll1l111_l1_ = l1l1llll1ll1_l1_()
	if not l1l1lll1l111_l1_: return
	id,l1l1ll111111_l1_,l1l1l1l1l1ll_l1_,answer,l1l11l1l11ll_l1_,reason = l1l1lll1l111_l1_[0]
	l1l1l11l1l1l_l1_,l1ll11111l1l_l1_ = answer.split(l1l1ll_l1_ (u"ࠨ࡞ࡱ࠿ࡀ࠭仈"))
	l1ll1l11l1l_l1_,l1111l1ll1l_l1_,l1111l1lll1_l1_ = l1l11l1l11ll_l1_.split(l1l1ll_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ仉"))
	l1ll1111l1ll_l1_ = l1l11l1l1l11_l1_
	stay = True
	while stay:
		l1l1l11ll11l_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࠫ今"),l1l1ll_l1_ (u"้๊ࠫวฺฬิห฻࠭介"),l1l1ll_l1_ (u"๊ࠬไฤูไห้࠭仌"),l1l1ll_l1_ (u"࠭ฮา๊ฯࠫ仍"),l1l1ll_l1_ (u"ࠧๅวํๆฬ็ࠠศๆศ฽้อๆศฬࠣๆ๊ࠦศๆีะࠤอืๆศ็ฯࠤ฾๋วะ่๊ࠢࠥา็ศิๆࠫ从"),l1ll1l11l1l_l1_)
		if l1l1l11ll11l_l1_==0:
			yes = DIALOG_OK(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ仏"),l1l1ll_l1_ (u"ࠩ฼์ิฯࠧ仐"),l1l1ll_l1_ (u"ࠪห้อูหำสฺࠥ฿ไ๊่ࠢฬิษࠠศๆศ฽้อๆศฬࠣ฾๏ืࠠใษห่๊ࠥไ็ไสุࠬ仑"),l1111l1ll1l_l1_)
			#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ仒"),l1l1ll_l1_ (u"ࠬ฿่ะหࠪ仓"),l1l1ll_l1_ (u"࠭สุ้ํัࠬ仔"),l1l1ll_l1_ (u"ࠧศๆส฽ฯืวืࠢ฼่๎ࠦๅษัฦࠤฬ๊ลฺๆส๊ฬะࠠ฻์ิࠤ็อศๅࠢ็่๋่วีࠩ仕"),l1111l1ll1l_l1_)
			#if yes: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ他"),l1l1ll_l1_ (u"ࠩ฼์ิฯࠧ仗"),l1l1ll_l1_ (u"้้ࠪออูษอࠫ付"),l1111l1lll1_l1_)
		if l1l1l11ll11l_l1_==1: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ仙"),l1ll1111l1ll_l1_,l1ll1111l1ll_l1_,l1l1ll_l1_ (u"ࠬอำหะา้ࠥํะศࠢส่ืืࠠๅๆัีําࠠๆ่ࠣหู้ฤศๆࠣฬิ๎ๆࠡวฯหอฯࠠศๆึศฬ๊࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠวํࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ษึฮำีๅ่ࠢ็็๏ࠦสฺำไࠤฬ๊ฬ้ษหࠤฬ๊ีฮ์ะࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ仚")+l1ll1111l1ll_l1_+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ仛"))
		if l1l1l11ll11l_l1_==2: stay = False
	return
def l1l1lllll11l_l1_():
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ仜"),l1l1ll_l1_ (u"ࠨࠩ仝"),l1l1ll_l1_ (u"ࠩࠪ仞"),l1l1ll_l1_ (u"ࠪืษอไࠨ仟"),l1l1ll_l1_ (u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬ仠"))
	if yes==1:
		succeeded = True
		if os.path.exists(l1l11ll1lll1_l1_):
			try: os.remove(l1l11ll1lll1_l1_)
			except: succeeded = False
		if succeeded: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭仡"),l1l1ll_l1_ (u"࠭ࠧ仢"),l1l1ll_l1_ (u"ࠧࠨ代"),l1l1ll_l1_ (u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ令"))
		else: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ以"),l1l1ll_l1_ (u"ࠪࠫ仦"),l1l1ll_l1_ (u"ࠫࠬ仧"),l1l1ll_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬ仨"))
	return
def l1l1ll111ll1_l1_():
	l1l1l1l111l1_l1_()
	l1ll1111llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ仩"))
	message = {}
	message[l1l1ll_l1_ (u"ࠧࡂࡗࡗࡓࠬ仪")] = l1l1ll_l1_ (u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ仫")
	message[l1l1ll_l1_ (u"ࠩࡖࡘࡔࡖࠧ们")] = l1l1ll_l1_ (u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ仭")
	message[l1l1ll_l1_ (u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ仮")] = l1l1ll_l1_ (u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭仯")+str(LIMITED_CACHE/60)+l1l1ll_l1_ (u"࠭ࠠะไํๆฮࠦแใูࠪ仰")
	l1l1l1111l11_l1_ = message[l1ll1111llll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠧࠨ仱"),l1l1ll_l1_ (u"ࠨๅสุࠥ࠭仲")+str(LIMITED_CACHE/60)+l1l1ll_l1_ (u"ࠩࠣำ็๐โสࠩ仳"),l1l1ll_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ仴"),l1l1ll_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ仵"),l1l1l1111l11_l1_,l1l1ll_l1_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨ件"))
	if choice==0: l1l1l111111l_l1_ = l1l1ll_l1_ (u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ价")
	elif choice==1: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠧࡂࡗࡗࡓࠬ仸")
	elif choice==2: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠨࡕࡗࡓࡕ࠭仹")
	else: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠩࠪ仺")
	if l1l1l111111l_l1_:
		settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ任"),l1l1l111111l_l1_)
		l1l11lll1ll1_l1_ = message[l1l1l111111l_l1_]
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ仼"),l1l1ll_l1_ (u"ࠬ࠭份"),l1l1ll_l1_ (u"࠭ࠧ仾"),l1l11lll1ll1_l1_)
	return
def l1l1l11l111l_l1_():
	message = {}
	message[l1l1ll_l1_ (u"ࠧࡂࡗࡗࡓࠬ仿")] = l1l1ll_l1_ (u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭伀")
	message[l1l1ll_l1_ (u"ࠩࡄࡗࡐ࠭企")] = l1l1ll_l1_ (u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ伂")
	message[l1l1ll_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ伃")] = l1l1ll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ伄")
	l1l1lll1llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡦࡴࡹࡩࡷ࠭伅"))
	l1ll1111llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ伆"))
	l1l1l1111l11_l1_ = message[l1ll1111llll_l1_]+l1l1lll1llll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠨࠩ伇"),l1l1ll_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ伈"),l1l1ll_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ伉"),l1l1ll_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ伊"),l1l1l1111l11_l1_,l1l1ll_l1_ (u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩ伋"))
	if choice==0: l1l1l111111l_l1_ = l1l1ll_l1_ (u"࠭ࡁࡔࡍࠪ伌")
	elif choice==1: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠧࡂࡗࡗࡓࠬ伍")
	elif choice==2: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠨࡕࡗࡓࡕ࠭伎")
	if choice in [0,1]:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ伏"),l1l1ll_l1_ (u"ࠪื๏ืแา࠼ࠣࠫ伐")+l1l11l111l11_l1_[1],l1l1ll_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ休")+l1l11l111l11_l1_[0],l1l1ll_l1_ (u"ࠬ࠭伒"),l1l1ll_l1_ (u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ伓"))
		if yes==1: newserver = l1l11l111l11_l1_[0]
		else: newserver = l1l11l111l11_l1_[1]
	elif choice==2: newserver = l1l1ll_l1_ (u"ࠧࠨ伔")
	else: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠨࠩ伕")
	if l1l1l111111l_l1_:
		settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳ࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ伖"),l1l1l111111l_l1_)
		settings.setSetting(l1l1ll_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ众"),newserver)
		l1l11lll1ll1_l1_ = message[l1l1l111111l_l1_]+newserver
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ优"),l1l1ll_l1_ (u"ࠬ࠭伙"),l1l1ll_l1_ (u"࠭ࠧ会"),l1l11lll1ll1_l1_)
	return
def l1l1l1l1lll1_l1_():
	l1ll1111llll_l1_ = settings.getSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ伛"))
	message = {}
	message[l1l1ll_l1_ (u"ࠨࡃࡘࡘࡔ࠭伜")] = l1l1ll_l1_ (u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪ伝")
	message[l1l1ll_l1_ (u"ࠪࡅࡘࡑࠧ伞")] = l1l1ll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ伟")
	message[l1l1ll_l1_ (u"࡙ࠬࡔࡐࡒࠪ传")] = l1l1ll_l1_ (u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ伡")
	l1l1l1111l11_l1_ = message[l1ll1111llll_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠧࠨ伢"),l1l1ll_l1_ (u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭伣"),l1l1ll_l1_ (u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ伤"),l1l1ll_l1_ (u"ࠪษ๏่วโࠢๆห๊๊ࠧ伥"),l1l1l1111l11_l1_,l1l1ll_l1_ (u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧ伦"))
	if choice==0: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠬࡇࡓࡌࠩ伧")
	elif choice==1: l1l1l111111l_l1_ = l1l1ll_l1_ (u"࠭ࡁࡖࡖࡒࠫ伨")
	elif choice==2: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠧࡔࡖࡒࡔࠬ伩")
	else: l1l1l111111l_l1_ = l1l1ll_l1_ (u"ࠨࠩ伪")
	if l1l1l111111l_l1_:
		settings.setSetting(l1l1ll_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ伫"),l1l1l111111l_l1_)
		l1l11lll1ll1_l1_ = message[l1l1l111111l_l1_]
		DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ伬"),l1l1ll_l1_ (u"ࠫࠬ伭"),l1l1ll_l1_ (u"ࠬ࠭伮"),l1l11lll1ll1_l1_)
	return
def l1l1ll1l1111_l1_():
	l1l11ll1ll1l_l1_ = settings.getSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ伯"))
	if l1l11ll1ll1l_l1_==l1l1ll_l1_ (u"ࠧࡔࡖࡒࡔࠬ估"): header = l1l1ll_l1_ (u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧ伱")
	else: header = l1l1ll_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧ伲")
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࠫ伳"),l1l1ll_l1_ (u"ࠫส๐โศใࠪ伴"),l1l1ll_l1_ (u"ࠬะแฺ์็ࠫ伵"),header,l1l1ll_l1_ (u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱ๋้ࠦสา์าࠤฯ็ู๋ๆࠣว๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥลࠡࠢࠩ伶"))
	if yes==-1: return
	elif yes:
		settings.setSetting(l1l1ll_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ伷"),l1l1ll_l1_ (u"ࠨࠩ伸"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ伹"),l1l1ll_l1_ (u"ࠪࠫ伺"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ伻"),l1l1ll_l1_ (u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ似"))
	else:
		settings.setSetting(l1l1ll_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡳࡻࡳࡠࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ伽"),l1l1ll_l1_ (u"ࠧࡔࡖࡒࡔࠬ伾"))
		DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ伿"),l1l1ll_l1_ (u"ࠩࠪ佀"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭佁"),l1l1ll_l1_ (u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭佂"))
	return
def l1l1l1l11l11_l1_(text):
	if text!=l1l1ll_l1_ (u"ࠬ࠭佃"):
		text = l1l1ll11111_l1_(text)
		text = text.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ佄")).encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ佅"))
		l1l1ll111ll_l1_ = 10103
		l1l1ll1111l_l1_ = xbmcgui.l1l1l1ll11l_l1_(l1l1ll111ll_l1_)
		l1l1ll1111l_l1_.getControl(311).l1l1ll11ll1_l1_(text)
		#l1l1l1ll1l11_l1_ = xbmcgui.WindowXMLDialog(l1l1ll_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡌࡧࡼࡦࡴࡧࡲࡥ࠴࠵࠲ࡽࡳ࡬ࠨ但"), xbmcaddon.Addon().getAddonInfo(l1l1ll_l1_ (u"ࠩࡳࡥࡹ࡮ࠧ佇")).decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ佈")),l1l1ll_l1_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ佉"),l1l1ll_l1_ (u"ࠬ࠽࠲࠱ࡲࠪ佊"))
		#l1l1l1ll1l11_l1_.show()
		#l1l1l1ll1l11_l1_.getControl(99991).setPosition(0,0)
		#l1l1l1ll1l11_l1_.getControl(311).l1l1ll11ll1_l1_(text)
		#l1l1l1ll1l11_l1_.getControl(5).l1l11l11l1ll_l1_(l1l1lll1l1ll_l1_)
		#width = xbmcgui.l1l1ll1l1l1l_l1_()
		#height = xbmcgui.l1l1l1lllll1_l1_()
		#resolution = (0.0+width)/height
		#l1l1l1ll1l11_l1_.getControl(5).l1l1ll1l1ll1_l1_(width-180)
		#l1l1l1ll1l11_l1_.getControl(5).setHeight(height-180)
		#l1l1l1ll1l11_l1_.doModal()
		#del l1l1l1ll1l11_l1_
	return
l1l11ll11ll1_l1_ = [
			 l1l1ll_l1_ (u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࠪࠫࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦ佋")
			,l1l1ll_l1_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪ佌")
			,l1l1ll_l1_ (u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪ位")
			,l1l1ll_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼࠫ低")
			,l1l1ll_l1_ (u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫ住")
			,l1l1ll_l1_ (u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭佐")
			,l1l1ll_l1_ (u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠧࡸࡹ࡬࠮ࡹࡤࡶࡳ࡯࡮ࡨࡵࠪ佑")
			,l1l1ll_l1_ (u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩ佒")
			,l1l1ll_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫࠽࠱ࠨࡷࡩࡽࡺ࠽ࠨ体")
			,l1l1ll_l1_ (u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩ佔")
			,l1l1ll_l1_ (u"ࠩࡡࡢࡣࡤ࡞ࠨ何")
			]
def l1l1l11l1l11_l1_(line):
	if l1l1ll_l1_ (u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨ佖") in line and l1l1ll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ佗") in line: return True
	for text in l1l11ll11ll1_l1_:
		if text in line: return True
	return False
def l1l11l11ll1l_l1_(data):
	data = data.replace(l1l1ll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ佘")+l1l1ll_l1_ (u"࠭ࠠࠨ余")*51+l1l1ll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ佚"),l1l1ll_l1_ (u"ࠨ࡞ࡵࡠࡳ࠭佛"))
	data = data.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ作")+l1l1ll_l1_ (u"ࠪࠤࠬ佝")*51+l1l1ll_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ佞"),l1l1ll_l1_ (u"ࠬࡢࡲ࡝ࡰࠪ佟"))
	data = data.replace(l1l1ll_l1_ (u"࠭࡜࡯ࠩ你")+l1l1ll_l1_ (u"ࠧࠡࠩ佡")*51+l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ佢"),l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ佣"))
	#data = data.replace(l1l1ll_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢ࠰ࡵࡷࡳࡷࡧࡧࡦ࠱ࡨࡱࡺࡲࡡࡵࡧࡧ࠳࠵࠵ࡁ࡯ࡦࡵࡳ࡮ࡪ࠯ࡥࡣࡷࡥ࠴ࡵࡲࡨ࠰ࡻࡦࡲࡩ࠮࡬ࡱࡧ࡭࠴࡬ࡩ࡭ࡧࡶ࠳࠳ࡱ࡯ࡥ࡫࠲ࡥࡩࡪ࡯࡯ࡵ࠲ࠫ佤"),l1l1ll_l1_ (u"ࠫࠥࠦࠠࠡࠢࡉ࡭ࡱ࡫ࠠࠣࠩ佥"))
	data = data.replace(l1l1ll_l1_ (u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫ佦"),l1l1ll_l1_ (u"࠭࠺ࠡࠩ佧"))
	data2 = l1l1ll_l1_ (u"ࠧࠨ佨")
	for line in data.splitlines():
		delete = re.findall(l1l1ll_l1_ (u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ佩"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l1l1ll_l1_ (u"ࠩࠪ佪"))
		data2 += l1l1ll_l1_ (u"ࠪࡠࡳ࠭佫")+line
	#WRITE_THIS(l1l1ll_l1_ (u"ࠫࠬ佬"),data2)
	return data2
def l1l11ll11111_l1_(l1l1l1ll1ll1_l1_):
	if l1l1ll_l1_ (u"ࠬࡕࡌࡅࠩ佭") in l1l1l1ll1ll1_l1_:
		l1l1llll1111_l1_ = l1l11l1ll11l_l1_
		header = l1l1ll_l1_ (u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊โะ์่ࠤฤ࠭佮")
	else:
		l1l1llll1111_l1_ = l1l1lllll111_l1_
		header = l1l1ll_l1_ (u"ࠧใำสลฮࠦวๅีฯ่ࠥอไฮษ็๎ࠥลࠧ佯")
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࠩ佰"),l1l1ll_l1_ (u"ࠩࠪ佱"),l1l1ll_l1_ (u"ࠪࠫ佲"),header,l1l1ll_l1_ (u"ุࠫาไࠡษ็วำ฽วยࠢํัฯ๎๊ࠡลํฺฬูࠦๅ๋ࠣืั๊ࠠศๆสืฯิฯศ็ࠣ࠲ࠥ๎วๅษฮ๊๏์ࠠืำ๋ี๏ฯࠠๅ็฼ีๆฯࠠไ์ไࠤาีหหࠢสฺ่๊ใๅหࠣ์๊อ่๊ࠠࠣห้๋ใศ่ࠣห้ึ๊ࠡีหฬࠥำฯ้อࠣห้๋ิไๆฬࠤ࠳ࠦใ้ัํࠤ๏ำสโฺࠣฬุาไ๋่ࠣ࠲ࠥอไฤ๊็ࠤ์๎ࠠศๆึะ้ࠦวๅฯส่๏่ࠦโ์๊ࠤ๊฿ไ้็สฮࠥะศะล้๋ࠣึࠠษัส๎ฮࠦวๅฬื฾๏๊ࠠศๆะห้๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦศๆ์ࠤฬ๊ย็ࠢ࠱ࠤศ๋วࠡษ็ืั๊ࠠศๆๅำ๏๋ࠠโ้๋ࠤฬ๊ำอๆࠣหู้วษไࠣห้ึ๊ࠡฬ่ࠤัู๋่่๊ࠢࠥฮั็ษ่ะ้่ࠥะ์ࠣๆอ๊ࠠระิࠤส฽แศร่ࠣ์ࠦ࠮้ࠡ็ࠤฯื๊ะࠢส่ฬูสๆำสีࠥลࠧ佳"))
	if yes!=1: return
	l1l11l1l11l1_l1_,counts = [],0
	size = os.path.getsize(l1l1llll1111_l1_)
	file = open(l1l1llll1111_l1_,l1l1ll_l1_ (u"ࠬࡸࡢࠨ佴"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ併"))
	data = l1l11l11ll1l_l1_(data)
	lines = data.split(l1l1ll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ佶"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭佷"))
		#if line.strip(l1l1ll_l1_ (u"ࠩࠣࠫ佸"))==l1l1ll_l1_ (u"ࠪࠫ佹"): continue
		ignore = l1l1l11l1l11_l1_(line)
		if ignore: continue
		line = line.replace(l1l1ll_l1_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡢࠫ佺"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭佻"))
		line = line.replace(l1l1ll_l1_ (u"࠭ࡅࡓࡔࡒࡖ࠿࠭佼"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊ࠵࠶࠰࠱࡟ࡈࡖࡗࡕࡒ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ佽"))
		l1l11ll11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡠࠫࡠࡩ࠱࠭ࠪࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ佾"),line,re.DOTALL)
		l1l1l1lll11l_l1_ = l1l1ll_l1_ (u"ࠩࠪ使")
		if l1l11ll11l1l_l1_:
			line = line.replace(l1l11ll11l1l_l1_[0][0],l1l1ll_l1_ (u"ࠪࠫ侀")).replace(l1l11ll11l1l_l1_[0][2],l1l1ll_l1_ (u"ࠫࠬ侁"))
			l1l1l1lll11l_l1_ = l1l11ll11l1l_l1_[0][1]
		else:
			l1l11ll11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ侂"),line,re.DOTALL)
			if l1l11ll11l1l_l1_:
				line = line.replace(l1l11ll11l1l_l1_[0][1],l1l1ll_l1_ (u"࠭ࠧ侃"))
				l1l1l1lll11l_l1_ = l1l11ll11l1l_l1_[0][0]
		if l1l1l1lll11l_l1_: line = line.replace(l1l1l1lll11l_l1_,l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ侄")+l1l1l1lll11l_l1_+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ侅"))
		l1l11l1l11l1_l1_.append(line)
		if len(str(l1l11l1l11l1_l1_))>50100: break
	l1l11l1l11l1_l1_ = reversed(l1l11l1l11l1_l1_)
	l1l1lll1l1ll_l1_ = l1l1ll_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ來").join(l1l11l1l11l1_l1_)
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ侇"),l1l1ll_l1_ (u"ࠫวิัࠡลึ฻ึࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠨ侈"),l1l1lll1l1ll_l1_,l1l1ll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡴ࡯ࡤࡰࡱ࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ侉"))
	return
def l1l11ll11l11_l1_():
	l1l1llll111l_l1_ = open(l1l1l1lll1ll_l1_,l1l1ll_l1_ (u"࠭ࡲࡣࠩ侊")).read()
	if kodi_version>18.99: l1l1llll111l_l1_ = l1l1llll111l_l1_.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ例"))
	l1l1llll111l_l1_ = l1l1llll111l_l1_.replace(l1l1ll_l1_ (u"ࠨ࡞ࡷࠫ侌"),l1l1ll_l1_ (u"ࠩࠣࠤࠥࠦࠠࠡࠢࠣࠫ侍"))
	l1ll1l11l1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬࡻࡢࡤ࠯ࠬࡂ࠭ࡠࡢ࡮࡝ࡴࡠࠫ侎"),l1l1llll111l_l1_,re.DOTALL)
	for line in l1ll1l11l1l1_l1_:
		l1l1llll111l_l1_ = l1l1llll111l_l1_.replace(line,l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ侏")+line+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ侐"))
	DIALOG_TEXTVIEWER(l1l1ll_l1_ (u"࠭วๅฬ฽๎๏ืวหࠢส่ศิ๊าหࠣๅ๏ࠦวๅสิห๊าࠧ侑"),l1l1llll111l_l1_)
	return
def l1l1ll11llll_l1_():
	l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠧษ฻ูࠤฬ๊รำำสีࠥ฿ไ๊ࠢส่ึ๐ๅ้ฬࠣ็ํ์สา๊็ࠤฯ๎แาࠢศ้่อๆ๋หࠣฮ็ี๊ๆ๋ࠢฮศิ๊าࠢส่ๆ๐ฯ๋๊ࠣ์์ึ็ࠡษ็วืืวา๊ࠢ๎ࠥอไฤี๊้ࠥ๎วๅลิๆฬ๋ࠠๆ฻ࠣฬ฾฼้ࠠๅส่ฯอไ๋ࠩ侒")
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠨๆอๆิ๐ๅࠡษ็ๅ๏ี๊้ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎๊๐ๆ๊ࠡ็ฮศิ๊า้ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏ูวาࠢ࠱ࠤศ๋วࠡ฻าอࠥอำ่็้ࠣฯะวๅ์ฬࠤๆํะ่ࠢอๆํ๋ࠠษฬะี๏้ࠠศๆไ๎ิ๐่ࠡส๋ๆฯࠦวไสิࠤ๊์้ࠠไอࠤฬ๊ำ่็ࠣห้๎วฮัࠣ࠲ࠥษๅศࠢสุ่ํๅࠡษ็ว฾๊้๊ࠡส่ศูแๅࠢไ๋ํ๊ࠦฮำๆࠤฬ๊แ๋ัํ์ࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวย๋่่ࠢ์ࠠษไไึฮࠦใษ์ิอࠬ侓")
	l1111l1ll1l_l1_ = l1l1ll_l1_ (u"ࠩฦ้ฬࠦวๅลิๆฬ๋ࠠโ้ํࠤฯูสฯั่ࠤ้๊สใัํ้ࠥ๎วๅฬฦา๏ื้ࠠๆๆ๊ࠥฮๅใัสีࠥ฿ฯะࠢส่ะ๎ว็์ࠣ์ฬ๊ฯใษษๆࠥ࠴ࠠๆอ็หࠥืโๆࠢ࠸࠸࠹ࠦสฺ่ํࠤ࠺ࠦฯใษษๆࠥ๎ࠠ࠵࠶ࠣฯฬ์๊สࠢศ่๎ࠦวๅล่ห๊ࠦร้ࠢศ่๎ࠦวๅ๊ิหฦࠦศฮีหࠤฬูสฯัส้่ࠦไๅี๊้ࠥอไ๋็ํ๊ࠥษ่ࠡี๊้ࠥอไ๋ีสีࠬ侔")
	message = l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠪ࠾ࠥ࠭侕")+l1ll1l11l1l_l1_+l1l1ll_l1_ (u"ࠫࠥ࠴ࠠࠨ侖")+l1111l1ll1l_l1_
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ侗"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ侘"),message,l1l1ll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ侙"))
	return
def l111lll1ll1_l1_(l1llll1l1111_l1_,message,showDialogs=True,url=l1l1ll_l1_ (u"ࠨࠩ侚"),source=l1l1ll_l1_ (u"ࠩࠪ供"),text=l1l1ll_l1_ (u"ࠪࠫ侜"),l111ll11l1l_l1_=l1l1ll_l1_ (u"ࠫࠬ依")):
	if l1l1ll_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ侞") in text: l1ll1l111l11_l1_ = True
	else: l1ll1l111l11_l1_ = False
	l1l11l111lll_l1_ = True
	if not l1l1l111lll1_l1_(l1l1ll_l1_ (u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ侟")):
		if showDialogs:
			#if message.count(l1l1ll_l1_ (u"ࠧ࡝࡞ࡱࠫ侠"))>1: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ価")
			#else: l1l11lll11l1_l1_ = l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ侢")
			l1l11ll1llll_l1_ = (l1l1ll_l1_ (u"ࠪหู้ืา࠼ࠪ侣") in message and l1l1ll_l1_ (u"ࠫฬ๊ๅไษ้࠾ࠬ侤") in message and l1l1ll_l1_ (u"ࠬอไๆๆไ࠾ࠬ侥") in message and l1l1ll_l1_ (u"࠭วๅะฺวࠬ侦") in message and l1l1ll_l1_ (u"ࠧศๆู่ิื࠺ࠨ侧") in message)
			if not l1l11ll1llll_l1_: l1l11l111lll_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ侨"),l1l1ll_l1_ (u"ࠩࠪ侩"),l1l1ll_l1_ (u"ࠪࠫ侪"),l1l1ll_l1_ (u"ࠫ์๊ࠠหำึ่ࠥํะ่ࠢส่ึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ侫"),message.replace(l1l1ll_l1_ (u"ࠬࡢ࡜࡯ࠩ侬"),l1l1ll_l1_ (u"࠭࡜࡯ࠩ侭")))
	elif showDialogs:
		message = l1l1ll_l1_ (u"ࠧ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࡠࡡࡴสๆ่ࠢืาࠦวๅำึห้ฯࠧ侮")
		l1ll111l11l1_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ侯"),l1l1ll_l1_ (u"ࠩࠪ侰"),l1l1ll_l1_ (u"ࠪࠫ侱"),l1l1ll_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ侲")+l1l1ll_l1_ (u"ࠬࠦࠠ࠲࠱࠸ࠫ侳"),l1l1ll_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ侴"))
		l1ll111l111l_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ侵"),l1l1ll_l1_ (u"ࠨࠩ侶"),l1l1ll_l1_ (u"ࠩࠪ侷"),l1l1ll_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ侸")+l1l1ll_l1_ (u"ࠫࠥࠦ࠲࠰࠷ࠪ侹"),l1l1ll_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ侺"))
		l1ll111l1111_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭侻"),l1l1ll_l1_ (u"ࠧࠨ侼"),l1l1ll_l1_ (u"ࠨࠩ侽"),l1l1ll_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ侾")+l1l1ll_l1_ (u"ࠪࠤࠥ࠹࠯࠶ࠩ便"),l1l1ll_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ俀"))
		l1ll111l1ll1_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ俁"),l1l1ll_l1_ (u"࠭ࠧ係"),l1l1ll_l1_ (u"ࠧࠨ促"),l1l1ll_l1_ (u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ俄")+l1l1ll_l1_ (u"ࠩࠣࠤ࠹࠵࠵ࠨ俅"),l1l1ll_l1_ (u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ俆"))
		l1l11l111lll_l1_ = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ俇"),l1l1ll_l1_ (u"ࠬ࠭俈"),l1l1ll_l1_ (u"࠭ࠧ俉"),l1l1ll_l1_ (u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ俊")+l1l1ll_l1_ (u"ࠨࠢࠣ࠹࠴࠻ࠧ俋"),l1l1ll_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ俌"))
	if l1l11l111lll_l1_!=1:
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ俍"),l1l1ll_l1_ (u"ࠫࠬ俎"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ俏"),l1l1ll_l1_ (u"࠭สๆࠢศ่฿อมࠡษ็ษึูวๅࠢห๊ฬวฺࠠๆ์ࠤ฼๊ศไࠩ俐"))
		return False
	l1ll111l1lll_l1_ = xbmc.getInfoLabel( l1l1ll_l1_ (u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪࠨ俑") )
	message += l1l1ll_l1_ (u"ࠨࠢ࡟ࡠࡳࡢ࡜࡯࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾ࠢ࡟ࡠࡳࡇࡤࡥࡱࡱࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿ࠦࠧ俒")+addon_version+l1l1ll_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࠨ俓")
	message += l1l1ll_l1_ (u"ࠪࡉࡲࡧࡩ࡭ࠢࡖࡩࡳࡪࡥࡳ࠼ࠣࠫ俔")+l1l1l1l1l1l_l1_(32)+l1l1ll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡎࡳࡩ࡯ࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪ俕")+l1l1l1lll111_l1_+l1l1ll_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࠫ俖")
	message += l1l1ll_l1_ (u"࠭ࡋࡰࡦ࡬ࠤࡓࡧ࡭ࡦ࠼ࠣࠫ俗")+l1ll111l1lll_l1_
	#l1ll1111l11l_l1_ = l1l11lll1111_l1_(l1l1ll_l1_ (u"ࠧ࠸࠸࠱࠺࠺࠴࠱࠴࠺࠱࠶࠸࠶ࠧ俘"))
	l1ll1111l11l_l1_ = l1l11lll1111_l1_()
	l1ll1111l11l_l1_ = QUOTE(l1ll1111l11l_l1_)
	if l1ll1111l11l_l1_: message += l1l1ll_l1_ (u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪ俙")+l1ll1111l11l_l1_
	if url: message += l1l1ll_l1_ (u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭俚")+url
	if source: message += l1l1ll_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪ俛")+source
	message += l1l1ll_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ俜")
	if showDialogs: DIALOG_NOTIFICATION(l1l1ll_l1_ (u"ࠬาวา์ࠣห้หัิษ็ࠫ保"),l1l1ll_l1_ (u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨ俞"))
	if l111ll11l1l_l1_:
		l1l1lll1l1ll_l1_ = l111ll11l1l_l1_
		if kodi_version>18.99: l1l1lll1l1ll_l1_ = l1l1lll1l1ll_l1_.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ俟"))
		l1l1lll1l1ll_l1_ = base64.b64encode(l1l1lll1l1ll_l1_)
	elif l1ll1l111l11_l1_:
		if l1l1ll_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ俠") in text: l1ll1111ll1l_l1_ = l1l11l1ll11l_l1_
		else: l1ll1111ll1l_l1_ = l1l1lllll111_l1_
		if not os.path.exists(l1ll1111ll1l_l1_):
			DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ信"),l1l1ll_l1_ (u"ࠪࠫ俢"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ俣"),l1l1ll_l1_ (u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪ俤"))
			return False
		l1l11l1l11l1_l1_,counts = [],0
		size = os.path.getsize(l1ll1111ll1l_l1_)
		file = open(l1ll1111ll1l_l1_,l1l1ll_l1_ (u"࠭ࡲࡣࠩ俥"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ俦"))
		data = l1l11l11ll1l_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭俧"))
			ignore = l1l1l11l1l11_l1_(line)
			if ignore: continue
			l1l11ll11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡡࠬࡡࡪࠫ࠮ࠫࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩ俨"),line,re.DOTALL)
			if l1l11ll11l1l_l1_:
				line = line.replace(l1l11ll11l1l_l1_[0][0],l1l1ll_l1_ (u"ࠪࠫ俩")).replace(l1l11ll11l1l_l1_[0][2],l1l1ll_l1_ (u"ࠫࠬ俪"))
			else:
				l1l11ll11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡤࠨ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࡚࠭ࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬ俫"),line,re.DOTALL)
				if l1l11ll11l1l_l1_: line = line.replace(l1l11ll11l1l_l1_[0][1],l1l1ll_l1_ (u"࠭ࠧ俬"))
			l1l11l1l11l1_l1_.append(line)
			if len(str(l1l11l1l11l1_l1_))>121000: break
		l1l11l1l11l1_l1_ = reversed(l1l11l1l11l1_l1_)
		l1l1lll1l1ll_l1_ = l1l1ll_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ俭").join(l1l11l1l11l1_l1_)
		l1l1lll1l1ll_l1_ = l1l1lll1l1ll_l1_.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭修"))
		l1l1lll1l1ll_l1_ = base64.b64encode(l1l1lll1l1ll_l1_)
	else: l1l1lll1l1ll_l1_ = l1l1ll_l1_ (u"ࠩࠪ俯")
	url = WEBSITES[l1l1ll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ俰")][2]
	payload = {l1l1ll_l1_ (u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬ俱"):l1llll1l1111_l1_,l1l1ll_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭俲"):message,l1l1ll_l1_ (u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧ俳"):l1l1lll1l1ll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠧࡑࡑࡖࡘࠬ俴"),url,payload,l1l1ll_l1_ (u"ࠨࠩ俵"),l1l1ll_l1_ (u"ࠩࠪ俶"),l1l1ll_l1_ (u"ࠪࠫ俷"),l1l1ll_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧ俸"))
	#succeeded = response.succeeded
	html = response.content
	if l1l1ll_l1_ (u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧ俹") in html: succeeded = True
	else: succeeded = False
	if showDialogs:
		if succeeded:
			DIALOG_NOTIFICATION(l1l1ll_l1_ (u"࠭สๆࠢส่สืำศๆࠪ俺"),l1l1ll_l1_ (u"ࠧษ่ฯหา࠭俻"))
			DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ俼"),l1l1ll_l1_ (u"ࠩࠪ俽"),l1l1ll_l1_ (u"ࠪࡑࡪࡹࡳࡢࡩࡨࠤࡸ࡫࡮ࡵࠩ俾"),l1l1ll_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦวๅำึห้ฯࠠษ่ฯหา࠭俿"))
		else:
			DIALOG_NOTIFICATION(l1l1ll_l1_ (u"๊ࠬไฤีไࠫ倀"),l1l1ll_l1_ (u"࠭แีๆࠣๅ๏ࠦวๅวิืฬ๊ࠧ倁"))
			DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ倂"),l1l1ll_l1_ (u"ࠨࠩ倃"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ倄"),l1l1ll_l1_ (u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨ倅"))
	return succeeded
def l1l11l11l11l_l1_():
	l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ倆")
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠศๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧ倇")
	DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ倈"),l1l1ll_l1_ (u"ࠧࠨ倉"),l1l1ll_l1_ (u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ倊"),l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ個")+l1ll1l11l1l_l1_)
	l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠪ࠶࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡥࡤࡲࡡ࠭ࡴࠡࡨ࡬ࡲࡩࠦࠢࡂࡴ࡬ࡥࡱࠨࠠࡧࡱࡱࡸࠥࡺࡨࡦࡰࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡴ࡭࡬ࡲࠥࡧ࡮ࡥࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠩ倌")
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠫ࠷࠴ࠠࠡࠢศิฬࠦไๆࠢอะิࠦวๅะฺࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ็โๆࠢหฮ฿๐๊าࠢส่ั๊ฯࠡอ่ࠤ็๋ࠠษฬ฽๎ึࠦวๅะฺࠤฬ๊ๅิฬัำ๊ࠦวๅ๋ࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ倍")
	DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭倎"),l1l1ll_l1_ (u"࠭ࠧ倏"),l1l1ll_l1_ (u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭倐"),l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭們")+l1ll1l11l1l_l1_)
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ倒"),l1l1ll_l1_ (u"ࠪࠫ倓"),l1l1ll_l1_ (u"ࠫࠬ倔"),l1l1ll_l1_ (u"ࠬࡌ࡯࡯ࡶࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬ倕"),l1l1ll_l1_ (u"࠭ࡄࡰࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡳࡵࡷࠡࡁࠪ倖")+l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ倗")+l1l1ll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ีํวษࠢศ่๎ࠦไ้ฯฬࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฦ่ว์ฟࠨ倘"))
	if yes==1: l1l1lll1ll11_l1_()
	return
def l1ll111llll1_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ候"),l1l1ll_l1_ (u"ࠪࠫ倚"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ倛"),l1l1ll_l1_ (u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫ倜"))
	return
def l1l1lllll1ll_l1_():
	message = l1l1ll_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭倝")
	DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ倞"),l1l1ll_l1_ (u"ࠨࠩ借"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ倠"),message)
	return
def l1l1l1l1l1l1_l1_():
	message = l1l1ll_l1_ (u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧ倡")
	DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ倢"),l1l1ll_l1_ (u"ࠬ࠭倣"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ値"),message)
	return
def l1l11l111ll1_l1_():
	message = l1l1ll_l1_ (u"่ࠧ์ࠣื๏ืแาษอࠤ้อ๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢสืฯิฯศ็๊หࠥฮำษสࠣ็ํ์็ศ่ࠢั๊๐ษࠡ็้ࠤฬ๊ๅึัิࠤศ๎ࠠษฯสะฮࠦลๅ๋ࠣหูะัศๅࠣีุ๋๊ࠡล๋ࠤัี๊ะหࠣวํࠦไศࠢํ฽ึ็็ศࠢส่อืๆศ็ฯࠫ倥")
	DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ倦"),l1l1ll_l1_ (u"ࠩࠪ倧"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭倨"),l1l1ll_l1_ (u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭倩"),message)
	return
def l1l1lll1ll1l_l1_():
	message = l1l1ll_l1_ (u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ倪")
	l11llll1l1_l1_(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭倫"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ倬"),message,l1l1ll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ倭"))
	return
def l1l1ll11111l_l1_():
	l1ll1l11l11_l1_ = l1l1ll_l1_ (u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪ倮")
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬ倯")
	l1111l1ll1l_l1_ = l1l1ll_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ倰")
	DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭倱"),l1l1ll_l1_ (u"࠭ࠧ倲"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ倳"),l1ll1l11l11_l1_,l1ll1l11l1l_l1_,l1111l1ll1l_l1_)
	return
def l1l1l1l111l1_l1_():
	l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠨษ็็ฬฺ่๊้ࠠࠣำุๆࠡ็วๆฯࠦไๅ็฼่ํ๋วหࠢํืฯิฯๆ้ࠣห้ฮั็ษ่ะ๊ࠥฮำู่ࠣๆำวหࠢส่ส์สา่ํฮࠥ๎ั้ษห฻ࠥอไโ์า๎ํํวหࠢ็่ํ฻่ๅࠢศ่๏ํวࠡสึี฾ฯ้ࠠสา์๋ࠦล็ฬิ๊๏ะ้ࠠษ็ฬึ์วๆฮࠣ๎ู๊อ่ษࠣฮ้่วว์สࠤอ฿ฯࠡษ้ฮ์อมࠡ฻่ี์อ้ࠠลํฺฬูࠦ็ัࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤ࠳่่ࠦาสࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦำษ฻ฬࠤศ์่ศ฻่ࠣ฾๋ัࠡษ็็ฬฺࠠ࠻ࠩ倴")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ倵") + l1l1ll_l1_ (u"ࠪ࠵࠳ࠦหศสอࠤ้๊ีโฯสฮࠥอไห์้ࠣ฾ื่โࠢฦ๊์อࠠๅษࠣฮฯเ๊า้๋ࠢฬฬ๊ศ๋้ࠢิะ็ࠡࠩ倶") + str(PERMANENT_CACHE/60/60/24/30) + l1l1ll_l1_ (u"ฺࠫࠥ็าࠩ倷")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ倸") + l1l1ll_l1_ (u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ倹") + str(l1ll11ll11l_l1_/60/60/24) + l1l1ll_l1_ (u"ࠧࠡ์๋้ࠬ债")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ倻") + l1l1ll_l1_ (u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭值") + str(l11l1ll_l1_/60/60/24) + l1l1ll_l1_ (u"ࠪࠤ๏๎ๅࠨ倽")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠫࡡࡴࠧ倾") + l1l1ll_l1_ (u"ࠬ࠺࠮ࠡ็อ์ุ฽ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎่ࠥฯࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ倿") + str(REGULAR_CACHE/60/60) + l1l1ll_l1_ (u"࠭ࠠิษ฼อࠬ偀")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ偁") + l1l1ll_l1_ (u"ࠨ࠷࠱ࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦฯศศ่หࠥ๎ๅะฬ๊ࠤࠬ偂") + str(l1llll1l1_l1_/60/60) + l1l1ll_l1_ (u"ࠩࠣืฬ฿ษࠨ偃")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠪࡠࡳ࠭偄") + l1l1ll_l1_ (u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ偅") + str(l11ll1l1l1l_l1_/60) + l1l1ll_l1_ (u"ࠬࠦฯใ์ๅอࠬ偆")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"࠭࡜࡯ࠩ假") + l1l1ll_l1_ (u"ࠧ࠸࠰ࠣฬิ๎ๆࠡๅสุ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣฬุืูส๋้ࠢิะ็ࠡࠩ偈") + str(NO_CACHE) + l1l1ll_l1_ (u"ࠨࠢาๆ๏่ษࠨ偉")
	l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ偊") + l1l1ll_l1_ (u"้ࠪะ๊ว࠻ุࠢๅาอสࠡไ๋หห๋ࠠศๆฦๅ้อๅ๊ࠡสู่๊ไิๆสฮࠥ๎วๅฯ็ๆฬะฺࠠ็ิ๋ฬࠦࠧ偋") + str(REGULAR_CACHE/60/60) + l1l1ll_l1_ (u"ูࠫࠥวฺหࠣ࠲ࠥษๅศࠢๅ์ฬฬๅࠡล้์ฬ฿ࠠศๆไ๎ิ๐่่ษอࠤๆ฿ๅา้สࠤࠬ偌") + str(l11l1ll_l1_/60/60/24) + l1l1ll_l1_ (u"ࠬࠦร๋ษ่ࠤ࠳ࠦรๆษ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣๅ฾๋ั่ษࠣࠫ偍") + str(l1llll1l1_l1_/60/60) + l1l1ll_l1_ (u"࠭ࠠิษ฼อࠥ็โุࠢ࠱ࠤศ๋วࠡใะูࠥืโๆࠢส่ส฻ฯศำࠣๅ฾๋ั่ࠢࠪ偎") + str(l11ll1l1l1l_l1_/60) + l1l1ll_l1_ (u"ࠧࠡัๅ๎็ฯࠠ࠯ࠢฦ้ฬࠦแฮืࠣหูะัศๅࠣไࡎࡖࡔࡗࠢไ฽๊ื็ࠡࠩ偏") + str(NO_CACHE) + l1l1ll_l1_ (u"ࠨࠢาๆ๏่ษࠨ偐")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ偑"),l1l1ll_l1_ (u"้ࠪฬࠦ็้ࠢส่่อิࠡษ็ุ้ะฮะ็ࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ偒"),l1ll1l11l1l_l1_,l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ偓"))
	return
def l1l11ll1l111_l1_():
	message = l1l1ll_l1_ (u"ࠬอไโษุ่ฮࠦสฺ่ํࠤ๊าไะࠢห๊ๆูࠠศี่๋ࠥอไฤื็๎ࠥ๎วๅ่ๅ฻ฮࠦสฺ่ํࠤศ์ࠠศๆสื๊ࠦวๅลุ่๏ࠦสๆࠢอ฽ิ๐ไ่๋ࠢๅฬ฻ไส๋๊ࠢ็฽ษࠡฬ฼๊๎ࠦๅอๆาࠤํะๅࠡฬ฼ำ๏๊ࠠศี่๋ࠥ๎ศะ๊้ࠤ฾๊วๆหࠣฮ฾์๊ࠡ็็ๅࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊ࠨ偔")
	DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ偕"),l1l1ll_l1_ (u"ࠧࠨ偖"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ偗"),message)
	return
def l1l11llll11l_l1_():
	message = l1l1ll_l1_ (u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪ偘")
	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ偙"),l1l1ll_l1_ (u"ࠫࠬ做"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ偛"),message)
	return
def l1l1ll1l11ll_l1_():
	message = l1l1ll_l1_ (u"࠭วๅ฼ิฺ๋ࠥๆࠡึ๊หิฯࠠศๆอุๆ๐ั้๋ࠡࠤ฻๋ว็ุࠢัฮ่ࠦิำํอࠥอไๆ฻็์๊อสࠡษ็้ฯฮวะๆฬࠤอ๐ๆࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅ้ไ฼ࠤฬ๊ๅีใิࠤํํะศࠢส่฻๋ว็ࠢ฽๎ึࠦๅุๆ๋ฬࠥ๎ไศࠢะหัฯࠠๅ้ࠣ฽๋ีࠠศๆสฮฺอไࠡษ๋ࠤฬ๊ัษู้ࠣ฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํํวหࠢสฺ่๊แาหࠪ停")
	DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ偝"),l1l1ll_l1_ (u"ࠨࠩ偞"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ偟"),message)
	return
def l1l11lll1l11_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ偠"),l1l1ll_l1_ (u"ࠫࠬ偡"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ偢"),l1l1ll_l1_ (u"࠭ไไ์ࠣ๎฾๋ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆไ๎ิ๐่่ษอࠤࡡࡴ๋ࠠฮหࠤฯ็ู๋ๆࠣษ฻อแสࠢสื๊ํวࠡ࡞ࡱࠤ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ偣"))
	l1l1ll11lll1_l1_(l1l1ll_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ偤"),True)
	return
def l1l1l111l1l1_l1_():
	message  = l1l1ll_l1_ (u"ࠨ็วาึอࠠใษ่ฮࠥฮูืࠢืี่อสࠡษ็ษ๋ะั็ฬࠣห้ี่ๅ์ࠣฬํ฼ูࠡ฻สส็ࠦึะࠢส่อืวๆฮ้ࠣะ๊ࠠไ๊า๎๊ࠥสิ็ะࠤๆ่ืࠡๆห฽฻ࠦๅิฬัำ๊๐ࠠศๆ่ฮฺ็อࠡสส่ิิ่ๅࠢ็้ํอโฺࠢส่ๆ๐ฯ๋๊ࠪ健")
	#message += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ่่าสࠤฬู๊ศศๅࠤ์๎ࠠࡳࡧࡆࡅࡕ࡚ࡃࡉࡃࠣห้ิวึࠢหุึ้ษࠡฮ๋ะ้ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ偦")
	#message += l1l1ll_l1_ (u"ࠪ์ฬ๊ะุ๋๊ࠢ฾ะ็ࠡึิ็ฮࠦฬ้ฮ็ࠤำ฻๊ึษ่๊ࠣ์ูࠡสิห๊าࠠๆอ็ࠤ่๎ฯ๋่๊ࠢࠥะีโฯࠣห้หๆหำ้ฮࠬ偧")
	message += l1l1ll_l1_ (u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ偨")
	message += l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ใࠤࠥ࡜ࡐࡏࠢࠣวํࠦࠠࡑࡴࡲࡼࡾࠦࠠฤ๊ࠣࠤࡉࡔࡓࠡࠢฦ์ࠥษ๊ࠡฯ็ࠤอูุ๊ࠢลาึࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠩ偩")
	message += l1l1ll_l1_ (u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭偪")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭偫"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ偬"),message,l1l1ll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ偭"))
	message = l1l1ll_l1_ (u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭偮")
	message += l1l1ll_l1_ (u"ࠫࡡࡴࠧ偯")+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ偰")
	message += l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ偱")+l1l1ll_l1_ (u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ偲")
	message += l1l1ll_l1_ (u"ࠨ࡞ࡱࠫ偳")+l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊฻ัࠡࠢส่่๎๊หࠢࠣว๊๐ัไษࠣࠤ่์ฯศࠢࠣๅึ์ำศࠢࠣห้๐่็ษ้ࠤࠥฮัู๋ส๊๏อࠠศๆศ้ฬืวหࠢฦ่๊อๆ๋ษࠣีํู๊ศࠢส่๏อศศ่ࠣหูู้้ัํอࠥื่ๆษ้๎ฬࠦ็้ๆ้ำฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ側")
	message += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ偵")+l1l1ll_l1_ (u"ࠫฬ๊ๅษำ่ะࠥ๎ฬะฺࠢี๏่ษࠡๆอะฬ๎าࠡษ็฽ฬฬโ๊ࠡ็็๋ํวࠡฬะฮฬาࠠอ้าࠤ่ฮ๊า๋ࠢห้๋ศา็ฯࠤ๏฾ๆࠡษ็ู้้ไสุࠢ฾๏ืษ๊ࠡ็หࠥะำหฯๅࠤฬ๊สฺสࠣๅสึวࠡๆา๎่ࠦๅีๅ็อࠥฮวๅัั์้ࠦไษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎รุ๋สࠤ้้๊ࠡ์อฺาࠦออ็ࠣห้๋ิไๆฬࠤࠬ偶")
	message += l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ศำึ่ࠥืำศๆฬࠤ๊สฯษหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡส็ฯฮࠠโ์๊หࠥอำๆࠢห่ิ้้ࠠลึ้ฬวࠠศๆ่์ฬู่ࠡษ็ฮ๏ࠦไศࠢอืฯ฽ฺ๊ࠢาาํ๊็ศ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ偷")
	l11llll1l1_l1_(l1l1ll_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ偸"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ偹"),message,l1l1ll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ偺"))
	#l1l11llllll1_l1_(l1l1ll_l1_ (u"ࠩࡌࡷࡕࡸ࡯ࡣ࡮ࡨࡱࡂࡌࡡ࡭ࡵࡨࠫ偻"))
	#message = l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ偼")+l1l1ll_l1_ (u"ࠫํ๊โะࠢ็หา฾ๆศࠢส๎฻อࠠฤ่ࠣห้๋่ศไ฼ࠤฬ๊ๅฺษๅอࠥะฮหๆไࠤออฮหๆสๅࠥอไษๆาࠤํะฮหๆไࠤออฮหๆสๅฺࠥัไหࠣห้อๆหำ้๎ฯࠦแ๋ࠢำ่่ࠦวๅส็ำࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊์ࠦอห๋่ࠣํࠦสๆࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣࡔࡷࡵࡸࡺࠢฦ์ࠥษ๊๊ࠡึ๎้ฯࠠศะิํࠥ็ว็ࠢส่๊๎วใ฻ࠣหู้๋ศไฬࠤุ๎แࠡฬัฮ้็้ࠠๆๆ๊์อࠠๅ่ࠣฮ฾๋ไࠡฮ่๎฾ํวࠨ偽")
	#message += l1l1ll_l1_ (u"๊ࠬอๅࠢสฺ่๊ใๅหࠣๆ๊ࠦศฺ็็๎๋ࡀࠠࠡࠢࠣห้ษ่ๅ࠼ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮่ࠦศๅอฬู๋่ࠥࠢสื๊ࠦศๅัๆࠤํอำๆࠢืี่ฯࠠศๆศ๊ฯืๆ๋ฬࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะูๆๆࠣ฽๋ีใࠨ偾")
	#message += l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ偿")+l1l1ll_l1_ (u"้ࠧษ็ฯฬ์๊࠻ࠢฯีอࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤํ฿ๆะࠢส่อ฿ึࠡไาࠤฯำสศฮࠣๅ็฽ࠠห฼ํ๎ึࠦࡄࡏࡕࠣ์ฬ๊รฮี้ࠤศ์๋ࠠๅ๋๊ࠥ็๊ࠡส็ำࠥอฮาࠢ฼่๊อࠠศ่ࠣหุะฮะษ่ࠤࡕࡸ࡯ࡹࡻࠣๆิ๊ࠦฮๆู้้ࠣไสࠢห฽฻ࠦวๅ็๋ห็฿้ࠠๆๆ๊๊๊ࠥิࠢไ๎ࠥาๅ๋฻ࠣห้ี่ๅࠩ傀")
	#DIALOG_TEXTVIEWER(l1l1ll_l1_ (u"ࠨ็ื็้ฯฺ่ࠠาࠤอ฿ึࠡษ็๊ฬูࠧ傁"),message)
	#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ傂"),l1l1ll_l1_ (u"ࠪๅา฻ࠠอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ั࠭傃"),l1l1ll_l1_ (u"ࠫ์ึวࠡษ็ๅา฻่๊่๊ࠠࠣ฿ัโห๋้ࠣࠦวๅ็ื็้ฯࠠๆ่ࠣ฽๋ีใࠡษ่ࠤ๊์ࠠศๆหี๋อๅอ࠰ࠣื๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหๅา฻ࠠๆ๊สๆ฾ํࠠๆำอ๎๋ࠦวๅล๋่๎ࠦศุ้฼็ࠥอไุสํ฽๏่ࠦศๆฮห๋๐ษࠡสสืฯิฯศ็ࠣฬึ๎ใิ์้ࠣัอๆ๋ࠢส๊ฯࠦสฯฬสี์ࠦๅ็ࠢส่็อฦๆหࠣห้ะ๊ࠡีอ฼์ืࠠๅษะๆฬ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิรࠬ傄"),l1l1ll_l1_ (u"ࠬ࠭傅"),l1l1ll_l1_ (u"࠭ࠧ傆"),l1l1ll_l1_ (u"ࠧไๆสࠫ傇"),l1l1ll_l1_ (u"ࠨ่฼้ࠬ傈"))
	#if yes==1:
	#l1l1l1ll11ll_l1_()
	return
def l1l1l11lll1l_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ傉"),l1l1ll_l1_ (u"ࠪࠫ傊"),l1l1ll_l1_ (u"ࠫะ๊วฬฺࠢี็ࠦไๅฬ๋หฺ๊ࠠๆ฻ࠣห้๋ศา็ฯࠫ傋"),l1l1ll_l1_ (u"ࠬษัิๆࠣีุอไสࠢฦ์๋ࠥิไๆฬࠤ๊์ࠠใษษ้ฮࠦฮะ็สฮࠥํะศࠢส่อืๆศ็ฯࡠࡳࡢ࡮ฤ๊ࠣวึูไࠡำึห้ฯࠠโ์ึฬํ้ࠠศๆ์ࠤࠧอไฮษฯࠤ฾๋วะࠤࠣวํࠦวๅ๋ࠣࡠࡳ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡦࡩࡥࡣࡱࡲ࡯࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࠮࡮ࡣ࡫ࡨ࡮࠷ࠠ࡝ࡰ࡟ࡲศ๎ࠠศใอัࠥ์โศึࠣฬฬูสฯัส้ࠥํะศࠢส่ึอศุࠢ࡟ࡲࠥ࡮ࡴࡵࡲ࠽࠳࠴࡭ࡩࡵࡪࡸࡦ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲࡭ࡸࡹࡵࡦࡵࠪ傌"))
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ傍"),l1l1ll_l1_ (u"ࠧࠨ傎"),l1l1ll_l1_ (u"ࠨࡄࡅࡆࡇࡈࡂࡃࡄࡅࡆࠥࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ傏"),l1l1ll_l1_ (u"ࠩ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࡡࡴ࡜࡯࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࡤ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁ࠲ࡡࡅࡆࡇࡈࡂ࠲ࡡࡆࡇࡈࡉࡃ࠲ࡡࡇࡈࡉࡊࡄ࠲ࡡࡈࡉࡊࡋࡅ࠲ࡡࡉࡊࡋࡌࡆ࠲ࡡࡊࡋࡌࡍࡇ࠲ࡡࡋࡌࡍࡎࡈ࠲ࡡࡌࡍࡎࡏࡉ࠲ࡡࡍࡎࡏࡐࡊ࠲ࡡࡎࡏࡐࡑࡋ࠲ࡡࡏࡐࡑࡒࡌ࠲ࡡࡐࡑࡒࡓࡍ࠲ࠢ࠳࠴࠵࠶࠰ࠡ࠳࠴࠵࠶࠷ࠠ࠳࠴࠵࠶࠷ࠦ࠳࠴࠵࠶࠷ࠥ࠺࠴࠵࠶࠷ࠤࡆࡇࡁࡂࡃ࠵ࡣࡇࡈࡂࡃࡄ࠵ࡣࡈࡉࡃࡄࡅ࠵ࡣࡉࡊࡄࡅࡆ࠵ࡣࡊࡋࡅࡆࡇ࠵ࡣࡋࡌࡆࡇࡈ࠵ࡣࡌࡍࡇࡈࡉ࠵ࡣࡍࡎࡈࡉࡊ࠵ࡣࡎࡏࡉࡊࡋ࠵ࡣࡏࡐࡊࡋࡌ࠵ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦ࠵࠶࠷࠸࠹ࠥ࠼࠶࠷࠸࠹ࠤ࠼࠽࠷࠸࠹ࠣ࠼࠽࠾࠸࠹ࠢ࠼࠽࠾࠿࠹ࠡࡃࡄࡅࡆࡇࠠࡃࡄࡅࡆࡇ࠭傐"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ傑"),l1l1ll_l1_ (u"ࠫࠬ傒"),l1l1ll_l1_ (u"ࠬࡈࡂࡃࡄࡅࡆࡇࡈࡂࡃࠢࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ傓"),l1l1ll_l1_ (u"࠭࠰ࠡ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠴ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠸ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠵ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠹ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠶ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠺ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠷ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠻ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠿ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࡠࡌࡍࡎࡏࡐ࠱ࡠࡍࡎࡏࡐࡑ࠱ࡠࡎࡏࡐࡑࡒ࠱ࡠࡏࡐࡑࡒࡓ࠱ࠡ࠲࠳࠴࠵࠶ࠠ࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶ࠥ࠹࠳࠴࠵࠶ࠤ࠹࠺࠴࠵࠶ࠣࡅࡆࡇࡁࡂ࠴ࡢࡆࡇࡈࡂࡃ࠴ࡢࡇࡈࡉࡃࡄ࠴ࡢࡈࡉࡊࡄࡅ࠴ࡢࡉࡊࡋࡅࡆ࠴ࡢࡊࡋࡌࡆࡇ࠴ࡢࡋࡌࡍࡇࡈ࠴ࡢࡌࡍࡎࡈࡉ࠴ࡢࡍࡎࡏࡉࡊ࠴ࡢࡎࡏࡐࡊࡋ࠴ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥ࠻࠵࠶࠷࠸ࠤ࠻࠼࠶࠷࠸ࠣ࠻࠼࠽࠷࠸ࠢ࠻࠼࠽࠾࠸ࠡ࠻࠼࠽࠾࠿ࠠࡂࡃࡄࡅࡆࠦࡂࡃࡄࡅࡆࠬ傔"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ傕"),l1l1ll_l1_ (u"ࠨࠩ傖"),l1l1ll_l1_ (u"ࠩࡅࡆࡇࡈࡂࡃࡄࡅࡆࡇࠦࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ傗"),l1l1ll_l1_ (u"ࠪ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠩ傘"))
	#text = l1l1ll_l1_ (u"ࠫ࠭ࠦࡁࡂࡃࡄࡅ࠶ࡥࡂࡃࡄࡅࡆ࠶ࡥࡃࡄࡅࡆࡇ࠶ࡥࡄࡅࡆࡇࡈ࠶ࡥࡅࡆࡇࡈࡉ࠶ࡥࡆࡇࡈࡉࡊ࠶ࡥࡇࡈࡉࡊࡋ࠶ࡥࡈࡉࡊࡋࡌ࠶ࡥࡉࡊࡋࡌࡍ࠶ࠦࠩࠡ࠲ࠣ࠵ࠥ࠸ࠠ࠴ࠢ࠷ࠤ࠺ࠦ࠶ࠡ࠹ࠣ࠼ࠥ࠿ࠠࡢࠢࡥࠤࡨࠦࡤࠡࡧࠣࡪࠥ࡭ࠠࡩࠢ࡬ࠤ࡯ࠦ࡫ࠡ࡮ࠣࡱࠥࡴࠠࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠠࡷࠢࡺࠤࡽࠦࡹࠡࡼࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࡰࠢࡳࠤࡶࠦࡲࠡࡵࠣࡸࠥࡻࠧ備")
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠬ࠭傚"),l1l1ll_l1_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠳࠵࠷࠹࠴ࠨ傛"),l1l1ll_l1_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠴࠶࠸࠳࠵ࠩ傜"),l1l1ll_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ傝"),l1l1ll_l1_ (u"ࠩ࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ࠦ࠲࠳࠴࠵࠶࠷࠸࠲࠳࠴ࠪ傞"),text,1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠪࠫ傟"),l1l1ll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ傠"),l1l1ll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ傡"),l1l1ll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭傢"),l1l1ll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ傣"),l1l1ll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ傤"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠩࠪ傥"),l1l1ll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傦"),l1l1ll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ傧"),l1l1ll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ储"),l1l1ll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傩"),l1l1ll_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ傪"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠨࠩ傫"),l1l1ll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ催"),l1l1ll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傭"),l1l1ll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ傮"),l1l1ll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傯"),l1l1ll_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傰"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l1l1ll_l1_ (u"ࠧࠨ傱"),l1l1ll_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ傲"),l1l1ll_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ傳"),l1l1ll_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ傴"),l1l1ll_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎ࡜࡯ࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ債"),l1l1ll_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭傶"))
	return
def l1l1l11ll111_l1_():
	l1l1l1l111l1_l1_()
	yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭傷"),l1l1ll_l1_ (u"ࠧࠨ傸"),l1l1ll_l1_ (u"ࠨࠩ傹"),l1l1ll_l1_ (u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭傺"),l1l1ll_l1_ (u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศ๋ࠢห้๋ำฮࠢํฮ๊ࠦสๅไสส๏อฺ่ࠠาࠤฬ์ส่ษฤࠤ฾๋ัࠡษ็ูๆำวห๋ࠢห้๋ำฮࠢ็หࠥ๐ึา๋้๊้ࠢๆࠡ์ะ่ࠥฮูืࠢสฺ่๊วไๆࠪ傻"))
	if yes==1:
		l1l1l1l111ll_l1_(True)
		DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ傼"),l1l1ll_l1_ (u"ࠬ࠭傽"),l1l1ll_l1_ (u"࠭สๆ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะࠥฮวๅๅส้้࠭傾"),l1l1ll_l1_ (u"ࠧฦาสࠤ่อๆหࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢสัิࠦวๅ็๋ห็฿ࠠโฮิฬࠥอไๆ๊ๅ฽ࠥอไร่ࠣ࠲࠳࠴้ࠠลำหࠥอไๆึๆ่ฮࠦๅิฬ่ีฮࠦแฦา้ࠤฬืำๅࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ傿"))
	return yes
def l1l1llll11l1_l1_(showDialogs=True):
	if not showDialogs: showDialogs = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ僀"),l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡽࡧ࡭ࡱ࡮ࡨ࠲ࡨࡵ࡭ࠨ僁"),l1l1ll_l1_ (u"ࠪࠫ僂"),l1l1ll_l1_ (u"ࠫࠬ僃"),False,l1l1ll_l1_ (u"ࠬ࠭僄"),l1l1ll_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩ僅"))
	#html = response.content
	if not response.succeeded:
		l1l1l1111lll_l1_ = False
		l11lll1111_l1_ = l11ll1l1ll_l1_()
		LOG_THIS(l1l1ll_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ僆"),LOGGING(script_name)+l1l1ll_l1_ (u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭僇")+l11lll1111_l1_+l1l1ll_l1_ (u"ࠩࡠࠫ僈"))
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ僉"),l1l1ll_l1_ (u"ࠫࠬ僊"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ僋"),l1l1ll_l1_ (u"࠭แฮืࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠳࠴࠮ࠡ็ื็้ฯࠠ࠯࠰࠱ࠤฬ๊วหืส่ࠥอไๆึไีࠥ࠮วๅำห฻ࠥอไๆึไี࠮ࠦไศࠢํ฽ฺ๊๊่ࠠา็ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯࠰࠱ࠤํ฿ๆะๅࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅࠡษ็้ํอโฺࠢสฺ่๊แาหࠪ僌"))
	else:
		l1l1l1111lll_l1_ = True
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ働"),l1l1ll_l1_ (u"ࠨࠩ僎"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ像"),l1l1ll_l1_ (u"ࠪะ๏ีࠠอัสࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แาࠫࠣ๎฾๋ไࠡ฻้ำ่่ࠦศๆหี๋อๅอࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧ僐"))
	if not l1l1l1111lll_l1_ and showDialogs: l1l1l1llllll_l1_()
	return l1l1l1111lll_l1_
def l1l1l1llllll_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ僑"),l1l1ll_l1_ (u"ࠬ࠭僒"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ僓"),l1l1ll_l1_ (u"ࠧษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥะอหษฯࠤึฮืࠡ็ืๅึ่ࠦใัࠣ๎่๎ๆࠡฮ๊หื้ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวๅำห฻ࠥอไๆึไีࠥษ่้้ࠡห่ࠦๅีๅ็อࠥ็๊ࠡึ๊หิฯࠠศๆอุๆ๐ัࠡษ็าฬ฻ษࠡสๆ์ิ๐ฺ่ࠠา็ࠥ฿ไๆษࠣห๋ํࠠห็ࠣๅา฻ࠠศๆหี๋อๅอࠢ฼่๎ࠦใ้ัํࠤฬ๊ลึัสีฬะࠠ࡝ࡰࠣ࠵࠼࠴࠶ࠡࠢࠩࠤࠥ࠷࠸࠯࡝࠳࠱࠾ࡣࠠࠡࠨࠣࠤ࠶࠿࠮࡜࠲࠰࠷ࡢ࠭僔"))
	#l1ll1l11l1l_l1_ = l1l1ll_l1_ (u"ࠨึ๊หิฯࠠศๆอุๆ๐ั้ࠡํࠤ๊๊แࠡ์ะฮํ๐ฺࠠๆ์ࠤู็ัสࠢัหฺฯࠠฤ๊ࠣฮํอโ๋฻ࠣาฬ฻ษࠡๆืี่อสࠡ็฼ีํ็ษ๊ࠡ็๋ࠥะวา์ัࠤฺ๊วฮ์ฬࠤํ์แศาࠣ์ฬฺ๊าุ้๋ࠣํ่๊ࠠࠣฮออฯๅࠢส่๊฿ไ้็สฮࠥฮืา์ๅอ๋ࠥิโำฬࠤ๏฻ูษࠢสาฯืวใ้สࠤํ็็ๆ้สࠫ僕")
	l1l1ll1l1l11_l1_()
	return
def l1l11llllll1_l1_(text=l1l1ll_l1_ (u"ࠩࠪ僖")):
	l1ll1l111l11_l1_ = True
	if l1l1ll_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭僗") not in text:
		l1ll1l111l11_l1_ = False
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ僘"),l1l1ll_l1_ (u"ࠬหัิษ็ࠤึูวๅหࠪ僙"),l1l1ll_l1_ (u"࠭ลาีส่๋ࠥิไๆฬࠫ僚"),l1l1ll_l1_ (u"ࠧࠨ僛"),l1l1ll_l1_ (u"ࠨ้็ࠤฯื๊ะࠢฦ๊ࠥะัิๆࠣีุอไสࠢฦ้ࠥะั๋ัࠣว๋ࠦสาี็ࠤฺ๊ใๅหࠣรࠬ僜"))
		if yes==1:
			l1ll1l111l11_l1_ = True
			text = l1l1ll_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ僝")
	if l1ll1l111l11_l1_:
		#yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ僞"),l1l1ll_l1_ (u"ࠫࠬ僟"),l1l1ll_l1_ (u"ࠬ࠭僠"),l1l1ll_l1_ (u"࠭ลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧ僡"),l1l1ll_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏ูสุ์฼ࠤฬ๊ๅษำ่ะู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ลึๆสั์อࠧ僢"))
		#if not yes:
		#	DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ僣"),l1l1ll_l1_ (u"ࠩࠪ僤"),l1l1ll_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭僥"),l1l1ll_l1_ (u"้๊ࠫริใࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ僦"))
		#	return
		l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡭ࡱࡪࡷࡂࡿࡥࡴࠩࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲่ࠧๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ࠬࠨไห่ࠥอัิษ็ࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾๊๊ไࠢส๊ࠥะโ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๎ࠠศๆิหอ฽ࠠศๆำ๎ࠥ๐ูุ์ๆࠤฬ๊ๅีๅ็อ๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅษั฻ฬว้ࠠษ็หุะฮะษ่࠲ࠥํไࠡฬิ๎ิࠦวๅษิืฬ๊ࠠศๆส๊ࠥลࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨๅ็หࠬ࠲ࠧ็฻่ࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡿࡥࡴ࠿ࡀ࠴࠿ࠐࠉࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩอ้ࠥอไ฻ษฤࠤฬ๊วาีส่ࠬ࠯ࠊࠊࠋࠌࠍࡷ࡫ࡴࡶࡴࡱࠤࠬ࠭ࠊࠊࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࠬอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭ࠬࠨษำห้ࠥว็ฬ่ࠣิ๐ใࠡ็ื็้ฯࠠโษ็ีัอมࠡไิหฦฯࠠใี่ࠤฬ๊ๅีษๆ่ࠥ๎วๅษึส้ฯ้ࠠษำห๊ࠥๅࠡฬฯำࠥอไฮๆ๋๋ࠣอใࠡใะหํ๊ࠠไฬสฬฮࠦฬๆ์฼ࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อ๊ࠥว็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࠭ࠏࠏࠉࠣࠤࠥ僧")
		if l1l1ll_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭僨") not in text:
			yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ僩"),l1l1ll_l1_ (u"ࠨࠩ僪"),l1l1ll_l1_ (u"ࠩࠪ僫"),l1l1ll_l1_ (u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪ僬"),l1l1ll_l1_ (u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫ僭"))
			if yes!=1:
				DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭僮"),l1l1ll_l1_ (u"࠭ࠧ僯"),l1l1ll_l1_ (u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠪ僰"),l1l1ll_l1_ (u"ࠨๆ็วุ็ࠠษั๋๊ࠥะำอ์็ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣๅฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏ูสุ์฼ࠤ๊฿ัโหࠣห้๋ิไๆฬࠤํ๊วࠡฯ็๋ฬࠦไศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ僱"))
				return
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ僲"),l1l1ll_l1_ (u"ࠪࠫ僳"),l1l1ll_l1_ (u"่ࠫะวษหࠣ์ูือࠡษ็้ํ฼ฺ่ࠢ็่๊ฮัๆฮࠪ僴"),l1l1ll_l1_ (u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้อ๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ僵"))
	search = OPEN_KEYBOARD(l1l1ll_l1_ (u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ僶"))
	if not search: return
	message = search
	if l1ll1l111l11_l1_: type = l1l1ll_l1_ (u"ࠧ࠮ࡒࡵࡳࡧࡲࡥ࡮ࠩ僷")
	else: type = l1l1ll_l1_ (u"ࠨ࠯ࡐࡩࡸࡹࡡࡨࡧࠪ僸")
	l1llll1l1111_l1_ = l1l1ll_l1_ (u"ࠩࡄ࡚࠿ࠦࠧ價")+l1l1l1l1l1l_l1_(32)+type
	succeeded = l111lll1ll1_l1_(l1llll1l1111_l1_,message,True,l1l1ll_l1_ (u"ࠪࠫ僺"),l1l1ll_l1_ (u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧ僻"),text)
	#	url = l1l1ll_l1_ (u"ࠬࡳࡹࠡࡃࡓࡍࠥࡧ࡮ࡥ࠱ࡲࡶ࡙ࠥࡍࡕࡒࠣࡷࡪࡸࡶࡦࡴࠪ僼")
	#	payload = l1l1ll_l1_ (u"࠭ࡻࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ࠽ࠦࡒ࡟ࠠࡂࡒࡌࠤࡐࡋ࡙ࠣ࠮ࠥࡸࡴࠨ࠺࡜ࠤࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠣ࡟࠯ࠦࡸ࡫࡮ࡥࡧࡵࠦ࠿ࠨ࡭ࡦࡂࡨࡱࡦ࡯࡬࠯ࡥࡲࡱࠧ࠲ࠢࡴࡷࡥ࡮ࡪࡩࡴࠣ࠼ࠥࡊࡷࡵ࡭ࠡࡃࡵࡥࡧ࡯ࡣࠡࡘ࡬ࡨࡪࡵࡳࠣ࠮ࠥࡸࡪࡾࡴࡠࡤࡲࡨࡾࠨ࠺ࠣࠩ僽")+message+l1l1ll_l1_ (u"ࠧࠣࡿࠪ僾")
	#	#auth=(l1l1ll_l1_ (u"ࠣࡣࡳ࡭ࠧ僿"), l1l1ll_l1_ (u"ࠤࡰࡽࠥࡶࡥࡳࡵࡲࡲࡦࡲࠠࡢࡲ࡬ࠤࡰ࡫ࡹࠣ儀")),
	#	import requests
	#	response = requests.request(l1l1ll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ儁"),url, data=payload, headers=l1l1ll_l1_ (u"ࠫࠬ儂"), auth=l1l1ll_l1_ (u"ࠬ࠭儃"))
	#	response = requests.l111ll_l1_(url, data=payload, headers=l1l1ll_l1_ (u"࠭ࠧ億"), auth=l1l1ll_l1_ (u"ࠧࠨ儅"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ儆"),l1l1ll_l1_ (u"ࠩࠪ儇"),l1l1ll_l1_ (u"ࠪࠫ儈"),l1l1ll_l1_ (u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ儉"))
	#	else:
	#		DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭儊"),l1l1ll_l1_ (u"࠭ࠧ儋"),l1l1ll_l1_ (u"ࠧฯูฦࠤๆ๐ࠠศๆศีุอไࠨ儌"),l1l1ll_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࡼࡿ࠽ࠤࢀࠧࡲࡾࠩ儍").format(response.status_code, response.content))
	#	l1l1l11111l1_l1_ = l1l1ll_l1_ (u"ࠩࡰࡩࡅ࡫࡭ࡢ࡫࡯࠲ࡨࡵ࡭ࠨ儎")
	#	l1l1l11ll1ll_l1_ = l1l1ll_l1_ (u"ࠪࡱࡪࡆࡥ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩ儏")
	#	header = l1l1ll_l1_ (u"ࠫࠬ儐")
	#	#header += l1l1ll_l1_ (u"ࠬࡌࡲࡰ࡯࠽ࠤࠬ儑") + l1l1l11111l1_l1_
	#	#header += l1l1ll_l1_ (u"࠭࡜࡯ࡖࡲ࠾ࠥ࠭儒") + l1l11l111l1l_l1_
	#	#header += l1l1ll_l1_ (u"ࠧ࡝ࡰࡆࡧ࠿ࠦࠧ儓") + l1l11l111l1l_l1_
	#	header += l1l1ll_l1_ (u"ࠨ࡞ࡱࡗࡺࡨࡪࡦࡥࡷ࠾๋ࠥๆࠡๅ๋ำ๏ࠦวๅใํำ๏๎ࠠศๆ฼ีอ๐ࠧ儔")
	#	server = l1ll11111lll_l1_.l1l1l111l1ll_l1_(l1l1ll_l1_ (u"ࠩࡶࡱࡹࡶ࠭ࡴࡧࡵࡺࡪࡸࠧ儕"),25)
	#	#server.l1l1l1l1ll11_l1_()
	#	server.l1l1l1ll11l1_l1_(l1l1ll_l1_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬ儖"),l1l1ll_l1_ (u"ࠫࡵࡧࡳࡴࡹࡲࡶࡩ࠭儗"))
	#	response = server.l1l1ll11l111_l1_(l1l1l11111l1_l1_,l1l1l11ll1ll_l1_, header + l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ儘") + message)
	#	server.quit()
	return
def l1l1ll1lll11_l1_():
	text = l1l1ll_l1_ (u"࠭็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์๋ะิࠦไ่ࠢฦ๎ู๊ࠥาใิࠤ๏ูสื์ไࠤศ๐ࠠๆฯอ์๏อส࠯ࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤึ๎วษูࠣ์ฯ฼ๅ๋่่๊ࠣำส้์สฮ๋ࠥัโ๊฼อࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣาฬืฬ๋ห࠱ࠤฬ๊ศา่ส้ัฺ๋ࠦำุ้ࠣส่ๅࠢ฼๊ࠥษ๊ࠡ็ะฮํ๐วหࠢอ้ࠥะอๆ์็๋ฬูࠦๅ๋ࠣื๏ืแาษอࠤํ๋่ศไ฼ࠤำอัอ์ฬࠤ๋่ࠧศไ฼ࠤ฼ืแࠡอส่ะࠨ࠮ࠡฮ่๎฾ࠦวๅลึ้ฬว้ࠠษ็้ฬืใศฬࠣ์ฬ๊ี้ำࠣ์ฬ๊ๅ็ึ๋ีฬะ่ࠠ์ࠣาฬ฻ษࠡสสูาอศ่ษ࠱ࠤฬ๊ศา่ส้ัࠦไศࠢํ๊ฯํใࠡฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠡࡆࡐࡇࡆࠦลัษࠣ็ฬ์ࠠๅัํ็ฺࠥใ้๋ࠣาฬ฻ษࠡสส่ึ๎วษูࠣ์ฬ๊สืษ่๎๋ࠦวๅะสีั๐ษࠡใส่ึาวยࠢส่ฯ๎วึๆ้ࠣ฾ࠦละษิอࠥํะ่ࠢสุ่๐ัโำสฮࠥ๎วๅ็๋ห็฿ࠠศๆัหึา๊ส࠰๋ࠣีอࠠศๆหี๋อๅอ๊ࠢ์ࠥฮศิษฺอ๋ࠥสึใะࠤ้๋่ศไ฼ࠤฬ๊่๋สࠪ儙")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭儚"),l1l1ll_l1_ (u"ࠨฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠨ儛"),text,l1l1ll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ儜"))
	text = l1l1ll_l1_ (u"ࠪࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤ࡭ࡵࡳࡵࠢࡤࡲࡾࠦࡣࡰࡰࡷࡩࡳࡺࠠࡰࡰࠣࡥࡳࡿࠠࡴࡧࡵࡺࡪࡸ࠮ࠡࡋࡷࠤࡴࡴ࡬ࡺࠢࡸࡷࡪࡹࠠ࡭࡫ࡱ࡯ࡸࠦࡴࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡺࡨࡢࡶࠣࡻࡦࡹࠠࡶࡲ࡯ࡳࡦࡪࡥࡥࠢࡷࡳࠥࡶ࡯ࡱࡷ࡯ࡥࡷࠦ࡯࡯࡮࡬ࡲࡪࠦࡶࡪࡦࡨࡳࠥ࡮࡯ࡴࡶ࡬ࡲ࡬ࠦࡳࡪࡶࡨࡷ࠳ࠦࡁ࡭࡮ࠣࡸࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠬࠡࡸ࡬ࡨࡪࡵࡳ࠭ࠢࡷࡶࡦࡪࡥࠡࡰࡤࡱࡪࡹࠬࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡰࡥࡷࡱࡳ࠭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࡪࡪࠠࡸࡱࡵ࡯࠱ࠦ࡬ࡰࡩࡲࡷࠥࡸࡥࡧࡧࡵࡩࡳࡩࡥࡥࠢ࡫ࡩࡷ࡫ࡩ࡯ࠢࡥࡩࡱࡵ࡮ࡨࠢࡷࡳࠥࡺࡨࡦ࡫ࡵࠤࡷ࡫ࡳࡱࡧࡦࡸ࡮ࡼࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣࡧࡴࡳࡰࡢࡰ࡬ࡩࡸ࠴ࠠࡕࡪࡨࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡸ࡯ࡢ࡭ࡧࠣࡪࡴࡸࠠࡸࡪࡤࡸࠥࡵࡴࡩࡧࡵࠤࡵ࡫࡯ࡱ࡮ࡨࠤࡺࡶ࡬ࡰࡣࡧࠤࡹࡵࠠ࠴ࡴࡧࠤࡵࡧࡲࡵࡻࠣࡷ࡮ࡺࡥࡴ࠰࡛ࠣࡪࠦࡵࡳࡩࡨࠤࡦࡲ࡬ࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࠤࡴࡽ࡮ࡦࡴࡶ࠰ࠥࡺ࡯ࠡࡴࡨࡧࡴ࡭࡮ࡪࡼࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮ࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡤࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡢࡴࡨࠤࡱࡵࡣࡢࡶࡨࡨࠥࡹ࡯࡮ࡧࡺ࡬ࡪࡸࡥࠡࡧ࡯ࡷࡪࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡳࡷࠦࡶࡪࡦࡨࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡢࡴࡨࠤ࡫ࡸ࡯࡮ࠢࡲࡸ࡭࡫ࡲࠡࡸࡤࡶ࡮ࡵࡵࡴࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡢࡰࡼࠤࡱ࡫ࡧࡢ࡮ࠣ࡭ࡸࡹࡵࡦࡵࠣࡴࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡰࡩࡩ࡯ࡡࠡࡨ࡬ࡰࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡪࡲࡷࡹ࡫ࡲࡴ࠰ࠣࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡹࡩ࡮ࡲ࡯ࡽࠥࡧࠠࡸࡧࡥࠤࡧࡸ࡯ࡸࡵࡨࡶ࠳࠭儝")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ儞"),l1l1ll_l1_ (u"ࠬࡊࡩࡨ࡫ࡷࡥࡱࠦࡍࡪ࡮࡯ࡩࡳࡴࡩࡶ࡯ࠣࡇࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦࡁࡤࡶࠣࠬࡉࡓࡃࡂࠫࠪ償"),text,l1l1ll_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ儠"))
	return
def l1l1l1ll1111_l1_(addon_id):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ儡"),l1l1ll_l1_ (u"ࠨࠩ儢"),l1l1ll_l1_ (u"ࠩࠪ儣"),addon_id)
	result = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭儤")+addon_id+l1l1ll_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡩࡥࡱࡹࡥࡾࡿࠪ儥"))
	refresh = True
	l1l1ll_l1_ (u"ࠧࠨࠢࠋࠋ࡬ࡱࡵࡵࡲࡵࠢࡶ࡬ࡺࡺࡩ࡭ࠌࠌࡼࡧࡳࡣࡧ࡫࡯ࡩࠥࡃࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯࡬ࡲ࡭ࡳ࠮ࡸࡣ࡯ࡦࡪࡴࡲࡤࡦࡴ࠯ࠫࡦࡪࡤࡰࡰࡶࠫ࠱ࡧࡤࡥࡱࡱࡣ࡮ࡪࠩࠋࠋ࡬ࡪࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮ࡸࡣ࡯ࡦࡪ࡮ࡲࡥࠪ࠼ࠍࠍࠎࡹࡨࡶࡶ࡬ࡰ࠳ࡸ࡭ࡵࡴࡨࡩ࠭ࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠩࠋࠋࠌࡶࡪ࡬ࡲࡦࡵ࡫ࠤࡂࠦࡔࡳࡷࡨࠎࠎࡻࡳࡦࡴࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡷࡶࡩࡷ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡷࡶࡩࡷ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡶࡵࡨࡶ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࠤ࡫ࡰࡴࡴࡸࡴࠡࡵࡴࡰ࡮ࡺࡥ࠴ࠌࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡧࡤࡥࡱࡱࡷࡤࡪࡢࡧ࡫࡯ࡩ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡺࡥࡹࡶࡢࡪࡦࡩࡴࡰࡴࡼࠤࡂࠦࡳࡵࡴࠍࠍࡨࡩࠠ࠾ࠢࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪࠌࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪࠦࠥࡁࠧࠪࠌࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡡࡥࡦࡲࡲࡸࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠣࠢ࠾ࠫ࠮ࠐࠉࠤࡥࡦ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡷ࡫ࡰࡰࡵ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫࠧࠦ࠻ࠨࠫࠍࠍࡨࡵ࡮࡯࠰ࡦࡳࡲࡳࡩࡵࠪࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡱࡵࡳࡦࠪࠬࠎࠎࠨࠢࠣ儦")
	if refresh:
		time.sleep(1)
		xbmc.executebuiltin(l1l1ll_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ儧"))
		time.sleep(1)
	return
def l1l1ll1l111l_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ儨"),l1l1ll_l1_ (u"ࠨࠩ儩"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ優"),l1l1ll_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨ儫"))
	l1l1ll1l11ll_l1_()
	return
def l1l1ll1l1l11_l1_():
	#	l1lll11l_l1_://l111llll11l_l1_.tv/download/849
	#   l1lll11l_l1_://play.l1ll1lll1ll1_l1_.l1lll1ll1_l1_/l1l1l11l11ll_l1_/l1l1l11ll1l1_l1_/l1ll11ll1l11_l1_?id=l1llll1lll1_l1_.xbmc.l111llll11l_l1_
	#	http://mirror.l1l1ll11ll11_l1_.l1l1l11111ll_l1_.l1ll111ll1l1_l1_/l1l1ll111l11_l1_/xbmc/l1l1l111llll_l1_/l1l11l11ll11_l1_/l1l1ll111lll_l1_
	#	http://l1l11lll1l1l_l1_.l1l11l1lll11_l1_.l1ll111ll1l1_l1_/l111llll11l_l1_/l1l1l111llll_l1_/l1l11l11ll11_l1_/l1l1ll111lll_l1_
	url = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩ儬")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ儭"),url,l1l1ll_l1_ (u"࠭ࠧ儮"),l1l1ll_l1_ (u"ࠧࠨ儯"),l1l1ll_l1_ (u"ࠨࠩ儰"),l1l1ll_l1_ (u"ࠩࠪ儱"),l1l1ll_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡈࡐ࡙ࡢࡐࡆ࡚ࡅࡔࡖࡢࡏࡔࡊࡉࡠࡘࡈࡖࡘࡏࡏࡏ࠯࠴ࡷࡹ࠭儲"))
	html = response.content
	l1l11l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦࡰࡵࡤࡪ࠯ࠫࡠࡩ࠱࡜࠯࡞ࡧ࠯࠲ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠪ࠯ࠪ儳"),html,re.DOTALL)
	l1l11l1ll111_l1_ = l1l11l1ll111_l1_[0].split(l1l1ll_l1_ (u"ࠬ࠳ࠧ儴"))[0]
	l1ll111l1l11_l1_ = str(kodi_version)
	#l1111l1lll1_l1_ = l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ儵")+l1l1ll_l1_ (u"ࠧศๆหี๋อๅอࠢ็หࠥ๐ูๆๆ้ࠣ฾ࠦใ้ัํࠤส฻ฯศำࠣ࠵࠾่ࠦๆษࠣฬ฾ี็ࠨ儶")+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ儷")
	l1111l1lll1_l1_ = l1l1ll_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ儸")+l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭儹")+l1l11l1ll111_l1_+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭儺")
	l1111l1lll1_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ儻")+l1l1ll_l1_ (u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ儼")+l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ儽")+l1ll111l1l11_l1_+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ儾")
	DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ儿"),l1l1ll_l1_ (u"ࠪࠫ兀"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ允"),l1111l1lll1_l1_)
	return
def l1l11llll111_l1_():
	# l1lll11l_l1_://l1ll111ll1ll_l1_-l1l11lllllll_l1_-l1l1l1l1111l_l1_.l1ll11l111l1_l1_.l1lll1ll1_l1_/request-l1l1l1l11l1l_l1_
	# l1lll11l_l1_://l1ll111ll1ll_l1_-l1l11lllllll_l1_-l1l1l1l1111l_l1_.l1ll11l111l1_l1_.l1lll1ll1_l1_/query-l1l11l1ll1l1_l1_
	l1ll1l11l11_l1_,l1ll1l11l1l_l1_,l1111l1ll1l_l1_,l1111l1lll1_l1_,l1l1ll1ll111_l1_,l1l11ll111ll_l1_,l1l1l111ll11_l1_ = l1l1ll_l1_ (u"ࠬ࠭兂"),l1l1ll_l1_ (u"࠭ࠧ元"),l1l1ll_l1_ (u"ࠧࠨ兄"),l1l1ll_l1_ (u"ࠨࠩ充"),l1l1ll_l1_ (u"ࠩࠪ兆"),l1l1ll_l1_ (u"ࠪࠫ兇"),l1l1ll_l1_ (u"ࠫࠬ先")
	payload,l1l11l1ll1ll_l1_,l1l1ll1111ll_l1_,l1l11l11lll1_l1_ = {l1l1ll_l1_ (u"ࠬࡧࠧ光"):l1l1ll_l1_ (u"࠭ࡡࠨ兊")},{},[],{}
	url = WEBSITES[l1l1ll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ克")][1]
	response = OPENURL_REQUESTS_CACHED(l11ll1l1l1l_l1_,l1l1ll_l1_ (u"ࠨࡒࡒࡗ࡙࠭兌"),url,payload,l1l1ll_l1_ (u"ࠩࠪ免"),l1l1ll_l1_ (u"ࠪࠫ兎"),l1l1ll_l1_ (u"ࠫࠬ兏"),l1l1ll_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪ児"))
	html = response.content
	html = html.replace(l1l1ll_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡓࡵࡣࡷࡩࡸ࠭兑"),l1l1ll_l1_ (u"ࠧࡖࡕࡄࠫ兒"))
	html = html.replace(l1l1ll_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡍ࡬ࡲ࡬ࡪ࡯࡮ࠩ兓"),l1l1ll_l1_ (u"ࠩࡘࡏࠬ兔"))
	html = html.replace(l1l1ll_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡅࡷࡧࡢࠡࡇࡰ࡭ࡷࡧࡴࡦࡵࠪ兕"),l1l1ll_l1_ (u"࡚ࠫࡇࡅࠨ兖"))
	html = html.replace(l1l1ll_l1_ (u"࡙ࠬࡡࡶࡦ࡬ࠤࡆࡸࡡࡣ࡫ࡤࠫ兗"),l1l1ll_l1_ (u"࠭ࡋࡔࡃࠪ兘"))
	html = html.replace(l1l1ll_l1_ (u"ࠧࡏࡱࡵࡸ࡭ࠦࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ兙"),l1l1ll_l1_ (u"ࠨࡐ࠱ࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭党"))
	html = html.replace(l1l1ll_l1_ (u"࡚ࠩࡩࡸࡺࡥࡳࡰࠣࡗࡦ࡮ࡡࡳࡣࠪ兛"),l1l1ll_l1_ (u"࡛ࠪ࠳࡙ࡡࡩࡣࡵࡥࠬ兜"))
	html = html.replace(l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ兝"),l1l1ll_l1_ (u"ࠬࠦࠠࠨ兞"))
	try: l1l1ll1111l1_l1_ = EVAL(l1l1ll_l1_ (u"࠭࡬ࡪࡵࡷࠫ兟"),html)
	except:
		DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ兠"),l1l1ll_l1_ (u"ࠨࠩ兡"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ兢"),l1l1ll_l1_ (u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠๆฯอ์๏อสࠡฬๅี๏ืࠠศๆสืฯิฯศ็ࠪ兣"))
		return
	l1ll11111ll1_l1_,l1ll111ll11l_l1_,l1l1l11lllll_l1_ = l1l1ll1111l1_l1_
	#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ兤"),str(l1ll11111ll1_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭入"),str(l1ll111ll11l_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ兦"),str(l1l1l11lllll_l1_))
	l1l11l11lll1_l1_ = {}
	for site,l1ll1111l111_l1_,l1l1llll11ll_l1_ in l1ll111ll11l_l1_:
		l1l1llll11ll_l1_ = escapeUNICODE(l1l1llll11ll_l1_)
		l1l1llll11ll_l1_ = l1l1llll11ll_l1_.strip(l1l1ll_l1_ (u"ࠧࠡࠩ內")).strip(l1l1ll_l1_ (u"ࠨࠢ࠱ࠫ全"))
		l1111l1lll1_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ兩")+site+l1l1ll_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ兪")+l1l1llll11ll_l1_+l1l1ll_l1_ (u"ࠫࡡࡴࠧ八")
		if l1ll1111l111_l1_.isdigit():
			l1l11l11lll1_l1_[site] = int(l1ll1111l111_l1_)
			if int(l1ll1111l111_l1_)>100: l1ll1111l111_l1_ = l1l1ll_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ公")
			else: l1ll1111l111_l1_ = l1l1ll_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ六")
		if site not in [l1l1ll_l1_ (u"ࠧࡂࡎࡏࠫ兮"),l1l1ll_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ兯"),l1l1ll_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ兰"),l1l1ll_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ共"),l1l1ll_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ兲")]:
			if   l1ll1111l111_l1_==l1l1ll_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ关"): l1ll1l11l11_l1_ += l1l1ll_l1_ (u"࠭ࠠࠡࠩ兴")+site
			elif l1ll1111l111_l1_==l1l1ll_l1_ (u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩ兵"): l1ll1l11l1l_l1_ += l1l1ll_l1_ (u"ࠨࠢࠣࠫ其")+site
	l1ll1111l1l1_l1_,l1l1l111l111_l1_,l1l1l111ll1l_l1_ = list(zip(*l1ll111ll11l_l1_))
	for site in sorted(l11ll1llll1_l1_):
		if site not in l1ll1111l1l1_l1_:
			l1111l1lll1_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ具")+site+l1l1ll_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ典")+l1l1ll_l1_ (u"้ࠫอ๋๊ࠠฯำࠬ兹")+l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ兺")
			if site not in [l1l1ll_l1_ (u"࠭ࡁࡍࡎࠪ养"),l1l1ll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ兼"),l1l1ll_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ兽"),l1l1ll_l1_ (u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭兾"),l1l1ll_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ兿")]: l1111l1ll1l_l1_ += l1l1ll_l1_ (u"ࠫࠥࠦࠧ冀")+site
	for l1l1llll11ll_l1_,counts in l1ll11111ll1_l1_:
		l1l1llll11ll_l1_ = escapeUNICODE(l1l1llll11ll_l1_)
		l1l1ll1ll111_l1_ += l1l1llll11ll_l1_+l1l1ll_l1_ (u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ冁")+str(counts)+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫ冂")
	l1ll1l11l11_l1_ = l1ll1l11l11_l1_.strip(l1l1ll_l1_ (u"ࠧࠡࠩ冃"))
	l1ll1l11l1l_l1_ = l1ll1l11l1l_l1_.strip(l1l1ll_l1_ (u"ࠨࠢࠪ冄"))
	l1111l1ll1l_l1_ = l1111l1ll1l_l1_.strip(l1l1ll_l1_ (u"ࠩࠣࠫ内"))
	l1111ll1111_l1_ = l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠪࠤࠥ࠭円")+l1ll1l11l1l_l1_
	#l1lll11ll11l_l1_  = l1l1ll_l1_ (u"ࠫࡡࡴࡈࡪࡩ࡫࡙ࡸࡧࡧࡦ࠼ࠣ࡟ࠥ࠭冇")+l1ll1l11l11_l1_+l1l1ll_l1_ (u"ࠬࠦ࡝ࠨ冈")
	#l1lll11ll11l_l1_ += l1l1ll_l1_ (u"࠭࡜࡯ࡎࡲࡻ࡚ࡹࡡࡨࡧࠣ࠾ࠥࡡࠠࠨ冉")+l1ll1l11l1l_l1_+l1l1ll_l1_ (u"ࠧࠡ࡟ࠪ冊")
	#l1lll11ll11l_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱࡒࡴ࡛ࡳࡢࡩࡨࠤࠥࡀࠠ࡜ࠢࠪ冋")+l1111l1ll1l_l1_+l1l1ll_l1_ (u"ࠩࠣࡡࠬ册")
	l1111l1llll_l1_  = l1l1ll_l1_ (u"้ࠪํอโฺࠢื฾้ࠦๅ็้สࠤฬ๊ศา่ส้ั๊้ࠦ็ࠣห้ฮวาฯฬࠤๆ๐ฯ๋๊๊หฯࠦศะ๊้ࠤฺ๊วไๆࠪ再")+l1l1ll_l1_ (u"ࠫࡡࡴࠧ冎")+l1l1ll_l1_ (u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ์๐ࠠๅ์ึฮ๋ࠥๆࠡษ็ฬึ์วๆฮࠪ冏")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ冐")
	l1111l1llll_l1_ += l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ冑")+l1111ll1111_l1_+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴࠧ冒")
	l1111l1llll_l1_ += l1l1ll_l1_ (u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢํ์๊ࠦวๅสสีาฯࠠฤ์ࠣๅ๏ี๊้้สฮࠬ冓")+l1l1ll_l1_ (u"ࠪࡠࡳ࠭冔")+l1l1ll_l1_ (u"ࠫํํะศ่ࠢ฽๋อ็ࠡษะฮ๊อไࠡๅห๎ึ่ࠦอ๊าࠤฺ๊ใๅหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨ冕")+l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ冖")
	l1111l1llll_l1_ += l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ冗")+l1111l1ll1l_l1_+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ冘")
	l1ll1111111l_l1_,l1l11llll1l1_l1_,l1l1ll11l1ll_l1_,l1l11lll11ll_l1_ = 0,0,0,0
	all = l1l11l11lll1_l1_[l1l1ll_l1_ (u"ࠨࡃࡏࡐࠬ写")]
	if l1l1ll_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ冚") in list(l1l11l11lll1_l1_.keys()): l1ll1111111l_l1_ = l1l11l11lll1_l1_[l1l1ll_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ军")]
	if l1l1ll_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ农") in list(l1l11l11lll1_l1_.keys()): l1l11llll1l1_l1_ = l1l11l11lll1_l1_[l1l1ll_l1_ (u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭冝")]
	if l1l1ll_l1_ (u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ冞") in list(l1l11l11lll1_l1_.keys()): l1l1ll11l1ll_l1_ = l1l11l11lll1_l1_[l1l1ll_l1_ (u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ冟")]
	if l1l1ll_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ冠") in list(l1l11l11lll1_l1_.keys()): l1l11lll11ll_l1_ = l1l11l11lll1_l1_[l1l1ll_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ冡")]
	videos_count = all-l1ll1111111l_l1_-l1l11llll1l1_l1_-l1l1ll11l1ll_l1_-l1l11lll11ll_l1_
	dummy,l1l1l1llll1l_l1_ = l1l1l11lllll_l1_[0]
	dummy,l1l11ll11lll_l1_ = l1l1l11lllll_l1_[1]
	l1l1l11lll11_l1_ = l1l1l1llll1l_l1_-l1l11ll11lll_l1_
	l1l1l111ll11_l1_ += l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭冢")+str(l1l11ll11lll_l1_)+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭冣")+l1l1ll_l1_ (u"ࠬอไฺัาࠤฬ๊อใ์ๅ๎๊ࠥไฤฮ๊ึฮࠦ࠺ࠡࠩ冤")
	l1l1l111ll11_l1_ += l1l1ll_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ冥")+str(l1l1l11lll11_l1_)+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ冦")+l1l1ll_l1_ (u"ࠨสสืฯิฯศ็ࠣࡴࡷࡵࡸࡺࠢฦ์ࠥࡼࡰ࡯ࠢ࠽ࠤࠬ冧")
	l1l1l111ll11_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ冨")+str(l1l1l1llll1l_l1_)+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冩")+l1l1ll_l1_ (u"ࠫฬู๊ะัࠣห้้ไ๋ࠢ็ะ๊๐ูࠡษ็วัําสࠢ࠽ࠤࠬ冪")
	l1l1l111ll11_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ冫")+str(len(l1l1l11lllll_l1_[2:]))+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ冬")+l1l1ll_l1_ (u"ฺࠧัาࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡใํ๋ฬࠦรอ้ีอࠥࡀࠠ࡝ࡰ࡟ࡲࠬ冭")
	for country,l1l1ll111111_l1_ in l1l1l11lllll_l1_[2:]:
		country = escapeUNICODE(country)
		country = country.strip(l1l1ll_l1_ (u"ࠨࠢࠪ冮")).strip(l1l1ll_l1_ (u"ࠩࠣ࠲ࠬ冯"))
		l1l1l111ll11_l1_ += country+l1l1ll_l1_ (u"ࠪ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ冰")+str(l1l1ll111111_l1_)+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠩ冱")
	#l1l1l111ll11_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮࠯ࠩ冲")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ决")+str(videos_count)+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ冴")+l1l1ll_l1_ (u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࠥ࠭况")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ冶")+str(l1ll1111111l_l1_)+l1l1ll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ冷")+l1l1ll_l1_ (u"ࠫ฼๊ศศฬࠣื๏ืแาࠢหห๏ั่็ࠢ࠽ࠤࠬ冸")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ冹")+str(l1l11lll11ll_l1_)+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ冺")+l1l1ll_l1_ (u"ุࠧๆหหฯࠦำ๋ำไีࠥอไๆะสึ๋ࠦ࠺ࠡࠩ冻")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭冼")+str(l1l11llll1l1_l1_)+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ冽")+l1l1ll_l1_ (u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧ冾")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ冿")+str(l1l1ll11l1ll_l1_)+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ净")+l1l1ll_l1_ (u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬ凁")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ凂")+str(len(l1ll11111ll1_l1_))+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ凃")+l1l1ll_l1_ (u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩ凄")
	#l1l11ll111ll_l1_ += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ凅")+l1l1ll_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤฬู๊ศๆ่ࠤ๏๎ๅࠡล่ืࠥ࠮วๅสสีาฯࠩࠨ准")+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ凇")
	l1l11ll111ll_l1_ += l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ凈")+l1l1ll1ll111_l1_
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ凉"),l1l1ll_l1_ (u"ࠨ฻าำࠥอไฤฮ๊ึฮࠦวๅฬํࠤฬูสฯั่ฮࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠศๆ฼ห้๋๋๊่ࠠࠤศ๋ำࠡࠪส่ออัฮหࠬࠫ凊"),l1l1l111ll11_l1_,l1l1ll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ凋"))
	#l11llll1l1_l1_(l1l1ll_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ凌"),l1l1ll_l1_ (u"ࠫัฺ๋๊๊ࠢิ์ࠦวๅลิๆฬ๋ࠠหะุࠤศูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤࠥ็โุࠢํ์๊ࠦรๆีࠣࠬฬ๊ศศำะอ࠮࠭凍"),l1l11ll111ll_l1_,l1l1ll_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ凎"))
	l11llll1l1_l1_(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭减"),l1l1ll_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠศๆ฼ห้๋๋๊่ࠠࠤศ๋ำࠡࠪส่ออัฮหࠬࠫ凐"),l1l11ll111ll_l1_,l1l1ll_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ凑"))
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ凒"),l1l1ll_l1_ (u"้ࠪํอโฺࠢสุฯเไหࠢํ์๊ࠦวๅสสีาฯࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠬ凓"),l1111l1llll_l1_,l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ凔"))
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠬࡲࡥࡧࡶࠪ凕"),l1l1ll_l1_ (u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡ์๋้ࠥอไษษิัฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩ凖"),l1111l1lll1_l1_,l1l1ll_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ凗"))
	return
def l1l1l11l1111_l1_():
	message = l1l1ll_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠢฦ์ࠥะอๆ์็๋๋ࠥๆ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬ凘")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ凙"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭凚"),message,l1l1ll_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ凛"))
	return
def l1l1llll1lll_l1_():
	message = l1l1ll_l1_ (u"ࠬอไาษห฻๏์ࠠฤั้ห์ࠦแ๋้่หࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬี้้๋ࠠࠤ฾ฮวาหࠣ฽๋ࠦสฬสํฮ้ࠥวๆๆࠣหํะ่ๆษอ๎่๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦๆ฻๊ࠤฬ฼วโหࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ่ࠦๆ฻๊ࠤฬ฼วโหࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี้ࠠ็฼๋ࠥอึศใฬࠤ๊ิา็ࠢ฼้ฬี้ࠠใํ๋ࠥษ๊ืษࠣะ๊๐ูࠡษ฼ำฬีสࠡๅ๋ำ๏ࠦวๅ็ฺ่ํฮษࠡๆ฼้้ࠦศา่ส้ัูࠦๆษาࠤํ้ไ่ษࠣฮฯ๋ࠠศ๊อ์๊อส๋ๅํหࠥ๎ไศࠢอัฯอฬࠡลํࠤ๋๎ูࠡ็้ࠤฬ๊ฮษำฬࠤๆ๐ࠠไ๊า๎ࠥษ่ࠡษ็าอืษࠡใํࠤฯัศ๋ฬࠣว฻อแศฬࠣ็ํี๊ࠨ凜")+l1l1ll_l1_ (u"࠭࡜࡯ࠩ凝")+l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ凞")+WEBSITES[l1l1ll_l1_ (u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧ凟")][0]+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭几")+WEBSITES[l1l1ll_l1_ (u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ凡")][1]+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭凢")
	message += l1l1ll_l1_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺ๎๋ࠦระ่ส๋ࠥํๅศࠢสุ่๎ัิࠢส่ี๐๋ࠠฯอหัํࠠๆัํี๋ࠥไโษอࠤ่๎ฯ๋ࠢ็ฮะฮ๊หࠢหี๋อๅอࠢ฼้ฬีࠠษษ็฻ึ๐โสࠢส่ฯ่ไ๋ัํอࠥอไใัํ้ฮࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ凣")+WEBSITES[l1l1ll_l1_ (u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧ凤")][0]+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ凥")+WEBSITES[l1l1ll_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ処")][1]+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ凧")
	message += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮࡝ࡰฯ้๏฿ࠠๆๆไหฯูࠦๆษาࠤ๊๎ฬ้ัฬࠤๆ๐ࠠศๆ่์็฿ࠠฤั้ห์࠭凨")+l1l1ll_l1_ (u"ࠫࡡࡴࠧ凩")+l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ凪")+WEBSITES[l1l1ll_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ凫")][0]+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ凬")
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ凭"),l1l1ll_l1_ (u"ࠩส่๊๎วใ฻ࠣห้ืำๆ์ฬࠤ้ฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨ凮"),message,l1l1ll_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭凯"))
	return
def l1l1llll1l1l_l1_(l1l1lllll1l1_l1_):
	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪࠪ凰")+l1l1lllll1l1_l1_+l1l1ll_l1_ (u"ࠬ࠯ࠧ凱"), True)
	return
def l1l1lll1ll11_l1_():
	l1ll1ll1l_l1_(l1l1ll_l1_ (u"࠭ࡳࡵࡱࡳࠫ凲"))
	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠢࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡋࡱࡸࡪࡸࡦࡢࡥࡨࡗࡪࡺࡴࡪࡰࡪࡷ࠮ࠨ凳"))
	return
def l1l1l11llll1_l1_():
	xbmc.executebuiltin(l1l1ll_l1_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠯ࠧ凴"), True)
	return
def l1l1ll1l1lll_l1_(showDialogs=True):
	if not showDialogs: yes = True
	else: yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ凵"),l1l1ll_l1_ (u"ࠪࠫ凶"),l1l1ll_l1_ (u"ࠫࠬ凷"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ凸"),l1l1ll_l1_ (u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦวๅฤ้ࠤฤ࠭凹"))
	if yes==1:
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ出"))
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ击"),l1l1ll_l1_ (u"ࠩࠪ凼"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭函"),l1l1ll_l1_ (u"ࠫฯ๋ࠠฦำึห้ࠦืๅสࠣษ้๏ࠠษำ้ห๊าࠠไ๊า๎ࠥอไั์ࠣๅ๏ࠦฬ่ษี็๊ࠥใ๋ࠢํๆํ๋ࠠษฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣ࠲ࠥฮๅศࠢไ๎์อࠠหฯา๎ะࠦ็ัษࠣห้ฮั็ษ่ะࠥ๎สฮัํฯ๋ࠥฮำ่ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩ凾"))
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ凿"))
	l1l11l1l1ll_l1_ = (not yes)
	return l1l11l1l1ll_l1_
def l1l1l1111l1l_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ刀"),l1l1ll_l1_ (u"ࠧࠨ刁"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ刂"),l1l1ll_l1_ (u"ࠩ็ุ้ำࠠๆฯอ์๏อสࠡไสส๊ฯࠠ࠯ࠢสิ์ฮࠠฦๆ์ࠤฬ๊โศศ่อࠥอไห์ࠣฮึ๐ฯࠡ็ึั์อ้ࠠๆสࠤฯีฮๅࠢศ่๏ํว๊ࠡ็็๋ࠦศศีอาิอๅࠡࠤส่๊อ่ิࠤࠣวํࠦࠢศๆิ๎๊๎สࠣࠢสฺ฿฽ฺࠠๆ์ࠤฬ๊าาࠢฯ๋ฮࠦวๅ์่๎๋่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫ刃"))
	return
def l1l1lll111ll_l1_():
	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ刄"),l1l1ll_l1_ (u"ࠫࠬ刅"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ分"),l1l1ll_l1_ (u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ฻เืࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ切"))
	return
#l1l1llllll1l_l1_ 	  required	and l1l1llllll1l_l1_     installed	and		not l1l11l1l1ll_l1_		ignore
#l1l1llllll1l_l1_ not required	and	l1l1llllll1l_l1_ not installed 	and 	    l1l11l1l1ll_l1_		ignore
#l1l1llllll1l_l1_ not required	and	l1l1llllll1l_l1_ not installed 	and 	not l1l11l1l1ll_l1_		ignore
#l1l1llllll1l_l1_ not required	and	l1l1llllll1l_l1_     installed 	and 	not l1l11l1l1ll_l1_		ignore
#l1l1llllll1l_l1_     required	and	l1l1llllll1l_l1_ not installed 	and 	    l1l11l1l1ll_l1_		l1111ll11l_l1_ l1l11llll1l1_l1_	l1l1ll1ll11l_l1_
#l1l1llllll1l_l1_     required	and	l1l1llllll1l_l1_ not installed 	and 	not l1l11l1l1ll_l1_		l1111ll11l_l1_ l1l11llll1l1_l1_	l1l1ll1ll11l_l1_
#l1l1llllll1l_l1_     required 	and l1l1llllll1l_l1_     installed 	and 	    l1l11l1l1ll_l1_		l1111ll11l_l1_ l1ll111l11ll_l1_	l1l1ll1ll11l_l1_
#l1l1llllll1l_l1_ not required	and	l1l1llllll1l_l1_     installed 	and 	    l1l11l1l1ll_l1_		l1111ll11l_l1_ l1ll111l11ll_l1_	l1l1ll1ll11l_l1_
#cond1: required and not installed: l1111ll11l_l1_ l1l11llll1l1_l1_
#cond2: installed and l1111ll11l_l1_ update: l1111ll11l_l1_ l1ll111l11ll_l1_
def l1l1lll11ll1_l1_(showDialogs=True):
	l1ll1l11l1l1_l1_ = l1l1l1l1llll_l1_([l1l1ll_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ刈")])
	l1l1ll11l11l_l1_ = []
	for addon_id in [l1l1ll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ刉")]:
		if addon_id not in list(l1ll1l11l1l1_l1_.keys()): continue
		l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1l111l_l1_,l1l1lll11111_l1_,l1l1ll1lll1l_l1_,l1l11l1llll1_l1_,l1l1ll1llll1_l1_ = l1ll1l11l1l1_l1_[addon_id]
		if not l1l11l11l1l_l1_ or (l1l11l11l1l_l1_ and l1l11l1l1ll_l1_): l1l1ll11l11l_l1_.append(addon_id)
	l1l11l11l111_l1_ = len(l1l1ll11l11l_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l1lll111l1_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1l1lll11lll_l1_ = []
	for addon_id in l1ll11l1111l_l1_:
		cc.execute(l1l1ll_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢ࠭ࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡪࡴࡡࡣ࡮ࡨࡨࠥࡃࠠࠣ࠳ࠥࠤࡦࡴࡤࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭刊")+addon_id+l1l1ll_l1_ (u"ࠪࠦࠥࡁࠧ刋"))
		rows = cc.fetchall()
		if rows: l1l1lll11lll_l1_.append(addon_id)
	l1l1l11l1lll_l1_ = len(l1l1lll11lll_l1_)>0
	for addon_id in l1l1lll1111l_l1_:
		cc.execute(l1l1ll_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ刌")+addon_id+l1l1ll_l1_ (u"ࠬࠨࠠ࠼ࠩ刍"))
		l1ll11l111ll_l1_ = cc.fetchall()
		if l1ll11l111ll_l1_ and l1l1ll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ刎") not in str(l1ll11l111ll_l1_): l1l1ll11l11l_l1_.append(addon_id)
	l1l11lllll1l_l1_ = len(l1l1ll11l11l_l1_)>0
	l1l1ll11l11l_l1_ = list(set(l1l1ll11l11l_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ刏"),l1l1ll_l1_ (u"ࠨࡰࡨࡩࡩࡥࡦࡪࡺ࡬ࡲ࡬ࡥࡲࡦࡲࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࡀࠠࠡࠩ刐")+str(l1l11l11l111_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"ࠩࠪ刑"),l1l1ll_l1_ (u"ࠪࡲࡪ࡫ࡤࡠࡦࡨࡰࡪࡺࡩ࡯ࡩࡢࡳࡱࡪ࡟ࡢࡦࡧࡳࡳࡹ࠺ࠡࠢࠪ划")+str(l1l1l11l1lll_l1_))
	#LOG_THIS(l1l1ll_l1_ (u"ࠫࠬ刓"),l1l1ll_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡳࡷ࡯ࡧࡪࡰ࠽ࠤࠥ࠭刔")+str(l1l11lllll1l_l1_))
	l1l11l1l1ll_l1_ = False
	if l1l1l11l1lll_l1_ or l1l11lllll1l_l1_:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭刕"),l1l1ll_l1_ (u"ࠧࠨ刖"),l1l1ll_l1_ (u"ࠨࠩ列"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ刘"),l1l1ll_l1_ (u"ࠪห้ฮั็ษ่ะࠥ๎ฬะุ่่๊ࠢษࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳࠴࠮ࠡไาࠤ๏้่็่ࠢ฽฼๊ࠠฤ๊่ࠣฬฺ๊ࠦ็็ࠤอ฻่าหูࠣา๐อสࠢ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝่ๆࠣฮึ๐ฯࠡวุ่ฬำ่ࠠา๊ࠤฬ๊ๅีๅ็อࠥอไร่ࠣรࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭则"))
		if yes==1:
			l1ll1111ll11_l1_ = True
			if l1l11l11l111_l1_:
				l1ll1111ll11_l1_ = l1ll111l1l1l_l1_(False)
			l1l11ll1ll11_l1_ = True
			if l1l1l11l1lll_l1_:
				for addon_id in l1l1lll11lll_l1_: l1l1l1ll1111_l1_(addon_id)
				l1l11ll1ll11_l1_ = True
			l1l1l1l1l111_l1_ = True
			if l1l11lllll1l_l1_:
				conn = sqlite3.connect(l1l1lll111l1_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1l1ll11l11l_l1_:
					if l1l1ll_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࠧ刚") in addon_id: l1ll11l111ll_l1_ = addon_id
					else: l1ll11l111ll_l1_ = l1l1ll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ创")
					try: cc.execute(l1l1ll_l1_ (u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪ刜")+l1ll11l111ll_l1_+l1l1ll_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭初")+addon_id+l1l1ll_l1_ (u"ࠨࠤࠣ࠿ࠬ刞"))
					except: l1l1l1l1l111_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭刟"))
			time.sleep(1)
			if l1ll1111ll11_l1_ or l1l11ll1ll11_l1_ or l1l1l1l1l111_l1_:
				l1l11l1l1ll_l1_ = False
				DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ删"),l1l1ll_l1_ (u"ࠫࠬ刡"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ刢"),l1l1ll_l1_ (u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡฬไ฽๏๊้ࠠวุ่ฬำࠠศๆอัิ๐หࠡษ็ฮ้่วว์่ࠣัฺ๋๊ࠢศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ刣"))
			else:
				l1l11l1l1ll_l1_ = True
				DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ判"),l1l1ll_l1_ (u"ࠨࠩ別"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ刦"),l1l1ll_l1_ (u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦลึๆสัࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ刧"))
	elif showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ刨"),l1l1ll_l1_ (u"ࠬ࠭利"),l1l1ll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ刪"),l1l1ll_l1_ (u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐ฬะุ่่๊ࠢษࠡใํࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅวูหๆอสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭别"))
	return l1l11l1l1ll_l1_
def l1l11llll1ll_l1_():
	l1l11l11llll_l1_,l1ll111111l1_l1_,l1l11l1l1lll_l1_ = False,l1l1ll_l1_ (u"ࠨࠩ刬"),l1l1ll_l1_ (u"ࠩࠪ刭")
	l1l1lllllll1_l1_,l1l1l1l1l11l_l1_,l1l1l1llll11_l1_ = False,l1l1ll_l1_ (u"ࠪࠫ刮"),l1l1ll_l1_ (u"ࠫࠬ刯")
	l1ll1l11l1l1_l1_ = l1l1l1l1llll_l1_([l1l1ll_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ到"),l1l1ll_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ刱"),l1l1ll_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭刲")])
	for addon_id in [l1l1ll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭刳"),l1l1ll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ刴"),l1l1ll_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ刵")]:
		if addon_id not in list(l1ll1l11l1l1_l1_.keys()): continue
		l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1ll1l_l1_,l1l11llll11_l1_,l1l11lll1l1_l1_,l1ll111ll111_l1_,l1l11l11lll_l1_ = l1ll1l11l1l1_l1_[addon_id]
		if addon_id==l1l1ll_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ制"):
			l1l1lllllll1_l1_ = l1l11l1l1ll_l1_
			l1l1l1l1l11l_l1_ = l1l1ll_l1_ (u"ࠬ࠮ࠧ刷")+l1l11l11l1l_l1_+l1l1ll_l1_ (u"࠭ࠠࠨ券")+TRANSLATE(l1ll111ll111_l1_)+l1l1ll_l1_ (u"ࠧࠪࠩ刹")
			l1l1l1llll11_l1_ = l1l11llll11_l1_
		elif addon_id==l1l1ll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ刺"):
			l1l11l11llll_l1_ = l1l11l11llll_l1_ or l1l11l1l1ll_l1_
			l1ll111111l1_l1_ += l1l1ll_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠩࠩ刻")+l1l11l11l1l_l1_+l1l1ll_l1_ (u"ࠪࠤࠬ刼")+TRANSLATE(l1ll111ll111_l1_)+l1l1ll_l1_ (u"ࠫ࠮࠭刽")
			l1l11l1l1lll_l1_ += l1l1ll_l1_ (u"ࠬࠦࠠ࠭ࠢࠣࠫ刾")+l1l11llll11_l1_
		elif addon_id==l1l1ll_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ刿"):
			l1l1l11l11l1_l1_ = l1l11l1l1ll_l1_
			l1l1l111l11l_l1_ = l1l1ll_l1_ (u"ࠧࠩࠩ剀")+l1l11l11l1l_l1_+l1l1ll_l1_ (u"ࠨࠢࠪ剁")+TRANSLATE(l1ll111ll111_l1_)+l1l1ll_l1_ (u"ࠩࠬࠫ剂")
			l1l11l11l1l1_l1_ = l1l11llll11_l1_
	l1ll111111l1_l1_ = l1ll111111l1_l1_.strip(l1l1ll_l1_ (u"ࠪࠤࠥ࠲ࠠࠡࠩ剃"))
	l1l11l1l1lll_l1_ = l1l11l1l1lll_l1_.strip(l1l1ll_l1_ (u"ࠫࠥࠦࠬࠡࠢࠪ剄"))
	text1  = l1l1ll_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ剅")+l1l1l1llll11_l1_+l1l1ll_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ剆")
	text1 += l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ則")+l1l1ll_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้่ࠣอืๆศ็ฯࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ剈")+l1l1l1l1l11l_l1_+l1l1ll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ剉")
	text1 += l1l1ll_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ削")+l1l1ll_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่๊ࠣิา็ࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ剋")+l1l11l1l1lll_l1_+l1l1ll_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ剌")
	text1 += l1l1ll_l1_ (u"࠭࡜࡯ࠩ前")+l1l1ll_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็้ำุๆࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ剎")+l1ll111111l1_l1_+l1l1ll_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ剏")
	text1 += l1l1ll_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ剐")+l1l1ll_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ剑")+l1l11l11l1l1_l1_+l1l1ll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭剒")
	text1 += l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ剓")+l1l1ll_l1_ (u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ剔")+l1l1l111l11l_l1_+l1l1ll_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ剕")
	l1l11l1l1ll_l1_ = (l1l1lllllll1_l1_ or l1l11l11llll_l1_)
	if l1l11l1l1ll_l1_:
		header = l1l1ll_l1_ (u"ࠨษ็ีัอมࠡฬะำ๏ัࠠฦุสๅฬะࠠไ๊า๎๊ࠥอๅࠢสฺ่๊วไๆࠪ剖")
		text2 = l1l1ll_l1_ (u"ࠩส๊ฯࠦศฮษฯอ๊ࠥสฮัํฯࠥฮั็ษ่ะࠥ฿ๅศัࠣวํࠦสฮัํฯ๋ࠥฮำ่ࠣ฽๊อฯࠨ剗")
	else:
		header = l1l1ll_l1_ (u"ࠪัฬ๊๊ศࠢ็หࠥ๐่อัࠣฮาี๊ฬษอࠤ้ฮั็ษ่ะࠥ฿ๅศัࠣวํࠦๅฯิ้ࠤ฾๋วะࠩ剘")
		text2 = l1l1ll_l1_ (u"ࠫฬ๊ัอษฤࠤสฮไศ฼ࠣห้๋ศา็ฯࠤ฾์ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦส้ษฯ๋่࠭剙")
	text3 = l1l1ll_l1_ (u"๊ࠬใ๋ࠢํ฽ฺ๊๊่ࠠา็ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡ์ฯฬࠥษๆࠡ์ๆ์๋ࠦไะ์ๆࠤๆ๐ࠠไ๊า๎ࡡࡴๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫ剚")
	l1ll1l1111_l1_ = text1+l1l1ll_l1_ (u"࠭࡜࡯࡞ࡱࠫ剛")+text2+l1l1ll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ剜")+text3
	l11llll1l1_l1_(l1l1ll_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ剝"),header,l1ll1l1111_l1_,l1l1ll_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ剞"))
	return
def l1l1ll111l1l_l1_(showDialogs=True,l1l1l1111111_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭剟"),l1l1ll_l1_ (u"ࠫࡊࡓࡁࡅࡡࡄࡈࡉࡕࡎࡔࡡࡇࡉ࡙ࡇࡉࡍࡕࠪ剠"))
	DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ剡"),l1l1ll_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ剢"))
	if showDialogs:
		l1l11llll1ll_l1_()
		l1l1ll1l1l11_l1_()
	if l1l1l1111111_l1_:
		l1l11ll1l1l1_l1_ = l1l1lll11ll1_l1_(False)
		l1l11ll1l11l_l1_ = l1l1ll1l1lll_l1_(showDialogs)
		if not (l1l11ll1l1l1_l1_ or l1l11ll1l11l_l1_):
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ剣"))
	return
def l1ll111l1l1l_l1_(showDialogs=True):
	l1ll1l11l1l1_l1_ = l1l1l1l1llll_l1_([l1l1ll_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ剤")])
	yes,l1ll11111111_l1_,l1ll111lll1l_l1_ = True,True,True
	for addon_id in [l1l1ll_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ剥")]:
		l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1ll1l_l1_,l1l11llll11_l1_,l1l11lll1l1_l1_,l1ll111ll111_l1_,l1l11l11lll_l1_ = l1ll1l11l1l1_l1_[addon_id]
		if l1l11l1l1ll_l1_:
			l1ll11111111_l1_ = False
			break
	if l1ll11111111_l1_:
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ剦"),l1l1ll_l1_ (u"ࠫࠬ剧"),l1l1ll_l1_ (u"ࠬ็อึ่ࠢาื์ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ剨"),l1l1ll_l1_ (u"࠭ๅฯิ้ࠤ฾๋วะ่ࠢ์ั๎ฯࠡ฻้ำ่่ࠦๆใ฼่ࠥ๎ฬศ้ีࠤ้๊วิฬัำฬ๋ࠧ剩"))
		return
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ剪"),l1l1ll_l1_ (u"ࠨࠩ剫"),l1l1ll_l1_ (u"ࠩࠪ剬"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭剭"),l1l1ll_l1_ (u"๊ࠫิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࡞ࡱࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦโะ์่ࠤศ๎ࠠๆใๅ์ิࠦร้่ࠢฮํ่แࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥอไๆึๆ่ฮࠦวๅฤ้ࠤฤ࠭剮"))
		if yes!=1: return
	if yes==1:
		for addon_id in [l1l1ll_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ副")]:
			if addon_id not in list(l1ll1l11l1l1_l1_.keys()): continue
			l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1ll1l_l1_,l1l11llll11_l1_,l1l11lll1l1_l1_,l1ll111ll111_l1_,l1l11l11lll_l1_ = l1ll1l11l1l1_l1_[addon_id]
			succeeded = l1l1l1111ll1_l1_(addon_id,l1l11l11lll_l1_,showDialogs)
			l1ll111lll1l_l1_ = l1ll111lll1l_l1_ and succeeded
	if showDialogs:
		if l1ll111lll1l_l1_: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ剰"),l1l1ll_l1_ (u"ࠧࠨ剱"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ割"),l1l1ll_l1_ (u"ࠩอ้ࠥะหษ์อࠤํะแฺ์็ࠤࡡࡴࠠๆะี๊ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬ剳"))
		else: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ剴"),l1l1ll_l1_ (u"ࠫࠬ創"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ剶"),l1l1ll_l1_ (u"࠭ไๅลึๅ๊ࠥๅࠡ์อ้่์ࠠศๆหี๋อๅอ่๊ࠢࠥหีๅษะࠤฺ๊ใๅห࡟ࡲ๋ࠥฮำ่ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ剷"))
	return l1ll111lll1l_l1_
	#xbmc.executebuiltin(l1l1ll_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ剸")+sys.argv[0]+l1l1ll_l1_ (u"ࠨࡁࡰࡳࡩ࡫࠽࠳࠸࠳ࠫ剹")+l1l1ll_l1_ (u"ࠤࠬࠦ剺"))
	#xbmc.executebuiltin(l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ剻"))
def l1l1l1111ll1_l1_(addon_id,l1l11l11lll_l1_,showDialogs=True):
	succeeded = False
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࠬ剼"),l1l1ll_l1_ (u"ࠬ࠭剽"),l1l1ll_l1_ (u"࠭ࠧ剾"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剿"),l1l1ll_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫ劀"))
		if yes!=1: return False
	l1l11l1l1l1l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1l11l11lll_l1_)
	if l1l11l1l1l1l_l1_:
		import zipfile,io
		l1l1l1l11ll1_l1_ = io.BytesIO(l1l11l1l1l1l_l1_)
		zf = zipfile.ZipFile(l1l1l1l11ll1_l1_)
		zf.extractall(l1ll1llll1_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭劁"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭劂")+addon_id+l1l1ll_l1_ (u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ劃"))
		if l1l1ll_l1_ (u"ࠬࡕࡋࠨ劄") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l1l1ll_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ劅"),l1l1ll_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ劆"))
	if showDialogs:
		if succeeded: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ劇"),l1l1ll_l1_ (u"ࠩࠪ劈"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭劉"),l1l1ll_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ劊"))
		else: DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭劋"),l1l1ll_l1_ (u"࠭ࠧ劌"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ劍"),l1l1ll_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭劎"))
	return succeeded
	l1l1ll_l1_ (u"ࠤࠥࠦࠏࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࡦࡳࡳࡴࠠ࠾ࠢࡶࡵࡱ࡯ࡴࡦ࠵࠱ࡧࡴࡴ࡮ࡦࡥࡷࠬࡦࡪࡤࡰࡰࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡹ࡫ࡸࡵࡡࡩࡥࡨࡺ࡯ࡳࡻࠣࡁࠥࡹࡴࡳࠌࠌࡧࡨࠦ࠽ࠡࡥࡲࡲࡳ࠴ࡣࡶࡴࡶࡳࡷ࠮ࠩࠋࠋࡦࡧ࠳࡫ࡸࡦࡥࡸࡸࡪ࠮ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ࠯ࡦࡪࡤࡰࡰࡢ࡭ࡩ࠱ࠧࠣࠩࠬࠎࠎࡩ࡯࡯ࡰ࠱ࡧࡴࡳ࡭ࡪࡶࠫ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡲ࡯ࡴࡧࠫ࠭ࠏࠏࠢࠣࠤ劏")
def l1l1ll11lll1_l1_(addon_id,showDialogs=True):
	if showDialogs==l1l1ll_l1_ (u"ࠪࠫ劐"): showDialogs = True
	#l1ll11111l11_l1_ = xbmc.getCondVisibility(l1l1ll_l1_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࠧ劑")+addon_id+l1l1ll_l1_ (u"ࠬ࠯ࠧ劒"))
	l1l1lll1l11l_l1_ = l1l11lll1lll_l1_([addon_id])
	l1l1lll11l1l_l1_,l1ll11111l11_l1_ = l1l1lll1l11l_l1_[addon_id]
	if l1ll11111l11_l1_:
		succeeded = True
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ劓"),l1l1ll_l1_ (u"ࠧࠨ劔"),l1l1ll_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ劕"),l1l1ll_l1_ (u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫ劖")+addon_id+l1l1ll_l1_ (u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭劗"))
	else:
		succeeded = False
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ劘"),l1l1ll_l1_ (u"ࠬ࠭劙"),l1l1ll_l1_ (u"࠭ࠧ劚"),l1l1ll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ力"),l1l1ll_l1_ (u"ࠨࠩ劜")+addon_id+l1l1ll_l1_ (u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤ๏฿ๅๅࠢส่อืๆศ็ฯࠤ฾์ฯไࠢหูํืษࠡืะ๎าฯࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧ劝"))
		if yes==1:
			xbmc.executebuiltin(l1l1ll_l1_ (u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪࠪ办")+addon_id+l1l1ll_l1_ (u"ࠫ࠮࠭功"))
			time.sleep(1)
			xbmc.executebuiltin(l1l1ll_l1_ (u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ加"))
			time.sleep(1)
			while xbmc.getCondVisibility(l1l1ll_l1_ (u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪ务")): time.sleep(1)
			result = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ劢")+addon_id+l1l1ll_l1_ (u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭劣"))
			if l1l1ll_l1_ (u"ࠩࡒࡏࠬ劤") in result:
				succeeded = True
				if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ劥"),l1l1ll_l1_ (u"ࠫࠬ劦"),l1l1ll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ劧"),l1l1ll_l1_ (u"࠭สๆࠢไัฺࠦร้ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬ动"))
			elif showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ助"),l1l1ll_l1_ (u"ࠨࠩ努"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劫"),l1l1ll_l1_ (u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬ劬"))
	return succeeded
def l1l1l1l11lll_l1_(addon_id,showDialogs=True):
	l1ll1l11l1l1_l1_ = l1l1l1l1llll_l1_([addon_id])
	if addon_id not in list(l1ll1l11l1l1_l1_.keys()): return False
	l1l11l1l1ll_l1_,l1l11l11l1l_l1_,l1l11l1ll1l_l1_,l1l11llll11_l1_,l1l11lll1l1_l1_,l1ll111ll111_l1_,l1l11l11lll_l1_ = l1ll1l11l1l1_l1_[addon_id]
	succeeded,l1l1ll1ll1ll_l1_ = False,l1l1ll_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ劭")
	if l1ll111ll111_l1_==l1l1ll_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ劮"):
		succeeded = True
		l1l1ll1ll1ll_l1_ = l1l1ll_l1_ (u"࠭ࡧࡰࡱࡧࠫ劯")
	elif l1ll111ll111_l1_==l1l1ll_l1_ (u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ劰"):
		succeeded = False
		result = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫ励")+addon_id+l1l1ll_l1_ (u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ劲"))
		if l1l1ll_l1_ (u"ࠪࡓࡐ࠭劳") in result: succeeded = True
		if succeeded: l1l1ll1ll1ll_l1_ = l1l1ll_l1_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬ労")
	elif l1ll111ll111_l1_==l1l1ll_l1_ (u"ࠬࡵ࡬ࡥࠩ劵"):
		succeeded = l1l1l1111ll1_l1_(addon_id,l1l11l11lll_l1_,showDialogs)
		if succeeded: l1l1ll1ll1ll_l1_ = l1l1ll_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧ劶")
	elif l1ll111ll111_l1_==l1l1ll_l1_ (u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ劷"):
		l1l1l1l1ll1l_l1_ = l1ll111l1l1l_l1_(showDialogs)
		if l1l1l1l1ll1l_l1_:
			succeeded = l1l1ll11lll1_l1_(addon_id,showDialogs)
			if succeeded: l1l1ll1ll1ll_l1_ = l1l1ll_l1_ (u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫ劸")
	l1l11ll1111l_l1_ = l1l11llll11_l1_
	return succeeded,l1l1ll1ll1ll_l1_,l1l11ll1111l_l1_
def l1l1ll11ll1l_l1_(l1l1lll1lll1_l1_=l1l1ll_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ効"),showDialogs=True):
	l1l11l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭劺"))
	import json
	data = json.loads(l1l11l1lllll_l1_)
	l1l11l1lll1l_l1_ = data[l1l1ll_l1_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫ劻")][l1l1ll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ劼")]
	if kodi_version<19: l1l11l1lll1l_l1_ = l1l11l1lll1l_l1_.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ劽"))
	if showDialogs:
		yes = DIALOG_YESNO(l1l1ll_l1_ (u"ࠧࠨ劾"),l1l1ll_l1_ (u"ࠨࠩ势"),l1l1ll_l1_ (u"ࠩࠪ勀"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭勁"),l1l1ll_l1_ (u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩ勂")+l1l11l1lll1l_l1_+l1l1ll_l1_ (u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧ勃")+l1l1lll1lll1_l1_+l1l1ll_l1_ (u"࠭ࠠภࠣࠪ勄"))
		if yes!=1: return False
	succeeded,l1l1ll1ll1ll_l1_,l1l11ll1111l_l1_ = l1l1l1l11lll_l1_(l1l1lll1lll1_l1_,False)
	if succeeded:
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ勅"),l1l1ll_l1_ (u"ࠨࠩ勆"),l1l1ll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ勇"),l1l1ll_l1_ (u"ࠪฮ๊ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไอๆาࠤฬ๊ฬะ์าࠤํํ่ࠡฮส๋ืࠦไๅษึฮำีวๆࠢ࠱ࠤุ๎แࠡ์อ้ࠥอไร่ࠣฮ฿๐๊าࠢศ฽ิอฯศฬࠣ็ํี๊ࠡๆๆ๎ࠥ๐ำห฻่่ࠥอไอๆาࠤฬ๊ฬะ์าࠤอีไศ่๊ࠢࠥอไใัํ้ࠬ勈"))
		result = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀࠢࠨ勉")+l1l1lll1lll1_l1_+l1l1ll_l1_ (u"ࠬࠨࡽࡾࠩ勊"))
		if l1l1ll_l1_ (u"࠭ࡏࡌࠩ勋") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l1l1ll_l1_ (u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯ࠧ勌"))
	elif showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ勍"),l1l1ll_l1_ (u"ࠩࠪ勎"),l1l1ll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭勏"),l1l1ll_l1_ (u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯ่ࠦหใ฼๎้ࠦวๅฮ็ำࠥอไๆู็์อ࠭勐"))
	return succeeded
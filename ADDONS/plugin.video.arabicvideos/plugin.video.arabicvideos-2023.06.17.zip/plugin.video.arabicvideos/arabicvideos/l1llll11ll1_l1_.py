# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ⍰")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡈࡋࡓࡥࠧ⍱")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ⍲"),l1l1ll_l1_ (u"ࠪห้้ไࠨ⍳"),l1l1ll_l1_ (u"ࠫࡳ࠵ࡁࠨ⍴"),l1l1ll_l1_ (u"ࠬอไๆิํำࠬ⍵"),l1l1ll_l1_ (u"࠭โึหࠣ฽ู่ࠧ⍶")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l11l1l_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l11ll1l_l1_(url)
	elif mode==434: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭⍷")+text)
	elif mode==435: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࡣࡤࡥࠧ⍸")+text)
	elif mode==436: results = l1ll1l_l1_(url)
	elif mode==437: results = l11111ll1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭⍹"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪ⍺"),l1l1ll_l1_ (u"ࠫࠬ⍻"),l1l1ll_l1_ (u"ࠬ࠭⍼"),l1l1ll_l1_ (u"࠭ࠧ⍽"),l1l1ll_l1_ (u"ࠧࠨ⍾"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⍿"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡦࡴ࡯࡯࡫ࡦࡥࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⎀"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ⎁"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ⎂"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⎃"),menu_name+l1l1ll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⎄"),l1l1ll_l1_ (u"ࠧࠨ⎅"),439,l1l1ll_l1_ (u"ࠨࠩ⎆"),l1l1ll_l1_ (u"ࠩࠪ⎇"),l1l1ll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⎈"))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎉"),menu_name+l1l1ll_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ⎊"),l11ll1_l1_,435)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎋"),menu_name+l1l1ll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ⎌"),l11ll1_l1_,434)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⎍"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⎎"),l1l1ll_l1_ (u"ࠪࠫ⎏"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎐"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎑")+menu_name+l1l1ll_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ⎒"),l11ll1_l1_,431)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎓"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎔")+menu_name+l1l1ll_l1_ (u"ࠩสๅ้อๅࠡษ๋๊๊ࠥว๋่ࠪ⎕"),l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵ࠴ࠫ⎖"),436)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎗"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎘")+menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะࠠศ๊้ࠤ้อ๊็ࠩ⎙"),l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠮ࡣ࡯ࡰ࠶࠭⎚"),436)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎛"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⎜")+menu_name+l1l1ll_l1_ (u"ࠪๆฬฬๅสࠢอๅฺ๐ไ๋หࠪ⎝"),l11ll1_l1_,437)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⎞"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⎟"),l1l1ll_l1_ (u"࠭ࠧ⎠"),9999)
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎡"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎢")+menu_name+l1l1ll_l1_ (u"ࠩส่๊๋๊ำหࠪ⎣"),l11ll1_l1_,431,l1l1ll_l1_ (u"ࠪࠫ⎤"),l1l1ll_l1_ (u"ࠫࠬ⎥"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⎦"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎧"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎨")+menu_name+l1l1ll_l1_ (u"ࠨลไ่ฬ๋ࠧ⎩"),l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡴ࠱ࠪ⎪"),436)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎫"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⎬")+menu_name+l1l1ll_l1_ (u"๋ࠬำๅี็หฯ࠭⎭"),l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠭࠲࠱ࠪ⎮"),436)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕ࡬ࡸࡪࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡷࡩࡨࠣࠩ⎯"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⎰"),block,re.DOTALL)
	for link,title in items:
		#if title==l1l1ll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ⎱"): title = l1l1ll_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ⎲")
		if title in l1ll11_l1_: continue
		if title==l1l1ll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭⎳"): continue
		if l1l1ll_l1_ (u"ࠬอ่็ࠢ็ห๏์ࠧ⎴") in title: continue
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎵"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎶")+menu_name+title,link,431)
	return
def l11111ll1_l1_(website=l1l1ll_l1_ (u"ࠨࠩ⎷")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭⎸"),website+l1l1ll_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵࠪ⎹"),l1l1ll_l1_ (u"ࠫࠬ⎺"),l1l1ll_l1_ (u"ࠬ࠭⎻"),l1l1ll_l1_ (u"࠭ࠧ⎼"),l1l1ll_l1_ (u"ࠧࠨ⎽"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⎾"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡧࡦࡴ࡯࡯࡫ࡦࡥࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⎿"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠪ࠳ࠬ⏀"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ⏁"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡌࡪࡵࡷࡈࡷࡵࡰࡦࡦࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡸࡣࡩ࡫ࡱ࡫ࡒࡧࡳࡵࡧࡵࠦࠬ⏂"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⏃"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1ll11_l1_: continue
		link = website+l1l1ll_l1_ (u"ࠧ࠰ࡧࡻࡴࡱࡵࡲࡦ࠱ࡂࠫ⏄")+category+l1l1ll_l1_ (u"ࠨ࠿ࠪ⏅")+value
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏆"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⏇")+menu_name+title,link,431)
	return
def	l1ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ⏈"),l1l1ll_l1_ (u"ࠬ࠭⏉"),l1l1ll_l1_ (u"࠭ࡓࡖࡄࡐࡉࡓ࡛ࠧ⏊"),url)
	#LOG_THIS(l1l1ll_l1_ (u"ࠧࠨ⏋"),link)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ⏌"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭⏍"),url,l1l1ll_l1_ (u"ࠪࠫ⏎"),l1l1ll_l1_ (u"ࠫࠬ⏏"),l1l1ll_l1_ (u"ࠬ࠭⏐"),l1l1ll_l1_ (u"࠭ࠧ⏑"),l1l1ll_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⏒"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⏓"),menu_name+l1l1ll_l1_ (u"ࠩส่ัฺ๋๊ࠩ⏔"),url,431)
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⏕"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯࡮ࡩࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠪ⏖"),block,re.DOTALL)
	for l1111ll11_l1_,title in items:
		if title in l1ll11_l1_: continue
		url2 = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴ࡓ࡯ࡷ࡫ࡨࡷ࠴ࡑࡥࡺࡵ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡁࠬ⏗")+l1111ll11_l1_
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⏘"),menu_name+title,url2,431)
	#addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⏙"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⏚"),l1l1ll_l1_ (u"ࠩࠪ⏛"),9999)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡎࡴ࡮ࡦࡴࡓࡥ࡬࡫ࡆࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠪ⏜"),html,re.DOTALL)
	#block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ⏝"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1ll11_l1_: continue
	#	if l1l1ll_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷ࠴࠭⏞") in url: url2 = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡍࡰࡸ࡬ࡩࡸ࠵ࡔࡦࡴࡰࡷ࠳ࡶࡨࡱࡁࠪ⏟")+category+l1l1ll_l1_ (u"ࠧ࠾ࠩ⏠")+value
	#	elif l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠯ࠪ⏡") in url: url2 = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡖࡩࡷ࡯ࡥࡴ࠱ࡊࡩࡹ࠴ࡰࡩࡲࡂࠫ⏢")+category+l1l1ll_l1_ (u"ࠪࡁࠬ⏣")+value
	#	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏤"),menu_name+title,url2,431)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠬ࠭⏥")):
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⏦"),l1l1ll_l1_ (u"ࠧࠨ⏧"),request,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ⏨"))
	items = []
	if l1l1ll_l1_ (u"ࠩ࠲ࡘࡪࡸ࡭ࡴ࠰ࡳ࡬ࡵ࠭⏩") in url or l1l1ll_l1_ (u"ࠪ࠳ࡌ࡫ࡴ࠯ࡲ࡫ࡴࠬ⏪") in url or l1l1ll_l1_ (u"ࠫ࠴ࡑࡥࡺࡵ࠱ࡴ࡭ࡶࠧ⏫") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1ll_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ⏬"):l1l1ll_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ⏭"),l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⏮"):l1l1ll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ⏯")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⏰"),url2,data2,headers2,l1l1ll_l1_ (u"ࠪࠫ⏱"),l1l1ll_l1_ (u"ࠫࠬ⏲"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⏳"))
		html = response.content
		block = html
	elif request==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⏴"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ⏵"),url,l1l1ll_l1_ (u"ࠨࠩ⏶"),l1l1ll_l1_ (u"ࠩࠪ⏷"),l1l1ll_l1_ (u"ࠪࠫ⏸"),l1l1ll_l1_ (u"ࠫࠬ⏹"),l1l1ll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⏺"))
		html = response.content
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡑࡦࡺࡣࡩࡧࡶࡘࡦࡨ࡬ࡦࠤࠪ⏻"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ⏼"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⏽"),url,l1l1ll_l1_ (u"ࠩࠪ⏾"),l1l1ll_l1_ (u"ࠪࠫ⏿"),l1l1ll_l1_ (u"ࠫࠬ␀"),l1l1ll_l1_ (u"ࠬ࠭␁"),l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ␂"))
		html = response.content
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡕࡧࡧࡪࡰࡤࡸࡪࠨࠧ␃"),html,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࡇࡴࡴࠢࠨ␄"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	if not items: items = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡳࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ␅"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ู้ࠪอ็ะหࠪ␆"),l1l1ll_l1_ (u"ࠫๆ๐ไๆࠩ␇"),l1l1ll_l1_ (u"ࠬอฺ็์ฬࠫ␈"),l1l1ll_l1_ (u"࠭ใๅ์หࠫ␉"),l1l1ll_l1_ (u"ࠧศ฻็ห๋࠭␊"),l1l1ll_l1_ (u"ࠨ้าหๆ࠭␋"),l1l1ll_l1_ (u"่ࠩฬฬืวสࠩ␌"),l1l1ll_l1_ (u"ࠪ฽ึ฼ࠧ␍"),l1l1ll_l1_ (u"๊ࠫํัอษ้ࠫ␎"),l1l1ll_l1_ (u"ࠬอไษ๊่ࠫ␏")]
	for link,title,img in items:
		link = UNQUOTE(link).strip(l1l1ll_l1_ (u"࠭࠯ࠨ␐"))
		#link = unescapeHTML(link)
		title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩ␑"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ␒"),title,re.DOTALL)
		if any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ␓"),menu_name+title,link,432,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"ࠪห้ำไใหࠪ␔") in title:
			title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ␕") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ␖"),menu_name+title,link,433,img)
				l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫ␗") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␘"),menu_name+title,link,431,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␙"),menu_name+title,link,433,img)
	if request!=l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ␚"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡕࡧࡧࡪࡰࡤࡸࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ␛"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ␜"),block,re.DOTALL)
			for link,title in items:
				if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ␝") not in link: link = l11ll1_l1_+link
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				if title!=l1l1ll_l1_ (u"࠭ࠧ␞"): addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ␟"),menu_name+l1l1ll_l1_ (u"ࠨืไัฮࠦࠧ␠")+title,link,431)
		l1111l111_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ␡"),html,re.DOTALL)
		if l1111l111_l1_:
			link = l1111l111_l1_[0]
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␢"),menu_name+l1l1ll_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ␣"),link,431)
	return
def l11ll1l_l1_(url):
	#LOG_THIS(l1l1ll_l1_ (u"ࠬ࠭␤"),l1l1ll_l1_ (u"࠭࠱࠲࠳࠴ࠤࠥ࠭␥")+url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ␦"))
	l1ll1ll_l1_,l1ll1l1_l1_ = [],[]
	if l1l1ll_l1_ (u"ࠨࡇࡳ࡭ࡸࡵࡤࡦࡵ࠱ࡴ࡭ࡶࠧ␧") in url:
		url2,data2 = URLDECODE(url)
		headers2 = {l1l1ll_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ␨"):l1l1ll_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ␩"),l1l1ll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ␪"):l1l1ll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ␫")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡐࡐࡕࡗࠫ␬"),url2,data2,headers2,l1l1ll_l1_ (u"ࠧࠨ␭"),l1l1ll_l1_ (u"ࠨࠩ␮"),l1l1ll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ␯"))
		html = response.content
		l1ll1l1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ␰"),url,l1l1ll_l1_ (u"ࠫࠬ␱"),l1l1ll_l1_ (u"ࠬ࠭␲"),l1l1ll_l1_ (u"࠭ࠧ␳"),l1l1ll_l1_ (u"ࠧࠨ␴"),l1l1ll_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ␵"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ␶"),html,re.DOTALL)
		l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡊࡶࡩࡴࡱࡧࡩࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ␷"),html,re.DOTALL)
	# l11l11_l1_
	if l1ll1ll_l1_:
		img = re.findall(l1l1ll_l1_ (u"ࠫࠧࡵࡧ࠻࡫ࡰࡥ࡬࡫ࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ␸"),html,re.DOTALL)
		img = img[0]
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴࡧࡤࡷࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ␹"),block,re.DOTALL)
		for l111ll_l1_,l1llll11l11_l1_,title in items:
			link = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡊ࡭ࡹࡏࡱࡺࡆࡾࡋ࡬ࡴࡪࡤ࡭ࡰ࡮࠯ࡂ࡬ࡤࡼࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠯ࡲ࡫ࡴࡄ࠭␺")+l1l1ll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴ࠽ࠨ␻")+l1llll11l11_l1_+l1l1ll_l1_ (u"ࠨࠨࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ␼")+l111ll_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ␽"),menu_name+title,link,433,img)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫ␾"))
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ␿"),block,re.DOTALL)
		for link,title,l11111_l1_ in items:
			title = title+l1l1ll_l1_ (u"ࠬࠦࠧ⑀")+l11111_l1_
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⑁"),menu_name+title,link,432,img)
	return
def PLAY(url):
	url2 = url+l1l1ll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ⑂")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⑃"),url2,l1l1ll_l1_ (u"ࠩࠪ⑄"),l1l1ll_l1_ (u"ࠪࠫ⑅"),l1l1ll_l1_ (u"ࠫࠬ⑆"),l1l1ll_l1_ (u"ࠬ࠭⑇"),l1l1ll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⑈"))
	html = response.content
	l11l1_l1_ = []
	l11ll1_l1_ = SERVER(url2,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ⑉"))
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲ࡹࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⑊"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1lll1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑋"),block,re.DOTALL)
		if l1lll1ll1l_l1_:
			l1lll1ll1l_l1_ = l1lll1ll1l_l1_[0]
			#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ⑌"),l1l1ll_l1_ (u"ࠫࠬ⑍"),l1l1ll_l1_ (u"ࠬ࠭⑎"),l1lll1ll1l_l1_)
			items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ⑏"),block,re.DOTALL)
			for server,title in items:
				link = l11ll1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࡃࡸ࡫ࡲࡷࡧࡵࡁࠬ⑐")+server+l1l1ll_l1_ (u"ࠨࠨࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ⑑")+l1lll1ll1l_l1_+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⑒")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⑓")
				l11l1_l1_.append(link)
	# l1l1l1l11_l1_ link
	l1l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮࡫ࡩࡶࡦࡳࡥࠣࡀ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⑔"),html,re.DOTALL)
	if l1l1l1l11_l1_:
		l1l1l1l11_l1_ = l1l1l1l11_l1_[0].replace(l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ⑕"),l1l1ll_l1_ (u"࠭ࠧ⑖"))
		title = SERVER(l1l1l1l11_l1_,l1l1ll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ⑗"))
		link = l1l1l1l11_l1_+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⑘")+title+l1l1ll_l1_ (u"ࠩࡢࡣࡪࡳࡢࡦࡦࠪ⑙")
		l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⑚"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⑛"),block,re.DOTALL)
		for link,title,l11ll1l1_l1_ in items:
			link = link.replace(l1l1ll_l1_ (u"ࠬࡢ࡮ࠨ⑜"),l1l1ll_l1_ (u"࠭ࠧ⑝"))
			if l11ll1l1_l1_!=l1l1ll_l1_ (u"ࠧࠨ⑞"): l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࡡࡢࡣࡤ࠭⑟")+l11ll1l1_l1_
			link = link+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ①")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ②")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ③"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ④"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧ⑤"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨ⑥"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪ⑦"),l1l1ll_l1_ (u"ࠩࠨ࠶࠵࠭⑧"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⑨")+search
	l11l1l_l1_(url)
	return
# ===========================================
#     l1111l1ll_l1_ l1lllllll1_l1_ l1lllll1ll_l1_
# ===========================================
def l1111l1l1_l1_(url):
	url = url.split(l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⑩"))[0]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ⑪"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ⑫"),l11ll1_l1_,l1l1ll_l1_ (u"ࠧࠨ⑬"),l1l1ll_l1_ (u"ࠨࠩ⑭"),l1l1ll_l1_ (u"ࠩࠪ⑮"),l1l1ll_l1_ (u"ࠪࠫ⑯"),l1l1ll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭⑰"))
	html = response.content
	# all l1l1l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡥࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡶࡨ࡮ࡩ࡯ࡩࡐࡥࡸࡺࡥࡳࠤࠪ⑱"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	# name + options block + category
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡥࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠩࠨ⑲"),block,re.DOTALL)
	return l1111ll_l1_
def l1llllllll_l1_(block):
	# value + name
	items = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭ࡢࡤࠬࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⑳"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	#url = url.replace(l1l1ll_l1_ (u"ࠨࡥࡤࡸࡂ࠭⑴"),l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ⑵"))
	l1111111l_l1_ = url.split(l1l1ll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⑶"))[0]
	l11111111_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠫࡺࡸ࡬ࠨ⑷"))
	url = url.replace(l1111111l_l1_,l11111111_l1_)
	url = url.replace(l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⑸"),l1l1ll_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࡁࠪ⑹"))
	return url
def l1llll11l1l_l1_(l1lll111_l1_,url):
	l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⑺")) # l11111l111_l1_ be l11111ll1l_l1_
	url3 = url+l1l1ll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⑻")+l1l1l1l1_l1_
	url3 = l11111lll_l1_(url3)
	return url3
l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⑼"),l1l1ll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ⑽"),l1l1ll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ⑾"),l1l1ll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ⑿")]
l1llll1l_l1_ = [l1l1ll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ⒀"),l1l1ll_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭⒁"),l1l1ll_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ⒂"),l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⒃"),l1l1ll_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ⒄"),l1l1ll_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ⒅")]
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⒆"),l1l1ll_l1_ (u"࠭ࠧ⒇"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ⒈"),l1l1ll_l1_ (u"ࠨࠩ⒉"),filter,url)
	if l1l1ll_l1_ (u"ࠩࡂࠫ⒊") in url: url = url.split(l1l1ll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⒋"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ⒌"),1)
	if filter==l1l1ll_l1_ (u"ࠬ࠭⒍"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"࠭ࠧ⒎"),l1l1ll_l1_ (u"ࠧࠨ⒏")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ⒐"))
	if type==l1l1ll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⒑"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠪࡁࠬ⒒") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠫࡂ࠭⒓") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ⒔")+category+l1l1ll_l1_ (u"࠭࠽࠱ࠩ⒕")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠩ⒖")+category+l1l1ll_l1_ (u"ࠨ࠿࠳ࠫ⒗")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠩࠩࠫ⒘"))+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ⒙")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠫࠫ࠭⒚"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⒛")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		url2 = url+l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⒜")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪ⒝"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⒞")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠩࠪ⒟"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⒠")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠫࠬ⒡"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⒢")+l1l1ll1l_l1_
		url2 = l11111lll_l1_(url2)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⒣"),menu_name+l1l1ll_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ⒤"),url2,431)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒥"),menu_name+l1l1ll_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ⒦")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ⒧"),url2,431)
		addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⒨"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⒩"),l1l1ll_l1_ (u"࠭ࠧ⒪"),9999)
	l1111ll_l1_ = l1111l1l1_l1_(url)
	dict = {}
	for name,block,l11111l_l1_ in l1111ll_l1_:
		name = name.replace(l1l1ll_l1_ (u"ࠧ࠮࠯ࠪ⒫"),l1l1ll_l1_ (u"ࠨࠩ⒬"))
		items = l1llllllll_l1_(block)
		if l1l1ll_l1_ (u"ࠩࡀࠫ⒭") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⒮"):
			if category!=l11111l_l1_: continue
			elif len(items)<2:
				if l11111l_l1_==l1ll1111_l1_[-1]:
					url = l11111lll_l1_(url)
					l11l1l_l1_(url)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⒯")+l1ll11l1_l1_)
				return
			else:
				url2 = l11111lll_l1_(url2)
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⒰"),menu_name+l1l1ll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ⒱"),url2,431)
				else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒲"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ⒳"),url2,435,l1l1ll_l1_ (u"ࠩࠪ⒴"),l1l1ll_l1_ (u"ࠪࠫ⒵"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧⒶ"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠧⒷ")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽࠱ࠩⒸ")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠩⒹ")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿࠳ࠫⒺ")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭Ⓕ")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⒼ"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭Ⓗ")+name,url2,434,l1l1ll_l1_ (u"ࠬ࠭Ⓘ"),l1l1ll_l1_ (u"࠭ࠧⒿ"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩⓀ"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if value==l1l1ll_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠳ࠨⓁ"): option = l1l1ll_l1_ (u"ࠩฦๅ้อๅ่ࠡํฮๆ๊ใิࠩⓂ")
			elif value==l1l1ll_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠳ࠪⓃ"): option = l1l1ll_l1_ (u"ู๊ࠫไิๆสฮࠥ์๊หใ็็ุ࠭Ⓞ")
			if option in l1ll11_l1_: continue
			#if l1l1ll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫⓅ") not in value: value = option
			#else: value = re.findall(l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧⓆ"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠧࠧࠩⓇ")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࠪⓈ")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠩࠩࠫⓉ")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࠬⓊ")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨⓋ")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠬࠦ࠺ࠨⓌ")#+dict[l11111l_l1_][l1l1ll_l1_ (u"࠭࠰ࠨⓍ")]
			title = option+l1l1ll_l1_ (u"ࠧࠡ࠼ࠪⓎ")+name
			if type==l1l1ll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫⓏ"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓐ"),menu_name+title,url,434,l1l1ll_l1_ (u"ࠪࠫⓑ"),l1l1ll_l1_ (u"ࠫࠬⓒ"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧⓓ"))
			elif type==l1l1ll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩⓔ") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠧ࠾ࠩⓕ") in l1l1lll1_l1_:
				url3 = l1llll11l1l_l1_(l1lll111_l1_,url)
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓖ"),menu_name+title,url3,431)
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⓗ"),menu_name+title,url,435,l1l1ll_l1_ (u"ࠪࠫⓘ"),l1l1ll_l1_ (u"ࠫࠬⓙ"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ⓚ"),l1l1ll_l1_ (u"࠭ࠧⓛ"),filters,l1l1ll_l1_ (u"ࠧࡓࡇࡆࡓࡓ࡙ࡔࡓࡗࡆࡘࡤࡌࡉࡍࡖࡈࡖࠥ࠷࠱ࠨⓜ"))
	# mode==l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪⓝ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬⓞ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨⓟ")			all l1ll1l1l_l1_ & l1111l11l_l1_ filters
	filters = filters.replace(l1l1ll_l1_ (u"ࠫࡂࠬࠧⓠ"),l1l1ll_l1_ (u"ࠬࡃ࠰ࠧࠩⓡ"))
	filters = filters.strip(l1l1ll_l1_ (u"࠭ࠦࠨⓢ"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠧ࠾ࠩⓣ") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠨࠨࠪⓤ"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠩࡀࠫⓥ"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠪࠫⓦ")
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠫ࠵࠭ⓧ")
		if l1l1ll_l1_ (u"ࠬࠫࠧⓨ") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨⓩ") and value!=l1l1ll_l1_ (u"ࠧ࠱ࠩ⓪"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠢ࠮ࠤࠬ⓫")+value
		elif mode==l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⓬") and value!=l1l1ll_l1_ (u"ࠪ࠴ࠬ⓭"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭⓮")+key+l1l1ll_l1_ (u"ࠬࡃࠧ⓯")+value
		elif mode==l1l1ll_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⓰"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠧࠧࠩ⓱")+key+l1l1ll_l1_ (u"ࠨ࠿ࠪ⓲")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠩࠣ࠯ࠥ࠭⓳"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠪࠪࠬ⓴"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠫࡂ࠶ࠧ⓵"),l1l1ll_l1_ (u"ࠬࡃࠧ⓶"))
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⓷"),l1l1ll_l1_ (u"ࠧࠨ⓸"),filters,l1l1ll_l1_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠲࠳ࠩ⓹"))
	return l1llllll_l1_
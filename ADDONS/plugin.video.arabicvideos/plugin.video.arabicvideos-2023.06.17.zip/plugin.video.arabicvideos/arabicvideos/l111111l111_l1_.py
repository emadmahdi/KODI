# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭墑")
menu_name = l1l1ll_l1_ (u"ࠨࡡࡗ࡚ࡋࡥࠧ墒")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩหฯ๋ࠥศศึิࠫ墓")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l11l1l_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l11ll1l_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ墔"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬ墕"),l1l1ll_l1_ (u"ࠬ࠭墖"),l1l1ll_l1_ (u"࠭ࠧ増"),l1l1ll_l1_ (u"ࠧࠨ墘"),l1l1ll_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ墙"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墚"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ墛"),l1l1ll_l1_ (u"ࠫࠬ墜"),469,l1l1ll_l1_ (u"ࠬ࠭墝"),l1l1ll_l1_ (u"࠭ࠧ增"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ墟"))
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墠"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ墡")+menu_name+l1l1ll_l1_ (u"ࠪวำืࠠศๆะ่็อสࠨ墢"),l1l1l1_l1_,461,l1l1ll_l1_ (u"ࠫࠬ墣"),l1l1ll_l1_ (u"ࠬ࠭墤"),l1l1ll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭墥"))
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ墦"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ墧"),l1l1ll_l1_ (u"ࠩࠪ墨"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡲ࡫࡮ࡶ࠯ࡥࡸࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ墩"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ墪"),block,re.DOTALL)
		for link,title in items:
			#if link==l1l1ll_l1_ (u"ࠬࠩࠧ墫"): continue
			if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ墬") not in link: link = l1l1l1_l1_+link
			if title==l1l1ll_l1_ (u"ࠧศๆิส๏ู๊สࠩ墭"): title = l1l1ll_l1_ (u"ࠨฮา๎ิࠦอๅไสฮࠥะ๊โ์ࠣๅฬ์ࠧ墮")
			if title in l1ll11_l1_: continue
			addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墯"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ墰")+menu_name+title,link,461)
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡌ࡯ࡰࡶࡨࡶࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ墱"),html,re.DOTALL)
	#if l1lll11_l1_:
	#	block = l1lll11_l1_[0]
	#	items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ墲"),block,re.DOTALL)
	#	for link,title in items:
	#		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭墳"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ墴")+menu_name+title,link,461)
	return
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"ࠨࠩ墵")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ墶"),l1l1ll_l1_ (u"ࠪࠫ墷"),l1111ll11_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ墸"),url,l1l1ll_l1_ (u"ࠬ࠭墹"),l1l1ll_l1_ (u"࠭ࠧ墺"),l1l1ll_l1_ (u"ࠧࠨ墻"),l1l1ll_l1_ (u"ࠨࠩ墼"),l1l1ll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ墽"))
	html = response.content
	if l1111ll11_l1_!=l1l1ll_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ墾"): l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭ࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠭墿"),html,re.DOTALL)
	else: l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠦࠬ壀"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ壁"),block,re.DOTALL)
		l1l1_l1_ = []
		l111l_l1_ = [l1l1ll_l1_ (u"ࠧๆึส๋ิฯࠧ壂"),l1l1ll_l1_ (u"ࠨใํ่๊࠭壃"),l1l1ll_l1_ (u"ࠩส฾๋๐ษࠨ壄"),l1l1ll_l1_ (u"ࠪ็้๐ศࠨ壅"),l1l1ll_l1_ (u"ࠫฬ฿ไศ่ࠪ壆"),l1l1ll_l1_ (u"ࠬํฯศใࠪ壇"),l1l1ll_l1_ (u"࠭ๅษษิหฮ࠭壈"),l1l1ll_l1_ (u"ฺࠧำูࠫ壉"),l1l1ll_l1_ (u"ࠨ็๊ีัอๆࠨ壊"),l1l1ll_l1_ (u"ࠩส่อ๎ๅࠨ壋")]
		for link,title,img in items:
			if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ壌") not in link: link = l1l1l1_l1_+link
			link = UNQUOTE(link)	#.strip(l1l1ll_l1_ (u"ࠫ࠴࠭壍"))
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ壎"),title,re.DOTALL)
			if any(value in title for value in l111l_l1_):
				addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ壏"),menu_name+title,link,462,img)
			elif l11111_l1_ and l1l1ll_l1_ (u"ࠧศๆะ่็ฯࠧ壐") in title:
				title = l1l1ll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ壑") + l11111_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ壒"),menu_name+title,link,463,img)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壓"),menu_name+title,link,463,img)
	if l1111ll11_l1_!=l1l1ll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ壔"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ壕"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ壖"),block,re.DOTALL)
			for link,title in items:
				link = link.strip(l1l1ll_l1_ (u"ࠧࠡࠩ壗"))
				if link==l1l1ll_l1_ (u"ࠣࠤ壘"): continue
				if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ壙") not in link: link = l1l1l1_l1_+link
				#title = unescapeHTML(title)
				if title!=l1l1ll_l1_ (u"ࠪࠫ壚"): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ壛"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ壜")+title,link,461)
	return
def l11ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ壝"),l1l1ll_l1_ (u"ࠧࠨ壞"),l1l1ll_l1_ (u"ࠨࡇࡓࡍࡘࡕࡄࡆࡕࠪ壟"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭壠"),url,l1l1ll_l1_ (u"ࠪࠫ壡"),l1l1ll_l1_ (u"ࠫࠬ壢"),l1l1ll_l1_ (u"ࠬ࠭壣"),l1l1ll_l1_ (u"࠭ࠧ壤"),l1l1ll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ壥"))
	html = response.content
	# l1ll1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡥࡢࡦ࠰ࡸ࡮ࡺ࡬ࡦࠤࠪ壦"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ壧"),block,re.DOTALL)
		for link,title,img in items:
			if l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ壨") not in link: link = l1l1l1_l1_+link
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ壩"),menu_name+title,link,462,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ壪"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ士"),block,re.DOTALL)
		for link,title in items:
			link = link.strip(l1l1ll_l1_ (u"ࠧࠡࠩ壬"))
			if link==l1l1ll_l1_ (u"ࠣࠤ壭"): continue
			if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ壮") not in link: link = l1l1l1_l1_+link
			#title = unescapeHTML(title)
			if title!=l1l1ll_l1_ (u"ࠪࠫ壯"): addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ声"),menu_name+l1l1ll_l1_ (u"ࠬ฻แฮหࠣࠫ壱")+title,link,463)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ売"),url,l1l1ll_l1_ (u"ࠧࠨ壳"),l1l1ll_l1_ (u"ࠨࠩ壴"),l1l1ll_l1_ (u"ࠩࠪ壵"),l1l1ll_l1_ (u"ࠪࠫ壶"),l1l1ll_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ壷"))
	html = response.content
	# l1l1l1l11_l1_ link
	l111l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨ࡚ࡸ࡬ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ壸"),html,re.DOTALL)
	if l111l11l1l_l1_:
		l111l11l1l_l1_ = l111l11l1l_l1_[0]
		if l1l1ll_l1_ (u"࠭ࡨࡵࡶࡳࠫ壹") not in l111l11l1l_l1_:
			if l1l1ll_l1_ (u"ࠧ࠰࠱ࠪ壺") in l111l11l1l_l1_: l111l11l1l_l1_ = l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ壻")+l111l11l1l_l1_
			else: l111l11l1l_l1_ = l1l1l1_l1_+l111l11l1l_l1_
		l111l11l1l_l1_ = l111l11l1l_l1_+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ壼")
		l11l1_l1_.append(l111l11l1l_l1_)
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡦ࠶࠻࠺ࡣࡧࡩࡳࡷ࡫ࠨ࠯ࠬࡂ࠭ࡸࡳࡡ࡭࡮࠱࠮ࡄࠨࡖࡪࡦࡨࡳࡘ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࠦࡕࡲࡡࡺࠤࠪ壽"),html,re.DOTALL)
	if l1lll11_l1_:
		l1l111l1111l_l1_,l1l111l111l1_l1_ = l1lll11_l1_[0]
		names = re.findall(l1l1ll_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ壾"),l1l111l1111l_l1_,re.DOTALL)
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡹࡥࡵࡘ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦ壿"),l1l111l111l1_l1_,re.DOTALL)
		l1l111l11111_l1_ = zip(names,l1ll_l1_)
		for name,l1ll1l11llll_l1_ in l1l111l11111_l1_:
			l1ll1l11llll_l1_ = l1ll1l11llll_l1_[2:]
			if kodi_version<19: l1ll1l11llll_l1_ = l1ll1l11llll_l1_.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ夀"))
			l1ll1l11llll_l1_ = base64.b64decode(l1ll1l11llll_l1_)
			if kodi_version>18.99: l1ll1l11llll_l1_ = l1ll1l11llll_l1_.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ夁"))
			link = re.findall(l1l1ll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭夂"),l1ll1l11llll_l1_,re.DOTALL)
			link = link[0]
		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ夃") not in link:
			if l1l1ll_l1_ (u"ࠪ࠳࠴࠭处") in link: link = l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ夅")+link
			else: link = l1l1l1_l1_+link
			link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭夆")+name+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ备")
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ夈"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ変"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l1l1ll_l1_ (u"ࠩࠣࠫ夊") in search:
		if showDialogs: DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ夋"),l1l1ll_l1_ (u"ࠫࠬ夌"),l1l1ll_l1_ (u"࡚ࠬࡖࡇࡗࡑࠤ๊๎โฺࠢอ๎ๆ๐ࠠโษ้ࠫ复"),l1l1ll_l1_ (u"࠭ไๅลึๅࠥอไษฯฮࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ้อ๋ࠠ฻่่ࠥ฿ๆะฺ่ࠢอࠦรไอิࠤ๊์ࠠไๆ่อࠥ๎วฮัฬࠤ࠳࠴࠮ࠡ์ิะ๎ࠦวๅสะฯࠥ฿ๆࠡๅ็้ฮ่ࠦศฯาอࠥ็โุࠩ夎"))
		return
	#search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ夏"),l1l1ll_l1_ (u"ࠨ࠯ࠪ夐"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ夑")+search
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡶ࠵ࠧ夒")+search+l1l1ll_l1_ (u"ࠫ࠴࠭夓")
	l11l1l_l1_(url)
	return
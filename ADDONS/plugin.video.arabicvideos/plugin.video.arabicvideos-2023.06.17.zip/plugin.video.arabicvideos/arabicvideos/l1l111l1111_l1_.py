# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ㼯")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡎ࠶ࡘࡣࠬ㼰")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧศ่๋ห฾ࠦวโๆส้ࠬ㼱"),l1l1ll_l1_ (u"ࠨฮ๋ำฬะࠠศใ็ห๊࠭㼲")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l11l1l_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l11ll1l_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㼳"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ㼴"),l1l1ll_l1_ (u"ࠫࠬ㼵"),389,l1l1ll_l1_ (u"ࠬ࠭㼶"),l1l1ll_l1_ (u"࠭ࠧ㼷"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㼸"))
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㼹"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㼺"),l1l1ll_l1_ (u"ࠪࠫ㼻"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㼼"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㼽")+menu_name+l1l1ll_l1_ (u"࠭วๅ็่๎ืฯࠧ㼾"),l1l1l1_l1_,381,l1l1ll_l1_ (u"ࠧࠨ㼿"),l1l1ll_l1_ (u"ࠨࠩ㽀"),l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㽁"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㽂"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㽃")+menu_name+l1l1ll_l1_ (u"ࠬอไอษ้ฬ๏ฯࠧ㽄"),l1l1l1_l1_,381,l1l1ll_l1_ (u"࠭ࠧ㽅"),l1l1ll_l1_ (u"ࠧࠨ㽆"),l1l1ll_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ㽇"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭㽈"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ㽉"),l1l1ll_l1_ (u"ࠫࠬ㽊"),l1l1ll_l1_ (u"ࠬ࠭㽋"),l1l1ll_l1_ (u"࠭ࠧ㽌"),l1l1ll_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㽍"))
	html = response.content
	items = re.findall(l1l1ll_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㽎"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㽏"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㽐")+menu_name+title,l1l1l1_l1_,381,l1l1ll_l1_ (u"ࠫࠬ㽑"),l1l1ll_l1_ (u"ࠬ࠭㽒"),l1l1ll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭㽓")+str(seq))
	block = l1l1ll_l1_ (u"ࠧࠨ㽔")
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡦࡦࡲࡶࠧ࠭㽕"),html,re.DOTALL)
	if l1lll11_l1_: block += l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭㽖"),html,re.DOTALL)
	if l1lll11_l1_: block += l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㽗"),block,re.DOTALL)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㽘"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㽙"),l1l1ll_l1_ (u"࠭ࠧ㽚"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l1l1ll_l1_ (u"ࠧศๆฦ฽้๏ࠠๆึส๋ิฯࠧ㽛"):
			if first:
				title = l1l1ll_l1_ (u"ࠨษ็หๆ๊วๆࠢࠪ㽜")+title
				first = False
			else: title = l1l1ll_l1_ (u"ࠩสู่๊ไิๆสฮࠥ࠭㽝")+title
		if title not in l1ll11_l1_:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㽞"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㽟")+menu_name+title,link,381)
	return html
def l11l1l_l1_(url,type):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭㽠"),l1l1ll_l1_ (u"࠭ࠧ㽡"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ㽢"),url,l1l1ll_l1_ (u"ࠨࠩ㽣"),l1l1ll_l1_ (u"ࠩࠪ㽤"),l1l1ll_l1_ (u"ࠪࠫ㽥"),l1l1ll_l1_ (u"ࠫࠬ㽦"),l1l1ll_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㽧"))
	html = response.content
	if type==l1l1ll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭㽨"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡧࡤࡶࡨ࡮࠭ࡱࡣࡪࡩࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ㽩"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㽪"),block,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ㽫"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺࠧ㽬"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		z = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㽭"),block,re.DOTALL)
		l11l1_l1_,l1l1l111l_l1_,l111l1l_l1_ = zip(*z)
		items = zip(l1l1l111l_l1_,l11l1_l1_,l111l1l_l1_)
	elif type==l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ㽮"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡩࡥ࠿ࠥࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࡵ࠰ࡸࡻࡹࡨࡰࡹࡶࠦ࠭࠴ࠪࡀࠫ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ㽯"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㽰"),block,re.DOTALL)
	elif l1l1ll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㽱") in type:
		seq = int(type[-1:])
		html = html.replace(l1l1ll_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁࠫ㽲"),l1l1ll_l1_ (u"ࠪࡀࡪࡴࡤ࠿࠾ࡶࡸࡦࡸࡴ࠿ࠩ㽳"))
		html = html.replace(l1l1ll_l1_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ㽴"),l1l1ll_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ㽵"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡶࡤࡶࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡮ࡥࡀࠪ㽶"),html,re.DOTALL)
		block = l1lll11_l1_[seq]
		if seq==2: items = re.findall(l1l1ll_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㽷"),block,re.DOTALL)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࠩࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࢁࡹࡩࡥࡧࡥࡥࡷ࠯ࠧ㽸"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0][0]
			if l1l1ll_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ㽹") in url:
				items = re.findall(l1l1ll_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㽺"),block,re.DOTALL)
			elif l1l1ll_l1_ (u"ࠫ࠴ࡷࡵࡢ࡮࡬ࡸࡾ࠵ࠧ㽻") in url:
				items = re.findall(l1l1ll_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㽼"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l1ll_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㽽"),block,re.DOTALL)
	l1l1_l1_ = []
	for img,link,title in items:
		if l1l1ll_l1_ (u"ࠧࡴࡧࡵ࡭ࡪ࠭㽾") in title:
			title = re.findall(l1l1ll_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸ࡫ࡲࡪࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㽿"),title,re.DOTALL)
			title = title[0][1]#+l1l1ll_l1_ (u"ࠩࠣ࠱ࠥ࠭㾀")+title[0][0]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㾁")+title
		title2 = re.findall(l1l1ll_l1_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀࠬ㾂"),title,re.DOTALL)
		if title2: title = title2[0]
		title = unescapeHTML(title)
		if l1l1ll_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ㾃") in link: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾄"),menu_name+title,link,383,img)
		elif l1l1ll_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ㾅") in link: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㾆"),menu_name+title,link,383,img)
		elif l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ㾇") in link: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾈"),menu_name+title,link,383,img)
		elif l1l1ll_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ㾉") in link: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㾊"),menu_name+title,link,381,img)
		else: addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㾋"),menu_name+title,link,382,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࡑࡣࡪࡩࠥ࠮࠮ࠫࡁࠬࠤࡴ࡬ࠠࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㾌"),html,re.DOTALL)
	if l1lll11_l1_:
		current = l1lll11_l1_[0][0]
		last = l1lll11_l1_[0][1]
		block = l1lll11_l1_[0][2]
		items = re.findall(l1l1ll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥ㾍"),block,re.DOTALL)
		for link,title in items:
			if title==l1l1ll_l1_ (u"ࠩࠪ㾎") or title==last: continue
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㾏"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪ㾐")+title,link,381,l1l1ll_l1_ (u"ࠬ࠭㾑"),l1l1ll_l1_ (u"࠭ࠧ㾒"),type)
		#if title==last:
		link = link.replace(l1l1ll_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ㾓")+title+l1l1ll_l1_ (u"ࠨ࠱ࠪ㾔"),l1l1ll_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ㾕")+last+l1l1ll_l1_ (u"ࠪ࠳ࠬ㾖"))
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㾗"),menu_name+l1l1ll_l1_ (u"ࠬอฮาุࠢๅาฯࠠࠨ㾘")+last,link,381,l1l1ll_l1_ (u"࠭ࠧ㾙"),l1l1ll_l1_ (u"ࠧࠨ㾚"),type)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ㾛"),url,l1l1ll_l1_ (u"ࠩࠪ㾜"),l1l1ll_l1_ (u"ࠪࠫ㾝"),l1l1ll_l1_ (u"ࠫࠬ㾞"),l1l1ll_l1_ (u"ࠬ࠭㾟"),l1l1ll_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ㾠"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡄࠢࡵࡥࡹ࡫ࡤࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㾡"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_,False):
		addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㾢"),menu_name+l1l1ll_l1_ (u"ࠩสู่๊ไิๆ่้้ࠣศศำࠣ์ฬ๊ๅษำ่ะ๋ࠥๆฺ้ࠪ㾣"),l1l1ll_l1_ (u"ࠪࠫ㾤"),9999)
		return
	if l1l1ll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ㾥") in url or l1l1ll_l1_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹ࠯ࠨ㾦") in url:
		url2 = re.findall(l1l1ll_l1_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨ࡫ࡷࡩࡲ࠭࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ㾧"),html,re.DOTALL)
		if url2:
			url2 = url2[1]
			l11ll1l_l1_(url2)
			return
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠨࠩࡦࡰࡦࡹࡳ࠾ࠩࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࡷࠬ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡤࡣࡶࡸࠧ࠭ࠧࠨ㾨"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࠩࠪࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡲࡺࡳࡥࡳࡣࡱࡨࡴ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ㾩"),block,re.DOTALL)
		for img,l11111_l1_,link,name in items:
			title = l11111_l1_+l1l1ll_l1_ (u"ࠩࠣ࠾ࠥ࠭㾪")+name+l1l1ll_l1_ (u"ࠪࠤฬ๊อๅไฬࠫ㾫")
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㾬"),menu_name+title,link,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ㾭"),url,l1l1ll_l1_ (u"࠭ࠧ㾮"),l1l1ll_l1_ (u"ࠧࠨ㾯"),l1l1ll_l1_ (u"ࠨࠩ㾰"),l1l1ll_l1_ (u"ࠩࠪ㾱"),l1l1ll_l1_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㾲"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡈࠦࡲࡢࡶࡨࡨࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㾳"),html,re.DOTALL)
	if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	l11l1_l1_ = []
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠨࠢࡪࡦࡀࠫࡵࡲࡡࡺࡧࡵ࠱ࡴࡶࡴࡪࡱࡱ࠱࠶࠭ࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠬࠧࡹࡨࡦࡣࡧࡩࡷࠨࡼࠨࡲࡤ࡫ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧࠪࠤࠥࠦ㾴"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0][0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠫࡸ࡫ࡲࡷࡧࡵࠫࡃ࠮࠮ࠫࡁࠬࡀࠧ㾵"),block,re.DOTALL)
		for link,title in items:
			link = link+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㾶")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㾷")
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡲࡵࡤࡢ࡮ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭࠯ࡦࡰࡴࡹࡥࠣࠩ㾸"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡣࡤࡥࡤ࡭ࡡࡪࡨࡷ࡯ࡶࡦ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㾹"),block,re.DOTALL)
		for link,title in items:
			link = l1l1l1_l1_+link
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㾺")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㾻")
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ㾼"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㾽"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠨࠩ㾾"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠩࠪ㾿"): return
	search = search.replace(l1l1ll_l1_ (u"ࠪࠤࠬ㿀"),l1l1ll_l1_ (u"ࠫ࠰࠭㿁"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵࠿ࡴ࠿ࠪ㿂")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭㿃"))
	return
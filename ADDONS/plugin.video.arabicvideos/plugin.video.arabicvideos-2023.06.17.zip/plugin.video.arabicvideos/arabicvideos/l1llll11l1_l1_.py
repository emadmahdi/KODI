# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖࠧᣠ")
menu_name = l1l1ll_l1_ (u"࠭࡟ࡄࡏࡆࡣࠬᣡ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ์สโๆํ็ุ࠭ᣢ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l11l1l_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l11ll1l_l1_(url)
	elif mode==494: results = l1ll1l_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᣣ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪᣤ"),l1l1ll_l1_ (u"ࠪࠫᣥ"),l1l1ll_l1_ (u"ࠫࠬᣦ"),l1l1ll_l1_ (u"ࠬ࠭ᣧ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᣨ"))
	html = response.content
	l11ll1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᣩ"),html,re.DOTALL)
	l11ll1_l1_ = l11ll1_l1_[0].strip(l1l1ll_l1_ (u"ࠨ࠱ࠪᣪ"))
	l11ll1_l1_ = SERVER(l11ll1_l1_,l1l1ll_l1_ (u"ࠩࡸࡶࡱ࠭ᣫ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᣬ"),menu_name+l1l1ll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᣭ"),l11ll1_l1_,499,l1l1ll_l1_ (u"ࠬ࠭ᣮ"),l1l1ll_l1_ (u"࠭ࠧᣯ"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᣰ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣱ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᣲ")+menu_name+l1l1ll_l1_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩᣳ"),l11ll1_l1_,491,l1l1ll_l1_ (u"ࠫࠬᣴ"),l1l1ll_l1_ (u"ࠬ࠭ᣵ"),l1l1ll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᣶"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᣷"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᣸"),l1l1ll_l1_ (u"ࠩࠪ᣹"),9999)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦ࡫࡯࡬ࡵࡧࡵࠤࡆࡰࡡࡹ࡫ࡩࡽࡋ࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ᣺"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡩ࡭ࡱࡺࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᣻"),block,re.DOTALL)
		for link,title in items:
			if title in l1ll11_l1_: continue
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡳࡱࡪ࠯ࡧ࡫࡯ࡸࡪࡸ࠯ࠨ᣼")+link+l1l1ll_l1_ (u"࠭࠮ࡱࡪࡳࠫ᣽")
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᣾"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᣿")+menu_name+title,link,491)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᤀ"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᤁ"),l1l1ll_l1_ (u"ࠫࠬᤂ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤃ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᤄ")+menu_name+l1l1ll_l1_ (u"ࠧฤใ็ห๊࠭ᤅ"),l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ฬ็ไศ็࠰ࡱࡴࡼࡩࡦࡵ࠰ࡪ࡮ࡲ࡭ࡦ࠱ࡩࡳࡷ࡫ࡩࡨࡰ࠰࡬ࡩ࠳วโๆส้࠲อฬ็ส์࠱࠷࠭ᤆ"),494,l1l1ll_l1_ (u"ࠩࠪᤇ"),l1l1ll_l1_ (u"ࠪࠫᤈ"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᤉ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤊ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᤋ")+menu_name+l1l1ll_l1_ (u"ࠧๆี็ื้อสࠨᤌ"),l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ู๊ไิๆสฮ࠴๋ำๅี็หฯ࠳วอ่หํࠬᤍ"),494,l1l1ll_l1_ (u"ࠩࠪᤎ"),l1l1ll_l1_ (u"ࠪࠫᤏ"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᤐ"))
	addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᤑ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᤒ"),l1l1ll_l1_ (u"ࠧࠨᤓ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᤔ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᤕ"),block,re.DOTALL)
	for link,title in items:
		if link==l1l1ll_l1_ (u"ࠪ࠳ࠬᤖ"): continue
		if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᤗ") not in link: link = l11ll1_l1_+link
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤘ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᤙ")+menu_name+title,link,491)
	return html
def l1ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨᤚ"),l1l1ll_l1_ (u"ࠨࠩᤛ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ᤜ"),url,l1l1ll_l1_ (u"ࠪࠫᤝ"),l1l1ll_l1_ (u"ࠫࠬᤞ"),l1l1ll_l1_ (u"ࠬ࠭᤟"),l1l1ll_l1_ (u"࠭ࠧᤠ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᤡ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᤢ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᤣ"),block,re.DOTALL)
		for link,title in items:
			if title in l1ll11_l1_: continue
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᤤ"),menu_name+title,link,491)
	return
def l11l1l_l1_(url,l1111ll11_l1_=l1l1ll_l1_ (u"ࠫࠬᤥ")):
	items = []
	#l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩᤦ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᤧ"),url,l1l1ll_l1_ (u"ࠧࠨᤨ"),l1l1ll_l1_ (u"ࠨࠩᤩ"),l1l1ll_l1_ (u"ࠩࠪᤪ"),l1l1ll_l1_ (u"ࠪࠫᤫ"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ᤬"))
	html = response.content
	block = l1l1ll_l1_ (u"ࠬ࠭᤭")
	if l1l1ll_l1_ (u"࠭࠮ࡱࡪࡳࠫ᤮") in url: block = html
	elif l1l1ll_l1_ (u"ࠧࡀࡵࡀࠫ᤯") in url:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡥࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࠢ࡮ࡣࡱ࡭࡫࡫ࡳࡵࠤࠪᤰ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᤱ"),block,re.DOTALL)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࠤࡰࡥࡳ࡯ࡦࡦࡵࡷࠦࠬᤲ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
	if not block: return
	#if not items: items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨࡠ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࠢࡣࡱࡻࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᤳ"),block,re.DOTALL)
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"๋ࠬิศ้าอࠬᤴ"),l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫᤵ"),l1l1ll_l1_ (u"ࠧศ฼้๎ฮ࠭ᤶ"),l1l1ll_l1_ (u"ࠨล฽๊๏ฯࠧᤷ"),l1l1ll_l1_ (u"ࠩๆ่๏ฮࠧᤸ"),l1l1ll_l1_ (u"ࠪห฾๊ว็᤹ࠩ"),l1l1ll_l1_ (u"ࠫ์ีวโࠩ᤺"),l1l1ll_l1_ (u"๋ࠬศศำสอ᤻ࠬ"),l1l1ll_l1_ (u"ู࠭าุࠪ᤼"),l1l1ll_l1_ (u"ࠧๆ้ิะฬ์ࠧ᤽"),l1l1ll_l1_ (u"ࠨษ็ฬํ๋ࠧ᤾"),l1l1ll_l1_ (u"่ࠩืึำ๊สࠩ᤿")]
	for link,img,title in items:
		title = unescapeHTML(title)
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ᥀"),title,re.DOTALL)
		if not l11111_l1_: l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ᥁"),title,re.DOTALL)
		if not l11111_l1_ or any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᥂"),menu_name+title,link,492,img)
		elif l11111_l1_ and l1l1ll_l1_ (u"࠭อๅไฬࠫ᥃") in title:
			title = l1l1ll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭᥄") + l11111_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᥅"),menu_name+title,link,493,img)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᥆"),menu_name+title,link,493,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᥇"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᥈"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l1ll_l1_ (u"ࠬอไึใะอࠥ࠭᥉"),l1l1ll_l1_ (u"࠭ࠧ᥊"))
			if title!=l1l1ll_l1_ (u"ࠧࠨ᥋"): addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᥌"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ᥍")+title,link,491)
	return
def l11ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ᥎"),url,l1l1ll_l1_ (u"ࠫࠬ᥏"),l1l1ll_l1_ (u"ࠬ࠭ᥐ"),l1l1ll_l1_ (u"࠭ࠧᥑ"),l1l1ll_l1_ (u"ࠧࠨᥒ"),l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᥓ"))
	html = response.content
	url2 = re.findall(l1l1ll_l1_ (u"ࠩࠥࡆࡺࡺࡴࡰࡰࡶࡆࡦࡸࡃࡰࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᥔ"),html,re.DOTALL)
	if url2:
		url2 = url2[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧᥕ"),url2,l1l1ll_l1_ (u"ࠫࠬᥖ"),l1l1ll_l1_ (u"ࠬ࠭ᥗ"),l1l1ll_l1_ (u"࠭ࠧᥘ"),l1l1ll_l1_ (u"ࠧࠨᥙ"),l1l1ll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠸࡮ࡥࠩᥚ"))
		html = response.content
	img = re.findall(l1l1ll_l1_ (u"ࠩࠥ࡭ࡲ࡭࠭ࡳࡧࡶࡴࡴࡴࡳࡪࡸࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᥛ"),html,re.DOTALL)
	if img: img = img[0]
	else: img = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡚ࡨࡶ࡯ࡥࠫᥜ"))
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᥝ"),html,re.DOTALL)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠨᥞ"),html,re.DOTALL)
	# l11l11_l1_
	if l1ll1ll_l1_ and l1l1ll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨᥟ") not in url:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᥠ"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᥡ"),menu_name+title,link,493,img)
	# l1ll1_l1_
	elif l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࡞࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࠧࡨ࡯ࡹࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᥢ"),block,re.DOTALL)
		if items:
			for link,img,title in items:
				title = title.strip(l1l1ll_l1_ (u"ࠪࠤࠬᥣ"))
				addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᥤ"),menu_name+title,link,492,img)
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᥥ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᥦ"),block,re.DOTALL)
			for link,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l1ll_l1_ (u"ࠧศๆุๅาฯࠠࠨᥧ"),l1l1ll_l1_ (u"ࠨࠩᥨ"))
				if title!=l1l1ll_l1_ (u"ࠩࠪᥩ"): addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᥪ"),menu_name+l1l1ll_l1_ (u"ฺࠫ็อสࠢࠪᥫ")+title,link,491)
	return
def PLAY(url):
	url2 = url.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧᥬ"))+l1l1ll_l1_ (u"࠭࠯ࡀࡸ࡬ࡩࡼࡃ࠱ࠨᥭ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ᥮"),url2,l1l1ll_l1_ (u"ࠨࠩ᥯"),l1l1ll_l1_ (u"ࠩࠪᥰ"),l1l1ll_l1_ (u"ࠪࠫᥱ"),l1l1ll_l1_ (u"ࠫࠬᥲ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᥳ"))
	html = response.content
	l11l1_l1_ = []
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪᥴ"))
	l1lll1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠢࡥࡣࡷࡥ࠿ࠦࠧࡲ࠿ࠫ࠲࠯ࡅࠩࠧࠤ᥵"),html,re.DOTALL)
	#if not l1lll1ll1l_l1_: l1lll1ll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࠫࡸ࡭࡯ࡳ࡝࠰࡬ࡨࡡ࠲࠰࡝࠮ࠫ࠲࠯ࡅࠩ࡝ࠫࠪ᥶"),html,re.DOTALL)
	l1lll1ll1l_l1_ = l1lll1ll1l_l1_[0]
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡷࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᥷"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭᥸"),block,re.DOTALL)
		for l1llll111l_l1_,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭᥹"))
			link = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡳࡱࡪ࠯ࡴࡧࡵࡺࡪࡸࡳ࠰ࡵࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ᥺")+l1lll1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࡪ࠿ࠪ᥻")+l1llll111l_l1_+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᥼")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᥽")
			l11l1_l1_.append(link)
	# l1l1l1l11_l1_ l11lllll1_l1_ link
	link = re.findall(l1l1ll_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡕࡨࡶࡻ࡫ࡲࠣ࠰࠭ࡃࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᥾"),html,re.DOTALL)
	if link:
		title = l1l1ll_l1_ (u"้ࠪๆ฼ไࠨ᥿")
		link = link[0]+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࡤࡥࠧᦀ")+title
		l11l1_l1_.append(link)
	# download l1ll_l1_
	#url2 = url.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧᦁ"))+l1l1ll_l1_ (u"࠭࠯ࡀࡦࡲࡻࡳࡲ࡯ࡢࡦࡀ࠵ࠬᦂ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫᦃ"),url2,l1l1ll_l1_ (u"ࠨࠩᦄ"),l1l1ll_l1_ (u"ࠩࠪᦅ"),l1l1ll_l1_ (u"ࠪࠫᦆ"),l1l1ll_l1_ (u"ࠫࠬᦇ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩᦈ"))
	#html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᦉ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᦊ"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪᦋ"))
			if l1l1ll_l1_ (u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪᦌ") in link: title2 = l1l1ll_l1_ (u"ࠪࡣࡤิวึࠩᦍ")
			else: title2 = l1l1ll_l1_ (u"ࠫࠬᦎ")
			link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᦏ")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᦐ")+title2
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬᦑ"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᦒ"),url)
	return
def SEARCH(search,l11ll1_l1_=l1l1ll_l1_ (u"ࠩࠪᦓ")):
	if not l11ll1_l1_: l11ll1_l1_ = l1l1l1_l1_
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l1l1ll_l1_ (u"ࠪࠤࠬᦔ"),l1l1ll_l1_ (u"ࠫ࠰࠭ᦕ"))
	url = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠳ࡶࡨࡱࡁࡶࡁࠬᦖ")+search
	l11l1l_l1_(url)
	return
#   search is l1l11111l_l1_ l1l11l11l_l1_ in l11l1l_l1_()
#   l1lll11l_l1_://l1lll1lll1_l1_.l1lll1llll_l1_-l1llll1111_l1_.l1llll1111_l1_/?s=the+l1lll1l1ll_l1_
#   l1lll11l_l1_://l1lll1lll1_l1_.l1lll1llll_l1_-l1llll1111_l1_.l1llll1111_l1_/search/the+l1lll1l1ll_l1_/
#   l1lll11l_l1_://l1lll1lll1_l1_.l1lll1llll_l1_-l1llll1111_l1_.l1llll1111_l1_/index.l1lll1ll11_l1_?s=the+l1lll1l1ll_l1_
#	l1lll11l_l1_://l1lll1llll_l1_-l1llll1111_l1_.io/index.l1lll1ll11_l1_?s=the+l1lll1l1ll_l1_
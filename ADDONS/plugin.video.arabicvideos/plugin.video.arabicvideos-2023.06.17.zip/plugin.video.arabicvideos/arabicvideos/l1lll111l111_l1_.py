# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ夔")
headers = {l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ夕"):l1l1ll_l1_ (u"ࠧࠨ外")}
menu_name = l1l1ll_l1_ (u"ࠨࡡ࡚ࡇࡒࡥࠧ夗")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭夘"),l1l1ll_l1_ (u"ࠪࡻࡼ࡫ࠧ夙")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l11l1l_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l11ll1l_l1_(url,text)
	elif mode==564: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ多")+text)
	elif mode==565: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠࠩ夛")+text)
	elif mode==566: results = l1ll1l_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ夜"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ夝"),l1l1ll_l1_ (u"ࠨࠩ夞"),False,l1l1ll_l1_ (u"ࠩࠪ够"),l1l1ll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ夠"))
	#hostname = response.headers[l1l1ll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭夡")]
	#hostname = hostname.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ夢"))
	#l11ll1_l1_ = l1l1l1_l1_
	#url = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭夣")
	#url = l11ll1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ夤"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠨࠩ夥"),l1l1ll_l1_ (u"ࠩࠪ夦"),l1l1ll_l1_ (u"ࠪࠫ大"),l1l1ll_l1_ (u"ࠫࠬ夨"),l1l1ll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ天"))
	#addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ太"),menu_name+l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊ิฬࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ夫"),l1l1ll_l1_ (u"ࠨࠩ夬"),8)
	#addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ夭"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ央"),l1l1ll_l1_ (u"ࠫࠬ夯"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ夰"),menu_name+l1l1ll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭失"),l1l1l1_l1_,569,l1l1ll_l1_ (u"ࠧࠨ夲"),l1l1ll_l1_ (u"ࠨࠩ夳"),l1l1ll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭头"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ夵"),menu_name+l1l1ll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ夶"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ夷"),564)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭夸"),menu_name+l1l1ll_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ夹"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ夺"),565)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ夻"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ夼"),l1l1ll_l1_ (u"ࠫࠬ夽"),9999)
	#headers2 = {l1l1ll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭夾"):hostname,l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ夿"):l1l1ll_l1_ (u"ࠧࠨ奀")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l1ll_l1_ (u"ࠨ࡞࠲ࠫ奁"),l1l1ll_l1_ (u"ࠩ࠲ࠫ奂"))
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࡤࡤࡶ࠭࠴ࠪࡀࠫࡩ࡭ࡱࡺࡥࡳࠩ奃"),html,re.DOTALL)
	#if l1lll11_l1_:
	#	block = l1lll11_l1_[0]
	#	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ奄"),block,re.DOTALL)
	#	for link,title in items:
	#		if l1l1ll_l1_ (u"ࠬࠫࡤ࠺ࠧ࠻࠹ࠪࡪ࠸ࠦࡤ࠸ࠩࡩ࠾ࠥࡢ࠹ࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡨ࠹ࠦࡦ࠻ࠩࡦ࠿࠭ࠦࡦ࠻ࠩࡦࡪࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡤ࠽ࠬ奅") in link: continue
	#		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭奆"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ奇")+menu_name+title,link,566)
	#	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭奈"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ奉"),l1l1ll_l1_ (u"ࠪࠫ奊"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ奋"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭奌"),l1l1ll_l1_ (u"࠭ࠧ奍"),l1l1ll_l1_ (u"ࠧࠨ奎"),l1l1ll_l1_ (u"ࠨࠩ奏"),l1l1ll_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ奐"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡍࡦࡰࡸࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡹࡌࡪࡵࡷࡆࡺࡺࡴࡰࡰࠥࠫ契"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡬ࡸࡪࡳ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ奒"),block,re.DOTALL)
		for link,title in items:
			#if l1l1ll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ奓") not in link:
			#	server = SERVER(link,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ奔"))
			#	link = link.replace(server,l11ll1_l1_)
			if title==l1l1ll_l1_ (u"ࠧࠨ奕"): continue
			if any(value in title.lower() for value in l1ll11_l1_): continue
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奖"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ套")+menu_name+title,link,566)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ奘"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ奙"),l1l1ll_l1_ (u"ࠬ࠭奚"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ奛"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ奜"),block,re.DOTALL)
		for link,img,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奝"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ奞")+menu_name+title,link,566,img)
	return html
def l1ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ奟"),l1l1ll_l1_ (u"ࠫࠬ奠"),url,l1l1ll_l1_ (u"ࠬ࠭奡"))
	#headers2 = {l1l1ll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ奢"):url,l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ奣"):l1l1ll_l1_ (u"ࠨࠩ奤")}
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭奥"),url,l1l1ll_l1_ (u"ࠪࠫ奦"),l1l1ll_l1_ (u"ࠫࠬ奧"),l1l1ll_l1_ (u"ࠬ࠭奨"),l1l1ll_l1_ (u"࠭ࠧ奩"),l1l1ll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ奪"))
	html = response.content
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奫"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ奬"),url,564)
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奭"),menu_name+l1l1ll_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ奮"),url,565)
	if l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦࠬ奯") in html:
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭奰"),menu_name+l1l1ll_l1_ (u"ࠧศๆ่้๏ุษࠨ奱"),url,561,l1l1ll_l1_ (u"ࠨࠩ奲"),l1l1ll_l1_ (u"ࠩࠪ女"),l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ奴"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ奵"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ奶"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭奷"),menu_name+title,link,561)
	return
def l11l1l_l1_(l1l1111llll_l1_,type=l1l1ll_l1_ (u"ࠧࠨ奸")):
	if l1l1ll_l1_ (u"ࠨ࠼࠽ࠫ她") in l1l1111llll_l1_:
		url3,url = l1l1111llll_l1_.split(l1l1ll_l1_ (u"ࠩ࠽࠾ࠬ奺"))
		server = SERVER(url3,l1l1ll_l1_ (u"ࠪࡹࡷࡲࠧ奻"))
		url = server+url
	else: url,url3 = l1l1111llll_l1_,l1l1111llll_l1_
	#headers2 = {l1l1ll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ奼"):url3,l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ好"):l1l1ll_l1_ (u"࠭ࠧ奾")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ奿"),url,l1l1ll_l1_ (u"ࠨࠩ妀"),l1l1ll_l1_ (u"ࠩࠪ妁"),l1l1ll_l1_ (u"ࠪࠫ如"),l1l1ll_l1_ (u"ࠫࠬ妃"),l1l1ll_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ妄"))
	html = response.content
	if type==l1l1ll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ妅"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ妆"),html,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ妇"):
		l1lll11_l1_ = [html.replace(l1l1ll_l1_ (u"ࠩ࡟ࡠ࠴࠭妈"),l1l1ll_l1_ (u"ࠪ࠳ࠬ妉")).replace(l1l1ll_l1_ (u"ࠫࡡࡢࠢࠨ妊"),l1l1ll_l1_ (u"ࠬࠨࠧ妋"))]
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲࡝ࡥࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ妌"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭妍"),block,re.DOTALL)
		for link,title,img in items:
			if any(value in title.lower() for value in l1ll11_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l1ll_l1_ (u"ࠨ็ืห์ีษࠡࠩ妎"),l1l1ll_l1_ (u"ࠩࠪ妏"))
			if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ妐") in link: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ妑"),menu_name+title,link,563,img)
			elif l1l1ll_l1_ (u"ࠬำไใหࠪ妒") in title:
				l11111_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ妓"),title,re.DOTALL)
				if l11111_l1_: title = l1l1ll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭妔") + l11111_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妕"),menu_name+title,link,563,img)
			else:
				addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ妖"),menu_name+title,link,562,img)
		if type==l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ妗"):
			l1ll1ll11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ妘"),block,re.DOTALL)
			if l1ll1ll11ll_l1_:
				count = l1ll1ll11ll_l1_[0]
				link = url+l1l1ll_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ妙")+count
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妚"),menu_name+l1l1ll_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ妛"),link,561,l1l1ll_l1_ (u"ࠨࠩ妜"),l1l1ll_l1_ (u"ࠩࠪ妝"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ妞"))
		elif type==l1l1ll_l1_ (u"ࠫࠬ妟"):
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭妠"),html,re.DOTALL)
			if l1lll11_l1_:
				block = l1lll11_l1_[0]
				items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ妡"),block,re.DOTALL)
				for link,title in items:
					title = l1l1ll_l1_ (u"ࠧึใะอࠥ࠭妢")+unescapeHTML(title)
					addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妣"),menu_name+title,link,561)
	return
def l11ll1l_l1_(url,type=l1l1ll_l1_ (u"ࠩࠪ妤")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ妥"),l1l1ll_l1_ (u"ࠫࠬ妦"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ妧"),url,l1l1ll_l1_ (u"࠭ࠧ妨"),l1l1ll_l1_ (u"ࠧࠨ妩"),l1l1ll_l1_ (u"ࠨࠩ妪"),l1l1ll_l1_ (u"ࠩࠪ妫"),l1l1ll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ妬"))
	html = response.content
	html = UNQUOTE(html)
	l1l1ll_l1_ (u"ࠦࠧࠨࠊࠊࡰࡤࡱࡪࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤ࡬ࡸࡪࡳࠢࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡳࡧ࡭ࡦ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥ࡜࠯࠴ࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠮ࠩ࠯ࠫࠥ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨ࠱ࠪ࠭ࠏࠏࡩࡧ้ࠢࠪํูๅࠨࠢ࡬ࡲࠥࡴࡡ࡮ࡧࠣࡥࡳࡪࠠ࡯ࡱࡷࠤࡹࡿࡰࡦ࠼ࠍࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࠱ࡷࡵࡲࡩࡵ้ࠪࠪํูๅࠨࠫ࡞࠴ࡢࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ็ืห์ีษࠨ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫࠍࠍࡪࡲࡩࡧࠢࠪั้่ษࠨࠢ࡬ࡲࠥࡴࡡ࡮ࡧ࠽ࠎࠎࠏ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࠲ࡸࡶ࡬ࡪࡶࠫࠫา๊โสࠩࠬ࡟࠵ࡣࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡳࡧࡳࡰࡦࡩࡥุ่ࠩࠩฬํฯสࠩ࠯ࠫࠬ࠯࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠨࠢࠣ妭")
	# l11l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ妮"),html,re.DOTALL)
	if not type and l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ妯"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l1l1ll_l1_ (u"ࠧࠡ࠯ࠣࠫ妰")+title
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ妱"),menu_name+title,link,563,l1l1ll_l1_ (u"ࠩࠪ妲"),l1l1ll_l1_ (u"ࠪࠫ妳"),l1l1ll_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭妴"))
			return
	# l1ll1_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࡷࡃ࠭妵"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ妶"),block)
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡳ࡭ࡸࡵࡤࡦࡖ࡬ࡸࡱ࡫࠾ࠨ妷"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l1l1ll_l1_ (u"ࠨࠩ妸"),str(items))
		for link,title in items:
			title = title.strip(l1l1ll_l1_ (u"ࠩࠣࠫ妹"))
			#title = name+l1l1ll_l1_ (u"ࠪࠤ࠲ࠦࠧ妺")+title
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ妻"),menu_name+title,link,562)
	if not menuItemsLIST:
		title = re.findall(l1l1ll_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ妼"),html,re.DOTALL)
		if title: title = title[0].replace(l1l1ll_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ妽"),l1l1ll_l1_ (u"ࠧࠨ妾")).replace(l1l1ll_l1_ (u"ࠨ็ืห์ีษࠡࠩ妿"),l1l1ll_l1_ (u"ࠩࠪ姀"))
		else: title = l1l1ll_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ姁")
		addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姂"),menu_name+title,url,562)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ姃"),url,l1l1ll_l1_ (u"࠭ࠧ姄"),l1l1ll_l1_ (u"ࠧࠨ姅"),l1l1ll_l1_ (u"ࠨࠩ姆"),l1l1ll_l1_ (u"ࠩࠪ姇"),l1l1ll_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ姈"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ姉"),html,re.DOTALL)
	if l1ll111_l1_:
		l1ll111_l1_ = [l1ll111_l1_[0][0],l1ll111_l1_[0][1]]
		if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ姊"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ始"),block,re.DOTALL)
		for link,name in items:
			if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ姌") not in link: link = l1l1l1_l1_+link
			if name==l1l1ll_l1_ (u"ࠨีํีๆื้ࠠ์ࠣื๏๋วࠨ姍"): name = l1l1ll_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ姎")
			link = link+l1l1ll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ姏")+name+l1l1ll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ姐")
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ姑"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ姒"),block,re.DOTALL)
		for link,l11ll1l1_l1_ in items:
			if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ姓") not in link: link = l1l1l1_l1_+link
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ委"),l11ll1l1_l1_,re.DOTALL)
			if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠩࡢࡣࡤࡥࠧ姕")+l11ll1l1_l1_[0]
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠪࠫ姖")
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡼ࡫ࡣࡪ࡯ࡤࠫ姗")+l1l1ll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ姘")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ姙"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭姚"),url)
	return
def SEARCH(search,hostname=l1l1ll_l1_ (u"ࠨࠩ姛")):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠩࠪ姜"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠪࠫ姝"): return
	search = search.replace(l1l1ll_l1_ (u"ࠫࠥ࠭姞"),l1l1ll_l1_ (u"ࠬ࠱ࠧ姟"))
	l11l1_l1_ = [l1l1ll_l1_ (u"࠭࠯ࠨ姠"),l1l1ll_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡳࡦࡴ࡬ࡩࡸ࠭姡"),l1l1ll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡢࡰ࡬ࡱࡪ࠭姢"),l1l1ll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡶࡹࠫ姣"),l1l1ll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ姤")]
	l1l1ll11l_l1_ = [l1l1ll_l1_ (u"ࠫฬ๊รโๆส้ࠬ姥"),l1l1ll_l1_ (u"ࠬอไๆี็ื้อสࠨ姦"),l1l1ll_l1_ (u"࠭วๅษ้๎๊๐้ࠠࠢส่่ืส้่ࠪ姧"),l1l1ll_l1_ (u"ࠧศๆหีฬ๋ฬࠡฬ็๎ๆุ๊้่ํอࠬ姨"),l1l1ll_l1_ (u"ࠨ฼ํี๋ࠥอะัࠪ姩")]
	if showDialogs:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩสาฯืࠠศๆ้์฾ࠦวๅ็ฺ่ํฮ࠺ࠨ姪"), l1l1ll11l_l1_)
		if selection==-1: return
	else: selection = 4
	if not hostname:
		hostname = l1l1l1_l1_
		#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ姫"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠫࠬ姬"),l1l1ll_l1_ (u"ࠬ࠭姭"),False,l1l1ll_l1_ (u"࠭ࠧ姮"),l1l1ll_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ姯"))
		#hostname = response.headers[l1l1ll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ姰")]
		#hostname = response.url
		#hostname = hostname.strip(l1l1ll_l1_ (u"ࠩ࠲ࠫ姱"))
	url2 = hostname+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ姲")+search+l11l1_l1_[selection]
	l11l1l_l1_(url2)
	return
def l111l11_l1_(l1l1111llll_l1_,filter):
	if l1l1ll_l1_ (u"ࠫࡄࡅࠧ姳") in l1l1111llll_l1_: url = l1l1111llll_l1_.split(l1l1ll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ姴"))[0]
	else: url = l1l1111llll_l1_
	#headers2 = {l1l1ll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ姵"):l1l1111llll_l1_,l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ姶"):l1l1ll_l1_ (u"ࠨࠩ姷")}
	filter = filter.replace(l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ姸"),l1l1ll_l1_ (u"ࠪࠫ姹"))
	type,filter = filter.split(l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ姺"),1)
	if filter==l1l1ll_l1_ (u"ࠬ࠭姻"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"࠭ࠧ姼"),l1l1ll_l1_ (u"ࠧࠨ姽")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ姾"))
	if type==l1l1ll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭姿"):
		if l1l1l11ll_l1_[0]+l1l1ll_l1_ (u"ࠪࡁࡂ࠭娀") not in l1l1lll1_l1_: category = l1l1l11ll_l1_[0]
		for i in range(len(l1l1l11ll_l1_[0:-1])):
			if l1l1l11ll_l1_[i]+l1l1ll_l1_ (u"ࠫࡂࡃࠧ威") in l1l1lll1_l1_: category = l1l1l11ll_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠦࠨ娂")+category+l1l1ll_l1_ (u"࠭࠽࠾࠲ࠪ娃")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠨࠪ娄")+category+l1l1ll_l1_ (u"ࠨ࠿ࡀ࠴ࠬ娅")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠩࠩࠪࠬ娆"))+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ娇")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠫࠫࠬࠧ娈"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ娉"))
		url2 = url+l1l1ll_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ娊")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨ娋"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ娌"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠩࠪ娍"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭娎"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠫࠬ娏"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ娐")+l1l1ll1l_l1_
		l111l11l_l1_ = l1l111111_l1_(url2,l1l1111llll_l1_)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭娑"),menu_name+l1l1ll_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪ娒"),l111l11l_l1_,561,l1l1ll_l1_ (u"ࠨࠩ娓"),l1l1ll_l1_ (u"ࠩࠪ娔"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ娕"))
		addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娖"),menu_name+l1l1ll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ娗")+l1l11l1l_l1_+l1l1ll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ娘"),l111l11l_l1_,561,l1l1ll_l1_ (u"ࠧࠨ娙"),l1l1ll_l1_ (u"ࠨࠩ娚"),l1l1ll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ娛"))
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ娜"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ娝"),l1l1ll_l1_ (u"ࠬ࠭娞"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ娟"),url,l1l1ll_l1_ (u"ࠧࠨ娠"),l1l1ll_l1_ (u"ࠨࠩ娡"),l1l1ll_l1_ (u"ࠩࠪ娢"),l1l1ll_l1_ (u"ࠪࠫ娣"),l1l1ll_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ娤"))
	html = response.content
	html = html.replace(l1l1ll_l1_ (u"ࠬࡢ࡜ࠣࠩ娥"),l1l1ll_l1_ (u"࠭ࠢࠨ娦")).replace(l1l1ll_l1_ (u"ࠧ࡝࡞࠲ࠫ娧"),l1l1ll_l1_ (u"ࠨ࠱ࠪ娨"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡻࡪࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡻࡪࡩࡩ࡮ࡣ࠰࠱࡫࡯࡬ࡵࡧࡵࡂࠬ娩"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡸࡦࡾ࡯࡯ࡱࡰࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ娪"),block+l1l1ll_l1_ (u"ࠫࡁ࡬ࡩ࡭ࡶࡨࡶࡧࡵࡸࠨ娫"),re.DOTALL)
	dict = {}
	for l11111l_l1_,name,block in l1111ll_l1_:
		name = escapeUNICODE(name)
		if l1l1ll_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ娬") in l11111l_l1_: continue
		items = re.findall(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡹ࡫ࡲ࡮࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡴࡹࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡽࡺ࠾ࠨ娭"),block,re.DOTALL)
		if l1l1ll_l1_ (u"ࠧ࠾࠿ࠪ娮") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ娯"):
			if category!=l11111l_l1_: continue
			elif len(items)<=1:
				if l11111l_l1_==l1l1l11ll_l1_[-1]: l11l1l_l1_(url2)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ娰")+l1ll11l1_l1_)
				return
			else:
				l111l11l_l1_ = l1l111111_l1_(url2,l1l1111llll_l1_)
				if l11111l_l1_==l1l1l11ll_l1_[-1]:
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ娱"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠫ娲"),l111l11l_l1_,561,l1l1ll_l1_ (u"ࠬ࠭娳"),l1l1ll_l1_ (u"࠭ࠧ娴"),l1l1ll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ娵"))
				else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ娶"),menu_name+l1l1ll_l1_ (u"ࠩส่ัฺ๋๊ࠩ娷"),url2,564,l1l1ll_l1_ (u"ࠪࠫ娸"),l1l1ll_l1_ (u"ࠫࠬ娹"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭娺"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"࠭ࠦࠧࠩ娻")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾࠿࠳ࠫ娼")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠨࠨࠩࠫ娽")+l11111l_l1_+l1l1ll_l1_ (u"ࠩࡀࡁ࠵࠭娾")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ娿")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婀"),menu_name+name+l1l1ll_l1_ (u"ࠬࡀࠠศๆฯ้๏฿ࠧ婁"),url2,565,l1l1ll_l1_ (u"࠭ࠧ婂"),l1l1ll_l1_ (u"ࠧࠨ婃"),l1ll11l1_l1_+l1l1ll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ婄"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l1ll_l1_ (u"ࠩࡵࠫ婅") or value==l1l1ll_l1_ (u"ࠪࡲࡨ࠳࠱࠸ࠩ婆"): continue
			if any(value in option.lower() for value in l1ll11_l1_): continue
			if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ婇") in option: continue
			if l1l1ll_l1_ (u"ࠬอไไๆࠪ婈") in option: continue
			if l1l1ll_l1_ (u"࠭࡮࠮ࡣࠪ婉") in value: continue
			#if value in [l1l1ll_l1_ (u"ࠧࡳࠩ婊"),l1l1ll_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ婋"),l1l1ll_l1_ (u"ࠩࡷࡺ࠲ࡳࡡࠨ婌")]: continue
			#if l11111l_l1_==l1l1ll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ婍"): option = value
			if option==l1l1ll_l1_ (u"ࠫࠬ婎"): option = value
			l11llll11_l1_ = option
			name1 = re.findall(l1l1ll_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ婏"),option,re.DOTALL)
			if name1: l11llll11_l1_ = name1[0]
			title2 = name+l1l1ll_l1_ (u"࠭࠺ࠡࠩ婐")+l11llll11_l1_
			dict[l11111l_l1_][value] = title2
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠧࠧࠨࠪ婑")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࡀࠫ婒")+l11llll11_l1_
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠩࠩࠪࠬ婓")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࡂ࠭婔")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ婕")+l1lll111_l1_
			if type==l1l1ll_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭婖"):
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婗"),menu_name+title2,url,565,l1l1ll_l1_ (u"ࠧࠨ婘"),l1l1ll_l1_ (u"ࠨࠩ婙"),l111111_l1_+l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ婚"))
			elif type==l1l1ll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ婛") and l1l1l11ll_l1_[-2]+l1l1ll_l1_ (u"ࠫࡂࡃࠧ婜") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ婝"))
				#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ婞"),l1l1ll_l1_ (u"ࠧࠨ婟"),l1l1l1l1_l1_,l1lll111_l1_)
				url3 = url+l1l1ll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ婠")+l1l1l1l1_l1_
				l111l11l_l1_ = l1l111111_l1_(url3,l1l1111llll_l1_)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婡"),menu_name+title2,l111l11l_l1_,561,l1l1ll_l1_ (u"ࠪࠫ婢"),l1l1ll_l1_ (u"ࠫࠬ婣"),l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭婤"))
			else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婥"),menu_name+title2,url,564,l1l1ll_l1_ (u"ࠧࠨ婦"),l1l1ll_l1_ (u"ࠨࠩ婧"),l111111_l1_)
	return
l1l1l11ll_l1_ = [l1l1ll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ婨"),l1l1ll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ婩"),l1l1ll_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ婪")]
l1l11llll_l1_ = [l1l1ll_l1_ (u"ࠬࡳࡰࡢࡣࠪ婫"),l1l1ll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ婬"),l1l1ll_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭婭"),l1l1ll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ婮"),l1l1ll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪ婯"),l1l1ll_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ婰"),l1l1ll_l1_ (u"ࠫࡳࡧࡴࡪࡱࡱࠫ婱"),l1l1ll_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ婲")]
def l1l111111_l1_(url2,url3):
	if l1l1ll_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡗ࡯ࡧࡩࡶࡅࡥࡷ࠭婳") in url2: url2 = url2.replace(l1l1ll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ婴"),l1l1ll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࠩ婵"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ婶"),l1l1ll_l1_ (u"ࠪ࠾࠿࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠵ࠧ婷"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠫࡂࡃࠧ婸"),l1l1ll_l1_ (u"ࠬ࠵ࠧ婹"))
	url2 = url2.replace(l1l1ll_l1_ (u"࠭ࠦࠧࠩ婺"),l1l1ll_l1_ (u"ࠧ࠰ࠩ婻"))
	return url2
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ婼"),l1l1ll_l1_ (u"ࠩࠪ婽"),filters,l1l1ll_l1_ (u"ࠪࡍࡓࠦࠠࠡࠢࠪ婾")+mode)
	# mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭婿")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ媀")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"࠭ࡡ࡭࡮ࠪ媁")					all filters (l1l1l111_l1_ l1ll1l1l_l1_ filter)
	filters = filters.strip(l1l1ll_l1_ (u"ࠧࠧࠨࠪ媂"))
	l1l1llll_l1_,l1llllll_l1_ = {},l1l1ll_l1_ (u"ࠨࠩ媃")
	if l1l1ll_l1_ (u"ࠩࡀࡁࠬ媄") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠪࠪࠫ࠭媅"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠫࡂࡃࠧ媆"))
			l1l1llll_l1_[var] = value
	for key in l1l11llll_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠬ࠶ࠧ媇")
		if l1l1ll_l1_ (u"࠭ࠥࠨ媈") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ媉") and value!=l1l1ll_l1_ (u"ࠨ࠲ࠪ媊"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠩࠣ࠯ࠥ࠭媋")+value
		elif mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭媌") and value!=l1l1ll_l1_ (u"ࠫ࠵࠭媍"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠬࠦࠨ媎")+key+l1l1ll_l1_ (u"࠭࠽࠾ࠩ媏")+value
		elif mode==l1l1ll_l1_ (u"ࠧࡢ࡮࡯ࠫ媐"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠨࠩࠫ媑")+key+l1l1ll_l1_ (u"ࠩࡀࡁࠬ媒")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠪࠤ࠰ࠦࠧ媓"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠫࠫࠬࠧ媔"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭媕"),l1l1ll_l1_ (u"࠭ࠧ媖"),l1llllll_l1_,l1l1ll_l1_ (u"ࠧࡐࡗࡗࠫ媗"))
	return l1llllll_l1_
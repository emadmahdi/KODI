﻿# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
#import unicodedata,simplejson
def MAIN(mode,l1l1ll11l11_l1_):
	if l1l1ll11l11_l1_==l1l1ll_l1_ (u"࠭ࠧㅡ"): return
	if mode==1:
		l1l1ll111ll_l1_ = xbmcgui.l1l1ll111l1_l1_()
		l1l1ll1111l_l1_ = xbmcgui.l1l1l1ll11l_l1_(l1l1ll111ll_l1_)
		l1l1ll11l11_l1_ = l1l1ll11111_l1_(l1l1ll11l11_l1_)
		l1l1ll1111l_l1_.getControl(311).l1l1ll11ll1_l1_(l1l1ll11l11_l1_)
	if mode==0:
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨㅢ"))
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ㅣ"))
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㅤ"))
		l1l1l1ll1ll_l1_=l1l1ll_l1_ (u"ࠪ࡜ࠬㅥ")
		if kodi_version>18.99: check = isinstance(l1l1ll11l11_l1_,str)
		else: check = isinstance(l1l1ll11l11_l1_,unicode)
		if check==True: l1l1l1ll1ll_l1_=l1l1ll_l1_ (u"࡚ࠫ࠭ㅦ")
		l1l1l1ll1l1_l1_=str(type(l1l1ll11l11_l1_))+l1l1ll_l1_ (u"ࠬࠦࠧㅧ")+l1l1ll11l11_l1_+l1l1ll_l1_ (u"࠭ࠠࠨㅨ")+l1l1l1ll1ll_l1_+l1l1ll_l1_ (u"ࠧࠡࠩㅩ")
		for i in range(0,len(l1l1ll11l11_l1_),1):
			l1l1l1ll1l1_l1_ += hex(ord(l1l1ll11l11_l1_[i])).replace(l1l1ll_l1_ (u"ࠨ࠲ࡻࠫㅪ"),l1l1ll_l1_ (u"ࠩࠪㅫ"))+l1l1ll_l1_ (u"ࠪࠤࠬㅬ")
		l1l1ll11l11_l1_ = l1l1ll11111_l1_(l1l1ll11l11_l1_)
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩㅭ"))
		l1l1l1ll1ll_l1_=l1l1ll_l1_ (u"ࠬ࡞ࠧㅮ")
		if kodi_version>18.99: check = isinstance(l1l1ll11l11_l1_, str)
		else: check = isinstance(l1l1ll11l11_l1_, unicode)
		if check==True: l1l1l1ll1ll_l1_=l1l1ll_l1_ (u"࠭ࡕࠨㅯ")
		l1l1l1lll11_l1_=str(type(l1l1ll11l11_l1_))+l1l1ll_l1_ (u"ࠧࠡࠩㅰ")+l1l1ll11l11_l1_+l1l1ll_l1_ (u"ࠨࠢࠪㅱ")+l1l1l1ll1ll_l1_+l1l1ll_l1_ (u"ࠩࠣࠫㅲ")
		for i in range(0,len(l1l1ll11l11_l1_),1):
			l1l1l1lll11_l1_ += hex(ord(l1l1ll11l11_l1_[i])).replace(l1l1ll_l1_ (u"ࠪ࠴ࡽ࠭ㅳ"),l1l1ll_l1_ (u"ࠫࠬㅴ"))+l1l1ll_l1_ (u"ࠬࠦࠧㅵ")
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧㅶ"),l1l1ll_l1_ (u"ࠧࠨㅷ"),l1l1l1ll1l1_l1_,l1l1l1lll11_l1_)
	return
	#for i in range(0,len(l1l1ll11l11_l1_)-2,3):
	#	string=hex(ord(l1l1ll11l11_l1_[i+0]))+l1l1ll_l1_ (u"ࠨࠢࠣࠫㅸ")+hex(ord(l1l1ll11l11_l1_[i+1]))+l1l1ll_l1_ (u"ࠩࠣࠤࠬㅹ")+hex(ord(l1l1ll11l11_l1_[i+2]))
	#	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫㅺ"),l1l1ll_l1_ (u"ࠫࠬㅻ"),l1l1ll_l1_ (u"ࠬ࠭ㅼ"),string)
	#return
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫㅽ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨㅾ"),l1l1ll_l1_ (u"ࠨࠩㅿ"),l1l1ll_l1_ (u"ࠩࠪㆀ"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11111_l1_(l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㆁ"))
	#l1l1ll11l11_l1_ = unicodedata.normalize(l1l1ll_l1_ (u"ࠫࡓࡌࡋࡅࠩㆂ"),l1l1ll11l11_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ㆃ"),l1l1ll_l1_ (u"࠭ࠧㆄ"),l1l1ll_l1_ (u"ࠧࠨㆅ"),   hex(  unicodedata.combining(l1l1ll11l11_l1_[0])  )   )
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩㆆ"),l1l1ll_l1_ (u"ࠩࠪㆇ"),l1l1ll11l11_l1_,   hex(ord(  l1l1ll11l11_l1_[0]  ))   )
	#new = l1l1ll_l1_ (u"ࠪࠫㆈ")
	#for l1l1l1llll1_l1_ in l1l1ll11l11_l1_:
	#	DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬㆉ"),l1l1ll_l1_ (u"ࠬ࠭ㆊ"),l1l1ll_l1_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭ㆋ"),unicodedata.decomposition(l1l1l1llll1_l1_) )
	#	new += l1l1ll_l1_ (u"ࠧ࡝ࡷ࠳ࠫㆌ") + hex(ord(l1l1l1llll1_l1_)).replace(l1l1ll_l1_ (u"ࠨ࠲ࡻࠫㆍ"),l1l1ll_l1_ (u"ࠩࠪㆎ"))
	#l1l1ll11l11_l1_ = new
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㆏"),l1l1ll_l1_ (u"ࠫࠬ㆐"),l1l1ll_l1_ (u"ࠬ࠭㆑"),l1l1ll11l11_l1_)
	#new = l1l1ll_l1_ (u"࠭ࠧ㆒")
	#for i in range(len(l1l1ll11l11_l1_)-6,-5,-6):
	#	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㆓"),l1l1ll_l1_ (u"ࠨࠩ㆔"),l1l1ll_l1_ (u"ࠩࠪ㆕"),str(i))
	#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1] + l1l1ll11l11_l1_[i+2] + l1l1ll11l11_l1_[i+3] + l1l1ll11l11_l1_[i+4] + l1l1ll11l11_l1_[i+5]
	#l1l1ll11l11_l1_ = new
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㆖"),l1l1ll_l1_ (u"ࠫࠬ㆗"),l1l1ll_l1_ (u"ࠬ࠭㆘"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ㆙"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㆚"),l1l1ll_l1_ (u"ࠨࠩ㆛"),l1l1ll_l1_ (u"ࠩࠪ㆜"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㆝"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ㆞"),l1l1ll_l1_ (u"ࠬ࠭㆟"),l1l1ll_l1_ (u"࠭ࠧㆠ"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll_l1_ (u"ࠧࡦ࡯ࡤࡨࠬㆡ")
	#l1l1l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡊࡰࡳࡹࡹ࠴ࡓࡦࡰࡧࡘࡪࡾࡴࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡴࡦࡺࡷࠦ࠿ࠨࠧㆢ")+l1l1ll11l11_l1_+l1l1ll_l1_ (u"ࠩࠥ࠰ࠧࡪ࡯࡯ࡧࠥ࠾࡫ࡧ࡬ࡴࡧࢀ࠰ࠧ࡯ࡤࠣ࠼࠴ࢁࠬㆣ"))
	#simplejson.loads(l1l1l1lllll_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㆤ"))
	#new = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬㆥ"))
	#l1l1ll11l11_l1_ = new
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ㆦ"),l1l1ll_l1_ (u"࠭ࠧㆧ"),l1l1ll_l1_ (u"ࠧࠨㆨ"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11111_l1_(l1l1ll11l11_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩㆩ"),l1l1ll_l1_ (u"ࠩࠪㆪ"),l1l1ll_l1_ (u"ࠪࠫㆫ"),l1l1ll11l11_l1_)
	#new = l1l1ll_l1_ (u"ࠫࠬㆬ")
	#for i in range(len(l1l1ll11l11_l1_)-2,-1,-2):
	#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1]
	#l1l1ll11l11_l1_ = new
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ㆭ"),l1l1ll_l1_ (u"࠭ࠧㆮ"),l1l1ll_l1_ (u"ࠧࠨㆯ"),l1l1ll11l11_l1_)
	#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㆰ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪㆱ"),l1l1ll_l1_ (u"ࠪࠫㆲ"),l1l1ll_l1_ (u"ࠫࠬㆳ"),l1l1ll11l11_l1_)
	#new = l1l1ll_l1_ (u"ࠬ࠭ㆴ")
	#for i in range(len(l1l1ll11l11_l1_)-2,-1,-2):
	#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1]
	#l1l1ll11l11_l1_ = new
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧㆵ"),l1l1ll_l1_ (u"ࠧࠨㆶ"),l1l1ll_l1_ (u"ࠨࠩㆷ"),l1l1ll11l11_l1_)
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.replace(l1l1ll_l1_ (u"ࠩࠣࠫㆸ"),l1l1ll_l1_ (u"ࠪࠫㆹ"))
		#new = l1l1ll_l1_ (u"ࠫࠬㆺ")
		#for i in range(len(l1l1ll11l11_l1_)-3,-2,-3):
		#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1] + l1l1ll11l11_l1_[i+2]
		#l1l1ll11l11_l1_ = new
		#new = l1l1ll_l1_ (u"ࠬ࠭ㆻ")
		#for i in range(len(l1l1ll11l11_l1_)-2,-1,-2):
		#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1]
		#l1l1ll11l11_l1_ = new
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧㆼ"),l1l1ll_l1_ (u"ࠧࠨㆽ"),l1l1ll_l1_ (u"ࠨࠩㆾ"),l1l1ll11l11_l1_)
		#l1l1ll11l11_l1_ = l1l1ll11l11_l1_.l1l1ll11l1l_l1_(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆿ"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㇀"),l1l1ll_l1_ (u"ࠫࠬ㇁"),str(ord(l1l1ll11l11_l1_[0]))+l1l1ll_l1_ (u"ࠬࠦࠧ㇂")+str(ord(l1l1ll11l11_l1_[1]))+l1l1ll_l1_ (u"࠭ࠠࠨ㇃")+str(ord(l1l1ll11l11_l1_[2])),str(len(l1l1ll11l11_l1_)))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨ㇄"),l1l1ll_l1_ (u"ࠨࠩ㇅"),l1l1ll_l1_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠢࡏࡩࡹࡺࡥࡳࡵࠪ㇆"),l1l1ll11l11_l1_)
		#new = l1l1ll_l1_ (u"ࠪࠫ㇇")
		#for i in range(len(l1l1ll11l11_l1_)-2,-1,-2):
		#	new += l1l1ll11l11_l1_[i] + l1l1ll11l11_l1_[i+1]
		#l1l1ll11l11_l1_ = new
		#new = l1l1ll11l11_l1_.decode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇈"))
		#new = new.decode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇉"))
		#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ㇊"),l1l1ll_l1_ (u"ࠧࠨ㇋"),l1l1ll_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨ㇌"),new )
		#l1l1l1ll1l1_l1_ = l1l1ll_l1_ (u"ࠩࠪ㇍")
		#for l1l1l1llll1_l1_ in new:
		#	DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㇎"),l1l1ll_l1_ (u"ࠫࠬ㇏"),l1l1ll_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㇐"),unicodedata.decomposition(l1l1l1llll1_l1_) )
		#	l1l1l1ll1l1_l1_ += l1l1ll_l1_ (u"࠭࡜ࡶࠩ㇑") + hex(ord(l1l1l1llll1_l1_)).replace(l1l1ll_l1_ (u"ࠧࡹࠩ㇒"),l1l1ll_l1_ (u"ࠨࠩ㇓"))
		#l1l1l1ll1l1_l1_ = l1l1l1ll1l1_l1_.decode(l1l1ll_l1_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ㇔"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ㇕"),l1l1ll_l1_ (u"ࠫࠬ㇖"),l1l1ll_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㇗"),l1l1l1ll1l1_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l1ll11111_l1_(new)
		#l1l1ll11l11_l1_ = new.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㇘"))
		#new = new.decode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㇙")) #.decode(l1l1ll_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㇚"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ㇛"),l1l1ll_l1_ (u"ࠪࠫ㇜"),l1l1ll_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㇝"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇞")))   )
		#l1l1ll11l11_l1_ = l1l1ll11111_l1_(new)
		#l1l1ll11l11_l1_ = l1l1ll11111_l1_(l1l1ll11l11_l1_)
		#method=l1l1ll_l1_ (u"ࠨࡉ࡯ࡲࡸࡸ࠳࡙ࡥ࡯ࡦࡗࡩࡽࡺࠢ㇟")
		#params=l1l1ll_l1_ (u"ࠧࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠨࡷࠧ࠲ࠠࠣࡦࡲࡲࡪࠨ࠺ࡧࡣ࡯ࡷࡪࢃࠧ㇠") % l1l1ll11l11_l1_
		#l1l1l1lllll_l1_ = xbmc.executeJSONRPC(l1l1ll_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠦࠢ࠳࠰࠳ࠦ࠱ࠦࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠢࠥࠩࡸࠨࠬࠡࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࠤࠪࡹࠬࠡࠤ࡬ࡨࠧࡀࠠ࠲ࡿࠪ㇡") % (method, params))
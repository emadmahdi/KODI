# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ㿄")
headers = {l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㿅"):l1l1ll_l1_ (u"ࠩࠪ㿆")}
menu_name = l1l1ll_l1_ (u"ࠪࡣࡒࡉࡍࡠࠩ㿇")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"๊ࠫ฻วา฻ฬࠤาืษࠨ㿈"),l1l1ll_l1_ (u"ࠬࡽࡷࡦࠩ㿉")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l11l1l_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l11ll1l_l1_(url,text)
	elif mode==364: results = l111l11_l1_(url,l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭㿊")+text)
	elif mode==365: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ㿋")+text)
	elif mode==366: results = l1ll1l_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ㿌"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ㿍"),l1l1ll_l1_ (u"ࠪࠫ㿎"),False,l1l1ll_l1_ (u"ࠫࠬ㿏"),l1l1ll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㿐"))
	#hostname = response.headers[l1l1ll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㿑")]
	#hostname = hostname.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ㿒"))
	#l11ll1_l1_ = l1l1l1_l1_
	#url = l11ll1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ㿓")
	#url = l11ll1_l1_
	#response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭㿔"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ㿕"),l1l1ll_l1_ (u"ࠫࠬ㿖"),l1l1ll_l1_ (u"ࠬ࠭㿗"),l1l1ll_l1_ (u"࠭ࠧ㿘"),l1l1ll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㿙"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㿚"),menu_name+l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์ึวࠡษ็้ํู่ࠡ็฽่็ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㿛"),l1l1ll_l1_ (u"ࠪࠫ㿜"),8)
	#addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㿝"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㿞"),l1l1ll_l1_ (u"࠭ࠧ㿟"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿠"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㿡"),l1l1l1_l1_,369,l1l1ll_l1_ (u"ࠩࠪ㿢"),l1l1ll_l1_ (u"ࠪࠫ㿣"),l1l1ll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㿤"))
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿥"),menu_name+l1l1ll_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ㿦"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡘࡩࡨࡪࡷࡆࡦࡸࠧ㿧"),364)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿨"),menu_name+l1l1ll_l1_ (u"ࠩไ่ฯืࠠไษ่่ࠬ㿩"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ㿪"),365)
	addMenuItem(l1l1ll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㿫"),l1l1ll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㿬"),l1l1ll_l1_ (u"࠭ࠧ㿭"),9999)
	#headers2 = {l1l1ll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㿮"):hostname,l1l1ll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㿯"):l1l1ll_l1_ (u"ࠩࠪ㿰")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l1l1ll_l1_ (u"ࠪࡠ࠴࠭㿱"),l1l1ll_l1_ (u"ࠫ࠴࠭㿲"))
	#l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡸࡩࡨࡪࡷࡦࡦࡸࠨ࠯ࠬࡂ࠭࡫࡯࡬ࡵࡧࡵࠫ㿳"),html,re.DOTALL)
	#if l1lll11_l1_:
	#	block = l1lll11_l1_[0]
	#	items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬ㿴"),block,re.DOTALL)
	#	for link,title in items:
	#		if l1l1ll_l1_ (u"ࠧࠦࡦ࠼ࠩ࠽࠻ࠥࡥ࠺ࠨࡦ࠺ࠫࡤ࠹ࠧࡤ࠻ࠪࡪ࠸ࠦࡤ࠴ࠩࡩ࠾ࠥࡣ࠻ࠨࡨ࠽ࠫࡡ࠺࠯ࠨࡨ࠽ࠫࡡࡥࠧࡧ࠼ࠪࡨ࠱ࠦࡦ࠻ࠩࡦ࠿ࠧ㿵") in link: continue
	#		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿶"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㿷")+menu_name+title,link,366)
	#	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㿸"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㿹"),l1l1ll_l1_ (u"ࠬ࠭㿺"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ㿻"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ㿼"),l1l1ll_l1_ (u"ࠨࠩ㿽"),l1l1ll_l1_ (u"ࠩࠪ㿾"),l1l1ll_l1_ (u"ࠪࠫ㿿"),l1l1ll_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭䀀"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡔࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡕࡸ࡯ࡥࡷࡦࡸ࡮ࡵ࡮ࡴࡎ࡬ࡷࡹࡈࡵࡵࡶࡲࡲࠧ࠭䀁"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䀂"),block,re.DOTALL)
		for link,title in items:
			#if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ䀃") not in link:
			#	server = SERVER(link,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬ䀄"))
			#	link = link.replace(server,l11ll1_l1_)
			if title==l1l1ll_l1_ (u"ࠩࠪ䀅"): continue
			if any(value in title.lower() for value in l1ll11_l1_): continue
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀆"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䀇")+menu_name+title,link,366)
		addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䀈"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䀉"),l1l1ll_l1_ (u"ࠧࠨ䀊"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭࡭ࡵࡶࡦࡴࡤࡦࡱ࡫ࠠࡢࡥࡷ࡭ࡻࡧࡢ࡭ࡧࠪ䀋"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䀌"),block,re.DOTALL)
		for link,img,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀍"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䀎")+menu_name+title,link,366,img)
	return html
def l1ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭䀏"),l1l1ll_l1_ (u"࠭ࠧ䀐"),url,l1l1ll_l1_ (u"ࠧࠨ䀑"))
	#headers2 = {l1l1ll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䀒"):url,l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䀓"):l1l1ll_l1_ (u"ࠪࠫ䀔")}
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ䀕"),url,l1l1ll_l1_ (u"ࠬ࠭䀖"),l1l1ll_l1_ (u"࠭ࠧ䀗"),l1l1ll_l1_ (u"ࠧࠨ䀘"),l1l1ll_l1_ (u"ࠨࠩ䀙"),l1l1ll_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ䀚"))
	html = response.content
	#addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀛"),menu_name+l1l1ll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䀜"),url,364)
	#addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䀝"),menu_name+l1l1ll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ䀞"),url,365)
	if l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠧ䀟") in html:
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䀠"),menu_name+l1l1ll_l1_ (u"ࠩส่๊๋๊ำหࠪ䀡"),url,361,l1l1ll_l1_ (u"ࠪࠫ䀢"),l1l1ll_l1_ (u"ࠫࠬ䀣"),l1l1ll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䀤"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ䀥"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䀦"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䀧"),menu_name+title,link,361)
	return
def l11l1l_l1_(l1l1111llll_l1_,type=l1l1ll_l1_ (u"ࠩࠪ䀨")):
	if l1l1ll_l1_ (u"ࠪ࠾࠿࠭䀩") in l1l1111llll_l1_:
		url3,url = l1l1111llll_l1_.split(l1l1ll_l1_ (u"ࠫ࠿ࡀࠧ䀪"))
		server = SERVER(url3,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩ䀫"))
		url = server+url
	else: url,url3 = l1l1111llll_l1_,l1l1111llll_l1_
	#headers2 = {l1l1ll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䀬"):url3,l1l1ll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䀭"):l1l1ll_l1_ (u"ࠨࠩ䀮")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䀯"),url,l1l1ll_l1_ (u"ࠪࠫ䀰"),l1l1ll_l1_ (u"ࠫࠬ䀱"),l1l1ll_l1_ (u"ࠬ࠭䀲"),l1l1ll_l1_ (u"࠭ࠧ䀳"),l1l1ll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䀴"))
	html = response.content
	if type==l1l1ll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ䀵"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷ࠱࠲࡚ࡡࡣࡵࡸ࡭ࠧ࠭䀶"),html,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䀷"):
		l1lll11_l1_ = [html.replace(l1l1ll_l1_ (u"ࠫࡡࡢ࠯ࠨ䀸"),l1l1ll_l1_ (u"ࠬ࠵ࠧ䀹")).replace(l1l1ll_l1_ (u"࠭࡜࡝ࠤࠪ䀺"),l1l1ll_l1_ (u"ࠧࠣࠩ䀻"))]
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡉࡵ࡭ࡩ࠳࠭ࡎࡻࡦ࡭ࡲࡧࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ䀼"),html,re.DOTALL)
	l1l1_l1_ = []
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩࡊࡶ࡮ࡪࡉࡵࡧࡰࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ䀽"),block,re.DOTALL)
		for link,title,img in items:
			if any(value in title.lower() for value in l1ll11_l1_): continue
			img = escapeUNICODE(img)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l1ll_l1_ (u"ู้ࠪอ็ะหࠣࠫ䀾"),l1l1ll_l1_ (u"ࠫࠬ䀿"))
			if l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䁀") in link: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䁁"),menu_name+title,link,363,img)
			elif l1l1ll_l1_ (u"ࠧฮๆๅอࠬ䁂") in title:
				l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠬฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫ䁃"),title,re.DOTALL)
				if l11111_l1_: title = l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䁄") + l11111_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁅"),menu_name+title,link,363,img)
			else:
				addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䁆"),menu_name+title,link,362,img)
		if type==l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䁇"):
			l1ll1ll11ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࠢ࡮ࡱࡵࡩࡤࡨࡵࡵࡶࡲࡲࡤࡶࡡࡨࡧࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫ䁈"),block,re.DOTALL)
			if l1ll1ll11ll_l1_:
				count = l1ll1ll11ll_l1_[0]
				link = url+l1l1ll_l1_ (u"ࠧ࠰ࡱࡩࡪࡸ࡫ࡴ࠰ࠩ䁉")+count
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䁊"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠฤะิํࠬ䁋"),link,361,l1l1ll_l1_ (u"ࠪࠫ䁌"),l1l1ll_l1_ (u"ࠫࠬ䁍"),l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䁎"))
		elif type==l1l1ll_l1_ (u"࠭ࠧ䁏"):
			l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ䁐"),html,re.DOTALL)
			if l1lll11_l1_:
				block = l1lll11_l1_[0]
				items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁑"),block,re.DOTALL)
				for link,title in items:
					title = l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨ䁒")+unescapeHTML(title)
					addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁓"),menu_name+title,link,361)
	return
def l11ll1l_l1_(url,type=l1l1ll_l1_ (u"ࠫࠬ䁔")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ䁕"),url,l1l1ll_l1_ (u"࠭ࠧ䁖"),l1l1ll_l1_ (u"ࠧࠨ䁗"),l1l1ll_l1_ (u"ࠨࠩ䁘"),l1l1ll_l1_ (u"ࠩࠪ䁙"),l1l1ll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ䁚"))
	html = response.content
	html = UNQUOTE(html)
	name = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡪࡶࡨࡱࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠫ࠲࠯ࡅࠩࠣࠩ䁛"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l1ll_l1_ (u"ࠬ࠳ࠧ䁜"),l1l1ll_l1_ (u"࠭ࠠࠨ䁝")).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩ䁞"))
	if l1l1ll_l1_ (u"ࠨ็๋ื๊࠭䁟") in name and type==l1l1ll_l1_ (u"ࠩࠪ䁠"):
		name = name.split(l1l1ll_l1_ (u"้ࠪํูๅࠨ䁡"))[0]
		name = name.replace(l1l1ll_l1_ (u"ฺ๊ࠫว่ัฬࠫ䁢"),l1l1ll_l1_ (u"ࠬ࠭䁣")).strip(l1l1ll_l1_ (u"࠭ࠠࠨ䁤"))
	elif l1l1ll_l1_ (u"ࠧฮๆๅอࠬ䁥") in name:
		name = name.split(l1l1ll_l1_ (u"ࠨฯ็ๆฮ࠭䁦"))[0]
		name = name.replace(l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩ䁧"),l1l1ll_l1_ (u"ࠪࠫ䁨")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭䁩"))
	else: name = name
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧࡥࡢࡵࡲࡲࡸ࠳࠭ࡆࡲ࡬ࡷࡴࡪࡥࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶ࡭ࡳ࡭࡬ࡦࡵࡨࡧࡹ࡯࡯࡯ࠩ䁪"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		if type==l1l1ll_l1_ (u"࠭ࠧ䁫"):
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ䁬"),block,re.DOTALL)
			for link,title in items:
				if l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ䁭") in title: continue
				if l1l1ll_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ䁮") in title: continue
				title = name+l1l1ll_l1_ (u"ࠪࠤ࠲ࠦࠧ䁯")+title
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䁰"),menu_name+title,link,363,l1l1ll_l1_ (u"ࠬ࠭䁱"),l1l1ll_l1_ (u"࠭ࠧ䁲"),l1l1ll_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䁳"))
		if len(menuItemsLIST)==0:
			l11ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䁴"),block+l1l1ll_l1_ (u"ࠩࠩࠪࠬ䁵"),re.DOTALL)
			if l11ll_l1_: block = l11ll_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䁶"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭䁷"))
				title = name+l1l1ll_l1_ (u"ࠬࠦ࠭ࠡࠩ䁸")+title
				addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䁹"),menu_name+title,link,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁺"),html,re.DOTALL)
		if title: title = title[0].replace(l1l1ll_l1_ (u"ࠨࠢ࠰ࠤ๊อ๊ࠡีํ้ฬ࠭䁻"),l1l1ll_l1_ (u"ࠩࠪ䁼")).replace(l1l1ll_l1_ (u"ู้ࠪอ็ะหࠣࠫ䁽"),l1l1ll_l1_ (u"ࠫࠬ䁾"))
		else: title = l1l1ll_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ䁿")
		addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䂀"),menu_name+title,url,362)
	return
def PLAY(url):
	l11l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ䂁"),url,l1l1ll_l1_ (u"ࠨࠩ䂂"),l1l1ll_l1_ (u"ࠩࠪ䂃"),l1l1ll_l1_ (u"ࠪࠫ䂄"),l1l1ll_l1_ (u"ࠫࠬ䂅"),l1l1ll_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䂆"))
	html = response.content
	l1ll111_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃอไหื้๎ๆࡂ࠮ࠫࡁ࠿ࡥ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䂇"),html,re.DOTALL)
	if l1ll111_l1_:
		l1ll111_l1_ = [l1ll111_l1_[0][0],l1ll111_l1_[0][1]]
		if l1ll111_l1_ and l1l1111_l1_(script_name,url,l1ll111_l1_): return
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡅ࡮ࡤࡨࡨࠧ࠭䂈"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䂉"),block,re.DOTALL)
		for link,name in items:
			if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䂊") not in link: link = l1l1l1_l1_+link
			if name==l1l1ll_l1_ (u"ࠪื๏ืแา่ࠢห๏ࠦำ๋็สࠫ䂋"): name = l1l1ll_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ䂌")
			link = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䂍")+name+l1l1ll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䂎")
			l11l1_l1_.append(link)
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡶࡸ࠲࠳ࡄࡰࡹࡱࡰࡴࡧࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ䂏"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䂐"),block,re.DOTALL)
		for link,l11ll1l1_l1_ in items:
			if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䂑") not in link: link = l1l1l1_l1_+link
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ䂒"),l11ll1l1_l1_,re.DOTALL)
			if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ䂓")+l11ll1l1_l1_[0]
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭䂔")
			link = link+l1l1ll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡭ࡺࡥ࡬ࡱࡦ࠭䂕")+l1l1ll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䂖")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䂗"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䂘"),url)
	return
def SEARCH(search,hostname=l1l1ll_l1_ (u"ࠪࠫ䂙")):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ䂚"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭䂛"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ䂜"),l1l1ll_l1_ (u"ࠧࠬࠩ䂝"))
	l11l1_l1_ = [l1l1ll_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ䂞"),l1l1ll_l1_ (u"ࠩ࠲ࠫ䂟"),l1l1ll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ䂠"),l1l1ll_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ䂡"),l1l1ll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ䂢")]
	l1l1ll11l_l1_ = [l1l1ll_l1_ (u"࠭วๅๅ็ࠫ䂣"),l1l1ll_l1_ (u"ࠧศๆฦๅ้อๅࠨ䂤"),l1l1ll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠫ䂥"),l1l1ll_l1_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭䂦"),l1l1ll_l1_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ䂧")]
	if showDialogs:
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้฼๊่ษ࠼ࠪ䂨"), l1l1ll11l_l1_)
		if selection==-1: return
	else: selection = 0
	if hostname==l1l1ll_l1_ (u"ࠬ࠭䂩"):
		response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ䂪"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠧࠨ䂫"),l1l1ll_l1_ (u"ࠨࠩ䂬"),False,l1l1ll_l1_ (u"ࠩࠪ䂭"),l1l1ll_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䂮"))
		hostname = response.headers[l1l1ll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䂯")]
		hostname = hostname.strip(l1l1ll_l1_ (u"ࠬ࠵ࠧ䂰"))
	url2 = hostname+l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ䂱")+search+l11l1_l1_[selection]
	l11l1l_l1_(url2)
	return
def l111l11_l1_(l1l1111llll_l1_,filter):
	if l1l1ll_l1_ (u"ࠧࡀࡁࠪ䂲") in l1l1111llll_l1_: url = l1l1111llll_l1_.split(l1l1ll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䂳"))[0]
	else: url = l1l1111llll_l1_
	#headers2 = {l1l1ll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䂴"):l1l1111llll_l1_,l1l1ll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䂵"):l1l1ll_l1_ (u"ࠫࠬ䂶")}
	filter = filter.replace(l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䂷"),l1l1ll_l1_ (u"࠭ࠧ䂸"))
	type,filter = filter.split(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ䂹"),1)
	if filter==l1l1ll_l1_ (u"ࠨࠩ䂺"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠩࠪ䂻"),l1l1ll_l1_ (u"ࠪࠫ䂼")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨ䂽"))
	if type==l1l1ll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ䂾"):
		if l1l1l11ll_l1_[0]+l1l1ll_l1_ (u"࠭࠽࠾ࠩ䂿") not in l1l1lll1_l1_: category = l1l1l11ll_l1_[0]
		for i in range(len(l1l1l11ll_l1_[0:-1])):
			if l1l1l11ll_l1_[i]+l1l1ll_l1_ (u"ࠧ࠾࠿ࠪ䃀") in l1l1lll1_l1_: category = l1l1l11ll_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠨࠨࠩࠫ䃁")+category+l1l1ll_l1_ (u"ࠩࡀࡁ࠵࠭䃂")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠪࠪࠫ࠭䃃")+category+l1l1ll_l1_ (u"ࠫࡂࡃ࠰ࠨ䃄")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠬࠬࠦࠨ䃅"))+l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪ䃆")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠨࠪ䃇"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䃈"))
		url2 = url+l1l1ll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䃉")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䃊"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䃋"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠬ࠭䃌"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䃍"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠧࠨ䃎"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ䃏")+l1l1ll1l_l1_
		l111l11l_l1_ = l1l111111_l1_(url2,l1l1111llll_l1_)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃐"),menu_name+l1l1ll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭䃑"),l111l11l_l1_,361,l1l1ll_l1_ (u"ࠫࠬ䃒"),l1l1ll_l1_ (u"ࠬ࠭䃓"),l1l1ll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䃔"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃕"),menu_name+l1l1ll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ䃖")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ䃗"),l111l11l_l1_,361,l1l1ll_l1_ (u"ࠪࠫ䃘"),l1l1ll_l1_ (u"ࠫࠬ䃙"),l1l1ll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䃚"))
		addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䃛"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䃜"),l1l1ll_l1_ (u"ࠨࠩ䃝"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭䃞"),url,l1l1ll_l1_ (u"ࠪࠫ䃟"),l1l1ll_l1_ (u"ࠫࠬ䃠"),l1l1ll_l1_ (u"ࠬ࠭䃡"),l1l1ll_l1_ (u"࠭ࠧ䃢"),l1l1ll_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䃣"))
	html = response.content
	html = html.replace(l1l1ll_l1_ (u"ࠨ࡞࡟ࠦࠬ䃤"),l1l1ll_l1_ (u"ࠩࠥࠫ䃥")).replace(l1l1ll_l1_ (u"ࠪࡠࡡ࠵ࠧ䃦"),l1l1ll_l1_ (u"ࠫ࠴࠭䃧"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂ࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵࡭ࡺࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ䃨"),html,re.DOTALL)
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ䃩"),block+l1l1ll_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ䃪"),re.DOTALL)
	dict = {}
	for l11111l_l1_,name,block in l1111ll_l1_:
		name = escapeUNICODE(name)
		if l1l1ll_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ䃫") in l11111l_l1_: continue
		items = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ䃬"),block,re.DOTALL)
		if l1l1ll_l1_ (u"ࠪࡁࡂ࠭䃭") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ䃮"):
			if category!=l11111l_l1_: continue
			elif len(items)<=1:
				if l11111l_l1_==l1l1l11ll_l1_[-1]: l11l1l_l1_(url2)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ䃯")+l1ll11l1_l1_)
				return
			else:
				l111l11l_l1_ = l1l111111_l1_(url2,l1l1111llll_l1_)
				if l11111l_l1_==l1l1l11ll_l1_[-1]:
					addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃰"),menu_name+l1l1ll_l1_ (u"ࠧศๆฯ้๏฿ࠧ䃱"),l111l11l_l1_,361,l1l1ll_l1_ (u"ࠨࠩ䃲"),l1l1ll_l1_ (u"ࠩࠪ䃳"),l1l1ll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䃴"))
				else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䃵"),menu_name+l1l1ll_l1_ (u"ࠬอไอ็ํ฽ࠬ䃶"),url2,364,l1l1ll_l1_ (u"࠭ࠧ䃷"),l1l1ll_l1_ (u"ࠧࠨ䃸"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䃹"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠩࠩࠪࠬ䃺")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࡂ࠶ࠧ䃻")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠫࠫࠬࠧ䃼")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠽࠱ࠩ䃽")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"࠭࡟ࡠࡡࠪ䃾")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃿"),menu_name+name+l1l1ll_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ䄀"),url2,365,l1l1ll_l1_ (u"ࠩࠪ䄁"),l1l1ll_l1_ (u"ࠪࠫ䄂"),l1ll11l1_l1_+l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䄃"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l1ll_l1_ (u"ࠬࡸࠧ䄄") or value==l1l1ll_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ䄅"): continue
			if any(value in option.lower() for value in l1ll11_l1_): continue
			if l1l1ll_l1_ (u"ࠧࡩࡶࡷࡴࠬ䄆") in option: continue
			if l1l1ll_l1_ (u"ࠨษ็็้࠭䄇") in option: continue
			if l1l1ll_l1_ (u"ࠩࡱ࠱ࡦ࠭䄈") in value: continue
			#if value in [l1l1ll_l1_ (u"ࠪࡶࠬ䄉"),l1l1ll_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ䄊"),l1l1ll_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ䄋")]: continue
			#if l11111l_l1_==l1l1ll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䄌"): option = value
			if option==l1l1ll_l1_ (u"ࠧࠨ䄍"): option = value
			l11llll11_l1_ = option
			name1 = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭䄎"),option,re.DOTALL)
			if name1: l11llll11_l1_ = name1[0]
			title2 = name+l1l1ll_l1_ (u"ࠩ࠽ࠤࠬ䄏")+l11llll11_l1_
			dict[l11111l_l1_][value] = title2
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠪࠪࠫ࠭䄐")+l11111l_l1_+l1l1ll_l1_ (u"ࠫࡂࡃࠧ䄑")+l11llll11_l1_
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠬࠬࠦࠨ䄒")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽࠾ࠩ䄓")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ䄔")+l1lll111_l1_
			if type==l1l1ll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䄕"):
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄖"),menu_name+title2,url,365,l1l1ll_l1_ (u"ࠪࠫ䄗"),l1l1ll_l1_ (u"ࠫࠬ䄘"),l111111_l1_+l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䄙"))
			elif type==l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䄚") and l1l1l11ll_l1_[-2]+l1l1ll_l1_ (u"ࠧ࠾࠿ࠪ䄛") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䄜"))
				#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪ䄝"),l1l1ll_l1_ (u"ࠪࠫ䄞"),l1l1l1l1_l1_,l1lll111_l1_)
				url3 = url+l1l1ll_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䄟")+l1l1l1l1_l1_
				l111l11l_l1_ = l1l111111_l1_(url3,l1l1111llll_l1_)
				addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䄠"),menu_name+title2,l111l11l_l1_,361,l1l1ll_l1_ (u"࠭ࠧ䄡"),l1l1ll_l1_ (u"ࠧࠨ䄢"),l1l1ll_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䄣"))
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䄤"),menu_name+title2,url,364,l1l1ll_l1_ (u"ࠪࠫ䄥"),l1l1ll_l1_ (u"ࠫࠬ䄦"),l111111_l1_)
	return
l1l1l11ll_l1_ = [l1l1ll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ䄧"),l1l1ll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ䄨"),l1l1ll_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ䄩")]
l1l11llll_l1_ = [l1l1ll_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭䄪"),l1l1ll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ䄫"),l1l1ll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ䄬"),l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭䄭"),l1l1ll_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭䄮"),l1l1ll_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ䄯"),l1l1ll_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ䄰"),l1l1ll_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ䄱")]
def l1l111111_l1_(url2,url3):
	if l1l1ll_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䄲") in url2: url2 = url2.replace(l1l1ll_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䄳"),l1l1ll_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ䄴"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䄵"),l1l1ll_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ䄶"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠧ࠾࠿ࠪ䄷"),l1l1ll_l1_ (u"ࠨ࠱ࠪ䄸"))
	url2 = url2.replace(l1l1ll_l1_ (u"ࠩࠩࠪࠬ䄹"),l1l1ll_l1_ (u"ࠪ࠳ࠬ䄺"))
	return url2
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ䄻"),l1l1ll_l1_ (u"ࠬ࠭䄼"),filters,l1l1ll_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭䄽")+mode)
	# mode==l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ䄾")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䄿")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠩࡤࡰࡱ࠭䅀")					all filters (l1l1l111_l1_ l1ll1l1l_l1_ filter)
	filters = filters.strip(l1l1ll_l1_ (u"ࠪࠪࠫ࠭䅁"))
	l1l1llll_l1_,l1llllll_l1_ = {},l1l1ll_l1_ (u"ࠫࠬ䅂")
	if l1l1ll_l1_ (u"ࠬࡃ࠽ࠨ䅃") in filters:
		items = filters.split(l1l1ll_l1_ (u"࠭ࠦࠧࠩ䅄"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠧ࠾࠿ࠪ䅅"))
			l1l1llll_l1_[var] = value
	for key in l1l11llll_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠨ࠲ࠪ䅆")
		if l1l1ll_l1_ (u"ࠩࠨࠫ䅇") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ䅈") and value!=l1l1ll_l1_ (u"ࠫ࠵࠭䅉"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩ䅊")+value
		elif mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䅋") and value!=l1l1ll_l1_ (u"ࠧ࠱ࠩ䅌"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠨࠨࠩࠫ䅍")+key+l1l1ll_l1_ (u"ࠩࡀࡁࠬ䅎")+value
		elif mode==l1l1ll_l1_ (u"ࠪࡥࡱࡲࠧ䅏"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠫࠬࠧ䅐")+key+l1l1ll_l1_ (u"ࠬࡃ࠽ࠨ䅑")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪ䅒"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠧࠧࠨࠪ䅓"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩ䅔"),l1l1ll_l1_ (u"ࠩࠪ䅕"),l1llllll_l1_,l1l1ll_l1_ (u"ࠪࡓ࡚࡚ࠧ䅖"))
	return l1llllll_l1_
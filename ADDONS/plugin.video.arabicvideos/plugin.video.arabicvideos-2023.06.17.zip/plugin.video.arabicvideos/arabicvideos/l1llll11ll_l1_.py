# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ៶")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡈࡉࡂࡠࠩ៷")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭៸"),l1l1ll_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭៹"),l1l1ll_l1_ (u"࠭สิฮํ่ࠬ៺"),l1l1ll_l1_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬ៻")]
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l11l1l_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l11_l1_(url,text)
	elif mode==634: results = l1ll1l_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ៼"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠩࠪ៽"),l1l1ll_l1_ (u"ࠪࠫ៾"),l1l1ll_l1_ (u"ࠫࠬ៿"),l1l1ll_l1_ (u"ࠬ࠭᠀"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ᠁"))
	html = response.content
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠂"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ᠃"),l1l1ll_l1_ (u"ࠩࠪ᠄"),639,l1l1ll_l1_ (u"ࠪࠫ᠅"),l1l1ll_l1_ (u"ࠫࠬ᠆"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᠇"))
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᠈"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᠉"),l1l1ll_l1_ (u"ࠨࠩ᠊"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᠋"),script_name+l1l1ll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᠌")+menu_name+l1l1ll_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ᠍"),l1l1l1_l1_,631,l1l1ll_l1_ (u"ࠬ࠭᠎"),l1l1ll_l1_ (u"࠭ࠧ᠏"),l1l1ll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ᠐"))
	#addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠑"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᠒")+menu_name+l1l1ll_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩ᠓"),l1l1l1_l1_,631,l1l1ll_l1_ (u"ࠫࠬ᠔"),l1l1ll_l1_ (u"ࠬ࠭᠕"),l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ᠖"))
	#addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠗"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᠘")+menu_name+l1l1ll_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨ᠙"),l1l1l1_l1_,631,l1l1ll_l1_ (u"ࠪࠫ᠚"),l1l1ll_l1_ (u"ࠫࠬ᠛"),l1l1ll_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩ᠜"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠝"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᠞")+menu_name+l1l1ll_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬ᠟"),l1l1l1_l1_,631,l1l1ll_l1_ (u"ࠩࠪᠠ"),l1l1ll_l1_ (u"ࠪࠫᠡ"),l1l1ll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᠢ"))
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᠣ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᠤ"),l1l1ll_l1_ (u"ࠧࠨᠥ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᠦ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᠧ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		if title==l1l1ll_l1_ (u"ࠪวาีหࠡษ็ั้่วหࠩᠨ"): mode,request = 631,l1l1ll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᠩ")
		else: mode,request = 634,l1l1ll_l1_ (u"ࠬ࠭ᠪ")
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᠫ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᠬ")+menu_name+title,link,mode,l1l1ll_l1_ (u"ࠨࠩᠭ"),l1l1ll_l1_ (u"ࠩࠪᠮ"),request)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᠯ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᠰ"),l1l1ll_l1_ (u"ࠬ࠭ᠱ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᠲ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᠳ"),html,re.DOTALL)
	for l11ll_l1_ in l1lll11_l1_: block = block.replace(l11ll_l1_,l1l1ll_l1_ (u"ࠨࠩᠴ"))
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᠵ"),block,re.DOTALL)
	for link,title in items:
		if title in l1ll11_l1_: continue
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᠶ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᠷ")+menu_name+title,link,634)
	return
def l1ll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩᠸ"),url,l1l1ll_l1_ (u"࠭ࠧᠹ"),l1l1ll_l1_ (u"ࠧࠨᠺ"),l1l1ll_l1_ (u"ࠨࠩᠻ"),l1l1ll_l1_ (u"ࠩࠪᠼ"),l1l1ll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᠽ"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᠾ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		block = l1ll1ll_l1_[0]
		block = block.replace(l1l1ll_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭ᠿ"),l1l1ll_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬᡀ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᡁ"),block,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = [(l1l1ll_l1_ (u"ࠨࠩᡂ"),block)]
		addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᡃ"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᡄ"),l1l1ll_l1_ (u"ࠫࠬᡅ"),9999)
		for l1l111_l1_,block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᡆ"),block,re.DOTALL)
			if l1l111_l1_: l1l111_l1_ = l1l111_l1_+l1l1ll_l1_ (u"࠭࠺ࠡࠩᡇ")
			for link,title in items:
				title = l1l111_l1_+title
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡈ"),menu_name+title,link,631)
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᡉ"),html,re.DOTALL)
	if l1ll1l1_l1_:
		block = l1ll1l1_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᡊ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᡋ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᡌ"),l1l1ll_l1_ (u"ࠬ࠭ᡍ"),9999)
			for link,title in items:
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᡎ"),menu_name+title,link,631)
	l1l1ll_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠵ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡵࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮࠮ࡪࡨࡥࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠵࠽ࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠸ࡡ࠰࡞ࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫ࡭ࡹ࡫࡭ࡴࠫ࠿࠷࠵ࡀࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࠉࠊࡨࡲࡶࠥࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠶࠴࠳ࠬࠎࠎ࡯ࡦࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠴ࠤࡦࡴࡤࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠵ࠤࡦࡴࡤࠡࡰࡲࡸࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶࠾࡚ࠥࡉࡕࡎࡈࡗ࠭ࡻࡲ࡭ࠫࠍࠍࠧࠨࠢᡏ")
	if not l1ll1ll_l1_ and not l1ll1l1_l1_: l11l1l_l1_(url)
	return
def l11l1l_l1_(url,request=l1l1ll_l1_ (u"ࠨࠩᡐ")):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪᡑ"),l1l1ll_l1_ (u"ࠪࠫᡒ"),request,url)
	if request==l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᡓ"):
		url,search = url.split(l1l1ll_l1_ (u"ࠬࡅࠧᡔ"),1)
		data = l1l1ll_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬᡕ")+search
		headers = {l1l1ll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᡖ"):l1l1ll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨᡗ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧᡘ"),url,data,headers,l1l1ll_l1_ (u"ࠪࠫᡙ"),l1l1ll_l1_ (u"ࠫࠬᡚ"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᡛ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᡜ"),url,l1l1ll_l1_ (u"ࠧࠨᡝ"),l1l1ll_l1_ (u"ࠨࠩᡞ"),l1l1ll_l1_ (u"ࠩࠪᡟ"),l1l1ll_l1_ (u"ࠪࠫᡠ"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᡡ"))
	html = response.content
	block,items = l1l1ll_l1_ (u"ࠬ࠭ᡢ"),[]
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪᡣ"))
	if request==l1l1ll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬᡤ"):
		block = html
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᡥ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((link,title,l1l1ll_l1_ (u"ࠩࠪᡦ")))
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᡧ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡶࡴࡻࡳࡦ࡮ࡢࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᡨ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠬ࠭ࠧࠣࡲࡲࡷࡹࡈ࡬ࡰࡥ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠨࠩࠪᡩ"),block,re.DOTALL)
	elif request==l1l1ll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᡪ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᡫ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬᡬ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᡭ"),html,re.DOTALL)
		if len(l1lll11_l1_)>1: block = l1lll11_l1_[1]
	elif request==l1l1ll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᡮ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ᡯ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᡰ"),block,re.DOTALL)
		for link,title in l1lll1l_l1_: items.append((link,title,l1l1ll_l1_ (u"࠭ࠧᡱ")))
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᡲ"),html,re.DOTALL)
		if l1lll11_l1_: block = l1lll11_l1_[0]
	if block and not items: items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᡳ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l111l_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩᡴ"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨᡵ"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪᡶ"),l1l1ll_l1_ (u"้ࠬไ๋สࠪᡷ"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬᡸ"),l1l1ll_l1_ (u"่ࠧัสๅࠬ᡹"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨ᡺"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭᡻"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪ᡼"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪ᡽"),l1l1ll_l1_ (u"๋ࠬำาฯํอࠬ᡾")]
	for link,title,img in items:
		#LOG_THIS(l1l1ll_l1_ (u"࠭ࠧ᡿"),link)
		#link = UNQUOTE(link).strip(l1l1ll_l1_ (u"ࠧ࠰ࠩᢀ"))
		#if l1l1ll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᢁ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫᢂ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬᢃ"))
		#if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᢄ") not in img: img = l11ll1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧᢅ")+img.strip(l1l1ll_l1_ (u"࠭࠯ࠨᢆ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l1l1ll_l1_ (u"ࠧࠡࠩᢇ"))
		title = title.replace(l1l1ll_l1_ (u"ࠨࠢึ๎๊อࠠไๆ๋ฬࠬᢈ"),l1l1ll_l1_ (u"ࠩࠪᢉ"))
		title = title.replace(l1l1ll_l1_ (u"ࠪࠤฬ๎ๆࠡๆส๎๋࠭ᢊ"),l1l1ll_l1_ (u"ࠫࠬᢋ"))
		l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤ࠭อไฮๆๅอࢁำไใหࠬ࠲ࡡࡪࠫࠨᢌ"),title,re.DOTALL)
		if l1l1ll_l1_ (u"࠭ࡗࡘࡇࠪᢍ") in title: continue
		elif any(value in title for value in l111l_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᢎ"),menu_name+title,link,632,img)
		elif request==l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧᢏ"):
			addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᢐ"),menu_name+title,link,632,img)
		elif l11111_l1_:
			title = l1l1ll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩᢑ") + l11111_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢒ"),menu_name+title,link,633,img)
				l1l1_l1_.append(title)
		#elif l1l1ll_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪᢓ") in link:
		#	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢔ"),menu_name+title,link,631,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢕ"),menu_name+title,link,633,img)
	if 1: #if request not in [l1l1ll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧᢖ"),l1l1ll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᢗ")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᢘ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᢙ"),block,re.DOTALL)
			for link,title in items:
				if link==l1l1ll_l1_ (u"ࠬࠩࠧᢚ"): continue
				link = l11ll1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨᢛ")+link.strip(l1l1ll_l1_ (u"ࠧ࠰ࠩᢜ"))
				title = unescapeHTML(title)
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢝ"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨᢞ")+title,link,631)
	return
def l11_l1_(url,l1lll_l1_):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫᢟ"),l1l1ll_l1_ (u"ࠫࠬᢠ"),l1lll_l1_,url)
	l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠬࡻࡲ࡭ࠩᢡ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᢢ"),url,l1l1ll_l1_ (u"ࠧࠨᢣ"),l1l1ll_l1_ (u"ࠨࠩᢤ"),l1l1ll_l1_ (u"ࠩࠪᢥ"),l1l1ll_l1_ (u"ࠪࠫᢦ"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬᢧ"))
	html = response.content
	image = re.findall(l1l1ll_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᢨ"),html,re.DOTALL)
	if image: img = image[0]
	else: img = l1l1ll_l1_ (u"ᢩ࠭ࠧ")
	items = []
	# l11l11_l1_
	l1l11_l1_ = False
	l1ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᢪ"),html,re.DOTALL)
	if l1ll1ll_l1_ and not l1lll_l1_:
		block = l1ll1ll_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࠩࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬ࠯ࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ࠧࠨ᢫"),block,re.DOTALL)
		for l1lll_l1_,title in items:
			l1lll_l1_ = l1lll_l1_.strip(l1l1ll_l1_ (u"ࠩࠦࠫ᢬"))
			if len(items)>1: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᢭"),menu_name+title,url,633,img,l1l1ll_l1_ (u"ࠫࠬ᢮"),l1lll_l1_)
			else: l1l11_l1_ = True
	else: l1l11_l1_ = True
	# l1ll1_l1_
	l1ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ᢯")+l1lll_l1_+l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᢰ"),html,re.DOTALL)
	if l1ll1l1_l1_ and l1l11_l1_:
		block = l1ll1l1_l1_[0]
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᢱ"),block,re.DOTALL)
		items = []
		for link,title in l1lll1l_l1_: items.append((link,title,img))
		if not items: items = re.findall(l1l1ll_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᢲ"),block,re.DOTALL)
		for link,title,img in items:
			#link = l11ll1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࠫᢳ")+link.strip(l1l1ll_l1_ (u"ࠪ࠳ࠬᢴ"))
			link = link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᢵ"))
			title = title.replace(l1l1ll_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᢶ"),l1l1ll_l1_ (u"࠭ࠠࠨᢷ"))
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᢸ"),menu_name+title,link,632,img)
		#else:
		#	items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᢹ"),block,re.DOTALL)
		#	for link,title,img in items:
		#		if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᢺ") not in link: link = l11ll1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬᢻ")+link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᢼ"))
		#		addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᢽ"),menu_name+title,link,632,img)
	return
def PLAY(url):
	l11l1_l1_,l1l1ll11l_l1_,l111ll1_l1_ = [],[],[]
	# l11lllll1_l1_ l1ll_l1_
	url2 = url.replace(l1l1ll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᢾ"),l1l1ll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪᢿ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬᣀ"),url2,l1l1ll_l1_ (u"ࠩࠪᣁ"),l1l1ll_l1_ (u"ࠪࠫᣂ"),l1l1ll_l1_ (u"ࠫࠬᣃ"),l1l1ll_l1_ (u"ࠬ࠭ᣄ"),l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪᣅ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣆ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠣࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠥᣇ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᣈ")+title+l1l1ll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᣉ"))
				l11l1_l1_.append(link)
	# download l1ll_l1_
	url2 = url.replace(l1l1ll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨᣊ"),l1l1ll_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࡴ࠰ࡳ࡬ࡵ࠭ᣋ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᣌ"),url2,l1l1ll_l1_ (u"ࠧࠨᣍ"),l1l1ll_l1_ (u"ࠨࠩᣎ"),l1l1ll_l1_ (u"ࠩࠪᣏ"),l1l1ll_l1_ (u"ࠪࠫᣐ"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᣑ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣒ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿ࠩᣓ"),block,re.DOTALL)
		for link,title in l1ll_l1_:
			if link not in l11l1_l1_:
				l1l1ll11l_l1_.append(l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᣔ")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᣕ"))
				l11l1_l1_.append(link)
	zzz = zip(l11l1_l1_,l1l1ll11l_l1_)
	for link,name in zzz: l111ll1_l1_.append(link+name)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧᣖ"),l111ll1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l111ll1_l1_,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᣗ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬᣘ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭ᣙ"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨᣚ"),l1l1ll_l1_ (u"ࠧࠬࠩᣛ"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩᣜ")+search
	l11l1l_l1_(url,l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᣝ"))
	#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧᣞ")+search
	#l11l1l_l1_(url,l1l1ll_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᣟ"))
	return
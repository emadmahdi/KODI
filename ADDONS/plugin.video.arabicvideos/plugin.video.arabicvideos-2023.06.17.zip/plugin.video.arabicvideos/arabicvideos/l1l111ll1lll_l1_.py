# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ啔")
menu_name = l1l1ll_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ啕")
l1l1l1_l1_ = WEBSITES[script_name][0]
headers = {l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ啖"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l11l1l_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1l111ll1ll1_l1_(url)
	elif mode==314: results = l1111ll1_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ啗"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ啘"),l1l1ll_l1_ (u"ࠩࠪ啙"),319,l1l1ll_l1_ (u"ࠪࠫ啚"),l1l1ll_l1_ (u"ࠫࠬ啛"),l1l1ll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ啜"))
	#addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭啝"),menu_name+l1l1ll_l1_ (u"ࠧโๆอีࠬ啞"),l1l1ll_l1_ (u"ࠨࠩ啟"),114,l1l1l1_l1_)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭啠"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠪࠫ啡"),l1l1ll_l1_ (u"ࠫࠬ啢"),l1l1ll_l1_ (u"ࠬ࠭啣"),l1l1ll_l1_ (u"࠭ࠧ啤"),l1l1ll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ啥"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷ࡯࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ啦"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ啧"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ啨"),l1l1ll_l1_ (u"ࠫࠬ啩"),9999)
	items = re.findall(l1l1ll_l1_ (u"ࠬࡂࡨ࠶ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠹ࡃ࠭啪"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l1ll_l1_ (u"࠭ࠠࠨ啫"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ啬"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ啭")+menu_name+title,l1l1l1_l1_,314,l1l1ll_l1_ (u"ࠩࠪ啮"),l1l1ll_l1_ (u"ࠪࠫ啯"),str(seq+1))
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ啰"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ啱")+menu_name+l1l1ll_l1_ (u"࠭ๅใษฺ฽ฺࠥ็าࠩ啲"),l1l1l1_l1_,314,l1l1ll_l1_ (u"ࠧࠨ啳"),l1l1ll_l1_ (u"ࠨࠩ啴"),l1l1ll_l1_ (u"ࠩ࠳ࠫ啵"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ啶"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ啷"),l1l1ll_l1_ (u"ࠬ࠭啸"),9999)
	items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡄࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡆࡃ࠭啹"),block,re.DOTALL)
	for link,title in items:
		link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ啺")+link
		#title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ啻"))
		#url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡄ࡫ࡰࡥࡓࡵࡷ࠰ࡋࡱࡸࡪࡸࡦࡢࡥࡨ࠳࡫࡯࡬ࡵࡧࡵ࠲ࡵ࡮ࡰࠨ啼")
		addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啽"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭啾")+menu_name+title,link,311)
	return html
def l1111ll1_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ啿"),l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧ喀"),l1l1ll_l1_ (u"ࠧࠨ喁"),l1l1ll_l1_ (u"ࠨࠩ喂"),l1l1ll_l1_ (u"ࠩࠪ喃"),l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ善"))
	html = response.content
	if seq==l1l1ll_l1_ (u"ࠫ࠵࠭喅"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡡࡣ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡦࡨ࡬ࡦࡀࠪ喆"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭喇"),block,re.DOTALL)
		for link,name,title in items:
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ喈")+link
			title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ喉"))
			name = name.strip(l1l1ll_l1_ (u"ࠩࠣࠫ喊"))
			title = title+l1l1ll_l1_ (u"ࠪࠤ࠭࠭喋")+name+l1l1ll_l1_ (u"ࠫ࠮࠭喌")
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ喍"),menu_name+title,link,312)
	elif seq in [l1l1ll_l1_ (u"࠭࠱ࠨ喎"),l1l1ll_l1_ (u"ࠧ࠳ࠩ喏"),l1l1ll_l1_ (u"ࠨ࠵ࠪ喐")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳࡬ࡨࠩ喑"),html,re.DOTALL)
		l1l111ll1l1l_l1_ = int(seq)-1
		block = l1lll11_l1_[l1l111ll1l1l_l1_]
		if seq==l1l1ll_l1_ (u"ࠪ࠵ࠬ喒"): items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ喓"),block,re.DOTALL)
		else: items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭喔"),block,re.DOTALL)
		for link,img,title,name in items:
			img = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࠨ喕")+img
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ喖")+link
			title = title.strip(l1l1ll_l1_ (u"ࠨࠢࠪ喗"))
			name = name.strip(l1l1ll_l1_ (u"ࠩࠣࠫ喘"))
			title = title+l1l1ll_l1_ (u"ࠪࠤ࠭࠭喙")+name+l1l1ll_l1_ (u"ࠫ࠮࠭喚")
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喛"),menu_name+title,link,311,img)
	elif seq in [l1l1ll_l1_ (u"࠭࠴ࠨ喜"),l1l1ll_l1_ (u"ࠧ࠶ࠩ喝"),l1l1ll_l1_ (u"ࠨ࠸ࠪ喞")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠫࡀ࡭࠻࠾࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭喟"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1lll11_l1_[seq]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅ࠭ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭喠"),block,re.DOTALL)
		for img,link,name1,title,name2 in items:
			img = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭喡")+img
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࠧ喢")+link
			title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ喣"))
			name1 = name1.strip(l1l1ll_l1_ (u"ࠧࠡࠩ喤"))
			name2 = name2.strip(l1l1ll_l1_ (u"ࠨࠢࠪ喥"))
			if name1: name = name1
			else: name = name2
			title = title+l1l1ll_l1_ (u"ࠩࠣࠬࠬ喦")+name+l1l1ll_l1_ (u"ࠪ࠭ࠬ喧")
			addMenuItem(l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ喨"),menu_name+title,link,312,img)
	return
def l11l1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ喩"),url,l1l1ll_l1_ (u"࠭ࠧ喪"),l1l1ll_l1_ (u"ࠧࠨ喫"),l1l1ll_l1_ (u"ࠨࠩ喬"),l1l1ll_l1_ (u"ࠩࠪ喭"),l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ單"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࡮ࡨ࡯ࡹ࠯࡫ࡩࡦࡪࡩ࡯ࡩࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡯ࡳࡦࡺ࠭ࡳ࡫ࡪ࡬ࡹ࠭喯"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	if l1l1ll_l1_ (u"ࠬࡩࡡࡵࡵࡸࡱ࠲ࡳ࡯ࡣ࡫࡯ࡩࠬ喰") in block:
		items = re.findall(l1l1ll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃࡨࡧࡴࡴࡷࡰ࠱ࡲࡵࡢࡪ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ喱"),block,re.DOTALL)
		if items:
			for img,link,title,count in items:
				img = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࠩ喲")+img
				link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࠪ喳")+link
				count = count.replace(l1l1ll_l1_ (u"ࠩࠣห้฻่ห์ฬ࠾ࠥ࠭喴"),l1l1ll_l1_ (u"ࠪ࠾ࠬ喵"))
				title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭営"))
				title = title+l1l1ll_l1_ (u"ࠬࠦࠨࠨ喷")+count+l1l1ll_l1_ (u"࠭ࠩࠨ喸")
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ喹"),menu_name+title,link,311,img)
	else:
		items = re.findall(l1l1ll_l1_ (u"ࠨࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ喺"),block,re.DOTALL)
		for link,title,l1l111lll111_l1_,duration in items:
			if title==l1l1ll_l1_ (u"ࠩࠪ喻") or l1l111lll111_l1_==l1l1ll_l1_ (u"ࠪࠫ喼"): continue
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭喽")+link
			title = title+l1l1ll_l1_ (u"ࠬࠦࠨࠨ喾")+duration+l1l1ll_l1_ (u"࠭ࠩࠨ喿")
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嗀"),menu_name+title,link,312)
	if not items: l11ll1l_l1_(html)
	return
def l11ll1l_l1_(html):
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩ嗁"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡧ࡯ࡰࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嗂"),block,re.DOTALL)
	for link,title,name,count,duration in items:
		link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࠬ嗃")+link
		title = title.strip(l1l1ll_l1_ (u"ࠫࠥ࠭嗄"))
		name = name.strip(l1l1ll_l1_ (u"ࠬࠦࠧ嗅"))
		title = title+l1l1ll_l1_ (u"࠭ࠠࠩࠩ嗆")+name+l1l1ll_l1_ (u"ࠧࠪࠩ嗇")
		addMenuItem(l1l1ll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嗈"),menu_name+title,link,312,l1l1ll_l1_ (u"ࠩࠪ嗉"),duration)
	return
def l1l111ll1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ嗊"),url,l1l1ll_l1_ (u"ࠫࠬ嗋"),l1l1ll_l1_ (u"ࠬ࠭嗌"),l1l1ll_l1_ (u"࠭ࠧ嗍"),l1l1ll_l1_ (u"ࠧࠨ嗎"),l1l1ll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋࡣࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ嗏"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠡࡲ࠰࠵ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ嗐"),html,re.DOTALL)
	if not l1lll11_l1_:
		l11l1l_l1_(url)
		return
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀࠬ嗑"),block,re.DOTALL)
	for link,title in items:
		link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࠭嗒")+link
		title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ嗓"))
		if l1l1ll_l1_ (u"࠭࠯ࡱ࡮ࡤࡽ࠲࠭嗔") in link: addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嗕"),menu_name+title,link,312)
		else: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嗖"),menu_name+title,link,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭嗗"),url,l1l1ll_l1_ (u"ࠪࠫ嗘"),l1l1ll_l1_ (u"ࠫࠬ嗙"),l1l1ll_l1_ (u"ࠬ࠭嗚"),l1l1ll_l1_ (u"࠭ࠧ嗛"),l1l1ll_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嗜"))
	html = response.content
	link = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡤࡹࡩ࡯࡯࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗝"),html,re.DOTALL)
	if not link: link = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡺ࡮ࡪࡥࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗞"),html,re.DOTALL)
	link = l1l1l1_l1_+link[0]
	PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嗟"))
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠫࠬ嗠"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠬ࠭嗡"): return
	search = search.replace(l1l1ll_l1_ (u"࠭ࠠࠨ嗢"),l1l1ll_l1_ (u"ࠧࠬࠩ嗣"))
	typeList = [l1l1ll_l1_ (u"ࠨࠨࡷࡁࡦ࠭嗤"),l1l1ll_l1_ (u"ࠩࠩࡸࡂࡩࠧ嗥"),l1l1ll_l1_ (u"ࠪࠪࡹࡃࡳࠨ嗦")]
	if showDialogs:
		searchTitle = [l1l1ll_l1_ (u"ࠫ็อัวࠩ嗧"),l1l1ll_l1_ (u"ࠬหีะษิࠤ࠴ࠦๅอๆาࠫ嗨"),l1l1ll_l1_ (u"࠭ๅใู฼ࠤฬ๊ี้ฬํࠫ嗩")]
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢ࠰ࠤศิสาࠢส่อำหࠨ嗪"), searchTitle)
		if selection == -1: return
	elif l1l1ll_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘࡥࠧ嗫") in options: selection = 0
	elif l1l1ll_l1_ (u"ࠩࡢࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡍࡄࡘࡑࡘࡥࠧ嗬") in options: selection = 1
	elif l1l1ll_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡗࡇࡍࡔ࡙࡟ࠨ嗭") in options: selection = 2
	else: return
	type = typeList[selection]
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ嗮")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ嗯"),url,l1l1ll_l1_ (u"࠭ࠧ嗰"),l1l1ll_l1_ (u"ࠧࠨ嗱"),l1l1ll_l1_ (u"ࠨࠩ嗲"),l1l1ll_l1_ (u"ࠩࠪ嗳"),l1l1ll_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ嗴"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ嗵"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		if selection in [0,1]:
			items = re.findall(l1l1ll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嗶"),block,re.DOTALL)
			for link,img,title,name in items:
				title = title.strip(l1l1ll_l1_ (u"࠭ࠠࠨ嗷"))
				name = name.strip(l1l1ll_l1_ (u"ࠧࠡࠩ嗸"))
				title = title+l1l1ll_l1_ (u"ࠨࠢࠫࠫ嗹")+name+l1l1ll_l1_ (u"ࠩࠬࠫ嗺")
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗻"),menu_name+title,link,313,img)
		elif selection==2:
			items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡸࡩࡄ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嗼"),block,re.DOTALL)
			for link,title,name in items:
				title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧ嗽"))
				name = name.strip(l1l1ll_l1_ (u"࠭ࠠࠨ嗾"))
				title = title+l1l1ll_l1_ (u"ࠧࠡࠪࠪ嗿")+name+l1l1ll_l1_ (u"ࠨࠫࠪ嘀")
				addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ嘁"),menu_name+title,link,312)
	return
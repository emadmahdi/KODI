# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
import bs4
script_name = l1l1ll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ⓺")
menu_name = l1l1ll_l1_ (u"ࠪࡣࡊࡒࡃࡠࠩ⓻")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = []
def MAIN(mode,url,text):
	if   mode==510: results = MENU(url)
	elif mode==511: results = l1lll1111l1_l1_(url)
	elif mode==512: results = l1llll111l1_l1_(url)
	elif mode==513: results = l1llll1111l_l1_(url)
	elif mode==514: results = l1lll1111ll_l1_(url,l1l1ll_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⓼")+text)
	elif mode==515: results = l1lll1111ll_l1_(url,l1l1ll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⓽")+text)
	elif mode==516: results = l1lll1l111l_l1_(text)
	elif mode==517: results = l1lll1ll1l1_l1_(url)
	elif mode==518: results = l1lll1ll1ll_l1_(url)
	elif mode==519: results = SEARCH(text)
	elif mode==520: results = l1lll1l1l11_l1_(url)
	elif mode==521: results = l1lll11111l_l1_(url)
	elif mode==522: results = PLAY(url)
	elif mode==523: results = l1lll111l1l_l1_(text)
	elif mode==524: results = l1lll111lll_l1_()
	elif mode==525: results = l1llll11111_l1_()
	elif mode==526: results = l1lll1l11ll_l1_()
	elif mode==527: results = l1lll11l111_l1_()
	else: results = False
	return results
def MENU(website=l1l1ll_l1_ (u"࠭ࠧ⓾")):
	if not website:
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⓿"),menu_name+l1l1ll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ─"),l1l1ll_l1_ (u"ࠩࠪ━"),519)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ│"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭┃"),l1l1ll_l1_ (u"ࠬ࠭┄"),9999)
		addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┅"),menu_name+l1l1ll_l1_ (u"ࠧๆ๊ึ์฾ฯࠠศๆฦ฽๊อไࠨ┆"),l1l1ll_l1_ (u"ࠨࠩ┇"),525)
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ┈"),menu_name+l1l1ll_l1_ (u"้ࠪํฺู่หࠣห้ษิฯษุࠫ┉"),l1l1ll_l1_ (u"ࠫࠬ┊"),526)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┋"),menu_name+l1l1ll_l1_ (u"࠭ๅ้ี๋฽ฮࠦวๅ็ุ๊ๆอสࠨ┌"),l1l1ll_l1_ (u"ࠧࠨ┍"),527)
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┎"),menu_name+l1l1ll_l1_ (u"่ࠩ์ุ๎ูสࠢส่๊์ฺ่ษอࠫ┏"),l1l1ll_l1_ (u"ࠪࠫ┐"),524)
	return
def l1lll111lll_l1_():
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┑"),menu_name+l1l1ll_l1_ (u"ࠬࠦแ๋ัํ์์อสࠡ࠯ࠣาฬ฻ษࠨ┒"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠭┓"),520)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ└"),menu_name+l1l1ll_l1_ (u"ࠨใํำ๏๎็ศฬࠣ࠱ࠥษอะอࠪ┕"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱࡯ࡥࡹ࡫ࡳࡵࠩ┖"),521)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┗"),menu_name+l1l1ll_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦ࠭ࠡลๅำ๊࠭┘"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴ࡵ࡬ࡥࡧࡶࡸࠬ┙"),521)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┚"),menu_name+l1l1ll_l1_ (u"ࠧโ์า๎ํํวหࠢ࠰ࠤศ้หาุ่ࠢฬํฯสࠩ┛"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࡸ࡬ࡩࡼࡹࠧ├"),521)
	return
def l1llll11111_l1_():
	l1l1ll_l1_ (u"ࠤࠥࠦࠒࠐࠉࡵࡻࡳࡩࠥࡃࠠ࠲ࠢࠦࠤࡦࡩࡴࡰࡴࡶࠑࠏࠏࡴࡺࡲࡨࠤࡂࠦ࠲ࠡࠥࠣࡺ࡮ࡪࡥࡰࡵࠐࠎࠎࡩࡡࡵࡧࡪࡳࡷࡿࠠ࠾ࠢ࠴ࠤࠨࠦ࡭ࡰࡸ࡬ࡩࡸࠓࠊࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠹ࠠࠤࠢࡶࡩࡷ࡯ࡥࡴࠏࠍࠍ࡫ࡵࡲࡦ࡫ࡪࡲࠥࡃࠠࡧࡣ࡯ࡷࡪࠦࠣࠡࡣࡵࡥࡧ࡯ࡣࠎࠌࠌࡪࡴࡸࡥࡪࡩࡱࠤࡂࠦࡴࡳࡷࡨࠤࠨࠦࡥ࡯ࡩ࡯࡭ࡸ࡮ࠍࠋࠋࠦࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧๆ็ฮ่๏์ࠠฤใ็หู๊ࠦาสํࠫ࠱ࡲࡩ࡯࡭࠵࠰࠺࠷࠱ࠪࠏࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥ่้ࠬࠩะ๊๊็่ࠢืู้ไศฬࠣ฽ึฮ๊ࠨ࠮࡯࡭ࡳࡱ࠳࠭࠷࠴࠵࠮ࠓࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭ๅๆอ็๎๋ࠦรโๆส้ࠥอฬ็สํࠫ࠱ࡲࡩ࡯࡭࠷࠰࠺࠷࠱ࠪࠏࠍࠍࠨࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥ่้ࠬࠩะ๊๊็่ࠢืู้ไศฬࠣหั์ศ๋ࠩ࠯ࡰ࡮ࡴ࡫࠶࠮࠸࠵࠶࠯ࠍࠋࠋ࡯࡭ࡳࡱ࠱ࠡ࠿ࠣࡰ࡮ࡴ࡫࠱࠭ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠦࡧࡱࡵࡩ࡮࡭࡮࠾ࠨࡷࡥ࡬ࡃࠧࠎࠌࠌࡰ࡮ࡴ࡫࠳ࠢࡀࠤࡱ࡯࡮࡬࠲࠮ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧࠎࠌࠌࡰ࡮ࡴ࡫࠴ࠢࡀࠤࡱ࡯࡮࡬࠲࠮ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠴ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧࠎࠌࠌࡰ࡮ࡴ࡫࠵ࠢࡀࠤࡱ࡯࡮࡬࠲࠮ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡸࡷࡻࡥࠧࡶࡤ࡫ࡂ࠭ࠍࠋࠋ࡯࡭ࡳࡱ࠵ࠡ࠿ࠣࡰ࡮ࡴ࡫࠱࠭ࠪࠪࡹࡿࡰࡦ࠿࠴ࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃ࠳ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࡷࡶࡺ࡫ࠦࡵࡣࡪࡁࠬࠓࠊࠊࠤࠥࠦ┝")
	l1lll11l1ll_l1_ = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠬ┞")
	l1lll11ll1l_l1_ = l1lll11l1ll_l1_+l1l1ll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠶ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠲ࠨࡩࡳࡷ࡫ࡩࡨࡰࡀࡪࡦࡲࡳࡦࠨࡷࡥ࡬ࡃࠧ┟")
	l1lll1lllll_l1_ = l1lll11l1ll_l1_+l1l1ll_l1_ (u"ࠬࠬࡴࡺࡲࡨࡁ࠷ࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾࠵ࠩࡪࡴࡸࡥࡪࡩࡱࡁ࡫ࡧ࡬ࡴࡧࠩࡸࡦ࡭࠽ࠨ┠")
	l1lll11l11l_l1_ = l1lll11l1ll_l1_+l1l1ll_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࠸ࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿࠴ࠪ࡫ࡵࡲࡦ࡫ࡪࡲࡂࡺࡲࡶࡧࠩࡸࡦ࡭࠽ࠨ┡")
	l1lll11l1l1_l1_ = l1lll11l1ll_l1_+l1l1ll_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࠲ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠷ࠫ࡬࡯ࡳࡧ࡬࡫ࡳࡃࡴࡳࡷࡨࠪࡹࡧࡧ࠾ࠩ┢")
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┣"),menu_name+l1l1ll_l1_ (u"ู่๋ࠩ็วหࠢฦๅ้อๅࠡ฻ิฬ๏࠭┤"),l1lll11ll1l_l1_,511)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┥"),menu_name+l1l1ll_l1_ (u"๊ࠫ฻ๆโษอࠤู๊ไิๆสฮࠥ฿ัษ์ࠪ┦"),l1lll1lllll_l1_,511)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┧"),menu_name+l1l1ll_l1_ (u"࠭ๅึ่ไหฯࠦรโๆส้ࠥอฬ็สํࠫ┨"),l1lll11l11l_l1_,511)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┩"),menu_name+l1l1ll_l1_ (u"ࠨ็ุ๊ๆอสࠡ็ึุ่๊วหࠢสะ๋ฮ๊ࠨ┪"),l1lll11l1l1_l1_,511)
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ┫"),l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠴࡟࠴ࡉࡏࡍࡑࡕࡡࠬ┬"),l1l1ll_l1_ (u"ࠫࠬ┭"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ┮"),menu_name+l1l1ll_l1_ (u"࠭แ่ำึࠤศ฿ๅศๆࠣวอาฯ๋ࠩ┯"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡸࡱࡵ࡯࠴ࡧ࡬ࡱࡪࡤࡦࡪࡺࠧ┰"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ┱"),menu_name+l1l1ll_l1_ (u"ࠩไ๋ึูࠠࠡส็ำࠥอไฦ่อหั࠭┲"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠲ࡻࡴࡸ࡫࠰ࡥࡲࡹࡳࡺࡲࡺࠩ┳"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┴"),menu_name+l1l1ll_l1_ (u"ࠬ็็าีࠣหฺ้๊สࠩ┵"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠵ࡷࡰࡴ࡮࠳ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠭┶"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ┷"),menu_name+l1l1ll_l1_ (u"ࠨใ๊ีุࠦๅึ่ไหฯࠦวๅ฻่่ࠬ┸"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠱ࡺࡳࡷࡱ࠯ࡨࡧࡱࡶࡪ࠭┹"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┺"),menu_name+l1l1ll_l1_ (u"ࠫๆํัิࠢึ๊ฮࠦวๅวุำฬืࠧ┻"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡽ࡯ࡳ࡭࠲ࡶࡪࡲࡥࡢࡵࡨࡣࡾ࡫ࡡࡳࠩ┼"),517)
	addMenuItem(l1l1ll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ┽"),l1l1ll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠵ࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠲࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ┾"),l1l1ll_l1_ (u"ࠨࠩ┿"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╀"),menu_name+l1l1ll_l1_ (u"้ࠪํอำๆࠢ࠰ࠤๆ๊สา่ࠢัิีࠧ╁"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡦࡲࡳࠨ╂"),515)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ╃"),menu_name+l1l1ll_l1_ (u"࠭ๅ้ษึ้ࠥ࠳ࠠโๆอี้ࠥวๆๆࠪ╄"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡢ࡮ࡶࠫ╅"),514)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭╆"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠸ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠵࡞࠳ࡈࡕࡌࡐࡔࡠࠫ╇"),l1l1ll_l1_ (u"ࠪࠫ╈"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╉"),menu_name+l1l1ll_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี๋ࠥอะัࠪ╊"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ╋"),515)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╌"),menu_name+l1l1ll_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡๅส้้࠭╍"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ╎"),514)
	return
def l1lll11l111_l1_():
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧ╏"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ═"),l1l1ll_l1_ (u"ࠬ࠭║"),l1l1ll_l1_ (u"࠭ࠧ╒"),l1l1ll_l1_ (u"ࠧࠨ╓"),l1l1ll_l1_ (u"ࠨࠩ╔"),l1l1ll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭╕"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ╖"),multi_valued_attributes=None)
	block = l1lll111111_l1_.find(l1l1ll_l1_ (u"ࠫࡸ࡫࡬ࡦࡥࡷࠫ╗"),attrs={l1l1ll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ╘"):l1l1ll_l1_ (u"࠭ࡴࡢࡩࠪ╙")})	# <select name=l1l1ll_l1_ (u"ࠧࡵࡣࡪࠫ╚")>
	options = block.find_all(l1l1ll_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠨ╛"))
	for option in options:
		value = option.get(l1l1ll_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ╜"))		# or option[l1l1ll_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ╝")] l1l1llllll_l1_ it will fail if not l1l1lllll_l1_
		if not value: continue
		title = option.text
		if kodi_version<19:
			title = title.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ╞"))
			value = value.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ╟"))
		link = l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶ࠿ࡶࡶࡩ࠼ࡂࠫࡅ࠳ࠧ࠼ࡇࠪ࠿࠳ࠧࡶࡼࡴࡪࡃࠦࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠩࡪࡴࡸࡥࡪࡩࡱࡁࠫࡺࡡࡨ࠿ࠪ╠")+value
		title = title.replace(l1l1ll_l1_ (u"ࠧใษษ้ฮࠦࠧ╡"),l1l1ll_l1_ (u"ࠨࠩ╢"))
		addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╣"),menu_name+title,link,511)
	return
def l1lll1l11ll_l1_():
	l1lll11l1ll_l1_ = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡱ࡯࡮ࡦࡷࡳࡃࡺࡺࡦ࠹࠿ࠨࡉ࠷ࠫ࠹ࡄࠧ࠼࠷ࠬ╤")
	l1lll11ll11_l1_ = l1lll11l1ll_l1_+l1l1ll_l1_ (u"ࠫࠫࡺࡹࡱࡧࡀ࠵ࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠧࡨࡲࡶࡪ࡯ࡧ࡯࠿ࠩࡸࡦ࡭࠽ࠨ╥")
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ╦"),menu_name+l1l1ll_l1_ (u"࠭ๅึ่ไหฯࠦรีะสูࠬ╧"),l1lll11ll11_l1_,511)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ╨"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠲࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ╩"),l1l1ll_l1_ (u"ࠩࠪ╪"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ╫"),menu_name+l1l1ll_l1_ (u"ࠫๆํัิࠢฦุำอีࠡลหะิ๐ࠧ╬"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠬ࠵ࡩ࡯ࡦࡨࡼ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡧ࡬ࡱࡪࡤࡦࡪࡺࠧ╭"),517)
	addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭╮"),menu_name+l1l1ll_l1_ (u"ࠧโ้ิืุ๋่่ࠥࠪ╯"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠨ࠱࡬ࡲࡩ࡫ࡸ࠰ࡲࡨࡶࡸࡵ࡮࠰ࡰࡤࡸ࡮ࡵ࡮ࡢ࡮࡬ࡸࡾ࠭╰"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ╱"),menu_name+l1l1ll_l1_ (u"ࠪๅ์ืำࠡࠢอหึ๐ฮࠡษ็้๏๊วะࠩ╲"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴࡯࡮ࡥࡧࡻ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࡧ࡯ࡲࡵࡪࡢࡽࡪࡧࡲࠨ╳"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ╴"),menu_name+l1l1ll_l1_ (u"࠭แ่ำึࠤࠥะวา์ัࠤฬ๊่โษฬࠫ╵"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰࡫ࡱࡨࡪࡾ࠯ࡱࡧࡵࡷࡴࡴ࠯ࡥࡧࡤࡸ࡭ࡥࡹࡦࡣࡵࠫ╶"),517)
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭╷"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࠷ࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠴࡞࠳ࡈࡕࡌࡐࡔࡠࠫ╸"),l1l1ll_l1_ (u"ࠪࠫ╹"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ╺"),menu_name+l1l1ll_l1_ (u"๋ࠬี็ใสฮࠥ࠳ࠠโๆอี๋ࠥอะัࠪ╻"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ╼"),515)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ╽"),menu_name+l1l1ll_l1_ (u"ࠨ็ุ๊ๆอสࠡ࠯ࠣๅ้ะัࠡๅส้้࠭╾"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠩ࠲ࡰ࡮ࡴࡥࡶࡲࠪ╿"),514)
	return
def l1lll1111l1_l1_(url):
	if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡥࡱࡹࠧ▀") in url: index = 0
	elif l1l1ll_l1_ (u"ࠫ࠴ࡲࡩ࡯ࡧࡸࡴࠬ▁") in url: index = 1
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩ▂"),url,l1l1ll_l1_ (u"࠭ࠧ▃"),l1l1ll_l1_ (u"ࠧࠨ▄"),l1l1ll_l1_ (u"ࠨࠩ▅"),l1l1ll_l1_ (u"ࠩࠪ▆"),l1l1ll_l1_ (u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲ࡒࡉࡔࡖࡖ࠱࠶ࡹࡴࠨ▇"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠫ࡭ࡺ࡭࡭࠰ࡳࡥࡷࡹࡥࡳࠩ█"),multi_valued_attributes=None)
	l1l1l11_l1_ = l1lll111111_l1_.find_all(class_=l1l1ll_l1_ (u"ࠬࡰࡵ࡮ࡤࡲ࠱ࡹ࡮ࡥࡢࡶࡨࡶࠥࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠧ▉"))
	for block in l1l1l11_l1_:
		title = block.find_all(l1l1ll_l1_ (u"࠭ࡡࠨ▊"))[index].text
		link = l1l1l1_l1_+block.find_all(l1l1ll_l1_ (u"ࠧࡢࠩ▋"))[index].get(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫࠭▌"))
		if kodi_version<19:
			title = title.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▍"))
			link = link.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▎"))
		if not l1l1l11_l1_:
			l1llll111l1_l1_(link)
			return
		else:
			title = title.replace(l1l1ll_l1_ (u"ࠫ็อฦๆหࠣࠫ▏"),l1l1ll_l1_ (u"ࠬ࠭▐"))
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭░"),menu_name+title,link,512)
	PAGINATION(l1lll111111_l1_,511)
	return
def PAGINATION(l1lll111111_l1_,mode):
	block = l1lll111111_l1_.find(class_=l1l1ll_l1_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ▒"))
	if block:
		pages = block.find_all(l1l1ll_l1_ (u"ࠨࡣࠪ▓"))
		l1ll1llllll_l1_ = block.find_all(l1l1ll_l1_ (u"ࠩ࡯࡭ࠬ▔"))
		l1lll1l11l1_l1_ = list(zip(pages,l1ll1llllll_l1_))
		ii = -1
		length = len(l1lll1l11l1_l1_)
		for l1ll1lll1_l1_,l1lll111l11_l1_ in l1lll1l11l1_l1_:
			ii += 1
			l1lll111l11_l1_ = l1lll111l11_l1_[l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ▕")]
			if l1l1ll_l1_ (u"ࠫࡺࡴࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠩ▖") in l1lll111l11_l1_ or l1l1ll_l1_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹ࠭▗") in l1lll111l11_l1_: continue
			name2 = l1ll1lll1_l1_.text
			l111111l1_l1_ = l1l1l1_l1_+l1ll1lll1_l1_.get(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࠫ▘"))
			if kodi_version<19:
				name2 = name2.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ▙"))
				l111111l1_l1_ = l111111l1_l1_.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭▚"))
			if   ii==0: name2 = l1l1ll_l1_ (u"ࠩฦ์้๏ࠧ▛")
			elif ii==1: name2 = l1l1ll_l1_ (u"ࠪืฬฮโสࠩ▜")
			elif ii==length-2: name2 = l1l1ll_l1_ (u"้ࠫออใหࠪ▝")
			elif ii==length-1: name2 = l1l1ll_l1_ (u"ࠬษฮ๋ำฬࠫ▞")
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭▟"),menu_name+l1l1ll_l1_ (u"ࠧึใะอࠥ࠭■")+name2,l111111l1_l1_,mode)
	return
def l1llll111l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ□"),url,l1l1ll_l1_ (u"ࠩࠪ▢"),l1l1ll_l1_ (u"ࠪࠫ▣"),l1l1ll_l1_ (u"ࠫࠬ▤"),l1l1ll_l1_ (u"ࠬ࠭▥"),l1l1ll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠲࠯࠴ࡷࡹ࠭▦"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ▧"),multi_valued_attributes=None)
	l1l1l11_l1_ = l1lll111111_l1_.find_all(class_=l1l1ll_l1_ (u"ࠨࡴࡲࡻࠬ▨"))
	items,first = [],True
	for block in l1l1l11_l1_:
		if not block.find(class_=l1l1ll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠲ࡽࡲࡢࡲࡳࡩࡷ࠭▩")): continue
		if first: first = False ; continue
		l1lll1ll11l_l1_ = []
		l1ll1lllll1_l1_ = block.find_all(class_=[l1l1ll_l1_ (u"ࠪࡧࡪࡴࡳࡰࡴࡶ࡬࡮ࡶࠠࡳࡧࡧࠫ▪"),l1l1ll_l1_ (u"ࠫࡨ࡫࡮ࡴࡱࡵࡷ࡭࡯ࡰࠡࡲࡸࡶࡵࡲࡥࠨ▫")])
		for l1lll111ll1_l1_ in l1ll1lllll1_l1_:
			l1lll11ll1_l1_ = l1lll111ll1_l1_.find_all(l1l1ll_l1_ (u"ࠬࡲࡩࠨ▬"))[1].text
			if kodi_version<19:
				l1lll11ll1_l1_ = l1lll11ll1_l1_.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ▭"))
			l1lll1ll11l_l1_.append(l1lll11ll1_l1_)
		if not l1l1111_l1_(script_name,l1l1ll_l1_ (u"ࠧࠨ▮"),l1lll1ll11l_l1_,False):
			image = block.find(l1l1ll_l1_ (u"ࠨ࡫ࡰ࡫ࠬ▯")).get(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࠫ▰"))
			title = block.find(l1l1ll_l1_ (u"ࠪ࡬࠸࠭▱"))
			name = title.find(l1l1ll_l1_ (u"ࠫࡦ࠭▲")).text
			link = l1l1l1_l1_+title.find(l1l1ll_l1_ (u"ࠬࡧࠧ△")).get(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࠫ▴"))
			plot = block.find(class_=l1l1ll_l1_ (u"ࠧ࡯ࡱ࠰ࡱࡦࡸࡧࡪࡰࠪ▵"))
			stars = block.find(class_=l1l1ll_l1_ (u"ࠨ࡮ࡨ࡫ࡪࡴࡤࠨ▶"))
			if plot: plot = plot.text
			if stars: stars = stars.text
			if kodi_version<19:
				image = image.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ▷"))
				name = name.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ▸"))
				link = link.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ▹"))
				if plot: plot = plot.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ►"))
			infodict = {}
			if stars: infodict[l1l1ll_l1_ (u"࠭ࡳࡵࡣࡵࡷࠬ▻")] = stars
			if plot:
				plot = plot.replace(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪ▼"),l1l1ll_l1_ (u"ࠨࠢ࠱࠲ࠥ࠭▽"))
				infodict[l1l1ll_l1_ (u"ࠩࡳࡰࡴࡺࠧ▾")] = plot.replace(l1l1ll_l1_ (u"ࠪ࠲࠳࠴วใำฦࠤฬ๊ๅำ์าࠫ▿"),l1l1ll_l1_ (u"ࠫࠬ◀"))
			if l1l1ll_l1_ (u"ࠬ࠵ࡷࡰࡴ࡮࠳ࠬ◁") in link:
				#name = l1l1ll_l1_ (u"࠭ศฮอࠣ฽๋ࠦࠧ◂")+name
				addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ◃"),menu_name+name,link,516,image,l1l1ll_l1_ (u"ࠨࠩ◄"),name,l1l1ll_l1_ (u"ࠩࠪ◅"),infodict)
			elif l1l1ll_l1_ (u"ࠪ࠳ࡵ࡫ࡲࡴࡱࡱ࠳ࠬ◆") in link: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ◇"),menu_name+name,link,513,image,l1l1ll_l1_ (u"ࠬ࠭◈"),name,l1l1ll_l1_ (u"࠭ࠧ◉"),infodict)
	PAGINATION(l1lll111111_l1_,512)
	return
def l1llll1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ◊"),url,l1l1ll_l1_ (u"ࠨࠩ○"),l1l1ll_l1_ (u"ࠩࠪ◌"),l1l1ll_l1_ (u"ࠪࠫ◍"),l1l1ll_l1_ (u"ࠫࠬ◎"),l1l1ll_l1_ (u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠲࠮࠳ࡶࡸࠬ●"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"࠭ࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠫ◐"),multi_valued_attributes=None)
	l1l1l11_l1_ = l1lll111111_l1_.find_all(l1l1ll_l1_ (u"ࠧ࡭࡫ࠪ◑"))
	names,items = [],[]
	for block in l1l1l11_l1_:
		if not block.find(class_=l1l1ll_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠱ࡼࡸࡡࡱࡲࡨࡶࠬ◒")): continue
		if not block.find(class_=[l1l1ll_l1_ (u"ࠩࡸࡲࡸࡺࡹ࡭ࡧࡧࠫ◓"),l1l1ll_l1_ (u"ࠪࡹࡳࡹࡴࡺ࡮ࡨࡨࠥࡺࡥࡹࡶ࠰ࡧࡪࡴࡴࡦࡴࠪ◔")]): continue
		if block.find(class_=l1l1ll_l1_ (u"ࠫ࡭࡯ࡤࡦࠩ◕")): continue
		title = block.find(class_=[l1l1ll_l1_ (u"ࠬࡻ࡮ࡴࡶࡼࡰࡪࡪࠧ◖"),l1l1ll_l1_ (u"࠭ࡵ࡯ࡵࡷࡽࡱ࡫ࡤࠡࡶࡨࡼࡹ࠳ࡣࡦࡰࡷࡩࡷ࠭◗")])
		name = title.find(l1l1ll_l1_ (u"ࠧࡢࠩ◘")).text
		if name in names: continue
		names.append(name)
		link = l1l1l1_l1_+title.find(l1l1ll_l1_ (u"ࠨࡣࠪ◙")).get(l1l1ll_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠧ◚"))
		if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡼࡵࡲ࡬࠱ࠪ◛") in url: image = block.find(l1l1ll_l1_ (u"ࠫ࡮ࡳࡧࠨ◜")).get(l1l1ll_l1_ (u"ࠬࡹࡲࡤࠩ◝"))
		elif l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ◞") in url: image = block.find(l1l1ll_l1_ (u"ࠧࡪ࡯ࡪࠫ◟")).get(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪ◠"))
		elif l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪ◡") in url: image = block.find(l1l1ll_l1_ (u"ࠪ࡭ࡲ࡭ࠧ◢")).get(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡶࡨ࠭◣"))
		else: image = block.find(l1l1ll_l1_ (u"ࠬ࡯࡭ࡨࠩ◤")).get(l1l1ll_l1_ (u"࠭ࡳࡳࡥࠪ◥"))
		if kodi_version<19:
			name = name.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ◦"))
			link = link.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭◧"))
			image = image.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ◨"))
		name = name.strip(l1l1ll_l1_ (u"ࠪࠤࠬ◩"))
		items.append((name,link,image))
	if l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡶࡥࡳࡵࡲࡲ࠴࠭◪") in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,link,image in items:
		if l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡶࡪࡦࡨࡳ࠴࠭◫") in url: addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ◬"),menu_name+name,link,522,image)
		elif l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩ◭") in url: addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ◮"),menu_name+name,link,513,image,l1l1ll_l1_ (u"ࠩࠪ◯"),name)
		else: addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ◰"),menu_name+name,link,516,image,l1l1ll_l1_ (u"ࠫࠬ◱"),name)
	return
def l1lll1l111l_l1_(text):
	text = text.replace(l1l1ll_l1_ (u"ࠬอไฦ฻็ห๋࠭◲"),l1l1ll_l1_ (u"࠭ࠧ◳")).replace(l1l1ll_l1_ (u"ࠧๅใํ่๊࠭◴"),l1l1ll_l1_ (u"ࠨࠩ◵")).replace(l1l1ll_l1_ (u"ࠩส่ึูๅ๋ࠩ◶"),l1l1ll_l1_ (u"ࠪࠫ◷"))
	text = text.replace(l1l1ll_l1_ (u"ࠫส฿ไศ่ࠪ◸"),l1l1ll_l1_ (u"ࠬ࠭◹")).replace(l1l1ll_l1_ (u"࠭แ๋ๆ่ࠫ◺"),l1l1ll_l1_ (u"ࠧࠨ◻")).replace(l1l1ll_l1_ (u"ࠨษ็ฬึ๎ๅ้ࠩ◼"),l1l1ll_l1_ (u"ࠩࠪ◽"))
	text = text.replace(l1l1ll_l1_ (u"ࠪห้ะิ้์ๅ๎ࠬ◾"),l1l1ll_l1_ (u"ࠫࠬ◿")).replace(l1l1ll_l1_ (u"๊ࠬๅิๆึ่ࠬ☀"),l1l1ll_l1_ (u"࠭ࠧ☁")).replace(l1l1ll_l1_ (u"ࠧๆี็ื้࠭☂"),l1l1ll_l1_ (u"ࠨࠩ☃"))
	text = text.replace(l1l1ll_l1_ (u"ࠩ࠽ࠫ☄"),l1l1ll_l1_ (u"ࠪࠫ★")).replace(l1l1ll_l1_ (u"ࠫ࠮࠭☆"),l1l1ll_l1_ (u"ࠬ࠭☇")).replace(l1l1ll_l1_ (u"࠭ࠨࠨ☈"),l1l1ll_l1_ (u"ࠧࠨ☉")).replace(l1l1ll_l1_ (u"ࠨ࠮ࠪ☊"),l1l1ll_l1_ (u"ࠩࠪ☋"))
	text = text.replace(l1l1ll_l1_ (u"ࠪࡣࠬ☌"),l1l1ll_l1_ (u"ࠫࠬ☍")).replace(l1l1ll_l1_ (u"ࠬࡁࠧ☎"),l1l1ll_l1_ (u"࠭ࠧ☏")).replace(l1l1ll_l1_ (u"ࠧ࠮ࠩ☐"),l1l1ll_l1_ (u"ࠨࠩ☑")).replace(l1l1ll_l1_ (u"ࠩ࠱ࠫ☒"),l1l1ll_l1_ (u"ࠪࠫ☓"))
	text = text.replace(l1l1ll_l1_ (u"ࠫࡡ࠭ࠧ☔"),l1l1ll_l1_ (u"ࠬ࠭☕")).replace(l1l1ll_l1_ (u"࠭࡜ࠣࠩ☖"),l1l1ll_l1_ (u"ࠧࠨ☗"))
	text = text.replace(l1l1ll_l1_ (u"ࠨࠢࠣࠤࠥ࠭☘"),l1l1ll_l1_ (u"ࠩࠣࠫ☙")).replace(l1l1ll_l1_ (u"ࠪࠤࠥࠦࠧ☚"),l1l1ll_l1_ (u"ࠫࠥ࠭☛")).replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ☜"),l1l1ll_l1_ (u"࠭ࠠࠨ☝"))
	text = text.strip(l1l1ll_l1_ (u"ࠧࠡࠩ☞"))
	l1lll1lll11_l1_ = text.count(l1l1ll_l1_ (u"ࠨࠢࠪ☟"))+1
	if l1lll1lll11_l1_==1:
		l1lll111l1l_l1_(text)
		return
	addMenuItem(l1l1ll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ☠"),menu_name+l1l1ll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࠣ็้๋วหࠢ็่อำหࠡ࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ☡"),l1l1ll_l1_ (u"ࠫࠬ☢"),9999)
	l1lll11llll_l1_ = text.split(l1l1ll_l1_ (u"ࠬࠦࠧ☣"))
	l1lll1llll1_l1_ = pow(2,l1lll1lll11_l1_)
	l1lll1l1ll1_l1_ = []
	def l1lll11lll1_l1_(a,b):
		if a==l1l1ll_l1_ (u"࠭࠱ࠨ☤"): return b
		return l1l1ll_l1_ (u"ࠧࠨ☥")
	for ii in range(l1lll1llll1_l1_,0,-1):
		l1lll1l1l1l_l1_ = list(l1lll1lll11_l1_*l1l1ll_l1_ (u"ࠨ࠲ࠪ☦")+bin(ii)[2:])[-l1lll1lll11_l1_:]
		l1lll1l1l1l_l1_ = reversed(l1lll1l1l1l_l1_)
		result = map(l1lll11lll1_l1_,l1lll1l1l1l_l1_,l1lll11llll_l1_)
		title = l1l1ll_l1_ (u"ࠩࠣࠫ☧").join(filter(None,result))
		if kodi_version<19: title2 = title.decode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ☨"))
		else: title2 = title
		if len(title2)>2 and title not in l1lll1l1ll1_l1_:
			l1lll1l1ll1_l1_.append(title)
			addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☩"),menu_name+title,l1l1ll_l1_ (u"ࠬ࠭☪"),523,l1l1ll_l1_ (u"࠭ࠧ☫"),l1l1ll_l1_ (u"ࠧࠨ☬"),title)
	return
def l1lll111l1l_l1_(l1lll1lll1l_l1_):
	if kodi_version<19:
		l1lll1lll1l_l1_ = l1lll1lll1l_l1_.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭☭"))
		import arabic_reshaper
		l1lll1lll1l_l1_ = arabic_reshaper.ArabicReshaper().reshape(l1lll1lll1l_l1_)
		l1lll1lll1l_l1_ = bidi.algorithm.get_display(l1lll1lll1l_l1_)
	import l1lll1ll111_l1_
	l1lll1lll1l_l1_ = OPEN_KEYBOARD(default=l1lll1lll1l_l1_)
	l1lll1ll111_l1_.SEARCH(l1lll1lll1l_l1_)
	return
def l1lll1ll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭☮"),url,l1l1ll_l1_ (u"ࠪࠫ☯"),l1l1ll_l1_ (u"ࠫࠬ☰"),l1l1ll_l1_ (u"ࠬ࠭☱"),l1l1ll_l1_ (u"࠭ࠧ☲"),l1l1ll_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡌࡒࡉࡋࡘࡆࡕࡢࡐࡎ࡙ࡔࡔ࠯࠴ࡷࡹ࠭☳"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭☴"),multi_valued_attributes=None)
	block = l1lll111111_l1_.find(class_=l1l1ll_l1_ (u"ࠩ࡯࡭ࡸࡺ࠭ࡴࡧࡳࡥࡷࡧࡴࡰࡴࠣࡰ࡮ࡹࡴ࠮ࡶ࡬ࡸࡱ࡫ࠧ☵"))
	titles = block.find_all(l1l1ll_l1_ (u"ࠪࡥࠬ☶"))
	items = []
	for title in titles:
		name = title.text
		link = l1l1l1_l1_+title.get(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧࠩ☷"))
		if kodi_version<19:
			name = name.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ☸"))
			link = link.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ☹"))
		if l1l1ll_l1_ (u"ࠧࠤࠩ☺") not in link: items.append((name,link))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for item in items:
		name,link = item
		addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ☻"),menu_name+name,link,518)
	return
def l1lll1ll1ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭☼"),url,l1l1ll_l1_ (u"ࠪࠫ☽"),l1l1ll_l1_ (u"ࠫࠬ☾"),l1l1ll_l1_ (u"ࠬ࠭☿"),l1l1ll_l1_ (u"࠭ࠧ♀"),l1l1ll_l1_ (u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡌࡒࡉࡋࡘࡆࡕࡢࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ♁"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠨࡪࡷࡱࡱ࠴ࡰࡢࡴࡶࡩࡷ࠭♂"),multi_valued_attributes=None)
	l1l1l11_l1_ = l1lll111111_l1_.find(class_=l1l1ll_l1_ (u"ࠩࡨࡼࡵࡧ࡮ࡥࠩ♃")).find_all(l1l1ll_l1_ (u"ࠪࡸࡷ࠭♄"))
	for block in l1l1l11_l1_:
		l1lll1l1111_l1_ = block.find_all(l1l1ll_l1_ (u"ࠫࡦ࠭♅"))
		if not l1lll1l1111_l1_: continue
		image = block.find(l1l1ll_l1_ (u"ࠬ࡯࡭ࡨࠩ♆")).get(l1l1ll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣࠨ♇"))
		name = l1lll1l1111_l1_[1].text
		link = l1l1l1_l1_+l1lll1l1111_l1_[1].get(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࠬ♈"))
		stars = block.find(class_=l1l1ll_l1_ (u"ࠨ࡮ࡨ࡫ࡪࡴࡤࠨ♉"))
		if stars: stars = stars.text
		if kodi_version<19:
			name = name.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♊"))
			link = link.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♋"))
			image = image.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♌"))
		infodict = {}
		if stars: infodict[l1l1ll_l1_ (u"ࠬࡹࡴࡢࡴࡶࠫ♍")] = stars
		if l1l1ll_l1_ (u"࠭࠯ࡸࡱࡵ࡯࠴࠭♎") in link:
			#name = l1l1ll_l1_ (u"ࠧษฯฮࠤ฾์ࠠࠨ♏")+name
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ♐"),menu_name+name,link,516,image,l1l1ll_l1_ (u"ࠩࠪ♑"),name,l1l1ll_l1_ (u"ࠪࠫ♒"),infodict)
		elif l1l1ll_l1_ (u"ࠫ࠴ࡶࡥࡳࡵࡲࡲ࠴࠭♓") in link: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♔"),menu_name+name,link,513,image,l1l1ll_l1_ (u"࠭ࠧ♕"),name,l1l1ll_l1_ (u"ࠧࠨ♖"),infodict)
	PAGINATION(l1lll111111_l1_,518)
	return
def l1lll1l1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ♗"),url,l1l1ll_l1_ (u"ࠩࠪ♘"),l1l1ll_l1_ (u"ࠪࠫ♙"),l1l1ll_l1_ (u"ࠫࠬ♚"),l1l1ll_l1_ (u"ࠬ࠭♛"),l1l1ll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡘࡌࡈࡊࡕࡓࡠࡎࡌࡗ࡙࡙࠭࠲ࡵࡷࠫ♜"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ♝"),multi_valued_attributes=None)
	titles = l1lll111111_l1_.find_all(class_=l1l1ll_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯࠯ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࡰ࡮ࡴࡥࠨ♞"))
	l1ll_l1_ = l1lll111111_l1_.find_all(class_=l1l1ll_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯ࠢࡪࡶࡪ࡫࡮ࠡࡵࡰࡥࡱࡲࠠࡳ࡫ࡪ࡬ࡹ࠭♟"))
	items = zip(titles,l1ll_l1_)
	for title,link in items:
		title = title.text
		link = l1l1l1_l1_+link.get(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ♠"))
		if kodi_version<19:
			title = title.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ♡"))
			link = link.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ♢"))
		title = title.replace(l1l1ll_l1_ (u"࠭ࠠࠡࠢࠣࠫ♣"),l1l1ll_l1_ (u"ࠧࠡࠩ♤")).replace(l1l1ll_l1_ (u"ࠨࠢࠣࠤࠬ♥"),l1l1ll_l1_ (u"ࠩࠣࠫ♦")).replace(l1l1ll_l1_ (u"ࠪࠤࠥ࠭♧"),l1l1ll_l1_ (u"ࠫࠥ࠭♨"))
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♩"),menu_name+title,link,521)
	return
def l1lll11111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪ♪"),url,l1l1ll_l1_ (u"ࠧࠨ♫"),l1l1ll_l1_ (u"ࠨࠩ♬"),l1l1ll_l1_ (u"ࠩࠪ♭"),l1l1ll_l1_ (u"ࠪࠫ♮"),l1l1ll_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡖࡊࡆࡈࡓࡘࡥࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ♯"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠬ࡮ࡴ࡮࡮࠱ࡴࡦࡸࡳࡦࡴࠪ♰"),multi_valued_attributes=None)
	l1llll111ll_l1_ = l1lll111111_l1_.find(class_=l1l1ll_l1_ (u"࠭࡬ࡢࡴࡪࡩ࠲ࡨ࡬ࡰࡥ࡮࠱࡬ࡸࡩࡥ࠯࠷ࠤࡲ࡫ࡤࡪࡷࡰ࠱ࡧࡲ࡯ࡤ࡭࠰࡫ࡷ࡯ࡤ࠮࠶ࠣࡷࡲࡧ࡬࡭࠯ࡥࡰࡴࡩ࡫࠮ࡩࡵ࡭ࡩ࠳࠲ࠨ♱"))
	l1l1l11_l1_ = l1llll111ll_l1_.find_all(l1l1ll_l1_ (u"ࠧ࡭࡫ࠪ♲"))
	for block in l1l1l11_l1_:
		title = block.find(class_=l1l1ll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ♳")).text
		link = l1l1l1_l1_+block.find(l1l1ll_l1_ (u"ࠩࡤࠫ♴")).get(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠨ♵"))
		image = block.find(l1l1ll_l1_ (u"ࠫ࡮ࡳࡧࠨ♶")).get(l1l1ll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡷࡩࠧ♷"))
		duration = block.find(class_=l1l1ll_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ♸")).text
		if kodi_version<19:
			title = title.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ♹"))
			link = link.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭♺"))
			image = image.encode(l1l1ll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ♻"))
			duration = duration.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ♼"))
		duration = duration.replace(l1l1ll_l1_ (u"ࠫࡡࡴࠧ♽"),l1l1ll_l1_ (u"ࠬ࠭♾")).strip(l1l1ll_l1_ (u"࠭ࠠࠨ♿"))
		addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⚀"),menu_name+title,link,522,image,duration)
	PAGINATION(l1lll111111_l1_,521)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⚁"),url,l1l1ll_l1_ (u"ࠩࠪ⚂"),l1l1ll_l1_ (u"ࠪࠫ⚃"),l1l1ll_l1_ (u"ࠫࠬ⚄"),l1l1ll_l1_ (u"ࠬ࠭⚅"),l1l1ll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⚆"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠧࡩࡶࡰࡰ࠳ࡶࡡࡳࡵࡨࡶࠬ⚇"),multi_valued_attributes=None)
	link = l1lll111111_l1_.find(class_=l1l1ll_l1_ (u"ࠨࡨ࡯ࡩࡽ࠳ࡶࡪࡦࡨࡳࠬ⚈")).find(l1l1ll_l1_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩ⚉")).get(l1l1ll_l1_ (u"ࠪࡷࡷࡩࠧ⚊"))
	if kodi_version<19: link = link.encode(l1l1ll_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⚋"))
	PLAY_VIDEO(link,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⚌"))
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧ⚍"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨ⚎"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪ⚏"),l1l1ll_l1_ (u"ࠩࠨ࠶࠵࠭⚐"))
	url = l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡄࡷ࠽ࠨ⚑")+search
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨ⚒"),url,l1l1ll_l1_ (u"ࠬ࠭⚓"),l1l1ll_l1_ (u"࠭ࠧ⚔"),l1l1ll_l1_ (u"ࠧࠨ⚕"),l1l1ll_l1_ (u"ࠨࠩ⚖"),l1l1ll_l1_ (u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ⚗"))
	html = response.content
	l1lll111111_l1_ = bs4.BeautifulSoup(html,l1l1ll_l1_ (u"ࠪ࡬ࡹࡳ࡬࠯ࡲࡤࡶࡸ࡫ࡲࠨ⚘"),multi_valued_attributes=None)
	l1l1l11_l1_ = l1lll111111_l1_.find_all(class_=l1l1ll_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲ࠲ࡺࡩࡵ࡮ࡨࠤࡱ࡫ࡦࡵࠩ⚙"))
	for block in l1l1l11_l1_:
		title = block.text
		if kodi_version<19:
			title = title.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ⚚"))
		title = title.split(l1l1ll_l1_ (u"࠭ࠨࠨ⚛"),1)[0].strip(l1l1ll_l1_ (u"ࠧࠡࠩ⚜"))
		if   l1l1ll_l1_ (u"ࠨล฼้ฬ๊ࠧ⚝") in title: link = url.replace(l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ⚞"),l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡼࡵࡲ࡬࠱ࠪ⚟"))
		elif l1l1ll_l1_ (u"ࠫศฺฮศืࠪ⚠") in title: link = url.replace(l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࠧ⚡"),l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ⚢"))
		#elif l1l1ll_l1_ (u"ࠧฤฯาหะ࠭⚣") in title: link = url.replace(l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⚤"),l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࡩࡻ࡫࡮ࡵ࠱ࠪ⚥"))
		#elif l1l1ll_l1_ (u"้ࠪ์ืฬศ่สฮࠬ⚦") in title: link = url.replace(l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴࠭⚧"),l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡦࡦࡵࡷ࡭ࡻࡧ࡬࠰ࠩ⚨"))
		elif l1l1ll_l1_ (u"࠭แ๋ัํ์์อสࠨ⚩") in title: link = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ⚪"),l1l1ll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ⚫"))
		#elif l1l1ll_l1_ (u"ࠩฦาออัࠨ⚬") in title: link = url.replace(l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ⚭"),l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠴ࡺ࡯ࡱ࡫ࡦ࠳ࠬ⚮"))
		else: continue
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚯"),menu_name+title,link,513)
	return
# ===========================================
#     l1111l1ll_l1_ l1lllllll1_l1_ l1lllll1ll_l1_
# ===========================================
def l1lll1111ll_l1_(url,text):
	global l1ll1111_l1_,l1llll1l_l1_
	if l1l1ll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡡ࡭ࡵࠪ⚰") in url:
		l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࡡ࡭ࠩ⚱"),l1l1ll_l1_ (u"ࠨࡻࡨࡥࡷ࠭⚲"),l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ⚳")]
		l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ⚴"),l1l1ll_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ⚵"),l1l1ll_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⚶")]
	elif l1l1ll_l1_ (u"࠭࠯࡭࡫ࡱࡩࡺࡶࠧ⚷") in url:
		l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⚸"),l1l1ll_l1_ (u"ࠨࡨࡲࡶࡪ࡯ࡧ࡯ࠩ⚹"),l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ⚺")]
		l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ⚻"),l1l1ll_l1_ (u"ࠫ࡫ࡵࡲࡦ࡫ࡪࡲࠬ⚼"),l1l1ll_l1_ (u"ࠬࡺࡹࡱࡧࠪ⚽")]
	l111l11_l1_(url,text)
	return
def l1111l1l1_l1_(url):
	url = url.split(l1l1ll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⚾"))[0]
	#l11ll1_l1_ = SERVER(url,l1l1ll_l1_ (u"ࠧࡶࡴ࡯ࠫ⚿"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠨࡉࡈࡘࠬ⛀"),url,l1l1ll_l1_ (u"ࠩࠪ⛁"),l1l1ll_l1_ (u"ࠪࠫ⛂"),l1l1ll_l1_ (u"ࠫࠬ⛃"),l1l1ll_l1_ (u"ࠬ࠭⛄"),l1l1ll_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ⛅"))
	html = response.content
	# all l1l1l11_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡧࡱࡵࡱࠥࡧࡣࡵ࡫ࡲࡲࡂࠨ࠯ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭⛆"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	# name + category + options block
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠢࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭⛇"),block,re.DOTALL)
	return l1111ll_l1_
def l1llllllll_l1_(block):
	# value + name
	items = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⛈"),block,re.DOTALL)
	return items
def l11111lll_l1_(url):
	#url = url.replace(l1l1ll_l1_ (u"ࠪࡧࡦࡺ࠽ࠨ⛉"),l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧ⛊"))
	l1111111l_l1_ = url.split(l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⛋"))[0]
	l11111111_l1_ = SERVER(url,l1l1ll_l1_ (u"࠭ࡵࡳ࡮ࠪ⛌"))
	#url = url.replace(l1111111l_l1_,l11111111_l1_)
	url = url.replace(l1l1ll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⛍"),l1l1ll_l1_ (u"ࠨ࠱ࡂࡹࡹ࡬࠸࠾ࠧࡈ࠶ࠪ࠿ࡃࠦ࠻࠶ࠪࠬ⛎"))
	return url
def l111l11111_l1_(l1lll111_l1_,url):
	l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⛏")) # l11111l111_l1_ be l11111ll1l_l1_
	url3 = url+l1l1ll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⛐")+l1l1l1l1_l1_
	url3 = l11111lll_l1_(url3)
	return url3
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭⛑"),l1l1ll_l1_ (u"ࠬ࠭⛒"))
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧ⛓"),l1l1ll_l1_ (u"ࠧࠨ⛔"),filter,url)
	if l1l1ll_l1_ (u"ࠨࡁࠪ⛕") in url: url = url.split(l1l1ll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⛖"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ⛗"),1)
	if filter==l1l1ll_l1_ (u"ࠫࠬ⛘"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭⛙"),l1l1ll_l1_ (u"࠭ࠧ⛚")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫ⛛"))
	if type==l1l1ll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⛜"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠩࡀࠫ⛝") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠪࡁࠬ⛞") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭⛟")+category+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨ⛠")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ⛡")+category+l1l1ll_l1_ (u"ࠧ࠾࠲ࠪ⛢")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠨࠨࠪ⛣"))+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭⛤")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠪࠪࠬ⛥"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⛦")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		url2 = url+l1l1ll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⛧")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⛨"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⛩")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠨࠩ⛪"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ⛫")) # l111111l11_l1_ l111l11ll1_l1_ not l11ll1l111_l1_
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠪࠫ⛬"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⛭")+l1l1ll1l_l1_
		url2 = l11111lll_l1_(url2)
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛮"),menu_name+l1l1ll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ⛯"),url2,511)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⛰"),menu_name+l1l1ll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ⛱")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ⛲"),url2,511)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⛳"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⛴"),l1l1ll_l1_ (u"ࠬ࠭⛵"),9999)
	l1111ll_l1_ = l1111l1l1_l1_(url)
	dict = {}
	for name,l11111l_l1_,block in l1111ll_l1_:
		name = name.replace(l1l1ll_l1_ (u"࠭࠭࠮ࠩ⛶"),l1l1ll_l1_ (u"ࠧࠨ⛷"))
		items = l1llllllll_l1_(block)
		if l1l1ll_l1_ (u"ࠨ࠿ࠪ⛸") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ⛹"):
			if l11111l_l1_ not in l1ll1111_l1_: continue
			if category!=l11111l_l1_: continue
			elif len(items)<2:
				if l11111l_l1_==l1ll1111_l1_[-1]:
					url = l11111lll_l1_(url)
					l1llll111l1_l1_(url)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⛺")+l1ll11l1_l1_)
				return
			else:
				url2 = l11111lll_l1_(url2)
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛻"),menu_name+l1l1ll_l1_ (u"ࠬอไอ็ํ฽ࠬ⛼"),url2,511)
				else: addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛽"),menu_name+l1l1ll_l1_ (u"ࠧศๆฯ้๏฿ࠧ⛾"),url2,515,l1l1ll_l1_ (u"ࠨࠩ⛿"),l1l1ll_l1_ (u"ࠩࠪ✀"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭✁"):
			if l11111l_l1_ not in l1llll1l_l1_: continue
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭✂")+l11111l_l1_+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨ✃")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ✄")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾࠲ࠪ✅")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠨࡡࡢࡣࠬ✆")+l1lll111_l1_
			if   name==l1l1ll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ✇"): name = l1l1ll_l1_ (u"ࠪห้์ฺ่ࠩ✈")
			elif name==l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭✉"): name = l1l1ll_l1_ (u"ࠬอไฺ็็ࠫ✊")
			elif name==l1l1ll_l1_ (u"࠭ࡦࡰࡴࡨ࡭࡬ࡴࠧ✋"): name = l1l1ll_l1_ (u"ࠧศๆ็฾ฮ࠭✌")
			elif name==l1l1ll_l1_ (u"ࠨࡻࡨࡥࡷ࠭✍"): name = l1l1ll_l1_ (u"ࠩสุ่์ษࠨ✎")
			elif name==l1l1ll_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡤࡰࠬ✏"): name = l1l1ll_l1_ (u"ࠫฬ๊ๅ้ี่ࠫ✐")
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ✑"),menu_name+l1l1ll_l1_ (u"࠭วๅฮ่๎฾ࡀࠠࠨ✒")+name,url2,514,l1l1ll_l1_ (u"ࠧࠨ✓"),l1l1ll_l1_ (u"ࠨࠩ✔"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ✕"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			if option in l1ll11_l1_: continue
			if l1l1ll_l1_ (u"ฺ้ࠪ์แศฬࠣวำื้ࠨ✖") in option: continue
			if l1l1ll_l1_ (u"ࠫฬ๊ใๅࠩ✗") in option: continue
			if l1l1ll_l1_ (u"ࠬอไๅ฼ฬࠫ✘") in option: continue
			option = option.replace(l1l1ll_l1_ (u"࠭โศศ่อࠥ࠭✙"),l1l1ll_l1_ (u"ࠧࠨ✚"))
			if   name==l1l1ll_l1_ (u"ࠨࡶࡼࡴࡪ࠭✛"): name = l1l1ll_l1_ (u"ࠩส่๋๎ูࠨ✜")
			elif name==l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ✝"): name = l1l1ll_l1_ (u"ࠫฬู๊ๆๆࠪ✞")
			elif name==l1l1ll_l1_ (u"ࠬ࡬࡯ࡳࡧ࡬࡫ࡳ࠭✟"): name = l1l1ll_l1_ (u"࠭วๅๆ฽อࠬ✠")
			elif name==l1l1ll_l1_ (u"ࠧࡺࡧࡤࡶࠬ✡"): name = l1l1ll_l1_ (u"ࠨษ็ื๋ฯࠧ✢")
			elif name==l1l1ll_l1_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࡣ࡯ࠫ✣"): name = l1l1ll_l1_ (u"ࠪห้๋่ิ็ࠪ✤")
			#if l1l1ll_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࠪ✥") not in value: value = option
			#else: value = re.findall(l1l1ll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࠧ࠭✦"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ✧")+l11111l_l1_+l1l1ll_l1_ (u"ࠧ࠾ࠩ✨")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠨࠨࠪ✩")+l11111l_l1_+l1l1ll_l1_ (u"ࠩࡀࠫ✪")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ✫")+l1lll111_l1_
			if name: title = option+l1l1ll_l1_ (u"ࠫࠥࡀࠧ✬")+name
			else: title = option   #+dict[l11111l_l1_][l1l1ll_l1_ (u"ࠬ࠶ࠧ✭")]
			if type==l1l1ll_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ✮"): addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✯"),menu_name+title,url,514,l1l1ll_l1_ (u"ࠨࠩ✰"),l1l1ll_l1_ (u"ࠩࠪ✱"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ✲"))
			elif type==l1l1ll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ✳") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠬࡃࠧ✴") in l1l1lll1_l1_:
				url3 = l111l11111_l1_(l1lll111_l1_,url)
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✵"),menu_name+title,url3,511)
			else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✶"),menu_name+title,url,515,l1l1ll_l1_ (u"ࠨࠩ✷"),l1l1ll_l1_ (u"ࠩࠪ✸"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫ✹"),l1l1ll_l1_ (u"ࠫࠬ✺"),filters,l1l1ll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭✻"))
	# mode==l1l1ll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ✼")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ✽")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭✾")			all l1ll1l1l_l1_ & l1111l11l_l1_ filters
	filters = filters.replace(l1l1ll_l1_ (u"ࠩࡀࠪࠬ✿"),l1l1ll_l1_ (u"ࠪࡁ࠵ࠬࠧ❀"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠫࠫ࠭❁"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠬࡃࠧ❂") in filters:
		items = filters.split(l1l1ll_l1_ (u"࠭ࠦࠨ❃"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠧ࠾ࠩ❄"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠨࠩ❅")
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠩ࠳ࠫ❆")
		if l1l1ll_l1_ (u"ࠪࠩࠬ❇") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭❈") and value!=l1l1ll_l1_ (u"ࠬ࠶ࠧ❉"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"࠭ࠠࠬࠢࠪ❊")+value
		elif mode==l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ❋") and value!=l1l1ll_l1_ (u"ࠨ࠲ࠪ❌"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠩࠩࠫ❍")+key+l1l1ll_l1_ (u"ࠪࡁࠬ❎")+value
		elif mode==l1l1ll_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ❏"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠬࠬࠧ❐")+key+l1l1ll_l1_ (u"࠭࠽ࠨ❑")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠧࠡ࠭ࠣࠫ❒"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠨࠨࠪ❓"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠩࡀ࠴ࠬ❔"),l1l1ll_l1_ (u"ࠪࡁࠬ❕"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ❖"),l1l1ll_l1_ (u"ࠬ࠭❗"),filters,l1l1ll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ❘"))
	return l1llllll_l1_
l1ll1111_l1_ = []
l1llll1l_l1_ = []
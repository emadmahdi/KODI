# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ᫵")
menu_name = l1l1ll_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭᫶")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠨไสส๊ะ๊ࠨ᫷")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1ll1l_l1_(url)
	elif mode==302: results = l11l1l_l1_(url)
	elif mode==303: results = l1lllll111_l1_(url)
	elif mode==304: results = l11ll1l_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫸"),menu_name+l1l1ll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ᫹"),l1l1ll_l1_ (u"ࠫࠬ᫺"),309,l1l1ll_l1_ (u"ࠬ࠭᫻"),l1l1ll_l1_ (u"࠭ࠧ᫼"),l1l1ll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᫽"))
	addMenuItem(l1l1ll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᫾"),l1l1ll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᫿"),l1l1ll_l1_ (u"ࠪࠫᬀ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᬁ"),l1l1l1_l1_,l1l1ll_l1_ (u"ࠬ࠭ᬂ"),l1l1ll_l1_ (u"࠭ࠧᬃ"),l1l1ll_l1_ (u"ࠧࠨᬄ"),l1l1ll_l1_ (u"ࠨࠩᬅ"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᬆ"))
	html = response.content
	html = l1lll111l1_l1_(html)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡀࡺࡲ࠾ࠩ࠰࠭ࡃ࠮ࡂࡳࡱࡣࡱࡂࠬᬇ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᬈ"),block,re.DOTALL)
	for link,title in items:
		link = l1l1l1_l1_+link
		title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧᬉ"))
		if title==l1l1ll_l1_ (u"࠭ัๆุส๊ࠬᬊ"): link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ี๊฼ว็࠱ࠪᬋ")
		if not any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬌ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᬍ")+menu_name+title,link,301)
	l1ll1l_l1_(l1l1l1_l1_+l1l1ll_l1_ (u"ࠪ࠳࡭ࡵ࡭ࡦࠩᬎ"))
	return html
def l1ll1l_l1_(url):
	seq = 0
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᬏ"),url,l1l1ll_l1_ (u"ࠬ࠭ᬐ"),l1l1ll_l1_ (u"࠭ࠧᬑ"),l1l1ll_l1_ (u"ࠧࠨᬒ"),l1l1ll_l1_ (u"ࠨࠩᬓ"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᬔ"))
	html = response.content
	html = l1lll111l1_l1_(html)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮ࠫࡁ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠯ࠧᬕ"),html,re.DOTALL)
	if l1lll11_l1_:
		for block in l1lll11_l1_:
			seq += 1
			items = re.findall(l1l1ll_l1_ (u"ࠫࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᬖ"),block,re.DOTALL)
			for title,test,link in items:
				title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧᬗ"))
				if title==l1l1ll_l1_ (u"࠭ࠧᬘ"): title = l1l1ll_l1_ (u"ࠧษ๊๋์ํ๎ࠧᬙ")
				if l1l1ll_l1_ (u"ࠨࡧࡰࡂࡁࡧࠧᬚ") not in test:
					if block.count(l1l1ll_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᬛ"))>0:
						l1ll1lllll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᬜ"),block,re.DOTALL)
						for link in l1ll1lllll_l1_:
							title = link.split(l1l1ll_l1_ (u"ࠫ࠴࠭ᬝ"))[-2]
							addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬞ"),menu_name+title,link,301)
						continue
					else: link = url+l1l1ll_l1_ (u"࠭࠿ࡴࡧࡴࡹࡪࡴࡣࡦ࠿ࠪᬟ")+str(seq)
				#l111lllll_l1_ = [l1l1ll_l1_ (u"ࠧๆี็ื้อสࠡࠩᬠ"),l1l1ll_l1_ (u"ࠨษไ่ฬ๋ࠠࠨᬡ"),l1l1ll_l1_ (u"ࠩหีฬ๋ฬࠨᬢ"),l1l1ll_l1_ (u"ࠪ฽ึ๎ึࠨᬣ"),l1l1ll_l1_ (u"่๊๊ࠫษษอࠫᬤ"),l1l1ll_l1_ (u"ࠬอฺศ่์ࠫᬥ")]
				#if any(value in title for value in l111lllll_l1_):
				if not any(value in title for value in l1ll11_l1_):
					addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᬦ"),menu_name+title,link,302)
	else: l11l1l_l1_(url,html)
	return
def l11l1l_l1_(url,html=l1l1ll_l1_ (u"ࠧࠨᬧ")):
	if html==l1l1ll_l1_ (u"ࠨࠩᬨ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ᬩ"),url,l1l1ll_l1_ (u"ࠪࠫᬪ"),l1l1ll_l1_ (u"ࠫࠬᬫ"),l1l1ll_l1_ (u"ࠬ࠭ᬬ"),l1l1ll_l1_ (u"࠭ࠧᬭ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᬮ"))
		html = response.content
		html = l1lll111l1_l1_(html)
	if l1l1ll_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬᬯ") in url:
		url,seq = url.split(l1l1ll_l1_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ᬰ"))
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬࡁࡹࡥࡤࡶ࡬ࡳࡳࡄ࠮ࠫࡁ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠯ࠧᬱ"),html,re.DOTALL)
		block = l1lll11_l1_[int(seq)-1]
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࠧࡶ࡯ࡴࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡵࡤࡺࡀࠪᬲ"),html,re.DOTALL)
		block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠬࡂࡡ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᬳ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,data,img in items:
		title = re.findall(l1l1ll_l1_ (u"࠭࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠱࠮ࡄࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡱࡃ᬴࠭"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l1ll_l1_ (u"ࠧ࡝ࡰࠪᬵ"),l1l1ll_l1_ (u"ࠨࠩᬶ")).strip(l1l1ll_l1_ (u"ࠩࠣࠫᬷ"))
		if not title or title==l1l1ll_l1_ (u"ࠪࠫᬸ"):
			title = re.findall(l1l1ll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥࡂ࠳࠰࠿࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬᬹ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l1ll_l1_ (u"ࠬࡢ࡮ࠨᬺ"),l1l1ll_l1_ (u"࠭ࠧᬻ")).strip(l1l1ll_l1_ (u"ࠧࠡࠩᬼ"))
			if not title or title==l1l1ll_l1_ (u"ࠨࠩᬽ"):
				title = re.findall(l1l1ll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᬾ"),data,re.DOTALL)
				title = title[0].replace(l1l1ll_l1_ (u"ࠪࡠࡳ࠭ᬿ"),l1l1ll_l1_ (u"ࠫࠬᭀ")).strip(l1l1ll_l1_ (u"ࠬࠦࠧᭁ"))
		title = unescapeHTML(title)
		#if title==l1l1ll_l1_ (u"࠭ࠧᭂ"): continue
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l11ll_l1_ = link+data+img
			if l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩᭃ") in l11ll_l1_ or l1l1ll_l1_ (u"ࠨ็ึ᭄ุ่๊ࠧ") in l11ll_l1_ or l1l1ll_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࠦࠬᭅ") in l11ll_l1_:
				if l1l1ll_l1_ (u"ࠪฬึอๅอࠩᭆ") in data: title = l1l1ll_l1_ (u"ࠫอืๆศ็ฯࠤࠬᭇ")+title
				elif l1l1ll_l1_ (u"๋ࠬำๅี็ࠫᭈ") in data or l1l1ll_l1_ (u"࠭ๅ้ี่ࠫᭉ") in data: title = l1l1ll_l1_ (u"ࠧๆี็ื้ࠦࠧᭊ")+title
				addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᭋ"),menu_name+title,link,303,img)
			else: addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᭌ"),menu_name+title,link,305,img)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᭍"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᭎"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭏"),menu_name+l1l1ll_l1_ (u"࠭ีโฯฬࠤࠬ᭐")+title,link,302)
	return
def l1lllll111_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫ᭑"),url,l1l1ll_l1_ (u"ࠨࠩ᭒"),l1l1ll_l1_ (u"ࠩࠪ᭓"),l1l1ll_l1_ (u"ࠪࠫ᭔"),l1l1ll_l1_ (u"ࠫࠬ᭕"),l1l1ll_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡓࡆࡃࡖࡓࡓ࡙࠭࠲ࡵࡷࠫ᭖"))
	html = response.content
	html = l1lll111l1_l1_(html)
	name = re.findall(l1l1ll_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠭᭗"),html,re.DOTALL)
	name = name[0].replace(l1l1ll_l1_ (u"ࠧࡽࠢึ๎๊อࠠ็ษ๋ࠫ᭘"),l1l1ll_l1_ (u"ࠨࠩ᭙")).replace(l1l1ll_l1_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫ᭚"),l1l1ll_l1_ (u"ࠪࠫ᭛")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭᭜")).replace(l1l1ll_l1_ (u"ࠬࠦࠠࠨ᭝"),l1l1ll_l1_ (u"࠭ࠠࠨ᭞"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡵࡨࡥࡸࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ᭟"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᭠"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l1l1ll_l1_ (u"ࠩࠣࠫ᭡")+title.replace(l1l1ll_l1_ (u"ࠪࡠࡳ࠭᭢"),l1l1ll_l1_ (u"ࠫࠬ᭣")).strip(l1l1ll_l1_ (u"ࠬࠦࠧ᭤"))
				title = title.replace(l1l1ll_l1_ (u"࠭࡜࡯ࠩ᭥"),l1l1ll_l1_ (u"ࠧࠨ᭦")).strip(l1l1ll_l1_ (u"ࠨࠢࠪ᭧"))
				addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᭨"),menu_name+title,link,304)
		else: l11ll1l_l1_(url)
	return
def l11ll1l_l1_(url):
	if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ᭩") not in url: url = url.strip(l1l1ll_l1_ (u"ࠫ࠴࠭᭪"))+l1l1ll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࡮ࡴࡧࠨ᭫")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖ᭬ࠪ"),url,l1l1ll_l1_ (u"ࠧࠨ᭭"),l1l1ll_l1_ (u"ࠨࠩ᭮"),l1l1ll_l1_ (u"ࠩࠪ᭯"),l1l1ll_l1_ (u"ࠪࠫ᭰"),l1l1ll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ᭱"))
	html = response.content
	html = l1lll111l1_l1_(html)
	#WRITE_THIS(l1l1ll_l1_ (u"ࠬ࠭᭲"),html)
	if l1l1ll_l1_ (u"࠭࠯ࡴࡧ࡯ࡥࡷࡿ࠯ࠨ᭳") not in url:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡧࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᭴"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᭵"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ᭶"),l1l1ll_l1_ (u"ࠪࠫ᭷")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭᭸"))
			title = l1l1ll_l1_ (u"ࠬอไฮๆๅอࠥ࠭᭹")+title
			addMenuItem(l1l1ll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᭺"),menu_name+title,link,305)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡦࡨࡸࡦ࡯࡬ࡴࠤࠫ࠲࠯ࡅࠩࠣࡴࡨࡰࡦࡺࡥࡥࠤࠪ᭻"),html,re.DOTALL)
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᭼"),block,re.DOTALL)
		for link,img,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠩ࡟ࡲࠬ᭽"),l1l1ll_l1_ (u"ࠪࠫ᭾")).strip(l1l1ll_l1_ (u"ࠫࠥ࠭᭿"))
			addMenuItem(l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᮀ"),menu_name+title,link,305,img)
	return
def PLAY(url):
	l1l1ll_l1_ (u"ࠨࠢࠣࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡮ࡩ࡯ࡧࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ࠯ࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡇࡉࡈࡕࡄࡆࡡࡄࡈࡎࡒࡂࡐࡡࡋࡘࡒࡒࠨࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠩࠋࠋࡦࡳࡴࡱࡩࡦࡵࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡲ࡯࡮࡫ࡳ࠯ࡩࡨࡸࡤࡪࡩࡤࡶࠫ࠭ࠏࠏࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࠢࡀࠤࡨࡵ࡯࡬࡫ࡨࡷࡠ࠭ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࠩࡠࠎࠎࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠥ࡬ࡷ࡫ࡦࠡ࠿ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦ࠱ࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫࡜࠲ࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿ࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠱࠭ࡃࡰࡱ࡮࡭ࡪ࠭࠺ࠨࡒࡋࡔࡘࡋࡓࡔࡋࡇࡁࠬ࠱ࡐࡉࡒࡖࡉࡘ࡙ࡉࡅࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡘࡎࡏࡓࡖࡢࡇࡆࡉࡈࡆ࠮ࠪࡋࡊ࡚ࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯ࠤࡂࠦࡄࡆࡅࡒࡈࡊࡥࡁࡅࡋࡏࡆࡔࡥࡈࡕࡏࡏࠬࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭ࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡥࡩࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡡࡥࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡤࡨࡤࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࠤࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡧࡤࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨࠫࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࠩࡡࡥࡡ࡫ࡸࡲࡲࠠ࠾ࠢࡇࡉࡈࡕࡄࡆࡡࡄࡈࡎࡒࡂࡐࡡࡋࡘࡒࡒࠨࡢࡦࡢ࡬ࡹࡳ࡬ࠪࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡦࡹࡴࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡦ࡬ࡷࡵࡲࡡࡺ࠼ࠣࡲࡴࡴࡥ࠼ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࡟࠵ࡣࠫࠨ࠱ࠪࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ࠿࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡧࡥ࠲ࡨ࡯࡭ࡢࡸ࡬ࡨࡸ࠴࡬ࡪࡸࡨ࠳ࠬࢃࠊࠊࠤࠥࠦᮁ")
	url2 = url+l1l1ll_l1_ (u"ࠧࡸࡣࡷࡧ࡭࡯࡮ࡨ࠱ࠪᮂ")
	#server = SERVER(url2,l1l1ll_l1_ (u"ࠨࡷࡵࡰࠬᮃ"))
	#headers2 = {l1l1ll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᮄ"):None,l1l1ll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᮅ"):server}
	response = OPENURL_REQUESTS_CACHED(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᮆ"),url2,l1l1ll_l1_ (u"ࠬ࠭ᮇ"),l1l1ll_l1_ (u"࠭ࠧᮈ"),l1l1ll_l1_ (u"ࠧࠨᮉ"),l1l1ll_l1_ (u"ࠨࠩᮊ"),l1l1ll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬᮋ"))
	html = response.content
	html = l1lll111l1_l1_(html)
	#url2 = l1lll111ll_l1_(url2,l1l1ll_l1_ (u"ࠪࡰࡴࡽࡥࡳࠩᮌ"))
	#html = l1lll11111_l1_(l1llll1l1_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᮍ"),url2,l1l1ll_l1_ (u"ࠬ࠭ᮎ"),l1l1ll_l1_ (u"࠭ࠧᮏ"),l1l1ll_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪᮐ"))
	#if html and kodi_version>18.99: html = html.decode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᮑ"))
	#html = l1lll111l1_l1_(html)
	l11l1_l1_ = []
	# download l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᮒ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᮓ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l1l1ll_l1_ (u"ࠫࡡࡴࠧᮔ"),l1l1ll_l1_ (u"ࠬ࠭ᮕ")).strip(l1l1ll_l1_ (u"࠭ࠠࠨᮖ"))
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨᮗ"),title,re.DOTALL)
			if l11ll1l1_l1_:
				l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࡡࡢࡣࡤ࠭ᮘ")+l11ll1l1_l1_[0]
				#title = l1l1ll_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᮙ")
				title = SERVER(link,l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥࠨᮚ"))
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࠬᮛ")
			l111111l1_l1_ = link+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᮜ")+title+l1l1ll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᮝ")+l11ll1l1_l1_
			l11l1_l1_.append(l111111l1_l1_)
	# l11lllll1_l1_ l1ll_l1_
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࠣࡹࡤࡸࡨ࡮ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᮞ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		# l1l1l1l11_l1_ l11lllll1_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࠪ࠲࠳࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧᮟ"),block,re.DOTALL)
		for link in l1ll_l1_:
			link = l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᮠ")+link
			title = SERVER(link,l1l1ll_l1_ (u"ࠪࡲࡦࡳࡥࠨᮡ"))
			link = link+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᮢ")+title+l1l1ll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᮣ")
			l11l1_l1_.append(link)
		# l1lll1111l_l1_ l11lllll1_l1_ l1ll_l1_
		l1ll_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡡ࡫ࡣࡻࡠ࠭ࢁࡵࡳ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬᮤ"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࡮ࡥࡧࡻࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩᮥ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l1ll_l1_ (u"ࠨ࡞ࡱࠫᮦ"),l1l1ll_l1_ (u"ࠩࠪᮧ")).strip(l1l1ll_l1_ (u"ࠪࠤࠬᮨ"))
				title = title.replace(l1l1ll_l1_ (u"ࠫࡈ࡯࡭ࡢࠢࡑࡳࡼ࠭ᮩ"),l1l1ll_l1_ (u"ࠬࡉࡩ࡮ࡣࡑࡳࡼ᮪࠭"))
				link = l1ll_l1_[0]+l1l1ll_l1_ (u"࠭࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡹ࡬ࡸࡨ࡮ࠦࡪࡰࡧࡩࡽࡃ᮫ࠧ")+index+l1l1ll_l1_ (u"ࠧࠧ࡫ࡧࡁࠬᮬ")+id+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᮭ")+title+l1l1ll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᮮ")
				l11l1_l1_.append(link)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᮯ"),l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᮰"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"ࠬ࠭᮱"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"࠭ࠧ᮲"): return
	search = search.replace(l1l1ll_l1_ (u"ࠧࠡࠩ᮳"),l1l1ll_l1_ (u"ࠨ࠭ࠪ᮴"))
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ᮵")+search
	l11l1l_l1_(url)
	return
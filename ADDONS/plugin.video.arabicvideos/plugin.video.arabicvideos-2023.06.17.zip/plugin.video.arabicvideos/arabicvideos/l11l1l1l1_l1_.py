# -*- coding: utf-8 -*-
import sys
l1lll1_l1_ = sys.version_info [0] == 2
l11l_l1_ = 2048
l1l1l_l1_ = 7
def l1l1ll_l1_ (l1_l1_):
    global l11lll_l1_
    l1llll1_l1_ = ord (l1_l1_ [-1])
    l1llll_l1_ = l1_l1_ [:-1]
    l111_l1_ = l1llll1_l1_ % len (l1llll_l1_)
    l1111l_l1_ = l1llll_l1_ [:l111_l1_] + l1llll_l1_ [l111_l1_:]
    if l1lll1_l1_:
        l1l11l_l1_ = unicode () .join ([unichr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    else:
        l1l11l_l1_ = str () .join ([chr (ord (char) - l11l_l1_ - (l1111_l1_ + l1llll1_l1_) % l1l1l_l1_) for l1111_l1_, char in enumerate (l1111l_l1_)])
    return eval (l1l11l_l1_)
from EXCLUDES import *
script_name = l1l1ll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧᅛ")
headers = { l1l1ll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᅜ") : l1l1ll_l1_ (u"ࠧࠨᅝ") }
menu_name = l1l1ll_l1_ (u"ࠨࡡࡄࡖࡑࡥࠧᅞ")
l1l1l1_l1_ = WEBSITES[script_name][0]
l1ll11_l1_ = [l1l1ll_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩᅟ"),l1l1ll_l1_ (u"ࠪห้้ไࠨᅠ"),l1l1ll_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᅡ"),l1l1ll_l1_ (u"ࠬอไฺษหࠫᅢ"),l1l1ll_l1_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࠭ᅣ"),l1l1ll_l1_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧᅤ"),l1l1ll_l1_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩᅥ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l11l1l_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l11ll1l_l1_(url)
	elif mode==204: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ᅦ")+text)
	elif mode==205: results = l111l11_l1_(url,l1l1ll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪᅧ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅨ"),menu_name+l1l1ll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᅩ"),l1l1ll_l1_ (u"࠭ࠧᅪ"),209,l1l1ll_l1_ (u"ࠧࠨᅫ"),l1l1ll_l1_ (u"ࠨࠩᅬ"),l1l1ll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᅭ"))
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅮ"),menu_name+l1l1ll_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧᅯ"),l1l1l1_l1_,205)
	addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅰ"),menu_name+l1l1ll_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩᅱ"),l1l1l1_l1_,204)
	addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᅲ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᅳ"),l1l1ll_l1_ (u"ࠩࠪᅴ"),9999)
	addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅵ"),script_name+l1l1ll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᅶ")+menu_name+l1l1ll_l1_ (u"๋ࠬๅ๋ิฬࠫᅷ"),l1l1l1_l1_+l1l1ll_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࠪᅸ"),201)
	addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅹ"),script_name+l1l1ll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᅺ")+menu_name+l1l1ll_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧᅻ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᅼ"),201)
	addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅽ"),script_name+l1l1ll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᅾ")+menu_name+l1l1ll_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᅿ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫᆀ"),201)
	addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆁ"),script_name+l1l1ll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᆂ")+menu_name+l1l1ll_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᆃ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫࡄࡅ࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨᆄ"),201)
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠬࡍࡅࡕࠩᆅ"),l1l1l1_l1_,l1l1ll_l1_ (u"࠭ࠧᆆ"),headers,True,l1l1ll_l1_ (u"ࠧࠨᆇ"),l1l1ll_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᆈ"))
	html = response.content
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡴࡢࡤࡶࠬ࠳࠰࠿ࠪࡏࡤ࡭ࡳࡘ࡯ࡸࠩᆉ"),html,re.DOTALL)
	if l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆊ"),block,re.DOTALL)
		for filter,title in items:
			link = l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡬ࡴࡳࡥ࠰࡯ࡲࡶࡪࡅࡦࡪ࡮ࡷࡩࡷࡃࠧᆋ")+filter
			addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆌ"),script_name+l1l1ll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆍ")+menu_name+title,link,201)
		addMenuItem(l1l1ll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᆎ"),l1l1ll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᆏ"),l1l1ll_l1_ (u"ࠩࠪᆐ"),9999)
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᆑ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	items = re.findall(l1l1ll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᆒ"),block,re.DOTALL)
	#l111lllll_l1_ = [l1l1ll_l1_ (u"๋ࠬำๅี็หฯࠦࠧᆓ"),l1l1ll_l1_ (u"࠭วโๆส้ࠥ࠭ᆔ"),l1l1ll_l1_ (u"ࠧษำส้ั࠭ᆕ"),l1l1ll_l1_ (u"ࠨ฻ิ์฻࠭ᆖ"),l1l1ll_l1_ (u"ࠩๆ่๏ฮวหࠩᆗ"),l1l1ll_l1_ (u"ࠪห฿อๆ๊ࠩᆘ")]
	for link,title in items:
		if l1l1ll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᆙ") not in link: link = l1l1l1_l1_+link
		title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧᆚ"))
		if not any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆛ"),script_name+l1l1ll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆜ")+menu_name+title,link,201)
	return html
def l11l1l_l1_(url):
	l1l1ll_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡧࡱࡵࠤࡕࡕࡓࡕࠢࡩ࡭ࡱࡺࡥࡳ࠼ࠍࠍ࡮࡬ࠠࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬࠦࡩ࡯ࠢࡸࡶࡱࡀࠊࠊࠋࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨࡁࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࠰ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠳࠮ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠭ࠏࠏࠉࡥࡣࡷࡥ࠷ࠦ࠽ࠡࡽࠪࡪࡴࡸ࡭ࠨ࠼ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠰ࠬࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥ࠿ࠪ࠾ࠬ࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡣࠠ࠾ࠢࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬࡣࠠ࠾ࠢࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩࡠࠤࡂࠦࠧࡈ࡜࠷ࡓࡩ࠶࡮࡫ࡖࡆࡥࡌࡽࡣࡈࡳ࠷ࡍࡿࡍࡱࡉࡇࡵ࡝࠵ࡻ࡚ࡰࡣࡘ࡜࡟ࡉ࠶ࡉࡧ࡛ࡼࡽ࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡻࡦࡸࡢ࡭࡫ࡲࡲࡿࡺࡶࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࡨࡽࡏࡶࡤࡪࡋ࠹ࡍࡲࡘ࠰ࡎ࡚ࡑࡎ࡞ࡲࡒࡍࡓ࡭ࡨࡦࡔࡄ࡬ࡺ࡙ࡲࡩࡍ࡚࠲ࡄ࠵࡝ࡱࡋ࠹ࡑࡕࡌࡷࡎࡴ࡚ࡩࡤࡋ࡚ࡱࡏࡪࡰ࡫ࡔࡘࡗࡘࡖ࡙ࡏ࠴࡙࡯ࡲࡇࡣࡈࡉࡶࡦ࡛ࡆ࡬ࡑࡈࡼࡊࡕࡕࡗࡓ࡜࡙࠹࠷ࡤ࠲ࡐ࡚ࡩࡍࡩࡷࡦࡰࡐࡽ࡛࡝ࡒࡇࡓࡰࡰ࠷࡛ࡘࡊ࠲ࡧ࡯ࡽࡲ࡚࠲ࡄࡱࡥ࠸ࡶࡘࡔ࠳ࡅ࡛ࡧ࡚ࡁ࠴ࡕࡰࡒ࡯ࡪࡆࡥ࠵࡚ࡇࡎࡹࡉ࡮࠳࡫࡝ࡾࡏ࠶ࡊ࡬ࡘࡼ࡟࡚ࡧࡺࡐࡰࡑࡾࡕࡇࡆࡻࡐ࡮ࡎ࠶ࡎࡅࡐ࡯࡞࡯࡮࡬ࡏ࠴ࡑ࡯࡟࡚ࡂ࡮ࡐ࡭ࡨࡲ࡟ࡺࡂ࠲ࡑ࡮ࡆࡽࡍࡕࡌ࡮ࡑࡿࡠࡪࡐࡆࡌࡾࡓ࡚࡙ࡺࡏࡽ࡯࠵ࡔࡄࡤ࠷ࡐࡘࡇࡰࡎࡘࡋࡼࡓ࡙ࡲࡪࡏ࡬ࡪ࡭࡫ࡗ࠽࠾ࠩࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠴࠯ࡨࡦࡺࡡ࠳࠮࡫ࡩࡦࡪࡥࡳࡵ࠵࠰࡙ࡸࡵࡦ࠮ࠪࠫ࠱࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠨ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠤࠥࠦᆝ")
	if l1l1ll_l1_ (u"ࠩࡂࡃࠬᆞ") in url: url,type = url.split(l1l1ll_l1_ (u"ࠪࡃࡄ࠭ᆟ"))
	else: type = l1l1ll_l1_ (u"ࠫࠬᆠ")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ᆡ"),l1l1ll_l1_ (u"࠭ࠧᆢ"),url,type)
	#if url==l1l1l1_l1_: url = url+l1l1ll_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᆣ")
	#DIALOG_OK(l1l1ll_l1_ (u"ࠨࠩᆤ"),l1l1ll_l1_ (u"ࠩࠪᆥ"),url,l1l1ll_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪᆦ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨᆧ"),url,l1l1ll_l1_ (u"ࠬ࠭ᆨ"),headers,True,l1l1ll_l1_ (u"࠭ࠧᆩ"),l1l1ll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᆪ"))
	html = response.content#.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᆫ"))
	#WRITE_THIS(html)
	if l1l1ll_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫᆬ") in url: l1lll11_l1_ = [html]
	elif type==l1l1ll_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬᆭ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ᆮ"),html,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᆯ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᆰ"),html,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩᆱ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᆲ"),html,re.DOTALL)
	elif type==l1l1ll_l1_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᆳ"):
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩᆴ"),html,re.DOTALL)
	else:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬᆵ"),html,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ᆶ"),l1l1ll_l1_ (u"࠭ࠧᆷ"),l1l1ll_l1_ (u"ࠧࠨᆸ"),str(l1lll11_l1_))
	if not l1lll11_l1_: return
	block = l1lll11_l1_[0]
	#items = re.findall(l1l1ll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆹ"),block,re.DOTALL)
	l11l1l1ll_l1_ = [l1l1ll_l1_ (u"ุ่ࠩฬํฯสࠩᆺ"),l1l1ll_l1_ (u"ࠪๅ๏๊ๅࠨᆻ"),l1l1ll_l1_ (u"ࠫฬเๆ๋หࠪᆼ"),l1l1ll_l1_ (u"้ࠬไ๋สࠪᆽ"),l1l1ll_l1_ (u"࠭วฺๆส๊ࠬᆾ"),l1l1ll_l1_ (u"่ࠧัสๅࠬᆿ"),l1l1ll_l1_ (u"ࠨ็หหึอษࠨᇀ"),l1l1ll_l1_ (u"ࠩ฼ี฻࠭ᇁ"),l1l1ll_l1_ (u"้ࠪ์ืฬศ่ࠪᇂ"),l1l1ll_l1_ (u"ࠫฬ๊ศ้็ࠪᇃ")]
	#addMenuItem(l1l1ll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᇄ"),l1l1ll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᇅ"),l1l1ll_l1_ (u"ࠧࠨᇆ"),9999)
	items = re.findall(l1l1ll_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᇇ"),block,re.DOTALL)
	if not items:
		items = re.findall(l1l1ll_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᇈ"),block,re.DOTALL)
		l1ll_l1_,l111llll1_l1_,titles = zip(*items)
		items = zip(l111llll1_l1_,l1ll_l1_,titles)
	l1l1_l1_ = []
	for img,link,title in items:
		#link = escapeUNICODE(link)
		#link = QUOTE(link)
		if l1l1ll_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᇉ") in link: continue
		link = link.strip(l1l1ll_l1_ (u"ࠫ࠴࠭ᇊ"))
		title = unescapeHTML(title)
		title = title.strip(l1l1ll_l1_ (u"ࠬࠦࠧᇋ"))
		if l1l1ll_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭ᇌ") in link or any(value in title for value in l11l1l1ll_l1_):
			addMenuItem(l1l1ll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᇍ"),menu_name+title,link,202,img)
		elif l1l1ll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᇎ") in link and l1l1ll_l1_ (u"ࠩส่า๊โสࠩᇏ") in title:
			l11111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᇐ"),title,re.DOTALL)
			if l11111_l1_:
				title = l1l1ll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᇑ") + l11111_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇒ"),menu_name+title,link,203,img)
					l1l1_l1_.append(title)
		elif l1l1ll_l1_ (u"࠭࠯ࡱࡣࡦ࡯࠴࠭ᇓ") in link:
			addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇔ"),menu_name+title,link+l1l1ll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᇕ"),201,img)
		else: addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇖ"),menu_name+title,link,203,img)
	if type in [l1l1ll_l1_ (u"ࠪࠫᇗ"),l1l1ll_l1_ (u"ࠫࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᇘ")]:
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᇙ"),html,re.DOTALL)
		if l1lll11_l1_:
			block = l1lll11_l1_[0]
			items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇚ"),block,re.DOTALL)
			for link,title in items:
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				title = title.replace(l1l1ll_l1_ (u"ࠧศๆุๅาฯࠠࠨᇛ"),l1l1ll_l1_ (u"ࠨࠩᇜ"))
				if l1l1ll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᇝ") in url:
					l111lll11_l1_ = link.split(l1l1ll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇞ"))[1]
					l11l11ll1_l1_ = url.split(l1l1ll_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᇟ"))[1]
					link = url.replace(l1l1ll_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᇠ")+l11l11ll1_l1_,l1l1ll_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬᇡ")+l111lll11_l1_)
				if title!=l1l1ll_l1_ (u"ࠧࠨᇢ"): addMenuItem(l1l1ll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇣ"),menu_name+l1l1ll_l1_ (u"ุࠩๅาฯࠠࠨᇤ")+title,link,201)
	return
def l11ll1l_l1_(url):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠪࠫᇥ"),l1l1ll_l1_ (u"ࠫࠬᇦ"),url,l1l1ll_l1_ (u"ࠬ࠭ᇧ"))
	l11l1lll1_l1_,items,l11l11l1_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪᇨ"),url,l1l1ll_l1_ (u"ࠧࠨᇩ"),headers,True,l1l1ll_l1_ (u"ࠨࠩᇪ"),l1l1ll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᇫ"))
	html = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᇬ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᇭ"),html,re.DOTALL)
	if l1lll11_l1_:
		l11l11l1_l1_ = []
		l1l1l11_l1_ = l1l1ll_l1_ (u"ࠬ࠭ᇮ").join(l1lll11_l1_)
		items = re.findall(l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᇯ"),l1l1l11_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l1l1ll_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨᇰ"))
	for link in items:
		link = link.strip(l1l1ll_l1_ (u"ࠨ࠱ࠪᇱ"))
		title = l1l1ll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᇲ") + link.split(l1l1ll_l1_ (u"ࠪ࠳ࠬᇳ"))[-1].replace(l1l1ll_l1_ (u"ࠫ࠲࠭ᇴ"),l1l1ll_l1_ (u"ࠬࠦࠧᇵ"))
		l11l1ll1_l1_ = re.findall(l1l1ll_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬᇶ"),link.split(l1l1ll_l1_ (u"ࠧ࠰ࠩᇷ"))[-1],re.DOTALL)
		if l11l1ll1_l1_: l11l1ll1_l1_ = l11l1ll1_l1_[0]
		else: l11l1ll1_l1_ = l1l1ll_l1_ (u"ࠨ࠲ࠪᇸ")
		l11l11l1_l1_.append([link,title,l11l1ll1_l1_])
	items = sorted(l11l11l1_l1_, reverse=False, key=lambda key: int(key[2]))
	l11l1ll11_l1_ = str(items).count(l1l1ll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᇹ"))
	l11l1lll1_l1_ = str(items).count(l1l1ll_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᇺ"))
	if l11l1ll11_l1_>1 and l11l1lll1_l1_>0 and l1l1ll_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᇻ") not in url:
		for link,title,l11l1ll1_l1_ in items:
			if l1l1ll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᇼ") in link:
				#link = QUOTE(link)
				addMenuItem(l1l1ll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇽ"),menu_name+title,link,203)
	else:
		for link,title,l11l1ll1_l1_ in items:
			if l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩᇾ") not in link:
				#if l1l1ll_l1_ (u"ࠨࠧࠪᇿ") not in link: link = QUOTE(link)
				#else: link = QUOTE(UNQUOTE(link))
				#link = UNQUOTE(link)
				title = UNQUOTE(title)
				addMenuItem(l1l1ll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨሀ"),menu_name+title,link,202)
	return
def PLAY(url):
	#LOG_THIS(l1l1ll_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪሁ"),l1l1ll_l1_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭ሂ"))
	l11l1_l1_ = []
	parts = url.split(l1l1ll_l1_ (u"ࠬ࠵ࠧሃ"))
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧሄ"),l1l1ll_l1_ (u"ࠧࠨህ"),url,l1l1ll_l1_ (u"ࠨࡒࡏࡅ࡞࠳࠱ࡴࡶࠪሆ"))
	#url = UNQUOTE(QUOTE(url))
	hostname = l1l1l1_l1_
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠩࡊࡉ࡙࠭ሇ"),url,l1l1ll_l1_ (u"ࠪࠫለ"),headers,True,True,l1l1ll_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨሉ"))
	html = response.content#.encode(l1l1ll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪሊ"))
	id = re.findall(l1l1ll_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧላ"),html,re.DOTALL)
	if not id: id = re.findall(l1l1ll_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨሌ"),html,re.DOTALL)
	if not id: id = re.findall(l1l1ll_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪል"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l1l1ll_l1_ (u"ࠩࠪሎ"),l1l1ll_l1_ (u"ࠪࠫሏ"),l1l1ll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሐ"),l1l1ll_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩሑ"))
	#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሒ"),l1l1ll_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠶࠷࠱ࠨሓ"))
	if l1l1ll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩሔ") in html:
		#parts = url.split(l1l1ll_l1_ (u"ࠩ࠲ࠫሕ"))
		url2 = url.replace(parts[3],l1l1ll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩሖ"))
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠫࡌࡋࡔࠨሗ"),url2,l1l1ll_l1_ (u"ࠬ࠭መ"),headers,True,True,l1l1ll_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪሙ"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠧࡶࡶࡩ࠼ࠬሚ"))
		l111ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧማ"),l1l11ll1_l1_,re.DOTALL)
		l1lll1l_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪሜ"),l1l11ll1_l1_,re.DOTALL)
		l111ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧም"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬሞ"),l1l11ll1_l1_)
		l111l1lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሟ"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		l11l11l1l_l1_ = re.findall(l1l1ll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨሠ"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
		items = l111ll1l1_l1_+l1lll1l_l1_+l111ll1ll_l1_+l111ll111_l1_+l111l1lll_l1_+l11l11l1l_l1_
		#LOG_THIS(l1l1ll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧሡ"),l1l1ll_l1_ (u"ࠨࡇࡐࡅࡉࠦࡓࡕࡃࡕࡘ࡚ࠥࡉࡎࡋࡑࡋࠥ࠺࠴࠵ࠩሢ"))
		if not items:
			items = re.findall(l1l1ll_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሣ"),l1l11ll1_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l1l1ll_l1_ (u"ࠪ࠲ࡵࡴࡧࠨሤ") in server: continue
			if l1l1ll_l1_ (u"ࠫ࠳ࡰࡰࡨࠩሥ") in server: continue
			if l1l1ll_l1_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬሦ") in server: continue
			l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧሧ"),title,re.DOTALL)
			if l11ll1l1_l1_:
				l11ll1l1_l1_ = l11ll1l1_l1_[0]
				if l11ll1l1_l1_ in title: title = title.replace(l11ll1l1_l1_+l1l1ll_l1_ (u"ࠧࡱࠩረ"),l1l1ll_l1_ (u"ࠨࠩሩ")).replace(l11ll1l1_l1_,l1l1ll_l1_ (u"ࠩࠪሪ")).strip(l1l1ll_l1_ (u"ࠪࠤࠬራ"))
				l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࡠࠩሬ")+l11ll1l1_l1_
			else: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭ር")
			#LOG_THIS(l1l1ll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሮ"),l1l1ll_l1_ (u"ࠧ࡜ࠩሯ")+str(id)+l1l1ll_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ሰ")+str(hostname)+l1l1ll_l1_ (u"ࠩࡠࠤࠥࡡࠧሱ")+str(title)+l1l1ll_l1_ (u"ࠪࡡ࡛ࠥࠦࠨሲ")+str(l11ll1l1_l1_)+l1l1ll_l1_ (u"ࠫࡢ࠭ሳ"))
			if server.isdigit():
				link = hostname+l1l1ll_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨሴ")+id+l1l1ll_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪስ")+server+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨሶ")+title+l1l1ll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩሷ")+l11ll1l1_l1_
			else:
				if l1l1ll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧሸ") not in server: server = l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩሹ")+server
				l11ll1l1_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬሺ"),title,re.DOTALL)
				if l11ll1l1_l1_: l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠬࡥ࡟ࡠࡡࠪሻ")+l11ll1l1_l1_[0]
				else: l11ll1l1_l1_ = l1l1ll_l1_ (u"࠭ࠧሼ")
				link = server+l1l1ll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨሽ")+l11ll1l1_l1_
			l11l1_l1_.append(link)
	#LOG_THIS(l1l1ll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨሾ"),l1l1ll_l1_ (u"ࠩ࡞ࠫሿ")+l11ll1l1_l1_+l1l1ll_l1_ (u"ࠪࡡࠥࠦࠠࠡ࡝ࠪቀ")+title+l1l1ll_l1_ (u"ࠫࡢ࠭ቁ"))
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪቂ"), l11l1_l1_)
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧቃ"),l1l1ll_l1_ (u"ࠧࠨቄ"),l1l1ll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠠ࠲ࠩቅ"),	str(len(items)))
	if l1l1ll_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧቆ") in html:
		headers2 = { l1l1ll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩቇ"):l1l1ll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫቈ") }
		url2 = url+l1l1ll_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨ቉")
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"࠭ࡇࡆࡖࠪቊ"),url2,l1l1ll_l1_ (u"ࠧࠨቋ"),headers2,True,l1l1ll_l1_ (u"ࠨࠩቌ"),l1l1ll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ቍ"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ቎"))
		#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬ቏"),l1l1ll_l1_ (u"ࠬ࠭ቐ"),url2,l1l11ll1_l1_)
		l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧቑ"),l1l11ll1_l1_,re.DOTALL)
		for block in l1lll11_l1_:
			items = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩቒ"),block,re.DOTALL)
			for link,name,l11ll1l1_l1_ in items:
				link = link+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩቓ")+name+l1l1ll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ቔ")+l1l1ll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨቕ")+l11ll1l1_l1_
				l11l1_l1_.append(link)
	elif l1l1ll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨቖ") in html:
		headers2 = { l1l1ll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ቗"):l1l1ll_l1_ (u"࠭ࠧቘ") , l1l1ll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ቙"):l1l1ll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩቚ") }
		url2 = hostname + l1l1ll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬቛ")+id
		response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧቜ"),url2,l1l1ll_l1_ (u"ࠫࠬቝ"),headers2,True,True,l1l1ll_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ቞"))
		l1l11ll1_l1_ = response.content#.encode(l1l1ll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ቟"))
		if l1l1ll_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧበ") in l1l11ll1_l1_:
			l111ll1ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧቡ"),l1l11ll1_l1_,re.DOTALL)
			for url3 in l111ll1ll_l1_:
				if l1l1ll_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩቢ") not in url3 and l1l1ll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨባ") in url3:
					url3 = url3+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨቤ")
					l11l1_l1_.append(url3)
				elif l1l1ll_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬብ") in url3:
					l11ll1l1_l1_ = l1l1ll_l1_ (u"࠭ࠧቦ")
					response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠧࡈࡇࡗࠫቧ"),url3,l1l1ll_l1_ (u"ࠨࠩቨ"),headers,True,True,l1l1ll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ቩ"))
					l11l11111_l1_ = response.content#.encode(l1l1ll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨቪ"))
					l1l1l11_l1_ = re.findall(l1l1ll_l1_ (u"ࠫ࠭ࡂࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࠬ࠱࠲࠳࠭࠮ࠩቫ"),l11l11111_l1_,re.DOTALL)
					for l11l1ll1l_l1_ in l1l1l11_l1_:
						l11l111l1_l1_ = l1l1ll_l1_ (u"ࠬ࠭ቬ")
						l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨቭ"),l11l1ll1l_l1_,re.DOTALL)
						for l11l11lll_l1_ in l111ll111_l1_:
							item = re.findall(l1l1ll_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨቮ"),l11l11lll_l1_,re.DOTALL)
							if item:
								l11ll1l1_l1_ = l1l1ll_l1_ (u"ࠨࡡࡢࡣࡤ࠭ቯ")+item[0]
								break
						for l11l11lll_l1_ in reversed(l111ll111_l1_):
							item = re.findall(l1l1ll_l1_ (u"ࠩ࡟ࡻࡡࡽࠫࠨተ"),l11l11lll_l1_,re.DOTALL)
							if item:
								l11l111l1_l1_ = item[0]
								break
						l111l1lll_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩቱ"),l11l1ll1l_l1_,re.DOTALL)
						for l11l11l11_l1_ in l111l1lll_l1_:
							l11l11l11_l1_ = l11l11l11_l1_+l1l1ll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬቲ")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩታ")+l11ll1l1_l1_
							l11l1_l1_.append(l11l11l11_l1_)
			#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧቴ"),l1l1ll_l1_ (u"ࠧࠨት"),l1l1ll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬቶ"),	str(len(l11l1_l1_))	)
		elif l1l1ll_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧቷ") in l1l11ll1_l1_:
			l1l11ll1_l1_ = l1l11ll1_l1_.replace(l1l1ll_l1_ (u"ࠪࡀ࡭࠼ࠠࠨቸ"),l1l1ll_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨቹ"))+l1l1ll_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ቺ")
			l1l11ll1_l1_ = l1l11ll1_l1_.replace(l1l1ll_l1_ (u"࠭࠼ࡩ࠵ࠣࠫቻ"),l1l1ll_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫቼ"))+l1l1ll_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩች")
			#LOG_THIS(l1l1ll_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩቾ"),l1l11ll1_l1_)
			#open(l1l1ll_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪቿ"),l1l1ll_l1_ (u"ࠫࡼ࠭ኀ")).write(l1l11ll1_l1_)
			l111ll11l_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ኁ"),l1l11ll1_l1_,re.DOTALL)
			if l111ll11l_l1_:
				for l11l1ll1l_l1_ in l111ll11l_l1_:
					if l1l1ll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬኂ") not in l11l1ll1l_l1_: continue
					#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨኃ"),l1l1ll_l1_ (u"ࠨࠩኄ"),l1l1ll_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࠶࠷࠱ࠨኅ"),	l11l1ll1l_l1_	)
					l11l1l111_l1_ = l1l1ll_l1_ (u"ࠪࠫኆ")
					l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኇ"),l11l1ll1l_l1_,re.DOTALL)
					for l11l11lll_l1_ in l111ll111_l1_:
						item = re.findall(l1l1ll_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ኈ"),l11l11lll_l1_,re.DOTALL)
						if item:
							l11l1l111_l1_ = l1l1ll_l1_ (u"࠭࡟ࡠࡡࡢࠫ኉")+item[0]
							break
					l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ኊ"),l11l1ll1l_l1_,re.DOTALL)
					if l111ll111_l1_:
						for l11l111l1_l1_,l11l111ll_l1_ in l111ll111_l1_:
							l11l111ll_l1_ = l11l111ll_l1_+l1l1ll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩኋ")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ኌ")+l11l1l111_l1_
							l11l1_l1_.append(l11l111ll_l1_)
					else:
						l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኍ"),l11l1ll1l_l1_,re.DOTALL)
						for l11l111ll_l1_,l11l111l1_l1_ in l111ll111_l1_:
							l11l111ll_l1_ = l11l111ll_l1_.strip(l1l1ll_l1_ (u"ࠫࠥ࠭኎"))+l1l1ll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭኏")+l11l111l1_l1_+l1l1ll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪነ")+l11l1l111_l1_
							l11l1_l1_.append(l11l111ll_l1_)
			else:
				l111ll111_l1_ = re.findall(l1l1ll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫࡠࡼ࠱ࠩ࠽ࠩኑ"),l1l11ll1_l1_,re.DOTALL)
				for l11l111ll_l1_,l11l111l1_l1_ in l111ll111_l1_:
					l11l111ll_l1_ = l11l111ll_l1_.strip(l1l1ll_l1_ (u"ࠨࠢࠪኒ"))+l1l1ll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪና")+l11l111l1_l1_+l1l1ll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧኔ")
					l11l1_l1_.append(l11l111ll_l1_)
	#selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩን"), l11l1_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l11l1_l1_,script_name,l1l1ll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫኖ"),url)
	return
def SEARCH(search):
	search,options,showDialogs = SEARCH_OPTIONS(search)
	if search==l1l1ll_l1_ (u"࠭ࠧኗ"): search = OPEN_KEYBOARD()
	if search==l1l1ll_l1_ (u"ࠧࠨኘ"): return
	search = search.replace(l1l1ll_l1_ (u"ࠨࠢࠪኙ"),l1l1ll_l1_ (u"ࠩ࠮ࠫኚ"))
	response = OPENURL_REQUESTS_CACHED(l11l1ll_l1_,l1l1ll_l1_ (u"ࠪࡋࡊ࡚ࠧኛ"),l1l1l1_l1_+l1l1ll_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩኜ"),l1l1ll_l1_ (u"ࠬ࠭ኝ"),headers,True,l1l1ll_l1_ (u"࠭ࠧኞ"),l1l1ll_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ኟ"))
	html = response.content#.encode(l1l1ll_l1_ (u"ࠨࡷࡷࡪ࠽࠭አ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧኡ"),html,re.DOTALL)
	if showDialogs and l1lll11_l1_:
		block = l1lll11_l1_[0]
		items = re.findall(l1l1ll_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ኢ"),block,re.DOTALL)
		l11l1l11l_l1_,l11l1111l_l1_ = [],[]
		for category,title in items:
			#if title in [l1l1ll_l1_ (u"ࠫึ๐วืหࠣ์๋ࠥีศำ฼๋ࠬኣ")]: continue
			l11l1l11l_l1_.append(category)
			l11l1111l_l1_.append(title)
		selection = DIALOG_SELECT(l1l1ll_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬኤ"), l11l1111l_l1_)
		if selection == -1 : return
		category = l11l1l11l_l1_[selection]
	else: category = l1l1ll_l1_ (u"࠭ࠧእ")
	url = l1l1l1_l1_ + l1l1ll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫኦ")+search+l1l1ll_l1_ (u"ࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬኧ")+category+l1l1ll_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾࠳ࠪከ")
	l11l1l_l1_(url)
	return
def l111l11_l1_(url,filter):
	#filter = filter.replace(l1l1ll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬኩ"),l1l1ll_l1_ (u"ࠫࠬኪ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠬ࠭ካ"),l1l1ll_l1_ (u"࠭ࠧኬ"),filter,url)
	# for l111lll1l_l1_ filter:		l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪክ"),l1l1ll_l1_ (u"ࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧኮ"),l1l1ll_l1_ (u"ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩኯ"),l1l1ll_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬኰ")]
	l1ll1111_l1_ = [l1l1ll_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭኱"),l1l1ll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫኲ"),l1l1ll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬኳ"),l1l1ll_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨኴ")]
	if l1l1ll_l1_ (u"ࠨࡁࠪኵ") in url: url = url.split(l1l1ll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭኶"))[0]
	type,filter = filter.split(l1l1ll_l1_ (u"ࠪࡣࡤࡥࠧ኷"),1)
	if filter==l1l1ll_l1_ (u"ࠫࠬኸ"): l1l1lll1_l1_,l1l1ll1l_l1_ = l1l1ll_l1_ (u"ࠬ࠭ኹ"),l1l1ll_l1_ (u"࠭ࠧኺ")
	else: l1l1lll1_l1_,l1l1ll1l_l1_ = filter.split(l1l1ll_l1_ (u"ࠧࡠࡡࡢࠫኻ"))
	if type==l1l1ll_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬኼ"):
		if l1ll1111_l1_[0]+l1l1ll_l1_ (u"ࠩࡀࠫኽ") not in l1l1lll1_l1_: category = l1ll1111_l1_[0]
		for i in range(len(l1ll1111_l1_[0:-1])):
			if l1ll1111_l1_[i]+l1l1ll_l1_ (u"ࠪࡁࠬኾ") in l1l1lll1_l1_: category = l1ll1111_l1_[i+1]
		l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠫࠫ࠭኿")+category+l1l1ll_l1_ (u"ࠬࡃ࠰ࠨዀ")
		l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"࠭ࠦࠨ዁")+category+l1l1ll_l1_ (u"ࠧ࠾࠲ࠪዂ")
		l1ll11l1_l1_ = l1llll11_l1_.strip(l1l1ll_l1_ (u"ࠨࠨࠪዃ"))+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭ዄ")+l1lll111_l1_.strip(l1l1ll_l1_ (u"ࠪࠪࠬዅ"))
		l1l1l1l1_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ዆"))
		url2 = url+l1l1ll_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩ዇")+l1l1l1l1_l1_
	elif type==l1l1ll_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧወ"):
		l1l11l1l_l1_ = l1l1l1ll_l1_(l1l1lll1_l1_,l1l1ll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩዉ"))
		l1l11l1l_l1_ = UNQUOTE(l1l11l1l_l1_)
		if l1l1ll1l_l1_!=l1l1ll_l1_ (u"ࠨࠩዊ"): l1l1ll1l_l1_ = l1l1l1ll_l1_(l1l1ll1l_l1_,l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬዋ"))
		if l1l1ll1l_l1_==l1l1ll_l1_ (u"ࠪࠫዌ"): url2 = url
		else: url2 = url+l1l1ll_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨው")+l1l1ll1l_l1_
		addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዎ"),menu_name+l1l1ll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩዏ"),url2,201)
		addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዐ"),menu_name+l1l1ll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨዑ")+l1l11l1l_l1_+l1l1ll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨዒ"),url2,201)
		addMenuItem(l1l1ll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨዓ"),l1l1ll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫዔ"),l1l1ll_l1_ (u"ࠬ࠭ዕ"),9999)
	html = OPENURL_CACHED(l11l1ll_l1_,url+l1l1ll_l1_ (u"࠭࠯ࡢ࡮ࡽࠫዖ"),l1l1ll_l1_ (u"ࠧࠨ዗"),headers,l1l1ll_l1_ (u"ࠨࠩዘ"),l1l1ll_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧዙ"))
	l1lll11_l1_ = re.findall(l1l1ll_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨዚ"),html,re.DOTALL)
	block = l1lll11_l1_[0]
	# for l111lll1l_l1_ filter:		l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪዛ"),block,re.DOTALL)
	l1111ll_l1_ = re.findall(l1l1ll_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡩࡳࡷ࡚ࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫዜ"),block,re.DOTALL)
	#DIALOG_OK(l1l1ll_l1_ (u"࠭ࠧዝ"),l1l1ll_l1_ (u"ࠧࠨዞ"),l1l1ll_l1_ (u"ࠨࠩዟ"),str(l1111ll_l1_))
	dict = {}
	for name,l11111l_l1_,block in l1111ll_l1_:
		#name = name.replace(l1l1ll_l1_ (u"ࠩ࠰࠱ࠬዠ"),l1l1ll_l1_ (u"ࠪࠫዡ"))
		name = name.replace(l1l1ll_l1_ (u"ࠫฬิส๋ษิࠤࠬዢ"),l1l1ll_l1_ (u"ࠬ࠭ዣ"))
		name = name.replace(l1l1ll_l1_ (u"࠭ำ็หࠣห้หๆหษฯࠫዤ"),l1l1ll_l1_ (u"ࠧศๆึ๊ฮ࠭ዥ"))
		items = re.findall(l1l1ll_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩዦ"),block,re.DOTALL)
		if l1l1ll_l1_ (u"ࠩࡀࠫዧ") not in url2: url2 = url
		if type==l1l1ll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧየ"):
			if category!=l11111l_l1_: continue
			elif len(items)<=1:
				if l11111l_l1_==l1ll1111_l1_[-1]: l11l1l_l1_(url2)
				else: l111l11_l1_(url2,l1l1ll_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫዩ")+l1ll11l1_l1_)
				return
			else:
				if l11111l_l1_==l1ll1111_l1_[-1]: addMenuItem(l1l1ll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዪ"),menu_name+l1l1ll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧያ"),url2,201)
				else: addMenuItem(l1l1ll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዬ"),menu_name+l1l1ll_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩይ"),url2,205,l1l1ll_l1_ (u"ࠩࠪዮ"),l1l1ll_l1_ (u"ࠪࠫዯ"),l1ll11l1_l1_)
		elif type==l1l1ll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬደ"):
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠬࠬࠧዱ")+l11111l_l1_+l1l1ll_l1_ (u"࠭࠽࠱ࠩዲ")
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠧࠧࠩዳ")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿࠳ࠫዴ")
			l1ll11l1_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠩࡢࡣࡤ࠭ድ")+l1lll111_l1_
			addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዶ"),menu_name+l1l1ll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ዷ")+name,url2,204,l1l1ll_l1_ (u"ࠬ࠭ዸ"),l1l1ll_l1_ (u"࠭ࠧዹ"),l1ll11l1_l1_)		# +l1l1ll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩዺ"))
		dict[l11111l_l1_] = {}
		for value,option in items:
			option = option.replace(l1l1ll_l1_ (u"ࠨ࡞ࡱࠫዻ"),l1l1ll_l1_ (u"ࠩࠪዼ"))
			if option in l1ll11_l1_: continue
			#if option==l1l1ll_l1_ (u"ࠪห้้ไࠨዽ"): continue
			#option = l1l1ll_l1_ (u"ࠫࡠ࠭ዾ")+option+l1l1ll_l1_ (u"ࠬࡣࠧዿ")
			#if l1l1ll_l1_ (u"࠭วๅๅ็ࠫጀ") in option: DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨጁ"),l1l1ll_l1_ (u"ࠨࠩጂ"),l1l1ll_l1_ (u"ࠩࠪጃ"),l1l1ll_l1_ (u"ࠪ࡟ࠬጄ")+str(option)+l1l1ll_l1_ (u"ࠫࡢ࠭ጅ"))
			#if l1l1ll_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫጆ") not in value: value = option
			#else: value = re.findall(l1l1ll_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧጇ"),value,re.DOTALL)[0]
			dict[l11111l_l1_][value] = option
			l1llll11_l1_ = l1l1lll1_l1_+l1l1ll_l1_ (u"ࠧࠧࠩገ")+l11111l_l1_+l1l1ll_l1_ (u"ࠨ࠿ࠪጉ")+option
			l1lll111_l1_ = l1l1ll1l_l1_+l1l1ll_l1_ (u"ࠩࠩࠫጊ")+l11111l_l1_+l1l1ll_l1_ (u"ࠪࡁࠬጋ")+value
			l111111_l1_ = l1llll11_l1_+l1l1ll_l1_ (u"ࠫࡤࡥ࡟ࠨጌ")+l1lll111_l1_
			title = option+l1l1ll_l1_ (u"ࠬࠦ࠺ࠨግ")#+dict[l11111l_l1_][l1l1ll_l1_ (u"࠭࠰ࠨጎ")]
			title = option+l1l1ll_l1_ (u"ࠧࠡ࠼ࠪጏ")+name
			if type==l1l1ll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩጐ"): addMenuItem(l1l1ll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ጑"),menu_name+title,url,204,l1l1ll_l1_ (u"ࠪࠫጒ"),l1l1ll_l1_ (u"ࠫࠬጓ"),l111111_l1_)		# +l1l1ll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧጔ"))
			elif type==l1l1ll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪጕ") and l1ll1111_l1_[-2]+l1l1ll_l1_ (u"ࠧ࠾ࠩ጖") in l1l1lll1_l1_:
				l1l1l1l1_l1_ = l1l1l1ll_l1_(l1lll111_l1_,l1l1ll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ጗"))
				url3 = url+l1l1ll_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ጘ")+l1l1l1l1_l1_
				addMenuItem(l1l1ll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጙ"),menu_name+title,url3,201)
			else: addMenuItem(l1l1ll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጚ"),menu_name+title,url,205,l1l1ll_l1_ (u"ࠬ࠭ጛ"),l1l1ll_l1_ (u"࠭ࠧጜ"),l111111_l1_)
	return
def l1l1l1ll_l1_(filters,mode):
	#DIALOG_OK(l1l1ll_l1_ (u"ࠧࠨጝ"),l1l1ll_l1_ (u"ࠨࠩጞ"),filters,l1l1ll_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪጟ"))
	# mode==l1l1ll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬጠ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ values
	# mode==l1l1ll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧጡ")		l1lll1l1_l1_ l1ll1l11_l1_ l1ll1l1l_l1_ filters
	# mode==l1l1ll_l1_ (u"ࠬࡧ࡬࡭ࠩጢ")					all filters (l1l1l111_l1_ l1ll1l1l_l1_ filter)
	filters = filters.replace(l1l1ll_l1_ (u"࠭࠽ࠧࠩጣ"),l1l1ll_l1_ (u"ࠧ࠾࠲ࠩࠫጤ"))
	filters = filters.strip(l1l1ll_l1_ (u"ࠨࠨࠪጥ"))
	l1l1llll_l1_ = {}
	if l1l1ll_l1_ (u"ࠩࡀࠫጦ") in filters:
		items = filters.split(l1l1ll_l1_ (u"ࠪࠪࠬጧ"))
		for item in items:
			var,value = item.split(l1l1ll_l1_ (u"ࠫࡂ࠭ጨ"))
			l1l1llll_l1_[var] = value
	l1llllll_l1_ = l1l1ll_l1_ (u"ࠬ࠭ጩ")
	# for l111lll1l_l1_ filter:		l1llll1l_l1_ = [l1l1ll_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩጪ"),l1l1ll_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ጫ"),l1l1ll_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጬ"),l1l1ll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫጭ")]
	l1llll1l_l1_ = [l1l1ll_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬጮ"),l1l1ll_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪጯ"),l1l1ll_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫጰ"),l1l1ll_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧጱ")]
	for key in l1llll1l_l1_:
		if key in list(l1l1llll_l1_.keys()): value = l1l1llll_l1_[key]
		else: value = l1l1ll_l1_ (u"ࠧ࠱ࠩጲ")
		if l1l1ll_l1_ (u"ࠨࠧࠪጳ") not in value: value = QUOTE(value)
		if mode==l1l1ll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫጴ") and value!=l1l1ll_l1_ (u"ࠪ࠴ࠬጵ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠫࠥ࠱ࠠࠨጶ")+value
		elif mode==l1l1ll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨጷ") and value!=l1l1ll_l1_ (u"࠭࠰ࠨጸ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠧࠧࠩጹ")+key+l1l1ll_l1_ (u"ࠨ࠿ࠪጺ")+value
		elif mode==l1l1ll_l1_ (u"ࠩࡤࡰࡱ࠭ጻ"): l1llllll_l1_ = l1llllll_l1_+l1l1ll_l1_ (u"ࠪࠪࠬጼ")+key+l1l1ll_l1_ (u"ࠫࡂ࠭ጽ")+value
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"ࠬࠦࠫࠡࠩጾ"))
	l1llllll_l1_ = l1llllll_l1_.strip(l1l1ll_l1_ (u"࠭ࠦࠨጿ"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠧ࠾࠲ࠪፀ"),l1l1ll_l1_ (u"ࠨ࠿ࠪፁ"))
	l1llllll_l1_ = l1llllll_l1_.replace(l1l1ll_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪፂ"),l1l1ll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫፃ"))
	#DIALOG_OK(l1l1ll_l1_ (u"ࠫࠬፄ"),l1l1ll_l1_ (u"ࠬ࠭ፅ"),filters,l1l1ll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧፆ"))
	return l1llllll_l1_
l1l1ll_l1_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨፇ")
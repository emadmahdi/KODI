﻿# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'ALMAAREF'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_MRF_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def HYWukw3pL2oMzPK4(mode,url,text,vYpMA3CxgcyR4VZJh):
	if   mode==40: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==41: mL7BVKcSygkuoPbWlEF4YD = r9gtNWGzOuJvZE()
	elif mode==42: mL7BVKcSygkuoPbWlEF4YD = qe9hDHBjcC5Ty(text,vYpMA3CxgcyR4VZJh)
	elif mode==43: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==44: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(text,vYpMA3CxgcyR4VZJh)
	elif mode==49: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'البث الحي لقناة المعارف','',41)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',49)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	qe9hDHBjcC5Ty('','1')
	return
def ddDPQyO2mWsLgHKoVlBNJAiFI5n(sdZQpO06qbHwAGPz7LCgu4lToE,GbnZpCQANPj1mu6K9wXvgh4Tdk):
	search,sort,ZyKr3DFwP7a5zXb,qGsE8fdyFtUwBnu,nvwUQPl1JRHC3YTczS0aL2O6XKf5 = '',[],[],[],[]
	g5lf2u4DxNp8imnYevK,VUD7sIY6ZRa2Ny = p2gG9rDHAXb7lYPvcMTa(sdZQpO06qbHwAGPz7LCgu4lToE)
	for khB9dCpWm4qPMrXTjgONf0Z in list(VUD7sIY6ZRa2Ny.keys()):
		Y3YqSmycrIWksoH5N0MvC = VUD7sIY6ZRa2Ny[khB9dCpWm4qPMrXTjgONf0Z]
		if not Y3YqSmycrIWksoH5N0MvC: continue
		if   khB9dCpWm4qPMrXTjgONf0Z=='sort': sort = [Y3YqSmycrIWksoH5N0MvC]
		elif khB9dCpWm4qPMrXTjgONf0Z=='series': ZyKr3DFwP7a5zXb = [Y3YqSmycrIWksoH5N0MvC]
		elif khB9dCpWm4qPMrXTjgONf0Z=='search': search = Y3YqSmycrIWksoH5N0MvC
		elif khB9dCpWm4qPMrXTjgONf0Z=='category': qGsE8fdyFtUwBnu = [Y3YqSmycrIWksoH5N0MvC]
		elif khB9dCpWm4qPMrXTjgONf0Z=='specialist': nvwUQPl1JRHC3YTczS0aL2O6XKf5 = [Y3YqSmycrIWksoH5N0MvC]
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":qGsE8fdyFtUwBnu,"specialist":nvwUQPl1JRHC3YTczS0aL2O6XKf5,"series":ZyKr3DFwP7a5zXb,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(GbnZpCQANPj1mu6K9wXvgh4Tdk)}}
	import json as aYhFKJupNC2ATLlXDqjc1SV6
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = aYhFKJupNC2ATLlXDqjc1SV6.dumps(zAkbOyR9ZirYWxTwvMqouPLBjeQ20)
	wHiSfdBL1v9Kl3n5 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',wHiSfdBL1v9Kl3n5,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,'','','','ALMAAREF-REQUEST_DATA_PAGE-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	data = G8EwoDOyKShm1i0IHMfNYZlU7('dict',YBEsLq8gVw629cMGQP1T)
	return data
def qe9hDHBjcC5Ty(sdZQpO06qbHwAGPz7LCgu4lToE,level):
	Ns3LKUFY21aQVf7e = ddDPQyO2mWsLgHKoVlBNJAiFI5n(sdZQpO06qbHwAGPz7LCgu4lToE,'1')
	mvgk7pP8Fw6heMSWd5oXn9itl = Ns3LKUFY21aQVf7e['facets']
	if level=='1':
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl['video_categories']
		items = JJDtX1PZyIgN2T.findall('<div(.*?)/div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for KxB8vVHUJg in items:
			QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',KxB8vVHUJg+'<',JJDtX1PZyIgN2T.DOTALL)
			if not QF4KdRaN2q0: QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('data-value=\\"(.*?)\\">(.*?)<',KxB8vVHUJg+'<',JJDtX1PZyIgN2T.DOTALL)
			qGsE8fdyFtUwBnu,title = QF4KdRaN2q0[0]
			if not sdZQpO06qbHwAGPz7LCgu4lToE: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,'',42,'','2','?category='+qGsE8fdyFtUwBnu)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,'',42,'','2',sdZQpO06qbHwAGPz7LCgu4lToE+'&category='+qGsE8fdyFtUwBnu)
	if level=='2':
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl['specialist']
		items = JJDtX1PZyIgN2T.findall('value="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for nvwUQPl1JRHC3YTczS0aL2O6XKf5,title in items:
			if not nvwUQPl1JRHC3YTczS0aL2O6XKf5: title = title = 'الجميع'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,'',42,'','3',sdZQpO06qbHwAGPz7LCgu4lToE+'&specialist='+nvwUQPl1JRHC3YTczS0aL2O6XKf5)
	elif level=='3':
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl['series']
		items = JJDtX1PZyIgN2T.findall('value="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for ZyKr3DFwP7a5zXb,title in items:
			if not ZyKr3DFwP7a5zXb: title = title = 'الجميع'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,'',42,'','4',sdZQpO06qbHwAGPz7LCgu4lToE+'&series='+ZyKr3DFwP7a5zXb)
	elif level=='4':
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl['sort_video']
		items = JJDtX1PZyIgN2T.findall('value="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for sort,title in items:
			if not sort: continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,'',44,'','1',sdZQpO06qbHwAGPz7LCgu4lToE+'&sort='+sort)
	return
def d2JXnUMPmgsKBQqCE58lkZ(sdZQpO06qbHwAGPz7LCgu4lToE,GbnZpCQANPj1mu6K9wXvgh4Tdk):
	Ns3LKUFY21aQVf7e = ddDPQyO2mWsLgHKoVlBNJAiFI5n(sdZQpO06qbHwAGPz7LCgu4lToE,GbnZpCQANPj1mu6K9wXvgh4Tdk)
	mvgk7pP8Fw6heMSWd5oXn9itl = Ns3LKUFY21aQVf7e['template']
	items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,43,ggdRiBo3smurLUGO)
	mvgk7pP8Fw6heMSWd5oXn9itl = Ns3LKUFY21aQVf7e['facets']['pagination']
	items = JJDtX1PZyIgN2T.findall('data-page="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for vYpMA3CxgcyR4VZJh,title in items:
		if GbnZpCQANPj1mu6K9wXvgh4Tdk==vYpMA3CxgcyR4VZJh: continue
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,'',44,'',vYpMA3CxgcyR4VZJh,sdZQpO06qbHwAGPz7LCgu4lToE)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ALMAAREF-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<video src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('youtube_url.*?(http.*?)&',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	pB8XANf71vaPJsedkWVIc5 = []
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0].replace('\/','/')
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def r9gtNWGzOuJvZE():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH+'/بث-مباشر','','','','','ALMAAREF-LIVE-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	url = i35i6al7upCAreLFQ(items[0])
	XbzQHGJ0cBV(url,FpjtBKrnu5SdfyOvEPIQ,'live')
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	FZVQBJHS2oKywNunj8kemdW7YR5rT = False
	if search=='':
		search = GVfnMyZxiRI()
		FZVQBJHS2oKywNunj8kemdW7YR5rT = True
	if search=='': return
	if not FZVQBJHS2oKywNunj8kemdW7YR5rT: d2JXnUMPmgsKBQqCE58lkZ('?search='+search,'1')
	else: qe9hDHBjcC5Ty('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'CIMA4U'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_C4U_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==420: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==421: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==422: mL7BVKcSygkuoPbWlEF4YD = Rlz1ix3kDKZIbrjq7O(url)
	elif mode==423: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==424: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==427: mL7BVKcSygkuoPbWlEF4YD = LLjUb3OSnVJCfYH9vgEi5xh61G7tq(url)
	elif mode==429: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','CIMA4U-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = JJDtX1PZyIgN2T.findall('href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	PeArnUDVym1pjBFaG = PeArnUDVym1pjBFaG[0].strip('/')
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(PeArnUDVym1pjBFaG,'url')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',429,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',PeArnUDVym1pjBFaG,425)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',PeArnUDVym1pjBFaG,424)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الرئيسية',PeArnUDVym1pjBFaG,421)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('NavigationMenu(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="*(.*?)"*>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		if '/actors' in wHiSfdBL1v9Kl3n5: title = 'أفلام النجوم'
		elif '/netflix' in wHiSfdBL1v9Kl3n5: title = 'أفلام ومسلسلات نيتفلكس'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,421)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'قائمة تفصيلية',PeArnUDVym1pjBFaG,427)
	return
def LLjUb3OSnVJCfYH9vgEi5xh61G7tq(website=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','CIMA4U-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('FilteringTitle(.*?)PageTitle',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for qGsE8fdyFtUwBnu,id,wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		if 'netflix-movies' in wHiSfdBL1v9Kl3n5: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in wHiSfdBL1v9Kl3n5: title = 'مسلسلات نيتفلكس'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,421,'','',qGsE8fdyFtUwBnu+'|'+id)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,IOC7UWYc5MTHZbLx9VtXpn=''):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','CIMA4U-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if not IOC7UWYc5MTHZbLx9VtXpn or '|' in IOC7UWYc5MTHZbLx9VtXpn:
		if '|' not in IOC7UWYc5MTHZbLx9VtXpn: rWPtLOU6h9v = ''
		else: rWPtLOU6h9v = '/archive/'+IOC7UWYc5MTHZbLx9VtXpn
		trXfJN2hZ6joUOa = False
		if 'PinSlider' in YBEsLq8gVw629cMGQP1T:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',url,421,'','','featured')
			trXfJN2hZ6joUOa = True
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('PageTitle(.*?)PageContent',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			DqrOZE3L85G = GGbRgKaoskDC[0]
			uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('data-tab="(.*?)".*?<span>(.*?)<',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
			for rXmYR7kBG6j40wMQf8,LpB4ilMr6vVtQ in uaq5LNOdZJhV4fDwvcsnU17WrX:
				tb4p6sRlFPcio = PeArnUDVym1pjBFaG+'/ajaxcenter/action/HomepageLoader/tab/'+rXmYR7kBG6j40wMQf8+rWPtLOU6h9v+'/'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,tb4p6sRlFPcio,421)
				trXfJN2hZ6joUOa = True
		if trXfJN2hZ6joUOa: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if IOC7UWYc5MTHZbLx9VtXpn=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('PinSlider(.*?)MultiFilter',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('PinSlider(.*?)PageTitle',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		else: mvgk7pP8Fw6heMSWd5oXn9itl = ''
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
	elif '/filter/' in url:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('PageContent(.*?)class="*pagination"*',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	elif '/actors' in url:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('PageContent(.*?)class="*pagination"*',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('Cima4uBlocks(.*?)</li></ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		else: mvgk7pP8Fw6heMSWd5oXn9itl = ''
	if not items: items = JJDtX1PZyIgN2T.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if not items: items = JJDtX1PZyIgN2T.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if not title: continue
		if '?news=' in wHiSfdBL1v9Kl3n5: continue
		title = title.replace('مشاهدة ','')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) حلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
		if vaQbluYS4GEsKCNwOymT1hFt and 'حلقة' in title:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,422,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif '/actor/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,421,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,422,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('pagination(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC and IOC7UWYc5MTHZbLx9VtXpn!='featured':
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = title.replace('الصفحة ','')
			if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,421)
	cTeasj2fu6yr7YtVzBh = JJDtX1PZyIgN2T.findall('</li><a href="(.*?)".*?>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if cTeasj2fu6yr7YtVzBh:
		wHiSfdBL1v9Kl3n5,title = cTeasj2fu6yr7YtVzBh[0]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,421)
	return
def Rlz1ix3kDKZIbrjq7O(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMA4U-SEASONS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="WatchNow".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		url = GGbRgKaoskDC[0]
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMA4U-SEASONS-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('SeasonsSections(.*?)</div></div></div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if '/tag/' in url or '/actor' in url:
		d2JXnUMPmgsKBQqCE58lkZ(url)
	elif GGbRgKaoskDC:
		ggdRiBo3smurLUGO = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Thumb')
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall("href='(.*?)'>(.*?)<",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		y65nMAOZQUp2eYuR = ['مسلسل','موسم','برنامج','حلقة']
		for wHiSfdBL1v9Kl3n5,title in items:
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in y65nMAOZQUp2eYuR):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,423,ggdRiBo3smurLUGO)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,426,ggdRiBo3smurLUGO)
	else: sjmSkpqHVtPcv(url)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMA4U-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	ggdRiBo3smurLUGO = JJDtX1PZyIgN2T.findall('"background-image:url\((.*?)\)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO[0]
	else: ggdRiBo3smurLUGO = ''
	HqUnaLCQh9EVdI5NmBg = JJDtX1PZyIgN2T.findall('EpisodesSection(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if HqUnaLCQh9EVdI5NmBg:
		mvgk7pP8Fw6heMSWd5oXn9itl = HqUnaLCQh9EVdI5NmBg[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,vaQbluYS4GEsKCNwOymT1hFt in items:
			title = title+' '+vaQbluYS4GEsKCNwOymT1hFt
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,426,ggdRiBo3smurLUGO)
	else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+'رابط التشغيل',url,426,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','CIMA4U-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	iSIAPoKDpqsgcy9ntd8lRNMEZ0TzUQ = SSzrgUnfVGL1hQsu40FoP7CWXax.url
	if wIqFesTOvYnu5S2dWfpBVC: iSIAPoKDpqsgcy9ntd8lRNMEZ0TzUQ = iSIAPoKDpqsgcy9ntd8lRNMEZ0TzUQ.encode('utf8')
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(iSIAPoKDpqsgcy9ntd8lRNMEZ0TzUQ,'url')
	EEgFl59RndzrBL8TUoaQMw6P = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('WatchSection(.*?)</div></div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('data-link="(.*?)".*? />(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for mLZb7XU6gaE8,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): title = 'خاص '+title
			wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/structure/server.php?id='+mLZb7XU6gaE8+'?named='+title+'__watch'
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\r','')
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('DownloadServers(.*?)</div></div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*? />(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if 'myvid' in title.lower(): LpB4ilMr6vVtQ = '__خاص'
			else: LpB4ilMr6vVtQ = ''
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'+LpB4ilMr6vVtQ
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\r','')
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/Search?q='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
def LWTgVSqXyoz26Hi931Ks(url):
	if 'smartemadfilter' not in url: url = OfTKisDR0Lv(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMA4U-GET_FILTERS_BLOCKS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('MultiFilter(.*?)PageTitle',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return KKMpOd0rWFRNPtun5cgY6
def ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl):
	items = JJDtX1PZyIgN2T.findall('data-id="(.*?)".*?</div>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return items
def l4yQ95DNGZEUi6r2CKtVwc(url):
	wHGCED2fklopYyFzI = url.split('/smartemadfilter?')[0]
	i1TCt53bykSvPp8e = OfTKisDR0Lv(url,'url')
	url = url.replace(wHGCED2fklopYyFzI,i1TCt53bykSvPp8e)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
EhaSnsdMYV90pT = ['category','types','release-year']
d1GKRIraF3whePop87L4JjDZnEVB = ['Quality','release-year','types','category']
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global EhaSnsdMYV90pT
			EhaSnsdMYV90pT = EhaSnsdMYV90pT[1:]
		if EhaSnsdMYV90pT[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[0]
		for ggjo5zu7yCiIOhrb in range(len(EhaSnsdMYV90pT[0:-1])):
			if EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
	elif type=='ALL_ITEMS_FILTER':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+oju0BC1rJO
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,421,'','','filter')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,421,'','','filter')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KKMpOd0rWFRNPtun5cgY6 = LWTgVSqXyoz26Hi931Ks(url)
	dict = {}
	for name,mvgk7pP8Fw6heMSWd5oXn9itl,eYFHT1CfSqZK in KKMpOd0rWFRNPtun5cgY6:
		if '/category/' in url and eYFHT1CfSqZK=='category': continue
		name = name.replace('--','')
		items = ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='SPECIFIED_FILTER':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<2:
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]:
					url = l4yQ95DNGZEUi6r2CKtVwc(url)
					d2JXnUMPmgsKBQqCE58lkZ(url)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'SPECIFIED_FILTER___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,421,'','','filter')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,425,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='ALL_ITEMS_FILTER':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع :'+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,424,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if Y3YqSmycrIWksoH5N0MvC=='196533': khB9dCpWm4qPMrXTjgONf0Z = 'أفلام نيتفلكس'
			elif Y3YqSmycrIWksoH5N0MvC=='196531': khB9dCpWm4qPMrXTjgONf0Z = 'مسلسلات نيتفلكس'
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'#+dict[eYFHT1CfSqZK]['0']
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'+name
			if type=='ALL_ITEMS_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,424,'','',oy5AiZKfC86qITkYWL)
			elif type=='SPECIFIED_FILTER' and EhaSnsdMYV90pT[-2]+'=' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
				kHWT0XY2S6apruwxiB8FDl1 = url+'/smartemadfilter?'+ssnIblOr0uX
				kHWT0XY2S6apruwxiB8FDl1 = l4yQ95DNGZEUi6r2CKtVwc(kHWT0XY2S6apruwxiB8FDl1)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,421,'','','filter')
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,425,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.replace('=&','=0&')
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	for key in d1GKRIraF3whePop87L4JjDZnEVB:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.replace('=0','=')
	return P1yxuh7MAmvSRVqLZcW6tY3
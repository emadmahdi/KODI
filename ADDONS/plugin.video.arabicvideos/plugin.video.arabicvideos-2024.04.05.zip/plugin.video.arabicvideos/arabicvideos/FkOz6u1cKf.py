# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
import bs4 as wMIs2xGgAKYcz9jp3OemqN0Qu745h
FpjtBKrnu5SdfyOvEPIQ = 'ELCINEMA'
eMlwAzaLSj8ZEQ3txIGP = '_ELC_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
headers = {'Referer':kU2ZXSViB3wLANOz8bH}
eJzpdvc3KTust = []
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==510: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==511: mL7BVKcSygkuoPbWlEF4YD = qhvK60w4pdPalf(url)
	elif mode==512: mL7BVKcSygkuoPbWlEF4YD = kYWCta68O21A0X5v9IBGihMlLPxS7(url)
	elif mode==513: mL7BVKcSygkuoPbWlEF4YD = xw4XE2KrmlC8toivH9h6cOIQbBgA(url)
	elif mode==514: mL7BVKcSygkuoPbWlEF4YD = B9ZFNAOud0zatL(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: mL7BVKcSygkuoPbWlEF4YD = B9ZFNAOud0zatL(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: mL7BVKcSygkuoPbWlEF4YD = FaiefXNhMHLsB(text)
	elif mode==517: mL7BVKcSygkuoPbWlEF4YD = J6XZrcYLwjv(url)
	elif mode==518: mL7BVKcSygkuoPbWlEF4YD = AJed8O7rSVy6fW(url)
	elif mode==519: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	elif mode==520: mL7BVKcSygkuoPbWlEF4YD = GgZUyfd4E7uKjTQPV1seC2lhz(url)
	elif mode==521: mL7BVKcSygkuoPbWlEF4YD = jK0lNQO54Pk(url)
	elif mode==522: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==523: mL7BVKcSygkuoPbWlEF4YD = hPxvNwX9Q41ZjHn6ag8V(text)
	elif mode==524: mL7BVKcSygkuoPbWlEF4YD = JcE3h7AzbsOfVL()
	elif mode==525: mL7BVKcSygkuoPbWlEF4YD = c5PMKfy71HlYZNtqxOCUvjL69XeJ()
	elif mode==526: mL7BVKcSygkuoPbWlEF4YD = NEa9V34Zu8()
	elif mode==527: mL7BVKcSygkuoPbWlEF4YD = ZcFxfTWL76HzChPJIbwV2poUlS1()
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث بموسوعة السينما','',519)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'موسوعة الأعمال','',525)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'موسوعة الأشخاص','',526)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'موسوعة المصنفات','',527)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'موسوعة المنوعات','',524)
	return
def JcE3h7AzbsOfVL():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' فيديوهات - خاصة',kU2ZXSViB3wLANOz8bH+'/video',520)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فيديوهات - أحدث',kU2ZXSViB3wLANOz8bH+'/video/latest',521)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فيديوهات - أقدم',kU2ZXSViB3wLANOz8bH+'/video/oldest',521)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فيديوهات - أكثر مشاهدة',kU2ZXSViB3wLANOz8bH+'/video/views',521)
	return
def c5PMKfy71HlYZNtqxOCUvjL69XeJ():
	hhI19LBk4vUJ = kU2ZXSViB3wLANOz8bH+'/lineup?utf8=%E2%9C%93'
	XaIvUnhJ2YyHNPMFAx8Rkri = hhI19LBk4vUJ+'&type=2&category=1&foreign=false&tag='
	LKXijzMbC8dtAeqOvkfP1N = hhI19LBk4vUJ+'&type=2&category=3&foreign=false&tag='
	JC3qFgTe5xcofDMu2kSUHawQ4bzVm = hhI19LBk4vUJ+'&type=2&category=1&foreign=true&tag='
	DLxi1W3Ea5KFpdAThgBv = hhI19LBk4vUJ+'&type=2&category=3&foreign=true&tag='
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات أفلام عربي',XaIvUnhJ2YyHNPMFAx8Rkri,511)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات مسلسلات عربي',LKXijzMbC8dtAeqOvkfP1N,511)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات أفلام اجنبي',JC3qFgTe5xcofDMu2kSUHawQ4bzVm,511)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات مسلسلات اجنبي',DLxi1W3Ea5KFpdAThgBv,511)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس أعمال أبجدي',kU2ZXSViB3wLANOz8bH+'/index/work/alphabet',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس  بلد الإنتاج',kU2ZXSViB3wLANOz8bH+'/index/work/country',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس اللغة',kU2ZXSViB3wLANOz8bH+'/index/work/language',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس مصنفات العمل',kU2ZXSViB3wLANOz8bH+'/index/work/genre',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس سنة الإصدار',kU2ZXSViB3wLANOz8bH+'/index/work/release_year',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مواسم - فلتر محدد',kU2ZXSViB3wLANOz8bH+'/seasonals',515)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مواسم - فلتر كامل',kU2ZXSViB3wLANOz8bH+'/seasonals',514)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات - فلتر محدد',kU2ZXSViB3wLANOz8bH+'/lineup',515)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات - فلتر كامل',kU2ZXSViB3wLANOz8bH+'/lineup',514)
	return
def ZcFxfTWL76HzChPJIbwV2poUlS1():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH+'/lineup','',headers,'','','ELCINEMA-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	mvgk7pP8Fw6heMSWd5oXn9itl = SVW9vF5TGdaDoHn84s16LiN.find('select',attrs={'name':'tag'})
	sdZQpO06qbHwAGPz7LCgu4lToE = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('option')
	for khB9dCpWm4qPMrXTjgONf0Z in sdZQpO06qbHwAGPz7LCgu4lToE:
		Y3YqSmycrIWksoH5N0MvC = khB9dCpWm4qPMrXTjgONf0Z.get('value')
		if not Y3YqSmycrIWksoH5N0MvC: continue
		title = khB9dCpWm4qPMrXTjgONf0Z.text
		if wIqFesTOvYnu5S2dWfpBVC:
			title = title.encode('utf8')
			Y3YqSmycrIWksoH5N0MvC = Y3YqSmycrIWksoH5N0MvC.encode('utf8')
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+Y3YqSmycrIWksoH5N0MvC
		title = title.replace('قائمة ','')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,511)
	return
def NEa9V34Zu8():
	hhI19LBk4vUJ = kU2ZXSViB3wLANOz8bH+'/lineup?utf8=%E2%9C%93'
	sD4yj1euPOfNJkXB2V9xn3grFQpI5 = hhI19LBk4vUJ+'&type=1&category=&foreign=&tag='
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات أشخاص',sD4yj1euPOfNJkXB2V9xn3grFQpI5,511)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس أشخاص أبجدي',kU2ZXSViB3wLANOz8bH+'/index/person/alphabet',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس موطن',kU2ZXSViB3wLANOz8bH+'/index/person/nationality',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس  تاريخ الميلاد',kU2ZXSViB3wLANOz8bH+'/index/person/birth_year',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فهرس  تاريخ الوفاة',kU2ZXSViB3wLANOz8bH+'/index/person/death_year',517)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات - فلتر محدد',kU2ZXSViB3wLANOz8bH+'/lineup',515)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مصنفات - فلتر كامل',kU2ZXSViB3wLANOz8bH+'/lineup',514)
	return
def qhvK60w4pdPalf(url):
	if '/seasonals' in url: ZJfCEzd2DxAvbiYg = 0
	elif '/lineup' in url: ZJfCEzd2DxAvbiYg = 1
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-LISTS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	Ns3LKUFY21aQVf7e = SVW9vF5TGdaDoHn84s16LiN.find_all(class_='jumbo-theater clearfix')
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		title = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('a')[ZJfCEzd2DxAvbiYg].text
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+mvgk7pP8Fw6heMSWd5oXn9itl.find_all('a')[ZJfCEzd2DxAvbiYg].get('href')
		if wIqFesTOvYnu5S2dWfpBVC:
			title = title.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
		if not Ns3LKUFY21aQVf7e:
			kYWCta68O21A0X5v9IBGihMlLPxS7(wHiSfdBL1v9Kl3n5)
			return
		else:
			title = title.replace('قائمة ','')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,512)
	eqg21COva5Ew3Fs4(SVW9vF5TGdaDoHn84s16LiN,511)
	return
def eqg21COva5Ew3Fs4(SVW9vF5TGdaDoHn84s16LiN,mode):
	mvgk7pP8Fw6heMSWd5oXn9itl = SVW9vF5TGdaDoHn84s16LiN.find(class_='pagination')
	if mvgk7pP8Fw6heMSWd5oXn9itl:
		uudj12RoUgH0hxFs = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('a')
		ZafOoDM2h8Rcp6TSu5EAQsJv31 = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('li')
		RKxIMHY8oF67Q5lS = list(zip(uudj12RoUgH0hxFs,ZafOoDM2h8Rcp6TSu5EAQsJv31))
		uvTwHSmjyW6Vr0192IZ = -1
		nfgR1P5HLpqdvoUl2Z = len(RKxIMHY8oF67Q5lS)
		for zzMCtO8apGR3A5H9jL4wNulv0,cI7OZP4DyugT0lB1GdE6aM89sf in RKxIMHY8oF67Q5lS:
			uvTwHSmjyW6Vr0192IZ += 1
			cI7OZP4DyugT0lB1GdE6aM89sf = cI7OZP4DyugT0lB1GdE6aM89sf['class']
			if 'unavailable' in cI7OZP4DyugT0lB1GdE6aM89sf or 'current' in cI7OZP4DyugT0lB1GdE6aM89sf: continue
			XUj8uOQAJ6pBCitZ4Te = zzMCtO8apGR3A5H9jL4wNulv0.text
			tb4p6sRlFPcio = kU2ZXSViB3wLANOz8bH+zzMCtO8apGR3A5H9jL4wNulv0.get('href')
			if wIqFesTOvYnu5S2dWfpBVC:
				XUj8uOQAJ6pBCitZ4Te = XUj8uOQAJ6pBCitZ4Te.encode('utf8')
				tb4p6sRlFPcio = tb4p6sRlFPcio.encode('utf8')
			if   uvTwHSmjyW6Vr0192IZ==0: XUj8uOQAJ6pBCitZ4Te = 'أولى'
			elif uvTwHSmjyW6Vr0192IZ==1: XUj8uOQAJ6pBCitZ4Te = 'سابقة'
			elif uvTwHSmjyW6Vr0192IZ==nfgR1P5HLpqdvoUl2Z-2: XUj8uOQAJ6pBCitZ4Te = 'لاحقة'
			elif uvTwHSmjyW6Vr0192IZ==nfgR1P5HLpqdvoUl2Z-1: XUj8uOQAJ6pBCitZ4Te = 'أخيرة'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+XUj8uOQAJ6pBCitZ4Te,tb4p6sRlFPcio,mode)
	return
def kYWCta68O21A0X5v9IBGihMlLPxS7(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-TITLES1-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	Ns3LKUFY21aQVf7e = SVW9vF5TGdaDoHn84s16LiN.find_all(class_='row')
	items,xg3XfdNISH5la = [],True
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		if not mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='thumbnail-wrapper'): continue
		if xg3XfdNISH5la: xg3XfdNISH5la = False ; continue
		rV8YimU172HS = []
		azi69Z520FjA = mvgk7pP8Fw6heMSWd5oXn9itl.find_all(class_=['censorship red','censorship purple'])
		for PPvkEsNXqJW7p2gz13arD8 in azi69Z520FjA:
			xfwbmueq9Oy = PPvkEsNXqJW7p2gz13arD8.find_all('li')[1].text
			if wIqFesTOvYnu5S2dWfpBVC:
				xfwbmueq9Oy = xfwbmueq9Oy.encode('utf8')
			rV8YimU172HS.append(xfwbmueq9Oy)
		if not t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,'',rV8YimU172HS,False):
			UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('data-src')
			title = mvgk7pP8Fw6heMSWd5oXn9itl.find('h3')
			name = title.find('a').text
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+title.find('a').get('href')
			sJcVU7nvWBLib02lNFA3wz = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='no-margin')
			Hv3eyIctGxn8rJqVD9O = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='legend')
			if sJcVU7nvWBLib02lNFA3wz: sJcVU7nvWBLib02lNFA3wz = sJcVU7nvWBLib02lNFA3wz.text
			if Hv3eyIctGxn8rJqVD9O: Hv3eyIctGxn8rJqVD9O = Hv3eyIctGxn8rJqVD9O.text
			if wIqFesTOvYnu5S2dWfpBVC:
				UCjpzQwrZyNIe3kg1ThDvi0nb8 = UCjpzQwrZyNIe3kg1ThDvi0nb8.encode('utf8')
				name = name.encode('utf8')
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
				if sJcVU7nvWBLib02lNFA3wz: sJcVU7nvWBLib02lNFA3wz = sJcVU7nvWBLib02lNFA3wz.encode('utf8')
			WFJYy6c9CKV4rdh27NjtILZ5HgRv = {}
			if Hv3eyIctGxn8rJqVD9O: WFJYy6c9CKV4rdh27NjtILZ5HgRv['stars'] = Hv3eyIctGxn8rJqVD9O
			if sJcVU7nvWBLib02lNFA3wz:
				sJcVU7nvWBLib02lNFA3wz = sJcVU7nvWBLib02lNFA3wz.replace('\n',' .. ')
				WFJYy6c9CKV4rdh27NjtILZ5HgRv['plot'] = sJcVU7nvWBLib02lNFA3wz.replace('...اقرأ المزيد','')
			if '/work/' in wHiSfdBL1v9Kl3n5:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,516,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name,'',WFJYy6c9CKV4rdh27NjtILZ5HgRv)
			elif '/person/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,513,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name,'',WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	eqg21COva5Ew3Fs4(SVW9vF5TGdaDoHn84s16LiN,512)
	return
def xw4XE2KrmlC8toivH9h6cOIQbBgA(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-TITLES2-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	Ns3LKUFY21aQVf7e = SVW9vF5TGdaDoHn84s16LiN.find_all('li')
	UGN4yb8Wn9AitV,items = [],[]
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		if not mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='thumbnail-wrapper'): continue
		if not mvgk7pP8Fw6heMSWd5oXn9itl.find(class_=['unstyled','unstyled text-center']): continue
		if mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='hide'): continue
		title = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in UGN4yb8Wn9AitV: continue
		UGN4yb8Wn9AitV.append(name)
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+title.find('a').get('href')
		if '/search/work/' in url: UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('src')
		elif '/search/person/' in url: UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('data-src')
		elif '/search/video/' in url: UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('data-src')
		else: UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('src')
		if wIqFesTOvYnu5S2dWfpBVC:
			name = name.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
			UCjpzQwrZyNIe3kg1ThDvi0nb8 = UCjpzQwrZyNIe3kg1ThDvi0nb8.encode('utf8')
		name = name.strip(' ')
		items.append((name,wHiSfdBL1v9Kl3n5,UCjpzQwrZyNIe3kg1ThDvi0nb8))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,wHiSfdBL1v9Kl3n5,UCjpzQwrZyNIe3kg1ThDvi0nb8 in items:
		if '/search/video/' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,522,UCjpzQwrZyNIe3kg1ThDvi0nb8)
		elif '/search/person/' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,513,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,516,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name)
	return
def FaiefXNhMHLsB(text):
	text = text.replace('الإعلان','').replace('لفيلم','').replace('الرسمي','')
	text = text.replace('إعلان','').replace('فيلم','').replace('البرومو','')
	text = text.replace('التشويقي','').replace('لمسلسل','').replace('مسلسل','')
	text = text.replace(':','').replace(')','').replace('(','').replace(',','')
	text = text.replace('_','').replace(';','').replace('-','').replace('.','')
	text = text.replace('\'','').replace('\"','')
	text = text.replace('    ',' ').replace('   ',' ').replace('  ',' ')
	text = text.strip(' ')
	JLoq0Fe9PAw4d3 = text.count(' ')+1
	if JLoq0Fe9PAw4d3==1:
		hPxvNwX9Q41ZjHn6ag8V(text)
		return
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]','',9999)
	ty0WTzXe6fAV5JpoQLSO43lc = text.split(' ')
	gJtPvhce5lV2IQXonAyjNWs0M3ZkL = pow(2,JLoq0Fe9PAw4d3)
	JYrIPxwsZKy1Gh9BuDESQd28 = []
	def PF1gMu89tLrY5Wb0lE(LLmQteRh6ldTEK1D3joZpH5,RDszKtiMG7mA):
		if LLmQteRh6ldTEK1D3joZpH5=='1': return RDszKtiMG7mA
		return ''
	for uvTwHSmjyW6Vr0192IZ in range(gJtPvhce5lV2IQXonAyjNWs0M3ZkL,0,-1):
		WWx0odQmpuFarUbCnN5fqhz = list(JLoq0Fe9PAw4d3*'0'+bin(uvTwHSmjyW6Vr0192IZ)[2:])[-JLoq0Fe9PAw4d3:]
		WWx0odQmpuFarUbCnN5fqhz = reversed(WWx0odQmpuFarUbCnN5fqhz)
		o6olgEz21iJbqLsKhP = map(PF1gMu89tLrY5Wb0lE,WWx0odQmpuFarUbCnN5fqhz,ty0WTzXe6fAV5JpoQLSO43lc)
		title = ' '.join(filter(None,o6olgEz21iJbqLsKhP))
		if wIqFesTOvYnu5S2dWfpBVC: LpB4ilMr6vVtQ = title.decode('utf8')
		else: LpB4ilMr6vVtQ = title
		if len(LpB4ilMr6vVtQ)>2 and title not in JYrIPxwsZKy1Gh9BuDESQd28:
			JYrIPxwsZKy1Gh9BuDESQd28.append(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,'',523,'','',title)
	return
def hPxvNwX9Q41ZjHn6ag8V(ntTrG6PdEqsuh2Qeo):
	if wIqFesTOvYnu5S2dWfpBVC:
		ntTrG6PdEqsuh2Qeo = ntTrG6PdEqsuh2Qeo.decode('utf8')
		import arabic_reshaper as rW4sAbnEYf1TKVLNm5
		ntTrG6PdEqsuh2Qeo = rW4sAbnEYf1TKVLNm5.ArabicReshaper().reshape(ntTrG6PdEqsuh2Qeo)
		ntTrG6PdEqsuh2Qeo = Asxc8GDnudJm.get_display(ntTrG6PdEqsuh2Qeo)
	import ogWviPNB8U
	ntTrG6PdEqsuh2Qeo = GVfnMyZxiRI(default=ntTrG6PdEqsuh2Qeo)
	ogWviPNB8U.VH5hnQa7CPSR1tMlZ03Wpx8(ntTrG6PdEqsuh2Qeo)
	return
def J6XZrcYLwjv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-INDEXES_LISTS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	mvgk7pP8Fw6heMSWd5oXn9itl = SVW9vF5TGdaDoHn84s16LiN.find(class_='list-separator list-title')
	FsBtqKUQXgMGWxTyrinfhjOev1 = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('a')
	items = []
	for title in FsBtqKUQXgMGWxTyrinfhjOev1:
		name = title.text
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+title.get('href')
		if wIqFesTOvYnu5S2dWfpBVC:
			name = name.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
		if '#' not in wHiSfdBL1v9Kl3n5: items.append((name,wHiSfdBL1v9Kl3n5))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for KxB8vVHUJg in items:
		name,wHiSfdBL1v9Kl3n5 = KxB8vVHUJg
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,518)
	return
def AJed8O7rSVy6fW(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-INDEXES_TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	Ns3LKUFY21aQVf7e = SVW9vF5TGdaDoHn84s16LiN.find(class_='expand').find_all('tr')
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		wfGDSl6R9ZQtmV4uzCHK = mvgk7pP8Fw6heMSWd5oXn9itl.find_all('a')
		if not wfGDSl6R9ZQtmV4uzCHK: continue
		UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('data-src')
		name = wfGDSl6R9ZQtmV4uzCHK[1].text
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wfGDSl6R9ZQtmV4uzCHK[1].get('href')
		Hv3eyIctGxn8rJqVD9O = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='legend')
		if Hv3eyIctGxn8rJqVD9O: Hv3eyIctGxn8rJqVD9O = Hv3eyIctGxn8rJqVD9O.text
		if wIqFesTOvYnu5S2dWfpBVC:
			name = name.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
			UCjpzQwrZyNIe3kg1ThDvi0nb8 = UCjpzQwrZyNIe3kg1ThDvi0nb8.encode('utf8')
		WFJYy6c9CKV4rdh27NjtILZ5HgRv = {}
		if Hv3eyIctGxn8rJqVD9O: WFJYy6c9CKV4rdh27NjtILZ5HgRv['stars'] = Hv3eyIctGxn8rJqVD9O
		if '/work/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,516,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name,'',WFJYy6c9CKV4rdh27NjtILZ5HgRv)
		elif '/person/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name,wHiSfdBL1v9Kl3n5,513,UCjpzQwrZyNIe3kg1ThDvi0nb8,'',name,'',WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	eqg21COva5Ew3Fs4(SVW9vF5TGdaDoHn84s16LiN,518)
	return
def GgZUyfd4E7uKjTQPV1seC2lhz(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_LISTS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	FsBtqKUQXgMGWxTyrinfhjOev1 = SVW9vF5TGdaDoHn84s16LiN.find_all(class_='section-title inline')
	kwqYoF8han = SVW9vF5TGdaDoHn84s16LiN.find_all(class_='button green small right')
	items = zip(FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han)
	for title,wHiSfdBL1v9Kl3n5 in items:
		title = title.text
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5.get('href')
		if wIqFesTOvYnu5S2dWfpBVC:
			title = title.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
		title = title.replace('    ',' ').replace('   ',' ').replace('  ',' ')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,521)
	return
def jK0lNQO54Pk(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-VIDEOS_TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	IQ4haj6MmdFg = SVW9vF5TGdaDoHn84s16LiN.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	Ns3LKUFY21aQVf7e = IQ4haj6MmdFg.find_all('li')
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		title = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='title').text
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+mvgk7pP8Fw6heMSWd5oXn9itl.find('a').get('href')
		UCjpzQwrZyNIe3kg1ThDvi0nb8 = mvgk7pP8Fw6heMSWd5oXn9itl.find('img').get('data-src')
		hhCd56yES0cqfUKRsZaVI4wzWuTO = mvgk7pP8Fw6heMSWd5oXn9itl.find(class_='duration').text
		if wIqFesTOvYnu5S2dWfpBVC:
			title = title.encode('utf8')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
			UCjpzQwrZyNIe3kg1ThDvi0nb8 = UCjpzQwrZyNIe3kg1ThDvi0nb8.encode('utf8')
			hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.encode('utf8')
		hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace('\n','').strip(' ')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,522,UCjpzQwrZyNIe3kg1ThDvi0nb8,hhCd56yES0cqfUKRsZaVI4wzWuTO)
	eqg21COva5Ew3Fs4(SVW9vF5TGdaDoHn84s16LiN,521)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	wHiSfdBL1v9Kl3n5 = SVW9vF5TGdaDoHn84s16LiN.find(class_='flex-video').find('iframe').get('src')
	if wIqFesTOvYnu5S2dWfpBVC: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.encode('utf8')
	XbzQHGJ0cBV(wHiSfdBL1v9Kl3n5,FpjtBKrnu5SdfyOvEPIQ,'video')
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','%20')
	url = kU2ZXSViB3wLANOz8bH+'/search/?q='+search
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-SEARCH-1st')
	if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
		sD4yj1euPOfNJkXB2V9xn3grFQpI5 = kU2ZXSViB3wLANOz8bH+'/search_entity/?q='+search+'&entity=work'
		tb4p6sRlFPcio = kU2ZXSViB3wLANOz8bH+'/search_entity/?q='+search+'&entity=person'
		XnzGmgvPrC0e = kU2ZXSViB3wLANOz8bH+'/search_entity/?q='+search+'&entity=video'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن أعمال',sD4yj1euPOfNJkXB2V9xn3grFQpI5,513,'',search)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن أشخاص',tb4p6sRlFPcio,513,'',search)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن فيديوهات',XnzGmgvPrC0e,513,'',search)
		return
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	SVW9vF5TGdaDoHn84s16LiN = wMIs2xGgAKYcz9jp3OemqN0Qu745h.BeautifulSoup(YBEsLq8gVw629cMGQP1T,'html.parser',multi_valued_attributes=None)
	Ns3LKUFY21aQVf7e = SVW9vF5TGdaDoHn84s16LiN.find_all(class_='section-title left')
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		title = mvgk7pP8Fw6heMSWd5oXn9itl.text
		if wIqFesTOvYnu5S2dWfpBVC:
			title = title.encode('utf8')
		title = title.split('(',1)[0].strip(' ')
		if   'أعمال' in title: wHiSfdBL1v9Kl3n5 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: wHiSfdBL1v9Kl3n5 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: wHiSfdBL1v9Kl3n5 = url.replace('/search/','/search/video/')
		else: continue
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,513)
	return
def B9ZFNAOud0zatL(url,text):
	global EhaSnsdMYV90pT,d1GKRIraF3whePop87L4JjDZnEVB
	if '/seasonals' in url:
		EhaSnsdMYV90pT = ['seasonal','year','category']
		d1GKRIraF3whePop87L4JjDZnEVB = ['seasonal','year','category']
	elif '/lineup' in url:
		EhaSnsdMYV90pT = ['category','foreign','type']
		d1GKRIraF3whePop87L4JjDZnEVB = ['category','foreign','type']
	c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,text)
	return
def LWTgVSqXyoz26Hi931Ks(url):
	url = url.split('/smartemadfilter?')[0]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ELCINEMA-GET_FILTERS_BLOCKS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('form action="/(.*?)</form>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return KKMpOd0rWFRNPtun5cgY6
def ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl):
	items = JJDtX1PZyIgN2T.findall('<option value="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return items
def l4yQ95DNGZEUi6r2CKtVwc(url):
	wHGCED2fklopYyFzI = url.split('/smartemadfilter?')[0]
	i1TCt53bykSvPp8e = OfTKisDR0Lv(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def DdPr2kWCQfoI6yxNeqhTBcwvHJj3(VQZDwq9mu4jrB1gPlcWOxyF,url):
	ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'all_filters')
	kHWT0XY2S6apruwxiB8FDl1 = url+'/smartemadfilter?'+ssnIblOr0uX
	kHWT0XY2S6apruwxiB8FDl1 = l4yQ95DNGZEUi6r2CKtVwc(kHWT0XY2S6apruwxiB8FDl1)
	return kHWT0XY2S6apruwxiB8FDl1
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if EhaSnsdMYV90pT[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[0]
		for ggjo5zu7yCiIOhrb in range(len(EhaSnsdMYV90pT[0:-1])):
			if EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
	elif type=='ALL_ITEMS_FILTER':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+oju0BC1rJO
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,511)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,511)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KKMpOd0rWFRNPtun5cgY6 = LWTgVSqXyoz26Hi931Ks(url)
	dict = {}
	for name,eYFHT1CfSqZK,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		name = name.replace('--','')
		items = ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='SPECIFIED_FILTER':
			if eYFHT1CfSqZK not in EhaSnsdMYV90pT: continue
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<2:
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]:
					url = l4yQ95DNGZEUi6r2CKtVwc(url)
					kYWCta68O21A0X5v9IBGihMlLPxS7(url)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'SPECIFIED_FILTER___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,511)
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,515,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='ALL_ITEMS_FILTER':
			if eYFHT1CfSqZK not in d1GKRIraF3whePop87L4JjDZnEVB: continue
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع: '+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,514,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			if 'مصنفات أخرى' in khB9dCpWm4qPMrXTjgONf0Z: continue
			if 'الكل' in khB9dCpWm4qPMrXTjgONf0Z: continue
			if 'اللغة' in khB9dCpWm4qPMrXTjgONf0Z: continue
			khB9dCpWm4qPMrXTjgONf0Z = khB9dCpWm4qPMrXTjgONf0Z.replace('قائمة ','')
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			if name: title = khB9dCpWm4qPMrXTjgONf0Z+' :'+name
			else: title = khB9dCpWm4qPMrXTjgONf0Z
			if type=='ALL_ITEMS_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,514,'','',oy5AiZKfC86qITkYWL)
			elif type=='SPECIFIED_FILTER' and EhaSnsdMYV90pT[-2]+'=' in u7fXcTJNB8djwxR6yS:
				kHWT0XY2S6apruwxiB8FDl1 = DdPr2kWCQfoI6yxNeqhTBcwvHJj3(VQZDwq9mu4jrB1gPlcWOxyF,url)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,511)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,515,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.replace('=&','=0&')
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	for key in d1GKRIraF3whePop87L4JjDZnEVB:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all_filters': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.replace('=0','=')
	return P1yxuh7MAmvSRVqLZcW6tY3
EhaSnsdMYV90pT = []
d1GKRIraF3whePop87L4JjDZnEVB = []
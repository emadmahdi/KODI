# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SHOFHA'
eMlwAzaLSj8ZEQ3txIGP = '_SHT_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['الصفحة الرئيسية','Sign in','أفلام للكبار فقط']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==640: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==641: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==642: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==643: mL7BVKcSygkuoPbWlEF4YD = pbojWB3SLPFInweUh10sJlVrTvZ2qO(url,text)
	elif mode==644: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==645: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==649: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','SHOFHA-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',649,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('/category.php">(.*?)"navslide-divider"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("'dropdown-menu'(.*?)</ul>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for DqrOZE3L85G in GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace(DqrOZE3L85G,'')
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,644)
	return
def YsCotEfMBv03z7mg(url):
	opXJty4rUB9OZKvfAcVRFmjWuSa = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHOFHA-SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"caret"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vLlUHJTNWusr0IGRxY63gDPCet9:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('"presentation"','</ul>')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: GGbRgKaoskDC = [('',mvgk7pP8Fw6heMSWd5oXn9itl)]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for GKHP5BSEAIhp,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			opXJty4rUB9OZKvfAcVRFmjWuSa = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if GKHP5BSEAIhp: GKHP5BSEAIhp = GKHP5BSEAIhp+': '
			for wHiSfdBL1v9Kl3n5,title in opXJty4rUB9OZKvfAcVRFmjWuSa:
				title = GKHP5BSEAIhp+title
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,641)
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"pm-category-subcats"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ooTeU5chRPu:
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if len(uaq5LNOdZJhV4fDwvcsnU17WrX)<30:
			if opXJty4rUB9OZKvfAcVRFmjWuSa: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,641)
	if not vLlUHJTNWusr0IGRxY63gDPCet9 and not ooTeU5chRPu: d2JXnUMPmgsKBQqCE58lkZ(url)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,WAEqF7ZldrmL9Xw=''):
	if WAEqF7ZldrmL9Xw=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,headers,'','','SHOFHA-TITLES-1st')
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHOFHA-TITLES-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	mvgk7pP8Fw6heMSWd5oXn9itl,items = '',[]
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	if WAEqF7ZldrmL9Xw=='ajax-search':
		mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append(('',wHiSfdBL1v9Kl3n5,title))
	elif WAEqF7ZldrmL9Xw=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pm-video-watch-featured"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	elif WAEqF7ZldrmL9Xw=='new_episodes':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"row pm-ul-browse-videos(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	elif WAEqF7ZldrmL9Xw=='new_movies':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"row pm-ul-browse-videos(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if len(GGbRgKaoskDC)>1: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[1]
	elif WAEqF7ZldrmL9Xw=='featured_series':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append(('',wHiSfdBL1v9Kl3n5,title))
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(data-echo=".*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if mvgk7pP8Fw6heMSWd5oXn9itl and not items: items = JJDtX1PZyIgN2T.findall('data-echo="(.*?)".*?href="(.*?)">.*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if not items: return
	ClXwqHm0DEMvI39agWyiRYopQ = []
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|حلقة).\d+',title,JJDtX1PZyIgN2T.DOTALL)
		if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,642,ggdRiBo3smurLUGO)
		elif WAEqF7ZldrmL9Xw=='new_episodes':
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,642,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0][0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,645,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,645,ggdRiBo3smurLUGO)
	if 1:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if wHiSfdBL1v9Kl3n5=='#': continue
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/'+wHiSfdBL1v9Kl3n5.strip('/')
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,641)
	return
def pbojWB3SLPFInweUh10sJlVrTvZ2qO(url,IdKlfS10Z42nz6JDoCLapxrkHPFby):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHOFHA-EPISODES-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	UCjpzQwrZyNIe3kg1ThDvi0nb8 = JJDtX1PZyIgN2T.findall('"series-header".*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if UCjpzQwrZyNIe3kg1ThDvi0nb8: ggdRiBo3smurLUGO = UCjpzQwrZyNIe3kg1ThDvi0nb8[0]
	else: ggdRiBo3smurLUGO = ''
	items = []
	AA2Ja1TXUgsZOxp = False
	if vLlUHJTNWusr0IGRxY63gDPCet9 and not IdKlfS10Z42nz6JDoCLapxrkHPFby:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		items = JJDtX1PZyIgN2T.findall('data-serie="(.*?)">(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for IdKlfS10Z42nz6JDoCLapxrkHPFby,title in items:
			IdKlfS10Z42nz6JDoCLapxrkHPFby = IdKlfS10Z42nz6JDoCLapxrkHPFby.strip('#')
			if len(items)>1: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,645,ggdRiBo3smurLUGO,'',IdKlfS10Z42nz6JDoCLapxrkHPFby)
			else: AA2Ja1TXUgsZOxp = True
	else: AA2Ja1TXUgsZOxp = True
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"SeasonsEpisodesMain.*?data-serie="'+IdKlfS10Z42nz6JDoCLapxrkHPFby+'"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ooTeU5chRPu and AA2Ja1TXUgsZOxp:
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)"><span>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		items = []
		for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append((wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO))
		for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/'+wHiSfdBL1v9Kl3n5.strip('/')
			title = title.replace('</span><em>',' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,642,ggdRiBo3smurLUGO)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHOFHA-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	UCjpzQwrZyNIe3kg1ThDvi0nb8 = JJDtX1PZyIgN2T.findall('"og:image" content="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if UCjpzQwrZyNIe3kg1ThDvi0nb8: ggdRiBo3smurLUGO = UCjpzQwrZyNIe3kg1ThDvi0nb8[0]
	else: ggdRiBo3smurLUGO = ''
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('episodeNumber.*?</div>(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="eplist"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?><span>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if not items: items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.replace('</span><em>',' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,642,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P,tjI2D513v7Yiyk6PesSnobKEWJ,pB8XANf71vaPJsedkWVIc5 = [],[],[]
	if '/watch.php' in url: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('/watch.php','/view.php')
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','SHOFHA-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if 'embedded-video' in YBEsLq8gVw629cMGQP1T:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"embedded-video"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			kwqYoF8han = JJDtX1PZyIgN2T.findall('src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if kwqYoF8han:
				wHiSfdBL1v9Kl3n5 = kwqYoF8han[0]
				if wHiSfdBL1v9Kl3n5 not in EEgFl59RndzrBL8TUoaQMw6P:
					tjI2D513v7Yiyk6PesSnobKEWJ.append('?named=__embed')
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if 'WatchServers' in YBEsLq8gVw629cMGQP1T:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"WatchServers"(.*?)</script>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			ND4Pd9OtH2Mc = JJDtX1PZyIgN2T.findall('id="(.*?)".*?</span>(.*?)</button>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('\\"','"').replace('\/','/')
			kwqYoF8han = JJDtX1PZyIgN2T.findall('"<iframe.src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if len(ND4Pd9OtH2Mc)==len(kwqYoF8han):
				for id,title in ND4Pd9OtH2Mc:
					wHiSfdBL1v9Kl3n5 = kwqYoF8han[int(id)]
					if wHiSfdBL1v9Kl3n5 not in EEgFl59RndzrBL8TUoaQMw6P:
						tjI2D513v7Yiyk6PesSnobKEWJ.append('?named='+title+'__watch')
						EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if 'DownloadServer' in YBEsLq8gVw629cMGQP1T:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"DownloadServer"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			kwqYoF8han = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if not kwqYoF8han: kwqYoF8han = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
			for wHiSfdBL1v9Kl3n5,title in kwqYoF8han:
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
				if wHiSfdBL1v9Kl3n5 not in EEgFl59RndzrBL8TUoaQMw6P:
					tjI2D513v7Yiyk6PesSnobKEWJ.append('?named='+title+'__download')
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	v9c1sSyiJXU2lN7C = zip(EEgFl59RndzrBL8TUoaQMw6P,tjI2D513v7Yiyk6PesSnobKEWJ)
	for wHiSfdBL1v9Kl3n5,name in v9c1sSyiJXU2lN7C: pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+name)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/search.php?keywords='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
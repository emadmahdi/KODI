# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'AHWAK'
eMlwAzaLSj8ZEQ3txIGP = '_AHK_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['الصفحة الرئيسية','Sign in']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==610: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==611: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==612: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==613: mL7BVKcSygkuoPbWlEF4YD = b4bZyuJOX5AtajevVRd7UQgw9HfTL(url,text)
	elif mode==614: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==619: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','AHWAK-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',619,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المميزة',kU2ZXSViB3wLANOz8bH,611,'','','featured')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المسلسلات المميزة',kU2ZXSViB3wLANOz8bH,611,'','','featured_series')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('/category.php">(.*?)"navslide-divider"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("'dropdown-menu'(.*?)</ul>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for DqrOZE3L85G in GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace(DqrOZE3L85G,'')
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,614)
	return
def YsCotEfMBv03z7mg(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','AHWAK-SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"caret"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vLlUHJTNWusr0IGRxY63gDPCet9:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('"presentation"','</ul>')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: GGbRgKaoskDC = [('',mvgk7pP8Fw6heMSWd5oXn9itl)]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]','',9999)
		for GKHP5BSEAIhp,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if GKHP5BSEAIhp: GKHP5BSEAIhp = GKHP5BSEAIhp+': '
			for wHiSfdBL1v9Kl3n5,title in items:
				title = GKHP5BSEAIhp+title
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,611)
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"pm-category-subcats"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ooTeU5chRPu:
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if len(items)<30:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			for wHiSfdBL1v9Kl3n5,title in items:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,611)
	if not vLlUHJTNWusr0IGRxY63gDPCet9 and not ooTeU5chRPu: d2JXnUMPmgsKBQqCE58lkZ(url)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,WAEqF7ZldrmL9Xw=''):
	if WAEqF7ZldrmL9Xw=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,headers,'','','AHWAK-TITLES-1st')
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','AHWAK-TITLES-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	mvgk7pP8Fw6heMSWd5oXn9itl,items = '',[]
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	if WAEqF7ZldrmL9Xw=='ajax-search':
		mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append(('',wHiSfdBL1v9Kl3n5,title))
	elif WAEqF7ZldrmL9Xw=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pm-video-watch-featured"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	elif WAEqF7ZldrmL9Xw=='new_episodes':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"row pm-ul-browse-videos(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	elif WAEqF7ZldrmL9Xw=='new_movies':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"row pm-ul-browse-videos(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if len(GGbRgKaoskDC)>1: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[1]
	elif WAEqF7ZldrmL9Xw=='featured_series':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append(('',wHiSfdBL1v9Kl3n5,title))
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(data-echo=".*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if mvgk7pP8Fw6heMSWd5oXn9itl and not items: items = JJDtX1PZyIgN2T.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if not items: return
	ClXwqHm0DEMvI39agWyiRYopQ = []
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|حلقة).\d+',title,JJDtX1PZyIgN2T.DOTALL)
		if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,612,ggdRiBo3smurLUGO)
		elif WAEqF7ZldrmL9Xw=='new_episodes':
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,612,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0][0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,613,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,613,ggdRiBo3smurLUGO)
	if 1:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if wHiSfdBL1v9Kl3n5=='#': continue
				wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/'+wHiSfdBL1v9Kl3n5.strip('/')
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,611)
	return
def b4bZyuJOX5AtajevVRd7UQgw9HfTL(url,IdKlfS10Z42nz6JDoCLapxrkHPFby):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','AHWAK-EPISODES-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	UCjpzQwrZyNIe3kg1ThDvi0nb8 = JJDtX1PZyIgN2T.findall('preview_image_url: "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if UCjpzQwrZyNIe3kg1ThDvi0nb8: ggdRiBo3smurLUGO = UCjpzQwrZyNIe3kg1ThDvi0nb8[0]
	else: ggdRiBo3smurLUGO = ''
	items = []
	AA2Ja1TXUgsZOxp = False
	if vLlUHJTNWusr0IGRxY63gDPCet9 and not IdKlfS10Z42nz6JDoCLapxrkHPFby:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		items = JJDtX1PZyIgN2T.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for IdKlfS10Z42nz6JDoCLapxrkHPFby,title in items:
			IdKlfS10Z42nz6JDoCLapxrkHPFby = IdKlfS10Z42nz6JDoCLapxrkHPFby.strip('#')
			if len(items)>1: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,613,ggdRiBo3smurLUGO,'',IdKlfS10Z42nz6JDoCLapxrkHPFby)
			else: AA2Ja1TXUgsZOxp = True
	else: AA2Ja1TXUgsZOxp = True
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('id="'+IdKlfS10Z42nz6JDoCLapxrkHPFby+'"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ooTeU5chRPu and AA2Ja1TXUgsZOxp:
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('''title=["'](.*?)["'].*?href=['"](.*?)['"]''',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		items = []
		for title,wHiSfdBL1v9Kl3n5 in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append((wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO))
		if not items: items = JJDtX1PZyIgN2T.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
			wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/'+wHiSfdBL1v9Kl3n5.strip('/')
			title = title.replace('</em><span>',' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,612,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	EEgFl59RndzrBL8TUoaQMw6P = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','AHWAK-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('id="player".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	EvutnH6GVfdhAk10g = wHiSfdBL1v9Kl3n5.split('post=')[1]
	EvutnH6GVfdhAk10g = gPSZVjJHKIL.b64decode(EvutnH6GVfdhAk10g)
	if DQfHadYvTpy1UR: EvutnH6GVfdhAk10g = EvutnH6GVfdhAk10g.decode('utf8')
	EvutnH6GVfdhAk10g = G8EwoDOyKShm1i0IHMfNYZlU7('dict',EvutnH6GVfdhAk10g)
	kwqYoF8han = EvutnH6GVfdhAk10g['servers']
	FsBtqKUQXgMGWxTyrinfhjOev1 = list(kwqYoF8han.keys())
	kwqYoF8han = list(kwqYoF8han.values())
	v9c1sSyiJXU2lN7C = zip(FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han)
	for title,wHiSfdBL1v9Kl3n5 in v9c1sSyiJXU2lN7C:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/search.php?keywords='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
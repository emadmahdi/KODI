# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'FASELHD1'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_FH1_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['جوائز الأوسكار','المراجعات','wwe']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==570: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==571: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==572: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==573: mL7BVKcSygkuoPbWlEF4YD = gaJo6Sm8HMP2jKrnBd(url,text)
	elif mode==576: mL7BVKcSygkuoPbWlEF4YD = ljOmp1dtMV()
	elif mode==579: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'لماذا الموقع بطيء','',576)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	PeArnUDVym1pjBFaG,url,SSzrgUnfVGL1hQsu40FoP7CWXax = h7px9MIDvPwgZ2U6CNbT(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'faselhd1','فاصل إعلاني','dubbed-movies')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع',PeArnUDVym1pjBFaG,579,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',PeArnUDVym1pjBFaG,571,'','','featured1')
	items = JJDtX1PZyIgN2T.findall('class="h3">(.*?)<.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not items:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع فاصل الأول','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	for title,wHiSfdBL1v9Kl3n5 in items:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,571,'','','details1')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"menu-primary"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		GH0TktKp6SyxN = JJDtX1PZyIgN2T.findall('<li (.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		bCHVX9Pz8QU3f4A = ['','أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		uvTwHSmjyW6Vr0192IZ = 0
		for D2DlJjSYIrn in GH0TktKp6SyxN:
			if uvTwHSmjyW6Vr0192IZ>0: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',D2DlJjSYIrn,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if wHiSfdBL1v9Kl3n5=='#': continue
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
				if title=='': continue
				if any(Y3YqSmycrIWksoH5N0MvC in title.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
				title = bCHVX9Pz8QU3f4A[uvTwHSmjyW6Vr0192IZ]+title
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,571,'','','details2')
			uvTwHSmjyW6Vr0192IZ += 1
	return
def ljOmp1dtMV():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','FASELHD1-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('class="h4">(.*?)</div>(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not ooTeU5chRPu: return
	if type=='filters':
		GGbRgKaoskDC = [YBEsLq8gVw629cMGQP1T.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"homeSlide"(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		jYCTd4vkXDP,kwqYoF8han,FsBtqKUQXgMGWxTyrinfhjOev1 = zip(*items)
		items = zip(kwqYoF8han,jYCTd4vkXDP,FsBtqKUQXgMGWxTyrinfhjOev1)
	elif type=='featured2':
		title,mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	elif type=='details2' and len(ooTeU5chRPu)>1:
		title = ooTeU5chRPu[0][0]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,571,'','','featured2')
		title = ooTeU5chRPu[1][0]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,571,'','','details3')
		return
	else:
		title,mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[-1]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if any(Y3YqSmycrIWksoH5N0MvC in title.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
		ggdRiBo3smurLUGO = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(ggdRiBo3smurLUGO)
		ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.split('?resize=')[0]
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|حلقة).\d+',title,JJDtX1PZyIgN2T.DOTALL)
		if '/collections/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,571,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt and type=='':
			title = '_MOD_'+vaQbluYS4GEsKCNwOymT1hFt[0][0]
			title = title.strip(' –')
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,573,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif 'episodes/' in wHiSfdBL1v9Kl3n5 or 'movies/' in wHiSfdBL1v9Kl3n5 or 'hindi/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,572,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,573,ggdRiBo3smurLUGO)
	if type=='filters':
		GHwMQ6AEyDKr3LuYheqRFkOWJg12C = JJDtX1PZyIgN2T.findall('"more_button_page":(.*?),',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if GHwMQ6AEyDKr3LuYheqRFkOWJg12C:
			count = GHwMQ6AEyDKr3LuYheqRFkOWJg12C[0]
			wHiSfdBL1v9Kl3n5 = url+'/offset/'+count
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة أخرى',wHiSfdBL1v9Kl3n5,571,'','','filters')
	elif 'details' in type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("class='pagination(.*?)</div>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall("href='(.*?)'.*?>(.*?)<",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = 'صفحة '+jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,571,'','','details4')
	return
def gaJo6Sm8HMP2jKrnBd(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','FASELHD1-SEASONS_EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YbPTE4rKt3cmIuz6WFdi = False
	if not type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"seasonList"(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if len(items)>1:
				PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
				YbPTE4rKt3cmIuz6WFdi = True
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,name,title in items:
					name = jbigKDeUf0OSMrRkly2B5I3Act(name)
					if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
					title = name+' - '+title
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,573,ggdRiBo3smurLUGO,'','episodes')
	if type=='episodes' or not YbPTE4rKt3cmIuz6WFdi:
		UCjpzQwrZyNIe3kg1ThDvi0nb8 = JJDtX1PZyIgN2T.findall('"posterImg".*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if UCjpzQwrZyNIe3kg1ThDvi0nb8: ggdRiBo3smurLUGO = UCjpzQwrZyNIe3kg1ThDvi0nb8[0]
		else: ggdRiBo3smurLUGO = ''
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"epAll"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,572,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	pB8XANf71vaPJsedkWVIc5,yN1kFpCuj8qLDTG7z43Zt,TTndkJXGRS = [],[],[]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','FASELHD1-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	HHTr8f6RvtQLF = JJDtX1PZyIgN2T.findall('مستوى المشاهدة.*?">(.*?)</span>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if HHTr8f6RvtQLF:
		lAnLtvg62C = JJDtX1PZyIgN2T.findall('"tag">(.*?)</a>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"videoRow"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&img=')[0]
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named=__embed')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="streamHeader(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall("href = '(.*?)'.*?</i>(.*?)</a>",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&img=')[0]
			name = name.strip(' ')
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+name+'__watch')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="downloadLinks(.*?)blackwindow',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</span>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&img=')[0]
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+name+'__download')
	for VPwny1D0BhGzde in pB8XANf71vaPJsedkWVIc5:
		wHiSfdBL1v9Kl3n5,name = VPwny1D0BhGzde.split('?named')
		if wHiSfdBL1v9Kl3n5 not in yN1kFpCuj8qLDTG7z43Zt:
			yN1kFpCuj8qLDTG7z43Zt.append(wHiSfdBL1v9Kl3n5)
			TTndkJXGRS.append(VPwny1D0BhGzde)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(TTndkJXGRS,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/?s='+search
	PeArnUDVym1pjBFaG,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,pmTdyfMuY6I3UQczZ = h7px9MIDvPwgZ2U6CNbT(DkRgFyVIBM85OA,'GET',url,'faselhd1','فاصل إعلاني','dubbed-movies')
	d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'details5')
	return
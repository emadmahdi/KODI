# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
headers = { 'User-Agent' : '' }
FpjtBKrnu5SdfyOvEPIQ = 'AKOAMCAM'
eMlwAzaLSj8ZEQ3txIGP = '_AKC_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['مصارعة']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==350: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==351: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==352: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==353: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==354: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'FILTERS___'+text)
	elif mode==355: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'CATEGORIES___'+text)
	elif mode==356: mL7BVKcSygkuoPbWlEF4YD = N93gVRASmynPCErOw20Gc7W8u(url)
	elif mode==357: mL7BVKcSygkuoPbWlEF4YD = Wdv56MmwBztPKFf(url)
	elif mode==359: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]','',8)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',359,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',kU2ZXSViB3wLANOz8bH,356)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',kU2ZXSViB3wLANOz8bH,357)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,kU2ZXSViB3wLANOz8bH,'',headers,'','AKOAMCAM-MENU-1st')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('recently-container.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'اضيف حديثا',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,351)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('@id":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المميزة',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,351,'','','featured')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-categories-list(.*?)main-categories-list',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?class="font.*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title not in eJzpdvc3KTust: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,351)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="categories-box(.*?)<footer',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = jbigKDeUf0OSMrRkly2B5I3Act(wHiSfdBL1v9Kl3n5)
			if title not in eJzpdvc3KTust: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,351)
	return YBEsLq8gVw629cMGQP1T
def N93gVRASmynPCErOw20Gc7W8u(website=''):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','AKOAMCAM-MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="menu(.*?)<nav',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?text">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title not in eJzpdvc3KTust:
				title = title+' مصنفة'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,355)
		if website=='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return YBEsLq8gVw629cMGQP1T
def Wdv56MmwBztPKFf(website=''):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','AKOAMCAM-MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="menu(.*?)<nav',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?text">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title not in eJzpdvc3KTust:
				title = title+' مفلترة'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,354)
		if website=='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(jCJnzmXDkNqtB,url,'',headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('swiper-container(.*?)swiper-button-prev',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	else: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="container"(.*?)main-footer',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		ClXwqHm0DEMvI39agWyiRYopQ = []
		for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|الحلقه) \d+',title,JJDtX1PZyIgN2T.DOTALL)
				if vaQbluYS4GEsKCNwOymT1hFt:
					title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0][0]
					if title not in ClXwqHm0DEMvI39agWyiRYopQ:
						nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,352,ggdRiBo3smurLUGO)
						ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			elif 'مسلسل' in title:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,352,ggdRiBo3smurLUGO)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,353,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href=["\'](.*?)["\'].*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = jbigKDeUf0OSMrRkly2B5I3Act(wHiSfdBL1v9Kl3n5)
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,351)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + '/?s='+s2hzmL48wFudNE5
	mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	return
def sjmSkpqHVtPcv(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,True,'AKOAMCAM-EPISODES-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('text-white">الحلقات(.*?)<header',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		l7PwAhTqWVUKME = JJDtX1PZyIgN2T.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in l7PwAhTqWVUKME:
			if 'الحلقة' in title or 'الحلقه' in title: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,353,ggdRiBo3smurLUGO)
	else:
		ggdRiBo3smurLUGO = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Icon')
		if YBEsLq8gVw629cMGQP1T.count('<title>')>1: title = JJDtX1PZyIgN2T.findall('<title>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[1]
		else: title = 'رابط التشغيل'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,url,353,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P,JCop4mjTiurYB7W = [],[]
	scvPZiDaKYIMtSfWQkoXFp2ALz = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','AKOAMCAM-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = scvPZiDaKYIMtSfWQkoXFp2ALz.content
	cKCInoAwzkR95WtXJdVUMGr = JJDtX1PZyIgN2T.findall('post_id=(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if cKCInoAwzkR95WtXJdVUMGr:
		cKCInoAwzkR95WtXJdVUMGr = cKCInoAwzkR95WtXJdVUMGr[0]
		headers = {'User-Agent':'','Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':cKCInoAwzkR95WtXJdVUMGr}
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		nakJSjo4sLZOzEYeDCmK = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,data,headers,'','','AKOAMCAM-PLAY-1st')
		Plj7MGOHohwdvam2ynfVY1z = nakJSjo4sLZOzEYeDCmK.content
		items = JJDtX1PZyIgN2T.findall('data-server="(.*?)".*?class="text">(.*?)<',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		for mLZb7XU6gaE8,name in items:
			wHiSfdBL1v9Kl3n5 = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?postid='+cKCInoAwzkR95WtXJdVUMGr+'&serverid='+mLZb7XU6gaE8+'?named='+name+'__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			JCop4mjTiurYB7W.append(name)
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		nakJSjo4sLZOzEYeDCmK = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,data,headers,'','','AKOAMCAM-PLAY-1st')
		Plj7MGOHohwdvam2ynfVY1z = nakJSjo4sLZOzEYeDCmK.content
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?class="text">(.*?)<',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.strip(' ')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			JCop4mjTiurYB7W.append(title)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	EhaSnsdMYV90pT = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='CATEGORIES':
		if EhaSnsdMYV90pT[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[0]
		for ggjo5zu7yCiIOhrb in range(len(EhaSnsdMYV90pT[0:-1])):
			if EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'all')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'?'+ssnIblOr0uX
	elif type=='FILTERS':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'all')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'?'+oju0BC1rJO
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,351,'','1')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,351,'','1')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<form id(.*?)</form>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	dict = {}
	for eYFHT1CfSqZK,name,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		items = JJDtX1PZyIgN2T.findall('<option(.*?)>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='CATEGORIES':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<=1:
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]: d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'CATEGORIES___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,351,'','1')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,355,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='FILTERS':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع : '+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,354,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			if 'value' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = khB9dCpWm4qPMrXTjgONf0Z
			else: Y3YqSmycrIWksoH5N0MvC = JJDtX1PZyIgN2T.findall('"(.*?)"',Y3YqSmycrIWksoH5N0MvC,JJDtX1PZyIgN2T.DOTALL)[0]
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			title = khB9dCpWm4qPMrXTjgONf0Z+' : '#+dict[eYFHT1CfSqZK]['0']
			title = khB9dCpWm4qPMrXTjgONf0Z+' : '+name
			if type=='FILTERS': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,354,'','',oy5AiZKfC86qITkYWL)
			elif type=='CATEGORIES' and EhaSnsdMYV90pT[-2]+'=' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'all')
				kHWT0XY2S6apruwxiB8FDl1 = url+'?'+ssnIblOr0uX
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,351,'','1')
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,355,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	d1GKRIraF3whePop87L4JjDZnEVB = ['cat','genre','release-year','quality','orderby']
	for key in d1GKRIraF3whePop87L4JjDZnEVB:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	return P1yxuh7MAmvSRVqLZcW6tY3
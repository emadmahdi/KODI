﻿# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
def HYWukw3pL2oMzPK4(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,oIe6nJP3LywDxKd2gN):
	if oIe6nJP3LywDxKd2gN=='': return
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr==1:
		Z3ZLXCOY2JV = U6zsmRNGTL.getCurrentWindowDialogId()
		dLPc8WEm9tBgDUqjRokQTI2yuZanAM = U6zsmRNGTL.Window(Z3ZLXCOY2JV)
		oIe6nJP3LywDxKd2gN = uusp6FEmWZwDhXo(oIe6nJP3LywDxKd2gN)
		dLPc8WEm9tBgDUqjRokQTI2yuZanAM.getControl(311).setLabel(oIe6nJP3LywDxKd2gN)
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr==0:
		ajLz9PfYbTigyorvZhW4IOFn='X'
		if DQfHadYvTpy1UR: dz8yNZomOx1ErATQH79 = isinstance(oIe6nJP3LywDxKd2gN,str)
		else: dz8yNZomOx1ErATQH79 = isinstance(oIe6nJP3LywDxKd2gN,unicode)
		if dz8yNZomOx1ErATQH79==True: ajLz9PfYbTigyorvZhW4IOFn='U'
		B4Wj5AqPyVKIFrDQw1S=str(type(oIe6nJP3LywDxKd2gN))+' '+oIe6nJP3LywDxKd2gN+' '+ajLz9PfYbTigyorvZhW4IOFn+' '
		for ggjo5zu7yCiIOhrb in range(0,len(oIe6nJP3LywDxKd2gN),1):
			B4Wj5AqPyVKIFrDQw1S += hex(ord(oIe6nJP3LywDxKd2gN[ggjo5zu7yCiIOhrb])).replace('0x','')+' '
		oIe6nJP3LywDxKd2gN = uusp6FEmWZwDhXo(oIe6nJP3LywDxKd2gN)
		ajLz9PfYbTigyorvZhW4IOFn='X'
		if DQfHadYvTpy1UR: dz8yNZomOx1ErATQH79 = isinstance(oIe6nJP3LywDxKd2gN, str)
		else: dz8yNZomOx1ErATQH79 = isinstance(oIe6nJP3LywDxKd2gN, unicode)
		if dz8yNZomOx1ErATQH79==True: ajLz9PfYbTigyorvZhW4IOFn='U'
		vGo9Eci0yw1LlmRuN8WBHD=str(type(oIe6nJP3LywDxKd2gN))+' '+oIe6nJP3LywDxKd2gN+' '+ajLz9PfYbTigyorvZhW4IOFn+' '
		for ggjo5zu7yCiIOhrb in range(0,len(oIe6nJP3LywDxKd2gN),1):
			vGo9Eci0yw1LlmRuN8WBHD += hex(ord(oIe6nJP3LywDxKd2gN[ggjo5zu7yCiIOhrb])).replace('0x','')+' '
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'DAILYMOTION'
eMlwAzaLSj8ZEQ3txIGP = '_DLM_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
kHZn1cEVXyGNTRug3 = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][1]
def HYWukw3pL2oMzPK4(mode,url,text,type,vYpMA3CxgcyR4VZJh):
	if	 mode==400: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==401: mL7BVKcSygkuoPbWlEF4YD = k9Uit4K1dlCwD(url,text)
	elif mode==402: mL7BVKcSygkuoPbWlEF4YD = hPSceQbUs7T8NZfdiKYOoIa(url,text)
	elif mode==403: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url,text)
	elif mode==404: mL7BVKcSygkuoPbWlEF4YD = ro8aAtZUFgbLmf1VC(text,vYpMA3CxgcyR4VZJh)
	elif mode==405: mL7BVKcSygkuoPbWlEF4YD = QSbenWdH7u2tm8EXCxgOlvGprN0(text,vYpMA3CxgcyR4VZJh)
	elif mode==406: mL7BVKcSygkuoPbWlEF4YD = VzxUfW7DPyp(text,vYpMA3CxgcyR4VZJh)
	elif mode==407: mL7BVKcSygkuoPbWlEF4YD = k2W3wS5x40(url,vYpMA3CxgcyR4VZJh)
	elif mode==408: mL7BVKcSygkuoPbWlEF4YD = FztiljcnuNWfxTPbqkKURHBJQM7(url,vYpMA3CxgcyR4VZJh)
	elif mode==409: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text,vYpMA3CxgcyR4VZJh)
	elif mode==411: mL7BVKcSygkuoPbWlEF4YD = WCFcf6aLN0Td(url,text)
	elif mode==412: mL7BVKcSygkuoPbWlEF4YD = FpfcEGqaOH6IzjeBxURk5obQ(text,vYpMA3CxgcyR4VZJh)
	elif mode==413: mL7BVKcSygkuoPbWlEF4YD = QYr5nWZzl2tjGcbReMCE9Somg3(url,vYpMA3CxgcyR4VZJh)
	elif mode==414: mL7BVKcSygkuoPbWlEF4YD = segEyKw6qkU(text)
	elif mode==415: mL7BVKcSygkuoPbWlEF4YD = zw6yMJHaBD7kGFNYv(text,vYpMA3CxgcyR4VZJh)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الرئيسية','',414)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',409,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن فيديوهات','',409,'','videos?sortBy=','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن آخر الفيديوهات','',409,'','videos?sortBy=RECENT','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن الفيديوهات الأكثر مشاهدة','',409,'','videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن قوائم التشغيل','',409,'','playlists','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن قنوات','',409,'','channels','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن مواضيع','',409,'','topics','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث عن بث حي','',409,'','lives','_REMEMBERRESULTS_')
	return
def hPSceQbUs7T8NZfdiKYOoIa(url,eAgVo2clMmwTSIaLFh):
	if '/dm_' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','',False,'','DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = SSzrgUnfVGL1hQsu40FoP7CWXax.headers
		if 'Location' in list(headers.keys()): url = kU2ZXSViB3wLANOz8bH+headers['Location']
	eAgVo2clMmwTSIaLFh = '[COLOR FFC89008]'+eAgVo2clMmwTSIaLFh+'[/COLOR]'
	eAgVo2clMmwTSIaLFh = HHg5UA4SKPr7jqkuosO(eAgVo2clMmwTSIaLFh)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: بث حي',url,411,'','','channel_lives_now')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: آخر الفيديوهات',url+'/videos',408)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: المميزة',url,411,'','','channel_featured_videos')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: قوائم التشغيل',url+'/playlists',407)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: قنوات ذات صلة',url,411,'','','channel_related_channel')
	return
def HHg5UA4SKPr7jqkuosO(title):
	title = title.rstrip('\\').strip(' ').replace('\\\\','\\')
	title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
	return title
def CsUdRabWuh0M9F(url,bbnzCkIBiPlYOXj3eWTESao):
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5([url],FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def ro8aAtZUFgbLmf1VC(search,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = ''
	search = search.split('/videos')[0]
	WAEqF7ZldrmL9Xw = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysearchwords',search)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	if sort=='': WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysortmethod','')
	else: WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'/videos'
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"videos"(.*?)"VideoConnection"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,title,BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh,hhCd56yES0cqfUKRsZaVI4wzWuTO,ggdRiBo3smurLUGO in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
			if '"' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace('"','')
			if '"' in BpkUnfPW1w0XJIDLTYhyzsGFbElRSN: BpkUnfPW1w0XJIDLTYhyzsGFbElRSN = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN.replace('"','')
			if '"' in eAgVo2clMmwTSIaLFh: eAgVo2clMmwTSIaLFh = eAgVo2clMmwTSIaLFh.replace('"','')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+id
			title = HHg5UA4SKPr7jqkuosO(title)
			bbnzCkIBiPlYOXj3eWTESao = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN+'::'+eAgVo2clMmwTSIaLFh
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO,bbnzCkIBiPlYOXj3eWTESao)
		if '"hasNextPage":true' in YBEsLq8gVw629cMGQP1T:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,404,'',vYpMA3CxgcyR4VZJh,search)
	return
def QSbenWdH7u2tm8EXCxgOlvGprN0(search,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	WAEqF7ZldrmL9Xw = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysearchwords',search)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'/playlists'
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	items = JJDtX1PZyIgN2T.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for id,name,xmnK2Zp4htgB,BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh,ggdRiBo3smurLUGO,count in items:
		if '"' in xmnK2Zp4htgB: xmnK2Zp4htgB = xmnK2Zp4htgB.replace('"','')
		if '"' in BpkUnfPW1w0XJIDLTYhyzsGFbElRSN: BpkUnfPW1w0XJIDLTYhyzsGFbElRSN = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN.replace('"','')
		if '"' in eAgVo2clMmwTSIaLFh: eAgVo2clMmwTSIaLFh = eAgVo2clMmwTSIaLFh.replace('"','')
		if '"' in id: id = id.replace('"','')
		if '"' in name: name = name.replace('"','')
		if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
		if '"' in count: count = count.replace('"','')
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = HHg5UA4SKPr7jqkuosO(title)
		bbnzCkIBiPlYOXj3eWTESao = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN+'::'+eAgVo2clMmwTSIaLFh
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,401,ggdRiBo3smurLUGO,'',bbnzCkIBiPlYOXj3eWTESao)
	if '"hasNextPage":true' in YBEsLq8gVw629cMGQP1T:
		vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,405,'',vYpMA3CxgcyR4VZJh,search)
	return
def VzxUfW7DPyp(search,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	WAEqF7ZldrmL9Xw = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    views {\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment VIDEO_WATCH_LATER_FRAGMENT on Video {\n  id\n  isInWatchLater\n  __typename\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_WATCH_LATER_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysearchwords',search)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'/channels'
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"channels"(.*?)"ChannelConnection"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,name,ggdRiBo3smurLUGO in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+id
			title = 'CHNL:  '+name
			title = HHg5UA4SKPr7jqkuosO(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,402,ggdRiBo3smurLUGO,'',name)
		if '"hasNextPage":true' in YBEsLq8gVw629cMGQP1T:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,406,'',vYpMA3CxgcyR4VZJh,search)
	return
def segEyKw6qkU(SSjPIdEnQ3qmMGyt8V):
	WAEqF7ZldrmL9Xw = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  thumbnail: coverURL(size: \"x532\")\n  coverURL: coverURL(size: \"x532\")\n  isFollowed\n  whitelistStatus {\n    id\n    isWhitelisted\n    __typename\n  }\n  __typename\n}\n\nquery HOME_QUERY($space: String!) {\n  home: views {\n    id\n    neon {\n      id\n      sections(space: $space) {\n        edges {\n          node {\n            id\n            name\n            title\n            description\n            groupingType\n            type\n            relatedComponent {\n              __typename\n              ... on Collection {\n                id\n                xid\n                __typename\n              }\n              ... on Channel {\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                __typename\n              }\n              ... on Topic {\n                id\n                __typename\n                ...TOPIC_BASE_FRAG\n              }\n            }\n            components {\n              edges {\n                node {\n                  __typename\n                  ... on Video {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    description\n                    duration\n                    __typename\n                  }\n                  ... on Live {\n                    id\n                    xid\n                    title\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx360: thumbnailURL(size: \"x360\")\n                    thumbnailx480: thumbnailURL(size: \"x480\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    aspectRatio\n                    createdAt\n                    channel {\n                      id\n                      xid\n                      name\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      accountType\n                      __typename\n                    }\n                    startAt\n                    __typename\n                  }\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	vZJ7na4qiNTEI = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	if vZJ7na4qiNTEI:
		DDRdQ8ZM70lmqg2 = G8EwoDOyKShm1i0IHMfNYZlU7('dict',vZJ7na4qiNTEI)
		a9DYMGiwfSv1TZ6WltynA4rhmgU = DDRdQ8ZM70lmqg2['data']['home']['neon']['sections']['edges']
		if not SSjPIdEnQ3qmMGyt8V:
			QQhICJPBO59GcMkDtUiKlRwf7L = []
			for ZOh7mzfc4oDegnIAQ3qjdvKwL in a9DYMGiwfSv1TZ6WltynA4rhmgU:
				F0an3zOLMK1HVYm = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['title']
				if F0an3zOLMK1HVYm not in QQhICJPBO59GcMkDtUiKlRwf7L: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+F0an3zOLMK1HVYm,'',414,'','',F0an3zOLMK1HVYm)
				QQhICJPBO59GcMkDtUiKlRwf7L.append(F0an3zOLMK1HVYm)
		else:
			for ZOh7mzfc4oDegnIAQ3qjdvKwL in a9DYMGiwfSv1TZ6WltynA4rhmgU:
				F0an3zOLMK1HVYm = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['title']
				if F0an3zOLMK1HVYm==SSjPIdEnQ3qmMGyt8V:
					CZqGbDJ2OsfTtSw19eQ = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['components']['edges']
					for AZbRpnosErqQMg54P83ViCFGS in CZqGbDJ2OsfTtSw19eQ:
						hhCd56yES0cqfUKRsZaVI4wzWuTO = str(AZbRpnosErqQMg54P83ViCFGS['node']['duration'])
						title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(AZbRpnosErqQMg54P83ViCFGS['node']['title'])
						title = title.replace('\/','/')
						RILV671CxFhBKtjml94evXnrPzW = AZbRpnosErqQMg54P83ViCFGS['node']['xid']
						ggdRiBo3smurLUGO = AZbRpnosErqQMg54P83ViCFGS['node']['thumbnailx480']
						ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('\/','/')
						wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+RILV671CxFhBKtjml94evXnrPzW
						nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO)
	return
def zw6yMJHaBD7kGFNYv(search,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	WAEqF7ZldrmL9Xw = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n  ... on Live {\n    id\n    viewerEngagement {\n      id\n      favorited\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          xid\n          title\n          thumbnail: thumbnailURL(size: \"x240\")\n          thumbnailx60: thumbnailURL(size: \"x60\")\n          thumbnailx120: thumbnailURL(size: \"x120\")\n          thumbnailx240: thumbnailURL(size: \"x240\")\n          thumbnailx720: thumbnailURL(size: \"x720\")\n          audienceCount\n          aspectRatio\n          isOnAir\n          channel {\n            id\n            xid\n            name\n            displayName\n            accountType\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysearchwords',search)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'/lives'
	vZJ7na4qiNTEI = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	if vZJ7na4qiNTEI:
		DDRdQ8ZM70lmqg2 = G8EwoDOyKShm1i0IHMfNYZlU7('dict',vZJ7na4qiNTEI)
		try: a9DYMGiwfSv1TZ6WltynA4rhmgU = DDRdQ8ZM70lmqg2['data']['search']['lives']['edges']
		except: a9DYMGiwfSv1TZ6WltynA4rhmgU = []
		for ZOh7mzfc4oDegnIAQ3qjdvKwL in a9DYMGiwfSv1TZ6WltynA4rhmgU:
			name = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['title']
			RILV671CxFhBKtjml94evXnrPzW = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['xid']
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+RILV671CxFhBKtjml94evXnrPzW
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'LIVE: '+name,wHiSfdBL1v9Kl3n5,403)
		if '"hasNextPage":true' in vZJ7na4qiNTEI:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,415,'',vYpMA3CxgcyR4VZJh,search)
	return
def FpfcEGqaOH6IzjeBxURk5obQ(search,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	WAEqF7ZldrmL9Xw = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {\n  id\n  xid\n  title\n  createdAt\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  duration\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  aspectRatio\n  __typename\n}\n\nfragment VIDEO_FAVORITES_FRAGMENT on Media {\n  __typename\n  ... on Video {\n    id\n    isInWatchLater\n    __typename\n  }\n  ... on Live {\n    id\n    isInWatchLater\n    __typename\n  }\n}\n\nfragment CHANNEL_BASE_FRAG on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isFollowed\n  thumbnailx60: logoURL(size: \"x60\")\n  thumbnailx120: logoURL(size: \"x120\")\n  thumbnailx240: logoURL(size: \"x240\")\n  thumbnailx720: logoURL(size: \"x720\")\n  __typename\n}\n\nfragment PLAYLIST_BASE_FRAG on Collection {\n  id\n  xid\n  name\n  channel {\n    id\n    xid\n    name\n    displayName\n    accountType\n    __typename\n  }\n  description\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment TOPIC_BASE_FRAG on Topic {\n  id\n  xid\n  name\n  videos(sort: \"recent\", first: 5) {\n    pageInfo {\n      hasNextPage\n      nextPage\n      __typename\n    }\n    edges {\n      node {\n        id\n        ...VIDEO_BASE_FRAGMENT\n        ...VIDEO_FAVORITES_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  stats {\n    id\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {\n  search {\n    id\n    videos(\n      query: $query\n      first: $limit\n      page: $page\n      sort: $sortByVideos\n      durationMin: $durationMinVideos\n      durationMax: $durationMaxVideos\n      createdAfter: $createdAfterVideos\n    ) @include(if: $shouldIncludeVideos) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...VIDEO_BASE_FRAGMENT\n          ...VIDEO_FAVORITES_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...CHANNEL_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...PLAYLIST_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {\n      metadata {\n        algorithm {\n          uuid\n          __typename\n        }\n        __typename\n      }\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      totalCount\n      edges {\n        node {\n          id\n          ...TOPIC_BASE_FRAG\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysearchwords',search)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'/topics'
	vZJ7na4qiNTEI = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	if vZJ7na4qiNTEI:
		DDRdQ8ZM70lmqg2 = G8EwoDOyKShm1i0IHMfNYZlU7('dict',vZJ7na4qiNTEI)
		try: a9DYMGiwfSv1TZ6WltynA4rhmgU = DDRdQ8ZM70lmqg2['data']['search']['topics']['edges']
		except: a9DYMGiwfSv1TZ6WltynA4rhmgU = []
		for ZOh7mzfc4oDegnIAQ3qjdvKwL in a9DYMGiwfSv1TZ6WltynA4rhmgU:
			name = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['name']
			RILV671CxFhBKtjml94evXnrPzW = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['xid']
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/topic/'+RILV671CxFhBKtjml94evXnrPzW
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'TOPIC: '+name,wHiSfdBL1v9Kl3n5,413)
		if '"hasNextPage":true' in vZJ7na4qiNTEI:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,412,'',vYpMA3CxgcyR4VZJh,search)
	return
def QYr5nWZzl2tjGcbReMCE9Somg3(url,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	RILV671CxFhBKtjml94evXnrPzW = url.split('/')[-1]
	WAEqF7ZldrmL9Xw = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  duration\n  isLiked\n  isInWatchLater\n  isCreatedForKids\n  createdAt\n  isExplicit\n  videoHeight: height\n  videoWidth: width\n  category\n  channel {\n    id\n    xid\n    name\n    displayName\n    logoURLx25: logoURL(size: \"x25\")\n    logoURL(size: \"x60\")\n    accountType\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  language {\n    id\n    codeAlpha2\n    __typename\n  }\n  thumbnailx60: thumbnailURL(size: \"x60\")\n  thumbnailx120: thumbnailURL(size: \"x120\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  bestAvailableQuality\n  aspectRatio\n  isPublished\n  __typename\n}\n\nquery DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {\n  topic(xid: $xid) {\n    id\n    xid\n    name\n    videos(sort: \"recent\", first: 30, page: $page) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...TOPIC_VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mytopicid',RILV671CxFhBKtjml94evXnrPzW)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	vZJ7na4qiNTEI = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	if vZJ7na4qiNTEI:
		DDRdQ8ZM70lmqg2 = G8EwoDOyKShm1i0IHMfNYZlU7('dict',vZJ7na4qiNTEI)
		a9DYMGiwfSv1TZ6WltynA4rhmgU = DDRdQ8ZM70lmqg2['data']['topic']['videos']['edges']
		for ZOh7mzfc4oDegnIAQ3qjdvKwL in a9DYMGiwfSv1TZ6WltynA4rhmgU:
			hhCd56yES0cqfUKRsZaVI4wzWuTO = str(ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['duration'])
			title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['title'])
			title = title.replace('\/','/')
			RILV671CxFhBKtjml94evXnrPzW = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['xid']
			ggdRiBo3smurLUGO = ZOh7mzfc4oDegnIAQ3qjdvKwL['node']['thumbnailx480']
			ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('\/','/')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+RILV671CxFhBKtjml94evXnrPzW
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO)
		if '"hasNextPage":true' in vZJ7na4qiNTEI:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,413,'',vYpMA3CxgcyR4VZJh)
	return
def k9Uit4K1dlCwD(url,bbnzCkIBiPlYOXj3eWTESao):
	id = url.split('/')[-1]
	BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh = bbnzCkIBiPlYOXj3eWTESao.split('::',1)
	wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+BpkUnfPW1w0XJIDLTYhyzsGFbElRSN
	eAgVo2clMmwTSIaLFh = HHg5UA4SKPr7jqkuosO(eAgVo2clMmwTSIaLFh)
	title = '[COLOR FFC89008]OWNER:  '+eAgVo2clMmwTSIaLFh+'[/COLOR]'
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,402,'','',eAgVo2clMmwTSIaLFh)
	WAEqF7ZldrmL9Xw = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {\n  views {\n    id\n    neon {\n      id\n      sections(device: $device, space: \"watching\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {\n        edges {\n          node {\n            id\n            name\n            groupingType\n            relatedComponent {\n              ... on Channel {\n                __typename\n                id\n                xid\n                name\n                displayName\n                logoURL(size: \"x60\")\n                logoURLx25: logoURL(size: \"x25\")\n              }\n              ... on Topic {\n                __typename\n                id\n                xid\n                name\n                names {\n                  edges {\n                    node {\n                      id\n                      name\n                      language {\n                        id\n                        codeAlpha2\n                        __typename\n                      }\n                      __typename\n                    }\n                    __typename\n                  }\n                  __typename\n                }\n              }\n              ... on Collection {\n                __typename\n                id\n                xid\n                name\n              }\n              __typename\n            }\n            components(first: $videoCountPerSection) {\n              metadata {\n                algorithm {\n                  name\n                  version\n                  uuid\n                  __typename\n                }\n                __typename\n              }\n              edges {\n                node {\n                  ... on Video {\n                    __typename\n                    id\n                    xid\n                    title\n                    duration\n                    thumbnailx60: thumbnailURL(size: \"x60\")\n                    thumbnailx120: thumbnailURL(size: \"x120\")\n                    thumbnailx240: thumbnailURL(size: \"x240\")\n                    thumbnailx720: thumbnailURL(size: \"x720\")\n                    channel {\n                      id\n                      xid\n                      accountType\n                      displayName\n                      logoURLx25: logoURL(size: \"x25\")\n                      logoURL(size: \"x60\")\n                      __typename\n                    }\n                  }\n                  ... on Channel {\n                    __typename\n                    id\n                    xid\n                    name\n                    displayName\n                    accountType\n                    logoURL(size: \"x60\")\n                  }\n                  __typename\n                }\n                __typename\n              }\n              __typename\n            }\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('myplaylistid',id)
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"collection_videos"(.*?)"SectionEdge"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,title,hhCd56yES0cqfUKRsZaVI4wzWuTO,ggdRiBo3smurLUGO,BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
			if '"' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace('"','')
			if '"' in BpkUnfPW1w0XJIDLTYhyzsGFbElRSN: BpkUnfPW1w0XJIDLTYhyzsGFbElRSN = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN.replace('"','')
			if '"' in eAgVo2clMmwTSIaLFh: eAgVo2clMmwTSIaLFh = eAgVo2clMmwTSIaLFh.replace('"','')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+id
			title = HHg5UA4SKPr7jqkuosO(title)
			bbnzCkIBiPlYOXj3eWTESao = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN+'::'+eAgVo2clMmwTSIaLFh
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO,bbnzCkIBiPlYOXj3eWTESao)
	return
def FztiljcnuNWfxTPbqkKURHBJQM7(url,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	rjcLNMPIGsBSni4odgDpx8zqQ2h = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	WAEqF7ZldrmL9Xw = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbURLx240: thumbnailURL(size: \"x240\")\n  thumbURLx360: thumbnailURL(size: \"x360\")\n  thumbURLx480: thumbnailURL(size: \"x480\")\n  thumbURLx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nquery CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          ...VIDEO_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mychannelid',rjcLNMPIGsBSni4odgDpx8zqQ2h)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysortmethod',sort)
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,title,hhCd56yES0cqfUKRsZaVI4wzWuTO,BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh,ggdRiBo3smurLUGO in items:
			if '"' in id: id = id.replace('"','')
			if '"' in title: title = title.replace('"','')
			if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
			if '"' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace('"','')
			if '"' in BpkUnfPW1w0XJIDLTYhyzsGFbElRSN: BpkUnfPW1w0XJIDLTYhyzsGFbElRSN = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN.replace('"','')
			if '"' in eAgVo2clMmwTSIaLFh: eAgVo2clMmwTSIaLFh = eAgVo2clMmwTSIaLFh.replace('"','')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+id
			title = HHg5UA4SKPr7jqkuosO(title)
			bbnzCkIBiPlYOXj3eWTESao = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN+'::'+eAgVo2clMmwTSIaLFh
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO,bbnzCkIBiPlYOXj3eWTESao)
		if '"hasNextPage":true' in YBEsLq8gVw629cMGQP1T:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,408,'',vYpMA3CxgcyR4VZJh)
	return
def k2W3wS5x40(url,vYpMA3CxgcyR4VZJh=''):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	rjcLNMPIGsBSni4odgDpx8zqQ2h = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	WAEqF7ZldrmL9Xw = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  isFollowed\n  accountType\n  __typename\n}\n\nfragment CHANNEL_IMAGES_FRAGMENT on Channel {\n  id\n  coverURLx375: coverURL(size: \"x375\")\n  __typename\n}\n\nfragment CHANNEL_UPDATED_FRAGMENT on Channel {\n  id\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_COMPLETE_FRAGMENT on Channel {\n  id\n  ...CHANNEL_BASE_FRAGMENT\n  ...CHANNEL_IMAGES_FRAGMENT\n  ...CHANNEL_UPDATED_FRAGMENT\n  description\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  externalLinks {\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    __typename\n  }\n  __typename\n}\n\nfragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    views {\n      total\n      __typename\n    }\n    followers {\n      total\n      __typename\n    }\n    videos {\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {\n  channel(xid: $channel_xid) {\n    id\n    ...CHANNEL_COMPLETE_FRAGMENT\n    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {\n      pageInfo {\n        hasNextPage\n        nextPage\n        __typename\n      }\n      edges {\n        node {\n          id\n          xid\n          updatedAt\n          name\n          description\n          thumbURLx240: thumbnailURL(size: \"x240\")\n          thumbURLx360: thumbnailURL(size: \"x360\")\n          thumbURLx480: thumbnailURL(size: \"x480\")\n          stats {\n            videos {\n              total\n              __typename\n            }\n            __typename\n          }\n          channel {\n            id\n            ...CHANNEL_FRAGMENT\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mychannelid',rjcLNMPIGsBSni4odgDpx8zqQ2h)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagelimit','40')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mypagenumber',vYpMA3CxgcyR4VZJh)
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mysortmethod',sort)
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,name,ggdRiBo3smurLUGO,count,xmnK2Zp4htgB,BpkUnfPW1w0XJIDLTYhyzsGFbElRSN,eAgVo2clMmwTSIaLFh in items:
			if '"' in id: id = id.replace('"','')
			if '"' in name: name = name.replace('"','')
			if '"' in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('"','')
			if '"' in count: count = count.replace('"','')
			if '"' in xmnK2Zp4htgB: xmnK2Zp4htgB = xmnK2Zp4htgB.replace('"','')
			if '"' in BpkUnfPW1w0XJIDLTYhyzsGFbElRSN: BpkUnfPW1w0XJIDLTYhyzsGFbElRSN = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN.replace('"','')
			if '"' in eAgVo2clMmwTSIaLFh: eAgVo2clMmwTSIaLFh = eAgVo2clMmwTSIaLFh.replace('"','')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = HHg5UA4SKPr7jqkuosO(title)
			bbnzCkIBiPlYOXj3eWTESao = BpkUnfPW1w0XJIDLTYhyzsGFbElRSN+'::'+eAgVo2clMmwTSIaLFh
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,401,ggdRiBo3smurLUGO,'',bbnzCkIBiPlYOXj3eWTESao)
		if '"hasNextPage":true' in YBEsLq8gVw629cMGQP1T:
			vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)+1)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+vYpMA3CxgcyR4VZJh,url,407,'',vYpMA3CxgcyR4VZJh)
	return
def WCFcf6aLN0Td(url,iW6R0zO1ITZ):
	rjcLNMPIGsBSni4odgDpx8zqQ2h = url.split('/')[3]
	WAEqF7ZldrmL9Xw = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {\n  accountType\n  id\n  xid\n  name\n  displayName\n  isArtist\n  logoURL(size: \"x60\")\n  coverURLx375: coverURL(size: \"x375\")\n  isFollowed\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment LIVE_FRAGMENT on Live {\n  id\n  xid\n  title\n  startAt\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  __typename\n}\n\nfragment VIDEO_FRAGMENT on Video {\n  id\n  xid\n  title\n  viewCount\n  duration\n  createdAt\n  isInWatchLater\n  channel {\n    id\n    ...CHANNEL_FRAGMENT\n    __typename\n  }\n  thumbnailx240: thumbnailURL(size: \"x240\")\n  thumbnailx360: thumbnailURL(size: \"x360\")\n  thumbnailx480: thumbnailURL(size: \"x480\")\n  thumbnailx720: thumbnailURL(size: \"x720\")\n  __typename\n}\n\nfragment CHANNEL_MAIN_FRAGMENT on Channel {\n  id\n  xid\n  name\n  displayName\n  description\n  accountType\n  isArtist\n  logoURL(size: \"x60\")\n  coverURL1024x: coverURL(size: \"1024x\")\n  coverURL1920x: coverURL(size: \"1920x\")\n  isFollowed\n  tagline\n  country {\n    id\n    codeAlpha2\n    __typename\n  }\n  stats {\n    id\n    views {\n      id\n      total\n      __typename\n    }\n    followers {\n      id\n      total\n      __typename\n    }\n    videos {\n      id\n      total\n      __typename\n    }\n    __typename\n  }\n  externalLinks {\n    id\n    facebookURL\n    twitterURL\n    websiteURL\n    instagramURL\n    pinterestURL\n    __typename\n  }\n  channel_lives_now: lives(first: 4, isOnAir: true) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_lives_scheduled: lives(first: 4, startIn: 7200) {\n    edges {\n      node {\n        id\n        ...LIVE_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_featured_videos: videos(first: 4, isFeatured: true) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_all_videos: videos(first: 4) {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_most_viewed: videos(first: 4, sort: \"visited\") {\n    edges {\n      node {\n        id\n        ...VIDEO_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_collections: collections(first: 4) {\n    edges {\n      node {\n        id\n        xid\n        name\n        description\n        stats {\n          id\n          videos {\n            id\n            total\n            __typename\n          }\n          __typename\n        }\n        thumbnailx240: thumbnailURL(size: \"x240\")\n        thumbnailx360: thumbnailURL(size: \"x360\")\n        thumbnailx480: thumbnailURL(size: \"x480\")\n        channel {\n          id\n          ...CHANNEL_FRAGMENT\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  channel_related_channel: networkChannels(\n    hasPublicVideos: true\n    first: $relatedChannels\n  ) {\n    edges {\n      node {\n        id\n        ...CHANNEL_FRAGMENT\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nquery CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {\n  channel(name: $channel_name) {\n    id\n    ...CHANNEL_MAIN_FRAGMENT\n    __typename\n  }\n}\n"}'
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('mychannelid',rjcLNMPIGsBSni4odgDpx8zqQ2h)
	YBEsLq8gVw629cMGQP1T = ps6RLOTG30Z(WAEqF7ZldrmL9Xw)
	import json as aYhFKJupNC2ATLlXDqjc1SV6
	JfGWalzkbL7USjicR4mrXOV9KFhgn = aYhFKJupNC2ATLlXDqjc1SV6.loads(YBEsLq8gVw629cMGQP1T)
	try: items = JfGWalzkbL7USjicR4mrXOV9KFhgn['data']['channel'][iW6R0zO1ITZ]['edges']
	except: items = []
	if not items: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'لا توجد نتائج','',9999)
	else:
		for KxB8vVHUJg in items:
			v2eVERnrGdMOktzlYyf6ZpTPW = KxB8vVHUJg['node']
			RILV671CxFhBKtjml94evXnrPzW = v2eVERnrGdMOktzlYyf6ZpTPW['xid']
			keys = list(v2eVERnrGdMOktzlYyf6ZpTPW.keys())
			iBO64vcUhXJIRDWLNFZtEn = v2eVERnrGdMOktzlYyf6ZpTPW['__typename'].lower()
			if iBO64vcUhXJIRDWLNFZtEn=='channel':
				name = v2eVERnrGdMOktzlYyf6ZpTPW['name']
				K5n241NTZuiLAOIc63CYs9Ggwr = v2eVERnrGdMOktzlYyf6ZpTPW['displayName']
				title = 'CHNL:  '+K5n241NTZuiLAOIc63CYs9Ggwr
				ggdRiBo3smurLUGO = v2eVERnrGdMOktzlYyf6ZpTPW['coverURLx375']
			else:
				name = v2eVERnrGdMOktzlYyf6ZpTPW['channel']['name']
				K5n241NTZuiLAOIc63CYs9Ggwr = v2eVERnrGdMOktzlYyf6ZpTPW['channel']['displayName']
				title = v2eVERnrGdMOktzlYyf6ZpTPW['title']
				ggdRiBo3smurLUGO = v2eVERnrGdMOktzlYyf6ZpTPW['thumbnailx360']
				if iBO64vcUhXJIRDWLNFZtEn=='live': title = 'LIVE:  '+title
			title = HHg5UA4SKPr7jqkuosO(title)
			bbnzCkIBiPlYOXj3eWTESao = name+'::'+K5n241NTZuiLAOIc63CYs9Ggwr
			if wIqFesTOvYnu5S2dWfpBVC:
				title = title.encode('utf8')
				bbnzCkIBiPlYOXj3eWTESao = bbnzCkIBiPlYOXj3eWTESao.encode('utf8')
			if iBO64vcUhXJIRDWLNFZtEn=='channel':
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+RILV671CxFhBKtjml94evXnrPzW
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,402,ggdRiBo3smurLUGO,'',bbnzCkIBiPlYOXj3eWTESao)
			else:
				if iBO64vcUhXJIRDWLNFZtEn=='video': hhCd56yES0cqfUKRsZaVI4wzWuTO = str(v2eVERnrGdMOktzlYyf6ZpTPW['duration'])
				else: hhCd56yES0cqfUKRsZaVI4wzWuTO = ''
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/video/'+RILV671CxFhBKtjml94evXnrPzW
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(iBO64vcUhXJIRDWLNFZtEn,eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,403,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO,bbnzCkIBiPlYOXj3eWTESao)
	return
def ps6RLOTG30Z(WAEqF7ZldrmL9Xw):
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace(' \"',' \\"')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('\", ','\\", ')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('\n','\\n')
	WAEqF7ZldrmL9Xw = WAEqF7ZldrmL9Xw.replace('")','\\")')
	TT7w6iqcYVuXk1IWfgOL9rhCdAjosy = DeufQUS2YtnBdx()
	headers = {"Authorization":TT7w6iqcYVuXk1IWfgOL9rhCdAjosy,"Origin":kU2ZXSViB3wLANOz8bH}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',kHZn1cEVXyGNTRug3,WAEqF7ZldrmL9Xw,headers,'','','DAILYMOTION-GET_PAGEDATA-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	return YBEsLq8gVw629cMGQP1T
def DeufQUS2YtnBdx():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,'','','','','DAILYMOTION-GET_AUTHINTICATION-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	pih694c5MQlG2dIruqAJatPR3v8ze = JJDtX1PZyIgN2T.findall('var r="(.*?)",o="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	VN38cyDKJtg5f1vFliYapITjuzqZ,N9DcvZxghdizP2LaR = pih694c5MQlG2dIruqAJatPR3v8ze[-1]
	k8vNPu7YaImg = 'https://graphql.api.dailymotion.com/oauth/token'
	JALMdShpk1xGuvYcRUVQy0ne3t = 'client_credentials'
	data = {'client_id':VN38cyDKJtg5f1vFliYapITjuzqZ,'client_secret':N9DcvZxghdizP2LaR,'grant_type':JALMdShpk1xGuvYcRUVQy0ne3t}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',k8vNPu7YaImg,data,headers,'','','DAILYMOTION-GET_AUTHINTICATION-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	pih694c5MQlG2dIruqAJatPR3v8ze = JJDtX1PZyIgN2T.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	ykHnS8am4wBKUj5cQ,HYX7B6V0le2aK4JMswAD3Ub95yZoL = pih694c5MQlG2dIruqAJatPR3v8ze[0]
	TT7w6iqcYVuXk1IWfgOL9rhCdAjosy = HYX7B6V0le2aK4JMswAD3Ub95yZoL+" "+ykHnS8am4wBKUj5cQ
	return TT7w6iqcYVuXk1IWfgOL9rhCdAjosy
def VH5hnQa7CPSR1tMlZ03Wpx8(search,type=''):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not type and showDialogs:
		TVXERxCSio = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن مواضيع','بحث عن بث حي']
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع ديلي موشن - اختر البحث',TVXERxCSio)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==0: type = 'videos?sortBy='
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==1: type = 'videos?sortBy=RECENT'
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==2: type = 'videos?sortBy=VIEW_COUNT'
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==3: type = 'playlists'
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==4: type = 'channels'
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==5: type = 'topics'
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==6: type = 'lives'
	elif '_DAILYMOTION-VIDEOS_' in sdZQpO06qbHwAGPz7LCgu4lToE: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in sdZQpO06qbHwAGPz7LCgu4lToE: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in sdZQpO06qbHwAGPz7LCgu4lToE: type = 'channels'
	elif '_DAILYMOTION-TOPICS_' in sdZQpO06qbHwAGPz7LCgu4lToE: type = 'topics'
	elif '_DAILYMOTION-LIVES_' in sdZQpO06qbHwAGPz7LCgu4lToE: type = 'lives'
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	if DQfHadYvTpy1UR: search = search.encode('utf8').decode('raw_unicode_escape')
	if 'videos' in type: ro8aAtZUFgbLmf1VC(search+'/'+type)
	elif 'playlists' in type: QSbenWdH7u2tm8EXCxgOlvGprN0(search)
	elif 'channels' in type: VzxUfW7DPyp(search)
	elif 'topics' in type: FpfcEGqaOH6IzjeBxURk5obQ(search)
	elif 'lives' in type: zw6yMJHaBD7kGFNYv(search)
	return
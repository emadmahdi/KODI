# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'TVFUN'
eMlwAzaLSj8ZEQ3txIGP = '_TVF_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['بث مباشر']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==460: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==461: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==462: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==463: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==469: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','TVFUN-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',469,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"menu-btn"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in eJzpdvc3KTust: continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,461)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,IOC7UWYc5MTHZbLx9VtXpn=''):
	items = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','TVFUN-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="head-title"(.*?)id="footer"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		ClXwqHm0DEMvI39agWyiRYopQ = []
		eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,462,ggdRiBo3smurLUGO)
			elif vaQbluYS4GEsKCNwOymT1hFt and 'الحلقة' in title:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,463,ggdRiBo3smurLUGO)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,463,ggdRiBo3smurLUGO)
	if IOC7UWYc5MTHZbLx9VtXpn!='latest':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('<a href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.strip(' ')
				if wHiSfdBL1v9Kl3n5=="": continue
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
				if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,461)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','TVFUN-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="head-title"(.*?)id="footer"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,462,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.strip(' ')
			if wHiSfdBL1v9Kl3n5=="": continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,463)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P = []
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('/video/','/watch/')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','TVFUN-PLAY-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('VideoServers"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		kwqYoF8han = JJDtX1PZyIgN2T.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for lYih6yH2X45,name in kwqYoF8han:
			lYih6yH2X45 = lYih6yH2X45[2:]
			if wIqFesTOvYnu5S2dWfpBVC: lYih6yH2X45 = lYih6yH2X45.decode('utf8')
			lYih6yH2X45 = gPSZVjJHKIL.b64decode(lYih6yH2X45)
			if DQfHadYvTpy1UR: lYih6yH2X45 = lYih6yH2X45.decode('utf8')
			wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',lYih6yH2X45,JJDtX1PZyIgN2T.DOTALL)
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
			if 'http' not in wHiSfdBL1v9Kl3n5:
				if '//' in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
				else: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if wHiSfdBL1v9Kl3n5 not in EEgFl59RndzrBL8TUoaQMw6P:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	if ' ' in search:
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = kU2ZXSViB3wLANOz8bH+'/q/'+search+'/'
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SHAHID4U'
headers = ''
eMlwAzaLSj8ZEQ3txIGP = '_SH4_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==110: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==111: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==112: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==113: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url,True)
	elif mode==114: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'FULL_FILTER___'+text)
	elif mode==115: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'DEFINED_FILTER___'+text)
	elif mode==116: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url,False)
	elif mode==119: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	PeArnUDVym1pjBFaG,url,SSzrgUnfVGL1hQsu40FoP7CWXax = h7px9MIDvPwgZ2U6CNbT(jCJnzmXDkNqtB,'GET',kU2ZXSViB3wLANOz8bH,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',119,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',PeArnUDVym1pjBFaG,115)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',PeArnUDVym1pjBFaG,114)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',PeArnUDVym1pjBFaG,111,'','','featured')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('simple-filter(.*?)adv-filter',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for filter,ggdRiBo3smurLUGO,title in items:
			url = PeArnUDVym1pjBFaG+filter
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,url,111,ggdRiBo3smurLUGO,'',filter)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="dropdown"(.*?)<script>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.replace('\n','').replace('\r','').strip(' ')
			if title in eJzpdvc3KTust: continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
			if 'netflix' in wHiSfdBL1v9Kl3n5: title = 'نيتفلكس'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,111)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,IOC7UWYc5MTHZbLx9VtXpn='',SSzrgUnfVGL1hQsu40FoP7CWXax=''):
	if not SSzrgUnfVGL1hQsu40FoP7CWXax: SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','SHAHID4U-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC,items,ClXwqHm0DEMvI39agWyiRYopQ = [],[],[]
	if IOC7UWYc5MTHZbLx9VtXpn=='featured': GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('glide__slides(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	else: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('shows-container(.*?)pagination',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if not items: items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if 'javascript' in wHiSfdBL1v9Kl3n5: continue
		wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5).strip('/')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		title = title.strip(' ')
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
		if '/film/' in wHiSfdBL1v9Kl3n5 or 'فيلم' in wHiSfdBL1v9Kl3n5 or any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,112,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,113,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif '/actor/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,111,ggdRiBo3smurLUGO)
		elif '/series/' in wHiSfdBL1v9Kl3n5 and '/list' not in url:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'/list'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,111,ggdRiBo3smurLUGO)
		elif '/list' in url and 'حلقة' in title:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,112,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,113,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		if IOC7UWYc5MTHZbLx9VtXpn!='search': items = JJDtX1PZyIgN2T.findall('(updateQuery).*?>(.+?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		else: items = JJDtX1PZyIgN2T.findall('<li>.*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if IOC7UWYc5MTHZbLx9VtXpn!='search':
				title = title.replace('\n','').replace('\r','')
				if '?' in url: wHiSfdBL1v9Kl3n5 = url+'&page='+title
				else: wHiSfdBL1v9Kl3n5 = url+'?page='+title
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			if title: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,111,'','',IOC7UWYc5MTHZbLx9VtXpn)
	return
def sjmSkpqHVtPcv(url,HHGYL0qZdlnNoE3Tu4aeh):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','SHAHID4U-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('items d-flex(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if len(GGbRgKaoskDC)>1:
		if '/season/' in GGbRgKaoskDC[0]: YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME = GGbRgKaoskDC[0],GGbRgKaoskDC[1]
		else: YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME = GGbRgKaoskDC[1],GGbRgKaoskDC[0]
	else: YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME = GGbRgKaoskDC[0],GGbRgKaoskDC[0]
	for uvTwHSmjyW6Vr0192IZ in range(2):
		if HHGYL0qZdlnNoE3Tu4aeh: mode,type,mvgk7pP8Fw6heMSWd5oXn9itl = 116,'folder',YbPTE4rKt3cmIuz6WFdi
		else: mode,type,mvgk7pP8Fw6heMSWd5oXn9itl = 112,'video',l7PwAhTqWVUKME
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if HHGYL0qZdlnNoE3Tu4aeh and len(items)<2:
			HHGYL0qZdlnNoE3Tu4aeh = False
			continue
		for wHiSfdBL1v9Kl3n5,XVD2KB3xEJaU1stlpjP4kmo,LpB4ilMr6vVtQ in items:
			title = XVD2KB3xEJaU1stlpjP4kmo+' '+LpB4ilMr6vVtQ
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(type,eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,mode)
		break
	if not items and '/episodes' in YBEsLq8gVw629cMGQP1T:
		HqUnaLCQh9EVdI5NmBg = JJDtX1PZyIgN2T.findall('class="breadcrumb"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if HqUnaLCQh9EVdI5NmBg:
			mvgk7pP8Fw6heMSWd5oXn9itl = HqUnaLCQh9EVdI5NmBg[0]
			kwqYoF8han = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if len(kwqYoF8han)>2:
				wHiSfdBL1v9Kl3n5 = kwqYoF8han[2]+'list'
				d2JXnUMPmgsKBQqCE58lkZ(wHiSfdBL1v9Kl3n5)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','SHAHID4U-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="actions(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	kwqYoF8han = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	gyIhfnP5BuDFX8 = '/watch/' in mvgk7pP8Fw6heMSWd5oXn9itl
	download = '/download/' in mvgk7pP8Fw6heMSWd5oXn9itl
	if   gyIhfnP5BuDFX8 and not download: v2lrbuFeVEDJzP1Xw6QGBfTIdH57kR,XaGBdc08JkN = kwqYoF8han[0],''
	elif not gyIhfnP5BuDFX8 and download: v2lrbuFeVEDJzP1Xw6QGBfTIdH57kR,XaGBdc08JkN = '',kwqYoF8han[0]
	elif gyIhfnP5BuDFX8 and download: v2lrbuFeVEDJzP1Xw6QGBfTIdH57kR,XaGBdc08JkN = kwqYoF8han[0],kwqYoF8han[1]
	else: v2lrbuFeVEDJzP1Xw6QGBfTIdH57kR,XaGBdc08JkN = '',''
	if gyIhfnP5BuDFX8:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',v2lrbuFeVEDJzP1Xw6QGBfTIdH57kR,'',headers,'','','SHAHID4U-PLAY-2nd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		ooTeU5chRPu = JJDtX1PZyIgN2T.findall('let servers(.*?)player',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		if ooTeU5chRPu:
			DqrOZE3L85G = ooTeU5chRPu[0]
			uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('"name":"(.*?)".*?"url":"(.*?)"',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
			for title,wHiSfdBL1v9Kl3n5 in uaq5LNOdZJhV4fDwvcsnU17WrX:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\\/','/')
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if download:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',XaGBdc08JkN,'',headers,'','','SHAHID4U-PLAY-3rd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"servers"(.*?)info-container',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if ooTeU5chRPu:
			DqrOZE3L85G = ooTeU5chRPu[0]
			uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title,y2nBfLCjDoXkKiwb8WV6 in uaq5LNOdZJhV4fDwvcsnU17WrX:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'+'____'+y2nBfLCjDoXkKiwb8WV6
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/search?s='+search
	PeArnUDVym1pjBFaG,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,pmTdyfMuY6I3UQczZ = h7px9MIDvPwgZ2U6CNbT(jCJnzmXDkNqtB,'GET',url,'shahid4u','شاهد فوريو - Shahid 4u','facebook.com/shahid4u.net',headers)
	d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'search',pmTdyfMuY6I3UQczZ)
	return
def LWTgVSqXyoz26Hi931Ks(url):
	url = url.split('/smartemadfilter?')[0]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','SHAHID4U-GET_FILTERS_BLOCKS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	KKMpOd0rWFRNPtun5cgY6 = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('adv-filter(.*?)shows-container',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('''updateQuery\('(.*?)'.*?value>(.*?)<(.*?)</select''',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		TAiIlqcgn0hW5fd,UGN4yb8Wn9AitV,Ns3LKUFY21aQVf7e = zip(*KKMpOd0rWFRNPtun5cgY6)
		KKMpOd0rWFRNPtun5cgY6 = zip(UGN4yb8Wn9AitV,TAiIlqcgn0hW5fd,Ns3LKUFY21aQVf7e)
	return KKMpOd0rWFRNPtun5cgY6
def ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl):
	items = JJDtX1PZyIgN2T.findall('value="(.*?)".*?>\s*(.*?)\s*<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return items
def QQZgeAI91wf8HY5jtyMb6D(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	wHGCED2fklopYyFzI = url.split('/smartemadfilter?')[0]
	i1TCt53bykSvPp8e = OfTKisDR0Lv(url,'url')
	url = url.replace(wHGCED2fklopYyFzI,i1TCt53bykSvPp8e)
	url = url.replace('/smartemadfilter?','/?')
	return url
BBaZ5SyxRQ8njIgt6mOAU4N10irM = ['quality','year','genre','category']
Mqv3QIiNgfUXo18h5AeLOZrzSERa2d = ['category','genre','year']
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='DEFINED_FILTER':
		if Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0]
		for ggjo5zu7yCiIOhrb in range(len(Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0:-1])):
			if Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
	elif type=='FULL_FILTER':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+oju0BC1rJO
		kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',kHWT0XY2S6apruwxiB8FDl1,111)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',kHWT0XY2S6apruwxiB8FDl1,111)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KKMpOd0rWFRNPtun5cgY6 = LWTgVSqXyoz26Hi931Ks(url)
	dict = {}
	for name,eYFHT1CfSqZK,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		name = name.replace('كل ','')
		items = ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='DEFINED_FILTER':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<2:
				if eYFHT1CfSqZK==Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-1]:
					kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
					d2JXnUMPmgsKBQqCE58lkZ(kHWT0XY2S6apruwxiB8FDl1)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'DEFINED_FILTER___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				if eYFHT1CfSqZK==Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-1]:
					kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',kHWT0XY2S6apruwxiB8FDl1,111)
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,115,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='FULL_FILTER':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع :'+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,114,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if Y3YqSmycrIWksoH5N0MvC=='196533': khB9dCpWm4qPMrXTjgONf0Z = 'أفلام نيتفلكس'
			elif Y3YqSmycrIWksoH5N0MvC=='196531': khB9dCpWm4qPMrXTjgONf0Z = 'مسلسلات نيتفلكس'
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'#+dict[eYFHT1CfSqZK]['0']
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'+name
			if type=='FULL_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,114,'','',oy5AiZKfC86qITkYWL)
			elif type=='DEFINED_FILTER' and Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-2]+'=' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
				kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,111)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,115,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.replace('=&','=0&')
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	for key in BBaZ5SyxRQ8njIgt6mOAU4N10irM:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.replace('=0','=')
	return P1yxuh7MAmvSRVqLZcW6tY3
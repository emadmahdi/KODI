# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'ALARAB'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_KLA_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==10: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==11: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==12: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==13: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==14: mL7BVKcSygkuoPbWlEF4YD = bX4pueFyDgAm3SJOx5()
	elif mode==15: mL7BVKcSygkuoPbWlEF4YD = smfXDaNAcJekj4Bz0LqvrEu2hRClZT()
	elif mode==16: mL7BVKcSygkuoPbWlEF4YD = Xy2si4ejMCbF7KDtlAQp6zEaY()
	elif mode==19: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',19,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'آخر الإضافات','',14)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان','',15)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','ALARAB-MENU-1st')
	GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('id="nav-slider"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	pkciAXsFxq53lJPnEgGUBhoV4OeTQ7 = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',pkciAXsFxq53lJPnEgGUBhoV4OeTQ7,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
		title = title.strip(' ')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="navbar"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	DqrOZE3L85G = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,11)
	return YBEsLq8gVw629cMGQP1T
def smfXDaNAcJekj4Bz0LqvrEu2hRClZT():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'جميع المسلسلات العربية',kU2ZXSViB3wLANOz8bH+'/view-8/مسلسلات-عربية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات السنة الأخيرة','',16)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان الأخيرة 1',kU2ZXSViB3wLANOz8bH+'/view-8/مسلسلات-رمضان-2022',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان الأخيرة 2',kU2ZXSViB3wLANOz8bH+'/view-8/مسلسلات-رمضان-2023',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2023',kU2ZXSViB3wLANOz8bH+'/ramadan2023/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2022',kU2ZXSViB3wLANOz8bH+'/ramadan2022/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2021',kU2ZXSViB3wLANOz8bH+'/ramadan2021/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2020',kU2ZXSViB3wLANOz8bH+'/ramadan2020/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2019',kU2ZXSViB3wLANOz8bH+'/ramadan2019/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2018',kU2ZXSViB3wLANOz8bH+'/ramadan2018/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2017',kU2ZXSViB3wLANOz8bH+'/ramadan2017/مصرية',11)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات رمضان 2016',kU2ZXSViB3wLANOz8bH+'/ramadan2016/مصرية',11)
	return
def bX4pueFyDgAm3SJOx5():
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,kU2ZXSViB3wLANOz8bH,'',headers,True,'ALARAB-LATEST-1st')
	GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('heading-top(.*?)div class=',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]+GGbRgKaoskDC[1]
	items=JJDtX1PZyIgN2T.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		url = kU2ZXSViB3wLANOz8bH + wHiSfdBL1v9Kl3n5
		if 'series' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,11,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,url,12,ggdRiBo3smurLUGO)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,True,True,'ALARAB-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('video-category(.*?)right_content',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	heF3WEQo7w6s0apxnUIr9 = False
	items = JJDtX1PZyIgN2T.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ,GiMNQxDjEY79dlmSOqXah6wZFtPVK = [],[]
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if title=='': title = wHiSfdBL1v9Kl3n5.split('/')[-1].replace('-',' ')
		ttIZeP6yNoM7 = JJDtX1PZyIgN2T.findall('(\d+)',title,JJDtX1PZyIgN2T.DOTALL)
		if ttIZeP6yNoM7: ttIZeP6yNoM7 = int(ttIZeP6yNoM7[0])
		else: ttIZeP6yNoM7 = 0
		GiMNQxDjEY79dlmSOqXah6wZFtPVK.append([ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title,ttIZeP6yNoM7])
	GiMNQxDjEY79dlmSOqXah6wZFtPVK = sorted(GiMNQxDjEY79dlmSOqXah6wZFtPVK, reverse=True, key=lambda key: key[3])
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title,ttIZeP6yNoM7 in GiMNQxDjEY79dlmSOqXah6wZFtPVK:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH + wHiSfdBL1v9Kl3n5
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي','')
		title = title.replace('عالية على العرب','')
		title = title.replace('مشاهدة مباشرة','')
		title = title.replace('اون لاين','')
		title = title.replace('اونلاين','')
		title = title.replace('بجودة عالية','')
		title = title.replace('جودة عالية','')
		title = title.replace('بدون تحميل','')
		title = title.replace('على العرب','')
		title = title.replace('مباشرة','')
		title = title.strip(' ').replace('  ',' ').replace('  ',' ')
		title = '_MOD_'+title
		LpB4ilMr6vVtQ = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if vaQbluYS4GEsKCNwOymT1hFt: LpB4ilMr6vVtQ = vaQbluYS4GEsKCNwOymT1hFt[0]
		if LpB4ilMr6vVtQ not in ClXwqHm0DEMvI39agWyiRYopQ:
			ClXwqHm0DEMvI39agWyiRYopQ.append(LpB4ilMr6vVtQ)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,wHiSfdBL1v9Kl3n5,13,ggdRiBo3smurLUGO)
				heF3WEQo7w6s0apxnUIr9 = True
			elif 'series' in wHiSfdBL1v9Kl3n5:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,11,ggdRiBo3smurLUGO)
				heF3WEQo7w6s0apxnUIr9 = True
			else:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,12,ggdRiBo3smurLUGO)
				heF3WEQo7w6s0apxnUIr9 = True
	if heF3WEQo7w6s0apxnUIr9:
		items = JJDtX1PZyIgN2T.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,vYpMA3CxgcyR4VZJh in items:
			url = kU2ZXSViB3wLANOz8bH + wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+vYpMA3CxgcyR4VZJh,url,11)
	return
def sjmSkpqHVtPcv(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,True,'ALARAB-EPISODES-1st')
	ZyKr3DFwP7a5zXb = JJDtX1PZyIgN2T.findall('href="(/series.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+ZyKr3DFwP7a5zXb[0]
	mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P = []
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,True,'ALARAB-PLAY-1st')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('class="resp-iframe" src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
		kwqYoF8han = JJDtX1PZyIgN2T.findall('^(http.*?)(http.*?)$',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,JJDtX1PZyIgN2T.DOTALL)
		if kwqYoF8han:
			xg3XfdNISH5la = kwqYoF8han[0][0]
			rpuGNmQ41MECRUIbTzZ,JhSjlfyTvCVRKo9u4ZP5Bzk = kwqYoF8han[0][1].rsplit('/',1)
			kHWT0XY2S6apruwxiB8FDl1 = rpuGNmQ41MECRUIbTzZ+'?named=__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(kHWT0XY2S6apruwxiB8FDl1)
			XTNUWlZgoH = xg3XfdNISH5la+JhSjlfyTvCVRKo9u4ZP5Bzk
		else:
			Plj7MGOHohwdvam2ynfVY1z = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,False,'ALARAB-PLAY-2nd')
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('"src": "(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]+'?named=__watch__m3u8'
				EEgFl59RndzrBL8TUoaQMw6P.append(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('searchBox(.*?)<style>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]+'?named=__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def Xy2si4ejMCbF7KDtlAQp6zEaY():
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,True,'ALARAB-RAMADAN-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="content_sec"(.*?)id="left_content"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	FHkUwxKos5c2aQ3D6e = JJDtX1PZyIgN2T.findall('/ramadan([0-9]+)/',str(items),JJDtX1PZyIgN2T.DOTALL)
	FHkUwxKos5c2aQ3D6e = FHkUwxKos5c2aQ3D6e[0]
	for wHiSfdBL1v9Kl3n5,title in items:
		url = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
		title = title.strip(' ')+' '+FHkUwxKos5c2aQ3D6e
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,11)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + "/q/" + s2hzmL48wFudNE5
	mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	return
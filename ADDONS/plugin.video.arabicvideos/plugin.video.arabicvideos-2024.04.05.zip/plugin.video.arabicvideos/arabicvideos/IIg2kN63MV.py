# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'MOVIZLAND'
headers = { 'User-Agent' : '' }
eMlwAzaLSj8ZEQ3txIGP = '_MVZ_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
kHZn1cEVXyGNTRug3 = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][1]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==180: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==181: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==182: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==183: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==188: mL7BVKcSygkuoPbWlEF4YD = vvluIPrLTh5MEBiCHNmy62()
	elif mode==189: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def vvluIPrLTh5MEBiCHNmy62():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج',message)
	return
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',189,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بوكس اوفيس موفيز لاند',kU2ZXSViB3wLANOz8bH,181,'','','box-office')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'أحدث الافلام',kU2ZXSViB3wLANOz8bH,181,'','','latest-movies')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'تليفزيون موفيز لاند',kU2ZXSViB3wLANOz8bH,181,'','','tv')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الاكثر مشاهدة',kU2ZXSViB3wLANOz8bH,181,'','','top-views')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'أقوى الافلام الحالية',kU2ZXSViB3wLANOz8bH,181,'','','top-movies')
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','MOVIZLAND-MENU-1st')
	items = JJDtX1PZyIgN2T.findall('<h2><a href="(.*?)".*?">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,181)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	elif type=='box-office': mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	elif type=='top-movies': mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('btn-2-overlay(.*?)<style>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	elif type=='top-views': mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	elif type=='tv': mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	else: mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
	if type in ['top-views','top-movies']:
		items = JJDtX1PZyIgN2T.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	else: items = JJDtX1PZyIgN2T.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	qqMcamz27wdPHLID = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for ggdRiBo3smurLUGO,cJsUR2bM3WZmAFT,RZdc3HWpJk,lIzHShWcUsPwjAVR9digvNLM3 in items:
		if type in ['top-views','top-movies']:
			ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,tb4p6sRlFPcio,title = ggdRiBo3smurLUGO,cJsUR2bM3WZmAFT,RZdc3HWpJk,lIzHShWcUsPwjAVR9digvNLM3
		else: ggdRiBo3smurLUGO,title,wHiSfdBL1v9Kl3n5,tb4p6sRlFPcio = ggdRiBo3smurLUGO,cJsUR2bM3WZmAFT,RZdc3HWpJk,lIzHShWcUsPwjAVR9digvNLM3
		wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('?view=true','')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		title = title.strip(' ')
		if 'الحلقة' in title or 'الحلقه' in title:
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|الحلقه) \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if vaQbluYS4GEsKCNwOymT1hFt:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0][0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,183,ggdRiBo3smurLUGO)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in qqMcamz27wdPHLID):
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5 + '?servers=' + tb4p6sRlFPcio
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,182,ggdRiBo3smurLUGO)
		else:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5 + '?servers=' + tb4p6sRlFPcio
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,183,ggdRiBo3smurLUGO)
	if type=='':
		items = JJDtX1PZyIgN2T.findall('\n<li><a href="(.*?)".*?>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = title.replace('الصفحة ','')
			if title!='':
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,181)
	return
def sjmSkpqHVtPcv(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.split('?servers=')[0]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','MOVIZLAND-EPISODES-1st')
	mvgk7pP8Fw6heMSWd5oXn9itl = JJDtX1PZyIgN2T.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	title,g5lf2u4DxNp8imnYevK,ggdRiBo3smurLUGO = mvgk7pP8Fw6heMSWd5oXn9itl[0]
	name = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,JJDtX1PZyIgN2T.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="episodesNumbers"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in items:
			wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
			title = JJDtX1PZyIgN2T.findall('(الحلقة|الحلقه)-([0-9]+)',wHiSfdBL1v9Kl3n5.split('/')[-2],JJDtX1PZyIgN2T.DOTALL)
			if not title: title = JJDtX1PZyIgN2T.findall('()-([0-9]+)',wHiSfdBL1v9Kl3n5.split('/')[-2],JJDtX1PZyIgN2T.DOTALL)
			if title: title = ' ' + title[0][1]
			else: title = ''
			title = name + ' - ' + 'الحلقة' + title
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,182,ggdRiBo3smurLUGO)
	if not items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ','').replace('بجوده ','')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,url,182,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	MdgvNCbsQAkFY945Llj6o = url.split('?servers=')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = MdgvNCbsQAkFY945Llj6o[0]
	del MdgvNCbsQAkFY945Llj6o[0]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','MOVIZLAND-PLAY-1st')
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('font-size: 25px;" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	if wHiSfdBL1v9Kl3n5 not in MdgvNCbsQAkFY945Llj6o: MdgvNCbsQAkFY945Llj6o.append(wHiSfdBL1v9Kl3n5)
	EEgFl59RndzrBL8TUoaQMw6P = []
	for wHiSfdBL1v9Kl3n5 in MdgvNCbsQAkFY945Llj6o:
		if '://moshahda.' in wHiSfdBL1v9Kl3n5:
			GGLNig4r5VtO3PuwWhZfAp = wHiSfdBL1v9Kl3n5
			EEgFl59RndzrBL8TUoaQMw6P.append(GGLNig4r5VtO3PuwWhZfAp+'?named=Main')
	for wHiSfdBL1v9Kl3n5 in MdgvNCbsQAkFY945Llj6o:
		if '://vb.movizland.' in wHiSfdBL1v9Kl3n5:
			YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,wHiSfdBL1v9Kl3n5,'',headers,'','MOVIZLAND-PLAY-2nd')
			YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.decode('windows-1256').encode('utf8')
			YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if GGbRgKaoskDC:
				nUTDz3uCgEsYJt,R8nkA2aSmYx4QMw = [],[]
				if len(GGbRgKaoskDC)==1:
					title = ''
					mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
				else:
					for mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
						DqrOZE3L85G = JJDtX1PZyIgN2T.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
						if DqrOZE3L85G: mvgk7pP8Fw6heMSWd5oXn9itl = 'src="/uploads/13721411411.png"  \n  ' + DqrOZE3L85G[0][1]
						DqrOZE3L85G = JJDtX1PZyIgN2T.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
						if DqrOZE3L85G: mvgk7pP8Fw6heMSWd5oXn9itl = 'src="/uploads/13721411411.png"  \n  ' + DqrOZE3L85G[0]
						DqrOZE3L85G = JJDtX1PZyIgN2T.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
						if DqrOZE3L85G: mvgk7pP8Fw6heMSWd5oXn9itl = DqrOZE3L85G[0] + '  \n  src="/uploads/13721411411.png"'
						IC2kMWmvXGAV9QFlDNyHoq = JJDtX1PZyIgN2T.findall('<(.*?)http://up.movizland.(online|com)/uploads/',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
						title = JJDtX1PZyIgN2T.findall('> *([^<>]+) *<',IC2kMWmvXGAV9QFlDNyHoq[0][0],JJDtX1PZyIgN2T.DOTALL)
						title = ' '.join(title)
						title = title.strip(' ')
						title = title.replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
						nUTDz3uCgEsYJt.append(title)
					zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر الفيديو المطلوب:', nUTDz3uCgEsYJt)
					if zKgFfQoODy90ewYb5jGElUJRVs4p == -1 : return
					title = nUTDz3uCgEsYJt[zKgFfQoODy90ewYb5jGElUJRVs4p]
					mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[zKgFfQoODy90ewYb5jGElUJRVs4p]
				wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('href="(http://moshahda\..*?/\w+.html)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				KeAZHpQoa9sPFRgktvCWyMr4 = wHiSfdBL1v9Kl3n5[0]
				EEgFl59RndzrBL8TUoaQMw6P.append(KeAZHpQoa9sPFRgktvCWyMr4+'?named=Forum')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('ـ','')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				mvgk7pP8Fw6heMSWd5oXn9itl = mvgk7pP8Fw6heMSWd5oXn9itl.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				CC1uA76awEhjz = JJDtX1PZyIgN2T.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for QQjudSRvzGsrnH9ADXCNL in CC1uA76awEhjz:
					type = JJDtX1PZyIgN2T.findall(' typetype="(.*?)" ',QQjudSRvzGsrnH9ADXCNL)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = ''
					items = JJDtX1PZyIgN2T.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',QQjudSRvzGsrnH9ADXCNL,JJDtX1PZyIgN2T.DOTALL)
					for LjcU9ymEox8rF2YI4RnZ3egKJ,wHiSfdBL1v9Kl3n5 in items:
						title = JJDtX1PZyIgN2T.findall('(\w+[ \w]*)<',LjcU9ymEox8rF2YI4RnZ3egKJ)
						title = title[-1]
						wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5 + '?named=' + title + type
						EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace(kU2ZXSViB3wLANOz8bH,kHZn1cEVXyGNTRug3)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kHWT0XY2S6apruwxiB8FDl1,'',headers,'','MOVIZLAND-PLAY-3rd')
	items = JJDtX1PZyIgN2T.findall('" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		Rdfz6jZnTw0BqHLSX4Dxe8hsJECVr = items[-1]
		EEgFl59RndzrBL8TUoaQMw6P.append(Rdfz6jZnTw0BqHLSX4Dxe8hsJECVr+'?named=Mobile')
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,kU2ZXSViB3wLANOz8bH,'',headers,'','MOVIZLAND-SEARCH-1st')
	items = JJDtX1PZyIgN2T.findall('<option value="(.*?)">(.*?)</option>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	o2KzOb81h5fLkQUwGvFDrWjHlN0dnS = [ '' ]
	v7TW8Yc3u6fe02IsxymKD = [ 'الكل وبدون فلتر' ]
	for qGsE8fdyFtUwBnu,title in items:
		o2KzOb81h5fLkQUwGvFDrWjHlN0dnS.append(qGsE8fdyFtUwBnu)
		v7TW8Yc3u6fe02IsxymKD.append(title)
	if qGsE8fdyFtUwBnu:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الفلتر المناسب:', v7TW8Yc3u6fe02IsxymKD)
		if zKgFfQoODy90ewYb5jGElUJRVs4p == -1 : return
		qGsE8fdyFtUwBnu = o2KzOb81h5fLkQUwGvFDrWjHlN0dnS[zKgFfQoODy90ewYb5jGElUJRVs4p]
	else: qGsE8fdyFtUwBnu = ''
	url = kU2ZXSViB3wLANOz8bH + '/?s='+search+'&mcat='+qGsE8fdyFtUwBnu
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
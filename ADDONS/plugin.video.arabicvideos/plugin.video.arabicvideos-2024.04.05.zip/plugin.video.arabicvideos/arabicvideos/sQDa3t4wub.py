# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'BOKRA'
eMlwAzaLSj8ZEQ3txIGP = '_BKR_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
headers = {'User-Agent':''}
eJzpdvc3KTust = ['افلام للكبار','بكرا TV']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==370: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==371: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==372: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==374: mL7BVKcSygkuoPbWlEF4YD = tJ94DpofBPCFke7dl1jGISOVabhc(url)
	elif mode==375: mL7BVKcSygkuoPbWlEF4YD = VVTjE7Sh1MoYvcqteU2BnQF3ayCK(url)
	elif mode==376: mL7BVKcSygkuoPbWlEF4YD = L0Nkerh3P8qRylYZbfKXi5TSd6CgO(0,url)
	elif mode==377: mL7BVKcSygkuoPbWlEF4YD = L0Nkerh3P8qRylYZbfKXi5TSd6CgO(1,url)
	elif mode==379: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','BOKRA-MENU-1st')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',379,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('right-side(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المميزة',kU2ZXSViB3wLANOz8bH,375)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الأحدث',kU2ZXSViB3wLANOz8bH,376)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'قائمة الممثلين',kU2ZXSViB3wLANOz8bH,374)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="container"(.*?)top-menu',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items[7:]:
			title = title.strip(' ')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371)
		for wHiSfdBL1v9Kl3n5,title in items[0:7]:
			title = title.strip(' ')
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371)
	return
def tJ94DpofBPCFke7dl1jGISOVabhc(website=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','BOKRA-ACTORSMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="row cat Tags"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if 'http' in wHiSfdBL1v9Kl3n5: continue
			else: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371)
	return
def VVTjE7Sh1MoYvcqteU2BnQF3ayCK(website=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,'','','','','BOKRA-FEATURED-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"MainContent"(.*?)main-title2',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('://',':///').replace('//','/').replace(' ','%20')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,372,ggdRiBo3smurLUGO)
	return
def L0Nkerh3P8qRylYZbfKXi5TSd6CgO(id,website=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,'','','','','BOKRA-WATCHINGNOW-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-title2(.*?)class="row',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[id]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('://',':///').replace('//','/').replace(' ','%20')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,372,ggdRiBo3smurLUGO)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,bNmWIyOl9Le2xg8BzFthCYT0f1q3Z=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','BOKRA-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if 'vidpage_' in url:
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('href="(/Album-.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if wHiSfdBL1v9Kl3n5:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5[0]
			d2JXnUMPmgsKBQqCE58lkZ(wHiSfdBL1v9Kl3n5)
			return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class=" subcats"(.*?)class="col-md-3',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if bNmWIyOl9Le2xg8BzFthCYT0f1q3Z=='' and GGbRgKaoskDC and GGbRgKaoskDC[0].count('href')>1:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',url,371,'','','titles')
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371)
	else:
		ClXwqHm0DEMvI39agWyiRYopQ = []
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="col-md-3(.*?)col-xs-12',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="col-sm-8"(.*?)col-xs-12',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
				title = title.strip(' ')
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.replace('://',':///').replace('//','/').replace(' ','%20')
				if '/al_' in wHiSfdBL1v9Kl3n5:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371,ggdRiBo3smurLUGO)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) - +الحلقة +\d+',title,JJDtX1PZyIgN2T.DOTALL)
					if vaQbluYS4GEsKCNwOymT1hFt: title = '_MOD_مسلسل '+vaQbluYS4GEsKCNwOymT1hFt[0]
					if title not in ClXwqHm0DEMvI39agWyiRYopQ:
						ClXwqHm0DEMvI39agWyiRYopQ.append(title)
						nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371,ggdRiBo3smurLUGO)
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,372,ggdRiBo3smurLUGO)
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('class="".*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
				title = 'صفحة '+jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,371,'','','titles')
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','BOKRA-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('label-success mrg-btm-5 ">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	kHWT0XY2S6apruwxiB8FDl1 = ''
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('var url = "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('/vidpage_','/Play/')
	if 'http' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+FrC9LhHZWIySdGwNsuzqt5Rf01TXO
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.strip('-')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','BOKRA-PLAY-2nd')
	Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	kHWT0XY2S6apruwxiB8FDl1 = JJDtX1PZyIgN2T.findall('src="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
	if kHWT0XY2S6apruwxiB8FDl1:
		kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1[-1]
		if 'http' not in kHWT0XY2S6apruwxiB8FDl1: kHWT0XY2S6apruwxiB8FDl1 = 'http:'+kHWT0XY2S6apruwxiB8FDl1
		if '/PLAY/' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			if 'embed.min.js' in kHWT0XY2S6apruwxiB8FDl1:
				ND4Pd9OtH2Mc = JJDtX1PZyIgN2T.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
				if ND4Pd9OtH2Mc:
					FpPCiXBzK5y3foS7GEnxd2bT, ug23BsJ86OlNnRb91kexLE = ND4Pd9OtH2Mc[0]
					kHWT0XY2S6apruwxiB8FDl1 = OfTKisDR0Lv(kHWT0XY2S6apruwxiB8FDl1,'url')+'/v2/'+FpPCiXBzK5y3foS7GEnxd2bT+'/config/'+ug23BsJ86OlNnRb91kexLE+'.json'
		import jfGcn9x8KN
		jfGcn9x8KN.AkMyd9E2pVrbG7g5([kHWT0XY2S6apruwxiB8FDl1],FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/Search/'+search
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
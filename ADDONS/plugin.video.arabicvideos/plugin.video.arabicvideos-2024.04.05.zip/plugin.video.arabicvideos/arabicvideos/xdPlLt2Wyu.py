# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'ALFATIMI'
eMlwAzaLSj8ZEQ3txIGP = '_FTM_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
KxRVJD3qMo9 = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
iLJXx8N62HME0DgS5BKqOml = ['3030','628']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==60: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==61: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==62: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==63: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==64: mL7BVKcSygkuoPbWlEF4YD = Gd39UEsHQxayAX7zNpo2SLVlibfr(text)
	elif mode==69: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',69,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'ما يتم مشاهدته الان',kU2ZXSViB3wLANOz8bH,64,'','','recent_viewed_vids')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الاكثر مشاهدة',kU2ZXSViB3wLANOz8bH,64,'','','most_viewed_vids')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'اضيفت مؤخرا',kU2ZXSViB3wLANOz8bH,64,'','','recently_added_vids')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'فيديو عشوائي',kU2ZXSViB3wLANOz8bH,64,'','','random_vids')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'افلام ومسلسلات',kU2ZXSViB3wLANOz8bH,61,'','','-1')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'البرامج الدينية',kU2ZXSViB3wLANOz8bH,61,'','','-2')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'English Videos',kU2ZXSViB3wLANOz8bH,61,'','','-3')
	return ''
def d2JXnUMPmgsKBQqCE58lkZ(url,qGsE8fdyFtUwBnu):
	DoFa7TOYKcSrJARPgwuzk = ''
	if qGsE8fdyFtUwBnu not in ['-1','-2','-3']: DoFa7TOYKcSrJARPgwuzk = '?cat='+qGsE8fdyFtUwBnu
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/menu_level.php'+DoFa7TOYKcSrJARPgwuzk
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','ALFATIMI-TITLES-1st')
	items = JJDtX1PZyIgN2T.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	eeZtLSEPCihApfcvN9QHY,heF3WEQo7w6s0apxnUIr9 = False,False
	for wHiSfdBL1v9Kl3n5,title,count in items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		title = title.strip(' ')
		if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
		DoFa7TOYKcSrJARPgwuzk = JJDtX1PZyIgN2T.findall('cat=(.*?)&',wHiSfdBL1v9Kl3n5,JJDtX1PZyIgN2T.DOTALL)[0]
		if qGsE8fdyFtUwBnu==DoFa7TOYKcSrJARPgwuzk: eeZtLSEPCihApfcvN9QHY = True
		elif eeZtLSEPCihApfcvN9QHY 	or (qGsE8fdyFtUwBnu=='-1' and DoFa7TOYKcSrJARPgwuzk in KxRVJD3qMo9)  						or (qGsE8fdyFtUwBnu=='-2' and DoFa7TOYKcSrJARPgwuzk not in iLJXx8N62HME0DgS5BKqOml and DoFa7TOYKcSrJARPgwuzk not in KxRVJD3qMo9)  						or (qGsE8fdyFtUwBnu=='-3' and DoFa7TOYKcSrJARPgwuzk in iLJXx8N62HME0DgS5BKqOml):
							if count=='1': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,63)
							else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,61,'','',DoFa7TOYKcSrJARPgwuzk)
							heF3WEQo7w6s0apxnUIr9 = True
	if not heF3WEQo7w6s0apxnUIr9: sjmSkpqHVtPcv(url)
	return
def sjmSkpqHVtPcv(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','',True,'ALFATIMI-EPISODES-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('pagination(.*?)id="footer',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	wHiSfdBL1v9Kl3n5 = ''
	for ggdRiBo3smurLUGO,title,wHiSfdBL1v9Kl3n5 in items:
		title = title.replace('Add','').replace('to Quicklist','').strip(' ')
		if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,63,ggdRiBo3smurLUGO)
	GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('(.*?)div',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl=GGbRgKaoskDC[0]
	mvgk7pP8Fw6heMSWd5oXn9itl=JJDtX1PZyIgN2T.findall('pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	items=JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.split('?')[0]
	for wHiSfdBL1v9Kl3n5,zzMCtO8apGR3A5H9jL4wNulv0 in items:
		wHiSfdBL1v9Kl3n5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO + wHiSfdBL1v9Kl3n5
		title = jbigKDeUf0OSMrRkly2B5I3Act(zzMCtO8apGR3A5H9jL4wNulv0)
		title = 'صفحة ' + title
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,62)
	return wHiSfdBL1v9Kl3n5
def CsUdRabWuh0M9F(url):
	if 'videos.php' in url: url = sjmSkpqHVtPcv(url)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'','',True,'ALFATIMI-PLAY-1st')
	items = JJDtX1PZyIgN2T.findall('playlistfile:"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	XbzQHGJ0cBV(url,FpjtBKrnu5SdfyOvEPIQ,'video')
	return
def Gd39UEsHQxayAX7zNpo2SLVlibfr(qGsE8fdyFtUwBnu):
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'mode' : qGsE8fdyFtUwBnu }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = lfM8WO96En(zAkbOyR9ZirYWxTwvMqouPLBjeQ20)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
		title = title.strip(' ')
		if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,63,ggdRiBo3smurLUGO)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + '/search_result.php?query=' + s2hzmL48wFudNE5
	sjmSkpqHVtPcv(url)
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'WECIMA'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_WCM_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['مصارعة حرة','wwe']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==560: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==561: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==562: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==563: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url,text)
	elif mode==564: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'CATEGORIES___'+text)
	elif mode==565: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'FILTERS___'+text)
	elif mode==566: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==569: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text,url)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع',kU2ZXSViB3wLANOz8bH,569,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',kU2ZXSViB3wLANOz8bH+'/AjaxCenter/RightBar',564)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',kU2ZXSViB3wLANOz8bH+'/AjaxCenter/RightBar',565)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','WECIMA-MENU-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('class="menu-item.*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title=='': continue
			if any(Y3YqSmycrIWksoH5N0MvC in title.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,566)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('hoverable activable(.*?)hoverable activable',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,566,ggdRiBo3smurLUGO)
	return YBEsLq8gVw629cMGQP1T
def YsCotEfMBv03z7mg(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','WECIMA-SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if 'class="Slider--Grid"' in YBEsLq8gVw629cMGQP1T:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',url,561,'','','featured')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="list--Tabsui"(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,561)
	return
def d2JXnUMPmgsKBQqCE58lkZ(YzFWKTy3jiJGsUEk8XRIgDNtB4u7x,type=''):
	if '::' in YzFWKTy3jiJGsUEk8XRIgDNtB4u7x:
		kHWT0XY2S6apruwxiB8FDl1,url = YzFWKTy3jiJGsUEk8XRIgDNtB4u7x.split('::')
		RgNSOU7P93n = OfTKisDR0Lv(kHWT0XY2S6apruwxiB8FDl1,'url')
		url = RgNSOU7P93n+url
	else: url,kHWT0XY2S6apruwxiB8FDl1 = YzFWKTy3jiJGsUEk8XRIgDNtB4u7x,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','WECIMA-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if type=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	elif type in ['filters','search']:
		GGbRgKaoskDC = [YBEsLq8gVw629cMGQP1T.replace('\\/','/').replace('\\"','"')]
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"Grid--WecimaPosts"(.*?)"RightUI"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
			if any(Y3YqSmycrIWksoH5N0MvC in title.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			ggdRiBo3smurLUGO = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(ggdRiBo3smurLUGO)
			wHiSfdBL1v9Kl3n5 = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(wHiSfdBL1v9Kl3n5)
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
			title = title.replace('مشاهدة ','')
			if '/series/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,563,ggdRiBo3smurLUGO)
			elif 'حلقة' in title:
				vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) +حلقة +\d+',title,JJDtX1PZyIgN2T.DOTALL)
				if vaQbluYS4GEsKCNwOymT1hFt: title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,563,ggdRiBo3smurLUGO)
			else:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,562,ggdRiBo3smurLUGO)
		if type=='filters':
			GHwMQ6AEyDKr3LuYheqRFkOWJg12C = JJDtX1PZyIgN2T.findall('"more_button_page":(.*?),',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if GHwMQ6AEyDKr3LuYheqRFkOWJg12C:
				count = GHwMQ6AEyDKr3LuYheqRFkOWJg12C[0]
				wHiSfdBL1v9Kl3n5 = url+'/offset/'+count
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة أخرى',wHiSfdBL1v9Kl3n5,561,'','','filters')
		elif type=='':
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if GGbRgKaoskDC:
				mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
				items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,title in items:
					if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
					title = 'صفحة '+jbigKDeUf0OSMrRkly2B5I3Act(title)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,561)
	return
def sjmSkpqHVtPcv(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','WECIMA-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YBEsLq8gVw629cMGQP1T = i35i6al7upCAreLFQ(YBEsLq8gVw629cMGQP1T)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="Seasons--Episodes"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not type and GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if len(items)>1:
			for wHiSfdBL1v9Kl3n5,title in items:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,563,'','','episodes')
			return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,562)
	if not PL2fM9WhpjEFb7:
		title = JJDtX1PZyIgN2T.findall('<title>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if title: title = title[0].replace(' - ماي سيما','').replace('مشاهدة ','')
		else: title = 'ملف التشغيل'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,url,562)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','WECIMA-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C:
		lAnLtvg62C = [lAnLtvg62C[0][0],lAnLtvg62C[0][1]]
		if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('data-url="(.*?)".*?strong>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			if name=='سيرفر وي سيما': name = 'wecima'
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__watch'
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\n','').replace('\r','')
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="List--Download(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			y2nBfLCjDoXkKiwb8WV6 = JJDtX1PZyIgN2T.findall('\d\d\d+',y2nBfLCjDoXkKiwb8WV6,JJDtX1PZyIgN2T.DOTALL)
			if y2nBfLCjDoXkKiwb8WV6: y2nBfLCjDoXkKiwb8WV6 = '____'+y2nBfLCjDoXkKiwb8WV6[0]
			else: y2nBfLCjDoXkKiwb8WV6 = ''
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named=wecima'+'__download'+y2nBfLCjDoXkKiwb8WV6
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\n','').replace('\r','')
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search,mfshVonrbcL6l93pNdK4w=''):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	if not mfshVonrbcL6l93pNdK4w:
		mfshVonrbcL6l93pNdK4w = kU2ZXSViB3wLANOz8bH
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = mfshVonrbcL6l93pNdK4w+'/AjaxCenter/Searching/'+search+'/'
	d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'search')
	return
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(YzFWKTy3jiJGsUEk8XRIgDNtB4u7x,filter):
	if '??' in YzFWKTy3jiJGsUEk8XRIgDNtB4u7x: url = YzFWKTy3jiJGsUEk8XRIgDNtB4u7x.split('//getposts??')[0]
	else: url = YzFWKTy3jiJGsUEk8XRIgDNtB4u7x
	filter = filter.replace('_FORGETRESULTS_','')
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='CATEGORIES':
		if qsd31N2pf9IyitMCSleF4[0]+'==' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = qsd31N2pf9IyitMCSleF4[0]
		for ggjo5zu7yCiIOhrb in range(len(qsd31N2pf9IyitMCSleF4[0:-1])):
			if qsd31N2pf9IyitMCSleF4[ggjo5zu7yCiIOhrb]+'==' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = qsd31N2pf9IyitMCSleF4[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+qGsE8fdyFtUwBnu+'==0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+qGsE8fdyFtUwBnu+'==0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'//getposts??'+ssnIblOr0uX
	elif type=='FILTERS':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'//getposts??'+oju0BC1rJO
		XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',XTNUWlZgoH,561,'','','filters')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',XTNUWlZgoH,561,'','','filters')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','WECIMA-FILTERS_MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('\\"','"').replace('\\/','/')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<wecima--filter(.*?)</wecima--filter>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',mvgk7pP8Fw6heMSWd5oXn9itl+'<filterbox',JJDtX1PZyIgN2T.DOTALL)
	dict = {}
	for eYFHT1CfSqZK,name,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		name = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(name)
		if 'interest' in eYFHT1CfSqZK: continue
		items = JJDtX1PZyIgN2T.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if '==' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='CATEGORIES':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<=1:
				if eYFHT1CfSqZK==qsd31N2pf9IyitMCSleF4[-1]: d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'CATEGORIES___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x)
				if eYFHT1CfSqZK==qsd31N2pf9IyitMCSleF4[-1]:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',XTNUWlZgoH,561,'','','filters')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,564,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='FILTERS':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+eYFHT1CfSqZK+'==0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+eYFHT1CfSqZK+'==0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+name+': الجميع',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,565,'','',ekFcZbonSHxsBqC7MU8hV+'_FORGETRESULTS_')
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			name = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(name)
			khB9dCpWm4qPMrXTjgONf0Z = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(khB9dCpWm4qPMrXTjgONf0Z)
			if Y3YqSmycrIWksoH5N0MvC=='r' or Y3YqSmycrIWksoH5N0MvC=='nc-17': continue
			if any(Y3YqSmycrIWksoH5N0MvC in khB9dCpWm4qPMrXTjgONf0Z.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' in khB9dCpWm4qPMrXTjgONf0Z: continue
			if 'الكل' in khB9dCpWm4qPMrXTjgONf0Z: continue
			if 'n-a' in Y3YqSmycrIWksoH5N0MvC: continue
			if khB9dCpWm4qPMrXTjgONf0Z=='': khB9dCpWm4qPMrXTjgONf0Z = Y3YqSmycrIWksoH5N0MvC
			XVD2KB3xEJaU1stlpjP4kmo = khB9dCpWm4qPMrXTjgONf0Z
			GTatBJjWw7qsmAXOv = JJDtX1PZyIgN2T.findall('<name>(.*?)</name>',khB9dCpWm4qPMrXTjgONf0Z,JJDtX1PZyIgN2T.DOTALL)
			if GTatBJjWw7qsmAXOv: XVD2KB3xEJaU1stlpjP4kmo = GTatBJjWw7qsmAXOv[0]
			LpB4ilMr6vVtQ = name+': '+XVD2KB3xEJaU1stlpjP4kmo
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = LpB4ilMr6vVtQ
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+eYFHT1CfSqZK+'=='+XVD2KB3xEJaU1stlpjP4kmo
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+eYFHT1CfSqZK+'=='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			if type=='FILTERS':
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url,565,'','',oy5AiZKfC86qITkYWL+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and qsd31N2pf9IyitMCSleF4[-2]+'==' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
				kHWT0XY2S6apruwxiB8FDl1 = url+'//getposts??'+ssnIblOr0uX
				XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(kHWT0XY2S6apruwxiB8FDl1,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,XTNUWlZgoH,561,'','','filters')
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url,564,'','',oy5AiZKfC86qITkYWL)
	return
qsd31N2pf9IyitMCSleF4 = ['genre','release-year','nation']
m4mRIeW8Od9ByfuMKHv = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def WAlh0r2supMG4Jzb3RfcwmF(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,kHWT0XY2S6apruwxiB8FDl1):
	if '/AjaxCenter/RightBar' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('//getposts??','::/AjaxCenter/Filtering/')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('==','/')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('&&','/')
	return FrC9LhHZWIySdGwNsuzqt5Rf01TXO
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&&')
	bHErtloWDJ3YCFvSfqLN1e7IVh,P1yxuh7MAmvSRVqLZcW6tY3 = {},''
	if '==' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('==')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	for key in m4mRIeW8Od9ByfuMKHv:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&&'+key+'=='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&&'+key+'=='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&&')
	return P1yxuh7MAmvSRVqLZcW6tY3
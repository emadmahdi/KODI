# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'RESOLVERS'
lX49jEyMD86wZ125FPtNSuoBbs = []
headers = {'User-Agent':''}
XX1MhWr3KH0Z = ['AKWAM','SHOOFMAX','IFILM','KARBALATV','ALMAAREF','SHIAVOICE','IPTV','M3U']
def AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,source,type,url):
	if not pB8XANf71vaPJsedkWVIc5:
		b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		WGdr0QRsTcLg97m1j56UvnChP = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'dict','MISC_PERM','SITES_ERRORS')
		ivc0RJCBlgr9wzqfbYLaFOEA = Mrx2OeZV1LNjBsQ58Savi7.strftime('%Y.%m.%d %H:%M',Mrx2OeZV1LNjBsQ58Savi7.gmtime(uZ7xiFaBvSrWG2mXjITp))
		dSvlymbao9Zs6t = ivc0RJCBlgr9wzqfbYLaFOEA,url
		key = source+'    '+K0dHTfq6P73sD8lWLZpoh+'    '+str(WWSLAyQdhUXl3ovb)
		Ay3eLGaTncD67lx8ZOud = ''
		if key not in list(WGdr0QRsTcLg97m1j56UvnChP.keys()): WGdr0QRsTcLg97m1j56UvnChP[key] = [dSvlymbao9Zs6t]
		else:
			if url not in str(WGdr0QRsTcLg97m1j56UvnChP[key]): WGdr0QRsTcLg97m1j56UvnChP[key].append(dSvlymbao9Zs6t)
			else: Ay3eLGaTncD67lx8ZOud = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		yCGWPZbfzX2TsqJQui = 0
		for key in list(WGdr0QRsTcLg97m1j56UvnChP.keys()):
			WGdr0QRsTcLg97m1j56UvnChP[key] = list(set(WGdr0QRsTcLg97m1j56UvnChP[key]))
			yCGWPZbfzX2TsqJQui += len(WGdr0QRsTcLg97m1j56UvnChP[key])
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+Ay3eLGaTncD67lx8ZOud+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(yCGWPZbfzX2TsqJQui))
		if yCGWPZbfzX2TsqJQui>=5:
			J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt('','','','رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==1:
				w4ZOJYBAlRq19xEfzcUmajsWkXNuIC = ''
				for key in list(WGdr0QRsTcLg97m1j56UvnChP.keys()):
					w4ZOJYBAlRq19xEfzcUmajsWkXNuIC += '\n'+key
					KGDUJCezWSEAX9iTZ18Y7p = sorted(WGdr0QRsTcLg97m1j56UvnChP[key],reverse=False,key=lambda QGj3nZ8hOAwXk4FLUzVYlid1: QGj3nZ8hOAwXk4FLUzVYlid1[0])
					for ivc0RJCBlgr9wzqfbYLaFOEA,url in KGDUJCezWSEAX9iTZ18Y7p:
						w4ZOJYBAlRq19xEfzcUmajsWkXNuIC += '\n'+ivc0RJCBlgr9wzqfbYLaFOEA+'    '+i35i6al7upCAreLFQ(url)
					w4ZOJYBAlRq19xEfzcUmajsWkXNuIC += '\n\n'
				import COH7BKApEP
				llC9WmbrAIgpzfi3n = COH7BKApEP.B4vT1EflKxbA9IaiG8U6Ck0('Videos','',False,'','RESOLVERS-PLAY_RESOLVERS','',w4ZOJYBAlRq19xEfzcUmajsWkXNuIC)
				if llC9WmbrAIgpzfi3n: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم الإرسال بنجاح')
				else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','فشلت عملية الإرسال')
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=-1:
				WGdr0QRsTcLg97m1j56UvnChP = {}
				egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'MISC_PERM','SITES_ERRORS')
		if WGdr0QRsTcLg97m1j56UvnChP: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'MISC_PERM','SITES_ERRORS',WGdr0QRsTcLg97m1j56UvnChP,iJnLmxA0ykozR98WXFQ4Ye3w)
		return
	pB8XANf71vaPJsedkWVIc5 = list(set(pB8XANf71vaPJsedkWVIc5))
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = IGkHJNLyDge69dROnBUA1Zm2Mc(pB8XANf71vaPJsedkWVIc5,source)
	ApPrCKR0zHsOiV4 = str(EEgFl59RndzrBL8TUoaQMw6P).count('__watch')
	pplBTrFPC4Q2o1Xt5nbRHwYsf3i = str(EEgFl59RndzrBL8TUoaQMw6P).count('__download')
	mpUQAbHWtV5hS = len(EEgFl59RndzrBL8TUoaQMw6P)-ApPrCKR0zHsOiV4-pplBTrFPC4Q2o1Xt5nbRHwYsf3i
	MdAsKamkqT7yI0pE4Nxu8Lv = 'مشاهدة:'+str(ApPrCKR0zHsOiV4)+'    تحميل:'+str(pplBTrFPC4Q2o1Xt5nbRHwYsf3i)+'    أخرى:'+str(mpUQAbHWtV5hS)
	if not EEgFl59RndzrBL8TUoaQMw6P: o6olgEz21iJbqLsKhP,rr07NBhdGXailkP = 'unresolved',''
	else:
		add = 0
		if not any(Y3YqSmycrIWksoH5N0MvC in source for Y3YqSmycrIWksoH5N0MvC in XX1MhWr3KH0Z):
			add = 1
			EEgFl59RndzrBL8TUoaQMw6P = ['RESOLVE_ALL_LINKS']+list(EEgFl59RndzrBL8TUoaQMw6P)
			JCop4mjTiurYB7W = ['فحص جميع السيرفرات']+list(JCop4mjTiurYB7W)
		while True:
			rr07NBhdGXailkP,o6olgEz21iJbqLsKhP = '',''
			if add and len(EEgFl59RndzrBL8TUoaQMw6P)==2: zKgFfQoODy90ewYb5jGElUJRVs4p = 1
			else: zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT(MdAsKamkqT7yI0pE4Nxu8Lv,JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: o6olgEz21iJbqLsKhP = 'canceled_1st_menu'
			elif add and zKgFfQoODy90ewYb5jGElUJRVs4p==0:
				o6olgEz21iJbqLsKhP = 'canceled_2nd_menu'
				mL7BVKcSygkuoPbWlEF4YD = WvLe4ywKZsFj8(JCop4mjTiurYB7W[add:],EEgFl59RndzrBL8TUoaQMw6P[add:],source)
				if mL7BVKcSygkuoPbWlEF4YD:
					mOjTxNiroVPgD0fpdF = []
					for X3pyfvgDUaTweLY7NMbzPG,XnzGmgvPrC0e,mPBgbzyVXHSfIGoOUj,xNUeIrvK9ApHhGkQVcPuC4tmdzM5Tf,nsWFUGhzNZ5lovJe7j1AOI in mL7BVKcSygkuoPbWlEF4YD:
						if nsWFUGhzNZ5lovJe7j1AOI: mOjTxNiroVPgD0fpdF.append((X3pyfvgDUaTweLY7NMbzPG,XnzGmgvPrC0e,mPBgbzyVXHSfIGoOUj,xNUeIrvK9ApHhGkQVcPuC4tmdzM5Tf,nsWFUGhzNZ5lovJe7j1AOI))
					if mOjTxNiroVPgD0fpdF: JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,errors,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han = zip(*mOjTxNiroVPgD0fpdF)
					else:
						ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						o6olgEz21iJbqLsKhP = 'failed'
						break
					MdAsKamkqT7yI0pE4Nxu8Lv = 'السيرفرات الجيدة ( '+str(len(EEgFl59RndzrBL8TUoaQMw6P))+' )'
					add = 0
					continue
			else:
				mL7BVKcSygkuoPbWlEF4YD = WvLe4ywKZsFj8([JCop4mjTiurYB7W[zKgFfQoODy90ewYb5jGElUJRVs4p]],[EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]],source)
				if mL7BVKcSygkuoPbWlEF4YD:
					title,wHiSfdBL1v9Kl3n5,errors,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han = mL7BVKcSygkuoPbWlEF4YD[0]
					if not kwqYoF8han and not any(Y3YqSmycrIWksoH5N0MvC in source for Y3YqSmycrIWksoH5N0MvC in XX1MhWr3KH0Z):
						errors,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han = SBsgCTi6ApOJ8roIEfuRmPhbXNqY(wHiSfdBL1v9Kl3n5,source)
					if 'سيرفر' in title and '2مجهول2' in title:
						b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Unknown Selected Server   Server: [ '+title+' ]   Link: [ '+wHiSfdBL1v9Kl3n5+' ]')
						import COH7BKApEP
						COH7BKApEP.yyWlchfo68Mm()
						o6olgEz21iJbqLsKhP = 'unresolved'
					else:
						b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Playing Selected Server   Server: [ '+title+' ]   Link: [ '+wHiSfdBL1v9Kl3n5+' ]')
						o6olgEz21iJbqLsKhP,rr07NBhdGXailkP,R8nkA2aSmYx4QMw = iJdtCP3h1W7Yz(title,wHiSfdBL1v9Kl3n5,errors,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han,source,type)
			if o6olgEz21iJbqLsKhP in ['EXIT_RESOLVER','download','playing','testing','canceled_1st_menu'] or len(EEgFl59RndzrBL8TUoaQMw6P)==1+add: break
			elif o6olgEz21iJbqLsKhP in ['failed','timeout','tried']: break
			elif o6olgEz21iJbqLsKhP not in ['canceled_2nd_menu','https']:
				if '\n' in rr07NBhdGXailkP: rr07NBhdGXailkP = '[LEFT]  '+rr07NBhdGXailkP.replace('\n','\n[LEFT]  ')
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+'\n'+rr07NBhdGXailkP,profile='confirm_mediumfont')
	if o6olgEz21iJbqLsKhP=='unresolved' and len(JCop4mjTiurYB7W)>0: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+'\n'+rr07NBhdGXailkP,profile='confirm_mediumfont')
	elif o6olgEz21iJbqLsKhP in ['failed','timeout'] and rr07NBhdGXailkP!='': ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج',rr07NBhdGXailkP,profile='confirm_mediumfont')
	return o6olgEz21iJbqLsKhP
def WvLe4ywKZsFj8(u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5,source):
	global lMTNDEUyYhgjaR2vpLs7n
	lMTNDEUyYhgjaR2vpLs7n,mL7BVKcSygkuoPbWlEF4YD,IGpQsua6feoOrlF5L1UiE3wkZc,new = [],[],[],[]
	DTeLX73NFMctyKU9i(False,False,False)
	count = len(pB8XANf71vaPJsedkWVIc5)
	for dGOnHaNWlA2DbyfgLRJi in range(count):
		lMTNDEUyYhgjaR2vpLs7n.append(None)
		title = u6jVYl28ZRT7UXzwxJH3va[dGOnHaNWlA2DbyfgLRJi]
		wHiSfdBL1v9Kl3n5 = pB8XANf71vaPJsedkWVIc5[dGOnHaNWlA2DbyfgLRJi].strip(' ').strip('&').strip('?').strip('/')
		if count>1: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0('فحص سيرفر رقم  '+str(dGOnHaNWlA2DbyfgLRJi+1),title)
		g7LF9lO8ETQuBhAqba1D46sim3j = wHiSfdBL1v9Kl3n5.split('?named=',1)[0]
		XmJGRzicQf7IW10glkwxrn = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','RESOLVED',g7LF9lO8ETQuBhAqba1D46sim3j)
		if XmJGRzicQf7IW10glkwxrn and 'AKWAM' not in source:
			lMTNDEUyYhgjaR2vpLs7n[dGOnHaNWlA2DbyfgLRJi] = XmJGRzicQf7IW10glkwxrn
		else:
			siX5jvfS3zrFby7dHLJc = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=SBsgCTi6ApOJ8roIEfuRmPhbXNqY,args=(wHiSfdBL1v9Kl3n5,source,dGOnHaNWlA2DbyfgLRJi))
			siX5jvfS3zrFby7dHLJc.start()
			Mrx2OeZV1LNjBsQ58Savi7.sleep(0.5)
			IGpQsua6feoOrlF5L1UiE3wkZc.append(siX5jvfS3zrFby7dHLJc)
			new.append(dGOnHaNWlA2DbyfgLRJi)
	timeout = 60 if source=='AKWAM' else 20
	for siX5jvfS3zrFby7dHLJc in IGpQsua6feoOrlF5L1UiE3wkZc: siX5jvfS3zrFby7dHLJc.join(timeout)
	for dGOnHaNWlA2DbyfgLRJi in range(count):
		title = u6jVYl28ZRT7UXzwxJH3va[dGOnHaNWlA2DbyfgLRJi]
		wHiSfdBL1v9Kl3n5 = pB8XANf71vaPJsedkWVIc5[dGOnHaNWlA2DbyfgLRJi].strip(' ').strip('&').strip('?').strip('/')
		if lMTNDEUyYhgjaR2vpLs7n[dGOnHaNWlA2DbyfgLRJi]: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = lMTNDEUyYhgjaR2vpLs7n[dGOnHaNWlA2DbyfgLRJi]
		else: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '\nFailed:  Timeout ('+str(timeout)+' seconds)',[],[]
		mL7BVKcSygkuoPbWlEF4YD.append([title,wHiSfdBL1v9Kl3n5,rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P])
		if dGOnHaNWlA2DbyfgLRJi in new:
			g7LF9lO8ETQuBhAqba1D46sim3j = wHiSfdBL1v9Kl3n5.split('?named=',1)[0]
			pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'RESOLVED',g7LF9lO8ETQuBhAqba1D46sim3j,[rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P],DkRgFyVIBM85OA)
	DTeLX73NFMctyKU9i('','','')
	return mL7BVKcSygkuoPbWlEF4YD
def SBsgCTi6ApOJ8roIEfuRmPhbXNqY(url,source,rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx=0):
	global lMTNDEUyYhgjaR2vpLs7n
	b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Resolving started   Original: [ '+url+' ]')
	wHiSfdBL1v9Kl3n5,ardzY6wRIUbH4v5mADSqNfn = url,''
	sDSqoO2Kft0FIAB = 'INTERNAL_RESOLVER'
	rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = je9NfEJgQHpOLoSDX(url,source)
	if rr07NBhdGXailkP=='EXIT_RESOLVER':
		ardzY6wRIUbH4v5mADSqNfn = '\nResolver 1:  Exit'
		lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		return ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	elif 'NEED_EXTERNAL_RESOLVERS' in rr07NBhdGXailkP:
		ardzY6wRIUbH4v5mADSqNfn = '\nResolver 1:  Need External Resolver'
		wHiSfdBL1v9Kl3n5 = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)[0]
		lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		sDSqoO2Kft0FIAB,ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = aaOekGdF3Bb8zqmlxAf(ardzY6wRIUbH4v5mADSqNfn,wHiSfdBL1v9Kl3n5,source,rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx)
	elif rr07NBhdGXailkP: ardzY6wRIUbH4v5mADSqNfn = 'Resolver 1:  '+rr07NBhdGXailkP.replace('\n','').replace('\r','')[:80]
	if EEgFl59RndzrBL8TUoaQMw6P:
		EEgFl59RndzrBL8TUoaQMw6P = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Resolving succeeded   Resolver: [ '+sDSqoO2Kft0FIAB+' ]   Original: [ '+url+' ]   Link: [ '+wHiSfdBL1v9Kl3n5+' ]   Results: [ '+str(EEgFl59RndzrBL8TUoaQMw6P)+' ]')
	else: b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Resolving failed   Original: [ '+url+' ]   Link: [ '+wHiSfdBL1v9Kl3n5+' ]   Errors: [ '+ardzY6wRIUbH4v5mADSqNfn+' ]')
	ardzY6wRIUbH4v5mADSqNfn = i35i6al7upCAreLFQ(ardzY6wRIUbH4v5mADSqNfn)
	lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	return ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def iJdtCP3h1W7Yz(title,wHiSfdBL1v9Kl3n5,rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,source,type=''):
	if rr07NBhdGXailkP=='EXIT_RESOLVER': return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	elif EEgFl59RndzrBL8TUoaQMw6P:
		while True:
			if len(EEgFl59RndzrBL8TUoaQMw6P)==1: zKgFfQoODy90ewYb5jGElUJRVs4p = 0
			else: zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الملف المناسب:', JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: o6olgEz21iJbqLsKhP = 'tried'
			else:
				C8t2wkdnfqG76ySNvOhce = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
				title = JCop4mjTiurYB7W[zKgFfQoODy90ewYb5jGElUJRVs4p]
				b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Playing selected video   Selected: [ '+title+' ]   URL: [ '+str(C8t2wkdnfqG76ySNvOhce)+' ]')
				if 'moshahda.' in C8t2wkdnfqG76ySNvOhce and 'download_orig' in C8t2wkdnfqG76ySNvOhce:
					bz57iAjd4H9vQVTwZtSxMf16,nUTDz3uCgEsYJt,R8nkA2aSmYx4QMw = iPTCSlcksvQ84K7xRU9tb(C8t2wkdnfqG76ySNvOhce)
					if R8nkA2aSmYx4QMw: C8t2wkdnfqG76ySNvOhce = R8nkA2aSmYx4QMw[0]
					else: C8t2wkdnfqG76ySNvOhce = ''
				if not C8t2wkdnfqG76ySNvOhce: o6olgEz21iJbqLsKhP = 'unresolved'
				else: o6olgEz21iJbqLsKhP = XbzQHGJ0cBV(C8t2wkdnfqG76ySNvOhce,source,type)
			if o6olgEz21iJbqLsKhP in ['playing','testing','canceled_2nd_menu'] or len(EEgFl59RndzrBL8TUoaQMw6P)==1: break
			elif o6olgEz21iJbqLsKhP in ['failed','timeout','tried']: break
			else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		o6olgEz21iJbqLsKhP = 'unresolved'
		if eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5): o6olgEz21iJbqLsKhP = XbzQHGJ0cBV(wHiSfdBL1v9Kl3n5,source,type)
	return o6olgEz21iJbqLsKhP,rr07NBhdGXailkP,EEgFl59RndzrBL8TUoaQMw6P
def DYj1nmd50tgBIHeCAi7RsOpNSh8TKl(url,source):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Pqnom3WlHbDrUB,RgNSOU7P93n,zVCjIO8k7iEpxLlRUv940Jud3Tf,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,aCOI75DKgfuSq4xhojtPzBlYRQ = url,'','','','','','','',''
	if '?named=' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Pqnom3WlHbDrUB = url.split('?named=',1)
		Pqnom3WlHbDrUB = Pqnom3WlHbDrUB+'__'+'__'+'__'+'__'+'__'
		rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,aCOI75DKgfuSq4xhojtPzBlYRQ,Cpxc4DQXoJyY5WO2dTFBAbMRne, = Pqnom3WlHbDrUB.split('__')[:6]
	if not y2nBfLCjDoXkKiwb8WV6: y2nBfLCjDoXkKiwb8WV6 = '0'
	else: y2nBfLCjDoXkKiwb8WV6 = y2nBfLCjDoXkKiwb8WV6.replace('p','').replace(' ','')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.strip('?').strip('/').strip('&')
	RgNSOU7P93n = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'host')
	if rBabYANvVwWzjCp2QF: zVCjIO8k7iEpxLlRUv940Jud3Tf = rBabYANvVwWzjCp2QF
	else: zVCjIO8k7iEpxLlRUv940Jud3Tf = RgNSOU7P93n
	zVCjIO8k7iEpxLlRUv940Jud3Tf = OfTKisDR0Lv(zVCjIO8k7iEpxLlRUv940Jud3Tf,'name')
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	Pqnom3WlHbDrUB = Pqnom3WlHbDrUB.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	zVCjIO8k7iEpxLlRUv940Jud3Tf = zVCjIO8k7iEpxLlRUv940Jud3Tf.replace('مباشر','').replace('سيرفر','').replace('ال ',' ').replace('  ',' ')
	return FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Pqnom3WlHbDrUB,RgNSOU7P93n,zVCjIO8k7iEpxLlRUv940Jud3Tf,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,aCOI75DKgfuSq4xhojtPzBlYRQ
def QHAPM5ITlXm(url,source):
	ed4t0vzEPMHh,rBabYANvVwWzjCp2QF,Qc2wak8HnAliIoPrEDXYCg5T7O31hy,lCaJOyFAV7MN,Rwk1NM0eu48ZDSzcPbhnLofvlFm7rE,ROY1V0Z2m5rKxU3itnJFbvzD8aI,sDSqoO2Kft0FIAB = '','',None,None,None,None,None
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Pqnom3WlHbDrUB,RgNSOU7P93n,zVCjIO8k7iEpxLlRUv940Jud3Tf,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,aCOI75DKgfuSq4xhojtPzBlYRQ = DYj1nmd50tgBIHeCAi7RsOpNSh8TKl(url,source)
	if '?named=' in url:
		if   type=='embed': type = ' '+'مفضل'
		elif type=='watch': type = ' '+'%مشاهدة'
		elif type=='both': type = ' '+'%%مشاهدة وتحميل'
		elif type=='download': type = ' '+'%%%تحميل'
		elif type=='': type = ' '+'%%%%'
		if ohCurPI3fkJGw8jB09n5Q1lHUvzETL!='':
			if 'mp4' not in ohCurPI3fkJGw8jB09n5Q1lHUvzETL: ohCurPI3fkJGw8jB09n5Q1lHUvzETL = '%'+ohCurPI3fkJGw8jB09n5Q1lHUvzETL
			ohCurPI3fkJGw8jB09n5Q1lHUvzETL = ' '+ohCurPI3fkJGw8jB09n5Q1lHUvzETL
		if y2nBfLCjDoXkKiwb8WV6!='':
			y2nBfLCjDoXkKiwb8WV6 = '%%%%%%%%%'+y2nBfLCjDoXkKiwb8WV6
			y2nBfLCjDoXkKiwb8WV6 = ' '+y2nBfLCjDoXkKiwb8WV6[-9:]
	if   'AKOAM'		in source: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'AKWAM'		in source: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'akwam'
	elif 'katkoute'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'photos.app.g'	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'arabseed'		in source: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'alarab'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'fasel'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 't7meel'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'movs4u'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'myegyvip'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'fajer'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'فجر'			in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'fajer'
	elif 'فلسطين'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'palestine'
	elif 'gdrive'		in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'google'
	elif 'mycima'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'wecima'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'cimanow'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'newcima'		in rBabYANvVwWzjCp2QF:   Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'dailymotion'	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'bokra'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'tvfun'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'tvksa'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'anavidz'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'shoofpro'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'shahid4u'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'shahed4u'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'cima4u'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'egynow'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'halacima'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'cimaabdo'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'youtu'	 	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'youtube'
	elif 'y2u.be'	 	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'youtube'
	elif 'd.egybest.d'	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'egybestvip'
	elif 'egy.best'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'egybest1'
	elif 'egybest'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'egybest3'
	elif 'moshahda'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'moshahda'
	elif 'facultybooks'	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'facultybooks'
	elif 'inflam.cc'	in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'inflam'
	elif 'buzzvrl'		in RgNSOU7P93n: Qc2wak8HnAliIoPrEDXYCg5T7O31hy	= 'buzzvrl'
	elif 'arabloads'	in RgNSOU7P93n: lCaJOyFAV7MN	= 'arabloads'
	elif 'archive'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'archive'
	elif 'catch.is'	 	in RgNSOU7P93n: lCaJOyFAV7MN	= 'catch'
	elif 'filerio'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'filerio'
	elif 'vidbm'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'vidbm'
	elif 'vidhd'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'myvid'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'myviid'		in RgNSOU7P93n: ROY1V0Z2m5rKxU3itnJFbvzD8aI	= zVCjIO8k7iEpxLlRUv940Jud3Tf
	elif 'videobin'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'videobin'
	elif 'govid'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'govid'
	elif 'liivideo' 	in RgNSOU7P93n: lCaJOyFAV7MN	= 'liivideo'
	elif 'mp4upload'	in RgNSOU7P93n: lCaJOyFAV7MN	= 'mp4upload'
	elif 'publicvideo'	in RgNSOU7P93n: lCaJOyFAV7MN	= 'publicvideo'
	elif 'rapidvideo' 	in RgNSOU7P93n: lCaJOyFAV7MN	= 'rapidvideo'
	elif 'top4top'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'top4top'
	elif 'upp' 			in RgNSOU7P93n: lCaJOyFAV7MN	= 'upbom'
	elif 'upb' 			in RgNSOU7P93n: lCaJOyFAV7MN	= 'upbom'
	elif 'uqload' 		in RgNSOU7P93n: lCaJOyFAV7MN	= 'uqload'
	elif 'vcstream' 	in RgNSOU7P93n: lCaJOyFAV7MN	= 'vcstream'
	elif 'vidbob'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'vidbob'
	elif 'vidoza' 		in RgNSOU7P93n: lCaJOyFAV7MN	= 'vidoza'
	elif 'watchvideo' 	in RgNSOU7P93n: lCaJOyFAV7MN	= 'watchvideo'
	elif 'wintv.live'	in RgNSOU7P93n: lCaJOyFAV7MN	= 'wintv.live'
	elif 'zippyshare'	in RgNSOU7P93n: lCaJOyFAV7MN	= 'zippyshare'
	elif 'hd-cdn'		in RgNSOU7P93n: lCaJOyFAV7MN	= 'hd-cdn'
	if   Qc2wak8HnAliIoPrEDXYCg5T7O31hy:	ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = 'خاص',Qc2wak8HnAliIoPrEDXYCg5T7O31hy
	elif ROY1V0Z2m5rKxU3itnJFbvzD8aI:		ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = '%محدد',ROY1V0Z2m5rKxU3itnJFbvzD8aI
	elif lCaJOyFAV7MN:		ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = '%%عام معروف',lCaJOyFAV7MN
	elif Rwk1NM0eu48ZDSzcPbhnLofvlFm7rE:	ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = '%%%عام خارجي',Rwk1NM0eu48ZDSzcPbhnLofvlFm7rE
	elif sDSqoO2Kft0FIAB:	ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = '%%%%عام خارجي',zVCjIO8k7iEpxLlRUv940Jud3Tf
	else:			ed4t0vzEPMHh,rBabYANvVwWzjCp2QF = '%%%%%عام مجهول',zVCjIO8k7iEpxLlRUv940Jud3Tf
	return ed4t0vzEPMHh,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6
def je9NfEJgQHpOLoSDX(url,source):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,ROY1V0Z2m5rKxU3itnJFbvzD8aI,RgNSOU7P93n,zVCjIO8k7iEpxLlRUv940Jud3Tf,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,aCOI75DKgfuSq4xhojtPzBlYRQ = DYj1nmd50tgBIHeCAi7RsOpNSh8TKl(url,source)
	if   'AKOAM'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = SN6YMRIvqW(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,rBabYANvVwWzjCp2QF)
	elif 'AKWAM'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = MoLGRCrH0B(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,type,y2nBfLCjDoXkKiwb8WV6)
	elif 'FASELHD1'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = qqpYambklH(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'CIMA4U'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = UxFtyevGjX(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'CIMACLUB'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = koJGyjUzmZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'ARABSEED'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = llrz36PXkA(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'CIMAABDO'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = cKzHS2f0kC(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'SHOFHA'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = cdm9Ne6MRP(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'EGYBEST1'		in source: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = EVQ2mzC1PH(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,aCOI75DKgfuSq4xhojtPzBlYRQ)
	elif 'katkoute'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = MKh7iAVYLX(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'akoam.cam'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Ir6zUqvsmE(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'alarab'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = YYETHKopn7r2fbPIZwXCeiMANzj(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'shahid4u'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = uufmkNnLt8(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'shahed4u'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = uufmkNnLt8(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'egynow'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = sNgmYqG68o(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'tvfun'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = DiCgabltxU(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'tvksa'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = DiCgabltxU(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'tv-f.com'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = DiCgabltxU(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'halacima'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Sk7lb5PuGq(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'shoofpro'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = KGuyljzBC9(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'myegyvip'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = IF273XeiluDAMf(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'vs4u'			in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = EOWJUYxVkQ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'fajer'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = hcqNB7oPQX(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'cimanow'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = A3OWx6KM4Z(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'newcima'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = A3OWx6KM4Z(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'cima-light'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = DWkFCLHpqe(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'cimalight'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = DWkFCLHpqe(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'mycima'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = iiz6XasOgk(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'wecima'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = OOlZvwMeN2(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'bokra'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = sQDa3t4wub(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'dailymotion'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = TISnj9iuNy(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'arblionz'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = KQk7oj83yq(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'd.egybest.d'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	elif 'egybest'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = xxTl5gOPoU(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'series4watch'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = IIMrxCDoVP(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	elif 'upbam' 		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	else: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	return 'Failed:  '+rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def S9wmdQRUjNrs05AF6WVq1uY(rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P):
	FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han = [],[]
	for title,wHiSfdBL1v9Kl3n5 in zip(JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P):
		if eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5):
			FsBtqKUQXgMGWxTyrinfhjOev1.append(title)
			kwqYoF8han.append(wHiSfdBL1v9Kl3n5)
	if not kwqYoF8han and not rr07NBhdGXailkP: rr07NBhdGXailkP = 'Failed'
	return rr07NBhdGXailkP,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han
def aaOekGdF3Bb8zqmlxAf(ardzY6wRIUbH4v5mADSqNfn,url,source,rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx):
	global lMTNDEUyYhgjaR2vpLs7n
	global WTc5gwBuZE,INAqZWsgCiStEO6mv,wOxksldM1GcuKTiPrE,rsA5mzNp8gORtFjLuySieWM
	WTc5gwBuZE,INAqZWsgCiStEO6mv,wOxksldM1GcuKTiPrE,rsA5mzNp8gORtFjLuySieWM = ('Timeout',[],[]),('Timeout',[],[]),('Timeout',[],[]),('Timeout',[],[])
	for NzfP6biDZJAqmyensuhE7HjwYvlQk in [2,3,4,5]:
		if   NzfP6biDZJAqmyensuhE7HjwYvlQk==2: WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=PPIv608VRnAF5NjezGkqwrEmx,args=(url,source))
		elif NzfP6biDZJAqmyensuhE7HjwYvlQk==3: WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=cihaGx73S9tyP,args=(url,source))
		elif NzfP6biDZJAqmyensuhE7HjwYvlQk==4: WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=Mt0koG8acWz4g,args=(url,source))
		elif NzfP6biDZJAqmyensuhE7HjwYvlQk==5: WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=Ttr5WNSm8ChJRGAUp0xDjEOke3B,args=(url,source))
		WpSDRloxYqHzyLtsfT8QA.start()
		WpSDRloxYqHzyLtsfT8QA.join(45)
	gZ8IojYmQD9pRNPh3JBOeasyX = 'EXTERNAL_RESOLVER_2'
	rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = WTc5gwBuZE
	EEgFl59RndzrBL8TUoaQMw6P = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)
	lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	if rr07NBhdGXailkP=='EXIT_RESOLVER': return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	elif not EEgFl59RndzrBL8TUoaQMw6P:
		ardzY6wRIUbH4v5mADSqNfn += '\nResolver 2:  '+rr07NBhdGXailkP.replace('\n','').replace('\r','')[:80]
		gZ8IojYmQD9pRNPh3JBOeasyX = 'EXTERNAL_RESOLVER_3'
		rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = INAqZWsgCiStEO6mv
		EEgFl59RndzrBL8TUoaQMw6P = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)
		lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		if rr07NBhdGXailkP=='EXIT_RESOLVER': return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		elif not EEgFl59RndzrBL8TUoaQMw6P:
			ardzY6wRIUbH4v5mADSqNfn += '\nResolver 3:  '+rr07NBhdGXailkP.replace('\n','').replace('\r','')[:80]
			gZ8IojYmQD9pRNPh3JBOeasyX = 'EXTERNAL_RESOLVER_4'
			rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = wOxksldM1GcuKTiPrE
			EEgFl59RndzrBL8TUoaQMw6P = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)
			lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
			if rr07NBhdGXailkP=='EXIT_RESOLVER': return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
			elif not EEgFl59RndzrBL8TUoaQMw6P:
				ardzY6wRIUbH4v5mADSqNfn += '\nResolver 4:  '+rr07NBhdGXailkP.replace('\n','').replace('\r','')[:80]
				gZ8IojYmQD9pRNPh3JBOeasyX = 'EXTERNAL_RESOLVER_5'
				rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = rsA5mzNp8gORtFjLuySieWM
				EEgFl59RndzrBL8TUoaQMw6P = EXv35meHtCFz(EEgFl59RndzrBL8TUoaQMw6P)
				lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
				if rr07NBhdGXailkP=='EXIT_RESOLVER': return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
				elif not EEgFl59RndzrBL8TUoaQMw6P:
					ardzY6wRIUbH4v5mADSqNfn += '\nResolver 5:  '+rr07NBhdGXailkP.replace('\n','').replace('\r','')[:80]
	lMTNDEUyYhgjaR2vpLs7n[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] = ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	return gZ8IojYmQD9pRNPh3JBOeasyX,ardzY6wRIUbH4v5mADSqNfn,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def PPIv608VRnAF5NjezGkqwrEmx(url,source):
	RgNSOU7P93n = OfTKisDR0Lv(url,'name')
	EEgFl59RndzrBL8TUoaQMw6P = []
	if   'youtu'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Z5aTos0RvJ(url)
	elif 'y2u.be'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Z5aTos0RvJ(url)
	elif 'googleuserco' in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = FEcpCkrZYNb6e1UuhoWBIq3Kn(url)
	elif 'photos.app.g'	in url   : rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = dMckS34QJI1(url)
	elif 'dailymotion'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = TISnj9iuNy(url)
	elif 'moshahda'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = iPTCSlcksvQ84K7xRU9tb(url)
	elif 'faselhd'		in url   : rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = qqpYambklH(url)
	elif 'arabloads'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = bl9v6ArgMHY35oNRPjKTphUe(url)
	elif 'archive'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = yXDfYaSLNn(url)
	elif 'buzzvrl'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = YrAnF8e5xKvL1V(url)
	elif 'e5tsar'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Hg9K0FLoBksG1tlZcJjwPqN(url)
	elif 'facultybooks'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = GzPCQY5jDxmksVZ618NdIgX(url)
	elif 'inflam.cc'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = GzPCQY5jDxmksVZ618NdIgX(url)
	elif 'upbam' 		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[''],[url]
	elif 'liivideo' 	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = SSWlv3Vy1zHT0DMu7O4kf8cr9EPap(url)
	elif 'mp4upload'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = b0bzfcIZqdoOge4prjMXLhQYs(url)
	elif 'rapidvideo' 	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = etyp8R5nxQmJIBuHSkE0YKcdWC(url)
	elif 'top4top'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = B0cJaLUDW9i7vGANZy(url)
	elif 'upb' 			in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = FPlKrLtyn2gsQ05w8Ne(url)
	elif 'upp' 			in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = FPlKrLtyn2gsQ05w8Ne(url)
	elif 'uqload' 		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = eCzdrtZFSIPLDwk(url)
	elif 'vcstream' 	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = LLEJK1ePHN8M(url)
	elif 'vidbob'		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = W5WqDEThbBazo0ljmCUFVSfNLrn(url)
	elif 'vidoza' 		in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = uC0DgYaPMwt9mnriXpqLfK(url)
	elif 'watchvideo' 	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = P2PAF0fKzgxJbGi3OBvSkc6mR(url)
	elif 'wintv.live'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Vn7PvKeXHM9Zxgi3p(url)
	elif 'zippyshare'	in RgNSOU7P93n: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = USJRIzCvbu(url)
	global WTc5gwBuZE
	if EEgFl59RndzrBL8TUoaQMw6P:
		WTc5gwBuZE = ('Failed: '+rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P)
		return WTc5gwBuZE
	WTc5gwBuZE = ('Failed:  ',[],[])
	return WTc5gwBuZE
def cihaGx73S9tyP(url,source):
	rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[],[]
	if eeiIspx5JaGYcH0zCu(url): rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[''],[url]
	if not EEgFl59RndzrBL8TUoaQMw6P: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = JV2E8fwuenZt(url)
	if not EEgFl59RndzrBL8TUoaQMw6P: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = Cvjr90TfOhcu4B(url)
	global INAqZWsgCiStEO6mv
	if not EEgFl59RndzrBL8TUoaQMw6P:
		if rr07NBhdGXailkP=='EXIT_RESOLVER': rr07NBhdGXailkP = ''
		INAqZWsgCiStEO6mv = ('Failed:  '+rr07NBhdGXailkP,[],[])
		return INAqZWsgCiStEO6mv
	INAqZWsgCiStEO6mv = (rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P)
	return INAqZWsgCiStEO6mv
def Mt0koG8acWz4g(url,source):
	n6MNfIpoX7GgJZu = ''
	mL7BVKcSygkuoPbWlEF4YD = False
	try:
		import resolveurl as ggnpx6OaGEykuRsfrAMjcBS
		mL7BVKcSygkuoPbWlEF4YD = ggnpx6OaGEykuRsfrAMjcBS.resolve(url)
	except Exception as iPKfTlH4FLoSvAt8zhs: n6MNfIpoX7GgJZu = str(iPKfTlH4FLoSvAt8zhs)
	global wOxksldM1GcuKTiPrE
	if not mL7BVKcSygkuoPbWlEF4YD:
		if n6MNfIpoX7GgJZu=='':
			n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
			if n6MNfIpoX7GgJZu!='NoneType: None\n': uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
		rr07NBhdGXailkP = n6MNfIpoX7GgJZu.splitlines()[-1]
		wOxksldM1GcuKTiPrE = ('Failed:  '+rr07NBhdGXailkP,[],[])
		return wOxksldM1GcuKTiPrE
	wOxksldM1GcuKTiPrE = ('',[''],[mL7BVKcSygkuoPbWlEF4YD])
	return wOxksldM1GcuKTiPrE
def Ttr5WNSm8ChJRGAUp0xDjEOke3B(url,source):
	n6MNfIpoX7GgJZu = ''
	mL7BVKcSygkuoPbWlEF4YD = False
	try:
		import yt_dlp as br8wdYC0hN61TGim24cVgpvF
		UwhV2u3Wz0E5 = br8wdYC0hN61TGim24cVgpvF.YoutubeDL({'no_color': True})
		mL7BVKcSygkuoPbWlEF4YD = UwhV2u3Wz0E5.extract_info(url,download=False)
	except Exception as iPKfTlH4FLoSvAt8zhs: n6MNfIpoX7GgJZu = str(iPKfTlH4FLoSvAt8zhs)
	global rsA5mzNp8gORtFjLuySieWM
	if not mL7BVKcSygkuoPbWlEF4YD or 'formats' not in list(mL7BVKcSygkuoPbWlEF4YD.keys()):
		if n6MNfIpoX7GgJZu=='':
			n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
			if n6MNfIpoX7GgJZu!='NoneType: None\n': uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
		rr07NBhdGXailkP = n6MNfIpoX7GgJZu.splitlines()[-1]
		rsA5mzNp8gORtFjLuySieWM = ('Failed:  '+rr07NBhdGXailkP,[],[])
	else:
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
		for wHiSfdBL1v9Kl3n5 in mL7BVKcSygkuoPbWlEF4YD['formats']:
			JCop4mjTiurYB7W.append(wHiSfdBL1v9Kl3n5['format'])
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5['url'])
		rsA5mzNp8gORtFjLuySieWM = ('',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P)
	return rsA5mzNp8gORtFjLuySieWM
def JV2E8fwuenZt(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','',False,'RESOLVERS-REDIRECT_URL-1st')
	headers = SSzrgUnfVGL1hQsu40FoP7CWXax.headers
	if 'Location' in list(headers.keys()):
		wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		if eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5): return '',[''],[wHiSfdBL1v9Kl3n5]
	return 'Failed:  ',[],[]
def EXv35meHtCFz(MdgvNCbsQAkFY945Llj6o):
	if 'list' in str(type(MdgvNCbsQAkFY945Llj6o)):
		kwqYoF8han = []
		for wHiSfdBL1v9Kl3n5 in MdgvNCbsQAkFY945Llj6o:
			if 'str' in str(type(wHiSfdBL1v9Kl3n5)): wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\r','').replace('\n','').strip(' ')
			kwqYoF8han.append(wHiSfdBL1v9Kl3n5)
	else: kwqYoF8han = MdgvNCbsQAkFY945Llj6o.replace('\r','').replace('\n','').strip(' ')
	return kwqYoF8han
def IGkHJNLyDge69dROnBUA1Zm2Mc(R8nkA2aSmYx4QMw,source):
	M4LzXn0ZpdAf8E = UHnG2wYuIQWKN38B4
	data = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SERVERS',R8nkA2aSmYx4QMw)
	if data:
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = list(zip(*data))
		return JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,xLUglaQikvNJS7OuW9qAewBEm = [],[],[]
	for wHiSfdBL1v9Kl3n5 in R8nkA2aSmYx4QMw:
		if '//' not in wHiSfdBL1v9Kl3n5: continue
		ed4t0vzEPMHh,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6 = QHAPM5ITlXm(wHiSfdBL1v9Kl3n5,source)
		y2nBfLCjDoXkKiwb8WV6 = JJDtX1PZyIgN2T.findall('\d+',y2nBfLCjDoXkKiwb8WV6,JJDtX1PZyIgN2T.DOTALL)
		if y2nBfLCjDoXkKiwb8WV6: y2nBfLCjDoXkKiwb8WV6 = int(y2nBfLCjDoXkKiwb8WV6[0])
		else: y2nBfLCjDoXkKiwb8WV6 = 0
		RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
		xLUglaQikvNJS7OuW9qAewBEm.append([ed4t0vzEPMHh,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5,RgNSOU7P93n])
	if xLUglaQikvNJS7OuW9qAewBEm:
		RRmfGwB0go6W4NVHcLZlMr = sorted(xLUglaQikvNJS7OuW9qAewBEm,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		Kr2Xv8TgoqesjdZtELMybOk = []
		for dSvlymbao9Zs6t in RRmfGwB0go6W4NVHcLZlMr:
			if dSvlymbao9Zs6t not in Kr2Xv8TgoqesjdZtELMybOk:
				Kr2Xv8TgoqesjdZtELMybOk.append(dSvlymbao9Zs6t)
		for ed4t0vzEPMHh,rBabYANvVwWzjCp2QF,type,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5,RgNSOU7P93n in Kr2Xv8TgoqesjdZtELMybOk:
			if y2nBfLCjDoXkKiwb8WV6: y2nBfLCjDoXkKiwb8WV6 = str(y2nBfLCjDoXkKiwb8WV6)
			else: y2nBfLCjDoXkKiwb8WV6 = ''
			title = 'سيرفر'+' '+type+' '+ed4t0vzEPMHh+' '+y2nBfLCjDoXkKiwb8WV6+' '+ohCurPI3fkJGw8jB09n5Q1lHUvzETL+' '+rBabYANvVwWzjCp2QF
			if RgNSOU7P93n not in title: title = title+' '+RgNSOU7P93n
			title = title.replace('%','').strip(' ').replace('  ',' ').replace('  ',' ').replace('  ',' ')
			if wHiSfdBL1v9Kl3n5 not in EEgFl59RndzrBL8TUoaQMw6P:
				JCop4mjTiurYB7W.append(title)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		if EEgFl59RndzrBL8TUoaQMw6P:
			data = list(zip(JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P))
			if data: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SERVERS',R8nkA2aSmYx4QMw,data,M4LzXn0ZpdAf8E)
	return JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def YYETHKopn7r2fbPIZwXCeiMANzj(url):
	if '.m3u8' in url:
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = XuJcNIWr8FMGQS(url)
		if EEgFl59RndzrBL8TUoaQMw6P: return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def MKh7iAVYLX(url):
	pB8XANf71vaPJsedkWVIc5,u6jVYl28ZRT7UXzwxJH3va = [],[]
	if '/videos.mp4?vid=' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','',False,'','RESOLVERS-KATKOUTE-1st')
		if 'Location' in SSzrgUnfVGL1hQsu40FoP7CWXax.headers:
			wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
			RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			u6jVYl28ZRT7UXzwxJH3va.append(RgNSOU7P93n)
	elif 'katkoute.com' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','RESOLVERS-KATKOUTE-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		yyJB8WmHTEw4OIbcnxf = JJDtX1PZyIgN2T.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if yyJB8WmHTEw4OIbcnxf:
			yyJB8WmHTEw4OIbcnxf = yyJB8WmHTEw4OIbcnxf[0]
			fDUlrZqcjakT8WpPG3Ku4XBL = lB1vAJfs6kthziXFgTuNr(yyJB8WmHTEw4OIbcnxf)
			MF6q1p9BT4ir = JJDtX1PZyIgN2T.findall('sources:(\[.*?\]),',fDUlrZqcjakT8WpPG3Ku4XBL,JJDtX1PZyIgN2T.DOTALL)
			if MF6q1p9BT4ir:
				MF6q1p9BT4ir = MF6q1p9BT4ir[0]
				MF6q1p9BT4ir = G8EwoDOyKShm1i0IHMfNYZlU7('list',MF6q1p9BT4ir)
				for dict in MF6q1p9BT4ir:
					wHiSfdBL1v9Kl3n5 = dict['file']
					y2nBfLCjDoXkKiwb8WV6 = dict['label']
					pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
					RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
					u6jVYl28ZRT7UXzwxJH3va.append(y2nBfLCjDoXkKiwb8WV6+' '+RgNSOU7P93n)
		elif 'Location' in SSzrgUnfVGL1hQsu40FoP7CWXax.headers:
			wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
			RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			u6jVYl28ZRT7UXzwxJH3va.append(RgNSOU7P93n)
		if '?url=https://photos.app.goo' in url:
			wHiSfdBL1v9Kl3n5 = url.split('?url=')[1]
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&')[0]
			if wHiSfdBL1v9Kl3n5:
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
				u6jVYl28ZRT7UXzwxJH3va.append('photos google')
	else:
		pB8XANf71vaPJsedkWVIc5.append(url)
		RgNSOU7P93n = OfTKisDR0Lv(url,'name')
		u6jVYl28ZRT7UXzwxJH3va.append(RgNSOU7P93n)
	if not pB8XANf71vaPJsedkWVIc5: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(pB8XANf71vaPJsedkWVIc5)==1: wHiSfdBL1v9Kl3n5 = pB8XANf71vaPJsedkWVIc5[0]
	else:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر الملف المناسب',u6jVYl28ZRT7UXzwxJH3va)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return 'EXIT_RESOLVER',[],[]
		wHiSfdBL1v9Kl3n5 = pB8XANf71vaPJsedkWVIc5[zKgFfQoODy90ewYb5jGElUJRVs4p]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def FEcpCkrZYNb6e1UuhoWBIq3Kn(url):
	headers = {'User-Agent':'Kodi/'+str(WWSLAyQdhUXl3ovb)}
	for uvTwHSmjyW6Vr0192IZ in range(50):
		Mrx2OeZV1LNjBsQ58Savi7.sleep(0.100)
		SSzrgUnfVGL1hQsu40FoP7CWXax = IjDgSHxpL2h('GET',url,'',headers,False,'','RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()):
			wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'|User-Agent='+headers['User-Agent']
			return '',[''],[wHiSfdBL1v9Kl3n5]
		if SSzrgUnfVGL1hQsu40FoP7CWXax.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def dMckS34QJI1(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','RESOLVERS-PHOTOSGOOGLE-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 = wHiSfdBL1v9Kl3n5[0]
		return '',[y2nBfLCjDoXkKiwb8WV6],[wHiSfdBL1v9Kl3n5]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def qqpYambklH(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-FASELHD1-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YBEsLq8gVw629cMGQP1T = lZVqvuJG40hwcXFIdeiP(YBEsLq8gVw629cMGQP1T)
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('"file":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5: return '',[''],[wHiSfdBL1v9Kl3n5[0]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def cdm9Ne6MRP(url):
	if '/down.php' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-SHOFHA-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('video-wrapper.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		url = wHiSfdBL1v9Kl3n5[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def UxFtyevGjX(url):
	if 'server.php' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-CIMA4U-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		if 'http' in wHiSfdBL1v9Kl3n5: return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def sNgmYqG68o(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
	JZP07kjvbV = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','RESOLVERS-EGYNOW-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: return 'Error: Resolver Failed EGYNOW',[],[]
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def KGuyljzBC9(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','RESOLVERS-SHOOFPRO-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	if not wHiSfdBL1v9Kl3n5: return 'Error: Resolver Failed SHOOFPRO',[],[]
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def Sk7lb5PuGq(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
	JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','RESOLVERS-HALACIMA-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('''<iframe src=["'](.*?)["']''',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	if not wHiSfdBL1v9Kl3n5: return 'Error: Resolver Failed HALACIMA',[],[]
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def cKzHS2f0kC(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
	JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','RESOLVERS-CIMAABDO-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('''<iframe src=["'](.*?)["']''',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	if wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	else: wHiSfdBL1v9Kl3n5 = url
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def DiCgabltxU(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','RESOLVERS-TVFUN-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lYih6yH2X45 = JJDtX1PZyIgN2T.findall("var fserv =.*?'(.*?)'",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	if lYih6yH2X45:
		lYih6yH2X45 = lYih6yH2X45[0][2:]
		lYih6yH2X45 = gPSZVjJHKIL.b64decode(lYih6yH2X45)
		if DQfHadYvTpy1UR: lYih6yH2X45 = lYih6yH2X45.decode('utf8')
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',lYih6yH2X45,JJDtX1PZyIgN2T.DOTALL)
	else: wHiSfdBL1v9Kl3n5 = ''
	if not wHiSfdBL1v9Kl3n5: return 'Error: Resolver Failed TVFUN',[],[]
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def IF273XeiluDAMf(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-MYEGYVIP-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('class="col-sm-12".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: return 'Error: Resolver Failed MYEGYVIP',[],[]
	wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def TISnj9iuNy(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed','')
	url = url.replace('.com/','.com/player/metadata/')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-DAILYMOTION-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	rr07NBhdGXailkP = 'Error: Resolver Failed DAILYMOTION'
	iPKfTlH4FLoSvAt8zhs = JJDtX1PZyIgN2T.findall('"error".*?"messagee":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if iPKfTlH4FLoSvAt8zhs: rr07NBhdGXailkP = iPKfTlH4FLoSvAt8zhs[0]
	url = JJDtX1PZyIgN2T.findall('x-mpegURL","url":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not url and rr07NBhdGXailkP:
		return rr07NBhdGXailkP,[],[]
	wHiSfdBL1v9Kl3n5 = url[0].replace('\\','')
	nUTDz3uCgEsYJt,R8nkA2aSmYx4QMw = XuJcNIWr8FMGQS(wHiSfdBL1v9Kl3n5)
	bbnzCkIBiPlYOXj3eWTESao = JJDtX1PZyIgN2T.findall('"owner":{"id":"(.*?)","screenname":"(.*?)","url":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if bbnzCkIBiPlYOXj3eWTESao: nzRyo6hDTrviAsuj0Vwldp5,Mf5YkAEwcPGvq,uu2gh46TMtYEzclVwnqLmKCP = bbnzCkIBiPlYOXj3eWTESao[0]
	else: nzRyo6hDTrviAsuj0Vwldp5,Mf5YkAEwcPGvq,uu2gh46TMtYEzclVwnqLmKCP = '','',''
	uu2gh46TMtYEzclVwnqLmKCP = uu2gh46TMtYEzclVwnqLmKCP.replace('\/','/')
	Mf5YkAEwcPGvq = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(Mf5YkAEwcPGvq)
	JCop4mjTiurYB7W = ['[COLOR FFC89008]OWNER:  '+Mf5YkAEwcPGvq+'[/COLOR]']+nUTDz3uCgEsYJt
	EEgFl59RndzrBL8TUoaQMw6P = [uu2gh46TMtYEzclVwnqLmKCP]+R8nkA2aSmYx4QMw
	zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الملف المناسب: ('+str(len(EEgFl59RndzrBL8TUoaQMw6P)-1)+' ملف)',JCop4mjTiurYB7W)
	if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return 'EXIT_RESOLVER',[],[]
	elif zKgFfQoODy90ewYb5jGElUJRVs4p==0:
		fbCg3QuR1M6dlAXDTnIFoe7aE = uea9JUBOMcEfh8CN0v6b.argv[0]+'?type=folder&mode=402&url='+uu2gh46TMtYEzclVwnqLmKCP+'&textt='+Mf5YkAEwcPGvq
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin("Container.Update("+fbCg3QuR1M6dlAXDTnIFoe7aE+")")
		return 'EXIT_RESOLVER',[],[]
	wHiSfdBL1v9Kl3n5 =  EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	return '',[''],[wHiSfdBL1v9Kl3n5]
def sQDa3t4wub(wHiSfdBL1v9Kl3n5):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',wHiSfdBL1v9Kl3n5,'','','','','RESOLVERS-BOKRA-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if '.json' in wHiSfdBL1v9Kl3n5: url = JJDtX1PZyIgN2T.findall('"src":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	else: url = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[0]
	if 'http' not in url: url = 'http:'+url
	return '',[''],[url]
def iPTCSlcksvQ84K7xRU9tb(url):
	headers = { 'User-Agent' : '' }
	if 'op=download_orig' in url:
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-MOSHAHDA-1st')
		items = JJDtX1PZyIgN2T.findall('direct link.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if items: return '',[''],[items[0]]
		else:
			Ay3eLGaTncD67lx8ZOud = JJDtX1PZyIgN2T.findall('class="err">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if Ay3eLGaTncD67lx8ZOud:
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من الموقع الاصلي',Ay3eLGaTncD67lx8ZOud[0])
				return 'Error: '+Ay3eLGaTncD67lx8ZOud[0],[],[]
	else:
		XUj8uOQAJ6pBCitZ4Te = 'movizland'
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-MOSHAHDA-2nd')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('Form method="POST" action=\'(.*?)\'(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: return 'Error: Resolver Failed MOSHAHDA',[],[]
		tb4p6sRlFPcio = GGbRgKaoskDC[0][0]
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0][1]
		if '.rar' in mvgk7pP8Fw6heMSWd5oXn9itl or '.zip' in mvgk7pP8Fw6heMSWd5oXn9itl: return 'Error: MOSHAHDA Not a video file',[],[]
		items = JJDtX1PZyIgN2T.findall('name="(.*?)".*?value="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {}
		for rBabYANvVwWzjCp2QF,Y3YqSmycrIWksoH5N0MvC in items:
			zAkbOyR9ZirYWxTwvMqouPLBjeQ20[rBabYANvVwWzjCp2QF] = Y3YqSmycrIWksoH5N0MvC
		data = lfM8WO96En(zAkbOyR9ZirYWxTwvMqouPLBjeQ20)
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,tb4p6sRlFPcio,data,headers,'','RESOLVERS-MOSHAHDA-3rd')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = GGbRgKaoskDC[0][0]
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0][1]
		items = JJDtX1PZyIgN2T.findall('file:"(.*?)"(,label:".*?"|)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,JCop4mjTiurYB7W,r03wsLKJioDyYhQTxX,EEgFl59RndzrBL8TUoaQMw6P,UKpznWTHCGLs4RXYxJkFgveqI = [],[],[],[],[]
		for wHiSfdBL1v9Kl3n5,title in items:
			if '.m3u8' in wHiSfdBL1v9Kl3n5:
				qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,r03wsLKJioDyYhQTxX = XuJcNIWr8FMGQS(wHiSfdBL1v9Kl3n5)
				EEgFl59RndzrBL8TUoaQMw6P = EEgFl59RndzrBL8TUoaQMw6P + r03wsLKJioDyYhQTxX
				if qSxgc4NEaF7pBYvKik0n6w2jmMVsyC[0]=='-1': JCop4mjTiurYB7W.append(' سيرفر خاص '+'m3u8 '+XUj8uOQAJ6pBCitZ4Te)
				else:
					for title in qSxgc4NEaF7pBYvKik0n6w2jmMVsyC:
						JCop4mjTiurYB7W.append(' سيرفر خاص '+'m3u8 '+XUj8uOQAJ6pBCitZ4Te+' '+title)
			else:
				title = title.replace(',label:"','')
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+XUj8uOQAJ6pBCitZ4Te+' '+title
				JCop4mjTiurYB7W.append(title)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		wHiSfdBL1v9Kl3n5 = 'http://moshahda.online' + download
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,wHiSfdBL1v9Kl3n5,'',headers,'','RESOLVERS-MOSHAHDA-5th')
		items = JJDtX1PZyIgN2T.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for id,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,hash,J7SmUMG3CW in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+XUj8uOQAJ6pBCitZ4Te+' '+J7SmUMG3CW.split('x')[1]
			wHiSfdBL1v9Kl3n5 = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+AFWci0tYmjRU1azGJEy3ovDw2hfsqr+'&hash='+hash
			UKpznWTHCGLs4RXYxJkFgveqI.append(J7SmUMG3CW)
			JCop4mjTiurYB7W.append(title)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		UKpznWTHCGLs4RXYxJkFgveqI = set(UKpznWTHCGLs4RXYxJkFgveqI)
		IIFO1A5g4VGqwbxLRC,ChWNTIHorSA514z2P8pOyskeLYj = [],[]
		for title in JCop4mjTiurYB7W:
			wU90RY1iSsDlP = JJDtX1PZyIgN2T.findall(" (\d*x|\d*)&&",title+'&&',JJDtX1PZyIgN2T.DOTALL)
			for J7SmUMG3CW in UKpznWTHCGLs4RXYxJkFgveqI:
				if wU90RY1iSsDlP[0] in J7SmUMG3CW:
					title = title.replace(wU90RY1iSsDlP[0],J7SmUMG3CW.split('x')[1])
			IIFO1A5g4VGqwbxLRC.append(title)
		for ggjo5zu7yCiIOhrb in range(len(EEgFl59RndzrBL8TUoaQMw6P)):
			items = JJDtX1PZyIgN2T.findall("&&(.*?)(\d*)&&",'&&'+IIFO1A5g4VGqwbxLRC[ggjo5zu7yCiIOhrb]+'&&',JJDtX1PZyIgN2T.DOTALL)
			ChWNTIHorSA514z2P8pOyskeLYj.append( [IIFO1A5g4VGqwbxLRC[ggjo5zu7yCiIOhrb],EEgFl59RndzrBL8TUoaQMw6P[ggjo5zu7yCiIOhrb],items[0][0],items[0][1]] )
		ChWNTIHorSA514z2P8pOyskeLYj = sorted(ChWNTIHorSA514z2P8pOyskeLYj, key=lambda SwAJPmoty8RC0n1: SwAJPmoty8RC0n1[3], reverse=True)
		ChWNTIHorSA514z2P8pOyskeLYj = sorted(ChWNTIHorSA514z2P8pOyskeLYj, key=lambda SwAJPmoty8RC0n1: SwAJPmoty8RC0n1[2], reverse=False)
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
		for ggjo5zu7yCiIOhrb in range(len(ChWNTIHorSA514z2P8pOyskeLYj)):
			JCop4mjTiurYB7W.append(ChWNTIHorSA514z2P8pOyskeLYj[ggjo5zu7yCiIOhrb][0])
			EEgFl59RndzrBL8TUoaQMw6P.append(ChWNTIHorSA514z2P8pOyskeLYj[ggjo5zu7yCiIOhrb][1])
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def Hg9K0FLoBksG1tlZcJjwPqN(url):
	xxyPKEIGHM75VZcR3S2z0Q = url.split('?')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = xxyPKEIGHM75VZcR3S2z0Q[0]
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','RESOLVERS-E5TSAR-1st')
	items = JJDtX1PZyIgN2T.findall('Please wait.*?href=\'(.*?)\'',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	url = items[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def YrAnF8e5xKvL1V(url):
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('redirect_url.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: return '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def GzPCQY5jDxmksVZ618NdIgX(url):
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,'','RESOLVERS-FACULTYBOOKS-1st')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('href","(htt.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: return '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def hcqNB7oPQX(url):
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,errno = [],[],''
	if '/wp-admin/' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
		JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','RESOLVERS-FAJERSHOW-2nd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if Plj7MGOHohwdvam2ynfVY1z.startswith('http'): FrC9LhHZWIySdGwNsuzqt5Rf01TXO = Plj7MGOHohwdvam2ynfVY1z
		else:
			kHWT0XY2S6apruwxiB8FDl1 = JJDtX1PZyIgN2T.findall('''src=['"](.*?)['"]''',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if kHWT0XY2S6apruwxiB8FDl1:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kHWT0XY2S6apruwxiB8FDl1[0]
				kHWT0XY2S6apruwxiB8FDl1 = JJDtX1PZyIgN2T.findall('source=(.*?)[&$]',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,JJDtX1PZyIgN2T.DOTALL)
				if kHWT0XY2S6apruwxiB8FDl1:
					FrC9LhHZWIySdGwNsuzqt5Rf01TXO = i35i6al7upCAreLFQ(kHWT0XY2S6apruwxiB8FDl1[0])
					return '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	elif '/links/' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','',True,'','RESOLVERS-FAJERSHOW-1st')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if 'Location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()): FrC9LhHZWIySdGwNsuzqt5Rf01TXO = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('id="link".*?href="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)[0]
	if '/v/' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO or '/f/' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('/f/','/api/source/')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('/v/','/api/source/')
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','RESOLVERS-FAJERSHOW-3rd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		items = JJDtX1PZyIgN2T.findall('"file":"(.*?)","label":"(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if items:
			for wHiSfdBL1v9Kl3n5,title in items:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\\','')
				JCop4mjTiurYB7W.append(title)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		else:
			items = JJDtX1PZyIgN2T.findall('"file":"(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if items:
				wHiSfdBL1v9Kl3n5 = items[0]
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\\','')
				JCop4mjTiurYB7W.append('')
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	else: return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def EOWJUYxVkQ(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-MOVS4U-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,errno = [],[],''
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if 'movs4u' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','RESOLVERS-MOVS4U-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="player"(.*?)videojs',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<source src="(.*?)".*?label="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if items:
			for wHiSfdBL1v9Kl3n5,MpTK2YaAjI4NWtiGcC3PQg in items:
				JCop4mjTiurYB7W.append(MpTK2YaAjI4NWtiGcC3PQg)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	elif 'main_player.php' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('url=(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','RESOLVERS-MOVS4U-3rd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		kHWT0XY2S6apruwxiB8FDl1 = JJDtX1PZyIgN2T.findall('"file": "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1[0]
		JCop4mjTiurYB7W.append('')
		EEgFl59RndzrBL8TUoaQMw6P.append(kHWT0XY2S6apruwxiB8FDl1)
	elif 'download_link' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('<center><a href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed MOVS4U',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def koJGyjUzmZ(url):
	if '?get=' in url:
		wHiSfdBL1v9Kl3n5 = url.split('?get=',1)[1]
		wHiSfdBL1v9Kl3n5 = gPSZVjJHKIL.b64decode(wHiSfdBL1v9Kl3n5)
		if DQfHadYvTpy1UR: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.decode('utf8','ignore')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
	website = LWzUbE5adDslTXGr['CIMACLUB'][0]
	headers = {'Referer':website}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'',headers,'','','RESOLVERS-CIMACLUB-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	RgNSOU7P93n = OfTKisDR0Lv(url,'url')
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('download=.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall("sources: \['(.*?)'",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall("file:'(.*?)'",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]+'|Referer='+website
		return '',[''],[wHiSfdBL1v9Kl3n5]
	if 'name="Xtoken"' in YBEsLq8gVw629cMGQP1T:
		SJkiE5QmLN16eOIFh = JJDtX1PZyIgN2T.findall('name="Xtoken" content="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if SJkiE5QmLN16eOIFh:
			wHiSfdBL1v9Kl3n5 = SJkiE5QmLN16eOIFh[0]
			wHiSfdBL1v9Kl3n5 = gPSZVjJHKIL.b64decode(wHiSfdBL1v9Kl3n5)
			if DQfHadYvTpy1UR: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.decode('utf8','ignore')
			wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('http.*?(http.*?),',wHiSfdBL1v9Kl3n5,JJDtX1PZyIgN2T.DOTALL)
			if wHiSfdBL1v9Kl3n5:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]+'|Referer='+website
				return '',[''],[wHiSfdBL1v9Kl3n5]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
def EVQ2mzC1PH(url,aCOI75DKgfuSq4xhojtPzBlYRQ):
	u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5 = [],[]
	if '/1/' in url:
		wHiSfdBL1v9Kl3n5 = url.replace('/1/','/4/')
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',wHiSfdBL1v9Kl3n5,'','',False,'','RESOLVERS-EGYBEST1-1st')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<video(.*?)</video>',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?size="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 in items:
				if wHiSfdBL1v9Kl3n5 not in pB8XANf71vaPJsedkWVIc5:
					pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
					RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
					u6jVYl28ZRT7UXzwxJH3va.append(RgNSOU7P93n+'  '+y2nBfLCjDoXkKiwb8WV6)
			return '',u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5
	elif '/d/' in url:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'','','','','RESOLVERS-EGYBEST1-2nd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<iframe.*?src="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if wHiSfdBL1v9Kl3n5:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0].replace('/1/','/4/')
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',wHiSfdBL1v9Kl3n5,'','',False,'','RESOLVERS-EGYBEST1-3rd')
			Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
			wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('class.*?href="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if wHiSfdBL1v9Kl3n5: return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5[0]]
	elif '/role/' in url:
		headers = {'Referer':aCOI75DKgfuSq4xhojtPzBlYRQ}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',headers,False,'','RESOLVERS-EGYBEST1-3rd')
		wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',wHiSfdBL1v9Kl3n5,'','','','','RESOLVERS-EGYBEST1-4th')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		rr07NBhdGXailkP,u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5 = LWRZQ0JTHB6zycXv9VCUI3Ep(wHiSfdBL1v9Kl3n5,YBEsLq8gVw629cMGQP1T)
		return rr07NBhdGXailkP,u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5
	return 'Error: Resolver Failed EGYBEST1',[],[]
def xxTl5gOPoU(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'','','','','RESOLVERS-EGYBEST3-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	data = JJDtX1PZyIgN2T.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if data:
		sto5mr2kveW7lcDfBPJ,id,tngv05rCMbFQaAK3 = data[0]
		data = 'op='+sto5mr2kveW7lcDfBPJ+'&id='+id+'&fname='+tngv05rCMbFQaAK3
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',url,data,headers,'','','RESOLVERS-EGYBEST3-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('"referer" value="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if wHiSfdBL1v9Kl3n5: return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5[0]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def XMwnvWaRz8(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.split('?named=',1)[0].strip('?').strip('/').strip('&')
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,items,kHWT0XY2S6apruwxiB8FDl1 = [],[],[],''
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,True,'','RESOLVERS-EGYBEST-1st')
	if 'Location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()): kHWT0XY2S6apruwxiB8FDl1 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
	if 'http' in kHWT0XY2S6apruwxiB8FDl1:
		if '__watch' in url: kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1.replace('/f/','/v/')
		fPJ2Ytpy7Tn0GiNcvjOIQaZ59zwF3 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('?PHPSID=')[1]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+fPJ2Ytpy7Tn0GiNcvjOIQaZ59zwF3 }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kHWT0XY2S6apruwxiB8FDl1,'',headers,False,'','EGYBEST-PLAY-3rd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if '/f/' in kHWT0XY2S6apruwxiB8FDl1: items = JJDtX1PZyIgN2T.findall('<h2>.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		elif '/v/' in kHWT0XY2S6apruwxiB8FDl1: items = JJDtX1PZyIgN2T.findall('id="video".*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if items: return [],[''],[ items[0] ]
		elif '<h1>404</h1>' in YBEsLq8gVw629cMGQP1T:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def IIMrxCDoVP(wHiSfdBL1v9Kl3n5):
	xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('postid=(.*?)&serverid=(.*?)&&',wHiSfdBL1v9Kl3n5+'&&',JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	cKCInoAwzkR95WtXJdVUMGr,mLZb7XU6gaE8 = xxyPKEIGHM75VZcR3S2z0Q[0]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+cKCInoAwzkR95WtXJdVUMGr+'&serverid='+mLZb7XU6gaE8
	headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
def iiz6XasOgk(url):
	RgNSOU7P93n = OfTKisDR0Lv(url,'url')
	JZP07kjvbV = {'Referer':RgNSOU7P93n,'Accept-Encoding':'gzip, deflate'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(WfPehiKL4XVlonMQr9kUwAca6IybDj,'GET',url,'',JZP07kjvbV,'','','RESOLVERS-MYCIMA-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('player.qualityselector(.*?)formats:',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = ''
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('format: \'(\d.*?)\', src: "(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
		for title,wHiSfdBL1v9Kl3n5 in items:
			JCop4mjTiurYB7W.append(title)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		if len(EEgFl59RndzrBL8TUoaQMw6P)==1: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = EEgFl59RndzrBL8TUoaQMw6P[0]
		elif len(EEgFl59RndzrBL8TUoaQMw6P)>1:
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر الملف المناسب', JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return '',[],[]
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = GGbRgKaoskDC[0]
	if not FrC9LhHZWIySdGwNsuzqt5Rf01TXO: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
def OOlZvwMeN2(url):
	RgNSOU7P93n = OfTKisDR0Lv(url,'url')
	JZP07kjvbV = {'Referer':RgNSOU7P93n,'Accept-Encoding':'gzip, deflate'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(WfPehiKL4XVlonMQr9kUwAca6IybDj,'GET',url,'',JZP07kjvbV,'','','RESOLVERS-WECIMA-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('player.qualityselector(.*?)formats:',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = ''
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('format: \'(\d.*?)\', src: "(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
		for title,wHiSfdBL1v9Kl3n5 in items:
			JCop4mjTiurYB7W.append(title)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		if len(EEgFl59RndzrBL8TUoaQMw6P)==1: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = EEgFl59RndzrBL8TUoaQMw6P[0]
		elif len(EEgFl59RndzrBL8TUoaQMw6P)>1:
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر الملف المناسب', JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return '',[],[]
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	if not FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = GGbRgKaoskDC[0]
	if not FrC9LhHZWIySdGwNsuzqt5Rf01TXO: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
def Ir6zUqvsmE(wHiSfdBL1v9Kl3n5):
	xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',wHiSfdBL1v9Kl3n5+'&&',JJDtX1PZyIgN2T.DOTALL)
	url,cKCInoAwzkR95WtXJdVUMGr,mLZb7XU6gaE8 = xxyPKEIGHM75VZcR3S2z0Q[0]
	data = {'post_id':cKCInoAwzkR95WtXJdVUMGr,'server':mLZb7XU6gaE8}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,'','','','RESOLVERS-AKOAMCAM-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('iframe src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
def DWkFCLHpqe(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','RESOLVERS-CIMALIGHT-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<iframe.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		if wHiSfdBL1v9Kl3n5: return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def dRoJIpX768(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','RESOLVERS-CIMACLUP-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<IFRAME SRC="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
def A3OWx6KM4Z(url):
	wHGCED2fklopYyFzI = OfTKisDR0Lv(url,'url')
	if 'index=' in url:
		headers = {'Referer':wHGCED2fklopYyFzI}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','RESOLVERS-CIMANOW-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
			if 'http' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = 'http:'+FrC9LhHZWIySdGwNsuzqt5Rf01TXO
			if 'cimanow' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('https://','http://')
				SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','','RESOLVERS-CIMANOW-2nd')
				Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
				items = JJDtX1PZyIgN2T.findall('source src="(.*?)".*?size="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
				JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
				i1TCt53bykSvPp8e = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'url')
				for wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 in reversed(items):
					wHiSfdBL1v9Kl3n5 = i1TCt53bykSvPp8e+wHiSfdBL1v9Kl3n5+'|Referer='+i1TCt53bykSvPp8e
					JCop4mjTiurYB7W.append(y2nBfLCjDoXkKiwb8WV6)
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
				return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
			else: return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'|Referer='+wHGCED2fklopYyFzI
	if 'http' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = 'http:'+FrC9LhHZWIySdGwNsuzqt5Rf01TXO
	return '',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
def IWuHYlG5psPvDN6BmjdSCafU0(wHiSfdBL1v9Kl3n5):
	wHGCED2fklopYyFzI = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'url')
	if 'postid' in wHiSfdBL1v9Kl3n5:
		xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',wHiSfdBL1v9Kl3n5+'&&',JJDtX1PZyIgN2T.DOTALL)
		url,cKCInoAwzkR95WtXJdVUMGr,mLZb7XU6gaE8 = xxyPKEIGHM75VZcR3S2z0Q[0]
		data = {'id':cKCInoAwzkR95WtXJdVUMGr,'server':mLZb7XU6gaE8}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,'','','','RESOLVERS-CIMANOW-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('iframe src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
		if 'cimanow' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			headers = {'Referer':wHGCED2fklopYyFzI,'User-Agent':''}
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','','RESOLVERS-CIMANOW-2nd')
			Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
			items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?size="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
			i1TCt53bykSvPp8e = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'url')
			for wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 in reversed(items):
				wHiSfdBL1v9Kl3n5 = i1TCt53bykSvPp8e+wHiSfdBL1v9Kl3n5+'|Referer='+i1TCt53bykSvPp8e
				JCop4mjTiurYB7W.append(y2nBfLCjDoXkKiwb8WV6)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
		else: return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	else:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'|Referer='+wHGCED2fklopYyFzI
		return '',[''],[wHiSfdBL1v9Kl3n5]
def KQk7oj83yq(wHiSfdBL1v9Kl3n5):
	if 'postid' in wHiSfdBL1v9Kl3n5:
		xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('postid=(.*?)&serverid=(.*?)&&',wHiSfdBL1v9Kl3n5+'&&',JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		cKCInoAwzkR95WtXJdVUMGr,mLZb7XU6gaE8 = xxyPKEIGHM75VZcR3S2z0Q[0]
		mx0c6BJ8UzATaV7 = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'url')
		url = mx0c6BJ8UzATaV7+'/ajaxCenter?_action=getserver&_post_id='+cKCInoAwzkR95WtXJdVUMGr+'&serverid='+mLZb7XU6gaE8
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-ARBLIONZ-1st')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('\n','').replace('\r','')
		return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	elif '/redirect/' in wHiSfdBL1v9Kl3n5:
		oISMg2J7z8nrWxitjAhGeBf = 0
		while '/redirect/' in wHiSfdBL1v9Kl3n5 and oISMg2J7z8nrWxitjAhGeBf<5:
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',wHiSfdBL1v9Kl3n5,'','','','','RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()): wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
			oISMg2J7z8nrWxitjAhGeBf += 1
		return '',[''],[wHiSfdBL1v9Kl3n5]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def llrz36PXkA(url):
	RgNSOU7P93n = OfTKisDR0Lv(url,'url')
	headers = {'Referer':RgNSOU7P93n,'User-Agent':yyYKmdtsAFic93()}
	if '/embed-' in url:
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-ARABSEED-2nd')
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if wHiSfdBL1v9Kl3n5:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0].replace('https','http')
			return '',[''],[wHiSfdBL1v9Kl3n5]
	else:
		ENHz2PfZUYKiCo1keqbX8 = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','RESOLVERS-ARABSEED-3rd')
		YBEsLq8gVw629cMGQP1T = ENHz2PfZUYKiCo1keqbX8.content
		JZP07kjvbV = headers.copy()
		if '_lnk_' in str(ENHz2PfZUYKiCo1keqbX8.cookies):
			cookies = ENHz2PfZUYKiCo1keqbX8.cookies
			JZP07kjvbV['Cookie'] = i35i6al7upCAreLFQ(lfM8WO96En(cookies))
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('link.href = "(http.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not wHiSfdBL1v9Kl3n5: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
		else:
			wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5[0])+'&d=1'
			pmTdyfMuY6I3UQczZ = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',wHiSfdBL1v9Kl3n5,'',JZP07kjvbV,'','','RESOLVERS-ARABSEED-4th')
			YBEsLq8gVw629cMGQP1T = pmTdyfMuY6I3UQczZ.content
			wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('id="btn".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if wHiSfdBL1v9Kl3n5:
				wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5[0])
				if 'mp4' in wHiSfdBL1v9Kl3n5 and '/d/' in wHiSfdBL1v9Kl3n5: return '',[''],[wHiSfdBL1v9Kl3n5]
				else: return 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
	return 'Error: Resolver Failed ARABSEED',[],[]
def uufmkNnLt8(wHiSfdBL1v9Kl3n5):
	if '_action=getserver' in wHiSfdBL1v9Kl3n5:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',wHiSfdBL1v9Kl3n5,'',headers,'','','RESOLVERS-SHAHID4U-1st')
		url = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[''],[url]
	else:
		xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('postid=(.*?)&serverid=(.*?)$',wHiSfdBL1v9Kl3n5,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		if not xxyPKEIGHM75VZcR3S2z0Q: xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('_post_id=(.*?)&serverid=(.*?)$',wHiSfdBL1v9Kl3n5,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		cKCInoAwzkR95WtXJdVUMGr,mLZb7XU6gaE8 = xxyPKEIGHM75VZcR3S2z0Q[0]
		RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'url')
		url = RgNSOU7P93n+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':cKCInoAwzkR95WtXJdVUMGr,'i':mLZb7XU6gaE8}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':wHiSfdBL1v9Kl3n5}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,headers,'','','RESOLVERS-SHAHID4U-2nd')
		Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('src="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0]
			return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def pOyYSrncudlUgTb725hzs6fk(OOVF8Nwa5kE6bMGdiYg4rm0JfKD):
	QiVB23yO51h9KUAk4IndNtu0YMG = BBwb2NzsHE.getSetting('av.akwam.verification')
	headers = {'Cookie':QiVB23yO51h9KUAk4IndNtu0YMG} if QiVB23yO51h9KUAk4IndNtu0YMG else ''
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	kqBSGvHZ9txailhR5VX = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	qcIPZ94LuE = str(SSzrgUnfVGL1hQsu40FoP7CWXax.headers)
	w2Jyhx4uWN1kRjZ = qcIPZ94LuE+kqBSGvHZ9txailhR5VX
	if '.mp4' in w2Jyhx4uWN1kRjZ: heF3WEQo7w6s0apxnUIr9 = True
	else:
		vY9Bq8MlUS2G1XL,BB0MgRSFCf5k6xyH4hLam,AANOSiEbR0,ttvkFAeTdm8KszNR,heF3WEQo7w6s0apxnUIr9 = '','','','',False
		captcha = JJDtX1PZyIgN2T.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',kqBSGvHZ9txailhR5VX,JJDtX1PZyIgN2T.DOTALL)
		if captcha: AANOSiEbR0,ttvkFAeTdm8KszNR = captcha[0]
		vxp28O4a10Vm = LWzUbE5adDslTXGr['PYTHON'][7]
		YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(32)
		if 0:
			data = {'user':YqywcljIHsFzoXaf0T97,'version':K0dHTfq6P73sD8lWLZpoh,'url':OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'key':ttvkFAeTdm8KszNR,'id':'','job':'geturls'}
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',vxp28O4a10Vm,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		YBEsLq8gVw629cMGQP1T = ''
		if YBEsLq8gVw629cMGQP1T.startswith('URLS='):
			MdgvNCbsQAkFY945Llj6o = G8EwoDOyKShm1i0IHMfNYZlU7('list',YBEsLq8gVw629cMGQP1T.split('URLS=',1)[1])
			for WAEqF7ZldrmL9Xw in MdgvNCbsQAkFY945Llj6o:
				url = WAEqF7ZldrmL9Xw['url']
				OtZMsjvzwxUWF = WAEqF7ZldrmL9Xw['method']
				data = WAEqF7ZldrmL9Xw['data']
				headers = WAEqF7ZldrmL9Xw['headers']
				SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,OtZMsjvzwxUWF,url,data,headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				kqBSGvHZ9txailhR5VX = SSzrgUnfVGL1hQsu40FoP7CWXax.content
				if '.mp4' in kqBSGvHZ9txailhR5VX:
					heF3WEQo7w6s0apxnUIr9 = True
					break
				qcIPZ94LuE = str(SSzrgUnfVGL1hQsu40FoP7CWXax.headers)
				w2Jyhx4uWN1kRjZ = qcIPZ94LuE+kqBSGvHZ9txailhR5VX
				vY9Bq8MlUS2G1XL = JJDtX1PZyIgN2T.findall('(akwamVerification\w+).*?"(eyJ.*?)"',w2Jyhx4uWN1kRjZ,JJDtX1PZyIgN2T.DOTALL)
				BB0MgRSFCf5k6xyH4hLam = JJDtX1PZyIgN2T.findall('recaptcha-token.*?"(03A.*?)"',w2Jyhx4uWN1kRjZ,JJDtX1PZyIgN2T.DOTALL)
				if BB0MgRSFCf5k6xyH4hLam: BB0MgRSFCf5k6xyH4hLam = BB0MgRSFCf5k6xyH4hLam[0]
				if vY9Bq8MlUS2G1XL or BB0MgRSFCf5k6xyH4hLam: break
		if not heF3WEQo7w6s0apxnUIr9:
			if not vY9Bq8MlUS2G1XL:
				if captcha and not BB0MgRSFCf5k6xyH4hLam:
					if 1: BB0MgRSFCf5k6xyH4hLam = Fjxed2z6PTCby0YmvOJwc9Q(ttvkFAeTdm8KszNR,'ar',OOVF8Nwa5kE6bMGdiYg4rm0JfKD)
					else:
						if not YBEsLq8gVw629cMGQP1T.startswith('ID='):
							data = {'user':YqywcljIHsFzoXaf0T97,'version':K0dHTfq6P73sD8lWLZpoh,'url':OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'key':ttvkFAeTdm8KszNR,'id':'','job':'getid'}
							SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',vxp28O4a10Vm,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
						else: YBEsLq8gVw629cMGQP1T = 'ID=1234::::TIMEOUT=45'
						if YBEsLq8gVw629cMGQP1T.startswith('ID='):
							SSwVND5PiBGMlrg84YWUh = JJDtX1PZyIgN2T.findall('ID=(.*?)::::TIMEOUT=(.*?)$',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
							aP0KDmQVHYFGIOM2,ObFSK3zDPkrX5qgN9 = SSwVND5PiBGMlrg84YWUh[0]
							Ay3eLGaTncD67lx8ZOud = 'هذه العملية تحتاج وقت من 10 إلى '+ObFSK3zDPkrX5qgN9+' ثانية'
							AL7Kjbmw0qcDit = W2mNFlgkhXS8KIQ0GcTt()
							AL7Kjbmw0qcDit.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',Ay3eLGaTncD67lx8ZOud)
							vvJ9E70RWb1ngXukDA = Mrx2OeZV1LNjBsQ58Savi7.time()
							I2smbQWVwaAdc,A1n3vphDBZWaNF2SLjM = 0,0
							while I2smbQWVwaAdc<int(ObFSK3zDPkrX5qgN9):
								VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,int(I2smbQWVwaAdc/int(ObFSK3zDPkrX5qgN9)*100),Ay3eLGaTncD67lx8ZOud,'',ObFSK3zDPkrX5qgN9+' / '+str(int(I2smbQWVwaAdc))+'  ثانية')
								if I2smbQWVwaAdc>A1n3vphDBZWaNF2SLjM+10:
									data = {'user':YqywcljIHsFzoXaf0T97,'version':K0dHTfq6P73sD8lWLZpoh,'url':OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'key':ttvkFAeTdm8KszNR,'id':aP0KDmQVHYFGIOM2,'job':'gettoken'}
									SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',vxp28O4a10Vm,data,'','','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
									if YBEsLq8gVw629cMGQP1T.startswith('TOKEN='):
										BB0MgRSFCf5k6xyH4hLam = YBEsLq8gVw629cMGQP1T.split('TOKEN=',1)[1]
										break
									A1n3vphDBZWaNF2SLjM = I2smbQWVwaAdc
								else: Mrx2OeZV1LNjBsQ58Savi7.sleep(1)
								I2smbQWVwaAdc = Mrx2OeZV1LNjBsQ58Savi7.time()-vvJ9E70RWb1ngXukDA
							AL7Kjbmw0qcDit.close()
				if BB0MgRSFCf5k6xyH4hLam:
					HJbCz6S9DAxpBevqVGEfjWZhgmL3u = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
					r4uPfwIokamLy89ibTqjWdQGVsEg = JJDtX1PZyIgN2T.findall('akwam_session=(.*?);',w2Jyhx4uWN1kRjZ,JJDtX1PZyIgN2T.DOTALL)
					if 'akwam_session' in list(HJbCz6S9DAxpBevqVGEfjWZhgmL3u.keys()): r4uPfwIokamLy89ibTqjWdQGVsEg = HJbCz6S9DAxpBevqVGEfjWZhgmL3u['akwam_session']
					elif r4uPfwIokamLy89ibTqjWdQGVsEg: r4uPfwIokamLy89ibTqjWdQGVsEg = r4uPfwIokamLy89ibTqjWdQGVsEg[0]
					captcha = JJDtX1PZyIgN2T.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',kqBSGvHZ9txailhR5VX,JJDtX1PZyIgN2T.DOTALL)
					if captcha: AANOSiEbR0,ttvkFAeTdm8KszNR = captcha[0]
					if r4uPfwIokamLy89ibTqjWdQGVsEg and captcha:
						headers = {'Cookie':'akwam_session='+r4uPfwIokamLy89ibTqjWdQGVsEg,'Referer':OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+BB0MgRSFCf5k6xyH4hLam
						SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'POST',AANOSiEbR0,data,headers,False,'','RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						kqBSGvHZ9txailhR5VX = SSzrgUnfVGL1hQsu40FoP7CWXax.content
						try: cookies = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
						except: cookies = {}
						vY9Bq8MlUS2G1XL = JJDtX1PZyIgN2T.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),JJDtX1PZyIgN2T.DOTALL)
			if vY9Bq8MlUS2G1XL:
				rBabYANvVwWzjCp2QF,vY9Bq8MlUS2G1XL = vY9Bq8MlUS2G1XL[0]
				QiVB23yO51h9KUAk4IndNtu0YMG = rBabYANvVwWzjCp2QF+'='+vY9Bq8MlUS2G1XL
				BBwb2NzsHE.setSetting('av.akwam.verification',QiVB23yO51h9KUAk4IndNtu0YMG)
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in kqBSGvHZ9txailhR5VX:
					headers = {'Cookie':QiVB23yO51h9KUAk4IndNtu0YMG}
					SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',OOVF8Nwa5kE6bMGdiYg4rm0JfKD,'',headers,'','','RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					kqBSGvHZ9txailhR5VX = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if not heF3WEQo7w6s0apxnUIr9 and not QiVB23yO51h9KUAk4IndNtu0YMG: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return kqBSGvHZ9txailhR5VX
def MoLGRCrH0B(url,type,y2nBfLCjDoXkKiwb8WV6):
	pB8XANf71vaPJsedkWVIc5,u6jVYl28ZRT7UXzwxJH3va = [],[]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','RESOLVERS-AKWAM-1st')
	Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('<a href=".*?</a>',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
	for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
		kwqYoF8han = JJDtX1PZyIgN2T.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in kwqYoF8han:
			if wHiSfdBL1v9Kl3n5 in pB8XANf71vaPJsedkWVIc5: continue
			if '/watch/' not in wHiSfdBL1v9Kl3n5 and '/download/' not in wHiSfdBL1v9Kl3n5: continue
			title = title.replace('</span>','').replace(' - ','').strip(' ').replace('  ',' ')
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
			u6jVYl28ZRT7UXzwxJH3va.append(title)
	if len(pB8XANf71vaPJsedkWVIc5)>1:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('بعضها يحتاج 60 ثانية',u6jVYl28ZRT7UXzwxJH3va)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return 'Error: Resolver Canceled AKWAM',[],[]
	elif len(pB8XANf71vaPJsedkWVIc5)==1: zKgFfQoODy90ewYb5jGElUJRVs4p = 0
	else: return 'Error: Resolver Failed AKWAM',[],[]
	OOVF8Nwa5kE6bMGdiYg4rm0JfKD = pB8XANf71vaPJsedkWVIc5[zKgFfQoODy90ewYb5jGElUJRVs4p]
	kqBSGvHZ9txailhR5VX = pOyYSrncudlUgTb725hzs6fk(OOVF8Nwa5kE6bMGdiYg4rm0JfKD)
	EEgFl59RndzrBL8TUoaQMw6P,JCop4mjTiurYB7W = [],[]
	if type=='download':
		aJhqEGmS82BQy = JJDtX1PZyIgN2T.findall('btn-loader.*?href="(.*?)"',kqBSGvHZ9txailhR5VX,JJDtX1PZyIgN2T.DOTALL)
		if aJhqEGmS82BQy:
			wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(aJhqEGmS82BQy[0])
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			JCop4mjTiurYB7W.append(y2nBfLCjDoXkKiwb8WV6)
	elif type=='watch':
		kwqYoF8han = JJDtX1PZyIgN2T.findall('<source.*?src="(.*?)".*?size="(.*?)"',kqBSGvHZ9txailhR5VX,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,size in kwqYoF8han:
			if not wHiSfdBL1v9Kl3n5: continue
			if y2nBfLCjDoXkKiwb8WV6 in size:
				JCop4mjTiurYB7W.append(size)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
				break
		if not EEgFl59RndzrBL8TUoaQMw6P:
			for wHiSfdBL1v9Kl3n5,size in kwqYoF8han:
				if not wHiSfdBL1v9Kl3n5: continue
				JCop4mjTiurYB7W.append(size)
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if not EEgFl59RndzrBL8TUoaQMw6P: return 'Error: Resolver Failed AKWAM',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def SN6YMRIvqW(url,rBabYANvVwWzjCp2QF):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','',True,'','RESOLVERS-AKOAM-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	cookies = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
	if 'golink' in list(cookies.keys()):
		QiVB23yO51h9KUAk4IndNtu0YMG = cookies['golink']
		QiVB23yO51h9KUAk4IndNtu0YMG = i35i6al7upCAreLFQ(CpRxBfZmj8VYNE50ULd3rJGl2giFhe(QiVB23yO51h9KUAk4IndNtu0YMG))
		items = JJDtX1PZyIgN2T.findall('route":"(.*?)"',QiVB23yO51h9KUAk4IndNtu0YMG,JJDtX1PZyIgN2T.DOTALL)
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = items[0].replace('\/','/')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
	if 'catch.is' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
		id = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('%2F')[-1]
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = 'http://catch.is/'+id
		return 'NEED_EXTERNAL_RESOLVERS',[''],[FrC9LhHZWIySdGwNsuzqt5Rf01TXO]
	else:
		website = LWzUbE5adDslTXGr['AKOAM'][0]
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',website,'','',True,'','RESOLVERS-AKOAM-2nd')
		vRw53CjWH61stPAalEoT = SSzrgUnfVGL1hQsu40FoP7CWXax.url
		YsA9wq2CIlTkFmrX1bRd5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('/')[2]
		WctG9EI3vrCepKi5J = vRw53CjWH61stPAalEoT.split('/')[2]
		kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace(YsA9wq2CIlTkFmrX1bRd5,WctG9EI3vrCepKi5J)
		headers = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' , 'Referer':kHWT0XY2S6apruwxiB8FDl1 }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST', kHWT0XY2S6apruwxiB8FDl1, '', headers, False,'','RESOLVERS-AKOAM-3rd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		items = JJDtX1PZyIgN2T.findall('direct_link":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		if not items:
			items = JJDtX1PZyIgN2T.findall('<iframe.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
			if not items:
				items = JJDtX1PZyIgN2T.findall('<embed.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
		if items:
			wHiSfdBL1v9Kl3n5 = items[0].replace('\/','/')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.rstrip('/')
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:' + wHiSfdBL1v9Kl3n5
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('http://','https://')
			if rBabYANvVwWzjCp2QF=='': rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[''],[wHiSfdBL1v9Kl3n5]
			else: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = 'NEED_EXTERNAL_RESOLVERS',[''],[wHiSfdBL1v9Kl3n5]
		else: rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = 'Error: Resolver Failed AKOAM',[],[]
		return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def etyp8R5nxQmJIBuHSkE0YKcdWC(url):
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-RAPIDVIDEO-1st')
	items = JJDtX1PZyIgN2T.findall('<source src="(.*?)".*?label="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,errno = [],[],''
	if items:
		for wHiSfdBL1v9Kl3n5,MpTK2YaAjI4NWtiGcC3PQg in items:
			JCop4mjTiurYB7W.append(MpTK2YaAjI4NWtiGcC3PQg)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def eCzdrtZFSIPLDwk(url):
	headers = {'User-Agent':''}
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-UQLOAD-1st')
	items = JJDtX1PZyIgN2T.findall('sources: \["(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		url = items[0]+'|Referer='+url
		return '',[''],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def LLEJK1ePHN8M(url):
	url = url.strip('/')
	if '/embed/' in url: id = url.split('/')[4]
	else: id = url.split('/')[-1]
	url = 'https://vcstream.to/player?fid=' + id
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-VCSTREAM-1st')
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('\\','')
	items = JJDtX1PZyIgN2T.findall('file":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def uC0DgYaPMwt9mnriXpqLfK(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-VIDOZA-1st')
	items = JJDtX1PZyIgN2T.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	for wHiSfdBL1v9Kl3n5,MpTK2YaAjI4NWtiGcC3PQg,wU90RY1iSsDlP in items:
		JCop4mjTiurYB7W.append(MpTK2YaAjI4NWtiGcC3PQg+' '+wU90RY1iSsDlP)
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed VIDOZA',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def P2PAF0fKzgxJbGi3OBvSkc6mR(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-WATCHVIDEO-1st')
	items = JJDtX1PZyIgN2T.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	items = set(items)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	for id,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,hash,MpTK2YaAjI4NWtiGcC3PQg,wU90RY1iSsDlP in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+id+'&mode='+AFWci0tYmjRU1azGJEy3ovDw2hfsqr+'&hash='+hash
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-WATCHVIDEO-2nd')
		items = JJDtX1PZyIgN2T.findall('direct link.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in items:
			JCop4mjTiurYB7W.append(MpTK2YaAjI4NWtiGcC3PQg+' '+wU90RY1iSsDlP)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if len(EEgFl59RndzrBL8TUoaQMw6P)==0: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def FPlKrLtyn2gsQ05w8Ne(url):
	wHiSfdBL1v9Kl3n5 = ''
	if 1 or 'Key=' not in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('upbom.live','uppom.live')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('/')
		id = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[3]
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = '/'.join(FrC9LhHZWIySdGwNsuzqt5Rf01TXO[0:4])
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {'id':id,'op':'download2','method_free':'Free+Download+%3E%3E'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,'','','','RESOLVERS-UPBOM-1st')
		if 'Location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()): wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		if not wHiSfdBL1v9Kl3n5 and SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
			wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('id="direct_link".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','RESOLVERS-UPBOM-2nd')
		if 'location' in list(SSzrgUnfVGL1hQsu40FoP7CWXax.headers.keys()): wHiSfdBL1v9Kl3n5 = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['location']
	if wHiSfdBL1v9Kl3n5: return '',[''],[wHiSfdBL1v9Kl3n5]
	return 'Error: Resolver Failed UPBOM',[],[]
def SSWlv3Vy1zHT0DMu7O4kf8cr9EPap(url):
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-LIIVIDEO-1st')
	items = JJDtX1PZyIgN2T.findall('sources:.*?"(.*?)","(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	if items:
		JCop4mjTiurYB7W.append('mp4')
		EEgFl59RndzrBL8TUoaQMw6P.append(items[0][1])
		JCop4mjTiurYB7W.append('m3u8')
		EEgFl59RndzrBL8TUoaQMw6P.append(items[0][0])
		return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
def Z5aTos0RvJ(url):
	id = url.split('/')[-1]
	id = id.split('&')[0]
	id = id.replace('watch?v=','')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = LWzUbE5adDslTXGr['YOUTUBE'][0]+'/watch?v='+id
	BUX6v5o4FuMtma = 'http://youtu.be/'+id
	OhvIzGts3b,gg1xH9u5eS0pkAwyZizMOqPdfNW,Lz7eWoYsiJ94guQTyGFK,am3rnY5bE4JGj = '','','',''
	for uvTwHSmjyW6Vr0192IZ in range(5):
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','RESOLVERS-YOUTUBE-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if 'itag' in YBEsLq8gVw629cMGQP1T: break
		Mrx2OeZV1LNjBsQ58Savi7.sleep(2)
	vZJ7na4qiNTEI = JJDtX1PZyIgN2T.findall('var ytInitialPlayerResponse = (.*?);</script>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vZJ7na4qiNTEI: vZJ7na4qiNTEI = vZJ7na4qiNTEI[0]
	else: vZJ7na4qiNTEI = YBEsLq8gVw629cMGQP1T
	vZJ7na4qiNTEI = vZJ7na4qiNTEI.replace('\\u0026','&')
	SrgC0oQ7jfJVbaqy = G8EwoDOyKShm1i0IHMfNYZlU7('dict',vZJ7na4qiNTEI)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = ['بدون ترجمة يوتيوب'],['']
	try:
		PdZoLfAnpH0g7aC39FBz1TN = SrgC0oQ7jfJVbaqy['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for ddp5V4guXL8 in PdZoLfAnpH0g7aC39FBz1TN:
			wHiSfdBL1v9Kl3n5 = ddp5V4guXL8['baseUrl']
			try: title = ddp5V4guXL8['name']['simpleText']
			except: title = ddp5V4guXL8['name']['runs'][0]['textt']
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			JCop4mjTiurYB7W.append(title)
	except: pass
	if len(JCop4mjTiurYB7W)>1:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الترجمة المناسبة:', JCop4mjTiurYB7W)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return 'EXIT_RESOLVER',[],[]
		elif zKgFfQoODy90ewYb5jGElUJRVs4p!=0:
			wHiSfdBL1v9Kl3n5 = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]+'&'
			mjAl8kZyGYvzcWaCTrXPJRtLOinS3 = JJDtX1PZyIgN2T.findall('&(fmt=.*?)&',wHiSfdBL1v9Kl3n5)
			if mjAl8kZyGYvzcWaCTrXPJRtLOinS3: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace(mjAl8kZyGYvzcWaCTrXPJRtLOinS3[0],'fmt=vtt')
			else: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'fmt=vtt'
			OhvIzGts3b = wHiSfdBL1v9Kl3n5.strip('&')
	Z2wiv6Wjl7QUgDut,ffc87j2EkGVy1P,dpX3QfWjvKJ4o7T1PxIyRaFc9C6,WWywmfJb8XpVktO12unI7,CY7amxXOBuZh9Dc = [],[],[],[],[]
	try: gg1xH9u5eS0pkAwyZizMOqPdfNW = SrgC0oQ7jfJVbaqy['streamingData']['dashManifestUrl']
	except: pass
	try: Lz7eWoYsiJ94guQTyGFK = SrgC0oQ7jfJVbaqy['streamingData']['hlsManifestUrl']
	except: pass
	try: Z2wiv6Wjl7QUgDut = SrgC0oQ7jfJVbaqy['streamingData']['formats']
	except: pass
	try: ffc87j2EkGVy1P = SrgC0oQ7jfJVbaqy['streamingData']['adaptiveFormats']
	except: pass
	KQjtYRNTUX1OEblxu0VDGA = Z2wiv6Wjl7QUgDut+ffc87j2EkGVy1P
	for dict in KQjtYRNTUX1OEblxu0VDGA:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			EgXrfev3tHLVsjqFu1M = dict['signatureCipher'].split('&')
			for KxB8vVHUJg in EgXrfev3tHLVsjqFu1M:
				key,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=',1)
				dict[key] = i35i6al7upCAreLFQ(Y3YqSmycrIWksoH5N0MvC)
		if 'url' in list(dict.keys()): dict['url'] = i35i6al7upCAreLFQ(dict['url'])
		dpX3QfWjvKJ4o7T1PxIyRaFc9C6.append(dict)
	njwBRQJbMeuxl3v86It9LfH0N = ''
	if 'sp=sig' in vZJ7na4qiNTEI:
		uUVA6XjdIWTac = JJDtX1PZyIgN2T.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if uUVA6XjdIWTac:
			uUVA6XjdIWTac = LWzUbE5adDslTXGr['YOUTUBE'][0]+uUVA6XjdIWTac[0]
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',uUVA6XjdIWTac,'','','','','RESOLVERS-YOUTUBE-2nd')
			njwBRQJbMeuxl3v86It9LfH0N = SSzrgUnfVGL1hQsu40FoP7CWXax.content
			import youtube_signature.cipher as GRKFXf07Oljk1BnY,youtube_signature.json_script_engine as OEy3kmhYR95DcwnIBVr2FSxsgqGdA
			EgXrfev3tHLVsjqFu1M = ElY3GqICniZoVJtypH6hzTfO.EgXrfev3tHLVsjqFu1M.Cipher()
			EgXrfev3tHLVsjqFu1M._object_cache = {}
			XSfOQEycGFZRHbtjnhAv0K86raoM = EgXrfev3tHLVsjqFu1M._load_javascript(njwBRQJbMeuxl3v86It9LfH0N)
			fg1yW2hts8oaRMz = G8EwoDOyKShm1i0IHMfNYZlU7('str',str(XSfOQEycGFZRHbtjnhAv0K86raoM))
			UrDqwmoBOKj9R = ElY3GqICniZoVJtypH6hzTfO.zv1jrbPRqDGS5NQknt8JZHoWfMLa.JsonScriptEngine(fg1yW2hts8oaRMz)
	for dict in dpX3QfWjvKJ4o7T1PxIyRaFc9C6:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>1:
			WWywmfJb8XpVktO12unI7.append(dict)
		elif njwBRQJbMeuxl3v86It9LfH0N and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			FHprM7egxa4bD = UrDqwmoBOKj9R.execute(dict['s'])
			if FHprM7egxa4bD!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+FHprM7egxa4bD
				WWywmfJb8XpVktO12unI7.append(dict)
	for dict in WWywmfJb8XpVktO12unI7:
		ohCurPI3fkJGw8jB09n5Q1lHUvzETL,C5wQVyz2AcM9bD4j07XpY38umrU,RzdeCZTqngwmEV8riGbD,pnF0HTjGdfAleEZ4hRYwS,DLf79yscmv3oXQIEBjR8HAwnKZO0t,sKyYbxqDkw3cC0t = 'unknown','unknown','unknown','Unknown','','0'
		try:
			rrPaLdkZU4lOuiYe = dict['type']
			rrPaLdkZU4lOuiYe = rrPaLdkZU4lOuiYe.replace('+','')
			items = JJDtX1PZyIgN2T.findall('(.*?)/(.*?);.*?"(.*?)"',rrPaLdkZU4lOuiYe,JJDtX1PZyIgN2T.DOTALL)
			pnF0HTjGdfAleEZ4hRYwS,ohCurPI3fkJGw8jB09n5Q1lHUvzETL,DLf79yscmv3oXQIEBjR8HAwnKZO0t = items[0]
			R2kTIfVY7wLJn6g = DLf79yscmv3oXQIEBjR8HAwnKZO0t.split(',')
			C5wQVyz2AcM9bD4j07XpY38umrU = ''
			for KxB8vVHUJg in R2kTIfVY7wLJn6g: C5wQVyz2AcM9bD4j07XpY38umrU += KxB8vVHUJg.split('.')[0]+','
			C5wQVyz2AcM9bD4j07XpY38umrU = C5wQVyz2AcM9bD4j07XpY38umrU.strip(',')
			if 'bitrate' in list(dict.keys()): sKyYbxqDkw3cC0t = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: sKyYbxqDkw3cC0t = ''
			if pnF0HTjGdfAleEZ4hRYwS=='textt': continue
			elif ',' in rrPaLdkZU4lOuiYe:
				pnF0HTjGdfAleEZ4hRYwS = 'A+V'
				RzdeCZTqngwmEV8riGbD = ohCurPI3fkJGw8jB09n5Q1lHUvzETL+'  '+sKyYbxqDkw3cC0t+dict['size'].split('x')[1]
			elif pnF0HTjGdfAleEZ4hRYwS=='video':
				pnF0HTjGdfAleEZ4hRYwS = 'Video'
				RzdeCZTqngwmEV8riGbD = sKyYbxqDkw3cC0t+dict['size'].split('x')[1]+'  '+dict['fps']+'fps'+'  '+ohCurPI3fkJGw8jB09n5Q1lHUvzETL
			elif pnF0HTjGdfAleEZ4hRYwS=='audio':
				pnF0HTjGdfAleEZ4hRYwS = 'Audio'
				RzdeCZTqngwmEV8riGbD = sKyYbxqDkw3cC0t+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+'  '+ohCurPI3fkJGw8jB09n5Q1lHUvzETL
		except:
			n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
			if n6MNfIpoX7GgJZu!='NoneType: None\n': uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
		if 'dur=' in dict['url']: hhCd56yES0cqfUKRsZaVI4wzWuTO = round(0.5+float(dict['url'].split('dur=',1)[1].split('&',1)[0]))
		elif 'approxDurationMs' in list(dict.keys()): hhCd56yES0cqfUKRsZaVI4wzWuTO = round(0.5+float(dict['approxDurationMs'])/1000)
		else: hhCd56yES0cqfUKRsZaVI4wzWuTO = '0'
		if 'bitrate' not in list(dict.keys()): sKyYbxqDkw3cC0t = dict['size'].split('x')[1]
		else: sKyYbxqDkw3cC0t = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = pnF0HTjGdfAleEZ4hRYwS+':  '+RzdeCZTqngwmEV8riGbD+'  ('+C5wQVyz2AcM9bD4j07XpY38umrU+','+dict['itag']+')'
		dict['quality'] = RzdeCZTqngwmEV8riGbD.split('  ')[0].split('kbps')[0]
		dict['type2'] = pnF0HTjGdfAleEZ4hRYwS
		dict['filetype'] = ohCurPI3fkJGw8jB09n5Q1lHUvzETL
		dict['codecs'] = DLf79yscmv3oXQIEBjR8HAwnKZO0t
		dict['duration'] = hhCd56yES0cqfUKRsZaVI4wzWuTO
		dict['bitrate'] = sKyYbxqDkw3cC0t
		CY7amxXOBuZh9Dc.append(dict)
	NPewSla3sFnB,QjG3ohDrEeL06tivKZ5,Kq8IEaXtdrHcyNPWz,NUbhcCF6mvB5sMjtKAR7ogZuX,dJFaboZU1lRf4kSwgc39P7Ix = [],[],[],[],[]
	bbL0p35qOnS,iiQLeGDKOI,FqA78XlHQ4UZS0p6xGjMzLt,GtR5vUo1xXAQ,Bf6LPDbHtFrQ = [],[],[],[],[]
	if gg1xH9u5eS0pkAwyZizMOqPdfNW:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
		dict['url'] = gg1xH9u5eS0pkAwyZizMOqPdfNW
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		CY7amxXOBuZh9Dc.append(dict)
	if Lz7eWoYsiJ94guQTyGFK:
		qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,r03wsLKJioDyYhQTxX = XuJcNIWr8FMGQS(Lz7eWoYsiJ94guQTyGFK)
		rxCzP1qmWLs6fngBhJHT2G3c = list(zip(qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,r03wsLKJioDyYhQTxX))
		for title,wHiSfdBL1v9Kl3n5 in rxCzP1qmWLs6fngBhJHT2G3c:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = wHiSfdBL1v9Kl3n5
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[0].rsplit('  ')[-1]
			else: dict['bitrate'] = '10'
			if title.count('  ')>1:
				y2nBfLCjDoXkKiwb8WV6 = title.rsplit('  ')[-3]
				if y2nBfLCjDoXkKiwb8WV6.isdigit(): dict['quality'] = y2nBfLCjDoXkKiwb8WV6
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+'  '+dict['bitrate']+'kbps  '+dict['quality']
			CY7amxXOBuZh9Dc.append(dict)
	CY7amxXOBuZh9Dc = sorted(CY7amxXOBuZh9Dc,reverse=True,key=lambda key: float(key['bitrate']))
	if not CY7amxXOBuZh9Dc:
		DDTdLb3SZQPv7rX1qfwHCpn2eyKc = JJDtX1PZyIgN2T.findall('class="messagee">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		d1cgFMGN2Eaoz9AelBI = JJDtX1PZyIgN2T.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		sHCNe7qXk2m = JJDtX1PZyIgN2T.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		R8Rag2sH1WBKOSFovjkdLn = JJDtX1PZyIgN2T.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		try: WBHA4XTOYEpdLZ7ijf8tyVkI6 = SrgC0oQ7jfJVbaqy['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][0]['textt']
		except: WBHA4XTOYEpdLZ7ijf8tyVkI6 = ''
		try: gtERJz1moheKiS2H = SrgC0oQ7jfJVbaqy['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][0]['runs'][0]['textt']
		except: gtERJz1moheKiS2H = ''
		try: u4pmfwtrYN = SrgC0oQ7jfJVbaqy['playabilityStatus']['reason']
		except: u4pmfwtrYN = ''
		if DDTdLb3SZQPv7rX1qfwHCpn2eyKc or d1cgFMGN2Eaoz9AelBI or sHCNe7qXk2m or R8Rag2sH1WBKOSFovjkdLn or WBHA4XTOYEpdLZ7ijf8tyVkI6 or gtERJz1moheKiS2H or u4pmfwtrYN:
			if   DDTdLb3SZQPv7rX1qfwHCpn2eyKc: Ay3eLGaTncD67lx8ZOud = DDTdLb3SZQPv7rX1qfwHCpn2eyKc[0]
			elif d1cgFMGN2Eaoz9AelBI: Ay3eLGaTncD67lx8ZOud = d1cgFMGN2Eaoz9AelBI[0]
			elif sHCNe7qXk2m: Ay3eLGaTncD67lx8ZOud = sHCNe7qXk2m[0]
			elif R8Rag2sH1WBKOSFovjkdLn: Ay3eLGaTncD67lx8ZOud = R8Rag2sH1WBKOSFovjkdLn[0]
			elif WBHA4XTOYEpdLZ7ijf8tyVkI6: Ay3eLGaTncD67lx8ZOud = WBHA4XTOYEpdLZ7ijf8tyVkI6
			elif gtERJz1moheKiS2H: Ay3eLGaTncD67lx8ZOud = gtERJz1moheKiS2H
			elif u4pmfwtrYN: Ay3eLGaTncD67lx8ZOud = u4pmfwtrYN
			iDVwr2OcWJ1thzjPlf = Ay3eLGaTncD67lx8ZOud.replace('\n','').strip(' ')
			gVuIYmS97d = '[COLOR FFC89008]هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن[/COLOR]'
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من الموقع والمبرمج',gVuIYmS97d+'\n\n'+iDVwr2OcWJ1thzjPlf)
			return 'Error    : Resolver YOUTUBE Failed: '+iDVwr2OcWJ1thzjPlf,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	d1IMUO674tXSRCyzvTimgrJfADWZ,vvTqD9zlcgt7NVXWFkmryu,VOGzgZ80U6RD1H = [],[],[]
	for dict in CY7amxXOBuZh9Dc:
		if dict['type2']=='Video':
			NPewSla3sFnB.append(dict['title'])
			bbL0p35qOnS.append(dict)
		elif dict['type2']=='Audio':
			QjG3ohDrEeL06tivKZ5.append(dict['title'])
			iiQLeGDKOI.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): sKyYbxqDkw3cC0t = '0'
			else: sKyYbxqDkw3cC0t = dict['bitrate']
			d1IMUO674tXSRCyzvTimgrJfADWZ.append([dict,{},title,sKyYbxqDkw3cC0t])
		else:
			title = dict['title'].replace('A+V:  ','')
			if 'bitrate' not in list(dict.keys()): sKyYbxqDkw3cC0t = '0'
			else: sKyYbxqDkw3cC0t = dict['bitrate']
			d1IMUO674tXSRCyzvTimgrJfADWZ.append([dict,{},title,sKyYbxqDkw3cC0t])
			Kq8IEaXtdrHcyNPWz.append(title)
			FqA78XlHQ4UZS0p6xGjMzLt.append(dict)
		UkCiIaodwqG9h = True
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: UkCiIaodwqG9h = False
			elif WWSLAyQdhUXl3ovb<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: UkCiIaodwqG9h = False
		if dict['type2']=='Video' and dict['init']!='0-0' and UkCiIaodwqG9h==True:
			dJFaboZU1lRf4kSwgc39P7Ix.append(dict['title'])
			Bf6LPDbHtFrQ.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and UkCiIaodwqG9h==True:
			NUbhcCF6mvB5sMjtKAR7ogZuX.append(dict['title'])
			GtR5vUo1xXAQ.append(dict)
	for TtI7Hp2xha8BRjLCgveZV in GtR5vUo1xXAQ:
		YsLhM3yqd4SeFg8POnw0 = TtI7Hp2xha8BRjLCgveZV['bitrate']
		for DDcnWFCEglh in Bf6LPDbHtFrQ:
			bsqd3AnKka6X = DDcnWFCEglh['bitrate']
			sKyYbxqDkw3cC0t = bsqd3AnKka6X+YsLhM3yqd4SeFg8POnw0
			title = DDcnWFCEglh['title'].replace('Video:  ','mpd  ')
			title = title.replace(DDcnWFCEglh['filetype']+'  ','')
			title = title.replace(str((float(bsqd3AnKka6X*10)//1024/10))+'kbps',str((float(sKyYbxqDkw3cC0t*10)//1024/10))+'kbps')
			title = title+'('+TtI7Hp2xha8BRjLCgveZV['title'].split('(',1)[1]
			d1IMUO674tXSRCyzvTimgrJfADWZ.append([DDcnWFCEglh,TtI7Hp2xha8BRjLCgveZV,title,sKyYbxqDkw3cC0t])
	d1IMUO674tXSRCyzvTimgrJfADWZ = sorted(d1IMUO674tXSRCyzvTimgrJfADWZ, reverse=True, key=lambda key: float(key[3]))
	for DDcnWFCEglh,TtI7Hp2xha8BRjLCgveZV,title,sKyYbxqDkw3cC0t in d1IMUO674tXSRCyzvTimgrJfADWZ:
		AAHpZUD4cnNGx0X1ob9iBw = DDcnWFCEglh['filetype']
		if 'filetype' in list(TtI7Hp2xha8BRjLCgveZV.keys()):
			AAHpZUD4cnNGx0X1ob9iBw = 'mpd'
		if AAHpZUD4cnNGx0X1ob9iBw not in VOGzgZ80U6RD1H:
			VOGzgZ80U6RD1H.append(AAHpZUD4cnNGx0X1ob9iBw)
			vvTqD9zlcgt7NVXWFkmryu.append([DDcnWFCEglh,TtI7Hp2xha8BRjLCgveZV,title,sKyYbxqDkw3cC0t])
	yakipx7nClN,rhXLqmxD1M9zHfZkdE8gt,ooHKBXGgZDjaLivsYmONu = [],[],0
	Mf5YkAEwcPGvq,lu7beTYcXHj1IwJGOAaNZyP8zE = '',''
	try: Mf5YkAEwcPGvq = SrgC0oQ7jfJVbaqy['videoDetails']['author']
	except: Mf5YkAEwcPGvq = ''
	try: WIbQfCviDzTa2FhjBJ4prHE05s = SrgC0oQ7jfJVbaqy['videoDetails']['channelId']
	except: WIbQfCviDzTa2FhjBJ4prHE05s = ''
	if Mf5YkAEwcPGvq and WIbQfCviDzTa2FhjBJ4prHE05s:
		ooHKBXGgZDjaLivsYmONu += 1
		title = '[COLOR FFC89008]OWNER:  '+Mf5YkAEwcPGvq+'[/COLOR]'
		wHiSfdBL1v9Kl3n5 = LWzUbE5adDslTXGr['YOUTUBE'][0]+'/channel/'+WIbQfCviDzTa2FhjBJ4prHE05s
		yakipx7nClN.append(title)
		rhXLqmxD1M9zHfZkdE8gt.append(wHiSfdBL1v9Kl3n5)
		try: lu7beTYcXHj1IwJGOAaNZyP8zE = SrgC0oQ7jfJVbaqy['videoDetails']['thumbnail']['thumbnails'][-1]['url']
		except: pass
	for DDcnWFCEglh,TtI7Hp2xha8BRjLCgveZV,title,sKyYbxqDkw3cC0t in vvTqD9zlcgt7NVXWFkmryu:
		yakipx7nClN.append(title) ; rhXLqmxD1M9zHfZkdE8gt.append('highest')
	if Kq8IEaXtdrHcyNPWz: yakipx7nClN.append('صورة وصوت محددة') ; rhXLqmxD1M9zHfZkdE8gt.append('muxed')
	if d1IMUO674tXSRCyzvTimgrJfADWZ: yakipx7nClN.append('صورة وصوت المتوفر') ; rhXLqmxD1M9zHfZkdE8gt.append('all')
	if dJFaboZU1lRf4kSwgc39P7Ix: yakipx7nClN.append('mpd اختر الصورة والصوت') ; rhXLqmxD1M9zHfZkdE8gt.append('mpd')
	if NPewSla3sFnB: yakipx7nClN.append('صورة بدون صوت') ; rhXLqmxD1M9zHfZkdE8gt.append('video')
	if QjG3ohDrEeL06tivKZ5: yakipx7nClN.append('صوت بدون صورة') ; rhXLqmxD1M9zHfZkdE8gt.append('audio')
	BAefDXsMmogaJpRPYH24WZN3 = False
	while True:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT(BUX6v5o4FuMtma, yakipx7nClN)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return 'EXIT_RESOLVER',[],[]
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==0 and Mf5YkAEwcPGvq:
			wHiSfdBL1v9Kl3n5 = rhXLqmxD1M9zHfZkdE8gt[zKgFfQoODy90ewYb5jGElUJRVs4p]
			fbCg3QuR1M6dlAXDTnIFoe7aE = uea9JUBOMcEfh8CN0v6b.argv[0]+'?type=folder&mode=141&name='+FVsLwz1tAH(Mf5YkAEwcPGvq)+'&url='+wHiSfdBL1v9Kl3n5
			if lu7beTYcXHj1IwJGOAaNZyP8zE: fbCg3QuR1M6dlAXDTnIFoe7aE = fbCg3QuR1M6dlAXDTnIFoe7aE+'&image='+FVsLwz1tAH(lu7beTYcXHj1IwJGOAaNZyP8zE)
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin("Container.Update("+fbCg3QuR1M6dlAXDTnIFoe7aE+")")
			return 'EXIT_RESOLVER',[],[]
		d1cy9GkbBivnRNTChoEFu5xIXp4 = rhXLqmxD1M9zHfZkdE8gt[zKgFfQoODy90ewYb5jGElUJRVs4p]
		GwqoS2C6TY = yakipx7nClN[zKgFfQoODy90ewYb5jGElUJRVs4p]
		if d1cy9GkbBivnRNTChoEFu5xIXp4=='dash':
			am3rnY5bE4JGj = gg1xH9u5eS0pkAwyZizMOqPdfNW
			break
		elif d1cy9GkbBivnRNTChoEFu5xIXp4 in ['audio','video','muxed']:
			if d1cy9GkbBivnRNTChoEFu5xIXp4=='muxed': JCop4mjTiurYB7W,K3VOhgtDWpTi9rnJ4Nk8FHP = Kq8IEaXtdrHcyNPWz,FqA78XlHQ4UZS0p6xGjMzLt
			elif d1cy9GkbBivnRNTChoEFu5xIXp4=='video': JCop4mjTiurYB7W,K3VOhgtDWpTi9rnJ4Nk8FHP = NPewSla3sFnB,bbL0p35qOnS
			elif d1cy9GkbBivnRNTChoEFu5xIXp4=='audio': JCop4mjTiurYB7W,K3VOhgtDWpTi9rnJ4Nk8FHP = QjG3ohDrEeL06tivKZ5,iiQLeGDKOI
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الملف المناسب:', JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p!=-1:
				am3rnY5bE4JGj = K3VOhgtDWpTi9rnJ4Nk8FHP[zKgFfQoODy90ewYb5jGElUJRVs4p]['url']
				GwqoS2C6TY = JCop4mjTiurYB7W[zKgFfQoODy90ewYb5jGElUJRVs4p]
				break
		elif d1cy9GkbBivnRNTChoEFu5xIXp4=='mpd':
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر جودة الصورة:', dJFaboZU1lRf4kSwgc39P7Ix)
			if zKgFfQoODy90ewYb5jGElUJRVs4p!=-1:
				GwqoS2C6TY = dJFaboZU1lRf4kSwgc39P7Ix[zKgFfQoODy90ewYb5jGElUJRVs4p]
				BSFOqGAkHwW7Drg5Y = Bf6LPDbHtFrQ[zKgFfQoODy90ewYb5jGElUJRVs4p]
				zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر جودة الصوت:', NUbhcCF6mvB5sMjtKAR7ogZuX)
				if zKgFfQoODy90ewYb5jGElUJRVs4p!=-1:
					GwqoS2C6TY += ' + '+NUbhcCF6mvB5sMjtKAR7ogZuX[zKgFfQoODy90ewYb5jGElUJRVs4p]
					QQWS4dY35ZTyeaRLhEHVmbGlFIw8 = GtR5vUo1xXAQ[zKgFfQoODy90ewYb5jGElUJRVs4p]
					BAefDXsMmogaJpRPYH24WZN3 = True
					break
		elif d1cy9GkbBivnRNTChoEFu5xIXp4=='all':
			D7Xl2e3wTJhyKnOrkUQS6N8E,thWmnplsGKzQ3i2V,dWmNPtXIflSqr50KAFboEDuCv8Bzj,HDRqsMkaTFLWl = list(zip(*d1IMUO674tXSRCyzvTimgrJfADWZ))
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الملف المناسب:', dWmNPtXIflSqr50KAFboEDuCv8Bzj)
			if zKgFfQoODy90ewYb5jGElUJRVs4p!=-1:
				GwqoS2C6TY = dWmNPtXIflSqr50KAFboEDuCv8Bzj[zKgFfQoODy90ewYb5jGElUJRVs4p]
				BSFOqGAkHwW7Drg5Y = D7Xl2e3wTJhyKnOrkUQS6N8E[zKgFfQoODy90ewYb5jGElUJRVs4p]
				if 'mpd' in dWmNPtXIflSqr50KAFboEDuCv8Bzj[zKgFfQoODy90ewYb5jGElUJRVs4p] and BSFOqGAkHwW7Drg5Y['url']!=gg1xH9u5eS0pkAwyZizMOqPdfNW:
					QQWS4dY35ZTyeaRLhEHVmbGlFIw8 = thWmnplsGKzQ3i2V[zKgFfQoODy90ewYb5jGElUJRVs4p]
					BAefDXsMmogaJpRPYH24WZN3 = True
				else: am3rnY5bE4JGj = BSFOqGAkHwW7Drg5Y['url']
				break
		elif d1cy9GkbBivnRNTChoEFu5xIXp4=='highest':
			D7Xl2e3wTJhyKnOrkUQS6N8E,thWmnplsGKzQ3i2V,dWmNPtXIflSqr50KAFboEDuCv8Bzj,HDRqsMkaTFLWl = list(zip(*vvTqD9zlcgt7NVXWFkmryu))
			BSFOqGAkHwW7Drg5Y = D7Xl2e3wTJhyKnOrkUQS6N8E[zKgFfQoODy90ewYb5jGElUJRVs4p-ooHKBXGgZDjaLivsYmONu]
			if 'mpd' in dWmNPtXIflSqr50KAFboEDuCv8Bzj[zKgFfQoODy90ewYb5jGElUJRVs4p-ooHKBXGgZDjaLivsYmONu] and BSFOqGAkHwW7Drg5Y['url']!=gg1xH9u5eS0pkAwyZizMOqPdfNW:
				QQWS4dY35ZTyeaRLhEHVmbGlFIw8 = thWmnplsGKzQ3i2V[zKgFfQoODy90ewYb5jGElUJRVs4p-ooHKBXGgZDjaLivsYmONu]
				BAefDXsMmogaJpRPYH24WZN3 = True
			else: am3rnY5bE4JGj = BSFOqGAkHwW7Drg5Y['url']
			GwqoS2C6TY = dWmNPtXIflSqr50KAFboEDuCv8Bzj[zKgFfQoODy90ewYb5jGElUJRVs4p-ooHKBXGgZDjaLivsYmONu]
			break
	if not BAefDXsMmogaJpRPYH24WZN3: rr8SNE1em6KYL7vxCydZ = am3rnY5bE4JGj
	else: rr8SNE1em6KYL7vxCydZ = 'Video: '+BSFOqGAkHwW7Drg5Y['url']+' + Audio: '+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['url']
	if BAefDXsMmogaJpRPYH24WZN3:
		H9aIV8RY1iltA7T = int(BSFOqGAkHwW7Drg5Y['duration'])
		rbUAOShNCcKgf46nHI0Pi9BLzq7F = int(QQWS4dY35ZTyeaRLhEHVmbGlFIw8['duration'])
		hhCd56yES0cqfUKRsZaVI4wzWuTO = str(max(H9aIV8RY1iltA7T,rbUAOShNCcKgf46nHI0Pi9BLzq7F))
		GmKyePDS5CsOY = BSFOqGAkHwW7Drg5Y['url'].replace('&','&amp;')
		AJNvV6HWhifXSCtmjZ4qx1Q = QQWS4dY35ZTyeaRLhEHVmbGlFIw8['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+hhCd56yES0cqfUKRsZaVI4wzWuTO+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+BSFOqGAkHwW7Drg5Y['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+BSFOqGAkHwW7Drg5Y['itag']+'" codecs="'+BSFOqGAkHwW7Drg5Y['codecs']+'" startWithSAP="1" bandwidth="'+str(BSFOqGAkHwW7Drg5Y['bitrate'])+'" width="'+str(BSFOqGAkHwW7Drg5Y['width'])+'" height="'+str(BSFOqGAkHwW7Drg5Y['height'])+'" frameRate="'+BSFOqGAkHwW7Drg5Y['fps']+'">\n'
		mpd += '<BaseURL>'+GmKyePDS5CsOY+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+BSFOqGAkHwW7Drg5Y['index']+'">\n'
		mpd += '<Initialization range="'+BSFOqGAkHwW7Drg5Y['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['filetype']+'" subsegmentAlignment="true">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['itag']+'" codecs="'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+AJNvV6HWhifXSCtmjZ4qx1Q+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['index']+'">\n'
		mpd += '<Initialization range="'+QQWS4dY35ZTyeaRLhEHVmbGlFIw8['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if DQfHadYvTpy1UR:
			import http.server as ATQPoglRsr
			import http.client as k90MeEuxgtpI34CHjNBKic
		else:
			import BaseHTTPServer as ATQPoglRsr
			import httplib as k90MeEuxgtpI34CHjNBKic
		class hrBaKL8Oe726TQgCvPWiGdM51yf(ATQPoglRsr.HTTPServer):
			def __init__(J5JHbM2XaGT7o9Zkhs4B,ip='localhost',port=55055,mpd='<>'):
				J5JHbM2XaGT7o9Zkhs4B.ip = ip
				J5JHbM2XaGT7o9Zkhs4B.port = port
				J5JHbM2XaGT7o9Zkhs4B.mpd = mpd
				ATQPoglRsr.HTTPServer.__init__(J5JHbM2XaGT7o9Zkhs4B,(J5JHbM2XaGT7o9Zkhs4B.ip,J5JHbM2XaGT7o9Zkhs4B.port),F1D0sWpcIJkHNr)
				J5JHbM2XaGT7o9Zkhs4B.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.threads = aDiNElZCYMU9ptH7oA3d5eu60IOwgj(False)
				J5JHbM2XaGT7o9Zkhs4B.threads.t5F2ieMUsZbgfAGqpzOTdaYn(1,J5JHbM2XaGT7o9Zkhs4B.IvKkeuLrRJdEzp7D0gVnUH)
			def IvKkeuLrRJdEzp7D0gVnUH(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.keeprunning = True
				while J5JHbM2XaGT7o9Zkhs4B.keeprunning:
					J5JHbM2XaGT7o9Zkhs4B.handle_request()
			def stop(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.keeprunning = False
				J5JHbM2XaGT7o9Zkhs4B.laAuvi7WEwJ6m853HBgoqDPN1Vhj()
			def a04aThWldjgN2(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.stop()
				J5JHbM2XaGT7o9Zkhs4B.r6h8FXwU1f9Knx3BtOI45mjgiG.close()
				J5JHbM2XaGT7o9Zkhs4B.server_close()
			def e9GFvAKthLW6NxOMToinZ0(J5JHbM2XaGT7o9Zkhs4B,mpd):
				J5JHbM2XaGT7o9Zkhs4B.mpd = mpd
			def laAuvi7WEwJ6m853HBgoqDPN1Vhj(J5JHbM2XaGT7o9Zkhs4B):
				LxomZnH9Ky = k90MeEuxgtpI34CHjNBKic.HTTPConnection(J5JHbM2XaGT7o9Zkhs4B.ip+':'+str(J5JHbM2XaGT7o9Zkhs4B.port))
				LxomZnH9Ky.request("HEAD", "/")
		class F1D0sWpcIJkHNr(ATQPoglRsr.BaseHTTPRequestHandler):
			def nA9KsPWJ8Dub7jHY(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.send_response(200)
				J5JHbM2XaGT7o9Zkhs4B.send_header('Content-type','textt/plain')
				J5JHbM2XaGT7o9Zkhs4B.end_headers()
				J5JHbM2XaGT7o9Zkhs4B.wfile.write(J5JHbM2XaGT7o9Zkhs4B.RgNSOU7P93n.mpd.encode('utf8'))
				Mrx2OeZV1LNjBsQ58Savi7.sleep(1)
				if J5JHbM2XaGT7o9Zkhs4B.path=='/youtube.mpd': J5JHbM2XaGT7o9Zkhs4B.RgNSOU7P93n.a04aThWldjgN2()
				if J5JHbM2XaGT7o9Zkhs4B.path=='/shutdown': J5JHbM2XaGT7o9Zkhs4B.RgNSOU7P93n.a04aThWldjgN2()
			def F9FzX6gBAaKhkvIPqnwbD3Jo5EjO(J5JHbM2XaGT7o9Zkhs4B):
				J5JHbM2XaGT7o9Zkhs4B.send_response(200)
				J5JHbM2XaGT7o9Zkhs4B.end_headers()
		PPYxBe6FLGorlk1IndW8Ka2 = hrBaKL8Oe726TQgCvPWiGdM51yf('127.0.0.1',55055,mpd)
		am3rnY5bE4JGj = PPYxBe6FLGorlk1IndW8Ka2.mpdurl
		PPYxBe6FLGorlk1IndW8Ka2.start()
	else: PPYxBe6FLGorlk1IndW8Ka2 = ''
	if not am3rnY5bE4JGj: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return '',[''],[[am3rnY5bE4JGj,OhvIzGts3b,PPYxBe6FLGorlk1IndW8Ka2]]
def W5WqDEThbBazo0ljmCUFVSfNLrn(url):
	headers = { 'User-Agent' : '' }
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'',headers,'','RESOLVERS-VIDBOB-1st')
	items = JJDtX1PZyIgN2T.findall('file:"(.*?)"(,label:"(.*?)"|)\}',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,JCop4mjTiurYB7W,r03wsLKJioDyYhQTxX,EEgFl59RndzrBL8TUoaQMw6P = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for wHiSfdBL1v9Kl3n5,g5lf2u4DxNp8imnYevK,MpTK2YaAjI4NWtiGcC3PQg in items:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('https:','http:')
		if '.m3u8' in wHiSfdBL1v9Kl3n5:
			qSxgc4NEaF7pBYvKik0n6w2jmMVsyC,r03wsLKJioDyYhQTxX = XuJcNIWr8FMGQS(wHiSfdBL1v9Kl3n5)
			EEgFl59RndzrBL8TUoaQMw6P = EEgFl59RndzrBL8TUoaQMw6P + r03wsLKJioDyYhQTxX
			if qSxgc4NEaF7pBYvKik0n6w2jmMVsyC[0]=='-1': JCop4mjTiurYB7W.append('سيرفر خاص'+'   m3u8')
			else:
				for title in qSxgc4NEaF7pBYvKik0n6w2jmMVsyC:
					JCop4mjTiurYB7W.append('سيرفر خاص'+'   '+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+MpTK2YaAjI4NWtiGcC3PQg
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			JCop4mjTiurYB7W.append(title)
	return '',JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
def LWRZQ0JTHB6zycXv9VCUI3Ep(url,YBEsLq8gVw629cMGQP1T):
	u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5,MkdugRNYvsLq25a,TTndkJXGRS,kwqYoF8han = [],[],[],[],[]
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<video preload.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5 and not eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5[0]): wHiSfdBL1v9Kl3n5 = []
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5 and not eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5[0]): wHiSfdBL1v9Kl3n5 = []
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('direct_link.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5 and not eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5[0]): wHiSfdBL1v9Kl3n5 = []
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		title = wHiSfdBL1v9Kl3n5.rsplit('.',1)[1]
		u6jVYl28ZRT7UXzwxJH3va.append(title)
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
	else:
		Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('sources: *(\[.*?\])',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not Ns3LKUFY21aQVf7e: Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('var sources = (\{.*?\})',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not Ns3LKUFY21aQVf7e: Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('var jw = (\{.*?\})',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not Ns3LKUFY21aQVf7e: Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('var player = .*?\((\{.*?\})\)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if Ns3LKUFY21aQVf7e:
			Ns3LKUFY21aQVf7e = Ns3LKUFY21aQVf7e[0]
			Razi4foNtkDbExycLP7r15nVsA9w = JJDtX1PZyIgN2T.findall('[,\{] *(\w+):',Ns3LKUFY21aQVf7e,JJDtX1PZyIgN2T.DOTALL)
			for key in list(set(Razi4foNtkDbExycLP7r15nVsA9w)): Ns3LKUFY21aQVf7e = Ns3LKUFY21aQVf7e.replace(key+':','"'+key+'":')
			Ns3LKUFY21aQVf7e = Ns3LKUFY21aQVf7e.replace('file:',"'file':").replace('type:',"'type':").replace('label:',"'label':")
			Ns3LKUFY21aQVf7e = Ns3LKUFY21aQVf7e.replace('default:',"'default':").replace('primary:',"'primary':")
			Ns3LKUFY21aQVf7e = Ns3LKUFY21aQVf7e.replace('true','True').replace('false','False').replace('none','None')
			Ns3LKUFY21aQVf7e = eval(Ns3LKUFY21aQVf7e)
			if isinstance(Ns3LKUFY21aQVf7e,dict): Ns3LKUFY21aQVf7e = [Ns3LKUFY21aQVf7e]
			for mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
				kcJ9YUDG2Z = ''
				if isinstance(mvgk7pP8Fw6heMSWd5oXn9itl,dict):
					keys = list(mvgk7pP8Fw6heMSWd5oXn9itl.keys())
					if 'type' in keys: kcJ9YUDG2Z = str(mvgk7pP8Fw6heMSWd5oXn9itl['type'])
					if 'file' in keys: wHiSfdBL1v9Kl3n5 = mvgk7pP8Fw6heMSWd5oXn9itl['file']
					elif 'hls' in keys: wHiSfdBL1v9Kl3n5 = mvgk7pP8Fw6heMSWd5oXn9itl['hls']
					if 'label' in keys: title = str(mvgk7pP8Fw6heMSWd5oXn9itl['label'])
					elif 'video_height' in keys: title = str(mvgk7pP8Fw6heMSWd5oXn9itl['video_height'])
					else: title = wHiSfdBL1v9Kl3n5.rsplit('.',1)[1]
				elif isinstance(mvgk7pP8Fw6heMSWd5oXn9itl,str):
					wHiSfdBL1v9Kl3n5 = mvgk7pP8Fw6heMSWd5oXn9itl
					title = wHiSfdBL1v9Kl3n5.rsplit('.',1)[1]
				if eeiIspx5JaGYcH0zCu(wHiSfdBL1v9Kl3n5):
					u6jVYl28ZRT7UXzwxJH3va.append(title+'  '+kcJ9YUDG2Z)
					pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
	for wHiSfdBL1v9Kl3n5,title in zip(pB8XANf71vaPJsedkWVIc5,u6jVYl28ZRT7UXzwxJH3va):
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\\/','/')
		RgNSOU7P93n = OfTKisDR0Lv(url,'url')
		ASwKFJhGY15gO4tLTd6fN0M = yyYKmdtsAFic93()
		if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = RgNSOU7P93n+wHiSfdBL1v9Kl3n5
		if '.m3u8' in wHiSfdBL1v9Kl3n5:
			headers = {'User-Agent':ASwKFJhGY15gO4tLTd6fN0M,'Referer':RgNSOU7P93n}
			qW6p7049ckj132eVOYHIoxyK5Ft,Y1Dy3w5XB7ELaiRP0ACOUh9 = XuJcNIWr8FMGQS(wHiSfdBL1v9Kl3n5,headers)
			TTndkJXGRS += Y1Dy3w5XB7ELaiRP0ACOUh9
			MkdugRNYvsLq25a += qW6p7049ckj132eVOYHIoxyK5Ft
		else:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'|User-Agent='+ASwKFJhGY15gO4tLTd6fN0M+'&Referer='+RgNSOU7P93n
			TTndkJXGRS.append(wHiSfdBL1v9Kl3n5)
			MkdugRNYvsLq25a.append(title)
	rr07NBhdGXailkP,u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5 = '',[],[]
	if TTndkJXGRS: rr07NBhdGXailkP,u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5 = '',MkdugRNYvsLq25a,TTndkJXGRS
	else:
		if '<' not in YBEsLq8gVw629cMGQP1T and len(YBEsLq8gVw629cMGQP1T)<100 and YBEsLq8gVw629cMGQP1T: rr07NBhdGXailkP = YBEsLq8gVw629cMGQP1T
		else:
			msg = JJDtX1PZyIgN2T.findall('<div style=".*?">(File.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if not msg: msg = JJDtX1PZyIgN2T.findall('<div class="vp_video_stub_txt">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if not msg: msg = JJDtX1PZyIgN2T.findall('<h2>(Sorry.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if msg: rr07NBhdGXailkP = msg[0]
	return rr07NBhdGXailkP,u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5
def Ut2zdfJWE1BToC0c3QDuLnryRPmNip(xxmlunj9R0kYdHfSUC5Bpt,url):
	global KhG836oTBiHy0m4Fk5SPJg1Eul7OW
	url = url.strip('/')
	fDUlrZqcjakT8WpPG3Ku4XBL,zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = '',{}
	headers = {'User-Agent':yyYKmdtsAFic93(),'Accept-Language':'en-US,en;q=0.9','Sec-Fetch-Dest':'iframe'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',headers,'',False,'RESOLVERS-XSHARING-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	AfbKSi12dUePk6X = SSzrgUnfVGL1hQsu40FoP7CWXax.code
	if not isinstance(YBEsLq8gVw629cMGQP1T,str): YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.decode('utf8','ignore')
	if 'function(p,a,c,k,e,' in YBEsLq8gVw629cMGQP1T:
		yyJB8WmHTEw4OIbcnxf = JJDtX1PZyIgN2T.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if yyJB8WmHTEw4OIbcnxf:
			try: fDUlrZqcjakT8WpPG3Ku4XBL = lB1vAJfs6kthziXFgTuNr(yyJB8WmHTEw4OIbcnxf[0])
			except: fDUlrZqcjakT8WpPG3Ku4XBL = ''
	Plj7MGOHohwdvam2ynfVY1z = YBEsLq8gVw629cMGQP1T+fDUlrZqcjakT8WpPG3Ku4XBL
	if '"id2"' in Plj7MGOHohwdvam2ynfVY1z or '"id"' in Plj7MGOHohwdvam2ynfVY1z:
		GOwFvaNX87xqdkmyfcJrsL3Mz = url.split('/')[3].replace('embed-','').replace('.html','')
		if '"id2"' in Plj7MGOHohwdvam2ynfVY1z: zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {'id2':GOwFvaNX87xqdkmyfcJrsL3Mz,'op':'download2'}
		elif '"id"' in Plj7MGOHohwdvam2ynfVY1z: zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {'id':GOwFvaNX87xqdkmyfcJrsL3Mz,'op':'download2'}
		JZP07kjvbV = headers.copy()
		JZP07kjvbV['Content-Type'] = 'application/x-www-form-urlencoded'
		pmTdyfMuY6I3UQczZ = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,JZP07kjvbV,'',False,'RESOLVERS-XSHARING-2nd')
		Plj7MGOHohwdvam2ynfVY1z = pmTdyfMuY6I3UQczZ.content
	tOwnapPCKsdqlX76h93oW0AIL,Hlfhap8VEkOWcz1TjgYZ,T8ZQKwhCb1S = LWRZQ0JTHB6zycXv9VCUI3Ep(url,Plj7MGOHohwdvam2ynfVY1z)
	KhG836oTBiHy0m4Fk5SPJg1Eul7OW[xxmlunj9R0kYdHfSUC5Bpt] = tOwnapPCKsdqlX76h93oW0AIL,Hlfhap8VEkOWcz1TjgYZ,T8ZQKwhCb1S,AfbKSi12dUePk6X
	return
KhG836oTBiHy0m4Fk5SPJg1Eul7OW,W1Wr3Oa92NTlFpdyJnhbEIBm0wufzD = {},0
def Cvjr90TfOhcu4B(url):
	global KhG836oTBiHy0m4Fk5SPJg1Eul7OW,W1Wr3Oa92NTlFpdyJnhbEIBm0wufzD
	kwqYoF8han,threads = [],[]
	W1Wr3Oa92NTlFpdyJnhbEIBm0wufzD += 100
	s4l9Suapz6OFxIGby0185YqfUDgvAt = W1Wr3Oa92NTlFpdyJnhbEIBm0wufzD
	kwqYoF8han.append([1,url])
	KhG836oTBiHy0m4Fk5SPJg1Eul7OW[s4l9Suapz6OFxIGby0185YqfUDgvAt+1] = [None,None,None,None]
	WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=Ut2zdfJWE1BToC0c3QDuLnryRPmNip,args=(s4l9Suapz6OFxIGby0185YqfUDgvAt+1,url))
	WpSDRloxYqHzyLtsfT8QA.start()
	WpSDRloxYqHzyLtsfT8QA.join(10)
	if not KhG836oTBiHy0m4Fk5SPJg1Eul7OW[s4l9Suapz6OFxIGby0185YqfUDgvAt+1][2]:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('/embed-','/')
		xxyPKEIGHM75VZcR3S2z0Q = JJDtX1PZyIgN2T.findall('^(.*?://.*?)/(.*?)/(.*?)$',FrC9LhHZWIySdGwNsuzqt5Rf01TXO+'/',JJDtX1PZyIgN2T.DOTALL)
		start,jigkZpVW6bCqQnM2AFDS,end = xxyPKEIGHM75VZcR3S2z0Q[0]
		end = end.strip('/')
		HOvoBzERNu = len(jigkZpVW6bCqQnM2AFDS)<4 or jigkZpVW6bCqQnM2AFDS in ['file','video','videoembed']
		if not HOvoBzERNu: kwqYoF8han.append([2,start+'/embed-'+jigkZpVW6bCqQnM2AFDS+'/'+end])
		if end: kwqYoF8han.append([3,start+'/'+jigkZpVW6bCqQnM2AFDS+'/embed-'+end])
		if '.html' in jigkZpVW6bCqQnM2AFDS:
			AhIWVH5Pe7S = jigkZpVW6bCqQnM2AFDS.replace('.html','')
			kwqYoF8han.append([4,start+'/'+AhIWVH5Pe7S+'/'+end])
			kwqYoF8han.append([5,start+'/embed-'+AhIWVH5Pe7S+'/'+end])
			if end: kwqYoF8han.append([6,start+'/'+AhIWVH5Pe7S+'/embed-'+end])
		elif '.html' in end:
			DDmla0Tz5sjo6rqA8 = end.replace('.html','')
			kwqYoF8han.append([7,start+'/'+jigkZpVW6bCqQnM2AFDS+'/'+DDmla0Tz5sjo6rqA8])
			if not HOvoBzERNu: kwqYoF8han.append([8,start+'/embed-'+jigkZpVW6bCqQnM2AFDS+'/'+DDmla0Tz5sjo6rqA8])
			kwqYoF8han.append([9,start+'/'+jigkZpVW6bCqQnM2AFDS+'/embed-'+DDmla0Tz5sjo6rqA8])
		else:
			if not HOvoBzERNu: kwqYoF8han.append([10,start+'/'+jigkZpVW6bCqQnM2AFDS+'.html'])
			if not HOvoBzERNu: kwqYoF8han.append([11,start+'/embed-'+jigkZpVW6bCqQnM2AFDS+'.html'])
			if end: kwqYoF8han.append([12,start+'/'+jigkZpVW6bCqQnM2AFDS+'/'+end+'.html'])
			if end: kwqYoF8han.append([13,start+'/'+jigkZpVW6bCqQnM2AFDS+'/embed-'+end+'.html'])
		if HOvoBzERNu and end:
			end = end.replace('/embed-','/')
			kwqYoF8han.append([14,start+'/'+end])
			kwqYoF8han.append([15,start+'/embed-'+end])
			if '.html' in end:
				DDmla0Tz5sjo6rqA8 = end.replace('.html','')
				kwqYoF8han.append([16,start+'/'+DDmla0Tz5sjo6rqA8])
				kwqYoF8han.append([17,start+'/embed-'+DDmla0Tz5sjo6rqA8])
			else:
				kwqYoF8han.append([18,start+'/'+end+'.html'])
				kwqYoF8han.append([19,start+'/embed-'+end+'.html'])
		for rjcLNMPIGsBSni4odgDpx8zqQ2h,wHiSfdBL1v9Kl3n5 in kwqYoF8han[1:]:
			KhG836oTBiHy0m4Fk5SPJg1Eul7OW[s4l9Suapz6OFxIGby0185YqfUDgvAt+rjcLNMPIGsBSni4odgDpx8zqQ2h] = [None,None,None,None]
			WpSDRloxYqHzyLtsfT8QA = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=Ut2zdfJWE1BToC0c3QDuLnryRPmNip,args=(s4l9Suapz6OFxIGby0185YqfUDgvAt+rjcLNMPIGsBSni4odgDpx8zqQ2h,wHiSfdBL1v9Kl3n5))
			WpSDRloxYqHzyLtsfT8QA.start()
			Mrx2OeZV1LNjBsQ58Savi7.sleep(0.5)
			threads.append(WpSDRloxYqHzyLtsfT8QA)
		for WpSDRloxYqHzyLtsfT8QA in threads: WpSDRloxYqHzyLtsfT8QA.join(10)
	rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = '',[],[]
	SoH9r3UhOYITLGKdMlai = []
	for rjcLNMPIGsBSni4odgDpx8zqQ2h,wHiSfdBL1v9Kl3n5 in kwqYoF8han:
		a4mGL5SCNcq0MsbYBH19TQA3rhf7vi,ggrVlBEjJA,QCWMPiNvmAnusoGKT2w0,jodixEKw9VUFuyXGJCbsr = KhG836oTBiHy0m4Fk5SPJg1Eul7OW[s4l9Suapz6OFxIGby0185YqfUDgvAt+rjcLNMPIGsBSni4odgDpx8zqQ2h]
		if not EEgFl59RndzrBL8TUoaQMw6P and QCWMPiNvmAnusoGKT2w0: JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = ggrVlBEjJA,QCWMPiNvmAnusoGKT2w0
		if not rr07NBhdGXailkP and a4mGL5SCNcq0MsbYBH19TQA3rhf7vi: rr07NBhdGXailkP = a4mGL5SCNcq0MsbYBH19TQA3rhf7vi
		if jodixEKw9VUFuyXGJCbsr: SoH9r3UhOYITLGKdMlai.append(jodixEKw9VUFuyXGJCbsr)
	SoH9r3UhOYITLGKdMlai = list(set(SoH9r3UhOYITLGKdMlai))
	if not rr07NBhdGXailkP and len(SoH9r3UhOYITLGKdMlai)==1:
		AfbKSi12dUePk6X = SoH9r3UhOYITLGKdMlai[0]
		if AfbKSi12dUePk6X!=200:
			if AfbKSi12dUePk6X<0: rr07NBhdGXailkP = 'Video page/server is not accessible'
			else:
				rr07NBhdGXailkP = 'HTTP Error: '+str(AfbKSi12dUePk6X)
				if DQfHadYvTpy1UR: import http.client as k90MeEuxgtpI34CHjNBKic
				else: import httplib as k90MeEuxgtpI34CHjNBKic
				rr07NBhdGXailkP += ' ( '+k90MeEuxgtpI34CHjNBKic.responses[AfbKSi12dUePk6X]+' )'
	Mrx2OeZV1LNjBsQ58Savi7.sleep(1)
	return rr07NBhdGXailkP,JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P
class f2a6IrkodP(U6zsmRNGTL.WindowDialog):
	def __init__(J5JHbM2XaGT7o9Zkhs4B, *args, **YqJpE3y8oAcLHOlj):
		cc4VovZ5anE8dimlygS = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV, 'resources', 'recaptcha2', 'dialogbg.png')
		tiOsjpcmlZwvHrb36zy1kR2 = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV, 'resources', 'recaptcha2', 'selected.png')
		DGUABO2spPTb7gew1z = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV, 'resources', 'recaptcha2', 'buttonfo.png')
		G6hvp95OFcDznixfJjsyVZkU = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV, 'resources', 'recaptcha2', 'buttonnf.png')
		xSr8PgbnRWZ1EQeX50ULMHd4IFKpD = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV, 'resources', 'recaptcha2', 'buttonbg.png')
		J5JHbM2XaGT7o9Zkhs4B.cancelled = False
		J5JHbM2XaGT7o9Zkhs4B.chk = [0] * 9
		J5JHbM2XaGT7o9Zkhs4B.chkbutton = [0] * 9
		J5JHbM2XaGT7o9Zkhs4B.chkstate = [False] * 9
		JR0PvjHXLU1eaTtYSxMDmn, iUSaZJKVLeF7j41klN3RB8Y5XC, WanlhLzBHrtgXRDI, L3CK45GQWRFtkl7qzeiHc8Mpf2V = 250, 0, 700, 760
		dLTW5n4VyjRX = JR0PvjHXLU1eaTtYSxMDmn+WanlhLzBHrtgXRDI//2
		F4fNxCjD9JvXzWRngoU, JRhoYFLG6It4kg, IIdnQDYcm3bgFsXxhV6S7ECAqHUo5, JLdMrwX2i63pb = 355, 120, 500, 500
		HbAWm0NzQsvF7dDgcBq8Ky5xCf = F4fNxCjD9JvXzWRngoU+IIdnQDYcm3bgFsXxhV6S7ECAqHUo5//2
		Yx0Fuqdo3HNpevE2DL4bml, mVzyJG3nAk, ecIsuRBba9US6731VG8JFkm4, SwXUpV1hnj = 100, 655, 150, 50
		P1rQqnRSgpHZbFzE53K8uIh4Dxea = dLTW5n4VyjRX-ecIsuRBba9US6731VG8JFkm4-Yx0Fuqdo3HNpevE2DL4bml//2
		RAi54YO1Jo3Znd = dLTW5n4VyjRX+Yx0Fuqdo3HNpevE2DL4bml//2
		KLwM8Qq35RuoPj1JFv, N2Emfcdg5w41ot9h38IRBADUkQXx, BxpaELNy2lCdR1DWsQqT5, rwTBy07VxuSn16A8ePkO2zD = 355, 30, 500, 50
		jboaDtUlGKHdMT5ReE9, QQDdglf7HPWRztbZBXOun, T6sxUdN7ECO, tLqpjUlsA7vWfeTxIuwhaKzP8m = 355, 70, 500, 50
		oH0PCtyEVg9KUN = 0.9
		JR0PvjHXLU1eaTtYSxMDmn, iUSaZJKVLeF7j41klN3RB8Y5XC, WanlhLzBHrtgXRDI, L3CK45GQWRFtkl7qzeiHc8Mpf2V = int(JR0PvjHXLU1eaTtYSxMDmn*oH0PCtyEVg9KUN), int(iUSaZJKVLeF7j41klN3RB8Y5XC*oH0PCtyEVg9KUN), int(WanlhLzBHrtgXRDI*oH0PCtyEVg9KUN), int(L3CK45GQWRFtkl7qzeiHc8Mpf2V*oH0PCtyEVg9KUN)
		F4fNxCjD9JvXzWRngoU, JRhoYFLG6It4kg, IIdnQDYcm3bgFsXxhV6S7ECAqHUo5, JLdMrwX2i63pb = int(F4fNxCjD9JvXzWRngoU*oH0PCtyEVg9KUN), int(JRhoYFLG6It4kg*oH0PCtyEVg9KUN), int(IIdnQDYcm3bgFsXxhV6S7ECAqHUo5*oH0PCtyEVg9KUN), int(JLdMrwX2i63pb*oH0PCtyEVg9KUN)
		P1rQqnRSgpHZbFzE53K8uIh4Dxea, W1dDPXSEbuj2xQak, ccNVikxETULtXh7Cg, tshDr0CvJY2ROxZGSbT7EQagWXKH = int(P1rQqnRSgpHZbFzE53K8uIh4Dxea*oH0PCtyEVg9KUN), int(mVzyJG3nAk*oH0PCtyEVg9KUN), int(ecIsuRBba9US6731VG8JFkm4*oH0PCtyEVg9KUN), int(SwXUpV1hnj*oH0PCtyEVg9KUN)
		RAi54YO1Jo3Znd, Xqmfbhk4lgs9Z, v4vRaVxwLBkqHd, YpAtmujUzeR0ETxLFZaNS7W14GoXhH = int(RAi54YO1Jo3Znd*oH0PCtyEVg9KUN), int(mVzyJG3nAk*oH0PCtyEVg9KUN), int(ecIsuRBba9US6731VG8JFkm4*oH0PCtyEVg9KUN), int(SwXUpV1hnj*oH0PCtyEVg9KUN)
		KLwM8Qq35RuoPj1JFv, N2Emfcdg5w41ot9h38IRBADUkQXx, BxpaELNy2lCdR1DWsQqT5, rwTBy07VxuSn16A8ePkO2zD = int(KLwM8Qq35RuoPj1JFv*oH0PCtyEVg9KUN), int(N2Emfcdg5w41ot9h38IRBADUkQXx*oH0PCtyEVg9KUN), int(BxpaELNy2lCdR1DWsQqT5*oH0PCtyEVg9KUN), int(rwTBy07VxuSn16A8ePkO2zD*oH0PCtyEVg9KUN)
		jboaDtUlGKHdMT5ReE9, QQDdglf7HPWRztbZBXOun, T6sxUdN7ECO, tLqpjUlsA7vWfeTxIuwhaKzP8m = int(jboaDtUlGKHdMT5ReE9*oH0PCtyEVg9KUN), int(QQDdglf7HPWRztbZBXOun*oH0PCtyEVg9KUN), int(T6sxUdN7ECO*oH0PCtyEVg9KUN), int(tLqpjUlsA7vWfeTxIuwhaKzP8m*oH0PCtyEVg9KUN)
		TCvDXErSzG = U6zsmRNGTL.ControlImage(JR0PvjHXLU1eaTtYSxMDmn, iUSaZJKVLeF7j41klN3RB8Y5XC, WanlhLzBHrtgXRDI, L3CK45GQWRFtkl7qzeiHc8Mpf2V, cc4VovZ5anE8dimlygS)
		J5JHbM2XaGT7o9Zkhs4B.addControl(TCvDXErSzG)
		J5JHbM2XaGT7o9Zkhs4B.iteration = YqJpE3y8oAcLHOlj.get('iteration')
		ffbjghuCGU = '[COLOR FFFFFF00]'+'فحص أنا إنسان ولست روبوت         '+'المحاولة رقم  '+str(J5JHbM2XaGT7o9Zkhs4B.iteration)+'[/COLOR]'
		J5JHbM2XaGT7o9Zkhs4B.strActionInfo = U6zsmRNGTL.ControlLabel(KLwM8Qq35RuoPj1JFv, N2Emfcdg5w41ot9h38IRBADUkQXx, BxpaELNy2lCdR1DWsQqT5, rwTBy07VxuSn16A8ePkO2zD, ffbjghuCGU, 'font13')
		J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.strActionInfo)
		ggdRiBo3smurLUGO = U6zsmRNGTL.ControlImage(F4fNxCjD9JvXzWRngoU, JRhoYFLG6It4kg, IIdnQDYcm3bgFsXxhV6S7ECAqHUo5, JLdMrwX2i63pb, YqJpE3y8oAcLHOlj.get('captcha'))
		J5JHbM2XaGT7o9Zkhs4B.addControl(ggdRiBo3smurLUGO)
		ihkpSQloBjL6W7M = '[COLOR FFFFFF00]'+YqJpE3y8oAcLHOlj.get('msg')+'[/COLOR]'
		J5JHbM2XaGT7o9Zkhs4B.strActionInfo = U6zsmRNGTL.ControlLabel(jboaDtUlGKHdMT5ReE9, QQDdglf7HPWRztbZBXOun, T6sxUdN7ECO, tLqpjUlsA7vWfeTxIuwhaKzP8m, ihkpSQloBjL6W7M, 'font13')
		J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.strActionInfo)
		text = '[COLOR FFFFFF00]'+'خروج'+'[/COLOR]'
		J5JHbM2XaGT7o9Zkhs4B.cancelbutton = U6zsmRNGTL.ControlButton(P1rQqnRSgpHZbFzE53K8uIh4Dxea, W1dDPXSEbuj2xQak, ccNVikxETULtXh7Cg, tshDr0CvJY2ROxZGSbT7EQagWXKH, text, focusTexture=xSr8PgbnRWZ1EQeX50ULMHd4IFKpD, noFocusTexture=DGUABO2spPTb7gew1z, alignment=2)
		text = '[COLOR FFFFFF00]'+'استمرار'+'[/COLOR]'
		J5JHbM2XaGT7o9Zkhs4B.okbutton = U6zsmRNGTL.ControlButton(RAi54YO1Jo3Znd, Xqmfbhk4lgs9Z, v4vRaVxwLBkqHd, YpAtmujUzeR0ETxLFZaNS7W14GoXhH, text, focusTexture=xSr8PgbnRWZ1EQeX50ULMHd4IFKpD, noFocusTexture=DGUABO2spPTb7gew1z, alignment=2)
		J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.okbutton)
		J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.cancelbutton)
		AZ5lnhRe0Esq7WvkOP8oHDu, GpBzmN8cSV = JLdMrwX2i63pb//3, IIdnQDYcm3bgFsXxhV6S7ECAqHUo5//3
		for ggjo5zu7yCiIOhrb in range(9):
			hb6JDwqG8KWjOYvR = ggjo5zu7yCiIOhrb // 3
			xmuf7J8eraq5Tzb4h0vcVLyWRgNQMt = ggjo5zu7yCiIOhrb % 3
			zUdC8ZBQNgOljLtsFv0q7 = F4fNxCjD9JvXzWRngoU + (GpBzmN8cSV * xmuf7J8eraq5Tzb4h0vcVLyWRgNQMt)
			oMFGRpxlhtNqj78CyDLngXcO = JRhoYFLG6It4kg + (AZ5lnhRe0Esq7WvkOP8oHDu * hb6JDwqG8KWjOYvR)
			J5JHbM2XaGT7o9Zkhs4B.chk[ggjo5zu7yCiIOhrb] = U6zsmRNGTL.ControlImage(zUdC8ZBQNgOljLtsFv0q7, oMFGRpxlhtNqj78CyDLngXcO, GpBzmN8cSV, AZ5lnhRe0Esq7WvkOP8oHDu, tiOsjpcmlZwvHrb36zy1kR2)
			J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.chk[ggjo5zu7yCiIOhrb])
			J5JHbM2XaGT7o9Zkhs4B.chk[ggjo5zu7yCiIOhrb].setVisible(False)
			J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb] = U6zsmRNGTL.ControlButton(zUdC8ZBQNgOljLtsFv0q7, oMFGRpxlhtNqj78CyDLngXcO, GpBzmN8cSV, AZ5lnhRe0Esq7WvkOP8oHDu, str(ggjo5zu7yCiIOhrb + 1), font='font13', focusTexture=DGUABO2spPTb7gew1z, noFocusTexture=G6hvp95OFcDznixfJjsyVZkU)
			J5JHbM2XaGT7o9Zkhs4B.addControl(J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb])
		for ggjo5zu7yCiIOhrb in range(9):
			XXgcwdY17vB0hICoGJ = (ggjo5zu7yCiIOhrb // 3) * 3
			wFjTcx3I0XPpbHeA9 = XXgcwdY17vB0hICoGJ + (ggjo5zu7yCiIOhrb + 1) % 3
			g27YRCScdOwuJ1PFrs = XXgcwdY17vB0hICoGJ + (ggjo5zu7yCiIOhrb - 1) % 3
			n1QxfhavBlHzOG4Ai8gpqXJkysPV = (ggjo5zu7yCiIOhrb - 3) % 9
			RRohNmivDzpwrfULg153dk = (ggjo5zu7yCiIOhrb + 3) % 9
			J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlRight(J5JHbM2XaGT7o9Zkhs4B.chkbutton[wFjTcx3I0XPpbHeA9])
			J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlLeft(J5JHbM2XaGT7o9Zkhs4B.chkbutton[g27YRCScdOwuJ1PFrs])
			if ggjo5zu7yCiIOhrb <= 2:
				J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlUp(J5JHbM2XaGT7o9Zkhs4B.okbutton)
			else:
				J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlUp(J5JHbM2XaGT7o9Zkhs4B.chkbutton[n1QxfhavBlHzOG4Ai8gpqXJkysPV])
			if ggjo5zu7yCiIOhrb >= 6:
				J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlDown(J5JHbM2XaGT7o9Zkhs4B.okbutton)
			else:
				J5JHbM2XaGT7o9Zkhs4B.chkbutton[ggjo5zu7yCiIOhrb].controlDown(J5JHbM2XaGT7o9Zkhs4B.chkbutton[RRohNmivDzpwrfULg153dk])
		J5JHbM2XaGT7o9Zkhs4B.okbutton.controlLeft(J5JHbM2XaGT7o9Zkhs4B.cancelbutton)
		J5JHbM2XaGT7o9Zkhs4B.okbutton.controlRight(J5JHbM2XaGT7o9Zkhs4B.cancelbutton)
		J5JHbM2XaGT7o9Zkhs4B.cancelbutton.controlLeft(J5JHbM2XaGT7o9Zkhs4B.okbutton)
		J5JHbM2XaGT7o9Zkhs4B.cancelbutton.controlRight(J5JHbM2XaGT7o9Zkhs4B.okbutton)
		J5JHbM2XaGT7o9Zkhs4B.okbutton.controlDown(J5JHbM2XaGT7o9Zkhs4B.chkbutton[2])
		J5JHbM2XaGT7o9Zkhs4B.okbutton.controlUp(J5JHbM2XaGT7o9Zkhs4B.chkbutton[8])
		J5JHbM2XaGT7o9Zkhs4B.cancelbutton.controlDown(J5JHbM2XaGT7o9Zkhs4B.chkbutton[0])
		J5JHbM2XaGT7o9Zkhs4B.cancelbutton.controlUp(J5JHbM2XaGT7o9Zkhs4B.chkbutton[6])
		J5JHbM2XaGT7o9Zkhs4B.setFocus(J5JHbM2XaGT7o9Zkhs4B.okbutton)
	def get(J5JHbM2XaGT7o9Zkhs4B):
		J5JHbM2XaGT7o9Zkhs4B.doModal()
		J5JHbM2XaGT7o9Zkhs4B.close()
		if not J5JHbM2XaGT7o9Zkhs4B.cancelled:
			return [ggjo5zu7yCiIOhrb for ggjo5zu7yCiIOhrb in range(9) if J5JHbM2XaGT7o9Zkhs4B.chkstate[ggjo5zu7yCiIOhrb]]
	def onControl(J5JHbM2XaGT7o9Zkhs4B, YYpic9gkqPmCAtTIexbK):
		if YYpic9gkqPmCAtTIexbK.getId() == J5JHbM2XaGT7o9Zkhs4B.okbutton.getId() and any(J5JHbM2XaGT7o9Zkhs4B.chkstate):
			J5JHbM2XaGT7o9Zkhs4B.close()
		elif YYpic9gkqPmCAtTIexbK.getId() == J5JHbM2XaGT7o9Zkhs4B.cancelbutton.getId():
			J5JHbM2XaGT7o9Zkhs4B.cancelled = True
			J5JHbM2XaGT7o9Zkhs4B.close()
		else:
			MpTK2YaAjI4NWtiGcC3PQg = YYpic9gkqPmCAtTIexbK.getLabel()
			if MpTK2YaAjI4NWtiGcC3PQg.isnumeric():
				index = int(MpTK2YaAjI4NWtiGcC3PQg) - 1
				J5JHbM2XaGT7o9Zkhs4B.chkstate[index] = not J5JHbM2XaGT7o9Zkhs4B.chkstate[index]
				J5JHbM2XaGT7o9Zkhs4B.chk[index].setVisible(J5JHbM2XaGT7o9Zkhs4B.chkstate[index])
	def onAction(J5JHbM2XaGT7o9Zkhs4B, TTWrI5lDaPd):
		if TTWrI5lDaPd == 10:
			J5JHbM2XaGT7o9Zkhs4B.cancelled = True
			J5JHbM2XaGT7o9Zkhs4B.close()
def Fjxed2z6PTCby0YmvOJwc9Q(key,LwmcG8ouzKfY2,url):
	headers = {'Referer':url,'Accept-Language':LwmcG8ouzKfY2}
	hpkS7BG9LzQ6Z8urK1aYDJUO5o = 'http://www.google.com/recaptcha/api/fallback?k='+key
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',hpkS7BG9LzQ6Z8urK1aYDJUO5o,'',headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	BB0MgRSFCf5k6xyH4hLam,iteration = '',0
	while True:
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = JJDtX1PZyIgN2T.findall('"(/recaptcha/api2/payload[^"]+)', YBEsLq8gVw629cMGQP1T)
		iteration += 1
		message = JJDtX1PZyIgN2T.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', YBEsLq8gVw629cMGQP1T)
		if not message: message = JJDtX1PZyIgN2T.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', YBEsLq8gVw629cMGQP1T)
		if not message:
			BB0MgRSFCf5k6xyH4hLam = JJDtX1PZyIgN2T.findall('readonly>(.*?)<', YBEsLq8gVw629cMGQP1T)[0]
			break
		else:
			message = message[0]
			zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = zAkbOyR9ZirYWxTwvMqouPLBjeQ20[0]
		TTNHFEiom2tlALRkrIxd3j = JJDtX1PZyIgN2T.findall(r'name="c"\s+value="([^"]+)', YBEsLq8gVw629cMGQP1T)[0]
		jeSkE0HqsPiczvpR9y4OGt = 'https://www.google.com%s' % (zAkbOyR9ZirYWxTwvMqouPLBjeQ20.replace('&amp;', '&'))
		message = JJDtX1PZyIgN2T.sub('</?(div|strong)[^>]*>', '', message)
		PR721BN5OSvYazxe = f2a6IrkodP(captcha=jeSkE0HqsPiczvpR9y4OGt, msg=message, iteration=iteration)
		IYqdgbNesa6F1EnGc8TVlpuM = PR721BN5OSvYazxe.get()
		if not IYqdgbNesa6F1EnGc8TVlpuM: break
		data = {'c': TTNHFEiom2tlALRkrIxd3j, 'response': IYqdgbNesa6F1EnGc8TVlpuM}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'POST',hpkS7BG9LzQ6Z8urK1aYDJUO5o,data,headers,'','','RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return BB0MgRSFCf5k6xyH4hLam
def bl9v6ArgMHY35oNRPjKTphUe(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-ARABLOADS-1st')
	items = JJDtX1PZyIgN2T.findall('color="red">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def B0cJaLUDW9i7vGANZy(url):
	return '',[''],[ url ]
def USJRIzCvbu(url):
	RgNSOU7P93n = url.split('/')
	A3hzw2ua8d1JbFri = '/'.join(RgNSOU7P93n[0:3])
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-ZIPPYSHARE-1st')
	items = JJDtX1PZyIgN2T.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		cJsUR2bM3WZmAFT,RZdc3HWpJk,lIzHShWcUsPwjAVR9digvNLM3,Vue6GREzpmaQ42wY7SML8FITlf0Bc3,TTqkidEoMAZKS,fAxSvmyTXMFnlC78tsJ6IozV3jP = items[0]
		DeC6ZNvQia8kdOonwqM3cEflB = int(RZdc3HWpJk) % int(lIzHShWcUsPwjAVR9digvNLM3) + int(Vue6GREzpmaQ42wY7SML8FITlf0Bc3) % int(TTqkidEoMAZKS)
		url = A3hzw2ua8d1JbFri + cJsUR2bM3WZmAFT + str(DeC6ZNvQia8kdOonwqM3cEflB) + fAxSvmyTXMFnlC78tsJ6IozV3jP
		return '',[''],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def b0bzfcIZqdoOge4prjMXLhQYs(url):
	id = url.split('/')[-1]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { "id":id , "op":"download2" }
	WAEqF7ZldrmL9Xw = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST', url, zAkbOyR9ZirYWxTwvMqouPLBjeQ20, headers, '','','RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(WAEqF7ZldrmL9Xw.headers.keys()): wHiSfdBL1v9Kl3n5 = WAEqF7ZldrmL9Xw.headers['Location']
	else: wHiSfdBL1v9Kl3n5 = url
	if wHiSfdBL1v9Kl3n5: return '',[''],[wHiSfdBL1v9Kl3n5]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def Vn7PvKeXHM9Zxgi3p(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-WINTVLIVE-1st')
	items = JJDtX1PZyIgN2T.findall('mp4: \[\'(.*?)\'',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def yXDfYaSLNn(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-ARCHIVE-1st')
	items = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[0]
		return '',[''],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def DnPwjLABUS2rfOeGYHdligWz0(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,url,'','','','RESOLVERS-ESTREAM-1st')
	items = JJDtX1PZyIgN2T.findall('video preload.*?src=.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items: return '',[''],[ items[0] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'CIMANOW'
eMlwAzaLSj8ZEQ3txIGP = '_CMN_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['قائمتي']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==300: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==301: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==302: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==303: mL7BVKcSygkuoPbWlEF4YD = Rlz1ix3kDKZIbrjq7O(url)
	elif mode==304: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==305: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==306: mL7BVKcSygkuoPbWlEF4YD = ljOmp1dtMV()
	elif mode==309: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'لماذا الموقع بطيء','',306)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',309,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH+'/home','','','','','CIMANOW-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<header>(.*?)</header>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('<li><a href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		title = title.strip(' ')
		if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,301)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	YsCotEfMBv03z7mg(kU2ZXSViB3wLANOz8bH+'/home',YBEsLq8gVw629cMGQP1T)
	return YBEsLq8gVw629cMGQP1T
def ljOmp1dtMV():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def YsCotEfMBv03z7mg(url,YBEsLq8gVw629cMGQP1T=''):
	if not YBEsLq8gVw629cMGQP1T:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','CIMANOW-SUBMENU-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	ZxtmiwJ4zPKpU6VkCAn = 0
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(<section>.*?</section>)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		for mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			ZxtmiwJ4zPKpU6VkCAn += 1
			items = JJDtX1PZyIgN2T.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for title,L8YWD9kEOZXf56zN,wHiSfdBL1v9Kl3n5 in items:
				title = title.strip(' ')
				if title=='': title = 'بووووو'
				if 'em><a' not in L8YWD9kEOZXf56zN:
					if mvgk7pP8Fw6heMSWd5oXn9itl.count('/category/')>0:
						dZRQc2rqusIveyX8p = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
						for wHiSfdBL1v9Kl3n5 in dZRQc2rqusIveyX8p:
							title = wHiSfdBL1v9Kl3n5.split('/')[-2]
							nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,301)
						continue
					else: wHiSfdBL1v9Kl3n5 = url+'?sequence='+str(ZxtmiwJ4zPKpU6VkCAn)
				if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,302)
	else: d2JXnUMPmgsKBQqCE58lkZ(url,YBEsLq8gVw629cMGQP1T)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,YBEsLq8gVw629cMGQP1T=''):
	if YBEsLq8gVw629cMGQP1T=='':
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMANOW-TITLES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if '?sequence=' in url:
		url,ZxtmiwJ4zPKpU6VkCAn = url.split('?sequence=')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(<section>.*?</section>)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[int(ZxtmiwJ4zPKpU6VkCAn)-1]
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"posts"(.*?)</body>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for wHiSfdBL1v9Kl3n5,data,ggdRiBo3smurLUGO in items:
		title = JJDtX1PZyIgN2T.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,JJDtX1PZyIgN2T.DOTALL)
		if title: title = title[0][2].replace('\n','').strip(' ')
		if not title or title=='':
			title = JJDtX1PZyIgN2T.findall('title">.*?</em>(.*?)<',data,JJDtX1PZyIgN2T.DOTALL)
			if title: title = title[0].replace('\n','').strip(' ')
			if not title or title=='':
				title = JJDtX1PZyIgN2T.findall('title">(.*?)<',data,JJDtX1PZyIgN2T.DOTALL)
				title = title[0].replace('\n','').strip(' ')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if title not in ClXwqHm0DEMvI39agWyiRYopQ:
			ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			DqrOZE3L85G = wHiSfdBL1v9Kl3n5+data+ggdRiBo3smurLUGO
			if '/selary/' in DqrOZE3L85G or 'مسلسل' in DqrOZE3L85G or '"episode"' in DqrOZE3L85G:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,303,ggdRiBo3smurLUGO)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,305,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<li><a href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,302)
	return
def Rlz1ix3kDKZIbrjq7O(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMANOW-SEASONS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	name = JJDtX1PZyIgN2T.findall('<title>(.*?)</title>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	name = name[0].replace('| سيما ناو','').replace('Cima Now','').strip(' ').replace('  ',' ')
	name = name.split('الحلقة')[0].strip(' ')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<section(.*?)</section>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if len(items)>1:
			for wHiSfdBL1v9Kl3n5,title in items:
				title = name+' - '+title.replace('\n','').strip(' ')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,304)
		else: sjmSkpqHVtPcv(url)
	return
def sjmSkpqHVtPcv(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMANOW-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if '/selary/' not in url:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"episodes"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.replace('\n','').strip(' ')
			title = 'الحلقة '+title
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,305)
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"details"(.*?)"related"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			title = title.replace('\n','').strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,305,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'watching/'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','CIMANOW-PLAY-5th')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	EEgFl59RndzrBL8TUoaQMw6P = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"download"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.replace('\n','').strip(' ')
			y2nBfLCjDoXkKiwb8WV6 = JJDtX1PZyIgN2T.findall('\d\d\d+',title,JJDtX1PZyIgN2T.DOTALL)
			if y2nBfLCjDoXkKiwb8WV6:
				y2nBfLCjDoXkKiwb8WV6 = '____'+y2nBfLCjDoXkKiwb8WV6[0]
				title = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			else: y2nBfLCjDoXkKiwb8WV6 = ''
			tb4p6sRlFPcio = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'+y2nBfLCjDoXkKiwb8WV6
			EEgFl59RndzrBL8TUoaQMw6P.append(tb4p6sRlFPcio)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"watch"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		kwqYoF8han = JJDtX1PZyIgN2T.findall('"embed".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in kwqYoF8han:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
			title = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__embed'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		kwqYoF8han = [kU2ZXSViB3wLANOz8bH+'/wp-content/themes/Cima%20Now%20New/core.php']
		if kwqYoF8han:
			items = JJDtX1PZyIgN2T.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for ZJfCEzd2DxAvbiYg,id,title in items:
				title = title.replace('\n','').strip(' ')
				wHiSfdBL1v9Kl3n5 = kwqYoF8han[0]+'?action=switch&index='+ZJfCEzd2DxAvbiYg+'&id='+id+'?named='+title+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + '/?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
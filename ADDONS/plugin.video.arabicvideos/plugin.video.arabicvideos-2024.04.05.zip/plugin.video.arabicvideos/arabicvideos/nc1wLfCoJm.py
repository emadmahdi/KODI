# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'CIMAFANS'
headers = { 'User-Agent' : '' }
eMlwAzaLSj8ZEQ3txIGP = '_CMF_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==90: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==91: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS(url)
	elif mode==92: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==94: mL7BVKcSygkuoPbWlEF4YD = bX4pueFyDgAm3SJOx5()
	elif mode==95: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==99: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',99,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المضاف حديثا','',94)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الأحدث',kU2ZXSViB3wLANOz8bH+'/?type=latest',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الأعلى تقيماً',kU2ZXSViB3wLANOz8bH+'/?type=imdb',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الأكثر مشاهدة',kU2ZXSViB3wLANOz8bH+'/?type=view',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المثبت',kU2ZXSViB3wLANOz8bH+'/?type=pin',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'جديد الأفلام',kU2ZXSViB3wLANOz8bH+'/?type=newMovies',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'جديد الحلقات',kU2ZXSViB3wLANOz8bH+'/?type=newEpisodes',91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','CIMAFANS-MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="mainmenu(.*?)nav',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('<li><a href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	eJzpdvc3KTust = ['افلام للكبار فقط']
	for wHiSfdBL1v9Kl3n5,title in items:
		title = title.strip(' ')
		if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,91)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="f-cats"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('<li><a href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		title = title.strip(' ')
		if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,91)
	return YBEsLq8gVw629cMGQP1T
def egYaAP6oIWDjfzqX20HnKS(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : '' , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',url,data,headers,'','','CIMAFANS-ITEMS-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	else:
		headers = { 'User-Agent' : '' }
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','CIMAFANS-ITEMS-2nd')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="movies-items(.*?)class="listfoot"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	else: mvgk7pP8Fw6heMSWd5oXn9itl = ''
	items = JJDtX1PZyIgN2T.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة [0-9]+',title,JJDtX1PZyIgN2T.DOTALL)
			if vaQbluYS4GEsKCNwOymT1hFt:
				title = '_MOD_'+vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,95,ggdRiBo3smurLUGO)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif '/video/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,92,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,91,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<a href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = title.replace('الصفحة ','')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,91)
	return
def sjmSkpqHVtPcv(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','CIMAFANS-EPISODES-1st')
	ggdRiBo3smurLUGO = JJDtX1PZyIgN2T.findall('img src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	ggdRiBo3smurLUGO = ggdRiBo3smurLUGO[0]
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="episodes-panel(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		name = JJDtX1PZyIgN2T.findall('itemprop="title">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if name: name = name[1]
		else:
			name = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Label')
			if '[/COLOR]' in name: name = name.split('[/COLOR]',1)[1]
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?name">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+name+' - '+title,wHiSfdBL1v9Kl3n5,92,ggdRiBo3smurLUGO)
	else:
		QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('class="movietitle"><a href="(.*?)">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if QF4KdRaN2q0: wHiSfdBL1v9Kl3n5,title = QF4KdRaN2q0[0]
		else: wHiSfdBL1v9Kl3n5,title = url,name
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,92,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P,CsRrOeH0MF8J5zuwxa7XjPQ = [],[]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','CIMAFANS-PLAY-1st')
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('text-shadow: none;">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="links-panel(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?__download'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('nav-tabs"(.*?)video-panel-more',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('id="(.*?)".*?embed src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for id,wHiSfdBL1v9Kl3n5 in items:
			title = 'سيرفر '+id
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		items = JJDtX1PZyIgN2T.findall('data-server-src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5 in items:
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
			wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def bX4pueFyDgAm3SJOx5():
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,kU2ZXSViB3wLANOz8bH,'',headers,'','CIMAFANS-LATEST-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="index-last-movie(.*?)id="index-slider-movie',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		if '/video/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,92,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,91,ggdRiBo3smurLUGO)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + '/search.php?t='+search
	egYaAP6oIWDjfzqX20HnKS(url)
	return
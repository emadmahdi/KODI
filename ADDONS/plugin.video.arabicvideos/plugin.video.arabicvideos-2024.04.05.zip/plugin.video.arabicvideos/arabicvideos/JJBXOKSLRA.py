# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'RANDOMS'
eMlwAzaLSj8ZEQ3txIGP = '_LST_'
iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H = 4
OHVFqiQ91Mju6aWBI2Dh7yx5J = 10
def HYWukw3pL2oMzPK4(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,url,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv):
	try: W8U7yZeMX3owTiS5mDfJh = str(WFJYy6c9CKV4rdh27NjtILZ5HgRv['folder'])
	except: W8U7yZeMX3owTiS5mDfJh = ''
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==160: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==161: mL7BVKcSygkuoPbWlEF4YD = Pl6AEoprTR19Bysg(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==162: mL7BVKcSygkuoPbWlEF4YD = xuTcVhnPOv7tMHeNyrBCg(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,162)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==163: mL7BVKcSygkuoPbWlEF4YD = xuTcVhnPOv7tMHeNyrBCg(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,163)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==164: mL7BVKcSygkuoPbWlEF4YD = m3HwQSTfcM6Fb5BoW9yrsO1aPCt(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==165: mL7BVKcSygkuoPbWlEF4YD = bOyPjXeWqmQ4rkxNc(url,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==166: mL7BVKcSygkuoPbWlEF4YD = dGAMw59WofqE6cDvrlZ1e0tkIF7(url,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==167: mL7BVKcSygkuoPbWlEF4YD = oo2LbFsVygxIM(url,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==168: mL7BVKcSygkuoPbWlEF4YD = Vu2f3MhAJkoUSlzPyFjpn(url,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==761: mL7BVKcSygkuoPbWlEF4YD = BBwzZxJ90ltIkTqOKY6()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==762: mL7BVKcSygkuoPbWlEF4YD = BjkHXt4Col()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==763: mL7BVKcSygkuoPbWlEF4YD = hpYbzHc1QB8R2jk5egKCAG4x9(W8U7yZeMX3owTiS5mDfJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,vYpMA3CxgcyR4VZJh)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==764: mL7BVKcSygkuoPbWlEF4YD = O97XtZV0G4TFf3NwdjMQrCn(W8U7yZeMX3owTiS5mDfJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==765: mL7BVKcSygkuoPbWlEF4YD = r81R2j3icmaXlTt(W8U7yZeMX3owTiS5mDfJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قنوات تلفزيون عشوائية','',161,'','','_LIVETV__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قسم عشوائي','',162,'','','_SITES__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات عشوائية','',163,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات بحث عشوائي','',164,'','','_SITES__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات عشوائية من قسم','',763,'','','_SITES__RANDOM_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قنوات M3U عشوائية','',163,'','','_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات M3U عشوائية','',163,'','','_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قسم قنوات M3U عشوائي','',162,'','','_M3U__LIVE__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قسم فيديو M3U عشوائي','',162,'','','_M3U__VOD__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات M3U بحث عشوائي','',164,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات M3U عشوائية من قسم','',765,'','','_M3U__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قنوات IPTV عشوائية','',163,'','','_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات IPTV عشوائية','',163,'','','_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قسم قنوات IPTV عشوائي','',162,'','','_IPTV__LIVE__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','قسم فيديو IPTV عشوائي','',162,'','','_IPTV__VOD__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات IPTV بحث عشوائي','',164,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','فيديوهات IPTV عشوائية من قسم','',764,'','','_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def BBwzZxJ90ltIkTqOKY6():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_IPT_'+'فيديوهات جميع IPTV','',764)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
		eMlwAzaLSj8ZEQ3txIGP = '_IP'+str(W8U7yZeMX3owTiS5mDfJh)+'_'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' فيديوهات مجلد '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[W8U7yZeMX3owTiS5mDfJh],'',764,'','','','',{'folder':W8U7yZeMX3owTiS5mDfJh})
	return
def BjkHXt4Col():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_M3U_'+'فيديوهات جميع M3U','',765)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
		eMlwAzaLSj8ZEQ3txIGP = '_MU'+str(W8U7yZeMX3owTiS5mDfJh)+'_'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' فيديوهات مجلد '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[W8U7yZeMX3owTiS5mDfJh],'',765,'','','','',{'folder':W8U7yZeMX3owTiS5mDfJh})
	return
def m0TBYfHuj7yEa54w8hO(HLAhjNIVMFonqi5zg2aQlpyfRKBrm):
	global Pxpm4KQvuc6H9bsWhykYdZU,DK1oR97FbSu
	UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b = DDE8bFYNye7xkqHoVvzXOSg1l0d6(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
	try:
		if 'IFILM' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm: UIXxutP306wVQaejNrmAgJ5Dsk4zLy(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
		else: UIXxutP306wVQaejNrmAgJ5Dsk4zLy()
		QQZmLxMPyDs5fG = False
	except:
		aXQw4TyRhrp()
		QQZmLxMPyDs5fG = True
	HLAhjNIVMFonqi5zg2aQlpyfRKBrm = kFhAce5Pz1(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
	if QQZmLxMPyDs5fG:
		sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(HLAhjNIVMFonqi5zg2aQlpyfRKBrm,'فشل للأسف',Mrx2OeZV1LNjBsQ58Savi7=2000)
		Pxpm4KQvuc6H9bsWhykYdZU += 1
		DK1oR97FbSu += ' '+HLAhjNIVMFonqi5zg2aQlpyfRKBrm
	else: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(HLAhjNIVMFonqi5zg2aQlpyfRKBrm,'',Mrx2OeZV1LNjBsQ58Savi7=1000)
	return
def FM0S4p7zQhnHOo(nn1YvpNLb2j6E=True):
	global Pxpm4KQvuc6H9bsWhykYdZU,DK1oR97FbSu
	if not nn1YvpNLb2j6E:
		global yvRq7ZeaIJx6d
		mL7BVKcSygkuoPbWlEF4YD = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if mL7BVKcSygkuoPbWlEF4YD:
			yvRq7ZeaIJx6d = mL7BVKcSygkuoPbWlEF4YD
			return
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt('center','','','رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=1: return
	DTeLX73NFMctyKU9i(False,False,False)
	Vr7MGbZICfyFx1kHSBv6P5m8DThwJo = PL2fM9WhpjEFb7
	Pxpm4KQvuc6H9bsWhykYdZU,DK1oR97FbSu,threads = 0,'',{}
	for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in dyNaHP9czZ4Vir5uqp8Eho:
		Mrx2OeZV1LNjBsQ58Savi7.sleep(0.5)
		threads[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=m0TBYfHuj7yEa54w8hO,args=(HLAhjNIVMFonqi5zg2aQlpyfRKBrm,))
		threads[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].start()
		if Pxpm4KQvuc6H9bsWhykYdZU>=OHVFqiQ91Mju6aWBI2Dh7yx5J: break
	else:
		for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in list(threads.keys()):
			threads[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].join()
	PL2fM9WhpjEFb7[:] = Vr7MGbZICfyFx1kHSBv6P5m8DThwJo
	if Pxpm4KQvuc6H9bsWhykYdZU>=OHVFqiQ91Mju6aWBI2Dh7yx5J: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','لديك مشكلة في '+str(Pxpm4KQvuc6H9bsWhykYdZU)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+DK1oR97FbSu)
	else:
		pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS_SITES','SECTIONS_SITES_ALL',yvRq7ZeaIJx6d,iJnLmxA0ykozR98WXFQ4Ye3w)
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	DTeLX73NFMctyKU9i('','','')
	return
def AHSW4yzE3xrVfdocFOP2UlhCJbwj7m(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0):
	u5yYiXzKRhjqoG8t = False
	dQ2zOuAWqSKi47YlnFpPxbeGv = PL2fM9WhpjEFb7
	PL2fM9WhpjEFb7[:] = []
	if u5yYiXzKRhjqoG8t and '_CREATENEW_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
		mL7BVKcSygkuoPbWlEF4YD = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+W8U7yZeMX3owTiS5mDfJh)
	elif '_LIVE_' not in ihbjPQKgtdYUvNnLV5XErp3f0 or '_VOD_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
		import Nipbs3ZV5T
		Ay3eLGaTncD67lx8ZOud = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			try: Nipbs3ZV5T.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_UNKNOWN_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـIPTV للفيديوهات',Ay3eLGaTncD67lx8ZOud)
			try: Nipbs3ZV5T.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_MOVIES_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـIPTV للفيديوهات',Ay3eLGaTncD67lx8ZOud)
			try: Nipbs3ZV5T.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_SERIES_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـIPTV للفيديوهات',Ay3eLGaTncD67lx8ZOud)
		if '_VOD_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			try: Nipbs3ZV5T.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'LIVE_UNKNOWN_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـIPTV للقنوات',Ay3eLGaTncD67lx8ZOud)
			try: Nipbs3ZV5T.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'LIVE_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـIPTV للقنوات',Ay3eLGaTncD67lx8ZOud)
		mL7BVKcSygkuoPbWlEF4YD = PL2fM9WhpjEFb7
		if u5yYiXzKRhjqoG8t: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS_IPTV','SECTIONS_IPTV_'+W8U7yZeMX3owTiS5mDfJh,mL7BVKcSygkuoPbWlEF4YD,iJnLmxA0ykozR98WXFQ4Ye3w)
	PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv
	return mL7BVKcSygkuoPbWlEF4YD
def ZZxOnKv5T1McaVyedo(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0):
	u5yYiXzKRhjqoG8t = False
	dQ2zOuAWqSKi47YlnFpPxbeGv = PL2fM9WhpjEFb7
	PL2fM9WhpjEFb7[:] = []
	if u5yYiXzKRhjqoG8t and '_CREATENEW_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
		mL7BVKcSygkuoPbWlEF4YD = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS_M3U','SECTIONS_M3U_'+W8U7yZeMX3owTiS5mDfJh)
	elif '_LIVE_' not in ihbjPQKgtdYUvNnLV5XErp3f0 or '_VOD_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
		import aCyfkwjhpQ
		Ay3eLGaTncD67lx8ZOud = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			try: aCyfkwjhpQ.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_UNKNOWN_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـM3U للفيديوهات',Ay3eLGaTncD67lx8ZOud)
			try: aCyfkwjhpQ.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_MOVIES_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـM3U للفيديوهات',Ay3eLGaTncD67lx8ZOud)
			try: aCyfkwjhpQ.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'VOD_SERIES_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـM3U للفيديوهات',Ay3eLGaTncD67lx8ZOud)
		if '_VOD_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			try: aCyfkwjhpQ.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'LIVE_UNKNOWN_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـM3U للقنوات',Ay3eLGaTncD67lx8ZOud)
			try: aCyfkwjhpQ.OUjyxPoiSLT6(W8U7yZeMX3owTiS5mDfJh,'LIVE_GROUPED_SORTED','','',ihbjPQKgtdYUvNnLV5XErp3f0+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','موقع ـM3U للقنوات',Ay3eLGaTncD67lx8ZOud)
		mL7BVKcSygkuoPbWlEF4YD = PL2fM9WhpjEFb7
		if u5yYiXzKRhjqoG8t: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_'+W8U7yZeMX3owTiS5mDfJh,mL7BVKcSygkuoPbWlEF4YD,iJnLmxA0ykozR98WXFQ4Ye3w)
	PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv
	return mL7BVKcSygkuoPbWlEF4YD
def hpYbzHc1QB8R2jk5egKCAG4x9(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0,jjlMIxo2wyDaKuQtNUpB18Y4):
	if '_CREATENEW_' in ihbjPQKgtdYUvNnLV5XErp3f0 and jjlMIxo2wyDaKuQtNUpB18Y4=='': FM0S4p7zQhnHOo(True)
	elif jjlMIxo2wyDaKuQtNUpB18Y4: FM0S4p7zQhnHOo(False)
	w6fNJ0bEMG7kVI5qdZnePHsyv = ihbjPQKgtdYUvNnLV5XErp3f0.replace('_CREATENEW_','').replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	if not jjlMIxo2wyDaKuQtNUpB18Y4:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','تحديث هذه القائمة','',763,'','','_CREATENEW_'+w6fNJ0bEMG7kVI5qdZnePHsyv,'',{'folder':W8U7yZeMX3owTiS5mDfJh})
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	dZRQc2rqusIveyX8p = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	IADzKfyPehTEBSCZQoulN6npMYJ = ['افلام','movie','فيلم','فلم']
	ZZDjNmoAELWPYsVd4I = ['مسلسل','series']
	p3daTSVMoQZABJW1gRHvLzm5KwY = ['مسارح','مسرحيات']
	bB72N4pSCf = ['برامج','show','تلفزيون','تليفزيون']
	pKfi0rEm1GUHbx = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	Xy2si4ejMCbF7KDtlAQp6zEaY = ['رمضان']
	bX4pueFyDgAm3SJOx5 = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	koZrGERU0CexwDsMbPhpty2O = ['سلاسل','سلسله']
	JN8dr56QjLGImwk = ['اغاني','موسيقى','كليب','حفل','music']
	VVTjE7Sh1MoYvcqteU2BnQF3ayCK = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	NukbcohwUBW06SA1dL = ['الان','حالي','مثبت','رائج']
	bbkQfS6s8URH = ['ضحك','كوميدي']
	AAk6HrmNcqdsJGIOV = ['رياضه','كوره','مصارعه','شوت','رياضة']
	xi7cOj6XVy5Dfp0lmrt3ESv = ['نيتفلكس','netflix','نيتفليكس']
	CdD7cQ4XMWoVKHgb8f = ['ممثلين','اشخاص','نجوم']
	r9gtNWGzOuJvZE = ['بث حي','live','قناه','قنوات']
	Ih5BLYKpNZ0tHR = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	VSKOLmFyXaZ8PjgEM2 = ['19','20','21','22','23','24','25','26']
	if not jjlMIxo2wyDaKuQtNUpB18Y4:
		jjlMIxo2wyDaKuQtNUpB18Y4 = 0
		for nnDy4OFcVT791IevG8d0zxM in dZRQc2rqusIveyX8p:
			jjlMIxo2wyDaKuQtNUpB18Y4 += 1
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+nnDy4OFcVT791IevG8d0zxM,'',763,'',str(jjlMIxo2wyDaKuQtNUpB18Y4),w6fNJ0bEMG7kVI5qdZnePHsyv,'',{'folder':W8U7yZeMX3owTiS5mDfJh})
	else:
		for rBabYANvVwWzjCp2QF in sorted(list(yvRq7ZeaIJx6d.keys())):
			XUj8uOQAJ6pBCitZ4Te = rBabYANvVwWzjCp2QF.lower()
			qGsE8fdyFtUwBnu = []
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in IADzKfyPehTEBSCZQoulN6npMYJ): qGsE8fdyFtUwBnu.append(1)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in ZZDjNmoAELWPYsVd4I): qGsE8fdyFtUwBnu.append(2)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in p3daTSVMoQZABJW1gRHvLzm5KwY): qGsE8fdyFtUwBnu.append(3)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in bB72N4pSCf): qGsE8fdyFtUwBnu.append(4)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in pKfi0rEm1GUHbx): qGsE8fdyFtUwBnu.append(5)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in Xy2si4ejMCbF7KDtlAQp6zEaY): qGsE8fdyFtUwBnu.append(6)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in bX4pueFyDgAm3SJOx5) and XUj8uOQAJ6pBCitZ4Te not in ['اخرى']: qGsE8fdyFtUwBnu.append(7)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in koZrGERU0CexwDsMbPhpty2O): qGsE8fdyFtUwBnu.append(8)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in JN8dr56QjLGImwk): qGsE8fdyFtUwBnu.append(9)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in VVTjE7Sh1MoYvcqteU2BnQF3ayCK): qGsE8fdyFtUwBnu.append(10)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in NukbcohwUBW06SA1dL): qGsE8fdyFtUwBnu.append(11)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in bbkQfS6s8URH): qGsE8fdyFtUwBnu.append(12)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in AAk6HrmNcqdsJGIOV): qGsE8fdyFtUwBnu.append(13)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in xi7cOj6XVy5Dfp0lmrt3ESv): qGsE8fdyFtUwBnu.append(14)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in CdD7cQ4XMWoVKHgb8f): qGsE8fdyFtUwBnu.append(15)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in r9gtNWGzOuJvZE): qGsE8fdyFtUwBnu.append(16)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in Ih5BLYKpNZ0tHR): qGsE8fdyFtUwBnu.append(17)
			if any(Y3YqSmycrIWksoH5N0MvC in XUj8uOQAJ6pBCitZ4Te for Y3YqSmycrIWksoH5N0MvC in VSKOLmFyXaZ8PjgEM2): qGsE8fdyFtUwBnu.append(18)
			if not qGsE8fdyFtUwBnu: qGsE8fdyFtUwBnu = [19]
			for DoFa7TOYKcSrJARPgwuzk in qGsE8fdyFtUwBnu:
				if str(DoFa7TOYKcSrJARPgwuzk)==jjlMIxo2wyDaKuQtNUpB18Y4:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+rBabYANvVwWzjCp2QF,rBabYANvVwWzjCp2QF,166,'','',w6fNJ0bEMG7kVI5qdZnePHsyv+'_REMEMBERRESULTS_')
	return
def O97XtZV0G4TFf3NwdjMQrCn(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0):
	u5yYiXzKRhjqoG8t = False
	if u5yYiXzKRhjqoG8t:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','تحديث هذه القائمة','',764,'','','_CREATENEW_','',{'folder':W8U7yZeMX3owTiS5mDfJh})
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	dQ2zOuAWqSKi47YlnFpPxbeGv = PL2fM9WhpjEFb7[:]
	import Nipbs3ZV5T
	if W8U7yZeMX3owTiS5mDfJh:
		if not Nipbs3ZV5T.dzgJhQfsE7wOD3AU(W8U7yZeMX3owTiS5mDfJh,True): return
		MknextyWwRf = AHSW4yzE3xrVfdocFOP2UlhCJbwj7m(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0)
		xjTiJEd9gz2HlwDpIe3 = sorted(MknextyWwRf,reverse=False,key=lambda key: key[1].lower())
	else:
		if not Nipbs3ZV5T.dzgJhQfsE7wOD3AU('',True): return
		if u5yYiXzKRhjqoG8t and '_CREATENEW_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			xjTiJEd9gz2HlwDpIe3 = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			qHZ2Ty3pMls0RcdBKYiNguJ4P,xjTiJEd9gz2HlwDpIe3,MknextyWwRf = [],[],[]
			for K32bMNk6Q9cnrVwpeldaLXi5J in range(1,Z7TlP2WKYq5SuRD+1):
				xjTiJEd9gz2HlwDpIe3 += AHSW4yzE3xrVfdocFOP2UlhCJbwj7m(str(K32bMNk6Q9cnrVwpeldaLXi5J),ihbjPQKgtdYUvNnLV5XErp3f0)
			for type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in xjTiJEd9gz2HlwDpIe3:
				if hulSHFUcXsaVQGTn8r9zMkNPIwgvo not in qHZ2Ty3pMls0RcdBKYiNguJ4P:
					qHZ2Ty3pMls0RcdBKYiNguJ4P.append(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
					J0rUNmTt96LvGkCsulXFioDZ4O = type,rBabYANvVwWzjCp2QF,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,165,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,ihbjPQKgtdYUvNnLV5XErp3f0,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv
					MknextyWwRf.append(J0rUNmTt96LvGkCsulXFioDZ4O)
			xjTiJEd9gz2HlwDpIe3 = sorted(MknextyWwRf,reverse=False,key=lambda key: key[1].lower())
			if u5yYiXzKRhjqoG8t: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',xjTiJEd9gz2HlwDpIe3,iJnLmxA0ykozR98WXFQ4Ye3w)
	PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+xjTiJEd9gz2HlwDpIe3
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin('Container.Refresh')
	return
def r81R2j3icmaXlTt(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0):
	u5yYiXzKRhjqoG8t = False
	if u5yYiXzKRhjqoG8t:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','تحديث هذه القائمة','',765,'','','_CREATENEW_','',{'folder':W8U7yZeMX3owTiS5mDfJh})
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	dQ2zOuAWqSKi47YlnFpPxbeGv = PL2fM9WhpjEFb7[:]
	import aCyfkwjhpQ
	if W8U7yZeMX3owTiS5mDfJh:
		if not aCyfkwjhpQ.dzgJhQfsE7wOD3AU(W8U7yZeMX3owTiS5mDfJh,True): return
		MknextyWwRf = ZZxOnKv5T1McaVyedo(W8U7yZeMX3owTiS5mDfJh,ihbjPQKgtdYUvNnLV5XErp3f0)
		xjTiJEd9gz2HlwDpIe3 = sorted(MknextyWwRf,reverse=False,key=lambda key: key[1].lower())
	else:
		if not aCyfkwjhpQ.dzgJhQfsE7wOD3AU('',True): return
		if u5yYiXzKRhjqoG8t and '_CREATENEW_' not in ihbjPQKgtdYUvNnLV5XErp3f0:
			xjTiJEd9gz2HlwDpIe3 = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			qHZ2Ty3pMls0RcdBKYiNguJ4P,xjTiJEd9gz2HlwDpIe3,MknextyWwRf = [],[],[]
			for K32bMNk6Q9cnrVwpeldaLXi5J in range(1,Z7TlP2WKYq5SuRD+1):
				xjTiJEd9gz2HlwDpIe3 += ZZxOnKv5T1McaVyedo(str(K32bMNk6Q9cnrVwpeldaLXi5J),ihbjPQKgtdYUvNnLV5XErp3f0)
			for type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in xjTiJEd9gz2HlwDpIe3:
				if hulSHFUcXsaVQGTn8r9zMkNPIwgvo not in qHZ2Ty3pMls0RcdBKYiNguJ4P:
					qHZ2Ty3pMls0RcdBKYiNguJ4P.append(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
					J0rUNmTt96LvGkCsulXFioDZ4O = type,rBabYANvVwWzjCp2QF,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,165,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,ihbjPQKgtdYUvNnLV5XErp3f0,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv
					MknextyWwRf.append(J0rUNmTt96LvGkCsulXFioDZ4O)
			xjTiJEd9gz2HlwDpIe3 = sorted(MknextyWwRf,reverse=False,key=lambda key: key[1].lower())
			if u5yYiXzKRhjqoG8t: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_ALL',xjTiJEd9gz2HlwDpIe3,iJnLmxA0ykozR98WXFQ4Ye3w)
	PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+xjTiJEd9gz2HlwDpIe3
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin('Container.Refresh')
	return
def bOyPjXeWqmQ4rkxNc(group,ihbjPQKgtdYUvNnLV5XErp3f0):
	u5yYiXzKRhjqoG8t = False
	mL7BVKcSygkuoPbWlEF4YD = []
	f9DM6s3pLyR7Q1i2ABt5J = '_IPTV_' if 'IPTV' in ihbjPQKgtdYUvNnLV5XErp3f0 else '_M3U_'
	if u5yYiXzKRhjqoG8t: mL7BVKcSygkuoPbWlEF4YD = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS'+f9DM6s3pLyR7Q1i2ABt5J[:-1],group)
	if not mL7BVKcSygkuoPbWlEF4YD:
		for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
			if u5yYiXzKRhjqoG8t: mL7BVKcSygkuoPbWlEF4YD += cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','SECTIONS'+f9DM6s3pLyR7Q1i2ABt5J[:-1],'SECTIONS'+f9DM6s3pLyR7Q1i2ABt5J+str(W8U7yZeMX3owTiS5mDfJh))
			elif f9DM6s3pLyR7Q1i2ABt5J=='_IPTV_': mL7BVKcSygkuoPbWlEF4YD += AHSW4yzE3xrVfdocFOP2UlhCJbwj7m(str(W8U7yZeMX3owTiS5mDfJh),'_CREATENEW_')
			elif f9DM6s3pLyR7Q1i2ABt5J=='_M3U_': mL7BVKcSygkuoPbWlEF4YD += ZZxOnKv5T1McaVyedo(str(W8U7yZeMX3owTiS5mDfJh),'_CREATENEW_')
		for type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in mL7BVKcSygkuoPbWlEF4YD:
			if hulSHFUcXsaVQGTn8r9zMkNPIwgvo==group: rGxOVv8jzm(type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
		items,uaq5LNOdZJhV4fDwvcsnU17WrX = [],[]
		for type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in PL2fM9WhpjEFb7:
			ywESxnPT5mUQWaiMftZqAYc630 = type,rBabYANvVwWzjCp2QF[4:],url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,''
			if ywESxnPT5mUQWaiMftZqAYc630 not in uaq5LNOdZJhV4fDwvcsnU17WrX:
				uaq5LNOdZJhV4fDwvcsnU17WrX.append(ywESxnPT5mUQWaiMftZqAYc630)
				KxB8vVHUJg = type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv
				items.append(KxB8vVHUJg)
		mL7BVKcSygkuoPbWlEF4YD = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if u5yYiXzKRhjqoG8t: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'SECTIONS'+f9DM6s3pLyR7Q1i2ABt5J[:-1],group,mL7BVKcSygkuoPbWlEF4YD,iJnLmxA0ykozR98WXFQ4Ye3w)
	if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0 and len(mL7BVKcSygkuoPbWlEF4YD)>iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H:
		PL2fM9WhpjEFb7[:] = []
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,'','',f9DM6s3pLyR7Q1i2ABt5J+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة الطلب العشوائي من نفس القسم',group,165,'','',f9DM6s3pLyR7Q1i2ABt5J+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		mL7BVKcSygkuoPbWlEF4YD = PL2fM9WhpjEFb7+GpOkwndjsI27uM.sample(mL7BVKcSygkuoPbWlEF4YD,iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H)
	PL2fM9WhpjEFb7[:] = mL7BVKcSygkuoPbWlEF4YD
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin('Container.Refresh')
	return
def Pl6AEoprTR19Bysg(ihbjPQKgtdYUvNnLV5XErp3f0):
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة طلب قنوات عشوائية','',161,'','','_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	x3xkNHPU5BmWnYsZ12 = PL2fM9WhpjEFb7[:]
	PL2fM9WhpjEFb7[:] = []
	import CvOdySBEle
	CvOdySBEle.egYaAP6oIWDjfzqX20HnKS('0',False)
	CvOdySBEle.egYaAP6oIWDjfzqX20HnKS('1',False)
	CvOdySBEle.egYaAP6oIWDjfzqX20HnKS('2',False)
	if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		PL2fM9WhpjEFb7[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
		if len(PL2fM9WhpjEFb7)>iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H: PL2fM9WhpjEFb7[:] = GpOkwndjsI27uM.sample(PL2fM9WhpjEFb7,iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H)
	PL2fM9WhpjEFb7[:] = x3xkNHPU5BmWnYsZ12+PL2fM9WhpjEFb7
	return
def m3HwQSTfcM6Fb5BoW9yrsO1aPCt(ihbjPQKgtdYUvNnLV5XErp3f0):
	ihbjPQKgtdYUvNnLV5XErp3f0 = ihbjPQKgtdYUvNnLV5XErp3f0.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	headers = { 'User-Agent' : '' }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = lfM8WO96En(data)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(WfPehiKL4XVlonMQr9kUwAca6IybDj,'GET',url,data,headers,'','','RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="content"(.*?)class="clearfix"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	icUOBZIvD3t7s0kl,aPSlAqY7FJC3Lznp0Vb = list(zip(*items))
	OOGWbvxCynwXiZ5NTBIY4UzsoaMA1 = []
	dKgbPiIk31OutYh27sVmq = [' ','"','`',',','.',':',';',"'",'-']
	KK0wmorzn5EfIeh7tPyJ9B1ZbWaSQ = aPSlAqY7FJC3Lznp0Vb+icUOBZIvD3t7s0kl
	for HHVePR6QpxUsAJS in KK0wmorzn5EfIeh7tPyJ9B1ZbWaSQ:
		if HHVePR6QpxUsAJS in aPSlAqY7FJC3Lznp0Vb: stikxmhaLnQK7oWz = 2
		if HHVePR6QpxUsAJS in icUOBZIvD3t7s0kl: stikxmhaLnQK7oWz = 4
		r0AHt4BneZ1Llsb3jfcvM = [ggjo5zu7yCiIOhrb in HHVePR6QpxUsAJS for ggjo5zu7yCiIOhrb in dKgbPiIk31OutYh27sVmq]
		if any(r0AHt4BneZ1Llsb3jfcvM):
			ZJfCEzd2DxAvbiYg = r0AHt4BneZ1Llsb3jfcvM.index(True)
			IoPSfKul1HFpsT = dKgbPiIk31OutYh27sVmq[ZJfCEzd2DxAvbiYg]
			uejB9fWkF50g1CyG7UYoS = ''
			if HHVePR6QpxUsAJS.count(IoPSfKul1HFpsT)>1: xYb8O0ZHGN2IUPvyCD76zmE,gXwR0dj3lkU,uejB9fWkF50g1CyG7UYoS = HHVePR6QpxUsAJS.split(IoPSfKul1HFpsT,2)
			else: xYb8O0ZHGN2IUPvyCD76zmE,gXwR0dj3lkU = HHVePR6QpxUsAJS.split(IoPSfKul1HFpsT,1)
			if len(xYb8O0ZHGN2IUPvyCD76zmE)>stikxmhaLnQK7oWz: OOGWbvxCynwXiZ5NTBIY4UzsoaMA1.append(xYb8O0ZHGN2IUPvyCD76zmE.lower())
			if len(gXwR0dj3lkU)>stikxmhaLnQK7oWz: OOGWbvxCynwXiZ5NTBIY4UzsoaMA1.append(gXwR0dj3lkU.lower())
			if len(uejB9fWkF50g1CyG7UYoS)>stikxmhaLnQK7oWz: OOGWbvxCynwXiZ5NTBIY4UzsoaMA1.append(uejB9fWkF50g1CyG7UYoS.lower())
		elif len(HHVePR6QpxUsAJS)>stikxmhaLnQK7oWz: OOGWbvxCynwXiZ5NTBIY4UzsoaMA1.append(HHVePR6QpxUsAJS.lower())
	for ggjo5zu7yCiIOhrb in range(9): GpOkwndjsI27uM.shuffle(OOGWbvxCynwXiZ5NTBIY4UzsoaMA1)
	if '_SITES_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		O68YEX0y52IrlcVtGao = Mo2ZvEHtN8QOj5gy1pnVxFLPd
	elif '_IPTV_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		O68YEX0y52IrlcVtGao = ['IPTV']
		import Nipbs3ZV5T
		if not Nipbs3ZV5T.dzgJhQfsE7wOD3AU('',True): return
	elif '_M3U_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		O68YEX0y52IrlcVtGao = ['M3U']
		import aCyfkwjhpQ
		if not aCyfkwjhpQ.dzgJhQfsE7wOD3AU('',True): return
	count,ykXfc96EUhQI = 0,0
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[  ] :البحث عن','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة البحث العشوائي','',164,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	L1ZOkniotJvp34MFQNVaXbK9 = PL2fM9WhpjEFb7[:]
	PL2fM9WhpjEFb7[:] = []
	lSWKhXcejJ = []
	for HHVePR6QpxUsAJS in OOGWbvxCynwXiZ5NTBIY4UzsoaMA1:
		gXwR0dj3lkU = JJDtX1PZyIgN2T.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',HHVePR6QpxUsAJS,JJDtX1PZyIgN2T.DOTALL)
		if gXwR0dj3lkU: HHVePR6QpxUsAJS = HHVePR6QpxUsAJS.split(gXwR0dj3lkU[0],1)[0]
		gMdbqOae7NhTJDWltHV31xmYSAICu4 = HHVePR6QpxUsAJS.replace('ّ','').replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		gMdbqOae7NhTJDWltHV31xmYSAICu4 = gMdbqOae7NhTJDWltHV31xmYSAICu4.replace('ِ','').replace('ٍ','').replace('ْ','').replace('،','').replace('ـ','')
		if gMdbqOae7NhTJDWltHV31xmYSAICu4: lSWKhXcejJ.append(gMdbqOae7NhTJDWltHV31xmYSAICu4)
	SSqIDUJF0sjwmxi = []
	for uvTwHSmjyW6Vr0192IZ in range(0,20):
		search = GpOkwndjsI27uM.sample(lSWKhXcejJ,1)[0]
		if search in SSqIDUJF0sjwmxi: continue
		SSqIDUJF0sjwmxi.append(search)
		HLAhjNIVMFonqi5zg2aQlpyfRKBrm = GpOkwndjsI27uM.sample(O68YEX0y52IrlcVtGao,1)[0]
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Random Video Search   site:'+str(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)+'  search:'+search)
		UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b = DDE8bFYNye7xkqHoVvzXOSg1l0d6(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
		y9topEPuNCwYTgB(search+'_NODIALOGS_')
		if len(PL2fM9WhpjEFb7)>0: break
	search = search.replace('_MOD_','')
	L1ZOkniotJvp34MFQNVaXbK9[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	PL2fM9WhpjEFb7[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
	if len(PL2fM9WhpjEFb7)>iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H: PL2fM9WhpjEFb7[:] = GpOkwndjsI27uM.sample(PL2fM9WhpjEFb7,iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H)
	PL2fM9WhpjEFb7[:] = L1ZOkniotJvp34MFQNVaXbK9+PL2fM9WhpjEFb7
	return
def dGAMw59WofqE6cDvrlZ1e0tkIF7(M9MiUIjNLQCEblR1uhyw6pZ5,ihbjPQKgtdYUvNnLV5XErp3f0):
	M9MiUIjNLQCEblR1uhyw6pZ5 = M9MiUIjNLQCEblR1uhyw6pZ5.replace('_MOD_','')
	ihbjPQKgtdYUvNnLV5XErp3f0 = ihbjPQKgtdYUvNnLV5XErp3f0.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	FM0S4p7zQhnHOo(False)
	if yvRq7ZeaIJx6d=={}: return
	if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[[COLOR FFC89008]'+M9MiUIjNLQCEblR1uhyw6pZ5+'[/COLOR] :القسم]',M9MiUIjNLQCEblR1uhyw6pZ5,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة الطلب العشوائي من نفس القسم',M9MiUIjNLQCEblR1uhyw6pZ5,166,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for website in sorted(list(yvRq7ZeaIJx6d[M9MiUIjNLQCEblR1uhyw6pZ5].keys())):
		type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = yvRq7ZeaIJx6d[M9MiUIjNLQCEblR1uhyw6pZ5][website]
		if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0 or len(yvRq7ZeaIJx6d[M9MiUIjNLQCEblR1uhyw6pZ5])==1:
			rGxOVv8jzm(type,'',url,Q8QglLCU5P,'',vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'','')
			PL2fM9WhpjEFb7[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
			dQ2zOuAWqSKi47YlnFpPxbeGv,xjTiJEd9gz2HlwDpIe3 = PL2fM9WhpjEFb7[:3],PL2fM9WhpjEFb7[3:]
			for ggjo5zu7yCiIOhrb in range(9): GpOkwndjsI27uM.shuffle(xjTiJEd9gz2HlwDpIe3)
			if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0: PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+xjTiJEd9gz2HlwDpIe3[:iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H]
			else: PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+xjTiJEd9gz2HlwDpIe3
		elif '_SITES_' in ihbjPQKgtdYUvNnLV5XErp3f0: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',website,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	return
def xuTcVhnPOv7tMHeNyrBCg(ihbjPQKgtdYUvNnLV5XErp3f0,AFWci0tYmjRU1azGJEy3ovDw2hfsqr):
	ihbjPQKgtdYUvNnLV5XErp3f0 = ihbjPQKgtdYUvNnLV5XErp3f0.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	rBabYANvVwWzjCp2QF,WP5vUbHTwJksX = '',[]
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[[COLOR FFC89008]'+rBabYANvVwWzjCp2QF+'[/COLOR] :القسم]','',AFWci0tYmjRU1azGJEy3ovDw2hfsqr,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة طلب قسم عشوائي','',AFWci0tYmjRU1azGJEy3ovDw2hfsqr,'','','_FORGETRESULTS__REMEMBERRESULTS_'+ihbjPQKgtdYUvNnLV5XErp3f0)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	dQ2zOuAWqSKi47YlnFpPxbeGv = PL2fM9WhpjEFb7[:]
	PL2fM9WhpjEFb7[:] = []
	mL7BVKcSygkuoPbWlEF4YD = []
	if '_SITES_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		FM0S4p7zQhnHOo(False)
		if yvRq7ZeaIJx6d=={}: return
		ZcEYr09LQ8BV2U5fTnKx = list(yvRq7ZeaIJx6d.keys())
		M9MiUIjNLQCEblR1uhyw6pZ5 = GpOkwndjsI27uM.sample(ZcEYr09LQ8BV2U5fTnKx,1)[0]
		OOGWbvxCynwXiZ5NTBIY4UzsoaMA1 = list(yvRq7ZeaIJx6d[M9MiUIjNLQCEblR1uhyw6pZ5].keys())
		website = GpOkwndjsI27uM.sample(OOGWbvxCynwXiZ5NTBIY4UzsoaMA1,1)[0]
		type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = yvRq7ZeaIJx6d[M9MiUIjNLQCEblR1uhyw6pZ5][website]
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Random Category   website: '+website+'   name: '+rBabYANvVwWzjCp2QF+'   url: '+url+'   mode: '+str(Q8QglLCU5P))
	elif '_IPTV_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		import Nipbs3ZV5T
		if not Nipbs3ZV5T.dzgJhQfsE7wOD3AU('',True): return
		for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
			mL7BVKcSygkuoPbWlEF4YD += AHSW4yzE3xrVfdocFOP2UlhCJbwj7m(str(W8U7yZeMX3owTiS5mDfJh),ihbjPQKgtdYUvNnLV5XErp3f0)
		if not mL7BVKcSygkuoPbWlEF4YD: return
		type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = GpOkwndjsI27uM.sample(mL7BVKcSygkuoPbWlEF4YD,1)[0]
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Random Category   name: '+rBabYANvVwWzjCp2QF+'   url: '+url+'   mode: '+str(Q8QglLCU5P))
	elif '_M3U_' in ihbjPQKgtdYUvNnLV5XErp3f0:
		import aCyfkwjhpQ
		if not aCyfkwjhpQ.dzgJhQfsE7wOD3AU('',True): return
		for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
			mL7BVKcSygkuoPbWlEF4YD += ZZxOnKv5T1McaVyedo(str(W8U7yZeMX3owTiS5mDfJh),ihbjPQKgtdYUvNnLV5XErp3f0)
		if not mL7BVKcSygkuoPbWlEF4YD: return
		type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = GpOkwndjsI27uM.sample(mL7BVKcSygkuoPbWlEF4YD,1)[0]
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Random Category   name: '+rBabYANvVwWzjCp2QF+'   url: '+url+'   mode: '+str(Q8QglLCU5P))
	xxwimVWvcoGSChEf = rBabYANvVwWzjCp2QF
	vsNUGtzIhZqJ = []
	for ggjo5zu7yCiIOhrb in range(0,10):
		if ggjo5zu7yCiIOhrb>0: b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Random Category   name: '+rBabYANvVwWzjCp2QF+'   url: '+url+'   mode: '+str(Q8QglLCU5P))
		PL2fM9WhpjEFb7[:] = []
		if Q8QglLCU5P==234 and '__IPTVSeries__' in hulSHFUcXsaVQGTn8r9zMkNPIwgvo: Q8QglLCU5P = 233
		if Q8QglLCU5P==714 and '__M3USeries__' in hulSHFUcXsaVQGTn8r9zMkNPIwgvo: Q8QglLCU5P = 713
		if Q8QglLCU5P==144: Q8QglLCU5P = 291
		g5lf2u4DxNp8imnYevK = rGxOVv8jzm(type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
		if '_IPTV_' in ihbjPQKgtdYUvNnLV5XErp3f0 and Q8QglLCU5P==167: del PL2fM9WhpjEFb7[:3]
		if '_M3U_' in ihbjPQKgtdYUvNnLV5XErp3f0 and Q8QglLCU5P==168: del PL2fM9WhpjEFb7[:3]
		WP5vUbHTwJksX[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
		if vsNUGtzIhZqJ and GlsezWv7iIro(u'حلقة') in str(WP5vUbHTwJksX) or GlsezWv7iIro(u'حلقه') in str(WP5vUbHTwJksX):
			rBabYANvVwWzjCp2QF = xxwimVWvcoGSChEf
			WP5vUbHTwJksX[:] = vsNUGtzIhZqJ
			break
		xxwimVWvcoGSChEf = rBabYANvVwWzjCp2QF
		vsNUGtzIhZqJ = WP5vUbHTwJksX
		if str(WP5vUbHTwJksX).count('video')>0: break
		if str(WP5vUbHTwJksX).count('live')>0: break
		if Q8QglLCU5P==233: break
		if Q8QglLCU5P==713: break
		if Q8QglLCU5P==291: break
		if WP5vUbHTwJksX: type,rBabYANvVwWzjCp2QF,url,Q8QglLCU5P,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = GpOkwndjsI27uM.sample(WP5vUbHTwJksX,1)[0]
	if not rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = '....'
	elif rBabYANvVwWzjCp2QF.count('_')>1: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.split('_',2)[2]
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('UNKNOWN: ','')
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('_MOD_','')
	dQ2zOuAWqSKi47YlnFpPxbeGv[0][1] = '[[COLOR FFC89008]'+rBabYANvVwWzjCp2QF+'[/COLOR] :القسم]'
	for ggjo5zu7yCiIOhrb in range(9): GpOkwndjsI27uM.shuffle(WP5vUbHTwJksX)
	if '_RANDOM_' in ihbjPQKgtdYUvNnLV5XErp3f0: PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+WP5vUbHTwJksX[:iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H]
	else: PL2fM9WhpjEFb7[:] = dQ2zOuAWqSKi47YlnFpPxbeGv+WP5vUbHTwJksX
	return
def oo2LbFsVygxIM(P1Gqs6pMf8,FKAfWTqC9JEYRvn30):
	FKAfWTqC9JEYRvn30 = FKAfWTqC9JEYRvn30.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	gRoa1ziklCPNhFUXDBV = FKAfWTqC9JEYRvn30
	if '__IPTVSeries__' in FKAfWTqC9JEYRvn30:
		gRoa1ziklCPNhFUXDBV = FKAfWTqC9JEYRvn30.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in P1Gqs6pMf8: type = ',VIDEOS: '
	elif 'LIVE' in P1Gqs6pMf8: type = ',LIVE: '
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[[COLOR FFC89008]'+type+gRoa1ziklCPNhFUXDBV+'[/COLOR] :القسم]',P1Gqs6pMf8,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+FKAfWTqC9JEYRvn30)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة الطلب العشوائي من نفس القسم',P1Gqs6pMf8,167,'','','_FORGETRESULTS__REMEMBERRESULTS_'+FKAfWTqC9JEYRvn30)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import Nipbs3ZV5T
	for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
		if '__IPTVSeries__' in FKAfWTqC9JEYRvn30: Nipbs3ZV5T.OUjyxPoiSLT6(str(W8U7yZeMX3owTiS5mDfJh),P1Gqs6pMf8,FKAfWTqC9JEYRvn30,'',False)
		else: Nipbs3ZV5T.egYaAP6oIWDjfzqX20HnKS(str(W8U7yZeMX3owTiS5mDfJh),P1Gqs6pMf8,FKAfWTqC9JEYRvn30,'',False)
	PL2fM9WhpjEFb7[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
	if len(PL2fM9WhpjEFb7)>(iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H+3): PL2fM9WhpjEFb7[:] = PL2fM9WhpjEFb7[:3]+GpOkwndjsI27uM.sample(PL2fM9WhpjEFb7[3:],iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H)
	return
def Vu2f3MhAJkoUSlzPyFjpn(P1Gqs6pMf8,FKAfWTqC9JEYRvn30):
	FKAfWTqC9JEYRvn30 = FKAfWTqC9JEYRvn30.replace('_FORGETRESULTS_','').replace('_REMEMBERRESULTS_','')
	gRoa1ziklCPNhFUXDBV = FKAfWTqC9JEYRvn30
	if '__M3USeries__' in FKAfWTqC9JEYRvn30:
		gRoa1ziklCPNhFUXDBV = FKAfWTqC9JEYRvn30.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in P1Gqs6pMf8: type = ',VIDEOS: '
	elif 'LIVE' in P1Gqs6pMf8: type = ',LIVE: '
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','[[COLOR FFC89008]'+type+gRoa1ziklCPNhFUXDBV+'[/COLOR] :القسم]',P1Gqs6pMf8,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+FKAfWTqC9JEYRvn30)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','إعادة الطلب العشوائي من نفس القسم',P1Gqs6pMf8,168,'','','_FORGETRESULTS__REMEMBERRESULTS_'+FKAfWTqC9JEYRvn30)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	import aCyfkwjhpQ
	for W8U7yZeMX3owTiS5mDfJh in range(1,Z7TlP2WKYq5SuRD+1):
		if '__M3USeries__' in FKAfWTqC9JEYRvn30: aCyfkwjhpQ.OUjyxPoiSLT6(str(W8U7yZeMX3owTiS5mDfJh),P1Gqs6pMf8,FKAfWTqC9JEYRvn30,'',False)
		else: aCyfkwjhpQ.egYaAP6oIWDjfzqX20HnKS(str(W8U7yZeMX3owTiS5mDfJh),P1Gqs6pMf8,FKAfWTqC9JEYRvn30,'',False)
	PL2fM9WhpjEFb7[:] = zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7)
	if len(PL2fM9WhpjEFb7)>(iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H+3): PL2fM9WhpjEFb7[:] = PL2fM9WhpjEFb7[:3]+GpOkwndjsI27uM.sample(PL2fM9WhpjEFb7[3:],iqxl1EIn6BJh9P7NMUDtTc8zOsYQ3H)
	return
def zzMJnkQDdI7CWGB1oTlK2Li3Njx(PL2fM9WhpjEFb7):
	WP5vUbHTwJksX = []
	for type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in PL2fM9WhpjEFb7:
		if 'صفحة' in rBabYANvVwWzjCp2QF or 'صفحه' in rBabYANvVwWzjCp2QF or 'page' in rBabYANvVwWzjCp2QF.lower(): continue
		WP5vUbHTwJksX.append([type,rBabYANvVwWzjCp2QF,url,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv])
	return WP5vUbHTwJksX
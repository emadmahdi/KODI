# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
s1ITpY2ghtCvR3mSXkFVBnlL8 = 'M3U'
t8SVWInB3P7 = '_M3U_'
kxteHPOwy8n0pC64mGVYLFTf = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
ZUQFS8NrIA6hH = 4
def LO5euqvXT1U3S7CaNlP(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,apIVksn1FTuj6rbYhMPDLHS9N,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,GGKpqhAcPw9FHBvdfarRuySJ1Yl,WXU2APNzuivcGgq,IxCL4nMsp0NGHgJy8hEOiQFoduAl):
	global t8SVWInB3P7
	try:
		F8UNnjSZvpI = str(IxCL4nMsp0NGHgJy8hEOiQFoduAl['folder'])
		t8SVWInB3P7 = '_MU'+F8UNnjSZvpI+'_'
	except: F8UNnjSZvpI = ''
	try: qpB7IC2ViZ9a4sDtlbTOdv6 = str(IxCL4nMsp0NGHgJy8hEOiQFoduAl['sequence'])
	except: qpB7IC2ViZ9a4sDtlbTOdv6 = ''
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==710: pyWkE2rh5uBN4G = bdit4wAW6JZxPQ7jUv8EuCFYcR()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==711: pyWkE2rh5uBN4G = WS7HwIGFXRNKVfQsiMZLtCO5(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==712: pyWkE2rh5uBN4G = eRrpZlnzoM9WGf(F8UNnjSZvpI)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==713: pyWkE2rh5uBN4G = OUjyxPoiSLT6(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,WXU2APNzuivcGgq)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==714: pyWkE2rh5uBN4G = egYaAP6oIWDjfzqX20HnKS(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,WXU2APNzuivcGgq)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==715: pyWkE2rh5uBN4G = CsUdRabWuh0M9F(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,GGKpqhAcPw9FHBvdfarRuySJ1Yl)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==716: pyWkE2rh5uBN4G = jJxoMwaU9uXfk4t15E(F8UNnjSZvpI,True)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==717: pyWkE2rh5uBN4G = TJ5FSbBKkOafQEGLg2XldcZ4Yjqh(F8UNnjSZvpI,True)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==718: pyWkE2rh5uBN4G = eIURObW5jtDa(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==719: pyWkE2rh5uBN4G = OXTVJbg9envrs(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,WXU2APNzuivcGgq)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==720: pyWkE2rh5uBN4G = iG6vTHmb5KUCaWqrjz(F8UNnjSZvpI,True)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==721: pyWkE2rh5uBN4G = mmLX1BP7VxJiIYAo82cabFC4W(F8UNnjSZvpI)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==722: pyWkE2rh5uBN4G = nkOmvZhb0H4auFxT5of7pSXQMtc(F8UNnjSZvpI)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==723: pyWkE2rh5uBN4G = bl0HXeJysOT7qNL8zVZ(F8UNnjSZvpI)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==726: pyWkE2rh5uBN4G = D7bspBFdjYOCc(F8UNnjSZvpI)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==729: pyWkE2rh5uBN4G = sfOnUGePLWz47tB(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,WXU2APNzuivcGgq)
	else: pyWkE2rh5uBN4G = False
	return pyWkE2rh5uBN4G
def bdit4wAW6JZxPQ7jUv8EuCFYcR():
	for F8UNnjSZvpI in range(1,Z7TlP2WKYq5SuRD+1):
		t8SVWInB3P7 = '_MU'+str(F8UNnjSZvpI)+'_'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قائمة مجلد '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[F8UNnjSZvpI],'',720,'','','','',{'folder':F8UNnjSZvpI})
	return
def iG6vTHmb5KUCaWqrjz(F8UNnjSZvpI='',Jjlf8RwAikOqePtvbW0IXudhF36Z=''):
	if F8UNnjSZvpI:
		aMovAWceF1G = {'folder':F8UNnjSZvpI}
		sLTw4nY3ACKboMIPZGt0 = ''
	else:
		aMovAWceF1G = ''
		sLTw4nY3ACKboMIPZGt0 = ''
	v65rgqsyHAPjRSxKetf = dzgJhQfsE7wOD3AU(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z)
	if not v65rgqsyHAPjRSxKetf:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'[COLOR FFFFFF00] إضافة وتغيير رابط'+sLTw4nY3ACKboMIPZGt0+' '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[1]+' [/COLOR]','',711,'','','','',{'folder':F8UNnjSZvpI,'sequence':1})
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'[COLOR FFFFFF00] جلب ملفات'+sLTw4nY3ACKboMIPZGt0+' [/COLOR]','',712,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	else:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'بحث في الملفات'+sLTw4nY3ACKboMIPZGt0,'',729,'','','_REMEMBERRESULTS_','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مصنفة مرتبة'+sLTw4nY3ACKboMIPZGt0,'LIVE_GROUPED_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مصنفة من القسم'+sLTw4nY3ACKboMIPZGt0,'LIVE_FROM_GROUP_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مصنفة من الاسم'+sLTw4nY3ACKboMIPZGt0,'LIVE_FROM_NAME_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مصنفة بلا ترتيب'+sLTw4nY3ACKboMIPZGt0,'LIVE_GROUPED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات بلا ترتيب'+sLTw4nY3ACKboMIPZGt0,'LIVE_ORIGINAL_GROUPED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مجهولة مرتبة'+sLTw4nY3ACKboMIPZGt0,'LIVE_UNKNOWN_GROUPED_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'قنوات مجهولة بلا ترتيب'+sLTw4nY3ACKboMIPZGt0,'LIVE_UNKNOWN_GROUPED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'فيديوهات بلا ترتيب'+sLTw4nY3ACKboMIPZGt0,'VOD_ORIGINAL_GROUPED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'فيديوهات مصنفة القسم'+sLTw4nY3ACKboMIPZGt0,'VOD_FROM_GROUP_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'فيديوهات مصنفة من الاسم'+sLTw4nY3ACKboMIPZGt0,'VOD_FROM_NAME_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'فيديوهات مجهولة بلا ترتيب'+sLTw4nY3ACKboMIPZGt0,'VOD_UNKNOWN_GROUPED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'فيديوهات مجهولة مرتبة'+sLTw4nY3ACKboMIPZGt0,'VOD_UNKNOWN_GROUPED_SORTED',713,'','','','',aMovAWceF1G)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'إضافة وتغيير رابط'+sLTw4nY3ACKboMIPZGt0+' '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx],'',711,'','','','',{'folder':F8UNnjSZvpI,'sequence':rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx})
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'جلب ملفات'+sLTw4nY3ACKboMIPZGt0,'',712,'','','','',aMovAWceF1G)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'مسح ملفات'+sLTw4nY3ACKboMIPZGt0,'',717,'','','','',aMovAWceF1G)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'عدد فيديوهات'+sLTw4nY3ACKboMIPZGt0,'',721,'','','','',aMovAWceF1G)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'Referer تغيير'+sLTw4nY3ACKboMIPZGt0,'',726,'','','','',aMovAWceF1G)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'User-Agent تغيير'+sLTw4nY3ACKboMIPZGt0,'',723,'','','','',aMovAWceF1G)
	return
def jJxoMwaU9uXfk4t15E(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	pgeLK8q1sAzJPR0N3YUo2XmT,llnEaeYP0VNMOCFRUuz = False,''
	D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa = '',''
	pozR0wQJE3ysXtvkreW4c5iZuY1,vhs4dn1piy6k8,jYbXqdxFSt,EEVQZiJPxTfBHz5sU6o,a30UskZYQp8G = muLs1NBgpVJFAqoT(F8UNnjSZvpI)
	if EEVQZiJPxTfBHz5sU6o=='': return False,'',''
	jmdxulY90XbNQGP5vSfoz16h = DDuOmxZytwH5qf061M4PVnvI(F8UNnjSZvpI)
	if pozR0wQJE3ysXtvkreW4c5iZuY1:
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',pozR0wQJE3ysXtvkreW4c5iZuY1,'',jmdxulY90XbNQGP5vSfoz16h,False,'','M3U-CHECK_ACCOUNT-1st')
		j4iteqgCJdK6kaY = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
		if UlqnkuTN3EZWXMOyQ9fo2BjiS8h.succeeded:
			QyFHwaYuvPhz0Zs75GWLVfMr1,MgblhfDCFUHBpYzxdPKjcAkQ0G21,wbyBjNd2vaz6RAYVXtcxl4EqIe,F9apICTX7wDVJxolu8YkqR3g,hTLvBPWbtRY3q7zfQ6uxAGSpoH2al = 0,0,'','',''
			try:
				FhtaHD8T5kOQWKSey96ob = G8EwoDOyKShm1i0IHMfNYZlU7('dict',j4iteqgCJdK6kaY)
				llnEaeYP0VNMOCFRUuz = FhtaHD8T5kOQWKSey96ob['user_info']['status']
				pgeLK8q1sAzJPR0N3YUo2XmT = True
				wbyBjNd2vaz6RAYVXtcxl4EqIe = FhtaHD8T5kOQWKSey96ob['server_info']['time_now']
			except: pass
			if wbyBjNd2vaz6RAYVXtcxl4EqIe:
				try:
					NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG = Mrx2OeZV1LNjBsQ58Savi7.strptime(wbyBjNd2vaz6RAYVXtcxl4EqIe,'%Y.%m.%d %H:%M:%S')
					QyFHwaYuvPhz0Zs75GWLVfMr1 = int(Mrx2OeZV1LNjBsQ58Savi7.mktime(NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG))
					MgblhfDCFUHBpYzxdPKjcAkQ0G21 = int(uZ7xiFaBvSrWG2mXjITp-QyFHwaYuvPhz0Zs75GWLVfMr1)
					MgblhfDCFUHBpYzxdPKjcAkQ0G21 = int((MgblhfDCFUHBpYzxdPKjcAkQ0G21+900)/1800)*1800
				except: pass
				try:
					NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG = Mrx2OeZV1LNjBsQ58Savi7.localtime(int(FhtaHD8T5kOQWKSey96ob['user_info']['created_at']))
					F9apICTX7wDVJxolu8YkqR3g = Mrx2OeZV1LNjBsQ58Savi7.strftime('%Y.%m.%d %H:%M:%S',NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG)
				except: pass
				try:
					NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG = Mrx2OeZV1LNjBsQ58Savi7.localtime(int(FhtaHD8T5kOQWKSey96ob['user_info']['exp_date']))
					hTLvBPWbtRY3q7zfQ6uxAGSpoH2al = Mrx2OeZV1LNjBsQ58Savi7.strftime('%Y.%m.%d %H:%M:%S',NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG)
				except: pass
			BBwb2NzsHE.setSetting('av.m3u.timestamp_'+F8UNnjSZvpI,str(uZ7xiFaBvSrWG2mXjITp))
			BBwb2NzsHE.setSetting('av.m3u.timediff_'+F8UNnjSZvpI,str(MgblhfDCFUHBpYzxdPKjcAkQ0G21))
			try:
				QvwU0LGbzaoXrxqV6FjpEcfRhSt5 = '"server_info":'+j4iteqgCJdK6kaY.split('"server_info":')[1]
				QvwU0LGbzaoXrxqV6FjpEcfRhSt5 = QvwU0LGbzaoXrxqV6FjpEcfRhSt5.replace(':',': ').replace(',',', ').replace('}}','}')
				rrVcd0khDGx2IEM = JJDtX1PZyIgN2T.findall('"url": "(.*?)", "port": "(.*?)"',QvwU0LGbzaoXrxqV6FjpEcfRhSt5,JJDtX1PZyIgN2T.DOTALL)
				D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa = rrVcd0khDGx2IEM[0]
			except: pgeLK8q1sAzJPR0N3YUo2XmT = False
			if pgeLK8q1sAzJPR0N3YUo2XmT and Jjlf8RwAikOqePtvbW0IXudhF36Z:
				max = FhtaHD8T5kOQWKSey96ob['user_info']['max_connections']
				vKO4Acm3PCIl5 = FhtaHD8T5kOQWKSey96ob['user_info']['active_cons']
				UUfKpYGhzVENlekqQ130cWX627 = FhtaHD8T5kOQWKSey96ob['user_info']['is_trial']
				mrE4hqXz15e6JPGtHnvIY7gl2jwV3R = pozR0wQJE3ysXtvkreW4c5iZuY1.split('?',1)
				Ay3eLGaTncD67lx8ZOud = 'URL:  [COLOR FFC89008]'+pozR0wQJE3ysXtvkreW4c5iZuY1+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\n\nStatus:  '+'[COLOR FFC89008]'+llnEaeYP0VNMOCFRUuz+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\nTrial:    '+'[COLOR FFC89008]'+str(UUfKpYGhzVENlekqQ130cWX627=='1')+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\nCreated  At:  '+'[COLOR FFC89008]'+F9apICTX7wDVJxolu8YkqR3g+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\nExpiry Date:  '+'[COLOR FFC89008]'+hTLvBPWbtRY3q7zfQ6uxAGSpoH2al+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\nConnections   ( Active / Maximum ) :  '+'[COLOR FFC89008]'+vKO4Acm3PCIl5+' / '+max+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\nAllowed Outputs:   '+'[COLOR FFC89008]'+" , ".join(FhtaHD8T5kOQWKSey96ob['user_info']['allowed_output_formats'])+'[/COLOR]'
				Ay3eLGaTncD67lx8ZOud += '\n\n'+QvwU0LGbzaoXrxqV6FjpEcfRhSt5
				if llnEaeYP0VNMOCFRUuz=='Active': iTYQXEG9swpIWC('الاشتراك يعمل بدون مشاكل',Ay3eLGaTncD67lx8ZOud)
				else: iTYQXEG9swpIWC('يبدو أن هناك مشكلة في الاشتراك',Ay3eLGaTncD67lx8ZOud)
	if pozR0wQJE3ysXtvkreW4c5iZuY1 and pgeLK8q1sAzJPR0N3YUo2XmT and llnEaeYP0VNMOCFRUuz=='Active':
		b6kj4LJ5tzTeOMQi('NOTICE','.  Checking M3U URL   [ M3U account is OK ]   [ '+pozR0wQJE3ysXtvkreW4c5iZuY1+' ]')
		dnD6ZJOtXsEGPhk3gH = True
	else:
		b6kj4LJ5tzTeOMQi('ERROR_LINES','Checking M3U URL   [ Does not work ]   [ '+pozR0wQJE3ysXtvkreW4c5iZuY1+' ]')
		if Jjlf8RwAikOqePtvbW0IXudhF36Z: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		dnD6ZJOtXsEGPhk3gH = False
	return dnD6ZJOtXsEGPhk3gH,D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa
def egYaAP6oIWDjfzqX20HnKS(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte,RxJhvUaYic6oIsHrfnt8Dm,YDqRFgKxH7J0,Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	if not YDqRFgKxH7J0: YDqRFgKxH7J0 = '1'
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z): return
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte)
	buLCgJMpUIA3rO56kaicRBTGq90 = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list',qqp1v0DYyPONaiu7VEte,RxJhvUaYic6oIsHrfnt8Dm)
	WMnq8haXrLtVEiFjb9SlxU = int(YDqRFgKxH7J0)*100
	BpgkdX0xaJO9EzS2K5T1GP = WMnq8haXrLtVEiFjb9SlxU-100
	for fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL in buLCgJMpUIA3rO56kaicRBTGq90[BpgkdX0xaJO9EzS2K5T1GP:WMnq8haXrLtVEiFjb9SlxU]:
		vvUyK4qrOIYt = ('GROUPED' in qqp1v0DYyPONaiu7VEte or qqp1v0DYyPONaiu7VEte=='ALL')
		SsTqIUzKMy6Jgw2lF = ('GROUPED' not in qqp1v0DYyPONaiu7VEte and qqp1v0DYyPONaiu7VEte!='ALL')
		if vvUyK4qrOIYt or SsTqIUzKMy6Jgw2lF:
			if   'ARCHIVED'  in qqp1v0DYyPONaiu7VEte: PL2fM9WhpjEFb7.append(['folder',t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,718,st9uk8gcDL,'','ARCHIVED','',{'folder':F8UNnjSZvpI}])
			elif 'EPG' 		 in qqp1v0DYyPONaiu7VEte: PL2fM9WhpjEFb7.append(['folder',t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,718,st9uk8gcDL,'','FULL_EPG','',{'folder':F8UNnjSZvpI}])
			elif 'TIMESHIFT' in qqp1v0DYyPONaiu7VEte: PL2fM9WhpjEFb7.append(['folder',t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,718,st9uk8gcDL,'','TIMESHIFT','',{'folder':F8UNnjSZvpI}])
			elif 'LIVE' 	 in qqp1v0DYyPONaiu7VEte: PL2fM9WhpjEFb7.append(['live',t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,715,st9uk8gcDL,'','',fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,{'folder':F8UNnjSZvpI}])
			else: PL2fM9WhpjEFb7.append(['video',t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,715,st9uk8gcDL,'','','',{'folder':F8UNnjSZvpI}])
	ICUfvdYPXcFDGs3g6jmktAW9 = len(buLCgJMpUIA3rO56kaicRBTGq90)
	eqg21COva5Ew3Fs4(F8UNnjSZvpI,YDqRFgKxH7J0,qqp1v0DYyPONaiu7VEte,714,ICUfvdYPXcFDGs3g6jmktAW9,RxJhvUaYic6oIsHrfnt8Dm)
	return
def gnRlcDIEW4qQKm(Wu2e0tPvrCo36Rn7US):
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',Wu2e0tPvrCo36Rn7US+'هذه القائمة إما فارغة أو غير موجودة','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',Wu2e0tPvrCo36Rn7US+'أو الخدمة غير موجودة في اشتراكك','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',Wu2e0tPvrCo36Rn7US+'أو رابط M3U الذي أنت أضفته غير صحيح','',9999)
	return
def OUjyxPoiSLT6(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte,RxJhvUaYic6oIsHrfnt8Dm,YDqRFgKxH7J0,RKUbZsCtw48GxHf5lN='',Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	if not YDqRFgKxH7J0: YDqRFgKxH7J0 = '1'
	Wu2e0tPvrCo36Rn7US = t8SVWInB3P7
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z): return False
	if '__SERIES__' in RxJhvUaYic6oIsHrfnt8Dm: hm2G5gIsQOzj6U4bCc9qB7,zX2KlFdwY16kagSiCyHO = RxJhvUaYic6oIsHrfnt8Dm.split('__SERIES__')
	else: hm2G5gIsQOzj6U4bCc9qB7,zX2KlFdwY16kagSiCyHO = RxJhvUaYic6oIsHrfnt8Dm,''
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte)
	mLUI3MoXa65pNf = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list',qqp1v0DYyPONaiu7VEte,'__GROUPS__')
	if not mLUI3MoXa65pNf: return False
	An0EO3NHCJdrFKTvpPfymDt64Ms = []
	for Duty5SzAherY3mXvZ,st9uk8gcDL in mLUI3MoXa65pNf:
		if '===== ===== =====' in Duty5SzAherY3mXvZ:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',Wu2e0tPvrCo36Rn7US+Duty5SzAherY3mXvZ,'',9999)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',Wu2e0tPvrCo36Rn7US+Duty5SzAherY3mXvZ,'',9999)
			continue
		if RKUbZsCtw48GxHf5lN:
			if '__SERIES__' in Duty5SzAherY3mXvZ: Wu2e0tPvrCo36Rn7US = 'SERIES'
			elif '!!__UNKNOWN__!!' in Duty5SzAherY3mXvZ: Wu2e0tPvrCo36Rn7US = 'UNKNOWN'
			elif 'LIVE' in qqp1v0DYyPONaiu7VEte: Wu2e0tPvrCo36Rn7US = 'LIVE'
			else: Wu2e0tPvrCo36Rn7US = 'VIDEOS'
			Wu2e0tPvrCo36Rn7US = ',[COLOR FFC89008]'+Wu2e0tPvrCo36Rn7US+': [/COLOR]'
		if '__SERIES__' in Duty5SzAherY3mXvZ: MpwmZOqiC8e4XPUoVQnIWBatKyu,oShjnYfiZO6zL7MVwl = Duty5SzAherY3mXvZ.split('__SERIES__')
		else: MpwmZOqiC8e4XPUoVQnIWBatKyu,oShjnYfiZO6zL7MVwl = Duty5SzAherY3mXvZ,''
		if not RxJhvUaYic6oIsHrfnt8Dm:
			if MpwmZOqiC8e4XPUoVQnIWBatKyu in An0EO3NHCJdrFKTvpPfymDt64Ms: continue
			An0EO3NHCJdrFKTvpPfymDt64Ms.append(MpwmZOqiC8e4XPUoVQnIWBatKyu)
			if 'RANDOM' in RKUbZsCtw48GxHf5lN: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',Wu2e0tPvrCo36Rn7US+MpwmZOqiC8e4XPUoVQnIWBatKyu,qqp1v0DYyPONaiu7VEte,168,'','1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
			elif '__SERIES__' in Duty5SzAherY3mXvZ: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',Wu2e0tPvrCo36Rn7US+MpwmZOqiC8e4XPUoVQnIWBatKyu,qqp1v0DYyPONaiu7VEte,713,'','1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',Wu2e0tPvrCo36Rn7US+MpwmZOqiC8e4XPUoVQnIWBatKyu,qqp1v0DYyPONaiu7VEte,714,'','1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
		elif '__SERIES__' in Duty5SzAherY3mXvZ and MpwmZOqiC8e4XPUoVQnIWBatKyu==hm2G5gIsQOzj6U4bCc9qB7:
			if oShjnYfiZO6zL7MVwl in An0EO3NHCJdrFKTvpPfymDt64Ms: continue
			An0EO3NHCJdrFKTvpPfymDt64Ms.append(oShjnYfiZO6zL7MVwl)
			if 'RANDOM' in RKUbZsCtw48GxHf5lN: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',Wu2e0tPvrCo36Rn7US+oShjnYfiZO6zL7MVwl,qqp1v0DYyPONaiu7VEte,168,'','1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',Wu2e0tPvrCo36Rn7US+oShjnYfiZO6zL7MVwl,qqp1v0DYyPONaiu7VEte,714,st9uk8gcDL,'1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
	PL2fM9WhpjEFb7[:] = sorted(PL2fM9WhpjEFb7,reverse=False,key=lambda FUAvmM61BHoYRKeGsTwrXC4qlZP: FUAvmM61BHoYRKeGsTwrXC4qlZP[1].lower())
	if not RKUbZsCtw48GxHf5lN:
		WMnq8haXrLtVEiFjb9SlxU = int(YDqRFgKxH7J0)*100
		BpgkdX0xaJO9EzS2K5T1GP = WMnq8haXrLtVEiFjb9SlxU-100
		ICUfvdYPXcFDGs3g6jmktAW9 = len(PL2fM9WhpjEFb7)
		PL2fM9WhpjEFb7[:] = PL2fM9WhpjEFb7[BpgkdX0xaJO9EzS2K5T1GP:WMnq8haXrLtVEiFjb9SlxU]
		eqg21COva5Ew3Fs4(F8UNnjSZvpI,YDqRFgKxH7J0,qqp1v0DYyPONaiu7VEte,713,ICUfvdYPXcFDGs3g6jmktAW9,RxJhvUaYic6oIsHrfnt8Dm)
	return True
def eIURObW5jtDa(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,m7mqGXRztoyNlUf5WbHOMkvp):
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,True): return
	jmdxulY90XbNQGP5vSfoz16h = DDuOmxZytwH5qf061M4PVnvI(F8UNnjSZvpI)
	QyFHwaYuvPhz0Zs75GWLVfMr1 = BBwb2NzsHE.getSetting('av.m3u.timestamp_'+F8UNnjSZvpI)
	if not QyFHwaYuvPhz0Zs75GWLVfMr1 or uZ7xiFaBvSrWG2mXjITp-int(QyFHwaYuvPhz0Zs75GWLVfMr1)>24*sseNwgOx0mZkuoQX:
		dnD6ZJOtXsEGPhk3gH,D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa = jJxoMwaU9uXfk4t15E(F8UNnjSZvpI,False)
		if not dnD6ZJOtXsEGPhk3gH: return
	MgblhfDCFUHBpYzxdPKjcAkQ0G21 = int(BBwb2NzsHE.getSetting('av.m3u.timediff_'+F8UNnjSZvpI))
	jYbXqdxFSt = BBwb2NzsHE.getSetting('av.m3u.server_'+F8UNnjSZvpI)
	EEVQZiJPxTfBHz5sU6o = BBwb2NzsHE.getSetting('av.m3u.username_'+F8UNnjSZvpI)
	a30UskZYQp8G = BBwb2NzsHE.getSetting('av.m3u.password_'+F8UNnjSZvpI)
	A3iznrE8Y2NjdQUVlt9efbS = apIVksn1FTuj6rbYhMPDLHS9N.split('/')
	gA9jmYCLitB2oDaT = A3iznrE8Y2NjdQUVlt9efbS[-1].replace('.ts','').replace('.m3u8','')
	if m7mqGXRztoyNlUf5WbHOMkvp=='SHORT_EPG': HQLdPcx6u7gsyvzfRK5SBMZ = 'get_short_epg'
	else: HQLdPcx6u7gsyvzfRK5SBMZ = 'get_simple_data_table'
	pozR0wQJE3ysXtvkreW4c5iZuY1,vhs4dn1piy6k8,jYbXqdxFSt,EEVQZiJPxTfBHz5sU6o,a30UskZYQp8G = muLs1NBgpVJFAqoT(F8UNnjSZvpI)
	if not EEVQZiJPxTfBHz5sU6o: return
	eeaxDI2YVP5XrTcltHhKvgQuA = pozR0wQJE3ysXtvkreW4c5iZuY1+'&action='+HQLdPcx6u7gsyvzfRK5SBMZ+'&stream_id='+gA9jmYCLitB2oDaT
	j4iteqgCJdK6kaY = C7vQYqP6RdyUZiJXprGsx2maM0(jCJnzmXDkNqtB,eeaxDI2YVP5XrTcltHhKvgQuA,'',jmdxulY90XbNQGP5vSfoz16h,'','M3U-EPG_ITEMS-2nd')
	PfrHDqel9Y = G8EwoDOyKShm1i0IHMfNYZlU7('dict',j4iteqgCJdK6kaY)
	iDkpTZUVqBXfbG = PfrHDqel9Y['epg_listings']
	dvwjITnNH2ogKFW = []
	if m7mqGXRztoyNlUf5WbHOMkvp in ['ARCHIVED','TIMESHIFT']:
		for FhtaHD8T5kOQWKSey96ob in iDkpTZUVqBXfbG:
			if FhtaHD8T5kOQWKSey96ob['has_archive']==1:
				dvwjITnNH2ogKFW.append(FhtaHD8T5kOQWKSey96ob)
				if m7mqGXRztoyNlUf5WbHOMkvp in ['TIMESHIFT']: break
		if not dvwjITnNH2ogKFW: return
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]','',9999)
		if m7mqGXRztoyNlUf5WbHOMkvp in ['TIMESHIFT']:
			Sg4KCm6QUcsk = 2
			XgfjhAZs2BkiouWweC0Yy = Sg4KCm6QUcsk*sseNwgOx0mZkuoQX
			dvwjITnNH2ogKFW = []
			NArQKtfn3p5hJzl14Mi02CFuxTY = int(int(FhtaHD8T5kOQWKSey96ob['start_timestamp'])/XgfjhAZs2BkiouWweC0Yy)*XgfjhAZs2BkiouWweC0Yy
			IuAzsmx64V9CNkqBM0ncJhj3LHg = uZ7xiFaBvSrWG2mXjITp+XgfjhAZs2BkiouWweC0Yy
			S4QtBI0gGTj8mRyLOsYPE6wu3Zvd = int((IuAzsmx64V9CNkqBM0ncJhj3LHg-NArQKtfn3p5hJzl14Mi02CFuxTY)/sseNwgOx0mZkuoQX)
			for LFuTwUYZScbJ6esjC9B in range(S4QtBI0gGTj8mRyLOsYPE6wu3Zvd):
				if LFuTwUYZScbJ6esjC9B>=6:
					if LFuTwUYZScbJ6esjC9B%Sg4KCm6QUcsk!=0: continue
					sTfGhkerj5bH8UAJCywSaonL2m = XgfjhAZs2BkiouWweC0Yy
				else: sTfGhkerj5bH8UAJCywSaonL2m = XgfjhAZs2BkiouWweC0Yy//2
				caE7iOuL6tdrq2IWYjvyTbH3sxZ = NArQKtfn3p5hJzl14Mi02CFuxTY+LFuTwUYZScbJ6esjC9B*sseNwgOx0mZkuoQX
				FhtaHD8T5kOQWKSey96ob = {}
				FhtaHD8T5kOQWKSey96ob['title'] = ''
				NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG = Mrx2OeZV1LNjBsQ58Savi7.localtime(caE7iOuL6tdrq2IWYjvyTbH3sxZ-MgblhfDCFUHBpYzxdPKjcAkQ0G21-sseNwgOx0mZkuoQX)
				FhtaHD8T5kOQWKSey96ob['start'] = Mrx2OeZV1LNjBsQ58Savi7.strftime('%Y.%m.%d %H:%M:%S',NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG)
				FhtaHD8T5kOQWKSey96ob['start_timestamp'] = str(caE7iOuL6tdrq2IWYjvyTbH3sxZ)
				FhtaHD8T5kOQWKSey96ob['stop_timestamp'] = str(caE7iOuL6tdrq2IWYjvyTbH3sxZ+sTfGhkerj5bH8UAJCywSaonL2m)
				dvwjITnNH2ogKFW.append(FhtaHD8T5kOQWKSey96ob)
	elif m7mqGXRztoyNlUf5WbHOMkvp in ['SHORT_EPG','FULL_EPG']: dvwjITnNH2ogKFW = iDkpTZUVqBXfbG
	if m7mqGXRztoyNlUf5WbHOMkvp=='FULL_EPG' and len(dvwjITnNH2ogKFW)>0:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]','',9999)
	GLDZqP1wz2V3xmXSbyhviKUt = []
	st9uk8gcDL = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Icon')
	for FhtaHD8T5kOQWKSey96ob in dvwjITnNH2ogKFW:
		UfHDlNvZCp = gPSZVjJHKIL.b64decode(FhtaHD8T5kOQWKSey96ob['title'])
		if DQfHadYvTpy1UR: UfHDlNvZCp = UfHDlNvZCp.decode('utf8')
		caE7iOuL6tdrq2IWYjvyTbH3sxZ = int(FhtaHD8T5kOQWKSey96ob['start_timestamp'])
		R1BgL7ZMNDYeET = int(FhtaHD8T5kOQWKSey96ob['stop_timestamp'])
		bYrXcUAJGlEyhDpxtqaOeL6Ru = str(int((R1BgL7ZMNDYeET-caE7iOuL6tdrq2IWYjvyTbH3sxZ+59)/60))
		RKtvul3oy4CIzF7V5Q96 = FhtaHD8T5kOQWKSey96ob['start'].replace(' ',':')
		NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG = Mrx2OeZV1LNjBsQ58Savi7.localtime(caE7iOuL6tdrq2IWYjvyTbH3sxZ-sseNwgOx0mZkuoQX)
		kqeFjLx51QSBi27TpCs4IlA9OMEn = Mrx2OeZV1LNjBsQ58Savi7.strftime('%H:%M',NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG)
		g5RDQVOybr7TdiwpY6q8JBSsF = Mrx2OeZV1LNjBsQ58Savi7.strftime('%a',NVsUrmMBE3vLpAwnq9zCd8ahtiu2oG)
		if m7mqGXRztoyNlUf5WbHOMkvp=='SHORT_EPG': UfHDlNvZCp = '[COLOR FFFFFF00]'+kqeFjLx51QSBi27TpCs4IlA9OMEn+' ـ '+UfHDlNvZCp+'[/COLOR]'
		elif m7mqGXRztoyNlUf5WbHOMkvp=='TIMESHIFT': UfHDlNvZCp = g5RDQVOybr7TdiwpY6q8JBSsF+' '+kqeFjLx51QSBi27TpCs4IlA9OMEn+' ('+bYrXcUAJGlEyhDpxtqaOeL6Ru+'min)'
		else: UfHDlNvZCp = g5RDQVOybr7TdiwpY6q8JBSsF+' '+kqeFjLx51QSBi27TpCs4IlA9OMEn+' ('+bYrXcUAJGlEyhDpxtqaOeL6Ru+'min)   '+UfHDlNvZCp+' ـ'
		if m7mqGXRztoyNlUf5WbHOMkvp in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			E86iulXIVZFJDMW4LnvCR = jYbXqdxFSt+'/timeshift/'+EEVQZiJPxTfBHz5sU6o+'/'+a30UskZYQp8G+'/'+bYrXcUAJGlEyhDpxtqaOeL6Ru+'/'+RKtvul3oy4CIzF7V5Q96+'/'+gA9jmYCLitB2oDaT+'.m3u8'
			if m7mqGXRztoyNlUf5WbHOMkvp=='FULL_EPG': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',t8SVWInB3P7+UfHDlNvZCp,E86iulXIVZFJDMW4LnvCR,9999,st9uk8gcDL,'','','',{'folder':F8UNnjSZvpI})
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',t8SVWInB3P7+UfHDlNvZCp,E86iulXIVZFJDMW4LnvCR,715,st9uk8gcDL,'','','',{'folder':F8UNnjSZvpI})
		GLDZqP1wz2V3xmXSbyhviKUt.append(UfHDlNvZCp)
	if m7mqGXRztoyNlUf5WbHOMkvp=='SHORT_EPG' and GLDZqP1wz2V3xmXSbyhviKUt: ZPgvai3UtdIHEFeofRwNL = nnd9gykLENea43cI2rZM(GLDZqP1wz2V3xmXSbyhviKUt)
	return GLDZqP1wz2V3xmXSbyhviKUt
def nkOmvZhb0H4auFxT5of7pSXQMtc(F8UNnjSZvpI):
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,True): return
	jYbXqdxFSt,EQ8iHyWpaXV7beUs0MG1zk,DXudMsoGBirILNYKOShRqme5PaZ8 = '',0,0
	dnD6ZJOtXsEGPhk3gH,D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa = jJxoMwaU9uXfk4t15E(F8UNnjSZvpI,False)
	if dnD6ZJOtXsEGPhk3gH:
		ulqJksP7IfzvFphSM = vI2HqhrFbX8sRkDC(D5wzIoVxnu8RX4OCl)
		EQ8iHyWpaXV7beUs0MG1zk = T1kimOBuXJDxZFpzH8tUdjnGo9rN(ulqJksP7IfzvFphSM[0],int(DCSd54AeZyf3HoQFB7uOa))
		GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'LIVE_GROUPED')
		IOYAmcp4VlJbEUGfuzwdisBPK = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list','LIVE_GROUPED')
		buLCgJMpUIA3rO56kaicRBTGq90 = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list','LIVE_GROUPED',IOYAmcp4VlJbEUGfuzwdisBPK[1])
		apIVksn1FTuj6rbYhMPDLHS9N = buLCgJMpUIA3rO56kaicRBTGq90[0][2]
		KCokPId37EZO6gmMzrljG = JJDtX1PZyIgN2T.findall('://(.*?)/',apIVksn1FTuj6rbYhMPDLHS9N,JJDtX1PZyIgN2T.DOTALL)
		KCokPId37EZO6gmMzrljG = KCokPId37EZO6gmMzrljG[0]
		if ':' in KCokPId37EZO6gmMzrljG: hiSYxtUk46ZTE1lQ8DINAHoBsbe,PeaNcVxS9GkD6q2nUX3lbdZB = KCokPId37EZO6gmMzrljG.split(':')
		else: hiSYxtUk46ZTE1lQ8DINAHoBsbe,PeaNcVxS9GkD6q2nUX3lbdZB = KCokPId37EZO6gmMzrljG,'80'
		YbX9sVp5h7iTDogmSP18fxWItzcZ = vI2HqhrFbX8sRkDC(hiSYxtUk46ZTE1lQ8DINAHoBsbe)
		DXudMsoGBirILNYKOShRqme5PaZ8 = T1kimOBuXJDxZFpzH8tUdjnGo9rN(YbX9sVp5h7iTDogmSP18fxWItzcZ[0],int(PeaNcVxS9GkD6q2nUX3lbdZB))
	if EQ8iHyWpaXV7beUs0MG1zk and DXudMsoGBirILNYKOShRqme5PaZ8:
		Ay3eLGaTncD67lx8ZOud = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		Ay3eLGaTncD67lx8ZOud += '\n\n'+'وقت ضائع في السيرفر الأصلي'+'\n'+str(int(DXudMsoGBirILNYKOShRqme5PaZ8*1000))+' ملي ثانية'
		Ay3eLGaTncD67lx8ZOud += '\n\n'+'وقت ضائع في السيرفر البديل'+'\n'+str(int(EQ8iHyWpaXV7beUs0MG1zk*1000))+' ملي ثانية'
		z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',Ay3eLGaTncD67lx8ZOud)
		if z3rhpEtd7KLGQZ64XonmW19HSJfAc==1 and EQ8iHyWpaXV7beUs0MG1zk<DXudMsoGBirILNYKOShRqme5PaZ8: jYbXqdxFSt = D5wzIoVxnu8RX4OCl+':'+DCSd54AeZyf3HoQFB7uOa
	else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	BBwb2NzsHE.setSetting('av.m3u.server_'+F8UNnjSZvpI,jYbXqdxFSt)
	return
def CsUdRabWuh0M9F(F8UNnjSZvpI,apIVksn1FTuj6rbYhMPDLHS9N,GGKpqhAcPw9FHBvdfarRuySJ1Yl):
	KmP7jBGwEc3f0HvkO = BBwb2NzsHE.getSetting('av.m3u.useragent_'+F8UNnjSZvpI)
	g268gDeMJbqUBc0lV4PZup5zvGQaj = BBwb2NzsHE.getSetting('av.m3u.referer_'+F8UNnjSZvpI)
	if KmP7jBGwEc3f0HvkO or g268gDeMJbqUBc0lV4PZup5zvGQaj:
		apIVksn1FTuj6rbYhMPDLHS9N += '|'
		if KmP7jBGwEc3f0HvkO: apIVksn1FTuj6rbYhMPDLHS9N += '&User-Agent='+KmP7jBGwEc3f0HvkO
		if g268gDeMJbqUBc0lV4PZup5zvGQaj: apIVksn1FTuj6rbYhMPDLHS9N += '&Referer='+g268gDeMJbqUBc0lV4PZup5zvGQaj
		apIVksn1FTuj6rbYhMPDLHS9N = apIVksn1FTuj6rbYhMPDLHS9N.replace('|&','|')
	XbzQHGJ0cBV(apIVksn1FTuj6rbYhMPDLHS9N,s1ITpY2ghtCvR3mSXkFVBnlL8,GGKpqhAcPw9FHBvdfarRuySJ1Yl)
	return
def bl0HXeJysOT7qNL8zVZ(F8UNnjSZvpI):
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	KmP7jBGwEc3f0HvkO = BBwb2NzsHE.getSetting('av.m3u.useragent_'+F8UNnjSZvpI)
	Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','استخدام الأصلي','تعديل القديم',KmP7jBGwEc3f0HvkO,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if Xz4qp8m6f3NWx9dFt==1: KmP7jBGwEc3f0HvkO = GVfnMyZxiRI('أكتب ـM3U User-Agent جديد',KmP7jBGwEc3f0HvkO,True)
	else: KmP7jBGwEc3f0HvkO = 'Unknown'
	if KmP7jBGwEc3f0HvkO==' ':
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','','',KmP7jBGwEc3f0HvkO,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if Xz4qp8m6f3NWx9dFt!=1:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم الإلغاء')
		return
	BBwb2NzsHE.setSetting('av.m3u.useragent_'+F8UNnjSZvpI,KmP7jBGwEc3f0HvkO)
	LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI)
	return
def D7bspBFdjYOCc(F8UNnjSZvpI):
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	g268gDeMJbqUBc0lV4PZup5zvGQaj = BBwb2NzsHE.getSetting('av.m3u.referer_'+F8UNnjSZvpI)
	Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','استخدام الأصلي','تعديل القديم',g268gDeMJbqUBc0lV4PZup5zvGQaj,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if Xz4qp8m6f3NWx9dFt==1: g268gDeMJbqUBc0lV4PZup5zvGQaj = GVfnMyZxiRI('أكتب ـM3U Referer جديد',g268gDeMJbqUBc0lV4PZup5zvGQaj,True)
	else: g268gDeMJbqUBc0lV4PZup5zvGQaj = ''
	if g268gDeMJbqUBc0lV4PZup5zvGQaj==' ':
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','','',g268gDeMJbqUBc0lV4PZup5zvGQaj,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if Xz4qp8m6f3NWx9dFt!=1:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم الإلغاء')
		return
	BBwb2NzsHE.setSetting('av.m3u.referer_'+F8UNnjSZvpI,g268gDeMJbqUBc0lV4PZup5zvGQaj)
	LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI)
	return
def muLs1NBgpVJFAqoT(F8UNnjSZvpI,fF4XSj6IsqpYT1OykKclr3C2=''):
	if not DyPvJk69SndIUfr3AMatLcB: DyPvJk69SndIUfr3AMatLcB = BBwb2NzsHE.getSetting('av.m3u.url_'+F8UNnjSZvpI)
	jYbXqdxFSt = OfTKisDR0Lv(DyPvJk69SndIUfr3AMatLcB,'url')
	EEVQZiJPxTfBHz5sU6o = JJDtX1PZyIgN2T.findall('username=(.*?)&',DyPvJk69SndIUfr3AMatLcB+'&',JJDtX1PZyIgN2T.DOTALL)
	a30UskZYQp8G = JJDtX1PZyIgN2T.findall('password=(.*?)&',DyPvJk69SndIUfr3AMatLcB+'&',JJDtX1PZyIgN2T.DOTALL)
	if not EEVQZiJPxTfBHz5sU6o or not a30UskZYQp8G:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return '','','','',''
	EEVQZiJPxTfBHz5sU6o = EEVQZiJPxTfBHz5sU6o[0]
	a30UskZYQp8G = a30UskZYQp8G[0]
	pozR0wQJE3ysXtvkreW4c5iZuY1 = jYbXqdxFSt+'/player_api.php?username='+EEVQZiJPxTfBHz5sU6o+'&password='+a30UskZYQp8G
	vhs4dn1piy6k8 = jYbXqdxFSt+'/get.php?username='+EEVQZiJPxTfBHz5sU6o+'&password='+a30UskZYQp8G+'&type=m3u_plus'
	return pozR0wQJE3ysXtvkreW4c5iZuY1,vhs4dn1piy6k8,jYbXqdxFSt,EEVQZiJPxTfBHz5sU6o,a30UskZYQp8G
def mgfKDXvqxe(F8UNnjSZvpI,BzoupqlePmISnMK7AgH29sGa=''):
	YoA7KjgekuVhlnP2y5 = BzoupqlePmISnMK7AgH29sGa.replace('/','_').replace(':','_').replace('.','_')
	YoA7KjgekuVhlnP2y5 = YoA7KjgekuVhlnP2y5.replace('?','_').replace('=','_').replace('&','_')
	YoA7KjgekuVhlnP2y5 = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,YoA7KjgekuVhlnP2y5).strip('.m3u')+'.m3u'
	return YoA7KjgekuVhlnP2y5
def WS7HwIGFXRNKVfQsiMZLtCO5(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6):
	yZPUQXm2LSvgbNK = BBwb2NzsHE.getSetting('av.m3u.url_'+F8UNnjSZvpI+'_'+qpB7IC2ViZ9a4sDtlbTOdv6)
	v1vhoKIe9j4 = True
	if yZPUQXm2LSvgbNK:
		Xz4qp8m6f3NWx9dFt = VYEiZteQcrT7aqOBMRAyHC9('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:','[COLOR FFC89008]'+yZPUQXm2LSvgbNK+'[/COLOR]'+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if Xz4qp8m6f3NWx9dFt==-1: return
		elif Xz4qp8m6f3NWx9dFt==0: yZPUQXm2LSvgbNK = ''
		elif Xz4qp8m6f3NWx9dFt==2:
			Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','','','رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if Xz4qp8m6f3NWx9dFt in [-1,0]: return
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم مسح الرابط')
			v1vhoKIe9j4 = False
			WyR1aBA59kE = ''
	if v1vhoKIe9j4:
		WyR1aBA59kE = GVfnMyZxiRI('اكتب رابط M3U كاملا',yZPUQXm2LSvgbNK)
		WyR1aBA59kE = WyR1aBA59kE.strip(' ')
		if not WyR1aBA59kE:
			Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('center','','','رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if Xz4qp8m6f3NWx9dFt in [-1,0]: return
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم مسح الرابط')
		else:
			Ay3eLGaTncD67lx8ZOud = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			Xz4qp8m6f3NWx9dFt = MMTfC8jWkbhxp2BDt('','','','الرابط الجديد هو:','[COLOR FFC89008]'+WyR1aBA59kE+'[/COLOR]'+'\n\n'+Ay3eLGaTncD67lx8ZOud)
			if Xz4qp8m6f3NWx9dFt!=1:
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم الإلغاء')
				return
	BBwb2NzsHE.setSetting('av.m3u.url_'+F8UNnjSZvpI+'_'+qpB7IC2ViZ9a4sDtlbTOdv6,WyR1aBA59kE)
	KmP7jBGwEc3f0HvkO = BBwb2NzsHE.getSetting('av.m3u.useragent_'+F8UNnjSZvpI)
	if not KmP7jBGwEc3f0HvkO: BBwb2NzsHE.setSetting('av.m3u.useragent_'+F8UNnjSZvpI,'Unknown')
	LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI)
	return
def lgokIvjshuey10zRdPY6GrJ7aFZ(ADoPKcJrFuZi,kHzJN8p6GIWZ,Wijm7pdUTSBuXLQ9ZCb4Mcr0fye,ttr9RZhTxXg5,tgrzum407Ewl,ljCiyDcov8N0kZeS,vhs4dn1piy6k8):
	buLCgJMpUIA3rO56kaicRBTGq90,LLkse1rfM7Unothv0Vi3la8 = [],[]
	yZgYLXdGjV5R7uSABHem = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		if ljCiyDcov8N0kZeS%473==0:
			VspYz0aKeZL7uXOI(ttr9RZhTxXg5,40+int(10*ljCiyDcov8N0kZeS/tgrzum407Ewl),'قراءة الفيديوهات','الفيديو رقم:-',str(ljCiyDcov8N0kZeS)+' / '+str(tgrzum407Ewl))
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return None,None,None
		apIVksn1FTuj6rbYhMPDLHS9N = JJDtX1PZyIgN2T.findall('^(.*?)\n+((http|https|rtmp).*?)$',D5wxHF2QT6bdzhuyl,JJDtX1PZyIgN2T.DOTALL)
		if apIVksn1FTuj6rbYhMPDLHS9N:
			D5wxHF2QT6bdzhuyl,apIVksn1FTuj6rbYhMPDLHS9N,DfJA7kUuMTpHtxLe0EqOczG5In = apIVksn1FTuj6rbYhMPDLHS9N[0]
			apIVksn1FTuj6rbYhMPDLHS9N = apIVksn1FTuj6rbYhMPDLHS9N.replace('\n','')
			D5wxHF2QT6bdzhuyl = D5wxHF2QT6bdzhuyl.replace('\n','')
		else:
			LLkse1rfM7Unothv0Vi3la8.append({'line':D5wxHF2QT6bdzhuyl})
			continue
		in8BOotyvMKbcSjGsrP,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,Duty5SzAherY3mXvZ,UfHDlNvZCp,GGKpqhAcPw9FHBvdfarRuySJ1Yl,WlO3j14yzTrY2ispE = {},'','','','',False
		try:
			D5wxHF2QT6bdzhuyl,UfHDlNvZCp = D5wxHF2QT6bdzhuyl.rsplit('",',1)
			D5wxHF2QT6bdzhuyl = D5wxHF2QT6bdzhuyl+'"'
		except:
			try: D5wxHF2QT6bdzhuyl,UfHDlNvZCp = D5wxHF2QT6bdzhuyl.rsplit('1,',1)
			except: UfHDlNvZCp = ''
		in8BOotyvMKbcSjGsrP['url'] = apIVksn1FTuj6rbYhMPDLHS9N
		B6FpLNn8oRhS4ql = JJDtX1PZyIgN2T.findall(' (.*?)="(.*?)"',D5wxHF2QT6bdzhuyl,JJDtX1PZyIgN2T.DOTALL)
		for FUAvmM61BHoYRKeGsTwrXC4qlZP,igAjXwvGcJfpYLVHZRmBtlW3DxOb62 in B6FpLNn8oRhS4ql:
			FUAvmM61BHoYRKeGsTwrXC4qlZP = FUAvmM61BHoYRKeGsTwrXC4qlZP.replace('"','').strip(' ')
			in8BOotyvMKbcSjGsrP[FUAvmM61BHoYRKeGsTwrXC4qlZP] = igAjXwvGcJfpYLVHZRmBtlW3DxOb62.strip(' ')
		SSWTV1gF57k = list(in8BOotyvMKbcSjGsrP.keys())
		if not UfHDlNvZCp:
			if 'name' in SSWTV1gF57k and in8BOotyvMKbcSjGsrP['name']: UfHDlNvZCp = in8BOotyvMKbcSjGsrP['name']
		in8BOotyvMKbcSjGsrP['title'] = UfHDlNvZCp.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'logo' in SSWTV1gF57k:
			in8BOotyvMKbcSjGsrP['img'] = in8BOotyvMKbcSjGsrP['logo']
			del in8BOotyvMKbcSjGsrP['logo']
		else: in8BOotyvMKbcSjGsrP['img'] = ''
		if 'group' in SSWTV1gF57k and in8BOotyvMKbcSjGsrP['group']: Duty5SzAherY3mXvZ = in8BOotyvMKbcSjGsrP['group']
		if any(Y3YqSmycrIWksoH5N0MvC in apIVksn1FTuj6rbYhMPDLHS9N.lower() for Y3YqSmycrIWksoH5N0MvC in yZgYLXdGjV5R7uSABHem):
			WlO3j14yzTrY2ispE = True if 'm3u' not in apIVksn1FTuj6rbYhMPDLHS9N else False
		if WlO3j14yzTrY2ispE or '__SERIES__' in Duty5SzAherY3mXvZ or '__MOVIES__' in Duty5SzAherY3mXvZ:
			GGKpqhAcPw9FHBvdfarRuySJ1Yl = 'VOD'
			if '__SERIES__' in Duty5SzAherY3mXvZ: GGKpqhAcPw9FHBvdfarRuySJ1Yl = GGKpqhAcPw9FHBvdfarRuySJ1Yl+'_SERIES'
			elif '__MOVIES__' in Duty5SzAherY3mXvZ: GGKpqhAcPw9FHBvdfarRuySJ1Yl = GGKpqhAcPw9FHBvdfarRuySJ1Yl+'_MOVIES'
			else: GGKpqhAcPw9FHBvdfarRuySJ1Yl = GGKpqhAcPw9FHBvdfarRuySJ1Yl+'_UNKNOWN'
			Duty5SzAherY3mXvZ = Duty5SzAherY3mXvZ.replace('__SERIES__','').replace('__MOVIES__','')
		else:
			GGKpqhAcPw9FHBvdfarRuySJ1Yl = 'LIVE'
			if UfHDlNvZCp in kHzJN8p6GIWZ: fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9 = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9+'_EPG'
			if UfHDlNvZCp in Wijm7pdUTSBuXLQ9ZCb4Mcr0fye: fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9 = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9+'_ARCHIVED'
			if not Duty5SzAherY3mXvZ: GGKpqhAcPw9FHBvdfarRuySJ1Yl = GGKpqhAcPw9FHBvdfarRuySJ1Yl+'_UNKNOWN'
			else: GGKpqhAcPw9FHBvdfarRuySJ1Yl = GGKpqhAcPw9FHBvdfarRuySJ1Yl+fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9
		Duty5SzAherY3mXvZ = Duty5SzAherY3mXvZ.strip(' ').replace('  ',' ').replace('  ',' ')
		if 'LIVE_UNKNOWN' in GGKpqhAcPw9FHBvdfarRuySJ1Yl: Duty5SzAherY3mXvZ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in GGKpqhAcPw9FHBvdfarRuySJ1Yl: Duty5SzAherY3mXvZ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in GGKpqhAcPw9FHBvdfarRuySJ1Yl:
			ZhEOnYBJwS1mN7TAVzxGd65DyjP = JJDtX1PZyIgN2T.findall('(.*?) [Ss]\d+ +[Ee]\d+',in8BOotyvMKbcSjGsrP['title'],JJDtX1PZyIgN2T.DOTALL)
			if ZhEOnYBJwS1mN7TAVzxGd65DyjP: ZhEOnYBJwS1mN7TAVzxGd65DyjP = ZhEOnYBJwS1mN7TAVzxGd65DyjP[0]
			else: ZhEOnYBJwS1mN7TAVzxGd65DyjP = '!!__UNKNOWN_SERIES__!!'
			Duty5SzAherY3mXvZ = Duty5SzAherY3mXvZ+'__SERIES__'+ZhEOnYBJwS1mN7TAVzxGd65DyjP
		if 'id' in SSWTV1gF57k: del in8BOotyvMKbcSjGsrP['id']
		if 'ID' in SSWTV1gF57k: del in8BOotyvMKbcSjGsrP['ID']
		if 'name' in SSWTV1gF57k: del in8BOotyvMKbcSjGsrP['name']
		UfHDlNvZCp = in8BOotyvMKbcSjGsrP['title']
		UfHDlNvZCp = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(UfHDlNvZCp)
		UfHDlNvZCp = mhGBPf3Oijz1dyqET8sFZobk9gaCQ(UfHDlNvZCp)
		uCwtFYPZSBWkQv,Duty5SzAherY3mXvZ = Nkt0JFDv4oz(Duty5SzAherY3mXvZ)
		OuTJMWrZICfNSR25jx,UfHDlNvZCp = Nkt0JFDv4oz(UfHDlNvZCp)
		in8BOotyvMKbcSjGsrP['type'] = GGKpqhAcPw9FHBvdfarRuySJ1Yl
		in8BOotyvMKbcSjGsrP['context'] = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9
		in8BOotyvMKbcSjGsrP['group'] = Duty5SzAherY3mXvZ.upper()
		in8BOotyvMKbcSjGsrP['title'] = UfHDlNvZCp.upper()
		in8BOotyvMKbcSjGsrP['country'] = OuTJMWrZICfNSR25jx.upper()
		in8BOotyvMKbcSjGsrP['language'] = uCwtFYPZSBWkQv.upper()
		buLCgJMpUIA3rO56kaicRBTGq90.append(in8BOotyvMKbcSjGsrP)
		ljCiyDcov8N0kZeS += 1
	return buLCgJMpUIA3rO56kaicRBTGq90,ljCiyDcov8N0kZeS,LLkse1rfM7Unothv0Vi3la8
def mhGBPf3Oijz1dyqET8sFZobk9gaCQ(UfHDlNvZCp):
	UfHDlNvZCp = UfHDlNvZCp.replace('  ',' ').replace('  ',' ').replace('  ',' ')
	UfHDlNvZCp = UfHDlNvZCp.replace('||','|').replace('___',':').replace('--','-')
	UfHDlNvZCp = UfHDlNvZCp.replace('[[','[').replace(']]',']')
	UfHDlNvZCp = UfHDlNvZCp.replace('((','(').replace('))',')')
	UfHDlNvZCp = UfHDlNvZCp.replace('<<','<').replace('>>','>')
	UfHDlNvZCp = UfHDlNvZCp.strip(' ')
	return UfHDlNvZCp
def cvxJ82VNiC1GTzw9pKQYjLehgWs7(tBnVOseYd7o3NcRq4Pzlx,ttr9RZhTxXg5,qpB7IC2ViZ9a4sDtlbTOdv6):
	EVNb6hR5sq8u3LarA0vQGcKi = {}
	for HHyGgloz6eJAD8CP9vc3EQO in kxteHPOwy8n0pC64mGVYLFTf: EVNb6hR5sq8u3LarA0vQGcKi[HHyGgloz6eJAD8CP9vc3EQO+'_'+qpB7IC2ViZ9a4sDtlbTOdv6] = []
	tgrzum407Ewl = len(tBnVOseYd7o3NcRq4Pzlx)
	ePb7wMQXlGSA3iEI40 = str(tgrzum407Ewl)
	ljCiyDcov8N0kZeS = 0
	LLkse1rfM7Unothv0Vi3la8 = []
	for in8BOotyvMKbcSjGsrP in tBnVOseYd7o3NcRq4Pzlx:
		if ljCiyDcov8N0kZeS%873==0:
			VspYz0aKeZL7uXOI(ttr9RZhTxXg5,50+int(5*ljCiyDcov8N0kZeS/tgrzum407Ewl),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(ljCiyDcov8N0kZeS)+' / '+ePb7wMQXlGSA3iEI40)
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return None,None
		Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL = in8BOotyvMKbcSjGsrP['group'],in8BOotyvMKbcSjGsrP['context'],in8BOotyvMKbcSjGsrP['title'],in8BOotyvMKbcSjGsrP['url'],in8BOotyvMKbcSjGsrP['img']
		OuTJMWrZICfNSR25jx,uCwtFYPZSBWkQv,HHyGgloz6eJAD8CP9vc3EQO = in8BOotyvMKbcSjGsrP['country'],in8BOotyvMKbcSjGsrP['language'],in8BOotyvMKbcSjGsrP['type']
		UUT95FDVM2Bydu4jIxRw6zb0L = (Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL)
		xoU8n6BvPuFVqwbl5scXLC = False
		if 'LIVE' in HHyGgloz6eJAD8CP9vc3EQO:
			if 'UNKNOWN' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_UNKNOWN_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			elif 'LIVE' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			else: xoU8n6BvPuFVqwbl5scXLC = True
			EVNb6hR5sq8u3LarA0vQGcKi['LIVE_ORIGINAL_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
		elif 'VOD' in HHyGgloz6eJAD8CP9vc3EQO:
			if 'UNKNOWN' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_UNKNOWN_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			elif 'MOVIES' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_MOVIES_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			elif 'SERIES' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_SERIES_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			else: xoU8n6BvPuFVqwbl5scXLC = True
			EVNb6hR5sq8u3LarA0vQGcKi['VOD_ORIGINAL_GROUPED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
		else: xoU8n6BvPuFVqwbl5scXLC = True
		if xoU8n6BvPuFVqwbl5scXLC: LLkse1rfM7Unothv0Vi3la8.append(in8BOotyvMKbcSjGsrP)
		ljCiyDcov8N0kZeS += 1
	CvaO0Gj1L5n7mxk = sorted(tBnVOseYd7o3NcRq4Pzlx,reverse=False,key=lambda FUAvmM61BHoYRKeGsTwrXC4qlZP: FUAvmM61BHoYRKeGsTwrXC4qlZP['title'].lower())
	del tBnVOseYd7o3NcRq4Pzlx
	ePb7wMQXlGSA3iEI40 = str(tgrzum407Ewl)
	ljCiyDcov8N0kZeS = 0
	for in8BOotyvMKbcSjGsrP in CvaO0Gj1L5n7mxk:
		ljCiyDcov8N0kZeS += 1
		if ljCiyDcov8N0kZeS%873==0:
			VspYz0aKeZL7uXOI(ttr9RZhTxXg5,55+int(5*ljCiyDcov8N0kZeS/tgrzum407Ewl),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(ljCiyDcov8N0kZeS)+' / '+ePb7wMQXlGSA3iEI40)
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return None,None
		HHyGgloz6eJAD8CP9vc3EQO = in8BOotyvMKbcSjGsrP['type']
		Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL = in8BOotyvMKbcSjGsrP['group'],in8BOotyvMKbcSjGsrP['context'],in8BOotyvMKbcSjGsrP['title'],in8BOotyvMKbcSjGsrP['url'],in8BOotyvMKbcSjGsrP['img']
		OuTJMWrZICfNSR25jx,uCwtFYPZSBWkQv = in8BOotyvMKbcSjGsrP['country'],in8BOotyvMKbcSjGsrP['language']
		UuXZDlNL0K7mRfJ5x6s2qvS = (Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9+'_TIMESHIFT',UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL)
		UUT95FDVM2Bydu4jIxRw6zb0L = (Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL)
		sTw2XrZqGd91DtzQ0BM5KRLpH = (OuTJMWrZICfNSR25jx,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL)
		tc5uP1NgRYrWas9BQM = (uCwtFYPZSBWkQv,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL)
		if 'LIVE' in HHyGgloz6eJAD8CP9vc3EQO:
			if 'UNKNOWN' in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_UNKNOWN_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			else: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			if 'EPG'		in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_EPG_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			if 'ARCHIVED'	in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_ARCHIVED_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			if 'ARCHIVED'	in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['LIVE_TIMESHIFT_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UuXZDlNL0K7mRfJ5x6s2qvS)
			EVNb6hR5sq8u3LarA0vQGcKi['LIVE_FROM_NAME_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(sTw2XrZqGd91DtzQ0BM5KRLpH)
			EVNb6hR5sq8u3LarA0vQGcKi['LIVE_FROM_GROUP_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(tc5uP1NgRYrWas9BQM)
		elif 'VOD' in HHyGgloz6eJAD8CP9vc3EQO:
			if   'UNKNOWN'	in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_UNKNOWN_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			elif 'MOVIES'	in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_MOVIES_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			elif 'SERIES'	in HHyGgloz6eJAD8CP9vc3EQO: EVNb6hR5sq8u3LarA0vQGcKi['VOD_SERIES_GROUPED_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(UUT95FDVM2Bydu4jIxRw6zb0L)
			EVNb6hR5sq8u3LarA0vQGcKi['VOD_FROM_NAME_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(sTw2XrZqGd91DtzQ0BM5KRLpH)
			EVNb6hR5sq8u3LarA0vQGcKi['VOD_FROM_GROUP_SORTED_'+qpB7IC2ViZ9a4sDtlbTOdv6].append(tc5uP1NgRYrWas9BQM)
	return EVNb6hR5sq8u3LarA0vQGcKi,LLkse1rfM7Unothv0Vi3la8
def Nkt0JFDv4oz(UfHDlNvZCp):
	if len(UfHDlNvZCp)<3: return UfHDlNvZCp,UfHDlNvZCp
	WI9OEeyXQAD34HoKvhi,b6PakN87w2fh = '',''
	uIAyUt5fJBrdW8h4CgxMzT1weLY = UfHDlNvZCp
	eBtEiNDbcVw0KnsF9YZMo3mRg72 = UfHDlNvZCp[:1]
	ooOqahgW4eyntAL7dH5 = UfHDlNvZCp[1:]
	if   eBtEiNDbcVw0KnsF9YZMo3mRg72=='(': b6PakN87w2fh = ')'
	elif eBtEiNDbcVw0KnsF9YZMo3mRg72=='[': b6PakN87w2fh = ']'
	elif eBtEiNDbcVw0KnsF9YZMo3mRg72=='<': b6PakN87w2fh = '>'
	elif eBtEiNDbcVw0KnsF9YZMo3mRg72=='|': b6PakN87w2fh = '|'
	if b6PakN87w2fh and (b6PakN87w2fh in ooOqahgW4eyntAL7dH5):
		mNSD8l42FGywvV6LtdefgXzoRbC,SmBn71A3o89v6iWVP4a = ooOqahgW4eyntAL7dH5.split(b6PakN87w2fh,1)
		WI9OEeyXQAD34HoKvhi = mNSD8l42FGywvV6LtdefgXzoRbC
		uIAyUt5fJBrdW8h4CgxMzT1weLY = eBtEiNDbcVw0KnsF9YZMo3mRg72+mNSD8l42FGywvV6LtdefgXzoRbC+b6PakN87w2fh+' '+SmBn71A3o89v6iWVP4a
	elif UfHDlNvZCp.count('|')>=2:
		mNSD8l42FGywvV6LtdefgXzoRbC,SmBn71A3o89v6iWVP4a = UfHDlNvZCp.split('|',1)
		WI9OEeyXQAD34HoKvhi = mNSD8l42FGywvV6LtdefgXzoRbC
		uIAyUt5fJBrdW8h4CgxMzT1weLY = mNSD8l42FGywvV6LtdefgXzoRbC+' |'+SmBn71A3o89v6iWVP4a
	else:
		b6PakN87w2fh = JJDtX1PZyIgN2T.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',UfHDlNvZCp,JJDtX1PZyIgN2T.DOTALL)
		if not b6PakN87w2fh: b6PakN87w2fh = JJDtX1PZyIgN2T.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',UfHDlNvZCp,JJDtX1PZyIgN2T.DOTALL)
		if not b6PakN87w2fh: b6PakN87w2fh = JJDtX1PZyIgN2T.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',UfHDlNvZCp,JJDtX1PZyIgN2T.DOTALL)
		if b6PakN87w2fh:
			mNSD8l42FGywvV6LtdefgXzoRbC,SmBn71A3o89v6iWVP4a = UfHDlNvZCp.split(b6PakN87w2fh[0],1)
			WI9OEeyXQAD34HoKvhi = mNSD8l42FGywvV6LtdefgXzoRbC
			uIAyUt5fJBrdW8h4CgxMzT1weLY = mNSD8l42FGywvV6LtdefgXzoRbC+' '+b6PakN87w2fh[0]+' '+SmBn71A3o89v6iWVP4a
	uIAyUt5fJBrdW8h4CgxMzT1weLY = uIAyUt5fJBrdW8h4CgxMzT1weLY.replace('   ',' ').replace('  ',' ')
	WI9OEeyXQAD34HoKvhi = WI9OEeyXQAD34HoKvhi.replace('  ',' ')
	if not WI9OEeyXQAD34HoKvhi: WI9OEeyXQAD34HoKvhi = '!!__UNKNOWN__!!'
	WI9OEeyXQAD34HoKvhi = WI9OEeyXQAD34HoKvhi.strip(' ')
	uIAyUt5fJBrdW8h4CgxMzT1weLY = uIAyUt5fJBrdW8h4CgxMzT1weLY.strip(' ')
	return WI9OEeyXQAD34HoKvhi,uIAyUt5fJBrdW8h4CgxMzT1weLY
def DDuOmxZytwH5qf061M4PVnvI(F8UNnjSZvpI):
	jmdxulY90XbNQGP5vSfoz16h = {}
	KmP7jBGwEc3f0HvkO = BBwb2NzsHE.getSetting('av.m3u.useragent_'+F8UNnjSZvpI)
	if KmP7jBGwEc3f0HvkO: jmdxulY90XbNQGP5vSfoz16h['User-Agent'] = KmP7jBGwEc3f0HvkO
	g268gDeMJbqUBc0lV4PZup5zvGQaj = BBwb2NzsHE.getSetting('av.m3u.referer_'+F8UNnjSZvpI)
	if g268gDeMJbqUBc0lV4PZup5zvGQaj: jmdxulY90XbNQGP5vSfoz16h['Referer'] = g268gDeMJbqUBc0lV4PZup5zvGQaj
	return jmdxulY90XbNQGP5vSfoz16h
def fsBAvMwadHmq2eyzTL1cJR8i76(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6):
	global ttr9RZhTxXg5,EVNb6hR5sq8u3LarA0vQGcKi,Q6TyBckZidKLXAvsDE1rfp2R03WP,sU9HvDJfVMu3k81h0xF7C5m2wo,VR53lYCF21ncfjam,IOYAmcp4VlJbEUGfuzwdisBPK,iZuVHfzRn0pdGQUq73oybP,Bk6vjUMpP4IzGxA,aGb8vRPF7IBEdj
	vhs4dn1piy6k8 = BBwb2NzsHE.getSetting('av.m3u.url_'+F8UNnjSZvpI+'_'+qpB7IC2ViZ9a4sDtlbTOdv6)
	KmP7jBGwEc3f0HvkO = BBwb2NzsHE.getSetting('av.m3u.useragent_'+F8UNnjSZvpI)
	jmdxulY90XbNQGP5vSfoz16h = {'User-Agent':KmP7jBGwEc3f0HvkO}
	YoA7KjgekuVhlnP2y5 = dd4ubU1pBVFhms56Y.replace('___','_'+F8UNnjSZvpI+'_'+qpB7IC2ViZ9a4sDtlbTOdv6)
	if 1:
		dnD6ZJOtXsEGPhk3gH,D5wzIoVxnu8RX4OCl,DCSd54AeZyf3HoQFB7uOa = True,'',''
		if not dnD6ZJOtXsEGPhk3gH:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not vhs4dn1piy6k8: b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   No M3U URL found to download M3U files')
			else: b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(s1ITpY2ghtCvR3mSXkFVBnlL8)+'   Failed to download M3U files')
			return
		p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = jFfs5J7diIt68yb9mBSZ(vhs4dn1piy6k8,jmdxulY90XbNQGP5vSfoz16h,True)
		if not p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj: return
		open(YoA7KjgekuVhlnP2y5,'wb').write(p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj)
	else: p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = open(YoA7KjgekuVhlnP2y5,'rb').read()
	if DQfHadYvTpy1UR and p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj: p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.decode('utf8')
	ttr9RZhTxXg5 = W2mNFlgkhXS8KIQ0GcTt()
	ttr9RZhTxXg5.create('جلب ملفات M3U جديدة','')
	VspYz0aKeZL7uXOI(ttr9RZhTxXg5,15,'تنظيف الملف الرئيسي','')
	p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.replace('"tvg-','" tvg-')
	p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
	p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.replace('ّ','').replace('ِ','').replace('ٍ','').replace('ْ','')
	p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.replace('group-title=','group=').replace('tvg-','')
	Wijm7pdUTSBuXLQ9ZCb4Mcr0fye,kHzJN8p6GIWZ = [],[]
	p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj = p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj.replace('\r','\n')
	ADoPKcJrFuZi = JJDtX1PZyIgN2T.findall('NF:(.+?)'+'#'+'EXTI',p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj+'\n+'+'#'+'EXTINF:',JJDtX1PZyIgN2T.DOTALL)
	if not ADoPKcJrFuZi:
		b6kj4LJ5tzTeOMQi('ERROR_LINES',ggSwBRPlX6fJDn2FsvA(s1ITpY2ghtCvR3mSXkFVBnlL8)+'   Folder:'+F8UNnjSZvpI+'  Sequence:'+qpB7IC2ViZ9a4sDtlbTOdv6+'   No video links found in M3U file')
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+'\n'+'[COLOR FFFFFF00]'+'مجلد رقم '+F8UNnjSZvpI+'      رابط رقم '+qpB7IC2ViZ9a4sDtlbTOdv6+'[/COLOR]')
		ttr9RZhTxXg5.close()
		return
	V4yi5L7CQBdZgpWa8I1ej9 = []
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		rZPLNoftYQBV3aluhHcDA = D5wxHF2QT6bdzhuyl.lower()
		if 'adult' in rZPLNoftYQBV3aluhHcDA: continue
		if 'xxx' in rZPLNoftYQBV3aluhHcDA: continue
		V4yi5L7CQBdZgpWa8I1ej9.append(D5wxHF2QT6bdzhuyl)
	ADoPKcJrFuZi = V4yi5L7CQBdZgpWa8I1ej9
	del V4yi5L7CQBdZgpWa8I1ej9
	if 'iptv-org' in vhs4dn1piy6k8:
		V4yi5L7CQBdZgpWa8I1ej9,d2dnKfyBht4S = [],[]
		for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
			IOYAmcp4VlJbEUGfuzwdisBPK = JJDtX1PZyIgN2T.findall('group="(.*?)"',D5wxHF2QT6bdzhuyl,JJDtX1PZyIgN2T.DOTALL)
			if IOYAmcp4VlJbEUGfuzwdisBPK:
				IOYAmcp4VlJbEUGfuzwdisBPK = IOYAmcp4VlJbEUGfuzwdisBPK[0]
				E5EnFGlItKaOSk = IOYAmcp4VlJbEUGfuzwdisBPK.split(';')
				if 'region' in vhs4dn1piy6k8: OOBICKlMaRmuAZXD78jvkGh3SP = '1_'
				elif 'category' in vhs4dn1piy6k8: OOBICKlMaRmuAZXD78jvkGh3SP = '2_'
				elif 'language' in vhs4dn1piy6k8: OOBICKlMaRmuAZXD78jvkGh3SP = '3_'
				elif 'country' in vhs4dn1piy6k8: OOBICKlMaRmuAZXD78jvkGh3SP = '4_'
				else: OOBICKlMaRmuAZXD78jvkGh3SP = '5_'
				dd3BTplsA0mrxktzZMIj = D5wxHF2QT6bdzhuyl.replace('group="'+IOYAmcp4VlJbEUGfuzwdisBPK+'"','group="'+OOBICKlMaRmuAZXD78jvkGh3SP+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				V4yi5L7CQBdZgpWa8I1ej9.append(dd3BTplsA0mrxktzZMIj)
				for Duty5SzAherY3mXvZ in E5EnFGlItKaOSk:
					dd3BTplsA0mrxktzZMIj = D5wxHF2QT6bdzhuyl.replace('group="'+IOYAmcp4VlJbEUGfuzwdisBPK+'"','group="'+OOBICKlMaRmuAZXD78jvkGh3SP+Duty5SzAherY3mXvZ+'"')
					V4yi5L7CQBdZgpWa8I1ej9.append(dd3BTplsA0mrxktzZMIj)
			else: V4yi5L7CQBdZgpWa8I1ej9.append(D5wxHF2QT6bdzhuyl)
		ADoPKcJrFuZi = V4yi5L7CQBdZgpWa8I1ej9
		del V4yi5L7CQBdZgpWa8I1ej9,d2dnKfyBht4S
	avhERrl91XI3 = 1024*1024
	BkxL7ApisfuD20o4rqZzeUT3MI = 1+len(p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj)//avhERrl91XI3//10
	del p3xMg7ycPzenb0dRr6JBTUVQ9k8Cj
	s19iTBh4Jy = len(ADoPKcJrFuZi)
	d2dnKfyBht4S = YEo9xV0vUsPuG2Z(ADoPKcJrFuZi,BkxL7ApisfuD20o4rqZzeUT3MI)
	del ADoPKcJrFuZi
	for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(BkxL7ApisfuD20o4rqZzeUT3MI):
		VspYz0aKeZL7uXOI(ttr9RZhTxXg5,35+int(5*NzfP6biDZJAqmyensuhE7HjwYvlQk/BkxL7ApisfuD20o4rqZzeUT3MI),'تقطيع الملف الرئيسي','الجزء رقم:-',str(NzfP6biDZJAqmyensuhE7HjwYvlQk+1)+' / '+str(BkxL7ApisfuD20o4rqZzeUT3MI))
		if ttr9RZhTxXg5.iscanceled():
			ttr9RZhTxXg5.close()
			return
		s5xhebkq9R = str(d2dnKfyBht4S[NzfP6biDZJAqmyensuhE7HjwYvlQk])
		if DQfHadYvTpy1UR: s5xhebkq9R = s5xhebkq9R.encode('utf8')
		open(YoA7KjgekuVhlnP2y5+'.00'+str(NzfP6biDZJAqmyensuhE7HjwYvlQk),'wb').write(s5xhebkq9R)
	del d2dnKfyBht4S,s5xhebkq9R
	ixIcOt8avCJzry,tBnVOseYd7o3NcRq4Pzlx,ljCiyDcov8N0kZeS = [],[],0
	for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(BkxL7ApisfuD20o4rqZzeUT3MI):
		if ttr9RZhTxXg5.iscanceled():
			ttr9RZhTxXg5.close()
			return
		s5xhebkq9R = open(YoA7KjgekuVhlnP2y5+'.00'+str(NzfP6biDZJAqmyensuhE7HjwYvlQk),'rb').read()
		Mrx2OeZV1LNjBsQ58Savi7.sleep(1)
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(YoA7KjgekuVhlnP2y5+'.00'+str(NzfP6biDZJAqmyensuhE7HjwYvlQk))
		except: pass
		if DQfHadYvTpy1UR: s5xhebkq9R = s5xhebkq9R.decode('utf8')
		hmnAL1DqfsMWZ7 = G8EwoDOyKShm1i0IHMfNYZlU7('list',s5xhebkq9R)
		del s5xhebkq9R
		buLCgJMpUIA3rO56kaicRBTGq90,ljCiyDcov8N0kZeS,LLkse1rfM7Unothv0Vi3la8 = lgokIvjshuey10zRdPY6GrJ7aFZ(hmnAL1DqfsMWZ7,kHzJN8p6GIWZ,Wijm7pdUTSBuXLQ9ZCb4Mcr0fye,ttr9RZhTxXg5,s19iTBh4Jy,ljCiyDcov8N0kZeS,vhs4dn1piy6k8)
		if ttr9RZhTxXg5.iscanceled():
			ttr9RZhTxXg5.close()
			return
		if not buLCgJMpUIA3rO56kaicRBTGq90:
			ttr9RZhTxXg5.close()
			return
		tBnVOseYd7o3NcRq4Pzlx += buLCgJMpUIA3rO56kaicRBTGq90
		ixIcOt8avCJzry += LLkse1rfM7Unothv0Vi3la8
	del hmnAL1DqfsMWZ7,buLCgJMpUIA3rO56kaicRBTGq90
	EVNb6hR5sq8u3LarA0vQGcKi,LLkse1rfM7Unothv0Vi3la8 = cvxJ82VNiC1GTzw9pKQYjLehgWs7(tBnVOseYd7o3NcRq4Pzlx,ttr9RZhTxXg5,qpB7IC2ViZ9a4sDtlbTOdv6)
	if ttr9RZhTxXg5.iscanceled():
		ttr9RZhTxXg5.close()
		return
	ixIcOt8avCJzry += LLkse1rfM7Unothv0Vi3la8
	del tBnVOseYd7o3NcRq4Pzlx,LLkse1rfM7Unothv0Vi3la8
	sU9HvDJfVMu3k81h0xF7C5m2wo,VR53lYCF21ncfjam,IOYAmcp4VlJbEUGfuzwdisBPK,iZuVHfzRn0pdGQUq73oybP,Bk6vjUMpP4IzGxA = {},{},{},0,0
	q5reDv28EgwS4FuklIaToP3 = list(EVNb6hR5sq8u3LarA0vQGcKi.keys())
	aGb8vRPF7IBEdj = len(q5reDv28EgwS4FuklIaToP3)*3
	if 1:
		kS4uiCYWts96N7gpv3leLBP = {}
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte] = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=njiSpQWfPa82zTO5VrUAcyIgw,args=(qqp1v0DYyPONaiu7VEte,))
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte].start()
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte].join()
		if ttr9RZhTxXg5.iscanceled():
			ttr9RZhTxXg5.close()
			return
	else:
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			njiSpQWfPa82zTO5VrUAcyIgw(qqp1v0DYyPONaiu7VEte)
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return
	iMZs9V7SuGrb4DcmgKCd(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6,False)
	q5reDv28EgwS4FuklIaToP3 = list(sU9HvDJfVMu3k81h0xF7C5m2wo.keys())
	Q6TyBckZidKLXAvsDE1rfp2R03WP = 0
	if 1:
		kS4uiCYWts96N7gpv3leLBP = {}
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte] = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=hebt9orqQxTXjlVOWM5cdsmuKL3U4,args=(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte))
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte].start()
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			kS4uiCYWts96N7gpv3leLBP[qqp1v0DYyPONaiu7VEte].join()
		if ttr9RZhTxXg5.iscanceled():
			ttr9RZhTxXg5.close()
			return
	else:
		for qqp1v0DYyPONaiu7VEte in q5reDv28EgwS4FuklIaToP3:
			hebt9orqQxTXjlVOWM5cdsmuKL3U4(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte)
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return
	NzfP6biDZJAqmyensuhE7HjwYvlQk = 0
	EwIQk9nKNaTeOGz3mAD = len(ixIcOt8avCJzry)
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'IGNORED')
	for QKx4E3saBcIZNCtVYOXG in ixIcOt8avCJzry:
		if NzfP6biDZJAqmyensuhE7HjwYvlQk%27==0:
			VspYz0aKeZL7uXOI(ttr9RZhTxXg5,95+int(5*NzfP6biDZJAqmyensuhE7HjwYvlQk//EwIQk9nKNaTeOGz3mAD),'تخزين المهملة','الفيديو رقم:-',str(NzfP6biDZJAqmyensuhE7HjwYvlQk)+' / '+str(EwIQk9nKNaTeOGz3mAD))
			if ttr9RZhTxXg5.iscanceled():
				ttr9RZhTxXg5.close()
				return
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,'IGNORED_'+qpB7IC2ViZ9a4sDtlbTOdv6,str(QKx4E3saBcIZNCtVYOXG),'',iJnLmxA0ykozR98WXFQ4Ye3w)
		NzfP6biDZJAqmyensuhE7HjwYvlQk += 1
	pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,'IGNORED_'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__',str(EwIQk9nKNaTeOGz3mAD),iJnLmxA0ykozR98WXFQ4Ye3w)
	ttr9RZhTxXg5.close()
	Mrx2OeZV1LNjBsQ58Savi7.sleep(1)
	LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI)
	return
def njiSpQWfPa82zTO5VrUAcyIgw(qqp1v0DYyPONaiu7VEte):
	global ttr9RZhTxXg5,EVNb6hR5sq8u3LarA0vQGcKi,Q6TyBckZidKLXAvsDE1rfp2R03WP,sU9HvDJfVMu3k81h0xF7C5m2wo,VR53lYCF21ncfjam,IOYAmcp4VlJbEUGfuzwdisBPK,iZuVHfzRn0pdGQUq73oybP,Bk6vjUMpP4IzGxA,aGb8vRPF7IBEdj
	sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte] = {}
	uxnBAcW0CMLKaIXs9qN5FGl,poDAhBzIg3RXfamnYVQ = {},[]
	NCS0BujUPmsvnVpWKf = len(EVNb6hR5sq8u3LarA0vQGcKi[qqp1v0DYyPONaiu7VEte])
	sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte]['__COUNT__'] = NCS0BujUPmsvnVpWKf
	if NCS0BujUPmsvnVpWKf>0:
		n2z3UJaSCyeLPK84dG9W,qrvPftC1k4,eez2gZMf6ICDT8i9qrEGaRFJ1ot,Ocdu54SPRhIj,O4oNDC9lILJ8fw6Ry = zip(*EVNb6hR5sq8u3LarA0vQGcKi[qqp1v0DYyPONaiu7VEte])
		del qrvPftC1k4,eez2gZMf6ICDT8i9qrEGaRFJ1ot,Ocdu54SPRhIj
		E5EnFGlItKaOSk = list(set(n2z3UJaSCyeLPK84dG9W))
		for Duty5SzAherY3mXvZ in E5EnFGlItKaOSk:
			uxnBAcW0CMLKaIXs9qN5FGl[Duty5SzAherY3mXvZ] = ''
			sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte][Duty5SzAherY3mXvZ] = []
		VspYz0aKeZL7uXOI(ttr9RZhTxXg5,60+int(15*Bk6vjUMpP4IzGxA//aGb8vRPF7IBEdj),'تصنيع القوائم','الجزء رقم:-',str(Bk6vjUMpP4IzGxA)+' / '+str(aGb8vRPF7IBEdj))
		if ttr9RZhTxXg5.iscanceled(): return
		Bk6vjUMpP4IzGxA += 1
		fXpY3FSCzIqewrW1n = len(E5EnFGlItKaOSk)
		del E5EnFGlItKaOSk
		poDAhBzIg3RXfamnYVQ = list(set(zip(n2z3UJaSCyeLPK84dG9W,O4oNDC9lILJ8fw6Ry)))
		del n2z3UJaSCyeLPK84dG9W,O4oNDC9lILJ8fw6Ry
		for Duty5SzAherY3mXvZ,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO in poDAhBzIg3RXfamnYVQ:
			if not uxnBAcW0CMLKaIXs9qN5FGl[Duty5SzAherY3mXvZ] and mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO: uxnBAcW0CMLKaIXs9qN5FGl[Duty5SzAherY3mXvZ] = mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO
		VspYz0aKeZL7uXOI(ttr9RZhTxXg5,60+int(15*Bk6vjUMpP4IzGxA//aGb8vRPF7IBEdj),'تصنيع القوائم','الجزء رقم:-',str(Bk6vjUMpP4IzGxA)+' / '+str(aGb8vRPF7IBEdj))
		if ttr9RZhTxXg5.iscanceled(): return
		Bk6vjUMpP4IzGxA += 1
		TKgsuO3XhnCo1trZJlDdSqcGV8 = list(uxnBAcW0CMLKaIXs9qN5FGl.keys())
		RmC1hUcQGatV5Z9xBSOj = list(uxnBAcW0CMLKaIXs9qN5FGl.values())
		del uxnBAcW0CMLKaIXs9qN5FGl
		poDAhBzIg3RXfamnYVQ = list(zip(TKgsuO3XhnCo1trZJlDdSqcGV8,RmC1hUcQGatV5Z9xBSOj))
		del TKgsuO3XhnCo1trZJlDdSqcGV8,RmC1hUcQGatV5Z9xBSOj
		poDAhBzIg3RXfamnYVQ = sorted(poDAhBzIg3RXfamnYVQ)
	else: Bk6vjUMpP4IzGxA += 2
	sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte]['__GROUPS__'] = poDAhBzIg3RXfamnYVQ
	del poDAhBzIg3RXfamnYVQ
	for Duty5SzAherY3mXvZ,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL in EVNb6hR5sq8u3LarA0vQGcKi[qqp1v0DYyPONaiu7VEte]:
		sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte][Duty5SzAherY3mXvZ].append((fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL))
	VspYz0aKeZL7uXOI(ttr9RZhTxXg5,60+int(15*Bk6vjUMpP4IzGxA//aGb8vRPF7IBEdj),'تصنيع القوائم','الجزء رقم:-',str(Bk6vjUMpP4IzGxA)+' / '+str(aGb8vRPF7IBEdj))
	if ttr9RZhTxXg5.iscanceled(): return
	Bk6vjUMpP4IzGxA += 1
	del EVNb6hR5sq8u3LarA0vQGcKi[qqp1v0DYyPONaiu7VEte]
	IOYAmcp4VlJbEUGfuzwdisBPK[qqp1v0DYyPONaiu7VEte] = list(sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte].keys())
	VR53lYCF21ncfjam[qqp1v0DYyPONaiu7VEte] = len(IOYAmcp4VlJbEUGfuzwdisBPK[qqp1v0DYyPONaiu7VEte])
	iZuVHfzRn0pdGQUq73oybP += VR53lYCF21ncfjam[qqp1v0DYyPONaiu7VEte]
	return
def hebt9orqQxTXjlVOWM5cdsmuKL3U4(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte):
	global ttr9RZhTxXg5,EVNb6hR5sq8u3LarA0vQGcKi,Q6TyBckZidKLXAvsDE1rfp2R03WP,sU9HvDJfVMu3k81h0xF7C5m2wo,VR53lYCF21ncfjam,IOYAmcp4VlJbEUGfuzwdisBPK,iZuVHfzRn0pdGQUq73oybP,Bk6vjUMpP4IzGxA,aGb8vRPF7IBEdj
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte)
	for ljCiyDcov8N0kZeS in range(1+VR53lYCF21ncfjam[qqp1v0DYyPONaiu7VEte]//273):
		CXmMyQJAGxgTFsht = []
		AATl3fOBqzL7CbU0g5H2Ic9p1dr6XK = IOYAmcp4VlJbEUGfuzwdisBPK[qqp1v0DYyPONaiu7VEte][0:273]
		for Duty5SzAherY3mXvZ in AATl3fOBqzL7CbU0g5H2Ic9p1dr6XK:
			CXmMyQJAGxgTFsht.append(sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte][Duty5SzAherY3mXvZ])
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,qqp1v0DYyPONaiu7VEte,AATl3fOBqzL7CbU0g5H2Ic9p1dr6XK,CXmMyQJAGxgTFsht,iJnLmxA0ykozR98WXFQ4Ye3w,True)
		Q6TyBckZidKLXAvsDE1rfp2R03WP += len(AATl3fOBqzL7CbU0g5H2Ic9p1dr6XK)
		VspYz0aKeZL7uXOI(ttr9RZhTxXg5,75+int(20*Q6TyBckZidKLXAvsDE1rfp2R03WP//iZuVHfzRn0pdGQUq73oybP),'تخزين القوائم','القائمة رقم:-',str(Q6TyBckZidKLXAvsDE1rfp2R03WP)+' / '+str(iZuVHfzRn0pdGQUq73oybP))
		if ttr9RZhTxXg5.iscanceled(): return
		del IOYAmcp4VlJbEUGfuzwdisBPK[qqp1v0DYyPONaiu7VEte][0:273]
	del sU9HvDJfVMu3k81h0xF7C5m2wo[qqp1v0DYyPONaiu7VEte],IOYAmcp4VlJbEUGfuzwdisBPK[qqp1v0DYyPONaiu7VEte],VR53lYCF21ncfjam[qqp1v0DYyPONaiu7VEte]
	return
def pyrOECsb792gGHn(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6,Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	O7O2dtkCRKZoENLQ5IBTg = 'عدد فيديوهات جميع الروابط'
	DDsW2HPpb0w = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'LIVE_ORIGINAL_GROUPED')
	iFeXZu2tMWYzJVQx3BbARvwp0P = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'VOD_ORIGINAL_GROUPED')
	if qpB7IC2ViZ9a4sDtlbTOdv6:
		O7O2dtkCRKZoENLQ5IBTg = 'عدد فيديوهات رابط '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[int(qpB7IC2ViZ9a4sDtlbTOdv6)]
		qpB7IC2ViZ9a4sDtlbTOdv6 = '_'+qpB7IC2ViZ9a4sDtlbTOdv6
	EwIQk9nKNaTeOGz3mAD = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','IGNORED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	VqmJiR5pGsMICkyKeZ = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','LIVE_ORIGINAL_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	HHocBi5QlTrAupst3wJGgx7 = cLozpXkSg1qU3VthuFbNyQTns(iFeXZu2tMWYzJVQx3BbARvwp0P,'int','VOD_ORIGINAL_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	LSYsMduwVqgZ8ejaKx3RN2QzH9kc6E = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','LIVE_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	Y4hPyi76H2M0sGrVI = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','LIVE_UNKNOWN_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	aQbELfkGJYAFhcVs7qx364ou2OXIUN = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','VOD_MOVIES_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	grvGBnj9xfE0 = cLozpXkSg1qU3VthuFbNyQTns(iFeXZu2tMWYzJVQx3BbARvwp0P,'int','VOD_SERIES_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	pNIMy7G9ABwr5sZ1xkfh2QX3q = cLozpXkSg1qU3VthuFbNyQTns(DDsW2HPpb0w,'int','VOD_UNKNOWN_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__COUNT__')
	IOYAmcp4VlJbEUGfuzwdisBPK = cLozpXkSg1qU3VthuFbNyQTns(iFeXZu2tMWYzJVQx3BbARvwp0P,'list','VOD_SERIES_GROUPED'+qpB7IC2ViZ9a4sDtlbTOdv6,'__GROUPS__')
	xhio2MBz4sSeK1Z = []
	for Duty5SzAherY3mXvZ,st9uk8gcDL in IOYAmcp4VlJbEUGfuzwdisBPK:
		XkfEiQnN57vqtbP4K = Duty5SzAherY3mXvZ.split('__SERIES__')[1]
		xhio2MBz4sSeK1Z.append(XkfEiQnN57vqtbP4K)
	bcV2hjXitxW8 = len(xhio2MBz4sSeK1Z)
	ICUfvdYPXcFDGs3g6jmktAW9 = int(aQbELfkGJYAFhcVs7qx364ou2OXIUN)+int(grvGBnj9xfE0)+int(pNIMy7G9ABwr5sZ1xkfh2QX3q)+int(Y4hPyi76H2M0sGrVI)+int(LSYsMduwVqgZ8ejaKx3RN2QzH9kc6E)
	w4h6AKMDfX7jeGE = ''
	w4h6AKMDfX7jeGE += 'قنوات: '+str(LSYsMduwVqgZ8ejaKx3RN2QzH9kc6E)
	w4h6AKMDfX7jeGE += '   .   أفلام: '+str(aQbELfkGJYAFhcVs7qx364ou2OXIUN)
	w4h6AKMDfX7jeGE += '\nمسلسلات: '+str(bcV2hjXitxW8)
	w4h6AKMDfX7jeGE += '   .   حلقات: '+str(grvGBnj9xfE0)
	w4h6AKMDfX7jeGE += '\nقنوات مجهولة: '+str(Y4hPyi76H2M0sGrVI)
	w4h6AKMDfX7jeGE += '   .   فيدوهات مجهولة: '+str(pNIMy7G9ABwr5sZ1xkfh2QX3q)
	w4h6AKMDfX7jeGE += '\nمجموع القنوات: '+str(VqmJiR5pGsMICkyKeZ)
	w4h6AKMDfX7jeGE += '   .   مجموع الفيديوهات: '+str(HHocBi5QlTrAupst3wJGgx7)
	w4h6AKMDfX7jeGE += '\n\nمجموع المضافة: '+str(ICUfvdYPXcFDGs3g6jmktAW9)
	w4h6AKMDfX7jeGE += '   .   مجموع المهملة: '+str(EwIQk9nKNaTeOGz3mAD)
	if Jjlf8RwAikOqePtvbW0IXudhF36Z: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('center','',O7O2dtkCRKZoENLQ5IBTg,w4h6AKMDfX7jeGE)
	JQajoyIcLUChkbM1VNf6eAGz4gFlTw = w4h6AKMDfX7jeGE.replace('\n\n','\n')
	if not qpB7IC2ViZ9a4sDtlbTOdv6: qpB7IC2ViZ9a4sDtlbTOdv6 = 'All'
	else: qpB7IC2ViZ9a4sDtlbTOdv6 = qpB7IC2ViZ9a4sDtlbTOdv6[1]
	b6kj4LJ5tzTeOMQi('NOTICE','.  Counts of M3U videos   Folder: '+F8UNnjSZvpI+'   Sequence: '+qpB7IC2ViZ9a4sDtlbTOdv6+'\n'+JQajoyIcLUChkbM1VNf6eAGz4gFlTw)
	return w4h6AKMDfX7jeGE
def iMZs9V7SuGrb4DcmgKCd(F8UNnjSZvpI,qpB7IC2ViZ9a4sDtlbTOdv6,Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	if Jjlf8RwAikOqePtvbW0IXudhF36Z:
		z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('center','','','مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if z3rhpEtd7KLGQZ64XonmW19HSJfAc!=1: return
		pt7mlKuTQ9S2hovIgz6f = dd4ubU1pBVFhms56Y.replace('___','_'+F8UNnjSZvpI+'_'+qpB7IC2ViZ9a4sDtlbTOdv6)
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(pt7mlKuTQ9S2hovIgz6f)
		except: pass
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'')
	if qpB7IC2ViZ9a4sDtlbTOdv6:
		wK78UF10sRY = []
		for zYocNMaHQ4vXdGDAjC in kxteHPOwy8n0pC64mGVYLFTf:
			wK78UF10sRY.append(zYocNMaHQ4vXdGDAjC+'_'+qpB7IC2ViZ9a4sDtlbTOdv6)
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,'LINK_'+qpB7IC2ViZ9a4sDtlbTOdv6)
	else:
		wK78UF10sRY = kxteHPOwy8n0pC64mGVYLFTf
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,'DUMMY')
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,'GROUPS')
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,'ITEMS')
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,'SEARCH')
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_'+F8UNnjSZvpI)
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for qqp1v0DYyPONaiu7VEte in wK78UF10sRY:
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,qqp1v0DYyPONaiu7VEte)
	CHPE7xQVoMzsLhlKmnNgudSaRp4U(False)
	LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI)
	if Jjlf8RwAikOqePtvbW0IXudhF36Z: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def dzgJhQfsE7wOD3AU(F8UNnjSZvpI='',Jjlf8RwAikOqePtvbW0IXudhF36Z=True):
	if F8UNnjSZvpI:
		GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(str(F8UNnjSZvpI),'DUMMY')
		DfJA7kUuMTpHtxLe0EqOczG5In = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'str','DUMMY','__DUMMY__')
		if DfJA7kUuMTpHtxLe0EqOczG5In: return True
	else:
		F8UNnjSZvpI = '1'
		for sLTw4nY3ACKboMIPZGt0 in range(1,Z7TlP2WKYq5SuRD+1):
			GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(str(sLTw4nY3ACKboMIPZGt0),'DUMMY')
			DfJA7kUuMTpHtxLe0EqOczG5In = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'str','DUMMY','__DUMMY__')
			if DfJA7kUuMTpHtxLe0EqOczG5In: return True
	if Jjlf8RwAikOqePtvbW0IXudhF36Z:
		wwKJW3oc1DfIFPkUCTe6zxAn7 = 'https://iptv-org.github.io/iptv/index.region.m3u'
		YxwVvaDtGnRpA4d = 'https://iptv-org.github.io/iptv/index.category.m3u'
		hRyE3UjcZiaqPv2tY = 'https://iptv-org.github.io/iptv/index.language.m3u'
		VNCq9ens4AKp = 'https://iptv-org.github.io/iptv/index.country.m3u'
		xXMUdq1SGpPa5vChlbjnZfkF7JA0T = wwKJW3oc1DfIFPkUCTe6zxAn7+'\n'+YxwVvaDtGnRpA4d+'\n'+hRyE3UjcZiaqPv2tY+'\n'+VNCq9ens4AKp
		z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('','','','رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+xXMUdq1SGpPa5vChlbjnZfkF7JA0T+'[/COLOR]',profile='confirm_mediumfont')
		if z3rhpEtd7KLGQZ64XonmW19HSJfAc==1:
			BBwb2NzsHE.setSetting('av.m3u.url_'+str(F8UNnjSZvpI)+'_1',wwKJW3oc1DfIFPkUCTe6zxAn7)
			BBwb2NzsHE.setSetting('av.m3u.url_'+str(F8UNnjSZvpI)+'_2',YxwVvaDtGnRpA4d)
			BBwb2NzsHE.setSetting('av.m3u.url_'+str(F8UNnjSZvpI)+'_3',hRyE3UjcZiaqPv2tY)
			BBwb2NzsHE.setSetting('av.m3u.url_'+str(F8UNnjSZvpI)+'_4',VNCq9ens4AKp)
			z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('','','','رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if z3rhpEtd7KLGQZ64XonmW19HSJfAc==1:
				Wg8BrbdCMD0eQX = eRrpZlnzoM9WGf(F8UNnjSZvpI)
				return Wg8BrbdCMD0eQX
		else:
			O7O2dtkCRKZoENLQ5IBTg = 'إضافة وتغيير رابط '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[1]+' (مجلد '+nK76kpOf2u3ENigzmlJVoqIeXwjt4W[int(F8UNnjSZvpI)]+')'
			z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('','','',O7O2dtkCRKZoENLQ5IBTg,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if z3rhpEtd7KLGQZ64XonmW19HSJfAc==1: WS7HwIGFXRNKVfQsiMZLtCO5(F8UNnjSZvpI,'1')
	return False
def OXTVJbg9envrs(MEvoH6hqOy,F8UNnjSZvpI='',qqp1v0DYyPONaiu7VEte='',YDqRFgKxH7J0=''):
	if not YDqRFgKxH7J0: YDqRFgKxH7J0 = '1'
	fEasiDJ3gHUoOqLRlNdp,ihbjPQKgtdYUvNnLV5XErp3f0,Jjlf8RwAikOqePtvbW0IXudhF36Z = aCId1D0KbRVrm6jq98UwyuFWkeX3(MEvoH6hqOy)
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z): return
	if not fEasiDJ3gHUoOqLRlNdp:
		fEasiDJ3gHUoOqLRlNdp = GVfnMyZxiRI()
		if not fEasiDJ3gHUoOqLRlNdp: return
	k3bu6Da0dsXGhJ8BV = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not qqp1v0DYyPONaiu7VEte:
		if not Jjlf8RwAikOqePtvbW0IXudhF36Z:
			if   '_M3U-LIVE_' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[1]
			elif '_M3U-MOVIES' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[2]
			elif '_M3U-SERIES' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[3]
			else: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[0]
		else:
			IM4rLYNmQuwiTeSfaRnXb72FB6 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			d1cy9GkbBivnRNTChoEFu5xIXp4 = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر البحث المناسب', IM4rLYNmQuwiTeSfaRnXb72FB6)
			if d1cy9GkbBivnRNTChoEFu5xIXp4==-1: return
			qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[d1cy9GkbBivnRNTChoEFu5xIXp4]
	fEasiDJ3gHUoOqLRlNdp = fEasiDJ3gHUoOqLRlNdp+'_NODIALOGS_'
	if F8UNnjSZvpI: sfOnUGePLWz47tB(fEasiDJ3gHUoOqLRlNdp,F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte,YDqRFgKxH7J0)
	else:
		for F8UNnjSZvpI in range(1,Z7TlP2WKYq5SuRD+1):
			sfOnUGePLWz47tB(fEasiDJ3gHUoOqLRlNdp,str(F8UNnjSZvpI),qqp1v0DYyPONaiu7VEte,YDqRFgKxH7J0)
		PL2fM9WhpjEFb7[:] = sorted(PL2fM9WhpjEFb7,reverse=False,key=lambda FUAvmM61BHoYRKeGsTwrXC4qlZP: FUAvmM61BHoYRKeGsTwrXC4qlZP[1].lower())
	return
def sfOnUGePLWz47tB(MEvoH6hqOy,F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte='',YDqRFgKxH7J0=''):
	if not YDqRFgKxH7J0: YDqRFgKxH7J0 = '1'
	fEasiDJ3gHUoOqLRlNdp,ihbjPQKgtdYUvNnLV5XErp3f0,Jjlf8RwAikOqePtvbW0IXudhF36Z = aCId1D0KbRVrm6jq98UwyuFWkeX3(MEvoH6hqOy)
	if not F8UNnjSZvpI: return
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z): return
	if not fEasiDJ3gHUoOqLRlNdp:
		fEasiDJ3gHUoOqLRlNdp = GVfnMyZxiRI()
		if not fEasiDJ3gHUoOqLRlNdp: return
	k3bu6Da0dsXGhJ8BV = ['','LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not qqp1v0DYyPONaiu7VEte:
		if not Jjlf8RwAikOqePtvbW0IXudhF36Z:
			if   '_M3U-LIVE_' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[1]
			elif '_M3U-MOVIES' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[2]
			elif '_M3U-SERIES' in ihbjPQKgtdYUvNnLV5XErp3f0: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[3]
			else: qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[0]
		else:
			IM4rLYNmQuwiTeSfaRnXb72FB6 = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			d1cy9GkbBivnRNTChoEFu5xIXp4 = wicVSPINX4Unkqr5hsgJa6AO8jCT('أختر البحث المناسب', IM4rLYNmQuwiTeSfaRnXb72FB6)
			if d1cy9GkbBivnRNTChoEFu5xIXp4==-1: return
			qqp1v0DYyPONaiu7VEte = k3bu6Da0dsXGhJ8BV[d1cy9GkbBivnRNTChoEFu5xIXp4]
	gnf4eRjW20TOPZdIN = fEasiDJ3gHUoOqLRlNdp.lower()
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'SEARCH')
	pyWkE2rh5uBN4G = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list','SEARCH',(qqp1v0DYyPONaiu7VEte,gnf4eRjW20TOPZdIN))
	if not pyWkE2rh5uBN4G:
		rkq0t28uEoJWOwS6lTMh5,XXQoCf6EJWPm9vYIG5edjpwubU = [],[]
		if not qqp1v0DYyPONaiu7VEte: DMOHZSuqGpV7 = [1,2,3,4,5]
		else: DMOHZSuqGpV7 = [k3bu6Da0dsXGhJ8BV.index(qqp1v0DYyPONaiu7VEte)]
		for NzfP6biDZJAqmyensuhE7HjwYvlQk in DMOHZSuqGpV7:
			if NzfP6biDZJAqmyensuhE7HjwYvlQk!=3:
				buLCgJMpUIA3rO56kaicRBTGq90 = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'dict',k3bu6Da0dsXGhJ8BV[NzfP6biDZJAqmyensuhE7HjwYvlQk])
				del buLCgJMpUIA3rO56kaicRBTGq90['__COUNT__']
				del buLCgJMpUIA3rO56kaicRBTGq90['__GROUPS__']
				del buLCgJMpUIA3rO56kaicRBTGq90['__SEQUENCED_COLUMNS__']
				IOYAmcp4VlJbEUGfuzwdisBPK = list(buLCgJMpUIA3rO56kaicRBTGq90.keys())
				for Duty5SzAherY3mXvZ in IOYAmcp4VlJbEUGfuzwdisBPK:
					for fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL in buLCgJMpUIA3rO56kaicRBTGq90[Duty5SzAherY3mXvZ]:
						if gnf4eRjW20TOPZdIN in UfHDlNvZCp.lower(): XXQoCf6EJWPm9vYIG5edjpwubU.append((UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL))
					del buLCgJMpUIA3rO56kaicRBTGq90[Duty5SzAherY3mXvZ]
				del buLCgJMpUIA3rO56kaicRBTGq90
			else: IOYAmcp4VlJbEUGfuzwdisBPK = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'list',k3bu6Da0dsXGhJ8BV[NzfP6biDZJAqmyensuhE7HjwYvlQk],'__GROUPS__')
			for Duty5SzAherY3mXvZ in IOYAmcp4VlJbEUGfuzwdisBPK:
				try: Duty5SzAherY3mXvZ,st9uk8gcDL = Duty5SzAherY3mXvZ
				except: st9uk8gcDL = ''
				if gnf4eRjW20TOPZdIN in Duty5SzAherY3mXvZ.lower():
					if NzfP6biDZJAqmyensuhE7HjwYvlQk!=3: NNp9dg30FI5UfExQYBhVqbK2DcsMPm = Duty5SzAherY3mXvZ
					else:
						MpwmZOqiC8e4XPUoVQnIWBatKyu,oShjnYfiZO6zL7MVwl = Duty5SzAherY3mXvZ.split('__SERIES__')
						if gnf4eRjW20TOPZdIN in MpwmZOqiC8e4XPUoVQnIWBatKyu.lower(): NNp9dg30FI5UfExQYBhVqbK2DcsMPm = MpwmZOqiC8e4XPUoVQnIWBatKyu
						else: NNp9dg30FI5UfExQYBhVqbK2DcsMPm = oShjnYfiZO6zL7MVwl
					rkq0t28uEoJWOwS6lTMh5.append((Duty5SzAherY3mXvZ,NNp9dg30FI5UfExQYBhVqbK2DcsMPm,k3bu6Da0dsXGhJ8BV[NzfP6biDZJAqmyensuhE7HjwYvlQk],st9uk8gcDL))
			del IOYAmcp4VlJbEUGfuzwdisBPK
		rkq0t28uEoJWOwS6lTMh5 = set(rkq0t28uEoJWOwS6lTMh5)
		XXQoCf6EJWPm9vYIG5edjpwubU = set(XXQoCf6EJWPm9vYIG5edjpwubU)
		rkq0t28uEoJWOwS6lTMh5 = sorted(rkq0t28uEoJWOwS6lTMh5,reverse=False,key=lambda FUAvmM61BHoYRKeGsTwrXC4qlZP: FUAvmM61BHoYRKeGsTwrXC4qlZP[1])
		XXQoCf6EJWPm9vYIG5edjpwubU = sorted(XXQoCf6EJWPm9vYIG5edjpwubU,reverse=False,key=lambda FUAvmM61BHoYRKeGsTwrXC4qlZP: FUAvmM61BHoYRKeGsTwrXC4qlZP[0])
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,'SEARCH',(qqp1v0DYyPONaiu7VEte,gnf4eRjW20TOPZdIN),(rkq0t28uEoJWOwS6lTMh5,XXQoCf6EJWPm9vYIG5edjpwubU),iJnLmxA0ykozR98WXFQ4Ye3w)
	else: rkq0t28uEoJWOwS6lTMh5,XXQoCf6EJWPm9vYIG5edjpwubU = pyWkE2rh5uBN4G
	IOYAmcp4VlJbEUGfuzwdisBPK = len(rkq0t28uEoJWOwS6lTMh5)
	hY1wVXeNy8lubf0KUkvjEz = len(XXQoCf6EJWPm9vYIG5edjpwubU)
	WXU2APNzuivcGgq = int(YDqRFgKxH7J0)
	vOD4fL8RpW5xNy = max(0,(WXU2APNzuivcGgq-1)*100)
	MMdv8jVJQguHxWcOENyqteSFC = max(0,WXU2APNzuivcGgq*100)
	iV5duvB26JEHT8 = max(0,vOD4fL8RpW5xNy-IOYAmcp4VlJbEUGfuzwdisBPK)
	u2uOR6pmLiPvhlqeFgywIYjsB = max(0,MMdv8jVJQguHxWcOENyqteSFC-IOYAmcp4VlJbEUGfuzwdisBPK)
	for Duty5SzAherY3mXvZ,NNp9dg30FI5UfExQYBhVqbK2DcsMPm,z9zZQFSajxD1w2ly3EAgsucfJT5t,st9uk8gcDL in rkq0t28uEoJWOwS6lTMh5[vOD4fL8RpW5xNy:MMdv8jVJQguHxWcOENyqteSFC]:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+NNp9dg30FI5UfExQYBhVqbK2DcsMPm,z9zZQFSajxD1w2ly3EAgsucfJT5t,714,st9uk8gcDL,'1',Duty5SzAherY3mXvZ,'',{'folder':F8UNnjSZvpI})
	del rkq0t28uEoJWOwS6lTMh5
	for UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,st9uk8gcDL in XXQoCf6EJWPm9vYIG5edjpwubU[iV5duvB26JEHT8:u2uOR6pmLiPvhlqeFgywIYjsB]:
		d8rpJM2Im30jR7xFSN = eeiIspx5JaGYcH0zCu(apIVksn1FTuj6rbYhMPDLHS9N)
		GGKpqhAcPw9FHBvdfarRuySJ1Yl = 'live'
		if '.mkv' in d8rpJM2Im30jR7xFSN or 'VOD' in qqp1v0DYyPONaiu7VEte: GGKpqhAcPw9FHBvdfarRuySJ1Yl = 'video'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(GGKpqhAcPw9FHBvdfarRuySJ1Yl,t8SVWInB3P7+UfHDlNvZCp,apIVksn1FTuj6rbYhMPDLHS9N,715,st9uk8gcDL,'','','',{'folder':F8UNnjSZvpI})
	del XXQoCf6EJWPm9vYIG5edjpwubU
	eqg21COva5Ew3Fs4(F8UNnjSZvpI,YDqRFgKxH7J0,qqp1v0DYyPONaiu7VEte,719,IOYAmcp4VlJbEUGfuzwdisBPK+hY1wVXeNy8lubf0KUkvjEz,fEasiDJ3gHUoOqLRlNdp+'_NODIALOGS_')
	return
def eqg21COva5Ew3Fs4(F8UNnjSZvpI,YDqRFgKxH7J0,qqp1v0DYyPONaiu7VEte,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,ICUfvdYPXcFDGs3g6jmktAW9,hulSHFUcXsaVQGTn8r9zMkNPIwgvo):
	if not YDqRFgKxH7J0: YDqRFgKxH7J0 = '1'
	if YDqRFgKxH7J0!='1': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'صفحة '+str(1),qqp1v0DYyPONaiu7VEte,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,'',str(1),hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',{'folder':F8UNnjSZvpI})
	if not ICUfvdYPXcFDGs3g6jmktAW9: ICUfvdYPXcFDGs3g6jmktAW9 = 0
	fdgZNlCO9RVcW = int(ICUfvdYPXcFDGs3g6jmktAW9/100)+1
	for WXU2APNzuivcGgq in range(2,fdgZNlCO9RVcW):
		vvUyK4qrOIYt = (WXU2APNzuivcGgq%10==0 or int(YDqRFgKxH7J0)-4<WXU2APNzuivcGgq<int(YDqRFgKxH7J0)+4)
		SsTqIUzKMy6Jgw2lF = (vvUyK4qrOIYt and int(YDqRFgKxH7J0)-40<WXU2APNzuivcGgq<int(YDqRFgKxH7J0)+40)
		if str(WXU2APNzuivcGgq)!=YDqRFgKxH7J0 and (WXU2APNzuivcGgq%100==0 or SsTqIUzKMy6Jgw2lF):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'صفحة '+str(WXU2APNzuivcGgq),qqp1v0DYyPONaiu7VEte,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,'',str(WXU2APNzuivcGgq),hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',{'folder':F8UNnjSZvpI})
	if str(fdgZNlCO9RVcW)!=YDqRFgKxH7J0: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',t8SVWInB3P7+'أخر صفحة '+str(fdgZNlCO9RVcW),qqp1v0DYyPONaiu7VEte,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,'',str(fdgZNlCO9RVcW),hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',{'folder':F8UNnjSZvpI})
	return
def RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,qqp1v0DYyPONaiu7VEte):
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = zr7JxlDyak06p9Wn.replace('___','_'+F8UNnjSZvpI)
	return GU76KHh1IfEPgo3bWkJO8YjM0D42
def eRrpZlnzoM9WGf(F8UNnjSZvpI):
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'')
	z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('center','','','رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if z3rhpEtd7KLGQZ64XonmW19HSJfAc!=1: return False
	TJ5FSbBKkOafQEGLg2XldcZ4Yjqh(F8UNnjSZvpI,False)
	TWY75GVglZke2bC = [0]
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
		BzoupqlePmISnMK7AgH29sGa = BBwb2NzsHE.getSetting('av.m3u.url_'+F8UNnjSZvpI+'_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
		if BzoupqlePmISnMK7AgH29sGa: fsBAvMwadHmq2eyzTL1cJR8i76(F8UNnjSZvpI,str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
		TWY75GVglZke2bC.append(0)
	for qqp1v0DYyPONaiu7VEte in kxteHPOwy8n0pC64mGVYLFTf:
		TGDoydCz43Yvh7ejWJOic0Hu,BgeU9l7tpuFkZ,Dgs1xNX9hopmitCITly0arz6YLvEA,UUbOp3J1venqAyWTHjXlV0xSfGwtN,uxnBAcW0CMLKaIXs9qN5FGl = 0,{},[],[],[]
		for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
			z9zZQFSajxD1w2ly3EAgsucfJT5t = qqp1v0DYyPONaiu7VEte+'_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx)
			EVNb6hR5sq8u3LarA0vQGcKi = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'dict',z9zZQFSajxD1w2ly3EAgsucfJT5t)
			try:
				GPr0uA3xOZ4TmUytg6 = EVNb6hR5sq8u3LarA0vQGcKi['__GROUPS__']
				LFuTwUYZScbJ6esjC9B = EVNb6hR5sq8u3LarA0vQGcKi['__COUNT__']
			except: GPr0uA3xOZ4TmUytg6,LFuTwUYZScbJ6esjC9B = [],'0'
			for xKmtSGij6gOZk7FLP4J0WYINVud in GPr0uA3xOZ4TmUytg6:
				Duty5SzAherY3mXvZ,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO = xKmtSGij6gOZk7FLP4J0WYINVud
				buLCgJMpUIA3rO56kaicRBTGq90 = EVNb6hR5sq8u3LarA0vQGcKi[Duty5SzAherY3mXvZ]
				if Duty5SzAherY3mXvZ not in UUbOp3J1venqAyWTHjXlV0xSfGwtN:
					UUbOp3J1venqAyWTHjXlV0xSfGwtN.append(Duty5SzAherY3mXvZ)
					uxnBAcW0CMLKaIXs9qN5FGl.append(xKmtSGij6gOZk7FLP4J0WYINVud)
					BgeU9l7tpuFkZ[Duty5SzAherY3mXvZ] = []
				BgeU9l7tpuFkZ[Duty5SzAherY3mXvZ] += buLCgJMpUIA3rO56kaicRBTGq90
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(GU76KHh1IfEPgo3bWkJO8YjM0D42,z9zZQFSajxD1w2ly3EAgsucfJT5t)
			pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,z9zZQFSajxD1w2ly3EAgsucfJT5t,'__COUNT__',LFuTwUYZScbJ6esjC9B,iJnLmxA0ykozR98WXFQ4Ye3w)
			TWY75GVglZke2bC[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx] += int(LFuTwUYZScbJ6esjC9B)
		for Duty5SzAherY3mXvZ in UUbOp3J1venqAyWTHjXlV0xSfGwtN:
			buLCgJMpUIA3rO56kaicRBTGq90 = list(set(BgeU9l7tpuFkZ[Duty5SzAherY3mXvZ]))
			if 'SORTED' in qqp1v0DYyPONaiu7VEte: buLCgJMpUIA3rO56kaicRBTGq90 = sorted(buLCgJMpUIA3rO56kaicRBTGq90,reverse=False,key=lambda key: key[1].lower())
			TGDoydCz43Yvh7ejWJOic0Hu += len(buLCgJMpUIA3rO56kaicRBTGq90)
			Dgs1xNX9hopmitCITly0arz6YLvEA.append(buLCgJMpUIA3rO56kaicRBTGq90)
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,qqp1v0DYyPONaiu7VEte,'__COUNT__',str(TGDoydCz43Yvh7ejWJOic0Hu),iJnLmxA0ykozR98WXFQ4Ye3w)
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,qqp1v0DYyPONaiu7VEte,'__GROUPS__',uxnBAcW0CMLKaIXs9qN5FGl,iJnLmxA0ykozR98WXFQ4Ye3w)
		pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,qqp1v0DYyPONaiu7VEte,UUbOp3J1venqAyWTHjXlV0xSfGwtN,Dgs1xNX9hopmitCITly0arz6YLvEA,iJnLmxA0ykozR98WXFQ4Ye3w,True)
	FFc0JOb8GvxzMEBSwI = False
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
		if int(TWY75GVglZke2bC[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx])>0:
			BzoupqlePmISnMK7AgH29sGa = BBwb2NzsHE.getSetting('av.m3u.url_'+F8UNnjSZvpI+'_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
			pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,'LINK_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx),'__LINK__',BzoupqlePmISnMK7AgH29sGa,iJnLmxA0ykozR98WXFQ4Ye3w)
			FFc0JOb8GvxzMEBSwI = True
	pRxmMktYgHCjWXf182(GU76KHh1IfEPgo3bWkJO8YjM0D42,'DUMMY','__DUMMY__','DUMMY',iJnLmxA0ykozR98WXFQ4Ye3w)
	if not FFc0JOb8GvxzMEBSwI:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	mmLX1BP7VxJiIYAo82cabFC4W(F8UNnjSZvpI)
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin('Container.Refresh')
	return True
def mmLX1BP7VxJiIYAo82cabFC4W(F8UNnjSZvpI):
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'')
	if not dzgJhQfsE7wOD3AU(F8UNnjSZvpI,True): return
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
		BzoupqlePmISnMK7AgH29sGa = cLozpXkSg1qU3VthuFbNyQTns(GU76KHh1IfEPgo3bWkJO8YjM0D42,'str','LINK_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx),'__LINK__')
		if BzoupqlePmISnMK7AgH29sGa: w4h6AKMDfX7jeGE = pyrOECsb792gGHn(F8UNnjSZvpI,str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
	pyrOECsb792gGHn(F8UNnjSZvpI,'')
	return
def TJ5FSbBKkOafQEGLg2XldcZ4Yjqh(F8UNnjSZvpI,Jjlf8RwAikOqePtvbW0IXudhF36Z):
	if Jjlf8RwAikOqePtvbW0IXudhF36Z:
		z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('center','','','مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if z3rhpEtd7KLGQZ64XonmW19HSJfAc!=1: return
	GU76KHh1IfEPgo3bWkJO8YjM0D42 = RICZxDOjhpUqtBi9vMS8Ef27(F8UNnjSZvpI,'')
	try: A73K6zLXIgFROeCHJQi0Pbos.remove(GU76KHh1IfEPgo3bWkJO8YjM0D42)
	except: pass
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in range(1,ZUQFS8NrIA6hH+1):
		TTkmwqXoLyID837SW9MtlxAg = dd4ubU1pBVFhms56Y.replace('___','_'+F8UNnjSZvpI+'_'+str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
		JZy81LiwjobPh69Mt0pHeIvk = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,TTkmwqXoLyID837SW9MtlxAg)
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(JZy81LiwjobPh69Mt0pHeIvk)
		except: pass
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_'+F8UNnjSZvpI)
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if Jjlf8RwAikOqePtvbW0IXudhF36Z:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin('Container.Refresh')
	return
def LFlmRe9BnxA2SNiHU0T(F8UNnjSZvpI):
	dDWfiwEZ3SGJ = BBwb2NzsHE.getSetting('av.language.provider')
	Zr56PK0QX7jRhlGizLItsbwd3CBugn = BBwb2NzsHE.getSetting('av.language.code')
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'MENUS_CACHE_'+dDWfiwEZ3SGJ+'_'+Zr56PK0QX7jRhlGizLItsbwd3CBugn,'%_MU'+F8UNnjSZvpI+'_%')
	return
exvTZp1FXcqtrUKnal2Pd = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
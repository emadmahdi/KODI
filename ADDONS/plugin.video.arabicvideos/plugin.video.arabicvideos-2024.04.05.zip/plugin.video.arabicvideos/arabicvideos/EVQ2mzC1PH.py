# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'EGYBEST1'
eMlwAzaLSj8ZEQ3txIGP = '_EB1_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['مكتبتي','ايجي بست']
def HYWukw3pL2oMzPK4(mode,url,vYpMA3CxgcyR4VZJh,text):
	if   mode==770: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==771: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh)
	elif mode==772: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==773: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==774: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'FULL_FILTER___'+text)
	elif mode==775: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'DEFINED_FILTER___'+text)
	elif mode==776: mL7BVKcSygkuoPbWlEF4YD = gaJo6Sm8HMP2jKrnBd(url,vYpMA3CxgcyR4VZJh)
	elif mode==779: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text,url)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',779,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','EGYBEST1-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('nav-list(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,771)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-article(.*?)social-box',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('main-title.*?">(.*?)<.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5 in items:
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,771,'','mainmenu')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-menu(.*?)</div></div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,771)
	return YBEsLq8gVw629cMGQP1T
def gaJo6Sm8HMP2jKrnBd(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST1-SEASONS_EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-article".*?">(.*?)<(.*?)article',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME,items = '','',[]
		for name,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			if 'حلقات' in name: l7PwAhTqWVUKME = mvgk7pP8Fw6heMSWd5oXn9itl
			if 'مواسم' in name: YbPTE4rKt3cmIuz6WFdi = mvgk7pP8Fw6heMSWd5oXn9itl
		if YbPTE4rKt3cmIuz6WFdi and not type:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',YbPTE4rKt3cmIuz6WFdi,JJDtX1PZyIgN2T.DOTALL)
			if len(items)>1:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,776,ggdRiBo3smurLUGO,'season')
		if l7PwAhTqWVUKME and len(items)<2:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
			if items:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,773,ggdRiBo3smurLUGO)
			else:
				items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,773)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST1-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items,NbI4DJ3rWOwRj,t9hx8YmpUDaFivZ = [],False,False
	if not type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-content(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,771,'','submenu')
				NbI4DJ3rWOwRj = True
	if not type and 'p=' not in url:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('searchform(.*?)</form>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			if NbI4DJ3rWOwRj: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',url,775,'','filter')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',url,774,'','filter')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث',url,779)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
			t9hx8YmpUDaFivZ = True
	if not NbI4DJ3rWOwRj:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('blocks(.*?)article',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.strip('\n')
				wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
				if '/serie/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,776,ggdRiBo3smurLUGO,'season')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,773,ggdRiBo3smurLUGO)
			vYpMA3CxgcyR4VZJh = '1'
			if 'p=' in url: url,vYpMA3CxgcyR4VZJh = url.split('p=',1)
			LxomZnH9Ky = '&' if '?' in url else '?'
			url = url+LxomZnH9Ky
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(vYpMA3CxgcyR4VZJh)+1)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الصفحة التالية',url,771)
			elif vYpMA3CxgcyR4VZJh!='1':
				url = url+'p='+str(int(vYpMA3CxgcyR4VZJh)-1)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الصفحة السابقة',url,771)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'','','','','EGYBEST1-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('<label>التصنيف</label>.*?">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	u6jVYl28ZRT7UXzwxJH3va,pB8XANf71vaPJsedkWVIc5,uiUZAmal9HPqQSo = [],[],[]
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('video-play-iframe.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
			uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named=__embed______'+FVsLwz1tAH(url))
	items = JJDtX1PZyIgN2T.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5 in items:
		if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
			uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
			y2nBfLCjDoXkKiwb8WV6 = y2nBfLCjDoXkKiwb8WV6.strip(' ')
			RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__download____'+y2nBfLCjDoXkKiwb8WV6+'__'+FVsLwz1tAH(url))
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search,url=''):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search: search = GVfnMyZxiRI()
	if not search: return
	s2hzmL48wFudNE5 = search.replace(' ','%20')
	if not url: url = kU2ZXSViB3wLANOz8bH+'/search?query='+s2hzmL48wFudNE5
	else: url = url+'?title='+s2hzmL48wFudNE5+'&genre=&year=&lang='
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
def LWTgVSqXyoz26Hi931Ks(url):
	url = url.split('/smartemadfilter?')[0]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','EGYBEST1-GET_FILTERS_BLOCKS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	KKMpOd0rWFRNPtun5cgY6 = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('form-row(.*?)</form>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		TAiIlqcgn0hW5fd,UGN4yb8Wn9AitV,Ns3LKUFY21aQVf7e = zip(*KKMpOd0rWFRNPtun5cgY6)
		KKMpOd0rWFRNPtun5cgY6 = zip(UGN4yb8Wn9AitV,TAiIlqcgn0hW5fd,Ns3LKUFY21aQVf7e)
	return KKMpOd0rWFRNPtun5cgY6
def ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl):
	items = JJDtX1PZyIgN2T.findall('value="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return items
def QQZgeAI91wf8HY5jtyMb6D(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
BBaZ5SyxRQ8njIgt6mOAU4N10irM = ['year','lang','genre']
Mqv3QIiNgfUXo18h5AeLOZrzSERa2d = ['year','lang','genre']
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='DEFINED_FILTER':
		if Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0]
		for ggjo5zu7yCiIOhrb in range(len(Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[0:-1])):
			if Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'all')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
	elif type=='FULL_FILTER':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO: oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'all')
		if not oju0BC1rJO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+oju0BC1rJO
		kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',kHWT0XY2S6apruwxiB8FDl1,771,'','filter')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',kHWT0XY2S6apruwxiB8FDl1,771,'','filter')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KKMpOd0rWFRNPtun5cgY6 = LWTgVSqXyoz26Hi931Ks(url)
	dict = {}
	for name,eYFHT1CfSqZK,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		name = name.replace('كل ','')
		items = ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='DEFINED_FILTER':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<2:
				if eYFHT1CfSqZK==Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-1]:
					kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
					d2JXnUMPmgsKBQqCE58lkZ(kHWT0XY2S6apruwxiB8FDl1)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'DEFINED_FILTER___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				if eYFHT1CfSqZK==Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-1]:
					kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',kHWT0XY2S6apruwxiB8FDl1,771,'','filter')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,775,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='FULL_FILTER':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع :'+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,774,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if not Y3YqSmycrIWksoH5N0MvC: continue
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'#+dict[eYFHT1CfSqZK]['0']
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'+name
			if type=='FULL_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,774,'','',oy5AiZKfC86qITkYWL)
			elif type=='DEFINED_FILTER' and Mqv3QIiNgfUXo18h5AeLOZrzSERa2d[-2]+'=' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
				kHWT0XY2S6apruwxiB8FDl1 = QQZgeAI91wf8HY5jtyMb6D(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,771,'','filter')
			elif type=='DEFINED_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,775,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.replace('=&','=0&')
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	for key in BBaZ5SyxRQ8njIgt6mOAU4N10irM:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.replace('=0','=')
	return P1yxuh7MAmvSRVqLZcW6tY3
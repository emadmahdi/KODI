# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = cg94WALw5orUhvtHSfNO(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
eMlwAzaLSj8ZEQ3txIGP = KylMx0kfTOrG(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
wMO4E2N7GjPvarxft = A73K6zLXIgFROeCHJQi0Pbos.path.join(I4D30chjOT,A6Iyo7eXrq2RtMmDxWj(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
Qs9NBkgKdaJ4uEI1SlMo = A73K6zLXIgFROeCHJQi0Pbos.path.join(I4D30chjOT,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
E3p9v4sqxKNPOZg0cdzjhf2 = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,CC4UDLW6brf(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
j7MW0pngNeR4klmv5cXzGTbyhos = yOvxDpJofVusbcXRAWZk23aBjrHw
SPBT6hjvVc2muRtoAqb3yx1 = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
WaHRs2hYFxZ1rQzK9DIOfew = WfgnOq9Fd4lhMSQpK5(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
LLQ5iTPx9cqkM273bHWKuOtf81Nl = vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
ihtGnmd6IXCywFTz = WfgnOq9Fd4lhMSQpK5(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
g2j5671VMxsp = vdHRKkIgTp56Je1OuNo(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
cbAM0R6lq2JWIDgPNLYXifShHtGoO = tvdQHb10PhNmuy6(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def HYWukw3pL2oMzPK4(mode):
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠹࠷࠴ࣉ"): mL7BVKcSygkuoPbWlEF4YD = d81dXNpsuE0I6iZVRByTePUFrCWJx()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==tvdQHb10PhNmuy6(u"࠺࠸࠶࣊"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(wMO4E2N7GjPvarxft,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡖࡵࡹࡪࣳ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡖࡵࡹࡪࣳ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==Vt4ELHXZP6(u"࠻࠹࠸࣋"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(Qs9NBkgKdaJ4uEI1SlMo,vdHRKkIgTp56Je1OuNo(u"ࡗࡶࡺ࡫ࣴ"),vdHRKkIgTp56Je1OuNo(u"ࡗࡶࡺ࡫ࣴ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==b098bsyjUud(u"࠼࠺࠳࣌"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(E3p9v4sqxKNPOZg0cdzjhf2,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡋࡧ࡬ࡴࡧࣶ"),u2NDjURZVHlmdc0(u"ࡘࡷࡻࡥࣵ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==VVtQk9vwe7(u"࠽࠴࠵࣍"): mL7BVKcSygkuoPbWlEF4YD = awfs10CbPkY3(j7MW0pngNeR4klmv5cXzGTbyhos,cg94WALw5orUhvtHSfNO(u"࡚ࡲࡶࡧࣷ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠷࠵࠷࣎"): mL7BVKcSygkuoPbWlEF4YD = rCxcGNqpHulzyFVUvi2WaBdLsTOb3(vlW6K1g8Xo35mPYbyO2GS(u"ࡔࡳࡷࡨࣸ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸࠷࠳࣏"): mL7BVKcSygkuoPbWlEF4YD = Stlp8daXHnOgf()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠹࠸࠵࣐"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(SPBT6hjvVc2muRtoAqb3yx1,ebT9xRB63E(u"ࡈࡤࡰࡸ࡫ࣺ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡕࡴࡸࡩࣹ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vlW6K1g8Xo35mPYbyO2GS(u"࠺࠹࠷࣑"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(WaHRs2hYFxZ1rQzK9DIOfew,vlW6K1g8Xo35mPYbyO2GS(u"ࡊࡦࡲࡳࡦࣼ"),KylMx0kfTOrG(u"ࡗࡶࡺ࡫ࣻ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==tjoHEAGv2XkrMBsVfCyp5U(u"࠻࠺࠹࣒"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(LLQ5iTPx9cqkM273bHWKuOtf81Nl,vdHRKkIgTp56Je1OuNo(u"ࡌࡡ࡭ࡵࡨࣾ"),tjoHEAGv2XkrMBsVfCyp5U(u"࡙ࡸࡵࡦࣽ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==cg94WALw5orUhvtHSfNO(u"࠼࠻࠴࣓"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(ihtGnmd6IXCywFTz,G5TxeI0ND4ztC6(u"ࡇࡣ࡯ࡷࡪऀ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡔࡳࡷࡨࣿ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==u2NDjURZVHlmdc0(u"࠽࠵࠶ࣔ"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(g2j5671VMxsp,KylMx0kfTOrG(u"ࡉࡥࡱࡹࡥं"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࡖࡵࡹࡪँ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷࠶࠸ࣕ"): mL7BVKcSygkuoPbWlEF4YD = IN1vbO8YfAu05Qyi7jMVwkxSE(cbAM0R6lq2JWIDgPNLYXifShHtGoO,vlW6K1g8Xo35mPYbyO2GS(u"ࡋࡧ࡬ࡴࡧऄ"),oh1JUWa3LdnqTpz5(u"ࡘࡷࡻࡥः"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vlW6K1g8Xo35mPYbyO2GS(u"࠸࠷࠺ࣖ"): mL7BVKcSygkuoPbWlEF4YD = rvKjszmY3CL1(vdHRKkIgTp56Je1OuNo(u"࡚ࡲࡶࡧअ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==CC4UDLW6brf(u"࠹࠸࠼ࣗ"): mL7BVKcSygkuoPbWlEF4YD = yB6NE1Ccns()
	else: mL7BVKcSygkuoPbWlEF4YD = A6Iyo7eXrq2RtMmDxWj(u"ࡆࡢ࡮ࡶࡩआ")
	return mL7BVKcSygkuoPbWlEF4YD
def d81dXNpsuE0I6iZVRByTePUFrCWJx():
	Lm21QWgpNZP,qzJRCvi39BEVK8 = Ei1lhA7yBXzaYVIfgNHjb(wMO4E2N7GjPvarxft)
	mQk8Fbyi9SnJa5T7qrPe,bev7ECHhWNuliZ4RwYOT = Ei1lhA7yBXzaYVIfgNHjb(Qs9NBkgKdaJ4uEI1SlMo)
	lcFAIVuYtW0a6r2m3HRhMikx7,Fh1Cti92ZQXVkPy7l6SWfnOgE8 = Ei1lhA7yBXzaYVIfgNHjb(E3p9v4sqxKNPOZg0cdzjhf2)
	lWB1JxrD2bInw8P3CfzgOYRS,uUiLkqKobsCO5RzTHr = eexb5wHNQEphIrs3WCBZjYcoTMu0(j7MW0pngNeR4klmv5cXzGTbyhos)
	lWB1JxrD2bInw8P3CfzgOYRS -= tvdQHb10PhNmuy6(u"࠶࠺࠽࠼࠴ࣘ")
	uUiLkqKobsCO5RzTHr -= jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠵ࣙ")
	AqnfldksY2OgQtaEC = CC4UDLW6brf(u"ࠩࠣࠬࠬࠌ")+YYPvXKrj8CMHVEdis43l9WwqA(Lm21QWgpNZP)+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࠤ࠲ࠦࠧࠍ")+str(qzJRCvi39BEVK8)+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	wfvQKiYRlFAtu1yco = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࠦࠨࠨࠏ")+YYPvXKrj8CMHVEdis43l9WwqA(mQk8Fbyi9SnJa5T7qrPe)+trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠠ࠮ࠢࠪࠐ")+str(bev7ECHhWNuliZ4RwYOT)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	qdK0TWlyLOho7gVMja62xnD = b46fBrugtPDSYspzMQIx(u"ࠨࠢࠫࠫࠒ")+YYPvXKrj8CMHVEdis43l9WwqA(lcFAIVuYtW0a6r2m3HRhMikx7)+DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(Fh1Cti92ZQXVkPy7l6SWfnOgE8)+DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	zrYOL3BnADKtljbhIC0i4Ep = Vt4ELHXZP6(u"ࠫࠥ࠮ࠧࠕ")+YYPvXKrj8CMHVEdis43l9WwqA(lWB1JxrD2bInw8P3CfzgOYRS)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠯ࠧࠖ")
	V781Gfb4DCSPkEXjMZBUWNh = Lm21QWgpNZP+mQk8Fbyi9SnJa5T7qrPe+lcFAIVuYtW0a6r2m3HRhMikx7+lWB1JxrD2bInw8P3CfzgOYRS
	LFuTwUYZScbJ6esjC9B = qzJRCvi39BEVK8+bev7ECHhWNuliZ4RwYOT+Fh1Cti92ZQXVkPy7l6SWfnOgE8+uUiLkqKobsCO5RzTHr
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = A6Iyo7eXrq2RtMmDxWj(u"࠭ࠠࠩࠩࠗ")+YYPvXKrj8CMHVEdis43l9WwqA(V781Gfb4DCSPkEXjMZBUWNh)+tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠡ࠯ࠣࠫ࠘")+str(LFuTwUYZScbJ6esjC9B)+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(A6Iyo7eXrq2RtMmDxWj(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),eMlwAzaLSj8ZEQ3txIGP+G5TxeI0ND4ztC6(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+hulSHFUcXsaVQGTn8r9zMkNPIwgvo,KylMx0kfTOrG(u"ࠫࠬࠜ"),u2NDjURZVHlmdc0(u"࠼࠺࠵ࣚ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡲࡩ࡯࡭ࠪࠝ"),DItWNMaLOZ146CubYk8lfAwTy(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨࠞ"),Yr0wo7FaSHx(u"ࠧࠨࠟ"),xmTX9Aeidq8cVhY(u"࠿࠹࠺࠻ࣛ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),eMlwAzaLSj8ZEQ3txIGP+Yr0wo7FaSHx(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨࠡ")+AqnfldksY2OgQtaEC,vdHRKkIgTp56Je1OuNo(u"ࠪࠫࠢ"),tjoHEAGv2XkrMBsVfCyp5U(u"࠷࠵࠳ࣜ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(oh1JUWa3LdnqTpz5(u"ࠫࡱ࡯࡮࡬ࠩࠣ"),eMlwAzaLSj8ZEQ3txIGP+uEed4OSxm7hBq9Vvky6QjHwWC(u"๋ࠬำฮࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠬࠤ")+wfvQKiYRlFAtu1yco,vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠧࠥ"),VVtQk9vwe7(u"࠸࠶࠵ࣝ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(oh1JUWa3LdnqTpz5(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),eMlwAzaLSj8ZEQ3txIGP+Wbwj0o5gsXQ8F2f(u"ࠨ็ึัࠥอไึ๊ิࠤฬ๊โะ์่อࠬࠧ")+qdK0TWlyLOho7gVMja62xnD,VVtQk9vwe7(u"ࠩࠪࠨ"),KylMx0kfTOrG(u"࠹࠷࠷ࣞ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(xmTX9Aeidq8cVhY(u"ࠪࡰ࡮ࡴ࡫ࠨࠩ"),eMlwAzaLSj8ZEQ3txIGP+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭ࠪ")+zrYOL3BnADKtljbhIC0i4Ep,tvdQHb10PhNmuy6(u"ࠬ࠭ࠫ"),KylMx0kfTOrG(u"࠺࠸࠹ࣟ"))
	BBwb2NzsHE.setSetting(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࠬ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࠨ࠭"))
	return
def Stlp8daXHnOgf():
	u32EqOCDZrN = KylMx0kfTOrG(u"ࡖࡵࡹࡪई") if CC4UDLW6brf(u"ࠨ࠱ࠪ࠮") in qvy1SuIXLZ2g0P35DUQN6n8G7 else NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡇࡣ࡯ࡷࡪइ")
	if not u32EqOCDZrN:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࠪ࠯"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫ࠰"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),WfgnOq9Fd4lhMSQpK5(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯๋ࠢะ์อาไࠢ็๎ุࠦๅ็้ࠢ์฾๊้่ࠦๆืࠬ࠲"))
		return
	y9sfZeW5tbQpkPHKxg7jDS = BBwb2NzsHE.getSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ࠳"))
	if not y9sfZeW5tbQpkPHKxg7jDS: yB6NE1Ccns()
	Lm21QWgpNZP,qzJRCvi39BEVK8 = Ei1lhA7yBXzaYVIfgNHjb(SPBT6hjvVc2muRtoAqb3yx1)
	mQk8Fbyi9SnJa5T7qrPe,bev7ECHhWNuliZ4RwYOT = Ei1lhA7yBXzaYVIfgNHjb(WaHRs2hYFxZ1rQzK9DIOfew)
	lcFAIVuYtW0a6r2m3HRhMikx7,Fh1Cti92ZQXVkPy7l6SWfnOgE8 = Ei1lhA7yBXzaYVIfgNHjb(LLQ5iTPx9cqkM273bHWKuOtf81Nl)
	lWB1JxrD2bInw8P3CfzgOYRS,uUiLkqKobsCO5RzTHr = Ei1lhA7yBXzaYVIfgNHjb(ihtGnmd6IXCywFTz)
	mxL52fSTIHdsRF,Qw7fJFn9AMIK = Ei1lhA7yBXzaYVIfgNHjb(g2j5671VMxsp)
	sNZDdzXSigc2,OhdNsUbWKyFkcvV1A2GuwnaYl = Ei1lhA7yBXzaYVIfgNHjb(cbAM0R6lq2JWIDgPNLYXifShHtGoO)
	AqnfldksY2OgQtaEC = KylMx0kfTOrG(u"ࠧࠡࠪࠪ࠴")+YYPvXKrj8CMHVEdis43l9WwqA(Lm21QWgpNZP)+oh1JUWa3LdnqTpz5(u"ࠨࠢ࠰ࠤࠬ࠵")+str(qzJRCvi39BEVK8)+vdHRKkIgTp56Je1OuNo(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	wfvQKiYRlFAtu1yco = cg94WALw5orUhvtHSfNO(u"ࠪࠤ࠭࠭࠷")+YYPvXKrj8CMHVEdis43l9WwqA(mQk8Fbyi9SnJa5T7qrPe)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠥ࠳ࠠࠨ࠸")+str(bev7ECHhWNuliZ4RwYOT)+Yr0wo7FaSHx(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	qdK0TWlyLOho7gVMja62xnD = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࠠࠩࠩ࠺")+YYPvXKrj8CMHVEdis43l9WwqA(lcFAIVuYtW0a6r2m3HRhMikx7)+vlW6K1g8Xo35mPYbyO2GS(u"ࠧࠡ࠯ࠣࠫ࠻")+str(Fh1Cti92ZQXVkPy7l6SWfnOgE8)+vlW6K1g8Xo35mPYbyO2GS(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	zrYOL3BnADKtljbhIC0i4Ep = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࠣࠬࠬ࠽")+YYPvXKrj8CMHVEdis43l9WwqA(lWB1JxrD2bInw8P3CfzgOYRS)+oh1JUWa3LdnqTpz5(u"ࠪࠤ࠲ࠦࠧ࠾")+str(uUiLkqKobsCO5RzTHr)+Yr0wo7FaSHx(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	SZjpUmAh60IPHnVb73a514gf = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࠦࠨࠨࡀ")+YYPvXKrj8CMHVEdis43l9WwqA(mxL52fSTIHdsRF)+Vt4ELHXZP6(u"࠭ࠠ࠮ࠢࠪࡁ")+str(Qw7fJFn9AMIK)+CC4UDLW6brf(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡂ")
	GM4wxXHI8J2fKL3ngmBpyPzr7uso = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࠢࠫࠫࡃ")+YYPvXKrj8CMHVEdis43l9WwqA(sNZDdzXSigc2)+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࠣ࠱ࠥ࠭ࡄ")+str(OhdNsUbWKyFkcvV1A2GuwnaYl)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡅ")
	V781Gfb4DCSPkEXjMZBUWNh = Lm21QWgpNZP+mQk8Fbyi9SnJa5T7qrPe+lcFAIVuYtW0a6r2m3HRhMikx7+lWB1JxrD2bInw8P3CfzgOYRS+mxL52fSTIHdsRF+sNZDdzXSigc2
	LFuTwUYZScbJ6esjC9B = qzJRCvi39BEVK8+bev7ECHhWNuliZ4RwYOT+Fh1Cti92ZQXVkPy7l6SWfnOgE8+uUiLkqKobsCO5RzTHr+Qw7fJFn9AMIK+OhdNsUbWKyFkcvV1A2GuwnaYl
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠥ࠮ࠧࡆ")+YYPvXKrj8CMHVEdis43l9WwqA(V781Gfb4DCSPkEXjMZBUWNh)+Vt4ELHXZP6(u"ࠬࠦ࠭ࠡࠩࡇ")+str(LFuTwUYZScbJ6esjC9B)+pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡈ")
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧ࡭࡫ࡱ࡯ࠬࡉ"),eMlwAzaLSj8ZEQ3txIGP+KylMx0kfTOrG(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫࡊ"),Wbwj0o5gsXQ8F2f(u"ࠩࠪࡋ"),CC4UDLW6brf(u"࠻࠺࠾࣠"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(WfgnOq9Fd4lhMSQpK5(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),eMlwAzaLSj8ZEQ3txIGP+tvdQHb10PhNmuy6(u"ู๊ࠫอࠡษ็ะ๊๐ูࠨࡍ")+hulSHFUcXsaVQGTn8r9zMkNPIwgvo,DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࠭ࡎ"),Yr0wo7FaSHx(u"࠼࠻࠷࣡"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(cg94WALw5orUhvtHSfNO(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),VVtQk9vwe7(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡐ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࠩࡑ"),CC4UDLW6brf(u"࠿࠹࠺࠻࣢"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(vlW6K1g8Xo35mPYbyO2GS(u"ࠩ࡯࡭ࡳࡱࠧࡒ"),eMlwAzaLSj8ZEQ3txIGP+ebT9xRB63E(u"ุ้ࠪำࠠๆๆไหฯࠦࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪࡓ")+AqnfldksY2OgQtaEC,tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠬࡔ"),CC4UDLW6brf(u"࠷࠶࠳ࣣ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),eMlwAzaLSj8ZEQ3txIGP+vdHRKkIgTp56Je1OuNo(u"࠭ๅิฯ้้ࠣ็วหࠢࡧࡶࡴࡶࡢࡰࡺࠪࡖ")+wfvQKiYRlFAtu1yco,Wbwj0o5gsXQ8F2f(u"ࠧࠨࡗ"),tvdQHb10PhNmuy6(u"࠸࠷࠵ࣤ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨ࡮࡬ࡲࡰ࠭ࡘ"),eMlwAzaLSj8ZEQ3txIGP+u2NDjURZVHlmdc0(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴ࡙ࠩ")+qdK0TWlyLOho7gVMja62xnD,b098bsyjUud(u"࡚ࠪࠫ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠹࠸࠷ࣥ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(oh1JUWa3LdnqTpz5(u"ࠫࡱ࡯࡮࡬࡛ࠩ"),eMlwAzaLSj8ZEQ3txIGP+vlW6K1g8Xo35mPYbyO2GS(u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫࡬࡫ࡲࠨ࡜")+zrYOL3BnADKtljbhIC0i4Ep,ebT9xRB63E(u"࠭ࠧ࡝"),WfgnOq9Fd4lhMSQpK5(u"࠺࠹࠹ࣦ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(Wbwj0o5gsXQ8F2f(u"ࠧ࡭࡫ࡱ࡯ࠬ࡞"),eMlwAzaLSj8ZEQ3txIGP+Vt4ELHXZP6(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࡟")+SZjpUmAh60IPHnVb73a514gf,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࠪࡠ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠻࠺࠻ࣧ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(Vt4ELHXZP6(u"ࠪࡰ࡮ࡴ࡫ࠨࡡ"),eMlwAzaLSj8ZEQ3txIGP+DItWNMaLOZ146CubYk8lfAwTy(u"ู๊ࠫอࠡ็็ๅฬะࠠࡢࡰࡵࠫࡢ")+GM4wxXHI8J2fKL3ngmBpyPzr7uso,xmTX9Aeidq8cVhY(u"ࠬ࠭ࡣ"),Yr0wo7FaSHx(u"࠼࠻࠶ࣨ"))
	BBwb2NzsHE.setSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡤ"),tvdQHb10PhNmuy6(u"ࠧࠨࡥ"))
	return
def yB6NE1Ccns():
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࠩࡦ"),oh1JUWa3LdnqTpz5(u"ࠩࠪࡧ"),C0CbfZuXJM(u"ࠪࠫࡨ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡩ"),Vt4ELHXZP6(u"๊ࠬใ๋ࠢํ฽๊๊ࠠศๆอ๊฽๐แࠡ฻้ำ่ࠦ࠮࠯ࠢหี๋อๅอࠢ฼้ฬีࠠษฯสะฮࠦลๅ๋ࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษห่้๋ࠣไโษอࠤํอไๆฮ็ำฬะࠠศๆอ๎ู่ࠥโࠢํุ้ำ็ศࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡว฼฻ฬว่ࠠา๊ࠤฬ๊ัฯืฬࠤฬ๊ย็ࠢยࠥࠬࡪ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==-YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠷ࣩ"): return
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6:
		import subprocess as T4LR589r62CmGhOoVzsANQFUdbfY
		try:
			T4LR589r62CmGhOoVzsANQFUdbfY.Popen(oh1JUWa3LdnqTpz5(u"࠭ࡳࡶࠩ࡫"))
			TKqH23oEJQzUcMxILDSduZa = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࡗࡶࡺ࡫उ")
		except: TKqH23oEJQzUcMxILDSduZa = G5TxeI0ND4ztC6(u"ࡊࡦࡲࡳࡦऊ")
		if TKqH23oEJQzUcMxILDSduZa:
			hF6r3JBmlQ9uSzfHoqV40xI5TRKv = SPBT6hjvVc2muRtoAqb3yx1+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࠡࠩ࡬")+WaHRs2hYFxZ1rQzK9DIOfew+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࠢࠪ࡭")+LLQ5iTPx9cqkM273bHWKuOtf81Nl+tvdQHb10PhNmuy6(u"ࠩࠣࠫ࡮")+ihtGnmd6IXCywFTz+pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࠤࠬ࡯")+g2j5671VMxsp+A6Iyo7eXrq2RtMmDxWj(u"ࠫࠥ࠭ࡰ")+cbAM0R6lq2JWIDgPNLYXifShHtGoO
			GF1a4PK9V5fBhjYzlZ = T4LR589r62CmGhOoVzsANQFUdbfY.Popen(b098bsyjUud(u"ࠬࡹࡵࠡ࠯ࡦࠤࠧࡩࡨ࡮ࡱࡧࠤ࠲ࡘࠠ࠱࠹࠺࠻ࠥ࠭ࡱ")+hF6r3JBmlQ9uSzfHoqV40xI5TRKv+trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠢࠨࡲ"),shell=vdHRKkIgTp56Je1OuNo(u"࡙ࡸࡵࡦऋ"),stdin=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE,stdout=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE,stderr=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE)
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠨࡳ"),VVtQk9vwe7(u"ࠨࠩࡴ"),cg94WALw5orUhvtHSfNO(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡵ"),WfgnOq9Fd4lhMSQpK5(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ฻ฺหฦࠦวๅำัูฮ࠭ࡶ"))
			BBwb2NzsHE.setSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࡷ"),tjoHEAGv2XkrMBsVfCyp5U(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨࡸ"))
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(WfgnOq9Fd4lhMSQpK5(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
		else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(cg94WALw5orUhvtHSfNO(u"ࠧࠨࡺ"),C0CbfZuXJM(u"ࠨࠩࡻ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),ebT9xRB63E(u"ࠪ฽๊๊๊สࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢอัฯอฬࠡสิ๊ฬ๋ฬࠡࠢࡵࡳࡴࡺࠠࠡล๋ࠤࠥࡹࡵࡱࡧࡵࡹࡸ࡫ࡲࠡࠢฦ์ࠥࠦࡳࡶࠢࠣ์ัํวำๅ่ࠣฬ๊้ࠦฮาࠤๆ๐็้ࠡำหࠥอไษำ้ห๊าࠠ࠯࠰ࠣวํࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪࡽ"))
	return
def YYPvXKrj8CMHVEdis43l9WwqA(V781Gfb4DCSPkEXjMZBUWNh):
	for SwAJPmoty8RC0n1 in [uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡇ࠭ࡾ"),xmTX9Aeidq8cVhY(u"ࠬࡑࡂࠨࡿ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࡍࡃࠩࢀ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡈࡄࠪࢁ"),b46fBrugtPDSYspzMQIx(u"ࠨࡖࡅࠫࢂ")]:
		if V781Gfb4DCSPkEXjMZBUWNh<GVPK9Ziaho6U2ySLj(u"࠱࠱࠴࠷࣪"): break
		else: V781Gfb4DCSPkEXjMZBUWNh /= A6Iyo7eXrq2RtMmDxWj(u"࠲࠲࠵࠸࠳࠶࣫")
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = trSQHvP4aqBWFKxN5bZgXCu(u"ࠤࠨ࠷࠳࠷ࡦࠡࠧࡶࠦࢃ")%(V781Gfb4DCSPkEXjMZBUWNh,SwAJPmoty8RC0n1)
	return hulSHFUcXsaVQGTn8r9zMkNPIwgvo
def Ei1lhA7yBXzaYVIfgNHjb(X5XrMhIcNA=Vt4ELHXZP6(u"ࠪ࠲ࠬࢄ")):
	global xyhPMq2YJOdIjQ5smz,dd8CfVaLeIAFQN09WGTMw
	xyhPMq2YJOdIjQ5smz,dd8CfVaLeIAFQN09WGTMw = b46fBrugtPDSYspzMQIx(u"࠲࣬"),b46fBrugtPDSYspzMQIx(u"࠲࣬")
	def ecQWw2HGauXfyMVdzrSv8mjZEl(X5XrMhIcNA):
		global xyhPMq2YJOdIjQ5smz,dd8CfVaLeIAFQN09WGTMw
		if A73K6zLXIgFROeCHJQi0Pbos.path.exists(X5XrMhIcNA):
			if ebT9xRB63E(u"࠳࣭") and YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡸࡩࡡ࡯ࡦ࡬ࡶࠬࢅ") in dir(A73K6zLXIgFROeCHJQi0Pbos):
				for R9Na7kKBblhcE in A73K6zLXIgFROeCHJQi0Pbos.scandir(X5XrMhIcNA):
					if R9Na7kKBblhcE.is_dir(follow_symlinks=Wbwj0o5gsXQ8F2f(u"ࡌࡡ࡭ࡵࡨऌ")):
						ecQWw2HGauXfyMVdzrSv8mjZEl(R9Na7kKBblhcE.path)
					elif R9Na7kKBblhcE.is_file(follow_symlinks=hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࡆࡢ࡮ࡶࡩऍ")):
						xyhPMq2YJOdIjQ5smz += R9Na7kKBblhcE.stat().st_size
						dd8CfVaLeIAFQN09WGTMw += YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵࣮")
			else:
				for R9Na7kKBblhcE in A73K6zLXIgFROeCHJQi0Pbos.listdir(X5XrMhIcNA):
					TSlKw1s2X8tJ6npI3CWDcyeoBAxuL = A73K6zLXIgFROeCHJQi0Pbos.path.abspath(A73K6zLXIgFROeCHJQi0Pbos.path.join(X5XrMhIcNA,R9Na7kKBblhcE))
					if A73K6zLXIgFROeCHJQi0Pbos.path.isdir(TSlKw1s2X8tJ6npI3CWDcyeoBAxuL):
						ecQWw2HGauXfyMVdzrSv8mjZEl(TSlKw1s2X8tJ6npI3CWDcyeoBAxuL)
					elif A73K6zLXIgFROeCHJQi0Pbos.path.isfile(TSlKw1s2X8tJ6npI3CWDcyeoBAxuL):
						V781Gfb4DCSPkEXjMZBUWNh,LFuTwUYZScbJ6esjC9B = eexb5wHNQEphIrs3WCBZjYcoTMu0(TSlKw1s2X8tJ6npI3CWDcyeoBAxuL)
						xyhPMq2YJOdIjQ5smz += V781Gfb4DCSPkEXjMZBUWNh
						dd8CfVaLeIAFQN09WGTMw += LFuTwUYZScbJ6esjC9B
		return
	try: ecQWw2HGauXfyMVdzrSv8mjZEl(X5XrMhIcNA)
	except: pass
	return xyhPMq2YJOdIjQ5smz,dd8CfVaLeIAFQN09WGTMw
def nhH5j4c3ZJbiPxvQemMp8BYC(RRtb6JPcihjsmBf8gv,showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(tjoHEAGv2XkrMBsVfCyp5U(u"ࠬ࠭ࢆ"),VVtQk9vwe7(u"࠭ࠧࢇ"),tvdQHb10PhNmuy6(u"ࠧࠨ࢈"),CC4UDLW6brf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢉ"),RRtb6JPcihjsmBf8gv+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࡟ࡲࡡࡴࠧࢊ")+tvdQHb10PhNmuy6(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢋ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠶࣯"): return
	vv5sG6BzK41x8QSLE7yMlIcYX = vdHRKkIgTp56Je1OuNo(u"ࡇࡣ࡯ࡷࡪऎ")
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(RRtb6JPcihjsmBf8gv):
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(RRtb6JPcihjsmBf8gv)
		except Exception as QLikYV7XZo21hAM:
			if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠬࢌ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬ࠭ࢍ"),G5TxeI0ND4ztC6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢎ"),str(QLikYV7XZo21hAM))
			vv5sG6BzK41x8QSLE7yMlIcYX = C0CbfZuXJM(u"ࡖࡵࡹࡪए")
	if showDialogs and not vv5sG6BzK41x8QSLE7yMlIcYX:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(xmTX9Aeidq8cVhY(u"ࠧࠨ࢏"),u2NDjURZVHlmdc0(u"ࠨࠩ࢐"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࢑"),Wbwj0o5gsXQ8F2f(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࢒"))
		BBwb2NzsHE.setSetting(GVPK9Ziaho6U2ySLj(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ࢓"),b098bsyjUud(u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ࢔"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(ebT9xRB63E(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ࢕"))
	return
def rCxcGNqpHulzyFVUvi2WaBdLsTOb3(showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(Vt4ELHXZP6(u"ࠧࠨ࢖"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࠩࢗ"),tvdQHb10PhNmuy6(u"ࠩࠪ࢘"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࢙࠭"),GVPK9Ziaho6U2ySLj(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะ࢚ࠫ")+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡢ࡮ࠨ࢛")+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ๅอๆาࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮࠦ࠮࠯๋้ࠢั๊ฯࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠤ࠳࠴้ࠠ็ฯ่ิࠦวๅื๋ีࠥอไใัํ้ฮࠦ࠮࠯๋ࠢฮๆื๊฻่่ࠢๆࠦี้ำࠣห้หึศใสฮࠬ࢜")+C0CbfZuXJM(u"ࠧ࡝ࡰࠪ࢝")+vdHRKkIgTp56Je1OuNo(u"ࠨมࠤࠥࠬ࢞")+cg94WALw5orUhvtHSfNO(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢟"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷ࣰ"): return
	IN1vbO8YfAu05Qyi7jMVwkxSE(wMO4E2N7GjPvarxft,KylMx0kfTOrG(u"ࡘࡷࡻࡥऑ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡉࡥࡱࡹࡥऐ"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(Qs9NBkgKdaJ4uEI1SlMo,KylMx0kfTOrG(u"࡚ࡲࡶࡧओ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡋࡧ࡬ࡴࡧऒ"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(E3p9v4sqxKNPOZg0cdzjhf2,u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩऔ"),u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩऔ"))
	awfs10CbPkY3(j7MW0pngNeR4klmv5cXzGTbyhos,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡇࡣ࡯ࡷࡪक"))
	if showDialogs:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࠫࢠ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬࢡ"),GVPK9Ziaho6U2ySLj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢢ"),b098bsyjUud(u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧࢣ"))
		BBwb2NzsHE.setSetting(ebT9xRB63E(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࢤ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫࢥ"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࢦ"))
	return
def rvKjszmY3CL1(showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࠫࢧ"),xmTX9Aeidq8cVhY(u"ࠫࠬࢨ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠭ࢩ"),tvdQHb10PhNmuy6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢪ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆๆไหฯ࠭ࢫ")+G5TxeI0ND4ztC6(u"ࠨ࡞ࡱࠫࢬ")+tvdQHb10PhNmuy6(u"ࠩࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸࠦ࠮࠯ࠢࡧࡶࡴࡶࡢࡰࡺࠣ࠲࠳ࠦࡴࡰ࡯ࡥࡷࡹࡵ࡮ࡦࡵࠣ࠲࠳ࠦ࡬ࡰࡩࡪࡩࡷࠦ࠮࠯ࠢ࡯ࡳ࡬ࠦ࠮࠯ࠢࡤࡲࡷ࠭ࢭ")+vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡠࡳ࠭ࢮ")+oh1JUWa3LdnqTpz5(u"ࠫࡄࠧࠡࠨࢯ")+oh1JUWa3LdnqTpz5(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢰ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=VVtQk9vwe7(u"࠱ࣱ"): return
	IN1vbO8YfAu05Qyi7jMVwkxSE(SPBT6hjvVc2muRtoAqb3yx1,Yr0wo7FaSHx(u"ࡈࡤࡰࡸ࡫ख"),Yr0wo7FaSHx(u"ࡈࡤࡰࡸ࡫ख"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(WaHRs2hYFxZ1rQzK9DIOfew,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡉࡥࡱࡹࡥग"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡉࡥࡱࡹࡥग"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(LLQ5iTPx9cqkM273bHWKuOtf81Nl,vlW6K1g8Xo35mPYbyO2GS(u"ࡊࡦࡲࡳࡦघ"),vlW6K1g8Xo35mPYbyO2GS(u"ࡊࡦࡲࡳࡦघ"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(ihtGnmd6IXCywFTz,vdHRKkIgTp56Je1OuNo(u"ࡋࡧ࡬ࡴࡧङ"),vdHRKkIgTp56Je1OuNo(u"ࡋࡧ࡬ࡴࡧङ"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(g2j5671VMxsp,Yr0wo7FaSHx(u"ࡌࡡ࡭ࡵࡨच"),Yr0wo7FaSHx(u"ࡌࡡ࡭ࡵࡨच"))
	IN1vbO8YfAu05Qyi7jMVwkxSE(cbAM0R6lq2JWIDgPNLYXifShHtGoO,u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩछ"),u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩछ"))
	if showDialogs:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Wbwj0o5gsXQ8F2f(u"࠭ࠧࢱ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠨࢲ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),cg94WALw5orUhvtHSfNO(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࢴ"))
		BBwb2NzsHE.setSetting(WfgnOq9Fd4lhMSQpK5(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧࢵ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧࢶ"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩࢷ"))
	return
def awfs10CbPkY3(Gu59Qt0lxV,showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠧࢸ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࠨࢹ"),KylMx0kfTOrG(u"ࠨࠩࢺ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢻ"),cg94WALw5orUhvtHSfNO(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํไࠡฬิ๎ิࠦๅิฯ้ࠣาะ่๋ษอࠤ๊๊แࠡื๋ีࠥอไอๆาࠤฤࠧࠡࠨࢼ")+WfgnOq9Fd4lhMSQpK5(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢽ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=trSQHvP4aqBWFKxN5bZgXCu(u"࠲ࣲ"): return
	LxomZnH9Ky = gxoYzqsnPQ.connect(Gu59Qt0lxV)
	LxomZnH9Ky.text_factory = str
	ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
	ooRPprGBD89QXusn.execute(vdHRKkIgTp56Je1OuNo(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࢾ"))
	ooRPprGBD89QXusn.execute(Yr0wo7FaSHx(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࢿ"))
	ooRPprGBD89QXusn.execute(G5TxeI0ND4ztC6(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࣀ"))
	LxomZnH9Ky.commit()
	ooRPprGBD89QXusn.execute(b46fBrugtPDSYspzMQIx(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࣁ"))
	LxomZnH9Ky.close()
	if showDialogs:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(b098bsyjUud(u"ࠩࠪࣂ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫࣃ"),cg94WALw5orUhvtHSfNO(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),Wbwj0o5gsXQ8F2f(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࣅ"))
		BBwb2NzsHE.setSetting(ebT9xRB63E(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࣆ"),A6Iyo7eXrq2RtMmDxWj(u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪࣇ"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(vdHRKkIgTp56Je1OuNo(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣈ"))
	return
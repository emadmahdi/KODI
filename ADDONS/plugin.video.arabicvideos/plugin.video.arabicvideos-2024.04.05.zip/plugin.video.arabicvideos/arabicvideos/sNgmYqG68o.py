# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'EGYNOW'
eMlwAzaLSj8ZEQ3txIGP = '_EGN_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==430: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==431: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==432: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==433: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==434: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==437: mL7BVKcSygkuoPbWlEF4YD = LLjUb3OSnVJCfYH9vgEi5xh61G7tq(url)
	elif mode==439: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH+'/films','','','','','EGYNOW-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = JJDtX1PZyIgN2T.findall('"canonical" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	PeArnUDVym1pjBFaG = PeArnUDVym1pjBFaG[0].strip('/')
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(PeArnUDVym1pjBFaG,'url')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',439,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',PeArnUDVym1pjBFaG,435)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',PeArnUDVym1pjBFaG,434)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المضاف حديثا',PeArnUDVym1pjBFaG,431)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'افلام اون لاين',PeArnUDVym1pjBFaG+'/films1',436)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مسلسلات اون لاين',PeArnUDVym1pjBFaG+'/series-all1',436)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'قائمة تفصيلية',PeArnUDVym1pjBFaG,437)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"SiteNavigation"(.*?)"Search"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,431)
	return
def LLjUb3OSnVJCfYH9vgEi5xh61G7tq(website=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',website+'/films','','','','','EGYNOW-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = JJDtX1PZyIgN2T.findall('"canonical" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	PeArnUDVym1pjBFaG = PeArnUDVym1pjBFaG[0].strip('/')
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(PeArnUDVym1pjBFaG,'url')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"ListDroped"(.*?)"SearchingMaster"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for qGsE8fdyFtUwBnu,Y3YqSmycrIWksoH5N0MvC,title in items:
		if title in eJzpdvc3KTust: continue
		wHiSfdBL1v9Kl3n5 = website+'/explore/?'+qGsE8fdyFtUwBnu+'='+Y3YqSmycrIWksoH5N0MvC
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,431)
	return
def YsCotEfMBv03z7mg(url):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYNOW-SUBMENU-1st')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',url,431)
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"titleSectionCon"(.*?)</div></div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('data-key="(.*?)".*?<em>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for IOC7UWYc5MTHZbLx9VtXpn,title in items:
		if title in eJzpdvc3KTust: continue
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = PeArnUDVym1pjBFaG+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+IOC7UWYc5MTHZbLx9VtXpn
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,431)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,WAEqF7ZldrmL9Xw=''):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
		JZP07kjvbV = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','EGYNOW-TITLES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
	elif WAEqF7ZldrmL9Xw=='featured':
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"MainSlider"(.*?)"MatchesTable"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYNOW-TITLES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"BlocksList"(.*?)"Paginate"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not GGbRgKaoskDC: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"BlocksList"(.*?)"titleSectionCon"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if not items: items = JJDtX1PZyIgN2T.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
		wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5).strip('/')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
		if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,432,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt and 'الحلقة' in title:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,433,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif '/movseries/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,431,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,433,ggdRiBo3smurLUGO)
	if WAEqF7ZldrmL9Xw!='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"Paginate"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
				wHiSfdBL1v9Kl3n5 = jbigKDeUf0OSMrRkly2B5I3Act(wHiSfdBL1v9Kl3n5)
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,431)
		cTeasj2fu6yr7YtVzBh = JJDtX1PZyIgN2T.findall('showmore" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if cTeasj2fu6yr7YtVzBh:
			wHiSfdBL1v9Kl3n5 = cTeasj2fu6yr7YtVzBh[0]
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مشاهدة المزيد',wHiSfdBL1v9Kl3n5,431)
	return
def sjmSkpqHVtPcv(url):
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	vLlUHJTNWusr0IGRxY63gDPCet9,ooTeU5chRPu = [],[]
	if 'Episodes.php' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
		JZP07kjvbV = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','EGYNOW-EPISODES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		ooTeU5chRPu = [YBEsLq8gVw629cMGQP1T]
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYNOW-EPISODES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"SeasonsList"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"EpisodesList"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vLlUHJTNWusr0IGRxY63gDPCet9:
		ggdRiBo3smurLUGO = JJDtX1PZyIgN2T.findall('"og:image" content="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		ggdRiBo3smurLUGO = ggdRiBo3smurLUGO[0]
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		items = JJDtX1PZyIgN2T.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for EvutnH6GVfdhAk10g,xxDg8zE5vYZ3OS7khVc,title in items:
			wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+xxDg8zE5vYZ3OS7khVc+'&post_id='+EvutnH6GVfdhAk10g
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,433,ggdRiBo3smurLUGO)
	elif ooTeU5chRPu:
		ggdRiBo3smurLUGO = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Thumb')
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,vaQbluYS4GEsKCNwOymT1hFt in items:
			title = title+' '+vaQbluYS4GEsKCNwOymT1hFt
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,432,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/watch/'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','EGYNOW-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	EEgFl59RndzrBL8TUoaQMw6P = []
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'url')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"container-servers"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		ttoevRYg7p8Sc2UO = JJDtX1PZyIgN2T.findall('data-id="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if ttoevRYg7p8Sc2UO:
			ttoevRYg7p8Sc2UO = ttoevRYg7p8Sc2UO[0]
			items = JJDtX1PZyIgN2T.findall('data-server="(.*?)".*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for RgNSOU7P93n,title in items:
				wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+RgNSOU7P93n+'&post_id='+ttoevRYg7p8Sc2UO+'?named='+title+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	TrN9q4Xz3CIuL = JJDtX1PZyIgN2T.findall('"container-iframe"><iframe src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if TrN9q4Xz3CIuL:
		TrN9q4Xz3CIuL = TrN9q4Xz3CIuL[0].replace('\n','')
		title = OfTKisDR0Lv(TrN9q4Xz3CIuL,'name')
		wHiSfdBL1v9Kl3n5 = TrN9q4Xz3CIuL+'?named='+title+'__embed'
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"container-download"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,y2nBfLCjDoXkKiwb8WV6 in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\n','')
			if y2nBfLCjDoXkKiwb8WV6!='': y2nBfLCjDoXkKiwb8WV6 = '____'+y2nBfLCjDoXkKiwb8WV6
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'+y2nBfLCjDoXkKiwb8WV6
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','%20')
	url = kU2ZXSViB3wLANOz8bH+'/?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
def LWTgVSqXyoz26Hi931Ks(url):
	url = url.split('/smartemadfilter?')[0]
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',PeArnUDVym1pjBFaG,'','','','','EGYNOW-GET_FILTERS_BLOCKS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('("dropdown-button".*?)"SearchingMaster"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	KKMpOd0rWFRNPtun5cgY6 = JJDtX1PZyIgN2T.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return KKMpOd0rWFRNPtun5cgY6
def ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl):
	items = JJDtX1PZyIgN2T.findall('data-term="(\d+)" data-name="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	return items
def l4yQ95DNGZEUi6r2CKtVwc(url):
	wHGCED2fklopYyFzI = url.split('/smartemadfilter?')[0]
	i1TCt53bykSvPp8e = OfTKisDR0Lv(url,'url')
	url = url.replace(wHGCED2fklopYyFzI,i1TCt53bykSvPp8e)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def gxWYGiortcHafXnN(VQZDwq9mu4jrB1gPlcWOxyF,url):
	ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
	kHWT0XY2S6apruwxiB8FDl1 = url+'/smartemadfilter?'+ssnIblOr0uX
	kHWT0XY2S6apruwxiB8FDl1 = l4yQ95DNGZEUi6r2CKtVwc(kHWT0XY2S6apruwxiB8FDl1)
	return kHWT0XY2S6apruwxiB8FDl1
EhaSnsdMYV90pT = ['category','country','genre','release-year']
d1GKRIraF3whePop87L4JjDZnEVB = ['quality','release-year','genre','category','language','country']
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if EhaSnsdMYV90pT[0]+'=' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[0]
		for ggjo5zu7yCiIOhrb in range(len(EhaSnsdMYV90pT[0:-1])):
			if EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb]+'=' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = EhaSnsdMYV90pT[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+qGsE8fdyFtUwBnu+'=0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+qGsE8fdyFtUwBnu+'=0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+ssnIblOr0uX
	elif type=='ALL_ITEMS_FILTER':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/smartemadfilter?'+oju0BC1rJO
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,431)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,431)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	KKMpOd0rWFRNPtun5cgY6 = LWTgVSqXyoz26Hi931Ks(url)
	dict = {}
	for name,mvgk7pP8Fw6heMSWd5oXn9itl,eYFHT1CfSqZK in KKMpOd0rWFRNPtun5cgY6:
		name = name.replace('--','')
		items = ppQwmG95RSYCfo3ABarhn(mvgk7pP8Fw6heMSWd5oXn9itl)
		if '=' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='SPECIFIED_FILTER':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<2:
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]:
					url = l4yQ95DNGZEUi6r2CKtVwc(url)
					d2JXnUMPmgsKBQqCE58lkZ(url)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'SPECIFIED_FILTER___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = l4yQ95DNGZEUi6r2CKtVwc(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				if eYFHT1CfSqZK==EhaSnsdMYV90pT[-1]: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,431)
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,435,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='ALL_ITEMS_FILTER':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'=0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'=0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع :'+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,434,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for Y3YqSmycrIWksoH5N0MvC,khB9dCpWm4qPMrXTjgONf0Z in items:
			if Y3YqSmycrIWksoH5N0MvC=='196533': khB9dCpWm4qPMrXTjgONf0Z = 'أفلام نيتفلكس'
			elif Y3YqSmycrIWksoH5N0MvC=='196531': khB9dCpWm4qPMrXTjgONf0Z = 'مسلسلات نيتفلكس'
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = khB9dCpWm4qPMrXTjgONf0Z
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&'+eYFHT1CfSqZK+'='+khB9dCpWm4qPMrXTjgONf0Z
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&'+eYFHT1CfSqZK+'='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'#+dict[eYFHT1CfSqZK]['0']
			title = khB9dCpWm4qPMrXTjgONf0Z+' :'+name
			if type=='ALL_ITEMS_FILTER': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,434,'','',oy5AiZKfC86qITkYWL)
			elif type=='SPECIFIED_FILTER' and EhaSnsdMYV90pT[-2]+'=' in u7fXcTJNB8djwxR6yS:
				kHWT0XY2S6apruwxiB8FDl1 = gxWYGiortcHafXnN(VQZDwq9mu4jrB1gPlcWOxyF,url)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,kHWT0XY2S6apruwxiB8FDl1,431)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,435,'','',oy5AiZKfC86qITkYWL)
	return
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.replace('=&','=0&')
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&')
	bHErtloWDJ3YCFvSfqLN1e7IVh = {}
	if '=' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('=')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = ''
	for key in d1GKRIraF3whePop87L4JjDZnEVB:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all_filters': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&'+key+'='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.replace('=0','=')
	return P1yxuh7MAmvSRVqLZcW6tY3
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'YOUTUBE'
eMlwAzaLSj8ZEQ3txIGP = '_YUT_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
rrpv1k9Nw6DmyMuKlfYSAqtXo5 = 0
def HYWukw3pL2oMzPK4(mode,url,text,type,vYpMA3CxgcyR4VZJh,name,UCjpzQwrZyNIe3kg1ThDvi0nb8):
	if	 mode==140: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==141: mL7BVKcSygkuoPbWlEF4YD = bEHQKumlveW3SXqBFJ(url,name,UCjpzQwrZyNIe3kg1ThDvi0nb8)
	elif mode==143: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url,type)
	elif mode==144: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh,text)
	elif mode==145: mL7BVKcSygkuoPbWlEF4YD = CBc1lYpjK2(url,vYpMA3CxgcyR4VZJh)
	elif mode==147: mL7BVKcSygkuoPbWlEF4YD = dga5lMNQrUE2thAVRfD4pYHOz3sPv()
	elif mode==148: mL7BVKcSygkuoPbWlEF4YD = vXGZWOERbVtzP9cM2Si4peCauY()
	elif mode==149: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	if 0:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'قائمة',kU2ZXSViB3wLANOz8bH+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'شخص',kU2ZXSViB3wLANOz8bH+'/user/TCNofficial',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'موقع',kU2ZXSViB3wLANOz8bH+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'حساب',kU2ZXSViB3wLANOz8bH+'/@TheSocialCTV',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'العاب',kU2ZXSViB3wLANOz8bH+'/gaming',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'افلام',kU2ZXSViB3wLANOz8bH+'/feed/storefront',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مختارات',kU2ZXSViB3wLANOz8bH+'/feed/guide_builder',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'قصيرة',kU2ZXSViB3wLANOz8bH+'/shorts',144,'','','_REMEMBERRESULTS_')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'تصفح',kU2ZXSViB3wLANOz8bH+'/youtubei/v1/guide?key=',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'رئيسية',kU2ZXSViB3wLANOz8bH+'',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'رائج',kU2ZXSViB3wLANOz8bH+'/feed/trending?bp=',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الرئيسية',kU2ZXSViB3wLANOz8bH+'',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الرائجة',kU2ZXSViB3wLANOz8bH+'/feed/trending',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'التصفح',kU2ZXSViB3wLANOz8bH+'/youtubei/v1/guide?key=',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'القصيرة',kU2ZXSViB3wLANOz8bH+'/shorts',144,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مختارات يوتيوب',kU2ZXSViB3wLANOz8bH+'/feed/guide_builder',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مختارات البرنامج','',290)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: قنوات عربية','',147)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: قنوات أجنبية','',148)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: افلام عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=فيلم',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: افلام اجنبية',kU2ZXSViB3wLANOz8bH+'/results?search_query=movie',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: مسرحيات عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=مسرحية',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات اجنبية',kU2ZXSViB3wLANOz8bH+'/results?search_query=series&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات كارتون',kU2ZXSViB3wLANOz8bH+'/results?search_query=كارتون&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث: خطبة المرجعية',kU2ZXSViB3wLANOz8bH+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def bEHQKumlveW3SXqBFJ(url,name,UCjpzQwrZyNIe3kg1ThDvi0nb8):
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'CHNL:  '+name,url,144,UCjpzQwrZyNIe3kg1ThDvi0nb8)
	return
def dga5lMNQrUE2thAVRfD4pYHOz3sPv():
	d2JXnUMPmgsKBQqCE58lkZ(kU2ZXSViB3wLANOz8bH+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def vXGZWOERbVtzP9cM2Si4peCauY():
	d2JXnUMPmgsKBQqCE58lkZ(kU2ZXSViB3wLANOz8bH+'/results?search_query=tv&sp=EgJAAQ==')
	return
def CsUdRabWuh0M9F(url,type):
	url = url.split('&',1)[0]
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5([url],FpjtBKrnu5SdfyOvEPIQ,type,url)
	return
def Y67chTFz0s1HSAob3(RA1u29NiFkEojSfvdm,url,ZJfCEzd2DxAvbiYg):
	level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = ZJfCEzd2DxAvbiYg.split('::')
	mOgKjNkMwU8z0xyvub93,Bidjh7eHMxLgJEaP03ktOpDYSoFA = [],[]
	if '/youtubei/v1/browse' in url: mOgKjNkMwU8z0xyvub93.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: mOgKjNkMwU8z0xyvub93.append("yccc['onResponseReceivedCommands']")
	if level=='1': mOgKjNkMwU8z0xyvub93.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	mOgKjNkMwU8z0xyvub93.append("yccc['entries']")
	mOgKjNkMwU8z0xyvub93.append("yccc['items'][3]['guideSectionRenderer']['items']")
	MrbPYaz2xo0t,FDhHYp80QT2NmrzgGfybwoXk46,MgB6xUdODFpzQtTRNjhe24bvCcZJqG = l0IuvDwmL3iUk8db5(RA1u29NiFkEojSfvdm,'',mOgKjNkMwU8z0xyvub93)
	if level=='1' and MrbPYaz2xo0t:
		if len(FDhHYp80QT2NmrzgGfybwoXk46)>1 and 'search_query' not in url:
			for gT0RPc1dtMWS3sJmyKGjul6 in range(len(FDhHYp80QT2NmrzgGfybwoXk46)):
				vV2CbuUyfnZWTpkQ8GF = str(gT0RPc1dtMWS3sJmyKGjul6)
				mOgKjNkMwU8z0xyvub93 = []
				mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['reloadContinuationItemsCommand']['continuationItems']")
				mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['command']")
				mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]")
				llC9WmbrAIgpzfi3n,KxB8vVHUJg,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(FDhHYp80QT2NmrzgGfybwoXk46,'',mOgKjNkMwU8z0xyvub93)
				if llC9WmbrAIgpzfi3n: Bidjh7eHMxLgJEaP03ktOpDYSoFA.append([KxB8vVHUJg,url,'2::'+vV2CbuUyfnZWTpkQ8GF+'::0::0'])
			mOgKjNkMwU8z0xyvub93.append("yccc['continuationEndpoint']")
			llC9WmbrAIgpzfi3n,KxB8vVHUJg,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(RA1u29NiFkEojSfvdm,'',mOgKjNkMwU8z0xyvub93)
			if llC9WmbrAIgpzfi3n and Bidjh7eHMxLgJEaP03ktOpDYSoFA and 'continuationCommand' in list(KxB8vVHUJg.keys()):
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/my_main_page_shorts_link'
				Bidjh7eHMxLgJEaP03ktOpDYSoFA.append([KxB8vVHUJg,wHiSfdBL1v9Kl3n5,'1::0::0::0'])
	return FDhHYp80QT2NmrzgGfybwoXk46,MrbPYaz2xo0t,Bidjh7eHMxLgJEaP03ktOpDYSoFA,MgB6xUdODFpzQtTRNjhe24bvCcZJqG
def xaRpTmclYnHEoj8I(RA1u29NiFkEojSfvdm,FDhHYp80QT2NmrzgGfybwoXk46,url,ZJfCEzd2DxAvbiYg):
	level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = ZJfCEzd2DxAvbiYg.split('::')
	mOgKjNkMwU8z0xyvub93,wkBcKlzuZjyxNAHfQ7RvJPt8dDT = [],[]
	mOgKjNkMwU8z0xyvub93.append("yddd[0]['itemSectionRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['reloadContinuationItemsCommand']['continuationItems']")
	mOgKjNkMwU8z0xyvub93.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: mOgKjNkMwU8z0xyvub93.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: mOgKjNkMwU8z0xyvub93.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yddd["+vV2CbuUyfnZWTpkQ8GF+"]")
	kDhn5EXNM6,FAaKPg0XR63mE8T4yvLqd,mOj1nEbISFV8qrU3auDyYB75 = l0IuvDwmL3iUk8db5(FDhHYp80QT2NmrzgGfybwoXk46,'',mOgKjNkMwU8z0xyvub93)
	if level=='2' and kDhn5EXNM6:
		if len(FAaKPg0XR63mE8T4yvLqd)>1:
			for gT0RPc1dtMWS3sJmyKGjul6 in range(len(FAaKPg0XR63mE8T4yvLqd)):
				KLiovD7sSjF9Npged4z1VHIBy8rXxJ = str(gT0RPc1dtMWS3sJmyKGjul6)
				mOgKjNkMwU8z0xyvub93 = []
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['richSectionRenderer']['content']")
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]")
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['richItemRenderer']['content']")
				mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]")
				llC9WmbrAIgpzfi3n,KxB8vVHUJg,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(FAaKPg0XR63mE8T4yvLqd,'',mOgKjNkMwU8z0xyvub93)
				if llC9WmbrAIgpzfi3n: wkBcKlzuZjyxNAHfQ7RvJPt8dDT.append([KxB8vVHUJg,url,'3::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::0'])
			mOgKjNkMwU8z0xyvub93.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			mOgKjNkMwU8z0xyvub93.append("yddd[1]")
			llC9WmbrAIgpzfi3n,KxB8vVHUJg,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(FDhHYp80QT2NmrzgGfybwoXk46,'',mOgKjNkMwU8z0xyvub93)
			if llC9WmbrAIgpzfi3n and wkBcKlzuZjyxNAHfQ7RvJPt8dDT and 'continuationItemRenderer' in list(KxB8vVHUJg.keys()):
				wkBcKlzuZjyxNAHfQ7RvJPt8dDT.append([KxB8vVHUJg,url,'3::0::0::0'])
	return FAaKPg0XR63mE8T4yvLqd,kDhn5EXNM6,wkBcKlzuZjyxNAHfQ7RvJPt8dDT,mOj1nEbISFV8qrU3auDyYB75
def LXoCPy1bvshYMUwigufd(RA1u29NiFkEojSfvdm,FAaKPg0XR63mE8T4yvLqd,url,ZJfCEzd2DxAvbiYg):
	level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = ZJfCEzd2DxAvbiYg.split('::')
	mOgKjNkMwU8z0xyvub93,CtO4sBaHD6U9PelVp3fQvGngZI = [],[]
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['reelShelfRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("yeee["+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("yeee")
	JRe854YfZKG0DCOx,rrAGgBVn8Fxyv,YYKH1bG30BIDMS8sraz2 = l0IuvDwmL3iUk8db5(FAaKPg0XR63mE8T4yvLqd,'',mOgKjNkMwU8z0xyvub93)
	if level=='3' and JRe854YfZKG0DCOx:
		if len(rrAGgBVn8Fxyv)>0:
			for gT0RPc1dtMWS3sJmyKGjul6 in range(len(rrAGgBVn8Fxyv)):
				NtqPSxFUcMby3 = str(gT0RPc1dtMWS3sJmyKGjul6)
				mOgKjNkMwU8z0xyvub93 = []
				mOgKjNkMwU8z0xyvub93.append("yfff["+NtqPSxFUcMby3+"]['richItemRenderer']['content']")
				mOgKjNkMwU8z0xyvub93.append("yfff["+NtqPSxFUcMby3+"]['gameCardRenderer']['game']")
				mOgKjNkMwU8z0xyvub93.append("yfff["+NtqPSxFUcMby3+"]['itemSectionRenderer']['contents'][0]")
				mOgKjNkMwU8z0xyvub93.append("yfff["+NtqPSxFUcMby3+"]")
				llC9WmbrAIgpzfi3n,KxB8vVHUJg,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(rrAGgBVn8Fxyv,'',mOgKjNkMwU8z0xyvub93)
				if llC9WmbrAIgpzfi3n: CtO4sBaHD6U9PelVp3fQvGngZI.append([KxB8vVHUJg,url,'4::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3])
	return rrAGgBVn8Fxyv,JRe854YfZKG0DCOx,CtO4sBaHD6U9PelVp3fQvGngZI,YYKH1bG30BIDMS8sraz2
def l0IuvDwmL3iUk8db5(cJsUR2bM3WZmAFT,RZdc3HWpJk,ve1HFYmJD9wQ):
	RA1u29NiFkEojSfvdm,RZdc3HWpJk = cJsUR2bM3WZmAFT,RZdc3HWpJk
	FDhHYp80QT2NmrzgGfybwoXk46,RZdc3HWpJk = cJsUR2bM3WZmAFT,RZdc3HWpJk
	FAaKPg0XR63mE8T4yvLqd,RZdc3HWpJk = cJsUR2bM3WZmAFT,RZdc3HWpJk
	rrAGgBVn8Fxyv,RZdc3HWpJk = cJsUR2bM3WZmAFT,RZdc3HWpJk
	KxB8vVHUJg,hLRwAl7jfc6tWPnO = cJsUR2bM3WZmAFT,RZdc3HWpJk
	count = len(ve1HFYmJD9wQ)
	for uvTwHSmjyW6Vr0192IZ in range(count):
		try:
			wImcinprFPLQO3x0jKA = eval(ve1HFYmJD9wQ[uvTwHSmjyW6Vr0192IZ])
			return True,wImcinprFPLQO3x0jKA,uvTwHSmjyW6Vr0192IZ+1
		except: pass
	return False,'',0
def d2JXnUMPmgsKBQqCE58lkZ(url,ZJfCEzd2DxAvbiYg='',data=''):
	Bidjh7eHMxLgJEaP03ktOpDYSoFA,wkBcKlzuZjyxNAHfQ7RvJPt8dDT,CtO4sBaHD6U9PelVp3fQvGngZI = [],[],[]
	if '::' not in ZJfCEzd2DxAvbiYg: ZJfCEzd2DxAvbiYg = '1::0::0::0'
	level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = ZJfCEzd2DxAvbiYg.split('::')
	if level=='4': level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = '1',vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3
	data = data.replace('_REMEMBERRESULTS_','')
	YBEsLq8gVw629cMGQP1T,RA1u29NiFkEojSfvdm,Gv7mT0LhB9YoOVpANMr = A2uKOeby9MT(url,data)
	ZJfCEzd2DxAvbiYg = level+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
	if level in ['1','2','3']:
		FDhHYp80QT2NmrzgGfybwoXk46,MrbPYaz2xo0t,Bidjh7eHMxLgJEaP03ktOpDYSoFA,MgB6xUdODFpzQtTRNjhe24bvCcZJqG = Y67chTFz0s1HSAob3(RA1u29NiFkEojSfvdm,url,ZJfCEzd2DxAvbiYg)
		if not MrbPYaz2xo0t: return
		qzJRCvi39BEVK8 = len(Bidjh7eHMxLgJEaP03ktOpDYSoFA)
		if qzJRCvi39BEVK8<2:
			if level=='1': level = '2'
			Bidjh7eHMxLgJEaP03ktOpDYSoFA = []
	ZJfCEzd2DxAvbiYg = level+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
	if level in ['2','3']:
		FAaKPg0XR63mE8T4yvLqd,kDhn5EXNM6,wkBcKlzuZjyxNAHfQ7RvJPt8dDT,mOj1nEbISFV8qrU3auDyYB75 = xaRpTmclYnHEoj8I(RA1u29NiFkEojSfvdm,FDhHYp80QT2NmrzgGfybwoXk46,url,ZJfCEzd2DxAvbiYg)
		if not kDhn5EXNM6: return
		bev7ECHhWNuliZ4RwYOT = len(wkBcKlzuZjyxNAHfQ7RvJPt8dDT)
		if bev7ECHhWNuliZ4RwYOT<2:
			if level=='2': level = '3'
			wkBcKlzuZjyxNAHfQ7RvJPt8dDT = []
	ZJfCEzd2DxAvbiYg = level+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
	if level in ['3']:
		rrAGgBVn8Fxyv,JRe854YfZKG0DCOx,CtO4sBaHD6U9PelVp3fQvGngZI,YYKH1bG30BIDMS8sraz2 = LXoCPy1bvshYMUwigufd(RA1u29NiFkEojSfvdm,FAaKPg0XR63mE8T4yvLqd,url,ZJfCEzd2DxAvbiYg)
		if not JRe854YfZKG0DCOx: return
		Fh1Cti92ZQXVkPy7l6SWfnOgE8 = len(CtO4sBaHD6U9PelVp3fQvGngZI)
	for KxB8vVHUJg,url,ZJfCEzd2DxAvbiYg in Bidjh7eHMxLgJEaP03ktOpDYSoFA+wkBcKlzuZjyxNAHfQ7RvJPt8dDT+CtO4sBaHD6U9PelVp3fQvGngZI:
		fk3hGJeYALcj5OTU1Sl2QrnH6iZIg = lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg,url,ZJfCEzd2DxAvbiYg)
	return
def lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg,url='',ZJfCEzd2DxAvbiYg=''):
	if '::' in ZJfCEzd2DxAvbiYg: level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = ZJfCEzd2DxAvbiYg.split('::')
	else: level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = '1','0','0','0'
	llC9WmbrAIgpzfi3n,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB,VWiLrbx15zaBjUFsG8g6XnoOZSHNEq = FFkr5MZCQHyRqIWoK(KxB8vVHUJg)
	vxtO15lf9GB2CsVaZFDNMILuTQU = '/videos?' in wHiSfdBL1v9Kl3n5 or '/streams?' in wHiSfdBL1v9Kl3n5 or '/playlists?' in wHiSfdBL1v9Kl3n5
	ZECn8mVfK6rTWH30beDh1PLtjJq = '/channels?' in wHiSfdBL1v9Kl3n5 or '/shorts?' in wHiSfdBL1v9Kl3n5
	if vxtO15lf9GB2CsVaZFDNMILuTQU or ZECn8mVfK6rTWH30beDh1PLtjJq: wHiSfdBL1v9Kl3n5 = url
	vxtO15lf9GB2CsVaZFDNMILuTQU = 'watch?v=' not in wHiSfdBL1v9Kl3n5 and '/playlist?list=' not in wHiSfdBL1v9Kl3n5
	ZECn8mVfK6rTWH30beDh1PLtjJq = '/gaming' not in wHiSfdBL1v9Kl3n5  and '/feed/storefront' not in wHiSfdBL1v9Kl3n5
	if ZJfCEzd2DxAvbiYg[0:5]=='3::0::' and vxtO15lf9GB2CsVaZFDNMILuTQU and ZECn8mVfK6rTWH30beDh1PLtjJq: wHiSfdBL1v9Kl3n5 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in wHiSfdBL1v9Kl3n5:
		level,vV2CbuUyfnZWTpkQ8GF,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,NtqPSxFUcMby3 = '1','0','0','0'
		ZJfCEzd2DxAvbiYg = ''
	Gv7mT0LhB9YoOVpANMr = ''
	if '/youtubei/v1/browse' in wHiSfdBL1v9Kl3n5 or '/youtubei/v1/search' in wHiSfdBL1v9Kl3n5 or '/my_main_page_shorts_link' in url:
		data = BBwb2NzsHE.getSetting('av.youtube.data')
		if data.count(':::')==4:
			XIlcQBxwEsmTvD32guYGtfACOa,key,UCwsM5Lng6GoqIrhxf4tjWpDv1,vQMKg0RqwDkcUriZ,BB0MgRSFCf5k6xyH4hLam = data.split(':::')
			Gv7mT0LhB9YoOVpANMr = XIlcQBxwEsmTvD32guYGtfACOa+':::'+key+':::'+UCwsM5Lng6GoqIrhxf4tjWpDv1+':::'+vQMKg0RqwDkcUriZ+':::'+VWiLrbx15zaBjUFsG8g6XnoOZSHNEq
			if '/my_main_page_shorts_link' in url and not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = url
			else: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?key='+key
	if not title:
		global rrpv1k9Nw6DmyMuKlfYSAqtXo5
		rrpv1k9Nw6DmyMuKlfYSAqtXo5 += 1
		title = 'فيديوهات '+str(rrpv1k9Nw6DmyMuKlfYSAqtXo5)
		ZJfCEzd2DxAvbiYg = '3'+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
	if not llC9WmbrAIgpzfi3n: return False
	elif 'searchPyvRenderer' in str(KxB8vVHUJg): return False
	elif '/about' in wHiSfdBL1v9Kl3n5: return False
	elif '/community' in wHiSfdBL1v9Kl3n5: return False
	elif 'continuationItemRenderer' in list(KxB8vVHUJg.keys()) or 'continuationCommand' in list(KxB8vVHUJg.keys()):
		if int(level)>1: level = str(int(level)-1)
		ZJfCEzd2DxAvbiYg = level+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+':: '+'صفحة أخرى',wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg,Gv7mT0LhB9YoOVpANMr)
	elif '/search' in wHiSfdBL1v9Kl3n5:
		title = ':: '+title
		ZJfCEzd2DxAvbiYg = '3'+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
		url = url.replace('/search','')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,145,'',ZJfCEzd2DxAvbiYg,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not wHiSfdBL1v9Kl3n5:
		ZJfCEzd2DxAvbiYg = '3'+'::'+vV2CbuUyfnZWTpkQ8GF+'::'+KLiovD7sSjF9Npged4z1VHIBy8rXxJ+'::'+NtqPSxFUcMby3
		title = ':: '+title
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg,Gv7mT0LhB9YoOVpANMr)
	elif '/browse' in wHiSfdBL1v9Kl3n5 and url==kU2ZXSViB3wLANOz8bH:
		title = ':: '+title
		ZJfCEzd2DxAvbiYg = '2::0::0::0'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg,Gv7mT0LhB9YoOVpANMr)
	elif not wHiSfdBL1v9Kl3n5 and 'horizontalMovieListRenderer' in str(KxB8vVHUJg):
		title = ':: '+title
		ZJfCEzd2DxAvbiYg = '3::0::0::0'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg)
	elif 'messageRenderer' in str(KxB8vVHUJg):
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+title,'',9999)
	elif HHXCbZ9z84V:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+HHXCbZ9z84V+title,wHiSfdBL1v9Kl3n5,143,ggdRiBo3smurLUGO)
	elif '/playlist?list=' in wHiSfdBL1v9Kl3n5:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'LIST'+count+':  '+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg)
	elif '/shorts/' in wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&list=',1)[0]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,143,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO)
	elif '/watch?v=' in wHiSfdBL1v9Kl3n5:
		if '&list=' in wHiSfdBL1v9Kl3n5 and count:
			wwqVHTGK59fkCFRAlubS = wHiSfdBL1v9Kl3n5.split('&list=',1)[1]
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/playlist?list='+wwqVHTGK59fkCFRAlubS
			ZJfCEzd2DxAvbiYg = '3::0::0::0'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'LIST'+count+':  '+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg)
		else:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&list=',1)[0]
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,143,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO)
	elif '/channel/' in wHiSfdBL1v9Kl3n5 or '/c/' in wHiSfdBL1v9Kl3n5 or ('/@' in wHiSfdBL1v9Kl3n5 and wHiSfdBL1v9Kl3n5.count('/')==3):
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'CHNL'+count+':  '+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg)
	elif '/user/' in wHiSfdBL1v9Kl3n5:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'USER'+count+':  '+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg)
	else:
		if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = url
		title = ':: '+title
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,ZJfCEzd2DxAvbiYg,Gv7mT0LhB9YoOVpANMr)
	return True
def FFkr5MZCQHyRqIWoK(KxB8vVHUJg):
	llC9WmbrAIgpzfi3n,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB,BB0MgRSFCf5k6xyH4hLam = False,'','','','','','','',''
	if not isinstance(KxB8vVHUJg,dict): return llC9WmbrAIgpzfi3n,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB,BB0MgRSFCf5k6xyH4hLam
	for qab1Px2OmuBVZ6s8giAWp7UDvlk in list(KxB8vVHUJg.keys()):
		hLRwAl7jfc6tWPnO = KxB8vVHUJg[qab1Px2OmuBVZ6s8giAWp7UDvlk]
		if isinstance(hLRwAl7jfc6tWPnO,dict): break
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['header']['richListHeaderRenderer']['title']")
	mOgKjNkMwU8z0xyvub93.append("yrender['headline']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['unplayableText']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['formattedTitle']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['title']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['title']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("yrender['text']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['text']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("yrender['title']")
	mOgKjNkMwU8z0xyvub93.append("item['title']")
	mOgKjNkMwU8z0xyvub93.append("item['reelWatchEndpoint']['videoId']")
	llC9WmbrAIgpzfi3n,title,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	mOgKjNkMwU8z0xyvub93.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	mOgKjNkMwU8z0xyvub93.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("item['commandMetadata']['webCommandMetadata']['url']")
	llC9WmbrAIgpzfi3n,wHiSfdBL1v9Kl3n5,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnail']['thumbnails'][0]['url']")
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	mOgKjNkMwU8z0xyvub93.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	llC9WmbrAIgpzfi3n,ggdRiBo3smurLUGO,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['videoCount']")
	mOgKjNkMwU8z0xyvub93.append("yrender['videoCountText']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	llC9WmbrAIgpzfi3n,count,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['lengthText']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	mOgKjNkMwU8z0xyvub93.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	llC9WmbrAIgpzfi3n,hhCd56yES0cqfUKRsZaVI4wzWuTO,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	mOgKjNkMwU8z0xyvub93.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	llC9WmbrAIgpzfi3n,BB0MgRSFCf5k6xyH4hLam,ttIZeP6yNoM7 = l0IuvDwmL3iUk8db5(KxB8vVHUJg,hLRwAl7jfc6tWPnO,mOgKjNkMwU8z0xyvub93)
	if 'LIVE' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V = '','LIVE:  '
	if 'مباشر' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V = '','LIVE:  '
	if 'badges' in list(hLRwAl7jfc6tWPnO.keys()):
		jWfAG1Sd4RQ52pmPL9EsDB8uKTV = str(hLRwAl7jfc6tWPnO['badges'])
		if 'Free with Ads' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$:  '
		if 'LIVE' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: HHXCbZ9z84V = 'LIVE:  '
		if 'Buy' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV or 'Rent' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:  '
		if GlsezWv7iIro(u'مباشر') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: HHXCbZ9z84V = 'LIVE:  '
		if GlsezWv7iIro(u'شراء') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:  '
		if GlsezWv7iIro(u'استئجار') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:  '
		if GlsezWv7iIro(u'إعلانات') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$:  '
	wHiSfdBL1v9Kl3n5 = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(wHiSfdBL1v9Kl3n5)
	if wHiSfdBL1v9Kl3n5 and 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
	ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.split('?')[0]
	if  ggdRiBo3smurLUGO and 'http' not in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = 'https:'+ggdRiBo3smurLUGO
	title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
	if gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB: title = gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB+title
	hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace(',','')
	count = count.replace(',','')
	count = JJDtX1PZyIgN2T.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB,BB0MgRSFCf5k6xyH4hLam
def A2uKOeby9MT(url,data='',WAEqF7ZldrmL9Xw=''):
	if WAEqF7ZldrmL9Xw=='': WAEqF7ZldrmL9Xw = 'ytInitialData'
	ASwKFJhGY15gO4tLTd6fN0M = yyYKmdtsAFic93()
	JZP07kjvbV = {'User-Agent':ASwKFJhGY15gO4tLTd6fN0M,'Cookie':'PREF=hl=ar'}
	global BBwb2NzsHE
	if not data: data = BBwb2NzsHE.getSetting('av.youtube.data')
	if data.count(':::')==4: XIlcQBxwEsmTvD32guYGtfACOa,key,UCwsM5Lng6GoqIrhxf4tjWpDv1,vQMKg0RqwDkcUriZ,BB0MgRSFCf5k6xyH4hLam = data.split(':::')
	else: XIlcQBxwEsmTvD32guYGtfACOa,key,UCwsM5Lng6GoqIrhxf4tjWpDv1,vQMKg0RqwDkcUriZ,BB0MgRSFCf5k6xyH4hLam = '','','','',''
	Gv7mT0LhB9YoOVpANMr = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":UCwsM5Lng6GoqIrhxf4tjWpDv1}}}
	if url==kU2ZXSViB3wLANOz8bH+'/shorts' or '/my_main_page_shorts_link' in url:
		url = kU2ZXSViB3wLANOz8bH+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		Gv7mT0LhB9YoOVpANMr['sequenceParams'] = XIlcQBxwEsmTvD32guYGtfACOa
		Gv7mT0LhB9YoOVpANMr = str(Gv7mT0LhB9YoOVpANMr)
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = kU2ZXSViB3wLANOz8bH+'/youtubei/v1/guide?key='+key
		Gv7mT0LhB9YoOVpANMr = str(Gv7mT0LhB9YoOVpANMr)
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and XIlcQBxwEsmTvD32guYGtfACOa:
		Gv7mT0LhB9YoOVpANMr['continuation'] = BB0MgRSFCf5k6xyH4hLam
		Gv7mT0LhB9YoOVpANMr['context']['client']['visitorData'] = XIlcQBxwEsmTvD32guYGtfACOa
		Gv7mT0LhB9YoOVpANMr = str(Gv7mT0LhB9YoOVpANMr)
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and vQMKg0RqwDkcUriZ:
		JZP07kjvbV.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':UCwsM5Lng6GoqIrhxf4tjWpDv1})
		JZP07kjvbV.update({'Cookie':'VISITOR_INFO1_LIVE='+vQMKg0RqwDkcUriZ})
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',JZP07kjvbV,'','','YOUTUBE-GET_PAGE_DATA-5th')
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',JZP07kjvbV,'','','YOUTUBE-GET_PAGE_DATA-6th')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('"innertubeApiKey".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if QF4KdRaN2q0: key = QF4KdRaN2q0[0]
	QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('"cver".*?"value".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if QF4KdRaN2q0: UCwsM5Lng6GoqIrhxf4tjWpDv1 = QF4KdRaN2q0[0]
	QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall('"visitorData".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if QF4KdRaN2q0: XIlcQBxwEsmTvD32guYGtfACOa = QF4KdRaN2q0[0]
	cookies = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): vQMKg0RqwDkcUriZ = cookies['VISITOR_INFO1_LIVE']
	SzY7aqbnEvWVi9xo5POl1BFK = XIlcQBxwEsmTvD32guYGtfACOa+':::'+key+':::'+UCwsM5Lng6GoqIrhxf4tjWpDv1+':::'+vQMKg0RqwDkcUriZ+':::'+BB0MgRSFCf5k6xyH4hLam
	if WAEqF7ZldrmL9Xw=='ytInitialData' and 'ytInitialData' in YBEsLq8gVw629cMGQP1T:
		aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('window\["ytInitialData"\] = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not aaDcwLKRqhOFfpmWYvgueMTinz8: aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('var ytInitialData = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',aaDcwLKRqhOFfpmWYvgueMTinz8[0])
	elif WAEqF7ZldrmL9Xw=='ytInitialGuideData' and 'ytInitialGuideData' in YBEsLq8gVw629cMGQP1T:
		aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('var ytInitialGuideData = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',aaDcwLKRqhOFfpmWYvgueMTinz8[0])
	elif '</script>' not in YBEsLq8gVw629cMGQP1T: kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',YBEsLq8gVw629cMGQP1T)
	else: kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = ''
	if 0:
		RA1u29NiFkEojSfvdm = str(kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7)
		if DQfHadYvTpy1UR: RA1u29NiFkEojSfvdm = RA1u29NiFkEojSfvdm.encode('utf8')
		open('S:\\0000emad.dat','wb').write(RA1u29NiFkEojSfvdm)
	BBwb2NzsHE.setSetting('av.youtube.data',SzY7aqbnEvWVi9xo5POl1BFK)
	return YBEsLq8gVw629cMGQP1T,kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7,SzY7aqbnEvWVi9xo5POl1BFK
def CBc1lYpjK2(url,ZJfCEzd2DxAvbiYg):
	search = GVfnMyZxiRI()
	if not search: return
	search = search.replace(' ','+')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/search?query='+search
	d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,ZJfCEzd2DxAvbiYg)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	search = search.replace(' ','+')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAg%253D%253D'
		else: qBNfvM61WAp2FlH7CYb5 = ''
		kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+qBNfvM61WAp2FlH7CYb5
	else:
		J1EFqwlbovtLGQVgKT3knfxRCs,LT9l7d8YFWzfpPUgV,LpB4ilMr6vVtQ = [],[],''
		tXM1DJW8Bg7TNiHal6VzOweusFY = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		kl5eIXT0jUNH2BJi = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		dvtBYAqefc1iwQN05r = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع يوتيوب - اختر الترتيب',tXM1DJW8Bg7TNiHal6VzOweusFY)
		if dvtBYAqefc1iwQN05r == -1: return
		a42qZEGHPR7vey = kl5eIXT0jUNH2BJi[dvtBYAqefc1iwQN05r]
		YBEsLq8gVw629cMGQP1T,xdm491qe0X7tGbyMDhaZ5zOioK,data = A2uKOeby9MT(FrC9LhHZWIySdGwNsuzqt5Rf01TXO+a42qZEGHPR7vey)
		if xdm491qe0X7tGbyMDhaZ5zOioK:
			try:
				akjC78lQFyGbS = xdm491qe0X7tGbyMDhaZ5zOioK['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for HH5mEvCWTnJwLKBd in range(len(akjC78lQFyGbS)):
					group = akjC78lQFyGbS[HH5mEvCWTnJwLKBd]['searchFilterGroupRenderer']['filters']
					for XXnqw8euimyP in range(len(group)):
						hLRwAl7jfc6tWPnO = group[XXnqw8euimyP]['searchFilterRenderer']
						if 'navigationEndpoint' in list(hLRwAl7jfc6tWPnO.keys()):
							wHiSfdBL1v9Kl3n5 = hLRwAl7jfc6tWPnO['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\u0026','&')
							title = hLRwAl7jfc6tWPnO['tooltip']
							title = title.replace('البحث عن ','')
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								LpB4ilMr6vVtQ = title
								tb4p6sRlFPcio = wHiSfdBL1v9Kl3n5
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ','')
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								LpB4ilMr6vVtQ = title
								tb4p6sRlFPcio = wHiSfdBL1v9Kl3n5
							if 'Sort by' in title: continue
							J1EFqwlbovtLGQVgKT3knfxRCs.append(CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title))
							LT9l7d8YFWzfpPUgV.append(wHiSfdBL1v9Kl3n5)
			except: pass
		if not LpB4ilMr6vVtQ: Ys1bfkLwCq538PIHiaWtXQ = ''
		else:
			J1EFqwlbovtLGQVgKT3knfxRCs = ['بدون فلتر',LpB4ilMr6vVtQ]+J1EFqwlbovtLGQVgKT3knfxRCs
			LT9l7d8YFWzfpPUgV = ['',tb4p6sRlFPcio]+LT9l7d8YFWzfpPUgV
			Upwuaflie5zLroKF2 = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع يوتيوب - اختر الفلتر',J1EFqwlbovtLGQVgKT3knfxRCs)
			if Upwuaflie5zLroKF2 == -1: return
			Ys1bfkLwCq538PIHiaWtXQ = LT9l7d8YFWzfpPUgV[Upwuaflie5zLroKF2]
		if Ys1bfkLwCq538PIHiaWtXQ: kHWT0XY2S6apruwxiB8FDl1 = kU2ZXSViB3wLANOz8bH+Ys1bfkLwCq538PIHiaWtXQ
		elif a42qZEGHPR7vey: kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+a42qZEGHPR7vey
		else: kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO
	d2JXnUMPmgsKBQqCE58lkZ(kHWT0XY2S6apruwxiB8FDl1)
	return
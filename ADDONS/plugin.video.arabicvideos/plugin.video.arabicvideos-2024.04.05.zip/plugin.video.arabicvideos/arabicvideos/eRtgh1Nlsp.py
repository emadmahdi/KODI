# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'YOUTUBE'
eMlwAzaLSj8ZEQ3txIGP = '_YUT_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,text,type,vYpMA3CxgcyR4VZJh):
	if	 mode==140: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==143: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url,type)
	elif mode==144: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS(url,text,vYpMA3CxgcyR4VZJh)
	elif mode==145: mL7BVKcSygkuoPbWlEF4YD = CBc1lYpjK2(url)
	elif mode==146: mL7BVKcSygkuoPbWlEF4YD = jjY6MJlwxGpiSvRQhzZk7Aatr(url)
	elif mode==147: mL7BVKcSygkuoPbWlEF4YD = dga5lMNQrUE2thAVRfD4pYHOz3sPv()
	elif mode==148: mL7BVKcSygkuoPbWlEF4YD = vXGZWOERbVtzP9cM2Si4peCauY()
	elif mode==149: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',149,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج','',290)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مواقع اختارها يوتيوب',kU2ZXSViB3wLANOz8bH+'/feed/guide_builder',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الصفحة الرئيسية',kU2ZXSViB3wLANOz8bH,144,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المحتوى الرائج',kU2ZXSViB3wLANOz8bH+'/feed/trending',146)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: قنوات عربية','',147)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: قنوات أجنبية','',148)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: افلام عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=فيلم',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: افلام اجنبية',kU2ZXSViB3wLANOz8bH+'/results?search_query=movie',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: مسرحيات عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=مسرحية',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات عربية',kU2ZXSViB3wLANOz8bH+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات اجنبية',kU2ZXSViB3wLANOz8bH+'/results?search_query=series&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: مسلسلات كارتون',kU2ZXSViB3wLANOz8bH+'/results?search_query=كارتون&sp=EgIQAw==',144)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'بحث: خطبة المرجعية',kU2ZXSViB3wLANOz8bH+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def dga5lMNQrUE2thAVRfD4pYHOz3sPv():
	egYaAP6oIWDjfzqX20HnKS(kU2ZXSViB3wLANOz8bH+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def vXGZWOERbVtzP9cM2Si4peCauY():
	egYaAP6oIWDjfzqX20HnKS(kU2ZXSViB3wLANOz8bH+'/results?search_query=tv&sp=EgJAAQ==')
	return
def CsUdRabWuh0M9F(url,type):
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5([url],FpjtBKrnu5SdfyOvEPIQ,type,url)
	return
def jjY6MJlwxGpiSvRQhzZk7Aatr(url):
	YBEsLq8gVw629cMGQP1T,ooRPprGBD89QXusn,data = A2uKOeby9MT(url)
	wZnazHF1v2 = ooRPprGBD89QXusn['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for uvTwHSmjyW6Vr0192IZ in range(len(wZnazHF1v2)):
		KxB8vVHUJg = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ]
		lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg,url,str(uvTwHSmjyW6Vr0192IZ))
	TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	ssFqk6JR7IdxECVLw0rc = 0
	for uvTwHSmjyW6Vr0192IZ in range(len(TnwI1Ug7aNxbX2YpyzWoB)):
		KxB8vVHUJg = TnwI1Ug7aNxbX2YpyzWoB[uvTwHSmjyW6Vr0192IZ]['itemSectionRenderer']['contents'][0]
		if list(KxB8vVHUJg['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		dnD6ZJOtXsEGPhk3gH,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = FFkr5MZCQHyRqIWoK(KxB8vVHUJg)
		if not title:
			ssFqk6JR7IdxECVLw0rc += 1
			title = 'فيديوهات رائجة '+str(ssFqk6JR7IdxECVLw0rc)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,144,'',str(uvTwHSmjyW6Vr0192IZ))
	key = JJDtX1PZyIgN2T.findall('"innertubeApiKey":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	YBEsLq8gVw629cMGQP1T,ooRPprGBD89QXusn,Gv7mT0LhB9YoOVpANMr = A2uKOeby9MT(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	for ZDIwmLuV5oA2XMk7pyi1PNgUc3O in range(3,4):
		wZnazHF1v2 = ooRPprGBD89QXusn['items'][ZDIwmLuV5oA2XMk7pyi1PNgUc3O]['guideSectionRenderer']['items']
		for uvTwHSmjyW6Vr0192IZ in range(len(wZnazHF1v2)):
			KxB8vVHUJg = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ]
			if 'YouTube Premium' in str(KxB8vVHUJg): continue
			lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg)
	return
def egYaAP6oIWDjfzqX20HnKS(url,data='',index=0):
	global BBwb2NzsHE
	if not data: data = BBwb2NzsHE.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_','')
	YBEsLq8gVw629cMGQP1T,ooRPprGBD89QXusn,Gv7mT0LhB9YoOVpANMr = A2uKOeby9MT(url,data)
	eAgVo2clMmwTSIaLFh,p8hCW4mn7V = '',''
	bbnzCkIBiPlYOXj3eWTESao = JJDtX1PZyIgN2T.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not bbnzCkIBiPlYOXj3eWTESao: bbnzCkIBiPlYOXj3eWTESao = JJDtX1PZyIgN2T.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not bbnzCkIBiPlYOXj3eWTESao: bbnzCkIBiPlYOXj3eWTESao = JJDtX1PZyIgN2T.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if bbnzCkIBiPlYOXj3eWTESao:
		eAgVo2clMmwTSIaLFh = '[COLOR FFC89008]'+bbnzCkIBiPlYOXj3eWTESao[0][0]+'[/COLOR]'
		wHiSfdBL1v9Kl3n5 = bbnzCkIBiPlYOXj3eWTESao[0][1]
		if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
		if 'list=' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+eAgVo2clMmwTSIaLFh,wHiSfdBL1v9Kl3n5,144)
	D1iVeWpt4MFQngKIZ0BHdvNlz = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	Jx1dK9W074PEs = not any(Y3YqSmycrIWksoH5N0MvC in url for Y3YqSmycrIWksoH5N0MvC in D1iVeWpt4MFQngKIZ0BHdvNlz)
	if Jx1dK9W074PEs and eAgVo2clMmwTSIaLFh:
		XVD2KB3xEJaU1stlpjP4kmo = 'البحث'
		LpB4ilMr6vVtQ = 'قوائم التشغيل'
		X3pyfvgDUaTweLY7NMbzPG = 'الفيديوهات'
		ggrVlBEjJA = 'القنوات'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+eAgVo2clMmwTSIaLFh,url,9999)
		if '"title":"بحث"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+XVD2KB3xEJaU1stlpjP4kmo,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url+'/playlists',144)
		if '"title":"الفيديوهات"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+X3pyfvgDUaTweLY7NMbzPG,url+'/videos',144)
		if '"title":"القنوات"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+ggrVlBEjJA,url+'/channels',144)
		if '"title":"Search"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+XVD2KB3xEJaU1stlpjP4kmo,url,145,'','','_REMEMBERRESULTS_')
		if '"title":"Playlists"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url+'/playlists',144)
		if '"title":"Videos"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+X3pyfvgDUaTweLY7NMbzPG,url+'/videos',144)
		if '"title":"Channels"' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+ggrVlBEjJA,url+'/channels',144)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	if 'search_query' in url:
		wZnazHF1v2 = ooRPprGBD89QXusn['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		vsDLphcd51EIutr3Xo = 0
		for ggjo5zu7yCiIOhrb in range(len(wZnazHF1v2)):
			if 'itemSectionRenderer' in list(wZnazHF1v2[ggjo5zu7yCiIOhrb].keys()):
				SSKjJYzWZhkQFm2dHGDwoX7 = wZnazHF1v2[ggjo5zu7yCiIOhrb]['itemSectionRenderer']
				nfgR1P5HLpqdvoUl2Z = len(str(SSKjJYzWZhkQFm2dHGDwoX7))
				if nfgR1P5HLpqdvoUl2Z>vsDLphcd51EIutr3Xo:
					vsDLphcd51EIutr3Xo = nfgR1P5HLpqdvoUl2Z
					p8hCW4mn7V = SSKjJYzWZhkQFm2dHGDwoX7
		if vsDLphcd51EIutr3Xo==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==kU2ZXSViB3wLANOz8bH:
		mOgKjNkMwU8z0xyvub93 = []
		mOgKjNkMwU8z0xyvub93.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		mOgKjNkMwU8z0xyvub93.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		mOgKjNkMwU8z0xyvub93.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		mOgKjNkMwU8z0xyvub93.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		mOgKjNkMwU8z0xyvub93.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		mOgKjNkMwU8z0xyvub93.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		mOgKjNkMwU8z0xyvub93.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		mOgKjNkMwU8z0xyvub93.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		A2OIzhLBX1tsxrRHD7,p8hCW4mn7V = SjkTC2e381AOHRJnDmZYVy(ooRPprGBD89QXusn,'',mOgKjNkMwU8z0xyvub93)
	if not p8hCW4mn7V:
		try:
			wZnazHF1v2 = ooRPprGBD89QXusn['contents']['twoColumnBrowseResultsRenderer']['tabs']
			vxtO15lf9GB2CsVaZFDNMILuTQU = '/videos' in url or '/playlists' in url or '/channels' in url
			QPCzBp1K6gtyN50F2RLieSYhUIkr = '"title":"الفيديوهات"' in YBEsLq8gVw629cMGQP1T or '"title":"قوائم التشغيل"' in YBEsLq8gVw629cMGQP1T or '"title":"القنوات"' in YBEsLq8gVw629cMGQP1T
			jNzUHSupCbsLMxq5QOvr = '"title":"Videos"' in YBEsLq8gVw629cMGQP1T or '"title":"Playlists"' in YBEsLq8gVw629cMGQP1T or '"title":"Channels"' in YBEsLq8gVw629cMGQP1T
			if vxtO15lf9GB2CsVaZFDNMILuTQU and (QPCzBp1K6gtyN50F2RLieSYhUIkr or jNzUHSupCbsLMxq5QOvr):
				for uvTwHSmjyW6Vr0192IZ in range(len(wZnazHF1v2)):
					if 'tabRenderer' not in list(wZnazHF1v2[uvTwHSmjyW6Vr0192IZ].keys()): continue
					TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ]['tabRenderer']
					try: ckgEClVn8Q1oNe0Sqr = TnwI1Ug7aNxbX2YpyzWoB['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][uvTwHSmjyW6Vr0192IZ]
					except: ckgEClVn8Q1oNe0Sqr = TnwI1Ug7aNxbX2YpyzWoB
					try: wHiSfdBL1v9Kl3n5 = ckgEClVn8Q1oNe0Sqr['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in wHiSfdBL1v9Kl3n5	and '/videos'		in url: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ] ; break
					elif '/playlists'	in wHiSfdBL1v9Kl3n5	and '/playlists'	in url: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ] ; break
					elif '/channels'	in wHiSfdBL1v9Kl3n5	and '/channels'		in url: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[uvTwHSmjyW6Vr0192IZ] ; break
					else: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[0]
			elif 'bp=' in url: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[index]
			else: TnwI1Ug7aNxbX2YpyzWoB = wZnazHF1v2[0]
			p8hCW4mn7V = TnwI1Ug7aNxbX2YpyzWoB['tabRenderer']['content']
		except: pass
	if not p8hCW4mn7V: return
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("ff['sectionListRenderer']")
	mOgKjNkMwU8z0xyvub93.append("ff['richGridRenderer']['contents']")
	mOgKjNkMwU8z0xyvub93.append("ff['contents']")
	mOgKjNkMwU8z0xyvub93.append("ff")
	ct8Eo0AGusOYR3qK2bWVHkpeQPwi = GlsezWv7iIro(u'كل قوائم التشغيل')
	CCcp5F9BSRQawPXnJ = GlsezWv7iIro(u'كل الفيديوهات')
	DrYOMpHNq9k6UtARS5QfX7EmyLKvdP = GlsezWv7iIro(u'كل القنوات')
	ZcEYr09LQ8BV2U5fTnKx = [ct8Eo0AGusOYR3qK2bWVHkpeQPwi,CCcp5F9BSRQawPXnJ,DrYOMpHNq9k6UtARS5QfX7EmyLKvdP,'All playlists','All videos','All channels']
	fVb48tnU09,ckgEClVn8Q1oNe0Sqr = SjkTC2e381AOHRJnDmZYVy(p8hCW4mn7V,index,mOgKjNkMwU8z0xyvub93)
	if 'list' in str(type(ckgEClVn8Q1oNe0Sqr)) and any(Y3YqSmycrIWksoH5N0MvC in str(ckgEClVn8Q1oNe0Sqr[0]) for Y3YqSmycrIWksoH5N0MvC in ZcEYr09LQ8BV2U5fTnKx): del ckgEClVn8Q1oNe0Sqr[0]
	for KLiovD7sSjF9Npged4z1VHIBy8rXxJ in range(len(ckgEClVn8Q1oNe0Sqr)):
		mOgKjNkMwU8z0xyvub93 = []
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['itemSectionRenderer']['header']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['horizontalCardListRenderer']['header']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['richSectionRenderer']['content']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['richItemRenderer']['content']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]['gameCardRenderer']['game']")
		mOgKjNkMwU8z0xyvub93.append("gg[index2]")
		A2OIzhLBX1tsxrRHD7,KxB8vVHUJg = SjkTC2e381AOHRJnDmZYVy(ckgEClVn8Q1oNe0Sqr,KLiovD7sSjF9Npged4z1VHIBy8rXxJ,mOgKjNkMwU8z0xyvub93)
		lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg,url,str(KLiovD7sSjF9Npged4z1VHIBy8rXxJ))
		if A2OIzhLBX1tsxrRHD7=='4':
			try:
				c3BeZ97bRhCyW = KxB8vVHUJg['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for NtqPSxFUcMby3 in range(len(c3BeZ97bRhCyW)):
					ywESxnPT5mUQWaiMftZqAYc630 = c3BeZ97bRhCyW[NtqPSxFUcMby3]
					lVOaASI3GBhYLm8bDuPMT(ywESxnPT5mUQWaiMftZqAYc630)
			except: pass
	NbI4DJ3rWOwRj = False
	if 'view=' not in url and fVb48tnU09=='8': NbI4DJ3rWOwRj = True
	if ':::' in Gv7mT0LhB9YoOVpANMr: XIlcQBxwEsmTvD32guYGtfACOa,key,SSQ9HbV0xlukUOY6GisNag,UCwsM5Lng6GoqIrhxf4tjWpDv1,BB0MgRSFCf5k6xyH4hLam,vQMKg0RqwDkcUriZ = Gv7mT0LhB9YoOVpANMr.split(':::')
	else: XIlcQBxwEsmTvD32guYGtfACOa,key,SSQ9HbV0xlukUOY6GisNag,UCwsM5Lng6GoqIrhxf4tjWpDv1,BB0MgRSFCf5k6xyH4hLam,vQMKg0RqwDkcUriZ = '','','','','',''
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,GHwMQ6AEyDKr3LuYheqRFkOWJg12C = '',''
	if PL2fM9WhpjEFb7:
		TeHFuUJ9hxlKzrwPvpCdWaf76B40 = str(PL2fM9WhpjEFb7[-1][1])
		if   eMlwAzaLSj8ZEQ3txIGP+'CHNL' in TeHFuUJ9hxlKzrwPvpCdWaf76B40: GHwMQ6AEyDKr3LuYheqRFkOWJg12C = 'CHANNELS'
		elif eMlwAzaLSj8ZEQ3txIGP+'USER' in TeHFuUJ9hxlKzrwPvpCdWaf76B40: GHwMQ6AEyDKr3LuYheqRFkOWJg12C = 'CHANNELS'
		elif eMlwAzaLSj8ZEQ3txIGP+'LIST' in TeHFuUJ9hxlKzrwPvpCdWaf76B40: GHwMQ6AEyDKr3LuYheqRFkOWJg12C = 'PLAYLISTS'
	if '"continuations"' in YBEsLq8gVw629cMGQP1T and '&list=' not in url and not NbI4DJ3rWOwRj and 'shelf_id' not in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/browse_ajax?ctoken='+SSQ9HbV0xlukUOY6GisNag
	elif '"token"' in YBEsLq8gVw629cMGQP1T and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/youtubei/v1/search?key='+key
	elif '"token"' in YBEsLq8gVw629cMGQP1T and 'bp=' not in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/youtubei/v1/browse?key='+key
	if FrC9LhHZWIySdGwNsuzqt5Rf01TXO: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة أخرى',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,144,GHwMQ6AEyDKr3LuYheqRFkOWJg12C,'',Gv7mT0LhB9YoOVpANMr)
	return
def SjkTC2e381AOHRJnDmZYVy(cJsUR2bM3WZmAFT,RZdc3HWpJk,ve1HFYmJD9wQ):
	ooRPprGBD89QXusn = cJsUR2bM3WZmAFT
	p8hCW4mn7V,index = cJsUR2bM3WZmAFT,RZdc3HWpJk
	ckgEClVn8Q1oNe0Sqr,KLiovD7sSjF9Npged4z1VHIBy8rXxJ = cJsUR2bM3WZmAFT,RZdc3HWpJk
	KxB8vVHUJg,sbYtLhC0XD = cJsUR2bM3WZmAFT,RZdc3HWpJk
	count = len(ve1HFYmJD9wQ)
	for uvTwHSmjyW6Vr0192IZ in range(count):
		try:
			wImcinprFPLQO3x0jKA = eval(ve1HFYmJD9wQ[uvTwHSmjyW6Vr0192IZ])
			return str(uvTwHSmjyW6Vr0192IZ+1),wImcinprFPLQO3x0jKA
		except: pass
	return '',''
def FFkr5MZCQHyRqIWoK(KxB8vVHUJg):
	try: qab1Px2OmuBVZ6s8giAWp7UDvlk = list(KxB8vVHUJg.keys())[0]
	except: return False,'','','','','','',''
	dnD6ZJOtXsEGPhk3gH,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = False,'','','','','','',''
	sbYtLhC0XD = KxB8vVHUJg[qab1Px2OmuBVZ6s8giAWp7UDvlk]
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("render['unplayableText']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['formattedTitle']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['title']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['title']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("render['text']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['text']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("render['title']")
	mOgKjNkMwU8z0xyvub93.append("item['title']")
	A2OIzhLBX1tsxrRHD7,title = SjkTC2e381AOHRJnDmZYVy(KxB8vVHUJg,sbYtLhC0XD,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	mOgKjNkMwU8z0xyvub93.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	A2OIzhLBX1tsxrRHD7,wHiSfdBL1v9Kl3n5 = SjkTC2e381AOHRJnDmZYVy(KxB8vVHUJg,sbYtLhC0XD,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("render['thumbnail']['thumbnails'][0]['url']")
	mOgKjNkMwU8z0xyvub93.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	A2OIzhLBX1tsxrRHD7,ggdRiBo3smurLUGO = SjkTC2e381AOHRJnDmZYVy(KxB8vVHUJg,sbYtLhC0XD,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("render['videoCount']")
	mOgKjNkMwU8z0xyvub93.append("render['videoCountText']['runs'][0]['text']")
	mOgKjNkMwU8z0xyvub93.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	A2OIzhLBX1tsxrRHD7,count = SjkTC2e381AOHRJnDmZYVy(KxB8vVHUJg,sbYtLhC0XD,mOgKjNkMwU8z0xyvub93)
	mOgKjNkMwU8z0xyvub93 = []
	mOgKjNkMwU8z0xyvub93.append("render['lengthText']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	mOgKjNkMwU8z0xyvub93.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	A2OIzhLBX1tsxrRHD7,hhCd56yES0cqfUKRsZaVI4wzWuTO = SjkTC2e381AOHRJnDmZYVy(KxB8vVHUJg,sbYtLhC0XD,mOgKjNkMwU8z0xyvub93)
	if 'LIVE' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V = '','LIVE:  '
	if 'مباشر' in hhCd56yES0cqfUKRsZaVI4wzWuTO: hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V = '','LIVE:  '
	if 'badges' in list(sbYtLhC0XD.keys()):
		jWfAG1Sd4RQ52pmPL9EsDB8uKTV = str(sbYtLhC0XD['badges'])
		if 'Free with Ads' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$:'
		if 'LIVE NOW' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: HHXCbZ9z84V = 'LIVE:  '
		if 'Buy' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV or 'Rent' in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:'
		if GlsezWv7iIro(u'مباشر') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: HHXCbZ9z84V = 'LIVE:  '
		if GlsezWv7iIro(u'شراء') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:'
		if GlsezWv7iIro(u'استئجار') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$$:'
		if GlsezWv7iIro(u'إعلانات') in jWfAG1Sd4RQ52pmPL9EsDB8uKTV: gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = '$:'
	wHiSfdBL1v9Kl3n5 = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(wHiSfdBL1v9Kl3n5)
	if wHiSfdBL1v9Kl3n5 and 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
	ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.split('?')[0]
	if  ggdRiBo3smurLUGO and 'http' not in ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = 'https:'+ggdRiBo3smurLUGO
	title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
	if gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB: title = gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB+'  '+title
	hhCd56yES0cqfUKRsZaVI4wzWuTO = hhCd56yES0cqfUKRsZaVI4wzWuTO.replace(',','')
	count = count.replace(',','')
	count = JJDtX1PZyIgN2T.findall('\d+',count)
	if count: count = count[0]
	else: count = ''
	return True,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB
def lVOaASI3GBhYLm8bDuPMT(KxB8vVHUJg,url='',index=''):
	dnD6ZJOtXsEGPhk3gH,title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,count,hhCd56yES0cqfUKRsZaVI4wzWuTO,HHXCbZ9z84V,gdMmoK9SfO8JCP5Vq0DNAxQrHeEwB = FFkr5MZCQHyRqIWoK(KxB8vVHUJg)
	if not dnD6ZJOtXsEGPhk3gH: return
	elif 'continuationItemRenderer' in str(KxB8vVHUJg): return
	elif 'searchPyvRenderer' in str(KxB8vVHUJg): return
	elif not wHiSfdBL1v9Kl3n5 and 'search_query' in url: return
	elif title and not wHiSfdBL1v9Kl3n5 and ('search_query' in url or 'horizontalMovieListRenderer' in str(KxB8vVHUJg) or url==kU2ZXSViB3wLANOz8bH):
		title = '=== '+title+' ==='
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+title,'',9999)
	elif title and 'messageRenderer' in str(KxB8vVHUJg):
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+title,'',9999)
	elif '/feed/trending' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,index)
	elif not title: return
	elif HHXCbZ9z84V: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+HHXCbZ9z84V+title,wHiSfdBL1v9Kl3n5,143,ggdRiBo3smurLUGO)
	elif 'watch?v=' in wHiSfdBL1v9Kl3n5 or '/shorts/' in wHiSfdBL1v9Kl3n5:
		if '&list=' in wHiSfdBL1v9Kl3n5 and 'index=' not in wHiSfdBL1v9Kl3n5:
			wwqVHTGK59fkCFRAlubS = wHiSfdBL1v9Kl3n5.split('&list=',1)[1]
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/playlist?list='+wwqVHTGK59fkCFRAlubS
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'LIST'+count+':  '+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO)
		else:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('&list=',1)[0]
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,143,ggdRiBo3smurLUGO,hhCd56yES0cqfUKRsZaVI4wzWuTO)
	else:
		type = ''
		if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = url
		elif not any(Y3YqSmycrIWksoH5N0MvC in wHiSfdBL1v9Kl3n5 for Y3YqSmycrIWksoH5N0MvC in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in wHiSfdBL1v9Kl3n5 or '/c/' in wHiSfdBL1v9Kl3n5: type = 'CHNL'+count+':  '
			if '/user/' in wHiSfdBL1v9Kl3n5: type = 'USER'+count+':  '
			index,GazhYcATC7mvUW203iDJqENRlS = '',''
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+type+title,wHiSfdBL1v9Kl3n5,144,ggdRiBo3smurLUGO,index)
	return
def A2uKOeby9MT(url,data='',WAEqF7ZldrmL9Xw=''):
	global BBwb2NzsHE
	if not data: data = BBwb2NzsHE.getSetting('av.youtube.data')
	if WAEqF7ZldrmL9Xw=='': WAEqF7ZldrmL9Xw = 'ytInitialData'
	ASwKFJhGY15gO4tLTd6fN0M = yyYKmdtsAFic93()
	JZP07kjvbV = {'User-Agent':ASwKFJhGY15gO4tLTd6fN0M,'Cookie':'PREF=hl=ar'}
	if ':::' in data: XIlcQBxwEsmTvD32guYGtfACOa,key,SSQ9HbV0xlukUOY6GisNag,UCwsM5Lng6GoqIrhxf4tjWpDv1,BB0MgRSFCf5k6xyH4hLam,vQMKg0RqwDkcUriZ = data.split(':::')
	else: XIlcQBxwEsmTvD32guYGtfACOa,key,SSQ9HbV0xlukUOY6GisNag,UCwsM5Lng6GoqIrhxf4tjWpDv1,BB0MgRSFCf5k6xyH4hLam,vQMKg0RqwDkcUriZ = '','','','','',''
	if 'guide?key=' in url:
		Gv7mT0LhB9YoOVpANMr = {}
		Gv7mT0LhB9YoOVpANMr['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":UCwsM5Lng6GoqIrhxf4tjWpDv1}}
		Gv7mT0LhB9YoOVpANMr = str(Gv7mT0LhB9YoOVpANMr)
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and XIlcQBxwEsmTvD32guYGtfACOa:
		Gv7mT0LhB9YoOVpANMr = {'continuation':BB0MgRSFCf5k6xyH4hLam}
		Gv7mT0LhB9YoOVpANMr['context'] = {"client":{"visitorData":XIlcQBxwEsmTvD32guYGtfACOa,"clientName":"WEB","clientVersion":UCwsM5Lng6GoqIrhxf4tjWpDv1}}
		Gv7mT0LhB9YoOVpANMr = str(Gv7mT0LhB9YoOVpANMr)
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',url,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and vQMKg0RqwDkcUriZ:
		JZP07kjvbV.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':UCwsM5Lng6GoqIrhxf4tjWpDv1})
		JZP07kjvbV.update({'Cookie':'VISITOR_INFO1_LIVE='+vQMKg0RqwDkcUriZ})
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',JZP07kjvbV,'','','YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'',JZP07kjvbV,'','','YOUTUBE-GET_PAGE_DATA-4th')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	ebG16mPuNdMwh2TnxOXzcqL0Z = JJDtX1PZyIgN2T.findall('"innertubeApiKey".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if ebG16mPuNdMwh2TnxOXzcqL0Z: key = ebG16mPuNdMwh2TnxOXzcqL0Z[0]
	ebG16mPuNdMwh2TnxOXzcqL0Z = JJDtX1PZyIgN2T.findall('"cver".*?"value".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if ebG16mPuNdMwh2TnxOXzcqL0Z: UCwsM5Lng6GoqIrhxf4tjWpDv1 = ebG16mPuNdMwh2TnxOXzcqL0Z[0]
	ebG16mPuNdMwh2TnxOXzcqL0Z = JJDtX1PZyIgN2T.findall('"token".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if ebG16mPuNdMwh2TnxOXzcqL0Z: BB0MgRSFCf5k6xyH4hLam = ebG16mPuNdMwh2TnxOXzcqL0Z[0]
	ebG16mPuNdMwh2TnxOXzcqL0Z = JJDtX1PZyIgN2T.findall('"visitorData".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if ebG16mPuNdMwh2TnxOXzcqL0Z: XIlcQBxwEsmTvD32guYGtfACOa = ebG16mPuNdMwh2TnxOXzcqL0Z[0]
	ebG16mPuNdMwh2TnxOXzcqL0Z = JJDtX1PZyIgN2T.findall('"continuation".*?"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.I)
	if ebG16mPuNdMwh2TnxOXzcqL0Z: SSQ9HbV0xlukUOY6GisNag = ebG16mPuNdMwh2TnxOXzcqL0Z[0]
	cookies = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): vQMKg0RqwDkcUriZ = cookies['VISITOR_INFO1_LIVE']
	data = XIlcQBxwEsmTvD32guYGtfACOa+':::'+key+':::'+SSQ9HbV0xlukUOY6GisNag+':::'+UCwsM5Lng6GoqIrhxf4tjWpDv1+':::'+BB0MgRSFCf5k6xyH4hLam+':::'+vQMKg0RqwDkcUriZ
	if WAEqF7ZldrmL9Xw=='ytInitialData' and 'ytInitialData' in YBEsLq8gVw629cMGQP1T:
		aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('window\["ytInitialData"\] = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not aaDcwLKRqhOFfpmWYvgueMTinz8: aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('var ytInitialData = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',aaDcwLKRqhOFfpmWYvgueMTinz8[0])
	elif WAEqF7ZldrmL9Xw=='ytInitialGuideData' and 'ytInitialGuideData' in YBEsLq8gVw629cMGQP1T:
		aaDcwLKRqhOFfpmWYvgueMTinz8 = JJDtX1PZyIgN2T.findall('var ytInitialGuideData = ({.*?});',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',aaDcwLKRqhOFfpmWYvgueMTinz8[0])
	elif '</script>' not in YBEsLq8gVw629cMGQP1T: kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = G8EwoDOyKShm1i0IHMfNYZlU7('str',YBEsLq8gVw629cMGQP1T)
	else: kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7 = ''
	BBwb2NzsHE.setSetting('av.youtube.data',data)
	return YBEsLq8gVw629cMGQP1T,kBKpOIE5yvTw2GMsSCA8Y0ltJfjgF7,data
def CBc1lYpjK2(url):
	search = GVfnMyZxiRI()
	if not search: return
	search = search.replace(' ','+')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'/search?query='+search
	egYaAP6oIWDjfzqX20HnKS(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	search = search.replace(' ','+')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in sdZQpO06qbHwAGPz7LCgu4lToE: qBNfvM61WAp2FlH7CYb5 = '&sp=EgIQAg%253D%253D'
		kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+qBNfvM61WAp2FlH7CYb5
	else:
		J1EFqwlbovtLGQVgKT3knfxRCs,LT9l7d8YFWzfpPUgV,LpB4ilMr6vVtQ = [],[],''
		tXM1DJW8Bg7TNiHal6VzOweusFY = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		kl5eIXT0jUNH2BJi = ['','&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		dvtBYAqefc1iwQN05r = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع يوتيوب - اختر الترتيب',tXM1DJW8Bg7TNiHal6VzOweusFY)
		if dvtBYAqefc1iwQN05r == -1: return
		a42qZEGHPR7vey = kl5eIXT0jUNH2BJi[dvtBYAqefc1iwQN05r]
		YBEsLq8gVw629cMGQP1T,xdm491qe0X7tGbyMDhaZ5zOioK,data = A2uKOeby9MT(FrC9LhHZWIySdGwNsuzqt5Rf01TXO+a42qZEGHPR7vey)
		if xdm491qe0X7tGbyMDhaZ5zOioK:
			akjC78lQFyGbS = xdm491qe0X7tGbyMDhaZ5zOioK['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for HH5mEvCWTnJwLKBd in range(len(akjC78lQFyGbS)):
				group = akjC78lQFyGbS[HH5mEvCWTnJwLKBd]['searchFilterGroupRenderer']['filters']
				for XXnqw8euimyP in range(len(group)):
					sbYtLhC0XD = group[XXnqw8euimyP]['searchFilterRenderer']
					if 'navigationEndpoint' in list(sbYtLhC0XD.keys()):
						wHiSfdBL1v9Kl3n5 = sbYtLhC0XD['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('\u0026','&')
						title = sbYtLhC0XD['tooltip']
						title = title.replace('البحث عن ','')
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							LpB4ilMr6vVtQ = title
							tb4p6sRlFPcio = wHiSfdBL1v9Kl3n5
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ','')
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							LpB4ilMr6vVtQ = title
							tb4p6sRlFPcio = wHiSfdBL1v9Kl3n5
						if 'Sort by' in title: continue
						J1EFqwlbovtLGQVgKT3knfxRCs.append(CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title))
						LT9l7d8YFWzfpPUgV.append(wHiSfdBL1v9Kl3n5)
		if not LpB4ilMr6vVtQ: Ys1bfkLwCq538PIHiaWtXQ = ''
		else:
			J1EFqwlbovtLGQVgKT3knfxRCs = ['بدون فلتر',LpB4ilMr6vVtQ]+J1EFqwlbovtLGQVgKT3knfxRCs
			LT9l7d8YFWzfpPUgV = ['',tb4p6sRlFPcio]+LT9l7d8YFWzfpPUgV
			Upwuaflie5zLroKF2 = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع يوتيوب - اختر الفلتر',J1EFqwlbovtLGQVgKT3knfxRCs)
			if Upwuaflie5zLroKF2 == -1: return
			Ys1bfkLwCq538PIHiaWtXQ = LT9l7d8YFWzfpPUgV[Upwuaflie5zLroKF2]
		if Ys1bfkLwCq538PIHiaWtXQ: kHWT0XY2S6apruwxiB8FDl1 = kU2ZXSViB3wLANOz8bH+Ys1bfkLwCq538PIHiaWtXQ
		elif a42qZEGHPR7vey: kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+a42qZEGHPR7vey
		else: kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO
	egYaAP6oIWDjfzqX20HnKS(kHWT0XY2S6apruwxiB8FDl1)
	return
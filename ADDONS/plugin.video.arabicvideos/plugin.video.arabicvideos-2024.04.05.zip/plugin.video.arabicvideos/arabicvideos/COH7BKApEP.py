# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭ᷠ")
def HYWukw3pL2oMzPK4(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,hulSHFUcXsaVQGTn8r9zMkNPIwgvo=KylMx0kfTOrG(u"ࠬ࠭ᷡ")):
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  Wbwj0o5gsXQ8F2f(u"࠴਩"): vdh2jbNTLscJMQG09wlnCY3W(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  Vt4ELHXZP6(u"࠷ਪ"): rDcxWnkhEUCJ(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  cg94WALw5orUhvtHSfNO(u"࠹ਫ"): sYBATZ9ylHDU6PQk()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  tjoHEAGv2XkrMBsVfCyp5U(u"࠴ਬ"): wfRngJdl2PDzHaXW(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  C0CbfZuXJM(u"࠶ਭ"): dHLU8x6rjFw()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  pOIe6U1vWYC7Gh2udFBRgT(u"࠸ਮ"): oCOWGuHNYfALx0()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  vlW6K1g8Xo35mPYbyO2GS(u"࠺ਯ"): uuzerSw4k8bt3QKD9cAjhgBvPMim(Wbwj0o5gsXQ8F2f(u"ࡕࡴࡸࡩ૜"),Wbwj0o5gsXQ8F2f(u"ࡕࡴࡸࡩ૜"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  GVPK9Ziaho6U2ySLj(u"࠼ਰ"): pSh4aBFoOe391qyA7EYmC2bn0GkVlc()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==  tjoHEAGv2XkrMBsVfCyp5U(u"࠾਱"): Ueiz9Cxh8QJVMEfwdR1cOI6()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==trSQHvP4aqBWFKxN5bZgXCu(u"࠷࠵࠱ਲ"): bVW0wxaLiI2uAe6hMTEOvt7()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==tjoHEAGv2XkrMBsVfCyp5U(u"࠱࠶࠳ਲ਼"): rrhfmpXuLqtD6l3o2EZVGNW()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==cg94WALw5orUhvtHSfNO(u"࠲࠷࠵਴"): LLKNOjU9Pbe71Rg()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==b098bsyjUud(u"࠳࠸࠷ਵ"): PPSJUI94lBhrfTgGz5cvY2()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==pOIe6U1vWYC7Gh2udFBRgT(u"࠴࠹࠹ਸ਼"): u67g8MkaY3CALUqx()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵࠺࠻਷"): EoH6Rlfp5ni()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==CC4UDLW6brf(u"࠶࠻࠶ਸ"): yyWlchfo68Mm()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==Yr0wo7FaSHx(u"࠷࠵࠸ਹ"): YbtvI8Jm2PZGsaRxULWlz0ioT()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==u2NDjURZVHlmdc0(u"࠱࠶࠺਺"): xogXmvCFHhbTpSsuRaGE()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==tvdQHb10PhNmuy6(u"࠲࠷࠼਻"): SSrIWDelfMtNcUdzAkF(A6Iyo7eXrq2RtMmDxWj(u"ࡖࡵࡹࡪ૝"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==Vt4ELHXZP6(u"࠳࠺࠴਼"): LLf9nm0FJYXRrEVGCce1wjdp8()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==G5TxeI0ND4ztC6(u"࠴࠻࠶਽"): ArgM8WhIktPwENlm1R4Kd3aHqO()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==KylMx0kfTOrG(u"࠵࠼࠸ਾ"): V2VoDzGIJflYU(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,GVPK9Ziaho6U2ySLj(u"ࡗࡶࡺ࡫૞"),GVPK9Ziaho6U2ySLj(u"ࡗࡶࡺ࡫૞"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==Wbwj0o5gsXQ8F2f(u"࠶࠽࠳ਿ"): w2chBfzYG4FlZR7QIbJHTyoKrdv(C0CbfZuXJM(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ᷢ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡘࡷࡻࡥ૟"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠷࠷࠵ੀ"): w2chBfzYG4FlZR7QIbJHTyoKrdv(CC4UDLW6brf(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪᷣ"),A6Iyo7eXrq2RtMmDxWj(u"࡙ࡸࡵࡦૠ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠱࠸࠷ੁ"): fKrUS71bCZP049mk5ov()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==xmTX9Aeidq8cVhY(u"࠲࠹࠹ੂ"): Svz9uiIDPCpYlRbFXytUgkds()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==u2NDjURZVHlmdc0(u"࠳࠺࠻੃"): J8kbHdvrDopY(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬᷤ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==C0CbfZuXJM(u"࠴࠻࠽੄"): J8kbHdvrDopY(DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩᷥ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==A6Iyo7eXrq2RtMmDxWj(u"࠵࠼࠿੅"): J8kbHdvrDopY(pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠪᷦ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==CC4UDLW6brf(u"࠶࠿࠰੆"): HwYLjQDqTP5k9F1CXhOte()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==GVPK9Ziaho6U2ySLj(u"࠷࠹࠲ੇ"): OdhmneuEgjNJPxB3YrTtzZW4UQS2G()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==WfgnOq9Fd4lhMSQpK5(u"࠱࠺࠴ੈ"): CubdyY19Z08nJUacDK()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠲࠻࠶੉"): nkJWMbO3Gv()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==KylMx0kfTOrG(u"࠳࠼࠸੊"): TYy02uDALVibcQolNMwGjFC69()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠴࠽࠺ੋ"): YpogBF5SOlcZrNtn1qmDkG()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==VVtQk9vwe7(u"࠵࠾࠼ੌ"): kkBoDHtCcLAr9G()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==C0CbfZuXJM(u"࠶࠿࠷੍"): UcLEgYKvT7Au6Go()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==VVtQk9vwe7(u"࠷࠹࠹੎"): FKrUMxiuXL0nONmTjh()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vlW6K1g8Xo35mPYbyO2GS(u"࠱࠺࠻੏"): lh0EHOCFWankLRPqU()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==C0CbfZuXJM(u"࠴࠶࠳੐"): fHReuOk79NEGiyP6sdbZD3(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==DItWNMaLOZ146CubYk8lfAwTy(u"࠵࠷࠵ੑ"): moO0HksFWS7NyZ()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==A6Iyo7eXrq2RtMmDxWj(u"࠶࠸࠷੒"): c0xlfywZO1jYsFqpPiGDaJb6EnB4e9()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==pOIe6U1vWYC7Gh2udFBRgT(u"࠷࠹࠹੓"): HvAFi82anhsjdXQL3rfT6BD()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==C0CbfZuXJM(u"࠸࠺࠴੔"): E7nCJk9OfjyM(vlW6K1g8Xo35mPYbyO2GS(u"࡚ࡲࡶࡧૡ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠹࠴࠶੕"): mQ63NA2MZp()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠳࠵࠸੖"): U6y7OMTJCE(vdHRKkIgTp56Je1OuNo(u"ࡆࡢ࡮ࡶࡩૢ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==b098bsyjUud(u"࠴࠶࠺੗"): LaqMoTyPh6J8sDCAN5IljkQXG91gp(vlW6K1g8Xo35mPYbyO2GS(u"ࡕࡴࡸࡩૣ"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==GVPK9Ziaho6U2ySLj(u"࠵࠷࠼੘"): rtmflbZ0zoXHSQyeREjv5()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==CC4UDLW6brf(u"࠶࠸࠾ਖ਼"): pass
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==GVPK9Ziaho6U2ySLj(u"࠹࠵࠶ਗ਼"): YijDf9c3UGv()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠺࠶࠱ਜ਼"): eGsZwmUE6l3rRYboMq9aX()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==xmTX9Aeidq8cVhY(u"࠻࠰࠳ੜ"): nNgI56u1qlQFoxM9DBYZbhcwKUf(b46fBrugtPDSYspzMQIx(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪᷧ"),KylMx0kfTOrG(u"ࡖࡵࡹࡪ૤"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==xmTX9Aeidq8cVhY(u"࠵࠱࠵੝"): XXy26KrxQdP4HRBGOCu(tgjCPKlcGephBE8ka)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==WfgnOq9Fd4lhMSQpK5(u"࠶࠲࠷ਫ਼"): XXy26KrxQdP4HRBGOCu(KoULXHCRWtulrsM1cP)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==xmTX9Aeidq8cVhY(u"࠷࠳࠹੟"): SSjl5idyt04Z()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==CC4UDLW6brf(u"࠸࠴࠻੠"): CHPE7xQVoMzsLhlKmnNgudSaRp4U(DItWNMaLOZ146CubYk8lfAwTy(u"ࡗࡶࡺ࡫૥"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==Vt4ELHXZP6(u"࠹࠵࠽੡"): Sx57dzTjBRuZ1YE4qWtV3(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,tvdQHb10PhNmuy6(u"ࠬ࠭ᷨ"),b46fBrugtPDSYspzMQIx(u"ࡘࡷࡻࡥ૦"))
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==oh1JUWa3LdnqTpz5(u"࠺࠶࠸੢"): kfqZAM5xpNH3GrWCUmeT7a()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==vdHRKkIgTp56Je1OuNo(u"࠻࠰࠺੣"): uCYBEtQzySe()
	return
def uCYBEtQzySe():
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧᷩ"),b46fBrugtPDSYspzMQIx(u"ࠧࠨᷪ"),G5TxeI0ND4ztC6(u"ࠨࠩᷫ"),xmTX9Aeidq8cVhY(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᷬ"),GVPK9Ziaho6U2ySLj(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬᷭ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6:
		E7nCJk9OfjyM(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡋࡧ࡬ࡴࡧ૧"))
		IN1vbO8YfAu05Qyi7jMVwkxSE(HnMP40juJfr6L1mexbWBV,G5TxeI0ND4ztC6(u"ࡔࡳࡷࡨ૩"),ebT9xRB63E(u"ࡌࡡ࡭ࡵࡨ૨"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(cg94WALw5orUhvtHSfNO(u"ࠫࠬᷮ"),KylMx0kfTOrG(u"ࠬ࠭ᷯ"),tvdQHb10PhNmuy6(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᷰ"),WfgnOq9Fd4lhMSQpK5(u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩᷱ"))
	return
def Sx57dzTjBRuZ1YE4qWtV3(f3pCnmFaVYx4zc1MNGBe5,MNm6AD7Xob9ShdgQKaPsuFrw4xC,showDialogs):
	LxomZnH9Ky = gxoYzqsnPQ.connect(pWKgVeBs5DjUcyv47PE0or2)
	LxomZnH9Ky.text_factory = str
	ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
	if wIqFesTOvYnu5S2dWfpBVC: ep9dh7mO0fPcUGu8DJt2R1bnv6 = tvdQHb10PhNmuy6(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫᷲ")
	else: ep9dh7mO0fPcUGu8DJt2R1bnv6 = C0CbfZuXJM(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨᷳ")
	ooRPprGBD89QXusn.execute(Vt4ELHXZP6(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫᷴ")+ep9dh7mO0fPcUGu8DJt2R1bnv6+KylMx0kfTOrG(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ᷵")+f3pCnmFaVYx4zc1MNGBe5+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࠨࠠ࠼ࠩ᷶"))
	Z2ARJehHkjndvF = ooRPprGBD89QXusn.fetchall()
	if Z2ARJehHkjndvF and MNm6AD7Xob9ShdgQKaPsuFrw4xC in [Yr0wo7FaSHx(u"᷷࠭ࠧ"),vdHRKkIgTp56Je1OuNo(u"ࠧࡦࡰࡤࡦࡱ࡫᷸ࠧ")]:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(Wbwj0o5gsXQ8F2f(u"ࠨ᷹ࠩ"),DItWNMaLOZ146CubYk8lfAwTy(u"᷺ࠩࠪ"),ebT9xRB63E(u"ࠪࠫ᷻"),Yr0wo7FaSHx(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᷼"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮᷽ࠡࠩ")+f3pCnmFaVYx4zc1MNGBe5+KylMx0kfTOrG(u"࠭ࠠ࡝ࡰ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ็อ์็็้ࠠๆสࠤ๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสโ฻ํ่์ࠦวๅฤ้ࠤฤࠧࠡࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢหี๋อๅอࠢ฼้ฬีࠧ᷾"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=VVtQk9vwe7(u"࠱੤"): return
		ooRPprGBD89QXusn.execute(vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑ᷿ࠥ࠭")+ep9dh7mO0fPcUGu8DJt2R1bnv6+G5TxeI0ND4ztC6(u"ࠨ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭Ḁ")+f3pCnmFaVYx4zc1MNGBe5+KylMx0kfTOrG(u"ࠩࠥࠤࡀ࠭ḁ"))
	elif MNm6AD7Xob9ShdgQKaPsuFrw4xC in [Wbwj0o5gsXQ8F2f(u"ࠪࠫḂ"),VVtQk9vwe7(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࠬḃ")]:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(KylMx0kfTOrG(u"ࠬ࠭Ḅ"),ebT9xRB63E(u"࠭ࠧḅ"),Yr0wo7FaSHx(u"ࠧࠨḆ"),ebT9xRB63E(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḇ"),VVtQk9vwe7(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭Ḉ")+f3pCnmFaVYx4zc1MNGBe5+Yr0wo7FaSHx(u"ࠪࠤࡡࡴ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๋ࠥแฺๆࠣ์๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦล๋ไสๅ์ࠦวๅฤ้ࠤฤࠧࠡࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢหี๋อๅอࠢ฼้ฬีࠧḉ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=Wbwj0o5gsXQ8F2f(u"࠲੥"): return
		if wIqFesTOvYnu5S2dWfpBVC: ooRPprGBD89QXusn.execute(xmTX9Aeidq8cVhY(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࡥࡰࡦࡩ࡫࡭࡫ࡶࡸࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫḊ")+f3pCnmFaVYx4zc1MNGBe5+CC4UDLW6brf(u"ࠬࠨࠩࠡ࠽ࠪḋ"))
		else: ooRPprGBD89QXusn.execute(xmTX9Aeidq8cVhY(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠣࠬࡦࡪࡤࡰࡰࡌࡈ࠱ࡻࡰࡥࡣࡷࡩࡗࡻ࡬ࡦ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭Ḍ")+f3pCnmFaVYx4zc1MNGBe5+vlW6K1g8Xo35mPYbyO2GS(u"ࠧࠣ࠮࠴࠭ࠥࡁࠧḍ"))
	LxomZnH9Ky.commit()
	LxomZnH9Ky.close()
	Mrx2OeZV1LNjBsQ58Savi7.sleep(C0CbfZuXJM(u"࠳੦"))
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(ebT9xRB63E(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬḎ"))
	Mrx2OeZV1LNjBsQ58Savi7.sleep(vdHRKkIgTp56Je1OuNo(u"࠴੧"))
	if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࠪḏ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࠫḐ"),Wbwj0o5gsXQ8F2f(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧḑ"),KylMx0kfTOrG(u"ࠬะๅหࠢส่฾๋ไ๋หࠣฬ๋าวฮࠩḒ"))
	if MNm6AD7Xob9ShdgQKaPsuFrw4xC in [VVtQk9vwe7(u"࠭ࠧḓ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡦࡰࡤࡦࡱ࡫ࠧḔ")]: SSrIWDelfMtNcUdzAkF(showDialogs)
	return
def SSjl5idyt04Z():
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,CC4UDLW6brf(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫḕ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬḖ"))
	dnM34UCiobvTqW = nOhiJ5zmHfxwaItpB6XPcA(G5TxeI0ND4ztC6(u"ࡇࡣ࡯ࡷࡪ૪"))
	QNEwHLqRgZ89OoIGYsPJCya4ShX3Tk = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡠࡳ࠭ḗ")
	g0A8PLU4fyDe7 = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫḘ")
	jPGeyqLNkudiOcRZBYgow6FbmWaAp = Wbwj0o5gsXQ8F2f(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫḙ")
	for id,YqywcljIHsFzoXaf0T97,EGaITWmJw64udk7zZq2OAM,cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq,reason in reversed(dnM34UCiobvTqW):
		if id==ebT9xRB63E(u"࠭࠰ࠨḚ"):
			N6SrZHYfqclvLaCIU7pWu1kdsJDK,FHuTUy4i1fGq = cFKVo2vauG0BRnXPmUdSpJCO6.split(Vt4ELHXZP6(u"ࠧ࡝ࡰ࠾࠿ࠬḛ"))
			continue
		if QNEwHLqRgZ89OoIGYsPJCya4ShX3Tk!=CC4UDLW6brf(u"ࠨ࡞ࡱࠫḜ"): QNEwHLqRgZ89OoIGYsPJCya4ShX3Tk += jPGeyqLNkudiOcRZBYgow6FbmWaAp
		DDTdLb3SZQPv7rX1qfwHCpn2eyKc = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪḝ")+id+vlW6K1g8Xo35mPYbyO2GS(u"ࠪࠤ࠿ࠦࠧḞ")+vdHRKkIgTp56Je1OuNo(u"ࠫฬ๊ำลษ็ࠤ࠿ࠦࠧḟ")+DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧḠ")+EGaITWmJw64udk7zZq2OAM
		d1cgFMGN2Eaoz9AelBI = uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭࡜࡯࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็ะํอศࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬḡ")+cFKVo2vauG0BRnXPmUdSpJCO6
		sHCNe7qXk2m = cg94WALw5orUhvtHSfNO(u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ศๆั฻ศࠦ࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪḢ")+sOu6vWYyjC9VREepAh10cXq
		R8Rag2sH1WBKOSFovjkdLn = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ศษࠢ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ḣ")+reason
		QNEwHLqRgZ89OoIGYsPJCya4ShX3Tk += DDTdLb3SZQPv7rX1qfwHCpn2eyKc+d1cgFMGN2Eaoz9AelBI+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩ࡟ࡲࠬḤ")+g0A8PLU4fyDe7+G5TxeI0ND4ztC6(u"ࠪࡠࡳ࠭ḥ")+sHCNe7qXk2m+R8Rag2sH1WBKOSFovjkdLn+Vt4ELHXZP6(u"ࠫࡡࡴࠧḦ")
	u59uk1YqFUTd(C0CbfZuXJM(u"ࠬࡸࡩࡨࡪࡷࠫḧ"),FHuTUy4i1fGq,QNEwHLqRgZ89OoIGYsPJCya4ShX3Tk,vdHRKkIgTp56Je1OuNo(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧḨ"))
	return
def XXy26KrxQdP4HRBGOCu(file):
	if file==KoULXHCRWtulrsM1cP: BBHMzSuJhoj3kFR0wWA7Xap1yqOrE = u2NDjURZVHlmdc0(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧḩ")
	elif file==tgjCPKlcGephBE8ka: BBHMzSuJhoj3kFR0wWA7Xap1yqOrE = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨḪ")
	d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(CC4UDLW6brf(u"ࠩࡦࡩࡳࡺࡥࡳࠩḫ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ุ้ࠪำࠧḬ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫส฻ไศฯࠪḭ"),WfgnOq9Fd4lhMSQpK5(u"ࠬิั้ฮࠪḮ"),GVPK9Ziaho6U2ySLj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩḯ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬḰ")+BBHMzSuJhoj3kFR0wWA7Xap1yqOrE+KylMx0kfTOrG(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨḱ"))
	if d1cy9GkbBivnRNTChoEFu5xIXp4==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴੨"):
		if A73K6zLXIgFROeCHJQi0Pbos.path.exists(file):
			try: A73K6zLXIgFROeCHJQi0Pbos.remove(file)
			except: pass
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(A6Iyo7eXrq2RtMmDxWj(u"ࠩࠪḲ"),b46fBrugtPDSYspzMQIx(u"ࠪࠫḳ"),GVPK9Ziaho6U2ySLj(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧḴ"),vdHRKkIgTp56Je1OuNo(u"ࠬะๅࠡ็ึั๋ࠥไโࠢࠪḵ")+BBHMzSuJhoj3kFR0wWA7Xap1yqOrE)
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==u2NDjURZVHlmdc0(u"࠶੩"):
		data = qqlgo4zmvG7sYR(file)
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(G5TxeI0ND4ztC6(u"࠭ࠧḶ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠨḷ"),xmTX9Aeidq8cVhY(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḸ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩḹ")+BBHMzSuJhoj3kFR0wWA7Xap1yqOrE)
	return
def eGsZwmUE6l3rRYboMq9aX():
	if WWSLAyQdhUXl3ovb<Vt4ELHXZP6(u"࠷࠸੪"):
		Ay3eLGaTncD67lx8ZOud = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭Ḻ")+str(WWSLAyQdhUXl3ovb)+CC4UDLW6brf(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬḻ")
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(VVtQk9vwe7(u"ࠬ࠭Ḽ"),WfgnOq9Fd4lhMSQpK5(u"࠭ࠧḽ"),cg94WALw5orUhvtHSfNO(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪḾ"),Ay3eLGaTncD67lx8ZOud)
		return
	PPiftToaU4hMWXsuyEgLzd = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫḿ"))
	gFdBaQ9bzKVRS = AwnlUgaf453N7P20([vdHRKkIgTp56Je1OuNo(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨṀ")])
	vuTHKR8XOry1aEF5P7m2WAhLSQU,QQaEIJsRgpw4W5823dVCeG,QAsCTKBoIkbrMP,qqNtyjr3HdElznmDWbesYvgSL19V,JUWFbMGH4p1jx,LTnkjge7ZHNA,SBw5f9TFWh6YPe = gFdBaQ9bzKVRS[vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩṁ")]
	if vuTHKR8XOry1aEF5P7m2WAhLSQU or Yr0wo7FaSHx(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪṂ") not in str(PPiftToaU4hMWXsuyEgLzd):
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(oh1JUWa3LdnqTpz5(u"ࠬ࠭ṃ"),b46fBrugtPDSYspzMQIx(u"࠭ࠧṄ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪṅ"),WfgnOq9Fd4lhMSQpK5(u"ࠨษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭Ṇ"))
		llC9WmbrAIgpzfi3n = nNgI56u1qlQFoxM9DBYZbhcwKUf(b46fBrugtPDSYspzMQIx(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨṇ"),xmTX9Aeidq8cVhY(u"ࡖࡵࡹࡪ૫"))
		if not llC9WmbrAIgpzfi3n: return
	g9geWoX2BkcOJYUCGIfli830vbpr(WfgnOq9Fd4lhMSQpK5(u"ࡗࡶࡺ࡫૬"))
	return
def g9geWoX2BkcOJYUCGIfli830vbpr(showDialogs=trSQHvP4aqBWFKxN5bZgXCu(u"ࡘࡷࡻࡥ૭")):
	PPiftToaU4hMWXsuyEgLzd = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(xmTX9Aeidq8cVhY(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭Ṉ"))
	if cg94WALw5orUhvtHSfNO(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪṉ") not in str(PPiftToaU4hMWXsuyEgLzd):
		if showDialogs:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬ࠭Ṋ"),b098bsyjUud(u"࠭ࠧṋ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪṌ"),cg94WALw5orUhvtHSfNO(u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭ṍ"))
		return
	kbM6v3pKdY1gFSo7tPLRGTBZH9ajO = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,Yr0wo7FaSHx(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩṎ"),xmTX9Aeidq8cVhY(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩṏ"),vdHRKkIgTp56Je1OuNo(u"ࠫ࠼࠸࠰ࡱࠩṐ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭ṑ"))
	if not A73K6zLXIgFROeCHJQi0Pbos.path.exists(kbM6v3pKdY1gFSo7tPLRGTBZH9ajO): return
	rxqXYiSVaLWp3e1yQncJ57 = open(kbM6v3pKdY1gFSo7tPLRGTBZH9ajO,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡲࡣࠩṒ")).read()
	if DQfHadYvTpy1UR: rxqXYiSVaLWp3e1yQncJ57 = rxqXYiSVaLWp3e1yQncJ57.decode(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡶࡶࡩ࠼ࠬṓ"))
	FSdrh4JEC6bOymKLvHN0X2ZP9wj = JJDtX1PZyIgN2T.findall(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨṔ"),rxqXYiSVaLWp3e1yQncJ57,JJDtX1PZyIgN2T.DOTALL)
	S0XqrTVIcApxQB4nO2g,WyEVnFb1eg0CHoRjM5YXA6kiUqfQhD = FSdrh4JEC6bOymKLvHN0X2ZP9wj[b098bsyjUud(u"࠰੫")]
	l8lrtcHaqGRkIS = Wbwj0o5gsXQ8F2f(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪṕ")+S0XqrTVIcApxQB4nO2g+WfgnOq9Fd4lhMSQpK5(u"ࠪ࠰ࠬṖ")+WyEVnFb1eg0CHoRjM5YXA6kiUqfQhD+VVtQk9vwe7(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ṗ")
	if showDialogs:
		F7dtHv2yUOe1LEaZ60NcCQ5SGnMz = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(Wbwj0o5gsXQ8F2f(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪṘ"))
		if F7dtHv2yUOe1LEaZ60NcCQ5SGnMz==vdHRKkIgTp56Je1OuNo(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩṙ"): ENCGKc7TSJrn3HFP5B8XUtoD = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧṚ")
		elif F7dtHv2yUOe1LEaZ60NcCQ5SGnMz==WfgnOq9Fd4lhMSQpK5(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧṛ"): ENCGKc7TSJrn3HFP5B8XUtoD = Vt4ELHXZP6(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧṜ")
		else: ENCGKc7TSJrn3HFP5B8XUtoD = trSQHvP4aqBWFKxN5bZgXCu(u"ࠪๆํอฦๆࠢฦาึ๏ࠧṝ")
		d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫṞ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"่่ࠬศศ่ࠤศิั๊ࠩṟ"),ebT9xRB63E(u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭Ṡ"),CC4UDLW6brf(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬṡ"),WfgnOq9Fd4lhMSQpK5(u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬṢ")+ENCGKc7TSJrn3HFP5B8XUtoD,oh1JUWa3LdnqTpz5(u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫṣ"))
		if d1cy9GkbBivnRNTChoEFu5xIXp4==GVPK9Ziaho6U2ySLj(u"࠲੬"): j74uS2OdyGCkDF60R8fQqcmZ = Yr0wo7FaSHx(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭Ṥ")
		elif d1cy9GkbBivnRNTChoEFu5xIXp4==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠴੭"): j74uS2OdyGCkDF60R8fQqcmZ = G5TxeI0ND4ztC6(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪṥ")
		else: j74uS2OdyGCkDF60R8fQqcmZ = Yr0wo7FaSHx(u"ࠬ࠭Ṧ")
	else:
		F7dtHv2yUOe1LEaZ60NcCQ5SGnMz = BBwb2NzsHE.getSetting(A6Iyo7eXrq2RtMmDxWj(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫṧ"))
		if   F7dtHv2yUOe1LEaZ60NcCQ5SGnMz==G5TxeI0ND4ztC6(u"ࠧࠨṨ"): d1cy9GkbBivnRNTChoEFu5xIXp4 = Wbwj0o5gsXQ8F2f(u"࠳੮")
		elif F7dtHv2yUOe1LEaZ60NcCQ5SGnMz==VVtQk9vwe7(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫṩ"): d1cy9GkbBivnRNTChoEFu5xIXp4 = trSQHvP4aqBWFKxN5bZgXCu(u"࠵੯")
		elif F7dtHv2yUOe1LEaZ60NcCQ5SGnMz==DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨṪ"): d1cy9GkbBivnRNTChoEFu5xIXp4 = u2NDjURZVHlmdc0(u"࠷ੰ")
		j74uS2OdyGCkDF60R8fQqcmZ = F7dtHv2yUOe1LEaZ60NcCQ5SGnMz
	if   d1cy9GkbBivnRNTChoEFu5xIXp4==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠶ੱ"): kUvoqbrjMygwI2p = Vt4ELHXZP6(u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧṫ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==C0CbfZuXJM(u"࠱ੲ"): kUvoqbrjMygwI2p = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨṬ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==VVtQk9vwe7(u"࠳ੳ"): kUvoqbrjMygwI2p = G5TxeI0ND4ztC6(u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩṭ")
	else: return
	BBwb2NzsHE.setSetting(b46fBrugtPDSYspzMQIx(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫṮ"),j74uS2OdyGCkDF60R8fQqcmZ)
	DUiTvqjcdzeJHxpKtSLZ0a1XkrC = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨṯ")+kUvoqbrjMygwI2p+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨ࠮ࠪṰ")+WyEVnFb1eg0CHoRjM5YXA6kiUqfQhD+A6Iyo7eXrq2RtMmDxWj(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫṱ")
	SMDOwX1AKRdFoupI0Q4ei = rxqXYiSVaLWp3e1yQncJ57.replace(l8lrtcHaqGRkIS,DUiTvqjcdzeJHxpKtSLZ0a1XkrC)
	if DQfHadYvTpy1UR: SMDOwX1AKRdFoupI0Q4ei = SMDOwX1AKRdFoupI0Q4ei.encode(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡹࡹ࡬࠸ࠨṲ"))
	open(kbM6v3pKdY1gFSo7tPLRGTBZH9ajO,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࡼࡨࠧṳ")).write(SMDOwX1AKRdFoupI0Q4ei)
	b6kj4LJ5tzTeOMQi(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡔࡏࡕࡋࡆࡉࠬṴ"),WfgnOq9Fd4lhMSQpK5(u"࠭࠮ࠡࠢࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫṵ")+kUvoqbrjMygwI2p+b098bsyjUud(u"ࠧࠡ࡟ࠪṶ"))
	if showDialogs: Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧṷ"))
	return
def YijDf9c3UGv():
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(WfgnOq9Fd4lhMSQpK5(u"ࠩࠪṸ"),vdHRKkIgTp56Je1OuNo(u"ࠪࠫṹ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࠬṺ"),oh1JUWa3LdnqTpz5(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨṻ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦรๅวุำฬืࠠใัํ้ࠥ࠴࠮࠯ࠢฦ์ࠥอๆห่้๋ࠢ๎ูࠡ็้ࠤฬูสฯัส้ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤศ๎ࠠๅัํ็๋ࠥิไๆฬࠤศิั๊ࠢอาฺࠦฬ่ษี็ࠥษๆห๋่ࠢฬࠦสฯืࠣฬ็๐ษࠡะ็ๆࠥอไๅ้ࠣࡠࡳࡢ࡮ࠡฯส์้ࠦสฮัํฯࠥอไษำ้ห๊าࠠฤ๊ࠣหฯ฻ไࠡสส่๊ฮัๆฮ่๊ࠣ฿ัโหࠣือฮࠠศๆุ่่๊ษࠡ฻้ำ่ࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำีࠡษ็ฮาี๊ฬษอࠤฬ๊ย็ࠢยࠫṼ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==oh1JUWa3LdnqTpz5(u"࠳ੴ"): uuzerSw4k8bt3QKD9cAjhgBvPMim(Yr0wo7FaSHx(u"࡙ࡸࡵࡦ૮"),Yr0wo7FaSHx(u"࡙ࡸࡵࡦ૮"))
	return
def pSh4aBFoOe391qyA7EYmC2bn0GkVlc():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(VVtQk9vwe7(u"ࠧࠨṽ"),ebT9xRB63E(u"ࠨࠩṾ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬṿ"),b46fBrugtPDSYspzMQIx(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭Ẁ"))
	return
def rtmflbZ0zoXHSQyeREjv5():
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẁ")
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc += Wbwj0o5gsXQ8F2f(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫẂ")
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc += u2NDjURZVHlmdc0(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩẃ")
	d1cgFMGN2Eaoz9AelBI = KylMx0kfTOrG(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟หี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫẄ")
	d1cgFMGN2Eaoz9AelBI += mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬẅ")
	d1cgFMGN2Eaoz9AelBI += jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷࡡ࠯ࡄࡑࡏࡓࡗࡣࠧẆ")
	Ay3eLGaTncD67lx8ZOud = xmTX9Aeidq8cVhY(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩẇ")+DDTdLb3SZQPv7rX1qfwHCpn2eyKc+CC4UDLW6brf(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩẈ")+d1cgFMGN2Eaoz9AelBI
	u59uk1YqFUTd(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡸࡩࡨࡪࡷࠫẉ"),C0CbfZuXJM(u"࠭ࠧẊ"),Ay3eLGaTncD67lx8ZOud)
	return
def U6y7OMTJCE(u5yYiXzKRhjqoG8t):
	XjZeYzB5J0(u5yYiXzKRhjqoG8t,GVPK9Ziaho6U2ySLj(u"ࡌࡡ࡭ࡵࡨ૯"))
	dnM34UCiobvTqW = nOhiJ5zmHfxwaItpB6XPcA(u5yYiXzKRhjqoG8t)
	id,YqywcljIHsFzoXaf0T97,EGaITWmJw64udk7zZq2OAM,cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq,reason = dnM34UCiobvTqW[trSQHvP4aqBWFKxN5bZgXCu(u"࠳ੵ")]
	N6SrZHYfqclvLaCIU7pWu1kdsJDK,FHuTUy4i1fGq = cFKVo2vauG0BRnXPmUdSpJCO6.split(vdHRKkIgTp56Je1OuNo(u"ࠧ࡝ࡰ࠾࠿ࠬẋ"))
	d1cgFMGN2Eaoz9AelBI,sHCNe7qXk2m,R8Rag2sH1WBKOSFovjkdLn = sOu6vWYyjC9VREepAh10cXq.split(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ࡞ࡱ࠿ࡀ࠭Ẍ"))
	vSZhyuNrK4z72 = ebT9xRB63E(u"ࡔࡳࡷࡨ૰")
	while vSZhyuNrK4z72:
		n5y6fPaYVzqJQIl8XBHk1 = VYEiZteQcrT7aqOBMRAyHC9(cg94WALw5orUhvtHSfNO(u"ࠩࠪẍ"),b46fBrugtPDSYspzMQIx(u"ࠪาึ๎ฬࠨẎ"),A6Iyo7eXrq2RtMmDxWj(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪẏ"),pOIe6U1vWYC7Gh2udFBRgT(u"่ࠬวว็ฬࠤฬ๊สษำ฼หฯ࠭Ẑ"),DItWNMaLOZ146CubYk8lfAwTy(u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢ࠽ࠤࠥะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ั࠭ẑ"),d1cgFMGN2Eaoz9AelBI)
		if n5y6fPaYVzqJQIl8XBHk1==Vt4ELHXZP6(u"࠶੶"): m0mxEPCQ1RXUfW = VYEiZteQcrT7aqOBMRAyHC9(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠨẒ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࠩẓ"),ebT9xRB63E(u"ࠩ฼์ิฯࠧẔ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫẕ"),G5TxeI0ND4ztC6(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫẖ"),sHCNe7qXk2m,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩẗ"))
		elif n5y6fPaYVzqJQIl8XBHk1==C0CbfZuXJM(u"࠶੷"): rDcxWnkhEUCJ()
		else: vSZhyuNrK4z72 = Vt4ELHXZP6(u"ࡇࡣ࡯ࡷࡪ૱")
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(b46fBrugtPDSYspzMQIx(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪẘ"))
	return
def E7nCJk9OfjyM(showDialogs):
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = C0CbfZuXJM(u"ࡖࡵࡹࡪ૲")
	if showDialogs: J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(b098bsyjUud(u"ࠧࡤࡧࡱࡸࡪࡸࠧẙ"),Vt4ELHXZP6(u"ࠨࠩẚ"),b46fBrugtPDSYspzMQIx(u"ࠩࠪẛ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪืษอไࠨẜ"),G5TxeI0ND4ztC6(u"ࠫ์๊ࠠฤ่อࠤ๊ะรไัࠣ์ฯื๊ะ่ࠢืา่ࠦหืไ๎ึࠦฬๆ์฼ࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰ࠣั๏ัࠠห฻๋ำࠥาๅ๋฻ࠣห้หูะษาหฯࠦลๅ๋ࠣ์฻฿๊สࠢอฯอ๐สࠡษ็ฬึ์วๆฮࠣรࠬẝ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6:
		llC9WmbrAIgpzfi3n = vlW6K1g8Xo35mPYbyO2GS(u"ࡗࡶࡺ࡫૳")
		if A73K6zLXIgFROeCHJQi0Pbos.path.exists(eexits2XpJ):
			try: A73K6zLXIgFROeCHJQi0Pbos.remove(eexits2XpJ)
			except: llC9WmbrAIgpzfi3n = CC4UDLW6brf(u"ࡊࡦࡲࡳࡦ૴")
		if showDialogs:
			if llC9WmbrAIgpzfi3n: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Yr0wo7FaSHx(u"ࠬ࠭ẞ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࠧẟ"),oh1JUWa3LdnqTpz5(u"ࠧࠨẠ"),tvdQHb10PhNmuy6(u"ࠨฬ่ࠤอ์ฬศฯุ้ࠣำ้ࠠฬุๅ๏ืࠠๆๆไࠤส฿ฯศัสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠨạ"))
			else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠪẢ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࠫả"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࠬẤ"),oh1JUWa3LdnqTpz5(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬấ"))
	return
def mQ63NA2MZp():
	HwYLjQDqTP5k9F1CXhOte()
	oeJvDKTQu3clz5mPkFafYr8d = BBwb2NzsHE.getSetting(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬẦ"))
	Ay3eLGaTncD67lx8ZOud = {}
	Ay3eLGaTncD67lx8ZOud[cg94WALw5orUhvtHSfNO(u"ࠧࡂࡗࡗࡓࠬầ")] = cg94WALw5orUhvtHSfNO(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧẨ")
	Ay3eLGaTncD67lx8ZOud[A6Iyo7eXrq2RtMmDxWj(u"ࠩࡖࡘࡔࡖࠧẩ")] = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩẪ")
	Ay3eLGaTncD67lx8ZOud[vdHRKkIgTp56Je1OuNo(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬẫ")] = oh1JUWa3LdnqTpz5(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭Ậ")+str(A1DMaRiPpTLJQvw6B7OdKbU439/vlW6K1g8Xo35mPYbyO2GS(u"࠼࠰੸"))+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠠะไํๆฮࠦแใูࠪậ")
	YTfi7PmKE8RjQFrdIxSXC = Ay3eLGaTncD67lx8ZOud[oeJvDKTQu3clz5mPkFafYr8d]
	d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(ebT9xRB63E(u"ࠧࠨẮ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠨๅสุࠥ࠭ắ")+str(A1DMaRiPpTLJQvw6B7OdKbU439/xmTX9Aeidq8cVhY(u"࠶࠱੹"))+vdHRKkIgTp56Je1OuNo(u"ࠩࠣำ็๐โสࠩẰ"),C0CbfZuXJM(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩằ"),u2NDjURZVHlmdc0(u"ࠫส๐โศใࠣ็ฬ๋ไࠨẲ"),YTfi7PmKE8RjQFrdIxSXC,WfgnOq9Fd4lhMSQpK5(u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆๆหูࠦวๅาๆ๎ࠥอไหๆๅหห๐ࠠฤ็ࠣฮึ๐ฯࠡวํๆฬ็ࠠศๆๆหูࠦศศๆๆห๊๊ࠠฤ็ࠣฮึ๐ฯࠡๅสุࠥ฿ๅา้ࠣๆฺ๐ัࠡฮาหࠥลࠡࠨẳ"))
	if d1cy9GkbBivnRNTChoEFu5xIXp4==pOIe6U1vWYC7Gh2udFBRgT(u"࠱੺"): QQGNuL4dXKZRF = trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧẴ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==ebT9xRB63E(u"࠳੻"): QQGNuL4dXKZRF = tvdQHb10PhNmuy6(u"ࠧࡂࡗࡗࡓࠬẵ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==cg94WALw5orUhvtHSfNO(u"࠵੼"): QQGNuL4dXKZRF = GVPK9Ziaho6U2ySLj(u"ࠨࡕࡗࡓࡕ࠭Ặ")
	else: QQGNuL4dXKZRF = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࠪặ")
	if QQGNuL4dXKZRF:
		BBwb2NzsHE.setSetting(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩẸ"),QQGNuL4dXKZRF)
		UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy = Ay3eLGaTncD67lx8ZOud[QQGNuL4dXKZRF]
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬẹ"),cg94WALw5orUhvtHSfNO(u"ࠬ࠭Ẻ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࠧẻ"),UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy)
	return
def HvAFi82anhsjdXQL3rfT6BD():
	Ay3eLGaTncD67lx8ZOud = {}
	Ay3eLGaTncD67lx8ZOud[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡂࡗࡗࡓࠬẼ")] = C0CbfZuXJM(u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭ẽ")
	Ay3eLGaTncD67lx8ZOud[C0CbfZuXJM(u"ࠩࡄࡗࡐ࠭Ế")] = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧế")
	Ay3eLGaTncD67lx8ZOud[b46fBrugtPDSYspzMQIx(u"ࠫࡘ࡚ࡏࡑࠩỀ")] = GVPK9Ziaho6U2ySLj(u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨề")
	FFdBYpEgNKfO9T03zPatsukh = BBwb2NzsHE.getSetting(ebT9xRB63E(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭Ể"))
	oeJvDKTQu3clz5mPkFafYr8d = BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪể"))
	YTfi7PmKE8RjQFrdIxSXC = Ay3eLGaTncD67lx8ZOud[oeJvDKTQu3clz5mPkFafYr8d]+FFdBYpEgNKfO9T03zPatsukh
	d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(vlW6K1g8Xo35mPYbyO2GS(u"ࠨࠩỄ"),tvdQHb10PhNmuy6(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧễ"),vdHRKkIgTp56Je1OuNo(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩỆ"),C0CbfZuXJM(u"ࠫส๐โศใࠣ็ฬ๋ไࠨệ"),YTfi7PmKE8RjQFrdIxSXC,VVtQk9vwe7(u"ู๊ࠬาใิࠤࡉࡔࡓ้๋ࠡࠤัํวำࠢไ๎ࠥอไฦ่อี๋๐สࠡ์ๅ์๊ࠦศหฯ๋๎้ࠦริ็สลࠥอไๆ๊สๆ฾่ࠦศๆึ๎ึ็ัศฬࠣษ้๏ࠠฤำๅหฺ๊่่ࠦาࠤอ฿ึࠡษ็๊ฬู๋ࠠไ๋้ࠥฮออสࠣ์๊์ู๊ࠡะฺึࠦศฺุࠣห้๋่ศไ฼ࠤ࠳ࠦไหึ฽๎้ࠦำ๋ำไีࠥࡊࡎࡔࠢๅ้ࠥฮวฯฬํหึࠦวๅีํีๆืࠠศๆ่๊ฬูศࠡล๋ࠤ็๋ࠠษวํๆฬ็็ࠡสส่่อๅๅࠩỈ"))
	if d1cy9GkbBivnRNTChoEFu5xIXp4==C0CbfZuXJM(u"࠴੽"): QQGNuL4dXKZRF = ebT9xRB63E(u"࠭ࡁࡔࡍࠪỉ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==DItWNMaLOZ146CubYk8lfAwTy(u"࠶੾"): QQGNuL4dXKZRF = DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡂࡗࡗࡓࠬỊ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==u2NDjURZVHlmdc0(u"࠸੿"): QQGNuL4dXKZRF = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡕࡗࡓࡕ࠭ị")
	if d1cy9GkbBivnRNTChoEFu5xIXp4 in [vdHRKkIgTp56Je1OuNo(u"࠱ઁ"),WfgnOq9Fd4lhMSQpK5(u"࠱઀")]:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(VVtQk9vwe7(u"ࠩࡦࡩࡳࡺࡥࡳࠩỌ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪื๏ืแา࠼ࠣࠫọ")+vXU90oAP4jJZzsw51SkNYu8Q6bF[CC4UDLW6brf(u"࠳ં")],tjoHEAGv2XkrMBsVfCyp5U(u"ุࠫ๐ัโำ࠽ࠤࠬỎ")+vXU90oAP4jJZzsw51SkNYu8Q6bF[tvdQHb10PhNmuy6(u"࠳ઃ")],G5TxeI0ND4ztC6(u"ࠬ࠭ỏ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬỐ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==GVPK9Ziaho6U2ySLj(u"࠵઄"): BAXH3PZ6Fimv1asSEd = vXU90oAP4jJZzsw51SkNYu8Q6bF[tjoHEAGv2XkrMBsVfCyp5U(u"࠵અ")]
		else: BAXH3PZ6Fimv1asSEd = vXU90oAP4jJZzsw51SkNYu8Q6bF[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠷આ")]
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==Wbwj0o5gsXQ8F2f(u"࠲ઇ"): BAXH3PZ6Fimv1asSEd = vlW6K1g8Xo35mPYbyO2GS(u"ࠧࠨố")
	else: QQGNuL4dXKZRF = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࠩỒ")
	if QQGNuL4dXKZRF:
		BBwb2NzsHE.setSetting(vdHRKkIgTp56Je1OuNo(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬồ"),QQGNuL4dXKZRF)
		BBwb2NzsHE.setSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪỔ"),BAXH3PZ6Fimv1asSEd)
		UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy = Ay3eLGaTncD67lx8ZOud[QQGNuL4dXKZRF]+BAXH3PZ6Fimv1asSEd
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(tvdQHb10PhNmuy6(u"ࠫࠬổ"),C0CbfZuXJM(u"ࠬ࠭Ỗ"),Vt4ELHXZP6(u"࠭ࠧỗ"),UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy)
	return
def c0xlfywZO1jYsFqpPiGDaJb6EnB4e9():
	oeJvDKTQu3clz5mPkFafYr8d = BBwb2NzsHE.getSetting(C0CbfZuXJM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬỘ"))
	Ay3eLGaTncD67lx8ZOud = {}
	Ay3eLGaTncD67lx8ZOud[C0CbfZuXJM(u"ࠨࡃࡘࡘࡔ࠭ộ")] = Wbwj0o5gsXQ8F2f(u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪỚ")
	Ay3eLGaTncD67lx8ZOud[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡅࡘࡑࠧớ")] = xmTX9Aeidq8cVhY(u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬỜ")
	Ay3eLGaTncD67lx8ZOud[tjoHEAGv2XkrMBsVfCyp5U(u"࡙ࠬࡔࡐࡒࠪờ")] = ebT9xRB63E(u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨỞ")
	YTfi7PmKE8RjQFrdIxSXC = Ay3eLGaTncD67lx8ZOud[oeJvDKTQu3clz5mPkFafYr8d]
	d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(C0CbfZuXJM(u"ࠧࠨở"),vlW6K1g8Xo35mPYbyO2GS(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭Ỡ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨỡ"),CC4UDLW6brf(u"ࠪษ๏่วโࠢๆห๊๊ࠧỢ"),YTfi7PmKE8RjQFrdIxSXC,b098bsyjUud(u"ࠫฬ๊ศา๊ๆื๏ࠦ็้ࠢฯ๋ฬุࠠโ์ࠣห้หๆหำ้๎ฯฺ๊ࠦ็็ࠤํูุ๊ࠢห๎๋ࠦฬ่ษี็ࠥ๎วๅว้ฮึ์๊หࠢ࠱ࠤ์๎๋ࠠีอ่๊ࠦืๅสสฮ่่๋ࠦไ๋้ࠥฮำฮส๊หࠥฮฯๅษ้๋้ࠣࠠฬ็ࠣ๎อ฿ห่ษ่่ࠣࠦ࠮้ࠡ็ࠤฯื๊ะࠢอุ฿๐ไࠡล่ࠤส๐โศใࠣห้ฮั้ๅึ๎ࠥลࠧợ"))
	if d1cy9GkbBivnRNTChoEFu5xIXp4==C0CbfZuXJM(u"࠱ઈ"): QQGNuL4dXKZRF = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࡇࡓࡌࠩỤ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==vlW6K1g8Xo35mPYbyO2GS(u"࠳ઉ"): QQGNuL4dXKZRF = ebT9xRB63E(u"࠭ࡁࡖࡖࡒࠫụ")
	elif d1cy9GkbBivnRNTChoEFu5xIXp4==tjoHEAGv2XkrMBsVfCyp5U(u"࠵ઊ"): QQGNuL4dXKZRF = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡔࡖࡒࡔࠬỦ")
	else: QQGNuL4dXKZRF = CC4UDLW6brf(u"ࠨࠩủ")
	if QQGNuL4dXKZRF:
		BBwb2NzsHE.setSetting(Vt4ELHXZP6(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧỨ"),QQGNuL4dXKZRF)
		UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy = Ay3eLGaTncD67lx8ZOud[QQGNuL4dXKZRF]
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(CC4UDLW6brf(u"ࠪࠫứ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬỪ"),b098bsyjUud(u"ࠬ࠭ừ"),UwQA5Rhj8YpJ7Mstc1ovzFEqNZxuy)
	return
def kfqZAM5xpNH3GrWCUmeT7a():
	PP3E92SoUfDriM = BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭Ử"))
	if PP3E92SoUfDriM==tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡔࡖࡒࡔࠬử"): header = CC4UDLW6brf(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็อ์็็ࠧỮ")
	else: header = cg94WALw5orUhvtHSfNO(u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢๅ฾๊ࠧữ")
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࠫỰ"),GVPK9Ziaho6U2ySLj(u"ࠫส๐โศใࠪự"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬะแฺ์็ࠫỲ"),header,xmTX9Aeidq8cVhY(u"࠭โ้ษษ้ࠥอไษำ้ห๊า๋ࠠฬ่ࠤฯำฯ๋อ๊หࠥษ่ห๊่หฯ๐ใ๋ษࠣฬ฾ีࠠ࠲࠸ࠣืฬ฿ษࠡ็้ࠤศ๎ไࠡลึฮำีวๆࠢ࠱࠲ࠥ๎ล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠥ๐ฤะ์ࠣษ้๏ࠠหฯา๎ะํวࠡใํࠤ่๊ࠠๆำฬࠤ๏ะๅࠡษึฮำีวๆࠢส่็๎วว็ࠣ࠲࠳่่ࠦาสࠤ๏ูศษࠢห฻หࠦแ๋ࠢไฮาࠦโ้ษษ้ࠥอไษำ้ห๊า࡜࡯࡞ࡱࠤ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪỳ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==-oh1JUWa3LdnqTpz5(u"࠵ઋ"): return
	elif J1SavlWIe5EOAdVTQrfGYRhjo8KCw6:
		BBwb2NzsHE.setSetting(b46fBrugtPDSYspzMQIx(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧỴ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡃࡘࡘࡔ࠭ỵ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࠪỶ"),G5TxeI0ND4ztC6(u"ࠪࠫỷ"),WfgnOq9Fd4lhMSQpK5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧỸ"),xmTX9Aeidq8cVhY(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧỹ"))
	else:
		BBwb2NzsHE.setSetting(oh1JUWa3LdnqTpz5(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭Ỻ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡔࡖࡒࡔࠬỻ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩỼ"),cg94WALw5orUhvtHSfNO(u"ࠩࠪỽ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ỿ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫฯ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊࠭ỿ"))
	return
def vdh2jbNTLscJMQG09wlnCY3W(hulSHFUcXsaVQGTn8r9zMkNPIwgvo):
	if hulSHFUcXsaVQGTn8r9zMkNPIwgvo!=G5TxeI0ND4ztC6(u"ࠬ࠭ἀ"):
		hulSHFUcXsaVQGTn8r9zMkNPIwgvo = uusp6FEmWZwDhXo(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
		hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.decode(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡵࡵࡨ࠻ࠫἁ")).encode(CC4UDLW6brf(u"ࠧࡶࡶࡩ࠼ࠬἂ"))
		Z3ZLXCOY2JV = GVPK9Ziaho6U2ySLj(u"࠶࠶࠱࠱࠵ઌ")
		dLPc8WEm9tBgDUqjRokQTI2yuZanAM = U6zsmRNGTL.Window(Z3ZLXCOY2JV)
		dLPc8WEm9tBgDUqjRokQTI2yuZanAM.getControl(tvdQHb10PhNmuy6(u"࠹࠱࠲ઍ")).setLabel(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	return
sTQuY9kcg5zh1eyCHbofxdL6 = [
			 u2NDjURZVHlmdc0(u"ࠣࡧࡻࡸࡪࡴࡳࡪࡱࡱࠤࠬ࠭ࠠࡪࡵࠣࡲࡴࡺࠠࡤࡷࡵࡶࡪࡴࡴ࡭ࡻࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࠨἃ")
			,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࡆ࡬ࡪࡩ࡫ࡪࡰࡪࠤ࡫ࡵࡲࠡࡏࡤࡰ࡮ࡩࡩࡰࡷࡶࠤࡸࡩࡲࡪࡲࡷࡷࠬἄ")
			,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࡔ࡛ࡘࠠࡊࡒࡗ࡚࡙ࠥࡩ࡮ࡲ࡯ࡩࠥࡉ࡬ࡪࡧࡱࡸࠬἅ")
			,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥ࡜ࡩࡥࡧࡲࠤࡎࡴࡦࡰࠢࡎࡩࡾ࠭ἆ")
			,VVtQk9vwe7(u"ࠬࡺࡨࡪࡵࠣ࡬ࡦࡹࡨࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣ࡭ࡸࠦࡢࡳࡱ࡮ࡩࡳ࠭ἇ")
			,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡵࡴࡧࡶࠤࡵࡲࡡࡪࡰࠣࡌ࡙࡚ࡐࠡࡨࡲࡶࠥࡧࡤࡥ࠯ࡲࡲࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࠨἈ")
			,cg94WALw5orUhvtHSfNO(u"ࠧࡢࡦࡹࡥࡳࡩࡥࡥ࠯ࡸࡷࡦ࡭ࡥ࠯ࡪࡷࡱࡱ࠭Ἁ")+xmTX9Aeidq8cVhY(u"ࠨࠥࠪἊ")+xmTX9Aeidq8cVhY(u"ࠩࡶࡷࡱ࠳ࡷࡢࡴࡱ࡭ࡳ࡭ࡳࠨἋ")
			,tvdQHb10PhNmuy6(u"ࠪࡍࡳࡹࡥࡤࡷࡵࡩࡗ࡫ࡱࡶࡧࡶࡸ࡜ࡧࡲ࡯࡫ࡱ࡫࠱࠭Ἄ")
			,G5TxeI0ND4ztC6(u"ࠫࡊࡸࡲࡰࡴࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈ࠴ࡅ࡭ࡰࡦࡨࡩࡂ࠶ࠦࡵࡧࡻࡸࡹࡃࠧἍ")
			,C0CbfZuXJM(u"ࠬࡽࡡࡳࡰ࡬ࡲ࡬ࡹ࠮ࡸࡣࡵࡲ࠭࠭Ἆ")
			,vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭࡞࡟ࡠࡡࡢࠬἏ")
			,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡍࡱࡤࡨ࡮ࡴࡧࠡࡵ࡮࡭ࡳࠦࡦࡪ࡮ࡨ࠾ࠬἐ")
			]
def p2oiXbxQPartDSY8MK1mkFWNEwVyRG(dSvlymbao9Zs6t):
	if vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭ἑ") in dSvlymbao9Zs6t and jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧἒ") in dSvlymbao9Zs6t: return xmTX9Aeidq8cVhY(u"࡙ࡸࡵࡦ૵")
	for hulSHFUcXsaVQGTn8r9zMkNPIwgvo in sTQuY9kcg5zh1eyCHbofxdL6:
		if hulSHFUcXsaVQGTn8r9zMkNPIwgvo in dSvlymbao9Zs6t: return jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࡚ࡲࡶࡧ૶")
	return KylMx0kfTOrG(u"ࡆࡢ࡮ࡶࡩ૷")
def PJdtxqsu1zShL0aXy9UWZcfNkGIrMV(data):
	data = data.replace(DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡠࡷࡢ࡮ࠨἓ")+Yr0wo7FaSHx(u"࠵࠲઎")*hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࠥ࠭ἔ")+GVPK9Ziaho6U2ySLj(u"ࠬࡢࡲ࡝ࡰࠪἕ"),CC4UDLW6brf(u"࠭࡜ࡳ࡞ࡱࠫ἖"))
	data = data.replace(oh1JUWa3LdnqTpz5(u"ࠧ࡝ࡰࠪ἗")+cg94WALw5orUhvtHSfNO(u"࠶࠳એ")*WfgnOq9Fd4lhMSQpK5(u"ࠨࠢࠪἘ")+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࡟ࡶࡡࡴࠧἙ"),vdHRKkIgTp56Je1OuNo(u"ࠪࡠࡷࡢ࡮ࠨἚ"))
	data = data.replace(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡡࡴࠧἛ")+b098bsyjUud(u"࠷࠴ઐ")*Yr0wo7FaSHx(u"ࠬࠦࠧἜ")+G5TxeI0ND4ztC6(u"࠭࡜࡯ࠩἝ"),WfgnOq9Fd4lhMSQpK5(u"ࠧ࡝ࡰࠪ἞"))
	data = data.replace(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨ࡞ࡱࠫ἟")+VVtQk9vwe7(u"࠹࠶઒")*jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࠣࠫἠ"),KylMx0kfTOrG(u"ࠪࡠࡳ࠭ἡ")+u2NDjURZVHlmdc0(u"࠶࠵ઑ")*xmTX9Aeidq8cVhY(u"ࠫࠥ࠭ἢ"))
	data = data.replace(WfgnOq9Fd4lhMSQpK5(u"ࠬࠦ࠼ࡨࡧࡱࡩࡷࡧ࡬࠿࠼ࠣࠫἣ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭࠺ࠡࠩἤ"))
	Gv7mT0LhB9YoOVpANMr = xmTX9Aeidq8cVhY(u"ࠧࠨἥ")
	for dSvlymbao9Zs6t in data.splitlines():
		ZOpgFwfRN7CduJIUEL = JJDtX1PZyIgN2T.findall(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧἦ"),dSvlymbao9Zs6t,JJDtX1PZyIgN2T.DOTALL)
		if ZOpgFwfRN7CduJIUEL: dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(ZOpgFwfRN7CduJIUEL[vlW6K1g8Xo35mPYbyO2GS(u"࠵ઓ")],ebT9xRB63E(u"ࠩࠪἧ"))
		Gv7mT0LhB9YoOVpANMr += ebT9xRB63E(u"ࠪࡠࡳ࠭Ἠ")+dSvlymbao9Zs6t
	return Gv7mT0LhB9YoOVpANMr
def fHReuOk79NEGiyP6sdbZD3(YBtwIAVuL6XR5TJrgMlSmdU1):
	if tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡔࡒࡄࠨἩ") in YBtwIAVuL6XR5TJrgMlSmdU1:
		XS7mR9NIoaq05kgv = xieTcq8n4kdFH6A
		header = Yr0wo7FaSHx(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣรࠬἪ")
	else:
		XS7mR9NIoaq05kgv = ZOf4z17vyLarQYEUAHK2dJS
		header = cg94WALw5orUhvtHSfNO(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭Ἣ")
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࠨἬ"),vdHRKkIgTp56Je1OuNo(u"ࠨࠩἭ"),Vt4ELHXZP6(u"ࠩࠪἮ"),header,VVtQk9vwe7(u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭Ἧ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠷ઔ"): return
	jX5C7t0xBAsaQ,oISMg2J7z8nrWxitjAhGeBf = [],u2NDjURZVHlmdc0(u"࠰ક")
	size,count = eexb5wHNQEphIrs3WCBZjYcoTMu0(XS7mR9NIoaq05kgv)
	file = open(XS7mR9NIoaq05kgv,KylMx0kfTOrG(u"ࠫࡷࡨࠧἰ"))
	if size>vdHRKkIgTp56Je1OuNo(u"࠳࠳࠴࠷࠶࠰ગ"): file.seek(-hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠲࠲࠳࠵࠵࠶ખ"),A73K6zLXIgFROeCHJQi0Pbos.SEEK_END)
	data = file.read()
	file.close()
	if DQfHadYvTpy1UR: data = data.decode(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡻࡴࡧ࠺ࠪἱ"))
	data = PJdtxqsu1zShL0aXy9UWZcfNkGIrMV(data)
	tBFLs10gh4MQyeXa5xSnqlPWdE = data.split(Wbwj0o5gsXQ8F2f(u"࠭࡜࡯ࠩἲ"))
	for dSvlymbao9Zs6t in reversed(tBFLs10gh4MQyeXa5xSnqlPWdE):
		OZBEo7mtqXU5Q1HavLN3c6prPg = p2oiXbxQPartDSY8MK1mkFWNEwVyRG(dSvlymbao9Zs6t)
		if OZBEo7mtqXU5Q1HavLN3c6prPg: continue
		dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(b46fBrugtPDSYspzMQIx(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩἳ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧἴ"))
		dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩἵ"),CC4UDLW6brf(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢࡋࡒࡓࡑࡕ࠾ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ἶ"))
		sC5QyIA1wK4mW8RGa = CC4UDLW6brf(u"ࠫࠬἷ")
		U5EKDMhRbO03Frt2iBzW6pZmxH = JJDtX1PZyIgN2T.findall(A6Iyo7eXrq2RtMmDxWj(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬἸ"),dSvlymbao9Zs6t,JJDtX1PZyIgN2T.DOTALL)
		if U5EKDMhRbO03Frt2iBzW6pZmxH:
			dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(U5EKDMhRbO03Frt2iBzW6pZmxH[GVPK9Ziaho6U2ySLj(u"࠴ઙ")][GVPK9Ziaho6U2ySLj(u"࠴ઙ")],U5EKDMhRbO03Frt2iBzW6pZmxH[GVPK9Ziaho6U2ySLj(u"࠴ઙ")][CC4UDLW6brf(u"࠴ઘ")]).replace(U5EKDMhRbO03Frt2iBzW6pZmxH[GVPK9Ziaho6U2ySLj(u"࠴ઙ")][cg94WALw5orUhvtHSfNO(u"࠷ચ")],GVPK9Ziaho6U2ySLj(u"࠭ࠧἹ"))
			sC5QyIA1wK4mW8RGa = U5EKDMhRbO03Frt2iBzW6pZmxH[G5TxeI0ND4ztC6(u"࠰જ")][b098bsyjUud(u"࠷છ")]
		else:
			U5EKDMhRbO03Frt2iBzW6pZmxH = JJDtX1PZyIgN2T.findall(CC4UDLW6brf(u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧἺ"),dSvlymbao9Zs6t,JJDtX1PZyIgN2T.DOTALL)
			if U5EKDMhRbO03Frt2iBzW6pZmxH:
				dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(U5EKDMhRbO03Frt2iBzW6pZmxH[u2NDjURZVHlmdc0(u"࠲ઞ")][Vt4ELHXZP6(u"࠲ઝ")],G5TxeI0ND4ztC6(u"ࠨࠩἻ"))
				sC5QyIA1wK4mW8RGa = U5EKDMhRbO03Frt2iBzW6pZmxH[C0CbfZuXJM(u"࠳ટ")][C0CbfZuXJM(u"࠳ટ")]
		if sC5QyIA1wK4mW8RGa: dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(sC5QyIA1wK4mW8RGa,u2NDjURZVHlmdc0(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬἼ")+sC5QyIA1wK4mW8RGa+xmTX9Aeidq8cVhY(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬἽ"))
		jX5C7t0xBAsaQ.append(dSvlymbao9Zs6t)
		if len(str(jX5C7t0xBAsaQ))>vdHRKkIgTp56Je1OuNo(u"࠹࠵࠷࠰࠱ઠ"): break
	jX5C7t0xBAsaQ = reversed(jX5C7t0xBAsaQ)
	bL9diQkcWE7 = oh1JUWa3LdnqTpz5(u"ࠫࡡࡴࠧἾ").join(jX5C7t0xBAsaQ)
	u59uk1YqFUTd(WfgnOq9Fd4lhMSQpK5(u"ࠬࡲࡥࡧࡶࠪἿ"),GVPK9Ziaho6U2ySLj(u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪὀ"),bL9diQkcWE7,CC4UDLW6brf(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪὁ"))
	return
def lh0EHOCFWankLRPqU():
	aJewN2OH9PKVhETnAM = open(MNVzRjrKOtLnQ6,pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࡴࡥࠫὂ")).read()
	if DQfHadYvTpy1UR: aJewN2OH9PKVhETnAM = aJewN2OH9PKVhETnAM.decode(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡸࡸ࡫࠾ࠧὃ"))
	aJewN2OH9PKVhETnAM = aJewN2OH9PKVhETnAM.replace(Wbwj0o5gsXQ8F2f(u"ࠪࡠࡹ࠭ὄ"),tvdQHb10PhNmuy6(u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥ࠭ὅ"))
	gFdBaQ9bzKVRS = JJDtX1PZyIgN2T.findall(Wbwj0o5gsXQ8F2f(u"ࠬ࠮ࡶ࡝ࡦ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭὆"),aJewN2OH9PKVhETnAM,JJDtX1PZyIgN2T.DOTALL)
	for dSvlymbao9Zs6t in gFdBaQ9bzKVRS:
		aJewN2OH9PKVhETnAM = aJewN2OH9PKVhETnAM.replace(dSvlymbao9Zs6t,vJ2Q9gokKptI6YxrhDURClcFOz4(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ὇")+dSvlymbao9Zs6t+b46fBrugtPDSYspzMQIx(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩὈ"))
	iTYQXEG9swpIWC(vlW6K1g8Xo35mPYbyO2GS(u"ࠨษ็ฮ฿๐๊าษอࠤฬ๊รฯ์ิอࠥ็๊ࠡษ็ฬึอๅอࠩὉ"),aJewN2OH9PKVhETnAM)
	return
def FKrUMxiuXL0nONmTjh():
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = DItWNMaLOZ146CubYk8lfAwTy(u"ࠩห฽฻ࠦวๅลีีฬืฺࠠๆ์ࠤฬ๊ั๋็๋ฮ้่ࠥ็ฬิ์้ࠦส้ใิࠤส๋ใศ่ํอࠥะโะ์่ࠤํะรฯ์ิࠤฬ๊แ๋ัํ์ࠥ๎็ั้ࠣห้ษาาษิࠤ์๐ࠠศๆฦื์๋้ࠠษ็วึ่วๆ่ࠢ฽ࠥฮูื๋ࠢ็ฬ๊สศๆํࠫὊ")
	d1cgFMGN2Eaoz9AelBI = xmTX9Aeidq8cVhY(u"่ࠪฯ่ฯ๋็ࠣห้็๊ะ์๋ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ๅ๋่ࠣ์้ะรฯ์ิ๋ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ิษิࠤ࠳ࠦรๆษࠣ฽ิฯࠠศี๊้๋ࠥสหษ็๎ฮࠦแ่า๊ࠤฯ่่ๆࠢหฮาื๊ไࠢส่ๆ๐ฯ๋๊ࠣฬํ่สࠡษๆฬึࠦๅ็๋ࠢๆฯࠦวๅี๊้ࠥอไ้ษะำࠥ࠴ࠠฤ็สࠤฬ๊ำ่็ࠣห้ษูๅ๋ࠣ์ฬ๊ริใ็ࠤๆํ่ࠡ์ะี่ࠦวๅใํำ๏๎ࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤํ๊ใ็ࠢหๆๆุษࠡๅห๎ึฯࠧὋ")
	sHCNe7qXk2m = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫศ๋วࠡษ็วึ่วๆࠢไ๋๏ࠦสิฬัำ๊ࠦไๅฬๅำ๏๋้ࠠษ็ฮศิ๊า๋่่ࠢ์ࠠษ็ๅำฬืฺࠠัาࠤฬ๊ห้ษ้๎ࠥ๎วๅัๅหห่ࠠ࠯่ࠢฯ้อࠠาไ่ࠤ࠺࠺࠴ࠡฬ฼๊๏ࠦ࠵ࠡัๅหห่้ࠠࠢ࠷࠸ࠥัว็์ฬࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอมࠡสะือࠦวิฬัำฬ๋ใࠡๆ็ื์๋ࠠศๆํ้๏์ࠠฤ๊ࠣื์๋ࠠศๆํืฬืࠧὌ")
	Ay3eLGaTncD67lx8ZOud = DDTdLb3SZQPv7rX1qfwHCpn2eyKc+cg94WALw5orUhvtHSfNO(u"ࠬࡀࠠࠨὍ")+d1cgFMGN2Eaoz9AelBI+tvdQHb10PhNmuy6(u"࠭ࠠ࠯ࠢࠪ὎")+sHCNe7qXk2m
	u59uk1YqFUTd(VVtQk9vwe7(u"ࠧࡤࡧࡱࡸࡪࡸࠧ὏"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫὐ"),Ay3eLGaTncD67lx8ZOud,A6Iyo7eXrq2RtMmDxWj(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬὑ"))
	return
def B4vT1EflKxbA9IaiG8U6Ck0(type,Ay3eLGaTncD67lx8ZOud,showDialogs=Vt4ELHXZP6(u"ࡕࡴࡸࡩ૸"),url=uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࠫὒ"),dbBRqLP6WeEV=VVtQk9vwe7(u"ࠫࠬὓ"),hulSHFUcXsaVQGTn8r9zMkNPIwgvo=Yr0wo7FaSHx(u"ࠬ࠭ὔ"),w4ZOJYBAlRq19xEfzcUmajsWkXNuIC=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࠧὕ")):
	bLfREqacQ1 = Wbwj0o5gsXQ8F2f(u"ࡖࡵࡹࡪૹ")
	if not HRnwFcAJIxaoXEbYQ(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨὖ")):
		if showDialogs:
			Go1VerxOPQaI9lfXspDz6UEtSMc0bd = (uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨษ็ื฼ื࠺ࠨὗ") in Ay3eLGaTncD67lx8ZOud and DItWNMaLOZ146CubYk8lfAwTy(u"ࠩส่๊้ว็࠼ࠪ὘") in Ay3eLGaTncD67lx8ZOud and CC4UDLW6brf(u"ࠪห้๋ไโ࠼ࠪὙ") in Ay3eLGaTncD67lx8ZOud and WfgnOq9Fd4lhMSQpK5(u"ࠫฬ๊ฮุลࠪ὚") in Ay3eLGaTncD67lx8ZOud and vlW6K1g8Xo35mPYbyO2GS(u"ࠬอไๆืาี࠿࠭Ὓ") in Ay3eLGaTncD67lx8ZOud)
			if not Go1VerxOPQaI9lfXspDz6UEtSMc0bd: bLfREqacQ1 = MMTfC8jWkbhxp2BDt(A6Iyo7eXrq2RtMmDxWj(u"࠭ࡣࡦࡰࡷࡩࡷ࠭὜"),VVtQk9vwe7(u"ࠧࠨὝ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠨࠩ὞"),cg94WALw5orUhvtHSfNO(u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭Ὗ"),Ay3eLGaTncD67lx8ZOud.replace(u2NDjURZVHlmdc0(u"ࠪࡠࡡࡴࠧὠ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡡࡴࠧὡ")))
	elif showDialogs:
		Ay3eLGaTncD67lx8ZOud = oh1JUWa3LdnqTpz5(u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬὢ")
		bb63ahXrpCsxK4 = MMTfC8jWkbhxp2BDt(cg94WALw5orUhvtHSfNO(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ὣ"),WfgnOq9Fd4lhMSQpK5(u"ࠧࠨὤ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠩὥ"),cg94WALw5orUhvtHSfNO(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩὦ")+tvdQHb10PhNmuy6(u"ࠪࠤࠥ࠷࠯࠶ࠩὧ"),Yr0wo7FaSHx(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩὨ"))
		NgUAdJyztTE4wSMjVkKG3CQ8YDv6 = MMTfC8jWkbhxp2BDt(pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬὩ"),vdHRKkIgTp56Je1OuNo(u"࠭ࠧὪ"),GVPK9Ziaho6U2ySLj(u"ࠧࠨὫ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨὬ")+xmTX9Aeidq8cVhY(u"ࠩࠣࠤ࠷࠵࠵ࠨὭ"),G5TxeI0ND4ztC6(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨὮ"))
		zzCquXRhFnDHtwOcI = MMTfC8jWkbhxp2BDt(vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫὯ"),ebT9xRB63E(u"ࠬ࠭ὰ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࠧά"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧὲ")+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࠢࠣ࠷࠴࠻ࠧέ"),oh1JUWa3LdnqTpz5(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧὴ"))
		lBAjzLFOuc7QeJkSM = MMTfC8jWkbhxp2BDt(trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡧࡪࡴࡴࡦࡴࠪή"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠬὶ"),Yr0wo7FaSHx(u"ࠬ࠭ί"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ὸ")+GVPK9Ziaho6U2ySLj(u"ࠧࠡࠢ࠷࠳࠺࠭ό"),Vt4ELHXZP6(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭ὺ"))
		bLfREqacQ1 = MMTfC8jWkbhxp2BDt(oh1JUWa3LdnqTpz5(u"ࠩࡦࡩࡳࡺࡥࡳࠩύ"),cg94WALw5orUhvtHSfNO(u"ࠪࠫὼ"),G5TxeI0ND4ztC6(u"ࠫࠬώ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ὾")+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠠࠡ࠷࠲࠹ࠬ὿"),C0CbfZuXJM(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬᾀ"))
	YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(VVtQk9vwe7(u"࠸࠸ડ"),cg94WALw5orUhvtHSfNO(u"ࡉࡥࡱࡹࡥૺ"))
	NlFUkf780K94Lg1dj = tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡃ࡙࠾ࠥ࠭ᾁ")+YqywcljIHsFzoXaf0T97+A6Iyo7eXrq2RtMmDxWj(u"ࠩ࠰ࠫᾂ")+type
	PAWq9e5lxaE2mp7iXyntVRZo1Js = Yr0wo7FaSHx(u"࡙ࡸࡵࡦૼ") if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ᾃ") in hulSHFUcXsaVQGTn8r9zMkNPIwgvo else CC4UDLW6brf(u"ࡊࡦࡲࡳࡦૻ")
	if not bLfREqacQ1:
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(C0CbfZuXJM(u"ࠫࠬᾄ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠭ᾅ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᾆ"),A6Iyo7eXrq2RtMmDxWj(u"ࠧห็ࠣษ้เวยࠢส่สืำศๆࠣฬ๋อมࠡ฻็ํࠥ฽ไษๅࠪᾇ"))
		return pOIe6U1vWYC7Gh2udFBRgT(u"ࡌࡡ࡭ࡵࡨ૽")
	azQOd2BbrhAcWf46u1y = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(ebT9xRB63E(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧᾈ"))
	Ay3eLGaTncD67lx8ZOud += vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠣࡠࡡࡴ࡜࡝ࡰࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡠࡡࡴࡁࡥࡦࡲࡲࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠࠨᾉ")+K0dHTfq6P73sD8lWLZpoh+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࠤ࠿ࡢ࡜࡯ࠩᾊ")
	Ay3eLGaTncD67lx8ZOud += oh1JUWa3LdnqTpz5(u"ࠫࡊࡳࡡࡪ࡮ࠣࡗࡪࡴࡤࡦࡴ࠽ࠤࠬᾋ")+YqywcljIHsFzoXaf0T97+WfgnOq9Fd4lhMSQpK5(u"ࠬࠦ࠺࡝࡞ࡱࡏࡴࡪࡩࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠫᾌ")+L2N3maPfeUCuG1rd4whqF+Yr0wo7FaSHx(u"࠭ࠠ࠻࡞࡟ࡲࠬᾍ")
	Ay3eLGaTncD67lx8ZOud += WfgnOq9Fd4lhMSQpK5(u"ࠧࡌࡱࡧ࡭ࠥࡔࡡ࡮ࡧ࠽ࠤࠬᾎ")+azQOd2BbrhAcWf46u1y
	JFPwNjatzforvbYRhykTIB0GmAl4Hp = ZLG9paBn0bWQd2eTVN1hw8KAq3jDHP()
	JFPwNjatzforvbYRhykTIB0GmAl4Hp = FVsLwz1tAH(JFPwNjatzforvbYRhykTIB0GmAl4Hp)
	if JFPwNjatzforvbYRhykTIB0GmAl4Hp: Ay3eLGaTncD67lx8ZOud += Yr0wo7FaSHx(u"ࠨࠢ࠽ࡠࡡࡴࡌࡰࡥࡤࡸ࡮ࡵ࡮࠻ࠢࠪᾏ")+JFPwNjatzforvbYRhykTIB0GmAl4Hp
	if url: Ay3eLGaTncD67lx8ZOud += WfgnOq9Fd4lhMSQpK5(u"ࠩࠣ࠾ࡡࡢ࡮ࡖࡔࡏ࠾ࠥ࠭ᾐ")+url
	if dbBRqLP6WeEV: Ay3eLGaTncD67lx8ZOud += DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠤ࠿ࡢ࡜࡯ࡕࡲࡹࡷࡩࡥ࠻ࠢࠪᾑ")+dbBRqLP6WeEV
	Ay3eLGaTncD67lx8ZOud += Vt4ELHXZP6(u"ࠫࠥࡀ࡜࡝ࡰࠪᾒ")
	if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(u2NDjURZVHlmdc0(u"ࠬาวา์ࠣห้หัิษ็ࠫᾓ"),oh1JUWa3LdnqTpz5(u"࠭วๅำฯหฦࠦวๅษ้ฮ฽อัࠨᾔ"))
	if w4ZOJYBAlRq19xEfzcUmajsWkXNuIC:
		bL9diQkcWE7 = w4ZOJYBAlRq19xEfzcUmajsWkXNuIC
		if DQfHadYvTpy1UR: bL9diQkcWE7 = bL9diQkcWE7.encode(xmTX9Aeidq8cVhY(u"ࠧࡶࡶࡩ࠼ࠬᾕ"))
		bL9diQkcWE7 = gPSZVjJHKIL.b64encode(bL9diQkcWE7)
	elif PAWq9e5lxaE2mp7iXyntVRZo1Js:
		if VVtQk9vwe7(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨᾖ") in hulSHFUcXsaVQGTn8r9zMkNPIwgvo: o0nLMZBj6R7OgUuitf134kvp2SFG = xieTcq8n4kdFH6A
		else: o0nLMZBj6R7OgUuitf134kvp2SFG = ZOf4z17vyLarQYEUAHK2dJS
		if not A73K6zLXIgFROeCHJQi0Pbos.path.exists(o0nLMZBj6R7OgUuitf134kvp2SFG):
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࠪᾗ"),G5TxeI0ND4ztC6(u"ࠪࠫᾘ"),b098bsyjUud(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᾙ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ูࠬฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ฻์ิࠤ๊๎ฬ้ัࠪᾚ"))
			return mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡆࡢ࡮ࡶࡩ૾")
		jX5C7t0xBAsaQ,oISMg2J7z8nrWxitjAhGeBf = [],VVtQk9vwe7(u"࠶ઢ")
		size,count = eexb5wHNQEphIrs3WCBZjYcoTMu0(o0nLMZBj6R7OgUuitf134kvp2SFG)
		file = open(o0nLMZBj6R7OgUuitf134kvp2SFG,b46fBrugtPDSYspzMQIx(u"࠭ࡲࡣࠩᾛ"))
		if size>CC4UDLW6brf(u"࠳࠷࠳࠶࠵࠶ત"): file.seek(-b098bsyjUud(u"࠲࠶࠲࠴࠴࠵ણ"),A73K6zLXIgFROeCHJQi0Pbos.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(GVPK9Ziaho6U2ySLj(u"ࠧࡶࡶࡩ࠼ࠬᾜ"))
		data = PJdtxqsu1zShL0aXy9UWZcfNkGIrMV(data)
		tBFLs10gh4MQyeXa5xSnqlPWdE = data.splitlines()
		for dSvlymbao9Zs6t in reversed(tBFLs10gh4MQyeXa5xSnqlPWdE):
			OZBEo7mtqXU5Q1HavLN3c6prPg = p2oiXbxQPartDSY8MK1mkFWNEwVyRG(dSvlymbao9Zs6t)
			if OZBEo7mtqXU5Q1HavLN3c6prPg: continue
			U5EKDMhRbO03Frt2iBzW6pZmxH = JJDtX1PZyIgN2T.findall(b46fBrugtPDSYspzMQIx(u"ࠨࡠࠫࡠࡩ࠱࠭ࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠢ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨᾝ"),dSvlymbao9Zs6t,JJDtX1PZyIgN2T.DOTALL)
			if U5EKDMhRbO03Frt2iBzW6pZmxH:
				dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(U5EKDMhRbO03Frt2iBzW6pZmxH[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠳દ")][YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠳દ")],U5EKDMhRbO03Frt2iBzW6pZmxH[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠳દ")][C0CbfZuXJM(u"࠳થ")]).replace(U5EKDMhRbO03Frt2iBzW6pZmxH[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠳દ")][C0CbfZuXJM(u"࠶ધ")],pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࠪᾞ"))
			else:
				U5EKDMhRbO03Frt2iBzW6pZmxH = JJDtX1PZyIgN2T.findall(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪᾟ"),dSvlymbao9Zs6t,JJDtX1PZyIgN2T.DOTALL)
				if U5EKDMhRbO03Frt2iBzW6pZmxH: dSvlymbao9Zs6t = dSvlymbao9Zs6t.replace(U5EKDMhRbO03Frt2iBzW6pZmxH[uEed4OSxm7hBq9Vvky6QjHwWC(u"࠶઩")][Vt4ELHXZP6(u"࠶ન")],DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬᾠ"))
			jX5C7t0xBAsaQ.append(dSvlymbao9Zs6t)
			if len(str(jX5C7t0xBAsaQ))>tvdQHb10PhNmuy6(u"࠱࠳࠳࠳࠴࠵પ"): break
		jX5C7t0xBAsaQ = reversed(jX5C7t0xBAsaQ)
		bL9diQkcWE7 = C0CbfZuXJM(u"ࠬࡢࡲ࡝ࡰࠪᾡ").join(jX5C7t0xBAsaQ)
		bL9diQkcWE7 = bL9diQkcWE7.encode(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡵࡵࡨ࠻ࠫᾢ"))
		bL9diQkcWE7 = gPSZVjJHKIL.b64encode(bL9diQkcWE7)
	else: bL9diQkcWE7 = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࠨᾣ")
	url = LWzUbE5adDslTXGr[b098bsyjUud(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᾤ")][VVtQk9vwe7(u"࠳ફ")]
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {A6Iyo7eXrq2RtMmDxWj(u"ࠩࡶࡹࡧࡰࡥࡤࡶࠪᾥ"):NlFUkf780K94Lg1dj,ebT9xRB63E(u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫᾦ"):Ay3eLGaTncD67lx8ZOud,DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࡱࡵࡧࡧ࡫࡯ࡩࠬᾧ"):bL9diQkcWE7}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,vdHRKkIgTp56Je1OuNo(u"ࠬࡖࡏࡔࡖࠪᾨ"),url,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,WfgnOq9Fd4lhMSQpK5(u"࠭ࠧᾩ"),G5TxeI0ND4ztC6(u"ࠧࠨᾪ"),C0CbfZuXJM(u"ࠨࠩᾫ"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡘࡋࡎࡅࡡࡈࡑࡆࡏࡌ࠮࠳ࡶࡸࠬᾬ"))
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if b098bsyjUud(u"ࠪࠦࡸࡻࡣࡤࡧࡨࡨࡪࡪࠢ࠻ࠢ࠴࠰ࠬᾭ") in YBEsLq8gVw629cMGQP1T: llC9WmbrAIgpzfi3n = CC4UDLW6brf(u"ࡕࡴࡸࡩ૿")
	else: llC9WmbrAIgpzfi3n = tjoHEAGv2XkrMBsVfCyp5U(u"ࡈࡤࡰࡸ࡫଀")
	if showDialogs:
		if llC9WmbrAIgpzfi3n:
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(VVtQk9vwe7(u"ࠫฯ๋ࠠศๆศีุอไࠨᾮ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠬฮๆอษะࠫᾯ"))
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Yr0wo7FaSHx(u"࠭ࠧᾰ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠨᾱ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠧᾲ"),G5TxeI0ND4ztC6(u"ࠩอ้ࠥหัิษ็ࠤฬ๊ัิษ็อࠥฮๆอษะࠫᾳ"))
		else:
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"่้ࠪษำโࠩᾴ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫๆฺไࠡใํࠤฬ๊ลาีส่ࠬ᾵"))
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vdHRKkIgTp56Je1OuNo(u"ࠬ࠭ᾶ"),b098bsyjUud(u"࠭ࠧᾷ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᾸ"),Vt4ELHXZP6(u"ࠨะฺวࠥ๎แีๆࠣๅ๏ࠦลาีส่ࠥอไาีส่ฮ࠭Ᾱ"))
	return llC9WmbrAIgpzfi3n
def rrhfmpXuLqtD6l3o2EZVGNW():
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࠴࠲ࠥࠦࠠࡊࡨࠣࡽࡴࡻࠠࡩࡣࡹࡩࠥࡶࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡆࡸࡡࡣ࡫ࡦࠤࡹ࡫ࡸࡵࡶࠣࡸ࡭࡫࡮ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠤࡹࡵࠠࠣࡃࡵ࡭ࡦࡲࠢࠨᾺ")
	d1cgFMGN2Eaoz9AelBI = GVPK9Ziaho6U2ySLj(u"ࠪ࠵࠳ࠦࠠࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥอไฤฯิๅࠥอไฺำห๎ฮࠦแศา๊ฬࠥหไ๊ࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฬ็ࠣ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬΆ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(GVPK9Ziaho6U2ySLj(u"ࠫࠬᾼ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬ࠭᾽"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡐࡳࡱࡥࡰࡪࡳࠧι"),DDTdLb3SZQPv7rX1qfwHCpn2eyKc+VVtQk9vwe7(u"ࠧ࡝ࡰ࡟ࡲࠬ᾿")+d1cgFMGN2Eaoz9AelBI)
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨ࠴࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡣࡢࡰ࡟ࠫࡹࠦࡦࡪࡰࡧࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࡬࡯࡯ࡶࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡹ࡫ࡪࡰࠣࡥࡳࡪࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠧ῀")
	d1cgFMGN2Eaoz9AelBI = A6Iyo7eXrq2RtMmDxWj(u"ࠩ࠵࠲ࠥࠦࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ็๋ࠠษฬ฽๎๏ืࠠศๆฯ่ิࠦหๆࠢๅ้ࠥฮส฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ῁")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vdHRKkIgTp56Je1OuNo(u"ࠪࠫῂ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬῃ"),KylMx0kfTOrG(u"ࠬࡌ࡯࡯ࡶࠣࡔࡷࡵࡢ࡭ࡧࡰࠫῄ"),DDTdLb3SZQPv7rX1qfwHCpn2eyKc+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭࡜࡯࡞ࡱࠫ῅")+d1cgFMGN2Eaoz9AelBI)
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = G5TxeI0ND4ztC6(u"ࠧ࠴࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥࡪ࡯࡯࡞ࠪࡸࠥ࡮ࡡࡷࡧࠣࡅࡷࡧࡢࡪࡥࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡴࡨ࡫࡮ࡵ࡮ࡢ࡮ࠣࡷࡪࡺࡴࡪࡰࡪࡷࠬῆ")
	d1cgFMGN2Eaoz9AelBI = G5TxeI0ND4ztC6(u"ࠨ࠵࠱ࠤࠥࠦลัษ่๊๊ࠣࠦไ่่ࠣิ๐ใࠡๆ๋ัฮࠦๅโษอ๎าูࠦาสํอࠥ็วั้หࠤส๊้ࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦหๆࠢ฽๎ึࠦลฺัสำฬะࠠศๆ่๊฼่ษࠡษ็ะ฿ืวโ์ฬࠫῇ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࠪῈ"),GVPK9Ziaho6U2ySLj(u"ࠪࠫΈ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡋࡵ࡮ࡵࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪῊ"),DDTdLb3SZQPv7rX1qfwHCpn2eyKc+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡢ࡮࡝ࡰࠪΉ")+d1cgFMGN2Eaoz9AelBI)
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ῌ"),b46fBrugtPDSYspzMQIx(u"ࠧࠨ῍"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠩ῎"),xmTX9Aeidq8cVhY(u"ࠩࡉࡳࡳࡺࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠩ῏"),oh1JUWa3LdnqTpz5(u"ࠪࡈࡴࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡰࡲࡻࠥࡅࠧῐ")+xmTX9Aeidq8cVhY(u"ࠫࡡࡴ࡜࡯ࠩῑ")+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬํไࠡฬิ๎ิࠦวๅา๊หอࠦลๅ๋่ࠣํำษࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦรๅฤ้รࠬῒ"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==vlW6K1g8Xo35mPYbyO2GS(u"࠳બ"): oCOWGuHNYfALx0()
	return
def PPSJUI94lBhrfTgGz5cvY2():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(A6Iyo7eXrq2RtMmDxWj(u"࠭ࠧΐ"),u2NDjURZVHlmdc0(u"ࠧࠨ῔"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ῕"),vdHRKkIgTp56Je1OuNo(u"ࠩ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬ๊ࠡ็่ฯษใะࠢๅ้ࠥฮสี฼ํ่ࠥอไาษห฻ࠥอไั์่ࠣฬฺ๊ࠦ็็ࠤะ๋ࠠใ็ࠣฬสืำศๆู้้ࠣไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣห้่วว็ฬࠤฬ๊ัว์ึ๎ฮࠦไๅสิ๊ฬ๋ฬࠨῖ"))
	return
def u67g8MkaY3CALUqx():
	Ay3eLGaTncD67lx8ZOud = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"๋ࠪีอࠠศๆหี๋อๅอ่ࠢาฺ฻ࠠโไฺࠤฺ้๊สࠢส่฾ืศ๋หࠣ์้้ๆ้ࠡำห๊ࠥวࠡ์่๊฾่ࠦอ๊าࠤ๊๎วใ฻ࠣๅ๏ํวࠡลไ่ฬ๋้ࠠ็ึุ่๊วห่ࠢฮึาๅสࠢฦ์๋ࠥฯษๆฯอࠥหไ๊ࠢส่้เษࠡษ็฽ึฮ๊ส๋ࠢห้๏ࠠๅ฼สฮࠥอฮา๋ࠣ์้อ๋๊ࠠฯำูࠥศษࠢ็่ฯ้ัศำࠪῗ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(u2NDjURZVHlmdc0(u"ࠫࠬῘ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠬ࠭Ῑ"),ebT9xRB63E(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩῚ"),Ay3eLGaTncD67lx8ZOud)
	return
def EoH6Rlfp5ni():
	Ay3eLGaTncD67lx8ZOud = trSQHvP4aqBWFKxN5bZgXCu(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫΊ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࠩ῜"),C0CbfZuXJM(u"ࠩࠪ῝"),vlW6K1g8Xo35mPYbyO2GS(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭῞"),Ay3eLGaTncD67lx8ZOud)
	return
def yyWlchfo68Mm():
	Ay3eLGaTncD67lx8ZOud = cg94WALw5orUhvtHSfNO(u"ࠫ์๐ࠠิ์ิๅึอสࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦวิฬัำฬ๋็ศࠢหือฮࠠไ๊้๋ฬࠦๅฮ็ํอ๋ࠥๆࠡษ็ฺ้ีัࠡล๋ࠤอำวอหࠣษ้๏ࠠศึอีฬ้ࠠาี่๎ࠥษ่ࠡฮา๎ิฯࠠฤ๊่ࠣฬฺ๊ࠦำไ๋ฬࠦวๅสิ๊ฬ๋ฬࠨ῟")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(pOIe6U1vWYC7Gh2udFBRgT(u"ࠬ࠭ῠ"),b46fBrugtPDSYspzMQIx(u"࠭ࠧῡ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪῢ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨีํีๆืวหࠢึ๎หฯࠠฤ๊้ࠣัํ่ๅหࠪΰ"),Ay3eLGaTncD67lx8ZOud)
	return
def YbtvI8Jm2PZGsaRxULWlz0ioT():
	Ay3eLGaTncD67lx8ZOud = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩสุ่๐ัโำสฮࠥอไฺษ่อࠥํ๊ࠡีํีๆืวหࠢัหึา๊ส๋ࠢ฾๏ืࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦอ็ํ฽ࠥอไๆ๊สๆ฾ࠦสิฬัำ๊ํว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฬศ่ํอࠥ๎ๅีษๆ่์อࠠไอํีฮࠦไศ่ࠣห้็๊ะ์๋๋ฬะࠠโ์๊หࠥหๅศࠢห฻๏ฬษࠡล๋ࠤ๊๋ๆ้฻ฬࠤศ๎ࠠๆฯำ์ๆฯࠠฤ๊ࠣๅ๏ํวࠡ็ื็้ฯࠠฮไ๋ๆࠥอไๆๆๆ๎ฮࡢ࡮࡝ࡰ࡟ࡲฬ๊ำ๋ำไีฬะࠠศๆัหฺฯ่ࠠ์ࠣื๏ืแาษอࠤฯอศฺห่้๋่ࠣใ฻ࠣห้ษีๅ์ࠣ์ู๊สฯั่อࠥ็๊ࠡ็๋ห็฿ࠠใๆํ่ฮࠦฬะษࠣ์฾อฯสࠢอ็ํ์ࠠๆัไ์฾ฯࠠศๆฦะึࠦร้ࠢํ้้้็ศࠢส่๊๎โฺࠢส่ศ฻ไ๋๋่ࠢ์ึวࠡใ๊๎ࠥา๊ะหุ๊ࠣฮ๊ศ๋ࠢืึ๐ูสู๋้ࠢอใๅ้สࠤ็๊๊ๅหࠣะิอࠧῤ")
	u59uk1YqFUTd(Wbwj0o5gsXQ8F2f(u"ࠪࡧࡪࡴࡴࡦࡴࠪῥ"),cg94WALw5orUhvtHSfNO(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧῦ"),Ay3eLGaTncD67lx8ZOud,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨῧ"))
	return
def xogXmvCFHhbTpSsuRaGE():
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧῨ")
	d1cgFMGN2Eaoz9AelBI = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩῩ")
	sHCNe7qXk2m = Wbwj0o5gsXQ8F2f(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩῪ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(CC4UDLW6brf(u"ࠩࠪΎ"),G5TxeI0ND4ztC6(u"ࠪࠫῬ"),vdHRKkIgTp56Je1OuNo(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ῭"),DDTdLb3SZQPv7rX1qfwHCpn2eyKc,d1cgFMGN2Eaoz9AelBI,sHCNe7qXk2m)
	return
def HwYLjQDqTP5k9F1CXhOte():
	d1cgFMGN2Eaoz9AelBI = GVPK9Ziaho6U2ySLj(u"ࠬอไไษืࠤ์๎ࠠๆะี๊๋ࠥฤใฬู่้๋ࠣๅ๊่หฯ๊ࠦิฬัำ๊ํࠠศๆหี๋อๅอࠢ็าื์ࠠึใะหฯࠦวๅว้ฮึ์๊ห๋ࠢีํอศุࠢส่ๆ๐ฯ๋๊๊หฯࠦไๅุ๊์้ࠦลๅ์๊หࠥฮำา฻ฬࠤํฮฯ้่ࠣษ๋ะั็์อࠤํอไษำ้ห๊า๋ࠠ็ึั์อࠠหๆๅหห๐วࠡส฼ำࠥอๆห้สลࠥ฿ๅา้สࠤํษ๊ืษࠣ฽๋ีࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡ࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣือ฿ษࠡล้์ฬ฿ࠠๅ฻่ีࠥอไไษืࠤ࠿࠭΅")
	d1cgFMGN2Eaoz9AelBI += KylMx0kfTOrG(u"࠭࡜࡯࡞ࡱࠫ`") + WfgnOq9Fd4lhMSQpK5(u"ࠧ࠲࠰ࠣฯฬฮสࠡๆ็ูๆำวหࠢส่ฯ๐ࠠๆ฻ิ์ๆࠦร็้สࠤ้อࠠหฬ฽๎ึࠦๆ่ษษ๎ฬ่ࠦๆัอ๋ࠥ࠭῰") + str(iJnLmxA0ykozR98WXFQ4Ye3w/mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠹࠴ભ")/mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠹࠴ભ")/VVtQk9vwe7(u"࠶࠹મ")/DItWNMaLOZ146CubYk8lfAwTy(u"࠸࠶ય")) + u2NDjURZVHlmdc0(u"ࠨࠢื๋ึ࠭῱")
	d1cgFMGN2Eaoz9AelBI += uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ࡟ࡲࠬῲ") + uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪ࠶࠳ࠦฬะษࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็้ๆื่ืࠢฦ๊์อࠠๅษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩῳ") + str(u5vT6erC7PYdV18MNSwRnJE/u2NDjURZVHlmdc0(u"࠼࠰ર")/u2NDjURZVHlmdc0(u"࠼࠰ર")/b098bsyjUud(u"࠲࠵઱")) + ebT9xRB63E(u"ࠫࠥ๐่ๆࠩῴ")
	d1cgFMGN2Eaoz9AelBI += mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡢ࡮ࠨ῵") + u2NDjURZVHlmdc0(u"࠭࠳࠯ฺࠢ์๏๊ࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥ์วะำสࠤฯะฺ๋ำࠣ์๊ีส่ࠢࠪῶ") + str(UHnG2wYuIQWKN38B4/YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠷࠲લ")/YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠷࠲લ")/G5TxeI0ND4ztC6(u"࠴࠷ળ")) + xmTX9Aeidq8cVhY(u"ࠧࠡ์๋้ࠬῷ")
	d1cgFMGN2Eaoz9AelBI += vlW6K1g8Xo35mPYbyO2GS(u"ࠨ࡞ࡱࠫῸ") + YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࠷࠲๋ࠥส้ีฺࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢๅำࠥะส฻์ิࠤํ๋ฯห้ࠣࠫΌ") + str(DkRgFyVIBM85OA/vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠹࠴઴")/vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠹࠴઴")) + jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࠤุอูสࠩῺ")
	d1cgFMGN2Eaoz9AelBI += ebT9xRB63E(u"ࠫࡡࡴࠧΏ") + YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩῼ") + str(mjBa0HgvKnI4oWRd/hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠺࠵વ")/hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠺࠵વ")) + vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࠠิษ฼อࠬ´")
	d1cgFMGN2Eaoz9AelBI += vlW6K1g8Xo35mPYbyO2GS(u"ࠧ࡝ࡰࠪ῾") + A6Iyo7eXrq2RtMmDxWj(u"ࠨ࠸࠱ࠤัีวࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣ็ะ๐ัศ๋้ࠢิะ็ࠡࠩ῿") + str(WfPehiKL4XVlonMQr9kUwAca6IybDj/vlW6K1g8Xo35mPYbyO2GS(u"࠻࠶શ")) + uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠥีโ๋ไฬࠫࠀ")
	d1cgFMGN2Eaoz9AelBI += ebT9xRB63E(u"ࠬࡢ࡮ࠨࠁ") + jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨࠂ") + str(jCJnzmXDkNqtB) + DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠡัๅ๎็ฯࠧࠃ")
	d1cgFMGN2Eaoz9AelBI += Yr0wo7FaSHx(u"ࠨ࡞ࡱࡠࡳ࠭ࠄ") + cg94WALw5orUhvtHSfNO(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭ࠅ") + str(DkRgFyVIBM85OA/xmTX9Aeidq8cVhY(u"࠼࠰ષ")/xmTX9Aeidq8cVhY(u"࠼࠰ષ")) + b46fBrugtPDSYspzMQIx(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫࠆ") + str(UHnG2wYuIQWKN38B4/xmTX9Aeidq8cVhY(u"࠼࠰ષ")/xmTX9Aeidq8cVhY(u"࠼࠰ષ")/YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠲࠵સ")) + YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪࠇ") + str(mjBa0HgvKnI4oWRd/xmTX9Aeidq8cVhY(u"࠼࠰ષ")/xmTX9Aeidq8cVhY(u"࠼࠰ષ")) + KylMx0kfTOrG(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩࠈ") + str(WfPehiKL4XVlonMQr9kUwAca6IybDj/xmTX9Aeidq8cVhY(u"࠼࠰ષ")) + KylMx0kfTOrG(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨࠉ") + str(jCJnzmXDkNqtB) + oh1JUWa3LdnqTpz5(u"ࠧࠡัๅ๎็ฯࠧࠊ")
	u59uk1YqFUTd(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡴ࡬࡫࡭ࡺࠧࠋ"),Wbwj0o5gsXQ8F2f(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧࠌ"),d1cgFMGN2Eaoz9AelBI,tvdQHb10PhNmuy6(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ࠍ"))
	return
def OdhmneuEgjNJPxB3YrTtzZW4UQS2G():
	Ay3eLGaTncD67lx8ZOud = oh1JUWa3LdnqTpz5(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧࠎ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(tjoHEAGv2XkrMBsVfCyp5U(u"ࠬ࠭ࠏ"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧࠐ"),WfgnOq9Fd4lhMSQpK5(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࠑ"),Ay3eLGaTncD67lx8ZOud)
	return
def CubdyY19Z08nJUacDK():
	Ay3eLGaTncD67lx8ZOud = C0CbfZuXJM(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩࠒ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(u2NDjURZVHlmdc0(u"ࠩࠪࠓ"),b098bsyjUud(u"ࠪࠫࠔ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠕ"),Ay3eLGaTncD67lx8ZOud)
	return
def nkJWMbO3Gv():
	Ay3eLGaTncD67lx8ZOud = DItWNMaLOZ146CubYk8lfAwTy(u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩࠖ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(ebT9xRB63E(u"࠭ࠧࠗ"),C0CbfZuXJM(u"ࠧࠨ࠘"),tvdQHb10PhNmuy6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠙"),Ay3eLGaTncD67lx8ZOud)
	return
def TYy02uDALVibcQolNMwGjFC69():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Wbwj0o5gsXQ8F2f(u"ࠩࠪࠚ"),ebT9xRB63E(u"ࠪࠫࠛ"),KylMx0kfTOrG(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࠜ"),cg94WALw5orUhvtHSfNO(u"๊ࠬใ๋ࠢํ฽๊๊่ࠠาสࠤฬ๊ๆ้฻้๋ࠣࠦวๅใํำ๏๎็ศฬࠣࡠࡳ๊ࠦอสࠣฮๆ฿๊ๅࠢศฺฬ็ษࠡษึ้์อࠠ࡝ࡰࠣ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪࠝ"))
	w2chBfzYG4FlZR7QIbJHTyoKrdv(GVPK9Ziaho6U2ySLj(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ࠞ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࡗࡶࡺ࡫ଁ"))
	return
def YpogBF5SOlcZrNtn1qmDkG():
	Ay3eLGaTncD67lx8ZOud  = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧๆฦัีฬࠦโศ็อࠤอ฿ึࠡึิ็ฬะࠠศๆศ๊ฯืๆหࠢส่ิ๎ไ๋ࠢห์฻฿ฺࠠษษๆࠥ฼ฯࠡษ็ฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ้ะำๆฯࠣๅ็฽ࠠๅส฼ฺ๋ࠥำหะา้๏ࠦวๅ็อูๆำࠠษษ็ำำ๎ไࠡๆ่์ฬู่ࠡษ็ๅ๏ี๊้ࠩࠟ")
	Ay3eLGaTncD67lx8ZOud += Vt4ELHXZP6(u"ࠨ๋๊ࠢฯ๐ฬสࠢ็๋ีอࠠศๆ฼หห่ࠠโษ้๋ࠥะโา์หหࠥาๅ๋฻ุ้ࠣะฮะ็ํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢ็หࠥ๐ำหูํ฽ํ์ࠠศๆาาํ๊ࠠๅฮ่๎฾ࠦๅ้ษๅ฽ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๊฿ࠠศีอาิอๅࠨࠠ")
	Ay3eLGaTncD67lx8ZOud += YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣเ࡙ࠡࠢࡔࡓࠦࠠฤ๊ࠣࠤࡕࡸ࡯ࡹࡻࠣࠤศ๎ࠠࠡࡆࡑࡗࠥࠦร้ࠢฦ๎ࠥำไࠡสึ๎฼ࠦยฯำ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳ࠭ࠡ")
	Ay3eLGaTncD67lx8ZOud += tvdQHb10PhNmuy6(u"ࠪࡠࡳ๊ว็๊ࠢิฬࠦไ็ࠢํั้ࠦวๅ็ื็้ฯ้ࠠว้้ฬࠦแใูࠣื๏่่ๆࠢหษฺ๊วฮࠢห฽฻ࠦวๅ็๋ห็฿้ࠠว฼ห็ฯࠠๆ๊สๆ฾ࠦวฯำ์ࠤ่อๆหࠢอ฽๊๊ࠠิษหๆฬࠦศะ๊้ࠤฺ๊วไๆࠪࠢ")
	u59uk1YqFUTd(tvdQHb10PhNmuy6(u"ࠫࡷ࡯ࡧࡩࡶࠪࠣ"),Yr0wo7FaSHx(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࠤ"),Ay3eLGaTncD67lx8ZOud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩࠥ"))
	Ay3eLGaTncD67lx8ZOud = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧศๆ่์ฬู่ࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪࠦ")
	Ay3eLGaTncD67lx8ZOud += vlW6K1g8Xo35mPYbyO2GS(u"ࠨ࡞ࡱࠫࠧ")+vdHRKkIgTp56Je1OuNo(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠨ")
	Ay3eLGaTncD67lx8ZOud += WfgnOq9Fd4lhMSQpK5(u"ࠪࡠࡳࡢ࡮ࠨࠩ")+u2NDjURZVHlmdc0(u"ࠫฬ๊ฯ้ๆࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬࠪ")
	Ay3eLGaTncD67lx8ZOud += b098bsyjUud(u"ࠬࡢ࡮ࠨࠫ")+pOIe6U1vWYC7Gh2udFBRgT(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠬ")
	Ay3eLGaTncD67lx8ZOud += u2NDjURZVHlmdc0(u"ࠧ࡝ࡰ࡟ࡲࠬ࠭")+DItWNMaLOZ146CubYk8lfAwTy(u"ࠨษ็้อืๅอ๋ࠢะิࠦืา์ๅอ๊ࠥสอษ๋ึࠥอไฺษษๆࠥ๎ไไ่๊หࠥะอหษฯࠤัํฯࠡๅห๎ึ่ࠦศๆ่ฬึ๋ฬࠡ์฻๊ࠥอไๆึๆ่ฮࠦี฻์ิอࠥ๎ไศࠢอืฯำโࠡษ็ฮ฾ฮࠠโวำห๊ࠥฯ๋ๅู้้ࠣไสࠢหห้ีฮ้ๆ่ࠣอ฿ึࠡษ็้ํอโฺ๋ࠢว๏฼วࠡๆๆ๎ࠥ๐สืฯࠣัั๋ࠠศๆุ่่๊ษࠡࠩ࠮")
	Ay3eLGaTncD67lx8ZOud += YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠯")
	u59uk1YqFUTd(b46fBrugtPDSYspzMQIx(u"ࠪࡶ࡮࡭ࡨࡵࠩ࠰"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ࠱"),Ay3eLGaTncD67lx8ZOud,CC4UDLW6brf(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࠲"))
	return
def kkBoDHtCcLAr9G():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Vt4ELHXZP6(u"࠭ࠧ࠳"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠨ࠴"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨอ็หะࠦืาไ่้ࠣะ่ศื็ࠤ๊฿ࠠศๆ่ฬึ๋ฬࠨ࠵"),cg94WALw5orUhvtHSfNO(u"ࠩฦีุ๊ࠠาีส่ฮࠦรุ้่่๊ࠢษࠡ็้ࠤ็อฦๆหࠣาิ๋วห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲศ๎ࠠษษึฮำีวๆࠢส่ๆ๐ำษ๊ๆࠤศีๆศ้࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡨࡵࡶࡳ࠾࠴࠵ࡦࡢࡥࡨࡦࡴࡵ࡫࠯ࡥࡲࡱ࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳษ่ࠡสสีุอไࠡษํ้๏๊ࠠศๆ์ࠤศีๆศ้ࠣࠤࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠳࠲࠴࠼ࡅ࡭࡭ࡢ࡫࡯࠲ࡨࡵ࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠶"))
	return
def Ueiz9Cxh8QJVMEfwdR1cOI6():
	HwYLjQDqTP5k9F1CXhOte()
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(tvdQHb10PhNmuy6(u"ࠪࡧࡪࡴࡴࡦࡴࠪ࠷"),vdHRKkIgTp56Je1OuNo(u"ࠫࠬ࠸"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬ࠭࠹"),b098bsyjUud(u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪ࠺"),b098bsyjUud(u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬ่ࠦศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯ่ࠦศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠻"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲હ"):
		jplLPaWg54UydbZrNn(pOIe6U1vWYC7Gh2udFBRgT(u"ࡘࡷࡻࡥଂ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(CC4UDLW6brf(u"ࠨࠩ࠼"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࠪ࠽"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪฮ๊ࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢหห้้วๆๆࠪ࠾"),b098bsyjUud(u"ࠫสึวࠡๅส๊ฯูࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวฮัࠣห้๋่ศไ฼ࠤๆาัษࠢส่๊๎โฺࠢส่ว์ࠠ࠯࠰࠱ࠤํษะศࠢสฺ่๊ใๅหุ้ࠣะๅาหࠣๅสึๆࠡษิื้ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ࠿"))
	return J1SavlWIe5EOAdVTQrfGYRhjo8KCw6
def wfRngJdl2PDzHaXW(showDialogs=vJ2Q9gokKptI6YxrhDURClcFOz4(u"࡙ࡸࡵࡦଃ")):
	if not showDialogs: showDialogs = cg94WALw5orUhvtHSfNO(u"࡚ࡲࡶࡧ଄")
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,cg94WALw5orUhvtHSfNO(u"ࠬࡍࡅࡕࠩࡀ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬࡁ"),VVtQk9vwe7(u"ࠧࠨࡂ"),xmTX9Aeidq8cVhY(u"ࠨࠩࡃ"),C0CbfZuXJM(u"ࡆࡢ࡮ࡶࡩଅ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠪࡄ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡎࡔࡕࡒࡖࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ࡅ"))
	if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
		eGSE8Rc2XCrLdmDAj9zJ3TUlwgW = GVPK9Ziaho6U2ySLj(u"ࡇࡣ࡯ࡷࡪଆ")
		llxDWyvLpAEwCkbJSN5hMr = xaEZjvs6y0qt2Wmh()
		b6kj4LJ5tzTeOMQi(tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩࡆ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝ࠪࡇ")+llxDWyvLpAEwCkbJSN5hMr+oh1JUWa3LdnqTpz5(u"࠭࡝ࠨࡈ"))
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠨࡉ"),xmTX9Aeidq8cVhY(u"ࠨࠩࡊ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡋ"),GVPK9Ziaho6U2ySLj(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧࡌ"))
	else:
		eGSE8Rc2XCrLdmDAj9zJ3TUlwgW = trSQHvP4aqBWFKxN5bZgXCu(u"ࡖࡵࡹࡪଇ")
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(C0CbfZuXJM(u"ࠫࠬࡍ"),vdHRKkIgTp56Je1OuNo(u"ࠬ࠭ࡎ"),Yr0wo7FaSHx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡏ"),b46fBrugtPDSYspzMQIx(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫࡐ"))
	if not eGSE8Rc2XCrLdmDAj9zJ3TUlwgW and showDialogs: LLKNOjU9Pbe71Rg()
	return eGSE8Rc2XCrLdmDAj9zJ3TUlwgW
def LLKNOjU9Pbe71Rg():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vlW6K1g8Xo35mPYbyO2GS(u"ࠨࠩࡑ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠪࡒ"),b098bsyjUud(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),Yr0wo7FaSHx(u"ࠫอ฿ึࠡษ็้ํอโฺࠢอัฯอฬࠡำห฻๋ࠥิโำࠣ์็ี๋ࠠๅ๋๊ࠥา็ศิๆࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣห้ืศุࠢสฺ่๊แาࠢฦ์ࠥํๆศๅู้้ࠣไสࠢไ๎ฺࠥ็ศัฬࠤฬ๊สีใํีࠥอไฯษุอࠥฮใ้ัํࠤ฾์ฯไࠢ฼่๊อࠠศ่๊ࠤฯ๋ࠠโฯุࠤฬ๊ศา่ส้ัูࠦๅ๋ࠣ็ํี๊ࠡษ็ษฺีวาษอࠤࡡࡴࠠ࠲࠹࠱࠺ࠥࠦࠦࠡࠢ࠴࠼࠳ࡡ࠰࠮࠻ࡠࠤࠥࠬࠠࠡ࠳࠼࠲ࡠ࠶࠭࠴࡟ࠪࡔ"))
	pZ4sfrO0W3SHGq()
	return
def rDcxWnkhEUCJ(hulSHFUcXsaVQGTn8r9zMkNPIwgvo=C0CbfZuXJM(u"ࠬ࠭ࡕ")):
	PAWq9e5lxaE2mp7iXyntVRZo1Js = b098bsyjUud(u"ࡗࡶࡺ࡫ଈ")
	if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩࡖ") not in hulSHFUcXsaVQGTn8r9zMkNPIwgvo:
		PAWq9e5lxaE2mp7iXyntVRZo1Js = u2NDjURZVHlmdc0(u"ࡊࡦࡲࡳࡦଉ")
		d1cy9GkbBivnRNTChoEFu5xIXp4 = VYEiZteQcrT7aqOBMRAyHC9(xmTX9Aeidq8cVhY(u"ࠧࡤࡧࡱࡸࡪࡸࠧࡗ"),ebT9xRB63E(u"ࠨะิ์ั࠭ࡘ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩศีุอไࠡ็ื็้ฯ࡙ࠧ"),Yr0wo7FaSHx(u"ࠪษึูวๅࠢิืฬ๊ษࠨ࡚"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊า࡛ࠧ"),ebT9xRB63E(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨ࡜"))
		if d1cy9GkbBivnRNTChoEFu5xIXp4 in [-u2NDjURZVHlmdc0(u"࠳઺"),b098bsyjUud(u"࠳઻")]: return
		elif d1cy9GkbBivnRNTChoEFu5xIXp4==C0CbfZuXJM(u"࠵઼"):
			PAWq9e5lxaE2mp7iXyntVRZo1Js = vlW6K1g8Xo35mPYbyO2GS(u"࡙ࡸࡵࡦଊ")
			hulSHFUcXsaVQGTn8r9zMkNPIwgvo = A6Iyo7eXrq2RtMmDxWj(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ࡝")
	if PAWq9e5lxaE2mp7iXyntVRZo1Js:
		if vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧ࡞") not in hulSHFUcXsaVQGTn8r9zMkNPIwgvo:
			J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࡟"),cg94WALw5orUhvtHSfNO(u"ࠩࠪࡠ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠫࡡ"),G5TxeI0ND4ztC6(u"ࠫํ฼ูࠡษ็ู้้ไสࠢไ๎ࠥอไิฮ็ࠫࡢ"),tjoHEAGv2XkrMBsVfCyp5U(u"่ࠬศๅࠢศีุอไࠡษ็ืัฺ๊ࠠๆํ็ࠥษๆࠡฬๆีึࠦࠠ็ใึࠤฬ๊แฺๆࠣห้ึ๊ࠡล฼฻ฬ้ࠠศๆุ่่๊ษࠡ࠰่่ࠣ๐๋ࠠฬ่ࠤฯูฬ๋ๆ๋ࠣีํࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦ࠮๊ࠡหำํ์่ࠠาสࠤฬ๊สิฮํู่่ࠥโࠢอีุ๊ࠠๆๆไࠤ้อࠠโษษำฮࠦๅ็้่ࠣส์็ࠡๆสࠤ๏ำส้์ࠣ฽้๏ࠠศๆุ่่๊ษࠡษ็ฮ๏ࠦสา์าࠤฬ์สࠡษ็ษอ๊ว฻ࠢ฼๊์อࠠ࠯๊่่ࠢࠥๅหࠢหฮ่ืวาࠢสฺ่๊ใๅหࠣรࠬࡣ"))
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=CC4UDLW6brf(u"࠶ઽ"):
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠧࡤ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠨࡥ"),A6Iyo7eXrq2RtMmDxWj(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫࡦ"),b098bsyjUud(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬࡧ"))
				return
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(WfgnOq9Fd4lhMSQpK5(u"ࠪࠫࡨ"),cg94WALw5orUhvtHSfNO(u"ࠫࠬࡩ"),u2NDjURZVHlmdc0(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),b46fBrugtPDSYspzMQIx(u"࠭แ๋ࠢสู่อิสࠢส่็อฯๆหࠣัฬ๎ไࠡล้ࠤฯ้สษࠢิืฬ๊ษࠡว็ํࠥอไๆสิ้ั่ࠦศึิัࠥ็๊่ษࠣห้๋ิไๆฬࠤศ๎ࠠศๆ่์฻๎ู๊ࠡศิฬࠦราัอࠤั๎วษ่๊ࠢࠥอไๆสิ้ัࠦแฦา้ࠤศ้สษࠢ฼๊ํอๆࠡสิ๎ิ้ࠠฤๆศ่่ะั้่ํࠤฬ๊ล๋็ํ่ࠥ๎สัๅิࠤํ๊วࠡฬ้ื๎ࠦร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠪ࡫"))
	search = GVfnMyZxiRI(header=YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࡘࡴ࡬ࡸࡪࠦࡡࠡ࡯ࡨࡷࡸࡧࡧࡦࡧࠣࠤࠥอใหสࠣีุอไสࠩ࡬"),source=FpjtBKrnu5SdfyOvEPIQ)
	if not search: return
	Ay3eLGaTncD67lx8ZOud = search
	if PAWq9e5lxaE2mp7iXyntVRZo1Js: type = DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠩ࡭")
	else: type = Wbwj0o5gsXQ8F2f(u"ࠩࡐࡩࡸࡹࡡࡨࡧࠪ࡮")
	llC9WmbrAIgpzfi3n = B4vT1EflKxbA9IaiG8U6Ck0(type,Ay3eLGaTncD67lx8ZOud,pOIe6U1vWYC7Gh2udFBRgT(u"࡚ࡲࡶࡧଋ"),oh1JUWa3LdnqTpz5(u"ࠪࠫ࡯"),Wbwj0o5gsXQ8F2f(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧࡰ"),hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	return
def sYBATZ9ylHDU6PQk():
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = b46fBrugtPDSYspzMQIx(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩࡱ")
	u59uk1YqFUTd(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡲࡪࡩ࡫ࡸࠬࡲ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧࡳ"),hulSHFUcXsaVQGTn8r9zMkNPIwgvo,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫࡴ"))
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬࡵ")
	u59uk1YqFUTd(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡰࡪ࡬ࡴࠨࡶ"),Wbwj0o5gsXQ8F2f(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩࡷ"),hulSHFUcXsaVQGTn8r9zMkNPIwgvo,C0CbfZuXJM(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨࡸ"))
	return
def rMN4VzB32OUgtWPd(f3pCnmFaVYx4zc1MNGBe5):
	o6olgEz21iJbqLsKhP = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(VVtQk9vwe7(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩࡹ")+f3pCnmFaVYx4zc1MNGBe5+b098bsyjUud(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭ࡺ"))
	y9sfZeW5tbQpkPHKxg7jDS = ebT9xRB63E(u"ࡔࡳࡷࡨଌ")
	if y9sfZeW5tbQpkPHKxg7jDS:
		Mrx2OeZV1LNjBsQ58Savi7.sleep(vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠷ા"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(Vt4ELHXZP6(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬࡻ"))
		Mrx2OeZV1LNjBsQ58Savi7.sleep(b46fBrugtPDSYspzMQIx(u"࠱િ"))
	return
def ArgM8WhIktPwENlm1R4Kd3aHqO():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(ebT9xRB63E(u"ࠩࠪࡼ"),WfgnOq9Fd4lhMSQpK5(u"ࠪࠫࡽ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡾ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪࡿ"))
	nkJWMbO3Gv()
	return
def pZ4sfrO0W3SHGq():
	url = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫࢀ")
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡈࡇࡗࠫࢁ"),url,ebT9xRB63E(u"ࠨࠩࢂ"),KylMx0kfTOrG(u"ࠩࠪࢃ"),Wbwj0o5gsXQ8F2f(u"ࠪࠫࢄ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࠬࢅ"),pOIe6U1vWYC7Gh2udFBRgT(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨࢆ"))
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	raSHETYVoDzR7B5X28LkWCs = JJDtX1PZyIgN2T.findall(G5TxeI0ND4ztC6(u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬࢇ"),YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	raSHETYVoDzR7B5X28LkWCs = raSHETYVoDzR7B5X28LkWCs[vlW6K1g8Xo35mPYbyO2GS(u"࠱ી")].split(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧ࠮ࠩ࢈"))[vlW6K1g8Xo35mPYbyO2GS(u"࠱ી")]
	OWxqrUb2uEs7ZYfM6mP = str(WWSLAyQdhUXl3ovb)
	R8Rag2sH1WBKOSFovjkdLn = b098bsyjUud(u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ษฮ๋ำࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪࢉ")+DItWNMaLOZ146CubYk8lfAwTy(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࢊ")+raSHETYVoDzR7B5X28LkWCs+tjoHEAGv2XkrMBsVfCyp5U(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢋ")
	R8Rag2sH1WBKOSFovjkdLn += uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡡࡴ࡜࡯ࠩࢌ")+b46fBrugtPDSYspzMQIx(u"ࠬࡡࡒࡕࡎࡠษฺีวาࠢๆ์ิ๐ࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆ้๋ࠣํࠦ࠺ࠡࠢࠣࠫࢍ")+b46fBrugtPDSYspzMQIx(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࢎ")+OWxqrUb2uEs7ZYfM6mP+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢏")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࠩ࢐"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࠪ࢑"),u2NDjURZVHlmdc0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭࢒"),R8Rag2sH1WBKOSFovjkdLn)
	return
def Svz9uiIDPCpYlRbFXytUgkds():
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc,d1cgFMGN2Eaoz9AelBI,sHCNe7qXk2m,R8Rag2sH1WBKOSFovjkdLn,hue6lGBoyiHT,TJQrGwVz62kmILMOjZhqKAi7BCD,QpHK9zjvuX = WfgnOq9Fd4lhMSQpK5(u"ࠫࠬ࢓"),G5TxeI0ND4ztC6(u"ࠬ࠭࢔"),VVtQk9vwe7(u"࠭ࠧ࢕"),Yr0wo7FaSHx(u"ࠧࠨ࢖"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠩࢗ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࠪ࢘"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"࢙ࠪࠫ")
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20,k1Mv4g2aP3wcKt,wExKuDyTseh9NX,JO3sChnivqVxDw1XPtTy9gz0FjS = {C0CbfZuXJM(u"ࠫࡦ࢚࠭"):A6Iyo7eXrq2RtMmDxWj(u"ࠬࡧ࢛ࠧ")},{},[],{}
	url = LWzUbE5adDslTXGr[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭࢜")][Vt4ELHXZP6(u"࠳ુ")]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(WfPehiKL4XVlonMQr9kUwAca6IybDj,tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡑࡑࡖࡘࠬ࢝"),url,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,KylMx0kfTOrG(u"ࠨࠩ࢞"),Vt4ELHXZP6(u"ࠩࠪ࢟"),tvdQHb10PhNmuy6(u"ࠪࠫࢠ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩࢡ"))
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(Wbwj0o5gsXQ8F2f(u"࡛ࠬ࡮ࡪࡶࡨࡨ࡙ࠥࡴࡢࡶࡨࡷࠬࢢ"),DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡕࡔࡃࠪࢣ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡌ࡫ࡱ࡫ࡩࡵ࡭ࠨࢤ"),Yr0wo7FaSHx(u"ࠨࡗࡎࠫࢥ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩࢦ"),G5TxeI0ND4ztC6(u"࡙ࠪࡆࡋࠧࢧ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(WfgnOq9Fd4lhMSQpK5(u"ࠫࡘࡧࡵࡥ࡫ࠣࡅࡷࡧࡢࡪࡣࠪࢨ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡑࡓࡂࠩࢩ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(KylMx0kfTOrG(u"࠭ࡎࡰࡴࡷ࡬ࠥࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨࢪ"),C0CbfZuXJM(u"ࠧࡏ࠰ࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬࢫ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(Wbwj0o5gsXQ8F2f(u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩࢬ"),u2NDjURZVHlmdc0(u"࡚ࠩ࠲ࡘࡧࡨࡢࡴࡤࠫࢭ"))
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace(vdHRKkIgTp56Je1OuNo(u"ࠪࡣࡤࡥࠧࢮ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࠥࠦࠧࢯ"))
	try: q57MZuYBFRj8IXLkb92nDo4wg = G8EwoDOyKShm1i0IHMfNYZlU7(u2NDjURZVHlmdc0(u"ࠬࡲࡩࡴࡶࠪࢰ"),YBEsLq8gVw629cMGQP1T)
	except:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࠧࢱ"),C0CbfZuXJM(u"ࠧࠨࢲ"),oh1JUWa3LdnqTpz5(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࢳ"),KylMx0kfTOrG(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩࢴ"))
		return
	LdNCmRAWItjkwpfY,jVy5hPEe9RzgHmDkfF,ynjtZHWid4lTA9ecprOoCD6x8Ja = q57MZuYBFRj8IXLkb92nDo4wg
	JO3sChnivqVxDw1XPtTy9gz0FjS = {}
	EOAsv6CyIu4 = [C0CbfZuXJM(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭ࢵ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪࢶ")]
	JrBIOcYNLCWgXVDEvpsi7Kyk2lRf = [CC4UDLW6brf(u"ࠬࡇࡌࡍࠩࢷ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ࢸ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨࢹ"),G5TxeI0ND4ztC6(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬࢺ"),b098bsyjUud(u"ࠩࡕࡉࡕࡕࡓࠨࢻ")]+EOAsv6CyIu4+xlhZCNs8FQ4+HzC0OmsPxKp8rbSiqlU
	for HLAhjNIVMFonqi5zg2aQlpyfRKBrm,dLRcj9VmIz4QNf0U23JwHPFu71,nSz4EuI716mjgsHy0DwZGlMoXx in jVy5hPEe9RzgHmDkfF:
		nSz4EuI716mjgsHy0DwZGlMoXx = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(nSz4EuI716mjgsHy0DwZGlMoXx)
		nSz4EuI716mjgsHy0DwZGlMoXx = nSz4EuI716mjgsHy0DwZGlMoXx.strip(KylMx0kfTOrG(u"ࠪࠤࠬࢼ")).strip(b46fBrugtPDSYspzMQIx(u"ࠫࠥ࠴ࠧࢽ"))
		R8Rag2sH1WBKOSFovjkdLn += u2NDjURZVHlmdc0(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࢾ")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm+Wbwj0o5gsXQ8F2f(u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢿ")+nSz4EuI716mjgsHy0DwZGlMoXx+CC4UDLW6brf(u"ࠧ࡝ࡰࠪࣀ")
		if dLRcj9VmIz4QNf0U23JwHPFu71.isdigit():
			JO3sChnivqVxDw1XPtTy9gz0FjS[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = int(dLRcj9VmIz4QNf0U23JwHPFu71)
			if int(dLRcj9VmIz4QNf0U23JwHPFu71)>A6Iyo7eXrq2RtMmDxWj(u"࠴࠴࠵ૂ"): dLRcj9VmIz4QNf0U23JwHPFu71 = trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫࣁ")
			else: dLRcj9VmIz4QNf0U23JwHPFu71 = G5TxeI0ND4ztC6(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫࣂ")
		if HLAhjNIVMFonqi5zg2aQlpyfRKBrm not in JrBIOcYNLCWgXVDEvpsi7Kyk2lRf:
			if   dLRcj9VmIz4QNf0U23JwHPFu71==Yr0wo7FaSHx(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ࣃ"): DDTdLb3SZQPv7rX1qfwHCpn2eyKc += uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠥࠦࠧࣄ")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm
			elif dLRcj9VmIz4QNf0U23JwHPFu71==G5TxeI0ND4ztC6(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧࣅ"): d1cgFMGN2Eaoz9AelBI += KylMx0kfTOrG(u"࠭ࠠࠡࠩࣆ")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm
	HHM0c8BpsWFG3,GVcpLbM9A1Br6WDnwoe3z,lPxXCEzFIhqBOWQG = list(zip(*jVy5hPEe9RzgHmDkfF))
	for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in sorted(Mo2ZvEHtN8QOj5gy1pnVxFLPd):
		if HLAhjNIVMFonqi5zg2aQlpyfRKBrm not in HHM0c8BpsWFG3:
			R8Rag2sH1WBKOSFovjkdLn += G5TxeI0ND4ztC6(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬࣇ")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm+ebT9xRB63E(u"ࠨ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࣈ")+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ็หࠥ๐่อัࠪࣉ")+G5TxeI0ND4ztC6(u"ࠪࡠࡳࡢ࡮ࠨ࣊")
			if HLAhjNIVMFonqi5zg2aQlpyfRKBrm not in JrBIOcYNLCWgXVDEvpsi7Kyk2lRf: sHCNe7qXk2m += tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠥࠦࠧ࣋")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm
	for nSz4EuI716mjgsHy0DwZGlMoXx,oISMg2J7z8nrWxitjAhGeBf in LdNCmRAWItjkwpfY:
		nSz4EuI716mjgsHy0DwZGlMoXx = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(nSz4EuI716mjgsHy0DwZGlMoXx)
		hue6lGBoyiHT += nSz4EuI716mjgsHy0DwZGlMoXx+Vt4ELHXZP6(u"ࠬࡀࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࣌")+str(oISMg2J7z8nrWxitjAhGeBf)+VVtQk9vwe7(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠫ࣍")
	DDTdLb3SZQPv7rX1qfwHCpn2eyKc = DDTdLb3SZQPv7rX1qfwHCpn2eyKc.strip(KylMx0kfTOrG(u"ࠧࠡࠩ࣎"))
	d1cgFMGN2Eaoz9AelBI = d1cgFMGN2Eaoz9AelBI.strip(KylMx0kfTOrG(u"ࠨ࣏ࠢࠪ"))
	sHCNe7qXk2m = sHCNe7qXk2m.strip(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࣐ࠩࠣࠫ"))
	gtERJz1moheKiS2H = DDTdLb3SZQPv7rX1qfwHCpn2eyKc+Wbwj0o5gsXQ8F2f(u"ࠪࠤ࣑ࠥ࠭")+d1cgFMGN2Eaoz9AelBI
	WBHA4XTOYEpdLZ7ijf8tyVkI6  = oh1JUWa3LdnqTpz5(u"๊ࠫ๎วใ฻๊ࠣัำࠠศๆหี๋อๅอࠢหฮูเ๊ๅࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨ࣒")+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡢ࡮ࠨ࣓")+uEed4OSxm7hBq9Vvky6QjHwWC(u"่่࠭าสࠤ๊฿ๆศ้ࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠫࣔ")+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧ࡝ࡰࠪࣕ")
	WBHA4XTOYEpdLZ7ijf8tyVkI6 += b46fBrugtPDSYspzMQIx(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫࣖ")+gtERJz1moheKiS2H+GVPK9Ziaho6U2ySLj(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨࣗ")
	WBHA4XTOYEpdLZ7ijf8tyVkI6 += hhmKpWNtn849SgBFoVqHkQCXZJvT(u"้ࠪํอโฺࠢ็้ࠥ๐ิ฻ๆࠣห้ฮั็ษ่ะ๋ࠥๆ่ษࠣๅ๏ี๊้้สฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠩࣘ")+DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࡡࡴࠧࣙ")+Vt4ELHXZP6(u"ࠬ๎็ัษ้ࠣ฾์ว่ࠢสัฯ๋วๅࠢๆฬ๏ื้ࠠฮ๋ำ๋ࠥิไๆฬࠤๆ๐ࠠศๆหี๋อๅอࠩࣚ")+Yr0wo7FaSHx(u"࠭࡜࡯ࠩࣛ")
	WBHA4XTOYEpdLZ7ijf8tyVkI6 += Yr0wo7FaSHx(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪࣜ")+sHCNe7qXk2m+b46fBrugtPDSYspzMQIx(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣝ")
	cKyptndmjRBC6a1Qwe4XG5EAHZLo,rrACtbRgYep0HXxoVnNKzfuv,GFxCKrfDTAN4HUzYkVIvtw75,Q3Qt7BOveKNrkaZmYpM8 = b46fBrugtPDSYspzMQIx(u"࠴ૃ"),b46fBrugtPDSYspzMQIx(u"࠴ૃ"),b46fBrugtPDSYspzMQIx(u"࠴ૃ"),b46fBrugtPDSYspzMQIx(u"࠴ૃ")
	all = JO3sChnivqVxDw1XPtTy9gz0FjS[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࡄࡐࡑ࠭ࣞ")]
	if Vt4ELHXZP6(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪࣟ") in list(JO3sChnivqVxDw1XPtTy9gz0FjS.keys()): cKyptndmjRBC6a1Qwe4XG5EAHZLo = JO3sChnivqVxDw1XPtTy9gz0FjS[Vt4ELHXZP6(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ࣠")]
	if CC4UDLW6brf(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭࣡") in list(JO3sChnivqVxDw1XPtTy9gz0FjS.keys()): rrACtbRgYep0HXxoVnNKzfuv = JO3sChnivqVxDw1XPtTy9gz0FjS[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ࣢")]
	if b46fBrugtPDSYspzMQIx(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࣣࠫ") in list(JO3sChnivqVxDw1XPtTy9gz0FjS.keys()): GFxCKrfDTAN4HUzYkVIvtw75 = JO3sChnivqVxDw1XPtTy9gz0FjS[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡏࡈࡘࡗࡕࡐࡐࡎࡌࡗࠬࣤ")]
	if uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡕࡉࡕࡕࡓࠨࣥ") in list(JO3sChnivqVxDw1XPtTy9gz0FjS.keys()): Q3Qt7BOveKNrkaZmYpM8 = JO3sChnivqVxDw1XPtTy9gz0FjS[A6Iyo7eXrq2RtMmDxWj(u"ࠪࡖࡊࡖࡏࡔࣦࠩ")]
	HwxNkufUmb51rnXB3I9 = all-cKyptndmjRBC6a1Qwe4XG5EAHZLo-rrACtbRgYep0HXxoVnNKzfuv-GFxCKrfDTAN4HUzYkVIvtw75-Q3Qt7BOveKNrkaZmYpM8
	g5lf2u4DxNp8imnYevK,VVx70Fiegtsfp8TbzAc6uaYBqEdO4 = ynjtZHWid4lTA9ecprOoCD6x8Ja[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠵ૄ")]
	g5lf2u4DxNp8imnYevK,SSruY9w0sDogn = ynjtZHWid4lTA9ecprOoCD6x8Ja[tvdQHb10PhNmuy6(u"࠷ૅ")]
	bbKx1isLIOlUQRCnghYJTf7 = VVx70Fiegtsfp8TbzAc6uaYBqEdO4-SSruY9w0sDogn
	QpHK9zjvuX += pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧࣧ")+str(SSruY9w0sDogn)+VVtQk9vwe7(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣨ")+pOIe6U1vWYC7Gh2udFBRgT(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࣩࠢࠪ")
	QpHK9zjvuX += ebT9xRB63E(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ࣪")+str(bbKx1isLIOlUQRCnghYJTf7)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࣫")+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩหหุะฮะษ่ࠤࡵࡸ࡯ࡹࡻࠣวํࠦࡶࡱࡰࠣ࠾ࠥ࠭࣬")
	QpHK9zjvuX += G5TxeI0ND4ztC6(u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ࣭")+str(VVx70Fiegtsfp8TbzAc6uaYBqEdO4)+vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࣮࠭")+G5TxeI0ND4ztC6(u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾࣯ࠥ࠭")
	QpHK9zjvuX += DItWNMaLOZ146CubYk8lfAwTy(u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࣰࠫ")+str(len(ynjtZHWid4lTA9ecprOoCD6x8Ja[WfgnOq9Fd4lhMSQpK5(u"࠲૆"):]))+tjoHEAGv2XkrMBsVfCyp5U(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࣱࠩ")+Yr0wo7FaSHx(u"ࠨ฻าำࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎์อࠠฤฮ๊ึฮࠦ࠺ࠡ࡞ࡱࡠࡳࣲ࠭")
	for QfZp1nrE5iHgVD60I,YqywcljIHsFzoXaf0T97 in ynjtZHWid4lTA9ecprOoCD6x8Ja[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠳ે"):]:
		QfZp1nrE5iHgVD60I = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(QfZp1nrE5iHgVD60I)
		QfZp1nrE5iHgVD60I = QfZp1nrE5iHgVD60I.strip(KylMx0kfTOrG(u"ࠩࠣࠫࣳ")).strip(C0CbfZuXJM(u"ࠪࠤ࠳࠭ࣴ"))
		QpHK9zjvuX += QfZp1nrE5iHgVD60I+A6Iyo7eXrq2RtMmDxWj(u"ࠫ࠿࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩࣵ")+str(YqywcljIHsFzoXaf0T97)+C0CbfZuXJM(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࣶࠠࠡࠢࠪ")
	TJQrGwVz62kmILMOjZhqKAi7BCD += NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩࣷ")+str(HwxNkufUmb51rnXB3I9)+tjoHEAGv2XkrMBsVfCyp5U(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣸ")+tjoHEAGv2XkrMBsVfCyp5U(u"ࠨใํำ๏๎็ศฬࠣหูะฺๅฬࠣ࠾ࣹࠥ࠭")
	TJQrGwVz62kmILMOjZhqKAi7BCD += ebT9xRB63E(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࣺࠧ")+str(cKyptndmjRBC6a1Qwe4XG5EAHZLo)+DItWNMaLOZ146CubYk8lfAwTy(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࣻ")+VVtQk9vwe7(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢหห๏ั่็ࠢ࠽ࠤࠬࣼ")
	TJQrGwVz62kmILMOjZhqKAi7BCD += tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪࣽ")+str(Q3Qt7BOveKNrkaZmYpM8)+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࣾ")+DItWNMaLOZ146CubYk8lfAwTy(u"ุࠧๆหหฯࠦำ๋ำไีࠥอไๆีอ์ิ฿ࠠ࠻ࠢࠪࣿ")
	TJQrGwVz62kmILMOjZhqKAi7BCD += jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭ऀ")+str(rrACtbRgYep0HXxoVnNKzfuv)+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫँ")+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪฮะฮ๊หࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤ࠿ࠦࠧं")
	TJQrGwVz62kmILMOjZhqKAi7BCD += NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩः")+str(GFxCKrfDTAN4HUzYkVIvtw75)+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧऄ")+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬअ")
	TJQrGwVz62kmILMOjZhqKAi7BCD += Yr0wo7FaSHx(u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬआ")+str(len(LdNCmRAWItjkwpfY))+Vt4ELHXZP6(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪइ")+VVtQk9vwe7(u"ࠩา์้ࠦิ฻ๆอࠤๆ๐ฯ๋๊๊หฯࠦ࠺ࠡࠩई")
	TJQrGwVz62kmILMOjZhqKAi7BCD += A6Iyo7eXrq2RtMmDxWj(u"ࠪࡠࡳࡢ࡮ࠨउ")+hue6lGBoyiHT
	u59uk1YqFUTd(tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫऊ"),VVtQk9vwe7(u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬऋ"),QpHK9zjvuX,Vt4ELHXZP6(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩऌ"))
	u59uk1YqFUTd(WfgnOq9Fd4lhMSQpK5(u"ࠧࡤࡧࡱࡸࡪࡸࠧऍ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩऎ"),TJQrGwVz62kmILMOjZhqKAi7BCD,DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬए"))
	u59uk1YqFUTd(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡧࡪࡴࡴࡦࡴࠪऐ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"๊ࠫ๎วใ฻ࠣหูะฺๅฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧऑ"),WBHA4XTOYEpdLZ7ijf8tyVkI6,vdHRKkIgTp56Je1OuNo(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨऒ"))
	u59uk1YqFUTd(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭࡬ࡦࡨࡷࠫओ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧฤ฻็ํࠥอไะ๊็ࠤฬ๊ส๋ࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦวิฬัำ๊ะࠠศๆหี๋อๅอࠩऔ"),R8Rag2sH1WBKOSFovjkdLn,xmTX9Aeidq8cVhY(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩक"))
	return
def UcLEgYKvT7Au6Go():
	Ay3eLGaTncD67lx8ZOud = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ์฼้้ࠦวโุ็ࠤออำหะาห๊ࠦฬๅัࠣ็ํี๊ࠡࠪࡎࡳࡩ࡯ࠠࡔ࡭࡬ࡲ࠮ࠦวๅาํࠤฬูๅ่࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯࡞ࡱࠤํ๋ๅไ่ࠣฮะฮ๊ห้ࠣฬฬูสฯัส้๋ࠥำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠥษ่ࠡฬะ้๏๊็ࠡ็้ࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨख")
	u59uk1YqFUTd(KylMx0kfTOrG(u"ࠪࡧࡪࡴࡴࡦࡴࠪग"),xmTX9Aeidq8cVhY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧघ"),Ay3eLGaTncD67lx8ZOud,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨङ"))
	return
def moO0HksFWS7NyZ():
	Ay3eLGaTncD67lx8ZOud = trSQHvP4aqBWFKxN5bZgXCu(u"࠭วๅำสฬ฼๐ๆࠡลา๊ฬํࠠโ์๊้ฬࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯ๊๊ࠡ์ࠥ฿ศศำฬࠤ฾์ࠠหอห๎ฯࠦใศ็็ࠤฬ๎ส้็สฮ๏้๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠ็฼๋ࠥอึศใฬࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯ้ࠠ็฼๋ࠥอึศใฬࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯ๊่ࠡ฽์ࠦวืษไอ๋ࠥำห๊า฽ࠥ฿ๅศัࠣ์ๆ๐็ࠡลํฺฬࠦฬๆ์฼ࠤฬ฿ฯศัอࠤ่๎ฯ๋ࠢส่๊฽ไ้สฬࠤ้฿ๅๅࠢหี๋อๅอࠢ฼้ฬี้ࠠๅ็๋ฬࠦสห็ࠣหํะ่ๆษอ๎่๐ว๊ࠡ็หࠥะอหษฯࠤศ๐ࠠ็๊฼ࠤ๊์ࠠศๆัฬึฯࠠโ์ࠣ็ํี๊ࠡล๋ࠤฬ๊ฮษำฬࠤๆ๐ࠠหอห๎ฯࠦรืษไหฯࠦใ้ัํࠫच")+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧ࡝ࡰࠪछ")+Vt4ELHXZP6(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫज")+LWzUbE5adDslTXGr[ebT9xRB63E(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨझ")][Yr0wo7FaSHx(u"࠳ૉ")]+C0CbfZuXJM(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧञ")+LWzUbE5adDslTXGr[u2NDjURZVHlmdc0(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪट")][VVtQk9vwe7(u"࠳ૈ")]+b46fBrugtPDSYspzMQIx(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧठ")
	Ay3eLGaTncD67lx8ZOud += tjoHEAGv2XkrMBsVfCyp5U(u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨड")+LWzUbE5adDslTXGr[vdHRKkIgTp56Je1OuNo(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨढ")][Vt4ELHXZP6(u"࠵૊")]+CC4UDLW6brf(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪण")
	Ay3eLGaTncD67lx8ZOud += Vt4ELHXZP6(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬत")+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡠࡳ࠭थ")+Yr0wo7FaSHx(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧद")+LWzUbE5adDslTXGr[Yr0wo7FaSHx(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭ध")][GVPK9Ziaho6U2ySLj(u"࠷ો")]+b46fBrugtPDSYspzMQIx(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨन")
	u59uk1YqFUTd(b46fBrugtPDSYspzMQIx(u"ࠧࡤࡧࡱࡸࡪࡸࠧऩ"),vdHRKkIgTp56Je1OuNo(u"ࠨษ็้ํอโฺࠢส่ึูๅ๋ห่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧप"),Ay3eLGaTncD67lx8ZOud,Yr0wo7FaSHx(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬफ"))
	return
def J8kbHdvrDopY(TAgJ5oX3suh7iy):
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠩब")+TAgJ5oX3suh7iy+vdHRKkIgTp56Je1OuNo(u"ࠫ࠮࠭भ"), xmTX9Aeidq8cVhY(u"ࡕࡴࡸࡩ଍"))
	return
def oCOWGuHNYfALx0():
	EYgQHCJOMW98Ps2wf(tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡹࡴࡰࡲࠪम"))
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡁࡤࡶ࡬ࡺࡦࡺࡥࡘ࡫ࡱࡨࡴࡽࠨࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࡖࡩࡹࡺࡩ࡯ࡩࡶ࠭ࠧय"))
	return
def dHLU8x6rjFw():
	Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(ebT9xRB63E(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭र"), NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡖࡵࡹࡪ଎"))
	return
def SSrIWDelfMtNcUdzAkF(showDialogs):
	if not showDialogs: J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = pOIe6U1vWYC7Gh2udFBRgT(u"ࡗࡶࡺ࡫ଏ")
	else: J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(vdHRKkIgTp56Je1OuNo(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऱ"),oh1JUWa3LdnqTpz5(u"ࠩࠪल"),ebT9xRB63E(u"ࠪࠫळ"),tvdQHb10PhNmuy6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऴ"),A6Iyo7eXrq2RtMmDxWj(u"ࠬฮั็ษ่ะ้่ࠥะ์ࠣ๎็๎ๅࠡส฼้้๐ษࠡฬะำ๏ัࠠอ็ํ฽ࠥอไฦุสๅฬะࠠหๆๅหห๐วࠡๅ็ࠤ࠷࠺ࠠิษ฼อࠥ๎ไไ่้๊้ࠣๆࠡวฯีฬว็ศࠢส่ว์ࠠ࠯๊่ࠢࠥะั๋ัࠣฮาี๊ฬࠢฯ้๏฿ࠠฦุสๅฬะࠠไ๊า๎ࠥอไร่ࠣรࠬव"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==Wbwj0o5gsXQ8F2f(u"࠷ૌ"):
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(b098bsyjUud(u"࠭ࡕࡱࡦࡤࡸࡪࡇࡤࡥࡱࡱࡖࡪࡶ࡯ࡴࠩश"))
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠨष"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࠩस"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬह"),cg94WALw5orUhvtHSfNO(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪऺ"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨऻ"))
	return
def LLf9nm0FJYXRrEVGCce1wjdp8():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"़ࠬ࠭"),vdHRKkIgTp56Je1OuNo(u"࠭ࠧऽ"),vdHRKkIgTp56Je1OuNo(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪा"),xmTX9Aeidq8cVhY(u"ࠨๆ่ืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้่วว็ฬࠤฬ๊ส๋ࠢอี๏ีࠠๆีะ๋ฬ่ࠦๅษࠣฮิิไࠡว็๎์อ้ࠠๆๆ๊ࠥฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥษ่ࠡษึฮำีๅࠡࠤส่่๐ศ้ำาࠦࠥ๎วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢสฺ฿฽ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨि"))
	return
def bVW0wxaLiI2uAe6hMTEOvt7():
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(A6Iyo7eXrq2RtMmDxWj(u"ࠩࠪी"),C0CbfZuXJM(u"ࠪࠫु"),xmTX9Aeidq8cVhY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧू"),GVPK9Ziaho6U2ySLj(u"๊ࠬไห฻ส้้ࠦๅฺࠢส่๊็ึๅหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆิหอ฽ࠠศๆำ๎ࠥะั๋ัࠣษ฻อแห้ࠣวํࠦๅิฯ๊ࠤ๊์ࠠࠡไสส๊ฯࠠศๆ่ๅ฻๊ษ๊ࠡ็็๋ࠦไศࠢอ๊็ืฺࠠๆํ๋ࠥ๎ไศࠢอุ฿๊็ࠡ࠰ࠣ์ออำหะาห๊ࠦࠢศๆ่หํูࠢࠡล๋ࠤࠧอไา์่์ฯࠨࠠศุ฽฻ࠥ฿ไ๊ࠢส่ืืࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦฤ็สࠤออำหะาห๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣๅฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠤ࠳่ࠦ็ใึࠤฬ๊ใๅษ่ࠤํอไุำํๆฮูࠦ็ัࠣห้ะูศ็็ࠤ๊฿ࠠๆฯอ์๏อสࠡไ๋หห๋ࠠศๆ่ๅ฻๊ษࠨृ"))
	return
def LaqMoTyPh6J8sDCAN5IljkQXG91gp(showDialogs=b46fBrugtPDSYspzMQIx(u"ࡘࡷࡻࡥଐ")):
	K78mS9RiVINY = [pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨॄ"),WfgnOq9Fd4lhMSQpK5(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨॅ"),oh1JUWa3LdnqTpz5(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫॆ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫे"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫै"),b46fBrugtPDSYspzMQIx(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨॉ")]
	gm9yXxIDGUZb3q54 = K78mS9RiVINY+[tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧॊ"),vdHRKkIgTp56Je1OuNo(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫो"),b098bsyjUud(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ौ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ्ࠧ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡶ࡯࡮ࡴ࠮ࡱࡪࡨࡲࡴࡳࡥ࡯ࡣ࡯ࡉࡒࡇࡄࠨॎ"),oh1JUWa3LdnqTpz5(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧॏ"),u2NDjURZVHlmdc0(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫॐ")]
	gFdBaQ9bzKVRS = AwnlUgaf453N7P20([C0CbfZuXJM(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ॑")])
	MqLDJCp8da6vBUcme2P = []
	for f3pCnmFaVYx4zc1MNGBe5 in [WfgnOq9Fd4lhMSQpK5(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ॒")]:
		if f3pCnmFaVYx4zc1MNGBe5 not in list(gFdBaQ9bzKVRS.keys()): continue
		vuTHKR8XOry1aEF5P7m2WAhLSQU,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk,QAsCTKBoIkbrMP,qqNtyjr3HdElznmDWbesYvgSL19V,JUWFbMGH4p1jx,LTnkjge7ZHNA,SBw5f9TFWh6YPe = gFdBaQ9bzKVRS[f3pCnmFaVYx4zc1MNGBe5]
		if not lqMyFS6oN1V2BjGrEUAvxeLtRTgCk or (lqMyFS6oN1V2BjGrEUAvxeLtRTgCk and vuTHKR8XOry1aEF5P7m2WAhLSQU): MqLDJCp8da6vBUcme2P.append(f3pCnmFaVYx4zc1MNGBe5)
	MR04Nzr2IKtg96yoW = len(MqLDJCp8da6vBUcme2P)>vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠰્")
	LxomZnH9Ky = gxoYzqsnPQ.connect(pWKgVeBs5DjUcyv47PE0or2)
	LxomZnH9Ky.text_factory = str
	ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
	Xlkhy3qMP2oQ1UzHuaSKW87Ed4vTp = []
	for f3pCnmFaVYx4zc1MNGBe5 in K78mS9RiVINY:
		ooRPprGBD89QXusn.execute(ebT9xRB63E(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡨࡲࡦࡨ࡬ࡦࡦࠣࡁࠥࠨ࠱ࠣࠢࡤࡲࡩࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ॓")+f3pCnmFaVYx4zc1MNGBe5+vdHRKkIgTp56Je1OuNo(u"ࠨࠤࠣ࠿ࠬ॔"))
		Z2ARJehHkjndvF = ooRPprGBD89QXusn.fetchall()
		if Z2ARJehHkjndvF: Xlkhy3qMP2oQ1UzHuaSKW87Ed4vTp.append(f3pCnmFaVYx4zc1MNGBe5)
	TXbYCMLoru = len(Xlkhy3qMP2oQ1UzHuaSKW87Ed4vTp)>NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠱૎")
	for f3pCnmFaVYx4zc1MNGBe5 in gm9yXxIDGUZb3q54:
		ooRPprGBD89QXusn.execute(b46fBrugtPDSYspzMQIx(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡲࡶ࡮࡭ࡩ࡯ࠢࡉࡖࡔࡓࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧॕ")+f3pCnmFaVYx4zc1MNGBe5+tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࠦࠥࡁࠧॖ"))
		l5tXYBhy4FT3CPjc7EKUH = ooRPprGBD89QXusn.fetchall()
		if l5tXYBhy4FT3CPjc7EKUH and b098bsyjUud(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ॗ") not in str(l5tXYBhy4FT3CPjc7EKUH): MqLDJCp8da6vBUcme2P.append(f3pCnmFaVYx4zc1MNGBe5)
	GujXw7DRdIs5L4KhUpTV = len(MqLDJCp8da6vBUcme2P)>mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲૏")
	MqLDJCp8da6vBUcme2P = list(set(MqLDJCp8da6vBUcme2P))
	LxomZnH9Ky.close()
	vuTHKR8XOry1aEF5P7m2WAhLSQU = DItWNMaLOZ146CubYk8lfAwTy(u"ࡋࡧ࡬ࡴࡧ଑")
	if TXbYCMLoru or GujXw7DRdIs5L4KhUpTV:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬक़"),WfgnOq9Fd4lhMSQpK5(u"࠭ࠧख़"),WfgnOq9Fd4lhMSQpK5(u"ࠧࠨग़"),C0CbfZuXJM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫज़"),C0CbfZuXJM(u"ࠩส่อืๆศ็ฯࠤําฯࠡ็ื็้ฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡ࡞ࡱࡠࡳ࡛ࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠศๆล๊ࠥล࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨड़"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴ૐ"):
			I4PiEVfbu3N5aZ0BsOQX2 = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࡚ࡲࡶࡧ଒")
			if MR04Nzr2IKtg96yoW:
				I4PiEVfbu3N5aZ0BsOQX2 = V2VoDzGIJflYU(WfgnOq9Fd4lhMSQpK5(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬढ़"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡆࡢ࡮ࡶࡩଓ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡆࡢ࡮ࡶࡩଓ"))
			YY1WfCqu5oO9PV4mcQzetd6NHh = VVtQk9vwe7(u"ࡕࡴࡸࡩଔ")
			if TXbYCMLoru:
				for f3pCnmFaVYx4zc1MNGBe5 in Xlkhy3qMP2oQ1UzHuaSKW87Ed4vTp: rMN4VzB32OUgtWPd(f3pCnmFaVYx4zc1MNGBe5)
				YY1WfCqu5oO9PV4mcQzetd6NHh = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡖࡵࡹࡪକ")
			jxy0NIgcAuFwQkXHnVqlbUfJZ3S = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡗࡶࡺ࡫ଖ")
			if GujXw7DRdIs5L4KhUpTV:
				LxomZnH9Ky = gxoYzqsnPQ.connect(pWKgVeBs5DjUcyv47PE0or2)
				LxomZnH9Ky.text_factory = str
				ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
				for f3pCnmFaVYx4zc1MNGBe5 in MqLDJCp8da6vBUcme2P:
					if trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࠧफ़") in f3pCnmFaVYx4zc1MNGBe5: l5tXYBhy4FT3CPjc7EKUH = f3pCnmFaVYx4zc1MNGBe5
					else: l5tXYBhy4FT3CPjc7EKUH = oh1JUWa3LdnqTpz5(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧय़")
					try: ooRPprGBD89QXusn.execute(trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪॠ")+l5tXYBhy4FT3CPjc7EKUH+cg94WALw5orUhvtHSfNO(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ॡ")+f3pCnmFaVYx4zc1MNGBe5+G5TxeI0ND4ztC6(u"ࠨࠤࠣ࠿ࠬॢ"))
					except: jxy0NIgcAuFwQkXHnVqlbUfJZ3S = Yr0wo7FaSHx(u"ࡊࡦࡲࡳࡦଗ")
				LxomZnH9Ky.commit()
				LxomZnH9Ky.close()
			Mrx2OeZV1LNjBsQ58Savi7.sleep(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵૑"))
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(G5TxeI0ND4ztC6(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ॣ"))
			Mrx2OeZV1LNjBsQ58Savi7.sleep(u2NDjURZVHlmdc0(u"࠶૒"))
			if I4PiEVfbu3N5aZ0BsOQX2 or YY1WfCqu5oO9PV4mcQzetd6NHh or jxy0NIgcAuFwQkXHnVqlbUfJZ3S:
				vuTHKR8XOry1aEF5P7m2WAhLSQU = b098bsyjUud(u"ࡋࡧ࡬ࡴࡧଘ")
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l(GVPK9Ziaho6U2ySLj(u"ࠪࠫ।"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࠬ॥"),ebT9xRB63E(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ०"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ฬ๋ัࠣ࠲࠳ࠦสๆࠢห๊ัออࠡฬไ฽๏๊้ࠠวุ่ฬำࠠศๆ่ืฯ๎ฯฺ๋ࠢห้ะอะ์ฮࠤฬ๊สๅไสส๏ࠦไอ็ํ฽ࠥหึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ१"))
			else:
				vuTHKR8XOry1aEF5P7m2WAhLSQU = tjoHEAGv2XkrMBsVfCyp5U(u"࡚ࡲࡶࡧଙ")
				ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Wbwj0o5gsXQ8F2f(u"ࠧࠨ२"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩ३"),Yr0wo7FaSHx(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ४"),GVPK9Ziaho6U2ySLj(u"่้ࠪษำโࠢ࠱࠲ࠥ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡ็ึฮํีูࠡ฻่หิ่ࠦฦื็หาࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨ५"))
	elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(GVPK9Ziaho6U2ySLj(u"ࠫࠬ६"),b46fBrugtPDSYspzMQIx(u"ࠬ࠭७"),GVPK9Ziaho6U2ySLj(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ८"),tvdQHb10PhNmuy6(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅีๅ็อࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦร้ࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠧ९"))
	return vuTHKR8XOry1aEF5P7m2WAhLSQU
def HrdbGelK51WAuCZox2V():
	PvhwX21M0LV,uFcEqXzUhna7Kft3CLPmAj,VjIuD6veCMJ5O9wBUfKRPmAQF4E = Wbwj0o5gsXQ8F2f(u"ࡆࡢ࡮ࡶࡩଚ"),u2NDjURZVHlmdc0(u"ࠨࠩ॰"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩࠪॱ")
	KQV0YZeIuf,LnKt0qpTlBJ9,rhb9P0NwHA = Vt4ELHXZP6(u"ࡇࡣ࡯ࡷࡪଛ"),Vt4ELHXZP6(u"ࠪࠫॲ"),b098bsyjUud(u"ࠫࠬॳ")
	P9PtAZfLuJNSpM3KR0bzQx512s = [YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪॴ"),Yr0wo7FaSHx(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬॵ"),GVPK9Ziaho6U2ySLj(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩॶ"),Vt4ELHXZP6(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧॷ")]
	gFdBaQ9bzKVRS = AwnlUgaf453N7P20(P9PtAZfLuJNSpM3KR0bzQx512s)
	for f3pCnmFaVYx4zc1MNGBe5 in P9PtAZfLuJNSpM3KR0bzQx512s:
		if f3pCnmFaVYx4zc1MNGBe5 not in list(gFdBaQ9bzKVRS.keys()): continue
		vuTHKR8XOry1aEF5P7m2WAhLSQU,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk,knWHD3LBS2bqEjI9Gt4czTrMU67hC,gGWQzIiOHf7NwqsS,ZSYDsxg4t1QJG7frwiTly,jjf3OBNmukDdn5qLe,vvFxAOQDrWCUtjbHlg = gFdBaQ9bzKVRS[f3pCnmFaVYx4zc1MNGBe5]
		if f3pCnmFaVYx4zc1MNGBe5==pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧॸ"):
			KQV0YZeIuf = vuTHKR8XOry1aEF5P7m2WAhLSQU
			LnKt0qpTlBJ9 = oh1JUWa3LdnqTpz5(u"ࠪࠬࠬॹ")+lqMyFS6oN1V2BjGrEUAvxeLtRTgCk+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࠥ࠭ॺ")+kFhAce5Pz1(jjf3OBNmukDdn5qLe)+xmTX9Aeidq8cVhY(u"ࠬ࠯ࠧॻ")
			rhb9P0NwHA = gGWQzIiOHf7NwqsS
		elif f3pCnmFaVYx4zc1MNGBe5==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨॼ"):
			PvhwX21M0LV = PvhwX21M0LV or vuTHKR8XOry1aEF5P7m2WAhLSQU
			uFcEqXzUhna7Kft3CLPmAj += tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠡࠢ࠯ࠤࠥ࠮ࠧॽ")+lqMyFS6oN1V2BjGrEUAvxeLtRTgCk+pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠢࠪॾ")+kFhAce5Pz1(jjf3OBNmukDdn5qLe)+Yr0wo7FaSHx(u"ࠩࠬࠫॿ")
			VjIuD6veCMJ5O9wBUfKRPmAQF4E += G5TxeI0ND4ztC6(u"ࠪࠤࠥ࠲ࠠࠡࠩঀ")+gGWQzIiOHf7NwqsS
		elif f3pCnmFaVYx4zc1MNGBe5==b098bsyjUud(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪঁ"):
			pkgM6zuoLK0QvYWfaCNqV78Ih = vuTHKR8XOry1aEF5P7m2WAhLSQU
			xPnMKs0XhaqTtrR6oy7vbQ = Vt4ELHXZP6(u"ࠬ࠮ࠧং")+lqMyFS6oN1V2BjGrEUAvxeLtRTgCk+DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࠠࠨঃ")+kFhAce5Pz1(jjf3OBNmukDdn5qLe)+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠪࠩ঄")
			n8n2QCmGRKE9F4xWD6qjrA0 = gGWQzIiOHf7NwqsS
	uFcEqXzUhna7Kft3CLPmAj = uFcEqXzUhna7Kft3CLPmAj.strip(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࠢࠣ࠰ࠥࠦࠧঅ"))
	VjIuD6veCMJ5O9wBUfKRPmAQF4E = VjIuD6veCMJ5O9wBUfKRPmAQF4E.strip(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࠣࠤ࠱ࠦࠠࠨআ"))
	AqnfldksY2OgQtaEC  = KylMx0kfTOrG(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡษ็้ฯ๎แาࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪই")+rhb9P0NwHA+b46fBrugtPDSYspzMQIx(u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ঈ")
	AqnfldksY2OgQtaEC += u2NDjURZVHlmdc0(u"ࠬࡢ࡮ࠨউ")+DItWNMaLOZ146CubYk8lfAwTy(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆหี๋อๅอࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪঊ")+LnKt0qpTlBJ9+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩঋ")
	AqnfldksY2OgQtaEC += vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨ࡞ࡱࡠࡳ࠭ঌ")+KylMx0kfTOrG(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่ืฯ๎ฯฺࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ঍")+VjIuD6veCMJ5O9wBUfKRPmAQF4E+xmTX9Aeidq8cVhY(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ঎")
	AqnfldksY2OgQtaEC += KylMx0kfTOrG(u"ࠫࡡࡴࠧএ")+u2NDjURZVHlmdc0(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅ็ึฮํีูࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩঐ")+uFcEqXzUhna7Kft3CLPmAj+trSQHvP4aqBWFKxN5bZgXCu(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ঑")
	AqnfldksY2OgQtaEC += Vt4ELHXZP6(u"ࠧ࡝ࡰ࡟ࡲࠬ঒")+cg94WALw5orUhvtHSfNO(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧও")+n8n2QCmGRKE9F4xWD6qjrA0+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫঔ")
	AqnfldksY2OgQtaEC += xmTX9Aeidq8cVhY(u"ࠪࡠࡳ࠭ক")+VVtQk9vwe7(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧখ")+xPnMKs0XhaqTtrR6oy7vbQ+oh1JUWa3LdnqTpz5(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧগ")
	vuTHKR8XOry1aEF5P7m2WAhLSQU = (KQV0YZeIuf or PvhwX21M0LV)
	if vuTHKR8XOry1aEF5P7m2WAhLSQU:
		header = KylMx0kfTOrG(u"࠭วๅำฯหฦࠦสฮัํฯࠥหึศใสฮ้่ࠥะ์่ࠣา๊ࠠศๆุ่ฬ้ไࠨঘ")
		wfvQKiYRlFAtu1yco = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧศ่อࠤอำวอห่ࠣฯำฯ๋อࠣฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠨঙ")
	else:
		header = GVPK9Ziaho6U2ySLj(u"ࠨฯส่๏อࠠๅษࠣ๎ําฯࠡฬะำ๏ัวหࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡล๋ࠤู๊ส้ั฼ࠤ฾๋วะࠩচ")
		wfvQKiYRlFAtu1yco = b46fBrugtPDSYspzMQIx(u"ࠩส่ึาวยࠢศฬ้อฺࠡษ็้อืๅอࠢ฼๊ࠥอไๆึๆ่ฮࠦวๅฬํࠤฯ๎วอ้ๆࠫছ")
	qdK0TWlyLOho7gVMja62xnD = vdHRKkIgTp56Je1OuNo(u"่่ࠪ๐๋ࠠ฻่่ࠥ฿ๆะๅࠣห้ะอะ์ฮࠤฬ๊สๅไสส๏๊ࠦอสࠣว๋๊ࠦไ๊้ࠤ้ี๊ไࠢไ๎้่ࠥะ์࡟ࡲู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫজ")
	zrYOL3BnADKtljbhIC0i4Ep = AqnfldksY2OgQtaEC+b46fBrugtPDSYspzMQIx(u"ࠫࡡࡴ࡜࡯ࠩঝ")+wfvQKiYRlFAtu1yco+ebT9xRB63E(u"ࠬࡢ࡮࡝ࡰࠪঞ")+qdK0TWlyLOho7gVMja62xnD
	u59uk1YqFUTd(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡲࡪࡩ࡫ࡸࠬট"),header,zrYOL3BnADKtljbhIC0i4Ep,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪঠ"))
	return
def uuzerSw4k8bt3QKD9cAjhgBvPMim(showDialogs,KKwWxjqePpUB1TEo8gD):
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,VVtQk9vwe7(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫড"),xmTX9Aeidq8cVhY(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪঢ"))
	if showDialogs:
		HrdbGelK51WAuCZox2V()
		pZ4sfrO0W3SHGq()
	if KKwWxjqePpUB1TEo8gD:
		LaqMoTyPh6J8sDCAN5IljkQXG91gp(ebT9xRB63E(u"ࡈࡤࡰࡸ࡫ଜ"))
		FFpU5N620xDYhSXgObwQLBK8 = [u2NDjURZVHlmdc0(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨণ"),Wbwj0o5gsXQ8F2f(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪত"),u2NDjURZVHlmdc0(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧথ"),DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪদ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧধ")]
		for kSKH25ipR9 in FFpU5N620xDYhSXgObwQLBK8:
			llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk = V2VoDzGIJflYU(kSKH25ipR9,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡘࡷࡻࡥଞ"),VVtQk9vwe7(u"ࡉࡥࡱࡹࡥଝ"))
		SSrIWDelfMtNcUdzAkF(showDialogs)
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(C0CbfZuXJM(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬন"))
	return
def nNgI56u1qlQFoxM9DBYZbhcwKUf(mmYQvDwyxfqdFJCWk04glXpRLBu5hI=tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ঩"),showDialogs=GVPK9Ziaho6U2ySLj(u"࡙ࡸࡵࡦଟ")):
	PPiftToaU4hMWXsuyEgLzd = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(b098bsyjUud(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭প"))
	import json as aYhFKJupNC2ATLlXDqjc1SV6
	data = aYhFKJupNC2ATLlXDqjc1SV6.loads(PPiftToaU4hMWXsuyEgLzd)
	MfpvPB4o928xH13kt7ZgTa5b = data[oh1JUWa3LdnqTpz5(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫফ")][tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡼࡡ࡭ࡷࡨࠫব")]
	if wIqFesTOvYnu5S2dWfpBVC: MfpvPB4o928xH13kt7ZgTa5b = MfpvPB4o928xH13kt7ZgTa5b.encode(tvdQHb10PhNmuy6(u"࠭ࡵࡵࡨ࠻ࠫভ"))
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(G5TxeI0ND4ztC6(u"ࠧࠨম"),KylMx0kfTOrG(u"ࠨࠩয"),cg94WALw5orUhvtHSfNO(u"ࠩࠪর"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭঱"),A6Iyo7eXrq2RtMmDxWj(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩল")+MfpvPB4o928xH13kt7ZgTa5b+Wbwj0o5gsXQ8F2f(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧ঳")+mmYQvDwyxfqdFJCWk04glXpRLBu5hI+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠠภࠣࠪ঴"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=trSQHvP4aqBWFKxN5bZgXCu(u"࠷૓"): return GVPK9Ziaho6U2ySLj(u"ࡌࡡ࡭ࡵࡨଠ")
	llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7,dRknSHhj3N7tfTzsW8GMbUicxg = V2VoDzGIJflYU(mmYQvDwyxfqdFJCWk04glXpRLBu5hI,trSQHvP4aqBWFKxN5bZgXCu(u"ࡆࡢ࡮ࡶࡩଡ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࡆࡢ࡮ࡶࡩଡ"))
	if llC9WmbrAIgpzfi3n:
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(GVPK9Ziaho6U2ySLj(u"ࠧࠨ঵"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩশ"),Wbwj0o5gsXQ8F2f(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬষ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪฮ๊ะฺࠠ็็๎ฮࠦสฬสํฮࠥอไอๆาࠤฬ๊ฬะ์าࠤํํ่ࠡฮส๋ืࠦไๅษึฮำีวๆࠢ࠱ࠤุ๎แࠡ์อ้ࠥอไร่ࠣฮ฿๐๊าࠢศ฽ิอฯศฬࠣ็ํี๊ࠡๆๆ๎ࠥ๐ำห฻่่ࠥอไอๆาࠤฬ๊ฬะ์าࠤอีไศ่๊ࠢࠥอไใัํ้ࠬস"))
		o6olgEz21iJbqLsKhP = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(ebT9xRB63E(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦ࠱ࠨࡶࡢ࡮ࡸࡩࠧࡀࠢࠨহ")+mmYQvDwyxfqdFJCWk04glXpRLBu5hI+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࠨࡽࡾࠩ঺"))
		if vdHRKkIgTp56Je1OuNo(u"࠭ࡏࡌࠩ঻") in o6olgEz21iJbqLsKhP: llC9WmbrAIgpzfi3n = vlW6K1g8Xo35mPYbyO2GS(u"ࡕࡴࡸࡩଢ")
		Mrx2OeZV1LNjBsQ58Savi7.sleep(KylMx0kfTOrG(u"࠱૔"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡔࡧࡱࡨࡈࡲࡩࡤ࡭ࠫ࠵࠶࠯়ࠧ"))
	elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩঽ"),ebT9xRB63E(u"ࠩࠪা"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ি"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯ่ࠦหใ฼๎้ࠦวๅฮ็ำࠥอไๆู็์อ࠭ী"))
	return llC9WmbrAIgpzfi3n
def w2chBfzYG4FlZR7QIbJHTyoKrdv(f3pCnmFaVYx4zc1MNGBe5,showDialogs=GVPK9Ziaho6U2ySLj(u"ࡖࡵࡹࡪଣ")):
	if showDialogs==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬ࠭ু"): showDialogs = tvdQHb10PhNmuy6(u"ࡗࡶࡺ࡫ତ")
	QPUpA7KVc6 = O7WQ68ESFD([f3pCnmFaVYx4zc1MNGBe5])
	bu2wQtfjG54Z0ToLdIe,NokWRv1KFMgb60XuSTxYZHp = QPUpA7KVc6[f3pCnmFaVYx4zc1MNGBe5]
	if NokWRv1KFMgb60XuSTxYZHp:
		llC9WmbrAIgpzfi3n = DItWNMaLOZ146CubYk8lfAwTy(u"ࡘࡷࡻࡥଥ")
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Vt4ELHXZP6(u"࠭ࠧূ"),VVtQk9vwe7(u"ࠧࠨৃ"),u2NDjURZVHlmdc0(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫৄ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰࠣࠫ৅")+f3pCnmFaVYx4zc1MNGBe5+A6Iyo7eXrq2RtMmDxWj(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭৆"))
	else:
		llC9WmbrAIgpzfi3n = C0CbfZuXJM(u"ࡋࡧ࡬ࡴࡧଦ")
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(WfgnOq9Fd4lhMSQpK5(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫে"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠭ৈ"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧ৉"),KylMx0kfTOrG(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৊"),Wbwj0o5gsXQ8F2f(u"ࠨࠩো")+f3pCnmFaVYx4zc1MNGBe5+cg94WALw5orUhvtHSfNO(u"ࠩࠣࡠࡳࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤ๏฿ๅๅࠢส่อืๆศ็ฯࠤ฾์ฯไࠢหูํืษࠡืะ๎าฯࠠ࠯๊่ࠢࠥะั๋ัࠣฮะฮ๊ห๋ࠢฮๆ฿๊ๅ๊ࠢิ์ࠦวๅวูหๆฯࠠศๆล๊ࠥลࠧৌ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠲૕"):
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯্ࠪࠪ")+f3pCnmFaVYx4zc1MNGBe5+b46fBrugtPDSYspzMQIx(u"ࠫ࠮࠭ৎ"))
			Mrx2OeZV1LNjBsQ58Savi7.sleep(Wbwj0o5gsXQ8F2f(u"࠳૖"))
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡙ࠬࡥ࡯ࡦࡆࡰ࡮ࡩ࡫ࠩ࠳࠴࠭ࠬ৏"))
			Mrx2OeZV1LNjBsQ58Savi7.sleep(KylMx0kfTOrG(u"࠴૗"))
			while Wj3qSagkcweAb2prRiDyM0HK7Guo.getCondVisibility(CC4UDLW6brf(u"࠭ࡗࡪࡰࡧࡳࡼ࠴ࡉࡴࡃࡦࡸ࡮ࡼࡥࠩࡲࡵࡳ࡬ࡸࡥࡴࡵࡧ࡭ࡦࡲ࡯ࡨࠫࠪ৐")): Mrx2OeZV1LNjBsQ58Savi7.sleep(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵૘"))
			o6olgEz21iJbqLsKhP = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(KylMx0kfTOrG(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ৑")+f3pCnmFaVYx4zc1MNGBe5+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭৒"))
			if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࡒࡏࠬ৓") in o6olgEz21iJbqLsKhP:
				llC9WmbrAIgpzfi3n = GVPK9Ziaho6U2ySLj(u"࡚ࡲࡶࡧଧ")
				if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࠫ৔"),Vt4ELHXZP6(u"ࠫࠬ৕"),GVPK9Ziaho6U2ySLj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ৖"),G5TxeI0ND4ztC6(u"࠭สๆࠢไัฺࠦร้ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬৗ"))
			elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠨ৘"),Wbwj0o5gsXQ8F2f(u"ࠨࠩ৙"),CC4UDLW6brf(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৚"),vdHRKkIgTp56Je1OuNo(u"ࠪๅู๊ࠠโ์ࠣฮะฮ๊หࠢฦ์ࠥะแฺ์็ࠤศ๎ࠠหฯา๎ะࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠢ࠱ࠤํอไฮๆ๋ࠣํࠦสฬสํฮ์อ้ࠠฬไ฽๏๊็ศ่๊ࠢࠥิวาฮࠣห้ฮั็ษ่ะࠬ৛"))
	return llC9WmbrAIgpzfi3n
def vAHLu1xzPK9CSyQWET0jlFq(f3pCnmFaVYx4zc1MNGBe5,vvFxAOQDrWCUtjbHlg,showDialogs):
	llC9WmbrAIgpzfi3n = C0CbfZuXJM(u"ࡆࡢ࡮ࡶࡩନ")
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬড়"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠭ঢ়"),CC4UDLW6brf(u"࠭ࠧ৞"),A6Iyo7eXrq2RtMmDxWj(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪয়"),xmTX9Aeidq8cVhY(u"ࠨี๋ๅࠥ๐สๆࠢส่ว์ࠠอๆหࠤฬ๊ๅๅใࠣห้๋ึ฻ฺ๊ࠤ้๊ลืษไอࠥอไๆู็์อฯࠠๅๅํࠤ๏ะๅࠡฬฮฬ๏ะ็ࠡ฻็ํ้่ࠥะ์ࠣ࠲ࠥอไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠢ࠱ࠤ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣห้ศๆࠡมࠤࠫৠ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=VVtQk9vwe7(u"࠶૙"): return VVtQk9vwe7(u"ࡇࡣ࡯ࡷࡪ଩")
	EcCmRUhBNTGza5JKVel7t = jFfs5J7diIt68yb9mBSZ(vvFxAOQDrWCUtjbHlg,{},showDialogs)
	if EcCmRUhBNTGza5JKVel7t:
		u7yn9oXPSLOH4fzKlT0 = A73K6zLXIgFROeCHJQi0Pbos.path.join(I4D30chjOT,f3pCnmFaVYx4zc1MNGBe5)
		IN1vbO8YfAu05Qyi7jMVwkxSE(u7yn9oXPSLOH4fzKlT0,Wbwj0o5gsXQ8F2f(u"ࡗࡶࡺ࡫ଫ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࡈࡤࡰࡸ࡫ପ"))
		import zipfile as I2Ns3RWlzYpKLtj9MXD,io as u4dqopLC7hsAZNOjilRbX2fvUkQY3E
		gfFLhb3pHmot8V1lsQE = u4dqopLC7hsAZNOjilRbX2fvUkQY3E.BytesIO(EcCmRUhBNTGza5JKVel7t)
		try:
			bKcVCj0lA97MBEU1Ip8gYeu5xRDTo = I2Ns3RWlzYpKLtj9MXD.ZipFile(gfFLhb3pHmot8V1lsQE)
			bKcVCj0lA97MBEU1Ip8gYeu5xRDTo.extractall(I4D30chjOT)
			Mrx2OeZV1LNjBsQ58Savi7.sleep(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷૚"))
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(WfgnOq9Fd4lhMSQpK5(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ৡ"))
			Mrx2OeZV1LNjBsQ58Savi7.sleep(ebT9xRB63E(u"࠲૛"))
			o6olgEz21iJbqLsKhP = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ৢ")+f3pCnmFaVYx4zc1MNGBe5+trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩৣ"))
			if A6Iyo7eXrq2RtMmDxWj(u"ࠬࡕࡋࠨ৤") in o6olgEz21iJbqLsKhP: llC9WmbrAIgpzfi3n = WfgnOq9Fd4lhMSQpK5(u"ࡘࡷࡻࡥବ")
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,Vt4ELHXZP6(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ৥"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ০"))
		except: llC9WmbrAIgpzfi3n = A6Iyo7eXrq2RtMmDxWj(u"ࡋࡧ࡬ࡴࡧଭ")
	if showDialogs:
		if llC9WmbrAIgpzfi3n: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(A6Iyo7eXrq2RtMmDxWj(u"ࠨࠩ১"),VVtQk9vwe7(u"ࠩࠪ২"),u2NDjURZVHlmdc0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭৩"),b098bsyjUud(u"ࠫฯ๋ࠠษ่ฯหาࠦสฬสํฮࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษࠨ৪"))
		else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(KylMx0kfTOrG(u"ࠬ࠭৫"),DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࠧ৬"),Yr0wo7FaSHx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৭"),b098bsyjUud(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭৮"))
	return llC9WmbrAIgpzfi3n
def V2VoDzGIJflYU(f3pCnmFaVYx4zc1MNGBe5,showDialogs,pDO9xX62lAjLZdJVC):
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6,llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk = CC4UDLW6brf(u"ࡔࡳࡷࡨଯ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡌࡡ࡭ࡵࡨମ"),oh1JUWa3LdnqTpz5(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ৯"),VVtQk9vwe7(u"ࠪࠫৰ")
	gFdBaQ9bzKVRS = AwnlUgaf453N7P20([f3pCnmFaVYx4zc1MNGBe5])
	if f3pCnmFaVYx4zc1MNGBe5 in list(gFdBaQ9bzKVRS.keys()):
		vuTHKR8XOry1aEF5P7m2WAhLSQU,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk,knWHD3LBS2bqEjI9Gt4czTrMU67hC,gGWQzIiOHf7NwqsS,ZSYDsxg4t1QJG7frwiTly,jjf3OBNmukDdn5qLe,vvFxAOQDrWCUtjbHlg = gFdBaQ9bzKVRS[f3pCnmFaVYx4zc1MNGBe5]
		if jjf3OBNmukDdn5qLe==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫ࡬ࡵ࡯ࡥࠩৱ"):
			llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7 = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡕࡴࡸࡩର"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭৲")
			if pDO9xX62lAjLZdJVC: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧ৳"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠨ৴"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ৵"),VVtQk9vwe7(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦใ้ัํࠤ๏ูสฯั่ࠤศิัࠡวุำฬืࠠๆฬ๋ๅึࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦไ่า๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩ৶")+f3pCnmFaVYx4zc1MNGBe5)
		else:
			if showDialogs:
				if jjf3OBNmukDdn5qLe==WfgnOq9Fd4lhMSQpK5(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ৷"): Ay3eLGaTncD67lx8ZOud = DItWNMaLOZ146CubYk8lfAwTy(u"๊ࠫะ่ใใฬࠫ৸")
				elif jjf3OBNmukDdn5qLe==G5TxeI0ND4ztC6(u"ࠬࡵ࡬ࡥࠩ৹"): Ay3eLGaTncD67lx8ZOud = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭โะ์่อࠬ৺")
				elif jjf3OBNmukDdn5qLe==trSQHvP4aqBWFKxN5bZgXCu(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨ৻"): Ay3eLGaTncD67lx8ZOud = WfgnOq9Fd4lhMSQpK5(u"ࠨ฼ํี๋ࠥหษฬฬࠫৼ")
				J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(cg94WALw5orUhvtHSfNO(u"ࠩࠪ৽"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠫ৾"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࠬ৿"),Yr0wo7FaSHx(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ਀"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭็ั้ࠣห้หึศใฬࠤࠬਁ")+Ay3eLGaTncD67lx8ZOud+C0CbfZuXJM(u"ࠧࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢยࠥࡡࡴ࡜࡯ࠩਂ")+f3pCnmFaVYx4zc1MNGBe5)
			if not J1SavlWIe5EOAdVTQrfGYRhjo8KCw6: JoskwhMAXU2BQb5SGOLfIx7 = Wbwj0o5gsXQ8F2f(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪਃ")
			else:
				if jjf3OBNmukDdn5qLe==C0CbfZuXJM(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ਄"):
					mL7BVKcSygkuoPbWlEF4YD = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(Vt4ELHXZP6(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭ਅ")+f3pCnmFaVYx4zc1MNGBe5+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩਆ"))
					if b098bsyjUud(u"ࠬࡕࡋࠨਇ") in mL7BVKcSygkuoPbWlEF4YD:
						llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7 = A6Iyo7eXrq2RtMmDxWj(u"ࡖࡵࡹࡪ଱"),Vt4ELHXZP6(u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧਈ")
						if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(xmTX9Aeidq8cVhY(u"ࠧࠨਉ"),u2NDjURZVHlmdc0(u"ࠨࠩਊ"),Wbwj0o5gsXQ8F2f(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ਋"),CC4UDLW6brf(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨ਌")+f3pCnmFaVYx4zc1MNGBe5)
					elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࠬ਍"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠬ࠭਎"),VVtQk9vwe7(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਏ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่ส฼วโห้ࠣฯ๎โโหࠣ࠲࠳่ࠦๅ็ࠣ๎ุะื๋฻ࠣห้ฮั็ษ่ะࠥะิ฻์็๋ฬࡢ࡮࡝ࡰࠪਐ")+f3pCnmFaVYx4zc1MNGBe5)
				elif jjf3OBNmukDdn5qLe in [uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡱ࡯ࡨࠬ਑"),vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ਒")]:
					llC9WmbrAIgpzfi3n = vAHLu1xzPK9CSyQWET0jlFq(f3pCnmFaVYx4zc1MNGBe5,vvFxAOQDrWCUtjbHlg,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡉࡥࡱࡹࡥଲ"))
					if llC9WmbrAIgpzfi3n:
						if jjf3OBNmukDdn5qLe==u2NDjURZVHlmdc0(u"ࠪࡳࡱࡪࠧਓ"): JoskwhMAXU2BQb5SGOLfIx7 = KylMx0kfTOrG(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬਔ")
						elif jjf3OBNmukDdn5qLe==xmTX9Aeidq8cVhY(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ਕ"): JoskwhMAXU2BQb5SGOLfIx7 = oh1JUWa3LdnqTpz5(u"࠭ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩਖ")
						lqMyFS6oN1V2BjGrEUAvxeLtRTgCk = gGWQzIiOHf7NwqsS
						if showDialogs:
							if JoskwhMAXU2BQb5SGOLfIx7==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨਗ"): ArKbmeZFN7cRuvjfiHBJ0SEqd2l(u2NDjURZVHlmdc0(u"ࠨࠩਘ"),xmTX9Aeidq8cVhY(u"ࠩࠪਙ"),b46fBrugtPDSYspzMQIx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ਚ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨਛ")+f3pCnmFaVYx4zc1MNGBe5)
							elif JoskwhMAXU2BQb5SGOLfIx7==xmTX9Aeidq8cVhY(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨਜ"): ArKbmeZFN7cRuvjfiHBJ0SEqd2l(u2NDjURZVHlmdc0(u"࠭ࠧਝ"),cg94WALw5orUhvtHSfNO(u"ࠧࠨਞ"),GVPK9Ziaho6U2ySLj(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫਟ"),tvdQHb10PhNmuy6(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠๅ็ࠣฮ่์ࠠๆ๊ฯ์ิฯࠠโ์ࠣ็ํี๊ࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะหษ์อ๋ฬࡢ࡮࡝ࡰࠪਠ")+f3pCnmFaVYx4zc1MNGBe5)
					elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(KylMx0kfTOrG(u"ࠪࠫਡ"),GVPK9Ziaho6U2ySLj(u"ࠫࠬਢ"),tvdQHb10PhNmuy6(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨਣ"),Yr0wo7FaSHx(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦสฮัํฯࠥษ่ࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩਤ")+f3pCnmFaVYx4zc1MNGBe5)
	elif showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Yr0wo7FaSHx(u"ࠧࠨਥ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠩਦ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬਧ"),xmTX9Aeidq8cVhY(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์้ࠣํอโฺ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯࠰ࠣ์้ํะศࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠฤ่ࠣ๎็๎ๅࠡสอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࠦร้ࠢอัิ๐ห่ษ࡟ࡲࡡࡴࠧਨ")+f3pCnmFaVYx4zc1MNGBe5)
	return llC9WmbrAIgpzfi3n,JoskwhMAXU2BQb5SGOLfIx7,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk
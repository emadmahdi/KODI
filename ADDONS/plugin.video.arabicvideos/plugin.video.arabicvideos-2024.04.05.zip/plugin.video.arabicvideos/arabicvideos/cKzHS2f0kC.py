# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'CIMAABDO'
eMlwAzaLSj8ZEQ3txIGP = '_ABD_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['الرئيسية']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==550: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==551: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==552: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==553: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==559: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH+'/home','','','','','CIMAABDO-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(kU2ZXSViB3wLANOz8bH,'url')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',559,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'اخترنا لك',PeArnUDVym1pjBFaG+'/home',551,'','','featured')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-content(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('data-name="(.*?)".*?</i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for IOC7UWYc5MTHZbLx9VtXpn,title in items:
		wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/ajax/getItem?item='+IOC7UWYc5MTHZbLx9VtXpn+'&Ajax=1'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,551)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"nav-main"(.*?)</nav>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if wHiSfdBL1v9Kl3n5=='#': continue
		if title in eJzpdvc3KTust: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,551)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	for wHiSfdBL1v9Kl3n5,title in items:
		if wHiSfdBL1v9Kl3n5=='#': continue
		if title in eJzpdvc3KTust: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,551)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,IOC7UWYc5MTHZbLx9VtXpn=''):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = p2gG9rDHAXb7lYPvcMTa(url)
		JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','CIMAABDO-TITLES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = [YBEsLq8gVw629cMGQP1T]
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMAABDO-TITLES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		if IOC7UWYc5MTHZbLx9VtXpn=='featured':
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"container"(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		elif '"section-post mb-10"' in YBEsLq8gVw629cMGQP1T:
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"section-post mb-10"(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		else:
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<article(.*?)"pagination"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if not items:
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if not items: items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
		wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5).strip('/')
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
		if 'سلاسل' not in url and any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,552,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt and 'الحلقة' in title:
			title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,553,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif '/movies/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,551,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,553,ggdRiBo3smurLUGO)
	if IOC7UWYc5MTHZbLx9VtXpn=='':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination"(.*?)<footer',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if wHiSfdBL1v9Kl3n5=="": continue
				if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'هناك المزيد',url,551)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','CIMAABDO-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"getSeasonsBySeries(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"list-episodes"(.*?)"container"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vLlUHJTNWusr0IGRxY63gDPCet9 and '/series/' not in url:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,553,ggdRiBo3smurLUGO)
	elif ooTeU5chRPu:
		ggdRiBo3smurLUGO = JJDtX1PZyIgN2T.findall('"image" src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		ggdRiBo3smurLUGO = ggdRiBo3smurLUGO[0]
		mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,552,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace('/movies/','/watch_movies/')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.replace('/episodes/','/watch_episodes/')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','CIMAABDO-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'url')
	EEgFl59RndzrBL8TUoaQMw6P = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"servers"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		cKCInoAwzkR95WtXJdVUMGr = JJDtX1PZyIgN2T.findall('postID = "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		cKCInoAwzkR95WtXJdVUMGr = cKCInoAwzkR95WtXJdVUMGr[0]
		items = JJDtX1PZyIgN2T.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if items:
			for RgNSOU7P93n,title in items:
				title = title.replace('\n','').strip(' ')
				wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/ajax/getPlayer?server='+RgNSOU7P93n+'&postID='+cKCInoAwzkR95WtXJdVUMGr+'&Ajax=1'
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		else:
			items = JJDtX1PZyIgN2T.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for RgNSOU7P93n,ztnKf34Eu2xJZOgjWhGP6aoUI1BLA,title in items:
				title = title.replace('\n','').strip(' ')
				wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/ajax/getPlayerByName?server='+RgNSOU7P93n+'&multipleServers='+ztnKf34Eu2xJZOgjWhGP6aoUI1BLA+'&postID='+cKCInoAwzkR95WtXJdVUMGr+'&Ajax=1'
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"downs"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__download'
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','-')
	url = kU2ZXSViB3wLANOz8bH+'/search/'+search+'.html'
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
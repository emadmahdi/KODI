# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
from j8oSXm7wWg import *
FpjtBKrnu5SdfyOvEPIQ = G5TxeI0ND4ztC6(u"ࠫࡎࡔࡉࡕࠩ଺")
b6kj4LJ5tzTeOMQi(KylMx0kfTOrG(u"ࠬࡔࡏࡕࡋࡆࡉࠬ଻"),tvdQHb10PhNmuy6(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ଼࠭"))
sXPuroaMIYnl = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = sXPuroaMIYnl
ocq9aTtSF2 = int(rCBzYkXesGinqfjWdMJ0I6EuthRAg1)
MpTK2YaAjI4NWtiGcC3PQg = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨଽ"))
MpTK2YaAjI4NWtiGcC3PQg = MpTK2YaAjI4NWtiGcC3PQg.replace(ccdMiA5sZ0koIRwpFgeU8j,DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࠩା")).replace(SBPbYXN9Rt2MHDrnU4mhlV0,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࠪି"))
if ocq9aTtSF2==xmTX9Aeidq8cVhY(u"࠲࠷࠲୧"): hiDXjZaexOEKBd3U = VVtQk9vwe7(u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫୀ")+K0dHTfq6P73sD8lWLZpoh+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫୁ")+L2N3maPfeUCuG1rd4whqF+trSQHvP4aqBWFKxN5bZgXCu(u"ࠬࠦ࡝ࠨୂ")
else:
	zENXqCOpG4Bv5YZjfP = i35i6al7upCAreLFQ(QfEL1VroTPIFZkmzjv5O).replace(G5TxeI0ND4ztC6(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩୃ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࠨୄ")).replace(tvdQHb10PhNmuy6(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ୅"),vdHRKkIgTp56Je1OuNo(u"ࠩࠪ୆"))
	zENXqCOpG4Bv5YZjfP = zENXqCOpG4Bv5YZjfP.replace(G5TxeI0ND4ztC6(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬେ"),CC4UDLW6brf(u"ࠫࠬୈ")).strip(xmTX9Aeidq8cVhY(u"ࠬࠦࠧ୉"))
	zENXqCOpG4Bv5YZjfP = zENXqCOpG4Bv5YZjfP.replace(GVPK9Ziaho6U2ySLj(u"࠭ࠠࠡࠢࠣࠫ୊"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࠡࠩୋ")).replace(xmTX9Aeidq8cVhY(u"ࠨࠢࠣࠤࠬୌ"),pOIe6U1vWYC7Gh2udFBRgT(u"୍ࠩࠣࠫ")).replace(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠤࠥ࠭୎"),b46fBrugtPDSYspzMQIx(u"ࠫࠥ࠭୏"))
	hiDXjZaexOEKBd3U = WfgnOq9Fd4lhMSQpK5(u"ࠬࠦࠠࠡࡎࡤࡦࡪࡲ࠺ࠡ࡝ࠣࠫ୐")+MpTK2YaAjI4NWtiGcC3PQg+G5TxeI0ND4ztC6(u"࠭ࠠ࡞ࠢࠣࠤࡒࡵࡤࡦ࠼ࠣ࡟ࠥ࠭୑")+rCBzYkXesGinqfjWdMJ0I6EuthRAg1+vdHRKkIgTp56Je1OuNo(u"ࠧࠡ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ୒")+zENXqCOpG4Bv5YZjfP+pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠢࡠࠫ୓")
b6kj4LJ5tzTeOMQi(u2NDjURZVHlmdc0(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୔"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+hiDXjZaexOEKBd3U)
NfKOPmGr2StWoEdMaRI5euc4wqZ1 = BBwb2NzsHE.getSetting(ebT9xRB63E(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ୕"))
C6Csp0jDBaEKYAPZ5 = tvdQHb10PhNmuy6(u"ࡌࡡ࡭ࡵࡨ୭") if NfKOPmGr2StWoEdMaRI5euc4wqZ1==K0dHTfq6P73sD8lWLZpoh else YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࡙ࡸࡵࡦ୬")
if not C6Csp0jDBaEKYAPZ5 and ocq9aTtSF2 in [G5TxeI0ND4ztC6(u"࠳࠵࠸୨"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠹࠴࠹୩")]:
	W8U7yZeMX3owTiS5mDfJh = str(WFJYy6c9CKV4rdh27NjtILZ5HgRv[pOIe6U1vWYC7Gh2udFBRgT(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫୖ")])
	FpjtBKrnu5SdfyOvEPIQ = vdHRKkIgTp56Je1OuNo(u"ࠬ࡯ࡰࡵࡸࠪୗ") if ocq9aTtSF2==GVPK9Ziaho6U2ySLj(u"࠵࠷࠺୪") else tvdQHb10PhNmuy6(u"࠭࡭࠴ࡷࠪ୘")
	ASwKFJhGY15gO4tLTd6fN0M = BBwb2NzsHE.getSetting(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࡢࡸ࠱ࠫ୙")+FpjtBKrnu5SdfyOvEPIQ+KylMx0kfTOrG(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭୚")+W8U7yZeMX3owTiS5mDfJh)
	aCOI75DKgfuSq4xhojtPzBlYRQ = BBwb2NzsHE.getSetting(C0CbfZuXJM(u"ࠩࡤࡺ࠳࠭୛")+FpjtBKrnu5SdfyOvEPIQ+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ଡ଼")+W8U7yZeMX3owTiS5mDfJh)
	if ASwKFJhGY15gO4tLTd6fN0M or aCOI75DKgfuSq4xhojtPzBlYRQ:
		OG9Usa51Nk8D += hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࢁ࠭ଢ଼")
		if ASwKFJhGY15gO4tLTd6fN0M: OG9Usa51Nk8D += vlW6K1g8Xo35mPYbyO2GS(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ୞")+ASwKFJhGY15gO4tLTd6fN0M
		if aCOI75DKgfuSq4xhojtPzBlYRQ: OG9Usa51Nk8D += VVtQk9vwe7(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩୟ")+aCOI75DKgfuSq4xhojtPzBlYRQ
		OG9Usa51Nk8D = OG9Usa51Nk8D.replace(C0CbfZuXJM(u"ࠧࡽࠨࠪୠ"),u2NDjURZVHlmdc0(u"ࠨࡾࠪୡ"))
	mtbyRFuoa0NY5UqExc3pQX6nMzVAlP = BBwb2NzsHE.getSetting(b098bsyjUud(u"ࠩࡤࡺ࠳࠭ୢ")+FpjtBKrnu5SdfyOvEPIQ+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬୣ")+W8U7yZeMX3owTiS5mDfJh)
	if mtbyRFuoa0NY5UqExc3pQX6nMzVAlP:
		go6XpJPlv7ZMC = JJDtX1PZyIgN2T.findall(xmTX9Aeidq8cVhY(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧ୤"),OG9Usa51Nk8D,JJDtX1PZyIgN2T.DOTALL)
		OG9Usa51Nk8D = OG9Usa51Nk8D.replace(go6XpJPlv7ZMC[Wbwj0o5gsXQ8F2f(u"࠴୫")],mtbyRFuoa0NY5UqExc3pQX6nMzVAlP)
	FpjtBKrnu5SdfyOvEPIQ = FpjtBKrnu5SdfyOvEPIQ.upper()
	XbzQHGJ0cBV(OG9Usa51Nk8D,FpjtBKrnu5SdfyOvEPIQ,ajLz9PfYbTigyorvZhW4IOFn)
else:
	from wDd0v4uSOc import EYgQHCJOMW98Ps2wf,XXK8RxypkNAH2tgoq79mjICZ,pkUwtxcrGZDAyEn0SN9d6KRbugXY
	n6MNfIpoX7GgJZu = CC4UDLW6brf(u"ࠬ࠭୥")
	EYgQHCJOMW98Ps2wf(KylMx0kfTOrG(u"࠭ࡳࡵࡣࡵࡸࠬ୦"))
	try: XXK8RxypkNAH2tgoq79mjICZ(sXPuroaMIYnl,MpTK2YaAjI4NWtiGcC3PQg)
	except Exception as CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ: n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
	pkUwtxcrGZDAyEn0SN9d6KRbugXY(n6MNfIpoX7GgJZu)
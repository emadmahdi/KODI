# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'KATKOTTV'
eMlwAzaLSj8ZEQ3txIGP = '_KTV_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = []
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==810: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==811: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==812: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==813: mL7BVKcSygkuoPbWlEF4YD = ZZDjNmoAELWPYsVd4I(url)
	elif mode==819: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','KATKOTTV-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',819,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"primary-links"(.*?)"most-viewed"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if title in eJzpdvc3KTust: continue
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,811)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','KATKOTTV-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"home-content"(.*?)"footer"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		ClXwqHm0DEMvI39agWyiRYopQ = []
		for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|حلقة).\d+',title,JJDtX1PZyIgN2T.DOTALL)
			if 'episodes' not in type and vaQbluYS4GEsKCNwOymT1hFt:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0][0]
				title = title.replace('اون لاين','')
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,813,ggdRiBo3smurLUGO)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,812,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("'pagination'(.*?)footer",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,811,'','',type)
	return
def ZZDjNmoAELWPYsVd4I(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','KATKOTTV-SERIES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('"category".*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5: d2JXnUMPmgsKBQqCE58lkZ(wHiSfdBL1v9Kl3n5[0],'episodes')
	return
def CsUdRabWuh0M9F(url):
	pB8XANf71vaPJsedkWVIc5 = []
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'?do=watch'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','KATKOTTV-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('" src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','KATKOTTV-PLAY-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		EvutnH6GVfdhAk10g = JJDtX1PZyIgN2T.findall('post=(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if EvutnH6GVfdhAk10g:
			EvutnH6GVfdhAk10g = gPSZVjJHKIL.b64decode(EvutnH6GVfdhAk10g[0])
			if DQfHadYvTpy1UR: EvutnH6GVfdhAk10g = EvutnH6GVfdhAk10g.decode('utf8')
			EvutnH6GVfdhAk10g = G8EwoDOyKShm1i0IHMfNYZlU7('dict',EvutnH6GVfdhAk10g)
			kwqYoF8han = EvutnH6GVfdhAk10g['servers']
			FsBtqKUQXgMGWxTyrinfhjOev1 = list(kwqYoF8han.keys())
			kwqYoF8han = list(kwqYoF8han.values())
			v9c1sSyiJXU2lN7C = zip(FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han)
			for title,wHiSfdBL1v9Kl3n5 in v9c1sSyiJXU2lN7C:
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
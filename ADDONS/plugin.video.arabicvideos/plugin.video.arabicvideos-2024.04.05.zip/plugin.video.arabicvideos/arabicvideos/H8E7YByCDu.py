# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'EGYBESTVIP'
eMlwAzaLSj8ZEQ3txIGP = '_EGV_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,vYpMA3CxgcyR4VZJh,text):
	if   mode==220: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==221: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh)
	elif mode==222: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==223: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==224: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url)
	elif mode==229: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',229,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','EGYBEST-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="i i-home"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,222)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="ba(.*?)<script',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5 in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,221)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if 'html' not in wHiSfdBL1v9Kl3n5: continue
			if not wHiSfdBL1v9Kl3n5.endswith('/'): nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,221)
	return YBEsLq8gVw629cMGQP1T
def YsCotEfMBv03z7mg(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'','','','','EGYBESTVIP-SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="rs_scroll"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,224)
	return
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url):
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع',url,221)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'','','','EGYBESTVIP-FILTERS_MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="sub_nav(.*?)id="movies',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".+?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if wHiSfdBL1v9Kl3n5=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,221)
	else: d2JXnUMPmgsKBQqCE58lkZ(url)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh='1'):
	if vYpMA3CxgcyR4VZJh=='': vYpMA3CxgcyR4VZJh = '1'
	if '/search' in url or '?' in url: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url + '&'
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url + '?'
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO + 'page=' + vYpMA3CxgcyR4VZJh
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('class="pda"(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[-1]
	elif '/series/' in url:
		GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('class="owl-carousel owl-carousel(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	else:
		GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('id="movies(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[-1]
	items = JJDtX1PZyIgN2T.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if '/movie/' in wHiSfdBL1v9Kl3n5 or '/episode' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5.rstrip('/'),223,ggdRiBo3smurLUGO)
		else:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,221,ggdRiBo3smurLUGO)
	if len(items)>=16:
		wFRra4N9UhJTgfubtWx = ['/movies','/tv','/search','/trending']
		vYpMA3CxgcyR4VZJh = int(vYpMA3CxgcyR4VZJh)
		if any(Y3YqSmycrIWksoH5N0MvC in url for Y3YqSmycrIWksoH5N0MvC in wFRra4N9UhJTgfubtWx):
			for iuOoPVbnNT0zA4hkMY1f7r in range(0,1000,100):
				if int(vYpMA3CxgcyR4VZJh/100)*100==iuOoPVbnNT0zA4hkMY1f7r:
					for ggjo5zu7yCiIOhrb in range(iuOoPVbnNT0zA4hkMY1f7r,iuOoPVbnNT0zA4hkMY1f7r+100,10):
						if int(vYpMA3CxgcyR4VZJh/10)*10==ggjo5zu7yCiIOhrb:
							for xb3aVh0Z8wN1GlMuyqAHKI7t in range(ggjo5zu7yCiIOhrb,ggjo5zu7yCiIOhrb+10,1):
								if not vYpMA3CxgcyR4VZJh==xb3aVh0Z8wN1GlMuyqAHKI7t and xb3aVh0Z8wN1GlMuyqAHKI7t!=0:
									nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+str(xb3aVh0Z8wN1GlMuyqAHKI7t),url,221,'',str(xb3aVh0Z8wN1GlMuyqAHKI7t))
						elif ggjo5zu7yCiIOhrb!=0: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+str(ggjo5zu7yCiIOhrb),url,221,'',str(ggjo5zu7yCiIOhrb))
						else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+str(1),url,221,'',str(1))
				elif iuOoPVbnNT0zA4hkMY1f7r!=0: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+str(iuOoPVbnNT0zA4hkMY1f7r),url,221,'',str(iuOoPVbnNT0zA4hkMY1f7r))
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+str(1),url,221)
	return
def CsUdRabWuh0M9F(url):
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'','','','EGYBESTVIP-PLAY-1st')
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('<td>التصنيف</td>.*?">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1,ux2gEibkBjJQeWAPt3no = '',''
	Nufj0pEo4nzekaic738dWUI,ZZ3rUmJ2lD8W7Ox5gC0I = YBEsLq8gVw629cMGQP1T,YBEsLq8gVw629cMGQP1T
	V2rkIe1oGTdXEJfOjv4Sqyl3 = JJDtX1PZyIgN2T.findall('show_dl api" href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if V2rkIe1oGTdXEJfOjv4Sqyl3:
		for wHiSfdBL1v9Kl3n5 in V2rkIe1oGTdXEJfOjv4Sqyl3:
			if '/watch/' in wHiSfdBL1v9Kl3n5: j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1 = wHiSfdBL1v9Kl3n5
			elif '/download/' in wHiSfdBL1v9Kl3n5: ux2gEibkBjJQeWAPt3no = wHiSfdBL1v9Kl3n5
		if j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1!='': Nufj0pEo4nzekaic738dWUI = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1,'','','','EGYBESTVIP-PLAY-2nd')
		if ux2gEibkBjJQeWAPt3no!='': ZZ3rUmJ2lD8W7Ox5gC0I = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,ux2gEibkBjJQeWAPt3no,'','','','EGYBESTVIP-PLAY-3rd')
	MGqbtJx1dLVi9uY35eDOHlhyEwW2 = JJDtX1PZyIgN2T.findall('id="video".*?data-src="(.*?)"',Nufj0pEo4nzekaic738dWUI,JJDtX1PZyIgN2T.DOTALL)
	if MGqbtJx1dLVi9uY35eDOHlhyEwW2:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = MGqbtJx1dLVi9uY35eDOHlhyEwW2[0]
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO!='' and 'uploaded.egybest.download' in FrC9LhHZWIySdGwNsuzqt5Rf01TXO and '/?id=_' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			Plj7MGOHohwdvam2ynfVY1z = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','EGYBESTVIP-PLAY-4th')
			H0Oc7mlfgeALFn4JVqj = JJDtX1PZyIgN2T.findall('source src="(.*?)" title="(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if H0Oc7mlfgeALFn4JVqj:
				for wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 in H0Oc7mlfgeALFn4JVqj:
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5+'?named=ed.egybest.do__watch__mp4__'+y2nBfLCjDoXkKiwb8WV6)
			else:
				RgNSOU7P93n = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('/')[2]
				EEgFl59RndzrBL8TUoaQMw6P.append(FrC9LhHZWIySdGwNsuzqt5Rf01TXO+'?named='+RgNSOU7P93n+'__watch')
		elif FrC9LhHZWIySdGwNsuzqt5Rf01TXO!='':
			RgNSOU7P93n = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split('/')[2]
			EEgFl59RndzrBL8TUoaQMw6P.append(FrC9LhHZWIySdGwNsuzqt5Rf01TXO+'?named='+RgNSOU7P93n+'__watch')
	LMdqx5EtUnwbYZSylimu19BVXQ0fv = JJDtX1PZyIgN2T.findall('<table class="dls_table(.*?)</table>',ZZ3rUmJ2lD8W7Ox5gC0I,JJDtX1PZyIgN2T.DOTALL)
	if LMdqx5EtUnwbYZSylimu19BVXQ0fv:
		LMdqx5EtUnwbYZSylimu19BVXQ0fv = LMdqx5EtUnwbYZSylimu19BVXQ0fv[0]
		bbg43WJEsMNtq = JJDtX1PZyIgN2T.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',LMdqx5EtUnwbYZSylimu19BVXQ0fv,JJDtX1PZyIgN2T.DOTALL)
		if bbg43WJEsMNtq:
			for y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5 in bbg43WJEsMNtq:
				if 'myegyvip' not in wHiSfdBL1v9Kl3n5: continue
				if wHiSfdBL1v9Kl3n5.count('/')>=2:
					RgNSOU7P93n = wHiSfdBL1v9Kl3n5.split('/')[2]
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__download__mp4__'+y2nBfLCjDoXkKiwb8WV6)
	xjTiJEd9gz2HlwDpIe3 = []
	for wHiSfdBL1v9Kl3n5 in EEgFl59RndzrBL8TUoaQMw6P:
		xjTiJEd9gz2HlwDpIe3.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(xjTiJEd9gz2HlwDpIe3,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(mjBa0HgvKnI4oWRd,kU2ZXSViB3wLANOz8bH,'','','','EGYBESTVIP-SEARCH-1st')
	BB0MgRSFCf5k6xyH4hLam = JJDtX1PZyIgN2T.findall('name="_token" value="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if BB0MgRSFCf5k6xyH4hLam:
		url = kU2ZXSViB3wLANOz8bH+'/search?_token='+BB0MgRSFCf5k6xyH4hLam[0]+'&q='+s2hzmL48wFudNE5
		d2JXnUMPmgsKBQqCE58lkZ(url)
	return
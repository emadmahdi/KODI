# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'EGYBEST3'
eMlwAzaLSj8ZEQ3txIGP = '_EB3_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def HYWukw3pL2oMzPK4(mode,url,vYpMA3CxgcyR4VZJh,text):
	if   mode==790: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==791: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh)
	elif mode==792: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==793: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==796: mL7BVKcSygkuoPbWlEF4YD = gaJo6Sm8HMP2jKrnBd(url,vYpMA3CxgcyR4VZJh)
	elif mode==799: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','EGYBEST3-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('list-pages(.*?)fa-folder',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-article(.*?)social-box',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('main-title.*?">(.*?)<.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5 in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791,'','mainmenu')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-menu(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791)
	return YBEsLq8gVw629cMGQP1T
def gaJo6Sm8HMP2jKrnBd(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST3-SEASONS_EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-article".*?">(.*?)<(.*?)article',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME,items = '','',[]
		for name,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			if 'حلقات' in name: l7PwAhTqWVUKME = mvgk7pP8Fw6heMSWd5oXn9itl
			if 'مواسم' in name: YbPTE4rKt3cmIuz6WFdi = mvgk7pP8Fw6heMSWd5oXn9itl
		if YbPTE4rKt3cmIuz6WFdi and not type:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',YbPTE4rKt3cmIuz6WFdi,JJDtX1PZyIgN2T.DOTALL)
			if len(items)>1:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,796,ggdRiBo3smurLUGO,'season')
		if l7PwAhTqWVUKME and len(items)<2:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
			if items:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,793,ggdRiBo3smurLUGO)
			else:
				items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,793)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	ePYyKi25Bz3ZUWJtg0Ec,start,pnF0HTjGdfAleEZ4hRYwS,select,XlxyTN169IVSM0d8pGObBYuihr4H = 0,0,'','',''
	if 'pagination' in type:
		kuzMYsL84xH3lbUhc,data = p2gG9rDHAXb7lYPvcMTa(url)
		ePYyKi25Bz3ZUWJtg0Ec = int(data['limit'])
		start = int(data['start'])
		pnF0HTjGdfAleEZ4hRYwS = data['type']
		select = data['select']
		Gv7mT0LhB9YoOVpANMr = 'limit='+str(ePYyKi25Bz3ZUWJtg0Ec)+'&start='+str(start)+'&type='+pnF0HTjGdfAleEZ4hRYwS+'&select='+select
		JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',kuzMYsL84xH3lbUhc,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','EGYBEST3-TITLES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		Plj7MGOHohwdvam2ynfVY1z = 'blocks'+YBEsLq8gVw629cMGQP1T+'article'
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST3-TITLES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		Plj7MGOHohwdvam2ynfVY1z = YBEsLq8gVw629cMGQP1T
		code = JJDtX1PZyIgN2T.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if code:
			code = code[0].replace('var','').replace(' ','').replace("'",'').replace(';','&')
			g5lf2u4DxNp8imnYevK,data = p2gG9rDHAXb7lYPvcMTa('?'+code)
			ePYyKi25Bz3ZUWJtg0Ec = int(data['limit'])
			start = int(data['start'])
			pnF0HTjGdfAleEZ4hRYwS = data['type']
			select = data['select']
			XlxyTN169IVSM0d8pGObBYuihr4H = data['ajaxurl']
			Gv7mT0LhB9YoOVpANMr = 'limit='+str(ePYyKi25Bz3ZUWJtg0Ec)+'&start='+str(start)+'&type='+pnF0HTjGdfAleEZ4hRYwS+'&select='+select
			kuzMYsL84xH3lbUhc = kU2ZXSViB3wLANOz8bH+XlxyTN169IVSM0d8pGObBYuihr4H
			JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded'}
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',kuzMYsL84xH3lbUhc,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','EGYBEST3-TITLES-3rd')
			Plj7MGOHohwdvam2ynfVY1z = SSzrgUnfVGL1hQsu40FoP7CWXax.content
			Plj7MGOHohwdvam2ynfVY1z = 'blocks'+Plj7MGOHohwdvam2ynfVY1z+'article'
	items,NbI4DJ3rWOwRj,t9hx8YmpUDaFivZ = [],False,False
	if not type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-content(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791,'','submenu')
				NbI4DJ3rWOwRj = True
	if not type:
		t9hx8YmpUDaFivZ = YXDbNkC5xlWPI9anAOsr6uZ(YBEsLq8gVw629cMGQP1T)
	if not NbI4DJ3rWOwRj and not t9hx8YmpUDaFivZ:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('blocks(.*?)article',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.strip('\n')
				wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
				if '/selary/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791,ggdRiBo3smurLUGO)
				elif 'مسلسل' in wHiSfdBL1v9Kl3n5 and 'حلقة' not in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,796,ggdRiBo3smurLUGO)
				elif 'موسم' in wHiSfdBL1v9Kl3n5 and 'حلقة' not in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,796,ggdRiBo3smurLUGO)
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,793,ggdRiBo3smurLUGO)
		nfgR1P5HLpqdvoUl2Z = 12
		data = JJDtX1PZyIgN2T.findall('class="(load-more.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if len(items)==nfgR1P5HLpqdvoUl2Z and (data or 'pagination' in type):
			Gv7mT0LhB9YoOVpANMr = 'limit='+str(nfgR1P5HLpqdvoUl2Z)+'&start='+str(start+nfgR1P5HLpqdvoUl2Z)+'&type='+pnF0HTjGdfAleEZ4hRYwS+'&select='+select
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kuzMYsL84xH3lbUhc+'?next=page&'+Gv7mT0LhB9YoOVpANMr
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المزيد',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,791,'','pagination_'+type)
	return
def YXDbNkC5xlWPI9anAOsr6uZ(YBEsLq8gVw629cMGQP1T):
	t9hx8YmpUDaFivZ = False
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-article(.*?)article',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if Ns3LKUFY21aQVf7e: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
		for qGsE8fdyFtUwBnu,name,mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
			name = name.strip(' ')
			items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,Y3YqSmycrIWksoH5N0MvC in items:
				title = name+':  '+Y3YqSmycrIWksoH5N0MvC
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,791,'','filter')
				t9hx8YmpUDaFivZ = True
	return t9hx8YmpUDaFivZ
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'','','','','EGYBEST3-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	pB8XANf71vaPJsedkWVIc5,uiUZAmal9HPqQSo = [],[]
	items = JJDtX1PZyIgN2T.findall('server-item.*?data-code="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for ssVDJcjMaZ in items:
		WM8jOU6DXfQ = gPSZVjJHKIL.b64decode(ssVDJcjMaZ)
		if DQfHadYvTpy1UR: WM8jOU6DXfQ = WM8jOU6DXfQ.decode('utf8')
		wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('src="(.*?)"',WM8jOU6DXfQ,JJDtX1PZyIgN2T.DOTALL)
		if wHiSfdBL1v9Kl3n5:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
			if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
				uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
				RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__watch')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="downloads(.*?)</section>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5 in items:
			if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
				if '/?url=' in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('/?url=')[1]
				uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
				RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__download____'+y2nBfLCjDoXkKiwb8WV6)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(text):
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
headers = { 'User-Agent' : '' }
FpjtBKrnu5SdfyOvEPIQ = 'AKOAM'
eMlwAzaLSj8ZEQ3txIGP = '_AKO_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
BvFOwneAZLjlQ5pPzJI = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==70: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==71: mL7BVKcSygkuoPbWlEF4YD = RuCt2Y0yFKScH7zdgIvA4maEVZ3eq(url)
	elif mode==72: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==73: mL7BVKcSygkuoPbWlEF4YD = dd0BUNE8YLyRtxD4TwaMbpsgcHqGnh(url)
	elif mode==74: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==79: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',79,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'سلسلة افلام','',79,'','','سلسلة افلام')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'سلاسل منوعة','',79,'','','سلسلة')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	eJzpdvc3KTust = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','AKOAM-MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="partions"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title not in eJzpdvc3KTust:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,71)
	return YBEsLq8gVw629cMGQP1T
def RuCt2Y0yFKScH7zdgIvA4maEVZ3eq(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,'','AKOAM-CATEGORIES-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('sect_parts(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,72)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'جميع الفروع',url,72)
	else: d2JXnUMPmgsKBQqCE58lkZ(url,'')
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('section_title featured_title(.*?)subjects-crousel',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	elif type=='search':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('akoam_result(.*?)<script',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	elif type=='more':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('section_title more_title(.*?)footer_bottom_services',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('navigation(.*?)<script',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not items and GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace('\n','').strip(' ')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in BvFOwneAZLjlQ5pPzJI): nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,73,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,73,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall("</li><li >.*?href='(.*?)'>(.*?)<",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,72,'','',type)
	return
def Rj9yQgDwHkh4IXSb1Zld(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,True,'AKOAM-SECTIONS-2nd')
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('"href","(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[1]
	return FrC9LhHZWIySdGwNsuzqt5Rf01TXO
def dd0BUNE8YLyRtxD4TwaMbpsgcHqGnh(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,True,'AKOAM-SECTIONS-1st')
	bckINREw4SWzFgQ = JJDtX1PZyIgN2T.findall('"(https*://akwam.net/\w+.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	UUnk6yMuQLOfsAYpJHXSd5lc13P = JJDtX1PZyIgN2T.findall('"(https*://underurl.com/\w+.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if bckINREw4SWzFgQ or UUnk6yMuQLOfsAYpJHXSd5lc13P:
		if bckINREw4SWzFgQ: kHWT0XY2S6apruwxiB8FDl1 = bckINREw4SWzFgQ[0]
		elif UUnk6yMuQLOfsAYpJHXSd5lc13P: kHWT0XY2S6apruwxiB8FDl1 = Rj9yQgDwHkh4IXSb1Zld(UUnk6yMuQLOfsAYpJHXSd5lc13P[0])
		kHWT0XY2S6apruwxiB8FDl1 = i35i6al7upCAreLFQ(kHWT0XY2S6apruwxiB8FDl1)
		import MoLGRCrH0B
		if '/series/' in kHWT0XY2S6apruwxiB8FDl1 or '/shows/' in kHWT0XY2S6apruwxiB8FDl1: MoLGRCrH0B.sjmSkpqHVtPcv(kHWT0XY2S6apruwxiB8FDl1)
		else: MoLGRCrH0B.CsUdRabWuh0M9F(kHWT0XY2S6apruwxiB8FDl1)
		return
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	items = JJDtX1PZyIgN2T.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,73)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC:
		sdJ1cr6xmpoASuhlqjXi3K7eR8kP0('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,ggdRiBo3smurLUGO,mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	name = name.strip(' ')
	if 'sub_epsiode_title' in mvgk7pP8Fw6heMSWd5oXn9itl:
		items = JJDtX1PZyIgN2T.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	else:
		JvVtNT4lRH9cES58qQij3Wpk = JJDtX1PZyIgN2T.findall('sub_file_title\'>(.*?) - <i>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		items = []
		for filename in JvVtNT4lRH9cES58qQij3Wpk:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل','') ]
	count = 0
	JCop4mjTiurYB7W,rVJvU0HLFaM72z3IKCEnpBGsh = [],[]
	size = len(items)
	for title,filename in items:
		ohCurPI3fkJGw8jB09n5Q1lHUvzETL = ''
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: ohCurPI3fkJGw8jB09n5Q1lHUvzETL = filename.split('.')[-1]
		title = title.replace('\n','').strip(' ')
		JCop4mjTiurYB7W.append(title)
		rVJvU0HLFaM72z3IKCEnpBGsh.append(count)
		count += 1
	if size>0:
		if any(Y3YqSmycrIWksoH5N0MvC in name for Y3YqSmycrIWksoH5N0MvC in BvFOwneAZLjlQ5pPzJI):
			if size==1:
				zKgFfQoODy90ewYb5jGElUJRVs4p = 0
			else:
				zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الفيديو المناسب:', JCop4mjTiurYB7W)
				if zKgFfQoODy90ewYb5jGElUJRVs4p == -1: return
			CsUdRabWuh0M9F(url+'?section='+str(1+rVJvU0HLFaM72z3IKCEnpBGsh[size-zKgFfQoODy90ewYb5jGElUJRVs4p-1]))
		else:
			for ggjo5zu7yCiIOhrb in reversed(range(size)):
				title = name + ' - ' + JCop4mjTiurYB7W[ggjo5zu7yCiIOhrb]
				title = title.replace('\n','').strip(' ')
				wHiSfdBL1v9Kl3n5 = url + '?section='+str(size-ggjo5zu7yCiIOhrb)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,74,ggdRiBo3smurLUGO)
	else:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+'الرابط ليس فيديو','',9999,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,vaQbluYS4GEsKCNwOymT1hFt = url.split('?section=')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,True,'','AKOAM-PLAY_AKOAM-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	UDkVXAKjTQ0SnP = GGbRgKaoskDC[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	UDkVXAKjTQ0SnP = UDkVXAKjTQ0SnP + 'direct_link_box'
	Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('epsoide_box(.*?)direct_link_box',UDkVXAKjTQ0SnP,JJDtX1PZyIgN2T.DOTALL)
	vaQbluYS4GEsKCNwOymT1hFt = len(Ns3LKUFY21aQVf7e)-int(vaQbluYS4GEsKCNwOymT1hFt)
	mvgk7pP8Fw6heMSWd5oXn9itl = Ns3LKUFY21aQVf7e[vaQbluYS4GEsKCNwOymT1hFt]
	pB8XANf71vaPJsedkWVIc5 = []
	WySp7QDm3ZwudHa = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = JJDtX1PZyIgN2T.findall("class='download_btn.*?href='(.*?)'",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5 in items:
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named=________akoam')
	items = JJDtX1PZyIgN2T.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for RjYbUO4yGmNd8Ao71Fkv,wHiSfdBL1v9Kl3n5 in items:
		RjYbUO4yGmNd8Ao71Fkv = RjYbUO4yGmNd8Ao71Fkv.split('/')[-1]
		RjYbUO4yGmNd8Ao71Fkv = RjYbUO4yGmNd8Ao71Fkv.split('.')[0]
		if RjYbUO4yGmNd8Ao71Fkv in WySp7QDm3ZwudHa:
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+WySp7QDm3ZwudHa[RjYbUO4yGmNd8Ao71Fkv]+'________akoam')
		else: pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RjYbUO4yGmNd8Ao71Fkv+'________akoam')
	if not pB8XANf71vaPJsedkWVIc5:
		message = JJDtX1PZyIgN2T.findall('sub-no-file.*?\n(.*?)\n',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if message: ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من الموقع الاصلي',message[0])
	else:
		import jfGcn9x8KN
		jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	s2hzmL48wFudNE5 = search.replace(' ','%20')
	url = kU2ZXSViB3wLANOz8bH + '/search/'+s2hzmL48wFudNE5
	mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
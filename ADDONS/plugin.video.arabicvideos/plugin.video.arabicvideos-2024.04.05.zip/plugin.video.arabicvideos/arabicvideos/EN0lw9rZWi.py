# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SHIAVOICE'
eMlwAzaLSj8ZEQ3txIGP = '_SHV_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
headers = {'User-Agent':None}
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==310: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==311: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==312: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==313: mL7BVKcSygkuoPbWlEF4YD = ZaWHpcOKsqD39(url)
	elif mode==314: mL7BVKcSygkuoPbWlEF4YD = bX4pueFyDgAm3SJOx5(text)
	elif mode==319: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',319,'','','_REMEMBERRESULTS_')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','SHIAVOICE-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="menulinks"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = JJDtX1PZyIgN2T.findall('<h5>(.*?)</h5>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	for ZxtmiwJ4zPKpU6VkCAn in range(len(items)):
		title = items[ZxtmiwJ4zPKpU6VkCAn].strip(' ')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,kU2ZXSViB3wLANOz8bH,314,'','',str(ZxtmiwJ4zPKpU6VkCAn+1))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مقاطع شهر',kU2ZXSViB3wLANOz8bH,314,'','','0')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<B>(.*?)</B>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,311)
	return YBEsLq8gVw629cMGQP1T
def bX4pueFyDgAm3SJOx5(ZxtmiwJ4zPKpU6VkCAn):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,'','','','','SHIAVOICE-LATEST-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if ZxtmiwJ4zPKpU6VkCAn=='0':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="tab-content"(.*?)</table>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312)
	elif ZxtmiwJ4zPKpU6VkCAn in ['1','2','3']:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(<h5>.*?)<div class="col-lg',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		JaZ9NlmDEYB0 = int(ZxtmiwJ4zPKpU6VkCAn)-1
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[JaZ9NlmDEYB0]
		if ZxtmiwJ4zPKpU6VkCAn=='1': items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		else: items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title,name in items:
			ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title.strip(' ')
			name = name.strip(' ')
			title = title+' ('+name+')'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,311,ggdRiBo3smurLUGO)
	elif ZxtmiwJ4zPKpU6VkCAn in ['4','5','6']:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('(<h5>.*?)</table>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		ZxtmiwJ4zPKpU6VkCAn = int(ZxtmiwJ4zPKpU6VkCAn)-4
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[ZxtmiwJ4zPKpU6VkCAn]
		items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,GTatBJjWw7qsmAXOv,title,XUj8uOQAJ6pBCitZ4Te in items:
			ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title.strip(' ')
			GTatBJjWw7qsmAXOv = GTatBJjWw7qsmAXOv.strip(' ')
			XUj8uOQAJ6pBCitZ4Te = XUj8uOQAJ6pBCitZ4Te.strip(' ')
			if GTatBJjWw7qsmAXOv: name = GTatBJjWw7qsmAXOv
			else: name = XUj8uOQAJ6pBCitZ4Te
			title = title+' ('+name+')'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312,ggdRiBo3smurLUGO)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHIAVOICE-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('ibox-heading"(.*?)class="float-right',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	if 'catsum-mobile' in mvgk7pP8Fw6heMSWd5oXn9itl:
		items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if items:
			for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title,count in items:
				ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
				wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
				count = count.replace(' الصوتية: ',':')
				title = title.strip(' ')
				title = title+' ('+count+')'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,311,ggdRiBo3smurLUGO)
	else:
		items = JJDtX1PZyIgN2T.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title,kbGx5gnp4itWfOwsFTHDruZX0B3EJ,hhCd56yES0cqfUKRsZaVI4wzWuTO in items:
			if title=='' or kbGx5gnp4itWfOwsFTHDruZX0B3EJ=='': continue
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title+' ('+hhCd56yES0cqfUKRsZaVI4wzWuTO+')'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312)
	if not items: sjmSkpqHVtPcv(YBEsLq8gVw629cMGQP1T)
	return
def sjmSkpqHVtPcv(YBEsLq8gVw629cMGQP1T):
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="ibox-content"(.*?)class="pagination',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title,name,count,hhCd56yES0cqfUKRsZaVI4wzWuTO in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
		title = title.strip(' ')
		name = name.strip(' ')
		title = title+' ('+name+')'
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312,'',hhCd56yES0cqfUKRsZaVI4wzWuTO)
	return
def ZaWHpcOKsqD39(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHIAVOICE-SEARCH_ITEMS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="ibox-content p-1"(.*?)class="ibox-content"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC:
		d2JXnUMPmgsKBQqCE58lkZ(url)
		return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<strong>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
		title = title.strip(' ')
		if '/play-' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,311)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','SHIAVOICE-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<audio.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<video.*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5[0]
	XbzQHGJ0cBV(wHiSfdBL1v9Kl3n5,FpjtBKrnu5SdfyOvEPIQ,'video')
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	LLDuNRxv4s2CyPI = ['&t=a','&t=c','&t=s']
	if showDialogs:
		oQIFjBzx8nfEA3gKv0h4slJeDRTC = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('موقع صوت الشيعة - أختر البحث', oQIFjBzx8nfEA3gKv0h4slJeDRTC)
		if zKgFfQoODy90ewYb5jGElUJRVs4p == -1: return
	elif '_SHIAVOICE-PERSONS_' in sdZQpO06qbHwAGPz7LCgu4lToE: zKgFfQoODy90ewYb5jGElUJRVs4p = 0
	elif '_SHIAVOICE-ALBUMS_' in sdZQpO06qbHwAGPz7LCgu4lToE: zKgFfQoODy90ewYb5jGElUJRVs4p = 1
	elif '_SHIAVOICE-AUDIOS_' in sdZQpO06qbHwAGPz7LCgu4lToE: zKgFfQoODy90ewYb5jGElUJRVs4p = 2
	else: return
	type = LLDuNRxv4s2CyPI[zKgFfQoODy90ewYb5jGElUJRVs4p]
	url = kU2ZXSViB3wLANOz8bH+'/search.php?q='+search+type
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHIAVOICE-SEARCH-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="ibox-content"(.*?)class="ibox-content"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		if zKgFfQoODy90ewYb5jGElUJRVs4p in [0,1]:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,313,ggdRiBo3smurLUGO)
		elif zKgFfQoODy90ewYb5jGElUJRVs4p==2:
			items = JJDtX1PZyIgN2T.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title,name in items:
				title = title.strip(' ')
				name = name.strip(' ')
				title = title+' ('+name+')'
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,312)
	return
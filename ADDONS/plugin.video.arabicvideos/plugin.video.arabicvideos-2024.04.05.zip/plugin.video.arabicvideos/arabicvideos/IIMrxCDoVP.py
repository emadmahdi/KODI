# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SERIES4WATCH'
headers = { 'User-Agent' : '' }
eMlwAzaLSj8ZEQ3txIGP = '_SFW_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==210: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==211: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==212: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==213: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==214: mL7BVKcSygkuoPbWlEF4YD = wMKlyv6cE1Rf(url)
	elif mode==215: mL7BVKcSygkuoPbWlEF4YD = TTEt1vmVzxq(url)
	elif mode==218: mL7BVKcSygkuoPbWlEF4YD = vvluIPrLTh5MEBiCHNmy62()
	elif mode==219: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def vvluIPrLTh5MEBiCHNmy62():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',219,'','','_REMEMBERRESULTS_')
	url = kU2ZXSViB3wLANOz8bH+'/getpostsPin?type=one&data=pin&limit=25'
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المميزة',url,211)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,kU2ZXSViB3wLANOz8bH,'',headers,'','SERIES4WATCH-MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('FiltersButtons(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('data-get="(.*?)".*?</i>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		url = kU2ZXSViB3wLANOz8bH+'/getposts?type=one&data='+wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,url,211)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('navigation-menu(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(http.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	eJzpdvc3KTust = ['مسلسلات انمي','الرئيسية']
	for wHiSfdBL1v9Kl3n5,title in items:
		title = title.strip(' ')
		if not any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,211)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('MediaGrid"(.*?)class="pagination"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		else: return
	items = JJDtX1PZyIgN2T.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	qqMcamz27wdPHLID = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		if '/series/' in wHiSfdBL1v9Kl3n5: continue
		wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5).strip('/')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		title = title.strip(' ')
		if '/film/' in wHiSfdBL1v9Kl3n5 or any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in qqMcamz27wdPHLID):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,212,ggdRiBo3smurLUGO)
		elif '/episode/' in wHiSfdBL1v9Kl3n5 and 'الحلقة' in title:
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if vaQbluYS4GEsKCNwOymT1hFt:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,213,ggdRiBo3smurLUGO)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,213,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = jbigKDeUf0OSMrRkly2B5I3Act(wHiSfdBL1v9Kl3n5)
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = title.replace('الصفحة ','')
			if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,211)
	return
def sjmSkpqHVtPcv(url):
	CRBMqtF3pNy509XzY17Ue,items,GiMNQxDjEY79dlmSOqXah6wZFtPVK = -1,[],[]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'',headers,'','SERIES4WATCH-EPISODES-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('ti-list-numbered(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		Ns3LKUFY21aQVf7e = ''.join(GGbRgKaoskDC)
		items = JJDtX1PZyIgN2T.findall('href="(.*?)"',Ns3LKUFY21aQVf7e,JJDtX1PZyIgN2T.DOTALL)
	items.append(url)
	items = set(items)
	for wHiSfdBL1v9Kl3n5 in items:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.strip('/')
		title = '_MOD_' + wHiSfdBL1v9Kl3n5.split('/')[-1].replace('-',' ')
		ttIZeP6yNoM7 = JJDtX1PZyIgN2T.findall('الحلقة-(\d+)',wHiSfdBL1v9Kl3n5.split('/')[-1],JJDtX1PZyIgN2T.DOTALL)
		if ttIZeP6yNoM7: ttIZeP6yNoM7 = ttIZeP6yNoM7[0]
		else: ttIZeP6yNoM7 = '0'
		GiMNQxDjEY79dlmSOqXah6wZFtPVK.append([wHiSfdBL1v9Kl3n5,title,ttIZeP6yNoM7])
	items = sorted(GiMNQxDjEY79dlmSOqXah6wZFtPVK, reverse=False, key=lambda key: int(key[2]))
	MEY7xiNyf4eaQWvuA = str(items).count('/season/')
	CRBMqtF3pNy509XzY17Ue = str(items).count('/episode/')
	if MEY7xiNyf4eaQWvuA>1 and CRBMqtF3pNy509XzY17Ue>0 and '/season/' not in url:
		for wHiSfdBL1v9Kl3n5,title,ttIZeP6yNoM7 in items:
			if '/season/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,213)
	else:
		for wHiSfdBL1v9Kl3n5,title,ttIZeP6yNoM7 in items:
			if '/season/' not in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,212)
	return
def CsUdRabWuh0M9F(url):
	EEgFl59RndzrBL8TUoaQMw6P = []
	xxyPKEIGHM75VZcR3S2z0Q = url.split('/')
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'',headers,'','SERIES4WATCH-PLAY-1st')
	if '/watch/' in YBEsLq8gVw629cMGQP1T:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace(xxyPKEIGHM75VZcR3S2z0Q[3],'watch')
		Plj7MGOHohwdvam2ynfVY1z = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','SERIES4WATCH-PLAY-2nd')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="servers-list(.*?)</div>',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if items:
				id = JJDtX1PZyIgN2T.findall('post_id=(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
				if id:
					rjcLNMPIGsBSni4odgDpx8zqQ2h = id[0]
					for wHiSfdBL1v9Kl3n5,title in items:
						wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/?postid='+rjcLNMPIGsBSni4odgDpx8zqQ2h+'&serverid='+wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
						EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
			else:
				items = JJDtX1PZyIgN2T.findall('data-embedd=".*?(http.*?)("|&quot;)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,g5lf2u4DxNp8imnYevK in items:
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if '/download/' in YBEsLq8gVw629cMGQP1T:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.replace(xxyPKEIGHM75VZcR3S2z0Q[3],'download')
		Plj7MGOHohwdvam2ynfVY1z = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',headers,'','SERIES4WATCH-PLAY-3rd')
		id = JJDtX1PZyIgN2T.findall('postId:"(.*?)"',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if id:
			rjcLNMPIGsBSni4odgDpx8zqQ2h = id[0]
			JZP07kjvbV = { 'User-Agent':'' , 'X-Requested-With':'XMLHttpRequest' }
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH + '/ajaxCenter?_action=getdownloadlinks&postId='+rjcLNMPIGsBSni4odgDpx8zqQ2h
			Plj7MGOHohwdvam2ynfVY1z = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'',JZP07kjvbV,'','SERIES4WATCH-PLAY-4th')
			GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<h3.*?(\d+)(.*?)</div>',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
			if GGbRgKaoskDC:
				for J7SmUMG3CW,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
					items = JJDtX1PZyIgN2T.findall('<td>(.*?)<.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
					for name,wHiSfdBL1v9Kl3n5 in items:
						EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5+'?named='+name+'__download'+'____'+J7SmUMG3CW)
			else:
				GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<h6(.*?)</table>',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
				if not GGbRgKaoskDC: GGbRgKaoskDC = [Plj7MGOHohwdvam2ynfVY1z]
				for mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
					name = ''
					items = JJDtX1PZyIgN2T.findall('href="(http.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
					for wHiSfdBL1v9Kl3n5 in items:
						RgNSOU7P93n = '&&' + wHiSfdBL1v9Kl3n5.split('/')[2].lower() + '&&'
						RgNSOU7P93n = RgNSOU7P93n.replace('.com&&','').replace('.co&&','')
						RgNSOU7P93n = RgNSOU7P93n.replace('.net&&','').replace('.org&&','')
						RgNSOU7P93n = RgNSOU7P93n.replace('.live&&','').replace('.online&&','')
						RgNSOU7P93n = RgNSOU7P93n.replace('&&hd.','').replace('&&www.','')
						RgNSOU7P93n = RgNSOU7P93n.replace('&&','')
						wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5 + '?named=' + name + RgNSOU7P93n + '__download'
						EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH + '/search?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url)
	return
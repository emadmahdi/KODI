# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
s1ITpY2ghtCvR3mSXkFVBnlL8 = 'FAVORITES'
def LO5euqvXT1U3S7CaNlP(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,NNn6pTSH9RMymw):
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==270: pyWkE2rh5uBN4G = iG6vTHmb5KUCaWqrjz(NNn6pTSH9RMymw)
	else: pyWkE2rh5uBN4G = False
	return pyWkE2rh5uBN4G
def l9ue7xUqdEKnkiQS8r0TbLDtsg5(fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9):
	if not fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9: return
	if '_' in fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9: NNn6pTSH9RMymw,UUOLkH4sD2MhNt0KuRbf = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9.split('_',1)
	else: NNn6pTSH9RMymw,UUOLkH4sD2MhNt0KuRbf = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,''
	if   UUOLkH4sD2MhNt0KuRbf=='UP1'	: ZysxTidm1C(NNn6pTSH9RMymw,True,1)
	elif UUOLkH4sD2MhNt0KuRbf=='DOWN1'	: ZysxTidm1C(NNn6pTSH9RMymw,False,1)
	elif UUOLkH4sD2MhNt0KuRbf=='UP4'	: ZysxTidm1C(NNn6pTSH9RMymw,True,4)
	elif UUOLkH4sD2MhNt0KuRbf=='DOWN4'	: ZysxTidm1C(NNn6pTSH9RMymw,False,4)
	elif UUOLkH4sD2MhNt0KuRbf=='ADD1'	: sF2BzoQ3MRv(NNn6pTSH9RMymw)
	elif UUOLkH4sD2MhNt0KuRbf=='REMOVE1': ALYqCrkD8NG6X93fBlVbZP(NNn6pTSH9RMymw)
	elif UUOLkH4sD2MhNt0KuRbf=='DELETELIST': x2gMSynJwCTBK4rtcZfL(NNn6pTSH9RMymw)
	return
def iG6vTHmb5KUCaWqrjz(NNn6pTSH9RMymw):
	xpHevuXWCNQ = GJk0y6NbYP5jOfpeoITHi()
	if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()):
		try:
			PmQEncVSy5lotRfvpKXh2wGT4MLYF9 = xpHevuXWCNQ[NNn6pTSH9RMymw]
			for GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl in PmQEncVSy5lotRfvpKXh2wGT4MLYF9:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl)
		except:
			xpHevuXWCNQ = qqlgo4zmvG7sYR(KoULXHCRWtulrsM1cP)
			PmQEncVSy5lotRfvpKXh2wGT4MLYF9 = xpHevuXWCNQ[NNn6pTSH9RMymw]
			for GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl in PmQEncVSy5lotRfvpKXh2wGT4MLYF9:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl)
	return
def sF2BzoQ3MRv(NNn6pTSH9RMymw):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
	QXeaYk1xv6VdP8D = GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',IxCL4nMsp0NGHgJy8hEOiQFoduAl
	xpHevuXWCNQ = GJk0y6NbYP5jOfpeoITHi()
	zGwXUYCyHLB5VW26uxo8DKt = {}
	for to5FYjiUDqHlcXgThQenyGaI in list(xpHevuXWCNQ.keys()):
		if to5FYjiUDqHlcXgThQenyGaI!=NNn6pTSH9RMymw: zGwXUYCyHLB5VW26uxo8DKt[to5FYjiUDqHlcXgThQenyGaI] = xpHevuXWCNQ[to5FYjiUDqHlcXgThQenyGaI]
		else:
			if rBabYANvVwWzjCp2QF and rBabYANvVwWzjCp2QF!='..':
				SaeAlgnxd1Y7fVt = xpHevuXWCNQ[to5FYjiUDqHlcXgThQenyGaI]
				if QXeaYk1xv6VdP8D in SaeAlgnxd1Y7fVt:
					KJw5NvGlVDUsHnIoe6RL1O8 = SaeAlgnxd1Y7fVt.index(QXeaYk1xv6VdP8D)
					del SaeAlgnxd1Y7fVt[KJw5NvGlVDUsHnIoe6RL1O8]
				xXVBUTQvCfnrLYD1SOqWphR3ug6eb = SaeAlgnxd1Y7fVt+[QXeaYk1xv6VdP8D]
				zGwXUYCyHLB5VW26uxo8DKt[to5FYjiUDqHlcXgThQenyGaI] = xXVBUTQvCfnrLYD1SOqWphR3ug6eb
			else: zGwXUYCyHLB5VW26uxo8DKt[to5FYjiUDqHlcXgThQenyGaI] = xpHevuXWCNQ[to5FYjiUDqHlcXgThQenyGaI]
	if NNn6pTSH9RMymw not in list(zGwXUYCyHLB5VW26uxo8DKt.keys()): zGwXUYCyHLB5VW26uxo8DKt[NNn6pTSH9RMymw] = [QXeaYk1xv6VdP8D]
	i80upnw4hREPgWQxMTrO7yAN5 = str(zGwXUYCyHLB5VW26uxo8DKt)
	if DQfHadYvTpy1UR: i80upnw4hREPgWQxMTrO7yAN5 = i80upnw4hREPgWQxMTrO7yAN5.encode('utf8')
	open(KoULXHCRWtulrsM1cP,'wb').write(i80upnw4hREPgWQxMTrO7yAN5)
	return
def ALYqCrkD8NG6X93fBlVbZP(NNn6pTSH9RMymw):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
	QXeaYk1xv6VdP8D = GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',IxCL4nMsp0NGHgJy8hEOiQFoduAl
	xpHevuXWCNQ = GJk0y6NbYP5jOfpeoITHi()
	if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()) and QXeaYk1xv6VdP8D in xpHevuXWCNQ[NNn6pTSH9RMymw]:
		xpHevuXWCNQ[NNn6pTSH9RMymw].remove(QXeaYk1xv6VdP8D)
		if len(xpHevuXWCNQ[NNn6pTSH9RMymw])==0: del xpHevuXWCNQ[NNn6pTSH9RMymw]
		i80upnw4hREPgWQxMTrO7yAN5 = str(xpHevuXWCNQ)
		if DQfHadYvTpy1UR: i80upnw4hREPgWQxMTrO7yAN5 = i80upnw4hREPgWQxMTrO7yAN5.encode('utf8')
		open(KoULXHCRWtulrsM1cP,'wb').write(i80upnw4hREPgWQxMTrO7yAN5)
	return
def ZysxTidm1C(NNn6pTSH9RMymw,jQJkmEbzHpKSrwh9eOPlUZsfDT,bWzekHhlSQufs71O6oRdC):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
	QXeaYk1xv6VdP8D = GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,'',IxCL4nMsp0NGHgJy8hEOiQFoduAl
	xpHevuXWCNQ = GJk0y6NbYP5jOfpeoITHi()
	if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()):
		SaeAlgnxd1Y7fVt = xpHevuXWCNQ[NNn6pTSH9RMymw]
		if QXeaYk1xv6VdP8D not in SaeAlgnxd1Y7fVt: return
		V781Gfb4DCSPkEXjMZBUWNh = len(SaeAlgnxd1Y7fVt)
		for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(0,bWzekHhlSQufs71O6oRdC):
			F1L6cKyjxY4qCd3MRPerSB9X = SaeAlgnxd1Y7fVt.index(QXeaYk1xv6VdP8D)
			if jQJkmEbzHpKSrwh9eOPlUZsfDT: cVu9DlzCAOMGqdiXFLgBYH1KRJQE8 = F1L6cKyjxY4qCd3MRPerSB9X-1
			else: cVu9DlzCAOMGqdiXFLgBYH1KRJQE8 = F1L6cKyjxY4qCd3MRPerSB9X+1
			if cVu9DlzCAOMGqdiXFLgBYH1KRJQE8>=V781Gfb4DCSPkEXjMZBUWNh: cVu9DlzCAOMGqdiXFLgBYH1KRJQE8 = cVu9DlzCAOMGqdiXFLgBYH1KRJQE8-V781Gfb4DCSPkEXjMZBUWNh
			if cVu9DlzCAOMGqdiXFLgBYH1KRJQE8<0: cVu9DlzCAOMGqdiXFLgBYH1KRJQE8 = cVu9DlzCAOMGqdiXFLgBYH1KRJQE8+V781Gfb4DCSPkEXjMZBUWNh
			SaeAlgnxd1Y7fVt.insert(cVu9DlzCAOMGqdiXFLgBYH1KRJQE8, SaeAlgnxd1Y7fVt.pop(F1L6cKyjxY4qCd3MRPerSB9X))
		xpHevuXWCNQ[NNn6pTSH9RMymw] = SaeAlgnxd1Y7fVt
		i80upnw4hREPgWQxMTrO7yAN5 = str(xpHevuXWCNQ)
		if DQfHadYvTpy1UR: i80upnw4hREPgWQxMTrO7yAN5 = i80upnw4hREPgWQxMTrO7yAN5.encode('utf8')
		open(KoULXHCRWtulrsM1cP,'wb').write(i80upnw4hREPgWQxMTrO7yAN5)
	return
def x2gMSynJwCTBK4rtcZfL(NNn6pTSH9RMymw):
	z3rhpEtd7KLGQZ64XonmW19HSJfAc = MMTfC8jWkbhxp2BDt('center','','','رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+NNn6pTSH9RMymw+' ؟!')
	if z3rhpEtd7KLGQZ64XonmW19HSJfAc!=1: return
	xpHevuXWCNQ = GJk0y6NbYP5jOfpeoITHi()
	if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()):
		del xpHevuXWCNQ[NNn6pTSH9RMymw]
		i80upnw4hREPgWQxMTrO7yAN5 = str(xpHevuXWCNQ)
		if DQfHadYvTpy1UR: i80upnw4hREPgWQxMTrO7yAN5 = i80upnw4hREPgWQxMTrO7yAN5.encode('utf8')
		open(KoULXHCRWtulrsM1cP,'wb').write(i80upnw4hREPgWQxMTrO7yAN5)
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+NNn6pTSH9RMymw)
	return
def GJk0y6NbYP5jOfpeoITHi():
	xpHevuXWCNQ = {}
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(KoULXHCRWtulrsM1cP):
		v7msJY14MyDQaTtfWHVq5U = open(KoULXHCRWtulrsM1cP,'rb').read()
		if DQfHadYvTpy1UR: v7msJY14MyDQaTtfWHVq5U = v7msJY14MyDQaTtfWHVq5U.decode('utf8')
		xpHevuXWCNQ = G8EwoDOyKShm1i0IHMfNYZlU7('dict',v7msJY14MyDQaTtfWHVq5U)
	return xpHevuXWCNQ
def jzoDS2dIB6mULq(xpHevuXWCNQ,QXeaYk1xv6VdP8D,v0IwnapZNsgbx5i):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = QXeaYk1xv6VdP8D
	if not AFWci0tYmjRU1azGJEy3ovDw2hfsqr: GGKpqhAcPw9FHBvdfarRuySJ1Yl,AFWci0tYmjRU1azGJEy3ovDw2hfsqr = 'folder','260'
	XU2HgbCGmz7NBDtSKfk4Q,NNn6pTSH9RMymw = [],''
	if 'context=' in QfEL1VroTPIFZkmzjv5O:
		rrafdlA1I3 = JJDtX1PZyIgN2T.findall('context=(\d+)',QfEL1VroTPIFZkmzjv5O,JJDtX1PZyIgN2T.DOTALL)
		if rrafdlA1I3: NNn6pTSH9RMymw = str(rrafdlA1I3[0])
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr=='270':
		NNn6pTSH9RMymw = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9
		if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()):
			XU2HgbCGmz7NBDtSKfk4Q.append(('مسح قائمة مفضلة '+NNn6pTSH9RMymw,'RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_DELETELIST'+')'))
	else:
		if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()):
			count = len(xpHevuXWCNQ[NNn6pTSH9RMymw])
			if count>1: XU2HgbCGmz7NBDtSKfk4Q.append(('تحريك 1 للأعلى','RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_UP1)'))
			if count>4: XU2HgbCGmz7NBDtSKfk4Q.append(('تحريك 4 للأعلى','RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_UP4)'))
			if count>1: XU2HgbCGmz7NBDtSKfk4Q.append(('تحريك 1 للأسفل','RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_DOWN1)'))
			if count>4: XU2HgbCGmz7NBDtSKfk4Q.append(('تحريك 4 للأسفل','RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_DOWN4)'))
		for NNn6pTSH9RMymw in ['1','2','3','4','5']:
			if NNn6pTSH9RMymw in list(xpHevuXWCNQ.keys()) and QXeaYk1xv6VdP8D in xpHevuXWCNQ[NNn6pTSH9RMymw]:
				XU2HgbCGmz7NBDtSKfk4Q.append(('مسح من مفضلة '+NNn6pTSH9RMymw,'RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_REMOVE1)'))
			else: XU2HgbCGmz7NBDtSKfk4Q.append(('إضافة إلى مفضلة '+NNn6pTSH9RMymw,'RunPlugin('+v0IwnapZNsgbx5i+'&context='+NNn6pTSH9RMymw+'_ADD1)'))
	nnxe5pg3t9fhU4X = []
	for kkAjt13GTJfXpw74lBiRFOVECNe,pdnXJDQNmHB in XU2HgbCGmz7NBDtSKfk4Q:
		kkAjt13GTJfXpw74lBiRFOVECNe = '[COLOR FFFFFF00]'+kkAjt13GTJfXpw74lBiRFOVECNe+'[/COLOR]'
		nnxe5pg3t9fhU4X.append((kkAjt13GTJfXpw74lBiRFOVECNe,pdnXJDQNmHB,))
	return nnxe5pg3t9fhU4X
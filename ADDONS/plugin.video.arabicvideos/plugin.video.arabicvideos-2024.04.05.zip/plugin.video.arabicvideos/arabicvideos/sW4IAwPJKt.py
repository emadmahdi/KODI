# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'FASELHD2'
headers = {'User-Agent':''}
eMlwAzaLSj8ZEQ3txIGP = '_FH2_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['wwe']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==590: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==591: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==592: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==593: mL7BVKcSygkuoPbWlEF4YD = gaJo6Sm8HMP2jKrnBd(url,text)
	elif mode==599: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	PeArnUDVym1pjBFaG = kU2ZXSViB3wLANOz8bH
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',PeArnUDVym1pjBFaG,'','','','','FASELHD2-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع',PeArnUDVym1pjBFaG,599,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',PeArnUDVym1pjBFaG,591,'','','featured1')
	items = JJDtX1PZyIgN2T.findall('<strong>(.*?)</strong>.*?href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for title,wHiSfdBL1v9Kl3n5 in items:
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,591,'','','details1')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-menu"(.*?)header-social',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		GH0TktKp6SyxN = JJDtX1PZyIgN2T.findall('<li (.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for D2DlJjSYIrn in GH0TktKp6SyxN:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',D2DlJjSYIrn,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+wHiSfdBL1v9Kl3n5
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,591,'','','details2')
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','FASELHD2-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	iYcdoyF8MWgsJkDX = 0
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"archive-slider(.*?)<h4>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ooTeU5chRPu: DqrOZE3L85G = ooTeU5chRPu[0]
	else: DqrOZE3L85G = ''
	if type=='featured1':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"slider-carousel"(.*?)</container>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		jYCTd4vkXDP,FsBtqKUQXgMGWxTyrinfhjOev1,kwqYoF8han = zip(*items)
		items = zip(kwqYoF8han,jYCTd4vkXDP,FsBtqKUQXgMGWxTyrinfhjOev1)
	elif type=='featured2':
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
	elif type=='filters':
		GGbRgKaoskDC = [YBEsLq8gVw629cMGQP1T.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in DqrOZE3L85G:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<h4>(.*?)</h4>(.*?)</container>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مميزة',url,591,'','','featured2')
		title = GGbRgKaoskDC[0][0]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,591,'','','details3')
		return
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<h4>(.*?)</h4>(.*?)</container>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		title,mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if any(Y3YqSmycrIWksoH5N0MvC in title.lower() for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
		title = title.strip(' ')
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) (الحلقة|حلقة).\d+',title,JJDtX1PZyIgN2T.DOTALL)
		if '/movseries/' in wHiSfdBL1v9Kl3n5:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,591,ggdRiBo3smurLUGO)
		elif vaQbluYS4GEsKCNwOymT1hFt and type=='':
			title = '_MOD_'+vaQbluYS4GEsKCNwOymT1hFt[0][0]
			if title not in ClXwqHm0DEMvI39agWyiRYopQ:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,593,ggdRiBo3smurLUGO)
				ClXwqHm0DEMvI39agWyiRYopQ.append(title)
		elif any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eePfCBGXTNMy67sw4FqtKxJ):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,592,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,593,ggdRiBo3smurLUGO)
	if type=='filters':
		GHwMQ6AEyDKr3LuYheqRFkOWJg12C = JJDtX1PZyIgN2T.findall('"more_button_page":(.*?),',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if GHwMQ6AEyDKr3LuYheqRFkOWJg12C:
			count = GHwMQ6AEyDKr3LuYheqRFkOWJg12C[0]
			wHiSfdBL1v9Kl3n5 = url+'/offset/'+count
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة أخرى',wHiSfdBL1v9Kl3n5,591,'','','filters')
	elif 'details' in type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = 'صفحة '+jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,591,'','','details4')
	return
def gaJo6Sm8HMP2jKrnBd(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','FASELHD2-SEASONS_EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YbPTE4rKt3cmIuz6WFdi = False
	if not type:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<seasons(.*?)</seasons>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			if len(items)>1:
				PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
				YbPTE4rKt3cmIuz6WFdi = True
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					title = jbigKDeUf0OSMrRkly2B5I3Act(title)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,593,ggdRiBo3smurLUGO,'','episodes')
	if type=='episodes' or not YbPTE4rKt3cmIuz6WFdi:
		UCjpzQwrZyNIe3kg1ThDvi0nb8 = JJDtX1PZyIgN2T.findall('<bkز*?image:url\((.*?)\)"></bk>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if UCjpzQwrZyNIe3kg1ThDvi0nb8: ggdRiBo3smurLUGO = UCjpzQwrZyNIe3kg1ThDvi0nb8[0]
		else: ggdRiBo3smurLUGO = ''
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<all-episodes(.*?)</all-episodes>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,592,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	pB8XANf71vaPJsedkWVIc5,yN1kFpCuj8qLDTG7z43Zt,TTndkJXGRS = [],[],[]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',url,'','','','','FASELHD2-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	HHTr8f6RvtQLF = JJDtX1PZyIgN2T.findall('العمر :.*?<strong">(.*?)</strong>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if HHTr8f6RvtQLF and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,HHTr8f6RvtQLF): return
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('<iframe src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named=__embed')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<slice-title(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('data-url="(.*?)".*?</i>(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			name = name.strip(' ')
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+name+'__watch')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<downloads(.*?)</downloads>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</div>(.*?)</div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,name in items:
			pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+name+'__download')
	for VPwny1D0BhGzde in pB8XANf71vaPJsedkWVIc5:
		wHiSfdBL1v9Kl3n5,name = VPwny1D0BhGzde.split('?named')
		if wHiSfdBL1v9Kl3n5 not in yN1kFpCuj8qLDTG7z43Zt:
			yN1kFpCuj8qLDTG7z43Zt.append(wHiSfdBL1v9Kl3n5)
			TTndkJXGRS.append(VPwny1D0BhGzde)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(TTndkJXGRS,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	PeArnUDVym1pjBFaG = kU2ZXSViB3wLANOz8bH
	url = PeArnUDVym1pjBFaG+'/?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'details5')
	return
# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
from j8oSXm7wWg import *
import bidi.algorithm as Asxc8GDnudJm,bidi.mirror as eNsQ6UdnX0C,base64 as gPSZVjJHKIL,requests as yUt4fqQpnL0AZ
FpjtBKrnu5SdfyOvEPIQ = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡌࡊࡄࡖࡘ࡜ࡕࠧ౾")
yvRq7ZeaIJx6d = {}
PL2fM9WhpjEFb7 = []
if DQfHadYvTpy1UR:
	u5XYGkwyKI40zTtB = SZKinUj8DBxCX3aepygo7fs4kwr2.translatePath(GVPK9Ziaho6U2ySLj(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ౿"))
	qvy1SuIXLZ2g0P35DUQN6n8G7 = SZKinUj8DBxCX3aepygo7fs4kwr2.translatePath(vdHRKkIgTp56Je1OuNo(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩಀ"))
	xs0XGa6V2p = SZKinUj8DBxCX3aepygo7fs4kwr2.translatePath(tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭ಁ"))
	pWKgVeBs5DjUcyv47PE0or2 = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,xmTX9Aeidq8cVhY(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬಂ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ಃ"),ebT9xRB63E(u"ࠬࡇࡤࡥࡱࡱࡷ࠸࠹࠮ࡥࡤࠪ಄"))
	J6Xz4Kd2gcVEsL = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨಅ"),WfgnOq9Fd4lhMSQpK5(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩಆ"),tvdQHb10PhNmuy6(u"ࠨࡘ࡬ࡩࡼࡓ࡯ࡥࡧࡶ࠺࠳ࡪࡢࠨಇ"))
	yOvxDpJofVusbcXRAWZk23aBjrHw = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,tvdQHb10PhNmuy6(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಈ"),CC4UDLW6brf(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಉ"),vdHRKkIgTp56Je1OuNo(u"࡙ࠫ࡫ࡸࡵࡷࡵࡩࡸ࠷࠳࠯ࡦࡥࠫಊ"))
	XTN45xdOzVH0vkep23thYInWPCZ = cg94WALw5orUhvtHSfNO(u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭ಋ")
	from urllib.parse import quote as _REqFlICrt94s0
else:
	u5XYGkwyKI40zTtB = Wj3qSagkcweAb2prRiDyM0HK7Guo.translatePath(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧಌ"))
	qvy1SuIXLZ2g0P35DUQN6n8G7 = Wj3qSagkcweAb2prRiDyM0HK7Guo.translatePath(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ಍"))
	xs0XGa6V2p = Wj3qSagkcweAb2prRiDyM0HK7Guo.translatePath(u2NDjURZVHlmdc0(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬಎ"))
	pWKgVeBs5DjUcyv47PE0or2 = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫಏ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬಐ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡆࡪࡤࡰࡰࡶ࠶࠼࠴ࡤࡣࠩ಑"))
	J6Xz4Kd2gcVEsL = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,b098bsyjUud(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧಒ"),VVtQk9vwe7(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨಓ"),KylMx0kfTOrG(u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧಔ"))
	yOvxDpJofVusbcXRAWZk23aBjrHw = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,vdHRKkIgTp56Je1OuNo(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪಕ"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫಖ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪಗ"))
	XTN45xdOzVH0vkep23thYInWPCZ = tvdQHb10PhNmuy6(u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬಘ").encode(WfgnOq9Fd4lhMSQpK5(u"ࠬࡻࡴࡧ࠺ࠪಙ"))
	from urllib import quote as _REqFlICrt94s0
ZOf4z17vyLarQYEUAHK2dJS = A73K6zLXIgFROeCHJQi0Pbos.path.join(xs0XGa6V2p,b098bsyjUud(u"࠭࡫ࡰࡦ࡬࠲ࡱࡵࡧࠨಚ"))
xieTcq8n4kdFH6A = A73K6zLXIgFROeCHJQi0Pbos.path.join(xs0XGa6V2p,KylMx0kfTOrG(u"ࠧ࡬ࡱࡧ࡭࠳ࡵ࡬ࡥ࠰࡯ࡳ࡬࠭ಛ"))
VTSy4HOAoPmB = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࡫ࡳࡸࡻ࠷ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪಜ"))
PZ5NgwKciFUdhelnzW3ujkIGR = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩ࡬ࡴࡹࡼ࠲ࡥࡣࡷࡥࡤࡥ࡟࠯ࡦࡥࠫಝ"))
zr7JxlDyak06p9Wn = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,Wbwj0o5gsXQ8F2f(u"ࠪࡱ࠸ࡻࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪಞ"))
KoULXHCRWtulrsM1cP = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,A6Iyo7eXrq2RtMmDxWj(u"ࠫ࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳ࠯ࡦࡤࡸࠬಟ"))
CC7dMp1vLSFRnKxltBhm2I = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࡯ࡰࡵࡸࡩ࡭ࡱ࡫࡟ࡠࡡ࠱ࡨࡦࡺࠧಠ"))
dd4ubU1pBVFhms56Y = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,G5TxeI0ND4ztC6(u"࠭࡭࠴ࡷࡩ࡭ࡱ࡫࡟ࡠࡡ࠱ࡨࡦࡺࠧಡ"))
FFoYQNgfsy = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࡪ࡯ࡤ࡫ࡪࡹࠧಢ"))
gIoXKvbGMfFrVRQtWe7shqyuiJmSDP = A73K6zLXIgFROeCHJQi0Pbos.path.join(FFoYQNgfsy,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡦ࡬ࡥࡱࡵࡧࡴࠩಣ"))
dnX2tKhRgS49YB7bCv = A73K6zLXIgFROeCHJQi0Pbos.path.join(gIoXKvbGMfFrVRQtWe7shqyuiJmSDP,ebT9xRB63E(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡡ࠳࠴࠵࠶࡟࠯ࡲࡱ࡫ࠬತ"))
fcISoWNUG0HKemCtBpAy9MV = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon().getAddonInfo(tvdQHb10PhNmuy6(u"ࠪࡴࡦࡺࡨࠨಥ"))
lEezQxTRZ9cd48v16tUIDL = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭ದ"))
kk6VQe4upafgzCqNF8nlG1Ob0LRHAm = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,oh1JUWa3LdnqTpz5(u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨಧ"))
wXlp5vsIhn6CbeJFtycHuP2kS = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪನ"))
qgd7LerTGM = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡣࡣࡱࡲࡪࡸ࠮ࡱࡰࡪࠫ಩"))
DWPrnJp5Rmt3iwbBdEAXhe9OyZ = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,tvdQHb10PhNmuy6(u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨ࠲ࡵࡴࡧࠨಪ"))
HzJgOc4vFANVCBTRsP = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡳࡳࡸࡺࡥࡳ࠰ࡳࡲ࡬࠭ಫ"))
oXBEGVrtTJngd6epPiau0YbHMcF3 = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,VVtQk9vwe7(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠴ࡰ࡯ࡩࠪಬ"))
qXRFIVCbLvuwjiBo = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,tvdQHb10PhNmuy6(u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠴ࡰ࡯ࡩࠪಭ"))
QIl4MNcYoRH3BU8JKgjAh = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡳࡥ࡯ࡷ࠱ࡴࡳ࡭ࠧಮ"))
MNVzRjrKOtLnQ6 = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,CC4UDLW6brf(u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭ಯ"))
I4D30chjOT = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡢࡦࡧࡳࡳࡹࠧರ"))
eexits2XpJ = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,u2NDjURZVHlmdc0(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪಱ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ಲ"),f3pCnmFaVYx4zc1MNGBe5,A6Iyo7eXrq2RtMmDxWj(u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩಳ"))
S3SXQP5fkxTymI4r = A73K6zLXIgFROeCHJQi0Pbos.path.join(u5XYGkwyKI40zTtB,GVPK9Ziaho6U2ySLj(u"ࠫࡲ࡫ࡤࡪࡣࠪ಴"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡌ࡯࡯ࡶࡶࠫವ"),GVPK9Ziaho6U2ySLj(u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩಶ"))
Z7TlP2WKYq5SuRD = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠻ᓜ")
nK76kpOf2u3ENigzmlJVoqIeXwjt4W = [Wbwj0o5gsXQ8F2f(u"ࠧึใิࠫಷ"),ebT9xRB63E(u"ࠨล๋่ࠬಸ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩฮห๋๐ࠧಹ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪฯฬ๊หࠨ಺"),C0CbfZuXJM(u"ࠫึอศฺࠩ಻"),vdHRKkIgTp56Je1OuNo(u"ࠬิวๆี಼ࠪ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ำศัึࠫಽ"),Yr0wo7FaSHx(u"ࠧิษห฽ࠬಾ"),KylMx0kfTOrG(u"ࠨอส้๋࠭ಿ"),CC4UDLW6brf(u"ࠩอหุ฿ࠧೀ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠪ฽ฬฺัࠨು")]
BFy7STa0tZ5nzcwm = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬೂ")
vLpF7c1SAb8MkKCQT = [DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫೃ")]
KpqMXoxe6bwJvuE9WkihFS28y7OtI = [cg94WALw5orUhvtHSfNO(u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨೄ"),b46fBrugtPDSYspzMQIx(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ೅"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬೆ"),G5TxeI0ND4ztC6(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪೇ"),KylMx0kfTOrG(u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭ೈ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ೉"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡓ࡙ࡄࡋࡐࡅࠬೊ"),oh1JUWa3LdnqTpz5(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ೋ"),WfgnOq9Fd4lhMSQpK5(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩೌ"),GVPK9Ziaho6U2ySLj(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵್ࠪ")]
KpqMXoxe6bwJvuE9WkihFS28y7OtI += [DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡋࡉࡑࡇࡌࠨ೎"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ೏"),u2NDjURZVHlmdc0(u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭೐"),xmTX9Aeidq8cVhY(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭೑"),oh1JUWa3LdnqTpz5(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ೒"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧ೓"),xmTX9Aeidq8cVhY(u"ࠨࡕࡋࡓࡔࡌࡐࡓࡑࠪ೔"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡓࡅࡓࡋࡔࠨೕ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪೖ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ೗")]
LwbVqPvuoEfTNt97n5cz2mOHlMDQW0 = [Yr0wo7FaSHx(u"ࠬࡏࡐࡕࡘࠪ೘"),A6Iyo7eXrq2RtMmDxWj(u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆࠩ೙"),KylMx0kfTOrG(u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗࠬ೚"),ebT9xRB63E(u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭೛")]
LwbVqPvuoEfTNt97n5cz2mOHlMDQW0 += [tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡐ࠷࡚࠭೜"),b46fBrugtPDSYspzMQIx(u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬೝ"),CC4UDLW6brf(u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨೞ"),KylMx0kfTOrG(u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ೟")]
LwbVqPvuoEfTNt97n5cz2mOHlMDQW0 += [Vt4ELHXZP6(u"࠭ࡉࡇࡋࡏࡑࠬೠ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡊࡈࡌࡐࡒ࠳ࡁࡓࡃࡅࡍࡈ࠭ೡ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨೢ")]
LwbVqPvuoEfTNt97n5cz2mOHlMDQW0 += [Wbwj0o5gsXQ8F2f(u"ࠩࡄࡐࡆࡘࡁࡃࠩೣ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡅࡐ࡝ࡁࡎࠩ೤"),VVtQk9vwe7(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭೥"),vdHRKkIgTp56Je1OuNo(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ೦"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡁࡌࡑࡄࡑࠬ೧"),vdHRKkIgTp56Je1OuNo(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩ೨")]
LwbVqPvuoEfTNt97n5cz2mOHlMDQW0 += [trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ೩"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩࡅࡓࡐࡘࡁࠨ೪"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ೫"),WfgnOq9Fd4lhMSQpK5(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ೬"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ೭"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ೮")]
SRpWNlGL7ZBiYXJd0OUtrK9 = [tvdQHb10PhNmuy6(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ೯"),tvdQHb10PhNmuy6(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ೰"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭ೱ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ೲ")]
SRpWNlGL7ZBiYXJd0OUtrK9 += [NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩೳ"),tvdQHb10PhNmuy6(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ೴"),b46fBrugtPDSYspzMQIx(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ೵"),b098bsyjUud(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ೶"),vdHRKkIgTp56Je1OuNo(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭೷"),Wbwj0o5gsXQ8F2f(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭೸")]
ffKGTopc4YXOAnu8JzQ0NjWw3ves9 = [tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭೹"),Wbwj0o5gsXQ8F2f(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ೺"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭೻"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ೼"),tvdQHb10PhNmuy6(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ೽")]
ffKGTopc4YXOAnu8JzQ0NjWw3ves9 += [VVtQk9vwe7(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ೾"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ೿"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࡛ࠪࡊࡉࡉࡎࡃࠪഀ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ഁ")]
Xe9gIFkDSyCHm0jKVf = [jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧം"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨഃ"),oh1JUWa3LdnqTpz5(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪഄ"),C0CbfZuXJM(u"ࠨࡈࡒࡗ࡙ࡇࠧഅ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡄࡌ࡜ࡇࡋࠨആ"),C0CbfZuXJM(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫഇ")]
Xe9gIFkDSyCHm0jKVf += [vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࡘࡎࡏࡇࡊࡄࠫഈ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡈࡒࡔࡖࡈࡎࠬഉ"),pOIe6U1vWYC7Gh2udFBRgT(u"࡙࠭ࡂࡓࡒࡘࠬഊ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨഋ"),G5TxeI0ND4ztC6(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩഌ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ഍"),C0CbfZuXJM(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬഎ")]
NN5MQ4Eqtxc9DpuRe  = [vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࡆࡑࡗࡂࡏࠪഏ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡇࡌࡂࡔࡄࡆࠬഐ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ഑"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡃࡑࡎࡖࡆ࠭ഒ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡃࡎࡓࡆࡓࠧഓ"),C0CbfZuXJM(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫഔ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬക"),oh1JUWa3LdnqTpz5(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬഖ")]
NN5MQ4Eqtxc9DpuRe += [Wbwj0o5gsXQ8F2f(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧഗ"),u2NDjURZVHlmdc0(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩഘ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨങ"),A6Iyo7eXrq2RtMmDxWj(u"ࠨ࡙ࡈࡇࡎࡓࡁࠨച"),G5TxeI0ND4ztC6(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ഛ"),u2NDjURZVHlmdc0(u"ࠪࡊࡔ࡙ࡔࡂࠩജ"),tvdQHb10PhNmuy6(u"ࠫࡆࡎࡗࡂࡍࠪഝ")]
NN5MQ4Eqtxc9DpuRe += [u2NDjURZVHlmdc0(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨഞ"),Vt4ELHXZP6(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩട"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩഠ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪഡ"),WfgnOq9Fd4lhMSQpK5(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫഢ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬണ")]
NN5MQ4Eqtxc9DpuRe += [Vt4ELHXZP6(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬത"),pOIe6U1vWYC7Gh2udFBRgT(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧഥ"),b46fBrugtPDSYspzMQIx(u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨദ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡕࡘࡉ࡙ࡓ࠭ധ"),WfgnOq9Fd4lhMSQpK5(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪന"),ebT9xRB63E(u"ࠩࡖࡌࡔࡌࡈࡂࠩഩ")]
NN5MQ4Eqtxc9DpuRe += [uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪപ"),G5TxeI0ND4ztC6(u"ࠫ࡞ࡇࡑࡐࡖࠪഫ"),WfgnOq9Fd4lhMSQpK5(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ബ"),Yr0wo7FaSHx(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧഭ"),A6Iyo7eXrq2RtMmDxWj(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬമ"),KylMx0kfTOrG(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪയ"),G5TxeI0ND4ztC6(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫര")]
Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM  = [uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨറ"),WfgnOq9Fd4lhMSQpK5(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬല"),u2NDjURZVHlmdc0(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬള"),tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫഴ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫവ")]
Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM += [oh1JUWa3LdnqTpz5(u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧശ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩഷ")]
Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM += [tvdQHb10PhNmuy6(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫസ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨഹ"),WfgnOq9Fd4lhMSQpK5(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨഺ")]
Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM += [YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡉࡑࡖ࡙࠱ࡑࡏࡖࡆ഻ࠩ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡊࡒࡗ࡚࠲ࡓࡏࡗࡋࡈࡗ഼ࠬ"),WfgnOq9Fd4lhMSQpK5(u"ࠨࡋࡓࡘ࡛࠳ࡓࡆࡔࡌࡉࡘ࠭ഽ")]
Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM += [jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࡐ࠷࡚࠳ࡌࡊࡘࡈࠫാ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧി"),b46fBrugtPDSYspzMQIx(u"ࠫࡒ࠹ࡕ࠮ࡕࡈࡖࡎࡋࡓࠨീ")]
XXRAjo5w8aES0PQkKhB1uYJZgyWF = [C0CbfZuXJM(u"ࠬࡓ࠳ࡖࠩു"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡉࡑࡖ࡙ࠫൂ"),u2NDjURZVHlmdc0(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬൃ"),vdHRKkIgTp56Je1OuNo(u"ࠨࡋࡉࡍࡑࡓࠧൄ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ൅")]
LmSe8awMPpCzoKW = NN5MQ4Eqtxc9DpuRe+Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM
Mo2ZvEHtN8QOj5gy1pnVxFLPd = NN5MQ4Eqtxc9DpuRe+XXRAjo5w8aES0PQkKhB1uYJZgyWF
dyNaHP9czZ4Vir5uqp8Eho = NN5MQ4Eqtxc9DpuRe+Nac3XIvKy9Wne5BCYPrq8G6HVJ4zDM
Fe5HaTsOjEVdJizL9IfQWvZr3ChSA = LwbVqPvuoEfTNt97n5cz2mOHlMDQW0+ffKGTopc4YXOAnu8JzQ0NjWw3ves9+Xe9gIFkDSyCHm0jKVf+SRpWNlGL7ZBiYXJd0OUtrK9
y5ZuIeDBf0RtS = [
						YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬെ")
						,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭േ")
						,Vt4ELHXZP6(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡘࡐ࡙ࡏ࡟࡙ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ൈ")
						]
emFVCjpawXi0xhtYQo1T9H2vPlyuJK = [
						KylMx0kfTOrG(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ൉")
						,C0CbfZuXJM(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫൊ")
						,CC4UDLW6brf(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩോ")
						,xmTX9Aeidq8cVhY(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪൌ")
						,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸ്ࠬ")
						,CC4UDLW6brf(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧൎ")
						,pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ൏")
						,oh1JUWa3LdnqTpz5(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ൐")
						,b46fBrugtPDSYspzMQIx(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ൑")
						,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ൒")
						,Vt4ELHXZP6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ൓")
						,b46fBrugtPDSYspzMQIx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪൔ")
						,b46fBrugtPDSYspzMQIx(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪൕ")
						]
TmeBwNcAQlb7XMau5LgYGrE4fWno2 = emFVCjpawXi0xhtYQo1T9H2vPlyuJK+[
				 uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡓࡑ࡛࡝ࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧൖ")
				,trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫൗ")
				,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ൘")
				,tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠳ࡰࡧࠫ൙")
				,tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠳ࡶࡸࠬ൚")
				,Vt4ELHXZP6(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠵ࡲࡩ࠭൛")
				,G5TxeI0ND4ztC6(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠴ࡷࡹ࠭൜")
				,DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠶ࡳࡪࠧ൝")
				,xmTX9Aeidq8cVhY(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠸ࡸࡤࠨ൞")
				,Wbwj0o5gsXQ8F2f(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡅࡋࡉࡈࡑ࡟ࡉࡖࡗࡔࡘࡥࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫൟ")
				,GVPK9Ziaho6U2ySLj(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫൠ")
				,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬൡ")
				,tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭ൢ")
				,tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡕࡔࡃࡊࡉࡤࡘࡅࡑࡑࡕࡘ࠲࠷ࡳࡵࠩൣ")
				,Yr0wo7FaSHx(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭൤")
				,xmTX9Aeidq8cVhY(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ൥")
				]
vXU90oAP4jJZzsw51SkNYu8Q6bF = [KylMx0kfTOrG(u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ൦"),Wbwj0o5gsXQ8F2f(u"ࠨ࠳࠱࠵࠳࠷࠮࠲ࠩ൧"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠩ࠴࠲࠵࠴࠰࠯࠳ࠪ൨"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪ࠼࠳࠾࠮࠵࠰࠷ࠫ൩"),CC4UDLW6brf(u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠲࠯࠴࠵࠶ࠬ൪"),oh1JUWa3LdnqTpz5(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠱࠰࠵࠶࠵࠭൫")]
LWzUbE5adDslTXGr = {
			 hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡁࡌࡑࡄࡑࠬ൬")		:[GVPK9Ziaho6U2ySLj(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼ࠯ࡰ࡮ࡧࠫ൭")]
			,vdHRKkIgTp56Je1OuNo(u"ࠨࡃࡋ࡛ࡆࡑࠧ൮")		:[WfgnOq9Fd4lhMSQpK5(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫ൯")]
			,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡅࡐ࡝ࡁࡎࠩ൰")		:[VVtQk9vwe7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫࠯ࡵࡹࠫ൱")]
			,b46fBrugtPDSYspzMQIx(u"ࠬࡇࡌࡂࡔࡄࡆࠬ൲")		:[G5TxeI0ND4ztC6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭ࠨ൳")]
			,Yr0wo7FaSHx(u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ൴")		:[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠭൵")]
			,trSQHvP4aqBWFKxN5bZgXCu(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ൶")		:[uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩ൷")]
			,vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ൸")	:[VVtQk9vwe7(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬ൹")]
			,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨൺ")		:[uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡥࡧࡹࡥࡦࡦ࠱ࡲࡪࡺࠧൻ")]
			,GVPK9Ziaho6U2ySLj(u"ࠨࡄࡒࡏࡗࡇࠧർ")		:[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨൽ")]
			,Wbwj0o5gsXQ8F2f(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪൾ")		:[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩൿ")]
			,ebT9xRB63E(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭඀")		:[tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬඁ")]
			,GVPK9Ziaho6U2ySLj(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧං")		:[uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧඃ")]
			,vdHRKkIgTp56Je1OuNo(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ඄")		:[vdHRKkIgTp56Je1OuNo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠵ࡥࡨࡴ࠴ࡣࡰ࡯ࠪඅ")]
			,pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ආ")		:[xmTX9Aeidq8cVhY(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡹࡤࡸࡨ࡮ࠧඇ")]
			,vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬඈ")	:[Yr0wo7FaSHx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡹࡺ࠳ࡩࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡴࡪࡲࡴࠬඉ")]
			,Wbwj0o5gsXQ8F2f(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪඊ")		:[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭උ")]
			,vdHRKkIgTp56Je1OuNo(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ඌ")	:[CC4UDLW6brf(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽ࠲࠷࠰ࡰࡽ࠲ࡩࡩ࡮ࡣ࠱ࡲࡪࡺࠧඍ")]
			,C0CbfZuXJM(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ඎ")		:[b098bsyjUud(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡥࡦࠫඏ")]
			,GVPK9Ziaho6U2ySLj(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬඐ")	:[b46fBrugtPDSYspzMQIx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨඑ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡷࡧࡰࡩࡳ࡯࠲ࡦࡶࡩ࠯ࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠴ࡣࡰ࡯ࠪඒ")]
			,trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫඓ")		:[G5TxeI0ND4ztC6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡣ࠯ࡦࡵࡥࡲࡧࡳ࠸࠰ࡦࡳࡲ࠭ඔ")]
			,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧඕ")		:[b098bsyjUud(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡪࡲࡱࡪࡹࠧඖ")]
			,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ඗")		:[u2NDjURZVHlmdc0(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡥࡨࡺ࡯ࡳࠩ඘")]
			,Vt4ELHXZP6(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ඙")		:[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪක")]
			,vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ඛ")		:[KylMx0kfTOrG(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬග")]
			,trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧඝ")		:[DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡩ࡫ࡡࡥ࠰࡯࡭ࡻ࡫ࠧඞ")]
			,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡇࡏࡇࡎࡔࡅࡎࡃࠪඟ")		:[Yr0wo7FaSHx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡱࡩࡩ࡯ࡧࡰࡥ࠳ࡩ࡯࡮ࠩච")]
			,b46fBrugtPDSYspzMQIx(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫඡ")		:[xmTX9Aeidq8cVhY(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡࡣࡴ࡮ࡥ࠳ࡩ࡯࡮ࠩජ")]
			,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨඣ")	:[G5TxeI0ND4ztC6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧࡣ࡭ࡩࡷ࠴ࡳࡩࡱࡺࠫඤ")]
			,C0CbfZuXJM(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩඥ")		:[C0CbfZuXJM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪࡷࡢࡶࡦ࡬࠳ࡺ࡯ࡱࠩඦ")]
			,DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫට")		:[trSQHvP4aqBWFKxN5bZgXCu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡹ࡬ࡢ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩඨ")]
			,GVPK9Ziaho6U2ySLj(u"ࠫࡋࡕࡓࡕࡃࠪඩ")		:[trSQHvP4aqBWFKxN5bZgXCu(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࡬࠱ࡪࡴࡹࡴࡢ࠯ࡷࡺ࠳ࡴࡥࡵࠩඪ")]
			,trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨණ")		:[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡱࡪࡪࡩࡢࠩඬ")]
			,Wbwj0o5gsXQ8F2f(u"ࠨࡋࡉࡍࡑࡓࠧත")		:[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪථ"),Vt4ELHXZP6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫද"),tvdQHb10PhNmuy6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬධ"),A6Iyo7eXrq2RtMmDxWj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧන"),tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭඲")]
			,GVPK9Ziaho6U2ySLj(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪඳ")	:[trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩප")]
			,vdHRKkIgTp56Je1OuNo(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫඵ")		:[A6Iyo7eXrq2RtMmDxWj(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵ࡯࠯࡭࡬ࡸࡰࡵࡴ࠯ࡶࡹࠫබ")]
			,A6Iyo7eXrq2RtMmDxWj(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪභ")	:[CC4UDLW6brf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩම"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࠰ࡩࡻࡸ࠴ࡳࡵࡱࡵࡩࠬඹ")]
			,tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨය")		:[tvdQHb10PhNmuy6(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡧࡦࡳࠧර")]
			,cg94WALw5orUhvtHSfNO(u"ࠩࡓࡅࡓࡋࡔࠨ඼")		:[ebT9xRB63E(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬල")]
			,b46fBrugtPDSYspzMQIx(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭඾")		:[b46fBrugtPDSYspzMQIx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡧࡧ࠸ࡺ࠴ࡣࡢ࡯ࠪ඿")]
			,Yr0wo7FaSHx(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪව")	:[uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭ශ")]
			,Wbwj0o5gsXQ8F2f(u"ࠨࡕࡋࡓࡋࡎࡁࠨෂ")		:[KylMx0kfTOrG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪ࠮ࡴࡪࡲࡪ࡭ࡧ࠮ࡵࡸࠪස")]
			,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬහ")		:[VVtQk9vwe7(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫළ"),GVPK9Ziaho6U2ySLj(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬෆ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ෇")]
			,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡕࡘࡉ࡙ࡓ࠭෈")		:[tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲ࡹࡼࡦࡶࡰ࠱ࡱࡪ࠭෉")]
			,A6Iyo7eXrq2RtMmDxWj(u"࡚ࠩࡉࡈࡏࡍࡂ්ࠩ")		:[b098bsyjUud(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡽࡴ࠭࠮࠯࠰࠱࠲ࡴࡺࡦࡤࡦࡥ࠺࡭ࡤ࠸ࡱࡧࡩ࠵ࡨࡩࡨ࡮࡫࠲ࡲࡿࡣࡪ࡫ࡰࡥ࠲ࡽࡥࡤ࡫࡬ࡱࡦ࠴ࡳࡩࡱࡳࠫ෋")]
			,vdHRKkIgTp56Je1OuNo(u"ࠫ࡞ࡇࡑࡐࡖࠪ෌")		:[tjoHEAGv2XkrMBsVfCyp5U(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹ࠯ࡻࡤࡵࡴࡺ࠮ࡵࡸࠪ෍")]
			,Yr0wo7FaSHx(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ෎")		:[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯ࠪා")]
			,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡔࡈࡔࡔ࡙ࠧැ")		:[vdHRKkIgTp56Je1OuNo(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩෑ"),VVtQk9vwe7(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧි"),G5TxeI0ND4ztC6(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨී")]
			,A6Iyo7eXrq2RtMmDxWj(u"ࠬࡘࡅࡑࡑࡖࡣࡇࡑࡐࠨු")	:[WfgnOq9Fd4lhMSQpK5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ෕"),Wbwj0o5gsXQ8F2f(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩූ"),b46fBrugtPDSYspzMQIx(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ෗")]
			,ebT9xRB63E(u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪෘ")		:[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡱ࡯ࡥ࡫ࠪෙ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩࠩේ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏࠨෛ")]
			}
if tvdQHb10PhNmuy6(u"࠱ᓝ"):
	LWzUbE5adDslTXGr[G5TxeI0ND4ztC6(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ො")] = [WfgnOq9Fd4lhMSQpK5(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩෝ"),WfgnOq9Fd4lhMSQpK5(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ෞ"),KylMx0kfTOrG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬෟ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ෠"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ෡"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ෢"),Wbwj0o5gsXQ8F2f(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ෣"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ෤"),cg94WALw5orUhvtHSfNO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ෥")]
	LWzUbE5adDslTXGr[vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭෦")] = [hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭෧"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ෨"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ෩"),C0CbfZuXJM(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ෪"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ෫"),tvdQHb10PhNmuy6(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ෬"),tvdQHb10PhNmuy6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ෭"),C0CbfZuXJM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ෮"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭෯")]
else:
	LWzUbE5adDslTXGr[vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ෰")] = [vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ෱"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ෲ"),WfgnOq9Fd4lhMSQpK5(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬෳ"),b46fBrugtPDSYspzMQIx(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ෴"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ෵"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ෶"),b46fBrugtPDSYspzMQIx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ෷"),Yr0wo7FaSHx(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ෸"),KylMx0kfTOrG(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ෹")]
	LWzUbE5adDslTXGr[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ෺")] = [G5TxeI0ND4ztC6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ෻"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ෼"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ෽"),KylMx0kfTOrG(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ෾"),oh1JUWa3LdnqTpz5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ෿"),CC4UDLW6brf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ฀"),KylMx0kfTOrG(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪก"),A6Iyo7eXrq2RtMmDxWj(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫข"),b46fBrugtPDSYspzMQIx(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬฃ")]
xlhZCNs8FQ4 = [b46fBrugtPDSYspzMQIx(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭ค"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭ฅ"),Yr0wo7FaSHx(u"࠭ࡅࡎࡃࡌࡐࡘ࠭ฆ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩง"),Yr0wo7FaSHx(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪจ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬฉ"),C0CbfZuXJM(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨช"),vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡈࡇࡐࡕࡅࡋࡅࠬซ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭ฌ")]
HzC0OmsPxKp8rbSiqlU = [DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡁࡅࡆࡒࡒࡘ࠭ญ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠹ࠩฎ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠻ࠪฏ")]
class rIH5SkfPXyxZecRbQzoq(jLxTKuQmGcE):
	def __init__(vUNh2O7nLwdF1eTkEfCYSm8t,*aargs,**kkwargs):
		vUNh2O7nLwdF1eTkEfCYSm8t.choiceID = -A6Iyo7eXrq2RtMmDxWj(u"࠲ᓞ")
	def onClick(vUNh2O7nLwdF1eTkEfCYSm8t,Ld6JxD2cZnK3NOYo):
		if Ld6JxD2cZnK3NOYo>=tvdQHb10PhNmuy6(u"࠻࠳࠵࠵ᓟ"): vUNh2O7nLwdF1eTkEfCYSm8t.choiceID = Ld6JxD2cZnK3NOYo-tvdQHb10PhNmuy6(u"࠻࠳࠵࠵ᓟ")
		vUNh2O7nLwdF1eTkEfCYSm8t.ZOpgFwfRN7CduJIUEL()
	def htEbDv0jQV2NAB9ZHRkWoYUTpsXS(vUNh2O7nLwdF1eTkEfCYSm8t,*aargs):
		vUNh2O7nLwdF1eTkEfCYSm8t.button0,vUNh2O7nLwdF1eTkEfCYSm8t.button1,vUNh2O7nLwdF1eTkEfCYSm8t.button2 = aargs[trSQHvP4aqBWFKxN5bZgXCu(u"࠴ᓡ")],aargs[b098bsyjUud(u"࠴ᓠ")],aargs[VVtQk9vwe7(u"࠷ᓢ")]
		vUNh2O7nLwdF1eTkEfCYSm8t.header,vUNh2O7nLwdF1eTkEfCYSm8t.text = aargs[KylMx0kfTOrG(u"࠹ᓣ")],aargs[Vt4ELHXZP6(u"࠴ᓤ")]
		vUNh2O7nLwdF1eTkEfCYSm8t.profile,vUNh2O7nLwdF1eTkEfCYSm8t.direction = aargs[Wbwj0o5gsXQ8F2f(u"࠶ᓥ")],aargs[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠸ᓦ")]
		vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout,vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout = aargs[b46fBrugtPDSYspzMQIx(u"࠻ᓨ")],aargs[WfgnOq9Fd4lhMSQpK5(u"࠻ᓧ")]
		if vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout>A6Iyo7eXrq2RtMmDxWj(u"࠵ᓩ") or vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout>A6Iyo7eXrq2RtMmDxWj(u"࠵ᓩ"): vUNh2O7nLwdF1eTkEfCYSm8t.enable_progressbar = GVPK9Ziaho6U2ySLj(u"ࡔࡳࡷࡨ᜷")
		else: vUNh2O7nLwdF1eTkEfCYSm8t.enable_progressbar = DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪ᜸")
		vUNh2O7nLwdF1eTkEfCYSm8t.image_filename = dnX2tKhRgS49YB7bCv.replace(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩฐ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࡣࠬฑ")+str(Mrx2OeZV1LNjBsQ58Savi7.time())+G5TxeI0ND4ztC6(u"ࠫࡤ࠭ฒ"))
		vUNh2O7nLwdF1eTkEfCYSm8t.image_filename = vUNh2O7nLwdF1eTkEfCYSm8t.image_filename.replace(xmTX9Aeidq8cVhY(u"ࠬࡢ࡜ࠨณ"),Vt4ELHXZP6(u"࠭࡜࡝࡞࡟ࠫด")).replace(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧ࠰࠱ࠪต"),u2NDjURZVHlmdc0(u"ࠨ࠱࠲࠳࠴࠭ถ"))
		vUNh2O7nLwdF1eTkEfCYSm8t.image_height = Whl52Kf4SzyA9qBOujbeLQtIJM(vUNh2O7nLwdF1eTkEfCYSm8t.button0,vUNh2O7nLwdF1eTkEfCYSm8t.button1,vUNh2O7nLwdF1eTkEfCYSm8t.button2,vUNh2O7nLwdF1eTkEfCYSm8t.header,vUNh2O7nLwdF1eTkEfCYSm8t.text,vUNh2O7nLwdF1eTkEfCYSm8t.profile,vUNh2O7nLwdF1eTkEfCYSm8t.direction,vUNh2O7nLwdF1eTkEfCYSm8t.enable_progressbar,vUNh2O7nLwdF1eTkEfCYSm8t.image_filename)
		vUNh2O7nLwdF1eTkEfCYSm8t.show()
		vUNh2O7nLwdF1eTkEfCYSm8t.getControl(ebT9xRB63E(u"࠿࠰࠶࠲ᓪ")).setImage(vUNh2O7nLwdF1eTkEfCYSm8t.image_filename)
		vUNh2O7nLwdF1eTkEfCYSm8t.getControl(C0CbfZuXJM(u"࠹࠱࠷࠳ᓫ")).setHeight(vUNh2O7nLwdF1eTkEfCYSm8t.image_height)
		if not vUNh2O7nLwdF1eTkEfCYSm8t.button1 and vUNh2O7nLwdF1eTkEfCYSm8t.button0 and vUNh2O7nLwdF1eTkEfCYSm8t.button2: vUNh2O7nLwdF1eTkEfCYSm8t.getControl(vdHRKkIgTp56Je1OuNo(u"࠻࠳࠵࠷ᓭ")).setPosition(-GVPK9Ziaho6U2ySLj(u"࠵࠶࠵ᓮ"),cg94WALw5orUhvtHSfNO(u"࠱ᓬ"))
		return vUNh2O7nLwdF1eTkEfCYSm8t.image_filename,vUNh2O7nLwdF1eTkEfCYSm8t.image_height
	def zNCheP0cUL1osQYa(vUNh2O7nLwdF1eTkEfCYSm8t):
		if vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout:
			vUNh2O7nLwdF1eTkEfCYSm8t.th1 = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=vUNh2O7nLwdF1eTkEfCYSm8t.AkKsh1J068,args=())
			vUNh2O7nLwdF1eTkEfCYSm8t.th1.start()
		else: vUNh2O7nLwdF1eTkEfCYSm8t.o2dXg3TlO0()
	def AkKsh1J068(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.getControl(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠽࠵࠸࠰ᓯ")).setEnabled(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡖࡵࡹࡪ᜹"))
		for uvTwHSmjyW6Vr0192IZ in range(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᓰ"),vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᓰ")):
			Mrx2OeZV1LNjBsQ58Savi7.sleep(trSQHvP4aqBWFKxN5bZgXCu(u"࠷ᓱ"))
			gnEybFJ9PcBC4S6Go0pH = int(Wbwj0o5gsXQ8F2f(u"࠱࠱࠲ᓲ")*uvTwHSmjyW6Vr0192IZ/vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout)
			vUNh2O7nLwdF1eTkEfCYSm8t.a3aGlsbwgQdiY(gnEybFJ9PcBC4S6Go0pH)
			if vUNh2O7nLwdF1eTkEfCYSm8t.choiceID>tvdQHb10PhNmuy6(u"࠱ᓳ"): break
		vUNh2O7nLwdF1eTkEfCYSm8t.o2dXg3TlO0()
	def jjDvSx5hJGWgrMVR4yEpTQ7aAz(vUNh2O7nLwdF1eTkEfCYSm8t):
		if vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout:
			vUNh2O7nLwdF1eTkEfCYSm8t.th2 = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=vUNh2O7nLwdF1eTkEfCYSm8t.mQ126iJCT4dPt9pYkWIcoDXvMlrH,args=())
			vUNh2O7nLwdF1eTkEfCYSm8t.th2.start()
		else: vUNh2O7nLwdF1eTkEfCYSm8t.o2dXg3TlO0()
	def mQ126iJCT4dPt9pYkWIcoDXvMlrH(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.getControl(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠻࠳࠶࠵ᓴ")).setEnabled(vlW6K1g8Xo35mPYbyO2GS(u"ࡗࡶࡺ࡫᜺"))
		Mrx2OeZV1LNjBsQ58Savi7.sleep(vUNh2O7nLwdF1eTkEfCYSm8t.buttonstimeout)
		for uvTwHSmjyW6Vr0192IZ in range(vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout-b46fBrugtPDSYspzMQIx(u"࠴ᓵ"),-b46fBrugtPDSYspzMQIx(u"࠴ᓵ"),-b46fBrugtPDSYspzMQIx(u"࠴ᓵ")):
			Mrx2OeZV1LNjBsQ58Savi7.sleep(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠵ᓶ"))
			gnEybFJ9PcBC4S6Go0pH = int(A6Iyo7eXrq2RtMmDxWj(u"࠶࠶࠰ᓷ")*uvTwHSmjyW6Vr0192IZ/vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout)
			vUNh2O7nLwdF1eTkEfCYSm8t.a3aGlsbwgQdiY(gnEybFJ9PcBC4S6Go0pH)
			if vUNh2O7nLwdF1eTkEfCYSm8t.choiceID>hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶ᓸ"): break
		if vUNh2O7nLwdF1eTkEfCYSm8t.closetimeout>Yr0wo7FaSHx(u"࠰ᓹ"): vUNh2O7nLwdF1eTkEfCYSm8t.choiceID = b46fBrugtPDSYspzMQIx(u"࠲࠲ᓺ")
		vUNh2O7nLwdF1eTkEfCYSm8t.ZOpgFwfRN7CduJIUEL()
	def a3aGlsbwgQdiY(vUNh2O7nLwdF1eTkEfCYSm8t,gnEybFJ9PcBC4S6Go0pH):
		vUNh2O7nLwdF1eTkEfCYSm8t.precent = gnEybFJ9PcBC4S6Go0pH
		vUNh2O7nLwdF1eTkEfCYSm8t.getControl(VVtQk9vwe7(u"࠻࠳࠶࠵ᓻ")).setPercent(vUNh2O7nLwdF1eTkEfCYSm8t.precent)
	def o2dXg3TlO0(vUNh2O7nLwdF1eTkEfCYSm8t):
		if vUNh2O7nLwdF1eTkEfCYSm8t.button0: vUNh2O7nLwdF1eTkEfCYSm8t.getControl(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠼࠴࠶࠶ᓼ")).setEnabled(ebT9xRB63E(u"ࡘࡷࡻࡥ᜻"))
		if vUNh2O7nLwdF1eTkEfCYSm8t.button1: vUNh2O7nLwdF1eTkEfCYSm8t.getControl(oh1JUWa3LdnqTpz5(u"࠽࠵࠷࠱ᓽ")).setEnabled(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࡙ࡸࡵࡦ᜼"))
		if vUNh2O7nLwdF1eTkEfCYSm8t.button2: vUNh2O7nLwdF1eTkEfCYSm8t.getControl(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠾࠶࠱࠳ᓾ")).setEnabled(uEed4OSxm7hBq9Vvky6QjHwWC(u"࡚ࡲࡶࡧ᜽"))
	def ZOpgFwfRN7CduJIUEL(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.close()
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(vUNh2O7nLwdF1eTkEfCYSm8t.image_filename)
		except: pass
class aDiNElZCYMU9ptH7oA3d5eu60IOwgj():
	def __init__(vUNh2O7nLwdF1eTkEfCYSm8t,showDialogs=oh1JUWa3LdnqTpz5(u"ࡇࡣ࡯ࡷࡪ᜿"),logErrors=tvdQHb10PhNmuy6(u"ࡔࡳࡷࡨ᜾")):
		vUNh2O7nLwdF1eTkEfCYSm8t.showDialogs = showDialogs
		vUNh2O7nLwdF1eTkEfCYSm8t.logErrors = logErrors
		vUNh2O7nLwdF1eTkEfCYSm8t.finishedLIST,vUNh2O7nLwdF1eTkEfCYSm8t.failedLIST = [],[]
		vUNh2O7nLwdF1eTkEfCYSm8t.statusDICT,vUNh2O7nLwdF1eTkEfCYSm8t.resultsDICT = {},{}
		vUNh2O7nLwdF1eTkEfCYSm8t.processesLIST = []
		vUNh2O7nLwdF1eTkEfCYSm8t.starttimeDICT,vUNh2O7nLwdF1eTkEfCYSm8t.finishtimeDICT,vUNh2O7nLwdF1eTkEfCYSm8t.elpasedtimeDICT = {},{},{}
	def HuWXO3UhTeKJj0ts2Bga(vUNh2O7nLwdF1eTkEfCYSm8t,iZXua1gCvb9Y5xr,cniFJsxa6TVCBY7,*aargs):
		iZXua1gCvb9Y5xr = str(iZXua1gCvb9Y5xr)
		vUNh2O7nLwdF1eTkEfCYSm8t.statusDICT[iZXua1gCvb9Y5xr] = ebT9xRB63E(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪท")
		if vUNh2O7nLwdF1eTkEfCYSm8t.showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(WfgnOq9Fd4lhMSQpK5(u"ࠪࠫธ"),iZXua1gCvb9Y5xr)
		db6imBFafuwc7 = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=vUNh2O7nLwdF1eTkEfCYSm8t.Aav7jPR2xs4Bh5rZX8q9,args=(iZXua1gCvb9Y5xr,cniFJsxa6TVCBY7,aargs))
		vUNh2O7nLwdF1eTkEfCYSm8t.processesLIST.append(db6imBFafuwc7)
		return db6imBFafuwc7
	def t5F2ieMUsZbgfAGqpzOTdaYn(vUNh2O7nLwdF1eTkEfCYSm8t,iZXua1gCvb9Y5xr,cniFJsxa6TVCBY7,*aargs):
		db6imBFafuwc7 = vUNh2O7nLwdF1eTkEfCYSm8t.HuWXO3UhTeKJj0ts2Bga(iZXua1gCvb9Y5xr,cniFJsxa6TVCBY7,*aargs)
		db6imBFafuwc7.start()
	def Aav7jPR2xs4Bh5rZX8q9(vUNh2O7nLwdF1eTkEfCYSm8t,iZXua1gCvb9Y5xr,cniFJsxa6TVCBY7,aargs):
		iZXua1gCvb9Y5xr = str(iZXua1gCvb9Y5xr)
		vUNh2O7nLwdF1eTkEfCYSm8t.starttimeDICT[iZXua1gCvb9Y5xr] = Mrx2OeZV1LNjBsQ58Savi7.time()
		try:
			vUNh2O7nLwdF1eTkEfCYSm8t.resultsDICT[iZXua1gCvb9Y5xr] = cniFJsxa6TVCBY7(*aargs)
			if jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬน") in str(cniFJsxa6TVCBY7) and not vUNh2O7nLwdF1eTkEfCYSm8t.resultsDICT[iZXua1gCvb9Y5xr].succeeded:
				ssIFxhY0K5JUkqicQ8WlbmMBP(vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫบ"))
			vUNh2O7nLwdF1eTkEfCYSm8t.finishedLIST.append(iZXua1gCvb9Y5xr)
			vUNh2O7nLwdF1eTkEfCYSm8t.statusDICT[iZXua1gCvb9Y5xr] = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨป")
		except Exception as Rs2m41dCIxHrBGwZ9i06DULv:
			if vUNh2O7nLwdF1eTkEfCYSm8t.logErrors:
				n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
				if n6MNfIpoX7GgJZu!=A6Iyo7eXrq2RtMmDxWj(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪผ"): uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
			vUNh2O7nLwdF1eTkEfCYSm8t.failedLIST.append(iZXua1gCvb9Y5xr)
			vUNh2O7nLwdF1eTkEfCYSm8t.statusDICT[iZXua1gCvb9Y5xr] = u2NDjURZVHlmdc0(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨฝ")
		vUNh2O7nLwdF1eTkEfCYSm8t.finishtimeDICT[iZXua1gCvb9Y5xr] = Mrx2OeZV1LNjBsQ58Savi7.time()
		vUNh2O7nLwdF1eTkEfCYSm8t.elpasedtimeDICT[iZXua1gCvb9Y5xr] = vUNh2O7nLwdF1eTkEfCYSm8t.finishtimeDICT[iZXua1gCvb9Y5xr] - vUNh2O7nLwdF1eTkEfCYSm8t.starttimeDICT[iZXua1gCvb9Y5xr]
	def nbvURy7WSEsk(vUNh2O7nLwdF1eTkEfCYSm8t):
		for Eus82DvKplRkWB1JN7FU in vUNh2O7nLwdF1eTkEfCYSm8t.processesLIST:
			Eus82DvKplRkWB1JN7FU.start()
	def tJpiSGs7n5DuECIRMxT6UF1(vUNh2O7nLwdF1eTkEfCYSm8t):
		while b46fBrugtPDSYspzMQIx(u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪพ") in list(vUNh2O7nLwdF1eTkEfCYSm8t.statusDICT.values()): Mrx2OeZV1LNjBsQ58Savi7.sleep(oh1JUWa3LdnqTpz5(u"࠷࠮࠱࠲࠳ᓿ"))
def indzKbDHVr1jptmv4fW5():
	NfKOPmGr2StWoEdMaRI5euc4wqZ1 = BBwb2NzsHE.getSetting(b46fBrugtPDSYspzMQIx(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧฟ"))
	if NfKOPmGr2StWoEdMaRI5euc4wqZ1==K0dHTfq6P73sD8lWLZpoh:
		W85bmTjGqLAwyzoP4EB,C6Csp0jDBaEKYAPZ5 = Vt4ELHXZP6(u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧภ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࡈࡤࡰࡸ࡫ᝀ")
		return W85bmTjGqLAwyzoP4EB,C6Csp0jDBaEKYAPZ5
	try: A73K6zLXIgFROeCHJQi0Pbos.makedirs(HnMP40juJfr6L1mexbWBV)
	except: pass
	W85bmTjGqLAwyzoP4EB,C6Csp0jDBaEKYAPZ5 = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪม"),cg94WALw5orUhvtHSfNO(u"ࡗࡶࡺ࡫ᝁ")
	BBYR7DjwGUrVIAPix4JHe9Kvh = [jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࠸࠯࠷࠱࠴ࠬย"),cg94WALw5orUhvtHSfNO(u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫร"),ebT9xRB63E(u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭ฤ"),Wbwj0o5gsXQ8F2f(u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭ล"),xmTX9Aeidq8cVhY(u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧฦ"),Yr0wo7FaSHx(u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨว"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩศ"),GVPK9Ziaho6U2ySLj(u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪษ"),WfgnOq9Fd4lhMSQpK5(u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫส"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬห"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࠵࠴࠷࠺࠮࠱࠳࠱࠵࠹࠭ฬ")]
	y9kF0Mj5mh76Wo1b2xtLS = BBYR7DjwGUrVIAPix4JHe9Kvh[-tjoHEAGv2XkrMBsVfCyp5U(u"࠱ᔀ")]
	uGaP9g6QekbN1WV = gVGcSPqfTBC8Z0u(y9kF0Mj5mh76Wo1b2xtLS)
	ggvCYlMLXi = gVGcSPqfTBC8Z0u(K0dHTfq6P73sD8lWLZpoh)
	if ggvCYlMLXi>uGaP9g6QekbN1WV:
		W85bmTjGqLAwyzoP4EB = vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪอ")
	return W85bmTjGqLAwyzoP4EB,C6Csp0jDBaEKYAPZ5
def HmcBIaR5TZM6wi0kYLgSxlNUOsG():
	if ebT9xRB63E(u"࠲ᔁ"):
		dd8CfVaLeIAFQN09WGTMw = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠲ᔂ")
		for IQhY9WqUXEoCsZaD52b0cKHd1Fy3zP,FGhMSo4KryQCW60nubBf3vJizLYt,G6xvk7zXYPqy4aofmTjRbMCd in A73K6zLXIgFROeCHJQi0Pbos.walk(FFoYQNgfsy,topdown=C0CbfZuXJM(u"ࡊࡦࡲࡳࡦᝂ")):
			dd8CfVaLeIAFQN09WGTMw += len(G6xvk7zXYPqy4aofmTjRbMCd)
	if dd8CfVaLeIAFQN09WGTMw>trSQHvP4aqBWFKxN5bZgXCu(u"࠸࠴࠵࠶ᔃ"): IN1vbO8YfAu05Qyi7jMVwkxSE(FFoYQNgfsy,Vt4ELHXZP6(u"࡚ࡲࡶࡧᝄ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡋࡧ࡬ࡴࡧᝃ"))
	return
def XXK8RxypkNAH2tgoq79mjICZ(sXPuroaMIYnl,MpTK2YaAjI4NWtiGcC3PQg):
	llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq = vlW6K1g8Xo35mPYbyO2GS(u"ࡕࡴࡸࡩᝆ"),b46fBrugtPDSYspzMQIx(u"ࡆࡢ࡮ࡶࡩᝅ"),b46fBrugtPDSYspzMQIx(u"ࡆࡢ࡮ࡶࡩᝅ")
	ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,Z9IXhMpLKqWlNjo4QvV,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = sXPuroaMIYnl
	zTVOBWjdwi2GZg7lpvS4xCFADY = ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,Z9IXhMpLKqWlNjo4QvV,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,b098bsyjUud(u"ࠫࠬฮ"),WFJYy6c9CKV4rdh27NjtILZ5HgRv
	ocq9aTtSF2 = int(rCBzYkXesGinqfjWdMJ0I6EuthRAg1)
	GRzamifuPTrsQA = int(ocq9aTtSF2%cg94WALw5orUhvtHSfNO(u"࠵࠵ᔄ"))
	Q8QglLCU5P = int(ocq9aTtSF2/YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠶࠶ᔅ"))
	PP3E92SoUfDriM = BBwb2NzsHE.getSetting(Wbwj0o5gsXQ8F2f(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬฯ"))
	if not PP3E92SoUfDriM: BBwb2NzsHE.setSetting(vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭ะ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡂࡗࡗࡓࠬั"))
	IGMzkHLKO8,C6Csp0jDBaEKYAPZ5 = indzKbDHVr1jptmv4fW5()
	if C6Csp0jDBaEKYAPZ5:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(WfgnOq9Fd4lhMSQpK5(u"ࠨࠩา"),Vt4ELHXZP6(u"ࠩࠪำ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ิ"),ebT9xRB63E(u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫี")+K0dHTfq6P73sD8lWLZpoh)
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,CC4UDLW6brf(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨึ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩื"))
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,CC4UDLW6brf(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒุࠪ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍูࠩ"))
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,G5TxeI0ND4ztC6(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑฺࠬ"),b46fBrugtPDSYspzMQIx(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ฻"))
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ฼"),Vt4ELHXZP6(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪ฽"))
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,GVPK9Ziaho6U2ySLj(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ฾"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭฿"))
		BBwb2NzsHE.setSetting(VVtQk9vwe7(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨเ"),u2NDjURZVHlmdc0(u"ࠩࠪแ"))
		BBwb2NzsHE.setSetting(Yr0wo7FaSHx(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡢࡳࡣ࡮ࡥࠬโ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࠬใ"))
		BBwb2NzsHE.setSetting(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨไ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࠧๅ"))
		BBwb2NzsHE.setSetting(trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡷࡪࡲࡨࡥ࠳ࠪๆ"),cg94WALw5orUhvtHSfNO(u"ࠨࠩ็"))
		BBwb2NzsHE.setSetting(G5TxeI0ND4ztC6(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ่ࠫ"),cg94WALw5orUhvtHSfNO(u"้ࠪࠫ"))
		BBwb2NzsHE.setSetting(vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ๊࠭"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"๋ࠬ࠭"))
		BBwb2NzsHE.setSetting(oh1JUWa3LdnqTpz5(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ์"),C0CbfZuXJM(u"ࠧࠨํ"))
		BBwb2NzsHE.setSetting(GVPK9Ziaho6U2ySLj(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ๎"),oh1JUWa3LdnqTpz5(u"ࠩࠪ๏"))
		BBwb2NzsHE.setSetting(WfgnOq9Fd4lhMSQpK5(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ๐"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠬ๑"))
		BBwb2NzsHE.setSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ๒"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࠧ๓"))
		BBwb2NzsHE.setSetting(ebT9xRB63E(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠲ࠩ๔"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠩ๕"))
		BBwb2NzsHE.setSetting(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠵ࠫ๖"),GVPK9Ziaho6U2ySLj(u"ࠪࠫ๗"))
		BBwb2NzsHE.setSetting(Yr0wo7FaSHx(u"ࠫࡦࡼ࠮ࡧࡣ࡬ࡰࡪࡪ࠮ࡴࡥࡤࡶࡵ࡫ࡰࡳࡱࡻࡽ࠸࠭๘"),b098bsyjUud(u"ࠬ࠭๙"))
		import COH7BKApEP
		if IGMzkHLKO8==oh1JUWa3LdnqTpz5(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭๚"):
			b6kj4LJ5tzTeOMQi(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡏࡑࡗࡍࡈࡋࠧ๛"),vlW6K1g8Xo35mPYbyO2GS(u"ࠨ࠰ࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡗࡎࡓࡐࡍࡇ࡙ࠣࡕࡊࡁࡕࡇࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧ๜")+QfEL1VroTPIFZkmzjv5O+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࠣࡡࠬ๝"))
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,KylMx0kfTOrG(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ๞"))
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ๟"))
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,b46fBrugtPDSYspzMQIx(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ๠"))
			jplLPaWg54UydbZrNn(GVPK9Ziaho6U2ySLj(u"ࡖࡵࡹࡪᝇ"),[tnQMXOP5mgZVI])
		else:
			b6kj4LJ5tzTeOMQi(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡎࡐࡖࡌࡇࡊ࠭๡"),vdHRKkIgTp56Je1OuNo(u"ࠧ࠯ࠢࠣࡅࡷࡧࡢࡪࡥ࡙࡭ࡩ࡫࡯ࡴࠢࡘࡴࡩࡧࡴࡦࠢࡗࡽࡵ࡫࠺ࠡࠢࡉ࡙ࡑࡒࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ๢")+QfEL1VroTPIFZkmzjv5O+Yr0wo7FaSHx(u"ࠨࠢࡠࠫ๣"))
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(C0CbfZuXJM(u"ࠩࠪ๤"),A6Iyo7eXrq2RtMmDxWj(u"ࠪࠫ๥"),WfgnOq9Fd4lhMSQpK5(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ๦"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ๧"))
			jplLPaWg54UydbZrNn(Wbwj0o5gsXQ8F2f(u"ࡉࡥࡱࡹࡥᝈ"),[])
			CHPE7xQVoMzsLhlKmnNgudSaRp4U(Vt4ELHXZP6(u"ࡊࡦࡲࡳࡦᝉ"))
			COH7BKApEP.moO0HksFWS7NyZ()
			COH7BKApEP.w2chBfzYG4FlZR7QIbJHTyoKrdv(vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭๨"),b098bsyjUud(u"ࡋࡧ࡬ࡴࡧᝊ"))
			COH7BKApEP.w2chBfzYG4FlZR7QIbJHTyoKrdv(VVtQk9vwe7(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ๩"),Vt4ELHXZP6(u"ࡌࡡ࡭ࡵࡨᝋ"))
			COH7BKApEP.wfRngJdl2PDzHaXW(Yr0wo7FaSHx(u"ࡆࡢ࡮ࡶࡩᝌ"))
			COH7BKApEP.LaqMoTyPh6J8sDCAN5IljkQXG91gp(DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪᝍ"))
			COH7BKApEP.Sx57dzTjBRuZ1YE4qWtV3(KylMx0kfTOrG(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭๪"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ๫"),Wbwj0o5gsXQ8F2f(u"ࡈࡤࡰࡸ࡫ᝎ"))
			try:
				fs28lh4iBUmtJHb3ePx = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,Wbwj0o5gsXQ8F2f(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ๬"),Yr0wo7FaSHx(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ๭"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ๮"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ๯"))
				AitzIeM3fLmBCFru7gxPO = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon(id=C0CbfZuXJM(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ๰"))
				AitzIeM3fLmBCFru7gxPO.setSetting(u2NDjURZVHlmdc0(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧ๱"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡩࡥࡱࡹࡥࠨ๲"))
			except: pass
			try:
				fs28lh4iBUmtJHb3ePx = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ๳"),CC4UDLW6brf(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ๴"),GVPK9Ziaho6U2ySLj(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬ๵"),u2NDjURZVHlmdc0(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ๶"))
				AitzIeM3fLmBCFru7gxPO = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon(id=CC4UDLW6brf(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ๷"))
				AitzIeM3fLmBCFru7gxPO.setSetting(A6Iyo7eXrq2RtMmDxWj(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫ๸"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩ࠶ࠫ๹"))
			except: pass
			try:
				fs28lh4iBUmtJHb3ePx = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,A6Iyo7eXrq2RtMmDxWj(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ๺"),vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ๻"),u2NDjURZVHlmdc0(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ๼"),b098bsyjUud(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ๽"))
				AitzIeM3fLmBCFru7gxPO = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon(id=Yr0wo7FaSHx(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ๾"))
				AitzIeM3fLmBCFru7gxPO.setSetting(oh1JUWa3LdnqTpz5(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭๿"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࠵ࠫ຀"))
			except: pass
		kOfDHhMnuAxQoBpWTeL = qqlgo4zmvG7sYR(tgjCPKlcGephBE8ka)
		kOfDHhMnuAxQoBpWTeL = qqlgo4zmvG7sYR(KoULXHCRWtulrsM1cP)
		BBwb2NzsHE.setSetting(ebT9xRB63E(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧກ"),K0dHTfq6P73sD8lWLZpoh)
		COH7BKApEP.g9geWoX2BkcOJYUCGIfli830vbpr(u2NDjURZVHlmdc0(u"ࡉࡥࡱࡹࡥᝏ"))
		return
	y9sfZeW5tbQpkPHKxg7jDS = BBwb2NzsHE.getSetting(Vt4ELHXZP6(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨຂ"))
	llxDWyvLpAEwCkbJSN5hMr = DDWps8j5MkOtw4JXG2nxVrE7g(MpTK2YaAjI4NWtiGcC3PQg)
	HimZ5nCXgVaA08yRFbN = DDWps8j5MkOtw4JXG2nxVrE7g(q9fpxUJbiKc6us4)
	Ub3RVxkQ8SrPDC0ltfWjZvhKnzLe = [NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠶ᔍ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠱࠶ᔇ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲࠹ᔈ"),Yr0wo7FaSHx(u"࠳࠼ᔉ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠸࠶ᔆ"),tvdQHb10PhNmuy6(u"࠸࠺ᔌ"),u2NDjURZVHlmdc0(u"࠸࠴ᔊ"),VVtQk9vwe7(u"࠹࠸ᔋ")]
	UU7WImCJ1ZavQsN9SA2O4Fo = [xmTX9Aeidq8cVhY(u"࠰ᔕ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠲࠷ᔏ"),tvdQHb10PhNmuy6(u"࠳࠺ᔐ"),cg94WALw5orUhvtHSfNO(u"࠴࠽ᔑ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠲࠷ᔎ"),b098bsyjUud(u"࠹࠴ᔔ"),GVPK9Ziaho6U2ySLj(u"࠹࠵ᔒ"),GVPK9Ziaho6U2ySLj(u"࠺࠹ᔓ")]
	CnMJEGHYi0 = Q8QglLCU5P not in UU7WImCJ1ZavQsN9SA2O4Fo
	iXwhISG8syMFZ = Q8QglLCU5P in [b46fBrugtPDSYspzMQIx(u"࠶࠸ᔙ"),Wbwj0o5gsXQ8F2f(u"࠳࠺ᔖ"),tjoHEAGv2XkrMBsVfCyp5U(u"࠺࠵ᔘ"),xmTX9Aeidq8cVhY(u"࠹࠵ᔗ")]
	tFgZXPBNcjpx5z87y4TSK = ocq9aTtSF2 in [C0CbfZuXJM(u"࠸࠶࠶ᔛ"),cg94WALw5orUhvtHSfNO(u"࠷࠽࠰ᔚ")]
	NNtgx0fRAv7 = (CnMJEGHYi0 or iXwhISG8syMFZ) and not tFgZXPBNcjpx5z87y4TSK
	LBMWkC0fITFE8cH2lRgAy5Jjd = y9sfZeW5tbQpkPHKxg7jDS!=ebT9xRB63E(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ຃") and (y9sfZeW5tbQpkPHKxg7jDS or not neEs3K9mgi7CJhaODRATXrqo)
	sdqbmLci2DawfenSBCz = cg94WALw5orUhvtHSfNO(u"࠭ࡴࡺࡲࡨࡁࠬຄ") in y9sfZeW5tbQpkPHKxg7jDS
	JJBXOKSLRA = ocq9aTtSF2 in [NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠴࠺࠶ᔦ"),VVtQk9vwe7(u"࠵࠻࠸ᔧ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶࠼࠳ᔨ"),C0CbfZuXJM(u"࠷࠶࠵ᔢ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠱࠷࠷ᔣ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲࠸࠹ᔤ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠳࠹࠻ᔥ"),trSQHvP4aqBWFKxN5bZgXCu(u"࠶࠼࠸ᔡ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠹࠹࠵ᔞ"),VVtQk9vwe7(u"࠷࠷࠴ᔜ"),b098bsyjUud(u"࠸࠸࠶ᔝ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠺࠺࠹ᔟ"),tvdQHb10PhNmuy6(u"࠻࠻࠻ᔠ")]
	VH5hnQa7CPSR1tMlZ03Wpx8 = GRzamifuPTrsQA==cg94WALw5orUhvtHSfNO(u"࠿ᔩ") or ocq9aTtSF2 in [Yr0wo7FaSHx(u"࠲࠶࠸ᔫ"),tjoHEAGv2XkrMBsVfCyp5U(u"࠸࠵࠻ᔭ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠷࠵࠷ᔬ"),GVPK9Ziaho6U2ySLj(u"࠴࠶ᔪ")]
	QHFIyRe6rCkg5uMnU820Oq4twWTLo = not JJBXOKSLRA
	g4qE9IQ0yoTZjbdCsRW7BH = not VH5hnQa7CPSR1tMlZ03Wpx8
	k7B6Ea31NfuoAjDnZFlIeMbLO = llxDWyvLpAEwCkbJSN5hMr in [G5TxeI0ND4ztC6(u"ࠧࠨ຅"),tvdQHb10PhNmuy6(u"ࠨ࠰࠱ࠫຆ")]
	BC2MeqlsZ3S4UwGLtikfEW1PxAdnav = k7B6Ea31NfuoAjDnZFlIeMbLO or QHFIyRe6rCkg5uMnU820Oq4twWTLo
	KMvmw5rjeE = k7B6Ea31NfuoAjDnZFlIeMbLO or g4qE9IQ0yoTZjbdCsRW7BH or sdqbmLci2DawfenSBCz
	lpUGcLEfZ5ATR7kzC = ocq9aTtSF2 not in [C0CbfZuXJM(u"࠳࠸࠳ᔲ"),xmTX9Aeidq8cVhY(u"࠶࠻࠷ᔮ"),A6Iyo7eXrq2RtMmDxWj(u"࠴࠹࠹ᔳ"),Wbwj0o5gsXQ8F2f(u"࠸࠷࠱ᔰ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠸࠹࠰ᔯ"),b098bsyjUud(u"࠵࠵࠲ᔱ")]
	if PP3E92SoUfDriM==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡖࡘࡔࡖࠧງ"): z4ECajx3LwTbVko1XyQu2G6v7JhA = VH5hnQa7CPSR1tMlZ03Wpx8 or JJBXOKSLRA
	else: z4ECajx3LwTbVko1XyQu2G6v7JhA = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࡘࡷࡻࡥᝐ")
	GGaS3gAByR = Q8QglLCU5P in [tjoHEAGv2XkrMBsVfCyp5U(u"࠻࠹ᔵ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠺࠹ᔴ")]
	OHpYZR8JnDN4Tji = ocq9aTtSF2 in [tjoHEAGv2XkrMBsVfCyp5U(u"࠷࠾࠰ᔶ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠽࠲࠱ᔷ")]
	EgPoYfwau5jlrWG1zA0cL9 = not GGaS3gAByR and not OHpYZR8JnDN4Tji
	ssNkl4WwCg = BC2MeqlsZ3S4UwGLtikfEW1PxAdnav and KMvmw5rjeE and lpUGcLEfZ5ATR7kzC and z4ECajx3LwTbVko1XyQu2G6v7JhA and EgPoYfwau5jlrWG1zA0cL9
	kn2QpzWflLbidIZ9oM45yrOUPSu = lpUGcLEfZ5ATR7kzC and z4ECajx3LwTbVko1XyQu2G6v7JhA and EgPoYfwau5jlrWG1zA0cL9
	QqVJ1vwfzK7Ny6bEe5H0IXZRAFiLcj = kn2QpzWflLbidIZ9oM45yrOUPSu
	jjla1mAvLiI6EynZukWpP = BBwb2NzsHE.getSetting(DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡲࡵࡳࡻ࡯ࡤࡦࡴࠪຈ"))
	sPwHIt1BkC2VGFNvgl5Q = BBwb2NzsHE.getSetting(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧຉ"))
	if ebT9xRB63E(u"࠱ᔸ") and LBMWkC0fITFE8cH2lRgAy5Jjd and ssNkl4WwCg:
		EwL6UaBtSfseznbO = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,vdHRKkIgTp56Je1OuNo(u"ࠬࡲࡩࡴࡶࠪຊ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ຋")+jjla1mAvLiI6EynZukWpP+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡠࠩຌ")+sPwHIt1BkC2VGFNvgl5Q,zTVOBWjdwi2GZg7lpvS4xCFADY)
		if EwL6UaBtSfseznbO:
			b6kj4LJ5tzTeOMQi(CC4UDLW6brf(u"ࠨࠩຍ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠩ࠱ࠤࠥࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫຎ")+jjla1mAvLiI6EynZukWpP+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡣࠬຏ")+sPwHIt1BkC2VGFNvgl5Q+cg94WALw5orUhvtHSfNO(u"ࠫࠥࠦࠠࡍࡱࡤࡨ࡮ࡴࡧࠡ࡯ࡨࡲࡺࠦࡦࡳࡱࡰࠤࡨࡧࡣࡩࡧࠪຐ"))
			if A6Iyo7eXrq2RtMmDxWj(u"࠲ᔹ") and sdqbmLci2DawfenSBCz:
				NNhmLEzSurYxDM6yf7oG2tlZj = []
				from NDqbtm1MlB import TnwuY7lhRX0HF54axOAcgQdyPJ
				from HJO9W03B54 import GJk0y6NbYP5jOfpeoITHi,jzoDS2dIB6mULq
				QQ2OAL4dBp7W9Mx3SPHKR = TnwuY7lhRX0HF54axOAcgQdyPJ
				T3dIHGKzixVWSpyLvYbR5o4cONXg2 = GJk0y6NbYP5jOfpeoITHi()
				OA7Fa9i6S3eyu4XzI = y9sfZeW5tbQpkPHKxg7jDS
				XwbhoyANBKU9icx8JdtrqgHTIF5k,Zi7sV9TxboHN8214WeMOJzK,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x,oZuwgnvJklhRB,a9AoXCxdZzQ,VtToBcL0UZznyMa8kXwqePsNl,odeHjiZAxu018CRkrGnvQL,TIXMiVHh5kvUdYAFglb,kdje6SfVRNI = NmPa38tGQK2x(OA7Fa9i6S3eyu4XzI)
				Q2J5mX1FUNsK6Wg3tq = XwbhoyANBKU9icx8JdtrqgHTIF5k,Zi7sV9TxboHN8214WeMOJzK,YzFWKTy3jiJGsUEk8XRIgDNtB4u7x,oZuwgnvJklhRB,a9AoXCxdZzQ,VtToBcL0UZznyMa8kXwqePsNl,odeHjiZAxu018CRkrGnvQL,vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠭ຑ"),kdje6SfVRNI
				for MTklReJ6VdpCD0QFcAwXj in EwL6UaBtSfseznbO:
					L4SrK7Iv8F5GAeliq1mRx9p = MTklReJ6VdpCD0QFcAwXj[vdHRKkIgTp56Je1OuNo(u"࠭࡭ࡦࡰࡸࡍࡹ࡫࡭ࠨຒ")]
					if L4SrK7Iv8F5GAeliq1mRx9p==Q2J5mX1FUNsK6Wg3tq or MTklReJ6VdpCD0QFcAwXj[Wbwj0o5gsXQ8F2f(u"ࠧ࡮ࡱࡧࡩࠬຓ")] in [u2NDjURZVHlmdc0(u"࠵࠺࠺ᔻ"),vlW6K1g8Xo35mPYbyO2GS(u"࠴࠺࠴ᔺ")]:
						MTklReJ6VdpCD0QFcAwXj = x2Sfo9yeIrFPsVjH8kaO4X6nhB0d71(L4SrK7Iv8F5GAeliq1mRx9p,QQ2OAL4dBp7W9Mx3SPHKR,T3dIHGKzixVWSpyLvYbR5o4cONXg2)
						if MTklReJ6VdpCD0QFcAwXj[u2NDjURZVHlmdc0(u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫດ")]:
							FcsndEgfOGLUPJ = jzoDS2dIB6mULq(T3dIHGKzixVWSpyLvYbR5o4cONXg2,L4SrK7Iv8F5GAeliq1mRx9p,MTklReJ6VdpCD0QFcAwXj[CC4UDLW6brf(u"ࠩࡱࡩࡼࡶࡡࡵࡪࠪຕ")])
							MTklReJ6VdpCD0QFcAwXj[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩຖ")] = FcsndEgfOGLUPJ+MTklReJ6VdpCD0QFcAwXj[WfgnOq9Fd4lhMSQpK5(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࡤࡳࡥ࡯ࡷࠪທ")]
					NNhmLEzSurYxDM6yf7oG2tlZj.append(MTklReJ6VdpCD0QFcAwXj)
				BBwb2NzsHE.setSetting(VVtQk9vwe7(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩຘ"),b098bsyjUud(u"࠭ࠧນ"))
				if ajLz9PfYbTigyorvZhW4IOFn==b46fBrugtPDSYspzMQIx(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧບ"): pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧປ")+jjla1mAvLiI6EynZukWpP+b46fBrugtPDSYspzMQIx(u"ࠩࡢࠫຜ")+sPwHIt1BkC2VGFNvgl5Q,zTVOBWjdwi2GZg7lpvS4xCFADY,NNhmLEzSurYxDM6yf7oG2tlZj,DkRgFyVIBM85OA)
			else: NNhmLEzSurYxDM6yf7oG2tlZj = EwL6UaBtSfseznbO
			if ajLz9PfYbTigyorvZhW4IOFn==pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡪࡴࡲࡤࡦࡴࠪຝ") and llxDWyvLpAEwCkbJSN5hMr!=oh1JUWa3LdnqTpz5(u"ࠫ࠳࠴ࠧພ") and NNtgx0fRAv7: CxvecthowDqgba7mOslpXLPMBfVz()
			k2kDxZJHsWwv = zzdJUmRVlxbjAoDFMPuvKSBa6NqT7i(zTVOBWjdwi2GZg7lpvS4xCFADY,NNhmLEzSurYxDM6yf7oG2tlZj,llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq)
			return
	elif ajLz9PfYbTigyorvZhW4IOFn==WfgnOq9Fd4lhMSQpK5(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬຟ") and y9sfZeW5tbQpkPHKxg7jDS==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡒࡆࡈࡕࡉࡘࡎࡅࡅࠩຠ") and kn2QpzWflLbidIZ9oM45yrOUPSu:
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࡤ࠭ມ")+jjla1mAvLiI6EynZukWpP+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡡࠪຢ")+sPwHIt1BkC2VGFNvgl5Q,zTVOBWjdwi2GZg7lpvS4xCFADY)
	if neEs3K9mgi7CJhaODRATXrqo:
		if cg94WALw5orUhvtHSfNO(u"ࠩࡢࠫຣ") in neEs3K9mgi7CJhaODRATXrqo: tGpTlbqz7osyj2c,JJMn9Er4NAtG = neEs3K9mgi7CJhaODRATXrqo.split(xmTX9Aeidq8cVhY(u"ࠪࡣࠬ຤"),trSQHvP4aqBWFKxN5bZgXCu(u"࠵ᔼ"))
		else: tGpTlbqz7osyj2c,JJMn9Er4NAtG = neEs3K9mgi7CJhaODRATXrqo,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠬລ")
		if tGpTlbqz7osyj2c in [xmTX9Aeidq8cVhY(u"ࠬ࠷ࠧ຦"),b098bsyjUud(u"࠭࠲ࠨວ"),b098bsyjUud(u"ࠧ࠴ࠩຨ"),KylMx0kfTOrG(u"ࠨ࠶ࠪຩ"),ebT9xRB63E(u"ࠩ࠸ࠫສ")] and JJMn9Er4NAtG:
			from HJO9W03B54 import l9ue7xUqdEKnkiQS8r0TbLDtsg5
			l9ue7xUqdEKnkiQS8r0TbLDtsg5(neEs3K9mgi7CJhaODRATXrqo)
			BBwb2NzsHE.setSetting(tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧຫ"),QfEL1VroTPIFZkmzjv5O)
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(VVtQk9vwe7(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨຬ"))
			return
		elif tGpTlbqz7osyj2c==A6Iyo7eXrq2RtMmDxWj(u"ࠬ࠼ࠧອ"):
			if JJMn9Er4NAtG==oh1JUWa3LdnqTpz5(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨຮ"): sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(vdHRKkIgTp56Je1OuNo(u"๋ࠧำฯํࠥอไศ่อ฼ฬืࠧຯ"),u2NDjURZVHlmdc0(u"ࠨฮสี๏ࠦแฮื้้ࠣ็ࠠศๆอั๊๐ไࠨະ"))
			elif JJMn9Er4NAtG==oh1JUWa3LdnqTpz5(u"ࠩࡇࡉࡑࡋࡔࡆࠩັ"): ocq9aTtSF2 = Wbwj0o5gsXQ8F2f(u"࠸࠹࠴ᔽ")
			mL7BVKcSygkuoPbWlEF4YD = rGxOVv8jzm(ajLz9PfYbTigyorvZhW4IOFn,HimZ5nCXgVaA08yRFbN,Z9IXhMpLKqWlNjo4QvV,ocq9aTtSF2,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧາ"))
			return
		elif neEs3K9mgi7CJhaODRATXrqo==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫ࠼࠭ຳ"):
			from ogWviPNB8U import q2vWLiRTVYUAXIQ0486e
			q2vWLiRTVYUAXIQ0486e()
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩິ"))
			return
		elif neEs3K9mgi7CJhaODRATXrqo==u2NDjURZVHlmdc0(u"࠭࠸ࠨີ"):
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(Vt4ELHXZP6(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ຶ")+f3pCnmFaVYx4zc1MNGBe5+A6Iyo7eXrq2RtMmDxWj(u"ࠨࡁࡰࡳࡩ࡫࠽ࠨື")+str(rCBzYkXesGinqfjWdMJ0I6EuthRAg1)+GVPK9Ziaho6U2ySLj(u"ࠩࠩࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲຸࠪࠩ"))
			return
		elif neEs3K9mgi7CJhaODRATXrqo==Wbwj0o5gsXQ8F2f(u"ࠪ࠽ູࠬ"):
			BBwb2NzsHE.setSetting(vdHRKkIgTp56Je1OuNo(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ຺"),cg94WALw5orUhvtHSfNO(u"ࠬࡘࡅࡒࡗࡈࡗ࡙ࡋࡄࠨົ"))
			Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(A6Iyo7eXrq2RtMmDxWj(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪຼ"))
			return
	if BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭ຽ")) not in [u2NDjURZVHlmdc0(u"ࠨࡃࡘࡘࡔ࠭຾"),GVPK9Ziaho6U2ySLj(u"ࠩࡖࡘࡔࡖࠧ຿"),ebT9xRB63E(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫເ")]:
		BBwb2NzsHE.setSetting(b46fBrugtPDSYspzMQIx(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪແ"),GVPK9Ziaho6U2ySLj(u"ࠬࡇࡕࡕࡑࠪໂ"))
	if not BBwb2NzsHE.getSetting(CC4UDLW6brf(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ໃ")): BBwb2NzsHE.setSetting(KylMx0kfTOrG(u"ࠧࡢࡸ࠱ࡨࡳࡹࠧໄ"),vXU90oAP4jJZzsw51SkNYu8Q6bF[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶ᔾ")])
	HEx703heJAVCGjcFpDonS = BBwb2NzsHE.getSetting(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨ໅"))
	HEx703heJAVCGjcFpDonS = Vt4ELHXZP6(u"࠰ᔿ") if not HEx703heJAVCGjcFpDonS else int(HEx703heJAVCGjcFpDonS)
	if not HEx703heJAVCGjcFpDonS or not KylMx0kfTOrG(u"࠱ᕀ")<=uZ7xiFaBvSrWG2mXjITp-HEx703heJAVCGjcFpDonS<=DkRgFyVIBM85OA:
		db6imBFafuwc7 = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=HmcBIaR5TZM6wi0kYLgSxlNUOsG)
		db6imBFafuwc7.start()
		BBwb2NzsHE.setSetting(pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩໆ"),str(uZ7xiFaBvSrWG2mXjITp))
	WnoefwMk0JxaTNXy1IQEDbZFHtl = BBwb2NzsHE.getSetting(vdHRKkIgTp56Je1OuNo(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧ໇"))
	WnoefwMk0JxaTNXy1IQEDbZFHtl = b46fBrugtPDSYspzMQIx(u"࠲ᕁ") if not WnoefwMk0JxaTNXy1IQEDbZFHtl else int(WnoefwMk0JxaTNXy1IQEDbZFHtl)
	if not WnoefwMk0JxaTNXy1IQEDbZFHtl or not Yr0wo7FaSHx(u"࠳ᕂ")<=uZ7xiFaBvSrWG2mXjITp-WnoefwMk0JxaTNXy1IQEDbZFHtl<=UHnG2wYuIQWKN38B4:
		import COH7BKApEP
		COH7BKApEP.uuzerSw4k8bt3QKD9cAjhgBvPMim(b098bsyjUud(u"ࡌࡡ࡭ࡵࡨᝒ"),ebT9xRB63E(u"࡙ࡸࡵࡦᝑ"))
		BBwb2NzsHE.setSetting(cg94WALw5orUhvtHSfNO(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨ່"),str(uZ7xiFaBvSrWG2mXjITp))
	C5nXbEc6GAmJM7sPBjFNRQ8 = BBwb2NzsHE.getSetting(C0CbfZuXJM(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ້ࠪ"))
	UjsIhvXm1J = zzkqvb6eSVxXAgUZ0ChptIR3w(BBwb2NzsHE.getSetting(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ໊ࠧ")))
	UjsIhvXm1J = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠴ᕃ") if not UjsIhvXm1J else int(UjsIhvXm1J)
	if C5nXbEc6GAmJM7sPBjFNRQ8 in [hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠨ໋"),KylMx0kfTOrG(u"ࠨࡑࡏࡈࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧ໌"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡑࡉ࡜ࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨໍ")] or not UjsIhvXm1J or not A6Iyo7eXrq2RtMmDxWj(u"࠵ᕄ")<=uZ7xiFaBvSrWG2mXjITp-UjsIhvXm1J<=mjBa0HgvKnI4oWRd:
		yHqpuj3LYGP8Z6E9 = XjZeYzB5J0(u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩᝓ"),u2NDjURZVHlmdc0(u"ࡆࡢ࡮ࡶࡩᝓ"))
		BBwb2NzsHE.setSetting(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ໎"),QaMk1EXgidcunwJhAPRIWTy5lxHrbj(uZ7xiFaBvSrWG2mXjITp))
		if yHqpuj3LYGP8Z6E9:
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(Wbwj0o5gsXQ8F2f(u"ࠫัืศࠡ็ิอࠥษฮา๋ࠪ໏"),Wbwj0o5gsXQ8F2f(u"࡚ࠬࡲࡺࠢࡤ࡫ࡦ࡯࡮ࠨ໐"),Mrx2OeZV1LNjBsQ58Savi7=G5TxeI0ND4ztC6(u"࠷࠰࠱࠲ᕅ"))
			return
	yTHlPEcUWvFZR = zzkqvb6eSVxXAgUZ0ChptIR3w(BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ໑")))
	yTHlPEcUWvFZR = u2NDjURZVHlmdc0(u"࠰ᕆ") if not yTHlPEcUWvFZR else int(yTHlPEcUWvFZR)
	fO3G28PwMpev = zzkqvb6eSVxXAgUZ0ChptIR3w(BBwb2NzsHE.getSetting(CC4UDLW6brf(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ໒")))
	fO3G28PwMpev = b098bsyjUud(u"࠱ᕇ") if not fO3G28PwMpev else int(fO3G28PwMpev)
	if not yTHlPEcUWvFZR or not fO3G28PwMpev or not Yr0wo7FaSHx(u"࠲ᕈ")<=uZ7xiFaBvSrWG2mXjITp-fO3G28PwMpev<=yTHlPEcUWvFZR:
		HHXPxla5joSyBQv96s8hR = CC4UDLW6brf(u"࠴ᕉ")
		V9f6HBhKLvGEloucCNs8R0dMJZq = vlW6K1g8Xo35mPYbyO2GS(u"ࡈࡤࡰࡸ࡫᝕") if HRnwFcAJIxaoXEbYQ(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩ໓")) else KylMx0kfTOrG(u"ࡕࡴࡸࡩ᝔")
		if V9f6HBhKLvGEloucCNs8R0dMJZq:
			dnM34UCiobvTqW = nOhiJ5zmHfxwaItpB6XPcA(u2NDjURZVHlmdc0(u"ࡗࡶࡺ࡫᝖"))
			if len(dnM34UCiobvTqW)>GVPK9Ziaho6U2ySLj(u"࠵ᕊ"):
				b6kj4LJ5tzTeOMQi(b098bsyjUud(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ໔"),Vt4ELHXZP6(u"ࠪ࠲ࠥࠦࡓࡩࡱࡺ࡭ࡳ࡭ࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭໕")+QfEL1VroTPIFZkmzjv5O+C0CbfZuXJM(u"ࠫࠥࡣࠧ໖"))
				iZXua1gCvb9Y5xr,YqywcljIHsFzoXaf0T97,EGaITWmJw64udk7zZq2OAM,cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq,KPW9hQet1aZUu4H2b0lvSi7Rs = dnM34UCiobvTqW[vlW6K1g8Xo35mPYbyO2GS(u"࠵ᕋ")]
				N6SrZHYfqclvLaCIU7pWu1kdsJDK,FHuTUy4i1fGq = cFKVo2vauG0BRnXPmUdSpJCO6.split(KylMx0kfTOrG(u"ࠬࡢ࡮࠼࠽ࠪ໗"))
				del dnM34UCiobvTqW[Wbwj0o5gsXQ8F2f(u"࠶ᕌ")]
				k25qflJET39tVBDzRZxbLa = GpOkwndjsI27uM.sample(dnM34UCiobvTqW,WfgnOq9Fd4lhMSQpK5(u"࠱ᕍ"))
				iZXua1gCvb9Y5xr,YqywcljIHsFzoXaf0T97,EGaITWmJw64udk7zZq2OAM,cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq,KPW9hQet1aZUu4H2b0lvSi7Rs = k25qflJET39tVBDzRZxbLa[b098bsyjUud(u"࠱ᕎ")]
				EGaITWmJw64udk7zZq2OAM = Yr0wo7FaSHx(u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠ࠻ࠢࠪ໘")+iZXua1gCvb9Y5xr+G5TxeI0ND4ztC6(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ໙")+EGaITWmJw64udk7zZq2OAM
				sOu6vWYyjC9VREepAh10cXq = b098bsyjUud(u"ࠨวิืฬ๊ࠠาีส่ฮࠦไๅ็หี๊าࠧ໚")
				BFy7STa0tZ5nzcwm = Vt4ELHXZP6(u"ࠩส่ฯฮัฺษอࠫ໛")
				button0,button1 = cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq
				V3aynRltPbCuBHvwrxiITQ = [button0,button1,BFy7STa0tZ5nzcwm]
				hVxRXr9uOmNTC2Ug = A6Iyo7eXrq2RtMmDxWj(u"࠳ᕏ") if HRnwFcAJIxaoXEbYQ(Vt4ELHXZP6(u"࡛ࠪࡘ࡛ࡒࡇࡖ࠴࠽ࡖ࡚ࡅࡇ࡜࡛ࠫໜ")) else DItWNMaLOZ146CubYk8lfAwTy(u"࠴࠴ᕐ")
				WnbmLQXcr7JdDtRyEe = -xmTX9Aeidq8cVhY(u"࠽ᕑ")
				while WnbmLQXcr7JdDtRyEe<ebT9xRB63E(u"࠵ᕒ"):
					W9OeU1KIBXRxuZ4atD = GpOkwndjsI27uM.sample(V3aynRltPbCuBHvwrxiITQ,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠹ᕓ"))
					WnbmLQXcr7JdDtRyEe = VYEiZteQcrT7aqOBMRAyHC9(GVPK9Ziaho6U2ySLj(u"ࠫࠬໝ"),W9OeU1KIBXRxuZ4atD[Yr0wo7FaSHx(u"࠱ᕕ")],W9OeU1KIBXRxuZ4atD[pOIe6U1vWYC7Gh2udFBRgT(u"࠱ᕔ")],W9OeU1KIBXRxuZ4atD[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠴ᕖ")],N6SrZHYfqclvLaCIU7pWu1kdsJDK,EGaITWmJw64udk7zZq2OAM,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧໞ"),hVxRXr9uOmNTC2Ug,G5TxeI0ND4ztC6(u"࠹࠴ᕗ"))
					if WnbmLQXcr7JdDtRyEe==vdHRKkIgTp56Je1OuNo(u"࠵࠵ᕘ"): break
					from COH7BKApEP import rDcxWnkhEUCJ,U6y7OMTJCE
					if WnbmLQXcr7JdDtRyEe>=hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶ᕚ") and W9OeU1KIBXRxuZ4atD[WnbmLQXcr7JdDtRyEe]==V3aynRltPbCuBHvwrxiITQ[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶ᕙ")]:
						rDcxWnkhEUCJ()
						if WnbmLQXcr7JdDtRyEe>=Yr0wo7FaSHx(u"࠱ᕜ"): WnbmLQXcr7JdDtRyEe = -DItWNMaLOZ146CubYk8lfAwTy(u"࠹ᕛ")
					elif WnbmLQXcr7JdDtRyEe>=CC4UDLW6brf(u"࠲ᕝ") and W9OeU1KIBXRxuZ4atD[WnbmLQXcr7JdDtRyEe]==V3aynRltPbCuBHvwrxiITQ[cg94WALw5orUhvtHSfNO(u"࠵ᕞ")]:
						U6y7OMTJCE(WfgnOq9Fd4lhMSQpK5(u"ࡊࡦࡲࡳࡦ᝗"))
					if WnbmLQXcr7JdDtRyEe==-b46fBrugtPDSYspzMQIx(u"࠵ᕟ"): ArKbmeZFN7cRuvjfiHBJ0SEqd2l(trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧໟ"),Vt4ELHXZP6(u"ࠧࠨ໠"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ໡"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡำื่อࠢั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ࠢ็่ำื่อࠢสฺ่ำ๊ฮࠢฦาฯื้ࠠษะำ๋ࠥๆࠡษ็วั๎ศสࠢส่๊ะ่โำฬࠫ໢"))
				HHXPxla5joSyBQv96s8hR = Yr0wo7FaSHx(u"࠶ᕠ")
			else: HHXPxla5joSyBQv96s8hR = tjoHEAGv2XkrMBsVfCyp5U(u"࠶ᕡ")
		pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭໣"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ໤"),HHXPxla5joSyBQv96s8hR,iJnLmxA0ykozR98WXFQ4Ye3w)
	mL7BVKcSygkuoPbWlEF4YD = rGxOVv8jzm(ajLz9PfYbTigyorvZhW4IOFn,HimZ5nCXgVaA08yRFbN,Z9IXhMpLKqWlNjo4QvV,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	if CC4UDLW6brf(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ໥") in JJ23NOKSjik1hg8Ts7CXbevYzrQHU: W1WbMxkGeUlKTZn9yHrdQXNh = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࡙ࡸࡵࡦ᝘")
	if ajLz9PfYbTigyorvZhW4IOFn==oh1JUWa3LdnqTpz5(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭໦"):
		if llxDWyvLpAEwCkbJSN5hMr!=G5TxeI0ND4ztC6(u"ࠧ࠯࠰ࠪ໧") and NNtgx0fRAv7: CxvecthowDqgba7mOslpXLPMBfVz()
		if MPBU8HXFoN3Ocj>-hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠱ᕢ"):
			if (cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,vlW6K1g8Xo35mPYbyO2GS(u"ࠨ࡫ࡱࡸࠬ໨"),cg94WALw5orUhvtHSfNO(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ໩"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨ໪")) or ocq9aTtSF2 not in Ub3RVxkQ8SrPDC0ltfWjZvhKnzLe) and not HRnwFcAJIxaoXEbYQ(WfgnOq9Fd4lhMSQpK5(u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ໫")):
				from NDqbtm1MlB import TnwuY7lhRX0HF54axOAcgQdyPJ
				EwL6UaBtSfseznbO = VcU4CTxXzs7OF(TnwuY7lhRX0HF54axOAcgQdyPJ)
				k2kDxZJHsWwv = zzdJUmRVlxbjAoDFMPuvKSBa6NqT7i(zTVOBWjdwi2GZg7lpvS4xCFADY,EwL6UaBtSfseznbO,llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq)
				if mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲ᕣ") and EwL6UaBtSfseznbO and QqVJ1vwfzK7Ny6bEe5H0IXZRAFiLcj:
					pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,tvdQHb10PhNmuy6(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ໬")+jjla1mAvLiI6EynZukWpP+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭࡟ࠨ໭")+sPwHIt1BkC2VGFNvgl5Q,zTVOBWjdwi2GZg7lpvS4xCFADY,EwL6UaBtSfseznbO,DkRgFyVIBM85OA)
			else:
				wwxkRfBvlShcg72TKtbdyQrniEY.addDirectoryItem(MPBU8HXFoN3Ocj,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ໮")+f3pCnmFaVYx4zc1MNGBe5+Vt4ELHXZP6(u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ໯"),U6zsmRNGTL.ListItem(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦๅ็ࠢฯ๋ฬุใࠨ໰")))
				wwxkRfBvlShcg72TKtbdyQrniEY.addDirectoryItem(MPBU8HXFoN3Ocj,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭໱")+f3pCnmFaVYx4zc1MNGBe5+VVtQk9vwe7(u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫ໲"),U6zsmRNGTL.ListItem(tvdQHb10PhNmuy6(u"ࠬษแหฯ่ࠣฯ่ัฤࠢส่ฯ็วึ์็ࠫ໳")))
			wwxkRfBvlShcg72TKtbdyQrniEY.endOfDirectory(MPBU8HXFoN3Ocj,llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq)
	return
def rGxOVv8jzm(ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv):
	ocq9aTtSF2 = int(rCBzYkXesGinqfjWdMJ0I6EuthRAg1)
	Q8QglLCU5P = int(ocq9aTtSF2//C0CbfZuXJM(u"࠳࠳ᕤ"))
	if   Q8QglLCU5P==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠳ᕥ"):  from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠵ᕦ"):  from AAwCF26QUM 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Yr0wo7FaSHx(u"࠷ᕧ"):  from eaNkRwx1yn 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠹ᕨ"):  from yL5TAd0MKu 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠴ᕩ"):  from kMKnEbC9He 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,vYpMA3CxgcyR4VZJh)
	elif Q8QglLCU5P==A6Iyo7eXrq2RtMmDxWj(u"࠶ᕪ"):  from keuctiXzqO 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠸ᕫ"):  from xdPlLt2Wyu 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==pOIe6U1vWYC7Gh2udFBRgT(u"࠺ᕬ"):  from SN6YMRIvqW 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==trSQHvP4aqBWFKxN5bZgXCu(u"࠼ᕭ"):  from Sk7lb5PuGq 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==b46fBrugtPDSYspzMQIx(u"࠾ᕮ"):  from nc1wLfCoJm		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==ebT9xRB63E(u"࠷࠰ᕯ"): from CvOdySBEle 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D)
	elif Q8QglLCU5P==G5TxeI0ND4ztC6(u"࠱࠲ᕰ"): from uufmkNnLt8 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==pOIe6U1vWYC7Gh2udFBRgT(u"࠲࠴ᕱ"): from XMwnvWaRz8 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==DItWNMaLOZ146CubYk8lfAwTy(u"࠳࠶ᕲ"): from oosSm6jxUA		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vlW6K1g8Xo35mPYbyO2GS(u"࠴࠸ᕳ"): from Z5aTos0RvJ 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh,q9fpxUJbiKc6us4,UCjpzQwrZyNIe3kg1ThDvi0nb8)
	elif Q8QglLCU5P==Wbwj0o5gsXQ8F2f(u"࠵࠺ᕴ"): from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==ebT9xRB63E(u"࠶࠼ᕵ"): from JJBXOKSLRA		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==Yr0wo7FaSHx(u"࠷࠷ᕶ"): from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠱࠹ᕷ"): from IIg2kN63MV		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==A6Iyo7eXrq2RtMmDxWj(u"࠲࠻ᕸ"): from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==u2NDjURZVHlmdc0(u"࠴࠳ᕹ"): from KQk7oj83yq		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==CC4UDLW6brf(u"࠵࠵ᕺ"): from IIMrxCDoVP	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==A6Iyo7eXrq2RtMmDxWj(u"࠶࠷ᕻ"): from H8E7YByCDu		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠷࠹ᕼ"): from Nipbs3ZV5T	import LO5euqvXT1U3S7CaNlP	; mL7BVKcSygkuoPbWlEF4YD = LO5euqvXT1U3S7CaNlP(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸࠴ᕽ"): from MoLGRCrH0B 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==trSQHvP4aqBWFKxN5bZgXCu(u"࠲࠶ᕾ"): from llrz36PXkA 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==b098bsyjUud(u"࠳࠸ᕿ"): from NDqbtm1MlB 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==GVPK9Ziaho6U2ySLj(u"࠴࠺ᖀ"): from HJO9W03B54	import LO5euqvXT1U3S7CaNlP	; mL7BVKcSygkuoPbWlEF4YD = LO5euqvXT1U3S7CaNlP(ocq9aTtSF2,neEs3K9mgi7CJhaODRATXrqo)
	elif Q8QglLCU5P==cg94WALw5orUhvtHSfNO(u"࠵࠼ᖁ"): from Nipbs3ZV5T	import LO5euqvXT1U3S7CaNlP	; mL7BVKcSygkuoPbWlEF4YD = LO5euqvXT1U3S7CaNlP(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠶࠾ᖂ"): from mmpfc3Zqus	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠸࠶ᖃ"): from A3OWx6KM4Z		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==b46fBrugtPDSYspzMQIx(u"࠹࠱ᖄ"): from EN0lw9rZWi		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠳࠳ᖅ"): from ZHmMw1VgJL		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴࠵ᖆ"): from tvJDK3FQ92		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D)
	elif Q8QglLCU5P==DItWNMaLOZ146CubYk8lfAwTy(u"࠵࠷ᖇ"): from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠶࠹ᖈ"): from Ir6zUqvsmE		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==trSQHvP4aqBWFKxN5bZgXCu(u"࠷࠻ᖉ"): from iiz6XasOgk			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==cg94WALw5orUhvtHSfNO(u"࠸࠽ᖊ"): from sQDa3t4wub			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Wbwj0o5gsXQ8F2f(u"࠹࠸ᖋ"): from EOWJUYxVkQ 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==b46fBrugtPDSYspzMQIx(u"࠳࠺ᖌ"): from hcqNB7oPQX		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵࠲ᖍ"): from TISnj9iuNy	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh)
	elif Q8QglLCU5P==CC4UDLW6brf(u"࠶࠴ᖎ"): from TISnj9iuNy	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh)
	elif Q8QglLCU5P==GVPK9Ziaho6U2ySLj(u"࠷࠶ᖏ"): from UxFtyevGjX			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==KylMx0kfTOrG(u"࠸࠸ᖐ"): from sNgmYqG68o			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Wbwj0o5gsXQ8F2f(u"࠹࠺ᖑ"): from L8QxOYXrZV		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==u2NDjURZVHlmdc0(u"࠺࠵ᖒ"): from vvdISQL4Rr		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠴࠷ᖓ"): from DiCgabltxU			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵࠹ᖔ"): from DWkFCLHpqe		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠶࠻ᖕ"): from KGuyljzBC9		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==DItWNMaLOZ146CubYk8lfAwTy(u"࠷࠽ᖖ"): from dRoJIpX768		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==WfgnOq9Fd4lhMSQpK5(u"࠹࠵ᖗ"): from COH7BKApEP 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==WfgnOq9Fd4lhMSQpK5(u"࠺࠷ᖘ"): from FkOz6u1cKf 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Yr0wo7FaSHx(u"࠻࠲ᖙ"): from FkOz6u1cKf 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Yr0wo7FaSHx(u"࠵࠴ᖚ"): from NDqbtm1MlB 			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶࠶ᖛ"): from ogWviPNB8U	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,vYpMA3CxgcyR4VZJh)
	elif Q8QglLCU5P==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠷࠸ᖜ"): from cKzHS2f0kC 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==cg94WALw5orUhvtHSfNO(u"࠸࠺ᖝ"): from OOlZvwMeN2			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠹࠼ᖞ"): from qqpYambklH		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vlW6K1g8Xo35mPYbyO2GS(u"࠺࠾ᖟ"): from ujPHJy61Fa		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==tvdQHb10PhNmuy6(u"࠻࠹ᖠ"): from sW4IAwPJKt		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶࠱ᖡ"): from R0doJiwWQS			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==C0CbfZuXJM(u"࠷࠳ᖢ"): from JD5mnp3oqj			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==CC4UDLW6brf(u"࠸࠵ᖣ"): from Moswlz0SZm		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠹࠷ᖤ"): from xJzWy2Va0b	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==G5TxeI0ND4ztC6(u"࠺࠹ᖥ"): from cdm9Ne6MRP			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==WfgnOq9Fd4lhMSQpK5(u"࠻࠻ᖦ"): from Dx9UnVW5oN			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==CC4UDLW6brf(u"࠼࠶ᖧ"): from FC20VcwO6f			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠶࠸ᖨ"): from MKh7iAVYLX		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠷࠺ᖩ"): from kJpKT16hwG		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠸࠼ᖪ"): from MiCT6ZOEzs		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠺࠴ᖫ"): from EdGqrsc8W6			import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==CC4UDLW6brf(u"࠻࠶ᖬ"): from aCyfkwjhpQ	import LO5euqvXT1U3S7CaNlP	; mL7BVKcSygkuoPbWlEF4YD = LO5euqvXT1U3S7CaNlP(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==C0CbfZuXJM(u"࠼࠸ᖭ"): from aCyfkwjhpQ	import LO5euqvXT1U3S7CaNlP	; mL7BVKcSygkuoPbWlEF4YD = LO5euqvXT1U3S7CaNlP(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,ajLz9PfYbTigyorvZhW4IOFn,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==C0CbfZuXJM(u"࠽࠳ᖮ"): from BcR8wVCXW1	import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Vt4ELHXZP6(u"࠷࠵ᖯ"): from GGaS3gAByR		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠸࠷ᖰ"): from GGaS3gAByR		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠹࠹ᖱ"): from JJBXOKSLRA		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,vYpMA3CxgcyR4VZJh,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	elif Q8QglLCU5P==cg94WALw5orUhvtHSfNO(u"࠺࠻ᖲ"): from EVQ2mzC1PH 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠻࠽ᖳ"): from pKfXcLRsYQ 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==oh1JUWa3LdnqTpz5(u"࠼࠿ᖴ"): from xxTl5gOPoU 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==Vt4ELHXZP6(u"࠾࠰ᖵ"): from ys3WRBKjgv 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸࠲ᖶ"): from wg6h2LsVex 		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	elif Q8QglLCU5P==vdHRKkIgTp56Je1OuNo(u"࠹࠴ᖷ"): from koJGyjUzmZ		import HYWukw3pL2oMzPK4	; mL7BVKcSygkuoPbWlEF4YD = HYWukw3pL2oMzPK4(ocq9aTtSF2,OG9Usa51Nk8D,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	else: mL7BVKcSygkuoPbWlEF4YD = None
	return mL7BVKcSygkuoPbWlEF4YD
def e9ypcP7NajLobFEAdWY8(jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs,dbBRqLP6WeEV,showDialogs):
	bMBAmoLJRjP4SXYV2 = BBwb2NzsHE.getSetting(C0CbfZuXJM(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ໴"))
	BBwb2NzsHE.setSetting(CC4UDLW6brf(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ໵"),oh1JUWa3LdnqTpz5(u"ࠨࠩ໶"))
	if oh1JUWa3LdnqTpz5(u"ࠩ࠰ࠫ໷") in dbBRqLP6WeEV: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = dbBRqLP6WeEV.split(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪ࠱ࠬ໸"),C0CbfZuXJM(u"࠳ᖸ"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠳ᖹ")]
	else: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = dbBRqLP6WeEV
	LrZdCkYRba4BzOU6FnPEcjimJX = jjKUzRlixEhe7vY3BO6TDs5pGZ in [vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠷ᖽ"),vdHRKkIgTp56Je1OuNo(u"࠶࠷࠰࠱࠳ᖻ"),G5TxeI0ND4ztC6(u"࠵࠶࠶࠰࠳ᖺ"),cg94WALw5orUhvtHSfNO(u"࠷࠰࠱࠷࠷ᖼ")]
	SIV2AifUKwlYXjoZ7eEaJ8unqbD = KPW9hQet1aZUu4H2b0lvSi7Rs.lower()
	C89RTvbIPBt7yc = jjKUzRlixEhe7vY3BO6TDs5pGZ in [vlW6K1g8Xo35mPYbyO2GS(u"࠱ᖾ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵࠵࠺ᗁ"),CC4UDLW6brf(u"࠳࠳࠴࠻࠷ᖿ"),cg94WALw5orUhvtHSfNO(u"࠴࠵࠶ᗀ")]
	Ed9Auk3cR6wjSyseXip = VVtQk9vwe7(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ໹") in SIV2AifUKwlYXjoZ7eEaJ8unqbD
	j6hV3JzyqD0QYOSu1Ard8ZwlbK9k = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬ໺") in SIV2AifUKwlYXjoZ7eEaJ8unqbD
	pZWjvsk0VX7h = b46fBrugtPDSYspzMQIx(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭໻") in SIV2AifUKwlYXjoZ7eEaJ8unqbD
	zJ1PExa8l50UILSZyhTA = GVPK9Ziaho6U2ySLj(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩ໼") in SIV2AifUKwlYXjoZ7eEaJ8unqbD
	GrZvUpxLeXDqCmjfa7KQ = BBwb2NzsHE.getSetting(tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭໽"))
	v2JEMkx6aPYch45I = BBwb2NzsHE.getSetting(vdHRKkIgTp56Je1OuNo(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ໾"))
	OOTGfazqwRg8exWZ = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪๅู๊ࠠโ์ࠣืาฮࠠศๆุๅาฯࠠๆ่ࠣห้หๆหำ้ฮࠬ໿")
	XeHqDdRzgUYZkCfcQLVrsal = b098bsyjUud(u"ࠫࡊࡸࡲࡰࡴࠣࠫༀ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+Vt4ELHXZP6(u"ࠬࡀࠠࠨ༁")+KPW9hQet1aZUu4H2b0lvSi7Rs
	XeHqDdRzgUYZkCfcQLVrsal = i35i6al7upCAreLFQ(XeHqDdRzgUYZkCfcQLVrsal)
	if C89RTvbIPBt7yc or Ed9Auk3cR6wjSyseXip or j6hV3JzyqD0QYOSu1Ard8ZwlbK9k or pZWjvsk0VX7h or zJ1PExa8l50UILSZyhTA:
		OOTGfazqwRg8exWZ += GVPK9Ziaho6U2ySLj(u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣฬฬ๊ๅ้ไ฼ࡠࡳ࠭༂")
	if LrZdCkYRba4BzOU6FnPEcjimJX: OOTGfazqwRg8exWZ += b098bsyjUud(u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࡡࡴࠧ༃")
	XeHqDdRzgUYZkCfcQLVrsal = C0CbfZuXJM(u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭༄")+XeHqDdRzgUYZkCfcQLVrsal+ebT9xRB63E(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ༅")
	if GrZvUpxLeXDqCmjfa7KQ==vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡅࡘࡑࠧ༆") or v2JEMkx6aPYch45I==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡆ࡙ࡋࠨ༇"):
		OOTGfazqwRg8exWZ += KylMx0kfTOrG(u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟๊่ࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ༈")
	w3xgzAeHjEkDrIZ1 = VVtQk9vwe7(u"ࡌࡡ࡭ࡵࡨ᝙")
	if showDialogs and dbBRqLP6WeEV not in emFVCjpawXi0xhtYQo1T9H2vPlyuJK:
		if GrZvUpxLeXDqCmjfa7KQ==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡁࡔࡍࠪ༉") or v2JEMkx6aPYch45I==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡂࡕࡎࠫ༊"):
			WnbmLQXcr7JdDtRyEe = VYEiZteQcrT7aqOBMRAyHC9(C0CbfZuXJM(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ་"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩัีําࠧ༌"),xmTX9Aeidq8cVhY(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩ།"),WfgnOq9Fd4lhMSQpK5(u"ࠫส฻ไศฯࠣห้๋ิไๆฬࠫ༎"),HLAhjNIVMFonqi5zg2aQlpyfRKBrm+cg94WALw5orUhvtHSfNO(u"ࠬࠦࠠࠡࠩ༏")+kFhAce5Pz1(HLAhjNIVMFonqi5zg2aQlpyfRKBrm),OOTGfazqwRg8exWZ+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭࡜࡯ࠩ༐")+XeHqDdRzgUYZkCfcQLVrsal)
			if WnbmLQXcr7JdDtRyEe==b098bsyjUud(u"࠶ᗂ"):
				from COH7BKApEP import rDcxWnkhEUCJ
				rDcxWnkhEUCJ()
			elif WnbmLQXcr7JdDtRyEe==ebT9xRB63E(u"࠸ᗃ"): w3xgzAeHjEkDrIZ1 = tvdQHb10PhNmuy6(u"ࡔࡳࡷࡨ᝚")
		else: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࠨ༑"),Vt4ELHXZP6(u"ࠨࠩ༒"),HLAhjNIVMFonqi5zg2aQlpyfRKBrm+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩࠣࠤࠥ࠭༓")+kFhAce5Pz1(HLAhjNIVMFonqi5zg2aQlpyfRKBrm),OOTGfazqwRg8exWZ,XeHqDdRzgUYZkCfcQLVrsal)
	BBwb2NzsHE.setSetting(KylMx0kfTOrG(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ༔"),bMBAmoLJRjP4SXYV2)
	return w3xgzAeHjEkDrIZ1
def jplLPaWg54UydbZrNn(CC58RKPDWLrAlVTHkGUx=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡇࡣ࡯ࡷࡪ᝛"),AoHFRgYdEfeCXqK=[]):
	wgUDNtXdQ5VBoEkb = [tgjCPKlcGephBE8ka,KoULXHCRWtulrsM1cP]+AoHFRgYdEfeCXqK
	for UZqkaAhucSIr6l1ed in A73K6zLXIgFROeCHJQi0Pbos.listdir(HnMP40juJfr6L1mexbWBV):
		if CC58RKPDWLrAlVTHkGUx and (UZqkaAhucSIr6l1ed.startswith(oh1JUWa3LdnqTpz5(u"ࠫ࡮ࡶࡴࡷࠩ༕")) or UZqkaAhucSIr6l1ed.startswith(WfgnOq9Fd4lhMSQpK5(u"ࠬࡳ࠳ࡶࠩ༖"))): continue
		if UZqkaAhucSIr6l1ed.startswith(G5TxeI0ND4ztC6(u"࠭ࡦࡪ࡮ࡨࡣࠬ༗")): continue
		KOnEApsw1BtJ8QHi4doacr = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,UZqkaAhucSIr6l1ed)
		if KOnEApsw1BtJ8QHi4doacr in wgUDNtXdQ5VBoEkb: continue
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(KOnEApsw1BtJ8QHi4doacr)
		except: pass
	if FFoYQNgfsy not in wgUDNtXdQ5VBoEkb: IN1vbO8YfAu05Qyi7jMVwkxSE(FFoYQNgfsy,pOIe6U1vWYC7Gh2udFBRgT(u"ࡗࡶࡺ࡫᝝"),tjoHEAGv2XkrMBsVfCyp5U(u"ࡈࡤࡰࡸ࡫᝜"))
	Mrx2OeZV1LNjBsQ58Savi7.sleep(KylMx0kfTOrG(u"࠱ᗄ"))
	return
def o6fusjwNAyi4CXDIazOt7cE(j8w9YnbNRkPd2SJx,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,c95E6IfsJToNp=trSQHvP4aqBWFKxN5bZgXCu(u"ࡘࡷࡻࡥ᝞"),hQbrjUIeoFgwOTNk9zYBXlMLR=trSQHvP4aqBWFKxN5bZgXCu(u"ࡘࡷࡻࡥ᝞")):
	OG9Usa51Nk8D = OG9Usa51Nk8D+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃ༘ࠧ")+j8w9YnbNRkPd2SJx
	QBDjIUdSiR = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,c95E6IfsJToNp,hQbrjUIeoFgwOTNk9zYBXlMLR)
	if OG9Usa51Nk8D in QBDjIUdSiR.content: QBDjIUdSiR.succeeded = DItWNMaLOZ146CubYk8lfAwTy(u"ࡋࡧ࡬ࡴࡧ᝟")
	if not QBDjIUdSiR.succeeded:
		ssIFxhY0K5JUkqicQ8WlbmMBP(A6Iyo7eXrq2RtMmDxWj(u"ࠨࡊࡗࡘࡕࠦࡒࡦࡳࡸࡩࡸࡺࠠࡇࡣ࡬ࡰࡺࡸࡥࠨ༙"))
	return QBDjIUdSiR
def WoAEjZckXYsDplMny7tN1r0zLeK8V(OG9Usa51Nk8D):
	QBDjIUdSiR = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,u2NDjURZVHlmdc0(u"ࠩࡊࡉ࡙࠭༚"),OG9Usa51Nk8D,GVPK9Ziaho6U2ySLj(u"ࠪࠫ༛"),CC4UDLW6brf(u"ࠫࠬ༜"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࡔࡳࡷࡨᝡ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬ࠭༝"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ༞"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࡔࡳࡷࡨᝡ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡌࡡ࡭ࡵࡨᝠ"))
	TEu5h3gNfynaKeb6rMdXHxsilv4 = []
	if QBDjIUdSiR.succeeded:
		TMq6SKsGo5muadx = QBDjIUdSiR.content
		rrf2qxRSp4TCMlQ = JJDtX1PZyIgN2T.findall(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ༟"),TMq6SKsGo5muadx)
		if rrf2qxRSp4TCMlQ: TMq6SKsGo5muadx = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨ࡞ࡱࠫ༠").join(rrf2qxRSp4TCMlQ)
		AA2xYzW8CS7 = TMq6SKsGo5muadx.replace(VVtQk9vwe7(u"ࠩ࡟ࡶࠬ༡"),vlW6K1g8Xo35mPYbyO2GS(u"ࠪࠫ༢")).strip(oh1JUWa3LdnqTpz5(u"ࠫࡡࡴࠧ༣")).split(VVtQk9vwe7(u"ࠬࡢ࡮ࠨ༤"))
		TEu5h3gNfynaKeb6rMdXHxsilv4 = []
		for j8w9YnbNRkPd2SJx in AA2xYzW8CS7:
			if j8w9YnbNRkPd2SJx.count(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭࠮ࠨ༥"))==vlW6K1g8Xo35mPYbyO2GS(u"࠴ᗅ"): TEu5h3gNfynaKeb6rMdXHxsilv4.append(j8w9YnbNRkPd2SJx)
	return TEu5h3gNfynaKeb6rMdXHxsilv4
def SGTdH4qP2f1ZxBcA9XMsyWbOm6vVF(*aargs):
	r5QIpnze8ViUsc = b46fBrugtPDSYspzMQIx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡶࡲࡰࡺࡼࡷࡨࡸࡡࡱࡧ࠱ࡧࡴࡳ࠯ࡷ࠴࠲ࡃࡷ࡫ࡱࡶࡧࡶࡸࡂࡪࡩࡴࡲ࡯ࡥࡾࡶࡲࡰࡺ࡬ࡩࡸࠬࡰࡳࡱࡻࡽࡹࡿࡰࡦ࠿࡫ࡸࡹࡶࠦࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳࠴࠵࠶ࠦࡴࡵ࡯ࡁࡾ࡫ࡳࠧ࡮࡬ࡱ࡮ࡺ࠽࠲࠲ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࡓࡒࠬࡃࡇ࠯ࡈࡊ࠲ࡆࡓ࠮ࡊࡆ࠱࡚ࡒࠨ༦")
	i2bJOdpReQk7I5YfXgtSD = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡱࡲࡷࡹ࡫ࡲ࡬࡫ࡧ࠳ࡴࡶࡥ࡯ࡲࡵࡳࡽࡿ࡬ࡪࡵࡷ࠳ࡲࡧࡩ࡯࠱ࡋࡘ࡙ࡖࡓ࠯ࡶࡻࡸࠬ༧")
	FJNioB46H37 = WoAEjZckXYsDplMny7tN1r0zLeK8V(i2bJOdpReQk7I5YfXgtSD)
	TEu5h3gNfynaKeb6rMdXHxsilv4 = WoAEjZckXYsDplMny7tN1r0zLeK8V(r5QIpnze8ViUsc)
	a5kfbADrLx = FJNioB46H37+TEu5h3gNfynaKeb6rMdXHxsilv4
	b6kj4LJ5tzTeOMQi(vdHRKkIgTp56Je1OuNo(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ༨"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩ༩")+str(len(FJNioB46H37))+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫ࠰࠭༪")+str(len(TEu5h3gNfynaKeb6rMdXHxsilv4))+cg94WALw5orUhvtHSfNO(u"ࠬࠦ࡝ࠨ༫"))
	j8w9YnbNRkPd2SJx = BBwb2NzsHE.getSetting(u2NDjURZVHlmdc0(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭༬"))
	QBDjIUdSiR = hzJoxHQE89aNMR7drb0VntI3CKeDFm()
	BBwb2NzsHE.setSetting(b098bsyjUud(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ༭"),xmTX9Aeidq8cVhY(u"ࠨࠩ༮"))
	if j8w9YnbNRkPd2SJx or a5kfbADrLx:
		iZXua1gCvb9Y5xr,ObFSK3zDPkrX5qgN9 = Wbwj0o5gsXQ8F2f(u"࠲ᗆ"),tjoHEAGv2XkrMBsVfCyp5U(u"࠴࠴ᗇ")
		y5y2cdBjOtAEvbQm8W0zf = len(a5kfbADrLx)
		vclO5w1nqeVYt4dCR = ObFSK3zDPkrX5qgN9
		if y5y2cdBjOtAEvbQm8W0zf>vclO5w1nqeVYt4dCR: YnseWhjrFbZkSa0A1CG = vclO5w1nqeVYt4dCR
		else: YnseWhjrFbZkSa0A1CG = y5y2cdBjOtAEvbQm8W0zf
		jcgvk9WqPdaI1xUJrVE = GpOkwndjsI27uM.sample(a5kfbADrLx,YnseWhjrFbZkSa0A1CG)
		if j8w9YnbNRkPd2SJx: jcgvk9WqPdaI1xUJrVE = [j8w9YnbNRkPd2SJx]+jcgvk9WqPdaI1xUJrVE
		ZBEePG67gAS8MYH = aDiNElZCYMU9ptH7oA3d5eu60IOwgj(GVPK9Ziaho6U2ySLj(u"ࡇࡣ࡯ࡷࡪᝢ"),GVPK9Ziaho6U2ySLj(u"ࡇࡣ࡯ࡷࡪᝢ"))
		XXsM6FBxqztKRYyAlvD = Mrx2OeZV1LNjBsQ58Savi7.time()
		while Mrx2OeZV1LNjBsQ58Savi7.time()-XXsM6FBxqztKRYyAlvD<=ObFSK3zDPkrX5qgN9 and not ZBEePG67gAS8MYH.finishedLIST:
			if iZXua1gCvb9Y5xr<YnseWhjrFbZkSa0A1CG:
				j8w9YnbNRkPd2SJx = jcgvk9WqPdaI1xUJrVE[iZXua1gCvb9Y5xr]
				ZBEePG67gAS8MYH.t5F2ieMUsZbgfAGqpzOTdaYn(iZXua1gCvb9Y5xr,o6fusjwNAyi4CXDIazOt7cE,j8w9YnbNRkPd2SJx,*aargs)
			Mrx2OeZV1LNjBsQ58Savi7.sleep(vlW6K1g8Xo35mPYbyO2GS(u"࠵ᗈ"))
			iZXua1gCvb9Y5xr += trSQHvP4aqBWFKxN5bZgXCu(u"࠶ᗉ")
			b6kj4LJ5tzTeOMQi(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ༯"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+Yr0wo7FaSHx(u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ༰")+j8w9YnbNRkPd2SJx+DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠥࡣࠧ༱"))
		finishedLIST = ZBEePG67gAS8MYH.finishedLIST
		if finishedLIST:
			resultsDICT = ZBEePG67gAS8MYH.resultsDICT
			FkHfRo750xvYCZ3Q9EGThDX6juS = finishedLIST[A6Iyo7eXrq2RtMmDxWj(u"࠶ᗊ")]
			QBDjIUdSiR = resultsDICT[FkHfRo750xvYCZ3Q9EGThDX6juS]
			j8w9YnbNRkPd2SJx = jcgvk9WqPdaI1xUJrVE[int(FkHfRo750xvYCZ3Q9EGThDX6juS)]
			BBwb2NzsHE.setSetting(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ༲"),j8w9YnbNRkPd2SJx)
			if FkHfRo750xvYCZ3Q9EGThDX6juS!=u2NDjURZVHlmdc0(u"࠰ᗋ"): b6kj4LJ5tzTeOMQi(b098bsyjUud(u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ༳"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+vlW6K1g8Xo35mPYbyO2GS(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ༴")+j8w9YnbNRkPd2SJx+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࠢࡠ༵ࠫ"))
			else: b6kj4LJ5tzTeOMQi(xmTX9Aeidq8cVhY(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ༶"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤ༷ࠬ")+j8w9YnbNRkPd2SJx+u2NDjURZVHlmdc0(u"ࠫࠥࡣࠧ༸"))
	return QBDjIUdSiR
def GCkrzDJ618ame5f(tjgzDHRyCJiS5XWxKcOp2MU4d3,ZtTAbOzD0fsJxw8SNcQnr):
	KAbz0kcq4y5hwpW3oRMePlfInmJY = tjgzDHRyCJiS5XWxKcOp2MU4d3.create_connection
	def bb3jheWHSfcv4T9imt8Ux(n8YR4VFuqZD,*aargs,**kkwargs):
		MMZ0ya2klCVt1WqFgxo,LvTKXZ7qSYh8DQ4gfrsEiMlNVkA = n8YR4VFuqZD
		ip = vI2HqhrFbX8sRkDC(MMZ0ya2klCVt1WqFgxo,ZtTAbOzD0fsJxw8SNcQnr)
		if ip: MMZ0ya2klCVt1WqFgxo = ip[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠱ᗌ")]
		else:
			if ZtTAbOzD0fsJxw8SNcQnr in vXU90oAP4jJZzsw51SkNYu8Q6bF: vXU90oAP4jJZzsw51SkNYu8Q6bF.remove(ZtTAbOzD0fsJxw8SNcQnr)
			if vXU90oAP4jJZzsw51SkNYu8Q6bF:
				E9UIMPDNtnYAk = vXU90oAP4jJZzsw51SkNYu8Q6bF[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠲ᗍ")]
				ip = vI2HqhrFbX8sRkDC(MMZ0ya2klCVt1WqFgxo,E9UIMPDNtnYAk)
				if ip: MMZ0ya2klCVt1WqFgxo = ip[xmTX9Aeidq8cVhY(u"࠳ᗎ")]
		n8YR4VFuqZD = (MMZ0ya2klCVt1WqFgxo,LvTKXZ7qSYh8DQ4gfrsEiMlNVkA)
		return KAbz0kcq4y5hwpW3oRMePlfInmJY(n8YR4VFuqZD,*aargs,**kkwargs)
	tjgzDHRyCJiS5XWxKcOp2MU4d3.create_connection = bb3jheWHSfcv4T9imt8Ux
	return KAbz0kcq4y5hwpW3oRMePlfInmJY
def ncwBHlxS7yX9QrOk8FIo1(OG9Usa51Nk8D):
	xaGKq7vVjlQ4,AHa9Cb5jPrRhDtMZqoO = OG9Usa51Nk8D.split(KylMx0kfTOrG(u"ࠬ࠵༹ࠧ"))[KylMx0kfTOrG(u"࠷ᗐ")],Wbwj0o5gsXQ8F2f(u"࠼࠵ᗏ")
	if tvdQHb10PhNmuy6(u"࠭࠺ࠨ༺") in xaGKq7vVjlQ4: xaGKq7vVjlQ4,AHa9Cb5jPrRhDtMZqoO = xaGKq7vVjlQ4.split(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧ࠻ࠩ༻"))
	tGo8bIDHplxrn2jc4v0JuYX7g = Yr0wo7FaSHx(u"ࠨ࠱ࠪ༼")+KylMx0kfTOrG(u"ࠩ࠲ࠫ༽").join(OG9Usa51Nk8D.split(b46fBrugtPDSYspzMQIx(u"ࠪ࠳ࠬ༾"))[u2NDjURZVHlmdc0(u"࠹ᗑ"):])
	WAEqF7ZldrmL9Xw = DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࡌࡋࡔࠡࠩ༿")+tGo8bIDHplxrn2jc4v0JuYX7g+G5TxeI0ND4ztC6(u"ࠬࠦࡈࡕࡖࡓ࠳࠶࠴࠱࡝ࡴ࡟ࡲࠬཀ")
	WAEqF7ZldrmL9Xw += cg94WALw5orUhvtHSfNO(u"࠭ࡈࡰࡵࡷ࠾ࠥ࠭ཁ")+xaGKq7vVjlQ4+b46fBrugtPDSYspzMQIx(u"ࠧ࡝ࡴ࡟ࡲࠬག")
	WAEqF7ZldrmL9Xw += vdHRKkIgTp56Je1OuNo(u"ࠨ࡞ࡵࡠࡳ࠭གྷ")
	from socket import socket as r6h8FXwU1f9Knx3BtOI45mjgiG,AF_INET as V47MU09QYBNxTjHF,SOCK_STREAM as y7Pbr6RV0Gij
	try:
		g3f94woH2m5Xuj1yTUbDPSk = r6h8FXwU1f9Knx3BtOI45mjgiG(V47MU09QYBNxTjHF,y7Pbr6RV0Gij)
		g3f94woH2m5Xuj1yTUbDPSk.connect((xaGKq7vVjlQ4,AHa9Cb5jPrRhDtMZqoO))
		g3f94woH2m5Xuj1yTUbDPSk.send(WAEqF7ZldrmL9Xw.encode(b46fBrugtPDSYspzMQIx(u"ࠩࡸࡸ࡫࠾ࠧང")))
		wsTfLZ6SO0FdYgnPQz8arGB1WNuMR = g3f94woH2m5Xuj1yTUbDPSk.recv(KylMx0kfTOrG(u"࠵࠲࠼࠺ᗓ")*vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠱࠱࠴࠷ᗒ"))
		TMq6SKsGo5muadx = repr(wsTfLZ6SO0FdYgnPQz8arGB1WNuMR)
	except: TMq6SKsGo5muadx = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࠫཅ")
	return TMq6SKsGo5muadx
def OfTKisDR0Lv(XvmKMQ7UWwFtBT5AVGcHipxI4j,ajLz9PfYbTigyorvZhW4IOFn):
	if C0CbfZuXJM(u"ࠫ࠳࠭ཆ") not in XvmKMQ7UWwFtBT5AVGcHipxI4j: return XvmKMQ7UWwFtBT5AVGcHipxI4j
	XvmKMQ7UWwFtBT5AVGcHipxI4j = XvmKMQ7UWwFtBT5AVGcHipxI4j+VVtQk9vwe7(u"ࠬ࠵ࠧཇ")
	GXWalz6qyre4MdpbNiH7xPmEChZ,adciP7gpIXhjTtvoF = XvmKMQ7UWwFtBT5AVGcHipxI4j.split(VVtQk9vwe7(u"࠭࠮ࠨ཈"),KylMx0kfTOrG(u"࠳ᗔ"))
	Tl3RXbgGW5S79PjNxpeQ1qyBmAVJu,DTIEznBsdS8Xea2JGjLk7RNgWb4 = adciP7gpIXhjTtvoF.split(vdHRKkIgTp56Je1OuNo(u"ࠧ࠰ࠩཉ"),xmTX9Aeidq8cVhY(u"࠴ᗕ"))
	qODFmdJk67Szep4Yh2vun9oMgRy = GXWalz6qyre4MdpbNiH7xPmEChZ+tjoHEAGv2XkrMBsVfCyp5U(u"ࠨ࠰ࠪཊ")+Tl3RXbgGW5S79PjNxpeQ1qyBmAVJu
	if ajLz9PfYbTigyorvZhW4IOFn in [DItWNMaLOZ146CubYk8lfAwTy(u"ࠩ࡫ࡳࡸࡺࠧཋ"),b098bsyjUud(u"ࠪࡲࡦࡳࡥࠨཌ")] and ebT9xRB63E(u"ࠫ࠴࠭ཌྷ") in qODFmdJk67Szep4Yh2vun9oMgRy: qODFmdJk67Szep4Yh2vun9oMgRy = qODFmdJk67Szep4Yh2vun9oMgRy.rsplit(KylMx0kfTOrG(u"ࠬ࠵ࠧཎ"),Vt4ELHXZP6(u"࠵ᗖ"))[Vt4ELHXZP6(u"࠵ᗖ")]
	if ajLz9PfYbTigyorvZhW4IOFn==Wbwj0o5gsXQ8F2f(u"࠭࡮ࡢ࡯ࡨࠫཏ") and DItWNMaLOZ146CubYk8lfAwTy(u"ࠧ࠯ࠩཐ") in qODFmdJk67Szep4Yh2vun9oMgRy:
		G6AToNaKQnX = qODFmdJk67Szep4Yh2vun9oMgRy.split(pOIe6U1vWYC7Gh2udFBRgT(u"ࠨ࠰ࠪད"))
		NDlGbe7IXhxwHySC6cpTi = len(G6AToNaKQnX)
		if NDlGbe7IXhxwHySC6cpTi<=Wbwj0o5gsXQ8F2f(u"࠸ᗘ") or Vt4ELHXZP6(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧདྷ") in qODFmdJk67Szep4Yh2vun9oMgRy: G6AToNaKQnX = G6AToNaKQnX[vlW6K1g8Xo35mPYbyO2GS(u"࠵ᗗ")]
		elif NDlGbe7IXhxwHySC6cpTi>=cg94WALw5orUhvtHSfNO(u"࠴ᗚ"): G6AToNaKQnX = G6AToNaKQnX[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠱ᗙ")]
		if len(G6AToNaKQnX)>KylMx0kfTOrG(u"࠳ᗛ"): qODFmdJk67Szep4Yh2vun9oMgRy = G6AToNaKQnX
	return qODFmdJk67Szep4Yh2vun9oMgRy
def GlsezWv7iIro(ct8Eo0AGusOYR3qK2bWVHkpeQPwi):
	CCcp5F9BSRQawPXnJ = repr(ct8Eo0AGusOYR3qK2bWVHkpeQPwi.encode(G5TxeI0ND4ztC6(u"ࠪࡹࡹ࡬࠸ࠨན"))).replace(WfgnOq9Fd4lhMSQpK5(u"ࠦࠬࠨཔ"),ebT9xRB63E(u"ࠬ࠭ཕ"))
	return CCcp5F9BSRQawPXnJ
def uusp6FEmWZwDhXo(L1NJRtZdl0pjHW7qUrYTwzku):
	ForxUN4X7OKWibyt = vdHRKkIgTp56Je1OuNo(u"࠭ࠧབ")
	if wIqFesTOvYnu5S2dWfpBVC: L1NJRtZdl0pjHW7qUrYTwzku = L1NJRtZdl0pjHW7qUrYTwzku.decode(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡶࡶࡩ࠼ࠬབྷ"))
	from unicodedata import decomposition as ybB0jav3ohZ
	for mOvlTMb0sJrfEcj71Sq3a5 in L1NJRtZdl0pjHW7qUrYTwzku:
		if   mOvlTMb0sJrfEcj71Sq3a5==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡶࠩลࠫམ"): heYbsqo1gjnTuU2tWkDf80VBvS = CC4UDLW6brf(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ࠪཙ")
		elif mOvlTMb0sJrfEcj71Sq3a5==Wbwj0o5gsXQ8F2f(u"ࡸࠫศ࠭ཚ"): heYbsqo1gjnTuU2tWkDf80VBvS = WfgnOq9Fd4lhMSQpK5(u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬཛ")
		elif mOvlTMb0sJrfEcj71Sq3a5==WfgnOq9Fd4lhMSQpK5(u"ࡺ࠭ฤࠨཛྷ"): heYbsqo1gjnTuU2tWkDf80VBvS = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧཝ")
		elif mOvlTMb0sJrfEcj71Sq3a5==KylMx0kfTOrG(u"ࡵࠨวࠪཞ"): heYbsqo1gjnTuU2tWkDf80VBvS = Wbwj0o5gsXQ8F2f(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ࠩཟ")
		elif mOvlTMb0sJrfEcj71Sq3a5==VVtQk9vwe7(u"ࡷࠪสࠬའ"): heYbsqo1gjnTuU2tWkDf80VBvS = cg94WALw5orUhvtHSfNO(u"ࠪࡠࡡࡻ࠰࠷࠴࠹ࠫཡ")
		else:
			wwjXKGHrTtZlk90xgh = ybB0jav3ohZ(mOvlTMb0sJrfEcj71Sq3a5)
			if vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠥ࠭ར") in wwjXKGHrTtZlk90xgh: heYbsqo1gjnTuU2tWkDf80VBvS = tvdQHb10PhNmuy6(u"ࠬࡢ࡜ࡶࠩལ")+wwjXKGHrTtZlk90xgh.split(C0CbfZuXJM(u"࠭ࠠࠨཤ"),Yr0wo7FaSHx(u"࠴ᗜ"))[Yr0wo7FaSHx(u"࠴ᗜ")]
			else:
				heYbsqo1gjnTuU2tWkDf80VBvS = Yr0wo7FaSHx(u"ࠧ࠱࠲࠳࠴ࠬཥ")+hex(ord(mOvlTMb0sJrfEcj71Sq3a5)).replace(C0CbfZuXJM(u"ࠨ࠲ࡻࠫས"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࠪཧ"))
				heYbsqo1gjnTuU2tWkDf80VBvS = DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡠࡡࡻࠧཨ")+heYbsqo1gjnTuU2tWkDf80VBvS[-tvdQHb10PhNmuy6(u"࠸ᗝ"):]
		ForxUN4X7OKWibyt += heYbsqo1gjnTuU2tWkDf80VBvS
	ForxUN4X7OKWibyt = ForxUN4X7OKWibyt.replace(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬཀྵ"),ebT9xRB63E(u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭ཪ"))
	if wIqFesTOvYnu5S2dWfpBVC: ForxUN4X7OKWibyt = ForxUN4X7OKWibyt.decode(b098bsyjUud(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧཫ")).encode(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡶࡶࡩ࠼ࠬཬ"))
	else: ForxUN4X7OKWibyt = ForxUN4X7OKWibyt.encode(KylMx0kfTOrG(u"ࠨࡷࡷࡪ࠽࠭཭")).decode(vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ཮"))
	return ForxUN4X7OKWibyt
def GVfnMyZxiRI(header=u2NDjURZVHlmdc0(u"่ࠪํำษࠡษ็้ๆอส๋ฯࠪ཯"),default=vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠬ཰"),bvoXFrmkZ2IBhcDR3G=ebT9xRB63E(u"ࡈࡤࡰࡸ࡫ᝣ"),source=Wbwj0o5gsXQ8F2f(u"ཱࠬ࠭")):
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = jrENWRfiCOxlsHVtQXJk351LFZn(header,default,type=U6zsmRNGTL.INPUT_ALPHANUM)
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(WfgnOq9Fd4lhMSQpK5(u"ི࠭ࠠࠡࠩ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ཱིࠧࠡࠩ")).replace(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨུࠢࠣࠫ"),A6Iyo7eXrq2RtMmDxWj(u"ཱུࠩࠣࠫ")).replace(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࠤࠥ࠭ྲྀ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠥ࠭ཷ"))
	if not JJ23NOKSjik1hg8Ts7CXbevYzrQHU and not bvoXFrmkZ2IBhcDR3G:
		b6kj4LJ5tzTeOMQi(tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡔࡏࡕࡋࡆࡉࠬླྀ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭࠮ࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪཹ")+JJ23NOKSjik1hg8Ts7CXbevYzrQHU+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ེࠧࠣࠩ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨཻࠩ"),Wbwj0o5gsXQ8F2f(u"ོࠩࠪ"),tvdQHb10PhNmuy6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัཽ࠭"),tvdQHb10PhNmuy6(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวาาฬ๊ࠧཾ"))
		return NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠭ཿ")
	if JJ23NOKSjik1hg8Ts7CXbevYzrQHU not in [A6Iyo7eXrq2RtMmDxWj(u"ྀ࠭ࠧ"),vdHRKkIgTp56Je1OuNo(u"ཱྀࠧࠡࠩ")]:
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.strip(xmTX9Aeidq8cVhY(u"ࠨࠢࠪྂ"))
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = uusp6FEmWZwDhXo(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	if source!=uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖࠫྃ") and t1O7yDIEwKeSxBjCJMRAlnq(cg94WALw5orUhvtHSfNO(u"ࠪࡏࡊ࡟ࡂࡐࡃࡕࡈ྄ࠬ"),G5TxeI0ND4ztC6(u"ࠫࠬ྅"),[JJ23NOKSjik1hg8Ts7CXbevYzrQHU],Wbwj0o5gsXQ8F2f(u"ࡉࡥࡱࡹࡥᝤ")):
		b6kj4LJ5tzTeOMQi(Wbwj0o5gsXQ8F2f(u"ࠬࡔࡏࡕࡋࡆࡉࠬ྆"),CC4UDLW6brf(u"࠭࠮ࠡࠢࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡦࡱࡵࡣ࡬ࡧࡧ࠾ࠥࠦࠠࠣࠩ྇")+JJ23NOKSjik1hg8Ts7CXbevYzrQHU+b098bsyjUud(u"ࠧࠣࠩྈ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࠩྉ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࠪྊ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྋ"),GVPK9Ziaho6U2ySLj(u"ࠫฬ์สࠡๅอฬฯࠦใๅ็ฬࠤศ๎ࠠาไ่ࠤ้ํฺࠠๆสๆฮࠦศฤใ็ห๊ࠦไๅๅหหึࠦแใูࠣ࠲࠳่่ࠦาสࠤฬ๊ศา่ส้ัࠦไศࠢํื๊ำࠠษษึฮำีวๆ๊ࠢ็ีอࠠไๆ่หฯ࠭ྌ"))
		return Yr0wo7FaSHx(u"ࠬ࠭ྍ")
	b6kj4LJ5tzTeOMQi(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ྎ"),tvdQHb10PhNmuy6(u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡦࡲ࡬ࡰࡹࡨࡨ࠿ࠦࠠࠡࠤࠪྏ")+JJ23NOKSjik1hg8Ts7CXbevYzrQHU+u2NDjURZVHlmdc0(u"ࠨࠤࠪྐ"))
	return JJ23NOKSjik1hg8Ts7CXbevYzrQHU
def XuJcNIWr8FMGQS(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,JZP07kjvbV={}):
	OG9Usa51Nk8D,II8DK0EBTdUjGoe3CnN4wWYc,VEZ2OmqIYG,rZNKBbXmpiEkAR61Yfj = FrC9LhHZWIySdGwNsuzqt5Rf01TXO,{},{},b098bsyjUud(u"ࠩࠪྑ")
	if xmTX9Aeidq8cVhY(u"ࠪࢀࠬྒ") in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: OG9Usa51Nk8D,II8DK0EBTdUjGoe3CnN4wWYc = p2gG9rDHAXb7lYPvcMTa(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࢁ࠭ྒྷ"))
	D1yXb62FGH3BYol = list(set(list(JZP07kjvbV.keys())+list(II8DK0EBTdUjGoe3CnN4wWYc.keys())))
	for oQmOMcBwDGK69ylqSN2z in D1yXb62FGH3BYol:
		if oQmOMcBwDGK69ylqSN2z in list(II8DK0EBTdUjGoe3CnN4wWYc.keys()): VEZ2OmqIYG[oQmOMcBwDGK69ylqSN2z] = II8DK0EBTdUjGoe3CnN4wWYc[oQmOMcBwDGK69ylqSN2z]
		else: VEZ2OmqIYG[oQmOMcBwDGK69ylqSN2z] = JZP07kjvbV[oQmOMcBwDGK69ylqSN2z]
	if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩྔ") not in D1yXb62FGH3BYol: VEZ2OmqIYG[xmTX9Aeidq8cVhY(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྕ")] = yyYKmdtsAFic93()
	if GVPK9Ziaho6U2ySLj(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨྖ") not in D1yXb62FGH3BYol: VEZ2OmqIYG[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩྗ")] = OfTKisDR0Lv(OG9Usa51Nk8D,vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡸࡶࡱ࠭྘"))
	for oQmOMcBwDGK69ylqSN2z in list(VEZ2OmqIYG.keys()): rZNKBbXmpiEkAR61Yfj += GVPK9Ziaho6U2ySLj(u"ࠪࠪࠬྙ")+oQmOMcBwDGK69ylqSN2z+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡂ࠭ྚ")+VEZ2OmqIYG[oQmOMcBwDGK69ylqSN2z]
	if rZNKBbXmpiEkAR61Yfj: rZNKBbXmpiEkAR61Yfj = Yr0wo7FaSHx(u"ࠬࢂࠧྛ")+rZNKBbXmpiEkAR61Yfj[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶ᗞ"):]
	QBDjIUdSiR = zibnBvFtmwKplXrg(WfPehiKL4XVlonMQr9kUwAca6IybDj,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡇࡆࡖࠪྜ"),OG9Usa51Nk8D,KylMx0kfTOrG(u"ࠧࠨྜྷ"),VEZ2OmqIYG,C0CbfZuXJM(u"ࠨࠩྞ"),ebT9xRB63E(u"ࠩࠪྟ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧྠ"),Wbwj0o5gsXQ8F2f(u"ࡊࡦࡲࡳࡦᝥ"),Wbwj0o5gsXQ8F2f(u"ࡊࡦࡲࡳࡦᝥ"))
	TMq6SKsGo5muadx = QBDjIUdSiR.content
	if pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆࠨྡ") not in TMq6SKsGo5muadx: return [Wbwj0o5gsXQ8F2f(u"ࠬ࠳࠱ࠨྡྷ")],[OG9Usa51Nk8D+rZNKBbXmpiEkAR61Yfj]
	if DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪྣ") in TMq6SKsGo5muadx: return [ebT9xRB63E(u"ࠧ࠮࠳ࠪྤ")],[OG9Usa51Nk8D+rZNKBbXmpiEkAR61Yfj]
	if GVPK9Ziaho6U2ySLj(u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬྥ") in TMq6SKsGo5muadx: return [uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩ࠰࠵ࠬྦ")],[OG9Usa51Nk8D+rZNKBbXmpiEkAR61Yfj]
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,xx5aZyND7Cf,Gntwg5lHYk39WXaZqjzhOx71R = [],[],[],[]
	tBFLs10gh4MQyeXa5xSnqlPWdE = JJDtX1PZyIgN2T.findall(b098bsyjUud(u"ࠪࠧࡊ࡞ࡔ࠮࡚࠰ࡗ࡙ࡘࡅࡂࡏ࠰ࡍࡓࡌ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠫྦྷ"),TMq6SKsGo5muadx+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡡࡴࠧྨ"),JJDtX1PZyIgN2T.DOTALL)
	if not tBFLs10gh4MQyeXa5xSnqlPWdE: return [C0CbfZuXJM(u"ࠬ࠳࠱ࠨྩ")],[OG9Usa51Nk8D+rZNKBbXmpiEkAR61Yfj]
	for Ik5bst9OBynwor01jzgCKP,XvmKMQ7UWwFtBT5AVGcHipxI4j in tBFLs10gh4MQyeXa5xSnqlPWdE:
		VMofhiFdWkl,sKyYbxqDkw3cC0t,y2nBfLCjDoXkKiwb8WV6 = {},-vlW6K1g8Xo35mPYbyO2GS(u"࠷ᗟ"),-vlW6K1g8Xo35mPYbyO2GS(u"࠷ᗟ")
		Erd62RNpxSbI48hv = KylMx0kfTOrG(u"࠭ࠧྪ")
		do68fQEmTijJ3P2aHwcr1GsFlN9AI = Ik5bst9OBynwor01jzgCKP.split(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧ࠭ࠩྫ"))
		for oTCvBQL2ae in do68fQEmTijJ3P2aHwcr1GsFlN9AI:
			if Yr0wo7FaSHx(u"ࠨ࠿ࠪྫྷ") in oTCvBQL2ae:
				oQmOMcBwDGK69ylqSN2z,cvzjdYsGOxH3R = oTCvBQL2ae.split(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡀࠫྭ"),Yr0wo7FaSHx(u"࠱ᗠ"))
				VMofhiFdWkl[oQmOMcBwDGK69ylqSN2z.lower()] = cvzjdYsGOxH3R
		if A6Iyo7eXrq2RtMmDxWj(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧྮ") in Ik5bst9OBynwor01jzgCKP.lower():
			sKyYbxqDkw3cC0t = int(VMofhiFdWkl[tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡦࡼࡥࡳࡣࡪࡩ࠲ࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨྯ")])//cg94WALw5orUhvtHSfNO(u"࠲࠲࠵࠸ᗡ")
			Erd62RNpxSbI48hv += str(sKyYbxqDkw3cC0t)+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡱࡢࡱࡵࠣࠤࠬྰ")
		elif tvdQHb10PhNmuy6(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩྱ") in Ik5bst9OBynwor01jzgCKP.lower():
			sKyYbxqDkw3cC0t = int(VMofhiFdWkl[DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪྲ")])//KylMx0kfTOrG(u"࠳࠳࠶࠹ᗢ")
			Erd62RNpxSbI48hv += str(sKyYbxqDkw3cC0t)+b46fBrugtPDSYspzMQIx(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨླ")
		if vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭ྴ") in Ik5bst9OBynwor01jzgCKP.lower():
			y2nBfLCjDoXkKiwb8WV6 = int(VMofhiFdWkl[b46fBrugtPDSYspzMQIx(u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧྵ")].split(VVtQk9vwe7(u"ࠫࡽ࠭ྶ"))[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠴ᗣ")])
			Erd62RNpxSbI48hv += str(y2nBfLCjDoXkKiwb8WV6)+WfgnOq9Fd4lhMSQpK5(u"ࠬࠦࠠࠨྷ")
		Erd62RNpxSbI48hv = Erd62RNpxSbI48hv.strip(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࠠࠡࠩྸ"))
		if not Erd62RNpxSbI48hv: Erd62RNpxSbI48hv = Wbwj0o5gsXQ8F2f(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨྐྵ")
		if not XvmKMQ7UWwFtBT5AVGcHipxI4j.startswith(CC4UDLW6brf(u"ࠨࡪࡷࡸࡵ࠭ྺ")):
			if XvmKMQ7UWwFtBT5AVGcHipxI4j.startswith(GVPK9Ziaho6U2ySLj(u"ࠩ࠲࠳ࠬྻ")): XvmKMQ7UWwFtBT5AVGcHipxI4j = OG9Usa51Nk8D.split(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪ࠾ࠬྼ"),oh1JUWa3LdnqTpz5(u"࠵ᗤ"))[tvdQHb10PhNmuy6(u"࠵ᗥ")]+C0CbfZuXJM(u"ࠫ࠿࠭྽")+XvmKMQ7UWwFtBT5AVGcHipxI4j
			elif XvmKMQ7UWwFtBT5AVGcHipxI4j.startswith(WfgnOq9Fd4lhMSQpK5(u"ࠬ࠵ࠧ྾")): XvmKMQ7UWwFtBT5AVGcHipxI4j = OfTKisDR0Lv(OG9Usa51Nk8D,GVPK9Ziaho6U2ySLj(u"࠭ࡵࡳ࡮ࠪ྿"))+XvmKMQ7UWwFtBT5AVGcHipxI4j
			else: XvmKMQ7UWwFtBT5AVGcHipxI4j = OG9Usa51Nk8D.rsplit(vlW6K1g8Xo35mPYbyO2GS(u"ࠧ࠰ࠩ࿀"),b098bsyjUud(u"࠷ᗦ"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠰ᗧ")]+DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࠱ࠪ࿁")+XvmKMQ7UWwFtBT5AVGcHipxI4j
		if WfgnOq9Fd4lhMSQpK5(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ࿂") in list(VMofhiFdWkl.keys()):
			tb4p6sRlFPcio = VMofhiFdWkl[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ࿃")]
			tb4p6sRlFPcio = tb4p6sRlFPcio.replace(C0CbfZuXJM(u"ࠫࠧ࠭࿄"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠭࿅")).replace(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࿆ࠧࠣ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠨ࿇")).split(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࠥࠪ࿈"),oh1JUWa3LdnqTpz5(u"࠲ᗨ"))[GVPK9Ziaho6U2ySLj(u"࠲ᗩ")]
			i9lyj1xVYRDEwQzaZ60 = eeiIspx5JaGYcH0zCu(tb4p6sRlFPcio)
			if i9lyj1xVYRDEwQzaZ60: LpB4ilMr6vVtQ = Erd62RNpxSbI48hv+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࠣࠤࠬ࿉")+i9lyj1xVYRDEwQzaZ60
			else: LpB4ilMr6vVtQ = Erd62RNpxSbI48hv
			LpB4ilMr6vVtQ = LpB4ilMr6vVtQ+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠤࠥࡖࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧࠪ࿊")
			LpB4ilMr6vVtQ = LpB4ilMr6vVtQ+KylMx0kfTOrG(u"ࠫࠥࠦࠧ࿋")+OfTKisDR0Lv(tb4p6sRlFPcio,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡴࡡ࡮ࡧࠪ࿌"))
			JCop4mjTiurYB7W.append(LpB4ilMr6vVtQ)
			EEgFl59RndzrBL8TUoaQMw6P.append(tb4p6sRlFPcio)
			xx5aZyND7Cf.append(y2nBfLCjDoXkKiwb8WV6)
			Gntwg5lHYk39WXaZqjzhOx71R.append(sKyYbxqDkw3cC0t)
		XvmKMQ7UWwFtBT5AVGcHipxI4j = XvmKMQ7UWwFtBT5AVGcHipxI4j.split(DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࠣࠨ࿍"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠴ᗪ"))[vdHRKkIgTp56Je1OuNo(u"࠴ᗫ")]
		i9lyj1xVYRDEwQzaZ60 = eeiIspx5JaGYcH0zCu(XvmKMQ7UWwFtBT5AVGcHipxI4j)
		if i9lyj1xVYRDEwQzaZ60: Erd62RNpxSbI48hv = Erd62RNpxSbI48hv+ebT9xRB63E(u"ࠧࠡࠢࠪ࿎")+i9lyj1xVYRDEwQzaZ60
		Erd62RNpxSbI48hv = Erd62RNpxSbI48hv+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࠢࠣࠫ࿏")+OfTKisDR0Lv(XvmKMQ7UWwFtBT5AVGcHipxI4j,CC4UDLW6brf(u"ࠩࡱࡥࡲ࡫ࠧ࿐"))
		JCop4mjTiurYB7W.append(Erd62RNpxSbI48hv)
		EEgFl59RndzrBL8TUoaQMw6P.append(XvmKMQ7UWwFtBT5AVGcHipxI4j)
		xx5aZyND7Cf.append(y2nBfLCjDoXkKiwb8WV6)
		Gntwg5lHYk39WXaZqjzhOx71R.append(sKyYbxqDkw3cC0t)
	v9c1sSyiJXU2lN7C = list(zip(JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,xx5aZyND7Cf,Gntwg5lHYk39WXaZqjzhOx71R))
	v9c1sSyiJXU2lN7C = sorted(v9c1sSyiJXU2lN7C, reverse=vdHRKkIgTp56Je1OuNo(u"࡙ࡸࡵࡦᝦ"), key=lambda key: key[Yr0wo7FaSHx(u"࠸ᗬ")])
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P,xx5aZyND7Cf,Gntwg5lHYk39WXaZqjzhOx71R = list(zip(*v9c1sSyiJXU2lN7C))
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = list(JCop4mjTiurYB7W),list(EEgFl59RndzrBL8TUoaQMw6P)
	R8nkA2aSmYx4QMw = []
	for XvmKMQ7UWwFtBT5AVGcHipxI4j in EEgFl59RndzrBL8TUoaQMw6P: R8nkA2aSmYx4QMw.append(XvmKMQ7UWwFtBT5AVGcHipxI4j+rZNKBbXmpiEkAR61Yfj)
	return JCop4mjTiurYB7W,R8nkA2aSmYx4QMw
def vI2HqhrFbX8sRkDC(MMZ0ya2klCVt1WqFgxo,ZtTAbOzD0fsJxw8SNcQnr=jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪࠫ࿑")):
	if not ZtTAbOzD0fsJxw8SNcQnr: ZtTAbOzD0fsJxw8SNcQnr = vXU90oAP4jJZzsw51SkNYu8Q6bF[G5TxeI0ND4ztC6(u"࠶ᗭ")]
	if MMZ0ya2klCVt1WqFgxo.replace(A6Iyo7eXrq2RtMmDxWj(u"ࠫ࠳࠭࿒"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬ࠭࿓")).isdigit(): return [MMZ0ya2klCVt1WqFgxo]
	from struct import pack as ZvwIAahrHFDRzKTiu8OMgSxCeGc,unpack_from as wKt0oinq19z63uXRAga8NGm
	from socket import socket as r6h8FXwU1f9Knx3BtOI45mjgiG,AF_INET as V47MU09QYBNxTjHF,SOCK_DGRAM as gdsa0ZD4l7
	try:
		t0oP9Niny4VeS58aZQq1TxgMHp2E = ZvwIAahrHFDRzKTiu8OMgSxCeGc(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࠾ࡉࠤ࿔"), oh1JUWa3LdnqTpz5(u"࠱࠳࠲࠷࠽ᗮ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠢ࠿ࡊࠥ࿕"), oh1JUWa3LdnqTpz5(u"࠳࠷࠹ᗯ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(Vt4ELHXZP6(u"ࠣࡀࡋࠦ࿖"), uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠳ᗰ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠤࡁࡌࠧ࿗"), hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠳ᗱ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(A6Iyo7eXrq2RtMmDxWj(u"ࠥࡂࡍࠨ࿘"), ebT9xRB63E(u"࠴ᗲ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(CC4UDLW6brf(u"ࠦࡃࡎࠢ࿙"), NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠵ᗳ"))
		if DQfHadYvTpy1UR: aNgIJDh0oXVxGFb = MMZ0ya2klCVt1WqFgxo.split(tvdQHb10PhNmuy6(u"ࠬ࠴ࠧ࿚"))
		else: aNgIJDh0oXVxGFb = MMZ0ya2klCVt1WqFgxo.decode(b098bsyjUud(u"࠭ࡵࡵࡨ࠻ࠫ࿛")).split(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧ࠯ࠩ࿜"))
		for aps9lmWJPf6xMNX0LhuSC75 in aNgIJDh0oXVxGFb:
			nn1bcMjfU4m0ytKGsZ9 = aps9lmWJPf6xMNX0LhuSC75.encode(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡷࡷࡪ࠽࠭࿝"))
			t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(cg94WALw5orUhvtHSfNO(u"ࠤࡅࠦ࿞"), len(aps9lmWJPf6xMNX0LhuSC75))
			for Jt6hTpCkFzMBYbyfH0 in aps9lmWJPf6xMNX0LhuSC75:
				t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(xmTX9Aeidq8cVhY(u"ࠥࡧࠧ࿟"), Jt6hTpCkFzMBYbyfH0.encode(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡺࡺࡦ࠹ࠩ࿠")))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(C0CbfZuXJM(u"ࠧࡈࠢ࿡"), tvdQHb10PhNmuy6(u"࠶ᗴ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(tjoHEAGv2XkrMBsVfCyp5U(u"ࠨ࠾ࡉࠤ࿢"), KylMx0kfTOrG(u"࠱ᗵ"))
		t0oP9Niny4VeS58aZQq1TxgMHp2E += ZvwIAahrHFDRzKTiu8OMgSxCeGc(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠢ࠿ࡊࠥ࿣"), vlW6K1g8Xo35mPYbyO2GS(u"࠲ᗶ"))
		fxSeuIVhJYZtcXA = r6h8FXwU1f9Knx3BtOI45mjgiG(V47MU09QYBNxTjHF,gdsa0ZD4l7)
		fxSeuIVhJYZtcXA.sendto(bytes(t0oP9Niny4VeS58aZQq1TxgMHp2E), (ZtTAbOzD0fsJxw8SNcQnr, uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠷࠶ᗷ")))
		fxSeuIVhJYZtcXA.settimeout(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠹ᗸ"))
		kOfDHhMnuAxQoBpWTeL, oJTdvBOnFyM = fxSeuIVhJYZtcXA.recvfrom(GVPK9Ziaho6U2ySLj(u"࠵࠵࠸࠴ᗹ"))
		fxSeuIVhJYZtcXA.close()
		MtDQIfUnxNu82K1EOJ7jRCGwLBZ3a = wKt0oinq19z63uXRAga8NGm(ebT9xRB63E(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ࿤"), kOfDHhMnuAxQoBpWTeL, YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵ᗺ"))
		l24EJrI1xQzZV9tWc = MtDQIfUnxNu82K1EOJ7jRCGwLBZ3a[pOIe6U1vWYC7Gh2udFBRgT(u"࠹ᗻ")]
		P2M5VIWXgN1qma7 = len(MMZ0ya2klCVt1WqFgxo)+Vt4ELHXZP6(u"࠱࠹ᗼ")
		cFKVo2vauG0BRnXPmUdSpJCO6 = []
		for _tCgK7T0VQSfpvk in range(l24EJrI1xQzZV9tWc):
			R8diDOyZNkxAWqM7mct4hgT = P2M5VIWXgN1qma7
			wr6mOTtRuUPeN7WZjgfxC421c = b098bsyjUud(u"࠲ᗽ")
			O6DwagGX3Hu = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡌࡡ࡭ࡵࡨᝧ")
			while Yr0wo7FaSHx(u"ࡔࡳࡷࡨᝨ"):
				Jt6hTpCkFzMBYbyfH0 = wKt0oinq19z63uXRAga8NGm(GVPK9Ziaho6U2ySLj(u"ࠤࡁࡆࠧ࿥"), kOfDHhMnuAxQoBpWTeL, R8diDOyZNkxAWqM7mct4hgT)[tjoHEAGv2XkrMBsVfCyp5U(u"࠲ᗾ")]
				if Jt6hTpCkFzMBYbyfH0 == tvdQHb10PhNmuy6(u"࠳ᗿ"):
					R8diDOyZNkxAWqM7mct4hgT += xmTX9Aeidq8cVhY(u"࠵ᘀ")
					break
				if Jt6hTpCkFzMBYbyfH0 >= vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠶࠿࠲ᘁ"):
					OsbDWqjRwQyCeJcaX = wKt0oinq19z63uXRAga8NGm(ebT9xRB63E(u"ࠥࡂࡇࠨ࿦"), kOfDHhMnuAxQoBpWTeL, R8diDOyZNkxAWqM7mct4hgT + KylMx0kfTOrG(u"࠷ᘂ"))[oh1JUWa3LdnqTpz5(u"࠰ᘃ")]
					R8diDOyZNkxAWqM7mct4hgT = ((Jt6hTpCkFzMBYbyfH0 << ebT9xRB63E(u"࠺ᘅ")) + OsbDWqjRwQyCeJcaX - 0xc000) - uEed4OSxm7hBq9Vvky6QjHwWC(u"࠲ᘄ")
					O6DwagGX3Hu = oh1JUWa3LdnqTpz5(u"ࡕࡴࡸࡩᝩ")
				R8diDOyZNkxAWqM7mct4hgT += vlW6K1g8Xo35mPYbyO2GS(u"࠴ᘆ")
				if O6DwagGX3Hu == pOIe6U1vWYC7Gh2udFBRgT(u"ࡈࡤࡰࡸ࡫ᝪ"): wr6mOTtRuUPeN7WZjgfxC421c += tjoHEAGv2XkrMBsVfCyp5U(u"࠵ᘇ")
			if O6DwagGX3Hu == Wbwj0o5gsXQ8F2f(u"ࡗࡶࡺ࡫ᝫ"): wr6mOTtRuUPeN7WZjgfxC421c += Wbwj0o5gsXQ8F2f(u"࠶ᘈ")
			P2M5VIWXgN1qma7 = P2M5VIWXgN1qma7 + wr6mOTtRuUPeN7WZjgfxC421c
			iPxMyFGEra1cCK7sjIUleYH4opnX = wKt0oinq19z63uXRAga8NGm(xmTX9Aeidq8cVhY(u"ࠦࡃࡎࡈࡊࡊࠥ࿧"), kOfDHhMnuAxQoBpWTeL, P2M5VIWXgN1qma7)
			P2M5VIWXgN1qma7 = P2M5VIWXgN1qma7 + C0CbfZuXJM(u"࠷࠰ᘉ")
			NVHWtX7pIj3rQxZSzubMeE = iPxMyFGEra1cCK7sjIUleYH4opnX[CC4UDLW6brf(u"࠰ᘊ")]
			Jj0nHwZqiISGgKCXTyrm2L6tsY1AO = iPxMyFGEra1cCK7sjIUleYH4opnX[DItWNMaLOZ146CubYk8lfAwTy(u"࠴ᘋ")]
			if NVHWtX7pIj3rQxZSzubMeE == VVtQk9vwe7(u"࠳ᘌ"):
				lkdc08iTxmQ4yIOXEBb = wKt0oinq19z63uXRAga8NGm(vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡄࠢ࿨")+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡂࠣ࿩")*Jj0nHwZqiISGgKCXTyrm2L6tsY1AO, kOfDHhMnuAxQoBpWTeL, P2M5VIWXgN1qma7)
				ip = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠨ࿪")
				for Jt6hTpCkFzMBYbyfH0 in lkdc08iTxmQ4yIOXEBb: ip += str(Jt6hTpCkFzMBYbyfH0) + GVPK9Ziaho6U2ySLj(u"ࠨ࠰ࠪ࿫")
				ip = ip[pOIe6U1vWYC7Gh2udFBRgT(u"࠴ᘎ"):-NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠴ᘍ")]
				cFKVo2vauG0BRnXPmUdSpJCO6.append(ip)
			if NVHWtX7pIj3rQxZSzubMeE in [pOIe6U1vWYC7Gh2udFBRgT(u"࠱ᘑ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠳ᘒ"),KylMx0kfTOrG(u"࠷ᘓ"),CC4UDLW6brf(u"࠹ᘔ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠶࠻ᘏ"),Vt4ELHXZP6(u"࠸࠸ᘐ")]: P2M5VIWXgN1qma7 = P2M5VIWXgN1qma7 + Jj0nHwZqiISGgKCXTyrm2L6tsY1AO
	except: cFKVo2vauG0BRnXPmUdSpJCO6 = []
	if not cFKVo2vauG0BRnXPmUdSpJCO6: b6kj4LJ5tzTeOMQi(Vt4ELHXZP6(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࿬"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+xmTX9Aeidq8cVhY(u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ࿭")+MMZ0ya2klCVt1WqFgxo+xmTX9Aeidq8cVhY(u"ࠫࠥࡣࠧ࿮"))
	return cFKVo2vauG0BRnXPmUdSpJCO6
def t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,OG9Usa51Nk8D,lAnLtvg62C,showDialogs=Vt4ELHXZP6(u"ࡘࡷࡻࡥᝬ")):
	if lAnLtvg62C:
		QgvRjU6ZqfEu29nLmSGKY = [b098bsyjUud(u"้ࠬศศำࠪ࿯"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭ศศๆ฽ࠫ࿰"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡢࡦࡸࡰࡹ࠭࿱"),VVtQk9vwe7(u"ࠨࡺࡻࠫ࿲"),KylMx0kfTOrG(u"ࠩࡶࡩࡽ࠭࿳")]
		if FpjtBKrnu5SdfyOvEPIQ!=uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡆࡔࡑࡒࡂࠩ࿴"):
			QgvRjU6ZqfEu29nLmSGKY += [b46fBrugtPDSYspzMQIx(u"ࠫࡷࡀࠧ࿵"),Wbwj0o5gsXQ8F2f(u"ࠬࡸ࠭ࠨ࿶"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭࠭࡮ࡣࠪ࿷")]
			QgvRjU6ZqfEu29nLmSGKY += [vlW6K1g8Xo35mPYbyO2GS(u"ࠧ࠻ࡴࠪ࿸"),Vt4ELHXZP6(u"ࠨ࠯ࡵࠫ࿹"),GVPK9Ziaho6U2ySLj(u"ࠩࡰࡥ࠲࠭࿺")]
		for xfwbmueq9Oy in lAnLtvg62C:
			if b098bsyjUud(u"ࠪ࡫ࡪࡺ࠮ࡱࡪࡳࡃࠬ࿻") in xfwbmueq9Oy: continue
			if u2NDjURZVHlmdc0(u"ࠫา๊โสࠩ࿼") in xfwbmueq9Oy: continue
			xfwbmueq9Oy = xfwbmueq9Oy.lower()
			if wIqFesTOvYnu5S2dWfpBVC: xfwbmueq9Oy = xfwbmueq9Oy.decode(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬࡻࡴࡧ࠺ࠪ࿽")).encode(A6Iyo7eXrq2RtMmDxWj(u"࠭ࡵࡵࡨ࠻ࠫ࿾"))
			xfwbmueq9Oy = xfwbmueq9Oy.replace(ebT9xRB63E(u"ࠧ࠻ࠩ࿿"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࠩက"))
			qCixvm1HV3fsR = JJDtX1PZyIgN2T.findall(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࠫ࠵ࡠ࠻࠭࠺࡟࠮ࢀ࠷ࡡ࠰࠮࠵ࡠ࠯࠮࠭ခ"),xfwbmueq9Oy,JJDtX1PZyIgN2T.DOTALL)
			I92IN7yHG6BOmYADXFj48w = oh1JUWa3LdnqTpz5(u"ࡋࡧ࡬ࡴࡧ᝭")
			for OOrYfI1iMWXFPvHAz35tJ7G in qCixvm1HV3fsR:
				if len(OOrYfI1iMWXFPvHAz35tJ7G)==trSQHvP4aqBWFKxN5bZgXCu(u"࠶ᘕ"):
					I92IN7yHG6BOmYADXFj48w = DItWNMaLOZ146CubYk8lfAwTy(u"࡚ࡲࡶࡧᝮ")
					break
			if A6Iyo7eXrq2RtMmDxWj(u"ࠪࡲࡴࡺࠠࡳࡣࡷࡩࡩ࠭ဂ") in xfwbmueq9Oy: continue
			elif Vt4ELHXZP6(u"ࠫࡺࡴࡲࡢࡶࡨࡨࠬဃ") in xfwbmueq9Oy: continue
			elif trSQHvP4aqBWFKxN5bZgXCu(u"ࠬเ๊าู่๋ࠢ็ࠧင") in xfwbmueq9Oy: continue
			elif HRnwFcAJIxaoXEbYQ(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡂࡕࡇࡻࡔ࡛࠷࠹ࡔࡔ࡙ࡒ࡚࡛࡬ࡗࡆ࡙ࡉ࡛ࡋࡘࠨစ")): continue
			elif xfwbmueq9Oy in [GVPK9Ziaho6U2ySLj(u"ࠧࡳࠩဆ")] or I92IN7yHG6BOmYADXFj48w or any(Y3YqSmycrIWksoH5N0MvC in xfwbmueq9Oy for Y3YqSmycrIWksoH5N0MvC in QgvRjU6ZqfEu29nLmSGKY):
				b6kj4LJ5tzTeOMQi(cg94WALw5orUhvtHSfNO(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ဇ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࠣࠤࠥࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡡࡥࡷ࡯ࡸࡸࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨဈ")+OG9Usa51Nk8D+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠤࡢ࠭ဉ"))
				if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(tjoHEAGv2XkrMBsVfCyp5U(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧည"),CC4UDLW6brf(u"ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧဋ"))
				return YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡔࡳࡷࡨᝯ")
	return DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪᝰ")
def ArKbmeZFN7cRuvjfiHBJ0SEqd2l(*aargs,**kkwargs):
	if aargs:
		direction = aargs[CC4UDLW6brf(u"࠵ᘖ")]
		zdUlkEN5YBtw = aargs[vlW6K1g8Xo35mPYbyO2GS(u"࠷ᘗ")]
		if not direction: direction = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ဌ")
		if not zdUlkEN5YBtw: zdUlkEN5YBtw = G5TxeI0ND4ztC6(u"ࠧศีอ้ึอัࠨဍ")
		VR9om4rMYs5 = aargs[oh1JUWa3LdnqTpz5(u"࠲ᘘ")]
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = GVPK9Ziaho6U2ySLj(u"ࠨ࡞ࡱࠫဎ").join(aargs[tjoHEAGv2XkrMBsVfCyp5U(u"࠴ᘙ"):])
	else: direction,zdUlkEN5YBtw,VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU = ebT9xRB63E(u"ࠩࠪဏ"),oh1JUWa3LdnqTpz5(u"ࠪࡓࡐ࠭တ"),Yr0wo7FaSHx(u"ࠫࠬထ"),G5TxeI0ND4ztC6(u"ࠬ࠭ဒ")
	VYEiZteQcrT7aqOBMRAyHC9(direction,b46fBrugtPDSYspzMQIx(u"࠭ࠧဓ"),zdUlkEN5YBtw,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠨန"),VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,**kkwargs)
	return
def MMTfC8jWkbhxp2BDt(*aargs,**kkwargs):
	direction = aargs[A6Iyo7eXrq2RtMmDxWj(u"࠲ᘚ")]
	KyICEW0U7TMYjaqmP = aargs[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴ᘛ")]
	yoNZG4QTsXqD9SlF = aargs[xmTX9Aeidq8cVhY(u"࠶ᘜ")]
	if yoNZG4QTsXqD9SlF or KyICEW0U7TMYjaqmP: DutRk0ajiwqcn4sXVHZmFe = vdHRKkIgTp56Je1OuNo(u"ࡖࡵࡹࡪ᝱")
	else: DutRk0ajiwqcn4sXVHZmFe = A6Iyo7eXrq2RtMmDxWj(u"ࡉࡥࡱࡹࡥᝲ")
	VR9om4rMYs5 = aargs[b46fBrugtPDSYspzMQIx(u"࠸ᘝ")]
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = aargs[CC4UDLW6brf(u"࠺ᘞ")]
	if not direction: direction = cg94WALw5orUhvtHSfNO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨပ")
	if not KyICEW0U7TMYjaqmP: KyICEW0U7TMYjaqmP = tvdQHb10PhNmuy6(u"ࠩๆ่ฬࠦࠠࡏࡱࠪဖ")
	if not yoNZG4QTsXqD9SlF: yoNZG4QTsXqD9SlF = trSQHvP4aqBWFKxN5bZgXCu(u"๊ࠪ฾๋࡛ࠠࠡࡨࡷࠬဗ")
	if len(aargs)>=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠷ᘠ"): JJ23NOKSjik1hg8Ts7CXbevYzrQHU += VVtQk9vwe7(u"ࠫࡡࡴࠧဘ")+aargs[vdHRKkIgTp56Je1OuNo(u"࠵ᘟ")]
	if len(aargs)>=cg94WALw5orUhvtHSfNO(u"࠹ᘡ"): JJ23NOKSjik1hg8Ts7CXbevYzrQHU += b46fBrugtPDSYspzMQIx(u"ࠬࡢ࡮ࠨမ")+aargs[Vt4ELHXZP6(u"࠹ᘢ")]
	WnbmLQXcr7JdDtRyEe = VYEiZteQcrT7aqOBMRAyHC9(direction,KyICEW0U7TMYjaqmP,Yr0wo7FaSHx(u"࠭ࠧယ"),yoNZG4QTsXqD9SlF,VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,**kkwargs)
	if WnbmLQXcr7JdDtRyEe==-mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵ᘣ") and DutRk0ajiwqcn4sXVHZmFe: WnbmLQXcr7JdDtRyEe = -mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵ᘣ")
	elif WnbmLQXcr7JdDtRyEe==-Yr0wo7FaSHx(u"࠶ᘤ") and not DutRk0ajiwqcn4sXVHZmFe: WnbmLQXcr7JdDtRyEe = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࡊࡦࡲࡳࡦᝳ")
	elif WnbmLQXcr7JdDtRyEe==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᘥ"): WnbmLQXcr7JdDtRyEe = Yr0wo7FaSHx(u"ࡋࡧ࡬ࡴࡧ᝴")
	elif WnbmLQXcr7JdDtRyEe==pOIe6U1vWYC7Gh2udFBRgT(u"࠲ᘦ"): WnbmLQXcr7JdDtRyEe = cg94WALw5orUhvtHSfNO(u"࡚ࡲࡶࡧ᝵")
	return WnbmLQXcr7JdDtRyEe
def wicVSPINX4Unkqr5hsgJa6AO8jCT(*aargs,**kkwargs):
	return U6zsmRNGTL.Dialog().select(*aargs,**kkwargs)
def sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(*aargs,**kkwargs):
	VR9om4rMYs5 = aargs[pOIe6U1vWYC7Gh2udFBRgT(u"࠱ᘧ")]
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = aargs[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠳ᘨ")]
	if mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡵ࡫ࡰࡩࠬရ") in list(kkwargs.keys()): ZugIU9y2JaxqSWinewF = kkwargs[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡶ࡬ࡱࡪ࠭လ")]
	else: ZugIU9y2JaxqSWinewF = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠴࠴࠵࠶ᘩ")
	if len(aargs)>vlW6K1g8Xo35mPYbyO2GS(u"࠶ᘪ") and Yr0wo7FaSHx(u"ࠩࡷ࡭ࡲ࡫ࠧဝ") not in aargs[vlW6K1g8Xo35mPYbyO2GS(u"࠶ᘪ")]: profile = aargs[vlW6K1g8Xo35mPYbyO2GS(u"࠶ᘪ")]
	else: profile = xmTX9Aeidq8cVhY(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩသ")
	y5yavHuw7kt1Vc8AiNKM9BWQSP = jLxTKuQmGcE(Vt4ELHXZP6(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡒࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡋࡰࡥ࡬࡫࠮ࡹ࡯࡯ࠫဟ"),fcISoWNUG0HKemCtBpAy9MV,xmTX9Aeidq8cVhY(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ဠ"),WfgnOq9Fd4lhMSQpK5(u"࠭࠷࠳࠲ࡳࠫအ"))
	image_filename = dnX2tKhRgS49YB7bCv.replace(tvdQHb10PhNmuy6(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧဢ"),Yr0wo7FaSHx(u"ࠨࡡࠪဣ")+str(Mrx2OeZV1LNjBsQ58Savi7.time())+KylMx0kfTOrG(u"ࠩࡢࠫဤ"))
	image_filename = image_filename.replace(trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡠࡡ࠭ဥ"),Wbwj0o5gsXQ8F2f(u"ࠫࡡࡢ࡜࡝ࠩဦ")).replace(Wbwj0o5gsXQ8F2f(u"ࠬ࠵࠯ࠨဧ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭࠯࠰࠱࠲ࠫဨ"))
	image_height = Whl52Kf4SzyA9qBOujbeLQtIJM(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠨဩ"),C0CbfZuXJM(u"ࠨࠩဪ"),b46fBrugtPDSYspzMQIx(u"ࠩࠪါ"),VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile,pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡰࡪ࡬ࡴࠨာ"),WfgnOq9Fd4lhMSQpK5(u"ࡆࡢ࡮ࡶࡩ᝶"),image_filename)
	y5yavHuw7kt1Vc8AiNKM9BWQSP.show()
	if profile==cg94WALw5orUhvtHSfNO(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬိ"):
		y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(A6Iyo7eXrq2RtMmDxWj(u"࠿࠰࠵࠲ᘬ")).setHeight(cg94WALw5orUhvtHSfNO(u"࠷࠷࠵ᘫ"))
		y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠻࠳࠸࠵ᘯ")).setPosition(G5TxeI0ND4ztC6(u"࠵࠶ᘭ"),-u2NDjURZVHlmdc0(u"࠹࠲ᘮ"))
		y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠼࠴࠺࠶ᘰ")).setPosition(tjoHEAGv2XkrMBsVfCyp5U(u"࠵࠷࠶ᘱ"),-b098bsyjUud(u"࠻࠶ᘲ"))
		y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(Vt4ELHXZP6(u"࠵࠲࠳ᘵ")).setPosition(xmTX9Aeidq8cVhY(u"࠿࠰ᘳ"),-G5TxeI0ND4ztC6(u"࠳࠶ᘴ"))
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(G5TxeI0ND4ztC6(u"࠶࠳࠵ᘶ")).setVisible(Vt4ELHXZP6(u"ࡇࡣ࡯ࡷࡪ᝷"))
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠷࠴࠷ᘷ")).setVisible(vdHRKkIgTp56Je1OuNo(u"ࡈࡤࡰࡸ࡫᝸"))
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(Vt4ELHXZP6(u"࠽࠵࠻࠰ᘸ")).setImage(image_filename)
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(trSQHvP4aqBWFKxN5bZgXCu(u"࠾࠶࠵࠱ᘹ")).setHeight(image_height)
	db6imBFafuwc7 = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=crJk4bSX20thDL3UQGa179oIPxs,args=(y5yavHuw7kt1Vc8AiNKM9BWQSP,image_filename,ZugIU9y2JaxqSWinewF))
	db6imBFafuwc7.start()
	return
def crJk4bSX20thDL3UQGa179oIPxs(y5yavHuw7kt1Vc8AiNKM9BWQSP,image_filename,ZugIU9y2JaxqSWinewF):
	Mrx2OeZV1LNjBsQ58Savi7.sleep(ZugIU9y2JaxqSWinewF//vlW6K1g8Xo35mPYbyO2GS(u"࠷࠰࠱࠲࠱࠴ᘺ"))
	Mrx2OeZV1LNjBsQ58Savi7.sleep(tjoHEAGv2XkrMBsVfCyp5U(u"࠰࠯࠳࠳࠴ᘻ"))
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(image_filename):
		try: A73K6zLXIgFROeCHJQi0Pbos.remove(image_filename)
		except: pass
	return
def iTYQXEG9swpIWC(*aargs,**kkwargs):
	VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile,direction = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬ࠭ီ"),KylMx0kfTOrG(u"࠭ࠧု"),CC4UDLW6brf(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨူ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨ࡮ࡨࡪࡹ࠭ေ")
	if len(aargs)>=jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠲ᘼ"): VR9om4rMYs5 = aargs[CC4UDLW6brf(u"࠲ᘽ")]
	if len(aargs)>=oh1JUWa3LdnqTpz5(u"࠶ᘿ"): JJ23NOKSjik1hg8Ts7CXbevYzrQHU = aargs[C0CbfZuXJM(u"࠴ᘾ")]
	if len(aargs)>=uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸ᙀ"): profile = aargs[Wbwj0o5gsXQ8F2f(u"࠸ᙁ")]
	if len(aargs)>=YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵ᙃ"): direction = aargs[Vt4ELHXZP6(u"࠳ᙂ")]
	return u59uk1YqFUTd(direction,VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile)
def nnd9gykLENea43cI2rZM(*aargs,**kkwargs):
	return U6zsmRNGTL.Dialog().contextmenu(*aargs,**kkwargs)
def ly0NGuYRPesoatS1kEwZMbWOX2UK(*aargs,**kkwargs):
	return U6zsmRNGTL.Dialog().browseSingle(*aargs,**kkwargs)
def jrENWRfiCOxlsHVtQXJk351LFZn(*aargs,**kkwargs):
	return U6zsmRNGTL.Dialog().input(*aargs,**kkwargs)
def W2mNFlgkhXS8KIQ0GcTt(*aargs,**kkwargs):
	return U6zsmRNGTL.DialogProgress(*aargs,**kkwargs)
def EYgQHCJOMW98Ps2wf(GfLA09yvr7FZmiX):
	if WWSLAyQdhUXl3ovb>C0CbfZuXJM(u"࠳࠺࠲࠾࠿ᙄ"): y5yavHuw7kt1Vc8AiNKM9BWQSP = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧဲ")
	else: y5yavHuw7kt1Vc8AiNKM9BWQSP = ebT9xRB63E(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧဳ")
	GfLA09yvr7FZmiX = GfLA09yvr7FZmiX.lower()
	if GfLA09yvr7FZmiX==trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡸࡺࡡࡳࡶࠪဴ"): Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(xmTX9Aeidq8cVhY(u"ࠬࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࠧဵ")+y5yavHuw7kt1Vc8AiNKM9BWQSP+GVPK9Ziaho6U2ySLj(u"࠭ࠩࠨံ"))
	elif GfLA09yvr7FZmiX==Yr0wo7FaSHx(u"ࠧࡴࡶࡲࡴ့ࠬ"): Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(tvdQHb10PhNmuy6(u"ࠨࡆ࡬ࡥࡱࡵࡧ࠯ࡅ࡯ࡳࡸ࡫ࠨࠨး")+y5yavHuw7kt1Vc8AiNKM9BWQSP+Wbwj0o5gsXQ8F2f(u"္ࠩࠬࠫ"))
	return
def VYEiZteQcrT7aqOBMRAyHC9(direction,button0=Vt4ELHXZP6(u"်ࠪࠫ"),button1=YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠬျ"),button2=KylMx0kfTOrG(u"ࠬ࠭ြ"),VR9om4rMYs5=b46fBrugtPDSYspzMQIx(u"࠭ࠧွ"),JJ23NOKSjik1hg8Ts7CXbevYzrQHU=C0CbfZuXJM(u"ࠧࠨှ"),profile=Wbwj0o5gsXQ8F2f(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪဿ"),XXmJYfqDLar=cg94WALw5orUhvtHSfNO(u"࠳ᙅ"),UfxNh0qP3p=cg94WALw5orUhvtHSfNO(u"࠳ᙅ")):
	if not direction: direction = tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡦࡩࡳࡺࡥࡳࠩ၀")
	y5yavHuw7kt1Vc8AiNKM9BWQSP = rIH5SkfPXyxZecRbQzoq(G5TxeI0ND4ztC6(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ၁"),fcISoWNUG0HKemCtBpAy9MV,G5TxeI0ND4ztC6(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ၂"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠬ࠽࠲࠱ࡲࠪ၃"))
	y5yavHuw7kt1Vc8AiNKM9BWQSP.htEbDv0jQV2NAB9ZHRkWoYUTpsXS(button0,button1,button2,VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile,direction,XXmJYfqDLar,UfxNh0qP3p)
	if XXmJYfqDLar>KylMx0kfTOrG(u"࠴ᙆ"): y5yavHuw7kt1Vc8AiNKM9BWQSP.zNCheP0cUL1osQYa()
	if UfxNh0qP3p>YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵ᙇ"): y5yavHuw7kt1Vc8AiNKM9BWQSP.jjDvSx5hJGWgrMVR4yEpTQ7aAz()
	if XXmJYfqDLar==DItWNMaLOZ146CubYk8lfAwTy(u"࠶ᙈ") and UfxNh0qP3p==DItWNMaLOZ146CubYk8lfAwTy(u"࠶ᙈ"): y5yavHuw7kt1Vc8AiNKM9BWQSP.o2dXg3TlO0()
	y5yavHuw7kt1Vc8AiNKM9BWQSP.doModal()
	WnbmLQXcr7JdDtRyEe = y5yavHuw7kt1Vc8AiNKM9BWQSP.choiceID
	return WnbmLQXcr7JdDtRyEe
def u59uk1YqFUTd(direction,VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile=uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ၄")):
	if not direction: direction = pOIe6U1vWYC7Gh2udFBRgT(u"ࠧ࡭ࡧࡩࡸࠬ၅")
	y5yavHuw7kt1Vc8AiNKM9BWQSP = jLxTKuQmGcE(vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡆ࡬ࡥࡱࡵࡧࡕࡧࡻࡸ࡛࡯ࡥࡸࡧࡵࡊࡺࡲ࡬ࡔࡥࡵࡩࡪࡴ࠮ࡹ࡯࡯ࠫ၆"),fcISoWNUG0HKemCtBpAy9MV,GVPK9Ziaho6U2ySLj(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ၇"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪ࠻࠷࠶ࡰࠨ၈"))
	image_filename = dnX2tKhRgS49YB7bCv.replace(VVtQk9vwe7(u"ࠫࡤ࠶࠰࠱࠲ࡢࠫ၉"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡥࠧ၊")+str(Mrx2OeZV1LNjBsQ58Savi7.time())+trSQHvP4aqBWFKxN5bZgXCu(u"࠭࡟ࠨ။"))
	image_filename = image_filename.replace(cg94WALw5orUhvtHSfNO(u"ࠧ࡝࡞ࠪ၌"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨ࡞࡟ࡠࡡ࠭၍")).replace(CC4UDLW6brf(u"ࠩ࠲࠳ࠬ၎"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪ࠳࠴࠵࠯ࠨ၏"))
	image_height = Whl52Kf4SzyA9qBOujbeLQtIJM(WfgnOq9Fd4lhMSQpK5(u"ࠫࠬၐ"),ebT9xRB63E(u"ࠬ࠭ၑ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࠧၒ"),VR9om4rMYs5,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,profile,direction,G5TxeI0ND4ztC6(u"ࡉࡥࡱࡹࡥ᝹"),image_filename)
	y5yavHuw7kt1Vc8AiNKM9BWQSP.show()
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(GVPK9Ziaho6U2ySLj(u"࠹࠱࠷࠳ᙉ")).setHeight(image_height)
	y5yavHuw7kt1Vc8AiNKM9BWQSP.getControl(cg94WALw5orUhvtHSfNO(u"࠺࠲࠸࠴ᙊ")).setImage(image_filename)
	xJhY7dQvaLoFCkGB0e4ZsEp6PSH = y5yavHuw7kt1Vc8AiNKM9BWQSP.doModal()
	try: A73K6zLXIgFROeCHJQi0Pbos.remove(image_filename)
	except: pass
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def yyYKmdtsAFic93(LzbYnZw1jq=GVPK9Ziaho6U2ySLj(u"ࡘࡷࡻࡥ᝺")):
	if LzbYnZw1jq:
		ASwKFJhGY15gO4tLTd6fN0M = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡴࡶࡵࠫၓ"),Yr0wo7FaSHx(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫၔ"),b46fBrugtPDSYspzMQIx(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬၕ"))
		if ASwKFJhGY15gO4tLTd6fN0M: return ASwKFJhGY15gO4tLTd6fN0M
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = VVtQk9vwe7(u"ࠪࠫၖ")
	if tjoHEAGv2XkrMBsVfCyp5U(u"࠲ᙋ") and QBDjIUdSiR.succeeded:
		TMq6SKsGo5muadx = QBDjIUdSiR.content
		fKG1iuWHwak9qCml6M7F = TMq6SKsGo5muadx.count(u2NDjURZVHlmdc0(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥࠬၗ"))
		if fKG1iuWHwak9qCml6M7F>hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠻࠴ᙌ"):
			JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJDtX1PZyIgN2T.findall(tvdQHb10PhNmuy6(u"ࠬ࡭ࡥࡵ࠯ࡷ࡬ࡪ࠳࡬ࡪࡵࡷ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧၘ"),TMq6SKsGo5muadx,JJDtX1PZyIgN2T.DOTALL)
			JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠴ᙍ")]
	if not JJ23NOKSjik1hg8Ts7CXbevYzrQHU:
		nEJG9gNd4BR5ArXYV = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,oh1JUWa3LdnqTpz5(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬၙ"),xmTX9Aeidq8cVhY(u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨၚ"))
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = open(nEJG9gNd4BR5ArXYV,tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡴࡥࠫၛ")).read()
		if DQfHadYvTpy1UR: JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.decode(b46fBrugtPDSYspzMQIx(u"ࠩࡸࡸ࡫࠾ࠧၜ"))
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(C0CbfZuXJM(u"ࠪࡠࡷ࠭ၝ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࠬၞ"))
	yNjz6Ym2tCBeVgq = JJDtX1PZyIgN2T.findall(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬ࠮ࡍࡰࡼ࡬ࡰࡱࡧ࠮ࠫࡁࠬࡠࡳ࠭ၟ"),JJ23NOKSjik1hg8Ts7CXbevYzrQHU,JJDtX1PZyIgN2T.DOTALL)
	tmUMekLREjAgx4Yr62JTOV1D7iX = []
	for Ik5bst9OBynwor01jzgCKP in yNjz6Ym2tCBeVgq:
		uVYinylKevzHLd = Ik5bst9OBynwor01jzgCKP.lower()
		if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡡ࡯ࡦࡵࡳ࡮ࡪࠧၠ") in uVYinylKevzHLd: continue
		if VVtQk9vwe7(u"ࠧࡶࡤࡸࡲࡹࡻࠧၡ") in uVYinylKevzHLd: continue
		if pOIe6U1vWYC7Gh2udFBRgT(u"ࠨ࡫ࡳ࡬ࡴࡴࡥࠨၢ") in uVYinylKevzHLd: continue
		if vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡦࡶࡴࡹࠧၣ") in uVYinylKevzHLd: continue
		tmUMekLREjAgx4Yr62JTOV1D7iX.append(Ik5bst9OBynwor01jzgCKP)
	ASwKFJhGY15gO4tLTd6fN0M = GpOkwndjsI27uM.sample(tmUMekLREjAgx4Yr62JTOV1D7iX,VVtQk9vwe7(u"࠶ᙎ"))
	ASwKFJhGY15gO4tLTd6fN0M = ASwKFJhGY15gO4tLTd6fN0M[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠶ᙏ")]
	pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ၤ"),ebT9xRB63E(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧၥ"),ASwKFJhGY15gO4tLTd6fN0M,DkRgFyVIBM85OA)
	return ASwKFJhGY15gO4tLTd6fN0M
def aXQw4TyRhrp(n6MNfIpoX7GgJZu=C0CbfZuXJM(u"ࠬ࠭ၦ")):
	if not n6MNfIpoX7GgJZu: n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
	if n6MNfIpoX7GgJZu!=A6Iyo7eXrq2RtMmDxWj(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩၧ"): uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
	tBFLs10gh4MQyeXa5xSnqlPWdE = n6MNfIpoX7GgJZu.splitlines()
	CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ = tBFLs10gh4MQyeXa5xSnqlPWdE[-C0CbfZuXJM(u"࠱ᙐ")]
	hM4qti5nUPD8VXlAgoGHpJQN = open(ZOf4z17vyLarQYEUAHK2dJS,vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡳࡤࠪၨ")).read()
	if DQfHadYvTpy1UR: hM4qti5nUPD8VXlAgoGHpJQN = hM4qti5nUPD8VXlAgoGHpJQN.decode(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡷࡷࡪ࠽࠭ၩ"))
	hM4qti5nUPD8VXlAgoGHpJQN = hM4qti5nUPD8VXlAgoGHpJQN[-G5TxeI0ND4ztC6(u"࠹࠲࠳࠴ᙑ"):]
	trXfJN2hZ6joUOa = Yr0wo7FaSHx(u"ࠩࡀࠫၪ")*xmTX9Aeidq8cVhY(u"࠳࠳࠴ᙒ")
	if trXfJN2hZ6joUOa in hM4qti5nUPD8VXlAgoGHpJQN: hM4qti5nUPD8VXlAgoGHpJQN = hM4qti5nUPD8VXlAgoGHpJQN.rsplit(trXfJN2hZ6joUOa,DItWNMaLOZ146CubYk8lfAwTy(u"࠴ᙓ"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠴ᙓ")]
	if CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ in hM4qti5nUPD8VXlAgoGHpJQN: hM4qti5nUPD8VXlAgoGHpJQN = hM4qti5nUPD8VXlAgoGHpJQN.rsplit(CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ,trSQHvP4aqBWFKxN5bZgXCu(u"࠵ᙔ"))[oh1JUWa3LdnqTpz5(u"࠵ᙕ")]
	MF6q1p9BT4ir = JJDtX1PZyIgN2T.findall(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࠬࡘࡵࡵࡳࡥࡨࢀࡒࡵࡤࡦࠫ࠽ࠤࡡࡡࠠࠩ࠰࠭ࡃ࠮ࠦ࡜࡞ࠩၫ"),hM4qti5nUPD8VXlAgoGHpJQN,JJDtX1PZyIgN2T.DOTALL)
	for YYZCoJESBrR6liDWAsxy,dbBRqLP6WeEV in reversed(MF6q1p9BT4ir):
		if dbBRqLP6WeEV: break
	else: dbBRqLP6WeEV = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡓࡕࡔࠡࡕࡓࡉࡈࡏࡆࡊࡇࡇࠫၬ")
	wErcn0kLyWxu6JG,Ik5bst9OBynwor01jzgCKP,cniFJsxa6TVCBY7 = DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࠭ၭ"),tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࠧၮ"),VVtQk9vwe7(u"ࠧࠨၯ")
	WVKFXGwJuUL7zmC5dlZ2x0 = A6Iyo7eXrq2RtMmDxWj(u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษ࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫၰ")+CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ
	Cpxc4DQXoJyY5WO2dTFBAbMRne = GVPK9Ziaho6U2ySLj(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊฻ฯา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၱ")+dbBRqLP6WeEV
	for xI6cTVBst8 in reversed(tBFLs10gh4MQyeXa5xSnqlPWdE):
		if hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡊ࡮ࡲࡥࠡࠤࠪၲ") in xI6cTVBst8 and trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪၳ") in xI6cTVBst8: break
	xI6cTVBst8 = JJDtX1PZyIgN2T.findall(KylMx0kfTOrG(u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨၴ"),xI6cTVBst8,JJDtX1PZyIgN2T.DOTALL)
	if xI6cTVBst8:
		wErcn0kLyWxu6JG,Ik5bst9OBynwor01jzgCKP,cniFJsxa6TVCBY7 = xI6cTVBst8[b46fBrugtPDSYspzMQIx(u"࠶ᙖ")]
		if G5TxeI0ND4ztC6(u"࠭࠯ࠨၵ") in wErcn0kLyWxu6JG: wErcn0kLyWxu6JG = wErcn0kLyWxu6JG.rsplit(C0CbfZuXJM(u"ࠧ࠰ࠩၶ"),Wbwj0o5gsXQ8F2f(u"࠱ᙗ"))[Wbwj0o5gsXQ8F2f(u"࠱ᙗ")]
		else: wErcn0kLyWxu6JG = wErcn0kLyWxu6JG.rsplit(b098bsyjUud(u"ࠨ࡞࡟ࠫၷ"),oh1JUWa3LdnqTpz5(u"࠲ᙘ"))[oh1JUWa3LdnqTpz5(u"࠲ᙘ")]
		Gi5SMLAFsxRaJfpCVUlO = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊๊แ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬၸ")+wErcn0kLyWxu6JG
		M8trsjfn2wdaUAPkgYi5mORV7TLSx = u2NDjURZVHlmdc0(u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ืา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ၹ")+Ik5bst9OBynwor01jzgCKP
		q9hPilAcSWVaQwpu1BCxT4JKzvm03 = DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅไษ้࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨၺ")+cniFJsxa6TVCBY7
		JPDT1h3CA7pbI8smEVKHB = Gi5SMLAFsxRaJfpCVUlO+b46fBrugtPDSYspzMQIx(u"ࠬࡢ࡮ࠨၻ")+M8trsjfn2wdaUAPkgYi5mORV7TLSx+G5TxeI0ND4ztC6(u"࠭࡜࡯ࠩၼ")+q9hPilAcSWVaQwpu1BCxT4JKzvm03+u2NDjURZVHlmdc0(u"ࠧ࡝ࡰࠪၽ")+Cpxc4DQXoJyY5WO2dTFBAbMRne+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨ࡞ࡱࠫၾ")+WVKFXGwJuUL7zmC5dlZ2x0
		ov49gJjUZhaA3lLR7Cprz0NBqVsm = M8trsjfn2wdaUAPkgYi5mORV7TLSx+Yr0wo7FaSHx(u"ࠩ࡟ࡲࠬၿ")+Cpxc4DQXoJyY5WO2dTFBAbMRne+trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡠࡳ࠭ႀ")+WVKFXGwJuUL7zmC5dlZ2x0+tvdQHb10PhNmuy6(u"ࠫࡡࡴࠧႁ")+Gi5SMLAFsxRaJfpCVUlO+G5TxeI0ND4ztC6(u"ࠬࡢ࡮ࠨႂ")+q9hPilAcSWVaQwpu1BCxT4JKzvm03
		Q2PuhNLR9pojadfnHM5I = M8trsjfn2wdaUAPkgYi5mORV7TLSx+trSQHvP4aqBWFKxN5bZgXCu(u"࠭࡜࡯ࠩႃ")+WVKFXGwJuUL7zmC5dlZ2x0+cg94WALw5orUhvtHSfNO(u"ࠧ࡝ࡰࠪႄ")+Gi5SMLAFsxRaJfpCVUlO+A6Iyo7eXrq2RtMmDxWj(u"ࠨ࡞ࡱࠫႅ")+q9hPilAcSWVaQwpu1BCxT4JKzvm03
	else:
		Gi5SMLAFsxRaJfpCVUlO,M8trsjfn2wdaUAPkgYi5mORV7TLSx,q9hPilAcSWVaQwpu1BCxT4JKzvm03 = A6Iyo7eXrq2RtMmDxWj(u"ࠩࠪႆ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࠫႇ"),b46fBrugtPDSYspzMQIx(u"ࠫࠬႈ")
		JPDT1h3CA7pbI8smEVKHB = Cpxc4DQXoJyY5WO2dTFBAbMRne+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡢ࡮࡝ࡰࠪႉ")+WVKFXGwJuUL7zmC5dlZ2x0
		ov49gJjUZhaA3lLR7Cprz0NBqVsm = Cpxc4DQXoJyY5WO2dTFBAbMRne+oh1JUWa3LdnqTpz5(u"࠭࡜࡯࡞ࡱࠫႊ")+WVKFXGwJuUL7zmC5dlZ2x0
		Q2PuhNLR9pojadfnHM5I = WVKFXGwJuUL7zmC5dlZ2x0
	khPUlHDJpORyI9cM6dCjLS = b098bsyjUud(u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าࠫႋ")+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨ࡞ࡱࠫႌ")
	ryWxkOZDFuUpzVt9Y7is = AWVr61C0oZpxaeUj78YDiOnP()
	c2ITfhv4ils9Jabu8BQ = []
	mL7BVKcSygkuoPbWlEF4YD = ryWxkOZDFuUpzVt9Y7is[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹႍࠧ")]
	ggvCYlMLXi = gVGcSPqfTBC8Z0u(K0dHTfq6P73sD8lWLZpoh)
	if KylMx0kfTOrG(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨႎ") in list(ryWxkOZDFuUpzVt9Y7is.keys()):
		for NfKOPmGr2StWoEdMaRI5euc4wqZ1,pNDMn09wHg23,zHQRe0Mk8g2JDaOKYEto43v in mL7BVKcSygkuoPbWlEF4YD: c2ITfhv4ils9Jabu8BQ = max(c2ITfhv4ils9Jabu8BQ,pNDMn09wHg23)
		if ggvCYlMLXi<c2ITfhv4ils9Jabu8BQ:
			VR9om4rMYs5 = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫ็๋ࠠษฬะำ๏ัࠠศๆหี๋อๅอࠢๅฬ้ࠦลาีส่ࠥอไฤะฺหฦࠦไๅ็หี๊าࠧႏ")
			WnbmLQXcr7JdDtRyEe = VYEiZteQcrT7aqOBMRAyHC9(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬࡸࡩࡨࡪࡷࠫ႐"),b098bsyjUud(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪ႑"),b46fBrugtPDSYspzMQIx(u"ࠧหฯา๎ะ࠭႒"),GVPK9Ziaho6U2ySLj(u"ࠨะิ์ั࠭႓"),khPUlHDJpORyI9cM6dCjLS+VR9om4rMYs5,JPDT1h3CA7pbI8smEVKHB)
			if WnbmLQXcr7JdDtRyEe==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠲ᙙ"):
				J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(VVtQk9vwe7(u"ࠩࡦࡩࡳࡺࡥࡳࠩ႔"),oh1JUWa3LdnqTpz5(u"ࠪาึ๎ฬࠨ႕"),C0CbfZuXJM(u"ࠫฯำฯ๋อࠪ႖"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠬ࠭႗"),VR9om4rMYs5)
				if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==vdHRKkIgTp56Je1OuNo(u"࠴ᙚ"): WnbmLQXcr7JdDtRyEe = vdHRKkIgTp56Je1OuNo(u"࠴ᙚ")
			if WnbmLQXcr7JdDtRyEe==WfgnOq9Fd4lhMSQpK5(u"࠵ᙛ"):
				import COH7BKApEP
				COH7BKApEP.uuzerSw4k8bt3QKD9cAjhgBvPMim(WfgnOq9Fd4lhMSQpK5(u"࡙ࡸࡵࡦ᝻"),WfgnOq9Fd4lhMSQpK5(u"࡙ࡸࡵࡦ᝻"))
			return
	jZesU1zPQ2KRFIMV0AvbWlBTu = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,ebT9xRB63E(u"࠭࡬ࡪࡵࡷࠫ႘"),CC4UDLW6brf(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ႙"),C0CbfZuXJM(u"ࠨࡃࡏࡐࡤ࡙ࡅࡏࡖࡢࡉࡗࡘࡏࡓࡕࠪႚ"))
	if not jZesU1zPQ2KRFIMV0AvbWlBTu: jZesU1zPQ2KRFIMV0AvbWlBTu = []
	ov49gJjUZhaA3lLR7Cprz0NBqVsm = ov49gJjUZhaA3lLR7Cprz0NBqVsm.replace(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࡟ࡲࠬႛ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡠࡡࡴࠧႜ")).replace(b46fBrugtPDSYspzMQIx(u"ࠫࡠࡘࡔࡍ࡟ࠪႝ"),WfgnOq9Fd4lhMSQpK5(u"ࠬ࠭႞")).replace(tvdQHb10PhNmuy6(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ႟"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࠨႠ")).replace(Wbwj0o5gsXQ8F2f(u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪႡ"),Wbwj0o5gsXQ8F2f(u"ࠩࠪႢ"))
	Q2PuhNLR9pojadfnHM5I = Q2PuhNLR9pojadfnHM5I.replace(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡠࡳ࠭Ⴃ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࡡࡢ࡮ࠨႤ")).replace(A6Iyo7eXrq2RtMmDxWj(u"ࠬࡡࡒࡕࡎࡠࠫႥ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࠧႦ")).replace(A6Iyo7eXrq2RtMmDxWj(u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪႧ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩႨ")).replace(Wbwj0o5gsXQ8F2f(u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫႩ"),C0CbfZuXJM(u"ࠪࠫႪ"))
	Wfz542FncotmO = K0dHTfq6P73sD8lWLZpoh+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫ࠿ࡀࠧႫ")+Q2PuhNLR9pojadfnHM5I
	if Wfz542FncotmO in jZesU1zPQ2KRFIMV0AvbWlBTu:
		VR9om4rMYs5 = u2NDjURZVHlmdc0(u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪႬ")
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(oh1JUWa3LdnqTpz5(u"࠭ࡲࡪࡩ࡫ࡸࠬႭ"),xmTX9Aeidq8cVhY(u"ࠧࠨႮ"),khPUlHDJpORyI9cM6dCjLS+VR9om4rMYs5,JPDT1h3CA7pbI8smEVKHB)
		return
	uZbwhWJlKAea610D2Q3iCO8sTjg = str(WWSLAyQdhUXl3ovb).split(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨ࠰ࠪႯ"))[tjoHEAGv2XkrMBsVfCyp5U(u"࠵ᙜ")]
	OG9Usa51Nk8D = LWzUbE5adDslTXGr[VVtQk9vwe7(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩႰ")][DItWNMaLOZ146CubYk8lfAwTy(u"࠼ᙝ")]
	QBDjIUdSiR = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,G5TxeI0ND4ztC6(u"ࠪࡔࡔ࡙ࡔࠨႱ"),OG9Usa51Nk8D,xmTX9Aeidq8cVhY(u"ࠫࠬႲ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬ࠭Ⴓ"),Wbwj0o5gsXQ8F2f(u"࠭ࠧႴ"),VVtQk9vwe7(u"ࠧࠨႵ"),Vt4ELHXZP6(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡌࡔ࡝࡟ࡆ࡚ࡌࡘࡤࡋࡒࡓࡑࡕࡗ࠲࠷ࡳࡵࠩႶ"),tvdQHb10PhNmuy6(u"ࡌࡡ࡭ࡵࡨ᝼"),tvdQHb10PhNmuy6(u"ࡌࡡ࡭ࡵࡨ᝼"))
	TMq6SKsGo5muadx = QBDjIUdSiR.content
	RtqbIgnr5UHo6BFYlhDNJ70Lfe = JJDtX1PZyIgN2T.findall(pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫ࠻࠼ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࡆࡐࡇ࠾࠿ࡋࡎࡅࠩႷ"),TMq6SKsGo5muadx,JJDtX1PZyIgN2T.DOTALL)
	for CD2Lt0rjeEblQYd,OYc2oHf50SIvjC3h,zeMwt5YCUB1HJgdIS,Ef8sUIcr74hCnKu6DbkYvzZ2oGgVt in RtqbIgnr5UHo6BFYlhDNJ70Lfe:
		CD2Lt0rjeEblQYd = CD2Lt0rjeEblQYd.split(DItWNMaLOZ146CubYk8lfAwTy(u"ࠪ࠯ࠬႸ"))
		zeMwt5YCUB1HJgdIS = zeMwt5YCUB1HJgdIS.split(A6Iyo7eXrq2RtMmDxWj(u"ࠫ࠰࠭Ⴙ"))
		Ef8sUIcr74hCnKu6DbkYvzZ2oGgVt = Ef8sUIcr74hCnKu6DbkYvzZ2oGgVt.split(Wbwj0o5gsXQ8F2f(u"ࠬ࠱ࠧႺ"))
		if Ik5bst9OBynwor01jzgCKP in CD2Lt0rjeEblQYd and CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ==OYc2oHf50SIvjC3h and K0dHTfq6P73sD8lWLZpoh in zeMwt5YCUB1HJgdIS and uZbwhWJlKAea610D2Q3iCO8sTjg in Ef8sUIcr74hCnKu6DbkYvzZ2oGgVt:
			VR9om4rMYs5 = pOIe6U1vWYC7Gh2udFBRgT(u"࠭็ัษࠣห้ิืฤ่ࠢ฽ึ๎แ๊ࠡึ๎฾อไอࠢหห้หีะษิࠤฬ๊โศั่ࠫႻ")
			J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭Ⴜ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨะิ์ั࠭Ⴝ"),GVPK9Ziaho6U2ySLj(u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭Ⴞ"),khPUlHDJpORyI9cM6dCjLS+VR9om4rMYs5,JPDT1h3CA7pbI8smEVKHB)
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==u2NDjURZVHlmdc0(u"࠱ᙞ"): ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Wbwj0o5gsXQ8F2f(u"ࠪࡧࡪࡴࡴࡦࡴࠪႿ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠬჀ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠭Ⴡ"),VR9om4rMYs5)
			return
	VR9om4rMYs5 = tvdQHb10PhNmuy6(u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭Ⴢ")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(ebT9xRB63E(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭Ⴣ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬჄ"),khPUlHDJpORyI9cM6dCjLS+VR9om4rMYs5,JPDT1h3CA7pbI8smEVKHB)
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(tvdQHb10PhNmuy6(u"ࠩࡦࡩࡳࡺࡥࡳࠩჅ"),xmTX9Aeidq8cVhY(u"ࠪࠫ჆"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠬჇ"),vdHRKkIgTp56Je1OuNo(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ჈"),tjoHEAGv2XkrMBsVfCyp5U(u"࠭ำ้ใࠣ๎ฯ๋ࠠฦำึห้ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัࠦไไ์ࠣ๎฾ืแࠡษ็้อืๅอࠢฦ๎๋่ࠦๆฬ์ࠤํ้๊โ๋่๊ࠢอะศࠢะู้ะ่ࠠา๊ࠤฬ๊ๅีๅ็อ๊ࠥร็ࠢส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠤฬฺ๊๋สࠣ์้อ๋ࠠีอ฻๏฿ࠠศื็หาࠦๅีๅ็อࠥ๎็้ࠢ็หࠥ๐ูาใࠣ็๏็ู้ࠠิฮࠥ๎ไๆษำหࠥ฾็าฬࠣ์๊ะฺ้๊ࠡีฯࠦ็ั้ࠣห้๋ิไๆฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤำึห้ࠦวๅีฯ่ࠥลࠧ჉"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==oh1JUWa3LdnqTpz5(u"࠲ᙟ"): PAWq9e5lxaE2mp7iXyntVRZo1Js = C0CbfZuXJM(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ჊")
	else:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ჋"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࠪ჌"),oh1JUWa3LdnqTpz5(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭Ⴭ"),GVPK9Ziaho6U2ySLj(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสๆࠢศ่฿อมࠡวิืฬ๊ࠠศๆั฻ศࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ჎"))
		return
	hiDXjZaexOEKBd3U = ov49gJjUZhaA3lLR7Cprz0NBqVsm
	from COH7BKApEP import B4vT1EflKxbA9IaiG8U6Ck0
	llC9WmbrAIgpzfi3n = B4vT1EflKxbA9IaiG8U6Ck0(KylMx0kfTOrG(u"ࠬࡋࡲࡳࡱࡵࡷࠬ჏"),hiDXjZaexOEKBd3U,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡔࡳࡷࡨ᝽"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠧა"),VVtQk9vwe7(u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙ࠧბ"),PAWq9e5lxaE2mp7iXyntVRZo1Js)
	if llC9WmbrAIgpzfi3n and PAWq9e5lxaE2mp7iXyntVRZo1Js:
		jZesU1zPQ2KRFIMV0AvbWlBTu.append(Wfz542FncotmO)
		pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,tvdQHb10PhNmuy6(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫგ"),WfgnOq9Fd4lhMSQpK5(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫდ"),jZesU1zPQ2KRFIMV0AvbWlBTu,iJnLmxA0ykozR98WXFQ4Ye3w)
	return
def m1JdcxjYnS0ZuIUMBF5avt(kOfDHhMnuAxQoBpWTeL):
	if DQfHadYvTpy1UR: kOfDHhMnuAxQoBpWTeL = kOfDHhMnuAxQoBpWTeL.encode(oh1JUWa3LdnqTpz5(u"ࠪࡹࡹ࡬࠸ࠨე"))
	UZqkaAhucSIr6l1ed = C0CbfZuXJM(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫვ")+str(Mrx2OeZV1LNjBsQ58Savi7.time())+oh1JUWa3LdnqTpz5(u"ࠬ࠴ࡤࡢࡶࠪზ")
	open(UZqkaAhucSIr6l1ed,DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡷࡣࠩთ")).write(kOfDHhMnuAxQoBpWTeL)
	return
def nOhiJ5zmHfxwaItpB6XPcA(u5yYiXzKRhjqoG8t):
	if u5yYiXzKRhjqoG8t:
		dnM34UCiobvTqW = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,G5TxeI0ND4ztC6(u"ࠧ࡭࡫ࡶࡸࠬი"),oh1JUWa3LdnqTpz5(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫკ"),Yr0wo7FaSHx(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬლ"))
		if dnM34UCiobvTqW: return dnM34UCiobvTqW
	OG9Usa51Nk8D = LWzUbE5adDslTXGr[Yr0wo7FaSHx(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪმ")][DItWNMaLOZ146CubYk8lfAwTy(u"࠷ᙠ")]
	YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(CC4UDLW6brf(u"࠶࠶ᙡ"),u5yYiXzKRhjqoG8t)
	JFPwNjatzforvbYRhykTIB0GmAl4Hp = ZLG9paBn0bWQd2eTVN1hw8KAq3jDHP()
	QfZp1nrE5iHgVD60I = JFPwNjatzforvbYRhykTIB0GmAl4Hp.split(DItWNMaLOZ146CubYk8lfAwTy(u"ࠫ࠱࠭ნ"))[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᙢ")]
	QW2d59Onpy = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫო"))
	UvpKnXAWLT = dpwXv5HneTbIg0AYCGlQs()
	eeP3Kvuxhao7bJHV = {trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡵࡴࡧࡵࠫპ"):YqywcljIHsFzoXaf0T97,A6Iyo7eXrq2RtMmDxWj(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨჟ"):K0dHTfq6P73sD8lWLZpoh,Yr0wo7FaSHx(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩრ"):QfZp1nrE5iHgVD60I,trSQHvP4aqBWFKxN5bZgXCu(u"ࠩ࡬ࡨࡸ࠭ს"):QaMk1EXgidcunwJhAPRIWTy5lxHrbj(UvpKnXAWLT)}
	QBDjIUdSiR = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡔࡔ࡙ࡔࠨტ"),OG9Usa51Nk8D,eeP3Kvuxhao7bJHV,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࠬუ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠭ფ"),cg94WALw5orUhvtHSfNO(u"࠭ࠧქ"),KylMx0kfTOrG(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡘࡤࡗࡕࡆࡕࡗࡍࡔࡔࡓ࠮࠳ࡶࡸࠬღ"))
	dnM34UCiobvTqW = []
	if QBDjIUdSiR.succeeded:
		TMq6SKsGo5muadx = QBDjIUdSiR.content
		dnM34UCiobvTqW = TMq6SKsGo5muadx.replace(A6Iyo7eXrq2RtMmDxWj(u"ࠨ࡞࡟ࡶࠬყ"),tvdQHb10PhNmuy6(u"ࠩ࡟ࡲࠬშ")).replace(oh1JUWa3LdnqTpz5(u"ࠪࡠࡡࡴࠧჩ"),tvdQHb10PhNmuy6(u"ࠫࡡࡴࠧც")).replace(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡢࡲ࡝ࡰࠪძ"),b46fBrugtPDSYspzMQIx(u"࠭࡜࡯ࠩწ")).replace(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧ࡝ࡴࠪჭ"),KylMx0kfTOrG(u"ࠨ࡞ࡱࠫხ"))
		dnM34UCiobvTqW = JJDtX1PZyIgN2T.findall(vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡖࡘࡆࡘࡔ࠻࠼ࡖࡘࡆࡘࡔ࠻࠼ࠫࡠࡩ࠱ࠩ࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱࡉࡓࡊ࠺࠻ࡇࡑࡈࠬჯ"),dnM34UCiobvTqW,JJDtX1PZyIgN2T.DOTALL)
		if dnM34UCiobvTqW:
			dnM34UCiobvTqW = sorted(dnM34UCiobvTqW,reverse=vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡇࡣ࡯ࡷࡪ᝾"),key=lambda key: int(key[DItWNMaLOZ146CubYk8lfAwTy(u"࠵ᙣ")]))
			iZXua1gCvb9Y5xr,YqywcljIHsFzoXaf0T97,EGaITWmJw64udk7zZq2OAM,cFKVo2vauG0BRnXPmUdSpJCO6,sOu6vWYyjC9VREepAh10cXq,KPW9hQet1aZUu4H2b0lvSi7Rs = dnM34UCiobvTqW[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠶ᙤ")]
			XeaV8tSMHY714iE = KPW9hQet1aZUu4H2b0lvSi7Rs if HRnwFcAJIxaoXEbYQ(ebT9xRB63E(u"ࠪࡑ࡙࠶࠵ࡉ࡚࠳ࡰ࡙࡚ࡅࡇࡐࡖ࡙ࡓ࡬ࡕࡆࡘࡖࡗ࡚࠿ࡅ࡙ࠩჰ")) else EGaITWmJw64udk7zZq2OAM
			BBwb2NzsHE.setSetting(Yr0wo7FaSHx(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ჱ"),XeaV8tSMHY714iE)
			pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨჲ"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩჳ"),dnM34UCiobvTqW,DkRgFyVIBM85OA)
			BBwb2NzsHE.setSetting(cg94WALw5orUhvtHSfNO(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩჴ"),QaMk1EXgidcunwJhAPRIWTy5lxHrbj(uZ7xiFaBvSrWG2mXjITp))
	return dnM34UCiobvTqW
def YEo9xV0vUsPuG2Z(do68fQEmTijJ3P2aHwcr1GsFlN9AI,UYzKI2ZeAaQd=b098bsyjUud(u"࠰ᙥ"),kjRs26714BAZGwFcObztD9fTPXIEdL=b098bsyjUud(u"࠰ᙥ")):
	if UYzKI2ZeAaQd and not kjRs26714BAZGwFcObztD9fTPXIEdL: kjRs26714BAZGwFcObztD9fTPXIEdL = len(do68fQEmTijJ3P2aHwcr1GsFlN9AI)//UYzKI2ZeAaQd
	ob9A5hCJrLgY2HlfB3wOXFt,uvTwHSmjyW6Vr0192IZ,ZDIwmLuV5oA2XMk7pyi1PNgUc3O = [],-vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠲ᙦ"),u2NDjURZVHlmdc0(u"࠲ᙧ")
	for oTCvBQL2ae in do68fQEmTijJ3P2aHwcr1GsFlN9AI:
		if ZDIwmLuV5oA2XMk7pyi1PNgUc3O%kjRs26714BAZGwFcObztD9fTPXIEdL==tjoHEAGv2XkrMBsVfCyp5U(u"࠳ᙨ"):
			uvTwHSmjyW6Vr0192IZ += pOIe6U1vWYC7Gh2udFBRgT(u"࠵ᙩ")
			ob9A5hCJrLgY2HlfB3wOXFt.append([])
		ob9A5hCJrLgY2HlfB3wOXFt[uvTwHSmjyW6Vr0192IZ].append(oTCvBQL2ae)
		ZDIwmLuV5oA2XMk7pyi1PNgUc3O += vlW6K1g8Xo35mPYbyO2GS(u"࠶ᙪ")
	return ob9A5hCJrLgY2HlfB3wOXFt
def WQfLV7y9Scbdh6l(UZqkaAhucSIr6l1ed,kOfDHhMnuAxQoBpWTeL):
	Wv36uZm2MoaSTQC = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,UZqkaAhucSIr6l1ed)
	if cg94WALw5orUhvtHSfNO(u"࠷ᙫ") or VVtQk9vwe7(u"ࠨࡋࡓࡘ࡛ࡥࠧჵ") not in UZqkaAhucSIr6l1ed or uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࡐ࠷࡚ࡥࠧჶ") not in UZqkaAhucSIr6l1ed: JJ23NOKSjik1hg8Ts7CXbevYzrQHU = str(kOfDHhMnuAxQoBpWTeL)
	else:
		ob9A5hCJrLgY2HlfB3wOXFt = YEo9xV0vUsPuG2Z(kOfDHhMnuAxQoBpWTeL,uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸ᙬ"))
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = Wbwj0o5gsXQ8F2f(u"ࠪࠫჷ")
		for xVeCpKH9hXaONM7nTs3GdJR5Et in ob9A5hCJrLgY2HlfB3wOXFt:
			JJ23NOKSjik1hg8Ts7CXbevYzrQHU += str(xVeCpKH9hXaONM7nTs3GdJR5Et)+oh1JUWa3LdnqTpz5(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪჸ")
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.strip(b46fBrugtPDSYspzMQIx(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫჹ"))
	iAr0fUTO4xhWpoS5G2Yv7XP9qFg = rxfk1jENTUA5XvMbG8acWIeCQi9.compress(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	open(Wv36uZm2MoaSTQC,vdHRKkIgTp56Je1OuNo(u"࠭ࡷࡣࠩჺ")).write(iAr0fUTO4xhWpoS5G2Yv7XP9qFg)
	return
def Z0Ot4jfQ71(DuUAOF9Yfv,UZqkaAhucSIr6l1ed):
	if DuUAOF9Yfv==C0CbfZuXJM(u"ࠧࡥ࡫ࡦࡸࠬ჻"): kOfDHhMnuAxQoBpWTeL = {}
	elif DuUAOF9Yfv==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ࡮࡬ࡷࡹ࠭ჼ"): kOfDHhMnuAxQoBpWTeL = []
	elif DuUAOF9Yfv==oh1JUWa3LdnqTpz5(u"ࠩࡶࡸࡷ࠭ჽ"): kOfDHhMnuAxQoBpWTeL = trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࠫჾ")
	elif DuUAOF9Yfv==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫ࡮ࡴࡴࠨჿ"): kOfDHhMnuAxQoBpWTeL = tvdQHb10PhNmuy6(u"࠱᙭")
	else: kOfDHhMnuAxQoBpWTeL = None
	Wv36uZm2MoaSTQC = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,UZqkaAhucSIr6l1ed)
	iAr0fUTO4xhWpoS5G2Yv7XP9qFg = open(Wv36uZm2MoaSTQC,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡸࡢࠨᄀ")).read()
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = rxfk1jENTUA5XvMbG8acWIeCQi9.decompress(iAr0fUTO4xhWpoS5G2Yv7XP9qFg)
	if DItWNMaLOZ146CubYk8lfAwTy(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬᄁ") not in JJ23NOKSjik1hg8Ts7CXbevYzrQHU: kOfDHhMnuAxQoBpWTeL = eval(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	else:
		ob9A5hCJrLgY2HlfB3wOXFt = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.split(b098bsyjUud(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭ᄂ"))
		del JJ23NOKSjik1hg8Ts7CXbevYzrQHU
		kOfDHhMnuAxQoBpWTeL = []
		bgOQkTEy5uF3z60lRMf4rU9xpDaq = aDiNElZCYMU9ptH7oA3d5eu60IOwgj()
		iZXua1gCvb9Y5xr = vlW6K1g8Xo35mPYbyO2GS(u"࠲᙮")
		for xVeCpKH9hXaONM7nTs3GdJR5Et in ob9A5hCJrLgY2HlfB3wOXFt:
			bgOQkTEy5uF3z60lRMf4rU9xpDaq.HuWXO3UhTeKJj0ts2Bga(str(iZXua1gCvb9Y5xr),eval,xVeCpKH9hXaONM7nTs3GdJR5Et)
			iZXua1gCvb9Y5xr += VVtQk9vwe7(u"࠴ᙯ")
		del ob9A5hCJrLgY2HlfB3wOXFt
		bgOQkTEy5uF3z60lRMf4rU9xpDaq.nbvURy7WSEsk()
		bgOQkTEy5uF3z60lRMf4rU9xpDaq.tJpiSGs7n5DuECIRMxT6UF1()
		HgByuFLRioIwMvc = list(bgOQkTEy5uF3z60lRMf4rU9xpDaq.resultsDICT.keys())
		YjbuTo2VLKSMsr = sorted(HgByuFLRioIwMvc,reverse=ebT9xRB63E(u"ࡈࡤࡰࡸ࡫᝿"),key=lambda key: int(key))
		for iZXua1gCvb9Y5xr in YjbuTo2VLKSMsr:
			kOfDHhMnuAxQoBpWTeL += bgOQkTEy5uF3z60lRMf4rU9xpDaq.resultsDICT[iZXua1gCvb9Y5xr]
	return kOfDHhMnuAxQoBpWTeL
def ttf3HyxOnUTKepsI1hR7WiNr8l(f3pCnmFaVYx4zc1MNGBe5):
	iJFCnEZekc = A73K6zLXIgFROeCHJQi0Pbos.path.join(qvy1SuIXLZ2g0P35DUQN6n8G7,trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡣࡧࡨࡴࡴࡳࠨᄃ"),f3pCnmFaVYx4zc1MNGBe5,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡤࡨࡩࡵ࡮࠯ࡺࡰࡰࠬᄄ"))
	try: And9qHxgZO80I7LYviz = open(iJFCnEZekc,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡶࡧ࠭ᄅ")).read()
	except:
		qpOHn79bNeVYW3JLlwCaIAgovd = A73K6zLXIgFROeCHJQi0Pbos.path.join(u5XYGkwyKI40zTtB,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡦࡪࡤࡰࡰࡶࠫᄆ"),f3pCnmFaVYx4zc1MNGBe5,Yr0wo7FaSHx(u"ࠬࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨᄇ"))
		try: And9qHxgZO80I7LYviz = open(qpOHn79bNeVYW3JLlwCaIAgovd,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡲࡣࠩᄈ")).read()
		except: return DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠨᄉ"),[]
	if DQfHadYvTpy1UR: And9qHxgZO80I7LYviz = And9qHxgZO80I7LYviz.decode(cg94WALw5orUhvtHSfNO(u"ࠨࡷࡷࡪ࠽࠭ᄊ"))
	s1DBWVd2KiUbmQM4GO8 = JJDtX1PZyIgN2T.findall(A6Iyo7eXrq2RtMmDxWj(u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭ᄋ"),And9qHxgZO80I7LYviz,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
	if not s1DBWVd2KiUbmQM4GO8: return tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࠫᄌ"),[]
	V1O8TzHomdChkfl9FSpENb6jBcGx3J,k87Czm31pcnHWb9qRVAj = s1DBWVd2KiUbmQM4GO8[tvdQHb10PhNmuy6(u"࠴ᙰ")],gVGcSPqfTBC8Z0u(s1DBWVd2KiUbmQM4GO8[tvdQHb10PhNmuy6(u"࠴ᙰ")])
	return V1O8TzHomdChkfl9FSpENb6jBcGx3J,k87Czm31pcnHWb9qRVAj
def AWVr61C0oZpxaeUj78YDiOnP():
	PIu2Cn40hclgwOx = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,b46fBrugtPDSYspzMQIx(u"ࠫࡩ࡯ࡣࡵࠩᄍ"),KylMx0kfTOrG(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨᄎ"),Wbwj0o5gsXQ8F2f(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧᄏ"))
	if PIu2Cn40hclgwOx: return PIu2Cn40hclgwOx
	ryWxkOZDFuUpzVt9Y7is,PIu2Cn40hclgwOx = {},{}
	MF6q1p9BT4ir = [LWzUbE5adDslTXGr[DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡓࡇࡓࡓࡘ࠭ᄐ")][CC4UDLW6brf(u"࠵ᙱ")]]
	if WWSLAyQdhUXl3ovb>uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠱࠸࠰࠼࠽ᙳ"): MF6q1p9BT4ir.append(LWzUbE5adDslTXGr[pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࡔࡈࡔࡔ࡙ࠧᄑ")][xmTX9Aeidq8cVhY(u"࠷ᙲ")])
	if DQfHadYvTpy1UR: MF6q1p9BT4ir.append(LWzUbE5adDslTXGr[ebT9xRB63E(u"ࠩࡕࡉࡕࡕࡓࠨᄒ")][xmTX9Aeidq8cVhY(u"࠳ᙴ")])
	for aGiXDRQmTgesbCoOq8SdH5y in MF6q1p9BT4ir:
		QBDjIUdSiR = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,GVPK9Ziaho6U2ySLj(u"ࠪࡋࡊ࡚ࠧᄓ"),aGiXDRQmTgesbCoOq8SdH5y,KylMx0kfTOrG(u"ࠫࠬᄔ"),Wbwj0o5gsXQ8F2f(u"ࠬ࠭ᄕ"),ebT9xRB63E(u"࠭ࠧᄖ"),Wbwj0o5gsXQ8F2f(u"ࠧࠨᄗ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉࡆࡊ࡟ࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌ࠮࠳ࡶࡸࠬᄘ"))
		if QBDjIUdSiR.succeeded:
			TMq6SKsGo5muadx = QBDjIUdSiR.content
			JzyX6kvVI82FN9j13cKR4 = aGiXDRQmTgesbCoOq8SdH5y.rsplit(u2NDjURZVHlmdc0(u"ࠩ࠲ࠫᄙ"),CC4UDLW6brf(u"࠳ᙵ"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠳ᙶ")]
			B57O2VvEWlPtoz3Jf1N = JJDtX1PZyIgN2T.findall(cg94WALw5orUhvtHSfNO(u"ࠪ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᄚ"),TMq6SKsGo5muadx,JJDtX1PZyIgN2T.DOTALL|JJDtX1PZyIgN2T.IGNORECASE)
			for f3pCnmFaVYx4zc1MNGBe5,kVm9vlYcXzTZdixUMDAW6KbwE in B57O2VvEWlPtoz3Jf1N:
				m5mzDcUFaMyLsVxiu = JzyX6kvVI82FN9j13cKR4+DItWNMaLOZ146CubYk8lfAwTy(u"ࠫ࠴࠭ᄛ")+f3pCnmFaVYx4zc1MNGBe5+tvdQHb10PhNmuy6(u"ࠬ࠵ࠧᄜ")+f3pCnmFaVYx4zc1MNGBe5+vlW6K1g8Xo35mPYbyO2GS(u"࠭࠭ࠨᄝ")+kVm9vlYcXzTZdixUMDAW6KbwE+G5TxeI0ND4ztC6(u"ࠧ࠯ࡼ࡬ࡴࠬᄞ")
				if f3pCnmFaVYx4zc1MNGBe5 not in list(ryWxkOZDFuUpzVt9Y7is.keys()):
					ryWxkOZDFuUpzVt9Y7is[f3pCnmFaVYx4zc1MNGBe5] = []
					PIu2Cn40hclgwOx[f3pCnmFaVYx4zc1MNGBe5] = []
				S08C9kdwxz = gVGcSPqfTBC8Z0u(kVm9vlYcXzTZdixUMDAW6KbwE)
				ryWxkOZDFuUpzVt9Y7is[f3pCnmFaVYx4zc1MNGBe5].append((kVm9vlYcXzTZdixUMDAW6KbwE,S08C9kdwxz,m5mzDcUFaMyLsVxiu))
	for f3pCnmFaVYx4zc1MNGBe5 in list(ryWxkOZDFuUpzVt9Y7is.keys()):
		PIu2Cn40hclgwOx[f3pCnmFaVYx4zc1MNGBe5] = sorted(ryWxkOZDFuUpzVt9Y7is[f3pCnmFaVYx4zc1MNGBe5],reverse=G5TxeI0ND4ztC6(u"ࡗࡶࡺ࡫ក"),key=lambda key: key[u2NDjURZVHlmdc0(u"࠵ᙷ")])
	pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,CC4UDLW6brf(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫᄟ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪᄠ"),PIu2Cn40hclgwOx,DkRgFyVIBM85OA)
	return PIu2Cn40hclgwOx
def gVGcSPqfTBC8Z0u(kVm9vlYcXzTZdixUMDAW6KbwE):
	S08C9kdwxz = []
	bCHVX9Pz8QU3f4A = kVm9vlYcXzTZdixUMDAW6KbwE.split(tjoHEAGv2XkrMBsVfCyp5U(u"ࠪ࠲ࠬᄡ"))
	for F0an3zOLMK1HVYm in bCHVX9Pz8QU3f4A:
		nn1bcMjfU4m0ytKGsZ9 = JJDtX1PZyIgN2T.findall(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࡡࡪࠫࡽ࡝࡟࠯ࡡ࠳ࡡ࠮ࡼࡄ࠱࡟ࡣࠫࠨᄢ"),F0an3zOLMK1HVYm,JJDtX1PZyIgN2T.DOTALL)
		nwScqRDF17eVErykAJ = []
		for aps9lmWJPf6xMNX0LhuSC75 in nn1bcMjfU4m0ytKGsZ9:
			if aps9lmWJPf6xMNX0LhuSC75.isdigit(): aps9lmWJPf6xMNX0LhuSC75 = int(aps9lmWJPf6xMNX0LhuSC75)
			nwScqRDF17eVErykAJ.append(aps9lmWJPf6xMNX0LhuSC75)
		S08C9kdwxz.append(nwScqRDF17eVErykAJ)
	return S08C9kdwxz
def rQzqAGi0pB91c3PRe(S08C9kdwxz):
	kVm9vlYcXzTZdixUMDAW6KbwE = KylMx0kfTOrG(u"ࠬ࠭ᄣ")
	for F0an3zOLMK1HVYm in S08C9kdwxz:
		for aps9lmWJPf6xMNX0LhuSC75 in F0an3zOLMK1HVYm: kVm9vlYcXzTZdixUMDAW6KbwE += str(aps9lmWJPf6xMNX0LhuSC75)
		kVm9vlYcXzTZdixUMDAW6KbwE += ebT9xRB63E(u"࠭࠮ࠨᄤ")
	kVm9vlYcXzTZdixUMDAW6KbwE = kVm9vlYcXzTZdixUMDAW6KbwE.strip(A6Iyo7eXrq2RtMmDxWj(u"ࠧ࠯ࠩᄥ"))
	return kVm9vlYcXzTZdixUMDAW6KbwE
def AwnlUgaf453N7P20(P9PtAZfLuJNSpM3KR0bzQx512s):
	gFdBaQ9bzKVRS = {}
	ryWxkOZDFuUpzVt9Y7is = AWVr61C0oZpxaeUj78YDiOnP()
	QPUpA7KVc6 = O7WQ68ESFD(P9PtAZfLuJNSpM3KR0bzQx512s)
	for f3pCnmFaVYx4zc1MNGBe5 in P9PtAZfLuJNSpM3KR0bzQx512s:
		if f3pCnmFaVYx4zc1MNGBe5 not in list(ryWxkOZDFuUpzVt9Y7is.keys()): continue
		PIu2Cn40hclgwOx = ryWxkOZDFuUpzVt9Y7is[f3pCnmFaVYx4zc1MNGBe5]
		gGWQzIiOHf7NwqsS,ZSYDsxg4t1QJG7frwiTly,vvFxAOQDrWCUtjbHlg = PIu2Cn40hclgwOx[KylMx0kfTOrG(u"࠵ᙸ")]
		lqMyFS6oN1V2BjGrEUAvxeLtRTgCk,knWHD3LBS2bqEjI9Gt4czTrMU67hC = ttf3HyxOnUTKepsI1hR7WiNr8l(f3pCnmFaVYx4zc1MNGBe5)
		bu2wQtfjG54Z0ToLdIe,NokWRv1KFMgb60XuSTxYZHp = QPUpA7KVc6[f3pCnmFaVYx4zc1MNGBe5]
		Dv4I8g7W9hsESQpRq0JBN = ZSYDsxg4t1QJG7frwiTly>knWHD3LBS2bqEjI9Gt4czTrMU67hC and bu2wQtfjG54Z0ToLdIe
		vuTHKR8XOry1aEF5P7m2WAhLSQU = CC4UDLW6brf(u"ࡘࡷࡻࡥខ")
		if not bu2wQtfjG54Z0ToLdIe: jjf3OBNmukDdn5qLe = b098bsyjUud(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩᄦ")
		elif not NokWRv1KFMgb60XuSTxYZHp: jjf3OBNmukDdn5qLe = VVtQk9vwe7(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᄧ")
		elif Dv4I8g7W9hsESQpRq0JBN: jjf3OBNmukDdn5qLe = trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡳࡱࡪࠧᄨ")
		else:
			jjf3OBNmukDdn5qLe = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫ࡬ࡵ࡯ࡥࠩᄩ")
			vuTHKR8XOry1aEF5P7m2WAhLSQU = trSQHvP4aqBWFKxN5bZgXCu(u"ࡋࡧ࡬ࡴࡧគ")
		gFdBaQ9bzKVRS[f3pCnmFaVYx4zc1MNGBe5] = (vuTHKR8XOry1aEF5P7m2WAhLSQU,lqMyFS6oN1V2BjGrEUAvxeLtRTgCk,knWHD3LBS2bqEjI9Gt4czTrMU67hC,gGWQzIiOHf7NwqsS,ZSYDsxg4t1QJG7frwiTly,jjf3OBNmukDdn5qLe,vvFxAOQDrWCUtjbHlg)
	return gFdBaQ9bzKVRS
def VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,TAHlY28DbLZaRr,oXVsZnk3Pvc=pOIe6U1vWYC7Gh2udFBRgT(u"ࠬ࠭ᄪ"),M8trsjfn2wdaUAPkgYi5mORV7TLSx=jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࠧᄫ"),CD2Lt0rjeEblQYd=vlW6K1g8Xo35mPYbyO2GS(u"ࠧࠨᄬ")):
	if wIqFesTOvYnu5S2dWfpBVC: AL7Kjbmw0qcDit.update(TAHlY28DbLZaRr,oXVsZnk3Pvc,M8trsjfn2wdaUAPkgYi5mORV7TLSx,CD2Lt0rjeEblQYd)
	else: AL7Kjbmw0qcDit.update(TAHlY28DbLZaRr,oXVsZnk3Pvc+KylMx0kfTOrG(u"ࠨ࡞ࡱࠫᄭ")+M8trsjfn2wdaUAPkgYi5mORV7TLSx+VVtQk9vwe7(u"ࠩ࡟ࡲࠬᄮ")+CD2Lt0rjeEblQYd)
	return
def lB1vAJfs6kthziXFgTuNr(yyJB8WmHTEw4OIbcnxf):
	def dU1YkKnM8BouZXwaAxG(leDAQyIGvJ5,RDszKtiMG7mA,eCFiL9MByOGZmKWI=jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥᄯ")):
		return ((leDAQyIGvJ5 == C0CbfZuXJM(u"࠶ᙹ")) and eCFiL9MByOGZmKWI[C0CbfZuXJM(u"࠶ᙹ")]) or (dU1YkKnM8BouZXwaAxG(leDAQyIGvJ5 // RDszKtiMG7mA, RDszKtiMG7mA, eCFiL9MByOGZmKWI).lstrip(eCFiL9MByOGZmKWI[C0CbfZuXJM(u"࠶ᙹ")]) + eCFiL9MByOGZmKWI[leDAQyIGvJ5 % RDszKtiMG7mA])
	def S3vNeLQ2VibI5XYoawWTnHhK0qP(gIREBj6poLYmc, LLmQteRh6ldTEK1D3joZpH5, xdm491qe0X7tGbyMDhaZ5zOioK, PmteKhXcn6SwvJT1bAC89UrW7ZsiNE, JOoTwr0UmHheVWaM5uC=None, akjC78lQFyGbS=None, vEiONes0an=None):
		while (xdm491qe0X7tGbyMDhaZ5zOioK):
			xdm491qe0X7tGbyMDhaZ5zOioK-=CC4UDLW6brf(u"࠱ᙺ")
			if (PmteKhXcn6SwvJT1bAC89UrW7ZsiNE[xdm491qe0X7tGbyMDhaZ5zOioK]): gIREBj6poLYmc = JJDtX1PZyIgN2T.sub(vdHRKkIgTp56Je1OuNo(u"ࠦࡡࡢࡢࠣᄰ") + dU1YkKnM8BouZXwaAxG(xdm491qe0X7tGbyMDhaZ5zOioK, LLmQteRh6ldTEK1D3joZpH5) + Wbwj0o5gsXQ8F2f(u"ࠧࡢ࡜ࡣࠤᄱ"),  PmteKhXcn6SwvJT1bAC89UrW7ZsiNE[xdm491qe0X7tGbyMDhaZ5zOioK], gIREBj6poLYmc)
		return gIREBj6poLYmc
	yyJB8WmHTEw4OIbcnxf = yyJB8WmHTEw4OIbcnxf.split(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡽࠩࠩᄲ"))[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠲ᙻ")]
	yyJB8WmHTEw4OIbcnxf = yyJB8WmHTEw4OIbcnxf.rsplit(vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡴࡲ࡯࡭ࡹ࠭ᄳ"))[ebT9xRB63E(u"࠲ᙼ")]+cg94WALw5orUhvtHSfNO(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨᄴ")
	fDUlrZqcjakT8WpPG3Ku4XBL = eval(b46fBrugtPDSYspzMQIx(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪᄵ")+yyJB8WmHTEw4OIbcnxf,{Wbwj0o5gsXQ8F2f(u"ࠪࡦࡦࡹࡥࡏࠩᄶ"):dU1YkKnM8BouZXwaAxG,trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫᄷ"):S3vNeLQ2VibI5XYoawWTnHhK0qP})
	return fDUlrZqcjakT8WpPG3Ku4XBL
def hno9zEpHtuSidjykYNBKerwv1OC(OG9Usa51Nk8D,RTLMC9N18WFkhcVb3AZ7p=vdHRKkIgTp56Je1OuNo(u"ࠬ࠭ᄸ")):
	if RTLMC9N18WFkhcVb3AZ7p==CC4UDLW6brf(u"࠭࡬ࡰࡹࡨࡶࠬᄹ"): OG9Usa51Nk8D = JJDtX1PZyIgN2T.sub(b46fBrugtPDSYspzMQIx(u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃࠧᄺ"),lambda eenWxbhGTLSqp491JN0CZ8Poc: eenWxbhGTLSqp491JN0CZ8Poc.group(u2NDjURZVHlmdc0(u"࠳ᙽ")).lower(),OG9Usa51Nk8D)
	elif RTLMC9N18WFkhcVb3AZ7p==b46fBrugtPDSYspzMQIx(u"ࠨࡷࡳࡴࡪࡸࠧᄻ"): OG9Usa51Nk8D = JJDtX1PZyIgN2T.sub(CC4UDLW6brf(u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾࠩᄼ"),lambda eenWxbhGTLSqp491JN0CZ8Poc: eenWxbhGTLSqp491JN0CZ8Poc.group(b098bsyjUud(u"࠴ᙾ")).upper(),OG9Usa51Nk8D)
	return OG9Usa51Nk8D
def O7WQ68ESFD(P9PtAZfLuJNSpM3KR0bzQx512s):
	rrVhqP39ZU,nTzi5swlxKRWZu860cpVjkAMXFabB = Vt4ELHXZP6(u"ࡌࡡ࡭ࡵࡨឃ"),Vt4ELHXZP6(u"ࡌࡡ࡭ࡵࡨឃ")
	LxomZnH9Ky = gxoYzqsnPQ.connect(pWKgVeBs5DjUcyv47PE0or2)
	LxomZnH9Ky.text_factory = str
	ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
	if len(P9PtAZfLuJNSpM3KR0bzQx512s)==trSQHvP4aqBWFKxN5bZgXCu(u"࠶ᙿ"): W0b4IuLP1BVYQf2mAiTvp5OEZCeG = Yr0wo7FaSHx(u"ࠪࠬࠧ࠭ᄽ")+P9PtAZfLuJNSpM3KR0bzQx512s[Wbwj0o5gsXQ8F2f(u"࠶ ")]+WfgnOq9Fd4lhMSQpK5(u"ࠫࠧ࠯ࠧᄾ")
	else: W0b4IuLP1BVYQf2mAiTvp5OEZCeG = str(tuple(P9PtAZfLuJNSpM3KR0bzQx512s))
	ooRPprGBD89QXusn.execute(WfgnOq9Fd4lhMSQpK5(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬᄿ")+W0b4IuLP1BVYQf2mAiTvp5OEZCeG+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࠠ࠼ࠩᅀ"))
	Z2ARJehHkjndvF = ooRPprGBD89QXusn.fetchall()
	QPUpA7KVc6 = {}
	for f3pCnmFaVYx4zc1MNGBe5 in P9PtAZfLuJNSpM3KR0bzQx512s: QPUpA7KVc6[f3pCnmFaVYx4zc1MNGBe5] = (Vt4ELHXZP6(u"ࡆࡢ࡮ࡶࡩង"),Vt4ELHXZP6(u"ࡆࡢ࡮ࡶࡩង"))
	for f3pCnmFaVYx4zc1MNGBe5,nTzi5swlxKRWZu860cpVjkAMXFabB in Z2ARJehHkjndvF:
		rrVhqP39ZU = vdHRKkIgTp56Je1OuNo(u"ࡕࡴࡸࡩច")
		nTzi5swlxKRWZu860cpVjkAMXFabB = nTzi5swlxKRWZu860cpVjkAMXFabB==cg94WALw5orUhvtHSfNO(u"࠱ᚁ")
		QPUpA7KVc6[f3pCnmFaVYx4zc1MNGBe5] = (rrVhqP39ZU,nTzi5swlxKRWZu860cpVjkAMXFabB)
	LxomZnH9Ky.close()
	return QPUpA7KVc6
def qqlgo4zmvG7sYR(wErcn0kLyWxu6JG):
	mL7BVKcSygkuoPbWlEF4YD = C0CbfZuXJM(u"ࠧࠨᅁ")
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(wErcn0kLyWxu6JG):
		rxqXYiSVaLWp3e1yQncJ57 = open(wErcn0kLyWxu6JG,tvdQHb10PhNmuy6(u"ࠨࡴࡥࠫᅂ")).read()
		if DQfHadYvTpy1UR: rxqXYiSVaLWp3e1yQncJ57 = rxqXYiSVaLWp3e1yQncJ57.decode(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡸࡸ࡫࠾ࠧᅃ"))
		ohwepsEbTvfBLxHAt = G8EwoDOyKShm1i0IHMfNYZlU7(G5TxeI0ND4ztC6(u"ࠪࡨ࡮ࡩࡴࠨᅄ"),rxqXYiSVaLWp3e1yQncJ57)
		if ohwepsEbTvfBLxHAt:
			mL7BVKcSygkuoPbWlEF4YD = {}
			for oQmOMcBwDGK69ylqSN2z in ohwepsEbTvfBLxHAt.keys():
				mL7BVKcSygkuoPbWlEF4YD[oQmOMcBwDGK69ylqSN2z] = []
				for xxwmOAdKygD9tLC in ohwepsEbTvfBLxHAt[oQmOMcBwDGK69ylqSN2z]:
					ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࠬᅅ"),CC4UDLW6brf(u"ࠬ࠭ᅆ"),Wbwj0o5gsXQ8F2f(u"࠭ࠧᅇ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࠨᅈ"),GVPK9Ziaho6U2ySLj(u"ࠨࠩᅉ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࠪᅊ"),oh1JUWa3LdnqTpz5(u"ࠪࠫᅋ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠬᅌ"),KylMx0kfTOrG(u"ࠬ࠭ᅍ")
					ajLz9PfYbTigyorvZhW4IOFn = xxwmOAdKygD9tLC[G5TxeI0ND4ztC6(u"࠱ᚂ")]
					q9fpxUJbiKc6us4 = xxwmOAdKygD9tLC[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠳ᚃ")]
					q9fpxUJbiKc6us4 = DDWps8j5MkOtw4JXG2nxVrE7g(q9fpxUJbiKc6us4)
					OG9Usa51Nk8D = xxwmOAdKygD9tLC[tvdQHb10PhNmuy6(u"࠵ᚄ")]
					rCBzYkXesGinqfjWdMJ0I6EuthRAg1 = xxwmOAdKygD9tLC[KylMx0kfTOrG(u"࠷ᚅ")]
					UCjpzQwrZyNIe3kg1ThDvi0nb8 = xxwmOAdKygD9tLC[Wbwj0o5gsXQ8F2f(u"࠹ᚆ")]
					vYpMA3CxgcyR4VZJh = xxwmOAdKygD9tLC[xmTX9Aeidq8cVhY(u"࠻ᚇ")]
					if len(xxwmOAdKygD9tLC)>pOIe6U1vWYC7Gh2udFBRgT(u"࠶ᚈ"): JJ23NOKSjik1hg8Ts7CXbevYzrQHU = xxwmOAdKygD9tLC[pOIe6U1vWYC7Gh2udFBRgT(u"࠶ᚈ")]
					if len(xxwmOAdKygD9tLC)>uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸ᚉ"): neEs3K9mgi7CJhaODRATXrqo = xxwmOAdKygD9tLC[uEed4OSxm7hBq9Vvky6QjHwWC(u"࠸ᚉ")]
					if len(xxwmOAdKygD9tLC)>tvdQHb10PhNmuy6(u"࠺ᚊ"): WFJYy6c9CKV4rdh27NjtILZ5HgRv = xxwmOAdKygD9tLC[tvdQHb10PhNmuy6(u"࠺ᚊ")]
					if wErcn0kLyWxu6JG==KoULXHCRWtulrsM1cP: G08Ugxo2ftul = ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,CC4UDLW6brf(u"࠭ࠧᅎ"),WFJYy6c9CKV4rdh27NjtILZ5HgRv
					else: G08Ugxo2ftul = ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv
					mL7BVKcSygkuoPbWlEF4YD[oQmOMcBwDGK69ylqSN2z].append(G08Ugxo2ftul)
		SMDOwX1AKRdFoupI0Q4ei = str(mL7BVKcSygkuoPbWlEF4YD)
		if DQfHadYvTpy1UR: SMDOwX1AKRdFoupI0Q4ei = SMDOwX1AKRdFoupI0Q4ei.encode(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡶࡶࡩ࠼ࠬᅏ"))
		open(wErcn0kLyWxu6JG,vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡹࡥࠫᅐ")).write(SMDOwX1AKRdFoupI0Q4ei)
	return mL7BVKcSygkuoPbWlEF4YD
def DDE8bFYNye7xkqHoVvzXOSg1l0d6(HLAhjNIVMFonqi5zg2aQlpyfRKBrm):
	vfIgDlJ8iPe3cZR20V4pkY = HLAhjNIVMFonqi5zg2aQlpyfRKBrm.split(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ࠰ࠫᅑ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠴ᚋ"))[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠴ᚌ")]
	UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b = WfgnOq9Fd4lhMSQpK5(u"ࠪࠫᅒ"),tvdQHb10PhNmuy6(u"ࠫࠬᅓ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬ࠭ᅔ")
	if   vfIgDlJ8iPe3cZR20V4pkY==b46fBrugtPDSYspzMQIx(u"࠭ࡁࡉ࡙ࡄࡏࠬᅕ")		:	from JD5mnp3oqj			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡂࡍࡒࡅࡒ࠭ᅖ")		:	from SN6YMRIvqW			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪᅗ")	:	from Ir6zUqvsmE		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡄࡏ࡜ࡇࡍࠨᅘ")		:	from MoLGRCrH0B			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡅࡑࡇࡒࡂࡄࠪᅙ")	:	from AAwCF26QUM			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==G5TxeI0ND4ztC6(u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭ᅚ")	:	from xdPlLt2Wyu		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==oh1JUWa3LdnqTpz5(u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨᅛ")	: 	from oosSm6jxUA		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==CC4UDLW6brf(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨᅜ")	:	from kMKnEbC9He		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==tvdQHb10PhNmuy6(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬᅝ"):	from BcR8wVCXW1	import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪᅞ")	:	from llrz36PXkA		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==cg94WALw5orUhvtHSfNO(u"ࠩࡅࡓࡐࡘࡁࠨᅟ")		:	from sQDa3t4wub			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==GVPK9Ziaho6U2ySLj(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪᅠ")	:	from Dx9UnVW5oN			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==G5TxeI0ND4ztC6(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬᅡ")	:	from MiCT6ZOEzs		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==ebT9xRB63E(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬᅢ")	:	from UxFtyevGjX			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==b46fBrugtPDSYspzMQIx(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᅣ")	:	from cKzHS2f0kC		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ᅤ"):	from xJzWy2Va0b	import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪᅥ"):		from koJGyjUzmZ		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==A6Iyo7eXrq2RtMmDxWj(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫᅦ")	:	from dRoJIpX768		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==u2NDjURZVHlmdc0(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬᅧ")	:	from nc1wLfCoJm		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==Vt4ELHXZP6(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᅨ")	:	from DWkFCLHpqe		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==A6Iyo7eXrq2RtMmDxWj(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᅩ")	:	from A3OWx6KM4Z		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==KylMx0kfTOrG(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫᅪ"):	from TISnj9iuNy	import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨᅫ")	:	from kJpKT16hwG		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩᅬ")	:	from XMwnvWaRz8		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==C0CbfZuXJM(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫᅭ")	:	from EVQ2mzC1PH		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==Wbwj0o5gsXQ8F2f(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬᅮ")	:	from pKfXcLRsYQ		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭ᅯ")	:	from xxTl5gOPoU		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==b098bsyjUud(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧᅰ")	:	from ys3WRBKjgv		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vdHRKkIgTp56Je1OuNo(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧᅱ")	:	from L8QxOYXrZV		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==CC4UDLW6brf(u"ࠧࡆࡉ࡜ࡒࡔ࡝ࠧᅲ")	:	from sNgmYqG68o			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩᅳ")	:	from Moswlz0SZm		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬᅴ")	:	from hcqNB7oPQX		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᅵ")	:	from qqpYambklH		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==G5TxeI0ND4ztC6(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ᅶ")	:	from sW4IAwPJKt		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==xmTX9Aeidq8cVhY(u"ࠬࡌࡏࡔࡖࡄࠫᅷ")		:	from R0doJiwWQS			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==A6Iyo7eXrq2RtMmDxWj(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨᅸ")	:	from Sk7lb5PuGq		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡊࡈࡌࡐࡒ࠭ᅹ")		:	from eaNkRwx1yn			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==CC4UDLW6brf(u"ࠨࡋࡓࡘ࡛࠭ᅺ")		:	from Nipbs3ZV5T	import iG6vTHmb5KUCaWqrjz as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,OXTVJbg9envrs as y9topEPuNCwYTgB,t8SVWInB3P7 as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==Yr0wo7FaSHx(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬᅻ")	:	from ZHmMw1VgJL		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬᅼ")	:	from wg6h2LsVex		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==tvdQHb10PhNmuy6(u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭ᅽ")	:	from MKh7iAVYLX		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==cg94WALw5orUhvtHSfNO(u"ࠬࡒࡁࡓࡑ࡝ࡅࠬᅾ")	:	from EdGqrsc8W6			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==KylMx0kfTOrG(u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧᅿ")	:	from vvdISQL4Rr		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==u2NDjURZVHlmdc0(u"ࠧࡎ࠵ࡘࠫᆀ")		:	from aCyfkwjhpQ	import iG6vTHmb5KUCaWqrjz as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,OXTVJbg9envrs as y9topEPuNCwYTgB,t8SVWInB3P7 as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==G5TxeI0ND4ztC6(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨᆁ")	:	from EOWJUYxVkQ			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vdHRKkIgTp56Je1OuNo(u"ࠩࡐ࡝ࡈࡏࡍࡂࠩᆂ")	:	from iiz6XasOgk			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==b46fBrugtPDSYspzMQIx(u"ࠪࡔࡆࡔࡅࡕࠩᆃ")		:	from yL5TAd0MKu			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==b46fBrugtPDSYspzMQIx(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ᆄ")	:	from uufmkNnLt8		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩᆅ"):	from ujPHJy61Fa		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==oh1JUWa3LdnqTpz5(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩᆆ")	:	from EN0lw9rZWi		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==Wbwj0o5gsXQ8F2f(u"ࠧࡔࡊࡒࡊࡍࡇࠧᆇ")	:	from cdm9Ne6MRP			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vdHRKkIgTp56Je1OuNo(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪᆈ")	:	from keuctiXzqO		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==C0CbfZuXJM(u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫᆉ")	:	from KGuyljzBC9		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡘ࡛ࡌࡕࡏࠩᆊ")		:	from DiCgabltxU			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==C0CbfZuXJM(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫᆋ")	:	from OOlZvwMeN2			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==WfgnOq9Fd4lhMSQpK5(u"ࠬ࡟ࡁࡒࡑࡗࠫᆌ")		:	from FC20VcwO6f			import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==GVPK9Ziaho6U2ySLj(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧᆍ")	:	from Z5aTos0RvJ		import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy,VH5hnQa7CPSR1tMlZ03Wpx8 as y9topEPuNCwYTgB,eMlwAzaLSj8ZEQ3txIGP as C42Qhj1WDOvPy9b
	elif vfIgDlJ8iPe3cZR20V4pkY==tjoHEAGv2XkrMBsVfCyp5U(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ᆎ"):	from mmpfc3Zqus	import UQ8xVqP243HvaWOMtJSp as UIXxutP306wVQaejNrmAgJ5Dsk4zLy
	return UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b
def jFfs5J7diIt68yb9mBSZ(iiBHOKqMl5Cdo1sb0N7yx,QOZAYj8g6yaqhl,showDialogs):
	b6kj4LJ5tzTeOMQi(vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡐࡒࡘࡎࡉࡅࠨᆏ"),xmTX9Aeidq8cVhY(u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࠽ࠤࡠࠦࠧᆐ")+iiBHOKqMl5Cdo1sb0N7yx+oh1JUWa3LdnqTpz5(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ᆑ")+str(QOZAYj8g6yaqhl)+WfgnOq9Fd4lhMSQpK5(u"ࠫࠥࡣࠧᆒ"))
	AL7Kjbmw0qcDit = W2mNFlgkhXS8KIQ0GcTt()
	AL7Kjbmw0qcDit.create(trSQHvP4aqBWFKxN5bZgXCu(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᆓ"),G5TxeI0ND4ztC6(u"๊࠭อำํࠤฬ๊ย็ࠢไัฺࠦวๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์่ࠦษ฻า๋ฬࠦำ้ใࠣฮอีรࠡ฻่่๏ฯࠠอๆหࠤฬ๊ๅๅใ้๋ࠣࠦวๅว้ฮึ์สࠨᆔ"))
	rcHgiYv9QXRJtCaPKFn4zoU2G5N = A6Iyo7eXrq2RtMmDxWj(u"࠶࠶࠲࠵ᚍ")*A6Iyo7eXrq2RtMmDxWj(u"࠶࠶࠲࠵ᚍ")
	ZhPXuqVvmpTy57UYo0r8cC9Ei1l = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠷ᚎ")*rcHgiYv9QXRJtCaPKFn4zoU2G5N
	QBDjIUdSiR = yUt4fqQpnL0AZ.get(iiBHOKqMl5Cdo1sb0N7yx,stream=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡖࡵࡹࡪឆ"),headers=QOZAYj8g6yaqhl)
	uHawqb3GQ4cBULEernFyjmZWgJ = QBDjIUdSiR.headers
	QBDjIUdSiR.close()
	WyiMT4EtSljO9Agk = bytes()
	if not uHawqb3GQ4cBULEernFyjmZWgJ:
		if showDialogs: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(oh1JUWa3LdnqTpz5(u"ࠧࠨᆕ"),C0CbfZuXJM(u"ࠨࠩᆖ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᆗ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭ᆘ"))
		AL7Kjbmw0qcDit.close()
	else:
		if Wbwj0o5gsXQ8F2f(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬᆙ") not in list(uHawqb3GQ4cBULEernFyjmZWgJ.keys()): Cs5Rl2PGvMF6BmAI3 = vlW6K1g8Xo35mPYbyO2GS(u"࠰ᚏ")
		else: Cs5Rl2PGvMF6BmAI3 = int(uHawqb3GQ4cBULEernFyjmZWgJ[VVtQk9vwe7(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᆚ")])
		n41U7rLeMmPTAWgOiFdxpf2ZY0 = str(int(A6Iyo7eXrq2RtMmDxWj(u"࠳࠳࠴࠵ᚑ")*Cs5Rl2PGvMF6BmAI3/rcHgiYv9QXRJtCaPKFn4zoU2G5N)/tjoHEAGv2XkrMBsVfCyp5U(u"࠲࠲࠳࠴࠳࠶ᚐ"))
		QhSrbEBW4sunlaGgRTty0cqZ = int(Cs5Rl2PGvMF6BmAI3/ZhPXuqVvmpTy57UYo0r8cC9Ei1l)+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠴ᚒ")
		if vdHRKkIgTp56Je1OuNo(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭ᆛ") in list(uHawqb3GQ4cBULEernFyjmZWgJ.keys()) and Cs5Rl2PGvMF6BmAI3>rcHgiYv9QXRJtCaPKFn4zoU2G5N:
			IEPnCGqNSH2LRKXchviO = C0CbfZuXJM(u"ࡗࡶࡺ࡫ជ")
			ZfysRlmiwb2h0TrQ3DPd = []
			C2CMjzVidkXT = DItWNMaLOZ146CubYk8lfAwTy(u"࠵࠵ᚓ")
			ZfysRlmiwb2h0TrQ3DPd.append(str(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠶ᚕ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+vlW6K1g8Xo35mPYbyO2GS(u"ࠧ࠮ࠩᆜ")+str(b46fBrugtPDSYspzMQIx(u"࠶ᚔ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-b46fBrugtPDSYspzMQIx(u"࠶ᚔ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠱ᚖ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+WfgnOq9Fd4lhMSQpK5(u"ࠨ࠯ࠪᆝ")+str(VVtQk9vwe7(u"࠳ᚗ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-uEed4OSxm7hBq9Vvky6QjHwWC(u"࠱ᚖ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶ᚚ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+Vt4ELHXZP6(u"ࠩ࠰ࠫᆞ")+str(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠶ᚙ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-CC4UDLW6brf(u"࠳ᚘ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(VVtQk9vwe7(u"࠹᚜")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+Yr0wo7FaSHx(u"ࠪ࠱ࠬᆟ")+str(Yr0wo7FaSHx(u"࠴᚝")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-ebT9xRB63E(u"࠶᚛")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠷ᚠ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+CC4UDLW6brf(u"ࠫ࠲࠭ᆠ")+str(b46fBrugtPDSYspzMQIx(u"࠷᚟")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-Wbwj0o5gsXQ8F2f(u"࠲᚞")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(b46fBrugtPDSYspzMQIx(u"࠺ᚢ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+b098bsyjUud(u"ࠬ࠳ࠧᆡ")+str(Yr0wo7FaSHx(u"࠼ᚣ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-Wbwj0o5gsXQ8F2f(u"࠵ᚡ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(DItWNMaLOZ146CubYk8lfAwTy(u"࠸ᚦ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭࠭ࠨᆢ")+str(C0CbfZuXJM(u"࠸ᚥ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠱ᚤ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(tvdQHb10PhNmuy6(u"࠼ᚩ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+ebT9xRB63E(u"ࠧ࠮ࠩᆣ")+str(CC4UDLW6brf(u"࠼ᚨ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-WfgnOq9Fd4lhMSQpK5(u"࠴ᚧ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠸ᚫ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+KylMx0kfTOrG(u"ࠨ࠯ࠪᆤ")+str(CC4UDLW6brf(u"࠿ᚪ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT-mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠲ᚬ")))
			ZfysRlmiwb2h0TrQ3DPd.append(str(CC4UDLW6brf(u"࠻ᚭ")*Cs5Rl2PGvMF6BmAI3//C2CMjzVidkXT)+A6Iyo7eXrq2RtMmDxWj(u"ࠩ࠰ࠫᆥ"))
			BiCcwvtQgkREDl9TMJ = float(QhSrbEBW4sunlaGgRTty0cqZ)/C2CMjzVidkXT
			ViYvtS6UMpGRnrWyxf0oN3lswzE = BiCcwvtQgkREDl9TMJ/int(vdHRKkIgTp56Je1OuNo(u"࠴ᚮ")+BiCcwvtQgkREDl9TMJ)
		else:
			IEPnCGqNSH2LRKXchviO = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡊࡦࡲࡳࡦឈ")
			C2CMjzVidkXT = CC4UDLW6brf(u"࠵ᚯ")
			ViYvtS6UMpGRnrWyxf0oN3lswzE = VVtQk9vwe7(u"࠶ᚰ")
		b6kj4LJ5tzTeOMQi(vdHRKkIgTp56Je1OuNo(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᆦ"),u2NDjURZVHlmdc0(u"ࠫ࠳ࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡴࡤࡲ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬᆧ")+str(IEPnCGqNSH2LRKXchviO)+b098bsyjUud(u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧᆨ")+str(Cs5Rl2PGvMF6BmAI3)+trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠠ࡞ࠩᆩ"))
		uvTwHSmjyW6Vr0192IZ,LT1IdqufjR8ms = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᚱ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠶ᚱ")
		for ZDIwmLuV5oA2XMk7pyi1PNgUc3O in range(C2CMjzVidkXT):
			JZP07kjvbV = QOZAYj8g6yaqhl.copy()
			if IEPnCGqNSH2LRKXchviO: JZP07kjvbV[oh1JUWa3LdnqTpz5(u"ࠧࡓࡣࡱ࡫ࡪ࠭ᆪ")] = b46fBrugtPDSYspzMQIx(u"ࠨࡤࡼࡸࡪࡹ࠽ࠨᆫ")+ZfysRlmiwb2h0TrQ3DPd[ZDIwmLuV5oA2XMk7pyi1PNgUc3O]
			QBDjIUdSiR = yUt4fqQpnL0AZ.get(iiBHOKqMl5Cdo1sb0N7yx,stream=cg94WALw5orUhvtHSfNO(u"࡙ࡸࡵࡦញ"),headers=JZP07kjvbV,timeout=Yr0wo7FaSHx(u"࠳࠱࠲ᚲ"))
			for pykoOBI9j0rhDw6 in QBDjIUdSiR.iter_content(chunk_size=ZhPXuqVvmpTy57UYo0r8cC9Ei1l):
				if AL7Kjbmw0qcDit.iscanceled():
					b6kj4LJ5tzTeOMQi(KylMx0kfTOrG(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᆬ"),WfgnOq9Fd4lhMSQpK5(u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠪᆭ"))
					break
				uvTwHSmjyW6Vr0192IZ += ViYvtS6UMpGRnrWyxf0oN3lswzE
				WyiMT4EtSljO9Agk += pykoOBI9j0rhDw6
				if not LT1IdqufjR8ms: LT1IdqufjR8ms = len(pykoOBI9j0rhDw6)
				if Cs5Rl2PGvMF6BmAI3: VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,oh1JUWa3LdnqTpz5(u"࠲࠲࠳ᚳ")*uvTwHSmjyW6Vr0192IZ//QhSrbEBW4sunlaGgRTty0cqZ,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬᆮ"),str(oh1JUWa3LdnqTpz5(u"࠳࠳࠴࠳࠶ᚴ")*LT1IdqufjR8ms*uvTwHSmjyW6Vr0192IZ//ZhPXuqVvmpTy57UYo0r8cC9Ei1l//oh1JUWa3LdnqTpz5(u"࠳࠳࠴࠳࠶ᚴ"))+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࠦ࠯ࠡࠩᆯ")+n41U7rLeMmPTAWgOiFdxpf2ZY0+WfgnOq9Fd4lhMSQpK5(u"࠭ࠠࡎࡄࠪᆰ"))
				else: VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,LT1IdqufjR8ms*uvTwHSmjyW6Vr0192IZ//ZhPXuqVvmpTy57UYo0r8cC9Ei1l,vdHRKkIgTp56Je1OuNo(u"ࠧอๆหࠤฬ๊ๅๅใ࠽࠱ࠬᆱ"),str(VVtQk9vwe7(u"࠴࠴࠵࠴࠰ᚵ")*LT1IdqufjR8ms*uvTwHSmjyW6Vr0192IZ//ZhPXuqVvmpTy57UYo0r8cC9Ei1l//VVtQk9vwe7(u"࠴࠴࠵࠴࠰ᚵ"))+KylMx0kfTOrG(u"ࠨࠢࡐࡆࠬᆲ"))
			QBDjIUdSiR.close()
		AL7Kjbmw0qcDit.close()
		if len(WyiMT4EtSljO9Agk)<Cs5Rl2PGvMF6BmAI3 and Cs5Rl2PGvMF6BmAI3>VVtQk9vwe7(u"࠴ᚶ"):
			b6kj4LJ5tzTeOMQi(C0CbfZuXJM(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᆳ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭ᆴ")+str(len(WyiMT4EtSljO9Agk)//rcHgiYv9QXRJtCaPKFn4zoU2G5N)+Vt4ELHXZP6(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩᆵ")+n41U7rLeMmPTAWgOiFdxpf2ZY0+b46fBrugtPDSYspzMQIx(u"ࠬࠦࡍࡃࠢࡠࠫᆶ"))
			WnbmLQXcr7JdDtRyEe = VYEiZteQcrT7aqOBMRAyHC9(Wbwj0o5gsXQ8F2f(u"࠭ࠧᆷ"),G5TxeI0ND4ztC6(u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬᆸ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨᆹ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫᆺ"),Wbwj0o5gsXQ8F2f(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᆻ"),cg94WALw5orUhvtHSfNO(u"ࠫๆฺไࠡใํࠤั๊ศࠡษ็้้็ࠠ࡝ࡰ่้ࠣษำโࠢะำะࠦฮุลࠣๅ๏ࠦสฮ็ํ่ࠥอไๆๆไࠤࡡࡴࠠห็ࠣะ้ฮࠠࠨᆼ")+str(len(WyiMT4EtSljO9Agk)//rcHgiYv9QXRJtCaPKFn4zoU2G5N)+CC4UDLW6brf(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ็้ࠤ๊าๅ้฻ࠣࠫᆽ")+n41U7rLeMmPTAWgOiFdxpf2ZY0+VVtQk9vwe7(u"࠭ࠠๆ์฽หออ๊หࠢ࡟ࡲࠥาัษࠢฯ่อࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠠ࡝ࡰ๋้ࠣࠦสา์าࠤฬูสฯัส้ࠥอไๆๆไࠤฬ๊ๆศไุࠤฤࠧࠡࠨᆾ"))
			if WnbmLQXcr7JdDtRyEe==b46fBrugtPDSYspzMQIx(u"࠷ᚷ"): WyiMT4EtSljO9Agk = jFfs5J7diIt68yb9mBSZ(iiBHOKqMl5Cdo1sb0N7yx,QOZAYj8g6yaqhl,showDialogs)
			elif WnbmLQXcr7JdDtRyEe==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠷ᚸ"): b6kj4LJ5tzTeOMQi(ebT9xRB63E(u"ࠧࡏࡑࡗࡍࡈࡋࠧᆿ"),GVPK9Ziaho6U2ySLj(u"ࠨ࠰ࠣࠤࡓࡵࡴࠡࡥࡲࡱࡵࡲࡥࡵࡧࡧࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡤࡧࡨ࡫ࡰࡵࡧࡧࠤࡦࡴࡤࠡࡹ࡬ࡰࡱࠦࡢࡦࠢࡸࡷࡪࡪࠧᇀ"))
			else: return vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࠪᇁ")
			if not WyiMT4EtSljO9Agk: return DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫᇂ")
		else: b6kj4LJ5tzTeOMQi(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡓࡕࡔࡊࡅࡈࠫᇃ"),u2NDjURZVHlmdc0(u"ࠬ࠴ࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩᇄ")+n41U7rLeMmPTAWgOiFdxpf2ZY0+b46fBrugtPDSYspzMQIx(u"࠭ࠠࡎࡄࠣࡡࠬᇅ"))
	return WyiMT4EtSljO9Agk
def TDsHnvIWl8Y1MGwyQtfV(FpjtBKrnu5SdfyOvEPIQ):
	return QBDjIUdSiR
def ZLG9paBn0bWQd2eTVN1hw8KAq3jDHP(ip=YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠨᇆ")):
	XXNufTcVeUDS3GpJaQ,QfZp1nrE5iHgVD60I,qXLnZmtUDaoyEGK9QS4sPhcJ,hVPGrYoAys0,R0YEe4uvyLMgxjJ3P9XW5kslGrf,gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x = GVPK9Ziaho6U2ySLj(u"ࠨࠩᇇ"),VVtQk9vwe7(u"ࠩࠪᇈ"),Yr0wo7FaSHx(u"ࠪࠫᇉ"),Wbwj0o5gsXQ8F2f(u"ࠫࠬᇊ"),Vt4ELHXZP6(u"ࠬ࠭ᇋ"),oh1JUWa3LdnqTpz5(u"࠭ࠧᇌ")
	OG9Usa51Nk8D = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࠴ࡩࡴ࠱ࠪᇍ")+ip+KylMx0kfTOrG(u"ࠨࡁࡲࡹࡹࡶࡵࡵ࠿࡭ࡷࡴࡴࠦࡧ࡫ࡨࡰࡩࡹ࠽ࡪࡲ࠯ࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ᇎ")
	QOZAYj8g6yaqhl = {GVPK9Ziaho6U2ySLj(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᇏ"):cg94WALw5orUhvtHSfNO(u"ࠪࠫᇐ")}
	QBDjIUdSiR = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,Yr0wo7FaSHx(u"ࠫࡌࡋࡔࠨᇑ"),OG9Usa51Nk8D,Wbwj0o5gsXQ8F2f(u"ࠬ࠭ᇒ"),QOZAYj8g6yaqhl,VVtQk9vwe7(u"࠭ࠧᇓ"),KylMx0kfTOrG(u"ࠧࠨᇔ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫᇕ"))
	if not QBDjIUdSiR.succeeded: JFPwNjatzforvbYRhykTIB0GmAl4Hp = ip+Wbwj0o5gsXQ8F2f(u"ࠩ࠯ࠫᇖ")+XXNufTcVeUDS3GpJaQ+xmTX9Aeidq8cVhY(u"ࠪ࠰ࠬᇗ")+QfZp1nrE5iHgVD60I+KylMx0kfTOrG(u"ࠫ࠱࠭ᇘ")+hVPGrYoAys0+GVPK9Ziaho6U2ySLj(u"ࠬ࠲ࠧᇙ")+R0YEe4uvyLMgxjJ3P9XW5kslGrf+VVtQk9vwe7(u"࠭ࠬࠨᇚ")+gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x
	else:
		TMq6SKsGo5muadx = QBDjIUdSiR.content
		TMq6SKsGo5muadx = JJDtX1PZyIgN2T.findall(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧ࡝ࡽ࠱࠮ࡄࡢࡽ࡝ࡿࠪᇛ"),TMq6SKsGo5muadx,JJDtX1PZyIgN2T.DOTALL)
		if TMq6SKsGo5muadx:
			TMq6SKsGo5muadx = TMq6SKsGo5muadx[oh1JUWa3LdnqTpz5(u"࠰ᚹ")]
			MgZJ9DxzBqPXYtk6TaN2 = G8EwoDOyKShm1i0IHMfNYZlU7(KylMx0kfTOrG(u"ࠨࡦ࡬ࡧࡹ࠭ᇜ"),TMq6SKsGo5muadx)
			OfZToRUIl3mCkF = list(MgZJ9DxzBqPXYtk6TaN2.keys())
			if C0CbfZuXJM(u"ࠩ࡬ࡴࠬᇝ") in OfZToRUIl3mCkF: ip = MgZJ9DxzBqPXYtk6TaN2[WfgnOq9Fd4lhMSQpK5(u"ࠪ࡭ࡵ࠭ᇞ")]
			if GVPK9Ziaho6U2ySLj(u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧᇟ") in OfZToRUIl3mCkF: XXNufTcVeUDS3GpJaQ = MgZJ9DxzBqPXYtk6TaN2[KylMx0kfTOrG(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨᇠ")]
			if ebT9xRB63E(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᇡ") in OfZToRUIl3mCkF: QfZp1nrE5iHgVD60I = MgZJ9DxzBqPXYtk6TaN2[tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᇢ")]
			if b46fBrugtPDSYspzMQIx(u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧᇣ") in OfZToRUIl3mCkF: qXLnZmtUDaoyEGK9QS4sPhcJ = MgZJ9DxzBqPXYtk6TaN2[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨᇤ")]
			if vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡶࡪ࡭ࡩࡰࡰࠪᇥ") in OfZToRUIl3mCkF: hVPGrYoAys0 = MgZJ9DxzBqPXYtk6TaN2[vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫᇦ")]
			if pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡩࡩࡵࡻࠪᇧ") in OfZToRUIl3mCkF: R0YEe4uvyLMgxjJ3P9XW5kslGrf = MgZJ9DxzBqPXYtk6TaN2[Yr0wo7FaSHx(u"࠭ࡣࡪࡶࡼࠫᇨ")]
			if YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩᇩ") in OfZToRUIl3mCkF:
				gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x = MgZJ9DxzBqPXYtk6TaN2[G5TxeI0ND4ztC6(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᇪ")][WfgnOq9Fd4lhMSQpK5(u"ࠩࡸࡸࡨ࠭ᇫ")]
				if gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠱ᚺ")] not in [tjoHEAGv2XkrMBsVfCyp5U(u"ࠪ࠱ࠬᇬ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫ࠰࠭ᇭ")]: gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x = vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠱ࠧᇮ")+gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x
			JFPwNjatzforvbYRhykTIB0GmAl4Hp = ip+vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࠬࠨᇯ")+XXNufTcVeUDS3GpJaQ+A6Iyo7eXrq2RtMmDxWj(u"ࠧ࠭ࠩᇰ")+QfZp1nrE5iHgVD60I+DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࠮ࠪᇱ")+hVPGrYoAys0+uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ࠯ࠫᇲ")+R0YEe4uvyLMgxjJ3P9XW5kslGrf+Vt4ELHXZP6(u"ࠪ࠰ࠬᇳ")+gHBEnutaPSD3Wwj2VLiUNqm8Mezb1x
			if DQfHadYvTpy1UR: JFPwNjatzforvbYRhykTIB0GmAl4Hp = JFPwNjatzforvbYRhykTIB0GmAl4Hp.encode(b46fBrugtPDSYspzMQIx(u"ࠫࡺࡺࡦ࠹ࠩᇴ")).decode(cg94WALw5orUhvtHSfNO(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ᇵ"))
	JFPwNjatzforvbYRhykTIB0GmAl4Hp = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(JFPwNjatzforvbYRhykTIB0GmAl4Hp)
	return JFPwNjatzforvbYRhykTIB0GmAl4Hp
def aCId1D0KbRVrm6jq98UwyuFWkeX3(MLm1lcCvaHAGn):
	agZNCfMFKijD4zpo2yuO0Tw,showDialogs = u2NDjURZVHlmdc0(u"࠭ࠧᇶ"),tjoHEAGv2XkrMBsVfCyp5U(u"࡚ࡲࡶࡧដ")
	if MLm1lcCvaHAGn.count(xmTX9Aeidq8cVhY(u"ࠧࡠࠩᇷ"))>=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠴ᚻ"):
		MLm1lcCvaHAGn,agZNCfMFKijD4zpo2yuO0Tw = MLm1lcCvaHAGn.split(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡡࠪᇸ"),b098bsyjUud(u"࠴ᚼ"))
		agZNCfMFKijD4zpo2yuO0Tw = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡢࠫᇹ")+agZNCfMFKijD4zpo2yuO0Tw
		if oh1JUWa3LdnqTpz5(u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨᇺ") in agZNCfMFKijD4zpo2yuO0Tw: showDialogs = DItWNMaLOZ146CubYk8lfAwTy(u"ࡆࡢ࡮ࡶࡩឋ")
		else: showDialogs = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࡕࡴࡸࡩឌ")
	return MLm1lcCvaHAGn,agZNCfMFKijD4zpo2yuO0Tw,showDialogs
def dpwXv5HneTbIg0AYCGlQs():
	QW2d59Onpy = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪᇻ"))
	UvpKnXAWLT = xmTX9Aeidq8cVhY(u"࠴ᚽ")
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(QW2d59Onpy):
		for UZqkaAhucSIr6l1ed in A73K6zLXIgFROeCHJQi0Pbos.listdir(QW2d59Onpy):
			if CC4UDLW6brf(u"ࠬ࠴ࡰࡺࡱࠪᇼ") in UZqkaAhucSIr6l1ed: continue
			if DItWNMaLOZ146CubYk8lfAwTy(u"࠭࡟ࡠࡲࡼࡧࡦࡩࡨࡦࡡࡢࠫᇽ") in UZqkaAhucSIr6l1ed: continue
			TSlKw1s2X8tJ6npI3CWDcyeoBAxuL = A73K6zLXIgFROeCHJQi0Pbos.path.join(QW2d59Onpy,UZqkaAhucSIr6l1ed)
			um2iyPU9LBYMbl4NEIhWjAF8,fKG1iuWHwak9qCml6M7F = eexb5wHNQEphIrs3WCBZjYcoTMu0(TSlKw1s2X8tJ6npI3CWDcyeoBAxuL)
			UvpKnXAWLT += um2iyPU9LBYMbl4NEIhWjAF8
	return UvpKnXAWLT
def XjZeYzB5J0(u5yYiXzKRhjqoG8t,showDialogs):
	DQtupElk5g3bKVf2m07JrCnZzMWXy = BBwb2NzsHE.getSetting(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬᇾ"))
	eOrqxlkc8X7oaVLg4fYzPMH = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,G5TxeI0ND4ztC6(u"ࠨࡵࡷࡶࠬᇿ"),C0CbfZuXJM(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬሀ"),ebT9xRB63E(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬሁ"))
	gt7xMpoYdyliXJ3DSQC,Sb3H78deiy9tZV5LGokrJu = DQtupElk5g3bKVf2m07JrCnZzMWXy,eOrqxlkc8X7oaVLg4fYzPMH
	kLGEeqNYQimPptZxfw1JR6gCKM,mGduRTMt68qsJ = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠬሂ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࠭ሃ")
	if not u5yYiXzKRhjqoG8t or not eOrqxlkc8X7oaVLg4fYzPMH or DQtupElk5g3bKVf2m07JrCnZzMWXy in [jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࠧሄ"),Vt4ELHXZP6(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ህ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧሆ")]:
		OG9Usa51Nk8D = LWzUbE5adDslTXGr[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩሇ")][b46fBrugtPDSYspzMQIx(u"࠸ᚾ")]
		YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠹࠲ᚿ"),u5yYiXzKRhjqoG8t)
		JFPwNjatzforvbYRhykTIB0GmAl4Hp = ZLG9paBn0bWQd2eTVN1hw8KAq3jDHP()
		QfZp1nrE5iHgVD60I = JFPwNjatzforvbYRhykTIB0GmAl4Hp.split(tjoHEAGv2XkrMBsVfCyp5U(u"ࠪ࠰ࠬለ"))[tjoHEAGv2XkrMBsVfCyp5U(u"࠲ᛀ")]
		UvpKnXAWLT = dpwXv5HneTbIg0AYCGlQs()
		eeP3Kvuxhao7bJHV = {YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡺࡹࡥࡳࠩሉ"):YqywcljIHsFzoXaf0T97,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ሊ"):K0dHTfq6P73sD8lWLZpoh,pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧላ"):QfZp1nrE5iHgVD60I,GVPK9Ziaho6U2ySLj(u"ࠧࡪࡦࡶࠫሌ"):QaMk1EXgidcunwJhAPRIWTy5lxHrbj(UvpKnXAWLT)}
		QBDjIUdSiR = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,cg94WALw5orUhvtHSfNO(u"ࠨࡒࡒࡗ࡙࠭ል"),OG9Usa51Nk8D,eeP3Kvuxhao7bJHV,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࠪሎ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠫሏ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬሐ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩሑ"))
		if not QBDjIUdSiR.succeeded:
			if DQtupElk5g3bKVf2m07JrCnZzMWXy in [cg94WALw5orUhvtHSfNO(u"࠭ࠧሒ"),ebT9xRB63E(u"ࠧࡏࡇ࡚ࠫሓ")]: gt7xMpoYdyliXJ3DSQC = G5TxeI0ND4ztC6(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧሔ")
			elif DQtupElk5g3bKVf2m07JrCnZzMWXy==b098bsyjUud(u"ࠩࡒࡐࡉ࠭ሕ"): gt7xMpoYdyliXJ3DSQC = C0CbfZuXJM(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩሖ")
		else:
			C1pH9wIUncjKG = QBDjIUdSiR.content
			C1pH9wIUncjKG = G8EwoDOyKShm1i0IHMfNYZlU7(vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡱ࡯ࡳࡵࠩሗ"),C1pH9wIUncjKG)
			C1pH9wIUncjKG = sorted(C1pH9wIUncjKG,reverse=hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࡖࡵࡹࡪឍ"),key=lambda key: int(key[GVPK9Ziaho6U2ySLj(u"࠱ᛁ")]))
			mGduRTMt68qsJ,Sb3H78deiy9tZV5LGokrJu = KylMx0kfTOrG(u"ࠬ࠭መ"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧሙ")
			for fzPo709Cm3bQ8yeqvjVsg,mMqrNE7ewIR,hiDXjZaexOEKBd3U in C1pH9wIUncjKG:
				if fzPo709Cm3bQ8yeqvjVsg==C0CbfZuXJM(u"ࠧ࠱ࠩሚ"):
					mGduRTMt68qsJ += hiDXjZaexOEKBd3U+A6Iyo7eXrq2RtMmDxWj(u"ࠨ࠼࠽ࠫማ")
					continue
				if Sb3H78deiy9tZV5LGokrJu: Sb3H78deiy9tZV5LGokrJu += uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮࡝ࡰࠪሜ")
				FCg6Jid0cQjYmz = hiDXjZaexOEKBd3U.split(u2NDjURZVHlmdc0(u"ࠪࡠࡳ࠭ም"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠲ᛂ")]
				Qc2wak8HnAliIoPrEDXYCg5T7O31hy = tjoHEAGv2XkrMBsVfCyp5U(u"ࠫึูวๅหࠣาฬ฻ษࠡๆๆࠤๆ่ืࠨሞ") if mMqrNE7ewIR else jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬ࠭ሟ")
				Sb3H78deiy9tZV5LGokrJu += hiDXjZaexOEKBd3U.replace(FCg6Jid0cQjYmz,A6Iyo7eXrq2RtMmDxWj(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩሠ")+FCg6Jid0cQjYmz+Qc2wak8HnAliIoPrEDXYCg5T7O31hy+Yr0wo7FaSHx(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩሡ"))+KylMx0kfTOrG(u"ࠨ࡞ࡱࠫሢ")
			Sb3H78deiy9tZV5LGokrJu = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩ࡟ࡲࠬሣ")+Sb3H78deiy9tZV5LGokrJu+tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡠࡳࡢ࡮ࠨሤ")
			mGduRTMt68qsJ = mGduRTMt68qsJ.strip(G5TxeI0ND4ztC6(u"ࠫ࠿ࡀࠧሥ"))
			kLGEeqNYQimPptZxfw1JR6gCKM = BBwb2NzsHE.getSetting(oh1JUWa3LdnqTpz5(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹࠧሦ"))
			if Sb3H78deiy9tZV5LGokrJu==eOrqxlkc8X7oaVLg4fYzPMH and DQtupElk5g3bKVf2m07JrCnZzMWXy in [DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡏࡍࡆࠪሧ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ረ")]: gt7xMpoYdyliXJ3DSQC = vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡑࡏࡈࠬሩ")
			else: gt7xMpoYdyliXJ3DSQC = WfgnOq9Fd4lhMSQpK5(u"ࠩࡑࡉ࡜࠭ሪ")
			pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ራ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ሬ"),Sb3H78deiy9tZV5LGokrJu,iJnLmxA0ykozR98WXFQ4Ye3w)
			BBwb2NzsHE.setSetting(GVPK9Ziaho6U2ySLj(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹࠧር"),mGduRTMt68qsJ)
			BBwb2NzsHE.setSetting(oh1JUWa3LdnqTpz5(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧሮ"),QaMk1EXgidcunwJhAPRIWTy5lxHrbj(uZ7xiFaBvSrWG2mXjITp))
	if showDialogs:
		if gt7xMpoYdyliXJ3DSQC in [WfgnOq9Fd4lhMSQpK5(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ሯ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧሰ")]:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(oh1JUWa3LdnqTpz5(u"ࠩࠪሱ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠫሲ"),xmTX9Aeidq8cVhY(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሳ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬํๆศๅู้้ࠣไสࠢไ๎ࠥา็ศิๆࠤํํ๊ࠡๆํืฯࠦๅ็ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠา๊ࠤฬ๊ๅีๅ็อ่ࠥฯࠡ์ๆ์๋ࠦำษส๊หࠥอไฦ่อี๋ะࠠศๆัหฺࠦศไࠢฦ์ࠥอไาษ๋ฮึࠦวๅะสูࠥฮใࠡล๋ࠤฺ๊ใๅหࠣๅ๏ࠦวๅลึ่ฬฺ้่ࠠา็ࠬሴ"))
		else:
			u59uk1YqFUTd(b098bsyjUud(u"࠭ࡲࡪࡩ࡫ࡸࠬስ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪሶ"),Sb3H78deiy9tZV5LGokrJu,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩሷ"))
			gt7xMpoYdyliXJ3DSQC = tvdQHb10PhNmuy6(u"ࠩࡒࡐࡉ࠭ሸ")
	if gt7xMpoYdyliXJ3DSQC!=DQtupElk5g3bKVf2m07JrCnZzMWXy:
		BBwb2NzsHE.setSetting(cg94WALw5orUhvtHSfNO(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨሹ"),gt7xMpoYdyliXJ3DSQC)
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨሺ"))
	yHqpuj3LYGP8Z6E9 = tvdQHb10PhNmuy6(u"ࡘࡷࡻࡥត") if mGduRTMt68qsJ!=kLGEeqNYQimPptZxfw1JR6gCKM else b098bsyjUud(u"ࡉࡥࡱࡹࡥណ")
	return yHqpuj3LYGP8Z6E9
def T1kimOBuXJDxZFpzH8tUdjnGo9rN(MMZ0ya2klCVt1WqFgxo,LvTKXZ7qSYh8DQ4gfrsEiMlNVkA):
	from socket import socket as r6h8FXwU1f9Knx3BtOI45mjgiG,AF_INET as V47MU09QYBNxTjHF,SOCK_STREAM as y7Pbr6RV0Gij
	fxSeuIVhJYZtcXA = r6h8FXwU1f9Knx3BtOI45mjgiG(V47MU09QYBNxTjHF,y7Pbr6RV0Gij)
	fxSeuIVhJYZtcXA.settimeout(xmTX9Aeidq8cVhY(u"࠴ᛃ"))
	fk3hGJeYALcj5OTU1Sl2QrnH6iZIg,jurzm5fPCJ97i = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡙ࡸࡵࡦថ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠴ᛄ")
	XXsM6FBxqztKRYyAlvD = Mrx2OeZV1LNjBsQ58Savi7.time()
	try: fxSeuIVhJYZtcXA.connect((MMZ0ya2klCVt1WqFgxo,LvTKXZ7qSYh8DQ4gfrsEiMlNVkA))
	except: fk3hGJeYALcj5OTU1Sl2QrnH6iZIg = KylMx0kfTOrG(u"ࡌࡡ࡭ࡵࡨទ")
	z9aewMpiRy0U5WNhdHuoC6xJ2Tcf = Mrx2OeZV1LNjBsQ58Savi7.time()
	if fk3hGJeYALcj5OTU1Sl2QrnH6iZIg: jurzm5fPCJ97i = z9aewMpiRy0U5WNhdHuoC6xJ2Tcf-XXsM6FBxqztKRYyAlvD
	return jurzm5fPCJ97i
def CHPE7xQVoMzsLhlKmnNgudSaRp4U(showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬ࠭ሻ"),WfgnOq9Fd4lhMSQpK5(u"࠭ࠧሼ"),xmTX9Aeidq8cVhY(u"ࠧࠨሽ"),GVPK9Ziaho6U2ySLj(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫሾ"),Vt4ELHXZP6(u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨሿ"))
	else: J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = tjoHEAGv2XkrMBsVfCyp5U(u"ࡔࡳࡷࡨធ")
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==Yr0wo7FaSHx(u"࠶ᛅ"):
		for UZqkaAhucSIr6l1ed in A73K6zLXIgFROeCHJQi0Pbos.listdir(HnMP40juJfr6L1mexbWBV):
			if UZqkaAhucSIr6l1ed.endswith(VVtQk9vwe7(u"ࠪ࠲ࡩࡨࠧቀ")) and tvdQHb10PhNmuy6(u"ࠫࡩࡧࡴࡢࠩቁ") in UZqkaAhucSIr6l1ed:
				Gu59Qt0lxV = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,UZqkaAhucSIr6l1ed)
				try: LxomZnH9Ky,ooRPprGBD89QXusn = vIhJlmEwFisoAOcepqVNLTDQrY(Gu59Qt0lxV)
				except: return
				ooRPprGBD89QXusn.execute(xmTX9Aeidq8cVhY(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨቂ"))
				ooRPprGBD89QXusn.execute(xmTX9Aeidq8cVhY(u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩቃ"))
				ooRPprGBD89QXusn.execute(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨቄ"))
				LxomZnH9Ky.commit()
				LxomZnH9Ky.close()
		if showDialogs:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(tvdQHb10PhNmuy6(u"ࠨࠩቅ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠩࠪቆ"),A6Iyo7eXrq2RtMmDxWj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ቇ"),tvdQHb10PhNmuy6(u"ࠫฯ๋สࠡส้ะฬำฺࠠ็็๎ฮࠦลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠬቈ"))
	return
def DTeLX73NFMctyKU9i(wwYbrmQJE8pIThUklzeg2q,QGxUzRZvXrdjbwmlOo9,showDialogs):
	if wwYbrmQJE8pIThUklzeg2q!=None:
		global jB5YAiHhRV30
		jB5YAiHhRV30 = wwYbrmQJE8pIThUklzeg2q
	if QGxUzRZvXrdjbwmlOo9!=None:
		global Rbv2e9XtnP
		Rbv2e9XtnP = QGxUzRZvXrdjbwmlOo9
	if showDialogs!=None:
		global SSOrgDEHYe51MnzGUlsyd9xIZoP2au
		SSOrgDEHYe51MnzGUlsyd9xIZoP2au = showDialogs
	return
jB5YAiHhRV30,Rbv2e9XtnP,SSOrgDEHYe51MnzGUlsyd9xIZoP2au = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬ࠭቉"),Yr0wo7FaSHx(u"࠭ࠧቊ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࠨቋ")
def IjDgSHxpL2h(DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,c95E6IfsJToNp=b098bsyjUud(u"ࠨࠩቌ"),hQbrjUIeoFgwOTNk9zYBXlMLR=oh1JUWa3LdnqTpz5(u"ࠩࠪቍ")):
	global LWzUbE5adDslTXGr
	if showDialogs==WfgnOq9Fd4lhMSQpK5(u"ࠪࠫ቎"): showDialogs = vdHRKkIgTp56Je1OuNo(u"ࡕࡴࡸࡩន") if SSOrgDEHYe51MnzGUlsyd9xIZoP2au==oh1JUWa3LdnqTpz5(u"ࠫࠬ቏") else SSOrgDEHYe51MnzGUlsyd9xIZoP2au
	if hQbrjUIeoFgwOTNk9zYBXlMLR==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬ࠭ቐ"): hQbrjUIeoFgwOTNk9zYBXlMLR = Vt4ELHXZP6(u"ࡖࡵࡹࡪប") if Rbv2e9XtnP==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࠧቑ") else Rbv2e9XtnP
	if c95E6IfsJToNp==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠨቒ"): c95E6IfsJToNp = VVtQk9vwe7(u"ࡗࡶࡺ࡫ផ") if jB5YAiHhRV30==cg94WALw5orUhvtHSfNO(u"ࠨࠩቓ") else jB5YAiHhRV30
	if mrYgMl8P6NU==tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࠪቔ"): L74fOWc6x0PMtjrsT8YAhKp = pOIe6U1vWYC7Gh2udFBRgT(u"ࡘࡷࡻࡥព")
	else: L74fOWc6x0PMtjrsT8YAhKp = mrYgMl8P6NU
	if kOfDHhMnuAxQoBpWTeL==None: Gv7mT0LhB9YoOVpANMr = None
	elif kOfDHhMnuAxQoBpWTeL==tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࠫቕ"): Gv7mT0LhB9YoOVpANMr = {}
	else: Gv7mT0LhB9YoOVpANMr = kOfDHhMnuAxQoBpWTeL
	if QOZAYj8g6yaqhl==None: JZP07kjvbV = None
	elif QOZAYj8g6yaqhl==G5TxeI0ND4ztC6(u"ࠫࠬቖ"): JZP07kjvbV = {}
	else: JZP07kjvbV = QOZAYj8g6yaqhl
	S23hIejLtWC0 = list(JZP07kjvbV.keys())
	if cg94WALw5orUhvtHSfNO(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ቗") not in S23hIejLtWC0: JZP07kjvbV[VVtQk9vwe7(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪቘ")] = u2NDjURZVHlmdc0(u"ࠧࡁࡂࡃࡗࡐࡏࡐࡠࡊࡈࡅࡉࡋࡒࡁࡂࡃࠫ቙")
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,IIgPFWErkX,NI89n26cvktE7V4,KrD3nScWfvLwJojkZTu9ps = eKNp5b4tm03jz(OG9Usa51Nk8D)
	ZtTAbOzD0fsJxw8SNcQnr = BBwb2NzsHE.getSetting(b46fBrugtPDSYspzMQIx(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨቚ"))
	v2JEMkx6aPYch45I = BBwb2NzsHE.getSetting(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬቛ"))
	GrZvUpxLeXDqCmjfa7KQ = BBwb2NzsHE.getSetting(tvdQHb10PhNmuy6(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨቜ"))
	wQlA3HWVd9P = (IIgPFWErkX==None and NI89n26cvktE7V4==None)
	Kq8EoLcuYpDO06Msb1 = LWzUbE5adDslTXGr[xmTX9Aeidq8cVhY(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫቝ")]
	erWx8MvjBuz3p2CSIAgcXtT0 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO in Kq8EoLcuYpDO06Msb1
	IY0j7R8kNGJsuVdEfz2 = LWzUbE5adDslTXGr[KylMx0kfTOrG(u"ࠬࡘࡅࡑࡑࡖࠫ቞")]
	A6K0YgqBzbhHfpkU1tO3vi = FrC9LhHZWIySdGwNsuzqt5Rf01TXO in IY0j7R8kNGJsuVdEfz2
	KcJ3EaO5Q6bRmy = erWx8MvjBuz3p2CSIAgcXtT0 or A6K0YgqBzbhHfpkU1tO3vi
	if wQlA3HWVd9P and KcJ3EaO5Q6bRmy:
		if erWx8MvjBuz3p2CSIAgcXtT0:
			YsRHnLtbSDvrO1f7K = Kq8EoLcuYpDO06Msb1.index(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
			pzcvYOC98uawkgZT0LqVjmeiQMW = LWzUbE5adDslTXGr[A6Iyo7eXrq2RtMmDxWj(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒࠪ቟")][YsRHnLtbSDvrO1f7K]
			CX45lHhpBy8sJEekM2PqDxURn6LY0 = xlhZCNs8FQ4[YsRHnLtbSDvrO1f7K]
		elif A6K0YgqBzbhHfpkU1tO3vi:
			YsRHnLtbSDvrO1f7K = IY0j7R8kNGJsuVdEfz2.index(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
			pzcvYOC98uawkgZT0LqVjmeiQMW = LWzUbE5adDslTXGr[VVtQk9vwe7(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒࠪበ")][YsRHnLtbSDvrO1f7K]
			CX45lHhpBy8sJEekM2PqDxURn6LY0 = HzC0OmsPxKp8rbSiqlU[YsRHnLtbSDvrO1f7K]
	if NI89n26cvktE7V4==ebT9xRB63E(u"ࠨࠩቡ"): NI89n26cvktE7V4 = ZtTAbOzD0fsJxw8SNcQnr
	elif NI89n26cvktE7V4==None and v2JEMkx6aPYch45I in [mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡄ࡙࡙ࡕࠧቢ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬባ")] and c95E6IfsJToNp: NI89n26cvktE7V4 = ZtTAbOzD0fsJxw8SNcQnr
	A3AjPkoK1DneutCVINw7 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO==LWzUbE5adDslTXGr[CC4UDLW6brf(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫቤ")][Vt4ELHXZP6(u"࠽ᛆ")]
	LQNrDCbUSR1TAI = VVtQk9vwe7(u"࡚ࡲࡶࡧម") if trSQHvP4aqBWFKxN5bZgXCu(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨብ") in OG9Usa51Nk8D or Vt4ELHXZP6(u"࠭ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫ࠪቦ") in OG9Usa51Nk8D or VVtQk9vwe7(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪቧ") in OG9Usa51Nk8D or DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭ቨ") in OG9Usa51Nk8D else uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡋࡧ࡬ࡴࡧភ")
	if LQNrDCbUSR1TAI: ObFSK3zDPkrX5qgN9 = G5TxeI0ND4ztC6(u"࠶࠱ᛇ")
	elif erWx8MvjBuz3p2CSIAgcXtT0 or A6K0YgqBzbhHfpkU1tO3vi: ObFSK3zDPkrX5qgN9 = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠲࠷ᛈ")
	elif dbBRqLP6WeEV in emFVCjpawXi0xhtYQo1T9H2vPlyuJK: ObFSK3zDPkrX5qgN9 = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠳࠳ᛉ")
	elif dbBRqLP6WeEV==tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫቩ"): ObFSK3zDPkrX5qgN9 = Yr0wo7FaSHx(u"࠵࠴ᛊ")
	elif dbBRqLP6WeEV==oh1JUWa3LdnqTpz5(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫቪ"): ObFSK3zDPkrX5qgN9 = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠶࠵ᛋ")
	elif trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭ቫ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = ebT9xRB63E(u"࠼࠶ᛌ")
	elif hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡙ࠬࡈࡐࡈࡋࡅࠬቬ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = Yr0wo7FaSHx(u"࠽࠵ᛍ")
	elif Yr0wo7FaSHx(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ቭ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = WfgnOq9Fd4lhMSQpK5(u"࠲࠶ᛎ")
	elif trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡂࡊ࡚ࡅࡐ࠭ቮ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = C0CbfZuXJM(u"࠳࠲ᛏ")
	elif Wbwj0o5gsXQ8F2f(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫቯ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = xmTX9Aeidq8cVhY(u"࠴࠳ᛐ")
	elif KylMx0kfTOrG(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨተ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = uEed4OSxm7hBq9Vvky6QjHwWC(u"࠶࠴ᛑ")
	elif GVPK9Ziaho6U2ySLj(u"ࠪࡅࡐࡕࡁࡎࠩቱ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = vdHRKkIgTp56Je1OuNo(u"࠶࠺ᛒ")
	elif DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࡆࡑࡗࡂࡏࠪቲ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = DItWNMaLOZ146CubYk8lfAwTy(u"࠸࠶ᛓ")
	elif mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧታ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠸࠰ᛔ")
	elif uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨቴ") in dbBRqLP6WeEV: ObFSK3zDPkrX5qgN9 = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶࠱ᛕ")
	else: ObFSK3zDPkrX5qgN9 = Yr0wo7FaSHx(u"࠲࠷ᛖ")
	if Vt4ELHXZP6(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩት") in dbBRqLP6WeEV and not Gv7mT0LhB9YoOVpANMr and trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࠨࠪቶ") not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO and b098bsyjUud(u"ࠩࡂࠫቷ") not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.rstrip(Yr0wo7FaSHx(u"ࠪ࠳ࠬቸ"))+ebT9xRB63E(u"ࠫ࠴࠭ቹ")
	iyxVPAXLI48wBEOmYFSrR7k1UWvC = (IIgPFWErkX!=None)
	WGDgsmSdLeQNVkI5trOn = (NI89n26cvktE7V4!=None and v2JEMkx6aPYch45I!=VVtQk9vwe7(u"࡙ࠬࡔࡐࡒࠪቺ"))
	if iyxVPAXLI48wBEOmYFSrR7k1UWvC and not LQNrDCbUSR1TAI: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩቻ"),IIgPFWErkX)
	elif WGDgsmSdLeQNVkI5trOn: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(VVtQk9vwe7(u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧቼ"),NI89n26cvktE7V4)
	if iyxVPAXLI48wBEOmYFSrR7k1UWvC:
		AA2xYzW8CS7 = {cg94WALw5orUhvtHSfNO(u"ࠣࡪࡷࡸࡵࠨች"):IIgPFWErkX,Wbwj0o5gsXQ8F2f(u"ࠤ࡫ࡸࡹࡶࡳࠣቾ"):IIgPFWErkX}
		YYBTohe1AyOJ5uMlScX0 = IIgPFWErkX
	else: AA2xYzW8CS7,YYBTohe1AyOJ5uMlScX0 = {},xmTX9Aeidq8cVhY(u"ࠪࠫቿ")
	if WGDgsmSdLeQNVkI5trOn:
		import urllib3.util.connection as tjgzDHRyCJiS5XWxKcOp2MU4d3
		KAbz0kcq4y5hwpW3oRMePlfInmJY = GCkrzDJ618ame5f(tjgzDHRyCJiS5XWxKcOp2MU4d3,ZtTAbOzD0fsJxw8SNcQnr)
	O7iXQPyGZ12vokH8suhV9RxAJYUb,Cpxc4DQXoJyY5WO2dTFBAbMRne,nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3,uYLw1hT0BmMXSNolFztI,hEj8rpdq34QeKkG,verify = L74fOWc6x0PMtjrsT8YAhKp,dbBRqLP6WeEV,DDWGZztREldKorePp6whj3,b46fBrugtPDSYspzMQIx(u"ࡆࡢ࡮ࡶࡩយ"),b46fBrugtPDSYspzMQIx(u"ࡆࡢ࡮ࡶࡩយ"),KrD3nScWfvLwJojkZTu9ps
	if A3AjPkoK1DneutCVINw7: hEj8rpdq34QeKkG = vlW6K1g8Xo35mPYbyO2GS(u"ࡕࡴࡸࡩរ")
	if KcJ3EaO5Q6bRmy or L74fOWc6x0PMtjrsT8YAhKp: O7iXQPyGZ12vokH8suhV9RxAJYUb = xmTX9Aeidq8cVhY(u"ࡈࡤࡰࡸ࡫ល")
	if erWx8MvjBuz3p2CSIAgcXtT0: nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3 = Yr0wo7FaSHx(u"ࠫࡕࡕࡓࡕࠩኀ")
	jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = -A6Iyo7eXrq2RtMmDxWj(u"࠳ᛗ"),tvdQHb10PhNmuy6(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬኁ")
	for uvTwHSmjyW6Vr0192IZ in range(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠼ᛘ")):
		JgIfK4HDZv2RbTz7WndCMEQ1BNeUP = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࡗࡶࡺ࡫វ")
		llC9WmbrAIgpzfi3n = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡊࡦࡲࡳࡦឝ")
		try:
			if uvTwHSmjyW6Vr0192IZ: Cpxc4DQXoJyY5WO2dTFBAbMRne = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧኂ")
			if LQNrDCbUSR1TAI or not iyxVPAXLI48wBEOmYFSrR7k1UWvC: gAcRrfHSDhJUKqPXF(trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠢࠣࡓࡕࡋࡎࡠࡗࡕࡐࠬኃ"),FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,Cpxc4DQXoJyY5WO2dTFBAbMRne,nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3)
			try: QBDjIUdSiR.close()
			except: pass
			kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO
			QBDjIUdSiR = yUt4fqQpnL0AZ.request(nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,data=Gv7mT0LhB9YoOVpANMr,headers=JZP07kjvbV,verify=verify,allow_redirects=O7iXQPyGZ12vokH8suhV9RxAJYUb,timeout=ObFSK3zDPkrX5qgN9,proxies=AA2xYzW8CS7)
			if tjoHEAGv2XkrMBsVfCyp5U(u"࠷࠵࠶ᛙ")<=QBDjIUdSiR.status_code<=KylMx0kfTOrG(u"࠸࠿࠹ᛚ"):
				if not uYLw1hT0BmMXSNolFztI:
					ipPVcZY0GMtNr5EdKXswfHUnAv = list(QBDjIUdSiR.headers.keys())
					if KylMx0kfTOrG(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪኄ") in ipPVcZY0GMtNr5EdKXswfHUnAv: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = QBDjIUdSiR.headers[WfgnOq9Fd4lhMSQpK5(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫኅ")]
					elif vdHRKkIgTp56Je1OuNo(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬኆ") in ipPVcZY0GMtNr5EdKXswfHUnAv: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = QBDjIUdSiR.headers[CC4UDLW6brf(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ኇ")]
					else: uYLw1hT0BmMXSNolFztI = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࡙ࡸࡵࡦឞ")
					if not uYLw1hT0BmMXSNolFztI: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.encode(xmTX9Aeidq8cVhY(u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭ኈ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡩࡨࡰࡲࡶࡪ࠭኉")).decode(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡶࡶࡩ࠼ࠬኊ"),C0CbfZuXJM(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨኋ"))
					if KcJ3EaO5Q6bRmy and QBDjIUdSiR.status_code==pOIe6U1vWYC7Gh2udFBRgT(u"࠹࠰࠸ᛛ"):
						O7iXQPyGZ12vokH8suhV9RxAJYUb = L74fOWc6x0PMtjrsT8YAhKp
						nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3 = DDWGZztREldKorePp6whj3
						uYLw1hT0BmMXSNolFztI = xmTX9Aeidq8cVhY(u"࡚ࡲࡶࡧស")
						zsVay83BJ0UCOuKcLG9RQd
				if not uYLw1hT0BmMXSNolFztI or L74fOWc6x0PMtjrsT8YAhKp:
					if b46fBrugtPDSYspzMQIx(u"ࠩ࡫ࡸࡹࡶࠧኌ") not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
						qODFmdJk67Szep4Yh2vun9oMgRy = OfTKisDR0Lv(kHWT0XY2S6apruwxiB8FDl1,b46fBrugtPDSYspzMQIx(u"ࠪࡹࡷࡲࠧኍ"))
						FrC9LhHZWIySdGwNsuzqt5Rf01TXO = qODFmdJk67Szep4Yh2vun9oMgRy+cg94WALw5orUhvtHSfNO(u"ࠫ࠴࠭኎")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO.lstrip(ebT9xRB63E(u"ࠬ࠵ࠧ኏"))
				if not uYLw1hT0BmMXSNolFztI and L74fOWc6x0PMtjrsT8YAhKp and not eeiIspx5JaGYcH0zCu(FrC9LhHZWIySdGwNsuzqt5Rf01TXO): Lh4zI6NWcQ2lmA
			elif G5TxeI0ND4ztC6(u"࠶࠷࠳ᛝ")<=QBDjIUdSiR.status_code<=tvdQHb10PhNmuy6(u"࠵࠺࠻ᛜ"):
				QBDjIUdSiR.reason = QBDjIUdSiR.content
				hEj8rpdq34QeKkG = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡔࡳࡷࡨហ")
			kHWT0XY2S6apruwxiB8FDl1 = QBDjIUdSiR.url
			jjKUzRlixEhe7vY3BO6TDs5pGZ = QBDjIUdSiR.status_code
			KPW9hQet1aZUu4H2b0lvSi7Rs = QBDjIUdSiR.reason
			QBDjIUdSiR.raise_for_status()
			llC9WmbrAIgpzfi3n = Yr0wo7FaSHx(u"ࡕࡴࡸࡩឡ")
		except yUt4fqQpnL0AZ.exceptions.HTTPError as Rs2m41dCIxHrBGwZ9i06DULv:
			pass
		except yUt4fqQpnL0AZ.exceptions.Timeout as Rs2m41dCIxHrBGwZ9i06DULv:
			if wIqFesTOvYnu5S2dWfpBVC: KPW9hQet1aZUu4H2b0lvSi7Rs = str(Rs2m41dCIxHrBGwZ9i06DULv.message).split(tvdQHb10PhNmuy6(u"࠭࠺ࠡࠩነ"))[trSQHvP4aqBWFKxN5bZgXCu(u"࠳ᛞ")]
			else: KPW9hQet1aZUu4H2b0lvSi7Rs = str(Rs2m41dCIxHrBGwZ9i06DULv).split(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧ࠻ࠢࠪኑ"))[oh1JUWa3LdnqTpz5(u"࠴ᛟ")]
		except yUt4fqQpnL0AZ.exceptions.ConnectionError as Rs2m41dCIxHrBGwZ9i06DULv:
			try:
				CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ = Rs2m41dCIxHrBGwZ9i06DULv.message[KylMx0kfTOrG(u"࠴ᛠ")]
				KPW9hQet1aZUu4H2b0lvSi7Rs = CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ
				if uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡇࡵࡶࡳࡵࠧኒ") in CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ: jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = JJDtX1PZyIgN2T.findall(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦና"),CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ)[trSQHvP4aqBWFKxN5bZgXCu(u"࠵ᛡ")]
				elif trSQHvP4aqBWFKxN5bZgXCu(u"ࠪ࠰ࠥ࡫ࡲࡳࡱࡵࠬࠬኔ") in CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ: jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = JJDtX1PZyIgN2T.findall(CC4UDLW6brf(u"ࠦ࠱ࠦࡥࡳࡴࡲࡶࡡ࠮ࠨ࡝ࡦ࠮࠭࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭ࠢን"),CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ)[WfgnOq9Fd4lhMSQpK5(u"࠶ᛢ")]
				elif CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ.count(GVPK9Ziaho6U2ySLj(u"ࠬࡀࠧኖ"))>=pOIe6U1vWYC7Gh2udFBRgT(u"࠳ᛤ"): KPW9hQet1aZUu4H2b0lvSi7Rs,jjKUzRlixEhe7vY3BO6TDs5pGZ = JJDtX1PZyIgN2T.findall(A6Iyo7eXrq2RtMmDxWj(u"࠭࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪࠩኗ"),CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ)[u2NDjURZVHlmdc0(u"࠰ᛣ")]
			except: pass
		except yUt4fqQpnL0AZ.exceptions.RequestException as Rs2m41dCIxHrBGwZ9i06DULv:
			if wIqFesTOvYnu5S2dWfpBVC: KPW9hQet1aZUu4H2b0lvSi7Rs = Rs2m41dCIxHrBGwZ9i06DULv.message
			else: KPW9hQet1aZUu4H2b0lvSi7Rs = str(Rs2m41dCIxHrBGwZ9i06DULv)
		except:
			JgIfK4HDZv2RbTz7WndCMEQ1BNeUP = pOIe6U1vWYC7Gh2udFBRgT(u"ࡈࡤࡰࡸ࡫អ")
			try: jjKUzRlixEhe7vY3BO6TDs5pGZ = QBDjIUdSiR.status_code
			except: pass
			try: KPW9hQet1aZUu4H2b0lvSi7Rs = QBDjIUdSiR.reason
			except: pass
		KPW9hQet1aZUu4H2b0lvSi7Rs = str(KPW9hQet1aZUu4H2b0lvSi7Rs)
		b6kj4LJ5tzTeOMQi(WfgnOq9Fd4lhMSQpK5(u"ࠧࡏࡑࡗࡍࡈࡋࠧኘ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠨ࠰ࠣࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠠࠡࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ኙ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+A6Iyo7eXrq2RtMmDxWj(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫኚ")+KPW9hQet1aZUu4H2b0lvSi7Rs+ebT9xRB63E(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬኛ")+dbBRqLP6WeEV+GVPK9Ziaho6U2ySLj(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪኜ")+OG9Usa51Nk8D+C0CbfZuXJM(u"ࠬࠦ࡝ࠨኝ"))
		if wQlA3HWVd9P and KcJ3EaO5Q6bRmy and JgIfK4HDZv2RbTz7WndCMEQ1BNeUP and not hEj8rpdq34QeKkG and jjKUzRlixEhe7vY3BO6TDs5pGZ!=hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴࠳࠴ᛥ"):
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = pzcvYOC98uawkgZT0LqVjmeiQMW
			hEj8rpdq34QeKkG = cg94WALw5orUhvtHSfNO(u"ࡗࡶࡺ࡫ឣ")
			continue
		if JgIfK4HDZv2RbTz7WndCMEQ1BNeUP: break
	if NI89n26cvktE7V4!=None and v2JEMkx6aPYch45I!=b46fBrugtPDSYspzMQIx(u"࠭ࡓࡕࡑࡓࠫኞ"): tjgzDHRyCJiS5XWxKcOp2MU4d3.create_connection = KAbz0kcq4y5hwpW3oRMePlfInmJY
	if v2JEMkx6aPYch45I==b46fBrugtPDSYspzMQIx(u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧኟ") and c95E6IfsJToNp: NI89n26cvktE7V4 = None
	if not llC9WmbrAIgpzfi3n and IIgPFWErkX==None and dbBRqLP6WeEV not in emFVCjpawXi0xhtYQo1T9H2vPlyuJK:
		n6MNfIpoX7GgJZu = By7dgpHrCuDPh3VfxiJ9n2.format_exc()
		if n6MNfIpoX7GgJZu!=trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫአ"): uea9JUBOMcEfh8CN0v6b.stderr.write(n6MNfIpoX7GgJZu)
	pmTdyfMuY6I3UQczZ = hzJoxHQE89aNMR7drb0VntI3CKeDFm()
	if LQNrDCbUSR1TAI:
		if   cg94WALw5orUhvtHSfNO(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬኡ") in kHWT0XY2S6apruwxiB8FDl1 and ebT9xRB63E(u"ࠪࠪࡺࡸ࡬࠾ࠩኢ") in kHWT0XY2S6apruwxiB8FDl1: kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1.rsplit(vdHRKkIgTp56Je1OuNo(u"ࠫࠫࡻࡲ࡭࠿ࠪኣ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴ᛦ"))[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴ᛦ")]
		elif hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨኤ") in kHWT0XY2S6apruwxiB8FDl1 and trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠦࡶࡴ࡯ࡁࠬእ") in kHWT0XY2S6apruwxiB8FDl1: kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1.rsplit(CC4UDLW6brf(u"ࠧࠧࡷࡵࡰࡂ࠭ኦ"),G5TxeI0ND4ztC6(u"࠵ᛧ"))[G5TxeI0ND4ztC6(u"࠵ᛧ")]
		elif tvdQHb10PhNmuy6(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭ኧ") in kHWT0XY2S6apruwxiB8FDl1 and vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠩࡹࡷࡲ࠽ࠨከ") in kHWT0XY2S6apruwxiB8FDl1: kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1.rsplit(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࠪࡺࡸ࡬࠾ࠩኩ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠶ᛨ"))[uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠶ᛨ")]
		elif b098bsyjUud(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫኪ") in kHWT0XY2S6apruwxiB8FDl1 and KylMx0kfTOrG(u"ࠬࠬࡵࡳ࡮ࡀࠫካ") in kHWT0XY2S6apruwxiB8FDl1: kHWT0XY2S6apruwxiB8FDl1 = kHWT0XY2S6apruwxiB8FDl1.rsplit(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࠦࡶࡴ࡯ࡁࠬኬ"),cg94WALw5orUhvtHSfNO(u"࠷ᛩ"))[cg94WALw5orUhvtHSfNO(u"࠷ᛩ")]
	pmTdyfMuY6I3UQczZ.url = kHWT0XY2S6apruwxiB8FDl1
	pmTdyfMuY6I3UQczZ.scrape = LQNrDCbUSR1TAI
	try: hsS6bI83uHpLeO4Bf0TJ = QBDjIUdSiR.content
	except: hsS6bI83uHpLeO4Bf0TJ = Vt4ELHXZP6(u"ࠧࠨክ")
	try: VEZ2OmqIYG = QBDjIUdSiR.headers
	except: VEZ2OmqIYG = {}
	try: ssD4UGYrwIZCty0HxJud93bN5fB = QBDjIUdSiR.cookies.get_dict()
	except: ssD4UGYrwIZCty0HxJud93bN5fB = {}
	try: QBDjIUdSiR.close()
	except: pass
	if DQfHadYvTpy1UR:
		try: hsS6bI83uHpLeO4Bf0TJ = hsS6bI83uHpLeO4Bf0TJ.decode(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࡷࡷࡪ࠽࠭ኮ"))
		except: pass
	jjKUzRlixEhe7vY3BO6TDs5pGZ = int(jjKUzRlixEhe7vY3BO6TDs5pGZ)
	pmTdyfMuY6I3UQczZ.code = jjKUzRlixEhe7vY3BO6TDs5pGZ
	pmTdyfMuY6I3UQczZ.reason = KPW9hQet1aZUu4H2b0lvSi7Rs
	pmTdyfMuY6I3UQczZ.content = hsS6bI83uHpLeO4Bf0TJ
	pmTdyfMuY6I3UQczZ.headers = VEZ2OmqIYG
	pmTdyfMuY6I3UQczZ.cookies = ssD4UGYrwIZCty0HxJud93bN5fB
	pmTdyfMuY6I3UQczZ.succeeded = llC9WmbrAIgpzfi3n
	if wIqFesTOvYnu5S2dWfpBVC or isinstance(pmTdyfMuY6I3UQczZ.content,str): jmw2BldUphRiO = pmTdyfMuY6I3UQczZ.content.lower()
	else: jmw2BldUphRiO = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࠪኯ")
	vxtO15lf9GB2CsVaZFDNMILuTQU = (A6Iyo7eXrq2RtMmDxWj(u"ࠪࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧኰ") in jmw2BldUphRiO or mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ኱") in jmw2BldUphRiO) and jmw2BldUphRiO.count(oh1JUWa3LdnqTpz5(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨኲ"))>vlW6K1g8Xo35mPYbyO2GS(u"࠲ᛪ") and uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨኳ") not in dbBRqLP6WeEV and jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡸࡴࡱࡥ࡯ࠩኴ") not in jmw2BldUphRiO and not LQNrDCbUSR1TAI
	if jjKUzRlixEhe7vY3BO6TDs5pGZ==WfgnOq9Fd4lhMSQpK5(u"࠳࠲࠳᛫") and vxtO15lf9GB2CsVaZFDNMILuTQU: pmTdyfMuY6I3UQczZ.succeeded = KylMx0kfTOrG(u"ࡊࡦࡲࡳࡦឤ")
	if pmTdyfMuY6I3UQczZ.succeeded and wQlA3HWVd9P and KcJ3EaO5Q6bRmy:
		if A3AjPkoK1DneutCVINw7: CX45lHhpBy8sJEekM2PqDxURn6LY0 = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡅࡄࡔ࡙ࡉࡈࡂࠩኵ")+Gv7mT0LhB9YoOVpANMr[b098bsyjUud(u"ࠩ࡭ࡳࡧ࠭኶")].upper().replace(Wbwj0o5gsXQ8F2f(u"ࠪࡋࡊ࡚ࠧ኷"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࠬኸ"))
		M9M2oTiGEk8AYnjmZXzutyxeJU = dPzeYJhmT9SHGO0ivLENku4rxl6Cc(CX45lHhpBy8sJEekM2PqDxURn6LY0)
	if not pmTdyfMuY6I3UQczZ.succeeded and wQlA3HWVd9P:
		ZECn8mVfK6rTWH30beDh1PLtjJq = (vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩኹ") in jmw2BldUphRiO and oh1JUWa3LdnqTpz5(u"࠭ࡲࡢࡻࠣ࡭ࡩࡀࠠࠨኺ") in jmw2BldUphRiO)
		QQcZO6RWBpfbPeM7x = (A6Iyo7eXrq2RtMmDxWj(u"ࠧ࠶ࠢࡶࡩࡨ࠭ኻ") in jmw2BldUphRiO and A6Iyo7eXrq2RtMmDxWj(u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩኼ") in jmw2BldUphRiO)
		tZ0VGhrxyWq2McRnm = (jjKUzRlixEhe7vY3BO6TDs5pGZ in [b098bsyjUud(u"࠶࠳࠷᛬")] and vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡨࡶࡷࡵࡲࠡࡥࡲࡨࡪࡀࠠ࠲࠲࠵࠴ࠬኽ") in jmw2BldUphRiO)
		Fl61vdG9sAawqkHZnOJ45u3cmN = (GVPK9Ziaho6U2ySLj(u"ࠪࡣࡨ࡬࡟ࡤࡪ࡯ࡣࠬኾ") in jmw2BldUphRiO and WfgnOq9Fd4lhMSQpK5(u"ࠫࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࠨ኿") in jmw2BldUphRiO)
		if   vxtO15lf9GB2CsVaZFDNMILuTQU: KPW9hQet1aZUu4H2b0lvSi7Rs = Yr0wo7FaSHx(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬዀ")
		elif ZECn8mVfK6rTWH30beDh1PLtjJq: KPW9hQet1aZUu4H2b0lvSi7Rs = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ዁")
		elif QQcZO6RWBpfbPeM7x: KPW9hQet1aZUu4H2b0lvSi7Rs = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧዂ")
		elif tZ0VGhrxyWq2McRnm: KPW9hQet1aZUu4H2b0lvSi7Rs = vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡤࡧࡨ࡫ࡳࡴࠢࡧࡩࡳ࡯ࡥࡥࠩዃ")
		elif Fl61vdG9sAawqkHZnOJ45u3cmN: KPW9hQet1aZUu4H2b0lvSi7Rs = b098bsyjUud(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫዄ")
		else: KPW9hQet1aZUu4H2b0lvSi7Rs = str(KPW9hQet1aZUu4H2b0lvSi7Rs)
		if dbBRqLP6WeEV in y5ZuIeDBf0RtS: pass
		elif dbBRqLP6WeEV in emFVCjpawXi0xhtYQo1T9H2vPlyuJK:
			b6kj4LJ5tzTeOMQi(oh1JUWa3LdnqTpz5(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩዅ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+VVtQk9vwe7(u"ࠫࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ዆")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+cg94WALw5orUhvtHSfNO(u"ࠬࠦ࡝ࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭዇")+KPW9hQet1aZUu4H2b0lvSi7Rs+trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨወ")+dbBRqLP6WeEV+xmTX9Aeidq8cVhY(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ዉ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠢࡠࠫዊ"))
		else: b6kj4LJ5tzTeOMQi(CC4UDLW6brf(u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧዋ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+KylMx0kfTOrG(u"ࠪࠤࠥࠦࡄࡪࡴࡨࡧࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧዌ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬው")+KPW9hQet1aZUu4H2b0lvSi7Rs+G5TxeI0ND4ztC6(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧዎ")+dbBRqLP6WeEV+A6Iyo7eXrq2RtMmDxWj(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬዏ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠡ࡟ࠪዐ"))
		qulgK3cADW5fwV4I8mG9ia = i35i6al7upCAreLFQ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		if wIqFesTOvYnu5S2dWfpBVC and isinstance(qulgK3cADW5fwV4I8mG9ia,unicode): qulgK3cADW5fwV4I8mG9ia = qulgK3cADW5fwV4I8mG9ia.encode(u2NDjURZVHlmdc0(u"ࠨࡷࡷࡪ࠽࠭ዑ"))
		if KcJ3EaO5Q6bRmy: qulgK3cADW5fwV4I8mG9ia = qulgK3cADW5fwV4I8mG9ia.split(WfgnOq9Fd4lhMSQpK5(u"ࠩ࠲ࠫዒ"))[-Wbwj0o5gsXQ8F2f(u"࠴᛭")]
		cXMUkm1ezSy = KPW9hQet1aZUu4H2b0lvSi7Rs
		KPW9hQet1aZUu4H2b0lvSi7Rs = str(KPW9hQet1aZUu4H2b0lvSi7Rs)+b098bsyjUud(u"ࠪࡠࡳ࠮ࠠࠨዓ")+qulgK3cADW5fwV4I8mG9ia+Yr0wo7FaSHx(u"ࠫࠥ࠯ࠧዔ")
		if vxtO15lf9GB2CsVaZFDNMILuTQU or ZECn8mVfK6rTWH30beDh1PLtjJq or QQcZO6RWBpfbPeM7x or tZ0VGhrxyWq2McRnm or Fl61vdG9sAawqkHZnOJ45u3cmN:
			jjKUzRlixEhe7vY3BO6TDs5pGZ = -b46fBrugtPDSYspzMQIx(u"࠶ᛮ")
			pmTdyfMuY6I3UQczZ.code = jjKUzRlixEhe7vY3BO6TDs5pGZ
			pmTdyfMuY6I3UQczZ.reason = KPW9hQet1aZUu4H2b0lvSi7Rs
			if hQbrjUIeoFgwOTNk9zYBXlMLR:
				gMumwQDrAhH4polcyFn7tfa06W = BBwb2NzsHE.getSetting(A6Iyo7eXrq2RtMmDxWj(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠷ࠧዕ"))
				CtEZU8wJbhsHKPQGiMeVjq2X5xn = BBwb2NzsHE.getSetting(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡡࡷ࠰ࡩࡥ࡮ࡲࡥࡥ࠰ࡶࡧࡦࡸࡰࡦࡲࡵࡳࡽࡿ࠲ࠨዖ"))
				Aob1wRO3ea7BmdlL5JQV = BBwb2NzsHE.getSetting(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠴ࠩ዗"))
				gMumwQDrAhH4polcyFn7tfa06W = Vt4ELHXZP6(u"࠵ᛯ") if not gMumwQDrAhH4polcyFn7tfa06W else int(gMumwQDrAhH4polcyFn7tfa06W)
				CtEZU8wJbhsHKPQGiMeVjq2X5xn = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶ᛰ") if not CtEZU8wJbhsHKPQGiMeVjq2X5xn else int(CtEZU8wJbhsHKPQGiMeVjq2X5xn)
				Aob1wRO3ea7BmdlL5JQV = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠰ᛱ") if not Aob1wRO3ea7BmdlL5JQV else int(Aob1wRO3ea7BmdlL5JQV)
				eyZFcnmiIJDldvVf0A2s8MXE17 = gMumwQDrAhH4polcyFn7tfa06W>Vt4ELHXZP6(u"࠴ᛲ") and CtEZU8wJbhsHKPQGiMeVjq2X5xn>Vt4ELHXZP6(u"࠴ᛲ") and Aob1wRO3ea7BmdlL5JQV>Vt4ELHXZP6(u"࠴ᛲ")
				y9yaAJxnhsEzD0egpvZMNumCw = []
				if eyZFcnmiIJDldvVf0A2s8MXE17 or gMumwQDrAhH4polcyFn7tfa06W<=ebT9xRB63E(u"࠶ᛴ"): y9yaAJxnhsEzD0egpvZMNumCw += [G5TxeI0ND4ztC6(u"࠳ᛳ"),G5TxeI0ND4ztC6(u"࠳ᛳ"),G5TxeI0ND4ztC6(u"࠳ᛳ"),G5TxeI0ND4ztC6(u"࠳ᛳ")]
				if eyZFcnmiIJDldvVf0A2s8MXE17 or CtEZU8wJbhsHKPQGiMeVjq2X5xn<=u2NDjURZVHlmdc0(u"࠷ᛵ"): y9yaAJxnhsEzD0egpvZMNumCw += [WfgnOq9Fd4lhMSQpK5(u"࠷ᛶ"),WfgnOq9Fd4lhMSQpK5(u"࠷ᛶ")]
				if eyZFcnmiIJDldvVf0A2s8MXE17 or Aob1wRO3ea7BmdlL5JQV<=Vt4ELHXZP6(u"࠹ᛷ"): y9yaAJxnhsEzD0egpvZMNumCw += [Vt4ELHXZP6(u"࠹ᛷ")]
				if b098bsyjUud(u"࠰ᛸ"):
					Vb5pOLorltCPJN = BBwb2NzsHE.getSetting(A6Iyo7eXrq2RtMmDxWj(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡧࡳ࠹࠭ዘ"))
					uqTMC2Zj6pyzFEJ819kOvSKte = BBwb2NzsHE.getSetting(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡨࡴ࠻ࠧዙ"))
					Vb5pOLorltCPJN = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠺࠻࠼࠽᛹") if not Vb5pOLorltCPJN else int(Vb5pOLorltCPJN)
					uqTMC2Zj6pyzFEJ819kOvSKte = vdHRKkIgTp56Je1OuNo(u"࠻࠼࠽࠾᛺") if not uqTMC2Zj6pyzFEJ819kOvSKte else int(uqTMC2Zj6pyzFEJ819kOvSKte)
					if Vb5pOLorltCPJN>uEed4OSxm7hBq9Vvky6QjHwWC(u"࠵࠴᛻"): y9yaAJxnhsEzD0egpvZMNumCw.append(vdHRKkIgTp56Je1OuNo(u"࠸᛼"))
					if uqTMC2Zj6pyzFEJ819kOvSKte>NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠸࠰᛾"): y9yaAJxnhsEzD0egpvZMNumCw.append(vlW6K1g8Xo35mPYbyO2GS(u"࠺᛽"))
				gOBCEfxDK360Y1sNH2rn4q8hXdm = GpOkwndjsI27uM.sample(y9yaAJxnhsEzD0egpvZMNumCw,u2NDjURZVHlmdc0(u"࠱᛿"))[vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠱ᜀ")]
				BFUbt3uhW4kcjVNSHAl0G5eRw = b098bsyjUud(u"ࠪื๏ืแาࠢิๆ๊ࠦࠠࠨዚ")+str(gOBCEfxDK360Y1sNH2rn4q8hXdm)
				b6kj4LJ5tzTeOMQi(tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪዛ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+VVtQk9vwe7(u"ࠬࠦࠠࠡࠢࡗࡶࡾࠦࡢࡺࡲࡤࡷࡸࠦࡳࡦࡥࡸࡶ࡮ࡺࡹࠡࡥ࡫ࡩࡨࡱࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ዜ")+str(gOBCEfxDK360Y1sNH2rn4q8hXdm)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࠠ࡞ࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬዝ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+ebT9xRB63E(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨዞ")+cXMUkm1ezSy+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪዟ")+dbBRqLP6WeEV+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨዠ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+b46fBrugtPDSYspzMQIx(u"ࠪࠤࡢ࠭ዡ"))
				sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(trSQHvP4aqBWFKxN5bZgXCu(u"ࠫอีมࠡษ็ๅา฻ࠠศๆฦ้๋๐ࠧዢ"),BFUbt3uhW4kcjVNSHAl0G5eRw,Mrx2OeZV1LNjBsQ58Savi7=CC4UDLW6brf(u"࠳࠳࠴࠵ᜁ"))
				if gOBCEfxDK360Y1sNH2rn4q8hXdm==GVPK9Ziaho6U2ySLj(u"࠴ᜂ"):
					Ez8q25FZGyQvk47oeVDKmTfPY3sc6 = b46fBrugtPDSYspzMQIx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠩࡴࡷࡵࡸࡺࡡࡦࡳࡺࡴࡴࡳࡻࡀࡅࡊࠬࡢࡳࡱࡺࡷࡪࡸ࠽ࡧࡣ࡯ࡷࡪࠬࡦࡰࡴࡺࡥࡷࡪ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡀ࠲ࡣ࠵࠷࠴ࡦ࠼࠸࠺࠲ࡤ࠹࠹࠶࠱ࡥࡤࡦ࠷࠼࠸ࡣ࠲࠳࠷࠹ࡩ࠿࠶࠳ࡧ࠻ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠯ࡥࡲࡱ࠿࠾࠰࠹࠲ࠪዣ")
					XTNUWlZgoH = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ዤ")+Ez8q25FZGyQvk47oeVDKmTfPY3sc6+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧዥ")
					pfvg1xiojJZXWPw = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,vdHRKkIgTp56Je1OuNo(u"ࡋࡧ࡬ࡴࡧឥ"),vdHRKkIgTp56Je1OuNo(u"ࡋࡧ࡬ࡴࡧឥ"))
					Xk1oKsdyMLBEJa57c = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࠩዦ") if pfvg1xiojJZXWPw.succeeded else str(Aob1wRO3ea7BmdlL5JQV+KylMx0kfTOrG(u"࠵ᜃ"))
					BBwb2NzsHE.setSetting(u2NDjURZVHlmdc0(u"ࠩࡤࡺ࠳࡬ࡡࡪ࡮ࡨࡨ࠳ࡹࡣࡢࡴࡳࡩࡵࡸ࡯ࡹࡻ࠴ࠫዧ"),Xk1oKsdyMLBEJa57c)
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==vlW6K1g8Xo35mPYbyO2GS(u"࠷ᜄ"):
					Ez8q25FZGyQvk47oeVDKmTfPY3sc6 = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂࡺࡲࡶࡧ࠽ࡦ࠷ࡩ࠲ࡧࡥ࠸࠽࠲࠾ࡦࡥ࠲࠰࠸ࡨ࠸ࡤ࠮࠻࠴࠺ࡨ࠳ࡢࡤ࠹࠶࠻࠾࠾࠰ࡤࡧ࠵ࡥࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨየ")
					XTNUWlZgoH = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+A6Iyo7eXrq2RtMmDxWj(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫዩ")+Ez8q25FZGyQvk47oeVDKmTfPY3sc6+Vt4ELHXZP6(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬዪ")
					pfvg1xiojJZXWPw = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡌࡡ࡭ࡵࡨឦ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࡌࡡ࡭ࡵࡨឦ"))
					Xk1oKsdyMLBEJa57c = vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠧያ") if pfvg1xiojJZXWPw.succeeded else str(CtEZU8wJbhsHKPQGiMeVjq2X5xn+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷ᜅ"))
					BBwb2NzsHE.setSetting(VVtQk9vwe7(u"ࠧࡢࡸ࠱ࡪࡦ࡯࡬ࡦࡦ࠱ࡷࡨࡧࡲࡱࡧࡳࡶࡴࡾࡹ࠲ࠩዬ"),Xk1oKsdyMLBEJa57c)
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==u2NDjURZVHlmdc0(u"࠳ᜆ"):
					Ez8q25FZGyQvk47oeVDKmTfPY3sc6 = WfgnOq9Fd4lhMSQpK5(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡹࡸࡵࡦ࠼࠺࠺ࡧ࠺ࡦࡤ࠵࠷ࡪࡨࡪ࠱࠺ࡦ࠼ࡧ࠺࠻ࡡ࠲࠷ࡩ࠷࠻࠶࠴ࡤࡦ࠼࠵࠹ࡩࡀࡱࡴࡲࡼࡾ࠳ࡳࡦࡴࡹࡩࡷ࠴ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠱ࡧࡴࡳ࠺࠹࠲࠳࠵ࠬይ")
					XTNUWlZgoH = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+xmTX9Aeidq8cVhY(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩዮ")+Ez8q25FZGyQvk47oeVDKmTfPY3sc6+vdHRKkIgTp56Je1OuNo(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪዯ")
					pfvg1xiojJZXWPw = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,cg94WALw5orUhvtHSfNO(u"ࡆࡢ࡮ࡶࡩឧ"),cg94WALw5orUhvtHSfNO(u"ࡆࡢ࡮ࡶࡩឧ"))
					Xk1oKsdyMLBEJa57c = A6Iyo7eXrq2RtMmDxWj(u"ࠫࠬደ") if pfvg1xiojJZXWPw.succeeded else str(gMumwQDrAhH4polcyFn7tfa06W+Vt4ELHXZP6(u"࠲ᜇ"))
					BBwb2NzsHE.setSetting(vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡧࡶ࠯ࡨࡤ࡭ࡱ࡫ࡤ࠯ࡵࡦࡥࡷࡶࡥࡱࡴࡲࡼࡾ࠷ࠧዱ"),Xk1oKsdyMLBEJa57c)
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==b098bsyjUud(u"࠶ᜈ"):
					Ez8q25FZGyQvk47oeVDKmTfPY3sc6 = oh1JUWa3LdnqTpz5(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡤ࠴࠹࠷ࡦࡨ࠱ࡦ࠷࠳࠸࠹ࡪ࠲ࡤࡣ࠸ࡨ࠺ࡪ࠳ࡧ࠻ࡨ࠷ࡨ࠹࠸࠷ࡧࡦࡥ࠶࠷࠰࠹࠵࠻࠽ࡦ࠽࠳࠻ࡥࡸࡷࡹࡵ࡭ࡉࡧࡤࡨࡪࡸࡳ࠾ࡶࡵࡹࡪࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ዲ")
					XTNUWlZgoH = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+xmTX9Aeidq8cVhY(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧዳ")+Ez8q25FZGyQvk47oeVDKmTfPY3sc6+vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨዴ")
					pfvg1xiojJZXWPw = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪឨ"),dbBRqLP6WeEV,DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪឨ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡇࡣ࡯ࡷࡪឨ"))
					if CC4UDLW6brf(u"ࠩࡖࡧࡷࡧࡰࡦ࠰ࡧࡳ࠲ࡘࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧ࠮ࡅࡵࡩࡩ࡯ࡴࡴࠩድ") in list(pfvg1xiojJZXWPw.headers.keys()):
						XXPcCawKlqv6e4E = pfvg1xiojJZXWPw.headers[tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡗࡨࡸࡡࡱࡧ࠱ࡨࡴ࠳ࡒࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨ࠯ࡆࡶࡪࡪࡩࡵࡵࠪዶ")]
						BBwb2NzsHE.setSetting(WfgnOq9Fd4lhMSQpK5(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠵ࠩዷ"),XXPcCawKlqv6e4E)
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==G5TxeI0ND4ztC6(u"࠸ᜉ"):
					Ez8q25FZGyQvk47oeVDKmTfPY3sc6 = KylMx0kfTOrG(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷ࡣ࠴ࡦ࠶ࡥࡪ࠷࠸࠶ࡦࡩ࠸ࡧ࡬࠶ࡢࡨ࠸࠷࠸ࡩ࠷࠱࠶࠳ࡦ࠸࠺࠷ࡤ࠻ࡨ࠽࠾ࡨࡥ࠵࠸࠹ࡥࡪ࠿࠺ࡤࡷࡶࡸࡴࡳࡈࡦࡣࡧࡩࡷࡹ࠽ࡵࡴࡸࡩࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨ࠲ࡩࡵ࠺࠹࠲࠻࠴ࠬዸ")
					XTNUWlZgoH = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ዹ")+Ez8q25FZGyQvk47oeVDKmTfPY3sc6+Wbwj0o5gsXQ8F2f(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧዺ")
					pfvg1xiojJZXWPw = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,A6Iyo7eXrq2RtMmDxWj(u"ࡈࡤࡰࡸ࡫ឩ"),dbBRqLP6WeEV,A6Iyo7eXrq2RtMmDxWj(u"ࡈࡤࡰࡸ࡫ឩ"),A6Iyo7eXrq2RtMmDxWj(u"ࡈࡤࡰࡸ࡫ឩ"))
					if xmTX9Aeidq8cVhY(u"ࠨࡕࡦࡶࡦࡶࡥ࠯ࡦࡲ࠱ࡗ࡫࡭ࡢ࡫ࡱ࡭ࡳ࡭࠭ࡄࡴࡨࡨ࡮ࡺࡳࠨዻ") in list(pfvg1xiojJZXWPw.headers.keys()):
						XXPcCawKlqv6e4E = pfvg1xiojJZXWPw.headers[vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡖࡧࡷࡧࡰࡦ࠰ࡧࡳ࠲ࡘࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧ࠮ࡅࡵࡩࡩ࡯ࡴࡴࠩዼ")]
						BBwb2NzsHE.setSetting(VVtQk9vwe7(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩࡩࡵ࠵ࠨዽ"),XXPcCawKlqv6e4E)
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠽࠾࠿࠳ᜊ"):
					XTNUWlZgoH = oh1JUWa3LdnqTpz5(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴ࠯ࡥࡲࡱ࠴ࡅࡴࡰ࡭ࡨࡲࡂࡧ࠴ࡧ࠹ࡩࡦ࠶࠺࠭࠳ࡦࡨࡪ࠲࠺࠰࠸࠳࠰࠼࠻࠺ࡢ࠮࠴࠵ࡩ࠸࠸࠶࠵ࡦ࠷ࡨࡩࡩࠦࡱࡴࡲࡼࡾࡉ࡯ࡶࡰࡷࡶࡾࡃࡊࡐࠨࡸࡶࡱࡃࠧዾ")+FVsLwz1tAH(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
					pfvg1xiojJZXWPw = IjDgSHxpL2h(CC4UDLW6brf(u"ࠬࡍࡅࡕࠩዿ"),XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,u2NDjURZVHlmdc0(u"ࡉࡥࡱࡹࡥឪ"),u2NDjURZVHlmdc0(u"ࡉࡥࡱࡹࡥឪ"))
					try:
						import json as aYhFKJupNC2ATLlXDqjc1SV6
						pfvg1xiojJZXWPw.content = aYhFKJupNC2ATLlXDqjc1SV6.dumps(pfvg1xiojJZXWPw.content)[uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡲࡦࡵࡸࡰࡹ࠭ጀ")]
					except: pass
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==G5TxeI0ND4ztC6(u"࠾࠿࠹࠲ᜋ"):
					XTNUWlZgoH = G5TxeI0ND4ztC6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴ࠵ࡶ࠲࠱ࡂࡥࡵ࡯࡟࡬ࡧࡼࡁࡧ࠸ࡣ࠳ࡨࡦ࠹࠾࠳࠸ࡧࡦ࠳࠱࠹ࡩ࠲ࡥ࠯࠼࠵࠻ࡩ࠭ࡣࡥ࠺࠷࠼࠿࠸࠱ࡥࡨ࠶ࡦࠬࡵࡳ࡮ࡀࠫጁ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO
					pfvg1xiojJZXWPw = IjDgSHxpL2h(G5TxeI0ND4ztC6(u"ࠨࡉࡈࡘࠬጂ"),XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡊࡦࡲࡳࡦឫ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࡊࡦࡲࡳࡦឫ"))
				elif gOBCEfxDK360Y1sNH2rn4q8hXdm==trSQHvP4aqBWFKxN5bZgXCu(u"࠿࠹࠺࠴ᜌ"):
					XTNUWlZgoH = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠳ࡩ࡯࡮࠱ࡹ࠶࠴࡭ࡥ࡯ࡧࡵࡥࡱࡅࡸ࠮ࡣࡳ࡭࠲ࡱࡥࡺ࠿࠵ࡦ࠸࠺࠰ࡢ࠸࠻࠽࠵ࡧ࠵࠵࠲࠴ࡨࡧࡩ࠳࠸࠴ࡦ࠵࠶࠺࠵ࡥ࠻࠹࠶ࡪ࠾ࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡦࡷࡵࡷࡴࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠩࡹࡷࡲ࠽ࠨጃ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO
					pfvg1xiojJZXWPw = IjDgSHxpL2h(CC4UDLW6brf(u"ࠪࡋࡊ࡚ࠧጄ"),XTNUWlZgoH,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,Vt4ELHXZP6(u"ࡋࡧ࡬ࡴࡧឬ"),Vt4ELHXZP6(u"ࡋࡧ࡬ࡴࡧឬ"))
				jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = pfvg1xiojJZXWPw.code,pfvg1xiojJZXWPw.reason
				if pfvg1xiojJZXWPw.succeeded:
					b6kj4LJ5tzTeOMQi(b46fBrugtPDSYspzMQIx(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪጅ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+WfgnOq9Fd4lhMSQpK5(u"ࠬࠦࠠࡔࡷࡦࡧࡪࡹࡳࠡࡤࡼࡴࡦࡹࡳࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጆ")+dbBRqLP6WeEV+VVtQk9vwe7(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጇ")+XTNUWlZgoH+pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠡ࡟ࠪገ"))
					sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(Yr0wo7FaSHx(u"ࠨ่ฯัࠥอไโฯุࠤฬ๊รๆ่ํࠫጉ"),BFUbt3uhW4kcjVNSHAl0G5eRw,Mrx2OeZV1LNjBsQ58Savi7=A6Iyo7eXrq2RtMmDxWj(u"࠱࠱࠲࠳ᜍ"))
					return pfvg1xiojJZXWPw
				else:
					b6kj4LJ5tzTeOMQi(GVPK9Ziaho6U2ySLj(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨጊ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠤࠥࠦࠠࡇࡣ࡬ࡰࠥࡨࡹࡱࡣࡶࡷࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪጋ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬጌ")+KPW9hQet1aZUu4H2b0lvSi7Rs+b46fBrugtPDSYspzMQIx(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧግ")+dbBRqLP6WeEV+C0CbfZuXJM(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጎ")+XTNUWlZgoH+oh1JUWa3LdnqTpz5(u"ࠧࠡ࡟ࠪጏ"))
					sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(pOIe6U1vWYC7Gh2udFBRgT(u"ࠨใื่ࠥอไโฯุࠤฬ๊รๆ่ํࠫጐ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩฯีอࠦๅาหࠣวำื้ࠨ጑"),Mrx2OeZV1LNjBsQ58Savi7=CC4UDLW6brf(u"࠲࠲࠳࠴ᜎ"))
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = b098bsyjUud(u"࡚ࡲࡶࡧឭ")
		if (v2JEMkx6aPYch45I==vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡅࡘࡑࠧጒ") or GrZvUpxLeXDqCmjfa7KQ==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫࡆ࡙ࡋࠨጓ")) and (c95E6IfsJToNp or hQbrjUIeoFgwOTNk9zYBXlMLR):
			J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = e9ypcP7NajLobFEAdWY8(jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs,dbBRqLP6WeEV,showDialogs)
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 and v2JEMkx6aPYch45I==tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡇࡓࡌࠩጔ"): v2JEMkx6aPYch45I = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨጕ")
			else: v2JEMkx6aPYch45I = vdHRKkIgTp56Je1OuNo(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ጖")
			if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 and GrZvUpxLeXDqCmjfa7KQ==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡃࡖࡏࠬ጗"): GrZvUpxLeXDqCmjfa7KQ = CC4UDLW6brf(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫጘ")
			else: GrZvUpxLeXDqCmjfa7KQ = tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬጙ")
			BBwb2NzsHE.setSetting(pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧጚ"),v2JEMkx6aPYch45I)
			BBwb2NzsHE.setSetting(CC4UDLW6brf(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪጛ"),GrZvUpxLeXDqCmjfa7KQ)
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6:
			ohXUIFHfBApQzWcC1vmrMZ4xd = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡔࡳࡷࡨឮ")
			if jjKUzRlixEhe7vY3BO6TDs5pGZ==NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠺ᜏ") and jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡨࡵࡶࡳࡷࠬጜ") in FrC9LhHZWIySdGwNsuzqt5Rf01TXO and ohXUIFHfBApQzWcC1vmrMZ4xd:
				if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧหใ฼๎้ࠦแฮืุࠣ์อฯสࠢส่ฯฺแ๋ำࠣࡗࡘࡒࠧጝ"),WfgnOq9Fd4lhMSQpK5(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪጞ"),Mrx2OeZV1LNjBsQ58Savi7=trSQHvP4aqBWFKxN5bZgXCu(u"࠵࠴࠵࠶ᜐ"))
				kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+GVPK9Ziaho6U2ySLj(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩጟ")
				M9M2oTiGEk8AYnjmZXzutyxeJU = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,kHWT0XY2S6apruwxiB8FDl1,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,WfgnOq9Fd4lhMSQpK5(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠸ࡶ࡫ࠫጠ"))
				if M9M2oTiGEk8AYnjmZXzutyxeJU.succeeded:
					pmTdyfMuY6I3UQczZ = M9M2oTiGEk8AYnjmZXzutyxeJU
					b6kj4LJ5tzTeOMQi(GVPK9Ziaho6U2ySLj(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪጡ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+b46fBrugtPDSYspzMQIx(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧጢ")+dbBRqLP6WeEV+vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬጣ")+OG9Usa51Nk8D+ebT9xRB63E(u"ࠧࠡ࡟ࠪጤ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨ่ฯหาࠦศศีอาิอๅࠡࡕࡖࡐࠬጥ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫጦ"),Mrx2OeZV1LNjBsQ58Savi7=C0CbfZuXJM(u"࠶࠵࠶࠰ᜑ"))
				else:
					b6kj4LJ5tzTeOMQi(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨጧ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+xmTX9Aeidq8cVhY(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪጨ")+dbBRqLP6WeEV+GVPK9Ziaho6U2ySLj(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫጩ")+OG9Usa51Nk8D+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࠠ࡞ࠩጪ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪጫ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪጬ"),Mrx2OeZV1LNjBsQ58Savi7=KylMx0kfTOrG(u"࠷࠶࠰࠱ᜒ"))
			if not pmTdyfMuY6I3UQczZ.succeeded and GrZvUpxLeXDqCmjfa7KQ in [G5TxeI0ND4ztC6(u"ࠩࡄ࡙࡙ࡕࠧጭ"),cg94WALw5orUhvtHSfNO(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬጮ")] and hQbrjUIeoFgwOTNk9zYBXlMLR:
				if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(GVPK9Ziaho6U2ySLj(u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫጯ"),b098bsyjUud(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጰ"),Mrx2OeZV1LNjBsQ58Savi7=Vt4ELHXZP6(u"࠸࠰࠱࠲ᜓ"))
				M9M2oTiGEk8AYnjmZXzutyxeJU = SGTdH4qP2f1ZxBcA9XMsyWbOm6vVF(DDWGZztREldKorePp6whj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,Vt4ELHXZP6(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠼ࡹ࡮ࠧጱ"))
				if M9M2oTiGEk8AYnjmZXzutyxeJU.succeeded:
					pmTdyfMuY6I3UQczZ = M9M2oTiGEk8AYnjmZXzutyxeJU
					b6kj4LJ5tzTeOMQi(GVPK9Ziaho6U2ySLj(u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭ጲ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࠢࠣࠤࡕࡸ࡯ࡹ࡫ࡨࡷࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨጳ")+dbBRqLP6WeEV+oh1JUWa3LdnqTpz5(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨጴ")+OG9Usa51Nk8D+WfgnOq9Fd4lhMSQpK5(u"ࠪࠤࡢ࠭ጵ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"๋ࠫาวฮࠢึ๎ึ็ัศฬࠣฬึ๎ใิ์ࠪጶ"),Vt4ELHXZP6(u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧጷ"),Mrx2OeZV1LNjBsQ58Savi7=trSQHvP4aqBWFKxN5bZgXCu(u"࠲࠱࠲࠳᜔"))
				else:
					b6kj4LJ5tzTeOMQi(vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫጸ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫጹ")+dbBRqLP6WeEV+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧጺ")+OG9Usa51Nk8D+xmTX9Aeidq8cVhY(u"ࠩࠣࡡࠬጻ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨጼ"),oh1JUWa3LdnqTpz5(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ጽ"),Mrx2OeZV1LNjBsQ58Savi7=pOIe6U1vWYC7Gh2udFBRgT(u"࠳࠲࠳࠴᜕"))
			if not pmTdyfMuY6I3UQczZ.succeeded and v2JEMkx6aPYch45I in [DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡇࡕࡕࡑࠪጾ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨጿ")] and c95E6IfsJToNp:
				if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(pOIe6U1vWYC7Gh2udFBRgT(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩፀ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪፁ"),Mrx2OeZV1LNjBsQ58Savi7=xmTX9Aeidq8cVhY(u"࠴࠳࠴࠵᜖"))
				kHWT0XY2S6apruwxiB8FDl1 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧፂ")
				M9M2oTiGEk8AYnjmZXzutyxeJU = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,kHWT0XY2S6apruwxiB8FDl1,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,WfgnOq9Fd4lhMSQpK5(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠺ࡶ࡫ࠫፃ"))
				if M9M2oTiGEk8AYnjmZXzutyxeJU.succeeded:
					pmTdyfMuY6I3UQczZ = M9M2oTiGEk8AYnjmZXzutyxeJU
					b6kj4LJ5tzTeOMQi(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪፄ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࠦࠠࠡࡆࡑࡗࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬፅ")+ZtTAbOzD0fsJxw8SNcQnr+G5TxeI0ND4ztC6(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨፆ")+dbBRqLP6WeEV+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ፇ")+OG9Usa51Nk8D+KylMx0kfTOrG(u"ࠨࠢࡠࠫፈ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(oh1JUWa3LdnqTpz5(u"้ࠩะฬำࠠิ์ิๅึࠦࡄࡏࡕࠪፉ"),Yr0wo7FaSHx(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬፊ"),Mrx2OeZV1LNjBsQ58Savi7=Yr0wo7FaSHx(u"࠵࠴࠵࠶᜗"))
				else:
					b6kj4LJ5tzTeOMQi(tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩፋ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+vdHRKkIgTp56Je1OuNo(u"ࠬࠦࠠࠡࡆࡑࡗࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩፌ")+ZtTAbOzD0fsJxw8SNcQnr+pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨፍ")+dbBRqLP6WeEV+GVPK9Ziaho6U2ySLj(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ፎ")+OG9Usa51Nk8D+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࠢࡠࠫፏ"))
					if showDialogs: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(vlW6K1g8Xo35mPYbyO2GS(u"ࠩไุ้ࠦำ๋ำไีࠥࡊࡎࡔࠩፐ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬፑ"),Mrx2OeZV1LNjBsQ58Savi7=pOIe6U1vWYC7Gh2udFBRgT(u"࠶࠵࠶࠰᜘"))
		if GrZvUpxLeXDqCmjfa7KQ==CC4UDLW6brf(u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭ፒ") or v2JEMkx6aPYch45I==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧፓ"): showDialogs = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࡇࡣ࡯ࡷࡪឯ")
		if not pmTdyfMuY6I3UQczZ.succeeded:
			if showDialogs: w3xgzAeHjEkDrIZ1 = e9ypcP7NajLobFEAdWY8(jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs,dbBRqLP6WeEV,showDialogs)
			if jjKUzRlixEhe7vY3BO6TDs5pGZ!=WfgnOq9Fd4lhMSQpK5(u"࠷࠶࠰᜙") and dbBRqLP6WeEV not in TmeBwNcAQlb7XMau5LgYGrE4fWno2 and u2NDjURZVHlmdc0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪፔ") not in dbBRqLP6WeEV:
				ssIFxhY0K5JUkqicQ8WlbmMBP(VVtQk9vwe7(u"ࠧࡇࡱࡵࡧࡪࡪࠠࡦࡺ࡬ࡸࠥࡪࡵࡦࠢࡷࡳࠥࡴࡥࡵࡹࡲࡶࡰࠦࡩࡴࡵࡸࡩࡸࠦࡷࡪࡶ࡫࠾ࠥ࠭ፕ")+dbBRqLP6WeEV)
	if BBwb2NzsHE.getSetting(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫፖ")) not in [GVPK9Ziaho6U2ySLj(u"ࠩࡄ࡙࡙ࡕࠧፗ"),A6Iyo7eXrq2RtMmDxWj(u"ࠪࡗ࡙ࡕࡐࠨፘ"),Vt4ELHXZP6(u"ࠫࡆ࡙ࡋࠨፙ")]: BBwb2NzsHE.setSetting(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨፚ"),G5TxeI0ND4ztC6(u"࠭ࡁࡔࡍࠪ፛"))
	if BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ፜")) not in [xmTX9Aeidq8cVhY(u"ࠨࡃࡘࡘࡔ࠭፝"),C0CbfZuXJM(u"ࠩࡖࡘࡔࡖࠧ፞"),G5TxeI0ND4ztC6(u"ࠪࡅࡘࡑࠧ፟")]: BBwb2NzsHE.setSetting(GVPK9Ziaho6U2ySLj(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ፠"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡇࡓࡌࠩ፡"))
	return pmTdyfMuY6I3UQczZ
def zibnBvFtmwKplXrg(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,c95E6IfsJToNp=CC4UDLW6brf(u"࠭ࠧ።"),hQbrjUIeoFgwOTNk9zYBXlMLR=YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠨ፣")):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,IIgPFWErkX,NI89n26cvktE7V4,KrD3nScWfvLwJojkZTu9ps = eKNp5b4tm03jz(OG9Usa51Nk8D)
	oTCvBQL2ae = DDWGZztREldKorePp6whj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU
	if pD0N4f87P5daEltjisJTCZUHKe:
		QBDjIUdSiR = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,xmTX9Aeidq8cVhY(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ፤"),vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ፥"),oTCvBQL2ae)
		if QBDjIUdSiR.succeeded:
			gAcRrfHSDhJUKqPXF(oh1JUWa3LdnqTpz5(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪ፦"),FrC9LhHZWIySdGwNsuzqt5Rf01TXO,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV,DDWGZztREldKorePp6whj3)
			return QBDjIUdSiR
	QBDjIUdSiR = IjDgSHxpL2h(DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,mrYgMl8P6NU,showDialogs,dbBRqLP6WeEV,c95E6IfsJToNp,hQbrjUIeoFgwOTNk9zYBXlMLR)
	if QBDjIUdSiR.succeeded:
		if vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ፧") in dbBRqLP6WeEV: QBDjIUdSiR.content = lZVqvuJG40hwcXFIdeiP(QBDjIUdSiR.content)
		if QBDjIUdSiR.scrape: pD0N4f87P5daEltjisJTCZUHKe = UHnG2wYuIQWKN38B4
		if pD0N4f87P5daEltjisJTCZUHKe: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,KylMx0kfTOrG(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ፨"),oTCvBQL2ae,QBDjIUdSiR,pD0N4f87P5daEltjisJTCZUHKe)
	return QBDjIUdSiR
def c6ZsDfYqVo(pD0N4f87P5daEltjisJTCZUHKe,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,showDialogs,dbBRqLP6WeEV):
	if not kOfDHhMnuAxQoBpWTeL or isinstance(kOfDHhMnuAxQoBpWTeL,dict): DDWGZztREldKorePp6whj3 = b46fBrugtPDSYspzMQIx(u"࠭ࡇࡆࡖࠪ፩")
	else:
		DDWGZztREldKorePp6whj3 = pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡑࡑࡖࡘࠬ፪")
		kOfDHhMnuAxQoBpWTeL = i35i6al7upCAreLFQ(kOfDHhMnuAxQoBpWTeL)
		xdOLkt0Vhq8lRoHjWYEImiN2pC3Xu,kOfDHhMnuAxQoBpWTeL = p2gG9rDHAXb7lYPvcMTa(kOfDHhMnuAxQoBpWTeL)
	QBDjIUdSiR = zibnBvFtmwKplXrg(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,Vt4ELHXZP6(u"ࡖࡵࡹࡪឰ"),showDialogs,dbBRqLP6WeEV)
	TMq6SKsGo5muadx = QBDjIUdSiR.content
	TMq6SKsGo5muadx = str(TMq6SKsGo5muadx)
	return TMq6SKsGo5muadx
def eKNp5b4tm03jz(OG9Usa51Nk8D):
	fDyGz4CgNeVFrvuPmdTisE = OG9Usa51Nk8D.split(cg94WALw5orUhvtHSfNO(u"ࠨࡾࡿࠫ፫"))
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,IIgPFWErkX,NI89n26cvktE7V4,KrD3nScWfvLwJojkZTu9ps = fDyGz4CgNeVFrvuPmdTisE[b46fBrugtPDSYspzMQIx(u"࠶᜚")],None,None,cg94WALw5orUhvtHSfNO(u"ࡗࡶࡺ࡫ឱ")
	for oTCvBQL2ae in fDyGz4CgNeVFrvuPmdTisE:
		if oh1JUWa3LdnqTpz5(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ፬") in oTCvBQL2ae: IIgPFWErkX = oTCvBQL2ae[vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠱࠲᜛"):]
		elif b098bsyjUud(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭፭") in oTCvBQL2ae: NI89n26cvktE7V4 = oTCvBQL2ae[tvdQHb10PhNmuy6(u"࠺᜜"):]
		elif CC4UDLW6brf(u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩ፮") in oTCvBQL2ae: KrD3nScWfvLwJojkZTu9ps = VVtQk9vwe7(u"ࡊࡦࡲࡳࡦឲ")
	return FrC9LhHZWIySdGwNsuzqt5Rf01TXO,IIgPFWErkX,NI89n26cvktE7V4,KrD3nScWfvLwJojkZTu9ps
def DDWps8j5MkOtw4JXG2nxVrE7g(q9fpxUJbiKc6us4):
	kkOFYxXLCf9I8H,HLAhjNIVMFonqi5zg2aQlpyfRKBrm,KDetvcCXNsVSglQz = oh1JUWa3LdnqTpz5(u"ࠬ࠭፯"),WfgnOq9Fd4lhMSQpK5(u"࠭ࠧ፰"),vdHRKkIgTp56Je1OuNo(u"ࠧࠨ፱")
	q9fpxUJbiKc6us4 = q9fpxUJbiKc6us4.replace(ccdMiA5sZ0koIRwpFgeU8j,Vt4ELHXZP6(u"ࠨࠩ፲")).replace(SBPbYXN9Rt2MHDrnU4mhlV0,pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࠪ፳"))
	QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall(pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࠬ࠳࠯࡜࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡞ࡠࠬࡡࡽ࡜ࡸ࡞ࡺ࠭ࠥ࠱࡜࡜࡞࠲ࡇࡔࡒࡏࡓ࡞ࡠࠬ࠳࠰࠿ࠪࠦࠪ፴"),q9fpxUJbiKc6us4,JJDtX1PZyIgN2T.DOTALL)
	if QF4KdRaN2q0: kkOFYxXLCf9I8H,HLAhjNIVMFonqi5zg2aQlpyfRKBrm,q9fpxUJbiKc6us4 = QF4KdRaN2q0[Vt4ELHXZP6(u"࠲᜝")]
	if kkOFYxXLCf9I8H not in [tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠥ࠭፵"),CC4UDLW6brf(u"ࠬ࠲ࠧ፶"),oh1JUWa3LdnqTpz5(u"࠭ࠧ፷")]: KDetvcCXNsVSglQz = b098bsyjUud(u"ࠧࡠࡏࡒࡈࡤ࠭፸")
	if HLAhjNIVMFonqi5zg2aQlpyfRKBrm: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡡࠪ፹")+HLAhjNIVMFonqi5zg2aQlpyfRKBrm+ebT9xRB63E(u"ࠩࡢࠫ፺")
	q9fpxUJbiKc6us4 = HLAhjNIVMFonqi5zg2aQlpyfRKBrm+KDetvcCXNsVSglQz+q9fpxUJbiKc6us4
	return q9fpxUJbiKc6us4
def h7px9MIDvPwgZ2U6CNbT(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,vzaF4Q7CwOKJ3XueGPAjrs,cWLDGyOqjdEgCT3KrImBH,nnJFjXg3T5uZz,QOZAYj8g6yaqhl=b098bsyjUud(u"ࠪࠫ፻")):
	Y3N1GDoru9aqFeRLPBypnbQklW = OfTKisDR0Lv(OG9Usa51Nk8D,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡺࡸ࡬ࠨ፼"))
	BAXH3PZ6Fimv1asSEd = BBwb2NzsHE.getSetting(cg94WALw5orUhvtHSfNO(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ፽")+vzaF4Q7CwOKJ3XueGPAjrs)
	if Y3N1GDoru9aqFeRLPBypnbQklW==BAXH3PZ6Fimv1asSEd: BBwb2NzsHE.setSetting(A6Iyo7eXrq2RtMmDxWj(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨ፾")+vzaF4Q7CwOKJ3XueGPAjrs,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠨ፿"))
	if BAXH3PZ6Fimv1asSEd: kHWT0XY2S6apruwxiB8FDl1 = OG9Usa51Nk8D.replace(Y3N1GDoru9aqFeRLPBypnbQklW,BAXH3PZ6Fimv1asSEd)
	else:
		kHWT0XY2S6apruwxiB8FDl1 = OG9Usa51Nk8D
		BAXH3PZ6Fimv1asSEd = Y3N1GDoru9aqFeRLPBypnbQklW
	M9M2oTiGEk8AYnjmZXzutyxeJU = zibnBvFtmwKplXrg(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,kHWT0XY2S6apruwxiB8FDl1,vlW6K1g8Xo35mPYbyO2GS(u"ࠨࠩᎀ"),QOZAYj8g6yaqhl,pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࠪᎁ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫᎂ"),VVtQk9vwe7(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨᎃ"))
	TMq6SKsGo5muadx = M9M2oTiGEk8AYnjmZXzutyxeJU.content
	if DQfHadYvTpy1UR:
		try: TMq6SKsGo5muadx = TMq6SKsGo5muadx.decode(pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡻࡴࡧ࠺ࠪᎄ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᎅ"))
		except: pass
	jjKUzRlixEhe7vY3BO6TDs5pGZ = M9M2oTiGEk8AYnjmZXzutyxeJU.code
	if jjKUzRlixEhe7vY3BO6TDs5pGZ!=-YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠵᜞") and (not M9M2oTiGEk8AYnjmZXzutyxeJU.succeeded or nnJFjXg3T5uZz not in TMq6SKsGo5muadx):
		cWLDGyOqjdEgCT3KrImBH = cWLDGyOqjdEgCT3KrImBH.replace(b46fBrugtPDSYspzMQIx(u"ࠧࠡࠩᎆ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࠭ࠪᎇ"))
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = Vt4ELHXZP6(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧᎈ")+cWLDGyOqjdEgCT3KrImBH
		JZP07kjvbV = {C0CbfZuXJM(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᎉ"):mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࠬᎊ")}
		pmTdyfMuY6I3UQczZ = zibnBvFtmwKplXrg(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬ࠭ᎋ"),JZP07kjvbV,cg94WALw5orUhvtHSfNO(u"࠭ࠧᎌ"),GVPK9Ziaho6U2ySLj(u"ࠧࠨᎍ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠴ࡱࡨࠬᎎ"))
		if pmTdyfMuY6I3UQczZ.succeeded:
			TMq6SKsGo5muadx = pmTdyfMuY6I3UQczZ.content
			if DQfHadYvTpy1UR:
				try: TMq6SKsGo5muadx = TMq6SKsGo5muadx.decode(xmTX9Aeidq8cVhY(u"ࠩࡸࡸ࡫࠾ࠧᎏ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ᎐"))
				except: pass
			kwqYoF8han = JJDtX1PZyIgN2T.findall(b098bsyjUud(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬ᎑"),TMq6SKsGo5muadx,JJDtX1PZyIgN2T.DOTALL)
			jXUhpy1ofDzvRiGZKT = [BAXH3PZ6Fimv1asSEd]
			XeZtw6mzogp4s1 = [b098bsyjUud(u"ࠬࡧࡰ࡬ࠩ᎒"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡧࡰࡱࡪࡰࡪ࠭᎓"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨ᎔"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ᎕"),VVtQk9vwe7(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫ᎖"),G5TxeI0ND4ztC6(u"ࠪࡴ࡭ࡶࠧ᎗"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡦࡺ࡬ࡢࡳࠪ᎘"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪ᎙"),Yr0wo7FaSHx(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭᎚"),vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩ᎛"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪ᎜"),oh1JUWa3LdnqTpz5(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫ᎝"),vdHRKkIgTp56Je1OuNo(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭᎞"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭᎟"),vdHRKkIgTp56Je1OuNo(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩᎠ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩᎡ")]
			for XvmKMQ7UWwFtBT5AVGcHipxI4j in kwqYoF8han:
				if any(Y3YqSmycrIWksoH5N0MvC in XvmKMQ7UWwFtBT5AVGcHipxI4j for Y3YqSmycrIWksoH5N0MvC in XeZtw6mzogp4s1): continue
				BAXH3PZ6Fimv1asSEd = OfTKisDR0Lv(XvmKMQ7UWwFtBT5AVGcHipxI4j,xmTX9Aeidq8cVhY(u"ࠧࡶࡴ࡯ࠫᎢ"))
				if BAXH3PZ6Fimv1asSEd in jXUhpy1ofDzvRiGZKT: continue
				if len(jXUhpy1ofDzvRiGZKT)==vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠽ᜟ"):
					b6kj4LJ5tzTeOMQi(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭Ꭳ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡦࡪࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩᎤ")+vzaF4Q7CwOKJ3XueGPAjrs+Vt4ELHXZP6(u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨᎥ")+Y3N1GDoru9aqFeRLPBypnbQklW+pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࠥࡣࠧᎦ"))
					BBwb2NzsHE.setSetting(ebT9xRB63E(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧᎧ")+vzaF4Q7CwOKJ3XueGPAjrs,Wbwj0o5gsXQ8F2f(u"࠭ࠧᎨ"))
					break
				jXUhpy1ofDzvRiGZKT.append(BAXH3PZ6Fimv1asSEd)
				kHWT0XY2S6apruwxiB8FDl1 = OG9Usa51Nk8D.replace(Y3N1GDoru9aqFeRLPBypnbQklW,BAXH3PZ6Fimv1asSEd)
				M9M2oTiGEk8AYnjmZXzutyxeJU = zibnBvFtmwKplXrg(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,kHWT0XY2S6apruwxiB8FDl1,xmTX9Aeidq8cVhY(u"ࠧࠨᎩ"),QOZAYj8g6yaqhl,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠩᎪ"),oh1JUWa3LdnqTpz5(u"ࠩࠪᎫ"),ebT9xRB63E(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠷ࡷࡪࠧᎬ"))
				TMq6SKsGo5muadx = M9M2oTiGEk8AYnjmZXzutyxeJU.content
				if M9M2oTiGEk8AYnjmZXzutyxeJU.succeeded and nnJFjXg3T5uZz in TMq6SKsGo5muadx:
					b6kj4LJ5tzTeOMQi(CC4UDLW6brf(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪᎭ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+GVPK9Ziaho6U2ySLj(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡨࡲࡹࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬᎮ")+vzaF4Q7CwOKJ3XueGPAjrs+tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࠠ࡞ࠢࠣࠤࡓ࡫ࡷ࠻ࠢ࡞ࠤࠬᎯ")+BAXH3PZ6Fimv1asSEd+DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠡ࡟ࠣࠤࡔࡲࡤ࠻ࠢ࡞ࠤࠬᎰ")+Y3N1GDoru9aqFeRLPBypnbQklW+VVtQk9vwe7(u"ࠨࠢࡠࠫᎱ"))
					BBwb2NzsHE.setSetting(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᎲ")+vzaF4Q7CwOKJ3XueGPAjrs,BAXH3PZ6Fimv1asSEd)
					break
	return BAXH3PZ6Fimv1asSEd,kHWT0XY2S6apruwxiB8FDl1,M9M2oTiGEk8AYnjmZXzutyxeJU
def kFhAce5Pz1(JJ23NOKSjik1hg8Ts7CXbevYzrQHU):
	iLaR1shtueBpUYfV = {
	 oh1JUWa3LdnqTpz5(u"ࠪࡳࡱࡪࠧᎳ")			:u2NDjURZVHlmdc0(u"ࠫ็ี๊ๆࠩᎴ")
	,ebT9xRB63E(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧᎵ")		:GVPK9Ziaho6U2ySLj(u"࠭ๅห๊ๅๅࠬᎶ")
	,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨᎷ")		:CC4UDLW6brf(u"ࠨ็ไๆํีࠧᎸ")
	,tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡪࡳࡴࡪࠧᎹ")			:KylMx0kfTOrG(u"ࠪะ๏ีࠧᎺ")
	,xmTX9Aeidq8cVhY(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᎻ")		:G5TxeI0ND4ztC6(u"ࠬ็ิๅࠩᎼ")
	,Yr0wo7FaSHx(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ꮍ")		:pOIe6U1vWYC7Gh2udFBRgT(u"ࠧๆฮ็ำࠬᎾ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡸ࡬ࡨࡪࡵࠧᎿ")		:tvdQHb10PhNmuy6(u"ࠩไ๎ิ๐่ࠨᏀ")
	,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࡰ࡮ࡼࡥࠨᏁ")			:NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫ็์วสࠩᏂ")
	,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡧ࡫ࡰࡣࡰࠫᏃ")		:vlW6K1g8Xo35mPYbyO2GS(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้่ฯ๋็ࠪᏄ")
	,tvdQHb10PhNmuy6(u"ࠧࡢ࡭ࡺࡥࡲ࠭Ꮕ")		:trSQHvP4aqBWFKxN5bZgXCu(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬᏆ")
	,vdHRKkIgTp56Je1OuNo(u"ࠩࡤ࡯ࡴࡧ࡭ࡤࡣࡰࠫᏇ")		:Yr0wo7FaSHx(u"้ࠪํู่ࠡลๆ์ฬ๋ࠠไษ่ࠫᏈ")
	,C0CbfZuXJM(u"ࠫࡦࡲࡡࡳࡣࡥࠫᏉ")		:pOIe6U1vWYC7Gh2udFBRgT(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬᏊ")
	,cg94WALw5orUhvtHSfNO(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨᏋ")		:Wbwj0o5gsXQ8F2f(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭Ꮜ")
	,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫᏍ")	:oh1JUWa3LdnqTpz5(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬᏎ")
	,xmTX9Aeidq8cVhY(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬᏏ")		:cg94WALw5orUhvtHSfNO(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨᏐ")
	,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧᏑ")		:DItWNMaLOZ146CubYk8lfAwTy(u"࠭ๅ้ไ฼ࠤ฾ืศࠡๆํ์ุ๋ࠧᏒ")
	,vdHRKkIgTp56Je1OuNo(u"ࠧࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠫᏓ")	:vdHRKkIgTp56Je1OuNo(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢࡹ࡭ࡵ࠭Ꮤ")
	,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫᏕ")		:vJ2Q9gokKptI6YxrhDURClcFOz4(u"้ࠪํู่ࠡษ็ื๏์ๅศࠩᏖ")
	,GVPK9Ziaho6U2ySLj(u"ࠫ࡭࡫࡬ࡢ࡮ࠪᏗ")		:xmTX9Aeidq8cVhY(u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨᏘ")
	,VVtQk9vwe7(u"࠭ࡣࡪ࡯ࡤࡪࡦࡴࡳࠨᏙ")		:oh1JUWa3LdnqTpz5(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣๅฬ์าࠨᏚ")
	,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪᏛ")		:b098bsyjUud(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫᏜ")
	,tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼࠬᏝ")		:WfgnOq9Fd4lhMSQpK5(u"๊ࠫ๎โฺࠢื์ๆࠦๅศๅึࠫᏞ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧᏟ")		:uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ๅ้ไ฼ࠤ฾ืศࠡีํ๎ิ࠭Ꮰ")
	,vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᏡ")		:VVtQk9vwe7(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ๋อ่ࠨᏢ")
	,oh1JUWa3LdnqTpz5(u"ࠩ࡮ࡥࡷࡨࡡ࡭ࡣࡷࡺࠬᏣ")	:A6Iyo7eXrq2RtMmDxWj(u"้ࠪํู่ࠡไ้หฮࠦใาส็หฦ࠭Ꮴ")
	,Vt4ELHXZP6(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᏥ")	:pOIe6U1vWYC7Gh2udFBRgT(u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫᏦ")
	,jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭Ꮷ")		:tvdQHb10PhNmuy6(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧᏨ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨᏩ")		:tjoHEAGv2XkrMBsVfCyp5U(u"่ࠩ์็฿้ࠠ์ࠣื๏๋วࠨᏪ")
	,C0CbfZuXJM(u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬᏫ")		:u2NDjURZVHlmdc0(u"๊ࠫ๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭Ꮼ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠸ࠧᏭ")		:Yr0wo7FaSHx(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ะอๆ๋ࠩᏮ")
	,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡣࡱ࡮ࡶࡦ࠭Ꮿ")		:Yr0wo7FaSHx(u"ࠨ็๋ๆ฾ࠦศไำสࠫᏰ")
	,A6Iyo7eXrq2RtMmDxWj(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫᏱ")		:YSGNpiTt6Xe8qh39ElIoQvjVxc(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫᏲ")
	,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫᏳ")		:Wbwj0o5gsXQ8F2f(u"๋ࠬไโࠩᏴ")
	,G5TxeI0ND4ztC6(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧᏵ")		:C0CbfZuXJM(u"ࠧๆๆไࠫ᏶")
	,Vt4ELHXZP6(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ᏷")		:Vt4ELHXZP6(u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫᏸ")
	,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭ᏹ")	:NALF8cewsai2lpT1OqICB0bDdVWrQ(u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩᏺ")
	,u2NDjURZVHlmdc0(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ᏻ")		:ebT9xRB63E(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧᏼ")
	,trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩᏽ")		:oh1JUWa3LdnqTpz5(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫ᏾")
	,b098bsyjUud(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫ᏿")		:G5TxeI0ND4ztC6(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭᐀")
	,tvdQHb10PhNmuy6(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ᐁ")		:tjoHEAGv2XkrMBsVfCyp5U(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨᐂ")
	,ebT9xRB63E(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨᐃ")		:WfgnOq9Fd4lhMSQpK5(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪᐄ")
	,trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡥ࡬ࡱࡦ࠺ࡵࠨᐅ")		:VVtQk9vwe7(u"่ࠩ์็฿ࠠิ์่หࠥ็่า์๋ࠫᐆ")
	,WfgnOq9Fd4lhMSQpK5(u"ࠪࡩ࡬ࡿ࡮ࡰࡹࠪᐇ")		:Yr0wo7FaSHx(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠ็ษ๋ࠫᐈ")
	,hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭ᐉ")		:vdHRKkIgTp56Je1OuNo(u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭ᐊ")
	,WfgnOq9Fd4lhMSQpK5(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩᐋ")		:uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨᐌ")
	,CC4UDLW6brf(u"ࠩ࡯ࡳࡩࡿ࡮ࡦࡶࠪᐍ")		:mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"้ࠪํู่ࠡๆ๋ำ๏ࠦๆหࠩᐎ")
	,cg94WALw5orUhvtHSfNO(u"ࠫࡹࡼࡦࡶࡰࠪᐏ")		:NALF8cewsai2lpT1OqICB0bDdVWrQ(u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬᐐ")
	,KylMx0kfTOrG(u"࠭ࡣࡪ࡯ࡤࡰ࡮࡭ࡨࡵࠩᐑ")	:Vt4ELHXZP6(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ่ࠣฬ๐สࠨᐒ")
	,xmTX9Aeidq8cVhY(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࡯ࡧࡺࡷࠬᐓ")	:oh1JUWa3LdnqTpz5(u"่ࠩ์็฿ࠠีษ๊ำࠥ์๊้ิࠪᐔ")
	,Wbwj0o5gsXQ8F2f(u"ࠪࡪࡴࡹࡴࡢࠩᐕ")		:DItWNMaLOZ146CubYk8lfAwTy(u"๊ࠫ๎โฺࠢไ์ุะวࠨᐖ")
	,oh1JUWa3LdnqTpz5(u"ࠬࡧࡨࡸࡣ࡮ࠫᐗ")		:CC4UDLW6brf(u"࠭ๅ้ไ฼ࠤศํ่ศๅࠣฮ๏็๊ࠨᐘ")
	,A6Iyo7eXrq2RtMmDxWj(u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨᐙ")		:uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨ็๋ๆ฾ࠦแษำๆอࠬᐚ")
	,oh1JUWa3LdnqTpz5(u"ࠩࡦ࡭ࡲࡧࡣ࡭ࡷࡥࡻࡴࡸ࡫ࠨᐛ")	:b098bsyjUud(u"้ࠪํู่ࠡีํ้ฬࠦใๅ๊หࠤ฾๋ไࠨᐜ")
	,vdHRKkIgTp56Je1OuNo(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ᐝ")		:b098bsyjUud(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ᐞ")
	,vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭ᐟ")		:trSQHvP4aqBWFKxN5bZgXCu(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩᐠ")
	,tvdQHb10PhNmuy6(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨᐡ")		:ebT9xRB63E(u"่ࠩ์็฿ࠠษำึฮ๏าࠧᐢ")
	,b098bsyjUud(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫᐣ")		:trSQHvP4aqBWFKxN5bZgXCu(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫᐤ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡲࡡࡳࡱࡽࡥࠬᐥ")		:Wbwj0o5gsXQ8F2f(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫᐦ")
	,C0CbfZuXJM(u"ࠧࡺࡣࡴࡳࡹ࠭ᐧ")		:pOIe6U1vWYC7Gh2udFBRgT(u"ࠨ็๋ๆ฾๊ࠦศไ๋ฮࠬᐨ")
	,tvdQHb10PhNmuy6(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫᐩ")		:A6Iyo7eXrq2RtMmDxWj(u"้ࠪํู่ࠡๅอ็ํะࠧᐪ")
	,vdHRKkIgTp56Je1OuNo(u"ࠫࡰࡧࡴ࡬ࡱࡷࡸࡻ࠭ᐫ")		:Yr0wo7FaSHx(u"๋่ࠬใ฻ࠣ็ฯ้่หࠢอ๎ๆ๐ࠧᐬ")
	,GVPK9Ziaho6U2ySLj(u"࠭ࡡࡳࡣࡥ࡭ࡨࡺ࡯ࡰࡰࡶࠫᐭ")	:trSQHvP4aqBWFKxN5bZgXCu(u"ࠧๆ๊ๅ฽ࠥะ่็ิࠣ฽ึฮ๊สࠩᐮ")
	,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡦࡵࡥࡲࡧࡳ࠸ࠩᐯ")		:Vt4ELHXZP6(u"่ࠩ์็฿ࠠะำส้ฬࠦีฮࠩᐰ")
	,ebT9xRB63E(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬᐱ")		:uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"๊ࠫ๎โฺࠢื์ๆࠦศา๊ࠪᐲ")
	,DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࡯ࡦࡪ࡮ࡰࠫᐳ")				:ebT9xRB63E(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪᐴ")
	,pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠭ᐵ")			:cg94WALw5orUhvtHSfNO(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪᐶ")
	,u2NDjURZVHlmdc0(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡧࡱ࡫ࡱ࡯ࡳࡩࠩᐷ")		:NALF8cewsai2lpT1OqICB0bDdVWrQ(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨᐸ")
	,GVPK9Ziaho6U2ySLj(u"ࠫࡵࡧ࡮ࡦࡶࠪᐹ")				:trSQHvP4aqBWFKxN5bZgXCu(u"๋่ࠬใ฻ࠣฬฬ์๊หࠩᐺ")
	,A6Iyo7eXrq2RtMmDxWj(u"࠭ࡰࡢࡰࡨࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᐻ")			:hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤฬ็ไศ็ࠪᐼ")
	,vdHRKkIgTp56Je1OuNo(u"ࠨࡲࡤࡲࡪࡺ࠭ࡴࡧࡵ࡭ࡪࡹࠧᐽ")			:u2NDjURZVHlmdc0(u"่ࠩ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧᐾ")
	,CC4UDLW6brf(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᐿ")				:pOIe6U1vWYC7Gh2udFBRgT(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩᑀ")
	,Vt4ELHXZP6(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ᑁ")		:vlW6K1g8Xo35mPYbyO2GS(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ᑂ")
	,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᑃ")	:vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬᑄ")
	,KylMx0kfTOrG(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᑅ")		:CC4UDLW6brf(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡไ้์ฬะࠧᑆ")
	,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧᑇ")			:CC4UDLW6brf(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧᑈ")
	,Wbwj0o5gsXQ8F2f(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡳࡩࡷࡹ࡯࡯ࡵࠪᑉ")	:b46fBrugtPDSYspzMQIx(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢๅหึฬࠧᑊ")
	,ebT9xRB63E(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡲࡢࡶ࡯ࡶࠫᑋ")		:trSQHvP4aqBWFKxN5bZgXCu(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฬ๊ศ้็ࠪᑌ")
	,vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡡࡶࡦ࡬ࡳࡸ࠭ᑍ")		:jmhU85aovOS1GxqKBn2RICXgQJ6T(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭ᑎ")
	,WfgnOq9Fd4lhMSQpK5(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪᑏ")			:A6Iyo7eXrq2RtMmDxWj(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧᑐ")
	,oh1JUWa3LdnqTpz5(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡼࡩࡥࡧࡲࡷࠬᑑ")	:pOIe6U1vWYC7Gh2udFBRgT(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫᑒ")
	,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪᑓ"):A6Iyo7eXrq2RtMmDxWj(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪᑔ")
	,Wbwj0o5gsXQ8F2f(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᑕ")	:mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦโ็๊สฮࠬᑖ")
	,trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡹࡵࡰࡪࡥࡶࠫᑗ")	:KylMx0kfTOrG(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡ็๋ห฻๐ูࠨᑘ")
	,G5TxeI0ND4ztC6(u"ࠨ࡫ࡳࡸࡻ࠭ᑙ")					:tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࡌࡔ࡙࡜ࠧᑚ")
	,tjoHEAGv2XkrMBsVfCyp5U(u"ࠪ࡭ࡵࡺࡶ࠮࡮࡬ࡺࡪ࠭ᑛ")			:tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡎࡖࡔࡗࠢๅ๊ํอสࠨᑜ")
	,xmTX9Aeidq8cVhY(u"ࠬ࡯ࡰࡵࡸ࠰ࡱࡴࡼࡩࡦࡵࠪᑝ")			:DItWNMaLOZ146CubYk8lfAwTy(u"࠭ࡉࡑࡖ࡙ࠤศ็ไศ็ࠪᑞ")
	,A6Iyo7eXrq2RtMmDxWj(u"ࠧࡪࡲࡷࡺ࠲ࡹࡥࡳ࡫ࡨࡷࠬᑟ")			:ebT9xRB63E(u"ࠨࡋࡓࡘ࡛ࠦๅิๆึ่ฬะࠧᑠ")
	,GVPK9Ziaho6U2ySLj(u"ࠩࡰ࠷ࡺ࠭ᑡ")					:vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡑ࠸࡛ࠧᑢ")
	,tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡲ࠹ࡵ࠮࡮࡬ࡺࡪ࠭ᑣ")				:oh1JUWa3LdnqTpz5(u"ࠬࡓ࠳ࡖࠢๅ๊ํอสࠨᑤ")
	,VVtQk9vwe7(u"࠭࡭࠴ࡷ࠰ࡱࡴࡼࡩࡦࡵࠪᑥ")			:vdHRKkIgTp56Je1OuNo(u"ࠧࡎ࠵ࡘࠤศ็ไศ็ࠪᑦ")
	,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨ࡯࠶ࡹ࠲ࡹࡥࡳ࡫ࡨࡷࠬᑧ")			:xmTX9Aeidq8cVhY(u"ࠩࡐ࠷࡚ࠦๅิๆึ่ฬะࠧᑨ")
	}
	try: xJhY7dQvaLoFCkGB0e4ZsEp6PSH = iLaR1shtueBpUYfV[JJ23NOKSjik1hg8Ts7CXbevYzrQHU.lower()]
	except: xJhY7dQvaLoFCkGB0e4ZsEp6PSH = ebT9xRB63E(u"ࠪࠫᑩ")
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def ssIFxhY0K5JUkqicQ8WlbmMBP(hiDXjZaexOEKBd3U=trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬᑪ")):
	pkUwtxcrGZDAyEn0SN9d6KRbugXY()
	if not hiDXjZaexOEKBd3U: hiDXjZaexOEKBd3U = vlW6K1g8Xo35mPYbyO2GS(u"ࠬࡌ࡯ࡳࡥࡨࡨࠥࡋࡸࡪࡶࠪᑫ")
	b6kj4LJ5tzTeOMQi(WfgnOq9Fd4lhMSQpK5(u"࠭ࠧᑬ"),WfgnOq9Fd4lhMSQpK5(u"ࠧ࡝ࡰࠪᑭ")+hiDXjZaexOEKBd3U+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨ࡞ࡱࠫᑮ"))
	try: uea9JUBOMcEfh8CN0v6b.exit()
	except: pass
	return
def FVsLwz1tAH(OG9Usa51Nk8D,KriDeOF4B6XMCRlpTxAPnqV=G5TxeI0ND4ztC6(u"ࠩ࠽࠳ࠬᑯ")):
	return _REqFlICrt94s0(OG9Usa51Nk8D,KriDeOF4B6XMCRlpTxAPnqV)
def IijJBnuUOE(wv7hlIgB05LTsGduAVHWDQ1f):
	if wv7hlIgB05LTsGduAVHWDQ1f in [uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠫᑰ"),C0CbfZuXJM(u"ࠫ࠵࠭ᑱ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠵ᜠ")]: return NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠭ᑲ")
	wv7hlIgB05LTsGduAVHWDQ1f = int(wv7hlIgB05LTsGduAVHWDQ1f)
	DG5sIbTFVgK63BhCcPYrizmHp = wv7hlIgB05LTsGduAVHWDQ1f^UHnG2wYuIQWKN38B4
	gikH8RuELbnmrCD = wv7hlIgB05LTsGduAVHWDQ1f^DkRgFyVIBM85OA
	JhSjlfyTvCVRKo9u4ZP5Bzk = wv7hlIgB05LTsGduAVHWDQ1f^mjBa0HgvKnI4oWRd
	xJhY7dQvaLoFCkGB0e4ZsEp6PSH = str(DG5sIbTFVgK63BhCcPYrizmHp)+str(gikH8RuELbnmrCD)+str(JhSjlfyTvCVRKo9u4ZP5Bzk)
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def v5Nq4MOgebKABCzFlJHjoLiRt(wv7hlIgB05LTsGduAVHWDQ1f):
	if wv7hlIgB05LTsGduAVHWDQ1f in [cg94WALw5orUhvtHSfNO(u"࠭ࠧᑳ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠧ࠱ࠩᑴ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠶ᜡ")]: return KylMx0kfTOrG(u"ࠨࠩᑵ")
	wv7hlIgB05LTsGduAVHWDQ1f = str(wv7hlIgB05LTsGduAVHWDQ1f)
	xJhY7dQvaLoFCkGB0e4ZsEp6PSH = ebT9xRB63E(u"ࠩࠪᑶ")
	if len(wv7hlIgB05LTsGduAVHWDQ1f)==tjoHEAGv2XkrMBsVfCyp5U(u"࠱࠶ᜢ"):
		DG5sIbTFVgK63BhCcPYrizmHp,gikH8RuELbnmrCD,JhSjlfyTvCVRKo9u4ZP5Bzk = wv7hlIgB05LTsGduAVHWDQ1f[cg94WALw5orUhvtHSfNO(u"࠲ᜤ"):mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷ᜥ")],wv7hlIgB05LTsGduAVHWDQ1f[mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠷ᜥ"):u2NDjURZVHlmdc0(u"࠺ᜣ")],wv7hlIgB05LTsGduAVHWDQ1f[u2NDjURZVHlmdc0(u"࠺ᜣ"):]
		DG5sIbTFVgK63BhCcPYrizmHp = int(DG5sIbTFVgK63BhCcPYrizmHp)^mjBa0HgvKnI4oWRd
		gikH8RuELbnmrCD = int(gikH8RuELbnmrCD)^DkRgFyVIBM85OA
		JhSjlfyTvCVRKo9u4ZP5Bzk = int(JhSjlfyTvCVRKo9u4ZP5Bzk)^UHnG2wYuIQWKN38B4
		if DG5sIbTFVgK63BhCcPYrizmHp==gikH8RuELbnmrCD==JhSjlfyTvCVRKo9u4ZP5Bzk: xJhY7dQvaLoFCkGB0e4ZsEp6PSH = str(DG5sIbTFVgK63BhCcPYrizmHp*mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠺࠵ᜦ"))
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def QaMk1EXgidcunwJhAPRIWTy5lxHrbj(wv7hlIgB05LTsGduAVHWDQ1f,hZjr7nIoMF=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬᑷ")):
	if wv7hlIgB05LTsGduAVHWDQ1f==trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬᑸ"): return G5TxeI0ND4ztC6(u"ࠬ࠭ᑹ")
	wv7hlIgB05LTsGduAVHWDQ1f = int(wv7hlIgB05LTsGduAVHWDQ1f)+int(hZjr7nIoMF)
	DG5sIbTFVgK63BhCcPYrizmHp = wv7hlIgB05LTsGduAVHWDQ1f^UHnG2wYuIQWKN38B4
	gikH8RuELbnmrCD = wv7hlIgB05LTsGduAVHWDQ1f^DkRgFyVIBM85OA
	JhSjlfyTvCVRKo9u4ZP5Bzk = wv7hlIgB05LTsGduAVHWDQ1f^mjBa0HgvKnI4oWRd
	xJhY7dQvaLoFCkGB0e4ZsEp6PSH = str(DG5sIbTFVgK63BhCcPYrizmHp)+str(gikH8RuELbnmrCD)+str(JhSjlfyTvCVRKo9u4ZP5Bzk)
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def zzkqvb6eSVxXAgUZ0ChptIR3w(wv7hlIgB05LTsGduAVHWDQ1f,hZjr7nIoMF=tvdQHb10PhNmuy6(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᑺ")):
	if wv7hlIgB05LTsGduAVHWDQ1f==G5TxeI0ND4ztC6(u"ࠧࠨᑻ"): return GVPK9Ziaho6U2ySLj(u"ࠨࠩᑼ")
	wv7hlIgB05LTsGduAVHWDQ1f = str(wv7hlIgB05LTsGduAVHWDQ1f)
	NDlGbe7IXhxwHySC6cpTi = int(len(wv7hlIgB05LTsGduAVHWDQ1f)/WfgnOq9Fd4lhMSQpK5(u"࠸ᜧ"))
	DG5sIbTFVgK63BhCcPYrizmHp = int(wv7hlIgB05LTsGduAVHWDQ1f[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠶ᜨ"):NDlGbe7IXhxwHySC6cpTi])^UHnG2wYuIQWKN38B4
	gikH8RuELbnmrCD = int(wv7hlIgB05LTsGduAVHWDQ1f[NDlGbe7IXhxwHySC6cpTi:DItWNMaLOZ146CubYk8lfAwTy(u"࠲ᜩ")*NDlGbe7IXhxwHySC6cpTi])^DkRgFyVIBM85OA
	JhSjlfyTvCVRKo9u4ZP5Bzk = int(wv7hlIgB05LTsGduAVHWDQ1f[A6Iyo7eXrq2RtMmDxWj(u"࠴ᜫ")*NDlGbe7IXhxwHySC6cpTi:uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠴ᜪ")*NDlGbe7IXhxwHySC6cpTi])^mjBa0HgvKnI4oWRd
	xJhY7dQvaLoFCkGB0e4ZsEp6PSH = G5TxeI0ND4ztC6(u"ࠩࠪᑽ")
	if DG5sIbTFVgK63BhCcPYrizmHp==gikH8RuELbnmrCD==JhSjlfyTvCVRKo9u4ZP5Bzk: xJhY7dQvaLoFCkGB0e4ZsEp6PSH = str(int(DG5sIbTFVgK63BhCcPYrizmHp)-int(hZjr7nIoMF))
	return xJhY7dQvaLoFCkGB0e4ZsEp6PSH
def TiKk1hPsEgaBzU2N7Zpmfo(HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz):
	arN0RwTkLpjOEel8ZXs6vz2 = LWzUbE5adDslTXGr[WfgnOq9Fd4lhMSQpK5(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᑾ")][hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠻ᜬ")]
	D4Dd76Y2HOWt8hRcuvZkCeFM = sPgi90KAz7JCOojl(b46fBrugtPDSYspzMQIx(u"࠷࠷ᜭ"))
	wiyt03cqkOC4TvHrJG7AbjS = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,Yr0wo7FaSHx(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧᑿ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬࡹ࡫ࡪࡰࡶࠫᒀ"),KylMx0kfTOrG(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧᒁ"),b46fBrugtPDSYspzMQIx(u"ࠧ࠸࠴࠳ࡴࠬᒂ"),GVPK9Ziaho6U2ySLj(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪᒃ"))
	pADaEw3RgLc,SD5siVcBm4nhMj = eexb5wHNQEphIrs3WCBZjYcoTMu0(wiyt03cqkOC4TvHrJG7AbjS)
	pADaEw3RgLc = QaMk1EXgidcunwJhAPRIWTy5lxHrbj(pADaEw3RgLc,G5TxeI0ND4ztC6(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬᒄ"))
	YYsOVihq6TXZjlEA2w = {xmTX9Aeidq8cVhY(u"ࠪ࡭ࡩࡹࠧᒅ"):uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡉࡏࡁࡍࡑࡊࠫᒆ"),Yr0wo7FaSHx(u"ࠬࡻࡳࡳࠩᒇ"):D4Dd76Y2HOWt8hRcuvZkCeFM,KylMx0kfTOrG(u"࠭ࡶࡦࡴࠪᒈ"):K0dHTfq6P73sD8lWLZpoh,CC4UDLW6brf(u"ࠧࡴࡥࡵࠫᒉ"):HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz,ebT9xRB63E(u"ࠨࡵ࡬ࡾࠬᒊ"):pADaEw3RgLc}
	LDC75zvY0lKjs = {u2NDjURZVHlmdc0(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᒋ"):vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩᒌ")}
	M8zKjR5veow64mcVNr = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,ebT9xRB63E(u"ࠫࡕࡕࡓࡕࠩᒍ"),arN0RwTkLpjOEel8ZXs6vz2,YYsOVihq6TXZjlEA2w,LDC75zvY0lKjs,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬ࠭ᒎ"),Yr0wo7FaSHx(u"࠭ࠧᒏ"),xmTX9Aeidq8cVhY(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡋࡓ࡜ࡥࡐࡍࡃ࡜ࡣࡉࡏࡁࡍࡑࡊ࠱࠶ࡹࡴࠨᒐ"))
	nNsrzav17jfK4OF6bTeZtk8MyxXHhY = M8zKjR5veow64mcVNr.content
	try:
		if not nNsrzav17jfK4OF6bTeZtk8MyxXHhY: Jxstcfz2iQMrETj7heISWDqPKF
		tQ8yMmuDpX09 = G8EwoDOyKShm1i0IHMfNYZlU7(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡦ࡬ࡧࡹ࠭ᒑ"),nNsrzav17jfK4OF6bTeZtk8MyxXHhY)
		ooEiTk6AIROrP = tQ8yMmuDpX09[Vt4ELHXZP6(u"ࠩࡰࡷ࡬࠭ᒒ")]
		t6wL15xPB39eZAJzrg = tQ8yMmuDpX09[cg94WALw5orUhvtHSfNO(u"ࠪࡷࡪࡩࠧᒓ")]
		k6aAN2xCW9Jnz1BjgYh = tQ8yMmuDpX09[WfgnOq9Fd4lhMSQpK5(u"ࠫࡸࡺࡰࠨᒔ")]
		t6wL15xPB39eZAJzrg = int(zzkqvb6eSVxXAgUZ0ChptIR3w(t6wL15xPB39eZAJzrg,u2NDjURZVHlmdc0(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨᒕ")))
		k6aAN2xCW9Jnz1BjgYh = int(zzkqvb6eSVxXAgUZ0ChptIR3w(k6aAN2xCW9Jnz1BjgYh,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩᒖ")))
		for VsXhYJ9G3I in range(t6wL15xPB39eZAJzrg,vlW6K1g8Xo35mPYbyO2GS(u"࠵ᜮ"),-k6aAN2xCW9Jnz1BjgYh):
			if not eval(C0CbfZuXJM(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪᒗ"),{WfgnOq9Fd4lhMSQpK5(u"ࠨࡺࡥࡱࡨ࠭ᒘ"):Wj3qSagkcweAb2prRiDyM0HK7Guo}): Jxstcfz2iQMrETj7heISWDqPKF
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩหห็๐ࠠๅๆอะึฮษ๊ࠡส่ๆำีࠨᒙ"),str(VsXhYJ9G3I)+vlW6K1g8Xo35mPYbyO2GS(u"ࠪࠤࠥัว็์ฬࠫᒚ"),Mrx2OeZV1LNjBsQ58Savi7=uEed4OSxm7hBq9Vvky6QjHwWC(u"࠹࠰࠱ᜯ")*k6aAN2xCW9Jnz1BjgYh)
			Wj3qSagkcweAb2prRiDyM0HK7Guo.sleep(vlW6K1g8Xo35mPYbyO2GS(u"࠱࠱࠲࠳ᜰ")*k6aAN2xCW9Jnz1BjgYh)
		if eval(vlW6K1g8Xo35mPYbyO2GS(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧᒛ"),{b46fBrugtPDSYspzMQIx(u"ࠬࡾࡢ࡮ࡥࠪᒜ"):Wj3qSagkcweAb2prRiDyM0HK7Guo}):
			ooEiTk6AIROrP = ooEiTk6AIROrP.replace(vlW6K1g8Xo35mPYbyO2GS(u"࠭࡜࡯ࠩᒝ"),b46fBrugtPDSYspzMQIx(u"ࠧ࡝࡞ࡱࠫᒞ")).replace(cg94WALw5orUhvtHSfNO(u"ࠨ࡞ࡵࠫᒟ"),Vt4ELHXZP6(u"ࠩ࡟ࡠࡷ࠭ᒠ"))
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(C0CbfZuXJM(u"ࠪࠫᒡ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫำื่อࠩᒢ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᒣ"),ooEiTk6AIROrP)
		Jxstcfz2iQMrETj7heISWDqPKF
	except: exec(trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ᒤ"),{tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࡹࡤࡰࡧࠬᒥ"):Wj3qSagkcweAb2prRiDyM0HK7Guo})
	return
def lfdUPv5WEQ():
	exec(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ᒦ"),{VVtQk9vwe7(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪᒧ"):U6zsmRNGTL,b098bsyjUud(u"ࠪࡼࡧࡳࡣࠨᒨ"):Wj3qSagkcweAb2prRiDyM0HK7Guo})
	return
def eexb5wHNQEphIrs3WCBZjYcoTMu0(wErcn0kLyWxu6JG):
	um2iyPU9LBYMbl4NEIhWjAF8,fKG1iuWHwak9qCml6M7F = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠱ᜱ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠱ᜱ")
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(wErcn0kLyWxu6JG):
		try: um2iyPU9LBYMbl4NEIhWjAF8 = A73K6zLXIgFROeCHJQi0Pbos.path.getsize(wErcn0kLyWxu6JG)
		except: pass
		if not um2iyPU9LBYMbl4NEIhWjAF8:
			try: um2iyPU9LBYMbl4NEIhWjAF8 = A73K6zLXIgFROeCHJQi0Pbos.stat(wErcn0kLyWxu6JG).st_size
			except: pass
		if not um2iyPU9LBYMbl4NEIhWjAF8:
			try:
				from pathlib import Path as RRmV6rGxiLPhS0BoK
				um2iyPU9LBYMbl4NEIhWjAF8 = RRmV6rGxiLPhS0BoK(wErcn0kLyWxu6JG).stat().st_size
			except: pass
		if um2iyPU9LBYMbl4NEIhWjAF8: fKG1iuWHwak9qCml6M7F = Vt4ELHXZP6(u"࠳ᜲ")
	return um2iyPU9LBYMbl4NEIhWjAF8,fKG1iuWHwak9qCml6M7F
def IN1vbO8YfAu05Qyi7jMVwkxSE(FKQi7CSlBo9LGE5VvDOwNcbyjsRqP2,O6UWlJutg3i1danNBKzQGeSbfoIF,showDialogs):
	if showDialogs:
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࠬᒩ"),u2NDjURZVHlmdc0(u"ࠬ࠭ᒪ"),KylMx0kfTOrG(u"࠭ࠧᒫ"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᒬ"),FKQi7CSlBo9LGE5VvDOwNcbyjsRqP2+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨ࡞ࡱࡠࡳ࠭ᒭ")+CC4UDLW6brf(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ์๊ࠠหำํำ๋ࠥำฮ๊ࠢิฬࠦวๅ็ฯ่ิࠦฟࠢ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᒮ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=u2NDjURZVHlmdc0(u"࠴ᜳ"): return
	CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ = tvdQHb10PhNmuy6(u"ࡋࡧ࡬ࡴࡧឳ")
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(FKQi7CSlBo9LGE5VvDOwNcbyjsRqP2):
		for IQhY9WqUXEoCsZaD52b0cKHd1Fy3zP,FGhMSo4KryQCW60nubBf3vJizLYt,G6xvk7zXYPqy4aofmTjRbMCd in A73K6zLXIgFROeCHJQi0Pbos.walk(FKQi7CSlBo9LGE5VvDOwNcbyjsRqP2,topdown=tjoHEAGv2XkrMBsVfCyp5U(u"ࡌࡡ࡭ࡵࡨ឴")):
			for wErcn0kLyWxu6JG in G6xvk7zXYPqy4aofmTjRbMCd:
				Wv36uZm2MoaSTQC = A73K6zLXIgFROeCHJQi0Pbos.path.join(IQhY9WqUXEoCsZaD52b0cKHd1Fy3zP,wErcn0kLyWxu6JG)
				try: A73K6zLXIgFROeCHJQi0Pbos.remove(Wv36uZm2MoaSTQC)
				except Exception as Rs2m41dCIxHrBGwZ9i06DULv:
					if showDialogs and not CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ: ArKbmeZFN7cRuvjfiHBJ0SEqd2l(VVtQk9vwe7(u"ࠪࠫᒯ"),G5TxeI0ND4ztC6(u"ࠫࠬᒰ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᒱ"),str(Rs2m41dCIxHrBGwZ9i06DULv))
					CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ = KylMx0kfTOrG(u"ࡔࡳࡷࡨ឵")
			if O6UWlJutg3i1danNBKzQGeSbfoIF:
				for dir in FGhMSo4KryQCW60nubBf3vJizLYt:
					u7yn9oXPSLOH4fzKlT0 = A73K6zLXIgFROeCHJQi0Pbos.path.join(IQhY9WqUXEoCsZaD52b0cKHd1Fy3zP,dir)
					try: A73K6zLXIgFROeCHJQi0Pbos.rmdir(u7yn9oXPSLOH4fzKlT0)
					except: pass
		if O6UWlJutg3i1danNBKzQGeSbfoIF:
			try: A73K6zLXIgFROeCHJQi0Pbos.rmdir(IQhY9WqUXEoCsZaD52b0cKHd1Fy3zP)
			except: pass
	if showDialogs and not CD6U0VTeFds1pvmxOoRlEk2GQZf9NJ:
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(oh1JUWa3LdnqTpz5(u"࠭ࠧᒲ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࠨᒳ"),C0CbfZuXJM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᒴ"),A6Iyo7eXrq2RtMmDxWj(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪᒵ"))
		BBwb2NzsHE.setSetting(Wbwj0o5gsXQ8F2f(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᒶ"),KylMx0kfTOrG(u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧᒷ"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(vdHRKkIgTp56Je1OuNo(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩᒸ"))
	return
def pkUwtxcrGZDAyEn0SN9d6KRbugXY(n6MNfIpoX7GgJZu=mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࠧᒹ")):
	EYgQHCJOMW98Ps2wf(xmTX9Aeidq8cVhY(u"ࠧࡴࡶࡲࡴࠬᒺ"))
	if n6MNfIpoX7GgJZu:
		bMBAmoLJRjP4SXYV2 = BBwb2NzsHE.getSetting(CC4UDLW6brf(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩᒻ"))
		BBwb2NzsHE.setSetting(GVPK9Ziaho6U2ySLj(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪᒼ"),KylMx0kfTOrG(u"ࠪࠫᒽ"))
		aXQw4TyRhrp(n6MNfIpoX7GgJZu)
		BBwb2NzsHE.setSetting(Yr0wo7FaSHx(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬᒾ"),bMBAmoLJRjP4SXYV2)
	y9sfZeW5tbQpkPHKxg7jDS = BBwb2NzsHE.getSetting(G5TxeI0ND4ztC6(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᒿ"))
	if y9sfZeW5tbQpkPHKxg7jDS==mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠭ࡒࡆࡓࡘࡉࡘ࡚ࡅࡅࠩᓀ"): BBwb2NzsHE.setSetting(tvdQHb10PhNmuy6(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᓁ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡇࡇࠫᓂ"))
	elif y9sfZeW5tbQpkPHKxg7jDS==u2NDjURZVHlmdc0(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬᓃ"): BBwb2NzsHE.setSetting(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᓄ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫࠬᓅ"))
	if BBwb2NzsHE.getSetting(Yr0wo7FaSHx(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᓆ")) not in [hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡁࡖࡖࡒࠫᓇ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡔࡖࡒࡔࠬᓈ"),G5TxeI0ND4ztC6(u"ࠨࡃࡖࡏࠬᓉ")]: BBwb2NzsHE.setSetting(vdHRKkIgTp56Je1OuNo(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᓊ"),A6Iyo7eXrq2RtMmDxWj(u"ࠪࡅࡘࡑࠧᓋ"))
	if BBwb2NzsHE.getSetting(b46fBrugtPDSYspzMQIx(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᓌ")) not in [DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࡇࡕࡕࡑࠪᓍ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡓࡕࡑࡓࠫᓎ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࡂࡕࡎࠫᓏ")]: BBwb2NzsHE.setSetting(oh1JUWa3LdnqTpz5(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᓐ"),G5TxeI0ND4ztC6(u"ࠩࡄࡗࡐ࠭ᓑ"))
	ENCGKc7TSJrn3HFP5B8XUtoD = BBwb2NzsHE.getSetting(pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨᓒ"))
	PPiftToaU4hMWXsuyEgLzd = Wj3qSagkcweAb2prRiDyM0HK7Guo.executeJSONRPC(DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧᓓ"))
	if vdHRKkIgTp56Je1OuNo(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫᓔ") in str(PPiftToaU4hMWXsuyEgLzd) and ENCGKc7TSJrn3HFP5B8XUtoD in [tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩᓕ"),CC4UDLW6brf(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ᓖ")]:
		Mrx2OeZV1LNjBsQ58Savi7.sleep(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠴࠳࠷࠰࠱᜴"))
		Wj3qSagkcweAb2prRiDyM0HK7Guo.executebuiltin(Wbwj0o5gsXQ8F2f(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬᓗ"))
	if KylMx0kfTOrG(u"࠶᜶") and MPBU8HXFoN3Ocj>-tvdQHb10PhNmuy6(u"࠶᜵"):
		wwxkRfBvlShcg72TKtbdyQrniEY.setResolvedUrl(MPBU8HXFoN3Ocj,A6Iyo7eXrq2RtMmDxWj(u"ࡇࡣ࡯ࡷࡪា"),U6zsmRNGTL.ListItem())
		llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq = DItWNMaLOZ146CubYk8lfAwTy(u"ࡈࡤࡰࡸ࡫ិ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡈࡤࡰࡸ࡫ិ"),DItWNMaLOZ146CubYk8lfAwTy(u"ࡈࡤࡰࡸ࡫ិ")
		wwxkRfBvlShcg72TKtbdyQrniEY.endOfDirectory(MPBU8HXFoN3Ocj,llC9WmbrAIgpzfi3n,W1WbMxkGeUlKTZn9yHrdQXNh,gsRxoN3lhI1iKWcTX9muBtyrOjSbq)
	return
def QR0ELrYcPAU1pWZqlgvjFNSxw(pD0N4f87P5daEltjisJTCZUHKe,DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,IIgPFWErkX,NI89n26cvktE7V4,KrD3nScWfvLwJojkZTu9ps = eKNp5b4tm03jz(OG9Usa51Nk8D)
	oTCvBQL2ae = DDWGZztREldKorePp6whj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl
	if pD0N4f87P5daEltjisJTCZUHKe:
		TMq6SKsGo5muadx = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡶࡸࡷ࠭ᓘ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫᓙ"),oTCvBQL2ae)
		if TMq6SKsGo5muadx:
			gAcRrfHSDhJUKqPXF(Vt4ELHXZP6(u"࡚ࠫࡘࡌࡍࡋࡅࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᓚ"),OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV,DDWGZztREldKorePp6whj3)
			return TMq6SKsGo5muadx
	TMq6SKsGo5muadx = D9562M4WoCRwdh7(DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV)
	if TMq6SKsGo5muadx and pD0N4f87P5daEltjisJTCZUHKe: pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,tvdQHb10PhNmuy6(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ᓛ"),oTCvBQL2ae,TMq6SKsGo5muadx,pD0N4f87P5daEltjisJTCZUHKe)
	return TMq6SKsGo5muadx
from R47OMvuKTU import *
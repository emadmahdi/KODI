# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'IFILM'
eMlwAzaLSj8ZEQ3txIGP = '_IFL_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
kHZn1cEVXyGNTRug3 = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][1]
e7dbD8QN5j4V31os2z9y = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][2]
bbeyGRNYpFKumwXt = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][3]
def HYWukw3pL2oMzPK4(mode,url,vYpMA3CxgcyR4VZJh,text):
	if   mode==20: mL7BVKcSygkuoPbWlEF4YD = pp7bT21QJaYeDSkIuGtFxi0KwUWmM()
	elif mode==21: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp(url)
	elif mode==22: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh)
	elif mode==23: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url,vYpMA3CxgcyR4VZJh)
	elif mode==24: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url,text)
	elif mode==25: mL7BVKcSygkuoPbWlEF4YD = kOVvrLibMBoT7lgjw2D9txNRq(url)
	elif mode==27: mL7BVKcSygkuoPbWlEF4YD = r9gtNWGzOuJvZE(url)
	elif mode==28: mL7BVKcSygkuoPbWlEF4YD = XXtBx0FaOKQJ()
	elif mode==29: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def pp7bT21QJaYeDSkIuGtFxi0KwUWmM():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'عربي',kU2ZXSViB3wLANOz8bH,21,'','101')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'English',kHZn1cEVXyGNTRug3,21,'','101')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فارسى',e7dbD8QN5j4V31os2z9y,21,'','101')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فارسى 2',bbeyGRNYpFKumwXt,21,'','101')
	return
def XXtBx0FaOKQJ():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'عربي',kU2ZXSViB3wLANOz8bH,27)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'English',kHZn1cEVXyGNTRug3,27)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'فارسى',e7dbD8QN5j4V31os2z9y,27)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+'فارسى 2',bbeyGRNYpFKumwXt,27)
	return
def UQ8xVqP243HvaWOMtJSp(dsKLYT0keR316XqGBAVmhDfSzvUMcI):
	FpjtBKrnu5SdfyOvEPIQ = dsKLYT0keR316XqGBAVmhDfSzvUMcI
	if dsKLYT0keR316XqGBAVmhDfSzvUMcI=='IFILM-ARABIC': dsKLYT0keR316XqGBAVmhDfSzvUMcI = kU2ZXSViB3wLANOz8bH
	elif dsKLYT0keR316XqGBAVmhDfSzvUMcI=='IFILM-ENGLISH': dsKLYT0keR316XqGBAVmhDfSzvUMcI = kHZn1cEVXyGNTRug3
	else: FpjtBKrnu5SdfyOvEPIQ = ''
	LwmcG8ouzKfY2 = KUtrygGimH(dsKLYT0keR316XqGBAVmhDfSzvUMcI)
	if LwmcG8ouzKfY2=='ar' or FpjtBKrnu5SdfyOvEPIQ=='IFILM-ARABIC':
		rziFwRcYh9xXt26vQCfqlbdgSmAN7s = 'بحث في الموقع'
		GTatBJjWw7qsmAXOv = 'مسلسلات - حالية'
		XUj8uOQAJ6pBCitZ4Te = 'مسلسلات - أحدث'
		dDi1U20mPzO6K7pIacf8ZYC = 'مسلسلات - أبجدي'
		B7V3UKurbwvo81XEy9lN5TzO = 'بث حي آي فيلم'
		MWJRatLHST2D1qcAQEliPV6n = 'أفلام'
		S6aLn0htAwuVBDlk2HRE = 'موسيقى'
		NXgAIxD1ctrQyU49jVs = 'برامج'
	elif LwmcG8ouzKfY2=='en' or FpjtBKrnu5SdfyOvEPIQ=='IFILM-ENGLISH':
		rziFwRcYh9xXt26vQCfqlbdgSmAN7s = 'Search in site'
		GTatBJjWw7qsmAXOv = 'Series - Current'
		XUj8uOQAJ6pBCitZ4Te = 'Series - Latest'
		dDi1U20mPzO6K7pIacf8ZYC = 'Series - Alphabet'
		B7V3UKurbwvo81XEy9lN5TzO = 'Live iFilm channel'
		MWJRatLHST2D1qcAQEliPV6n = 'Movies'
		S6aLn0htAwuVBDlk2HRE = 'Music'
		NXgAIxD1ctrQyU49jVs = 'Shows'
	elif LwmcG8ouzKfY2 in ['fa','fa2']:
		rziFwRcYh9xXt26vQCfqlbdgSmAN7s = 'جستجو در سایت'
		GTatBJjWw7qsmAXOv = 'سريال - جاری'
		XUj8uOQAJ6pBCitZ4Te = 'سريال - آخرین'
		dDi1U20mPzO6K7pIacf8ZYC = 'سريال - الفبا'
		B7V3UKurbwvo81XEy9lN5TzO = 'پخش زنده اي فيلم'
		MWJRatLHST2D1qcAQEliPV6n = 'فيلم'
		S6aLn0htAwuVBDlk2HRE = 'موسيقى'
		NXgAIxD1ctrQyU49jVs = 'برنامه ها'
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+rziFwRcYh9xXt26vQCfqlbdgSmAN7s,dsKLYT0keR316XqGBAVmhDfSzvUMcI,29,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+B7V3UKurbwvo81XEy9lN5TzO,dsKLYT0keR316XqGBAVmhDfSzvUMcI,27)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	D2DlJjSYIrn = ['Series','Program','Music']
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/home','','','','IFILM-MENU-1st')
	GGbRgKaoskDC=JJDtX1PZyIgN2T.findall('button-menu(.*?)/Contact',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if any(Y3YqSmycrIWksoH5N0MvC in wHiSfdBL1v9Kl3n5 for Y3YqSmycrIWksoH5N0MvC in D2DlJjSYIrn):
				url = dsKLYT0keR316XqGBAVmhDfSzvUMcI+wHiSfdBL1v9Kl3n5
				if 'Series' in wHiSfdBL1v9Kl3n5:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,url,22,'','100')
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+XUj8uOQAJ6pBCitZ4Te,url,22,'','101')
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+dDi1U20mPzO6K7pIacf8ZYC,url,22,'','201')
				elif 'Film' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+MWJRatLHST2D1qcAQEliPV6n,url,22,'','100')
				elif 'Music' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+S6aLn0htAwuVBDlk2HRE,url,25,'','101')
				elif 'Program' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+NXgAIxD1ctrQyU49jVs,url,22,'','101')
	return YBEsLq8gVw629cMGQP1T
def kOVvrLibMBoT7lgjw2D9txNRq(url):
	dsKLYT0keR316XqGBAVmhDfSzvUMcI = crYmdBbnu71R5wtap4LATEo6N(url)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'','','','IFILM-MUSIC_MENU-1st')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('Music-tools-header(.*?)Music-body',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	title = JJDtX1PZyIgN2T.findall('<p>(.*?)</p>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)[0]
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,22,'','101')
	items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = dsKLYT0keR316XqGBAVmhDfSzvUMcI + wHiSfdBL1v9Kl3n5
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,23,'','101')
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh):
	dsKLYT0keR316XqGBAVmhDfSzvUMcI = crYmdBbnu71R5wtap4LATEo6N(url)
	LwmcG8ouzKfY2 = KUtrygGimH(url)
	type = url.split('/')[-1]
	DiGugbTfWHZErhKldV7m42 = str(int(vYpMA3CxgcyR4VZJh)//100)
	vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)%100)
	if type=='Series' and vYpMA3CxgcyR4VZJh=='0':
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','IFILM-TITLES-1st')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('serial-body(.*?)class="row',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			wHiSfdBL1v9Kl3n5 = dsKLYT0keR316XqGBAVmhDfSzvUMcI + wHiSfdBL1v9Kl3n5
			ggdRiBo3smurLUGO = dsKLYT0keR316XqGBAVmhDfSzvUMcI + FVsLwz1tAH(ggdRiBo3smurLUGO)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,23,ggdRiBo3smurLUGO,DiGugbTfWHZErhKldV7m42+'01')
	mb72naMO5yPiTHNdGCzIeE=0
	if type=='Series': qGsE8fdyFtUwBnu='3'
	if type=='Film': qGsE8fdyFtUwBnu='5'
	if type=='Program': qGsE8fdyFtUwBnu='7'
	if type in ['Series','Program','Film'] and vYpMA3CxgcyR4VZJh!='0':
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Home/PageingItem?category='+qGsE8fdyFtUwBnu+'&page='+vYpMA3CxgcyR4VZJh+'&size=30&orderby='+DiGugbTfWHZErhKldV7m42
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-TITLES-2nd')
		items = JJDtX1PZyIgN2T.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for id,title,ggdRiBo3smurLUGO in items:
			title = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(title)
			title = title.replace('\\','')
			title = title.replace('"','')
			mb72naMO5yPiTHNdGCzIeE += 1
			wHiSfdBL1v9Kl3n5 = dsKLYT0keR316XqGBAVmhDfSzvUMcI + '/' + type + '/Content/' + id
			ggdRiBo3smurLUGO = dsKLYT0keR316XqGBAVmhDfSzvUMcI + FVsLwz1tAH(ggdRiBo3smurLUGO)
			if type=='Film': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,24,ggdRiBo3smurLUGO,DiGugbTfWHZErhKldV7m42+'01')
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,23,ggdRiBo3smurLUGO,DiGugbTfWHZErhKldV7m42+'01')
	if type=='Music':
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Music/Index?page='+vYpMA3CxgcyR4VZJh,'','','','IFILM-TITLES-3rd')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('pagination-demo(.*?)pagination-demo',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			mb72naMO5yPiTHNdGCzIeE += 1
			ggdRiBo3smurLUGO = dsKLYT0keR316XqGBAVmhDfSzvUMcI + ggdRiBo3smurLUGO
			wHiSfdBL1v9Kl3n5 = dsKLYT0keR316XqGBAVmhDfSzvUMcI + wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,23,ggdRiBo3smurLUGO,'101')
	if mb72naMO5yPiTHNdGCzIeE>20:
		title='صفحة '
		if LwmcG8ouzKfY2=='en': title = 'Page '
		if LwmcG8ouzKfY2=='fa': title = 'صفحه '
		if LwmcG8ouzKfY2=='fa2': title = 'صفحه '
		for RNFwDQWO0k3h4 in range(1,11) :
			if not vYpMA3CxgcyR4VZJh==str(RNFwDQWO0k3h4):
				sS2XM9cxDRT6duO = '0'+str(RNFwDQWO0k3h4)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title+str(RNFwDQWO0k3h4),url,22,'',DiGugbTfWHZErhKldV7m42+sS2XM9cxDRT6duO[-2:])
	return
def sjmSkpqHVtPcv(url,vYpMA3CxgcyR4VZJh):
	if not vYpMA3CxgcyR4VZJh: vYpMA3CxgcyR4VZJh = 0
	dsKLYT0keR316XqGBAVmhDfSzvUMcI = crYmdBbnu71R5wtap4LATEo6N(url)
	WK1Bf5cXpgUmOEl4L0Nd = crYmdBbnu71R5wtap4LATEo6N(url)
	LwmcG8ouzKfY2 = KUtrygGimH(url)
	xxyPKEIGHM75VZcR3S2z0Q = url.split('/')
	id,type = xxyPKEIGHM75VZcR3S2z0Q[-1],xxyPKEIGHM75VZcR3S2z0Q[3]
	DiGugbTfWHZErhKldV7m42 = str(int(vYpMA3CxgcyR4VZJh)//100)
	vYpMA3CxgcyR4VZJh = str(int(vYpMA3CxgcyR4VZJh)%100)
	mb72naMO5yPiTHNdGCzIeE = 0
	if type=='Series':
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','IFILM-EPISODES-1st')
		items = JJDtX1PZyIgN2T.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		title = ' - الحلقة '
		if LwmcG8ouzKfY2=='en': title = ' - Episode '
		if LwmcG8ouzKfY2=='fa': title = ' - قسمت '
		if LwmcG8ouzKfY2=='fa2': title = ' - قسمت '
		if LwmcG8ouzKfY2=='fa': c6DhYaZXwG21N = ''
		else: c6DhYaZXwG21N = LwmcG8ouzKfY2
		KuXEjJFZg0LQ4z = JJDtX1PZyIgN2T.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for name,count,ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5 in items:
			for vaQbluYS4GEsKCNwOymT1hFt in range(int(count),0,-1):
				uxpH0grO4DImTY = ggdRiBo3smurLUGO + c6DhYaZXwG21N + id + '/' + str(vaQbluYS4GEsKCNwOymT1hFt) + '.png'
				GTatBJjWw7qsmAXOv = name + title + str(vaQbluYS4GEsKCNwOymT1hFt)
				GTatBJjWw7qsmAXOv = jbigKDeUf0OSMrRkly2B5I3Act(GTatBJjWw7qsmAXOv)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,url,24,uxpH0grO4DImTY,'',str(vaQbluYS4GEsKCNwOymT1hFt))
	elif type=='Program':
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+vYpMA3CxgcyR4VZJh+'&size=30&orderby=1'
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-EPISODES-2nd')
		items = JJDtX1PZyIgN2T.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		title = ' - الحلقة '
		if LwmcG8ouzKfY2=='en': title = ' - Episode '
		if LwmcG8ouzKfY2=='fa': title = ' - قسمت '
		if LwmcG8ouzKfY2=='fa2': title = ' - قسمت '
		for vaQbluYS4GEsKCNwOymT1hFt,ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,RHMdaLNWiKFBm5GyQO72X6V8uIUC9,name in items:
			mb72naMO5yPiTHNdGCzIeE += 1
			uxpH0grO4DImTY = WK1Bf5cXpgUmOEl4L0Nd + FVsLwz1tAH(ggdRiBo3smurLUGO)
			name = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(name)
			GTatBJjWw7qsmAXOv = name + title + str(vaQbluYS4GEsKCNwOymT1hFt)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,24,uxpH0grO4DImTY,'',str(mb72naMO5yPiTHNdGCzIeE))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Music/GetTracksBy?id='+str(id)+'&page='+vYpMA3CxgcyR4VZJh+'&size=30&type=0'
			YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-EPISODES-3rd')
			items = JJDtX1PZyIgN2T.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,name,title in items:
				mb72naMO5yPiTHNdGCzIeE += 1
				uxpH0grO4DImTY = WK1Bf5cXpgUmOEl4L0Nd + FVsLwz1tAH(ggdRiBo3smurLUGO)
				GTatBJjWw7qsmAXOv = name + ' - ' + title
				GTatBJjWw7qsmAXOv = GTatBJjWw7qsmAXOv.strip(' ')
				GTatBJjWw7qsmAXOv = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(GTatBJjWw7qsmAXOv)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,24,uxpH0grO4DImTY,'',str(mb72naMO5yPiTHNdGCzIeE))
		elif 'Clips' in url:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Music/GetTracksBy?id=0&page='+vYpMA3CxgcyR4VZJh+'&size=30&type=15'
			YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-EPISODES-4th')
			items = JJDtX1PZyIgN2T.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			for ggdRiBo3smurLUGO,title,wHiSfdBL1v9Kl3n5 in items:
				mb72naMO5yPiTHNdGCzIeE += 1
				uxpH0grO4DImTY = WK1Bf5cXpgUmOEl4L0Nd + FVsLwz1tAH(ggdRiBo3smurLUGO)
				GTatBJjWw7qsmAXOv = title.strip(' ')
				GTatBJjWw7qsmAXOv = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(GTatBJjWw7qsmAXOv)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,24,uxpH0grO4DImTY,'',str(mb72naMO5yPiTHNdGCzIeE))
		elif 'category' in url:
			if 'category=6' in url:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Music/GetTracksBy?id=0&page='+vYpMA3CxgcyR4VZJh+'&size=30&type=6'
				YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-EPISODES-5th')
			elif 'category=4' in url:
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = dsKLYT0keR316XqGBAVmhDfSzvUMcI+'/Music/GetTracksBy?id=0&page='+vYpMA3CxgcyR4VZJh+'&size=30&type=4'
				YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-EPISODES-6th')
			items = JJDtX1PZyIgN2T.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,name,title in items:
				mb72naMO5yPiTHNdGCzIeE += 1
				uxpH0grO4DImTY = WK1Bf5cXpgUmOEl4L0Nd + FVsLwz1tAH(ggdRiBo3smurLUGO)
				GTatBJjWw7qsmAXOv = name + ' - ' + title
				GTatBJjWw7qsmAXOv = GTatBJjWw7qsmAXOv.strip(' ')
				GTatBJjWw7qsmAXOv = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(GTatBJjWw7qsmAXOv)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+GTatBJjWw7qsmAXOv,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,24,uxpH0grO4DImTY,'',str(mb72naMO5yPiTHNdGCzIeE))
	if type=='Music' or type=='Program':
		if mb72naMO5yPiTHNdGCzIeE>25:
			title='صفحة '
			if LwmcG8ouzKfY2=='en': title = ' Page '
			if LwmcG8ouzKfY2=='fa': title = ' صفحه '
			if LwmcG8ouzKfY2=='fa2': title = ' صفحه '
			for RNFwDQWO0k3h4 in range(1,11):
				if not vYpMA3CxgcyR4VZJh==str(RNFwDQWO0k3h4):
					sS2XM9cxDRT6duO = '0'+str(RNFwDQWO0k3h4)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title+str(RNFwDQWO0k3h4),url,23,'',DiGugbTfWHZErhKldV7m42+sS2XM9cxDRT6duO[-2:])
	return
def CsUdRabWuh0M9F(url,vaQbluYS4GEsKCNwOymT1hFt):
	WK1Bf5cXpgUmOEl4L0Nd = crYmdBbnu71R5wtap4LATEo6N(url)
	JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = [],[]
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','IFILM-PLAY-1st')
	items = JJDtX1PZyIgN2T.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		LwmcG8ouzKfY2 = KUtrygGimH(url)
		xxyPKEIGHM75VZcR3S2z0Q = url.split('/')
		id,type = xxyPKEIGHM75VZcR3S2z0Q[-1],xxyPKEIGHM75VZcR3S2z0Q[3]
		wHiSfdBL1v9Kl3n5 = items[0][0]+LwmcG8ouzKfY2+id+'/,'+vaQbluYS4GEsKCNwOymT1hFt+','+vaQbluYS4GEsKCNwOymT1hFt+'_'+items[0][2]
		JCop4mjTiurYB7W.append('m3u8')
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	items = JJDtX1PZyIgN2T.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		LwmcG8ouzKfY2 = KUtrygGimH(url)
		xxyPKEIGHM75VZcR3S2z0Q = url.split('/')
		id,type = xxyPKEIGHM75VZcR3S2z0Q[-1],xxyPKEIGHM75VZcR3S2z0Q[3]
		wHiSfdBL1v9Kl3n5 = items[0][0]+LwmcG8ouzKfY2+id+'/'+vaQbluYS4GEsKCNwOymT1hFt+items[0][2]
		JCop4mjTiurYB7W.append('mp4 url')
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	items = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5 in items:
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('//','/')
		JCop4mjTiurYB7W.append('mp4 src')
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	items = JJDtX1PZyIgN2T.findall('VideoAddress":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		wHiSfdBL1v9Kl3n5 = items[int(vaQbluYS4GEsKCNwOymT1hFt)-1]
		wHiSfdBL1v9Kl3n5 = WK1Bf5cXpgUmOEl4L0Nd+FVsLwz1tAH(wHiSfdBL1v9Kl3n5)
		JCop4mjTiurYB7W.append('mp4 address')
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	items = JJDtX1PZyIgN2T.findall('VoiceAddress":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		wHiSfdBL1v9Kl3n5 = items[int(vaQbluYS4GEsKCNwOymT1hFt)-1]
		wHiSfdBL1v9Kl3n5 = WK1Bf5cXpgUmOEl4L0Nd+FVsLwz1tAH(wHiSfdBL1v9Kl3n5)
		JCop4mjTiurYB7W.append('mp3 address')
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if len(EEgFl59RndzrBL8TUoaQMw6P)==1: wHiSfdBL1v9Kl3n5 = EEgFl59RndzrBL8TUoaQMw6P[0]
	else:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر الفيديو المناسب:', JCop4mjTiurYB7W)
		if zKgFfQoODy90ewYb5jGElUJRVs4p == -1 : return
		wHiSfdBL1v9Kl3n5 = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	XbzQHGJ0cBV(wHiSfdBL1v9Kl3n5,FpjtBKrnu5SdfyOvEPIQ,'video')
	return
def crYmdBbnu71R5wtap4LATEo6N(url):
	if kU2ZXSViB3wLANOz8bH in url: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = kU2ZXSViB3wLANOz8bH
	elif kHZn1cEVXyGNTRug3 in url: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = kHZn1cEVXyGNTRug3
	elif e7dbD8QN5j4V31os2z9y in url: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = e7dbD8QN5j4V31os2z9y
	elif bbeyGRNYpFKumwXt in url: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = bbeyGRNYpFKumwXt
	else: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = ''
	return HLAhjNIVMFonqi5zg2aQlpyfRKBrm
def KUtrygGimH(url):
	if   kU2ZXSViB3wLANOz8bH in url: LwmcG8ouzKfY2 = 'ar'
	elif kHZn1cEVXyGNTRug3 in url: LwmcG8ouzKfY2 = 'en'
	elif e7dbD8QN5j4V31os2z9y in url: LwmcG8ouzKfY2 = 'fa'
	elif bbeyGRNYpFKumwXt in url: LwmcG8ouzKfY2 = 'fa2'
	else: LwmcG8ouzKfY2 = ''
	return LwmcG8ouzKfY2
def r9gtNWGzOuJvZE(url):
	LwmcG8ouzKfY2 = KUtrygGimH(url)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url + '/Home/Live'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','IFILM-LIVE-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	kHWT0XY2S6apruwxiB8FDl1 = items[0]
	XbzQHGJ0cBV(kHWT0XY2S6apruwxiB8FDl1,FpjtBKrnu5SdfyOvEPIQ,'live')
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search:
		search = GVfnMyZxiRI()
		if not search: return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	if showDialogs:
		CsRrOeH0MF8J5zuwxa7XjPQ = [ kU2ZXSViB3wLANOz8bH , kHZn1cEVXyGNTRug3 , e7dbD8QN5j4V31os2z9y , bbeyGRNYpFKumwXt ]
		tjI2D513v7Yiyk6PesSnobKEWJ = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر اللغة المناسبة:', tjI2D513v7Yiyk6PesSnobKEWJ)
		if zKgFfQoODy90ewYb5jGElUJRVs4p == -1 : return
		website = CsRrOeH0MF8J5zuwxa7XjPQ[zKgFfQoODy90ewYb5jGElUJRVs4p]
	else:
		if '_IFILM-ARABIC_' in sdZQpO06qbHwAGPz7LCgu4lToE: website = kU2ZXSViB3wLANOz8bH
		elif '_IFILM-ENGLISH_' in sdZQpO06qbHwAGPz7LCgu4lToE: website = kHZn1cEVXyGNTRug3
		else: website = ''
	if not website: return
	LwmcG8ouzKfY2 = KUtrygGimH(website)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = website + "/Home/Search?searchstring=" + s2hzmL48wFudNE5
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','IFILM-SEARCH-1st')
	items = JJDtX1PZyIgN2T.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		for ggdRiBo3smurLUGO,qGsE8fdyFtUwBnu,id,title in items:
			if qGsE8fdyFtUwBnu in ['3','7']:
				title = title.replace('\\','')
				title = title.replace('"','')
				if qGsE8fdyFtUwBnu=='3':
					type = 'Series'
					if LwmcG8ouzKfY2=='ar': name = 'مسلسل : '
					elif LwmcG8ouzKfY2=='en': name = 'Series : '
					elif LwmcG8ouzKfY2=='fa': name = 'سريال ها : '
					elif LwmcG8ouzKfY2=='fa2': name = 'سريال ها : '
				elif qGsE8fdyFtUwBnu=='5':
					type = 'Film'
					if LwmcG8ouzKfY2=='ar': name = 'فيلم : '
					elif LwmcG8ouzKfY2=='en': name = 'Movie : '
					elif LwmcG8ouzKfY2=='fa': name = 'فيلم : '
					elif LwmcG8ouzKfY2=='fa2': name = 'فلم ها : '
				elif qGsE8fdyFtUwBnu=='7':
					type = 'Program'
					if LwmcG8ouzKfY2=='ar': name = 'برنامج : '
					elif LwmcG8ouzKfY2=='en': name = 'Program : '
					elif LwmcG8ouzKfY2=='fa': name = 'برنامه ها : '
					elif LwmcG8ouzKfY2=='fa2': name = 'برنامه ها : '
				title = name + title
				wHiSfdBL1v9Kl3n5 = website + '/' + type + '/Content/' + id
				ggdRiBo3smurLUGO = FVsLwz1tAH(ggdRiBo3smurLUGO)
				ggdRiBo3smurLUGO = website+ggdRiBo3smurLUGO
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,23,ggdRiBo3smurLUGO,'101')
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SHOOFPRO'
eMlwAzaLSj8ZEQ3txIGP = '_SHP_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['مصارعة','بث مباشر']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==480: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==481: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==482: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==483: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url,text)
	elif mode==489: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text,url)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',kU2ZXSViB3wLANOz8bH,'','','','','SHOOFPRO-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = JJDtX1PZyIgN2T.findall('href="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	PeArnUDVym1pjBFaG = PeArnUDVym1pjBFaG[0].strip('/')
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(PeArnUDVym1pjBFaG,'url')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع',PeArnUDVym1pjBFaG,489,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'أحدث المواضيع',PeArnUDVym1pjBFaG,481)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"navigation"(.*?)"myAccount"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</span>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		if wHiSfdBL1v9Kl3n5=='#': continue
		if title in eJzpdvc3KTust: continue
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,481)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,lgCsZBzHJta4wxRiOT):
	items = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','SHOOFPRO-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"post(.*?)"footer"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not GGbRgKaoskDC: return
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?image:url\((.*?)\)',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	eePfCBGXTNMy67sw4FqtKxJ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	MafbVdULxqkvgW1ZQn52P378 = '/'.join(lgCsZBzHJta4wxRiOT.strip('/').split('/')[4:]).split('-')
	for wHiSfdBL1v9Kl3n5,title,ggdRiBo3smurLUGO in items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) حلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
		if lgCsZBzHJta4wxRiOT:
			tb4p6sRlFPcio = '/'.join(wHiSfdBL1v9Kl3n5.strip('/').split('/')[4:]).split('-')
			aaYcN2BJKG4vl = len([SwAJPmoty8RC0n1 for SwAJPmoty8RC0n1 in MafbVdULxqkvgW1ZQn52P378 if SwAJPmoty8RC0n1 in tb4p6sRlFPcio])
			if aaYcN2BJKG4vl>2 and '/episodes/' in wHiSfdBL1v9Kl3n5:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,482,ggdRiBo3smurLUGO)
		else:
			if not vaQbluYS4GEsKCNwOymT1hFt: vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if set(title.split()) & set(eePfCBGXTNMy67sw4FqtKxJ) and 'مسلسل' not in title:
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,482,ggdRiBo3smurLUGO)
			elif vaQbluYS4GEsKCNwOymT1hFt and 'حلقة' in title:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,483,ggdRiBo3smurLUGO,'',url)
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,483,ggdRiBo3smurLUGO,'',url)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("'pagination'(.*?)</div>",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall("href='(.*?)'.*?>(.*?)</a>",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			title = title.replace('الصفحة ','')
			if title!='': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,481,'','',lgCsZBzHJta4wxRiOT)
	return
def sjmSkpqHVtPcv(url,FrC9LhHZWIySdGwNsuzqt5Rf01TXO):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','SHOOFPRO-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	ggdRiBo3smurLUGO = JJDtX1PZyIgN2T.findall('"img-responsive" src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ggdRiBo3smurLUGO: ggdRiBo3smurLUGO = ggdRiBo3smurLUGO[0]
	else: ggdRiBo3smurLUGO = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Thumb')
	DVPF8Mtr1bCklKo9L = True
	vLlUHJTNWusr0IGRxY63gDPCet9 = JJDtX1PZyIgN2T.findall('"listSeasons(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if vLlUHJTNWusr0IGRxY63gDPCet9 and '/ajax/seasons' not in url:
		mvgk7pP8Fw6heMSWd5oXn9itl = vLlUHJTNWusr0IGRxY63gDPCet9[0]
		count = mvgk7pP8Fw6heMSWd5oXn9itl.count('data-slug=')
		if count==0: count = mvgk7pP8Fw6heMSWd5oXn9itl.count('data-season=')
		if count>1:
			DVPF8Mtr1bCklKo9L = False
			if 'data-slug="' in mvgk7pP8Fw6heMSWd5oXn9itl:
				items = JJDtX1PZyIgN2T.findall('data-slug="(.*?)">(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for id,title in items:
					wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/wp-content/themes/vo2021/temp/ajax/seasons2.php?slug='+id
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,483,ggdRiBo3smurLUGO)
			else:
				items = JJDtX1PZyIgN2T.findall('data-season="(.*?)">(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for id,title in items:
					wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/wp-content/themes/vo2021/temp/ajax/seasons.php?seriesID='+id
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,483,ggdRiBo3smurLUGO)
	if DVPF8Mtr1bCklKo9L:
		mvgk7pP8Fw6heMSWd5oXn9itl = ''
		if '/ajax/seasons' in url: mvgk7pP8Fw6heMSWd5oXn9itl = YBEsLq8gVw629cMGQP1T
		else:
			ooTeU5chRPu = JJDtX1PZyIgN2T.findall('"eplist"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
			if ooTeU5chRPu: mvgk7pP8Fw6heMSWd5oXn9itl = ooTeU5chRPu[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if items:
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,482,ggdRiBo3smurLUGO)
	if not PL2fM9WhpjEFb7: d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,url)
	return
def CsUdRabWuh0M9F(url):
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.strip('/')+'/?do=watch'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','SHOOFPRO-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	EEgFl59RndzrBL8TUoaQMw6P = []
	PeArnUDVym1pjBFaG = OfTKisDR0Lv(url,'url')
	ttoevRYg7p8Sc2UO = JJDtX1PZyIgN2T.findall('vo_postID = "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not ttoevRYg7p8Sc2UO: ttoevRYg7p8Sc2UO = JJDtX1PZyIgN2T.findall('\(this\.id\,0\,(.*?)\)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	ttoevRYg7p8Sc2UO = ttoevRYg7p8Sc2UO[0]
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"serversList"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('id="(.*?)".*?">(.*?)</li>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for GBU56AWa01bHknpP3RNzTFuvQfe,title in items:
			title = title.strip(' ')
			wHiSfdBL1v9Kl3n5 = PeArnUDVym1pjBFaG+'/wp-content/themes/vo2021/temp/ajax/iframe2.php?id='+ttoevRYg7p8Sc2UO+'&video='+GBU56AWa01bHknpP3RNzTFuvQfe[2:]+'?named='+title+'__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	wHiSfdBL1v9Kl3n5 = JJDtX1PZyIgN2T.findall('"getEmbed".*?src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if wHiSfdBL1v9Kl3n5:
		title = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5[0],'url')
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5[0]+'?named='+title+'__embed'
		EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url.strip('/')+'/?do=download'
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','','SHOOFPRO-PLAY-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"table-responsive"(.*?)</table>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<td>(.*?)</td>.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5 in items:
			title = title.strip(' ')
			if 'anavidz' in wHiSfdBL1v9Kl3n5: LpB4ilMr6vVtQ = '__خاص'
			else: LpB4ilMr6vVtQ = ''
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'+LpB4ilMr6vVtQ
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search,PeArnUDVym1pjBFaG=''):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	if PeArnUDVym1pjBFaG=='': PeArnUDVym1pjBFaG = kU2ZXSViB3wLANOz8bH
	url = PeArnUDVym1pjBFaG+'/search/'+search+'/'
	d2JXnUMPmgsKBQqCE58lkZ(url,'')
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'LIVETV'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr['PYTHON'][0]
def HYWukw3pL2oMzPK4(mode,url):
	if   mode==100: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==101: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS('0',True)
	elif mode==102: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS('1',True)
	elif mode==103: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS('2',True)
	elif mode==104: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS('3',True)
	elif mode==105: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==106: mL7BVKcSygkuoPbWlEF4YD = egYaAP6oIWDjfzqX20HnKS('4',True)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_M3U_'+'قوائم فيديوهات M3U','',762)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_IPT_'+'قوائم فيديوهات IPTV','',761)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TV0_'+'قنوات من مواقعها الأصلية','',101)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TV4_'+'قنوات مختارة من يوتيوب','',106)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_YUT_'+'قنوات عربية من يوتيوب','',147)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_YUT_'+'قنوات أجنبية من يوتيوب','',148)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ','',28)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live','_MRF_'+'قناة المعارف من موقعهم','',41)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live','_PNT_'+'قناة هلا من موقع بانيت','',38)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TV1_'+'قنوات تلفزيونية عامة','',102)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TV2_'+'قنوات تلفزيونية خاصة','',103)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TV3_'+'قنوات تلفزيونية للفحص','',104)
	return
def egYaAP6oIWDjfzqX20HnKS(D2DlJjSYIrn,showDialogs=True):
	eMlwAzaLSj8ZEQ3txIGP = '_TV'+D2DlJjSYIrn+'_'
	YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(32)
	zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = {'id':'','user':YqywcljIHsFzoXaf0T97,'function':'list','menu':D2DlJjSYIrn}
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',kU2ZXSViB3wLANOz8bH,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,'','','','LIVETV-ITEMS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items = JJDtX1PZyIgN2T.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if items:
		for ggjo5zu7yCiIOhrb in range(len(items)):
			name = items[ggjo5zu7yCiIOhrb][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[ggjo5zu7yCiIOhrb] = items[ggjo5zu7yCiIOhrb][0],items[ggjo5zu7yCiIOhrb][1],items[ggjo5zu7yCiIOhrb][2],name,items[ggjo5zu7yCiIOhrb][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for dbBRqLP6WeEV,RgNSOU7P93n,rjcLNMPIGsBSni4odgDpx8zqQ2h,name,ggdRiBo3smurLUGO in items:
			if '#' in dbBRqLP6WeEV: continue
			if dbBRqLP6WeEV!='URL': name = name+'[COLOR FFC89008]   '+dbBRqLP6WeEV+'[/COLOR]'
			url = dbBRqLP6WeEV+';;'+RgNSOU7P93n+';;'+rjcLNMPIGsBSni4odgDpx8zqQ2h+';;'+D2DlJjSYIrn
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('live',eMlwAzaLSj8ZEQ3txIGP+''+name,url,105,ggdRiBo3smurLUGO)
	else:
		if showDialogs: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'هذه الخدمة مخصصة للمبرمج فقط','',9999)
	return
def CsUdRabWuh0M9F(id):
	dbBRqLP6WeEV,RgNSOU7P93n,rjcLNMPIGsBSni4odgDpx8zqQ2h,D2DlJjSYIrn = id.split(';;')
	url = ''
	YqywcljIHsFzoXaf0T97 = sPgi90KAz7JCOojl(32)
	if dbBRqLP6WeEV=='URL': url = rjcLNMPIGsBSni4odgDpx8zqQ2h
	elif dbBRqLP6WeEV=='YOUTUBE':
		url = LWzUbE5adDslTXGr['YOUTUBE'][0]+'/watch?v='+rjcLNMPIGsBSni4odgDpx8zqQ2h
		import jfGcn9x8KN
		jfGcn9x8KN.AkMyd9E2pVrbG7g5([url],FpjtBKrnu5SdfyOvEPIQ,'live',url)
		return
	elif dbBRqLP6WeEV=='GA':
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'id' : '', 'user' : YqywcljIHsFzoXaf0T97 , 'function' : 'playGA1' , 'menu' : '' }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,'',False,'','LIVETV-PLAY-1st')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		cookies = SSzrgUnfVGL1hQsu40FoP7CWXax.cookies
		r4uPfwIokamLy89ibTqjWdQGVsEg = cookies['ASP.NET_SessionId']
		url = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'id' : rjcLNMPIGsBSni4odgDpx8zqQ2h , 'user' : YqywcljIHsFzoXaf0T97 , 'function' : 'playGA2' , 'menu' : '' }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+r4uPfwIokamLy89ibTqjWdQGVsEg }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'GET',kU2ZXSViB3wLANOz8bH,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,headers,'','','LIVETV-PLAY-2nd')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		url = JJDtX1PZyIgN2T.findall('resp":"(http.*?m3u8)(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		wHiSfdBL1v9Kl3n5 = url[0][0]
		x2CNeEUiP4WYBMVRFIl = url[0][1]
		AbJuVh5986odS = 'http://38.'+RgNSOU7P93n+'777/'+rjcLNMPIGsBSni4odgDpx8zqQ2h+'_HD.m3u8'+x2CNeEUiP4WYBMVRFIl
		CpjoltY62M5wkvZ = AbJuVh5986odS.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		IOfauPy7ZBVQotF1gTA0pRJM = AbJuVh5986odS.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		JCop4mjTiurYB7W = ['HD','SD1','SD2']
		EEgFl59RndzrBL8TUoaQMw6P = [AbJuVh5986odS,CpjoltY62M5wkvZ,IOfauPy7ZBVQotF1gTA0pRJM]
		zKgFfQoODy90ewYb5jGElUJRVs4p = 0
		if zKgFfQoODy90ewYb5jGElUJRVs4p == -1: return
		else: url = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	elif dbBRqLP6WeEV=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'id' : rjcLNMPIGsBSni4odgDpx8zqQ2h , 'user' : YqywcljIHsFzoXaf0T97 , 'function' : 'playNT' , 'menu' : D2DlJjSYIrn }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST', kU2ZXSViB3wLANOz8bH, zAkbOyR9ZirYWxTwvMqouPLBjeQ20, headers, False,'','LIVETV-PLAY-3rd')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		url = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		url = url.replace('%20',' ')
		url = url.replace('%3D','=')
		if 'Learn' in rjcLNMPIGsBSni4odgDpx8zqQ2h:
			url = url.replace('NTNNile','')
			url = url.replace('learning1','Learning')
	elif dbBRqLP6WeEV=='PL':
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'id' : rjcLNMPIGsBSni4odgDpx8zqQ2h , 'user' : YqywcljIHsFzoXaf0T97 , 'function' : 'playPL' , 'menu' : D2DlJjSYIrn }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST', kU2ZXSViB3wLANOz8bH, zAkbOyR9ZirYWxTwvMqouPLBjeQ20, '',False,'','LIVETV-PLAY-4th')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		url = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		headers = {'Referer':SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Referer']}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',url, '',headers , '','','LIVETV-PLAY-5th')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		items = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		url = items[0]
	elif dbBRqLP6WeEV in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if dbBRqLP6WeEV=='TA': rjcLNMPIGsBSni4odgDpx8zqQ2h = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		zAkbOyR9ZirYWxTwvMqouPLBjeQ20 = { 'id' : rjcLNMPIGsBSni4odgDpx8zqQ2h , 'user' : YqywcljIHsFzoXaf0T97 , 'function' : 'play'+dbBRqLP6WeEV , 'menu' : D2DlJjSYIrn }
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,'POST',kU2ZXSViB3wLANOz8bH,zAkbOyR9ZirYWxTwvMqouPLBjeQ20,headers,'','','LIVETV-PLAY-6th')
		if not SSzrgUnfVGL1hQsu40FoP7CWXax.succeeded:
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		url = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
		if dbBRqLP6WeEV=='FM':
			SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET', url, '', '', False,'','LIVETV-PLAY-7th')
			url = SSzrgUnfVGL1hQsu40FoP7CWXax.headers['Location']
			url = url.replace('https','http')
	XbzQHGJ0cBV(url,FpjtBKrnu5SdfyOvEPIQ,'live')
	return
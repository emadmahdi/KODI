# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'MOVS4U'
eMlwAzaLSj8ZEQ3txIGP = '_M4U_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['انواع افلام','جودات افلام']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==380: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==381: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==382: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==383: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==389: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',389,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المميزة',kU2ZXSViB3wLANOz8bH,381,'','','featured')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الجانبية',kU2ZXSViB3wLANOz8bH,381,'','','sider')
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','MOVS4U-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items = JJDtX1PZyIgN2T.findall('<header>.*?<h2>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for ZxtmiwJ4zPKpU6VkCAn in range(len(items)):
		title = items[ZxtmiwJ4zPKpU6VkCAn]
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,kU2ZXSViB3wLANOz8bH,381,'','','latest'+str(ZxtmiwJ4zPKpU6VkCAn))
	mvgk7pP8Fw6heMSWd5oXn9itl = ''
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="menu"(.*?)id="contenedor"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl += GGbRgKaoskDC[0]
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="sidebar(.*?)aside',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC: mvgk7pP8Fw6heMSWd5oXn9itl += GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	xg3XfdNISH5la = True
	for wHiSfdBL1v9Kl3n5,title in items:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if title=='الأعلى مشاهدة':
			if xg3XfdNISH5la:
				title = 'الافلام '+title
				xg3XfdNISH5la = False
			else: title = 'المسلسلات '+title
		if title not in eJzpdvc3KTust:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,381)
	return YBEsLq8gVw629cMGQP1T
def d2JXnUMPmgsKBQqCE58lkZ(url,type):
	mvgk7pP8Fw6heMSWd5oXn9itl,items = [],[]
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','MOVS4U-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if type=='search':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="search-page"(.*?)class="sidebar',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	elif type=='sider':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="widget(.*?)class="widget',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		QoOV2DrxJsWNEaX6tuqIzfh5dbgRjn = JJDtX1PZyIgN2T.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		EEgFl59RndzrBL8TUoaQMw6P,PGsuVjve4kTXx8rM,JCop4mjTiurYB7W = zip(*QoOV2DrxJsWNEaX6tuqIzfh5dbgRjn)
		items = zip(PGsuVjve4kTXx8rM,EEgFl59RndzrBL8TUoaQMw6P,JCop4mjTiurYB7W)
	elif type=='featured':
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('id="slider-movies-tvshows"(.*?)<header>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	elif 'latest' in type:
		ZxtmiwJ4zPKpU6VkCAn = int(type[-1:])
		YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('<header>','<end><start>')
		YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T.replace('<div class="sidebar','<end><div class="sidebar')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<start>(.*?)<end>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[ZxtmiwJ4zPKpU6VkCAn]
		if ZxtmiwJ4zPKpU6VkCAn==2: items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	else:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="content"(.*?)class="(pagination|sidebar)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0][0]
			if '/collection/' in url:
				items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			elif '/quality/' in url:
				items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if not items and mvgk7pP8Fw6heMSWd5oXn9itl:
		items = JJDtX1PZyIgN2T.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for ggdRiBo3smurLUGO,wHiSfdBL1v9Kl3n5,title in items:
		if 'serie' in title:
			title = JJDtX1PZyIgN2T.findall('^(.*?)<.*?serie">(.*?)<',title,JJDtX1PZyIgN2T.DOTALL)
			title = title[0][1]
			if title in ClXwqHm0DEMvI39agWyiRYopQ: continue
			ClXwqHm0DEMvI39agWyiRYopQ.append(title)
			title = '_MOD_'+title
		LpB4ilMr6vVtQ = JJDtX1PZyIgN2T.findall('^(.*?)<',title,JJDtX1PZyIgN2T.DOTALL)
		if LpB4ilMr6vVtQ: title = LpB4ilMr6vVtQ[0]
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if '/tvshows/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,383,ggdRiBo3smurLUGO)
		elif '/episodes/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,383,ggdRiBo3smurLUGO)
		elif '/seasons/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,383,ggdRiBo3smurLUGO)
		elif '/collection/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,381,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,382,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		RxameojzIUZ75EkYQ4 = GGbRgKaoskDC[0][0]
		kC5X3NedD7vFGB1w = GGbRgKaoskDC[0][1]
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0][2]
		items = JJDtX1PZyIgN2T.findall("href='(.*?)'.*?>(.*?)<",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			if title=='' or title==kC5X3NedD7vFGB1w: continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,381,'','',type)
		wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.replace('/page/'+title+'/','/page/'+kC5X3NedD7vFGB1w+'/')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'اخر صفحة '+kC5X3NedD7vFGB1w,wHiSfdBL1v9Kl3n5,381,'','',type)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','MOVS4U-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('class="C rated".*?>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C,False):
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link',eMlwAzaLSj8ZEQ3txIGP+'المسلسل للكبار والمبرمج منعه','',9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = JJDtX1PZyIgN2T.findall('''class='item'><a href="(.*?)"''',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if FrC9LhHZWIySdGwNsuzqt5Rf01TXO:
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO[1]
			sjmSkpqHVtPcv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
			return
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('''class='episodios'(.*?)id="cast"''',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for ggdRiBo3smurLUGO,vaQbluYS4GEsKCNwOymT1hFt,wHiSfdBL1v9Kl3n5,name in items:
			title = vaQbluYS4GEsKCNwOymT1hFt+' : '+name+' الحلقة'
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,382)
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','MOVS4U-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('class="C rated".*?>(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	EEgFl59RndzrBL8TUoaQMw6P = []
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0][0]
		items = JJDtX1PZyIgN2T.findall("data-url='(.*?)'.*?class='server'>(.*?)<",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__watch'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="remodal"(.*?)class="remodal-close"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download'
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/?s='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
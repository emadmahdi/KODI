# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'GLOBALSEARCH'
eMlwAzaLSj8ZEQ3txIGP = '_GLS_'
def HYWukw3pL2oMzPK4(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,apIVksn1FTuj6rbYhMPDLHS9N,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,vYpMA3CxgcyR4VZJh):
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==540: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==541: mL7BVKcSygkuoPbWlEF4YD = HHgeukfw61YU3orA(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==542: mL7BVKcSygkuoPbWlEF4YD = Nw2RbHYcV3El0AIJn(hulSHFUcXsaVQGTn8r9zMkNPIwgvo,apIVksn1FTuj6rbYhMPDLHS9N,vYpMA3CxgcyR4VZJh)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==549: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','بحث جديد','',549)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]','',9999)
	dy2JDiowIGt87eX3VBphrM = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'dict','GLOBALSEARCH_SITES')
	if dy2JDiowIGt87eX3VBphrM:
		dy2JDiowIGt87eX3VBphrM = dy2JDiowIGt87eX3VBphrM['__SEQUENCED_COLUMNS__']
		for fEasiDJ3gHUoOqLRlNdp in reversed(dy2JDiowIGt87eX3VBphrM):
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',fEasiDJ3gHUoOqLRlNdp,'',549,'','',fEasiDJ3gHUoOqLRlNdp)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(fEasiDJ3gHUoOqLRlNdp):
	if not fEasiDJ3gHUoOqLRlNdp:
		fEasiDJ3gHUoOqLRlNdp = GVfnMyZxiRI()
		if not fEasiDJ3gHUoOqLRlNdp: return
		fEasiDJ3gHUoOqLRlNdp = fEasiDJ3gHUoOqLRlNdp.lower()
	ntTrG6PdEqsuh2Qeo = fEasiDJ3gHUoOqLRlNdp.replace(eMlwAzaLSj8ZEQ3txIGP,'')
	aKhVA308XvmoMJkODHibnNe9Y7Er(ntTrG6PdEqsuh2Qeo)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','عمل بحث جماعي - '+ntTrG6PdEqsuh2Qeo,'search_sites',542,'','',ntTrG6PdEqsuh2Qeo)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','نتائج البحث مفصلة - '+ntTrG6PdEqsuh2Qeo,'opened_sites',542,'','',ntTrG6PdEqsuh2Qeo)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','نتائج البحث مقسمة - '+ntTrG6PdEqsuh2Qeo,'listed_sites',542,'','',ntTrG6PdEqsuh2Qeo)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','بحث منفرد - '+ntTrG6PdEqsuh2Qeo,'',541,'','',ntTrG6PdEqsuh2Qeo)
	return
def aKhVA308XvmoMJkODHibnNe9Y7Er(t8yhpDALFcNku4oxUP):
	QpNasRbV0fkeWox6Ytizc = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_SITES',t8yhpDALFcNku4oxUP)
	K2L80Rj3Xc = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_SITES',eMlwAzaLSj8ZEQ3txIGP+t8yhpDALFcNku4oxUP)
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES',t8yhpDALFcNku4oxUP)
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES',eMlwAzaLSj8ZEQ3txIGP+t8yhpDALFcNku4oxUP)
	jshJ1Wf8FS7uECXtlgrvNycUB602 = QpNasRbV0fkeWox6Ytizc+K2L80Rj3Xc
	if jshJ1Wf8FS7uECXtlgrvNycUB602: t8yhpDALFcNku4oxUP = eMlwAzaLSj8ZEQ3txIGP+t8yhpDALFcNku4oxUP
	pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES',t8yhpDALFcNku4oxUP,jshJ1Wf8FS7uECXtlgrvNycUB602,u5vT6erC7PYdV18MNSwRnJE)
	return
def q2vWLiRTVYUAXIQ0486e():
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt('','','','رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=1: return
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES')
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_OPENED')
	egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_CLOSED')
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def Nw2RbHYcV3El0AIJn(ggK5UMkWfd6HqQCASiYR,CgEIoQaceLumDKWVr2p746Zb,HLAhjNIVMFonqi5zg2aQlpyfRKBrm=''):
	EEqTX5RJnjw,OObfqnLz9I,BBlvgSNozxXn4t6Ja8wyqM7uFQUE,WoIhtUi4cF,sXlvQKmJi1T4u7WC,eEN9HPRGbyx5v63gDO8zhLZlVmW,kS4uiCYWts96N7gpv3leLBP = [],[],[],{},{},{},{}
	if CgEIoQaceLumDKWVr2p746Zb!='search_sites':
		if CgEIoQaceLumDKWVr2p746Zb=='listed_sites': BBlvgSNozxXn4t6Ja8wyqM7uFQUE = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_SITES',eMlwAzaLSj8ZEQ3txIGP+ggK5UMkWfd6HqQCASiYR)
		elif CgEIoQaceLumDKWVr2p746Zb=='opened_sites': BBlvgSNozxXn4t6Ja8wyqM7uFQUE = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_OPENED',ggK5UMkWfd6HqQCASiYR)
		elif CgEIoQaceLumDKWVr2p746Zb=='closed_sites': BBlvgSNozxXn4t6Ja8wyqM7uFQUE = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_CLOSED',(HLAhjNIVMFonqi5zg2aQlpyfRKBrm,ggK5UMkWfd6HqQCASiYR))
	if not BBlvgSNozxXn4t6Ja8wyqM7uFQUE:
		DDTdLb3SZQPv7rX1qfwHCpn2eyKc = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		d1cgFMGN2Eaoz9AelBI = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+ggK5UMkWfd6HqQCASiYR+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if CgEIoQaceLumDKWVr2p746Zb=='search_sites': Ay3eLGaTncD67lx8ZOud = d1cgFMGN2Eaoz9AelBI
		else: Ay3eLGaTncD67lx8ZOud = DDTdLb3SZQPv7rX1qfwHCpn2eyKc+d1cgFMGN2Eaoz9AelBI
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt('','','','رسالة من المبرمج',Ay3eLGaTncD67lx8ZOud)
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=1: return
		DTeLX73NFMctyKU9i(False,False,False)
		b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Search For: [ '+ggK5UMkWfd6HqQCASiYR+' ]')
		jiEObaH7z5yD6WpvUe = 1
		for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in LmSe8awMPpCzoKW:
			WoIhtUi4cF[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = []
			ihbjPQKgtdYUvNnLV5XErp3f0 = '_NODIALOGS_'
			if '-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm: ihbjPQKgtdYUvNnLV5XErp3f0 = ihbjPQKgtdYUvNnLV5XErp3f0+'_REMEMBERRESULTS__'+HLAhjNIVMFonqi5zg2aQlpyfRKBrm+'_'
			UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b = DDE8bFYNye7xkqHoVvzXOSg1l0d6(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
			if jiEObaH7z5yD6WpvUe:
				Mrx2OeZV1LNjBsQ58Savi7.sleep(0.5)
				kS4uiCYWts96N7gpv3leLBP[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=y9topEPuNCwYTgB,args=(ggK5UMkWfd6HqQCASiYR+ihbjPQKgtdYUvNnLV5XErp3f0,))
				kS4uiCYWts96N7gpv3leLBP[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].start()
			else: y9topEPuNCwYTgB(ggK5UMkWfd6HqQCASiYR+ihbjPQKgtdYUvNnLV5XErp3f0)
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(kFhAce5Pz1(HLAhjNIVMFonqi5zg2aQlpyfRKBrm),'',Mrx2OeZV1LNjBsQ58Savi7=1000)
		if jiEObaH7z5yD6WpvUe:
			Mrx2OeZV1LNjBsQ58Savi7.sleep(2)
			for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in LmSe8awMPpCzoKW:
				kS4uiCYWts96N7gpv3leLBP[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].join(10)
			Mrx2OeZV1LNjBsQ58Savi7.sleep(2)
		for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in LmSe8awMPpCzoKW:
			UIXxutP306wVQaejNrmAgJ5Dsk4zLy,y9topEPuNCwYTgB,C42Qhj1WDOvPy9b = DDE8bFYNye7xkqHoVvzXOSg1l0d6(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
			for sXPuroaMIYnl in PL2fM9WhpjEFb7:
				GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = sXPuroaMIYnl
				if C42Qhj1WDOvPy9b in rBabYANvVwWzjCp2QF:
					if 'IPTV-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and (239>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=230 or 289>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=280):
						if sXPuroaMIYnl in WoIhtUi4cF['IPTV-LIVE']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['IPTV-MOVIES']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['IPTV-SERIES']: continue
						if 'صفحة' not in rBabYANvVwWzjCp2QF:
							if   GGKpqhAcPw9FHBvdfarRuySJ1Yl=='live': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-LIVE'
							elif GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-MOVIES'
							elif GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-SERIES'
						else:
							if   'LIVE' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-LIVE'
							elif 'MOVIES' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-MOVIES'
							elif 'SERIES' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IPTV-SERIES'
					elif 'M3U-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and 729>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=710:
						if sXPuroaMIYnl in WoIhtUi4cF['M3U-LIVE']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['M3U-MOVIES']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['M3U-SERIES']: continue
						if 'صفحة' not in rBabYANvVwWzjCp2QF:
							if   GGKpqhAcPw9FHBvdfarRuySJ1Yl=='live': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-LIVE'
							elif GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-MOVIES'
							elif GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder': HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-SERIES'
						else:
							if   'LIVE' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-LIVE'
							elif 'MOVIES' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-MOVIES'
							elif 'SERIES' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'M3U-SERIES'
					elif 'YOUTUBE-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and 149>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=140:
						if sXPuroaMIYnl in WoIhtUi4cF['YOUTUBE-CHANNELS']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['YOUTUBE-PLAYLISTS']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in rBabYANvVwWzjCp2QF or ':: ' in rBabYANvVwWzjCp2QF:
							continue
						else:
							if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==144 and 'USER' in rBabYANvVwWzjCp2QF: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'YOUTUBE-CHANNELS'
							elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==144 and 'CHNL' in rBabYANvVwWzjCp2QF: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'YOUTUBE-CHANNELS'
							elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==144 and 'LIST' in rBabYANvVwWzjCp2QF: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'YOUTUBE-PLAYLISTS'
							elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==143: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and 419>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=400:
						if sXPuroaMIYnl in WoIhtUi4cF['DAILYMOTION-PLAYLISTS']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['DAILYMOTION-CHANNELS']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['DAILYMOTION-VIDEOS']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['DAILYMOTION-TOPICS']: continue
						if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [401,405]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'DAILYMOTION-PLAYLISTS'
						elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [402,406]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'DAILYMOTION-CHANNELS'
						elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [404]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'DAILYMOTION-VIDEOS'
						elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [415]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'DAILYMOTION-LIVES'
						elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [412,413]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'DAILYMOTION-TOPICS'
					elif 'PANET-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and 39>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=30:
						if sXPuroaMIYnl in WoIhtUi4cF['PANET-SERIES']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['PANET-MOVIES']: continue
						if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [32,39]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'PANET-SERIES'
						elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [33,39]: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'PANET-MOVIES'
					elif 'IFILM-' in HLAhjNIVMFonqi5zg2aQlpyfRKBrm and 29>=AFWci0tYmjRU1azGJEy3ovDw2hfsqr>=20:
						if sXPuroaMIYnl in WoIhtUi4cF['IFILM-ARABIC']: continue
						if sXPuroaMIYnl in WoIhtUi4cF['IFILM-ENGLISH']: continue
						if   '/ar.' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IFILM-ARABIC'
						elif '/en.' in apIVksn1FTuj6rbYhMPDLHS9N: HLAhjNIVMFonqi5zg2aQlpyfRKBrm = 'IFILM-ENGLISH'
					WoIhtUi4cF[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].append(sXPuroaMIYnl)
		PL2fM9WhpjEFb7[:] = []
		for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in list(WoIhtUi4cF.keys()):
			sXlvQKmJi1T4u7WC[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = []
			eEN9HPRGbyx5v63gDO8zhLZlVmW[HLAhjNIVMFonqi5zg2aQlpyfRKBrm] = []
			for GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in WoIhtUi4cF[HLAhjNIVMFonqi5zg2aQlpyfRKBrm]:
				sXPuroaMIYnl = (GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
				if 'صفحة' in rBabYANvVwWzjCp2QF and GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder': eEN9HPRGbyx5v63gDO8zhLZlVmW[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].append(sXPuroaMIYnl)
				else: sXlvQKmJi1T4u7WC[HLAhjNIVMFonqi5zg2aQlpyfRKBrm].append(sXPuroaMIYnl)
		L5ub3RAQdZhE6SUweC4NgO = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
		for HLAhjNIVMFonqi5zg2aQlpyfRKBrm in Fe5HaTsOjEVdJizL9IfQWvZr3ChSA:
			if HLAhjNIVMFonqi5zg2aQlpyfRKBrm==ffKGTopc4YXOAnu8JzQ0NjWw3ves9[0]: L5ub3RAQdZhE6SUweC4NgO = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif HLAhjNIVMFonqi5zg2aQlpyfRKBrm==Xe9gIFkDSyCHm0jKVf[0]: L5ub3RAQdZhE6SUweC4NgO = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157,'','','','','')]
			elif HLAhjNIVMFonqi5zg2aQlpyfRKBrm==SRpWNlGL7ZBiYXJd0OUtrK9[0]: L5ub3RAQdZhE6SUweC4NgO = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157,'','','','','')]
			if HLAhjNIVMFonqi5zg2aQlpyfRKBrm not in sXlvQKmJi1T4u7WC.keys(): continue
			if sXlvQKmJi1T4u7WC[HLAhjNIVMFonqi5zg2aQlpyfRKBrm]:
				fYUuDPNQhVHLEnwTCbd5W7 = kFhAce5Pz1(HLAhjNIVMFonqi5zg2aQlpyfRKBrm)
				O1WviaL0I5l4to8b9Qfyks6rGVm3YF = [('link','[COLOR FFFFFF00]===== '+fYUuDPNQhVHLEnwTCbd5W7+' =====[/COLOR]','',9999,'','','','','')]
				if 0: JsZPr5jM1wQi0246uo9melL7Ka = ggK5UMkWfd6HqQCASiYR+' - '+'بحث'+' '+fYUuDPNQhVHLEnwTCbd5W7
				else: JsZPr5jM1wQi0246uo9melL7Ka = 'بحث'+' '+fYUuDPNQhVHLEnwTCbd5W7+' - '+ggK5UMkWfd6HqQCASiYR
				if len(sXlvQKmJi1T4u7WC[HLAhjNIVMFonqi5zg2aQlpyfRKBrm])<8: MPU5vtyRSs6Ow2ncYmZBoJp3deX = []
				else:
					c6D1kHvmo0bqih = '[COLOR FFC89008]'+JsZPr5jM1wQi0246uo9melL7Ka+'[/COLOR]'
					MPU5vtyRSs6Ow2ncYmZBoJp3deX = [('folder',eMlwAzaLSj8ZEQ3txIGP+c6D1kHvmo0bqih,'closed_sites',542,'',HLAhjNIVMFonqi5zg2aQlpyfRKBrm,ggK5UMkWfd6HqQCASiYR,'','')]
				Qk2xYJ4dNUMgWn8PTro = sXlvQKmJi1T4u7WC[HLAhjNIVMFonqi5zg2aQlpyfRKBrm]+eEN9HPRGbyx5v63gDO8zhLZlVmW[HLAhjNIVMFonqi5zg2aQlpyfRKBrm]
				OObfqnLz9I += L5ub3RAQdZhE6SUweC4NgO+O1WviaL0I5l4to8b9Qfyks6rGVm3YF+Qk2xYJ4dNUMgWn8PTro[:7]+MPU5vtyRSs6Ow2ncYmZBoJp3deX
				CWgx23ewrqsVK4LQXOaR8 = [('folder',eMlwAzaLSj8ZEQ3txIGP+JsZPr5jM1wQi0246uo9melL7Ka,'closed_sites',542,'',HLAhjNIVMFonqi5zg2aQlpyfRKBrm,ggK5UMkWfd6HqQCASiYR,'','')]
				EEqTX5RJnjw += L5ub3RAQdZhE6SUweC4NgO+CWgx23ewrqsVK4LQXOaR8
				L5ub3RAQdZhE6SUweC4NgO = []
				pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'GLOBALSEARCH_CLOSED',(HLAhjNIVMFonqi5zg2aQlpyfRKBrm,ggK5UMkWfd6HqQCASiYR),Qk2xYJ4dNUMgWn8PTro,u5vT6erC7PYdV18MNSwRnJE)
		pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'GLOBALSEARCH_OPENED',ggK5UMkWfd6HqQCASiYR,OObfqnLz9I,u5vT6erC7PYdV18MNSwRnJE)
		egFp6ox1ZirEC7hMQI0PLHwnmvNkK(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES',ggK5UMkWfd6HqQCASiYR)
		pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'GLOBALSEARCH_SITES',eMlwAzaLSj8ZEQ3txIGP+ggK5UMkWfd6HqQCASiYR,EEqTX5RJnjw,u5vT6erC7PYdV18MNSwRnJE)
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if CgEIoQaceLumDKWVr2p746Zb=='listed_sites' and EEqTX5RJnjw: BBlvgSNozxXn4t6Ja8wyqM7uFQUE = EEqTX5RJnjw
		else: BBlvgSNozxXn4t6Ja8wyqM7uFQUE = OObfqnLz9I
	if CgEIoQaceLumDKWVr2p746Zb!='search_sites':
		for GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv in BBlvgSNozxXn4t6Ja8wyqM7uFQUE:
			if CgEIoQaceLumDKWVr2p746Zb in ['listed_sites','opened_sites'] and 'صفحة' in rBabYANvVwWzjCp2QF and GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder': continue
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv)
	DTeLX73NFMctyKU9i('','','')
	return
def HHgeukfw61YU3orA(ggK5UMkWfd6HqQCASiYR=''):
	fEasiDJ3gHUoOqLRlNdp,ihbjPQKgtdYUvNnLV5XErp3f0,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(ggK5UMkWfd6HqQCASiYR)
	if not fEasiDJ3gHUoOqLRlNdp:
		fEasiDJ3gHUoOqLRlNdp = GVfnMyZxiRI()
		if not fEasiDJ3gHUoOqLRlNdp: return
		fEasiDJ3gHUoOqLRlNdp = fEasiDJ3gHUoOqLRlNdp.lower()
	b6kj4LJ5tzTeOMQi('NOTICE',ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+'   Search For: [ '+fEasiDJ3gHUoOqLRlNdp+' ]')
	s2hzmL48wFudNE5 = fEasiDJ3gHUoOqLRlNdp+ihbjPQKgtdYUvNnLV5XErp3f0
	if 0: enfRwbqsd3jlcoGvB0gNXzOC17tFHE,ntTrG6PdEqsuh2Qeo = fEasiDJ3gHUoOqLRlNdp+' - ',''
	else: enfRwbqsd3jlcoGvB0gNXzOC17tFHE,ntTrG6PdEqsuh2Qeo = '',' - '+fEasiDJ3gHUoOqLRlNdp
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_M3U_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث M3U'+ntTrG6PdEqsuh2Qeo,'',719,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_IPT_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث IPTV'+ntTrG6PdEqsuh2Qeo,'',239,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_BKR_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع بكرا'+ntTrG6PdEqsuh2Qeo,'',379,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_KLA_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع كل العرب'+ntTrG6PdEqsuh2Qeo,'',19,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_ART_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع تونز عربية'+ntTrG6PdEqsuh2Qeo,'',739,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_KRB_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع قناة كربلاء'+ntTrG6PdEqsuh2Qeo,'',329,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_FH1_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع فاصل الأول'+ntTrG6PdEqsuh2Qeo,'',579,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_KTV_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع كتكوت تيفي'+ntTrG6PdEqsuh2Qeo,'',819,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_EB1_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع ايجي بيست 1'+ntTrG6PdEqsuh2Qeo,'',779,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_EB2_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع ايجي بيست 2'+ntTrG6PdEqsuh2Qeo,'',789,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_IFL_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'  بحث موقع قناة آي فيلم'+ntTrG6PdEqsuh2Qeo+'  ','',29,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_AKO_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع أكوام القديم'+ntTrG6PdEqsuh2Qeo,'',79,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_AKW_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع أكوام الجديد'+ntTrG6PdEqsuh2Qeo,'',249,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_MRF_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع قناة المعارف'+ntTrG6PdEqsuh2Qeo,'',49,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_SHM_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع شوف ماكس'+ntTrG6PdEqsuh2Qeo,'',59,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]','',157)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_FJS_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+' بحث موقع فجر شو'+ntTrG6PdEqsuh2Qeo+' ','',399,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_TVF_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع تيفي فان'+ntTrG6PdEqsuh2Qeo,'',469,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_LDN_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع لودي نت'+ntTrG6PdEqsuh2Qeo,'',459,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_CMN_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما ناو'+ntTrG6PdEqsuh2Qeo,'',309,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_WCM_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع وي سيما'+ntTrG6PdEqsuh2Qeo,'',569,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_SHN_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع شاهد نيوز'+ntTrG6PdEqsuh2Qeo,'',589,'','',s2hzmL48wFudNE5+'_NODIALOGS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_ARS_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع عرب سييد'+ntTrG6PdEqsuh2Qeo,'',259,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_CCB_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما كلوب'+ntTrG6PdEqsuh2Qeo,'',829,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_SH4_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع شاهد فوريو'+ntTrG6PdEqsuh2Qeo,'',119,'','',s2hzmL48wFudNE5+'_NODIALOGS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_SHT_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع شوفها تيفي'+ntTrG6PdEqsuh2Qeo,'',649,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]','',157)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_FST_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع فوستا'+ntTrG6PdEqsuh2Qeo,'',609,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_FBK_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع فبركة'+ntTrG6PdEqsuh2Qeo,'',629,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_YQT_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع ياقوت'+ntTrG6PdEqsuh2Qeo,'',669,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_BRS_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع برستيج'+ntTrG6PdEqsuh2Qeo,'',659,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_HLC_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع هلا سيما'+ntTrG6PdEqsuh2Qeo,'',89,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_DR7_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع دراما صح'+ntTrG6PdEqsuh2Qeo,'',689,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_CMF_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما فانز'+ntTrG6PdEqsuh2Qeo,'',99,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_CML_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما لايت'+ntTrG6PdEqsuh2Qeo,'',479,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_ABD_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما عبدو'+ntTrG6PdEqsuh2Qeo,'',559,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_C4H_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع سيما 400'+ntTrG6PdEqsuh2Qeo,'',699,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_AHK_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع أهواك تيفي'+ntTrG6PdEqsuh2Qeo,'',619,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_EB4_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع ايجي بيست 4'+ntTrG6PdEqsuh2Qeo,'',809,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]','',157)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_YUT_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع يوتيوب'+ntTrG6PdEqsuh2Qeo,'',149,'','',s2hzmL48wFudNE5)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder','_DLM_'+enfRwbqsd3jlcoGvB0gNXzOC17tFHE+'بحث موقع ديلي موشن'+ntTrG6PdEqsuh2Qeo,'',409,'','',s2hzmL48wFudNE5)
	return
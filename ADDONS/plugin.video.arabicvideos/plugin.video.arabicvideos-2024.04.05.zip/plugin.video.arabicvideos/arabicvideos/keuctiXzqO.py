# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'SHOOFMAX'
eMlwAzaLSj8ZEQ3txIGP = '_SHM_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
kHZn1cEVXyGNTRug3 = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][1]
e7dbD8QN5j4V31os2z9y = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][2]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==50: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==51: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==52: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==53: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==55: mL7BVKcSygkuoPbWlEF4YD = PPwuGbxIlnA7pWC()
	elif mode==56: mL7BVKcSygkuoPbWlEF4YD = RMsmnxyfKD250pWE()
	elif mode==57: mL7BVKcSygkuoPbWlEF4YD = YXDbNkC5xlWPI9anAOsr6uZ(url,1)
	elif mode==58: mL7BVKcSygkuoPbWlEF4YD = YXDbNkC5xlWPI9anAOsr6uZ(url,2)
	elif mode==59: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',59,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المسلسلات','',56)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'الافلام','',55)
	return ''
def PPwuGbxIlnA7pWC():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أفلام مرتبة بسنة الإنتاج',kU2ZXSViB3wLANOz8bH+'/movie/1/yop',57)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أفلام مرتبة بالأفضل تقييم',kU2ZXSViB3wLANOz8bH+'/movie/1/review',57)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أفلام مرتبة بالأكثر مشاهدة',kU2ZXSViB3wLANOz8bH+'/movie/1/views',57)
	return
def RMsmnxyfKD250pWE():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات مرتبة بسنة الإنتاج',kU2ZXSViB3wLANOz8bH+'/series/1/yop',57)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات مرتبة بالأفضل تقييم',kU2ZXSViB3wLANOz8bH+'/series/1/review',57)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسلات مرتبة بالأكثر مشاهدة',kU2ZXSViB3wLANOz8bH+'/series/1/views',57)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url):
	if '?' in url:
		xxyPKEIGHM75VZcR3S2z0Q = url.split('?')
		url = xxyPKEIGHM75VZcR3S2z0Q[0]
		filter = '?' + FVsLwz1tAH(xxyPKEIGHM75VZcR3S2z0Q[1],'=&:/%')
	else: filter = ''
	type,vYpMA3CxgcyR4VZJh,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': bNmWIyOl9Le2xg8BzFthCYT0f1q3Z='فيلم'
		elif type=='series': bNmWIyOl9Le2xg8BzFthCYT0f1q3Z='مسلسل'
		url = kU2ZXSViB3wLANOz8bH + '/genre/filter/' + FVsLwz1tAH(bNmWIyOl9Le2xg8BzFthCYT0f1q3Z) + '/' + vYpMA3CxgcyR4VZJh + '/' + sort + filter
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','SHOOFMAX-TITLES-1st')
		items = JJDtX1PZyIgN2T.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mb72naMO5yPiTHNdGCzIeE=0
		for id,title,PXxp57CRjJnDgaI9NyL430QU2subm,ggdRiBo3smurLUGO in items:
			mb72naMO5yPiTHNdGCzIeE += 1
			ggdRiBo3smurLUGO = e7dbD8QN5j4V31os2z9y + '/v2/img/program/main/' + ggdRiBo3smurLUGO + '-2.jpg'
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH + '/program/' + id
			if type=='movie': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,53,ggdRiBo3smurLUGO)
			if type=='series': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسل '+title,wHiSfdBL1v9Kl3n5+'?ep='+PXxp57CRjJnDgaI9NyL430QU2subm+'='+title+'='+ggdRiBo3smurLUGO,52,ggdRiBo3smurLUGO)
	else:
		if type=='movie': bNmWIyOl9Le2xg8BzFthCYT0f1q3Z='movies'
		elif type=='series': bNmWIyOl9Le2xg8BzFthCYT0f1q3Z='series'
		url = kHZn1cEVXyGNTRug3 + '/json/selected/' + sort + '-' + bNmWIyOl9Le2xg8BzFthCYT0f1q3Z + '-WW.json'
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','SHOOFMAX-TITLES-2nd')
		items = JJDtX1PZyIgN2T.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mb72naMO5yPiTHNdGCzIeE=0
		for id,PXxp57CRjJnDgaI9NyL430QU2subm,ggdRiBo3smurLUGO,title in items:
			mb72naMO5yPiTHNdGCzIeE += 1
			ggdRiBo3smurLUGO = kHZn1cEVXyGNTRug3 + '/img/program/' + ggdRiBo3smurLUGO + '-2.jpg'
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH + '/program/' + id
			if type=='movie': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,53,ggdRiBo3smurLUGO)
			elif type=='series': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'مسلسل '+title,wHiSfdBL1v9Kl3n5+'?ep='+PXxp57CRjJnDgaI9NyL430QU2subm+'='+title+'='+ggdRiBo3smurLUGO,52,ggdRiBo3smurLUGO)
	title='صفحة '
	if mb72naMO5yPiTHNdGCzIeE==16:
		for RNFwDQWO0k3h4 in range(1,13) :
			if not vYpMA3CxgcyR4VZJh==str(RNFwDQWO0k3h4):
				url = kU2ZXSViB3wLANOz8bH+'/genre/filter/'+type+'/'+str(RNFwDQWO0k3h4)+'/'+sort+filter
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title+str(RNFwDQWO0k3h4),url,51)
	return
def sjmSkpqHVtPcv(url):
	xxyPKEIGHM75VZcR3S2z0Q = url.split('=')
	PXxp57CRjJnDgaI9NyL430QU2subm = int(xxyPKEIGHM75VZcR3S2z0Q[1])
	name = i35i6al7upCAreLFQ(xxyPKEIGHM75VZcR3S2z0Q[2])
	name = name.replace('_MOD_مسلسل ','')
	ggdRiBo3smurLUGO = xxyPKEIGHM75VZcR3S2z0Q[3]
	url = url.split('?')[0]
	if PXxp57CRjJnDgaI9NyL430QU2subm==0:
		YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(DkRgFyVIBM85OA,url,'','','','SHOOFMAX-EPISODES-1st')
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('<select(.*?)</select>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('option value="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		PXxp57CRjJnDgaI9NyL430QU2subm = int(items[-1])
	for vaQbluYS4GEsKCNwOymT1hFt in range(PXxp57CRjJnDgaI9NyL430QU2subm,0,-1):
		wHiSfdBL1v9Kl3n5 = url + '?ep=' + str(vaQbluYS4GEsKCNwOymT1hFt)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(vaQbluYS4GEsKCNwOymT1hFt)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,53,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,url,'','','','SHOOFMAX-PLAY-1st')
	CS4f0GzN6ExZsyYgKi9rvJ8m = JJDtX1PZyIgN2T.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if CS4f0GzN6ExZsyYgKi9rvJ8m:
		Mrx2OeZV1LNjBsQ58Savi7 = CS4f0GzN6ExZsyYgKi9rvJ8m[1].replace('T','    ')
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+'\n'+Mrx2OeZV1LNjBsQ58Savi7)
		return
	TZPABp8VeWbvEFzLSkqgHU,ORNWj23cgiJzAw5k = [],[]
	rWRguzmPxIhGfiepEXc = JJDtX1PZyIgN2T.findall('var origin_link = "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	aim3e1yc6AMQJSNl8Wd0CjU2Pq = JJDtX1PZyIgN2T.findall('var backup_origin_link = "(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)[0]
	kwqYoF8han = JJDtX1PZyIgN2T.findall('hls: (.*?)_link\+"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for RgNSOU7P93n,wHiSfdBL1v9Kl3n5 in kwqYoF8han:
		if 'backup' in RgNSOU7P93n:
			RgNSOU7P93n = 'backup server'
			url = aim3e1yc6AMQJSNl8Wd0CjU2Pq + wHiSfdBL1v9Kl3n5
		else:
			RgNSOU7P93n = 'main server'
			url = rWRguzmPxIhGfiepEXc + wHiSfdBL1v9Kl3n5
		if '.m3u8' in url:
			TZPABp8VeWbvEFzLSkqgHU.append(url)
			ORNWj23cgiJzAw5k.append('m3u8  '+RgNSOU7P93n)
	kwqYoF8han = JJDtX1PZyIgN2T.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	kwqYoF8han += JJDtX1PZyIgN2T.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for RgNSOU7P93n,wHiSfdBL1v9Kl3n5 in kwqYoF8han:
		filename = wHiSfdBL1v9Kl3n5.split('/')[-1]
		filename = filename.replace('fallback','')
		filename = filename.replace('.mp4','')
		filename = filename.replace('-','')
		if 'backup' in RgNSOU7P93n:
			RgNSOU7P93n = 'backup server'
			url = aim3e1yc6AMQJSNl8Wd0CjU2Pq + wHiSfdBL1v9Kl3n5
		else:
			RgNSOU7P93n = 'main server'
			url = rWRguzmPxIhGfiepEXc + wHiSfdBL1v9Kl3n5
		TZPABp8VeWbvEFzLSkqgHU.append(url)
		ORNWj23cgiJzAw5k.append('mp4  '+RgNSOU7P93n+'  '+filename)
	zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('Select Video Quality:', ORNWj23cgiJzAw5k)
	if zKgFfQoODy90ewYb5jGElUJRVs4p == -1 : return
	url = TZPABp8VeWbvEFzLSkqgHU[zKgFfQoODy90ewYb5jGElUJRVs4p]
	XbzQHGJ0cBV(url,FpjtBKrnu5SdfyOvEPIQ,'video')
	return
def YXDbNkC5xlWPI9anAOsr6uZ(url,type):
	if 'series' in url: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH + '/genre/مسلسل'
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kU2ZXSViB3wLANOz8bH + '/genre/فيلم'
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FVsLwz1tAH(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
	YBEsLq8gVw629cMGQP1T = c6ZsDfYqVo(UHnG2wYuIQWKN38B4,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'','','','SHOOFMAX-FILTERS-1st')
	if type==1: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('subgenre(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	elif type==2: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('country(.*?)div',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('option value="(.*?)">(.*?)</option',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if type==1:
		for UVjpTt74B0Y,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url+'?subgenre='+UVjpTt74B0Y,58)
	elif type==2:
		url,UVjpTt74B0Y = url.split('?')
		for QfZp1nrE5iHgVD60I,title in items:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url+'?country='+QfZp1nrE5iHgVD60I+'&'+UVjpTt74B0Y,51)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search: search = GVfnMyZxiRI()
	if not search: return
	s2hzmL48wFudNE5 = search.replace(' ','%20')
	url = kU2ZXSViB3wLANOz8bH+'/search?q='+s2hzmL48wFudNE5
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','',True,'','SHOOFMAX-SEARCH-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('general-body(.*?)search-bottom-padding',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	if items:
		for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
			url = kU2ZXSViB3wLANOz8bH + wHiSfdBL1v9Kl3n5
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+FVsLwz1tAH(title)+'='+ggdRiBo3smurLUGO
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,url,52,ggdRiBo3smurLUGO)
				else:
					title = '_MOD_فيلم '+title
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,url,53,ggdRiBo3smurLUGO)
	return
# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'ARABSEED'
headers = {'User-Agent':yyYKmdtsAFic93()}
eMlwAzaLSj8ZEQ3txIGP = '_ARS_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==250: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==251: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,text)
	elif mode==252: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==253: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==254: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'CATEGORIES___'+text)
	elif mode==255: mL7BVKcSygkuoPbWlEF4YD = c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,'FILTERS___'+text)
	elif mode==256: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url,text)
	elif mode==259: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH+'/main','',headers,'','','ARABSEED-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',259,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر محدد',kU2ZXSViB3wLANOz8bH+'/category/اخرى',254)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر كامل',kU2ZXSViB3wLANOz8bH+'/category/اخرى',255)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',kU2ZXSViB3wLANOz8bH+'/main',251,'','','featured_main')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'جديد الأفلام',kU2ZXSViB3wLANOz8bH+'/main',251,'','','new_movies')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'جديد الحلقات',kU2ZXSViB3wLANOz8bH+'/main',251,'','','new_episodes')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'المضاف حديثاً',kU2ZXSViB3wLANOz8bH+'/latest',251,'','','lastest')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	ooTeU5chRPu = JJDtX1PZyIgN2T.findall('class="MenuHeader"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	DqrOZE3L85G = ooTeU5chRPu[0]
	uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)<',DqrOZE3L85G,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in uaq5LNOdZJhV4fDwvcsnU17WrX:
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if title not in eJzpdvc3KTust and title!='':
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,256)
	return YBEsLq8gVw629cMGQP1T
def YsCotEfMBv03z7mg(url,type):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','ARABSEED-SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if 'class="SliderInSection' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الأكثر مشاهدة',url,251,'','','most')
	if 'class="MainSlides' in YBEsLq8gVw629cMGQP1T: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'المميزة',url,251,'','','featured')
	if 'class="LinksList' in YBEsLq8gVw629cMGQP1T:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="LinksList(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			if len(GGbRgKaoskDC)>1 and type=='new_episodes': mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[1]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)"(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				LpB4ilMr6vVtQ = JJDtX1PZyIgN2T.findall('</i>(.*?)<span>(.*?)<',title,JJDtX1PZyIgN2T.DOTALL)
				try: XXsM6FBxqztKRYyAlvD = LpB4ilMr6vVtQ[0][0]
				except: XXsM6FBxqztKRYyAlvD = ''
				try: VV8BiSNPTyX2rgQ4mHIf6xLk = LpB4ilMr6vVtQ[0][1]
				except: VV8BiSNPTyX2rgQ4mHIf6xLk = ''
				LpB4ilMr6vVtQ = XXsM6FBxqztKRYyAlvD+VV8BiSNPTyX2rgQ4mHIf6xLk
				LpB4ilMr6vVtQ = LpB4ilMr6vVtQ.replace('\n','')
				if '<strong>' in title:
					X3pyfvgDUaTweLY7NMbzPG = JJDtX1PZyIgN2T.findall('</i>(.*?)<',title,JJDtX1PZyIgN2T.DOTALL)
					if X3pyfvgDUaTweLY7NMbzPG: LpB4ilMr6vVtQ = X3pyfvgDUaTweLY7NMbzPG[0]
				if not LpB4ilMr6vVtQ:
					X3pyfvgDUaTweLY7NMbzPG = JJDtX1PZyIgN2T.findall('alt="(.*?)"',title,JJDtX1PZyIgN2T.DOTALL)
					if X3pyfvgDUaTweLY7NMbzPG: LpB4ilMr6vVtQ = X3pyfvgDUaTweLY7NMbzPG[0]
				if LpB4ilMr6vVtQ:
					if 'key=' in wHiSfdBL1v9Kl3n5: type = wHiSfdBL1v9Kl3n5.split('key=')[1]
					else: type = 'newest'
					LpB4ilMr6vVtQ = LpB4ilMr6vVtQ.strip(' ')
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,wHiSfdBL1v9Kl3n5,251,'','',type)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type):
	OtZMsjvzwxUWF,data,items = 'GET','',[]
	if type=='filters':
		if '?' in url:
			nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3,Gv7mT0LhB9YoOVpANMr = 'POST',{}
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO,SzY7aqbnEvWVi9xo5POl1BFK = url.split('?')
			tBFLs10gh4MQyeXa5xSnqlPWdE = SzY7aqbnEvWVi9xo5POl1BFK.split('&')
			for dSvlymbao9Zs6t in tBFLs10gh4MQyeXa5xSnqlPWdE:
				key,Y3YqSmycrIWksoH5N0MvC = dSvlymbao9Zs6t.split('=')
				Gv7mT0LhB9YoOVpANMr[key] = Y3YqSmycrIWksoH5N0MvC
			if tBFLs10gh4MQyeXa5xSnqlPWdE: OtZMsjvzwxUWF,url,data = nHvYuFmBACIo6qrLa1wz2ZcNi4Gj3,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,OtZMsjvzwxUWF,url,data,headers,'','','ARABSEED-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	if type=='filters': GGbRgKaoskDC = [YBEsLq8gVw629cMGQP1T]
	elif 'featured' in type: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="MainSlides(.*?)class="LinksList',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	elif type=='new_movies': GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	elif type=='new_episodes': GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	elif type=='most': GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="SliderInSection(.*?)class="LinksList',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	else: GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="Blocks-UL"(.*?)class="AboElSeed"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if 'featured' in type:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		gT0RPc1dtMWS3sJmyKGjul6 = JJDtX1PZyIgN2T.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if gT0RPc1dtMWS3sJmyKGjul6:
			EEgFl59RndzrBL8TUoaQMw6P,JCop4mjTiurYB7W,ZiVcUuAQO2g,PGsuVjve4kTXx8rM = zip(*gT0RPc1dtMWS3sJmyKGjul6)
			items = zip(EEgFl59RndzrBL8TUoaQMw6P,PGsuVjve4kTXx8rM,JCop4mjTiurYB7W)
	else:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	ClXwqHm0DEMvI39agWyiRYopQ = []
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		if 'WWE' in title: continue
		title = jbigKDeUf0OSMrRkly2B5I3Act(title)
		if 'الحلقة' in title:
			vaQbluYS4GEsKCNwOymT1hFt = JJDtX1PZyIgN2T.findall('(.*?) الحلقة \d+',title,JJDtX1PZyIgN2T.DOTALL)
			if vaQbluYS4GEsKCNwOymT1hFt:
				title = '_MOD_' + vaQbluYS4GEsKCNwOymT1hFt[0]
				if title not in ClXwqHm0DEMvI39agWyiRYopQ:
					ClXwqHm0DEMvI39agWyiRYopQ.append(title)
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,253,ggdRiBo3smurLUGO)
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,252,ggdRiBo3smurLUGO)
		elif '/selary/' in wHiSfdBL1v9Kl3n5 or 'مسلسل' in title:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,253,ggdRiBo3smurLUGO)
		else:
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,252,ggdRiBo3smurLUGO)
	if type in ['newest','best','most']:
		items = JJDtX1PZyIgN2T.findall('page-numbers" href="(.*?)">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			wHiSfdBL1v9Kl3n5 = jbigKDeUf0OSMrRkly2B5I3Act(wHiSfdBL1v9Kl3n5)
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,251,'','',type)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'',headers,'','','ARABSEED-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	YBEsLq8gVw629cMGQP1T = YBEsLq8gVw629cMGQP1T[10000:]
	items = JJDtX1PZyIgN2T.findall('data-src="(.*?)".*?alt="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if not items: return
	ggdRiBo3smurLUGO,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(' ')
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(' ')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="ContainerEpisodesList"(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<em>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,vaQbluYS4GEsKCNwOymT1hFt in items:
			title = name+' - الحلقة رقم '+vaQbluYS4GEsKCNwOymT1hFt
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,252,ggdRiBo3smurLUGO)
	else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+'ملف التشغيل',url,252,ggdRiBo3smurLUGO)
	return
def mJznWZtXx3D5SMqVY9B6KLRCOHrh1(title,wHiSfdBL1v9Kl3n5):
	LpB4ilMr6vVtQ = JJDtX1PZyIgN2T.findall('[a-zA-Z-]+',title,JJDtX1PZyIgN2T.DOTALL)
	if LpB4ilMr6vVtQ: title = LpB4ilMr6vVtQ[0]
	else: title = title+' '+OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
	title = title.replace('عرب سيد','').replace('مباشر','').replace('مشاهدة','')
	title = title.replace('ٍ','')
	title = title.replace('  ',' ').replace('  ',' ')
	return title
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',url,'',headers,'','','ARABSEED-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = SSzrgUnfVGL1hQsu40FoP7CWXax.url
	RgNSOU7P93n = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'url')
	headers['Referer'] = RgNSOU7P93n+'/'
	j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1,ux2gEibkBjJQeWAPt3no,EEgFl59RndzrBL8TUoaQMw6P = '','',[]
	kJB2jHf7c5pLIEUDF8YuzoPb = JJDtX1PZyIgN2T.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if kJB2jHf7c5pLIEUDF8YuzoPb: j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1,bNmWIyOl9Le2xg8BzFthCYT0f1q3Z,ux2gEibkBjJQeWAPt3no,pnF0HTjGdfAleEZ4hRYwS = kJB2jHf7c5pLIEUDF8YuzoPb[0]
	else:
		kJB2jHf7c5pLIEUDF8YuzoPb = JJDtX1PZyIgN2T.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if kJB2jHf7c5pLIEUDF8YuzoPb:
			wHiSfdBL1v9Kl3n5,bNmWIyOl9Le2xg8BzFthCYT0f1q3Z = kJB2jHf7c5pLIEUDF8YuzoPb[0]
			if 'watch' in bNmWIyOl9Le2xg8BzFthCYT0f1q3Z: j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1 = wHiSfdBL1v9Kl3n5
			else: ux2gEibkBjJQeWAPt3no = wHiSfdBL1v9Kl3n5
	if j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',j6Jl2x8qh9Kdg3m7pRW4GtXHvUPb1,'',headers,'','','ARABSEED-PLAY-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="WatcherArea"(.*?</ul>)',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			bKQgRXcoFDwWHStiMJPezmB5Nudnhs = GGbRgKaoskDC[0]
			bKQgRXcoFDwWHStiMJPezmB5Nudnhs = bKQgRXcoFDwWHStiMJPezmB5Nudnhs.replace('</ul>','<h3>')
			bKQgRXcoFDwWHStiMJPezmB5Nudnhs = bKQgRXcoFDwWHStiMJPezmB5Nudnhs.replace('<h3>','<h3><h3>')
			Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('<h3>.*?(\d+)(.*?)<h3>',bKQgRXcoFDwWHStiMJPezmB5Nudnhs,JJDtX1PZyIgN2T.DOTALL)
			if not Ns3LKUFY21aQVf7e: Ns3LKUFY21aQVf7e = [('',bKQgRXcoFDwWHStiMJPezmB5Nudnhs)]
			for y2nBfLCjDoXkKiwb8WV6,mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
				if y2nBfLCjDoXkKiwb8WV6: y2nBfLCjDoXkKiwb8WV6 = '____'+y2nBfLCjDoXkKiwb8WV6
				items = JJDtX1PZyIgN2T.findall('data-link="(.*?)".*?<span>(.*?)</span>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,name in items:
					if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = 'http:'+wHiSfdBL1v9Kl3n5
					wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__watch'+y2nBfLCjDoXkKiwb8WV6
					EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
		kwqYoF8han = JJDtX1PZyIgN2T.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if not kwqYoF8han: kwqYoF8han = JJDtX1PZyIgN2T.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if kwqYoF8han:
			wHiSfdBL1v9Kl3n5,y2nBfLCjDoXkKiwb8WV6 = kwqYoF8han[0]
			name = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
			if '%' in y2nBfLCjDoXkKiwb8WV6: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__embed__'
			else: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+name+'__embed____'+y2nBfLCjDoXkKiwb8WV6
			EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	if ux2gEibkBjJQeWAPt3no:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',ux2gEibkBjJQeWAPt3no,'',headers,'','','ARABSEED-PLAY-3rd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="DownloadArea"(.*?)function',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title,y2nBfLCjDoXkKiwb8WV6 in items:
				if not wHiSfdBL1v9Kl3n5: continue
				if 'reviewstation' in wHiSfdBL1v9Kl3n5: continue
				wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
				wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'?named='+title+'__download____'+y2nBfLCjDoXkKiwb8WV6
				EEgFl59RndzrBL8TUoaQMw6P.append(wHiSfdBL1v9Kl3n5)
	lldNiPcer7ELO1QnMjC = str(EEgFl59RndzrBL8TUoaQMw6P)
	YJaE3eoXzUQq9nO = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(Y3YqSmycrIWksoH5N0MvC in lldNiPcer7ELO1QnMjC for Y3YqSmycrIWksoH5N0MvC in YJaE3eoXzUQq9nO):
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l('','','رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(EEgFl59RndzrBL8TUoaQMw6P,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search: search = GVfnMyZxiRI()
	if not search: return
	search = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/find/?find='+search
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
def c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter=='': u7fXcTJNB8djwxR6yS,oju0BC1rJO = '',''
	else: u7fXcTJNB8djwxR6yS,oju0BC1rJO = filter.split('___')
	if type=='CATEGORIES':
		if qsd31N2pf9IyitMCSleF4[0]+'==' not in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = qsd31N2pf9IyitMCSleF4[0]
		for ggjo5zu7yCiIOhrb in range(len(qsd31N2pf9IyitMCSleF4[0:-1])):
			if qsd31N2pf9IyitMCSleF4[ggjo5zu7yCiIOhrb]+'==' in u7fXcTJNB8djwxR6yS: qGsE8fdyFtUwBnu = qsd31N2pf9IyitMCSleF4[ggjo5zu7yCiIOhrb+1]
		fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+qGsE8fdyFtUwBnu+'==0'
		VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+qGsE8fdyFtUwBnu+'==0'
		ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU.strip('&&')+'___'+VQZDwq9mu4jrB1gPlcWOxyF.strip('&&')
		ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'//getposts??'+ssnIblOr0uX
	elif type=='FILTERS':
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = AwEJ3H0CYstpiWTQ59(u7fXcTJNB8djwxR6yS,'modified_values')
		EnJ64ZLoMNvGsgpP9lauxXSkftQ7b = i35i6al7upCAreLFQ(EnJ64ZLoMNvGsgpP9lauxXSkftQ7b)
		if oju0BC1rJO!='': oju0BC1rJO = AwEJ3H0CYstpiWTQ59(oju0BC1rJO,'modified_filters')
		if oju0BC1rJO=='': FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url+'//getposts??'+oju0BC1rJO
		XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'أظهار قائمة الفيديو التي تم اختيارها ',XTNUWlZgoH,251,'','','filters')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+' [[   '+EnJ64ZLoMNvGsgpP9lauxXSkftQ7b+'   ]]',XTNUWlZgoH,251,'','','filters')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'POST',url,'',headers,'','','ARABSEED-FILTERS_MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	MINndQ1AEjoR7GcapsHCrlzKt = JJDtX1PZyIgN2T.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	BQ1faRrdTDXlV0xyN4OEsJAW = JJDtX1PZyIgN2T.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	KKMpOd0rWFRNPtun5cgY6 = MINndQ1AEjoR7GcapsHCrlzKt+BQ1faRrdTDXlV0xyN4OEsJAW
	dict = {}
	for name,eYFHT1CfSqZK,mvgk7pP8Fw6heMSWd5oXn9itl in KKMpOd0rWFRNPtun5cgY6:
		items = JJDtX1PZyIgN2T.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			uaq5LNOdZJhV4fDwvcsnU17WrX = JJDtX1PZyIgN2T.findall('data-rate="(.*?)".*?<em>(.*?)</em>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			items = []
			for khB9dCpWm4qPMrXTjgONf0Z,Y3YqSmycrIWksoH5N0MvC in uaq5LNOdZJhV4fDwvcsnU17WrX: items.append([khB9dCpWm4qPMrXTjgONf0Z,'',Y3YqSmycrIWksoH5N0MvC])
			eYFHT1CfSqZK = 'rate'
			name = 'التقييم'
		else: eYFHT1CfSqZK = items[0][1]
		if '==' not in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO = url
		if type=='CATEGORIES':
			if qGsE8fdyFtUwBnu!=eYFHT1CfSqZK: continue
			elif len(items)<=1:
				if eYFHT1CfSqZK==qsd31N2pf9IyitMCSleF4[-1]: d2JXnUMPmgsKBQqCE58lkZ(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				else: c7EVfnkA5dW4YGIe6bPSMwHijDBQZs(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,'CATEGORIES___'+ekFcZbonSHxsBqC7MU8hV)
				return
			else:
				XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(FrC9LhHZWIySdGwNsuzqt5Rf01TXO)
				if eYFHT1CfSqZK==qsd31N2pf9IyitMCSleF4[-1]: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',XTNUWlZgoH,251,'','','filters')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع ',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,254,'','',ekFcZbonSHxsBqC7MU8hV)
		elif type=='FILTERS':
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+eYFHT1CfSqZK+'==0'
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+eYFHT1CfSqZK+'==0'
			ekFcZbonSHxsBqC7MU8hV = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الجميع :'+name,FrC9LhHZWIySdGwNsuzqt5Rf01TXO,255,'','',ekFcZbonSHxsBqC7MU8hV)
		dict[eYFHT1CfSqZK] = {}
		for khB9dCpWm4qPMrXTjgONf0Z,g5lf2u4DxNp8imnYevK,Y3YqSmycrIWksoH5N0MvC in items:
			if khB9dCpWm4qPMrXTjgONf0Z in eJzpdvc3KTust: continue
			if 'الكل' in khB9dCpWm4qPMrXTjgONf0Z: continue
			khB9dCpWm4qPMrXTjgONf0Z = jbigKDeUf0OSMrRkly2B5I3Act(khB9dCpWm4qPMrXTjgONf0Z)
			XVD2KB3xEJaU1stlpjP4kmo,LpB4ilMr6vVtQ = khB9dCpWm4qPMrXTjgONf0Z,khB9dCpWm4qPMrXTjgONf0Z
			LpB4ilMr6vVtQ = name+': '+XVD2KB3xEJaU1stlpjP4kmo
			dict[eYFHT1CfSqZK][Y3YqSmycrIWksoH5N0MvC] = LpB4ilMr6vVtQ
			fHvtraZ5LWU = u7fXcTJNB8djwxR6yS+'&&'+eYFHT1CfSqZK+'=='+XVD2KB3xEJaU1stlpjP4kmo
			VQZDwq9mu4jrB1gPlcWOxyF = oju0BC1rJO+'&&'+eYFHT1CfSqZK+'=='+Y3YqSmycrIWksoH5N0MvC
			oy5AiZKfC86qITkYWL = fHvtraZ5LWU+'___'+VQZDwq9mu4jrB1gPlcWOxyF
			if type=='FILTERS':
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url,255,'','',oy5AiZKfC86qITkYWL)
			elif type=='CATEGORIES' and qsd31N2pf9IyitMCSleF4[-2]+'==' in u7fXcTJNB8djwxR6yS:
				ssnIblOr0uX = AwEJ3H0CYstpiWTQ59(VQZDwq9mu4jrB1gPlcWOxyF,'modified_filters')
				kHWT0XY2S6apruwxiB8FDl1 = url+'//getposts??'+ssnIblOr0uX
				XTNUWlZgoH = WAlh0r2supMG4Jzb3RfcwmF(kHWT0XY2S6apruwxiB8FDl1)
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,XTNUWlZgoH,251,'','','filters')
			else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+LpB4ilMr6vVtQ,url,254,'','',oy5AiZKfC86qITkYWL)
	return
qsd31N2pf9IyitMCSleF4 = ['category','country','release-year']
m4mRIeW8Od9ByfuMKHv = ['category','country','genre','release-year','language','quality','rate']
def WAlh0r2supMG4Jzb3RfcwmF(url):
	BrYq1NHEvaVL = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',BrYq1NHEvaVL)
	url = url.replace('/category/اخرى','')
	if BrYq1NHEvaVL not in url: url = url+BrYq1NHEvaVL
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def AwEJ3H0CYstpiWTQ59(t9hx8YmpUDaFivZ,mode):
	t9hx8YmpUDaFivZ = t9hx8YmpUDaFivZ.strip('&&')
	bHErtloWDJ3YCFvSfqLN1e7IVh,P1yxuh7MAmvSRVqLZcW6tY3 = {},''
	if '==' in t9hx8YmpUDaFivZ:
		items = t9hx8YmpUDaFivZ.split('&&')
		for KxB8vVHUJg in items:
			DeC6ZNvQia8kdOonwqM3cEflB,Y3YqSmycrIWksoH5N0MvC = KxB8vVHUJg.split('==')
			bHErtloWDJ3YCFvSfqLN1e7IVh[DeC6ZNvQia8kdOonwqM3cEflB] = Y3YqSmycrIWksoH5N0MvC
	for key in m4mRIeW8Od9ByfuMKHv:
		if key in list(bHErtloWDJ3YCFvSfqLN1e7IVh.keys()): Y3YqSmycrIWksoH5N0MvC = bHErtloWDJ3YCFvSfqLN1e7IVh[key]
		else: Y3YqSmycrIWksoH5N0MvC = '0'
		if '%' not in Y3YqSmycrIWksoH5N0MvC: Y3YqSmycrIWksoH5N0MvC = FVsLwz1tAH(Y3YqSmycrIWksoH5N0MvC)
		if mode=='modified_values' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+' + '+Y3YqSmycrIWksoH5N0MvC
		elif mode=='modified_filters' and Y3YqSmycrIWksoH5N0MvC!='0': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&&'+key+'=='+Y3YqSmycrIWksoH5N0MvC
		elif mode=='all': P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3+'&&'+key+'=='+Y3YqSmycrIWksoH5N0MvC
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip(' + ')
	P1yxuh7MAmvSRVqLZcW6tY3 = P1yxuh7MAmvSRVqLZcW6tY3.strip('&&')
	return P1yxuh7MAmvSRVqLZcW6tY3
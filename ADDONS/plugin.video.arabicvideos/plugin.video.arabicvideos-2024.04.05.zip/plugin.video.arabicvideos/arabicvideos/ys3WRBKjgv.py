# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'EGYBEST4'
eMlwAzaLSj8ZEQ3txIGP = '_EB4_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
eJzpdvc3KTust = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def HYWukw3pL2oMzPK4(mode,url,vYpMA3CxgcyR4VZJh,text):
	if   mode==800: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==801: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url,vYpMA3CxgcyR4VZJh)
	elif mode==802: mL7BVKcSygkuoPbWlEF4YD = YsCotEfMBv03z7mg(url)
	elif mode==803: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==804: mL7BVKcSygkuoPbWlEF4YD = YXDbNkC5xlWPI9anAOsr6uZ(url)
	elif mode==806: mL7BVKcSygkuoPbWlEF4YD = gaJo6Sm8HMP2jKrnBd(url,vYpMA3CxgcyR4VZJh)
	elif mode==809: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',809,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'فلتر',kU2ZXSViB3wLANOz8bH+'/trending',804,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(UHnG2wYuIQWKN38B4,'GET',kU2ZXSViB3wLANOz8bH,'','','','','EGYBEST4-MENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('nav-categories(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('mainContent(.*?)<footer>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801,'','mainmenu')
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('main-menu(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			title = title.strip(' ')
			if any(Y3YqSmycrIWksoH5N0MvC in title for Y3YqSmycrIWksoH5N0MvC in eJzpdvc3KTust): continue
			if 'http' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+wHiSfdBL1v9Kl3n5
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801)
	return YBEsLq8gVw629cMGQP1T
def gaJo6Sm8HMP2jKrnBd(url,type=''):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST4-SEASONS_EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('mainTitle.*?>(.*?)<(.*?)pageContent',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		YbPTE4rKt3cmIuz6WFdi,l7PwAhTqWVUKME,items = '','',[]
		for name,mvgk7pP8Fw6heMSWd5oXn9itl in GGbRgKaoskDC:
			if 'حلقات' in name: l7PwAhTqWVUKME = mvgk7pP8Fw6heMSWd5oXn9itl
			if 'مواسم' in name: YbPTE4rKt3cmIuz6WFdi = mvgk7pP8Fw6heMSWd5oXn9itl
		if YbPTE4rKt3cmIuz6WFdi and not type:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',YbPTE4rKt3cmIuz6WFdi,JJDtX1PZyIgN2T.DOTALL)
			if len(items)>1:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,806,ggdRiBo3smurLUGO,'season')
		if l7PwAhTqWVUKME and len(items)<2:
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
			if items:
				for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,803,ggdRiBo3smurLUGO)
			else:
				items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',l7PwAhTqWVUKME,JJDtX1PZyIgN2T.DOTALL)
				for wHiSfdBL1v9Kl3n5,title in items:
					nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,803)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url,type=''):
	ePYyKi25Bz3ZUWJtg0Ec,start,pnF0HTjGdfAleEZ4hRYwS,select,XlxyTN169IVSM0d8pGObBYuihr4H = 0,0,'','',''
	if 'pagination' in type:
		kuzMYsL84xH3lbUhc,Gv7mT0LhB9YoOVpANMr = url.split('?next=page&')
		JZP07kjvbV = {'Content-Type':'application/x-www-form-urlencoded'}
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'POST',kuzMYsL84xH3lbUhc,Gv7mT0LhB9YoOVpANMr,JZP07kjvbV,'','','EGYBEST4-TITLES-1st')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		Plj7MGOHohwdvam2ynfVY1z = 'secContent'+YBEsLq8gVw629cMGQP1T+'<footer>'
	else:
		SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST4-TITLES-2nd')
		YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
		Plj7MGOHohwdvam2ynfVY1z = YBEsLq8gVw629cMGQP1T
	items,NbI4DJ3rWOwRj,t9hx8YmpUDaFivZ = [],False,False
	if not type and '/collections' not in url:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('mainContent(.*?)</div>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?</i>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,title in items:
				title = title.strip(' ')
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801,'','submenu')
				NbI4DJ3rWOwRj = True
	if not NbI4DJ3rWOwRj:
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('secContent(.*?)mainContent',Plj7MGOHohwdvam2ynfVY1z,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
				wHiSfdBL1v9Kl3n5 = i35i6al7upCAreLFQ(wHiSfdBL1v9Kl3n5)
				ggdRiBo3smurLUGO = ggdRiBo3smurLUGO.strip('\n')
				title = jbigKDeUf0OSMrRkly2B5I3Act(title)
				if '/series/' in wHiSfdBL1v9Kl3n5 and type=='season': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,806,ggdRiBo3smurLUGO,'season')
				elif '/series/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,806,ggdRiBo3smurLUGO)
				elif '/seasons/' in wHiSfdBL1v9Kl3n5: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801,ggdRiBo3smurLUGO,'season')
				elif '/collections' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801,ggdRiBo3smurLUGO,'collections')
				else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,803,ggdRiBo3smurLUGO)
		GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('loadMoreParams = (.*?);',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
		if GGbRgKaoskDC:
			mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
			x2CNeEUiP4WYBMVRFIl = G8EwoDOyKShm1i0IHMfNYZlU7('dict',mvgk7pP8Fw6heMSWd5oXn9itl)
			XlxyTN169IVSM0d8pGObBYuihr4H = x2CNeEUiP4WYBMVRFIl['ajaxurl']
			GHwMQ6AEyDKr3LuYheqRFkOWJg12C = int(x2CNeEUiP4WYBMVRFIl['current_page'])+1
			Z0Z41RKTBVC = int(x2CNeEUiP4WYBMVRFIl['max_page'])
			TthaRsEXcbWquzUg = x2CNeEUiP4WYBMVRFIl['posts'].replace('False','false').replace('True','true').replace('None','null')
			if GHwMQ6AEyDKr3LuYheqRFkOWJg12C<Z0Z41RKTBVC:
				Gv7mT0LhB9YoOVpANMr = 'action=loadmore&query='+FVsLwz1tAH(TthaRsEXcbWquzUg,'')+'&page='+str(GHwMQ6AEyDKr3LuYheqRFkOWJg12C)
				FrC9LhHZWIySdGwNsuzqt5Rf01TXO = XlxyTN169IVSM0d8pGObBYuihr4H+'?next=page&'+Gv7mT0LhB9YoOVpANMr
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'جلب المزيد',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,801,'','pagination_'+type)
		elif '?next=page&' in url:
			Gv7mT0LhB9YoOVpANMr,zzMCtO8apGR3A5H9jL4wNulv0 = Gv7mT0LhB9YoOVpANMr.rsplit('=',1)
			zzMCtO8apGR3A5H9jL4wNulv0 = int(zzMCtO8apGR3A5H9jL4wNulv0)+1
			FrC9LhHZWIySdGwNsuzqt5Rf01TXO = kuzMYsL84xH3lbUhc+'?next=page&'+Gv7mT0LhB9YoOVpANMr+'='+str(zzMCtO8apGR3A5H9jL4wNulv0)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'جلب المزيد',FrC9LhHZWIySdGwNsuzqt5Rf01TXO,801,'','pagination_'+type)
	return
def YXDbNkC5xlWPI9anAOsr6uZ(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','EGYBEST4-FILTERS-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('sub_nav(.*?)secContent ',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		Ns3LKUFY21aQVf7e = JJDtX1PZyIgN2T.findall('"current_opt">(.*?)<(.*?)</div>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for name,mvgk7pP8Fw6heMSWd5oXn9itl in Ns3LKUFY21aQVf7e:
			if 'التصنيف' in name: continue
			name = name.strip(' ')
			items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
			for wHiSfdBL1v9Kl3n5,Y3YqSmycrIWksoH5N0MvC in items:
				title = name+':  '+Y3YqSmycrIWksoH5N0MvC
				nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,801,'','filter')
	return
def CsUdRabWuh0M9F(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'GET',url,'','','','','EGYBEST4-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	lAnLtvg62C = JJDtX1PZyIgN2T.findall('<td>التصنيف</td>.*?">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if lAnLtvg62C and t1O7yDIEwKeSxBjCJMRAlnq(FpjtBKrnu5SdfyOvEPIQ,url,lAnLtvg62C): return
	pB8XANf71vaPJsedkWVIc5,uiUZAmal9HPqQSo = [],[]
	ssVDJcjMaZ = JJDtX1PZyIgN2T.findall('postEmbed.*?post=(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if ssVDJcjMaZ:
		kwqYoF8han = gPSZVjJHKIL.b64decode(ssVDJcjMaZ[0])
		if DQfHadYvTpy1UR: kwqYoF8han = kwqYoF8han.decode('utf8')
		kwqYoF8han = G8EwoDOyKShm1i0IHMfNYZlU7('dict',kwqYoF8han)
		kwqYoF8han = list(kwqYoF8han.values())
		for wHiSfdBL1v9Kl3n5 in kwqYoF8han:
			if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
				uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
				RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__watch')
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('pageContentDown(.*?)</table>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for y2nBfLCjDoXkKiwb8WV6,wHiSfdBL1v9Kl3n5 in items:
			if wHiSfdBL1v9Kl3n5 not in uiUZAmal9HPqQSo:
				if '/?url=' in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5.split('/?url=')[1]
				uiUZAmal9HPqQSo.append(wHiSfdBL1v9Kl3n5)
				RgNSOU7P93n = OfTKisDR0Lv(wHiSfdBL1v9Kl3n5,'name')
				pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named='+RgNSOU7P93n+'__download____'+y2nBfLCjDoXkKiwb8WV6)
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if not search: search = GVfnMyZxiRI()
	if not search: return
	s2hzmL48wFudNE5 = search.replace(' ','+')
	url = kU2ZXSViB3wLANOz8bH+'/?s='+s2hzmL48wFudNE5
	d2JXnUMPmgsKBQqCE58lkZ(url,'search')
	return
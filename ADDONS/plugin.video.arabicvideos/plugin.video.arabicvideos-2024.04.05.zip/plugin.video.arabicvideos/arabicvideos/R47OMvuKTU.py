# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
from PIL import ImageDraw as rAtkoeldGFvTLWOn7,ImageFont as V47MU09QYBNxTjHF,Image as y7Pbr6RV0Gij
from arabic_reshaper import ArabicReshaper as ybB0jav3ohZ
s1ITpY2ghtCvR3mSXkFVBnlL8 = 'EXCLUDES'
def r5CWGms7jh(rBabYANvVwWzjCp2QF,oDG72BMvJEhKd):
	oDG72BMvJEhKd = oDG72BMvJEhKd.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	uNkSdfX1V5Pn = JJDtX1PZyIgN2T.findall('[a-zA-Z]',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
	if 'بحث IPTV - ' in rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('بحث IPTV - ',SBPbYXN9Rt2MHDrnU4mhlV0+'بحث IPTV - '+SBPbYXN9Rt2MHDrnU4mhlV0)
	elif ' IPTV' in rBabYANvVwWzjCp2QF and oDG72BMvJEhKd=='IPT': rBabYANvVwWzjCp2QF = SBPbYXN9Rt2MHDrnU4mhlV0+rBabYANvVwWzjCp2QF
	elif 'بحث M3U - ' in rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('بحث M3U - ',SBPbYXN9Rt2MHDrnU4mhlV0+'بحث M3U - '+SBPbYXN9Rt2MHDrnU4mhlV0)
	elif ' M3U' in rBabYANvVwWzjCp2QF and oDG72BMvJEhKd=='M3U': rBabYANvVwWzjCp2QF = SBPbYXN9Rt2MHDrnU4mhlV0+rBabYANvVwWzjCp2QF
	elif 'بحث ' in rBabYANvVwWzjCp2QF and ' - ' in rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = SBPbYXN9Rt2MHDrnU4mhlV0+rBabYANvVwWzjCp2QF
	elif not uNkSdfX1V5Pn:
		tacjWQrhpZL148CiPMv = JJDtX1PZyIgN2T.findall('^( *?)(.*?)( *?)$',rBabYANvVwWzjCp2QF)
		BIDYmL32axyP4Oktl9wS6,llaHvD0cUthbj28xZMqdBCJ,lFC4ikmq0cdTVL59y8rztUG1ao = tacjWQrhpZL148CiPMv[0]
		OONgvsrypw9cbElzQ = JJDtX1PZyIgN2T.findall('^([!-~])',llaHvD0cUthbj28xZMqdBCJ)
		if OONgvsrypw9cbElzQ: rBabYANvVwWzjCp2QF = BIDYmL32axyP4Oktl9wS6+ccdMiA5sZ0koIRwpFgeU8j+llaHvD0cUthbj28xZMqdBCJ+lFC4ikmq0cdTVL59y8rztUG1ao
		else: rBabYANvVwWzjCp2QF = lFC4ikmq0cdTVL59y8rztUG1ao+SBPbYXN9Rt2MHDrnU4mhlV0+llaHvD0cUthbj28xZMqdBCJ+BIDYmL32axyP4Oktl9wS6
	else:
		if 1:
			xnd17qtNy6aOs09jDEG = rBabYANvVwWzjCp2QF
			nKDhY4cAk1lBzPR = Asxc8GDnudJm.get_display(rBabYANvVwWzjCp2QF,base_dir='L')
			if wIqFesTOvYnu5S2dWfpBVC: xnd17qtNy6aOs09jDEG = xnd17qtNy6aOs09jDEG.decode('utf8')
			if wIqFesTOvYnu5S2dWfpBVC: nKDhY4cAk1lBzPR = nKDhY4cAk1lBzPR.decode('utf8')
			J0JPV7KM3Y = xnd17qtNy6aOs09jDEG.split(' ')
			nTj34FsPrvAUCe8wfWH9pNgLu1K0Et = nKDhY4cAk1lBzPR.split(' ')
			TTRyPV3tMo4cDgnkIsdJ,b0SMFatWhBr8Jm,HJkKsgZ6v0bMlYDI,U2Jtfwlrg0pv9dmK1 = [],[],'',''
			IPh841z06RKW53bGrtjgaxeqwmkU2i = zip(J0JPV7KM3Y,nTj34FsPrvAUCe8wfWH9pNgLu1K0Et)
			for sNEdmgI842A6Bh,KKXHDnlc5Yi in IPh841z06RKW53bGrtjgaxeqwmkU2i:
				if sNEdmgI842A6Bh==KKXHDnlc5Yi=='' and U2Jtfwlrg0pv9dmK1:
					HJkKsgZ6v0bMlYDI += ' '
					continue
				if sNEdmgI842A6Bh==KKXHDnlc5Yi:
					WI9OEeyXQAD34HoKvhi = 'EN'
					if U2Jtfwlrg0pv9dmK1==WI9OEeyXQAD34HoKvhi: HJkKsgZ6v0bMlYDI += ' '+sNEdmgI842A6Bh
					elif sNEdmgI842A6Bh:
						if HJkKsgZ6v0bMlYDI:
							b0SMFatWhBr8Jm.append(HJkKsgZ6v0bMlYDI)
							TTRyPV3tMo4cDgnkIsdJ.append('')
						HJkKsgZ6v0bMlYDI = sNEdmgI842A6Bh
				else:
					WI9OEeyXQAD34HoKvhi = 'AR'
					if U2Jtfwlrg0pv9dmK1==WI9OEeyXQAD34HoKvhi: HJkKsgZ6v0bMlYDI += ' '+sNEdmgI842A6Bh
					elif sNEdmgI842A6Bh:
						if HJkKsgZ6v0bMlYDI:
							TTRyPV3tMo4cDgnkIsdJ.append(HJkKsgZ6v0bMlYDI)
							b0SMFatWhBr8Jm.append('')
						HJkKsgZ6v0bMlYDI = sNEdmgI842A6Bh
				U2Jtfwlrg0pv9dmK1 = WI9OEeyXQAD34HoKvhi
			if WI9OEeyXQAD34HoKvhi=='EN':
				TTRyPV3tMo4cDgnkIsdJ.append(HJkKsgZ6v0bMlYDI)
				b0SMFatWhBr8Jm.append('')
			else:
				b0SMFatWhBr8Jm.append(HJkKsgZ6v0bMlYDI)
				TTRyPV3tMo4cDgnkIsdJ.append('')
			sW1QIk7cO0tJhqzyflAwR = ''
			IPh841z06RKW53bGrtjgaxeqwmkU2i = zip(TTRyPV3tMo4cDgnkIsdJ,b0SMFatWhBr8Jm)
			for DDdOSC0ocn6xhGiHBL,adP45jOSQhkRBU in IPh841z06RKW53bGrtjgaxeqwmkU2i:
				if DDdOSC0ocn6xhGiHBL: sW1QIk7cO0tJhqzyflAwR += ' '+DDdOSC0ocn6xhGiHBL
				else:
					OONgvsrypw9cbElzQ = JJDtX1PZyIgN2T.findall('([!-~]) *$',adP45jOSQhkRBU)
					if OONgvsrypw9cbElzQ:
						OONgvsrypw9cbElzQ = OONgvsrypw9cbElzQ[0]
						try:
							hhZHFv9KgIu4iJtUCD6c = eNsQ6UdnX0C.MIRRORED[OONgvsrypw9cbElzQ]
							tacjWQrhpZL148CiPMv = JJDtX1PZyIgN2T.findall('^( *?)(.*?)( *?)$',adP45jOSQhkRBU)
							if tacjWQrhpZL148CiPMv: BIDYmL32axyP4Oktl9wS6,adP45jOSQhkRBU,lFC4ikmq0cdTVL59y8rztUG1ao = tacjWQrhpZL148CiPMv[0]
							adP45jOSQhkRBU = BIDYmL32axyP4Oktl9wS6+hhZHFv9KgIu4iJtUCD6c+adP45jOSQhkRBU[:-1]+lFC4ikmq0cdTVL59y8rztUG1ao
						except: pass
					sW1QIk7cO0tJhqzyflAwR += ' '+adP45jOSQhkRBU
			rBabYANvVwWzjCp2QF = sW1QIk7cO0tJhqzyflAwR[1:]
			if wIqFesTOvYnu5S2dWfpBVC: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.encode('utf8')
		else:
			if wIqFesTOvYnu5S2dWfpBVC: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.decode('utf8')
			rBabYANvVwWzjCp2QF = Asxc8GDnudJm.get_display(rBabYANvVwWzjCp2QF)
			xnd17qtNy6aOs09jDEG,nKDhY4cAk1lBzPR = rBabYANvVwWzjCp2QF,rBabYANvVwWzjCp2QF
			if 1:
				U2Jtfwlrg0pv9dmK1,UjwMOle3mTH5t0uGKqFnpRNrBiaS = '',[]
				wzsTDxLOpc = rBabYANvVwWzjCp2QF.split(' ')
				for SMbpCQINGj2g4dqD0P in wzsTDxLOpc:
					if not SMbpCQINGj2g4dqD0P:
						if UjwMOle3mTH5t0uGKqFnpRNrBiaS: UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1] += ' '
						else: UjwMOle3mTH5t0uGKqFnpRNrBiaS.append('')
						continue
					P16BhgnjfVqzbNGZHFEM45okYQw = JJDtX1PZyIgN2T.findall('[!-~]',SMbpCQINGj2g4dqD0P[0])
					if P16BhgnjfVqzbNGZHFEM45okYQw==U2Jtfwlrg0pv9dmK1 and UjwMOle3mTH5t0uGKqFnpRNrBiaS: UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1] += ' '+SMbpCQINGj2g4dqD0P
					else:
						if UjwMOle3mTH5t0uGKqFnpRNrBiaS:
							abjCE78KPwMIZVuUlSF = JJDtX1PZyIgN2T.findall('[^!-~]',UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1])
							if abjCE78KPwMIZVuUlSF:
								UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1] = Asxc8GDnudJm.get_display(UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1])
								pVKbcvNkDRJLzh06rtTX = JJDtX1PZyIgN2T.findall('^ +',UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1])
								if pVKbcvNkDRJLzh06rtTX: UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1] = UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1].lstrip(' ')+pVKbcvNkDRJLzh06rtTX[0]
						UjwMOle3mTH5t0uGKqFnpRNrBiaS.append(SMbpCQINGj2g4dqD0P)
					U2Jtfwlrg0pv9dmK1 = P16BhgnjfVqzbNGZHFEM45okYQw
				if UjwMOle3mTH5t0uGKqFnpRNrBiaS: UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1] = Asxc8GDnudJm.get_display(UjwMOle3mTH5t0uGKqFnpRNrBiaS[-1])
				rBabYANvVwWzjCp2QF = ' '.join(UjwMOle3mTH5t0uGKqFnpRNrBiaS)
			if wIqFesTOvYnu5S2dWfpBVC: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.encode('utf8')
	return rBabYANvVwWzjCp2QF
def x2Sfo9yeIrFPsVjH8kaO4X6nhB0d71(QXeaYk1xv6VdP8D,iiMahkQHyUKfSxrg96oGR,nfHGKMiyLAFpa1bdCBOz2D):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,ufiY0Embag4lNzqhJGLo,CCdh9kIzjNAvp3,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = QXeaYk1xv6VdP8D
	AFWci0tYmjRU1azGJEy3ovDw2hfsqr = int(AFWci0tYmjRU1azGJEy3ovDw2hfsqr)
	SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = JJDtX1PZyIgN2T.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
	if SuRQwrCsNP9x2EUkFX8G6jbhHJ73:
		SuRQwrCsNP9x2EUkFX8G6jbhHJ73,TDIRVG2eEZoXjqvx4c1MntLOHp,ggm2o05qxMbIWXtSCzZ = SuRQwrCsNP9x2EUkFX8G6jbhHJ73[0]
		rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace(SuRQwrCsNP9x2EUkFX8G6jbhHJ73,'')
	AickPxv24Ia = rBabYANvVwWzjCp2QF
	oDG72BMvJEhKd = JJDtX1PZyIgN2T.findall('^_(\w\w\w)_(.*?)$',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
	if oDG72BMvJEhKd:
		oDG72BMvJEhKd,rBabYANvVwWzjCp2QF = oDG72BMvJEhKd[0]
		ySLv48bAn735Q1eBNzVqUflF2gIYZ = '_MOD_' in rBabYANvVwWzjCp2QF
		F8UNnjSZvpI = GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder'
		if ySLv48bAn735Q1eBNzVqUflF2gIYZ and F8UNnjSZvpI: BpgkdX0xaJO9EzS2K5T1GP = ';'
		elif ySLv48bAn735Q1eBNzVqUflF2gIYZ and not F8UNnjSZvpI: BpgkdX0xaJO9EzS2K5T1GP = XTN45xdOzVH0vkep23thYInWPCZ
		elif not ySLv48bAn735Q1eBNzVqUflF2gIYZ and F8UNnjSZvpI: BpgkdX0xaJO9EzS2K5T1GP = ','
		elif not ySLv48bAn735Q1eBNzVqUflF2gIYZ and not F8UNnjSZvpI: BpgkdX0xaJO9EzS2K5T1GP = ' '
		rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('_MOD_','')
		oDG72BMvJEhKd = BpgkdX0xaJO9EzS2K5T1GP+'[COLOR FFC89008]'+oDG72BMvJEhKd+' [/COLOR]'
	else: oDG72BMvJEhKd = ''
	if SuRQwrCsNP9x2EUkFX8G6jbhHJ73:
		if wIqFesTOvYnu5S2dWfpBVC:
			SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = '[COLOR FFFFFF00]'+TDIRVG2eEZoXjqvx4c1MntLOHp+' '+ggm2o05qxMbIWXtSCzZ+'[/COLOR]'
			if oDG72BMvJEhKd: rBabYANvVwWzjCp2QF = SuRQwrCsNP9x2EUkFX8G6jbhHJ73+' '+SBPbYXN9Rt2MHDrnU4mhlV0+oDG72BMvJEhKd+rBabYANvVwWzjCp2QF
			else: rBabYANvVwWzjCp2QF = SuRQwrCsNP9x2EUkFX8G6jbhHJ73+SBPbYXN9Rt2MHDrnU4mhlV0+rBabYANvVwWzjCp2QF+' '
		elif DQfHadYvTpy1UR:
			if oDG72BMvJEhKd:
				SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = '[COLOR FFFFFF00]'+TDIRVG2eEZoXjqvx4c1MntLOHp+' '+ggm2o05qxMbIWXtSCzZ+'[/COLOR]'
				rBabYANvVwWzjCp2QF = SuRQwrCsNP9x2EUkFX8G6jbhHJ73+' '+oDG72BMvJEhKd+rBabYANvVwWzjCp2QF
			else:
				SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = '[COLOR FFFFFF00]'+ggm2o05qxMbIWXtSCzZ+' '+TDIRVG2eEZoXjqvx4c1MntLOHp+'[/COLOR]'
				rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF+' '+SBPbYXN9Rt2MHDrnU4mhlV0+SuRQwrCsNP9x2EUkFX8G6jbhHJ73
	elif oDG72BMvJEhKd:
		rBabYANvVwWzjCp2QF = r5CWGms7jh(rBabYANvVwWzjCp2QF,oDG72BMvJEhKd)
		rBabYANvVwWzjCp2QF = oDG72BMvJEhKd+rBabYANvVwWzjCp2QF
	QXeaYk1xv6VdP8D = GGKpqhAcPw9FHBvdfarRuySJ1Yl,AickPxv24Ia,apIVksn1FTuj6rbYhMPDLHS9N,str(AFWci0tYmjRU1azGJEy3ovDw2hfsqr),mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,ufiY0Embag4lNzqhJGLo,CCdh9kIzjNAvp3,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl
	Iu9t1cFdeNMyk3WwPQE87L6izK2 = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	Iu9t1cFdeNMyk3WwPQE87L6izK2['name'] = FVsLwz1tAH(AickPxv24Ia)
	Iu9t1cFdeNMyk3WwPQE87L6izK2['type'] = GGKpqhAcPw9FHBvdfarRuySJ1Yl.strip(' ')
	Iu9t1cFdeNMyk3WwPQE87L6izK2['mode'] = str(AFWci0tYmjRU1azGJEy3ovDw2hfsqr).strip(' ')
	if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder' and ufiY0Embag4lNzqhJGLo: Iu9t1cFdeNMyk3WwPQE87L6izK2['page'] = FVsLwz1tAH(ufiY0Embag4lNzqhJGLo.strip(' '))
	if fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9: Iu9t1cFdeNMyk3WwPQE87L6izK2['context'] = fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9.strip(' ')
	if CCdh9kIzjNAvp3: Iu9t1cFdeNMyk3WwPQE87L6izK2['text'] = FVsLwz1tAH(CCdh9kIzjNAvp3.strip(' '))
	if mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO: Iu9t1cFdeNMyk3WwPQE87L6izK2['image'] = FVsLwz1tAH(mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO.strip(' '))
	if IxCL4nMsp0NGHgJy8hEOiQFoduAl:
		IxCL4nMsp0NGHgJy8hEOiQFoduAl = str(IxCL4nMsp0NGHgJy8hEOiQFoduAl)
		Iu9t1cFdeNMyk3WwPQE87L6izK2['infodict'] = FVsLwz1tAH(IxCL4nMsp0NGHgJy8hEOiQFoduAl.strip(' '))
		IxCL4nMsp0NGHgJy8hEOiQFoduAl = eval(IxCL4nMsp0NGHgJy8hEOiQFoduAl)
	else: IxCL4nMsp0NGHgJy8hEOiQFoduAl = {}
	if apIVksn1FTuj6rbYhMPDLHS9N: Iu9t1cFdeNMyk3WwPQE87L6izK2['url'] = FVsLwz1tAH(apIVksn1FTuj6rbYhMPDLHS9N.strip(' '))
	w7MRkOX0rcdSTmYHgxA3Uz4b = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	Oq0ru7GDdXhsAHtzY841p3nVEbj = []
	ednQsO4zpFa8Pty6o57T = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'/?type='+Iu9t1cFdeNMyk3WwPQE87L6izK2['type']+'&mode='+Iu9t1cFdeNMyk3WwPQE87L6izK2['mode']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['page']: ednQsO4zpFa8Pty6o57T += '&page='+Iu9t1cFdeNMyk3WwPQE87L6izK2['page']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['name']: ednQsO4zpFa8Pty6o57T += '&name='+Iu9t1cFdeNMyk3WwPQE87L6izK2['name']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['text']: ednQsO4zpFa8Pty6o57T += '&text='+Iu9t1cFdeNMyk3WwPQE87L6izK2['text']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['infodict']: ednQsO4zpFa8Pty6o57T += '&infodict='+Iu9t1cFdeNMyk3WwPQE87L6izK2['infodict']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['image']: ednQsO4zpFa8Pty6o57T += '&image='+Iu9t1cFdeNMyk3WwPQE87L6izK2['image']
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['url']: ednQsO4zpFa8Pty6o57T += '&url='+Iu9t1cFdeNMyk3WwPQE87L6izK2['url']
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr!=265: w7MRkOX0rcdSTmYHgxA3Uz4b['favorites'] = True
	else: w7MRkOX0rcdSTmYHgxA3Uz4b['favorites'] = False
	if Iu9t1cFdeNMyk3WwPQE87L6izK2['context']: ednQsO4zpFa8Pty6o57T += '&context='+Iu9t1cFdeNMyk3WwPQE87L6izK2['context']
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr in [235,238] and GGKpqhAcPw9FHBvdfarRuySJ1Yl=='live' and 'EPG' in fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9:
		Ss59fAlUhEx2 = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'?mode=238&text=SHORT_EPG&url='+apIVksn1FTuj6rbYhMPDLHS9N
		J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
		Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr==265:
		tgrzum407Ewl = iiMahkQHyUKfSxrg96oGR(CCdh9kIzjNAvp3,True)
		if tgrzum407Ewl>0:
			Ss59fAlUhEx2 = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'?mode=266&text='+CCdh9kIzjNAvp3
			J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+kFhAce5Pz1(CCdh9kIzjNAvp3)+'[/COLOR]'
			NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
			Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video' and AFWci0tYmjRU1azGJEy3ovDw2hfsqr!=331:
		Ss59fAlUhEx2 = ednQsO4zpFa8Pty6o57T+'&context=6_DOWNLOAD'
		J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
		Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr==331:
		Ss59fAlUhEx2 = ednQsO4zpFa8Pty6o57T+'&context=6_DELETE'
		J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
		Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder' and AFWci0tYmjRU1azGJEy3ovDw2hfsqr==540:
		hQPlJk9rLEMG1N0vHiz = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','GLOBALSEARCH_SITES')
		if hQPlJk9rLEMG1N0vHiz:
			Ss59fAlUhEx2 = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'?context=7'
			J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
			Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	sd7yLVih1Pzofct = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr not in sd7yLVih1Pzofct:
		Ss59fAlUhEx2 = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'?context=8&mode=260'
		J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
		Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	eptmnwaDyFPHG529AzUqvN6gCu = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if AFWci0tYmjRU1azGJEy3ovDw2hfsqr%10 and AFWci0tYmjRU1azGJEy3ovDw2hfsqr!=9990:
		vLcmKnABUplV6thIYke5wS8x3Rf = AFWci0tYmjRU1azGJEy3ovDw2hfsqr-AFWci0tYmjRU1azGJEy3ovDw2hfsqr%10
		if vLcmKnABUplV6thIYke5wS8x3Rf==280: vLcmKnABUplV6thIYke5wS8x3Rf = 230
		if vLcmKnABUplV6thIYke5wS8x3Rf==410: vLcmKnABUplV6thIYke5wS8x3Rf = 400
		if vLcmKnABUplV6thIYke5wS8x3Rf==520: vLcmKnABUplV6thIYke5wS8x3Rf = 510
		if vLcmKnABUplV6thIYke5wS8x3Rf not in eptmnwaDyFPHG529AzUqvN6gCu:
			Ss59fAlUhEx2 = 'plugin://'+f3pCnmFaVYx4zc1MNGBe5+'?context=8&mode='+str(vLcmKnABUplV6thIYke5wS8x3Rf)
			J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
			Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	Ss59fAlUhEx2 = ednQsO4zpFa8Pty6o57T+'&context=9'
	J4VLwiTR1P7uMQeNySbEnx3o5q = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	NNPluikQrMXmdSeCw5Bh = (J4VLwiTR1P7uMQeNySbEnx3o5q,'RunPlugin('+Ss59fAlUhEx2+')')
	Oq0ru7GDdXhsAHtzY841p3nVEbj.append(NNPluikQrMXmdSeCw5Bh)
	if GGKpqhAcPw9FHBvdfarRuySJ1Yl in ['link','video','live']: FBWRDa4GEzbUZCInduO9SpTl = False
	elif GGKpqhAcPw9FHBvdfarRuySJ1Yl=='folder': FBWRDa4GEzbUZCInduO9SpTl = True
	w7MRkOX0rcdSTmYHgxA3Uz4b['name'] = rBabYANvVwWzjCp2QF
	w7MRkOX0rcdSTmYHgxA3Uz4b['context_menu'] = Oq0ru7GDdXhsAHtzY841p3nVEbj
	if 'plot' in list(IxCL4nMsp0NGHgJy8hEOiQFoduAl.keys()): w7MRkOX0rcdSTmYHgxA3Uz4b['plot'] = IxCL4nMsp0NGHgJy8hEOiQFoduAl['plot']
	if 'stars' in list(IxCL4nMsp0NGHgJy8hEOiQFoduAl.keys()): w7MRkOX0rcdSTmYHgxA3Uz4b['stars'] = IxCL4nMsp0NGHgJy8hEOiQFoduAl['stars']
	if mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO: w7MRkOX0rcdSTmYHgxA3Uz4b['image'] = mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO
	if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video' and ufiY0Embag4lNzqhJGLo:
		sTfGhkerj5bH8UAJCywSaonL2m = JJDtX1PZyIgN2T.findall('[\d:]+',ufiY0Embag4lNzqhJGLo,JJDtX1PZyIgN2T.DOTALL)
		if sTfGhkerj5bH8UAJCywSaonL2m:
			sTfGhkerj5bH8UAJCywSaonL2m = '0:0:0:0:0:'+sTfGhkerj5bH8UAJCywSaonL2m[0]
			DfJA7kUuMTpHtxLe0EqOczG5In,l5qvoQmsnNY3Ld,z165ZklYxgOINpjwfv,dKHgXwuOy7DU9G,ttrivIenQ4C3Uwpf0H9 = sTfGhkerj5bH8UAJCywSaonL2m.rsplit(':',4)
			EtvyDu2KcXRsmYClJhZqfIaTiW7 = int(l5qvoQmsnNY3Ld)*24*sseNwgOx0mZkuoQX+int(z165ZklYxgOINpjwfv)*sseNwgOx0mZkuoQX+int(dKHgXwuOy7DU9G)*60+int(ttrivIenQ4C3Uwpf0H9)
			w7MRkOX0rcdSTmYHgxA3Uz4b['duration'] = EtvyDu2KcXRsmYClJhZqfIaTiW7
	w7MRkOX0rcdSTmYHgxA3Uz4b['type'] = GGKpqhAcPw9FHBvdfarRuySJ1Yl
	w7MRkOX0rcdSTmYHgxA3Uz4b['isFolder'] = FBWRDa4GEzbUZCInduO9SpTl
	w7MRkOX0rcdSTmYHgxA3Uz4b['newpath'] = ednQsO4zpFa8Pty6o57T
	w7MRkOX0rcdSTmYHgxA3Uz4b['menuItem'] = QXeaYk1xv6VdP8D
	w7MRkOX0rcdSTmYHgxA3Uz4b['mode'] = AFWci0tYmjRU1azGJEy3ovDw2hfsqr
	return w7MRkOX0rcdSTmYHgxA3Uz4b
def VcU4CTxXzs7OF(iiMahkQHyUKfSxrg96oGR):
	m0z479pI5LF82H1Pw = []
	from HJO9W03B54 import GJk0y6NbYP5jOfpeoITHi,jzoDS2dIB6mULq
	nfHGKMiyLAFpa1bdCBOz2D = GJk0y6NbYP5jOfpeoITHi()
	for QXeaYk1xv6VdP8D in PL2fM9WhpjEFb7:
		w7MRkOX0rcdSTmYHgxA3Uz4b = x2Sfo9yeIrFPsVjH8kaO4X6nhB0d71(QXeaYk1xv6VdP8D,iiMahkQHyUKfSxrg96oGR,nfHGKMiyLAFpa1bdCBOz2D)
		if w7MRkOX0rcdSTmYHgxA3Uz4b['favorites']:
			SYUceJZFCqXo1pAzE89 = jzoDS2dIB6mULq(nfHGKMiyLAFpa1bdCBOz2D,w7MRkOX0rcdSTmYHgxA3Uz4b['menuItem'],w7MRkOX0rcdSTmYHgxA3Uz4b['newpath'])
			w7MRkOX0rcdSTmYHgxA3Uz4b['context_menu'] = SYUceJZFCqXo1pAzE89+w7MRkOX0rcdSTmYHgxA3Uz4b['context_menu']
		m0z479pI5LF82H1Pw.append(w7MRkOX0rcdSTmYHgxA3Uz4b)
	return m0z479pI5LF82H1Pw
def ZYaC4UeGSWhXs6qHm(ADoPKcJrFuZi):
	BpgkdX0xaJO9EzS2K5T1GP,C5DyQK72He4sbc8wEFRr9StiTBqkgd, = [],''
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		if not D5wxHF2QT6bdzhuyl: BpgkdX0xaJO9EzS2K5T1GP.append('')
		else: break
	ADoPKcJrFuZi = ADoPKcJrFuZi[len(BpgkdX0xaJO9EzS2K5T1GP):]
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = '\n\n\n\n'.join(ADoPKcJrFuZi)
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('===== ===== =====','000001')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFC89008]','000002')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFFFFF00]','000003')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[/COLOR]','000004')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RIGHT]','000005')
	rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx = 100000
	d5LQFGZt21AkrI3KuHeCvJloaSVUb = {}
	QyN9WqRDT8vkXCMtBzgHplcds = JJDtX1PZyIgN2T.findall('http.*?[\r\n ]',hulSHFUcXsaVQGTn8r9zMkNPIwgvo,JJDtX1PZyIgN2T.DOTALL)
	for WHbqkMf7tcaOSdZ in QyN9WqRDT8vkXCMtBzgHplcds:
		rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx += 1
		hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace(WHbqkMf7tcaOSdZ,str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx))
		d5LQFGZt21AkrI3KuHeCvJloaSVUb[str(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx)] = WHbqkMf7tcaOSdZ
	for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(0,len(hulSHFUcXsaVQGTn8r9zMkNPIwgvo),4800):
		Rm31TfQBvOxMc7DYdGS4iACXqJWIoL = hulSHFUcXsaVQGTn8r9zMkNPIwgvo[NzfP6biDZJAqmyensuhE7HjwYvlQk:NzfP6biDZJAqmyensuhE7HjwYvlQk+4800]
		Zr56PK0QX7jRhlGizLItsbwd3CBugn = BBwb2NzsHE.getSetting('av.language.code')
		apIVksn1FTuj6rbYhMPDLHS9N = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+Zr56PK0QX7jRhlGizLItsbwd3CBugn
		jmdxulY90XbNQGP5vSfoz16h = {'Content-Type':'text/plain'}
		fWSqB07JuGo6jC5vHFIzpDN1PMYsb = Rm31TfQBvOxMc7DYdGS4iACXqJWIoL.encode('utf8')
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',apIVksn1FTuj6rbYhMPDLHS9N,fWSqB07JuGo6jC5vHFIzpDN1PMYsb,jmdxulY90XbNQGP5vSfoz16h,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if UlqnkuTN3EZWXMOyQ9fo2BjiS8h.succeeded:
			j4iteqgCJdK6kaY = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
			NZ1irwUABl7gvLt2 = G8EwoDOyKShm1i0IHMfNYZlU7('str',j4iteqgCJdK6kaY)
			if NZ1irwUABl7gvLt2:
				NZ1irwUABl7gvLt2 = NZ1irwUABl7gvLt2['translation']
				NZ1irwUABl7gvLt2 = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(NZ1irwUABl7gvLt2)
				for ljCiyDcov8N0kZeS in range(len(NZ1irwUABl7gvLt2)):
					C5DyQK72He4sbc8wEFRr9StiTBqkgd += NZ1irwUABl7gvLt2[ljCiyDcov8N0kZeS][0]
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000001','===== ===== =====')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000002','[COLOR FFC89008]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000003','[COLOR FFFFFF00]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000004','[/COLOR]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000005','[RIGHT]')
	for rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx in list(d5LQFGZt21AkrI3KuHeCvJloaSVUb.keys()):
		WHbqkMf7tcaOSdZ = d5LQFGZt21AkrI3KuHeCvJloaSVUb[rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx]
		C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace(rFNBTu9hdY4DUJ1LigOWaX0GVmZ7Kx,WHbqkMf7tcaOSdZ)
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.split('\n\n\n\n')
	return BpgkdX0xaJO9EzS2K5T1GP+C5DyQK72He4sbc8wEFRr9StiTBqkgd
def NNmISTnVLbFz7(ADoPKcJrFuZi):
	BpgkdX0xaJO9EzS2K5T1GP,C5DyQK72He4sbc8wEFRr9StiTBqkgd, = [],''
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		if not D5wxHF2QT6bdzhuyl: BpgkdX0xaJO9EzS2K5T1GP.append('')
		else: break
	ADoPKcJrFuZi = ADoPKcJrFuZi[len(BpgkdX0xaJO9EzS2K5T1GP):]
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = '\\n\\n\\n\\n'.join(ADoPKcJrFuZi)
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('كلا','no')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('استمرار','continue')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('===== ===== =====','000001')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFC89008]','000002')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFFFFF00]','000003')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[/COLOR]','000004')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RIGHT]','000005')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[CENTER]','000006')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RTL]','000007')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace("'","\\\\\\'")
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('"','\\\\\\"')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('\n','\\n')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('\r','\\\\r')
	for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(0,len(hulSHFUcXsaVQGTn8r9zMkNPIwgvo),4800):
		Rm31TfQBvOxMc7DYdGS4iACXqJWIoL = hulSHFUcXsaVQGTn8r9zMkNPIwgvo[NzfP6biDZJAqmyensuhE7HjwYvlQk:NzfP6biDZJAqmyensuhE7HjwYvlQk+4800]
		apIVksn1FTuj6rbYhMPDLHS9N = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		jmdxulY90XbNQGP5vSfoz16h = {'Content-Type':'application/x-www-form-urlencoded'}
		Zr56PK0QX7jRhlGizLItsbwd3CBugn = BBwb2NzsHE.getSetting('av.language.code')
		fWSqB07JuGo6jC5vHFIzpDN1PMYsb = 'f.req='+FVsLwz1tAH('[[["MkEWBc","[[\\"'+Rm31TfQBvOxMc7DYdGS4iACXqJWIoL+'\\",\\"ar\\",\\"'+Zr56PK0QX7jRhlGizLItsbwd3CBugn+'\\",1],[]]",null,"generic"]]]','')
		fWSqB07JuGo6jC5vHFIzpDN1PMYsb = fWSqB07JuGo6jC5vHFIzpDN1PMYsb.replace('%5Cn','%5C%5Cn')
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',apIVksn1FTuj6rbYhMPDLHS9N,fWSqB07JuGo6jC5vHFIzpDN1PMYsb,jmdxulY90XbNQGP5vSfoz16h,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if UlqnkuTN3EZWXMOyQ9fo2BjiS8h.succeeded:
			j4iteqgCJdK6kaY = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
			j4iteqgCJdK6kaY = j4iteqgCJdK6kaY.split('\n')[-1]
			NZ1irwUABl7gvLt2 = G8EwoDOyKShm1i0IHMfNYZlU7('str',j4iteqgCJdK6kaY)[0][2]
			if NZ1irwUABl7gvLt2:
				NZ1irwUABl7gvLt2 = G8EwoDOyKShm1i0IHMfNYZlU7('str',NZ1irwUABl7gvLt2)[1][0][0][5]
				NZ1irwUABl7gvLt2 = CpRxBfZmj8VYNE50ULd3rJGl2giFhe(NZ1irwUABl7gvLt2)
				for ljCiyDcov8N0kZeS in range(len(NZ1irwUABl7gvLt2)):
					C5DyQK72He4sbc8wEFRr9StiTBqkgd += NZ1irwUABl7gvLt2[ljCiyDcov8N0kZeS][0]
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('00000','0000').replace('0000','000')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0001','===== ===== =====')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0002','[COLOR FFC89008]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0003','[COLOR FFFFFF00]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0004','[/COLOR]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0005','[RIGHT]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0006','[CENTER]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0007','[RTL]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.split('\n\n\n\n')
	return BpgkdX0xaJO9EzS2K5T1GP+C5DyQK72He4sbc8wEFRr9StiTBqkgd
def v1ecYimbr60wW7ZOF4soLEkdMfu(ADoPKcJrFuZi):
	BpgkdX0xaJO9EzS2K5T1GP,Y58qEBc02seKz = [],[]
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		if not D5wxHF2QT6bdzhuyl: BpgkdX0xaJO9EzS2K5T1GP.append('')
		else: break
	ADoPKcJrFuZi = ADoPKcJrFuZi[len(BpgkdX0xaJO9EzS2K5T1GP):]
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = '\n\n\n\n'.join(ADoPKcJrFuZi)
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('كلا','no')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('استمرار','continue')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('أدناه','below')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFC89008]','00001')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR FFFFFF00]','00002')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[/COLOR]','00003')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('=====','00004')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace(',','00005')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RTL]','00009')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[CENTER]','0000A')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('\r','0000B')
	ADoPKcJrFuZi = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.split('\n')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo,C5DyQK72He4sbc8wEFRr9StiTBqkgd = '',''
	for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
		if len(hulSHFUcXsaVQGTn8r9zMkNPIwgvo+D5wxHF2QT6bdzhuyl)<1800: hulSHFUcXsaVQGTn8r9zMkNPIwgvo += '\n'+D5wxHF2QT6bdzhuyl
		else:
			Y58qEBc02seKz.append(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
			hulSHFUcXsaVQGTn8r9zMkNPIwgvo = D5wxHF2QT6bdzhuyl
	Y58qEBc02seKz.append(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
	from json import dumps as ZvwIAahrHFDRzKTiu8OMgSxCeGc
	for D5wxHF2QT6bdzhuyl in Y58qEBc02seKz:
		jmdxulY90XbNQGP5vSfoz16h = {'Content-Type':'application/json','User-Agent':''}
		apIVksn1FTuj6rbYhMPDLHS9N = 'https://api.reverso.net/translate/v1/translation'
		Zr56PK0QX7jRhlGizLItsbwd3CBugn = BBwb2NzsHE.getSetting('av.language.code')
		fWSqB07JuGo6jC5vHFIzpDN1PMYsb = {"format":"text","from":"ara","to":Zr56PK0QX7jRhlGizLItsbwd3CBugn,"input":D5wxHF2QT6bdzhuyl,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		fWSqB07JuGo6jC5vHFIzpDN1PMYsb = ZvwIAahrHFDRzKTiu8OMgSxCeGc(fWSqB07JuGo6jC5vHFIzpDN1PMYsb)
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = zibnBvFtmwKplXrg(jCJnzmXDkNqtB,'POST',apIVksn1FTuj6rbYhMPDLHS9N,fWSqB07JuGo6jC5vHFIzpDN1PMYsb,jmdxulY90XbNQGP5vSfoz16h,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if UlqnkuTN3EZWXMOyQ9fo2BjiS8h.succeeded:
			j4iteqgCJdK6kaY = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
			j4iteqgCJdK6kaY = G8EwoDOyKShm1i0IHMfNYZlU7('dict',j4iteqgCJdK6kaY)
			C5DyQK72He4sbc8wEFRr9StiTBqkgd += '\n'+''.join(j4iteqgCJdK6kaY['translation'])
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd[2:]
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000000','00000').replace('00000','0000').replace('0000','000')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0001','[COLOR FFC89008]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0002','[COLOR FFFFFF00]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0003','[/COLOR]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0004','=====')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0005',',')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('0009','[RTL]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000A','[CENTER]')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.replace('000B','\r')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = C5DyQK72He4sbc8wEFRr9StiTBqkgd.split('\n\n\n\n')
	return BpgkdX0xaJO9EzS2K5T1GP+C5DyQK72He4sbc8wEFRr9StiTBqkgd
def UrLi7Bfb1aHQY8E(ADoPKcJrFuZi):
	mHBMyV7slUNOoxIwhqXLgYdW9aeKfz = BBwb2NzsHE.getSetting('av.language.translate')
	if not mHBMyV7slUNOoxIwhqXLgYdW9aeKfz or not ADoPKcJrFuZi: return ADoPKcJrFuZi
	dDWfiwEZ3SGJ = BBwb2NzsHE.getSetting('av.language.provider')
	Zr56PK0QX7jRhlGizLItsbwd3CBugn = BBwb2NzsHE.getSetting('av.language.code')
	Ksqz3gLB4DCrimx = Zr56PK0QX7jRhlGizLItsbwd3CBugn+'__'+str(ADoPKcJrFuZi)
	BBwb2NzsHE.setSetting('av.language.translate','')
	C5DyQK72He4sbc8wEFRr9StiTBqkgd = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,'list','TRANSLATE_'+dDWfiwEZ3SGJ,Ksqz3gLB4DCrimx)
	if not C5DyQK72He4sbc8wEFRr9StiTBqkgd:
		if dDWfiwEZ3SGJ=='GOOGLE': C5DyQK72He4sbc8wEFRr9StiTBqkgd = NNmISTnVLbFz7(ADoPKcJrFuZi)
		elif dDWfiwEZ3SGJ=='REVERSO': C5DyQK72He4sbc8wEFRr9StiTBqkgd = v1ecYimbr60wW7ZOF4soLEkdMfu(ADoPKcJrFuZi)
		elif dDWfiwEZ3SGJ=='GLOSBE': C5DyQK72He4sbc8wEFRr9StiTBqkgd = ZYaC4UeGSWhXs6qHm(ADoPKcJrFuZi)
		if len(ADoPKcJrFuZi)==len(C5DyQK72He4sbc8wEFRr9StiTBqkgd):
			pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,'TRANSLATE_'+dDWfiwEZ3SGJ,Ksqz3gLB4DCrimx,C5DyQK72He4sbc8wEFRr9StiTBqkgd,u5vT6erC7PYdV18MNSwRnJE)
		else:
			C5DyQK72He4sbc8wEFRr9StiTBqkgd = ADoPKcJrFuZi
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0('الترجمة فشلت','Translation Failed')
	BBwb2NzsHE.setSetting('av.language.translate','1')
	return C5DyQK72He4sbc8wEFRr9StiTBqkgd
def zzdJUmRVlxbjAoDFMPuvKSBa6NqT7i(QXeaYk1xv6VdP8D,m0z479pI5LF82H1Pw,dnD6ZJOtXsEGPhk3gH,BVlLm69roX8jHD30vpwC2FOGyMASU,dclZLMYnbI4tD76Xsx1Q5iG):
	GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl = QXeaYk1xv6VdP8D
	bRHdrEB3SzU4T = []
	mHBMyV7slUNOoxIwhqXLgYdW9aeKfz = BBwb2NzsHE.getSetting('av.language.translate')
	if mHBMyV7slUNOoxIwhqXLgYdW9aeKfz:
		dXioAqKh7Wl1as,jjn47fiJVPwbE,EITilSpyzFY9AqjD1uL4nxUGJ = [],[],[]
		if not bRHdrEB3SzU4T:
			for w7MRkOX0rcdSTmYHgxA3Uz4b in m0z479pI5LF82H1Pw:
				rBabYANvVwWzjCp2QF = w7MRkOX0rcdSTmYHgxA3Uz4b['name'].replace(SBPbYXN9Rt2MHDrnU4mhlV0,'').replace(ccdMiA5sZ0koIRwpFgeU8j,'')
				SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = JJDtX1PZyIgN2T.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
				if SuRQwrCsNP9x2EUkFX8G6jbhHJ73:
					BpgkdX0xaJO9EzS2K5T1GP,TDIRVG2eEZoXjqvx4c1MntLOHp,ggm2o05qxMbIWXtSCzZ,WMnq8haXrLtVEiFjb9SlxU,rBabYANvVwWzjCp2QF = SuRQwrCsNP9x2EUkFX8G6jbhHJ73[0]
					SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = BpgkdX0xaJO9EzS2K5T1GP+TDIRVG2eEZoXjqvx4c1MntLOHp+' '+ggm2o05qxMbIWXtSCzZ+WMnq8haXrLtVEiFjb9SlxU+' '
				else:
					SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = JJDtX1PZyIgN2T.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
					if SuRQwrCsNP9x2EUkFX8G6jbhHJ73:
						rBabYANvVwWzjCp2QF,BpgkdX0xaJO9EzS2K5T1GP,ggm2o05qxMbIWXtSCzZ,TDIRVG2eEZoXjqvx4c1MntLOHp,WMnq8haXrLtVEiFjb9SlxU = SuRQwrCsNP9x2EUkFX8G6jbhHJ73[0]
						SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = BpgkdX0xaJO9EzS2K5T1GP+TDIRVG2eEZoXjqvx4c1MntLOHp+' '+ggm2o05qxMbIWXtSCzZ+WMnq8haXrLtVEiFjb9SlxU+' '
					else: SuRQwrCsNP9x2EUkFX8G6jbhHJ73 = ''
				oDG72BMvJEhKd = JJDtX1PZyIgN2T.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
				if oDG72BMvJEhKd: oDG72BMvJEhKd,rBabYANvVwWzjCp2QF = oDG72BMvJEhKd[0]
				else: oDG72BMvJEhKd = ''
				dXioAqKh7Wl1as.append(SuRQwrCsNP9x2EUkFX8G6jbhHJ73+oDG72BMvJEhKd)
				jjn47fiJVPwbE.append(rBabYANvVwWzjCp2QF)
			EITilSpyzFY9AqjD1uL4nxUGJ = UrLi7Bfb1aHQY8E(jjn47fiJVPwbE)
			if EITilSpyzFY9AqjD1uL4nxUGJ:
				for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(len(m0z479pI5LF82H1Pw)):
					w7MRkOX0rcdSTmYHgxA3Uz4b = m0z479pI5LF82H1Pw[NzfP6biDZJAqmyensuhE7HjwYvlQk]
					w7MRkOX0rcdSTmYHgxA3Uz4b['name'] = dXioAqKh7Wl1as[NzfP6biDZJAqmyensuhE7HjwYvlQk]+EITilSpyzFY9AqjD1uL4nxUGJ[NzfP6biDZJAqmyensuhE7HjwYvlQk]
					bRHdrEB3SzU4T.append(w7MRkOX0rcdSTmYHgxA3Uz4b)
	if bRHdrEB3SzU4T: m0z479pI5LF82H1Pw = bRHdrEB3SzU4T
	OO8GuRl6pqJkZxf,VU2C1xI4wRnWmcNhfesQzB,bITqGr8z3PsoYag0u5NjKkDVw2 = [],0,0
	AGjqmdK5iWk12NTHwbIcylp73LOt = A73K6zLXIgFROeCHJQi0Pbos.path.join(FFoYQNgfsy,AFWci0tYmjRU1azGJEy3ovDw2hfsqr)
	try: x6xilzc91yh3p4aZMqSKmXNr = A73K6zLXIgFROeCHJQi0Pbos.listdir(AGjqmdK5iWk12NTHwbIcylp73LOt)
	except:
		try: A73K6zLXIgFROeCHJQi0Pbos.makedirs(AGjqmdK5iWk12NTHwbIcylp73LOt)
		except: pass
		x6xilzc91yh3p4aZMqSKmXNr = []
	bCc5iIBvdw1uVMpJLKR4a73ZQsfED = hgCpZrHjMBsN4nLlcKoafvO1em('menu_item')
	for w7MRkOX0rcdSTmYHgxA3Uz4b in m0z479pI5LF82H1Pw:
		rBabYANvVwWzjCp2QF = w7MRkOX0rcdSTmYHgxA3Uz4b['name']
		Oq0ru7GDdXhsAHtzY841p3nVEbj = w7MRkOX0rcdSTmYHgxA3Uz4b['context_menu']
		FY8prDPShvM7oHTjO = w7MRkOX0rcdSTmYHgxA3Uz4b['plot']
		gguSMnr56cw = w7MRkOX0rcdSTmYHgxA3Uz4b['stars']
		mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO = w7MRkOX0rcdSTmYHgxA3Uz4b['image']
		GGKpqhAcPw9FHBvdfarRuySJ1Yl = w7MRkOX0rcdSTmYHgxA3Uz4b['type']
		sTfGhkerj5bH8UAJCywSaonL2m = w7MRkOX0rcdSTmYHgxA3Uz4b['duration']
		FBWRDa4GEzbUZCInduO9SpTl = w7MRkOX0rcdSTmYHgxA3Uz4b['isFolder']
		ednQsO4zpFa8Pty6o57T = w7MRkOX0rcdSTmYHgxA3Uz4b['newpath']
		i6uwNzl2yb4tRxYIGqadMFfCjc = U6zsmRNGTL.ListItem(rBabYANvVwWzjCp2QF)
		i6uwNzl2yb4tRxYIGqadMFfCjc.addContextMenuItems(Oq0ru7GDdXhsAHtzY841p3nVEbj)
		if mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO: i6uwNzl2yb4tRxYIGqadMFfCjc.setArt({'icon':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'thumb':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'fanart':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'banner':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'clearart':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'poster':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'clearlogo':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,'landscape':mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO})
		else:
			rBabYANvVwWzjCp2QF = xaEZjvs6y0qt2Wmh(rBabYANvVwWzjCp2QF)
			rBabYANvVwWzjCp2QF = qIKCc75Futx6BpNPz(rBabYANvVwWzjCp2QF)
			jurOFA9fldvYyC = rBabYANvVwWzjCp2QF+'.png'
			default = True
			if jurOFA9fldvYyC in x6xilzc91yh3p4aZMqSKmXNr:
				uXb80IGpv4Na7 = A73K6zLXIgFROeCHJQi0Pbos.path.join(AGjqmdK5iWk12NTHwbIcylp73LOt,jurOFA9fldvYyC)
				i6uwNzl2yb4tRxYIGqadMFfCjc.setArt({'icon':uXb80IGpv4Na7,'thumb':uXb80IGpv4Na7,'fanart':uXb80IGpv4Na7,'banner':uXb80IGpv4Na7,'clearart':uXb80IGpv4Na7,'poster':uXb80IGpv4Na7,'clearlogo':uXb80IGpv4Na7,'landscape':uXb80IGpv4Na7})
				default = False
			elif VU2C1xI4wRnWmcNhfesQzB<60 and bITqGr8z3PsoYag0u5NjKkDVw2<5:
				uXb80IGpv4Na7 = A73K6zLXIgFROeCHJQi0Pbos.path.join(AGjqmdK5iWk12NTHwbIcylp73LOt,jurOFA9fldvYyC)
				try:
					cc6sSVHf57bwXzUFPZ = fyqjBSaPOcFN67idrhIKLDGw531(bCc5iIBvdw1uVMpJLKR4a73ZQsfED,'','','','',rBabYANvVwWzjCp2QF,'menu_item','center',False,uXb80IGpv4Na7)
					i6uwNzl2yb4tRxYIGqadMFfCjc.setArt({'icon':uXb80IGpv4Na7,'thumb':uXb80IGpv4Na7,'fanart':uXb80IGpv4Na7,'banner':uXb80IGpv4Na7,'clearart':uXb80IGpv4Na7,'poster':uXb80IGpv4Na7,'clearlogo':uXb80IGpv4Na7,'landscape':uXb80IGpv4Na7})
					VU2C1xI4wRnWmcNhfesQzB += 1
					default = False
				except: bITqGr8z3PsoYag0u5NjKkDVw2 += 1
			if default: i6uwNzl2yb4tRxYIGqadMFfCjc.setArt({'icon':lEezQxTRZ9cd48v16tUIDL,'thumb':kk6VQe4upafgzCqNF8nlG1Ob0LRHAm,'fanart':wXlp5vsIhn6CbeJFtycHuP2kS,'banner':qgd7LerTGM,'clearart':qXRFIVCbLvuwjiBo,'poster':HzJgOc4vFANVCBTRsP,'clearlogo':oXBEGVrtTJngd6epPiau0YbHMcF3,'landscape':DWPrnJp5Rmt3iwbBdEAXhe9OyZ})
		if WWSLAyQdhUXl3ovb<20:
			if FY8prDPShvM7oHTjO: i6uwNzl2yb4tRxYIGqadMFfCjc.setInfo('video',{'Plot':FY8prDPShvM7oHTjO,'PlotOutline':FY8prDPShvM7oHTjO})
			if gguSMnr56cw: i6uwNzl2yb4tRxYIGqadMFfCjc.setInfo('video',{'Rating':gguSMnr56cw})
			if not mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO:
				i6uwNzl2yb4tRxYIGqadMFfCjc.setInfo('video',{'Title':rBabYANvVwWzjCp2QF})
			if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video':
				i6uwNzl2yb4tRxYIGqadMFfCjc.setInfo('video',{'mediatype':'movie'})
				if sTfGhkerj5bH8UAJCywSaonL2m: i6uwNzl2yb4tRxYIGqadMFfCjc.setInfo('video',{'duration':sTfGhkerj5bH8UAJCywSaonL2m})
				i6uwNzl2yb4tRxYIGqadMFfCjc.setProperty('IsPlayable','true')
		else:
			Zgu4bOAmNnfi3UHx = i6uwNzl2yb4tRxYIGqadMFfCjc.getVideoInfoTag()
			if gguSMnr56cw: Zgu4bOAmNnfi3UHx.setRating(float(gguSMnr56cw))
			if not mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO:
				Zgu4bOAmNnfi3UHx.setTitle(rBabYANvVwWzjCp2QF)
			if GGKpqhAcPw9FHBvdfarRuySJ1Yl=='video':
				Zgu4bOAmNnfi3UHx.setMediaType('tvshow')
				if sTfGhkerj5bH8UAJCywSaonL2m: Zgu4bOAmNnfi3UHx.setDuration(sTfGhkerj5bH8UAJCywSaonL2m)
				i6uwNzl2yb4tRxYIGqadMFfCjc.setProperty('IsPlayable','true')
		OO8GuRl6pqJkZxf.append((ednQsO4zpFa8Pty6o57T,i6uwNzl2yb4tRxYIGqadMFfCjc,FBWRDa4GEzbUZCInduO9SpTl))
	wwxkRfBvlShcg72TKtbdyQrniEY.setContent(MPBU8HXFoN3Ocj,'tvshows')
	ttNPiqWlrx4 = wwxkRfBvlShcg72TKtbdyQrniEY.addDirectoryItems(MPBU8HXFoN3Ocj,OO8GuRl6pqJkZxf)
	wwxkRfBvlShcg72TKtbdyQrniEY.endOfDirectory(MPBU8HXFoN3Ocj,dnD6ZJOtXsEGPhk3gH,BVlLm69roX8jHD30vpwC2FOGyMASU,dclZLMYnbI4tD76Xsx1Q5iG)
	return ttNPiqWlrx4
def nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO='',WXU2APNzuivcGgq='',hulSHFUcXsaVQGTn8r9zMkNPIwgvo='',fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9='',IxCL4nMsp0NGHgJy8hEOiQFoduAl={}):
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('\r','').replace('\n','').replace('\t','')
	apIVksn1FTuj6rbYhMPDLHS9N = apIVksn1FTuj6rbYhMPDLHS9N.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in rBabYANvVwWzjCp2QF: s1ITpY2ghtCvR3mSXkFVBnlL8,rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.split('_SCRIPT_',1)
	else: s1ITpY2ghtCvR3mSXkFVBnlL8,rBabYANvVwWzjCp2QF = '',rBabYANvVwWzjCp2QF
	if s1ITpY2ghtCvR3mSXkFVBnlL8:
		ix32nJYtauEl9740e1hH = rBabYANvVwWzjCp2QF
		if not ix32nJYtauEl9740e1hH: ix32nJYtauEl9740e1hH = '....'
		elif ix32nJYtauEl9740e1hH.count('_')>1: ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.split('_',2)[2]
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace(' ','')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('|','').replace('~','')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('اون لاين','').replace('سيما لايت','')
		aa5kRPdMTOzSy = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(igAjXwvGcJfpYLVHZRmBtlW3DxOb62 in ix32nJYtauEl9740e1hH for igAjXwvGcJfpYLVHZRmBtlW3DxOb62 in aa5kRPdMTOzSy): ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('ال','')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		ix32nJYtauEl9740e1hH = ix32nJYtauEl9740e1hH.replace('  ',' ').strip(' ')
		s1ITpY2ghtCvR3mSXkFVBnlL8 = '_LST_'+kFhAce5Pz1(s1ITpY2ghtCvR3mSXkFVBnlL8)
		if ix32nJYtauEl9740e1hH not in list(yvRq7ZeaIJx6d.keys()): yvRq7ZeaIJx6d[ix32nJYtauEl9740e1hH] = {}
		yvRq7ZeaIJx6d[ix32nJYtauEl9740e1hH][s1ITpY2ghtCvR3mSXkFVBnlL8] = [GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl]
	PL2fM9WhpjEFb7.append([GGKpqhAcPw9FHBvdfarRuySJ1Yl,rBabYANvVwWzjCp2QF,apIVksn1FTuj6rbYhMPDLHS9N,AFWci0tYmjRU1azGJEy3ovDw2hfsqr,mBSlWVvwuMeXL7hnqyk8pK1RxCA0JO,WXU2APNzuivcGgq,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,fOqZ8Ix2ibSwXCGdnNTgsAuhYBjJR9,IxCL4nMsp0NGHgJy8hEOiQFoduAl])
	return
def jbigKDeUf0OSMrRkly2B5I3Act(Pr0Cx7pcYhWmG3a45gqlQD):
	if DQfHadYvTpy1UR: from html import unescape as _y5G8YXh03KtRCgi6aFDB
	else:
		from HTMLParser import HTMLParser as ZahzuWKlnL1U4HeXD2m
		_y5G8YXh03KtRCgi6aFDB = ZahzuWKlnL1U4HeXD2m().unescape
	if '&' in Pr0Cx7pcYhWmG3a45gqlQD and ';' in Pr0Cx7pcYhWmG3a45gqlQD:
		if wIqFesTOvYnu5S2dWfpBVC: Pr0Cx7pcYhWmG3a45gqlQD = Pr0Cx7pcYhWmG3a45gqlQD.decode('utf8')
		Pr0Cx7pcYhWmG3a45gqlQD = _y5G8YXh03KtRCgi6aFDB(Pr0Cx7pcYhWmG3a45gqlQD)
		if wIqFesTOvYnu5S2dWfpBVC: Pr0Cx7pcYhWmG3a45gqlQD = Pr0Cx7pcYhWmG3a45gqlQD.encode('utf8')
	return Pr0Cx7pcYhWmG3a45gqlQD
def CpRxBfZmj8VYNE50ULd3rJGl2giFhe(Pr0Cx7pcYhWmG3a45gqlQD):
	if '\\u' in Pr0Cx7pcYhWmG3a45gqlQD:
		if wIqFesTOvYnu5S2dWfpBVC: Pr0Cx7pcYhWmG3a45gqlQD = Pr0Cx7pcYhWmG3a45gqlQD.decode('unicode_escape','ignore').encode('utf8')
		elif DQfHadYvTpy1UR: Pr0Cx7pcYhWmG3a45gqlQD = Pr0Cx7pcYhWmG3a45gqlQD.encode('utf8').decode('unicode_escape','ignore')
	return Pr0Cx7pcYhWmG3a45gqlQD
def Whl52Kf4SzyA9qBOujbeLQtIJM(vr3cmNWxh2SVjRqsz,NJX8KZiDeH5QdLtyAo,m4jM2RNzhT0JvyYa6G9ULEFs,ZYF8IqgHdUpWOVeom,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,mm3RKyoTBHgWdkN10GzLfOc,sIZY2toqXQD0irSkpvNOye6HnaFLcP,TX1fMUp9SzCP3RDrAilvu,cFShx14agobH3qOwIC2TKvrQlDAt):
	yWMP65EGUpNvos8XIAqadR4V1 = hgCpZrHjMBsN4nLlcKoafvO1em(mm3RKyoTBHgWdkN10GzLfOc)
	cc6sSVHf57bwXzUFPZ = fyqjBSaPOcFN67idrhIKLDGw531(yWMP65EGUpNvos8XIAqadR4V1,vr3cmNWxh2SVjRqsz,NJX8KZiDeH5QdLtyAo,m4jM2RNzhT0JvyYa6G9ULEFs,ZYF8IqgHdUpWOVeom,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,mm3RKyoTBHgWdkN10GzLfOc,sIZY2toqXQD0irSkpvNOye6HnaFLcP,TX1fMUp9SzCP3RDrAilvu,cFShx14agobH3qOwIC2TKvrQlDAt)
	return cc6sSVHf57bwXzUFPZ
def hgCpZrHjMBsN4nLlcKoafvO1em(mm3RKyoTBHgWdkN10GzLfOc):
	TJ24UEplRA9Xa = 5
	KN7lqX59nD = 20
	MYg1Q7TpKiVkLSdcjDNuqo = 20
	F6bkwecKyU3WnIis5YOQPqrT = 0
	UoN1KljmeHsqkdYGZLh7FpxC8 = 'center'
	zHs9btVcLe = 0
	GKEMmVcSQf0zLBjix2h = 19
	DmYQ0PFvoqidjB7c9zf6C = 30
	BOgbMlGxhzo = 8
	aSnt62o5dDNyc3WMkJzuRH8IUrpZg7 = True
	vkg0FrT25McEYQAoBIReCpU = 375
	FFI0pe7AOVJKbskBrP = 410
	ovWuKSnzR4Fb = 50
	byqwua6TBgGYVsJfmdNrkHC = 280
	jgbUnsINMux0fSZVhTmDvQXr = 28
	LDzt67wyepMfg10O8BsGXdR = 5
	D16SzTxtM3EHA07a = 0
	AhF4a2qdUX = 31
	mYVpK2cQMGH6WSguRZP0 = [36,32,28]
	if mm3RKyoTBHgWdkN10GzLfOc in ['notification','notification_twohalfs']:
		if mm3RKyoTBHgWdkN10GzLfOc=='notification_twohalfs':
			Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = 'UPPER',720
			UoN1KljmeHsqkdYGZLh7FpxC8 = 'right'
			aSnt62o5dDNyc3WMkJzuRH8IUrpZg7 = True
			F6bkwecKyU3WnIis5YOQPqrT = 10
		else:
			Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = 97+20,720
			UoN1KljmeHsqkdYGZLh7FpxC8 = 'left'
			aSnt62o5dDNyc3WMkJzuRH8IUrpZg7 = False
		mYVpK2cQMGH6WSguRZP0 = [33,33,33]
		MYg1Q7TpKiVkLSdcjDNuqo = 20
		KN7lqX59nD = 0
		DmYQ0PFvoqidjB7c9zf6C = 20
		GKEMmVcSQf0zLBjix2h = 25+10
	elif mm3RKyoTBHgWdkN10GzLfOc=='menu_item':
		mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [48,44,40],200,400
		DmYQ0PFvoqidjB7c9zf6C,GKEMmVcSQf0zLBjix2h,KN7lqX59nD = 0,0,-16
		dduW8KFxIJisqH5VOwgaBvPnb = y7Pbr6RV0Gij.open(QIl4MNcYoRH3BU8JKgjAh)
		PC9mZteO2zYoq8d = y7Pbr6RV0Gij.new('RGBA',(200,200),(255,0,0,255))
	elif mm3RKyoTBHgWdkN10GzLfOc=='confirm_smallfont': mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [28,24,20],500,900
	elif mm3RKyoTBHgWdkN10GzLfOc=='confirm_mediumfont': mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [32,28,24],500,900
	elif mm3RKyoTBHgWdkN10GzLfOc=='confirm_bigfont': mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [36,32,28],500,900
	elif mm3RKyoTBHgWdkN10GzLfOc=='textview_bigfont': Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = 740,1270
	elif mm3RKyoTBHgWdkN10GzLfOc=='textview_bigfont_long': Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = 'UPPER',1270
	elif mm3RKyoTBHgWdkN10GzLfOc=='textview_smallfont': mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [28,23,18],740,1270
	elif mm3RKyoTBHgWdkN10GzLfOc=='textview_smallfont_long': mYVpK2cQMGH6WSguRZP0,Gl3z9ptBDVcKZIjgrTuMs4YxAN,nm3c75CgUl4TMJvzhutxs = [28,23,18],'UPPER',1270
	RnEUj8WNqVKtJMhGguIlf4xDC = mYVpK2cQMGH6WSguRZP0[0]
	ii8y3f5cqtr4NDlTa0eHghSv = mYVpK2cQMGH6WSguRZP0[1]
	JEZ3eF52bHS = mYVpK2cQMGH6WSguRZP0[2]
	Kh9zbWTeC4UYtEoAnLrJFZ7iS = V47MU09QYBNxTjHF.truetype(S3SXQP5fkxTymI4r,size=RnEUj8WNqVKtJMhGguIlf4xDC)
	LLgeTjIKDtR0aZJF3C = V47MU09QYBNxTjHF.truetype(S3SXQP5fkxTymI4r,size=ii8y3f5cqtr4NDlTa0eHghSv)
	eZ1qmTtVzMyios3Qc72AxB9hpvC = V47MU09QYBNxTjHF.truetype(S3SXQP5fkxTymI4r,size=JEZ3eF52bHS)
	v6hyYUMaqr8ZHSn = y7Pbr6RV0Gij.new('RGBA',(100,100),(255,255,255,0))
	xsNZl6a8GXwPty3dHEjoRec7Y = rAtkoeldGFvTLWOn7.Draw(v6hyYUMaqr8ZHSn)
	IiOUGQTsSj7P,JNuW8jEHc0ZP = xsNZl6a8GXwPty3dHEjoRec7Y.textsize('HHH BBB 888 000',font=LLgeTjIKDtR0aZJF3C)
	LSE4qRJkx1aPigD,fldhzT0MesmZG8rBRk9 = xsNZl6a8GXwPty3dHEjoRec7Y.textsize('HHH BBB 888 000',font=Kh9zbWTeC4UYtEoAnLrJFZ7iS)
	iyRCdfum81o30 = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	F2FMfXVun4HzU0iPOWwgjmrqZ = ybB0jav3ohZ(configuration=iyRCdfum81o30)
	yWMP65EGUpNvos8XIAqadR4V1 = {}
	RfT3n7NSZGbI = locals()
	for FUAvmM61BHoYRKeGsTwrXC4qlZP in RfT3n7NSZGbI: yWMP65EGUpNvos8XIAqadR4V1[FUAvmM61BHoYRKeGsTwrXC4qlZP] = RfT3n7NSZGbI[FUAvmM61BHoYRKeGsTwrXC4qlZP]
	return yWMP65EGUpNvos8XIAqadR4V1
def fyqjBSaPOcFN67idrhIKLDGw531(yWMP65EGUpNvos8XIAqadR4V1,vr3cmNWxh2SVjRqsz,NJX8KZiDeH5QdLtyAo,m4jM2RNzhT0JvyYa6G9ULEFs,ZYF8IqgHdUpWOVeom,hulSHFUcXsaVQGTn8r9zMkNPIwgvo,mm3RKyoTBHgWdkN10GzLfOc,sIZY2toqXQD0irSkpvNOye6HnaFLcP,TX1fMUp9SzCP3RDrAilvu,cFShx14agobH3qOwIC2TKvrQlDAt):
	for FUAvmM61BHoYRKeGsTwrXC4qlZP in yWMP65EGUpNvos8XIAqadR4V1: globals()[FUAvmM61BHoYRKeGsTwrXC4qlZP] = yWMP65EGUpNvos8XIAqadR4V1[FUAvmM61BHoYRKeGsTwrXC4qlZP]
	global jgbUnsINMux0fSZVhTmDvQXr,LDzt67wyepMfg10O8BsGXdR
	mHBMyV7slUNOoxIwhqXLgYdW9aeKfz = BBwb2NzsHE.getSetting('av.language.translate')
	if mHBMyV7slUNOoxIwhqXLgYdW9aeKfz:
		if vr3cmNWxh2SVjRqsz=='نعم  Yes': vr3cmNWxh2SVjRqsz = 'Yes'
		elif vr3cmNWxh2SVjRqsz=='كلا  No': vr3cmNWxh2SVjRqsz = 'No'
		if NJX8KZiDeH5QdLtyAo=='نعم  Yes': NJX8KZiDeH5QdLtyAo = 'Yes'
		elif NJX8KZiDeH5QdLtyAo=='كلا  No': NJX8KZiDeH5QdLtyAo = 'No'
		if m4jM2RNzhT0JvyYa6G9ULEFs=='نعم  Yes': m4jM2RNzhT0JvyYa6G9ULEFs = 'Yes'
		elif m4jM2RNzhT0JvyYa6G9ULEFs=='كلا  No': m4jM2RNzhT0JvyYa6G9ULEFs = 'No'
		pyWkE2rh5uBN4G = UrLi7Bfb1aHQY8E([vr3cmNWxh2SVjRqsz,NJX8KZiDeH5QdLtyAo,m4jM2RNzhT0JvyYa6G9ULEFs,ZYF8IqgHdUpWOVeom,hulSHFUcXsaVQGTn8r9zMkNPIwgvo])
		if pyWkE2rh5uBN4G: vr3cmNWxh2SVjRqsz,NJX8KZiDeH5QdLtyAo,m4jM2RNzhT0JvyYa6G9ULEFs,ZYF8IqgHdUpWOVeom,hulSHFUcXsaVQGTn8r9zMkNPIwgvo = pyWkE2rh5uBN4G
	if wIqFesTOvYnu5S2dWfpBVC:
		hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.decode('utf8')
		ZYF8IqgHdUpWOVeom = ZYF8IqgHdUpWOVeom.decode('utf8')
		vr3cmNWxh2SVjRqsz = vr3cmNWxh2SVjRqsz.decode('utf8')
		NJX8KZiDeH5QdLtyAo = NJX8KZiDeH5QdLtyAo.decode('utf8')
		m4jM2RNzhT0JvyYa6G9ULEFs = m4jM2RNzhT0JvyYa6G9ULEFs.decode('utf8')
	Fox2ODH3ks = ZYF8IqgHdUpWOVeom.count('\n')+1
	VBip4mMgvjsZNcA059e86FQqIwPbr = KN7lqX59nD+Fox2ODH3ks*(fldhzT0MesmZG8rBRk9+F6bkwecKyU3WnIis5YOQPqrT)-F6bkwecKyU3WnIis5YOQPqrT
	if hulSHFUcXsaVQGTn8r9zMkNPIwgvo:
		VKpT0DYFMCEeUc = nm3c75CgUl4TMJvzhutxs-DmYQ0PFvoqidjB7c9zf6C*2
		bnuKlfCgLROWA = JNuW8jEHc0ZP+BOgbMlGxhzo
		KU2Pfq7lX6ApNhTZIr3vijWFHC15 = F2FMfXVun4HzU0iPOWwgjmrqZ.reshape(hulSHFUcXsaVQGTn8r9zMkNPIwgvo)
		if aSnt62o5dDNyc3WMkJzuRH8IUrpZg7:
			arTCn2msUZlb0G7WQukjS = J4JfE3WdRpM(KU2Pfq7lX6ApNhTZIr3vijWFHC15,ii8y3f5cqtr4NDlTa0eHghSv,VKpT0DYFMCEeUc,bnuKlfCgLROWA)
			t5EM1Gae94kALyO = dCO9IkfAUEt6Dx1BZr0binysN8(arTCn2msUZlb0G7WQukjS)
			hu7xlD5zsGQkdo2rW8tU = t5EM1Gae94kALyO.count('\n')+1
			if hu7xlD5zsGQkdo2rW8tU<6:
				zjlFs9TtWBa25vhXu = VKpT0DYFMCEeUc
				arTCn2msUZlb0G7WQukjS = J4JfE3WdRpM(KU2Pfq7lX6ApNhTZIr3vijWFHC15,ii8y3f5cqtr4NDlTa0eHghSv,zjlFs9TtWBa25vhXu,bnuKlfCgLROWA)
				t5EM1Gae94kALyO = dCO9IkfAUEt6Dx1BZr0binysN8(arTCn2msUZlb0G7WQukjS)
				hu7xlD5zsGQkdo2rW8tU = t5EM1Gae94kALyO.count('\n')+1
			GkuLAQXJTOV = GKEMmVcSQf0zLBjix2h+hu7xlD5zsGQkdo2rW8tU*bnuKlfCgLROWA-BOgbMlGxhzo
		else:
			GkuLAQXJTOV = GKEMmVcSQf0zLBjix2h+JNuW8jEHc0ZP
			t5EM1Gae94kALyO = KU2Pfq7lX6ApNhTZIr3vijWFHC15.split('\n')[0]
			arTCn2msUZlb0G7WQukjS = KU2Pfq7lX6ApNhTZIr3vijWFHC15.split('\n')[0]
	else: GkuLAQXJTOV = GKEMmVcSQf0zLBjix2h
	UKLnNAjrg0ZSQMv = D16SzTxtM3EHA07a+AhF4a2qdUX
	if TX1fMUp9SzCP3RDrAilvu:
		YYOv6xuyICtmgRANTw8QsMi1 = FFI0pe7AOVJKbskBrP-vkg0FrT25McEYQAoBIReCpU
		UKLnNAjrg0ZSQMv += YYOv6xuyICtmgRANTw8QsMi1
	else: YYOv6xuyICtmgRANTw8QsMi1 = 0
	if vr3cmNWxh2SVjRqsz or NJX8KZiDeH5QdLtyAo or m4jM2RNzhT0JvyYa6G9ULEFs: UKLnNAjrg0ZSQMv += ovWuKSnzR4Fb
	if Gl3z9ptBDVcKZIjgrTuMs4YxAN!='UPPER': cc6sSVHf57bwXzUFPZ = Gl3z9ptBDVcKZIjgrTuMs4YxAN
	else: cc6sSVHf57bwXzUFPZ = VBip4mMgvjsZNcA059e86FQqIwPbr+GkuLAQXJTOV+UKLnNAjrg0ZSQMv
	zk3JNDOoUZ6fpyWB = cc6sSVHf57bwXzUFPZ-VBip4mMgvjsZNcA059e86FQqIwPbr-UKLnNAjrg0ZSQMv-GKEMmVcSQf0zLBjix2h
	v6hyYUMaqr8ZHSn = y7Pbr6RV0Gij.new('RGBA',(nm3c75CgUl4TMJvzhutxs,cc6sSVHf57bwXzUFPZ),(255,255,255,0))
	xsNZl6a8GXwPty3dHEjoRec7Y = rAtkoeldGFvTLWOn7.Draw(v6hyYUMaqr8ZHSn)
	if not NJX8KZiDeH5QdLtyAo and vr3cmNWxh2SVjRqsz and m4jM2RNzhT0JvyYa6G9ULEFs:
		jgbUnsINMux0fSZVhTmDvQXr += 105
		LDzt67wyepMfg10O8BsGXdR -= 110
	if ZYF8IqgHdUpWOVeom:
		VGaFBCgRcpfYZSmI54uwz7jLeo1y6 = KN7lqX59nD
		ZYF8IqgHdUpWOVeom = Asxc8GDnudJm.get_display(F2FMfXVun4HzU0iPOWwgjmrqZ.reshape(ZYF8IqgHdUpWOVeom))
		ADoPKcJrFuZi = ZYF8IqgHdUpWOVeom.splitlines()
		for D5wxHF2QT6bdzhuyl in ADoPKcJrFuZi:
			if D5wxHF2QT6bdzhuyl:
				T4dCBI3N7D1PqLcJFKiMfE85,To8NIBfhOip = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(D5wxHF2QT6bdzhuyl,font=Kh9zbWTeC4UYtEoAnLrJFZ7iS)
				if UoN1KljmeHsqkdYGZLh7FpxC8=='center': VvjDiXghY4AaxWBCrS = TJ24UEplRA9Xa+(nm3c75CgUl4TMJvzhutxs-T4dCBI3N7D1PqLcJFKiMfE85)/2
				elif UoN1KljmeHsqkdYGZLh7FpxC8=='right': VvjDiXghY4AaxWBCrS = TJ24UEplRA9Xa+nm3c75CgUl4TMJvzhutxs-T4dCBI3N7D1PqLcJFKiMfE85-MYg1Q7TpKiVkLSdcjDNuqo
				elif UoN1KljmeHsqkdYGZLh7FpxC8=='left': VvjDiXghY4AaxWBCrS = TJ24UEplRA9Xa+MYg1Q7TpKiVkLSdcjDNuqo
				xsNZl6a8GXwPty3dHEjoRec7Y.text((VvjDiXghY4AaxWBCrS,VGaFBCgRcpfYZSmI54uwz7jLeo1y6),D5wxHF2QT6bdzhuyl,font=Kh9zbWTeC4UYtEoAnLrJFZ7iS,fill='yellow')
			VGaFBCgRcpfYZSmI54uwz7jLeo1y6 += RnEUj8WNqVKtJMhGguIlf4xDC+F6bkwecKyU3WnIis5YOQPqrT
	if vr3cmNWxh2SVjRqsz or NJX8KZiDeH5QdLtyAo or m4jM2RNzhT0JvyYa6G9ULEFs:
		y9sBIiXWv1pe3L2HC = VBip4mMgvjsZNcA059e86FQqIwPbr+zk3JNDOoUZ6fpyWB+GKEMmVcSQf0zLBjix2h+YYOv6xuyICtmgRANTw8QsMi1+D16SzTxtM3EHA07a
		if vr3cmNWxh2SVjRqsz:
			vr3cmNWxh2SVjRqsz = Asxc8GDnudJm.get_display(F2FMfXVun4HzU0iPOWwgjmrqZ.reshape(vr3cmNWxh2SVjRqsz))
			qlumQYSFT6,R3QEn1FCPbgXGUVadu0teySc85fK = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(vr3cmNWxh2SVjRqsz,font=eZ1qmTtVzMyios3Qc72AxB9hpvC)
			lm2XL56zCb0Y = jgbUnsINMux0fSZVhTmDvQXr+0*(LDzt67wyepMfg10O8BsGXdR+byqwua6TBgGYVsJfmdNrkHC)+(byqwua6TBgGYVsJfmdNrkHC-qlumQYSFT6)/2
			xsNZl6a8GXwPty3dHEjoRec7Y.text((lm2XL56zCb0Y,y9sBIiXWv1pe3L2HC),vr3cmNWxh2SVjRqsz,font=eZ1qmTtVzMyios3Qc72AxB9hpvC,fill='yellow')
		if NJX8KZiDeH5QdLtyAo:
			NJX8KZiDeH5QdLtyAo = Asxc8GDnudJm.get_display(F2FMfXVun4HzU0iPOWwgjmrqZ.reshape(NJX8KZiDeH5QdLtyAo))
			jC3cIN4Fp9,I73ktLGEBd = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(NJX8KZiDeH5QdLtyAo,font=eZ1qmTtVzMyios3Qc72AxB9hpvC)
			D8a6h7MGARZyI2mF1 = jgbUnsINMux0fSZVhTmDvQXr+1*(LDzt67wyepMfg10O8BsGXdR+byqwua6TBgGYVsJfmdNrkHC)+(byqwua6TBgGYVsJfmdNrkHC-jC3cIN4Fp9)/2
			xsNZl6a8GXwPty3dHEjoRec7Y.text((D8a6h7MGARZyI2mF1,y9sBIiXWv1pe3L2HC),NJX8KZiDeH5QdLtyAo,font=eZ1qmTtVzMyios3Qc72AxB9hpvC,fill='yellow')
		if m4jM2RNzhT0JvyYa6G9ULEFs:
			m4jM2RNzhT0JvyYa6G9ULEFs = Asxc8GDnudJm.get_display(F2FMfXVun4HzU0iPOWwgjmrqZ.reshape(m4jM2RNzhT0JvyYa6G9ULEFs))
			XpV1a0tu5m,r53TmLjFHfb0ZBc6GWal = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(m4jM2RNzhT0JvyYa6G9ULEFs,font=eZ1qmTtVzMyios3Qc72AxB9hpvC)
			OPyrLpHlSG2Cxd6uTW0eJVF7h = jgbUnsINMux0fSZVhTmDvQXr+2*(LDzt67wyepMfg10O8BsGXdR+byqwua6TBgGYVsJfmdNrkHC)+(byqwua6TBgGYVsJfmdNrkHC-XpV1a0tu5m)/2
			xsNZl6a8GXwPty3dHEjoRec7Y.text((OPyrLpHlSG2Cxd6uTW0eJVF7h,y9sBIiXWv1pe3L2HC),m4jM2RNzhT0JvyYa6G9ULEFs,font=eZ1qmTtVzMyios3Qc72AxB9hpvC,fill='yellow')
	if hulSHFUcXsaVQGTn8r9zMkNPIwgvo:
		vtjxwSC1VKb2q5rLsIdOizGZU,cx5BrTASeqR2nkvtPuCGl4KY = [],[]
		arTCn2msUZlb0G7WQukjS = bnaIM2NVrRDAtYejCupv6(arTCn2msUZlb0G7WQukjS)
		zZGBpetyb8uo = arTCn2msUZlb0G7WQukjS.split('_sss__newline_')
		for RHihJ5EsOKLgnpvj6kbMG7AtXml in zZGBpetyb8uo:
			STNZtK9o5bIap02XFzeQjCH = sIZY2toqXQD0irSkpvNOye6HnaFLcP
			if   '_sss__lineleft_' in RHihJ5EsOKLgnpvj6kbMG7AtXml: STNZtK9o5bIap02XFzeQjCH = 'left'
			elif '_sss__lineright_' in RHihJ5EsOKLgnpvj6kbMG7AtXml: STNZtK9o5bIap02XFzeQjCH = 'right'
			elif '_sss__linecenter_' in RHihJ5EsOKLgnpvj6kbMG7AtXml: STNZtK9o5bIap02XFzeQjCH = 'center'
			Czogsx8EVubfnaSwIcJDF35rh = RHihJ5EsOKLgnpvj6kbMG7AtXml
			A4AoyxJPLDN = JJDtX1PZyIgN2T.findall('_sss__.*?_',RHihJ5EsOKLgnpvj6kbMG7AtXml,JJDtX1PZyIgN2T.DOTALL)
			for UEZo8yhR2i0udn in A4AoyxJPLDN: Czogsx8EVubfnaSwIcJDF35rh = Czogsx8EVubfnaSwIcJDF35rh.replace(UEZo8yhR2i0udn,'')
			if Czogsx8EVubfnaSwIcJDF35rh=='': T4dCBI3N7D1PqLcJFKiMfE85,To8NIBfhOip = 0,bnuKlfCgLROWA
			else: T4dCBI3N7D1PqLcJFKiMfE85,To8NIBfhOip = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(Czogsx8EVubfnaSwIcJDF35rh,font=LLgeTjIKDtR0aZJF3C)
			if   STNZtK9o5bIap02XFzeQjCH=='left': VSOnKrmA86Jd4 = zHs9btVcLe+DmYQ0PFvoqidjB7c9zf6C
			elif STNZtK9o5bIap02XFzeQjCH=='right': VSOnKrmA86Jd4 = zHs9btVcLe+DmYQ0PFvoqidjB7c9zf6C+VKpT0DYFMCEeUc-T4dCBI3N7D1PqLcJFKiMfE85
			elif STNZtK9o5bIap02XFzeQjCH=='center': VSOnKrmA86Jd4 = zHs9btVcLe+DmYQ0PFvoqidjB7c9zf6C+(VKpT0DYFMCEeUc-T4dCBI3N7D1PqLcJFKiMfE85)/2
			if VSOnKrmA86Jd4<DmYQ0PFvoqidjB7c9zf6C: VSOnKrmA86Jd4 = zHs9btVcLe+DmYQ0PFvoqidjB7c9zf6C
			vtjxwSC1VKb2q5rLsIdOizGZU.append(VSOnKrmA86Jd4)
			cx5BrTASeqR2nkvtPuCGl4KY.append(T4dCBI3N7D1PqLcJFKiMfE85)
		VSOnKrmA86Jd4 = vtjxwSC1VKb2q5rLsIdOizGZU[0]
		szNBL0d42I5fqivDR9lJnOMHYgokWX = arTCn2msUZlb0G7WQukjS.split('_sss_')
		K8dst6I4mvPiGOUExZjHf = (255,255,255,255)
		TwOXYu0U8kJ = K8dst6I4mvPiGOUExZjHf
		vDbQ97JhaHeOZpt,X3ajYKSwJn8FNbl4kIrsEZ2pDgUqO = 0,0
		jMnvIH7kV4TP08itzSN = False
		kwW86nXlyeVo4jPJQBUHhmS5bK = 0
		JIPzYsli6hr5K7OoTCV28M = VBip4mMgvjsZNcA059e86FQqIwPbr+GKEMmVcSQf0zLBjix2h/2
		if GkuLAQXJTOV<(zk3JNDOoUZ6fpyWB+GKEMmVcSQf0zLBjix2h):
			OB1T4fiwgRv6ueP = (zk3JNDOoUZ6fpyWB+GKEMmVcSQf0zLBjix2h-GkuLAQXJTOV)/2
			JIPzYsli6hr5K7OoTCV28M = VBip4mMgvjsZNcA059e86FQqIwPbr+GKEMmVcSQf0zLBjix2h+OB1T4fiwgRv6ueP-JNuW8jEHc0ZP/2
		for D5wxHF2QT6bdzhuyl in szNBL0d42I5fqivDR9lJnOMHYgokWX:
			if not D5wxHF2QT6bdzhuyl or (D5wxHF2QT6bdzhuyl and ord(D5wxHF2QT6bdzhuyl[0])==65279): continue
			mmplBzOX4N = D5wxHF2QT6bdzhuyl.split('_newline_',1)
			jjNIkuls0o = D5wxHF2QT6bdzhuyl.split('_newcolor',1)
			oo5ClVzZO1 = D5wxHF2QT6bdzhuyl.split('_endcolor_',1)
			FkHiQVw4DYmWBR = D5wxHF2QT6bdzhuyl.split('_linertl_',1)
			t7rpBaSMjnwY5FOuLyI6D = D5wxHF2QT6bdzhuyl.split('_lineleft_',1)
			oet9ScUgvXFLzq8kdEsuAVCR6xnj = D5wxHF2QT6bdzhuyl.split('_lineright_',1)
			IqT18K0AwxS9rUEzsDCHyORtg = D5wxHF2QT6bdzhuyl.split('_linecenter_',1)
			if len(mmplBzOX4N)>1:
				kwW86nXlyeVo4jPJQBUHhmS5bK += 1
				D5wxHF2QT6bdzhuyl = mmplBzOX4N[1]
				vDbQ97JhaHeOZpt = 0
				VSOnKrmA86Jd4 = vtjxwSC1VKb2q5rLsIdOizGZU[kwW86nXlyeVo4jPJQBUHhmS5bK]
				X3ajYKSwJn8FNbl4kIrsEZ2pDgUqO += bnuKlfCgLROWA
				jMnvIH7kV4TP08itzSN = False
			elif len(jjNIkuls0o)>1:
				D5wxHF2QT6bdzhuyl = jjNIkuls0o[1]
				TwOXYu0U8kJ = D5wxHF2QT6bdzhuyl[0:8]
				TwOXYu0U8kJ = '#'+TwOXYu0U8kJ[2:]
				D5wxHF2QT6bdzhuyl = D5wxHF2QT6bdzhuyl[9:]
			elif len(oo5ClVzZO1)>1:
				D5wxHF2QT6bdzhuyl = oo5ClVzZO1[1]
				TwOXYu0U8kJ = K8dst6I4mvPiGOUExZjHf
			elif len(FkHiQVw4DYmWBR)>1:
				D5wxHF2QT6bdzhuyl = FkHiQVw4DYmWBR[1]
				jMnvIH7kV4TP08itzSN = True
				vDbQ97JhaHeOZpt = cx5BrTASeqR2nkvtPuCGl4KY[kwW86nXlyeVo4jPJQBUHhmS5bK]
			elif len(t7rpBaSMjnwY5FOuLyI6D)>1: D5wxHF2QT6bdzhuyl = t7rpBaSMjnwY5FOuLyI6D[1]
			elif len(oet9ScUgvXFLzq8kdEsuAVCR6xnj)>1: D5wxHF2QT6bdzhuyl = oet9ScUgvXFLzq8kdEsuAVCR6xnj[1]
			elif len(IqT18K0AwxS9rUEzsDCHyORtg)>1: D5wxHF2QT6bdzhuyl = IqT18K0AwxS9rUEzsDCHyORtg[1]
			if D5wxHF2QT6bdzhuyl:
				kvwdz4N12UPeJg7DaYf5uL0bmx8i = JIPzYsli6hr5K7OoTCV28M+X3ajYKSwJn8FNbl4kIrsEZ2pDgUqO
				D5wxHF2QT6bdzhuyl = Asxc8GDnudJm.get_display(D5wxHF2QT6bdzhuyl)
				T4dCBI3N7D1PqLcJFKiMfE85,To8NIBfhOip = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(D5wxHF2QT6bdzhuyl,font=LLgeTjIKDtR0aZJF3C)
				if jMnvIH7kV4TP08itzSN: vDbQ97JhaHeOZpt -= T4dCBI3N7D1PqLcJFKiMfE85
				UfpGQBecViE9DzM2LS = VSOnKrmA86Jd4+vDbQ97JhaHeOZpt
				xsNZl6a8GXwPty3dHEjoRec7Y.text((UfpGQBecViE9DzM2LS,kvwdz4N12UPeJg7DaYf5uL0bmx8i),D5wxHF2QT6bdzhuyl,font=LLgeTjIKDtR0aZJF3C,fill=TwOXYu0U8kJ)
				if mm3RKyoTBHgWdkN10GzLfOc=='menu_item':
					xsNZl6a8GXwPty3dHEjoRec7Y.text((UfpGQBecViE9DzM2LS+1,kvwdz4N12UPeJg7DaYf5uL0bmx8i+1),D5wxHF2QT6bdzhuyl,font=LLgeTjIKDtR0aZJF3C,fill=TwOXYu0U8kJ)
				if not jMnvIH7kV4TP08itzSN: vDbQ97JhaHeOZpt += T4dCBI3N7D1PqLcJFKiMfE85
				if kvwdz4N12UPeJg7DaYf5uL0bmx8i>zk3JNDOoUZ6fpyWB+bnuKlfCgLROWA: break
	if mm3RKyoTBHgWdkN10GzLfOc=='menu_item':
		v6hyYUMaqr8ZHSn = v6hyYUMaqr8ZHSn.resize((200,200))
		EE1u9R73WAIcJkqg4sjoaChyznZ2 = dduW8KFxIJisqH5VOwgaBvPnb.copy()
		EE1u9R73WAIcJkqg4sjoaChyznZ2.paste(PC9mZteO2zYoq8d,(0,0),mask=v6hyYUMaqr8ZHSn)
	else: EE1u9R73WAIcJkqg4sjoaChyznZ2 = v6hyYUMaqr8ZHSn
	if wIqFesTOvYnu5S2dWfpBVC: cFShx14agobH3qOwIC2TKvrQlDAt = cFShx14agobH3qOwIC2TKvrQlDAt.decode('utf8')
	try: EE1u9R73WAIcJkqg4sjoaChyznZ2.save(cFShx14agobH3qOwIC2TKvrQlDAt)
	except:
		TBZlMAWLt1x2 = A73K6zLXIgFROeCHJQi0Pbos.path.dirname(cFShx14agobH3qOwIC2TKvrQlDAt)
		try: A73K6zLXIgFROeCHJQi0Pbos.makedirs(TBZlMAWLt1x2)
		except: pass
		EE1u9R73WAIcJkqg4sjoaChyznZ2.save(cFShx14agobH3qOwIC2TKvrQlDAt)
	return cc6sSVHf57bwXzUFPZ
def J4JfE3WdRpM(UgMon2aVDFS,WwGprbdLFzisMJaIR4KgxB0USv8u,RDeWrP6OvdEgNYZBmqhj,JPrDkVhpabInxlYtcsHvu6):
	RkqAQLBVdZfF2rO6sizG3juKD,mmF6IvfoWaY4Qwh8RPNu,RFOzrKsGw3H6Puey = '',0,15000
	UgMon2aVDFS = UgMon2aVDFS.replace('[COLOR ','[COLOR:::')
	k8wTlexG6NKpJrCBXQZy = V47MU09QYBNxTjHF.truetype(S3SXQP5fkxTymI4r,size=WwGprbdLFzisMJaIR4KgxB0USv8u)
	RDeWrP6OvdEgNYZBmqhj -= WwGprbdLFzisMJaIR4KgxB0USv8u*2
	v6hyYUMaqr8ZHSn = y7Pbr6RV0Gij.new('RGBA',(RDeWrP6OvdEgNYZBmqhj,99),(255,255,255,0))
	xsNZl6a8GXwPty3dHEjoRec7Y = rAtkoeldGFvTLWOn7.Draw(v6hyYUMaqr8ZHSn)
	for GG1yBDImYu7L in UgMon2aVDFS.splitlines():
		mmF6IvfoWaY4Qwh8RPNu += JPrDkVhpabInxlYtcsHvu6
		OOgdhnAD08,a1BUbDzN9LmXf = 0,''
		for SMbpCQINGj2g4dqD0P in GG1yBDImYu7L.split(' '):
			JFcMlUsH9hOmKn7bu8Yp6fP5NW = dCO9IkfAUEt6Dx1BZr0binysN8(' '+SMbpCQINGj2g4dqD0P)
			tBrLkH4F5lsaEmURdZjVWw87v,YGcoQ7ZXxKEI2mqkrl4fnjwigtO = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(JFcMlUsH9hOmKn7bu8Yp6fP5NW,font=k8wTlexG6NKpJrCBXQZy)
			if OOgdhnAD08+tBrLkH4F5lsaEmURdZjVWw87v<RDeWrP6OvdEgNYZBmqhj:
				if not a1BUbDzN9LmXf: a1BUbDzN9LmXf += SMbpCQINGj2g4dqD0P
				else: a1BUbDzN9LmXf += ' '+SMbpCQINGj2g4dqD0P
				OOgdhnAD08 += tBrLkH4F5lsaEmURdZjVWw87v
			else:
				if tBrLkH4F5lsaEmURdZjVWw87v<RDeWrP6OvdEgNYZBmqhj:
					a1BUbDzN9LmXf += '\n '+SMbpCQINGj2g4dqD0P
					mmF6IvfoWaY4Qwh8RPNu += JPrDkVhpabInxlYtcsHvu6
					OOgdhnAD08 = tBrLkH4F5lsaEmURdZjVWw87v
				else:
					while tBrLkH4F5lsaEmURdZjVWw87v>RDeWrP6OvdEgNYZBmqhj:
						for NzfP6biDZJAqmyensuhE7HjwYvlQk in range(1,len(' '+SMbpCQINGj2g4dqD0P),1):
							nBC0FuQGILYKJN42derf = ' '+SMbpCQINGj2g4dqD0P[:NzfP6biDZJAqmyensuhE7HjwYvlQk]
							zzbgEXVSoTQd = SMbpCQINGj2g4dqD0P[NzfP6biDZJAqmyensuhE7HjwYvlQk:]
							it1lQvedMp25AVoaS8 = dCO9IkfAUEt6Dx1BZr0binysN8(nBC0FuQGILYKJN42derf)
							WKi9hxn7fEUHlSZp2y,HKmBuU0IdveXaG5b162oZQVFSr = xsNZl6a8GXwPty3dHEjoRec7Y.textsize(it1lQvedMp25AVoaS8,font=k8wTlexG6NKpJrCBXQZy)
							if OOgdhnAD08+WKi9hxn7fEUHlSZp2y>RDeWrP6OvdEgNYZBmqhj:
								zzD3MlmvkBtZ5gYHhTAWLJidX = tBrLkH4F5lsaEmURdZjVWw87v-WKi9hxn7fEUHlSZp2y
								a1BUbDzN9LmXf += nBC0FuQGILYKJN42derf+'\n'
								mmF6IvfoWaY4Qwh8RPNu += JPrDkVhpabInxlYtcsHvu6
								tBrLkH4F5lsaEmURdZjVWw87v = zzD3MlmvkBtZ5gYHhTAWLJidX
								if zzD3MlmvkBtZ5gYHhTAWLJidX>RDeWrP6OvdEgNYZBmqhj:
									OOgdhnAD08 = 0
									SMbpCQINGj2g4dqD0P = zzbgEXVSoTQd
								else:
									OOgdhnAD08 = zzD3MlmvkBtZ5gYHhTAWLJidX
									a1BUbDzN9LmXf += zzbgEXVSoTQd
								break
				if mmF6IvfoWaY4Qwh8RPNu>RFOzrKsGw3H6Puey: break
		RkqAQLBVdZfF2rO6sizG3juKD += '\n'+a1BUbDzN9LmXf
		if mmF6IvfoWaY4Qwh8RPNu>RFOzrKsGw3H6Puey: break
	RkqAQLBVdZfF2rO6sizG3juKD = RkqAQLBVdZfF2rO6sizG3juKD[1:]
	RkqAQLBVdZfF2rO6sizG3juKD = RkqAQLBVdZfF2rO6sizG3juKD.replace('[COLOR:::','[COLOR ')
	return RkqAQLBVdZfF2rO6sizG3juKD
def dCO9IkfAUEt6Dx1BZr0binysN8(SMbpCQINGj2g4dqD0P):
	if '[' in SMbpCQINGj2g4dqD0P and ']' in SMbpCQINGj2g4dqD0P:
		A4AoyxJPLDN = ['[/COLOR]','[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		f4ZhOiBqwXvaP = JJDtX1PZyIgN2T.findall('\[COLOR .*?\]',SMbpCQINGj2g4dqD0P,JJDtX1PZyIgN2T.DOTALL)
		CUaN3B7nXcsGdDoxgK0VkljhWLptJY = JJDtX1PZyIgN2T.findall('\[COLOR:::.*?\]',SMbpCQINGj2g4dqD0P,JJDtX1PZyIgN2T.DOTALL)
		oobUJE9NdtLB30RQkvGK = A4AoyxJPLDN+f4ZhOiBqwXvaP+CUaN3B7nXcsGdDoxgK0VkljhWLptJY
		for UEZo8yhR2i0udn in oobUJE9NdtLB30RQkvGK: SMbpCQINGj2g4dqD0P = SMbpCQINGj2g4dqD0P.replace(UEZo8yhR2i0udn,'')
	return SMbpCQINGj2g4dqD0P
def bnaIM2NVrRDAtYejCupv6(hulSHFUcXsaVQGTn8r9zMkNPIwgvo):
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('\n','_sss__newline_')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RTL]','_sss__linertl_')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[LEFT]','_sss__lineleft_')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[RIGHT]','_sss__lineright_')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[CENTER]','_sss__linecenter_')
	hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[/COLOR]','_sss__endcolor_')
	BYmsltdc3Apr1nNWqgoGLV = JJDtX1PZyIgN2T.findall('\[COLOR (.*?)\]',hulSHFUcXsaVQGTn8r9zMkNPIwgvo,JJDtX1PZyIgN2T.DOTALL)
	for QQtbwYhXA1nWxNJcSHeIOTm in BYmsltdc3Apr1nNWqgoGLV: hulSHFUcXsaVQGTn8r9zMkNPIwgvo = hulSHFUcXsaVQGTn8r9zMkNPIwgvo.replace('[COLOR '+QQtbwYhXA1nWxNJcSHeIOTm+']','_sss__newcolor'+QQtbwYhXA1nWxNJcSHeIOTm+'_')
	return hulSHFUcXsaVQGTn8r9zMkNPIwgvo
def xaEZjvs6y0qt2Wmh(rBabYANvVwWzjCp2QF=''):
	if not rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel('ListItem.Label')
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('[/COLOR]','')
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('    ',' ').replace('   ',' ').replace('  ',' ').strip(' ')
	rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.replace('[COLOR FFFFFF00]','').replace('[COLOR FFC89008]','')
	rrafdlA1I3 = JJDtX1PZyIgN2T.findall('\d\d:\d\d ',rBabYANvVwWzjCp2QF,JJDtX1PZyIgN2T.DOTALL)
	if rrafdlA1I3: rBabYANvVwWzjCp2QF = rBabYANvVwWzjCp2QF.split(rrafdlA1I3[0],1)[1]
	if not rBabYANvVwWzjCp2QF: rBabYANvVwWzjCp2QF = 'Main Menu'
	return rBabYANvVwWzjCp2QF
def qIKCc75Futx6BpNPz(TTkmwqXoLyID837SW9MtlxAg):
	DILlYACJEMwBUZ4V = ''.join(NzfP6biDZJAqmyensuhE7HjwYvlQk for NzfP6biDZJAqmyensuhE7HjwYvlQk in TTkmwqXoLyID837SW9MtlxAg if NzfP6biDZJAqmyensuhE7HjwYvlQk not in '\/":*?<>|'+XTN45xdOzVH0vkep23thYInWPCZ)
	return DILlYACJEMwBUZ4V
def lZVqvuJG40hwcXFIdeiP(WXU2APNzuivcGgq):
	fWSqB07JuGo6jC5vHFIzpDN1PMYsb = JJDtX1PZyIgN2T.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",WXU2APNzuivcGgq,JJDtX1PZyIgN2T.S)
	if fWSqB07JuGo6jC5vHFIzpDN1PMYsb:
		cXNyMohRxIi,Mf5U4WKRvx0otQI = fWSqB07JuGo6jC5vHFIzpDN1PMYsb[0]
		cXNyMohRxIi = JJDtX1PZyIgN2T.findall("=[\r\n\s\t]+'(.*?)';", cXNyMohRxIi, JJDtX1PZyIgN2T.S)[0]
		if cXNyMohRxIi and Mf5U4WKRvx0otQI:
			WlsL0jmtDJKv6koafISbPhZO5EFXY = cXNyMohRxIi.replace("'",'').replace("+",'').replace("\n",'').replace("\r",'')
			T1tzaDmYXQSlFJg = WlsL0jmtDJKv6koafISbPhZO5EFXY.split('.')
			WXU2APNzuivcGgq = ''
			for c1cfMz7OJKg59y6kW4dGwvB0 in T1tzaDmYXQSlFJg:
				SYquQxdlJe6DgG07b19kUVhnEpN4X = gPSZVjJHKIL.b64decode(c1cfMz7OJKg59y6kW4dGwvB0+'==').decode('utf8')
				dOyDES8M5UzZQs6r1qbnojX2340i = JJDtX1PZyIgN2T.findall('\d+', SYquQxdlJe6DgG07b19kUVhnEpN4X, JJDtX1PZyIgN2T.S)
				if dOyDES8M5UzZQs6r1qbnojX2340i:
					NxYd0yEm7Cv82qJDM = int(dOyDES8M5UzZQs6r1qbnojX2340i[0])
					NxYd0yEm7Cv82qJDM += int(Mf5U4WKRvx0otQI)
					WXU2APNzuivcGgq = WXU2APNzuivcGgq + chr(NxYd0yEm7Cv82qJDM)
			if DQfHadYvTpy1UR: WXU2APNzuivcGgq = WXU2APNzuivcGgq.encode('iso-8859-1').decode('utf8')
	return WXU2APNzuivcGgq
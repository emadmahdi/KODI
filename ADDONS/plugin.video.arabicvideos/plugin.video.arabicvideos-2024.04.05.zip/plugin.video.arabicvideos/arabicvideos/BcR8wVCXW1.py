# -*- coding: utf-8 -*-
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = 'ARABICTOONS'
eMlwAzaLSj8ZEQ3txIGP = '_ART_'
kU2ZXSViB3wLANOz8bH = LWzUbE5adDslTXGr[FpjtBKrnu5SdfyOvEPIQ][0]
def HYWukw3pL2oMzPK4(mode,url,text):
	if   mode==730: mL7BVKcSygkuoPbWlEF4YD = UQ8xVqP243HvaWOMtJSp()
	elif mode==731: mL7BVKcSygkuoPbWlEF4YD = d2JXnUMPmgsKBQqCE58lkZ(url)
	elif mode==732: mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(url)
	elif mode==733: mL7BVKcSygkuoPbWlEF4YD = sjmSkpqHVtPcv(url)
	elif mode==734: mL7BVKcSygkuoPbWlEF4YD = Pp4ysWjIGgw7EY3(url)
	elif mode==735: mL7BVKcSygkuoPbWlEF4YD = Ob0VJT9IeHAfShNwZQtKU(url)
	elif mode==739: mL7BVKcSygkuoPbWlEF4YD = VH5hnQa7CPSR1tMlZ03Wpx8(text)
	else: mL7BVKcSygkuoPbWlEF4YD = False
	return mL7BVKcSygkuoPbWlEF4YD
def UQ8xVqP243HvaWOMtJSp():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'بحث في الموقع','',739,'','','_REMEMBERRESULTS_')
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]','',9999)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مسلسلات مميزة',kU2ZXSViB3wLANOz8bH+'/top.php',735)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'مسلسلات',kU2ZXSViB3wLANOz8bH+'/cartoon.php',734)
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',FpjtBKrnu5SdfyOvEPIQ+'_SCRIPT_'+eMlwAzaLSj8ZEQ3txIGP+'افلام',kU2ZXSViB3wLANOz8bH+'/movies.php',731)
	return
def Pp4ysWjIGgw7EY3(url):
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'الكل',url,731)
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-SERIES_SUBMENU-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('label="navigation"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall("href='(.*?)'>(.*?)</a>",mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = 'حرف '+title
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,731)
	return
def Ob0VJT9IeHAfShNwZQtKU(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-SERIES_FEATURED-2nd')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('class="slider"(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
			title = title.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,733,ggdRiBo3smurLUGO)
	return
def d2JXnUMPmgsKBQqCE58lkZ(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-TITLES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("class='moviesBlocks(.*?)navigation",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
	items = JJDtX1PZyIgN2T.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
		ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
		title = title.strip(' ')
		if 'movies.php' in url: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,732,ggdRiBo3smurLUGO)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,733,ggdRiBo3smurLUGO)
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall('"pagination(.*?)</ul>',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[-1]
		items = JJDtX1PZyIgN2T.findall('href="(.*?)".*?>(.*?)</a>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for wHiSfdBL1v9Kl3n5,title in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			title = title.strip(' ')
			title = jbigKDeUf0OSMrRkly2B5I3Act(title)
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+'صفحة '+title,wHiSfdBL1v9Kl3n5,731)
	return
def sjmSkpqHVtPcv(url):
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-EPISODES-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	GGbRgKaoskDC = JJDtX1PZyIgN2T.findall("class='moviesBlocks(.*?)script",YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if GGbRgKaoskDC:
		mvgk7pP8Fw6heMSWd5oXn9itl = GGbRgKaoskDC[0]
		items = JJDtX1PZyIgN2T.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',mvgk7pP8Fw6heMSWd5oXn9itl,JJDtX1PZyIgN2T.DOTALL)
		for title,wHiSfdBL1v9Kl3n5,ggdRiBo3smurLUGO,wv7hlIgB05LTsGduAVHWDQ1f in items:
			wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
			ggdRiBo3smurLUGO = kU2ZXSViB3wLANOz8bH+'/'+ggdRiBo3smurLUGO
			title = title.strip(' ')
			title = title+' '+wv7hlIgB05LTsGduAVHWDQ1f.strip(' ')
			nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,732,ggdRiBo3smurLUGO)
	return
def CsUdRabWuh0M9F(url):
	pB8XANf71vaPJsedkWVIc5 = []
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-PLAY-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	kwqYoF8han = JJDtX1PZyIgN2T.findall('source src="(.*?)"',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	if kwqYoF8han:
		wHiSfdBL1v9Kl3n5 = kwqYoF8han[0]
		if 'Referer=' not in wHiSfdBL1v9Kl3n5: wHiSfdBL1v9Kl3n5 = wHiSfdBL1v9Kl3n5+'|Referer=https://www.arabic-toons.com'
		pB8XANf71vaPJsedkWVIc5.append(wHiSfdBL1v9Kl3n5+'?named=__embed')
	import jfGcn9x8KN
	jfGcn9x8KN.AkMyd9E2pVrbG7g5(pB8XANf71vaPJsedkWVIc5,FpjtBKrnu5SdfyOvEPIQ,'video',url)
	return
def VH5hnQa7CPSR1tMlZ03Wpx8(search):
	search,sdZQpO06qbHwAGPz7LCgu4lToE,showDialogs = aCId1D0KbRVrm6jq98UwyuFWkeX3(search)
	if search=='': search = GVfnMyZxiRI()
	if search=='': return
	search = search.replace(' ','%20')
	EEgFl59RndzrBL8TUoaQMw6P = ['','m']
	tjI2D513v7Yiyk6PesSnobKEWJ = ['مسلسلات','افلام']
	if showDialogs:
		zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT('اختر النوع المطلوب:', tjI2D513v7Yiyk6PesSnobKEWJ)
		if zKgFfQoODy90ewYb5jGElUJRVs4p==-1: return
	else: zKgFfQoODy90ewYb5jGElUJRVs4p = 0
	type = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	url = kU2ZXSViB3wLANOz8bH+'/livesearch.php?'+type+'&q='+search
	SSzrgUnfVGL1hQsu40FoP7CWXax = zibnBvFtmwKplXrg(DkRgFyVIBM85OA,'GET',url,'','','','','ARABICTOONS-SEARCH-1st')
	YBEsLq8gVw629cMGQP1T = SSzrgUnfVGL1hQsu40FoP7CWXax.content
	items = JJDtX1PZyIgN2T.findall('href="(.*?)">(.*?)<',YBEsLq8gVw629cMGQP1T,JJDtX1PZyIgN2T.DOTALL)
	for wHiSfdBL1v9Kl3n5,title in items:
		wHiSfdBL1v9Kl3n5 = kU2ZXSViB3wLANOz8bH+'/'+wHiSfdBL1v9Kl3n5
		title = title.strip(' ')
		if type=='m': nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('video',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,732)
		else: nUHOFvo7RiecSJ5V9zPEhCkWZqY86G('folder',eMlwAzaLSj8ZEQ3txIGP+title,wHiSfdBL1v9Kl3n5,733)
	return
# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
import xbmc as Wj3qSagkcweAb2prRiDyM0HK7Guo,re as JJDtX1PZyIgN2T,sys as uea9JUBOMcEfh8CN0v6b,xbmcaddon as zToRkFxN3PemAqS60tD5LpB2VUdHg,random as GpOkwndjsI27uM,os as A73K6zLXIgFROeCHJQi0Pbos,xbmcvfs as SZKinUj8DBxCX3aepygo7fs4kwr2,time as Mrx2OeZV1LNjBsQ58Savi7,pickle as agQL8CV9Rb1YOlqW6IG7v,zlib as rxfk1jENTUA5XvMbG8acWIeCQi9,xbmcgui as U6zsmRNGTL,xbmcplugin as wwxkRfBvlShcg72TKtbdyQrniEY,sqlite3 as gxoYzqsnPQ,traceback as By7dgpHrCuDPh3VfxiJ9n2,threading as g6OFXePvfKW0SjLm4G5uBrQnYRIwC
FpjtBKrnu5SdfyOvEPIQ = u2NDjURZVHlmdc0(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬਰ")
fcISoWNUG0HKemCtBpAy9MV = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon().getAddonInfo(xmTX9Aeidq8cVhY(u"ࠬࡶࡡࡵࡪࠪ਱"))
nDYQ7WabfVNuZ = A73K6zLXIgFROeCHJQi0Pbos.path.join(fcISoWNUG0HKemCtBpAy9MV,A6Iyo7eXrq2RtMmDxWj(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨਲ"))
uea9JUBOMcEfh8CN0v6b.path.append(nDYQ7WabfVNuZ)
L2N3maPfeUCuG1rd4whqF = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(ebT9xRB63E(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨਲ਼"))
WWSLAyQdhUXl3ovb = JJDtX1PZyIgN2T.findall(ebT9xRB63E(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ਴"),L2N3maPfeUCuG1rd4whqF,JJDtX1PZyIgN2T.DOTALL)
WWSLAyQdhUXl3ovb = float(WWSLAyQdhUXl3ovb[tjoHEAGv2XkrMBsVfCyp5U(u"࠰ఁ")])
KnD1WCe34Z890xBitm5MsQaP6hVOH = Wj3qSagkcweAb2prRiDyM0HK7Guo.Player
jLxTKuQmGcE = U6zsmRNGTL.WindowXMLDialog
wIqFesTOvYnu5S2dWfpBVC = WWSLAyQdhUXl3ovb<vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠲࠻ం")
DQfHadYvTpy1UR = WWSLAyQdhUXl3ovb>oh1JUWa3LdnqTpz5(u"࠳࠻࠲࠾࠿ః")
if DQfHadYvTpy1UR:
	wjuG4C2v6medtRU7 = Wj3qSagkcweAb2prRiDyM0HK7Guo.LOGINFO
	ccdMiA5sZ0koIRwpFgeU8j,SBPbYXN9Rt2MHDrnU4mhlV0 = VVtQk9vwe7(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪਵ"),u2NDjURZVHlmdc0(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫਸ਼")
	yDEF7f8jYugdKa = SZKinUj8DBxCX3aepygo7fs4kwr2.translatePath(oh1JUWa3LdnqTpz5(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ਷"))
	from urllib.parse import unquote as _MtTwklrC9xivHsjXL7z
else:
	wjuG4C2v6medtRU7 = Wj3qSagkcweAb2prRiDyM0HK7Guo.LOGNOTICE
	ccdMiA5sZ0koIRwpFgeU8j,SBPbYXN9Rt2MHDrnU4mhlV0 = DItWNMaLOZ146CubYk8lfAwTy(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ਸ").encode(tvdQHb10PhNmuy6(u"࠭ࡵࡵࡨ࠻ࠫਹ")),ebT9xRB63E(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ਺").encode(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡷࡷࡪ࠽࠭਻"))
	yDEF7f8jYugdKa = Wj3qSagkcweAb2prRiDyM0HK7Guo.translatePath(Wbwj0o5gsXQ8F2f(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲ਼ࠪ"))
	from urllib import unquote as _MtTwklrC9xivHsjXL7z
GuTv8U2p9XQnZFMb4LkJm = CC4UDLW6brf(u"࠹࠴ఄ")
sseNwgOx0mZkuoQX = A6Iyo7eXrq2RtMmDxWj(u"࠺࠵అ")*GuTv8U2p9XQnZFMb4LkJm
AYOxyR0t4hI5bWmgi8jEZlpMXkenK = VVtQk9vwe7(u"࠷࠺ఆ")*sseNwgOx0mZkuoQX
DtWI3iOgvJ7dh = cg94WALw5orUhvtHSfNO(u"࠹࠰ఇ")*AYOxyR0t4hI5bWmgi8jEZlpMXkenK
jCJnzmXDkNqtB = CC4UDLW6brf(u"࠰ఈ")
WfPehiKL4XVlonMQr9kUwAca6IybDj = u2NDjURZVHlmdc0(u"࠴࠲ఉ")*GuTv8U2p9XQnZFMb4LkJm
mjBa0HgvKnI4oWRd = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠴ఊ")*sseNwgOx0mZkuoQX
DkRgFyVIBM85OA = xmTX9Aeidq8cVhY(u"࠴࠺ఋ")*sseNwgOx0mZkuoQX
UHnG2wYuIQWKN38B4 = cg94WALw5orUhvtHSfNO(u"࠷ఌ")*AYOxyR0t4hI5bWmgi8jEZlpMXkenK
u5vT6erC7PYdV18MNSwRnJE = b46fBrugtPDSYspzMQIx(u"࠸࠶఍")*AYOxyR0t4hI5bWmgi8jEZlpMXkenK
iJnLmxA0ykozR98WXFQ4Ye3w = CC4UDLW6brf(u"࠷࠲ఎ")*DtWI3iOgvJ7dh
A1DMaRiPpTLJQvw6B7OdKbU439 = cg94WALw5orUhvtHSfNO(u"࠱ఏ")*sseNwgOx0mZkuoQX
f3pCnmFaVYx4zc1MNGBe5 = uea9JUBOMcEfh8CN0v6b.argv[GVPK9Ziaho6U2ySLj(u"࠱ఐ")].split(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪ࠳ࠬ਽"))[b46fBrugtPDSYspzMQIx(u"࠴఑")]
MPBU8HXFoN3Ocj = int(uea9JUBOMcEfh8CN0v6b.argv[WfgnOq9Fd4lhMSQpK5(u"࠴ఒ")])
QfEL1VroTPIFZkmzjv5O = uea9JUBOMcEfh8CN0v6b.argv[uEed4OSxm7hBq9Vvky6QjHwWC(u"࠶ఓ")]
DDrdYk7wegNmiC = f3pCnmFaVYx4zc1MNGBe5.split(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠫ࠳࠭ਾ"))[vdHRKkIgTp56Je1OuNo(u"࠷ఔ")]
K0dHTfq6P73sD8lWLZpoh = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(vdHRKkIgTp56Je1OuNo(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬਿ")+f3pCnmFaVYx4zc1MNGBe5+GVPK9Ziaho6U2ySLj(u"࠭ࠩࠨੀ"))
HnMP40juJfr6L1mexbWBV = A73K6zLXIgFROeCHJQi0Pbos.path.join(yDEF7f8jYugdKa,f3pCnmFaVYx4zc1MNGBe5)
tnQMXOP5mgZVI = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,G5TxeI0ND4ztC6(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬੁ"))
tgjCPKlcGephBE8ka = A73K6zLXIgFROeCHJQi0Pbos.path.join(HnMP40juJfr6L1mexbWBV,ebT9xRB63E(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩੂ"))
uZ7xiFaBvSrWG2mXjITp = int(Mrx2OeZV1LNjBsQ58Savi7.time())
BBwb2NzsHE = zToRkFxN3PemAqS60tD5LpB2VUdHg.Addon(id=f3pCnmFaVYx4zc1MNGBe5)
def p2gG9rDHAXb7lYPvcMTa(OG9Usa51Nk8D,trXfJN2hZ6joUOa=Yr0wo7FaSHx(u"ࠩࡂࠫ੃")):
	if u2NDjURZVHlmdc0(u"ࠪࡁࠬ੄") in OG9Usa51Nk8D:
		if trXfJN2hZ6joUOa in OG9Usa51Nk8D: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,jeqNpSYCnQ5tu0gbkZloOH = OG9Usa51Nk8D.split(trXfJN2hZ6joUOa,pOIe6U1vWYC7Gh2udFBRgT(u"࠷క"))
		else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,jeqNpSYCnQ5tu0gbkZloOH = b098bsyjUud(u"ࠫࠬ੅"),OG9Usa51Nk8D
		jeqNpSYCnQ5tu0gbkZloOH = jeqNpSYCnQ5tu0gbkZloOH.split(G5TxeI0ND4ztC6(u"ࠬࠬࠧ੆"))
		Gv7mT0LhB9YoOVpANMr = {}
		for zgu7qm1sa0HEoKUNXABLWy6 in jeqNpSYCnQ5tu0gbkZloOH:
			oQmOMcBwDGK69ylqSN2z,cvzjdYsGOxH3R = zgu7qm1sa0HEoKUNXABLWy6.split(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࠽ࠨੇ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠱ఖ"))
			Gv7mT0LhB9YoOVpANMr[oQmOMcBwDGK69ylqSN2z] = cvzjdYsGOxH3R
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr = OG9Usa51Nk8D,{}
	return FrC9LhHZWIySdGwNsuzqt5Rf01TXO,Gv7mT0LhB9YoOVpANMr
def i35i6al7upCAreLFQ(OG9Usa51Nk8D):
	return _MtTwklrC9xivHsjXL7z(OG9Usa51Nk8D)
def NmPa38tGQK2x(nn0jridBsVkNXEpULcHwt5a):
	PP5yGWs3mwABM7qQTluhJgpRHN = {GVPK9Ziaho6U2ySLj(u"ࠧࡵࡻࡳࡩࠬੈ"):ebT9xRB63E(u"ࠨࠩ੉"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡰࡳࡩ࡫ࠧ੊"):uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠫੋ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࡺࡸ࡬ࠨੌ"):KylMx0kfTOrG(u"੍ࠬ࠭"),A6Iyo7eXrq2RtMmDxWj(u"࠭ࡴࡦࡺࡷࠫ੎"):xmTX9Aeidq8cVhY(u"ࠧࠨ੏"),cg94WALw5orUhvtHSfNO(u"ࠨࡲࡤ࡫ࡪ࠭੐"):DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࠪੑ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡲࡦࡳࡥࠨ੒"):DItWNMaLOZ146CubYk8lfAwTy(u"ࠫࠬ੓"),VVtQk9vwe7(u"ࠬ࡯࡭ࡢࡩࡨࠫ੔"):uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠧ੕"),tvdQHb10PhNmuy6(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ੖"):G5TxeI0ND4ztC6(u"ࠨࠩ੗"),xmTX9Aeidq8cVhY(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫ੘"):KylMx0kfTOrG(u"ࠪࠫਖ਼")}
	if tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࡄ࠭ਗ਼") in nn0jridBsVkNXEpULcHwt5a: nn0jridBsVkNXEpULcHwt5a = nn0jridBsVkNXEpULcHwt5a.split(GVPK9Ziaho6U2ySLj(u"ࠬࡅࠧਜ਼"),G5TxeI0ND4ztC6(u"࠲గ"))[G5TxeI0ND4ztC6(u"࠲గ")]
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO,tzS7qi3Qk2XYKRBAZLCrE = p2gG9rDHAXb7lYPvcMTa(nn0jridBsVkNXEpULcHwt5a)
	aargs = dict(list(PP5yGWs3mwABM7qQTluhJgpRHN.items())+list(tzS7qi3Qk2XYKRBAZLCrE.items()))
	qIbjGvLzc6OPUtf8N1 = aargs[b098bsyjUud(u"࠭࡭ࡰࡦࡨࠫੜ")]
	Z9IXhMpLKqWlNjo4QvV = i35i6al7upCAreLFQ(aargs[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡶࡴ࡯ࠫ੝")])
	VyED9uN4HIvn2BeYapP5qA = i35i6al7upCAreLFQ(aargs[vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡶࡨࡼࡹ࠭ਫ਼")])
	fhExSFOpLd78CeR1Tg4MDX3vAkP = i35i6al7upCAreLFQ(aargs[Vt4ELHXZP6(u"ࠩࡳࡥ࡬࡫ࠧ੟")])
	AcrwhZR8O2xe7IgvX = i35i6al7upCAreLFQ(aargs[VVtQk9vwe7(u"ࠪࡸࡾࡶࡥࠨ੠")])
	HimZ5nCXgVaA08yRFbN = i35i6al7upCAreLFQ(aargs[VVtQk9vwe7(u"ࠫࡳࡧ࡭ࡦࠩ੡")])
	IGXnaCgFJuqd1DTStiAeRW952wb = i35i6al7upCAreLFQ(aargs[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬ࡯࡭ࡢࡩࡨࠫ੢")])
	zNWVQ9bHYBRAKnre = aargs[YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ੣")]
	MTarxBIHLhKJjpqO9UPzfA5dZ = i35i6al7upCAreLFQ(aargs[Wbwj0o5gsXQ8F2f(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ੤")])
	if MTarxBIHLhKJjpqO9UPzfA5dZ: MTarxBIHLhKJjpqO9UPzfA5dZ = eval(MTarxBIHLhKJjpqO9UPzfA5dZ)
	else: MTarxBIHLhKJjpqO9UPzfA5dZ = {}
	if not qIbjGvLzc6OPUtf8N1: AcrwhZR8O2xe7IgvX = vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ੥") ; qIbjGvLzc6OPUtf8N1 = G5TxeI0ND4ztC6(u"ࠩ࠵࠺࠵࠭੦")
	return AcrwhZR8O2xe7IgvX,HimZ5nCXgVaA08yRFbN,Z9IXhMpLKqWlNjo4QvV,qIbjGvLzc6OPUtf8N1,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,VyED9uN4HIvn2BeYapP5qA,zNWVQ9bHYBRAKnre,MTarxBIHLhKJjpqO9UPzfA5dZ
def ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ):
	v7vTyDZMA1VlY40X2fjQPmUKkn = uea9JUBOMcEfh8CN0v6b._getframe(C0CbfZuXJM(u"࠳ఘ")).f_code.co_name
	if not FpjtBKrnu5SdfyOvEPIQ or not v7vTyDZMA1VlY40X2fjQPmUKkn or v7vTyDZMA1VlY40X2fjQPmUKkn==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ੧"):
		return CC4UDLW6brf(u"ࠫࡠࠦࠧ੨")+DDrdYk7wegNmiC.upper()+vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠳ࠧ੩")+K0dHTfq6P73sD8lWLZpoh+u2NDjURZVHlmdc0(u"࠭࠭ࠨ੪")+str(WWSLAyQdhUXl3ovb)+tvdQHb10PhNmuy6(u"ࠧࠡ࡟ࠪ੫")
	return b46fBrugtPDSYspzMQIx(u"ࠨ࠰ࠣࠤࠬ੬")+v7vTyDZMA1VlY40X2fjQPmUKkn
def b6kj4LJ5tzTeOMQi(QpRACxyTrgoa,hiDXjZaexOEKBd3U):
	if wIqFesTOvYnu5S2dWfpBVC: hiDXjZaexOEKBd3U = hiDXjZaexOEKBd3U.decode(CC4UDLW6brf(u"ࠩࡸࡸ࡫࠾ࠧ੭")).encode(tjoHEAGv2XkrMBsVfCyp5U(u"ࠪࡹࡹ࡬࠸ࠨ੮"))
	CHx4VGlndUT1k0FLDWjmMaA8c = wjuG4C2v6medtRU7
	tBFLs10gh4MQyeXa5xSnqlPWdE = [b098bsyjUud(u"ࠫࠬ੯"),Yr0wo7FaSHx(u"ࠬ࠭ੰ")]
	if QpRACxyTrgoa: hiDXjZaexOEKBd3U = hiDXjZaexOEKBd3U.replace(Wbwj0o5gsXQ8F2f(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩੱ"),Yr0wo7FaSHx(u"ࠧࠨੲ")).replace(xmTX9Aeidq8cVhY(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫੳ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࠪੴ")).replace(WfgnOq9Fd4lhMSQpK5(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬੵ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬ੶"))
	else: QpRACxyTrgoa = ebT9xRB63E(u"ࠬࡔࡏࡕࡋࡆࡉࠬ੷")
	U6CyL8fbgJZoSD,trXfJN2hZ6joUOa,ooHKBXGgZDjaLivsYmONu = CC4UDLW6brf(u"࠭ࠠࠡࠢࠣࠫ੸"),WfgnOq9Fd4lhMSQpK5(u"ࠧࠡࠢࠣࠫ੹"),Yr0wo7FaSHx(u"ࠨࠩ੺")
	if oh1JUWa3LdnqTpz5(u"ࠩࡈࡖࡗࡕࡒࠨ੻") in QpRACxyTrgoa: CHx4VGlndUT1k0FLDWjmMaA8c = Wj3qSagkcweAb2prRiDyM0HK7Guo.LOGERROR
	if QpRACxyTrgoa==b098bsyjUud(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ੼"):
		hiDXjZaexOEKBd3U = hiDXjZaexOEKBd3U+trXfJN2hZ6joUOa
		tBFLs10gh4MQyeXa5xSnqlPWdE = hiDXjZaexOEKBd3U.split(trXfJN2hZ6joUOa)
		ooHKBXGgZDjaLivsYmONu = U6CyL8fbgJZoSD
	elif QpRACxyTrgoa==uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ੽"):
		hiDXjZaexOEKBd3U = hiDXjZaexOEKBd3U.replace(CC4UDLW6brf(u"ࠬ࠴ࠧ੾")+trXfJN2hZ6joUOa,pOIe6U1vWYC7Gh2udFBRgT(u"࠭࠮ࠡࠢࠪ੿"))
		tBFLs10gh4MQyeXa5xSnqlPWdE = hiDXjZaexOEKBd3U.split(trXfJN2hZ6joUOa)
		tBFLs10gh4MQyeXa5xSnqlPWdE[A6Iyo7eXrq2RtMmDxWj(u"࠴చ")] = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠧ࠯ࠩ઀")+tBFLs10gh4MQyeXa5xSnqlPWdE[A6Iyo7eXrq2RtMmDxWj(u"࠴చ")][jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠴ఙ"):]
		ooHKBXGgZDjaLivsYmONu = U6CyL8fbgJZoSD+trXfJN2hZ6joUOa
	elif QpRACxyTrgoa in [Vt4ELHXZP6(u"ࠨࡐࡒࡘࡎࡉࡅࠨઁ"),xmTX9Aeidq8cVhY(u"ࠩࡈࡖࡗࡕࡒࠨં")]: tBFLs10gh4MQyeXa5xSnqlPWdE = hiDXjZaexOEKBd3U.split(U6CyL8fbgJZoSD)
	ooHKBXGgZDjaLivsYmONu += tvdQHb10PhNmuy6(u"࠻ఛ")*U6CyL8fbgJZoSD
	dVSEvgt4TCF8 = tvdQHb10PhNmuy6(u"࠹జ")*U6CyL8fbgJZoSD
	if WWSLAyQdhUXl3ovb>tvdQHb10PhNmuy6(u"࠲࠹࠱࠽࠾ఞ"): ooHKBXGgZDjaLivsYmONu += trSQHvP4aqBWFKxN5bZgXCu(u"࠱࠲ఝ")*cg94WALw5orUhvtHSfNO(u"ࠪࠤࠬઃ")
	OOfrmIbJ9nFAQPYt13sihdT = tBFLs10gh4MQyeXa5xSnqlPWdE[KylMx0kfTOrG(u"࠲ట")]
	for Ik5bst9OBynwor01jzgCKP in tBFLs10gh4MQyeXa5xSnqlPWdE[oh1JUWa3LdnqTpz5(u"࠴ఠ"):]:
		if Vt4ELHXZP6(u"ࠫࡡࡴࠧ઄") in Ik5bst9OBynwor01jzgCKP: Ik5bst9OBynwor01jzgCKP = Ik5bst9OBynwor01jzgCKP.replace(G5TxeI0ND4ztC6(u"ࠬࡢ࡮ࠨઅ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࡜࡯ࠩઆ")+U6CyL8fbgJZoSD+U6CyL8fbgJZoSD)
		dVSEvgt4TCF8 += U6CyL8fbgJZoSD
		OOfrmIbJ9nFAQPYt13sihdT += A6Iyo7eXrq2RtMmDxWj(u"ࠧ࡝ࡴࠪઇ")+ooHKBXGgZDjaLivsYmONu+dVSEvgt4TCF8+Ik5bst9OBynwor01jzgCKP
	OOfrmIbJ9nFAQPYt13sihdT += uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠢࡢࠫઈ")
	if vlW6K1g8Xo35mPYbyO2GS(u"ࠩࠨࠫઉ") in OOfrmIbJ9nFAQPYt13sihdT: OOfrmIbJ9nFAQPYt13sihdT = i35i6al7upCAreLFQ(OOfrmIbJ9nFAQPYt13sihdT)
	Wj3qSagkcweAb2prRiDyM0HK7Guo.log(OOfrmIbJ9nFAQPYt13sihdT,level=CHx4VGlndUT1k0FLDWjmMaA8c)
	return
def vIhJlmEwFisoAOcepqVNLTDQrY(Gu59Qt0lxV):
	LxomZnH9Ky = gxoYzqsnPQ.connect(Gu59Qt0lxV)
	ooRPprGBD89QXusn = LxomZnH9Ky.cursor()
	ooRPprGBD89QXusn.execute(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩઊ"))
	ooRPprGBD89QXusn.execute(trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡫ࡵࡲࡦ࡫ࡪࡲࡤࡱࡥࡺࡵࡀࡲࡴࡁࠧઋ"))
	ooRPprGBD89QXusn.execute(G5TxeI0ND4ztC6(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧઌ"))
	ooRPprGBD89QXusn.execute(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪઍ"))
	ooRPprGBD89QXusn.execute(GVPK9Ziaho6U2ySLj(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡵࡧࡰࡴࡤࡹࡴࡰࡴࡨࡁࡒࡋࡍࡐࡔ࡜࠿ࠬ઎"))
	ooRPprGBD89QXusn.execute(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈ࠾ࠫએ"))
	LxomZnH9Ky.text_factory = str
	return LxomZnH9Ky,ooRPprGBD89QXusn
def egFp6ox1ZirEC7hMQI0PLHwnmvNkK(Gu59Qt0lxV,SaotLMu5qvCdUi4,a4x6tmkGzWBh7rp9we5nF=None):
	try: LxomZnH9Ky,ooRPprGBD89QXusn = vIhJlmEwFisoAOcepqVNLTDQrY(Gu59Qt0lxV)
	except: return
	if a4x6tmkGzWBh7rp9we5nF==None: ooRPprGBD89QXusn.execute(A6Iyo7eXrq2RtMmDxWj(u"ࠩࡇࡖࡔࡖࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫઐ")+SaotLMu5qvCdUi4+b098bsyjUud(u"ࠪࠦࠥࡁࠧઑ"))
	else:
		vvAdDNMUyzBOeKtsYHgC05kEucWV = (str(a4x6tmkGzWBh7rp9we5nF),)
		try:
			if Vt4ELHXZP6(u"ࠫࠪ࠭઒") in a4x6tmkGzWBh7rp9we5nF: ooRPprGBD89QXusn.execute(b098bsyjUud(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬઓ")+SaotLMu5qvCdUi4+b46fBrugtPDSYspzMQIx(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࡭࡫࡮ࡩࠥࡅࠠ࠼ࠩઔ"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
			else: ooRPprGBD89QXusn.execute(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧક")+SaotLMu5qvCdUi4+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨખ"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
		except: pass
	LxomZnH9Ky.commit()
	LxomZnH9Ky.close()
	return
class cvUMBRVbku6wPadJWA(): pass
class hzJoxHQE89aNMR7drb0VntI3CKeDFm(cvUMBRVbku6wPadJWA):
	def __init__(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.url = tvdQHb10PhNmuy6(u"ࠩࠪગ")
		vUNh2O7nLwdF1eTkEfCYSm8t.code = -vdHRKkIgTp56Je1OuNo(u"࠽࠾డ")
		vUNh2O7nLwdF1eTkEfCYSm8t.reason = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠫઘ")
		vUNh2O7nLwdF1eTkEfCYSm8t.content = CC4UDLW6brf(u"ࠫࠬઙ")
		vUNh2O7nLwdF1eTkEfCYSm8t.headers = {}
		vUNh2O7nLwdF1eTkEfCYSm8t.cookies = {}
		vUNh2O7nLwdF1eTkEfCYSm8t.succeeded = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࡌࡡ࡭ࡵࡨ౩")
def xnprKHAXUQ(ajLz9PfYbTigyorvZhW4IOFn):
	if ajLz9PfYbTigyorvZhW4IOFn==xmTX9Aeidq8cVhY(u"ࠬࡪࡩࡤࡶࠪચ"): kOfDHhMnuAxQoBpWTeL = {}
	elif ajLz9PfYbTigyorvZhW4IOFn==vlW6K1g8Xo35mPYbyO2GS(u"࠭࡬ࡪࡵࡷࠫછ"): kOfDHhMnuAxQoBpWTeL = []
	elif ajLz9PfYbTigyorvZhW4IOFn==vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡴࡶࡵࠫજ"): kOfDHhMnuAxQoBpWTeL = KylMx0kfTOrG(u"ࠨࠩઝ")
	elif ajLz9PfYbTigyorvZhW4IOFn==tvdQHb10PhNmuy6(u"ࠩ࡬ࡲࡹ࠭ઞ"): kOfDHhMnuAxQoBpWTeL = CC4UDLW6brf(u"࠵ఢ")
	elif ajLz9PfYbTigyorvZhW4IOFn==vdHRKkIgTp56Je1OuNo(u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬટ"): kOfDHhMnuAxQoBpWTeL = hzJoxHQE89aNMR7drb0VntI3CKeDFm()
	elif not ajLz9PfYbTigyorvZhW4IOFn: kOfDHhMnuAxQoBpWTeL = None
	else: kOfDHhMnuAxQoBpWTeL = None
	return kOfDHhMnuAxQoBpWTeL
def HRnwFcAJIxaoXEbYQ(KZSfbvMg5a0ucoT8j4BRn):
	from hashlib import md5 as rAtkoeldGFvTLWOn7
	kZ6X5j1OSCPqbciyIl = BBwb2NzsHE.getSetting(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠭ઠ"))
	esG1X6mVirtzandCLIwl = sPgi90KAz7JCOojl(vlW6K1g8Xo35mPYbyO2GS(u"࠹࠲ణ")).splitlines()
	PPzqS9ocOhDViQB2tfvn6dJHGl = VVtQk9vwe7(u"࠰త")
	for csxly95vMwY0 in [uZ7xiFaBvSrWG2mXjITp,uZ7xiFaBvSrWG2mXjITp-mjBa0HgvKnI4oWRd]:
		pVArzC3yoEdUJDxItnTMSv8blN1 = str(csxly95vMwY0*trSQHvP4aqBWFKxN5bZgXCu(u"࠴࠴࠵࠶࠰࠱࠰࠳ధ")/VVtQk9vwe7(u"࠶࠶࠶࠵࠶࠰ద"))[xmTX9Aeidq8cVhY(u"࠱థ"):mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠸న")]
		if pVArzC3yoEdUJDxItnTMSv8blN1!=PPzqS9ocOhDViQB2tfvn6dJHGl:
			for AhLl5jt7I8sbETD0adwOefzWq in esG1X6mVirtzandCLIwl:
				vv1id57LuqDnOZS2TzNMVCseKjYPbg = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬ࡞࠱࠺ࠩડ")+KZSfbvMg5a0ucoT8j4BRn+vlW6K1g8Xo35mPYbyO2GS(u"࠭࠱࠹࠿ࠪઢ")+AhLl5jt7I8sbETD0adwOefzWq[-Wbwj0o5gsXQ8F2f(u"࠷࠺఩"):]+K0dHTfq6P73sD8lWLZpoh+pVArzC3yoEdUJDxItnTMSv8blN1
				vv1id57LuqDnOZS2TzNMVCseKjYPbg = rAtkoeldGFvTLWOn7(vv1id57LuqDnOZS2TzNMVCseKjYPbg.encode(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧࡶࡶࡩ࠼ࠬણ"))).hexdigest()[:Wbwj0o5gsXQ8F2f(u"࠹࠲ప")]
				if vv1id57LuqDnOZS2TzNMVCseKjYPbg in kZ6X5j1OSCPqbciyIl: return vdHRKkIgTp56Je1OuNo(u"ࡔࡳࡷࡨ౪")
			PPzqS9ocOhDViQB2tfvn6dJHGl = pVArzC3yoEdUJDxItnTMSv8blN1
	return Wbwj0o5gsXQ8F2f(u"ࡇࡣ࡯ࡷࡪ౫")
def cLozpXkSg1qU3VthuFbNyQTns(Gu59Qt0lxV,DuUAOF9Yfv,SaotLMu5qvCdUi4,a4x6tmkGzWBh7rp9we5nF=None):
	kOfDHhMnuAxQoBpWTeL = xnprKHAXUQ(DuUAOF9Yfv)
	pD0N4f87P5daEltjisJTCZUHKe = BBwb2NzsHE.getSetting(G5TxeI0ND4ztC6(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧત"))
	if SaotLMu5qvCdUi4!=Yr0wo7FaSHx(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬથ") and Gu59Qt0lxV==tnQMXOP5mgZVI:
		if pD0N4f87P5daEltjisJTCZUHKe==vdHRKkIgTp56Je1OuNo(u"ࠪࡗ࡙ࡕࡐࠨદ"): return kOfDHhMnuAxQoBpWTeL
		y9sfZeW5tbQpkPHKxg7jDS = BBwb2NzsHE.getSetting(xmTX9Aeidq8cVhY(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨધ"))
		if y9sfZeW5tbQpkPHKxg7jDS==KylMx0kfTOrG(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨન"):
			egFp6ox1ZirEC7hMQI0PLHwnmvNkK(Gu59Qt0lxV,SaotLMu5qvCdUi4,a4x6tmkGzWBh7rp9we5nF)
			return kOfDHhMnuAxQoBpWTeL
	vOsg1GbPFycCirq = tjoHEAGv2XkrMBsVfCyp5U(u"࠰ఫ")
	if pD0N4f87P5daEltjisJTCZUHKe==b098bsyjUud(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ઩"): vOsg1GbPFycCirq = A1DMaRiPpTLJQvw6B7OdKbU439
	try: LxomZnH9Ky,ooRPprGBD89QXusn = vIhJlmEwFisoAOcepqVNLTDQrY(Gu59Qt0lxV)
	except: return kOfDHhMnuAxQoBpWTeL
	tyVk3cUnx4L = KylMx0kfTOrG(u"ࡖࡵࡹࡪ౬")
	try: ooRPprGBD89QXusn.execute(Vt4ELHXZP6(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࠫࠢࡉࡖࡔࡓࠠࠣࠩપ")+SaotLMu5qvCdUi4+GVPK9Ziaho6U2ySLj(u"ࠨࠤࠣࡐࡎࡓࡉࡕࠢ࠴ࠤࡀ࠭ફ"))
	except: tyVk3cUnx4L = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࡉࡥࡱࡹࡥ౭")
	if tyVk3cUnx4L:
		if vOsg1GbPFycCirq: ooRPprGBD89QXusn.execute(b46fBrugtPDSYspzMQIx(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩબ")+SaotLMu5qvCdUi4+G5TxeI0ND4ztC6(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬભ")+str(uZ7xiFaBvSrWG2mXjITp+vOsg1GbPFycCirq)+oh1JUWa3LdnqTpz5(u"ࠫࠥࡁࠧમ"))
		LxomZnH9Ky.commit()
		ooRPprGBD89QXusn.execute(cg94WALw5orUhvtHSfNO(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬય")+SaotLMu5qvCdUi4+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨર")+str(uZ7xiFaBvSrWG2mXjITp)+pOIe6U1vWYC7Gh2udFBRgT(u"ࠧࠡ࠽ࠪ઱"))
		LxomZnH9Ky.commit()
		if a4x6tmkGzWBh7rp9we5nF:
			vvAdDNMUyzBOeKtsYHgC05kEucWV = (str(a4x6tmkGzWBh7rp9we5nF),)
			ooRPprGBD89QXusn.execute(VVtQk9vwe7(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭લ")+SaotLMu5qvCdUi4+KylMx0kfTOrG(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩળ"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
			Z2ARJehHkjndvF = ooRPprGBD89QXusn.fetchall()
			if Z2ARJehHkjndvF:
				try:
					JJ23NOKSjik1hg8Ts7CXbevYzrQHU = rxfk1jENTUA5XvMbG8acWIeCQi9.decompress(Z2ARJehHkjndvF[jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠱బ")][jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠱బ")])
					kOfDHhMnuAxQoBpWTeL = agQL8CV9Rb1YOlqW6IG7v.loads(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
				except: pass
		else:
			ooRPprGBD89QXusn.execute(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ઴")+SaotLMu5qvCdUi4+oh1JUWa3LdnqTpz5(u"ࠫࠧࠦ࠻ࠨવ"))
			Z2ARJehHkjndvF = ooRPprGBD89QXusn.fetchall()
			if Z2ARJehHkjndvF:
				kOfDHhMnuAxQoBpWTeL,p8szFOP1UcJL0hrEwm9At = {},[]
				for xUzDJ4p7shM9BS,Gv7mT0LhB9YoOVpANMr in Z2ARJehHkjndvF:
					wfvQKiYRlFAtu1yco = rxfk1jENTUA5XvMbG8acWIeCQi9.decompress(Gv7mT0LhB9YoOVpANMr)
					Gv7mT0LhB9YoOVpANMr = agQL8CV9Rb1YOlqW6IG7v.loads(wfvQKiYRlFAtu1yco)
					kOfDHhMnuAxQoBpWTeL[xUzDJ4p7shM9BS] = Gv7mT0LhB9YoOVpANMr
					p8szFOP1UcJL0hrEwm9At.append(xUzDJ4p7shM9BS)
				if p8szFOP1UcJL0hrEwm9At:
					kOfDHhMnuAxQoBpWTeL[Vt4ELHXZP6(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭શ")] = p8szFOP1UcJL0hrEwm9At
					if DuUAOF9Yfv==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࡬ࡪࡵࡷࠫષ"): kOfDHhMnuAxQoBpWTeL = p8szFOP1UcJL0hrEwm9At
	LxomZnH9Ky.close()
	return kOfDHhMnuAxQoBpWTeL
class c8MHvAwb0E21g4mLeClpVPska(KnD1WCe34Z890xBitm5MsQaP6hVOH):
	def __init__(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.pVI85sQOiol0EHKh = HRnwFcAJIxaoXEbYQ(xmTX9Aeidq8cVhY(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨસ"))
		vUNh2O7nLwdF1eTkEfCYSm8t.s7BjiA8ZGJV3lPHozrTq2 = HRnwFcAJIxaoXEbYQ(u2NDjURZVHlmdc0(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩહ"))
		vUNh2O7nLwdF1eTkEfCYSm8t.zv3SfLemodVQRHpBOkDl7gts4 = HRnwFcAJIxaoXEbYQ(G5TxeI0ND4ztC6(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ઺"))
		vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ઻") if vUNh2O7nLwdF1eTkEfCYSm8t.pVI85sQOiol0EHKh else VVtQk9vwe7(u"઼ࠫࠬ")
	def cZBuPVsp46UxLSA8OG5TvwNI1q(vUNh2O7nLwdF1eTkEfCYSm8t,HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz): vUNh2O7nLwdF1eTkEfCYSm8t.HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz = HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz
	def onPlayBackStopped(vUNh2O7nLwdF1eTkEfCYSm8t): vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = CC4UDLW6brf(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬઽ")
	def onPlayBackError(vUNh2O7nLwdF1eTkEfCYSm8t): vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ા")
	def onPlayBackEnded(vUNh2O7nLwdF1eTkEfCYSm8t): vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = C0CbfZuXJM(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧિ")
	def onPlayBackStarted(vUNh2O7nLwdF1eTkEfCYSm8t):
		vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = WfgnOq9Fd4lhMSQpK5(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩી")
		HHF0QZfOduTGlES1eoNi = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=vUNh2O7nLwdF1eTkEfCYSm8t.CE1Yc0swhTOGdyoQpUn,args=())
		HHF0QZfOduTGlES1eoNi.start()
	def onAVStarted(vUNh2O7nLwdF1eTkEfCYSm8t):
		if vUNh2O7nLwdF1eTkEfCYSm8t.s7BjiA8ZGJV3lPHozrTq2: vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = cg94WALw5orUhvtHSfNO(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪુ")
		else: vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૂ")
	def CE1Yc0swhTOGdyoQpUn(vUNh2O7nLwdF1eTkEfCYSm8t):
		from wDd0v4uSOc import TiKk1hPsEgaBzU2N7Zpmfo,lfdUPv5WEQ,EYgQHCJOMW98Ps2wf
		EYgQHCJOMW98Ps2wf(G5TxeI0ND4ztC6(u"ࠫࡸࡺ࡯ࡱࠩૃ"))
		nHLmG2OWw0QxtZJj6DIBSNvMa = oh1JUWa3LdnqTpz5(u"࠲భ")
		while not eval(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨૄ"),{tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡸࡣ࡯ࡦࠫૅ"):Wj3qSagkcweAb2prRiDyM0HK7Guo}) and vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ==tvdQHb10PhNmuy6(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ૆"):
			Wj3qSagkcweAb2prRiDyM0HK7Guo.sleep(GVPK9Ziaho6U2ySLj(u"࠴࠴࠵࠶మ"))
			nHLmG2OWw0QxtZJj6DIBSNvMa += tvdQHb10PhNmuy6(u"࠵య")
			if nHLmG2OWw0QxtZJj6DIBSNvMa>tjoHEAGv2XkrMBsVfCyp5U(u"࠻࠶ర"): return
		if vUNh2O7nLwdF1eTkEfCYSm8t.pVI85sQOiol0EHKh: vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩે")
		elif vUNh2O7nLwdF1eTkEfCYSm8t.s7BjiA8ZGJV3lPHozrTq2: vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = WfgnOq9Fd4lhMSQpK5(u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪૈ")
		elif vUNh2O7nLwdF1eTkEfCYSm8t.zv3SfLemodVQRHpBOkDl7gts4:
			vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = Wbwj0o5gsXQ8F2f(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫૉ")
			Mj87oSOecy4DNUY0Hr5bf1BlAZFvx = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=TiKk1hPsEgaBzU2N7Zpmfo,args=(vUNh2O7nLwdF1eTkEfCYSm8t.HH1bGWFUaPJLAv2xEfOMCeqpuVN8Xz,))
			Mj87oSOecy4DNUY0Hr5bf1BlAZFvx.start()
			NBeiH0hXoPufKCkynQzE1RDqUgLTaO = g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=lfdUPv5WEQ,args=())
			NBeiH0hXoPufKCkynQzE1RDqUgLTaO.start()
		else: vUNh2O7nLwdF1eTkEfCYSm8t.lAaCZBGdwOUuxJ = oh1JUWa3LdnqTpz5(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ૊")
def vbrMe5TGnJAdlUy48XcVhz():
	yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt = trSQHvP4aqBWFKxN5bZgXCu(u"ࠬ࠭ો"),oh1JUWa3LdnqTpz5(u"࠭ࠧૌ")
	Uj5FaAR7TiphHPw1Qkb82o = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(C0CbfZuXJM(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ્࠭"))
	try:
		eakWDMuGiVLtv76Oh = open(A6Iyo7eXrq2RtMmDxWj(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ૎"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡵࡦࠬ૏")).read()
		if DQfHadYvTpy1UR: eakWDMuGiVLtv76Oh = eakWDMuGiVLtv76Oh.decode(GVPK9Ziaho6U2ySLj(u"ࠪࡹࡹ࡬࠸ࠨૐ"))
		uN80OB65zV1 = JJDtX1PZyIgN2T.findall(C0CbfZuXJM(u"ࠫࡘ࡫ࡲࡪࡣ࡯࠲࠯ࡅ࠺ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ૑"),eakWDMuGiVLtv76Oh,JJDtX1PZyIgN2T.IGNORECASE)
		if uN80OB65zV1: yyXSV4x6MLDdslIFJNG = uN80OB65zV1[tvdQHb10PhNmuy6(u"࠶ఱ")]
	except: pass
	try:
		import subprocess as T4LR589r62CmGhOoVzsANQFUdbfY
		Eus82DvKplRkWB1JN7FU = T4LR589r62CmGhOoVzsANQFUdbfY.Popen(pOIe6U1vWYC7Gh2udFBRgT(u"ࠬࡹࡴࡢࡶࠣ࠱ࡨ࡛ࠦࠢࠡࠧࠤࠧࠦ࠯ࡴࡶࡲࡶࡦ࡭ࡥ࠰ࡧࡰࡹࡱࡧࡴࡦࡦ࠲࠴ࠥࡁࠠࡴࡶࡤࡸࠥ࠳ࡣࠡࠤࠣࠩ࡜ࠦࠢࠡ࠱ࡹࡥࡷ࠵࡬ࡰࡩࠪ૒"),shell=ebT9xRB63E(u"ࡘࡷࡻࡥ౮"),stdin=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE,stdout=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE,stderr=T4LR589r62CmGhOoVzsANQFUdbfY.PIPE)
		AicuZQkwCYoFsja23JRf4bIr5VHM6 = Eus82DvKplRkWB1JN7FU.stdout.read()
		if AicuZQkwCYoFsja23JRf4bIr5VHM6:
			if DQfHadYvTpy1UR:
				AicuZQkwCYoFsja23JRf4bIr5VHM6 = AicuZQkwCYoFsja23JRf4bIr5VHM6.decode(oh1JUWa3LdnqTpz5(u"࠭ࡵࡵࡨ࠻ࠫ૓"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ૔"))
			QTj28xIgokX59t = JJDtX1PZyIgN2T.findall(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬ૕"),AicuZQkwCYoFsja23JRf4bIr5VHM6,JJDtX1PZyIgN2T.IGNORECASE)
			if QTj28xIgokX59t: Hm1YBxTjkuz2bodhGKt = min(QTj28xIgokX59t)
	except: pass
	return Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt
def sPgi90KAz7JCOojl(NDlGbe7IXhxwHySC6cpTi,cdCyOWn82p6ZETBPSzuH5rX=vJ2Q9gokKptI6YxrhDURClcFOz4(u"࡙ࡸࡵࡦ౯")):
	LE6Vz3wFdMqmanIxuG = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࡚ࡲࡶࡧ౰")
	if cdCyOWn82p6ZETBPSzuH5rX:
		O1chSwubif5mV = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠩ࡯࡭ࡸࡺࠧ૖"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭૗"),tvdQHb10PhNmuy6(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ૘"))
		if O1chSwubif5mV:
			esG1X6mVirtzandCLIwl,FxCQtUPvf6JaN7nDOLiBuIlh5,qqtQ0fFHDhs,fsuvxmzODE46MlnGP8iIdhp15 = O1chSwubif5mV
			LE6Vz3wFdMqmanIxuG = cLozpXkSg1qU3VthuFbNyQTns(tnQMXOP5mgZVI,KylMx0kfTOrG(u"ࠬࡲࡩࡴࡶࠪ૙"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૚"),Vt4ELHXZP6(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૛"))
			if LE6Vz3wFdMqmanIxuG: Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt = LE6Vz3wFdMqmanIxuG
			else: Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt = vbrMe5TGnJAdlUy48XcVhz()
			if (FxCQtUPvf6JaN7nDOLiBuIlh5,qqtQ0fFHDhs,fsuvxmzODE46MlnGP8iIdhp15)==(Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt): return WfgnOq9Fd4lhMSQpK5(u"ࠨ࡞ࡱࠫ૜").join(esG1X6mVirtzandCLIwl)
	if LE6Vz3wFdMqmanIxuG: Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt = vbrMe5TGnJAdlUy48XcVhz()
	global OWD3pQ1jXrhSf5vaMklEdGPUToR,WHT2ftCDxmj0XG
	OWD3pQ1jXrhSf5vaMklEdGPUToR,WHT2ftCDxmj0XG,ScPld4esU8N7qgrJXm6xjFOY5V = b46fBrugtPDSYspzMQIx(u"ࠩࠪ૝"),WfgnOq9Fd4lhMSQpK5(u"ࠪࠫ૞"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫࠬ૟")
	NDlGbe7IXhxwHySC6cpTi = NDlGbe7IXhxwHySC6cpTi//pOIe6U1vWYC7Gh2udFBRgT(u"࠲ల")
	g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=SSgG7z6aZ8isD9).start()
	g6OFXePvfKW0SjLm4G5uBrQnYRIwC.Thread(target=SzXVKA5WpI7Z).start()
	for uvTwHSmjyW6Vr0192IZ in range(C0CbfZuXJM(u"࠲࠲ళ")):
		Mrx2OeZV1LNjBsQ58Savi7.sleep(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠲࠱࠹ఴ"))
		if not ScPld4esU8N7qgrJXm6xjFOY5V:
			try:
				oo0BTDdSUvKtquY = Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(Wbwj0o5gsXQ8F2f(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪૠ"))
				if oo0BTDdSUvKtquY.count(cg94WALw5orUhvtHSfNO(u"࠭࠺ࠨૡ"))==Wbwj0o5gsXQ8F2f(u"࠹శ") and oo0BTDdSUvKtquY.count(oh1JUWa3LdnqTpz5(u"ࠧ࠱ࠩૢ"))<uEed4OSxm7hBq9Vvky6QjHwWC(u"࠼వ"):
					oo0BTDdSUvKtquY = oo0BTDdSUvKtquY.lower().replace(DItWNMaLOZ146CubYk8lfAwTy(u"ࠨ࠼ࠪૣ"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࠪ૤"))
					ScPld4esU8N7qgrJXm6xjFOY5V = str(int(oo0BTDdSUvKtquY,GVPK9Ziaho6U2ySLj(u"࠶࠼ష")))
			except: pass
		if OWD3pQ1jXrhSf5vaMklEdGPUToR and WHT2ftCDxmj0XG and ScPld4esU8N7qgrJXm6xjFOY5V: break
	xjyW4t1b9APR8dShwL0G52TODEQ = [OWD3pQ1jXrhSf5vaMklEdGPUToR,WHT2ftCDxmj0XG,ScPld4esU8N7qgrJXm6xjFOY5V,u2NDjURZVHlmdc0(u"ࠪࠫ૥"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࠬ૦"),VVtQk9vwe7(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ૧")]
	if yyXSV4x6MLDdslIFJNG or Hm1YBxTjkuz2bodhGKt:
		from hashlib import md5 as rAtkoeldGFvTLWOn7
		mmXedVbUJrglQKhMN8kqw4IA = [(KylMx0kfTOrG(u"࠴హ"),yyXSV4x6MLDdslIFJNG),(oh1JUWa3LdnqTpz5(u"࠻స"),Hm1YBxTjkuz2bodhGKt)]
		for oQmOMcBwDGK69ylqSN2z,cvzjdYsGOxH3R in mmXedVbUJrglQKhMN8kqw4IA:
			cvzjdYsGOxH3R = cvzjdYsGOxH3R.strip(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭࠰ࠨ૨"))
			if cvzjdYsGOxH3R:
				if DQfHadYvTpy1UR: cvzjdYsGOxH3R = cvzjdYsGOxH3R.encode(xmTX9Aeidq8cVhY(u"ࠧࡶࡶࡩ࠼ࠬ૩"))
				cvzjdYsGOxH3R = str(int(rAtkoeldGFvTLWOn7(cvzjdYsGOxH3R).hexdigest(),tvdQHb10PhNmuy6(u"࠴࠸఺")))
				DS9Ejuz0y6mtnIa = [int(cvzjdYsGOxH3R[O8tMxjovzmnyF340GANuUKZ7ps:O8tMxjovzmnyF340GANuUKZ7ps+b46fBrugtPDSYspzMQIx(u"࠴࠹఼")]) for O8tMxjovzmnyF340GANuUKZ7ps in range(len(cvzjdYsGOxH3R)) if O8tMxjovzmnyF340GANuUKZ7ps%b46fBrugtPDSYspzMQIx(u"࠴࠹఼")==WfgnOq9Fd4lhMSQpK5(u"࠲఻")]
				xjyW4t1b9APR8dShwL0G52TODEQ[oQmOMcBwDGK69ylqSN2z-ebT9xRB63E(u"࠵ఽ")] = str(sum(DS9Ejuz0y6mtnIa))
	esG1X6mVirtzandCLIwl,UTPgQfG5X8aydrsOFweEKqHDbciN = [],b098bsyjUud(u"ࡆࡢ࡮ࡶࡩ౱")
	for WX2e5R1rwaLMAKhlkcmtv8 in range(len(xjyW4t1b9APR8dShwL0G52TODEQ)):
		DS9Ejuz0y6mtnIa = xjyW4t1b9APR8dShwL0G52TODEQ[WX2e5R1rwaLMAKhlkcmtv8]
		if not DS9Ejuz0y6mtnIa: continue
		if UTPgQfG5X8aydrsOFweEKqHDbciN and DS9Ejuz0y6mtnIa==xjyW4t1b9APR8dShwL0G52TODEQ[-WfgnOq9Fd4lhMSQpK5(u"࠶ా")]: continue
		UTPgQfG5X8aydrsOFweEKqHDbciN = CC4UDLW6brf(u"ࡕࡴࡸࡩ౲")
		DS9Ejuz0y6mtnIa = G5TxeI0ND4ztC6(u"ࠨ࠲ࠪ૪")*NDlGbe7IXhxwHySC6cpTi+DS9Ejuz0y6mtnIa
		DS9Ejuz0y6mtnIa = DS9Ejuz0y6mtnIa[-NDlGbe7IXhxwHySC6cpTi:]
		n5GES1UMs8YOdAKQhuHwqlBTvrIZ,JyFwqUrP9x3EHLNeK8YsWaibTklm = tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࠪ૫"),DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࠫ૬")
		mcJboYk86CH4Qj0ZrRwNLa = str(int(vlW6K1g8Xo35mPYbyO2GS(u"ࠫ࠾࠭૭")*(NDlGbe7IXhxwHySC6cpTi+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠷ి")))-int(DS9Ejuz0y6mtnIa))[-NDlGbe7IXhxwHySC6cpTi:]
		for dGOnHaNWlA2DbyfgLRJi in list(range(tjoHEAGv2XkrMBsVfCyp5U(u"࠰ీ"),NDlGbe7IXhxwHySC6cpTi,b46fBrugtPDSYspzMQIx(u"࠵ు"))):
			n5GES1UMs8YOdAKQhuHwqlBTvrIZ += mcJboYk86CH4Qj0ZrRwNLa[dGOnHaNWlA2DbyfgLRJi:dGOnHaNWlA2DbyfgLRJi+A6Iyo7eXrq2RtMmDxWj(u"࠶ూ")]+NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠳ࠧ૮")
			JyFwqUrP9x3EHLNeK8YsWaibTklm += str(sum(map(int,DS9Ejuz0y6mtnIa[dGOnHaNWlA2DbyfgLRJi:dGOnHaNWlA2DbyfgLRJi+DItWNMaLOZ146CubYk8lfAwTy(u"࠸ౄ")]))%A6Iyo7eXrq2RtMmDxWj(u"࠴࠴ృ"))
		AhLl5jt7I8sbETD0adwOefzWq = str(WX2e5R1rwaLMAKhlkcmtv8)+n5GES1UMs8YOdAKQhuHwqlBTvrIZ+JyFwqUrP9x3EHLNeK8YsWaibTklm
		esG1X6mVirtzandCLIwl.append(AhLl5jt7I8sbETD0adwOefzWq)
	pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,cg94WALw5orUhvtHSfNO(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ૯"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭૰"),[Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt],DkRgFyVIBM85OA)
	pRxmMktYgHCjWXf182(tnQMXOP5mgZVI,u2NDjURZVHlmdc0(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ૱"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ૲"),[esG1X6mVirtzandCLIwl,Uj5FaAR7TiphHPw1Qkb82o,yyXSV4x6MLDdslIFJNG,Hm1YBxTjkuz2bodhGKt],UHnG2wYuIQWKN38B4)
	return b098bsyjUud(u"ࠪࡠࡳ࠭૳").join(esG1X6mVirtzandCLIwl)
def gAcRrfHSDhJUKqPXF(ajLz9PfYbTigyorvZhW4IOFn,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV,DDWGZztREldKorePp6whj3):
	JZP07kjvbV = str(QOZAYj8g6yaqhl)[hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠵౅"):GVPK9Ziaho6U2ySLj(u"࠸࠵࠱ె")].replace(cg94WALw5orUhvtHSfNO(u"ࠫࡡࡴࠧ૴"),vdHRKkIgTp56Je1OuNo(u"ࠬࡢ࡜࡯ࠩ૵")).replace(C0CbfZuXJM(u"࠭࡜ࡳࠩ૶"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧ࡝࡞ࡵࠫ૷")).replace(CC4UDLW6brf(u"ࠨࠢࠣࠤࠥ࠭૸"),VVtQk9vwe7(u"ࠩࠣࠫૹ")).replace(A6Iyo7eXrq2RtMmDxWj(u"ࠪࠤࠥࠦࠧૺ"),C0CbfZuXJM(u"ࠫࠥ࠭ૻ"))
	if len(str(QOZAYj8g6yaqhl))>b46fBrugtPDSYspzMQIx(u"࠲࠶࠲ే"): JZP07kjvbV = JZP07kjvbV+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࠦ࠮࠯࠰ࠪૼ")
	Gv7mT0LhB9YoOVpANMr = str(kOfDHhMnuAxQoBpWTeL)[xmTX9Aeidq8cVhY(u"࠱ై"):vlW6K1g8Xo35mPYbyO2GS(u"࠴࠸࠴౉")].replace(A6Iyo7eXrq2RtMmDxWj(u"࠭࡜࡯ࠩ૽"),WfgnOq9Fd4lhMSQpK5(u"ࠧ࡝࡞ࡱࠫ૾")).replace(KylMx0kfTOrG(u"ࠨ࡞ࡵࠫ૿"),u2NDjURZVHlmdc0(u"ࠩ࡟ࡠࡷ࠭଀")).replace(A6Iyo7eXrq2RtMmDxWj(u"ࠪࠤࠥࠦࠠࠨଁ"),vdHRKkIgTp56Je1OuNo(u"ࠫࠥ࠭ଂ")).replace(GVPK9Ziaho6U2ySLj(u"ࠬࠦࠠࠡࠩଃ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠠࠨ଄"))
	if len(str(kOfDHhMnuAxQoBpWTeL))>KylMx0kfTOrG(u"࠵࠹࠵ొ"): Gv7mT0LhB9YoOVpANMr = Gv7mT0LhB9YoOVpANMr+A6Iyo7eXrq2RtMmDxWj(u"ࠧࠡ࠰࠱࠲ࠬଅ")
	b6kj4LJ5tzTeOMQi(KylMx0kfTOrG(u"ࠨࡐࡒࡘࡎࡉࡅࠨଆ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࠧଇ")+ajLz9PfYbTigyorvZhW4IOFn+xmTX9Aeidq8cVhY(u"ࠪࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ଈ")+OG9Usa51Nk8D+pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ଉ")+dbBRqLP6WeEV+KylMx0kfTOrG(u"ࠬࠦ࡝ࠡࠢࠣࡑࡪࡺࡨࡰࡦ࠽ࠤࡠࠦࠧଊ")+DDWGZztREldKorePp6whj3+pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿࡛ࠦࠡࠩଋ")+str(JZP07kjvbV)+CC4UDLW6brf(u"ࠧࠡ࡟ࠣࠤࠥࡊࡡࡵࡣ࠽ࠤࡠࠦࠧଌ")+Gv7mT0LhB9YoOVpANMr+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࠢࡠࠫ଍"))
	return
def SSgG7z6aZ8isD9():
	global OWD3pQ1jXrhSf5vaMklEdGPUToR
	import getmac82 as JjOingaxus9NFm48LroIMfZvWph5
	try:
		LGnB2lhF0a = JjOingaxus9NFm48LroIMfZvWph5.get_mac_address()
		if LGnB2lhF0a.count(oh1JUWa3LdnqTpz5(u"ࠩ࠽ࠫ଎"))==uEed4OSxm7hBq9Vvky6QjHwWC(u"࠺ౌ") and LGnB2lhF0a.count(GVPK9Ziaho6U2ySLj(u"ࠪ࠴ࠬଏ"))<jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠽ో"):
			LGnB2lhF0a = LGnB2lhF0a.lower().replace(G5TxeI0ND4ztC6(u"ࠫ࠿࠭ଐ"),Vt4ELHXZP6(u"ࠬ࠭଑"))
			OWD3pQ1jXrhSf5vaMklEdGPUToR = str(int(LGnB2lhF0a,WfgnOq9Fd4lhMSQpK5(u"࠷࠶్")))
	except: pass
	return
def SzXVKA5WpI7Z():
	global WHT2ftCDxmj0XG
	import getmac94 as h5s8S3JT6O7PtQpiL4DjMamRY
	try:
		vdz4Iau1VCKe8bPR2EG06pgk = h5s8S3JT6O7PtQpiL4DjMamRY.get_mac_address()
		if vdz4Iau1VCKe8bPR2EG06pgk.count(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭࠺ࠨ଒"))==xmTX9Aeidq8cVhY(u"࠶౏") and vdz4Iau1VCKe8bPR2EG06pgk.count(Vt4ELHXZP6(u"ࠧ࠱ࠩଓ"))<xmTX9Aeidq8cVhY(u"࠹౎"):
			vdz4Iau1VCKe8bPR2EG06pgk = vdz4Iau1VCKe8bPR2EG06pgk.lower().replace(ebT9xRB63E(u"ࠨ࠼ࠪଔ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࠪକ"))
			WHT2ftCDxmj0XG = str(int(vdz4Iau1VCKe8bPR2EG06pgk,GVPK9Ziaho6U2ySLj(u"࠳࠹౐")))
	except: pass
	return
def D9562M4WoCRwdh7(DDWGZztREldKorePp6whj3,OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL=C0CbfZuXJM(u"ࠪࠫଖ"),QOZAYj8g6yaqhl=ebT9xRB63E(u"ࠫࠬଗ"),dbBRqLP6WeEV=hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬ࠭ଘ")):
	gAcRrfHSDhJUKqPXF(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩଙ"),OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,dbBRqLP6WeEV,DDWGZztREldKorePp6whj3)
	if DQfHadYvTpy1UR: import urllib.request as tHFnOlXaxsTqcPi8S5zko
	else: import urllib2 as tHFnOlXaxsTqcPi8S5zko
	if not QOZAYj8g6yaqhl: QOZAYj8g6yaqhl = {uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଚ"):A6Iyo7eXrq2RtMmDxWj(u"ࠨࠩଛ")}
	if not kOfDHhMnuAxQoBpWTeL: kOfDHhMnuAxQoBpWTeL = {}
	if DDWGZztREldKorePp6whj3==A6Iyo7eXrq2RtMmDxWj(u"ࠩࡊࡉ࡙࠭ଜ"):
		OG9Usa51Nk8D = OG9Usa51Nk8D+vdHRKkIgTp56Je1OuNo(u"ࠪࡃࠬଝ")+lfM8WO96En(kOfDHhMnuAxQoBpWTeL)
		kOfDHhMnuAxQoBpWTeL = None
	elif DDWGZztREldKorePp6whj3==jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡕࡕࡓࡕࠩଞ") and CC4UDLW6brf(u"ࠬࡰࡳࡰࡰࠪଟ") in str(QOZAYj8g6yaqhl):
		from json import dumps as V47MU09QYBNxTjHF
		kOfDHhMnuAxQoBpWTeL = V47MU09QYBNxTjHF(kOfDHhMnuAxQoBpWTeL)
		kOfDHhMnuAxQoBpWTeL = str(kOfDHhMnuAxQoBpWTeL).encode(ebT9xRB63E(u"࠭ࡵࡵࡨ࠻ࠫଠ"))
	elif DDWGZztREldKorePp6whj3==hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࡑࡑࡖࡘࠬଡ"):
		kOfDHhMnuAxQoBpWTeL = lfM8WO96En(kOfDHhMnuAxQoBpWTeL)
		kOfDHhMnuAxQoBpWTeL = kOfDHhMnuAxQoBpWTeL.encode(CC4UDLW6brf(u"ࠨࡷࡷࡪ࠽࠭ଢ"))
	try:
		aHtFnZ3NqOo8 = tHFnOlXaxsTqcPi8S5zko.Request(OG9Usa51Nk8D,headers=QOZAYj8g6yaqhl,data=kOfDHhMnuAxQoBpWTeL)
		QBDjIUdSiR = tHFnOlXaxsTqcPi8S5zko.urlopen(aHtFnZ3NqOo8)
		TMq6SKsGo5muadx = QBDjIUdSiR.read()
		jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = u2NDjURZVHlmdc0(u"࠵࠴࠵౑"),Wbwj0o5gsXQ8F2f(u"ࠩࡒࡏࠬଣ")
	except:
		TMq6SKsGo5muadx = GVPK9Ziaho6U2ySLj(u"ࠪࠫତ")
		jjKUzRlixEhe7vY3BO6TDs5pGZ,KPW9hQet1aZUu4H2b0lvSi7Rs = -mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠵౒"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫଥ")
	b6kj4LJ5tzTeOMQi(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡔࡏࡕࡋࡆࡉࠬଦ"),vlW6K1g8Xo35mPYbyO2GS(u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩଧ")+str(jjKUzRlixEhe7vY3BO6TDs5pGZ)+tvdQHb10PhNmuy6(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩନ")+KPW9hQet1aZUu4H2b0lvSi7Rs+Yr0wo7FaSHx(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ଩")+dbBRqLP6WeEV+cg94WALw5orUhvtHSfNO(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨପ")+OG9Usa51Nk8D+oh1JUWa3LdnqTpz5(u"ࠪࠤࡢ࠭ଫ"))
	if TMq6SKsGo5muadx and DQfHadYvTpy1UR: TMq6SKsGo5muadx = TMq6SKsGo5muadx.decode(KylMx0kfTOrG(u"ࠫࡺࡺࡦ࠹ࠩବ"))
	return TMq6SKsGo5muadx
def dPzeYJhmT9SHGO0ivLENku4rxl6Cc(RI0VS6BqWuL,Pe8fNydFa3I9wo61RMW47EHUOQSYDt=trSQHvP4aqBWFKxN5bZgXCu(u"ࠬ࠭ଭ")):
	pyoxhgIkWbduLfm81A7EiCvnFB = str(GpOkwndjsI27uM.randrange(Yr0wo7FaSHx(u"࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳౓"),DItWNMaLOZ146CubYk8lfAwTy(u"࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼౔")))
	QOZAYj8g6yaqhl = {b46fBrugtPDSYspzMQIx(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬମ"):tvdQHb10PhNmuy6(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪଯ")}
	BG9IR8jZyUHzPd = {	tvdQHb10PhNmuy6(u"ࠣࡷࡶࡩࡷࡥࡩࡥࠤର"):sPgi90KAz7JCOojl(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠴࠴ౖ")).splitlines()[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠲౗")][-C0CbfZuXJM(u"࠲࠵ౕ"):],
				vdHRKkIgTp56Je1OuNo(u"ࠤࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳࠨ଱"):str(WWSLAyQdhUXl3ovb),
				C0CbfZuXJM(u"ࠥࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠣଲ"):K0dHTfq6P73sD8lWLZpoh,
				Yr0wo7FaSHx(u"ࠦࡩ࡫ࡶࡪࡥࡨࡣ࡫ࡧ࡭ࡪ࡮ࡼࠦଳ"):K0dHTfq6P73sD8lWLZpoh,
				vlW6K1g8Xo35mPYbyO2GS(u"ࠧ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠤ଴"):RI0VS6BqWuL,
				u2NDjURZVHlmdc0(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣଵ"): K0dHTfq6P73sD8lWLZpoh,
				vdHRKkIgTp56Je1OuNo(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣଶ"):A6Iyo7eXrq2RtMmDxWj(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣଷ"),
				oh1JUWa3LdnqTpz5(u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧସ"):{cg94WALw5orUhvtHSfNO(u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢହ"):RI0VS6BqWuL},
				vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ଺"): {WfgnOq9Fd4lhMSQpK5(u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ଻"):RI0VS6BqWuL},
				xmTX9Aeidq8cVhY(u"ࠨࠤࡴ࡭࡬ࡴࡤࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹ࡟ࡴࡻࡱࡧ଼ࠧ"):pOIe6U1vWYC7Gh2udFBRgT(u"ࡈࡤࡰࡸ࡫౳"),
				uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠢࡪࡲࠥଽ"): vlW6K1g8Xo35mPYbyO2GS(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤା")
			}
	if not Pe8fNydFa3I9wo61RMW47EHUOQSYDt: NfWbHE8kpD = [BG9IR8jZyUHzPd]
	else:
		cZbqCPfBtRjrW06g = BG9IR8jZyUHzPd.copy()
		cZbqCPfBtRjrW06g[pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ି")] = Pe8fNydFa3I9wo61RMW47EHUOQSYDt
		cZbqCPfBtRjrW06g[VVtQk9vwe7(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ୀ")] = {Yr0wo7FaSHx(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୁ"):Pe8fNydFa3I9wo61RMW47EHUOQSYDt}
		cZbqCPfBtRjrW06g[xmTX9Aeidq8cVhY(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧୂ")] = {b098bsyjUud(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣୃ"):Pe8fNydFa3I9wo61RMW47EHUOQSYDt}
		NfWbHE8kpD = [BG9IR8jZyUHzPd,cZbqCPfBtRjrW06g]
	kOfDHhMnuAxQoBpWTeL = {Vt4ELHXZP6(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣୄ"):GVPK9Ziaho6U2ySLj(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭୅"),
			jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ୆"):pyoxhgIkWbduLfm81A7EiCvnFB,
			uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥେ"): NfWbHE8kpD
		}
	OG9Usa51Nk8D = uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠴࠱ࡥࡲࡶ࡬ࡪࡶࡸࡨࡪ࠴ࡣࡰ࡯࠲࠶࠴࡮ࡴࡵࡲࡤࡴ࡮࠭ୈ")
	TMq6SKsGo5muadx = D9562M4WoCRwdh7(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠬࡖࡏࡔࡖࠪ୉"),OG9Usa51Nk8D,kOfDHhMnuAxQoBpWTeL,QOZAYj8g6yaqhl,vlW6K1g8Xo35mPYbyO2GS(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ୊"))
	return TMq6SKsGo5muadx
def G8EwoDOyKShm1i0IHMfNYZlU7(DuUAOF9Yfv,JJ23NOKSjik1hg8Ts7CXbevYzrQHU):
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(ebT9xRB63E(u"ࠧ࡯ࡷ࡯ࡰࠬୋ"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡐࡲࡲࡪ࠭ୌ"))
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(VVtQk9vwe7(u"ࠩࡷࡶࡺ࡫୍ࠧ"),A6Iyo7eXrq2RtMmDxWj(u"ࠪࡘࡷࡻࡥࠨ୎"))
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(DItWNMaLOZ146CubYk8lfAwTy(u"ࠫ࡫ࡧ࡬ࡴࡧࠪ୏"),b098bsyjUud(u"ࠬࡌࡡ࡭ࡵࡨࠫ୐"))
	JJ23NOKSjik1hg8Ts7CXbevYzrQHU = JJ23NOKSjik1hg8Ts7CXbevYzrQHU.replace(Yr0wo7FaSHx(u"࠭࡜࠰ࠩ୑"),b46fBrugtPDSYspzMQIx(u"ࠧ࠰ࠩ୒"))
	try: wfvQKiYRlFAtu1yco = eval(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	except: wfvQKiYRlFAtu1yco = xnprKHAXUQ(DuUAOF9Yfv)
	return wfvQKiYRlFAtu1yco
def CxvecthowDqgba7mOslpXLPMBfVz():
	ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
	QF4KdRaN2q0 = JJDtX1PZyIgN2T.findall(KylMx0kfTOrG(u"ࠨ࡞ࡧࡠࡩࡀ࡜ࡥ࡞ࡧࠤࡡࡡ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠨ୓"),q9fpxUJbiKc6us4,JJDtX1PZyIgN2T.DOTALL)
	if QF4KdRaN2q0: q9fpxUJbiKc6us4 = q9fpxUJbiKc6us4.split(QF4KdRaN2q0[G5TxeI0ND4ztC6(u"࠴ౙ")],DItWNMaLOZ146CubYk8lfAwTy(u"࠴ౘ"))[DItWNMaLOZ146CubYk8lfAwTy(u"࠴ౘ")]
	ivc0RJCBlgr9wzqfbYLaFOEA = Mrx2OeZV1LNjBsQ58Savi7.strftime(u2NDjURZVHlmdc0(u"ࠩࡢࠩࡲ࠴ࠥࡥࡡࠨࡌ࠿ࠫࡍࡠࠩ୔"),Mrx2OeZV1LNjBsQ58Savi7.localtime(uZ7xiFaBvSrWG2mXjITp))
	q9fpxUJbiKc6us4 = q9fpxUJbiKc6us4+ivc0RJCBlgr9wzqfbYLaFOEA
	sXPuroaMIYnl = ajLz9PfYbTigyorvZhW4IOFn,q9fpxUJbiKc6us4,OG9Usa51Nk8D,rCBzYkXesGinqfjWdMJ0I6EuthRAg1,UCjpzQwrZyNIe3kg1ThDvi0nb8,vYpMA3CxgcyR4VZJh,JJ23NOKSjik1hg8Ts7CXbevYzrQHU,neEs3K9mgi7CJhaODRATXrqo,WFJYy6c9CKV4rdh27NjtILZ5HgRv
	if A73K6zLXIgFROeCHJQi0Pbos.path.exists(tgjCPKlcGephBE8ka):
		rxqXYiSVaLWp3e1yQncJ57 = open(tgjCPKlcGephBE8ka,GVPK9Ziaho6U2ySLj(u"ࠪࡶࡧ࠭୕")).read()
		if DQfHadYvTpy1UR: rxqXYiSVaLWp3e1yQncJ57 = rxqXYiSVaLWp3e1yQncJ57.decode(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫࡺࡺࡦ࠹ࠩୖ"))
		rxqXYiSVaLWp3e1yQncJ57 = G8EwoDOyKShm1i0IHMfNYZlU7(Wbwj0o5gsXQ8F2f(u"ࠬࡪࡩࡤࡶࠪୗ"),rxqXYiSVaLWp3e1yQncJ57)
	else: rxqXYiSVaLWp3e1yQncJ57 = {}
	SMDOwX1AKRdFoupI0Q4ei = {}
	for IuovF3JqsV1P04RdeXQhDtlxgA in list(rxqXYiSVaLWp3e1yQncJ57.keys()):
		if IuovF3JqsV1P04RdeXQhDtlxgA!=ajLz9PfYbTigyorvZhW4IOFn: SMDOwX1AKRdFoupI0Q4ei[IuovF3JqsV1P04RdeXQhDtlxgA] = rxqXYiSVaLWp3e1yQncJ57[IuovF3JqsV1P04RdeXQhDtlxgA]
		else:
			if q9fpxUJbiKc6us4 and q9fpxUJbiKc6us4!=jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࠮࠯ࠩ୘"):
				EA4Ca9NKWZD6Yl = rxqXYiSVaLWp3e1yQncJ57[IuovF3JqsV1P04RdeXQhDtlxgA]
				if sXPuroaMIYnl in EA4Ca9NKWZD6Yl:
					ZJfCEzd2DxAvbiYg = EA4Ca9NKWZD6Yl.index(sXPuroaMIYnl)
					del EA4Ca9NKWZD6Yl[ZJfCEzd2DxAvbiYg]
				xjTiJEd9gz2HlwDpIe3 = [sXPuroaMIYnl]+EA4Ca9NKWZD6Yl
				xjTiJEd9gz2HlwDpIe3 = xjTiJEd9gz2HlwDpIe3[:hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠺࠶ౚ")]
				SMDOwX1AKRdFoupI0Q4ei[IuovF3JqsV1P04RdeXQhDtlxgA] = xjTiJEd9gz2HlwDpIe3
			else: SMDOwX1AKRdFoupI0Q4ei[IuovF3JqsV1P04RdeXQhDtlxgA] = rxqXYiSVaLWp3e1yQncJ57[IuovF3JqsV1P04RdeXQhDtlxgA]
	if ajLz9PfYbTigyorvZhW4IOFn not in list(SMDOwX1AKRdFoupI0Q4ei.keys()): SMDOwX1AKRdFoupI0Q4ei[ajLz9PfYbTigyorvZhW4IOFn] = [sXPuroaMIYnl]
	SMDOwX1AKRdFoupI0Q4ei = str(SMDOwX1AKRdFoupI0Q4ei)
	if DQfHadYvTpy1UR: SMDOwX1AKRdFoupI0Q4ei = SMDOwX1AKRdFoupI0Q4ei.encode(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࡶࡶࡩ࠼ࠬ୙"))
	open(tgjCPKlcGephBE8ka,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡹࡥࠫ୚")).write(SMDOwX1AKRdFoupI0Q4ei)
	return
def pRxmMktYgHCjWXf182(Gu59Qt0lxV,SaotLMu5qvCdUi4,a4x6tmkGzWBh7rp9we5nF,kOfDHhMnuAxQoBpWTeL,M4LzXn0ZpdAf8E,wkuUOqbjBrJRmxfl8SgdiLY9CGEzQ=GVPK9Ziaho6U2ySLj(u"ࡉࡥࡱࡹࡥ౴")):
	pD0N4f87P5daEltjisJTCZUHKe = BBwb2NzsHE.getSetting(DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ୛"))
	if pD0N4f87P5daEltjisJTCZUHKe==b098bsyjUud(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫଡ଼") and M4LzXn0ZpdAf8E>A1DMaRiPpTLJQvw6B7OdKbU439: M4LzXn0ZpdAf8E = A1DMaRiPpTLJQvw6B7OdKbU439
	if wkuUOqbjBrJRmxfl8SgdiLY9CGEzQ:
		XXsM6FBxqztKRYyAlvD,VV8BiSNPTyX2rgQ4mHIf6xLk = [],[]
		for uvTwHSmjyW6Vr0192IZ in range(len(a4x6tmkGzWBh7rp9we5nF)):
			JJ23NOKSjik1hg8Ts7CXbevYzrQHU = agQL8CV9Rb1YOlqW6IG7v.dumps(kOfDHhMnuAxQoBpWTeL[uvTwHSmjyW6Vr0192IZ])
			G0MxZhJY2E = rxfk1jENTUA5XvMbG8acWIeCQi9.compress(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
			XXsM6FBxqztKRYyAlvD.append((a4x6tmkGzWBh7rp9we5nF[uvTwHSmjyW6Vr0192IZ],))
			VV8BiSNPTyX2rgQ4mHIf6xLk.append((M4LzXn0ZpdAf8E+uZ7xiFaBvSrWG2mXjITp,str(a4x6tmkGzWBh7rp9we5nF[uvTwHSmjyW6Vr0192IZ]),G0MxZhJY2E))
	else:
		JJ23NOKSjik1hg8Ts7CXbevYzrQHU = agQL8CV9Rb1YOlqW6IG7v.dumps(kOfDHhMnuAxQoBpWTeL)
		iAr0fUTO4xhWpoS5G2Yv7XP9qFg = rxfk1jENTUA5XvMbG8acWIeCQi9.compress(JJ23NOKSjik1hg8Ts7CXbevYzrQHU)
	try: LxomZnH9Ky,ooRPprGBD89QXusn = vIhJlmEwFisoAOcepqVNLTDQrY(Gu59Qt0lxV)
	except: return
	while xmTX9Aeidq8cVhY(u"ࡘࡷࡻࡥ౵"):
		try:
			ooRPprGBD89QXusn.execute(xmTX9Aeidq8cVhY(u"ࠫࡇࡋࡇࡊࡐࠣࡍࡒࡓࡅࡅࡋࡄࡘࡊࠦࡔࡓࡃࡑࡗࡆࡉࡔࡊࡑࡑࠤࡀ࠭ଢ଼"))
			break
		except: Mrx2OeZV1LNjBsQ58Savi7.sleep(cg94WALw5orUhvtHSfNO(u"࠶࠮࠶౛"))
	ooRPprGBD89QXusn.execute(A6Iyo7eXrq2RtMmDxWj(u"ࠬࡉࡒࡆࡃࡗࡉ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡏࡑࡗࠤࡊ࡞ࡉࡔࡖࡖࠤࠧ࠭୞")+SaotLMu5qvCdUi4+b098bsyjUud(u"࠭ࠢࠡࠪࡨࡼࡵ࡯ࡲࡺ࠮ࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠩࠡ࠽ࠪୟ"))
	if wkuUOqbjBrJRmxfl8SgdiLY9CGEzQ:
		ooRPprGBD89QXusn.executemany(C0CbfZuXJM(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨࠧୠ")+SaotLMu5qvCdUi4+Vt4ELHXZP6(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨୡ"),XXsM6FBxqztKRYyAlvD)
		ooRPprGBD89QXusn.executemany(uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩୢ")+SaotLMu5qvCdUi4+vlW6K1g8Xo35mPYbyO2GS(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨୣ"),VV8BiSNPTyX2rgQ4mHIf6xLk)
	else:
		if M4LzXn0ZpdAf8E:
			vvAdDNMUyzBOeKtsYHgC05kEucWV = (str(a4x6tmkGzWBh7rp9we5nF),)
			ooRPprGBD89QXusn.execute(KylMx0kfTOrG(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫ୤")+SaotLMu5qvCdUi4+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ୥"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
			vvAdDNMUyzBOeKtsYHgC05kEucWV = (M4LzXn0ZpdAf8E+uZ7xiFaBvSrWG2mXjITp,str(a4x6tmkGzWBh7rp9we5nF),iAr0fUTO4xhWpoS5G2Yv7XP9qFg)
			ooRPprGBD89QXusn.execute(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠧ࠭୦")+SaotLMu5qvCdUi4+CC4UDLW6brf(u"࡙ࠧࠣࠢࡅࡑ࡛ࡅࡔࠢࠫࡃ࠱ࡅࠬࡀࠫࠣ࠿ࠬ୧"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
		else:
			vvAdDNMUyzBOeKtsYHgC05kEucWV = (iAr0fUTO4xhWpoS5G2Yv7XP9qFg,str(a4x6tmkGzWBh7rp9we5nF))
			ooRPprGBD89QXusn.execute(trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࡗࡓࡈࡆ࡚ࡅࠡࠤࠪ୨")+SaotLMu5qvCdUi4+oh1JUWa3LdnqTpz5(u"ࠩࠥࠤࡘࡋࡔࠡࡦࡤࡸࡦࠦ࠽ࠡࡁ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨ୩"),vvAdDNMUyzBOeKtsYHgC05kEucWV)
	LxomZnH9Ky.commit()
	LxomZnH9Ky.close()
	return
def lfM8WO96En(kOfDHhMnuAxQoBpWTeL):
	if DQfHadYvTpy1UR: import urllib.parse as X305SlQTcb6dFPnVY9WprtAG7wZuyD
	else: import urllib as X305SlQTcb6dFPnVY9WprtAG7wZuyD
	BRxPgfzmdCZcFsUu46AajEnbSJl8q = X305SlQTcb6dFPnVY9WprtAG7wZuyD.urlencode(kOfDHhMnuAxQoBpWTeL)
	return BRxPgfzmdCZcFsUu46AajEnbSJl8q
lAaCZBGdwOUuxJ = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࠫ୪")
def XbzQHGJ0cBV(kHWT0XY2S6apruwxiB8FDl1,WK1Bf5cXpgUmOEl4L0Nd=A6Iyo7eXrq2RtMmDxWj(u"ࠫࠬ୫"),AcrwhZR8O2xe7IgvX=ebT9xRB63E(u"ࠬ࠭୬")):
	LqhAVNWZtIvUrMSEQkx = WK1Bf5cXpgUmOEl4L0Nd not in [hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡍ࠴ࡗࠪ୭"),KylMx0kfTOrG(u"ࠧࡊࡒࡗ࡚ࠬ୮")]
	global lAaCZBGdwOUuxJ
	if not AcrwhZR8O2xe7IgvX: AcrwhZR8O2xe7IgvX = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡸ࡬ࡨࡪࡵࠧ୯")
	lAaCZBGdwOUuxJ,mO3gFiCAx276hQolM,PPYxBe6FLGorlk1IndW8Ka2 = oh1JUWa3LdnqTpz5(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ୰"),xmTX9Aeidq8cVhY(u"ࠪࠫୱ"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࠬ୲")
	if len(kHWT0XY2S6apruwxiB8FDl1)==tvdQHb10PhNmuy6(u"࠳౜"):
		OG9Usa51Nk8D,vjMf9UA7Zx1t,PPYxBe6FLGorlk1IndW8Ka2 = kHWT0XY2S6apruwxiB8FDl1
		if vjMf9UA7Zx1t: mO3gFiCAx276hQolM = tvdQHb10PhNmuy6(u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ୳")+vjMf9UA7Zx1t+GVPK9Ziaho6U2ySLj(u"࠭ࠠ࡞ࠩ୴")
	else: OG9Usa51Nk8D,vjMf9UA7Zx1t,PPYxBe6FLGorlk1IndW8Ka2 = kHWT0XY2S6apruwxiB8FDl1,NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࠨ୵"),YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࠩ୶")
	OG9Usa51Nk8D = OG9Usa51Nk8D.replace(VVtQk9vwe7(u"ࠩࠨ࠶࠵࠭୷"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠪࠤࠬ୸"))
	i9lyj1xVYRDEwQzaZ60 = eeiIspx5JaGYcH0zCu(OG9Usa51Nk8D)
	if WK1Bf5cXpgUmOEl4L0Nd not in [trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭୹"),xmTX9Aeidq8cVhY(u"ࠬࡏࡐࡕࡘࠪ୺")]:
		if WK1Bf5cXpgUmOEl4L0Nd!=uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ୻"): OG9Usa51Nk8D = OG9Usa51Nk8D.replace(C0CbfZuXJM(u"ࠧࠡࠩ୼"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠨࠧ࠵࠴ࠬ୽"))
		b6kj4LJ5tzTeOMQi(C0CbfZuXJM(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ୾"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ୿")+OG9Usa51Nk8D+u2NDjURZVHlmdc0(u"ࠫࠥࡣࠧ஀")+mO3gFiCAx276hQolM)
		if i9lyj1xVYRDEwQzaZ60==ebT9xRB63E(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ஁") and WK1Bf5cXpgUmOEl4L0Nd not in [VVtQk9vwe7(u"࠭ࡉࡑࡖ࡙ࠫஂ"),b46fBrugtPDSYspzMQIx(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஃ")]:
			from wDd0v4uSOc import XuJcNIWr8FMGQS,wicVSPINX4Unkqr5hsgJa6AO8jCT,sdJ1cr6xmpoASuhlqjXi3K7eR8kP0
			JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = XuJcNIWr8FMGQS(OG9Usa51Nk8D)
			fKG1iuWHwak9qCml6M7F = len(EEgFl59RndzrBL8TUoaQMw6P)
			if fKG1iuWHwak9qCml6M7F>ebT9xRB63E(u"࠲ౝ"):
				zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT(GVPK9Ziaho6U2ySLj(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩ஄")+str(fKG1iuWHwak9qCml6M7F)+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"้้ࠩࠣ็ࠩࠨஅ"), JCop4mjTiurYB7W)
				if zKgFfQoODy90ewYb5jGElUJRVs4p==-b098bsyjUud(u"࠳౞"):
					sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(u2NDjURZVHlmdc0(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหึ฽๎้࠭ஆ"),b098bsyjUud(u"ࠫࠬஇ"))
					return lAaCZBGdwOUuxJ
			else: zKgFfQoODy90ewYb5jGElUJRVs4p = uEed4OSxm7hBq9Vvky6QjHwWC(u"࠳౟")
			OG9Usa51Nk8D = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
			if JCop4mjTiurYB7W[ebT9xRB63E(u"࠴ౠ")]!=NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠬ࠳࠱ࠨஈ"):
				b6kj4LJ5tzTeOMQi(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭ࡎࡐࡖࡌࡇࡊ࠭உ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+Vt4ELHXZP6(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ஊ")+JCop4mjTiurYB7W[zKgFfQoODy90ewYb5jGElUJRVs4p]+CC4UDLW6brf(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ஋")+OG9Usa51Nk8D+u2NDjURZVHlmdc0(u"ࠩࠣࡡࠬ஌"))
		if A6Iyo7eXrq2RtMmDxWj(u"ࠪ࠳࡮࡬ࡩ࡭࡯࠲ࠫ஍") in OG9Usa51Nk8D: OG9Usa51Nk8D = OG9Usa51Nk8D+tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஎ")
		elif vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࡮ࡴࡵࡲࠪஏ") in OG9Usa51Nk8D.lower() and pOIe6U1vWYC7Gh2udFBRgT(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ஐ") not in OG9Usa51Nk8D and b098bsyjUud(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ஑") not in OG9Usa51Nk8D:
			if vdHRKkIgTp56Je1OuNo(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ஒ") not in OG9Usa51Nk8D and VVtQk9vwe7(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫஓ") in OG9Usa51Nk8D.lower():
				if vlW6K1g8Xo35mPYbyO2GS(u"ࠪࢀࠬஔ") not in OG9Usa51Nk8D: OG9Usa51Nk8D = OG9Usa51Nk8D+G5TxeI0ND4ztC6(u"ࠫࢁࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨக")
				else: OG9Usa51Nk8D = OG9Usa51Nk8D+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ஖")
			if vdHRKkIgTp56Je1OuNo(u"࠭ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࠪ஗") not in OG9Usa51Nk8D.lower() and WK1Bf5cXpgUmOEl4L0Nd not in [WfgnOq9Fd4lhMSQpK5(u"ࠧࡊࡒࡗ࡚ࠬ஘"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࡏ࠶࡙ࠬங")]:
				if Vt4ELHXZP6(u"ࠩࡿࠫச") not in OG9Usa51Nk8D: OG9Usa51Nk8D = OG9Usa51Nk8D+WfgnOq9Fd4lhMSQpK5(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ஛")
				else: OG9Usa51Nk8D = OG9Usa51Nk8D+cg94WALw5orUhvtHSfNO(u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫஜ")
	b6kj4LJ5tzTeOMQi(VVtQk9vwe7(u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ஝"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+tvdQHb10PhNmuy6(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬஞ")+OG9Usa51Nk8D+xmTX9Aeidq8cVhY(u"ࠧࠡ࡟ࠪட"))
	K2oh8Y1cFTkeGtjV = U6zsmRNGTL.ListItem()
	AcrwhZR8O2xe7IgvX,HimZ5nCXgVaA08yRFbN,Z9IXhMpLKqWlNjo4QvV,qIbjGvLzc6OPUtf8N1,IGXnaCgFJuqd1DTStiAeRW952wb,fhExSFOpLd78CeR1Tg4MDX3vAkP,VyED9uN4HIvn2BeYapP5qA,zNWVQ9bHYBRAKnre,MTarxBIHLhKJjpqO9UPzfA5dZ = NmPa38tGQK2x(QfEL1VroTPIFZkmzjv5O)
	if WK1Bf5cXpgUmOEl4L0Nd not in [GVPK9Ziaho6U2ySLj(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ஠"),Vt4ELHXZP6(u"ࠩࡌࡔ࡙࡜ࠧ஡")]:
		if wIqFesTOvYnu5S2dWfpBVC: JoY3rWqHPnKRIgt = oh1JUWa3LdnqTpz5(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭஢")
		else: JoY3rWqHPnKRIgt = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩண")
		K2oh8Y1cFTkeGtjV.setProperty(JoY3rWqHPnKRIgt, xmTX9Aeidq8cVhY(u"ࠬ࠭த"))
		K2oh8Y1cFTkeGtjV.setMimeType(WfgnOq9Fd4lhMSQpK5(u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ஥"))
		if WWSLAyQdhUXl3ovb<G5TxeI0ND4ztC6(u"࠷࠶ౡ"): K2oh8Y1cFTkeGtjV.setInfo(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࡷ࡫ࡧࡩࡴ࠭஦"),{oh1JUWa3LdnqTpz5(u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ஧"):vlW6K1g8Xo35mPYbyO2GS(u"ࠩࡰࡳࡻ࡯ࡥࠨந")})
		else:
			AwCfZtF3qNI47UgDVhzMWEKjG = K2oh8Y1cFTkeGtjV.getVideoInfoTag()
			AwCfZtF3qNI47UgDVhzMWEKjG.setMediaType(cg94WALw5orUhvtHSfNO(u"ࠪࡱࡴࡼࡩࡦࠩன"))
		K2oh8Y1cFTkeGtjV.setArt({Vt4ELHXZP6(u"ࠫࡹ࡮ࡵ࡮ࡤࠪப"):IGXnaCgFJuqd1DTStiAeRW952wb,tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ஫"):IGXnaCgFJuqd1DTStiAeRW952wb,uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࡢࡢࡰࡱࡩࡷ࠭஬"):IGXnaCgFJuqd1DTStiAeRW952wb,ebT9xRB63E(u"ࠧࡧࡣࡱࡥࡷࡺࠧ஭"):IGXnaCgFJuqd1DTStiAeRW952wb,WfgnOq9Fd4lhMSQpK5(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪம"):IGXnaCgFJuqd1DTStiAeRW952wb,A6Iyo7eXrq2RtMmDxWj(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬய"):IGXnaCgFJuqd1DTStiAeRW952wb,u2NDjURZVHlmdc0(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ர"):IGXnaCgFJuqd1DTStiAeRW952wb,GVPK9Ziaho6U2ySLj(u"ࠫ࡮ࡩ࡯࡯ࠩற"):IGXnaCgFJuqd1DTStiAeRW952wb})
		if i9lyj1xVYRDEwQzaZ60 in [tjoHEAGv2XkrMBsVfCyp5U(u"ࠬ࠴࡭ࡱࡦࠪல"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭࠮࡮࠵ࡸ࠼ࠬள")]: K2oh8Y1cFTkeGtjV.setContentLookup(DItWNMaLOZ146CubYk8lfAwTy(u"࡙ࡸࡵࡦ౶"))
		else: K2oh8Y1cFTkeGtjV.setContentLookup(oh1JUWa3LdnqTpz5(u"ࡌࡡ࡭ࡵࡨ౷"))
		from COH7BKApEP import w2chBfzYG4FlZR7QIbJHTyoKrdv
		if A6Iyo7eXrq2RtMmDxWj(u"ࠧࡳࡶࡰࡴࠬழ") in OG9Usa51Nk8D:
			w2chBfzYG4FlZR7QIbJHTyoKrdv(GVPK9Ziaho6U2ySLj(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫவ"),CC4UDLW6brf(u"ࡆࡢ࡮ࡶࡩ౸"))
		elif i9lyj1xVYRDEwQzaZ60==KylMx0kfTOrG(u"ࠩ࠱ࡱࡵࡪࠧஶ") or uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪஷ") in OG9Usa51Nk8D:
			w2chBfzYG4FlZR7QIbJHTyoKrdv(WfgnOq9Fd4lhMSQpK5(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫஸ"),pOIe6U1vWYC7Gh2udFBRgT(u"ࡇࡣ࡯ࡷࡪ౹"))
			K2oh8Y1cFTkeGtjV.setProperty(JoY3rWqHPnKRIgt,DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬஹ"))
			K2oh8Y1cFTkeGtjV.setProperty(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡭ࡢࡰ࡬ࡪࡪࡹࡴࡠࡶࡼࡴࡪ࠭஺"),KylMx0kfTOrG(u"ࠧ࡮ࡲࡧࠫ஻"))
		if vjMf9UA7Zx1t:
			K2oh8Y1cFTkeGtjV.setSubtitles([vjMf9UA7Zx1t])
	if AcrwhZR8O2xe7IgvX==vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡸ࡬ࡨࡪࡵࠧ஼") and WK1Bf5cXpgUmOEl4L0Nd==ebT9xRB63E(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ஽"):
		lAaCZBGdwOUuxJ = vlW6K1g8Xo35mPYbyO2GS(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪா")
		WK1Bf5cXpgUmOEl4L0Nd = u2NDjURZVHlmdc0(u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫி")
	elif AcrwhZR8O2xe7IgvX==G5TxeI0ND4ztC6(u"ࠬࡼࡩࡥࡧࡲࠫீ") and zNWVQ9bHYBRAKnre.startswith(b098bsyjUud(u"࠭࠶ࠨு")):
		lAaCZBGdwOUuxJ = WfgnOq9Fd4lhMSQpK5(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩூ")
		WK1Bf5cXpgUmOEl4L0Nd = WK1Bf5cXpgUmOEl4L0Nd+mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠨࡡࡇࡐࠬ௃")
	if lAaCZBGdwOUuxJ!=b46fBrugtPDSYspzMQIx(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ௄"): CxvecthowDqgba7mOslpXLPMBfVz()
	Icq0w9JEDLPZ7GO4xQ6agNX = c8MHvAwb0E21g4mLeClpVPska()
	if Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ: return ebT9xRB63E(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ௅")
	Icq0w9JEDLPZ7GO4xQ6agNX.cZBuPVsp46UxLSA8OG5TvwNI1q(WK1Bf5cXpgUmOEl4L0Nd)
	if AcrwhZR8O2xe7IgvX==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠫࡻ࡯ࡤࡦࡱࠪெ") and not zNWVQ9bHYBRAKnre.startswith(GVPK9Ziaho6U2ySLj(u"ࠬ࠼ࠧே")):
		K2oh8Y1cFTkeGtjV.setPath(OG9Usa51Nk8D)
		b6kj4LJ5tzTeOMQi(C0CbfZuXJM(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ை"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+xmTX9Aeidq8cVhY(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௉")+OG9Usa51Nk8D+Wbwj0o5gsXQ8F2f(u"ࠨࠢࡠࠫொ"))
		wwxkRfBvlShcg72TKtbdyQrniEY.setResolvedUrl(MPBU8HXFoN3Ocj,uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡖࡵࡹࡪ౺"),K2oh8Y1cFTkeGtjV)
	elif AcrwhZR8O2xe7IgvX==b46fBrugtPDSYspzMQIx(u"ࠩ࡯࡭ࡻ࡫ࠧோ"):
		b6kj4LJ5tzTeOMQi(tvdQHb10PhNmuy6(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪௌ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+Vt4ELHXZP6(u"ࠫࠥࠦࠠࡍ࡫ࡹࡩࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡳࡰࡦࡿࠨࠪࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ்ࠬ")+OG9Usa51Nk8D+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࠦ࡝ࠨ௎"))
		Icq0w9JEDLPZ7GO4xQ6agNX.play(OG9Usa51Nk8D,K2oh8Y1cFTkeGtjV)
	llC9WmbrAIgpzfi3n = uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࡉࡥࡱࡹࡥ౻")
	if lAaCZBGdwOUuxJ==G5TxeI0ND4ztC6(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ௏"):
		from tvJDK3FQ92 import V9fmwgBH3yhYzR
		llC9WmbrAIgpzfi3n = V9fmwgBH3yhYzR(OG9Usa51Nk8D,i9lyj1xVYRDEwQzaZ60,WK1Bf5cXpgUmOEl4L0Nd)
		if llC9WmbrAIgpzfi3n: CxvecthowDqgba7mOslpXLPMBfVz()
	else:
		ObFSK3zDPkrX5qgN9,lAaCZBGdwOUuxJ,HWQTgzvckrD6SVK0il7FqPuy8OJbx2,hc3RHtIZDWnSaXQC0yLg2zmuUF,T2SUkVfBzZhH8cmXodJ = tvdQHb10PhNmuy6(u"࠶ౢ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠧࡵࡴ࡬ࡩࡩ࠭ௐ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࡊࡦࡲࡳࡦ౼"),C0CbfZuXJM(u"࠲࠲࠳࠴౤"),A6Iyo7eXrq2RtMmDxWj(u"࠳࠱࠲࠳࠴ౣ")
		if LqhAVNWZtIvUrMSEQkx: from wDd0v4uSOc import sdJ1cr6xmpoASuhlqjXi3K7eR8kP0
		while ObFSK3zDPkrX5qgN9<T2SUkVfBzZhH8cmXodJ:
			Wj3qSagkcweAb2prRiDyM0HK7Guo.sleep(hc3RHtIZDWnSaXQC0yLg2zmuUF)
			ObFSK3zDPkrX5qgN9 += hc3RHtIZDWnSaXQC0yLg2zmuUF
			if Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ௑") and not HWQTgzvckrD6SVK0il7FqPuy8OJbx2:
				if LqhAVNWZtIvUrMSEQkx: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(b098bsyjUud(u"้ࠩะาࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௒"),Vt4ELHXZP6(u"ࠪࠫ௓"),Mrx2OeZV1LNjBsQ58Savi7=A6Iyo7eXrq2RtMmDxWj(u"࠹࠸࠴౥"))
				b6kj4LJ5tzTeOMQi(trSQHvP4aqBWFKxN5bZgXCu(u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ௔"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+xmTX9Aeidq8cVhY(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ௕")+OG9Usa51Nk8D+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠭ࠠ࡞ࠩ௖")+mO3gFiCAx276hQolM)
				HWQTgzvckrD6SVK0il7FqPuy8OJbx2 = G5TxeI0ND4ztC6(u"࡙ࡸࡵࡦ౽")
			elif Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ in [vdHRKkIgTp56Je1OuNo(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨௗ"),C0CbfZuXJM(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ௘")]:
				b6kj4LJ5tzTeOMQi(b098bsyjUud(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ௙"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+cg94WALw5orUhvtHSfNO(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ௚")+OG9Usa51Nk8D+tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠥࡣࠧ௛")+mO3gFiCAx276hQolM)
				break
			elif Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ==u2NDjURZVHlmdc0(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௜"):
				b6kj4LJ5tzTeOMQi(CC4UDLW6brf(u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ௝"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+u2NDjURZVHlmdc0(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡴࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭௞")+OG9Usa51Nk8D+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠨࠢࡠࠫ௟")+mO3gFiCAx276hQolM)
				if LqhAVNWZtIvUrMSEQkx: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(DItWNMaLOZ146CubYk8lfAwTy(u"ࠩไุ้ࠦสี฼ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪ௠"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࠫ௡"),Mrx2OeZV1LNjBsQ58Savi7=Wbwj0o5gsXQ8F2f(u"࠴࠶࠺࠶౦"))
				break
			elif Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ==b098bsyjUud(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ௢"):
				b6kj4LJ5tzTeOMQi(Wbwj0o5gsXQ8F2f(u"ࠬࡋࡒࡓࡑࡕࠫ௣"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+tvdQHb10PhNmuy6(u"࠭ࠠࠡࠢࡇࡩࡻ࡯ࡣࡦࠢ࡬ࡷࠥࡨ࡬ࡰࡥ࡮ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ௤")+OG9Usa51Nk8D+b098bsyjUud(u"ࠧࠡ࡟ࠪ௥"))
				break
		else:
			if LqhAVNWZtIvUrMSEQkx: sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(tjoHEAGv2XkrMBsVfCyp5U(u"ࠨใื่ࠥะิ฻์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩ௦"),C0CbfZuXJM(u"ࠩࠪ௧"),Mrx2OeZV1LNjBsQ58Savi7=vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠵࠷࠻࠰౧"))
			b6kj4LJ5tzTeOMQi(Vt4ELHXZP6(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ௨"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+CC4UDLW6brf(u"ࠫࠥࠦࠠࡕ࡫ࡰࡩࡴࡻࡴ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ௩")+OG9Usa51Nk8D+DItWNMaLOZ146CubYk8lfAwTy(u"ࠬࠦ࡝ࠨ௪")+mO3gFiCAx276hQolM)
			lAaCZBGdwOUuxJ = xmTX9Aeidq8cVhY(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ௫")
	if lAaCZBGdwOUuxJ in [Yr0wo7FaSHx(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ௬")] or Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ in [vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ௭"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ௮")] or llC9WmbrAIgpzfi3n:
		if Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ==pOIe6U1vWYC7Gh2udFBRgT(u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ௯"): WK1Bf5cXpgUmOEl4L0Nd = WK1Bf5cXpgUmOEl4L0Nd+KylMx0kfTOrG(u"ࠫࡤ࡚ࡓࠨ௰")
		QBDjIUdSiR = dPzeYJhmT9SHGO0ivLENku4rxl6Cc(WK1Bf5cXpgUmOEl4L0Nd)
	else: exec(DItWNMaLOZ146CubYk8lfAwTy(u"ࠬ࡯࡭ࡱࡱࡵࡸࠥࡾࡢ࡮ࡥ࠾ࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱ࡷࡹࡵࡰࠩࠫࠪ௱"))
	return Icq0w9JEDLPZ7GO4xQ6agNX.lAaCZBGdwOUuxJ
def eeiIspx5JaGYcH0zCu(OG9Usa51Nk8D):
	if DQfHadYvTpy1UR: from urllib.parse import urlparse
	else: from urlparse import urlparse
	path = urlparse(OG9Usa51Nk8D).path
	gkWfymKYO34hnl26Bzp = b46fBrugtPDSYspzMQIx(u"࠭ࠧ௲") if C0CbfZuXJM(u"ࠧ࠯ࠩ௳") not in path else path.rsplit(vdHRKkIgTp56Je1OuNo(u"ࠨ࠰ࠪ௴"),tvdQHb10PhNmuy6(u"࠶౨"))[tvdQHb10PhNmuy6(u"࠶౨")]
	if gkWfymKYO34hnl26Bzp in [vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠩࡤࡺ࡮࠭௵"),b46fBrugtPDSYspzMQIx(u"ࠪࡸࡸ࠭௶"),G5TxeI0ND4ztC6(u"ࠫࡦࡧࡣࠨ௷"),KylMx0kfTOrG(u"ࠬࡳࡰ࠵ࠩ௸"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭࡭࠴ࡷࠪ௹"),CC4UDLW6brf(u"ࠧ࡮࠵ࡸ࠼ࠬ௺"),b098bsyjUud(u"ࠨ࡯ࡳࡨࠬ௻"),A6Iyo7eXrq2RtMmDxWj(u"ࠩࡰ࡯ࡻ࠭௼"),VVtQk9vwe7(u"ࠪࡪࡱࡼࠧ௽"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫࡲࡶ࠳ࠨ௾"),b46fBrugtPDSYspzMQIx(u"ࠬࡽࡥࡣ࡯ࠪ௿")]: return gkWfymKYO34hnl26Bzp
	return vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠭ࠧఀ")

# kjfjdkfjdfkjdkf

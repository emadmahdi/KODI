# -*- coding: utf-8 -*-
import sys as uea9JUBOMcEfh8CN0v6b
VuPF4AakS68MzCOoK9EhcX = uea9JUBOMcEfh8CN0v6b.version_info [0] == 2
YMI8bZmlShHeE = 2048
DCiYr3F0bTd = 7
def zVmLhkoDTfGBMF8UeH3sW9jcKd (lpSv1IjaByxCEGnbDoMQ7ZKXYP5):
	global H1hBFmoiC4lcqX63QJA7D
	g2g3WRvKMPuT4ibD0Se5mcyGUowLE = ord (lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [-1])
	WWIR4zUaoF0t51rX = lpSv1IjaByxCEGnbDoMQ7ZKXYP5 [:-1]
	h7fAQcsU6jpZ0NXuM4RT9DFlW5 = g2g3WRvKMPuT4ibD0Se5mcyGUowLE % len (WWIR4zUaoF0t51rX)
	LLlnrZIxpckuCGmh3Kj4 = WWIR4zUaoF0t51rX [:h7fAQcsU6jpZ0NXuM4RT9DFlW5] + WWIR4zUaoF0t51rX [h7fAQcsU6jpZ0NXuM4RT9DFlW5:]
	if VuPF4AakS68MzCOoK9EhcX:
		tLNUQnJH1ZYP3O = unicode () .join ([unichr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	else:
		tLNUQnJH1ZYP3O = str () .join ([chr (ord (NBGoz9FwI51f67jsyclZxDJtC2g) - YMI8bZmlShHeE - (PkCBd0c2Y1v7h5MqyXz8torlpWDfU + g2g3WRvKMPuT4ibD0Se5mcyGUowLE) % DCiYr3F0bTd) for PkCBd0c2Y1v7h5MqyXz8torlpWDfU, NBGoz9FwI51f67jsyclZxDJtC2g in enumerate (LLlnrZIxpckuCGmh3Kj4)])
	return eval (tLNUQnJH1ZYP3O)
cg94WALw5orUhvtHSfNO,Vt4ELHXZP6,WfgnOq9Fd4lhMSQpK5=zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd,zVmLhkoDTfGBMF8UeH3sW9jcKd
Yr0wo7FaSHx,trSQHvP4aqBWFKxN5bZgXCu,hhmKpWNtn849SgBFoVqHkQCXZJvT=WfgnOq9Fd4lhMSQpK5,Vt4ELHXZP6,cg94WALw5orUhvtHSfNO
ebT9xRB63E,vJ2Q9gokKptI6YxrhDURClcFOz4,KylMx0kfTOrG=hhmKpWNtn849SgBFoVqHkQCXZJvT,trSQHvP4aqBWFKxN5bZgXCu,Yr0wo7FaSHx
tvdQHb10PhNmuy6,G5TxeI0ND4ztC6,uuxL7t2lIi0JTESMR8kQrNKdjZU3m=KylMx0kfTOrG,vJ2Q9gokKptI6YxrhDURClcFOz4,ebT9xRB63E
CC4UDLW6brf,GVPK9Ziaho6U2ySLj,Wbwj0o5gsXQ8F2f=uuxL7t2lIi0JTESMR8kQrNKdjZU3m,G5TxeI0ND4ztC6,tvdQHb10PhNmuy6
mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc,b098bsyjUud,uEed4OSxm7hBq9Vvky6QjHwWC=Wbwj0o5gsXQ8F2f,GVPK9Ziaho6U2ySLj,CC4UDLW6brf
DItWNMaLOZ146CubYk8lfAwTy,vlW6K1g8Xo35mPYbyO2GS,b46fBrugtPDSYspzMQIx=uEed4OSxm7hBq9Vvky6QjHwWC,b098bsyjUud,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc
C0CbfZuXJM,jmhU85aovOS1GxqKBn2RICXgQJ6T,vdHRKkIgTp56Je1OuNo=b46fBrugtPDSYspzMQIx,vlW6K1g8Xo35mPYbyO2GS,DItWNMaLOZ146CubYk8lfAwTy
A6Iyo7eXrq2RtMmDxWj,u2NDjURZVHlmdc0,tjoHEAGv2XkrMBsVfCyp5U=vdHRKkIgTp56Je1OuNo,jmhU85aovOS1GxqKBn2RICXgQJ6T,C0CbfZuXJM
xmTX9Aeidq8cVhY,VVtQk9vwe7,YSGNpiTt6Xe8qh39ElIoQvjVxc=tjoHEAGv2XkrMBsVfCyp5U,u2NDjURZVHlmdc0,A6Iyo7eXrq2RtMmDxWj
oh1JUWa3LdnqTpz5,pOIe6U1vWYC7Gh2udFBRgT,NALF8cewsai2lpT1OqICB0bDdVWrQ=YSGNpiTt6Xe8qh39ElIoQvjVxc,VVtQk9vwe7,xmTX9Aeidq8cVhY
from wDd0v4uSOc import *
FpjtBKrnu5SdfyOvEPIQ = NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪज")
def HYWukw3pL2oMzPK4(AFWci0tYmjRU1azGJEy3ovDw2hfsqr,apIVksn1FTuj6rbYhMPDLHS9N):
	if   AFWci0tYmjRU1azGJEy3ovDw2hfsqr==uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"࠷࠸࠶৪"): mL7BVKcSygkuoPbWlEF4YD = TvQ3WsDB9cYeqlIZAnXELtVP5o7C1()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==WfgnOq9Fd4lhMSQpK5(u"࠸࠹࠱৫"): mL7BVKcSygkuoPbWlEF4YD = CsUdRabWuh0M9F(apIVksn1FTuj6rbYhMPDLHS9N)
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==tjoHEAGv2XkrMBsVfCyp5U(u"࠹࠳࠳৬"): mL7BVKcSygkuoPbWlEF4YD = SwJAsRkvMaL0ir1oeDU()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==u2NDjURZVHlmdc0(u"࠳࠴࠵৭"): mL7BVKcSygkuoPbWlEF4YD = qu0py78bdYnI5rmMZG2wS6i()
	elif AFWci0tYmjRU1azGJEy3ovDw2hfsqr==b098bsyjUud(u"࠴࠵࠷৮"): mL7BVKcSygkuoPbWlEF4YD = nhH5j4c3ZJbiPxvQemMp8BYC(apIVksn1FTuj6rbYhMPDLHS9N)
	else: mL7BVKcSygkuoPbWlEF4YD = Wbwj0o5gsXQ8F2f(u"ࡋࡧ࡬ࡴࡧਜ")
	return mL7BVKcSygkuoPbWlEF4YD
def nhH5j4c3ZJbiPxvQemMp8BYC(TC8Sh37AlIpdXxRGy92rJqjuNWas):
	try: A73K6zLXIgFROeCHJQi0Pbos.remove(TC8Sh37AlIpdXxRGy92rJqjuNWas.decode(A6Iyo7eXrq2RtMmDxWj(u"ࠩࡸࡸ࡫࠾ࠧझ")))
	except: A73K6zLXIgFROeCHJQi0Pbos.remove(TC8Sh37AlIpdXxRGy92rJqjuNWas)
	return
def CsUdRabWuh0M9F(apIVksn1FTuj6rbYhMPDLHS9N):
	XbzQHGJ0cBV(apIVksn1FTuj6rbYhMPDLHS9N,FpjtBKrnu5SdfyOvEPIQ,KylMx0kfTOrG(u"ࠪࡺ࡮ࡪࡥࡰࠩञ"))
	return
def qu0py78bdYnI5rmMZG2wS6i():
	Ay3eLGaTncD67lx8ZOud = jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪट")
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(VVtQk9vwe7(u"ࠬ࠭ठ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠭ࠧड"),xmTX9Aeidq8cVhY(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ढ"),Ay3eLGaTncD67lx8ZOud)
	return
def TvQ3WsDB9cYeqlIZAnXELtVP5o7C1():
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(G5TxeI0ND4ztC6(u"ࠨ࡮࡬ࡲࡰ࠭ण"),xmTX9Aeidq8cVhY(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ฼ื๊ใหࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪत"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠪࠫथ"),oh1JUWa3LdnqTpz5(u"࠵࠶࠷৯"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(ebT9xRB63E(u"ࠫࡱ࡯࡮࡬ࠩद"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ห฼ํ๎ึࠦๅไษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨध"),trSQHvP4aqBWFKxN5bZgXCu(u"࠭ࠧन"),tvdQHb10PhNmuy6(u"࠶࠷࠷ৰ"))
	nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(KylMx0kfTOrG(u"ࠧ࡭࡫ࡱ࡯ࠬऩ"),Vt4ELHXZP6(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),GVPK9Ziaho6U2ySLj(u"ࠩࠪफ"),pOIe6U1vWYC7Gh2udFBRgT(u"࠽࠾࠿࠹ৱ"))
	nKHX0316wQ89CPGesxqJmF = YHU6yu4sO0()
	uufirvj6k9g3JpOHFdBmxPGhloM = A73K6zLXIgFROeCHJQi0Pbos.stat(nKHX0316wQ89CPGesxqJmF).st_mtime
	G6xvk7zXYPqy4aofmTjRbMCd = []
	if DQfHadYvTpy1UR: z4cPMqdtHAfVe = A73K6zLXIgFROeCHJQi0Pbos.listdir(nKHX0316wQ89CPGesxqJmF.encode(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪࡹࡹ࡬࠸ࠨब")))
	else: z4cPMqdtHAfVe = A73K6zLXIgFROeCHJQi0Pbos.listdir(nKHX0316wQ89CPGesxqJmF.decode(xmTX9Aeidq8cVhY(u"ࠫࡺࡺࡦ࠹ࠩभ")))
	for TTkmwqXoLyID837SW9MtlxAg in z4cPMqdtHAfVe:
		if DQfHadYvTpy1UR: TTkmwqXoLyID837SW9MtlxAg = TTkmwqXoLyID837SW9MtlxAg.decode(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠬࡻࡴࡧ࠺ࠪम"))
		if not TTkmwqXoLyID837SW9MtlxAg.startswith(Yr0wo7FaSHx(u"࠭ࡦࡪ࡮ࡨࡣࠬय")): continue
		QDSOneLB0p9WCI6AxFsV1Gdl5Pj = A73K6zLXIgFROeCHJQi0Pbos.path.join(nKHX0316wQ89CPGesxqJmF,TTkmwqXoLyID837SW9MtlxAg)
		uufirvj6k9g3JpOHFdBmxPGhloM = A73K6zLXIgFROeCHJQi0Pbos.path.getmtime(QDSOneLB0p9WCI6AxFsV1Gdl5Pj)
		G6xvk7zXYPqy4aofmTjRbMCd.append([TTkmwqXoLyID837SW9MtlxAg,uufirvj6k9g3JpOHFdBmxPGhloM])
	G6xvk7zXYPqy4aofmTjRbMCd = sorted(G6xvk7zXYPqy4aofmTjRbMCd,reverse=vdHRKkIgTp56Je1OuNo(u"࡚ࡲࡶࡧਝ"),key=lambda key: key[b46fBrugtPDSYspzMQIx(u"࠶৲")])
	for TTkmwqXoLyID837SW9MtlxAg,uufirvj6k9g3JpOHFdBmxPGhloM in G6xvk7zXYPqy4aofmTjRbMCd:
		if wIqFesTOvYnu5S2dWfpBVC:
			try: TTkmwqXoLyID837SW9MtlxAg = TTkmwqXoLyID837SW9MtlxAg.decode(cg94WALw5orUhvtHSfNO(u"ࠧࡶࡶࡩ࠼ࠬर"))
			except: pass
			TTkmwqXoLyID837SW9MtlxAg = TTkmwqXoLyID837SW9MtlxAg.encode(b46fBrugtPDSYspzMQIx(u"ࠨࡷࡷࡪ࠽࠭ऱ"))
		QDSOneLB0p9WCI6AxFsV1Gdl5Pj = A73K6zLXIgFROeCHJQi0Pbos.path.join(nKHX0316wQ89CPGesxqJmF,TTkmwqXoLyID837SW9MtlxAg)
		nUHOFvo7RiecSJ5V9zPEhCkWZqY86G(oh1JUWa3LdnqTpz5(u"ࠩࡹ࡭ࡩ࡫࡯ࠨल"),TTkmwqXoLyID837SW9MtlxAg,QDSOneLB0p9WCI6AxFsV1Gdl5Pj,u2NDjURZVHlmdc0(u"࠹࠳࠲৳"))
	return
def YHU6yu4sO0():
	nKHX0316wQ89CPGesxqJmF = BBwb2NzsHE.getSetting(DItWNMaLOZ146CubYk8lfAwTy(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ळ"))
	if nKHX0316wQ89CPGesxqJmF: return nKHX0316wQ89CPGesxqJmF
	BBwb2NzsHE.setSetting(WfgnOq9Fd4lhMSQpK5(u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧऴ"),HnMP40juJfr6L1mexbWBV)
	return HnMP40juJfr6L1mexbWBV
def SwJAsRkvMaL0ir1oeDU():
	nKHX0316wQ89CPGesxqJmF = YHU6yu4sO0()
	pcSGorwAVqQfE7OWU0a = MMTfC8jWkbhxp2BDt(cg94WALw5orUhvtHSfNO(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬव"),GVPK9Ziaho6U2ySLj(u"࠭ࠧश"),Yr0wo7FaSHx(u"ࠧࠨष"),Wbwj0o5gsXQ8F2f(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬस"),b46fBrugtPDSYspzMQIx(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬह")+nKHX0316wQ89CPGesxqJmF+A6Iyo7eXrq2RtMmDxWj(u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬऺ"))
	if pcSGorwAVqQfE7OWU0a==oh1JUWa3LdnqTpz5(u"࠱৴"):
		r4wRpJqQT0Z5XySt8e7ED9dMHNIn = ly0NGuYRPesoatS1kEwZMbWOX2UK(uEed4OSxm7hBq9Vvky6QjHwWC(u"࠴৵"),b098bsyjUud(u"๊้ࠫว็ࠢอั๊๐ไࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠨऻ"),u2NDjURZVHlmdc0(u"ࠬࡲ࡯ࡤࡣ࡯़ࠫ"),CC4UDLW6brf(u"࠭ࠧऽ"),A6Iyo7eXrq2RtMmDxWj(u"ࡇࡣ࡯ࡷࡪਟ"),ebT9xRB63E(u"ࡔࡳࡷࡨਞ"),nKHX0316wQ89CPGesxqJmF)
		J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࡤࡧࡱࡸࡪࡸࠧा"),b098bsyjUud(u"ࠨࠩि"),ebT9xRB63E(u"ࠩࠪी"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧु"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧू")+nKHX0316wQ89CPGesxqJmF+u2NDjURZVHlmdc0(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱ๋ีอ่๊ࠠࠣห้๋ใศ่ࠣห้าฯ๋ั่ࠣฯิา๋่้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬะ้้ํวࠡษ้ฮࠥฮวิฬัำฬ๋่ࠠาสࠤฬ๊ศา่ส้ัࠦ࠮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็๊ࠤอีไศ่๊ࠢࠥอไๆๅส๊ࠥอไใัํ้ࠥลࠧृ"))
		if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6==KylMx0kfTOrG(u"࠳৶"):
			BBwb2NzsHE.setSetting(CC4UDLW6brf(u"࠭ࡡࡷ࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵࡧࡴࡩࠩॄ"),r4wRpJqQT0Z5XySt8e7ED9dMHNIn)
			ArKbmeZFN7cRuvjfiHBJ0SEqd2l(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࠨॅ"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠨࠩॆ"),uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬे"),A6Iyo7eXrq2RtMmDxWj(u"ࠪฮ๊ࠦส฻์ํี๋ࠥใศ่ࠣฮำุ๊็ࠢส่๊๊แศฬࠣห้๋อๆๆฬࠫै"))
	return
def V9fmwgBH3yhYzR(apIVksn1FTuj6rbYhMPDLHS9N,i9lyj1xVYRDEwQzaZ60=u2NDjURZVHlmdc0(u"ࠫࠬॉ"),website=vdHRKkIgTp56Je1OuNo(u"ࠬ࠭ॊ")):
	b6kj4LJ5tzTeOMQi(tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࡎࡐࡖࡌࡇࡊ࠭ो"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧौ")+apIVksn1FTuj6rbYhMPDLHS9N+pOIe6U1vWYC7Gh2udFBRgT(u"ࠨࠢࡠ्ࠫ"))
	if not i9lyj1xVYRDEwQzaZ60: i9lyj1xVYRDEwQzaZ60 = eeiIspx5JaGYcH0zCu(apIVksn1FTuj6rbYhMPDLHS9N)
	nKHX0316wQ89CPGesxqJmF = YHU6yu4sO0()
	llxDWyvLpAEwCkbJSN5hMr = xaEZjvs6y0qt2Wmh()
	TTkmwqXoLyID837SW9MtlxAg = llxDWyvLpAEwCkbJSN5hMr.replace(GVPK9Ziaho6U2ySLj(u"ࠩࠣࠫॎ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡣࠬॏ"))
	TTkmwqXoLyID837SW9MtlxAg = qIKCc75Futx6BpNPz(TTkmwqXoLyID837SW9MtlxAg)
	TTkmwqXoLyID837SW9MtlxAg = cg94WALw5orUhvtHSfNO(u"ࠫ࡫࡯࡬ࡦࡡࠪॐ")+str(int(uZ7xiFaBvSrWG2mXjITp))[-jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠷৷"):]+xmTX9Aeidq8cVhY(u"ࠬࡥࠧ॑")+TTkmwqXoLyID837SW9MtlxAg+i9lyj1xVYRDEwQzaZ60
	w6J70rVDdcWMEO = A73K6zLXIgFROeCHJQi0Pbos.path.join(nKHX0316wQ89CPGesxqJmF,TTkmwqXoLyID837SW9MtlxAg)
	jmdxulY90XbNQGP5vSfoz16h = {}
	jmdxulY90XbNQGP5vSfoz16h[NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ॒")] = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠧࠨ॓")
	jmdxulY90XbNQGP5vSfoz16h[Vt4ELHXZP6(u"ࠨࡃࡦࡧࡪࡶࡴࠨ॔")] = Vt4ELHXZP6(u"ࠩ࠭࠳࠯࠭ॕ")
	apIVksn1FTuj6rbYhMPDLHS9N = apIVksn1FTuj6rbYhMPDLHS9N.replace(mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭ॖ"),vlW6K1g8Xo35mPYbyO2GS(u"ࠫࠬॗ"))
	if VVtQk9vwe7(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪक़") in apIVksn1FTuj6rbYhMPDLHS9N:
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO,ASwKFJhGY15gO4tLTd6fN0M = apIVksn1FTuj6rbYhMPDLHS9N.rsplit(WfgnOq9Fd4lhMSQpK5(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫख़"),trSQHvP4aqBWFKxN5bZgXCu(u"࠵৸"))
		ASwKFJhGY15gO4tLTd6fN0M = ASwKFJhGY15gO4tLTd6fN0M.replace(KylMx0kfTOrG(u"ࠧࡽࠩग़"),Vt4ELHXZP6(u"ࠨࠩज़")).replace(GVPK9Ziaho6U2ySLj(u"ࠩࠩࠫड़"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࠫढ़"))
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,ASwKFJhGY15gO4tLTd6fN0M = apIVksn1FTuj6rbYhMPDLHS9N,None
	if not ASwKFJhGY15gO4tLTd6fN0M: ASwKFJhGY15gO4tLTd6fN0M = yyYKmdtsAFic93()
	if ASwKFJhGY15gO4tLTd6fN0M: jmdxulY90XbNQGP5vSfoz16h[G5TxeI0ND4ztC6(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨफ़")] = ASwKFJhGY15gO4tLTd6fN0M
	if jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧय़") in FrC9LhHZWIySdGwNsuzqt5Rf01TXO: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,aCOI75DKgfuSq4xhojtPzBlYRQ = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.rsplit(vdHRKkIgTp56Je1OuNo(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨॠ"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"࠶৹"))
	else: FrC9LhHZWIySdGwNsuzqt5Rf01TXO,aCOI75DKgfuSq4xhojtPzBlYRQ = FrC9LhHZWIySdGwNsuzqt5Rf01TXO,uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࠨॡ")
	FrC9LhHZWIySdGwNsuzqt5Rf01TXO = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.strip(WfgnOq9Fd4lhMSQpK5(u"ࠨࡾࠪॢ")).strip(Vt4ELHXZP6(u"ࠩࠩࠫॣ")).strip(Wbwj0o5gsXQ8F2f(u"ࠪࢀࠬ।")).strip(Vt4ELHXZP6(u"ࠫࠫ࠭॥"))
	aCOI75DKgfuSq4xhojtPzBlYRQ = aCOI75DKgfuSq4xhojtPzBlYRQ.replace(tvdQHb10PhNmuy6(u"ࠬࢂࠧ०"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࠭ࠧ१")).replace(DItWNMaLOZ146CubYk8lfAwTy(u"ࠧࠧࠩ२"),Yr0wo7FaSHx(u"ࠨࠩ३"))
	if aCOI75DKgfuSq4xhojtPzBlYRQ:	jmdxulY90XbNQGP5vSfoz16h[DItWNMaLOZ146CubYk8lfAwTy(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ४")] = aCOI75DKgfuSq4xhojtPzBlYRQ
	b6kj4LJ5tzTeOMQi(A6Iyo7eXrq2RtMmDxWj(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ५"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+GVPK9Ziaho6U2ySLj(u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ६")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+Vt4ELHXZP6(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨ७")+str(jmdxulY90XbNQGP5vSfoz16h)+tjoHEAGv2XkrMBsVfCyp5U(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭८")+w6J70rVDdcWMEO+G5TxeI0ND4ztC6(u"ࠧࠡ࡟ࠪ९"))
	rcHgiYv9QXRJtCaPKFn4zoU2G5N = cg94WALw5orUhvtHSfNO(u"࠷࠰࠳࠶৺")*cg94WALw5orUhvtHSfNO(u"࠷࠰࠳࠶৺")
	U70bPCrxOjD6zctRhQ = YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠰৻")
	try:
		VwFm42ibsO6KNuTZfg0y =	Wj3qSagkcweAb2prRiDyM0HK7Guo.getInfoLabel(Vt4ELHXZP6(u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫ॰"))
		VwFm42ibsO6KNuTZfg0y = JJDtX1PZyIgN2T.findall(oh1JUWa3LdnqTpz5(u"ࠩ࡟ࡨ࠰࠭ॱ"),VwFm42ibsO6KNuTZfg0y)
		U70bPCrxOjD6zctRhQ = int(VwFm42ibsO6KNuTZfg0y[vdHRKkIgTp56Je1OuNo(u"࠱ৼ")])
	except: pass
	if not U70bPCrxOjD6zctRhQ:
		try:
			wZOBEeK6lDGoR1Srn0d7TV2uPIC = A73K6zLXIgFROeCHJQi0Pbos.statvfs(nKHX0316wQ89CPGesxqJmF)
			U70bPCrxOjD6zctRhQ = wZOBEeK6lDGoR1Srn0d7TV2uPIC.f_frsize*wZOBEeK6lDGoR1Srn0d7TV2uPIC.f_bavail//rcHgiYv9QXRJtCaPKFn4zoU2G5N
		except: pass
	if not U70bPCrxOjD6zctRhQ:
		try:
			wZOBEeK6lDGoR1Srn0d7TV2uPIC = A73K6zLXIgFROeCHJQi0Pbos.fstatvfs(nKHX0316wQ89CPGesxqJmF)
			U70bPCrxOjD6zctRhQ = wZOBEeK6lDGoR1Srn0d7TV2uPIC.f_frsize*wZOBEeK6lDGoR1Srn0d7TV2uPIC.f_bavail//rcHgiYv9QXRJtCaPKFn4zoU2G5N
		except: pass
	if not U70bPCrxOjD6zctRhQ:
		try:
			import shutil as MJcpwD4fjTOlbrKNGSy
			yCGWPZbfzX2TsqJQui,xAohsq40rHkO2EF6uDSR,FFDlV2c5yBLCE3bHUuxXNWQs89h6 = MJcpwD4fjTOlbrKNGSy.disk_usage(nKHX0316wQ89CPGesxqJmF)
			U70bPCrxOjD6zctRhQ = FFDlV2c5yBLCE3bHUuxXNWQs89h6//rcHgiYv9QXRJtCaPKFn4zoU2G5N
		except: pass
	if not U70bPCrxOjD6zctRhQ:
		u59uk1YqFUTd(u2NDjURZVHlmdc0(u"ࠪࡶ࡮࡭ࡨࡵࠩॲ"),ebT9xRB63E(u"ู๊ࠫวฮหࠣห้ะฮำ์้ࠤ๊า็้ๆฬࠫॳ"),KylMx0kfTOrG(u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ำฯะ่ࠢๆิอัࠡ็ึหาฯࠠศๆอาื๐ๆࠡษ็ๅฬืฺสࠢไ๎ࠥา็ศิๆࠤํ฿ไ๋้ࠣๅฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬฺ่๋๊ࠣࠦ็็ࠤ฾์ฯไࠢศ่๎ࠦร็ࠢํๆํ๋ࠠๆสิ้ั๐ࠠษำ้ห๊าࠠไ๊า๎ࠥฮอๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠใัࠣ๎ุฮศࠡษ่ฮ้อมࠡฮ๊หื้ࠠษษ็้้็วห๋๋ࠢีอࠠโ์๊ࠤำ฽่าหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬฺ๎ัสุࠢั๏ำษ๊ࠡ็๋ีอࠠศๆึฬอࠦโศ็ࠣห้๋ศา็ฯࠤ๊สโหษࠣฬ๊์ูࠡษ็ฬึ์วๆฮ้๋ࠣࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩॴ"),GVPK9Ziaho6U2ySLj(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩॵ"))
		b6kj4LJ5tzTeOMQi(Yr0wo7FaSHx(u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬॶ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+DItWNMaLOZ146CubYk8lfAwTy(u"ࠨࠢࠣࠤ࡚ࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡥ࡫ࡶ࡯ࠥ࡬ࡲࡦࡧࠣࡷࡵࡧࡣࡦࠩॷ"))
		return CC4UDLW6brf(u"ࡈࡤࡰࡸ࡫ਠ")
	if i9lyj1xVYRDEwQzaZ60==G5TxeI0ND4ztC6(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॸ"):
		JCop4mjTiurYB7W,EEgFl59RndzrBL8TUoaQMw6P = XuJcNIWr8FMGQS(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,jmdxulY90XbNQGP5vSfoz16h)
		if len(JCop4mjTiurYB7W)==YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠲৽"):
			sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(trSQHvP4aqBWFKxN5bZgXCu(u"ࠪๅู๊ࠠโ์ࠣษ๏าวะ่่ࠢๆࠦวๅฬะ้๏๊ࠧॹ"),b098bsyjUud(u"ࠫࠬॺ"))
			return C0CbfZuXJM(u"ࡉࡥࡱࡹࡥਡ")
		elif len(JCop4mjTiurYB7W)==oh1JUWa3LdnqTpz5(u"࠴৾"): zKgFfQoODy90ewYb5jGElUJRVs4p = G5TxeI0ND4ztC6(u"࠴৿")
		elif len(JCop4mjTiurYB7W)>NALF8cewsai2lpT1OqICB0bDdVWrQ(u"࠶਀"):
			zKgFfQoODy90ewYb5jGElUJRVs4p = wicVSPINX4Unkqr5hsgJa6AO8jCT(ebT9xRB63E(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิสࠪॻ"), JCop4mjTiurYB7W)
			if zKgFfQoODy90ewYb5jGElUJRVs4p == -oh1JUWa3LdnqTpz5(u"࠷ਁ") :
				sdJ1cr6xmpoASuhlqjXi3K7eR8kP0(tjoHEAGv2XkrMBsVfCyp5U(u"࠭สๆࠢศ่฿อมࠡษ็ฮา๋๊ๅࠩॼ"),CC4UDLW6brf(u"ࠧࠨॽ"))
				return VVtQk9vwe7(u"ࡊࡦࡲࡳࡦਢ")
		FrC9LhHZWIySdGwNsuzqt5Rf01TXO = EEgFl59RndzrBL8TUoaQMw6P[zKgFfQoODy90ewYb5jGElUJRVs4p]
	yymODKEzwt2NQo9 = b46fBrugtPDSYspzMQIx(u"࠰ਂ")
	if i9lyj1xVYRDEwQzaZ60==GVPK9Ziaho6U2ySLj(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧॾ"):
		w6J70rVDdcWMEO = w6J70rVDdcWMEO.rsplit(Vt4ELHXZP6(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨॿ"))[cg94WALw5orUhvtHSfNO(u"࠱ਃ")]+oh1JUWa3LdnqTpz5(u"ࠪ࠲ࡲࡶ࠴ࠨঀ")
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = zibnBvFtmwKplXrg(mjBa0HgvKnI4oWRd,ebT9xRB63E(u"ࠫࡌࡋࡔࠨঁ"),FrC9LhHZWIySdGwNsuzqt5Rf01TXO,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬ࠭ং"),jmdxulY90XbNQGP5vSfoz16h,b46fBrugtPDSYspzMQIx(u"࠭ࠧঃ"),trSQHvP4aqBWFKxN5bZgXCu(u"ࠧࠨ঄"),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨঅ"))
		cB72KhvLZJa39FdjCTWeVoX = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
		kwqYoF8han = JJDtX1PZyIgN2T.findall(b46fBrugtPDSYspzMQIx(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪআ"),cB72KhvLZJa39FdjCTWeVoX+C0CbfZuXJM(u"ࠪࡠࡳࡢࡲࠨই"),JJDtX1PZyIgN2T.DOTALL)
		if not kwqYoF8han:
			b6kj4LJ5tzTeOMQi(pOIe6U1vWYC7Gh2udFBRgT(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩঈ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+b098bsyjUud(u"ࠬࠦࠠࠡࡖ࡫ࡩࠥࡳ࠳ࡶ࠺ࠣࡪ࡮ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢ࡫ࡥࡻ࡫ࠠࡵࡪࡨࠤࡷ࡫ࡱࡶ࡫ࡵࡩࡩࠦ࡬ࡪࡰ࡮ࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨউ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+uEed4OSxm7hBq9Vvky6QjHwWC(u"࠭ࠠ࡞ࠩঊ"))
			return C0CbfZuXJM(u"ࡋࡧ࡬ࡴࡧਣ")
		wHiSfdBL1v9Kl3n5 = kwqYoF8han[KylMx0kfTOrG(u"࠲਄")]
		if not wHiSfdBL1v9Kl3n5.startswith(WfgnOq9Fd4lhMSQpK5(u"ࠧࡩࡶࡷࡴࠬঋ")):
			if wHiSfdBL1v9Kl3n5.startswith(Vt4ELHXZP6(u"ࠨ࠱࠲ࠫঌ")): wHiSfdBL1v9Kl3n5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠩ࠽ࠫ঍"),trSQHvP4aqBWFKxN5bZgXCu(u"࠴ਅ"))[Wbwj0o5gsXQ8F2f(u"࠴ਆ")]+uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠪ࠾ࠬ঎")+wHiSfdBL1v9Kl3n5
			elif wHiSfdBL1v9Kl3n5.startswith(vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠫ࠴࠭এ")): wHiSfdBL1v9Kl3n5 = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠬࡻࡲ࡭ࠩঐ"))+wHiSfdBL1v9Kl3n5
			else: wHiSfdBL1v9Kl3n5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.rsplit(G5TxeI0ND4ztC6(u"࠭࠯ࠨ঑"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶ਇ"))[C0CbfZuXJM(u"࠶ਈ")]+vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠧ࠰ࠩ঒")+wHiSfdBL1v9Kl3n5
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = yUt4fqQpnL0AZ.request(tvdQHb10PhNmuy6(u"ࠨࡉࡈࡘࠬও"),wHiSfdBL1v9Kl3n5,headers=jmdxulY90XbNQGP5vSfoz16h,verify=G5TxeI0ND4ztC6(u"ࡌࡡ࡭ࡵࡨਤ"))
		hdxNcF1VHGrXCw = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
		Qm95cvoqOKAjwSai0HF4N = len(hdxNcF1VHGrXCw)
		QhSrbEBW4sunlaGgRTty0cqZ = len(kwqYoF8han)
		yymODKEzwt2NQo9 = Qm95cvoqOKAjwSai0HF4N*QhSrbEBW4sunlaGgRTty0cqZ
	else:
		Qm95cvoqOKAjwSai0HF4N = cg94WALw5orUhvtHSfNO(u"࠱ਉ")*rcHgiYv9QXRJtCaPKFn4zoU2G5N
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h = yUt4fqQpnL0AZ.request(pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡊࡉ࡙࠭ঔ"),FrC9LhHZWIySdGwNsuzqt5Rf01TXO,headers=jmdxulY90XbNQGP5vSfoz16h,verify=b46fBrugtPDSYspzMQIx(u"ࡇࡣ࡯ࡷࡪਦ"),stream=xmTX9Aeidq8cVhY(u"ࡔࡳࡷࡨਥ"))
		if vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫক") in UlqnkuTN3EZWXMOyQ9fo2BjiS8h.headers: yymODKEzwt2NQo9 = int(UlqnkuTN3EZWXMOyQ9fo2BjiS8h.headers[ebT9xRB63E(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬখ")])
		QhSrbEBW4sunlaGgRTty0cqZ = int(yymODKEzwt2NQo9//Qm95cvoqOKAjwSai0HF4N)
	n41U7rLeMmPTAWgOiFdxpf2ZY0 = int(yymODKEzwt2NQo9//rcHgiYv9QXRJtCaPKFn4zoU2G5N)+KylMx0kfTOrG(u"࠲ਊ")
	if yymODKEzwt2NQo9<tvdQHb10PhNmuy6(u"࠴࠴࠴࠵࠶਋"):
		b6kj4LJ5tzTeOMQi(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪগ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+uEed4OSxm7hBq9Vvky6QjHwWC(u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡩࡴࠢࡷࡳࡴࠦࡳ࡮ࡣ࡯ࡰࠥࡵࡲࠡ࡫ࡷࠤ࡮ࡹࠠ࡮࠵ࡸ࠼ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঘ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+u2NDjURZVHlmdc0(u"ࠧࠡ࡟ࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫঙ")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+G5TxeI0ND4ztC6(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧচ")+str(U70bPCrxOjD6zctRhQ)+hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬছ")+w6J70rVDdcWMEO+Wbwj0o5gsXQ8F2f(u"ࠪࠤࡢ࠭জ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(WfgnOq9Fd4lhMSQpK5(u"ࠫࠬঝ"),VVtQk9vwe7(u"ࠬ࠭ঞ"),vdHRKkIgTp56Je1OuNo(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),Wbwj0o5gsXQ8F2f(u"ࠧโึ็ࠤๆ๐ࠠๆ฻ิๅฮࠦออ็้้ࠣ็ࠠศๆไ๎ิ๐่ࠡล๋ࠤฬ๊ๅๅใูࠣ฿๐ัࠡฮาหࠥ๎ไ่าสࠤ้อ๋ࠠ็ๆ๊๊ࠥไษำ้ห๊าࠠหฯ่๎้ࠦ็ัษࠣห้๋ไโࠩঠ"))
		return CC4UDLW6brf(u"ࡈࡤࡰࡸ࡫ਧ")
	M42Bgk3z6Gbu19fKZOiESpC = vdHRKkIgTp56Je1OuNo(u"࠷࠴࠵਌")
	ObnK6kuCDIMRjTvVUFPdcgoX = U70bPCrxOjD6zctRhQ-n41U7rLeMmPTAWgOiFdxpf2ZY0
	if ObnK6kuCDIMRjTvVUFPdcgoX<M42Bgk3z6Gbu19fKZOiESpC:
		b6kj4LJ5tzTeOMQi(WfgnOq9Fd4lhMSQpK5(u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ড"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+b098bsyjUud(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨঢ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧণ")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+GVPK9Ziaho6U2ySLj(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪত")+str(U70bPCrxOjD6zctRhQ)+KylMx0kfTOrG(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬথ")+str(M42Bgk3z6Gbu19fKZOiESpC)+WfgnOq9Fd4lhMSQpK5(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩদ")+w6J70rVDdcWMEO+xmTX9Aeidq8cVhY(u"ࠧࠡ࡟ࠪধ"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨࠩন"),b46fBrugtPDSYspzMQIx(u"ࠩࠪ঩"),KylMx0kfTOrG(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪপ"),hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪফ")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+ebT9xRB63E(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫব")+str(U70bPCrxOjD6zctRhQ)+u2NDjURZVHlmdc0(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ভ")+str(M42Bgk3z6Gbu19fKZOiESpC)+oh1JUWa3LdnqTpz5(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩম"))
		return DItWNMaLOZ146CubYk8lfAwTy(u"ࡉࡥࡱࡹࡥਨ")
	J1SavlWIe5EOAdVTQrfGYRhjo8KCw6 = MMTfC8jWkbhxp2BDt(A6Iyo7eXrq2RtMmDxWj(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨয"),xmTX9Aeidq8cVhY(u"ࠩࠪর"),C0CbfZuXJM(u"ࠪࠫ঱"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠫ์๊ࠠหำํำࠥะอๆ์็ࠤฬ๊ๅๅใࠣรࠬল"),vlW6K1g8Xo35mPYbyO2GS(u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥำฬๆ้ࠣฮ็ื๊ษษࠣࠫ঳")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+vlW6K1g8Xo35mPYbyO2GS(u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤฯ่ั๋สสࠤࠬ঴")+str(U70bPCrxOjD6zctRhQ)+G5TxeI0ND4ztC6(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์์ึวࠡษ็้้็ࠠใัࠣ๎าะวอࠢห฽฻ࠦวๅ๊ๅฮ๊ࠥไหฯ่๎้ࠦๅ็ࠢส่ส์สา่อࠤส๊้ࠡฮ๊หื้ࠠ࠯๊่ࠢࠥอๆห่ࠢฮศ้ฯ๊ࠡอี๏ีࠠศๆสืฯ๋ัศำࠣฬฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡมࠪ঵"))
	if J1SavlWIe5EOAdVTQrfGYRhjo8KCw6!=xmTX9Aeidq8cVhY(u"࠵਍"):
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(GVPK9Ziaho6U2ySLj(u"ࠨࠩশ"),oh1JUWa3LdnqTpz5(u"ࠩࠪষ"),mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"ࠪࠫস"),NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩহ"))
		b6kj4LJ5tzTeOMQi(jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬࡔࡏࡕࡋࡆࡉࠬ঺"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+A6Iyo7eXrq2RtMmDxWj(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡳࡧࡩࡹࡸ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ঻")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+YSGNpiTt6Xe8qh39ElIoQvjVxc(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠ়ࠦࠧ")+w6J70rVDdcWMEO+tvdQHb10PhNmuy6(u"ࠨࠢࡠࠫঽ"))
		return A6Iyo7eXrq2RtMmDxWj(u"ࡊࡦࡲࡳࡦ਩")
	b6kj4LJ5tzTeOMQi(pOIe6U1vWYC7Gh2udFBRgT(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩা"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+CC4UDLW6brf(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨি"))
	AL7Kjbmw0qcDit = W2mNFlgkhXS8KIQ0GcTt()
	AL7Kjbmw0qcDit.create(w6J70rVDdcWMEO,b46fBrugtPDSYspzMQIx(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬী"))
	lU1bHOxLZ0fP7MyjhN = hhmKpWNtn849SgBFoVqHkQCXZJvT(u"࡙ࡸࡵࡦਪ")
	XXsM6FBxqztKRYyAlvD = Mrx2OeZV1LNjBsQ58Savi7.time()
	if DQfHadYvTpy1UR: pt7mlKuTQ9S2hovIgz6f = open(w6J70rVDdcWMEO,tvdQHb10PhNmuy6(u"ࠬࡽࡢࠨু"))
	else: pt7mlKuTQ9S2hovIgz6f = open(w6J70rVDdcWMEO.decode(Vt4ELHXZP6(u"࠭ࡵࡵࡨ࠻ࠫূ")),uuxL7t2lIi0JTESMR8kQrNKdjZU3m(u"ࠧࡸࡤࠪৃ"))
	if i9lyj1xVYRDEwQzaZ60==GVPK9Ziaho6U2ySLj(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧৄ"):
		for uvTwHSmjyW6Vr0192IZ in range(Yr0wo7FaSHx(u"࠶਎"),QhSrbEBW4sunlaGgRTty0cqZ+Yr0wo7FaSHx(u"࠶਎")):
			wHiSfdBL1v9Kl3n5 = kwqYoF8han[uvTwHSmjyW6Vr0192IZ-A6Iyo7eXrq2RtMmDxWj(u"࠷ਏ")]
			if not wHiSfdBL1v9Kl3n5.startswith(trSQHvP4aqBWFKxN5bZgXCu(u"ࠩ࡫ࡸࡹࡶࠧ৅")):
				if wHiSfdBL1v9Kl3n5.startswith(ebT9xRB63E(u"ࠪ࠳࠴࠭৆")): wHiSfdBL1v9Kl3n5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.split(uEed4OSxm7hBq9Vvky6QjHwWC(u"ࠫ࠿࠭ে"),WfgnOq9Fd4lhMSQpK5(u"࠱ਐ"))[uEed4OSxm7hBq9Vvky6QjHwWC(u"࠱਑")]+u2NDjURZVHlmdc0(u"ࠬࡀࠧৈ")+wHiSfdBL1v9Kl3n5
				elif wHiSfdBL1v9Kl3n5.startswith(KylMx0kfTOrG(u"࠭࠯ࠨ৉")): wHiSfdBL1v9Kl3n5 = OfTKisDR0Lv(FrC9LhHZWIySdGwNsuzqt5Rf01TXO,vdHRKkIgTp56Je1OuNo(u"ࠧࡶࡴ࡯ࠫ৊"))+wHiSfdBL1v9Kl3n5
				else: wHiSfdBL1v9Kl3n5 = FrC9LhHZWIySdGwNsuzqt5Rf01TXO.rsplit(hhmKpWNtn849SgBFoVqHkQCXZJvT(u"ࠨ࠱ࠪো"),Vt4ELHXZP6(u"࠳਒"))[oh1JUWa3LdnqTpz5(u"࠳ਓ")]+Vt4ELHXZP6(u"ࠩ࠲ࠫৌ")+wHiSfdBL1v9Kl3n5
			UlqnkuTN3EZWXMOyQ9fo2BjiS8h = yUt4fqQpnL0AZ.request(b46fBrugtPDSYspzMQIx(u"ࠪࡋࡊ্࡚ࠧ"),wHiSfdBL1v9Kl3n5,headers=jmdxulY90XbNQGP5vSfoz16h,verify=CC4UDLW6brf(u"ࡌࡡ࡭ࡵࡨਫ"))
			hdxNcF1VHGrXCw = UlqnkuTN3EZWXMOyQ9fo2BjiS8h.content
			UlqnkuTN3EZWXMOyQ9fo2BjiS8h.close()
			pt7mlKuTQ9S2hovIgz6f.write(hdxNcF1VHGrXCw)
			z9aewMpiRy0U5WNhdHuoC6xJ2Tcf = Mrx2OeZV1LNjBsQ58Savi7.time()
			RrbUiCZ5F0Q4gxNSlYPDX9Mq1a = z9aewMpiRy0U5WNhdHuoC6xJ2Tcf-XXsM6FBxqztKRYyAlvD
			UU26Q0l8ciORD4J = RrbUiCZ5F0Q4gxNSlYPDX9Mq1a//uvTwHSmjyW6Vr0192IZ
			cBfYe0rp1kzTw5P7EO = UU26Q0l8ciORD4J*(QhSrbEBW4sunlaGgRTty0cqZ+CC4UDLW6brf(u"࠵ਔ"))
			s4UflFDGAzq90tWZodxETcIuO = cBfYe0rp1kzTw5P7EO-RrbUiCZ5F0Q4gxNSlYPDX9Mq1a
			VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,int(YSGNpiTt6Xe8qh39ElIoQvjVxc(u"࠷࠰࠱ਖ")*uvTwHSmjyW6Vr0192IZ//(QhSrbEBW4sunlaGgRTty0cqZ+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠶ਕ"))),WfgnOq9Fd4lhMSQpK5(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬৎ"),jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬ৏"),str(uvTwHSmjyW6Vr0192IZ*Qm95cvoqOKAjwSai0HF4N//rcHgiYv9QXRJtCaPKFn4zoU2G5N)+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"࠭࠯ࠨ৐")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬ৑")+Mrx2OeZV1LNjBsQ58Savi7.strftime(b46fBrugtPDSYspzMQIx(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ৒"),Mrx2OeZV1LNjBsQ58Savi7.gmtime(s4UflFDGAzq90tWZodxETcIuO))+tjoHEAGv2XkrMBsVfCyp5U(u"ࠩࠣไࠬ৓"))
			if AL7Kjbmw0qcDit.iscanceled():
				lU1bHOxLZ0fP7MyjhN = b46fBrugtPDSYspzMQIx(u"ࡆࡢ࡮ࡶࡩਬ")
				break
	else:
		uvTwHSmjyW6Vr0192IZ = mUgRB7dwVEJ4r5PiquKIY2xvp8hjfc(u"࠰ਗ")
		for hdxNcF1VHGrXCw in UlqnkuTN3EZWXMOyQ9fo2BjiS8h.iter_content(chunk_size=Qm95cvoqOKAjwSai0HF4N):
			pt7mlKuTQ9S2hovIgz6f.write(hdxNcF1VHGrXCw)
			uvTwHSmjyW6Vr0192IZ = uvTwHSmjyW6Vr0192IZ+G5TxeI0ND4ztC6(u"࠲ਘ")
			z9aewMpiRy0U5WNhdHuoC6xJ2Tcf = Mrx2OeZV1LNjBsQ58Savi7.time()
			RrbUiCZ5F0Q4gxNSlYPDX9Mq1a = z9aewMpiRy0U5WNhdHuoC6xJ2Tcf-XXsM6FBxqztKRYyAlvD
			UU26Q0l8ciORD4J = RrbUiCZ5F0Q4gxNSlYPDX9Mq1a/uvTwHSmjyW6Vr0192IZ
			cBfYe0rp1kzTw5P7EO = UU26Q0l8ciORD4J*(QhSrbEBW4sunlaGgRTty0cqZ+tvdQHb10PhNmuy6(u"࠳ਙ"))
			s4UflFDGAzq90tWZodxETcIuO = cBfYe0rp1kzTw5P7EO-RrbUiCZ5F0Q4gxNSlYPDX9Mq1a
			VspYz0aKeZL7uXOI(AL7Kjbmw0qcDit,int(vdHRKkIgTp56Je1OuNo(u"࠵࠵࠶ਛ")*uvTwHSmjyW6Vr0192IZ/(QhSrbEBW4sunlaGgRTty0cqZ+xmTX9Aeidq8cVhY(u"࠴ਚ"))),oh1JUWa3LdnqTpz5(u"ࠪหู้ืาࠢไ์็ࠦ็้่ࠢ็ฬ์ࠠหะี๎๋ࠦๅๅใࠣห้็๊ะ์๋ࠫ৔"),C0CbfZuXJM(u"ࠫั๊ศࠡ็็ๅࠥอไโ์า๎ํࡀ࠭ࠡษ็ะืวࠠาไ่ࠫ৕"),str(uvTwHSmjyW6Vr0192IZ*Qm95cvoqOKAjwSai0HF4N//rcHgiYv9QXRJtCaPKFn4zoU2G5N)+vlW6K1g8Xo35mPYbyO2GS(u"ࠬ࠵ࠧ৖")+str(n41U7rLeMmPTAWgOiFdxpf2ZY0)+Vt4ELHXZP6(u"࠭ࠠࡎࡄࠣࠤ่ࠥࠦใฬ้ࠣฯฮโ๋࠼ࠣࠫৗ")+Mrx2OeZV1LNjBsQ58Savi7.strftime(DItWNMaLOZ146CubYk8lfAwTy(u"ࠢࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ৘"),Mrx2OeZV1LNjBsQ58Savi7.gmtime(s4UflFDGAzq90tWZodxETcIuO))+b46fBrugtPDSYspzMQIx(u"ࠨࠢใࠫ৙"))
			if AL7Kjbmw0qcDit.iscanceled():
				lU1bHOxLZ0fP7MyjhN = VVtQk9vwe7(u"ࡇࡣ࡯ࡷࡪਭ")
				break
		UlqnkuTN3EZWXMOyQ9fo2BjiS8h.close()
	pt7mlKuTQ9S2hovIgz6f.close()
	AL7Kjbmw0qcDit.close()
	if not lU1bHOxLZ0fP7MyjhN:
		b6kj4LJ5tzTeOMQi(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ৚"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+u2NDjURZVHlmdc0(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ৛")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+tjoHEAGv2XkrMBsVfCyp5U(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫড়")+w6J70rVDdcWMEO+VVtQk9vwe7(u"ࠬࠦ࡝ࠨঢ়"))
		ArKbmeZFN7cRuvjfiHBJ0SEqd2l(Yr0wo7FaSHx(u"࠭ࠧ৞"),tjoHEAGv2XkrMBsVfCyp5U(u"ࠧࠨয়"),b098bsyjUud(u"ࠨࠩৠ"),oh1JUWa3LdnqTpz5(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧৡ"))
		return jmhU85aovOS1GxqKBn2RICXgQJ6T(u"ࡖࡵࡹࡪਮ")
	b6kj4LJ5tzTeOMQi(trSQHvP4aqBWFKxN5bZgXCu(u"ࠪࡒࡔ࡚ࡉࡄࡇࠪৢ"),ggSwBRPlX6fJDn2FsvA(FpjtBKrnu5SdfyOvEPIQ)+oh1JUWa3LdnqTpz5(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࡫ࡤࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࡱࡿࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪৣ")+FrC9LhHZWIySdGwNsuzqt5Rf01TXO+tjoHEAGv2XkrMBsVfCyp5U(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬ৤")+w6J70rVDdcWMEO+b098bsyjUud(u"࠭ࠠ࡞ࠩ৥"))
	ArKbmeZFN7cRuvjfiHBJ0SEqd2l(NALF8cewsai2lpT1OqICB0bDdVWrQ(u"ࠧࠨ০"),vJ2Q9gokKptI6YxrhDURClcFOz4(u"ࠨࠩ১"),CC4UDLW6brf(u"ࠩࠪ২"),KylMx0kfTOrG(u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩ৩"))
	return cg94WALw5orUhvtHSfNO(u"ࡗࡶࡺ࡫ਯ")
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䕄"):l1l111_l1_ (u"ࠩࠪ䕅")}
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕࠩ䕆")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪ䕇")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠬ࠹ࠧ䕈"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"࠭࠱ࠨ䕉"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠧ࠳ࠩ䕊"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠨ࠶ࠪ䕋"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䕌"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䕍")+l1lllll_l1_+l1l111_l1_ (u"ࠫ็์วส๊่ࠢฬࠦๅ็่ࠢ์็฿ࠠษษ้๎ฯ࠭䕎"),l1l111_l1_ (u"ࠬ࠭䕏"),38)
	return l1l111_l1_ (u"࠭ࠧ䕐")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠧࠨ䕑")):
	type = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ䕒"))[3]
	if type==l1l111_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䕓"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ䕔"),headers,l1l111_l1_ (u"ࠫࠬ䕕"),l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸࠬ䕖"))
		if select==l1l111_l1_ (u"࠭࠳ࠨ䕗"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࡑࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡹࡥࡳ࡫ࡨࡷࡋࡵࡲ࡮ࠩ䕘"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䕙"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"ࠩๆ่๏ฮวหฺ่ࠢา้ษࠨ䕚") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ䕛"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕜"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠬ࠺ࠧ䕝"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠲ࡪࡥࡵࡣ࡬ࡰࡸ࠳ࡰࡢࡰࡨࡰ࠭࠴ࠪࡀࠫࡹࡂࡁ࠵ࡡ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ䕞"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕟"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ䕠"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䕡"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䕢"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠫࠬ䕣"),headers,l1l111_l1_ (u"ࠬ࠭䕤"),l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔ࠯࠵ࡲࡩ࠭䕥"))
		if select==l1l111_l1_ (u"ࠧ࠲ࠩ䕦"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࡈࡧࡱࡨࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ䕧"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡀ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕨"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳࡬࡫࡮ࡳࡧ࠲ࠫ䕩") + value
				name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭䕪"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕫"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"࠭࠲ࠨ䕬"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࡁࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ䕭"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮࠿࠾ࡲࡴࡹ࡯࡯࡯ࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕮"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ䕯"))
				url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࡦࡩࡴࡰࡴ࠲ࠫ䕰") + value
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕱"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䕲"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ䕳"),headers,l1l111_l1_ (u"ࠧࠨ䕴"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ䕵"))
	if l1l111_l1_ (u"ࠩ࡫ࡳࡲ࡫ࠧ䕶") in url: type=l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䕷")
	if type==l1l111_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䕸"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠩ࠰࠭ࡃ࠮ࡶࡡ࡯ࡧࡷ࠱ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ䕹"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䕺"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ䕻"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕼"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ䕽"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ䕾"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨ䕿"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ䖀"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䖁"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ䖂"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ䖃"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠩ࠴ࠫ䖄"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠨ䖅"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࠬ䖆"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䖇") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䖈"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶ࠲࠯ࡅࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ䖉"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࠩ䖊"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ䖋"))
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ䖌"))
			name = title + l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䖍") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䖎"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡧ࡭ࡻࡳ࡬࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠯ࡄ࠯ࡤࡢࡶࡤ࠱ࡷ࡫ࡶࡪࡸࡨ࠱ࡿࡵ࡮ࡦ࡫ࡧࡁࠧ࠺ࠢࠨ䖏"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䖐"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ࠨืไัฮࠦࠧ䖑") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䖒"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"ࠪࡱࡴࡹࡡ࡭ࡵࡤࡰࡦࡺࠧ䖓") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵ࠱ࡹ࠵࠴ࡹࡥࡳ࡫ࡨࡷࡑ࡯࡮࡬࠱ࠪ䖔") + url.split(l1l111_l1_ (u"ࠬ࠵ࠧ䖕"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䖖"),url,l1l111_l1_ (u"ࠧࠨ䖗"),headers,l1l111_l1_ (u"ࠨࠩ䖘"),l1l111_l1_ (u"ࠩࠪ䖙"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䖚"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䖛"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ䖜"),l1l111_l1_ (u"࠭࠯ࠨ䖝"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䖞"),url,l1l111_l1_ (u"ࠨࠩ䖟"),headers,l1l111_l1_ (u"ࠩࠪ䖠"),l1l111_l1_ (u"ࠪࠫ䖡"),l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䖢"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࡛ࡒࡍࠤࠣࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䖣"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䖤"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠧࠨ䖥")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠨࠢࠪ䖦"),l1l111_l1_ (u"ࠩࠨ࠶࠵࠭䖧"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ䖨"),l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ䖩")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠬ࠷ࠧ䖪")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ䖫"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠧษฯฮࠤ฾์ࠠศใ็ห๊࠭䖬") , l1l111_l1_ (u"ࠨสะฯࠥ฿ๆࠡ็ึุ่๊วหࠩ䖭")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿ࠠษษ้๎ฯࠦ࠭ࠡษัฮึࠦวๅสะฯࠬ䖮"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠪࡣࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࡢࠫ䖯") in options: type = l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ䖰")
		elif l1l111_l1_ (u"ࠬࡥࡐࡂࡐࡈࡘ࠲࡙ࡅࡓࡋࡈࡗࡤ࠭䖱") in options: type = l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭䖲")
		else: return
	headers[l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䖳")] = l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䖴")
	data = {l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࠨ䖵"):l1lll1ll_l1_ , l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡇࡳࡲࡧࡩ࡯ࠩ䖶"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠫ࠶࠭䖷"): data[l1l111_l1_ (u"ࠬ࡬ࡲࡰ࡯ࠪ䖸")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䖹"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ䖺"),data,headers,l1l111_l1_ (u"ࠨࠩ䖻"),l1l111_l1_ (u"ࠩࠪ䖼"),l1l111_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭䖽"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䖾"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨ䖿"),l1l111_l1_ (u"࠭࠯ࠨ䗀"))
			if l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ䗁") in url: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䗂"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ๎้๋ࠠࠨ䗃")+title,url,33)
			elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䗄") in url:
				url = url.replace(l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䗅"),l1l111_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࠫ䗆"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗇"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆี็ื้ࠦࠧ䗈")+title,url+l1l111_l1_ (u"ࠨ࠱࠴ࠫ䗉"),32)
	count=re.findall(l1l111_l1_ (u"ࠩࠥࡸࡴࡺࡡ࡭ࠤ࠽ࠬ࠳࠰࠿ࠪࡿࠪ䗊"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗋"),l1l111_l1_ (u"ฺࠫ็อสࠢࠪ䗌")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠬ࠭䗍"),39,l1l111_l1_ (u"࠭ࠧ䗎"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ䗏")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡣࡋࡖ࠵ࡩࡄࡰࡸࡏ࠶ࡩࢀࡤࡉࡌ࡯࡝࡜࠶࠰ࡍࡰࡅ࡬ࡧࡳࡖ࠱ࡎࡰࡒࡻࡒ࡭࡭ࡵࡏ࠶࡛ࡱ࡚࠳ࡘࡩ࡝࡜ࡐࡹࡍ࠴࡫࡬ࡧࡍࡆࡖࡘ࡬࠽ࡼࡨࡇࡇ࠷ࡥࡋࡱࢀࡤࡄ࠷ࡷࡑ࠸࡛࠴ࠨ䗐")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䗑"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䗒"))
	return
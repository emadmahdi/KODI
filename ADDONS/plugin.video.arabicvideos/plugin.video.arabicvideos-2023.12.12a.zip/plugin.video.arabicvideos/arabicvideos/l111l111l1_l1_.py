# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ⑽")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ⑾")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ⑿"),l1l111_l1_ (u"࠭วๅๅ็ࠫ⒀"),l1l111_l1_ (u"ࠧ࡯࠱ࡄࠫ⒁"),l1l111_l1_ (u"ࠨษ็้ื๐ฯࠨ⒂"),l1l111_l1_ (u"ࠩๅูฮูࠦีไࠪ⒃")]
def l11l1ll_l1_(mode,url,text):
	if   mode==430: l1lll_l1_ = l1l1l11_l1_()
	elif mode==431: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==432: l1lll_l1_ = PLAY(url)
	elif mode==433: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==434: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⒄")+text)
	elif mode==435: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⒅")+text)
	elif mode==436: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==437: l1lll_l1_ = l111ll1l1_l1_(url)
	elif mode==439: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⒆"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭⒇"),l1l111_l1_ (u"ࠧࠨ⒈"),l1l111_l1_ (u"ࠨࠩ⒉"),l1l111_l1_ (u"ࠩࠪ⒊"),l1l111_l1_ (u"ࠪࠫ⒋"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⒌"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⒍"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"࠭࠯ࠨ⒎"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ⒏"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⒐"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⒑"),l1l111_l1_ (u"ࠪࠫ⒒"),439,l1l111_l1_ (u"ࠫࠬ⒓"),l1l111_l1_ (u"ࠬ࠭⒔"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⒕"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒖"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ⒗"),l1l11ll_l1_,435)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒘"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭⒙"),l1l11ll_l1_,434)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⒚"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⒛"),l1l111_l1_ (u"࠭ࠧ⒜"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒝"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⒞")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨ⒟"),l1l11ll_l1_,431)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⒠"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⒡")+l1lllll_l1_+l1l111_l1_ (u"ࠬอแๅษ่ࠤฬ๎ๆࠡๆส๎๋࠭⒢"),l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠷ࠧ⒣"),436)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒤"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⒥")+l1lllll_l1_+l1l111_l1_ (u"่ࠩืู้ไศฬࠣหํ์ࠠๅษํ๊ࠬ⒦"),l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱ࡦࡲ࡬࠲ࠩ⒧"),436)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⒨"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⒩")+l1lllll_l1_+l1l111_l1_ (u"࠭โศศ่อࠥะแึ์็๎ฮ࠭⒪"),l1l11ll_l1_,437)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⒫"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⒬"),l1l111_l1_ (u"ࠩࠪ⒭"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬ⒮"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⒯"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠬอไาศํื๏ฯࠧ⒰"): continue
		if l1l111_l1_ (u"࠭ว้่่ࠣฬ๐ๆࠨ⒱") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⒲"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⒳")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l111ll1l1_l1_(l1l11l11_l1_=l1l111_l1_ (u"ࠩࠪ⒴")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⒵"),l1l11l11_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫⒶ"),l1l111_l1_ (u"ࠬ࠭Ⓑ"),l1l111_l1_ (u"࠭ࠧⒸ"),l1l111_l1_ (u"ࠧࠨⒹ"),l1l111_l1_ (u"ࠨࠩⒺ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫⒻ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧ࡮ࡰࡰ࡬ࡧࡦࡲࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⒼ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠫ࠴࠭Ⓗ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩⒾ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡍ࡫ࡶࡸࡉࡸ࡯ࡱࡧࡧࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭Ⓙ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⓀ"),block,re.DOTALL)
	for category,value,title in items:
		if title in l11lll_l1_: continue
		l1ll1ll_l1_ = l1l11l11_l1_+l1l111_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࡃࠬⓁ")+category+l1l111_l1_ (u"ࠩࡀࠫⓂ")+value
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓃ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭Ⓞ")+l1lllll_l1_+title,l1ll1ll_l1_,431)
	return
def l11ll1_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩⓅ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪⓆ"),url,l1l111_l1_ (u"ࠧࠨⓇ"),l1l111_l1_ (u"ࠨࠩⓈ"),l1l111_l1_ (u"ࠩࠪⓉ"),l1l111_l1_ (u"ࠪࠫⓊ"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩⓋ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓌ"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭Ⓧ"),url,431)
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧⓎ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡫ࡦࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡲࡄࠧⓏ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		if title in l11lll_l1_: continue
		l1lllll1_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࡃࡰ࡫ࡹ࠾ࠩⓐ")+l111l1l1l_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓑ"),l1lllll_l1_+title,l1lllll1_l1_,431)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠫࠬⓒ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩⓓ"))
	items = []
	if l1l111_l1_ (u"࠭࠯ࡕࡧࡵࡱࡸ࠴ࡰࡩࡲࠪⓔ") in url or l1l111_l1_ (u"ࠧ࠰ࡉࡨࡸ࠳ࡶࡨࡱࠩⓕ") in url or l1l111_l1_ (u"ࠨ࠱ࡎࡩࡾࡹ࠮ࡱࡪࡳࠫⓖ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬⓗ"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫⓘ"),l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪⓙ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬⓚ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫⓛ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨⓜ"),l1l111_l1_ (u"ࠨࠩⓝ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ⓞ"))
		html = response.content
		block = html
	elif request==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬⓟ"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨⓠ"),url,l1l111_l1_ (u"ࠬ࠭ⓡ"),l1l111_l1_ (u"࠭ࠧⓢ"),l1l111_l1_ (u"ࠧࠨⓣ"),l1l111_l1_ (u"ࠨࠩⓤ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ⓥ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡕ࡯࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢࡎࡣࡷࡧ࡭࡫ࡳࡕࡣࡥࡰࡪࠨࠧⓦ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧⓧ"),block,re.DOTALL)
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩⓨ"),url,l1l111_l1_ (u"࠭ࠧⓩ"),l1l111_l1_ (u"ࠧࠨ⓪"),l1l111_l1_ (u"ࠨࠩ⓫"),l1l111_l1_ (u"ࠩࠪ⓬"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⓭"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡒࡤ࡫࡮ࡴࡡࡵࡧࠥࠫ⓮"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦࠬ⓯"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⓰"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ⓱"),l1l111_l1_ (u"ࠨใํ่๊࠭⓲"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ⓳"),l1l111_l1_ (u"ࠪ็้๐ศࠨ⓴"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ⓵"),l1l111_l1_ (u"ࠬํฯศใࠪ⓶"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭⓷"),l1l111_l1_ (u"ฺࠧำูࠫ⓸"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ⓹"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ⓺")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬ⓻"))
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ⓼"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⓽"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭⓾") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⓿") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ─"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ━") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ│"),l1lllll_l1_+title,l1ll1ll_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ┃"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	if request!=l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ┄"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭┅"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭┆"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭┇") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
				title = unescapeHTML(title)
				if title!=l1l111_l1_ (u"ࠩࠪ┈"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┉"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢࠪ┊")+title,l1ll1ll_l1_,431)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ┋"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭┌"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ┍"),l1ll1ll_l1_,431)
	return
def l1ll1l11_l1_(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ┎"))
	l11ll1l_l1_,l11ll11_l1_ = [],[]
	if l1l111_l1_ (u"ࠩࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠲ࡵ࡮ࡰࠨ┏") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭┐"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ┑"),l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ┒"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭┓")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ└"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ┕"),l1l111_l1_ (u"ࠩࠪ┖"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ┗"))
		html = response.content
		l11ll11_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ┘"),url,l1l111_l1_ (u"ࠬ࠭┙"),l1l111_l1_ (u"࠭ࠧ┚"),l1l111_l1_ (u"ࠧࠨ┛"),l1l111_l1_ (u"ࠨࠩ├"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ┝"))
		html = response.content
		l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭┞"),html,re.DOTALL)
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡋࡰࡪࡵࡲࡨࡪࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ┟"),html,re.DOTALL)
	if l11ll1l_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡯ࡨ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ┠"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ┡"),block,re.DOTALL)
		for l1ll11l_l1_,l1111lllll_l1_,title in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡆࡲ࡬ࡷࡴࡪࡥࡴ࠰ࡳ࡬ࡵࡅࠧ┢")+l1l111_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮࠾ࠩ┣")+l1111lllll_l1_+l1l111_l1_ (u"ࠩࠩࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ┤")+l1ll11l_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ┥"),l1lllll_l1_+title,l1ll1ll_l1_,433,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ┦"))
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩ┧"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1l1lll_l1_ in items:
			title = title+l1l111_l1_ (u"࠭ࠠࠨ┨")+l1l1lll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭┩"),l1lllll_l1_+title,l1ll1ll_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩ┪")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭┫"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ┬"),l1l111_l1_ (u"ࠫࠬ┭"),l1l111_l1_ (u"ࠬ࠭┮"),l1l111_l1_ (u"࠭ࠧ┯"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ┰"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ┱"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ┲"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ┳"),block,re.DOTALL)
		if l11111lll_l1_:
			l11111lll_l1_ = l11111lll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ┴"),block,re.DOTALL)
			for server,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁࡶࡩࡷࡼࡥࡳ࠿ࠪ┵")+server+l1l111_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ┶")+l11111lll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ┷")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ┸")
				l1llll_l1_.append(l1ll1ll_l1_)
	l111l11111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡩࡧࡴࡤࡱࡪࠨ࠾࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭┹"),html,re.DOTALL)
	if l111l11111_l1_:
		l111l11111_l1_ = l111l11111_l1_[0].replace(l1l111_l1_ (u"ࠪࡠࡳ࠭┺"),l1l111_l1_ (u"ࠫࠬ┻"))
		title = l1l111l_l1_(l111l11111_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ┼"))
		l1ll1ll_l1_ = l111l11111_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ┽")+title+l1l111_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ┾")
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ┿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭╀"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111l1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭╁"),l1l111_l1_ (u"ࠫࠬ╂"))
			if l111l1ll_l1_!=l1l111_l1_ (u"ࠬ࠭╃"): l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ╄")+l111l1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ╅")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ╆")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ╇"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ╈"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ╉"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ╊"),l1l111_l1_ (u"࠭ࠥ࠳࠲ࠪ╋"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ╌")+search
	l1lll11_l1_(url)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ╍"))[0]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭╎"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ╏"),l1l11ll_l1_,l1l111_l1_ (u"ࠫࠬ═"),l1l111_l1_ (u"ࠬ࠭║"),l1l111_l1_ (u"࠭ࠧ╒"),l1l111_l1_ (u"ࠧࠨ╓"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪ╔"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫࡭ࡳ࡭ࡍࡢࡵࡷࡩࡷࠨࠧ╕"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡢࡶࡶࡷࡳࡳࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭ࠬ╖"),block,re.DOTALL)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࡟ࡨ࠰࠯ࠢࠡࡦࡤࡸࡦ࠳࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ╗"),block,re.DOTALL)
	return items
def l111lll11_l1_(url):
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ╘"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ╙"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ╚"),l1l111_l1_ (u"ࠨ࠱ࡨࡼࡵࡲ࡯ࡳࡧ࠲ࡃࠬ╛"))
	return url
def l111l1111l_l1_(l1l1ll11_l1_,url):
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ╜"))
	l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ╝")+l11ll111_l1_
	l1llllll_l1_ = l111lll11_l1_(l1llllll_l1_)
	return l1llllll_l1_
l1l11111_l1_ = [l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭╞"),l1l111_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭╟"),l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ╠"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭╡")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ╢"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ╣"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ╤"),l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭╥"),l1l111_l1_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧ╦"),l1l111_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ╧")]
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠧࡀࠩ╨") in url: url = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ╩"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭╪"),1)
	if filter==l1l111_l1_ (u"ࠪࠫ╫"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠫࠬ╬"),l1l111_l1_ (u"ࠬ࠭╭")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ╮"))
	if type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ╯"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠨ࠿ࠪ╰") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠩࡀࠫ╱") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ╲")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ╳")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ╴")+category+l1l111_l1_ (u"࠭࠽࠱ࠩ╵")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ╶"))+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ╷")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ╸"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭╹"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ╺")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ╻"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ╼"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠧࠨ╽"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ╾"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠩࠪ╿"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ▀")+l11lll11_l1_
		l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▁"),l1lllll_l1_+l1l111_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ▂"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭▃"),l1lllll_l1_+l1l111_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ▄")+l11l1l1l_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ▅"),l1lllll1_l1_,431)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ▆"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ▇"),l1l111_l1_ (u"ࠫࠬ█"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠬ࠳࠭ࠨ▉"),l1l111_l1_ (u"࠭ࠧ▊"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠧ࠾ࠩ▋") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ▌"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					url = l111lll11_l1_(url)
					l1lll11_l1_(url)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ▍")+l1l111l1_l1_)
				return
			else:
				l1lllll1_l1_ = l111lll11_l1_(l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▎"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ▏"),l1lllll1_l1_,431)
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ▐"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ░"),l1lllll1_l1_,435,l1l111_l1_ (u"ࠧࠨ▒"),l1l111_l1_ (u"ࠨࠩ▓"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ▔"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠬ▕")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂ࠶ࠧ▖")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠧ▗")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ▘")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ▙")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ▚"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ▛")+name,l1lllll1_l1_,434,l1l111_l1_ (u"ࠪࠫ▜"),l1l111_l1_ (u"ࠫࠬ▝"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠷ࠬ▞"): option = l1l111_l1_ (u"࠭รโๆส้ࠥ์๊หใ็็ุ࠭▟")
			elif value==l1l111_l1_ (u"ࠧ࠲࠻࠹࠹࠸࠷ࠧ■"): option = l1l111_l1_ (u"ࠨ็ึุ่๊วห้ࠢ๎ฯ็ไไีࠪ□")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠫ▢")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ▣")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫ࠭▤")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃࠧ▥")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ▦")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ▧")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠨ࠲ࠪ▨")]
			title = option+l1l111_l1_ (u"ࠩࠣ࠾ࠬ▩")+name
			if type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭▪"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ▫"),l1lllll_l1_+title,url,434,l1l111_l1_ (u"ࠬ࠭▬"),l1l111_l1_ (u"࠭ࠧ▭"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ▮") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࠪ▯") in l11lll1l_l1_:
				l1llllll_l1_ = l111l1111l_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ▰"),l1lllll_l1_+title,l1llllll_l1_,431)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ▱"),l1lllll_l1_+title,url,435,l1l111_l1_ (u"ࠫࠬ▲"),l1l111_l1_ (u"ࠬ࠭△"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"࠭࠽ࠧࠩ▴"),l1l111_l1_ (u"ࠧ࠾࠲ࠩࠫ▵"))
	filters = filters.strip(l1l111_l1_ (u"ࠨࠨࠪ▶"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠩࡀࠫ▷") in filters:
		items = filters.split(l1l111_l1_ (u"ࠪࠪࠬ▸"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭▹"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭►")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"࠭࠰ࠨ▻")
		if l1l111_l1_ (u"ࠧࠦࠩ▼") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ▽") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ▾"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ▿")+value
		elif mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ◀") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ◁"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠨ◂")+key+l1l111_l1_ (u"ࠧ࠾ࠩ◃")+value
		elif mode==l1l111_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭◄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠩࠫ◅")+key+l1l111_l1_ (u"ࠪࡁࠬ◆")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ◇"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ◈"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"࠭࠽࠱ࠩ◉"),l1l111_l1_ (u"ࠧ࠾ࠩ◊"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜ࠧ㮇")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㮈")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠩ࠳ࠫ㮉"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠵ࠬ㮊"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠷࠭㮋"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠹ࠧ㮌"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠴ࠨ㮍"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㮎"),l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㮏")+l1l111_l1_ (u"ࠩๅ์ฬฬๅࠡใํำ๏๎็ศฬࠣࡑ࠸࡛ࠧ㮐"),l1l111_l1_ (u"ࠪࠫ㮑"),762)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮒"),l1l111_l1_ (u"ࠬࡥࡉࡑࡖࡢࠫ㮓")+l1l111_l1_ (u"࠭โ้ษษ้ࠥ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠬ㮔"),l1l111_l1_ (u"ࠧࠨ㮕"),761)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮖"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠶࡟ࠨ㮗")+l1l111_l1_ (u"ࠪๆ๋๎วห่๊๋่ࠢࠥศไ฼๋ฬࠦวๅลุ่๏ฯࠧ㮘"),l1l111_l1_ (u"ࠫࠬ㮙"),101)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮚"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠷ࡣࠬ㮛")+l1l111_l1_ (u"ࠧใ่๋หฯࠦๅฯฬสีฮࠦๅ็ࠢํ์ฯ๐่ษࠩ㮜"),l1l111_l1_ (u"ࠨࠩ㮝"),106)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮞"),l1l111_l1_ (u"ࠪࡣ࡞࡛ࡔࡠࠩ㮟")+l1l111_l1_ (u"ࠫ็์่ศฬࠣ฽ึฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ㮠"),l1l111_l1_ (u"ࠬ࠭㮡"),147)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮢"),l1l111_l1_ (u"ࠧࡠ࡛ࡘࡘࡤ࠭㮣")+l1l111_l1_ (u"ࠨไ้์ฬะࠠฤฮ้ฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ㮤"),l1l111_l1_ (u"ࠩࠪ㮥"),148)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㮦"),l1l111_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ㮧")+l1l111_l1_ (u"ࠬࠦࠠใ่สอࠥศ๊ࠡใํ่๊ࠦๅ็่ࠢ์็฿็ๆࠢࠣࠫ㮨"),l1l111_l1_ (u"࠭ࠧ㮩"),28)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㮪"),l1l111_l1_ (u"ࠨࡡࡐࡖࡋࡥࠧ㮫")+l1l111_l1_ (u"ࠩๅ๊ฬฯࠠศๆ่฽ฬืแࠡ็้ࠤ๊๎โฺ้่ࠫ㮬"),l1l111_l1_ (u"ࠪࠫ㮭"),41)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㮮"),l1l111_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫ㮯")+l1l111_l1_ (u"࠭โ็ษฬࠤ์๊วࠡ็้ࠤ๊๎โฺࠢหห๋๐สࠨ㮰"),l1l111_l1_ (u"ࠧࠨ㮱"),38)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㮲"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㮳"),l1l111_l1_ (u"ࠪࠫ㮴"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㮵"),l1l111_l1_ (u"ࠬࡥࡔࡗ࠳ࡢࠫ㮶")+l1l111_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡ฻ส้ฮ࠭㮷"),l1l111_l1_ (u"ࠧࠨ㮸"),102)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㮹"),l1l111_l1_ (u"ࠩࡢࡘ࡛࠸࡟ࠨ㮺")+l1l111_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอࠥิวึหࠪ㮻"),l1l111_l1_ (u"ࠫࠬ㮼"),103)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮽"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠶ࡣࠬ㮾")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ็่ๆำีࠨ㮿"),l1l111_l1_ (u"ࠨࠩ㯀"),104)
	return
def ITEMS(l1llll1ll1l_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡘ࡛࠭㯁")+l1llll1ll1l_l1_+l1l111_l1_ (u"ࠪࡣࠬ㯂")
	user = l1l1ll1l11l_l1_(32)
	payload = {l1l111_l1_ (u"ࠫ࡮ࡪࠧ㯃"):l1l111_l1_ (u"ࠬ࠭㯄"),l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㯅"):user,l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㯆"):l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㯇"),l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㯈"):l1llll1ll1l_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㯉"),l111l1_l1_,payload,l1l111_l1_ (u"ࠫࠬ㯊"),l1l111_l1_ (u"ࠬ࠭㯋"),l1l111_l1_ (u"࠭ࠧ㯌"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ㯍"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩ㯎"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠩࡤࡰࠬ㯏"),l1l111_l1_ (u"ࠪࡅࡱ࠭㯐"))
			start = start.replace(l1l111_l1_ (u"ࠫࡊࡲࠧ㯑"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㯒"))
			start = start.replace(l1l111_l1_ (u"࠭ࡁࡍࠩ㯓"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㯔"))
			start = start.replace(l1l111_l1_ (u"ࠨࡇࡏࠫ㯕"),l1l111_l1_ (u"ࠩࡄࡰࠬ㯖"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠪࡅࡱ࠳ࠧ㯗"),l1l111_l1_ (u"ࠫࡆࡲࠧ㯘"))
			start = start.replace(l1l111_l1_ (u"ࠬࡇ࡬ࠡࠩ㯙"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㯚"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l11l11_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠧࠤࠩ㯛") in source: continue
			if source!=l1l111_l1_ (u"ࠨࡗࡕࡐࠬ㯜"): name = name+l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࠦࠠࠨ㯝")+source+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㯞")
			url = source+l1l111_l1_ (u"ࠫࡀࡁࠧ㯟")+server+l1l111_l1_ (u"ࠬࡁ࠻ࠨ㯠")+l1l1l11l11_l1_+l1l111_l1_ (u"࠭࠻࠼ࠩ㯡")+l1llll1ll1l_l1_
			addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㯢"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠩ㯣")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㯤"),l1lllll_l1_+l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㯥"),l1l111_l1_ (u"ࠫࠬ㯦"),9999)
	return
def PLAY(id):
	source,server,l1l1l11l11_l1_,l1llll1ll1l_l1_ = id.split(l1l111_l1_ (u"ࠬࡁ࠻ࠨ㯧"))
	url = l1l111_l1_ (u"࠭ࠧ㯨")
	user = l1l1ll1l11l_l1_(32)
	if source==l1l111_l1_ (u"ࠧࡖࡔࡏࠫ㯩"): url = l1l1l11l11_l1_
	elif source==l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㯪"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㯫")][0]+l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭㯬")+l1l1l11l11_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㯭"),url)
		return
	elif source==l1l111_l1_ (u"ࠬࡍࡁࠨ㯮"):
		payload = { l1l111_l1_ (u"࠭ࡩࡥࠩ㯯") : l1l111_l1_ (u"ࠧࠨ㯰"), l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㯱") : user , l1l111_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㯲") : l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡈࡃ࠴ࠫ㯳") , l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㯴") : l1l111_l1_ (u"ࠬ࠭㯵") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㯶"),l111l1_l1_,payload,l1l111_l1_ (u"ࠧࠨ㯷"),False,l1l111_l1_ (u"ࠨࠩ㯸"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ㯹"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㯺"),l1l111_l1_ (u"ࠫࠬ㯻"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㯼"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㯽"))
			return
		html = response.content
		cookies = response.cookies
		l1l1ll11lll1_l1_ = cookies[l1l111_l1_ (u"ࠧࡂࡕࡓ࠲ࡓࡋࡔࡠࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࠫ㯾")]
		url = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㯿")]
		payload = { l1l111_l1_ (u"ࠩ࡬ࡨࠬ㰀") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㰁") : user , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㰂") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡊࡅ࠷࠭㰃") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㰄") : l1l111_l1_ (u"ࠧࠨ㰅") }
		headers = { l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ㰆") : l1l111_l1_ (u"ࠩࡄࡗࡕ࠴ࡎࡆࡖࡢࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠧ㰇")+l1l1ll11lll1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㰈"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠫࠬ㰉"),l1l111_l1_ (u"ࠬ࠭㰊"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ㰋"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㰌"),l1l111_l1_ (u"ࠨࠩ㰍"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㰎"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㰏"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠫࡷ࡫ࡳࡱࠤ࠽ࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄࡳ࠳ࡶ࠺ࠬࠬ࠳࠰࠿ࠪࠤࠪ㰐"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1l1ll11ll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠸࠯ࠩ㰑")+server+l1l111_l1_ (u"࠭࠷࠸࠹࠲ࠫ㰒")+l1l1l11l11_l1_+l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㰓")+params
		l1l1ll11ll11_l1_ = l1l1ll11ll1l_l1_.replace(l1l111_l1_ (u"ࠨ࠵࠹࠾࠼࠭㰔"),l1l111_l1_ (u"ࠩ࠷࠴࠿࠽ࠧ㰕")).replace(l1l111_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㰖"),l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㰗"))
		l1l1ll11llll_l1_ = l1l1ll11ll1l_l1_.replace(l1l111_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㰘"),l1l111_l1_ (u"࠭࠴࠳࠼࠺ࠫ㰙")).replace(l1l111_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㰚"),l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㰛"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠩࡋࡈࠬ㰜"),l1l111_l1_ (u"ࠪࡗࡉ࠷ࠧ㰝"),l1l111_l1_ (u"ࠫࡘࡊ࠲ࠨ㰞")]
		l1llll_l1_ = [l1l1ll11ll1l_l1_,l1l1ll11ll11_l1_,l1l1ll11llll_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"ࠬࡔࡔࠨ㰟"):
		headers = { l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㰠") : l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭㰡") }
		payload = { l1l111_l1_ (u"ࠨ࡫ࡧࠫ㰢") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㰣") : user , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㰤") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡐࡗࠫ㰥") , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㰦") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㰧"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠧࠨ㰨"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㰩"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㰪"),l1l111_l1_ (u"ࠪࠫ㰫"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㰬"),l1l111_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㰭"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㰮")]
		url = url.replace(l1l111_l1_ (u"ࠧࠦ࠴࠳ࠫ㰯"),l1l111_l1_ (u"ࠨࠢࠪ㰰"))
		url = url.replace(l1l111_l1_ (u"ࠩࠨ࠷ࡉ࠭㰱"),l1l111_l1_ (u"ࠪࡁࠬ㰲"))
		if l1l111_l1_ (u"ࠫࡑ࡫ࡡࡳࡰࠪ㰳") in l1l1l11l11_l1_:
			url = url.replace(l1l111_l1_ (u"ࠬࡔࡔࡏࡐ࡬ࡰࡪ࠭㰴"),l1l111_l1_ (u"࠭ࠧ㰵"))
			url = url.replace(l1l111_l1_ (u"ࠧ࡭ࡧࡤࡶࡳ࡯࡮ࡨ࠳ࠪ㰶"),l1l111_l1_ (u"ࠨࡎࡨࡥࡷࡴࡩ࡯ࡩࠪ㰷"))
	elif source==l1l111_l1_ (u"ࠩࡓࡐࠬ㰸"):
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㰹") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㰺") : user , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㰻") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡔࡑ࠭㰼") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㰽") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㰾"), l111l1_l1_, payload, l1l111_l1_ (u"ࠩࠪ㰿"),False,l1l111_l1_ (u"ࠪࠫ㱀"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠷ࡸ࡭࠭㱁"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㱂"),l1l111_l1_ (u"࠭ࠧ㱃"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㱄"),l1l111_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㱅"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㱆")]
		headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㱇"):response.headers[l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㱈")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㱉"),url, l1l111_l1_ (u"࠭ࠧ㱊"),headers , l1l111_l1_ (u"ࠧࠨ㱋"),l1l111_l1_ (u"ࠨࠩ㱌"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ㱍"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㱎"),l1l111_l1_ (u"ࠫࠬ㱏"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㱐"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㱑"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㱒"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠨࡖࡄࠫ㱓"),l1l111_l1_ (u"ࠩࡉࡑࠬ㱔"),l1l111_l1_ (u"ࠪ࡝࡚࠭㱕"),l1l111_l1_ (u"ࠫ࡜࡙࠱ࠨ㱖"),l1l111_l1_ (u"ࠬ࡝ࡓ࠳ࠩ㱗"),l1l111_l1_ (u"࠭ࡒࡍ࠳ࠪ㱘"),l1l111_l1_ (u"ࠧࡓࡎ࠵ࠫ㱙")]:
		if source==l1l111_l1_ (u"ࠨࡖࡄࠫ㱚"): l1l1l11l11_l1_ = id
		headers = { l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㱛") : l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㱜") }
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㱝") : l1l1l11l11_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㱞") : user , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㱟") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࠬ㱠")+source , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㱡") : l1llll1ll1l_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㱢"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠪࠫ㱣"),l1l111_l1_ (u"ࠫࠬ㱤"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ㱥"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㱦"),l1l111_l1_ (u"ࠧࠨ㱧"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㱨"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㱩"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㱪")]
		if source==l1l111_l1_ (u"ࠫࡋࡓࠧ㱫"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㱬"), url, l1l111_l1_ (u"࠭ࠧ㱭"), l1l111_l1_ (u"ࠧࠨ㱮"), False,l1l111_l1_ (u"ࠨࠩ㱯"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠸ࡶ࡫ࠫ㱰"))
			url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㱱")]
			url = url.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ㱲"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ㱳"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㱴"))
	return
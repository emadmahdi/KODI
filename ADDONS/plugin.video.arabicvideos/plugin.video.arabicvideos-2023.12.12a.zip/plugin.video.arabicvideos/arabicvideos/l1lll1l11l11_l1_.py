# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ䏴")
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䏵"):l1l111_l1_ (u"ࠪࠫ䏶")}
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡃࡎࡡࠪ䏷")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ䏸"),l1l111_l1_ (u"࠭ࡷࡸࡧࠪ䏹")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䏺")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ䏻")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏼"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䏽"),l111l1_l1_,369,l1l111_l1_ (u"ࠫࠬ䏾"),l1l111_l1_ (u"ࠬ࠭䏿"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䐀"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䐁"),l1lllll_l1_+l1l111_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ䐂"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䐃"),364)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䐄"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ䐅"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䐆"),365)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䐇"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䐈"),l1l111_l1_ (u"ࠨࠩ䐉"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䐊"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ䐋"),l1l111_l1_ (u"ࠫࠬ䐌"),l1l111_l1_ (u"ࠬ࠭䐍"),l1l111_l1_ (u"࠭ࠧ䐎"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ䐏"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡑࡴࡲࡨࡺࡩࡴࡪࡱࡱࡷࡑ࡯ࡳࡵࡄࡸࡸࡹࡵ࡮ࠣࠩ䐐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻ࠭ࡪࡶࡨࡱ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䐑"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠪࠫ䐒"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐓"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䐔")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䐕"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䐖"),l1l111_l1_ (u"ࠨࠩ䐗"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ䐘"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䐙"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐚"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䐛")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䐜"),url,l1l111_l1_ (u"ࠧࠨ䐝"),l1l111_l1_ (u"ࠨࠩ䐞"),l1l111_l1_ (u"ࠩࠪ䐟"),l1l111_l1_ (u"ࠪࠫ䐠"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䐡"))
	html = response.content
	if l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶ࠲࠳ࡇࡳ࡫ࡧࠦࠬ䐢") in html:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐣"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ䐤"),url,361,l1l111_l1_ (u"ࠨࠩ䐥"),l1l111_l1_ (u"ࠩࠪ䐦"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䐧"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ䐨"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䐩"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐪"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1lll1lll11l_l1_,type=l1l111_l1_ (u"ࠧࠨ䐫")):
	if l1l111_l1_ (u"ࠨ࠼࠽ࠫ䐬") in l1lll1lll11l_l1_:
		l1llllll_l1_,url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠩ࠽࠾ࠬ䐭"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䐮"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1lll11l_l1_,l1lll1lll11l_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䐯"),url,l1l111_l1_ (u"ࠬ࠭䐰"),l1l111_l1_ (u"࠭ࠧ䐱"),l1l111_l1_ (u"ࠧࠨ䐲"),l1l111_l1_ (u"ࠨࠩ䐳"),l1l111_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䐴"))
	html = response.content
	if type==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䐵"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠨ䐶"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䐷"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"࠭࡜࡝࠱ࠪ䐸"),l1l111_l1_ (u"ࠧ࠰ࠩ䐹")).replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ䐺"),l1l111_l1_ (u"ࠩࠥࠫ䐻"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡋࡷ࡯ࡤ࠮࠯ࡐࡽࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䐼"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ䐽"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭䐾"),l1l111_l1_ (u"࠭ࠧ䐿"))
			if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䑀") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑁"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠩะ่็ฯࠧ䑂") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭䑃"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䑄") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑅"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䑆"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䑇"):
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭䑈"),block,re.DOTALL)
			if l111l1lll1_l1_:
				count = l111l1lll1_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ䑉")+count
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑊"),l1lllll_l1_+l1l111_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ䑋"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠬ࠭䑌"),l1l111_l1_ (u"࠭ࠧ䑍"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䑎"))
		elif type==l1l111_l1_ (u"ࠨࠩ䑏"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䑐"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䑑"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ䑒")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑓"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ䑔")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䑕"),url,l1l111_l1_ (u"ࠨࠩ䑖"),l1l111_l1_ (u"ࠩࠪ䑗"),l1l111_l1_ (u"ࠪࠫ䑘"),l1l111_l1_ (u"ࠫࠬ䑙"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䑚"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤ࡬ࡸࡪࡳࠢࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠭࠴ࠪࡀࠫࠥࠫ䑛"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠧ࠮ࠩ䑜"),l1l111_l1_ (u"ࠨࠢࠪ䑝")).strip(l1l111_l1_ (u"ࠩ࠲ࠫ䑞"))
	if l1l111_l1_ (u"้ࠪํูๅࠨ䑟") in name and type==l1l111_l1_ (u"ࠫࠬ䑠"):
		name = name.split(l1l111_l1_ (u"๋่ࠬิ็ࠪ䑡"))[0]
		name = name.replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭䑢"),l1l111_l1_ (u"ࠧࠨ䑣")).strip(l1l111_l1_ (u"ࠨࠢࠪ䑤"))
	elif l1l111_l1_ (u"ࠩะ่็ฯࠧ䑥") in name:
		name = name.split(l1l111_l1_ (u"ࠪั้่ษࠨ䑦"))[0]
		name = name.replace(l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫ䑧"),l1l111_l1_ (u"ࠬ࠭䑨")).strip(l1l111_l1_ (u"࠭ࠠࠨ䑩"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࠫ䑪"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠨࠩ䑫"):
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䑬"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ䑭") in title: continue
				if l1l111_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ䑮") in title: continue
				title = name+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ䑯")+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑰"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠧࠨ䑱"),l1l111_l1_ (u"ࠨࠩ䑲"),l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ䑳"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠨࠩࠫ䑴"),block+l1l111_l1_ (u"ࠫࠫࠬࠧ䑵"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䑶"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ䑷"))
				title = name+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䑸")+title
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䑹"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䑺"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ䑻"),l1l111_l1_ (u"ࠫࠬ䑼")).replace(l1l111_l1_ (u"๋ࠬิศ้าอࠥ࠭䑽"),l1l111_l1_ (u"࠭ࠧ䑾"))
		else: title = l1l111_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ䑿")
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䒀"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䒁"),url,l1l111_l1_ (u"ࠪࠫ䒂"),l1l111_l1_ (u"ࠫࠬ䒃"),l1l111_l1_ (u"ࠬ࠭䒄"),l1l111_l1_ (u"࠭ࠧ䒅"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䒆"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䒇"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ䒈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䒉"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䒊") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ู๊ࠬาใิࠤ๊อ๊ࠡีํ้ฬ࠭䒋"): name = l1l111_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䒌")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䒍")+name+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䒎")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䒏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䒐"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䒑") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䒒"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"࠭࡟ࡠࡡࡢࠫ䒓")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ䒔")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾࡯ࡼࡧ࡮ࡳࡡࠨ䒕")+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䒖")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䒗"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠫࠬ䒘")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭䒙"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ䒚"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ䒛"),l1l111_l1_ (u"ࠨ࠭ࠪ䒜"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ䒝"),l1l111_l1_ (u"ࠪ࠳ࠬ䒞"),l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡷࡪࡸࡩࡦࡵࠪ䒟"),l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡦࡴࡩ࡮ࡧࠪ䒠"),l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡺࡶࠨ䒡")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠧศๆๆ่ࠬ䒢"),l1l111_l1_ (u"ࠨษ็วๆ๊วๆࠩ䒣"),l1l111_l1_ (u"ࠩสู่๊ไิๆสฮࠬ䒤"),l1l111_l1_ (u"ࠪห้อๆ๋็ํࠤํࠦวๅๅิฮํ์ࠧ䒥"),l1l111_l1_ (u"ࠫฬ๊ศาษ่ะࠥะไ๋ใี๎ํ์๊สࠩ䒦")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ䒧"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"࠭ࠧ䒨"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䒩"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ䒪"),l1l111_l1_ (u"ࠩࠪ䒫"),False,l1l111_l1_ (u"ࠪࠫ䒬"),l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ䒭"))
		hostname = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䒮")]
		hostname = hostname.strip(l1l111_l1_ (u"࠭࠯ࠨ䒯"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ䒰")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1lll11l_l1_,filter):
	if l1l111_l1_ (u"ࠨࡁࡂࠫ䒱") in l1lll1lll11l_l1_: url = l1lll1lll11l_l1_.split(l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䒲"))[0]
	else: url = l1lll1lll11l_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䒳"),l1l111_l1_ (u"ࠫࠬ䒴"))
	type,filter = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䒵"),1)
	if filter==l1l111_l1_ (u"࠭ࠧ䒶"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠧࠨ䒷"),l1l111_l1_ (u"ࠨࠩ䒸")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠩࡢࡣࡤ࠭䒹"))
	if type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䒺"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠫࡂࡃࠧ䒻") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䒼") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䒽")+category+l1l111_l1_ (u"ࠧ࠾࠿࠳ࠫ䒾")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䒿")+category+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭䓀")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭䓁"))+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ䓂")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ䓃"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䓄"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䓅")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ䓆"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䓇"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠪࠫ䓈"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ䓉"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠬ࠭䓊"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䓋")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓌"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ䓍"),l1111111_l1_,361,l1l111_l1_ (u"ࠩࠪ䓎"),l1l111_l1_ (u"ࠪࠫ䓏"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䓐"))
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓑"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭䓒")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭䓓"),l1111111_l1_,361,l1l111_l1_ (u"ࠨࠩ䓔"),l1l111_l1_ (u"ࠩࠪ䓕"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䓖"))
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䓗"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䓘"),l1l111_l1_ (u"࠭ࠧ䓙"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䓚"),url,l1l111_l1_ (u"ࠨࠩ䓛"),l1l111_l1_ (u"ࠩࠪ䓜"),l1l111_l1_ (u"ࠪࠫ䓝"),l1l111_l1_ (u"ࠫࠬ䓞"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ䓟"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"࠭࡜࡝ࠤࠪ䓠"),l1l111_l1_ (u"ࠧࠣࠩ䓡")).replace(l1l111_l1_ (u"ࠨ࡞࡟࠳ࠬ䓢"),l1l111_l1_ (u"ࠩ࠲ࠫ䓣"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭䓤"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ䓥"),block+l1l111_l1_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩ䓦"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ䓧") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩ䓨"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠨ࠿ࡀࠫ䓩") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭䓪"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ䓫")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1lll11l_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓬"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ䓭"),l1111111_l1_,361,l1l111_l1_ (u"࠭ࠧ䓮"),l1l111_l1_ (u"ࠧࠨ䓯"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䓰"))
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓱"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠪ䓲"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠫࠬ䓳"),l1l111_l1_ (u"ࠬ࠭䓴"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧ䓵"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䓶")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀ࠴ࠬ䓷")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䓸")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ䓹")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ䓺")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓻"),l1lllll_l1_+name+l1l111_l1_ (u"࠭࠺ࠡษ็ะ๊๐ูࠨ䓼"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠧࠨ䓽"),l1l111_l1_ (u"ࠨࠩ䓾"),l1l111l1_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓿"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠪࡶࠬ䔀") or value==l1l111_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ䔁"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䔂") in option: continue
			if l1l111_l1_ (u"࠭วๅๅ็ࠫ䔃") in option: continue
			if l1l111_l1_ (u"ࠧ࡯࠯ࡤࠫ䔄") in value: continue
			if option==l1l111_l1_ (u"ࠨࠩ䔅"): option = value
			l1l11l1ll_l1_ = option
			l1ll1l11l11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡲࡦࡳࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡱࡪࡄࠧ䔆"),option,re.DOTALL)
			if l1ll1l11l11_l1_: l1l11l1ll_l1_ = l1ll1l11l11_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠪ࠾ࠥ࠭䔇")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䔈")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔉")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ䔊")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔋")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䔌")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ䔍"):
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔎"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠫࠬ䔏"),l1l111_l1_ (u"ࠬ࠭䔐"),l1l1l11l_l1_+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䔑"))
			elif type==l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ䔒") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔓") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䔔"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䔕")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1lll11l_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔖"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠬ࠭䔗"),l1l111_l1_ (u"࠭ࠧ䔘"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䔙"))
			else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔚"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"ࠩࠪ䔛"),l1l111_l1_ (u"ࠪࠫ䔜"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䔝"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䔞"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭䔟")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠧ࡮ࡲࡤࡥࠬ䔠"),l1l111_l1_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ䔡"),l1l111_l1_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ䔢"),l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ䔣"),l1l111_l1_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬ䔤"),l1l111_l1_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧ䔥"),l1l111_l1_ (u"࠭࡮ࡢࡶ࡬ࡳࡳ࠭䔦"),l1l111_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ䔧")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䔨") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䔩"),l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࠫ䔪"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䔫"),l1l111_l1_ (u"ࠬࡀ࠺࠰ࡃ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶ࠴ࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧ࠰ࠩ䔬"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠽࠾ࠩ䔭"),l1l111_l1_ (u"ࠧ࠰ࠩ䔮"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨࠨࠩࠫ䔯"),l1l111_l1_ (u"ࠩ࠲ࠫ䔰"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭䔱"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠫࠬ䔲")
	if l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔳") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠧࠩ䔴"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾࠿ࠪ䔵"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪ䔶")
		if l1l111_l1_ (u"ࠩࠨࠫ䔷") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ䔸") and value!=l1l111_l1_ (u"ࠫ࠵࠭䔹"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩ䔺")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䔻") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ䔼"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䔽")+key+l1l111_l1_ (u"ࠩࡀࡁࠬ䔾")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧ䔿"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䕀")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䕁")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ䕂"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ䕃"))
	return l1l1l111_l1_